# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ樂")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭樃")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠨࠩ樄")
#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭樅"):l11ll1_l1_ (u"ࠪࠫ樆")}
def MAIN(mode,url,text,type,l1l1111_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11111ll_l1_(url)
	#elif mode==142: results = l1ll1ll111lll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l1111_l1_)
	elif mode==145: results = l1lll111111l1_l1_(url)
	elif mode==146: results = l1ll1ll11111l_l1_(url)
	elif mode==147: results = l1ll1lll1lll1_l1_()
	elif mode==148: results = l1ll1llll1111_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎࡇ࠷࡝ࡩࡘࡌࡄࡘࡷࡿࡲࡂࡵࡏࡖࡻࡋ࡬࡚࡛ࡘࡗࡐࡕࡑࡺࡻࡲࡵࡼࡔ࡙ࠧ樇")
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樈"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡔࡆࡕࡗࠤ࡞ࡕࡕࡕࡗࡅࡉࠬ樉"),url,144)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ樊"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡱ࡯ࡨࡪࡸࠠࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠢࡱࡳࡹࠦ࡬ࡪࡵࡷ࡭ࡳ࡭ࠠ࡯ࡧࡺࡩࡷࠦࡰ࡭ࡻࡤࡰ࡮ࡹࡴࠨ樋"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡇࡲࡴࡩ࡞ࢀࡘ࡛ࡨ࡮ࠪࡱ࡯ࡳࡵ࠿ࡕࡈࡖࡓ࠶࠴ࡸࡋ࡮ࡕ࠶ࡨࡦࡖࡶࠫ樌"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樍"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎โฺࠢไหึเࠧ樎"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡖࡅࡷࡓࡻࡵ࡮࡫࠶ࡊࡽࡴࡶࡍࡕࡏࡅࡥ࠷࠹ࡱࡖࡥࡺࠫ樏"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樐"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ樑"),l11ll1_l1_ (u"ࠨࠩ樒"),149,l11ll1_l1_ (u"ࠩࠪ樓"),l11ll1_l1_ (u"ࠪࠫ樔"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ樕"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樖"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ樗")+l11ll1_l1_ (u"ࠧࡠ࡛ࡗࡇࡤ࠭樘")+l11ll1_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡษ็้อืๅอࠩ標"),l11ll1_l1_ (u"ࠩࠪ樚"),290)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樛"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭樜")+l111l1_l1_+l11ll1_l1_ (u"๋่ࠬศไ฼ࠤฬิสศำ๊หࠥ๐่ห์๋ฬࠬ樝"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ樞"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ樟"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ樠")+l111l1_l1_+l11ll1_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ模"),l11l1l_l1_,144,l11ll1_l1_ (u"ࠪࠫ樢"),l11ll1_l1_ (u"ࠫࠬ樣"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ樤"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樥"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ樦")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้าะ่๊ࠢส่ึอฦอࠩ樧"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ樨"),146)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ権"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ横"),l11ll1_l1_ (u"ࠬ࠭樫"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樬"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ樭")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ樮"),l11ll1_l1_ (u"ࠩࠪ樯"),147)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樰"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭樱")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢฦะ๋ฮ๊สࠩ樲"),l11ll1_l1_ (u"࠭ࠧ樳"),148)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ樴"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ樵")+l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠศใ็หู๊ࠦาสํอࠬ樶"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁๆ๐ไๆࠩ樷"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ樸"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ樹")+l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ樺"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ樻"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樼"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ樽")+l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡ็ึีา๐วหࠢ฼ีอ๐ษࠨ樾"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำาฯํอࠬ樿"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ橀"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ橁")+l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯูࠦาสํอࠬ橂"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืู้ไࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭橃"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ橄"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ橅")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣหั์ศ๋หࠪ橆"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡳࡦࡴ࡬ࡩࡸࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ橇"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭橈"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ橉")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ橊"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ橋"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ橌"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭橍")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣา฼ฮษࠡษ็้ึาู๋หࠪ橎"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰้ัษๆสล࠰อไโุสส๏ฯࠫฯูหอ࠰อไอ็฼อࠫࡹࡰ࠾ࡅࡄࡍࡘࡇࡨࡂࡄࠪ橏"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ橐"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ橑")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่฾ืวใࠢั฻อฯࠠศๆ่ีั฿๊สࠩ橒"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒ࠴࡫ࡗࡴ࠺ࡵࡴࡇ࠴࠸ࡔ࡮ࡺ࡞ࡄࡩࡐࡱࡍࡱࡸࡩࡶࡼࡵࡳ࡙ࡌࡴ࡮ࡨࡵࠫ橓"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ橔"),l111l1_l1_+l11ll1_l1_ (u"ࠬอูะษาหฯࠦวืษไอࠥ๐่ห์๋ฬࠬ橕"),l11ll1_l1_ (u"࠭ࠧ橖"),144)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ橗"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ橘"),l11ll1_l1_ (u"๊ࠩิฬࠦวๅษัฮ๏อัࠡี๋ๅࠥ๐ฮาฮๆࠤ๊์ࠠศๆหี๋อๅอࠩ橙"),l11ll1_l1_ (u"่ࠪศ์็ࠡี๋ๅࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣฬึ์วๆฮࠣ๎ํะ๊้สࠪ橚"))
	#if l1ll111ll1_l1_==1:
	#	url = l11ll1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭橛")
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠪࠩ橜"))
	#	xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡒࡦࡲ࡯ࡥࡨ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡶࡪࡦࡨࡳࡸ࠲ࠧ橝")+url+l11ll1_l1_ (u"ࠧࠪࠩ橞"))
	#	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡔࡸࡲࡆࡪࡤࡰࡰࠫࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠬࠫ機"))
	return
l11ll1_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡐࡅࡎࡔࡐࡂࡉࡈࠬࡺࡸ࡬ࠪ࠼ࠍࠍ࡭ࡺ࡭࡭࠮ࡦࡧ࠱ࡪࡡࡵࡣࠣࡁࠥࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠭ࡻࡲ࡭ࠫࠍࠍ࡮࡬ࠠࠨࡔࡨࡪࡦࡧࡴࠡࡃ࡯࠱ࡌࡧ࡭࡮ࡣ࡯ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡀࠠࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡺࡧࡶࠫ࠮ࠐࠉࡥࡦࠣࡁࠥࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡴࡡࡨࡧࠫࡰࡪࡴࠨࡥࡦࠬ࠭࠿ࠐࠉࠊ࡫ࡷࡩࡲࠦ࠽ࠡࡦࡧ࡟࡮ࡣࠊࠊࠋࡌࡒࡘࡋࡒࡕࡡࡌࡘࡊࡓ࡟ࡕࡑࡢࡑࡊࡔࡕࠩ࡫ࡷࡩࡲ࠯ࠊࠊࡋࡗࡉࡒ࡙ࠨࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤ橠")
def l1ll1lll1lll1_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ橡"))
	return
def l1ll1llll1111_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭橢"))
	return
def PLAY(url,type):
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ橣")
	#items = re.findall(l11ll1_l1_ (u"࠭ࡶ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ橤"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ橥")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ橦"))
	#return
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠫࡹࡷࡲࠩࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࠭࠮࠯࠰࠱ࠫࠡࠢࠪ࠯ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩࠪࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡐࡍࡃ࡜ࡣ࡛ࡏࡄࡆࡑࠫࡰ࡮ࡴ࡫ࡴ࡝࠳ࡡ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࡸࡾࡶࡥࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠍࠧࠨࠢ橧")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1ll11111l_l1_(url):
	html,cc,data = l1ll1lll1l11l_l1_(url)
	dd = cc[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ橨")][l11ll1_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ橩")][l11ll1_l1_ (u"ࠬࡺࡡࡣࡵࠪ橪")]
	for l11ll11111_l1_ in range(len(dd)):
		item = dd[l11ll11111_l1_]
		l1ll1llllll1l_l1_(item,url,str(l11ll11111_l1_))
	ee = dd[0][l11ll1_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ橫")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ橬")][l11ll1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ橭")][l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ橮")]
	s = 0
	for l11ll11111_l1_ in range(len(ee)):
		item = ee[l11ll11111_l1_][l11ll1_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ橯")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭橰")][0]
		if list(item[l11ll1_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ橱")][l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ橲")].keys())[0]==l11ll1_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ橳"): continue
		succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_ = l1lll11111ll1_l1_(item)
		if not title:
			s += 1
			title = l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣีฬฬฬสࠢࠪ橴")+str(s)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ橵"),l111l1_l1_+title,url,144,l11ll1_l1_ (u"ࠪࠫ橶"),str(l11ll11111_l1_))
	key = re.findall(l11ll1_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ橷"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ橸")+key[0]
	html,cc,l11ll111l_l1_ = l1ll1lll1l11l_l1_(l111lll_l1_)
	for l1ll1l1l11l1_l1_ in range(3,4):
		dd = cc[l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ橹")][l1ll1l1l11l1_l1_][l11ll1_l1_ (u"ࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ橺")][l11ll1_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ橻")]
		for l11ll11111_l1_ in range(len(dd)):
			item = dd[l11ll11111_l1_]
			if l11ll1_l1_ (u"ࠩ࡜ࡳࡺ࡚ࡵࡣࡧࠣࡔࡷ࡫࡭ࡪࡷࡰࠫ橼") in str(item): continue
			l1ll1llllll1l_l1_(item)
	return
def ITEMS(url,data=l11ll1_l1_ (u"ࠪࠫ橽"),index=0):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭橾"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ橿"),l11ll1_l1_ (u"࠭ࠧ檀"))
	html,cc,l11ll111l_l1_ = l1ll1lll1l11l_l1_(url,data)
	l1l1111111_l1_,ff = l11ll1_l1_ (u"ࠧࠨ檁"),l11ll1_l1_ (u"ࠨࠩ檂")
	#if l11ll1_l1_ (u"ࠩࡲࡻࡳ࡫ࡲࠨ檃") in html.lower(): DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ檄"),l11ll1_l1_ (u"ࠫࠬ檅"),l11ll1_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠤࡪࡾࡩࡴࡶࠪ檆"),l11ll1_l1_ (u"࠭ࡩ࡯ࠢ࡫ࡸࡲࡲࠧ檇"))
	owner = re.findall(l11ll1_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࡎࡢ࡯ࡨࠦ࠳࠰࠿ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ檈"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠨࠤࡹ࡭ࡩ࡫࡯ࡐࡹࡱࡩࡷࠨ࠮ࠫࡁࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ檉"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ檊"),html,re.DOTALL)
	if owner:
		l1l1111111_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭檋")+owner[0][0]+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭檌")
		l1lllll_l1_ = owner[0][1]
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ檍") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		#if l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ檎") in url and l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ檏") not in url and l11ll1_l1_ (u"ࠨ࠱ࡦ࠳ࠬ檐") not in url and l11ll1_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ檑") not in url:
		if l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ檒") in url: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ檓"),l111l1_l1_+l1l1111111_l1_,l1lllll_l1_,144)
	#if cc==l11ll1_l1_ (u"ࠬ࠭檔"): l1ll1ll111ll1_l1_(url,html) ; return
	l1ll1ll111l11_l1_ = [l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ檕"),l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ檖"),l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ檗"),l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭檘"),l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭檙"),l11ll1_l1_ (u"ࠫࡸࡹ࠽ࠨ檚"),l11ll1_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭檛"),l11ll1_l1_ (u"࠭࡫ࡦࡻࡀࠫ檜"),l11ll1_l1_ (u"ࠧࡣࡲࡀࠫ檝"),l11ll1_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ檞")]
	l1ll1l1llllll_l1_ = not any(value in url for value in l1ll1ll111l11_l1_)
	if l1ll1l1llllll_l1_ and l1l1111111_l1_:
		l11l1l11l_l1_ = l11ll1_l1_ (u"ࠩส่อำหࠨ檟")
		l1lll1l11_l1_ = l11ll1_l1_ (u"ࠪๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ檠")
		l11l1l111_l1_ = l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠨ檡")
		l1ll1ll111111_l1_ = l11ll1_l1_ (u"ࠬอไใ่๋หฯ࠭檢")
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ檣"),l111l1_l1_+l1l1111111_l1_,url,9999)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤหัะࠨࠧ檤") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檥"),l111l1_l1_+l11l1l11l_l1_,url,145,l11ll1_l1_ (u"ࠩࠪ檦"),l11ll1_l1_ (u"ࠪࠫ檧"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ檨"))
		if l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ檩") in html: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檪"),l111l1_l1_+l1lll1l11_l1_,url+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ檫"),144)
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ檬") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ檭"),l111l1_l1_+l11l1l111_l1_,url+l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ檮"),144)
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ檯") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ檰"),l111l1_l1_+l1ll1ll111111_l1_,url+l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ檱"),144)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡖࡩࡦࡸࡣࡩࠤࠪ檲") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檳"),l111l1_l1_+l11l1l11l_l1_,url,145,l11ll1_l1_ (u"ࠩࠪ檴"),l11ll1_l1_ (u"ࠪࠫ檵"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ檶"))
		if l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ檷") in html: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檸"),l111l1_l1_+l1lll1l11_l1_,url+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ檹"),144)
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ檺") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ檻"),l111l1_l1_+l11l1l111_l1_,url+l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ檼"),144)
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ檽") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ檾"),l111l1_l1_+l1ll1ll111111_l1_,url+l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ檿"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ櫀"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ櫁"),l11ll1_l1_ (u"ࠩࠪ櫂"),9999)
	if l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ櫃") in url:
		dd = cc[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭櫄")][l11ll1_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫅")][l11ll1_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ櫆")][l11ll1_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭櫇")][l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ櫈")]
		l1ll1l1lllll1_l1_ = 0
		for i in range(len(dd)):
			if l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫉") in list(dd[i].keys()):
				l1ll1l1llll1l_l1_ = dd[i][l11ll1_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ櫊")]
				length = len(str(l1ll1l1llll1l_l1_))
				if length>l1ll1l1lllll1_l1_:
					l1ll1l1lllll1_l1_ = length
					ff = l1ll1l1llll1l_l1_
		if l1ll1l1lllll1_l1_==0: return
	elif l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ櫋") in url or l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ櫌") in url or l11ll1_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ櫍") in url or l11ll1_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ櫎") in url or l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ櫏") in url or url==l11l1l_l1_:
		l1ll1ll1l1l1l_l1_ = []
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ櫐"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ櫑"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ櫒"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ櫓"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ櫔"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠯࠴ࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ櫕"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ櫖"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡗࡢࡶࡦ࡬ࡓ࡫ࡸࡵࡔࡨࡷࡺࡲࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣࠢ櫗"))
		l1ll1ll1111ll_l1_,ff = l1ll1ll11l1l1_l1_(cc,l11ll1_l1_ (u"ࠪࠫ櫘"),l1ll1ll1l1l1l_l1_)
	if not ff:
		try:
			dd = cc[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭櫙")][l11ll1_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫚")][l11ll1_l1_ (u"࠭ࡴࡢࡤࡶࠫ櫛")]
			l1ll1lll1ll1_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ櫜") in url or l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ櫝") in url or l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ櫞") in url
			l1ll1ll11lll1_l1_ = l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ櫟") in html or l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ櫠") in html or l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ櫡") in html
			l1ll1ll11ll1l_l1_ = l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ櫢") in html or l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭櫣") in html or l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭櫤") in html
			if l1ll1lll1ll1_l1_ and (l1ll1ll11lll1_l1_ or l1ll1ll11ll1l_l1_):
				for l11ll11111_l1_ in range(len(dd)):
					if l11ll1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ櫥") not in list(dd[l11ll11111_l1_].keys()): continue
					ee = dd[l11ll11111_l1_][l11ll1_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫦")]
					try: gg = ee[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ櫧")][l11ll1_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ櫨")][l11ll1_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ櫩")][l11ll1_l1_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ櫪")][l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫ櫫")][l11ll11111_l1_]
					except: gg = ee
					try: l1lllll_l1_ = gg[l11ll1_l1_ (u"ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫ櫬")][l11ll1_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ櫭")][l11ll1_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ櫮")][l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ櫯")]
					except: continue
					if   l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ櫰")		in l1lllll_l1_	and l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ櫱")		in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ櫲")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭櫳")	in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭櫴")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ櫵")		in url: ee = dd[l11ll11111_l1_] ; break
					else: ee = dd[0]
			elif l11ll1_l1_ (u"ࠬࡨࡰ࠾ࠩ櫶") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11ll1_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ櫷")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ櫸")]
		except: pass
	if not ff: return
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ櫹"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ櫺"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ櫻"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ櫼"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ櫽"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ櫾"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ櫿"))
	if l11ll1_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ欀") not in url: l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩࡠ࡟ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭࡝ࠣ欁"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ欂"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ欃"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ欄"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ欅"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ欆"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ欇"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ欈"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ欉"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬ࠢ權"))
	l111l1lllll_l1_ = l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡺ࠭ใๅࠢๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ欋"))
	l111ll11111_l1_ = l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡻࠧไๆࠣห้็๊ะ์๋๋ฬะࠧ欌"))
	l1ll1ll1111l1_l1_ = l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡵࠨๅ็ࠤฬ๊โ็๊สฮࠬ欍"))
	l11l1llll11l_l1_ = [l111l1lllll_l1_,l111ll11111_l1_,l1ll1ll1111l1_l1_,l11ll1_l1_ (u"ࠨࡃ࡯ࡰࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ欎"),l11ll1_l1_ (u"ࠩࡄࡰࡱࠦࡶࡪࡦࡨࡳࡸ࠭欏"),l11ll1_l1_ (u"ࠪࡅࡱࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ欐")]
	l1ll1ll111l1l_l1_,gg = l1ll1ll11l1l1_l1_(ff,index,l1ll1ll1l1l1l_l1_)
	if l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ欑") in str(type(gg)) and any(value in str(gg[0]) for value in l11l1llll11l_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll1ll1l1l1l_l1_ = []
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ欒"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ欓"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ欔"))
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ欕"))		#4
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ欖"))		#7
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ欗"))		#6
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ欘"))		#5
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞ࠤ欙"))
		l1ll1ll1111ll_l1_,item = l1ll1ll11l1l1_l1_(gg,index2,l1ll1ll1l1l1l_l1_)
		#if l1ll1ll1111ll_l1_ not in [l11ll1_l1_ (u"࠭࠲ࠨ欚"),l11ll1_l1_ (u"ࠧ࠵ࠩ欛"),l11ll1_l1_ (u"ࠨ࠷ࠪ欜")]: l1ll1llllll1l_l1_(item)		# 2,4,7
		#else: l1ll1llllll1l_l1_(item,url,str(index2))
		l1ll1llllll1l_l1_(item,url,str(index2))
		if l1ll1ll1111ll_l1_==l11ll1_l1_ (u"ࠩ࠷ࠫ欝"):
			try:
				hh = item[l11ll1_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ欞")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ欟")][l11ll1_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ欠")][l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ次")]
				for l1ll1lll1ll11_l1_ in range(len(hh)):
					l1ll1ll11l111_l1_ = hh[l1ll1lll1ll11_l1_]
					l1ll1llllll1l_l1_(l1ll1ll11l111_l1_)
			except: pass
	l1ll1ll1lll1l_l1_ = False
	if l11ll1_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭欢") not in url and l1ll1ll111l1l_l1_==l11ll1_l1_ (u"ࠨ࠺ࠪ欣"): l1ll1ll1lll1l_l1_ = True
	if l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭欤") in l11ll111l_l1_: l1ll1llll1l1l_l1_,key,l1lll11111l1l_l1_,l1ll1lll1llll_l1_,token,l1ll1lll1111l_l1_ = l11ll111l_l1_.split(l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ欥"))
	else: l1ll1llll1l1l_l1_,key,l1lll11111l1l_l1_,l1ll1lll1llll_l1_,token,l1ll1lll1111l_l1_ = l11ll1_l1_ (u"ࠫࠬ欦"),l11ll1_l1_ (u"ࠬ࠭欧"),l11ll1_l1_ (u"࠭ࠧ欨"),l11ll1_l1_ (u"ࠧࠨ欩"),l11ll1_l1_ (u"ࠨࠩ欪"),l11ll1_l1_ (u"ࠩࠪ欫")
	l111lll_l1_,l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ欬"),l11ll1_l1_ (u"ࠫࠬ欭")
	if menuItemsLIST:
		l1ll1ll11ll11_l1_ = str(menuItemsLIST[-1][1])
		if   l111l1_l1_+l11ll1_l1_ (u"ࠬࡉࡈࡏࡎࠪ欮") in l1ll1ll11ll11_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ欯")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠧࡖࡕࡈࡖࠬ欰") in l1ll1ll11ll11_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ欱")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ欲") in l1ll1ll11ll11_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠪࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭欳")
	if l11ll1_l1_ (u"ࠫࠧࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡷࠧ࠭欴") in html and l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ欵") not in url and not l1ll1ll1lll1l_l1_ and l11ll1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤࠨ欶") not in url:	# and (index!=l11ll1_l1_ (u"ࠧࠨ欷") or l11ll1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ欸") in url or l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ欹") in url or l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ欺") in url or l11ll1_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ欻") in url):
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡥࡡ࡫ࡣࡻࡃࡨࡺ࡯࡬ࡧࡱࡁࠬ欼")+l1lll11111l1l_l1_
	elif l11ll1_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨࠧ欽") in html and l11ll1_l1_ (u"ࠧࡣࡲࡀࠫ款") not in url and l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ欿") in url or l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ歀") in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ歁")+key
	elif l11ll1_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ歂") in html and l11ll1_l1_ (u"ࠬࡨࡰ࠾ࠩ歃") not in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ歄")+key
	if l111lll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歅"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ歆"),l111lll_l1_,144,l1ll1l111l1_l1_,l11ll1_l1_ (u"ࠩࠪ歇"),l11ll111l_l1_)
	return
def l1ll1ll11l1l1_l1_(l11ll1l11111_l1_,l11ll1l1ll11_l1_,l1ll1ll1llll1_l1_):
	cc = l11ll1l11111_l1_
	ff,index = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	gg,index2 = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	item,render = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	count = len(l1ll1ll1llll1_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1ll1llll1_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠪࠫ歈")
			return str(l11ll11111_l1_+1),out
		except: pass
	return l11ll1_l1_ (u"ࠫࠬ歉"),l11ll1_l1_ (u"ࠬ࠭歊")
def l1lll11111ll1_l1_(item):
	try: l1ll1lllll11l_l1_ = list(item.keys())[0]
	except: return False,l11ll1_l1_ (u"࠭ࠧ歋"),l11ll1_l1_ (u"ࠧࠨ歌"),l11ll1_l1_ (u"ࠨࠩ歍"),l11ll1_l1_ (u"ࠩࠪ歎"),l11ll1_l1_ (u"ࠪࠫ歏"),l11ll1_l1_ (u"ࠫࠬ歐"),l11ll1_l1_ (u"ࠬ࠭歑")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_ = False,l11ll1_l1_ (u"࠭ࠧ歒"),l11ll1_l1_ (u"ࠧࠨ歓"),l11ll1_l1_ (u"ࠨࠩ歔"),l11ll1_l1_ (u"ࠩࠪ歕"),l11ll1_l1_ (u"ࠪࠫ歖"),l11ll1_l1_ (u"ࠫࠬ歗"),l11ll1_l1_ (u"ࠬ࠭歘")
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧ歙"),str(item))
	render = item[l1ll1lllll11l_l1_]
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡷࡱࡴࡱࡧࡹࡢࡤ࡯ࡩ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ歚"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡩࡳࡷࡳࡡࡵࡶࡨࡨ࡙࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ歛"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ歜"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ歝"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ歞"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ歟"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ歠"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ歡"))
	l1ll1ll1111ll_l1_,title = l1ll1ll11l1l1_l1_(item,render,l1ll1ll1l1l1l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ止"),l11ll1_l1_ (u"ࠩࠪ正"),l11ll1_l1_ (u"ࠪࠫ此"),title)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ步"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ武"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ歧"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ歨")) # required for l11ll11l1l11_l1_ l1ll1ll1lll1l_l1_
	l1ll1ll1111ll_l1_,l1lllll_l1_ = l1ll1ll11l1l1_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ歩"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ歪"))
	l1ll1ll1111ll_l1_,l1lll1_l1_ = l1ll1ll11l1l1_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࠨ࡟ࠥ歫"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࡖࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ歬"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡇࡵࡴࡵࡱࡰࡔࡦࡴࡥ࡭ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ歭"))
	l1ll1ll1111ll_l1_,count = l1ll1ll11l1l1_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ歮"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ歯"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ歰"))
	l1ll1ll1111ll_l1_,l1l11ll1l_l1_ = l1ll1ll11l1l1_l1_(item,render,l1ll1ll1l1l1l_l1_)
	if l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ歱") in l1l11ll1l_l1_: l1l11ll1l_l1_,l111lllll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ歲"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ歳")
	if l11ll1_l1_ (u"๋ࠬศศึิࠫ歴") in l1l11ll1l_l1_: l1l11ll1l_l1_,l111lllll1l_l1_ = l11ll1_l1_ (u"࠭ࠧ歵"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ歶")
	if l11ll1_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ歷") in list(render.keys()):
		l1ll1lllllll1_l1_ = str(render[l11ll1_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ歸")])
		if l11ll1_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ歹") in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠫࠩࡀࠧ歺")
		if l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠣࡒࡔ࡝ࠧ死") in l1ll1lllllll1_l1_: l111lllll1l_l1_ = l11ll1_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ歼")
		if l11ll1_l1_ (u"ࠧࡃࡷࡼࠫ歽") in l1ll1lllllll1_l1_ or l11ll1_l1_ (u"ࠨࡔࡨࡲࡹ࠭歾") in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠩࠧࠨ࠿࠭歿")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡸ๊ࠫฮวีำࠪ殀")) in l1ll1lllllll1_l1_: l111lllll1l_l1_ = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ殁")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡺ࠭ิาษฤࠫ殂")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"࠭ࠤࠥ࠼ࠪ殃")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡵࠨษึฮหาวาࠩ殄")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠨࠦࠧ࠾ࠬ殅")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ殆")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠪࠨ࠿࠭殇")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ殈") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠬࡅࠧ殉"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ殊") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ残")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1lll1l1l1_l1_: title = l1ll1lll1l1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠫ殌")+title
	#title = unescapeHTML(title)
	l1l11ll1l_l1_ = l1l11ll1l_l1_.replace(l11ll1_l1_ (u"ࠩ࠯ࠫ殍"),l11ll1_l1_ (u"ࠪࠫ殎"))
	count = count.replace(l11ll1_l1_ (u"ࠫ࠱࠭殏"),l11ll1_l1_ (u"ࠬ࠭殐"))
	count = re.findall(l11ll1_l1_ (u"࠭࡜ࡥ࠭ࠪ殑"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠧࠨ殒")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_
def l1ll1llllll1l_l1_(item,url=l11ll1_l1_ (u"ࠨࠩ殓"),index=l11ll1_l1_ (u"ࠩࠪ殔")):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_ = l1lll11111ll1_l1_(item)
	#if l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ殕") in url and index==l11ll1_l1_ (u"ࠫ࠵࠭殖"):
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殗"),l111l1_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殘") in str(item): return	# l1lll11111l1l_l1_ not items
	elif l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ殙") in str(item): return			# l1ll1lllll1ll_l1_ not items
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ殚") in url: return			# separator l1ll1l1llll11_l1_ list not items
	elif title and not l1lllll_l1_ and (l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ殛") in url or l11ll1_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殜") in str(item) or url==l11l1l_l1_):
		title = l11ll1_l1_ (u"ࠫࡂࡃ࠽ࠡࠩ殝")+title+l11ll1_l1_ (u"ࠬࠦ࠽࠾࠿ࠪ殞")
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ殟"),l111l1_l1_+title,l11ll1_l1_ (u"ࠧࠨ殠"),9999)
	elif title and l11ll1_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殡") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ殢"),l111l1_l1_+title,l11ll1_l1_ (u"ࠪࠫ殣"),9999)
	elif l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ殤") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殥"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif not title: return
	elif l111lllll1l_l1_: addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ殦"),l111l1_l1_+l111lllll1l_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	#elif l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭殧") in l1lllll_l1_ and l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ殨") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠩࡷࡁ࠵࠭殩") not in l1lllll_l1_:
	#	l1ll1lll1l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ殪"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭殫")+l1ll1lll1l1ll_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殬"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡌࡊࡕࡗࠫ殭")+count+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ殮")+title,l1lllll_l1_,144,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ殯") in l1lllll_l1_ or l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ殰") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ殱") in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ殲") not in l1lllll_l1_:
			l1ll1lll1l1ll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ殳"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ殴")+l1ll1lll1l1ll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ段"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡎࡌࡗ࡙࠭殶")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭殷")+title,l1lllll_l1_,144,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ殸"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ殹"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11ll1l_l1_)
	else:
		type = l11ll1_l1_ (u"ࠬ࠭殺")
		if not l1lllll_l1_: l1lllll_l1_ = url
		#if l11ll1_l1_ (u"࠭ࡳࡴ࠿ࠪ殻") in l1lllll_l1_: l1lllll_l1_ = url
		#elif l11ll1_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ殼") in l1lllll_l1_: l1lllll_l1_ = url		# not needed it will stop l1ll1ll11l11l_l1_ l11ll11l1l11_l1_ l1ll1ll1lll1l_l1_
		elif not any(value in l1lllll_l1_ for value in [l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ殽"),l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭殾"),l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭殿"),l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ毀"),l11ll1_l1_ (u"ࠬࡹࡳ࠾ࠩ毁"),l11ll1_l1_ (u"࠭ࡢࡱ࠿ࠪ毂")]):
			if l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ毃")	in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡦ࠳ࠬ毄") in l1lllll_l1_: type = l11ll1_l1_ (u"ࠩࡆࡌࡓࡒࠧ毅")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ毆")
			if l11ll1_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ毇") in l1lllll_l1_: type = l11ll1_l1_ (u"࡛ࠬࡓࡆࡔࠪ毈")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ毉")
			index,l1ll1llll11ll_l1_ = l11ll1_l1_ (u"ࠧࠨ毊"),l11ll1_l1_ (u"ࠨࠩ毋")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毌"),l111l1_l1_+type+title,l1lllll_l1_,144,l1lll1_l1_,index)
	return
def l1ll1lll1l11l_l1_(url,data=l11ll1_l1_ (u"ࠪࠫ母"),request=l11ll1_l1_ (u"ࠫࠬ毎")):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ每"))
	#if l11ll1_l1_ (u"࠭࡟ࡠࠩ毐") in l1ll1llll11ll_l1_: l1ll1llll11ll_l1_ = l11ll1_l1_ (u"ࠧࠨ毑")
	#if l11ll1_l1_ (u"ࠨࡵࡶࡁࠬ毒") in url: url = url.split(l11ll1_l1_ (u"ࠩࡶࡷࡂ࠭毓"))[0]
	if request==l11ll1_l1_ (u"ࠪࠫ比"): request = l11ll1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ毕")
	l111lll1ll_l1_ = l11lllll1_l1_()
	l1l1ll111_l1_ = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ毖"):l111lll1ll_l1_,l11ll1_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭毗"):l11ll1_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ毘")}
	#l1l1ll111_l1_ = headers.copy()
	if l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ毙") in data: l1ll1llll1l1l_l1_,key,l1lll11111l1l_l1_,l1ll1lll1llll_l1_,token,l1ll1lll1111l_l1_ = data.split(l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭毚"))
	else: l1ll1llll1l1l_l1_,key,l1lll11111l1l_l1_,l1ll1lll1llll_l1_,token,l1ll1lll1111l_l1_ = l11ll1_l1_ (u"ࠪࠫ毛"),l11ll1_l1_ (u"ࠫࠬ毜"),l11ll1_l1_ (u"ࠬ࠭毝"),l11ll1_l1_ (u"࠭ࠧ毞"),l11ll1_l1_ (u"ࠧࠨ毟"),l11ll1_l1_ (u"ࠨࠩ毠")
	if l11ll1_l1_ (u"ࠩࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭毡") in url:
		l11ll111l_l1_ = {}
		l11ll111l_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ毢")] = {l11ll1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ毣"):{l11ll1_l1_ (u"ࠧ࡮࡬ࠣ毤"):l11ll1_l1_ (u"ࠨࡡࡳࠤ毥"),l11ll1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ毦"):l11ll1_l1_ (u"࡙ࠣࡈࡆࠧ毧"),l11ll1_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ毨"):l1ll1lll1llll_l1_}}
		l11ll111l_l1_ = str(l11ll111l_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ毩"),url,l11ll111l_l1_,l1l1ll111_l1_,True,True,l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠷ࡳࡵࠩ毪"))
	elif l11ll1_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ毫") in url and l1ll1llll1l1l_l1_:
		l11ll111l_l1_ = {l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ毬"):token}
		l11ll111l_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ毭")] = {l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ毮"):{l11ll1_l1_ (u"ࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ毯"):l1ll1llll1l1l_l1_,l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ毰"):l11ll1_l1_ (u"ࠦ࡜ࡋࡂࠣ毱"),l11ll1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ毲"):l1ll1lll1llll_l1_}}
		l11ll111l_l1_ = str(l11ll111l_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ毳"),url,l11ll111l_l1_,l1l1ll111_l1_,True,True,l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠴ࡱࡨࠬ毴"))
	elif l11ll1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ毵") in url and l1ll1lll1111l_l1_:
		l1l1ll111_l1_.update({l11ll1_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ毶"):l11ll1_l1_ (u"ࠪ࠵ࠬ毷"),l11ll1_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ毸"):l1ll1lll1llll_l1_})
		l1l1ll111_l1_.update({l11ll1_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ毹"):l11ll1_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࡁࠬ毺")+l1ll1lll1111l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ毻"),url,l11ll1_l1_ (u"ࠨࠩ毼"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠩࠪ毽"),l11ll1_l1_ (u"ࠪࠫ毾"),l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ毿"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ氀"),url,l11ll1_l1_ (u"࠭ࠧ氁"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨ氂"),l11ll1_l1_ (u"ࠨࠩ氃"),l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ氄"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ氅"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡶࡦࡴࠥ࠲࠯ࡅࠢࡷࡣ࡯ࡹࡪࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ氆"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll1llll_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ氇"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ氈"),html,re.DOTALL|re.I)
	if tmp: l1ll1llll1l1l_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ氉"),html,re.DOTALL|re.I)
	if tmp: l1lll11111l1l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭氊") in list(cookies.keys()): l1ll1lll1111l_l1_ = cookies[l11ll1_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ氋")]
	data = l1ll1llll1l1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ氌")+key+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ氍")+l1lll11111l1l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ氎")+l1ll1lll1llll_l1_+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ氏")+token+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ氐")+l1ll1lll1111l_l1_
	if request==l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ民") and l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ氒") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ氓"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ气"),html,re.DOTALL)
		l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ氕"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ氖") and l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ気") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ氘"),html,re.DOTALL)
		l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭氙"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭氚") not in html: l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ氛"),html)
	else: l1ll1ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭氜")
	#open(l11ll1_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳ࡰࡳࡰࡰࠪ氝"),l11ll1_l1_ (u"ࠧࡸࠩ氞")).write(str(l1ll1ll1l1ll1_l1_))
	#open(l11ll1_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬ氟"),l11ll1_l1_ (u"ࠩࡺࠫ氠")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ氡"),data)
	return html,l1ll1ll1l1ll1_l1_,data
def l1lll111111l1_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭氢"),l11ll1_l1_ (u"ࠬ࠱ࠧ氣"))
	l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲࡷࡨࡶࡾࡃࠧ氤")+search
	ITEMS(l111lll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ氥"),l11ll1_l1_ (u"ࠨ࠭ࠪ氦"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࠫ氧")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭氨") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡑࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ氩")
		elif l11ll1_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ氪") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭氫")
		elif l11ll1_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬ氬") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄ࡫ࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ氭")
		l11l111_l1_ = l111lll_l1_+l1ll1lll111ll_l1_
	else:
		l1ll1lll111l1_l1_,l1ll1ll1l11l1_l1_,l1lll1l11_l1_ = [],[],l11ll1_l1_ (u"ࠩࠪ氮")
		l1ll1ll1l1l11_l1_ = [l11ll1_l1_ (u"ࠪฬิ๎ๆࠡฬิฮ๏ฮࠧ氯"),l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮࠠๆั์ࠤฬ๊ีๅหࠪ氰"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡฬสี๏ิࠠศๆอั๊๐ไࠨ氱"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษࠢ฼ำิࠦวๅ็ืห์ีวหࠩ氲"),l11ll1_l1_ (u"ࠧหำอ๎อࠦอิสࠣห้ะโ๋์่ࠫ氳")]
		l1ll1lllll1l1_l1_ = [l11ll1_l1_ (u"ࠨࠩ水"),l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡃࠨ࠶࠺࠹ࡄࠨ氵"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡌࠩ࠷࠻࠳ࡅࠩ氶"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡑࠪ࠸࠵࠴ࡆࠪ氷"),l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡊࠫ࠲࠶࠵ࡇࠫ永")]
		l1ll1llllllll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊สาฬํฬࠬ氹"),l1ll1ll1l1l11_l1_)
		if l1ll1llllllll_l1_ == -1: return
		l1ll1lll11111_l1_ = l1ll1lllll1l1_l1_[l1ll1llllllll_l1_]
		html,c,data = l1ll1lll1l11l_l1_(l111lll_l1_+l1ll1lll11111_l1_)
		if c:
			d = c[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ氺")][l11ll1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ氻")][l11ll1_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ氼")][l11ll1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ氽")][l11ll1_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ氾")][l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭氿")][l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࡸ࠭汀")]
			for l1ll1ll1l111l_l1_ in range(len(d)):
				group = d[l1ll1ll1l111l_l1_][l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡍࡲࡰࡷࡳࡖࡪࡴࡤࡦࡴࡨࡶࠬ汁")][l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ求")]
				for l1lll111111ll_l1_ in range(len(group)):
					render = group[l1lll111111ll_l1_][l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩ汃")]
					if l11ll1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ汄") in list(render.keys()):
						l1lllll_l1_ = render[l11ll1_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ汅")][l11ll1_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ汆")][l11ll1_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ汇")][l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ汈")]
						l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡸ࠴࠵࠸࠶ࠨ汉"),l11ll1_l1_ (u"ࠩࠩࠫ汊"))
						title = render[l11ll1_l1_ (u"ࠪࡸࡴࡵ࡬ࡵ࡫ࡳࠫ汋")]
						title = title.replace(l11ll1_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦࠧ汌"),l11ll1_l1_ (u"ࠬ࠭汍"))
						if l11ll1_l1_ (u"࠭ลำษ็อࠥอไโๆอีࠬ汎") in title: continue
						if l11ll1_l1_ (u"ࠧใษษ้ฮࠦสี฼ํ่ࠬ汏") in title:
							title = l11ll1_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ汐")+title
							l1lll1l11_l1_ = title
							l1lllll111_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠬ汑") in title: continue
						title = title.replace(l11ll1_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠠࠨ汒"),l11ll1_l1_ (u"ࠫࠬ汓"))
						if l11ll1_l1_ (u"ࠬࡘࡥ࡮ࡱࡹࡩࠬ汔") in title: continue
						if l11ll1_l1_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ汕") in title:
							title = l11ll1_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ汖")+title
							l1lll1l11_l1_ = title
							l1lllll111_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠨࡕࡲࡶࡹࠦࡢࡺࠩ汗") in title: continue
						l1ll1lll111l1_l1_.append(escapeUNICODE(title))
						l1ll1ll1l11l1_l1_.append(l1lllll_l1_)
		if not l1lll1l11_l1_: l1ll1llll1lll_l1_ = l11ll1_l1_ (u"ࠩࠪ汘")
		else:
			l1ll1lll111l1_l1_ = [l11ll1_l1_ (u"ࠪฬิ๎ๆࠡใ็ฮึ࠭汙"),l1lll1l11_l1_]+l1ll1lll111l1_l1_
			l1ll1ll1l11l1_l1_ = [l11ll1_l1_ (u"ࠫࠬ汚"),l1lllll111_l1_]+l1ll1ll1l11l1_l1_
			l1lll1111111l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้็ไหำࠪ汛"),l1ll1lll111l1_l1_)
			if l1lll1111111l_l1_ == -1: return
			l1ll1llll1lll_l1_ = l1ll1ll1l11l1_l1_[l1lll1111111l_l1_]
		if l1ll1llll1lll_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1llll1lll_l1_
		elif l1ll1lll11111_l1_: l11l111_l1_ = l111lll_l1_+l1ll1lll11111_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡫࡯࡬ࡵࡧࡵ࠱ࡩࡸ࡯ࡱࡦࡲࡻࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡹ࡫࡭࠮ࡵࡨࡧࡹ࡯࡯࡯ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡪࡨࠣࠫࡗ࡫࡭ࡰࡸࡨࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷ࠭ࠬࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡳࡷࡺࠠࡣࡻࠪ࠰࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠬࠎࠎࠏࠉࠊ࡫ࡩࠤࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹࡥࡢࡴࡦ࡬࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠉࠊ࡫ࡩࠤ࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡳࡷࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠣࠤࠥ汜")
	ITEMS(l11l111_l1_)
	return
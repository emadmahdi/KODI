# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ䭎")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡐ࠸࡚ࡥࠧ䭏")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠩส๊ํอูࠡษไ่ฬ๋ࠧ䭐"),l11ll1_l1_ (u"ࠪะํีวหࠢสๅ้อๅࠨ䭑")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11111_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llll11_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭒"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䭓"),l11ll1_l1_ (u"࠭ࠧ䭔"),389,l11ll1_l1_ (u"ࠧࠨ䭕"),l11ll1_l1_ (u"ࠨࠩ䭖"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䭗"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䭘"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䭙"),l11ll1_l1_ (u"ࠬ࠭䭚"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭛"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䭜")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩ䭝"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠩࠪ䭞"),l11ll1_l1_ (u"ࠪࠫ䭟"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䭠"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭡"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭢")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯห๋ฮ๊สࠩ䭣"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠨࠩ䭤"),l11ll1_l1_ (u"ࠩࠪ䭥"),l11ll1_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ䭦"))
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䭧"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭䭨"),l11ll1_l1_ (u"࠭ࠧ䭩"),l11ll1_l1_ (u"ࠧࠨ䭪"),l11ll1_l1_ (u"ࠨࠩ䭫"),l11ll1_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䭬"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭭"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭮"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䭯")+l111l1_l1_+title,l11l1l_l1_,381,l11ll1_l1_ (u"࠭ࠧ䭰"),l11ll1_l1_ (u"ࠧࠨ䭱"),l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䭲")+str(seq))
	block = l11ll1_l1_ (u"ࠩࠪ䭳")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡨࡨࡴࡸࠢࠨ䭴"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶ࠭࠴ࠪࡀࠫࡤࡷ࡮ࡪࡥࠨ䭵"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭶"),block,re.DOTALL)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䭷"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䭸"),l11ll1_l1_ (u"ࠨࠩ䭹"),9999)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠩส่ศ฿ไุ๊่ࠢฬํฯสࠩ䭺"):
			if first:
				title = l11ll1_l1_ (u"ࠪห้อแๅษ่ࠤࠬ䭻")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠࠨ䭼")+title
		if title not in l1l11l_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭽"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭾")+l111l1_l1_+title,l1lllll_l1_,381)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䭿"),l11ll1_l1_ (u"ࠨࠩ䮀"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䮁"),url,l11ll1_l1_ (u"ࠪࠫ䮂"),l11ll1_l1_ (u"ࠫࠬ䮃"),l11ll1_l1_ (u"ࠬ࠭䮄"),l11ll1_l1_ (u"࠭ࠧ䮅"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䮆"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ䮇"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡦࡸࡣࡩ࠯ࡳࡥ࡬࡫ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭䮈"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䮉"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠫࡸ࡯ࡤࡦࡴࠪ䮊"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠩ䮋"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		z = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䮌"),block,re.DOTALL)
		l1llll_l1_,l1l11111l_l1_,l1lll111_l1_ = zip(*z)
		items = zip(l1l11111l_l1_,l1llll_l1_,l1lll111_l1_)
	elif type==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䮍"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡹ࡬ࡪࡦࡨࡶ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲ࡺࡶࡴࡪࡲࡻࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭䮎"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䮏"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䮐") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠫࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭䮑"),l11ll1_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡸࡺࡡࡳࡶࡁࠫ䮒"))
		html = html.replace(l11ll1_l1_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ䮓"),l11ll1_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䮔"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡸࡦࡸࡴ࠿ࠪ࠱࠮ࡄ࠯࠼ࡦࡰࡧࡂࠬ䮕"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==2: items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䮖"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࠫࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࡼࡴ࡫ࡧࡩࡧࡧࡲࠪࠩ䮗"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ䮘") in url:
				items = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䮙"),block,re.DOTALL)
			elif l11ll1_l1_ (u"࠭࠯ࡲࡷࡤࡰ࡮ࡺࡹ࠰ࠩ䮚") in url:
				items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䮛"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䮜"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࠨ䮝") in title:
			title = re.findall(l11ll1_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䮞"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ䮟")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䮠")+title
		l1lll1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂࠧ䮡"),title,re.DOTALL)
		if l1lll1l11_l1_: title = l1lll1l11_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ䮢") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䮣"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭䮤") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䮥"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ䮦") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䮧"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ䮨") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䮩"),l111l1_l1_+title,l1lllll_l1_,381,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䮪"),l111l1_l1_+title,l1lllll_l1_,382,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡓࡥ࡬࡫ࠠࠩ࠰࠭ࡃ࠮ࠦ࡯ࡧࠢࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䮫"),html,re.DOTALL)
	if l1l1l11_l1_:
		current = l1l1l11_l1_[0][0]
		last = l1l1l11_l1_[0][1]
		block = l1l1l11_l1_[0][2]
		items = re.findall(l11ll1_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ䮬"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title==l11ll1_l1_ (u"ࠫࠬ䮭") or title==last: continue
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䮮"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ䮯")+title,l1lllll_l1_,381,l11ll1_l1_ (u"ࠧࠨ䮰"),l11ll1_l1_ (u"ࠨࠩ䮱"),type)
		#if title==last:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ䮲")+title+l11ll1_l1_ (u"ࠪ࠳ࠬ䮳"),l11ll1_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䮴")+last+l11ll1_l1_ (u"ࠬ࠵ࠧ䮵"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䮶"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะิࠤฺ็อสࠢࠪ䮷")+last,l1lllll_l1_,381,l11ll1_l1_ (u"ࠨࠩ䮸"),l11ll1_l1_ (u"ࠩࠪ䮹"),type)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䮺"),url,l11ll1_l1_ (u"ࠫࠬ䮻"),l11ll1_l1_ (u"ࠬ࠭䮼"),l11ll1_l1_ (u"࠭ࠧ䮽"),l11ll1_l1_ (u"ࠧࠨ䮾"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䮿"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䯀"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,False):
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䯁"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅิๆึ่๊ࠥไไสสีࠥ๎วๅ็หี๊าࠠๆ่฼๋ࠬ䯂"),l11ll1_l1_ (u"ࠬ࠭䯃"),9999)
		return
	if l11ll1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䯄") in url or l11ll1_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ䯅") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪ࡭ࡹ࡫࡭ࠨࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭䯆"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[1]
			l1llll11_l1_(l111lll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠪࠫࡨࡲࡡࡴࡵࡀࠫࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠧࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡥࡸࡺࠢࠨࠩࠪ䯇"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡴࡵ࡮ࡧࡵࡥࡳࡪ࡯ࠨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ䯈"),block,re.DOTALL)
		for l1lll1_l1_,l1ll1l1_l1_,l1lllll_l1_,name in items:
			title = l1ll1l1_l1_+l11ll1_l1_ (u"ࠫࠥࡀࠠࠨ䯉")+name+l11ll1_l1_ (u"ࠬࠦวๅฯ็ๆฮ࠭䯊")
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䯋"),l111l1_l1_+title,l1lllll_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䯌"),url,l11ll1_l1_ (u"ࠨࠩ䯍"),l11ll1_l1_ (u"ࠩࠪ䯎"),l11ll1_l1_ (u"ࠪࠫ䯏"),l11ll1_l1_ (u"ࠫࠬ䯐"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䯑"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䯒"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠣࠤ࡬ࡨࡂ࠭ࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠨࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂ࠮ࠢࡴࡪࡨࡥࡩ࡫ࡲࠣࡾࠪࡴࡦ࡭࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩࠬࠦࠧࠨ䯓"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠣࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂ࠭ࡳࡦࡴࡹࡩࡷ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ䯔"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䯕")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䯖")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡭ࡰࡦࡤࡰࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯࠱ࡨࡲ࡯ࡴࡧࠥࠫ䯗"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡥ࡟ࡠࡦ࡯ࡣ࡬ࡪࡲࡪࡸࡨ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䯘"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䯙")+title+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䯚")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䯛"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䯜"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ䯝"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ䯞"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ䯟"),l11ll1_l1_ (u"࠭ࠫࠨ䯠"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䯡")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ䯢"))
	return
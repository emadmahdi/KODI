# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭妩")
headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ妪") : l11ll1_l1_ (u"ࠩࠪ妫") }
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ妬")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l11111_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llll11_l1_(url)
	elif mode==214: results = l1lllll1ll11l_l1_(url)
	elif mode==215: results = l1lllll1ll1l1_l1_(url)
	elif mode==218: results = l11ll1l1l1ll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11ll1l1l1ll_l1_():
	message = l11ll1_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ妭")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭妮"),l11ll1_l1_ (u"࠭ࠧ妯"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ妰"),l11ll1_l1_ (u"ࠨษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠧ妱"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妲"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ妳"),l11ll1_l1_ (u"ࠫࠬ妴"),219,l11ll1_l1_ (u"ࠬ࠭妵"),l11ll1_l1_ (u"࠭ࠧ妶"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ妷"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妸"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠧ妹"),l11ll1_l1_ (u"ࠪࠫ妺"),114,l11l1l_l1_)
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ妻")
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妼"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ妽")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่้๏ุษࠨ妾"),url,211)
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ妿"),headers,l11ll1_l1_ (u"ࠩࠪ姀"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ姁"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ姂"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ姃"),block,re.DOTALL)
	for l1lllll_l1_,title in items:#[1:-1]:
		url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ姄")+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ姅"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ姆")+l111l1_l1_+title,url,211)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ姇"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭姈"),block,re.DOTALL)
	l1l11l_l1_ = [l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ姉"),l11ll1_l1_ (u"ࠬอไาศํื๏ฯࠧ姊")]
	#l1111llll_l1_ = [l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ始"),l11ll1_l1_ (u"ࠧศใ็ห๊ࠦࠧ姌"),l11ll1_l1_ (u"ࠨสิห๊าࠧ姍"),l11ll1_l1_ (u"ࠩ฼ีํ฼ࠧ姎"),l11ll1_l1_ (u"ࠪ็้๐ศศฬࠪ姏"),l11ll1_l1_ (u"ࠫฬเว็๋ࠪ姐")]
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ姑"))
		if not any(value in title for value in l1l11l_l1_):
		#	if any(value in title for value in l1111llll_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姒"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ姓")+l111l1_l1_+title,l1lllll_l1_,211)
	return html
def l11111_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨࠩ委"),headers,l11ll1_l1_ (u"ࠩࠪ姕"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭姖"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ姗"),l11ll1_l1_ (u"ࠬ࠭姘"),url,html)
	if l11ll1_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ姙") in url or l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ姚") in url: block = html
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡏࡨࡨ࡮ࡧࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ姛"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: return
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ姜"),block,re.DOTALL)
	l11l_l1_ = []
	l111ll1ll_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ姝"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ姞"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫ姟"),l11ll1_l1_ (u"࠭ใๅ์หࠫ姠"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭姡"),l11ll1_l1_ (u"ࠨ้าหๆ࠭姢"),l11ll1_l1_ (u"่ࠩฬฬืวสࠩ姣"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧ姤"),l11ll1_l1_ (u"๊ࠫํัอษ้ࠫ姥"),l11ll1_l1_ (u"ࠬอไษ๊่ࠫ姦")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ姧") in l1lllll_l1_: continue
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ姨"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ姩"))
		if l11ll1_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ姪") in l1lllll_l1_ or any(value in title for value in l111ll1ll_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ姫"),l111l1_l1_+title,l1lllll_l1_,212,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ姬") in l1lllll_l1_ and l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ姭") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ姮"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭姯") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姰"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
					l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姱"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ姲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ姳"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠬอไึใะอࠥ࠭姴"),l11ll1_l1_ (u"࠭ࠧ姵"))
			if title!=l11ll1_l1_ (u"ࠧࠨ姶"): addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姷"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ姸")+title,l1lllll_l1_,211)
	return
def l1llll11_l1_(url):
	l111llll1_l1_,items,l1111ll1_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ姹"),headers,l11ll1_l1_ (u"ࠫࠬ姺"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ姻"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡴࡪ࠯࡯࡭ࡸࡺ࠭࡯ࡷࡰࡦࡪࡸࡥࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭姼"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1111l1_l1_ = l11ll1_l1_ (u"ࠧࠨ姽").join(l1l1l11_l1_)
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姾"),l1111l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ姿"))
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ娀"))
		title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ威") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ娂"))[-1].replace(l11ll1_l1_ (u"࠭࠭ࠨ娃"),l11ll1_l1_ (u"ࠧࠡࠩ娄"))
		l111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨษ็ั้่ษ࠮ࠪ࡟ࡨ࠰࠯ࠧ娅"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫ娆"))[-1],re.DOTALL)
		if l111l1l1_l1_: l111l1l1_l1_ = l111l1l1_l1_[0]
		else: l111l1l1_l1_ = l11ll1_l1_ (u"ࠪ࠴ࠬ娇")
		l1111ll1_l1_.append([l1lllll_l1_,title,l111l1l1_l1_])
	items = sorted(l1111ll1_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lll11_l1_ = str(items).count(l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭娈"))
	l111llll1_l1_ = str(items).count(l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ娉"))
	if l111lll11_l1_>1 and l111llll1_l1_>0 and l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ娊") not in url:
		for l1lllll_l1_,title,l111l1l1_l1_ in items:
			if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ娋") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ娌"),l111l1_l1_+title,l1lllll_l1_,213)
	else:
		for l1lllll_l1_,title,l111l1l1_l1_ in items:
			if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ娍") not in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ娎"),l111l1_l1_+title,l1lllll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l11ll1_l1_ (u"ࠫ࠴࠭娏"))
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭娐"),headers,l11ll1_l1_ (u"࠭ࠧ娑"),l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ娒"))
	# l11l1l1l1_l1_ l1l1_l1_
	if l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ娓") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ娔"))
		l11ll1l1_l1_ = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ娕"),headers,l11ll1_l1_ (u"ࠫࠬ娖"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭娗"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ娘"),l11ll1l1_l1_,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ娙"),block,re.DOTALL)
			if items:
				id = re.findall(l11ll1_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ娚"),l11ll1l1_l1_,re.DOTALL)
				if id:
					l11lll1l11_l1_ = id[0]
					for l1lllll_l1_,title in items:
						l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ娛")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ娜")+l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ娝")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭娞")
						l1llll_l1_.append(l1lllll_l1_)
			else:
				# https://l1lllll1ll1ll_l1_.tv/l11l1l1l1_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ娟"),block,re.DOTALL)
				for l1lllll_l1_,dummy in items:
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	if l11ll1_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ娠") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ娡"))
		l11ll1l1_l1_ = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ娢"),headers,l11ll1_l1_ (u"ࠪࠫ娣"),l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ娤"))
		id = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭娥"),l11ll1l1_l1_,re.DOTALL)
		if id:
			l11lll1l11_l1_ = id[0]
			l1l1ll111_l1_ = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ娦"):l11ll1_l1_ (u"ࠧࠨ娧") , l11ll1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ娨"):l11ll1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ娩") }
			l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭娪")+l11lll1l11_l1_
			l11ll1l1_l1_ = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ娫"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠬ࠭娬"),l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ娭"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪ࠶࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ娮"),l11ll1l1_l1_,re.DOTALL)
			if l1l1l11_l1_:
				for resolution,block in l1l1l11_l1_:
					items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭娯"),block,re.DOTALL)
					for name,l1lllll_l1_ in items:
						l1llll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ娰")+name+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ娱")+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ娲")+resolution)
			else:
				l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡨ࠷ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ娳"),l11ll1l1_l1_,re.DOTALL)
				if not l1l1l11_l1_: l1l1l11_l1_ = [l11ll1l1_l1_]
				for block in l1l1l11_l1_:
					l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡥࡳࡸࡨࡶࡸ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠎࠎࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࡜࠯࠴ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧศๆาๆฮࠦࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡲࡦࡳࡥࠢ࠿ࠪࠫ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨࠤ࠰ࠦࠧࠡโࠣࠫࠏࠏࠉࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࠪࠫࠏࠏࠉࠊࠋࠌࠦࠧࠨ娴")
					name = l11ll1_l1_ (u"ࠧࠨ娵")
					items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ娶"),block,re.DOTALL)
					for l1lllll_l1_ in items:
						server = l11ll1_l1_ (u"ࠩࠩࠪࠬ娷") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ娸"))[2].lower() + l11ll1_l1_ (u"ࠫࠫࠬࠧ娹")
						server = server.replace(l11ll1_l1_ (u"ࠬ࠴ࡣࡰ࡯ࠩࠪࠬ娺"),l11ll1_l1_ (u"࠭ࠧ娻")).replace(l11ll1_l1_ (u"ࠧ࠯ࡥࡲࠪࠫ࠭娼"),l11ll1_l1_ (u"ࠨࠩ娽"))
						server = server.replace(l11ll1_l1_ (u"ࠩ࠱ࡲࡪࡺࠦࠧࠩ娾"),l11ll1_l1_ (u"ࠪࠫ娿")).replace(l11ll1_l1_ (u"ࠫ࠳ࡵࡲࡨࠨࠩࠫ婀"),l11ll1_l1_ (u"ࠬ࠭婁"))
						server = server.replace(l11ll1_l1_ (u"࠭࠮࡭࡫ࡹࡩࠫࠬࠧ婂"),l11ll1_l1_ (u"ࠧࠨ婃")).replace(l11ll1_l1_ (u"ࠨ࠰ࡲࡲࡱ࡯࡮ࡦࠨࠩࠫ婄"),l11ll1_l1_ (u"ࠩࠪ婅"))
						server = server.replace(l11ll1_l1_ (u"ࠪࠪࠫ࡮ࡤ࠯ࠩ婆"),l11ll1_l1_ (u"ࠫࠬ婇")).replace(l11ll1_l1_ (u"ࠬࠬࠦࡸࡹࡺ࠲ࠬ婈"),l11ll1_l1_ (u"࠭ࠧ婉"))
						server = server.replace(l11ll1_l1_ (u"ࠧࠧࠨࠪ婊"),l11ll1_l1_ (u"ࠨࠩ婋"))
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ婌") + name + server + l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ婍")
						l1llll_l1_.append(l1lllll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ婎"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭婏"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ婐"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ婑"),l11ll1_l1_ (u"ࠨ࠭ࠪ婒"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭婓")+search
	l11111_l1_(url)
	return
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠤࡸ࡫ࡣࡰࡰࡧࡥࡷࡿࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣࡩࡧࡦ࡯ࡲࡧࡲ࡬࠯ࡥࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡥࡤࡸࡪ࡭࡯ࡳࡻࠬࠎࠎࠏࠉࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ࠲ࠠࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵ࠥࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭ࠫࡴࡧࡤࡶࡨ࡮ࠫࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ࠱ࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ婔")
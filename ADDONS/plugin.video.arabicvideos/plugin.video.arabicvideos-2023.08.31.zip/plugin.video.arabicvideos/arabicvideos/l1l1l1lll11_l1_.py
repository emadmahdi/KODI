# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ〴")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡍࡕࡆࡤ࠭〵")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ〶"):l11ll1_l1_ (u"ࠩࠪ〷")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l11111_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ〸"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ〹"),l11ll1_l1_ (u"ࠬ࠭〺"),329,l11ll1_l1_ (u"࠭ࠧ〻"),l11ll1_l1_ (u"ࠧࠨ〼"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ〽"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ〾"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ〿"),l11ll1_l1_ (u"ࠫࠬ぀"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩぁ"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪあ"),l11ll1_l1_ (u"ࠧࠨぃ"),headers,l11ll1_l1_ (u"ࠨࠩい"),l11ll1_l1_ (u"ࠩࠪぅ"),l11ll1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨう"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡩ࡯࡯ࡱ࠰ࡴࡱࡻࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬぇ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫえ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title==l11ll1_l1_ (u"࠭วๅ็ๆฮอฯࠠศๆ่ีห๐ษࠨぉ"): continue
		l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧお"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪか")+l111l1_l1_+title,l1lllll_l1_,321)
	return html
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪが"),l11ll1_l1_ (u"ࠪࠫき"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨぎ"),url,l11ll1_l1_ (u"ࠬ࠭く"),headers,l11ll1_l1_ (u"࠭ࠧぐ"),l11ll1_l1_ (u"ࠧࠨけ"),l11ll1_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨげ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡵࡴࡦࡴࠪこ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡶࡤ࠶ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ご"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫさ"),block,re.DOTALL)
	for l1lllll_l1_,l1lll1_l1_,count,title in items:
		count = count.replace(l11ll1_l1_ (u"ࠬ฿ฯะࠢࠪざ"),l11ll1_l1_ (u"࠭ࠧし")).replace(l11ll1_l1_ (u"ࠧࠡࠩじ"),l11ll1_l1_ (u"ࠨࠩす"))
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࠫず"),l11ll1_l1_ (u"ࠪࠫせ"))
		l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠦࠬࠨぜ"),l11ll1_l1_ (u"ࠬ࠭そ"))
		if l11ll1_l1_ (u"࠭࠮ࡱࡪࡳࠫぞ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪた")+l1lllll_l1_
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪだ")+l1lllll_l1_
		l1lll1_l1_ = l11l1l_l1_+l1lll1_l1_
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫち"))
		title = title+l11ll1_l1_ (u"ࠪࠤ࠭࠭ぢ")+count+l11ll1_l1_ (u"ࠫ࠮࠭っ")
		if l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨつ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭づ"),l111l1_l1_+title,l1lllll_l1_,321,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪて") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧで"),l111l1_l1_+title,l1lllll_l1_,322,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡵࡴࡦࡴࠪと"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩど"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨな")+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬに"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬぬ")+title,l1lllll_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫね"),url,l11ll1_l1_ (u"ࠨࠩの"),headers,l11ll1_l1_ (u"ࠩࠪは"),l11ll1_l1_ (u"ࠪࠫば"),l11ll1_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩぱ"))
	html = response.content
	#l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡡࡶࡦ࡬ࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬひ"),html,re.DOTALL)
	#if not l1lllll_l1_:
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭び"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]#+l11ll1_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ぴ")+l11lllll1_l1_()+l11ll1_l1_ (u"ࠨࠨࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡴࡳࡷࡨࠫふ")
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨぶ"))
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"้ࠪำะวาࠩぷ")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬへ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭べ"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨぺ"),l11ll1_l1_ (u"ࠧࠬࠩほ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩぼ")+search
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᨮ")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪᨯ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"่ࠬๆ้ษอࠤๆ฼วว์ฬࠫᨰ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l11111_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l1llll11_l1_(url,text)
	elif mode==474: results = l1l111_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᨱ"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨᨲ"),l11ll1_l1_ (u"ࠨࠩᨳ"),l11ll1_l1_ (u"ࠩࠪᨴ"),l11ll1_l1_ (u"ࠪࠫᨵ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᨶ"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᨷ"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"࠭࠯ࠨᨸ"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫᨹ"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᨺ"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᨻ"),l11ll1_l1_ (u"ࠪࠫᨼ"),479,l11ll1_l1_ (u"ࠫࠬᨽ"),l11ll1_l1_ (u"ࠬ࠭ᨾ"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᨿ"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩀ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᩁ"),l11ll1_l1_ (u"ࠩࠪᩂ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᩃ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᩄ")+l111l1_l1_+l11ll1_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪᩅ"),l1ll111_l1_,471,l11ll1_l1_ (u"࠭ࠧᩆ"),l11ll1_l1_ (u"ࠧࠨᩇ"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪᩈ"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᩉ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᩊ")+l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥๅ๋ิฬࠫᩋ"),l1ll111_l1_,471,l11ll1_l1_ (u"ࠬ࠭ᩌ"),l11ll1_l1_ (u"࠭ࠧᩍ"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᩎ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᩏ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᩐ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬᩑ"))
		#if title in l1l11l_l1_: continue
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡨࡧࡴ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳ࠲ࠩᩒ"),l11ll1_l1_ (u"ࠬࡩࡡࡵ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴࠩᩓ"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩔ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᩕ")+l111l1_l1_+title,l1lllll_l1_,474)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩖ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᩗ"),l11ll1_l1_ (u"ࠪࠫᩘ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᩙ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥᩚ"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_:
		block = block.replace(l111l_l1_,l11ll1_l1_ (u"࠭ࠧᩛ"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᩜ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		#l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࡃࠬᩝ")+category+l11ll1_l1_ (u"ࠩࡀࠫᩞ")+value
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᩟"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ᩠࠭")+l111l1_l1_+title,l1lllll_l1_,474)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᩡ"),url,l11ll1_l1_ (u"࠭ࠧᩢ"),l11ll1_l1_ (u"ࠧࠨᩣ"),l11ll1_l1_ (u"ࠨࠩᩤ"),l11ll1_l1_ (u"ࠩࠪᩥ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᩦ"))
	html = response.content
	if l11ll1_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫᩧ") in url: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠩᩨ"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᩩ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᩪ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࠨᩫ") in l1lllll_l1_:
				if l11ll1_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡪࡴࡧ࡭࡫ࡶ࡬࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᩬ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠶࠭ᩭ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃ࡭ࡪࡵࡦࠫᩮ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡵࡸ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫᩯ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"࠭ๅ็าࠣห้ฮฯศ์ฬࠫᩰ") in title and l11ll1_l1_ (u"ࠧࡥࡱࡀࡶࡦࡺࡩ࡯ࡩࠪᩱ") not in l1lllll_l1_: continue
			else: title = l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠษษึฮำีวๆ࠼ࠣࠤࠬᩲ")+title
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᩳ"),l111l1_l1_+title,l1lllll_l1_,471)
	else: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠪࠫᩴ")):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ᩵"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ᩶"),url,l11ll1_l1_ (u"࠭ࠧ᩷"),l11ll1_l1_ (u"ࠧࠨ᩸"),l11ll1_l1_ (u"ࠨࠩ᩹"),l11ll1_l1_ (u"ࠩࠪ᩺"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ᩻"))
	html = response.content
	items = []
	if request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭᩼"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯ࡩࡰࡺ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᩽"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᩾"),block,re.DOTALL)
		l1l1_l1_,l11lll_l1_,l1ll1ll111_l1_ = zip(*items)
		items = zip(l1ll1ll111_l1_,l1l1_l1_,l11lll_l1_)
	elif request==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴ᩿ࠩ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ᪀"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧ᪁"),block,re.DOTALL)
		l1l1_l1_,l11lll_l1_,l1ll1ll111_l1_ = zip(*items)
		items = zip(l1ll1ll111_l1_,l1l1_l1_,l11lll_l1_)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᪂"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫ᪃"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲࡭ࡲࡪࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᪄"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᪅"),html,re.DOTALL)
		if not l1l1l11_l1_: return
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᪆"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᪇"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩ᪈"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ᪉"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪ᪊"),l11ll1_l1_ (u"้ࠬไ๋สࠪ᪋"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ᪌"),l11ll1_l1_ (u"่ࠧัสๅࠬ᪍"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ᪎"),l11ll1_l1_ (u"ࠩ฼ี฻࠭᪏"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ᪐"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ᪑"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬ᪒")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"࠭࠯ࠨ᪓"))
		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ᪔") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ᪕")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ᪖"))
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ᪗") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭᪘")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ᪙"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ᪚"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ᪛"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᪜"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠩส่า๊โสࠩ᪝") in title:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ᪞") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪟"),l111l1_l1_+title,l1lllll_l1_,473,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ᪠") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪡"),l111l1_l1_+title,l1lllll_l1_,471,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪢"),l111l1_l1_+title,l1lllll_l1_,473,l1lll1_l1_)
	if request not in [l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ᪣"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ᪤")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᪥"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᪦"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧᪧ"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ᪨")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ᪩"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪪"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ᪫")+title,l1lllll_l1_,471)
		l1llll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷ࡭ࡵࡷ࡮ࡱࡵࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᪬"),html,re.DOTALL)
		if l1llll1l1l_l1_:
			l1lllll_l1_ = l1llll1l1l_l1_[0]
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪭"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬิศ้าอࠥอไๆิํำࠬ᪮"),l1lllll_l1_,471)
	return
def l1llll11_l1_(url,l1l1l_l1_):
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ᪯"),l11ll1_l1_ (u"ࠧ࠲࠳࠴࠵ࠥࠦࠧ᪰")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ᪱"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭᪲"),url,l11ll1_l1_ (u"ࠪࠫ᪳"),l11ll1_l1_ (u"ࠫࠬ᪴"),l11ll1_l1_ (u"᪵ࠬ࠭"),l11ll1_l1_ (u"᪶࠭ࠧ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥ᪷ࠩ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ᪸ࠫ"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨ᪹ࠧ")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᪺"),html,re.DOTALL)
	items = []
	# l1lll1l_l1_
	if l1l11l1_l1_ and not l1l1l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᪻"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺ࡜࠭ࠢ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ᪼"),block,re.DOTALL)
		for l1l1l_l1_,title in items: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᪽࠭"),l111l1_l1_+title,url,473,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ᪾"),l1l1l_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		#l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣᪿࠩ"))
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀᫀࠫࠥࠫ"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠥࡸ࡮ࡺ࡬ࡦ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠣ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࠤ᫁"),block,re.DOTALL)
		if items:
			for title,l1lllll_l1_ in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭᫂")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵᫃ࠧ"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳ᫄ࠬ"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ᫅"),block,re.DOTALL)
			for l1lllll_l1_,title,l1lll1_l1_ in items:
				if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭᫆") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ᫇")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ᫈"))
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᫉"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
	if l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨ᫊ࠧ") in html:
		if items: addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᫋"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᫌ"),l11ll1_l1_ (u"ࠨࠩᫍ"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᫎ"),l111l1_l1_+l11ll1_l1_ (u"้ࠪํอึ๋฻ࠣิฬะࠠึๆฬࠫ᫏"),url,471)
	#else: l11111_l1_(url)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ᫐"))
	l1llll_l1_ = []
	# l1ll1l1lll_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ᫑"),url,l11ll1_l1_ (u"࠭ࠧ᫒"),l11ll1_l1_ (u"ࠧࠨ᫓"),l11ll1_l1_ (u"ࠨࠩ᫔"),l11ll1_l1_ (u"ࠩࠪ᫕"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ᫖"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪ࡬࠿ࠩ᫗"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᫘"),block,re.DOTALL)
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,True): return
	# default l11l1l1l1_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᫙"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨ᫚")
		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭᫛") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᫜")+l1lllll_l1_
		l1llll_l1_.append(l1lllll_l1_)
	# l1l111l11_l1_ l11l1l1l1_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡖࡑࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᫝"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ᫞")
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᫟") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ᫠")+l1lllll_l1_
		l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ᫡"),l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫ᫢"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭᫣"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ᫤"),l11ll1_l1_ (u"ࠫࠬ᫥"),l11ll1_l1_ (u"ࠬ࠭᫦"),l11ll1_l1_ (u"࠭ࠧ᫧"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ᫨"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᫩"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨ᫪"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᫫")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ᫬")
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᫭") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ᫮")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ᫯"),l11ll1_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵ࡮ࡰࠨ᫰"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭᫱"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ᫲"),l11ll1_l1_ (u"ࠫࠬ᫳"),l11ll1_l1_ (u"ࠬ࠭᫴"),l11ll1_l1_ (u"࠭ࠧ᫵"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ᫶"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᫷"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ᫸"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᫹")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ᫺")
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᫻") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ᫼")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ᫽"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᫾"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ᫿"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫᬀ"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭ᬁ"),l11ll1_l1_ (u"ࠬ࠱ࠧᬂ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧᬃ")+search
	l11111_l1_(url)
	return
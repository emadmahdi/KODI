# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨ⭙")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡌࡒࡓࡠࠩ⭚")
def MAIN(mode,url,text,l1l1111_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll11l11l1_l1_(text)
	elif mode==542: results = l1ll1111ll1_l1_(text,url,l1l1111_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭛"),l11ll1_l1_ (u"ࠬฮอฬࠢฯำ๏ีࠧ⭜"),l11ll1_l1_ (u"࠭ࠧ⭝"),549)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⭞"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๆะี๊ฮࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⭟"),l11ll1_l1_ (u"ࠩࠪ⭠"),9999)
	l1ll111ll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⭡"),l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⭢"))
	if l1ll111ll1l_l1_:
		l1ll111ll1l_l1_ = l1ll111ll1l_l1_[l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭⭣")]
		for search in reversed(l1ll111ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭤"),search,l11ll1_l1_ (u"ࠧࠨ⭥"),549,l11ll1_l1_ (u"ࠨࠩ⭦"),l11ll1_l1_ (u"ࠩࠪ⭧"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll1l11l1_l1_ = search.replace(l111l1_l1_,l11ll1_l1_ (u"ࠪࠫ⭨"))
	l1l1llllll1_l1_(l1lll1l11l1_l1_)
	#l1l1llll11l_l1_ = search+options+l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⭩")
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭪"),l11ll1_l1_ (u"ู࠭ๆๆࠣฬาัࠠอ็ส฽๏ࠦ࠭ࠡࠩ⭫")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⭬"),542,l11ll1_l1_ (u"ࠨࠩ⭭"),l11ll1_l1_ (u"ࠩࠪ⭮"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⭯"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭰"),l11ll1_l1_ (u"ࠬ࠭⭱"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭲"),l11ll1_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥแึๆฬࠤ࠲ࠦࠧ⭳")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⭴"),542,l11ll1_l1_ (u"ࠩࠪ⭵"),l11ll1_l1_ (u"ࠪࠫ⭶"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭷"),l11ll1_l1_ (u"ࠬ์สศศฯࠤฬ๊ศฮอ้ࠣ็ูๅสࠢ࠰ࠤࠬ⭸")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ⭹"),542,l11ll1_l1_ (u"ࠧࠨ⭺"),l11ll1_l1_ (u"ࠨࠩ⭻"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭼"),l11ll1_l1_ (u"ࠪฬาัࠠๆ่ไีิࠦ࠭ࠡࠩ⭽")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬ⭾"),541,l11ll1_l1_ (u"ࠬ࠭⭿"),l11ll1_l1_ (u"࠭ࠧ⮀"),l1lll1l11l1_l1_)
	return
def l1l1llllll1_l1_(l1ll11l1lll_l1_):
	l1ll11ll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⮁"),l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮂"),l1ll11l1lll_l1_)
	l1ll11ll111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮃"),l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮄"),l111l1_l1_+l1ll11l1lll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮅"),l1ll11l1lll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮆"),l111l1_l1_+l1ll11l1lll_l1_)
	old_value = l1ll11ll11l_l1_+l1ll11ll111_l1_
	if old_value: l1ll11l1lll_l1_ = l111l1_l1_+l1ll11l1lll_l1_
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮇"),l1ll11l1lll_l1_,old_value,VERYLONG_CACHE)
	return
def l1ll11111l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ⮈"),l11ll1_l1_ (u"ࠨࠩ⮉"),l11ll1_l1_ (u"ࠩࠪ⮊"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⮋"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ⮌"))
	if l1ll111ll1_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮍"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⮎"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭⮏"))
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⮐"),l11ll1_l1_ (u"ࠩࠪ⮑"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⮒"),l11ll1_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ⮓"))
	return
def l1ll1111ll1_l1_(l1ll11111ll_l1_,action,l1ll111l111_l1_=l11ll1_l1_ (u"ࠬ࠭⮔")):
	l1ll111l11l_l1_,l1ll111l1l1_l1_,l1ll111llll_l1_,l1l1lll1lll_l1_,l1l1llll1l1_l1_,l1ll111lll1_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⮕"):
		if action==l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮖"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮗"),l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮘"),l111l1_l1_+l1ll11111ll_l1_)
		elif action==l11ll1_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮙"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮚"),l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫ⮛"),l1ll11111ll_l1_)
		elif action==l11ll1_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬ⮜"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⮝"),l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⮞"),(l1ll111l111_l1_,l1ll11111ll_l1_))
	if not l1ll111llll_l1_:
		l1ll11l11ll_l1_ = l11ll1_l1_ (u"๊ࠩิฬࠦวๅสะฯࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮࡝ࡰࠪ⮟")
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็ࠢส่อำหࠡใํࠤัฺ๋๊ࠢส่๊๎วใ฻ࠣ฽๋ࠦ࡜࡯ࠢࠥ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦࠧ⮠")+l1ll11111ll_l1_+l11ll1_l1_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࠡ࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่อำหࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯ࠭⮡")
		if action==l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫ⮢"): message = l1ll11l1l11_l1_
		else: message = l1ll11l11ll_l1_+l1ll11l1l11_l1_
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ⮣"),l11ll1_l1_ (u"ࠧࠨ⮤"),l11ll1_l1_ (u"ࠨࠩ⮥"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⮦"),message)
		if l1ll111ll1_l1_!=1: return
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⮧"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ⮨")+l1ll11111ll_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ⮩"))
		#global menuItemsLIST
		import threading
		#l1ll111ll11_l1_ = [l11ll1_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ⮪"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ⮫"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ⮬")]
		l1ll11llll1_l1_ = 1
		for l1ll111l111_l1_ in l1ll111ll11_l1_:
			l1l1lll1lll_l1_[l1ll111l111_l1_] = []
			options = l11ll1_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⮭")
			if l11ll1_l1_ (u"ࠪ࠱ࠬ⮮") in l1ll111l111_l1_: options = options+l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⮯")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠬࡥࠧ⮰")
			l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
			if l1ll11llll1_l1_:
				threads[l1ll111l111_l1_] = threading.Thread(target=l1ll1111lll_l1_,args=(l1ll11111ll_l1_+options,))
				threads[l1ll111l111_l1_].start()
			else: l1ll1111lll_l1_(l1ll11111ll_l1_+options)
			l1llllll_l1_(TRANSLATE(l1ll111l111_l1_),l11ll1_l1_ (u"࠭ࠧ⮱"),time=1000)
		if l1ll11llll1_l1_:
			time.sleep(2)
			for l1ll111l111_l1_ in l1ll111ll11_l1_:
				threads[l1ll111l111_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⮲"),l11ll1_l1_ (u"ࠨࠩ⮳"),l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠡࡨࡲࡹࡳࡪࡥࡥ࠼ࠪ⮴"),str(len(menuItemsLIST)))
		for l1ll111l111_l1_ in l1ll111ll11_l1_:
			l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
			for l1ll1111l1l_l1_ in menuItemsLIST:
				type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
				if l1ll11lll1l_l1_ in name:
					if l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࠩ⮵") in l1ll111l111_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⮶")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⮷")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⮸")]: continue
						if l11ll1_l1_ (u"ࠧึใะอࠬ⮹") not in name:
							if   type==l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⮺"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⮻")
							elif type==l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⮼"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⮽")
							elif type==l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮾"): l1ll111l111_l1_ = l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⮿")
						else:
							if   l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ⯀") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⯁")
							elif l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ⯂") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⯃")
							elif l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ⯄") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ⯅")
					elif l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࠫ⯆") in l1ll111l111_l1_ and 729>=mode>=710:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⯇")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⯈")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⯉")]: continue
						if l11ll1_l1_ (u"ูࠪๆำษࠨ⯊") not in name:
							if   type==l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⯋"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ⯌")
							elif type==l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⯍"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ⯎")
							elif type==l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯏"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⯐")
						else:
							if   l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ⯑") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭⯒")
							elif l11ll1_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ⯓") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⯔")
							elif l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ⯕") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ⯖")
					elif l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࠫ⯗") in l1ll111l111_l1_ and 149>=mode>=140:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯘")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯙")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯚")]: continue
						if l11ll1_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⯛") in name or l11ll1_l1_ (u"ࠧ࠻࠼ࠣࠫ⯜") in name:
							continue
							#if   l111_l1_==l11ll1_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯝"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯞")
							#elif l111_l1_==l11ll1_l1_ (u"ࠪࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭⯟"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯠")
							#else: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯡")
						else:
							if   mode==144 and l11ll1_l1_ (u"࠭ࡕࡔࡇࡕࠫ⯢") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯣")
							elif mode==144 and l11ll1_l1_ (u"ࠨࡅࡋࡒࡑ࠭⯤") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯥")
							elif mode==144 and l11ll1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ⯦") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯧")
							elif mode==143: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯨")
							else: continue
					elif l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࠬ⯩") in l1ll111l111_l1_ and 419>=mode>=400:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯪")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯫")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯬")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ⯭")]: continue
						if   mode in [401,405]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯮")
						elif mode in [402,406]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯯")
						elif mode in [403,404]: l1ll111l111_l1_ = l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ⯰")
						elif mode in [412,413]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ⯱")
					elif l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࠨ⯲") in l1ll111l111_l1_ and 39>=mode>=30:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ⯳")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯴")]: continue
						if   mode in [32,39]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⯵")
						elif mode in [33,39]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⯶")
					elif l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࠭⯷") in l1ll111l111_l1_ and 29>=mode>=20:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⯸")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⯹")]: continue
						if   l11ll1_l1_ (u"ࠩ࠲ࡥࡷ࠴ࠧ⯺") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⯻")
						elif l11ll1_l1_ (u"ࠫ࠴࡫࡮࠯ࠩ⯼") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⯽")
					#elif l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࠪ⯾") in l1ll111l111_l1_ and 319>=mode>=310:
					#	if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l1ll111l111_l1_]: continue
					#	if mode==312: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"ࠧ࠮ࡃࡘࡈࡎࡕࡓࠨ⯿")
					#	elif l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࠳ࠧⰀ") in url: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"ࠩ࠰ࡅࡑࡈࡕࡎࡕࠪⰁ")
					#	else: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"ࠪ࠱ࡕࡋࡒࡔࡑࡑࡗࠬⰂ")
					l1l1lll1lll_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
		menuItemsLIST[:] = []
		for l1ll111l111_l1_ in list(l1l1lll1lll_l1_.keys()):
			l1l1llll1l1_l1_[l1ll111l111_l1_] = []
			l1ll111lll1_l1_[l1ll111l111_l1_] = []
			for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ in l1l1lll1lll_l1_[l1ll111l111_l1_]:
				l1ll1111l1l_l1_ = (type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_)
				if l11ll1_l1_ (u"ฺࠫ็อสࠩⰃ") in name and type==l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰄ"): l1ll111lll1_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
				else: l1l1llll1l1_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
		l1ll11l111l_l1_ = [(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰅ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰆ"),l11ll1_l1_ (u"ࠨࠩⰇ"),157,l11ll1_l1_ (u"ࠩࠪⰈ"),l11ll1_l1_ (u"ࠪࠫⰉ"),l11ll1_l1_ (u"ࠫࠬⰊ"),l11ll1_l1_ (u"ࠬ࠭Ⰻ"),l11ll1_l1_ (u"࠭ࠧⰌ"))]
		for l1ll111l111_l1_ in l1ll111l1ll_l1_:
			if l1ll111l111_l1_==l1ll111111l_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰍ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰎ"),l11ll1_l1_ (u"ࠩࠪⰏ"),157,l11ll1_l1_ (u"ࠪࠫⰐ"),l11ll1_l1_ (u"ࠫࠬⰑ"),l11ll1_l1_ (u"ࠬ࠭Ⱂ"),l11ll1_l1_ (u"࠭ࠧⰓ"),l11ll1_l1_ (u"ࠧࠨⰔ"))]
			elif l1ll111l111_l1_==l1ll11ll1l1_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⱅ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰖ"),l11ll1_l1_ (u"ࠪࠫⰗ"),157,l11ll1_l1_ (u"ࠫࠬⰘ"),l11ll1_l1_ (u"ࠬ࠭Ⱉ"),l11ll1_l1_ (u"࠭ࠧⰚ"),l11ll1_l1_ (u"ࠧࠨⰛ"),l11ll1_l1_ (u"ࠨࠩⰜ"))]
			elif l1ll111l111_l1_==l1l1llll111_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰝ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⱎ"),l11ll1_l1_ (u"ࠫࠬⰟ"),157,l11ll1_l1_ (u"ࠬ࠭Ⱐ"),l11ll1_l1_ (u"࠭ࠧⰡ"),l11ll1_l1_ (u"ࠧࠨⰢ"),l11ll1_l1_ (u"ࠨࠩⰣ"),l11ll1_l1_ (u"ࠩࠪⰤ"))]
			if l1ll111l111_l1_ not in l1l1llll1l1_l1_.keys(): continue
			if l1l1llll1l1_l1_[l1ll111l111_l1_]:
				l1l1lllll1l_l1_ = TRANSLATE(l1ll111l111_l1_)
				l1ll1111l11_l1_ = [(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰥ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭Ⱖ")+l1l1lllll1l_l1_+l11ll1_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⱗ"),l11ll1_l1_ (u"࠭ࠧⰨ"),9999,l11ll1_l1_ (u"ࠧࠨⰩ"),l11ll1_l1_ (u"ࠨࠩⰪ"),l11ll1_l1_ (u"ࠩࠪⰫ"),l11ll1_l1_ (u"ࠪࠫⰬ"),l11ll1_l1_ (u"ࠫࠬⰭ"))]
				if 0:
					l1ll11ll1ll_l1_ = l1ll11111ll_l1_+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩⰮ")+l11ll1_l1_ (u"࠭ศฮอࠪⰯ")+l11ll1_l1_ (u"ࠧࠡࠩⰰ")+l1l1lllll1l_l1_
				else:
					l1ll11ll1ll_l1_ = l11ll1_l1_ (u"ࠨสะฯࠬⰱ")+l11ll1_l1_ (u"ࠩࠣࠫⰲ")+l1l1lllll1l_l1_+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧⰳ")+l1ll11111ll_l1_
				if len(l1l1llll1l1_l1_[l1ll111l111_l1_])<8: l1ll11l1111_l1_ = []
				else:
					l1ll11lll11_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧⰴ")+l1ll11ll1ll_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰵ")
					l1ll11l1111_l1_ = [(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰶ"),l111l1_l1_+l1ll11lll11_l1_,l11ll1_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⰷ"),542,l11ll1_l1_ (u"ࠨࠩⰸ"),l1ll111l111_l1_,l1ll11111ll_l1_,l11ll1_l1_ (u"ࠩࠪⰹ"),l11ll1_l1_ (u"ࠪࠫⰺ"))]
				l1ll11l1l1l_l1_ = l1l1llll1l1_l1_[l1ll111l111_l1_]+l1ll111lll1_l1_[l1ll111l111_l1_]
				l1ll111l1l1_l1_ += l1ll11l111l_l1_+l1ll1111l11_l1_+l1ll11l1l1l_l1_[:7]+l1ll11l1111_l1_
				l1l1lllll11_l1_ = [(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰻ"),l111l1_l1_+l1ll11ll1ll_l1_,l11ll1_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⰼ"),542,l11ll1_l1_ (u"࠭ࠧⰽ"),l1ll111l111_l1_,l1ll11111ll_l1_,l11ll1_l1_ (u"ࠧࠨⰾ"),l11ll1_l1_ (u"ࠨࠩⰿ"))]
				l1ll111l11l_l1_ += l1ll11l111l_l1_+l1l1lllll11_l1_
				l1ll11l111l_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⱀ"),(l1ll111l111_l1_,l1ll11111ll_l1_),l1ll11l1l1l_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩⱁ"),l1ll11111ll_l1_,l1ll111l1l1_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩⱂ"),l1ll11111ll_l1_)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱃ"),l111l1_l1_+l1ll11111ll_l1_,l1ll111l11l_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧⱄ"),l11ll1_l1_ (u"ࠧࠨⱅ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⱆ"),l11ll1_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬⱇ"))
		if action==l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⱈ") and l1ll111l11l_l1_: l1ll111llll_l1_ = l1ll111l11l_l1_
		else: l1ll111llll_l1_ = l1ll111l1l1_l1_
	if action!=l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪⱉ"):
		for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ in l1ll111llll_l1_:
			if action in [l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⱊ"),l11ll1_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬⱋ")] and l11ll1_l1_ (u"ࠧึใะอࠬⱌ") in name and type==l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱍ"): continue
			addMenuItem(type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_)
	return
def l1ll11l11l1_l1_(l1ll11111ll_l1_=l11ll1_l1_ (u"ࠩࠪⱎ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪⱏ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨⱐ")+search+l11ll1_l1_ (u"ࠬࠦ࡝ࠨⱑ"))
	l1111ll_l1_ = search+options
	if 0:
		l1ll11l1ll1_l1_,l1lll1l11l1_l1_ = search+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪⱒ"),l11ll1_l1_ (u"ࠧࠨⱓ")
	else:
		l1ll11l1ll1_l1_,l1lll1l11l1_l1_ = l11ll1_l1_ (u"ࠨࠩⱔ"),l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ⱕ")+search
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱖ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱗ"),l11ll1_l1_ (u"ࠬ࠭ⱘ"),157)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱙ"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭ⱚ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥࡓ࠳ࡖࠩⱛ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⱜ"),719,l11ll1_l1_ (u"ࠪࠫⱝ"),l11ll1_l1_ (u"ࠫࠬⱞ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱟ"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬⱠ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤࡎࡖࡔࡗࠩⱡ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⱢ"),239,l11ll1_l1_ (u"ࠩࠪⱣ"),l11ll1_l1_ (u"ࠪࠫⱤ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱥ"),l11ll1_l1_ (u"ࠬࡥࡂࡌࡔࡢࠫⱦ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสๆีฬ࠭Ⱨ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⱨ"),379,l11ll1_l1_ (u"ࠨࠩⱩ"),l11ll1_l1_ (u"ࠩࠪⱪ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱫ"),l11ll1_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪⱬ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯ࠭Ɑ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⱮ"),39,l11ll1_l1_ (u"ࠧࠨⱯ"),l11ll1_l1_ (u"ࠨࠩⱰ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱱ"),l11ll1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩⱲ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫⱳ"),l11ll1_l1_ (u"ࠬ࠭ⱴ"),39,l11ll1_l1_ (u"࠭ࠧⱵ"),l11ll1_l1_ (u"ࠧࠨⱶ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࡤ࠭ⱷ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱸ"),l11ll1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩⱹ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ⱺ"),l11ll1_l1_ (u"ࠬ࠭ⱻ"),39,l11ll1_l1_ (u"࠭ࠧⱼ"),l11ll1_l1_ (u"ࠧࠨⱽ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭Ȿ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱿ"),l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⲀ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨⲁ"),l11ll1_l1_ (u"ࠬ࠭Ⲃ"),149,l11ll1_l1_ (u"࠭ࠧⲃ"),l11ll1_l1_ (u"ࠧࠨⲄ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨⲅ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲆ"),l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⲇ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬⲈ"),l11ll1_l1_ (u"ࠬ࠭ⲉ"),149,l11ll1_l1_ (u"࠭ࠧⲊ"),l11ll1_l1_ (u"ࠧࠨⲋ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫⲌ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲍ"),l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⲎ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬⲏ"),l11ll1_l1_ (u"ࠬ࠭Ⲑ"),149,l11ll1_l1_ (u"࠭ࠧⲑ"),l11ll1_l1_ (u"ࠧࠨⲒ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪⲓ"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲔ"),l11ll1_l1_ (u"ࠪࡣࡐࡒࡁࡠࠩⲕ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨⲖ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⲗ"),19,l11ll1_l1_ (u"࠭ࠧⲘ"),l11ll1_l1_ (u"ࠧࠨⲙ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲚ"),l11ll1_l1_ (u"ࠩࡢࡅࡗ࡚࡟ࠨⲛ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩⲜ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⲝ"),739,l11ll1_l1_ (u"ࠬ࠭Ⲟ"),l11ll1_l1_ (u"࠭ࠧⲟ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲠ"),l11ll1_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧⲡ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩⲢ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⲣ"),329,l11ll1_l1_ (u"ࠫࠬⲤ"),l11ll1_l1_ (u"ࠬ࠭ⲥ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲧ"),l11ll1_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭ⲧ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧⲨ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⲩ"),579,l11ll1_l1_ (u"ࠪࠫⲪ"),l11ll1_l1_ (u"ࠫࠬⲫ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲬ"),l11ll1_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬⲭ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠬⲮ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⲯ"),129,l11ll1_l1_ (u"ࠩࠪⲰ"),l11ll1_l1_ (u"ࠪࠫⲱ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲲ"),l11ll1_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⲳ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭Ⲵ"),l11ll1_l1_ (u"ࠧࠨⲵ"),409,l11ll1_l1_ (u"ࠨࠩⲶ"),l11ll1_l1_ (u"ࠩࠪⲷ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘࡥࠧⲸ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲹ"),l11ll1_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⲺ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪⲻ"),l11ll1_l1_ (u"ࠧࠨⲼ"),409,l11ll1_l1_ (u"ࠨࠩⲽ"),l11ll1_l1_ (u"ࠩࠪⲾ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪⲿ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳀ"),l11ll1_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⳁ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪⳂ"),l11ll1_l1_ (u"ࠧࠨⳃ"),409,l11ll1_l1_ (u"ࠨࠩⳄ"),l11ll1_l1_ (u"ࠩࠪⳅ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩⳆ"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳇ"),l11ll1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳈ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩⳉ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪⳊ"),l11ll1_l1_ (u"ࠨࠩⳋ"),29,l11ll1_l1_ (u"ࠩࠪⳌ"),l11ll1_l1_ (u"ࠪࠫⳍ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳎ"),l11ll1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳏ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬⳐ"),l11ll1_l1_ (u"ࠧࠨⳑ"),29,l11ll1_l1_ (u"ࠨࠩⳒ"),l11ll1_l1_ (u"ࠩࠪⳓ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉ࡟ࠨⳔ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳕ"),l11ll1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳖ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨⳗ"),l11ll1_l1_ (u"ࠧࠨⳘ"),29,l11ll1_l1_ (u"ࠨࠩⳙ"),l11ll1_l1_ (u"ࠩࠪⳚ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࡠࠩⳛ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳜ"),l11ll1_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫⳝ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧⳞ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⳟ"),79,l11ll1_l1_ (u"ࠨࠩⳠ"),l11ll1_l1_ (u"ࠩࠪⳡ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳢ"),l11ll1_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪⳣ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ⳤ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ⳥"),249,l11ll1_l1_ (u"ࠧࠨ⳦"),l11ll1_l1_ (u"ࠨࠩ⳧"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳨"),l11ll1_l1_ (u"ࠪࡣࡒࡘࡆࠨ⳩")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬ⳪"),l11ll1_l1_ (u"ࠬ࠭Ⳬ"),49,l11ll1_l1_ (u"࠭ࠧⳬ"),l11ll1_l1_ (u"ࠧࠨⳭ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳮ"),l11ll1_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ⳯")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧ⳰")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬ⳱"),59,l11ll1_l1_ (u"ࠬ࠭Ⳳ"),l11ll1_l1_ (u"࠭ࠧⳳ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳴"),l11ll1_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧ⳵")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ⳶")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫ⳷"),69,l11ll1_l1_ (u"ࠫࠬ⳸"),l11ll1_l1_ (u"ࠬ࠭⳹"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳺"),l11ll1_l1_ (u"ࠧࡠࡍ࡚ࡘࡤ࠭⳻")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็็ํััࠨ⳼"),l11ll1_l1_ (u"ࠩࠪ⳽"),139,l11ll1_l1_ (u"ࠪࠫ⳾"),l11ll1_l1_ (u"ࠫࠬ⳿"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴀ"),l11ll1_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬⴁ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭ⴂ"),l11ll1_l1_ (u"ࠨࠩⴃ"),319,l11ll1_l1_ (u"ࠩࠪⴄ"),l11ll1_l1_ (u"ࠪࠫⴅ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴆ"),l11ll1_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫⴇ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪⴈ"),l11ll1_l1_ (u"ࠧࠨⴉ"),319,l11ll1_l1_ (u"ࠨࠩⴊ"),l11ll1_l1_ (u"ࠩࠪⴋ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࡤ࠭ⴌ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴍ"),l11ll1_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫⴎ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ๋ࠥฬๅัࠪⴏ"),l11ll1_l1_ (u"ࠧࠨⴐ"),319,l11ll1_l1_ (u"ࠨࠩⴑ"),l11ll1_l1_ (u"ࠩࠪⴒ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬⴓ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴔ"),l11ll1_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫⴕ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬⴖ"),l11ll1_l1_ (u"ࠧࠨⴗ"),319,l11ll1_l1_ (u"ࠨࠩⴘ"),l11ll1_l1_ (u"ࠩࠪⴙ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬⴚ"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⴛ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⴜ"),l11ll1_l1_ (u"࠭ࠧⴝ"),157)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴞ"),l11ll1_l1_ (u"ࠨࡡࡎࡘࡐࡥࠧⴟ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠪⴠ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⴡ"),679,l11ll1_l1_ (u"ࠫࠬⴢ"),l11ll1_l1_ (u"ࠬ࠭ⴣ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴤ"),l11ll1_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭ⴥ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨࠢหัะࠦๅ้ไ฼ࠤๆาัࠡึ๋ࠫ⴦")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠩࠣࠫⴧ"),l11ll1_l1_ (u"ࠪࠫ⴨"),399,l11ll1_l1_ (u"ࠫࠬ⴩"),l11ll1_l1_ (u"ࠬ࠭⴪"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⴫"),l11ll1_l1_ (u"ࠧࡠࡖ࡙ࡊࡤ࠭⴬")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬⴭ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪ⴮"),469,l11ll1_l1_ (u"ࠪࠫ⴯"),l11ll1_l1_ (u"ࠫࠬⴰ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴱ"),l11ll1_l1_ (u"࠭࡟ࡍࡆࡑࡣࠬⴲ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ็์ิ๐ࠠ็ฬࠪⴳ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⴴ"),459,l11ll1_l1_ (u"ࠩࠪⴵ"),l11ll1_l1_ (u"ࠪࠫⴶ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴷ"),l11ll1_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫⴸ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦๆศ๊ࠪⴹ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⴺ"),309,l11ll1_l1_ (u"ࠨࠩⴻ"),l11ll1_l1_ (u"ࠩࠪⴼ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴽ"),l11ll1_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪⴾ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿้ࠠ์ࠣื๏๋วࠨⴿ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⵀ"),569,l11ll1_l1_ (u"ࠧࠨⵁ"),l11ll1_l1_ (u"ࠨࠩⵂ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵃ"),l11ll1_l1_ (u"ࠪࡣࡘࡎࡎࡠࠩⵄ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩⵅ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⵆ"),589,l11ll1_l1_ (u"࠭ࠧⵇ"),l11ll1_l1_ (u"ࠧࠨⵈ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ⵉ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵊ"),l11ll1_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩⵋ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨⵌ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⵍ"),369,l11ll1_l1_ (u"࠭ࠧⵎ"),l11ll1_l1_ (u"ࠧࠨⵏ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵐ"),l11ll1_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨⵑ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭ⵒ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⵓ"),489,l11ll1_l1_ (u"ࠬ࠭ⵔ"),l11ll1_l1_ (u"࠭ࠧⵕ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵖ"),l11ll1_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧⵗ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ⵘ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⵙ"),259,l11ll1_l1_ (u"ࠫࠬⵚ"),l11ll1_l1_ (u"ࠬ࠭ⵛ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵜ"),l11ll1_l1_ (u"ࠧࡠࡅ࠷࡙ࡤ࠭ⵝ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧⵞ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⵟ"),429,l11ll1_l1_ (u"ࠪࠫⵠ"),l11ll1_l1_ (u"ࠫࠬⵡ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵢ"),l11ll1_l1_ (u"࠭࡟ࡔࡊ࠷ࡣࠬⵣ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭ⵤ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⵥ"),119,l11ll1_l1_ (u"ࠩࠪⵦ"),l11ll1_l1_ (u"ࠪࠫⵧ"),l1111ll_l1_+l11ll1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ⵨"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵩"),l11ll1_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬ⵪")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭⵫"),l11ll1_l1_ (u"ࠨࠩ⵬"),389,l11ll1_l1_ (u"ࠩࠪ⵭"),l11ll1_l1_ (u"ࠪࠫ⵮"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵯ"),l11ll1_l1_ (u"ࠬࡥࡅࡈࡘࡢࠫ⵰")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡวํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ⵱"),l11ll1_l1_ (u"ࠧࠨ⵲"),229,l11ll1_l1_ (u"ࠨࠩ⵳"),l11ll1_l1_ (u"ࠩࠪ⵴"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⵵"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⵶"),l11ll1_l1_ (u"ࠬ࠭⵷"),157)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵸"),l11ll1_l1_ (u"ࠧࡠࡎࡕ࡞ࡤ࠭⵹")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻่ࠣฬื่ำษࠪ⵺")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪ⵻"),709,l11ll1_l1_ (u"ࠪࠫ⵼"),l11ll1_l1_ (u"ࠫࠬ⵽"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵾"),l11ll1_l1_ (u"࠭࡟ࡇࡕࡗࡣ⵿ࠬ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไ์ุะวࠨⶀ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⶁ"),609,l11ll1_l1_ (u"ࠩࠪⶂ"),l11ll1_l1_ (u"ࠪࠫⶃ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶄ"),l11ll1_l1_ (u"ࠬࡥࡆࡃࡍࡢࠫⶅ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใหี่ฯࠧⶆ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⶇ"),629,l11ll1_l1_ (u"ࠨࠩⶈ"),l11ll1_l1_ (u"ࠩࠪⶉ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶊ"),l11ll1_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪⶋ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋ࠠษๅ์ฯ࠭ⶌ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⶍ"),669,l11ll1_l1_ (u"ࠧࠨⶎ"),l11ll1_l1_ (u"ࠨࠩⶏ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶐ"),l11ll1_l1_ (u"ࠪࡣࡇࡘࡓࡠࠩⶑ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศาีอ๎ั࠭ⶒ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⶓ"),659,l11ll1_l1_ (u"࠭ࠧⶔ"),l11ll1_l1_ (u"ࠧࠨⶕ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶖ"),l11ll1_l1_ (u"ࠩࡢࡌࡑࡉ࡟ࠨ⶗")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ⶘")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬ⶙"),89,l11ll1_l1_ (u"ࠬ࠭⶚"),l11ll1_l1_ (u"࠭ࠧ⶛"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⶜"),l11ll1_l1_ (u"ࠨࡡࡇࡖ࠼ࡥࠧ⶝")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤิืวๆษูࠣา࠭⶞")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫ⶟"),689,l11ll1_l1_ (u"ࠫࠬⶠ"),l11ll1_l1_ (u"ࠬ࠭ⶡ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶢ"),l11ll1_l1_ (u"ࠧࡠࡅࡐࡊࡤ࠭ⶣ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡใส๊ื࠭ⶤ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⶥ"),99,l11ll1_l1_ (u"ࠪࠫⶦ"),l11ll1_l1_ (u"ࠫࠬ⶧"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶨ"),l11ll1_l1_ (u"࠭࡟ࡄࡏࡏࡣࠬⶩ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠๅษํฮࠬⶪ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⶫ"),479,l11ll1_l1_ (u"ࠩࠪⶬ"),l11ll1_l1_ (u"ࠪࠫⶭ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶮ"),l11ll1_l1_ (u"ࠬࡥࡁࡃࡆࡢࠫ⶯")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬูࠦษั๋ࠫⶰ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⶱ"),559,l11ll1_l1_ (u"ࠨࠩⶲ"),l11ll1_l1_ (u"ࠩࠪⶳ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶴ"),l11ll1_l1_ (u"ࠫࡤࡉ࠴ࡉࡡࠪⶵ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩⶶ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ⶷"),699,l11ll1_l1_ (u"ࠧࠨⶸ"),l11ll1_l1_ (u"ࠨࠩⶹ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶺ"),l11ll1_l1_ (u"ࠪࡣࡆࡎࡋࡠࠩⶻ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪⶼ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⶽ"),619,l11ll1_l1_ (u"࠭ࠧⶾ"),l11ll1_l1_ (u"ࠧࠨ⶿"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷀ"),l11ll1_l1_ (u"ࠩࡢࡇࡈࡈ࡟ࠨⷁ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨⷂ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⷃ"),639,l11ll1_l1_ (u"ࠬ࠭ⷄ"),l11ll1_l1_ (u"࠭ࠧⷅ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷆ"),l11ll1_l1_ (u"ࠨࡡࡖࡌ࡙ࡥࠧ⷇")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨⷈ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⷉ"),649,l11ll1_l1_ (u"ࠫࠬⷊ"),l11ll1_l1_ (u"ࠬ࠭ⷋ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷌ"),l11ll1_l1_ (u"ࠧࡠࡇࡊࡒࡤ࠭ⷍ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊่ࠡส์ࠬⷎ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪ⷏"),439,l11ll1_l1_ (u"ࠪࠫⷐ"),l11ll1_l1_ (u"ࠫࠬⷑ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷒ"),l11ll1_l1_ (u"࠭࡟ࡇࡊ࠵ࡣࠬⷓ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧⷔ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⷕ"),599,l11ll1_l1_ (u"ࠩࠪⷖ"),l11ll1_l1_ (u"ࠪࠫ⷗"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷘ"),l11ll1_l1_ (u"ࠬࡥࡅࡈࡆࡢࠫⷙ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡวํะ๏ࠦฯ๋ัࠪⷚ"),l11ll1_l1_ (u"ࠧࠨⷛ"),449,l11ll1_l1_ (u"ࠨࠩⷜ"),l11ll1_l1_ (u"ࠩࠪⷝ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷞ"),l11ll1_l1_ (u"ࠫࡤࡇࡋࡄࡡࠪ⷟")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศๅ๋ห๊ࠦใศ็ࠪⷠ"),l11ll1_l1_ (u"࠭ࠧⷡ"),359,l11ll1_l1_ (u"ࠧࠨⷢ"),l11ll1_l1_ (u"ࠨࠩⷣ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷤ"),l11ll1_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩⷥ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩⷦ"),l11ll1_l1_ (u"ࠬ࠭ⷧ"),499,l11ll1_l1_ (u"࠭ࠧⷨ"),l11ll1_l1_ (u"ࠧࠨⷩ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷪ"),l11ll1_l1_ (u"ࠩࡢࡅࡗࡒ࡟ࠨⷫ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨⷬ"),l11ll1_l1_ (u"ࠫࠬⷭ"),209,l11ll1_l1_ (u"ࠬ࠭ⷮ"),l11ll1_l1_ (u"࠭ࠧⷯ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷰ"),l11ll1_l1_ (u"ࠨࡡࡋࡉࡑࡥࠧⷱ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩⷲ"),l11ll1_l1_ (u"ࠪࠫⷳ"),99,l11ll1_l1_ (u"ࠫࠬⷴ"),l11ll1_l1_ (u"ࠬ࠭ⷵ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷶ"),l11ll1_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭ⷷ")+search+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏ื๊ิࠢไ์ึ่ࠦหึࠪⷸ"),l11ll1_l1_ (u"ࠩࠪⷹ"),218,l11ll1_l1_ (u"ࠪࠫⷺ"),l11ll1_l1_ (u"ࠫࠬⷻ"),search) # 219
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷼ"),l11ll1_l1_ (u"࠭࡟ࡎࡘ࡝ࡣࠬⷽ")+search+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺ่ࠢ์ๆ๐าࠡๆส๊ิ࠭ⷾ"),l11ll1_l1_ (u"ࠨࠩⷿ"),188,l11ll1_l1_ (u"ࠩࠪ⸀"),l11ll1_l1_ (u"ࠪࠫ⸁"),search)# 189
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⸂"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⸃"),l11ll1_l1_ (u"࠭ࠧ⸄"),157)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸅"),l11ll1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ⸆")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏๎ส๋๊หࠫ⸇")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫ⸈"),149,l11ll1_l1_ (u"ࠫࠬ⸉"),l11ll1_l1_ (u"ࠬ࠭⸊"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸋"),l11ll1_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭⸌")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭⸍")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪ⸎"),409,l11ll1_l1_ (u"ࠪࠫ⸏"),l11ll1_l1_ (u"ࠫࠬ⸐"),l1111ll_l1_)
	return
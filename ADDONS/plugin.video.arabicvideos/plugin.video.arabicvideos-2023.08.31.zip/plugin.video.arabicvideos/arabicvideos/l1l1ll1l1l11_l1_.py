# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ擆")
headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ擇"):l11ll1_l1_ (u"ࠬ࠭擈")}
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ擉")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ擊"),l11ll1_l1_ (u"ࠨࡹࡺࡩࠬ擋")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11111_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llll11_l1_(url,text)
	elif mode==564: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ擌")+text)
	elif mode==565: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ操")+text)
	elif mode==566: results = l1l111_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ擎"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭擏"),l11ll1_l1_ (u"࠭ࠧ擐"),False,l11ll1_l1_ (u"ࠧࠨ擑"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ擒"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ擓")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ擔"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ擕")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ擖"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ擗"),l11ll1_l1_ (u"ࠧࠨ擘"),l11ll1_l1_ (u"ࠨࠩ擙"),l11ll1_l1_ (u"ࠩࠪ據"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ擛"))
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ擜"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ擝"),l11ll1_l1_ (u"࠭ࠧ擞"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ擟"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ擠"),l11ll1_l1_ (u"ࠩࠪ擡"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ擢"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ擣"),l11l1l_l1_,569,l11ll1_l1_ (u"ࠬ࠭擤"),l11ll1_l1_ (u"࠭ࠧ擥"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ擦"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ擧"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ擨"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ擩"),564)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擪"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ擫"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭擬"),565)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ擭"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ擮"),l11ll1_l1_ (u"ࠩࠪ擯"),9999)
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ擰"):hostname,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ擱"):l11ll1_l1_ (u"ࠬ࠭擲")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ擳"),l11ll1_l1_ (u"ࠧ࠰ࠩ擴"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࡢࡢࡴࠫ࠲࠯ࡅࠩࡧ࡫࡯ࡸࡪࡸࠧ擵"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ擶"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠪࠩࡩ࠿ࠥ࠹࠷ࠨࡨ࠽ࠫࡢ࠶ࠧࡧ࠼ࠪࡧ࠷ࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡦ࠾ࠫࡤ࠹ࠧࡤ࠽࠲ࠫࡤ࠹ࠧࡤࡨࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡢ࠻ࠪ擷") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擸"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ擹")+l111l1_l1_+title,l1lllll_l1_,566)
	#	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ擺"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ擻"),l11ll1_l1_ (u"ࠨࠩ擼"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭擽"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ擾"),l11ll1_l1_ (u"ࠫࠬ擿"),l11ll1_l1_ (u"ࠬ࠭攀"),l11ll1_l1_ (u"࠭ࠧ攁"),l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ攂"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡷࡑ࡯ࡳࡵࡄࡸࡸࡹࡵ࡮ࠣࠩ攃"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭攄"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ攅") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ攆"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠬ࠭攇"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攈"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ攉")+l111l1_l1_+title,l1lllll_l1_,566)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭攊"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ攋"),l11ll1_l1_ (u"ࠪࠫ攌"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭攍"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ攎"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攏"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ攐")+l111l1_l1_+title,l1lllll_l1_,566,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ攑"),l11ll1_l1_ (u"ࠩࠪ攒"),url,l11ll1_l1_ (u"ࠪࠫ攓"))
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ攔"):url,l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ攕"):l11ll1_l1_ (u"࠭ࠧ攖")}
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ攗"),url,l11ll1_l1_ (u"ࠨࠩ攘"),l11ll1_l1_ (u"ࠩࠪ攙"),l11ll1_l1_ (u"ࠪࠫ攚"),l11ll1_l1_ (u"ࠫࠬ攛"),l11ll1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ攜"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攝"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ攞"),url,564)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攟"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ攠"),url,565)
	if l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ攡") in html:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ攢"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭攣"),url,561,l11ll1_l1_ (u"࠭ࠧ攤"),l11ll1_l1_ (u"ࠧࠨ攥"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ攦"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ攧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭攨"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ攩"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l11111_l1_(l1ll1l1lll11_l1_,type=l11ll1_l1_ (u"ࠬ࠭攪")):
	if l11ll1_l1_ (u"࠭࠺࠻ࠩ攫") in l1ll1l1lll11_l1_:
		l11l111_l1_,url = l1ll1l1lll11_l1_.split(l11ll1_l1_ (u"ࠧ࠻࠼ࠪ攬"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ攭"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1lll11_l1_,l1ll1l1lll11_l1_
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ攮"):l11l111_l1_,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ支"):l11ll1_l1_ (u"ࠫࠬ攰")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ攱"),url,l11ll1_l1_ (u"࠭ࠧ攲"),l11ll1_l1_ (u"ࠧࠨ攳"),l11ll1_l1_ (u"ࠨࠩ攴"),l11ll1_l1_ (u"ࠩࠪ攵"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ收"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭攷"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠩ攸"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ改"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠧ࡝࡞࠲ࠫ攺"),l11ll1_l1_ (u"ࠨ࠱ࠪ攻")).replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠧ࠭攼"),l11ll1_l1_ (u"ࠪࠦࠬ攽"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ放"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ政"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ敀"),l11ll1_l1_ (u"ࠧࠨ敁"))
			if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ敂") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ敃"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠪั้่ษࠨ敄") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠯า๊โสࠢ࠮ࡠࡩ࠱ࠧ故"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ敆") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭敇"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭效"),l111l1_l1_+title,l1lllll_l1_,562,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ敉"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ敊"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ敋")+count
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ敌"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ敍"),l1lllll_l1_,561,l11ll1_l1_ (u"࠭ࠧ敎"),l11ll1_l1_ (u"ࠧࠨ敏"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ敐"))
		elif type==l11ll1_l1_ (u"ࠩࠪ救"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ敒"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ敓"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ敔")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭敕"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l1llll11_l1_(url,type=l11ll1_l1_ (u"ࠧࠨ敖")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ敗"),l11ll1_l1_ (u"ࠩࠪ敘"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ教"),url,l11ll1_l1_ (u"ࠫࠬ敚"),l11ll1_l1_ (u"ࠬ࠭敛"),l11ll1_l1_ (u"࠭ࠧ敜"),l11ll1_l1_ (u"ࠧࠨ敝"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ敞"))
	html = response.content
	html = l1111_l1_(html)
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࡡ࠭࠲࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠳ࠧ࠭ࠩࠣࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍ࡮࡬ࠠࠨ็๋ื๊࠭ࠠࡪࡰࠣࡲࡦࡳࡥࠡࡣࡱࡨࠥࡴ࡯ࡵࠢࡷࡽࡵ࡫࠺ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨ็๋ื๊࠭ࠩ࡜࠲ࡠࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ๅีษ๊ำฮ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࡨࡰ࡮࡬ࠠࠨฯ็ๆฮ࠭ࠠࡪࡰࠣࡲࡦࡳࡥ࠻ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩะ่็ฯࠧࠪ࡝࠳ࡡࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧๆึส๋ิฯࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠦࠧࠨ敟")
	# l1lll1l_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ敠"),html,re.DOTALL)
	if not type and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭敡"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ敢")+title
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭散"),l111l1_l1_+title,l1lllll_l1_,563,l11ll1_l1_ (u"ࠧࠨ敤"),l11ll1_l1_ (u"ࠨࠩ敥"),l11ll1_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ敦"))
			return
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࡵࡁࠫ敧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ敨"),block)
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭敩"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ敪"),str(items))
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ敫"))
			#title = name+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬ敬")+title
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ敭"),l111l1_l1_+title,l1lllll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11ll1_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ敮"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠫࠥ࠳ࠠๆษํࠤุ๐ๅศࠩ敯"),l11ll1_l1_ (u"ࠬ࠭数")).replace(l11ll1_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ敱"),l11ll1_l1_ (u"ࠧࠨ敲"))
		else: title = l11ll1_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭敳")
		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ整"),l111l1_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ敵"),url,l11ll1_l1_ (u"ࠫࠬ敶"),l11ll1_l1_ (u"ࠬ࠭敷"),l11ll1_l1_ (u"࠭ࠧ數"),l11ll1_l1_ (u"ࠧࠨ敹"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ敺"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ษ็ฮฺ์๊โ࠾࠱࠮ࡄࡂࡡ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ敻"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡈࡱࡧ࡫ࡤࠣࠩ敼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ敽"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ敾") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"࠭ำ๋ำไีࠥ๎๊ࠡีํ้ฬ࠭敿"): name = l11ll1_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ斀")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ斁")+name+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ斂")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡹࡴ࠮࠯ࡇࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ斃"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ斄"),block,re.DOTALL)
		for l1lllll_l1_,l111lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ斅") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ斆"),l111lll1_l1_,re.DOTALL)
			if l111lll1_l1_: l111lll1_l1_ = l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬ文")+l111lll1_l1_[0]
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠨࠩ斈")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡺࡩࡨ࡯࡭ࡢࠩ斉")+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ斊")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ斋"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ斌"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"࠭ࠧ斍")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ斎"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ斏"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ斐"),l11ll1_l1_ (u"ࠪ࠯ࠬ斑"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠫ࠴࠭斒"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ斓"),l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ斔"),l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ斕"),l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ斖")]
	l1l11l111_l1_ = [l11ll1_l1_ (u"ࠩฦๅ้อๅࠨ斗"),l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠫ斘"),l11ll1_l1_ (u"ࠫศ์๊ๆ์ࠣ์่ืส้่ࠪ料"),l11ll1_l1_ (u"ࠬฮัศ็ฯࠤฯ๊๊โิํ์๋࠭斚"),l11ll1_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠล้๎๊๐ࠧ斛")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅุๆ๋ฬ࠿࠭斜"), l1l11l111_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l1l_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ斝"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ斞"),l11ll1_l1_ (u"ࠪࠫ斟"),False,l11ll1_l1_ (u"ࠫࠬ斠"),l11ll1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ斡"))
		#hostname = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ斢")]
		#hostname = response.url
		#hostname = hostname.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ斣"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ斤")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1ll1lll_l1_(l1ll1l1lll11_l1_,filter):
	if l11ll1_l1_ (u"ࠩࡂࡃࠬ斥") in l1ll1l1lll11_l1_: url = l1ll1l1lll11_l1_.split(l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ斦"))[0]
	else: url = l1ll1l1lll11_l1_
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ斧"):l1ll1l1lll11_l1_,l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ斨"):l11ll1_l1_ (u"࠭ࠧ斩")}
	filter = filter.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ斪"),l11ll1_l1_ (u"ࠨࠩ斫"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭斬"),1)
	if filter==l11ll1_l1_ (u"ࠪࠫ断"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠫࠬ斮"),l11ll1_l1_ (u"ࠬ࠭斯")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ新"))
	if type==l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ斱"):
		if l1l1111ll_l1_[0]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ斲") not in l1l111l1_l1_: category = l1l1111ll_l1_[0]
		for i in range(len(l1l1111ll_l1_[0:-1])):
			if l1l1111ll_l1_[i]+l11ll1_l1_ (u"ࠩࡀࡁࠬ斳") in l1l111l1_l1_: category = l1l1111ll_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭斴")+category+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ斵")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ斶")+category+l11ll1_l1_ (u"࠭࠽࠾࠲ࠪ斷")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ斸"))+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ方")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠪࠬ斺"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭斻"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ於")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭施"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ斾"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠧࠨ斿"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ旀"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠩࠪ旁"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ旂")+l1l1111l_l1_
		l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_,l1ll1l1lll11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ旃"),l111l1_l1_+l11ll1_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ旄"),l1lllll1l_l1_,561,l11ll1_l1_ (u"࠭ࠧ旅"),l11ll1_l1_ (u"ࠧࠨ旆"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ旇"))
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ旈"),l111l1_l1_+l11ll1_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ旉")+l11ll11l_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ旊"),l1lllll1l_l1_,561,l11ll1_l1_ (u"ࠬ࠭旋"),l11ll1_l1_ (u"࠭ࠧ旌"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ旍"))
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭旎"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ族"),l11ll1_l1_ (u"ࠪࠫ旐"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ旑"),url,l11ll1_l1_ (u"ࠬ࠭旒"),l11ll1_l1_ (u"࠭ࠧ旓"),l11ll1_l1_ (u"ࠧࠨ旔"),l11ll1_l1_ (u"ࠨࠩ旕"),l11ll1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ旖"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠪࡠࡡࠨࠧ旗"),l11ll1_l1_ (u"ࠫࠧ࠭旘")).replace(l11ll1_l1_ (u"ࠬࡢ࡜࠰ࠩ旙"),l11ll1_l1_ (u"࠭࠯ࠨ旚"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ旛"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭旜"),block+l11ll1_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭旝"),re.DOTALL)
	dict = {}
	for l1ll1l11_l1_,name,block in l1ll1ll1_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ旞") in l1ll1l11_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭旟"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠬࡃ࠽ࠨ无") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ旡"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<=1:
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ既")+l1l11ll1_l1_)
				return
			else:
				l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_,l1ll1l1lll11_l1_)
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ旣"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ัฺ๋๊ࠩ旤"),l1lllll1l_l1_,561,l11ll1_l1_ (u"ࠪࠫ日"),l11ll1_l1_ (u"ࠫࠬ旦"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭旧"))
				else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭旨"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠧ早"),l111lll_l1_,564,l11ll1_l1_ (u"ࠨࠩ旪"),l11ll1_l1_ (u"ࠩࠪ旫"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ旬"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ旭")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ旮")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ旯")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠧ࠾࠿࠳ࠫ旰")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ旱")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ旲"),l111l1_l1_+name+l11ll1_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ旳"),l111lll_l1_,565,l11ll1_l1_ (u"ࠫࠬ旴"),l11ll1_l1_ (u"ࠬ࠭旵"),l1l11ll1_l1_+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ时"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠧࡳࠩ旷") or value==l11ll1_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ旸"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ旹") in option: continue
			if l11ll1_l1_ (u"ࠪห้้ไࠨ旺") in option: continue
			if l11ll1_l1_ (u"ࠫࡳ࠳ࡡࠨ旻") in value: continue
			#if value in [l11ll1_l1_ (u"ࠬࡸࠧ旼"),l11ll1_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ旽"),l11ll1_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭旾")]: continue
			#if l1ll1l11_l1_==l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ旿"): option = value
			if option==l11ll1_l1_ (u"ࠩࠪ昀"): option = value
			l11l1l11l_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ昁"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l11l_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l11_l1_ = name+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ昂")+l11l1l11l_l1_
			dict[l1ll1l11_l1_][value] = l1lll1l11_l1_
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ昃")+l1ll1l11_l1_+l11ll1_l1_ (u"࠭࠽࠾ࠩ昄")+l11l1l11l_l1_
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ昅")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ昆")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭昇")+l1l1ll11_l1_
			if type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ昈"):
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昉"),l111l1_l1_+l1lll1l11_l1_,url,565,l11ll1_l1_ (u"ࠬ࠭昊"),l11ll1_l1_ (u"࠭ࠧ昋"),l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ昌"))
			elif type==l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ昍") and l1l1111ll_l1_[-2]+l11ll1_l1_ (u"ࠩࡀࡁࠬ明") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭昏"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ昐"),l11ll1_l1_ (u"ࠬ࠭昑"),l11llll1_l1_,l1l1ll11_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ昒")+l11llll1_l1_
				l1lllll1l_l1_ = l11ll1l11_l1_(l11l111_l1_,l1ll1l1lll11_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ易"),l111l1_l1_+l1lll1l11_l1_,l1lllll1l_l1_,561,l11ll1_l1_ (u"ࠨࠩ昔"),l11ll1_l1_ (u"ࠩࠪ昕"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ昖"))
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昗"),l111l1_l1_+l1lll1l11_l1_,url,564,l11ll1_l1_ (u"ࠬ࠭昘"),l11ll1_l1_ (u"࠭ࠧ昙"),l1ll11ll_l1_)
	return
l1l1111ll_l1_ = [l11ll1_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭昚"),l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ昛"),l11ll1_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ昜")]
l11llllll_l1_ = [l11ll1_l1_ (u"ࠪࡱࡵࡧࡡࠨ昝"),l11ll1_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ昞"),l11ll1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ星"),l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ映"),l11ll1_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ昡"),l11ll1_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ昢"),l11ll1_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ昣"),l11ll1_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ昤")]
def l11ll1l11_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ春") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ昦"),l11ll1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ昧"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭昨"),l11ll1_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ昩"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩࡀࡁࠬ昪"),l11ll1_l1_ (u"ࠪ࠳ࠬ昫"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫࠫࠬࠧ昬"),l11ll1_l1_ (u"ࠬ࠵ࠧ昭"))
	return l111lll_l1_
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ昮"),l11ll1_l1_ (u"ࠧࠨ是"),filters,l11ll1_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ昰")+mode)
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ昱")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭昲")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ昳")					all filters (l11lll11_l1_ l1l1l1l1_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ昴"))
	l1l111ll_l1_,l1ll11l1_l1_ = {},l11ll1_l1_ (u"࠭ࠧ昵")
	if l11ll1_l1_ (u"ࠧ࠾࠿ࠪ昶") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠨࠨࠩࠫ昷"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠩࡀࡁࠬ昸"))
			l1l111ll_l1_[var] = value
	for key in l11llllll_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠪ࠴ࠬ昹")
		if l11ll1_l1_ (u"ࠫࠪ࠭昺") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ昻") and value!=l11ll1_l1_ (u"࠭࠰ࠨ昼"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ昽")+value
		elif mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ显") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫ昿"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭晀")+key+l11ll1_l1_ (u"ࠫࡂࡃࠧ晁")+value
		elif mode==l11ll1_l1_ (u"ࠬࡧ࡬࡭ࠩ時"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ晃")+key+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ晄")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ晅"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠪࠬ晆"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ晇"),l11ll1_l1_ (u"ࠫࠬ晈"),l1ll11l1_l1_,l11ll1_l1_ (u"ࠬࡕࡕࡕࠩ晉"))
	return l1ll11l1_l1_
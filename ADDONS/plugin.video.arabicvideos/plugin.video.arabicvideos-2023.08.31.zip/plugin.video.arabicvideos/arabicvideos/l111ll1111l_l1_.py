# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭䵶")
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䵷"):l11ll1_l1_ (u"ࠨࠩ䵸")}
script_name = l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ䵹")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ䵺")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11ll1_l1_ (u"ࠫ࠸࠭䵻"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11ll1_l1_ (u"ࠬ࠷ࠧ䵼"))
	elif mode==36: results = CATEGORIES(url,l11ll1_l1_ (u"࠭࠲ࠨ䵽"))
	elif mode==37: results = CATEGORIES(url,l11ll1_l1_ (u"ࠧ࠵ࠩ䵾"))
	elif mode==38: results = l1l1ll1l1_l1_()
	elif mode==39: results = SEARCH(text,l1l1111_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵿"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䶀"),l11ll1_l1_ (u"ࠪࠫ䶁"),39,l11ll1_l1_ (u"ࠫࠬ䶂"),l11ll1_l1_ (u"ࠬ࠭䶃"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䶄"))
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䶅"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䶆"),l11ll1_l1_ (u"ࠩࠪ䶇"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䶈"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䶉")+l111l1_l1_+l11ll1_l1_ (u"่ࠬๆศห๋้ࠣอࠠๆ่้ࠣํู่ࠡสส๊๏ะࠧ䶊"),l11ll1_l1_ (u"࠭ࠧ䶋"),38)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶌"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䶍")+l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไศฬࠣ์อืวๆฮࠪ䶎"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䶏"),31)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶐"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䶑")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬ้หาุ่ࠢฬํฯสࠩ䶒"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䶓"),37)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶔"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䶕")+l111l1_l1_+l11ll1_l1_ (u"ࠪหๆ๊วๆࠢะือࠦวๅ่๋฽ࠬ䶖"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ䶗"),35)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䶘"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䶙")+l111l1_l1_+l11ll1_l1_ (u"ࠧศใ็ห๊ࠦอิสࠣห้๋ๅฬๆࠪ䶚"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ䶛"),36)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶜"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䶝")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬำฯฬࠢส่ฬ็ไศ็ࠪ䶞"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭䶟"),32)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䶠"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䶡")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึีา๐วหࠩ䶢"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱࠷࠳࠶࠭䶣"),32)
	return l11ll1_l1_ (u"ࠪࠫ䶤")
def CATEGORIES(url,select=l11ll1_l1_ (u"ࠫࠬ䶥")):
	type = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ䶦"))[3]
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䶧"),l11ll1_l1_ (u"ࠧࠨ䶨"),type, url)
	if type==l11ll1_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䶩"):
		html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ䶪"),headers,l11ll1_l1_ (u"ࠪࠫ䶫"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫ䶬"))
		if select==l11ll1_l1_ (u"ࠬ࠹ࠧ䶭"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡸ࡫ࡲࡪࡧࡶࡊࡴࡸ࡭ࠨ䶮"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䶯"),block,re.DOTALL)
			for l1lllll_l1_,name in items:
				if l11ll1_l1_ (u"ࠨๅ็๎ออสࠡ็ูั่ฯࠧ䶰") in name: continue
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ䶱"))
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶲"),l111l1_l1_+name,url,32)
		if select==l11ll1_l1_ (u"ࠫ࠹࠭䶳"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡩ࡫ࡴࡢ࡫࡯ࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡸࡁࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䶴"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䶵"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title in items:
				url = l11l1l_l1_ + l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ䶶"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶷"),l111l1_l1_+title,url,32,l1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䶸"),l11ll1_l1_ (u"ࠪࠫ䶹"),url,l11ll1_l1_ (u"ࠫࠬ䶺"))
	if type==l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䶻"):
		html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ䶼"),headers,l11ll1_l1_ (u"ࠧࠨ䶽"),l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠷ࡴࡤࠨ䶾"))
		if select==l11ll1_l1_ (u"ࠩ࠴ࠫ䶿"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࡊࡩࡳࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䷀"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࡂࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䷁"),block,re.DOTALL)
			for value,name in items:
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡧࡦࡰࡵࡩ࠴࠭䷂") + value
				name = name.strip(l11ll1_l1_ (u"࠭ࠠࠨ䷃"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䷄"),l111l1_l1_+name,url,32)
		elif select==l11ll1_l1_ (u"ࠨ࠴ࠪ䷅"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡃࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ䷆"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䷇"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭䷈"))
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡡࡤࡶࡲࡶ࠴࠭䷉") + value
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷊"),l111l1_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䷋"),l11ll1_l1_ (u"ࠨࠩ䷌"),url,l11ll1_l1_ (u"ࠩࠪ䷍"))
	type = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ䷎"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ䷏"),headers,l11ll1_l1_ (u"ࠬ࠭䷐"),l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ䷑"))
	if l11ll1_l1_ (u"ࠧࡩࡱࡰࡩࠬ䷒") in url: type=l11ll1_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䷓")
	if type==l11ll1_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䷔"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠮࠮ࠫࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䷕"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀࠬ䷖"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,name in items:
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ䷗"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷘"),l111l1_l1_+name,url,32,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䷙"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠭࠴ࠫࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ䷚"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠭䷛"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,name in items:
			name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ䷜"))
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䷝"),l111l1_l1_+name,url,33,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䷞"):
		l1l1111_l1_ = url.split(l11ll1_l1_ (u"࠭࠯ࠨ䷟"))[-1]
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䷠"),l11ll1_l1_ (u"ࠨࠩ䷡"),url,l11ll1_l1_ (u"ࠩࠪ䷢"))
		if l1l1111_l1_==l11ll1_l1_ (u"ࠪ࠵ࠬ䷣"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠩ䷤"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻ࠭䷥"),block,re.DOTALL)
			count = 0
			for l1lllll_l1_,l1lll1_l1_,l1ll1l1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪ䷦") + l1ll1l1_l1_
				url = l11l1l_l1_ + l1lllll_l1_
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䷧"),l111l1_l1_+name,url,33,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠳࠰࠿ࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䷨"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࠪ䷩"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,l1ll1l1_l1_ in items:
			l1ll1l1_l1_ = l1ll1l1_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ䷪"))
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭䷫"))
			name = title + l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ䷬") + l1ll1l1_l1_
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䷭"),l111l1_l1_+name,url,33,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡨ࡮ࡼࡴ࡭࡯ࡣࡰࡰ࠰ࡧ࡭࡫ࡶࡳࡱࡱ࠱ࡷ࡯ࡧࡩࡶࠫ࠲࠰ࡅࠩࡥࡣࡷࡥ࠲ࡸࡥࡷ࡫ࡹࡩ࠲ࢀ࡯࡯ࡧ࡬ࡨࡂࠨ࠴ࠣࠩ䷮"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䷯"),block,re.DOTALL)
	for l1lllll_l1_,l1l1111_l1_ in items:
		url = l11l1l_l1_ + l1lllll_l1_
		name = l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ䷰") + l1l1111_l1_
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷱"),l111l1_l1_+name,url,32)
	return
def PLAY(url):
	if l11ll1_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䷲") in url:
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࡺ࠶࠵ࡳࡦࡴ࡬ࡩࡸࡒࡩ࡯࡭࠲ࠫ䷳") + url.split(l11ll1_l1_ (u"࠭࠯ࠨ䷴"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䷵"),url,l11ll1_l1_ (u"ࠨࠩ䷶"),headers,l11ll1_l1_ (u"ࠩࠪ䷷"),l11ll1_l1_ (u"ࠪࠫ䷸"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䷹"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷺"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ䷻"),l11ll1_l1_ (u"ࠧ࠰ࠩ䷼"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䷽"),url,l11ll1_l1_ (u"ࠩࠪ䷾"),headers,l11ll1_l1_ (u"ࠪࠫ䷿"),l11ll1_l1_ (u"ࠫࠬ一"),l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭丁"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡕࡓࡎࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丂"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭七"))
	return
def SEARCH(search,l1l1111_l1_=l11ll1_l1_ (u"ࠨࠩ丄")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ丅"),l11ll1_l1_ (u"ࠪࠩ࠷࠶ࠧ丆"))
	l1l1llll1_l1_ = [l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ万"),l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ丈")]
	if not l1l1111_l1_: l1l1111_l1_ = l11ll1_l1_ (u"࠭࠱ࠨ三")
	else: l1l1111_l1_,type = l1l1111_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩ上"))
	if l1ll_l1_:
		l1l11l111_l1_ = [ l11ll1_l1_ (u"ࠨสะฯࠥ฿ๆࠡษไ่ฬ๋ࠧ下") , l11ll1_l1_ (u"ࠩหัะูࠦ็่ࠢืู้ไศฬࠪ丌")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠠ࠮ࠢสาฯืࠠศๆหัะ࠭不"), l1l11l111_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1llll1_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࡣࠬ与") in options: type = l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ丏")
		elif l11ll1_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧ丐") in options: type = l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ丑")
		else: return
	headers[l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ丒")] = l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ专")
	data = {l11ll1_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࠩ且"):l1111ll_l1_ , l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡈࡴࡳࡡࡪࡰࠪ丕"):type}
	if l1l1111_l1_!=l11ll1_l1_ (u"ࠬ࠷ࠧ世"): data[l11ll1_l1_ (u"࠭ࡦࡳࡱࡰࠫ丗")] = l1l1111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ丘"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ丙"),data,headers,l11ll1_l1_ (u"ࠩࠪ业"),l11ll1_l1_ (u"ࠪࠫ丛"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ东"))
	html = response.content
	items=re.findall(l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ丝"),html,re.DOTALL)
	if items:
		for title,l1lllll_l1_ in items:
			url = l11l1l_l1_ + l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ丞"),l11ll1_l1_ (u"ࠧ࠰ࠩ丟"))
			if l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ丠") in url: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ両"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ๏๊ๅࠡࠩ丢")+title,url,33)
			elif l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭丣") in url:
				url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ两"),l11ll1_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷ࠳ࠬ严"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ並"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊ࠠࠨ丧")+title,url+l11ll1_l1_ (u"ࠩ࠲࠵ࠬ丨"),32)
	count=re.findall(l11ll1_l1_ (u"ࠪࠦࡹࡵࡴࡢ࡮ࠥ࠾࠭࠴ࠪࡀࠫࢀࠫ丩"),html,re.DOTALL)
	if count:
		l1l1l1ll1_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll111l1_l1_ in range(1,l1l1l1ll1_l1_):
			l1ll111l1_l1_ = str(l1ll111l1_l1_)
			if l1ll111l1_l1_!=l1l1111_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ个"),l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ丫")+l1ll111l1_l1_,l11ll1_l1_ (u"࠭ࠧ丬"),39,l11ll1_l1_ (u"ࠧࠨ中"),l1ll111l1_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ丮")+type,search)
	return
def l1l1ll1l1_l1_():
	l1lllll_l1_ = l11ll1_l1_ (u"ࠩࡤࡌࡗ࠶ࡣࡅࡱࡹࡐ࠷ࡪࡺࡥࡊࡍࡰ࡞࡝࠰࠱ࡎࡱࡆ࡭ࡨ࡭ࡗ࠲ࡏࡱࡓࡼࡌ࡮࡮ࡶࡐ࠷࡜࡫࡛࠴࡙ࡪ࡞࡝ࡊࡺࡎ࠵࡬࡭ࡨࡇࡇࡗ࡙࡭࠾ࡽࡢࡈࡈ࠸ࡦࡌࡲࡺࡥࡅ࠸ࡸࡒ࠹ࡕ࠵ࠩ丯")
	l1lllll_l1_ = base64.b64decode(l1lllll_l1_)
	l1lllll_l1_ = l1lllll_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ丰"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ丱"))
	return
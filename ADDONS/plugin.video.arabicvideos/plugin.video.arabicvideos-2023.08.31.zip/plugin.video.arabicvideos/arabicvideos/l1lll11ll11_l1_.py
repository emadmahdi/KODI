# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
import bs4
script_name = l11ll1_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ│")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡋࡌࡄࡡࠪ┃")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1ll1ll11ll_l1_(url)
	elif mode==512: results = l1lll1ll111_l1_(url)
	elif mode==513: results = l1lll1l1lll_l1_(url)
	elif mode==514: results = l1ll1ll1l1l_l1_(url,l11ll1_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ┄")+text)
	elif mode==515: results = l1ll1ll1l1l_l1_(url,l11ll1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ┅")+text)
	elif mode==516: results = l1lll111ll1_l1_(text)
	elif mode==517: results = l1lll11llll_l1_(url)
	elif mode==518: results = l1lll1l1111_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1lll11l11l_l1_(url)
	elif mode==521: results = l1ll1ll11l1_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1ll1lll111_l1_(text)
	elif mode==524: results = l1ll1lll1ll_l1_()
	elif mode==525: results = l1lll1l1ll1_l1_()
	elif mode==526: results = l1lll11l111_l1_()
	elif mode==527: results = l1ll1llll11_l1_()
	else: results = False
	return results
def MENU(l1l1l11l_l1_=l11ll1_l1_ (u"ࠧࠨ┆")):
	if not l1l1l11l_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┇"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ┈"),l11ll1_l1_ (u"ࠪࠫ┉"),519)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ┊"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ┋"),l11ll1_l1_ (u"࠭ࠧ┌"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┍"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็ว฾๋วๅࠩ┎"),l11ll1_l1_ (u"ࠩࠪ┏"),525)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┐"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊รีะสูࠬ┑"),l11ll1_l1_ (u"ࠬ࠭┒"),526)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆู่๋็วหࠩ└"),l11ll1_l1_ (u"ࠨࠩ┕"),527)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┖"),l111l1_l1_+l11ll1_l1_ (u"้ࠪํฺู่หࠣห้๋ๆ้฻สฮࠬ┗"),l11ll1_l1_ (u"ࠫࠬ┘"),524)
	return
def l1ll1lll1ll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┙"),l111l1_l1_+l11ll1_l1_ (u"࠭ࠠโ์า๎ํํวหࠢ࠰ࠤำอีสࠩ┚"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࠧ┛"),520)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ├"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรฮัฮࠫ┝"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡰࡦࡺࡥࡴࡶࠪ┞"),521)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┟"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦๆิ๋ࠧ┠"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵࡯࡭ࡦࡨࡷࡹ࠭┡"),521)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┢"),l111l1_l1_+l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษใฬำู้ࠣอ็ะหࠪ┣"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࡹ࡭ࡪࡽࡳࠨ┤"),521)
	return
def l1lll1l1ll1_l1_():
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊࡶࡼࡴࡪࠦ࠽ࠡ࠳ࠣࠧࠥࡧࡣࡵࡱࡵࡷࠒࠐࠉࡵࡻࡳࡩࠥࡃࠠ࠳ࠢࠦࠤࡻ࡯ࡤࡦࡱࡶࠑࠏࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࠵ࠥࠩࠠ࡮ࡱࡹ࡭ࡪࡹࠍࠋࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦ࠳ࠡࠥࠣࡷࡪࡸࡩࡦࡵࠐࠎࠎ࡬࡯ࡳࡧ࡬࡫ࡳࠦ࠽ࠡࡨࡤࡰࡸ࡫ࠠࠤࠢࡤࡶࡦࡨࡩࡤࠏࠍࠍ࡫ࡵࡲࡦ࡫ࡪࡲࠥࡃࠠࡵࡴࡸࡩࠥࠩࠠࡦࡰࡪࡰ࡮ࡹࡨࠎࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨ็่ฯ้๐ๆࠡลไ่ฬฺ๋ࠠำห๎ࠬ࠲࡬ࡪࡰ࡮࠶࠱࠻࠱࠲ࠫࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไุ๋่้๊ࠣำๅษอࠤ฾ืศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠴࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠฤใ็ห๊ࠦวอ่ห๎ࠬ࠲࡬ࡪࡰ࡮࠸࠱࠻࠱࠲ࠫࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไุ๋่้๊ࠣำๅษอࠤฬาๆษ์ࠪ࠰ࡱ࡯࡮࡬࠷࠯࠹࠶࠷ࠩࠎࠌࠌࡰ࡮ࡴ࡫࠲ࠢࡀࠤࡱ࡯࡮࡬࠲࠮ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨࠏࠍࠍࡱ࡯࡮࡬࠴ࠣࡁࠥࡲࡩ࡯࡭࠳࠯ࠬࠬࡴࡺࡲࡨࡁ࠶ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠳ࠩࡪࡴࡸࡥࡪࡩࡱࡁ࡫ࡧ࡬ࡴࡧࠩࡸࡦ࡭࠽ࠨࠏࠍࠍࡱ࡯࡮࡬࠵ࠣࡁࠥࡲࡩ࡯࡭࠳࠯ࠬࠬࡴࡺࡲࡨࡁ࠶ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁ࡫ࡧ࡬ࡴࡧࠩࡸࡦ࡭࠽ࠨࠏࠍࠍࡱ࡯࡮࡬࠶ࠣࡁࠥࡲࡩ࡯࡭࠳࠯ࠬࠬࡴࡺࡲࡨࡁ࠶ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠳ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧࠎࠌࠌࡰ࡮ࡴ࡫࠶ࠢࡀࠤࡱ࡯࡮࡬࠲࠮ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭ࠍࠋࠋࠥࠦࠧ┥")
	l1ll1ll1ll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸࠭┦")
	l1lll1111l1_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠳ࠩࡪࡴࡸࡥࡪࡩࡱࡁ࡫ࡧ࡬ࡴࡧࠩࡸࡦ࡭࠽ࠨ┧")
	l1lll1l1l1l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠶ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂ࡬ࡡ࡭ࡵࡨࠪࡹࡧࡧ࠾ࠩ┨")
	l1ll1llll1l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩ┩")
	l1ll1lllll1_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪ┪")
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┫"),l111l1_l1_+l11ll1_l1_ (u"ฺ้ࠪ์แศฬࠣวๆ๊วๆࠢ฼ีอ๐ࠧ┬"),l1lll1111l1_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┭"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬี็ใสฮ๋ࠥำๅี็หฯูࠦาสํࠫ┮"),l1lll1l1l1l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┯"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆื้ๅฬะࠠฤใ็ห๊ࠦวอ่ห๎ࠬ┰"),l1ll1llll1l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┱"),l111l1_l1_+l11ll1_l1_ (u"ู่๋ࠩ็วห่ࠢืู้ไศฬࠣหั์ศ๋ࠩ┲"),l1ll1lllll1_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ┳"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭┴"),l11ll1_l1_ (u"ࠬ࠭┵"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┶"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ้ิืࠥษูๆษ็ࠤศฮฬะ์ࠪ┷"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡡ࡭ࡲ࡫ࡥࡧ࡫ࡴࠨ┸"),517)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┹"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ์ืำࠡࠢห่ิࠦวๅว้ฮฬาࠧ┺"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡦࡳࡺࡴࡴࡳࡻࠪ┻"),517)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┼"),l111l1_l1_+l11ll1_l1_ (u"࠭แ่ำึࠤฬ๊ไ฻หࠪ┽"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ┾"),517)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┿"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๋ึูࠠๆื้ๅฬะࠠศๆ฼้้࠭╀"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡩࡨࡲࡷ࡫ࠧ╁"),517)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╂"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็็าีࠣื๋ฯࠠศๆศูิอัࠨ╃"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡷ࡫࡬ࡦࡣࡶࡩࡤࡿࡥࡢࡴࠪ╄"),517)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╅"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠳࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ╆"),l11ll1_l1_ (u"ࠩࠪ╇"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╈"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎วิ็ࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨ╉"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡧ࡬ࡴࠩ╊"),515)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╋"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆ๊สื๊ࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫ╌"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ╍"),514)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ╎"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠹ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠶࡟࠴ࡉࡏࡍࡑࡕࡡࠬ╏"),l11ll1_l1_ (u"ࠫࠬ═"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ║"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫ╒"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ╓"),515)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╔"),l111l1_l1_+l11ll1_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧ╕"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ╖"),514)
	return
def l1ll1llll11_l1_():
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ╗"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭╘"),l11ll1_l1_ (u"࠭ࠧ╙"),l11ll1_l1_ (u"ࠧࠨ╚"),l11ll1_l1_ (u"ࠨࠩ╛"),l11ll1_l1_ (u"ࠩࠪ╜"),l11ll1_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ╝"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ╞"),multi_valued_attributes=None)
	block = l1ll1ll111l_l1_.find(l11ll1_l1_ (u"ࠬࡹࡥ࡭ࡧࡦࡸࠬ╟"),attrs={l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ╠"):l11ll1_l1_ (u"ࠧࡵࡣࡪࠫ╡")})	# <select name=l11ll1_l1_ (u"ࠨࡶࡤ࡫ࠬ╢")>
	options = block.find_all(l11ll1_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠩ╣"))
	for option in options:
		value = option.get(l11ll1_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ╤"))		# or option[l11ll1_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ╥")] l1l1l1ll1l_l1_ it will l1lll1l111l_l1_ if not l1l11llll_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ╦"))
			value = value.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ╧"))
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠨࡷࡽࡵ࡫࠽ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫ╨")+value
		title = title.replace(l11ll1_l1_ (u"ࠨไสส๊ฯࠠࠨ╩"),l11ll1_l1_ (u"ࠩࠪ╪"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╫"),l111l1_l1_+title,l1lllll_l1_,511)
	return
def l1lll11l111_l1_():
	l1ll1ll1ll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸࠭╬")
	l1lll11111l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠶ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࠪࡹࡧࡧ࠾ࠩ╭")
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╮"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆื้ๅฬะࠠฤึัหฺ࠭╯"),l1lll11111l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭╰"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ╱"),l11ll1_l1_ (u"ࠪࠫ╲"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╳"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็็าีࠣวูิวึࠢฦฬัี๊ࠨ╴"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵ࡡ࡭ࡲ࡫ࡥࡧ࡫ࡴࠨ╵"),517)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╶"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ๊ีุࠦๅู้้ࠫ╷"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡱࡥࡹ࡯࡯࡯ࡣ࡯࡭ࡹࡿࠧ╸"),517)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╹"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆํัิࠢࠣฮฬื๊ฯࠢส่๊๐ไศัࠪ╺"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡨࡩࡳࡶ࡫ࡣࡾ࡫ࡡࡳࠩ╻"),517)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╼"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ้ิืࠥࠦสศำําࠥอไ้ใสอࠬ╽"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡦࡨࡥࡹ࡮࡟ࡺࡧࡤࡶࠬ╾"),517)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ╿"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠸ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠵࡟࠴ࡉࡏࡍࡑࡕࡡࠬ▀"),l11ll1_l1_ (u"ࠫࠬ▁"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▂"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫ▃"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ▄"),515)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▅"),l111l1_l1_+l11ll1_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧ▆"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ▇"),514)
	return
def l1ll1ll11ll_l1_(url):
	if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ█") in url: index = 0
	elif l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭▉") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ▊"),url,l11ll1_l1_ (u"ࠧࠨ▋"),l11ll1_l1_ (u"ࠨࠩ▌"),l11ll1_l1_ (u"ࠩࠪ▍"),l11ll1_l1_ (u"ࠪࠫ▎"),l11ll1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ▏"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ▐"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"࠭ࡪࡶ࡯ࡥࡳ࠲ࡺࡨࡦࡣࡷࡩࡷࠦࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠨ░"))
	for block in l1111l1_l1_:
		title = block.find_all(l11ll1_l1_ (u"ࠧࡢࠩ▒"))[index].text
		l1lllll_l1_ = l11l1l_l1_+block.find_all(l11ll1_l1_ (u"ࠨࡣࠪ▓"))[index].get(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ▔"))
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▕"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ▖"))
		if not l1111l1_l1_:
			l1lll1ll111_l1_(l1lllll_l1_)
			return
		else:
			title = title.replace(l11ll1_l1_ (u"่ࠬวว็ฬࠤࠬ▗"),l11ll1_l1_ (u"࠭ࠧ▘"))
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▙"),l111l1_l1_+title,l1lllll_l1_,512)
	PAGINATION(l1ll1ll111l_l1_,511)
	return
def PAGINATION(l1ll1ll111l_l1_,mode):
	block = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ▚"))
	if block:
		l1l1l1ll1_l1_ = block.find_all(l11ll1_l1_ (u"ࠩࡤࠫ▛"))
		l1ll1ll1111_l1_ = block.find_all(l11ll1_l1_ (u"ࠪࡰ࡮࠭▜"))
		l1lll111lll_l1_ = list(zip(l1l1l1ll1_l1_,l1ll1ll1111_l1_))
		l11ll11111_l1_ = -1
		length = len(l1lll111lll_l1_)
		for l1ll111l1_l1_,l1ll1ll1lll_l1_ in l1lll111lll_l1_:
			l11ll11111_l1_ += 1
			l1ll1ll1lll_l1_ = l1ll1ll1lll_l1_[l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࠪ▝")]
			if l11ll1_l1_ (u"ࠬࡻ࡮ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠪ▞") in l1ll1ll1lll_l1_ or l11ll1_l1_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺࠧ▟") in l1ll1ll1lll_l1_: continue
			l1ll1lll1l1_l1_ = l1ll111l1_l1_.text
			l1lllll111_l1_ = l11l1l_l1_+l1ll111l1_l1_.get(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࠬ■"))
			if kodi_version<19:
				l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭□"))
				l1lllll111_l1_ = l1lllll111_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▢"))
			if   l11ll11111_l1_==0: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠪวํ๊้ࠨ▣")
			elif l11ll11111_l1_==1: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ุࠫอศใหࠪ▤")
			elif l11ll11111_l1_==length-2: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"๊ࠬวฮไฬࠫ▥")
			elif l11ll11111_l1_==length-1: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"࠭รฯ์ิอࠬ▦")
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▧"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ▨")+l1ll1lll1l1_l1_,l1lllll111_l1_,mode)
	return
def l1lll1ll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭▩"),url,l11ll1_l1_ (u"ࠪࠫ▪"),l11ll1_l1_ (u"ࠫࠬ▫"),l11ll1_l1_ (u"ࠬ࠭▬"),l11ll1_l1_ (u"࠭ࠧ▭"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠳࠰࠵ࡸࡺࠧ▮"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭▯"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠩࡵࡳࡼ࠭▰"))
	items,first = [],True
	for block in l1111l1_l1_:
		if not block.find(class_=l11ll1_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠳ࡷࡳࡣࡳࡴࡪࡸࠧ▱")): continue
		if first: first = False ; continue
		l1lll11lll1_l1_ = []
		l1ll1l1llll_l1_ = block.find_all(class_=[l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡴࡱࡵࡷ࡭࡯ࡰࠡࡴࡨࡨࠬ▲"),l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡵࡲࡶࡸ࡮ࡩࡱࠢࡳࡹࡷࡶ࡬ࡦࠩ△")])
		for l1ll1lll11l_l1_ in l1ll1l1llll_l1_:
			l1ll1l1lll_l1_ = l1ll1lll11l_l1_.find_all(l11ll1_l1_ (u"࠭࡬ࡪࠩ▴"))[1].text
			if kodi_version<19:
				l1ll1l1lll_l1_ = l1ll1l1lll_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ▵"))
			l1lll11lll1_l1_.append(l1ll1l1lll_l1_)
		if not l11l1l1_l1_(script_name,l11ll1_l1_ (u"ࠨࠩ▶"),l1lll11lll1_l1_,False):
			l111_l1_ = block.find(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭▷")).get(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ▸"))
			title = block.find(l11ll1_l1_ (u"ࠫ࡭࠹ࠧ▹"))
			name = title.find(l11ll1_l1_ (u"ࠬࡧࠧ►")).text
			l1lllll_l1_ = l11l1l_l1_+title.find(l11ll1_l1_ (u"࠭ࡡࠨ▻")).get(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࠬ▼"))
			l1ll1llllll_l1_ = block.find(class_=l11ll1_l1_ (u"ࠨࡰࡲ࠱ࡲࡧࡲࡨ࡫ࡱࠫ▽"))
			l1lll111111_l1_ = block.find(class_=l11ll1_l1_ (u"ࠩ࡯ࡩ࡬࡫࡮ࡥࠩ▾"))
			if l1ll1llllll_l1_: l1ll1llllll_l1_ = l1ll1llllll_l1_.text
			if l1lll111111_l1_: l1lll111111_l1_ = l1lll111111_l1_.text
			if kodi_version<19:
				l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▿"))
				name = name.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ◀"))
				l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ◁"))
				if l1ll1llllll_l1_: l1ll1llllll_l1_ = l1ll1llllll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ◂"))
			l1ll1ll1l11_l1_ = {}
			if l1lll111111_l1_: l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡸ࠭◃")] = l1lll111111_l1_
			if l1ll1llllll_l1_:
				l1ll1llllll_l1_ = l1ll1llllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ◄"),l11ll1_l1_ (u"ࠩࠣ࠲࠳ࠦࠧ◅"))
				l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠪࡴࡱࡵࡴࠨ◆")] = l1ll1llllll_l1_.replace(l11ll1_l1_ (u"ࠫ࠳࠴࠮ศไิวࠥอไๆิํำࠬ◇"),l11ll1_l1_ (u"ࠬ࠭◈"))
			if l11ll1_l1_ (u"࠭࠯ࡸࡱࡵ࡯࠴࠭◉") in l1lllll_l1_:
				#name = l11ll1_l1_ (u"ࠧษฯฮࠤ฾์ࠠࠨ◊")+name
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ○"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"ࠩࠪ◌"),name,l11ll1_l1_ (u"ࠪࠫ◍"),l1ll1ll1l11_l1_)
			elif l11ll1_l1_ (u"ࠫ࠴ࡶࡥࡳࡵࡲࡲ࠴࠭◎") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ●"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"࠭ࠧ◐"),name,l11ll1_l1_ (u"ࠧࠨ◑"),l1ll1ll1l11_l1_)
	PAGINATION(l1ll1ll111l_l1_,512)
	return
def l1lll1l1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ◒"),url,l11ll1_l1_ (u"ࠩࠪ◓"),l11ll1_l1_ (u"ࠪࠫ◔"),l11ll1_l1_ (u"ࠫࠬ◕"),l11ll1_l1_ (u"ࠬ࠭◖"),l11ll1_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠳࠯࠴ࡷࡹ࠭◗"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ◘"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(l11ll1_l1_ (u"ࠨ࡮࡬ࠫ◙"))
	names,items = [],[]
	for block in l1111l1_l1_:
		if not block.find(class_=l11ll1_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠲ࡽࡲࡢࡲࡳࡩࡷ࠭◚")): continue
		if not block.find(class_=[l11ll1_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠬ◛"),l11ll1_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩࠦࡴࡦࡺࡷ࠱ࡨ࡫࡮ࡵࡧࡵࠫ◜")]): continue
		if block.find(class_=l11ll1_l1_ (u"ࠬ࡮ࡩࡥࡧࠪ◝")): continue
		title = block.find(class_=[l11ll1_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠨ◞"),l11ll1_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠢࡷࡩࡽࡺ࠭ࡤࡧࡱࡸࡪࡸࠧ◟")])
		name = title.find(l11ll1_l1_ (u"ࠨࡣࠪ◠")).text
		if name in names: continue
		names.append(name)
		l1lllll_l1_ = l11l1l_l1_+title.find(l11ll1_l1_ (u"ࠩࡤࠫ◡")).get(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ◢"))
		if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡽ࡯ࡳ࡭࠲ࠫ◣") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ◤")).get(l11ll1_l1_ (u"࠭ࡳࡳࡥࠪ◥"))
		elif l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ◦") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠬ◧")).get(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ◨"))
		elif l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ◩") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠨ◪")).get(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ◫"))
		else: l111_l1_ = block.find(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠪ◬")).get(l11ll1_l1_ (u"ࠧࡴࡴࡦࠫ◭"))
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭◮"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ◯"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ◰"))
		name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭◱"))
		items.append((name,l1lllll_l1_,l111_l1_))
	if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ◲") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1lllll_l1_,l111_l1_ in items:
		if l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ◳") in url: addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭◴"),l111l1_l1_+name,l1lllll_l1_,522,l111_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ◵") in url: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◶"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"ࠪࠫ◷"),name)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◸"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"ࠬ࠭◹"),name)
	return
def l1lll111ll1_l1_(text):
	text = text.replace(l11ll1_l1_ (u"࠭วๅว฼่ฬ์ࠧ◺"),l11ll1_l1_ (u"ࠧࠨ◻")).replace(l11ll1_l1_ (u"ࠨๆไ๎้๋ࠧ◼"),l11ll1_l1_ (u"ࠩࠪ◽")).replace(l11ll1_l1_ (u"ࠪห้ืำๆ์ࠪ◾"),l11ll1_l1_ (u"ࠫࠬ◿"))
	text = text.replace(l11ll1_l1_ (u"ࠬหูๅษ้ࠫ☀"),l11ll1_l1_ (u"࠭ࠧ☁")).replace(l11ll1_l1_ (u"ࠧโ์็้ࠬ☂"),l11ll1_l1_ (u"ࠨࠩ☃")).replace(l11ll1_l1_ (u"ࠩส่อื่ๆ๊ࠪ☄"),l11ll1_l1_ (u"ࠪࠫ★"))
	text = text.replace(l11ll1_l1_ (u"ࠫฬ๊สี๊ํๆ๏࠭☆"),l11ll1_l1_ (u"ࠬ࠭☇")).replace(l11ll1_l1_ (u"࠭ไๆี็ื้࠭☈"),l11ll1_l1_ (u"ࠧࠨ☉")).replace(l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ☊"),l11ll1_l1_ (u"ࠩࠪ☋"))
	text = text.replace(l11ll1_l1_ (u"ࠪ࠾ࠬ☌"),l11ll1_l1_ (u"ࠫࠬ☍")).replace(l11ll1_l1_ (u"ࠬ࠯ࠧ☎"),l11ll1_l1_ (u"࠭ࠧ☏")).replace(l11ll1_l1_ (u"ࠧࠩࠩ☐"),l11ll1_l1_ (u"ࠨࠩ☑")).replace(l11ll1_l1_ (u"ࠩ࠯ࠫ☒"),l11ll1_l1_ (u"ࠪࠫ☓"))
	text = text.replace(l11ll1_l1_ (u"ࠫࡤ࠭☔"),l11ll1_l1_ (u"ࠬ࠭☕")).replace(l11ll1_l1_ (u"࠭࠻ࠨ☖"),l11ll1_l1_ (u"ࠧࠨ☗")).replace(l11ll1_l1_ (u"ࠨ࠯ࠪ☘"),l11ll1_l1_ (u"ࠩࠪ☙")).replace(l11ll1_l1_ (u"ࠪ࠲ࠬ☚"),l11ll1_l1_ (u"ࠫࠬ☛"))
	text = text.replace(l11ll1_l1_ (u"ࠬࡢࠧࠨ☜"),l11ll1_l1_ (u"࠭ࠧ☝")).replace(l11ll1_l1_ (u"ࠧ࡝ࠤࠪ☞"),l11ll1_l1_ (u"ࠨࠩ☟"))
	text = text.replace(l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ☠"),l11ll1_l1_ (u"ࠪࠤࠬ☡")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ☢"),l11ll1_l1_ (u"ࠬࠦࠧ☣")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ☤"),l11ll1_l1_ (u"ࠧࠡࠩ☥"))
	text = text.strip(l11ll1_l1_ (u"ࠨࠢࠪ☦"))
	l1lll1l1l11_l1_ = text.count(l11ll1_l1_ (u"ࠩࠣࠫ☧"))+1
	if l1lll1l1l11_l1_==1:
		l1ll1lll111_l1_(text)
		return
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ☨"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࠤ่๊ๅศฬ่้ࠣฮอฬࠢࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ☩"),l11ll1_l1_ (u"ࠬ࠭☪"),9999)
	l1lll111l11_l1_ = text.split(l11ll1_l1_ (u"࠭ࠠࠨ☫"))
	l1lll1l11ll_l1_ = pow(2,l1lll1l1l11_l1_)
	l1lll11l1ll_l1_ = []
	def l1lll1111ll_l1_(a,b):
		if a==l11ll1_l1_ (u"ࠧ࠲ࠩ☬"): return b
		return l11ll1_l1_ (u"ࠨࠩ☭")
	for l11ll11111_l1_ in range(l1lll1l11ll_l1_,0,-1):
		l1lll11l1l1_l1_ = list(l1lll1l1l11_l1_*l11ll1_l1_ (u"ࠩ࠳ࠫ☮")+bin(l11ll11111_l1_)[2:])[-l1lll1l1l11_l1_:]
		l1lll11l1l1_l1_ = reversed(l1lll11l1l1_l1_)
		result = map(l1lll1111ll_l1_,l1lll11l1l1_l1_,l1lll111l11_l1_)
		title = l11ll1_l1_ (u"ࠪࠤࠬ☯").join(filter(None,result))
		if kodi_version<19: l1lll1l11_l1_ = title.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ☰"))
		else: l1lll1l11_l1_ = title
		if len(l1lll1l11_l1_)>2 and title not in l1lll11l1ll_l1_:
			l1lll11l1ll_l1_.append(title)
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☱"),l111l1_l1_+title,l11ll1_l1_ (u"࠭ࠧ☲"),523,l11ll1_l1_ (u"ࠧࠨ☳"),l11ll1_l1_ (u"ࠨࠩ☴"),title)
	return
def l1ll1lll111_l1_(l1lll1l11l1_l1_):
	if kodi_version<19:
		l1lll1l11l1_l1_ = l1lll1l11l1_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ☵"))
		import arabic_reshaper
		l1lll1l11l1_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1lll1l11l1_l1_)
		l1lll1l11l1_l1_ = bidi.algorithm.get_display(l1lll1l11l1_l1_)
	import l1lll11ll1l_l1_
	l1lll1l11l1_l1_ = OPEN_KEYBOARD(default=l1lll1l11l1_l1_)
	l1lll11ll1l_l1_.SEARCH(l1lll1l11l1_l1_)
	return
def l1lll11llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ☶"),url,l11ll1_l1_ (u"ࠫࠬ☷"),l11ll1_l1_ (u"ࠬ࠭☸"),l11ll1_l1_ (u"࠭ࠧ☹"),l11ll1_l1_ (u"ࠧࠨ☺"),l11ll1_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡍࡓࡊࡅ࡙ࡇࡖࡣࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ☻"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ☼"),multi_valued_attributes=None)
	block = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠮ࡵࡨࡴࡦࡸࡡࡵࡱࡵࠤࡱ࡯ࡳࡵ࠯ࡷ࡭ࡹࡲࡥࠨ☽"))
	l11lll_l1_ = block.find_all(l11ll1_l1_ (u"ࠫࡦ࠭☾"))
	items = []
	for title in l11lll_l1_:
		name = title.text
		l1lllll_l1_ = l11l1l_l1_+title.get(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ☿"))
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♀"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♁"))
		if l11ll1_l1_ (u"ࠨࠥࠪ♂") not in l1lllll_l1_: items.append((name,l1lllll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1lllll_l1_ = item
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♃"),l111l1_l1_+name,l1lllll_l1_,518)
	return
def l1lll1l1111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ♄"),url,l11ll1_l1_ (u"ࠫࠬ♅"),l11ll1_l1_ (u"ࠬ࠭♆"),l11ll1_l1_ (u"࠭ࠧ♇"),l11ll1_l1_ (u"ࠧࠨ♈"),l11ll1_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡍࡓࡊࡅ࡙ࡇࡖࡣ࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ♉"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ♊"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠪࡩࡽࡶࡡ࡯ࡦࠪ♋")).find_all(l11ll1_l1_ (u"ࠫࡹࡸࠧ♌"))
	for block in l1111l1_l1_:
		l1lll111l1l_l1_ = block.find_all(l11ll1_l1_ (u"ࠬࡧࠧ♍"))
		if not l1lll111l1l_l1_: continue
		l111_l1_ = block.find(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠪ♎")).get(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ♏"))
		name = l1lll111l1l_l1_[1].text
		l1lllll_l1_ = l11l1l_l1_+l1lll111l1l_l1_[1].get(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫࠭♐"))
		l1lll111111_l1_ = block.find(class_=l11ll1_l1_ (u"ࠩ࡯ࡩ࡬࡫࡮ࡥࠩ♑"))
		if l1lll111111_l1_: l1lll111111_l1_ = l1lll111111_l1_.text
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♒"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♓"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♔"))
		l1ll1ll1l11_l1_ = {}
		if l1lll111111_l1_: l1ll1ll1l11_l1_[l11ll1_l1_ (u"࠭ࡳࡵࡣࡵࡷࠬ♕")] = l1lll111111_l1_
		if l11ll1_l1_ (u"ࠧ࠰ࡹࡲࡶࡰ࠵ࠧ♖") in l1lllll_l1_:
			#name = l11ll1_l1_ (u"ࠨสะฯࠥ฿ๆࠡࠩ♗")+name
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♘"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"ࠪࠫ♙"),name,l11ll1_l1_ (u"ࠫࠬ♚"),l1ll1ll1l11_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ♛") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♜"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"ࠧࠨ♝"),name,l11ll1_l1_ (u"ࠨࠩ♞"),l1ll1ll1l11_l1_)
	PAGINATION(l1ll1ll111l_l1_,518)
	return
def l1lll11l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭♟"),url,l11ll1_l1_ (u"ࠪࠫ♠"),l11ll1_l1_ (u"ࠫࠬ♡"),l11ll1_l1_ (u"ࠬ࠭♢"),l11ll1_l1_ (u"࠭ࠧ♣"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯࡙ࡍࡉࡋࡏࡔࡡࡏࡍࡘ࡚ࡓ࠮࠳ࡶࡸࠬ♤"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭♥"),multi_valued_attributes=None)
	l11lll_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰ࠰ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࡱ࡯࡮ࡦࠩ♦"))
	l1l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠪࡦࡺࡺࡴࡰࡰࠣ࡫ࡷ࡫ࡥ࡯ࠢࡶࡱࡦࡲ࡬ࠡࡴ࡬࡫࡭ࡺࠧ♧"))
	items = zip(l11lll_l1_,l1l1_l1_)
	for title,l1lllll_l1_ in items:
		title = title.text
		l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_.get(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ♨"))
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♩"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♪"))
		title = title.replace(l11ll1_l1_ (u"ࠧࠡࠢࠣࠤࠬ♫"),l11ll1_l1_ (u"ࠨࠢࠪ♬")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭♭"),l11ll1_l1_ (u"ࠪࠤࠬ♮")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ♯"),l11ll1_l1_ (u"ࠬࠦࠧ♰"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♱"),l111l1_l1_+title,l1lllll_l1_,521)
	return
def l1ll1ll11l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ♲"),url,l11ll1_l1_ (u"ࠨࠩ♳"),l11ll1_l1_ (u"ࠩࠪ♴"),l11ll1_l1_ (u"ࠪࠫ♵"),l11ll1_l1_ (u"ࠫࠬ♶"),l11ll1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡗࡋࡇࡉࡔ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ♷"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ♸"),multi_valued_attributes=None)
	l1lll1ll11l_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠧ࡭ࡣࡵ࡫ࡪ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠸ࠥࡳࡥࡥ࡫ࡸࡱ࠲ࡨ࡬ࡰࡥ࡮࠱࡬ࡸࡩࡥ࠯࠷ࠤࡸࡳࡡ࡭࡮࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠳ࠩ♹"))
	l1111l1_l1_ = l1lll1ll11l_l1_.find_all(l11ll1_l1_ (u"ࠨ࡮࡬ࠫ♺"))
	for block in l1111l1_l1_:
		title = block.find(class_=l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ♻")).text
		l1lllll_l1_ = l11l1l_l1_+block.find(l11ll1_l1_ (u"ࠪࡥࠬ♼")).get(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ♽"))
		l111_l1_ = block.find(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ♾")).get(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ♿"))
		l1l11ll1l_l1_ = block.find(class_=l11ll1_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ⚀")).text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚁"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚂"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚃"))
			l1l11ll1l_l1_ = l1l11ll1l_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚄"))
		l1l11ll1l_l1_ = l1l11ll1l_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ⚅"),l11ll1_l1_ (u"࠭ࠧ⚆")).strip(l11ll1_l1_ (u"ࠧࠡࠩ⚇"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⚈"),l111l1_l1_+title,l1lllll_l1_,522,l111_l1_,l1l11ll1l_l1_)
	PAGINATION(l1ll1ll111l_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⚉"),url,l11ll1_l1_ (u"ࠪࠫ⚊"),l11ll1_l1_ (u"ࠫࠬ⚋"),l11ll1_l1_ (u"ࠬ࠭⚌"),l11ll1_l1_ (u"࠭ࠧ⚍"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⚎"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⚏"),multi_valued_attributes=None)
	l1lllll_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠩࡩࡰࡪࡾ࠭ࡷ࡫ࡧࡩࡴ࠭⚐")).find(l11ll1_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪ⚑")).get(l11ll1_l1_ (u"ࠫࡸࡸࡣࠨ⚒"))
	if kodi_version<19: l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚓"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⚔"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⚕"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⚖"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⚗"),l11ll1_l1_ (u"ࠪࠩ࠷࠶ࠧ⚘"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡅࡱ࠾ࠩ⚙")+search
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⚚"),url,l11ll1_l1_ (u"࠭ࠧ⚛"),l11ll1_l1_ (u"ࠧࠨ⚜"),l11ll1_l1_ (u"ࠨࠩ⚝"),l11ll1_l1_ (u"ࠩࠪ⚞"),l11ll1_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ⚟"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⚠"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡴࡪࡶ࡯ࡩࠥࡲࡥࡧࡶࠪ⚡"))
	for block in l1111l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚢"))
		title = title.split(l11ll1_l1_ (u"ࠧࠩࠩ⚣"),1)[0].strip(l11ll1_l1_ (u"ࠨࠢࠪ⚤"))
		if   l11ll1_l1_ (u"ࠩฦ฽๊อไࠨ⚥") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⚦"),l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡽ࡯ࡳ࡭࠲ࠫ⚧"))
		elif l11ll1_l1_ (u"ࠬษิฯษุࠫ⚨") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⚩"),l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⚪"))
		#elif l11ll1_l1_ (u"ࠨละำฬัࠧ⚫") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⚬"),l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡪࡼࡥ࡯ࡶ࠲ࠫ⚭"))
		#elif l11ll1_l1_ (u"๊ࠫํัอษ้หฯ࠭⚮") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⚯"),l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡧࡧࡶࡸ࡮ࡼࡡ࡭࠱ࠪ⚰"))
		elif l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠩ⚱") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⚲"),l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ⚳"))
		#elif l11ll1_l1_ (u"ࠪวำฮวาࠩ⚴") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⚵"),l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡴࡰࡲ࡬ࡧ࠴࠭⚶"))
		else: continue
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⚷"),l111l1_l1_+title,l1lllll_l1_,513)
	return
# ===========================================
#     l1lll1lll1_l1_ l1lll1ll1l_l1_ l1lll1llll_l1_
# ===========================================
def l1ll1ll1l1l_l1_(url,text):
	global l1l11l11_l1_,l1ll1111_l1_
	if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ⚸") in url:
		l1l11l11_l1_ = [l11ll1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ⚹"),l11ll1_l1_ (u"ࠩࡼࡩࡦࡸࠧ⚺"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⚻")]
		l1ll1111_l1_ = [l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⚼"),l11ll1_l1_ (u"ࠬࡿࡥࡢࡴࠪ⚽"),l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⚾")]
	elif l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ⚿") in url:
		l1l11l11_l1_ = [l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⛀"),l11ll1_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ⛁"),l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ⛂")]
		l1ll1111_l1_ = [l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⛃"),l11ll1_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭⛄"),l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ⛅")]
	l1ll1lll_l1_(url,text)
	return
def l1lllll1ll_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⛆"))[0]
	#l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ⛇"))
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⛈"),url,l11ll1_l1_ (u"ࠪࠫ⛉"),l11ll1_l1_ (u"ࠫࠬ⛊"),l11ll1_l1_ (u"ࠬ࠭⛋"),l11ll1_l1_ (u"࠭ࠧ⛌"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ⛍"))
	html = response.content
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࠦࡡࡤࡶ࡬ࡳࡳࡃࠢ࠰ࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ⛎"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# name + category + options block
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠣࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⛏"),block,re.DOTALL)
	return l1ll1ll1_l1_
def l1llll11l1_l1_(block):
	# value + name
	items = re.findall(l11ll1_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⛐"),block,re.DOTALL)
	return items
def l1llll11ll_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ⛑"),l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ⛒"))
	l1lllll11l_l1_ = url.split(l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⛓"))[0]
	l1llll1l11_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ⛔"))
	#url = url.replace(l1lllll11l_l1_,l1llll1l11_l1_)
	url = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⛕"),l11ll1_l1_ (u"ࠩ࠲ࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠫ࠭⛖"))
	return url
def l11111ll1l_l1_(l1l1ll11_l1_,url):
	l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⛗")) # l1llllll1ll_l1_ be l1lllllllll_l1_
	l11l111_l1_ = url+l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⛘")+l11llll1_l1_
	l11l111_l1_ = l1llll11ll_l1_(l11l111_l1_)
	return l11l111_l1_
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⛙"),l11ll1_l1_ (u"࠭ࠧ⛚"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⛛"),l11ll1_l1_ (u"ࠨࠩ⛜"),filter,url)
	if l11ll1_l1_ (u"ࠩࡂࠫ⛝") in url: url = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⛞"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ⛟"),1)
	if filter==l11ll1_l1_ (u"ࠬ࠭⛠"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"࠭ࠧ⛡"),l11ll1_l1_ (u"ࠧࠨ⛢")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ⛣"))
	if type==l11ll1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⛤"):
		if l1l11l11_l1_[0]+l11ll1_l1_ (u"ࠪࡁࠬ⛥") not in l1l111l1_l1_: category = l1l11l11_l1_[0]
		for i in range(len(l1l11l11_l1_[0:-1])):
			if l1l11l11_l1_[i]+l11ll1_l1_ (u"ࠫࡂ࠭⛦") in l1l111l1_l1_: category = l1l11l11_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠧ⛧")+category+l11ll1_l1_ (u"࠭࠽࠱ࠩ⛨")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠧࠧࠩ⛩")+category+l11ll1_l1_ (u"ࠨ࠿࠳ࠫ⛪")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠫ⛫"))+l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ⛬")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠫࠫ࠭⛭"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⛮")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⛯")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ⛰"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⛱")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠩࠪ⛲"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⛳")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠫࠬ⛴"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⛵")+l1l1111l_l1_
		l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛶"),l111l1_l1_+l11ll1_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ⛷"),l111lll_l1_,511)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛸"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ⛹")+l11ll11l_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ⛺"),l111lll_l1_,511)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⛻"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⛼"),l11ll1_l1_ (u"࠭ࠧ⛽"),9999)
	l1ll1ll1_l1_ = l1lllll1ll_l1_(url)
	dict = {}
	for name,l1ll1l11_l1_,block in l1ll1ll1_l1_:
		name = name.replace(l11ll1_l1_ (u"ࠧ࠮࠯ࠪ⛾"),l11ll1_l1_ (u"ࠨࠩ⛿"))
		items = l1llll11l1_l1_(block)
		if l11ll1_l1_ (u"ࠩࡀࠫ✀") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭✁"):
			if l1ll1l11_l1_ not in l1l11l11_l1_: continue
			if category!=l1ll1l11_l1_: continue
			elif len(items)<2:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]:
					url = l1llll11ll_l1_(url)
					l1lll1ll111_l1_(url)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ✂")+l1l11ll1_l1_)
				return
			else:
				l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✃"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾࠭✄"),l111lll_l1_,511)
				else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✅"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨ✆"),l111lll_l1_,515,l11ll1_l1_ (u"ࠩࠪ✇"),l11ll1_l1_ (u"ࠪࠫ✈"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ✉"):
			if l1ll1l11_l1_ not in l1ll1111_l1_: continue
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠧ✊")+l1ll1l11_l1_+l11ll1_l1_ (u"࠭࠽࠱ࠩ✋")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠧࠧࠩ✌")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿࠳ࠫ✍")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭✎")+l1l1ll11_l1_
			if   name==l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ✏"): name = l11ll1_l1_ (u"ࠫฬ๊ๆ้฻ࠪ✐")
			elif name==l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ✑"): name = l11ll1_l1_ (u"࠭วๅ฻่่ࠬ✒")
			elif name==l11ll1_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ✓"): name = l11ll1_l1_ (u"ࠨษ็่฿ฯࠧ✔")
			elif name==l11ll1_l1_ (u"ࠩࡼࡩࡦࡸࠧ✕"): name = l11ll1_l1_ (u"ࠪหู้ๆสࠩ✖")
			elif name==l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭✗"): name = l11ll1_l1_ (u"ࠬอไๆ๊ึ้ࠬ✘")
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✙"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿࠺ࠡࠩ✚")+name,l111lll_l1_,514,l11ll1_l1_ (u"ࠨࠩ✛"),l11ll1_l1_ (u"ࠩࠪ✜"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ✝"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			if option in l1l11l_l1_: continue
			if l11ll1_l1_ (u"๊ࠫ฻ๆโษอࠤศิั๊ࠩ✞") in option: continue
			if l11ll1_l1_ (u"ࠬอไไๆࠪ✟") in option: continue
			if l11ll1_l1_ (u"࠭วๅๆ฽อࠬ✠") in option: continue
			option = option.replace(l11ll1_l1_ (u"ࠧใษษ้ฮࠦࠧ✡"),l11ll1_l1_ (u"ࠨࠩ✢"))
			if   name==l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ✣"): name = l11ll1_l1_ (u"ࠪห้์ฺ่ࠩ✤")
			elif name==l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭✥"): name = l11ll1_l1_ (u"ࠬอไฺ็็ࠫ✦")
			elif name==l11ll1_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ✧"): name = l11ll1_l1_ (u"ࠧศๆ็฾ฮ࠭✨")
			elif name==l11ll1_l1_ (u"ࠨࡻࡨࡥࡷ࠭✩"): name = l11ll1_l1_ (u"ࠩสุ่์ษࠨ✪")
			elif name==l11ll1_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ✫"): name = l11ll1_l1_ (u"ࠫฬ๊ๅ้ี่ࠫ✬")
			#if l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ✭") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ✮"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩ✯")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ✰")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠩࠩࠫ✱")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁࠬ✲")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ✳")+l1l1ll11_l1_
			if name: title = option+l11ll1_l1_ (u"ࠬࠦ࠺ࠨ✴")+name
			else: title = option   #+dict[l1ll1l11_l1_][l11ll1_l1_ (u"࠭࠰ࠨ✵")]
			if type==l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ✶"): addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✷"),l111l1_l1_+title,url,514,l11ll1_l1_ (u"ࠩࠪ✸"),l11ll1_l1_ (u"ࠪࠫ✹"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭✺"))
			elif type==l11ll1_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ✻") and l1l11l11_l1_[-2]+l11ll1_l1_ (u"࠭࠽ࠨ✼") in l1l111l1_l1_:
				l11l111_l1_ = l11111ll1l_l1_(l1l1ll11_l1_,url)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✽"),l111l1_l1_+title,l11l111_l1_,511)
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✾"),l111l1_l1_+title,url,515,l11ll1_l1_ (u"ࠩࠪ✿"),l11ll1_l1_ (u"ࠪࠫ❀"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ❁"),l11ll1_l1_ (u"ࠬ࠭❂"),filters,l11ll1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧ❃"))
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ❄")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ❅")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ❆")			all l1l1l1l1_l1_ & l1llll1lll_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠪࡁࠫ࠭❇"),l11ll1_l1_ (u"ࠫࡂ࠶ࠦࠨ❈"))
	filters = filters.strip(l11ll1_l1_ (u"ࠬࠬࠧ❉"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"࠭࠽ࠨ❊") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠧࠧࠩ❋"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠨ࠿ࠪ❌"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"ࠩࠪ❍")
	for key in l1ll1111_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠪ࠴ࠬ❎")
		if l11ll1_l1_ (u"ࠫࠪ࠭❏") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ❐") and value!=l11ll1_l1_ (u"࠭࠰ࠨ❑"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ❒")+value
		elif mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ❓") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫ❔"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠪࠬ❕")+key+l11ll1_l1_ (u"ࠫࡂ࠭❖")+value
		elif mode==l11ll1_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ❗"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ❘")+key+l11ll1_l1_ (u"ࠧ࠾ࠩ❙")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ❚"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠫ❛"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠪࡁ࠵࠭❜"),l11ll1_l1_ (u"ࠫࡂ࠭❝"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭❞"),l11ll1_l1_ (u"࠭ࠧ❟"),filters,l11ll1_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠸࠲ࠨ❠"))
	return l1ll11l1_l1_
l1l11l11_l1_ = []
l1ll1111_l1_ = []
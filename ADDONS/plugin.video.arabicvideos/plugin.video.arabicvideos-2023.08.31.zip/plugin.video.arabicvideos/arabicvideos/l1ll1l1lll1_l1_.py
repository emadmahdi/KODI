# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ❡")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨ❢")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ❣"),l11ll1_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ❤")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l11111_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l1llll1_l1_(url,text)
	elif mode==624: results = l1l111_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1ll1l_l1_(l11l1l_l1_,l11ll1_l1_ (u"ࠬ࡬ࡡࡣࡴࡤ࡯ࡦ࠭❥"),l11ll1_l1_ (u"࠭แษำๆอࠥࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬ❦"),l11ll1_l1_ (u"ࠧ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠧ❧"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❨"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ❩"),l11ll1_l1_ (u"ࠪࠫ❪"),629,l11ll1_l1_ (u"ࠫࠬ❫"),l11ll1_l1_ (u"ࠬ࠭❬"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ❭"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ❮"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ❯"),l11ll1_l1_ (u"ࠩࠪ❰"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❱"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭❲")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭❳"),l1ll111_l1_,621,l11ll1_l1_ (u"࠭ࠧ❴"),l11ll1_l1_ (u"ࠧࠨ❵"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ❶"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❷"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❸")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ❹"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠬ࠭❺"),l11ll1_l1_ (u"࠭ࠧ❻"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭❼"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❽"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ❾")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ❿"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠫࠬ➀"),l11ll1_l1_ (u"ࠬ࠭➁"),l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ➂"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➃"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ➄")+l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭➅"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠪࠫ➆"),l11ll1_l1_ (u"ࠫࠬ➇"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ➈"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➉"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➊"),l11ll1_l1_ (u"ࠨࠩ➋"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ➌"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ➍"),l11ll1_l1_ (u"ࠫࠬ➎"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ➏"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส๐ฬศัࠣ฽๋๎ว็ࠢส่๊๎โฺࠢฦ์ࠥะีๆ์่ࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠩ➐"))
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ➑"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➒"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ➓")+l111l1_l1_+title,l1lllll_l1_,624)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ➔"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ➕"),l11ll1_l1_ (u"ࠬ࠭➖"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ➗"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ➘"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠨࠩ➙"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ➚"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➛"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭➜")+l111l1_l1_+title,l1lllll_l1_,624)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ➝"),url,l11ll1_l1_ (u"࠭ࠧ➞"),l11ll1_l1_ (u"ࠧࠨ➟"),l11ll1_l1_ (u"ࠨࠩ➠"),l11ll1_l1_ (u"ࠩࠪ➡"),l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ➢"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ➣"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭➤"),l11ll1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ➥"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ➦"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠨࠩ➧"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ➨"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➩"),l11ll1_l1_ (u"ࠫࠬ➪"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ➫"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠩ➬")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➭"),l111l1_l1_+title,l1lllll_l1_,621)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ➮"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ➯"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ➰"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ➱"),l11ll1_l1_ (u"ࠬ࠭➲"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➳"),l111l1_l1_+title,l1lllll_l1_,621)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠧࠨ➴")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ➵"),l11ll1_l1_ (u"ࠩࠪ➶"),request,url)
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ➷"):
		url,search = url.split(l11ll1_l1_ (u"ࠫࡄ࠭➸"),1)
		data = l11ll1_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ➹")+search
		headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ➺"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ➻")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭➼"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ➽"),l11ll1_l1_ (u"ࠪࠫ➾"),l11ll1_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ➿"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⟀"),url,l11ll1_l1_ (u"࠭ࠧ⟁"),l11ll1_l1_ (u"ࠧࠨ⟂"),l11ll1_l1_ (u"ࠨࠩ⟃"),l11ll1_l1_ (u"ࠩࠪ⟄"),l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⟅"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠫࠬ⟆"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⟇"))
	if request==l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ⟈"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⟉"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩ⟊"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ⟋"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⟌"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⟍"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⟎"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ⟏"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⟐"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ⟑"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ⟒"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⟓"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠫࠬ⟔"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⟕"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⟖"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧ⟗"),l11ll1_l1_ (u"ࠨใํ่๊࠭⟘"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨ⟙"),l11ll1_l1_ (u"ࠪ็้๐ศࠨ⟚"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪ⟛"),l11ll1_l1_ (u"ࠬํฯศใࠪ⟜"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭⟝"),l11ll1_l1_ (u"ฺࠧำูࠫ⟞"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨ⟟"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨ⟠"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪ⟡")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭⟢"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⟣") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ⟤")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ⟥"))
		#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭⟦") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ⟧")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ⟨"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭⟩"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⟪"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⟫"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⟬"):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⟭"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⟮") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟯"),l111l1_l1_+title,l1lllll_l1_,623,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⟰") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟱"),l111l1_l1_+title,l1lllll_l1_,621,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟲"),l111l1_l1_+title,l1lllll_l1_,623,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⟳"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ⟴")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⟵"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⟶"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭⟷"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ⟸")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ⟹"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟺"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ⟻")+title,l1lllll_l1_,621)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⟼"),l11ll1_l1_ (u"ࠪࠫ⟽"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ⟾"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⟿"),url,l11ll1_l1_ (u"࠭ࠧ⠀"),l11ll1_l1_ (u"ࠧࠨ⠁"),l11ll1_l1_ (u"ࠨࠩ⠂"),l11ll1_l1_ (u"ࠩࠪ⠃"),l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⠄"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ⠅"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⠆"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"࠭ࠧ⠇")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡲࡲࡨࡲࡩࡤ࡭ࡀࠦࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ࠭ࠧ⠈"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠨࠥࠪ⠉"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⠊"),l111l1_l1_+title,url,623,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ⠋"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩ⠌")+l1l1l_l1_+l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⠍"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠧࠨࡪࡵࡩ࡫ࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ࠧࠨ⠎"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠏"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ⠐")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ⠑"))
			title = title.replace(l11ll1_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨ⠒"),l11ll1_l1_ (u"ࠫࠥ࠭⠓"))
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⠔"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ⠕"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ⠖") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ⠗")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ⠘"))
		#		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⠙"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ⠚"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⠛"),url,l11ll1_l1_ (u"࠭ࠧ⠜"),l11ll1_l1_ (u"ࠧࠨ⠝"),l11ll1_l1_ (u"ࠨࠩ⠞"),l11ll1_l1_ (u"ࠩࠪ⠟"),l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⠠"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⠡"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	post = l1lllll_l1_.split(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶࡀࠫ⠢"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⠣"))
	post = EVAL(l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⠤"),post)
	l1l1_l1_ = post[l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࡴࠩ⠥")]
	l11lll_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l1111l_l1_ = zip(l11lll_l1_,l1l1_l1_)
	for title,l1lllll_l1_ in l1111l_l1_:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⠦")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⠧")
		l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࠥ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡥࡳࡪࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠭ࠫ࡭࡫ࡱ࡯ࠏࠏࡨࡢࡵ࡫ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡸࡶ࡬ࡪࡶࠫࠫ࡭ࡧࡳࡩ࠿ࠪ࠭ࡠ࠷࡝ࠋࠋࡳࡥࡷࡺࡳࠡ࠿ࠣ࡬ࡦࡹࡨ࠯ࡵࡳࡰ࡮ࡺࠨࠨࡡࡢࠫ࠮ࠐࠉ࡯ࡧࡺࡣࡵࡧࡲࡵࡵࠣࡁࠥࡡ࡝ࠋࠋࡩࡳࡷࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡱࡣࡵࡸࡸࡀࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌࡴࡦࡸࡴࠡ࠿ࠣࡦࡦࡹࡥ࠷࠶࠱ࡦ࠻࠺ࡤࡦࡥࡲࡨࡪ࠮ࡰࡢࡴࡷ࠯ࠬࡃࠧࠪࠌࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡱࡣࡵࡸࠥࡃࠠࡱࡣࡵࡸ࠳ࡪࡥࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊࠋࡱࡩࡼࡥࡰࡢࡴࡷࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡶࡡࡳࡶࠬࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠏࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠࠨࡀࠪ࠲࡯ࡵࡩ࡯ࠪࡱࡩࡼࡥࡰࡢࡴࡷࡷ࠮ࠐࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡ࡮࡬ࡲࡰࡹ࠮ࡴࡲ࡯࡭ࡹࡲࡩ࡯ࡧࡶࠬ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠴ࠣ࡭ࡳࠦࡺࡻࡼ࠽ࠎࠎࠏࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠵࠲ࡸࡶ࡬ࡪࡶࠫࠫࠥࡃ࠾ࠡࠩࠬࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡺࡥࡹࡩࡨࠨࠌࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ⠨")
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⠩"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⠪"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⠫"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⠬"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⠭"),l11ll1_l1_ (u"ࠪ࠯ࠬ⠮"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ⠯")+search
	l1ll111_l1_,l111lll_l1_,l1ll11111_l1_ = l1ll1l1ll1l_l1_(url,l11ll1_l1_ (u"ࠬ࡬ࡡࡣࡴࡤ࡯ࡦ࠭⠰"),l11ll1_l1_ (u"࠭แษำๆอࠥࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬ⠱"),l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࠪ⠲"))
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⠳"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭⠴")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ⠵"))
	return
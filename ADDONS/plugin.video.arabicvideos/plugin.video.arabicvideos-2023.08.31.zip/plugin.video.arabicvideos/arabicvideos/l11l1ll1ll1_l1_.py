# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ朮")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ术")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠬ࠭朰")
#headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ朱"):l11ll1_l1_ (u"ࠧࠨ朲")}
l1ll1ll1ll1l1_l1_ = 0
def MAIN(mode,url,text,type,l1l1111_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1ll1ll111_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11111_l1_(url,l1l1111_l1_,text)
	elif mode==145: results = l1lll111111l1_l1_(url,l1l1111_l1_)
	elif mode==147: results = l1ll1lll1lll1_l1_()
	elif mode==148: results = l1ll1llll1111_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ朳"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅหห๋ษࠨ朴"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ朵"),144)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朶"),l111l1_l1_+l11ll1_l1_ (u"ฺࠬฮึࠩ朷"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ朸"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ朹"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็๋ๆ฾࠭机"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ朻"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ朼"),l111l1_l1_+l11ll1_l1_ (u"ࠫาูวษࠩ朽"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭朾"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭朿"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ฼หอ࠭杀"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ杁"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ杂"),l111l1_l1_+l11ll1_l1_ (u"ࠪหๆ๊วๆࠩ权"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ杄"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ杅"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅฯฬสีฬะࠧ杆"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭杇"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杈"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅู๏ืษࠨ杉"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ杊"),144,l11ll1_l1_ (u"ࠫࠬ杋"),l11ll1_l1_ (u"ࠬ࠭杌"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ杍"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ李"),l111l1_l1_+l11ll1_l1_ (u"ࠨฬุๅา࠭杏"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ材"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ村"),l111l1_l1_+l11ll1_l1_ (u"ࠫึฬ๊ิ์ฬࠫ杒"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠭杓"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭杔"),l111l1_l1_+l11ll1_l1_ (u"ࠧาษษะࠬ杕"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭杖"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ杗"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ杘"),l11ll1_l1_ (u"ࠫࠬ杙"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ杚"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭杛"),l11ll1_l1_ (u"ࠧࠨ杜"),149,l11ll1_l1_ (u"ࠨࠩ杝"),l11ll1_l1_ (u"ࠩࠪ杞"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ束"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ杠"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไาศํื๏ฯࠧ条"),l11l1l_l1_+l11ll1_l1_ (u"࠭ࠧ杢"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杣"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ีฬฬฬสࠩ杤"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ来"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ杦"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊สึใะࠫ杧"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ杨"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭杩"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆๅู๏ืษࠨ杪"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ杫"),144,l11ll1_l1_ (u"ࠩࠪ杬"),l11ll1_l1_ (u"ࠪࠫ杭"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ杮"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ杯"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅฯฬสีฬะ๋๊ࠠอ๎ํฮࠧ杰"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭東"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杲"),l111l1_l1_+l11ll1_l1_ (u"่ࠩาฯอัศฬࠣห้ฮั็ษ่ะࠬ杳"),l11ll1_l1_ (u"ࠪࠫ杴"),290)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ杵"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ杶"),l11ll1_l1_ (u"࠭ࠧ杷"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杸"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ杹"),l11ll1_l1_ (u"ࠩࠪ杺"),147)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ杻"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ杼"),l11ll1_l1_ (u"ࠬ࠭杽"),148)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭松"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ板"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ枀"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ极"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ枂"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ枃"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ构"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ枅"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ枆"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枇"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ枈"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ枉"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ枊"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ枋"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ枌"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ枍"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ枎"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ枏"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ析"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ枑"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ枒"),144)
	return
def l1ll1ll1ll111_l1_(url,name,l111_l1_):
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭枓"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡄࡊࡑࡐ࠿ࠦࠠࠨ枔")+name,url,144,l111_l1_)
	return
def l1ll1lll1lll1_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ枕"))
	return
def l1ll1llll1111_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ枖"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ林"),l11ll1_l1_ (u"ࠫࠬ枘"),l11ll1_l1_ (u"ࠬ࠭枙"),url)
	#url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨ枚")
	#items = re.findall(l11ll1_l1_ (u"ࠧࡷ࠿ࠫ࠲࠯ࡅࠩࠥࠩ枛"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ果")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ枝"))
	#return
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡪ࡯ࡳࡳࡷࡺࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠩࡷࡵࡰ࠮ࠐࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ枞")
	url = url.split(l11ll1_l1_ (u"ࠫࠫ࠭枟"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1lll11ll1_l1_(cc,url,index):
	level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = index.split(l11ll1_l1_ (u"ࠬࡀ࠺ࠨ枠"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ枡"),l11ll1_l1_ (u"ࠧࠨ枢"),index,l11ll1_l1_ (u"ࠨࡈࡌࡖࡘ࡚ࠧ枣")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ枤")+url)
	l1ll1ll1l1l1l_l1_,l1ll1ll1l1lll_l1_ = [],[]
	# l1l111l1l11_l1_ l11l11l11l11_l1_    should be the first item in the l1ll1ll1l1l1l_l1_ list
	if l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ枥") in url: l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝ࠣ枦"))
	# l1l111l1l11_l1_ search l1lll11111l1l_l1_      should be the first item in the l1ll1ll1l1l1l_l1_ list
	if l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ枧") in url: l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠࠦ枨"))
	# main l1l1111_l1_
	if level==l11ll1_l1_ (u"ࠧ࠲ࠩ枩"): l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ枪"))
	# search results
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ枫"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠࠦ枬"))
	# l1ll1llll11l1_l1_ l1ll1lll1ll1l_l1_ & main l1l1111_l1_ l1ll1lll1ll1l_l1_ l1lll11111l1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡧࡱࡸࡷ࡯ࡥࡴࠩࡠࠦ枭"))
	# l1ll1lll11lll_l1_ menu
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟࡞࠷ࡢࡡࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ枮"))
	l1ll1llll1l11_l1_,dd,l1ll1ll11llll_l1_ = l1ll1ll1l11ll_l1_(cc,l11ll1_l1_ (u"࠭ࠧ枯"),l1ll1ll1l1l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ枰"),str(dd))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ枱"),l11ll1_l1_ (u"ࠩࠪ枲"),l11ll1_l1_ (u"ࠪࠫ枳"),str(len(dd)))
	if level==l11ll1_l1_ (u"ࠫ࠶࠭枴") and l1ll1llll1l11_l1_:
		if len(dd)>1 and l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ枵") not in url:
			for zz in range(len(dd)):
				l1ll1ll1lllll_l1_ = str(zz)
				l1ll1ll1l1l1l_l1_ = []
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ架")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ枷"))
				# l1ll1llll11l1_l1_ l1ll1lll1ll1l_l1_
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ枸")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩ࠭࡝ࠣ枹"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡࠢ枺")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠦࡢࠨ枻"))
				succeeded,item,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(dd,l11ll1_l1_ (u"ࠬ࠭枼"),l1ll1ll1l1l1l_l1_)
				if succeeded: l1ll1ll1l1lll_l1_.append([item,url,l11ll1_l1_ (u"࠭࠲࠻࠼ࠪ枽")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ枾")])
				#l1l1l1lll1l1_l1_ = l1ll1llllll1l_l1_(item,url,l11ll1_l1_ (u"ࠨ࠴࠽࠾ࠬ枿")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ柀"))
				#if l1l1l1lll1l1_l1_: l1ll11l1l1_l1_ += 1
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token = l1lll11111ll1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ柁"),l111l1_l1_+title,l1lllll_l1_,144,l11ll1_l1_ (u"ࠫࠬ柂"),l11ll1_l1_ (u"ࠬ࠸࠺࠻ࠩ柃")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭柄"))
				#l1ll11l1l1_l1_ += 1
			# main l1l1111_l1_ l1ll1lll1ll1l_l1_ l1lll11111l1l_l1_
			l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࠨ柅"))
			succeeded,item,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(cc,l11ll1_l1_ (u"ࠨࠩ柆"),l1ll1ll1l1l1l_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ柇"),str(cc))
			if succeeded and l1ll1ll1l1lll_l1_ and l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩ柈") in list(item.keys()):
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ柉")
				l1ll1ll1l1lll_l1_.append([item,l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ柊")])
	return dd,l1ll1llll1l11_l1_,l1ll1ll1l1lll_l1_,l1ll1ll11llll_l1_
def l1ll1ll1l1111_l1_(cc,dd,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ柋"),l11ll1_l1_ (u"ࠧࠨ柌"),index,l11ll1_l1_ (u"ࠨࡕࡈࡇࡔࡔࡄࠨ柍")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ柎")+url)
	level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = index.split(l11ll1_l1_ (u"ࠪ࠾࠿࠭柏"))
	l1ll1ll1l1l1l_l1_,l1ll1lll1l111_l1_ = [],[]
	# search results
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ某"))
	# main l1l1111_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ柑")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ柒"))
	# l11ll11l1l11_l1_ l1ll1lll1ll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞࠵ࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ染"))
	# l1l111l1l11_l1_ search & l11l11l11l11_l1_ & l1lll11111l1l_l1_
	if l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ柔") in url: l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ柕"))
	elif l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ柖") in url: l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ柗"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ柘")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ柙"))
	# l11ll11l1l11_l1_ l11ll11ll1_l1_ & l1ll1lll1ll1l_l1_ filters
	if l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ柚") in url or (l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ柛") in url and l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ柜") not in url):
		l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡࠢ柝")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡧࡧࡨࡨࡋ࡯࡬ࡵࡧࡵࡇ࡭࡯ࡰࡃࡣࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ柞"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ柟")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ柠"))
	# l1ll1llll11l1_l1_ search
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞ࠦ柡")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ柢"))
	# main l1l1111_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠࠨ柣")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ柤"))
	# l1l111l1l11_l1_ l11l11l11l11_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ查")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠧࡣࠢ柦"))
	l1ll1llll111l_l1_,ee,l1ll1lll11l11_l1_ = l1ll1ll1l11ll_l1_(dd,l11ll1_l1_ (u"࠭ࠧ柧"),l1ll1ll1l1l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ柨"),str(ee))
	#DIALOG_OK()
	if level==l11ll1_l1_ (u"ࠨ࠴ࠪ柩") and l1ll1llll111l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll1ll1l1l1l_l1_ = []
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ柪")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ柫"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ柬")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ柭"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ柮")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ柯"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ柰")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ柱"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ柲")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ柳"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ柴")+index2+l11ll1_l1_ (u"ࠨ࡝ࠣ柵"))
				succeeded,item,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(ee,l11ll1_l1_ (u"ࠧࠨ柶"),l1ll1ll1l1l1l_l1_)
				if succeeded: l1ll1lll1l111_l1_.append([item,url,l11ll1_l1_ (u"ࠨ࠵࠽࠾ࠬ柷")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ柸")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠶ࠧ柹")])
				#l1l1l1lll1l1_l1_ = l1ll1llllll1l_l1_(item,url,l11ll1_l1_ (u"ࠫ࠸ࡀ࠺ࠨ柺")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ査")+index2+l11ll1_l1_ (u"࠭࠺࠻࠲ࠪ柼"))
				#if l1l1l1lll1l1_l1_: l1l1l11l11_l1_ += 1
				#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ柽"),str(l111l1l1_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ柾")+str(item))
				#l1l1l11l11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token = l1lll11111ll1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ柿"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,l11ll1_l1_ (u"ࠪ࠷࠿ࡀࠧ栀")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ栁")+index2+l11ll1_l1_ (u"ࠬࡀ࠺࠱ࠩ栂"))
			# search l1lll11111l1l_l1_
			l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠵ࡢࠨ栃"))
			# search l1lll11111l1l_l1_
			l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞࠵ࡢࠨ栄"))
			succeeded,item,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(dd,l11ll1_l1_ (u"ࠨࠩ栅"),l1ll1ll1l1l1l_l1_)
			if succeeded and l1ll1lll1l111_l1_ and l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭栆") in list(item.keys()):
				l1ll1lll1l111_l1_.append([item,url,l11ll1_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ标")])
			#l1l1l1lll1l1_l1_ = l1ll1llllll1l_l1_(item,url,l11ll1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ栈"))
			#if l1l1l1lll1l1_l1_: l1l1l11l11_l1_ += 1
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭栉"),str(item))
			#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ栊"),l1lllll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ栋")+token)
	return ee,l1ll1llll111l_l1_,l1ll1lll1l111_l1_,l1ll1lll11l11_l1_
def l1ll1ll1ll11l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ栌"),l11ll1_l1_ (u"ࠩࠪ栍"),index,l11ll1_l1_ (u"ࠪࡘࡍࡏࡒࡅࠩ栎")+l11ll1_l1_ (u"ࠫࡡࡴࠧ栏")+url)
	level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = index.split(l11ll1_l1_ (u"ࠬࡀ࠺ࠨ栐"))
	l1ll1ll1l1l1l_l1_,l1ll1ll1lll11_l1_ = [],[]
	# search results
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ树")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡺࡪࡸࡴࡪࡥࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ栒"))
	# l1l111l1l11_l1_ l11l11l11l11_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ栓")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ栔"))
	# l1ll1llllll11_l1_ menu l1ll1lll1ll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ栕")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ栖"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ栗")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ栘"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ栙")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ栚"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ栛")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ栜"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ栝")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ栞"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ栟")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ栠"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ校"))
	# l1ll1llll11l1_l1_ l1lll11111lll_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ栢"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ栣"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ栤")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ栥"))
	# main l1l1111_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ栦")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ栧"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨࠦ栨"))
	l1ll1llll1ll1_l1_,ff,l1lll11111l11_l1_ = l1ll1ll1l11ll_l1_(ee,l11ll1_l1_ (u"ࠩࠪ栩"),l1ll1ll1l1l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ株"),str(ff))
	if level==l11ll1_l1_ (u"ࠫ࠸࠭栫") and l1ll1llll1ll1_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1ll1lll1ll11_l1_ = str(zz)
				#DIALOG_OK()
				l1ll1ll1l1l1l_l1_ = []
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠤ栬")+l1ll1lll1ll11_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ栭"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠦ栮")+l1ll1lll1ll11_l1_+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ栯"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠࠨ栰")+l1ll1lll1ll11_l1_+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ栱"))
				l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠣ栲")+l1ll1lll1ll11_l1_+l11ll1_l1_ (u"ࠧࡣࠢ栳"))
				succeeded,item,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(ff,l11ll1_l1_ (u"࠭ࠧ栴"),l1ll1ll1l1l1l_l1_)
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token = l1lll11111ll1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭栵"),l111l1_l1_+l1lllll_l1_,l1lllll_l1_,143,l1lll1_l1_)
				if succeeded: l1ll1ll1lll11_l1_.append([item,url,l11ll1_l1_ (u"ࠨ࠶࠽࠾ࠬ栶")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ样")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭核")+l1ll1lll1ll11_l1_])
				#l1l1l1lll1l1_l1_ = l1ll1llllll1l_l1_(item,url,l11ll1_l1_ (u"ࠫ࠹ࡀ࠺ࠨ根")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ栺")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ栻")+l1ll1lll1ll11_l1_)
				#if l1l1l1lll1l1_l1_: l1l1l11l1l_l1_ += 1
	return ff,l1ll1llll1ll1_l1_,l1ll1ll1lll11_l1_,l1lll11111l11_l1_
def l1ll1ll1l11ll_l1_(l11ll1l11111_l1_,l11ll1l1ll11_l1_,l1ll1ll1llll1_l1_):
	cc,l11ll1l1ll11_l1_ = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	dd,l11ll1l1ll11_l1_ = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	ee,l11ll1l1ll11_l1_ = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	ff,l11ll1l1ll11_l1_ = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	item,render = l11ll1l11111_l1_,l11ll1l1ll11_l1_
	count = len(l1ll1ll1llll1_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1ll1llll1_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠧࠨ格")
			return True,out,l11ll11111_l1_+1
		except: pass
	return False,l11ll1_l1_ (u"ࠨࠩ栽"),0
def l11111_l1_(url,index=l11ll1_l1_ (u"ࠩࠪ栾"),data=l11ll1_l1_ (u"ࠪࠫ栿")):
	l1ll1ll1l1lll_l1_,l1ll1lll1l111_l1_,l1ll1ll1lll11_l1_ = [],[],[]
	if l11ll1_l1_ (u"ࠫ࠿ࡀࠧ桀") not in index: index = l11ll1_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ桁")
	level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = index.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ桂"))
	if level==l11ll1_l1_ (u"ࠧ࠵ࠩ桃"): level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠨ࠳ࠪ桄"),l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ桅"),l11ll1_l1_ (u"ࠪࠫ框"),index,url)
	data = data.replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ桇"),l11ll1_l1_ (u"ࠬ࠭案"))
	html,cc,l11ll111l_l1_ = l1ll1lll1l11l_l1_(url,data)
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌ࡭࡫ࠦࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪࠤ࡮ࡴࠠࡶࡴ࡯ࠤࡴࡸࠠࠨ࠱ࡸࡷࡪࡸ࠯ࠨࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠍࠍࠎࠩ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡴ࡯ࡵࠢࡲࡻࡳ࡫ࡲ࠻ࠢࠍࠍࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡩࡨࡢࡰࡱࡩࡱࡓࡥࡵࡣࡧࡥࡹࡧࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡲࡻࡳ࡫ࡲࡖࡴ࡯ࡷࠧࡀ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠤ࡫ࡩࠤࡳࡵࡴࠡࡱࡺࡲࡪࡸ࠺ࠡࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥࡵࡷ࡯ࡧࡵ࠾ࠏࠏࠉࠊࡱࡺࡲࡪࡸࡎࡂࡏࡈࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠲ࡠ࠭ࠏࠏࠉࠊࡱࡺࡲࡪࡸࡎࡂࡏࡈࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࠯ࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠴ࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱࡬ࡪࡰ࡮ࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡳࡼࡴࡥࡳࡐࡄࡑࡊ࠲࡬ࡪࡰ࡮࠰࠶࠺࠴ࠪࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡱ࡯࡮࡬ࠩ࠯ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠱࠭ࠧ࠭࠻࠼࠽࠾࠯ࠊࠊࠤࠥࠦ桉")
	index = level+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ桊")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ桋")+index2+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ桌")+l1ll1lll1ll11_l1_
	if level in [l11ll1_l1_ (u"ࠪ࠵ࠬ桍"),l11ll1_l1_ (u"ࠫ࠷࠭桎"),l11ll1_l1_ (u"ࠬ࠹ࠧ桏")]:
		dd,l1ll1llll1l11_l1_,l1ll1ll1l1lll_l1_,l1ll1ll11llll_l1_ = l1ll1lll11ll1_l1_(cc,url,index)
		if not l1ll1llll1l11_l1_: return
		l1ll11l1l1_l1_ = len(l1ll1ll1l1lll_l1_)
		if l1ll11l1l1_l1_<2:
			if level==l11ll1_l1_ (u"࠭࠱ࠨ桐"): level = l11ll1_l1_ (u"ࠧ࠳ࠩ桑")
			l1ll1ll1l1lll_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ桒"),l11ll1_l1_ (u"ࠩࠪ桓"),index,l11ll1_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠵ࡡࡴࠧ桔")+l11ll1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ桕")+str(l1ll1ll11llll_l1_)+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ桖")+l11ll1_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ桗")+str(len(dd))+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ桘")+l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ桙")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ桚")+url)
	index = level+l11ll1_l1_ (u"ࠪ࠾࠿࠭桛")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ桜")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ桝")+l1ll1lll1ll11_l1_
	if level in [l11ll1_l1_ (u"࠭࠲ࠨ桞"),l11ll1_l1_ (u"ࠧ࠴ࠩ桟")]:
		ee,l1ll1llll111l_l1_,l1ll1lll1l111_l1_,l1ll1lll11l11_l1_ = l1ll1ll1l1111_l1_(cc,dd,url,index)
		if not l1ll1llll111l_l1_: return
		l1l1l11l11_l1_ = len(l1ll1lll1l111_l1_)
		if l1l1l11l11_l1_<2:
			if level==l11ll1_l1_ (u"ࠨ࠴ࠪ桠"): level = l11ll1_l1_ (u"ࠩ࠶ࠫ桡")
			l1ll1lll1l111_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ桢"),l11ll1_l1_ (u"ࠫࠬ档"),index,l11ll1_l1_ (u"ࠬࡲࡥࡷࡧ࡯࠾ࠥ࠸࡜࡯ࠩ桤")+l11ll1_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥ࠻ࠢࠪ桥")+str(l1ll1lll11l11_l1_)+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ桦")+l11ll1_l1_ (u"ࠨ࡮ࡨࡲ࡬ࡺࡨ࠻ࠢࠪ桧")+str(len(ee))+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ桨")+l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵ࠼ࠣࠫ桩")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠫࡡࡴࠧ桪")+url)
	index = level+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ桫")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"࠭࠺࠻ࠩ桬")+index2+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ桭")+l1ll1lll1ll11_l1_
	if level in [l11ll1_l1_ (u"ࠨ࠵ࠪ桮")]:
		ff,l1ll1llll1ll1_l1_,l1ll1ll1lll11_l1_,l1lll11111l11_l1_ = l1ll1ll1ll11l_l1_(cc,ee,url,index)
		if not l1ll1llll1ll1_l1_: return
		l1l1l11l1l_l1_ = len(l1ll1ll1lll11_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ桯"),l11ll1_l1_ (u"ࠪࠫ桰"),index,l11ll1_l1_ (u"ࠫࡱ࡫ࡶࡦ࡮࠽ࠤ࠸ࡢ࡮ࠨ桱")+l11ll1_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ桲")+str(l1lll11111l11_l1_)+l11ll1_l1_ (u"࠭࡜࡯ࠩ桳")+l11ll1_l1_ (u"ࠧ࡭ࡧࡱ࡫ࡹ࡮࠺ࠡࠩ桴")+str(len(ff))+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ桵")+l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴ࠻ࠢࠪ桶")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠪࡠࡳ࠭桷")+url)
	for item,url,index in l1ll1ll1l1lll_l1_+l1ll1lll1l111_l1_+l1ll1ll1lll11_l1_:
		l1l1l1lll1l1_l1_ = l1ll1llllll1l_l1_(item,url,index)
	return
def l1ll1llllll1l_l1_(item,url=l11ll1_l1_ (u"ࠫࠬ桸"),index=l11ll1_l1_ (u"ࠬ࠭桹")):
	if l11ll1_l1_ (u"࠭࠺࠻ࠩ桺") in index: level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = index.split(l11ll1_l1_ (u"ࠧ࠻࠼ࠪ桻"))
	else: level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠨ࠳ࠪ桼"),l11ll1_l1_ (u"ࠩ࠳ࠫ桽"),l11ll1_l1_ (u"ࠪ࠴ࠬ桾"),l11ll1_l1_ (u"ࠫ࠵࠭桿")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,l1lll11111111_l1_ = l1lll11111ll1_l1_(item)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭梀"),url)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ梁"),l1lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ梂"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ梃")+title)
	# needed for l1ll1llll11l1_l1_ l1lll11111lll_l1_ next l1l1111_l1_
	# and needed for l1ll1llll11l1_l1_ l1lll11111lll_l1_ sub-menu
	#if (l11ll1_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽࠶࠲ࠪ梄") in l1lllll_l1_ or l11ll1_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾࠶࠼ࠫ梅") in l1lllll_l1_) and (l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ梆") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ梇") in l1lllll_l1_): l1lllll_l1_ = url
	l1ll1lll1ll1_l1_ = l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠿ࠨ梈") in l1lllll_l1_ or l11ll1_l1_ (u"ࠧ࠰ࡵࡷࡶࡪࡧ࡭ࡴࡁࠪ梉") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࡄ࠭梊") in l1lllll_l1_
	l1ll1lll1l11_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࡄ࠭梋") in l1lllll_l1_ or l11ll1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࡃࠬ梌") in l1lllll_l1_
	if l1ll1lll1ll1_l1_ or l1ll1lll1l11_l1_: l1lllll_l1_ = url
	l1ll1lll1ll1_l1_ = l11ll1_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭梍") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ梎") not in l1lllll_l1_
	l1ll1lll1l11_l1_ = l11ll1_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ梏") not in l1lllll_l1_  and l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡳࡵࡱࡵࡩ࡫ࡸ࡯࡯ࡶࠪ梐") not in l1lllll_l1_
	if index[0:5]==l11ll1_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺ࠨ梑") and l1ll1lll1ll1_l1_ and l1ll1lll1l11_l1_: l1lllll_l1_ = url
	if l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ梒") in url or l11ll1_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ梓") in l1lllll_l1_:
		level,l1ll1ll1lllll_l1_,index2,l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭梔"),l11ll1_l1_ (u"ࠬ࠶ࠧ梕"),l11ll1_l1_ (u"࠭࠰ࠨ梖"),l11ll1_l1_ (u"ࠧ࠱ࠩ梗")
		index = l11ll1_l1_ (u"ࠨࠩ梘")
	l11ll111l_l1_ = l11ll1_l1_ (u"ࠩࠪ梙")
	if l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ梚") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ梛") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ梜") in url:
		data = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ條"))
		if data.count(l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ梞"))==4:
			l1ll1llll1l1l_l1_,key,l1ll1lll1llll_l1_,l1ll1lll1111l_l1_,token = data.split(l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ梟"))
			l11ll111l_l1_ = l1ll1llll1l1l_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭梠")+key+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ梡")+l1ll1lll1llll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ梢")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ梣")+l1lll11111111_l1_
			if l11ll1_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ梤") in url and not l1lllll_l1_: l1lllll_l1_ = url
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀ࡭ࡨࡽࡂ࠭梥")+key
	if not title:
		global l1ll1ll1ll1l1_l1_
		l1ll1ll1ll1l1_l1_ += 1
		title = l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣࠫ梦")+str(l1ll1ll1ll1l1_l1_)
		index = l11ll1_l1_ (u"ࠩ࠶ࠫ梧")+l11ll1_l1_ (u"ࠪ࠾࠿࠭梨")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ梩")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ梪")+l1ll1lll1ll11_l1_
	#if l11ll1_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬ梫") in url: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ梬"),l11ll1_l1_ (u"ࠨࠩ梭"),title,index+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ梮")+l1lllll_l1_)
	#if not l1lllll_l1_: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ梯"),l11ll1_l1_ (u"ࠫࠬ械"),str(succeeded),title+l11ll1_l1_ (u"ࠬࠦ࠺࠻࠼ࠣࠫ梱")+l1lllll_l1_)
	#if l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ梲") in url and index==l11ll1_l1_ (u"ࠧ࠱ࠩ梳"):
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ梴"),l111l1_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭梵") in str(item): return False			# l1ll1lllll1ll_l1_ not items
	elif l11ll1_l1_ (u"ࠪ࠳ࡦࡨ࡯ࡶࡶࠪ梶") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠫ࠴ࡩ࡯࡮࡯ࡸࡲ࡮ࡺࡹࠨ梷") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ梸") in list(item.keys()) or l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ梹") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ梺")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ梻")+index2+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ梼")+l1ll1lll1ll11_l1_
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梽"),l111l1_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ梾")+l11ll1_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ梿"),l1lllll_l1_,144,l1lll1_l1_,index,l11ll111l_l1_)
	elif l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ检") in l1lllll_l1_:
		title = l11ll1_l1_ (u"ࠧ࠻࠼ࠣࠫ棁")+title
		index = l11ll1_l1_ (u"ࠨ࠵ࠪ棂")+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ棃")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭棄")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ棅")+l1ll1lll1ll11_l1_
		url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭棆"),l11ll1_l1_ (u"࠭ࠧ棇"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ棈"),l111l1_l1_+title,url,145,l11ll1_l1_ (u"ࠨࠩ棉"),index,l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭棊"))
	elif l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ棋") in url and not l1lllll_l1_:
		index = l11ll1_l1_ (u"ࠫ࠸࠭棌")+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ棍")+l1ll1ll1lllll_l1_+l11ll1_l1_ (u"࠭࠺࠻ࠩ棎")+index2+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ棏")+l1ll1lll1ll11_l1_
		title = l11ll1_l1_ (u"ࠨ࠼࠽ࠤࠬ棐")+title
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棑"),l111l1_l1_+title,url,144,l1lll1_l1_,index,l11ll111l_l1_)
	#elif l11ll1_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭棒") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࠬ棓") in l1lllll_l1_ and url==l11l1l_l1_:
		title = l11ll1_l1_ (u"ࠬࡀ࠺ࠡࠩ棔")+title
		index = l11ll1_l1_ (u"࠭࠲࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ棕")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ棖"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll111l_l1_)
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ棗") in str(item):
		title = l11ll1_l1_ (u"ࠩ࠽࠾ࠥ࠭棘")+title
		index = l11ll1_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ棙")
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ棚"),l111l1_l1_+title,url,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ棛") in str(item):
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ棜"),l111l1_l1_+title,l11ll1_l1_ (u"ࠧࠨ棝"),9999)
	#elif l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ棞") in l1lllll_l1_ and l11ll1_l1_ (u"ࠩࡥࡴࡂ࠭棟") not in l1lllll_l1_:
	#	title = l11ll1_l1_ (u"ࠪ࠾࠿ࠦࠧ棠")+title
	#	index = l11ll1_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ棡")
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ棢"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l111lllll1l_l1_:
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ棣"),l111l1_l1_+l111lllll1l_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ棤") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ棥"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ棦")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ棧")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	#elif l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ棨") in l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ棩") not in l1lllll_l1_ and l11ll1_l1_ (u"࠭ࡴ࠾࠲ࠪ棪") not in l1lllll_l1_:
	#	l1ll1lll1l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠮࠮ࠫࡁࠬࠨࠬ棫"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ棬")+l1ll1lll1l1ll_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棭"),l111l1_l1_+l11ll1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ森")+count+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ棯")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ棰") in l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭棱"),1)[0]
		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭棲"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11ll1l_l1_)
	elif l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ棳") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ棴") in l1lllll_l1_ and count:
			l1ll1lll1l1ll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ棵"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭棶")+l1ll1lll1l1ll_l1_
			index = l11ll1_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ棷")
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棸"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡍࡋࡖࡘࠬ棹")+count+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ棺")+title,l1lllll_l1_,144,l1lll1_l1_,index)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ棻"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ棼"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11ll1l_l1_)
	elif l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ棽") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵ࡣ࠰ࠩ棾") in l1lllll_l1_ or (l11ll1_l1_ (u"࠭࠯ࡁࠩ棿") in l1lllll_l1_ and l1lllll_l1_.count(l11ll1_l1_ (u"ࠧ࠰ࠩ椀"))==3):
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ椁"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡆࡌࡓࡒࠧ椂")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ椃")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ椄") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椅"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡕࡔࡇࡕࠫ椆")+count+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ椇")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	else:
		if not l1lllll_l1_: l1lllll_l1_ = url
		title = l11ll1_l1_ (u"ࠨ࠼࠽ࠤࠬ椈")+title
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ椉"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll111l_l1_)
	return True
def l1lll11111ll1_l1_(item):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token = False,l11ll1_l1_ (u"ࠪࠫ椊"),l11ll1_l1_ (u"ࠫࠬ椋"),l11ll1_l1_ (u"ࠬ࠭椌"),l11ll1_l1_ (u"࠭ࠧ植"),l11ll1_l1_ (u"ࠧࠨ椎"),l11ll1_l1_ (u"ࠨࠩ椏"),l11ll1_l1_ (u"ࠩࠪ椐"),l11ll1_l1_ (u"ࠪࠫ椑")
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ椒"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token
	for l1ll1lllll11l_l1_ in list(item.keys()):
		render = item[l1ll1lllll11l_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭椓"),str(render))
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ椔"),str(render))
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ椕"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ椖"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤ࡭࡫ࡱࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ椗"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ椘"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ椙"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ椚"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ椛"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ検"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ椝"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ椞"))
	# required for l11ll11l1l11_l1_ l1ll1lll11l1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ椟"))
	# l1ll1llll11l1_l1_ l1ll1lll1ll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡺ࡮ࡪࡥࡰࡋࡧࠫࡢࠨ椠"))
	succeeded,title,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭椡"),l11ll1_l1_ (u"࠭ࠧ椢"),l11ll1_l1_ (u"ࠧࠨ椣"),str(l111l1l1_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ椤"),str(l111l1l1_l1_)+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭椥")+str(title))
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ椦"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ椧"))
	# l1lll11111l1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡣࡳ࡭࡚ࡸ࡬ࠨ࡟ࠥ椨"))
	# header feed
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ椩"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ椪"))
	# required for l11ll11l1l11_l1_ l1ll1ll1lll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ椫"))
	# l1ll1llll11l1_l1_ l1ll1lll1ll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ椬"))
	succeeded,l1lllll_l1_,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ椭"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ椮"))
	# l1ll1llll11l1_l1_ l1ll1lll1ll1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡷ࡫ࡥ࡭࡙ࡤࡸࡨ࡮ࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ椯"))
	succeeded,l1lll1_l1_,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ椰"),str(l111l1l1_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ椱")+l1lll1_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ椲"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ椳"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ椴"))
	succeeded,count,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ椵"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ椶"))
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ椷"))
	# l1ll1lllll111_l1_ l1ll1llll11l1_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡥࡲࡲࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࡚ࡹࡱࡧࠪࡡࠧ椸"))
	# l1ll1lllll111_l1_ l1ll1llll11l1_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡷࡽࡱ࡫ࠧ࡞ࠤ椹"))
	succeeded,l1l11ll1l_l1_,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	#l1ll1ll1l1l1l_l1_ = []
	# l1lll11111l1l_l1_
	#l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣ࡭࡫ࡦ࡯࡙ࡸࡡࡤ࡭࡬ࡲ࡬ࡖࡡࡳࡣࡰࡷࠬࡣࠢ椺"))
	# l1l111l1l11_l1_ l11l11l11l11_l1_
	#l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡲࡢࡥ࡮࡭ࡳ࡭ࡐࡢࡴࡤࡱࡸ࠭࡝ࠣ椻"))
	#succeeded,l1ll1ll1ll1ll_l1_,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	l1ll1ll1l1l1l_l1_ = []
	# l1l111l1l11_l1_ l11l11l11l11_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡶࡲ࡯ࡪࡴࠧ࡞ࠤ椼"))
	# l1lll11111l1l_l1_
	l1ll1ll1l1l1l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ椽"))
	succeeded,token,l111l1l1_l1_ = l1ll1ll1l11ll_l1_(item,render,l1ll1ll1l1l1l_l1_)
	if l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ椾") in l1l11ll1l_l1_: l1l11ll1l_l1_,l111lllll1l_l1_ = l11ll1_l1_ (u"ࠧࠨ椿"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ楀")
	if l11ll1_l1_ (u"่ࠩฬฬฺัࠨ楁") in l1l11ll1l_l1_: l1l11ll1l_l1_,l111lllll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ楂"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ楃")
	if l11ll1_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ楄") in list(render.keys()):
		l1ll1lllllll1_l1_ = str(render[l11ll1_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭楅")])
		if l11ll1_l1_ (u"ࠧࡇࡴࡨࡩࠥࡽࡩࡵࡪࠣࡅࡩࡹࠧ楆") in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭楇")
		if l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ楈") in l1ll1lllllll1_l1_: l111lllll1l_l1_ = l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ楉")
		if l11ll1_l1_ (u"ࠫࡇࡻࡹࠨ楊") in l1ll1lllllll1_l1_ or l11ll1_l1_ (u"ࠬࡘࡥ࡯ࡶࠪ楋") in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ楌")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡵࠨ็หหูืࠧ楍")) in l1ll1lllllll1_l1_: l111lllll1l_l1_ = l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ楎")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡷุࠪึอมࠨ楏")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ楐")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡹࠬอำหศฯหึ࠭楑")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ楒")
		if l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡻࠧฦ฻็ห๋อสࠨ楓")) in l1ll1lllllll1_l1_: l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ楔")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭楕") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠩࡂࠫ楖"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ楗") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ楘")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1lll1l1l1_l1_: title = l1ll1lll1l1l1_l1_+title
	#title = unescapeHTML(title)
	l1l11ll1l_l1_ = l1l11ll1l_l1_.replace(l11ll1_l1_ (u"ࠬ࠲ࠧ楙"),l11ll1_l1_ (u"࠭ࠧ楚"))
	count = count.replace(l11ll1_l1_ (u"ࠧ࠭ࠩ楛"),l11ll1_l1_ (u"ࠨࠩ楜"))
	count = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨ࠰࠭楝"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠪࠫ楞")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11ll1l_l1_,l111lllll1l_l1_,l1ll1lll1l1l1_l1_,token
def l1ll1lll1l11l_l1_(url,data=l11ll1_l1_ (u"ࠫࠬ楟"),request=l11ll1_l1_ (u"ࠬ࠭楠")):
	if request==l11ll1_l1_ (u"࠭ࠧ楡"): request = l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ楢")
	#if l11ll1_l1_ (u"ࠨࡡࡢࠫ楣") in l1ll1llll11ll_l1_: l1ll1llll11ll_l1_ = l11ll1_l1_ (u"ࠩࠪ楤")
	#if l11ll1_l1_ (u"ࠪࡷࡸࡃࠧ楥") in url: url = url.split(l11ll1_l1_ (u"ࠫࡸࡹ࠽ࠨ楦"))[0]
	l111lll1ll_l1_ = l11lllll1_l1_()
	#l111lll1ll_l1_ = l11ll1_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠴࠴࠾࠴࠰࠯࠲࠱࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠥࡋࡤࡨ࠱࠴࠴࠾࠴࠰࠯࠳࠸࠵࠽࠴࠷࠱ࠩ楧")
	l1l1ll111_l1_ = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ楨"):l111lll1ll_l1_,l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ楩"):l11ll1_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ楪")}
	#l1l1ll111_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ楫"))
	if data.count(l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ楬"))==4: l1ll1llll1l1l_l1_,key,l1ll1lll1llll_l1_,l1ll1lll1111l_l1_,token = data.split(l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ業"))
	else: l1ll1llll1l1l_l1_,key,l1ll1lll1llll_l1_,l1ll1lll1111l_l1_,token = l11ll1_l1_ (u"ࠬ࠭楮"),l11ll1_l1_ (u"࠭ࠧ楯"),l11ll1_l1_ (u"ࠧࠨ楰"),l11ll1_l1_ (u"ࠨࠩ楱"),l11ll1_l1_ (u"ࠩࠪ楲")
	l11ll111l_l1_ = {l11ll1_l1_ (u"ࠥࡧࡴࡴࡴࡦࡺࡷࠦ楳"):{l11ll1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ楴"):{l11ll1_l1_ (u"ࠧ࡮࡬ࠣ極"):l11ll1_l1_ (u"ࠨࡡࡳࠤ楶"),l11ll1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ楷"):l11ll1_l1_ (u"࡙ࠣࡈࡆࠧ楸"),l11ll1_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ楹"):l1ll1lll1llll_l1_}}}
	if url==l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ楺") or l11ll1_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ楻") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡷ࡫ࡥ࡭࠱ࡵࡩࡪࡲ࡟ࡸࡣࡷࡧ࡭ࡥࡳࡦࡳࡸࡩࡳࡩࡥࠨ楼")+l11ll1_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ楽")+key
		l11ll111l_l1_[l11ll1_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࡒࡤࡶࡦࡳࡳࠨ楾")] = l1ll1llll1l1l_l1_
		l11ll111l_l1_ = str(l11ll111l_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭楿"),url,l11ll111l_l1_,l1l1ll111_l1_,True,True,l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ榀"))
	elif l11ll1_l1_ (u"ࠪ࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ榁") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ概")+key
		l11ll111l_l1_ = str(l11ll111l_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ榃"),url,l11ll111l_l1_,l1l1ll111_l1_,True,True,l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ榄"))
	elif l11ll1_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ榅") in url and l1ll1llll1l1l_l1_:
		l11ll111l_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ榆")] = token
		l11ll111l_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ榇")][l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࠪ榈")][l11ll1_l1_ (u"ࠫࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠩ榉")] = l1ll1llll1l1l_l1_
		l11ll111l_l1_ = str(l11ll111l_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ榊"),url,l11ll111l_l1_,l1l1ll111_l1_,True,True,l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠵ࡶ࡫ࠫ榋"))
	elif l11ll1_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ榌") in url and l1ll1lll1111l_l1_:
		l1l1ll111_l1_.update({l11ll1_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ榍"):l11ll1_l1_ (u"ࠩ࠴ࠫ榎"),l11ll1_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ榏"):l1ll1lll1llll_l1_})
		l1l1ll111_l1_.update({l11ll1_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ榐"):l11ll1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ榑")+l1ll1lll1111l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ榒"),url,l11ll1_l1_ (u"ࠧࠨ榓"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠨࠩ榔"),l11ll1_l1_ (u"ࠩࠪ榕"),l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠺ࡺࡨࠨ榖"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ榗"),url,l11ll1_l1_ (u"ࠬ࠭榘"),l1l1ll111_l1_,l11ll1_l1_ (u"࠭ࠧ榙"),l11ll1_l1_ (u"ࠧࠨ榚"),l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠹ࡸ࡭࠭榛"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ榜"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ榝"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll1llll_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ榞"),html,re.DOTALL|re.I)
	if tmp: l1ll1llll1l1l_l1_ = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ榟"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ榠"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠢ࠻ࡽࠥࡸࡴࡱࡥ࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ榡"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ榢"),l11ll1_l1_ (u"ࠩࠪ榣"),l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩ榤"),str(len(tmp)))
	#if tmp: l1lll11111l1l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ榥") in list(cookies.keys()): l1ll1lll1111l_l1_ = cookies[l11ll1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ榦")]
	l11ll11l1_l1_ = l1ll1llll1l1l_l1_+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ榧")+key+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ榨")+l1ll1lll1llll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ榩")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭榪")+token
	if request==l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ榫") and l11ll1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ榬") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ榭"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ榮"),html,re.DOTALL)
		l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ榯"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭榰") and l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ榱") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ榲"),html,re.DOTALL)
		l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ榳"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ榴") not in html: l1ll1ll1l1ll1_l1_ = EVAL(l11ll1_l1_ (u"࠭ࡳࡵࡴࠪ榵"),html)
	else: l1ll1ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠧࠨ榶")
	if 0:
		cc = str(l1ll1ll1l1ll1_l1_)
		if kodi_version>18.99: cc = cc.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭榷"))
		open(l11ll1_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ榸"),l11ll1_l1_ (u"ࠪࡻࡧ࠭榹")).write(cc)
		#open(l11ll1_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ榺"),l11ll1_l1_ (u"ࠬࡽࠧ榻")).write(html)
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ榼"),l11ll11l1_l1_)
	return html,l1ll1ll1l1ll1_l1_,l11ll11l1_l1_
def l1lll111111l1_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ榽"),l11ll1_l1_ (u"ࠨ࠭ࠪ榾"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ榿")+search
	l11111_l1_(l111lll_l1_,index)
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ槀")+l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ槁")+l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ槂")+l11ll1_l1_ (u"࠭࡟ࠨ槃")+search
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ槄"),l11ll1_l1_ (u"ࠨࠩ槅"),l11ll1_l1_ (u"ࠩࠪ槆"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ槇"),l11ll1_l1_ (u"ࠫࠬ槈"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ槉"),l11ll1_l1_ (u"࠭ࠫࠨ槊"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ構")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ槌") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ槍")
		elif l11ll1_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ槎") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ槏")
		elif l11ll1_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ槐") in options: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭槑")
		else: l1ll1lll111ll_l1_ = l11ll1_l1_ (u"ࠧࠨ槒")
		l11l111_l1_ = l111lll_l1_+l1ll1lll111ll_l1_
	else:
		l1ll1lll111l1_l1_,l1ll1ll1l11l1_l1_,l1lll1l11_l1_ = [],[],l11ll1_l1_ (u"ࠨࠩ槓")
		l1ll1ll1l1l11_l1_ = [l11ll1_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭槔"),l11ll1_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ槕"),l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ槖"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ槗"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ様")]
		l1ll1lllll1l1_l1_ = [l11ll1_l1_ (u"ࠧࠨ槙"),l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ槚"),l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ槛"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ槜"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ槝")]
		l1ll1llllllll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ槞"),l1ll1ll1l1l11_l1_)
		if l1ll1llllllll_l1_ == -1: return
		l1ll1lll11111_l1_ = l1ll1lllll1l1_l1_[l1ll1llllllll_l1_]
		html,c,data = l1ll1lll1l11l_l1_(l111lll_l1_+l1ll1lll11111_l1_)
		if c:
			try:
				d = c[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ槟")][l11ll1_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ槠")][l11ll1_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ槡")][l11ll1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ槢")][l11ll1_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ槣")][l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ槤")][l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ槥")]
				for l1ll1ll1l111l_l1_ in range(len(d)):
					group = d[l1ll1ll1l111l_l1_][l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ槦")][l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ槧")]
					for l1lll111111ll_l1_ in range(len(group)):
						render = group[l1lll111111ll_l1_][l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ槨")]
						if l11ll1_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ槩") in list(render.keys()):
							l1lllll_l1_ = render[l11ll1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ槪")][l11ll1_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭槫")][l11ll1_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ槬")][l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ槭")]
							l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ槮"),l11ll1_l1_ (u"ࠨࠨࠪ槯"))
							title = render[l11ll1_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ槰")]
							title = title.replace(l11ll1_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭槱"),l11ll1_l1_ (u"ࠫࠬ槲"))
							if l11ll1_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ槳") in title: continue
							if l11ll1_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ槴") in title:
								title = l11ll1_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ槵")+title
								l1lll1l11_l1_ = title
								l1lllll111_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ槶") in title: continue
							title = title.replace(l11ll1_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ槷"),l11ll1_l1_ (u"ࠪࠫ槸"))
							if l11ll1_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ槹") in title: continue
							if l11ll1_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ槺") in title:
								title = l11ll1_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ槻")+title
								l1lll1l11_l1_ = title
								l1lllll111_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ槼") in title: continue
							l1ll1lll111l1_l1_.append(escapeUNICODE(title))
							l1ll1ll1l11l1_l1_.append(l1lllll_l1_)
			except: pass
		if not l1lll1l11_l1_: l1ll1llll1lll_l1_ = l11ll1_l1_ (u"ࠨࠩ槽")
		else:
			l1ll1lll111l1_l1_ = [l11ll1_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ槾"),l1lll1l11_l1_]+l1ll1lll111l1_l1_
			l1ll1ll1l11l1_l1_ = [l11ll1_l1_ (u"ࠪࠫ槿"),l1lllll111_l1_]+l1ll1ll1l11l1_l1_
			l1lll1111111l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ樀"),l1ll1lll111l1_l1_)
			if l1lll1111111l_l1_ == -1: return
			l1ll1llll1lll_l1_ = l1ll1ll1l11l1_l1_[l1lll1111111l_l1_]
		if l1ll1llll1lll_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1llll1lll_l1_
		elif l1ll1lll11111_l1_: l11l111_l1_ = l111lll_l1_+l1ll1lll11111_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪ࡮ࡲࡴࡦࡴ࠰ࡨࡷࡵࡰࡥࡱࡺࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡩࡧࠢࠪࡖࡪࡳ࡯ࡷࡧࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠬ࠲ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡲࡶࡹࠦࡢࡺࠩ࠯ࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭ࠫࡵ࡫ࡷࡰࡪࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠢࠣࠤ樁")
	#DIALOG_OK()
	l11111_l1_(l11l111_l1_)
	return
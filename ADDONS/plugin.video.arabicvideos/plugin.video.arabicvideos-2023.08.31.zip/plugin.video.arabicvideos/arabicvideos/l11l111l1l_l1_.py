# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪỄ")
def MAIN(mode,url):
	if   mode==330: results = l11ll111ll_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l11lll1_l1_()
	elif mode==333: results = l111llll1l_l1_()
	elif mode==334: results = l1ll1111l1_l1_(url)
	else: results = False
	return results
def l1ll1111l1_l1_(l11l1l11ll_l1_):
	try: os.remove(l11l1l11ll_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧễ")))
	except: os.remove(l11l1l11ll_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩỆ"))
	return
def l111llll1l_l1_():
	message = l11ll1_l1_ (u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪệ")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭Ỉ"),l11ll1_l1_ (u"࠭ࠧỉ"),l11ll1_l1_ (u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭Ị"),message)
	return
def l11ll111ll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ị"),l11ll1_l1_ (u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧỌ"),l11ll1_l1_ (u"ࠪࠫọ"),333)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩỎ"),l11ll1_l1_ (u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬỏ"),l11ll1_l1_ (u"࠭ࠧỐ"),332)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬố"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨỒ"),l11ll1_l1_ (u"ࠩࠪồ"),9999)
	l11l1ll11l_l1_ = l11l11ll11_l1_()
	mtime = os.stat(l11l1ll11l_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1ll111_l1_ = os.listdir(l11l1ll11l_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨỔ")))
	else: l11l1ll111_l1_ = os.listdir(l11l1ll11l_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩổ")))
	for filename in l11l1ll111_l1_:
		if kodi_version>18.99: filename = filename.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪỖ"))
		if not filename.startswith(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬỗ")): continue
		filepath = os.path.join(l11l1ll11l_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11l1lllll_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬỘ"))
			except: pass
			filename = filename.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ộ"))
		filepath = os.path.join(l11l1ll11l_l1_,filename)
		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨỚ"),filename,filepath,331)
	return
def l11l11ll11_l1_():
	l11l1ll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ớ"))
	if l11l1ll11l_l1_: return l11l1ll11l_l1_
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧỜ"),addoncachefolder)
	return addoncachefolder
def l11l11lll1_l1_():
	l11l1ll11l_l1_ = l11l11ll11_l1_()
	l11l111l11_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬờ"),l11ll1_l1_ (u"࠭ࠧỞ"),l11ll1_l1_ (u"ࠧࠨở"),l11l1ll11l_l1_,l11ll1_l1_ (u"ࠨ้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬỠ"))
	if l11l111l11_l1_==1:
		newpath = l11l1l1111_l1_(3,l11ll1_l1_ (u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭ỡ"),l11ll1_l1_ (u"ࠪࡰࡴࡩࡡ࡭ࠩỢ"),l11ll1_l1_ (u"ࠫࠬợ"),False,True,l11l1ll11l_l1_)
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬỤ"),l11ll1_l1_ (u"࠭ࠧụ"),l11ll1_l1_ (u"ࠧࠨỦ"),newpath,l11ll1_l1_ (u"ࠨ้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬủ"))
		if l1ll111ll1_l1_==1:
			settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬỨ"),newpath)
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫứ"),l11ll1_l1_ (u"ࠫࠬỪ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨừ"),l11ll1_l1_ (u"࠭สๆࠢอ฾๏๐ัࠡ็ๆห๋ࠦสฯิํ๊ࠥอไๆๆไหฯࠦวๅ็ะ้้ฯࠧỬ"))
	#if not l11l111l11_l1_ or not l1ll111ll1_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨử"),l11ll1_l1_ (u"ࠨࠩỮ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬữ"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅ฼สลࠥอไฺ็็๎ฮ࠭Ự"))
	return
def l11l11llll_l1_(filename):
	l11ll111l1_l1_ = l11ll1_l1_ (u"ࠫࠬự").join(l11ll11111_l1_ for l11ll11111_l1_ in filename if l11ll11111_l1_ not in l11ll1_l1_ (u"ࠬࡢ࠯ࠣ࠼࠭ࡃࡁࡄࡼࠨỲ")+half_triangular_colon)
	return l11ll111l1_l1_
def l11l11l1ll_l1_(url,l111lll1l1_l1_=l11ll1_l1_ (u"࠭ࠧỳ"),l1l1l11l_l1_=l11ll1_l1_ (u"ࠧࠨỴ")):
	#l1llllll_l1_(l11ll1_l1_ (u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨỵ"),l11ll1_l1_ (u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩỶ"))
	LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪỷ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫỸ")+url+l11ll1_l1_ (u"ࠬࠦ࡝ࠨỹ"))
	if not l111lll1l1_l1_: l111lll1l1_l1_ = l11l1lll11_l1_(url,l1l1l11l_l1_)
	#if not l111lll1l1_l1_:
	#	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧỺ"),l11ll1_l1_ (u"ࠧࠨỻ"),l11ll1_l1_ (u"ࠨฬ้ึ๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬỼ"),l11ll1_l1_ (u"ࠩส่๊๊แࠡ็้ࠤ๋๎ูࠡࠩỽ")+l111lll1l1_l1_+l11ll1_l1_ (u"ࠪࠤํอไษำ้ห๊าࠠฮษ็๎ฬฺ๋ࠦำࠣะฬําࠡๆอั๊๐ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆ่่ๆอสࠨỾ"))
	#	LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩỿ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡵࡻࡳࡩ࠴࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠡ࡫ࡶࠤࡳࡵࡴࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧἀ")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩἁ"))
	#	return False
	l11l1ll11l_l1_ = l11l11ll11_l1_()
	l11l1lll1l_l1_ = l11l1l1ll1_l1_()
	filename = l11l1lll1l_l1_.replace(l11ll1_l1_ (u"ࠧࠡࠩἂ"),l11ll1_l1_ (u"ࠨࡡࠪἃ"))
	filename = l11l11llll_l1_(filename)
	#l111lll1l1_l1_ = l111lll1l1_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧἄ"))
	filename = l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩἅ")+str(int(now))[-4:]+l11ll1_l1_ (u"ࠫࡤ࠭ἆ")+filename+l111lll1l1_l1_
	l111lllll1_l1_ = os.path.join(l11l1ll11l_l1_,filename)
	headers = {}
	headers[l11ll1_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧἇ")] = l11ll1_l1_ (u"࠭ࠧἈ")
	headers[l11ll1_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧἉ")] = l11ll1_l1_ (u"ࠨࠬ࠲࠮ࠬἊ")
	url = url.replace(l11ll1_l1_ (u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬἋ"),l11ll1_l1_ (u"ࠪࠫἌ"))
	if l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩἍ") in url:
		l111lll_l1_,l111lll1ll_l1_ = url.rsplit(l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪἎ"),1)
		l111lll1ll_l1_ = l111lll1ll_l1_.replace(l11ll1_l1_ (u"࠭ࡼࠨἏ"),l11ll1_l1_ (u"ࠧࠨἐ")).replace(l11ll1_l1_ (u"ࠨࠨࠪἑ"),l11ll1_l1_ (u"ࠩࠪἒ"))
	else: l111lll_l1_,l111lll1ll_l1_ = url,None
	if not l111lll1ll_l1_: l111lll1ll_l1_ = l11lllll1_l1_()
	if l111lll1ll_l1_: headers[l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧἓ")] = l111lll1ll_l1_
	if l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ἔ") in l111lll_l1_: l111lll_l1_,l11l111lll_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧἕ"),1)
	else: l111lll_l1_,l11l111lll_l1_ = l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ἖")
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠧࡽࠩ἗")).strip(l11ll1_l1_ (u"ࠨࠨࠪἘ")).strip(l11ll1_l1_ (u"ࠩࡿࠫἙ")).strip(l11ll1_l1_ (u"ࠪࠪࠬἚ"))
	l11l111lll_l1_ = l11l111lll_l1_.replace(l11ll1_l1_ (u"ࠫࢁ࠭Ἓ"),l11ll1_l1_ (u"ࠬ࠭Ἔ")).replace(l11ll1_l1_ (u"࠭ࠦࠨἝ"),l11ll1_l1_ (u"ࠧࠨ἞"))
	if l11l111lll_l1_:	headers[l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ἟")] = l11l111lll_l1_
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩἠ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫἡ")+l111lll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧἢ")+str(headers)+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬἣ")+l111lllll1_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩἤ"))
	l11ll11l11_l1_ = 1024*1024
	l11l1ll1ll_l1_ = 0
	try:
		l11l1ll1l1_l1_ =	xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪἥ"))
		l11l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡞ࡧ࠯ࠬἦ"),l11l1ll1l1_l1_)
		l11l1ll1ll_l1_ = int(l11l1ll1l1_l1_[0])
	except: pass
	if not l11l1ll1ll_l1_:
		try:
			l11l1l1l11_l1_ = os.l111lll11l_l1_(l11l1ll11l_l1_)
			l11l1ll1ll_l1_ = l11l1l1l11_l1_.f_frsize*l11l1l1l11_l1_.f_bavail//l11ll11l11_l1_
		except: pass
	if not l11l1ll1ll_l1_:
		try:
			l11l1l1l11_l1_ = os.l11ll1111l_l1_(l11l1ll11l_l1_)
			l11l1ll1ll_l1_ = l11l1l1l11_l1_.f_frsize*l11l1l1l11_l1_.f_bavail//l11ll11l11_l1_
		except: pass
	if not l11l1ll1ll_l1_:
		try:
			import shutil
			total,l11l11ll1l_l1_,l11l11l1l1_l1_ = shutil.l11ll11lll_l1_(l11l1ll11l_l1_)
			l11l1ll1ll_l1_ = l11l11l1l1_l1_//l11ll11l11_l1_
		except: pass
	if not l11l1ll1ll_l1_:
		l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨἧ"),l11ll1_l1_ (u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪἨ"),l11ll1_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨἩ"),l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨἪ"))
		LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫἫ"),LOGGING(script_name)+l11ll1_l1_ (u"࡙ࠧࠡࠢࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡷ࡬ࡪࠦࡤࡪࡵ࡮ࠤ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨἬ"))
		return False
	import requests
	if l111lll1l1_l1_==l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧἭ"):
		l1lll111_l1_,l1llll_l1_ = l11ll11l1l_l1_(l111lll_l1_,headers)
		#DIALOG_SELECT(l11ll1_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧἮ"), l1lll111_l1_)
		#DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨἯ"), l1llll_l1_)
		if len(l1lll111_l1_)==0:
			l1llllll_l1_(l11ll1_l1_ (u"ࠫๆฺไࠡใํࠤส๐ฬศั้้ࠣ็ࠠศๆอั๊๐ไࠨἰ"),l11ll1_l1_ (u"ࠬ࠭ἱ"))
			return False
		elif len(l1lll111_l1_)==1: l1l_l1_ = 0
		elif len(l1lll111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫἲ"), l1lll111_l1_)
			if l1l_l1_ == -1 :
				l1llllll_l1_(l11ll1_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯำๅ๋ๆࠪἳ"),l11ll1_l1_ (u"ࠨࠩἴ"))
				return False
		l111lll_l1_ = l1llll_l1_[l1l_l1_]
	filesize = 0
	if l111lll1l1_l1_==l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨἵ"):
		l111lllll1_l1_ = l111lllll1_l1_.rsplit(l11ll1_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩἶ"))[0]+l11ll1_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩἷ")
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩἸ"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧἹ"),headers,l11ll1_l1_ (u"ࠧࠨἺ"),l11ll1_l1_ (u"ࠨࠩἻ"),l11ll1_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ࠱ࡉࡕࡗࡏࡎࡒࡅࡉࡥࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩἼ"))
		l1lll1lll_l1_ = response.content
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡠࠨࡋࡘࡕࡋࡑࡊ࠿࠴ࠪࡀ࡝࡟ࡲࡡࡸ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬἽ"),l1lll1lll_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜ࡳࠩἾ"),re.DOTALL)
		if not l1l1_l1_:
			LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪἿ"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡗ࡬ࡪࠦ࡭࠴ࡷ࠻ࠤ࡫࡯࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣ࡬ࡦࡼࡥࠡࡶ࡫ࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠ࡭࡫ࡱ࡯ࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩὀ")+l111lll_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪὁ"))
			return False
		l1lllll_l1_ = l1l1_l1_[0]
		if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ὂ")):
			if l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠩ࠲࠳ࠬὃ")): l1lllll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠪ࠾ࠬὄ"),1)[0]+l11ll1_l1_ (u"ࠫ࠿࠭ὅ")+l1lllll_l1_
			elif l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠬ࠵ࠧ὆")): l1lllll_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ὇"))+l1lllll_l1_
			else: l1lllll_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠧ࠰ࠩὈ"),1)[0]+l11ll1_l1_ (u"ࠨ࠱ࠪὉ")+l1lllll_l1_
		response = requests.request(l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭Ὂ"),l1lllll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l11l11l_l1_ = len(l1l1_l1_)
		filesize = chunksize*l11l11l11l_l1_
	else:
		chunksize = 1*l11ll11l11_l1_
		response = requests.request(l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧὋ"),l111lll_l1_,headers=headers,verify=False,stream=True)
		if l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬὌ") in response.headers: filesize = int(response.headers[l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭Ὅ")])
		l11l11l11l_l1_ = int(filesize//chunksize)
	#l11l1llll1_l1_ = l11l11l11l_l1_+1
	l11l1llll1_l1_ = int(filesize//l11ll11l11_l1_)+1
	if filesize<21000:
		LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ὎"),LOGGING(script_name)+l11ll1_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ὏")+l111lll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬὐ")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨὑ")+str(l11l1ll1ll_l1_)+l11ll1_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ὒ")+l111lllll1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧὓ"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ὔ"),l11ll1_l1_ (u"࠭ࠧὕ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὖ"),l11ll1_l1_ (u"ࠨใื่ࠥ็๊ࠡ็฼ีๆฯࠠฮฮ่ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไๆๆไࠤฺเ๊าࠢฯำฬ่ࠦๅ้ำห๊ࠥวࠡ์่็๋ࠦไๅสิ๊ฬ๋ฬࠡฬะ้๏๊่ࠠาสࠤฬ๊ๅๅใࠪὗ"))
		return False
	l11l111ll1_l1_ = 400
	l11l11111l_l1_ = l11l1ll1ll_l1_-l11l1llll1_l1_
	if l11l11111l_l1_<l11l111ll1_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ὘"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡎࡰࡶࠣࡩࡳࡵࡵࡨࡪࠣࡨ࡮ࡹ࡫ࠡࡵࡳࡥࡨ࡫ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩὙ")+l111lll_l1_+l11ll1_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ὚")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫὛ")+str(l11l1ll1ll_l1_)+l11ll1_l1_ (u"࠭ࠠࡎࡄࠣ࠱ࠥ࠭὜")+str(l11l111ll1_l1_)+l11ll1_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪὝ")+l111lllll1_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ὞"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪὟ"),l11ll1_l1_ (u"ࠪࠫὠ"),l11ll1_l1_ (u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫὡ"),l11ll1_l1_ (u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫὢ")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬὣ")+str(l11l1ll1ll_l1_)+l11ll1_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧὤ")+str(l11l111ll1_l1_)+l11ll1_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪὥ"))
		return False
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩὦ"),l11ll1_l1_ (u"ࠪࠫὧ"),l11ll1_l1_ (u"ࠫࠬὨ"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฤ࠭Ὡ"),l11ll1_l1_ (u"࠭วๅ็็ๅࠥอไๆู็์อࠦออ็๊ࠤฯ่ั๋สสࠤࠬὪ")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อࠥะโา์หหࠥ࠭Ὣ")+str(l11l1ll1ll_l1_)+l11ll1_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤํํะศࠢส่๊๊แࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦไๅฬะ้๏๊ࠠๆ่ࠣห้หๆหำ้ฮࠥหไ๊ࠢฯ๋ฬุใࠡ࠰๋้ࠣࠦว็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡษ็หุะๅาษิࠤอะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢยࠫὬ"))
	if l1ll111ll1_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪὭ"),l11ll1_l1_ (u"ࠪࠫὮ"),l11ll1_l1_ (u"ࠫࠬὯ"),l11ll1_l1_ (u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪὰ"))
		LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ά"),LOGGING(script_name)+l11ll1_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡴࡨࡪࡺࡹࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪὲ")+l111lll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨέ")+l111lllll1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬὴ"))
		return False
	LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪή"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩὶ"))
	l11l1l1lll_l1_ = DIALOG_PROGRESS()
	l11l1l1lll_l1_.create(l111lllll1_l1_,l11ll1_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ί"))
	l11l11l111_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111lllll1_l1_,l11ll1_l1_ (u"࠭ࡷࡣࠩὸ"))
	else: file = open(l111lllll1_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬό")),l11ll1_l1_ (u"ࠨࡹࡥࠫὺ"))
	if l111lll1l1_l1_==l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨύ"): # l11l11ll1l_l1_ for l1lll1lll_l1_ and l11l1111l1_l1_ chunks video files such as .l11l1l1l1l_l1_
		for l11ll11111_l1_ in range(1,l11l11l11l_l1_+1):
			l1lllll_l1_ = l1l1_l1_[l11ll11111_l1_-1]
			if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨὼ")):
				if l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠫ࠴࠵ࠧώ")): l1lllll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠬࡀࠧ὾"),1)[0]+l11ll1_l1_ (u"࠭࠺ࠨ὿")+l1lllll_l1_
				elif l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠧ࠰ࠩᾀ")): l1lllll_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᾁ"))+l1lllll_l1_
				else: l1lllll_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠩ࠲ࠫᾂ"),1)[0]+l11ll1_l1_ (u"ࠪ࠳ࠬᾃ")+l1lllll_l1_
			response = requests.request(l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᾄ"),l1lllll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11l111111_l1_ = time.time()
			l111llll11_l1_ = l11l111111_l1_-t1
			l111llllll_l1_ = l111llll11_l1_//l11ll11111_l1_
			l11l1l111l_l1_ = l111llllll_l1_*(l11l11l11l_l1_+1)
			l11l1111ll_l1_ = l11l1l111l_l1_-l111llll11_l1_
			PROGRESS_UPDATE(l11l1l1lll_l1_,int(100*l11ll11111_l1_//(l11l11l11l_l1_+1)),l11ll1_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ᾅ"),l11ll1_l1_ (u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ᾆ"),str(l11ll11111_l1_*chunksize//l11ll11l11_l1_)+l11ll1_l1_ (u"ࠧ࠰ࠩᾇ")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ᾈ")+time.strftime(l11ll1_l1_ (u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦᾉ"),time.gmtime(l11l1111ll_l1_))+l11ll1_l1_ (u"ࠪࠤๅ࠭ᾊ"))
			if l11l1l1lll_l1_.iscanceled():
				l11l11l111_l1_ = False
				break
	else: # l1111l11_l1_ and other l11l1l11l1_l1_ file l11ll11ll1_l1_
		l11ll11111_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11ll11111_l1_ = l11ll11111_l1_+1
			l11l111111_l1_ = time.time()
			l111llll11_l1_ = l11l111111_l1_-t1
			l111llllll_l1_ = l111llll11_l1_/l11ll11111_l1_
			l11l1l111l_l1_ = l111llllll_l1_*(l11l11l11l_l1_+1)
			l11l1111ll_l1_ = l11l1l111l_l1_-l111llll11_l1_
			PROGRESS_UPDATE(l11l1l1lll_l1_,int(100*l11ll11111_l1_/(l11l11l11l_l1_+1)),l11ll1_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᾋ"),l11ll1_l1_ (u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬᾌ"),str(l11ll11111_l1_*chunksize//l11ll11l11_l1_)+l11ll1_l1_ (u"࠭࠯ࠨᾍ")+str(l11l1llll1_l1_)+l11ll1_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬᾎ")+time.strftime(l11ll1_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᾏ"),time.gmtime(l11l1111ll_l1_))+l11ll1_l1_ (u"ࠩࠣไࠬᾐ"))
			if l11l1l1lll_l1_.iscanceled():
				l11l11l111_l1_ = False
				break
		response.close()
	file.close()
	l11l1l1lll_l1_.close()
	if not l11l11l111_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᾑ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᾒ")+l111lll_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᾓ")+l111lllll1_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩᾔ"))
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᾕ"),l11ll1_l1_ (u"ࠨࠩᾖ"),l11ll1_l1_ (u"ࠩࠪᾗ"),l11ll1_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᾘ"))
		return True
	LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᾙ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᾚ")+l111lll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᾛ")+l111lllll1_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪᾜ"))
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᾝ"),l11ll1_l1_ (u"ࠩࠪᾞ"),l11ll1_l1_ (u"ࠪࠫᾟ"),l11ll1_l1_ (u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪᾠ"))
	return True
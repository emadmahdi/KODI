# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ䯣")
headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䯤"):l11ll1_l1_ (u"ࠫࠬ䯥")}
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫ䯦")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ䯧"),l11ll1_l1_ (u"ࠧࡸࡹࡨࠫ䯨")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11111_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llll11_l1_(url,text)
	elif mode==364: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ䯩")+text)
	elif mode==365: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭䯪")+text)
	elif mode==366: results = l1l111_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䯫"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ䯬"),l11ll1_l1_ (u"ࠬ࠭䯭"),False,l11ll1_l1_ (u"࠭ࠧ䯮"),l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䯯"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䯰")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ䯱"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䯲")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䯳"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭䯴"),l11ll1_l1_ (u"࠭ࠧ䯵"),l11ll1_l1_ (u"ࠧࠨ䯶"),l11ll1_l1_ (u"ࠨࠩ䯷"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䯸"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䯹"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䯺"),l11ll1_l1_ (u"ࠬ࠭䯻"),8)
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䯼"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䯽"),l11ll1_l1_ (u"ࠨࠩ䯾"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䯿"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䰀"),l11l1l_l1_,369,l11ll1_l1_ (u"ࠫࠬ䰁"),l11ll1_l1_ (u"ࠬ࠭䰂"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䰃"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䰄"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ䰅"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䰆"),364)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰇"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ䰈"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䰉"),365)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䰊"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䰋"),l11ll1_l1_ (u"ࠨࠩ䰌"),9999)
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䰍"):hostname,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䰎"):l11ll1_l1_ (u"ࠫࠬ䰏")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠬࡢ࠯ࠨ䰐"),l11ll1_l1_ (u"࠭࠯ࠨ䰑"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡦࡪ࡮ࡷࡩࡷ࠭䰒"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䰓"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠩࠨࡨ࠾ࠫ࠸࠶ࠧࡧ࠼ࠪࡨ࠵ࠦࡦ࠻ࠩࡦ࠽ࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡥ࠽ࠪࡪ࠸ࠦࡣ࠼࠱ࠪࡪ࠸ࠦࡣࡧࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡡ࠺ࠩ䰔") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰕"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䰖")+l111l1_l1_+title,l1lllll_l1_,366)
	#	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䰗"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䰘"),l11ll1_l1_ (u"ࠧࠨ䰙"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䰚"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䰛"),l11ll1_l1_ (u"ࠪࠫ䰜"),l11ll1_l1_ (u"ࠫࠬ䰝"),l11ll1_l1_ (u"ࠬ࠭䰞"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ䰟"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ䰠"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䰡"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䰢") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ䰣"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠫࠬ䰤"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䰥"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䰦")+l111l1_l1_+title,l1lllll_l1_,366)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䰧"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䰨"),l11ll1_l1_ (u"ࠩࠪ䰩"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩࠬ䰪"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䰫"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䰬"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䰭")+l111l1_l1_+title,l1lllll_l1_,366,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䰮"),l11ll1_l1_ (u"ࠨࠩ䰯"),url,l11ll1_l1_ (u"ࠩࠪ䰰"))
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䰱"):url,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䰲"):l11ll1_l1_ (u"ࠬ࠭䰳")}
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ䰴"),url,l11ll1_l1_ (u"ࠧࠨ䰵"),l11ll1_l1_ (u"ࠨࠩ䰶"),l11ll1_l1_ (u"ࠩࠪ䰷"),l11ll1_l1_ (u"ࠪࠫ䰸"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䰹"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䰺"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䰻"),url,364)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䰼"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䰽"),url,365)
	if l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ䰾") in html:
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰿"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䱀"),url,361,l11ll1_l1_ (u"ࠬ࠭䱁"),l11ll1_l1_ (u"࠭ࠧ䱂"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䱃"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䱄"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䱅"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䱆"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l11111_l1_(l1ll1l1lll11_l1_,type=l11ll1_l1_ (u"ࠫࠬ䱇")):
	if l11ll1_l1_ (u"ࠬࡀ࠺ࠨ䱈") in l1ll1l1lll11_l1_:
		l11l111_l1_,url = l1ll1l1lll11_l1_.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ䱉"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ䱊"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1lll11_l1_,l1ll1l1lll11_l1_
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䱋"):l11l111_l1_,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䱌"):l11ll1_l1_ (u"ࠪࠫ䱍")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䱎"),url,l11ll1_l1_ (u"ࠬ࠭䱏"),l11ll1_l1_ (u"࠭ࠧ䱐"),l11ll1_l1_ (u"ࠧࠨ䱑"),l11ll1_l1_ (u"ࠨࠩ䱒"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䱓"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䱔"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠨ䱕"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䱖"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"࠭࡜࡝࠱ࠪ䱗"),l11ll1_l1_ (u"ࠧ࠰ࠩ䱘")).replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠦࠬ䱙"),l11ll1_l1_ (u"ࠩࠥࠫ䱚"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡋࡷ࡯ࡤ࠮࠯ࡐࡽࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䱛"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ䱜"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"๋ࠬิศ้าอࠥ࠭䱝"),l11ll1_l1_ (u"࠭ࠧ䱞"))
			if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䱟") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䱠"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠩะ่็ฯࠧ䱡") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭䱢"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䱣") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䱤"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䱥"),l111l1_l1_+title,l1lllll_l1_,362,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䱦"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭䱧"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ䱨")+count
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䱩"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ䱪"),l1lllll_l1_,361,l11ll1_l1_ (u"ࠬ࠭䱫"),l11ll1_l1_ (u"࠭ࠧ䱬"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䱭"))
		elif type==l11ll1_l1_ (u"ࠨࠩ䱮"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䱯"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䱰"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ䱱")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䱲"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l1llll11_l1_(url,type=l11ll1_l1_ (u"࠭ࠧ䱳")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䱴"),url,l11ll1_l1_ (u"ࠨࠩ䱵"),l11ll1_l1_ (u"ࠩࠪ䱶"),l11ll1_l1_ (u"ࠪࠫ䱷"),l11ll1_l1_ (u"ࠫࠬ䱸"),l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䱹"))
	html = response.content
	html = l1111_l1_(html)
	name = re.findall(l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤ࡬ࡸࡪࡳࠢࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠭࠴ࠪࡀࠫࠥࠫ䱺"),html,re.DOTALL)
	if name: name = name[-1].replace(l11ll1_l1_ (u"ࠧ࠮ࠩ䱻"),l11ll1_l1_ (u"ࠨࠢࠪ䱼")).strip(l11ll1_l1_ (u"ࠩ࠲ࠫ䱽"))
	if l11ll1_l1_ (u"้ࠪํูๅࠨ䱾") in name and type==l11ll1_l1_ (u"ࠫࠬ䱿"):
		name = name.split(l11ll1_l1_ (u"๋่ࠬิ็ࠪ䲀"))[0]
		name = name.replace(l11ll1_l1_ (u"࠭ๅีษ๊ำฮ࠭䲁"),l11ll1_l1_ (u"ࠧࠨ䲂")).strip(l11ll1_l1_ (u"ࠨࠢࠪ䲃"))
	elif l11ll1_l1_ (u"ࠩะ่็ฯࠧ䲄") in name:
		name = name.split(l11ll1_l1_ (u"ࠪั้่ษࠨ䲅"))[0]
		name = name.replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ䲆"),l11ll1_l1_ (u"ࠬ࠭䲇")).strip(l11ll1_l1_ (u"࠭ࠠࠨ䲈"))
	else: name = name
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࠫ䲉"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if type==l11ll1_l1_ (u"ࠨࠩ䲊"):
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䲋"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ䲌") in title: continue
				if l11ll1_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ䲍") in title: continue
				title = name+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ䲎")+title
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䲏"),l111l1_l1_+title,l1lllll_l1_,363,l11ll1_l1_ (u"ࠧࠨ䲐"),l11ll1_l1_ (u"ࠨࠩ䲑"),l11ll1_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ䲒"))
		if len(menuItemsLIST)==0:
			l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠨࠩࠫ䲓"),block+l11ll1_l1_ (u"ࠫࠫࠬࠧ䲔"),re.DOTALL)
			if l111l_l1_: block = l111l_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䲕"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ䲖"))
				title = name+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ䲗")+title
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䲘"),l111l1_l1_+title,l1lllll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䲙"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ䲚"),l11ll1_l1_ (u"ࠫࠬ䲛")).replace(l11ll1_l1_ (u"๋ࠬิศ้าอࠥ࠭䲜"),l11ll1_l1_ (u"࠭ࠧ䲝"))
		else: title = l11ll1_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ䲞")
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䲟"),l111l1_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䲠"),url,l11ll1_l1_ (u"ࠪࠫ䲡"),l11ll1_l1_ (u"ࠫࠬ䲢"),l11ll1_l1_ (u"ࠬ࠭䲣"),l11ll1_l1_ (u"࠭ࠧ䲤"),l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䲥"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲦"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ䲧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲨"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䲩") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ู๊ࠬาใิࠤ๊อ๊ࠡีํ้ฬ࠭䲪"): name = l11ll1_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䲫")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䲬")+name+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䲭")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䲮"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲯"),block,re.DOTALL)
		for l1lllll_l1_,l111lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䲰") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䲱"),l111lll1_l1_,re.DOTALL)
			if l111lll1_l1_: l111lll1_l1_ = l11ll1_l1_ (u"࠭࡟ࡠࡡࡢࠫ䲲")+l111lll1_l1_[0]
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ䲳")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾࡯ࡼࡧ࡮ࡳࡡࠨ䲴")+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䲵")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䲶"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䲷"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠬ࠭䲸")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧ䲹"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ䲺"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ䲻"),l11ll1_l1_ (u"ࠩ࠮ࠫ䲼"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䲽"),l11ll1_l1_ (u"ࠫ࠴࠭䲾"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ䲿"),l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ䳀"),l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ䳁")]
	l1l11l111_l1_ = [l11ll1_l1_ (u"ࠨษ็็้࠭䳂"),l11ll1_l1_ (u"ࠩส่ศ็ไศ็ࠪ䳃"),l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯ࠭䳄"),l11ll1_l1_ (u"ࠫฬ๊ว็์่๎ࠥ๎ࠠศๆๆีฯ๎ๆࠨ䳅"),l11ll1_l1_ (u"ࠬอไษำส้ัࠦสๅ์ไึ๏๎ๆ๋หࠪ䳆")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ䳇"), l1l11l111_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11ll1_l1_ (u"ࠧࠨ䳈"):
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䳉"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䳊"),l11ll1_l1_ (u"ࠪࠫ䳋"),False,l11ll1_l1_ (u"ࠫࠬ䳌"),l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䳍"))
		hostname = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䳎")]
		hostname = hostname.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ䳏"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ䳐")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1ll1lll_l1_(l1ll1l1lll11_l1_,filter):
	if l11ll1_l1_ (u"ࠩࡂࡃࠬ䳑") in l1ll1l1lll11_l1_: url = l1ll1l1lll11_l1_.split(l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䳒"))[0]
	else: url = l1ll1l1lll11_l1_
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䳓"):l1ll1l1lll11_l1_,l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䳔"):l11ll1_l1_ (u"࠭ࠧ䳕")}
	filter = filter.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䳖"),l11ll1_l1_ (u"ࠨࠩ䳗"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭䳘"),1)
	if filter==l11ll1_l1_ (u"ࠪࠫ䳙"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠫࠬ䳚"),l11ll1_l1_ (u"ࠬ࠭䳛")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ䳜"))
	if type==l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ䳝"):
		if l1l1111ll_l1_[0]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ䳞") not in l1l111l1_l1_: category = l1l1111ll_l1_[0]
		for i in range(len(l1l1111ll_l1_[0:-1])):
			if l1l1111ll_l1_[i]+l11ll1_l1_ (u"ࠩࡀࡁࠬ䳟") in l1l111l1_l1_: category = l1l1111ll_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭䳠")+category+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ䳡")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ䳢")+category+l11ll1_l1_ (u"࠭࠽࠾࠲ࠪ䳣")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ䳤"))+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䳥")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠪࠬ䳦"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䳧"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䳨")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䳩"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䳪"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠧࠨ䳫"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䳬"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠩࠪ䳭"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䳮")+l1l1111l_l1_
		l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_,l1ll1l1lll11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳯"),l111l1_l1_+l11ll1_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ䳰"),l1lllll1l_l1_,361,l11ll1_l1_ (u"࠭ࠧ䳱"),l11ll1_l1_ (u"ࠧࠨ䳲"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䳳"))
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳴"),l111l1_l1_+l11ll1_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ䳵")+l11ll11l_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ䳶"),l1lllll1l_l1_,361,l11ll1_l1_ (u"ࠬ࠭䳷"),l11ll1_l1_ (u"࠭ࠧ䳸"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䳹"))
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䳺"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䳻"),l11ll1_l1_ (u"ࠪࠫ䳼"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䳽"),url,l11ll1_l1_ (u"ࠬ࠭䳾"),l11ll1_l1_ (u"࠭ࠧ䳿"),l11ll1_l1_ (u"ࠧࠨ䴀"),l11ll1_l1_ (u"ࠨࠩ䴁"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䴂"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠪࡠࡡࠨࠧ䴃"),l11ll1_l1_ (u"ࠫࠧ࠭䴄")).replace(l11ll1_l1_ (u"ࠬࡢ࡜࠰ࠩ䴅"),l11ll1_l1_ (u"࠭࠯ࠨ䴆"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ䴇"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䴈"),block+l11ll1_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䴉"),re.DOTALL)
	dict = {}
	for l1ll1l11_l1_,name,block in l1ll1ll1_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䴊") in l1ll1l11_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭䴋"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠬࡃ࠽ࠨ䴌") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䴍"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<=1:
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䴎")+l1l11ll1_l1_)
				return
			else:
				l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_,l1ll1l1lll11_l1_)
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䴏"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ัฺ๋๊ࠩ䴐"),l1lllll1l_l1_,361,l11ll1_l1_ (u"ࠪࠫ䴑"),l11ll1_l1_ (u"ࠫࠬ䴒"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䴓"))
				else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䴔"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠧ䴕"),l111lll_l1_,364,l11ll1_l1_ (u"ࠨࠩ䴖"),l11ll1_l1_ (u"ࠩࠪ䴗"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䴘"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ䴙")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ䴚")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ䴛")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠧ࠾࠿࠳ࠫ䴜")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䴝")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䴞"),l111l1_l1_+name+l11ll1_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ䴟"),l111lll_l1_,365,l11ll1_l1_ (u"ࠫࠬ䴠"),l11ll1_l1_ (u"ࠬ࠭䴡"),l1l11ll1_l1_+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䴢"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠧࡳࠩ䴣") or value==l11ll1_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䴤"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䴥") in option: continue
			if l11ll1_l1_ (u"ࠪห้้ไࠨ䴦") in option: continue
			if l11ll1_l1_ (u"ࠫࡳ࠳ࡡࠨ䴧") in value: continue
			#if value in [l11ll1_l1_ (u"ࠬࡸࠧ䴨"),l11ll1_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ䴩"),l11ll1_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭䴪")]: continue
			#if l1ll1l11_l1_==l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䴫"): option = value
			if option==l11ll1_l1_ (u"ࠩࠪ䴬"): option = value
			l11l1l11l_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ䴭"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l11l_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l11_l1_ = name+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ䴮")+l11l1l11l_l1_
			dict[l1ll1l11_l1_][value] = l1lll1l11_l1_
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ䴯")+l1ll1l11_l1_+l11ll1_l1_ (u"࠭࠽࠾ࠩ䴰")+l11l1l11l_l1_
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ䴱")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ䴲")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭䴳")+l1l1ll11_l1_
			if type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䴴"):
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䴵"),l111l1_l1_+l1lll1l11_l1_,url,365,l11ll1_l1_ (u"ࠬ࠭䴶"),l11ll1_l1_ (u"࠭ࠧ䴷"),l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䴸"))
			elif type==l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䴹") and l1l1111ll_l1_[-2]+l11ll1_l1_ (u"ࠩࡀࡁࠬ䴺") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䴻"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䴼"),l11ll1_l1_ (u"ࠬ࠭䴽"),l11llll1_l1_,l1l1ll11_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䴾")+l11llll1_l1_
				l1lllll1l_l1_ = l11ll1l11_l1_(l11l111_l1_,l1ll1l1lll11_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴿"),l111l1_l1_+l1lll1l11_l1_,l1lllll1l_l1_,361,l11ll1_l1_ (u"ࠨࠩ䵀"),l11ll1_l1_ (u"ࠩࠪ䵁"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䵂"))
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵃"),l111l1_l1_+l1lll1l11_l1_,url,364,l11ll1_l1_ (u"ࠬ࠭䵄"),l11ll1_l1_ (u"࠭ࠧ䵅"),l1ll11ll_l1_)
	return
l1l1111ll_l1_ = [l11ll1_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䵆"),l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䵇"),l11ll1_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䵈")]
l11llllll_l1_ = [l11ll1_l1_ (u"ࠪࡱࡵࡧࡡࠨ䵉"),l11ll1_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䵊"),l11ll1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䵋"),l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ䵌"),l11ll1_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ䵍"),l11ll1_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ䵎"),l11ll1_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䵏"),l11ll1_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ䵐")]
def l11ll1l11_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䵑") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䵒"),l11ll1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ䵓"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䵔"),l11ll1_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ䵕"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩࡀࡁࠬ䵖"),l11ll1_l1_ (u"ࠪ࠳ࠬ䵗"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫࠫࠬࠧ䵘"),l11ll1_l1_ (u"ࠬ࠵ࠧ䵙"))
	return l111lll_l1_
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䵚"),l11ll1_l1_ (u"ࠧࠨ䵛"),filters,l11ll1_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ䵜")+mode)
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䵝")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䵞")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ䵟")					all filters (l11lll11_l1_ l1l1l1l1_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ䵠"))
	l1l111ll_l1_,l1ll11l1_l1_ = {},l11ll1_l1_ (u"࠭ࠧ䵡")
	if l11ll1_l1_ (u"ࠧ࠾࠿ࠪ䵢") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠨࠨࠩࠫ䵣"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠩࡀࡁࠬ䵤"))
			l1l111ll_l1_[var] = value
	for key in l11llllll_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠪ࠴ࠬ䵥")
		if l11ll1_l1_ (u"ࠫࠪ࠭䵦") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ䵧") and value!=l11ll1_l1_ (u"࠭࠰ࠨ䵨"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ䵩")+value
		elif mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䵪") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫ䵫"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭䵬")+key+l11ll1_l1_ (u"ࠫࡂࡃࠧ䵭")+value
		elif mode==l11ll1_l1_ (u"ࠬࡧ࡬࡭ࠩ䵮"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ䵯")+key+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ䵰")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ䵱"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠪࠬ䵲"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䵳"),l11ll1_l1_ (u"ࠫࠬ䵴"),l1ll11l1_l1_,l11ll1_l1_ (u"ࠬࡕࡕࡕࠩ䵵"))
	return l1ll11l1_l1_
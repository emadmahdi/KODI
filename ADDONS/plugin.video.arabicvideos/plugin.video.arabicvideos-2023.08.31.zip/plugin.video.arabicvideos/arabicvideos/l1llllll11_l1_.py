# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫᗈ")
headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᗉ"):l11ll1_l1_ (u"࠭ࠧᗊ")}
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡅ࠷࡙ࡤ࠭ᗋ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬᗌ"),l11ll1_l1_ (u"ࠩสาึ๐ࠧᗍ"),l11ll1_l1_ (u"ࠪหำื้ࠨᗎ"),l11ll1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᗏ"),l11ll1_l1_ (u"ࠬฮฯ้่ࠣษำะ๊ศำࠪᗐ"),l11ll1_l1_ (u"࠭วโๆส้ࠬᗑ"),l11ll1_l1_ (u"ࠧๆี็ื้อสࠨᗒ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l11111_l1_(url,text)
	elif mode==422: results = l1lll1ll11_l1_(url)
	elif mode==423: results = l1llll11_l1_(url)
	elif mode==424: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᗓ")+text)
	elif mode==425: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨᗔ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l1llll1111_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1llll1ll1_l1_(l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᗕ"),l11l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬᗖ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᗗ"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧᗘ"),l11ll1_l1_ (u"ࠧࠨᗙ"),l11ll1_l1_ (u"ࠨࠩᗚ"),l11ll1_l1_ (u"ࠩࠪᗛ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᗜ"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᗝ"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠬ࠵ࠧᗞ"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᗟ"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗠ"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᗡ"),l11ll1_l1_ (u"ࠩࠪᗢ"),429,l11ll1_l1_ (u"ࠪࠫᗣ"),l11ll1_l1_ (u"ࠫࠬᗤ"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᗥ"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗦ"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี๋ࠥอะัࠪᗧ"),l1ll111_l1_,425)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗨ"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬᗩ"),l1ll111_l1_,424)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᗪ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᗫ"),l11ll1_l1_ (u"ࠬ࠭ᗬ"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗭ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᗮ")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪᗯ"),l1ll111_l1_,421)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗰ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗱ")+l111l1_l1_+l11ll1_l1_ (u"ࠫศ็ไศ็ࠣห้์ฬ้็ࠪᗲ"),l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࡸ࠵ࠧᗳ"),421)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗴ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᗵ")+l111l1_l1_+l11ll1_l1_ (u"ࠨ่ํฮๆ๊ใิࠩᗶ"),l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡲࡪࡺࡦ࡭࡫ࡻ࠳ࠬᗷ"),421)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᗸ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥ࠮࠭࠴ࠪࡀࠫࠥ࠮ࡃ࠮࠮ࠫࡁࠬࡀࠬᗹ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࡸ࠭ᗺ") in l1lllll_l1_: title = l11ll1_l1_ (u"࠭รโๆส้ࠥอไ็ฮ๋้ࠬᗻ")
		elif l11ll1_l1_ (u"ࠧ࠰ࡰࡨࡸ࡫ࡲࡩࡹࠩᗼ") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠨลไ่ฬ๋้ࠠ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪᗽ")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗾ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗿ")+l111l1_l1_+title,l1lllll_l1_,421)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘀ"),l111l1_l1_+l11ll1_l1_ (u"่ࠬวว็ฬࠤฯ็ี๋ๆํอࠬᘁ"),l1ll111_l1_,427)
	return
def l1llll1111_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"࠭ࠧᘂ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᘃ"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩᘄ"),l11ll1_l1_ (u"ࠩࠪᘅ"),l11ll1_l1_ (u"ࠪࠫᘆ"),l11ll1_l1_ (u"ࠫࠬᘇ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᘈ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡖ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᘉ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥ࠮࠭࠴ࠪࡀࠫࠥ࠮ࠥࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠮࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬᘊ"),block,re.DOTALL)
	for category,id,l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹ࠯ࡰࡳࡻ࡯ࡥࡴࠩᘋ") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩᘌ")
		elif l11ll1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵ࠰ࡲࡪࡺࡦ࡭࡫ࡻࠫᘍ") in l1lllll_l1_: title = l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭ᘎ")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘏ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᘐ")+l111l1_l1_+title,l1lllll_l1_,421,l11ll1_l1_ (u"ࠧࠨᘑ"),l11ll1_l1_ (u"ࠨࠩᘒ"),category+l11ll1_l1_ (u"ࠩࡿࠫᘓ")+id)
	return
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"ࠪࠫᘔ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᘕ"),l11ll1_l1_ (u"ࠬ࠭ᘖ"),l1lll1l11l_l1_,url)
	if l11ll1_l1_ (u"࠭࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᘗ") in url: url = url.strip(l11ll1_l1_ (u"ࠧ࠰ࠩᘘ"))+l11ll1_l1_ (u"ࠨ࠱ࡰࡴࡦࡧ࠯ࡧࡣࡰ࡭ࡱࡿ࠯ࠨᘙ")
	items = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭ᘚ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᘛ"),url,l11ll1_l1_ (u"ࠫࠬᘜ"),headers,l11ll1_l1_ (u"ࠬ࠭ᘝ"),l11ll1_l1_ (u"࠭ࠧᘞ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᘟ"))
	html = response.content
	if not l1lll1l11l_l1_ or l11ll1_l1_ (u"ࠨࡾࠪᘠ") in l1lll1l11l_l1_:
		#if l11ll1_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠧᘡ") in html:
		#	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘢ"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧᘣ"),url,425)
		#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘤ"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩᘥ"),url,424)
		#	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᘦ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᘧ"),l11ll1_l1_ (u"ࠩࠪᘨ"),9999)
		if l11ll1_l1_ (u"ࠪࢀࠬᘩ") not in l1lll1l11l_l1_: l1lll1l1ll_l1_ = l11ll1_l1_ (u"ࠫࠬᘪ")
		else: l1lll1l1ll_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠯ࠨᘫ")+l1lll1l11l_l1_
		separator = False
		if l11ll1_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠩᘬ") in html:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘭ"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩᘮ"),url,421,l11ll1_l1_ (u"ࠩࠪᘯ"),l11ll1_l1_ (u"ࠪࠫᘰ"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᘱ"))
			separator = True
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡖࡡࡨࡧࡗ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡖࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠪᘲ"),html,re.DOTALL)
		if l1l1l11_l1_:
			l111l_l1_ = l1l1l11_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡢ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪࠤ࠭࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᘳ"),l111l_l1_,re.DOTALL)
			for l1lllll1l1_l1_,l1lll1l11_l1_ in l1l1l1l_l1_:
				l1lllll111_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡩࡥ࡯ࡶࡨࡶ࠴ࡧࡣࡵ࡫ࡲࡲ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࡴࡢࡤ࠲ࠫᘴ")+l1lllll1l1_l1_+l1lll1l1ll_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪᘵ")
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘶ"),l111l1_l1_+l1lll1l11_l1_,l1lllll111_l1_,421)
				separator = True
		if separator: addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘷ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘸ"),l11ll1_l1_ (u"ࠬ࠭ᘹ"),9999)
	if l1lll1l11l_l1_==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᘺ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩࡎࡷ࡯ࡸ࡮ࡌࡩ࡭ࡶࡨࡶࠬᘻ"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡒ࡬ࡲࡘࡲࡩࡥࡧࡵࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠫᘼ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: block = l11ll1_l1_ (u"ࠩࠪᘽ")
	elif l11ll1_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴࠭ᘾ") in url or l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡨ࡫࡮ࡵࡧࡵ࠳ࠬᘿ") in url:
		block = html
	elif l11ll1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧᙀ") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡐࡢࡩࡨࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠪࠨᙁ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳࠨᙂ") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠬࠪᙃ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡃࡦࡸࡴࡸࡎࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᙄ"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡇ࡮ࡳࡡ࠵ࡷࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪᙅ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: block = l11ll1_l1_ (u"ࠫࠬᙆ")
	if not items: items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࠰ࡍࡰࡸ࡬ࡩࡇࡲ࡯ࡤ࡭ࠥ࠮࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠮࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠳࠰࠿ࡃࡱࡻࡘ࡮ࡺ࡬ࡦࡋࡱࡪࡴ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᙇ"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡰࡸ࡬ࡩࡇࡲ࡯ࡤ࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯࡭ࡢࡩࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᙈ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if not title: continue
		if l11ll1_l1_ (u"ࠧࡀࡰࡨࡻࡸࡃࠧᙉ") in l1lllll_l1_: continue
		title = title.replace(l11ll1_l1_ (u"ࠨ็ืห์ีษࠡࠩᙊ"),l11ll1_l1_ (u"ࠩࠪᙋ"))
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫᙌ"),title,re.DOTALL)
		if l1ll1l1_l1_ and l11ll1_l1_ (u"ࠫา๊โสࠩᙍ") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᙎ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙏ"),l111l1_l1_+title,l1lllll_l1_,422,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸ࠯ࠨᙐ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙑ"),l111l1_l1_+title,l1lllll_l1_,421,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙒ"),l111l1_l1_+title,l1lllll_l1_,422,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᙓ"),html,re.DOTALL)
	if l1l1l11_l1_ and l1lll1l11l_l1_!=l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᙔ"):
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀ࡟ࡡ࠭࡜ࠣ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠪࡠࠧࡣ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙕ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"࠭วๅืไัฮࠦࠧᙖ"),l11ll1_l1_ (u"ࠧࠨᙗ"))
			if title!=l11ll1_l1_ (u"ࠨࠩᙘ"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙙ"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩᙚ")+title,l1lllll_l1_,421)
	l1llll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁ࠵࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙛ"),html,re.DOTALL)
	if l1llll1l1l_l1_:
		l1lllll_l1_,title = l1llll1l1l_l1_[0]
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙜ"),l111l1_l1_+title,l1lllll_l1_,421)
	return
def l1lll1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᙝ"),url,l11ll1_l1_ (u"ࠧࠨᙞ"),l11ll1_l1_ (u"ࠨࠩᙟ"),l11ll1_l1_ (u"ࠩࠪᙠ"),l11ll1_l1_ (u"ࠪࠫᙡ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠷ࡳࡵࠩᙢ"))
	html = response.content
	# l11l1l1l1_l1_/download main l11l11ll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡒࡴࡽࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᙣ"),html,re.DOTALL)
	if l1l1l11_l1_:
		url = l1l1l11_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᙤ"),url,l11ll1_l1_ (u"ࠧࠨᙥ"),l11ll1_l1_ (u"ࠨࠩᙦ"),l11ll1_l1_ (u"ࠩࠪᙧ"),l11ll1_l1_ (u"ࠪࠫᙨ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠸࡮ࡥࠩᙩ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᙪ"),l11ll1_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᙫ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡔࡧࡤࡷࡴࡴࡳࡔࡧࡦࡸ࡮ࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫᙬ"),html,re.DOTALL)
	# l1llll111l_l1_ l1lll1l1l1_l1_
	if l11ll1_l1_ (u"ࠨ࠱ࡷࡥ࡬࠵ࠧ᙭") in url or l11ll1_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࠩ᙮") in url:
		l11111_l1_(url)
	# l1lll1l_l1_
	elif l1l1l11_l1_:
		l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫᙯ"))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥᙰ"),block,re.DOTALL)
		l1llllll1l_l1_ = [l11ll1_l1_ (u"๋ࠬำๅี็ࠫᙱ"),l11ll1_l1_ (u"࠭ๅ้ี่ࠫᙲ"),l11ll1_l1_ (u"ࠧษำ้ห๊าࠧᙳ"),l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭ᙴ")]
		for l1lllll_l1_,title in items:
			if any(value in title for value in l1llllll1l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙵ"),l111l1_l1_+title,l1lllll_l1_,423,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᙶ"),l111l1_l1_+title,l1lllll_l1_,426,l1lll1_l1_)
	else: l1llll11_l1_(url)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᙷ"),url,l11ll1_l1_ (u"ࠬ࠭ᙸ"),l11ll1_l1_ (u"࠭ࠧᙹ"),l11ll1_l1_ (u"ࠧࠨᙺ"),l11ll1_l1_ (u"ࠨࠩᙻ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᙼ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᙽ"),l11ll1_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᙾ"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᙿ"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"࠭ࠧ ")
	# l1l11_l1_
	l1l11lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡆࡲ࡬ࡷࡴࡪࡥࡴࡕࡨࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᚁ"),html,re.DOTALL)
	if l1l11lll1_l1_:
		block = l1l11lll1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᚂ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1ll1l1_l1_ in items:
			title = title+l11ll1_l1_ (u"ࠩࠣࠫᚃ")+l1ll1l1_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᚄ"),l111l1_l1_+title,l1lllll_l1_,426,l1lll1_l1_)
	else: addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᚅ"),l111l1_l1_+l11ll1_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫᚆ"),url,426,l1lll1_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᚇ"),url,l11ll1_l1_ (u"ࠧࠨᚈ"),headers,l11ll1_l1_ (u"ࠨࠩᚉ"),l11ll1_l1_ (u"ࠩࠪᚊ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᚋ"))
	html = response.content
	#newurl = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡴࡺ࡮ࡨࡷ࡭࡫ࡥࡵࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᚌ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᚍ"))
	l1ll111_l1_ = SERVER(newurl,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᚎ"))
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᚏ"),l11ll1_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᚐ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡚ࠩࡥࡹࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫᚑ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡮࡬ࡲࡰࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠣࠢ࠲ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᚒ"),block,re.DOTALL)
		for l11lll1l_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᚓ"))
			if l11ll1_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫᚔ") in title.lower(): title = l11ll1_l1_ (u"࠭ฮศืࠣࠫᚕ")+title
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡷࡶࡺࡩࡴࡶࡴࡨ࠳ࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬᚖ")+l11lll1l_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᚗ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᚘ")
			#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡣ࠷ࡹ࠳࡯ࡣࡶࠩᚙ"),l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢ࠶ࡸ࠲ࡲࡾࠧᚚ"))
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ᚛"),l11ll1_l1_ (u"࠭ࠧ᚜"))
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࡕࡨࡶࡻ࡫ࡲࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ᚝"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠣࠢ࠲ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᚞"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ᚟"))
			if l11ll1_l1_ (u"ࠪࡱࡾࡼࡩࡥࠩᚠ") in title.lower(): l1lll1l11_l1_ = l11ll1_l1_ (u"ࠫࡤࡥฮศืࠪᚡ")
			else: l1lll1l11_l1_ = l11ll1_l1_ (u"ࠬ࠭ᚢ")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᚣ")+title+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᚤ")+l1lll1l11_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫᚥ"),l11ll1_l1_ (u"ࠩࠪᚦ"))
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᚧ"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᚨ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ᚩ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧᚪ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩᚫ"),l11ll1_l1_ (u"ࠨ࠭ࠪᚬ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫᚭ")+search+l11ll1_l1_ (u"ࠪ࠳ࠬᚮ")
	l11111_l1_(url,l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᚯ"))
	return
# ===========================================
#     l1lll1lll1_l1_ l1lll1ll1l_l1_ l1lll1llll_l1_
# ===========================================
def l1lllll1ll_l1_(url):
	if l11ll1_l1_ (u"ࠬࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸࠧᚰ") not in url: url = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᚱ"))
	else: url = url.split(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᚲ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᚳ"),url,l11ll1_l1_ (u"ࠩࠪᚴ"),l11ll1_l1_ (u"ࠪࠫᚵ"),l11ll1_l1_ (u"ࠫࠬᚶ"),l11ll1_l1_ (u"ࠬ࠭ᚷ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨᚸ"))
	html = response.content
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡎࡷ࡯ࡸ࡮ࡌࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡓࡥ࡬࡫ࡔࡪࡶ࡯ࡩࠬᚹ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# name + options block + category
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡊࡲࡺࡪࡸࡡࡣ࡮ࡨ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࠢࡢ࡮࡯ࠦ࠳࠰࠿ࠩࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᚺ"),block,re.DOTALL)
	return l1ll1ll1_l1_
def l1llll11l1_l1_(block):
	# id + title
	items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᚻ"),block,re.DOTALL)
	return items
def l1llll11ll_l1_(url):
	l1lllll11l_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᚼ"))[0]
	l1llll1l11_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨᚽ"))
	url = url.replace(l1lllll11l_l1_,l1llll1l11_l1_)
	url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᚾ"),l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡨ࡫࡮ࡵࡧࡵ࠳ࡦࡩࡴࡪࡱࡱ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴࠭ᚿ"))
	url = url.replace(l11ll1_l1_ (u"ࠧ࠾ࠩᛀ"),l11ll1_l1_ (u"ࠨ࠱ࠪᛁ")).replace(l11ll1_l1_ (u"ࠩࠩࠫᛂ"),l11ll1_l1_ (u"ࠪ࠳ࠬᛃ"))
	url = url+l11ll1_l1_ (u"ࠫ࠴࠭ᛄ")
	return url
l1l11l11_l1_ = [l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᛅ"),l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࡷࠬᛆ"),l11ll1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ᛇ")]
l1ll1111_l1_ = [l11ll1_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩᛈ"),l11ll1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᛉ"),l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࡴࠩᛊ"),l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᛋ")]
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᛌ"),l11ll1_l1_ (u"࠭ࠧᛍ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᛎ"),l11ll1_l1_ (u"ࠨࠩᛏ"),filter,url)
	if l11ll1_l1_ (u"ࠩࡂࠫᛐ") in url: url = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᛑ"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨᛒ"),1)
	if filter==l11ll1_l1_ (u"ࠬ࠭ᛓ"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"࠭ࠧᛔ"),l11ll1_l1_ (u"ࠧࠨᛕ")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬᛖ"))
	if type==l11ll1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬᛗ"):
		if l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧᛘ") in url:
			global l1l11l11_l1_
			l1l11l11_l1_ = l1l11l11_l1_[1:]
		if l1l11l11_l1_[0]+l11ll1_l1_ (u"ࠫࡂ࠭ᛙ") not in l1l111l1_l1_: category = l1l11l11_l1_[0]
		for i in range(len(l1l11l11_l1_[0:-1])):
			if l1l11l11_l1_[i]+l11ll1_l1_ (u"ࠬࡃࠧᛚ") in l1l111l1_l1_: category = l1l11l11_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨᛛ")+category+l11ll1_l1_ (u"ࠧ࠾࠲ࠪᛜ")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪᛝ")+category+l11ll1_l1_ (u"ࠩࡀ࠴ࠬᛞ")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬᛟ"))+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨᛠ")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧᛡ"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᛢ"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᛣ")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᛤ"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫᛥ"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠪࠫᛦ"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᛧ"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠬ࠭ᛨ"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᛩ")+l1l1111l_l1_
		l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛪ"),l111l1_l1_+l11ll1_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ᛫"),l111lll_l1_,421,l11ll1_l1_ (u"ࠩࠪ᛬"),l11ll1_l1_ (u"ࠪࠫ᛭"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᛮ"))
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᛯ"),l111l1_l1_+l11ll1_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ᛰ")+l11ll11l_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ᛱ"),l111lll_l1_,421,l11ll1_l1_ (u"ࠨࠩᛲ"),l11ll1_l1_ (u"ࠩࠪᛳ"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᛴ"))
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᛵ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᛶ"),l11ll1_l1_ (u"࠭ࠧᛷ"),9999)
	l1ll1ll1_l1_ = l1lllll1ll_l1_(url)
	dict = {}
	for name,block,l1ll1l11_l1_ in l1ll1ll1_l1_:
		if l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫᛸ") in url and l1ll1l11_l1_==l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ᛹"): continue
		name = name.replace(l11ll1_l1_ (u"ࠩ࠰࠱ࠬ᛺"),l11ll1_l1_ (u"ࠪࠫ᛻"))
		items = l1llll11l1_l1_(block)
		if l11ll1_l1_ (u"ࠫࡂ࠭᛼") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ᛽"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<2:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]:
					url = l1llll11ll_l1_(url)
					l11111_l1_(url)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ᛾")+l1l11ll1_l1_)
				return
			else:
				l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᛿"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨᜀ"),l111lll_l1_,421,l11ll1_l1_ (u"ࠩࠪᜁ"),l11ll1_l1_ (u"ࠪࠫᜂ"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᜃ"))
				else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᜄ"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾࠭ᜅ"),l111lll_l1_,425,l11ll1_l1_ (u"ࠧࠨᜆ"),l11ll1_l1_ (u"ࠨࠩᜇ"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬᜈ"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠬᜉ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠫࡂ࠶ࠧᜊ")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠬࠬࠧᜋ")+l1ll1l11_l1_+l11ll1_l1_ (u"࠭࠽࠱ࠩᜌ")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫᜍ")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜎ"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᜏ")+name,l111lll_l1_,424,l11ll1_l1_ (u"ࠪࠫᜐ"),l11ll1_l1_ (u"ࠫࠬᜑ"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᜒ"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭ᜓ"): option = l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไ᜔ู่่ࠧ")
			elif value==l11ll1_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨ᜕"): option = l11ll1_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫ᜖")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ᜗") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬ᜘"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠧ᜙")+l1ll1l11_l1_+l11ll1_l1_ (u"࠭࠽ࠨ᜚")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠧࠧࠩ᜛")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ᜜")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭᜝")+l1l1ll11_l1_
			title = option+l11ll1_l1_ (u"ࠪࠤ࠿࠭᜞")#+dict[l1ll1l11_l1_][l11ll1_l1_ (u"ࠫ࠵࠭ᜟ")]
			title = option+l11ll1_l1_ (u"ࠬࠦ࠺ࠨᜠ")+name
			if type==l11ll1_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩᜡ"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜢ"),l111l1_l1_+title,url,424,l11ll1_l1_ (u"ࠨࠩᜣ"),l11ll1_l1_ (u"ࠩࠪᜤ"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᜥ"))
			elif type==l11ll1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᜦ") and l1l11l11_l1_[-2]+l11ll1_l1_ (u"ࠬࡃࠧᜧ") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᜨ"))
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᜩ")+l11llll1_l1_
				l11l111_l1_ = l1llll11ll_l1_(l11l111_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜪ"),l111l1_l1_+title,l11l111_l1_,421,l11ll1_l1_ (u"ࠩࠪᜫ"),l11ll1_l1_ (u"ࠪࠫᜬ"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᜭ"))
			else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᜮ"),l111l1_l1_+title,url,425,l11ll1_l1_ (u"࠭ࠧᜯ"),l11ll1_l1_ (u"ࠧࠨᜰ"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᜱ"),l11ll1_l1_ (u"ࠩࠪᜲ"),filters,l11ll1_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫᜳ"))
	# mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ᜴࠭")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ᜵")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪ᜶")					all l1l1l1l1_l1_ & l1llll1lll_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠧ࠾ࠨࠪ᜷"),l11ll1_l1_ (u"ࠨ࠿࠳ࠪࠬ᜸"))
	filters = filters.strip(l11ll1_l1_ (u"ࠩࠩࠫ᜹"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"ࠪࡁࠬ᜺") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠫࠫ࠭᜻"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠬࡃࠧ᜼"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"࠭ࠧ᜽")
	for key in l1ll1111_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠧ࠱ࠩ᜾")
		if l11ll1_l1_ (u"ࠨࠧࠪ᜿") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫᝀ") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬᝁ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨᝂ")+value
		elif mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᝃ") and value!=l11ll1_l1_ (u"࠭࠰ࠨᝄ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩᝅ")+key+l11ll1_l1_ (u"ࠨ࠿ࠪᝆ")+value
		elif mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭ᝇ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠪࠬᝈ")+key+l11ll1_l1_ (u"ࠫࡂ࠭ᝉ")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠫࠡࠩᝊ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨᝋ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠧ࠾࠲ࠪᝌ"),l11ll1_l1_ (u"ࠨ࠿ࠪᝍ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᝎ"),l11ll1_l1_ (u"ࠪࠫᝏ"),filters,l11ll1_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬᝐ"))
	return l1ll11l1_l1_
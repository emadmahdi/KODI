# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ষ") : l11ll1_l1_ (u"ࠪࠫস") }
script_name = l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭হ")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡁࡌࡅࡢࠫ঺")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#l11ll1l_l1_ = [l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ঻"),l11ll1_l1_ (u"ࠧไๆํฬ়ࠬ"),l11ll1_l1_ (u"ࠨษ็฽ึ฼ࠠศๆสือ๎ู๋ࠩঽ"),l11ll1_l1_ (u"่ࠩืึำ๊สࠩা"),l11ll1_l1_ (u"ุ้ࠪือ๋้ࠪি"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪী"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫু"),l11ll1_l1_ (u"࠭ไใษฤࠫূ")]
#proxy = l11ll1_l1_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯࠲࠷࠼࠲࠷࠶࠳࠯࠺࠺࠲࠶࠹࠰࠻࠵࠴࠶࠽࠭ৃ")
#proxy = l11ll1_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨৄ")+l11l1ll1_l1_[6][1]
#l1l11l_l1_ = [l11ll1_l1_ (u"ࠩหีฬ๋ฬࠨ৅"),l11ll1_l1_ (u"ࠪว้฿วษࠩ৆"),l11ll1_l1_ (u"ࠫฬ๊ๅึษิ฽ฮࠦวๅฯิอࠬে"),l11ll1_l1_ (u"ࠬอไฤฮ๊ึฮࠦวๅๆ๋ั๏ฯࠧৈ"),l11ll1_l1_ (u"࠭วๅๅ๋ีุอสࠡษ็ฮ฾๊๊ๆ์ฬࠫ৉"),l11ll1_l1_ (u"ࠧษำส้ัࠦวๅฬุ้๏๋ࠧ৊"),l11ll1_l1_ (u"ࠨษ็฽ฬฮࠠใฬส่ࠬো"),l11ll1_l1_ (u"ࠩส่฾อศࠡษ็็๊ฮ๊้ฬิࠤࡕࡉࠧৌ"),l11ll1_l1_ (u"ࠪห้ฮัศ็ฯ্ࠫ")]
l1l11l_l1_ = [l11ll1_l1_ (u"๊ࠫ฻วา฻ฬࠫৎ")]
def MAIN(mode,url,text):
	if   mode==350: results = MENU(url)
	elif mode==351: results = l11111_l1_(url,text)
	elif mode==352: results = l1llll11_l1_(url)
	elif mode==353: results = PLAY(url)
	elif mode==354: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ৏")+text)
	elif mode==355: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭৐")+text)
	elif mode==356: results = l1l1lll1_l1_(url)
	elif mode==357: results = l11l1l1l_l1_(url)
	elif mode==359: results = SEARCH(text)
	else: results = False
	return results
def MENU(l1l1l11l_l1_=l11ll1_l1_ (u"ࠧࠨ৑")):
	if l1l1l11l_l1_==l11ll1_l1_ (u"ࠨࠩ৒"):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ৓"),l111l1_l1_+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ৔"),l11ll1_l1_ (u"ࠫࠬ৕"),8)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ৖"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ৗ"),l11ll1_l1_ (u"ࠧࠨ৘"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ৙"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ৚"),l11ll1_l1_ (u"ࠪࠫ৛"),359,l11ll1_l1_ (u"ࠫࠬড়"),l11ll1_l1_ (u"ࠬ࠭ঢ়"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ৞"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧয়"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫৠ"),l11l1l_l1_,356)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩৡ"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭ৢ"),l11l1l_l1_,357)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩৣ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ৤"),l11ll1_l1_ (u"࠭ࠧ৥"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ০"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ১")+l111l1_l1_+l11ll1_l1_ (u"ࠩสุ่๊๊ะࠩ২"),l11l1l_l1_,352,l11ll1_l1_ (u"ࠪࠫ৩"),l11ll1_l1_ (u"ࠫࠬ৪"),l11ll1_l1_ (u"ࠬࡳ࡯ࡳࡧࠪ৫"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭৬"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ৭")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็หำฮวาࠩ৮"),l11l1l_l1_,352,l11ll1_l1_ (u"ࠩࠪ৯"),l11ll1_l1_ (u"ࠪࠫৰ"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡴࠩৱ"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭৲"),headers,l11ll1_l1_ (u"࠭ࠧ৳"),l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ৴"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡴࡨࡧࡪࡴࡴ࡭ࡻ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৵"),html,re.DOTALL)
	if l111lll_l1_: l111lll_l1_ = l111lll_l1_[0]
	else: l111lll_l1_ = l11l1l_l1_
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৶"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ৷")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ฼๊โࠢะำ๏ัวࠨ৸"),l111lll_l1_,351)
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡆࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ৹"),html,re.DOTALL)
	if l111lll_l1_: l111lll_l1_ = l111lll_l1_[0]
	else: l111lll_l1_ = l11l1l_l1_
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭৺"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ৻")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩৼ"),l111lll_l1_,351,l11ll1_l1_ (u"ࠩࠪ৽"),l11ll1_l1_ (u"ࠪࠫ৾"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭৿"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠩ਀"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡱࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨਁ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title not in l1l11l_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧਂ"),l111l1_l1_+title,l1lllll_l1_,351)
		if l1l1l11l_l1_==l11ll1_l1_ (u"ࠨࠩਃ"): addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ਄"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਅ"),l11ll1_l1_ (u"ࠫࠬਆ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡥࡳࡽ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫਇ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩਈ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			if title not in l1l11l_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧਉ"),l111l1_l1_+title,l1lllll_l1_,351)
	return html
def l1l1lll1_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"ࠨࠩਊ")):
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ਋"),headers,l11ll1_l1_ (u"ࠪࠫ਌"),l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ਍"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽ࡰࡤࡺࠬ਎"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧਏ"),l11ll1_l1_ (u"ࠧࠨਐ"),l1lllll_l1_,l1l1l11_l1_][0])
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ਑"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ਒"),l11ll1_l1_ (u"ࠪࠫਓ"),l1lllll_l1_,title)
			if title not in l1l11l_l1_:
				title = title+l11ll1_l1_ (u"๋ࠫࠥี็ใฬࠫਔ")
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਕ"),l111l1_l1_+title,l1lllll_l1_,355)
		if l1l1l11l_l1_==l11ll1_l1_ (u"࠭ࠧਖ"): addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬਗ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨਘ"),l11ll1_l1_ (u"ࠩࠪਙ"),9999)
	return html
def l11l1l1l_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"ࠪࠫਚ")):
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬਛ"),headers,l11ll1_l1_ (u"ࠬ࠭ਜ"),l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪਝ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧਞ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨਟ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title not in l1l11l_l1_:
				title = title+l11ll1_l1_ (u"้ࠩࠣๆ๊สาหࠪਠ")
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪਡ"),l111l1_l1_+title,l1lllll_l1_,354)
		if l1l1l11l_l1_==l11ll1_l1_ (u"ࠫࠬਢ"): addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪਣ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ਤ"),l11ll1_l1_ (u"ࠧࠨਥ"),9999)
	return html
def l11111_l1_(url,type=l11ll1_l1_ (u"ࠨࠩਦ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪਧ"),l11ll1_l1_ (u"ࠪࠫਨ"),url,type)
	html = OPENURL_CACHED(NO_CACHE,url,l11ll1_l1_ (u"ࠫࠬ਩"),headers,True,l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫਪ"))
	if type==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨਫ"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡹ࡬ࡴࡪࡸ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠫ࠲࠯ࡅࠩࡴࡹ࡬ࡴࡪࡸ࠭ࡣࡷࡷࡸࡴࡴ࠭ࡱࡴࡨࡺࠬਬ"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡧࡱࡲࡸࡪࡸࠧਭ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡻࡰ࡮ࡴ࡫࠻ࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨਮ"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫਯ"),l11ll1_l1_ (u"ࠫࠬਰ"),str(len(block)),url)
		l11l_l1_ = []
		for l1lll1_l1_,l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			if l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ਱") in title or l11ll1_l1_ (u"࠭วๅฯ็ๆ์࠭ਲ") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡞ࡧ࠯ࠬਲ਼"),title,re.DOTALL)
				if l1ll1l1_l1_:
					title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ਴") + l1ll1l1_l1_[0][0]
					if title not in l11l_l1_:
						addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਵ"),l111l1_l1_+title,l1lllll_l1_,352,l1lll1_l1_)
						l11l_l1_.append(title)
			elif l11ll1_l1_ (u"ุ้๊ࠪำๅࠩਸ਼") in title:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ਷"),l111l1_l1_+title,l1lllll_l1_,352,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫਸ"),l111l1_l1_+title,l1lllll_l1_,353,l1lll1_l1_)
			#if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨਹ") in l1lllll_l1_ or l11ll1_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡼࡹ࠯ࠨ਺") in l1lllll_l1_:
			#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ਻"),l111l1_l1_+title,l1lllll_l1_,352,l1lll1_l1_)
			#elif l11ll1_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰࡷ࠴਼࠭") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡦࡵ࠲ࠫ਽") not in l1lllll_l1_:
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬਾ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨਿ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"࠭ࠦ࡭ࡵࡤࡵࡺࡵ࠻ࠨੀ") in title: title = l11ll1_l1_ (u"ࠧึใะอูࠥวษไฬࠫੁ")
			#if l11ll1_l1_ (u"ࠨࠨࡵࡷࡦࡷࡵࡰ࠽ࠪੂ") in title: title = l11ll1_l1_ (u"ุࠩๅาฯࠠๅษะๆฮ࠭੃")
			#if l11ll1_l1_ (u"ࠪࠪࡱࡧࡱࡶࡱࠪ੄") in title: title = l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊สศๆํอࠬ੅")
			#if l11ll1_l1_ (u"ࠬ฻แฮหࠪ੆") not in title: title = l11ll1_l1_ (u"࠭ีโฯฬࠤࠬੇ")+title
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧੈ"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ੉")+title,l1lllll_l1_,351)
	return
def SEARCH(search):
	# https://l11l1lll_l1_.net/search?q=%l11ll111_l1_%l1l1l1ll_l1_%l11ll111_l1_%l1ll111l_l1_%l11ll111_l1_%l1l11lll_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ੊"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫੋ"): return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭ੌ"),l11ll1_l1_ (u"ࠬ࠱੍ࠧ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡀࡵࡀࠫ੎")+l1111ll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ੏"),l11ll1_l1_ (u"ࠨࠩ੐"),url,l11ll1_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࡡࡄࡏࡔࡇࡍࠨੑ"))
	results = l11111_l1_(url)
	return
def l1llll11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ੒"),l11ll1_l1_ (u"ࠫࠬ੓"),url,l11ll1_l1_ (u"ࠬࡋࡐࡊࡕࡒࡈࡊ࡙࡟ࡂࡍ࡚ࡅࡒ࠭੔"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"࠭ࠧ੕"),headers,True,l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ੖"))
	#if l11ll1_l1_ (u"ࠨ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ੗") not in html:
	#	l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ੘"))
	#	addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩਖ਼"),l111l1_l1_+l11ll1_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪਗ਼"),url,353,l1lll1_l1_)
	#else:
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁห้ำไใษอࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࠩਜ਼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩੜ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in l1l11_l1_:
			if l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ੝") in title or l11ll1_l1_ (u"ࠨษ็ั้่็ࠨਫ਼") in title: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ੟"),l111l1_l1_+title,l1lllll_l1_,353,l1lll1_l1_)
			#else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ੠"),l111l1_l1_+title,l1lllll_l1_,352,l1lll1_l1_)
	else:
		l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ੡"))
		if html.count(l11ll1_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠭੢"))>1: title = re.findall(l11ll1_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭੣"),html,re.DOTALL)[1]
		else: title = l11ll1_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭੤")
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ੥"),l111l1_l1_+title,url,353,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1lll111_l1_ = [],[]
	l1ll1l1l_l1_ = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭੦"),url,l11ll1_l1_ (u"ࠪࠫ੧"),l11ll1_l1_ (u"ࠫࠬ੨"),l11ll1_l1_ (u"ࠬ࠭੩"),l11ll1_l1_ (u"࠭ࠧ੪"),l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ੫"))
	html = l1ll1l1l_l1_.content
	l11ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ੬"),html,re.DOTALL)
	if l11ll1ll_l1_:
		l11ll1ll_l1_ = l11ll1ll_l1_[0]
		headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭੭"):l11ll1_l1_ (u"ࠪࠫ੮"),l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ੯"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫੰ")}
		data = {l11ll1_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧੱ"):l11ll1ll_l1_}
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡧࡦ࡭ࡣࡰ࠼ࡰࡱ࡫࠰ࡋࡱࡧ࠴ࡇࡪࡢࡺ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲࡛ࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ੲ")
		l1l11111_l1_ = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ੳ"),l111lll_l1_,data,headers,l11ll1_l1_ (u"ࠩࠪੴ"),l11ll1_l1_ (u"ࠪࠫੵ"),l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ੶"))
		l11ll1l1_l1_ = l1l11111_l1_.content
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ੷"),l11ll1l1_l1_,re.DOTALL)
		for l11lll1l_l1_,name in items:
			#data = {l11ll1_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧ੸"):l11ll1ll_l1_,l11ll1_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ੹"):l11lll1l_l1_}
			l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠲ࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳ࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡦ࡬࡬ࡢ࡯࠻࡯ࡰࡱ࠯ࡊࡰࡦ࠳ࡆࡰࡡࡹ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭੺")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡴࡴࡹࡴࡪࡦࡀࠫ੻")+l11ll1ll_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ੼")+l11lll1l_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ੽")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭੾")
			l1llll_l1_.append(l1lllll_l1_)
			l1lll111_l1_.append(name)
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡦ࡬࡬ࡢ࡯࠻࡯ࡰࡱ࠯ࡊࡰࡦ࠳ࡆࡰࡡࡹ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵ࡮ࡰࠨ੿")
		l1l11111_l1_ = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ઀"),l111lll_l1_,data,headers,l11ll1_l1_ (u"ࠨࠩઁ"),l11ll1_l1_ (u"ࠩࠪં"),l11ll1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧઃ"))
		l11ll1l1_l1_ = l1l11111_l1_.content
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ઄"),l11ll1l1_l1_,re.DOTALL)
		for l1lllll_l1_,title in items:
			#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭અ"),l11ll1_l1_ (u"࠭ࠧઆ"),l1lllll_l1_,title)
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩઇ"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩઈ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ઉ")
			l1llll_l1_.append(l1lllll_l1_)
			l1lll111_l1_.append(title)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩઊ"),url)
	return
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ઋ"),l11ll1_l1_ (u"ࠬ࠭ઌ"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧઍ"),l11ll1_l1_ (u"ࠧࠨ઎"),filter,url)
	l1l11l11_l1_ = [l11ll1_l1_ (u"ࠨࡥࡤࡸࠬએ"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨઐ"),l11ll1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩઑ"),l11ll1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ઒"),l11ll1_l1_ (u"ࠬࡵࡲࡥࡧࡵࡦࡾ࠭ઓ")]
	if l11ll1_l1_ (u"࠭࠿ࠨઔ") in url: url = url.split(l11ll1_l1_ (u"ࠧࡀࠩક"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬખ"),1)
	if filter==l11ll1_l1_ (u"ࠩࠪગ"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠪࠫઘ"),l11ll1_l1_ (u"ࠫࠬઙ")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩચ"))
	if type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪછ"):
		if l1l11l11_l1_[0]+l11ll1_l1_ (u"ࠧ࠾ࠩજ") not in l1l111l1_l1_: category = l1l11l11_l1_[0]
		for i in range(len(l1l11l11_l1_[0:-1])):
			if l1l11l11_l1_[i]+l11ll1_l1_ (u"ࠨ࠿ࠪઝ") in l1l111l1_l1_: category = l1l11l11_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫઞ")+category+l11ll1_l1_ (u"ࠪࡁ࠵࠭ટ")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠫࠫ࠭ઠ")+category+l11ll1_l1_ (u"ࠬࡃ࠰ࠨડ")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨઢ"))+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫણ")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪત"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭થ"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠪࡃࠬદ")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬધ"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧન"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"࠭ࠧ઩"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫપ"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠨࠩફ"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠩࡂࠫબ")+l1l1111l_l1_
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪભ"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬ࠭મ"),l111lll_l1_,351,l11ll1_l1_ (u"ࠬ࠭ય"),l11ll1_l1_ (u"࠭࠱ࠨર"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ઱"),l111l1_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨલ")+l11ll11l_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨળ"),l111lll_l1_,351,l11ll1_l1_ (u"ࠪࠫ઴"),l11ll1_l1_ (u"ࠫ࠶࠭વ"))
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪશ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ષ"),l11ll1_l1_ (u"ࠧࠨસ"),9999)
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠨࠩહ"),headers,True,l11ll1_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ઺"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢ࡬ࡨ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ઻"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀ઼ࠪ"),block,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ઽ"),l11ll1_l1_ (u"࠭ࠧા"),l11ll1_l1_ (u"ࠧࠨિ"),str(l1ll1ll1_l1_))
	dict = {}
	for l1ll1l11_l1_,name,block in l1ll1ll1_l1_:
		#name = name.replace(l11ll1_l1_ (u"ࠨ࠯࠰ࠫી"),l11ll1_l1_ (u"ࠩࠪુ"))
		items = re.findall(l11ll1_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡀࠫ࠲࠯ࡅࠩ࠽ࠩૂ"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠫࡂ࠭ૃ") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩૄ"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<=1:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ૅ")+l1l11ll1_l1_)
				return
			else:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૆"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨે"),l111lll_l1_,351,l11ll1_l1_ (u"ࠩࠪૈ"),l11ll1_l1_ (u"ࠪ࠵ࠬૉ"))
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ૊"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬો"),l111lll_l1_,355,l11ll1_l1_ (u"࠭ࠧૌ"),l11ll1_l1_ (u"ࠧࠨ્"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ૎"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫ૏")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁ࠵࠭ૐ")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠫࠫ࠭૑")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ૒")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ૓")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૔"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠣࠫ૕")+name,l111lll_l1_,354,l11ll1_l1_ (u"ࠩࠪ૖"),l11ll1_l1_ (u"ࠪࠫ૗"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭૘"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			if option in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ૙") not in value: value = option
			else: value = re.findall(l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૚"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩ૛")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ૜")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠩࠩࠫ૝")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁࠬ૞")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ૟")+l1l1ll11_l1_
			title = option+l11ll1_l1_ (u"ࠬࠦ࠺ࠡࠩૠ")#+dict[l1ll1l11_l1_][l11ll1_l1_ (u"࠭࠰ࠨૡ")]
			title = option+l11ll1_l1_ (u"ࠧࠡ࠼ࠣࠫૢ")+name
			if type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩૣ"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ૤"),l111l1_l1_+title,url,354,l11ll1_l1_ (u"ࠪࠫ૥"),l11ll1_l1_ (u"ࠫࠬ૦"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ૧"))
			elif type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ૨") and l1l11l11_l1_[-2]+l11ll1_l1_ (u"ࠧ࠾ࠩ૩") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ૪"))
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠩࡂࠫ૫")+l11llll1_l1_
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ૬"),l111l1_l1_+title,l11l111_l1_,351,l11ll1_l1_ (u"ࠫࠬ૭"),l11ll1_l1_ (u"ࠬ࠷ࠧ૮"))
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭૯"),l111l1_l1_+title,url,355,l11ll1_l1_ (u"ࠧࠨ૰"),l11ll1_l1_ (u"ࠨࠩ૱"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ૲"),l11ll1_l1_ (u"ࠪࠫ૳"),filters,l11ll1_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬ૴"))
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ૵")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ૶")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫ૷")					all filters (l11lll11_l1_ l1l1l1l1_l1_ filter)
	#filters = filters.replace(l11ll1_l1_ (u"ࠨ࠿ࠩࠫ૸"),l11ll1_l1_ (u"ࠩࡀ࠴ࠫ࠭ૹ"))
	filters = filters.strip(l11ll1_l1_ (u"ࠪࠪࠬૺ"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"ࠫࡂ࠭ૻ") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠬࠬࠧૼ"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"࠭࠽ࠨ૽"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"ࠧࠨ૾")
	l1ll1111_l1_ = [l11ll1_l1_ (u"ࠨࡥࡤࡸࠬ૿"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ଀"),l11ll1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩଁ"),l11ll1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬଂ"),l11ll1_l1_ (u"ࠬࡵࡲࡥࡧࡵࡦࡾ࠭ଃ")]
	for key in l1ll1111_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"࠭࠰ࠨ଄")
		#if l11ll1_l1_ (u"ࠧࠦࠩଅ") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪଆ") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫଇ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠤ࠰ࠦࠧଈ")+value
		elif mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧଉ") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧଊ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨଋ")+key+l11ll1_l1_ (u"ࠧ࠾ࠩଌ")+value
		elif mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ଍"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫ଎")+key+l11ll1_l1_ (u"ࠪࡁࠬଏ")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨଐ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧ଑"))
	#l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"࠭࠽࠱ࠩ଒"),l11ll1_l1_ (u"ࠧ࠾ࠩଓ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩଔ"),l11ll1_l1_ (u"ࠩࠪକ"),filters,l11ll1_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫଖ"))
	return l1ll11l1_l1_
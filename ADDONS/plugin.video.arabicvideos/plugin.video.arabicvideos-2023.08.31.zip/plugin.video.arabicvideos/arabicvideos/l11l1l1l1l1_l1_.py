# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ恛")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭恜")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨไ้์ฬะࠠโุสส๏ฯࠧ恝"),l11ll1_l1_ (u"ࠩไหึูใ้ࠩ恞"),l11ll1_l1_ (u"ࠪࡗ࡭ࡵࡷࠡ࡯ࡲࡶࡪ࠭恟")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l11111_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1llll11_l1_(url,text)
	elif mode==584: results = l1l111_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ恠"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭恡"),l11ll1_l1_ (u"࠭ࠧ恢"),l11ll1_l1_ (u"ࠧࠨ恣"),l11ll1_l1_ (u"ࠨࠩ恤"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ恥"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ恦"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ恧"),l11ll1_l1_ (u"ࠬ࠭恨"),589,l11ll1_l1_ (u"࠭ࠧ恩"),l11ll1_l1_ (u"ࠧࠨ恪"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ恫"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ恬"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恭"),l11ll1_l1_ (u"ࠫࠬ恮"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ息"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ恰"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠧࠨ恱"))
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭恲"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ恳"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ恴")+l111l1_l1_+title,l1lllll_l1_,584)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ恵"),url,l11ll1_l1_ (u"ࠬ࠭恶"),l11ll1_l1_ (u"࠭ࠧ恷"),l11ll1_l1_ (u"ࠧࠨ恸"),l11ll1_l1_ (u"ࠨࠩ恹"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ恺"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ恻"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ恼"),l11ll1_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ恽"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ恾"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠧࠨ恿"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭悀"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ悁"),l11ll1_l1_ (u"ࠪࠫ悂"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ悃"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠬࡀࠠࠨ悄")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭悅"),l111l1_l1_+title,l1lllll_l1_,581)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ悆"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ悇"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ悈"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ悉"),l11ll1_l1_ (u"ࠫࠬ悊"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悋"),l111l1_l1_+title,l1lllll_l1_,581)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"࠭ࠧ悌")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ悍"),l11ll1_l1_ (u"ࠨࠩ悎"),request,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭悏"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ悐"),url,l11ll1_l1_ (u"ࠫࠬ悑"),l11ll1_l1_ (u"ࠬ࠭悒"),l11ll1_l1_ (u"࠭ࠧ悓"),l11ll1_l1_ (u"ࠧࠨ悔"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ悕"))
	html = response.content
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ悖"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪ悗"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭悘"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ悙"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ悚"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ悛"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ悜"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ悝"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ悞"),l11ll1_l1_ (u"่๊๊ࠫษࠩ悟"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ悠"),l11ll1_l1_ (u"࠭็ะษไࠫ悡"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ悢"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ患"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ悤"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ悥"),l11ll1_l1_ (u"ู๊ࠫัฮ์ฬࠫ悦")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ悧"))
		if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ您") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ悩")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ悪"))
		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ悫") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ悬")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭悭"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ悮"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ悯"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭悰"),l111l1_l1_+title,l1lllll_l1_,582,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ悱") in title:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ悲") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悳"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ悴") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悵"),l111l1_l1_+title,l1lllll_l1_,581,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭悶"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
	if request not in [l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ悷"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ悸")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ悹"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ悺"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭悻"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ悼")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ悽"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ悾"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ悿")+title,l1lllll_l1_,581)
		l1llll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ惀"),html,re.DOTALL)
		if l1llll1l1l_l1_:
			l1lllll_l1_ = l1llll1l1l_l1_[0]
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ惁"),l111l1_l1_+l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ惂"),l1lllll_l1_,581)
	return
def l1llll11_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭惃"),l11ll1_l1_ (u"࠭ࠧ惄"),l1l1l_l1_,url)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ情"),l11ll1_l1_ (u"ࠨ࠳࠴࠵࠶ࠦࠠࠨ惆")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭惇"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ惈"),url,l11ll1_l1_ (u"ࠫࠬ惉"),l11ll1_l1_ (u"ࠬ࠭惊"),l11ll1_l1_ (u"࠭ࠧ惋"),l11ll1_l1_ (u"ࠧࠨ惌"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ惍"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡱࡥࡻ࠳ࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ惎"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ惏"),str(l1l1l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ惐"),str(l1l111l_l1_))
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ惑"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"࠭ࠣࠨ惒"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ惓"),l111l1_l1_+title,url,583,l11ll1_l1_ (u"ࠨࠩ惔"),l11ll1_l1_ (u"ࠩࠪ惕"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ惖")+l1l1l_l1_+l11ll1_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ惗"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ惘"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ惙")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ惚"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ惛"),l111l1_l1_+title,l1lllll_l1_,582)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ惜"),block,re.DOTALL)
			for l1lllll_l1_,title,l1lll1_l1_ in items:
				if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ惝") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭惞")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ惟"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ惠"),l111l1_l1_+title,l1lllll_l1_,582)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ惡"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ惢"),url,l11ll1_l1_ (u"ࠩࠪ惣"),l11ll1_l1_ (u"ࠪࠫ惤"),l11ll1_l1_ (u"ࠫࠬ惥"),l11ll1_l1_ (u"ࠬ࠭惦"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ惧"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ惨"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭惩") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ惪")+l1lllll_l1_
	#//www.l1lll111lllll_l1_.l1lll111llll1_l1_/l1lll11l11111_l1_/?l1lll11l1111l_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1lllll_l1_.split(l11ll1_l1_ (u"ࠪ࡬ࡦࡹࡨ࠾ࠩ惫"))[1]
	parts = hash.split(l11ll1_l1_ (u"ࠫࡤࡥࠧ惬"))
	l1l11lllllll_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11ll1_l1_ (u"ࠬࡃࠧ惭"))
			if kodi_version>18.99: part = part.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ惮"))
			l1l11lllllll_l1_.append(part)
		except: pass
	l1l1_l1_ = l11ll1_l1_ (u"ࠧ࠿ࠩ惯").join(l1l11lllllll_l1_)
	l1l1_l1_ = l1l1_l1_.splitlines()
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ惰"),str(l1l1_l1_))
	if l11ll1_l1_ (u"ࠩࡩࡥࡷࡹ࡯࡭ࠩ惱") not in str(l1l1_l1_):
		for l1lllll_l1_ in l1l1_l1_:
			title,l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠪࠤࡂࡄࠠࠨ惲"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ想")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭惴")
			l1llll_l1_.append(l1lllll_l1_)
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ惵"),l1llll_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭惶"),url)
	else:
		title,l1lllll_l1_ = l1l1_l1_[0].split(l11ll1_l1_ (u"ࠨࠢࡀࡂࠥ࠭惷"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ惸"),l11ll1_l1_ (u"ࠪࠫ惹"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ惺"),l11ll1_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫ惻")+l11ll1_l1_ (u"࠭࡜࡯ࠩ惼")+l11ll1_l1_ (u"๋ࠧำฯํࠥอไๆฯส์้ฯࠠๅษะๆฬ࠭惽")+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭惾")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ惿"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ愀"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭愁"),l11ll1_l1_ (u"ࠬ࠱ࠧ愂"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ愃")+search
	l11111_l1_(url)
	return
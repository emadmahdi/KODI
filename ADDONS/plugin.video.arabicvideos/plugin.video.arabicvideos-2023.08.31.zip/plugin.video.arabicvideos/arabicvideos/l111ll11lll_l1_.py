# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ愄")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ愅")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭愆"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11111_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1lll111lll11_l1_(url)
	elif mode==314: results = l1llll1l1_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愇"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ愈"),l11ll1_l1_ (u"ࠬ࠭愉"),319,l11ll1_l1_ (u"࠭ࠧ愊"),l11ll1_l1_ (u"ࠧࠨ愋"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ愌"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ愍"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠨ愎"),l11ll1_l1_ (u"ࠫࠬ意"),114,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ愐"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ愑"),l11ll1_l1_ (u"ࠧࠨ愒"),l11ll1_l1_ (u"ࠨࠩ愓"),l11ll1_l1_ (u"ࠩࠪ愔"),l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ愕"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ愖"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ愗"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭愘"),l11ll1_l1_ (u"ࠧࠨ愙"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡫࠹ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠵࠿ࠩ愚"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11ll1_l1_ (u"ࠩࠣࠫ愛"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愜"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭愝")+l111l1_l1_+title,l11l1l_l1_,314,l11ll1_l1_ (u"ࠬ࠭愞"),l11ll1_l1_ (u"࠭ࠧ感"),str(seq+1))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ愠"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ愡")+l111l1_l1_+l11ll1_l1_ (u"่ࠩๆฬ฽ูࠡึ๊ีࠬ愢"),l11l1l_l1_,314,l11ll1_l1_ (u"ࠪࠫ愣"),l11ll1_l1_ (u"ࠫࠬ愤"),l11ll1_l1_ (u"ࠬ࠶ࠧ愥"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ愦"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ愧"),l11ll1_l1_ (u"ࠨࠩ愨"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡇࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂ࠿ࠩ愩"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ愪")+l1lllll_l1_
		#title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭愫"))
		#url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫ愬")
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭愭"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ愮")+l111l1_l1_+title,l1lllll_l1_,311)
	return html
def l1llll1l1_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ愯"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ愰"),l11ll1_l1_ (u"ࠪࠫ愱"),l11ll1_l1_ (u"ࠫࠬ愲"),l11ll1_l1_ (u"ࠬ࠭愳"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭愴"))
	html = response.content
	if seq==l11ll1_l1_ (u"ࠧ࠱ࠩ愵"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭愶"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ愷"),block,re.DOTALL)
		for l1lllll_l1_,name,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ愸")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭愹"))
			name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ愺"))
			title = title+l11ll1_l1_ (u"࠭ࠠࠩࠩ愻")+name+l11ll1_l1_ (u"ࠧࠪࠩ愼")
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ愽"),l111l1_l1_+title,l1lllll_l1_,312)
	elif seq in [l11ll1_l1_ (u"ࠩ࠴ࠫ愾"),l11ll1_l1_ (u"ࠪ࠶ࠬ愿"),l11ll1_l1_ (u"ࠫ࠸࠭慀")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ慁"),html,re.DOTALL)
		l1lll111ll1ll_l1_ = int(seq)-1
		block = l1l1l11_l1_[l1lll111ll1ll_l1_]
		if seq==l11ll1_l1_ (u"࠭࠱ࠨ慂"): items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ慃"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ慄"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,name in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ慅")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ慆")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭慇"))
			name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ慈"))
			title = title+l11ll1_l1_ (u"࠭ࠠࠩࠩ慉")+name+l11ll1_l1_ (u"ࠧࠪࠩ慊")
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ態"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	elif seq in [l11ll1_l1_ (u"ࠩ࠷ࠫ慌"),l11ll1_l1_ (u"ࠪ࠹ࠬ慍"),l11ll1_l1_ (u"ࠫ࠻࠭慎")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ慏"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1l11_l1_[seq]
		items = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ慐"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,l1l1ll1111l_l1_,title,l1ll1lll1l1_l1_ in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ慑")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ慒")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ慓"))
			l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ慔"))
			l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠭慕"))
			if l1l1ll1111l_l1_: name = l1l1ll1111l_l1_
			else: name = l1ll1lll1l1_l1_
			title = title+l11ll1_l1_ (u"ࠬࠦࠨࠨ慖")+name+l11ll1_l1_ (u"࠭ࠩࠨ慗")
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭慘"),l111l1_l1_+title,l1lllll_l1_,312,l1lll1_l1_)
	return
def l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ慙"),url,l11ll1_l1_ (u"ࠩࠪ慚"),l11ll1_l1_ (u"ࠪࠫ慛"),l11ll1_l1_ (u"ࠫࠬ慜"),l11ll1_l1_ (u"ࠬ࠭慝"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭慞"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ慟"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	if l11ll1_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ慠") in block:
		items = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ慡"),block,re.DOTALL)
		if items:
			for l1lll1_l1_,l1lllll_l1_,title,count in items:
				l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ慢")+l1lll1_l1_
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࠭慣")+l1lllll_l1_
				count = count.replace(l11ll1_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ慤"),l11ll1_l1_ (u"࠭࠺ࠨ慥"))
				title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ慦"))
				title = title+l11ll1_l1_ (u"ࠨࠢࠫࠫ慧")+count+l11ll1_l1_ (u"ࠩࠬࠫ慨")
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ慩"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	else:
		items = re.findall(l11ll1_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ慪"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll111lll1l_l1_,l1l11ll1l_l1_ in items:
			if title==l11ll1_l1_ (u"ࠬ࠭慫") or l1lll111lll1l_l1_==l11ll1_l1_ (u"࠭ࠧ慬"): continue
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ慭")+l1lllll_l1_
			title = title+l11ll1_l1_ (u"ࠨࠢࠫࠫ慮")+l1l11ll1l_l1_+l11ll1_l1_ (u"ࠩࠬࠫ慯")
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ慰"),l111l1_l1_+title,l1lllll_l1_,312)
	if not items: l1llll11_l1_(html)
	return
def l1llll11_l1_(html):
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ慱"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ慲"),block,re.DOTALL)
	for l1lllll_l1_,title,name,count,l1l11ll1l_l1_ in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ慳")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ慴"))
		name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ慵"))
		title = title+l11ll1_l1_ (u"ࠩࠣࠬࠬ慶")+name+l11ll1_l1_ (u"ࠪ࠭ࠬ慷")
		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ慸"),l111l1_l1_+title,l1lllll_l1_,312,l11ll1_l1_ (u"ࠬ࠭慹"),l1l11ll1l_l1_)
	return
def l1lll111lll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ慺"),url,l11ll1_l1_ (u"ࠧࠨ慻"),l11ll1_l1_ (u"ࠨࠩ慼"),l11ll1_l1_ (u"ࠩࠪ慽"),l11ll1_l1_ (u"ࠪࠫ慾"),l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ慿"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭憀"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l11111_l1_(url)
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ憁"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ憂")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ憃"))
		if l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ憄") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ憅"),l111l1_l1_+title,l1lllll_l1_,312)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ憆"),l111l1_l1_+title,l1lllll_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ憇"),url,l11ll1_l1_ (u"࠭ࠧ憈"),l11ll1_l1_ (u"ࠧࠨ憉"),l11ll1_l1_ (u"ࠨࠩ憊"),l11ll1_l1_ (u"ࠩࠪ憋"),l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ憌"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ憍"),html,re.DOTALL)
	if not l1lllll_l1_: l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ憎"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ憏"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ憐"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ憑"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ憒"),l11ll1_l1_ (u"ࠪ࠯ࠬ憓"))
	l11llllll111_l1_ = [l11ll1_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ憔"),l11ll1_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ憕"),l11ll1_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ憖")]
	if l1ll_l1_:
		l1l1111l1lll_l1_ = [l11ll1_l1_ (u"ࠧใษิสࠬ憗"),l11ll1_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ憘"),l11ll1_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ憙")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ憚"), l1l1111l1lll_l1_)
		if l1l_l1_ == -1: return
	elif l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ憛") in options: l1l_l1_ = 0
	elif l11ll1_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ憜") in options: l1l_l1_ = 1
	elif l11ll1_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ憝") in options: l1l_l1_ = 2
	else: return
	type = l11llllll111_l1_[l1l_l1_]
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ憞")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ憟"),url,l11ll1_l1_ (u"ࠩࠪ憠"),l11ll1_l1_ (u"ࠪࠫ憡"),l11ll1_l1_ (u"ࠫࠬ憢"),l11ll1_l1_ (u"ࠬ࠭憣"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭憤"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ憥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ憦"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ憧"))
				name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ憨"))
				title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ憩")+name+l11ll1_l1_ (u"ࠬ࠯ࠧ憪")
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭憫"),l111l1_l1_+title,l1lllll_l1_,313,l1lll1_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭憬"),block,re.DOTALL)
			for l1lllll_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ憭"))
				name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ憮"))
				title = title+l11ll1_l1_ (u"ࠪࠤ࠭࠭憯")+name+l11ll1_l1_ (u"ࠫ࠮࠭憰")
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ憱"),l111l1_l1_+title,l1lllll_l1_,312)
	return
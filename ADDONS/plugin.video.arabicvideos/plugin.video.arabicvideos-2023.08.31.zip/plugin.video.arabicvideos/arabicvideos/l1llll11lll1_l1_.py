# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ摃")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ摄")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧษอ้ࠣออิาࠩ摅")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l11111_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llll11_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ摆"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ摇"),l11ll1_l1_ (u"ࠪࠫ摈"),l11ll1_l1_ (u"ࠫࠬ摉"),l11ll1_l1_ (u"ࠬ࠭摊"),l11ll1_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ摋"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ摌"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ摍"),l11ll1_l1_ (u"ࠩࠪ摎"),469,l11ll1_l1_ (u"ࠪࠫ摏"),l11ll1_l1_ (u"ࠫࠬ摐"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ摑"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭摒"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ摓")+l111l1_l1_+l11ll1_l1_ (u"ࠨลัีࠥอไฮๆๅหฯ࠭摔"),l11l1l_l1_,461,l11ll1_l1_ (u"ࠩࠪ摕"),l11ll1_l1_ (u"ࠪࠫ摖"),l11ll1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ摗"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ摘"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭摙"),l11ll1_l1_ (u"ࠧࠨ摚"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ摛"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ摜"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l1lllll_l1_==l11ll1_l1_ (u"ࠪࠧࠬ摝"): continue
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ摞") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if title==l11ll1_l1_ (u"ࠬอไาศํื๏ฯࠧ摟"): title = l11ll1_l1_ (u"࠭ฬะ์าࠤา๊โศฬࠣฮ๏็๊ࠡใส๊ࠬ摠")
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ摡"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ摢")+l111l1_l1_+title,l1lllll_l1_,461)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡊࡴࡵࡴࡦࡴࡆࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ摣"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ摤"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ摥"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ摦")+l111l1_l1_+title,l1lllll_l1_,461)
	return
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"࠭ࠧ摧")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ摨"),l11ll1_l1_ (u"ࠨࠩ摩"),l1lll1l11l_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭摪"),url,l11ll1_l1_ (u"ࠪࠫ摫"),l11ll1_l1_ (u"ࠫࠬ摬"),l11ll1_l1_ (u"ࠬ࠭摭"),l11ll1_l1_ (u"࠭ࠧ摮"),l11ll1_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ摯"))
	html = response.content
	#if l1lll1l11l_l1_==l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ摰"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩฦาึࠦวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ摱"),html,re.DOTALL)
	#else:
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ摲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ摳"),block,re.DOTALL)
		l11l_l1_ = []
		l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ摴"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ摵"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭摶"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭摷"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ摸"),l11ll1_l1_ (u"๋ࠪิอแࠨ摹"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ摺"),l11ll1_l1_ (u"ࠬ฿ัืࠩ摻"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭摼"),l11ll1_l1_ (u"ࠧศๆห์๊࠭摽")]
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭摾") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)	#.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ摿"))
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭撀"),title,re.DOTALL)
			if any(value in title for value in l1ll1l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ撁"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ撂") in title:
				title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ撃") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ撄"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撅"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
	if l1lll1l11l_l1_!=l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ撆"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ撇"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ撈"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ撉"))
				if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠢ撊"): continue
				if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ撋") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠨࠩ撌"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撍"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ撎")+title,l1lllll_l1_,461)
	return
def l1llll11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ撏"),l11ll1_l1_ (u"ࠬ࠭撐"),l11ll1_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࠨ撑"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ撒"),url,l11ll1_l1_ (u"ࠨࠩ撓"),l11ll1_l1_ (u"ࠩࠪ撔"),l11ll1_l1_ (u"ࠪࠫ撕"),l11ll1_l1_ (u"ࠫࠬ撖"),l11ll1_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ撗"))
	html = response.content
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭撘"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ撙"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭撚") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ撛"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ撜"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭撝"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ撞"))
			if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠢ撟"): continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ撠") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			#title = unescapeHTML(title)
			if title!=l11ll1_l1_ (u"ࠨࠩ撡"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撢"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ撣")+title,l1lllll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ撤"),url,l11ll1_l1_ (u"ࠬ࠭撥"),l11ll1_l1_ (u"࠭ࠧ撦"),l11ll1_l1_ (u"ࠧࠨ撧"),l11ll1_l1_ (u"ࠨࠩ撨"),l11ll1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ撩"))
	html = response.content
	# l1l111l11_l1_ l1lllll_l1_
	l1111l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ撪"),html,re.DOTALL)
	if l1111l11l1_l1_:
		l1111l11l1_l1_ = l1111l11l1_l1_[0]
		if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ撫") not in l1111l11l1_l1_:
			if l11ll1_l1_ (u"ࠬ࠵࠯ࠨ撬") in l1111l11l1_l1_: l1111l11l1_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ播")+l1111l11l1_l1_
			else: l1111l11l1_l1_ = l11l1l_l1_+l1111l11l1_l1_
		l1111l11l1_l1_ = l1111l11l1_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ撮")
		l1llll_l1_.append(l1111l11l1_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ撯"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1lll1111l11l_l1_,l1lll1111l1l1_l1_ = l1l1l11_l1_[0]
		names = re.findall(l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ撰"),l1lll1111l11l_l1_,re.DOTALL)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ撱"),l1lll1111l1l1_l1_,re.DOTALL)
		l1lll1111l111_l1_ = zip(names,l1l1_l1_)
		for name,l111111111ll_l1_ in l1lll1111l111_l1_:
			l111111111ll_l1_ = l111111111ll_l1_[2:]
			if kodi_version<19: l111111111ll_l1_ = l111111111ll_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ撲"))
			l111111111ll_l1_ = base64.b64decode(l111111111ll_l1_)
			if kodi_version>18.99: l111111111ll_l1_ = l111111111ll_l1_.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ撳"))
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ撴"),l111111111ll_l1_,re.DOTALL)
			l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ撵") not in l1lllll_l1_:
			if l11ll1_l1_ (u"ࠨ࠱࠲ࠫ撶") in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ撷")+l1lllll_l1_
			else: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ撸")+name+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ撹")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ撺"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ撻"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11ll1_l1_ (u"ࠧࠡࠩ撼") in search:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ撽"),l11ll1_l1_ (u"ࠩࠪ撾"),l11ll1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ撿"),l11ll1_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ擀"))
		return
	#search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ擁"),l11ll1_l1_ (u"࠭࠭ࠨ擂"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ擃")+search
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡴ࠳ࠬ擄")+search+l11ll1_l1_ (u"ࠩ࠲ࠫ擅")
	l11111_l1_(url)
	return
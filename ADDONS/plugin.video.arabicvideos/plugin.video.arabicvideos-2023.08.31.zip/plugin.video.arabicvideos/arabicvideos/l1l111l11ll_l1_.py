# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭婕")
def MAIN(mode,text=l11ll1_l1_ (u"ࠬ࠭婖")):
	if   mode==  0: l1lll1llll1l1_l1_(text)
	elif mode==  2: l1ll111lll1l_l1_(text)
	elif mode==  3: l1llll1l11l1l_l1_()
	elif mode==  4: l1lll1ll1lll_l1_(text)
	elif mode==  5: l1lll1lll1ll1_l1_()
	elif mode==  6: l1llll1ll111l_l1_()
	elif mode==  7: l1ll1l1ll111_l1_()
	elif mode==  8: l1lll1ll1llll_l1_()
	elif mode==  9: l1lll1lll111l_l1_()
	elif mode==150: l1lll1ll111ll_l1_()
	elif mode==151: l1lll11l1ll11_l1_()
	elif mode==152: l1llll111ll1l_l1_()
	elif mode==153: l1lllll1l1111_l1_()
	elif mode==154: l1llll1lll1ll_l1_()
	elif mode==155: l1lll1llllll1_l1_()
	elif mode==156: l1lll11l1l11l_l1_()
	elif mode==157: l1llll1ll11l1_l1_()
	elif mode==158: l1llll111llll_l1_()
	elif mode==159: l1lll1l1lll11_l1_(True)
	elif mode==170: l1lll1l1lll1l_l1_()
	elif mode==171: l1llll11lll11_l1_()
	elif mode==172: l1lll1l11ll1l_l1_(text,True,True)
	elif mode==173: l11l1l11ll1_l1_(l11ll1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭婗"),True)
	elif mode==174: l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ婘"),True)
	elif mode==175: l1llll1111l1l_l1_()
	elif mode==176: l1lll1l11lll1_l1_()
	elif mode==177: l1llll1lll111_l1_(l11ll1_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ婙"))
	elif mode==178: l1llll1lll111_l1_(l11ll1_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭婚"))
	elif mode==179: l1llll1lll111_l1_(l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ婛"))
	elif mode==190: l1lll1llll11l_l1_()
	elif mode==191: l1lll1l1111l1_l1_()
	elif mode==192: l1lll1l11llll_l1_()
	elif mode==193: l1llll11llll1_l1_()
	elif mode==194: l1lll1l11l1l1_l1_()
	elif mode==195: l1lll1ll111l1_l1_()
	elif mode==196: l1lll1lll1l1l_l1_()
	elif mode==197: l1lll1ll1l11l_l1_()
	elif mode==198: l1llll11ll1l1_l1_()
	elif mode==199: l1lll1ll11lll_l1_()
	elif mode==340: l1lll11llll11_l1_(text)
	elif mode==341: l1l1l1llll1l_l1_()
	elif mode==342: l1llll111111l_l1_()
	elif mode==343: l1lll1ll1l1l1_l1_()
	elif mode==344: l1lll1l1111ll_l1_(True)
	elif mode==345: l1llll11l11ll_l1_()
	elif mode==346: l1l11l1111l_l1_(False)
	elif mode==347: l1l1l1ll111l_l1_(True)
	elif mode==348: l1llll11lll1l_l1_()
	elif mode==349: l1llll1l1l1ll_l1_(l1l11l1ll1l1_l1_)
	elif mode==500: l1lll1l111l11_l1_()
	elif mode==501: l1lll11ll1l1l_l1_()
	elif mode==502: l1llll11ll11l_l1_(l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ婜"),True)
	elif mode==503: l1llll1l1l1ll_l1_(l1l111ll111_l1_)
	elif mode==504: l1llll1l1l1ll_l1_(favoritesfile)
	elif mode==505: l1llll11111ll_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1lll1ll_l1_(text,l11ll1_l1_ (u"ࠬ࠭婝"),True)
	elif mode==508: l1llll11ll1ll_l1_()
	elif mode==509: l1lllll11ll1l_l1_()
	return
def l1lllll11ll1l_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ婞"),l11ll1_l1_ (u"ࠧࠨ婟"),l11ll1_l1_ (u"ࠨࠩ婠"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ婡"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬ婢"))
	if l1ll111ll1_l1_:
		l1lll1l1111ll_l1_(False)
		l1ll11l1ll_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ婣"),l11ll1_l1_ (u"ࠬ࠭婤"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ婥"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩ婦"))
	return
def l1l1l1lll1ll_l1_(addon_id,function,l1ll_l1_):
	# function: l11ll1_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ婧"),l11ll1_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ婨"),l11ll1_l1_ (u"ࠪࠫ婩")
	conn = sqlite3.connect(l1l1ll1l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1lll1l1l11l1_l1_ = l11ll1_l1_ (u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧ婪")
	else: l1lll1l1l11l1_l1_ = l11ll1_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫ婫")
	cc.execute(l11ll1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧ婬")+l1lll1l1l11l1_l1_+l11ll1_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ婭")+addon_id+l11ll1_l1_ (u"ࠨࠤࠣ࠿ࠬ婮"))
	l1l111l111l_l1_ = cc.fetchall()
	if l1l111l111l_l1_ and function in [l11ll1_l1_ (u"ࠩࠪ婯"),l11ll1_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ婰")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ婱"),l11ll1_l1_ (u"ࠬ࠭婲"),l11ll1_l1_ (u"࠭ࠧ婳"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ婴"),l11ll1_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ婵")+addon_id+l11ll1_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ婶"))
		if l1ll111ll1_l1_!=1: return
		cc.execute(l11ll1_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩ婷")+l1lll1l1l11l1_l1_+l11ll1_l1_ (u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ婸")+addon_id+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ婹"))
	elif function in [l11ll1_l1_ (u"࠭ࠧ婺"),l11ll1_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨ婻")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ婼"),l11ll1_l1_ (u"ࠩࠪ婽"),l11ll1_l1_ (u"ࠪࠫ婾"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ婿"),l11ll1_l1_ (u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ媀")+addon_id+l11ll1_l1_ (u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ媁"))
		if l1ll111ll1_l1_!=1: return
		if kodi_version<19: cc.execute(l11ll1_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧ媂")+addon_id+l11ll1_l1_ (u"ࠨࠤࠬࠤࡀ࠭媃"))
		else: cc.execute(l11ll1_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ媄")+addon_id+l11ll1_l1_ (u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪ媅"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11ll1_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ媆"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭媇"),l11ll1_l1_ (u"࠭ࠧ媈"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ媉"),l11ll1_l1_ (u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬ媊"))
	if function in [l11ll1_l1_ (u"ࠩࠪ媋"),l11ll1_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ媌")]: l1lll1l1lll11_l1_(l1ll_l1_)
	return
def l1llll11111ll_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ媍"),l11ll1_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ媎"))
	l1l1ll1ll1l1_l1_ = l11ll1111ll_l1_(False)
	l11111111ll_l1_ = l11ll1_l1_ (u"࠭࡜࡯ࠩ媏")
	l1lllll1l1l11_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ媐")
	l1lllll1l111l_l1_ = l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ媑")
	for id,l1l11l1l1lll_l1_,l1l11lllll1l_l1_,l111l1ll1l1_l1_,l111l1l111l_l1_,reason in reversed(l1l1ll1ll1l1_l1_):
		if id==l11ll1_l1_ (u"ࠩ࠳ࠫ媒"):
			l1lllll11ll1_l1_,l1lllll11lll_l1_ = l111l1ll1l1_l1_.split(l11ll1_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ媓"))
			continue
		if l11111111ll_l1_!=l11ll1_l1_ (u"ࠫࡡࡴࠧ媔"): l11111111ll_l1_ += l1lllll1l111l_l1_
		l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭媕")+id+l11ll1_l1_ (u"࠭ࠠ࠻ࠢࠪ媖")+l11ll1_l1_ (u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ媗")+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ媘")+l1l11lllll1l_l1_
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ媙")+l111l1ll1l1_l1_
		l111ll1l111l_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媚")+l111l1l111l_l1_
		l111ll1l11l1_l1_ = l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ媛")+reason
		l11111111ll_l1_ += l1ll11l11ll_l1_+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ媜")+l1lllll1l1l11_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ媝")+l111ll1l111l_l1_+l111ll1l11l1_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ媞")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ媟"),l1lllll11lll_l1_,l11111111ll_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ媠"))
	return
def l1llll1l1l1ll_l1_(file):
	if file==favoritesfile: l1llll111l111_l1_ = l11ll1_l1_ (u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ媡")
	elif file==l1l11l1ll1l1_l1_: l1llll111l111_l1_ = l11ll1_l1_ (u"ࠫฬ๊ัิษษ่ࠬ媢")
	elif file==l1l111ll111_l1_: l1llll111l111_l1_ = l11ll1_l1_ (u"่่ࠬศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬ媣")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭媤"),l11ll1_l1_ (u"ࠧๆีะࠫ媥"),l11ll1_l1_ (u"ࠨวุ่ฬำࠧ媦"),l11ll1_l1_ (u"ࠩัีําࠧ媧"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭媨"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩ媩")+l1llll111l111_l1_+l11ll1_l1_ (u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬ媪"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ媫"),l11ll1_l1_ (u"ࠧࠨ媬"),l11ll1_l1_ (u"ࠨࠩ媭"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ媮"),l11ll1_l1_ (u"ࠪࠫ媯"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ媰"),l11ll1_l1_ (u"ࠬะๅࠡ็ึั๋ࠥไโࠢࠪ媱")+l1llll111l111_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ媲"),l11ll1_l1_ (u"ࠧࠨ媳"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ媴"),l11ll1_l1_ (u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ媵")+l1llll111l111_l1_)
	return
def l1lll11ll1l1l_l1_():
	if kodi_version<18:
		message = l11ll1_l1_ (u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭媶")+str(kodi_version)+l11ll1_l1_ (u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ媷")
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭媸"),l11ll1_l1_ (u"࠭ࠧ媹"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ媺"),message)
		return
	l111l1ll1ll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ媻"))
	l1l11ll1ll1l_l1_ = l1lll1l1llll_l1_([l11ll1_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ媼")])
	l1l11l11lll1_l1_,l1llll1l1l111_l1_,l1llll1l1l1l1_l1_,l1llll1l1l11l_l1_,l1llll1l11ll1_l1_,l1lll11lll1ll_l1_,l1llll1l11lll_l1_ = l1l11ll1ll1l_l1_[l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ媽")]
	if l1l11l11lll1_l1_ or l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ媾") not in str(l111l1ll1ll_l1_):
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭媿"),l11ll1_l1_ (u"࠭ࠧ嫀"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嫁"),l11ll1_l1_ (u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭嫂"))
		succeeded = l1llll11ll11l_l1_(l11ll1_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ嫃"),True)
		if not succeeded: return
	l11l1l1llll_l1_(True)
	return
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠫ࠮ࠐࠉࡪࡨࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊ࠽࠾ࠩ࠸࠸࠹࠭࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ࠊࠊࡧ࡯࡭࡫ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࡀࡁࠬ࠻࠵࠶ࠩ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡษ็ูํืࠧࠋࠋࡨࡰࡸ࡫࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้๋ࠥฬ่๊็อࠬࠐࠉࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠵ࡀࠉࠊࠥࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡶࡪࡧࡺࡸࡾࡶࡥࠋࠋࠌࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪࠫࠏࠏࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡶࡪࡧࡺࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡥࡦࠤࡂࠦࡣࡰࡰࡱ࠲ࡨࡻࡲࡴࡱࡵࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠷࠹࠸࠳࠴࠻ࠥࡁࠧࠪࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠺࠻࠶࠸࠱ࠢ࠾ࠫ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣࡰ࡯ࡰ࡭ࡹ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࡩࡱ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠴࠾ࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠻࠴࠵ࠩࠌࠧࠥࠨࡌࡪࡵࡷࠤࡊࡳࡡࡥࠤࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠏࠏࡥ࡭࡫ࡩࠤࡨ࡮࡯ࡪࡥࡨࡁࡂ࠸࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨ࠷࠸࠹ࠬࠏࠣࠡࠤࡊࡥࡱࡲࡥࡳࡻࡢࡉࡲࡧࡤࠣࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠪ࠰ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠪࠌࠌࠦࠧࠨ嫄")
def l11l1l1llll_l1_(l1ll_l1_=True):
	l111l1ll1ll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ嫅"))
	if l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ嫆") not in str(l111l1ll1ll_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嫇"),l11ll1_l1_ (u"ࠧࠨ嫈"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嫉"),l11ll1_l1_ (u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ嫊"))
		return
	l1llll1l1llll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ嫋"),l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ嫌"),l11ll1_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ嫍"),l11ll1_l1_ (u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧ嫎"))
	if not os.path.exists(l1llll1l1llll_l1_): return
	l1l11111lll_l1_ = open(l1llll1l1llll_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ嫏")).read()
	if kodi_version>18.99: l1l11111lll_l1_ = l1l11111lll_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭嫐"))
	l1lll11ll11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ嫑"),l1l11111lll_l1_,re.DOTALL)
	l1lll11lllll1_l1_,l1lllll11llll_l1_ = l1lll11ll11l1_l1_[0]
	l1llll1lllll1_l1_ = l11ll1_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ嫒")+l1lll11lllll1_l1_+l11ll1_l1_ (u"ࠫ࠱࠭嫓")+l1lllll11llll_l1_+l11ll1_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ嫔")
	if l1ll_l1_:
		l1llll1llllll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫ嫕"))
		if l1llll1llllll_l1_==l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ嫖"): l11ll11l11l_l1_ = l11ll1_l1_ (u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨ嫗")
		elif l1llll1llllll_l1_==l11ll1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ嫘"): l11ll11l11l_l1_ = l11ll1_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ嫙")
		else: l11ll11l11l_l1_ = l11ll1_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ嫚")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ嫛"),l11ll1_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ嫜"),l11ll1_l1_ (u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ嫝"),l11ll1_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭嫞"),l11ll1_l1_ (u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭嫟")+l11ll11l11l_l1_,l11ll1_l1_ (u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嫠"))
		if choice==1: l1llll1111ll1_l1_ = l11ll1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ嫡")
		elif choice==2: l1llll1111ll1_l1_ = l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ嫢")
		else: l1llll1111ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ嫣")
	else:
		l1llll1llllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ嫤"))
		if   l1llll1llllll_l1_==l11ll1_l1_ (u"ࠨࠩ嫥"): choice = 0
		elif l1llll1llllll_l1_==l11ll1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ嫦"): choice = 1
		elif l1llll1llllll_l1_==l11ll1_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ嫧"): choice = 2
		l1llll1111ll1_l1_ = l1llll1llllll_l1_
	if   choice==0: l1lll1llll111_l1_ = l11ll1_l1_ (u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨ嫨")
	elif choice==1: l1lll1llll111_l1_ = l11ll1_l1_ (u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩ嫩")
	elif choice==2: l1lll1llll111_l1_ = l11ll1_l1_ (u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪ嫪")
	else: return
	settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ嫫"),l1llll1111ll1_l1_)
	l1lll1l111ll1_l1_ = l11ll1_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ嫬")+l1lll1llll111_l1_+l11ll1_l1_ (u"ࠩ࠯ࠫ嫭")+l1lllll11llll_l1_+l11ll1_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ嫮")
	l11lllll1ll_l1_ = l1l11111lll_l1_.replace(l1llll1lllll1_l1_,l1lll1l111ll1_l1_)
	if kodi_version>18.99: l11lllll1ll_l1_ = l11lllll1ll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嫯"))
	open(l1llll1l1llll_l1_,l11ll1_l1_ (u"ࠬࡽࡢࠨ嫰")).write(l11lllll1ll_l1_)
	LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭嫱"),l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠤࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭嫲")+l1lll1llll111_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ嫳"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨ嫴"))
	return
def l1lll1l111l11_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ嫵"),l11ll1_l1_ (u"่๊ࠫวࠨ嫶"),l11ll1_l1_ (u"ࠬ์ูๆࠩ嫷"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嫸"),l11ll1_l1_ (u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬ嫹"))
	if l1ll111ll1_l1_==1: l1ll1l1ll111_l1_()
	return
def l1lll1ll1llll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嫺"),l11ll1_l1_ (u"ࠩࠪ嫻"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嫼"),l11ll1_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧ嫽"))
	return
def l1llll11lll1l_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห฻าหิࠦิ๋฻ฬࠤว๊ࠠๆฯ่ำ๊ࠥำ็หࠣ࠶࠵࠸࠱ࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嫾")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬ嫿")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嬀")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮุࠣึ๐ืࠡษ็ุ้๊ๅࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嬁")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭嬂")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ嬃")
	message = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ嬄")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪ嬅")+l1ll11l1l11_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ嬆"),l11ll1_l1_ (u"ࠧࠨ嬇"),message)
	return
def l1l11l1111l_l1_(l1111l1l111_l1_):
	try: status = l111l1l11ll_l1_(l1111l1l111_l1_,False)
	except: pass
	l1l1ll1ll1l1_l1_ = l11ll1111ll_l1_(l1111l1l111_l1_)
	id,l1l11l1l1lll_l1_,l1l11lllll1l_l1_,l111l1ll1l1_l1_,l111l1l111l_l1_,reason = l1l1ll1ll1l1_l1_[0]
	l1lllll11ll1_l1_,l1lllll11lll_l1_ = l111l1ll1l1_l1_.split(l11ll1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭嬈"))
	l1ll11l1l11_l1_,l111ll1l111l_l1_,l111ll1l11l1_l1_ = l111l1l111l_l1_.split(l11ll1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ嬉"))
	l1l11l1l1l11_l1_ = True
	while l1l11l1l1l11_l1_:
		l1lll1lll11ll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ嬊"),l11ll1_l1_ (u"ࠫำื่อࠩ嬋"),l11ll1_l1_ (u"ࠬษัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ嬌"),l11ll1_l1_ (u"࠭โศศ่อࠥอไหสิ฽ࠬ嬍"),l11ll1_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣๆ๊ࠦศศๆอฬึ฿ࠠฤ๊ࠣหู๊อࠡษ็ฬึ์วๆฮ้๋ࠣࠦฬ่ษี็ࠬ嬎"),l1ll11l1l11_l1_)
		if l1lll1lll11ll_l1_==2: l1lll1lll11l1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ嬏"),l11ll1_l1_ (u"ࠩࠪ嬐"),l11ll1_l1_ (u"ࠪ฽ํีษࠨ嬑"),l11ll1_l1_ (u"ࠫࠬ嬒"),l11ll1_l1_ (u"ࠬอไศ฻อีฬ฼ฺࠠๆ์ࠤ๊ฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫ嬓"),l111ll1l111l_l1_,l11ll1_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪ嬔"))
		elif l1lll1lll11ll_l1_==1: l1ll111lll1l_l1_()
		else: l1l11l1l1l11_l1_ = False
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ嬕"))
	return
def l1lll1l1111ll_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ嬖"),l11ll1_l1_ (u"ࠩࠪ嬗"),l11ll1_l1_ (u"ࠪࠫ嬘"),l11ll1_l1_ (u"ุࠫสวๅࠩ嬙"),l11ll1_l1_ (u"ࠬํไࠡล้ฮ๋ࠥสฤๅาࠤํะั๋ัุ้ࠣำ้ࠠฬุๅ๏ืࠠอ็ํ฽ࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤา๐หࠡฬ฼์ิࠦฬๆ์฼ࠤฬ๊ลฺัสำฬะࠠฦๆ์ࠤํ฼ู๋หࠣฮะฮ๊หࠢส่อืๆศ็ฯࠤฤ࠭嬚"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_:
		succeeded = True
		if os.path.exists(l1ll1111lll1_l1_):
			try: os.remove(l1ll1111lll1_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嬛"),l11ll1_l1_ (u"ࠧࠨ嬜"),l11ll1_l1_ (u"ࠨࠩ嬝"),l11ll1_l1_ (u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ嬞"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嬟"),l11ll1_l1_ (u"ࠫࠬ嬠"),l11ll1_l1_ (u"ࠬ࠭嬡"),l11ll1_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅๅใࠣห้หูะษาหฯ࠭嬢"))
	return
def l1llll11l11ll_l1_():
	l1lll1llll11l_l1_()
	l1lllll111l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ嬣"))
	message = {}
	message[l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭嬤")] = l11ll1_l1_ (u"ࠩส่่อิࠡษ็ฮ้่วว์ࠣ๎฾๋ไࠨ嬥")
	message[l11ll1_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ嬦")] = l11ll1_l1_ (u"ࠫฬ๊ใศึ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ嬧")
	message[l11ll1_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭嬨")] = l11ll1_l1_ (u"࠭ใศึࠣะิอࠠใืํีࠥอไๆั์ࠤ࠳ࠦࠧ嬩")+str(l11lllll1l1_l1_/60)+l11ll1_l1_ (u"ࠧࠡัๅ๎็ฯࠠโไฺࠫ嬪")
	l1lll1l1ll1ll_l1_ = message[l1lllll111l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ嬫"),l11ll1_l1_ (u"ࠩๆหูࠦࠧ嬬")+str(l11lllll1l1_l1_/60)+l11ll1_l1_ (u"ࠪࠤิ่๊ใหࠪ嬭"),l11ll1_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ嬮"),l11ll1_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ嬯"),l1lll1l1ll1ll_l1_,l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩ嬰"))
	if choice==0: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ嬱")
	elif choice==1: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭嬲")
	elif choice==2: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ嬳")
	else: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠪࠫ嬴")
	if l1lll1l1ll111_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭嬵"),l1lll1l1ll111_l1_)
		l1lll1l11ll11_l1_ = message[l1lll1l1ll111_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嬶"),l11ll1_l1_ (u"࠭ࠧ嬷"),l11ll1_l1_ (u"ࠧࠨ嬸"),l1lll1l11ll11_l1_)
	return
def l1lll1ll1l1l1_l1_():
	message = {}
	message[l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭嬹")] = l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥอไหๆๅหห๐๋ࠠ฻่่࠿ࠦࠧ嬺")
	message[l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ嬻")] = l11ll1_l1_ (u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์ࡀࠠࠨ嬼")
	message[l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ嬽")] = l11ll1_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔ่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ嬾")
	l1llll1ll1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ嬿"))
	l1lllll111l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ孀"))
	l1lll1l1ll1ll_l1_ = message[l1lllll111l11_l1_]+l1llll1ll1l11_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ孁"),l11ll1_l1_ (u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ孂"),l11ll1_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ孃"),l11ll1_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ孄"),l1lll1l1ll1ll_l1_,l11ll1_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ孅"))
	if choice==0: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ孆")
	elif choice==1: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭孇")
	elif choice==2: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ孈")
	if choice in [0,1]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ孉"),l11ll1_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ孊")+l1lllll11111_l1_[1],l11ll1_l1_ (u"ู๊ࠬาใิ࠾ࠥ࠭孋")+l1lllll11111_l1_[0],l11ll1_l1_ (u"࠭ࠧ孌"),l11ll1_l1_ (u"ࠧฤะอหึࠦำ๋ำไีࠥࡊࡎࡔࠢส่๊์วิส่่ࠣ࠭孍"))
		if l1ll111ll1_l1_==1: l111ll1l1l1_l1_ = l1lllll11111_l1_[0]
		else: l111ll1l1l1_l1_ = l1lllll11111_l1_[1]
	elif choice==2: l111ll1l1l1_l1_ = l11ll1_l1_ (u"ࠨࠩ孎")
	else: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠩࠪ孏")
	if l1lll1l1ll111_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ子"),l1lll1l1ll111_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ孑"),l111ll1l1l1_l1_)
		l1lll1l11ll11_l1_ = message[l1lll1l1ll111_l1_]+l111ll1l1l1_l1_
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭孒"),l11ll1_l1_ (u"࠭ࠧ孓"),l11ll1_l1_ (u"ࠧࠨ孔"),l1lll1l11ll11_l1_)
	return
def l1llll111111l_l1_():
	l1lllll111l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ孕"))
	message = {}
	message[l11ll1_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ孖")] = l11ll1_l1_ (u"ࠪห้ฮั้ๅึ๎ࠥอไหๆๅหห๐ࠠอษ๊ึ๊ࠥไฺ็็ࠫ字")
	message[l11ll1_l1_ (u"ࠫࡆ࡙ࡋࠨ存")] = l11ll1_l1_ (u"ࠬอไษำ๋็ุ๐ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์࠭孙")
	message[l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ孚")] = l11ll1_l1_ (u"ࠧศๆหีํ้ำ๋่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ孛")
	l1lll1l1ll1ll_l1_ = message[l1lllll111l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ孜"),l11ll1_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ孝"),l11ll1_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ孞"),l11ll1_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ孟"),l1lll1l1ll1ll_l1_,l11ll1_l1_ (u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨ孠"))
	if choice==0: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ孡")
	elif choice==1: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ孢")
	elif choice==2: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭季")
	else: l1lll1l1ll111_l1_ = l11ll1_l1_ (u"ࠩࠪ孤")
	if l1lll1l1ll111_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ孥"),l1lll1l1ll111_l1_)
		l1lll1l11ll11_l1_ = message[l1lll1l1ll111_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ学"),l11ll1_l1_ (u"ࠬ࠭孧"),l11ll1_l1_ (u"࠭ࠧ孨"),l1lll1l11ll11_l1_)
	return
def l1llll11ll1ll_l1_():
	l1l11l1lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ孩"))
	if l1l11l1lllll_l1_==l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭孪"): header = l11ll1_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨ孫")
	else: header = l11ll1_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨ孬")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ孭"),l11ll1_l1_ (u"ࠬห๊ใษไࠫ孮"),l11ll1_l1_ (u"࠭สโ฻ํ่ࠬ孯"),header,l11ll1_l1_ (u"ࠧใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ์อ้ࠥะอะ์ฮ๋ฬࠦร้ฬ๋้ฬะ๊ไ์สࠤอ฿ฯࠡ࠳࠹ࠤุอูส่๊ࠢࠥษ่ๅࠢฦืฯิฯศ็ࠣ࠲࠳่ࠦฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊๊ࠦลัํࠤส๊้ࠡฬะำ๏ั็ศࠢไ๎้ࠥไࠡ็ิอࠥ๐สๆࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤ࠳࠴้้ࠠำหࠥ๐ำษสࠣฬ฼ฬࠠโ์ࠣๅฯำࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪ孰"))
	if l1ll111ll1_l1_==-1: return
	elif l1ll111ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ孱"),l11ll1_l1_ (u"ࠩࠪ孲"))
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ孳"),l11ll1_l1_ (u"ࠫࠬ孴"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ孵"),l11ll1_l1_ (u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ孶"))
	else:
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ孷"),l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭學"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ孹"),l11ll1_l1_ (u"ࠪࠫ孺"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ孻"),l11ll1_l1_ (u"ࠬะๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ孼"))
	return
def l1lll1llll1l1_l1_(text):
	if text!=l11ll1_l1_ (u"࠭ࠧ孽"):
		text = l1l1l11ll1l_l1_(text)
		text = text.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ孾")).encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭孿"))
		l1l1l1l1111_l1_ = 10103
		l1l1l11lll1_l1_ = xbmcgui.l1l1l111ll1_l1_(l1l1l1l1111_l1_)
		l1l1l11lll1_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l11l1111_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡍࡨࡽࡧࡵࡡࡳࡦ࠵࠶࠳ࡾ࡭࡭ࠩ宀"), xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠪࡴࡦࡺࡨࠨ宁")).decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ宂")),l11ll1_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭它"),l11ll1_l1_ (u"࠭࠷࠳࠲ࡳࠫ宄"))
		#l1l1l11l1111_l1_.show()
		#l1l1l11l1111_l1_.getControl(99991).setPosition(0,0)
		#l1l1l11l1111_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l11l1111_l1_.getControl(5).l1lll1l1l11l_l1_(l1llll1ll1111_l1_)
		#width = xbmcgui.l1lll1l1l1l11_l1_()
		#l1ll1l111111_l1_ = xbmcgui.l1llll111ll11_l1_()
		#resolution = (0.0+width)/l1ll1l111111_l1_
		#l1l1l11l1111_l1_.getControl(5).l1l1l11111l1_l1_(width-180)
		#l1l1l11l1111_l1_.getControl(5).setHeight(l1ll1l111111_l1_-180)
		#l1l1l11l1111_l1_.doModal()
		#del l1l1l11l1111_l1_
	return
l1lll1l111111_l1_ = [
			 l11ll1_l1_ (u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࠫࠬࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧ宅")
			,l11ll1_l1_ (u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫ宆")
			,l11ll1_l1_ (u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫ宇")
			,l11ll1_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬ守")
			,l11ll1_l1_ (u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬ安")
			,l11ll1_l1_ (u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧ宊")
			,l11ll1_l1_ (u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠨࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫ宋")
			,l11ll1_l1_ (u"ࠧࡊࡰࡶࡩࡨࡻࡲࡦࡔࡨࡵࡺ࡫ࡳࡵ࡙ࡤࡶࡳ࡯࡮ࡨ࠮ࠪ完")
			,l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࠱ࡂࡱࡴࡪࡥ࠾࠲ࠩࡸࡪࡾࡴ࠾ࠩ宍")
			,l11ll1_l1_ (u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࡶ࠲ࡼࡧࡲ࡯ࠪࠪ宎")
			,l11ll1_l1_ (u"ࠪࡢࡣࡤ࡞࡟ࠩ宏")
			,l11ll1_l1_ (u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ宐")
			]
def l1lll1ll1ll1l_l1_(line):
	if l11ll1_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪ宑") in line and l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ宒") in line: return True
	for text in l1lll1l111111_l1_:
		if text in line: return True
	return False
def l1lll11l1llll_l1_(data):
	data = data.replace(l11ll1_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ宓")+l11ll1_l1_ (u"ࠨࠢࠪ宔")*51+l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ宕"),l11ll1_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ宖"))
	data = data.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ宗")+l11ll1_l1_ (u"ࠬࠦࠧ官")*51+l11ll1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ宙"),l11ll1_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ定"))
	data = data.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ宛")+l11ll1_l1_ (u"ࠩࠣࠫ宜")*51+l11ll1_l1_ (u"ࠪࡠࡳ࠭宝"),l11ll1_l1_ (u"ࠫࡡࡴࠧ实"))
	#data = data.replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰࠰ࡃࡱࡨࡷࡵࡩࡥ࠱ࡧࡥࡹࡧ࠯ࡰࡴࡪ࠲ࡽࡨ࡭ࡤ࠰࡮ࡳࡩ࡯࠯ࡧ࡫࡯ࡩࡸ࠵࠮࡬ࡱࡧ࡭࠴ࡧࡤࡥࡱࡱࡷ࠴࠭実"),l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠫ宠"))
	data = data.replace(l11ll1_l1_ (u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭审"),l11ll1_l1_ (u"ࠨ࠼ࠣࠫ客"))
	l11ll111l_l1_ = l11ll1_l1_ (u"ࠩࠪ宣")
	for line in data.splitlines():
		delete = re.findall(l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ室"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11ll1_l1_ (u"ࠫࠬ宥"))
		l11ll111l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ宦")+line
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧ宧"),l11ll111l_l1_)
	return l11ll111l_l1_
def l1lll11llll11_l1_(l1llll1111lll_l1_):
	if l11ll1_l1_ (u"ࠧࡐࡎࡇࠫ宨") in l1llll1111lll_l1_:
		l1llll1ll1l1l_l1_ = l1lll1ll11ll_l1_
		header = l11ll1_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ宩")
	else:
		l1llll1ll1l1l_l1_ = l1lll1111lll_l1_
		header = l11ll1_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ宪")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ宫"),l11ll1_l1_ (u"ࠫࠬ宬"),l11ll1_l1_ (u"ࠬ࠭宭"),header,l11ll1_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ宮"))
	if l1ll111ll1_l1_!=1: return
	l1lll11ll11ll_l1_,counts = [],0
	size,count = l1l1l11ll1_l1_(l1llll1ll1l1l_l1_)
	#size = os.path.getsize(l1llll1ll1l1l_l1_)
	file = open(l1llll1ll1l1l_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ宯"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭宰"))
	data = l1lll11l1llll_l1_(data)
	lines = data.split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ宱"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ宲"))
		#if line.strip(l11ll1_l1_ (u"ࠫࠥ࠭害"))==l11ll1_l1_ (u"ࠬ࠭宴"): continue
		ignore = l1lll1ll1ll1l_l1_(line)
		if ignore: continue
		line = line.replace(l11ll1_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡤ࠭宵"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ家"))
		line = line.replace(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ宷"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬ宸"))
		l1llll111l11l_l1_ = l11ll1_l1_ (u"ࠪࠫ容")
		l1lll11llllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ宺"),line,re.DOTALL)
		if l1lll11llllll_l1_:
			line = line.replace(l1lll11llllll_l1_[0][0],l1lll11llllll_l1_[0][1]).replace(l1lll11llllll_l1_[0][2],l11ll1_l1_ (u"ࠬ࠭宻"))
			l1llll111l11l_l1_ = l1lll11llllll_l1_[0][1]
		else:
			l1lll11llllll_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭宼"),line,re.DOTALL)
			if l1lll11llllll_l1_:
				line = line.replace(l1lll11llllll_l1_[0][1],l11ll1_l1_ (u"ࠧࠨ宽"))
				l1llll111l11l_l1_ = l1lll11llllll_l1_[0][0]
		if l1llll111l11l_l1_: line = line.replace(l1llll111l11l_l1_,l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ宾")+l1llll111l11l_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ宿"))
		l1lll11ll11ll_l1_.append(line)
		if len(str(l1lll11ll11ll_l1_))>50100: break
	l1lll11ll11ll_l1_ = reversed(l1lll11ll11ll_l1_)
	l1llll1ll1111_l1_ = l11ll1_l1_ (u"ࠪࡠࡳ࠭寀").join(l1lll11ll11ll_l1_)
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ寁"),l11ll1_l1_ (u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ寂"),l1llll1ll1111_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ寃"))
	return
def l1lll1ll11lll_l1_():
	l1llll1ll1ll1_l1_ = open(l1ll111ll1ll_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ寄")).read()
	if kodi_version>18.99: l1llll1ll1ll1_l1_ = l1llll1ll1ll1_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭寅"))
	l1llll1ll1ll1_l1_ = l1llll1ll1ll1_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡸࠬ密"),l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬ寇"))
	l1l11ll1ll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ寈"),l1llll1ll1ll1_l1_,re.DOTALL)
	for line in l1l11ll1ll1l_l1_:
		l1llll1ll1ll1_l1_ = l1llll1ll1ll1_l1_.replace(line,l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ寉")+line+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ寊"))
	DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨ寋"),l1llll1ll1ll1_l1_)
	return
def l1llll11ll1l1_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪ富")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭寍")
	l111ll1l111l_l1_ = l11ll1_l1_ (u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭寎")
	message = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ寏")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࠦ࠮ࠡࠩ寐")+l111ll1l111l_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭寑"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ寒"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ寓"))
	return
def l111ll1l1ll_l1_(l1ll1ll1l111_l1_,message,l1ll_l1_=True,url=l11ll1_l1_ (u"ࠩࠪ寔"),source=l11ll1_l1_ (u"ࠪࠫ寕"),text=l11ll1_l1_ (u"ࠫࠬ寖"),l11l11111l1l_l1_=l11ll1_l1_ (u"ࠬ࠭寗")):
	if l11ll1_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ寘") in text: l1l11ll11lll_l1_ = True
	else: l1l11ll11lll_l1_ = False
	l1lll11l1l1l1_l1_ = True
	if not l11lllll111_l1_(l11ll1_l1_ (u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ寙")):
		if l1ll_l1_:
			#if message.count(l11ll1_l1_ (u"ࠨ࡞࡟ࡲࠬ寚"))>1: l1ll11ll111l_l1_ = l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ寛")
			#else: l1ll11ll111l_l1_ = l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ寜")
			l1lll1l111lll_l1_ = (l11ll1_l1_ (u"ࠫฬ๊ำุำ࠽ࠫ寝") in message and l11ll1_l1_ (u"ࠬอไๆๅส๊࠿࠭寞") in message and l11ll1_l1_ (u"࠭วๅ็็ๅ࠿࠭察") in message and l11ll1_l1_ (u"ࠧศๆั฻ศ࠭寠") in message and l11ll1_l1_ (u"ࠨษ็ฺ้ีั࠻ࠩ寡") in message)
			if not l1lll1l111lll_l1_: l1lll11l1l1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ寢"),l11ll1_l1_ (u"ࠪࠫ寣"),l11ll1_l1_ (u"ࠫࠬ寤"),l11ll1_l1_ (u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩ寥"),message.replace(l11ll1_l1_ (u"࠭࡜࡝ࡰࠪ實"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ寧")))
	elif l1ll_l1_:
		message = l11ll1_l1_ (u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨ寨")
		l1lllll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ審"),l11ll1_l1_ (u"ࠪࠫ寪"),l11ll1_l1_ (u"ࠫࠬ寫"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ寬")+l11ll1_l1_ (u"࠭ࠠࠡ࠳࠲࠹ࠬ寭"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ寮"))
		l1lllll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ寯"),l11ll1_l1_ (u"ࠩࠪ寰"),l11ll1_l1_ (u"ࠪࠫ寱"),l11ll1_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ寲")+l11ll1_l1_ (u"ࠬࠦࠠ࠳࠱࠸ࠫ寳"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ寴"))
		l1lllll111l1l_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ寵"),l11ll1_l1_ (u"ࠨࠩ寶"),l11ll1_l1_ (u"ࠩࠪ寷"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ寸")+l11ll1_l1_ (u"ࠫࠥࠦ࠳࠰࠷ࠪ对"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ寺"))
		l1lllll11l1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭寻"),l11ll1_l1_ (u"ࠧࠨ导"),l11ll1_l1_ (u"ࠨࠩ寽"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ対")+l11ll1_l1_ (u"ࠪࠤࠥ࠺࠯࠶ࠩ寿"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ尀"))
		l1lll11l1l1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ封"),l11ll1_l1_ (u"࠭ࠧ専"),l11ll1_l1_ (u"ࠧࠨ尃"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ射")+l11ll1_l1_ (u"ࠩࠣࠤ࠺࠵࠵ࠨ尅"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ将"))
	if l1lll11l1l1l1_l1_!=1:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ將"),l11ll1_l1_ (u"ࠬ࠭專"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ尉"),l11ll1_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪ尊"))
		return False
	l1lllll11l1ll_l1_ = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠢ尋") )
	message += l11ll1_l1_ (u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨ尌")+addon_version+l11ll1_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ對")
	message += l11ll1_l1_ (u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬ導")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ小")+l1l111ll1ll_l1_+l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ尐")
	message += l11ll1_l1_ (u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬ少")+l1lllll11l1ll_l1_
	#l1l111l1ll1_l1_ = l11lll1l1ll_l1_(l11ll1_l1_ (u"ࠨ࠹࠹࠲࠻࠻࠮࠲࠵࠻࠲࠷࠹࠰ࠨ尒"))
	l1llllll111l_l1_ = l11lll1l1ll_l1_()
	l1llllll111l_l1_ = QUOTE(l1llllll111l_l1_)
	if l1llllll111l_l1_: message += l11ll1_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡍࡱࡦࡥࡹ࡯࡯࡯࠼ࠣࠫ尓")+l1llllll111l_l1_
	if url: message += l11ll1_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡗࡕࡐ࠿ࠦࠧ尔")+url
	if source: message += l11ll1_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡖࡳࡺࡸࡣࡦ࠼ࠣࠫ尕")+source
	message += l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ尖")
	if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"࠭ฬศำํࠤฬ๊ลาีส่ࠬ尗"),l11ll1_l1_ (u"ࠧศๆิะฬวࠠศๆส๊ฯ฾วาࠩ尘"))
	if l11l11111l1l_l1_:
		l1llll1ll1111_l1_ = l11l11111l1l_l1_
		if kodi_version>18.99: l1llll1ll1111_l1_ = l1llll1ll1111_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭尙"))
		l1llll1ll1111_l1_ = base64.b64encode(l1llll1ll1111_l1_)
	elif l1l11ll11lll_l1_:
		if l11ll1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩ尚") in text: l1lllll1111ll_l1_ = l1lll1ll11ll_l1_
		else: l1lllll1111ll_l1_ = l1lll1111lll_l1_
		if not os.path.exists(l1lllll1111ll_l1_):
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ尛"),l11ll1_l1_ (u"ࠫࠬ尜"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ尝"),l11ll1_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ尞"))
			return False
		l1lll11ll11ll_l1_,counts = [],0
		size,count = l1l1l11ll1_l1_(l1lllll1111ll_l1_)
		#size = os.path.getsize(l1lllll1111ll_l1_)
		file = open(l1lllll1111ll_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ尟"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭尠"))
		data = l1lll11l1llll_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ尡"))
			ignore = l1lll1ll1ll1l_l1_(line)
			if ignore: continue
			l1lll11llllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ尢"),line,re.DOTALL)
			if l1lll11llllll_l1_:
				line = line.replace(l1lll11llllll_l1_[0][0],l1lll11llllll_l1_[0][1]).replace(l1lll11llllll_l1_[0][2],l11ll1_l1_ (u"ࠫࠬ尣"))
			else:
				l1lll11llllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ尤"),line,re.DOTALL)
				if l1lll11llllll_l1_: line = line.replace(l1lll11llllll_l1_[0][1],l11ll1_l1_ (u"࠭ࠧ尥"))
			l1lll11ll11ll_l1_.append(line)
			if len(str(l1lll11ll11ll_l1_))>121000: break
		l1lll11ll11ll_l1_ = reversed(l1lll11ll11ll_l1_)
		l1llll1ll1111_l1_ = l11ll1_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ尦").join(l1lll11ll11ll_l1_)
		l1llll1ll1111_l1_ = l1llll1ll1111_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭尧"))
		l1llll1ll1111_l1_ = base64.b64encode(l1llll1ll1111_l1_)
	else: l1llll1ll1111_l1_ = l11ll1_l1_ (u"ࠩࠪ尨")
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ尩")][2]
	payload = {l11ll1_l1_ (u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬ尪"):l1ll1ll1l111_l1_,l11ll1_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭尫"):message,l11ll1_l1_ (u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧ尬"):l1llll1ll1111_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ尭"),url,payload,l11ll1_l1_ (u"ࠨࠩ尮"),l11ll1_l1_ (u"ࠩࠪ尯"),l11ll1_l1_ (u"ࠪࠫ尰"),l11ll1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ就"))
	#succeeded = response.succeeded
	html = response.content
	if l11ll1_l1_ (u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧ尲") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			l1llllll_l1_(l11ll1_l1_ (u"࠭สๆࠢส่สืำศๆࠪ尳"),l11ll1_l1_ (u"ࠧษ่ฯหา࠭尴"))
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ尵"),l11ll1_l1_ (u"ࠩࠪ尶"),l11ll1_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩ尷"),l11ll1_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭尸"))
		else:
			l1llllll_l1_(l11ll1_l1_ (u"๊ࠬไฤีไࠫ尹"),l11ll1_l1_ (u"࠭แีๆࠣๅ๏ࠦวๅวิืฬ๊ࠧ尺"))
			DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ尻"),l11ll1_l1_ (u"ࠨࠩ尼"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ尽"),l11ll1_l1_ (u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨ尾"))
	return succeeded
def l1lll11l1ll11_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ尿")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠศๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ局")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ屁"),l11ll1_l1_ (u"ࠧࠨ层"),l11ll1_l1_ (u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ屃"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ屄")+l1ll11l1l11_l1_)
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩ居")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦวๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ屆")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭屇"),l11ll1_l1_ (u"࠭ࠧ屈"),l11ll1_l1_ (u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭屉"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭届")+l1ll11l1l11_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ屋"),l11ll1_l1_ (u"ࠪࠫ屌"),l11ll1_l1_ (u"ࠫࠬ屍"),l11ll1_l1_ (u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ屎"),l11ll1_l1_ (u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪ屏")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ屐")+l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨ屑"))
	if l1ll111ll1_l1_==1: l1llll1ll111l_l1_()
	return
def l1lllll1l1111_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ屒"),l11ll1_l1_ (u"ࠪࠫ屓"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ屔"),l11ll1_l1_ (u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ展"))
	return
def l1llll1lll1ll_l1_():
	message = l11ll1_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭屖")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ屗"),l11ll1_l1_ (u"ࠨࠩ屘"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ屙"),message)
	return
def l1lll1llllll1_l1_():
	message = l11ll1_l1_ (u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧ屚")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ屛"),l11ll1_l1_ (u"ࠬ࠭屜"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ屝"),message)
	return
def l1lll11l1l11l_l1_():
	message = l11ll1_l1_ (u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫ属")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ屟"),l11ll1_l1_ (u"ࠩࠪ屠"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭屡"),l11ll1_l1_ (u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭屢"),message)
	return
def l1llll1ll11l1_l1_():
	message = l11ll1_l1_ (u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ屣")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭層"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ履"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ屦"))
	return
def l1llll111llll_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪ屧")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬ屨")
	l111ll1l111l_l1_ = l11ll1_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ屩")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭屪"),l11ll1_l1_ (u"࠭ࠧ屫"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ屬"),l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111ll1l111l_l1_)
	return
def l1lll1llll11l_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩ屭")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ屮") + l11ll1_l1_ (u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩ屯") + str(PERMANENT_CACHE/60/60/24/30) + l11ll1_l1_ (u"ฺࠫࠥ็าࠩ屰")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ山") + l11ll1_l1_ (u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ屲") + str(VERYLONG_CACHE/60/60/24) + l11ll1_l1_ (u"ࠧࠡ์๋้ࠬ屳")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ屴") + l11ll1_l1_ (u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭屵") + str(l1lllll1_l1_/60/60/24) + l11ll1_l1_ (u"ࠪࠤ๏๎ๅࠨ屶")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ屷") + l11ll1_l1_ (u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ屸") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"࠭ࠠิษ฼อࠬ屹")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ屺") + l11ll1_l1_ (u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬ屻") + str(l1ll1ll1l_l1_/60/60) + l11ll1_l1_ (u"ࠩࠣืฬ฿ษࠨ屼")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭屽") + l11ll1_l1_ (u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ屾") + str(l1ll11llll1l_l1_/60) + l11ll1_l1_ (u"ࠬࠦฯใ์ๅอࠬ屿")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࠩ岀") + l11ll1_l1_ (u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩ岁") + str(NO_CACHE) + l11ll1_l1_ (u"ࠨࠢาๆ๏่ษࠨ岂")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ岃") + l11ll1_l1_ (u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧ岄") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬ岅") + str(l1lllll1_l1_/60/60/24) + l11ll1_l1_ (u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫ岆") + str(l1ll1ll1l_l1_/60/60) + l11ll1_l1_ (u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪ岇") + str(l1ll11llll1l_l1_/60) + l11ll1_l1_ (u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩ岈") + str(NO_CACHE) + l11ll1_l1_ (u"ࠨࠢาๆ๏่ษࠨ岉")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ岊"),l11ll1_l1_ (u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ岋"),l1ll11l1l11_l1_,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ岌"))
	return
def l1lll1l1111l1_l1_():
	message = l11ll1_l1_ (u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨ岍")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ岎"),l11ll1_l1_ (u"ࠧࠨ岏"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ岐"),message)
	return
def l1lll1l11llll_l1_():
	message = l11ll1_l1_ (u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪ岑")
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ岒"),l11ll1_l1_ (u"ࠫࠬ岓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ岔"),message)
	return
def l1llll11llll1_l1_():
	message = l11ll1_l1_ (u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ岕")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ岖"),l11ll1_l1_ (u"ࠨࠩ岗"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ岘"),message)
	return
def l1lll1l11l1l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ岙"),l11ll1_l1_ (u"ࠫࠬ岚"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ岛"),l11ll1_l1_ (u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ岜"))
	l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ岝"),True)
	return
def l1lll1ll111l1_l1_():
	message  = l11ll1_l1_ (u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪ岞")
	#message += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ่่าสࠤฬู๊ศศๅࠤ์๎ࠠࡳࡧࡆࡅࡕ࡚ࡃࡉࡃࠣห้ิวึࠢหุึ้ษࠡฮ๋ะ้ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ岟")
	#message += l11ll1_l1_ (u"ࠪ์ฬ๊ะุ๋๊ࠢ฾ะ็ࠡึิ็ฮࠦฬ้ฮ็ࠤำ฻๊ึษ่๊ࠣ์ูࠡสิห๊าࠠๆอ็ࠤ่๎ฯ๋่๊ࠢࠥะีโฯࠣห้หๆหำ้ฮࠬ岠")
	message += l11ll1_l1_ (u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ岡")
	message += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ岢")
	message += l11ll1_l1_ (u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭岣")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭岤"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ岥"),message,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ岦"))
	message = l11ll1_l1_ (u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭岧")
	message += l11ll1_l1_ (u"ࠫࡡࡴࠧ岨")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ岩")
	message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ岪")+l11ll1_l1_ (u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ岫")
	message += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ岬")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊฻ัࠡࠢส่่๎๊หࠢࠣว๊๐ัไษࠣࠤ่์ฯศࠢࠣๅึ์ำศࠢࠣห้๐่็ษ้ࠤࠥฮัู๋ส๊๏อࠠศๆศ้ฬืวหࠢฦ่๊อๆ๋ษࠣีํู๊ศࠢส่๏อศศ่ࠣหูู้้ัํอࠥื่ๆษ้๎ฬࠦ็้ๆ้ำฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ岭")
	message += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ岮")+l11ll1_l1_ (u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬ岯")
	message += l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ศำึ่ࠥืำศๆฬࠤ๊สฯษหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡส็ฯฮࠠโ์๊หࠥอำๆࠢห่ิ้้ࠠลึ้ฬวࠠศๆ่์ฬู่ࠡษ็ฮ๏ࠦไศࠢอืฯ฽ฺ๊ࠢาาํ๊็ศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ岰")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ岱"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ岲"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ岳"))
	#l1ll111lll1l_l1_(l11ll1_l1_ (u"ࠩࡌࡷࡕࡸ࡯ࡣ࡮ࡨࡱࡂࡌࡡ࡭ࡵࡨࠫ岴"))
	#message = l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ岵")+l11ll1_l1_ (u"ࠫํ๊โะࠢ็หา฾ๆศࠢส๎฻อࠠฤ่ࠣห้๋่ศไ฼ࠤฬ๊ๅฺษๅอࠥะฮหๆไࠤออฮหๆสๅࠥอไษๆาࠤํะฮหๆไࠤออฮหๆสๅฺࠥัไหࠣห้อๆหำ้๎ฯࠦแ๋ࠢำ่่ࠦวๅส็ำࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊์ࠦอห๋่ࠣํࠦสๆࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣࡔࡷࡵࡸࡺࠢฦ์ࠥษ๊๊ࠡึ๎้ฯࠠศะิํࠥ็ว็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤุ๎แࠡฬัฮ้็้ࠠๆๆ๊์อࠠๅ่ࠣฮ฾๋ไࠡฮ่๎฾ํวࠨ岶")
	#message += l11ll1_l1_ (u"๊ࠬอๅࠢสฺ่๊ใๅหࠣๆ๊ࠦศฺ็็๎๋ࡀࠠࠡࠢࠣห้ษ่ๅ࠼ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮่ࠦศๅอฬู๋่ࠥࠢสื๊ࠦศๅัๆࠤํอำๆࠢืี่ฯࠠศๆศ๊ฯืๆ๋ฬࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะูๆๆࠣ฽๋ีใࠨ岷")
	#message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ岸")+l11ll1_l1_ (u"้ࠧษ็ฯฬ์๊࠻ࠢฯีอࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤํ฿ๆะࠢส่อ฿ึࠡไาࠤฯำสศฮࠣๅ็฽ࠠห฼ํ๎ึࠦࡄࡏࡕࠣ์ฬ๊รฮี้ࠤศ์๋ࠠๅ๋๊ࠥ็๊ࠡส็ำࠥอฮาࠢ฼่๊อࠠศ่ࠣหุะฮะษ่ࠤࡕࡸ࡯ࡹࡻࠣๆิ๊ࠦฮๆู้้ࠣไสࠢห฽฻ࠦวๅ็๋ห็฿้ࠠๆๆ๊๊๊ࠥิࠢไ๎ࠥาๅ๋฻ࠣห้ี่ๅࠩ岹")
	#DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠨ็ื็้ฯฺ่ࠠาࠤอ฿ึࠡษ็๊ฬูࠧ岺"),message)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ岻"),l11ll1_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭岼"),l11ll1_l1_ (u"ࠫ์ึวࠡษ็ๅา฻่๊่๊ࠠࠣ฿ัโห๋้ࠣࠦวๅ็ื็้ฯࠠๆ่ࠣ฽๋ีใࠡษ่ࠤ๊์ࠠศๆหี๋อๅอ࠰ࠣื๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหๅา฻ࠠๆ๊สๆ฾ํࠠๆำอ๎๋ࠦวๅล๋่๎ࠦศุ้฼็ࠥอไุสํ฽๏่ࠦศๆฮห๋๐ษࠡสสืฯิฯศ็ࠣฬึ๎ใิ์้ࠣัอๆ๋ࠢส๊ฯࠦสฯฬสี์ࠦๅ็ࠢส่็อฦๆหࠣห้ะ๊ࠡีอ฼์ืࠠๅษะๆฬ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิรࠬ岽"),l11ll1_l1_ (u"ࠬ࠭岾"),l11ll1_l1_ (u"࠭ࠧ岿"),l11ll1_l1_ (u"ࠧไๆสࠫ峀"),l11ll1_l1_ (u"ࠨ่฼้ࠬ峁"))
	#if l1ll111ll1_l1_==1:
	#l1llll1111l1l_l1_()
	return
def l1lll1lll1l1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ峂"),l11ll1_l1_ (u"ࠪࠫ峃"),l11ll1_l1_ (u"ࠫะ๊วฬฺࠢี็ࠦไๅฬ๋หฺ๊ࠠๆ฻ࠣห้๋ศา็ฯࠫ峄"),l11ll1_l1_ (u"ࠬษัิๆࠣีุอไสࠢฦ์๋ࠥิไๆฬࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥํะศࠢส่อืๆศ็ฯࡠࡳࡢ࡮ฤ๊ࠣฬฬูสฯัส้ࠥอไโ์ึฬํ้ࠠฤั้ห์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ峅"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ峆"),l11ll1_l1_ (u"ࠧࠨ峇"),l11ll1_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ峈"),l11ll1_l1_ (u"ࠩ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࡡࡴ࡜࡯࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࡤ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࡡࡍࡎࡏࡐࡊ࠲ࡡࡎࡏࡐࡑࡋ࠲ࡡࡏࡐࡑࡒࡌ࠲ࡡࡐࡑࡒࡓࡍ࠲ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤࡆࡇࡁࡂࡃ࠵ࡣࡇࡈࡂࡃࡄ࠵ࡣࡈࡉࡃࡄࡅ࠵ࡣࡉࡊࡄࡅࡆ࠵ࡣࡊࡋࡅࡆࡇ࠵ࡣࡋࡌࡆࡇࡈ࠵ࡣࡌࡍࡇࡈࡉ࠵ࡣࡍࡎࡈࡉࡊ࠵ࡣࡎࡏࡉࡊࡋ࠵ࡣࡏࡐࡊࡋࡌ࠵ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࠤ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇࠠࡃࡄࡅࡆࡇ࠭峉"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ峊"),l11ll1_l1_ (u"ࠫࠬ峋"),l11ll1_l1_ (u"ࠬࡈࡂࡃࡄࡅࡆࡇࡈࡂࡃࠢࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峌"),l11ll1_l1_ (u"࠭࠰ࠡ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠿ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ峍"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ峎"),l11ll1_l1_ (u"ࠨࠩ峏"),l11ll1_l1_ (u"ࠩࡅࡆࡇࡈࡂࡃࡄࡅࡆࡇࠦࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ峐"),l11ll1_l1_ (u"ࠪ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠩ峑"))
	#text = l11ll1_l1_ (u"ࠫ࠭ࠦࡁࡂࡃࡄࡅ࠶ࡥࡂࡃࡄࡅࡆ࠶ࡥࡃࡄࡅࡆࡇ࠶ࡥࡄࡅࡆࡇࡈ࠶ࡥࡅࡆࡇࡈࡉ࠶ࡥࡆࡇࡈࡉࡊ࠶ࡥࡇࡈࡉࡊࡋ࠶ࡥࡈࡉࡊࡋࡌ࠶ࡥࡉࡊࡋࡌࡍ࠶ࠦࠩࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠧ峒")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭峓"),l11ll1_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ峔"),l11ll1_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ峕"),l11ll1_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ峖"),l11ll1_l1_ (u"ࠩ࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶࠷࠸࠲࠳࠴ࠪ峗"),text,l11ll1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ峘"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ峙"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峚"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭峛"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ峜"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峝"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭峞"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ峟"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峠"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峡"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭峢"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峣"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ峤"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ峥"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ峦"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峧"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峨"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峩"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峪"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ峫"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ峬"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ峭"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ峮"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈ࡝ࡰࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ峯"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ峰"))
	return
def l1lll1lll111l_l1_():
	l1lll1llll11l_l1_()
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ峱"),l11ll1_l1_ (u"ࠨࠩ峲"),l11ll1_l1_ (u"ࠩࠪ峳"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧ峴"),l11ll1_l1_ (u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ์ฬ๊ๅิฯࠣ๎ฯ๋ࠠหๆๅหห๐วࠡ฻้ำࠥอๆห้สลࠥ฿ๅาࠢสฺ่็อศฬࠣ์ฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫ峵"))
	if l1ll111ll1_l1_==1:
		l11l111l1l1_l1_(True)
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭島"),l11ll1_l1_ (u"࠭ࠧ峷"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧ峸"),l11ll1_l1_ (u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩ峹"))
	return l1ll111ll1_l1_
def l1lll1ll1lll_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭峺"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩ峻"),l11ll1_l1_ (u"ࠫࠬ峼"),l11ll1_l1_ (u"ࠬ࠭峽"),False,l11ll1_l1_ (u"࠭ࠧ峾"),l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ峿"))
	#html = response.content
	if not response.succeeded:
		l1lll1l1lllll_l1_ = False
		l11l1lll1l_l1_ = l11l1l1ll1_l1_()
		LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭崀"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧ崁")+l11l1lll1l_l1_+l11ll1_l1_ (u"ࠪࡡࠬ崂"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ崃"),l11ll1_l1_ (u"ࠬ࠭崄"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ崅"),l11ll1_l1_ (u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ崆"))
	else:
		l1lll1l1lllll_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ崇"),l11ll1_l1_ (u"ࠩࠪ崈"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭崉"),l11ll1_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ崊"))
	if not l1lll1l1lllll_l1_ and l1ll_l1_: l1llll111ll1l_l1_()
	return l1lll1l1lllll_l1_
def l1llll111ll1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭崋"),l11ll1_l1_ (u"࠭ࠧ崌"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ崍"),l11ll1_l1_ (u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧ崎"))
	#l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠩื๋ฬีษࠡษ็ฮู็๊า๊ࠢ๎๋ࠥไโࠢํัฯ๎๊ࠡ฻็ํฺࠥแาหࠣาฬ฻ษࠡล๋ࠤฯ๎วใ์฼ࠤำอีสࠢ็ุึ้วห่ࠢ฽ึ๎แส๋่ࠢ์ࠦสศำําࠥ฻ไศฯํอࠥ๎ๆโษำࠤํอไ฻ำูࠤ๊์็้๋ࠡࠤฯฮวะๆࠣหู้๋ๅ๊่หฯࠦศุำํๆฮࠦๅีใิอࠥ๐ีฺสࠣหำะัศไ๊หࠥ๎แ่็๊หࠬ崏")
	l1llll11lllll_l1_()
	return
def l1ll111lll1l_l1_(text=l11ll1_l1_ (u"ࠪࠫ崐")):
	l1l11ll11lll_l1_ = True
	if l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ崑") not in text:
		l1l11ll11lll_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ崒"),l11ll1_l1_ (u"࠭ฮา๊ฯࠫ崓"),l11ll1_l1_ (u"ࠧฦำึห้ࠦๅีๅ็อࠬ崔"),l11ll1_l1_ (u"ࠨวิืฬ๊ࠠาีส่ฮ࠭崕"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ崖"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠๆึๆ่ฮࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤ࠭崗"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l11ll11lll_l1_ = True
			text = l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ崘")
	if l1l11ll11lll_l1_:
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ崙"),l11ll1_l1_ (u"࠭ࠧ崚"),l11ll1_l1_ (u"ࠧࠨ崛"),l11ll1_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ崜"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ崝"))
		#if not l1ll111ll1_l1_:
		#	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ崞"),l11ll1_l1_ (u"ࠫࠬ崟"),l11ll1_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ崠"),l11ll1_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ崡"))
		#	return
		l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ崢")
		if l11ll1_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ崣") not in text:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ崤"),l11ll1_l1_ (u"ࠪࠫ崥"),l11ll1_l1_ (u"ࠫࠬ崦"),l11ll1_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ崧"),l11ll1_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭崨"))
			if l1ll111ll1_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ崩"),l11ll1_l1_ (u"ࠨࠩ崪"),l11ll1_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ崫"),l11ll1_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭崬"))
				return
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ崭"),l11ll1_l1_ (u"ࠬ࠭崮"),l11ll1_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ崯"),l11ll1_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ崰"))
	search = OPEN_KEYBOARD(header=l11ll1_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ崱"),source=script_name)
	if not search: return
	message = search
	if l1l11ll11lll_l1_: type = l11ll1_l1_ (u"ࠩ࠰ࡔࡷࡵࡢ࡭ࡧࡰࠫ崲")
	else: type = l11ll1_l1_ (u"ࠪ࠱ࡒ࡫ࡳࡴࡣࡪࡩࠬ崳")
	l1ll1ll1l111_l1_ = l11ll1_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ崴")+l1l11l1l11l_l1_(32)+type
	succeeded = l111ll1l1ll_l1_(l1ll1ll1l111_l1_,message,True,l11ll1_l1_ (u"ࠬ࠭崵"),l11ll1_l1_ (u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩ崶"),text)
	#	url = l11ll1_l1_ (u"ࠧ࡮ࡻࠣࡅࡕࡏࠠࡢࡰࡧ࠳ࡴࡸࠠࡔࡏࡗࡔࠥࡹࡥࡳࡸࡨࡶࠬ崷")
	#	payload = l11ll1_l1_ (u"ࠨࡽࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ࠿ࠨࡍ࡚ࠢࡄࡔࡎࠦࡋࡆ࡛ࠥ࠰ࠧࡺ࡯ࠣ࠼࡞ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥࡡ࠱ࠨࡳࡦࡰࡧࡩࡷࠨ࠺ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࠭ࠤࡶࡹࡧࡰࡥࡤࡶࠥ࠾ࠧࡌࡲࡰ࡯ࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥ࠰ࠧࡺࡥࡹࡶࡢࡦࡴࡪࡹࠣ࠼ࠥࠫ崸")+message+l11ll1_l1_ (u"ࠩࠥࢁࠬ崹")
	#	#auth=(l11ll1_l1_ (u"ࠥࡥࡵ࡯ࠢ崺"), l11ll1_l1_ (u"ࠦࡲࡿࠠࡱࡧࡵࡷࡴࡴࡡ࡭ࠢࡤࡴ࡮ࠦ࡫ࡦࡻࠥ崻")),
	#	import requests
	#	response = requests.request(l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ崼"),url, data=payload, headers=l11ll1_l1_ (u"࠭ࠧ崽"), auth=l11ll1_l1_ (u"ࠧࠨ崾"))
	#	response = requests.post(url, data=payload, headers=l11ll1_l1_ (u"ࠨࠩ崿"), auth=l11ll1_l1_ (u"ࠩࠪ嵀"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嵁"),l11ll1_l1_ (u"ࠫࠬ嵂"),l11ll1_l1_ (u"ࠬ࠭嵃"),l11ll1_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ嵄"))
	#	else:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嵅"),l11ll1_l1_ (u"ࠨࠩ嵆"),l11ll1_l1_ (u"ࠩั฻ศࠦแ๋ࠢส่สืำศๆࠪ嵇"),l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡾࢁ࠿ࠦࡻࠢࡴࢀࠫ嵈").format(response.status_code, response.content))
	#	l1lll1l1ll11l_l1_ = l11ll1_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ嵉")
	#	l1lll1lll1l11_l1_ = l11ll1_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ嵊")
	#	header = l11ll1_l1_ (u"࠭ࠧ嵋")
	#	#header += l11ll1_l1_ (u"ࠧࡇࡴࡲࡱ࠿ࠦࠧ嵌") + l1lll1l1ll11l_l1_
	#	#header += l11ll1_l1_ (u"ࠨ࡞ࡱࡘࡴࡀࠠࠨ嵍") + l1lll11l1l111_l1_
	#	#header += l11ll1_l1_ (u"ࠩ࡟ࡲࡈࡩ࠺ࠡࠩ嵎") + l1lll11l1l111_l1_
	#	header += l11ll1_l1_ (u"ࠪࡠࡳ࡙ࡵࡣ࡬ࡨࡧࡹࡀࠠๆ่ࠣ็ํี๊ࠡษ็ๅ๏ี๊้ࠢส่฾ืศ๋ࠩ嵏")
	#	server = l1lllll111111_l1_.l1lll1ll11l11_l1_(l11ll1_l1_ (u"ࠫࡸࡳࡴࡱ࠯ࡶࡩࡷࡼࡥࡳࠩ嵐"),25)
	#	#server.l1llll1111111_l1_()
	#	server.l1llll1111l11_l1_(l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ嵑"),l11ll1_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ嵒"))
	#	response = server.l1llll11l1l1l_l1_(l1lll1l1ll11l_l1_,l1lll1lll1l11_l1_, header + l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嵓") + message)
	#	server.quit()
	return
def l1llll1l11l1l_l1_():
	text = l11ll1_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ嵔")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ嵕"),l11ll1_l1_ (u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ嵖"),text,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ嵗"))
	text = l11ll1_l1_ (u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨ嵘")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ嵙"),l11ll1_l1_ (u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬ嵚"),text,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ嵛"))
	return
def l1llll11111l1_l1_(addon_id):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嵜"),l11ll1_l1_ (u"ࠪࠫ嵝"),l11ll1_l1_ (u"ࠫࠬ嵞"),addon_id)
	result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ嵟")+addon_id+l11ll1_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬ嵠"))
	l1l11llll1_l1_ = True
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡸ࡮ࡵࡵ࡫࡯ࠎࠎࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡺࡥࡱࡨ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࡶࡵࡨࡶ࡫࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡹࡸ࡫ࡲࡧࡱ࡯ࡨࡪࡸࠬࠨࡣࡧࡨࡴࡴࡳࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠏࠏࡩࡧࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࡀࠊࠊࠋࡶ࡬ࡺࡺࡩ࡭࠰ࡵࡱࡹࡸࡥࡦࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡳࡧࡩࡶࡪࡹࡨࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨࡢࡦࡧࡳࡳࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡣࡧࡨࡴࡴࡳ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࠦࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡲࡦࡲࡲࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠣࠤࠥ嵡")
	if l1l11llll1_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ嵢"))
		time.sleep(1)
	return
def l1llll11lll11_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嵣"),l11ll1_l1_ (u"ࠪࠫ嵤"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ嵥"),l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪ嵦"))
	l1llll11llll1_l1_()
	return
def l1llll11lllll_l1_():
	#	https://l111ll1llll_l1_.tv/download/849
	#   https://play.l1l1l1ll11l1_l1_.com/l1lll1ll1ll11_l1_/l1lll1lllllll_l1_/details?id=l1llll111ll_l1_.xbmc.l111ll1llll_l1_
	#	http://mirror.l1llll11ll111_l1_.l1lll1l1ll1l1_l1_.l1lllll11lll1_l1_/l1llll11l11l1_l1_/xbmc/l1lll1ll1l111_l1_/l1lll11l1lll1_l1_/l1llll11l1l11_l1_
	#	http://l1lll1l11l1ll_l1_.l1lll11lll11l_l1_.l1lllll11lll1_l1_/l111ll1llll_l1_/l1lll1ll1l111_l1_/l1lll11l1lll1_l1_/l1llll11l1l11_l1_
	url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫ嵧")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ嵨"),url,l11ll1_l1_ (u"ࠨࠩ嵩"),l11ll1_l1_ (u"ࠩࠪ嵪"),l11ll1_l1_ (u"ࠪࠫ嵫"),l11ll1_l1_ (u"ࠫࠬ嵬"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨ嵭"))
	html = response.content
	l1lll11ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬ嵮"),html,re.DOTALL)
	l1lll11ll1ll1_l1_ = l1lll11ll1ll1_l1_[0].split(l11ll1_l1_ (u"ࠧ࠮ࠩ嵯"))[0]
	l1lllll11l11l_l1_ = str(kodi_version)
	#l111ll1l11l1_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ嵰")+l11ll1_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠ฻ู่่๋ࠥࠡๅ๋ำ๏ࠦลึัสีࠥ࠷࠹๊่ࠡหࠥฮูะ้ࠪ嵱")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嵲")
	l111ll1l11l1_l1_ = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭嵳")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ嵴")+l1lll11ll1ll1_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ嵵")
	l111ll1l11l1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ嵶")+l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ嵷")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ嵸")+l1lllll11l11l_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嵹")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嵺"),l11ll1_l1_ (u"ࠬ࠭嵻"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嵼"),l111ll1l11l1_l1_)
	return
def l1lll1l11lll1_l1_():
	# https://l11l1lll111_l1_-l111ll1ll11_l1_-l11l111l111_l1_.l1lllll1l1ll1_l1_.com/request-l1lll1llll1ll_l1_
	# https://l11l1lll111_l1_-l111ll1ll11_l1_-l11l111l111_l1_.l1lllll1l1ll1_l1_.com/query-l1lll11ll1lll_l1_
	l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111ll1l111l_l1_,l111ll1l11l1_l1_,l1llll1l1111l_l1_,l1lll11l1ll1l_l1_,l1lll1ll11l1l_l1_ = l11ll1_l1_ (u"ࠧࠨ嵽"),l11ll1_l1_ (u"ࠨࠩ嵾"),l11ll1_l1_ (u"ࠩࠪ嵿"),l11ll1_l1_ (u"ࠪࠫ嶀"),l11ll1_l1_ (u"ࠫࠬ嶁"),l11ll1_l1_ (u"ࠬ࠭嶂"),l11ll1_l1_ (u"࠭ࠧ嶃")
	payload,l1lll11lll111_l1_,l1llll11l111l_l1_,l1lll11ll1111_l1_ = {l11ll1_l1_ (u"ࠧࡢࠩ嶄"):l11ll1_l1_ (u"ࠨࡣࠪ嶅")},{},[],{}
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ嶆")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ嶇"),url,payload,l11ll1_l1_ (u"ࠫࠬ嶈"),l11ll1_l1_ (u"ࠬ࠭嶉"),l11ll1_l1_ (u"࠭ࠧ嶊"),l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ嶋"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨ嶌"),l11ll1_l1_ (u"ࠩࡘࡗࡆ࠭嶍"))
	html = html.replace(l11ll1_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ嶎"),l11ll1_l1_ (u"࡚ࠫࡑࠧ嶏"))
	html = html.replace(l11ll1_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ嶐"),l11ll1_l1_ (u"࠭ࡕࡂࡇࠪ嶑"))
	html = html.replace(l11ll1_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭嶒"),l11ll1_l1_ (u"ࠨࡍࡖࡅࠬ嶓"))
	html = html.replace(l11ll1_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ嶔"),l11ll1_l1_ (u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ嶕"))
	html = html.replace(l11ll1_l1_ (u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ嶖"),l11ll1_l1_ (u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ嶗"))
	html = html.replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ嶘"),l11ll1_l1_ (u"ࠧࠡࠢࠪ嶙"))
	try: l1llll11l1111_l1_ = EVAL(l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭嶚"),html)
	except:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嶛"),l11ll1_l1_ (u"ࠪࠫ嶜"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ嶝"),l11ll1_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ嶞"))
		return
	l1llll1lll11l_l1_,l1lllll11ll11_l1_,l1lll1lll1lll_l1_ = l1llll11l1111_l1_
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ嶟"),str(l1llll1lll11l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ嶠"),str(l1lllll11ll11_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ嶡"),str(l1lll1lll1lll_l1_))
	l1lll11ll1111_l1_ = {}
	l1lllll1l1lll_l1_ = [l11ll1_l1_ (u"ࠩࡄࡐࡑ࠭嶢"),l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ嶣"),l11ll1_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ嶤"),l11ll1_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ嶥"),l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ嶦")]+l1llllllll11_l1_+l111ll111ll_l1_
	for l1ll111l111_l1_,l1lllll11111l_l1_,l1llll1ll1lll_l1_ in l1lllll11ll11_l1_:
		l1llll1ll1lll_l1_ = escapeUNICODE(l1llll1ll1lll_l1_)
		l1llll1ll1lll_l1_ = l1llll1ll1lll_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ嶧")).strip(l11ll1_l1_ (u"ࠨࠢ࠱ࠫ嶨"))
		l111ll1l11l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ嶩")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶪")+l1llll1ll1lll_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ嶫")
		if l1lllll11111l_l1_.isdigit():
			l1lll11ll1111_l1_[l1ll111l111_l1_] = int(l1lllll11111l_l1_)
			if int(l1lllll11111l_l1_)>100: l1lllll11111l_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ嶬")
			else: l1lllll11111l_l1_ = l11ll1_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ嶭")
		if l1ll111l111_l1_ not in l1lllll1l1lll_l1_:
			if   l1lllll11111l_l1_==l11ll1_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ嶮"): l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠫ嶯")+l1ll111l111_l1_
			elif l1lllll11111l_l1_==l11ll1_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ嶰"): l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࠤࠥ࠭嶱")+l1ll111l111_l1_
	l1lllll1l1l1l_l1_,l1lll1ll11111_l1_,l1lll1ll11ll1_l1_ = list(zip(*l1lllll11ll11_l1_))
	for l1ll111l111_l1_ in sorted(l1ll111111ll_l1_):
		if l1ll111l111_l1_ not in l1lllll1l1l1l_l1_:
			l111ll1l11l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ嶲")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嶳")+l11ll1_l1_ (u"࠭ไศࠢํ์ัีࠧ嶴")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ嶵")
			if l1ll111l111_l1_ not in l1lllll1l1lll_l1_: l111ll1l111l_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠫ嶶")+l1ll111l111_l1_
	for l1llll1ll1lll_l1_,counts in l1llll1lll11l_l1_:
		l1llll1ll1lll_l1_ = escapeUNICODE(l1llll1ll1lll_l1_)
		l1llll1l1111l_l1_ += l1llll1ll1lll_l1_+l11ll1_l1_ (u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ嶷")+str(counts)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨ嶸")
	l1ll11l11ll_l1_ = l1ll11l11ll_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠭嶹"))
	l1ll11l1l11_l1_ = l1ll11l1l11_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ嶺"))
	l111ll1l111l_l1_ = l111ll1l111l_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ嶻"))
	l111ll1l1l11_l1_ = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ嶼")+l1ll11l1l11_l1_
	#l1111l111lll_l1_  = l11ll1_l1_ (u"ࠨ࡞ࡱࡌ࡮࡭ࡨࡖࡵࡤ࡫ࡪࡀࠠ࡜ࠢࠪ嶽")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ嶾")
	#l1111l111lll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡒ࡯ࡸࡗࡶࡥ࡬࡫ࠠ࠻ࠢ࡞ࠤࠬ嶿")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ巀")
	#l1111l111lll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࡏࡱࡘࡷࡦ࡭ࡥࠡࠢ࠽ࠤࡠࠦࠧ巁")+l111ll1l111l_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ巂")
	l111ll1l11ll_l1_  = l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦิ฻ๆ้๋ࠣํวࠡษ็ฬึ์วๆฮࠣห้ฮวาฯฬࠤ࠭๐่ๆࠢฦุ้࠯ࠠโ์า๎ํํวหࠢหำํ์ࠠๆึส็้࠭巃")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ巄")+l11ll1_l1_ (u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧ巅")+l11ll1_l1_ (u"ࠪࡠࡳ࠭巆")
	l111ll1l11ll_l1_ += l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ巇")+l111ll1l1l11_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ巈")
	l111ll1l11ll_l1_ += l11ll1_l1_ (u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣว๏ࠦแ๋ัํ์์อสࠨ巉")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ巊")+l11ll1_l1_ (u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ巋")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ巌")
	l111ll1l11ll_l1_ += l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭巍")+l111ll1l111l_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭巎")
	l1111l1llll_l1_,l1lll1l1l1111_l1_,l1llll11l1lll_l1_,l1lll1l11l11l_l1_ = 0,0,0,0
	all = l1lll11ll1111_l1_[l11ll1_l1_ (u"ࠬࡇࡌࡍࠩ巏")]
	if l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭巐") in list(l1lll11ll1111_l1_.keys()): l1111l1llll_l1_ = l1lll11ll1111_l1_[l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ巑")]
	if l11ll1_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ巒") in list(l1lll11ll1111_l1_.keys()): l1lll1l1l1111_l1_ = l1lll11ll1111_l1_[l11ll1_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ巓")]
	if l11ll1_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ巔") in list(l1lll11ll1111_l1_.keys()): l1llll11l1lll_l1_ = l1lll11ll1111_l1_[l11ll1_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ巕")]
	if l11ll1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ巖") in list(l1lll11ll1111_l1_.keys()): l1lll1l11l11l_l1_ = l1lll11ll1111_l1_[l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ巗")]
	l11lll11l111_l1_ = all-l1111l1llll_l1_-l1lll1l1l1111_l1_-l1llll11l1lll_l1_-l1lll1l11l11l_l1_
	dummy,l1llll111l1ll_l1_ = l1lll1lll1lll_l1_[0]
	dummy,l1lll1l11111l_l1_ = l1lll1lll1lll_l1_[1]
	l1lll1l1l1ll1_l1_ = l1llll111l1ll_l1_-l1lll1l11111l_l1_
	l1lll1ll11l1l_l1_ += l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ巘")+str(l1lll1l11111l_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ巙")+l11ll1_l1_ (u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭巚")
	l1lll1ll11l1l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ巛")+str(l1lll1l1l1ll1_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭巜")+l11ll1_l1_ (u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ川")
	l1lll1ll11l1l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ州")+str(l1llll111l1ll_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ巟")+l11ll1_l1_ (u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩ巠")
	l1lll1ll11l1l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ巡")+str(len(l1lll1lll1lll_l1_[2:]))+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ巢")+l11ll1_l1_ (u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩ巣")
	for l1ll1l11ll1l_l1_,l1l11l1l1lll_l1_ in l1lll1lll1lll_l1_[2:]:
		l1ll1l11ll1l_l1_ = escapeUNICODE(l1ll1l11ll1l_l1_)
		l1ll1l11ll1l_l1_ = l1ll1l11ll1l_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ巤")).strip(l11ll1_l1_ (u"࠭ࠠ࠯ࠩ工"))
		l1lll1ll11l1l_l1_ += l1ll1l11ll1l_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ左")+str(l1l11l1l1lll_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭巧")
	#l1lll1ll11l1l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲ࠳࠭巨")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭巩")+str(l11lll11l111_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭巪")+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪ巫")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ巬")+str(l1111l1llll_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ巭")+l11ll1_l1_ (u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩ差")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ巯")+str(l1lll1l11l11l_l1_)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ巰")+l11ll1_l1_ (u"ࠫ฼๊ศศฬࠣื๏ืแาࠢส่๊ิวำ่ࠣ࠾ࠥ࠭己")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ已")+str(l1lll1l1l1111_l1_)+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ巳")+l11ll1_l1_ (u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫ巴")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭巵")+str(l1llll11l1lll_l1_)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ巶")+l11ll1_l1_ (u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩ巷")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ巸")+str(len(l1llll1lll11l_l1_))+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ巹")+l11ll1_l1_ (u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭巺")
	#l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ巻")+l11ll1_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡษ็฽ฬ๊ๅࠡ์๋้ࠥษๅิࠢࠫห้ฮวาฯฬ࠭ࠬ巼")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ巽")
	l1lll11l1ll1l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ巾")+l1llll1l1111l_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ巿"),l11ll1_l1_ (u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ帀"),l1lll1ll11l1l_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ币"))
	#l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ市"),l11ll1_l1_ (u"ࠨฮ่๎฾ࠦ็ั้ࠣห้ษัใษ่ࠤฯิีࠡลึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡࠢไๆ฼๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ布"),l1lll11l1ll1l_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ帄"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ帅"),l11ll1_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ帆"),l1lll11l1ll1l_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ帇"))
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭师"),l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ帉"),l111ll1l11ll_l1_,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ帊"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ帋"),l11ll1_l1_ (u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥอไษษิัฮࠦࠨ๋๊่ࠤศ๋ำࠪࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬ希"),l111ll1l11l1_l1_,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ帍"))
	return
def l1lll1ll1l11l_l1_():
	message = l11ll1_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡลฯ์อฯࠠศๆหี๋อๅอࠩ帎")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭帏"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ帐"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ帑"))
	return
def l1l1l1llll1l_l1_():
	message = l11ll1_l1_ (u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ัึู๋ࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬ帒")+l11ll1_l1_ (u"ࠪࡠࡳ࠭帓")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ帔")+l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ帕")][0]+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ帖")+l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭帗")][1]+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ帘")
	message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮื๋่ࠣวิ์ว่๊้ࠢฬࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ帙")+l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ帚")][1]+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ帛")+l1l1lll_l1_[l11ll1_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭帜")][0]+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ帝")
	message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪ帞")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ帟")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ帠")+l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ帡")][2]+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭帢")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ帣"),l11ll1_l1_ (u"࠭วๅ็๋ห็฿ࠠศๆิื๊๐ษࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ帤"),message,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ帥"))
	return
def l1llll1lll111_l1_(l1llll1lll1l1_l1_):
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠧ带")+l1llll1lll1l1_l1_+l11ll1_l1_ (u"ࠩࠬࠫ帧"), True)
	return
def l1llll1ll111l_l1_():
	l1ll1111l_l1_(l11ll1_l1_ (u"ࠪࡷࡹࡵࡰࠨ帨"))
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠦࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࡔࡧࡷࡸ࡮ࡴࡧࡴࠫࠥ帩"))
	return
def l1lll1lll1ll1_l1_():
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠬࠫ帪"), True)
	return
def l1lll1l1lll11_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111ll1_l1_ = True
	else: l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭師"),l11ll1_l1_ (u"ࠧࠨ帬"),l11ll1_l1_ (u"ࠨࠩ席"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ帮"),l11ll1_l1_ (u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣห้ศๆࠡมࠪ帯"))
	if l1ll111ll1_l1_==1:
		xbmc.executebuiltin(l11ll1_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧ帰"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭帱"),l11ll1_l1_ (u"࠭ࠧ帲"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ帳"),l11ll1_l1_ (u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢาื์ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭帴"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭帵"))
	return
def l1lll1l1lll1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ帶"),l11ll1_l1_ (u"ࠫࠬ帷"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ常"),l11ll1_l1_ (u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭帹"))
	return
def l1lll1ll111ll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ帺"),l11ll1_l1_ (u"ࠨࠩ帻"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ帼"),l11ll1_l1_ (u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠหุ฽฻ࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭帽"))
	return
#l1llll1llll11_l1_ 	  required	and l1llll1llll11_l1_     installed	and		not l1l11l11lll1_l1_		ignore
#l1llll1llll11_l1_ not required	and	l1llll1llll11_l1_ not installed 	and 	    l1l11l11lll1_l1_		ignore
#l1llll1llll11_l1_ not required	and	l1llll1llll11_l1_ not installed 	and 	not l1l11l11lll1_l1_		ignore
#l1llll1llll11_l1_ not required	and	l1llll1llll11_l1_     installed 	and 	not l1l11l11lll1_l1_		ignore
#l1llll1llll11_l1_     required	and	l1llll1llll11_l1_ not installed 	and 	    l1l11l11lll1_l1_		l111111lll_l1_ l1lll1l1l1111_l1_	l1llll1l111l1_l1_
#l1llll1llll11_l1_     required	and	l1llll1llll11_l1_ not installed 	and 	not l1l11l11lll1_l1_		l111111lll_l1_ l1lll1l1l1111_l1_	l1llll1l111l1_l1_
#l1llll1llll11_l1_     required 	and l1llll1llll11_l1_     installed 	and 	    l1l11l11lll1_l1_		l111111lll_l1_ l1lllll11l111_l1_	l1llll1l111l1_l1_
#l1llll1llll11_l1_ not required	and	l1llll1llll11_l1_     installed 	and 	    l1l11l11lll1_l1_		l111111lll_l1_ l1lllll11l111_l1_	l1llll1l111l1_l1_
#l1ll1lll1ll1_l1_: required and not installed: l111111lll_l1_ l1lll1l1l1111_l1_
#l1ll1lll1l11_l1_: installed and l111111lll_l1_ update: l111111lll_l1_ l1lllll11l111_l1_
def l1l1l1ll111l_l1_(l1ll_l1_=True):
	l1l11ll1ll1l_l1_ = l1lll1l1llll_l1_([l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭帾")])
	l1llll11l1ll1_l1_ = []
	for addon_id in [l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ帿")]:
		if addon_id not in list(l1l11ll1ll1l_l1_.keys()): continue
		l1l11l11lll1_l1_,l1lllllll1l1_l1_,l1llll1l1l1l1_l1_,l1llll1l1l11l_l1_,l1llll1l11ll1_l1_,l1lll11lll1ll_l1_,l1llll1l11lll_l1_ = l1l11ll1ll1l_l1_[addon_id]
		if not l1lllllll1l1_l1_ or (l1lllllll1l1_l1_ and l1l11l11lll1_l1_): l1llll11l1ll1_l1_.append(addon_id)
	l1lll11l1l1ll_l1_ = len(l1llll11l1ll1_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1ll1l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1llll1l1lll1_l1_ = []
	for addon_id in l11lll11l11_l1_:
		cc.execute(l11ll1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࠧ࠷ࠢࠡࡣࡱࡨࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ幀")+addon_id+l11ll1_l1_ (u"ࠧࠣࠢ࠾ࠫ幁"))
		l1l111l111l_l1_ = cc.fetchall()
		if l1l111l111l_l1_: l1llll1l1lll1_l1_.append(addon_id)
	l1lll1lll1111_l1_ = len(l1llll1l1lll1_l1_)>0
	for addon_id in l1111111lll_l1_:
		cc.execute(l11ll1_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡱࡵ࡭࡬࡯࡮ࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭幂")+addon_id+l11ll1_l1_ (u"ࠩࠥࠤࡀ࠭幃"))
		l1lllll1ll111_l1_ = cc.fetchall()
		if l1lllll1ll111_l1_ and l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ幄") not in str(l1lllll1ll111_l1_): l1llll11l1ll1_l1_.append(addon_id)
	l1lll1l1l11ll_l1_ = len(l1llll11l1ll1_l1_)>0
	l1llll11l1ll1_l1_ = list(set(l1llll11l1ll1_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ幅"),l11ll1_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡶࡪࡶ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰ࠽ࠤࠥ࠭幆")+str(l1lll11l1l1ll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ幇"),l11ll1_l1_ (u"ࠧ࡯ࡧࡨࡨࡤࡪࡥ࡭ࡧࡷ࡭ࡳ࡭࡟ࡰ࡮ࡧࡣࡦࡪࡤࡰࡰࡶ࠾ࠥࠦࠧ幈")+str(l1lll1lll1111_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ幉"),l11ll1_l1_ (u"ࠩࡱࡩࡪࡪ࡟ࡧ࡫ࡻ࡭ࡳ࡭࡟ࡰࡴ࡬࡫࡮ࡴ࠺ࠡࠢࠪ幊")+str(l1lll1l1l11ll_l1_))
	l1l11l11lll1_l1_ = False
	if l1lll1lll1111_l1_ or l1lll1l1l11ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ幋"),l11ll1_l1_ (u"ࠫࠬ幌"),l11ll1_l1_ (u"ࠬ࠭幍"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ幎"),l11ll1_l1_ (u"ࠧศๆหี๋อๅอ๋ࠢะิࠦๅีๅ็อࠥ็๊ࠡ็ัหื์ฺࠠ็สำࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฬ๊ย็ࠢย࡟࠴ࡉࡏࡍࡑࡕࡡࠬ幏"))
		if l1ll111ll1_l1_==1:
			l1lllll1111l1_l1_ = True
			if l1lll11l1l1ll_l1_:
				l1lllll1111l1_l1_ = l1lll1l11ll1l_l1_(l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ幐"),False,False)
			l1llll111lll1_l1_ = True
			if l1lll1lll1111_l1_:
				for addon_id in l1llll1l1lll1_l1_: l1llll11111l1_l1_(addon_id)
				l1llll111lll1_l1_ = True
			l1lll1l11l111_l1_ = True
			if l1lll1l1l11ll_l1_:
				conn = sqlite3.connect(l1l1ll1l11ll_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1llll11l1ll1_l1_:
					if l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࠬ幑") in addon_id: l1lllll1ll111_l1_ = addon_id
					else: l1lllll1ll111_l1_ = l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ幒")
					try: cc.execute(l11ll1_l1_ (u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ幓")+l1lllll1ll111_l1_+l11ll1_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ幔")+addon_id+l11ll1_l1_ (u"࠭ࠢࠡ࠽ࠪ幕"))
					except: l1lll1l11l111_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ幖"))
			time.sleep(1)
			if l1lllll1111l1_l1_ or l1llll111lll1_l1_ or l1lll1l11l111_l1_:
				l1l11l11lll1_l1_ = False
				DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ幗"),l11ll1_l1_ (u"ࠩࠪ幘"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幙"),l11ll1_l1_ (u"ࠫั๐ฯࠡ࠰࠱ࠤฯ๋ࠠษ่ฯหาࠦสโ฻ํ่ࠥ๎ลึๆสัࠥอไๆะสึ๋่ࠦศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣัฺ๋๊ࠢศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ幚"))
			else:
				l1l11l11lll1_l1_ = True
				DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭幛"),l11ll1_l1_ (u"࠭ࠧ幜"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ幝"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠฦื็หาࠦๅฯษี๊ࠥ฿ๅศัࠣ์ส฻ไศฯࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬ幞"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ幟"),l11ll1_l1_ (u"ࠪࠫ幠"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ幡"),l11ll1_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦๅฯษี๊ࠥ฿ๅศัࠣวํࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ幢"))
	return l1l11l11lll1_l1_
def l1lll1l1l111l_l1_():
	l1lll11ll111l_l1_,l1llll1l1ll11_l1_,l1llll1l111ll_l1_ = False,l11ll1_l1_ (u"࠭ࠧ幣"),l11ll1_l1_ (u"ࠧࠨ幤")
	l1llll1llll1l_l1_,l1lll1lllll1l_l1_,l1llll111l1l1_l1_ = False,l11ll1_l1_ (u"ࠨࠩ幥"),l11ll1_l1_ (u"ࠩࠪ幦")
	l1l11ll1ll1l_l1_ = l1lll1l1llll_l1_([l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ幧"),l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭幨"),l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ幩")])
	for addon_id in [l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ幪"),l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ幫"),l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ幬")]:
		if addon_id not in list(l1l11ll1ll1l_l1_.keys()): continue
		l1l11l11lll1_l1_,l1lllllll1l1_l1_,l111l11l11l_l1_,l1lll11111l1_l1_,l11l1l1lll1_l1_,l11ll1lll11_l1_,l1l11l11ll11_l1_ = l1l11ll1ll1l_l1_[addon_id]
		if addon_id==l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ幭"):
			l1llll1llll1l_l1_ = l1l11l11lll1_l1_
			l1lll1lllll1l_l1_ = l11ll1_l1_ (u"ࠪࠬࠬ幮")+l1lllllll1l1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭幯")+TRANSLATE(l11ll1lll11_l1_)+l11ll1_l1_ (u"ࠬ࠯ࠧ幰")
			l1llll111l1l1_l1_ = l1lll11111l1_l1_
		elif addon_id==l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ幱"):
			l1lll11ll111l_l1_ = l1lll11ll111l_l1_ or l1l11l11lll1_l1_
			l1llll1l1ll11_l1_ += l11ll1_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠮ࠧ干")+l1lllllll1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠪ平")+TRANSLATE(l11ll1lll11_l1_)+l11ll1_l1_ (u"ࠩࠬࠫ年")
			l1llll1l111ll_l1_ += l11ll1_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠩ幵")+l1lll11111l1_l1_
		elif addon_id==l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ并"):
			l1lll1ll1l1ll_l1_ = l1l11l11lll1_l1_
			l1lll1ll1111l_l1_ = l11ll1_l1_ (u"ࠬ࠮ࠧ幷")+l1lllllll1l1_l1_+l11ll1_l1_ (u"࠭ࠠࠨ幸")+TRANSLATE(l11ll1lll11_l1_)+l11ll1_l1_ (u"ࠧࠪࠩ幹")
			l1llll1l11111_l1_ = l1lll11111l1_l1_
	l1llll1l1ll11_l1_ = l1llll1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ幺"))
	l1llll1l111ll_l1_ = l1llll1l111ll_l1_.strip(l11ll1_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ幻"))
	l1l11ll1l1_l1_  = l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ幼")+l1llll111l1l1_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭幽")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ幾")+l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆหี๋อๅอࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ广")+l1lll1lllll1l_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ庀")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭庁")+l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่าื์ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ庂")+l1llll1l111ll_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ広")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ庄")+l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ัึู๋ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ庅")+l1llll1l1ll11_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ庆")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ庇")+l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ庈")+l1llll1l11111_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ庉")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭床")+l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ庋")+l1lll1ll1111l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ庌")
	l1l11l11lll1_l1_ = (l1llll1llll1l_l1_ or l1lll11ll111l_l1_)
	if l1l11l11lll1_l1_:
		header = l11ll1_l1_ (u"࠭วๅำฯหฦࠦสฮัํฯࠥหึศใสฮ้่ࠥะ์่ࠣา๊ࠠศๆุ่ฬ้ไࠨ庍")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠧศ่อࠤอำวอห่ࠣฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤฯำฯ๋อ้ࠣำุๆࠡ฻่หิ࠭庎")
	else:
		header = l11ll1_l1_ (u"ࠨฯส่๏อࠠๅษࠣ๎ําฯࠡฬะำ๏ัวหࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤ๊ิา็ࠢ฼้ฬีࠧ序")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠩส่ึาวยࠢศฬ้อฺࠡษ็้อืๅอࠢ฼๊ࠥอไๆึๆ่ฮࠦวๅฬํࠤฯ๎วอ้ๆࠫ庐")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"่่ࠪ๐๋ࠠ฻่่ࠥ฿ๆะๅࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏๊ࠦอสࠣว๋๊ࠦไ๊้ࠤ้ี๊ไࠢไ๎้่ࠥะ์࡟ࡲ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩ庑")
	l1ll11ll1l_l1_ = l1l11ll1l1_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ庒")+l1l1l1ll11_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ库")+l1l1l1l1ll_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ应"),header,l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ底"))
	return
def l1ll1l1ll111_l1_(l1ll_l1_=True,l1lll1l1l1lll_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ庖"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡊ࡟ࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ店"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭庘"),l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ庙"))
	if l1ll_l1_:
		l1lll1l1l111l_l1_()
		l1llll11lllll_l1_()
	if l1lll1l1l1lll_l1_:
		l1l1l1ll111l_l1_(False)
		l1lllll1l11l1_l1_,l1lll1l111l1l_l1_,l1lll1l1l1l1l_l1_ = l1lll1l11ll1l_l1_(l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ庚"),True,False)
		l1lllll1l11ll_l1_,l1lll1l111l1l_l1_,l1llll1l1ll1l_l1_ = l1lll1l11ll1l_l1_(l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ庛"),True,False)
		l1lll1l1lll11_l1_(l1ll_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ府"))
	return
def l1llll11ll11l_l1_(l1llll1ll11ll_l1_=l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ庝"),l1ll_l1_=True):
	l111l1ll1ll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ庞"))
	import json
	data = json.loads(l111l1ll1ll_l1_)
	l1lll11lll1l1_l1_ = data[l11ll1_l1_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ废")][l11ll1_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ庠")]
	if kodi_version<19: l1lll11lll1l1_l1_ = l1lll11lll1l1_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ庡"))
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ庢"),l11ll1_l1_ (u"ࠧࠨ庣"),l11ll1_l1_ (u"ࠨࠩ庤"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庥"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨ度")+l1lll11lll1l1_l1_+l11ll1_l1_ (u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭座")+l1llll1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠦฟࠢࠩ庨"))
		if l1ll111ll1_l1_!=1: return False
	succeeded,l1llll1l11l11_l1_,l1lll11llll1l_l1_ = l1lll1l11ll1l_l1_(l1llll1ll11ll_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ庩"),l11ll1_l1_ (u"ࠧࠨ庪"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ庫"),l11ll1_l1_ (u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫ庬"))
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧ庭")+l1llll1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠧࢃࡽࠨ庮"))
		if l11ll1_l1_ (u"ࠬࡕࡋࠨ庯") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭庰"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ庱"),l11ll1_l1_ (u"ࠨࠩ庲"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庳"),l11ll1_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬ庴"))
	return succeeded
def l11l1l11ll1_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11ll1_l1_ (u"ࠫࠬ庵"): l1ll_l1_ = True
	#l1lll11l11l1_l1_ = xbmc.getCondVisibility(l11ll1_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ庶")+addon_id+l11ll1_l1_ (u"࠭ࠩࠨ康"))
	l11l1lll11l_l1_ = l1ll111l1l1l_l1_([addon_id])
	l11l111l1ll_l1_,l1lll11l11l1_l1_ = l11l1lll11l_l1_[addon_id]
	if l1lll11l11l1_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ庸"),l11ll1_l1_ (u"ࠨࠩ庹"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庺"),l11ll1_l1_ (u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬ庻")+addon_id+l11ll1_l1_ (u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧ庼"))
	else:
		succeeded = False
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ庽"),l11ll1_l1_ (u"࠭ࠧ庾"),l11ll1_l1_ (u"ࠧࠨ庿"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ廀"),l11ll1_l1_ (u"ࠩࠪ廁")+addon_id+l11ll1_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨ廂"))
		if l1ll111ll1_l1_==1:
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫ廃")+addon_id+l11ll1_l1_ (u"ࠬ࠯ࠧ廄"))
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭廅"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11ll1_l1_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ廆")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ廇")+addon_id+l11ll1_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ廈"))
			if l11ll1_l1_ (u"ࠪࡓࡐ࠭廉") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ廊"),l11ll1_l1_ (u"ࠬ࠭廋"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ廌"),l11ll1_l1_ (u"ࠧห็ࠣๅา฻ࠠฤ๊ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭廍"))
			elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ廎"),l11ll1_l1_ (u"ࠩࠪ廏"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭廐"),l11ll1_l1_ (u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭廑"))
	return succeeded
def l1lll1l1llll1_l1_(addon_id,l1l11l11ll11_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭廒"),l11ll1_l1_ (u"࠭ࠧ廓"),l11ll1_l1_ (u"ࠧࠨ廔"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ廕"),l11ll1_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬ廖"))
		if l1ll111ll1_l1_!=1: return False
	l1lll11ll1l11_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l11ll11_l1_,{},l1ll_l1_)
	if l1lll11ll1l11_l1_:
		l1l11l1ll111_l1_ = os.path.join(l1ll11llll_l1_,addon_id)
		l1ll11l1ll_l1_(l1l11l1ll111_l1_,True,False)
		import zipfile,io
		l1lll1lllll11_l1_ = io.BytesIO(l1lll11ll1l11_l1_)
		zf = zipfile.ZipFile(l1lll1lllll11_l1_)
		zf.extractall(l1ll11llll_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ廗"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ廘")+addon_id+l11ll1_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ廙"))
		if l11ll1_l1_ (u"࠭ࡏࡌࠩ廚") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ廛"),l11ll1_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ廜"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ廝"),l11ll1_l1_ (u"ࠪࠫ廞"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ廟"),l11ll1_l1_ (u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ廠"))
		else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ廡"),l11ll1_l1_ (u"ࠧࠨ廢"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ廣"),l11ll1_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ廤"))
	return succeeded
def l1lll1l11ll1l_l1_(addon_id,l1ll_l1_,l1lll1ll1lll1_l1_):
	l1ll111ll1_l1_,succeeded,l1llll1l11l11_l1_,l1lllllll1l1_l1_ = True,False,l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ廥"),l11ll1_l1_ (u"ࠫࠬ廦")
	l1l11ll1ll1l_l1_ = l1lll1l1llll_l1_([addon_id])
	if addon_id in list(l1l11ll1ll1l_l1_.keys()):
		l1l11l11lll1_l1_,l1lllllll1l1_l1_,l111l11l11l_l1_,l1lll11111l1_l1_,l11l1l1lll1_l1_,l11ll1lll11_l1_,l1l11l11ll11_l1_ = l1l11ll1ll1l_l1_[addon_id]
		if l11ll1lll11_l1_==l11ll1_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ廧"):
			succeeded,l1llll1l11l11_l1_ = True,l11ll1_l1_ (u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧ廨")
			if l1lll1ll1lll1_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ廩"),l11ll1_l1_ (u"ࠨࠩ廪"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ廫"),l11ll1_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠไ๊า๎ࠥ๐ำหะา้ࠥษฮาࠢศูิอัࠡ็อ์ๆืࠠโ์้ࠣํอโฺ่ࠢาื์ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ廬")+addon_id)
		else:
			if l1ll_l1_:
				if l11ll1lll11_l1_==l11ll1_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭廭"): message = l11ll1_l1_ (u"๋ࠬส้ไไอࠬ廮")
				elif l11ll1lll11_l1_==l11ll1_l1_ (u"࠭࡯࡭ࡦࠪ廯"): message = l11ll1_l1_ (u"ࠧใัํ้ฮ࠭廰")
				elif l11ll1lll11_l1_==l11ll1_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ廱"): message = l11ll1_l1_ (u"ࠩ฽๎ึࠦๅฬสออࠬ廲")
				l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ廳"),l11ll1_l1_ (u"ࠫࠬ廴"),l11ll1_l1_ (u"ࠬ࠭廵"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ延"),l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭廷")+message+l11ll1_l1_ (u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪ廸")+addon_id)
			if not l1ll111ll1_l1_: l1llll1l11l11_l1_ = l11ll1_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ廹")
			else:
				if l11ll1lll11_l1_==l11ll1_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ建"):
					results = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ廻")+addon_id+l11ll1_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ廼"))
					if l11ll1_l1_ (u"࠭ࡏࡌࠩ廽") in results:
						succeeded,l1llll1l11l11_l1_ = True,l11ll1_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨ廾")
						if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ廿"),l11ll1_l1_ (u"ࠩࠪ开"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭弁"),l11ll1_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩ异")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭弃"),l11ll1_l1_ (u"࠭ࠧ弄"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ弅"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫ弆")+addon_id)
				elif l11ll1lll11_l1_ in [l11ll1_l1_ (u"ࠩࡲࡰࡩ࠭弇"),l11ll1_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ弈")]:
					succeeded = l1lll1l1llll1_l1_(addon_id,l1l11l11ll11_l1_,False)
					if succeeded:
						if l11ll1lll11_l1_==l11ll1_l1_ (u"ࠫࡴࡲࡤࠨ弉"): l1llll1l11l11_l1_ = l11ll1_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭弊")
						elif l11ll1lll11_l1_==l11ll1_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ弋"): l1llll1l11l11_l1_ = l11ll1_l1_ (u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪ弌")
						l1lllllll1l1_l1_ = l1lll11111l1_l1_
						if l1ll_l1_:
							if l1llll1l11l11_l1_==l11ll1_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩ弍"): DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ弎"),l11ll1_l1_ (u"ࠪࠫ式"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ弐"),l11ll1_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ弑")+addon_id)
							elif l1llll1l11l11_l1_==l11ll1_l1_ (u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ弒"): DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ弓"),l11ll1_l1_ (u"ࠨࠩ弔"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ引"),l11ll1_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫ弖")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ弗"),l11ll1_l1_ (u"ࠬ࠭弘"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ弙"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ弚")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ弛"),l11ll1_l1_ (u"ࠩࠪ弜"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭弝"),l11ll1_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦ็ั้ࠣห้หึศใฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤ๊๎วใ฻้ࠣำุๆࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭弞")+addon_id)
	return succeeded,l1llll1l11l11_l1_,l1lllllll1l1_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬྙ")
headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨྚ"):l11ll1_l1_ (u"ࠬ࠭ྛ")}
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬྜ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧศๆิส๏ู๊สࠩྜྷ"),l11ll1_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอ๋ࠨྞ"),l11ll1_l1_ (u"ู่ࠩฬืู่ࠩྟ"),l11ll1_l1_ (u"ࠪห฾๊ๆࠡ็฼๊ฬࠦ⠓ࠡࡈࡲࡶࠥࡧࡤࡴࠩྠ"),l11ll1_l1_ (u"๊ࠫ๎ศศ์็หฯ࠭ྡ"),l11ll1_l1_ (u"ࠬฮัศ็ฯࠤ่๋ศ๋๊อีࠬྡྷ"),l11ll1_l1_ (u"࠭วๅ฻สฬ้ࠥๅษ์๋ฮึ࠭ྣ"),l11ll1_l1_ (u"ࠧศี็ห๊๐วหࠩྤ"),l11ll1_l1_ (u"ࠨษัี๎࠭ྥ"),l11ll1_l1_ (u"ࠩสๆุอๅࠡษัี๏࠭ྦ"),l11ll1_l1_ (u"ࠪหูะัศๅสฮࠬྦྷ")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l11111_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l1llll11_l1_(url)
	elif mode==254: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫྨ")+text)
	elif mode==255: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩྩ")+text)
	elif mode==256: results = l1l111_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྪ"):l11lllll1_l1_()}
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫྫ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡥ࡮ࡴࠧྫྷ"),l11ll1_l1_ (u"ࠩࠪྭ"),headers,l11ll1_l1_ (u"ࠪࠫྮ"),l11ll1_l1_ (u"ࠫࠬྯ"),l11ll1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩྰ"))
	html = response.content
	#l11l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬྱ"),html,re.DOTALL)
	#if l11l11l1_l1_: l11l11l1_l1_ = SERVER(l11l11l1_l1_[0],l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫྲ"))
	#else: l11l11l1_l1_ = l11l1l_l1_
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨླ"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩྴ"),l11ll1_l1_ (u"ࠪࠫྵ"),259,l11ll1_l1_ (u"ࠫࠬྶ"),l11ll1_l1_ (u"ࠬ࠭ྷ"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪྸ"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧྐྵ"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫྺ"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪྻ"),254)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྼ"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ྽"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭྾"),255)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ྿"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࿀"),l11ll1_l1_ (u"ࠨࠩ࿁"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿂"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ࿃"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪ࿄"),251,l11ll1_l1_ (u"ࠬ࠭࿅"),l11ll1_l1_ (u"࿆࠭ࠧ"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡥ࡮ࡴࠧ࿇"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿈"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࿉")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ࿊"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪ࿋"),251,l11ll1_l1_ (u"ࠬ࠭࿌"),l11ll1_l1_ (u"࠭ࠧ࿍"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ࿎"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿏"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࿐")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ࿑"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪ࿒"),251,l11ll1_l1_ (u"ࠬ࠭࿓"),l11ll1_l1_ (u"࠭ࠧ࿔"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭࿕"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿖"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࿗")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪ࿘"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡡࡵࡧࡶࡸࠬ࿙"),251,l11ll1_l1_ (u"ࠬ࠭࿚"),l11ll1_l1_ (u"࠭ࠧ࿛"),l11ll1_l1_ (u"ࠧ࡭ࡣࡶࡸࡪࡹࡴࠨ࿜"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭࿝"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࿞"),l11ll1_l1_ (u"ࠪࠫ࿟"),9999)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒ࡫࡮ࡶࡊࡨࡥࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭࿠"),html,re.DOTALL)
	l111l_l1_ = l1l111l_l1_[0]
	l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࿡"),l111l_l1_,re.DOTALL)
	for l1lllll_l1_,title in l1l1l1l_l1_:
		title = unescapeHTML(title)
		if title not in l1l11l_l1_ and title!=l11ll1_l1_ (u"࠭ࠧ࿢"):
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ࿣") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			#l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠨ࠱ࠪ࿤")).replace(SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭࿥")),l11l1l_l1_)
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿦"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿧")+l111l1_l1_+title,l1lllll_l1_,256)
	return html
def l1l111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭࿨"),l11ll1_l1_ (u"࠭ࠧ࿩"),l11ll1_l1_ (u"ࠧࡔࡗࡅࡑࡊࡔࡕࠡࠢࠣࠤࠥ࠭࿪")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ࿫"),url,l11ll1_l1_ (u"ࠩࠪ࿬"),headers,l11ll1_l1_ (u"ࠪࠫ࿭"),l11ll1_l1_ (u"ࠫࠬ࿮"),l11ll1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ࿯"))
	html = response.content
	if l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠨ࿰") in html: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿱"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ว่ััࠡ็ืห์ีษࠨ࿲"),url,251,l11ll1_l1_ (u"ࠩࠪ࿳"),l11ll1_l1_ (u"ࠪࠫ࿴"),l11ll1_l1_ (u"ࠫࡲࡵࡳࡵࠩ࿵"))
	if l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓࡡࡪࡰࡖࡰ࡮ࡪࡥࡴࠩ࿶") in html: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࿷"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่้๏ุษࠨ࿸"),url,251,l11ll1_l1_ (u"ࠨࠩ࿹"),l11ll1_l1_ (u"ࠩࠪ࿺"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ࿻"))
	if l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧ࿼") in html:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩ࡯࡭ࡶࡐ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࿽"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			if len(l1l1l11_l1_)>1 and type==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࿾"): block = l1l1l11_l1_[1]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ࿿"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩက"),title,re.DOTALL)
				try: l11l1ll11_l1_ = l1lll1l11_l1_[0][0]
				except: l11l1ll11_l1_ = l11ll1_l1_ (u"ࠩࠪခ")
				try: l11l1ll1l_l1_ = l1lll1l11_l1_[0][1]
				except: l11l1ll1l_l1_ = l11ll1_l1_ (u"ࠪࠫဂ")
				l1lll1l11_l1_ = l11l1ll11_l1_+l11l1ll1l_l1_
				l1lll1l11_l1_ = l1lll1l11_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧဃ"),l11ll1_l1_ (u"ࠬ࠭င"))
				#LOG_THIS(l11ll1_l1_ (u"࠭ࠧစ"),str(l1lll1l11_l1_))
				if l11ll1_l1_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠩဆ") in title:
					l11l1l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬဇ"),title,re.DOTALL)
					if l11l1l111_l1_: l1lll1l11_l1_ = l11l1l111_l1_[0]
				if not l1lll1l11_l1_:
					l11l1l111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧဈ"),title,re.DOTALL)
					if l11l1l111_l1_: l1lll1l11_l1_ = l11l1l111_l1_[0]
				if l1lll1l11_l1_:
					if l11ll1_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨဉ") in l1lllll_l1_: type = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩည"))[1]
					else: type = l11ll1_l1_ (u"ࠬࡴࡥࡸࡧࡶࡸࠬဋ")
					#l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"࠭࠯ࠨဌ")).replace(SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫဍ")),l11l1l_l1_)
					l1lll1l11_l1_ = l1lll1l11_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪဎ"))
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩဏ"),l111l1_l1_+l1lll1l11_l1_,l1lllll_l1_,251,l11ll1_l1_ (u"ࠪࠫတ"),l11ll1_l1_ (u"ࠫࠬထ"),type)
	return
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ဒ"),l11ll1_l1_ (u"࠭ࠧဓ"),l11ll1_l1_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠠࠡࠢࠣࠤࠬန")+type,url)
	method,data,items = l11ll1_l1_ (u"ࠨࡉࡈࡘࠬပ"),l11ll1_l1_ (u"ࠩࠪဖ"),[]
	if type==l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫဗ"):
		if l11ll1_l1_ (u"ࠫࡄ࠭ဘ") in url:
			l11ll1111_l1_,l11ll111l_l1_ = l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪမ"),{}
			l111lll_l1_,l11ll11l1_l1_ = url.split(l11ll1_l1_ (u"࠭࠿ࠨယ"))
			lines = l11ll11l1_l1_.split(l11ll1_l1_ (u"ࠧࠧࠩရ"))
			for line in lines:
				key,value = line.split(l11ll1_l1_ (u"ࠨ࠿ࠪလ"))
				l11ll111l_l1_[key] = value
			if lines: method,url,data = l11ll1111_l1_,l111lll_l1_,l11ll111l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l11ll1_l1_ (u"ࠩࠪဝ"),l11ll1_l1_ (u"ࠪࠫသ"),l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪဟ"))
	html = response.content
	#html = html[99000:]
	if type==l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ဠ"): l1l1l11_l1_ = [html]
	elif l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨအ") in type: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫဢ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬဣ"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆสๅ้อๅ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴࡌࡲࡘ࡫ࡣࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩဤ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩဥ"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫဦ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡶࠪဧ"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡒࡩ࡯࡭ࡶࡐ࡮ࡹࡴࠨဨ"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡃ࡮ࡲࡧࡰࡹ࠭ࡖࡎࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡃࡥࡳࡊࡲࡓࡦࡧࡧࠦࠬဩ"),html,re.DOTALL)
	if l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪဪ") in type:
		block = l1l1l11_l1_[0]
		zz = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡮ࡤࡾࡾ࠴ࠪࡀࠢࠫࡷࡷࡩࡼࡥࡣࡷࡥ࠲࡯࡭ࡢࡩࡨ࠭ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ါ"),block,re.DOTALL)
		if zz:
			l1llll_l1_,l1lll111_l1_,l11lll111_l1_,l1l11111l_l1_ = zip(*zz)
			items = zip(l1llll_l1_,l1l11111l_l1_,l1lll111_l1_)
	else:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡐࡴࡧࡤࡪࡰࡪࡅࡷ࡫ࡡ࠯ࠬࡂࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡤࡢࡶࡤ࠱ࡡࡽࡻ࠴࠮࠸ࢁࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧာ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠫ࡜࡝ࡅࠨိ") in title: continue
		#l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠬ࠵ࠧီ")).replace(SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪု")),l11l1l_l1_)
		#l1lll1_l1_ = l1lll1_l1_.rstrip(l11ll1_l1_ (u"ࠧ࠰ࠩူ")).replace(SERVER(l1lll1_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬေ")),l11l1l_l1_)
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠩส่า๊โสࠩဲ") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ဳ"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪဴ") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဵ"),l111l1_l1_+title,l1lllll_l1_,253,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬံ"),l111l1_l1_+title,l1lllll_l1_,252,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰့ࠩ") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧး") in title:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ္ࠩ"),l111l1_l1_+title,l1lllll_l1_,253,l1lll1_l1_)
		else:
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ်ࠩ"),l111l1_l1_+title,l1lllll_l1_,252,l1lll1_l1_)
	if type in [l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡦࡵࡷࠫျ"),l11ll1_l1_ (u"ࠬࡨࡥࡴࡶࠪြ"),l11ll1_l1_ (u"࠭࡭ࡰࡵࡷࠫွ")]:
		items = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡴࡵ࡮ࡤࡨࡶࡸࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ှ"),html,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဿ"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ၀")+title,l1lllll_l1_,251,l11ll1_l1_ (u"ࠪࠫ၁"),l11ll1_l1_ (u"ࠫࠬ၂"),type)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ၃"),url,l11ll1_l1_ (u"࠭ࠧ၄"),headers,l11ll1_l1_ (u"ࠧࠨ၅"),l11ll1_l1_ (u"ࠨࠩ၆"),l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ၇"))
	html = response.content
	#items = re.findall(l11ll1_l1_ (u"ࠪࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡖ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၈"),html,re.DOTALL)
	# the first 10000 character of the html file is l11l1lll1_l1_ l11lll11l_l1_ in l11lll1ll_l1_ .. it l11ll1ll1_l1_ l11l1l1ll_l1_
	html = html[10000:]
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ၉"),html,re.DOTALL)
	if not items: return
	l1lll1_l1_,name = items[0]
	if l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ၊") in name: name = name.split(l11ll1_l1_ (u"࠭วๅฯ็ๆฮ࠭။"))[0].strip(l11ll1_l1_ (u"ࠧࠡࠩ၌"))
	elif l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭၍") in name: name = name.split(l11ll1_l1_ (u"ࠩะ่็ฯࠧ၎"))[0].strip(l11ll1_l1_ (u"ࠪࠤࠬ၏"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪၐ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧၑ"),block,re.DOTALL)
		for l1lllll_l1_,l1ll1l1_l1_ in items:
			title = name+l11ll1_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢิๆ๊ࠦࠧၒ")+l1ll1l1_l1_
			#l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠧ࠰ࠩၓ")).replace(SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬၔ")),l11l1l_l1_)
			#l1lll1_l1_ = l1lll1_l1_.rstrip(l11ll1_l1_ (u"ࠩ࠲ࠫၕ")).replace(SERVER(l1lll1_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧၖ")),l11l1l_l1_)
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪၗ"),l111l1_l1_+title,l1lllll_l1_,252,l1lll1_l1_)
	else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫၘ"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫၙ"),url,252,l1lll1_l1_)
	return
def l11l111ll_l1_(title,l1lllll_l1_):
	l1lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡜ࡣ࠰ࡾࡆ࠳࡚࠮࡟࠮ࠫၚ"),title,re.DOTALL)
	if l1lll1l11_l1_: title = l1lll1l11_l1_[0]
	else: title = title+l11ll1_l1_ (u"ࠨࠢࠪၛ")+SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧၜ"))
	title = title.replace(l11ll1_l1_ (u"ࠪ฽ึฮࠠิ์าࠫၝ"),l11ll1_l1_ (u"ࠫࠬၞ")).replace(l11ll1_l1_ (u"๋ࠬศศึิࠫၟ"),l11ll1_l1_ (u"࠭ࠧၠ")).replace(l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧၡ"),l11ll1_l1_ (u"ࠨࠩၢ"))
	title = title.replace(l11ll1_l1_ (u"ࠩ๐ࠫၣ"),l11ll1_l1_ (u"ࠪࠫၤ"))
	title = title.replace(l11ll1_l1_ (u"ࠫࠥࠦࠧၥ"),l11ll1_l1_ (u"ࠬࠦࠧၦ")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩၧ"),l11ll1_l1_ (u"ࠧࠡࠩၨ"))
	return title
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬၩ"),url,l11ll1_l1_ (u"ࠩࠪၪ"),headers,l11ll1_l1_ (u"ࠪࠫၫ"),l11ll1_l1_ (u"ࠫࠬၬ"),l11ll1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩၭ"))
	html = response.content
	l111lll_l1_ = response.url
	server = SERVER(l111lll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪၮ"))
	headers[l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨၯ")] = server+l11ll1_l1_ (u"ࠨ࠱ࠪၰ")
	l11l111l1_l1_,l11ll1l1l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠩࠪၱ"),l11ll1_l1_ (u"ࠪࠫၲ"),[]
	# l11l1l1l1_l1_ & download l11l111l_l1_
	l1l111111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡅࡹࡹࡺ࡯࡯ࡵࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡷࡢࡶࡦ࡬࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠭ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࠫࡁࠬࠦࠬၳ"),html,re.DOTALL)
	if l1l111111_l1_: l11l111l1_l1_,l11ll1lll_l1_,l11ll1l1l_l1_,l11ll11ll_l1_ = l1l111111_l1_[0]
	else:
		l1l111111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡆࡺࡺࡴࡰࡰࡶࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ၴ"),html,re.DOTALL)
		if l1l111111_l1_:
			l1lllll_l1_,l11ll1lll_l1_ = l1l111111_l1_[0]
			if l11ll1_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬၵ") in l11ll1lll_l1_: l11l111l1_l1_ = l1lllll_l1_
			else: l11ll1l1l_l1_ = l1lllll_l1_
	if l11l111l1_l1_:
		# l11l1l1l1_l1_ l1l1_l1_
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫၶ"),l11l111l1_l1_,l11ll1_l1_ (u"ࠨࠩၷ"),headers,l11ll1_l1_ (u"ࠩࠪၸ"),l11ll1_l1_ (u"ࠪࠫၹ"),l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨၺ"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡩࡷࡇࡲࡦࡣࠥࠬ࠳࠰࠿࠽࠱ࡸࡰࡃ࠯ࠧၻ"),html,re.DOTALL)
		if l1l1l11_l1_:
			l111lllll_l1_ = l1l1l11_l1_[0]
			l111lllll_l1_ = l111lllll_l1_.replace(l11ll1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬၼ"),l11ll1_l1_ (u"ࠧ࠽ࡪ࠶ࡂࠬၽ"))
			l111lllll_l1_ = l111lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࠾࡫࠷ࡃ࠭ၾ"),l11ll1_l1_ (u"ࠩ࠿࡬࠸ࡄ࠼ࡩ࠵ࡁࠫၿ"))
			l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀ࡭࠹࠾࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼ࡩ࠵ࡁࠫႀ"),l111lllll_l1_,re.DOTALL)
			if not l1111l1_l1_: l1111l1_l1_ = [(l11ll1_l1_ (u"ࠫࠬႁ"),l111lllll_l1_)]
			for l111lll1_l1_,block in l1111l1_l1_:
				if l111lll1_l1_: l111lll1_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪႂ")+l111lll1_l1_
				items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪႃ"),block,re.DOTALL)
				for l1lllll_l1_,name in items:
					if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬႄ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧႅ")+l1lllll_l1_
					#name = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩ࡫ࡳࡸࡺࠧႆ"))
					l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫႇ")+name+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬႈ")+l111lll1_l1_
					l1llll_l1_.append(l1lllll_l1_)
		# l1l111l11_l1_ l1lllll_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡊࡨࡵࡥࡲ࡫ࠢ࠯ࠬࡂࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ႉ"),html,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࡋࡩࡶࡦࡳࡥࠣ࠰࠭ࡃ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡈࡆࡋࡊࡌ࡙ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧႊ"),html,re.DOTALL)
		if l1l1_l1_:
			l1lllll_l1_,l111lll1_l1_ = l1l1_l1_[0]
			name = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬႋ"))
			if l11ll1_l1_ (u"ࠨࠧࠪႌ") in l111lll1_l1_: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ႍࠪ")+name+l11ll1_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭ႎ")
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬႏ")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࡠࡡࠪ႐")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	if l11ll1l1l_l1_:
		# download l1l1_l1_
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ႑"),l11ll1l1l_l1_,l11ll1_l1_ (u"ࠧࠨ႒"),headers,l11ll1_l1_ (u"ࠨࠩ႓"),l11ll1_l1_ (u"ࠩࠪ႔"),l11ll1_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ႕"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡇࡲࡦࡣࠥࠬ࠳࠰࠿ࠪࡨࡸࡲࡨࡺࡩࡰࡰࠪ႖"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ႗"),block,re.DOTALL)
			for l1lllll_l1_,title,l111lll1_l1_ in items:
				if not l1lllll_l1_: continue
				# l11l1llll_l1_ l11l11111_l1_ by l11l11l11_l1_ .. it l11lll1l1_l1_ a l11l11lll_l1_ from l11l11l11_l1_ l1l1111l1_l1_
				if l11ll1_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡹࡴࡢࡶ࡬ࡳࡳ࠭႘") in l1lllll_l1_: continue
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
				#title = l11l111ll_l1_(title,l1lllll_l1_)
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ႙")+title+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩႚ")+l111lll1_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧႛ"), l1llll_l1_)
	l11l11ll1_l1_ = str(l1llll_l1_)
	l111ll1_l1_ = [l11ll1_l1_ (u"ࠪ࠲ࡿ࡯ࡰࡀࠩႜ"),l11ll1_l1_ (u"ࠫ࠳ࡸࡡࡳࡁࠪႝ"),l11ll1_l1_ (u"ࠬ࠴ࡴࡹࡶࡂࠫ႞"),l11ll1_l1_ (u"࠭࠮ࡱࡦࡩࡃࠬ႟"),l11ll1_l1_ (u"ࠧ࠯ࡶࡤࡶࡄ࠭Ⴀ"),l11ll1_l1_ (u"ࠨ࠰࡬ࡷࡴࡅࠧႡ"),l11ll1_l1_ (u"ࠩ࠱ࡾ࡮ࡶ࠮ࠨႢ"),l11ll1_l1_ (u"ࠪ࠲ࡷࡧࡲ࠯ࠩႣ"),l11ll1_l1_ (u"ࠫ࠳ࡺࡸࡵ࠰ࠪႤ"),l11ll1_l1_ (u"ࠬ࠴ࡰࡥࡨ࠱ࠫႥ"),l11ll1_l1_ (u"࠭࠮ࡵࡣࡵ࠲ࠬႦ"),l11ll1_l1_ (u"ࠧ࠯࡫ࡶࡳ࠳࠭Ⴇ")]
	if any(value in l11l11ll1_l1_ for value in l111ll1_l1_):
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩႨ"),l11ll1_l1_ (u"ࠩࠪႩ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ⴊ"),l11ll1_l1_ (u"ࠫัืศࠡำสฬ฼ࠦๅฯฬ็ๅ๊ࠥร็๊ࠢิฬࠦวๅำสฬ฼ࠦไ๋ี้๋ࠣࠦๆ้฻ࠣห้ื่ศสฺࠤฬ๊ส๋ࠢไ๎์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡๆฦ๊ࠥํะศࠢส่๊๎โฺࠢไ๎์ࠦฮะ็สฮࠥษฮา๋ࠣ฾๏ืࠠๆๆไหฯࠦวๅใํำ๏๎ࠧႫ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫႬ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨႭ"),l11ll1_l1_ (u"ࠧࠬࠩႮ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩ࡭ࡳࡪ࠯ࡀࡨ࡬ࡲࡩࡃࠧႯ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩႰ"))
	return
def l1ll1lll_l1_(url,filter):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫႱ"),l11ll1_l1_ (u"ࠫࠬႲ"),filter,url)
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭Ⴓ"):url,l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪႴ"):l11ll1_l1_ (u"ࠧࠨႵ")}
	#l1l1ll111_l1_ = l11ll1_l1_ (u"ࠨࠩႶ")
	#filter = filter.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫႷ"),l11ll1_l1_ (u"ࠪࠫႸ"))
	if l11ll1_l1_ (u"ࠫࡄࡅࠧႹ") in url: url = url.split(l11ll1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫႺ"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪႻ"),1)
	if filter==l11ll1_l1_ (u"ࠧࠨႼ"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠨࠩႽ"),l11ll1_l1_ (u"ࠩࠪႾ")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠪࡣࡤࡥࠧႿ"))
	if type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨჀ"):
		if l1l1111ll_l1_[0]+l11ll1_l1_ (u"ࠬࡃ࠽ࠨჁ") not in l1l111l1_l1_: category = l1l1111ll_l1_[0]
		for i in range(len(l1l1111ll_l1_[0:-1])):
			if l1l1111ll_l1_[i]+l11ll1_l1_ (u"࠭࠽࠾ࠩჂ") in l1l111l1_l1_: category = l1l1111ll_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪჃ")+category+l11ll1_l1_ (u"ࠨ࠿ࡀ࠴ࠬჄ")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬჅ")+category+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ჆")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠫࠫࠬࠧჇ"))+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ჈")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠧࠩ჉"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ჊"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ჋")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ჌"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬჍ"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠫࠬ჎"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ჏"))
		if l1l1111l_l1_==l11ll1_l1_ (u"࠭ࠧა"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭ბ")+l1l1111l_l1_
		l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨგ"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬდ"),l1lllll1l_l1_,251,l11ll1_l1_ (u"ࠪࠫე"),l11ll1_l1_ (u"ࠫࠬვ"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ზ"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭თ"),l111l1_l1_+l11ll1_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧი")+l11ll11l_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧკ"),l1lllll1l_l1_,251,l11ll1_l1_ (u"ࠩࠪლ"),l11ll1_l1_ (u"ࠪࠫმ"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬნ"))
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪო"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭პ"),l11ll1_l1_ (u"ࠧࠨჟ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭რ"),url,l11ll1_l1_ (u"ࠩࠪს"),headers,l11ll1_l1_ (u"ࠪࠫტ"),l11ll1_l1_ (u"ࠫࠬუ"),l11ll1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪფ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡔࡢࡺࡓࡥ࡬࡫ࡆࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡙ࠦ࡫ࡲ࡮ࡄࡗࡒࡸࠨࠧქ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l11llll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡕࡣࡻࡔࡦ࡭ࡥࡇ࡫࡯ࡸࡪࡸࡉࡵࡧࡰࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩღ"),block,re.DOTALL)
	l11llll11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡔࡤࡸ࡮ࡴࡧࡇ࡫࡯ࡸࡪࡸࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁ࠲࠯ࡅࠨ࠽ࡷ࡯ࡂ࠮࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩყ"),block,re.DOTALL)
	l1ll1ll1_l1_ = l11llll1l_l1_+l11llll11_l1_
	dict = {}
	for name,l1ll1l11_l1_,block in l1ll1ll1_l1_:
		#if l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫშ") in l1ll1l11_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫჩ"),block,re.DOTALL)
		if name==l11ll1_l1_ (u"ࠫฬิั๊ࠩც"): name = l11ll1_l1_ (u"ࠬอไศไึห๊࠭ძ")
		if not items:
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡷࡧࡴࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭წ"),block,re.DOTALL)
			items = []
			for option,value in l1l1l1l_l1_: items.append([option,l11ll1_l1_ (u"ࠧࠨჭ"),value])
			l1ll1l11_l1_ = l11ll1_l1_ (u"ࠨࡴࡤࡸࡪ࠭ხ")
			name = l11ll1_l1_ (u"ࠩส่ฯ่๊๋็ࠪჯ")
		else: l1ll1l11_l1_ = items[0][1]
		if l11ll1_l1_ (u"ࠪࡁࡂ࠭ჰ") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨჱ"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<=1:
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬჲ")+l1l11ll1_l1_)
				return
			else:
				l1lllll1l_l1_ = l11ll1l11_l1_(l111lll_l1_)
				if l1ll1l11_l1_==l1l1111ll_l1_[-1]: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ჳ"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨჴ"),l1lllll1l_l1_,251,l11ll1_l1_ (u"ࠨࠩჵ"),l11ll1_l1_ (u"ࠩࠪჶ"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫჷ"))
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫჸ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ჹ"),l111lll_l1_,254,l11ll1_l1_ (u"࠭ࠧჺ"),l11ll1_l1_ (u"ࠧࠨ჻"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩჼ"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬჽ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧჾ")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧჿ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩᄀ")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪᄁ")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᄂ"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪᄃ")+name,l111lll_l1_,255,l11ll1_l1_ (u"ࠩࠪᄄ"),l11ll1_l1_ (u"ࠪࠫᄅ"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᄆ"))
		dict[l1ll1l11_l1_] = {}
		for option,dummy,value in items:
			if option in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠬอไไๆࠪᄇ") in option: continue
			option = unescapeHTML(option)
			#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫᄈ") in option: continue
			#if l11ll1_l1_ (u"ࠧ࡯࠯ࡤࠫᄉ") in value: continue
			l11l1l11l_l1_,l1lll1l11_l1_ = option,option
			l1lll1l11_l1_ = name+l11ll1_l1_ (u"ࠨ࠼ࠣࠫᄊ")+l11l1l11l_l1_
			dict[l1ll1l11_l1_][value] = l1lll1l11_l1_
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬᄋ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠭ᄌ")+l11l1l11l_l1_
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧᄍ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠽ࠨᄎ")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪᄏ")+l1l1ll11_l1_
			if type==l11ll1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨᄐ"):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᄑ"),l111l1_l1_+l1lll1l11_l1_,url,255,l11ll1_l1_ (u"ࠩࠪᄒ"),l11ll1_l1_ (u"ࠪࠫᄓ"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᄔ"))
			elif type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩᄕ") and l1l1111ll_l1_[-2]+l11ll1_l1_ (u"࠭࠽࠾ࠩᄖ") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᄗ"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᄘ"),l11ll1_l1_ (u"ࠩࠪᄙ"),l11llll1_l1_,l1l1ll11_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩᄚ")+l11llll1_l1_
				l1lllll1l_l1_ = l11ll1l11_l1_(l11l111_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄛ"),l111l1_l1_+l1lll1l11_l1_,l1lllll1l_l1_,251,l11ll1_l1_ (u"ࠬ࠭ᄜ"),l11ll1_l1_ (u"࠭ࠧᄝ"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨᄞ"))
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᄟ"),l111l1_l1_+l1lll1l11_l1_,url,254,l11ll1_l1_ (u"ࠩࠪᄠ"),l11ll1_l1_ (u"ࠪࠫᄡ"),l1ll11ll_l1_)
	return
l1l1111ll_l1_ = [l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᄢ"),l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ᄣ"),l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄤ")]
l11llllll_l1_ = [l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᄥ"),l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᄦ"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᄧ"),l11ll1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᄨ"),l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ᄩ"),l11ll1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ᄪ"),l11ll1_l1_ (u"࠭ࡲࡢࡶࡨࠫᄫ")]
def l11ll1l11_l1_(url):
	l11l1111l_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠲࠱࠴࠴࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡍࡵ࡭ࡦ࠰ࡳ࡬ࡵ࠭ᄬ")
	url = url.replace(l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࠬᄭ"),l11l1111l_l1_)
	url = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪᄮ"),l11ll1_l1_ (u"ࠪࠫᄯ"))
	if l11l1111l_l1_ not in url: url = url+l11l1111l_l1_
	url = url.replace(l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᄰ"),l11ll1_l1_ (u"ࠬࡿࡥࡢࡴࠪᄱ"))
	url = url.replace(l11ll1_l1_ (u"࠭࠿ࡀࠩᄲ"),l11ll1_l1_ (u"ࠧࡀࠩᄳ"))
	url = url.replace(l11ll1_l1_ (u"ࠨࠨࠩࠫᄴ"),l11ll1_l1_ (u"ࠩࠩࠫᄵ"))
	url = url.replace(l11ll1_l1_ (u"ࠪࡁࡂ࠭ᄶ"),l11ll1_l1_ (u"ࠫࡂ࠭ᄷ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ᄸ"),l11ll1_l1_ (u"࠭ࠧᄹ"),l11ll1_l1_ (u"ࠧࠨᄺ"),l11ll1_l1_ (u"ࠨࡒࡕࡉࡕࡇࡒࡆࡡࡉࡍࡑ࡚ࡅࡓࡡࡉࡍࡓࡇࡌࡠࡗࡕࡐࠬᄻ"))
	return url
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᄼ"),l11ll1_l1_ (u"ࠪࠫᄽ"),filters,l11ll1_l1_ (u"ࠫࡎࡔࠠࠡࠢࠣࠫᄾ")+mode)
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᄿ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᅀ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫᅁ")					all filters (l11lll11_l1_ l1l1l1l1_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫᅂ"))
	l1l111ll_l1_,l1ll11l1_l1_ = {},l11ll1_l1_ (u"ࠩࠪᅃ")
	if l11ll1_l1_ (u"ࠪࡁࡂ࠭ᅄ") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠫࠫࠬࠧᅅ"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠬࡃ࠽ࠨᅆ"))
			l1l111ll_l1_[var] = value
	for key in l11llllll_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"࠭࠰ࠨᅇ")
		if l11ll1_l1_ (u"ࠧࠦࠩᅈ") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᅉ") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫᅊ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠪࠤ࠰ࠦࠧᅋ")+value
		elif mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᅌ") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧᅍ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩᅎ")+key+l11ll1_l1_ (u"ࠧ࠾࠿ࠪᅏ")+value
		elif mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬᅐ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬᅑ")+key+l11ll1_l1_ (u"ࠪࡁࡂ࠭ᅒ")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨᅓ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨᅔ"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᅕ"),l11ll1_l1_ (u"ࠧࠨᅖ"),l1ll11l1_l1_,l11ll1_l1_ (u"ࠨࡑࡘࡘࠬᅗ"))
	return l1ll11l1_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭憲")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭憳")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ憴"),l11ll1_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ憵"),l11ll1_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭憶")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l11111_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l1llll1_l1_(url,text)
	elif mode==644: results = l1l111_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ憷"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭憸"),l11ll1_l1_ (u"࠭ࠧ憹"),l11ll1_l1_ (u"ࠧࠨ憺"),l11ll1_l1_ (u"ࠨࠩ憻"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ憼"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ憽"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ憾"),l11ll1_l1_ (u"ࠬ࠭憿"),649,l11ll1_l1_ (u"࠭ࠧ懀"),l11ll1_l1_ (u"ࠧࠨ懁"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ懂"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ懃"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ懄"),l11ll1_l1_ (u"ࠫࠬ懅"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懆"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ懇")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่้๏ุษࠨ懈"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠨࠩ應"),l11ll1_l1_ (u"ࠩࠪ懊"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ懋"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ懌"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ懍")+l111l1_l1_+l11ll1_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫ懎"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠧࠨ懏"),l11ll1_l1_ (u"ࠨࠩ懐"),l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ懑"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ懒"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭懓")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ懔"),l11l1l_l1_,641,l11ll1_l1_ (u"࠭ࠧ懕"),l11ll1_l1_ (u"ࠧࠨ懖"),l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ懗"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ懘"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ懙")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ懚"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠬ࠭懛"),l11ll1_l1_ (u"࠭ࠧ懜"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ懝"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭懞"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ懟"),l11ll1_l1_ (u"ࠪࠫ懠"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ懡"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭懢"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭懣"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ懤")+l111l1_l1_+title,l1lllll_l1_,644)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭懥"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ懦"),l11ll1_l1_ (u"ࠪࠫ懧"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ懨"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ懩"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"࠭ࠧ懪"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ懫"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ懬"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ懭")+l111l1_l1_+title,l1lllll_l1_,644)
	return
def l1l111_l1_(url):
	l1111l1l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ懮"),url,l11ll1_l1_ (u"ࠫࠬ懯"),l11ll1_l1_ (u"ࠬ࠭懰"),l11ll1_l1_ (u"࠭ࠧ懱"),l11ll1_l1_ (u"ࠧࠨ懲"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭懳"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭懴"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ懵"),l11ll1_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ懶"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ懷"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"࠭ࠧ懸"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ懹"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭懺"),l11ll1_l1_ (u"ࠩࠪ懻"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			l1111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ懼"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ懽")
			for l1lllll_l1_,title in l1111l1l1_l1_:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懾"),l111l1_l1_+title,l1lllll_l1_,641)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ懿"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ戀"),block,re.DOTALL)
		if len(l1l1l1l_l1_)<30:
			if l1111l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭戁"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ戂"),l11ll1_l1_ (u"ࠪࠫ戃"),9999)
			for l1lllll_l1_,title in l1l1l1l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ戄"),l111l1_l1_+title,l1lllll_l1_,641)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠬ࠭戅")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ戆"),l11ll1_l1_ (u"ࠧࠨ戇"),request,url)
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭戈"):
		url,search = url.split(l11ll1_l1_ (u"ࠩࡂࠫ戉"),1)
		data = l11ll1_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ戊")+search
		headers = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ戋"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ戌")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ戍"),url,data,headers,l11ll1_l1_ (u"ࠧࠨ戎"),l11ll1_l1_ (u"ࠨࠩ戏"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭成"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ我"),url,l11ll1_l1_ (u"ࠫࠬ戒"),l11ll1_l1_ (u"ࠬ࠭戓"),l11ll1_l1_ (u"࠭ࠧ戔"),l11ll1_l1_ (u"ࠧࠨ戕"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ或"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠩࠪ戗"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ战"))
	if request==l11ll1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ戙"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ戚"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"࠭ࠧ戛"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ戜"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ戝"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ戞"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ戟"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ戠"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ戡"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ戢"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ戣"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ戤"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠩࠪ戥"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ戦"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭戧"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ戨"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ戩"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭截"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭戫"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ戬"),l11ll1_l1_ (u"๋ࠪิอแࠨ戭"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ戮"),l11ll1_l1_ (u"ࠬ฿ัืࠩ戯"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭戰"),l11ll1_l1_ (u"ࠧศๆห์๊࠭戱"),l11ll1_l1_ (u"ࠨ็ึีา๐ษࠨ戲")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠩ࠲ࠫ戳"))
		#if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ戴") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭戵")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ戶"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ户") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ戸")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ戹"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ戺"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭戻"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ戼"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ戽"):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ戾"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭房") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ所"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ扁") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ扂"),l111l1_l1_+title,l1lllll_l1_,641,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ扃"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ扄"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ扅")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ扆"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭扇"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠩࠦࠫ扈"): continue
				if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ扉") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭扊")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ手"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭扌"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭才")+title,l1lllll_l1_,641)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ扎"),l11ll1_l1_ (u"ࠩࠪ扏"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ扐"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ扑"),url,l11ll1_l1_ (u"ࠬ࠭扒"),l11ll1_l1_ (u"࠭ࠧ打"),l11ll1_l1_ (u"ࠧࠨ扔"),l11ll1_l1_ (u"ࠨࠩ払"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ扖"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭扗"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭托"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠬ࠭扙")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ扚"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠧࠤࠩ扛"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ扜"),l111l1_l1_+title,url,643,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ扝"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ扞")+l1l1l_l1_+l11ll1_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ扟"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ扠"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		#if not items: items = re.findall(l11ll1_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ扡"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ扢") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ扣")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ扤"))
			title = title.replace(l11ll1_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ扥"),l11ll1_l1_ (u"ࠫࠥ࠭扦"))
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ执"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ扨"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ扩") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ扪")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ扫"))
		#		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ扬"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l111_l1_,l1lll1ll_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ扭"),l11ll1_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠲ࡵ࡮ࡰࠨ扮"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ扯"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ扰"),l11ll1_l1_ (u"ࠨࠩ扱"),l11ll1_l1_ (u"ࠩࠪ扲"),l11ll1_l1_ (u"ࠪࠫ扳"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭扴"))
	html = response.content
	# l1l111l11_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ扵"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ扶"),block,re.DOTALL)
		if l1l1_l1_:
			l1lllll_l1_ = l1l1_l1_[0]
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ扷"))
				l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ扸"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l111111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ批"),block,re.DOTALL)
		block = block.replace(l11ll1_l1_ (u"ࠪࡠࡡࠨࠧ扺"),l11ll1_l1_ (u"ࠫࠧ࠭扻")).replace(l11ll1_l1_ (u"ࠬࡢ࠯ࠨ扼"),l11ll1_l1_ (u"࠭࠯ࠨ扽"))
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣ࠾࡬ࡪࡷࡧ࡭ࡦ࠰ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ找"),block,re.DOTALL)
		if len(l111111ll_l1_)==len(l1l1_l1_):
			for id,title in l111111ll_l1_:
				l1lllll_l1_ = l1l1_l1_[int(id)]
				if l1lllll_l1_ not in l1llll_l1_:
					l1l11l111_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ承")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ技"))
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ抁"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ抂"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭抃")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ抄"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l111_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1lll1ll_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ抅"),l1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ抆"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ抇"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ抈"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭抉"),l11ll1_l1_ (u"ࠬ࠱ࠧ把"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ抋")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ抌"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ抍")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ抎"))
	return
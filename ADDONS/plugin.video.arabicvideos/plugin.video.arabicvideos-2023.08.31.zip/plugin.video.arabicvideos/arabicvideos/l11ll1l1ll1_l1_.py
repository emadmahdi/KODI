# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㽪")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨ㽫")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪห้ืฦ๋ีํอࠬ㽬"),l11ll1_l1_ (u"ࠫฬูสโีสีฯ้ๅ๊ࠡࠣห้฽ไษษอࠫ㽭")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l11111_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1ll11_l1_(url)
	elif mode==454: results = l1llll11_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㽮"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ㽯"),l11ll1_l1_ (u"ࠧࠨ㽰"),l11ll1_l1_ (u"ࠨࠩ㽱"),l11ll1_l1_ (u"ࠩࠪ㽲"),l11ll1_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㽳"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ㽴"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㽵"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㽶"),l11ll1_l1_ (u"ࠧࠨ㽷"),459,l11ll1_l1_ (u"ࠨࠩ㽸"),l11ll1_l1_ (u"ࠩࠪ㽹"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㽺"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㽻"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㽼")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅฬสอหฯࠦไ้ัํࠤ๋ะࠧ㽽"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠧࠨ㽾"),l11ll1_l1_ (u"ࠨࠩ㽿"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㾀"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾁"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㾂")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ㾃"),l1ll111_l1_,451,l11ll1_l1_ (u"࠭ࠧ㾄"),l11ll1_l1_ (u"ࠧࠨ㾅"),l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㾆"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㾇"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㾈")+l111l1_l1_+l11ll1_l1_ (u"๊๋ࠫหๅ์้ࠫ㾉"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠬ࠭㾊"),l11ll1_l1_ (u"࠭ࠧ㾋"),l11ll1_l1_ (u"ࠧࡢࡥࡷࡳࡷࡹࠧ㾌"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾍"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㾎")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ์์ฯ๋หࠪ㾏"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠫࠬ㾐"),l11ll1_l1_ (u"ࠬ࠭㾑"),l11ll1_l1_ (u"࠭࠰ࠨ㾒"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㾓"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㾔")+l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไศฬ๋๋ࠣี๊ส่ࠢำอ๊ฬสࠩ㾕"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠪࠫ㾖"),l11ll1_l1_ (u"ࠫࠬ㾗"),l11ll1_l1_ (u"ࠬ࠷ࠧ㾘"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾙"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㾚")+l111l1_l1_+l11ll1_l1_ (u"ࠨษไ่ฬ๋่่ࠠา๎ฮ࠭㾛"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠩࠪ㾜"),l11ll1_l1_ (u"ࠪࠫ㾝"),l11ll1_l1_ (u"ࠫ࠷࠭㾞"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㾟"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㾠"),l11ll1_l1_ (u"ࠧࠨ㾡"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡐࡥ࡮ࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࠥࡗ࡮ࡺࡥࡔ࡮࡬ࡨࡪࡸࠢࠨ㾢"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㾣"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠪࠧࠬ㾤"): continue
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㾥"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㾦")+l111l1_l1_+title,l1lllll_l1_,451)
	return
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"࠭ࠧ㾧")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㾨"),l11ll1_l1_ (u"ࠨࠩ㾩"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㾪"),url,l11ll1_l1_ (u"ࠪࠫ㾫"),l11ll1_l1_ (u"ࠫࠬ㾬"),l11ll1_l1_ (u"ࠬ࠭㾭"),l11ll1_l1_ (u"࠭ࠧ㾮"),l11ll1_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ㾯"))
	html = response.content
	if l1lll1l11l_l1_==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㾰"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡗ࡮ࡺࡥࡔ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡷࡢࡸࡨࡷࠧ࠭㾱"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l1lll1l11l_l1_==l11ll1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㾲"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡘࡥࡤࡧࡱࡸࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ㾳"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠫ㾴") in html:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭㾵"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࠦࡆࡩࡴࡰࡴࡑࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㾶"),block,re.DOTALL)
	elif l1lll1l11l_l1_ in [l11ll1_l1_ (u"ࠨ࠲ࠪ㾷"),l11ll1_l1_ (u"ࠩ࠴ࠫ㾸"),l11ll1_l1_ (u"ࠪ࠶ࠬ㾹")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠫࠧࡥࡤࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾ࠨ㾺"),html,re.DOTALL)
		block = l1l1l11_l1_[int(l1lll1l11l_l1_)]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡇࡲࡦࡣࠥࠬ࠳࠰࠿ࠪࠤࡷࡩࡽࡺ࠯࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠦࠬ㾻"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠾ࠨ㾼"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧ㾽"),l11ll1_l1_ (u"ࠨใํ่๊࠭㾾"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨ㾿"),l11ll1_l1_ (u"ࠪว฿์๊สࠩ㿀"),l11ll1_l1_ (u"่๊๊ࠫษࠩ㿁"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ㿂"),l11ll1_l1_ (u"࠭็ะษไࠫ㿃"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ㿄"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ㿅"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ㿆"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ㿇")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠪ㿈") in html and l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠪ㿉") in l1lll1_l1_:
			l1lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㿊"),l1lll1_l1_,re.DOTALL)
			l1lll1_l1_ = l1lll1_l1_[0]
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ㿋"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩ㿌"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ㿍"),title,re.DOTALL)
		#if any(value in title for value in l1ll1l_l1_):
		if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ุ้๊ࠪำๅࠩ㿎") not in title:
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㿏"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠬำไใหࠪ㿐") in title:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ㿑") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿒"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿓"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
	if l1lll1l11l_l1_ in [l11ll1_l1_ (u"ࠩࠪ㿔"),l11ll1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㿕")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㿖"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㿗"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠢ㿘"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠧࠨ㿙"):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿚"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ㿛")+title,l1lllll_l1_,451)
	return
def l1lll1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㿜"),url,l11ll1_l1_ (u"ࠫࠬ㿝"),l11ll1_l1_ (u"ࠬ࠭㿞"),l11ll1_l1_ (u"࠭ࠧ㿟"),l11ll1_l1_ (u"ࠧࠨ㿠"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㿡"))
	html = response.content
	# l1lll1l_l1_
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡇࡦࡺࡥࡨࡱࡵࡽࡘࡻࡢࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㿢"),html,re.DOTALL)
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩ㿣") in str(l1l11l1_l1_):
		title = re.findall(l11ll1_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠰ࠫ㿤"),html,re.DOTALL)
		title = title[0].strip(l11ll1_l1_ (u"ࠬࠦࠧ㿥"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿦"),l111l1_l1_+title,url,454)
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿧"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿨"),l111l1_l1_+title,l1lllll_l1_,454)
	else: l1llll11_l1_(url)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㿩"),url,l11ll1_l1_ (u"ࠪࠫ㿪"),l11ll1_l1_ (u"ࠫࠬ㿫"),l11ll1_l1_ (u"ࠬ࠭㿬"),l11ll1_l1_ (u"࠭ࠧ㿭"),l11ll1_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㿮"))
	html = response.content
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㿯"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㿰"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㿱"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㿲"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㿳"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠢ㿴"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠧࠨ㿵"):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿶"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ㿷")+title,l1lllll_l1_,454)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ㿸"),l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡲࡵࡶࡪࡧࡶ࠳ࠬ㿹"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ㿺"),l11ll1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ㿻"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㿼"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ㿽"),l11ll1_l1_ (u"ࠩࠪ㿾"),l11ll1_l1_ (u"ࠪࠫ㿿"),l11ll1_l1_ (u"ࠫࠬ䀀"),l11ll1_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䀁"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ䀂"))
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡔࡪࡶ࡯ࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡧࡳࡪࡦࡨࡂࠬ䀃"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ䀄"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䀅")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䀆")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡌࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࠦࡸ࡫࡬ࡢࡴࡼࠦࠬ䀇"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ䀈"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			name = unescapeHTML(name)
			l111lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ䀉"),name,re.DOTALL)
			if l111lll1_l1_:
				l111lll1_l1_ = l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬ䀊")+l111lll1_l1_[0]
				name = l11ll1_l1_ (u"ࠨࠩ䀋")
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠩࠪ䀌")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䀍")+name+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䀎")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䀏"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䀐"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ䀑"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ䀒"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ䀓"),l11ll1_l1_ (u"ࠪ࠯ࠬ䀔"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭䀕")+search
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭串")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡍࡕࡗࡣࠬ丳")
l11ll111llll_l1_ = 5
l11ll11111ll_l1_ = 10
def MAIN(mode,url,text,l1l1111_l1_,l1ll1ll1l11_l1_):
	try: l1lll11l1l1l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ临")])
	except: l1lll11l1l1l_l1_ = l11ll1_l1_ (u"ࠨࠩ丵")
	if   mode==160: results = MENU()
	elif mode==161: results = l11ll11lll11_l1_(text)
	elif mode==162: results = l11l1lll1lll_l1_(text,162)
	elif mode==163: results = l11l1lll1lll_l1_(text,163)
	elif mode==164: results = l11ll11ll1l1_l1_(text)
	elif mode==165: results = l11ll111lll1_l1_(l1lll11l1l1l_l1_,text,l1l1111_l1_)
	elif mode==166: results = l11ll11l11ll_l1_(url,text)
	elif mode==167: results = l11l1ll1ll1l_l1_(url,text)
	elif mode==168: results = l11l1ll111l1_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ丶"),l11ll1_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ࠣ฽ู๎วว์ฬࠫ丷"),l11ll1_l1_ (u"ࠫࠬ丸"),161,l11ll1_l1_ (u"ࠬ࠭丹"),l11ll1_l1_ (u"࠭ࠧ为"),l11ll1_l1_ (u"ࠧࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭主"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丼"),l11ll1_l1_ (u"ࠩๅืู๊ࠦี๊สส๏࠭丽"),l11ll1_l1_ (u"ࠪࠫ举"),162,l11ll1_l1_ (u"ࠫࠬ丿"),l11ll1_l1_ (u"ࠬ࠭乀"),l11ll1_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ乁"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乂"),l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ乃"),l11ll1_l1_ (u"ࠩࠪ乄"),163,l11ll1_l1_ (u"ࠪࠫ久"),l11ll1_l1_ (u"ࠫࠬ乆"),l11ll1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ乇"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭么"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭义"),l11ll1_l1_ (u"ࠨࠩ乊"),164,l11ll1_l1_ (u"ࠩࠪ之"),l11ll1_l1_ (u"ࠪࠫ乌"),l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ乍"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乎"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ乏"),l11ll1_l1_ (u"ࠧࠨ乐"),165,l11ll1_l1_ (u"ࠨࠩ乑"),l11ll1_l1_ (u"ࠩࠪ乒"),l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ乓"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ乔"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ乕"),l11ll1_l1_ (u"࠭ࠧ乖"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乗"),l11ll1_l1_ (u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ乘"),l11ll1_l1_ (u"ࠩࠪ乙"),163,l11ll1_l1_ (u"ࠪࠫ乚"),l11ll1_l1_ (u"ࠫࠬ乛"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ乜"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭九"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ乞"),l11ll1_l1_ (u"ࠨࠩ也"),163,l11ll1_l1_ (u"ࠩࠪ习"),l11ll1_l1_ (u"ࠪࠫ乡"),l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ乢"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乣"),l11ll1_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭乤"),l11ll1_l1_ (u"ࠧࠨ乥"),162,l11ll1_l1_ (u"ࠨࠩ书"),l11ll1_l1_ (u"ࠩࠪ乧"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ乨"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乩"),l11ll1_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬ乪"),l11ll1_l1_ (u"࠭ࠧ乫"),162,l11ll1_l1_ (u"ࠧࠨ乬"),l11ll1_l1_ (u"ࠨࠩ乭"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ乮"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乯"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣฬาัฺࠠึ๋หห๐ࠧ买"),l11ll1_l1_ (u"ࠬ࠭乱"),164,l11ll1_l1_ (u"࠭ࠧ乲"),l11ll1_l1_ (u"ࠧࠨ乳"),l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ乴"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乵"),l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ乶"),l11ll1_l1_ (u"ࠫࠬ乷"),165,l11ll1_l1_ (u"ࠬ࠭乸"),l11ll1_l1_ (u"࠭ࠧ乹"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ乺"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭乻"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ乼"),l11ll1_l1_ (u"ࠪࠫ乽"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乾"),l11ll1_l1_ (u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ乿"),l11ll1_l1_ (u"࠭ࠧ亀"),163,l11ll1_l1_ (u"ࠧࠨ亁"),l11ll1_l1_ (u"ࠨࠩ亂"),l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ亃"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ亄"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ亅"),l11ll1_l1_ (u"ࠬ࠭了"),163,l11ll1_l1_ (u"࠭ࠧ亇"),l11ll1_l1_ (u"ࠧࠨ予"),l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ争"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ亊"),l11ll1_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ事"),l11ll1_l1_ (u"ࠫࠬ二"),162,l11ll1_l1_ (u"ࠬ࠭亍"),l11ll1_l1_ (u"࠭ࠧ于"),l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ亏"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ亐"),l11ll1_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ云"),l11ll1_l1_ (u"ࠪࠫ互"),162,l11ll1_l1_ (u"ࠫࠬ亓"),l11ll1_l1_ (u"ࠬ࠭五"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ井"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亖"),l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡสะฯࠥ฿ิ้ษษ๎ࠬ亗"),l11ll1_l1_ (u"ࠩࠪ亘"),164,l11ll1_l1_ (u"ࠪࠫ亙"),l11ll1_l1_ (u"ࠫࠬ亚"),l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ些"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭亜"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ亝"),l11ll1_l1_ (u"ࠨࠩ亞"),165,l11ll1_l1_ (u"ࠩࠪ亟"),l11ll1_l1_ (u"ࠪࠫ亠"),l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ亡"))
	return
def l11ll11lll11_l1_(options):
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ亢"),l11ll1_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ亣"),l11ll1_l1_ (u"ࠧࠨ交"),161,l11ll1_l1_ (u"ࠨࠩ亥"),l11ll1_l1_ (u"ࠩࠪ亦"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ产"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ亨"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ亩"),l11ll1_l1_ (u"࠭ࠧ亪"),9999)
	l1l1ll1l1l1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ享"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ࡞࡛ࡔࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ京")+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ亭"),l11ll1_l1_ (u"ࠪࠫ亮"),147)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亯"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ亰")+l11ll1_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ亱"),l11ll1_l1_ (u"ࠧࠨ亲"),148)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ亳"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡏࡆࡍࠢࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ亴")+l11ll1_l1_ (u"ࠪๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠬ亵"),l11ll1_l1_ (u"ࠫࠬ亶"),28)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ亷"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡐࡖࡋࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ亸")+l11ll1_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ亹"),l11ll1_l1_ (u"ࠨࠩ人"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ亻"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡋࡘࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭亼")+l11ll1_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ亽"),l11ll1_l1_ (u"ࠬ࠭亾"),135)
	import l1ll1ll11111_l1_
	l1ll1ll11111_l1_.ITEMS(l11ll1_l1_ (u"࠭࠰ࠨ亿"),False)
	l1ll1ll11111_l1_.ITEMS(l11ll1_l1_ (u"ࠧ࠲ࠩ什"),False)
	l1ll1ll11111_l1_.ITEMS(l11ll1_l1_ (u"ࠨ࠴ࠪ仁"),False)
	#l1ll1ll11111_l1_.ITEMS(l11ll1_l1_ (u"ࠩ࠶ࠫ仂"),False)
	if l11ll1_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ仃") in options:
		menuItemsLIST[:] = l11l1llll1l1_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11ll111llll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11ll111llll_l1_)
	menuItemsLIST[:] = l1l1ll1l1l1l_l1_+menuItemsLIST
	return
def l11ll11ll1l1_l1_(options):
	options = options.replace(l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭仄"),l11ll1_l1_ (u"ࠬ࠭仅")).replace(l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ仆"),l11ll1_l1_ (u"ࠧࠨ仇"))
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ仈") : l11ll1_l1_ (u"ࠩࠪ仉") }
	url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩ今")
	payload = { l11ll1_l1_ (u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭介") : l11ll1_l1_ (u"ࠬ࠻࠰ࠨ仌") }
	data = l1ll1l111_l1_(payload)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ仍"),l11ll1_l1_ (u"ࠧࠨ从"),l11ll1_l1_ (u"ࠨࠩ仏"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭仐"),url,data,headers,l11ll1_l1_ (u"ࠪࠫ仑"),l11ll1_l1_ (u"ࠫࠬ仒"),l11ll1_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧ仓"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨ仔"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ仕"),block,re.DOTALL)
	l11l1l1lllll_l1_,l11l1ll1l1ll_l1_ = list(zip(*items))
	l11ll11l1l1l_l1_ = []
	l11ll11ll11l_l1_ = [l11ll1_l1_ (u"ࠨࠢࠪ他"),l11ll1_l1_ (u"ࠩࠥࠫ仗"),l11ll1_l1_ (u"ࠪࡤࠬ付"),l11ll1_l1_ (u"ࠫ࠱࠭仙"),l11ll1_l1_ (u"ࠬ࠴ࠧ仚"),l11ll1_l1_ (u"࠭࠺ࠨ仛"),l11ll1_l1_ (u"ࠧ࠼ࠩ仜"),l11ll1_l1_ (u"ࠣࠩࠥ仝"),l11ll1_l1_ (u"ࠩ࠰ࠫ仞")]
	l11ll111ll11_l1_ = l11l1ll1l1ll_l1_+l11l1l1lllll_l1_
	for word in l11ll111ll11_l1_:
		if word in l11l1ll1l1ll_l1_: l11ll1111ll1_l1_ = 2
		if word in l11l1l1lllll_l1_: l11ll1111ll1_l1_ = 4
		l11ll11l1ll1_l1_ = [i in word for i in l11ll11ll11l_l1_]
		if any(l11ll11l1ll1_l1_):
			index = l11ll11l1ll1_l1_.index(True)
			l11l1lll1111_l1_ = l11ll11ll11l_l1_[index]
			l11ll11l111l_l1_ = l11ll1_l1_ (u"ࠪࠫ仟")
			if word.count(l11l1lll1111_l1_)>1: l11ll11l11l1_l1_,l11ll11l1111_l1_,l11ll11l111l_l1_ = word.split(l11l1lll1111_l1_,2)
			else: l11ll11l11l1_l1_,l11ll11l1111_l1_ = word.split(l11l1lll1111_l1_,1)
			if len(l11ll11l11l1_l1_)>l11ll1111ll1_l1_: l11ll11l1l1l_l1_.append(l11ll11l11l1_l1_.lower())
			if len(l11ll11l1111_l1_)>l11ll1111ll1_l1_: l11ll11l1l1l_l1_.append(l11ll11l1111_l1_.lower())
			if len(l11ll11l111l_l1_)>l11ll1111ll1_l1_: l11ll11l1l1l_l1_.append(l11ll11l111l_l1_.lower())
		elif len(word)>l11ll1111ll1_l1_: l11ll11l1l1l_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11ll11l1l1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll11l1l1l_l1_)),l11ll11l1l1l_l1_)
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊ࡮࡬ࡷࡹࠦ࠽ࠡ࡝ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣ฽ึฮ๊สࠩ࠯่๊ࠫๅศฬࠣ฽ู๎วว์ฬࠤส์ใๅ์ี๎ฮ࠭࡝ࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠵࠭ࠏࠏ࡬ࡪࡵࡷ࠵ࠥࡃࠠ࡜࡟ࠍࠍࡨࡵࡵ࡯ࡶࡶࠤࡂࠦ࡬ࡦࡰࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡩ࡯ࡶࡰࡷࡷ࠯࠻ࠩ࠻ࠢࡵࡥࡳࡪ࡯࡮࠰ࡶ࡬ࡺ࡬ࡦ࡭ࡧࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࡩࡷ࡬࠮ࡀࠠ࡭࡫ࡶࡸ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧไๆ่อࠥ฿ิ้ษษ๎ฮࠦัใ็ࠣࠫ࠰ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠏࠏࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไๅ฼ฬ࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࠧࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡂࡃ࠰࠻ࠢ࡯࡭ࡸࡺ࠲ࠡ࠿ࠣࡥࡷࡨࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡦࡰࡪࡐࡎ࡙ࡔࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠴࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠡ࠾ࠢ࠰࠵࠿ࠦࡢࡳࡧࡤ࡯ࠏࠏࠉࡦ࡮࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡶࡩࡦࡸࡣࡩࠢࡀࠤࡱ࡯ࡳࡵ࠴࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠤࠥࠦ仠")
	if l11ll1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭仡") in options:
		l11l1llllll1_l1_ = l1ll111111ll_l1_
	elif l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭仢") in options:
		l11l1llllll1_l1_ = [l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ代")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠨࠩ令"),True): return
	elif l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ以") in options:
		l11l1llllll1_l1_ = [l11ll1_l1_ (u"ࠪࡑ࠸࡛ࠧ仦")]
		import l1l1l11l11ll_l1_
		if not l1l1l11l11ll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠫࠬ仧"),True): return
	count,l11l1ll11111_l1_ = 0,0
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ仨"),l11ll1_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡ࠼ࠣ࡟ࠥࠦ࡝ࠨ仩"),l11ll1_l1_ (u"ࠧࠨ仪"),164,l11ll1_l1_ (u"ࠨࠩ仫"),l11ll1_l1_ (u"ࠩࠪ们"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ仭")+options)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ仮"),l11ll1_l1_ (u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬ仯"),l11ll1_l1_ (u"࠭ࠧ仰"),164,l11ll1_l1_ (u"ࠧࠨ仱"),l11ll1_l1_ (u"ࠨࠩ仲"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ仳")+options)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ仴"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ仵"),l11ll1_l1_ (u"ࠬ࠭件"),9999)
	l11l1l1llll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11ll11ll111_l1_ = []
	for word in l11ll11l1l1l_l1_:
		l11ll11l1111_l1_ = re.findall(l11ll1_l1_ (u"࡛࠭ࠡ࡞࠯ࡠࡀࡢ࠺࡝࠯࡟࠯ࡡࡃ࡜ࠣ࡞ࠪࡠࡠࡢ࡝࡝ࠪ࡟࠭ࡡࢁ࡜ࡾ࡞ࠤࡠࡅࡢࠣ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫ价"),word,re.DOTALL)
		if l11ll11l1111_l1_: word = word.split(l11ll11l1111_l1_[0],1)[0]
		l11ll111l1ll_l1_ = word.replace(l11ll1_l1_ (u"ࠧ๒ࠩ仸"),l11ll1_l1_ (u"ࠨࠩ仹")).replace(l11ll1_l1_ (u"ࠩ๑ࠫ仺"),l11ll1_l1_ (u"ࠪࠫ任")).replace(l11ll1_l1_ (u"ࠫ๐࠭仼"),l11ll1_l1_ (u"ࠬ࠭份")).replace(l11ll1_l1_ (u"࠭๏ࠨ仾"),l11ll1_l1_ (u"ࠧࠨ仿")).replace(l11ll1_l1_ (u"ࠨ๎ࠪ伀"),l11ll1_l1_ (u"ࠩࠪ企"))
		l11ll111l1ll_l1_ = l11ll111l1ll_l1_.replace(l11ll1_l1_ (u"ࠪ๔ࠬ伂"),l11ll1_l1_ (u"ࠫࠬ伃")).replace(l11ll1_l1_ (u"ࠬ๓ࠧ伄"),l11ll1_l1_ (u"࠭ࠧ伅")).replace(l11ll1_l1_ (u"ࠧ๓ࠩ伆"),l11ll1_l1_ (u"ࠨࠩ伇")).replace(l11ll1_l1_ (u"ࠩฏࠫ伈"),l11ll1_l1_ (u"ࠪࠫ伉")).replace(l11ll1_l1_ (u"ࠫๅ࠭伊"),l11ll1_l1_ (u"ࠬ࠭伋"))
		if l11ll111l1ll_l1_: l11ll11ll111_l1_.append(l11ll111l1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll11ll111_l1_)),l11ll11ll111_l1_)
	l11ll111l11l_l1_ = []
	for l11ll11111_l1_ in range(0,20):
		search = random.sample(l11ll11ll111_l1_,1)[0]
		if search in l11ll111l11l_l1_: continue
		l11ll111l11l_l1_.append(search)
		l1ll111l111_l1_ = random.sample(l11l1llllll1_l1_,1)[0]
		LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭伌"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ伍")+str(l1ll111l111_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ伎")+search)
		#results = l1l1ll1ll1ll_l1_(l11ll1_l1_ (u"ࠩࠪ伏"),l11ll1_l1_ (u"ࠪࠫ伐"),l11ll1_l1_ (u"ࠫࠬ休"),l1ll111l111_l1_,l11ll1_l1_ (u"ࠬ࠭伒"),l11ll1_l1_ (u"࠭ࠧ伓"),search+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ伔"),l11ll1_l1_ (u"ࠨࠩ伕"),l11ll1_l1_ (u"ࠩࠪ伖"))
		l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
		l1ll1111lll_l1_(search+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ众"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ优"),l11ll1_l1_ (u"ࠬ࠭伙"))
	l11l1l1llll1_l1_[0][1] = l11ll1_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ会")+search+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่อำหࠡ฻้ࠤ࠿࡛ࠦࠡࠩ伛")
	menuItemsLIST[:] = l11l1llll1l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11ll111llll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11ll111llll_l1_)
	menuItemsLIST[:] = l11l1l1llll1_l1_+menuItemsLIST
	#import l1lll11ll1l_l1_
	#l1lll11ll1l_l1_.SEARCH(search)
	return
def l11ll11l1lll_l1_(l1ll111l111_l1_):
	l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
	try:
		if l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ伜") in l1ll111l111_l1_: l1l1lllllll_l1_(l1ll111l111_l1_)
		else: l1l1lllllll_l1_()
		l11ll111l111_l1_ = False
	except: l11ll111l111_l1_ = True
	l1ll111l111_l1_ = TRANSLATE(l1ll111l111_l1_)
	if l11ll111l111_l1_: l1llllll_l1_(l1ll111l111_l1_,l11ll1_l1_ (u"ࠩไุ้ࠦศ่าสࠤฬ๊ๅ้ไ฼ࠫ伝"),time=2000)
	else: l1llllll_l1_(l1ll111l111_l1_,l11ll1_l1_ (u"ࠪฮ๊ࠦฬๅสࠣห้ษโิษ่ࠫ伞"),time=2000)
	return l11ll111l111_l1_
def l11l1ll11l1l_l1_(l11ll1111l11_l1_=True):
	if not l11ll1111l11_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ伟"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ传"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ伡"))
		if results:
			contentsDICT = results
			return
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ伢"),l11ll1_l1_ (u"ࠨࠩ伣"),l11ll1_l1_ (u"ࠩࠪ伤"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭伥"),l11ll1_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ伦"))
	if l1ll111ll1_l1_!=1: return
	l11l1ll11lll_l1_ = menuItemsLIST[:]
	l11l1lllll1l_l1_,l11l1llll1ll_l1_ = 0,l11ll1_l1_ (u"ࠬ࠭伧")
	for l1ll111l111_l1_ in l11lll111l1_l1_:
		l11ll111l111_l1_ = l11ll11l1lll_l1_(l1ll111l111_l1_)
		if l11ll111l111_l1_:
			l11l1lllll1l_l1_ += 1
			l11l1llll1ll_l1_ += l11ll1_l1_ (u"࠭ࠠࠨ伨")+l1ll111l111_l1_
			if l11l1lllll1l_l1_>=l11ll11111ll_l1_: break
	menuItemsLIST[:] = l11l1ll11lll_l1_
	if l11l1lllll1l_l1_>=l11ll11111ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ伩"),l11ll1_l1_ (u"ࠨࠩ伪"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ伫"),l11ll1_l1_ (u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫ伬")+str(l11l1lllll1l_l1_)+l11ll1_l1_ (u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩ伭")+l11l1llll1ll_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ伮"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ伯"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ估"),l11ll1_l1_ (u"ࠨࠩ伱"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ伲"),l11ll1_l1_ (u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩ伳"))
	return
def l11l1lll1l1l_l1_(l1lll11l1l1l_l1_,options):
	if l11ll1_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ伴") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ伵"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ伶"),l11ll1_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ伷")+l1lll11l1l1l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭伸")
	import IPTV
	if l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ伹") in options and l11ll1_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ伺") not in options:
		try: IPTV.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ伻"),l11ll1_l1_ (u"ࠬ࠭似"),l11ll1_l1_ (u"࠭ࠧ伽"),options+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ伾"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ伿"),l11ll1_l1_ (u"ࠩࠪ佀"),l11ll1_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ佁"),message)
		try: IPTV.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ佂"),l11ll1_l1_ (u"ࠬ࠭佃"),l11ll1_l1_ (u"࠭ࠧ佄"),options+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ佅"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ但"),l11ll1_l1_ (u"ࠩࠪ佇"),l11ll1_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ佈"),message)
		try: IPTV.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ佉"),l11ll1_l1_ (u"ࠬ࠭佊"),l11ll1_l1_ (u"࠭ࠧ佋"),options+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ佌"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ位"),l11ll1_l1_ (u"ࠩࠪ低"),l11ll1_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ住"),message)
	if l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ佐") in options and l11ll1_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ佑") not in options:
		try: IPTV.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭佒"),l11ll1_l1_ (u"ࠧࠨ体"),l11ll1_l1_ (u"ࠨࠩ佔"),options+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ何"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ佖"),l11ll1_l1_ (u"ࠫࠬ佗"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ佘"),message)
		try: IPTV.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ余"),l11ll1_l1_ (u"ࠧࠨ佚"),l11ll1_l1_ (u"ࠨࠩ佛"),options+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ作"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ佝"),l11ll1_l1_ (u"ࠫࠬ佞"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ佟"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ你"),l11ll1_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ佡")+l1lll11l1l1l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11ll111111l_l1_(l1lll11l1l1l_l1_,options):
	if l11ll1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭佢") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ佣"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭佤"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ佥")+l1lll11l1l1l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ佦")
	import l1l1l11l11ll_l1_
	if l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ佧") in options and l11ll1_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ佨") not in options:
		try: l1l1l11l11ll_l1_.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ佩"),l11ll1_l1_ (u"ࠩࠪ佪"),l11ll1_l1_ (u"ࠪࠫ佫"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ佬"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭佭"),l11ll1_l1_ (u"࠭ࠧ佮"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ佯"),message)
		try: l1l1l11l11ll_l1_.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭佰"),l11ll1_l1_ (u"ࠩࠪ佱"),l11ll1_l1_ (u"ࠪࠫ佲"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ佳"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭佴"),l11ll1_l1_ (u"࠭ࠧ併"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ佶"),message)
		try: l1l1l11l11ll_l1_.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭佷"),l11ll1_l1_ (u"ࠩࠪ佸"),l11ll1_l1_ (u"ࠪࠫ佹"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ佺"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭佻"),l11ll1_l1_ (u"࠭ࠧ佼"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ佽"),message)
	if l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ佾") in options and l11ll1_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ使") not in options:
		try: l1l1l11l11ll_l1_.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ侀"),l11ll1_l1_ (u"ࠫࠬ侁"),l11ll1_l1_ (u"ࠬ࠭侂"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ侃"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ侄"),l11ll1_l1_ (u"ࠨࠩ侅"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭來"),message)
		try: l1l1l11l11ll_l1_.GROUPS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ侇"),l11ll1_l1_ (u"ࠫࠬ侈"),l11ll1_l1_ (u"ࠬ࠭侉"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ侊"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ例"),l11ll1_l1_ (u"ࠨࠩ侌"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭侍"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭侎"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ侏")+l1lll11l1l1l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11ll111lll1_l1_(l1lll11l1l1l_l1_,options,l11l1ll1llll_l1_):
	if l11ll1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭侐") in options:
		if l11ll1_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ侑") in options and l11l1ll1llll_l1_==l11ll1_l1_ (u"ࠧࠨ侒"): l11l1ll11l1l_l1_(True)
		elif l11l1ll1llll_l1_: l11l1ll11l1l_l1_(False)
		#if contentsDICT=={}: return
	l11ll1111l1l_l1_ = options.replace(l11ll1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭侓"),l11ll1_l1_ (u"ࠩࠪ侔")).replace(l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ侕"),l11ll1_l1_ (u"ࠫࠬ侖")).replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ侗"),l11ll1_l1_ (u"࠭ࠧ侘"))
	if not l11l1ll1llll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ侙"),l11ll1_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ侚"),l11ll1_l1_ (u"ࠩࠪ供"),165,l11ll1_l1_ (u"ࠪࠫ侜"),l11ll1_l1_ (u"ࠫࠬ依"),l11ll1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ侞")+l11ll1111l1l_l1_,l11ll1_l1_ (u"࠭ࠧ侟"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侠"):l1lll11l1l1l_l1_})
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭価"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ侢"),l11ll1_l1_ (u"ࠪࠫ侣"),9999)
	if l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ侤") in options:
		l1ll1l1111_l1_ = [l11ll1_l1_ (u"ࠬษแๅษ่ࠫ侥"),l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠧ侦"),l11ll1_l1_ (u"ࠧๆีิั๏อสࠨ侧"),l11ll1_l1_ (u"ࠨสิห๊าࠧ侨"),l11ll1_l1_ (u"ࠩฦ฻ๆอไ๊ࠡๆีฯ๎ๆࠨ侩"),l11ll1_l1_ (u"ࠪี๊฼ว็ࠩ侪"),l11ll1_l1_ (u"ࠫศำฯฬ࠯ฦาึ࠭侫"),l11ll1_l1_ (u"ูࠬไศี็ࠫ侬"),l11ll1_l1_ (u"࠭ๅ้ีํๆ๎࠭侭"),l11ll1_l1_ (u"ࠧฤึ๊ี࠲ษใฬำࠪ侮"),l11ll1_l1_ (u"ࠨษ็ฦ๋࠭侯"),l11ll1_l1_ (u"ูࠩั่࠭侰"),l11ll1_l1_ (u"ࠪี๏อึสࠩ侱"),l11ll1_l1_ (u"๋ࠫ๐สโๆๆืࠬ侲"),l11ll1_l1_ (u"๋ࠬๅฬๆํ๊ࠬ侳"),l11ll1_l1_ (u"࠭ศฬࠢะ๎ࠬ侴"),l11ll1_l1_ (u"ࠧะ์้๎ฮ࠭侵"),l11ll1_l1_ (u"ࠨี้์ฬะࠧ侶"),l11ll1_l1_ (u"ࠩฦาึ๏ࠧ侷")]
		l11l1ll1l111_l1_ = [l11ll1_l1_ (u"ࠪหๆ๊วๆࠩ侸"),l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ侹"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ侺"),l11ll1_l1_ (u"࠭แๅ็ࠪ侻")]
		l11l1lll11l1_l1_ = [l11ll1_l1_ (u"ࠧๆี็ื้࠭侼"),l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ侽")]
		l11ll11ll1ll_l1_ = [l11ll1_l1_ (u"่ࠩืฬือࠨ侾"),l11ll1_l1_ (u"ุ้ࠪือ๋ษอࠫ便")]
		l11l1lll111l_l1_ = [l11ll1_l1_ (u"ࠫอืวๆฮࠪ俀"),l11ll1_l1_ (u"ࠬࡹࡨࡰࡹࠪ俁"),l11ll1_l1_ (u"࠭สๅใี๎ํ์ࠧ係"),l11ll1_l1_ (u"ࠧหๆํๅื๐่็ࠩ促")]
		l11ll111l1l1_l1_ = [l11ll1_l1_ (u"ࠨษ้้๏࠭俄"),l11ll1_l1_ (u"ࠩๆีฯ๎ๆࠨ俅"),l11ll1_l1_ (u"ࠪ็ฬืส้่ࠪ俆"),l11ll1_l1_ (u"ࠫࡰ࡯ࡤࡴࠩ俇"),l11ll1_l1_ (u"ࠬ฽แๅࠩ俈"),l11ll1_l1_ (u"࠭วุใส่ࠬ俉")]
		l1111l1l_l1_ = [l11ll1_l1_ (u"ࠧา็ูห๋࠭俊")]
		l1llll1l1_l1_ = [l11ll1_l1_ (u"ࠨษะำะ࠭俋"),l11ll1_l1_ (u"ࠩสาึ࠭俌"),l11ll1_l1_ (u"้ࠪํิัࠨ俍"),l11ll1_l1_ (u"ࠫัี๊ะࠩ俎"),l11ll1_l1_ (u"๋ࠬึศใࠪ俏"),l11ll1_l1_ (u"࠭อะ์ฮࠫ俐")]
		l11l1lll1ll1_l1_ = [l11ll1_l1_ (u"ࠧิๆสื้࠭俑"),l11ll1_l1_ (u"ࠨี็ื้ํࠧ俒")]
		l11l1ll1111l_l1_ = [l11ll1_l1_ (u"ࠩส฾ฬ์๊ࠨ俓"),l11ll1_l1_ (u"้ࠪํู๊ใ๋ࠪ俔"),l11ll1_l1_ (u"่๊๊ࠫษࠩ俕"),l11ll1_l1_ (u"ࠬำแๅࠩ俖"),l11ll1_l1_ (u"࠭࡭ࡶࡵ࡬ࡧࠬ俗")]
		l1111111l_l1_ = [l11ll1_l1_ (u"ࠧศๅฮีࠬ俘"),l11ll1_l1_ (u"ࠨษื๋ึ࠭俙"),l11ll1_l1_ (u"่้ࠩ๏ุ็ࠨ俚"),l11ll1_l1_ (u"ࠪห฾๊้ࠨ俛"),l11ll1_l1_ (u"๊ࠫิสศำ๊ࠫ俜"),l11ll1_l1_ (u"๋ࠬฮหษิหฯ࠭保"),l11ll1_l1_ (u"࠭วใ๊์ࠫ俞")]
		l11l1ll11ll1_l1_ = [l11ll1_l1_ (u"ࠧศๆส๊ࠬ俟"),l11ll1_l1_ (u"ࠨฯส่๏࠭俠"),l11ll1_l1_ (u"่ࠩฯอะࠧ信"),l11ll1_l1_ (u"ࠪีฬฬฬࠨ俢")]
		l11l1ll11l11_l1_ = [l11ll1_l1_ (u"ࠫ฻ำใࠨ俣"),l11ll1_l1_ (u"้่ࠬๆ์า๎ࠬ俤")]
		l11l1ll1l11l_l1_ = [l11ll1_l1_ (u"࠭ั๋ษู๋ࠬ俥"),l11ll1_l1_ (u"ࠧไ๊ิ๋ࠬ俦"),l11ll1_l1_ (u"ࠨ็ุหึ฿็ࠨ俧"),l11ll1_l1_ (u"ࠩื์ฯ࠭俨"),l11ll1_l1_ (u"ࠪี๏อึสࠩ俩")]
		l11ll1111lll_l1_ = [l11ll1_l1_ (u"๋ࠫ๐สโๆๆืࠬ俪"),l11ll1_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭俫"),l11ll1_l1_ (u"࠭ๆ๋ฬไ่๏้ำࠨ俬")]
		l11ll1111111_l1_ = [l11ll1_l1_ (u"ࠧๆ็ฮ่๏์ࠧ俭"),l11ll1_l1_ (u"ࠨษืาฬ฻ࠧ修"),l11ll1_l1_ (u"้ࠩะํ๋ࠧ俯")]
		l1l1ll1l1_l1_ = [l11ll1_l1_ (u"ࠪฬะࠦอ๋ࠩ俰"),l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ俱"),l11ll1_l1_ (u"่ࠬๆศ้ࠪ俲"),l11ll1_l1_ (u"࠭โ็๊สฮࠬ俳")]
		l11ll11111l1_l1_ = [l11ll1_l1_ (u"ࠧะ์้ࠫ俴"),l11ll1_l1_ (u"ࠨษา฽๏ํࠧ俵"),l11ll1_l1_ (u"ࠩี๎ฬืวหࠩ俶"),l11ll1_l1_ (u"่ࠪ฼๋๊ศฬࠪ俷"),l11ll1_l1_ (u"ࠫิ฿วยࠩ俸"),l11ll1_l1_ (u"่ࠬัศ่ࠪ俹"),l11ll1_l1_ (u"࠭โึษษำࠬ俺"),l11ll1_l1_ (u"ࠧาอสลࠬ俻"),l11ll1_l1_ (u"ࠨ็ิะ฾๐็ࠨ俼"),l11ll1_l1_ (u"ࠩสิฬ์ࠧ俽"),l11ll1_l1_ (u"ࠪหุ๊วๆࠩ俾"),l11ll1_l1_ (u"ࠫฯ๎วี์ะࠫ俿"),l11ll1_l1_ (u"ࠬิืษࠩ倀"),l11ll1_l1_ (u"࠭อ้ิ๋๎ࠬ倁"),l11ll1_l1_ (u"ฺࠧฬหหฯ࠭倂"),l11ll1_l1_ (u"ࠨ็๋ห้๐ฯࠨ倃"),l11ll1_l1_ (u"้ࠩ์ฬ฿๊ࠨ倄"),l11ll1_l1_ (u"ࠪ฽็อฦะࠩ倅"),l11ll1_l1_ (u"ࠫฬ์วี์าࠫ倆")]
		l11ll111ll1l_l1_ = [l11ll1_l1_ (u"ࠬ࠷࠹ࠨ倇"),l11ll1_l1_ (u"࠭࠲࠱ࠩ倈"),l11ll1_l1_ (u"ࠧ࠳࠳ࠪ倉"),l11ll1_l1_ (u"ࠨ࠴࠵ࠫ倊"),l11ll1_l1_ (u"ࠩ࠵࠷ࠬ個"),l11ll1_l1_ (u"ࠪ࠶࠹࠭倌"),l11ll1_l1_ (u"ࠫ࠷࠻ࠧ倍"),l11ll1_l1_ (u"ࠬ࠸࠶ࠨ倎")]
		if not l11l1ll1llll_l1_:
			l11l1ll1llll_l1_ = 0
			for l11l1lllllll_l1_ in l1ll1l1111_l1_:
				l11l1ll1llll_l1_ += 1
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭倏"),l111l1_l1_+l11l1lllllll_l1_,l11ll1_l1_ (u"ࠧࠨ倐"),165,l11ll1_l1_ (u"ࠨࠩ們"),str(l11l1ll1llll_l1_),l11ll1111l1l_l1_,l11ll1_l1_ (u"ࠩࠪ倒"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倓"):l1lll11l1l1l_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1lll1l1_l1_ = name.lower()
				category = []
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1l111_l1_): category.append(1)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll11l1_l1_): category.append(2)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll11ll1ll_l1_): category.append(3)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll111l_l1_): category.append(4)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll111l1l1_l1_): category.append(5)
				if any(value in l1ll1lll1l1_l1_ for value in l1111l1l_l1_): category.append(6)
				if any(value in l1ll1lll1l1_l1_ for value in l1llll1l1_l1_) and l1ll1lll1l1_l1_ not in [l11ll1_l1_ (u"ࠫฬิั๊ࠩ倔")]: category.append(7)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll1ll1_l1_): category.append(8)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1111l_l1_): category.append(9)
				if any(value in l1ll1lll1l1_l1_ for value in l1111111l_l1_): category.append(10)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll11ll1_l1_): category.append(11)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll11l11_l1_): category.append(12)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1l11l_l1_): category.append(13)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll1111lll_l1_): category.append(14)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll1111111_l1_): category.append(15)
				if any(value in l1ll1lll1l1_l1_ for value in l1l1ll1l1_l1_): category.append(16)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll11111l1_l1_): category.append(17)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll111ll1l_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l11l1ll1llll_l1_:
						addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ倕"),l111l1_l1_+name,name,166,l11ll1_l1_ (u"࠭ࠧ倖"),l11ll1_l1_ (u"ࠧࠨ倗"),l11ll1111l1l_l1_+l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倘"))
	elif l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ候") in options:
		import IPTV
		#if l11ll1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ倚") in options:
		l11l1ll111ll_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll11l1l1l_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True): return
			l11l1lll1l1l_l1_(l1lll11l1l1l_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠫࠬ倛"),True): return
			for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
				l11l1lll1l1l_l1_(str(l1lll11l1l1l_l1_),options)
			#else: l11l1ll111ll_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1ll111ll_l1_+menuItemsLIST[:]
	elif l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ倜") in options:
		import l1l1l11l11ll_l1_
		#if l11ll1_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ倝") in options:
		l11l1ll111ll_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll11l1l1l_l1_:
			if not l1l1l11l11ll_l1_.CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True): return
			l11ll111111l_l1_(l1lll11l1l1l_l1_,options)
		else:
			if not l1l1l11l11ll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠧࠨ倞"),True): return
			for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
				l11ll111111l_l1_(str(l1lll11l1l1l_l1_),options)
			#else: l11l1ll111ll_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1ll111ll_l1_+menuItemsLIST[:]
	return
def l11ll11l11ll_l1_(l11l1ll1lll1_l1_,options):
	l11l1ll1lll1_l1_ = l11l1ll1lll1_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ借"),l11ll1_l1_ (u"ࠩࠪ倠"))
	options = options.replace(l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倡"),l11ll1_l1_ (u"ࠫࠬ倢")).replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ倣"),l11ll1_l1_ (u"࠭ࠧ値"))
	l11l1ll11l1l_l1_(False)
	if contentsDICT=={}: return
	if l11ll1_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ倥") in options:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倦"),l11ll1_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ倧")+l11l1ll1lll1_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ倨"),l11l1ll1lll1_l1_,166,l11ll1_l1_ (u"ࠫࠬ倩"),l11ll1_l1_ (u"ࠬ࠭倪"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ倫")+options)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ倬"),l11ll1_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ倭"),l11l1ll1lll1_l1_,166,l11ll1_l1_ (u"ࠩࠪ倮"),l11ll1_l1_ (u"ࠪࠫ倯"),l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ倰")+options)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ倱"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倲"),l11ll1_l1_ (u"ࠧࠨ倳"),9999)
	for l1l1l11l_l1_ in sorted(list(contentsDICT[l11l1ll1lll1_l1_].keys())):
		type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1ll1lll1_l1_][l1l1l11l_l1_]
		if l11ll1_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ倴") in options or len(contentsDICT[l11l1ll1lll1_l1_])==1:
			l1l1ll1ll1ll_l1_(type,l11ll1_l1_ (u"ࠩࠪ倵"),url,l1ll1111l11l_l1_,l11ll1_l1_ (u"ࠪࠫ倶"),l1l1111_l1_,text,l11ll1_l1_ (u"ࠫࠬ倷"),l11ll1_l1_ (u"ࠬ࠭倸"))
			menuItemsLIST[:] = l11l1llll1l1_l1_(menuItemsLIST)
			l11l1ll111ll_l1_,l1llll11ll1_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1llll11ll1_l1_)
			if l11ll1_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ倹") in options: menuItemsLIST[:] = l11l1ll111ll_l1_+l1llll11ll1_l1_[:l11ll111llll_l1_]
			else: menuItemsLIST[:] = l11l1ll111ll_l1_+l1llll11ll1_l1_
		elif l11ll1_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ债") in options: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倻"),l1l1l11l_l1_,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_)
	return
def l11l1lll1lll_l1_(options,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ值"),l11ll1_l1_ (u"ࠪࠫ倽"),str(mode),options)
	options = options.replace(l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭倾"),l11ll1_l1_ (u"ࠬ࠭倿")).replace(l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ偀"),l11ll1_l1_ (u"ࠧࠨ偁"))
	name,l11l1lll1l11_l1_ = l11ll1_l1_ (u"ࠨࠩ偂"),[]
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偃"),l11ll1_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ偄")+name+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅไึ้ࠥࡀࠠ࡜ࠢࠪ偅"),l11ll1_l1_ (u"ࠬ࠭偆"),mode,l11ll1_l1_ (u"࠭ࠧ假"),l11ll1_l1_ (u"ࠧࠨ偈"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭偉")+options)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偊"),l11ll1_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪ偋"),l11ll1_l1_ (u"ࠫࠬ偌"),mode,l11ll1_l1_ (u"ࠬ࠭偍"),l11ll1_l1_ (u"࠭ࠧ偎"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ偏")+options)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭偐"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ偑"),l11ll1_l1_ (u"ࠪࠫ偒"),9999)
	l11l1ll111ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ偓") in options:
		l11l1ll11l1l_l1_(False)
		if contentsDICT=={}: return
		l11l1llll11l_l1_ = list(contentsDICT.keys())
		l11l1ll1lll1_l1_ = random.sample(l11l1llll11l_l1_,1)[0]
		l11ll11l1l1l_l1_ = list(contentsDICT[l11l1ll1lll1_l1_].keys())
		l1l1l11l_l1_ = random.sample(l11ll11l1l1l_l1_,1)[0]
		type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1ll1lll1_l1_][l1l1l11l_l1_]
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ偔"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩ偕")+l1l1l11l_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ偖")+name+l11ll1_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ偗")+url+l11ll1_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ偘")+str(l1ll1111l11l_l1_))
	elif l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ偙") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠫࠬ做"),True): return
		for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
			l11l1lll1l1l_l1_(str(l1lll11l1l1l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ偛"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭停")+name+l11ll1_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ偝")+url+l11ll1_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ偞")+str(l1ll1111l11l_l1_))
	elif l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ偟") in options:
		import l1l1l11l11ll_l1_
		if not l1l1l11l11ll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠪࠫ偠"),True): return
		for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
			l11ll111111l_l1_(str(l1lll11l1l1l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ偡"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ偢")+name+l11ll1_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ偣")+url+l11ll1_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ偤")+str(l1ll1111l11l_l1_))
	l11l1lll11ll_l1_ = name
	l11l1lllll11_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ健"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ偦")+name+l11ll1_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ偧")+url+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ偨")+str(l1ll1111l11l_l1_))
		menuItemsLIST[:] = []
		if l1ll1111l11l_l1_==234 and l11ll1_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭偩") in text: l1ll1111l11l_l1_ = 233
		if l1ll1111l11l_l1_==714 and l11ll1_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭偪") in text: l1ll1111l11l_l1_ = 713
		if l1ll1111l11l_l1_==144: l1ll1111l11l_l1_ = 291
		html = l1l1ll1ll1ll_l1_(type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_)
		#if l11ll1_l1_ (u"ࠧࡠࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࡣࠬ偫") in html: l11l1lll1lll_l1_(options,mode)
		if l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ偬") in options and l1ll1111l11l_l1_==167: del menuItemsLIST[:3]
		if l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ偭") in options and l1ll1111l11l_l1_==168: del menuItemsLIST[:3]
		l11l1lll1l11_l1_[:] = l11l1llll1l1_l1_(menuItemsLIST)
		if l11l1lllll11_l1_ and l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡸࠫา๊โสࠩ偮")) in str(l11l1lll1l11_l1_) or l1l1l1ll1lll_l1_(l11ll1_l1_ (u"ࡹࠬำไใ้ࠪ偯")) in str(l11l1lll1l11_l1_):
			name = l11l1lll11ll_l1_
			l11l1lll1l11_l1_[:] = l11l1lllll11_l1_
			break
		l11l1lll11ll_l1_ = name
		l11l1lllll11_l1_ = l11l1lll1l11_l1_[:]
		if str(l11l1lll1l11_l1_).count(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ偰"))>0: break
		if str(l11l1lll1l11_l1_).count(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ偱"))>0: break
		if l1ll1111l11l_l1_==233: break	# iptv l111l11l_l1_ names l11llll1l1l_l1_ of l1l11_l1_ name
		if l1ll1111l11l_l1_==713: break	# l11l1ll1ll11_l1_ l111l11l_l1_ names l11llll1l1l_l1_ of l1l11_l1_ name
		if l1ll1111l11l_l1_==291: break	# l1ll1ll11_l1_ l11ll11l1l11_l1_ names l11llll1l1l_l1_ of l1ll1ll11_l1_ l11ll11l1l11_l1_ contents
		if l11l1lll1l11_l1_: type,name,url,l1ll1111l11l_l1_,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ = random.sample(l11l1lll1l11_l1_,1)[0]
	if not name: name = l11ll1_l1_ (u"ࠧ࠯࠰࠱࠲ࠬ偲")
	elif name.count(l11ll1_l1_ (u"ࠨࡡࠪ偳"))>1: name = name.split(l11ll1_l1_ (u"ࠩࡢࠫ側"),2)[2]
	name = name.replace(l11ll1_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭偵"),l11ll1_l1_ (u"ࠫࠬ偶"))#.replace(l11ll1_l1_ (u"ࠬ࠲ࡍࡐࡘࡌࡉࡘࡀࠠࠨ偷"),l11ll1_l1_ (u"࠭ࠧ偸")).replace(l11ll1_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ偹"),l11ll1_l1_ (u"ࠨࠩ偺")).replace(l11ll1_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ偻"),l11ll1_l1_ (u"ࠪࠫ偼"))
	name = name.replace(l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ偽"),l11ll1_l1_ (u"ࠬ࠭偾"))
	l11l1ll111ll_l1_[0][1] = l11ll1_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ偿")+name+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭傀")
	for i in range(9): random.shuffle(l11l1lll1l11_l1_)
	if l11ll1_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ傁") in options: menuItemsLIST[:] = l11l1ll111ll_l1_+l11l1lll1l11_l1_[:l11ll111llll_l1_]
	else: menuItemsLIST[:] = l11l1ll111ll_l1_+l11l1lll1l11_l1_
	return
def l11l1ll1ll1l_l1_(l1l111111lll_l1_,l1l111l11l1l_l1_):
	l1l111l11l1l_l1_ = l1l111l11l1l_l1_.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ傂"),l11ll1_l1_ (u"ࠪࠫ傃")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傄"),l11ll1_l1_ (u"ࠬ࠭傅"))
	l11l1llll111_l1_ = l1l111l11l1l_l1_
	if l11ll1_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ傆") in l1l111l11l1l_l1_:
		l11l1llll111_l1_ = l1l111l11l1l_l1_.split(l11ll1_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ傇"))[0]
		type = l11ll1_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ傈")
	elif l11ll1_l1_ (u"࡙ࠩࡓࡉ࠭傉") in l1l111111lll_l1_: type = l11ll1_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭傊")
	elif l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ傋") in l1l111111lll_l1_: type = l11ll1_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭傌")
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭傍"),l11ll1_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ傎")+type+l11l1llll111_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ傏"),l1l111111lll_l1_,167,l11ll1_l1_ (u"ࠩࠪ傐"),l11ll1_l1_ (u"ࠪࠫ傑"),l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傒")+l1l111l11l1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傓"),l11ll1_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ傔"),l1l111111lll_l1_,167,l11ll1_l1_ (u"ࠧࠨ傕"),l11ll1_l1_ (u"ࠨࠩ傖"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傗")+l1l111l11l1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ傘"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ備"),l11ll1_l1_ (u"ࠬ࠭傚"),9999)
	import IPTV
	for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ傛") in l1l111l11l1l_l1_: IPTV.GROUPS(str(l1lll11l1l1l_l1_),l1l111111lll_l1_,l1l111l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ傜"),False)
		else: IPTV.ITEMS(str(l1lll11l1l1l_l1_),l1l111111lll_l1_,l1l111l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ傝"),False)
	menuItemsLIST[:] = l11l1llll1l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11ll111llll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11ll111llll_l1_)
	return
def l11l1ll111l1_l1_(l1l111111lll_l1_,l1l111l11l1l_l1_):
	l1l111l11l1l_l1_ = l1l111l11l1l_l1_.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ傞"),l11ll1_l1_ (u"ࠪࠫ傟")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傠"),l11ll1_l1_ (u"ࠬ࠭傡"))
	l11l1llll111_l1_ = l1l111l11l1l_l1_
	if l11ll1_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭傢") in l1l111l11l1l_l1_:
		l11l1llll111_l1_ = l1l111l11l1l_l1_.split(l11ll1_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ傣"))[0]
		type = l11ll1_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ傤")
	elif l11ll1_l1_ (u"࡙ࠩࡓࡉ࠭傥") in l1l111111lll_l1_: type = l11ll1_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭傦")
	elif l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ傧") in l1l111111lll_l1_: type = l11ll1_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭储")
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭傩"),l11ll1_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ傪")+type+l11l1llll111_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ傫"),l1l111111lll_l1_,168,l11ll1_l1_ (u"ࠩࠪ催"),l11ll1_l1_ (u"ࠪࠫ傭"),l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傮")+l1l111l11l1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傯"),l11ll1_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ傰"),l1l111111lll_l1_,168,l11ll1_l1_ (u"ࠧࠨ傱"),l11ll1_l1_ (u"ࠨࠩ傲"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傳")+l1l111l11l1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ傴"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ債"),l11ll1_l1_ (u"ࠬ࠭傶"),9999)
	import l1l1l11l11ll_l1_
	for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭傷") in l1l111l11l1l_l1_: l1l1l11l11ll_l1_.GROUPS(str(l1lll11l1l1l_l1_),l1l111111lll_l1_,l1l111l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ傸"),False)
		else: l1l1l11l11ll_l1_.ITEMS(str(l1lll11l1l1l_l1_),l1l111111lll_l1_,l1l111l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ傹"),False)
	menuItemsLIST[:] = l11l1llll1l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11ll111llll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11ll111llll_l1_)
	return
def l11l1llll1l1_l1_(menuItemsLIST):
	l11l1lll1l11_l1_ = []
	for type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_ in menuItemsLIST:
		if l11ll1_l1_ (u"ุࠩๅาฯࠧ傺") in name or l11ll1_l1_ (u"ูࠪๆำ็ࠨ傻") in name or l11ll1_l1_ (u"ࠫࡵࡧࡧࡦࠩ傼") in name.lower(): continue
		l11l1lll1l11_l1_.append([type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1ll1l1l1_l1_,l1ll1ll1l11_l1_])
	return l11l1lll1l11_l1_
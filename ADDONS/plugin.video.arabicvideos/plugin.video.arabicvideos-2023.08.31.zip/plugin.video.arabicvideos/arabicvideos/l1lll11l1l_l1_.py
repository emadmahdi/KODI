# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧᝑ")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡂࡄࡇࡣࠬᝒ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧศๆิส๏ู๊สࠩᝓ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l11111_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l1llll11_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ᝔"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ᝕"),l11ll1_l1_ (u"ࠪࠫ᝖"),l11ll1_l1_ (u"ࠫࠬ᝗"),l11ll1_l1_ (u"ࠬ࠭᝘"),l11ll1_l1_ (u"࠭ࠧ᝙"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᝚"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ᝛"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᝜"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ᝝"),l11ll1_l1_ (u"ࠫࠬ᝞"),559,l11ll1_l1_ (u"ࠬ࠭᝟"),l11ll1_l1_ (u"࠭ࠧᝠ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᝡ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᝢ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᝣ"),l11ll1_l1_ (u"ࠪࠫᝤ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᝥ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮหำ้ห๊ࠥใࠨᝦ"),l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬᝧ"),551,l11ll1_l1_ (u"ࠧࠨᝨ"),l11ll1_l1_ (u"ࠨࠩᝩ"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᝪ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᝫ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᝬ"),block,re.DOTALL)
	for l1lll1l11l_l1_,title in items:
		l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࡄ࡯ࡴࡦ࡯ࡀࠫ᝭")+l1lll1l11l_l1_+l11ll1_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧᝮ")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᝯ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᝰ")+l111l1_l1_+title,l1lllll_l1_,551)
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᝱"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᝲ"),l11ll1_l1_ (u"ࠫࠬᝳ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡮ࡢࡸ࠰ࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡺࡃ࠭᝴"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᝵"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ᝶"): continue
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ࠨ็ึุ่๊ࠠࠨ᝷") in title: continue
		if l11ll1_l1_ (u"ࠩฦัิัࠧ᝸") in title: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᝹"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᝺")+l111l1_l1_+title,l1lllll_l1_,551)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᝻"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᝼"),l11ll1_l1_ (u"ࠧࠨ᝽"),9999)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ᝾"): continue
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"่ࠩืู้ไࠡࠩ᝿") in title: continue
		if l11ll1_l1_ (u"ࠪวาีหࠨក") not in title: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫខ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧគ")+l111l1_l1_+title,l1lllll_l1_,551)
	return
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"࠭ࠧឃ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨង"),l11ll1_l1_ (u"ࠨࠩច"),url)
	items = []
	# l1lll11ll1_l1_ l1lll11lll_l1_
	if l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩឆ") in url or l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫជ") in url:
		l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
		l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪឈ"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬញ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫដ"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨឋ"),l11ll1_l1_ (u"ࠨࠩឌ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨឍ"))
		html = response.content
		l1l1l11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧណ"),url,l11ll1_l1_ (u"ࠫࠬត"),l11ll1_l1_ (u"ࠬ࠭ថ"),l11ll1_l1_ (u"࠭ࠧទ"),l11ll1_l1_ (u"ࠧࠨធ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧន"))
		html = response.content
		# l1lll1l11l_l1_ items
		if l1lll1l11l_l1_==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫប"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪផ"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪព"),block,re.DOTALL)
			#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ភ"),l11ll1_l1_ (u"࠭ࠧម"),l11ll1_l1_ (u"ࠧࠨយ"))
		# l1llll111l_l1_ l111l11l_l1_
		elif l11ll1_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠨរ") in html:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫល"),html,re.DOTALL)
		else:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨវ"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items:
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡳࡷ࡯ࡧࡪࡰࡤࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ឝ"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫឞ"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"࠭ๅีษ๊ำฮ࠭ស"),l11ll1_l1_ (u"ࠧโ์็้ࠬហ"),l11ll1_l1_ (u"ࠨษ฽๊๏ฯࠧឡ"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧអ"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩឣ"),l11ll1_l1_ (u"ࠫ์ีวโࠩឤ"),l11ll1_l1_ (u"๋ࠬศศำสอࠬឥ"),l11ll1_l1_ (u"ู࠭าุࠪឦ"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧឧ"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧឨ")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠩ࠲ࠫឩ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ឪ"),title,re.DOTALL)
		if l11ll1_l1_ (u"ุ๊ࠫวิๆࠪឫ") not in url and any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫឬ"),l111l1_l1_+title,l1lllll_l1_,552,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"࠭วๅฯ็ๆฮ࠭ឭ") in title:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ឮ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨឯ"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫឰ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឱ"),l111l1_l1_+title,l1lllll_l1_,551,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឲ"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
	if l1lll1l11l_l1_==l11ll1_l1_ (u"ࠬ࠭ឳ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࠪ឴"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ឵"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠣࠤា"): continue
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠩࠪិ"): addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪី"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪឹ")+title,l1lllll_l1_,551)
	if l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬឺ") in url or l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧុ") in url:
		if l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧូ") in url:
			url = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨួ"),l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪើ"))+l11ll1_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁ࠷࠶ࠧឿ")
		elif l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬៀ") in url:
			url,offset = url.split(l11ll1_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧេ"))
			offset = int(offset)+20
			url = url+l11ll1_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨែ")+str(offset)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧៃ"),l111l1_l1_+l11ll1_l1_ (u"ࠨ้้ห่ࠦวๅ็ี๎ิ࠭ោ"),url,551)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ៅ"),url,l11ll1_l1_ (u"ࠪࠫំ"),l11ll1_l1_ (u"ࠫࠬះ"),l11ll1_l1_ (u"ࠬ࠭ៈ"),l11ll1_l1_ (u"࠭ࠧ៉"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ៊"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸࡈࡹࡔࡧࡵ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ់"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡰ࡮ࡹࡴ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭៌"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ៍") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ៎"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ៏"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡪ࡯ࡤ࡫ࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ័"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭៑"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#title = title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱ្ࠫ"),l11ll1_l1_ (u"ࠩࠪ៓")).strip(l11ll1_l1_ (u"ࠪࠤࠬ។"))
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ៕"),l111l1_l1_+title,l1lllll_l1_,552,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ៖"),l11ll1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧៗ"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ៘"),l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ៙"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭៚"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ៛"),l11ll1_l1_ (u"ࠫࠬៜ"),l11ll1_l1_ (u"ࠬ࠭៝"),l11ll1_l1_ (u"࠭ࠧ៞"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ៟"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ០"))
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ១"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭២"),html,re.DOTALL)
		l11ll1ll_l1_ = l11ll1ll_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠦ࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ៣"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ៤"),l11ll1_l1_ (u"࠭ࠧ៥")).strip(l11ll1_l1_ (u"ࠧࠡࠩ៦"))
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡔࡱࡧࡹࡦࡴࡂࡷࡪࡸࡶࡦࡴࡀࠫ៧")+server+l11ll1_l1_ (u"ࠩࠩࡴࡴࡹࡴࡊࡆࡀࠫ៨")+l11ll1ll_l1_+l11ll1_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫ៩")
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ៪")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭៫")
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳࡄࡼࡒࡦࡳࡥ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࡜ࠣࡵࡨࡶࡻ࡫ࡲ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ៬"),block,re.DOTALL)
			for server,l1lll11l11_l1_,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ៭"),l11ll1_l1_ (u"ࠨࠩ៮")).strip(l11ll1_l1_ (u"ࠩࠣࠫ៯"))
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡇࡿࡎࡢ࡯ࡨࡃࡸ࡫ࡲࡷࡧࡵࡁࠬ៰")+server+l11ll1_l1_ (u"ࠫࠫࡳࡵ࡭ࡶ࡬ࡴࡱ࡫ࡓࡦࡴࡹࡩࡷࡹ࠽ࠨ៱")+l1lll11l11_l1_+l11ll1_l1_ (u"ࠬࠬࡰࡰࡵࡷࡍࡉࡃࠧ៲")+l11ll1ll_l1_+l11ll1_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧ៳")
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ៴")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ៵")
				l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡴࡽ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭៶"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ៷"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ៸")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ៹")
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ៺") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭៻")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭៼"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ៽"),url)
	return
l11ll1_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡔࡑࡇ࡙ࡠࡑࡏࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࡪࡡࡵࡣࠣࡁࠥࢁࠧࡗ࡫ࡨࡻࠬࡀ࠱ࡾࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࠻ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࡺࡸ࡬࠭ࡦࡤࡸࡦ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠࠎࠎࠩࠠࡸࡣࡷࡧ࡭ࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡼࡧࡴࡤࡪࠪࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡵࡨࡶ࠲ࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮ࡴࡹࡦࡲࡩࡵࡻ࠯ࡰ࡮ࡴ࡫ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ࠮ࠫࡤࡥ࡟ࡠࠩ࠮ࡵࡺࡧ࡬ࡪࡶࡼࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠬࠎࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩ࠾࠿࠳࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠱࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭ࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࠊࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱࠭ࡶࡪࡦࡨࡳࠬ࠲ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ៾")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ៿"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭᠀"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ᠁"),l11ll1_l1_ (u"ࠧ࠮ࠩ᠂"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ᠃")+search+l11ll1_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ᠄")
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11llll1l11_l1_ import *
script_name = l11ll1_l1_ (u"ࠨࡋࡑࡍ࡙࠭澃")
LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ澄"),l11ll1_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠨ澅"))
l1ll1111l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
l1ll1111l111_l1_ = int(mode)
l1ll1ll111l1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ澆"))
l1ll1ll111l1_l1_ = l1ll1ll111l1_l1_.replace(ltr,l11ll1_l1_ (u"ࠬ࠭澇")).replace(rtl,l11ll1_l1_ (u"࠭ࠧ澈"))
if l1ll1111l111_l1_==260: message = l11ll1_l1_ (u"࡚ࠧࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࡡࠠࠨ澉")+addon_version+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡋࡰࡦ࡬࠾ࠥࡡࠠࠨ澊")+l1l111ll1ll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ澋")
else:
	l1ll1l1lll1l1_l1_ = l1111_l1_(addon_path).replace(l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭澌"),l11ll1_l1_ (u"ࠫࠬ澍")).replace(l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ澎"),l11ll1_l1_ (u"࠭ࠧ澏"))
	l1ll1l1lll1l1_l1_ = l1ll1l1lll1l1_l1_.replace(l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ澐"),l11ll1_l1_ (u"ࠨࠩ澑")).strip(l11ll1_l1_ (u"ࠩࠣࠫ澒"))
	l1ll1l1lll1l1_l1_ = l1ll1l1lll1l1_l1_.replace(l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠨ澓"),l11ll1_l1_ (u"ࠫࠥ࠭澔")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ澕"),l11ll1_l1_ (u"࠭ࠠࠨ澖")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ澗"),l11ll1_l1_ (u"ࠨࠢࠪ澘"))
	message = l11ll1_l1_ (u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨ澙")+l1ll1ll111l1_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪ澚")+mode+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ澛")+l1ll1l1lll1l1_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ澜")
LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭澝"),LOGGING(script_name)+message)
l1l1llll11ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ澞"))
l111111l11l_l1_ = True if l1l1llll11ll_l1_==addon_version else False
if not l111111l11l_l1_ and l1ll1111l111_l1_ in [235,715]:
	l1lll11l1l1l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ澟")])
	script_name = l11ll1_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ澠") if l1ll1111l111_l1_==235 else l11ll1_l1_ (u"ࠪࡱ࠸ࡻࠧ澡")
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࠨ澢")+script_name+l11ll1_l1_ (u"ࠬ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ澣")+l1lll11l1l1l_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࠪ澤")+script_name+l11ll1_l1_ (u"ࠧ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ澥")+l1lll11l1l1l_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠨࡾࠪ澦")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ澧")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭澨")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"ࠫࢁࠬࠧ澩"),l11ll1_l1_ (u"ࠬࢂࠧ澪"))
	l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࠪ澫")+script_name+l11ll1_l1_ (u"ࠧ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ澬")+l1lll11l1l1l_l1_)
	if l1111l1l11_l1_:
		l1l1111l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫ澭"),url,re.DOTALL)
		url = url.replace(l1l1111l111l_l1_[0],l1111l1l11_l1_)
	script_name = script_name.upper()
	l1l11l1l1l1_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lllllll111_l1_ = l11ll1_l1_ (u"ࠩࠪ澮")
	l1ll1111l_l1_(l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ澯"))
	try: l1llll111lll_l1_(l1ll1111l1l_l1_,l1ll1ll111l1_l1_)
	except Exception as error: l1lllllll111_l1_ = traceback.format_exc()
	l1ll1111l_l1_(l11ll1_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ澰"))
	l1ll111lll11_l1_(l1lllllll111_l1_)
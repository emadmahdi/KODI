# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫᅘ")
headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᅙ") : l11ll1_l1_ (u"ࠫࠬᅚ") }
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡁࡓࡎࡢࠫᅛ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ู࠭าู๊ࠤฬ๊ๅึษิ฽ฮ࠭ᅜ"),l11ll1_l1_ (u"ࠧศๆๆ่ࠬᅝ"),l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪᅞ"),l11ll1_l1_ (u"ࠩส่฾อศࠨᅟ"),l11ll1_l1_ (u"ࠪฬึอๅอࠢๆ้อ๐่หำࠪᅠ"),l11ll1_l1_ (u"๊ࠫ๎ศศ์็ࠤํࠦฬ้ษ็ࠫᅡ"),l11ll1_l1_ (u"ࠬอไใี่ࠤฬ๊วิๆส้๏࠭ᅢ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l11111_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l1llll11_l1_(url)
	elif mode==204: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪᅣ")+text)
	elif mode==205: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧᅤ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅥ"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᅦ"),l11ll1_l1_ (u"ࠪࠫᅧ"),209,l11ll1_l1_ (u"ࠫࠬᅨ"),l11ll1_l1_ (u"ࠬ࠭ᅩ"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᅪ"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅫ"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫᅬ"),l11l1l_l1_,205)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅭ"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭ᅮ"),l11l1l_l1_,204)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᅯ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᅰ"),l11ll1_l1_ (u"࠭ࠧᅱ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅲ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᅳ")+l111l1_l1_+l11ll1_l1_ (u"่้ࠩ๏ุษࠨᅴ"),l11l1l_l1_+l11ll1_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧᅵ"),201)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅶ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᅷ")+l111l1_l1_+l11ll1_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫᅸ"),l11l1l_l1_+l11ll1_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡲࡵࡶࡪࡧࡶࠫᅹ"),201)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅺ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᅻ")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪᅼ"),l11l1l_l1_+l11ll1_l1_ (u"ࠫࡄࡅࡴࡳࡧࡱࡨ࡮ࡴࡧࡠࡵࡨࡶ࡮࡫ࡳࠨᅽ"),201)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅾ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᅿ")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᆀ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨࡁࡂࡱࡦ࡯࡮ࡱࡣࡪࡩࠬᆁ"),201)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᆂ"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫᆃ"),headers,True,l11ll1_l1_ (u"ࠫࠬᆄ"),l11ll1_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᆅ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡓࡡࡪࡰࡕࡳࡼ࠭ᆆ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᆇ"),block,re.DOTALL)
		for filter,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡩࡱࡰࡩ࠴ࡳ࡯ࡳࡧࡂࡪ࡮ࡲࡴࡦࡴࡀࠫᆈ")+filter
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᆉ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᆊ")+l111l1_l1_+title,l1lllll_l1_,201)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᆋ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᆌ"),l11ll1_l1_ (u"࠭ࠧᆍ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᆎ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᆏ"),block,re.DOTALL)
	#l1111llll_l1_ = [l11ll1_l1_ (u"่ࠩืู้ไศฬࠣࠫᆐ"),l11ll1_l1_ (u"ࠪหๆ๊วๆࠢࠪᆑ"),l11ll1_l1_ (u"ࠫอืวๆฮࠪᆒ"),l11ll1_l1_ (u"ࠬ฿ัุ้ࠪᆓ"),l11ll1_l1_ (u"࠭ใๅ์หหฯ࠭ᆔ"),l11ll1_l1_ (u"ࠧศ฼ส๊๎࠭ᆕ")]
	for l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᆖ") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᆗ"))
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆘ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᆙ")+l111l1_l1_+title,l1lllll_l1_,201)
	return html
def l11111_l1_(url):
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠦࠤ࡫ࡵࡲࠡࡒࡒࡗ࡙ࠦࡦࡪ࡮ࡷࡩࡷࡀࠊࠊ࡫ࡩࠤࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࡵࡳ࡮࠵࠰࡫࡯࡬ࡵࡧࡵࡷ࠷ࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡅࠧࠪࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧ࠭ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥࠫࡥࡣࡰࡷࡱࡸࡂ࠻࠰ࠨࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡷࡵࡰ࠷࠲ࡦࡪ࡮ࡷࡩࡷࡹ࠲ࠪࠌࠌࠍࡩࡧࡴࡢ࠴ࠣࡁࠥࢁࠧࡧࡱࡵࡱࠬࡀࡦࡪ࡮ࡷࡩࡷࡹ࠲࠭ࠩࡉ࡭ࡱࡺࡥࡳ࡙ࡲࡶࡩࡃࠧ࠻ࠩࠪࢁࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳ࠢࡀࠤ࡭࡫ࡡࡥࡧࡵࡷࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩࡠࠤࡂࠦࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩࡠࠤࡂ࡙ࠦࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷ࠷ࡡ࡙ࠧ࠯ࡆࡗࡗࡌ࠭ࡕࡑࡎࡉࡓ࠭࡝ࠡ࠿ࠣࠫࡌࡠ࠴ࡐࡦ࠳ࡲ࡯࡚ࡃࡢࡉࡺࡧࡌࡷ࠴ࡊࡼࡊࡵࡍࡋࡲ࡚࠲ࡸ࡞ࡴࡧࡕ࡙࡜ࡆ࠺ࡍ࡫ࡘࡹࡺࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜ࠩࡆࡳࡴࡱࡩࡦࠩࡠࠤࡂࠦࠧࡸࡣࡵࡦࡱ࡯࡯࡯ࡼࡷࡺࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࡥࡺࡌࡳࡨ࡮ࡏ࠶ࡊ࡯ࡕ࠴ࡒ࡞ࡎࡋ࡛࡯ࡖࡑࡗࡪࡥࡣࡑࡈࡰࡾࡖ࡯ࡦࡊ࡞࠶ࡈ࠲࡚࡮ࡈ࠽ࡕ࡙ࡉࡴࡋࡱ࡞࡭ࡨࡈࡗ࡮ࡌ࡮ࡴ࡯ࡑࡕࡔࡕ࡚࡝ࡓ࠱ࡖ࡬࡯ࡋࡧࡌࡆࡳࡣࡘࡊࡰࡕࡅࡹࡇࡒ࡙࡛ࡗ࡙ࡖ࠶࠴ࡨ࠶ࡔࡗࡦࡊࡦࡻࡪࡴࡍࡺࡘ࡚ࡖࡋࡗ࡭࡭࠴ࡘ࡜ࡎ࠶ࡤ࡬ࡺ࡯࡞࠶ࡈ࡮ࡢ࠵ࡳ࡜ࡘ࠷ࡂࡘࡤࡗࡅ࠸࡙࡭ࡏ࡬ࡧࡊࡩ࠹ࡗࡄࡋࡶࡍࡲ࠷ࡨ࡚ࡻࡌ࠺ࡎࡰࡕࡹ࡜ࡗ࡫ࡾࡔ࡭ࡎࡻࡒࡋࡊࡿࡍ࡫ࡋ࠳ࡒࡉࡔ࡬࡛࡬࡫ࡰࡓ࠸ࡎ࡬࡜ࡗࡆࡲࡔࡪࡥ࡯࡜ࡾࡆ࠶ࡎ࡫ࡃࡺࡑ࡙ࡐ࡫ࡎࡼ࡝࡮ࡔࡊࡉࡻࡐࡗ࡝ࡾࡓࡺ࡬࠲ࡑࡈࡨ࠻ࡍࡕࡄ࡭ࡒ࡜ࡏࡹࡐࡖ࡯࡮ࡓࡰࡧࡪࡨࡔࡁࡂ࠭ࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡔࡔ࡙ࡔࠨ࠮ࡸࡶࡱ࠸ࠬࡥࡣࡷࡥ࠷࠲ࡨࡦࡣࡧࡩࡷࡹ࠲࠭ࡖࡵࡹࡪ࠲ࠧࠨ࠮ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩࠬࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠥ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠨࠢࠣᆚ")
	if l11ll1_l1_ (u"࠭࠿ࡀࠩᆛ") in url: url,type = url.split(l11ll1_l1_ (u"ࠧࡀࡁࠪᆜ"))
	else: type = l11ll1_l1_ (u"ࠨࠩᆝ")
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᆞ"),l11ll1_l1_ (u"ࠪࠫᆟ"),url,type)
	#if url==l11l1l_l1_: url = url+l11ll1_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩᆠ")
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ᆡ"),l11ll1_l1_ (u"࠭ࠧᆢ"),url,l11ll1_l1_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠧᆣ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᆤ"),url,l11ll1_l1_ (u"ࠩࠪᆥ"),headers,True,l11ll1_l1_ (u"ࠪࠫᆦ"),l11ll1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᆧ"))
	html = response.content#.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᆨ"))
	#WRITE_THIS(html)
	if l11ll1_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨᆩ") in url: l1l1l11_l1_ = [html]
	elif type==l11ll1_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࠩᆪ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡏࡤࡷࡹ࡫ࡲࡔ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡠࡳࠦࠪ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀࠪᆫ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࡣࡲࡵࡶࡪࡧࡶࠫᆬ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡗࡱ࡯ࡤࡦࡴࡢ࠵࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᆭ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠫࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥࡳࡦࡴ࡬ࡩࡸ࠭ᆮ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡤ࠸ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᆯ"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"࠭࠱࠲࠳ࡰࡥ࡮ࡴࡰࡢࡩࡨࠫᆰ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣࡴࡦ࡭ࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥࡷࠧ࠭ᆱ"),html,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩᆲ"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᆳ"),l11ll1_l1_ (u"ࠪࠫᆴ"),l11ll1_l1_ (u"ࠫࠬᆵ"),str(l1l1l11_l1_))
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨ࡯ࡹ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᆶ"),block,re.DOTALL)
	l111ll1ll_l1_ = [l11ll1_l1_ (u"࠭ๅีษ๊ำฮ࠭ᆷ"),l11ll1_l1_ (u"ࠧโ์็้ࠬᆸ"),l11ll1_l1_ (u"ࠨษ฽๊๏ฯࠧᆹ"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧᆺ"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩᆻ"),l11ll1_l1_ (u"ࠫ์ีวโࠩᆼ"),l11ll1_l1_ (u"๋ࠬศศำสอࠬᆽ"),l11ll1_l1_ (u"ู࠭าุࠪᆾ"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧᆿ"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧᇀ")]
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᇁ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᇂ"),l11ll1_l1_ (u"ࠫࠬᇃ"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᇄ"),block,re.DOTALL)
	if not items:
		items = re.findall(l11ll1_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡏࡴࡦ࡯ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀࠬᇅ"),block,re.DOTALL)
		l1l1_l1_,l1111lll1_l1_,l11lll_l1_ = zip(*items)
		items = zip(l1111lll1_l1_,l1l1_l1_,l11lll_l1_)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
		#l1lllll_l1_ = QUOTE(l1lllll_l1_)
		if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩᇆ") in l1lllll_l1_: continue
		l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᇇ"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᇈ"))
		if l11ll1_l1_ (u"ࠪ࠳࡫࡯࡬࡮࠱ࠪᇉ") in l1lllll_l1_ or any(value in title for value in l111ll1ll_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᇊ"),l111l1_l1_+title,l1lllll_l1_,202,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨᇋ") in l1lllll_l1_ and l11ll1_l1_ (u"࠭วๅฯ็ๆฮ࠭ᇌ") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᇍ"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᇎ") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇏ"),l111l1_l1_+title,l1lllll_l1_,203,l1lll1_l1_)
					l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠪ࠳ࡵࡧࡣ࡬࠱ࠪᇐ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᇑ"),l111l1_l1_+title,l1lllll_l1_+l11ll1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬᇒ"),201,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇓ"),l111l1_l1_+title,l1lllll_l1_,203,l1lll1_l1_)
	if type in [l11ll1_l1_ (u"ࠧࠨᇔ"),l11ll1_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡶࡡࡨࡧࠪᇕ")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᇖ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᇗ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
				title = unescapeHTML(title)
				title = title.replace(l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᇘ"),l11ll1_l1_ (u"ࠬ࠭ᇙ"))
				if l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩᇚ") in url:
					l1111ll11_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭ᇛ"))[1]
					l111l1ll1_l1_ = url.split(l11ll1_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧᇜ"))[1]
					l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨᇝ")+l111l1ll1_l1_,l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇞ")+l1111ll11_l1_)
				if title!=l11ll1_l1_ (u"ࠫࠬᇟ"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇠ"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬᇡ")+title,l1lllll_l1_,201)
	return
def l1llll11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᇢ"),l11ll1_l1_ (u"ࠨࠩᇣ"),url,l11ll1_l1_ (u"ࠩࠪᇤ"))
	l111llll1_l1_,items,l1111ll1_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᇥ"),url,l11ll1_l1_ (u"ࠫࠬᇦ"),headers,True,l11ll1_l1_ (u"ࠬ࠭ᇧ"),l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᇨ"))
	html = response.content#.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᇩ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡶ࡬࠱ࡱ࡯ࡳࡵ࠯ࡱࡹࡲࡨࡥࡳࡧࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᇪ"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1111ll1_l1_ = []
		l1111l1_l1_ = l11ll1_l1_ (u"ࠩࠪᇫ").join(l1l1l11_l1_)
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᇬ"),l1111l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬᇭ"))
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧᇮ"))
		title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᇯ") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩᇰ"))[-1].replace(l11ll1_l1_ (u"ࠨ࠯ࠪᇱ"),l11ll1_l1_ (u"ࠩࠣࠫᇲ"))
		l111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪห้ำไให࠰ࠬࡡࡪࠫࠪࠩᇳ"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭ᇴ"))[-1],re.DOTALL)
		if l111l1l1_l1_: l111l1l1_l1_ = l111l1l1_l1_[0]
		else: l111l1l1_l1_ = l11ll1_l1_ (u"ࠬ࠶ࠧᇵ")
		l1111ll1_l1_.append([l1lllll_l1_,title,l111l1l1_l1_])
	items = sorted(l1111ll1_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lll11_l1_ = str(items).count(l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨᇶ"))
	l111llll1_l1_ = str(items).count(l11ll1_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᇷ"))
	if l111lll11_l1_>1 and l111llll1_l1_>0 and l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪᇸ") not in url:
		for l1lllll_l1_,title,l111l1l1_l1_ in items:
			if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᇹ") in l1lllll_l1_:
				#l1lllll_l1_ = QUOTE(l1lllll_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᇺ"),l111l1_l1_+title,l1lllll_l1_,203)
	else:
		for l1lllll_l1_,title,l111l1l1_l1_ in items:
			if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᇻ") not in l1lllll_l1_:
				#if l11ll1_l1_ (u"ࠬࠫࠧᇼ") not in l1lllll_l1_: l1lllll_l1_ = QUOTE(l1lllll_l1_)
				#else: l1lllll_l1_ = QUOTE(l1111_l1_(l1lllll_l1_))
				#l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
				title = l1111_l1_(title)
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᇽ"),l111l1_l1_+title,l1lllll_l1_,202)
	return
def PLAY(url):
	#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᇾ"),l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦ࠱࠲࠳ࠪᇿ"))
	l1llll_l1_ = []
	parts = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫሀ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫሁ"),l11ll1_l1_ (u"ࠫࠬሂ"),url,l11ll1_l1_ (u"ࠬࡖࡌࡂ࡛࠰࠵ࡸࡺࠧሃ"))
	#url = l1111_l1_(QUOTE(url))
	hostname = l11l1l_l1_
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪሄ"),url,l11ll1_l1_ (u"ࠧࠨህ"),headers,True,True,l11ll1_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬሆ"))
	html = response.content#.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧሇ"))
	id = re.findall(l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫለ"),html,re.DOTALL)
	if not id: id = re.findall(l11ll1_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬሉ"),html,re.DOTALL)
	if not id: id = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሊ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧላ"),l11ll1_l1_ (u"ࠧࠨሌ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫል"),l11ll1_l1_ (u"ࠩํีั๏ࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ้๋ࠢࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭ሎ"))
	#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪሏ"),l11ll1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡖࡘࡆࡘࡔࠡࡖࡌࡑࡎࡔࡇࠡ࠳࠴࠵ࠬሐ"))
	if l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ሑ") in html:
		#parts = url.split(l11ll1_l1_ (u"࠭࠯ࠨሒ"))
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭ሓ"))
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬሔ"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪሕ"),headers,True,True,l11ll1_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧሖ"))
		l11ll1l1_l1_ = response.content#.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩሗ"))
		l1111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫመ"),l11ll1l1_l1_,re.DOTALL)
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧሙ"),l11ll1l1_l1_,re.DOTALL)
		l1111l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫሚ"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
		l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࡝ࡰ࠭࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩማ"),l11ll1l1_l1_)
		l11111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪሜ"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
		l111l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬም"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
		items = l1111l1l1_l1_+l1l1l1l_l1_+l1111l1ll_l1_+l1111l111_l1_+l11111lll_l1_+l111l1l1l_l1_
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫሞ"),l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡗ࡙ࡇࡒࡕࠢࡗࡍࡒࡏࡎࡈࠢ࠷࠸࠹࠭ሟ"))
		if not items:
			items = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫሠ"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l11ll1_l1_ (u"ࠧ࠯ࡲࡱ࡫ࠬሡ") in server: continue
			if l11ll1_l1_ (u"ࠨ࠰࡭ࡴ࡬࠭ሢ") in server: continue
			if l11ll1_l1_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩሣ") in server: continue
			l111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫሤ"),title,re.DOTALL)
			if l111lll1_l1_:
				l111lll1_l1_ = l111lll1_l1_[0]
				if l111lll1_l1_ in title: title = title.replace(l111lll1_l1_+l11ll1_l1_ (u"ࠫࡵ࠭ሥ"),l11ll1_l1_ (u"ࠬ࠭ሦ")).replace(l111lll1_l1_,l11ll1_l1_ (u"࠭ࠧሧ")).strip(l11ll1_l1_ (u"ࠧࠡࠩረ"))
				l111lll1_l1_ = l11ll1_l1_ (u"ࠨࡡࡢࡣࡤ࠭ሩ")+l111lll1_l1_
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠩࠪሪ")
			#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪራ"),l11ll1_l1_ (u"ࠫࡠ࠭ሬ")+str(id)+l11ll1_l1_ (u"ࠬࡣࠠࠡ࡝ࠪር")+str(hostname)+l11ll1_l1_ (u"࠭࡝ࠡࠢ࡞ࠫሮ")+str(title)+l11ll1_l1_ (u"ࠧ࡞ࠢࠣ࡟ࠬሯ")+str(l111lll1_l1_)+l11ll1_l1_ (u"ࠨ࡟ࠪሰ"))
			if server.isdigit():
				l1lllll_l1_ = hostname+l11ll1_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬሱ")+id+l11ll1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧሲ")+server+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬሳ")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ሴ")+l111lll1_l1_
			else:
				if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫስ") not in server: server = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ሶ")+server
				l111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩሷ"),title,re.DOTALL)
				if l111lll1_l1_: l111lll1_l1_ = l11ll1_l1_ (u"ࠩࡢࡣࡤࡥࠧሸ")+l111lll1_l1_[0]
				else: l111lll1_l1_ = l11ll1_l1_ (u"ࠪࠫሹ")
				l1lllll_l1_ = server+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬሺ")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬሻ"),l11ll1_l1_ (u"࡛࠭ࠨሼ")+l111lll1_l1_+l11ll1_l1_ (u"ࠧ࡞ࠢࠣࠤࠥࡡࠧሽ")+title+l11ll1_l1_ (u"ࠨ࡟ࠪሾ"))
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧሿ"), l1llll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫቀ"),l11ll1_l1_ (u"ࠫࠬቁ"),l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠤ࠶࠭ቂ"),	str(len(items)))
	if l11ll1_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡏࡱࡺࠫቃ") in html:
		l1l1ll111_l1_ = { l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ቄ"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨቅ") }
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬቆ")
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧቇ"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬቈ"),l1l1ll111_l1_,True,l11ll1_l1_ (u"ࠬ࠭቉"),l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪቊ"))
		l11ll1l1_l1_ = response.content#.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬቋ"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩቌ"),l11ll1_l1_ (u"ࠩࠪቍ"),l111lll_l1_,l11ll1l1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ቎"),l11ll1l1_l1_,re.DOTALL)
		for block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭቏"),block,re.DOTALL)
			for l1lllll_l1_,name,l111lll1_l1_ in items:
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ቐ")+name+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪቑ")+l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬቒ")+l111lll1_l1_
				l1llll_l1_.append(l1lllll_l1_)
	elif l11ll1_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬቓ") in html:
		l1l1ll111_l1_ = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ቔ"):l11ll1_l1_ (u"ࠪࠫቕ") , l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧቖ"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭቗") }
		l111lll_l1_ = hostname + l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩቘ")+id
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ቙"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩቚ"),l1l1ll111_l1_,True,True,l11ll1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭ቛ"))
		l11ll1l1_l1_ = response.content#.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨቜ"))
		if l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠳ࡢࡵࡰࡶࠫቝ") in l11ll1l1_l1_:
			l1111l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ቞"),l11ll1l1_l1_,re.DOTALL)
			for l11l111_l1_ in l1111l1ll_l1_:
				if l11ll1_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭቟") not in l11l111_l1_ and l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬበ") in l11l111_l1_:
					l11l111_l1_ = l11l111_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬቡ")
					l1llll_l1_.append(l11l111_l1_)
				elif l11ll1_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩቢ") in l11l111_l1_:
					l111lll1_l1_ = l11ll1_l1_ (u"ࠪࠫባ")
					response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨቤ"),l11l111_l1_,l11ll1_l1_ (u"ࠬ࠭ብ"),headers,True,True,l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪቦ"))
					l111l1111_l1_ = response.content#.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬቧ"))
					l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭ቨ"),l111l1111_l1_,re.DOTALL)
					for l111lll1l_l1_ in l1111l1_l1_:
						l111l11l1_l1_ = l11ll1_l1_ (u"ࠩࠪቩ")
						l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬቪ"),l111lll1l_l1_,re.DOTALL)
						for l111l1lll_l1_ in l1111l111_l1_:
							item = re.findall(l11ll1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬቫ"),l111l1lll_l1_,re.DOTALL)
							if item:
								l111lll1_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪቬ")+item[0]
								break
						for l111l1lll_l1_ in reversed(l1111l111_l1_):
							item = re.findall(l11ll1_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬቭ"),l111l1lll_l1_,re.DOTALL)
							if item:
								l111l11l1_l1_ = item[0]
								break
						l11111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ቮ"),l111lll1l_l1_,re.DOTALL)
						for l111l1l11_l1_ in l11111lll_l1_:
							l111l1l11_l1_ = l111l1l11_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩቯ")+l111l11l1_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ተ")+l111lll1_l1_
							l1llll_l1_.append(l111l1l11_l1_)
			#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫቱ"),l11ll1_l1_ (u"ࠫࠬቲ"),l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࠲ࠩታ"),	str(len(l1llll_l1_))	)
		elif l11ll1_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠫቴ") in l11ll1l1_l1_:
			l11ll1l1_l1_ = l11ll1l1_l1_.replace(l11ll1_l1_ (u"ࠧ࠽ࡪ࠹ࠤࠬት"),l11ll1_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬቶ"))+l11ll1_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪቷ")
			l11ll1l1_l1_ = l11ll1l1_l1_.replace(l11ll1_l1_ (u"ࠪࡀ࡭࠹ࠠࠨቸ"),l11ll1_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨቹ"))+l11ll1_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ቺ")
			#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ቻ"),l11ll1l1_l1_)
			#open(l11ll1_l1_ (u"ࠧࡴ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧቼ"),l11ll1_l1_ (u"ࠨࡹࠪች")).write(l11ll1l1_l1_)
			l1111l11l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡀࡁࡘ࡚ࡁࡓࡖࡀࡁ࠭࠴ࠪࡀࠫࡀࡁࡊࡔࡄ࠾࠿ࠪቾ"),l11ll1l1_l1_,re.DOTALL)
			if l1111l11l_l1_:
				for l111lll1l_l1_ in l1111l11l_l1_:
					if l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩቿ") not in l111lll1l_l1_: continue
					#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬኀ"),l11ll1_l1_ (u"ࠬ࠭ኁ"),l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠡ࠳࠴࠵ࠬኂ"),	l111lll1l_l1_	)
					l111ll111_l1_ = l11ll1_l1_ (u"ࠧࠨኃ")
					l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵ࡯ࡳࡼ࠳࡭ࡰࡶ࡬ࡳࡳࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧኄ"),l111lll1l_l1_,re.DOTALL)
					for l111l1lll_l1_ in l1111l111_l1_:
						item = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪኅ"),l111l1lll_l1_,re.DOTALL)
						if item:
							l111ll111_l1_ = l11ll1_l1_ (u"ࠪࡣࡤࡥ࡟ࠨኆ")+item[0]
							break
					l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪኇ"),l111lll1l_l1_,re.DOTALL)
					if l1111l111_l1_:
						for l111l11l1_l1_,l111l11ll_l1_ in l1111l111_l1_:
							l111l11ll_l1_ = l111l11ll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ኈ")+l111l11l1_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ኉")+l111ll111_l1_
							l1llll_l1_.append(l111l11ll_l1_)
					else:
						l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧኊ"),l111lll1l_l1_,re.DOTALL)
						for l111l11ll_l1_,l111l11l1_l1_ in l1111l111_l1_:
							l111l11ll_l1_ = l111l11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪኋ"))+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪኌ")+l111l11l1_l1_+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧኍ")+l111ll111_l1_
							l1llll_l1_.append(l111l11ll_l1_)
			else:
				l1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࡝ࡹ࠮࠭ࡁ࠭኎"),l11ll1l1_l1_,re.DOTALL)
				for l111l11ll_l1_,l111l11l1_l1_ in l1111l111_l1_:
					l111l11ll_l1_ = l111l11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ኏"))+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧነ")+l111l11l1_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫኑ")
					l1llll_l1_.append(l111l11ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ኒ"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨና"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫኔ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬን"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧኖ"),l11ll1_l1_ (u"࠭ࠫࠨኗ"))
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫኘ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡤࡰࡿ࠭ኙ"),l11ll1_l1_ (u"ࠩࠪኚ"),headers,True,l11ll1_l1_ (u"ࠪࠫኛ"),l11ll1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪኜ"))
	html = response.content#.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪኝ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣࡩࡧࡹࡶࡴࡴ࠭ࡴࡧ࡯ࡩࡨࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫኞ"),html,re.DOTALL)
	if l1ll_l1_ and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪኟ"),block,re.DOTALL)
		l111ll11l_l1_,l111l111l_l1_ = [],[]
		for category,title in items:
			#if title in [l11ll1_l1_ (u"ࠨำํห฻ฯู้่ࠠࠢฬืู่ࠩአ")]: continue
			l111ll11l_l1_.append(category)
			l111l111l_l1_.append(title)
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩኡ"), l111l111l_l1_)
		if l1l_l1_ == -1 : return
		category = l111ll11l_l1_[l1l_l1_]
	else: category = l11ll1_l1_ (u"ࠪࠫኢ")
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨኣ")+search+l11ll1_l1_ (u"ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩኤ")+category+l11ll1_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠷ࠧእ")
	l11111_l1_(url)
	return
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩኦ"),l11ll1_l1_ (u"ࠨࠩኧ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪከ"),l11ll1_l1_ (u"ࠪࠫኩ"),filter,url)
	# for l1111ll1l_l1_ filter:		l1l11l11_l1_ = [l11ll1_l1_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶࡾࡉࡨࡦࡥ࡮ࡆࡴࡾࠧኪ"),l11ll1_l1_ (u"ࠬ࡟ࡥࡢࡴࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫካ"),l11ll1_l1_ (u"࠭ࡇࡦࡰࡵࡩࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ኬ"),l11ll1_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩክ")]
	l1l11l11_l1_ = [l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪኮ"),l11ll1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨኯ"),l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩኰ"),l11ll1_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ኱")]
	if l11ll1_l1_ (u"ࠬࡅࠧኲ") in url: url = url.split(l11ll1_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪኳ"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫኴ"),1)
	if filter==l11ll1_l1_ (u"ࠨࠩኵ"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠩࠪ኶"),l11ll1_l1_ (u"ࠪࠫ኷")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨኸ"))
	if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩኹ"):
		if l1l11l11_l1_[0]+l11ll1_l1_ (u"࠭࠽ࠨኺ") not in l1l111l1_l1_: category = l1l11l11_l1_[0]
		for i in range(len(l1l11l11_l1_[0:-1])):
			if l1l11l11_l1_[i]+l11ll1_l1_ (u"ࠧ࠾ࠩኻ") in l1l111l1_l1_: category = l1l11l11_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪኼ")+category+l11ll1_l1_ (u"ࠩࡀ࠴ࠬኽ")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠪࠪࠬኾ")+category+l11ll1_l1_ (u"ࠫࡂ࠶ࠧ኿")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧዀ"))+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ዁")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠩዂ"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫዃ"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ዄ")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫዅ"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭዆"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠬ࠭዇"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩወ"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠧࠨዉ"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬዊ")+l1l1111l_l1_
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዋ"),l111l1_l1_+l11ll1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ዌ"),l111lll_l1_,201)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫው"),l111l1_l1_+l11ll1_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬዎ")+l11ll11l_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬዏ"),l111lll_l1_,201)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬዐ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨዑ"),l11ll1_l1_ (u"ࠩࠪዒ"),9999)
	html = OPENURL_CACHED(l1lllll1_l1_,url+l11ll1_l1_ (u"ࠪ࠳ࡦࡲࡺࠨዓ"),l11ll1_l1_ (u"ࠫࠬዔ"),headers,l11ll1_l1_ (u"ࠬ࠭ዕ"),l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫዖ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡂ࡬ࡤࡼࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡄࡢࡶࡤࠬ࠳࠰࠿ࠪࡈ࡬ࡰࡹ࡫ࡲࡘࡱࡵࡨࠬ዗"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# for l1111ll1l_l1_ filter:		l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࡭࠸ࠧዘ"),block,re.DOTALL)
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡦࡰࡴࡗࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࡮࠲ࠨዙ"),block,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫዚ"),l11ll1_l1_ (u"ࠫࠬዛ"),l11ll1_l1_ (u"ࠬ࠭ዜ"),str(l1ll1ll1_l1_))
	dict = {}
	for name,l1ll1l11_l1_,block in l1ll1ll1_l1_:
		#name = name.replace(l11ll1_l1_ (u"࠭࠭࠮ࠩዝ"),l11ll1_l1_ (u"ࠧࠨዞ"))
		name = name.replace(l11ll1_l1_ (u"ࠨษัฮ๏อัࠡࠩዟ"),l11ll1_l1_ (u"ࠩࠪዠ"))
		name = name.replace(l11ll1_l1_ (u"ࠪื๋ฯࠠศๆศ๊ฯอฬࠨዡ"),l11ll1_l1_ (u"ࠫฬ๊ำ็หࠪዢ"))
		items = re.findall(l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ዣ"),block,re.DOTALL)
		if l11ll1_l1_ (u"࠭࠽ࠨዤ") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫዥ"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<=1:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨዦ")+l1l11ll1_l1_)
				return
			else:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዧ"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠣࠫየ"),l111lll_l1_,201)
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዩ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ዪ"),l111lll_l1_,205,l11ll1_l1_ (u"࠭ࠧያ"),l11ll1_l1_ (u"ࠧࠨዬ"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩይ"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫዮ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡁ࠵࠭ዯ")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠫࠫ࠭ደ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃ࠰ࠨዱ")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪዲ")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዳ"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪዴ")+name,l111lll_l1_,204,l11ll1_l1_ (u"ࠩࠪድ"),l11ll1_l1_ (u"ࠪࠫዶ"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ዷ"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			option = option.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨዸ"),l11ll1_l1_ (u"࠭ࠧዹ"))
			if option in l1l11l_l1_: continue
			#if option==l11ll1_l1_ (u"ࠧศๆๆ่ࠬዺ"): continue
			#option = l11ll1_l1_ (u"ࠨ࡝ࠪዻ")+option+l11ll1_l1_ (u"ࠩࡠࠫዼ")
			#if l11ll1_l1_ (u"ࠪห้้ไࠨዽ") in option: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬዾ"),l11ll1_l1_ (u"ࠬ࠭ዿ"),l11ll1_l1_ (u"࠭ࠧጀ"),l11ll1_l1_ (u"ࠧ࡜ࠩጁ")+str(option)+l11ll1_l1_ (u"ࠨ࡟ࠪጂ"))
			#if l11ll1_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨጃ") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫጄ"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭ጅ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡃࠧጆ")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"࠭ࠦࠨጇ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠧ࠾ࠩገ")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬጉ")+l1l1ll11_l1_
			title = option+l11ll1_l1_ (u"ࠩࠣ࠾ࠬጊ")#+dict[l1ll1l11_l1_][l11ll1_l1_ (u"ࠪ࠴ࠬጋ")]
			title = option+l11ll1_l1_ (u"ࠫࠥࡀࠧጌ")+name
			if type==l11ll1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ግ"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ጎ"),l111l1_l1_+title,url,204,l11ll1_l1_ (u"ࠧࠨጏ"),l11ll1_l1_ (u"ࠨࠩጐ"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ጑"))
			elif type==l11ll1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧጒ") and l1l11l11_l1_[-2]+l11ll1_l1_ (u"ࠫࡂ࠭ጓ") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨጔ"))
				l11l111_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪጕ")+l11llll1_l1_
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ጖"),l111l1_l1_+title,l11l111_l1_,201)
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ጗"),l111l1_l1_+title,url,205,l11ll1_l1_ (u"ࠩࠪጘ"),l11ll1_l1_ (u"ࠪࠫጙ"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬጚ"),l11ll1_l1_ (u"ࠬ࠭ጛ"),filters,l11ll1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧጜ"))
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩጝ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫጞ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭ጟ")					all filters (l11lll11_l1_ l1l1l1l1_l1_ filter)
	filters = filters.replace(l11ll1_l1_ (u"ࠪࡁࠫ࠭ጠ"),l11ll1_l1_ (u"ࠫࡂ࠶ࠦࠨጡ"))
	filters = filters.strip(l11ll1_l1_ (u"ࠬࠬࠧጢ"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"࠭࠽ࠨጣ") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠧࠧࠩጤ"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠨ࠿ࠪጥ"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"ࠩࠪጦ")
	# for l1111ll1l_l1_ filter:		l1ll1111_l1_ = [l11ll1_l1_ (u"ࠪࡇࡦࡺࡥࡨࡱࡵࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ጧ"),l11ll1_l1_ (u"ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪጨ"),l11ll1_l1_ (u"ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬጩ"),l11ll1_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጪ")]
	l1ll1111_l1_ = [l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩጫ"),l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧጬ"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨጭ"),l11ll1_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫጮ")]
	for key in l1ll1111_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠫ࠵࠭ጯ")
		if l11ll1_l1_ (u"ࠬࠫࠧጰ") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨጱ") and value!=l11ll1_l1_ (u"ࠧ࠱ࠩጲ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬጳ")+value
		elif mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬጴ") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬጵ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭ጶ")+key+l11ll1_l1_ (u"ࠬࡃࠧጷ")+value
		elif mode==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪጸ"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩጹ")+key+l11ll1_l1_ (u"ࠨ࠿ࠪጺ")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠩࠣ࠯ࠥ࠭ጻ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬጼ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠫࡂ࠶ࠧጽ"),l11ll1_l1_ (u"ࠬࡃࠧጾ"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧጿ"),l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨፀ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩፁ"),l11ll1_l1_ (u"ࠩࠪፂ"),filters,l11ll1_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫፃ"))
	return l1ll11l1_l1_
l11ll1_l1_ (u"ࠦࠧࠨࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠴ࡷࡹࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡷࡶࡩࡩࠦ࡮ࡰࡹࠣ࡭ࡳࠦࡷࡦࡤࡶ࡭ࡹ࡫ࠩࠋࡣࡧࡨ࡮ࡴࡧࠡࡨ࡬ࡰࡹ࡫ࡲࠡࡶࡲࠤࡸ࡫ࡡࡳࡥ࡫ࠎࡕࡕࡓࡕ࠼ࠌ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴ࡡࡳࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥࠫࡥࡣࡰࡷࡱࡸࡂ࠻࠰ࠋࠋࡧࡥࡹࡧ࠺ࠊ࡝ࠪࡇࡦࡺࡥࡨࡱࡵࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ࠬࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧ࠭ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫࡖࡻࡡ࡭࡫ࡷࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭࡝ࠋࠋ࡫ࡩࡦࡪࡥࡳࡵ࠽ࠍࡈࡵ࡯࡬࡫ࡨࠤ࠰ࠦࡘࡓࡇࡉ࠱࡙ࡕࡋࡆࡐࠍࠎࠏ࡬ࡩ࡭ࡶࡨࡶࡸࡀࠉ࠳ࡰࡧࠤࡲ࡫ࡴࡩࡱࡧࠍࠎ࠮࡯࡭ࡦࠣࡱࡪࡺࡨࡰࡦࠣࡦࡺࡺࠠࡴࡶ࡬ࡰࡱࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠩࠊࠋࠫࡹࡸ࡫ࡤࠡ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡶࡻࡡ࡭࡫ࡷࡽࡂ࡝ࡅࡃ࠯ࡇࡐࠫࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࡁ࠷࠶࠲࠱ࠌࠍࠎࠏ࡬ࡩ࡭ࡶࡨࡶࡸࡀࠉ࠴ࡴࡧࠤࡲ࡫ࡴࡩࡱࡧࠍࠎ࠮࡯࡭ࡦࠣࡱࡪࡺࡨࡰࡦࠣࡦࡺࡺࠠࡴࡶ࡬ࡰࡱࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠩࠋࡉࡈࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶ࠴࠸࠰࠲࠻ࠍࡋࡊ࡚࠺ࠊࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡦࡸࡴ࠰ࡳࡸࡥࡱ࡯ࡴࡺ࠱࠷ࡏࠪ࠸࠰ࡃ࡮ࡸࡖࡦࡿࠊࠣࠤࠥፄ")
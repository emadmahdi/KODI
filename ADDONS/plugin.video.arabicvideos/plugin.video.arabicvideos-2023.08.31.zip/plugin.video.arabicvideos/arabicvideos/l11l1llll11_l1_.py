# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ晊")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠ࡛ࡔࡘࡤ࠭晋")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ晌"),l11ll1_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ晍"),l11ll1_l1_ (u"ࠪฮุา๊ๅࠩ晎"),l11ll1_l1_ (u"ࠫฯูฬ๋ๆࠣห้ีฮ้ๆࠪ晏"),l11ll1_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩ晐")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l11111_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l1llll1_l1_(url,text)
	elif mode==664: results = l1l111_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ晑"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ晒"),l11ll1_l1_ (u"ࠨࠩ晓"),l11ll1_l1_ (u"ࠩࠪ晔"),l11ll1_l1_ (u"ࠪࠫ晕"),l11ll1_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ晖"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ晗"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭晘"),l11ll1_l1_ (u"ࠧࠨ晙"),669,l11ll1_l1_ (u"ࠨࠩ晚"),l11ll1_l1_ (u"ࠩࠪ晛"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ晜"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ晝"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ晞"),l11ll1_l1_ (u"࠭ࠧ晟"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ晠"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ晡")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊๋๊ำหࠪ晢"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠪࠫ晣"),l11ll1_l1_ (u"ࠫࠬ晤"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ晥"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭晦"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ晧")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ晨"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠩࠪ晩"),l11ll1_l1_ (u"ࠪࠫ晪"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ晫"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ晬"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ晭")+l111l1_l1_+l11ll1_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭普"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠨࠩ景"),l11ll1_l1_ (u"ࠩࠪ晰"),l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ晱"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ晲"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ晳")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪ晴"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠧࠨ晵"),l11ll1_l1_ (u"ࠨࠩ晶"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ晷"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ晸"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ晹"),l11ll1_l1_ (u"ࠬ࠭智"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ晻"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ晼"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ晽"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ晾")+l111l1_l1_+title,l1lllll_l1_,664)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ晿"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ暀"),l11ll1_l1_ (u"ࠬ࠭暁"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ暂"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ暃"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠨࠩ暄"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ暅"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = title.replace(l11ll1_l1_ (u"ࠪࡀࡧࡄࠧ暆"),l11ll1_l1_ (u"ࠫࠬ暇")).replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡣࡀࠪ暈"),l11ll1_l1_ (u"࠭ࠧ暉")).replace(l11ll1_l1_ (u"ࠧ࠽ࡤࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡸࡥࡵࠤࡁࠫ暊"),l11ll1_l1_ (u"ࠨࠩ暋")).replace(l11ll1_l1_ (u"ࠩ࠿ࡦࡃ࠭暌"),l11ll1_l1_ (u"ࠪࠫ暍")).strip(l11ll1_l1_ (u"ࠫࠥ࠭暎"))
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ暏"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ暐")+l111l1_l1_+title,l1lllll_l1_,664)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ暑"),url,l11ll1_l1_ (u"ࠨࠩ暒"),l11ll1_l1_ (u"ࠩࠪ暓"),l11ll1_l1_ (u"ࠪࠫ暔"),l11ll1_l1_ (u"ࠫࠬ暕"),l11ll1_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ暖"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ暗"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ暘"),l11ll1_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ暙"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭暚"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠪࠫ暛"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ暜"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ暝"),l11ll1_l1_ (u"࠭ࠧ暞"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ暟"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣࠫ暠")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ暡"),l111l1_l1_+title,l1lllll_l1_,661)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ暢"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭暣"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ暤"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭暥"),l11ll1_l1_ (u"ࠧࠨ暦"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ暧"),l111l1_l1_+title,l1lllll_l1_,661)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠩࠪ暨")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ暩"),l11ll1_l1_ (u"ࠫࠬ暪"),request,url)
	if request==l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ暫"):
		url,search = url.split(l11ll1_l1_ (u"࠭࠿ࠨ暬"),1)
		data = l11ll1_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭暭")+search
		headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ暮"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ暯")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ暰"),url,data,headers,l11ll1_l1_ (u"ࠫࠬ暱"),l11ll1_l1_ (u"ࠬ࠭暲"),l11ll1_l1_ (u"࡙࠭ࡂࡓࡒࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ暳"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ暴"),url,l11ll1_l1_ (u"ࠨࠩ暵"),l11ll1_l1_ (u"ࠩࠪ暶"),l11ll1_l1_ (u"ࠪࠫ暷"),l11ll1_l1_ (u"ࠫࠬ暸"),l11ll1_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ暹"))
	html = response.content
	block,items = l11ll1_l1_ (u"࠭ࠧ暺"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ暻"))
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭暼"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ暽"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠪࠫ暾"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭暿"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭曀"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ曁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ曂"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ曃"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ曄"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ曅"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭曆"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ曇"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"࠭ࠧ曈"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ曉"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ曊"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩ曋"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ曌"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪ曍"),l11ll1_l1_ (u"้ࠬไ๋สࠪ曎"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ曏"),l11ll1_l1_ (u"่ࠧัสๅࠬ曐"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ曑"),l11ll1_l1_ (u"ࠩ฼ี฻࠭曒"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ曓"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ曔"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬ曕")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		title = title.replace(l11ll1_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠡࠩ曖"),l11ll1_l1_ (u"ࠧࠨ曗")).replace(l11ll1_l1_ (u"ࠨษ๋๊้อ๊็ࠢࠪ曘"),l11ll1_l1_ (u"ࠩࠪ曙")).replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠣࠫ曚"),l11ll1_l1_ (u"ࠫࠬ曛"))
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ曜"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ曝") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ曞")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ曟"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ曠") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ曡")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭曢"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ曣"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ曤"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭曥"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ曦"):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ曧"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ曨") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ曩"),l111l1_l1_+title,l1lllll_l1_,663,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ曪") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曫"),l111l1_l1_+title,l1lllll_l1_,661,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ曬"),l111l1_l1_+title,l1lllll_l1_,663,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ曭"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ曮")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ曯"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ曰"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧ曱"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ曲")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ曳"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ更"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ曵")+title,l1lllll_l1_,661)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ曶"),l11ll1_l1_ (u"ࠫࠬ曷"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ書"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ曹"),url,l11ll1_l1_ (u"ࠧࠨ曺"),l11ll1_l1_ (u"ࠨࠩ曻"),l11ll1_l1_ (u"ࠩࠪ曼"),l11ll1_l1_ (u"ࠪࠫ曽"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ曾"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ替"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ最"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ朁")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭朂"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩࠦࠫ會"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ朄"),l111l1_l1_+title,url,663,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ朅"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭朆")+l1l1l_l1_+l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ朇"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ月"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		#if not items: items = re.findall(l11ll1_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ有"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ朊")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠲࠴࠭朋"))
			title = title.replace(l11ll1_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ朌"),l11ll1_l1_ (u"ࠬࠦࠧ服"))
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ朎"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ朏"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭朐") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ朑")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ朒"))
		#		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ朓"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l111_l1_,l1lll1ll_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ朔"),l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ朕"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ朖"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ朗"),l11ll1_l1_ (u"ࠩࠪ朘"),l11ll1_l1_ (u"ࠪࠫ朙"),l11ll1_l1_ (u"ࠫࠬ朚"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ望"))
	html = response.content
	# l1l111l11_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ朜"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭朝"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l111_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ朞"))
			l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ期"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ朠"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ朡")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭朢"))
				l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࠧࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ࠰ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰ࡳ࡬ࡵ࠭ࠩࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠷࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡵࡳ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍࠎࠏ࡮ࡢ࡯ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ朣")
	l1111l_l1_ = zip(l1llll_l1_,l1l11l111_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1lll1ll_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ朤"),l1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ朥"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ朦"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ朧"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭木"),l11ll1_l1_ (u"ࠬ࠱ࠧ朩"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ未")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ末"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ本")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ札"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᬄ")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡆࡑࡓࡥࠧᬅ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠩๅหห๋ส๋ࠩᬆ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l111_l1_(url)
	elif mode==302: results = l11111_l1_(url)
	elif mode==303: results = l1lll1ll11_l1_(url)
	elif mode==304: results = l1llll11_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll1l111l_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᬇ"),l111l1_l1_+l11ll1_l1_ (u"้๋ࠫวัษࠣห้๋่ใ฻ࠣฬ฼๐มࠨᬈ"),l11ll1_l1_ (u"ࠬ࠭ᬉ"),306)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᬊ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᬋ"),l11ll1_l1_ (u"ࠨࠩᬌ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᬍ"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᬎ"),l11ll1_l1_ (u"ࠫࠬᬏ"),309,l11ll1_l1_ (u"ࠬ࠭ᬐ"),l11ll1_l1_ (u"࠭ࠧᬑ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᬒ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᬓ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᬔ"),l11ll1_l1_ (u"ࠪࠫᬕ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᬖ"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᬗ"),l11ll1_l1_ (u"࠭ࠧᬘ"),l11ll1_l1_ (u"ࠧࠨᬙ"),l11ll1_l1_ (u"ࠨࠩᬚ"),l11ll1_l1_ (u"ࠩࠪᬛ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᬜ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬᬝ"),html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨࡦࡣࡧࡩࡷࡄࠧᬞ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᬟ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		#l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩᬠ"))
		#if title==l11ll1_l1_ (u"ࠨำฺ่ฬ์ࠧᬡ"): l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴ืๅืษ้࠳ࠬᬢ")
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᬣ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᬤ")+l111l1_l1_+title,l1lllll_l1_,301)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᬥ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᬦ"),l11ll1_l1_ (u"ࠧࠨᬧ"),9999)
	l1l111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᬨ"),html)
	return html
def l1ll1l111l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᬩ"),l11ll1_l1_ (u"ࠪࠫᬪ"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᬫ"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠥฮื๋ร้๋ࠣࠦวๅ็ุำึࠦ࠮࠯ࠢหือฮࠠใ์ส้ࠥษีฮษหࠤฬ๊ๅ้ไ฼ࠤอะิโ์ิࠤ๊ำส้์สฮࠥาๅ๋฻ูࠣๆำวหࠢส่๊๎โฺࠢ࠱࠲ࠥ๎วๅ๊ๅฮࠥอไืษษ฽ࠥ๐ะ่สࠣๅ๏ࠦๅฺษ็ะฮࠦสีใํีࠥอไึใะหฯࠦวๅ็ืๅึฯࠠใส็ࠤ฾ืึࠡ็ะฮํ๐วห้สࠤๆ๐ࠠใ๊สส๊ࠦ็ัษࠣห้ฮั็ษ่ะࠬᬬ"))
	return
def l1l111_l1_(url,html=l11ll1_l1_ (u"࠭ࠧᬭ")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᬮ"),url,l11ll1_l1_ (u"ࠨࠩᬯ"),l11ll1_l1_ (u"ࠩࠪᬰ"),l11ll1_l1_ (u"ࠪࠫᬱ"),l11ll1_l1_ (u"ࠫࠬᬲ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᬳ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱࠮ࡄࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿᬴ࠫࠪ"),html,re.DOTALL)
	if l1l1l11_l1_:
		for block in l1l1l11_l1_:
			seq += 1
			items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱ࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᬵ"),block,re.DOTALL)
			for title,test,l1lllll_l1_ in items:
				title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪᬶ"))
				if title==l11ll1_l1_ (u"ࠩࠪᬷ"): title = l11ll1_l1_ (u"ࠪฬํ๎่้๊ࠪᬸ")
				if l11ll1_l1_ (u"ࠫࡪࡳ࠾࠽ࡣࠪᬹ") not in test:
					if block.count(l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᬺ"))>0:
						l1ll1l1111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᬻ"),block,re.DOTALL)
						for l1lllll_l1_ in l1ll1l1111_l1_:
							title = l1lllll_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩᬼ"))[-2]
							addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬽ"),l111l1_l1_+title,l1lllll_l1_,301)
						continue
					else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ᬾ")+str(seq)
				#l1111llll_l1_ = [l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤࠬᬿ"),l11ll1_l1_ (u"ࠫฬ็ไศ็ࠣࠫᭀ"),l11ll1_l1_ (u"ࠬฮัศ็ฯࠫᭁ"),l11ll1_l1_ (u"ู࠭าู๊ࠫᭂ"),l11ll1_l1_ (u"ࠧไๆํฬฬะࠧᭃ"),l11ll1_l1_ (u"ࠨษ฽ห๋๏᭄ࠧ")]
				#if any(value in title for value in l1111llll_l1_):
				if not any(value in title for value in l1l11l_l1_):
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᭅ"),l111l1_l1_+title,l1lllll_l1_,302)
	else: l11111_l1_(url,html)
	return
def l11111_l1_(url,html=l11ll1_l1_ (u"ࠪࠫᭆ")):
	if html==l11ll1_l1_ (u"ࠫࠬᭇ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᭈ"),url,l11ll1_l1_ (u"࠭ࠧᭉ"),l11ll1_l1_ (u"ࠧࠨᭊ"),l11ll1_l1_ (u"ࠨࠩᭋ"),l11ll1_l1_ (u"ࠩࠪᭌ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ᭍"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11ll1_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨ᭎") in url:
		url,seq = url.split(l11ll1_l1_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩ᭏"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱࠮ࡄࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠫࠪ᭐"),html,re.DOTALL)
		block = l1l1l11_l1_[int(seq)-1]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡱࡧࡽࡃ࠭᭑"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᭒"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,data,l1lll1_l1_ in items:
		title = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠴ࠪࡀ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡭࠿ࠩ᭓"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭᭔"),l11ll1_l1_ (u"ࠫࠬ᭕")).strip(l11ll1_l1_ (u"ࠬࠦࠧ᭖"))
		if not title or title==l11ll1_l1_ (u"࠭ࠧ᭗"):
			title = re.findall(l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠾࠯ࠬࡂࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᭘"),data,re.DOTALL)
			if title: title = title[0].replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ᭙"),l11ll1_l1_ (u"ࠩࠪ᭚")).strip(l11ll1_l1_ (u"ࠪࠤࠬ᭛"))
			if not title or title==l11ll1_l1_ (u"ࠫࠬ᭜"):
				title = re.findall(l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᭝"),data,re.DOTALL)
				title = title[0].replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ᭞"),l11ll1_l1_ (u"ࠧࠨ᭟")).strip(l11ll1_l1_ (u"ࠨࠢࠪ᭠"))
		title = unescapeHTML(title)
		#if title==l11ll1_l1_ (u"ࠩࠪ᭡"): continue
		if title not in l11l_l1_:
			l11l_l1_.append(title)
			l111l_l1_ = l1lllll_l1_+data+l1lll1_l1_
			if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ᭢") in l111l_l1_ or l11ll1_l1_ (u"ู๊ࠫไิๆࠪ᭣") in l111l_l1_ or l11ll1_l1_ (u"ࠬࠨࡥࡱ࡫ࡶࡳࡩ࡫ࠢࠨ᭤") in l111l_l1_:
				if l11ll1_l1_ (u"࠭ศาษ่ะࠬ᭥") in data: title = l11ll1_l1_ (u"ࠧษำ้ห๊าࠠࠨ᭦")+title
				elif l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ᭧") in data or l11ll1_l1_ (u"่ࠩ์ุ๋ࠧ᭨") in data: title = l11ll1_l1_ (u"ุ้๊ࠪำๅࠢࠪ᭩")+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᭪"),l111l1_l1_+title,l1lllll_l1_,303,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᭫"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿᭬ࠩ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᭭"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᭮"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ᭯")+title,l1lllll_l1_,302)
	return
def l1lll1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ᭰"),url,l11ll1_l1_ (u"ࠫࠬ᭱"),l11ll1_l1_ (u"ࠬ࠭᭲"),l11ll1_l1_ (u"࠭ࠧ᭳"),l11ll1_l1_ (u"ࠧࠨ᭴"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧ᭵"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿ࠩ᭶"),html,re.DOTALL)
	name = name[0].replace(l11ll1_l1_ (u"ࠪࢀู๊ࠥๆษ๊ࠣฬ๎ࠧ᭷"),l11ll1_l1_ (u"ࠫࠬ᭸")).replace(l11ll1_l1_ (u"ࠬࡉࡩ࡮ࡣࠣࡒࡴࡽࠧ᭹"),l11ll1_l1_ (u"࠭ࠧ᭺")).strip(l11ll1_l1_ (u"ࠧࠡࠩ᭻")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ᭼"),l11ll1_l1_ (u"ࠩࠣࠫ᭽"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ᭾"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᭿"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠬࠦࠧᮀ")+title.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩᮁ"),l11ll1_l1_ (u"ࠧࠨᮂ")).strip(l11ll1_l1_ (u"ࠨࠢࠪᮃ"))
				title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬᮄ"),l11ll1_l1_ (u"ࠪࠫᮅ")).strip(l11ll1_l1_ (u"ࠫࠥ࠭ᮆ"))
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᮇ"),l111l1_l1_+title,l1lllll_l1_,304)
		else: l1llll11_l1_(url)
	return
def l1llll11_l1_(url):
	if l11ll1_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨᮈ") not in url: url = url.strip(l11ll1_l1_ (u"ࠧ࠰ࠩᮉ"))+l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡪࡰࡪࠫᮊ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᮋ"),url,l11ll1_l1_ (u"ࠪࠫᮌ"),l11ll1_l1_ (u"ࠫࠬᮍ"),l11ll1_l1_ (u"ࠬ࠭ᮎ"),l11ll1_l1_ (u"࠭ࠧᮏ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᮐ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠨࠩᮑ"),html)
	if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫᮒ") not in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᮓ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᮔ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨᮕ"),l11ll1_l1_ (u"࠭ࠧᮖ")).strip(l11ll1_l1_ (u"ࠧࠡࠩᮗ"))
			title = l11ll1_l1_ (u"ࠨษ็ั้่ษࠡࠩᮘ")+title
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᮙ"),l111l1_l1_+title,l1lllll_l1_,305)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡩ࡫ࡴࡢ࡫࡯ࡷࠧ࠮࠮ࠫࡁࠬࠦࡷ࡫࡬ࡢࡶࡨࡨࠧ࠭ᮚ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᮛ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨᮜ"),l11ll1_l1_ (u"࠭ࠧᮝ")).strip(l11ll1_l1_ (u"ࠧࠡࠩᮞ"))
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᮟ"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	return
def PLAY(url):
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠦ࡬ࡹࡳ࡬ࠡ࠿ࠣࡈࡊࡉࡏࡅࡇࡢࡅࡉࡏࡌࡃࡑࡢࡌ࡙ࡓࡌࠩࡪࡷࡱࡱ࠯ࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡫࡭ࡳ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯࠭ࠏࠏࡣࡰࡱ࡮࡭ࡪࡹࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡯࡬࡫ࡨࡷ࠳࡭ࡥࡵࡡࡧ࡭ࡨࡺࠨࠪࠌࠌࡔࡍࡖࡓࡆࡕࡖࡍࡉࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡔࡍࡖࡓࡆࡕࡖࡍࡉ࠭࡝ࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡩࡴࡨࡪࠥࡃࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣ࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯ࡠ࠶࡝ࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࠼ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࡇࡴࡵ࡫ࡪࡧࠪ࠾ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄ࠾ࠩ࠮ࡔࡍࡖࡓࡆࡕࡖࡍࡉࢃࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ࠭ࠏࠏࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡈࡊࡉࡏࡅࡇࡢࡅࡉࡏࡌࡃࡑࡢࡌ࡙ࡓࡌࠩࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠯ࠊࠊࠥࡤࡨࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢࡢࡦࠥࠤࡹࡧࡲࡨࡧࡷࡁࠧࡥࡢ࡭ࡣࡱ࡯ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡥࡩࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡡࡥࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍࠨࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡤࡨࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ࠯ࠊࠊࠥࡤࡨࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠦࡥࡩࡥࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬࡦࡪ࡟ࡩࡶࡰࡰ࠮ࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤࡣࡶࡱࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡪࡩࡴࡲ࡯ࡥࡾࡀࠠ࡯ࡱࡱࡩࡀࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟ࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࡜࠲ࡠ࠯ࠬ࠵ࠧࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࠼ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡢ࠯ࡥ࡬ࡱࡦࡼࡩࡥࡵ࠱ࡰ࡮ࡼࡥ࠰ࠩࢀࠎࠎࠨࠢࠣᮠ")
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩ࡫ࡱ࡫࠴࠭ᮡ")
	#server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨᮢ"))
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᮣ"):None,l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᮤ"):server}
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᮥ"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩᮦ"),l11ll1_l1_ (u"ࠩࠪᮧ"),l11ll1_l1_ (u"ࠪࠫᮨ"),l11ll1_l1_ (u"ࠫࠬᮩ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ᮪"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l111lll_l1_ = l1ll1l1l11_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭࡬ࡰࡹࡨࡶ᮫ࠬ"))
	#html = l1ll1l11l1_l1_(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᮬ"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩᮭ"),l11ll1_l1_ (u"ࠩࠪᮮ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠹ࡸ࡭࠭ᮯ"))
	#if html and kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ᮰"))
	#html = DECODE_ADILBO_HTML(html)
	l1llll_l1_ = []
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᮱"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᮲"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ᮳"),l11ll1_l1_ (u"ࠨࠩ᮴")).strip(l11ll1_l1_ (u"ࠩࠣࠫ᮵"))
			l111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ᮶"),title,re.DOTALL)
			if l111lll1_l1_:
				l111lll1_l1_ = l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ᮷")+l111lll1_l1_[0]
				#title = l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭᮸")
				title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ᮹"))
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠧࠨᮺ")
			l1lllll111_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᮻ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᮼ")+l111lll1_l1_
			l1llll_l1_.append(l1lllll111_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡼࡧࡴࡤࡪࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᮽ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l11_l1_ l11l1l1l1_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠵࠯࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪᮾ"),block,re.DOTALL)
		for l1lllll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᮿ")+l1lllll_l1_
			title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫᯀ"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᯁ")+title+l11ll1_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩᯂ")
			l1llll_l1_.append(l1lllll_l1_)
		# l1ll1l11ll_l1_ l11l1l1l1_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡤ࡮ࡦࡾ࡜ࠩࡽࡸࡶࡱࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᯃ"),html,re.DOTALL)
		if l1l1_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡱࡨࡪࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬᯄ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧᯅ"),l11ll1_l1_ (u"ࠬ࠭ᯆ")).strip(l11ll1_l1_ (u"࠭ࠠࠨᯇ"))
				title = title.replace(l11ll1_l1_ (u"ࠧࡄ࡫ࡰࡥࠥࡔ࡯ࡸࠩᯈ"),l11ll1_l1_ (u"ࠨࡅ࡬ࡱࡦࡔ࡯ࡸࠩᯉ"))
				l1lllll_l1_ = l1l1_l1_[0]+l11ll1_l1_ (u"ࠩࡂࡥࡨࡺࡩࡰࡰࡀࡷࡼ࡯ࡴࡤࡪࠩ࡭ࡳࡪࡥࡹ࠿ࠪᯊ")+index+l11ll1_l1_ (u"ࠪࠪ࡮ࡪ࠽ࠨᯋ")+id+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᯌ")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᯍ")
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᯎ"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᯏ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩᯐ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪᯑ"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬᯒ"),l11ll1_l1_ (u"ࠫ࠰࠭ᯓ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪᯔ")+search
	l11111_l1_(url)
	return
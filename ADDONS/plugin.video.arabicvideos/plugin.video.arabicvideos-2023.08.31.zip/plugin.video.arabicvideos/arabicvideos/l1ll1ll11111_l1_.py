# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘࠪ㹍")
l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㹎")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11ll1_l1_ (u"ࠬ࠶ࠧ㹏"),True)
	elif mode==102: results = ITEMS(l11ll1_l1_ (u"࠭࠱ࠨ㹐"),True)
	elif mode==103: results = ITEMS(l11ll1_l1_ (u"ࠧ࠳ࠩ㹑"),True)
	elif mode==104: results = ITEMS(l11ll1_l1_ (u"ࠨ࠵ࠪ㹒"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11ll1_l1_ (u"ࠩ࠷ࠫ㹓"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㹔"),l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ㹕")+l11ll1_l1_ (u"๊ࠬไๆึอี่๐ๆࠡสัำ๊ฯࠠࡎ࠵ࡘࠫ㹖"),l11ll1_l1_ (u"࠭ࠧ㹗"),710)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㹘"),l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧ㹙")+l11ll1_l1_ (u"ࠩ็ฺ่๊สาๅํ๊ࠥฮฮะ็ฬࠤࡎࡖࡔࡗࠩ㹚"),l11ll1_l1_ (u"ࠪࠫ㹛"),230)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㹜"),l11ll1_l1_ (u"ࠬࡥࡔࡗ࠲ࡢࠫ㹝")+l11ll1_l1_ (u"࠭โ็๊สฮ๋ࠥๆࠡ็๋ห็฿็ศࠢส่ศ฻ไ๋หࠪ㹞"),l11ll1_l1_ (u"ࠧࠨ㹟"),101)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㹠"),l11ll1_l1_ (u"ࠩࡢࡘ࡛࠺࡟ࠨ㹡")+l11ll1_l1_ (u"ࠪๆ๋๎วห่ࠢาฯอัส่๊ࠢࠥ๐่ห์๋ฬࠬ㹢"),l11ll1_l1_ (u"ࠫࠬ㹣"),106)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㹤"),l11ll1_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ㹥")+l11ll1_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㹦"),l11ll1_l1_ (u"ࠨࠩ㹧"),147)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㹨"),l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ㹩")+l11ll1_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㹪"),l11ll1_l1_ (u"ࠬ࠭㹫"),148)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㹬"),l11ll1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭㹭")+l11ll1_l1_ (u"ࠨࠢࠣๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠥࠦࠧ㹮"),l11ll1_l1_ (u"ࠩࠪ㹯"),28)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㹰"),l11ll1_l1_ (u"ࠫࡤࡓࡒࡇࡡࠪ㹱")+l11ll1_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ㹲"),l11ll1_l1_ (u"࠭ࠧ㹳"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㹴"),l11ll1_l1_ (u"ࠨࡡࡎ࡛࡙ࡥࠧ㹵")+l11ll1_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ㹶"),l11ll1_l1_ (u"ࠪࠫ㹷"),135)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㹸"),l11ll1_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ㹹")+l11ll1_l1_ (u"࠭โ็ษฬࠤ์๊วࠡ็้ࠤ๊๎โฺࠢหห๋๐สࠨ㹺"),l11ll1_l1_ (u"ࠧࠨ㹻"),38)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㹼"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㹽"),l11ll1_l1_ (u"ࠪࠫ㹾"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㹿"),l11ll1_l1_ (u"ࠬࡥࡔࡗ࠳ࡢࠫ㺀")+l11ll1_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡ฻ส้ฮ࠭㺁"),l11ll1_l1_ (u"ࠧࠨ㺂"),102)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㺃"),l11ll1_l1_ (u"ࠩࡢࡘ࡛࠸࡟ࠨ㺄")+l11ll1_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอࠥิวึหࠪ㺅"),l11ll1_l1_ (u"ࠫࠬ㺆"),103)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺇"),l11ll1_l1_ (u"࠭࡟ࡕࡘ࠶ࡣࠬ㺈")+l11ll1_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ็่ๆำีࠨ㺉"),l11ll1_l1_ (u"ࠨࠩ㺊"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡘ࡛࠭㺋")+menu+l11ll1_l1_ (u"ࠪࡣࠬ㺌")
	client = l1l11l1l11l_l1_(32)
	payload = {l11ll1_l1_ (u"ࠫ࡮ࡪࠧ㺍"):l11ll1_l1_ (u"ࠬ࠭㺎"),l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㺏"):client,l11ll1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㺐"):l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㺑"),l11ll1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㺒"):menu}
	#data = l1ll1l111_l1_(payload)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㺓"),str(payload))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㺔"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ㺕"), l11l1l_l1_, payload, l11ll1_l1_ (u"࠭ࠧ㺖"), True,l11ll1_l1_ (u"ࠧࠨ㺗"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ㺘"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㺙"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠪࠫ㺚"),l11ll1_l1_ (u"ࠫࠬ㺛"),l11ll1_l1_ (u"ࠬ࠭㺜"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㺝"))
	html = response.content
	#html = html.replace(l11ll1_l1_ (u"ࠧ࡝ࡴࠪ㺞"),l11ll1_l1_ (u"ࠨࠩ㺟"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㺠"),l11ll1_l1_ (u"ࠪࠫ㺡"),html,html)
	#file = open(l11ll1_l1_ (u"ࠫࡸࡀ࠯ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ㺢"), l11ll1_l1_ (u"ࠬࡽࠧ㺣"))
	#file.write(html)
	#file.close()
	items = re.findall(l11ll1_l1_ (u"࠭ࠨ࡜ࡠ࠾ࡠࡷࡢ࡮࡞࠭ࡂ࠭ࡀࡁࠨ࠯ࠬࡂ࠭ࡀࡁࠨ࠯ࠬࡂ࠭ࡀࡁࠨ࠯ࠬࡂ࠭ࡀࡁࠨ࠯ࠬࡂ࠭ࡀࡁࠧ㺤"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11ll1_l1_ (u"ࠧࡢ࡮ࠪ㺥"),l11ll1_l1_ (u"ࠨࡃ࡯ࠫ㺦"))
			start = start.replace(l11ll1_l1_ (u"ࠩࡈࡰࠬ㺧"),l11ll1_l1_ (u"ࠪࡅࡱ࠭㺨"))
			start = start.replace(l11ll1_l1_ (u"ࠫࡆࡒࠧ㺩"),l11ll1_l1_ (u"ࠬࡇ࡬ࠨ㺪"))
			start = start.replace(l11ll1_l1_ (u"࠭ࡅࡍࠩ㺫"),l11ll1_l1_ (u"ࠧࡂ࡮ࠪ㺬"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11ll1_l1_ (u"ࠨࡃ࡯࠱ࠬ㺭"),l11ll1_l1_ (u"ࠩࡄࡰࠬ㺮"))
			start = start.replace(l11ll1_l1_ (u"ࠪࡅࡱࠦࠧ㺯"),l11ll1_l1_ (u"ࠫࡆࡲࠧ㺰"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1l11_l1_,name,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠬࠩࠧ㺱") in source: continue
			#if source in [l11ll1_l1_ (u"࠭ࡎࡕࠩ㺲"),l11ll1_l1_ (u"࡚ࠧࡗࠪ㺳"),l11ll1_l1_ (u"ࠨ࡙ࡖ࠴ࠬ㺴"),l11ll1_l1_ (u"ࠩࡕࡐ࠶࠭㺵"),l11ll1_l1_ (u"ࠪࡖࡑ࠸ࠧ㺶")]: continue
			if source!=l11ll1_l1_ (u"࡚ࠫࡘࡌࠨ㺷"): name = name+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡࠢࠣࠫ㺸")+source+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㺹")
			url = source+l11ll1_l1_ (u"ࠧ࠼࠽ࠪ㺺")+server+l11ll1_l1_ (u"ࠨ࠽࠾ࠫ㺻")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠩ࠾࠿ࠬ㺼")+menu
			addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㺽"),l111l1_l1_+l11ll1_l1_ (u"ࠫࠬ㺾")+name,url,105,l1lll1_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㺿"),l111l1_l1_+l11ll1_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㻀"),l11ll1_l1_ (u"ࠧࠨ㻁"),9999)
		#if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㻂"),l11ll1_l1_ (u"ࠩࠪ㻃"),l11ll1_l1_ (u"ࠪࠫ㻄"),l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㻅"))
		#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㻆"),l111l1_l1_+l11ll1_l1_ (u"࠭ไๅลึๅ๊ࠥวࠡฬ๋ะิࠦโ็๊สฮࠥะไโิ๋๊๏ฯࠠๅๅࠪ㻇"),l11ll1_l1_ (u"ࠧࠨ㻈"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㻉"),l111l1_l1_+l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไศไิฬฬว้ࠠษ็หฺีโศรࠣๅ็฽ࠧ㻊"),l11ll1_l1_ (u"ࠪࠫ㻋"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㻌"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㻍"),l11ll1_l1_ (u"࠭ࠧ㻎"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㻏"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡗࡱࡪࡴࡸࡴࡶࡰࡤࡸࡪࡲࡹ࠭ࠢࡱࡳ࡚ࠥࡖࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡪࡴࡸࠠࡺࡱࡸࠫ㻐"),l11ll1_l1_ (u"ࠩࠪ㻑"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㻒"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡎࡺࠠࡪࡵࠣࡪࡴࡸࠠࡳࡧ࡯ࡥࡹ࡯ࡶࡦࡵࠣࠪࠥ࡬ࡲࡪࡧࡱࡨࡸࠦ࡯࡯࡮ࡼࠫ㻓"),l11ll1_l1_ (u"ࠬ࠭㻔"),9999)
	return
def PLAY(id):
	source,server,l11lll1l11_l1_,menu = id.split(l11ll1_l1_ (u"࠭࠻࠼ࠩ㻕"))
	url = l11ll1_l1_ (u"ࠧࠨ㻖")
	if source==l11ll1_l1_ (u"ࠨࡗࡕࡐࠬ㻗"): url = l11lll1l11_l1_
	elif source==l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㻘"):
		url = l1l1lll_l1_[l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㻙")][0]+l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ㻚")+l11lll1l11_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㻛"),url)
		return
	elif source==l11ll1_l1_ (u"࠭ࡇࡂࠩ㻜"):
		payload = { l11ll1_l1_ (u"ࠧࡪࡦࠪ㻝") : l11ll1_l1_ (u"ࠨࠩ㻞"), l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㻟") : l1l11l1l11l_l1_(32) , l11ll1_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㻠") : l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠵ࠬ㻡") , l11ll1_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㻢") : l11ll1_l1_ (u"࠭ࠧ㻣") }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㻤"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠨࠩ㻥"),False,l11ll1_l1_ (u"ࠩࠪ㻦"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㻧"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㻨"),l11ll1_l1_ (u"ࠬ࠭㻩"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㻪"),l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㻫"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l11l11l1l1_l1_ = cookies[l11ll1_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࠬ㻬")]
		url = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㻭")]
		payload = { l11ll1_l1_ (u"ࠪ࡭ࡩ࠭㻮") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㻯") : l1l11l1l11l_l1_(32) , l11ll1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㻰") : l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠸ࠧ㻱") , l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㻲") : l11ll1_l1_ (u"ࠨࠩ㻳") }
		headers = { l11ll1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ㻴") : l11ll1_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪ࠽ࠨ㻵")+l1l11l11l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㻶"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠬ࠭㻷"),l11ll1_l1_ (u"࠭ࠧ㻸"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㻹"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㻺"),l11ll1_l1_ (u"ࠩࠪ㻻"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㻼"),l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㻽"))
			return
		html = response.content
		url = re.findall(l11ll1_l1_ (u"ࠬࡸࡥࡴࡲࠥ࠾ࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅ࡭࠴ࡷ࠻࠭࠭࠴ࠪࡀࠫࠥࠫ㻾"),html,re.DOTALL)
		l1lllll_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㻿"),l11ll1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠠࠨ㼀")+l1lllll_l1_)
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㼁"),l11ll1_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬࠢࠪ㼂")+params)
		l1l11l11l11l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠷࠽࠴ࠧ㼃")+server+l11ll1_l1_ (u"ࠫ࠼࠽࠷࠰ࠩ㼄")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠬࡥࡈࡅ࠰ࡰ࠷ࡺ࠾ࠧ㼅")+params
		l1l11l11l111_l1_ = l1l11l11l11l_l1_.replace(l11ll1_l1_ (u"࠭࠳࠷࠼࠺ࠫ㼆"),l11ll1_l1_ (u"ࠧ࠵࠲࠽࠻ࠬ㼇")).replace(l11ll1_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㼈"),l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㼉"))
		l1l11l11l1ll_l1_ = l1l11l11l11l_l1_.replace(l11ll1_l1_ (u"ࠪ࠷࠻ࡀ࠷ࠨ㼊"),l11ll1_l1_ (u"ࠫ࠹࠸࠺࠸ࠩ㼋")).replace(l11ll1_l1_ (u"ࠬࡥࡈࡅ࠰ࡰ࠷ࡺ࠾ࠧ㼌"),l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㼍"))
		l1lll111_l1_ = [l11ll1_l1_ (u"ࠧࡉࡆࠪ㼎"),l11ll1_l1_ (u"ࠨࡕࡇ࠵ࠬ㼏"),l11ll1_l1_ (u"ࠩࡖࡈ࠷࠭㼐")]
		l1llll_l1_ = [l1l11l11l11l_l1_,l1l11l11l111_l1_,l1l11l11l1ll_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ㼑"), l1lll111_l1_)
		if l1l_l1_ == -1: return
		else: url = l1llll_l1_[l1l_l1_]
	elif source==l11ll1_l1_ (u"ࠫࡓ࡚ࠧ㼒"):
		headers = { l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㼓") : l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ㼔") }
		payload = { l11ll1_l1_ (u"ࠧࡪࡦࠪ㼕") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠨࡷࡶࡩࡷ࠭㼖") : l1l11l1l11l_l1_(32) , l11ll1_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㼗") : l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡏࡖࠪ㼘") , l11ll1_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㼙") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ㼚"), l11l1l_l1_, payload, headers, False,l11ll1_l1_ (u"࠭ࠧ㼛"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㼜"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㼝"),l11ll1_l1_ (u"ࠩࠪ㼞"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㼟"),l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㼠"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㼡")]
		url = url.replace(l11ll1_l1_ (u"࠭ࠥ࠳࠲ࠪ㼢"),l11ll1_l1_ (u"ࠧࠡࠩ㼣"))
		url = url.replace(l11ll1_l1_ (u"ࠨࠧ࠶ࡈࠬ㼤"),l11ll1_l1_ (u"ࠩࡀࠫ㼥"))
		if l11ll1_l1_ (u"ࠪࡐࡪࡧࡲ࡯ࠩ㼦") in l11lll1l11_l1_:
			url = url.replace(l11ll1_l1_ (u"ࠫࡓ࡚ࡎࡏ࡫࡯ࡩࠬ㼧"),l11ll1_l1_ (u"ࠬ࠭㼨"))
			url = url.replace(l11ll1_l1_ (u"࠭࡬ࡦࡣࡵࡲ࡮ࡴࡧ࠲ࠩ㼩"),l11ll1_l1_ (u"ࠧࡍࡧࡤࡶࡳ࡯࡮ࡨࠩ㼪"))
	elif source==l11ll1_l1_ (u"ࠨࡒࡏࠫ㼫"):
		#headers = { l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㼬") : l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㼭") }
		payload = { l11ll1_l1_ (u"ࠫ࡮ࡪࠧ㼮") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࠪ㼯") : l1l11l1l11l_l1_(32) , l11ll1_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㼰") : l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽࡕࡒࠧ㼱") , l11ll1_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㼲") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㼳"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠪࠫ㼴"),False,l11ll1_l1_ (u"ࠫࠬ㼵"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ㼶"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㼷"),l11ll1_l1_ (u"ࠧࠨ㼸"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㼹"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㼺"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㼻")]
		headers = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㼼"):response.headers[l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㼽")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㼾"),url, l11ll1_l1_ (u"ࠧࠨ㼿"),headers , l11ll1_l1_ (u"ࠨࠩ㽀"),l11ll1_l1_ (u"ࠩࠪ㽁"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬ㽂"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㽃"),l11ll1_l1_ (u"ࠬ࠭㽄"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㽅"),l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㽆"))
			return
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㽇"),html,re.DOTALL)
		url = items[0]
	elif source in [l11ll1_l1_ (u"ࠩࡗࡅࠬ㽈"),l11ll1_l1_ (u"ࠪࡊࡒ࠭㽉"),l11ll1_l1_ (u"ࠫ࡞࡛ࠧ㽊"),l11ll1_l1_ (u"ࠬ࡝ࡓ࠲ࠩ㽋"),l11ll1_l1_ (u"࠭ࡗࡔ࠴ࠪ㽌"),l11ll1_l1_ (u"ࠧࡓࡎ࠴ࠫ㽍"),l11ll1_l1_ (u"ࠨࡔࡏ࠶ࠬ㽎")]:
		if source==l11ll1_l1_ (u"ࠩࡗࡅࠬ㽏"): l11lll1l11_l1_ = id
		headers = { l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㽐") : l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㽑") }
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㽒") : l11lll1l11_l1_ , l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㽓") : l1l11l1l11l_l1_(32) , l11ll1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㽔") : l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࠭㽕")+source , l11ll1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㽖") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㽗"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠫࠬ㽘"),l11ll1_l1_ (u"ࠬ࠭㽙"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠻ࡺࡨࠨ㽚"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㽛"),l11ll1_l1_ (u"ࠨࠩ㽜"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㽝"),l11ll1_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㽞"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㽟")]
		if source==l11ll1_l1_ (u"ࠬࡌࡍࠨ㽠"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㽡"), url, l11ll1_l1_ (u"ࠧࠨ㽢"), l11ll1_l1_ (u"ࠨࠩ㽣"), False,l11ll1_l1_ (u"ࠩࠪ㽤"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠹ࡷ࡬ࠬ㽥"))
			url = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㽦")]
			url = url.replace(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㽧"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ㽨"))
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㽩"))
	return
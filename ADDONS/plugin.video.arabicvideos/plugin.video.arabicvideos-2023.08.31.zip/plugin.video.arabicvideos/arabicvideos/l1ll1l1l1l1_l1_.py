# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ⠶")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫ⠷")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭วๅฬุ๊๏็วหࠩ⠸"),l11ll1_l1_ (u"ࠧศ่ืหฦࠦอิษหࠫ⠹"),l11ll1_l1_ (u"ࠨู็ฬฬะࠠศๆี์๖อัࠨ⠺")]
#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⠻"):l11ll1_l1_ (u"ࠪࠫ⠼")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l11111_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llll11_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⠽"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⠾"),l11ll1_l1_ (u"࠭ࠧ⠿"),399,l11ll1_l1_ (u"ࠧࠨ⡀"),l11ll1_l1_ (u"ࠨࠩ⡁"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⡂"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⡃"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⡄"),l11ll1_l1_ (u"ࠬ࠭⡅"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⡆"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ⡇"),l11ll1_l1_ (u"ࠨࠩ⡈"),l11ll1_l1_ (u"ࠩࠪ⡉"),l11ll1_l1_ (u"ࠪࠫ⡊"),l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⡋"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⡌"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⡍"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⡎")+l111l1_l1_+title,l11l1l_l1_,391,l11ll1_l1_ (u"ࠨࠩ⡏"),l11ll1_l1_ (u"ࠩࠪ⡐"),l11ll1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ⡑")+str(seq))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡒"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⡓")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅฯฬสีฬะฺࠠึ๋หห๐ษࠨ⡔"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠧࠨ⡕"),l11ll1_l1_ (u"ࠨࠩ⡖"),l11ll1_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ⡗"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡘"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⡙")+l111l1_l1_+l11ll1_l1_ (u"ࠬษูๅ๋ࠣห้ษแๅษ่ࠤฯ่๊๋็ส๏ࠬ⡚"),l11l1l_l1_,391,l11ll1_l1_ (u"࠭ࠧ⡛"),l11ll1_l1_ (u"ࠧࠨ⡜"),l11ll1_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡱࡴࡼࡩࡦࡵࠪ⡝"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡞"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⡟")+l111l1_l1_+l11ll1_l1_ (u"ࠫศ฿ไ๊ࠢสู่๊ไิๆสฮࠥะโ๋์่ห๐࠭⡠"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠬ࠭⡡"),l11ll1_l1_ (u"࠭ࠧ⡢"),l11ll1_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩ⡣"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡤"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡥")+l111l1_l1_+l11ll1_l1_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨ⡦"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⡧"),391,l11ll1_l1_ (u"ࠬ࠭⡨"),l11ll1_l1_ (u"࠭ࠧ⡩"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⡪"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡫"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡬")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪ⡭"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭⡮"),391,l11ll1_l1_ (u"ࠬ࠭⡯"),l11ll1_l1_ (u"࠭ࠧ⡰"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⡱"))
	block = l11ll1_l1_ (u"ࠨࠩ⡲")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ⡳"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⡴"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⡵"),l11ll1_l1_ (u"ࠬ࠭⡶"),l11ll1_l1_ (u"࠭ࠧ⡷"),l11ll1_l1_ (u"ࠧࠨ⡸"),l11ll1_l1_ (u"ࠨࠩ⡹"),l11ll1_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ⡺"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡲࡥࡢࡵࡨࡷࠧ࠮࠮ࠫࡁࠬࡥࡸ࡯ࡤࡦࠩ⡻"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⡼"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⡽"),l11ll1_l1_ (u"࠭ࠧ⡾"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⡿"),block,re.DOTALL)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ⢀"):
			if first:
				title = l11ll1_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ⢁")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ⢂")+title
		if title not in l1l11l_l1_:
			if title==l11ll1_l1_ (u"ࠫศ็ไศ็ࠪ⢃"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢄"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⢅")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⢆"),391,l11ll1_l1_ (u"ࠨࠩ⢇"),l11ll1_l1_ (u"ࠩࠪ⢈"),l11ll1_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⢉"))
			elif title==l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠬ⢊"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢋"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⢌")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩ⢍"),391,l11ll1_l1_ (u"ࠨࠩ⢎"),l11ll1_l1_ (u"ࠩࠪ⢏"),l11ll1_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⢐"))
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢑"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⢒")+l111l1_l1_+title,l1lllll_l1_,391)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⢓"),l11ll1_l1_ (u"ࠧࠨ⢔"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⢕"),url,l11ll1_l1_ (u"ࠩࠪ⢖"),l11ll1_l1_ (u"ࠪࠫ⢗"),l11ll1_l1_ (u"ࠫࠬ⢘"),l11ll1_l1_ (u"ࠬ࠭⢙"),l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⢚"))
	html = response.content
	if type in [l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⢛"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⢜")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ⢝"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⢞"),l11ll1_l1_ (u"ࠫࠬ⢟"),url,block)
	elif type==l11ll1_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⢠"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡥࡷࡩࡨࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ⢡"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif type==l11ll1_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡰࡳࡻ࡯ࡥࡴࠩ⢢"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶ࡯ࡩ࡫ࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠫࡹࡵࡰ࠮࡫ࡰࡨࡧ࠳࡬ࡪࡵࡷࠤࡹࡸࡩࡨࡪࡷࠦ⢣"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⢤"),l11ll1_l1_ (u"ࠪࠫ⢥"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⢦"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟ࡴࡧࡵ࡭ࡪࡹࠧ⢧"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴࡳ࡫ࡪ࡬ࡹ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴࠥ⢨"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⢩"),l11ll1_l1_ (u"ࠨࠩ⢪"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠤ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ⢫"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⢬"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ⢭"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⢮"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ⢯"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ⢰"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢱"),block,re.DOTALL)
		l1llll_l1_,l1l11111l_l1_,l1lll111_l1_ = zip(*l1111l_l1_)
		items = zip(l1l11111l_l1_,l1llll_l1_,l1lll111_l1_)
	elif type==l11ll1_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ⢲"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ⢳"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢴"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ⢵") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ⢶"),l11ll1_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭⢷"))
		html = html.replace(l11ll1_l1_ (u"ࠨ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭⢸"),l11ll1_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡦࡰࡧࡂࠬ⢹"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ⢺"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==6:
			l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⢻"),block,re.DOTALL)
			l1l11111l_l1_,l1lll111_l1_,l1llll_l1_ = zip(*l1111l_l1_)
			items = zip(l1l11111l_l1_,l1llll_l1_,l1lll111_l1_)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ⢼"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ⢽") in url:
				items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢾"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ⢿") in url:
				items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⣀"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⣁"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠩ⣂") in title: continue
		if l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࠫ⣃") in title:
			title = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡩࡷ࡯ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⣄"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ⣅")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⣆")+title
		l1lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾ࠪ⣇"),title,re.DOTALL)
		if l1lll1l11_l1_: title = l1lll1l11_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭⣈") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣉"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⣊") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣋"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ⣌") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣍"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ⣎") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣏"),l111l1_l1_+title,l1lllll_l1_,391,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⣐"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	if type not in [l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⣑"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ⣒")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⣓"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⣔"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣕"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ⣖")+title,l1lllll_l1_,391,l11ll1_l1_ (u"ࠫࠬ⣗"),l11ll1_l1_ (u"ࠬ࠭⣘"),type)
	return
def l1llll11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⣙"),l11ll1_l1_ (u"ࠧࠨ⣚"),l11ll1_l1_ (u"ࠨࠩ⣛"),url)
	server = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⣜"))
	url = url.replace(server,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⣝"),url,l11ll1_l1_ (u"ࠫࠬ⣞"),l11ll1_l1_ (u"ࠬ࠭⣟"),l11ll1_l1_ (u"࠭ࠧ⣠"),l11ll1_l1_ (u"ࠧࠨ⣡"),l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⣢"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⣣"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡦࡲ࡬ࡷࡴࡪࡩࡰࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ⣤"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⣥"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⣦"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	return
def PLAY(url):
	html = l1ll1l11l1_l1_(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⣧"),url,l11ll1_l1_ (u"ࠧࠨ⣨"),l11ll1_l1_ (u"ࠨࠩ⣩"),l11ll1_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⣪"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⣫"),url,l11ll1_l1_ (u"ࠫࠬ⣬"),l11ll1_l1_ (u"ࠬ࠭⣭"),l11ll1_l1_ (u"࠭ࠧ⣮"),l11ll1_l1_ (u"ࠧࠨ⣯"),l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⣰"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⣱"),l11ll1_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ⣲"))
		except: pass
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⣳"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳ࠯ࡲࡴࡹ࡯࡯࡯࠯࠴ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾࡝ࠥࢀࡡ࠭࡝ࠩࡵ࡫ࡩࡦࡪࡥࡳࡾࡳࡥ࡬ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠪ࡝ࠥࢀࡡ࠭࡝ࠨ⣴"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡿࡰࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡲࡲࡷࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡵ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡶࡪࡦࡢࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⣵"),block,re.DOTALL)
		for type,post,l1ll1l1l1ll_l1_,title in items:
			#l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡼ࠴ࡡ࡭ࡨࡤ࡮ࡪࡸࡴࡷ࠰ࡦࡳࡲ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࠩ⣶")
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࡦࡪ࡭ࡪࡰ࠰ࡥ࡯ࡧࡸ࠯ࡲ࡫ࡴࡄࡧࡣࡵ࡫ࡲࡲࡂࡪ࡯ࡰࡡࡳࡰࡦࡿࡥࡳࡡࡤ࡮ࡦࡾࠦࡱࡱࡶࡸࡂ࠭⣷")+post+l11ll1_l1_ (u"ࠩࠩࡲࡺࡳࡥ࠾ࠩ⣸")+l1ll1l1l1ll_l1_+l11ll1_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࠪ⣹")+type
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⣺")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⣻")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	#WRITE_THIS(html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡩࡥ࠿ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬࠦࡣ࡭ࡣࡶࡷ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾࡝࡟ࠦࢁ࠭࡝ࡴࡤࡲࡼࡠࡢࠢࡽࠩࡠࠦ⣼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠢࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⣽"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⣾"),l11ll1_l1_ (u"ࠩࠪ⣿"),str(items),str(block))
		for l1lll1_l1_,l1lllll_l1_,l111lll1_l1_,l1ll1l1ll11_l1_ in items:
			if l11ll1_l1_ (u"ࠪࡁࠬ⤀") in l1lll1_l1_:
				host = l1lll1_l1_.split(l11ll1_l1_ (u"ࠫࡂ࠭⤁"))[1]
				title = SERVER(host,l11ll1_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ⤂"))
			else: title = l11ll1_l1_ (u"࠭ࠧ⤃")
			title = l1ll1l1ll11_l1_+l11ll1_l1_ (u"ࠧࠡࠩ⤄")+title
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⤅")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟ࡠࡡࠪ⤆")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ⤇"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⤈"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭⤉"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ⤊"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ⤋"),l11ll1_l1_ (u"ࠨ࠭ࠪ⤌"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⤍")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⤎"))
	return
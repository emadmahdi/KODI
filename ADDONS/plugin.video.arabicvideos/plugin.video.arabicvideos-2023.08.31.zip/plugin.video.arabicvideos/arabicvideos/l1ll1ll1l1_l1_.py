# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡧ࠲࠹࡮ࡥ࡭ࡣ࡯࠲ࡹࡼࠧᦦ")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠷࡬ࡪࡲࡡ࡭࠰ࡷࡺࠬᦧ")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࠵ࡪࡨࡰࡦࡲ࠮ࡵࡸࠪᦨ")
script_name = l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬᦩ")
headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᦪ") : l11ll1_l1_ (u"ࠬ࠭ᦫ") }
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡄࡏࡉࡣࠬ᦬")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1llll1l1_l1_()
	elif mode==95: results = l1llll11_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᦭"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ᦮"),l11ll1_l1_ (u"ࠩࠪ᦯"),99,l11ll1_l1_ (u"ࠪࠫᦰ"),l11ll1_l1_ (u"ࠫࠬᦱ"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᦲ"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᦳ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᦴ"),l11ll1_l1_ (u"ࠨࠩᦵ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᦶ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᦷ")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪᦸ"),l11ll1_l1_ (u"ࠬ࠭ᦹ"),94)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦺ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᦻ")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็วาีหࠨᦼ"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯ࡥࡹ࡫ࡳࡵࠩᦽ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦾ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᦿ")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไฤ฻็ํࠥะโ๋็ส๏ࠬᧀ"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡩ࡮ࡦࡥࠫᧁ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᧂ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᧃ")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่ศ้หาุ่ࠢฬํฯสࠩᧄ"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡺ࡮࡫ࡷࠨᧅ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᧆ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᧇ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ฮฬฯ࠭ᧈ"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡱ࡫ࡱࠫᧉ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧊"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᧋")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ᧌"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡳ࡫ࡷࡎࡱࡹ࡭ࡪࡹࠧ᧍"),91)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᧎"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᧏")+l111l1_l1_+l11ll1_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭᧐"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡰࡨࡻࡊࡶࡩࡴࡱࡧࡩࡸ࠭᧑"),91)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᧒"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᧓"),l11ll1_l1_ (u"ࠫࠬ᧔"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᧕"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᧖")+l111l1_l1_+l11ll1_l1_ (u"ࠧอัํำࠥอไๆ๊ๅ฽ࠬ᧗"),l11l1l_l1_,91)
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ᧘"),headers,l11ll1_l1_ (u"ࠩࠪ᧙"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ᧚"))
	#upper menu
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡧࡩ࡯࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡲࡦࡼࠧ᧛"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᧜"),block,re.DOTALL)
	l1l11l_l1_ = [l11ll1_l1_ (u"࠭วโๆส้๊ࠥไไสสีࠥ็โุࠩ᧝")]
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ᧞"))
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧟"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᧠")+l111l1_l1_+title,l1lllll_l1_,91)
	return html
def ITEMS(url):
	if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࠨ᧡") in url:
		url,search = url.split(l11ll1_l1_ (u"ࠫࡄࡺ࠽ࠨ᧢"))
		headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᧣") : l11ll1_l1_ (u"࠭ࠧ᧤") , l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭᧥") : l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ᧦") }
		data = { l11ll1_l1_ (u"ࠩࡷࠫ᧧") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ᧨"),url,data,headers,l11ll1_l1_ (u"ࠫࠬ᧩"),l11ll1_l1_ (u"ࠬ࠭᧪"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ᧫"))
		html = response.content
	else:
		headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᧬") : l11ll1_l1_ (u"ࠨࠩ᧭") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠩࠪ᧮"),headers,l11ll1_l1_ (u"ࠪࠫ᧯"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠸࡮ࡥࠩ᧰"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶࡩࡳࡴࡺࠢࠨ᧱"),html,re.DOTALL)
	if l1l1l11_l1_: block = l1l1l11_l1_[0]
	else: block = l11ll1_l1_ (u"࠭ࠧ᧲")
	items = re.findall(l11ll1_l1_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡳ࡯ࡷ࡫ࡨ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᧳"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ᧴") in title and l11ll1_l1_ (u"ࠩ࠲ࡧ࠴࠭᧵") not in url and l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴ࠰ࠩ᧶") not in url:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣ࡟࠵࠳࠹࡞࠭ࠪ᧷"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ᧸")+l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᧹"),l111l1_l1_+title,l1lllll_l1_,95,l1lll1_l1_)
					l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ᧺") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᧻"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᧼"),l111l1_l1_+title,l1lllll_l1_,91,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ᧽"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᧾"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠬอไึใะอࠥ࠭᧿"),l11ll1_l1_ (u"࠭ࠧᨀ"))
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᨁ"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧᨂ")+title,l1lllll_l1_,91)
	return
def l1llll11_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠩࠪᨃ"),headers,l11ll1_l1_ (u"ࠪࠫᨄ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᨅ"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᨆ"),html,re.DOTALL)
	l1lll1_l1_ = l1lll1_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᨇ"),html,re.DOTALL)
	if l1l1l11_l1_:
		name = re.findall(l11ll1_l1_ (u"ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᨈ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩᨉ"))
			if l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᨊ") in name: name = name.split(l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᨋ"),1)[1]
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᨌ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᨍ"),l111l1_l1_+name+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᨎ")+title,l1lllll_l1_,92,l1lll1_l1_)
	else:
		tmp = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡱࡹ࡭ࡪࡺࡩࡵ࡮ࡨࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᨏ"),html,re.DOTALL)
		if tmp: l1lllll_l1_,title = tmp[0]
		else: l1lllll_l1_,title = url,name
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᨐ"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll1ll11l_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠩࠪᨑ"),headers,l11ll1_l1_ (u"ࠪࠫᨒ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᨓ"))
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡺࡥࡹࡶ࠰ࡷ࡭ࡧࡤࡰࡹ࠽ࠤࡳࡵ࡮ࡦ࠽ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᨔ"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᨕ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᨖ"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᨗ")
			l1llll_l1_.append(l1lllll_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡱࡥࡻ࠳ࡴࡢࡤࡶࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࠮ࡲࡤࡲࡪࡲ࠭࡮ࡱࡵࡩᨘࠬ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l11l1l1l1_l1_ l1l1_l1_
		items = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡨࡱࡧ࡫ࡤࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᨙ"),block,re.DOTALL)
		for id,l1lllll_l1_ in items:
			title = l11ll1_l1_ (u"ุࠫ๐ัโำࠣࠫᨚ")+id
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᨛ")+title+l11ll1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ᨜")
			l1llll_l1_.append(l1lllll_l1_)
		# other l1l1_l1_
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᨝"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭᨞") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᨟")+l1lllll_l1_
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᨠ"),url)
	return
def l1llll1l1_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬᨡ"),headers,l11ll1_l1_ (u"ࠬ࠭ᨢ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬᨣ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦ࡮ࡴࡤࡦࡺ࠰ࡰࡦࡹࡴ࠮࡯ࡲࡺ࡮࡫ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡫ࡱࡨࡪࡾ࠭ࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪ࠭ᨤ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᨥ"),block,re.DOTALL)
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪᨦ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᨧ"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᨨ"),l111l1_l1_+title,l1lllll_l1_,91,l1lll1_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ᨩ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧᨪ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩᨫ"),l11ll1_l1_ (u"ࠨ࠭ࠪᨬ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡵ࠿ࠪᨭ")+search
	ITEMS(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ弟")
headers = l11ll1_l1_ (u"࠭ࠧ张") #{ l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ弡") : l11ll1_l1_ (u"ࠨࠩ弢") }
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨ弣")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ弤"),l11ll1_l1_ (u"ࠫฬ๊ใๅࠩ弥"),l11ll1_l1_ (u"ࠬอแๅษ่ࠫ弦"),l11ll1_l1_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ弧"),l11ll1_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ弨")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11111_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llll11_l1_(url,True)
	elif mode==114: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ弩")+text)
	elif mode==115: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭弪")+text)
	elif mode==116: results = l1llll11_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1ll1l_l1_(l11l1l_l1_,l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ弫"),l11ll1_l1_ (u"ูࠫอ็ะࠢไ์ึ๊้ࠦࠢ࠰ࠤࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭弬"),l11ll1_l1_ (u"ࠬࡵࡲࡥࡧࡵࡁࡱࡧࡳࡵࡡࡩ࡭ࡱࡳࡳࠨ弭"),headers)
	html = response.content
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弮"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ弯"),l11ll1_l1_ (u"ࠨࠩ弰"),119,l11ll1_l1_ (u"ࠩࠪ弱"),l11ll1_l1_ (u"ࠪࠫ弲"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ弳"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弴"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ張"),l1ll111_l1_,115)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弶"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ強"),l1ll111_l1_,114)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ弸"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ弹"),l11ll1_l1_ (u"ࠫࠬ强"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弻"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧ弼"),l1ll111_l1_,111,l11ll1_l1_ (u"ࠧࠨ弽"),l11ll1_l1_ (u"ࠨࠩ弾"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ弿"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷ࡮ࡳࡰ࡭ࡧ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡢࡦࡹ࠱࡫࡯࡬ࡵࡧࡵࠫ彀"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ彁"),l11ll1_l1_ (u"ࠬ࠭彂"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ彃"),l11ll1_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥห๊อษาࠤ฾์่ศ่ࠣห้๋่ใ฻ࠣวํࠦสึ็ํ้ࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠪ彄"))
		return
	else:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡁࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ彅"),block,re.DOTALL)
		for filter,l1lll1_l1_,title in items:
			url = l1ll111_l1_+filter
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彆"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ彇")+l111l1_l1_+title,url,111,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ彈"),filter)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ彉"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭彊"),l11ll1_l1_ (u"ࠧࠨ彋"),9999)
	l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࡀࠪ彌"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ彍"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭彎"),l11ll1_l1_ (u"ࠫࠬ彏")).replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ彐"),l11ll1_l1_ (u"࠭ࠧ彑")).strip(l11ll1_l1_ (u"ࠧࠡࠩ归"))
			if title in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭当") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
			if l11ll1_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ彔") in l1lllll_l1_: title = l11ll1_l1_ (u"๊ࠪ๏ะแๅๅึࠫ录")
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彖"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ彗")+l111l1_l1_+title,l1lllll_l1_,111)
	return html
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"࠭ࠧ彘"),response=l11ll1_l1_ (u"ࠧࠨ彙")):
	#l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ彚"):l11ll1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ彛")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ彜"),url,l11ll1_l1_ (u"ࠫࠬ彝"),headers,l11ll1_l1_ (u"ࠬ࠭彞"),l11ll1_l1_ (u"࠭ࠧ彟"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭彠"))
	html = response.content
	l1l1l11_l1_,items,l11l_l1_ = [],[],[]
	if l1lll1l11l_l1_==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ彡"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡪࡰ࡮ࡪࡥࡠࡡࡶࡰ࡮ࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ形"),html,re.DOTALL)
	elif l1lll1l11l_l1_==l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ彣"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡒ࡫ࡤࡪࡣࡊࡶ࡮ࡪࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ彤"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡨࡰࡹࡶ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ彥"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if l1lll1l11l_l1_==l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭彦"): items = re.findall(l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ彧"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ彨"),block,re.DOTALL)
	l1ll1l_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩ彩"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ彪"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪ彫"),l11ll1_l1_ (u"้ࠬไ๋สࠪ彬"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ彭"),l11ll1_l1_ (u"่ࠧัสๅࠬ彮"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ彯"),l11ll1_l1_ (u"ࠩ฼ี฻࠭彰"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ影"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ彲")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ彳") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ彴") in l1lllll_l1_: continue
		#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧࠧࠥ࠳࠷࠽ࡁࠧ彵"),l11ll1_l1_ (u"ࠨࠨࠪ彶"))
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠩ࠲ࠫ彷"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ彸"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ役"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ彺") in l1lllll_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ彻"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ彼") in title and l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ彽") not in url:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ彾") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彿"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵ࠳ࠬ往") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ征"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ徂") in l1lllll_l1_ and l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭徃") not in url:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ径")
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ待"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ徆") in url and l11ll1_l1_ (u"ࠫา๊โสࠩ徇") in title:
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ很"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徉"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ徊"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1lll1l11l_l1_!=l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ律"): items = re.findall(l11ll1_l1_ (u"ࠩࠫࡹࡵࡪࡡࡵࡧࡔࡹࡪࡸࡹࠪ࠰࠭ࡃࡃ࠮࠮ࠬࡁࠬࡀࠬ後"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ徍"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lll1l11l_l1_!=l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ徎"):
				title = title.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ徏"),l11ll1_l1_ (u"࠭ࠧ徐")).replace(l11ll1_l1_ (u"ࠧ࡝ࡴࠪ徑"),l11ll1_l1_ (u"ࠨࠩ徒"))
				if l11ll1_l1_ (u"ࠩࡂࠫ従") in url: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ徔")+title
				else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫ徕")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ徖"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ得")+title,l1lllll_l1_,111,l11ll1_l1_ (u"ࠧࠨ徘"),l11ll1_l1_ (u"ࠨࠩ徙"),l1lll1l11l_l1_)
	return
def l1llll11_l1_(url,l1lll11l11lll_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭徚"),url,l11ll1_l1_ (u"ࠪࠫ徛"),headers,l11ll1_l1_ (u"ࠫࠬ徜"),l11ll1_l1_ (u"ࠬ࠭徝"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ從"))
	html = response.content
	# l1lll1l_l1_ & l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡶࡨࡱࡸࠦࡤ࠮ࡨ࡯ࡩࡽ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪ徟"),html,re.DOTALL)
	if len(l1l1l11_l1_)>1:
		if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ徠") in l1l1l11_l1_[0]: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[1]
		else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[1],l1l1l11_l1_[0]
	else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[0]
	for l11ll11111_l1_ in range(2):
		if l1lll11l11lll_l1_: mode,type,block = 116,l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ御"),l1lll1l_l1_
		else: mode,type,block = 112,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ徢"),l1l11_l1_
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ徣"),block,re.DOTALL)
		if l1lll11l11lll_l1_ and len(items)<2:
			l1lll11l11lll_l1_ = False
			continue
		for l1lllll_l1_,l11l1l11l_l1_,l1lll1l11_l1_ in items:
			title = l11l1l11l_l1_+l11ll1_l1_ (u"ࠬࠦࠧ徤")+l1lll1l11_l1_
			addMenuItem(type,l111l1_l1_+title,l1lllll_l1_,mode)
		break
	# l1l11_l1_ l11l11ll_l1_
	if not items and l11ll1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ徥") in html:
		l1l11lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡴࡨࡥࡩࡩࡲࡶ࡯ࡥࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ徦"),html,re.DOTALL)
		if l1l11lll1_l1_:
			block = l1l11lll1_l1_[0]
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ徧"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1lllll_l1_ = l1l1_l1_[2]+l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ徨")
				l11111_l1_(l1lllll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ復"),url,l11ll1_l1_ (u"ࠫࠬ循"),headers,l11ll1_l1_ (u"ࠬ࠭徫"),l11ll1_l1_ (u"࠭ࠧ徬"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ徭"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡦࡸ࡮ࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭微"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ徯"),block,re.DOTALL)
	l11l1l1l1_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ徰") in block
	download = l11ll1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ徱") in block
	if   l11l1l1l1_l1_ and not download: l1lll11l111ll_l1_,l111lll1lll1_l1_ = l1l1_l1_[0],l11ll1_l1_ (u"ࠬ࠭徲")
	elif not l11l1l1l1_l1_ and download: l1lll11l111ll_l1_,l111lll1lll1_l1_ = l11ll1_l1_ (u"࠭ࠧ徳"),l1l1_l1_[0]
	elif l11l1l1l1_l1_ and download: l1lll11l111ll_l1_,l111lll1lll1_l1_ = l1l1_l1_[0],l1l1_l1_[1]
	else: l1lll11l111ll_l1_,l111lll1lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ徴"),l11ll1_l1_ (u"ࠨࠩ徵")
	# l11l1l1l1_l1_
	if l11l1l1l1_l1_:
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭徶"),l1lll11l111ll_l1_,l11ll1_l1_ (u"ࠪࠫ德"),headers,l11ll1_l1_ (u"ࠫࠬ徸"),l11ll1_l1_ (u"ࠬ࠭徹"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ徺"))
		l11ll1l1_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡭ࡧࡷࠤࡸ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫࡳࡰࡦࡿࡥࡳࠩ徻"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ徼"),l111l_l1_,re.DOTALL)
			for title,l1lllll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡠ࠴࠭徽"),l11ll1_l1_ (u"ࠪ࠳ࠬ徾"))
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ徿")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭忀")
				l1llll_l1_.append(l1lllll_l1_)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ忁"),l111lll1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ忂"),headers,l11ll1_l1_ (u"ࠨࠩ心"),l11ll1_l1_ (u"ࠩࠪ忄"),l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ必"))
		l11ll1l1_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭࡮ࡴࡦࡰ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ忆"),l11ll1l1_l1_,re.DOTALL)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠳ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ忇"),l111l_l1_,re.DOTALL)
			for l1lllll_l1_,title,l111lll1_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ忈")+title+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ忉")+l11ll1_l1_ (u"ࠨࡡࡢࡣࡤ࠭忊")+l111lll1_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ忋"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ忌"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭忍"),l11ll1_l1_ (u"ࠬ࠱ࠧ忎"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ忏")+search
	l1ll111_l1_,l111lll_l1_,l1ll11111_l1_ = l1ll1l1ll1l_l1_(url,l11ll1_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ忐"),l11ll1_l1_ (u"ࠨึส๋ิࠦแ้ำࠣ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ忑"),l11ll1_l1_ (u"ࠩࡐࡩࡩ࡯ࡡࡈࡴ࡬ࡨࠬ忒"),headers)
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ忓"),l1ll11111_l1_)
	return
# ===========================================
#     l1lll1lll1_l1_ l1lll1ll1l_l1_ l1lll1llll_l1_
# ===========================================
def l1lllll1ll_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ忔"))[0]
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ忕"),url,l11ll1_l1_ (u"࠭ࠧ忖"),headers,l11ll1_l1_ (u"ࠧࠨ志"),l11ll1_l1_ (u"ࠨࠩ忘"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭忙"))
	html = response.content
	l1ll1ll1_l1_ = []
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭忚"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# name & category & options block
		l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡸࡤࡰࡺ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ忛"),block,re.DOTALL)
		l1lll11l11l1l_l1_,names,l1111l1_l1_ = zip(*l1ll1ll1_l1_)
		l1ll1ll1_l1_ = zip(names,l1lll11l11l1l_l1_,l1111l1_l1_)
	return l1ll1ll1_l1_
def l1llll11l1_l1_(block):
	# id & title
	items = re.findall(l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠴ࠨ࠯ࠬࡂ࠭࠳ࡂࠧ応"),block,re.DOTALL)
	return items
def l1lll11l111l1_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"࠭ࡣࡢࡶࡀࠫ忝"),l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ忞"))
	if l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ忟") not in url: url = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭忠")
	l1lllll11l_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ忡"))[0]
	l1llll1l11_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ忢"))
	url = url.replace(l1lllll11l_l1_,l1llll1l11_l1_)
	#url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ忣"),l11ll1_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪ忤"))
	url = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ忥"),l11ll1_l1_ (u"ࠨ࠱ࡂࠫ忦"))
	return url
l1lll11l11l11_l1_ = [l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ忧"),l11ll1_l1_ (u"ࠪࡽࡪࡧࡲࠨ忨"),l11ll1_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ忩"),l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ忪")]
l1lll11l11ll1_l1_ = [l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ快"),l11ll1_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭忬"),l11ll1_l1_ (u"ࠨࡻࡨࡥࡷ࠭忭")]
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ忮"),l11ll1_l1_ (u"ࠪࠫ忯"))
	url = url.split(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ忰"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ忱"),1)
	if filter==l11ll1_l1_ (u"࠭ࠧ忲"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠧࠨ忳"),l11ll1_l1_ (u"ࠨࠩ忴")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭念"))
	if type==l11ll1_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ忶"):
		if l1lll11l11ll1_l1_[0]+l11ll1_l1_ (u"ࠫࡂ࠭忷") not in l1l111l1_l1_: category = l1lll11l11ll1_l1_[0]
		for i in range(len(l1lll11l11ll1_l1_[0:-1])):
			if l1lll11l11ll1_l1_[i]+l11ll1_l1_ (u"ࠬࡃࠧ忸") in l1l111l1_l1_: category = l1lll11l11ll1_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ忹")+category+l11ll1_l1_ (u"ࠧ࠾࠲ࠪ忺")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪ忻")+category+l11ll1_l1_ (u"ࠩࡀ࠴ࠬ忼")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ忽"))+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ忾")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧ忿"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ怀"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ态")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭怂"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ怃"))
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠪࠫ怄"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ怅"))
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠬ࠭怆"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ怇")+l1l1111l_l1_
		l11l111_l1_ = l1lll11l111l1_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ怈"),l111l1_l1_+l11ll1_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ怉"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怊"),l111l1_l1_+l11ll1_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ怋")+l11ll11l_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ怌"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ怍"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭怎"),l11ll1_l1_ (u"ࠧࠨ怏"),9999)
	l1ll1ll1_l1_ = l1lllll1ll_l1_(url)
	dict = {}
	for name,l1ll1l11_l1_,block in l1ll1ll1_l1_:
		name = name.replace(l11ll1_l1_ (u"ࠨๅ็ࠤࠬ怐"),l11ll1_l1_ (u"ࠩࠪ怑"))
		items = l1llll11l1_l1_(block)
		if l11ll1_l1_ (u"ࠪࡁࠬ怒") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ怓"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<2:
				if l1ll1l11_l1_==l1lll11l11ll1_l1_[-1]:
					l11l111_l1_ = l1lll11l111l1_l1_(l111lll_l1_)
					l11111_l1_(l11l111_l1_)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ怔")+l1l11ll1_l1_)
				return
			else:
				if l1ll1l11_l1_==l1lll11l11ll1_l1_[-1]:
					l11l111_l1_ = l1lll11l111l1_l1_(l111lll_l1_)
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怕"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ怖"),l11l111_l1_,111)
				else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ怗"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ怘"),l111lll_l1_,115,l11ll1_l1_ (u"ࠪࠫ怙"),l11ll1_l1_ (u"ࠫࠬ怚"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ怛"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ怜")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠧ࠾࠲ࠪ思")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪ怞")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠩࡀ࠴ࠬ怟")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ怠")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ怡"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ怢")+name,l111lll_l1_,114,l11ll1_l1_ (u"࠭ࠧ怣"),l11ll1_l1_ (u"ࠧࠨ怤"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ急"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ怦"): option = l11ll1_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ性")
			elif value==l11ll1_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ怨"): option = l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ怩")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ怪") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ怫"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪ怬")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠩࡀࠫ怭")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠪࠪࠬ怮")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠫࡂ࠭怯")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ怰")+l1l1ll11_l1_
			title = option+l11ll1_l1_ (u"࠭ࠠ࠻ࠩ怱")#+dict[l1ll1l11_l1_][l11ll1_l1_ (u"ࠧ࠱ࠩ怲")]
			title = option+l11ll1_l1_ (u"ࠨࠢ࠽ࠫ怳")+name
			if type==l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ怴"): addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ怵"),l111l1_l1_+title,url,114,l11ll1_l1_ (u"ࠫࠬ怶"),l11ll1_l1_ (u"ࠬ࠭怷"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ怸"))
			elif type==l11ll1_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ怹") and l1lll11l11ll1_l1_[-2]+l11ll1_l1_ (u"ࠨ࠿ࠪ怺") in l1l111l1_l1_:
				l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ总"))
				l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ怼")+l11llll1_l1_
				l11l111_l1_ = l1lll11l111l1_l1_(l111lll_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ怽"),l111l1_l1_+title,l11l111_l1_,111)
			else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怾"),l111l1_l1_+title,url,115,l11ll1_l1_ (u"࠭ࠧ怿"),l11ll1_l1_ (u"ࠧࠨ恀"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ恁")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ恂")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ恃")					all l1l1l1l1_l1_ & l1llll1lll_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠫࡂࠬࠧ恄"),l11ll1_l1_ (u"ࠬࡃ࠰ࠧࠩ恅"))
	filters = filters.strip(l11ll1_l1_ (u"࠭ࠦࠨ恆"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"ࠧ࠾ࠩ恇") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠨࠨࠪ恈"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠩࡀࠫ恉"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"ࠪࠫ恊")
	for key in l1lll11l11l11_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠫ࠵࠭恋")
		if l11ll1_l1_ (u"ࠬࠫࠧ恌") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ恍") and value!=l11ll1_l1_ (u"ࠧ࠱ࠩ恎"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ恏")+value
		elif mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ恐") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬ恑"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭恒")+key+l11ll1_l1_ (u"ࠬࡃࠧ恓")+value
		elif mode==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪ恔"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩ恕")+key+l11ll1_l1_ (u"ࠨ࠿ࠪ恖")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠩࠣ࠯ࠥ࠭恗"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ恘"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠫࡂ࠶ࠧ恙"),l11ll1_l1_ (u"ࠬࡃࠧ恚"))
	return l1ll11l1_l1_
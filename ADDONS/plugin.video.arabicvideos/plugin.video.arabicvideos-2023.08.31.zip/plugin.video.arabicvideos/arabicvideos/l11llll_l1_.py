# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࣑ࠧ") : l11ll1_l1_ (u"࣒ࠫࠬ") }
script_name = l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐ࣓ࠫ")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡂࡍࡒࡣࠬࣔ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11ll1l_l1_ = [l11ll1_l1_ (u"ࠧโ์็้ࠬࣕ"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭ࣖ"),l11ll1_l1_ (u"ࠩส่฾ืึࠡษ็หุฮฺ่์ࠪࣗ"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪࣘ"),l11ll1_l1_ (u"ู๊ࠫัฮ์๊ࠫࣙ"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫࣚ"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬࣛ"),l11ll1_l1_ (u"ࠧๅไสลࠬࣜ")]
def MAIN(mode,url,text):
	if   mode==70: results = MENU()
	elif mode==71: results = CATEGORIES(url)
	elif mode==72: results = l11111_l1_(url,text)
	elif mode==73: results = l1lll11l_l1_(url)
	elif mode==74: results = PLAY(url)
	elif mode==79: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣝ"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩࣞ"),l11ll1_l1_ (u"ࠪࠫࣟ"),79,l11ll1_l1_ (u"ࠫࠬ࣠"),l11ll1_l1_ (u"ࠬ࠭࣡"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ࣢"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࣣࠧ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪࣤ")+l111l1_l1_+l11ll1_l1_ (u"ࠩึุ่๊ษࠡษไ่ฬ๋ࠧࣥ"),l11ll1_l1_ (u"ࣦࠪࠫ"),79,l11ll1_l1_ (u"ࠫࠬࣧ"),l11ll1_l1_ (u"ࠬ࠭ࣨ"),l11ll1_l1_ (u"࠭ำๅี็อࠥอแๅษ่ࣩࠫ"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࣪"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࣫")+l111l1_l1_+l11ll1_l1_ (u"ࠩึ่ฬูไࠡ็้์฾ฯࠧ࣬"),l11ll1_l1_ (u"࣭ࠪࠫ"),79,l11ll1_l1_ (u"࣮ࠫࠬ"),l11ll1_l1_ (u"࣯ࠬ࠭"),l11ll1_l1_ (u"࠭ำๅี็อࣰࠬ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࣱࠧ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࣲࠪ")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊๋๊ำหࠪࣳ"),l11l1l_l1_,72,l11ll1_l1_ (u"ࠪࠫࣴ"),l11ll1_l1_ (u"ࠫࠬࣵ"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࣶࠧ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࣷ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩࣸ")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้ื๐ฯࠨࣹ"),l11l1l_l1_,72,l11ll1_l1_ (u"ࣺࠩࠪ"),l11ll1_l1_ (u"ࠪࠫࣻ"),l11ll1_l1_ (u"ࠫࡲࡵࡲࡦࠩࣼ"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࣽ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨࣾ")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฦาออัࠨࣿ"),l11l1l_l1_,72,l11ll1_l1_ (u"ࠨࠩऀ"),l11ll1_l1_ (u"ࠩࠪँ"),l11ll1_l1_ (u"ࠪࡲࡪࡽࡳࠨं"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫः"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧऄ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅลัฬฬืࠧअ"),l11l1l_l1_,72,l11ll1_l1_ (u"ࠧࠨआ"),l11ll1_l1_ (u"ࠨࠩइ"),l11ll1_l1_ (u"ࠩࡱࡩࡼࡹࠧई"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨउ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫऊ"),l11ll1_l1_ (u"ࠬ࠭ऋ"),9999)
	l1l11l_l1_ = [l11ll1_l1_ (u"࠭วๅๅอฬࠥ๎ࠠศๆสฬาอหࠨऌ"),l11ll1_l1_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬऍ"),l11ll1_l1_ (u"ࠨษ็ว้฿วษࠩऎ"),l11ll1_l1_ (u"ࠩส่อืวๆฮࠪए"),l11ll1_l1_ (u"ࠪห้อฬ่ิฬࠤฬ๊ไ้ฯํอࠬऐ"),l11ll1_l1_ (u"ࠫฬ๊ี้ำࠣ์ࠥอไฯๆไ๎ฬะࠧऑ"),l11ll1_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭ऒ")]
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧओ"),headers,l11ll1_l1_ (u"ࠧࠨऔ"),l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩक"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥࡷࡺࡩࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨख"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩग"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title not in l1l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫघ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧङ")+l111l1_l1_+title,l1lllll_l1_,71)
	return html
def CATEGORIES(url):
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"࠭ࠧच"),headers,l11ll1_l1_ (u"ࠧࠨछ"),l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨज"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡩࡨࡺ࡟ࡱࡣࡵࡸࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪझ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬञ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ट"))
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬठ"),l111l1_l1_+title,l1lllll_l1_,72)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ड"),l111l1_l1_+l11ll1_l1_ (u"ࠧอ็ํ฽ࠥอไโำ๋฽ࠬढ"),url,72)
	else: l11111_l1_(url,l11ll1_l1_ (u"ࠨࠩण"))
	return
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪत"),l11ll1_l1_ (u"ࠪࠫथ"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬद"),headers,True,l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨध"))
	items = []
	if type==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨन"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡠࡶ࡬ࡸࡱ࡫ࠠࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡹࡵࡣ࡬ࡨࡧࡹࡹ࠭ࡤࡴࡲࡹࡸ࡫࡬ࠨऩ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣ࡬ࡨࡧࡹࡥࡢࡰࡺ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩप"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩफ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࡡࡵࡩࡸࡻ࡬ࡵࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧब"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠳ࡁࠫभ"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭म"),l11ll1_l1_ (u"࠭ࠧय"),str(len(items)),block)
	elif type==l11ll1_l1_ (u"ࠧ࡮ࡱࡵࡩࠬर"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡡࡷ࡭ࡹࡲࡥࠡ࡯ࡲࡶࡪࡥࡴࡪࡶ࡯ࡩ࠭࠴ࠪࡀࠫࡩࡳࡴࡺࡥࡳࡡࡥࡳࡹࡺ࡯࡮ࡡࡶࡩࡷࡼࡩࡤࡧࡶࠫऱ"),html,re.DOTALL)
	#elif type==l11ll1_l1_ (u"ࠩࡱࡩࡼࡹࠧल"):
	#	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡣࡹ࡯ࡴ࡭ࡧࠣࡲࡪࡽࡳࡠࡶ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡳ࡫ࡷࡴࡡࡰࡳࡷ࡫࡟ࡤࡪࡲ࡭ࡨ࡫ࡳࠨळ"),html,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹ࠭ऴ"),html,re.DOTALL)
	if not items and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶࡹࡧࡰࡥࡤࡶࡢࡦࡴࡾ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧव"),block,re.DOTALL)
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"࠭สุ้ํัࠥํวๆࠩश") in title: continue
		title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪष"),l11ll1_l1_ (u"ࠨࠩस")).strip(l11ll1_l1_ (u"ࠩࠣࠫह"))
		title = unescapeHTML(title)
		if any(value in title for value in l11ll1l_l1_): addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩऺ"),l111l1_l1_+title,l1lllll_l1_,73,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫऻ"),l111l1_l1_+title,l1lllll_l1_,73,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ़࠭"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࠼࠰࡮࡬ࡂࡁࡲࡩࠡࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦऽ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧा"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧि")+title,l1lllll_l1_,72,l11ll1_l1_ (u"ࠩࠪी"),l11ll1_l1_ (u"ࠪࠫु"),type)
	return
def l111l11_l1_(url):
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠫࠬू"),headers,True,l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐ࠱ࡘࡋࡃࡕࡋࡒࡒࡘ࠳࠲࡯ࡦࠪृ"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡩࡴࡨࡪࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧॄ"),html,re.DOTALL)
	l111lll_l1_ = l111lll_l1_[1]
	return l111lll_l1_
def l1lll11l_l1_(url):
	#l111ll1_l1_ = [l11ll1_l1_ (u"ࠧࡻ࡫ࡳࠫॅ"),l11ll1_l1_ (u"ࠨࡴࡤࡶࠬॆ"),l11ll1_l1_ (u"ࠩࡷࡼࡹ࠭े"),l11ll1_l1_ (u"ࠪࡴࡩ࡬ࠧै"),l11ll1_l1_ (u"ࠫ࡭ࡺ࡭ࠨॉ"),l11ll1_l1_ (u"ࠬࡺࡡࡳࠩॊ"),l11ll1_l1_ (u"࠭ࡩࡴࡱࠪो"),l11ll1_l1_ (u"ࠧࡩࡶࡰࡰࠬौ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨ्ࠩ"),headers,True,l11ll1_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡕࡈࡇ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧॎ"))
	l111111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠮࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶ࠲ࡠࡼ࠱࠮ࠫࡁࠬࠦࠬॏ"),html,re.DOTALL)
	l11111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠯ࡀ࠯࠰ࡷࡱࡨࡪࡸࡵࡳ࡮࠱ࡧࡴࡳ࠯࡝ࡹ࠮࠲࠯ࡅࠩࠣࠩॐ"),html,re.DOTALL)
	if l111111_l1_ or l11111l_l1_:
		if l111111_l1_: l11l111_l1_ = l111111_l1_[0]
		elif l11111l_l1_: l11l111_l1_ = l111l11_l1_(l11111l_l1_[0])
		l11l111_l1_ = l1111_l1_(l11l111_l1_)
		import l1llll1l_l1_
		if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ॑") in l11l111_l1_ or l11ll1_l1_ (u"࠭࠯ࡴࡪࡲࡻࡸ࠵॒ࠧ") in l11l111_l1_: l1llll1l_l1_.l1llll11_l1_(l11l111_l1_)
		else: l1llll1l_l1_.PLAY(l11l111_l1_)
		return
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧๆฯอ์๎ࠦวๅใํ่๊࠴ࠪࡀࡀ࠱࠮ࡄ࠮࡜ࡸࠬࡂ࠭ࡡ࡝ࠪࡀ࠾ࠪ॓"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡥࡶࠥ࠵࠾࡝ࡰ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ॔"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩॕ"),l111l1_l1_+title,l1lllll_l1_,73)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨ࡟ࡵ࡫ࡷࡰࡪࠨ࠮ࠫࡁ࠿࡬࠶࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡤ࡭ࡳࡥࡩ࡮ࡩࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡࡥ࠯࠶࠴࠵࠳࠲࠶࠲ࠫ࠲࠯ࡅࠩࡢ࡭ࡲ࠱࡫࡫ࡥࡥࡤࡤࡧࡰ࠭ॖ"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l1llllll_l1_(l11ll1_l1_ (u"ࠫำ฽รࠡะสีั๐ࠧॗ"),l11ll1_l1_ (u"๊ࠬวࠡ์๋ะิࠦๅๅใࠣๅ๏ี๊้ࠩक़"))
		return
	name,l1lll1_l1_,block = l1l1l11_l1_[0]
	name = name.strip(l11ll1_l1_ (u"࠭ࠠࠨख़"))
	if l11ll1_l1_ (u"ࠧࡴࡷࡥࡣࡪࡶࡳࡪࡱࡧࡩࡤࡺࡩࡵ࡮ࡨࠫग़") in block:
		items = re.findall(l11ll1_l1_ (u"ࠨࡵࡸࡦࡤ࡫ࡰࡴ࡫ࡲࡨࡪࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀ࠱࠮ࡄࡹࡵࡣࡡࡩ࡭ࡱ࡫࡟ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩज़"),block,re.DOTALL)
	else:
		filenames = re.findall(l11ll1_l1_ (u"ࠩࡶࡹࡧࡥࡦࡪ࡮ࡨࡣࡹ࡯ࡴ࡭ࡧ࡟ࠫࡃ࠮࠮ࠫࡁࠬࠤ࠲ࠦ࠼ࡪࡀࠪड़"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l11ll1_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩढ़"),filename) )
	if not items: items = [ (l11ll1_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪफ़"),l11ll1_l1_ (u"ࠬ࠭य़")) ]
	count = 0
	l1lll111_l1_,l111l1l_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l11lll1_l1_ = l11ll1_l1_ (u"࠭ࠧॠ")
		if l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫॡ") in filename: filename = filename.split(l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬॢ"))[0]
		else: filename = l11ll1_l1_ (u"ࠩࡧࡹࡲࡳࡹ࠯ࡼ࡬ࡴࠬॣ")
		if l11ll1_l1_ (u"ࠪ࠲ࠬ।") in filename: l11lll1_l1_ = filename.split(l11ll1_l1_ (u"ࠫ࠳࠭॥"))[-1]
		#if any(value in l11lll1_l1_ for value in l111ll1_l1_):
		#	if l11ll1_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫ०") not in title: title = title + l11ll1_l1_ (u"࠭࠺ࠨ१")
		title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ२"),l11ll1_l1_ (u"ࠨࠩ३")).strip(l11ll1_l1_ (u"ࠩࠣࠫ४"))
		l1lll111_l1_.append(title)
		l111l1l_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l11ll1l_l1_):
			if size==1:
				l1l_l1_ = 0
			else:
				#DIALOG_SELECT(l11ll1_l1_ (u"ࠪࠫ५"),l1lll111_l1_)
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬ६"), l1lll111_l1_)
				if l1l_l1_ == -1: return
			PLAY(url+l11ll1_l1_ (u"ࠬࡅࡳࡦࡥࡷ࡭ࡴࡴ࠽ࠨ७")+str(1+l111l1l_l1_[size-l1l_l1_-1]))
		else:
			for i in reversed(range(size)):
				#if l11ll1_l1_ (u"࠭࠺ࠨ८") in l1lll111_l1_[i]: title = l1lll111_l1_[i].strip(l11ll1_l1_ (u"ࠧ࠻ࠩ९")) + l11ll1_l1_ (u"ࠨࠢ࠰ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢ฽๎ึࠦๅ้ฮ๋ำࠬ॰")
				#else: title = name + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ॱ") + l1lll111_l1_[i]
				title = name + l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧॲ") + l1lll111_l1_[i]
				title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧॳ"),l11ll1_l1_ (u"ࠬ࠭ॴ")).strip(l11ll1_l1_ (u"࠭ࠠࠨॵ"))
				l1lllll_l1_ = url + l11ll1_l1_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪॶ")+str(size-i)
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧॷ"),l111l1_l1_+title,l1lllll_l1_,74,l1lll1_l1_)
	else:
		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨॸ"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้ืวษู่ࠣ๏ูࠠโ์า๎ํ࠭ॹ"),l11ll1_l1_ (u"ࠫࠬॺ"),9999,l1lll1_l1_)
		#l1llllll_l1_(l11ll1_l1_ (u"ࠬิืฤࠢัหึา๊ࠨॻ"),l11ll1_l1_ (u"࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ี๊้ࠩॼ"))
	return
def PLAY(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨॽ"),l11ll1_l1_ (u"ࠨࠩॾ"),url,l11ll1_l1_ (u"ࠩࠪॿ"))
	l111lll_l1_,l1ll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠪࡃࡸ࡫ࡣࡵ࡫ࡲࡲࡂ࠭ঀ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨঁ"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭ং"),headers,True,l11ll1_l1_ (u"࠭ࠧঃ"),l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠳ࡐࡍࡃ࡜ࡣࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧ঄"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠳࠰࠿ࡢࡦ࠰࠷࠵࠶࠭࠳࠷࠳ࠬ࠳࠰࠿ࠪࡣ࡮ࡳ࠲࡬ࡥࡦࡦࡥࡥࡨࡱࠧঅ"),html,re.DOTALL)
	l11l11l_l1_ = l1l1l11_l1_[0].replace(l11ll1_l1_ (u"ࠤࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࡠࡤࡲࡼࠧআ"),l11ll1_l1_ (u"ࠪࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࡡࡥࡳࡽࠦࡥࡱࡵࡲ࡭ࡩ࡫࡟ࡣࡱࡻࠫই"))
	l11l11l_l1_ = l11l11l_l1_ + l11ll1_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࡡࡥࡳࡽ࠭ঈ")
	l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡫ࡰࡴࡱ࡬ࡨࡪࡥࡢࡰࡺࠫ࠲࠯ࡅࠩࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࡤࡨ࡯ࡹࠩউ"),l11l11l_l1_,re.DOTALL)
	l1ll1l1_l1_ = len(l1111l1_l1_)-int(l1ll1l1_l1_)
	block = l1111l1_l1_[l1ll1l1_l1_]
	l1lll1ll_l1_ = []
	l1lll1l1_l1_ = {l11ll1_l1_ (u"࠭࠱࠵࠴࠶࠴࠼࠻࠸࠷࠴ࠪঊ"):l11ll1_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬঋ"),l11ll1_l1_ (u"ࠨ࠳࠷࠻࠼࠺࠸࠸࠸࠳࠵ࠬঌ"):l11ll1_l1_ (u"ࠩࡨࡷࡹࡸࡥࡢ࡯ࠪ঍"),l11ll1_l1_ (u"ࠪ࠵࠺࠶࠵࠴࠴࠻࠸࠵࠺ࠧ঎"):l11ll1_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰࡥࡳ࡭࡯ࠨএ"),
		l11ll1_l1_ (u"ࠬ࠷࠴࠳࠵࠳࠼࠵࠶࠱࠶ࠩঐ"):l11ll1_l1_ (u"࠭ࡦ࡭ࡣࡶ࡬ࡽ࠭঑"),l11ll1_l1_ (u"ࠧ࠲࠶࠸࠼࠶࠷࠷࠳࠻࠸ࠫ঒"):l11ll1_l1_ (u"ࠨࡱࡳࡩࡳࡲ࡯ࡢࡦࠪও"),l11ll1_l1_ (u"ࠩ࠴࠸࠷࠹࠰࠸࠻࠶࠴࠻࠭ঔ"):l11ll1_l1_ (u"ࠪࡺ࡮ࡳࡰ࡭ࡧࠪক"),l11ll1_l1_ (u"ࠫ࠶࠺࠳࠱࠲࠸࠶࠸࠽࠱ࠨখ"):l11ll1_l1_ (u"ࠬࡵ࡫࠯ࡴࡸࠫগ"),
		l11ll1_l1_ (u"࠭࠱࠵࠹࠺࠸࠽࠾࠲࠲࠵ࠪঘ"):l11ll1_l1_ (u"ࠧࡵࡪࡨࡺ࡮ࡪࠧঙ"),l11ll1_l1_ (u"ࠨ࠳࠸࠹࠽࠸࠷࠹࠲࠳࠺ࠬচ"):l11ll1_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩছ"),l11ll1_l1_ (u"ࠪ࠵࠹࠽࠷࠵࠺࠺࠽࠾࠶ࠧজ"):l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡵࡱࡧࡳࠬঝ")}
	items = re.findall(l11ll1_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡣࡶࡱ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࠧঞ"),block,re.DOTALL)
	for l1lllll_l1_ in items:
		l1lll1ll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭ট"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ঠ"),block,re.DOTALL)
	for l11ll11_l1_,l1lllll_l1_ in items:
		l11ll11_l1_ = l11ll11_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪড"))[-1]
		l11ll11_l1_ = l11ll11_l1_.split(l11ll1_l1_ (u"ࠩ࠱ࠫঢ"))[0]
		if l11ll11_l1_ in l1lll1l1_l1_:
			l1lll1ll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫণ")+l1lll1l1_l1_[l11ll11_l1_]+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࡡࡢࡣࡤࡧ࡫ࡰࡣࡰࠫত"))
		else: l1lll1ll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭থ")+l11ll11_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭দ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨধ"),l11ll1_l1_ (u"ࠨࠩন"),url,str(l1lll1ll_l1_))
	if not l1lll1ll_l1_:
		message = re.findall(l11ll1_l1_ (u"ࠩࡶࡹࡧ࠳࡮ࡰ࠯ࡩ࡭ࡱ࡫࠮ࠫࡁ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ঩"),block,re.DOTALL)
		if message: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫপ"),l11ll1_l1_ (u"ࠫࠬফ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧব"),message[0])
	else:
		import ll_l1_
		ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬভ"),url)
	return
def SEARCH(search):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨম"),l11ll1_l1_ (u"ࠨࠩয"),search,l11ll1_l1_ (u"ࠩࠪর"))
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ঱"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬল"): return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ঳"),l11ll1_l1_ (u"࠭ࠥ࠳࠲ࠪ঴"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ঵")+l1111ll_l1_
	results = l11111_l1_(url,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨশ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
l1llllll_l1_(l11ll1_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ携"),l11ll1_l1_ (u"࡙ࠫࡋࡓࡕࠩ搻"))
#url = l11ll1_l1_ (u"ࠬࡉ࠺࡝࡞ࡓࡳࡷࡺࡡࡣ࡮ࡨࠤࡕࡸ࡯ࡨࡴࡤࡱࡸࡢ࡜ࡌࡑࡇࡍࡤࡼ࠱࠹ࡡ࠹࠸ࡧ࡯ࡴ࡝࡞ࡎࡳࡩ࡯࡜࡝ࡲࡲࡶࡹࡧࡢ࡭ࡧࡢࡨࡦࡺࡡ࡝࡞ࡦࡥࡨ࡮ࡥ࡝࡞ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࡜࡝ࡨ࡬ࡰࡪࡥ࠰࠹࠻࠹ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫ搼")
#url = l11ll1_l1_ (u"࠭ࡣ࠻࡞࡟ࡥࡸࡪࡦ࠯࡯ࡳ࠷ࠬ搽")
#url = l11ll1_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡷࡩ࡬࠮࡮ࡲ࠶ࠫ搾")
#url = l11ll1_l1_ (u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ࡥࡸࡪࡦ࠯࡯ࡳ࠷ࠬ搿")
url = l11ll1_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠๆำี࠯࡯ࡳ࠷ࠬ摀")
url = l11ll1_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡ࡬ࡩ࡭ࡧࡢ࠸࠽࠹࠴ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ摁")
#url = url.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ摂"))
xbmc.Player().play(url)
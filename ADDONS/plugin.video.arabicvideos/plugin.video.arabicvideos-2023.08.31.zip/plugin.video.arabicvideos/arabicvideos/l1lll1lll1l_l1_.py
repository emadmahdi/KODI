# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ⌘")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡋࡇࡅࡡࠪ⌙")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๋ࠬีศำ฼อࠬ⌚"),l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊ศาษ่ะࠬ⌛"),l11ll1_l1_ (u"ࠧศฯาฯࠥอไศๆ฼หอ࠭⌜"),l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⌝"),l11ll1_l1_ (u"ࠩสัิัࠠศๆส฾ฬ์้ࠨ⌞")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l11111_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l1llll11_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⌟"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ⌠"),l11ll1_l1_ (u"ࠬ࠭⌡"),l11ll1_l1_ (u"࠭ࠧ⌢"),l11ll1_l1_ (u"ࠧࠨ⌣"),l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⌤"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⌥"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌦"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⌧"),l11ll1_l1_ (u"ࠬ࠭⌨"),449,l11ll1_l1_ (u"࠭ࠧ〈"),l11ll1_l1_ (u"ࠧࠨ〉"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⌫"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌬"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⌭")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭⌮"),l11l1l_l1_,441)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⌯"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⌰"),l11ll1_l1_ (u"ࠧࠨ⌱"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫࡟࡮ࡧࡱࡹࡤࡸࡩࡨࡪࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⌲"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⌳"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l1lllll_l1_==l11ll1_l1_ (u"ࠪࠧࠬ⌴"): continue
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌵"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⌶")+l111l1_l1_+title,l1lllll_l1_,441)
	return
def l11111_l1_(url,l111l1l1_l1_=l11ll1_l1_ (u"࠭ࠧ⌷")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⌸"),url,l11ll1_l1_ (u"ࠨࠩ⌹"),l11ll1_l1_ (u"ࠩࠪ⌺"),l11ll1_l1_ (u"ࠪࠫ⌻"),l11ll1_l1_ (u"ࠫࠬ⌼"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⌽"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ⌾"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽࡮࡬ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠱࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⌿"),block,re.DOTALL)
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		if l11ll1_l1_ (u"ࠨ࠱ࡸࡶࡱ࠵ࠧ⍀") in l1lllll_l1_: continue
		elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ⍁") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍂"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ⍃") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⍄"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⍅"),l111l1_l1_+title,l1lllll_l1_,442,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⍆"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⍇"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍈"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ⍉")+title,l1lllll_l1_,441)
	return
l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶࠤࡂ࡛ࠦ࡞ࠌࠌࡺ࡮ࡪࡥࡰࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ู้ࠪอ็ะหࠪ࠰ࠬ็๊ๅ็ࠪ࠰ࠬอฺ็์ฬࠫ࠱࠭ใๅ์หࠫ࠱࠭วฺๆส๊ࠬ࠲่ࠧัสๅࠬ࠲ࠧๆสสีฬฯࠧ࠭ࠩ฼ี฻࠭ࠬࠨ็๊ีัอๆࠨ࠮ࠪห้ฮ่ๆࠩࡠࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪ࠲ࡩ࡮ࡩࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡸࡲࡪࡹࡣࡢࡲࡨࡌ࡙ࡓࡌࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡱ࡯࡮࡬ࠫ࠱ࡷࡹࡸࡩࡱࠪࠪ࠳ࠬ࠯ࠊࠊࠋࡨࡴ࡮ࡹ࡯ࡥࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ࠬࡵ࡫ࡷࡰࡪ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡣࡱࡽ࠭ࡼࡡ࡭ࡷࡨࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࠦࡦࡰࡴࠣࡺࡦࡲࡵࡦࠢ࡬ࡲࠥࡼࡩࡥࡧࡲࡐࡎ࡙ࡔࠪ࠼ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡼࡩࡥࡧࡲࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠺࠴࠳࠮࡬ࡱ࡬࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࡦࡲ࡬ࡷࡴࡪࡥࠡࡣࡱࡨࠥ࠭วๅฯ็ๆฮ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨࡡࡐࡓࡉࡥࠧࠡ࠭ࠣࡩࡵ࡯ࡳࡰࡦࡨ࡟࠵ࡣࠊࠊࠋࠌ࡭࡫ࠦࡴࡪࡶ࡯ࡩࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳ࠻ࠌࠌࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠴࠵࠵࠯࡭ࡲ࡭ࠩࠋࠋࠌࠍࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡩࡱ࡯ࡦࠡࠩ࠲ࡥࡸࡹࡥ࡮ࡤ࡯ࡽ࠴࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠴࠵࠳࠯࡭ࡲ࡭ࠩࠋࠋࠌࡩࡱ࡯ࡦࠡࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠳࠭࡫ࡰ࡫࠮ࠐࠉࠊࡧ࡯ࡷࡪࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠵࠶࠶࠰࡮ࡳࡧࠪࠌࠌ࡭࡫ࠦࡳࡦࡳࡸࡩࡳࡩࡥ࠾࠿ࠪࠫ࠿ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠣࠤࠥ⍊")
def l1llll11_l1_(url):
	data = {l11ll1_l1_ (u"ࠬ࡜ࡩࡦࡹࠪ⍋"):1}
	headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⍌"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⍍")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭⍎"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ⍏"),l11ll1_l1_ (u"ࠪࠫ⍐"),l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⍑"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪ⍒"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ⍓"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⍔"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍕"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⍖"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⍗"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ⍘"),l11ll1_l1_ (u"ࠬ࠭⍙")).strip(l11ll1_l1_ (u"࠭ࠠࠨ⍚"))
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⍛"),l111l1_l1_+title,l1lllll_l1_,442,l1lll1_l1_)
	return
def PLAY(url):
	data = {l11ll1_l1_ (u"ࠨࡘ࡬ࡩࡼ࠭⍜"):1}
	headers = {l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⍝"):l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⍞")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ⍟"),url,data,headers,l11ll1_l1_ (u"ࠬ࠭⍠"),l11ll1_l1_ (u"࠭ࠧ⍡"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⍢"))
	html = response.content
	l1llll_l1_ = []
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡺࡥࡹࡩࡨࡂࡴࡨࡥࡒࡧࡳࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⍣"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ⍤"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭⍥"),l11ll1_l1_ (u"ࠫࠬ⍦")).strip(l11ll1_l1_ (u"ࠬࠦࠧ⍧"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⍨")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⍩")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡧࡳࡳࡽ࡬ࡰࡣࡧ࠱ࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⍪"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸ࠭࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⍫"),block,re.DOTALL)
		for title,l111lll1_l1_,l1lllll_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭⍬"),l11ll1_l1_ (u"ࠫࠬ⍭"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⍮")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⍯")+l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬ⍰")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⍱"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⍲"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ⍳"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ⍴"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ⍵"),l11ll1_l1_ (u"࠭ࠫࠨ⍶"))
	#search = unescapeHTML(search)
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⍷")+search
	l11111_l1_(url)
	return
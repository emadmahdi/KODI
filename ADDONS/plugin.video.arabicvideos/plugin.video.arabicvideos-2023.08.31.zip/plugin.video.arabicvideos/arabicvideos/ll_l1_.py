# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ傽")
#l111ll111111_l1_ = [ l11ll1_l1_ (u"࠭࡭ࡺࡵࡷࡶࡪࡧ࡭ࠨ傾"),l11ll1_l1_ (u"ࠧࡷ࡫ࡰࡴࡱ࡫ࠧ傿"),l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡵ࡭ࠨ僀"),l11ll1_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ僁") ]
l111ll111111_l1_ = []
headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ僂"):l11ll1_l1_ (u"ࠫࠬ僃")}
def l11_l1_(l1lll1ll_l1_,source,type,url):
	#DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ืวษูࠣห้๋ๆศีหࠫ僄"),l1lll1ll_l1_)
	if not l1lll1ll_l1_:
		LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ僅"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ僆")+source+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ僇")+type+l11ll1_l1_ (u"ࠩࠣࡡࠬ僈"))
		l11l111111ll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ僉"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ僊"),l11ll1_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ僋"))
		datetime = time.strftime(l11ll1_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ僌"),time.gmtime(now))
		line = datetime,url
		key = source+l11ll1_l1_ (u"ࠧࠡࠢࠣࠤࠬ働")+addon_version+l11ll1_l1_ (u"ࠨࠢࠣࠤࠥ࠭僎")+str(kodi_version)
		message = l11ll1_l1_ (u"ࠩࠪ像")
		if key not in list(l11l111111ll_l1_.keys()): l11l111111ll_l1_[key] = [line]
		else:
			if url not in str(l11l111111ll_l1_[key]): l11l111111ll_l1_[key].append(line)
			else: message = l11ll1_l1_ (u"ࠪࡠࡳࠦ็ัษࠣห้็๊ะ์๋ࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣฮ฾๋ไࠨ僐")
		total = 0
		for key in list(l11l111111ll_l1_.keys()):
			l11l111111ll_l1_[key] = list(set(l11l111111ll_l1_[key]))
			total += len(l11l111111ll_l1_[key])
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ僑"),l11ll1_l1_ (u"ࠬ࠭僒"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ僓"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ僔")+message+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠧ僕")+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ僖")+l11ll1_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠศๆๅหห๋ษࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥ࠭僗")+str(total))
		if total>=5:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ僘"),l11ll1_l1_ (u"ࠬ࠭僙"),l11ll1_l1_ (u"࠭ࠧ僚"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ僛"),l11ll1_l1_ (u"ࠨษ็ฬึ์วๆฮࠣะ๊฿ࠠใษษ้ฮࠦแ๋้สࠤ࠺ࠦแ๋ัํ์์อสࠡๆ่ࠤ๏าฯࠡษ็ฬึ์วๆฮ่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬู๊อ้ࠡำ๋ࠥอไใษษ้ฮࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥหัิษ็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢๅฬ้ࠦๅิฯ๊หࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไๆสิ้ัࠦศโฯุࠤ์ึ็ࠡษ็ๅ๏ี๊้้สฮࠥลࠡࠢࠩ僜"))
			if l1ll111ll1_l1_==1:
				l11l11111l1l_l1_ = l11ll1_l1_ (u"ࠩࠪ僝")
				for key in list(l11l111111ll_l1_.keys()):
					l11l11111l1l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭僞")+key
					l11111l1l111_l1_ = sorted(l11l111111ll_l1_[key],reverse=False,key=lambda l11llll1ll11_l1_: l11llll1ll11_l1_[0])
					for datetime,url in l11111l1l111_l1_:
						l11l11111l1l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ僟")+datetime+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠪ僠")+l1111_l1_(url)
					l11l11111l1l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ僡")
				import l1l111l11ll_l1_
				l1ll1ll1l111_l1_ = l11ll1_l1_ (u"ࠧࡂࡘ࠽ࠤࠬ僢")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠨ࠯࡙࡭ࡩ࡫࡯ࡴࠩ僣")
				succeeded = l1l111l11ll_l1_.l111ll1l1ll_l1_(l1ll1ll1l111_l1_,l11ll1_l1_ (u"ࠩࠪ僤"),False,l11ll1_l1_ (u"ࠪࠫ僥"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ僦"),l11ll1_l1_ (u"ࠬ࠭僧"),l11l11111l1l_l1_)
				if succeeded: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ僨"),l11ll1_l1_ (u"ࠧࠨ僩"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ僪"),l11ll1_l1_ (u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬ僫"))
				else: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ僬"),l11ll1_l1_ (u"ࠫࠬ僭"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ僮"),l11ll1_l1_ (u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫ僯"))
			if l1ll111ll1_l1_!=-1:
				l11l111111ll_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ僰"),l11ll1_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ僱"))
		if l11l111111ll_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ僲"),l11ll1_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ僳"),l11l111111ll_l1_,PERMANENT_CACHE)
		return
	l1lll1ll_l1_ = list(set(l1lll1ll_l1_))
	l1lll111_l1_,l1llll_l1_ = l11111lllll1_l1_(l1lll1ll_l1_,source)
	l11111l11lll_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ僴"))
	l1111l1111l1_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ僵"))
	l11111l1l1l1_l1_ = len(l1llll_l1_)-l11111l11lll_l1_-l1111l1111l1_l1_
	l1111l11l1ll_l1_ = l11ll1_l1_ (u"࠭ๅีษ๊ำฮࡀࠧ僶")+str(l11111l11lll_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠤฯำๅ๋ๆ࠽ࠫ僷")+str(l1111l1111l1_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࠤࠥษฮา๋࠽ࠫ僸")+str(l11111l1l1l1_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ價"),l11ll1_l1_ (u"ࠪࠫ僺"),str(l11111l11lll_l1_),str(l1111l1111l1_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1111l11l1ll_l1_, l1llll_l1_)
	if not l1llll_l1_:
		result = l11ll1_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ僻")
		l11l1l11l111_l1_ = l11ll1_l1_ (u"ࠬ࠭僼")
	else:
		while True:
			l11l1l11l111_l1_ = l11ll1_l1_ (u"࠭ࠧ僽")
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1111l11l1ll_l1_,l1lll111_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ僾")
			else:
				title = l1lll111_l1_[l1l_l1_]
				l1lllll_l1_ = l1llll_l1_[l1l_l1_]
				#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ僿"),l11ll1_l1_ (u"ࠩࠪ儀"),title,l1lllll_l1_)
				if l11ll1_l1_ (u"ࠪื๏ืแาࠩ儁") in title and l11ll1_l1_ (u"ࠫ࠷๋ฬ่๊็࠶ࠬ儂") in title:
					LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ儃"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡪࡲࡥࡤࡶࡨࡨ࡙ࠥࡥࡳࡸࡨࡶࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ億")+title+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ儅")+l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ儆"))
					import l1l111l11ll_l1_
					l1l111l11ll_l1_.MAIN(156)
					result = l11ll1_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭儇")
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ儈"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ儉")+title+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ儊")+l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ儋"))
					result,l11l1l11l111_l1_,l11ll1l11ll1_l1_ = l1111l1l1l1l_l1_(l1lllll_l1_,source,type)
					#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ儌"),l11ll1_l1_ (u"ࠨࠩ儍"),result,l11l1l11l111_l1_)
			if l11ll1_l1_ (u"ࠩ࡟ࡲࠬ儎") not in l11l1l11l111_l1_: l11l11ll111l_l1_,l11l11ll111_l1_ = l11l1l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ儏")
			else: l11l11ll111l_l1_,l11l11ll111_l1_ = l11l1l11l111_l1_.split(l11ll1_l1_ (u"ࠫࡡࡴࠧ儐"),1)
			if result in [l11ll1_l1_ (u"ࠬࡋࡘࡊࡖࠪ儑"),l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ儒"),l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ儓"),l11ll1_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ儔")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ儕"),l11ll1_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ儖"),l11ll1_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ儗")]: break
			elif result not in [l11ll1_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ儘"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ儙")]: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ儚"),l11ll1_l1_ (u"ࠨࠩ儛"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ儜"),l11ll1_l1_ (u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์࠭儝")+l11ll1_l1_ (u"ࠫࡡࡴࠧ儞")+l11l11ll111l_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ償")+l11l11ll111_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ儠"),l11ll1_l1_ (u"ࠧࠨ儡"),l11ll1_l1_ (u"ࠨࠩ儢"),str(l11ll1l11ll1_l1_))
	if result==l11ll1_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭儣") and len(l1lll111_l1_)>0: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ儤"),l11ll1_l1_ (u"ࠫࠬ儥"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ儦"),l11ll1_l1_ (u"࠭ำ๋ำไีࠥํะศࠢส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠤัืศࠡใํำ๏๎ࠠ฻์ิ๋ࠬ儧")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ儨")+l11l1l11l111_l1_)
	elif result in [l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ儩"),l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ優")] and l11l1l11l111_l1_!=l11ll1_l1_ (u"ࠪࠫ儫"): DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ儬"),l11ll1_l1_ (u"ࠬ࠭儭"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ儮"),l11l1l11l111_l1_)
	#elif l11l1l11l111_l1_==l11ll1_l1_ (u"ࠧࡓࡇࡗ࡙ࡗࡔ࡟ࡕࡑࡢ࡝ࡔ࡛ࡔࡖࡄࡈࠫ儯"): result = l11ll1l11ll1_l1_
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࡶࡪࡹࡵ࡭ࡶࠣ࡭ࡳ࡛ࠦࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ࠲ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫࡢࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡍࡑࡊࡋࡎࡔࡇࠩࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠯ࠫࠨࠢࠣࠤ࡙࡫ࡳࡵ࠼ࠣࠤࠥ࠭ࠫࡴࡻࡶ࠲ࡦࡸࡧࡷ࡝࠳ࡡ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠳࡟ࠬࠎࠎࠏࡸࡣ࡯ࡦࡴࡱࡻࡧࡪࡰ࠱ࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬࡦࡪࡤࡰࡰࡢ࡬ࡦࡴࡤ࡭ࡧ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳ࡒࡩࡴࡶࡌࡸࡪࡳࠨࠪࠫࠍࠍࠎࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲ࡑ࡯ࡳࡵࡋࡷࡩࡲ࠮ࡰࡢࡶ࡫ࡁࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡅ࡭ࡰࡦࡨࡁ࠶࠺࠳ࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮ࠥ࠴ࡈࡹࠩ࠸ࡊࡧࡸࡤ࠴ࡴࡽ࡜ࡴࡸ࠻ࡔࠫ࠮ࠐࠉࠊࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡲ࡯ࡥࡾ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨ࡯ࡺ࠶࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯࠲࡭ࡵ࡮࡯࡯ࡧ࠲࠵࠷࠹࠴࠵࠹࠱ࡱࡵ࠺ࠧ࠭ࡲ࡯ࡥࡾࡥࡩࡵࡧࡰ࠭ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆส่฿อมࠨ࠮ࠪࠫ࠮ࠐࠉࠣࠤࠥ儰")
	return result
	#if source==l11ll1_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ儱"): l111l1_l1_ = l11ll1_l1_ (u"ࠪࡌࡑࡇࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儲")
	#elif source==l11ll1_l1_ (u"ࠫ࠹ࡎࡅࡍࡃࡏࠫ儳"): l111l1_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡉࡇࡏࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭儴")
	#elif source==l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ儵"): l111l1_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡄࡏࡒ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ儶")
	#elif source==l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ儷"): l111l1_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡘࡎ࠴ࠡࠩ儸")
	#size = len(l1ll1ll11l_l1_)
	#for i in range(0,size):
	#	title = l11l1l111ll1_l1_[i]
	#	l1lllll_l1_ = l1ll1ll11l_l1_[i]
	#	addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ儹"),l111l1_l1_+title,l1lllll_l1_,160,l11ll1_l1_ (u"ࠫࠬ儺"),l11ll1_l1_ (u"ࠬ࠭儻"),source)
def l1111l1l1l1l_l1_(url,source,type=l11ll1_l1_ (u"࠭ࠧ儼")):
	url = url.strip(l11ll1_l1_ (u"ࠧࠡࠩ儽")).strip(l11ll1_l1_ (u"ࠨࠨࠪ儾")).strip(l11ll1_l1_ (u"ࠩࡂࠫ儿")).strip(l11ll1_l1_ (u"ࠪ࠳ࠬ兀"))
	l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111111l1lll_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ允"),l11ll1_l1_ (u"ࠬ࠭兂"),url,l11l1l11l111_l1_)
	if l11l1l11l111_l1_==l11ll1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ元"): return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭兄"), l1lll111_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ充")
			else:
				l111l11l1l1l_l1_ = l1llll_l1_[l1l_l1_]
				title = l1lll111_l1_[l1l_l1_]
				LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ兆"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡴࡧ࡯ࡩࡨࡺࡥࡥࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ兇")+title+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ先")+str(l111l11l1l1l_l1_)+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ光"))
				if l11ll1_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ兊") in l111l11l1l1l_l1_ and l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ克") in l111l11l1l1l_l1_:
					l111l1ll1l11_l1_,l11ll11llll1_l1_,l11ll1l11ll1_l1_ = l11l111l1111_l1_(l111l11l1l1l_l1_)
					if l11ll1l11ll1_l1_: l111l11l1l1l_l1_ = l11ll1l11ll1_l1_[0]
					else: l111l11l1l1l_l1_ = l11ll1_l1_ (u"ࠨࠩ兌")
				if not l111l11l1l1l_l1_: result = l11ll1_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭免")
				else: result = PLAY_VIDEO(l111l11l1l1l_l1_,source,type)
			if result in [l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ兎"),l11ll1_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ兏")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ児"),l11ll1_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ兑"),l11ll1_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭兒")]: break
			else: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ兓"),l11ll1_l1_ (u"ࠩࠪ兔"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭兕"),l11ll1_l1_ (u"ࠫฬ๊ๅๅใฺ่๊๊ࠣࠦ็็ࠤัืศࠡ็็ๅࠥเ๊า้ࠪ兖"))
	else:
		result = l11ll1_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ兗")
		l111lll1l1_l1_ = l11l1lll11_l1_(url)
		if l111lll1l1_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11l1l11l111_l1_,l1llll_l1_
	#title = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠢ兘") )
	#if l11ll1_l1_ (u"ࠧิ์ิๅึูࠦศ็้ࠣัํ่ๅࠩ兙") in title:
	#	import l1l111l11ll_l1_
	#	l1l111l11ll_l1_.MAIN(156)
	#	return l11ll1_l1_ (u"ࠨࠩ党")
def l1111111111l_l1_(url,source):
	# url = url+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ兛")+name+l11ll1_l1_ (u"ࠪࡣࡤ࠭兜")+type+l11ll1_l1_ (u"ࠫࡤࡥࠧ兝")+l11lll1_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࠨ兞")+l111lll1_l1_
	# url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡬ࡹࡤࡱ࠳ࡴࡥࡵࡁࡱࡥࡲ࡫ࡤ࠾ࡣ࡮ࡻࡦࡳ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯ࡳ࠸ࡤࡥ࠷࠳࠲ࠪ兟")
	l111lll_l1_,l11l111lll1l_l1_,server,l111l11lllll_l1_,name,type,l11lll1_l1_,l111lll1_l1_ = url,l11ll1_l1_ (u"ࠧࠨ兠"),l11ll1_l1_ (u"ࠨࠩ兡"),l11ll1_l1_ (u"ࠩࠪ兢"),l11ll1_l1_ (u"ࠪࠫ兣"),l11ll1_l1_ (u"ࠫࠬ兤"),l11ll1_l1_ (u"ࠬ࠭入"),l11ll1_l1_ (u"࠭ࠧ兦")
	#source = source.lower()
	if l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ內") in url:
		l111lll_l1_,l11l111lll1l_l1_ = url.split(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ全"),1)
		l11l111lll1l_l1_ = l11l111lll1l_l1_+l11ll1_l1_ (u"ࠩࡢࡣࠬ兩")+l11ll1_l1_ (u"ࠪࡣࡤ࠭兪")+l11ll1_l1_ (u"ࠫࡤࡥࠧ八")+l11ll1_l1_ (u"ࠬࡥ࡟ࠨ公")
		l11l111lll1l_l1_ = l11l111lll1l_l1_.lower()
		name,type,l11lll1_l1_,l111lll1_l1_,l1llll1ll11l_l1_ = l11l111lll1l_l1_.split(l11ll1_l1_ (u"࠭࡟ࡠࠩ六"))[:5]
	if l111lll1_l1_==l11ll1_l1_ (u"ࠧࠨ兮"): l111lll1_l1_ = l11ll1_l1_ (u"ࠨ࠲ࠪ兯")
	else: l111lll1_l1_ = l111lll1_l1_.replace(l11ll1_l1_ (u"ࠩࡳࠫ兰"),l11ll1_l1_ (u"ࠪࠫ共")).replace(l11ll1_l1_ (u"ࠫࠥ࠭兲"),l11ll1_l1_ (u"ࠬ࠭关"))
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"࠭࠿ࠨ兴")).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ兵")).strip(l11ll1_l1_ (u"ࠨࠨࠪ其"))
	server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ具"))
	if name: l111l11lllll_l1_ = name
	#elif source: l111l11lllll_l1_ = source
	else: l111l11lllll_l1_ = server
	l111l11lllll_l1_ = SERVER(l111l11lllll_l1_,l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ典"))
	name = name.replace(l11ll1_l1_ (u"๊ࠫฮวีำࠪ兹"),l11ll1_l1_ (u"ࠬ࠭兺")).replace(l11ll1_l1_ (u"࠭ำ๋ำไีࠬ养"),l11ll1_l1_ (u"ࠧࠨ兼")).replace(l11ll1_l1_ (u"ࠨษ็ࠤࠬ兽"),l11ll1_l1_ (u"ࠩࠣࠫ兾")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭兿"),l11ll1_l1_ (u"ࠫࠥ࠭冀"))
	l11l111lll1l_l1_ = l11l111lll1l_l1_.replace(l11ll1_l1_ (u"๋ࠬศศึิࠫ冁"),l11ll1_l1_ (u"࠭ࠧ冂")).replace(l11ll1_l1_ (u"ࠧิ์ิๅึ࠭冃"),l11ll1_l1_ (u"ࠨࠩ冄")).replace(l11ll1_l1_ (u"ࠩส่ࠥ࠭内"),l11ll1_l1_ (u"ࠪࠤࠬ円")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ冇"),l11ll1_l1_ (u"ࠬࠦࠧ冈"))
	l111l11lllll_l1_ = l111l11lllll_l1_.replace(l11ll1_l1_ (u"࠭ๅษษืีࠬ冉"),l11ll1_l1_ (u"ࠧࠨ冊")).replace(l11ll1_l1_ (u"ࠨีํีๆืࠧ冋"),l11ll1_l1_ (u"ࠩࠪ册")).replace(l11ll1_l1_ (u"ࠪห้ࠦࠧ再"),l11ll1_l1_ (u"ࠫࠥ࠭冎")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ冏"),l11ll1_l1_ (u"࠭ࠠࠨ冐"))
	return l111lll_l1_,l11l111lll1l_l1_,server,l111l11lllll_l1_,name,type,l11lll1_l1_,l111lll1_l1_
def l11l1l111111_l1_(url,source):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ冑"),l11ll1_l1_ (u"ࠨࠩ冒"),url,l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡃࡅࡐࡊ࠭冓"))
	# l1lll11ll_l1_	: سيرفر خاص
	# l11l11l1l1l1_l1_		: سيرفر محدد
	# l11l111ll1ll_l1_		: سيرفر عام معروف
	# l1ll1l11l_l1_	: سيرفر عام خارجي
	# l11111l1ll1l_l1_	: سيرفر عام خارجي
	l111l111ll11_l1_,name,l1lll11ll_l1_,l11l111ll1ll_l1_,l1ll1l11l_l1_,l11l11l1l1l1_l1_,l11111l1ll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ冔"),l11ll1_l1_ (u"ࠫࠬ冕"),None,None,None,None,None
	l111lll_l1_,l11l111lll1l_l1_,server,l111l11lllll_l1_,name,type,l11lll1_l1_,l111lll1_l1_ = l1111111111l_l1_(url,source)
	if l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭冖") in url:
		if   type==l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨࠬ冗"): type = l11ll1_l1_ (u"ࠧࠡࠩ冘")+l11ll1_l1_ (u"ࠨ็ไฺ้࠭写")
		elif type==l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ冚"): type = l11ll1_l1_ (u"ࠪࠤࠬ军")+l11ll1_l1_ (u"๋ࠫࠪิศ้าอࠬ农")
		elif type==l11ll1_l1_ (u"ࠬࡨ࡯ࡵࡪࠪ冝"): type = l11ll1_l1_ (u"࠭ࠠࠨ冞")+l11ll1_l1_ (u"ุ่ࠧࠦࠧฬํฯส๋ࠢฮา๋๊ๅࠩ冟")
		elif type==l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ冠"): type = l11ll1_l1_ (u"ࠩࠣࠫ冡")+l11ll1_l1_ (u"ࠪࠩࠪࠫสฮ็ํ่ࠬ冢")
		elif type==l11ll1_l1_ (u"ࠫࠬ冣"): type = l11ll1_l1_ (u"ࠬࠦࠧ冤")+l11ll1_l1_ (u"࠭ࠥࠦࠧࠨࠫ冥")
		if l11lll1_l1_!=l11ll1_l1_ (u"ࠧࠨ冦"):
			if l11ll1_l1_ (u"ࠨ࡯ࡳ࠸ࠬ冧") not in l11lll1_l1_: l11lll1_l1_ = l11ll1_l1_ (u"ࠩࠨࠫ冨")+l11lll1_l1_
			l11lll1_l1_ = l11ll1_l1_ (u"ࠪࠤࠬ冩")+l11lll1_l1_
		if l111lll1_l1_!=l11ll1_l1_ (u"ࠫࠬ冪"):
			l111lll1_l1_ = l11ll1_l1_ (u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨ冫")+l111lll1_l1_
			l111lll1_l1_ = l11ll1_l1_ (u"࠭ࠠࠨ冬")+l111lll1_l1_[-9:]
	#if any(value in server for value in l111ll111111_l1_): return l11ll1_l1_ (u"ࠧࠨ冭")
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ冮"),l11ll1_l1_ (u"ࠩࠪ冯"),name,l111l11lllll_l1_)
	if   l11ll1_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ冰")		in source: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ冱")		in source: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ冲")
	elif l11ll1_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ决")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ冴")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ况")	in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ冶")		in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ冷")
	#elif l11ll1_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡷࡹࡧࡴࡪࡱࡱࠫ冸") in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ冹")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭冺")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	#elif l11ll1_l1_ (u"ࠧࡱࡥࡵࡩࡻ࡯ࡥࡸࠩ冻")	in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ冼")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠩࡷ࠻ࡲ࡫ࡥ࡭ࠩ冽")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ冾")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭冿")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ净")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣࠩ凁")	in name:   l1lll11ll_l1_	= l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ凂")
	elif l11ll1_l1_ (u"ࠨใฯีࠬ凃")			in name:   l1lll11ll_l1_	= l11ll1_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ凄")
	elif l11ll1_l1_ (u"ࠪๅู้ื๋่ࠪ凅")		in name:   l1lll11ll_l1_	= l11ll1_l1_ (u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧ准")
	elif l11ll1_l1_ (u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬ凇")		in l111lll_l1_:   l1lll11ll_l1_	= l11ll1_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭凈")
	elif l11ll1_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ凉")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ凊")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ凋")		in name:   l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ凌")	in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ凍")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ凎")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ减")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ凐")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ凑")		in server: l1lll11ll_l1_	= l111l11lllll_l1_
	#elif l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹ࠱ࡲࡪࡺࠧ凒")	in l111lll_l1_:   l1lll11ll_l1_	= l11ll1_l1_ (u"ࠪࠤࠬ凓")
	elif l11ll1_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭凔")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ凕")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭凖")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ凗")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ凘")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ凙")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠪࡽࡴࡻࡴࡶࠩ凚")	 	in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ凛")
	elif l11ll1_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ凜")	 	in server: l1lll11ll_l1_	= l11ll1_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ凝")
	elif l11ll1_l1_ (u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ凞")	in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ凟")
	elif l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ几")		in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ凡")
	elif l11ll1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭凢")		in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ凣")
	elif l11ll1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ凤")	in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭凥")
	elif l11ll1_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ処")	in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩ凧")
	elif l11ll1_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ凨")		in server: l1lll11ll_l1_	= l11ll1_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ凩")
	elif l11ll1_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ凪")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ凫")
	elif l11ll1_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ凬")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ凭")
	elif l11ll1_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ凮")	 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠪࡧࡦࡺࡣࡩࠩ凯")
	elif l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ凰")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭凱")
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ凲")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭凳")
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨ࡭ࡪࠧ凴")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠩࡰࡽࡻ࡯ࡤࠨ凵")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠪࡱࡾࡼࡩࡪࡦࠪ凶")		in server: l11l11l1l1l1_l1_	= l111l11lllll_l1_
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭凷")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ凸")
	elif l11ll1_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ凹")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠧࡨࡱࡹ࡭ࡩ࠭出")
	elif l11ll1_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ击") 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ凼")
	elif l11ll1_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭函")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ凾")
	elif l11ll1_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ凿")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫ刀")
	elif l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ刁") 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ刂")
	elif l11ll1_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ刃")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ刄")
	elif l11ll1_l1_ (u"ࠫࡺࡶࡰࠨ刅") 			in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠬࡻࡰࡣࡱࡰࠫ分")
	elif l11ll1_l1_ (u"࠭ࡵࡱࡤࠪ切") 			in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭刈")
	elif l11ll1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ刉") 		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ刊")
	elif l11ll1_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ刋") 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭刌")
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ刍")		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"࠭ࡶࡪࡦࡥࡳࡧ࠭刎")
	elif l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ刏") 		in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ刐")
	elif l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭刑") 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ划")
	elif l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ刓")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ刔")
	elif l11ll1_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ刕")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ刖")
	#elif l11ll1_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ列") 	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠩࡸࡴࡹࡵࡢࡰࡺࠪ刘")
	#elif l11ll1_l1_ (u"ࠪࡹࡵࡺ࡯ࡴࡶࡵࡩࡦࡳࠧ则")	in server: l11l111ll1ll_l1_	= l11ll1_l1_ (u"ࠫࡺࡶࡴࡰࡵࡷࡶࡪࡧ࡭ࠨ刚")
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࡷࡵࡰ࠰࠭࠽࠾࠿ࠪ࠯ࡺࡸ࡬࠳ࠫࠍࠍࠎࡺࡲࡺ࠼ࠍࠍࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠍࠍࠎࠏࡲࡦࡵࡲࡰࡻ࡫ࡲࠡ࠿ࠣࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲ࠮ࡉࡱࡶࡸࡪࡪࡍࡦࡦ࡬ࡥࡋ࡯࡬ࡦࠪࡸࡶࡱ࠸ࠩ࠯ࡸࡤࡰ࡮ࡪ࡟ࡶࡴ࡯ࠬ࠮ࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠊࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࡵ࠾ࠏࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠲࠳࠴࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡆࡢ࡮ࡶࡩࠏࠏࠉࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠯ࡱࡵ࡫ࠏࠏࠉࠊ࡮࡬ࡷࡹࡥࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡶࡧࡰ࠲ࡵࡲࡨ࠰ࡪ࡭ࡹ࡮ࡵࡣ࠰࡬ࡳ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡤ࡭࠱ࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡸ࡯ࡴࡦࡵ࠱࡬ࡹࡳ࡬ࠨࠌࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࡰ࡮ࡹࡴࡠࡷࡵࡰ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡓࡐࡎ࡙ࡅࡇࡒࡅ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾ࡸࡰࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡭ࡺ࡭࡭࠼ࠍࠍࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰࡠ࠶࡝࠯࡮ࡲࡻࡪࡸࠨࠪࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࡭࡫ࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁࡨ࠾ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀ࠴ࡲࡩ࠿ࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠴࠵࠶࠷ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ࠯ࠊࠊࠋࠌࠍࡵࡧࡲࡵࡵࠣࡁࠥࡹࡥࡳࡸࡨࡶ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠴ࠧࠪࠌࠌࠍࠎࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡲࡥ࡯ࠪࡳࡥࡷࡺࠩ࠽࠶࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࠍࡪࡲࡩࡧࠢࡳࡥࡷࡺࠠࡪࡰࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࠎࠏࠉࠊࠋࡥࡶࡪࡧ࡫ࠋࠋࠥࠦࠧ创")
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ刜"),l11ll1_l1_ (u"ࠧࠨ初"),url,l111lll_l1_)
	if   l1lll11ll_l1_:	l111l111ll11_l1_,name = l11ll1_l1_ (u"ࠨะสูࠬ刞"),l1lll11ll_l1_
	elif l11l11l1l1l1_l1_:		l111l111ll11_l1_,name = l11ll1_l1_ (u"ࠩࠨ้าีฯࠨ刟"),l11l11l1l1l1_l1_
	elif l11l111ll1ll_l1_:		l111l111ll11_l1_,name = l11ll1_l1_ (u"ࠪࠩࠪ฿วๆ่ࠢ฽ึ๎แࠨ删"),l11l111ll1ll_l1_
	elif l1ll1l11l_l1_:	l111l111ll11_l1_,name = l11ll1_l1_ (u"ฺࠫࠪࠫࠥษ่ࠤำอัอ์ࠪ刡"),l1ll1l11l_l1_
	elif l11111l1ll1l_l1_:	l111l111ll11_l1_,name = l11ll1_l1_ (u"ࠬࠫࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ刢"),l111l11lllll_l1_
	else:			l111l111ll11_l1_,name = l11ll1_l1_ (u"࠭ࠥࠦࠧࠨࠩ฾อๅࠡ็ฯ๋ํ๊ࠧ刣"),l111l11lllll_l1_
	return l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࠪࡴࡱࡧࡹࡳ࠰࠷࡬ࡪࡲࡡ࡭ࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊࡲࡵ࡭ࡻࡧࡴࡦࠢࡀࠤࠬ࡮ࡥ࡭ࡣ࡯ࠫࠏࠏࡥ࡭࡫ࡩࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡨࡷࡹࡸࡥࡢ࡯ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡴࡩࡧࡹ࡭ࡩ࡫࡯ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡦࡸ࠱࡭ࡴ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹࡩࡻ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹ࡭ࡩࡨ࡯࡮ࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡨࡥࠩࠣࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡪࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠏࠏࠢࠣࠤ判")
def l1111ll111ll_l1_(url,source):
	l111lll_l1_,l11l111lll1l_l1_,server,l111l11lllll_l1_,name,type,l11lll1_l1_,l111lll1_l1_ = l1111111111l_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ別"),l11ll1_l1_ (u"ࠩࠪ刦"),l11l11l1l1l1_l1_,server)
	#if l11ll1_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ刧")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ刨"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ利"))
	#if any(value in server for value in l111ll111111_l1_): l1lll111_l1_,l1llll_l1_ = [l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ刪")],[]
	if   l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭别")		in source: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11llll_l1_(l111lll_l1_,name)
	elif l11ll1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ刬")		in source: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llll1l_l1_(l111lll_l1_,type,l111lll1_l1_)
	elif l11ll1_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ刭")		in source: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1l111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ刮")		in source: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llllll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭刯")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1l1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨ到")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭刱")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11ll1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ刲")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1ll11ll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ刳")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1ll11ll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦࠬ刴")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1lll111l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ刵")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1lll1lll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ制")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llll11lll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ刷")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llll11lll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ券")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1lll1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ刹")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1lll11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ刺")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1l1l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ刻")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111l11111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡺࡸ࠺ࡵࠨ刼")			in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1111111l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ刽")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1l1l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭刾")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ刿")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ剀")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ剁")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l111l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ剂")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1l1ll1l1l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ剃")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ剄")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11lll1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ剅")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭剆")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡴࡦࡥ࡫ࠫ則")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡳࡣࡷࡩࠬ剈")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡳࡧࡷ࡫ࡶࡪࡧࡺࠫ剉")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ削")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111ll1l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ剋")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬ࠭剌"),[l11ll1_l1_ (u"࠭ࠧ前")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ剎")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧ剏")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l11111l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ剐") 		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠪࠫ剑"),[l11ll1_l1_ (u"ࠫࠬ剒")],[l111lll_l1_]
	else: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ剓"),[l11ll1_l1_ (u"࠭ࠧ剔")],[l111lll_l1_]
	return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
def l11l111ll11l_l1_(url,source):
	server = SERVER(url,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ剕"))
	#if l11ll1_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭剖")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ剗"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ剘"))
	#if any(value in server for value in l111ll111111_l1_): l1lll111_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗࡋࡓࡐࡎ࡙ࡉࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡦࡴࡹࡩࡷ࠭剙")],[]
	l1111ll111l1_l1_ = False
	if   l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ剚")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l1ll1ll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭剛")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l1ll1ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷࠫ剜") in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l1l111ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ剝")	in url: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111ll1111l1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ剞")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ剟")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l11l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ剠")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11lll1l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ剡")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l111l1111_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ剢")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1ll1l1l111_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ剣")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111lll1lll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ剤")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llllll1l11l_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ剥")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l111l111_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ剦")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111lllll11l_l1_(url)
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ剧")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111llllll11_l1_(url)
	elif l11ll1_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ剨")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111llllll11_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ剩")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ剪")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ剫")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡮ࡤࠨ剬")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ剭")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡪࡸ࡬ࡨࡪࡵࠧ剮")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡱࡥࡥࠬ副")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llllllllll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡶࡴࡪ࡫ࡤࠨ剰")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llllllllll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡶࡲࡥࡥࡲ࠭剱") 		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࠩ割"),[l11ll1_l1_ (u"ࠩࠪ剳")],[url]
	#elif l11ll1_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ剴")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1llllll1l111_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭創") 	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l1llll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ剶")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111ll1llll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲ࡬ࡴ࠭剷")in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l11ll1l1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ剸") 	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l1111l111_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ剹")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111ll1ll11_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧ࠭剺") 			in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1lllll1llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡹࡵࡶࠧ剻") 			in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1lllll1llll1_l1_(url)
	#elif l11ll1_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ剼") 	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l11111ll_l1_(url)
	#elif l11ll1_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ剽")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l11111ll_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭剾") 		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111llll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ剿") 	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l1ll1lll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ劀")		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111ll1l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ劁") 		in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111l1l1111_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ劂") 	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111ll1l1l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ劃")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111l11111l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ劄")	in server: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111l1111lll_l1_(url)
	else: l1111ll111l1_l1_ = True
	if l1111ll111l1_l1_ or l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ劅") in l11l1l11l111_l1_:
		l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶ࠦࡆࡢ࡫࡯ࡩࡩ࠭劆"),[],[]
	return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆࡕࡗࡖࡊࡇࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡌࡕࡕࡏࡎࡌࡑࡎ࡚ࡅࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡏࡎࡕࡑࡘࡔࡑࡕࡁࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡘࡍࡋࡖࡊࡆࡈࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡅࡗࡋࡒࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡊࡈࡐࡆࡒࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡤࡲࡱࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡅࡓࡒ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡩࡦࠪࠤࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡊࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡕࡋࡅࡗࡋࠨࡶࡴ࡯࠭ࠏࠏࠢࠣࠤ劇")
def	l111l1ll1111_l1_(l11ll1l1lll1_l1_):
	if l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ劈") in str(type(l11ll1l1lll1_l1_)):
		l1l1_l1_ = []
		for l1lllll_l1_ in l11ll1l1lll1_l1_:
			if l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ劉") in str(type(l1lllll_l1_)):
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡸࠧ劊"),l11ll1_l1_ (u"ࠬ࠭劋")).replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ劌"),l11ll1_l1_ (u"ࠧࠨ劍")).strip(l11ll1_l1_ (u"ࠨࠢࠪ劎"))
			l1l1_l1_.append(l1lllll_l1_)
	else: l1l1_l1_ = l11ll1l1lll1_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡶࠬ劏"),l11ll1_l1_ (u"ࠪࠫ劐")).replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ劑"),l11ll1_l1_ (u"ࠬ࠭劒")).strip(l11ll1_l1_ (u"࠭ࠠࠨ劓"))
	return l1l1_l1_
def l111111l1lll_l1_(url,source):
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ劔"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ劕")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ劖"))
	l11111l1ll1l_l1_,l1lllll_l1_,l111l1ll111l_l1_ = l11ll1_l1_ (u"ࠪࡍࡓ࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠧ劗"),l11ll1_l1_ (u"ࠫࠬ劘"),l11ll1_l1_ (u"ࠬ࠭劙")
	l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l1111ll111ll_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ劚"),l11ll1_l1_ (u"ࠧࠨ力"),l11ll1_l1_ (u"ࠨࠩ劜"),l11l1l11l111_l1_)
	l1llll_l1_ = l111l1ll1111_l1_(l1llll_l1_)
	if l11l1l11l111_l1_==l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ劝"): return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	elif l1llll_l1_: l1lllll_l1_ = l1llll_l1_[0]
	if l11l1l11l111_l1_==l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭办"):
		#l11l1l11l111_l1_ = l11l1l11l111_l1_.replace(l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ功"),l11ll1_l1_ (u"ࠬ࠭加"))
		l11111l1ll1l_l1_ = l11ll1_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠬ务")
		l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l111ll11l_l1_(l1lllll_l1_,source)
		l1llll_l1_ = l111l1ll1111_l1_(l1llll_l1_)
		if l11l1l11l111_l1_==l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ劢"): return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
		elif l11ll1_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ劣") in l11l1l11l111_l1_:
			l111l1ll111l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠪ劤")+l11l1l11l111_l1_
			l11111l1ll1l_l1_ = l11ll1_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ劥")
			l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l111ll111_l1_(l1lllll_l1_,source)
			l1llll_l1_ = l111l1ll1111_l1_(l1llll_l1_)
			if l11l1l11l111_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ劦"): return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
			elif l11ll1_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ劧") in l11l1l11l111_l1_:
				l111l1ll111l_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ动")+l11l1l11l111_l1_
				l11111l1ll1l_l1_ = l11ll1_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭助")
				l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11l111l1lll_l1_(l1lllll_l1_,source)
				l1llll_l1_ = l111l1ll1111_l1_(l1llll_l1_)
				if l11l1l11l111_l1_==l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭努"): return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
				elif l11ll1_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ劫") in l11l1l11l111_l1_:
					l111l1ll111l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠫ劬")+l11l1l11l111_l1_
	elif l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭劭") in l11l1l11l111_l1_: l111l1ll111l_l1_ = l11ll1_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ劮")+l11l1l11l111_l1_
	if l1llll_l1_: LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭劯"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ劰")+l11111l1ll1l_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ励")+url+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ劲")+l1lllll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭劳")+str(l1llll_l1_)+l11ll1_l1_ (u"ࠫࠥࡣࠧ労"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ劵"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭劶")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ劷")+l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ劸")+l111l1ll111l_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ効"))
	l111l1ll111l_l1_ = l1111_l1_(l111l1ll111l_l1_)
	return l111l1ll111l_l1_,l1lll111_l1_,l1llll_l1_
def l11111lllll1_l1_(l11ll1l11ll1_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ劺"),l11ll1l11ll1_l1_)
	l1l11l11l11_l1_ = l1lllll1_l1_
	data = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ劻"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭劼"),l11ll1l11ll1_l1_)
	if data:
		l1lll111_l1_,l1llll_l1_ = list(zip(*data))
		return l1lll111_l1_,l1llll_l1_
	l1lll111_l1_,l1llll_l1_,l11l1l111ll1_l1_ = [],[],[]
	for l1lllll_l1_ in l11ll1l11ll1_l1_:
		if l11ll1_l1_ (u"࠭࠯࠰ࠩ劽") not in l1lllll_l1_: continue
		l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_ = l11l1l111111_l1_(l1lllll_l1_,source)
		l111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࠮ࠫ劾"),l111lll1_l1_,re.DOTALL)
		if l111lll1_l1_: l111lll1_l1_ = int(l111lll1_l1_[0])
		else: l111lll1_l1_ = 0
		#if l111lll1_l1_:
		#	l11l1111lll1_l1_ = sorted(l111lll1_l1_,reverse=True,key=lambda key: int(key))
		#	l111lll1_l1_ = int(l11l1111lll1_l1_[0])
		#else: l111lll1_l1_ = 0
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭势"))
		l11l1l111ll1_l1_.append([l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_,l1lllll_l1_,server])
	if l11l1l111ll1_l1_:
		#l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_,l1lllll_l1_ = zip(*l11l1l111ll1_l1_)
		#name = reversed(name)
		#l11l1l111ll1_l1_ = zip(l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_,l1lllll_l1_)
		l1llll1l1l11_l1_ = sorted(l11l1l111ll1_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111l1l1l1l1_l1_ = []
		for line in l1llll1l1l11_l1_:
			if line not in l111l1l1l1l1_l1_:
				l111l1l1l1l1_l1_.append(line)
				#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ勀"),str(line))
		for l111l111ll11_l1_,name,type,l11lll1_l1_,l111lll1_l1_,l1lllll_l1_,server in l111l1l1l1l1_l1_:
			if l111lll1_l1_: l111lll1_l1_ = str(l111lll1_l1_)
			else: l111lll1_l1_ = l11ll1_l1_ (u"ࠪࠫ勁")
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ勂"),l11ll1_l1_ (u"ࠬ࠭勃"),name,l1lllll_l1_)
			title = l11ll1_l1_ (u"࠭ำ๋ำไีࠬ勄")+l11ll1_l1_ (u"ࠧࠡࠩ勅")+type+l11ll1_l1_ (u"ࠨࠢࠪ勆")+l111l111ll11_l1_+l11ll1_l1_ (u"ࠩࠣࠫ勇")+l111lll1_l1_+l11ll1_l1_ (u"ࠪࠤࠬ勈")+l11lll1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭勉")+name
			if server not in title: title = title+l11ll1_l1_ (u"ࠬࠦࠧ勊")+server
			title = title.replace(l11ll1_l1_ (u"࠭ࠥࠨ勋"),l11ll1_l1_ (u"ࠧࠨ勌")).strip(l11ll1_l1_ (u"ࠨࠢࠪ勍")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ勎"),l11ll1_l1_ (u"ࠪࠤࠬ勏")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ勐"),l11ll1_l1_ (u"ࠬࠦࠧ勑")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ勒"),l11ll1_l1_ (u"ࠧࠡࠩ勓"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1lll111_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		if l1llll_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭勔"),l1llll_l1_)
			data = list(zip(l1lll111_l1_,l1llll_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪ動"),l11ll1l11ll1_l1_,data,l1l11l11l11_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ勖"),l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠼࠵࠾ࠥࠦࠠࠨ勗")+str(data))
	return l1lll111_l1_,l1llll_l1_
def	l11l111ll111_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡄࡤ࡛ࡤࡰࡥ࡯ࡱࡽࡏࡨ࠭勘")
	l1lllllll111_l1_ = l11ll1_l1_ (u"࠭ࠧ務")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l11l1l1ll_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lllllll111_l1_ = str(error)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ勚"),l11ll1_l1_ (u"ࠨࠩ勛"),l11ll1_l1_ (u"ࠩࠪ勜"),str(results))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ勝"),l11ll1_l1_ (u"ࠫࠬ勞"),l11ll1_l1_ (u"ࠬ࠭募"),str(l1lllllll111_l1_))
	# resolveurl l1111l1l1l_l1_ l1lll1l111l_l1_ l111l11l1l11_l1_ with l1lllllll1ll1_l1_ error or l111l1ll1ll1_l1_ value False
	if not results:
		if l1lllllll111_l1_==l11ll1_l1_ (u"࠭ࠧ勠"):
			l1lllllll111_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllllll111_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ勡"),l11ll1_l1_ (u"ࠨࠩ勢"),l11ll1_l1_ (u"ࠩࠪ勣"),str(l1lllllll111_l1_))
		l11l1l11l111_l1_ = l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠢࡉࡥ࡮ࡲࡥࡥࠩ勤")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠫࠥ࠭勥")+l1lllllll111_l1_.splitlines()[-1]
		return l11l1l11l111_l1_,[],[]
	return l11ll1_l1_ (u"ࠬ࠭勦"),[l11ll1_l1_ (u"࠭ࠧ勧")],[results]
def	l11l111l1lll_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ勨")
	#url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭࠰ࡸ࡬ࡨࡪࡵ࠯ࡹ࠹ࡼࡽ࠹࠷ࡳࠨ勩")
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ勪"),l11ll1_l1_ (u"ࠪࠫ勫"),url,l11ll1_l1_ (u"ࠫࠬ勬"))
	#return l11ll1_l1_ (u"ࠬ࠭勭"),[],[]
	l1lllllll111_l1_ = l11ll1_l1_ (u"࠭ࠧ勮")
	results = False
	try:
		import youtube_dl
		l11l11lll11l_l1_ = youtube_dl.YoutubeDL({l11ll1_l1_ (u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩ勯"): True})
		results = l11l11lll11l_l1_.extract_info(url,download=False)
	except Exception as error: l1lllllll111_l1_ = str(error)
	# youtube_dl l1111l1l1l_l1_ l1lll1l111l_l1_ l111l11l1l11_l1_ with l1lllllll1ll1_l1_ error or l111l1ll1ll1_l1_ value False
	if not results or l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ勰") not in list(results.keys()):
		if l1lllllll111_l1_==l11ll1_l1_ (u"ࠩࠪ勱"):
			l1lllllll111_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllllll111_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ勲"),l11ll1_l1_ (u"ࠫࠬ勳"),l11ll1_l1_ (u"ࠬ࠭勴"),l1lllllll111_l1_)
		l11l1l11l111_l1_ = l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠥࡌࡡࡪ࡮ࡨࡨࠬ勵")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠧࠡࠩ勶")+l1lllllll111_l1_.splitlines()[-1]
		return l11l1l11l111_l1_,[],[]
	else:
		l1lll111_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_ in results[l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ勷")]:
			l1lll111_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࠩ勸")])
			l1llll_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ勹")])
		return l11ll1_l1_ (u"ࠫࠬ勺"),l1lll111_l1_,l1llll_l1_
def l11l11ll1lll_l1_(url):
	if l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ勻") in url:
		l1lll111_l1_,l1llll_l1_ = l11ll11l1l_l1_(url)
		if l1llll_l1_: return l11ll1_l1_ (u"࠭ࠧ勼"),l1lll111_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡐࡆࡘࡁࡃࠩ勽"),[],[]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ勾"),[l11ll1_l1_ (u"ࠩࠪ勿")],[url]
def l1l1l1l1ll1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ匀"),l11ll1_l1_ (u"ࠫࠬ匁"),l11ll1_l1_ (u"ࠬ࠭匂"),url)
	l1lll1ll_l1_,l111l11l11l1_l1_ = [],[]
	if l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩ匃") in url:
		# l111ll1ll1ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_11111l1llll_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l11ll11ll1_l1_.l1111l11_l1_?l1l1l1ll1l1_l1_=49e3a27b4
		# l1111lllll11_l1_: https://l111l1lll1l1_l1_.l1lll1lllll_l1_.l1llllll1llll_l1_.l1llll111ll_l1_/15/items/40animeHD/l111l1ll11l1_l1_.l1111l11_l1_
		# l111ll1ll1ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1111l1l111l_l1_-l111ll11l11l_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l11ll11ll1_l1_.l1111l11_l1_?l1l1l1ll1l1_l1_=l1111111l1ll_l1_
		# l1111lllll11_l1_: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11ll11ll1_l1_/l111l1l11l1l_l1_%20.l1111l11_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ匄"),url,l11ll1_l1_ (u"ࠨࠩ包"),l11ll1_l1_ (u"ࠩࠪ匆"),False,l11ll1_l1_ (u"ࠪࠫ匇"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭匈"))
		if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ匉") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ匊")]
			l1lll1ll_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ匋"))
			l111l11l11l1_l1_.append(server)
	elif l11ll1_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ匌") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111ll1ll1ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l11ll1111_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l11l11llll11_l1_/?l1lllll_l1_=https://drive.l1l1l1ll11l1_l1_.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l11l11111_l1_&l11111111l11_l1_=
		# l111ll1ll1ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l1l111l11_l1_.l1ll1lll11_l1_?url=l1llllllll11l_l1_==&sub=https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l111lll1111l_l1_/l1lllllll1lll_l1_.l111111l1111_l1_&l11111111l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11111lll111_l1_/l1llllll111l1_l1_-1.l1111l11ll1l_l1_
		# l111ll1ll1ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l1l1111l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l111l111l11l_l1_/?url=https://photos.l11l111lll1_l1_.l111ll1l1lll_l1_.l11l1l1lll11_l1_/l111l1lll11l_l1_&sub=&l11111111l11_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11111lll111_l1_/4723b8ebe-1.l1111l11ll1l_l1_
		# l111ll1ll1ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l11ll1l1l_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l11l11llll11_l1_/?l1lllll_l1_=https://l1l11ll1lll_l1_.l1l1l1ll11l1_l1_.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l11l11111_l1_&sub=&l11111111l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11111lll111_l1_/2e8bc4c34-1.l1111l11ll1l_l1_
		# l111ll1ll1ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1111l1lllll_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l11l11llll11_l1_/?l1lllll_l1_=https://drive.l1l1l1ll11l1_l1_.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l11l111l1_l1_=l11l111lllll_l1_&l11111111l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11111lll111_l1_/l111ll1ll1l1_l1_-1.l1111l11ll1l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭匍"),url,l11ll1_l1_ (u"ࠪࠫ匎"),l11ll1_l1_ (u"ࠫࠬ匏"),l11ll1_l1_ (u"ࠬ࠭匐"),l11ll1_l1_ (u"࠭ࠧ匑"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ匒"))
		html = response.content
		l1ll1ll1l11l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ匓"),html,re.DOTALL)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ匔"),str(l1ll1ll1l11l_l1_))
		if l1ll1ll1l11l_l1_:
			l1ll1ll1l11l_l1_ = l1ll1ll1l11l_l1_[0]
			l1l1lll1llll_l1_ = l1ll111ll11l_l1_(l1ll1ll1l11l_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ匕"),str(l1l1lll1llll_l1_))
			l1l1ll1lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࡜࡜࠰࠭ࡃࡡࡣࠩ࠭ࠩ化"),l1l1lll1llll_l1_,re.DOTALL)
			if l1l1ll1lll11_l1_:
				l1l1ll1lll11_l1_ = l1l1ll1lll11_l1_[0]
				l1l1ll1lll11_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ北"),l1l1ll1lll11_l1_)
				for dict in l1l1ll1lll11_l1_:
					l1lllll_l1_ = dict[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࠫ匘")]
					l111lll1_l1_ = dict[l11ll1_l1_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭匙")]
					#l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࡡࡢࠫ匚")+l111lll1_l1_
					l1lll1ll_l1_.append(l1lllll_l1_)
					server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ匛"))
					l111l11l11l1_l1_.append(l111lll1_l1_+l11ll1_l1_ (u"ࠪࠤࠬ匜")+server)
		elif l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭匝") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ匞")]
			l1lll1ll_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ匟"))
			l111l11l11l1_l1_.append(server)
		# l111ll1ll1ll_l1_: 5
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l1l1111l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1111111l1l1_l1_/l111l111l11l_l1_/?url=https://photos.l11l111lll1_l1_.l111ll1l1lll_l1_.l11l1l1lll11_l1_/l111l1lll11l_l1_&sub=&l11111111l11_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l111111ll11l_l1_/l11111lll111_l1_/4723b8ebe-1.l1111l11ll1l_l1_
		if l11ll1_l1_ (u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧ匠") in url:
			l1lllll_l1_ = url.split(l11ll1_l1_ (u"ࠨࡁࡸࡶࡱࡃࠧ匡"))[1]
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࠫ匢"))[0]
			if l1lllll_l1_:
				l1lll1ll_l1_.append(l1lllll_l1_)
				l111l11l11l1_l1_.append(l11ll1_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪ匣"))
	else:
		# l111ll1ll1ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_111111111l1_l1_.html
		# l1lllll_l1_: http://ok.l111ll1ll111_l1_/l111llll1l1l_l1_/1676019108395
		# l111ll1ll1ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1111111l11l_l1_.html
		# l1lllll_l1_: https://drive.l1l1l1ll11l1_l1_.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l11l11111_l1_
		l1lll1ll_l1_.append(url)
		server = SERVER(url,l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ匤"))
		l111l11l11l1_l1_.append(server)
	if not l1lll1ll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ匥"),[],[]
	elif len(l1lll1ll_l1_)==1: l1lllll_l1_ = l1lll1ll_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ匦"),l111l11l11l1_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ匧"),[],[]
		l1lllll_l1_ = l1lll1ll_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ匨"),[l11ll1_l1_ (u"ࠩࠪ匩")],[l1lllll_l1_]
def l111l1l111ll_l1_(url):
	# test from: https://www.l1l1l1ll111_l1_.com/l11l1l1l1_l1_/l11l11l11l11_l1_-l111l1l11ll1_l1_-l1111lllll1l_l1_-l1111l111l11_l1_-l1111l11ll11_l1_-l11ll11ll1_l1_-1-date.html
	# url = https://l11l11111ll1_l1_.l1llllll111ll_l1_.com/l1111lll1ll1_l1_=l111ll111ll1_l1_
	headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ匪"):l11ll1_l1_ (u"ࠫࡐࡵࡤࡪ࠱ࠪ匫")+str(kodi_version)}
	for l11ll11111_l1_ in range(50):
		time.sleep(0.100)
		response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ匬"),url,l11ll1_l1_ (u"࠭ࠧ匭"),headers,False,l11ll1_l1_ (u"ࠧࠨ匮"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ匯"))
		if l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ匰") in list(response.headers.keys()):
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ匱")]
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ匲")+headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ匳")]
			return l11ll1_l1_ (u"࠭ࠧ匴"),[l11ll1_l1_ (u"ࠧࠨ匵")],[l1lllll_l1_]
		if response.code!=429: break
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚ࠧ匶"),[],[]
def l111ll1111l1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ匷"),l11ll1_l1_ (u"ࠪࠫ匸"),l11ll1_l1_ (u"ࠫࠬ匹"),url)
	# https://photos.l11l111lll1_l1_.l111ll1l1lll_l1_.l11l1l1lll11_l1_/l111l1lll11l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ区"),url,l11ll1_l1_ (u"࠭ࠧ医"),l11ll1_l1_ (u"ࠧࠨ匼"),l11ll1_l1_ (u"ࠨࠩ匽"),l11ll1_l1_ (u"ࠩࠪ匾"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩ匿"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨ區"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_,l111lll1_l1_ = l1lllll_l1_[0]
		return l11ll1_l1_ (u"ࠬ࠭十"),[l111lll1_l1_],[l1lllll_l1_]
	return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ卂"),[],[]
def l1ll1l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ千"),l11ll1_l1_ (u"ࠨࠩ卄"),l11ll1_l1_ (u"ࠩࠪ卅"),url)
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡲࡲࡪ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡨࡩࡦ࠼࠶࠸ࡤ࠳࠼࠶ࡨ࠸࠸ࡥ࠳࠴࠶࠵࠸ࡡࡥ࠳࠻ࡨࡩ࠷࠲ࡤ࠸࠻࠴࠻࠭卆")
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡴࡧ࡯࡬ࡩ࠳ࡥ࡮ࡤࡨࡨ࠳ࡹࡣࡥࡰ࠱ࡸࡴ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡤ࠳࠵࠺࠿࠰࠵ࡣ࠻ࡥࡨ࡬࠷࠺࠷࠹ࡨ࠶࡫࠷࠷࠵࠳ࡦࡪ࠷࠷࠷࠷࠻࠻࠸࠭升")
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ午"),url,l11ll1_l1_ (u"࠭ࠧ卉"),l11ll1_l1_ (u"ࠧࠨ半"),l11ll1_l1_ (u"ࠨࠩ卋"),l11ll1_l1_ (u"ࠩࠪ卌"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸࠬ卍"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬ华"),html)
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭协"),html,re.DOTALL)
	if l1lllll_l1_: return l11ll1_l1_ (u"࠭ࠧ卐"),[l11ll1_l1_ (u"ࠧࠨ卑")],[l1lllll_l1_[0]]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ卒"),[],[]
def l1llllll11_l1_(url):
	if l11ll1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭卓") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ協"),url,l11ll1_l1_ (u"ࠫࠬ单"),l11ll1_l1_ (u"ࠬ࠭卖"),l11ll1_l1_ (u"࠭ࠧ南"),l11ll1_l1_ (u"ࠧࠨ単"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨ卙"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ博"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ卛") in l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ卜"),[l11ll1_l1_ (u"ࠬ࠭卝")],[l1lllll_l1_]
		return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ卞"),[],[]
	else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ卟"),[l11ll1_l1_ (u"ࠨࠩ占")],[url]
def l1lll1lll11_l1_(url):
	l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
	l1l1ll111_l1_ = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ卡"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ卢"),l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ卣"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ卤")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ卥"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨ卦"),l11ll1_l1_ (u"ࠨࠩ卧"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩ卨"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ卩"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭卪"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ卫"),[l11ll1_l1_ (u"࠭ࠧ卬")],[l1lllll_l1_]
def l1l1l1l11l1l_l1_(url):
	headers = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ卭"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ卮")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭卯"),url,l11ll1_l1_ (u"ࠪࠫ印"),headers,l11ll1_l1_ (u"ࠫࠬ危"),l11ll1_l1_ (u"ࠬ࠭卲"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ即"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ却"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ卵"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ卶"),[l11ll1_l1_ (u"ࠪࠫ卷")],[l1lllll_l1_]
def l1l1lll1ll1_l1_(url):
	l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
	l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ卸"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ卹")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ卺"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨ卻"),l11ll1_l1_ (u"ࠨࠩ卼"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ卽"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ卾"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ卿"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ厀") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ厁")+l1lllll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ厂"),l11ll1_l1_ (u"ࠨࠩ厃"),l11ll1_l1_ (u"ࠩࠪ厄"),l1lllll_l1_)
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭厅"),[l11ll1_l1_ (u"ࠫࠬ历")],[l1lllll_l1_]
def l1lll11l1l_l1_(url):
	l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
	l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ厇"):l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭厈")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ厉"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠨࠩ厊"),l11ll1_l1_ (u"ࠩࠪ压"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬ厌"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ厍"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡆࡈࡄࡐࠩ厎"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ厏"),[l11ll1_l1_ (u"ࠧࠨ厐")],[l1lllll_l1_]
def l1llll11lll1_l1_(url):
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ厑"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭厒"),url,l11ll1_l1_ (u"ࠪࠫ厓"),l11ll1_l1_ (u"ࠫࠬ厔"),l11ll1_l1_ (u"ࠬ࠭厕"),l11ll1_l1_ (u"࠭ࠧ厖"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡘ࡛ࡌࡕࡏ࠯࠴ࡷࡹ࠭厗"))
	html = response.content
	l111111111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡸࡤࡶࠥ࡬ࡳࡦࡴࡹࠤࡂ࠴ࠪࡀࠩࠫ࠲࠯ࡅࠩࠨࠤ厘"),html,re.DOTALL|re.IGNORECASE)
	if l111111111ll_l1_:
		l111111111ll_l1_ = l111111111ll_l1_[0][2:]
		#l111111111ll_l1_ = l111111111ll_l1_.decode(l11ll1_l1_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ厙"))
		l111111111ll_l1_ = base64.b64decode(l111111111ll_l1_)
		if kodi_version>18.99: l111111111ll_l1_ = l111111111ll_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ厚"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ厛"),l111111111ll_l1_,re.DOTALL)
	else: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࠭厜")
	if not l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ厝"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ厞") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ原")+l1lllll_l1_
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ厠"),[l11ll1_l1_ (u"ࠪࠫ厡")],[l1lllll_l1_]
def l11111l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ厢"),url,l11ll1_l1_ (u"ࠬ࠭厣"),l11ll1_l1_ (u"࠭ࠧ厤"),l11ll1_l1_ (u"ࠧࠨ厥"),l11ll1_l1_ (u"ࠨࠩ厦"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫ厧"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ厨"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨ厩"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ厪"),[l11ll1_l1_ (u"࠭ࠧ厫")],[l1lllll_l1_]
def l11lll1l1l_l1_(url):
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ厬"))[-1]
	if l11ll1_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ厭") in url: url = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ厮"),l11ll1_l1_ (u"ࠪࠫ厯"))
	url = url.replace(l11ll1_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࠪ厰"),l11ll1_l1_ (u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭厱"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ厲"),url,l11ll1_l1_ (u"ࠧࠨ厳"),l11ll1_l1_ (u"ࠨࠩ厴"),l11ll1_l1_ (u"ࠩࠪ厵"),l11ll1_l1_ (u"ࠪࠫ厶"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ厷"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭厸"),url)
	l11l1l11l111_l1_ = l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭厹")
	error = re.findall(l11ll1_l1_ (u"ࠧࠣࡧࡵࡶࡴࡸࠢ࠯ࠬࡂࠦࡲ࡫ࡳࡴࡣࡪࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ厺"),html,re.DOTALL)
	if error: l11l1l11l111_l1_ = error[0]
	url = re.findall(l11ll1_l1_ (u"ࠨࡺ࠰ࡱࡵ࡫ࡧࡖࡔࡏࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ去"),html,re.DOTALL)
	if not url and l11l1l11l111_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ厼"),l11ll1_l1_ (u"ࠪࠫ厽"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾࠭厾"),l11l1l11l111_l1_)
		return l11l1l11l111_l1_,[],[]
	l1lllll_l1_ = url[0].replace(l11ll1_l1_ (u"ࠬࡢ࡜ࠨ县"),l11ll1_l1_ (u"࠭ࠧ叀"))
	l11ll11llll1_l1_,l11ll1l11ll1_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
	owner = re.findall(l11ll1_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻ࡽࠥ࡭ࡩࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ叁"),html,re.DOTALL)
	if owner: l1111lll1l11_l1_,l11l11lll111_l1_,l111lll1ll1l_l1_ = owner[0]
	else: l1111lll1l11_l1_,l11l11lll111_l1_,l111lll1ll1l_l1_ = l11ll1_l1_ (u"ࠨࠩ参"),l11ll1_l1_ (u"ࠩࠪ參"),l11ll1_l1_ (u"ࠪࠫ叄")
	l111lll1ll1l_l1_ = l111lll1ll1l_l1_.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ叅"),l11ll1_l1_ (u"ࠬ࠵ࠧ叆"))
	l11l11lll111_l1_ = escapeUNICODE(l11l11lll111_l1_)
	l1lll111_l1_ = [l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ叇")+l11l11lll111_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ又")]+l11ll11llll1_l1_
	l1llll_l1_ = [l111lll1ll1l_l1_]+l11ll1l11ll1_l1_
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ叉")+str(len(l1llll_l1_)-1)+l11ll1_l1_ (u"้้ࠩࠣ็ࠩࠨ及"),l1lll111_l1_)
	if l1l_l1_==-1: return l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ友"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11ll1_l1_ (u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿ࠪ双")+l111lll1ll1l_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡦࡺࡷࡁࠬ反")+l11l11lll111_l1_
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ収")+new_path+l11ll1_l1_ (u"ࠢࠪࠤ叏"))
		return l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭叐"),[],[]
	l1lllll_l1_ =  l1llll_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠩࠪ发"),[l11ll1_l1_ (u"ࠪࠫ叒")],[l1lllll_l1_]
def l11111ll1_l1_(l1lllll_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ叓"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭叔"),l11ll1_l1_ (u"࠭ࠧ叕"),l11ll1_l1_ (u"ࠧࠨ取"),l11ll1_l1_ (u"ࠨࠩ受"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨ变"))
	html = response.content
	if l11ll1_l1_ (u"ࠪ࠲࡯ࡹ࡯࡯ࠩ叙") in l1lllll_l1_: url = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ叚"),html,re.DOTALL)
	else: url = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ叛"),html,re.DOTALL)
	if not url: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧ叜"),[],[]
	url = url[0]
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ叝") not in url: url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ叞")+url
	return l11ll1_l1_ (u"ࠩࠪ叟"),[l11ll1_l1_ (u"ࠪࠫ叠")],[url]
def l11l111l1111_l1_(url):
	# http://l1111ll11l1l_l1_.l1lll1lll1ll_l1_/l11l11llllll_l1_.html?l11l11l1l1l1_l1_=l111l1l1l111_l1_
	# http://l1111ll11l1l_l1_.l1lll1lll1ll_l1_/l111l111lll1_l1_?op=l1lllllll11l1_l1_&id=l11l11llllll_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ叡") : l11ll1_l1_ (u"ࠬ࠭叢") }
	if l11ll1_l1_ (u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ口") in url:
		html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠧࠨ古"),headers,l11ll1_l1_ (u"ࠨࠩ句"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫ另"))
		#xbmc.log(html)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ叧"),l11ll1_l1_ (u"ࠫࠬ叨"),url,html)
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ叩"),html,re.DOTALL)
		if items: return l11ll1_l1_ (u"࠭ࠧ只"),[l11ll1_l1_ (u"ࠧࠨ叫")],[items[0]]
		else:
			message = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭召"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ叭"),l11ll1_l1_ (u"ࠪࠫ叮"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭可"),message[0])
				return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭台")+message[0],[],[]
	else:
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ叱"),l11ll1_l1_ (u"ࠧࠨ史"),l1lllll_l1_,l11ll1_l1_ (u"ࠨࠩ右"))
		#url,l1ll1lll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ叴"))
		#l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.lower()
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭叵")
		# l11l1l1l1_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠫࠬ叶"),headers,l11ll1_l1_ (u"ࠬ࠭号"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ司"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ叹"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ叺"),[],[]
		l1lllll111_l1_ = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		if l11ll1_l1_ (u"ࠩ࠱ࡶࡦࡸࠧ叻") in block or l11ll1_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ叼") in block: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ叽"),[],[]
		items = re.findall(l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭叾"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l111_l1_(payload)
		html = OPENURL_CACHED(l1ll1ll1l_l1_,l1lllll111_l1_,data,headers,l11ll1_l1_ (u"࠭ࠧ叿"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩ吀"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭吁"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭吂"),[],[]
		download = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		items = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪ吃"),block,re.DOTALL)
		l11111l1l11l_l1_,l1lll111_l1_,l11l111llll1_l1_,l1llll_l1_,l1111l1l11ll_l1_ = [],[],[],[],[]
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ各") in l1lllll_l1_:
				l11111l1l11l_l1_,l11l111llll1_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11l111llll1_l1_
				if l11111l1l11l_l1_[0]==l11ll1_l1_ (u"ࠬ࠳࠱ࠨ吅"): l1lll111_l1_.append(l11ll1_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ吆")+l11ll1_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭吇")+l1ll1lll1l1_l1_)
				else:
					for title in l11111l1l11l_l1_:
						l1lll111_l1_.append(l11ll1_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭合")+l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ吉")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠪࠤࠬ吊")+title)
			else:
				title = title.replace(l11ll1_l1_ (u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭吋"),l11ll1_l1_ (u"ࠬ࠭同"))
				title = title.strip(l11ll1_l1_ (u"࠭ࠢࠨ名"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ后"),l11ll1_l1_ (u"ࠨࠩ吏"),title,str(l1111l1l11ll_l1_))
				title = l11ll1_l1_ (u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨ吐")+l11ll1_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ向")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭吒")+title
				l1lll111_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ吓") + download
		html = OPENURL_CACHED(l1ll1ll1l_l1_,l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ吔"),headers,l11ll1_l1_ (u"ࠧࠨ吕"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪ吖"))
		items = re.findall(l11ll1_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨ吗"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11ll1_l1_ (u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧ吘")+l11ll1_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ吙")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠬࠦࠧ吚")+resolution.split(l11ll1_l1_ (u"࠭ࡸࠨ君"))[1]
			l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ吜")+id+l11ll1_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ吝")+mode+l11ll1_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ吞")+hash
			l1111l1l11ll_l1_.append(resolution)
			l1lll111_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		l1111l1l11ll_l1_ = set(l1111l1l11ll_l1_)
		l1111ll1l11l_l1_,l111llll111l_l1_ = [],[]
		for title in l1lll111_l1_:
			#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ吟"),l11ll1_l1_ (u"ࠫࠬ吠"),title,l11ll1_l1_ (u"ࠬ࠭吡"))
			res = re.findall(l11ll1_l1_ (u"ࠨࠠࠩ࡞ࡧ࠮ࡽࢂ࡜ࡥࠬࠬࠪࠫࠨ吢"),title+l11ll1_l1_ (u"ࠧࠧࠨࠪ吣"),re.DOTALL)
			for resolution in l1111l1l11ll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11ll1_l1_ (u"ࠨࡺࠪ吤"))[1])
			l1111ll1l11l_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1llll_l1_)):
			items = re.findall(l11ll1_l1_ (u"ࠤࠩࠪ࠭࠴ࠪࡀࠫࠫࡠࡩ࠰ࠩࠧࠨࠥ吥"),l11ll1_l1_ (u"ࠪࠪࠫ࠭否")+l1111ll1l11l_l1_[i]+l11ll1_l1_ (u"ࠫࠫࠬࠧ吧"),re.DOTALL)
			l111llll111l_l1_.append( [l1111ll1l11l_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l111llll111l_l1_ = sorted(l111llll111l_l1_, key=lambda x: x[3], reverse=True)
		l111llll111l_l1_ = sorted(l111llll111l_l1_, key=lambda x: x[2], reverse=False)
		l1lll111_l1_,l1llll_l1_ = [],[]
		for i in range(len(l111llll111l_l1_)):
			l1lll111_l1_.append(l111llll111l_l1_[i][0])
			l1llll_l1_.append(l111llll111l_l1_[i][1])
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ吨"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ吩"),l1lll111_l1_,l1llll_l1_
def l111lllll11l_l1_(url):
	# http://l1lllllll111l_l1_.com/717254
	parts = url.split(l11ll1_l1_ (u"ࠧࡀࠩ吪"))
	l111lll_l1_ = parts[0]
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ含") : l11ll1_l1_ (u"ࠩࠪ听") }
	html = OPENURL_CACHED(l1ll1ll1l_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ吭"),headers,l11ll1_l1_ (u"ࠫࠬ吮"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࠬ启"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ吰"),html,re.DOTALL)
	url = items[0]
	#l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111111lll1l_l1_(url)
	#return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ吱"),[l11ll1_l1_ (u"ࠨࠩ吲")],[url]
def l111l111l111_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll111_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭吳") : l11ll1_l1_ (u"ࠪࠫ吴") }
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ吵"),headers,l11ll1_l1_ (u"ࠬ࠭吶"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ吷"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡࡸࡶࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吸"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠨࠩ吹"),[l11ll1_l1_ (u"ࠩࠪ吺")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡕ࡛࡜࡙ࡖࡑ࠭吻"),[],[]
def l111llllll11_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll111_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ吼") : l11ll1_l1_ (u"ࠬ࠭吽") }
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ吾"),headers,l11ll1_l1_ (u"ࠧࠨ吿"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ呀"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁࠬࠦࠬ呁"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠪࠫ呂"),[l11ll1_l1_ (u"ࠫࠬ呃")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠭呄"),[],[]
def l1ll1l1l1l1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ呅"),l11ll1_l1_ (u"ࠧࠨ呆"),l11ll1_l1_ (u"ࠨࠩ呇"),url)
	# l11l1l1l1_l1_    https://show.l1111llll111_l1_.com/l1111ll1lll1_l1_-l1111ll1l1l1_l1_/l1111ll1l1l1_l1_-l111ll11l1ll_l1_.l1ll1lll11_l1_?action=l1111l1l1l11_l1_&post=32513&l1ll1l1l1ll_l1_=1&type=l1lllll111l_l1_
	# download https://show.l1111llll111_l1_.com/l1l1_l1_/l111111ll1l1_l1_
	l1lll111_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠩࠪ呈")
	# l11l1l1l1_l1_
	if l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ呉") in url:
		l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
		l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ告"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ呋")}
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ呌"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨ呍"),l11ll1_l1_ (u"ࠨࠩ呎"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬ呏"))
		l11ll1l1_l1_ = response.content
		if l11ll1l1_l1_.startswith(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ呐")): l111lll_l1_ = l11ll1l1_l1_
		else:
			l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬ呑"),l11ll1l1_l1_,re.DOTALL)
			if l11l111_l1_:
				l111lll_l1_ = l11l111_l1_[0]
				l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬࠨࠬ呒"),l111lll_l1_,re.DOTALL)
				if l11l111_l1_:
					l111lll_l1_ = l1111_l1_(l11l111_l1_[0])
					return l11ll1_l1_ (u"࠭ࠧ呓"),[l11ll1_l1_ (u"ࠧࠨ呔")],[l111lll_l1_]
	# download
	elif l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩ呕") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭呖"),url,l11ll1_l1_ (u"ࠪࠫ呗"),l11ll1_l1_ (u"ࠫࠬ员"),True,l11ll1_l1_ (u"ࠬ࠭呙"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ呚"))
		l11ll1l1_l1_ = response.content
		if l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ呛") in list(response.headers.keys()): l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ呜")]
		else: l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭呝"),l11ll1l1_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ呞"),l11ll1_l1_ (u"ࠫࠬ呟"),l111lll_l1_,str(2222))
	if l11ll1_l1_ (u"ࠬ࠵ࡶ࠰ࠩ呠") in l111lll_l1_ or l11ll1_l1_ (u"࠭࠯ࡧ࠱ࠪ呡") in l111lll_l1_:
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰ࡨ࠲ࠫ呢"),l11ll1_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ呣"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡺ࠴࠭呤"),l11ll1_l1_ (u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ呥"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ呦"),l11ll1_l1_ (u"ࠬ࠭呧"),l111lll_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ周"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ呩"),l11ll1_l1_ (u"ࠨࠩ呪"),l11ll1_l1_ (u"ࠩࠪ呫"),l11ll1_l1_ (u"ࠪࠫ呬"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧ呭"))
		l11ll1l1_l1_ = response.content
		items = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ呮"),l11ll1l1_l1_,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡝ࠩ呯"),l11ll1_l1_ (u"ࠧࠨ呰"))
				l1lll111_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ呱"),l11ll1l1_l1_,re.DOTALL)
			if items:
				l1lllll_l1_ = items[0]
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠬ呲"),l11ll1_l1_ (u"ࠪࠫ味"))
				l1lll111_l1_.append(l11ll1_l1_ (u"ࠫࠬ呴"))
				l1llll_l1_.append(l1lllll_l1_)
	else: return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ呵"),[l11ll1_l1_ (u"࠭ࠧ呶")],[l111lll_l1_]
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ呷"),l11ll1_l1_ (u"ࠨࠩ呸"),str(l11ll111l_l1_),l111lll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ呹"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ呺"),l1lll111_l1_,l1llll_l1_
def l1ll1111111l_l1_(url):
	# l11l1l1l1_l1_ l1111l11_l1_  https://l111l11llll1_l1_.l11l111lll11_l1_.l1llll111ll_l1_/l11llllll1l_l1_/l1lllll1lllll_l1_.l1ll1lll11_l1_?s=07&id=l11l1l11l1ll_l1_,&l1lll1_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1111l11ll1l_l1_&l111lll11lll_l1_=l11111111111_l1_&l111l11111l1_l1_=l1llllll1l1l1_l1_
	# l11l1l1l1_l1_ l1lll1lll_l1_ https://l11l11l1111l_l1_.l11l111lll11_l1_.l1llll111ll_l1_/l11llllll1l_l1_/l1111111lll1_l1_.l1ll1lll11_l1_?l11l11111l11_l1_=l1111ll11ll1_l1_&l111l1ll11ll_l1_=8a26a6cc61a884e89076504130c71626&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111l11ll1l_l1_&l111lll11lll_l1_=l11111111111_l1_&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111l11ll1l_l1_&l111lll11lll_l1_=l11111111111_l1_&l111l11111l1_l1_=l11111ll1lll_l1_
	# download https://www.l11l1111llll_l1_.l1111ll1llll_l1_/l111lll1lll1_l1_?server=l1111111ll11_l1_&id=l111ll111l11_l1_,,
	# l1l111l11_l1_ https://l11l1111llll_l1_.l1lll11111_l1_/l1l111l11_l1_/l111lll11111_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ呻"),url,l11ll1_l1_ (u"ࠬ࠭呼"),l11ll1_l1_ (u"࠭ࠧ命"),l11ll1_l1_ (u"ࠧࠨ呾"),l11ll1_l1_ (u"ࠨࠩ呿"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ咀"))
	html = response.content
	l1lll111_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠪࠫ咁")
	if l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ咂") in url or l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭咃") in url:
		if l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ咄") in url:
			l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ咅"),html,re.DOTALL)
			l111lll_l1_ = l111lll_l1_[0]
		else: l111lll_l1_ = url
		if l11ll1_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ咆") not in l111lll_l1_: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ咇"),[l11ll1_l1_ (u"ࠪࠫ咈")],[l111lll_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ咉"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭咊"),l11ll1_l1_ (u"࠭ࠧ咋"),l11ll1_l1_ (u"ࠧࠨ和"),l11ll1_l1_ (u"ࠨࠩ咍"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩ咎"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭咏"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ咐"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1ll1ll111l1_l1_ in items:
				l1lll111_l1_.append(l1ll1ll111l1_l1_)
				l1llll_l1_.append(l1lllll_l1_)
	elif l11ll1_l1_ (u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧ咑") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪ咒"),html,re.DOTALL)
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ咓"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ咔"),l11ll1_l1_ (u"ࠩࠪ咕"),l11ll1_l1_ (u"ࠪࠫ咖"),l11ll1_l1_ (u"ࠫࠬ咗"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬ咘"))
		html = response.content
		l11l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ咙"),html,re.DOTALL)
		l11l111_l1_ = l11l111_l1_[0]
		l1lll111_l1_.append(l11ll1_l1_ (u"ࠧࠨ咚"))
		l1llll_l1_.append(l11l111_l1_)
	elif l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨ咛") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ咜"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭咝"),[l11ll1_l1_ (u"ࠫࠬ咞")],[l111lll_l1_]
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧ咟"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ咠"),l1lll111_l1_,l1llll_l1_
def l11111l1ll_l1_(url):
	# https://l111lllllll1_l1_.l1111llll1l1_l1_/l1l111l1l11_l1_?call=l111lll111ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l11l1l1l1_l1_=l111l1l11l11_l1_
	# https://l111lllllll1_l1_.l1111llll1l1_l1_/l1l111l1l11_l1_?call=l111lll111ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l11l1l1l1_l1_=l1111ll1ll1l_l1_
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ咡"),1)[0].strip(l11ll1_l1_ (u"ࠨࡁࠪ咢")).strip(l11ll1_l1_ (u"ࠩ࠲ࠫ咣")).strip(l11ll1_l1_ (u"ࠪࠪࠬ咤"))
	l1lll111_l1_,l1llll_l1_,items,l11l111_l1_ = [],[],[],l11ll1_l1_ (u"ࠫࠬ咥")
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ咦"):l11ll1_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭咧") }
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ咨"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ咩"),headers,True,l11ll1_l1_ (u"ࠩࠪ咪"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫ咫"))
	if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咬") in list(response.headers.keys()): l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咭")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ咮"),l11l111_l1_,l11ll1_l1_ (u"ࠧࠨ咯"),headers,False,l11ll1_l1_ (u"ࠨࠩ咰"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠲࡯ࡦࠪ咱"))
	#if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ咲") in response.headers: l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咳")]
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭咴"),l11ll1_l1_ (u"࠭ࠧ咵"),l11l111_l1_,response.content)
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ咶") in l11l111_l1_:
		# https://l1111l111l_l1_.top/f/l111ll1l1111_l1_/?l111ll1111_l1_=l11l1l1l1lll_l1_
		# https://l1111l111l_l1_.top/v/l111ll1l1111_l1_/?l111ll1111_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ咷") in url: l11l111_l1_ = l11l111_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡪ࠴࠭咸"),l11ll1_l1_ (u"ࠪ࠳ࡻ࠵ࠧ咹"))
		l11l11l1llll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭咺"))[1]
		headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ咻"):headers[l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ咼")] , l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ咽"):l11ll1_l1_ (u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩ咾")+l11l11l1llll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭咿"),l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ哀"),headers,False,l11ll1_l1_ (u"ࠫࠬ品"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ哂"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1ll1l_l1_,l11l111_l1_,l11ll1_l1_ (u"࠭ࠧ哃"),headers,l11ll1_l1_ (u"ࠧࠨ哄"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠹ࡲࡥࠩ哅"))
		if l11ll1_l1_ (u"ࠩ࠲ࡪ࠴࠭哆") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哇"),html,re.DOTALL)
		elif l11ll1_l1_ (u"ࠫ࠴ࡼ࠯ࠨ哈") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哉"),html,re.DOTALL)
		if items: return [],[l11ll1_l1_ (u"࠭ࠧ哊")],[ items[0] ]
		elif l11ll1_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭哋") in html:
			return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫ哌"),[],[]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬ响"),[],[]
	#xbmc.log(html)
def l111l11111l_l1_(l1lllll_l1_):
	# https://l11l1l1ll1l1_l1_.net/?l11ll1ll_l1_=147043&l11lll1l_l1_=5
	parts = re.findall(l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ哎"),l1lllll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ哏"),re.DOTALL|re.IGNORECASE)
	l11ll1ll_l1_,l11lll1l_l1_ = parts[0]
	url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭哐")+l11ll1ll_l1_+l11ll1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ哑")+l11lll1l_l1_
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ哒"):l11ll1_l1_ (u"ࠨࠩ哓") , l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ哔"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ哕") }
	l111lll_l1_ = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠫࠬ哖"),headers,l11ll1_l1_ (u"ࠬ࠭哗"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮࠳ࡶࡸࠬ哘"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ哙"),l11ll1_l1_ (u"ࠨࠩ哚"),url,l111lll_l1_)
	#l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111111lll1l_l1_(l111lll_l1_)
	#return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ哛"),[l11ll1_l1_ (u"ࠪࠫ哜")],[l111lll_l1_]
def l1ll1l111l11_l1_(url):
	# https://l1llllll1lll1_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll11llll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111llll1lll_l1_=1608181746
	server = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ哝"))
	l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭哞"):server,l11ll1_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ哟"):l11ll1_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ哠")}
	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ員"),url,l11ll1_l1_ (u"ࠩࠪ哢"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠪࠫ哣"),l11ll1_l1_ (u"ࠫࠬ哤"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ哥"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ哦"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠧࠨ哧")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ哨"),block,re.DOTALL)
		l1lll111_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll111_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ哩"), l1lll111_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠪࠫ哪"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哫"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧ哬"),[],[]
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ哭"),[l11ll1_l1_ (u"ࠧࠨ哮")],[l111lll_l1_]
def l1l1ll1l1l11_l1_(url):
	# https://l11l1l1ll1ll_l1_.l111111lllll_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll11llll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111llll1lll_l1_=1608181746
	# https://l11l1l1ll1ll_l1_.l1111llll1l1_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111ll11llll_l1_=l11l1l1111l1_l1_&l111llll1lll_l1_=1684182121
	server = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ哯"))
	l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ哰"):server,l11ll1_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ哱"):l11ll1_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ哲")}
	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ哳"),url,l11ll1_l1_ (u"࠭ࠧ哴"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠧࠨ哵"),l11ll1_l1_ (u"ࠨࠩ哶"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ哷"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ哸"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ哹")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ哺"),block,re.DOTALL)
		l1lll111_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll111_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ哻"), l1lll111_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࠨ哼"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	if not l111lll_l1_:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭哽"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫ哾"),[],[]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭哿"),[l11ll1_l1_ (u"ࠫࠬ唀")],[l111lll_l1_]
def l1l11l1l_l1_(l1lllll_l1_):
	# https://w.l1111l1llll1_l1_.l11l111l1l11_l1_/l1111ll1lll1_l1_-content/l11l1l11l1l1_l1_/l1111l1ll11l_l1_/l11l111l11l1_l1_/l1111l1ll111_l1_/l111l11lll1l_l1_/l1111lll111l_l1_.l1ll1lll11_l1_?l11ll1ll_l1_=42869&l11lll1l_l1_=4
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭唁"),l11ll1_l1_ (u"࠭ࠧ唂"),l1lllll_l1_,html)
	parts = re.findall(l11ll1_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭唃"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ唄"),re.DOTALL)
	url,l11ll1ll_l1_,l11lll1l_l1_ = parts[0]
	data = {l11ll1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ唅"):l11ll1ll_l1_,l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ唆"):l11lll1l_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ唇"),url,data,l11ll1_l1_ (u"ࠬ࠭唈"),l11ll1_l1_ (u"࠭ࠧ唉"),l11ll1_l1_ (u"ࠧࠨ唊"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪ唋"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ唌"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭唍"),[l11ll1_l1_ (u"ࠫࠬ唎")],[l111lll_l1_]
def l1ll1l1ll1_l1_(url):
	# https://l111llll11ll_l1_.l1ll1lllll_l1_-l111llllll1l_l1_.com/l1l111l11_l1_.l1ll1lll11_l1_?l1l1l1ll1l1_l1_=l111l1111l11_l1_
	# https://l.l1111lll11l1_l1_.l1111ll1llll_l1_/l1l111l11_l1_.l1ll1lll11_l1_?l1l1l1ll1l1_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ唏"),url,l11ll1_l1_ (u"࠭ࠧ唐"),l11ll1_l1_ (u"ࠧࠨ唑"),l11ll1_l1_ (u"ࠨࠩ唒"),l11ll1_l1_ (u"ࠩࠪ唓"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭唔"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唕"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ唖"),[l11ll1_l1_ (u"࠭ࠧ唗")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ唘"),[],[]
def l1lll111l1_l1_(url):
	# https://l1ll1llll1_l1_.l1ll1lllll_l1_-l1lll11111_l1_.l1lll11111_l1_/l1111ll1lll1_l1_-content/l11l1l11l1l1_l1_/old/l1lll11_l1_/server.l1ll1lll11_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ唙"),url,l11ll1_l1_ (u"ࠩࠪ唚"),l11ll1_l1_ (u"ࠪࠫ唛"),l11ll1_l1_ (u"ࠫࠬ唜"),l11ll1_l1_ (u"ࠬ࠭唝"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ唞"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭唟"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ唠"),[l11ll1_l1_ (u"ࠩࠪ唡")],[l1lllll_l1_]
def l1ll1l1l1l_l1_(url):
	# https://l1l11l1ll11_l1_.l1l11lll1l1l_l1_.cc/l1111ll1lll1_l1_-content/l11l1l11l1l1_l1_/l11111ll111l_l1_%20Now%20New/l111111ll111_l1_.l1ll1lll11_l1_?action=l111lllll1l1_l1_&index=00&id=58504
	# https://l111ll11lll1_l1_.l1l11lll1l1l_l1_.net/l111111ll11l_l1_/2021/04/05/_111l1111ll1_l1_-l11l1l1l1l1l_l1_.l1llllll1111l_l1_ 200.l111111l111l_l1_.2020.l11111l111ll_l1_/[l11111ll111l_l1_-l11l1l1l1l1l_l1_.l1111l111111_l1_] 200.l111111l111l_l1_.2020.l11111l111ll_l1_-360p.l1111l11_l1_
	l1lllll11l_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ唢"))
	if l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ唣") in url:
		headers = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭唤"):l1lllll11l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ唥"),url,l11ll1_l1_ (u"ࠧࠨ唦"),headers,l11ll1_l1_ (u"ࠨࠩ唧"),l11ll1_l1_ (u"ࠩࠪ唨"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ唩"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ唪"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			if l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭唫") in l111lll_l1_:
				l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ唬"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ唭"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ售"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ唯"),headers,l11ll1_l1_ (u"ࠪࠫ唰"),l11ll1_l1_ (u"ࠫࠬ唱"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭唲"))
				l11ll1l1_l1_ = response.content
				items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唳"),l11ll1l1_l1_,re.DOTALL)
				l1lll111_l1_,l1llll_l1_ = [],[]
				l1llll1l11_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ唴"))
				for l1lllll_l1_,l111lll1_l1_ in reversed(items):
					l1lllll_l1_ = l1llll1l11_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ唵")+l1llll1l11_l1_
					l1lll111_l1_.append(l111lll1_l1_)
					l1llll_l1_.append(l1lllll_l1_)
				return l11ll1_l1_ (u"ࠩࠪ唶"),l1lll111_l1_,l1llll_l1_
			else: return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭唷"),[l11ll1_l1_ (u"ࠫࠬ唸")],[l111lll_l1_]
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ唹")+l1lllll11l_l1_
	return l11ll1_l1_ (u"࠭ࠧ唺"),[l11ll1_l1_ (u"ࠧࠨ唻")],[l111lll_l1_]
def l111l1l1llll_l1_(l1lllll_l1_):
	# https://l1l11lll1l1l_l1_.l11l111l1l11_l1_/l1111ll1lll1_l1_-content/l11l1l11l1l1_l1_/l111lllll111_l1_/l111111ll1ll_l1_/server.l1ll1lll11_l1_?l11ll1ll_l1_=42869&l11lll1l_l1_=4
	# https://l11l11l111ll_l1_.l1l11lll1l1l_l1_.net/l111111ll11l_l1_/2020/08/14/_111l1111ll1_l1_-l11l1l1l1l1l_l1_.l1llllll1111l_l1_ l11111l1lll1_l1_.l111l1l11lll_l1_.2020.l111l111llll_l1_-l111l1l1ll11_l1_/[l11111ll111l_l1_-l11l1l1l1l1l_l1_.l1111l111111_l1_] l11111l1lll1_l1_.l111l1l11lll_l1_.2020.l111l111llll_l1_-l111l1l1ll11_l1_-1080p.l1111l11_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ唼"),l11ll1_l1_ (u"ࠩࠪ唽"),url,html)
	l1lllll11l_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ唾"))
	if l11ll1_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ唿") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ啀"),l1lllll_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ啁"),re.DOTALL)
		url,l11ll1ll_l1_,l11lll1l_l1_ = parts[0]
		data = {l11ll1_l1_ (u"ࠧࡪࡦࠪ啂"):l11ll1ll_l1_,l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ啃"):l11lll1l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ啄"),url,data,l11ll1_l1_ (u"ࠪࠫ啅"),l11ll1_l1_ (u"ࠫࠬ商"),l11ll1_l1_ (u"ࠬ࠭啇"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ啈"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ啉"),html,re.DOTALL)[0]
		if l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ啊") in l111lll_l1_:
			headers = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ啋"):l1lllll11l_l1_,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ啌"):l11ll1_l1_ (u"ࠫࠬ啍")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ啎"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ問"),headers,l11ll1_l1_ (u"ࠧࠨ啐"),l11ll1_l1_ (u"ࠨࠩ啑"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ啒"))
			l11ll1l1_l1_ = response.content
			items = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ啓"),l11ll1l1_l1_,re.DOTALL)
			l1lll111_l1_,l1llll_l1_ = [],[]
			l1llll1l11_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ啔"))
			for l1lllll_l1_,l111lll1_l1_ in reversed(items):
				l1lllll_l1_ = l1llll1l11_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ啕")+l1llll1l11_l1_
				l1lll111_l1_.append(l111lll1_l1_)
				l1llll_l1_.append(l1lllll_l1_)
			return l11ll1_l1_ (u"࠭ࠧ啖"),l1lll111_l1_,l1llll_l1_
		else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ啗"),[l11ll1_l1_ (u"ࠨࠩ啘")],[l111lll_l1_]
	else:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ啙")+l1lllll11l_l1_
		return l11ll1_l1_ (u"ࠪࠫ啚"),[l11ll1_l1_ (u"ࠫࠬ啛")],[l1lllll_l1_]
def l111ll1l1_l1_(l1lllll_l1_):
	# http://l11l11lllll1_l1_.tv/?l11ll1ll_l1_=159485&l11lll1l_l1_=0
	if l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ啜") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ啝"),l1lllll_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ啞"),re.DOTALL|re.IGNORECASE)
		l11ll1ll_l1_,l11lll1l_l1_ = parts[0]
		host = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ啟"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ啠"),l11ll1_l1_ (u"ࠪࠫ啡"),l1lllll_l1_,host)
		url = host+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ啢")+l11ll1ll_l1_+l11ll1_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ啣")+l11lll1l_l1_
		headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ啤"):l11ll1_l1_ (u"ࠧࠨ啥") , l11ll1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ啦"):l11ll1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ啧") }
		l111lll_l1_ = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠪࠫ啨"),headers,l11ll1_l1_ (u"ࠫࠬ啩"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ啪"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ啫"),l11ll1_l1_ (u"ࠧࠨ啬")).replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ啭"),l11ll1_l1_ (u"ࠩࠪ啮"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ啯"),l11ll1_l1_ (u"ࠫࠬ啰"),url,l111lll_l1_)
		#l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l111111lll1l_l1_(l111lll_l1_)
		#return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ啱"),[l11ll1_l1_ (u"࠭ࠧ啲")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ啳") in l1lllll_l1_:
		counts = 0
		while l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ啴") in l1lllll_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭啵"),l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ啶"),l11ll1_l1_ (u"ࠫࠬ啷"),l11ll1_l1_ (u"ࠬ࠭啸"),l11ll1_l1_ (u"࠭ࠧ啹"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩ啺"))
			if l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ啻") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ啼")]
			counts += 1
		return l11ll1_l1_ (u"ࠪࠫ啽"),[l11ll1_l1_ (u"ࠫࠬ啾")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ啿"),[],[]
def l11l11l1l_l1_(url):
	# https://l1111llll1ll_l1_.l11111llll11_l1_.me/l/l11l1l111l1l_l1_=
	# https://l111lll11l1l_l1_.l11111l11l1l_l1_.net/l1l111l11_l1_-l1l111l11_l1_-l11111l1l1ll_l1_.html
	# https://m.l11111l11l1l_l1_.net/l11111l1l1ll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ喀"),l11ll1_l1_ (u"ࠧࠨ喁"),l11ll1_l1_ (u"ࠨࠩ喂"),url)
	server = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭喃"))
	if l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ善") in url and l11ll1_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ喅") not in url: url = server+l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭喆")+url.split(l11ll1_l1_ (u"࠭࠯ࠨ喇"))[-1]+l11ll1_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭喈")
	headers = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ喉"):server,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭喊"):l11lllll1_l1_()}
	if l11ll1_l1_ (u"ࠪ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ喋") in url:
		l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ喌"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ喍")}
		l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ喎"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,True,l11ll1_l1_ (u"ࠧࠨ喏"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠱ࡴࡶࠪ喐"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ喑"),html,re.DOTALL|re.IGNORECASE)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠪࠫ喒"),[l11ll1_l1_ (u"ࠫࠬ喓")],[l1lllll_l1_[0]]
	elif l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭喔") in url:
		html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"࠭ࠧ喕"),headers,l11ll1_l1_ (u"ࠧࠨ喖"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ喗"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喘"),html,re.DOTALL)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠪࠫ喙"),[l11ll1_l1_ (u"ࠫࠬ喚")],[l1lllll_l1_[0]]
	else:
		l1111llllll1_l1_ = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ喛"),url,l11ll1_l1_ (u"࠭ࠧ喜"),headers,l11ll1_l1_ (u"ࠧࠨ喝"),l11ll1_l1_ (u"ࠨࠩ喞"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ喟"))
		html = l1111llllll1_l1_.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭喠"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])+l11ll1_l1_ (u"ࠫࠫࡪ࠽࠲ࠩ喡")
			l1ll11111_l1_ = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ喢"),l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ喣"),headers,l11ll1_l1_ (u"ࠧࠨ喤"),l11ll1_l1_ (u"ࠨࠩ喥"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ喦"))
			html = l1ll11111_l1_.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭喧"),html,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠫࠬ喨"),[l11ll1_l1_ (u"ࠬ࠭喩")],[l1lllll_l1_]
		if l11ll1_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ喪") in list(l1111llllll1_l1_.headers.keys()):
			cookies = l1111llllll1_l1_.headers[l11ll1_l1_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫ喫")]
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡡ࡯ࡲࡰࡥ࠮ࠫࡁࡀࠬ࠳࠰࠿ࠪ࠽ࠪ喬"),cookies,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ喭"),[l11ll1_l1_ (u"ࠪࠫ單")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ喯"),[],[]
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࠥࡴ࡯ࡵࠢࡺࡳࡷࡱࡩ࡯ࡩࠍࠍࠎࠩࠠࡪࡶࠣࡲࡪ࡫ࡤࡴࠢࡦࡳࡴࡱࡩࡦࠢࡩࡶࡴࡳࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠎࠎࠏࠣࠡࡅࡲࡳࡰ࡯ࡥ࠻ࠢࡦࡪࡤࡩ࡬ࡦࡣࡵࡥࡳࡩࡥ࠾ࡅࡐࡩ࠳ࡎࡋࡈࡓ࡮ࡱࡼࡴࡓࡗࡷࡱࡾ࡛ࡏࡰࡲࡱࡺࡵࡘࡇ࡚ࡤࡲࡱࡊ࠼ࡰࡂࡑࡗࡒࡕࡧ࡟ࡂࡇ࠲࠰࠵࠻࠼࠳࠲࠳࠵࠴࠵࠼࠭࠱࠯࠵࠹࠵ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࠫࡹࡷࡲࠬࠨࡷࡵࡰࠬ࠯ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠩࠫ࠯ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࡳࡦࡴࡹࡩࡷࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨࠫࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࡿࡶࡪ࠴ࡉࡈࡐࡒࡖࡊࡉࡁࡔࡇࠬࠎࠎࠏࡩࡧࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡦ࡯ࡥࡩࡩ࠳ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࠩ࠯࡟ࠬ࠭࡝࠭࡝࡯࡭ࡳࡱ࡝ࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪ࠮࡫ࡸࡲࡲࠩࠋࠋࠌࠧࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠉࠤ࡫ࡩࠤࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠦࠍࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠥࠌࡶࡪࡺࡵࡳࡰࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠦࠧࠨ喰")
	#if l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷࠲࡭ࡺ࡭࡭ࠩ喱") in url:
	#	l1ll11l111ll_l1_ = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ喲"))
	#	url = l11ll1_l1_ (u"ࠨ࠱ࠪ喳").join(l1ll11l111ll_l1_[:4])
	#	tmp = re.findall(l11ll1_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠳࠴࠴ࠪࡀ࠱ࠬࠬ࠳࠰࠿ࠪࠦࠪ喴"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ喵")+tmp[0][1]+l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ営")
	#	#return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ喷"),[l11ll1_l1_ (u"࠭ࠧ喸")],[url]
	#	#l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11111111ll1_l1_(url)
	#	#return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
	# l1l111l11_l1_ l1lllll_l1_
	#return l11ll1_l1_ (u"ࠧࠨ喹"),[l11ll1_l1_ (u"ࠨࠩ喺")],[l1lllll_l1_]
def l1l1ll11ll1l_l1_(l1lllll_l1_):
	# https://l111l11l1lll_l1_.l111l1l1lll1_l1_/l1lllll1lll11_l1_?_1111l1111ll_l1_=l1llllllll111_l1_&_1111l1l1ll1_l1_=86046&l11lll1l_l1_=0
	if l11ll1_l1_ (u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭喻") in l1lllll_l1_:
		headers = {l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭喼"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ喽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ喾"),l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ喿"),headers,l11ll1_l1_ (u"ࠧࠨ嗀"),l11ll1_l1_ (u"ࠨࠩ嗁"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ嗂"))
		url = response.content
		if url: return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嗃"),[l11ll1_l1_ (u"ࠫࠬ嗄")],[url]
	else:
		# https://l11111l11ll1_l1_.net/?l11ll1ll_l1_=142302&l11lll1l_l1_=4
		parts = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭嗅"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11ll1_l1_ (u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ嗆"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1ll_l1_,l11lll1l_l1_ = parts[0]
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ嗇"))
		#url = server+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ嗈")
		url = server+l11ll1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ嗉")
		#url = server+l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ嗊")+l11ll1ll_l1_+l11ll1_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ嗋")+l11lll1l_l1_
		#data = {l11ll1_l1_ (u"ࠬ࡯ࡤࠨ嗌"):l11ll1ll_l1_,l11ll1_l1_ (u"࠭ࡩࠨ嗍"):l11lll1l_l1_,l11ll1_l1_ (u"ࠧ࡮ࡧࡷࡥࠬ嗎"):l11ll1_l1_ (u"ࠨࡱ࡯ࡨࡤࡹࡥࡳࡸࡨࡶࡸ࠭嗏"),l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ嗐"):l11ll1_l1_ (u"ࠪࡳࡱࡪࠧ嗑")}
		data = {l11ll1_l1_ (u"ࠫ࡮ࡪࠧ嗒"):l11ll1ll_l1_,l11ll1_l1_ (u"ࠬ࡯ࠧ嗓"):l11lll1l_l1_}
		headers = {l11ll1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ嗔"):l11ll1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ嗕"),l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ嗖"):l1lllll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ嗗"),url,data,headers,l11ll1_l1_ (u"ࠪࠫ嗘"),l11ll1_l1_ (u"ࠫࠬ嗙"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ嗚"))
		l11ll1l1_l1_ = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嗛"),l11ll1l1_l1_,re.DOTALL|re.IGNORECASE)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嗜"),[l11ll1_l1_ (u"ࠨࠩ嗝")],[l111lll_l1_]
	return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭嗞"),[],[]
def l1llll1l_l1_(url,type,l111lll1_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嗟"),l11ll1_l1_ (u"ࠫࠬ嗠"),l111lll_l1_,type)
	# http://l1111llll11l_l1_.l11l11l1lll1_l1_.io/l1lllll_l1_/136530
	l1lll1ll_l1_,l111l11l11l1_l1_ = [],[]
	l11ll1l1_l1_ = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭嗡"),l11ll1_l1_ (u"࠭ࠧ嗢"),True,l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭嗣"))
	l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ嗤"),l11ll1l1_l1_,re.DOTALL)
	for block in l1111l1_l1_:
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭嗥"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ in l1lll1ll_l1_: continue
			if l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ嗦") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ嗧") not in l1lllll_l1_: continue
			title = title.replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭嗨"),l11ll1_l1_ (u"࠭ࠧ嗩")).replace(l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ嗪"),l11ll1_l1_ (u"ࠨࠩ嗫")).strip(l11ll1_l1_ (u"ࠩࠣࠫ嗬")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭嗭"),l11ll1_l1_ (u"ࠫࠥ࠭嗮"))
			l1lll1ll_l1_.append(l1lllll_l1_)
			l111l11l11l1_l1_.append(title)
	if not l1lll1ll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭嗯"),[],[]
	if len(l1lll1ll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭嗰"),l111l11l11l1_l1_)
		if l1l_l1_==-1: l1l_l1_ = 0
	else: l1l_l1_ = 0
	l11l111_l1_ = l1lll1ll_l1_[l1l_l1_]
	l1llll_l1_,l1lll111_l1_ = [],[]
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ嗱"),l11l111_l1_,l11ll1_l1_ (u"ࠨࠩ嗲"),l11ll1_l1_ (u"ࠩࠪ嗳"),l11ll1_l1_ (u"ࠪࠫ嗴"),True,l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠲࡯ࡦࠪ嗵"))
	l1l1ll11l_l1_ = response.content
	if type==l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ嗶"):
		l1lllll1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡢࡵࡰ࠰ࡰࡴࡧࡤࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嗷"),l1l1ll11l_l1_,re.DOTALL)
		if l1lllll1l_l1_:
			l1lllll_l1_ = l1111_l1_(l1lllll1l_l1_[0])
			l1llll_l1_.append(l1lllll_l1_)
			l1lll111_l1_.append(l111lll1_l1_)
	elif type==l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭嗸"):
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嗹"),l1l1ll11l_l1_,re.DOTALL)
		for l1lllll_l1_,size in l1l1_l1_:
			if not l1lllll_l1_: continue
			if l111lll1_l1_ in size:
				l1lll111_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
				break
		if not l1llll_l1_:
			for l1lllll_l1_,size in l1l1_l1_:
				if not l1lllll_l1_: continue
				l1lll111_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ嗺"),l1llll_l1_)
	if not l1llll_l1_: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ嗻"),[],[]
	return l11ll1_l1_ (u"ࠫࠬ嗼"),l1lll111_l1_,l1llll_l1_
def l11llll_l1_(url,name):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嗽"),l11ll1_l1_ (u"࠭ࠧ嗾"),url,l11l11l1l1l1_l1_)
	# http://l11ll1lll1l_l1_.l1111l1llll1_l1_.net/5cf68c23e6e79			?l11l11l1l1l1_l1_=			__11l1l1l11l1_l1_
	# http://w.l11l1lll_l1_.l1llll111ll_l1_/5e14fd0a2806e			?l11l11l1l1l1_l1_=			ok.l111l111111l_l1_
	#l11l11l1l1l1_l1_ = l11l11l1l1l1_l1_.replace(l11ll1_l1_ (u"ࠧࡢ࡭ࡲࡥࡲࡥ࡟ࠨ嗿"),l11ll1_l1_ (u"ࠨࠩ嘀")).split(l11ll1_l1_ (u"ࠩࡢࡣࠬ嘁"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嘂"),url,l11ll1_l1_ (u"ࠫࠬ嘃"),l11ll1_l1_ (u"ࠬ࠭嘄"),True,l11ll1_l1_ (u"࠭ࠧ嘅"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭嘆"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ嘇") in list(cookies.keys()):
		l11l11lll_l1_ = cookies[l11ll1_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ嘈")]
		l11l11lll_l1_ = l1111_l1_(escapeUNICODE(l11l11lll_l1_))
		items = re.findall(l11ll1_l1_ (u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嘉"),l11l11lll_l1_,re.DOTALL)
		l111lll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ嘊"),l11ll1_l1_ (u"ࠬ࠵ࠧ嘋"))
		l111lll_l1_ = escapeUNICODE(l111lll_l1_)
	else: l111lll_l1_ = url
	if l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ嘌") in l111lll_l1_:
		id = l111lll_l1_.split(l11ll1_l1_ (u"ࠧࠦ࠴ࡉࠫ嘍"))[-1]
		l111lll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫ嘎")+id
		return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嘏"),[l11ll1_l1_ (u"ࠪࠫ嘐")],[l111lll_l1_]
	else:
		l1l1l11l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ嘑")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ嘒"),l1l1l11l_l1_,l11ll1_l1_ (u"࠭ࠧ嘓"),l11ll1_l1_ (u"ࠧࠨ嘔"),True,l11ll1_l1_ (u"ࠨࠩ嘕"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠷ࡴࡤࠨ嘖"))
		l11l11l1l111_l1_ = response.url
		#l11l11l1l111_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ嘗")]
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嘘"),l11ll1_l1_ (u"ࠬ࠭嘙"),response.url,l1l1l11l_l1_)
		l111l11l1111_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ嘚"))[2]#.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嘛"))
		l11l1l1lll1l_l1_ = l11l11l1l111_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ嘜"))[2]#.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ嘝"))
		l11l111_l1_ = l111lll_l1_.replace(l111l11l1111_l1_,l11l1l1lll1l_l1_)
		headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ嘞"):l11ll1_l1_ (u"ࠫࠬ嘟") , l11ll1_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ嘠"):l11ll1_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ嘡") , l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ嘢"):l11l111_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭嘣"), l11l111_l1_, l11ll1_l1_ (u"ࠩࠪ嘤"), headers, False,l11ll1_l1_ (u"ࠪࠫ嘥"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪ嘦"))
		html = response.content
		#xbmc.log(str(l11l111_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嘧"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11ll1_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘨"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘩"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嘪"),l11ll1_l1_ (u"ࠩࠪ嘫"),str(items),html)
		if items:
			l1lllll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭嘬"),l11ll1_l1_ (u"ࠫ࠴࠭嘭"))
			l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠬ࠵ࠧ嘮"))
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ嘯") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭嘰") + l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ嘱"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ嘲"))
			if name==l11ll1_l1_ (u"ࠪࠫ嘳"): l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠫࠬ嘴"),[l11ll1_l1_ (u"ࠬ࠭嘵")],[l1lllll_l1_]
			else: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嘶"),[l11ll1_l1_ (u"ࠧࠨ嘷")],[l1lllll_l1_]
		else: l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐࡕࡁࡎࠩ嘸"),[],[]
		return l11l1l11l111_l1_,l1lll111_l1_,l1llll_l1_
def l11l1111l111_l1_(url):
	# https://www.l11l111l1ll1_l1_.com/e/l11111l1ll11_l1_
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嘹") : l11ll1_l1_ (u"ࠪࠫ嘺") }
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠫࠬ嘻"),headers,l11ll1_l1_ (u"ࠬ࠭嘼"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ嘽"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嘾"),l11ll1_l1_ (u"ࠨࠩ嘿"),url,html)
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ噀"),html,re.DOTALL)
	l1lll111_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠪࠫ噁")
	if items:
		for l1lllll_l1_,l1ll1ll111l1_l1_ in items:
			l1lll111_l1_.append(l1ll1ll111l1_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑࠪ噂"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭噃"),l1lll111_l1_,l1llll_l1_
def l11111llll1l_l1_(url):
	# https://l1111ll1l111_l1_.io/l1l111l11_l1_-l11111llllll_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭噄"),l11ll1_l1_ (u"ࠧࠨ噅"))
	headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ噆"):l11ll1_l1_ (u"ࠩࠪ噇")}
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠪࠫ噈"),headers,l11ll1_l1_ (u"ࠫࠬ噉"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ噊"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ噋"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ噌"),l11ll1_l1_ (u"ࠨࠩ噍"),url,items[0])
	if items:
		url = items[0]+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ噎")+url
		return l11ll1_l1_ (u"ࠪࠫ噏"),[l11ll1_l1_ (u"ࠫࠬ噐")],[url]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡓࡏࡓࡆࡊࠧ噑"),[],[]
def l111l1ll1lll_l1_(url):
	# https://l1lllll1lll1l_l1_.to/l1l111l11_l1_/5c83f14297d62
	url = url.strip(l11ll1_l1_ (u"࠭࠯ࠨ噒"))
	if l11ll1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ噓") in url: id = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ噔"))[4]
	else: id = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ噕"))[-1]
	url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡩࡳࡵࡴࡨࡥࡲ࠴ࡴࡰ࠱ࡳࡰࡦࡿࡥࡳࡁࡩ࡭ࡩࡃࠧ噖") + id
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ噗") : l11ll1_l1_ (u"ࠬ࠭噘") }
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"࠭ࠧ噙"),headers,l11ll1_l1_ (u"ࠧࠨ噚"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡉࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ噛"))
	html = html.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠬ噜"),l11ll1_l1_ (u"ࠪࠫ噝"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ噞"),l11ll1_l1_ (u"ࠬ࠭噟"),url,html)
	items = re.findall(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噠"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠧࠨ噡"),[l11ll1_l1_ (u"ࠨࠩ噢")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭噣"),[],[]
def l1111l1l1111_l1_(url):
	# https://l11l11lll1ll_l1_.net/l1l111l11_l1_-l111llll1ll1_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ噤"),l11ll1_l1_ (u"ࠫࠬ噥"))
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠬ࠭噦"),l11ll1_l1_ (u"࠭ࠧ噧"),l11ll1_l1_ (u"ࠧࠨ器"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡐ࡜ࡄ࠱࠶ࡹࡴࠨ噩"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࡷ࡫ࡳ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ噪"),html,re.DOTALL)
	l1lll111_l1_,l1llll_l1_ = [],[]
	for l1lllll_l1_,l1ll1ll111l1_l1_,res in items:
		l1lll111_l1_.append(l1ll1ll111l1_l1_+l11ll1_l1_ (u"ࠪࠤࠬ噫")+res)
		l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭噬"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭噭"),l1lll111_l1_,l1llll_l1_
def l111ll1l1l1l_l1_(url):
	# https://l11l1l11l11l_l1_.l1lll1lllll_l1_/l1l111l11_l1_-l1111l1lll11_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭噮"),l11ll1_l1_ (u"ࠧࠨ噯"))
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠨࠩ噰"),l11ll1_l1_ (u"ࠩࠪ噱"),l11ll1_l1_ (u"ࠪࠫ噲"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ噳"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥ噴"),html,re.DOTALL)
	items = set(items)
	l1lll111_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1ll1ll111l1_l1_,res in items:
		url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ噵")+id+l11ll1_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ噶")+mode+l11ll1_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ噷")+hash
		html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠩࠪ噸"),l11ll1_l1_ (u"ࠪࠫ噹"),l11ll1_l1_ (u"ࠫࠬ噺"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ噻"))
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ噼"),html,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lll111_l1_.append(l1ll1ll111l1_l1_+l11ll1_l1_ (u"ࠧࠡࠩ噽")+res)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧ噾"),[],[]
	return l11ll1_l1_ (u"ࠩࠪ噿"),l1lll111_l1_,l1llll_l1_
def l1lllll1llll1_l1_(url):
	# https://l1llllllll1l1_l1_.com:2053/l1lllllllll1l_l1_/l1111l1l1lll_l1_.l111lll111l1_l1_.l11l1l1ll111_l1_.1080p.l11l1l1l1111_l1_.l11l11l1l11l_l1_.l1llllll1ll1l_l1_.l1111l11_l1_.html?l111ll11llll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111llll1lll_l1_=1624070560
	# http://l111111l1l1l_l1_.l111lllll1l_l1_/l111ll1lll11_l1_/l111lll11ll1_l1_.l111l1l11111_l1_.l111llll11l1_l1_.2018.1080p.l111l111llll_l1_-l111l1l1ll11_l1_.l111111l11ll_l1_.l1111l11_l1_.html
	l1lllll_l1_ = l11ll1_l1_ (u"ࠪࠫ嚀")
	if 1 or l11ll1_l1_ (u"ࠫࡐ࡫ࡹ࠾ࠩ嚁") not in url:
		l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩ嚂"),l11ll1_l1_ (u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪ嚃"))
		l111lll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩ嚄"))
		id = l111lll_l1_[3]
		l111lll_l1_ = l11ll1_l1_ (u"ࠨ࠱ࠪ嚅").join(l111lll_l1_[0:4])
		#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嚆"):l11lllll1_l1_(),l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ嚇"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ嚈")}
		payload = {l11ll1_l1_ (u"ࠬ࡯ࡤࠨ嚉"):id,l11ll1_l1_ (u"࠭࡯ࡱࠩ嚊"):l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ嚋"),l11ll1_l1_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭嚌"):l11ll1_l1_ (u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ嚍")}
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ嚎"),l111lll_l1_,payload,l11ll1_l1_ (u"ࠫࠬ嚏"),l11ll1_l1_ (u"ࠬ࠭嚐"),l11ll1_l1_ (u"࠭ࠧ嚑"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡕࡈࡏࡎ࠯࠴ࡷࡹ࠭嚒"))
		if l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ嚓") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ嚔")]
		if not l1lllll_l1_ and response.succeeded:
			html = response.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚕"),html,re.DOTALL)
			if l1lllll_l1_: l1lllll_l1_ = l1lllll_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嚖"),url,l11ll1_l1_ (u"ࠬ࠭嚗"),l11ll1_l1_ (u"࠭ࠧ嚘"),l11ll1_l1_ (u"ࠧࠨ嚙"),l11ll1_l1_ (u"ࠨࠩ嚚"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ嚛"))
		if l11ll1_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ嚜") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭嚝")]
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠬ࠭嚞"),[l11ll1_l1_ (u"࠭ࠧ嚟")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡔࡇࡕࡍࠨ嚠"),[],[]
def l111l1llll1l_l1_(url):
	# https://www.l111l11ll11l_l1_.com/012ocyw9li6g.html
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嚡") : l11ll1_l1_ (u"ࠩࠪ嚢") }
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠪࠫ嚣"),headers,l11ll1_l1_ (u"ࠫࠬ嚤"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡌࡍ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ嚥"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧ࠮࠮ࠫࡁࠬࠦࠬ嚦"),html,re.DOTALL)
	l1lll111_l1_,l1llll_l1_ = [],[]
	if items:
		l1lll111_l1_.append(l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࠫ嚧"))
		l1llll_l1_.append(items[0][1])
		l1lll111_l1_.append(l11ll1_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭嚨"))
		l1llll_l1_.append(items[0][0])
		return l11ll1_l1_ (u"ࠩࠪ嚩"),l1lll111_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧ嚪"),[],[]
def l11l1ll1ll1_l1_(url):
	# l111lll1111l_l1_ l11l111l11ll_l1_			url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡛࠺࡛࠹࠷ࡖࡎࡺࡼࡕࡊ࠭嚫")
	# l11111111lll_l1_ .l11l1l1l11ll_l1_ l11l111l11ll_l1_		url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡺࡲ࡙ࡎࡂࡻࡨࡽࡋࡏࠧ嚬")
	# l111ll1lll1l_l1_ l11l1l1l1l_l1_ .l1lll1lll_l1_ l11l111l11ll_l1_		url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡋ࡫࠸࠭ࡏࡕࡷࡗࡸࡔࡷࠨ嚭")
	# l111ll1111ll_l1_ l11l111l11ll_l1_			url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡪࡥࡓ࠺ࡘࡹࡎࡒ࠷ࡐࡊࠩ嚮")
	# l111l11l1l_l1_ files have l111l1lll111_l1_ l1l11ll11lll_l1_		url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠷ࡷࡅࡔࡘ࡚ࡨ࡙ࡹࡠࡓࠪ嚯")
	# url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ嚰")
	# url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽ࠷ࡻ࠮ࡣࡧ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ嚱")
	# url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ嚲")
	# url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ嚳")
	# url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡴࡋࡋ࡬࡬࡫ࡢࡎ࠶࡟࡫ࠧࡣࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡂࡍ࡯࡭ࡦࡨࡲࡑ࡯࡮ࡦࡨࡲࡶ࡙࡜ࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡤࡲࡩࡊࡩࡴࡶࡵ࡭ࡧࡻࡴࡪࡱࡱࡃࡸࡿ࡮ࡥ࡫ࡦࡥࡹ࡯࡯࡯࠿࠵࠻࠼࠻࠷࠶ࠩ嚴")
	# l1ll1ll11_l1_ l11111lll11l_l1_ details   https://l1111l1ll1ll_l1_.me/l1lllllll1l1l_l1_/l1llllll11ll1_l1_-l1lllllll1l11_l1_-l11111ll1ll1_l1_
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ嚵"))[-1]
	id = id.split(l11ll1_l1_ (u"ࠨࠨࠪ嚶"))[0]
	id = id.replace(l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ嚷"),l11ll1_l1_ (u"ࠪࠫ嚸"))
	#id = l11ll1_l1_ (u"ࠫࡪࡥࡓ࠺ࡘࡹࡎࡒ࠷ࡐࡊࠩ嚹")
	#url = l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯ࡱ࡮ࡤࡽ࠴ࡅࡶࡪࡦࡨࡳࡤ࡯ࡤ࠾ࠩ嚺")+id
	#return l11ll1_l1_ (u"࠭ࠧ嚻"),[l11ll1_l1_ (u"ࠧࠨ嚼")],[url]
	l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ嚽")][0]+l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ嚾")+id
	l1llllll11111_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭嚿")+id
	l111l1l111l1_l1_,l1lllllllll11_l1_,l11l1l1ll11l_l1_,l1111111ll1l_l1_ = l11ll1_l1_ (u"ࠫࠬ囀"),l11ll1_l1_ (u"ࠬ࠭囁"),l11ll1_l1_ (u"࠭ࠧ囂"),l11ll1_l1_ (u"ࠧࠨ囃")
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡢࡵ࠱࠲࠵࠺ࠬ࠲ࠧࠧࠨࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࡞ࠪ࠰ࠬ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠬ࠳࠰࠿ࠪࡦࡨࡪࡦࡻ࡬ࡵࡃࡸࡨ࡮ࡵࡔࡳࡣࡦ࡯ࡎࡴࡤࡦࡺࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠪࠬ࠯ࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡽࠥࡰࡦࡴࡧࡶࡣࡪࡩࡈࡵࡤࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩࡠ࠰ࡠ࠭ࠧ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯ࡥࡳ࡭ࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮ࡤࡲ࡬࠯ࠊࠊࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆอีั๋ษࠡษ็้๋อำษห࠽ࠫ࠱ࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࠫࠍࠍࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡡ࠰࠭࠯࠴ࡡ࠿ࠐࠉࠊࠋࠌࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎ࡞࠴ࡢ࠱ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠨࡷࡽࡵ࡫࠽ࡵࡴࡤࡧࡰࠬࡴ࡭ࡣࡱ࡫ࡂ࠭ࠫ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡵ࡬࡫ࡳࡧࡴࡶࡴࡨ࠳ࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠽ࠤࡩࡧࡳࡩࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࡩࡱࡹࡥ࠻ࠢࡧࡥࡸ࡮ࡕࡓࡎࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡶ࠳ࠬ࠲ࠧ࠰ࡵ࡬࡫ࡳࡧࡴࡶࡴࡨ࠳ࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡬ࡱࡹࡕࡓࡎࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠥ࡫ࡸࡲࡲ࠲ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮࡫ࡰࡸ࡛ࡒࡍ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌࠧ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡜࠲ࡓࡅࡅࡋࡄ࠾࡚ࡘࡉ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࡗ࡝ࡕࡋ࠽ࡔࡗࡅࡘࡎ࡚ࡌࡆࡕ࠯ࡋࡗࡕࡕࡑ࠯ࡌࡈࡂࠨࡶࡵࡶࠪ࠰࡭ࡺ࡭࡭࠴࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠦࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡩࡵࡧࡰࡷࡠ࠶࡝ࠤ࠭ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠫࡺࡹࡱࡧࡀࡸࡷࡧࡣ࡬ࠨࡷࡰࡦࡴࡧ࠾ࠩࠍࠍࡧࡲ࡯ࡤ࡭ࡶ࠰ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠰࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࢁࡽࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡶࡴ࡯ࡣࡪࡴࡣࡰࡦࡨࡨࡤ࡬࡭ࡵࡡࡶࡸࡷ࡫ࡡ࡮ࡡࡰࡥࡵࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡣࡧࡥࡵࡺࡩࡷࡧࡢࡪࡲࡺࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡯ࡦࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩࡱࡹࡥ࡬ࡪࡵࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡧ࡮ࡥࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠡ࠾࡝ࠪࠫࡢࡀࠊࠊࠋࠌࡪࡲࡺ࡟࡭࡫ࡶࡸࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡫ࡳࡴࡠ࡫ࡷࡥ࡬ࡹࠠ࠾ࠢࡩࡱࡹࡥ࡬ࡪࡵࡷ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠱࠭ࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢࡩࡱࡹࡥࡩࡵࡣࡪࡷ࠿ࠐࠉࠊࠋࠌ࡭ࡹࡧࡧ࠭ࡵ࡬ࡾࡪࠦ࠽ࠡ࡫ࡷࡩࡲ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫࠍࠍࠎࠏࠉࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࡛ࡪࡶࡤ࡫ࡢࠦ࠽ࠡࡵ࡬ࡾࡪࠐࠉࡧࡱࡵࠤࡧࡲ࡯ࡤ࡭ࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡥࡰࡴࡩ࡫࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏ࡬ࡪࡰࡨࡷࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠬࠨࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳ࡫ࠠࡪࡰࠣࡰ࡮ࡴࡥࡴ࠼ࠍࠍࠎࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪࠪࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ࠲࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊࠋࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮࡬ࡪࡰࡨ࠰ࡱ࡫ࡶࡦ࡮ࡀࡼࡧࡳࡣ࠯ࡎࡒࡋࡓࡕࡔࡊࡅࡈ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡪࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪ࡯࡭ࡳ࡫ࠩࠋࠋࠌࠍࡩ࡯ࡣࡵࠢࡀࠤࢀࢃࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡱ࡯࡮ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩࠩࠪࠬ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡱࡥࡺ࠮ࡹࡥࡱࡻࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠿ࠪ࠰࠶࠯ࠊࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝࡮ࡩࡾࡣࠠ࠾ࠢࡹࡥࡱࡻࡥࠋࠋࠌࠍ࡮࡬ࠠࠨࡵ࡬ࡾࡪ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬࠤࡦࡴࡤࠡࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠍࠍࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡼࡨࠫࡢࠦ࠽ࠡࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࡜ࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣ࡝ࠋࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵࠫࠍࠍࡧࡲ࡯ࡤ࡭ࡶ࠰ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵ࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧ࡬࡯ࡳ࡯ࡤࡸࡸࠨ࠺࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸࠨ࠺࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡬࡯ࡳࠢࡥࡰࡴࡩ࡫ࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠩࠪࠬ࠲ࠧࠧࠩࠬࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠿ࠥࠫ࠱࠭࠽ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠨࠢࠨ࠮ࠪࠦࠬ࠯ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠿ࡺࡲࡶࡧࠪ࠰ࠬࡀࡔࡳࡷࡨࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠼ࡩࡥࡱࡹࡥࠨ࠮ࠪ࠾ࡋࡧ࡬ࡴࡧࠪ࠭ࠏࠏࠉࡪࡨࠣࠫࡠ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡀࠠࡣ࡮ࡲࡧࡰࠦ࠽ࠡࠩ࡞ࠫ࠰ࡨ࡬ࡰࡥ࡮࠯ࠬࡣࠧࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡊ࡜ࡁࡍࠪࠪࡰ࡮ࡹࡴࠨ࠮ࡥࡰࡴࡩ࡫ࠪࠌࠌࠍ࡫ࡵࡲࠡࡦ࡬ࡧࡹࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫࠻ࠌࠌࠍࠎࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞ࠫࠍࠍࠎࠏࡤࡪࡥࡷ࡟ࠬࡺࡹࡱࡧࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡃࠧ࠭ࠩࡀࠦࠬ࠯ࠫࠨࠤࠪࠎࠎࠏࠉࡪࡨࠣࠫ࡫ࡶࡳࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡩࡴࡸ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡦࡱࡵࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩࡺ࡭ࡩࡺࡨࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡶ࡭ࡿ࡫ࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡸ࡫ࡧࡸ࡭࠭࡝ࠪ࠭ࠪࡼࠬ࠱ࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩ࡫ࡩ࡮࡭ࡨࡵࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡶࡸࡦࡸࡴࠨ࡟࠮ࠫ࠲࠭ࠫࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࡠ࡟ࠬ࡫࡮ࡥࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲࡩ࡫ࡸࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡸࡺࡡࡳࡶࠪࡡ࠰࠭࠭ࠨ࠭ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡧࡱࡨࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬࠤࡦࡴࡤࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࡁ࠵࠶࠷࠲࠳࠴࠶࠷࠸ࡀࠠࡥࡧ࡯ࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠍࠍࠎࠏࠉࡤ࡫ࡳ࡬ࡪࡸࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠬࠧࠪࠌࠌࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤࡨ࡯ࡰࡩࡧࡵ࠾ࠏࠏࠉࠊࠋࠌ࡯ࡪࡿࠬࡷࡣ࡯ࡹࡪࠦ࠽ࠡ࡫ࡷࡩࡲ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠽ࠨ࠮࠴࠭ࠏࠏࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜࡭ࡨࡽࡢࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡹࡥࡱࡻࡥࠪࠌࠌࠍࠎࠩࡩࡧࠢࠪࡹࡷࡲࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡷࡵࡰࠬࡣࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࡜ࠩࡸࡶࡱ࠭࡝ࠪࠌࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶࠬࠎࠎࡻࡲ࡭ࡡ࡯࡭ࡸࡺࠬࡴࡶࡵࡩࡦࡳࡳ࠱࠮ࡶࡸࡷ࡫ࡡ࡮ࡵ࠴࠰ࡸࡺࡲࡦࡣࡰࡷ࠷ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳ࠣࡥࡳࡪࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠺ࠋࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸ࠶ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠼ࠍࠍࠎࠏࡵࡳ࡮࠴ࠤࡂࠦࡤࡪࡥࡷ࠵ࡠ࠭ࡵࡳ࡮ࠪࡡࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠤࡷࡵࡰ࠶ࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࠲࡝ࠪࡹࡷࡲࠧ࡞ࠫࠬ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴ࠳ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶࠿ࠐࠉࠊࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡨ࡮ࡩࡴ࠳࡝ࠪࡹࡷࡲࠧ࡞࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠎࠩࡵࡳ࡮࠵ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡦ࡬ࡧࡹ࠸࡛ࠨࡷࡵࡰࠬࡣࠩࠪ࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠎ࡯ࡦࠡࡷࡵࡰ࠶ࡃ࠽ࡶࡴ࡯࠶ࠥࡧ࡮ࡥࠢࡸࡶࡱ࠷ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠼ࠍࠍࠎࠏࠉࠊࡷࡵࡰࡤࡲࡩࡴࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲ࠱ࠪࠌࠌࠍࠎࠏࠉࡥ࡫ࡦࡸ࠶࠴ࡵࡱࡦࡤࡸࡪ࠮ࡤࡪࡥࡷ࠶࠮ࠐࠉࠊࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷ࠵࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠵࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡳࡵࡴࡨࡥࡲࡹ࠰ࠡ࠿ࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠮ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴ࠍࠍࠧࠨࠢ囄")
	# l111111l11l1_l1_ json data
	# l1l111l11_l1_ url l11l111l11ll_l1_:    https://www.l1ll1ll11_l1_.com/l1l111l11_l1_/l111llll1111_l1_
	# list of l11l111l1l1l_l1_ & l1l11ll1ll1l_l1_
	# https://github.com/l11111ll1l1l_l1_-l1111lll1l1l_l1_/l11111ll1l1l_l1_-l1111lll1l1l_l1_/blob/master/l11l1111l11l_l1_/l111l11ll1ll_l1_/l1ll1ll11_l1_.py
	# all the below l1111l11lll1_l1_ were l111l1llll11_l1_ using:	https://www.l1ll1ll11_l1_.com/l11l11ll11l1_l1_/l1l1llll1lll_l1_/l11llllll1l_l1_?l1llllll11l1l_l1_=l11111111111_l1_	&	l11l11111111_l1_ = l111llll1111_l1_
	# 3 l1ll1l11l11l_l1_:	13KB:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭囅"): l11ll1_l1_ (u"ࠪࡍࡔ࡙࡟ࡄࡔࡈࡅ࡙ࡕࡒࠨ囆"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ囇"): l11ll1_l1_ (u"ࠬ࠸࠲࠯࠵࠶࠲࠶࠶࠱ࠨ囈")
	# 7 l1ll1l11l11l_l1_		44KB:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ囉"): l11ll1_l1_ (u"ࠧࡊࡑࡖࡣࡒࡋࡓࡔࡃࡊࡉࡘࡥࡅ࡙ࡖࡈࡒࡘࡏࡏࡏࠩ囊"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ囋"): l11ll1_l1_ (u"ࠩ࠴࠻࠳࠹࠳࠯࠴ࠪ囌")
	# 7 l1ll1l11l11l_l1_		58KB:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ囍"): l11ll1_l1_ (u"ࠫࡎࡕࡓࠨ囎"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ囏"): l11ll1_l1_ (u"࠭࠱࠸࠰࠶࠷࠳࠸ࠧ囐")
	# 9 l1ll1l11l11l_l1_		24KB:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ囑"): l11ll1_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡆࡖࡊࡇࡔࡐࡔࠪ囒"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ囓"): l11ll1_l1_ (u"ࠪ࠶࠷࠴࠳࠱࠰࠴࠴࠵࠭囔")
	# no json file:		21 l1ll1l11l11l_l1_	95KB:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ囕"): l11ll1_l1_ (u"ࠬ࡝ࡅࡃࡡࡆࡖࡊࡇࡔࡐࡔࠪ囖"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭囗"): l11ll1_l1_ (u"ࠧ࠲࠰࠵࠴࠷࠸࠰࠸࠴࠹࠲࠵࠶࠮࠱࠲ࠪ囘")
	# no json file:		21 l1ll1l11l11l_l1_	121KB:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ囙"): l11ll1_l1_ (u"࡚ࠩࡉࡇ࠭囚"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ四"): l11ll1_l1_ (u"ࠫ࠷࠴࠲࠱࠴࠵࠴࠽࠶࠱࠯࠲࠳࠲࠵࠶ࠧ囜")
	# no json file: 	26 l1ll1l11l11l_l1_	115KB:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ囝"): l11ll1_l1_ (u"࠭ࡍࡘࡇࡅࠫ回"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ囟"): l11ll1_l1_ (u"ࠨ࠴࠱࠶࠵࠸࠲࠱࠺࠳࠵࠳࠶࠰࠯࠲࠳ࠫ因")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭囡"): l11ll1_l1_ (u"ࠪࡅࡓࡊࡒࡐࡋࡇࠫ团"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ団"): l11ll1_l1_ (u"ࠬ࠷࠷࠯࠵࠴࠲࠸࠻ࠧ囤")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ囥"): l11ll1_l1_ (u"ࠧࡘࡇࡅࡣࡗࡋࡍࡊ࡚ࠪ囦"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ囧"): l11ll1_l1_ (u"ࠩ࠴࠲࠷࠶࠲࠳࠲࠺࠶࠼࠴࠰࠲࠰࠳࠴ࠬ囨")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ囩"): l11ll1_l1_ (u"ࠫ࡜ࡋࡂࡠࡇࡐࡆࡊࡊࡄࡆࡆࡢࡔࡑࡇ࡙ࡆࡔࠪ囪"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ囫"): l11ll1_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠴࠳࠱࠴࠵࠴࠰࠱ࠩ囬")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ园"): l11ll1_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ囮"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ囯"): l11ll1_l1_ (u"ࠪ࠵࠼࠴࠳࠲࠰࠶࠹ࠬ困")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ囱"): l11ll1_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡍࡖࡕࡌࡇࠬ囲"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭図"): l11ll1_l1_ (u"ࠧ࠶࠰࠴࠺࠳࠻࠱ࠨ围")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ囵"): l11ll1_l1_ (u"ࠩࡗ࡚ࡍ࡚ࡍࡍ࠷ࡢࡗࡎࡓࡐࡍ࡛ࡢࡉࡒࡈࡅࡅࡆࡈࡈࡤࡖࡌࡂ࡛ࡈࡖࠬ囶"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ囷"): l11ll1_l1_ (u"ࠫ࠷࠴࠰ࠨ囸")
	# l11ll111l111_l1_:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ囹"): l11ll1_l1_ (u"࠭ࡉࡐࡕࡢࡑ࡚࡙ࡉࡄࠩ固"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ囻"): l11ll1_l1_ (u"ࠨ࠷࠱࠶࠶࠭囼")
	# l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ国")][0]+l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࡁࡳࡶࡪࡺࡴࡺࡒࡵ࡭ࡳࡺ࠽ࡵࡴࡸࡩࠬ图")  # l11111111111_l1_ l1lll11l111l_l1_ l1lllllllllll_l1_ and l11111lll1ll_l1_ l1ll1ll11ll1_l1_ l1l1l1ll1l_l1_ l11111l11l11_l1_ file size
	#l11ll111l_l1_ = l11ll1_l1_ (u"ࠫࢀ࠭囿")l1llllll11l11_l1_ (u"ࠬࡀࡩࡥ࠮ࠪ圀")l111l11l111l_l1_ (u"࠭࠺ࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࡿࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠦࡆࡔࡄࡓࡑࡌࡈࠧ࠲ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠤ࠴࠻࠳࠹࠱࠯࠵࠸ࠦࢂࢃࡽࠨ圁")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ圂"),l111lll_l1_,l11ll111l_l1_,l11ll1_l1_ (u"ࠨࠩ圃"),l11ll1_l1_ (u"ࠩࠪ圄"),l11ll1_l1_ (u"ࠪࠫ圅"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ圆"))
	#html = response.content
	for l11ll11111_l1_ in range(5):
		#l1llllll_l1_(l11ll1_l1_ (u"ࠬอไๆฯส์้ฯࠠาไ่࠾ࠥࠦࠧ圇")+str(l11ll11111_l1_+1),l11ll1_l1_ (u"࠭ࠧ圈"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ圉"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ圊"),l11ll1_l1_ (u"ࠩࠪ國"),l11ll1_l1_ (u"ࠪࠫ圌"),l11ll1_l1_ (u"ࠫࠬ圍"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭圎"))
		html = response.content
		if l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ圏") in html: break
		time.sleep(2)
	#WRITE_THIS(l11ll1_l1_ (u"ࠧࠨ圐"),html)
	l11lll11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ圑"),html,re.DOTALL)
	if l11lll11l1_l1_: l11lll11l1_l1_ = l11lll11l1_l1_[0]
	else: l11lll11l1_l1_ = html
	l11lll11l1_l1_ = l11lll11l1_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ園"),l11ll1_l1_ (u"ࠪࠪࠬ圓"))
	l11111ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ圔"),l11lll11l1_l1_)
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭圕"),str(l11111ll11l1_l1_))
	# l111111l11l1_l1_ l111llll1l11_l1_ & l11l1l11lll1_l1_
	# l1ll1ll11_l1_ l111lll1111l_l1_ l1lllll_l1_ l11lll1l1_l1_ l11ll1_l1_ (u"࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠨ圖") to l111l1l111_l1_ on l111ll1llll_l1_
	l1lll111_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠧษั๋๊ࠥะัอ็ฬࠤ๏๎ส๋๊หࠫ圗")],[l11ll1_l1_ (u"ࠨࠩ團")]
	try:
		l111llll1l11_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠩࡦࡥࡵࡺࡩࡰࡰࡶࠫ圙")][l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ圚")][l11ll1_l1_ (u"ࠫࡨࡧࡰࡵ࡫ࡲࡲ࡙ࡸࡡࡤ࡭ࡶࠫ圛")]
		for l111ll111l1l_l1_ in l111llll1l11_l1_:
			l1lllll_l1_ = l111ll111l1l_l1_[l11ll1_l1_ (u"ࠬࡨࡡࡴࡧࡘࡶࡱ࠭圜")]
			try: title = l111ll111l1l_l1_[l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ圝")][l11ll1_l1_ (u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫ圞")]
			except: title = l111ll111l1l_l1_[l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭土")][l11ll1_l1_ (u"ࠩࡵࡹࡳࡹࠧ圠")][0][l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࠨ圡")]
			l1llll_l1_.append(l1lllll_l1_)
			l1lll111_l1_.append(title)
	except: pass
	if len(l1lll111_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭圢"), l1lll111_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠬࡋࡘࡊࡖࠪ圣"),[],[]
		elif l1l_l1_!=0:
			l1lllll_l1_ = l1llll_l1_[l1l_l1_]+l11ll1_l1_ (u"࠭ࠦࠨ圤")
			l1111ll11l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠧࠪࡩࡱࡹࡃ࠮ࠫࡁࠬࠪࠬ圥"),l1lllll_l1_)
			if l1111ll11l11_l1_: l1lllll_l1_ = l1lllll_l1_.replace(l1111ll11l11_l1_[0],l11ll1_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ圦"))
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ圧")
			l111l1l111l1_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ在"))
	formats,l11l1l11ll11_l1_,l11l1111l1ll_l1_,l11l1111ll11_l1_,l11l1111l1l1_l1_ = [],[],[],[],[]
	# l111111l11l1_l1_ l111l1l1l11l_l1_ l1ll1l11l11l_l1_
	try: l1lllllllll11_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ圩")][l11ll1_l1_ (u"ࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ圪")]
	except: pass
	# l111111l11l1_l1_ l111ll1lll1l_l1_ stream
	try: l11l1l1ll11l_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭圫")][l11ll1_l1_ (u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ圬")]
	except: pass
	# l111111l11l1_l1_ l1ll1l11ll_l1_ l1111l11_l1_ l1ll1l11l11l_l1_
	try: formats = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ圭")][l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ圮")]
	except: pass
	# l111111l11l1_l1_ l1ll1l11ll_l1_ l11l1l1l11ll_l1_ l1ll1l11l11l_l1_
	try: l11l1l11ll11_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ圯")][l11ll1_l1_ (u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭地")]
	except: pass
	l111ll1ll11l_l1_ = formats+l11l1l11ll11_l1_
	for dict in l111ll1ll11l_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭圱"),str(dict))
		if l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ圲") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ圳")] = str(dict[l11ll1_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭圴")])
		if l11ll1_l1_ (u"ࠩࡩࡴࡸ࠭圵") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪࡪࡵࡹࠧ圶")] = str(dict[l11ll1_l1_ (u"ࠫ࡫ࡶࡳࠨ圷")])
		if l11ll1_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ圸") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ圹")] = dict[l11ll1_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ场")]		#.replace(l11ll1_l1_ (u"ࠨ࠿ࠪ圻"),l11ll1_l1_ (u"ࠩࡀࠫ圼"))+l11ll1_l1_ (u"ࠪࠦࠬ圽")
		if l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭圾") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ圿")] = str(dict[l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ址")])
		if l11ll1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ坁") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ坂")] = str(dict[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ坃")])
		if l11ll1_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ坄") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ坅")] = str(dict[l11ll1_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ坆")])+l11ll1_l1_ (u"࠭ࡸࠨ均")+str(dict[l11ll1_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ坈")])
		if l11ll1_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ坉") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ坊")] = dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭坋")][l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ坌")]+l11ll1_l1_ (u"ࠬ࠳ࠧ坍")+dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ坎")][l11ll1_l1_ (u"ࠧࡦࡰࡧࠫ坏")]
		if l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ坐") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ坑")] = dict[l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ坒")][l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ坓")]+l11ll1_l1_ (u"ࠬ࠳ࠧ坔")+dict[l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ坕")][l11ll1_l1_ (u"ࠧࡦࡰࡧࠫ坖")]
		if l11ll1_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ块") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ坘")] = dict[l11ll1_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ坙")]
		if l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ坚") in list(dict.keys()) and int(dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭坛")])>111222333: del dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ坜")]
		if l11ll1_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ坝") in list(dict.keys()):
			cipher = dict[l11ll1_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ坞")].split(l11ll1_l1_ (u"ࠩࠩࠫ坟"))
			for item in cipher:
				key,value = item.split(l11ll1_l1_ (u"ࠪࡁࠬ坠"),1)
				dict[key] = l1111_l1_(value)
		if l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ坡") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ坢")] = l1111_l1_(dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ坣")])
		#if l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹ࠽ࠨ坤") in dict[l11ll1_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ坥")]: dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ坦")] = dict[l11ll1_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ坧")].split(l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࡁࡡࠨࠧ坨"))[1].strip(l11ll1_l1_ (u"ࠬࡢࠢࠨ坩"))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ坪"),dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ坫")]+l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡࠩ坬")+dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ坭")])
		l11l1111l1ll_l1_.append(dict)
	l11l1l1ll_l1_ = l11ll1_l1_ (u"ࠪࠫ坮")
	if l11ll1_l1_ (u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫ坯") in l11lll11l1_l1_:
		#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠴ࡿࡴࡴ࠱࡭ࡷࡧ࡯࡮࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࠰࠭ࡃ࠮ࠨࠧ坰"),html,re.DOTALL)
		# l11l111l11ll_l1_:	/s/l11llllll1l_l1_/6dde7fb4/l11111l111l1_l1_.l111l111l1ll_l1_/l111l1l1ll1l_l1_/base.l111111llll1_l1_
		#l11l11l11l1l_l1_ = [l11ll1_l1_ (u"࠭࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱ࡧ࠼࠼ࡪ࠵࠹࠳ࡩ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࡚࡙࠯ࡣࡣࡶࡩ࠳ࡰࡳࠨ坱")]
		l11l11l11l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭坲"),html,re.DOTALL)
		if l11l11l11l1l_l1_:
			l11l11l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ坳")][0]+l11l11l11l1l_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭坴"),l11l11l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ坵"),l11ll1_l1_ (u"ࠫࠬ坶"),l11ll1_l1_ (u"ࠬ࠭坷"),l11ll1_l1_ (u"࠭ࠧ坸"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨ坹"))
			l11l1l1ll_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l111111l1ll1_l1_ = cipher._load_javascript(l11l1l1ll_l1_)
			l1llllllll1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ坺"),str(l111111l1ll1_l1_))
			l1111l11l111_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1llllllll1ll_l1_)
	for dict in l11l1111l1ll_l1_:
		url = dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭坻")]
		if l11ll1_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧ坼") in url or url.count(l11ll1_l1_ (u"ࠫࡸ࡯ࡧ࠾ࠩ坽"))>1:
			l11l1111ll11_l1_.append(dict)
		elif l11l1l1ll_l1_ and l11ll1_l1_ (u"ࠬࡹࠧ坾") in list(dict.keys()) and l11ll1_l1_ (u"࠭ࡳࡱࠩ坿") in list(dict.keys()):
			l111ll1111ll_l1_ = l1111l11l111_l1_.execute(dict[l11ll1_l1_ (u"ࠧࡴࠩ垀")])
			if l111ll1111ll_l1_!=dict[l11ll1_l1_ (u"ࠨࡵࠪ垁")]:
				dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭垂")] = url+l11ll1_l1_ (u"ࠪࠪࠬ垃")+dict[l11ll1_l1_ (u"ࠫࡸࡶࠧ垄")]+l11ll1_l1_ (u"ࠬࡃࠧ垅")+l111ll1111ll_l1_
				l11l1111ll11_l1_.append(dict)
	for dict in l11l1111ll11_l1_:
		l11lll1_l1_,l11111ll11ll_l1_,l1111ll11lll_l1_,l11ll11ll_l1_,codecs,l11l11lll11_l1_ = l11ll1_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ垆"),l11ll1_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ垇"),l11ll1_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ垈"),l11ll1_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ垉"),l11ll1_l1_ (u"ࠪࠫ垊"),l11ll1_l1_ (u"ࠫ࠵࠭型")
		try:
			l11l1111ll1l_l1_ = dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧࠪ垌")]
			l11l1111ll1l_l1_ = l11l1111ll1l_l1_.replace(l11ll1_l1_ (u"࠭ࠫࠨ垍"),l11ll1_l1_ (u"ࠧࠨ垎"))
			items = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ垏"),l11l1111ll1l_l1_,re.DOTALL)
			l11ll11ll_l1_,l11lll1_l1_,codecs = items[0]
			l11l1l1111ll_l1_ = codecs.split(l11ll1_l1_ (u"ࠩ࠯ࠫ垐"))
			l11111ll11ll_l1_ = l11ll1_l1_ (u"ࠪࠫ垑")
			for item in l11l1l1111ll_l1_: l11111ll11ll_l1_ += item.split(l11ll1_l1_ (u"ࠫ࠳࠭垒"))[0]+l11ll1_l1_ (u"ࠬ࠲ࠧ垓")
			l11111ll11ll_l1_ = l11111ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠬࠨ垔"))
			if l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ垕") in list(dict.keys()): l11l11lll11_l1_ = str(float(dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ垖")]*10)//1024/10)+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ垗")
			else: l11l11lll11_l1_ = l11ll1_l1_ (u"ࠪࠫ垘")
			if l11ll11ll_l1_==l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ垙"): continue
			elif l11ll1_l1_ (u"ࠬ࠲ࠧ垚") in l11l1111ll1l_l1_:
				l11ll11ll_l1_ = l11ll1_l1_ (u"࠭ࡁࠬࡘࠪ垛")
				l1111ll11lll_l1_ = l11lll1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ垜")+l11l11lll11_l1_+dict[l11ll1_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭垝")].split(l11ll1_l1_ (u"ࠩࡻࠫ垞"))[1]
			elif l11ll11ll_l1_==l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ垟"):
				l11ll11ll_l1_ = l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ垠")
				l1111ll11lll_l1_ = l11l11lll11_l1_+dict[l11ll1_l1_ (u"ࠬࡹࡩࡻࡧࠪ垡")].split(l11ll1_l1_ (u"࠭ࡸࠨ垢"))[1]+l11ll1_l1_ (u"ࠧࠡࠢࠪ垣")+dict[l11ll1_l1_ (u"ࠨࡨࡳࡷࠬ垤")]+l11ll1_l1_ (u"ࠩࡩࡴࡸ࠭垥")+l11ll1_l1_ (u"ࠪࠤࠥ࠭垦")+l11lll1_l1_
			elif l11ll11ll_l1_==l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ垧"):
				l11ll11ll_l1_ = l11ll1_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ垨")
				l1111ll11lll_l1_ = l11l11lll11_l1_+str(int(dict[l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ垩")])/1000)+l11ll1_l1_ (u"ࠧ࡬ࡪࡽࠤࠥ࠭垪")+dict[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ垫")]+l11ll1_l1_ (u"ࠩࡦ࡬ࠬ垬")+l11ll1_l1_ (u"ࠪࠤࠥ࠭垭")+l11lll1_l1_
		except:
			l1lllllll111_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllllll111_l1_)
		if l11ll1_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ垮") in dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ垯")]: l1l11ll1l_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ垰")].split(l11ll1_l1_ (u"ࠧࡥࡷࡵࡁࠬ垱"),1)[1].split(l11ll1_l1_ (u"ࠨࠨࠪ垲"),1)[0]))
		elif l11ll1_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ垳") in list(dict.keys()): l1l11ll1l_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭垴")])/1000)
		else: l1l11ll1l_l1_ = l11ll1_l1_ (u"ࠫ࠵࠭垵")
		if l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭垶") not in list(dict.keys()): l11l11lll11_l1_ = dict[l11ll1_l1_ (u"࠭ࡳࡪࡼࡨࠫ垷")].split(l11ll1_l1_ (u"ࠧࡹࠩ垸"))[1]
		else: l11l11lll11_l1_ = dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ垹")]
		if l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ垺") not in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ垻")] = l11ll1_l1_ (u"ࠫ࠵࠳࠰ࠨ垼")
		dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ垽")] = l11ll11ll_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ垾")+l1111ll11lll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠫࠫ垿")+l11111ll11ll_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ埀")+dict[l11ll1_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ埁")]+l11ll1_l1_ (u"ࠪ࠭ࠬ埂")
		dict[l11ll1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ埃")] = l1111ll11lll_l1_.split(l11ll1_l1_ (u"ࠬࠦࠠࠨ埄"))[0].split(l11ll1_l1_ (u"࠭࡫ࡣࡲࡶࠫ埅"))[0]
		dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭埆")] = l11ll11ll_l1_
		dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ埇")] = l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ埈")] = codecs
		dict[l11ll1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ埉")] = l1l11ll1l_l1_
		dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ埊")] = l11l11lll11_l1_
		l11l1111l1l1_l1_.append(dict)
	l111ll1l1ll1_l1_,l11l11l11ll1_l1_,l11l1l1l1l11_l1_,l111l11l11ll_l1_,l111lllll1ll_l1_ = [],[],[],[],[]
	l111l1111111_l1_,l11l111l111l_l1_,l1111l1lll1l_l1_,l11l1l11111l_l1_,l11l1l11llll_l1_ = [],[],[],[],[]
	if l1lllllllll11_l1_:
		dict = {}
		dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ埋")] = l11ll1_l1_ (u"࠭ࡁࠬࡘࠪ埌")
		dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ埍")] = l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ城")
		dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ埏")] = dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ埐")]+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ埑")+dict[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ埒")]+l11ll1_l1_ (u"࠭ࠠࠡࠩ埓")+l11ll1_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ埔")
		dict[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ埕")] = l1lllllllll11_l1_
		dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ埖")] = l11ll1_l1_ (u"ࠪ࠴ࠬ埗") # for l11l1l11l1_l1_ l1lllllllll11_l1_ any l1l111ll1_l1_ will l111llllllll_l1_ l1111l11l1l1_l1_ sort l1l1l1lll1l_l1_
		dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ埘")] = l11ll1_l1_ (u"ࠬ࠿࠸࠸࠸࠸࠸࠸࠸࠱࠱ࠩ埙") # 20
		l11l1111l1l1_l1_.append(dict)
	if l11l1l1ll11l_l1_:
		l11111l1l11l_l1_,l11l111llll1_l1_ = l11ll11l1l_l1_(l11l1l1ll11l_l1_)
		l11l11ll11ll_l1_ = list(zip(l11111l1l11l_l1_,l11l111llll1_l1_))
		for title,l1lllll_l1_ in l11l11ll11ll_l1_:
			dict = {}
			dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ埚")] = l11ll1_l1_ (u"ࠧࡂ࡙࠭ࠫ埛")
			dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ埜")] = l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ埝")
			dict[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ埞")] = l1lllll_l1_
			#if l11ll1_l1_ (u"ࠫࡇ࡝࠺ࠡࠩ域") in title: dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭埠")] = title.split(l11ll1_l1_ (u"࠭ࠠࠡࠩ埡"))[1].split(l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ埢"))[0]
			#if l11ll1_l1_ (u"ࠨࡔࡨࡷ࠿ࠦࠧ埣") in title: dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ埤")] = title.split(l11ll1_l1_ (u"ࠪࡖࡪࡹ࠺ࠡࠩ埥"))[1]
			# title = l11ll1_l1_ (u"ࠦ࠹࠸࠶࠸࡭ࡥࡴࡸࠦࠠ࠸࠴࠳ࠤࠥ࠴࡭࠴ࡷ࠻ࠦ埦")
			if l11ll1_l1_ (u"ࠬࡱࡢࡱࡵࠪ埧") in title: dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ埨")] = title.split(l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ埩"))[0].rsplit(l11ll1_l1_ (u"ࠨࠢࠣࠫ埪"))[-1]
			else: dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ埫")] = l11ll1_l1_ (u"ࠪ࠵࠵࠭埬")
			if title.count(l11ll1_l1_ (u"ࠫࠥࠦࠧ埭"))>1:
				l111lll1_l1_ = title.rsplit(l11ll1_l1_ (u"ࠬࠦࠠࠨ埮"))[-3]
				if l111lll1_l1_.isdigit(): dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ埯")] = l111lll1_l1_
				else: dict[l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ埰")] = l11ll1_l1_ (u"ࠨ࠲࠳࠴࠵࠭埱")
			#dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ埲")] = title
			if title==l11ll1_l1_ (u"ࠪ࠱࠶࠭埳"): dict[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ埴")] = dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ埵")]+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ埶")+dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ執")]+l11ll1_l1_ (u"ࠨࠢࠣࠫ埸")+l11ll1_l1_ (u"ࠩฯ์ิฯࠠัๅํอࠬ培")
			else: dict[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ基")] = dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ埻")]+l11ll1_l1_ (u"ࠬࡀࠠࠡࠩ埼")+dict[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ埽")]+l11ll1_l1_ (u"ࠧࠡࠢࠪ埾")+dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ埿")]+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ堀")+dict[l11ll1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ堁")]
			l11l1111l1l1_l1_.append(dict)
	l11l1111l1l1_l1_ = sorted(l11l1111l1l1_l1_,reverse=True,key=lambda key: float(key[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ堂")]))
	if not l11l1111l1l1_l1_:
		l1ll11l11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ堃"),html,re.DOTALL)
		l1ll11l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺࡝ࡽࠥࡶࡺࡴࡳࠣ࠼࡟࡟ࡡࢁࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堄"),html,re.DOTALL)
		l111ll1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堅"),html,re.DOTALL)
		l111ll1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ堆"),html,re.DOTALL)
		try: l111ll1l11ll_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭堇")][l11ll1_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ堈")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ堉")][l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ堊")][l11ll1_l1_ (u"࠭ࡲࡶࡰࡶࠫ堋")][0][l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ堌")]
		except: l111ll1l11ll_l1_ = l11ll1_l1_ (u"ࠨࠩ堍")
		try: l111ll1l1l11_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭堎")][l11ll1_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ堏")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ堐")][l11ll1_l1_ (u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭堑")][0][l11ll1_l1_ (u"࠭ࡲࡶࡰࡶࠫ堒")][0][l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ堓")]
		except: l111ll1l1l11_l1_ = l11ll1_l1_ (u"ࠨࠩ堔")
		try: l1111l111lll_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭堕")][l11ll1_l1_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ堖")]
		except: l1111l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ堗")
		if l1ll11l11ll_l1_ or l1ll11l1l11_l1_ or l111ll1l111l_l1_ or l111ll1l11l1_l1_ or l111ll1l11ll_l1_ or l111ll1l1l11_l1_ or l1111l111lll_l1_:
			if   l1ll11l11ll_l1_: message = l1ll11l11ll_l1_[0]
			elif l1ll11l1l11_l1_: message = l1ll11l1l11_l1_[0]
			elif l111ll1l111l_l1_: message = l111ll1l111l_l1_[0]
			elif l111ll1l11l1_l1_: message = l111ll1l11l1_l1_[0]
			elif l111ll1l11ll_l1_: message = l111ll1l11ll_l1_
			elif l111ll1l1l11_l1_: message = l111ll1l1l11_l1_
			elif l1111l111lll_l1_: message = l1111l111lll_l1_
			l1111ll11111_l1_ = message.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ堘"),l11ll1_l1_ (u"࠭ࠧ堙")).strip(l11ll1_l1_ (u"ࠧࠡࠩ堚"))
			l111lll1llll_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋ีอࠠศๆไ๎ิ๐่ࠡใํ๋๋ࠥิไๆฬࠤํ่ฯࠡ์ๆ์ฺ๋๋ࠦำ้้ࠣอฦๆࠢ็ฬ฾฼ࠠศๆ่ืฯิฯๆ์้ࠤศ๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ堛")
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ堜"),l11ll1_l1_ (u"ࠪࠫ堝"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾่ࠦศๆ่ฬึ๋ฬࠨ堞"),l111lll1llll_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ堟")+l1111ll11111_l1_)
			return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩࡀࠠࠨ堠")+l1111ll11111_l1_,[],[]
		else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧ堡"),[],[]
	l1111l11l11l_l1_,l1llllll1l1ll_l1_,l111l1llllll_l1_ = [],[],[]
	for dict in l11l1111l1l1_l1_:
		if dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ堢")]==l11ll1_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ堣"):
			l111ll1l1ll1_l1_.append(dict[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ堤")])
			l111l1111111_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ堥")]==l11ll1_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ堦"):
			l11l11l11ll1_l1_.append(dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ堧")])
			l11l111l111l_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ堨")]==l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ堩"):
			title = dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ堪")].replace(l11ll1_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ堫"),l11ll1_l1_ (u"ࠫࠬ堬"))
			if l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭堭") not in list(dict.keys()): l11l11lll11_l1_ = l11ll1_l1_ (u"࠭࠰ࠨ堮")
			else: l11l11lll11_l1_ = dict[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ堯")]
			l1111l11l11l_l1_.append([dict,{},title,l11l11lll11_l1_])
		else:
			title = dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ堰")].replace(l11ll1_l1_ (u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ報"),l11ll1_l1_ (u"ࠪࠫ堲"))
			if l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ堳") not in list(dict.keys()): l11l11lll11_l1_ = l11ll1_l1_ (u"ࠬ࠶ࠧ場")
			else: l11l11lll11_l1_ = dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ堵")]
			l1111l11l11l_l1_.append([dict,{},title,l11l11lll11_l1_])
			l11l1l1l1l11_l1_.append(title)
			l1111l1lll1l_l1_.append(dict)
		l11l11ll1ll1_l1_ = True
		if l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ堶") in list(dict.keys()):
			if l11ll1_l1_ (u"ࠨࡣࡹ࠴ࠬ堷") in dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ堸")]: l11l11ll1ll1_l1_ = False
			elif kodi_version<18:
				if l11ll1_l1_ (u"ࠪࡥࡻࡩࠧ堹") not in dict[l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ堺")] and l11ll1_l1_ (u"ࠬࡳࡰ࠵ࡣࠪ堻") not in dict[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭堼")]: l11l11ll1ll1_l1_ = False
		if dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭堽")]==l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ堾") and dict[l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ堿")]!=l11ll1_l1_ (u"ࠪ࠴࠲࠶ࠧ塀") and l11l11ll1ll1_l1_==True:
			l111lllll1ll_l1_.append(dict[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ塁")])
			l11l1l11llll_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ塂")]==l11ll1_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ塃") and dict[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ塄")]!=l11ll1_l1_ (u"ࠨ࠲࠰࠴ࠬ塅") and l11l11ll1ll1_l1_==True:
			l111l11l11ll_l1_.append(dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ塆")])
			l11l1l11111l_l1_.append(dict)
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ塇"),l11ll1_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮࠯ࠥࠦࠠࠨ塈")+dict[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ塉")])
	for l11l11l1ll1l_l1_ in l11l1l11111l_l1_:
		l111l11l1ll1_l1_ = l11l11l1ll1l_l1_[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ塊")]
		for l111ll11ll11_l1_ in l11l1l11llll_l1_:
			l11111lll1l1_l1_ = l111ll11ll11_l1_[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ塋")]
			l11l11lll11_l1_ = l11111lll1l1_l1_+l111l11l1ll1_l1_
			title = l111ll11ll11_l1_[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ塌")].replace(l11ll1_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠣࠫ塍"),l11ll1_l1_ (u"ࠪࡱࡵࡪࠠࠡࠩ塎"))
			title = title.replace(l111ll11ll11_l1_[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭塏")]+l11ll1_l1_ (u"ࠬࠦࠠࠨ塐"),l11ll1_l1_ (u"࠭ࠧ塑"))
			title = title.replace(str((float(l11111lll1l1_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ塒"),str((float(l11l11lll11_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭塓"))
			title = title+l11ll1_l1_ (u"ࠩࠫࠫ塔")+l11l11l1ll1l_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ塕")].split(l11ll1_l1_ (u"ࠫ࠭࠭塖"),1)[1]
			l1111l11l11l_l1_.append([l111ll11ll11_l1_,l11l11l1ll1l_l1_,title,l11l11lll11_l1_])
	l1111l11l11l_l1_ = sorted(l1111l11l11l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111ll11ll11_l1_,l11l11l1ll1l_l1_,title,l11l11lll11_l1_ in l1111l11l11l_l1_:
		l11l11111lll_l1_ = l111ll11ll11_l1_[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ塗")]
		if l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ塘") in list(l11l11l1ll1l_l1_.keys()):
			l11l11111lll_l1_ = l11ll1_l1_ (u"ࠧ࡮ࡲࡧࠫ塙")
			#l11l11111lll_l1_ = l11l11111lll_l1_+l11l11l1ll1l_l1_[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ塚")]
		if l11l11111lll_l1_ not in l111l1llllll_l1_:
			l111l1llllll_l1_.append(l11l11111lll_l1_)
			l1llllll1l1ll_l1_.append([l111ll11ll11_l1_,l11l11l1ll1l_l1_,title,l11l11lll11_l1_])
			#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ塛"),str(l11l11lll11_l1_)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ塜")+title)
	#l1llllll1l1ll_l1_ = sorted(l1llllll1l1ll_l1_, reverse=True, key=lambda key: int(key[3]))
	l1111l111ll1_l1_,l111l111l1l1_l1_,shift = [],[],0
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡱࡺࡲࡪࡸࠢ࠻࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡀࠊࠊࠋࡶ࡬࡮࡬ࡴࠡ࠭ࡀࠤ࠶ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧࠬࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠴ࡢ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠲࡟ࠍࠍࠎࡹࡥ࡭ࡧࡦࡸࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡨ࡮࡯ࡪࡥࡨࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠤࠥࠦ塝")
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡲࡻࡳ࡫ࡲࡠࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬ࡠ࡬ࡶࡳࡳ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡴࡽ࡮ࡦࡴࡢࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡤࡹࡹ࡮࡯ࡳࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯ࡣ࡯ࡹ࡯࡯࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫࠺ࠋࠋࠌ࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡢ࡮࡯ࡳࡼࡘࡡࡵ࡫ࡱ࡫ࡸࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡ࡫ࡰࡥ࡬࡫ࡳࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࠎ࡯࡭ࡢࡩࡨࡷࡤࡻࡲ࡭ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡭ࡲࡧࡧࡦࡵࡢࡹࡷࡲ࠺ࠡ࡫ࡰࡥ࡬࡫ࠠ࠾ࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࡡ࠭࠲࡟ࠍࠍࠎࡵࡷ࡯ࡧࡵࠤࡂࠦ࡯ࡸࡰࡨࡶࡤࡴࡡ࡮ࡧ࡞࠴ࡢࠐࠉࠊࡵ࡫࡭࡫ࡺࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࠫࡰࡹࡱࡩࡷ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡝ࡅࡃࡕࡌࡘࡊ࡙࡛ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩࡠ࡟࠵ࡣࠫࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ࠰ࡵࡷ࡯ࡧࡵࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡠ࠶࡝ࠋࠋࠌࡷࡪࡲࡥࡤࡶࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡦ࡬ࡴ࡯ࡣࡦࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ塞")
	l11l11lll111_l1_,l11l1111111l_l1_ = l11ll1_l1_ (u"࠭ࠧ塟"),l11ll1_l1_ (u"ࠧࠨ塠")
	try: l11l11lll111_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ塡")][l11ll1_l1_ (u"ࠩࡤࡹࡹ࡮࡯ࡳࠩ塢")]
	except: l11l11lll111_l1_ = l11ll1_l1_ (u"ࠪࠫ塣")
	try: l1111ll1111l_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ塤")][l11ll1_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨ塥")]
	except: l1111ll1111l_l1_ = l11ll1_l1_ (u"࠭ࠧ塦")
	if l11l11lll111_l1_ and l1111ll1111l_l1_:
		shift += 1
		title = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ塧")+l11l11lll111_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ塨")
		l1lllll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ塩")][0]+l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭塪")+l1111ll1111l_l1_
		l1111l111ll1_l1_.append(title)
		l111l111l1l1_l1_.append(l1lllll_l1_)
		try: l11l1111111l_l1_ = l11111ll11l1_l1_[l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ填")][l11ll1_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ塬")][l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ塭")][-1][l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ塮")]
		except: pass
	#if l1lllllllll11_l1_:
	#	shift += 1
	#	l1111l111ll1_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠥา่ะหࠣิ่๐ษࠨ塯")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠩࡧࡥࡸ࡮ࠧ塰"))
	for l111ll11ll11_l1_,l11l11l1ll1l_l1_,title,l11l11lll11_l1_ in l1llllll1l1ll_l1_:
		l1111l111ll1_l1_.append(title) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ塱"))
	if l11l1l1l1l11_l1_: l1111l111ll1_l1_.append(l11ll1_l1_ (u"ฺࠫ๎ัสู๋ࠢํะࠠๆฯาำฮ࠭塲")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ塳"))
	if l1111l11l11l_l1_: l1111l111ll1_l1_.append(l11ll1_l1_ (u"࠭ี้ำฬࠤํ฻่หࠢส่๊ะ่โำࠪ塴")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫ塵"))
	if l111lllll1ll_l1_: l1111l111ll1_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠥอฮหำࠣห้฻่าหࠣ์ฬ๊ี้ฬࠪ塶")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠩࡰࡴࡩ࠭塷"))
	if l111ll1l1ll1_l1_: l1111l111ll1_l1_.append(l11ll1_l1_ (u"ูࠪํืษࠡสา์๋ࠦี้ฬࠪ塸")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ塹"))
	if l11l11l11ll1_l1_: l1111l111ll1_l1_.append(l11ll1_l1_ (u"ࠬ฻่หࠢหำํ์ࠠึ๊ิอࠬ塺")) ; l111l111l1l1_l1_.append(l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ塻"))
	l11l1l1l1ll1_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1llllll11111_l1_, l1111l111ll1_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ塼"),[],[]
		elif l1l_l1_==0 and l11l11lll111_l1_:
			l1lllll_l1_ = l111l111l1l1_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11ll1_l1_ (u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠷࠴࠲ࠨࡱࡥࡲ࡫࠽ࠨ塽")+QUOTE(l11l11lll111_l1_)+l11ll1_l1_ (u"ࠩࠩࡹࡷࡲ࠽ࠨ塾")+l1lllll_l1_
			if l11l1111111l_l1_: new_path = new_path+l11ll1_l1_ (u"ࠪࠪ࡮ࡳࡡࡨࡧࡀࠫ塿")+QUOTE(l11l1111111l_l1_)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ墀")+new_path+l11ll1_l1_ (u"ࠧ࠯ࠢ墁"))
			return l11ll1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ墂"),[],[]
		choice = l111l111l1l1_l1_[l1l_l1_]
		l11111l1111l_l1_ = l1111l111ll1_l1_[l1l_l1_]
		if choice==l11ll1_l1_ (u"ࠧࡥࡣࡶ࡬ࠬ境"):
			l1111111ll1l_l1_ = l1lllllllll11_l1_
			break
		elif choice in [l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ墄"),l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ墅"),l11ll1_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ墆")]:
			if choice==l11ll1_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ墇"): l1lll111_l1_,l1111lll1111_l1_ = l11l1l1l1l11_l1_,l1111l1lll1l_l1_
			elif choice==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ墈"): l1lll111_l1_,l1111lll1111_l1_ = l111ll1l1ll1_l1_,l111l1111111_l1_
			elif choice==l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ墉"): l1lll111_l1_,l1111lll1111_l1_ = l11l11l11ll1_l1_,l11l111l111l_l1_
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭墊"), l1lll111_l1_)
			if l1l_l1_!=-1:
				l1111111ll1l_l1_ = l1111lll1111_l1_[l1l_l1_][l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ墋")]
				l11111l1111l_l1_ = l1lll111_l1_[l1l_l1_]
				break
		elif choice==l11ll1_l1_ (u"ࠩࡰࡴࡩ࠭墌"):
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࡀࠧ墍"), l111lllll1ll_l1_)
			if l1l_l1_!=-1:
				l11111l1111l_l1_ = l111lllll1ll_l1_[l1l_l1_]
				l11l111111l1_l1_ = l11l1l11llll_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࡀࠧ墎"), l111l11l11ll_l1_)
				if l1l_l1_!=-1:
					l11111l1111l_l1_ += l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ墏")+l111l11l11ll_l1_[l1l_l1_]
					l111ll11l1l1_l1_ = l11l1l11111l_l1_[l1l_l1_]
					l11l1l1l1ll1_l1_ = True
					break
		elif choice==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪ墐"):
			l11l111ll1l1_l1_,l111l11lll11_l1_,l1lllllll1111_l1_,l111lll1l1ll_l1_ = list(zip(*l1111l11l11l_l1_))
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭墑"), l1lllllll1111_l1_)
			if l1l_l1_!=-1:
				l11111l1111l_l1_ = l1lllllll1111_l1_[l1l_l1_]
				l11l111111l1_l1_ = l11l111ll1l1_l1_[l1l_l1_]
				if l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ墒") in l1lllllll1111_l1_[l1l_l1_] and l11l111111l1_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭墓")]!=l1lllllllll11_l1_:
					l111ll11l1l1_l1_ = l111l11lll11_l1_[l1l_l1_]
					l11l1l1l1ll1_l1_ = True
				else: l1111111ll1l_l1_ = l11l111111l1_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ墔")]
				break
		elif choice==l11ll1_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ墕"):
			#shift += 1
			l11l111ll1l1_l1_,l111l11lll11_l1_,l1lllllll1111_l1_,l111lll1l1ll_l1_ = list(zip(*l1llllll1l1ll_l1_))
			l11l111111l1_l1_ = l11l111ll1l1_l1_[l1l_l1_-shift]
			if l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ墖") in l1lllllll1111_l1_[l1l_l1_-shift] and l11l111111l1_l1_[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ増")]!=l1lllllllll11_l1_:
				l111ll11l1l1_l1_ = l111l11lll11_l1_[l1l_l1_-shift]
				l11l1l1l1ll1_l1_ = True
			else: l1111111ll1l_l1_ = l11l111111l1_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ墘")]
			l11111l1111l_l1_ = l1lllllll1111_l1_[l1l_l1_-shift]
			break
	if not l11l1l1l1ll1_l1_: l1111111l111_l1_ = l1111111ll1l_l1_
	else: l1111111l111_l1_ = l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠩ墙")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭墚")]+l11ll1_l1_ (u"ࠪࠤ࠰ࠦࡁࡶࡦ࡬ࡳ࠿ࠦࠧ墛")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ墜")]
	if l11l1l1l1ll1_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭墝"),l11ll1_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰࠱ࠠࠡࠢࠪ增")+str(l11l111111l1_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ墟"),l11ll1_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ墠")+str(l111ll11l1l1_l1_))
		#if l11l1l11ll1l_l1_>l111l1lll1ll_l1_: l1l11ll1l_l1_ = str(l11l1l11ll1l_l1_)
		#else: l1l11ll1l_l1_ = str(l111l1lll1ll_l1_)
		#l1l11ll1l_l1_ = str(l11l1l11ll1l_l1_) if l11l1l11ll1l_l1_>l111l1lll1ll_l1_ else str(l111l1lll1ll_l1_)
		l11l1l11ll1l_l1_ = int(l11l111111l1_l1_[l11ll1_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ墡")])
		l111l1lll1ll_l1_ = int(l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ墢")])
		l1l11ll1l_l1_ = str(max(l11l1l11ll1l_l1_,l111l1lll1ll_l1_))
		l111l1l1l1ll_l1_ = l11l111111l1_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ墣")].replace(l11ll1_l1_ (u"ࠬࠬࠧ墤"),l11ll1_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ墥"))		# +l11ll1_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ墦")
		l11l11l11lll_l1_ = l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ墧")].replace(l11ll1_l1_ (u"ࠩࠩࠫ墨"),l11ll1_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ墩"))		# +l11ll1_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ墪")
		l11l1l1l11ll_l1_ = l11ll1_l1_ (u"ࠬࡂ࠿ࡹ࡯࡯ࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨ࠱࠯࠲ࠥࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࡃࠢࡖࡖࡉ࠱࠽ࠨ࠿࠿࡞ࡱࠫ墫")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"࠭࠼ࡎࡒࡇࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡸ࡯࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠸࠰࠱࠳࠲࡜ࡒࡒࡓࡤࡪࡨࡱࡦ࠳ࡩ࡯ࡵࡷࡥࡳࡩࡥࠣࠢࡻࡱࡱࡴࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠦࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡲࡩ࡯࡭ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠳࠼࠽࠾࠵ࡸ࡭࡫ࡱ࡯ࠧࠦࡸࡴ࡫࠽ࡷࡨ࡮ࡥ࡮ࡣࡏࡳࡨࡧࡴࡪࡱࡱࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠠࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡲࡩࡧࡲࡥࡵ࠱࡭ࡸࡵ࠮ࡰࡴࡪ࠳࡮ࡺࡴࡧ࠱ࡓࡹࡧࡲࡩࡤ࡮ࡼࡅࡻࡧࡩ࡭ࡣࡥࡰࡪ࡙ࡴࡢࡰࡧࡥࡷࡪࡳ࠰ࡏࡓࡉࡌ࠳ࡄࡂࡕࡋࡣࡸࡩࡨࡦ࡯ࡤࡣ࡫࡯࡬ࡦࡵ࠲ࡈࡆ࡙ࡈ࠮ࡏࡓࡈ࠳ࡾࡳࡥࠤࠣࡱ࡮ࡴࡂࡶࡨࡩࡩࡷ࡚ࡩ࡮ࡧࡀࠦࡕ࡚࠱࠯࠷ࡖࠦࠥࡳࡥࡥ࡫ࡤࡔࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡆࡸࡶࡦࡺࡩࡰࡰࡀࠦࡕ࡚ࠧ墬")+l1l11ll1l_l1_+l11ll1_l1_ (u"ࠧࡔࠤࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࡁࡠࡳ࠭墭")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ墮")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠱ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡶࡪࡦࡨࡳ࠴࠭墯")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ墰")]+l11ll1_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ墱")		# l111ll11111l_l1_=l11ll1_l1_ (u"ࠧ࠷ࠢ墲") l11l1l1l111l_l1_=l11ll1_l1_ (u"ࠨࡴࡳࡷࡨࠦ墳") default=l11ll1_l1_ (u"ࠢࡵࡴࡸࡩࠧ墴")>\n
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭墵")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ墶")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ墷")]+l11ll1_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ墸")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ墹")]+l11ll1_l1_ (u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ墺")+str(l11l111111l1_l1_[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ墻")])+l11ll1_l1_ (u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ墼")+str(l11l111111l1_l1_[l11ll1_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ墽")])+l11ll1_l1_ (u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ墾")+str(l11l111111l1_l1_[l11ll1_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ墿")])+l11ll1_l1_ (u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬ壀")+l11l111111l1_l1_[l11ll1_l1_ (u"࠭ࡦࡱࡵࠪ壁")]+l11ll1_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ壂")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ壃")+l111l1l1l1ll_l1_+l11ll1_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ壄")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ壅")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ壆")]+l11ll1_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ壇")	# l1llllll1ll11_l1_=l11ll1_l1_ (u"ࠨࡴࡳࡷࡨࠦ壈")>\n
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ壉")+l11l111111l1_l1_[l11ll1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭壊")]+l11ll1_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ壋")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭壌")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ壍")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ壎")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪ壏")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ壐")]+l11ll1_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ壑")		# l111ll11111l_l1_=l11ll1_l1_ (u"ࠤ࠴ࠦ壒") l11l1l1l111l_l1_=l11ll1_l1_ (u"ࠥࡸࡷࡻࡥࠣ壓") default=l11ll1_l1_ (u"ࠦࡹࡸࡵࡦࠤ壔")>\n
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ壕")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭壖")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ壗")]+l11ll1_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ壘")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ壙")]+l11ll1_l1_ (u"ࠪࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤ࠴࠷࠵࠺࠷࠶ࠤࡁࡠࡳ࠭壚")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠫࡁࡇࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼࠵࠷࠵࠶࠳࠻࠵࠽ࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠪ壛")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭壜")]+l11ll1_l1_ (u"࠭ࠢ࠰ࡀ࡟ࡲࠬ壝")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ壞")+l11l11l11lll_l1_+l11ll1_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ壟")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ壠")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ壡")]+l11ll1_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ壢")	# l1llllll1ll11_l1_=l11ll1_l1_ (u"ࠧࡺࡲࡶࡧࠥ壣")>\n
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ壤")+l111ll11l1l1_l1_[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ壥")]+l11ll1_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ壦")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ壧")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ壨")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ壩")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"ࠬࡂ࠯ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪ壪")
		l11l1l1l11ll_l1_ += l11ll1_l1_ (u"࠭࠼࠰ࡏࡓࡈࡃࡢ࡮ࠨ士")
		#open(l11ll1_l1_ (u"ࠧࡴ࠼࡟ࡠࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ壬"),l11ll1_l1_ (u"ࠨࡹࡥࠫ壭")).write(l11l1l1l11ll_l1_)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ壮"),l11l1l1l11ll_l1_)
		#l11l1l1l11ll_l1_ = OPENURL_CACHED(NO_CACHE,l1lllllllll11_l1_,l11ll1_l1_ (u"ࠪࠫ壯"),l11ll1_l1_ (u"ࠫࠬ声"),l11ll1_l1_ (u"ࠬ࠭壱"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠽ࡹ࡮ࠧ売"))
		if kodi_version>18.99:
			import http.server as l111ll1lllll_l1_
			import http.client as l1111l111l1l_l1_
		else:
			import BaseHTTPServer as l111ll1lllll_l1_
			import httplib as l1111l111l1l_l1_
		class l111111lll11_l1_(l111ll1lllll_l1_.HTTPServer):
			#l11l1l1l11ll_l1_ = l11ll1_l1_ (u"ࠧ࠽ࡀࠪ壳")
			def __init__(self,l1ll111l11l1_l1_=l11ll1_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ壴"),port=55055,l11l1l1l11ll_l1_=l11ll1_l1_ (u"ࠩ࠿ࡂࠬ壵")):
				self.l1ll111l11l1_l1_ = l1ll111l11l1_l1_
				self.port = port
				self.l11l1l1l11ll_l1_ = l11l1l1l11ll_l1_
				l111ll1lllll_l1_.HTTPServer.__init__(self,(self.l1ll111l11l1_l1_,self.port),l111l111ll1l_l1_)
				self.l111111l1l11_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ壶")+l1ll111l11l1_l1_+l11ll1_l1_ (u"ࠫ࠿࠭壷")+str(port)+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ壸")
				#print(l11ll1_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡴࠥࡴ࡯ࡸࠢ࡯࡭ࡸࡺࡥ࡯࡫ࡱ࡫ࠥࡵ࡮ࠡࡲࡲࡶࡹࡀࠠࠨ壹")+str(port))
			def start(self):
				self.threads = l111l1lll1l_l1_(False)
				self.threads.start_new_thread(1,self.l111l1ll1l1l_l1_)
			def l111l1ll1l1l_l1_(self):
				#print(l11ll1_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡧࡲࡵࡧࡧࠫ壺"))
				self.l1llllll11lll_l1_ = True
				#l1l1l1lllll_l1_ = 0
				while self.l1llllll11lll_l1_:
					#l1l1l1lllll_l1_ += 1
					#print(l11ll1_l1_ (u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠢࡤࠤࡸ࡯࡮ࡨ࡮ࡨࠤ࡭ࡧ࡮ࡥ࡮ࡨࡣࡷ࡫ࡱࡶࡧࡶࡸ࠭࠯ࠠ࡯ࡱࡺ࠾ࠥ࠭壻")+str(l1l1l1lllll_l1_)+l11ll1_l1_ (u"ࠩࠪ壼"))
					#settimeout l1111ll1ll_l1_ not l111l1l111_l1_ l1111l1ll1l1_l1_ to error message if it l11111ll1111_l1_ l1lllllll1ll1_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111l1ll1l1l_l1_ l111l1lllll1_l1_ request l1111111llll_l1_ 60 seconds)
					self.handle_request()
				#print(l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡱࡳࡴࡪࡪ࡜࡯ࠩ壽"))
			def stop(self):
				self.l1llllll11lll_l1_ = False
				self.l111ll11ll1l_l1_()	# needed to l11l1l111l11_l1_ self.handle_request() to l111l1ll1l1l_l1_ l1111lll111_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠥࡴ࡯ࡸ࡞ࡱࠫ壾"))
			def load(self,l11l1l1l11ll_l1_):
				self.l11l1l1l11ll_l1_ = l11l1l1l11ll_l1_
			def l111ll11ll1l_l1_(self):
				conn = l1111l111l1l_l1_.HTTPConnection(self.l1ll111l11l1_l1_+l11ll1_l1_ (u"ࠬࡀࠧ壿")+str(self.port))
				conn.request(l11ll1_l1_ (u"ࠨࡈࡆࡃࡇࠦ夀"), l11ll1_l1_ (u"ࠢ࠰ࠤ夁"))
		class l111l111ll1l_l1_(l111ll1lllll_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11ll1_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡈࡇࡗࠤࠥ࠭夂")+self.path)
				self.send_response(200)
				self.send_header(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ夃"),l11ll1_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ处"))
				self.end_headers()
				#self.wfile.write(self.path+l11ll1_l1_ (u"ࠫࡡࡴࠧ夅"))
				self.wfile.write(self.server.l11l1l1l11ll_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ夆")))
				time.sleep(1)
				if self.path==l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ备"): self.server.shutdown()
				if self.path==l11ll1_l1_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ夈"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11ll1_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡉࡇࡄࡈࠥࠦࠧ変")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l111111lll11_l1_(l11ll1_l1_ (u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ夊"),55055,l11l1l1l11ll_l1_)
		#httpd.load(l11l1l1l11ll_l1_)
		l1111111ll1l_l1_ = httpd.l111111l1l11_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1111111ll1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱ࡯ࡶࡦࡵ࡬ࡱ࠳ࡪࡡࡴࡪ࡬ࡪ࠳ࡵࡲࡨ࠱࡯࡭ࡻ࡫ࡳࡪ࡯࠲ࡧ࡭ࡻ࡮࡬ࡦࡸࡶࡤ࠷࠯ࡢࡶࡲࡣ࠼࠵ࡴࡦࡵࡷࡴ࡮ࡩ࠴ࡠ࠺ࡶ࠳ࡒࡧ࡮ࡪࡨࡨࡷࡹ࠴࡭ࡱࡦࠪ夋")
		#l1111111ll1l_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡡࡴࡪ࠱ࡥࡰࡧ࡭ࡢ࡫ࡽࡩࡩ࠴࡮ࡦࡶ࠲ࡨࡦࡹࡨ࠳࠸࠷࠳࡙࡫ࡳࡵࡅࡤࡷࡪࡹ࠯࠳ࡥ࠲ࡵࡺࡧ࡬ࡤࡱࡰࡱ࠴࠷࠯ࡎࡷ࡯ࡸ࡮ࡘࡥࡴࡏࡓࡉࡌ࠸࠮࡮ࡲࡧࠫ夌")
		#l1111111ll1l_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡵࡵ࡬࠲ࡹ࡫࡬ࡦࡥࡲࡱ࠲ࡶࡡࡳ࡫ࡶࡸࡪࡩࡨ࠯ࡨࡵ࠳࡬ࡶࡡࡤ࠱ࡇࡅࡘࡎ࡟ࡄࡑࡑࡊࡔࡘࡍࡂࡐࡆࡉ࠴࡚ࡥ࡭ࡧࡦࡳࡲࡖࡡࡳ࡫ࡶࡘࡪࡩࡨ࠰࡯ࡳ࠸࠲ࡲࡩࡷࡧ࠲ࡱࡵ࠺࠭࡭࡫ࡹࡩ࠲ࡳࡰࡥ࠯ࡄ࡚࠲ࡈࡓ࠯࡯ࡳࡨࠬ复")
		#l1111111ll1l_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡲࡥ࡯ࡨࡨ࡮ࡧ࠮ࡣࡤࡦ࠲ࡨࡵ࠮ࡶ࡭࠲ࡨࡦࡹࡨ࠰ࡱࡱࡨࡪࡳࡡ࡯ࡦ࠲ࡸࡪࡹࡴࡤࡣࡵࡨ࠴࠷࠯ࡤ࡮࡬ࡩࡳࡺ࡟࡮ࡣࡱ࡭࡫࡫ࡳࡵ࠯ࡨࡺࡪࡴࡴࡴ࠯ࡰࡹࡱࡺࡩ࡭ࡣࡱ࡫࠳ࡳࡰࡥࠩ夎")
		#l1111111ll1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ夏")
	else: httpd = l11ll1_l1_ (u"ࠨࠩ夐")
	if not l1111111ll1l_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ夑"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ夒"),[l11ll1_l1_ (u"ࠫࠬ夓")],[[l1111111ll1l_l1_,l111l1l111l1_l1_,httpd]]
def l1111ll1l1ll_l1_(url):
	# https://l11l11llll1l_l1_.com/l1111lllllll_l1_
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ夔") : l11ll1_l1_ (u"࠭ࠧ夕") }
	#url = url.replace(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭外"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ夗"))
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠩࠪ夘"),headers,l11ll1_l1_ (u"ࠪࠫ夙"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡆࡔࡈ࠭࠲ࡵࡷࠫ多"))
	items = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࢁ࠯࡜ࡾࠩ夛"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11111l1l11l_l1_,l1lll111_l1_,l11l111llll1_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1lllll_l1_,dummy,l1ll1ll111l1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭夜"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭夝"))
			if l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ夞") in l1lllll_l1_:
				l11111l1l11l_l1_,l11l111llll1_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ够"),l11ll1_l1_ (u"ࠪࠫ夠"),str(l1llll_l1_),str(l11l111llll1_l1_))
				l1llll_l1_ = l1llll_l1_ + l11l111llll1_l1_
				if l11111l1l11l_l1_[0]==l11ll1_l1_ (u"ࠫ࠲࠷ࠧ夡"): l1lll111_l1_.append(l11ll1_l1_ (u"ู๊ࠬาใิࠤำอีࠨ夢")+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧ夣"))
				else:
					for title in l11111l1l11l_l1_:
						l1lll111_l1_.append(l11ll1_l1_ (u"ࠧิ์ิๅึࠦฮศืࠪ夤")+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ夥")+title)
			else:
				title = l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ夦")+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭大")+l1ll1ll111l1_l1_
				l1llll_l1_.append(l1lllll_l1_)
				l1lll111_l1_.append(title)
		return l11ll1_l1_ (u"ࠫࠬ夨"),l1lll111_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡆࡔࡈࠧ天"),[],[]
def	l1llllllllll1_l1_(url):
	# https://l11l1l111lll_l1_.cc/l1l111l11_l1_-1qrpoobdg7bu.html
	# https://l111ll11l111_l1_.cc//l1l111l11_l1_-l111lll1ll11_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ太"),url,l11ll1_l1_ (u"ࠧࠨ夫"),l11ll1_l1_ (u"ࠨࠩ夬"),l11ll1_l1_ (u"ࠩࠪ夭"),l11ll1_l1_ (u"ࠪࠫ央"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡘࡌࡈࡊࡕࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ夯"))
	html = response.content
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ夰"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		return l11ll1_l1_ (u"࠭ࠧ失"),[l11ll1_l1_ (u"ࠧࠨ夲")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠨࠩ夳"),[],[]
def	l11111111ll1_l1_(url):
	# https://l11111111l1l_l1_.in/l11111ll1l11_l1_
	# https://l11111111l1l_l1_.in/l1l111l11_l1_-l11111ll1l11_l1_.html
	# https://l111lll11l11_l1_.l1111l11llll_l1_/l11l11ll1l11_l1_
	# https://l111lll11l11_l1_.l1111l11llll_l1_/l1l111l11_l1_-l11l11ll1l11_l1_.html
	# https://www.l11l11lll1l1_l1_.com/l1l111l11_l1_-l111l11ll111_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ头"),l11ll1_l1_ (u"ࠪࠫ夵")).replace(l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ夶"),l11ll1_l1_ (u"ࠬ࠭夷"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ夸"),url,l11ll1_l1_ (u"ࠧࠨ夹"),l11ll1_l1_ (u"ࠨࠩ夺"),l11ll1_l1_ (u"ࠩࠪ夻"),l11ll1_l1_ (u"ࠪࠫ夼"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ夽"))
	html = response.content
	l1ll1ll1l11l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩ࡝ࠫࠬࠫ夾"),html,re.DOTALL)
	if l1ll1ll1l11l_l1_:
		l1ll1ll1l11l_l1_ = l1ll1ll1l11l_l1_[0]
		l1l1lll1llll_l1_ = l1ll111ll11l_l1_(l1ll1ll1l11l_l1_)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ夿"),l1l1lll1llll_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠩࡾࠩ奀"),l1l1lll1llll_l1_,re.DOTALL)
		l1lll111_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_,title in l1l1_l1_:
			if not title: title = l1lllll_l1_.rsplit(l11ll1_l1_ (u"ࠨ࠰ࠪ奁"),1)[1]
			l1lll111_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		return l11ll1_l1_ (u"ࠩࠪ奂"),l1lll111_l1_,l1llll_l1_
	id = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ奃"))[3]
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ奄"):l11ll1_l1_ (u"ࠬ࠭奅") , l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ奆"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭奇") }
	payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ奈"):id , l11ll1_l1_ (u"ࠩࡲࡴࠬ奉"):l11ll1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭奊") }
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ奋"),url,payload,headers,l11ll1_l1_ (u"ࠬ࠭奌"),l11ll1_l1_ (u"࠭ࠧ奍"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭奎"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奏"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠩࠪ奐"),[l11ll1_l1_ (u"ࠪࠫ契")],[ items[0] ]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋࠬ奒"),[],[]
l11ll1_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡍࡏࡗࡋࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡹ࡭ࡩ࡫࡯࠰ࡲ࡯ࡥࡾ࠵ࡁࡂࡘࡈࡒࡩࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࠤ࠿ࠦࠧࠨࠢࢀࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑ࡙ࡍࡉ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡦࠡࠩ࠱ࡱ࠸ࡻ࠸ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧࠪࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶ࠺ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪื๏ืแาࠢัหฺ࠭ࠫࠨࠢࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤู๊ࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭ࡱ࠶ࠪࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡺࡵࡳࡰࠣࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡘࡌࡈࠬ࠲࡛࡞࠮࡞ࡡࠏࠏࠣࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠵ࡲ࠴ࡧࡰࡸ࡬ࡨ࠳ࡩ࡯࠰ࡵࡷࡶࡪࡧ࡭࠰࠴࠵࠽࠳ࡳ࠳ࡶ࠺ࠍࠦࠧࠨ奓")
#####################################################
#    l11l11l1ll11_l1_ l111l1111l1l_l1_ l1111l1l11l1_l1_
#    16-06-2019
#####################################################
def l1111lll1lll_l1_(url):
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"࠭ࠧ奔"),l11ll1_l1_ (u"ࠧࠨ奕"),l11ll1_l1_ (u"ࠨࠩ奖"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ套"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ奘"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠫࠬ奙"),[l11ll1_l1_ (u"ࠬ࠭奚")],[ items[0] ]
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ奛"),[],[]
def l1111ll1ll11_l1_(url):
	return l11ll1_l1_ (u"ࠧࠨ奜"),[l11ll1_l1_ (u"ࠨࠩ奝")],[ url ]
def l111l1111lll_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ奞"),l11ll1_l1_ (u"ࠪࠫ奟"),url,l11ll1_l1_ (u"ࠫࠬ奠"))
	server = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ奡"))
	basename = l11ll1_l1_ (u"࠭࠯ࠨ奢").join(server[0:3])
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠧࠨ奣"),l11ll1_l1_ (u"ࠨࠩ奤"),l11ll1_l1_ (u"ࠩࠪ奥"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧ奦"))
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奧"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭奨"),l11ll1_l1_ (u"࠭ࠧ奩"),url,str(var))
	if items:
		l11ll1l11111_l1_,l11ll1l1ll11_l1_,l11ll1l1ll1l_l1_,l111lll1l11l_l1_,l111lll1l1l1_l1_,l111lll1l111_l1_ = items[0]
		var = int(l11ll1l1ll11_l1_) % int(l11ll1l1ll1l_l1_) + int(l111lll1l11l_l1_) % int(l111lll1l1l1_l1_)
		url = basename + l11ll1l11111_l1_ + str(var) + l111lll1l111_l1_
		return l11ll1_l1_ (u"ࠧࠨ奪"),[l11ll1_l1_ (u"ࠨࠩ奫")],[url]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅࠨ奬"),[],[]
def l111ll1llll1_l1_(url):
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ奭"),l11ll1_l1_ (u"ࠫࠬ奮"))
	url = url.replace(l11ll1_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ奯"),l11ll1_l1_ (u"࠭ࠧ奰"))
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ奱"))[-1]
	headers = { l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ奲") : l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ女") }
	payload = { l11ll1_l1_ (u"ࠥ࡭ࡩࠨ奴"):id , l11ll1_l1_ (u"ࠦࡴࡶࠢ奵"):l11ll1_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣ奶") }
	request = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ奷"), url, payload, headers, l11ll1_l1_ (u"ࠧࠨ奸"),l11ll1_l1_ (u"ࠨࠩ她"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ奺"))
	if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ奻") in list(request.headers.keys()): l1lllll_l1_ = request.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭奼")]
	else: l1lllll_l1_ = url
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠬ࠭好"),[l11ll1_l1_ (u"࠭ࠧ奾")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬ奿"),[],[]
def l1111l11111l_l1_(url):
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠨࠩ妀"),l11ll1_l1_ (u"ࠩࠪ妁"),l11ll1_l1_ (u"ࠪࠫ如"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ妃"))
	items = re.findall(l11ll1_l1_ (u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ妄"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"࠭ࠧ妅"),[l11ll1_l1_ (u"ࠧࠨ妆")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭妇"),[],[]
def l1llllll1l11l_l1_(url):
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠩࠪ妈"),l11ll1_l1_ (u"ࠪࠫ妉"),l11ll1_l1_ (u"ࠫࠬ妊"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭妋"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ妌"),html,re.DOTALL)
	#l111ll111lll_l1_.l1lllllll11ll_l1_(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭妍") + items[0])
	if items:
		url = url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ妎") + items[0]
		return l11ll1_l1_ (u"ࠩࠪ妏"),[l11ll1_l1_ (u"ࠪࠫ妐")],[ url ]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧ妑"),[],[]
def l111l11ll1l1_l1_(url):
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠬ࠭妒"),l11ll1_l1_ (u"࠭ࠧ妓"),l11ll1_l1_ (u"ࠧࠨ妔"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕ࡛ࡂࡍࡋࡆ࡚ࡎࡊࡅࡐࡊࡒࡗ࡙࠳࠱ࡴࡶࠪ妕"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ妖"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ妗"),l11ll1_l1_ (u"ࠫࠬ妘"),str(items),html)
	if items: return l11ll1_l1_ (u"ࠬ࠭妙"),[l11ll1_l1_ (u"࠭ࠧ妚")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓ࡙ࡇࡒࡉࡄࡘࡌࡈࡊࡕࡈࡐࡕࡗࠫ妛"),[],[]
def l1111lll11ll_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ妜"),l11ll1_l1_ (u"ࠩࠪ妝"))
	html = OPENURL_CACHED(l1ll1ll1l_l1_,url,l11ll1_l1_ (u"ࠪࠫ妞"),l11ll1_l1_ (u"ࠫࠬ妟"),l11ll1_l1_ (u"ࠬ࠭妠"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ妡"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妢"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ妣"),l11ll1_l1_ (u"ࠩࠪ妤"),items[0],items[0])
	if items: return l11ll1_l1_ (u"ࠪࠫ妥"),[l11ll1_l1_ (u"ࠫࠬ妦")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ妧"),[],[]
l11ll1_l1_ (u"ࠨࠢࠣࠌࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠊࠤࠢࠣࠤࠥࡔࡏࡕ࡚ࠢࡓࡗࡑࡉࡏࡉࠣࡅࡓ࡟ࡍࡐࡔࡈࠎࠨࠦࠠࠡࠢ࠳࠶࠲ࡌࡅࡃ࠯࠵࠴࠷࠷ࠊࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠏࠐࠊࠋࠌࠥࠦࠧ妨")
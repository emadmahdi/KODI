# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡓ࠳ࡖࠩ䀖")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䀗")
l11lllllllll_l1_ = [
		 l11ll1_l1_ (u"ࠧࡊࡉࡑࡓࡗࡋࡄࠨ䀘")
		,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䀙"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䀚")
		,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䀛"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䀜")
		#,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡅࡗࡉࡈࡊࡘࡈࡈࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䀝"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡊࡖࡇࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䀞"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䀟")
		,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䀠"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䀡")
		,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䀢"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭䀣"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭䀤")
		,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䀥"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䀦")
		,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䀧"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䀨")
		,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䀩"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࠬ䀪"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࠬ䀫")
		]
l11llllll1l1_l1_ = 4
def MAIN(mode,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_):
	global l111l1_l1_
	try:
		l1lll11l1l1l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀬")])
		l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡏࡘࠫ䀭")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠨࡡࠪ䀮")
	except: l1lll11l1l1l_l1_ = l11ll1_l1_ (u"ࠩࠪ䀯")
	try: l111l1l1_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࠬ䀰")])
	except: l111l1l1_l1_ = l11ll1_l1_ (u"ࠫࠬ䀱")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1lll11l1l1l_l1_,l111l1l1_l1_)
	elif mode==712: results = l1l111l11l11_l1_(l1lll11l1l1l_l1_)
	elif mode==713: results = GROUPS(l1lll11l1l1l_l1_,url,text,l1l1111_l1_)
	elif mode==714: results = ITEMS(l1lll11l1l1l_l1_,url,text,l1l1111_l1_)
	elif mode==715: results = PLAY(l1lll11l1l1l_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1lll11l1l1l_l1_,True)
	elif mode==717: results = l1l111lll1ll_l1_(l1lll11l1l1l_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1lll11l1l1l_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1lll11l1l1l_l1_,url,l1l1111_l1_)
	elif mode==720: results = MENU(l1lll11l1l1l_l1_)
	elif mode==721: results = l1l1111l11ll_l1_(l1lll11l1l1l_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1lll11l1l1l_l1_)
	elif mode==723: results = ADD_USERAGENT(l1lll11l1l1l_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==726: results = ADD_REFERER(l1lll11l1l1l_l1_)
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1lll11l1l1l_l1_,url,l1l1111_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1lll11l1l1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1l111111111_l1_ = l11ll1_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ䀲")+str(l1lll11l1l1l_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡎࡗࠪ䀳")+str(l1lll11l1l1l_l1_)+l11ll1_l1_ (u"ࠧࡠࠩ䀴")
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䀵"),l111l1_l1_+l11ll1_l1_ (u"่ࠩะ้ีࠠࠨ䀶")+text_numbers[l1lll11l1l1l_l1_]+l1l111111111_l1_,l11ll1_l1_ (u"ࠪࠫ䀷"),720,l11ll1_l1_ (u"ࠫࠬ䀸"),l11ll1_l1_ (u"ࠬ࠭䀹"),l11ll1_l1_ (u"࠭ࠧ䀺"),l11ll1_l1_ (u"ࠧࠨ䀻"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䀼"):l1lll11l1l1l_l1_})
	return
def SECTIONS_MENU():
	global l111l1_l1_
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀽"),l111l1_l1_+l11ll1_l1_ (u"ࠪะ๊๐ูࠡลๅืฬ๋ࠧ䀾"),l11ll1_l1_ (u"ࠫࠬ䀿"),165,l11ll1_l1_ (u"ࠬ࠭䁀"),l11ll1_l1_ (u"࠭ࠧ䁁"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䁂"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䁃"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䁄"),l11ll1_l1_ (u"ࠪࠫ䁅"),9999)
	for l1lll11l1l1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1l111111111_l1_ = l11ll1_l1_ (u"ࠫࠥࡓ࠳ࡖࠩ䁆")+str(l1lll11l1l1l_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍࡖࠩ䁇")+str(l1lll11l1l1l_l1_)+l11ll1_l1_ (u"࠭࡟ࠨ䁈")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁉"),l111l1_l1_+l11ll1_l1_ (u"ࠨลๅืฬ๋ࠠๆฮ็ำࠥ࠭䁊")+text_numbers[l1lll11l1l1l_l1_]+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࠪ䁋"),165,l11ll1_l1_ (u"ࠪࠫ䁌"),l11ll1_l1_ (u"ࠫࠬ䁍"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䁎"),l11ll1_l1_ (u"࠭ࠧ䁏"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁐"):l1lll11l1l1l_l1_})
	return
def MENU(l1lll11l1l1l_l1_=l11ll1_l1_ (u"ࠨࠩ䁑")):
	if l1lll11l1l1l_l1_:
		l11llll11l11_l1_ = {l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䁒"):l1lll11l1l1l_l1_}
		l1l111111111_l1_ = l11ll1_l1_ (u"ࠪࠫ䁓")  # l11ll1_l1_ (u"ࠫࠥࡓ࠳ࡖࠩ䁔")+str(l1lll11l1l1l_l1_)
	else:
		l11llll11l11_l1_ = l11ll1_l1_ (u"ࠬ࠭䁕")
		l1l111111111_l1_ = l11ll1_l1_ (u"࠭ࠧ䁖")
	if CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True):
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁗"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้้็วหࠩ䁘")+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࠪ䁙"),729,l11ll1_l1_ (u"ࠪࠫ䁚"),l11ll1_l1_ (u"ࠫࠬ䁛"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䁜"),l11ll1_l1_ (u"࠭ࠧ䁝"),l11llll11l11_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁞"),l111l1_l1_+l11ll1_l1_ (u"ࠨไสส๊ฯࠠฤไึห๊࠭䁟")+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࠪ䁠"),165,l11ll1_l1_ (u"ࠪࠫ䁡"),l11ll1_l1_ (u"ࠫࠬ䁢"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䁣"),l11ll1_l1_ (u"࠭ࠧ䁤"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䁥"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䁦"),l11ll1_l1_ (u"ࠩࠪ䁧"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁨"),l111l1_l1_+l11ll1_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แส่๊ࠢࠥษำๆษษ๋ฬ࠭䁩")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭䁪"),713,l11ll1_l1_ (u"࠭ࠧ䁫"),l11ll1_l1_ (u"ࠧࠨ䁬"),l11ll1_l1_ (u"ࠨࠩ䁭"),l11ll1_l1_ (u"ࠩࠪ䁮"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁯"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอ๋ࠥๆࠡลึ้ฬฬ็ศࠩ䁰")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࠬ䁱"),713,l11ll1_l1_ (u"࠭ࠧ䁲"),l11ll1_l1_ (u"ࠧࠨ䁳"),l11ll1_l1_ (u"ࠨࠩ䁴"),l11ll1_l1_ (u"ࠩࠪ䁵"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䁶"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䁷"),l11ll1_l1_ (u"ࠬ࠭䁸"),9999)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁹"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอ๋ࠥๆࠡลๅืฬ๋็ศࠩ䁺")+l1l111111111_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ䁻"),713,l11ll1_l1_ (u"ࠩࠪ䁼"),l11ll1_l1_ (u"ࠪࠫ䁽"),l11ll1_l1_ (u"ࠫࠬ䁾"),l11ll1_l1_ (u"ࠬ࠭䁿"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䂀"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠡ็้ࠤศ่ำศ็๊หࠬ䂁")+l1l111111111_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࠩ䂂"),713,l11ll1_l1_ (u"ࠩࠪ䂃"),l11ll1_l1_ (u"ࠪࠫ䂄"),l11ll1_l1_ (u"ࠫࠬ䂅"),l11ll1_l1_ (u"ࠬ࠭䂆"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䂇"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䂈"),l11ll1_l1_ (u"ࠨࠩ䂉"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䂊"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้่ๆ้ษอࠤฬ๊รึๆํอࠬ䂋")+l1l111111111_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䂌"),713,l11ll1_l1_ (u"ࠬ࠭䂍"),l11ll1_l1_ (u"࠭ࠧ䂎"),l11ll1_l1_ (u"ࠧࠨ䂏"),l11ll1_l1_ (u"ࠨࠩ䂐"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䂑"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้็๊ะ์๋๋ฬะࠠศๆฦู้๐ษࠨ䂒")+l1l111111111_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䂓"),713,l11ll1_l1_ (u"ࠬ࠭䂔"),l11ll1_l1_ (u"࠭ࠧ䂕"),l11ll1_l1_ (u"ࠧࠨ䂖"),l11ll1_l1_ (u"ࠨࠩ䂗"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䂘"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䂙"),l11ll1_l1_ (u"ࠫࠬ䂚"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂛"),l111l1_l1_+l11ll1_l1_ (u"࠭โ็๊สฮ๋ࠥี็ใฬࠫ䂜")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭䂝"),713,l11ll1_l1_ (u"ࠨࠩ䂞"),l11ll1_l1_ (u"ࠩࠪ䂟"),l11ll1_l1_ (u"ࠪࠫ䂠"),l11ll1_l1_ (u"ࠫࠬ䂡"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂢"),l111l1_l1_+l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ็ุ๊ๆฯࠧ䂣")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ䂤"),713,l11ll1_l1_ (u"ࠨࠩ䂥"),l11ll1_l1_ (u"ࠩࠪ䂦"),l11ll1_l1_ (u"ࠪࠫ䂧"),l11ll1_l1_ (u"ࠫࠬ䂨"),l11llll11l11_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂩"),l111l1_l1_+l11ll1_l1_ (u"࠭รโๆส้๋ࠥี็ใฬࠫ䂪")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ䂫"),713,l11ll1_l1_ (u"ࠨࠩ䂬"),l11ll1_l1_ (u"ࠩࠪ䂭"),l11ll1_l1_ (u"ࠪࠫ䂮"),l11ll1_l1_ (u"ࠫࠬ䂯"),l11llll11l11_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂰"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠๆื้ๅฮ࠭䂱")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ䂲"),713,l11ll1_l1_ (u"ࠨࠩ䂳"),l11ll1_l1_ (u"ࠩࠪ䂴"),l11ll1_l1_ (u"ࠪࠫ䂵"),l11ll1_l1_ (u"ࠫࠬ䂶"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂷"),l111l1_l1_+l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠨ䂸")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䂹"),713,l11ll1_l1_ (u"ࠨࠩ䂺"),l11ll1_l1_ (u"ࠩࠪ䂻"),l11ll1_l1_ (u"ࠪࠫ䂼"),l11ll1_l1_ (u"ࠫࠬ䂽"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂾"),l111l1_l1_+l11ll1_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ䂿")+l1l111111111_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䃀"),713,l11ll1_l1_ (u"ࠨࠩ䃁"),l11ll1_l1_ (u"ࠩࠪ䃂"),l11ll1_l1_ (u"ࠪࠫ䃃"),l11ll1_l1_ (u"ࠫࠬ䃄"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䃅"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䃆"),l11ll1_l1_ (u"ࠧࠨ䃇"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃈"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ䃉")+l1l111111111_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䃊"),713,l11ll1_l1_ (u"ࠫࠬ䃋"),l11ll1_l1_ (u"ࠬ࠭䃌"),l11ll1_l1_ (u"࠭ࠧ䃍"),l11ll1_l1_ (u"ࠧࠨ䃎"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃏"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโหࠣ์๊ืสษหࠪ䃐")+l1l111111111_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䃑"),713,l11ll1_l1_ (u"ࠫࠬ䃒"),l11ll1_l1_ (u"ࠬ࠭䃓"),l11ll1_l1_ (u"࠭ࠧ䃔"),l11ll1_l1_ (u"ࠧࠨ䃕"),l11llll11l11_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃖"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦๅ้อๅࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ䃗")+l1l111111111_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䃘"),713,l11ll1_l1_ (u"ࠫࠬ䃙"),l11ll1_l1_ (u"ࠬ࠭䃚"),l11ll1_l1_ (u"࠭ࠧ䃛"),l11ll1_l1_ (u"ࠧࠨ䃜"),l11llll11l11_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃝"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไศฬฺ้ࠣ์แส๋้ࠢึะศสࠩ䃞")+l1l111111111_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䃟"),713,l11ll1_l1_ (u"ࠫࠬ䃠"),l11ll1_l1_ (u"ࠬ࠭䃡"),l11ll1_l1_ (u"࠭ࠧ䃢"),l11ll1_l1_ (u"ࠧࠨ䃣"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃤"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠤํ๋ัหสฬࠫ䃥")+l1l111111111_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䃦"),713,l11ll1_l1_ (u"ࠫࠬ䃧"),l11ll1_l1_ (u"ࠬ࠭䃨"),l11ll1_l1_ (u"࠭ࠧ䃩"),l11ll1_l1_ (u"ࠧࠨ䃪"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃫"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡ็ฯ๋ํ๊ษ๊่ࠡีฯฮษࠨ䃬")+l1l111111111_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䃭"),713,l11ll1_l1_ (u"ࠫࠬ䃮"),l11ll1_l1_ (u"ࠬ࠭䃯"),l11ll1_l1_ (u"࠭ࠧ䃰"),l11ll1_l1_ (u"ࠧࠨ䃱"),l11llll11l11_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䃲"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䃳"),l11ll1_l1_ (u"ࠪࠫ䃴"),9999)
	for seq in range(1,l11llllll1l1_l1_+1):
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䃵"),l111l1_l1_+l11ll1_l1_ (u"ࠬหึศใฬࠤํะฺ๋์ิࠤึอศุࠩ䃶")+l1l111111111_l1_+l11ll1_l1_ (u"࠭ࠠࠨ䃷")+text_numbers[seq],l11ll1_l1_ (u"ࠧࠨ䃸"),711,l11ll1_l1_ (u"ࠨࠩ䃹"),l11ll1_l1_ (u"ࠩࠪ䃺"),l11ll1_l1_ (u"ࠪࠫ䃻"),l11ll1_l1_ (u"ࠫࠬ䃼"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䃽"):l1lll11l1l1l_l1_,l11ll1_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࠨ䃾"):seq})
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃿"),l111l1_l1_+l11ll1_l1_ (u"ࠨสิห๊าࠠศๆๅ๊ํอสࠡࠪฯำํ๊ࠠโไฺ࠭ࠬ䄀")+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡆࡒࡊࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䄁"),713,l11ll1_l1_ (u"ࠪࠫ䄂"),l11ll1_l1_ (u"ࠫࠬ䄃"),l11ll1_l1_ (u"ࠬ࠭䄄"),l11ll1_l1_ (u"࠭ࠧ䄅"),l11llll11l11_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䄆"),l111l1_l1_+l11ll1_l1_ (u"ࠨลิุ๏็ࠠศๆๅ๊ํอสࠡๆ็ว๏อๅࠡษ็้ฬ฼๊สࠩ䄇")+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䄈"),713,l11ll1_l1_ (u"ࠪࠫ䄉"),l11ll1_l1_ (u"ࠫࠬ䄊"),l11ll1_l1_ (u"ࠬ࠭䄋"),l11ll1_l1_ (u"࠭ࠧ䄌"),l11llll11l11_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䄍"),l111l1_l1_+l11ll1_l1_ (u"ࠨลิุ๏็ࠠษำส้ัࠦวๅไ้์ฬะࠠๅๆฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ䄎")+l1l111111111_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡂࡔࡆࡌࡎ࡜ࡅࡅࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䄏"),713,l11ll1_l1_ (u"ࠪࠫ䄐"),l11ll1_l1_ (u"ࠫࠬ䄑"),l11ll1_l1_ (u"ࠬ࠭䄒"),l11ll1_l1_ (u"࠭ࠧ䄓"),l11llll11l11_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䄔"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䄕"),l11ll1_l1_ (u"ࠩࠪ䄖"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄗"),l111l1_l1_+l11ll1_l1_ (u"ࠫส฼วโหࠣวํࠦส฻์ํีࠥอิหำส็ࠬ䄘")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄙"),711,l11ll1_l1_ (u"࠭ࠧ䄚"),l11ll1_l1_ (u"ࠧࠨ䄛"),l11ll1_l1_ (u"ࠨࠩ䄜"),l11ll1_l1_ (u"ࠩࠪ䄝"),l11llll11l11_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄞"),l111l1_l1_+l11ll1_l1_ (u"ࠫ฾ีฯࠡใํำ๏๎็ศฬࠪ䄟")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄠"),721,l11ll1_l1_ (u"࠭ࠧ䄡"),l11ll1_l1_ (u"ࠧࠨ䄢"),l11ll1_l1_ (u"ࠨࠩ䄣"),l11ll1_l1_ (u"ࠩࠪ䄤"),l11llll11l11_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄥"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆำีࠡษืฮึอใࠨ䄦")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄧"),716,l11ll1_l1_ (u"࠭ࠧ䄨"),l11ll1_l1_ (u"ࠧࠨ䄩"),l11ll1_l1_ (u"ࠨࠩ䄪"),l11ll1_l1_ (u"ࠩࠪ䄫"),l11llll11l11_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄬"),l111l1_l1_+l11ll1_l1_ (u"ࠫั๊ศࠡ็็ๅฬะࠧ䄭")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄮"),712,l11ll1_l1_ (u"࠭ࠧ䄯"),l11ll1_l1_ (u"ࠧࠨ䄰"),l11ll1_l1_ (u"ࠨࠩ䄱"),l11ll1_l1_ (u"ࠩࠪ䄲"),l11llll11l11_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄳"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠧ䄴")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄵"),717,l11ll1_l1_ (u"࠭ࠧ䄶"),l11ll1_l1_ (u"ࠧࠨ䄷"),l11ll1_l1_ (u"ࠨࠩ䄸"),l11ll1_l1_ (u"ࠩࠪ䄹"),l11llll11l11_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄺"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬูสฯัส้ࠥอไิ์ิๅึࠦวๅลึี฾࠭䄻")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䄼"),722,l11ll1_l1_ (u"࠭ࠧ䄽"),l11ll1_l1_ (u"ࠧࠨ䄾"),l11ll1_l1_ (u"ࠨࠩ䄿"),l11ll1_l1_ (u"ࠩࠪ䅀"),l11llll11l11_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䅁"),l111l1_l1_+l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠡฬ฽๎๏ืࠧ䅂")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䅃"),723,l11ll1_l1_ (u"࠭ࠧ䅄"),l11ll1_l1_ (u"ࠧࠨ䅅"),l11ll1_l1_ (u"ࠨࠩ䅆"),l11ll1_l1_ (u"ࠩࠪ䅇"),l11llll11l11_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䅈"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠥะฺ๋์ิࠫ䅉")+l1l111111111_l1_,l11ll1_l1_ (u"ࠬ࠭䅊"),726,l11ll1_l1_ (u"࠭ࠧ䅋"),l11ll1_l1_ (u"ࠧࠨ䅌"),l11ll1_l1_ (u"ࠨࠩ䅍"),l11ll1_l1_ (u"ࠩࠪ䅎"),l11llll11l11_l1_)
	return
def CHECK_ACCOUNT(l1lll11l1l1l_l1_,l1ll_l1_=True):
	ok,status = False,l11ll1_l1_ (u"ࠪࠫ䅏")
	l11llll111l1_l1_,l1l111llll1l_l1_ = l11ll1_l1_ (u"ࠫࠬ䅐"),l11ll1_l1_ (u"ࠬ࠭䅑")
	l1l11l111l1l_l1_,l11lllllll11_l1_,server,username,password = GET_URL(l1lll11l1l1l_l1_)
	if username==l11ll1_l1_ (u"࠭ࠧ䅒"): return
	headers = GET_HEADERS(l1lll11l1l1l_l1_)
	if l1l11l111l1l_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䅓"),l1l11l111l1l_l1_,l11ll1_l1_ (u"ࠨࠩ䅔"),headers,False,l11ll1_l1_ (u"ࠩࠪ䅕"),l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡄࡊࡈࡇࡐࡥࡁࡄࡅࡒ࡙ࡓ࡚࠭࠲ࡵࡷࠫ䅖"))
		html = response.content
		if response.succeeded:
			timestamp,l11lll1lll1l_l1_,l11lll1ll111_l1_,l11lll111lll_l1_,l11llllllll1_l1_ = 0,0,l11ll1_l1_ (u"ࠫࠬ䅗"),l11ll1_l1_ (u"ࠬ࠭䅘"),l11ll1_l1_ (u"࠭ࠧ䅙")
			try:
				dict = EVAL(l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ䅚"),html)
				status = dict[l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ䅛")][l11ll1_l1_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ䅜")]
				ok = True
				l11lll1ll111_l1_ = dict[l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡢ࡭ࡳ࡬࡯ࠨ䅝")][l11ll1_l1_ (u"ࠫࡹ࡯࡭ࡦࡡࡱࡳࡼ࠭䅞")]
			except: pass
			if l11lll1ll111_l1_:
				try:
					struct = time.strptime(l11lll1ll111_l1_,l11ll1_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ䅟"))
					timestamp = int(time.mktime(struct))
					l11lll1lll1l_l1_ = int(now-timestamp)
					l11lll1lll1l_l1_ = int((l11lll1lll1l_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ䅠")][l11ll1_l1_ (u"ࠧࡤࡴࡨࡥࡹ࡫ࡤࡠࡣࡷࠫ䅡")]))
					l11lll111lll_l1_ = time.strftime(l11ll1_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ䅢"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ䅣")][l11ll1_l1_ (u"ࠪࡩࡽࡶ࡟ࡥࡣࡷࡩࠬ䅤")]))
					l11llllllll1_l1_ = time.strftime(l11ll1_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨ䅥"),struct)
				except: pass
			settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ䅦")+l1lll11l1l1l_l1_,str(now))
			settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ䅧")+l1lll11l1l1l_l1_,str(l11lll1lll1l_l1_))
			try:
				l1l111111l1l_l1_ = l11ll1_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡱࡪࡴࠨ࠺ࠨ䅨")+html.split(l11ll1_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡡ࡬ࡲ࡫ࡵࠢ࠻ࠩ䅩"))[1]
				l1l111111l1l_l1_ = l1l111111l1l_l1_.replace(l11ll1_l1_ (u"ࠩ࠽ࠫ䅪"),l11ll1_l1_ (u"ࠪ࠾ࠥ࠭䅫")).replace(l11ll1_l1_ (u"ࠫ࠱࠭䅬"),l11ll1_l1_ (u"ࠬ࠲ࠠࠨ䅭")).replace(l11ll1_l1_ (u"࠭ࡽࡾࠩ䅮"),l11ll1_l1_ (u"ࠧࡾࠩ䅯"))
				new = re.findall(l11ll1_l1_ (u"ࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࠦࡵࡵࡲࡵࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䅰"),l1l111111l1l_l1_,re.DOTALL)
				l11llll111l1_l1_,l1l111llll1l_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11ll1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ䅱")][l11ll1_l1_ (u"ࠪࡱࡦࡾ࡟ࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࡷࠬ䅲")]
				l1l11111ll11_l1_ = dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䅳")][l11ll1_l1_ (u"ࠬࡧࡣࡵ࡫ࡹࡩࡤࡩ࡯࡯ࡵࠪ䅴")]
				l1l1111ll1ll_l1_ = dict[l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ䅵")][l11ll1_l1_ (u"ࠧࡪࡵࡢࡸࡷ࡯ࡡ࡭ࠩ䅶")]
				parts = l1l11l111l1l_l1_.split(l11ll1_l1_ (u"ࠨࡁࠪ䅷"),1)
				message = l11ll1_l1_ (u"ࠩࡘࡖࡑࡀࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䅸")+l1l11l111l1l_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䅹")
				message += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࡕࡷࡥࡹࡻࡳ࠻ࠢࠣࠫ䅺")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䅻")+status+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䅼")
				message += l11ll1_l1_ (u"ࠧ࡝ࡰࡗࡶ࡮ࡧ࡬࠻ࠢࠣࠤࠥ࠭䅽")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䅾")+str(l1l1111ll1ll_l1_==l11ll1_l1_ (u"ࠩ࠴ࠫ䅿"))+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䆀")
				message += l11ll1_l1_ (u"ࠫࡡࡴࡃࡳࡧࡤࡸࡪࡪࠠࠡࡃࡷ࠾ࠥࠦࠧ䆁")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䆂")+l11lll111lll_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䆃")
				message += l11ll1_l1_ (u"ࠧ࡝ࡰࡈࡼࡵ࡯ࡲࡺࠢࡇࡥࡹ࡫࠺ࠡࠢࠪ䆄")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䆅")+l11llllllll1_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䆆")
				message += l11ll1_l1_ (u"ࠪࡠࡳࡉ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࡵࠣࠤࠥ࠮ࠠࡂࡥࡷ࡭ࡻ࡫ࠠ࠰ࠢࡐࡥࡽ࡯࡭ࡶ࡯ࠣ࠭ࠥࡀࠠࠡࠩ䆇")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䆈")+l1l11111ll11_l1_+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䆉")+max+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䆊")
				message += l11ll1_l1_ (u"ࠧ࡝ࡰࡄࡰࡱࡵࡷࡦࡦࠣࡓࡺࡺࡰࡶࡶࡶ࠾ࠥࠦࠠࠨ䆋")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䆌")+l11ll1_l1_ (u"ࠤࠣ࠰ࠥࠨ䆍").join(dict[l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䆎")][l11ll1_l1_ (u"ࠫࡦࡲ࡬ࡰࡹࡨࡨࡤࡵࡵࡵࡲࡸࡸࡤ࡬࡯ࡳ࡯ࡤࡸࡸ࠭䆏")])+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䆐")
				message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ䆑")+l1l111111l1l_l1_
				if status==l11ll1_l1_ (u"ࠧࡂࡥࡷ࡭ࡻ࡫ࠧ䆒"): DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠨษ็หูะัศๅࠣ๎฾๋ไࠡสา์๋ࠦๅีษๆ่ࠬ䆓"),message)
				else: DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠩํฬิ๎ࠠฤ่๋๋ࠣอใࠡ็ื็้ฯࠠโ์ࠣห้อิหำส็ࠬ䆔"),message)
	if l1l11l111l1l_l1_ and ok and status==l11ll1_l1_ (u"ࠪࡅࡨࡺࡩࡷࡧࠪ䆕"):
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䆖"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤࡒ࠹ࡕࠡࡗࡕࡐࠥࠦࠠ࡜ࠢࡐ࠷࡚ࠦࡡࡤࡥࡲࡹࡳࡺࠠࡪࡵࠣࡓࡐࠦ࡝ࠡࠢࠣ࡟ࠥ࠭䆗")+l1l11l111l1l_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ䆘"))
		succeeded = True
	else:
		LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䆙"),l11ll1_l1_ (u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡑ࠸࡛ࠠࡖࡔࡏࠤ࡛ࠥࠦࠡࡆࡲࡩࡸࠦ࡮ࡰࡶࠣࡻࡴࡸ࡫ࠡ࡟ࠣࠤࠥࡡࠠࠨ䆚")+l1l11l111l1l_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ䆛"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䆜"),l11ll1_l1_ (u"ࠫࠬ䆝"),l11ll1_l1_ (u"ࠬ็อึࠢสุฯืวไࠢใࡑ࠸࡛ࠧ䆞"),l11ll1_l1_ (u"࠭ัศสฺࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠢส่ี๐ࠠใ็อࠤฬ์สࠡสศฺฬ็ส่ࠢศ่๎ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏฿ๅๅࠢฦ์ࠥอไาษห฻ࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤฬ๊ศา่ส้ัࠦ࠮ࠡลำ๋อࠦลๅ๋ࠣๆฬฬๅสࠢสุฯืวไࠢใࡑ࠸้࡛ࠠไ่ࠤอหึศใฬࠤึอศุࠢใࡑ࠸࡛ࠠอัํำࠥษ่ࠡไ่ࠤอหีๅษะࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠫ䆟"))
		succeeded = False
	return succeeded,l11llll111l1_l1_,l1l111llll1l_l1_
def ITEMS(l1lll11l1l1l_l1_,l1l111111lll_l1_,l1l111l11l1l_l1_,l11llll11lll_l1_,l1ll_l1_=True):
	if not l11llll11lll_l1_: l11llll11lll_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ䆠")
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,l1ll_l1_): return
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l1l111111lll_l1_)
	l1ll1l11l11l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䆡"),l1l111111lll_l1_,l1l111l11l1l_l1_)
	end = int(l11llll11lll_l1_)*100
	start = end-100
	for context,title,url,l1lll1_l1_ in l1ll1l11l11l_l1_[start:end]:
		l1ll1lll1ll1_l1_ = (l11ll1_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡆࡆࠪ䆢") in l1l111111lll_l1_ or l1l111111lll_l1_==l11ll1_l1_ (u"ࠪࡅࡑࡒࠧ䆣"))
		l1ll1lll1l11_l1_ = (l11ll1_l1_ (u"ࠫࡌࡘࡏࡖࡒࡈࡈࠬ䆤") not in l1l111111lll_l1_ and l1l111111lll_l1_!=l11ll1_l1_ (u"ࠬࡇࡌࡍࠩ䆥"))
		if l1ll1lll1ll1_l1_ or l1ll1lll1l11_l1_:
			if   l11ll1_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ䆦")  in l1l111111lll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䆧"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ䆨"),l11ll1_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ䆩"),l11ll1_l1_ (u"ࠪࠫ䆪"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆫"):l1lll11l1l1l_l1_}])
			elif l11ll1_l1_ (u"ࠬࡋࡐࡈࠩ䆬") 		 in l1l111111lll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䆭"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䆮"),l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ䆯"),l11ll1_l1_ (u"ࠩࠪ䆰"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䆱"):l1lll11l1l1l_l1_}])
			elif l11ll1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䆲") in l1l111111lll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䆳"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䆴"),l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䆵"),l11ll1_l1_ (u"ࠨࠩ䆶"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䆷"):l1lll11l1l1l_l1_}])
			elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䆸") 	 in l1l111111lll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䆹"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭䆺"),l11ll1_l1_ (u"࠭ࠧ䆻"),context,{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䆼"):l1lll11l1l1l_l1_}])
			else: menuItemsLIST.append([l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䆽"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䆾"),l11ll1_l1_ (u"ࠪࠫ䆿"),l11ll1_l1_ (u"ࠫࠬ䇀"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇁"):l1lll11l1l1l_l1_}])
	total = len(l1ll1l11l11l_l1_)
	PAGINATION(l1lll11l1l1l_l1_,l11llll11lll_l1_,l1l111111lll_l1_,714,total,l1l111l11l1l_l1_)
	return
def SHOW_EMPTY(l11lll1l1ll1_l1_):
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䇂"),l11lll1l1ll1_l1_+l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊โศศ่อࠥหๅศࠢไหึเษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠨ䇃"),l11ll1_l1_ (u"ࠨࠩ䇄"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䇅"),l11lll1l1ll1_l1_+l11ll1_l1_ (u"ࠪวํࠦวๅะา้ฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦวีฬิห่้ࠧ䇆"),l11ll1_l1_ (u"ࠫࠬ䇇"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䇈"),l11lll1l1ll1_l1_+l11ll1_l1_ (u"࠭ร้ࠢิหอ฽ࠠࡎ࠵ࡘไࠥอไั์ࠣว๋ะࠠฤุไฮ์ฺ๋ࠦำูࠣา๐อࠨ䇉"),l11ll1_l1_ (u"ࠧࠨ䇊"),9999)
	return
def GROUPS(l1lll11l1l1l_l1_,l1l111111lll_l1_,l1l111l11l1l_l1_,l11llll11lll_l1_,l1l1l11l_l1_=l11ll1_l1_ (u"ࠨࠩ䇋"),l1ll_l1_=True):
	if not l11llll11lll_l1_: l11llll11lll_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ䇌")
	l11lll1l1ll1_l1_ = l111l1_l1_
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,l1ll_l1_): return False
	if l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䇍") in l1l111l11l1l_l1_: l11llll1l1ll_l1_,l11lll1l11l1_l1_ = l1l111l11l1l_l1_.split(l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䇎"))
	else: l11llll1l1ll_l1_,l11lll1l11l1_l1_ = l1l111l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭䇏")
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l1l111111lll_l1_)
	l1l11111llll_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ䇐"),l1l111111lll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ䇑"))
	if not l1l11111llll_l1_: return False
	l1l111ll111l_l1_ = []
	for group,l1lll1_l1_ in l1l11111llll_l1_:
		if l1l1l11l_l1_:
			if l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䇒") in group: l11lll1l1ll1_l1_ = l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ䇓")
			elif l11ll1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡡࠤࠥࠬ䇔") in group: l11lll1l1ll1_l1_ = l11ll1_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ䇕")
			elif l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ䇖") in l1l111111lll_l1_: l11lll1l1ll1_l1_ = l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䇗")
			else: l11lll1l1ll1_l1_ = l11ll1_l1_ (u"ࠧࡗࡋࡇࡉࡔ࡙ࠧ䇘")
			l11lll1l1ll1_l1_ = l11ll1_l1_ (u"ࠨ࠮࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䇙")+l11lll1l1ll1_l1_+l11ll1_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䇚")
		if l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䇛") in group: l1l111l1111l_l1_,l11lll1111l1_l1_ = group.split(l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䇜"))
		else: l1l111l1111l_l1_,l11lll1111l1_l1_ = group,l11ll1_l1_ (u"ࠬ࠭䇝")
		if not l1l111l11l1l_l1_:
			if l1l111l1111l_l1_ in l1l111ll111l_l1_: continue
			l1l111ll111l_l1_.append(l1l111l1111l_l1_)
			if l11ll1_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࠭䇞") in l1l1l11l_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇟"),l11lll1l1ll1_l1_+l1l111l1111l_l1_,l1l111111lll_l1_,168,l11ll1_l1_ (u"ࠨࠩ䇠"),l11ll1_l1_ (u"ࠩ࠴ࠫ䇡"),group,l11ll1_l1_ (u"ࠪࠫ䇢"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇣"):l1lll11l1l1l_l1_})
			elif l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䇤") in group: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䇥"),l11lll1l1ll1_l1_+l1l111l1111l_l1_,l1l111111lll_l1_,713,l11ll1_l1_ (u"ࠧࠨ䇦"),l11ll1_l1_ (u"ࠨ࠳ࠪ䇧"),group,l11ll1_l1_ (u"ࠩࠪ䇨"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇩"):l1lll11l1l1l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇪"),l11lll1l1ll1_l1_+l1l111l1111l_l1_,l1l111111lll_l1_,714,l11ll1_l1_ (u"ࠬ࠭䇫"),l11ll1_l1_ (u"࠭࠱ࠨ䇬"),group,l11ll1_l1_ (u"ࠧࠨ䇭"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇮"):l1lll11l1l1l_l1_})
		elif l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䇯") in group and l1l111l1111l_l1_==l11llll1l1ll_l1_:
			if l11lll1111l1_l1_ in l1l111ll111l_l1_: continue
			l1l111ll111l_l1_.append(l11lll1111l1_l1_)
			if l11ll1_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࠪ䇰") in l1l1l11l_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇱"),l11lll1l1ll1_l1_+l11lll1111l1_l1_,l1l111111lll_l1_,168,l11ll1_l1_ (u"ࠬ࠭䇲"),l11ll1_l1_ (u"࠭࠱ࠨ䇳"),group,l11ll1_l1_ (u"ࠧࠨ䇴"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇵"):l1lll11l1l1l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇶"),l11lll1l1ll1_l1_+l11lll1111l1_l1_,l1l111111lll_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠪ࠵ࠬ䇷"),group,l11ll1_l1_ (u"ࠫࠬ䇸"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇹"):l1lll11l1l1l_l1_})
	#if l11ll1_l1_ (u"࠭ࡓࡐࡔࡗࡉࡉ࠭䇺") in l1l111111lll_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1l11l_l1_:
		end = int(l11llll11lll_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1lll11l1l1l_l1_,l11llll11lll_l1_,l1l111111lll_l1_,713,total,l1l111l11l1l_l1_)
	return True
def EPG_ITEMS(l1lll11l1l1l_l1_,url,function):
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True): return
	headers = GET_HEADERS(l1lll11l1l1l_l1_)
	timestamp = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡢࠫ䇻")+l1lll11l1l1l_l1_)
	if not timestamp or now-int(timestamp)>24*l11lll1l1l11_l1_:
		succeeded,l11llll111l1_l1_,l1l111llll1l_l1_ = CHECK_ACCOUNT(l1lll11l1l1l_l1_,False)
		if not succeeded: return
	l11lll1lll1l_l1_ = int(settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࡢࠫ䇼")+l1lll11l1l1l_l1_))
	server = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ䇽")+l1lll11l1l1l_l1_)
	username = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡤ࠭䇾")+l1lll11l1l1l_l1_)
	password = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡵࡧࡳࡴࡹࡲࡶࡩࡥࠧ䇿")+l1lll11l1l1l_l1_)
	l11llll11111_l1_ = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ䈀"))
	l11lll111l1l_l1_ = l11llll11111_l1_[-1].replace(l11ll1_l1_ (u"࠭࠮ࡵࡵࠪ䈁"),l11ll1_l1_ (u"ࠧࠨ䈂")).replace(l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䈃"),l11ll1_l1_ (u"ࠩࠪ䈄"))
	if function==l11ll1_l1_ (u"ࠪࡗࡍࡕࡒࡕࡡࡈࡔࡌ࠭䈅"): l1l111ll1lll_l1_ = l11ll1_l1_ (u"ࠫ࡬࡫ࡴࡠࡵ࡫ࡳࡷࡺ࡟ࡦࡲࡪࠫ䈆")
	else: l1l111ll1lll_l1_ = l11ll1_l1_ (u"ࠬ࡭ࡥࡵࡡࡶ࡭ࡲࡶ࡬ࡦࡡࡧࡥࡹࡧ࡟ࡵࡣࡥࡰࡪ࠭䈇")
	l1l11l111l1l_l1_,l11lllllll11_l1_,server,username,password = GET_URL(l1lll11l1l1l_l1_)
	if not username: return
	l11llll1lll1_l1_ = l1l11l111l1l_l1_+l11ll1_l1_ (u"࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࠨ䈈")+l1l111ll1lll_l1_+l11ll1_l1_ (u"ࠧࠧࡵࡷࡶࡪࡧ࡭ࡠ࡫ࡧࡁࠬ䈉")+l11lll111l1l_l1_
	html = OPENURL_CACHED(NO_CACHE,l11llll1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ䈊"),headers,l11ll1_l1_ (u"ࠩࠪ䈋"),l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡆࡒࡊࡣࡎ࡚ࡅࡎࡕ࠰࠶ࡳࡪࠧ䈌"))
	l1l111111l11_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䈍"),html)
	l11lll1l1111_l1_ = l1l111111l11_l1_[l11ll1_l1_ (u"ࠬ࡫ࡰࡨࡡ࡯࡭ࡸࡺࡩ࡯ࡩࡶࠫ䈎")]
	l11lllll1l1l_l1_ = []
	if function in [l11ll1_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ䈏"),l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䈐")]:
		for dict in l11lll1l1111_l1_:
			if dict[l11ll1_l1_ (u"ࠨࡪࡤࡷࡤࡧࡲࡤࡪ࡬ࡺࡪ࠭䈑")]==1:
				l11lllll1l1l_l1_.append(dict)
				if function in [l11ll1_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䈒")]: break
		if not l11lllll1l1l_l1_: return
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䈓"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣวๅ็็ๅฬะࠠศๆฦ์้๐ࠠษ้ำ๋ࠥอไใษษ้ฮࠦโะࠢ็หࠥะูๆๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䈔"),l11ll1_l1_ (u"ࠬ࠭䈕"),9999)
		if function in [l11ll1_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ䈖")]:
			l1l111lll1l1_l1_ = 2
			l11lll1l11ll_l1_ = l1l111lll1l1_l1_*l11lll1l1l11_l1_
			l11lllll1l1l_l1_ = []
			l1l11l1111ll_l1_ = int(int(dict[l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䈗")])/l11lll1l11ll_l1_)*l11lll1l11ll_l1_
			l1l1111lllll_l1_ = now+l11lll1l11ll_l1_
			l11lll11l111_l1_ = int((l1l1111lllll_l1_-l1l11l1111ll_l1_)/l11lll1l1l11_l1_)
			for count in range(l11lll11l111_l1_):
				if count>=6:
					if count%l1l111lll1l1_l1_!=0: continue
					l1l11ll1l_l1_ = l11lll1l11ll_l1_
				else: l1l11ll1l_l1_ = l11lll1l11ll_l1_//2
				l11lll11l1ll_l1_ = l1l11l1111ll_l1_+count*l11lll1l1l11_l1_
				dict = {}
				dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䈘")] = l11ll1_l1_ (u"ࠩࠪ䈙")
				struct = time.localtime(l11lll11l1ll_l1_-l11lll1lll1l_l1_-l11lll1l1l11_l1_)
				dict[l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ䈚")] = time.strftime(l11ll1_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨ䈛"),struct)
				dict[l11ll1_l1_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ䈜")] = str(l11lll11l1ll_l1_)
				dict[l11ll1_l1_ (u"࠭ࡳࡵࡱࡳࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ䈝")] = str(l11lll11l1ll_l1_+l1l11ll1l_l1_)
				l11lllll1l1l_l1_.append(dict)
	elif function in [l11ll1_l1_ (u"ࠧࡔࡊࡒࡖ࡙ࡥࡅࡑࡉࠪ䈞"),l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ䈟")]: l11lllll1l1l_l1_ = l11lll1l1111_l1_
	if function==l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ䈠") and len(l11lllll1l1l_l1_)>0:
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䈡"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ั้ࠣๆฬฬๅสࠢหีฬ๋ฬࠡษ็ๆ๋๎วหࠢࠫะิ๎ไࠡใๅ฻࠮ๆ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䈢"),l11ll1_l1_ (u"ࠬ࠭䈣"),9999)
	l11lllll11l1_l1_ = []
	l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡋࡦࡳࡳ࠭䈤"))
	for dict in l11lllll1l1l_l1_:
		title = base64.b64decode(dict[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䈥")])
		if kodi_version>18.99: title = title.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭䈦"))
		l11lll11l1ll_l1_ = int(dict[l11ll1_l1_ (u"ࠩࡶࡸࡦࡸࡴࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ䈧")])
		l1l111l11lll_l1_ = int(dict[l11ll1_l1_ (u"ࠪࡷࡹࡵࡰࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ䈨")])
		l1l111l111l1_l1_ = str(int((l1l111l11lll_l1_-l11lll11l1ll_l1_+59)/60))
		l1l11l111lll_l1_ = dict[l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ䈩")].replace(l11ll1_l1_ (u"ࠬࠦࠧ䈪"),l11ll1_l1_ (u"࠭࠺ࠨ䈫"))
		struct = time.localtime(l11lll11l1ll_l1_-l11lll1l1l11_l1_)
		l1l1111ll111_l1_ = time.strftime(l11ll1_l1_ (u"ࠧࠦࡊ࠽ࠩࡒ࠭䈬"),struct)
		l1l111l111ll_l1_ = time.strftime(l11ll1_l1_ (u"ࠨࠧࡤࠫ䈭"),struct)
		if function==l11ll1_l1_ (u"ࠩࡖࡌࡔࡘࡔࡠࡇࡓࡋࠬ䈮"): title = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䈯")+l1l1111ll111_l1_+l11ll1_l1_ (u"ࠫࠥๆࠠࠨ䈰")+title+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䈱")
		elif function==l11ll1_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ䈲"): title = l1l111l111ll_l1_+l11ll1_l1_ (u"ࠧࠡࠩ䈳")+l1l1111ll111_l1_+l11ll1_l1_ (u"ࠨࠢࠫࠫ䈴")+l1l111l111l1_l1_+l11ll1_l1_ (u"ࠩࡰ࡭ࡳ࠯ࠧ䈵")
		else: title = l1l111l111ll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ䈶")+l1l1111ll111_l1_+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ䈷")+l1l111l111l1_l1_+l11ll1_l1_ (u"ࠬࡳࡩ࡯ࠫࠣࠤࠥ࠭䈸")+title+l11ll1_l1_ (u"࠭ࠠแࠩ䈹")
		if function in [l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䈺"),l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ䈻"),l11ll1_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䈼")]:
			l11lll11ll1l_l1_ = server+l11ll1_l1_ (u"ࠪ࠳ࡹ࡯࡭ࡦࡵ࡫࡭࡫ࡺ࠯ࠨ䈽")+username+l11ll1_l1_ (u"ࠫ࠴࠭䈾")+password+l11ll1_l1_ (u"ࠬ࠵ࠧ䈿")+l1l111l111l1_l1_+l11ll1_l1_ (u"࠭࠯ࠨ䉀")+l1l11l111lll_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ䉁")+l11lll111l1l_l1_+l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䉂")
			if function==l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ䉃"): addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䉄"),l111l1_l1_+title,l11lll11ll1l_l1_,9999,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䉅"),l11ll1_l1_ (u"ࠬ࠭䉆"),l11ll1_l1_ (u"࠭ࠧ䉇"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䉈"):l1lll11l1l1l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䉉"),l111l1_l1_+title,l11lll11ll1l_l1_,235,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䉊"),l11ll1_l1_ (u"ࠪࠫ䉋"),l11ll1_l1_ (u"ࠫࠬ䉌"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉍"):l1lll11l1l1l_l1_})
		l11lllll11l1_l1_.append(title)
	if function==l11ll1_l1_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩ䉎") and l11lllll11l1_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11lllll11l1_l1_)
	return l11lllll11l1_l1_
def USE_FASTER_SERVER(l1lll11l1l1l_l1_):
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True): return
	server,l11llll1111l_l1_,l11lll1ll11l_l1_ = l11ll1_l1_ (u"ࠧࠨ䉏"),0,0
	succeeded,l11llll111l1_l1_,l1l111llll1l_l1_ = CHECK_ACCOUNT(l1lll11l1l1l_l1_,False)
	if succeeded:
		l1l111ll1ll1_l1_ = DNS_RESOLVER(l11llll111l1_l1_)
		l11llll1111l_l1_ = PING(l1l111ll1ll1_l1_[0],int(l1l111llll1l_l1_))
		l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䉐"))
		groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䉑"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䉒"))
		l1ll1l11l11l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䉓"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䉔"),groups[1])
		url = l1ll1l11l11l_l1_[0][2]
		l1l1111ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩ䉕"),url,re.DOTALL)
		l1l1111ll1l1_l1_ = l1l1111ll1l1_l1_[0]
		if l11ll1_l1_ (u"ࠧ࠻ࠩ䉖") in l1l1111ll1l1_l1_: l1l11111l111_l1_,l1l111l1ll1l_l1_ = l1l1111ll1l1_l1_.split(l11ll1_l1_ (u"ࠨ࠼ࠪ䉗"))
		else: l1l11111l111_l1_,l1l111l1ll1l_l1_ = l1l1111ll1l1_l1_,l11ll1_l1_ (u"ࠩ࠻࠴ࠬ䉘")
		l11lll11l11l_l1_ = DNS_RESOLVER(l1l11111l111_l1_)
		l11lll1ll11l_l1_ = PING(l11lll11l11l_l1_[0],int(l1l111l1ll1l_l1_))
	if l11llll1111l_l1_ and l11lll1ll11l_l1_:
		message = l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥอไิ์ิๅึࠦวๅลุ่๏ࠦรๆࠢสุ่๐ัโำࠣห้ษำา฻ࠣรࠦࠧࠧ䉙")
		message += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䉚")+l11ll1_l1_ (u"ࠬ๎โหูࠢหห฿ࠠโ์ࠣหู้๊าใิࠤฬ๊รึๆํࠫ䉛")+l11ll1_l1_ (u"࠭࡜࡯ࠩ䉜")+str(int(l11lll1ll11l_l1_*1000))+l11ll1_l1_ (u"ࠧࠡ็็๎ࠥัว็์ฬࠫ䉝")
		message += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䉞")+l11ll1_l1_ (u"๋ࠩๆฯࠦึศศ฼ࠤๆ๐ࠠศๆึ๎ึ็ัࠡษ็ฬิ๐ไࠨ䉟")+l11ll1_l1_ (u"ࠪࡠࡳ࠭䉠")+str(int(l11llll1111l_l1_*1000))+l11ll1_l1_ (u"๋ࠫࠥไ๋ࠢฮห๋๐ษࠨ䉡")
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䉢"),l11ll1_l1_ (u"࠭วๅีํีๆืࠠศๆฦู้๐ࠧ䉣"),l11ll1_l1_ (u"ࠧศๆึ๎ึ็ัࠡษ็วุืูࠨ䉤"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䉥"),message)
		if l1ll111ll1_l1_==1 and l11llll1111l_l1_<l11lll1ll11l_l1_: server = l11llll111l1_l1_+l11ll1_l1_ (u"ࠩ࠽ࠫ䉦")+l1l111llll1l_l1_
	else: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䉧"),l11ll1_l1_ (u"ࠫࠬ䉨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䉩"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡษ็ื๏ืแาࠢส่อี๊ๅࠩ䉪"))
	settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ䉫")+l1lll11l1l1l_l1_,server)
	return
def PLAY(l1lll11l1l1l_l1_,url,type):
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䉬")+l1lll11l1l1l_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫ䉭")+l1lll11l1l1l_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠪࢀࠬ䉮")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ䉯")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䉰")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"࠭ࡼࠧࠩ䉱"),l11ll1_l1_ (u"ࠧࡽࠩ䉲"))
	#l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ䉳")+l1lll11l1l1l_l1_)
	#if l1111l1l11_l1_:
	#	l1l1111l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬ䉴"),url,re.DOTALL)
	#	url = url.replace(l1l1111l111l_l1_[0],l1111l1l11_l1_)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(l1lll11l1l1l_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䉵"),l11ll1_l1_ (u"ࠫࠬ䉶"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䉷"),l11ll1_l1_ (u"࠭สฮาํี๋ࠥ็ๆ๋๋ࠢฬ๋ࠠอัสࠤ࠳๊ࠦาฮ์ࠤ฾ีๅࠡฬ฽๎๏ื็ࠡวำห้ࠥๆหࠢ็หࠥะูาใ้ࠣฬࠦ็้ࠢ࠱ࠤࠥ๎ูะ็ࠣฮ฿๐๊า้ࠣษ้อฺ่ࠠาࠤฬ๊ึา๊ิอࠥอไใื๋ํࠥ࠴ࠠศๆะหัฯࠠๅ้ำหࠥอไห฼ํ๎ึࠦ็๋ࠢไๆ฼ࠦลัษࠣ฻้ฮสࠡ็้็ฺࠥัไหࠣไࡒ࠹ࡕࠡล้ࠤฯ฿ๅๅ๊ࠢิฬࠦวๅฬ฽๎๏ืࠠ࠯๋ࠢๅ็฽ฺ่ࠠา้ฬࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡓ࠳ࡖࠢอัฯอฬࠡโࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฮศืࠪ䉸"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ䉹")+l1lll11l1l1l_l1_)
	l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䉺"),l11ll1_l1_ (u"ࠩสืฯิฯศ็ࠣห้ษีๅ์ࠪ䉻"),l11ll1_l1_ (u"ࠪฮ฾ี๊ๅࠢส่็ี๊ๆࠩ䉼"),l111lll1ll_l1_,l11ll1_l1_ (u"ࠫ์ึว้๋ࠡࠤๅ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠢสู่๊สฯั่ࠤาอไ๋ษ้ࠣ฾ࠦเࡎ࠵ࡘࠤฬ๊ะ๋ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฻า๎้ํࠠฤ็ࠣฮึ๐ฯࠡว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊สฬสํฮࠥอไฤื็๎ࠥ๎วๅฬํࠤฯ่ั๋สสࠤฯ์วิสࠣะ๊๐ูࠡึิ็ฬะࠠแࡏ࠶࡙ࠥลࠡࠨ䉽"))
	if l111l1ll1l1_l1_==1: l111lll1ll_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠬษใหสࠣไࡒ࠹ࡕࠡࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥาฯ๋ัࠪ䉾"),l111lll1ll_l1_,True)
	else: l111lll1ll_l1_ = l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ䉿")
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠧࠡࠩ䊀"):
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䊁"),l11ll1_l1_ (u"ࠩࠪ䊂"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䊃"),l11ll1_l1_ (u"ࠫ฿๐ัࠡ็ึ้ํำࠠฤีอาิอๅࠡใิห฿ࠦไ้ฯา๋ࠥษ่ࠡ฻าอࠥ็ัศ฼สฮ๊่ࠥฮั๊หࠥ࠴࠮࠯ࠢํะอࠦลๆษࠣฮึ้็ࠡใสี฿ࠦสๆษ่หࠥษ่ࠡวูหๆฯࠠฮำไࠤศ๎ࠠฤ์ุࠣ๏ࠦยฯำ้ࠣ฾ํวࠨ䊄"))
		return
	l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䊅"),l11ll1_l1_ (u"࠭ࠧ䊆"),l11ll1_l1_ (u"ࠧࠨ䊇"),l111lll1ll_l1_,l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็๋ࠣีอࠠแࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥฮฯๅษ้๋ࠣࠦࠠศๆๅำ๏๋ࠠภࠩ䊈"))
	if l111l1ll1l1_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䊉"),l11ll1_l1_ (u"ࠪࠫ䊊"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䊋"),l11ll1_l1_ (u"ࠬะๅࠡษ็ษ้เวยࠩ䊌"))
		return
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䊍")+l1lll11l1l1l_l1_,l111lll1ll_l1_)
	#l1l111l11l11_l1_(l1lll11l1l1l_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_)
	return
def ADD_REFERER(l1lll11l1l1l_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䊎"),l11ll1_l1_ (u"ࠨࠩ䊏"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䊐"),l11ll1_l1_ (u"ࠪฮาึ๊า่๋๊่่ࠢࠦษ่ࠤัีวࠡ࠰ࠣ๎ึา้ࠡ฻า้ࠥะฺ๋์ิ๋ࠥหะศࠢๆ๊ฯࠦไศࠢอ฽ึ็ࠠๆษ๋ࠣํࠦ࠮๋ࠡࠢ฽ิ๋ࠠห฼ํ๎ึํࠠฦๆสࠤ฾์ฯࠡษ็ฺึ๎ัสࠢส่็฻่๊ࠢ࠱ࠤฬ๊อศฮฬࠤ้ํะศࠢส่ฯเ๊๋ำ๋ࠣ๏ࠦแใูࠣษีอุࠠๆหฮ๋ࠥๆไࠢืี่ฯࠠแࡏ࠶࡙ࠥษๆࠡฬ฼้้ࠦ็ัษࠣห้ะฺ๋์ิࠤ࠳่ࠦโไฺࠤ฾์ฯๆษࠣฮุะฮะ็ࠣาิ๋ษࠡโࡐ࠷࡚ࠦสฮฬสะࠥๆࡒࡦࡨࡨࡶࡪࡸࠠฯษุࠫ䊑"))
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭䊒")+l1lll11l1l1l_l1_)
	l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䊓"),l11ll1_l1_ (u"࠭วิฬัำฬ๋ࠠศๆฦู้๐ࠧ䊔"),l11ll1_l1_ (u"ࠧห฻า๎้ࠦวๅไา๎๊࠭䊕"),l11l111lll_l1_,l11ll1_l1_ (u"ࠨ้ำหࠥํ่ࠡโࡕࡩ࡫࡫ࡲࡦࡴࠣห้๋ำหะา้ࠥำวๅ์สࠤ๊฿ࠠแࡏ࠶࡙ࠥอไั์ࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฼ำ๏๊็ࠡล่ࠤฯื๊ะࠢศ฽ฬีส่ࠢศ่๎่ࠦื฻ํอࠥอไหอห๎ฯࠦวๅลุ่๏่ࠦศๆอ๎ࠥะโา์หหࠥะๆศีหࠤัฺ๋๊ࠢืี่อสࠡโࡐ࠷࡚ࠦฟࠢࠩ䊖"))
	if l111l1ll1l1_l1_==1: refererr = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠩฦ็ฯฮࠠแࡏ࠶࡙ࠥࡘࡥࡧࡧࡵࡩࡷࠦฬะ์าࠫ䊗"),l11l111lll_l1_,True)
	else: l11l111lll_l1_ = l11ll1_l1_ (u"ࠪࠫ䊘")
	if l11l111lll_l1_==l11ll1_l1_ (u"ࠫࠥ࠭䊙"):
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䊚"),l11ll1_l1_ (u"࠭ࠧ䊛"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䊜"),l11ll1_l1_ (u"ࠨ฼ํี๋ࠥำๆ๊ะࠤศูสฯัส้ࠥ็ัศ฼่ࠣํำฯ่ࠢฦ์ࠥ฿ฯสࠢไีฬเวหࠢ็์าี็ศࠢ࠱࠲࠳๊ࠦอสࠣษ๊อࠠหำๆ๋ࠥ็วา฼ࠣฮ๊อๅศࠢฦ์ࠥหึศใฬࠤาืแࠡล๋ࠤศ๐ࠠี์ࠣฦำืࠠๆ฻๊หࠬ䊝"))
		return
	l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䊞"),l11ll1_l1_ (u"ࠪࠫ䊟"),l11ll1_l1_ (u"ࠫࠬ䊠"),l11l111lll_l1_,l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋่ࠠาสࠤๅࡘࡥࡧࡧࡵࡩࡷࠦศะๆสࠤ๊์ࠠࠡษ็ๆิ๐ๅࠡมࠪ䊡"))
	if l111l1ll1l1_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䊢"),l11ll1_l1_ (u"ࠧࠨ䊣"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䊤"),l11ll1_l1_ (u"ࠩอ้ࠥอไฦๆ฽หฦ࠭䊥"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ䊦")+l1lll11l1l1l_l1_,l11l111lll_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_)
	return
def GET_URL(l1lll11l1l1l_l1_,l11lll1l111l_l1_=l11ll1_l1_ (u"ࠫࠬ䊧")):
	if not l11lll1l111l_l1_: l11lll1l111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ䊨")+l1lll11l1l1l_l1_)
	server = SERVER(l11lll1l111l_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ䊩"))
	username = re.findall(l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ࠫ࠲࠯ࡅࠩࠧࠩ䊪"),l11lll1l111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪ䊫"),re.DOTALL)
	password = re.findall(l11ll1_l1_ (u"ࠩࡳࡥࡸࡹࡷࡰࡴࡧࡁ࠭࠴ࠪࡀࠫࠩࠫ䊬"),l11lll1l111l_l1_+l11ll1_l1_ (u"ࠪࠪࠬ䊭"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䊮"),l11ll1_l1_ (u"ࠬ࠭䊯"),l11ll1_l1_ (u"࠭แฮืࠣหูะัศๅࠣไࡒ࠹ࡕࠨ䊰"),l11ll1_l1_ (u"ࠧาษห฻ࠥอิหำส็ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡไ่ฮࠥอๆหࠢหษ฻อแห้ࠣษ้๏ࠠศๆหี๋อๅอࠢ็หࠥ๐ูๆๆࠣวํࠦวๅำสฬ฼ฺ๋ࠦำ้ࠣํา่ะࠢไ๎ࠥอไษำ้ห๊าࠠ࠯ࠢฦิ์ฮࠠฦๆ์ࠤ็อฦๆหࠣหูะัศๅࠣไࡒ࠹ࡕ๊ࠡๅ้ࠥฮลืษไอࠥืวษูࠣไࡒ࠹ࡕࠡฮา๎ิࠦร้ࠢๅ้ࠥฮลึๆสัࠥอไาษห฻ࠥอไใัํ้ࠬ䊱"))
		return l11ll1_l1_ (u"ࠨࠩ䊲"),l11ll1_l1_ (u"ࠩࠪ䊳"),l11ll1_l1_ (u"ࠪࠫ䊴"),l11ll1_l1_ (u"ࠫࠬ䊵"),l11ll1_l1_ (u"ࠬ࠭䊶")
	username = username[0]
	password = password[0]
	l1l11l111l1l_l1_ = server+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡢࡲ࡬࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ䊷")+username+l11ll1_l1_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ䊸")+password
	l11lllllll11_l1_ = server+l11ll1_l1_ (u"ࠨ࠱ࡪࡩࡹ࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭䊹")+username+l11ll1_l1_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭䊺")+password+l11ll1_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡰ࠷ࡺࡥࡰ࡭ࡷࡶࠫ䊻")
	return l1l11l111l1l_l1_,l11lllllll11_l1_,server,username,password
def GET_FILENAME(l1lll11l1l1l_l1_,l1l111ll1l1l_l1_=l11ll1_l1_ (u"ࠫࠬ䊼")):
	l1l11111l1ll_l1_ = l1l111ll1l1l_l1_.replace(l11ll1_l1_ (u"ࠬ࠵ࠧ䊽"),l11ll1_l1_ (u"࠭࡟ࠨ䊾")).replace(l11ll1_l1_ (u"ࠧ࠻ࠩ䊿"),l11ll1_l1_ (u"ࠨࡡࠪ䋀")).replace(l11ll1_l1_ (u"ࠩ࠱ࠫ䋁"),l11ll1_l1_ (u"ࠪࡣࠬ䋂"))
	l1l11111l1ll_l1_ = l1l11111l1ll_l1_.replace(l11ll1_l1_ (u"ࠫࡄ࠭䋃"),l11ll1_l1_ (u"ࠬࡥࠧ䋄")).replace(l11ll1_l1_ (u"࠭࠽ࠨ䋅"),l11ll1_l1_ (u"ࠧࡠࠩ䋆")).replace(l11ll1_l1_ (u"ࠨࠨࠪ䋇"),l11ll1_l1_ (u"ࠩࡢࠫ䋈"))
	l1l11111l1ll_l1_ = os.path.join(addoncachefolder,l1l11111l1ll_l1_).strip(l11ll1_l1_ (u"ࠪ࠲ࡲ࠹ࡵࠨ䋉"))+l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶࠩ䋊")
	return l1l11111l1ll_l1_
def ADD_ACCOUNT(l1lll11l1l1l_l1_,l111l1l1_l1_):
	l1l1111llll1_l1_ = l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䋋")
	if l111l1l1_l1_: l1l1111llll1_l1_ = l11ll1_l1_ (u"࠭ลืษไอࠥ๎ส฻์ํีࠥืวษูࠣࠫ䋌")+text_numbers[int(l111l1l1_l1_)]
	l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䋍"),l11ll1_l1_ (u"ࠨࠩ䋎"),l11ll1_l1_ (u"ࠩࠪ䋏"),l1l1111llll1_l1_,l11ll1_l1_ (u"๋ࠪีอࠠศๆฯึฦࠦๅ็ࠢส่อืๆศ็ฯࠤ๏ำสศฮࠣีฬฮืࠡใํำ๏๎็ศฬ้๋ࠣࠦวๅว้ฮึ์สࠡล๋ࠤศฺสาษๆࠤ๊ีแ้฻้๋ࠣࠦวๅึิ็ฬะࠠศๆอ๎ࠥะศ๋฻๊ࠤํอไาษห฻๋ࠥๆ่๋ࠡ฽ࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࡱ࠸ࡻ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳ่่ࠦาสࠤ๊ัวๅࠢ็ฮํ฼๊ฮࠢื็้ࠦ็ัษࠣห้ืวษูࠣࡠࡳࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲࡷࡺ࠲ࡵࡲࡨ࠰ࡪ࡭ࡹ࡮ࡵࡣ࠰࡬ࡳ࠴࡯ࡰࡵࡸ࠲ࡰࡦࡴࡧࡶࡣࡪࡩࡸ࠵ࡡࡳࡣ࠱ࡱ࠸ࡻࠠ࡝ࡰ๋้ࠣࠦสา์าࠤส฼วโหࠣวํࠦส฻์ํีࠥษ่ࠡ็ึัࠥอไาษห฻ࠥอไร่ࠣรࠬ䋐"))
	if l111l1ll1l1_l1_!=1: return
	l1l111ll11l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡸ࡬ࡠࠩ䋑")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䋒")+l111l1l1_l1_)
	l11lll1l1l1l_l1_ = True
	if l1l111ll11l1_l1_:
		l111l1ll1l1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䋓"),l11ll1_l1_ (u"ࠧไฬสฬฮࠦฬะ์าࠫ䋔"),l11ll1_l1_ (u"ࠨฬ฼ำ๏๊ࠠศๆๅำ๏๋ࠧ䋕"),l11ll1_l1_ (u"่ࠩืาࠦวๅไา๎๊࠭䋖"),l11ll1_l1_ (u"ࠪห้ืวษูࠣห้ำวๅ์๋ࠣํࡀࠧ䋗"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䋘")+l1l111ll11l1_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䋙")+l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠤ์ึว้๋ࠡࠤึอศุࠢใࡑ࠸࡛ࠠศๆ่ืั๊ࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣฮ฾ี๊ๅ้ࠣว๊ࠦสา์าࠤ่ะวษหࠣีฬฮืࠡฮา๎ิࠦฟࠢࠩ䋚"))
		if l111l1ll1l1_l1_==-1: return
		elif l111l1ll1l1_l1_==0: l1l111ll11l1_l1_ = l11ll1_l1_ (u"ࠧࠨ䋛")
		elif l111l1ll1l1_l1_==2:
			l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䋜"),l11ll1_l1_ (u"ࠩࠪ䋝"),l11ll1_l1_ (u"ࠪࠫ䋞"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䋟"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣห้ืวษูࠣห้๋ำอๆࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ䋠"))
			if l111l1ll1l1_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䋡"),l11ll1_l1_ (u"ࠧࠨ䋢"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䋣"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢส่ึอศุࠩ䋤"))
			l11lll1l1l1l_l1_ = False
			l11lllll11ll_l1_ = l11ll1_l1_ (u"ࠪࠫ䋥")
	if l11lll1l1l1l_l1_:
		l11lllll11ll_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠫฬ้สษࠢิหอ฽ࠠแࡏ࠶้࡙ࠥวๆๆสࠫ䋦"),l1l111ll11l1_l1_)
		l11lllll11ll_l1_ = l11lllll11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ䋧"))
		if not l11lllll11ll_l1_:
			l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䋨"),l11ll1_l1_ (u"ࠧࠨ䋩"),l11ll1_l1_ (u"ࠨࠩ䋪"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䋫"),l11ll1_l1_ (u"่ࠪ็ีࠠใ็อࠤอหฯฯษ็ࠤึอศุࠢไหึเࠠ࠯࠰๋้ࠣࠦสา์าࠤู๊อࠡษ็ีฬฮืࠡษ็ุ้าไࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠩ䋬"))
			if l111l1ll1l1_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䋭"),l11ll1_l1_ (u"ࠬ࠭䋮"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䋯"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠศๆิหอ฽ࠧ䋰"))
		else:
			#l1l11l111l1l_l1_,l11lllllll11_l1_,server,username,password = GET_URL(l1lll11l1l1l_l1_)
			#if not username: return
			message = l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไๆ฻็์๊อสࠡฬ่ࠤศิะ่ษ้๋ࠣࠦัศสฺࠤๅࡓ࠳ࡖࠢส่ี๐ࠠศ่อࠤ่ะศห้ࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ศࠢยࠥࡡࡴࠧ䋱")
			#message += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䋲")+server+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ฾์่ศ่ࠣหู้๊าใิ࠾ࠥ࠭䋳")
			#message += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䋴")+username+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣวิ็ࠣห้๋ำหะา้࠿ࠦࠧ䋵")
			#message += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䋶")+password+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ๅ็้ฮࠦวๅีิ࠾ࠥ࠭䋷")
			l111l1ll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ䋸"),l11ll1_l1_ (u"ࠩࠪ䋹"),l11ll1_l1_ (u"ࠪࠫ䋺"),l11ll1_l1_ (u"ࠫฬ๊ัศสฺࠤฬ๊ฬะ์าࠤ์๎࠺ࠨ䋻"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䋼")+l11lllll11ll_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䋽")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䋾")+message)
			if l111l1ll1l1_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䋿"),l11ll1_l1_ (u"ࠩࠪ䌀"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䌁"),l11ll1_l1_ (u"ࠫฯ๋ࠠศๆศ่฿อมࠨ䌂"))
				return
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ䌃")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䌄")+l111l1l1_l1_,l11lllll11ll_l1_)
	#settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡢࠫ䌅")+l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠨࠩ䌆"))
	#settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡷ࡭ࡲ࡫ࡤࡪࡨࡩࡣࠬ䌇")+l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䌈"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ䌉")+l1lll11l1l1l_l1_)
	if not l111lll1ll_l1_: settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䌊")+l1lll11l1l1l_l1_,l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ䌋"))
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䌌"),l11ll1_l1_ (u"ࠨࠩ䌍"),l11ll1_l1_ (u"ࠩࠪ䌎"),l11ll1_l1_ (u"ࠪࠫ䌏"),l11lllll11ll_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ฬ่ࠤฯเ๊าࠢิหอ฽ࠠศึอีฬ้ࠠแࡏ࠶࡙ࠥหไ๊๊ࠢิฬࠦวๅำสฬ฼ࠦวๅฮา๎ิࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำี้ࠡำหࠥอไาษห฻ࠥอไร่ࠣรࠬ䌐"))
	#if l1ll111ll1_l1_==1: ok,l11llll111l1_l1_,l1l111llll1l_l1_ = CHECK_ACCOUNT(l1lll11l1l1l_l1_,True)
	#l1l111l11l11_l1_(l1lll11l1l1l_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_)
	return
def READ_ALL_LINES(lines,l1l111ll1l11_l1_,l1l11111l11l_l1_,l11l1l1lll_l1_,length,l1ll1l1l11l1_l1_,l11lllllll11_l1_):
	l1ll1l11l11l_l1_,l11lll11llll_l1_ = [],[]
	l11lll1ll1l1_l1_ = [l11ll1_l1_ (u"ࠬ࠴ࡡࡷ࡫ࠪ䌑"),l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䌒"),l11ll1_l1_ (u"ࠧ࠯࡯࡮ࡺࠬ䌓"),l11ll1_l1_ (u"ࠨ࠰ࡩࡰࡻ࠭䌔"),l11ll1_l1_ (u"ࠩ࠱ࡱࡵ࠹ࠧ䌕"),l11ll1_l1_ (u"ࠪ࠲ࡼ࡫ࡢ࡮ࠩ䌖")]
	for line in lines:
		if l1ll1l1l11l1_l1_%473==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,40+int(10*l1ll1l1l11l1_l1_/length),l11ll1_l1_ (u"ࠫ็ืวยหࠣห้็๊ะ์๋๋ฬะࠧ䌗"),l11ll1_l1_ (u"ࠬอไโ์า๎ํࠦัใ็࠽࠱ࠬ䌘"),str(l1ll1l1l11l1_l1_)+l11ll1_l1_ (u"࠭ࠠ࠰ࠢࠪ䌙")+str(length))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None,None
		url = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࡜࡯࠭ࠫࠬ࡭ࡺࡴࡱࡾ࡫ࡸࡹࡶࡳࡽࡴࡷࡱࡵ࠯࠮ࠫࡁࠬࠨࠬ䌚"),line,re.DOTALL)
		if url:
			line,url,dummy = url[0]
			url = url.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ䌛"),l11ll1_l1_ (u"ࠩࠪ䌜"))
			line = line.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭䌝"),l11ll1_l1_ (u"ࠫࠬ䌞"))
		else:
			l11lll11llll_l1_.append({l11ll1_l1_ (u"ࠬࡲࡩ࡯ࡧࠪ䌟"):line})
			continue
		l1l1111lll11_l1_,context,group,title,type,l1l1111l1l1l_l1_ = {},l11ll1_l1_ (u"࠭ࠧ䌠"),l11ll1_l1_ (u"ࠧࠨ䌡"),l11ll1_l1_ (u"ࠨࠩ䌢"),l11ll1_l1_ (u"ࠩࠪ䌣"),False
		try:
			line,title = line.rsplit(l11ll1_l1_ (u"ࠪࠦ࠱࠭䌤"),1)
			line = line+l11ll1_l1_ (u"ࠫࠧ࠭䌥")
		except:
			try: line,title = line.rsplit(l11ll1_l1_ (u"ࠬ࠷ࠬࠨ䌦"),1)
			except: title = l11ll1_l1_ (u"࠭ࠧ䌧")
		l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ䌨")] = url
		params = re.findall(l11ll1_l1_ (u"ࠨࠢࠫ࠲࠯ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䌩"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11ll1_l1_ (u"ࠩࠥࠫ䌪"),l11ll1_l1_ (u"ࠪࠫ䌫")).strip(l11ll1_l1_ (u"ࠫࠥ࠭䌬"))
			l1l1111lll11_l1_[key] = value.strip(l11ll1_l1_ (u"ࠬࠦࠧ䌭"))
		keys = list(l1l1111lll11_l1_.keys())
		if not title:
			if l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䌮") in keys and l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䌯")]: title = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭䌰")]
		l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䌱")] = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ䌲")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䌳"),l11ll1_l1_ (u"ࠬࠦࠧ䌴")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䌵"),l11ll1_l1_ (u"ࠧࠡࠩ䌶"))
		if l11ll1_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭䌷") in keys:
			l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭䌸")] = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠪࡰࡴ࡭࡯ࠨ䌹")]
			del l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫࡱࡵࡧࡰࠩ䌺")]
		else: l1l1111lll11_l1_[l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ䌻")] = l11ll1_l1_ (u"࠭ࠧ䌼")
		if l11ll1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭䌽") in keys and l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䌾")]: group = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ䌿")]
		if any(value in url.lower() for value in l11lll1ll1l1_l1_): l1l1111l1l1l_l1_ = True
		if l1l1111l1l1l_l1_ or l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䍀") in group or l11ll1_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ䍁") in group:
			type = l11ll1_l1_ (u"ࠬ࡜ࡏࡅࠩ䍂")
			if l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䍃") in group: type = type+l11ll1_l1_ (u"ࠧࡠࡕࡈࡖࡎࡋࡓࠨ䍄")
			elif l11ll1_l1_ (u"ࠨࡡࡢࡑࡔ࡜ࡉࡆࡕࡢࡣࠬ䍅") in group: type = type+l11ll1_l1_ (u"ࠩࡢࡑࡔ࡜ࡉࡆࡕࠪ䍆")
			else: type = type+l11ll1_l1_ (u"ࠪࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬ䍇")
			group = group.replace(l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䍈"),l11ll1_l1_ (u"ࠬ࠭䍉")).replace(l11ll1_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ䍊"),l11ll1_l1_ (u"ࠧࠨ䍋"))
		else:
			type = l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䍌")
			if title in l1l111ll1l11_l1_: context = context+l11ll1_l1_ (u"ࠩࡢࡉࡕࡍࠧ䍍")
			if title in l1l11111l11l_l1_: context = context+l11ll1_l1_ (u"ࠪࡣࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䍎")
			if not group: type = type+l11ll1_l1_ (u"ࠫࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭䍏")
			else: type = type+context
		group = group.strip(l11ll1_l1_ (u"ࠬࠦࠧ䍐")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䍑"),l11ll1_l1_ (u"ࠧࠡࠩ䍒")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䍓"),l11ll1_l1_ (u"ࠩࠣࠫ䍔"))
		if l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࠩ䍕") in type: group = l11ll1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡏࡍ࡛ࡋ࡟ࡠࠣࠤࠫ䍖")
		elif l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪ䍗") in type: group = l11ll1_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣ࡛ࡕࡄࡠࡡࠤࠥࠬ䍘")
		elif l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࠫ䍙") in type:
			l1l111ll1111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠ࡜ࡕࡶࡡࡡࡪࠫࠡ࠭࡞ࡉࡪࡣ࡜ࡥ࠭ࠪ䍚"),l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䍛")],re.DOTALL)
			if l1l111ll1111_l1_: l1l111ll1111_l1_ = l1l111ll1111_l1_[0]
			else: l1l111ll1111_l1_ = l11ll1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡕࡈࡖࡎࡋࡓࡠࡡࠤࠥࠬ䍜")
			group = group+l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䍝")+l1l111ll1111_l1_
		l11lll1l11_l1_ = l11ll1_l1_ (u"ࠬ࠭䍞")
		if l11ll1_l1_ (u"࠭ࡩࡥࠩ䍟") in keys:
			l11lll1l11_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧࡪࡦࠪ䍠")]
			del l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨ࡫ࡧࠫ䍡")]
		if l11ll1_l1_ (u"ࠩࡌࡈࠬ䍢") in keys:
			l11lll1l11_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠪࡍࡉ࠭䍣")]
			del l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫࡎࡊࠧ䍤")]
		if l11ll1_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡳࡷ࡭ࠧ䍥") in l11lllllll11_l1_ and l11ll1_l1_ (u"࠭࠮ࠨ䍦") in l11lll1l11_l1_:
			l11lll1l11_l1_ = l11lll1l11_l1_.rsplit(l11ll1_l1_ (u"ࠧ࠯ࠩ䍧"),1)[1]
			l11lll1l11_l1_ = l11ll1_l1_ (u"ࠨࡾࠪ䍨")+l11lll1l11_l1_.upper()+l11ll1_l1_ (u"ࠩࡿࠤࠬ䍩")
		if l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ䍪") in keys: del l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䍫")]
		title = l11lll1l11_l1_+l1l1111lll11_l1_[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䍬")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l1ll1l11ll1l_l1_,title = SPLIT_NAME(title)
		l1l1111lll11_l1_[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ䍭")] = type
		l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ䍮")] = context
		l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䍯")] = group.upper()
		l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䍰")] = title.upper()
		try: l1l1111lll11_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䍱")] = COUNTRIES_CODES[l1ll1l11ll1l_l1_.upper()]
		except: l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ䍲")] = l1ll1l11ll1l_l1_.upper()
		#dictt1[l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䍳")] = countryy.upper()
		l1l1111lll11_l1_[l11ll1_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䍴")] = language.upper()
		l1ll1l11l11l_l1_.append(l1l1111lll11_l1_)
		l1ll1l1l11l1_l1_ += 1
	return l1ll1l11l11l_l1_,l1ll1l1l11l1_l1_,l11lll11llll_l1_
def CLEAN_NAME(title):
	title = title.replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䍵"),l11ll1_l1_ (u"ࠨࠢࠪ䍶")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䍷"),l11ll1_l1_ (u"ࠪࠤࠬ䍸")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䍹"),l11ll1_l1_ (u"ࠬࠦࠧ䍺"))
	title = title.replace(l11ll1_l1_ (u"࠭ࡼࡽࠩ䍻"),l11ll1_l1_ (u"ࠧࡽࠩ䍼")).replace(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䍽"),l11ll1_l1_ (u"ࠩ࠽ࠫ䍾")).replace(l11ll1_l1_ (u"ࠪ࠱࠲࠭䍿"),l11ll1_l1_ (u"ࠫ࠲࠭䎀"))
	title = title.replace(l11ll1_l1_ (u"ࠬࡡ࡛ࠨ䎁"),l11ll1_l1_ (u"࡛࠭ࠨ䎂")).replace(l11ll1_l1_ (u"ࠧ࡞࡟ࠪ䎃"),l11ll1_l1_ (u"ࠨ࡟ࠪ䎄"))
	title = title.replace(l11ll1_l1_ (u"ࠩࠫࠬࠬ䎅"),l11ll1_l1_ (u"ࠪࠬࠬ䎆")).replace(l11ll1_l1_ (u"ࠫ࠮࠯ࠧ䎇"),l11ll1_l1_ (u"ࠬ࠯ࠧ䎈"))
	title = title.replace(l11ll1_l1_ (u"࠭࠼࠽ࠩ䎉"),l11ll1_l1_ (u"ࠧ࠽ࠩ䎊")).replace(l11ll1_l1_ (u"ࠨࡀࡁࠫ䎋"),l11ll1_l1_ (u"ࠩࡁࠫ䎌"))
	title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ䎍"))
	return title
def CREATE_GROUPED_STREAMS(l11lllll1ll1_l1_,l11l1l1lll_l1_,l111l1l1_l1_):
	l1l11111l1l1_l1_ = {}
	for l11ll1lll_l1_ in l11lllllllll_l1_: l1l11111l1l1_l1_[l11ll1lll_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䎎")+l111l1l1_l1_] = []
	length = len(l11lllll1ll1_l1_)
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l1l11l1_l1_ = 0
	l11lll11llll_l1_ = []
	for l1l1111lll11_l1_ in l11lllll1ll1_l1_:
		if l1ll1l1l11l1_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,50+int(5*l1ll1l1l11l1_l1_/length),l11ll1_l1_ (u"ࠬะี็์ไࠤฬ๊แ๋ัํ์์อสࠡษ็฾๏ืࠠๆำอฬฮ࠭䎏"),l11ll1_l1_ (u"࠭วๅใํำ๏๎ࠠาไ่࠾࠲࠭䎐"),str(l1ll1l1l11l1_l1_)+l11ll1_l1_ (u"ࠧࠡ࠱ࠣࠫ䎑")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		group,context,title,url,l1lll1_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䎒")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䎓")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䎔")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䎕")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ䎖")]
		l1ll1l11ll1l_l1_,language,l11ll1lll_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ䎗")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䎘")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠭䎙")]
		l1l111l1l1ll_l1_ = (group,context,title,url,l1lll1_l1_)
		l1lll1l111l_l1_ = False
		if l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䎚") in l11ll1lll_l1_:
			if l11ll1_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ䎛") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ䎜")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			elif l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ䎝") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭䎞")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			else: l1lll1l111l_l1_ = True
			l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䎟")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
		elif l11ll1_l1_ (u"ࠨࡘࡒࡈࠬ䎠") in l11ll1lll_l1_:
			if l11ll1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䎡") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䎢")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			elif l11ll1_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫ䎣") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䎤")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			elif l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭䎥") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭䎦")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			else: l1lll1l111l_l1_ = True
			l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䎧")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
		else: l1lll1l111l_l1_ = True
		if l1lll1l111l_l1_: l11lll11llll_l1_.append(l1l1111lll11_l1_)
		l1ll1l1l11l1_l1_ += 1
	l1l1111111ll_l1_ = sorted(l11lllll1ll1_l1_,reverse=False,key=lambda key: key[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䎨")].lower())
	del l11lllll1ll1_l1_
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l1l11l1_l1_ = 0
	for l1l1111lll11_l1_ in l1l1111111ll_l1_:
		l1ll1l1l11l1_l1_ += 1
		if l1ll1l1l11l1_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,55+int(5*l1ll1l1l11l1_l1_/length),l11ll1_l1_ (u"ࠪฮฺ์๊โࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ิฮอฯࠧ䎩"),l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ䎪"),str(l1ll1l1l11l1_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䎫")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		l11ll1lll_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ䎬")]
		group,context,title,url,l1lll1_l1_ = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭䎭")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ䎮")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䎯")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ䎰")],l1l1111lll11_l1_[l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠨ䎱")]
		l1ll1l11ll1l_l1_,language = l1l1111lll11_l1_[l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䎲")],l1l1111lll11_l1_[l11ll1_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䎳")]
		l1l111l1ll11_l1_ = (group,context+l11ll1_l1_ (u"ࠧࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䎴"),title,url,l1lll1_l1_)
		l1l111l1l1ll_l1_ = (group,context,title,url,l1lll1_l1_)
		l1l111l1l1l1_l1_ = (l1ll1l11ll1l_l1_,context,title,url,l1lll1_l1_)
		l1l111l1l11l_l1_ = (language,context,title,url,l1lll1_l1_)
		if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䎵") in l11ll1lll_l1_:
			if l11ll1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䎶") in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䎷")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			else: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䎸")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			if l11ll1_l1_ (u"ࠬࡋࡐࡈࠩ䎹")		in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡊࡖࡇࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䎺")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			if l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䎻")	in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡁࡓࡅࡋࡍ࡛ࡋࡄࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䎼")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			if l11ll1_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ䎽")	in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䎾")+l111l1l1_l1_].append(l1l111l1ll11_l1_)
			l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䎿")+l111l1l1_l1_].append(l1l111l1l1l1_l1_)
			l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏀")+l111l1l1_l1_].append(l1l111l1l11l_l1_)
		elif l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ䏁") in l11ll1lll_l1_:
			if   l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䏂")	in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏃")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			elif l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ䏄")	in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏅")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			elif l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ䏆")	in l11ll1lll_l1_: l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䏇")+l111l1l1_l1_].append(l1l111l1l1ll_l1_)
			l1l11111l1l1_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉࡥࠧ䏈")+l111l1l1_l1_].append(l1l111l1l1l1_l1_)
			l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏉")+l111l1l1_l1_].append(l1l111l1l11l_l1_)
	return l1l11111l1l1_l1_,l11lll11llll_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l1ll11_l1_,sep = l11ll1_l1_ (u"ࠨࠩ䏊"),l11ll1_l1_ (u"ࠩࠪ䏋")
	l1lll1l11_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11ll1_l1_ (u"ࠪࠬࠬ䏌"): sep = l11ll1_l1_ (u"ࠫ࠮࠭䏍")
	elif first==l11ll1_l1_ (u"ࠬࡡࠧ䏎"): sep = l11ll1_l1_ (u"࠭࡝ࠨ䏏")
	elif first==l11ll1_l1_ (u"ࠧ࠽ࠩ䏐"): sep = l11ll1_l1_ (u"ࠨࡀࠪ䏑")
	elif first==l11ll1_l1_ (u"ࠩࡿࠫ䏒"): sep = l11ll1_l1_ (u"ࠪࢀࠬ䏓")
	if sep and (sep in rest):
		l1l1lll1ll1l_l1_,l1l1lll1ll11_l1_ = rest.split(sep,1)
		l1ll1l1ll11_l1_ = l1l1lll1ll1l_l1_
		l1lll1l11_l1_ = first+l1l1lll1ll1l_l1_+sep+l11ll1_l1_ (u"ࠫࠥ࠭䏔")+l1l1lll1ll11_l1_
	elif title.count(l11ll1_l1_ (u"ࠬࢂࠧ䏕"))>=2:
		l1l1lll1ll1l_l1_,l1l1lll1ll11_l1_ = title.split(l11ll1_l1_ (u"࠭ࡼࠨ䏖"),1)
		l1ll1l1ll11_l1_ = l1l1lll1ll1l_l1_
		l1lll1l11_l1_ = l1l1lll1ll1l_l1_+l11ll1_l1_ (u"ࠧࠡࡾࠪ䏗")+l1l1lll1ll11_l1_
	else:
		sep = re.findall(l11ll1_l1_ (u"ࠨࡠ࡟ࡻࢀ࠸ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ䏘"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠩࡡࡠࡼࢁ࠳ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ䏙"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠪࡢࡡࡽࡻ࠵ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬ䏚"),title,re.DOTALL)
		if sep:
			l1l1lll1ll1l_l1_,l1l1lll1ll11_l1_ = title.split(sep[0],1)
			l1ll1l1ll11_l1_ = l1l1lll1ll1l_l1_
			l1lll1l11_l1_ = l1l1lll1ll1l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭䏛")+sep[0]+l11ll1_l1_ (u"ࠬࠦࠧ䏜")+l1l1lll1ll11_l1_
	l1lll1l11_l1_ = l1lll1l11_l1_.replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ䏝"),l11ll1_l1_ (u"ࠧࠡࠩ䏞")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䏟"),l11ll1_l1_ (u"ࠩࠣࠫ䏠"))
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭䏡"),l11ll1_l1_ (u"ࠫࠥ࠭䏢"))
	if not l1ll1l1ll11_l1_: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ䏣")
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ䏤"))
	l1lll1l11_l1_ = l1lll1l11_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ䏥"))
	return l1ll1l1ll11_l1_,l1lll1l11_l1_
def GET_HEADERS(l1lll11l1l1l_l1_):
	headers = {}
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䏦")+l1lll11l1l1l_l1_)
	if l111lll1ll_l1_: headers[l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䏧")] = l111lll1ll_l1_
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ䏨")+l1lll11l1l1l_l1_)
	if l11l111lll_l1_: headers[l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䏩")] = l11l111lll_l1_
	return headers
def CREATE_STREAMS(l1lll11l1l1l_l1_,l111l1l1_l1_):
	global l11l1l1lll_l1_,l1l11111l1l1_l1_,l11lll111l11_l1_,l1l111lllll1_l1_,l1l111lll11l_l1_,groups,l11lll1ll1ll_l1_,l11llll1ll11_l1_,l1l111lll111_l1_
	l11lllllll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ䏪")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䏫")+l111l1l1_l1_)
	#l1l11l111l1l_l1_,l11lllllll11_l1_,server,username,password = GET_URL(l1lll11l1l1l_l1_)
	#if not username: return
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ䏬")+l1lll11l1l1l_l1_)
	headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䏭"):l111lll1ll_l1_}
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䏮"),l11ll1_l1_ (u"ࠪࠫ䏯"),l11ll1_l1_ (u"ࠫࠬ䏰"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䏱"),l11ll1_l1_ (u"ู࠭ๆๆํอࠥาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอ่ࠥฯࠡฬะฮฬาฺࠠัฬࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ้ฮࠠศๆ่่ๆอสࠡษ็ฦ๋ࠦฟࠨ䏲"))
	#if l1ll111ll1_l1_!=1: return
	l1l11111l1ll_l1_ = l1l1l1ll1l1l_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ䏳"),l11ll1_l1_ (u"ࠨࡡࠪ䏴")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䏵")+l111l1l1_l1_)
	if 1:
		succeeded,l11llll111l1_l1_,l1l111llll1l_l1_ = True,l11ll1_l1_ (u"ࠪࠫ䏶"),l11ll1_l1_ (u"ࠫࠬ䏷")
		if not succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䏸"),l11ll1_l1_ (u"࠭ࠧ䏹"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䏺"),l11ll1_l1_ (u"ࠨใื่ࠥฮำฮส้้ࠣ็วหࠢใࡑ࠸࡛ࠠ࠯ࠢฦัฯ๋วๅࠢิหอ฽ࠠแࡏ࠶࡙ࠥเ๊าุࠢั๏ำࠠฤ๊ࠣๆิ๐ๅࠡล๋ࠤ้อ๋ࠠ฻่่ࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะࠥอิหำส็๋ࠥฯโ๊฼ࠤํ฻อ๋ฯࠣ์๏าศࠡล้ࠤฯ฼๊โࠢิหอ฽ࠠศๆสุฯืวไࠢห๊ๆูใࠡๆ็ฬึ์วๆฮࠣฬฬูสฯัส้่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢส่๊๎ฬ้ัฬࠤอํะศࠢส่อืๆศ็ฯࠫ䏻"))
			if not l11lllllll11_l1_: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䏼"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡎࡰࠢࡐ࠷࡚ࠦࡕࡓࡎࠣࡪࡴࡻ࡮ࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࡵࠪ䏽"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䏾"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡍ࠴ࡗࠣࡪ࡮ࡲࡥࡴࠩ䏿"))
			return
		l1l11l111ll1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11lllllll11_l1_,headers,True)
		if not l1l11l111ll1_l1_: return
		open(l1l11111l1ll_l1_,l11ll1_l1_ (u"࠭ࡷࡣࠩ䐀")).write(l1l11l111ll1_l1_)
	else: l1l11l111ll1_l1_ = open(l1l11111l1ll_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ䐁")).read()
	if kodi_version>18.99 and l1l11l111ll1_l1_: l1l11l111ll1_l1_ = l1l11l111ll1_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭䐂"))
	#l1l11l111ll1_l1_ = l1l11l111ll1_l1_[33000111:77000111]
	l11l1l1lll_l1_ = DIALOG_PROGRESS()
	l11l1l1lll_l1_.create(l11ll1_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠩ䐃"),l11ll1_l1_ (u"ࠪࠫ䐄"))
	PROGRESS_UPDATE(l11l1l1lll_l1_,15,l11ll1_l1_ (u"ࠫฯ์ุ๋ใࠣห้๋ไโࠢส่ึฬ๊ิ์ࠪ䐅"),l11ll1_l1_ (u"ࠬ࠭䐆"))
	l1l11l111ll1_l1_ = l1l11l111ll1_l1_.replace(l11ll1_l1_ (u"࠭ࠢࡵࡸࡪ࠱ࠬ䐇"),l11ll1_l1_ (u"ࠧࠣࠢࡷࡺ࡬࠳ࠧ䐈"))
	l1l11l111ll1_l1_ = l1l11l111ll1_l1_.replace(l11ll1_l1_ (u"ࠨ๐ࠪ䐉"),l11ll1_l1_ (u"ࠩࠪ䐊")).replace(l11ll1_l1_ (u"ࠪ๏ࠬ䐋"),l11ll1_l1_ (u"ࠫࠬ䐌")).replace(l11ll1_l1_ (u"ࠬ๕ࠧ䐍"),l11ll1_l1_ (u"࠭ࠧ䐎")).replace(l11ll1_l1_ (u"ࠧํࠩ䐏"),l11ll1_l1_ (u"ࠨࠩ䐐"))
	l1l11l111ll1_l1_ = l1l11l111ll1_l1_.replace(l11ll1_l1_ (u"ࠩ๔ࠫ䐑"),l11ll1_l1_ (u"ࠪࠫ䐒")).replace(l11ll1_l1_ (u"ࠫ๕࠭䐓"),l11ll1_l1_ (u"ࠬ࠭䐔")).replace(l11ll1_l1_ (u"࠭ํࠨ䐕"),l11ll1_l1_ (u"ࠧࠨ䐖")).replace(l11ll1_l1_ (u"ࠨ๔ࠪ䐗"),l11ll1_l1_ (u"ࠩࠪ䐘"))
	l1l11l111ll1_l1_ = l1l11l111ll1_l1_.replace(l11ll1_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠯ࡷ࡭ࡹࡲࡥ࠾ࠩ䐙"),l11ll1_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡀࠫ䐚")).replace(l11ll1_l1_ (u"ࠬࡺࡶࡨ࠯ࠪ䐛"),l11ll1_l1_ (u"࠭ࠧ䐜"))
	l1l11111l11l_l1_,l1l111ll1l11_l1_ = [],[]
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࡕࡘࡏࡈࡔࡈࡗࡘࡥࡕࡑࡆࡄࡘࡊ࠮ࡰࡅ࡫ࡤࡰࡴ࡭ࠬ࠳࠲࠯ࠫั๊ศࠡษ็้้็วหࠢส่ะอๆ้์ฬࠫ࠱࠭วๅ็็ๅࠥืโๆ࠼࠰ࠫ࠱࠭࠱ࠡ࠱ࠣ࠷ࠬ࠯ࠊࠊ࡫ࡩࠤࡵࡊࡩࡢ࡮ࡲ࡫࠳࡯ࡳࡤࡣࡱࡧࡪࡲࡥࡥࠪࠬ࠾ࠏࠏࠉࡱࡆ࡬ࡥࡱࡵࡧ࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤ࡚ࡘࡌࡠࡲ࡯ࡥࡾ࡫ࡲࠬࠩࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟ࡴࡧࡵ࡭ࡪࡹ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠫࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡍ࠴ࡗ࠰ࡇࡗࡋࡁࡕࡇࡢࡗ࡙ࡘࡅࡂࡏࡖ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡪࡷࡱࡱ࠯ࠊࠊࡵࡨࡶ࡮࡫ࡳࡠࡩࡵࡳࡺࡶࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡢࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡥࡧ࡯ࠤ࡭ࡺ࡭࡭ࠌࠌࡪࡴࡸࠠࡨࡴࡲࡹࡵࠦࡩ࡯ࠢࡶࡩࡷ࡯ࡥࡴࡡࡪࡶࡴࡻࡰࡴ࠼ࠍࠍࠎ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡂ࠱࠺࠼ࠣ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉ࡮࠵ࡸࡣࡹ࡫ࡸࡵࠢࡀࠤࡲ࠹ࡵࡠࡶࡨࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠲ࠧࡨࡴࡲࡹࡵࡃࠢࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧࠪࠌࠌࡨࡪࡲࠠࡴࡧࡵ࡭ࡪࡹ࡟ࡨࡴࡲࡹࡵࡹࠊࠊࡒࡕࡓࡌࡘࡅࡔࡕࡢ࡙ࡕࡊࡁࡕࡇࠫࡴࡉ࡯ࡡ࡭ࡱࡪ࠰࠷࠻ࠬࠨฮ็ฬࠥอไๆๆไหฯࠦวๅอส๊ํ๐ษࠨ࠮ࠪห้๋ไโࠢิๆ๊ࡀ࠭ࠨ࠮ࠪ࠶ࠥ࠵ࠠ࠴ࠩࠬࠎࠎ࡯ࡦࠡࡲࡇ࡭ࡦࡲ࡯ࡨ࠰࡬ࡷࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠮ࠩ࠻ࠌࠌࠍࡵࡊࡩࡢ࡮ࡲ࡫࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࡸࡶࡱࠦ࠽ࠡࡗࡕࡐࡤࡶ࡬ࡢࡻࡨࡶ࠰࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡻࡵࡤࡠࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠬࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡎ࠵ࡘ࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩࠋࠋࡹࡳࡩࡥࡧࡳࡱࡸࡴࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡪࡥ࡭ࠢ࡫ࡸࡲࡲࠊࠊࡨࡲࡶࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡴࠠࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶ࠾ࠏࠏࠉࡨࡴࡲࡹࡵࠦ࠽ࠡࡩࡵࡳࡺࡶ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟࠳ࠬ࠲ࠧ࠰ࠩࠬࠎࠎࠏࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠽࠳࠼࠾ࠥ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡪࡥࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࠋࡰ࠷ࡺࡥࡴࡦࡺࡷࠤࡂࠦ࡭࠴ࡷࡢࡸࡪࡾࡴ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࡫ࡷࡵࡵࡱ࠿ࠥࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧ࠭ࠩࡪࡶࡴࡻࡰ࠾ࠤࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭ࠫࡨࡴࡲࡹࡵ࠱ࠧࠣࠩࠬࠎࠎࡪࡥ࡭ࠢࡹࡳࡩࡥࡧࡳࡱࡸࡴࡸࠐࠉࡑࡔࡒࡋࡗࡋࡓࡔࡡࡘࡔࡉࡇࡔࡆࠪࡳࡈ࡮ࡧ࡬ࡰࡩ࠯࠷࠵࠲ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯࠧ࠭ࠩส่๊๊แࠡำๅ้࠿࠳ࠧ࠭ࠩ࠶ࠤ࠴ࠦ࠳ࠨࠫࠍࠍ࡮࡬ࠠࡱࡆ࡬ࡥࡱࡵࡧ࠯࡫ࡶࡧࡦࡴࡣࡦ࡮ࡨࡨ࠭࠯࠺ࠋࠋࠌࡴࡉ࡯ࡡ࡭ࡱࡪ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠉࡳࡧࡷࡹࡷࡴࠊࠊࡷࡵࡰࠥࡃࠠࡖࡔࡏࡣࡵࡲࡡࡺࡧࡵ࠯ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠩࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡒ࠹ࡕ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠶ࡶࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸࡻࡥࡡࡳࡥ࡫࡭ࡻ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢࡱࡥࡲ࡫ࠬࡢࡴࡦ࡬࡮ࡼࡥࡥࠢ࡬ࡲࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨ࠿ࠐࠉࠊ࡫ࡩࠤࡦࡸࡣࡩ࡫ࡹࡩࡩࡃ࠽ࠨ࠳ࠪ࠾ࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨࡤࡩࡨࡢࡰࡱࡩࡱࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡯ࡣࡰࡩ࠮ࠐࠉࡥࡧ࡯ࠤࡱ࡯ࡶࡦࡡࡤࡶࡨ࡮ࡩࡷࡧࡧࠎࠎࡲࡩࡷࡧࡢࡩࡵ࡭ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡪࡶࡧࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣࡲࡦࡳࡥ࠭ࡧࡳ࡫ࠥ࡯࡮ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩ࠽ࠎࠎࠏࡩࡧࠢࡨࡴ࡬ࠧ࠽ࠨࡰࡸࡰࡱ࠭࠺ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡡ࡮ࡧࠬࠎࠎࡪࡥ࡭ࠢ࡯࡭ࡻ࡫࡟ࡦࡲࡪࠎࠎࠨࠢࠣ䐝")
	l1l11l111ll1_l1_ = l1l11l111ll1_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ䐞"),l11ll1_l1_ (u"ࠩ࡟ࡲࠬ䐟"))
	lines = re.findall(l11ll1_l1_ (u"ࠪࡒࡋࡀࠨ࠯࠭ࡂ࠭ࠨࡋࡘࡕࡋࠪ䐠"),l1l11l111ll1_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠣࡆ࡚ࡗࡍࡓࡌ࠺ࠨ䐡"),re.DOTALL)
	if not lines:
		LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䐢"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡉࡳࡱࡪࡥࡳ࠼ࠪ䐣")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠧࠡࠢࡖࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠬ䐤")+l111l1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࡓࡵࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࡷࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࠩ䐥"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䐦"),l11ll1_l1_ (u"ࠪࠫ䐧"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䐨"),l11ll1_l1_ (u"ࠬืวษูࠣไࡒ࠹ࡕࠡษ็ิ๏ࠦร็ฬࠣว฻็ส่ࠢ็หࠥะ่อัࠣๅ๏ํࠠโ์า๎ํํวหࠢ࠱࠲ࠥออห็ส่ࠥืวษูࠣไࡒ࠹ࡕࠡ฼ํีࠥ฻อ๋ฯࠪ䐩")+l11ll1_l1_ (u"࠭࡜࡯ࠩ䐪")+l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䐫")+l11ll1_l1_ (u"ࠨำสฬ฼ࠦัใ็ࠣࠫ䐬")+str(int(l111l1l1_l1_)+1)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐭"))
		l11l1l1lll_l1_.close()
		return
	l11ll11l11_l1_ = 1024*1024
	l1l11ll1111l_l1_ = 1+len(l1l11l111ll1_l1_)//l11ll11l11_l1_//10
	del l1l11l111ll1_l1_
	l11lll111ll1_l1_ = len(lines)
	l11lll11lll1_l1_ = SPLIT_BIGLIST(lines,l1l11ll1111l_l1_)
	del lines
	for l11ll11111_l1_ in range(l1l11ll1111l_l1_):
		PROGRESS_UPDATE(l11l1l1lll_l1_,35+int(5*l11ll11111_l1_/l1l11ll1111l_l1_),l11ll1_l1_ (u"ࠪฮ็฽ฺ๊ࠢส่๊๊แࠡษ็ีห๐ำ๋ࠩ䐮"),l11ll1_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ䐯"),str(l11ll11111_l1_+1)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䐰")+str(l1l11ll1111l_l1_))
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l1l1111111l1_l1_ = str(l11lll11lll1_l1_[l11ll11111_l1_])
		if kodi_version>18.99: l1l1111111l1_l1_ = l1l1111111l1_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䐱"))
		open(l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠧ࠯࠲࠳ࠫ䐲")+str(l11ll11111_l1_),l11ll1_l1_ (u"ࠨࡹࡥࠫ䐳")).write(l1l1111111l1_l1_)
	del l11lll11lll1_l1_,l1l1111111l1_l1_
	l11lll11l1l1_l1_,l11lllll1ll1_l1_,l1ll1l1l11l1_l1_ = [],[],0
	for l11ll11111_l1_ in range(l1l11ll1111l_l1_):
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l1l1111111l1_l1_ = open(l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠩ࠱࠴࠵࠭䐴")+str(l11ll11111_l1_),l11ll1_l1_ (u"ࠪࡶࡧ࠭䐵")).read()
		time.sleep(1)
		try: os.remove(l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠫ࠳࠶࠰ࠨ䐶")+str(l11ll11111_l1_))
		except: pass
		if kodi_version>18.99: l1l1111111l1_l1_ = l1l1111111l1_l1_.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䐷"))
		lines = EVAL(l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ䐸"),l1l1111111l1_l1_)
		del l1l1111111l1_l1_
		l1ll1l11l11l_l1_,l1ll1l1l11l1_l1_,l11lll11llll_l1_ = READ_ALL_LINES(lines,l1l111ll1l11_l1_,l1l11111l11l_l1_,l11l1l1lll_l1_,l11lll111ll1_l1_,l1ll1l1l11l1_l1_,l11lllllll11_l1_)
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		if not l1ll1l11l11l_l1_:
			l11l1l1lll_l1_.close()
			return
		l11lllll1ll1_l1_ += l1ll1l11l11l_l1_
		l11lll11l1l1_l1_ += l11lll11llll_l1_
	del lines,l1ll1l11l11l_l1_
	l1l11111l1l1_l1_,l11lll11llll_l1_ = CREATE_GROUPED_STREAMS(l11lllll1ll1_l1_,l11l1l1lll_l1_,l111l1l1_l1_)
	if l11l1l1lll_l1_.iscanceled():
		l11l1l1lll_l1_.close()
		return
	l11lll11l1l1_l1_ += l11lll11llll_l1_
	del l11lllll1ll1_l1_,l11lll11llll_l1_
	l1l111lllll1_l1_,l1l111lll11l_l1_,groups,l11lll1ll1ll_l1_,l11llll1ll11_l1_ = {},{},{},0,0
	l11lll1lllll_l1_ = list(l1l11111l1l1_l1_.keys())
	l1l111lll111_l1_ = len(l11lll1lllll_l1_)*3
	import threading
	if 1:
		threads = {}
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			threads[l1l111111lll_l1_] = threading.Thread(target=CREATE_MENUS,args=(l1l111111lll_l1_,))
			threads[l1l111111lll_l1_].start()
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			threads[l1l111111lll_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			CREATE_MENUS(l1l111111lll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	DELETE_FILES(l1lll11l1l1l_l1_,l111l1l1_l1_,False)
	l11lll1lllll_l1_ = list(l1l111lllll1_l1_.keys())
	l11lll111l11_l1_ = 0
	if 1:
		threads = {}
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			threads[l1l111111lll_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1lll11l1l1l_l1_,l1l111111lll_l1_))
			threads[l1l111111lll_l1_].start()
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			threads[l1l111111lll_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l1l111111lll_l1_ in l11lll1lllll_l1_:
			SAVE_MENUS(l1lll11l1l1l_l1_,l1l111111lll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	l11ll11111_l1_ = 0
	l1l11l111111_l1_ = len(l11lll11l1l1_l1_)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠧࡊࡉࡑࡓࡗࡋࡄࠨ䐹"))
	for stream in l11lll11l1l1_l1_:
		if l11ll11111_l1_%27==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,95+int(5*l11ll11111_l1_//l1l11l111111_l1_),l11ll1_l1_ (u"ࠨฬัึ๏์ࠠศๆ่๋๊๊ษࠨ䐺"),l11ll1_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ䐻"),str(l11ll11111_l1_)+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䐼")+str(l1l11l111111_l1_))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࡤ࠭䐽")+l111l1l1_l1_,str(stream),l11ll1_l1_ (u"ࠬ࠭䐾"),PERMANENT_CACHE)
		l11ll11111_l1_ += 1
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊ࡟ࠨ䐿")+l111l1l1_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䑀"),str(l1l11l111111_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟࡟ࠨ䑁")+l111l1l1_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ䑂"),l11ll1_l1_ (u"ࠪ࠵ࠬ䑃"),PERMANENT_CACHE)
	#open(l1lllll1l11l_l1_,l11ll1_l1_ (u"ࠫࡼ࠭䑄")).write(l11ll1_l1_ (u"ࠬ࠭䑅"))
	l11l1l1lll_l1_.close()
	time.sleep(1)
	#l11llll1l111_l1_ = COUNTS(l1lll11l1l1l_l1_,l111l1l1_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䑆"),l11ll1_l1_ (u"ࠧࠨ䑇"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䑈"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䑉")+l11ll1_l1_ (u"ࠪฮ๊ࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭䑊")+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䑋")+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䑌")+l11llll1l111_l1_)
	#xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䑍"))
	DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_)
	return
def CREATE_MENUS(l1l111111lll_l1_):
	global l11l1l1lll_l1_,l1l11111l1l1_l1_,l11lll111l11_l1_,l1l111lllll1_l1_,l1l111lll11l_l1_,groups,l11lll1ll1ll_l1_,l11llll1ll11_l1_,l1l111lll111_l1_
	l1l111lllll1_l1_[l1l111111lll_l1_] = {}
	l11llll11l1l_l1_,l1l1111ll11l_l1_ = {},[]
	l11lll11ll11_l1_ = len(l1l11111l1l1_l1_[l1l111111lll_l1_])
	l1l111lllll1_l1_[l1l111111lll_l1_][l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䑎")] = l11lll11ll11_l1_
	if l11lll11ll11_l1_>0:
		l1l111l11ll1_l1_,l1l11l111l11_l1_,l11lll111111_l1_,l1l11l11111l_l1_,l1l1111l1111_l1_ = zip(*l1l11111l1l1_l1_[l1l111111lll_l1_])
		del l1l11l111l11_l1_,l11lll111111_l1_,l1l11l11111l_l1_
		l11lllll1lll_l1_ = list(set(l1l111l11ll1_l1_))
		for group in l11lllll1lll_l1_:
			l11llll11l1l_l1_[group] = l11ll1_l1_ (u"ࠨࠩ䑏")
			l1l111lllll1_l1_[l1l111111lll_l1_][group] = []
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll1ll11_l1_//l1l111lll111_l1_),l11ll1_l1_ (u"ࠩอู๋๐ูࠡษ็ๆํอฦๆࠩ䑐"),l11ll1_l1_ (u"ࠪห้าายࠢิๆ๊ࡀ࠭ࠨ䑑"),str(l11llll1ll11_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ䑒")+str(l1l111lll111_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11llll1ll11_l1_ += 1
		l11lll1llll1_l1_ = len(l11lllll1lll_l1_)
		del l11lllll1lll_l1_
		l1l1111ll11l_l1_ = list(set(zip(l1l111l11ll1_l1_,l1l1111l1111_l1_)))
		del l1l111l11ll1_l1_,l1l1111l1111_l1_
		for group,l111_l1_ in l1l1111ll11l_l1_:
			if not l11llll11l1l_l1_[group] and l111_l1_: l11llll11l1l_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll1ll11_l1_//l1l111lll111_l1_),l11ll1_l1_ (u"ࠬะี็์฼ࠤฬ๊โ้ษษ้ࠬ䑓"),l11ll1_l1_ (u"࠭วๅฮีลࠥืโๆ࠼࠰ࠫ䑔"),str(l11llll1ll11_l1_)+l11ll1_l1_ (u"ࠧࠡ࠱ࠣࠫ䑕")+str(l1l111lll111_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11llll1ll11_l1_ += 1
		l11lllll111l_l1_ = list(l11llll11l1l_l1_.keys())
		l11lll1lll11_l1_ = list(l11llll11l1l_l1_.values())
		del l11llll11l1l_l1_
		l1l1111ll11l_l1_ = list(zip(l11lllll111l_l1_,l11lll1lll11_l1_))
		del l11lllll111l_l1_,l11lll1lll11_l1_
		l1l1111ll11l_l1_ = sorted(l1l1111ll11l_l1_)
	else: l11llll1ll11_l1_ += 2
	l1l111lllll1_l1_[l1l111111lll_l1_][l11ll1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ䑖")] = l1l1111ll11l_l1_
	del l1l1111ll11l_l1_
	for group,context,title,url,l1lll1_l1_ in l1l11111l1l1_l1_[l1l111111lll_l1_]:
		l1l111lllll1_l1_[l1l111111lll_l1_][group].append((context,title,url,l1lll1_l1_))
	PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll1ll11_l1_//l1l111lll111_l1_),l11ll1_l1_ (u"ࠩอู๋๐ูࠡษ็ๆํอฦๆࠩ䑗"),l11ll1_l1_ (u"ࠪห้าายࠢิๆ๊ࡀ࠭ࠨ䑘"),str(l11llll1ll11_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ䑙")+str(l1l111lll111_l1_))
	if l11l1l1lll_l1_.iscanceled(): return
	l11llll1ll11_l1_ += 1
	del l1l11111l1l1_l1_[l1l111111lll_l1_]
	groups[l1l111111lll_l1_] = list(l1l111lllll1_l1_[l1l111111lll_l1_].keys())
	l1l111lll11l_l1_[l1l111111lll_l1_] = len(groups[l1l111111lll_l1_])
	l11lll1ll1ll_l1_ += l1l111lll11l_l1_[l1l111111lll_l1_]
	return
def SAVE_MENUS(l1lll11l1l1l_l1_,l1l111111lll_l1_):
	global l11l1l1lll_l1_,l1l11111l1l1_l1_,l11lll111l11_l1_,l1l111lllll1_l1_,l1l111lll11l_l1_,groups,l11lll1ll1ll_l1_,l11llll1ll11_l1_,l1l111lll111_l1_
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l1l111111lll_l1_)
	for l1ll1l1l11l1_l1_ in range(1+l1l111lll11l_l1_[l1l111111lll_l1_]//173):
		l11lll1l1lll_l1_ = []
		l1l1111lll1l_l1_ = groups[l1l111111lll_l1_][0:273]
		for group in l1l1111lll1l_l1_:
			l11lll1l1lll_l1_.append(l1l111lllll1_l1_[l1l111111lll_l1_][group])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111111lll_l1_,l1l1111lll1l_l1_,l11lll1l1lll_l1_,PERMANENT_CACHE,True)
		l11lll111l11_l1_ += len(l1l1111lll1l_l1_)
		PROGRESS_UPDATE(l11l1l1lll_l1_,75+int(20*l11lll111l11_l1_//l11lll1ll1ll_l1_),l11ll1_l1_ (u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้ࠬ䑚"),l11ll1_l1_ (u"࠭วๅไสส๊ฯࠠาไ่࠾࠲࠭䑛"),str(l11lll111l11_l1_)+l11ll1_l1_ (u"ࠧࠡ࠱ࠣࠫ䑜")+str(l11lll1ll1ll_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		del groups[l1l111111lll_l1_][0:273]
	del l1l111lllll1_l1_[l1l111111lll_l1_],groups[l1l111111lll_l1_],l1l111lll11l_l1_[l1l111111lll_l1_]
	return
def COUNTS(l1lll11l1l1l_l1_,l111l1l1_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,l1ll_l1_): return
	l1l1111llll1_l1_ = l11ll1_l1_ (u"ࠨ฻าำࠥ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥอไา๊สฬ฼࠭䑝")
	l11llll1l11l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䑞"))
	l1l11111ll1l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䑟"))
	if l111l1l1_l1_:
		l1l1111llll1_l1_ = l11ll1_l1_ (u"ࠫ฾ีฯࠡใํำ๏๎็ศฬࠣีฬฮืࠡࠩ䑠")+text_numbers[int(l111l1l1_l1_)]
		l111l1l1_l1_ = l11ll1_l1_ (u"ࠬࡥࠧ䑡")+l111l1l1_l1_
	l1l11l111111_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ䑢"),l11ll1_l1_ (u"ࠧࡊࡉࡑࡓࡗࡋࡄࠨ䑣")+l111l1l1_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䑤"))
	l1l1111l1l11_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࠭䑥"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䑦")+l111l1l1_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䑧"))
	l11lll11111l_l1_ = READ_FROM_SQL3(l1l11111ll1l_l1_,l11ll1_l1_ (u"ࠬ࡯࡮ࡵࠩ䑨"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭䑩")+l111l1l1_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䑪"))
	l1l111111ll1_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"ࠨ࡫ࡱࡸࠬ䑫"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䑬")+l111l1l1_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䑭"))
	l11llll111ll_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䑮"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䑯")+l111l1l1_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䑰"))
	l1l111l1l111_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ䑱"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䑲")+l111l1l1_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䑳"))
	l1l111llllll_l1_ = READ_FROM_SQL3(l1l11111ll1l_l1_,l11ll1_l1_ (u"ࠪ࡭ࡳࡺࠧ䑴"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䑵")+l111l1l1_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䑶"))
	l11lllll1111_l1_ = READ_FROM_SQL3(l11llll1l11l_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ䑷"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䑸")+l111l1l1_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䑹"))
	groups = READ_FROM_SQL3(l1l11111ll1l_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䑺"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䑻")+l111l1l1_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡇࡓࡑࡘࡔࡘࡥ࡟ࠨ䑼"))
	l11lllllll1l_l1_ = []
	for group,l1lll1_l1_ in groups:
		l11llllll11l_l1_ = group.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䑽"))[1]
		l11lllllll1l_l1_.append(l11llllll11l_l1_)
	l1l11111lll1_l1_ = len(l11lllllll1l_l1_)
	total = int(l1l111l1l111_l1_)+int(l1l111llllll_l1_)+int(l11lllll1111_l1_)+int(l11llll111ll_l1_)+int(l1l111111ll1_l1_)
	l11llll1l111_l1_ = l11ll1_l1_ (u"࠭ࠧ䑾")
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠧใ่๋หฯࡀࠠࠨ䑿")+str(l1l111111ll1_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡลไ่ฬ๋࠺ࠡࠩ䒀")+str(l1l111l1l111_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲู๊ไิๆสฮ࠿ࠦࠧ䒁")+str(l1l11111lll1_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣั้่วห࠼ࠣࠫ䒂")+str(l1l111llllll_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠫࡡࡴโ็๊สฮ๋ࠥฬ่๊็อ࠿ࠦࠧ䒃")+str(l11llll111ll_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥ็๊ะ๊๊หฯࠦๅอ้๋่ฮࡀࠠࠨ䒄")+str(l11lllll1111_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"࠭࡜࡯็ฯ้ํ฿ࠠศๆๅ๊ํอส࠻ࠢࠪ䒅")+str(l1l1111l1l11_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠๆฮ่์฾ࠦวๅใํำ๏๎็ศฬ࠽ࠤࠬ䒆")+str(l11lll11111l_l1_)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ๋ฬๆ๊฼ࠤฬ๊ๅืษไอ࠿ࠦࠧ䒇")+str(total)
	l11llll1l111_l1_ += l11ll1_l1_ (u"ࠩࠣࠤࠥ࠴่ࠠࠡࠢะ๊๎ูࠡษ็้์๋ไส࠼ࠣࠫ䒈")+str(l1l11l111111_l1_)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䒉"),l11ll1_l1_ (u"ࠫࠬ䒊"),l1l1111llll1_l1_,l11llll1l111_l1_)
	l11llll1llll_l1_ = l11llll1l111_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䒋"),l11ll1_l1_ (u"࠭࡜࡯ࠩ䒌"))
	if not l111l1l1_l1_: l111l1l1_l1_ = l11ll1_l1_ (u"ࠧࡂ࡮࡯ࠫ䒍")
	else: l111l1l1_l1_ = l111l1l1_l1_[1]
	LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䒎"),l11ll1_l1_ (u"ࠩ࠱ࠤࠥࠦࡃࡰࡷࡱࡸࡸࠦ࡯ࡧࠢࡐ࠷࡚ࠦࡶࡪࡦࡨࡳࡸࠦࠠࠡࡈࡲࡰࡩ࡫ࡲ࠻ࠢࠪ䒏")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦࡓࡦࡳࡸࡩࡳࡩࡥ࠻ࠢࠪ䒐")+l111l1l1_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ䒑")+l11llll1llll_l1_)
	return l11llll1l111_l1_
def DELETE_FILES(l1lll11l1l1l_l1_,l111l1l1_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䒒"),l11ll1_l1_ (u"࠭ࠧ䒓"),l11ll1_l1_ (u"ࠧࠨ䒔"),l11ll1_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤๅࡓ࠳ࡖࠩ䒕"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡ็ึัࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠢ࠱࠲ࠥ฿ไๆษࠣห๋้ࠠหีอ฻๏฿ࠠโ์ࠣว๏่ࠦใฬࠣห้ีฮ้ๆࠣษ้๏ࠠใษษ้ฮࠦเࡎ࠵ࡘࠤําไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ䒖"))
		if l1ll111ll1_l1_!=1: return
		file = l1l1l1ll1l1l_l1_.replace(l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ䒗"),l11ll1_l1_ (u"ࠫࡤ࠭䒘")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䒙")+l111l1l1_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l1111l1ll1_l1_)
	#except: pass
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"࠭ࠧ䒚"))
	if l111l1l1_l1_:
		l1l11111111l_l1_ = []
		for l11ll11ll_l1_ in l11lllllllll_l1_:
			l1l11111111l_l1_.append(l11ll11ll_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䒛")+l111l1l1_l1_)
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡎࡌࡒࡐࡥࠧ䒜")+l111l1l1_l1_)
	else:
		l1l11111111l_l1_ = l11lllllllll_l1_
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࠨ䒝"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡋࡗࡕࡕࡑࡕࠪ䒞"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡎ࡚ࡅࡎࡕࠪ䒟"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࠬ䒠"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䒡"),l11ll1_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ䒢")+l1lll11l1l1l_l1_)
	for l1l111111lll_l1_ in l1l11111111l_l1_:
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l1l111111lll_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䒣"),l11ll1_l1_ (u"ࠩࠪ䒤"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䒥"),l11ll1_l1_ (u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊่่ࠢๆอสࠡโࡐ࠷࡚࠭䒦"))
	DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_)
	return
def CHECK_TABLES_EXIST(l1lll11l1l1l_l1_=l11ll1_l1_ (u"ࠬ࠭䒧"),l1ll_l1_=True):
	if l1lll11l1l1l_l1_:
		l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll11l1l1l_l1_),l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䒨"))
		dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ䒩"),l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䒪"),l11ll1_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ䒫"))
		if dummy: return True
	else:
		for l1lll11l1l1l_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll11l1l1l_l1_),l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䒬"))
			dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ䒭"),l11ll1_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ䒮"),l11ll1_l1_ (u"࠭࡟ࡠࡆࡘࡑࡒ࡟࡟ࡠࠩ䒯"))
			if dummy: return True
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䒰"),l11ll1_l1_ (u"ࠨࠩ䒱"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䒲"),l11ll1_l1_ (u"ࠪห๋ะࠠษฯสะฮࠦลๅ๋ࠣห้ึ็ศสࠣษ้๏ࠠใษษ้ฮࠦเࡎ࠵ࡘࠤะ๋ࠠหุ฽฻ࠥ฿ไ๊ࠢࠥษ฻อแสࠢิหอ฽ࠠฤ๊ࠣหูะัศๅࠣไࡒ࠹ࡕࠣࠢ࠱࠲ࠥํะ่ࠢส่ึ๎วษูࠣหาะๅศๆࠣฮัี็ศࠢไ๎ࠥอไฦ่อี๋ะࠠฤ๊ࠣฮูะั๋้สࠤ๊์ࠠีำๆอࠥ็๊ะ์๋๋ฬะࠠ࡝ࡰ࡟ࡲࠥษๅศࠢศิฬࠦโๆฬࠣๅ฾๊วࠡสศฺฬ็ษࠡษ็ีฬฮืࠡใศิ๋ࠦร็ฬࠣฬาอฬสࠢ็ะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤํึไไࠢหห้ึ็ศสࠣษ้๏ࠠใษษ้ฮࠦเࡎ࠵ࡘࠤะ๋ࠠหุ฽฻ࠥ฿ไ๊ࠢࠥะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠦ࠳࠭䒳"))
	#SHOW_EMPTY(l111l1_l1_)
	return False
def SEARCH(l1ll11111ll_l1_,l1lll11l1l1l_l1_=l11ll1_l1_ (u"ࠫࠬ䒴"),l1l111111lll_l1_=l11ll1_l1_ (u"ࠬ࠭䒵"),l11llll11lll_l1_=l11ll1_l1_ (u"࠭ࠧ䒶")):
	if not l11llll11lll_l1_: l11llll11lll_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ䒷")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llllll111_l1_ = [l11ll1_l1_ (u"ࠨࠩ䒸"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䒹"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䒺"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䒻"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䒼"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䒽")]
	if not l1l111111lll_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡒࡉࡗࡇࡢࠫ䒾") in options: l1l111111lll_l1_ = l11llllll111_l1_[1]
			elif l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭䒿") in options: l1l111111lll_l1_ = l11llllll111_l1_[2]
			elif l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ䓀") in options: l1l111111lll_l1_ = l11llllll111_l1_[3]
			else: l1l111111lll_l1_ = l11llllll111_l1_[0]
		else:
			l1l1111l1lll_l1_ = [l11ll1_l1_ (u"ࠪห้้ไࠨ䓁"),l11ll1_l1_ (u"ࠫ็์่ศฬࠪ䓂"),l11ll1_l1_ (u"ࠬษแๅษ่ࠫ䓃"),l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠧ䓄"),l11ll1_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ䓅"),l11ll1_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯࠧ䓆")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䓇"), l1l1111l1lll_l1_)
			if choice==-1: return
			l1l111111lll_l1_ = l11llllll111_l1_[choice]
	search = search+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䓈")
	if l1lll11l1l1l_l1_: SEARCH_ONE_FOLDER(search,l1lll11l1l1l_l1_,l1l111111lll_l1_,l11llll11lll_l1_)
	else:
		for l1lll11l1l1l_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1lll11l1l1l_l1_),l1l111111lll_l1_,l11llll11lll_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1ll11111ll_l1_,l1lll11l1l1l_l1_,l1l111111lll_l1_=l11ll1_l1_ (u"ࠫࠬ䓉"),l11llll11lll_l1_=l11ll1_l1_ (u"ࠬ࠭䓊")):
	if not l11llll11lll_l1_: l11llll11lll_l1_ = l11ll1_l1_ (u"࠭࠱ࠨ䓋")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not l1lll11l1l1l_l1_: return
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llllll111_l1_ = [l11ll1_l1_ (u"ࠧࠨ䓌"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䓍"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䓎"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䓏"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䓐"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䓑")]
	if not l1l111111lll_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡑࡏࡖࡆࡡࠪ䓒") in options: l1l111111lll_l1_ = l11llllll111_l1_[1]
			elif l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ䓓") in options: l1l111111lll_l1_ = l11llllll111_l1_[2]
			elif l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭䓔") in options: l1l111111lll_l1_ = l11llllll111_l1_[3]
			else: l1l111111lll_l1_ = l11llllll111_l1_[0]
		else:
			l1l1111l1lll_l1_ = [l11ll1_l1_ (u"ࠩส่่๊ࠧ䓕"),l11ll1_l1_ (u"ࠪๆ๋๎วหࠩ䓖"),l11ll1_l1_ (u"ࠫศ็ไศ็ࠪ䓗"),l11ll1_l1_ (u"๋ࠬำๅี็หฯ࠭䓘"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠨ䓙"),l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ࠭䓚")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䓛"), l1l1111l1lll_l1_)
			if choice==-1: return
			l1l111111lll_l1_ = l11llllll111_l1_[choice]
	l11lll1111ll_l1_ = search.lower()
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ䓜"))
	results = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䓝"),l11ll1_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ䓞"),(l1l111111lll_l1_,l11lll1111ll_l1_))
	if not results:
		l1l111ll11ll_l1_,l11llllll1ll_l1_ = [],[]
		if not l1l111111lll_l1_: l11llll1ll1l_l1_ = [1,2,3,4,5]
		else: l11llll1ll1l_l1_ = [l11llllll111_l1_.index(l1l111111lll_l1_)]
		for l11ll11111_l1_ in l11llll1ll1l_l1_:
			#l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11llllll111_l1_[l11ll11111_l1_])
			if l11ll11111_l1_!=3:
				l1ll1l11l11l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ䓟"),l11llllll111_l1_[l11ll11111_l1_])
				del l1ll1l11l11l_l1_[l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䓠")]
				del l1ll1l11l11l_l1_[l11ll1_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ䓡")]
				del l1ll1l11l11l_l1_[l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ䓢")]
				groups = list(l1ll1l11l11l_l1_.keys())
				for group in groups:
					for context,title,url,l1lll1_l1_ in l1ll1l11l11l_l1_[group]:
						if l11lll1111ll_l1_ in title.lower(): l11llllll1ll_l1_.append((title,url,l1lll1_l1_))
					del l1ll1l11l11l_l1_[group]
				del l1ll1l11l11l_l1_
			else: groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䓣"),l11llllll111_l1_[l11ll11111_l1_],l11ll1_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䓤"))
			for group in groups:
				try: group,l1lll1_l1_ = group
				except: l1lll1_l1_ = l11ll1_l1_ (u"ࠫࠬ䓥")
				if l11lll1111ll_l1_ in group.lower():
					if l11ll11111_l1_!=3: l1l111l11111_l1_ = group
					else:
						l1l111l1111l_l1_,l11lll1111l1_l1_ = group.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䓦"))
						if l11lll1111ll_l1_ in l1l111l1111l_l1_.lower(): l1l111l11111_l1_ = l1l111l1111l_l1_
						else: l1l111l11111_l1_ = l11lll1111l1_l1_
					l1l111ll11ll_l1_.append((group,l1l111l11111_l1_,l11llllll111_l1_[l11ll11111_l1_],l1lll1_l1_))
			del groups
		l1l111ll11ll_l1_ = set(l1l111ll11ll_l1_)
		l11llllll1ll_l1_ = set(l11llllll1ll_l1_)
		l1l111ll11ll_l1_ = sorted(l1l111ll11ll_l1_,reverse=False,key=lambda key: key[1])
		l11llllll1ll_l1_ = sorted(l11llllll1ll_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡓࡆࡃࡕࡇࡍ࠭䓧"),(l1l111111lll_l1_,l11lll1111ll_l1_),(l1l111ll11ll_l1_,l11llllll1ll_l1_),PERMANENT_CACHE)
	else: l1l111ll11ll_l1_,l11llllll1ll_l1_ = results
	groups = len(l1l111ll11ll_l1_)
	l11lll_l1_ = len(l11llllll1ll_l1_)
	l1l1111_l1_ = int(l11llll11lll_l1_)
	s1 = max(0,(l1l1111_l1_-1)*100)
	e1 = max(0,l1l1111_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l111l11111_l1_,l1l111l1llll_l1_,l1lll1_l1_ in l1l111ll11ll_l1_[s1:e1]:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓨"),l111l1_l1_+l1l111l11111_l1_,l1l111l1llll_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠨ࠳ࠪ䓩"),group,l11ll1_l1_ (u"ࠩࠪ䓪"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓫"):l1lll11l1l1l_l1_})
	del l1l111ll11ll_l1_
	for title,url,l1lll1_l1_ in l11llllll1ll_l1_[s2:e2]:
		l1l111l1lll1_l1_ = url.split(l11ll1_l1_ (u"ࠫ࠴࠭䓬"))[-1]
		if l11ll1_l1_ (u"ࠬ࠴ࠧ䓭") in l1l111l1lll1_l1_ and l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䓮") not in l1l111l1lll1_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䓯"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ䓰"),l11ll1_l1_ (u"ࠩࠪ䓱"),l11ll1_l1_ (u"ࠪࠫ䓲"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓳"):l1lll11l1l1l_l1_})
		else: addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ䓴"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䓵"),l11ll1_l1_ (u"ࠧࠨ䓶"),l11ll1_l1_ (u"ࠨࠩ䓷"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓸"):l1lll11l1l1l_l1_})
	del l11llllll1ll_l1_
	PAGINATION(l1lll11l1l1l_l1_,l11llll11lll_l1_,l1l111111lll_l1_,719,groups+l11lll_l1_,search+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䓹"))
	return
def PAGINATION(l1lll11l1l1l_l1_,l11llll11lll_l1_,l1l111111lll_l1_,mode,total,text):
	if not l11llll11lll_l1_: l11llll11lll_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭䓺")
	if l11llll11lll_l1_!=l11ll1_l1_ (u"ࠬ࠷ࠧ䓻"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓼"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭䓽")+str(1),l1l111111lll_l1_,mode,l11ll1_l1_ (u"ࠨࠩ䓾"),str(1),text,l11ll1_l1_ (u"ࠩࠪ䓿"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔀"):l1lll11l1l1l_l1_})
	if not total: total = 0
	l1l1l1ll1_l1_ = int(total/100)+1
	for l1l1111_l1_ in range(2,l1l1l1ll1_l1_):
		l1ll1lll1ll1_l1_ = (l1l1111_l1_%10==0 or int(l11llll11lll_l1_)-4<l1l1111_l1_<int(l11llll11lll_l1_)+4)
		l1ll1lll1l11_l1_ = (l1ll1lll1ll1_l1_ and int(l11llll11lll_l1_)-40<l1l1111_l1_<int(l11llll11lll_l1_)+40)
		if str(l1l1111_l1_)!=l11llll11lll_l1_ and (l1l1111_l1_%100==0 or l1ll1lll1l11_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔁"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ䔂")+str(l1l1111_l1_),l1l111111lll_l1_,mode,l11ll1_l1_ (u"࠭ࠧ䔃"),str(l1l1111_l1_),text,l11ll1_l1_ (u"ࠧࠨ䔄"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔅"):l1lll11l1l1l_l1_})
	if str(l1l1l1ll1_l1_)!=l11llll11lll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔆"),l111l1_l1_+l11ll1_l1_ (u"ࠪวำืࠠึใะอࠥ࠭䔇")+str(l1l1l1ll1_l1_),l1l111111lll_l1_,mode,l11ll1_l1_ (u"ࠫࠬ䔈"),str(l1l1l1ll1_l1_),text,l11ll1_l1_ (u"ࠬ࠭䔉"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔊"):l1lll11l1l1l_l1_})
	return
def GET_DBFILE_NAME(l1lll11l1l1l_l1_,l1l111111lll_l1_):
	#if l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ䔋") in l1l111111lll_l1_ or l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒࠧ䔌") in l1l111111lll_l1_: l1l1ll111l_l1_ = l1l1llll1ll1_l1_
	#else: l1l1ll111l_l1_ = l1l1llll1ll1_l1_
	l1l1ll111l_l1_ = l1l1llll1ll1_l1_.replace(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭䔍"),l11ll1_l1_ (u"ࠪࡣࠬ䔎")+l1lll11l1l1l_l1_)
	return l1l1ll111l_l1_
def l1l111l11l11_l1_(l1lll11l1l1l_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠫࠬ䔏"))
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䔐"),l11ll1_l1_ (u"࠭ࠧ䔑"),l11ll1_l1_ (u"ࠧࠨ䔒"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䔓"),l11ll1_l1_ (u"ࠩ฼้้๐ษࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠡไาࠤฯำสศฮࠣ฽ิฯࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๅสࠣห้๋ไโษอࠤฬ๊ย็ࠢยࠫ䔔"))
	if l1ll111ll1_l1_!=1: return
	l1l111lll1ll_l1_(l1lll11l1l1l_l1_,False)
	counts = [0]
	for seq in range(1,l11llllll1l1_l1_+1):
		l1l111ll1l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䔕")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䔖")+str(seq))
		if l1l111ll1l1l_l1_: CREATE_STREAMS(l1lll11l1l1l_l1_,str(seq))
		counts.append(0)
	for l1l111111lll_l1_ in l11lllllllll_l1_:
		l11llll11ll1_l1_,l11llll1l1l1_l1_,l1l11l1111l1_l1_,l11lllll1l11_l1_,l11llll11l1l_l1_ = 0,{},[],[],[]
		for seq in range(1,l11llllll1l1_l1_+1):
			l1l111l1llll_l1_ = l1l111111lll_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䔗")+str(seq)
			l1l11111l1l1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡤࡪࡥࡷࠫ䔘"),l1l111l1llll_l1_)
			try:
				l1l111llll11_l1_ = l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ䔙")]
				count = l1l11111l1l1_l1_[l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䔚")]
			except:
				l1l111llll11_l1_ = []
				count = l11ll1_l1_ (u"ࠩ࠳ࠫ䔛")
			for tuple in l1l111llll11_l1_:
				group,l111_l1_ = tuple
				l1ll1l11l11l_l1_ = l1l11111l1l1_l1_[group]
				if group not in l11lllll1l11_l1_:
					l11lllll1l11_l1_.append(group)
					l11llll11l1l_l1_.append(tuple)
					l11llll1l1l1_l1_[group] = []
				l11llll1l1l1_l1_[group] += l1ll1l11l11l_l1_
			DELETE_FROM_SQL3(l1l1ll111l_l1_,l1l111l1llll_l1_)
			WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111l1llll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䔜"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11lllll1l11_l1_:
			l1ll1l11l11l_l1_ = list(set(l11llll1l1l1_l1_[group]))
			l11llll11ll1_l1_ += len(l1ll1l11l11l_l1_)
			l1l11l1111l1_l1_.append(l1ll1l11l11l_l1_)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111111lll_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䔝"),str(l11llll11ll1_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111111lll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䔞"),l11llll11l1l_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111111lll_l1_,l11lllll1l11_l1_,l1l11l1111l1_l1_,PERMANENT_CACHE,True)
	l1l1111l11l1_l1_ = False
	for seq in range(1,l11llllll1l1_l1_+1):
		if int(counts[seq])>0:
			l1l111ll1l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ䔟")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䔠")+str(seq))
			WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡎࡌࡒࡐࡥࠧ䔡")+str(seq),l11ll1_l1_ (u"ࠩࡢࡣࡑࡏࡎࡌࡡࡢࠫ䔢"),l1l111ll1l1l_l1_,PERMANENT_CACHE)
			l1l1111l11l1_l1_ = True
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䔣"),l11ll1_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ䔤"),l11ll1_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ䔥"),PERMANENT_CACHE)
	if l1l1111l11l1_l1_:
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䔦"),l11ll1_l1_ (u"ࠧࠨ䔧"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䔨"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䔩")+l11ll1_l1_ (u"ࠪฮ๊ࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭䔪")+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䔫"))
		l1l1111l11ll_l1_(l1lll11l1l1l_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䔬"))
	else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䔭"),l11ll1_l1_ (u"ࠧࠨ䔮"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䔯"),l11ll1_l1_ (u"ࠩไุ้ࠦศิฯหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡ࠰ࠣวาะๅศๆࠣีํอศุࠢใࡑ࠸࡛ࠠศๆอ๎ࠥษๆหࠢฦฺๆะ็ศࠢ็่อืๆศ็ฯࠤ฿๐ัࠡืะ๎าฯࠠ࠯࠰ࠣ฽้๋วࠡล้ࠤ์ึ็ࠡษ็าิ๋ษࠡฬะฮฬาࠠๆ่ๆࠤศ์ࠠหุํๅࠥอไาษห฻ࠥฮๆโีๆࠤ้๊ศา่ส้ัࠦศศีอาิอๅࠡไสส๊ฯࠠแࡏ࠶࡙ࠥอไๆ๊ฯ์ิฯࠠษ้ำหࠥอไษำ้ห๊าࠧ䔰"))
	return
def l1l1111l11ll_l1_(l1lll11l1l1l_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䔱"))
	if not CHECK_TABLES_EXIST(l1lll11l1l1l_l1_,True): return
	for seq in range(1,l11llllll1l1_l1_+1):
		l1l111ll1l1l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ䔲"),l11ll1_l1_ (u"ࠬࡒࡉࡏࡍࡢࠫ䔳")+str(seq),l11ll1_l1_ (u"࠭࡟ࡠࡎࡌࡒࡐࡥ࡟ࠨ䔴"))
		if l1l111ll1l1l_l1_: l11llll1l111_l1_ = COUNTS(l1lll11l1l1l_l1_,str(seq))
	COUNTS(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠧࠨ䔵"))
	return
def l1l111lll1ll_l1_(l1lll11l1l1l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䔶"),l11ll1_l1_ (u"ࠩࠪ䔷"),l11ll1_l1_ (u"ࠪࠫ䔸"),l11ll1_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠแࡏ࠶࡙ࠬ䔹"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฮำ่ฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠥ࠴࠮ࠡ฻็้ฬࠦว็ๅࠣฮุะื๋฻ࠣๅ๏ࠦร๋๋ࠢๆฯࠦวๅัั์้ࠦลๅ๋ࠣๆฬฬๅสࠢใࡑ࠸้࡛ࠠฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ䔺"))
		if l1ll111ll1_l1_!=1: return
	#for seq in range(1,l11llllll1l1_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11ll1_l1_ (u"࠭ࠧ䔻"),False)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll11l1l1l_l1_,l11ll1_l1_ (u"ࠧࠨ䔼"))
	try: os.remove(l1l1ll111l_l1_)
	except: pass
	for seq in range(1,l11llllll1l1_l1_+1):
		filename = l1l1l1ll1l1l_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䔽"),l11ll1_l1_ (u"ࠩࡢࠫ䔾")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䔿")+str(seq))
		l1lll11l1lll_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1lll11l1lll_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䕀"),l11ll1_l1_ (u"ࠬ࠭䕁"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕂"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠอ็ํ฽๋ࠥไโษอࠤๅࡓ࠳ࡖࠩ䕃"))
	return
def DELETE_OLD_MENUS_CACHE(l1lll11l1l1l_l1_):
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊ࠭䕄"),l11ll1_l1_ (u"ࠩࠨࡣࡎࡖࠧ䕅")+l1lll11l1l1l_l1_+l11ll1_l1_ (u"ࠪࡣࠪ࠭䕆"))
	return
COUNTRIES_CODES = {
		 l11ll1_l1_ (u"ࠫࡆࡌࠧ䕇"):l11ll1_l1_ (u"ࠬࡇࡦࡨࡪࡤࡲ࡮ࡹࡴࡢࡰࠪ䕈")
		,l11ll1_l1_ (u"࠭ࡁࡍࠩ䕉"):l11ll1_l1_ (u"ࠧࡂ࡮ࡥࡥࡳ࡯ࡡࠨ䕊")
		,l11ll1_l1_ (u"ࠨࡆ࡝ࠫ䕋"):l11ll1_l1_ (u"ࠩࡄࡰ࡬࡫ࡲࡪࡣࠪ䕌")
		,l11ll1_l1_ (u"ࠪࡅࡘ࠭䕍"):l11ll1_l1_ (u"ࠫࡆࡳࡥࡳ࡫ࡦࡥࡳࠦࡓࡢ࡯ࡲࡥࠬ䕎")
		,l11ll1_l1_ (u"ࠬࡇࡄࠨ䕏"):l11ll1_l1_ (u"࠭ࡁ࡯ࡦࡲࡶࡷࡧࠧ䕐")
		,l11ll1_l1_ (u"ࠧࡂࡑࠪ䕑"):l11ll1_l1_ (u"ࠨࡃࡱ࡫ࡴࡲࡡࠨ䕒")
		,l11ll1_l1_ (u"ࠩࡄࡍࠬ䕓"):l11ll1_l1_ (u"ࠪࡅࡳ࡭ࡵࡪ࡮࡯ࡥࠬ䕔")
		,l11ll1_l1_ (u"ࠫࡆࡗࠧ䕕"):l11ll1_l1_ (u"ࠬࡇ࡮ࡵࡣࡵࡧࡹ࡯ࡣࡢࠩ䕖")
		,l11ll1_l1_ (u"࠭ࡁࡈࠩ䕗"):l11ll1_l1_ (u"ࠧࡂࡰࡷ࡭࡬ࡻࡡࠡࡣࡱࡨࠥࡈࡡࡳࡤࡸࡨࡦ࠭䕘")
		,l11ll1_l1_ (u"ࠨࡃࡕࠫ䕙"):l11ll1_l1_ (u"ࠩࡄࡶ࡬࡫࡮ࡵ࡫ࡱࡥࠬ䕚")
		,l11ll1_l1_ (u"ࠪࡅࡒ࠭䕛"):l11ll1_l1_ (u"ࠫࡆࡸ࡭ࡦࡰ࡬ࡥࠬ䕜")
		,l11ll1_l1_ (u"ࠬࡇࡗࠨ䕝"):l11ll1_l1_ (u"࠭ࡁࡳࡷࡥࡥࠬ䕞")
		,l11ll1_l1_ (u"ࠧࡂࡗࠪ䕟"):l11ll1_l1_ (u"ࠨࡃࡸࡷࡹࡸࡡ࡭࡫ࡤࠫ䕠")
		,l11ll1_l1_ (u"ࠩࡄࡘࠬ䕡"):l11ll1_l1_ (u"ࠪࡅࡺࡹࡴࡳ࡫ࡤࠫ䕢")
		,l11ll1_l1_ (u"ࠫࡆࡠࠧ䕣"):l11ll1_l1_ (u"ࠬࡇࡺࡦࡴࡥࡥ࡮ࡰࡡ࡯ࠩ䕤")
		,l11ll1_l1_ (u"࠭ࡂࡔࠩ䕥"):l11ll1_l1_ (u"ࠧࡃࡣ࡫ࡥࡲࡧࡳࠨ䕦")
		,l11ll1_l1_ (u"ࠨࡄࡋࠫ䕧"):l11ll1_l1_ (u"ࠩࡅࡥ࡭ࡸࡡࡪࡰࠪ䕨")
		,l11ll1_l1_ (u"ࠪࡆࡉ࠭䕩"):l11ll1_l1_ (u"ࠫࡇࡧ࡮ࡨ࡮ࡤࡨࡪࡹࡨࠨ䕪")
		,l11ll1_l1_ (u"ࠬࡈࡂࠨ䕫"):l11ll1_l1_ (u"࠭ࡂࡢࡴࡥࡥࡩࡵࡳࠨ䕬")
		,l11ll1_l1_ (u"ࠧࡃ࡛ࠪ䕭"):l11ll1_l1_ (u"ࠨࡄࡨࡰࡦࡸࡵࡴࠩ䕮")
		,l11ll1_l1_ (u"ࠩࡅࡉࠬ䕯"):l11ll1_l1_ (u"ࠪࡆࡪࡲࡧࡪࡷࡰࠫ䕰")
		,l11ll1_l1_ (u"ࠫࡇࡠࠧ䕱"):l11ll1_l1_ (u"ࠬࡈࡥ࡭࡫ࡽࡩࠬ䕲")
		,l11ll1_l1_ (u"࠭ࡂࡋࠩ䕳"):l11ll1_l1_ (u"ࠧࡃࡧࡱ࡭ࡳ࠭䕴")
		,l11ll1_l1_ (u"ࠨࡄࡐࠫ䕵"):l11ll1_l1_ (u"ࠩࡅࡩࡷࡳࡵࡥࡣࠪ䕶")
		,l11ll1_l1_ (u"ࠪࡆ࡙࠭䕷"):l11ll1_l1_ (u"ࠫࡇ࡮ࡵࡵࡣࡱࠫ䕸")
		,l11ll1_l1_ (u"ࠬࡈࡏࠨ䕹"):l11ll1_l1_ (u"࠭ࡂࡰ࡮࡬ࡺ࡮ࡧࠧ䕺")
		,l11ll1_l1_ (u"ࠧࡃࡓࠪ䕻"):l11ll1_l1_ (u"ࠨࡄࡲࡲࡦ࡯ࡲࡦࠩ䕼")
		,l11ll1_l1_ (u"ࠩࡅࡅࠬ䕽"):l11ll1_l1_ (u"ࠪࡆࡴࡹ࡮ࡪࡣࠣࡥࡳࡪࠠࡉࡧࡵࡾࡪ࡭࡯ࡷ࡫ࡱࡥࠬ䕾")
		,l11ll1_l1_ (u"ࠫࡇ࡝ࠧ䕿"):l11ll1_l1_ (u"ࠬࡈ࡯ࡵࡵࡺࡥࡳࡧࠧ䖀")
		,l11ll1_l1_ (u"࠭ࡂࡗࠩ䖁"):l11ll1_l1_ (u"ࠧࡃࡱࡸࡺࡪࡺࠠࡊࡵ࡯ࡥࡳࡪࠧ䖂")
		,l11ll1_l1_ (u"ࠨࡄࡕࠫ䖃"):l11ll1_l1_ (u"ࠩࡅࡶࡦࢀࡩ࡭ࠩ䖄")
		,l11ll1_l1_ (u"ࠪࡍࡔ࠭䖅"):l11ll1_l1_ (u"ࠫࡇࡸࡩࡵ࡫ࡶ࡬ࠥࡏ࡮ࡥ࡫ࡤࡲࠥࡕࡣࡦࡣࡱࠤ࡙࡫ࡲࡳ࡫ࡷࡳࡷࡿࠧ䖆")
		,l11ll1_l1_ (u"ࠬ࡜ࡇࠨ䖇"):l11ll1_l1_ (u"࠭ࡂࡳ࡫ࡷ࡭ࡸ࡮ࠠࡗ࡫ࡵ࡫࡮ࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ䖈")
		,l11ll1_l1_ (u"ࠧࡃࡐࠪ䖉"):l11ll1_l1_ (u"ࠨࡄࡵࡹࡳ࡫ࡩࠨ䖊")
		,l11ll1_l1_ (u"ࠩࡅࡋࠬ䖋"):l11ll1_l1_ (u"ࠪࡆࡺࡲࡧࡢࡴ࡬ࡥࠬ䖌")
		,l11ll1_l1_ (u"ࠫࡇࡌࠧ䖍"):l11ll1_l1_ (u"ࠬࡈࡵࡳ࡭࡬ࡲࡦࠦࡆࡢࡵࡲࠫ䖎")
		,l11ll1_l1_ (u"࠭ࡂࡊࠩ䖏"):l11ll1_l1_ (u"ࠧࡃࡷࡵࡹࡳࡪࡩࠨ䖐")
		,l11ll1_l1_ (u"ࠨࡍࡋࠫ䖑"):l11ll1_l1_ (u"ࠩࡆࡥࡲࡨ࡯ࡥ࡫ࡤࠫ䖒")
		,l11ll1_l1_ (u"ࠪࡇࡒ࠭䖓"):l11ll1_l1_ (u"ࠫࡈࡧ࡭ࡦࡴࡲࡳࡳ࠭䖔")
		,l11ll1_l1_ (u"ࠬࡉࡁࠨ䖕"):l11ll1_l1_ (u"࠭ࡃࡢࡰࡤࡨࡦ࠭䖖")
		,l11ll1_l1_ (u"ࠧࡄࡘࠪ䖗"):l11ll1_l1_ (u"ࠨࡅࡤࡴࡪࠦࡖࡦࡴࡧࡩࠬ䖘")
		,l11ll1_l1_ (u"ࠩࡎ࡝ࠬ䖙"):l11ll1_l1_ (u"ࠪࡇࡦࡿ࡭ࡢࡰࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䖚")
		,l11ll1_l1_ (u"ࠫࡈࡌࠧ䖛"):l11ll1_l1_ (u"ࠬࡉࡥ࡯ࡶࡵࡥࡱࠦࡁࡧࡴ࡬ࡧࡦࡴࠠࡓࡧࡳࡹࡧࡲࡩࡤࠩ䖜")
		,l11ll1_l1_ (u"࠭ࡔࡅࠩ䖝"):l11ll1_l1_ (u"ࠧࡄࡪࡤࡨࠬ䖞")
		,l11ll1_l1_ (u"ࠨࡅࡏࠫ䖟"):l11ll1_l1_ (u"ࠩࡆ࡬࡮ࡲࡥࠨ䖠")
		,l11ll1_l1_ (u"ࠪࡇࡓ࠭䖡"):l11ll1_l1_ (u"ࠫࡈ࡮ࡩ࡯ࡣࠪ䖢")
		,l11ll1_l1_ (u"ࠬࡉࡘࠨ䖣"):l11ll1_l1_ (u"࠭ࡃࡩࡴ࡬ࡷࡹࡳࡡࡴࠢࡌࡷࡱࡧ࡮ࡥࠩ䖤")
		,l11ll1_l1_ (u"ࠧࡄࡅࠪ䖥"):l11ll1_l1_ (u"ࠨࡅࡲࡧࡴࡹࠠࠩࡍࡨࡩࡱ࡯࡮ࡨࠫࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䖦")
		,l11ll1_l1_ (u"ࠩࡆࡓࠬ䖧"):l11ll1_l1_ (u"ࠪࡇࡴࡲ࡯࡮ࡤ࡬ࡥࠬ䖨")
		,l11ll1_l1_ (u"ࠫࡐࡓࠧ䖩"):l11ll1_l1_ (u"ࠬࡉ࡯࡮ࡱࡵࡳࡸ࠭䖪")
		,l11ll1_l1_ (u"࠭ࡃࡌࠩ䖫"):l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䖬")
		,l11ll1_l1_ (u"ࠨࡅࡕࠫ䖭"):l11ll1_l1_ (u"ࠩࡆࡳࡸࡺࡡࠡࡔ࡬ࡧࡦ࠭䖮")
		,l11ll1_l1_ (u"ࠪࡌࡗ࠭䖯"):l11ll1_l1_ (u"ࠫࡈࡸ࡯ࡢࡶ࡬ࡥࠬ䖰")
		,l11ll1_l1_ (u"ࠬࡉࡕࠨ䖱"):l11ll1_l1_ (u"࠭ࡃࡶࡤࡤࠫ䖲")
		,l11ll1_l1_ (u"ࠧࡄ࡙ࠪ䖳"):l11ll1_l1_ (u"ࠨࡅࡸࡶࡦࡩࡡࡰࠩ䖴")
		,l11ll1_l1_ (u"ࠩࡆ࡝ࠬ䖵"):l11ll1_l1_ (u"ࠪࡇࡾࡶࡲࡶࡵࠪ䖶")
		,l11ll1_l1_ (u"ࠫࡈࡠࠧ䖷"):l11ll1_l1_ (u"ࠬࡉࡺࡦࡥ࡫ࠤࡗ࡫ࡰࡶࡤ࡯࡭ࡨ࠭䖸")
		,l11ll1_l1_ (u"࠭ࡃࡅࠩ䖹"):l11ll1_l1_ (u"ࠧࡅࡧࡰࡳࡨࡸࡡࡵ࡫ࡦࠤࡗ࡫ࡰࡶࡤ࡯࡭ࡨࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡃࡰࡰࡪࡳࠬ䖺")
		,l11ll1_l1_ (u"ࠨࡆࡎࠫ䖻"):l11ll1_l1_ (u"ࠩࡇࡩࡳࡳࡡࡳ࡭ࠪ䖼")
		,l11ll1_l1_ (u"ࠪࡈࡏ࠭䖽"):l11ll1_l1_ (u"ࠫࡉࡰࡩࡣࡱࡸࡸ࡮࠭䖾")
		,l11ll1_l1_ (u"ࠬࡊࡍࠨ䖿"):l11ll1_l1_ (u"࠭ࡄࡰ࡯࡬ࡲ࡮ࡩࡡࠨ䗀")
		,l11ll1_l1_ (u"ࠧࡅࡑࠪ䗁"):l11ll1_l1_ (u"ࠨࡆࡲࡱ࡮ࡴࡩࡤࡣࡱࠤࡗ࡫ࡰࡶࡤ࡯࡭ࡨ࠭䗂")
		,l11ll1_l1_ (u"ࠩࡗࡐࠬ䗃"):l11ll1_l1_ (u"ࠪࡉࡦࡹࡴࠡࡖ࡬ࡱࡴࡸࠧ䗄")
		,l11ll1_l1_ (u"ࠫࡊࡉࠧ䗅"):l11ll1_l1_ (u"ࠬࡋࡣࡶࡣࡧࡳࡷ࠭䗆")
		,l11ll1_l1_ (u"࠭ࡅࡈࠩ䗇"):l11ll1_l1_ (u"ࠧࡆࡩࡼࡴࡹ࠭䗈")
		,l11ll1_l1_ (u"ࠨࡕ࡙ࠫ䗉"):l11ll1_l1_ (u"ࠩࡈࡰ࡙ࠥࡡ࡭ࡸࡤࡨࡴࡸࠧ䗊")
		,l11ll1_l1_ (u"ࠪࡋࡖ࠭䗋"):l11ll1_l1_ (u"ࠫࡊࡷࡵࡢࡶࡲࡶ࡮ࡧ࡬ࠡࡉࡸ࡭ࡳ࡫ࡡࠨ䗌")
		,l11ll1_l1_ (u"ࠬࡋࡒࠨ䗍"):l11ll1_l1_ (u"࠭ࡅࡳ࡫ࡷࡶࡪࡧࠧ䗎")
		,l11ll1_l1_ (u"ࠧࡆࡇࠪ䗏"):l11ll1_l1_ (u"ࠨࡇࡶࡸࡴࡴࡩࡢࠩ䗐")
		,l11ll1_l1_ (u"ࠩࡈࡘࠬ䗑"):l11ll1_l1_ (u"ࠪࡉࡹ࡮ࡩࡰࡲ࡬ࡥࠬ䗒")
		,l11ll1_l1_ (u"ࠫࡋࡑࠧ䗓"):l11ll1_l1_ (u"ࠬࡌࡡ࡭࡭࡯ࡥࡳࡪࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ䗔")
		,l11ll1_l1_ (u"࠭ࡆࡐࠩ䗕"):l11ll1_l1_ (u"ࠧࡇࡣࡵࡳࡪࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䗖")
		,l11ll1_l1_ (u"ࠨࡈࡍࠫ䗗"):l11ll1_l1_ (u"ࠩࡉ࡭࡯࡯ࠧ䗘")
		,l11ll1_l1_ (u"ࠪࡊࡎ࠭䗙"):l11ll1_l1_ (u"ࠫࡋ࡯࡮࡭ࡣࡱࡨࠬ䗚")
		,l11ll1_l1_ (u"ࠬࡌࡒࠨ䗛"):l11ll1_l1_ (u"࠭ࡆࡳࡣࡱࡧࡪ࠭䗜")
		,l11ll1_l1_ (u"ࠧࡈࡈࠪ䗝"):l11ll1_l1_ (u"ࠨࡈࡵࡩࡳࡩࡨࠡࡉࡸ࡭ࡦࡴࡡࠨ䗞")
		,l11ll1_l1_ (u"ࠩࡓࡊࠬ䗟"):l11ll1_l1_ (u"ࠪࡊࡷ࡫࡮ࡤࡪࠣࡔࡴࡲࡹ࡯ࡧࡶ࡭ࡦ࠭䗠")
		,l11ll1_l1_ (u"࡙ࠫࡌࠧ䗡"):l11ll1_l1_ (u"ࠬࡌࡲࡦࡰࡦ࡬࡙ࠥ࡯ࡶࡶ࡫ࡩࡷࡴࠠࡕࡧࡵࡶ࡮ࡺ࡯ࡳ࡫ࡨࡷࠬ䗢")
		,l11ll1_l1_ (u"࠭ࡇࡂࠩ䗣"):l11ll1_l1_ (u"ࠧࡈࡣࡥࡳࡳ࠭䗤")
		,l11ll1_l1_ (u"ࠨࡉࡐࠫ䗥"):l11ll1_l1_ (u"ࠩࡊࡥࡲࡨࡩࡢࠩ䗦")
		,l11ll1_l1_ (u"ࠪࡋࡊ࠭䗧"):l11ll1_l1_ (u"ࠫࡌ࡫࡯ࡳࡩ࡬ࡥࠬ䗨")
		,l11ll1_l1_ (u"ࠬࡊࡅࠨ䗩"):l11ll1_l1_ (u"࠭ࡇࡦࡴࡰࡥࡳࡿࠧ䗪")
		,l11ll1_l1_ (u"ࠧࡈࡊࠪ䗫"):l11ll1_l1_ (u"ࠨࡉ࡫ࡥࡳࡧࠧ䗬")
		,l11ll1_l1_ (u"ࠩࡊࡍࠬ䗭"):l11ll1_l1_ (u"ࠪࡋ࡮ࡨࡲࡢ࡮ࡷࡥࡷ࠭䗮")
		,l11ll1_l1_ (u"ࠫࡌࡘࠧ䗯"):l11ll1_l1_ (u"ࠬࡍࡲࡦࡧࡦࡩࠬ䗰")
		,l11ll1_l1_ (u"࠭ࡇࡍࠩ䗱"):l11ll1_l1_ (u"ࠧࡈࡴࡨࡩࡳࡲࡡ࡯ࡦࠪ䗲")
		,l11ll1_l1_ (u"ࠨࡉࡇࠫ䗳"):l11ll1_l1_ (u"ࠩࡊࡶࡪࡴࡡࡥࡣࠪ䗴")
		,l11ll1_l1_ (u"ࠪࡋࡕ࠭䗵"):l11ll1_l1_ (u"ࠫࡌࡻࡡࡥࡧ࡯ࡳࡺࡶࡥࠨ䗶")
		,l11ll1_l1_ (u"ࠬࡍࡕࠨ䗷"):l11ll1_l1_ (u"࠭ࡇࡶࡣࡰࠫ䗸")
		,l11ll1_l1_ (u"ࠧࡈࡖࠪ䗹"):l11ll1_l1_ (u"ࠨࡉࡸࡥࡹ࡫࡭ࡢ࡮ࡤࠫ䗺")
		,l11ll1_l1_ (u"ࠩࡊࡋࠬ䗻"):l11ll1_l1_ (u"ࠪࡋࡺ࡫ࡲ࡯ࡵࡨࡽࠬ䗼")
		,l11ll1_l1_ (u"ࠫࡌࡔࠧ䗽"):l11ll1_l1_ (u"ࠬࡍࡵࡪࡰࡨࡥࠬ䗾")
		,l11ll1_l1_ (u"࠭ࡇࡘࠩ䗿"):l11ll1_l1_ (u"ࠧࡈࡷ࡬ࡲࡪࡧ࠭ࡃ࡫ࡶࡷࡦࡻࠧ䘀")
		,l11ll1_l1_ (u"ࠨࡉ࡜ࠫ䘁"):l11ll1_l1_ (u"ࠩࡊࡹࡾࡧ࡮ࡢࠩ䘂")
		,l11ll1_l1_ (u"ࠪࡌ࡙࠭䘃"):l11ll1_l1_ (u"ࠫࡍࡧࡩࡵ࡫ࠪ䘄")
		,l11ll1_l1_ (u"ࠬࡎࡍࠨ䘅"):l11ll1_l1_ (u"࠭ࡈࡦࡣࡵࡨࠥࡏࡳ࡭ࡣࡱࡨࠥࡧ࡮ࡥࠢࡐࡧࡉࡵ࡮ࡢ࡮ࡧࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䘆")
		,l11ll1_l1_ (u"ࠧࡉࡐࠪ䘇"):l11ll1_l1_ (u"ࠨࡊࡲࡲࡩࡻࡲࡢࡵࠪ䘈")
		,l11ll1_l1_ (u"ࠩࡋࡏࠬ䘉"):l11ll1_l1_ (u"ࠪࡌࡴࡴࡧࠡࡍࡲࡲ࡬࠭䘊")
		,l11ll1_l1_ (u"ࠫࡍ࡛ࠧ䘋"):l11ll1_l1_ (u"ࠬࡎࡵ࡯ࡩࡤࡶࡾ࠭䘌")
		,l11ll1_l1_ (u"࠭ࡉࡔࠩ䘍"):l11ll1_l1_ (u"ࠧࡊࡥࡨࡰࡦࡴࡤࠨ䘎")
		,l11ll1_l1_ (u"ࠨࡋࡑࠫ䘏"):l11ll1_l1_ (u"ࠩࡌࡲࡩ࡯ࡡࠨ䘐")
		,l11ll1_l1_ (u"ࠪࡍࡉ࠭䘑"):l11ll1_l1_ (u"ࠫࡎࡴࡤࡰࡰࡨࡷ࡮ࡧࠧ䘒")
		,l11ll1_l1_ (u"ࠬࡏࡒࠨ䘓"):l11ll1_l1_ (u"࠭ࡉࡳࡣࡱࠫ䘔")
		,l11ll1_l1_ (u"ࠧࡊࡓࠪ䘕"):l11ll1_l1_ (u"ࠨࡋࡵࡥࡶ࠭䘖")
		,l11ll1_l1_ (u"ࠩࡌࡉࠬ䘗"):l11ll1_l1_ (u"ࠪࡍࡷ࡫࡬ࡢࡰࡧࠫ䘘")
		,l11ll1_l1_ (u"ࠫࡎࡓࠧ䘙"):l11ll1_l1_ (u"ࠬࡏࡳ࡭ࡧࠣࡳ࡫ࠦࡍࡢࡰࠪ䘚")
		,l11ll1_l1_ (u"࠭ࡉࡍࠩ䘛"):l11ll1_l1_ (u"ࠧࡊࡵࡵࡥࡪࡲࠧ䘜")
		,l11ll1_l1_ (u"ࠨࡋࡗࠫ䘝"):l11ll1_l1_ (u"ࠩࡌࡸࡦࡲࡹࠨ䘞")
		,l11ll1_l1_ (u"ࠪࡇࡎ࠭䘟"):l11ll1_l1_ (u"ࠫࡎࡼ࡯ࡳࡻࠣࡇࡴࡧࡳࡵࠩ䘠")
		,l11ll1_l1_ (u"ࠬࡐࡍࠨ䘡"):l11ll1_l1_ (u"࠭ࡊࡢ࡯ࡤ࡭ࡨࡧࠧ䘢")
		,l11ll1_l1_ (u"ࠧࡋࡒࠪ䘣"):l11ll1_l1_ (u"ࠨࡌࡤࡴࡦࡴࠧ䘤")
		,l11ll1_l1_ (u"ࠩࡍࡉࠬ䘥"):l11ll1_l1_ (u"ࠪࡎࡪࡸࡳࡦࡻࠪ䘦")
		,l11ll1_l1_ (u"ࠫࡏࡕࠧ䘧"):l11ll1_l1_ (u"ࠬࡐ࡯ࡳࡦࡤࡲࠬ䘨")
		,l11ll1_l1_ (u"࠭ࡋ࡛ࠩ䘩"):l11ll1_l1_ (u"ࠧࡌࡣࡽࡥࡰ࡮ࡳࡵࡣࡱࠫ䘪")
		,l11ll1_l1_ (u"ࠨࡍࡈࠫ䘫"):l11ll1_l1_ (u"ࠩࡎࡩࡳࡿࡡࠨ䘬")
		,l11ll1_l1_ (u"ࠪࡏࡎ࠭䘭"):l11ll1_l1_ (u"ࠫࡐ࡯ࡲࡪࡤࡤࡸ࡮࠭䘮")
		,l11ll1_l1_ (u"ࠬ࡞ࡋࠨ䘯"):l11ll1_l1_ (u"࠭ࡋࡰࡵࡲࡺࡴ࠭䘰")
		,l11ll1_l1_ (u"ࠧࡌ࡙ࠪ䘱"):l11ll1_l1_ (u"ࠨࡍࡸࡻࡦ࡯ࡴࠨ䘲")
		,l11ll1_l1_ (u"ࠩࡎࡋࠬ䘳"):l11ll1_l1_ (u"ࠪࡏࡾࡸࡧࡺࡼࡶࡸࡦࡴࠧ䘴")
		,l11ll1_l1_ (u"ࠫࡑࡇࠧ䘵"):l11ll1_l1_ (u"ࠬࡒࡡࡰࡵࠪ䘶")
		,l11ll1_l1_ (u"࠭ࡌࡗࠩ䘷"):l11ll1_l1_ (u"ࠧࡍࡣࡷࡺ࡮ࡧࠧ䘸")
		,l11ll1_l1_ (u"ࠨࡎࡅࠫ䘹"):l11ll1_l1_ (u"ࠩࡏࡩࡧࡧ࡮ࡰࡰࠪ䘺")
		,l11ll1_l1_ (u"ࠪࡐࡘ࠭䘻"):l11ll1_l1_ (u"ࠫࡑ࡫ࡳࡰࡶ࡫ࡳࠬ䘼")
		,l11ll1_l1_ (u"ࠬࡒࡒࠨ䘽"):l11ll1_l1_ (u"࠭ࡌࡪࡤࡨࡶ࡮ࡧࠧ䘾")
		,l11ll1_l1_ (u"ࠧࡍ࡛ࠪ䘿"):l11ll1_l1_ (u"ࠨࡎ࡬ࡦࡾࡧࠧ䙀")
		,l11ll1_l1_ (u"ࠩࡏࡍࠬ䙁"):l11ll1_l1_ (u"ࠪࡐ࡮࡫ࡣࡩࡶࡨࡲࡸࡺࡥࡪࡰࠪ䙂")
		,l11ll1_l1_ (u"ࠫࡑ࡚ࠧ䙃"):l11ll1_l1_ (u"ࠬࡒࡩࡵࡪࡸࡥࡳ࡯ࡡࠨ䙄")
		,l11ll1_l1_ (u"࠭ࡌࡖࠩ䙅"):l11ll1_l1_ (u"ࠧࡍࡷࡻࡩࡲࡨ࡯ࡶࡴࡪࠫ䙆")
		,l11ll1_l1_ (u"ࠨࡏࡒࠫ䙇"):l11ll1_l1_ (u"ࠩࡐࡥࡨࡧ࡯ࠨ䙈")
		,l11ll1_l1_ (u"ࠪࡑࡌ࠭䙉"):l11ll1_l1_ (u"ࠫࡒࡧࡤࡢࡩࡤࡷࡨࡧࡲࠨ䙊")
		,l11ll1_l1_ (u"ࠬࡓࡗࠨ䙋"):l11ll1_l1_ (u"࠭ࡍࡢ࡮ࡤࡻ࡮࠭䙌")
		,l11ll1_l1_ (u"ࠧࡎ࡛ࠪ䙍"):l11ll1_l1_ (u"ࠨࡏࡤࡰࡦࡿࡳࡪࡣࠪ䙎")
		,l11ll1_l1_ (u"ࠩࡐ࡚ࠬ䙏"):l11ll1_l1_ (u"ࠪࡑࡦࡲࡤࡪࡸࡨࡷࠬ䙐")
		,l11ll1_l1_ (u"ࠫࡒࡒࠧ䙑"):l11ll1_l1_ (u"ࠬࡓࡡ࡭࡫ࠪ䙒")
		,l11ll1_l1_ (u"࠭ࡍࡕࠩ䙓"):l11ll1_l1_ (u"ࠧࡎࡣ࡯ࡸࡦ࠭䙔")
		,l11ll1_l1_ (u"ࠨࡏࡋࠫ䙕"):l11ll1_l1_ (u"ࠩࡐࡥࡷࡹࡨࡢ࡮࡯ࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䙖")
		,l11ll1_l1_ (u"ࠪࡑࡖ࠭䙗"):l11ll1_l1_ (u"ࠫࡒࡧࡲࡵ࡫ࡱ࡭ࡶࡻࡥࠨ䙘")
		,l11ll1_l1_ (u"ࠬࡓࡒࠨ䙙"):l11ll1_l1_ (u"࠭ࡍࡢࡷࡵ࡭ࡹࡧ࡮ࡪࡣࠪ䙚")
		,l11ll1_l1_ (u"ࠧࡎࡗࠪ䙛"):l11ll1_l1_ (u"ࠨࡏࡤࡹࡷ࡯ࡴࡪࡷࡶࠫ䙜")
		,l11ll1_l1_ (u"ࠩ࡜ࡘࠬ䙝"):l11ll1_l1_ (u"ࠪࡑࡦࡿ࡯ࡵࡶࡨࠫ䙞")
		,l11ll1_l1_ (u"ࠫࡒ࡞ࠧ䙟"):l11ll1_l1_ (u"ࠬࡓࡥࡹ࡫ࡦࡳࠬ䙠")
		,l11ll1_l1_ (u"࠭ࡆࡎࠩ䙡"):l11ll1_l1_ (u"ࠧࡎ࡫ࡦࡶࡴࡴࡥࡴ࡫ࡤࠫ䙢")
		,l11ll1_l1_ (u"ࠨࡏࡇࠫ䙣"):l11ll1_l1_ (u"ࠩࡐࡳࡱࡪ࡯ࡷࡣࠪ䙤")
		,l11ll1_l1_ (u"ࠪࡑࡈ࠭䙥"):l11ll1_l1_ (u"ࠫࡒࡵ࡮ࡢࡥࡲࠫ䙦")
		,l11ll1_l1_ (u"ࠬࡓࡎࠨ䙧"):l11ll1_l1_ (u"࠭ࡍࡰࡰࡪࡳࡱ࡯ࡡࠨ䙨")
		,l11ll1_l1_ (u"ࠧࡎࡇࠪ䙩"):l11ll1_l1_ (u"ࠨࡏࡲࡲࡹ࡫࡮ࡦࡩࡵࡳࠬ䙪")
		,l11ll1_l1_ (u"ࠩࡐࡗࠬ䙫"):l11ll1_l1_ (u"ࠪࡑࡴࡴࡴࡴࡧࡵࡶࡦࡺࠧ䙬")
		,l11ll1_l1_ (u"ࠫࡒࡇࠧ䙭"):l11ll1_l1_ (u"ࠬࡓ࡯ࡳࡱࡦࡧࡴ࠭䙮")
		,l11ll1_l1_ (u"࠭ࡍ࡛ࠩ䙯"):l11ll1_l1_ (u"ࠧࡎࡱࡽࡥࡲࡨࡩࡲࡷࡨࠫ䙰")
		,l11ll1_l1_ (u"ࠨࡏࡐࠫ䙱"):l11ll1_l1_ (u"ࠩࡐࡽࡦࡴ࡭ࡢࡴࠣࠬࡇࡻࡲ࡮ࡣࠬࠫ䙲")
		,l11ll1_l1_ (u"ࠪࡒࡆ࠭䙳"):l11ll1_l1_ (u"ࠫࡓࡧ࡭ࡪࡤ࡬ࡥࠬ䙴")
		,l11ll1_l1_ (u"ࠬࡔࡒࠨ䙵"):l11ll1_l1_ (u"࠭ࡎࡢࡷࡵࡹࠬ䙶")
		,l11ll1_l1_ (u"ࠧࡏࡒࠪ䙷"):l11ll1_l1_ (u"ࠨࡐࡨࡴࡦࡲࠧ䙸")
		,l11ll1_l1_ (u"ࠩࡑࡐࠬ䙹"):l11ll1_l1_ (u"ࠪࡒࡪࡺࡨࡦࡴ࡯ࡥࡳࡪࡳࠨ䙺")
		,l11ll1_l1_ (u"ࠫࡓࡉࠧ䙻"):l11ll1_l1_ (u"ࠬࡔࡥࡸࠢࡆࡥࡱ࡫ࡤࡰࡰ࡬ࡥࠬ䙼")
		,l11ll1_l1_ (u"࠭ࡎ࡛ࠩ䙽"):l11ll1_l1_ (u"ࠧࡏࡧࡺࠤ࡟࡫ࡡ࡭ࡣࡱࡨࠬ䙾")
		,l11ll1_l1_ (u"ࠨࡐࡌࠫ䙿"):l11ll1_l1_ (u"ࠩࡑ࡭ࡨࡧࡲࡢࡩࡸࡥࠬ䚀")
		,l11ll1_l1_ (u"ࠪࡒࡊ࠭䚁"):l11ll1_l1_ (u"ࠫࡓ࡯ࡧࡦࡴࠪ䚂")
		,l11ll1_l1_ (u"ࠬࡔࡇࠨ䚃"):l11ll1_l1_ (u"࠭ࡎࡪࡩࡨࡶ࡮ࡧࠧ䚄")
		,l11ll1_l1_ (u"ࠧࡏࡗࠪ䚅"):l11ll1_l1_ (u"ࠨࡐ࡬ࡹࡪ࠭䚆")
		,l11ll1_l1_ (u"ࠩࡑࡊࠬ䚇"):l11ll1_l1_ (u"ࠪࡒࡴࡸࡦࡰ࡮࡮ࠤࡎࡹ࡬ࡢࡰࡧࠫ䚈")
		,l11ll1_l1_ (u"ࠫࡐࡖࠧ䚉"):l11ll1_l1_ (u"ࠬࡔ࡯ࡳࡶ࡫ࠤࡐࡵࡲࡦࡣࠪ䚊")
		,l11ll1_l1_ (u"࠭ࡍࡌࠩ䚋"):l11ll1_l1_ (u"ࠧࡏࡱࡵࡸ࡭ࠦࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ䚌")
		,l11ll1_l1_ (u"ࠨࡏࡓࠫ䚍"):l11ll1_l1_ (u"ࠩࡑࡳࡷࡺࡨࡦࡴࡱࠤࡒࡧࡲࡪࡣࡱࡥࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䚎")
		,l11ll1_l1_ (u"ࠪࡒࡔ࠭䚏"):l11ll1_l1_ (u"ࠫࡓࡵࡲࡸࡣࡼࠫ䚐")
		,l11ll1_l1_ (u"ࠬࡕࡍࠨ䚑"):l11ll1_l1_ (u"࠭ࡏ࡮ࡣࡱࠫ䚒")
		,l11ll1_l1_ (u"ࠧࡑࡍࠪ䚓"):l11ll1_l1_ (u"ࠨࡒࡤ࡯࡮ࡹࡴࡢࡰࠪ䚔")
		,l11ll1_l1_ (u"ࠩࡓ࡛ࠬ䚕"):l11ll1_l1_ (u"ࠪࡔࡦࡲࡡࡶࠩ䚖")
		,l11ll1_l1_ (u"ࠫࡕ࡙ࠧ䚗"):l11ll1_l1_ (u"ࠬࡖࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨ䚘")
		,l11ll1_l1_ (u"࠭ࡐࡂࠩ䚙"):l11ll1_l1_ (u"ࠧࡑࡣࡱࡥࡲࡧࠧ䚚")
		,l11ll1_l1_ (u"ࠨࡒࡊࠫ䚛"):l11ll1_l1_ (u"ࠩࡓࡥࡵࡻࡡࠡࡐࡨࡻࠥࡍࡵࡪࡰࡨࡥࠬ䚜")
		,l11ll1_l1_ (u"ࠪࡔ࡞࠭䚝"):l11ll1_l1_ (u"ࠫࡕࡧࡲࡢࡩࡸࡥࡾ࠭䚞")
		,l11ll1_l1_ (u"ࠬࡖࡅࠨ䚟"):l11ll1_l1_ (u"࠭ࡐࡦࡴࡸࠫ䚠")
		,l11ll1_l1_ (u"ࠧࡑࡊࠪ䚡"):l11ll1_l1_ (u"ࠨࡒ࡫࡭ࡱ࡯ࡰࡱ࡫ࡱࡩࡸ࠭䚢")
		,l11ll1_l1_ (u"ࠩࡓࡒࠬ䚣"):l11ll1_l1_ (u"ࠪࡔ࡮ࡺࡣࡢ࡫ࡵࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䚤")
		,l11ll1_l1_ (u"ࠫࡕࡒࠧ䚥"):l11ll1_l1_ (u"ࠬࡖ࡯࡭ࡣࡱࡨࠬ䚦")
		,l11ll1_l1_ (u"࠭ࡐࡕࠩ䚧"):l11ll1_l1_ (u"ࠧࡑࡱࡵࡸࡺ࡭ࡡ࡭ࠩ䚨")
		,l11ll1_l1_ (u"ࠨࡒࡕࠫ䚩"):l11ll1_l1_ (u"ࠩࡓࡹࡪࡸࡴࡰࠢࡕ࡭ࡨࡵࠧ䚪")
		,l11ll1_l1_ (u"ࠪࡕࡆ࠭䚫"):l11ll1_l1_ (u"ࠫࡖࡧࡴࡢࡴࠪ䚬")
		,l11ll1_l1_ (u"ࠬࡉࡇࠨ䚭"):l11ll1_l1_ (u"࠭ࡒࡦࡲࡸࡦࡱ࡯ࡣࠡࡱࡩࠤࡹ࡮ࡥࠡࡅࡲࡲ࡬ࡵࠧ䚮")
		,l11ll1_l1_ (u"ࠧࡓࡑࠪ䚯"):l11ll1_l1_ (u"ࠨࡔࡲࡱࡦࡴࡩࡢࠩ䚰")
		,l11ll1_l1_ (u"ࠩࡕ࡙ࠬ䚱"):l11ll1_l1_ (u"ࠪࡖࡺࡹࡳࡪࡣࠪ䚲")
		,l11ll1_l1_ (u"ࠫࡗ࡝ࠧ䚳"):l11ll1_l1_ (u"ࠬࡘࡷࡢࡰࡧࡥࠬ䚴")
		,l11ll1_l1_ (u"࠭ࡒࡆࠩ䚵"):l11ll1_l1_ (u"ࠧࡓ࣫ࡸࡲ࡮ࡵ࡮ࠨ䚶")
		,l11ll1_l1_ (u"ࠨࡄࡏࠫ䚷"):l11ll1_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡄࡤࡶࡹ࡮ࣩ࡭ࡧࡰࡽࠬ䚸")
		,l11ll1_l1_ (u"ࠪࡗࡍ࠭䚹"):l11ll1_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡌࡪࡲࡥ࡯ࡣࠪ䚺")
		,l11ll1_l1_ (u"ࠬࡑࡎࠨ䚻"):l11ll1_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡑࡩࡵࡶࡶࠤࡦࡴࡤࠡࡐࡨࡺ࡮ࡹࠧ䚼")
		,l11ll1_l1_ (u"ࠧࡍࡅࠪ䚽"):l11ll1_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡍࡷࡦ࡭ࡦ࠭䚾")
		,l11ll1_l1_ (u"ࠩࡐࡊࠬ䚿"):l11ll1_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡐࡥࡷࡺࡩ࡯ࠩ䛀")
		,l11ll1_l1_ (u"ࠫࡕࡓࠧ䛁"):l11ll1_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡕ࡯ࡥࡳࡴࡨࠤࡦࡴࡤࠡࡏ࡬ࡵࡺ࡫࡬ࡰࡰࠪ䛂")
		,l11ll1_l1_ (u"࠭ࡖࡄࠩ䛃"):l11ll1_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡖࡪࡰࡦࡩࡳࡺࠠࡢࡰࡧࠤࡹ࡮ࡥࠡࡉࡵࡩࡳࡧࡤࡪࡰࡨࡷࠬ䛄")
		,l11ll1_l1_ (u"ࠨ࡙ࡖࠫ䛅"):l11ll1_l1_ (u"ࠩࡖࡥࡲࡵࡡࠨ䛆")
		,l11ll1_l1_ (u"ࠪࡗࡒ࠭䛇"):l11ll1_l1_ (u"ࠫࡘࡧ࡮ࠡࡏࡤࡶ࡮ࡴ࡯ࠨ䛈")
		,l11ll1_l1_ (u"࡙ࠬࡁࠨ䛉"):l11ll1_l1_ (u"࠭ࡓࡢࡷࡧ࡭ࠥࡇࡲࡢࡤ࡬ࡥࠬ䛊")
		,l11ll1_l1_ (u"ࠧࡔࡐࠪ䛋"):l11ll1_l1_ (u"ࠨࡕࡨࡲࡪ࡭ࡡ࡭ࠩ䛌")
		,l11ll1_l1_ (u"ࠩࡕࡗࠬ䛍"):l11ll1_l1_ (u"ࠪࡗࡪࡸࡢࡪࡣࠪ䛎")
		,l11ll1_l1_ (u"ࠫࡘࡉࠧ䛏"):l11ll1_l1_ (u"࡙ࠬࡥࡺࡥ࡫ࡩࡱࡲࡥࡴࠩ䛐")
		,l11ll1_l1_ (u"࠭ࡓࡍࠩ䛑"):l11ll1_l1_ (u"ࠧࡔ࡫ࡨࡶࡷࡧࠠࡍࡧࡲࡲࡪ࠭䛒")
		,l11ll1_l1_ (u"ࠨࡕࡊࠫ䛓"):l11ll1_l1_ (u"ࠩࡖ࡭ࡳ࡭ࡡࡱࡱࡵࡩࠬ䛔")
		,l11ll1_l1_ (u"ࠪࡗ࡝࠭䛕"):l11ll1_l1_ (u"ࠫࡘ࡯࡮ࡵࠢࡐࡥࡦࡸࡴࡦࡰࠪ䛖")
		,l11ll1_l1_ (u"࡙ࠬࡋࠨ䛗"):l11ll1_l1_ (u"࠭ࡓ࡭ࡱࡹࡥࡰ࡯ࡡࠨ䛘")
		,l11ll1_l1_ (u"ࠧࡔࡋࠪ䛙"):l11ll1_l1_ (u"ࠨࡕ࡯ࡳࡻ࡫࡮ࡪࡣࠪ䛚")
		,l11ll1_l1_ (u"ࠩࡖࡆࠬ䛛"):l11ll1_l1_ (u"ࠪࡗࡴࡲ࡯࡮ࡱࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䛜")
		,l11ll1_l1_ (u"ࠫࡘࡕࠧ䛝"):l11ll1_l1_ (u"࡙ࠬ࡯࡮ࡣ࡯࡭ࡦ࠭䛞")
		,l11ll1_l1_ (u"࡚࠭ࡂࠩ䛟"):l11ll1_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡁࡧࡴ࡬ࡧࡦ࠭䛠")
		,l11ll1_l1_ (u"ࠨࡉࡖࠫ䛡"):l11ll1_l1_ (u"ࠩࡖࡳࡺࡺࡨࠡࡉࡨࡳࡷ࡭ࡩࡢࠢࡤࡲࡩࠦࡴࡩࡧࠣࡗࡴࡻࡴࡩࠢࡖࡥࡳࡪࡷࡪࡥ࡫ࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䛢")
		,l11ll1_l1_ (u"ࠪࡏࡗ࠭䛣"):l11ll1_l1_ (u"ࠫࡘࡵࡵࡵࡪࠣࡏࡴࡸࡥࡢࠩ䛤")
		,l11ll1_l1_ (u"࡙ࠬࡓࠨ䛥"):l11ll1_l1_ (u"࠭ࡓࡰࡷࡷ࡬࡙ࠥࡵࡥࡣࡱࠫ䛦")
		,l11ll1_l1_ (u"ࠧࡆࡕࠪ䛧"):l11ll1_l1_ (u"ࠨࡕࡳࡥ࡮ࡴࠧ䛨")
		,l11ll1_l1_ (u"ࠩࡏࡏࠬ䛩"):l11ll1_l1_ (u"ࠪࡗࡷ࡯ࠠࡍࡣࡱ࡯ࡦ࠭䛪")
		,l11ll1_l1_ (u"ࠫࡘࡊࠧ䛫"):l11ll1_l1_ (u"࡙ࠬࡵࡥࡣࡱࠫ䛬")
		,l11ll1_l1_ (u"࠭ࡓࡓࠩ䛭"):l11ll1_l1_ (u"ࠧࡔࡷࡵ࡭ࡳࡧ࡭ࡦࠩ䛮")
		,l11ll1_l1_ (u"ࠨࡕࡍࠫ䛯"):l11ll1_l1_ (u"ࠩࡖࡺࡦࡲࡢࡢࡴࡧࠤࡦࡴࡤࠡࡌࡤࡲࠥࡓࡡࡺࡧࡱࠫ䛰")
		,l11ll1_l1_ (u"ࠪࡗ࡟࠭䛱"):l11ll1_l1_ (u"ࠫࡘࡽࡡࡻ࡫࡯ࡥࡳࡪࠧ䛲")
		,l11ll1_l1_ (u"࡙ࠬࡅࠨ䛳"):l11ll1_l1_ (u"࠭ࡓࡸࡧࡧࡩࡳ࠭䛴")
		,l11ll1_l1_ (u"ࠧࡄࡊࠪ䛵"):l11ll1_l1_ (u"ࠨࡕࡺ࡭ࡹࢀࡥࡳ࡮ࡤࡲࡩ࠭䛶")
		,l11ll1_l1_ (u"ࠩࡖ࡝ࠬ䛷"):l11ll1_l1_ (u"ࠪࡗࡾࡸࡩࡢࠩ䛸")
		,l11ll1_l1_ (u"ࠫࡘ࡚ࠧ䛹"):l11ll1_l1_ (u"࡙ࣣࠬࡰࠢࡗࡳࡲ࣯ࠠࡢࡰࡧࠤࡕࡸ࣭࡯ࡥ࡬ࡴࡪ࠭䛺")
		,l11ll1_l1_ (u"࠭ࡔࡘࠩ䛻"):l11ll1_l1_ (u"ࠧࡕࡣ࡬ࡻࡦࡴࠧ䛼")
		,l11ll1_l1_ (u"ࠨࡖࡍࠫ䛽"):l11ll1_l1_ (u"ࠩࡗࡥ࡯࡯࡫ࡪࡵࡷࡥࡳ࠭䛾")
		,l11ll1_l1_ (u"ࠪࡘ࡟࠭䛿"):l11ll1_l1_ (u"࡙ࠫࡧ࡮ࡻࡣࡱ࡭ࡦ࠭䜀")
		,l11ll1_l1_ (u"࡚ࠬࡈࠨ䜁"):l11ll1_l1_ (u"࠭ࡔࡩࡣ࡬ࡰࡦࡴࡤࠨ䜂")
		,l11ll1_l1_ (u"ࠧࡕࡉࠪ䜃"):l11ll1_l1_ (u"ࠨࡖࡲ࡫ࡴ࠭䜄")
		,l11ll1_l1_ (u"ࠩࡗࡏࠬ䜅"):l11ll1_l1_ (u"ࠪࡘࡴࡱࡥ࡭ࡣࡸࠫ䜆")
		,l11ll1_l1_ (u"࡙ࠫࡕࠧ䜇"):l11ll1_l1_ (u"࡚ࠬ࡯࡯ࡩࡤࠫ䜈")
		,l11ll1_l1_ (u"࠭ࡔࡕࠩ䜉"):l11ll1_l1_ (u"ࠧࡕࡴ࡬ࡲ࡮ࡪࡡࡥࠢࡤࡲࡩࠦࡔࡰࡤࡤ࡫ࡴ࠭䜊")
		,l11ll1_l1_ (u"ࠨࡖࡑࠫ䜋"):l11ll1_l1_ (u"ࠩࡗࡹࡳ࡯ࡳࡪࡣࠪ䜌")
		,l11ll1_l1_ (u"ࠪࡘࡗ࠭䜍"):l11ll1_l1_ (u"࡙ࠫࡻࡲ࡬ࡧࡼࠫ䜎")
		,l11ll1_l1_ (u"࡚ࠬࡍࠨ䜏"):l11ll1_l1_ (u"࠭ࡔࡶࡴ࡮ࡱࡪࡴࡩࡴࡶࡤࡲࠬ䜐")
		,l11ll1_l1_ (u"ࠧࡕࡅࠪ䜑"):l11ll1_l1_ (u"ࠨࡖࡸࡶࡰࡹࠠࡢࡰࡧࠤࡈࡧࡩࡤࡱࡶࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䜒")
		,l11ll1_l1_ (u"ࠩࡗ࡚ࠬ䜓"):l11ll1_l1_ (u"ࠪࡘࡺࡼࡡ࡭ࡷࠪ䜔")
		,l11ll1_l1_ (u"࡚ࠫࡓࠧ䜕"):l11ll1_l1_ (u"࡛ࠬ࠮ࡔ࠰ࠣࡑ࡮ࡴ࡯ࡳࠢࡒࡹࡹࡲࡹࡪࡰࡪࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䜖")
		,l11ll1_l1_ (u"࠭ࡖࡊࠩ䜗"):l11ll1_l1_ (u"ࠧࡖ࠰ࡖ࠲ࠥ࡜ࡩࡳࡩ࡬ࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䜘")
		,l11ll1_l1_ (u"ࠨࡗࡊࠫ䜙"):l11ll1_l1_ (u"ࠩࡘ࡫ࡦࡴࡤࡢࠩ䜚")
		,l11ll1_l1_ (u"࡙ࠪࡆ࠭䜛"):l11ll1_l1_ (u"࡚ࠫࡱࡲࡢ࡫ࡱࡩࠬ䜜")
		,l11ll1_l1_ (u"ࠬࡇࡅࠨ䜝"):l11ll1_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭䜞")
		,l11ll1_l1_ (u"ࠧࡖࡍࠪ䜟"):l11ll1_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡍ࡬ࡲ࡬ࡪ࡯࡮ࠩ䜠")
		,l11ll1_l1_ (u"ࠩࡘࡗࠬ䜡"):l11ll1_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡗࡹࡧࡴࡦࡵࠪ䜢")
		,l11ll1_l1_ (u"࡚ࠫ࡟ࠧ䜣"):l11ll1_l1_ (u"࡛ࠬࡲࡶࡩࡸࡥࡾ࠭䜤")
		,l11ll1_l1_ (u"࠭ࡕ࡛ࠩ䜥"):l11ll1_l1_ (u"ࠧࡖࡼࡥࡩࡰ࡯ࡳࡵࡣࡱࠫ䜦")
		,l11ll1_l1_ (u"ࠨࡘࡘࠫ䜧"):l11ll1_l1_ (u"࡙ࠩࡥࡳࡻࡡࡵࡷࠪ䜨")
		,l11ll1_l1_ (u"࡚ࠪࡆ࠭䜩"):l11ll1_l1_ (u"࡛ࠫࡧࡴࡪࡥࡤࡲࠥࡉࡩࡵࡻࠪ䜪")
		,l11ll1_l1_ (u"ࠬ࡜ࡅࠨ䜫"):l11ll1_l1_ (u"࠭ࡖࡦࡰࡨࡾࡺ࡫࡬ࡢࠩ䜬")
		,l11ll1_l1_ (u"ࠧࡗࡐࠪ䜭"):l11ll1_l1_ (u"ࠨࡘ࡬ࡩࡹࡴࡡ࡮ࠩ䜮")
		,l11ll1_l1_ (u"࡚ࠩࡊࠬ䜯"):l11ll1_l1_ (u"࡛ࠪࡦࡲ࡬ࡪࡵࠣࡥࡳࡪࠠࡇࡷࡷࡹࡳࡧࠧ䜰")
		,l11ll1_l1_ (u"ࠫࡊࡎࠧ䜱"):l11ll1_l1_ (u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭䜲")
		,l11ll1_l1_ (u"࡙࠭ࡆࠩ䜳"):l11ll1_l1_ (u"࡚ࠧࡧࡰࡩࡳ࠭䜴")
		,l11ll1_l1_ (u"ࠨ࡜ࡐࠫ䜵"):l11ll1_l1_ (u"ࠩ࡝ࡥࡲࡨࡩࡢࠩ䜶")
		,l11ll1_l1_ (u"ࠪ࡞࡜࠭䜷"):l11ll1_l1_ (u"ࠫ࡟࡯࡭ࡣࡣࡥࡻࡪ࠭䜸")
		,l11ll1_l1_ (u"ࠬࡇࡘࠨ䜹"):l11ll1_l1_ (u"࠭ࣅ࡭ࡣࡱࡨࠬ䜺")
		}
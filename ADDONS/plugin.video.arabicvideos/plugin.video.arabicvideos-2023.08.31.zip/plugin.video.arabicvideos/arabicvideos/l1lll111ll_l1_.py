# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ᠅")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪ᠆")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ᠇"),l11ll1_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ᠈"),l11ll1_l1_ (u"ࠧหีฯ๎้࠭᠉"),l11ll1_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭᠊")]
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l11111_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l1llll1_l1_(url,text)
	elif mode==634: results = l1l111_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭᠋"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ᠌"),l11ll1_l1_ (u"ࠫࠬ᠍"),l11ll1_l1_ (u"ࠬ࠭᠎"),l11ll1_l1_ (u"࠭ࠧ᠏"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᠐"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠑"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ᠒"),l11ll1_l1_ (u"ࠪࠫ᠓"),639,l11ll1_l1_ (u"ࠫࠬ᠔"),l11ll1_l1_ (u"ࠬ࠭᠕"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᠖"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᠗"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᠘"),l11ll1_l1_ (u"ࠩࠪ᠙"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠚"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᠛")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭᠜"),l11l1l_l1_,631,l11ll1_l1_ (u"࠭ࠧ᠝"),l11ll1_l1_ (u"ࠧࠨ᠞"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ᠟"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠠ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᠡ")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪᠢ"),l11l1l_l1_,631,l11ll1_l1_ (u"ࠬ࠭ᠣ"),l11ll1_l1_ (u"࠭ࠧᠤ"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᠥ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᠦ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᠧ")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩᠨ"),l11l1l_l1_,631,l11ll1_l1_ (u"ࠫࠬᠩ"),l11ll1_l1_ (u"ࠬ࠭ᠪ"),l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪᠫ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᠬ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᠭ")+l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭ᠮ"),l11l1l_l1_,631,l11ll1_l1_ (u"ࠪࠫᠯ"),l11ll1_l1_ (u"ࠫࠬᠰ"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧᠱ"))
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᠲ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᠳ"),l11ll1_l1_ (u"ࠨࠩᠴ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᠵ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᠶ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if title==l11ll1_l1_ (u"ࠫศำฯฬࠢส่า๊โศฬࠪᠷ"): mode,request = 631,l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᠸ")
		else: mode,request = 634,l11ll1_l1_ (u"࠭ࠧᠹ")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᠺ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᠻ")+l111l1_l1_+title,l1lllll_l1_,mode,l11ll1_l1_ (u"ࠩࠪᠼ"),l11ll1_l1_ (u"ࠪࠫᠽ"),request)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᠾ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᠿ"),l11ll1_l1_ (u"࠭ࠧᡀ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫᡁ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨᡂ"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠩࠪᡃ"))
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᡄ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡅ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᡆ")+l111l1_l1_+title,l1lllll_l1_,634)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᡇ"),url,l11ll1_l1_ (u"ࠧࠨᡈ"),l11ll1_l1_ (u"ࠨࠩᡉ"),l11ll1_l1_ (u"ࠩࠪᡊ"),l11ll1_l1_ (u"ࠪࠫᡋ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᡌ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᡍ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧᡎ"),l11ll1_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ᡏ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᡐ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠩࠪᡑ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᡒ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᡓ"),l11ll1_l1_ (u"ࠬ࠭ᡔ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᡕ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢࠪᡖ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᡗ"),l111l1_l1_+title,l1lllll_l1_,631)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᡘ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᡙ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᡚ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᡛ"),l11ll1_l1_ (u"࠭ࠧᡜ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡝ"),l111l1_l1_+title,l1lllll_l1_,631)
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡶ࡭࠮ࡵࡨࡧࡹ࡯࡯࡯࠯࡫ࡩࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸ࠹࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬ࡮ࡺࡥ࡮ࡵࠬࡀ࠸࠶࠺ࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡰ࡮ࡴ࡫ࠨ࠮ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠰ࠬ࠭ࠬ࠺࠻࠼࠽࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫࠍࠍࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠷࠵࠴࠭ࠏࠏࡩࡧࠢࡱࡳࡹࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠵ࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠶ࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠷࠿ࠦࡔࡊࡖࡏࡉࡘ࠮ࡵࡳ࡮ࠬࠎࠎࠨࠢࠣᡞ")
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠩࠪᡟ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᡠ"),l11ll1_l1_ (u"ࠫࠬᡡ"),request,url)
	if request==l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᡢ"):
		url,search = url.split(l11ll1_l1_ (u"࠭࠿ࠨᡣ"),1)
		data = l11ll1_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ᡤ")+search
		headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᡥ"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᡦ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᡧ"),url,data,headers,l11ll1_l1_ (u"ࠫࠬᡨ"),l11ll1_l1_ (u"ࠬ࠭ᡩ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᡪ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᡫ"),url,l11ll1_l1_ (u"ࠨࠩᡬ"),l11ll1_l1_ (u"ࠩࠪᡭ"),l11ll1_l1_ (u"ࠪࠫᡮ"),l11ll1_l1_ (u"ࠫࠬᡯ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᡰ"))
	html = response.content
	block,items = l11ll1_l1_ (u"࠭ࠧᡱ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫᡲ"))
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᡳ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᡴ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l11ll1_l1_ (u"ࠪࠫᡵ")))
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᡶ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࡣ࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᡷ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࠧࠨࠤࡳࡳࡸࡺࡂ࡭ࡱࡦ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠩࠪࠫᡸ"),block,re.DOTALL)
	elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭᡹"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᡺"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭᡻"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᡼"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭᡽"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ᡾"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᡿"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l11ll1_l1_ (u"ࠧࠨᢀ")))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᢁ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᢂ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪᢃ"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩᢄ"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫᢅ"),l11ll1_l1_ (u"࠭ใๅ์หࠫᢆ"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭ᢇ"),l11ll1_l1_ (u"ࠨ้าหๆ࠭ᢈ"),l11ll1_l1_ (u"่ࠩฬฬืวสࠩᢉ"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧᢊ"),l11ll1_l1_ (u"๊ࠫํัอษ้ࠫᢋ"),l11ll1_l1_ (u"ࠬอไษ๊่ࠫᢌ"),l11ll1_l1_ (u"࠭ๅิำะ๎ฮ࠭ᢍ")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨᢎ"),l1lllll_l1_)
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪᢏ"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᢐ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬᢑ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭ᢒ"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᢓ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨᢔ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩᢕ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪᢖ"))
		title = title.replace(l11ll1_l1_ (u"ࠩࠣื๏๋วࠡๅ็์อ࠭ᢗ"),l11ll1_l1_ (u"ࠪࠫᢘ"))
		title = title.replace(l11ll1_l1_ (u"ࠫࠥอ่็ࠢ็ห๏์ࠧᢙ"),l11ll1_l1_ (u"ࠬ࠭ᢚ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩᢛ"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠧࡘ࡙ࡈࠫᢜ") in title: continue
		elif any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᢝ"),l111l1_l1_+title,l1lllll_l1_,632,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᢞ"):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᢟ"),l111l1_l1_+title,l1lllll_l1_,632,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᢠ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᢡ"),l111l1_l1_+title,l1lllll_l1_,633,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫᢢ") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢣ"),l111l1_l1_+title,l1lllll_l1_,631,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢤ"),l111l1_l1_+title,l1lllll_l1_,633,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᢥ"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᢦ")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᢧ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᢨ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"࠭ࠣࠨᢩ"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᢪ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ᢫"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᢬"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ᢭")+title,l1lllll_l1_,631)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ᢮"),l11ll1_l1_ (u"ࠬ࠭᢯"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᢰ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᢱ"),url,l11ll1_l1_ (u"ࠨࠩᢲ"),l11ll1_l1_ (u"ࠩࠪᢳ"),l11ll1_l1_ (u"ࠪࠫᢴ"),l11ll1_l1_ (u"ࠫࠬᢵ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ᢶ"))
	html = response.content
	l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᢷ"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࠨᢸ")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫᢹ"),html,re.DOTALL)
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭࠰ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩᢺ"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠪࠧࠬᢻ"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢼ"),l111l1_l1_+title,url,633,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭ᢽ"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࠫᢾ")+l1l1l_l1_+l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᢿ"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᣀ"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᣁ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			#l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬᣂ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭ᣃ"))
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧᣄ"))
			title = title.replace(l11ll1_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫᣅ"),l11ll1_l1_ (u"ࠧࠡࠩᣆ"))
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᣇ"),l111l1_l1_+title,l1lllll_l1_,632,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᣈ"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᣉ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭ᣊ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧᣋ"))
		#		addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᣌ"),l111l1_l1_+title,l1lllll_l1_,632,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l111_l1_,l1lll1ll_l1_ = [],[],[]
	# l11l1l1l1_l1_ l1l1_l1_
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫᣍ"),l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫᣎ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᣏ"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫᣐ"),l11ll1_l1_ (u"ࠫࠬᣑ"),l11ll1_l1_ (u"ࠬ࠭ᣒ"),l11ll1_l1_ (u"࠭ࠧᣓ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᣔ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᣕ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠤࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠦᣖ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᣗ")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᣘ"))
				l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᣙ"),l11ll1_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱ࡴ࡭ࡶࠧᣚ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᣛ"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩᣜ"),l11ll1_l1_ (u"ࠩࠪᣝ"),l11ll1_l1_ (u"ࠪࠫᣞ"),l11ll1_l1_ (u"ࠫࠬᣟ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩᣠ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᣡ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪᣢ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᣣ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᣤ"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l111_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1lll1ll_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᣥ"),l1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᣦ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ᣧ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧᣨ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩᣩ"),l11ll1_l1_ (u"ࠨ࠭ࠪᣪ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪᣫ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪᣬ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨᣭ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᣮ"))
	return
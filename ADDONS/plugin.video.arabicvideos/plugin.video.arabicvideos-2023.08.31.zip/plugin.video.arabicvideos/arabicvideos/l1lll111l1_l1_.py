# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨᣯ")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡅࡐࡇࡤ࠭ᣰ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦๆหใ็๎ู่ࠧᣱ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l11111_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l1llll11_l1_(url)
	elif mode==494: results = l1l111_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᣲ"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫᣳ"),l11ll1_l1_ (u"ࠫࠬᣴ"),l11ll1_l1_ (u"ࠬ࠭ᣵ"),l11ll1_l1_ (u"࠭ࠧ᣶"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᣷"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᣸"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠩ࠲ࠫ᣹"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ᣺"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᣻"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ᣼"),l1ll111_l1_,499,l11ll1_l1_ (u"࠭ࠧ᣽"),l11ll1_l1_ (u"ࠧࠨ᣾"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᣿"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤀ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᤁ")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪᤂ"),l1ll111_l1_,491,l11ll1_l1_ (u"ࠬ࠭ᤃ"),l11ll1_l1_ (u"࠭ࠧᤄ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᤅ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᤆ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᤇ"),l11ll1_l1_ (u"ࠪࠫᤈ"),9999)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡇࡪࡢࡺ࡬ࡪࡾࡌࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᤉ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡪ࡮ࡲࡴࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᤊ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡴࡲࡤ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩᤋ")+l1lllll_l1_+l11ll1_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬᤌ")
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤍ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᤎ")+l111l1_l1_+title,l1lllll_l1_,491)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᤏ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᤐ"),l11ll1_l1_ (u"ࠬ࠭ᤑ"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤒ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᤓ")+l111l1_l1_+l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠧᤔ"),l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อแๅษ่࠱ࡲࡵࡶࡪࡧࡶ࠱࡫࡯࡬࡮ࡧ࠲ࡪࡴࡸࡥࡪࡩࡱ࠱࡭ࡪ࠭ศใ็ห๊࠳วอ่หํ࠲࠸ࠧᤕ"),494,l11ll1_l1_ (u"ࠪࠫᤖ"),l11ll1_l1_ (u"ࠫࠬᤗ"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᤘ"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤙ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᤚ")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠩᤛ"),l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴๋ำๅี็หฯ࠵ๅิๆึ่ฬะ࠭ศฮ้ฬ๎࠭ᤜ"),494,l11ll1_l1_ (u"ࠪࠫᤝ"),l11ll1_l1_ (u"ࠫࠬᤞ"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᤟"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᤠ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᤡ"),l11ll1_l1_ (u"ࠨࠩᤢ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᤣ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᤤ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠫ࠴࠭ᤥ"): continue
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᤦ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤧ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᤨ")+l111l1_l1_+title,l1lllll_l1_,491)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᤩ"),l11ll1_l1_ (u"ࠩࠪᤪ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᤫ"),url,l11ll1_l1_ (u"ࠫࠬ᤬"),l11ll1_l1_ (u"ࠬ࠭᤭"),l11ll1_l1_ (u"࠭ࠧ᤮"),l11ll1_l1_ (u"ࠧࠨ᤯"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᤰ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡪ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᤱ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᤲ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤳ"),l111l1_l1_+title,l1lllll_l1_,491)
	return
def l11111_l1_(url,l1lll1l11l_l1_=l11ll1_l1_ (u"ࠬ࠭ᤴ")):
	items = []
	#l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᤵ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᤶ"),url,l11ll1_l1_ (u"ࠨࠩᤷ"),l11ll1_l1_ (u"ࠩࠪᤸ"),l11ll1_l1_ (u"᤹ࠪࠫ"),l11ll1_l1_ (u"ࠫࠬ᤺"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷ᤻ࠫ"))
	html = response.content
	block = l11ll1_l1_ (u"࠭ࠧ᤼")
	if l11ll1_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬ᤽") in url: block = html
	elif l11ll1_l1_ (u"ࠨࡁࡶࡁࠬ᤾") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࠣ࡯ࡤࡲ࡮࡬ࡥࡴࡶࠥࠫ᤿"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᥀"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࠥࡱࡦࡴࡩࡧࡧࡶࡸࠧ࠭᥁"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
	if not block: return
	#if not items: items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩࡡࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡤࡲࡼࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ᥂"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"࠭ๅีษ๊ำฮ࠭᥃"),l11ll1_l1_ (u"ࠧโ์็้ࠬ᥄"),l11ll1_l1_ (u"ࠨษ฽๊๏ฯࠧ᥅"),l11ll1_l1_ (u"ࠩฦ฾๋๐ษࠨ᥆"),l11ll1_l1_ (u"ࠪ็้๐ศࠨ᥇"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪ᥈"),l11ll1_l1_ (u"ࠬํฯศใࠪ᥉"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭᥊"),l11ll1_l1_ (u"ฺࠧำูࠫ᥋"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨ᥌"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨ᥍"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪ᥎")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ᥏"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨᥐ"),title,re.DOTALL)
		if not l1ll1l1_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᥑ"),l111l1_l1_+title,l1lllll_l1_,492,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠧฮๆๅอࠬᥒ") in title:
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᥓ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᥔ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᥕ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᥖ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᥗ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"࠭วๅืไัฮࠦࠧᥘ"),l11ll1_l1_ (u"ࠧࠨᥙ"))
			if title!=l11ll1_l1_ (u"ࠨࠩᥚ"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᥛ"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩᥜ")+title,l1lllll_l1_,491)
	return
def l1llll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᥝ"),url,l11ll1_l1_ (u"ࠬ࠭ᥞ"),l11ll1_l1_ (u"࠭ࠧᥟ"),l11ll1_l1_ (u"ࠧࠨᥠ"),l11ll1_l1_ (u"ࠨࠩᥡ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᥢ"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡇࡻࡴࡵࡱࡱࡷࡇࡧࡲࡄࡱࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᥣ"),html,re.DOTALL)
	if l111lll_l1_:
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᥤ"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭ᥥ"),l11ll1_l1_ (u"࠭ࠧᥦ"),l11ll1_l1_ (u"ࠧࠨᥧ"),l11ll1_l1_ (u"ࠨࠩᥨ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪᥩ"))
		html = response.content
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡳࡧ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᥪ"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬᥫ"))
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᥬ"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩᥭ"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ᥮") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᥯"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᥰ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࡟࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࠨࡢࡰࡺࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᥱ"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1lll1_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᥲ"))
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᥳ"),l111l1_l1_+title,l1lllll_l1_,492,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᥴ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᥵"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l11ll1_l1_ (u"ࠨษ็ูๆำษࠡࠩ᥶"),l11ll1_l1_ (u"ࠩࠪ᥷"))
				if title!=l11ll1_l1_ (u"ࠪࠫ᥸"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᥹"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ᥺")+title,l1lllll_l1_,491)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"࠭࠯ࠨ᥻"))+l11ll1_l1_ (u"ࠧ࠰ࡁࡹ࡭ࡪࡽ࠽࠲ࠩ᥼")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ᥽"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ᥾"),l11ll1_l1_ (u"ࠪࠫ᥿"),l11ll1_l1_ (u"ࠫࠬᦀ"),l11ll1_l1_ (u"ࠬ࠭ᦁ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᦂ"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫᦃ"))
	l1ll1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡦࡤࡸࡦࡀࠠࠨࡳࡀࠬ࠳࠰࠿ࠪࠨࠥᦄ"),html,re.DOTALL)
	#if not l1ll1lll1l_l1_: l1ll1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡟ࠬࡹ࡮ࡩࡴ࡞࠱࡭ࡩࡢࠬ࠱࡞࠯ࠬ࠳࠰࠿ࠪ࡞ࠬࠫᦅ"),html,re.DOTALL)
	l1ll1lll1l_l1_ = l1ll1lll1l_l1_[0]
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᦆ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧᦇ"),block,re.DOTALL)
		for l1lll1111l_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧᦈ"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡴࡲࡤ࠰ࡵࡨࡶࡻ࡫ࡲࡴ࠱ࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩᦉ")+l1ll1lll1l_l1_+l11ll1_l1_ (u"ࠧࠧ࡫ࡀࠫᦊ")+l1lll1111l_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᦋ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᦌ")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l11_l1_ l11l1l1l1_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡖࡩࡷࡼࡥࡳࠤ࠱࠮ࡄ࡙ࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᦍ"),html,re.DOTALL)
	if l1lllll_l1_:
		title = l11ll1_l1_ (u"๊ࠫ็ึๅࠩᦎ")
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࠨᦏ")+title
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	#l111lll_l1_ = url.strip(l11ll1_l1_ (u"࠭࠯ࠨᦐ"))+l11ll1_l1_ (u"ࠧ࠰ࡁࡧࡳࡼࡴ࡬ࡰࡣࡧࡁ࠶࠭ᦑ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᦒ"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪᦓ"),l11ll1_l1_ (u"ࠪࠫᦔ"),l11ll1_l1_ (u"ࠫࠬᦕ"),l11ll1_l1_ (u"ࠬ࠭ᦖ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪᦗ"))
	#html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᦘ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᦙ"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᦚ"))
			if l11ll1_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫᦛ") in l1lllll_l1_: l1lll1l11_l1_ = l11ll1_l1_ (u"ࠫࡤࡥฮศืࠪᦜ")
			else: l1lll1l11_l1_ = l11ll1_l1_ (u"ࠬ࠭ᦝ")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᦞ")+title+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᦟ")+l1lll1l11_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᦠ"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᦡ"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"ࠪࠫᦢ")):
	if not l1ll111_l1_: l1ll111_l1_ = l11l1l_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭ᦣ"),l11ll1_l1_ (u"ࠬ࠱ࠧᦤ"))
	url = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࡷࡂ࠭ᦥ")+search
	l11111_l1_(url)
	return
#   search is l11l1lll1_l1_ l11lll11l_l1_ in l11111_l1_()
#   https://l1ll1llll1_l1_.l1ll1lllll_l1_-l1lll11111_l1_.l1lll11111_l1_/?s=the+l1ll1ll1ll_l1_
#   https://l1ll1llll1_l1_.l1ll1lllll_l1_-l1lll11111_l1_.l1lll11111_l1_/search/the+l1ll1ll1ll_l1_/
#   https://l1ll1llll1_l1_.l1ll1lllll_l1_-l1lll11111_l1_.l1lll11111_l1_/index.l1ll1lll11_l1_?s=the+l1ll1ll1ll_l1_
#	https://l1ll1lllll_l1_-l1lll11111_l1_.io/index.l1ll1lll11_l1_?s=the+l1ll1ll1ll_l1_
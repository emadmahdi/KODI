# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11llll1l11_l1_ import *
import traceback,bidi.algorithm
#import l1l1lll1l11l_l1_
script_name = l11ll1_l1_ (u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ㏰")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1llll1l111l_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ㏱"))
	l1l1l11111_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭㏲"))
	l11ll11111l_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ㏳"))
	l1l1ll1l11ll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㏴"),l11ll1_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㏵"),l11ll1_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ㏶"))
	l11l111ll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㏷"),l11ll1_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㏸"),l11ll1_l1_ (u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ㏹"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㏺"),l11ll1_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㏻"),l11ll1_l1_ (u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ㏼"))
	half_triangular_colon = l11ll1_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ㏽")
	from urllib.parse import quote as _1lll1111l11_l1_
	#from io import BytesIO as _1ll1l11l1ll_l1_
else:
	l1llll1l111l_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ㏾"))
	l1l1l11111_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ㏿"))
	l11ll11111l_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ㐀"))
	l1l1ll1l11ll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㐁"),l11ll1_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㐂"),l11ll1_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭㐃"))
	l11l111ll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㐄"),l11ll1_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㐅"),l11ll1_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ㐆"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㐇"),l11ll1_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㐈"),l11ll1_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ㐉"))
	half_triangular_colon = l11ll1_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ㐊").encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㐋"))
	from urllib import quote as _1lll1111l11_l1_
	#from StringIO import StringIO as _1ll1l11l1ll_l1_
#l1lllll1ll1l_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11llll111l_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡌ࡯࡭ࡦࡨࡶࡕࡧࡴࡩࠩ㐌"))
dest_lang = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧ㐍"))
do_trans = False if not dest_lang or dest_lang==l11ll1_l1_ (u"ࠬࡧࡲࡢࠩ㐎") else True
l1lll1111lll_l1_ = os.path.join(l11ll11111l_l1_,l11ll1_l1_ (u"࠭࡫ࡰࡦ࡬࠲ࡱࡵࡧࠨ㐏"))
l1lll1ll11ll_l1_ = os.path.join(l11ll11111l_l1_,l11ll1_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡵ࡬ࡥ࠰࡯ࡳ࡬࠭㐐"))
l11lll11l11_l1_ = [l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ㐑"),l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪ㐒"),l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭㐓"),l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭㐔"),l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭㐕"),l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ㐖")]
l1111111lll_l1_ = l11lll11l11_l1_+[l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ㐗"),l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㐘"),l11ll1_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ㐙"),l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯ࡲ࡫ࡩࡳࡵ࡭ࡦࡰࡤࡰࡊࡓࡁࡅࠩ㐚")]		# ,l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰࡬ࡲࡸࡺࡡ࡭࡮ࡈࡑࡆࡊࠧ㐛")
iptv1_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠬ࡯ࡰࡵࡸ࠴ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㐜"))
iptv2_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㐝"))
l1l1llll1ll1_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠧ࡮࠵ࡸࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㐞"))
#l1lll1ll1ll1_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠨࡺࡷࡶࡪࡧ࡭ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ㐟"))
#l1lll1l1l1ll_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠩ࡯ࡥࡸࡺ࡭ࡦࡰࡸ࠲ࡩࡧࡴࠨ㐠"))
favoritesfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫ㐡"))
#dummyiptvfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠫࡩࡻ࡭࡮ࡻ࡬ࡴࡹࡼ࠮ࡥࡣࡷࠫ㐢"))
fulliptvfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠬ࡯ࡰࡵࡸࡩ࡭ࡱ࡫࡟ࡠࡡ࠱ࡨࡦࡺࠧ㐣"))
l1l1l1ll1l1l_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"࠭࡭࠴ࡷࡩ࡭ࡱ࡫࡟ࡠࡡ࠱ࡨࡦࡺࠧ㐤"))
l1l11l1ll1l1_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡧࡥࡹ࠭㐥"))
l1l11lll11l1_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠨࡦ࡬ࡥࡱࡵࡧࡠ࠲࠳࠴࠵ࡥ࠮ࡱࡰࡪࠫ㐦"))
l1l11l111ll_l1_ = xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ㐧"))
defaulticon = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠪ࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ㐨"))
defaultthumb = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤ࠱ࡴࡳ࡭ࠧ㐩"))
defaultfanart = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸ࠳ࡶ࡮ࡨࠩ㐪"))
defaultbanner = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠴ࡰ࡯ࡩࠪ㐫"))
defaultlandscape = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧ࠱ࡴࡳ࡭ࠧ㐬"))
defaultposter = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠨࡲࡲࡷࡹ࡫ࡲ࠯ࡲࡱ࡫ࠬ㐭"))
defaultclearlogo = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳ࠳ࡶ࡮ࡨࠩ㐮"))
defaultclearart = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸ࠳ࡶ࡮ࡨࠩ㐯"))
l1ll111ll1ll_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡩࡨࡰࡴ࡭࠮ࡵࡺࡷࠫ㐰"))
l1ll11llll_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ㐱"))
l1ll1111lll1_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㐲"),l11ll1_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ㐳"),addon_id,l11ll1_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㐴"))
l1lllll1111l_l1_ = os.path.join(l1llll1l111l_l1_,l11ll1_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࠨ㐵"),l11ll1_l1_ (u"ࠪࡊࡴࡴࡴࡴࠩ㐶"),l11ll1_l1_ (u"ࠫࡦࡸࡩࡢ࡮࠱ࡸࡹ࡬ࠧ㐷"))
l1llllllll11_l1_ = [l11ll1_l1_ (u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ㐸"),l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ㐹"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ㐺"),l11ll1_l1_ (u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ㐻"),l11ll1_l1_ (u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ㐼"),l11ll1_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㐽"),l11ll1_l1_ (u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩ㐾")]
l111ll111ll_l1_ = [l11ll1_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗࠬ㐿"),l11ll1_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠸ࠨ㑀"),l11ll1_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠺ࠩ㑁")]
FOLDERS_COUNT = 5
text_numbers = [l11ll1_l1_ (u"ࠨืไีࠬ㑂"),l11ll1_l1_ (u"ࠩฦ์้࠭㑃"),l11ll1_l1_ (u"ࠪฯฬ์๊ࠨ㑄"),l11ll1_l1_ (u"ࠫะอไฬࠩ㑅"),l11ll1_l1_ (u"ࠬืวษ฻ࠪ㑆"),l11ll1_l1_ (u"࠭ฮศ็ึࠫ㑇"),l11ll1_l1_ (u"ࠧิษาืࠬ㑈"),l11ll1_l1_ (u"ࠨีสฬ฾࠭㑉"),l11ll1_l1_ (u"ࠩฮห๊์ࠧ㑊"),l11ll1_l1_ (u"ࠪฮฬููࠨ㑋"),l11ll1_l1_ (u"ࠫ฾อิาࠩ㑌")]
l1lll1ll111l_l1_ = l11ll1_l1_ (u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭㑍")
NO_CACHE = 0
l1ll11llll1l_l1_ = 30*l1l11ll1l1l_l1_
l1ll1ll1l_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l1lllll1_l1_ = 3*l11llll11ll_l1_
VERYLONG_CACHE = 30*l11llll11ll_l1_
l11lllll1l1_l1_ = 1*HOUR
l1l1ll111l1l_l1_ = [l11ll1_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㑎"),l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㑏")]
l1lll1l1lll1_l1_ = [l11ll1_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㑐")]
l1llll1l1111_l1_ = [l11ll1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ㑑"),l11ll1_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㑒"),l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㑓"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭㑔"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ㑕"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㑖"),l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㑗")]
l1llll1l1111_l1_ += [l11ll1_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ㑘"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ㑙"),l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭㑚"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㑛"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ㑜"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㑝"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ㑞")]
l1l11l1lll1l_l1_ = [l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㑟"),l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㑠"),l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㑡"),l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㑢")]
l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"࠭ࡍ࠴ࡗࠪ㑣"),l11ll1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㑤"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㑥"),l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㑦")]
l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㑧"),l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㑨"),l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㑩")]
l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㑪"),l11ll1_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㑫"),l11ll1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㑬"),l11ll1_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㑭")]		# l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㑮")
l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㑯"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㑰"),l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㑱"),l11ll1_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㑲"),l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㑳"),l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㑴")]
#l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ㑵"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㑶"),l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ㑷"),l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ㑸")]
#l1l11l1lll1l_l1_ += [l11ll1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㑹"),l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࠫ㑺"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭㑻"),l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘ࠭㑼")]
l1l1llll111_l1_ = [l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㑽"),l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㑾"),l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㑿"),l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㒀")]
l1l1llll111_l1_ += [l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㒁"),l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㒂"),l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㒃"),l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㒄"),l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ㒅")]
l1ll111111l_l1_ = [l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㒆"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㒇"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㒈"),l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㒉"),l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㒊"),l11ll1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㒋")]
l1ll111111l_l1_ += [l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㒌"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㒍"),l11ll1_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㒎"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㒏")]
#l1ll111111l_l1_ += [l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㒐"),l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ㒑")]
l1ll11ll1l1_l1_ = [l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㒒"),l11ll1_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㒓"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㒔"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㒕"),l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㒖"),l11ll1_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㒗"),l11ll1_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㒘"),l11ll1_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㒙")]	# ,l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㒚")
l1ll11ll1l1_l1_ += [l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㒛"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㒜"),l11ll1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㒝"),l11ll1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㒞"),l11ll1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㒟"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㒠"),l11ll1_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ㒡")]
#l1ll11ll1l1_l1_ += [l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㒢"),l11ll1_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㒣"),l11ll1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㒤"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ㒥"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ㒦"),l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㒧"),l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㒨")]
l1ll11l1111l_l1_  = [l11ll1_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㒩"),l11ll1_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㒪"),l11ll1_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㒫"),l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㒬"),l11ll1_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㒭"),l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㒮"),l11ll1_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㒯"),l11ll1_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㒰")]
l1ll11l1111l_l1_ += [l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㒱"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㒲"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㒳"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㒴"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㒵"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㒶"),l11ll1_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㒷"),l11ll1_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㒸"),l11ll1_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㒹")]
l1ll11l1111l_l1_ += [l11ll1_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㒺"),l11ll1_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㒻"),l11ll1_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㒼")]		# l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㒽"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㒾"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㒿")
l1ll11l1111l_l1_ += [l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㓀"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㓁"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㓂"),l11ll1_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㓃"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㓄"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㓅"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㓆")]
l1ll11l1111l_l1_ += [l11ll1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㓇"),l11ll1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㓈"),l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㓉"),l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㓊"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㓋"),l11ll1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㓌"),l11ll1_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ㓍")]
l1l1l1l1ll1l_l1_  = [l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭㓎"),l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㓏"),l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㓐"),l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩ㓑")]
l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㓒"),l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㓓")]
l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ㓔"),l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㓕"),l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㓖")]
l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㓗"),l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㓘"),l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㓙")]
l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ㓚"),l11ll1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㓛"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㓜")]
#l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㓝"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩ㓞")]
#l1l1l1l1ll1l_l1_ += [l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࠨ㓟"),l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࠨ㓠"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࠩ㓡")]
l1l1ll1l111l_l1_ = [l11ll1_l1_ (u"ࠧࡎ࠵ࡘࠫ㓢"),l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠭㓣"),l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㓤"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㓥"),l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㓦")]		# l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㓧"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ㓨")
l1ll111ll11_l1_ = l1ll11l1111l_l1_+l1l1l1l1ll1l_l1_
l1ll111111ll_l1_ = l1ll11l1111l_l1_+l1l1ll1l111l_l1_
l11lll111l1_l1_ = l1ll11l1111l_l1_+l1l1ll1l111l_l1_+l1l1ll111l1l_l1_
l1ll111l1ll_l1_ = l1l11l1lll1l_l1_+l1ll111111l_l1_+l1ll11ll1l1_l1_+l1l1llll111_l1_
# l1lll1ll1l11_l1_ will not show l11111l11ll_l1_ errors and will not exit from the l11ll1l1l1l_l1_
l1111ll1l1l_l1_ = [
						l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ㓩")
						,l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ㓪")
						,l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ㓫")
						,l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ㓬")
						,l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭㓭")
						,l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ㓮")
						,l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㓯")
						,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ㓰")
						,l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ㓱")
						,l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭㓲")
						]
l111lll1ll1_l1_ = l1111ll1l1l_l1_+[
				 l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡘࡏ࡙࡛ࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ㓳")
				,l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡈࡕࡖࡓࡗࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㓴")
				,l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ㓵")
				,l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠸࡮ࡥࠩ㓶")
				,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠱ࡴࡶࠪ㓷")
				,l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠳ࡰࡧࠫ㓸")
				,l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠲ࡵࡷࠫ㓹")
				,l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠴ࡱࡨࠬ㓺")
				,l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠶ࡶࡩ࠭㓻")
				,l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡃࡉࡇࡆࡏࡤࡎࡔࡕࡒࡖࡣࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㓼")
				,l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ㓽")
				,l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠱ࡴࡶࠪ㓾")
				,l11ll1_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠳ࡰࡧࠫ㓿")
				,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧ㔀")
				,l11ll1_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭㔁")
				#,l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㔂")
				#,l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㔃")
				#,l11ll1_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ㔄")
				#,l11ll1_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㔅")
				#,l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ㔆")
				#,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡌࡋࡔࡠࡎࡄࡘࡊ࡙ࡔࡠࡘࡈࡖࡘࡏࡏࡏࡡࡑ࡙ࡒࡈࡅࡓࡕ࠰࠵ࡸࡺࠧ㔇")
				#,l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㔈")
				#,l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㔉")
				#,l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㔊")
				]
l1lllll11111_l1_ = [l11ll1_l1_ (u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ㔋"),l11ll1_l1_ (u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨ㔌"),l11ll1_l1_ (u"ࠨ࠳࠱࠴࠳࠶࠮࠲ࠩ㔍"),l11ll1_l1_ (u"ࠩ࠻࠲࠽࠴࠴࠯࠶ࠪ㔎"),l11ll1_l1_ (u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠸࠮࠳࠴࠵ࠫ㔏"),l11ll1_l1_ (u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠰࠯࠴࠵࠴ࠬ㔐")]
l1l1lll_l1_ = {
			#,l11ll1_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㔑")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ㔒")]
			#,l11ll1_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㔓")	:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡ࡭࡭ࡤࡻࡹ࡮ࡡࡳࡶࡹ࠲࡮ࡸࠧ㔔")]
			#,l11ll1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ㔕")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴࡮ࡦࡶࠪ㔖")]
			#,l11ll1_l1_ (u"ࠫࡊࡍ࡙࠵ࡄࡈࡗ࡙࠭㔗")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ㔘")]
			#,l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ㔙")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ㔚")]
			#,l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ㔛")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ㔜")]
			#,l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ㔝")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡨ࡫ࡾࡴ࡯ࡸ࠰࡯࡭ࡻ࡫ࠧ㔞")]
			#,l11ll1_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ㔟")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠵ࡪࡨࡰࡦࡲ࠮࡮ࡧࠪ㔠")]
			#,l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ㔡")	:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩࠬ㔢"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥࠨ㔣")]
			#,l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ㔤")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡳࡻࡹ࠴ࡶ࠰ࡺࡷࠬ㔥")]
			#,l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ㔦")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡱࠪ㔧")]
			#,l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭㔨"):[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸࠬ㔩")]
			#,l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ㔪")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠮ࡤࡱࡰࠫ㔫")]
			#,l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭㔬")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣ࠯ࡵ࡫ࡳࡴ࡬ࡰࡳࡱ࠱ࡳࡳࡲࡩ࡯ࡧࠪ㔭")]    #	l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡶࡲࡰ࠰ࡦࡳࡲ࠭㔮")
			 l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㔯")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ㔰")]
			,l11ll1_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㔱")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬ㔲")]
			,l11ll1_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㔳")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬ࡹࡤࡱ࠳ࡴࡥࡵࠩ㔴")]
			,l11ll1_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㔵")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ㔶")]
			,l11ll1_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㔷")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ㔸")]
			,l11ll1_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㔹")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ㔺")]
			,l11ll1_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㔻")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭㔼")]
			,l11ll1_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㔽")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ㔾")]
			,l11ll1_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㔿")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ㕀")]
			,l11ll1_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㕁")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ㕂")]
			,l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㕃")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭㕄")]
			,l11ll1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㕅")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ㕆")]
			,l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ㕇")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡤࡦࡩࡵ࠮ࡤࡱࡰࠫ㕈")]
			,l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ㕉")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡥ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡽ࡯ࡳ࡭ࠪ㕊")]
			,l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㕋")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦ࠳࡯࡯ࠨ㕌")]
			,l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㕍")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧ㕎")]
			,l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㕏")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵ࠰ࡦࡳࡲ࠭㕐")]
			,l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㕑")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳࡮ࡰࡹ࠱ࡧࡴࡳࠧ㕒")]
			,l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㕓")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ㕔"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ㕕")]
			,l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㕖")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧ㕗")]
			,l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㕘")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ㕙")]
			,l11ll1_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ㕚")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ㕛")]
			,l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㕜")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩ㕝")]
			,l11ll1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㕞")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫ㕟")]
			,l11ll1_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㕠")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡷ࡫ࡳࠫ㕡")]
			,l11ll1_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㕢")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭㕣")]
			,l11ll1_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㕤")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡦ࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩ㕥")]
			,l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㕦")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡹࡸ࠭㕧")]
			,l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㕨")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㕩"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㕪"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㕫"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㕬"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭㕭")]
			,l11ll1_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㕮")	:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩ㕯")]
			,l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ㕰")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ㕱")]
			,l11ll1_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ㕲")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ㕳"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࡫ࡷ࠲ࡱࡿ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ㕴")]
			,l11ll1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㕵")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡥࡷࡵࡺࡢ࠰ࡲࡲࡪ࠭㕶")]
			,l11ll1_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㕷")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡩࡡ࡮ࠩ㕸")]
			,l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㕹")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧ㕺")]
			,l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㕻")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷ࠱ࡦࡪࡺࠧ㕼")]
			,l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ㕽")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࠳ࡹࡨ࠵ࡷ࠱ࡲࡪࡽࡳࠨ㕾")]
			,l11ll1_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㕿")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪ㖀")]
			,l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㖁")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭㖂"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ㖃"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ㖄")]
			,l11ll1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㖅")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨ㖆")]
			,l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㖇")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡴࡶࡤࡨࠫ㖈")]
			,l11ll1_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㖉")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬ㖊")]
			,l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㖋")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ㖌")]
			#,l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㖍")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㖎"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㖏"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㖐"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㖑"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㖒"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㖓"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㖔")]
			#,l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㖕")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㖖"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㖗"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㖘"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㖙"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㖚"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㖛"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㖜")]
			#,l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㖝")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㖞"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㖟"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㖠"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㖡"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㖢"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㖣"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㖤")]
			#,l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㖥")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㖦"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㖧"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㖨"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㖩"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㖪"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㖫"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㖬")]
			#,l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㖭")	:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㖮"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㖯"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㖰"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㖱"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㖲"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㖳"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㖴")]
			,l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㖵")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㖶"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㖷"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㖸"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㖹"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㖺"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㖻"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㖼")]
			,l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭㖽")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㖾"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㖿"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㗀"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㗁"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㗂"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㗃"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㗄")]
			,l11ll1_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㗅")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㗆"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ㗇"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ㗈")]
			,l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ㗉")	:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㗊"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ㗋"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ㗌")]
			,l11ll1_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ㗍")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ㗎"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪࠩ㗏"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ㗐")]
			}
class l1ll1l1ll1l1_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11ll1l111l_l1_ = -1
	def onClick(self,l1lllll11l11_l1_):
		if l1lllll11l11_l1_>=9010: self.l11ll1l111l_l1_ = l1lllll11l11_l1_-9010
		self.delete()
	def l111l1111l1_l1_(self,*args):
		#self.getControl(9001).l1l1l1l11ll_l1_(header)
		#self.getControl(9009).l1lll1l1l11l_l1_(text)
		#self.getControl(9010).l1l1l1l11ll_l1_(l111111ll1l_l1_)
		#self.getControl(9011).l1l1l1l11ll_l1_(l1l1ll111ll1_l1_)
		#self.getControl(9012).l1l1l1l11ll_l1_(l11111l11l1_l1_)
		self.l111111ll1l_l1_,self.l1l1ll111ll1_l1_,self.l11111l11l1_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.l11111lll1l_l1_,self.l1ll11ll111l_l1_ = args[5],args[6]
		self.l1ll11ll1ll1_l1_,self.l1l11l1l1ll1_l1_,self.l1l1l11l1l11_l1_ = args[7],args[8],args[9]
		if self.l1l11l1l1ll1_l1_>0 or self.l1l1l11l1l11_l1_>0: self.l1ll111l1l11_l1_ = True
		else: self.l1ll111l1l11_l1_ = False
		self.l1lll1lll111_l1_,self.l111l1111ll_l1_ = l1l1l11ll1ll_l1_(self.l111111ll1l_l1_,self.l1l1ll111ll1_l1_,self.l11111l11l1_l1_,self.header,self.text,self.l11111lll1l_l1_,self.l1ll11ll111l_l1_,self.l1ll11ll1ll1_l1_,self.l1ll111l1l11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll1lll111_l1_)
		self.getControl(9050).setHeight(self.l111l1111ll_l1_)
		if not self.l1l1ll111ll1_l1_ and self.l111111ll1l_l1_ and self.l11111l11l1_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll1lll111_l1_,self.l111l1111ll_l1_
	def l11ll11ll1l_l1_(self):
		if self.l1l11l1l1ll1_l1_:
			import threading
			self.l11llll1ll1_l1_ = threading.Thread(target=self.l1ll1l11l111_l1_,args=())
			self.l11llll1ll1_l1_.start()
			#self.l11llll1ll1_l1_.join()
		else: self.enableButtons()
	def l1ll1l11l111_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11ll11111_l1_ in range(1,self.l1l11l1l1ll1_l1_+1):
			time.sleep(1)
			l1l11l1ll1ll_l1_ = int(100*l11ll11111_l1_/self.l1l11l1l1ll1_l1_)
			self.l1lll111l111_l1_(l1l11l1ll1ll_l1_)
			if self.l11ll1l111l_l1_>0: break
		self.enableButtons()
	def l11l1ll1l1l_l1_(self):
		if self.l1l1l11l1l11_l1_:
			import threading
			self.l1ll111111l1_l1_ = threading.Thread(target=self.l1lll1lllll1_l1_,args=())
			self.l1ll111111l1_l1_.start()
			#self.l1ll111111l1_l1_.join()
		else: self.enableButtons()
	def l1lll1lllll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l11l1l1ll1_l1_)
		for l11ll11111_l1_ in range(self.l1l1l11l1l11_l1_-1,-1,-1):
			time.sleep(1)
			l1l11l1ll1ll_l1_ = int(100*l11ll11111_l1_/self.l1l1l11l1l11_l1_)
			self.l1lll111l111_l1_(l1l11l1ll1ll_l1_)
			if self.l11ll1l111l_l1_>0: break
		if self.l1l1l11l1l11_l1_>0: self.l11ll1l111l_l1_ = 10
		self.delete()
	def l1lll111l111_l1_(self,l1l11l1ll1ll_l1_):
		self.l1lll1ll11l1_l1_ = l1l11l1ll1ll_l1_
		self.getControl(9020).setPercent(self.l1lll1ll11l1_l1_)
	def enableButtons(self):
		if self.l111111ll1l_l1_!=l11ll1_l1_ (u"ࠨࠩ㗑"): self.getControl(9010).setEnabled(True)
		if self.l1l1ll111ll1_l1_!=l11ll1_l1_ (u"ࠩࠪ㗒"): self.getControl(9011).setEnabled(True)
		if self.l11111l11l1_l1_!=l11ll1_l1_ (u"ࠪࠫ㗓"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll1lll111_l1_)
		except: pass
		#del self
	l11ll1_l1_ (u"ࠦࠧࠨࠍࠋࠋࡧࡩ࡫ࠦࡵࡱࡦࡤࡸࡪ࠮ࡳࡦ࡮ࡩ࠰ࡵ࡫ࡲࡤࡧࡱࡸ࠱࠰ࡡࡳࡩࡶ࠭࠿ࠓࠊࠊࠋࡷࡩࡽࡺࠠ࠾ࠢࡤࡶ࡬ࡹ࡛࠱࡟ࠐࠎࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡡࡳࡩࡶ࠭ࡃ࠷࠺ࠡࡶࡨࡼࡹࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࡢࡴࡪࡷࡠ࠷࡝ࠎࠌࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡦࡸࡧࡴࠫࡁ࠶࠿ࠦࡴࡦࡺࡷࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰ࡧࡲࡨࡵ࡞࠶ࡢࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡱࡧࡵࡧࡪࡴࡴ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷࠤࡂࠦࡰࡦࡴࡦࡩࡳࡺࠬࡵࡧࡻࡸࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡭࡫ࡩࡨࡪࡷࠤࡂࠦࡳࡦ࡮ࡩ࠲ࡨࡸࡥࡢࡶࡨࡗ࡭ࡵࡷࡊ࡯ࡤ࡫ࡪ࠮ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠴࠱ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠴࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯࠴࠯ࡷࡪࡲࡦ࠯ࡪࡨࡥࡩ࡫ࡲ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷ࠰ࡸ࡫࡬ࡧ࠰ࡳࡶࡴ࡬ࡩ࡭ࡧ࠯ࡷࡪࡲࡦ࠯ࡦ࡬ࡶࡪࡩࡴࡪࡱࡱ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡹ࡬ࡨࡹ࡮ࠬࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲࡸࡺࡩ࡮ࡧࡲࡹࡹ࠲ࡳࡦ࡮ࡩ࠲ࡨࡲ࡯ࡴࡧࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠑࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪࡳࡩࡷࡩࡥ࡯ࡶࠬࠑࠏࠏࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢ࡬ࡪ࡯ࡧࡩࡶࠐࠎࠎࠨࠢࠣ㗔")
class l111l1lll1l_l1_():
	def __init__(self,l1ll_l1_=False,l1ll111l1lll_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1ll111l1lll_l1_ = l1ll111l1lll_l1_
		self.l111lll1111_l1_,self.l11lll1111l_l1_ = [],[]
		self.l1lllll11l1l_l1_,self.l1lll11ll111_l1_ = {},{}
		self.l1111l1lll1_l1_ = []
		self.l1llll1llll1_l1_,self.l1l1l1111lll_l1_,self.l11ll111ll1_l1_ = {},{},{}
	def l111l1l1111_l1_(self,id,func,*args):
		id = str(id)
		self.l1lllll11l1l_l1_[id] = l11ll1_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㗕")
		if self.l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"࠭ࠧ㗖"),id)
		# l1111l1llll_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1111l1llll_l1_ 2 & 3
		import threading
		l11ll1l1l11_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1111l1lll1_l1_.append(l11ll1l1l11_l1_)
		#l11ll1l1l11_l1_.start()
		return l11ll1l1l11_l1_
	def start_new_thread(self,id,func,*args):
		l11ll1l1l11_l1_ = self.l111l1l1111_l1_(id,func,*args)
		l11ll1l1l11_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1llll1llll1_l1_[id] = time.time()
		#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㗗"),l11ll1_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢ࡬ࡨ࠿ࠦࠧ㗘")+id)
		try:
			#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㗙"),l11ll1_l1_ (u"ࠪࡉࡒࡇࡄ࠻࠼ࠣࠫ㗚")+str(func))
			self.l1lll11ll111_l1_[id] = func(*args)
			if l11ll1_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ㗛") in str(func) and not self.l1lll11ll111_l1_[id].succeeded:
				l1llll11l11l_l1_(l11ll1_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ㗜"))
			self.l111lll1111_l1_.append(id)
			self.l1lllll11l1l_l1_[id] = l11ll1_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㗝")
			#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㗞"),l11ll1_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠣ࡭ࡩࡀࠠࠨ㗟")+id)
		except Exception as err:
			#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㗠"),l11ll1_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣ࡭ࡩࡀࠠࠨ㗡")+id)
			if self.l1ll111l1lll_l1_:
				l1lllllll111_l1_ = traceback.format_exc()
				sys.stderr.write(l1lllllll111_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11lll1111l_l1_.append(id)
			self.l1lllll11l1l_l1_[id] = l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㗢")
		self.l1l1l1111lll_l1_[id] = time.time()
		self.l11ll111ll1_l1_[id] = self.l1l1l1111lll_l1_[id] - self.l1llll1llll1_l1_[id]
	def l1ll111l1ll1_l1_(self):
		for proc in self.l1111l1lll1_l1_:
			proc.start()
	def l1l11ll11111_l1_(self):
		while l11ll1_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㗣") in list(self.l1lllll11l1l_l1_.values()): time.sleep(1.000)
def l1ll11l1l11l_l1_():
	l1l1llll11ll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㗤"))
	l111111l11l_l1_ = True
	if l1l1llll11ll_l1_==addon_version:
		status = l11ll1_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ㗥")
		l111111l11l_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭㗦")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11ll1_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ㗧")
	else:
		status = l11ll1_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ㗨")
		l11l111l11l_l1_ = [l11ll1_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ㗩"),l11ll1_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ㗪"),l11ll1_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ㗫"),l11ll1_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ㗬"),l11ll1_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ㗭"),l11ll1_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭㗮"),l11ll1_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ㗯"),l11ll1_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ㗰"),l11ll1_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ㗱")]
		l1lll111l1l1_l1_ = l11l111l11l_l1_[-1]
		l11111l1ll1_l1_ = l1l11l1ll11l_l1_(l1lll111l1l1_l1_)
		l1ll1ll1ll11_l1_ = l1l11l1ll11l_l1_(addon_version)
		if l1ll1ll1ll11_l1_>l11111l1ll1_l1_:
			status = l11ll1_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㗲")
			l11ll1_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡧ࡫࡯ࡩࡸࠦ࠽ࠡࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲࠪࠏࠍࠍࠎࠏࡦࡪ࡮ࡨࡷࠥࡃࠠࡴࡱࡵࡸࡪࡪࠨࡧ࡫࡯ࡩࡸ࠲ࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠮ࠓࠊࠊࠋࠌࡪࡴࡸࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡶ࠾ࠒࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡥࡣࡷࡥࡤ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡥ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࠪ࠲ࡩࡨࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢࡡࠫ࠲࠯ࡅࠩ࡝࠰ࡧࡦࠬ࠲ࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯࡝࠳ࡡࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࡡࡦࡳࡲࡶࡡࡳࡧࠣࡁࠥ࡜ࡅࡓࡕࡌࡓࡓࡥࡃࡐࡏࡓࡅࡗࡋ࡟ࡑࡃࡕࡗࡊࡘࠨࡰ࡮ࡧࡣࡻ࡫ࡲࡴ࡫ࡲࡲ࠮ࠓࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬࠦࡩ࡯ࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠾ࠒࠐࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠾࠾࡮ࡤࡷࡹ࡬ࡵ࡭࡮ࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩ࠿ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡰ࡮ࡧࡣࡩࡨࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩࠦࡃ࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠾ࠥࡵࡳ࠯ࡴࡨࡲࡦࡳࡥࠩࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩ࠱ࡳࡡࡪࡰࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡳࡵࡣࡷࡹࡸࠦ࠽ࠡࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠑࠏࠏࠉࠊࠋࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠉࠊࠤࠥࠦ㗳")
	return status,l111111l11l_l1_
def l1llll111lll_l1_(l1ll1111l1l_l1_,l1ll1ll111l1_l1_):
	succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_ = True,False,False
	type,name,l1l111lllll_l1_,mode,l1l11l1l111_l1_,l11lll1l11l_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
	l1l1l1ll11ll_l1_ = type,name,l1l111lllll_l1_,mode,l1l11l1l111_l1_,l11lll1l11l_l1_,text,l11ll1_l1_ (u"ࠨࠩ㗴"),l1ll1ll1l11_l1_
	l1ll1111l111_l1_ = int(mode)
	l111l111l1l_l1_ = int(l1ll1111l111_l1_%10)
	l1ll1111l11l_l1_ = int(l1ll1111l111_l1_/10)
	l1l11l1lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㗵"))
	l1llllllll1l_l1_,l111111l11l_l1_ = l1ll11l1l11l_l1_()
	if l111111l11l_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㗶"),l11ll1_l1_ (u"ࠫࠬ㗷"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㗸"),l11ll1_l1_ (u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭㗹")+addon_version)
		#settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ㗺"),l11ll1_l1_ (u"ࠨࠩ㗻"))
		#settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩ㗼"),l11ll1_l1_ (u"ࠪࠫ㗽"))
		#settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭㗾"),l11ll1_l1_ (u"ࠬ࠭㗿"))
		#settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㘀"),l11ll1_l1_ (u"ࠧࠨ㘁"))
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㘂"),l11ll1_l1_ (u"ࠩࠪ㘃"))
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴ࠰࡯ࡥࡸࡺࡴࡪ࡯ࡨࠫ㘄"),l11ll1_l1_ (u"ࠫࠬ㘅"))
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㘆"),l11ll1_l1_ (u"࠭ࠧ㘇"))
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㘈"),l11ll1_l1_ (u"ࠨࠩ㘉"))
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ㘊"),l11ll1_l1_ (u"ࠪࠫ㘋"))
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ㘌"),l11ll1_l1_ (u"ࠬ࠭㘍"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㘎"),l11ll1_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㘏"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㘐"),l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㘑"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㘒"),l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡉࠩ㘓"))
		if not l1l11l1lllll_l1_: settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡲࡺࡹ࡟ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㘔"),l11ll1_l1_ (u"࠭ࠧ㘕"))
		#l1l1llll11ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㘖"))
		#if l1l1llll11ll_l1_:
		#	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㘗"),l11ll1_l1_ (u"ࠩࠪ㘘"))
		#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㘙"))
		#	return
		#l11l111l1l1_l1_([main_dbfile])
		import l1l111l11ll_l1_
		if l1llllllll1l_l1_==l11ll1_l1_ (u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ㘚"):
			LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㘛"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㘜")+addon_path+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㘝"))
			DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㘞"),l11ll1_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㘟"))
			for l1lll11l1l1l_l1_ in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㘠"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ㘡")+str(l1lll11l1l1l_l1_))
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㘢"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭㘣")+str(l1lll11l1l1l_l1_))
		else:
			LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㘤"),l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㘥")+addon_path+l11ll1_l1_ (u"ࠩࠣࡡࠬ㘦"))
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㘧"),l11ll1_l1_ (u"ࠫࠬ㘨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㘩"),l11ll1_l1_ (u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ㘪"))
			l11l111l1l1_l1_()
			FIX_ALL_DATABASES(False)
			l111l1l1lll_l1_ = l1l11l1l11l_l1_(32)
			l1l111l11ll_l1_.l1l1l1llll1l_l1_()
			l1l111l11ll_l1_.l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㘫"),False)
			l1l111l11ll_l1_.l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㘬"),False)
			l1l111l11ll_l1_.l1lll1ll1lll_l1_(False)
			l1l111l11ll_l1_.l1l1l1ll111l_l1_(False)
			l1l111l11ll_l1_.l1l1l1lll1ll_l1_(l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㘭"),l11ll1_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ㘮"),False)
			l11ll1_l1_ (u"ࠦࠧࠨࠍࠋࠋࠌࠍࡹࡸࡹ࠻ࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴࡨ࡬ࡰࡪ࠸ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡷࡶࡩࡷ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ࠮ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ࠭ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ࠯ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ࠭ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠷ࠦ࠽ࠡࡺࡥࡱࡨࡧࡤࡥࡱࡱ࠲ࡆࡪࡤࡰࡰࠫ࡭ࡩࡃࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧࠪࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠴࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨ࡭ࡲࡨ࡮ࡵ࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡲࡷࡤࡰ࡮ࡺࡹ࠯ࡣࡶ࡯ࠬ࠲ࠧࡵࡴࡸࡩࠬ࠯ࠍࠋࠋࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠐࠎࠎࠏࠉࠣࠤࠥ㘯")
			try:
				l111lllll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㘰"),l11ll1_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㘱"),l11ll1_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ㘲"),l11ll1_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㘳"))
				l1l11llll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭㘴"))
				l1l11llll11l_l1_.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ㘵"),l11ll1_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ㘶"))
			except: pass
			try:
				l111lllll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㘷"),l11ll1_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㘸"),l11ll1_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ㘹"),l11ll1_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㘺"))
				l1l11llll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭㘻"))
				l1l11llll11l_l1_.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭㘼"),l11ll1_l1_ (u"ࠫ࠸࠭㘽"))
			except: pass
			try:
				l111lllll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㘾"),l11ll1_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㘿"),l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㙀"),l11ll1_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㙁"))
				l1l11llll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㙂"))
				l1l11llll11l_l1_.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ㙃"),l11ll1_l1_ (u"ࠫ࠷࠭㙄"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㙅"),l11ll1_l1_ (u"࠭ࠧ㙆"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㙇"),l11ll1_l1_ (u"ࠨวำห้ࠥๆหࠢอืฯิฯๆࠢัำ๊ฯࠠแࡋࡓࡘ࡛ࠦวๅ็๋ะํีษࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦสๅไสส๏อࠠษฮ็ฬ๋ࠥไโษอࠤๅࡏࡐࡕࡘࠣะิ๐ฯสࠩ㙈"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1lllll1l11l_l1_):
			#	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㙉"),l11ll1_l1_ (u"ࠪࠫ㙊"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㙋"),l11ll1_l1_ (u"ࠬหะศࠢๆ๊ฯࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡓ࠳ࡖࠢส่๊๎ฬ้ัฬࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦแิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢอ่็อฦ๋ษࠣฬั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㙌"))
			#	import l1l1l11l11ll_l1_
			#	l1l1l11l11ll_l1_.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l1l111ll111_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l11l1ll1l1_l1_)
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㙍"),addon_version)
		l1l111l11ll_l1_.l11l1l1llll_l1_(False)
		#return
	#text = text.replace(l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㙎"),l11ll1_l1_ (u"ࠨࠩ㙏"))
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㙐"))
	l11l1lll1l_l1_ = RESTORE_PATH_NAME(l1ll1ll111l1_l1_)
	l1l1111ll11_l1_ = RESTORE_PATH_NAME(name)
	l1llll11l1ll_l1_ = [0,15,17,19,26,34,50,53]
	l1ll11ll1l11_l1_ = [0,15,17,19,26,34,50,53]
	l11ll11l1ll_l1_ = l1ll1111l11l_l1_ not in l1ll11ll1l11_l1_
	l1l11ll111l1_l1_ = l1ll1111l11l_l1_ in [23,28,71,72]
	l1ll1l1ll1ll_l1_ = l1ll1111l111_l1_ in [265,270]
	l1lll11llll1_l1_ = (l11ll11l1ll_l1_ or l1l11ll111l1_l1_) and not l1ll1l1ll1ll_l1_
	l11l1111l11_l1_ = l1l11llll1_l1_!=l11ll1_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㙑") and (l1l11llll1_l1_!=l11ll1_l1_ (u"ࠫࠬ㙒") or context==l11ll1_l1_ (u"ࠬ࠭㙓"))
	l1ll111l1111_l1_ = l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ㙔") in l1l11llll1_l1_
	l1l1l1ll1ll1_l1_ = l1ll1111l111_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l111l111l1l_l1_==9 or l1ll1111l111_l1_ in [145,516,523]
	l11l1lll1ll_l1_ = not l1l1l1ll1ll1_l1_
	l111ll1ll1l_l1_ = not SEARCH
	l1l1lll1lll1_l1_ = l11l1lll1l_l1_ in [l11ll1_l1_ (u"ࠧࠨ㙕"),l11ll1_l1_ (u"ࠨ࠰࠱ࠫ㙖")]
	l11111l111l_l1_ = l1l1lll1lll1_l1_ or l11l1lll1ll_l1_
	l1llll11llll_l1_ = l1l1lll1lll1_l1_ or l111ll1ll1l_l1_ or l1ll111l1111_l1_
	l1l1l111l1ll_l1_ = l1ll1111l111_l1_ not in [260,265,270,330,540]
	if l1l11l1lllll_l1_: l111111lll1_l1_ = SEARCH or l1l1l1ll1ll1_l1_
	else: l111111lll1_l1_ = True
	l1l1l1llll_l1_ = l1ll1111l11l_l1_ in [74,75]
	l11l1ll111l_l1_ = l1ll1111l111_l1_ in [280,720]
	l11111lllll_l1_ = not l1l1l1llll_l1_ and not l11l1ll111l_l1_
	l1ll1ll1llll_l1_ = l11111l111l_l1_ and l1llll11llll_l1_ and l1l1l111l1ll_l1_ and l111111lll1_l1_ and l11111lllll_l1_
	l1ll11ll1l1l_l1_ = l1l1l111l1ll_l1_ and l111111lll1_l1_ and l11111lllll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㙗"),l11ll1_l1_ (u"ࠪࠫ㙘"),l11ll1_l1_ (u"ࠫࠬ㙙"),type+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㙚")+l1l11llll1_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㙛")+str(l1ll11ll1l1l_l1_))
	if 1 and l11l1111l11_l1_ and l1ll1ll1llll_l1_:
		l1lll11l1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㙜"),l11ll1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊ࠭㙝"),l1l1l1ll11ll_l1_)
		if l1lll11l1l11_l1_:
			#xbmcgui.Dialog().notification(l11ll1_l1_ (u"ࠩࠪ㙞"),l11ll1_l1_ (u"ࠪࡶࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࠪ㙟"),l11ll1_l1_ (u"ࠫࠬ㙠"),100,False)
			LOG_THIS(l11ll1_l1_ (u"ࠬ࠭㙡"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠡࠢࠣࡐࡴࡧࡤࡪࡰࡪࠤࡲ࡫࡮ࡶࠢࡩࡶࡴࡳࠠࡤࡣࡦ࡬ࡪ࠭㙢"))
			if 1 and l1ll111l1111_l1_:
				#xbmcgui.Dialog().notification(l11ll1_l1_ (u"ࠧࠨ㙣"),l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡹࡪࡰࡪࠤ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ㙤"),l11ll1_l1_ (u"ࠩࠪ㙥"),100,False)
				l11l1ll11ll_l1_ = []
				import l1l1l11lll1l_l1_,FAVORITES
				l1ll1ll11l11_l1_ = l1l1l11lll1l_l1_.l1lll111llll_l1_
				l11l1l1ll11_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lllll1l111_l1_ = l1l11llll1_l1_
				l111ll11l11_l1_,l111lll111l_l1_,l1ll1l1lll11_l1_,l1ll11111111_l1_,l1l1l11lll11_l1_,l1llll1111ll_l1_,l111lll11l1_l1_,l1ll11lll1l1_l1_,l1lll1llllll_l1_ = EXTRACT_KODI_PATH(l1lllll1l111_l1_)
				l1ll1ll11lll_l1_ = l111ll11l11_l1_,l111lll111l_l1_,l1ll1l1lll11_l1_,l1ll11111111_l1_,l1l1l11lll11_l1_,l1llll1111ll_l1_,l111lll11l1_l1_,l11ll1_l1_ (u"ࠪࠫ㙦"),l1lll1llllll_l1_
				#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㙧"),str(l1ll1ll11lll_l1_))
				for l1ll1l1l1111_l1_ in l1lll11l1l11_l1_:
					l1l1ll1ll111_l1_ = l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠬࡳࡥ࡯ࡷࡌࡸࡪࡳࠧ㙨")]
					#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㙩"),str(l1l1ll1ll111_l1_))
					if l1l1ll1ll111_l1_==l1ll1ll11lll_l1_ or l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ㙪")] in [265,270]:
						l1ll1l1l1111_l1_ = GET_LIST_ITEM(l1l1ll1ll111_l1_,l1ll1ll11l11_l1_,l11l1l1ll11_l1_)
						if l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ㙫")]:
							#xbmcgui.Dialog().notification(l11ll1_l1_ (u"ࠩࠪ㙬"),l11ll1_l1_ (u"ࠪࡹࡵࡪࡡࡵ࡫ࡱ࡫ࠥࡩ࡯࡯ࡶࡨࡼࡹ࠭㙭"),l11ll1_l1_ (u"ࠫࠬ㙮"),100,False)
							l1l1llll1l11_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l11l1l1ll11_l1_,l1l1ll1ll111_l1_,l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭㙯")])
							#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㙰"),str(l1l1llll1l11_l1_))
							#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ㙱"),str(l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ㙲")]))
							l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ㙳")] = l1l1llll1l11_l1_+l1ll1l1l1111_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ㙴")]
					l11l1ll11ll_l1_.append(l1ll1l1l1111_l1_)
				settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㙵"),l11ll1_l1_ (u"ࠬ࠭㙶"))
				if type==l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙷"): WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ㙸"),l1l1l1ll11ll_l1_,l11l1ll11ll_l1_,REGULAR_CACHE)
			else: l11l1ll11ll_l1_ = l1lll11l1l11_l1_
			if type==l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㙹") and l11l1lll1l_l1_!=l11ll1_l1_ (u"ࠩ࠱࠲ࠬ㙺") and l1lll11llll1_l1_: l1l11l11lll_l1_()
			l111llll1l1_l1_ = CREATE_KODI_MENU(l1l1l1ll11ll_l1_,l11l1ll11ll_l1_,succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_)
			#xbmcgui.Dialog().notification(l11ll1_l1_ (u"ࠪࠫ㙻"),l11ll1_l1_ (u"ࠫࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦ࡭ࡦࡰࡸࠫ㙼"),l11ll1_l1_ (u"ࠬ࠭㙽"),100,False)
			return
	elif type==l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙾") and l1l11llll1_l1_==l11ll1_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㙿") and l1ll11ll1l1l_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㚀"),l11ll1_l1_ (u"ࠩ࠱ࠤࠥࠦࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࠤࠥࠦࡄࡦ࡮ࡨࡸ࡮ࡴࡧࠡࡱ࡯ࡨࠥࡩࡡࡤࡪࡨࡨࠥࡳࡥ࡯ࡷࠪ㚁"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ㚂"),l1l1l1ll11ll_l1_)
	#context = l11ll1_l1_ (u"ࠫࠬ㚃")
	if l11ll1_l1_ (u"ࠬࡥࠧ㚄") in context: l1ll11ll1lll_l1_,l1l1l111llll_l1_ = context.split(l11ll1_l1_ (u"࠭࡟ࠨ㚅"),1)
	else: l1ll11ll1lll_l1_,l1l1l111llll_l1_ = context,l11ll1_l1_ (u"ࠧࠨ㚆")
	if l1ll11ll1lll_l1_ in [l11ll1_l1_ (u"ࠨ࠳ࠪ㚇"),l11ll1_l1_ (u"ࠩ࠵ࠫ㚈"),l11ll1_l1_ (u"ࠪ࠷ࠬ㚉"),l11ll1_l1_ (u"ࠫ࠹࠭㚊"),l11ll1_l1_ (u"ࠬ࠻ࠧ㚋")] and l1l1l111llll_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㚌") l11l11ll1l_l1_ l1l1l1111ll1_l1_ l1l11llllll1_l1_ is no addon_handle l1l111ll1_l1_ to l11l11111ll_l1_ for l1lll1l1111l_l1_ directory
		#l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠪ㚍") l11l11ll1l_l1_ to open a menu list using l1l1l1lll111_l1_ addon_path
		#xbmc.executebuiltin(l11ll1_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ㚎")+sys.argv[0]+addon_path.split(l11ll1_l1_ (u"ࠩࠩࡧࡴࡴࡴࡦࡺࡷࡁࠬ㚏"))[0]+l11ll1_l1_ (u"ࠪࠪࡨࡵ࡮ࡵࡧࡻࡸࡂ࠶ࠧ㚐")+l11ll1_l1_ (u"ࠦ࠮ࠨ㚑"))
		#xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ㚒")+addon_id+l11ll1_l1_ (u"࠭࠯ࡀࡶࡨࡼࡹࡃ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠪࠩ㚓"))
		# l1111l11ll_l1_ not remove addon_path .. it is needed to update l1l1llll1l1l_l1_ status
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㚔"),addon_path)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㚕"))
		return
	elif l1ll11ll1lll_l1_==l11ll1_l1_ (u"ࠩ࠹ࠫ㚖"):
		if l1l1l111llll_l1_==l11ll1_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㚗"): l1llllll_l1_(l11ll1_l1_ (u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫ㚘"),l11ll1_l1_ (u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬ㚙"))
		elif l1l1l111llll_l1_==l11ll1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊ࠭㚚"): l1ll1111l111_l1_ = 334
		results = l1l1ll1ll1ll_l1_(type,l1l1111ll11_l1_,l1l111lllll_l1_,l1ll1111l111_l1_,l1l11l1l111_l1_,l11lll1l11l_l1_,text,context,l1ll1ll1l11_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㚛"))
		return
	elif context==l11ll1_l1_ (u"ࠨ࠹ࠪ㚜"):
		import l1lll11ll1l_l1_
		l1lll11ll1l_l1_.l1ll11111l1_l1_()
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㚝"))
		return
	elif context==l11ll1_l1_ (u"ࠪ࠼ࠬ㚞"):
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㚟")+addon_id+l11ll1_l1_ (u"ࠬࡅ࡭ࡰࡦࡨࡁࠬ㚠")+str(mode)+l11ll1_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭㚡"))
		return
	elif context==l11ll1_l1_ (u"ࠧ࠺ࠩ㚢"):
		# l1ll11l111l1_l1_ update the l1l11ll1ll11_l1_ menu
		#results = l1l1ll1ll1ll_l1_(type,l1l1111ll11_l1_,l1l111lllll_l1_,mode,l1l11l1l111_l1_,l11lll1l11l_l1_,text,context,l1ll1ll1l11_l1_)
		# l1ll11l111l1_l1_ update the l1lll11ll11l_l1_ menu
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㚣"),l11ll1_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ㚤"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㚥"))
		return
	if settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㚦")) not in [l11ll1_l1_ (u"ࠬࡇࡕࡕࡑࠪ㚧"),l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ㚨"),l11ll1_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ㚩")]: settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㚪"),l11ll1_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㚫"))
	if not settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ㚬")): settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ㚭"),l1lllll11111_l1_[0])
	l1l1l111ll11_l1_ = l1llll111ll1_l1_(settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㚮")))
	l1l1l111ll11_l1_ = 0 if not l1l1l111ll11_l1_ else int(l1l1l111ll11_l1_)
	if not l1l1l111ll11_l1_ or now-l1l1l111ll11_l1_<=0 or now-l1l1l111ll11_l1_>l1ll1ll1l_l1_:
		l11l1llll1l_l1_ = l111l1l11ll_l1_(True,False)
	l11ll111lll_l1_ = l1llll111ll1_l1_(settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㚯")))
	l11ll111lll_l1_ = 0 if not l11ll111lll_l1_ else int(l11ll111lll_l1_)
	l111ll1lll1_l1_ = l1llll111ll1_l1_(settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡸ࡮ࡳࡥࠨ㚰")))
	l111ll1lll1_l1_ = 0 if not l111ll1lll1_l1_ else int(l111ll1lll1_l1_)
	if not l11ll111lll_l1_ or not l111ll1lll1_l1_ or now-l111ll1lll1_l1_<0 or now-l111ll1lll1_l1_>l11ll111lll_l1_:
		auth = 1
		if not l11lllll111_l1_(l11ll1_l1_ (u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩ㚱")):
			# https://www.l1llll1ll1l1_l1_.com/l1l1l1lllll1_l1_/l1111llllll_l1_
			# unescapeHTML(l11ll1_l1_ (u"ࠩࠣࠪࠨࡾ࠲࠷࠵ࡅ࠿ࠥࠬࠣࡹ࠴࠺࠵ࡉࡁࠠࠧࠥࡻ࠶࠻࠸ࡁ࠼ࠢࠩࠧࡽ࠸࠶࠴ࡄ࠾ࠫ㚲"))
			#l1ll1ll1l1l1_l1_ = l11ll1_l1_ (u"ࠪ⸿ࠥ⼣ࠠࠡ⾌ࠣࠤⸯࠦ⸻ࠨ㚳")
			#l1lll1llll11_l1_ = l11ll1_l1_ (u"ࠫ⹀ࠦ⼝ࠡࠢ⾎ࠤࠥ⸰ࠠ⸼ࠩ㚴")
			l1l1ll1ll1l1_l1_ = l11ll1111ll_l1_(True)
			if len(l1l1ll1ll1l1_l1_)>1:
				LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㚵"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㚶")+addon_path+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㚷"))
				id,l1l11l1l1lll_l1_,l1l11lllll1l_l1_,l111l1ll1l1_l1_,l111l1l111l_l1_,reason = l1l1ll1ll1l1_l1_[0]
				#if l11ll1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㚸") in reason: l1ll11l1ll11_l1_,l1ll11l1ll1l_l1_,l1ll11l1lll1_l1_ = reason.split(l11ll1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㚹"),2)
				#else: l1ll11l1ll11_l1_,l1ll11l1ll1l_l1_,l1ll11l1lll1_l1_ = reason,reason,reason
				l1lllll11ll1_l1_,l1lllll11lll_l1_ = l111l1ll1l1_l1_.split(l11ll1_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ㚺"))
				del l1l1ll1ll1l1_l1_[0]
				l1ll1111l1l1_l1_ = random.sample(l1l1ll1ll1l1_l1_,1)
				id,l1l11l1l1lll_l1_,l1l11lllll1l_l1_,l111l1ll1l1_l1_,l111l1l111l_l1_,reason = l1ll1111l1l1_l1_[0]
				l1l11lllll1l_l1_ = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥࡀࠠࠨ㚻")+id+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㚼")+l1l11lllll1l_l1_
				l111l1l111l_l1_ = l11ll1_l1_ (u"࠭ราีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠫ㚽")
				l111111ll1l_l1_,l1l1ll111ll1_l1_ = l111l1ll1l1_l1_,l111l1l111l_l1_
				l11l111l_l1_ = [l111111ll1l_l1_,l1l1ll111ll1_l1_,l1lll1ll111l_l1_]
				choice = -9
				while choice<0:
					l111lll1l1l_l1_ = random.sample(l11l111l_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ㚾"),l111lll1l1l_l1_[0],l111lll1l1l_l1_[1],l111lll1l1l_l1_[2],l1lllll11ll1_l1_,l1l11lllll1l_l1_,l11ll1_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㚿"),10,60)
					if choice==10: break
					if choice>=0 and l111lll1l1l_l1_[choice]==l11l111l_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ㛀"),l11ll1_l1_ (u"ࠪࠫ㛁"),l11ll1_l1_ (u"ࠫ฾๎ฯสࠩ㛂"),l11ll1_l1_ (u"ࠬ࠭㛃"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㛄"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ั๎วษࠢั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ㛅")+reason,l11ll1_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㛆"),20)
						import l1l111l11ll_l1_
						l1l111l11ll_l1_.l1ll111lll1l_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l111lll1l1l_l1_[choice]==l11l111l_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ㛇"),l11ll1_l1_ (u"ࠪࠫ㛈"),l1lll1ll111l_l1_,l11ll1_l1_ (u"ࠫࠬ㛉"),l1lllll11ll1_l1_,l1l11lllll1l_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㛊")+l11l111l_l1_[0]+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㛋"),l11ll1_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㛌"),30)
					if choice==-1: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㛍"),l11ll1_l1_ (u"ࠩࠪ㛎"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㛏"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่้ิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ㛐"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡶ࡬ࡱࡪ࠭㛑"),l1ll11l11111_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㛒"),l11ll1_l1_ (u"ࠧࡂࡗࡗࡌࠬ㛓"),auth,PERMANENT_CACHE)
	# l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㛔")	l11l11111ll_l1_ file to read/write the l1l1ll1l1l1l_l1_ menu list
	# l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㛕")		no l11ll1lll1l_l1_ l1l1l1ll1111_l1_ to the l1l1ll1l1l1l_l1_ menu list
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊࡕࡌࡘࡊ࡙࡟ࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡌࡘࡊ࡙࡟ࡎࡑࡇࡉࡘࠦࡡ࡯ࡦࠣࡱࡴࡪࡥ࠲࠿ࡀ࠽ࠒࠐࠉࡐࡖࡋࡉࡗࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠻ࠬ࠶࠳࠹࠰࠺࠸࠳࡞ࠏࠍࠍࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁ࡙ࠥࡉࡕࡇࡖࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡳࡷࠦࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠑࠏࠏࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠷ࡃ࠽࠲࠸ࠣࡥࡳࡪࠠ࡮ࡱࡧࡩ࠵ࠧ࠽࠲࠸࠳ࠑࠏࠏ࡙ࡐࡗࡗ࡙ࡇࡋ࡟ࡎࡇࡑ࡙ࡘࠦ࠽ࠡ࡯ࡲࡨࡪ࠶ࠠࡪࡰࠣ࡟࠶࠺࠴࡞ࠏࠍࠍࠨࡴࡡ࡮ࡧࡢࠤࡂࠦࡃࡍࡇࡄࡒࡤࡓࡅࡏࡗࡢࡐࡆࡈࡅࡍࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡳࡧ࡭ࡦࡡࠣࡁࠥࡘࡅࡔࡖࡒࡖࡊࡥࡐࡂࡖࡋࡣࡓࡇࡍࡆࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡗࡋࡍࡆࡏࡅࡉࡗࡥࡒࡆࡕࡘࡐ࡙࡙࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣࡖࡆࡔࡄࡐࡏࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠒࠐࠉࡪࡨࠣࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗ࠿ࠓࠊࠊࠋࠦ࡭࡫ࠦࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗ࠿ࠦࡣࡰࡰࡧ࠵ࠥࡃࠠࠩ࡯ࡨࡲࡺࡥ࡬ࡢࡤࡨࡰࠥ࡯࡮ࠡ࡝ࠪ࠲࠳࠭ࠬࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫࡢ࠯ࠍࠋࠋࠌࠧࡪࡲࡩࡧࠢࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓ࠻ࠢࡦࡳࡳࡪ࠱ࠡ࠿ࠣࠬࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࠎ࡯ࡦࠡࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠠࡪࡰࠣࡸࡪࡾࡴࠡࡣࡱࡨࠥࡳࡥ࡯ࡷࡢࡰࡦࡨࡥ࡭ࠣࡀࡲࡦࡳࡥࡠࠢࡤࡲࡩࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨ࡭ࡣࡶࡸࡲ࡫࡮ࡶࡨ࡬ࡰࡪ࠯࠺ࠎࠌࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠲ࠥࠦࠠࡓࡧࡤࡨ࡮ࡴࡧࠡ࡮ࡤࡷࡹࠦ࡭ࡦࡰࡸࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ࠭ࡤࡨࡩࡵ࡮ࡠࡲࡤࡸ࡭࠱ࠧࠡ࡟ࠪ࠭ࠒࠐࠉࠊࠋࡲࡰࡩࡌࡉࡍࡇࠣࡁࠥࡵࡰࡦࡰࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦ࠮ࠪࡶࡧ࠭ࠩ࠯ࡴࡨࡥࡩ࠮ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡱࡪࡆࡊࡎࡈ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠒࠐࠉࠊࠋࡰࡩࡳࡻࡉࡵࡧࡰࡷࡑࡏࡓࡕ࡝࠽ࡡࠥࡃࠠࡆࡘࡄࡐ࠭࠭࡬ࡪࡵࡷࠫ࠱ࡵ࡬ࡥࡈࡌࡐࡊ࠯ࠍࠋࠋࠌࡩࡱࡹࡥ࠻ࠏࠍࠍࠎࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠳࡙ࠦࠠࠡࡵ࡭ࡹ࡯࡮ࡨࠢ࡯ࡥࡸࡺࠠ࡮ࡧࡱࡹࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ࠮ࡥࡩࡪ࡯࡯ࡡࡳࡥࡹ࡮ࠫࠨࠢࡠࠫ࠮ࠓࠊࠊࠋࠌࡶࡪࡹࡵ࡭ࡶࡶࠤࡂࠦࡍࡂࡋࡑࡣࡉࡏࡓࡑࡃࡗࡇࡍࡋࡒࠩࡶࡼࡴࡪ࠲࡮ࡢ࡯ࡨࡣ࠱ࡻࡲ࡭ࡡ࠯ࡱࡴࡪࡥ࠭࡫ࡰࡥ࡬࡫࡟࠭ࡲࡤ࡫ࡪࡥࠬࡵࡧࡻࡸ࠱ࡩ࡯࡯ࡶࡨࡼࡹ࠲ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠪࠏࠍࠍࠎࠏ࡮ࡦࡹࡉࡍࡑࡋࠠ࠾ࠢࡶࡸࡷ࠮࡭ࡦࡰࡸࡍࡹ࡫࡭ࡴࡎࡌࡗ࡙࠯ࠍࠋࠋࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦ࡮ࡦࡹࡉࡍࡑࡋࠠ࠾ࠢࡱࡩࡼࡌࡉࡍࡇ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠑࠏࠏࠉࠊࡱࡳࡩࡳ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠱࠭ࡷࡣࠩࠬ࠲ࡼࡸࡩࡵࡧࠫࡲࡪࡽࡆࡊࡎࡈ࠭ࠒࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡵࡸࡰࡹࡹࠠ࠾ࠢࡐࡅࡎࡔ࡟ࡅࡋࡖࡔࡆ࡚ࡃࡉࡇࡕࠬࡹࡿࡰࡦ࠮ࡱࡥࡲ࡫࡟࠭ࡷࡵࡰࡤ࠲࡭ࡰࡦࡨ࠰࡮ࡳࡡࡨࡧࡢ࠰ࡵࡧࡧࡦࡡ࠯ࡸࡪࡾࡴ࠭ࡥࡲࡲࡹ࡫ࡸࡵ࠮࡬ࡲ࡫ࡵࡤࡪࡥࡷ࠭ࠒࠐࠉࠣࠤࠥ㛖")
	results = l1l1ll1ll1ll_l1_(type,l1l1111ll11_l1_,l1l111lllll_l1_,mode,l1l11l1l111_l1_,l11lll1l11l_l1_,text,context,l1ll1ll1l11_l1_)
	# l111ll1llll_l1_ l1111111ll1_l1_: succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_ = True,False,True
	# l1llllll1ll1_l1_ = True => l1lll11l111l_l1_ this list is l1l1lllll1l1_l1_ and will exit to main menu
	# l1llllll1ll1_l1_ = False => l1lll11l111l_l1_ this list is l1111ll11l1_l1_ and will exit to l1l1ll1l1l1l_l1_ menu
	# l11l1l11lll_l1_ = True => will cause the l1l11l1llll1_l1_ status to l1l11ll11l1l_l1_ l1ll1111l1ll_l1_
	# l11l1l11lll_l1_ = False => will l1ll11111l11_l1_ the l1l11l1llll1_l1_ status to l11l11111l1_l1_ l11111l1l11_l1_
	#succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_ = True,False,True
	#if not l11111llll1_l1_: l11l1l11lll_l1_ = False
	if l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㛗") in text: l1llllll1ll1_l1_ = True
	if type==l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㛘"):
		if l11l1lll1l_l1_!=l11ll1_l1_ (u"࠭࠮࠯ࠩ㛙") and l1lll11llll1_l1_: l1l11l11lll_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ㛚"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㛛"),l11ll1_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ㛜")) or l1ll1111l111_l1_ not in l1llll11l1ll_l1_) and not l11lllll111_l1_(l11ll1_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㛝")):
				import l1l1l11lll1l_l1_
				l1lll11l1l11_l1_ = GET_ALL_LIST_ITEMS(l1l1l11lll1l_l1_.l1lll111llll_l1_)
				l111llll1l1_l1_ = CREATE_KODI_MENU(l1l1l1ll11ll_l1_,l1lll11l1l11_l1_,succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_)
				if 1 and l1lll11l1l11_l1_ and l1ll11ll1l1l_l1_:
					WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࠩ㛞"),l1l1l1ll11ll_l1_,l1lll11l1l11_l1_,REGULAR_CACHE)
				#elif 1 and not l1lll11l1l11_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࠪ㛟"),l1l1l1ll11ll_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㛠")+addon_id+l11ll1_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㛡"),xbmcgui.ListItem(l11ll1_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧ㛢")))
				xbmcplugin.addDirectoryItem(addon_handle,l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㛣")+addon_id+l11ll1_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ㛤"),xbmcgui.ListItem(l11ll1_l1_ (u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪ㛥")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_)
	return
def l1l1ll1ll1ll_l1_(type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_):
	l1ll1111l111_l1_ = int(mode)
	l1ll1111l11l_l1_ = int(l1ll1111l111_l1_//10)
	if   l1ll1111l11l_l1_==0:  import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==1:  import l1111lll_l1_ 		; results = l1111lll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==2:  import l1l1lll1l1l_l1_ 		; results = l1l1lll1l1l_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==3:  import l111ll1111l_l1_ 		; results = l111ll1111l_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==4:  import l1l1l1l11_l1_ 	; results = l1l1l1l11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==5:  import l11ll111l1l_l1_ 	; results = l11ll111l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==6:  import l1ll111ll_l1_ 	; results = l1ll111ll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==7:  import l11llll_l1_ 		; results = l11llll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==8:  import l1l1lll1ll1_l1_ 	; results = l1l1lll1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==9:  import l1ll1ll1l1_l1_		; results = l1ll1ll1l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==10: import l1ll1ll11111_l1_ 		; results = l1ll1ll11111_l1_.MAIN(l1ll1111l111_l1_,url)
	elif l1ll1111l11l_l1_==11: import l1l1ll11ll1l_l1_ 	; results = l1l1ll11ll1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==12: import l11111l1ll_l1_ 		; results = l11111l1ll_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==13: import l1l1l1l1l_l1_	; results = l1l1l1l1l_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==14: import l11l1ll1ll1_l1_ 		; results = l11l1ll1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_,name,l111_l1_)
	elif l1ll1111l11l_l1_==15: import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==16: import l1l1l1ll1ll1_l1_	 	; results = l1l1l1ll1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text,l1l1111_l1_,l1ll1ll1l11_l1_)
	elif l1ll1111l11l_l1_==17: import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==18: import l1l11ll1l1l1_l1_	; results = l1l11ll1l1l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==19: import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==20: import l111ll1l1_l1_		; results = l111ll1l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==21: import l111l11111l_l1_ ; results = l111l11111l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==22: import l1llll11l1l_l1_ 	; results = l1llll11l1l_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==23: import IPTV 		; results = IPTV.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_)
	elif l1ll1111l11l_l1_==24: import l1llll1l_l1_ 		; results = l1llll1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==25: import l11l11l1l_l1_ 	; results = l11l11l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==26: import l1l1l11lll1l_l1_ 		; results = l1l1l11lll1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1ll1111l111_l1_,context)
	elif l1ll1111l11l_l1_==28: import IPTV 		; results = IPTV.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_)
	elif l1ll1111l11l_l1_==29: import l11l11ll1l1_l1_	; results = l11l11ll1l1_l1_.MAIN(l1ll1111l111_l1_,url,l1l1111_l1_,text)
	elif l1ll1111l11l_l1_==30: import l1ll1l1l1l_l1_		; results = l1ll1l1l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==31: import l111ll11lll_l1_	; results = l111ll11lll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==32: import l1l1l1lll11_l1_	; results = l1l1l1lll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==33: import l11l111l1l_l1_		; results = l11l111l1l_l1_.MAIN(l1ll1111l111_l1_,url)
	elif l1ll1111l11l_l1_==34: import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==35: import l1l11l1l_l1_		; results = l1l11l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==36: import l1ll1l111l11_l1_		; results = l1ll1l111l11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==37: import l11111ll1_l1_		; results = l11111ll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==38: import l1ll1111111l_l1_ 		; results = l1ll1111111l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==39: import l1ll1l1l1l1_l1_	; results = l1ll1l1l1l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==40: import l11lll1l1l_l1_	; results = l11lll1l1l_l1_.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_)
	elif l1ll1111l11l_l1_==41: import l11lll1l1l_l1_	; results = l11lll1l1l_l1_.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_)
	elif l1ll1111l11l_l1_==42: import l1llllll11_l1_		; results = l1llllll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==43: import l1lll1lll11_l1_		; results = l1lll1lll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==44: import l1lll1lll1l_l1_		; results = l1lll1lll1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==45: import l11ll1l1ll1_l1_		; results = l11ll1l1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==46: import l1llll11lll1_l1_		; results = l1llll11lll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==47: import l1ll1l1ll1_l1_	; results = l1ll1l1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==48: import l1l1l1l11l1l_l1_		; results = l1l1l1l11l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==49: import l1lll111l1_l1_		; results = l1lll111l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==50: import l1l111l11ll_l1_ 	; results = l1l111l11ll_l1_.MAIN(l1ll1111l111_l1_,text)
	elif l1ll1111l11l_l1_==51: import l1lll11ll11_l1_ 	; results = l1lll11ll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==52: import l1lll11ll11_l1_ 	; results = l1lll11ll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==53: import l1l1l11lll1l_l1_ 		; results = l1l1l11lll1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==54: import l1lll11ll1l_l1_	; results = l1lll11ll1l_l1_.MAIN(l1ll1111l111_l1_,url,text,l1l1111_l1_)
	elif l1ll1111l11l_l1_==55: import l1lll11l1l_l1_ 	; results = l1lll11l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==56: import l1l1ll1l1l11_l1_		; results = l1l1ll1l1l11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==57: import l1ll1l1l111_l1_		; results = l1ll1l1l111_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==58: import l11l1l1l1l1_l1_	; results = l11l1l1l1l1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==59: import l1ll1l1111l_l1_		; results = l1ll1l1111l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==60: import l1ll11lllll_l1_		; results = l1ll11lllll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==61: import l1ll11l_l1_		; results = l1ll11l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==62: import l1ll1l1lll1_l1_		; results = l1ll1l1lll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==63: import l1lll111ll_l1_		; results = l1lll111ll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==64: import l1llllll1l1l_l1_		; results = l1llllll1l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==65: import l1llllllll_l1_		; results = l1llllllll_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==66: import l11l1llll11_l1_		; results = l11l1llll11_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==67: import l1l1l1l1ll1_l1_		; results = l1l1l1l1ll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==68: import l111lll111_l1_		; results = l111lll111_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==69: import l1lllllll1_l1_		; results = l1lllllll1_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==70: import l1l1l111l1l_l1_		; results = l1l1l111l1l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==71: import l1l1l11l11ll_l1_			; results = l1l1l11l11ll_l1_.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_)
	elif l1ll1111l11l_l1_==72: import l1l1l11l11ll_l1_			; results = l1l1l11l11ll_l1_.MAIN(l1ll1111l111_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_)
	elif l1ll1111l11l_l1_==73: import l1l11l11l_l1_	; results = l1l11l11l_l1_.MAIN(l1ll1111l111_l1_,url,text)
	elif l1ll1111l11l_l1_==74: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1ll1111l111_l1_)
	elif l1ll1111l11l_l1_==75: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1ll1111l111_l1_)
	else: results = None
	return results
def l11l1l1ll1_l1_(name=l11ll1_l1_ (u"ࠬ࠭㛦")):
	if not name: name = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㛧"))
	name = name.replace(l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㛨"),l11ll1_l1_ (u"ࠨࠩ㛩"))
	name = name.replace(l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ㛪"),l11ll1_l1_ (u"ࠪࠤࠬ㛫")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ㛬"),l11ll1_l1_ (u"ࠬࠦࠧ㛭")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ㛮"),l11ll1_l1_ (u"ࠧࠡࠩ㛯")).strip(l11ll1_l1_ (u"ࠨࠢࠪ㛰"))
	name = name.replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㛱"),l11ll1_l1_ (u"ࠪࠫ㛲")).replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㛳"),l11ll1_l1_ (u"ࠬ࠭㛴"))
	tmp = re.findall(l11ll1_l1_ (u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢࠪ㛵"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11ll1_l1_ (u"ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪ㛶")
	return name
def l1lll11l1111_l1_(code,reason,source,l1ll_l1_):
	if l11ll1_l1_ (u"ࠨ࠯ࠪ㛷") in source: l1ll111l111_l1_ = source.split(l11ll1_l1_ (u"ࠩ࠰ࠫ㛸"),1)[0]
	else: l1ll111l111_l1_ = source
	l111llll1ll_l1_ = code in [7,11001,11002,10054]
	l1l11ll11l11_l1_ = reason.lower()
	l1ll1lllllll_l1_ = code in [0,104,10061,111]
	l1ll1llllll1_l1_ = l11ll1_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㛹") in l1l11ll11l11_l1_
	l1ll1lllll1l_l1_ = l11ll1_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ㛺") in l1l11ll11l11_l1_
	l1ll1lllll11_l1_ = l11ll1_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㛻") in l1l11ll11l11_l1_
	l1ll1llll1ll_l1_ = l11ll1_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ㛼") in l1l11ll11l11_l1_
	l1l1l1llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㛽"))
	l1l1l11ll1l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㛾"))
	l1llll1l1ll1_l1_ = l11ll1_l1_ (u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ㛿")
	l1ll111l11ll_l1_ = l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠪ㜀")+str(code)+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ㜁")+reason
	l1ll111l11ll_l1_ = l1111_l1_(l1ll111l11ll_l1_)
	if l1ll1lllllll_l1_ or l1ll1llllll1_l1_ or l1ll1lllll1l_l1_ or l1ll1lllll11_l1_ or l1ll1llll1ll_l1_:
		l1llll1l1ll1_l1_ += l11ll1_l1_ (u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬ㜂")
	if l111llll1ll_l1_: l1llll1l1ll1_l1_ += l11ll1_l1_ (u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭㜃")
	l1ll111l11ll_l1_ = l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㜄")+l1ll111l11ll_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜅")
	if l1l1l1llll11_l1_==l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㜆") or l1l1l11ll1l1_l1_==l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㜇"):
		l1llll1l1ll1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㜈")
	l11ll1111l1_l1_ = False
	if l1ll_l1_ and source not in l1111ll1l1l_l1_:
		if l1l1l1llll11_l1_==l11ll1_l1_ (u"ࠬࡇࡓࡌࠩ㜉") or l1l1l11ll1l1_l1_==l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ㜊"):
			#if kodi_version<19: l1ll111l11ll_l1_ = l1ll111l11ll_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㜋"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㜌"),l11ll1_l1_ (u"ࠩัีําࠧ㜍"),l11ll1_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㜎"),l11ll1_l1_ (u"ࠫส฻ไศฯࠣห้๋ิไๆฬࠫ㜏"),l1ll111l111_l1_+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㜐")+TRANSLATE(l1ll111l111_l1_),l1llll1l1ll1_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ㜑")+l1ll111l11ll_l1_)
			if choice==1:
				import l1l111l11ll_l1_
				l1l111l11ll_l1_.l1ll111lll1l_l1_()
			elif choice==2: l11ll1111l1_l1_ = True
		else: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㜒"),l11ll1_l1_ (u"ࠨࠩ㜓"),l1ll111l111_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㜔")+TRANSLATE(l1ll111l111_l1_),l1llll1l1ll1_l1_,l1ll111l11ll_l1_)
	#if reason.endswith(l11ll1_l1_ (u"ࠪࠤ࠮࠭㜕")): reason = reason.rsplit(l11ll1_l1_ (u"ࠫࡡࡴࠧ㜖"))[0]
	#if l11ll1111l1_l1_: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㜗"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㜘")+str(code)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ㜙")+reason+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㜚")+source+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ㜛")+l1llll1l1ll1_l1_+l11ll1_l1_ (u"ࠪࠤࡢࡣࠠࠡࠢࡈࡒࡌࡒࡉࡔࡊ࠽ࠤࡠࠦࠧ㜜")+l1ll111l11ll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㜝"))
	return l11ll1111l1_l1_
	l11ll1_l1_ (u"ࠧࠨࠢࠎࠌࠌ࡭࡫ࠦࡤ࡯ࡵࠣࡳࡷࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠱ࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠷ࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠶࠾ࠒࠐࠉࠊࡤ࡯ࡳࡨࡱ࡟࡮ࡧࡨࡷࡸࡧࡧࡦࠢࡀࠤࠬ์ฺ่่๊ࠢࠥอไฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใ࠯ࠩࠐࠎࠎࠏࡩࡧࠢࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹ࠺ࠡࡤ࡯ࡳࡨࡱ࡟࡮ࡧࡨࡷࡸࡧࡧࡦࠢ࠮ࡁ่ࠥ࠭ࠠๆࠣฮึ๐ฯࠡฬไหฺ๐ไࠡษๆฯึࠦฟࠨࠏࠍࠍࠎ࡯ࡦࠡࡦࡱࡷ࠿ࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅࠣࡁࠥ࠭ไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็ࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦࠫ࠾ࠢࠪࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ࠭ࠫࡣ࡮ࡲࡧࡰࡥ࡭ࡦࡧࡶࡷࡦ࡭ࡥࠎࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅࠣࡁࠥ࠭็ัษࠣห้๋่ใ฻ࠣๅ๏ํࠠࠨ࠭ࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠐࠎࠎࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࠭ࡎࡒࡋࡌࡏࡎࡈࠪࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠩࠬࠩࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ࠮ࡷࡴࡻࡲࡤࡧ࠮ࠫࠥࡣࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ࠰ࡹࡴࡳࠪࡦࡳࡩ࡫ࠩࠬࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ࠰ࡸࡥࡢࡵࡲࡲ࠰࠭ࠠ࡞ࠢࠣࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠾ࠥࡡࠠࠨ࠭ࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤࡢࡣࠠࠡࠢࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠽ࠤࡠࠦࠧࠬ࡯ࡨࡷࡸࡧࡧࡦࡇࡑࡋࡑࡏࡓࡉ࠭ࠪࠤࡢ࠭ࠩࠎࠌࠌࠍ࡮࡬ࠠࡴࡪࡲࡻࡉ࡯ࡡ࡭ࡱࡪࡷ࠿ࠓࠊࠊࠋࠌࡽࡪࡹࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡ࡜ࡉࡘࡔࡏࠩࠩࡦࡩࡳࡺࡥࡳࠩ࠯ࡷ࡮ࡺࡥࠬࠩࠣࠤࠥ࠭ࠫࡕࡔࡄࡒࡘࡒࡁࡕࡇࠫࡷ࡮ࡺࡥࠪ࠮ࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠮ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠯ࠫࠬ࠲ࠧไๆสࠫ࠱࠭ๆฺ็ࠪ࠭ࠒࠐࠉࠊࠋ࡬ࡪࠥࡿࡥࡴ࠿ࡀ࠵࠿ࠦࡩ࡮ࡲࡲࡶࡹࠦࡓࡆࡔ࡙ࡍࡈࡋࡓࠡ࠽ࠣࡗࡊࡘࡖࡊࡅࡈࡗ࠳ࡓࡁࡊࡐࠫ࠵࠾࠻ࠩࠎࠌࠌࡩࡱ࡯ࡦࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࡀࠍࠋࠋࠌࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠵ࠤࡂࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠱ࠧࠡ࠰๋้ࠣࠦสา์าࠤ๊฿ัโหࠣห้ษำษษหࠤํอไฮๆ๋่ࠥลࠧࠎࠌࠌࠍࡾ࡫ࡳࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢ࡝ࡊ࡙ࡎࡐࠪࠪࡧࡪࡴࡴࡦࡴࠪ࠰ࡸ࡯ࡴࡦ࠭ࠪࠤࠥࠦࠧࠬࡖࡕࡅࡓ࡙ࡌࡂࡖࡈࠬࡸ࡯ࡴࡦࠫ࠯ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠵࠰ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠱࠭ࠧ࠭ࠩๆ่ฬ࠭ࠬࠨ่฼้ࠬ࠯ࠍࠋࠋࠌ࡭࡫ࠦࡹࡦࡵࡀࡁ࠶ࡀࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥࡃࠠࠨไาࠤ๏้่็๊๊ࠢฬ้ࠠ็๊฼ࠤ๊์ࠠศๆะะอูࠦ็ัๆࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็ษ๋ะั็ฬࠣ฽๋ีใࠡ็ไูํ๊ษࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไาสฺࠤฬ๊ๅีใิࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥเ๊า๊ࠢิ์ࠦวๅืไัฮ่ࠦศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮࡝ࡰࠪ࠯ࠬาัษ่ࠢืาࠦวๅๅสุࠥ࠮ๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠫࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠฤำึู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠮ๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠫࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠอำหࠤ฼ืโࠡำไ฽ࠥอไฮฮหࠤ๋࠭หๅษ࡚ࠣࡕࡔࠠ࠭ࠢࡓࡶࡴࡾࡹࠡ࠮ࠣࡈࡓ࡙ࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥาัษฺ่ࠢอࠦ็ัษࠣห้๋่ใ฻่ࠣฬำโศࠩࠐࠎࠎࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡕࡇ࡛ࡘ࡛ࡏࡅࡘࡇࡕࠬࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ࠭࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠫࠐࠎࠎࠨࠢࠣ㜞")
def l11l111l1l1_l1_(l1l1l11ll11l_l1_=False):
	l1llll1lll11_l1_ = [l1l111ll111_l1_,favoritesfile,l1l11l1ll1l1_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l1l11ll11l_l1_ and (filename.startswith(l11ll1_l1_ (u"࠭ࡩࡱࡶࡹࠫ㜟")) or filename.startswith(l11ll1_l1_ (u"ࠧ࡮࠵ࡸࠫ㜠"))): continue
		if filename.startswith(l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ㜡")): continue
		l1lll11l1lll_l1_ = os.path.join(addoncachefolder,filename)
		if l1lll11l1lll_l1_ in l1llll1lll11_l1_: continue
		try: os.remove(l1lll11l1lll_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll1l1l11ll_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l1l11l11_l1_=True,l1ll11l1l111_l1_=True):
	l1l1ll11llll_l1_,l1ll1l1l1l1l_l1_ = proxy.split(l11ll1_l1_ (u"ࠩ࠽ࠫ㜢"))
	#l1llllll_l1_(l11ll1_l1_ (u"ู้้ࠪไสࠢศ๊ฯืๆ๋ฬࠣ࠲ูࠥรฮษ๋่ࠥหีๅษะ๋ฬ࠭㜣"),l11ll1_l1_ (u"ุࠫษฬาสࠣࠫ㜤")+name,time=2000)
	#LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㜥"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࠪ㜦")+name+l11ll1_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㜧")+proxy+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㜨")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㜩"))
	url = url+l11ll1_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ㜪")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l1l11l11_l1_,l1ll11l1l111_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㜫"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠩ㜬")+name+l11ll1_l1_ (u"࠭ࠠࡴࡧࡵࡺࡪࡸࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ㜭")+proxy+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㜮")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㜯"))
		l1llll11l11l_l1_(l11ll1_l1_ (u"ࠩࡋࡘ࡙ࡖࠠࡓࡧࡴࡹࡪࡹࡴࠡࡈࡤ࡭ࡱࡻࡲࡦࠩ㜰"))
	#else: LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㜱"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㜲")+proxy+l11ll1_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㜳")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㜴"))
	return response
def l1l1l11llll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㜵"),url,l11ll1_l1_ (u"ࠨࠩ㜶"),l11ll1_l1_ (u"ࠩࠪ㜷"),True,l11ll1_l1_ (u"ࠪࠫ㜸"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ㜹"),True,False)
	l111111llll_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111llllll1_l1_
		l1ll111llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨ㜺"),html)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㜻"),str(l1ll111llll1_l1_))
		if l1ll111llll1_l1_: html = l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㜼").join(l1ll111llll1_l1_)
		proxies = html.replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ㜽"),l11ll1_l1_ (u"ࠩࠪ㜾")).strip(l11ll1_l1_ (u"ࠪࡠࡳ࠭㜿")).split(l11ll1_l1_ (u"ࠫࡡࡴࠧ㝀"))
		l111111llll_l1_ = []
		for proxy in proxies:
			if proxy.count(l11ll1_l1_ (u"ࠬ࠴ࠧ㝁"))==3: l111111llll_l1_.append(proxy)
	return l111111llll_l1_
def l11l1l11l1l_l1_(*args):
	#l1ll11ll1111_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠴࠶࠰࠶࠷࠳࠷࠷࠯࠳࠵࠻࠴ࡧࡰࡪ࠱ࡳࡶࡴࡾࡹࡀࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡸࡶࡥࡦࡦࡀ࠵࠵ࠬ࡬ࡢࡵࡷࡣࡨ࡮ࡥࡤ࡭ࡀ࠵࠵ࠬࡨࡵࡶࡳࡷࡂࡺࡲࡶࡧࠩࡴࡴࡹࡴ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡰࡥࡹࡃࡴࡹࡶࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ㝂")
	l11ll11l111_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ㝃")
	l1lll1111l1l_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬ㝄")
	#l11111l1111_l1_ = l1l1l11llll1_l1_(l1ll11ll1111_l1_)
	l11111l1111_l1_ = l1l1l11llll1_l1_(l1lll1111l1l_l1_)
	l111111llll_l1_ = l1l1l11llll1_l1_(l11ll11l111_l1_)
	l11ll1l1lll_l1_ = l11111l1111_l1_+l111111llll_l1_
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㝅"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩ㝆")+str(len(l11111l1111_l1_))+l11ll1_l1_ (u"ࠫ࠰࠭㝇")+str(len(l111111llll_l1_))+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㝈"))
	proxy = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭㝉"))
	response = l1l11llll1l_l1_()
	settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㝊"),l11ll1_l1_ (u"ࠨࠩ㝋"))
	if proxy or l11ll1l1lll_l1_:
		id,timeout = 0,10
		l1l1l1ll1l11_l1_ = len(l11ll1l1lll_l1_)
		l1111llll1l_l1_ = timeout
		if l1l1l1ll1l11_l1_>l1111llll1l_l1_: counts = l1111llll1l_l1_
		else: counts = l1l1l1ll1l11_l1_
		l111lll1l11_l1_ = random.sample(l11ll1l1lll_l1_,counts)
		if proxy: l111lll1l11_l1_ = [proxy]+l111lll1l11_l1_
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㝌"),str(l111lll1l11_l1_))
		threads = l111l1lll1l_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l111lll1111_l1_:
			if id<counts:
				proxy = l111lll1l11_l1_[id]
				threads.start_new_thread(id,l1ll1l1l11ll_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㝍"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㝎")+proxy+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㝏"))
		l111lll1111_l1_ = threads.l111lll1111_l1_
		if l111lll1111_l1_:
			l1lll11ll111_l1_ = threads.l1lll11ll111_l1_
			l1llll1111l1_l1_ = l111lll1111_l1_[0]
			response = l1lll11ll111_l1_[l1llll1111l1_l1_]
			proxy = l111lll1l11_l1_[int(l1llll1111l1_l1_)]
			settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭㝐"),proxy)
			if l1llll1111l1_l1_!=0: LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㝑"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㝒")+proxy+l11ll1_l1_ (u"ࠩࠣࡡࠬ㝓"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㝔"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㝕")+proxy+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㝖"))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㝗"),l11ll1_l1_ (u"ࠧࡱࡴࡲࡼ࡮࡫ࡳࡍࡋࡖࡘ࠷ࠦ࠺࠻ࠢࠪ㝘")+str(l111lll1l11_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㝙"),l11ll1_l1_ (u"ࠩࡳࡶࡴࡾࡩࡦࡵࡏࡍࡘ࡚ࠠ࠻࠼ࠣࠫ㝚")+str(l11ll1l1lll_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㝛"),l11ll1_l1_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ㝜")+str(threads.l111lll1111_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㝝"),l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ㝞")+str(threads.l11lll1111l_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㝟"),l11ll1_l1_ (u"ࠨࡴࡨࡷࡺࡲࡴࡴࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ㝠")+str(threads.l1lll11ll111_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㝡"),l11ll1_l1_ (u"ࠪࡩࡱࡶࡡࡴࡧࡧࡸ࡮ࡳࡥࡅࡋࡆࡘࠥࡀ࠺ࠡࠩ㝢")+str(threads.l11ll111ll1_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㝣"),l11ll1_l1_ (u"ࠬࡹ࡯ࡳࡶࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭㝤")+str(l1llll1l1l11_l1_))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㝥"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㝦")+l1l1l1l1ll11_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ㝧")+str(l1llll1l1l11_l1_))
	return response
def l1l1l11111ll_l1_(connection,l1l11ll1llll_l1_):
	l111l1l1l11_l1_ = connection.create_connection
	def l1l1ll1lllll_l1_(address,*args,**kwargs):
		host,port = address
		l1ll111l11l1_l1_ = DNS_RESOLVER(host,l1l11ll1llll_l1_)
		if l1ll111l11l1_l1_: host = l1ll111l11l1_l1_[0]
		else:
			if l1l11ll1llll_l1_ in l1lllll11111_l1_: l1lllll11111_l1_.remove(l1l11ll1llll_l1_)
			if l1lllll11111_l1_:
				l1111ll111l_l1_ = l1lllll11111_l1_[0]
				#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㝨"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥ࡝ࡩ࡭࡮ࠣࡸࡷࡿࠠࡵࡪࡨࠤࡴࡺࡨࡦࡴࠣࡈࡓ࡙࠺࡜ࠢࠪ㝩")+l1111ll111l_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡳࡸࡺ࠺࡜ࠢࠪ㝪")+str(host)+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㝫"))
				l1ll111l11l1_l1_ = DNS_RESOLVER(host,l1111ll111l_l1_)
				if l1ll111l11l1_l1_: host = l1ll111l11l1_l1_[0]
		address = (host,port)
		return l111l1l1l11_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1ll1lllll_l1_
	return l111l1l1l11_l1_
def l1ll1l11l1_l1_(l1l11l11l11_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡳࡵࡴࠪ㝬"),l11ll1_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ㝭"),(method,url,data,headers))
	if html:
		l1l11l11ll1_l1_(True,url,data,headers,source,l11ll1_l1_ (u"ࠨࠩ㝮"))
		return html
	html = l1llll1ll1_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ㝯"),(method,url,data,headers),html,l1l11l11l11_l1_)
	return html
def l1l11ll1l111_l1_(url):
	l11l1111l1l_l1_,l11l11l11l1_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ㝰"))[2],80
	if l11ll1_l1_ (u"ࠫ࠿࠭㝱") in l11l1111l1l_l1_: l11l1111l1l_l1_,l11l11l11l1_l1_ = l11l1111l1l_l1_.split(l11ll1_l1_ (u"ࠬࡀࠧ㝲"))
	l111l11l1l1_l1_ = l11ll1_l1_ (u"࠭࠯ࠨ㝳")+l11ll1_l1_ (u"ࠧ࠰ࠩ㝴").join(url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ㝵"))[3:])
	request = l11ll1_l1_ (u"ࠩࡊࡉ࡙ࠦࠧ㝶")+l111l11l1l1_l1_+l11ll1_l1_ (u"ࠪࠤࡍ࡚ࡔࡑ࠱࠴࠲࠶ࡢࡲ࡝ࡰࠪ㝷")
	#request += l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠻ࠢ࡟ࡶࡡࡴࠧ㝸")
	request += l11ll1_l1_ (u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬ㝹")+l11l1111l1l_l1_+l11ll1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ㝺")
	request += l11ll1_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㝻")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l11l1111l1l_l1_,l11l11l11l1_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11ll1_l1_ (u"ࠨࠩ㝼")
	return html
def SERVER(l1lllll_l1_,type):
	# url:	http://www.l11111ll111_l1_.com
	# host:	www.l11111ll111_l1_.com
	# name:	l11111ll111_l1_
	#server = l11ll1_l1_ (u"ࠩ࠲ࠫ㝽").join(l1lllll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ㝾"))[:3])
	if l11ll1_l1_ (u"ࠫ࠳࠭㝿") not in l1lllll_l1_: return l1lllll_l1_
	l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ㞀")
	l1l1lll1ll1l_l1_,l1l1lll1ll11_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭࠮ࠨ㞁"),1)
	l1l1lll1l1ll_l1_,l1l1lll1l1l1_l1_ = l1l1lll1ll11_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩ㞂"),1)
	server = l1l1lll1ll1l_l1_+l11ll1_l1_ (u"ࠨ࠰ࠪ㞃")+l1l1lll1l1ll_l1_
	if type in [l11ll1_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ㞄"),l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ㞅")] and l11ll1_l1_ (u"ࠫ࠴࠭㞆") in server: server = server.rsplit(l11ll1_l1_ (u"ࠬ࠵ࠧ㞇"),1)[1]
	if type==l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㞈") and l11ll1_l1_ (u"ࠧ࠯ࠩ㞉") in server:
		l1ll11ll11l1_l1_ = server.split(l11ll1_l1_ (u"ࠨ࠰ࠪ㞊"))
		length = len(l1ll11ll11l1_l1_)
		if length<=2 or l11ll1_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ㞋") in server: l1ll11ll11l1_l1_ = l1ll11ll11l1_l1_[0]
		elif length>=3: l1ll11ll11l1_l1_ = l1ll11ll11l1_l1_[1]
		if len(l1ll11ll11l1_l1_)>1: server = l1ll11ll11l1_l1_
	return server
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࠩ࠲ࠫ࠰ࡻࡲ࡭࠴࠮ࠫ࠴࠭ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡲࡪࡺ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡴࡳ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡳࡷ࡭࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡰ࡮ࡼࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡹࡼ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡻࡸ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡷࡳ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡯ࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤࡱ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡲࡶ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩࡡ࡮࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡵ࡮࡭࡫ࡱࡩ࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡺࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡦࡰࡺࡨ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡰ࡮࡬ࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡲࡾ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱࡭ࡳ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡺࡻࡼ࠴ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡰ࠲ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࠤࠥࠦ㞌")
def l1l1l1ll1lll_l1_(l111l1lllll_l1_):
	l111ll11111_l1_ = repr(l111l1lllll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㞍"))).replace(l11ll1_l1_ (u"ࠧ࠭ࠢ㞎"),l11ll1_l1_ (u"࠭ࠧ㞏"))
	return l111ll11111_l1_
def l1l1l11ll1l_l1_(string):
	#if l11ll1_l1_ (u"ࠧ࡝ࡷࠪ㞐") in string:
	#	string = string.decode(l11ll1_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㞑"))
	#	l1lll1l11ll1_l1_=re.findall(l11ll1_l1_ (u"ࡴࠪࡠࡺࡡ࠰࠮࠻ࡄ࠱ࡋࡣࠧ㞒"),string)
	#	for unicode in l1lll1l11ll1_l1_
	#		char = l1l11l1l11ll_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㞓"))
	l1l1l1111l1l_l1_ = l11ll1_l1_ (u"ࠫࠬ㞔")
	if kodi_version<19: string = string.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㞕"))
	import unicodedata
	for l1l1l11l1ll_l1_ in string:
		if   l1l1l11l1ll_l1_==l11ll1_l1_ (u"ࡻࠧรࠩ㞖"): l111l111ll1_l1_ = l11ll1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠲ࠨ㞗")
		elif l1l1l11l1ll_l1_==l11ll1_l1_ (u"ࡶࠩฦࠫ㞘"): l111l111ll1_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠵ࠪ㞙")
		elif l1l1l11l1ll_l1_==l11ll1_l1_ (u"ࡸࠫษ࠭㞚"): l111l111ll1_l1_ = l11ll1_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠸ࠬ㞛")
		elif l1l1l11l1ll_l1_==l11ll1_l1_ (u"ࡺ࠭ลࠨ㞜"): l111l111ll1_l1_ = l11ll1_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠻ࠧ㞝")
		elif l1l1l11l1ll_l1_==l11ll1_l1_ (u"ࡵࠨศࠪ㞞"): l111l111ll1_l1_ = l11ll1_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠷ࠩ㞟")
		else:
			l1l11l11llll_l1_ = unicodedata.decomposition(l1l1l11l1ll_l1_)
			if l11ll1_l1_ (u"ࠩࠣࠫ㞠") in l1l11l11llll_l1_: l111l111ll1_l1_ = l11ll1_l1_ (u"ࠪࡠࡡࡻࠧ㞡")+l1l11l11llll_l1_.split(l11ll1_l1_ (u"ࠫࠥ࠭㞢"),1)[1]
			else:
				l111l111ll1_l1_ = l11ll1_l1_ (u"ࠬ࠶࠰࠱࠲ࠪ㞣")+hex(ord(l1l1l11l1ll_l1_)).replace(l11ll1_l1_ (u"࠭࠰ࡹࠩ㞤"),l11ll1_l1_ (u"ࠧࠨ㞥"))
				l111l111ll1_l1_ = l11ll1_l1_ (u"ࠨ࡞࡟ࡹࠬ㞦")+l111l111ll1_l1_[-4:]
			#if ord(l1l1l11l1ll_l1_)<256: l111l111ll1_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠰ࠨ㞧")+l1l1ll1111ll_l1_
			#elif ord(l1l1l11l1ll_l1_)<4096: l111l111ll1_l1_ = l11ll1_l1_ (u"ࠪࡠࡡࡻ࠰ࠨ㞨")+l1l1ll1111ll_l1_
			#elif l11ll1_l1_ (u"ࠫࠥ࠭㞩") in l1l11l11llll_l1_: l111l111ll1_l1_ = l11ll1_l1_ (u"ࠬࡢ࡜ࡶࠩ㞪")+l1l11l11llll_l1_.split(l11ll1_l1_ (u"࠭ࠠࠨ㞫"),1)[1]
			#else: l111l111ll1_l1_ = l11ll1_l1_ (u"ࠧ࡝࡞ࡸࠫ㞬")+l1l1ll1111ll_l1_
		l1l1l1111l1l_l1_ += l111l111ll1_l1_
	l1l1l1111l1l_l1_ = l1l1l1111l1l_l1_.replace(l11ll1_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼ࡃࡄࠩ㞭"),l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠵࠻ࠪ㞮"))
	if kodi_version<19: l1l1l1111l1l_l1_ = l1l1l1111l1l_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㞯")).encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㞰"))
	else: l1l1l1111l1l_l1_ = l1l1l1111l1l_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㞱")).decode(l11ll1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㞲"))
	return l1l1l1111l1l_l1_
def OPEN_KEYBOARD(header=l11ll1_l1_ (u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠧ㞳"),default=l11ll1_l1_ (u"ࠨࠩ㞴"),l1111lll1ll_l1_=False,source=l11ll1_l1_ (u"ࠩࠪ㞵")):
	text = l11l11l1l11_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭㞶"),l11ll1_l1_ (u"ࠫࠥ࠭㞷")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ㞸"),l11ll1_l1_ (u"࠭ࠠࠨ㞹")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ㞺"),l11ll1_l1_ (u"ࠨࠢࠪ㞻"))
	if not text and not l1111lll1ll_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㞼"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨ㞽")+text+l11ll1_l1_ (u"ࠫࠧ࠭㞾"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㞿"),l11ll1_l1_ (u"࠭ࠧ㟀"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㟁"),l11ll1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫ㟂"))
		return l11ll1_l1_ (u"ࠩࠪ㟃")
	if text not in [l11ll1_l1_ (u"ࠪࠫ㟄"),l11ll1_l1_ (u"ࠫࠥ࠭㟅")]:
		text = text.strip(l11ll1_l1_ (u"ࠬࠦࠧ㟆"))
		text = l1l1l11ll1l_l1_(text)
	if source!=l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨ㟇") and l11l1l1_l1_(l11ll1_l1_ (u"ࠧࡌࡇ࡜ࡆࡔࡇࡒࡅࠩ㟈"),l11ll1_l1_ (u"ࠨࠩ㟉"),[text],False):
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㟊"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧ㟋")+text+l11ll1_l1_ (u"ࠫࠧ࠭㟌"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㟍"),l11ll1_l1_ (u"࠭ࠧ㟎"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㟏"),l11ll1_l1_ (u"ࠨษ้ฮ้ࠥสษฬࠣ็้๋ษࠡล๋ࠤึ่ๅࠡๆ๊ࠤ฾๊วใหࠣฬศ็ไศ็่้้ࠣศศำࠣๅ็฽ࠠ࠯࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦิ็ะࠤออำหะาห๊ࠦ็ไาสࠤ่๊ๅศฬࠪ㟐"))
		return l11ll1_l1_ (u"ࠩࠪ㟑")
	LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㟒"),l11ll1_l1_ (u"ࠫ࠳ࠦࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨ㟓")+text+l11ll1_l1_ (u"ࠬࠨࠧ㟔"))
	return text
def l11ll11l1l_l1_(l111lll_l1_,headers={}):
	#if headers[l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㟕")]==l11ll1_l1_ (u"ࠧࠨ㟖"): headers[l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㟗")] = l11ll1_l1_ (u"ࠩࠣࠫ㟘")
	#l1lll1l1ll11_l1_ = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㟙") : l11ll1_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠹࠸࠲࠵࠴࠳࠸࠹࠳࠲࠶࠺࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ㟚") }
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡥ࠺࠷࠲ࡲࡿࡣࡥࡰ࠱ࡱࡪ࠵ࡶࡪࡦࡨࡳ࠳ࡳ࠳ࡶ࠺ࠪ㟛")
	#open(l11ll1_l1_ (u"࠭ࡓ࠻࡞࡟ࡸࡪࡹࡴ࠳࠰ࡰ࠷ࡺ࠾ࠧ㟜"), l11ll1_l1_ (u"ࠧࡳࠩ㟝")).read()
	url,params = l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ㟞")
	if l11ll1_l1_ (u"ࠩࡿࠫ㟟") in l111lll_l1_:
		url,params = l111lll_l1_.split(l11ll1_l1_ (u"ࠪࢀࠬ㟠"),1)
		if l11ll1_l1_ (u"ࠫࡂ࠭㟡") not in params: url,params = l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭㟢")
	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㟣"),url,l11ll1_l1_ (u"ࠧࠨ㟤"),headers,l11ll1_l1_ (u"ࠨࠩ㟥"),l11ll1_l1_ (u"ࠩࠪ㟦"),l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ㟧"),False,False)
	html = response.content
	if l11ll1_l1_ (u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨ㟨") not in html: return [l11ll1_l1_ (u"ࠬ࠳࠱ࠨ㟩")],[l111lll_l1_]
	#	if l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㟪") in list(headers.keys()): del headers[l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㟫")]
	#	else: headers[l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㟬")] = l11ll1_l1_ (u"ࠩࠪ㟭")
	#	response = OPENURL_REQUESTS_CACHED(l1ll11llll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㟮"),url,l11ll1_l1_ (u"ࠫࠬ㟯"),headers,l11ll1_l1_ (u"ࠬ࠭㟰"),l11ll1_l1_ (u"࠭ࠧ㟱"),l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠳ࡰࡧࠫ㟲"),False,False)
	#	html = response.content
	if l11ll1_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ㟳") in html: return [l11ll1_l1_ (u"ࠩ࠰࠵ࠬ㟴")],[l111lll_l1_]
	if l11ll1_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ㟵") in html: return [l11ll1_l1_ (u"ࠫ࠲࠷ࠧ㟶")],[l111lll_l1_]
	#if l11ll1_l1_ (u"࡚࡙ࠬࡑࡇࡀࡗ࡚ࡈࡔࡊࡖࡏࡉࡘ࠭㟷") in html: return [l11ll1_l1_ (u"࠭࠭࠲ࠩ㟸")],[l111lll_l1_]
	l1lll111_l1_,l1llll_l1_,l11111lll11_l1_,l1ll11l1llll_l1_ = [],[],[],[]
	lines = re.findall(l11ll1_l1_ (u"ࠧ࡝ࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠩ㟹"),html+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㟺"),re.DOTALL)
	if not lines: return [l11ll1_l1_ (u"ࠩ࠰࠵ࠬ㟻")],[l111lll_l1_]
	for line,l1lllll_l1_ in lines:
		l1l11llll1l1_l1_,l11l11lll11_l1_,l111lll1_l1_ = {},-1,-1
		title = l11ll1_l1_ (u"ࠪࠫ㟼")
		#hostname = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㟽"))
		#title = title+l11ll1_l1_ (u"ࠬࠦࠠࠨ㟾")+hostname+l11ll1_l1_ (u"࠭ࠠࠡࠩ㟿")
		#line = line.lower()
		items = line.split(l11ll1_l1_ (u"ࠧ࠭ࠩ㠀"))
		for item in items:
			#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㠁"),l11ll1_l1_ (u"ࠩࠪ㠂"),item,l11ll1_l1_ (u"ࠪࠫ㠃"))
			#if l11ll1_l1_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭㠄") in item: l1l11llll1l1_l1_[key] = value
			if l11ll1_l1_ (u"ࠬࡃࠧ㠅") in item:
				key,value = item.split(l11ll1_l1_ (u"࠭࠽ࠨ㠆"),1)
				l1l11llll1l1_l1_[key.lower()] = value
		if l11ll1_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㠇") in line.lower():
			l11l11lll11_l1_ = int(l1l11llll1l1_l1_[l11ll1_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㠈")])//1024
			#title += l11ll1_l1_ (u"ࠩࡄࡺ࡬ࡈࡗ࠻ࠢࠪ㠉")+str(l11l11lll11_l1_)+l11ll1_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㠊")
			title += str(l11l11lll11_l1_)+l11ll1_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㠋")
		elif l11ll1_l1_ (u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ㠌") in line.lower():
			l11l11lll11_l1_ = int(l1l11llll1l1_l1_[l11ll1_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㠍")])//1024
			#title += l11ll1_l1_ (u"ࠧࡃ࡙࠽ࠤࠬ㠎")+str(l11l11lll11_l1_)+l11ll1_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㠏")
			title += str(l11l11lll11_l1_)+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㠐")
		if l11ll1_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ㠑") in line.lower():
			l111lll1_l1_ = int(l1l11llll1l1_l1_[l11ll1_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㠒")].split(l11ll1_l1_ (u"ࠬࡾࠧ㠓"))[1])
			#title += l11ll1_l1_ (u"࠭ࡒࡦࡵ࠽ࠤࠬ㠔")+str(l111lll1_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠪ㠕")
			title += str(l111lll1_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࠫ㠖")
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠤࠬ㠗"))
		if not title: title = l11ll1_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ㠘")
		if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㠙")):
			if l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠬ࠵࠯ࠨ㠚")): l1lllll_l1_ = url.split(l11ll1_l1_ (u"࠭࠺ࠨ㠛"),1)[0]+l11ll1_l1_ (u"ࠧ࠻ࠩ㠜")+l1lllll_l1_
			elif l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠨ࠱ࠪ㠝")): l1lllll_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㠞"))+l1lllll_l1_
			else: l1lllll_l1_ = url.rsplit(l11ll1_l1_ (u"ࠪ࠳ࠬ㠟"),1)[0]+l11ll1_l1_ (u"ࠫ࠴࠭㠠")+l1lllll_l1_
		if params!=l11ll1_l1_ (u"ࠬ࠭㠡"): l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭ࡼࠨ㠢")+params
		if l11ll1_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ㠣") in list(l1l11llll1l1_l1_.keys()):
			l1lllll111_l1_ = l1l11llll1l1_l1_[l11ll1_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㠤")]
			l1lllll111_l1_ = l1lllll111_l1_.replace(l11ll1_l1_ (u"ࠩࠥࠫ㠥"),l11ll1_l1_ (u"ࠪࠫ㠦")).replace(l11ll1_l1_ (u"ࠦࠬࠨ㠧"),l11ll1_l1_ (u"ࠬ࠭㠨")).split(l11ll1_l1_ (u"࠭ࠣࠨ㠩"),1)[0]
			l111lll1l1_l1_ = l11l1lll11_l1_(l1lllll111_l1_)
			if l111lll1l1_l1_: l1lll1l11_l1_ = title+l11ll1_l1_ (u"ࠧࠡࠢࠪ㠪")+l111lll1l1_l1_
			else: l1lll1l11_l1_ = title
			l1lll1l11_l1_ = l1lll1l11_l1_+l11ll1_l1_ (u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ㠫")
			l1lll1l11_l1_ = l1lll1l11_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠬ㠬")+SERVER(l1lllll111_l1_,l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ㠭"))
			l1lll111_l1_.append(l1lll1l11_l1_)
			l1llll_l1_.append(l1lllll111_l1_)
			l11111lll11_l1_.append(l111lll1_l1_)
			l1ll11l1llll_l1_.append(l11l11lll11_l1_)
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࠨ࠭㠮"),1)[0]
		l111lll1l1_l1_ = l11l1lll11_l1_(l1lllll_l1_)
		if l111lll1l1_l1_: title = title+l11ll1_l1_ (u"ࠬࠦࠠࠨ㠯")+l111lll1l1_l1_
		title = title+l11ll1_l1_ (u"࠭ࠠࠡࠩ㠰")+SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㠱"))
		l1lll111_l1_.append(title)
		l1llll_l1_.append(l1lllll_l1_)
		l11111lll11_l1_.append(l111lll1_l1_)
		l1ll11l1llll_l1_.append(l11l11lll11_l1_)
	zz = list(zip(l1lll111_l1_,l1llll_l1_,l11111lll11_l1_,l1ll11l1llll_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll111_l1_,l1llll_l1_,l11111lll11_l1_,l1ll11l1llll_l1_ = list(zip(*zz))
	l1lll111_l1_,l1llll_l1_ = list(l1lll111_l1_),list(l1llll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨࠩ㠲"), l1lll111_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩࠪ㠳"), l1llll_l1_)
	return l1lll111_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l11ll1llll_l1_=l11ll1_l1_ (u"ࠪࠫ㠴")):
	if not l1l11ll1llll_l1_: l1l11ll1llll_l1_ = l1lllll11111_l1_[0]
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㠵"),l11ll1_l1_ (u"ࠬ࠭㠶"),str(l1l11ll1llll_l1_),str(host))
	if host.replace(l11ll1_l1_ (u"࠭࠮ࠨ㠷"),l11ll1_l1_ (u"ࠧࠨ㠸")).isdigit(): return [host]
	import struct,socket
	try:
		l111ll11l1l_l1_ = struct.pack(l11ll1_l1_ (u"ࠣࡀࡋࠦ㠹"), 12049)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠤࡁࡌࠧ㠺"), 256)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠥࡂࡍࠨ㠻"), 1)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠦࡃࡎࠢ㠼"), 0)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠧࡄࡈࠣ㠽"), 0)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠨ࠾ࡉࠤ㠾"), 0)
		if kodi_version>18.99: l1lll111lll1_l1_ = host.split(l11ll1_l1_ (u"ࠧ࠯ࠩ㠿"))
		else: l1lll111lll1_l1_ = host.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㡀")).split(l11ll1_l1_ (u"ࠩ࠱ࠫ㡁"))
		for part in l1lll111lll1_l1_:
			parts = part.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㡂"))
			l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠦࡇࠨ㡃"), len(part))
			for l1llllllllll_l1_ in part:
				l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠧࡩࠢ㡄"), l1llllllllll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㡅")))
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠢࡃࠤ㡆"), 0)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠣࡀࡋࠦ㡇"), 1)
		l111ll11l1l_l1_ += struct.pack(l11ll1_l1_ (u"ࠤࡁࡌࠧ㡈"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l111ll11l1l_l1_), (l1l11ll1llll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l111llll11l_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ㡉"), data, 0)
		l1111l1l1l1_l1_ = l111llll11l_l1_[3]
		offset = len(host)+18
		l111l1ll1l1_l1_ = []
		for _ in range(l1111l1l1l1_l1_):
			l11111ll1l1_l1_ = offset
			l1ll1l1lll1l_l1_ = 1
			l1llll1l1l1l_l1_ = False
			while True:
				l1llllllllll_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠦࡃࡈࠢ㡊"), data, l11111ll1l1_l1_)[0]
				if l1llllllllll_l1_ == 0:
					l11111ll1l1_l1_ += 1
					break
				# l1l1lll11l1l_l1_ the field l1l1ll11l1l1_l1_ the first l11l1111111_l1_ bits l1ll1111llll_l1_ to 1, l1111lll111_l1_ a pointer
				if l1llllllllll_l1_ >= 192:
					l1llllll1lll_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠧࡄࡂࠣ㡋"), data, l11111ll1l1_l1_ + 1)[0]
					# l1l11lll11ll_l1_ the pointer
					l11111ll1l1_l1_ = ((l1llllllllll_l1_ << 8) + l1llllll1lll_l1_ - 0xc000) - 1
					l1llll1l1l1l_l1_ = True
				l11111ll1l1_l1_ += 1
				if l1llll1l1l1l_l1_ == False: l1ll1l1lll1l_l1_ += 1
			if l1llll1l1l1l_l1_ == True: l1ll1l1lll1l_l1_ += 1
			offset = offset + l1ll1l1lll1l_l1_
			l11ll1l11l1_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠨ࠾ࡉࡊࡌࡌࠧ㡌"), data, offset)
			offset = offset + 10
			l11l111111l_l1_ = l11ll1l11l1_l1_[0]
			l1llll1l1lll_l1_ = l11ll1l11l1_l1_[3]
			if l11l111111l_l1_ == 1: # l111l1l1ll1_l1_ type
				l1111111111_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠢ࠿ࠤ㡍")+l11ll1_l1_ (u"ࠣࡄࠥ㡎")*l1llll1l1lll_l1_, data, offset)
				l1ll111l11l1_l1_ = l11ll1_l1_ (u"ࠩࠪ㡏")
				for l1llllllllll_l1_ in l1111111111_l1_: l1ll111l11l1_l1_ += str(l1llllllllll_l1_) + l11ll1_l1_ (u"ࠪ࠲ࠬ㡐")
				l1ll111l11l1_l1_ = l1ll111l11l1_l1_[0:-1]
				l111l1ll1l1_l1_.append(l1ll111l11l1_l1_)
			if l11l111111l_l1_ in [1,2,5,6,15,28]: offset = offset + l1llll1l1lll_l1_
	except: l111l1ll1l1_l1_ = []
	if not l111l1ll1l1_l1_: LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㡑"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ㡒")+host+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㡓"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㡔"),l11ll1_l1_ (u"ࠨࠩ㡕"),str(host),str(l111l1ll1l1_l1_))
	return l111l1ll1l1_l1_
def l11l1l1_l1_(script_name,url,l11l1ll_l1_,l1ll_l1_=True):
	if l11l1ll_l1_:
		l111lll1lll_l1_ = [l11ll1_l1_ (u"ࠩๆฬฬืࠧ㡖"),l11ll1_l1_ (u"ࠪฬฬฺ๊ࠨ㡗"),l11ll1_l1_ (u"ࠫࡦࡪࡵ࡭ࡶࠪ㡘"),l11ll1_l1_ (u"ࠬࡾࡸࠨ㡙"),l11ll1_l1_ (u"࠭ࡳࡦࡺࠪ㡚")]
		if script_name!=l11ll1_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㡛"):
			l111lll1lll_l1_ += [l11ll1_l1_ (u"ࠨࡴ࠽ࠫ㡜"),l11ll1_l1_ (u"ࠩࡵ࠱ࠬ㡝"),l11ll1_l1_ (u"ࠪ࠱ࡲࡧࠧ㡞")]
			l111lll1lll_l1_ += [l11ll1_l1_ (u"ࠫ࠿ࡸࠧ㡟"),l11ll1_l1_ (u"ࠬ࠳ࡲࠨ㡠"),l11ll1_l1_ (u"࠭࡭ࡢ࠯ࠪ㡡")]
		for l1ll1l1lll_l1_ in l11l1ll_l1_:
			if l11ll1_l1_ (u"ࠧࡨࡧࡷ࠲ࡵ࡮ࡰࡀࠩ㡢") in l1ll1l1lll_l1_: continue
			if l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭㡣") in l1ll1l1lll_l1_: continue
			l1ll1l1lll_l1_ = l1ll1l1lll_l1_.lower()
			if kodi_version<19: l1ll1l1lll_l1_ = l1ll1l1lll_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㡤")).encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㡥"))
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㡦"),l11ll1_l1_ (u"ࠬ࠭㡧"),l11ll1_l1_ (u"࠭ࠧ㡨"),str(l1ll1l1lll_l1_))
			#l1111l11l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫࠧࠫ㡩"),l1ll1l1lll_l1_,re.DOTALL)
			#l1111l11ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡠ࡟࠯࠭࠷࡛࠷࠯࠼ࡡࢁ࠸࡛࠱࠯࠼ࡡ࠮ࠪࠧ㡪"),l1ll1l1lll_l1_,re.DOTALL)
			#l1111l11l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡡࠬ࠶ࡡ࠶࠮࠻ࡠࢀ࠷ࡡ࠰࠮࠻ࡠ࠭ࡡ࠱ࠤࠨ㡫"),l1ll1l1lll_l1_,re.DOTALL)
			#l111l1l11l1_l1_ = any(l1111l11l11_l1_,l1111l11ll1_l1_,l1111l11l1l_l1_,l1111l111l1_l1_)
			l1ll1l1lll_l1_ = l1ll1l1lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠾ࠬ㡬"),l11ll1_l1_ (u"ࠫࠬ㡭"))
			l111l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩ㡮"),l1ll1l1lll_l1_,re.DOTALL)
			l1ll11ll11ll_l1_ = False
			for digits in l111l1l11l1_l1_:
				if len(digits)==2:
					l1ll11ll11ll_l1_ = True
					break
			if l11ll1_l1_ (u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩ㡯") in l1ll1l1lll_l1_: continue
			elif l11ll1_l1_ (u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨ㡰") in l1ll1l1lll_l1_: continue
			elif l11ll1_l1_ (u"ࠨ฼ํี๋ࠥี็ใࠪ㡱") in l1ll1l1lll_l1_: continue
			elif l11lllll111_l1_(l11ll1_l1_ (u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫ㡲")): continue
			elif l1ll1l1lll_l1_ in [l11ll1_l1_ (u"ࠪࡶࠬ㡳")] or l1ll11ll11ll_l1_ or any(value in l1ll1l1lll_l1_ for value in l111lll1lll_l1_):
				LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㡴"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㡵")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㡶"))
				if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㡷"),l11ll1_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ㡸"))
				return True
	return False
def l1ll1l111_l1_(data):
	if kodi_version>18.99: import urllib.parse as l11ll1l11ll_l1_
	else: import urllib as l11ll1l11ll_l1_
	l1111lllll1_l1_ = l11ll1l11ll_l1_.urlencode(data)
	return l1111lllll1_l1_
def l1111l1ll1l_l1_(l11l111_l1_,l1l1l11l_l1_=l11ll1_l1_ (u"ࠩࠪ㡹"),l11lll1l111_l1_=l11ll1_l1_ (u"ࠪࠫ㡺")):
	global l1l1l1111ll_l1_
	import threading
	l11llll1ll1_l1_ = threading.Thread(target=l1111l1111l_l1_,args=(l11l111_l1_,l1l1l11l_l1_,l11lll1l111_l1_))
	l11llll1ll1_l1_.start()
	l11llll1ll1_l1_.join()
	return l1l1l1111ll_l1_
def PLAY_VIDEO(l11l111_l1_,l1l1l11l_l1_=l11ll1_l1_ (u"ࠫࠬ㡻"),l11lll1l111_l1_=l11ll1_l1_ (u"ࠬ࠭㡼")):
	global l1l1l1111ll_l1_
	if not l11lll1l111_l1_: l11lll1l111_l1_ = l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㡽")
	l1l1l1111ll_l1_,l111lllllll_l1_,httpd = l11ll1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥ࠲ࠪ㡾"),l11ll1_l1_ (u"ࠨࠩ㡿"),l11ll1_l1_ (u"ࠩࠪ㢀")
	if len(l11l111_l1_)==3:
		url,l1ll1l111l1l_l1_,httpd = l11l111_l1_
		if l1ll1l111l1l_l1_: l111lllllll_l1_ = l11ll1_l1_ (u"ࠪࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻ࠢ࡞ࠤࠬ㢁")+l1ll1l111l1l_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㢂")
	else: url,l1ll1l111l1l_l1_,httpd = l11l111_l1_,l11ll1_l1_ (u"ࠬ࠭㢃"),l11ll1_l1_ (u"࠭ࠧ㢄")
	#url = l1111_l1_(url)		# cause l1l11l1l1l1l_l1_ for l1ll1ll11_l1_ l1lll1lll_l1_ l111lllll1l_l1_ l1ll1l11l11l_l1_
	url = url.replace(l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫ㢅"),l11ll1_l1_ (u"ࠨࠢࠪ㢆"))	# needed for l1l11lll1l1l_l1_
	l111lll1l1_l1_ = l11l1lll11_l1_(url,l1l1l11l_l1_)
	if l1l1l11l_l1_ not in [l11ll1_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㢇"),l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㢈")]:
		if l1l1l11l_l1_!=l11ll1_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㢉"): url = url.replace(l11ll1_l1_ (u"ࠬࠦࠧ㢊"),l11ll1_l1_ (u"࠭ࠥ࠳࠲ࠪ㢋"))
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㢌"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡴࡱࡧࡹ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㢍")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㢎")+l111lllllll_l1_)
		if l111lll1l1_l1_==l11ll1_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㢏") and l1l1l11l_l1_ not in [l11ll1_l1_ (u"ࠫࡎࡖࡔࡗࠩ㢐"),l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㢑")]:
			headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㢒"):l11ll1_l1_ (u"ࠧࠨ㢓")}
			l1lll111_l1_,l1llll_l1_ = l11ll11l1l_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ㢔")+str(count)+l11ll1_l1_ (u"้้ࠩࠣ็ࠩࠨ㢕"), l1lll111_l1_)
				if l1l_l1_ == -1:
					l1llllll_l1_(l11ll1_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭㢖"),l11ll1_l1_ (u"ࠫࠬ㢗"))
					return l1l1l1111ll_l1_
			else: l1l_l1_ = 0
			url = l1llll_l1_[l1l_l1_]
			if l1lll111_l1_[0]!=l11ll1_l1_ (u"ࠬ࠳࠱ࠨ㢘"):
				LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㢙"),LOGGING(script_name)+l11ll1_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭㢚")+l1lll111_l1_[l1l_l1_]+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㢛")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㢜"))
		#url = url+l11ll1_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠱࠹࠸࠳࠴࠵࠶ࠧ㢝")
		#url = url+l11ll1_l1_ (u"ࠫࢁࡊࡎࡕ࠿࠴ࠪࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪࡃࡥ࡯࠯ࡘࡗ࠱࡫࡮࠼ࡳࡀ࠴࠳࠻ࠦࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨ࠿ࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠨࡄࡧࡨ࡫ࡰࡵ࠿࠭࠳࠯ࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰ࠡࠪࡏ࡭ࡳࡻࡸ࠼ࠢࡄࡲࡩࡸ࡯ࡪࡦࠣ࠻࠳࠶࠻ࠡࡕࡐ࠱ࡌ࠾࠹࠳ࡃࠣࡆࡺ࡯࡬ࡥ࠱ࡑࡖࡉ࠿࠰ࡎ࠽ࠣࡻࡻ࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠴࠺࠮࠱ࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠹࠻࠳࠶࠮࠴࠵࠼࠺࠳࠾࠷ࠡࡏࡲࡦ࡮ࡲࡥࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ㢞")
		if l11ll1_l1_ (u"ࠬ࠵ࡩࡧ࡫࡯ࡱ࠴࠭㢟") in url: url = url+l11ll1_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㢠")
		elif l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ㢡") in url.lower() and l11ll1_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ㢢") not in url and l11ll1_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ㢣") not in url:
			if l11ll1_l1_ (u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨ㢤") not in url and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㢥") in url.lower():
				if l11ll1_l1_ (u"ࠬࢂࠧ㢦") not in url: url = url+l11ll1_l1_ (u"࠭ࡼࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ㢧")
				else: url = url+l11ll1_l1_ (u"ࠧࠧࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ㢨")
			if l11ll1_l1_ (u"ࠨࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ㢩") not in url.lower() and l1l1l11l_l1_ not in [l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㢪"),l11ll1_l1_ (u"ࠪࡑ࠸࡛ࠧ㢫")]:
				if l11ll1_l1_ (u"ࠫࢁ࠭㢬") not in url: url = url+l11ll1_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ㢭")
				else: url = url+l11ll1_l1_ (u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㢮")
		#url = url.replace(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ㢯"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ㢰"))
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㢱"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㢲")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㢳"))
	l11lll1ll11_l1_ = xbmcgui.ListItem()
	#l11lll1ll11_l1_ = xbmcgui.ListItem(l11ll1_l1_ (u"ࠬࡺࡥࡴࡶࠪ㢴"))
	l11lll1l111_l1_,l1l1111ll11_l1_,l1l111lllll_l1_,l11lll1llll_l1_,l1l11l1l111_l1_,l11lll1l11l_l1_,l1l1111l1ll_l1_,l1l1111l11l_l1_,l1l111ll11l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1l11l_l1_ not in [l11ll1_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㢵"),l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㢶")]:
		if kodi_version<19: l1l1l11ll111_l1_ = l11ll1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫ㢷")
		else: l1l1l11ll111_l1_ = l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧ㢸")
		#l11lll1ll11_l1_ = xbmcgui.ListItem(path=url)
		l11lll1ll11_l1_.setProperty(l1l1l11ll111_l1_, l11ll1_l1_ (u"ࠪࠫ㢹"))
		l11lll1ll11_l1_.setMimeType(l11ll1_l1_ (u"ࠫࡲ࡯࡭ࡦ࠱ࡻ࠱ࡹࡿࡰࡦࠩ㢺"))
		if kodi_version<20: l11lll1ll11_l1_.setInfo(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㢻"),{l11ll1_l1_ (u"࠭࡭ࡦࡦ࡬ࡥࡹࡿࡰࡦࠩ㢼"):l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭㢽")})
		else:
			l1l1l11l111l_l1_ = l11lll1ll11_l1_.getVideoInfoTag()
			l1l1l11l111l_l1_.setMediaType(l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㢾"))
		#l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡮ࡩ࡯࡯ࠩ㢿"))
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ㣀"),l11ll1_l1_ (u"ࠫࡊࡓࡁࡅ࠼࠽࠾࠿ࡀࠠࠨ㣁")+l111_l1_)
		#l11lll1ll11_l1_.setArt({l11ll1_l1_ (u"ࠬ࡯ࡣࡰࡰࠪ㣂"):l111_l1_,l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ㣃"):l111_l1_,l11ll1_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ㣄"):l111_l1_})
		l11lll1ll11_l1_.setArt({l11ll1_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ㣅"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ㣆"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ㣇"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ㣈"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ㣉"):l1l11l1l111_l1_,l11ll1_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ㣊"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ㣋"):l1l11l1l111_l1_,l11ll1_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭㣌"):l1l11l1l111_l1_})
		#l11lll1ll11_l1_.setInfo(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㣍"),{l11ll1_l1_ (u"ࠪࡘ࡮ࡺ࡬ࡦࠩ㣎"):name})
		#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ㣏"))
		#name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ㣐"))
		# when set to l11ll1_l1_ (u"ࠨࡆࡢ࡮ࡶࡩࠧ㣑") it l11l11l111l_l1_ l1ll11111lll_l1_ l1ll1ll11ll1_l1_ and l1ll11111l11_l1_ l111l11l1ll_l1_ l1l11lll1lll_l1_ l1l1lll1ll_l1_
		if l111lll1l1_l1_ in [l11ll1_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ㣒"),l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㣓")]: l11lll1ll11_l1_.setContentLookup(True)
		else: l11lll1ll11_l1_.setContentLookup(False)
		#if l111lll1l1_l1_ in [l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㣔")]: l11lll1ll11_l1_.setContentLookup(False)
		if l11ll1_l1_ (u"ࠪࡶࡹࡳࡰࠨ㣕") in url:
			import l1l111l11ll_l1_
			l1l111l11ll_l1_.l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ㣖"),False)
		elif l111lll1l1_l1_==l11ll1_l1_ (u"ࠬ࠴࡭ࡱࡦࠪ㣗") or l11ll1_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭㣘") in url:
			import l1l111l11ll_l1_
			l1l111l11ll_l1_.l11l1l11ll1_l1_(l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㣙"),False)
			l11lll1ll11_l1_.setProperty(l1l1l11ll111_l1_,l11ll1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㣚"))
			l11lll1ll11_l1_.setProperty(l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦ࠰ࡰࡥࡳ࡯ࡦࡦࡵࡷࡣࡹࡿࡰࡦࠩ㣛"),l11ll1_l1_ (u"ࠪࡱࡵࡪࠧ㣜"))
			#l11lll1ll11_l1_.setMimeType(l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡧࡥࡸ࡮ࠫࡹ࡯࡯ࠫ㣝"))
			#l11lll1ll11_l1_.setContentLookup(False)
		if l1ll1l111l1l_l1_:
			l11lll1ll11_l1_.setSubtitles([l1ll1l111l1l_l1_])
			#xbmc.log(LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࡆࡪࡤࡦࡦࠣࡷࡺࡨࡴࡪࡶ࡯ࡩࠥࡺ࡯ࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡹࡧࡺࡩࡵ࡮ࡨ࠾ࡠ࠭㣞")+l1ll1l111l1l_l1_+l11ll1_l1_ (u"࠭࡝ࠨ㣟"), level=xbmc.LOGNOTICE)
	if l11lll1l111_l1_==l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㣠") and l1l1l11l_l1_==l11ll1_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㣡"):
		l1l1l1111ll_l1_ = l11ll1_l1_ (u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㣢")
		l1l1l11l_l1_ = l11ll1_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡆࡏࡣࡋࡏࡌࡆࡕࠪ㣣")
	elif l11lll1l111_l1_==l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㣤") and l1l1111l11l_l1_.startswith(l11ll1_l1_ (u"ࠬ࠼ࠧ㣥")):
		l1l1l1111ll_l1_ = l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㣦")
		l1l1l11l_l1_ = l1l1l11l_l1_+l11ll1_l1_ (u"ࠧࡠࡆࡏࠫ㣧")
	# l11llll1111_l1_ l1l11llll11_l1_
	#	l1l1111llll_l1_ = l1l11l111l1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11ll1l_l1_ with xbmc.sleep(step*1000)
	if l1l1l1111ll_l1_!=l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㣨"): l1l11l11lll_l1_()
	l1l1111llll_l1_ = l1l11l111l1_l1_()
	if l1l1111llll_l1_.status:
		l1l1l1111ll_l1_ == l11ll1_l1_ (u"ࠩࠪ㣩")
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㣪"),l11ll1_l1_ (u"ࠫࠬ㣫"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㣬"),l11ll1_l1_ (u"࠭ไใัࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡสศ๎็อแࠡฬื฾๏๊้ࠠฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤๆ๐่ࠠาสࠤฬ๊ฬ่ษีࠫ㣭"))
	elif l11lll1l111_l1_==l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㣮") and not l1l1111l11l_l1_.startswith(l11ll1_l1_ (u"ࠨ࠸ࠪ㣯")):
		#title = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡯ࡴ࡭ࡧࠪ㣰"))
		#l11lll1ll11_l1_.setInfo(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㣱"),{l11ll1_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭㣲"): 3600})
		#xbmcplugin.setContent(addon_handle,l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ㣳"))
		#l11lll1ll11_l1_.setInfo(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㣴"),{l11ll1_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ㣵"):l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㣶")})
		#l11lll1ll11_l1_.setProperty(l11ll1_l1_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭㣷"),l11ll1_l1_ (u"ࠪࡸࡷࡻࡥࠨ㣸"))
		#l11lll1ll11_l1_.setInfo(type=l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㣹"),l1l1l111l11l_l1_={l11ll1_l1_ (u"࡚ࠧࡩࡵ࡮ࡨࠦ㣺"):l11ll1_l1_ (u"࠭ࡨࡦ࡮࡯ࡳࠥࡽ࡯ࡳ࡮ࡧࠫ㣻")})
		l11lll1ll11_l1_.setPath(url)
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㣼"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㣽")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㣾"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11lll1ll11_l1_)
	elif l11lll1l111_l1_==l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㣿"):
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㤀"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡎ࡬ࡺࡪࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡴࡱࡧࡹࠩࠫࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㤁")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㤂"))
		l1l1111llll_l1_.play(url,l11lll1ll11_l1_)
		#xbmc.Player().play(url,l11lll1ll11_l1_)
	succeeded = False
	if l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㤃"):
		import l11l111l1l_l1_
		succeeded = l11l111l1l_l1_.l11l11l1ll_l1_(url,l111lll1l1_l1_,l1l1l11l_l1_)
		if succeeded: l1l11l11lll_l1_()
	else:
		timeout,l1l1l1111ll_l1_ = 10,l11ll1_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㤄")
		for l11ll11111_l1_ in range(timeout):
			# l11llll1111_l1_ l1l11llll11_l1_
			#	if using time.sleep() l11llll1l1l_l1_ of xbmc.sleep() l1l11lll11l_l1_ the l11llllll1l_l1_ status
			#	l11ll1_l1_ (u"ࠤࡰࡽࡵࡲࡡࡺࡧࡵ࠲ࡸࡺࡡࡵࡷࡶࠦ㤅") will stop l1l111l1111_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l1l1111ll_l1_ = l1l1111llll_l1_.status
			if l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㤆"):
				l1llllll_l1_(l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥ๐ูๆๆࠪ㤇"),l11ll1_l1_ (u"ࠬ࠭㤈"),time=500)
				LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㤉"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࡼࡩࡥࡧࡲࠤ࡮ࡹࠠࡱ࡮ࡤࡽ࡮ࡴࡧ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㤊")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㤋")+l111lllllll_l1_)
				break
			elif l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㤌"):
				LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㤍"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㤎")+url+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㤏")+l111lllllll_l1_)
				l1llllll_l1_(l11ll1_l1_ (u"࠭วๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠨ㤐"),l11ll1_l1_ (u"ࠧࠨ㤑"),time=500)
				break
			l1llllll_l1_(l11ll1_l1_ (u"ࠨฮสี๏ࠦสี฼ํ่ࠥอไโ์า๎ํ࠭㤒"),l11ll1_l1_ (u"ࠩหห็๐ࠠࠨ㤓")+str(timeout-l11ll11111_l1_)+l11ll1_l1_ (u"ࠪࠤะอๆ๋หࠪ㤔"))
		else:
			l1llllll_l1_(l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭㤕"),l11ll1_l1_ (u"ࠬ࠭㤖"),time=500)
			if l1l1l1111ll_l1_: LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㤗"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㤘")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㤙"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㤚"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡔࡪ࡯ࡨࡳࡺࡺࠠࡶࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㤛")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㤜")+l111lllllll_l1_)
			l1l1l1111ll_l1_ = l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㤝")
	l11ll1_l1_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࡩࡶࡷࡴࡩࡀࠍࠋࠋࠌࠧࠥ࡮ࡴࡵࡲ࠽࠳࠴ࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴ࠻࠷࠸࠴࠺࠻࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠒࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡥ࡯࡭ࡨࡱࠠࡰ࡭ࠣࡸࡴࠦࡳࡩࡷࡷࡨࡴࡽ࡮ࠡࡶ࡫ࡩࠥ࡮ࡴࡵࡲࠣࡷࡪࡸࡶࡦࡴࠪ࠭ࠒࠐࠉࠊࠥ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡒࡔࡥࡃࡂࡅࡋࡉ࠱࠭ࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ࠼࠸࠹࠵࠻࠵࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨࠫࠐࠎࠎࠏࡴࡪ࡯ࡨ࠲ࡸࡲࡥࡦࡲࠫ࠵࠮ࠓࠊࠊࠋ࡫ࡸࡹࡶࡤ࠯ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠫ࠭ࠒࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬ࡮ࡴࡵࡲࠣࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡤࡰࡹࡱࠫ࠱࠭ࠧࠪࠏࠍࠍࠧࠨࠢ㤞")
	if l1l1l1111ll_l1_ in [l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㤟"),l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㤠")] or succeeded: response = l1l11llllll_l1_(l1l1l11l_l1_)
	else: l1l1111llll_l1_.stop()
	#if l1l1l1111ll_l1_ in [l11ll1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㤡"),l11ll1_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ㤢"),l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㤣"),l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㤤"),l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㤥")]: l11l1111lll_l1_(l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ㤦"),False)
	#l11l1111lll_l1_(l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠳ࡳࡦࠪ㤧"))
	#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ㤨") in url and l1l1l1111ll_l1_ in [l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㤩"),l11ll1_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ㤪")]:
	#	l1l111l1111_l1_ = HTTPS(False)
	#	if not l1l111l1111_l1_:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㤫"),l11ll1_l1_ (u"࠭ࠧ㤬"),l11ll1_l1_ (u"ࠧศๆสฮฺอไࠡ็ืๅึ࠭㤭"),l11ll1_l1_ (u"ࠨ็ื็้ฯࠠ࠯࠰࠱ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢํัฯอฬࠡษ็ํࠥอสึษ็ࠤฺ๊แาࠢࠫีอ฽ࠠๆึไี࠮่ࠦๅๅ้ࠤ้๊ริใࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ้อ๋ࠠ฻่่ࠥ฿ไ๊ࠢฯ๋ฬุใࠨ㤮"))
	#		return l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ㤯")
	#sys.exit()
	if 0 and l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㤰"):
		LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㤱"),l11ll1_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡗ࡙ࡇࡔࡖࡕ࠽࠾ࠥࠦࠠࠨ㤲")+l11ll1_l1_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ㤳"))
		while True:
			l1l1l1111ll_l1_ = l1l1111llll_l1_.status
			#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ㤴"),l11ll1_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡓࡕࡃࡗ࡙ࡘࡀ࠺ࠡࠢࠣࠫ㤵")+l1l1l1111ll_l1_)
			if l1l1l1111ll_l1_!=l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㤶"): break
			xbmc.sleep(1000)
		LOG_THIS(l11ll1_l1_ (u"ࠪࠫ㤷"),l11ll1_l1_ (u"ࠫࡕࡒࡁ࡚ࡡࡖࡘࡆ࡚ࡕࡔ࠼࠽ࠤࠥࠦࠧ㤸")+l11ll1_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧ㤹"))
	return l1l1l1111ll_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1ll11ll111l_l1_ = args[0]
		l11l11ll_l1_ = args[1]
		if not l1ll11ll111l_l1_: l1ll11ll111l_l1_ = l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㤺")
		if not l11l11ll_l1_: l11l11ll_l1_ = l11ll1_l1_ (u"ࠧศีอ้ึอัࠨ㤻")
		header = args[2]
		text = l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㤼").join(args[3:])
	else: l1ll11ll111l_l1_,l11l11ll_l1_,header,text = l11ll1_l1_ (u"ࠩࠪ㤽"),l11ll1_l1_ (u"ࠪࡓࡐ࠭㤾"),l11ll1_l1_ (u"ࠫࠬ㤿"),l11ll1_l1_ (u"ࠬ࠭㥀")
	DIALOG_THREEBUTTONS_TIMEOUT(l1ll11ll111l_l1_,l11ll1_l1_ (u"࠭ࠧ㥁"),l11l11ll_l1_,l11ll1_l1_ (u"ࠧࠨ㥂"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1ll11ll111l_l1_ = args[0]
	l1ll1lll11ll_l1_ = args[1]
	l1ll1l1ll11l_l1_ = args[2]
	if l1ll1l1ll11l_l1_ or l1ll1lll11ll_l1_: l1ll1ll1ll1l_l1_ = True
	else: l1ll1ll1ll1l_l1_ = False
	header = args[3]
	text = args[4]
	if not l1ll11ll111l_l1_: l1ll11ll111l_l1_ = l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㥃")
	if not l1ll1lll11ll_l1_: l1ll1lll11ll_l1_ = l11ll1_l1_ (u"ࠩๆ่ฬ࠭㥄")
	if not l1ll1l1ll11l_l1_: l1ll1l1ll11l_l1_ = l11ll1_l1_ (u"๊ࠪ฾๋ࠧ㥅")
	if len(args)>=6: text += l11ll1_l1_ (u"ࠫࡡࡴࠧ㥆")+args[5]
	if len(args)>=7: text += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㥇")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1ll11ll111l_l1_,l1ll1lll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ㥈"),l1ll1l1ll11l_l1_,header,text)
	if choice==-1 and l1ll1ll1ll1l_l1_: choice = -1
	elif choice==-1 and not l1ll1ll1ll1l_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1llll11ll11_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1llllll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11ll1_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㥉") in list(kwargs.keys()): l11ll1lllll_l1_ = kwargs[l11ll1_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㥊")]
	else: l11ll1lllll_l1_ = 1000
	if len(args)>2 and l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㥋") not in args[2]: l11111lll1l_l1_ = args[2]
	else: l11111lll1l_l1_ = l11ll1_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ㥌")
	l1l1l11l1111_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫ㥍"),l1l11l111ll_l1_,l11ll1_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭㥎"),l11ll1_l1_ (u"࠭࠷࠳࠲ࡳࠫ㥏"))
	l1lll1lll111_l1_,l111l1111ll_l1_ = l1l1l11ll1ll_l1_(l11ll1_l1_ (u"ࠧࠨ㥐"),l11ll1_l1_ (u"ࠨࠩ㥑"),l11ll1_l1_ (u"ࠩࠪ㥒"),header,text,l11111lll1l_l1_,l11ll1_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㥓"),720,False)
	#time.sleep(0.200)
	l1l1l11l1111_l1_.show()
	if l11111lll1l_l1_==l11ll1_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ㥔"):
		l1l1l11l1111_l1_.getControl(9040).setHeight(215)
		l1l1l11l1111_l1_.getControl(9040).setPosition(55,-80)
		l1l1l11l1111_l1_.getControl(9050).setPosition(120,-60)
		l1l1l11l1111_l1_.getControl(400).setPosition(90,-35)
	l1l1l11l1111_l1_.getControl(401).setVisible(False)
	l1l1l11l1111_l1_.getControl(402).setVisible(False)
	l1l1l11l1111_l1_.getControl(9050).setImage(l1lll1lll111_l1_)
	l1l1l11l1111_l1_.getControl(9050).setHeight(l111l1111ll_l1_)
	import threading
	l11ll1l1l11_l1_ = threading.Thread(target=l1l11l1l111l_l1_,args=(l1l1l11l1111_l1_,l1lll1lll111_l1_,l11ll1lllll_l1_))
	l11ll1l1l11_l1_.start()
	#l11ll1l1l11_l1_.join()
	return
	#return xbmcgui.Dialog().notification(l1ll11l11l1l_l1_=False,*args,**kwargs)
def l1l11l1l111l_l1_(l1l1l11l1111_l1_,l1lll1lll111_l1_,l11ll1lllll_l1_):
	time.sleep(l11ll1lllll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll1lll111_l1_):
		try: os.remove(l1lll1lll111_l1_)
		except: pass
	#del l1l1l11l1111_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,l11111lll1l_l1_,l1ll11ll111l_l1_ = l11ll1_l1_ (u"ࠬ࠭㥕"),l11ll1_l1_ (u"࠭ࠧ㥖"),l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㥗"),l11ll1_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㥘")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: l11111lll1l_l1_ = args[2]
	if len(args)>=4: l1ll11ll111l_l1_ = args[3]
	return l11ll1l111_l1_(l1ll11ll111l_l1_,header,text,l11111lll1l_l1_)
	#return xbmcgui.Dialog().l1lll111111l_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1llll111l_l1_(*args,**kwargs)
def l11l1l1111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l11l11l1l11_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text,l11111lll1l_l1_,l1ll11ll111l_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l1l11l1111_l1_ = l1ll1l1ll1l1_l1_(l11ll1_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㥙"),l1l11l111ll_l1_,l11ll1_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㥚"),l11ll1_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㥛"))
	#l1l1l11l1111_l1_.l111l1111l1_l1_(l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text,l11111lll1l_l1_,l1ll11ll111l_l1_,855)
	#return l1l1l11l1111_l1_
	l11ll1_l1_ (u"ࠧࠨࠢࠎࠌࠌ࡭࡫ࠦࡴࡪ࡯ࡨࡳࡺࡺ࠾࠱࠼ࠣࡨ࡮ࡧ࡬ࡰࡩ࠱ࡷࡹࡧࡲࡵࡄࡸࡸࡹࡵ࡮ࡴࡖ࡬ࡱࡪࡵࡵࡵࠪࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠑࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡪࡩࡢ࡮ࡲ࡫࠳࡫࡮ࡢࡤ࡯ࡩࡇࡻࡴࡵࡱࡱࡷ࠭࠯ࠍࠋࠋࠦࡨ࡮ࡧ࡬ࡰࡩ࠱ࡹࡵࡪࡡࡵࡧࡓࡶࡴ࡭ࡲࡦࡵࡶࡆࡦࡸࠨ࠸࠲ࠬࠍࠨࠦ࠷࠱ࠧࠐࠎࠎࡪࡩࡢ࡮ࡲ࡫࠳ࡪ࡯ࡎࡱࡧࡥࡱ࠮ࠩࠎࠌࠌࡧ࡭ࡵࡩࡤࡧࠣࡁࠥࡪࡩࡢ࡮ࡲ࡫࠳ࡩࡨࡰ࡫ࡦࡩࡎࡊࠍࠋࠋࡷࡶࡾࡀࠠࡰࡵ࠱ࡶࡪࡳ࡯ࡷࡧࠫࡨ࡮ࡧ࡬ࡰࡩ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠒࠐࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠥࡧࡩࡱࠦࡤࡪࡣ࡯ࡳ࡬ࠓࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡥ࡫ࡳ࡮ࡩࡥࠎࠌࠌࠦࠧࠨ㥜")
def l1ll1111l_l1_(l1ll1l1l1l11_l1_):
	if kodi_version>17.99: l1l1l11l1111_l1_ = l11ll1_l1_ (u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫ㥝")
	else: l1l1l11l1111_l1_ = l11ll1_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫ㥞")
	l1ll1l1l1l11_l1_ = l1ll1l1l1l11_l1_.lower()
	if l1ll1l1l1l11_l1_==l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ㥟"): xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࠫ㥠")+l1l1l11l1111_l1_+l11ll1_l1_ (u"ࠪ࠭ࠬ㥡"))
	elif l1ll1l1l1l11_l1_==l11ll1_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ㥢"): xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࠬ㥣")+l1l1l11l1111_l1_+l11ll1_l1_ (u"࠭ࠩࠨ㥤"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1ll11ll111l_l1_,l111111ll1l_l1_=l11ll1_l1_ (u"ࠧࠨ㥥"),l1l1ll111ll1_l1_=l11ll1_l1_ (u"ࠨࠩ㥦"),l11111l11l1_l1_=l11ll1_l1_ (u"ࠩࠪ㥧"),header=l11ll1_l1_ (u"ࠪࠫ㥨"),text=l11ll1_l1_ (u"ࠫࠬ㥩"),l11111lll1l_l1_=l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ㥪"),l1ll1ll1l1ll_l1_=0,l1ll11111l1l_l1_=0):
	if not l1ll11ll111l_l1_: l1ll11ll111l_l1_ = l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㥫")
	l1l1l11l1111_l1_ = l1ll1l1ll1l1_l1_(l11ll1_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㥬"),l1l11l111ll_l1_,l11ll1_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㥭"),l11ll1_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㥮"))
	l1l1l11l1111_l1_.l111l1111l1_l1_(l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text,l11111lll1l_l1_,l1ll11ll111l_l1_,900,l1ll1ll1l1ll_l1_,l1ll11111l1l_l1_)
	if l1ll1ll1l1ll_l1_>0: l1l1l11l1111_l1_.l11ll11ll1l_l1_()
	if l1ll11111l1l_l1_>0: l1l1l11l1111_l1_.l11l1ll1l1l_l1_()
	if l1ll1ll1l1ll_l1_==0 and l1ll11111l1l_l1_==0: l1l1l11l1111_l1_.enableButtons()
	l1l1l11l1111_l1_.doModal()
	choice = l1l1l11l1111_l1_.l11ll1l111l_l1_
	return choice
def l11ll1l111_l1_(l1ll11ll111l_l1_,header,text,l11111lll1l_l1_=l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㥯")):
	if not l1ll11ll111l_l1_: l1ll11ll111l_l1_ = l11ll1_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㥰")
	#text = l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㥱").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11ll1_l1_ (u"࠭ࠧ㥲")
	l1l1l11l1111_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡔࡦࡺࡷ࡚࡮࡫ࡷࡦࡴࡉࡹࡱࡲࡓࡤࡴࡨࡩࡳ࠴ࡸ࡮࡮ࠪ㥳"),l1l11l111ll_l1_,l11ll1_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㥴"),l11ll1_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㥵"))
	l1lll1lll111_l1_,l111l1111ll_l1_ = l1l1l11ll1ll_l1_(l11ll1_l1_ (u"ࠪࠫ㥶"),l11ll1_l1_ (u"ࠫࠬ㥷"),l11ll1_l1_ (u"ࠬ࠭㥸"),header,text,l11111lll1l_l1_,l1ll11ll111l_l1_,1270,False)
	l1l1l11l1111_l1_.show()
	#time.sleep(1)
	#l1l1l11l1111_l1_.getControl(9050).l1l1l11111l1_l1_(1270-60)
	l1l1l11l1111_l1_.getControl(9050).setHeight(l111l1111ll_l1_)
	l1l1l11l1111_l1_.getControl(9050).setImage(l1lll1lll111_l1_)
	result = l1l1l11l1111_l1_.doModal()
	#del l1l1l11l1111_l1_
	try: os.remove(l1lll1lll111_l1_)
	except: pass
	return result
def l11lllll1_l1_(l1l1lllll111_l1_=True):
	if l1l1lllll111_l1_:
		l111lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡳࡵࡴࠪ㥹"),l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㥺"),l11ll1_l1_ (u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫ㥻"))
		if l111lll1ll_l1_: return l111lll1ll_l1_
	#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㥼"),l11ll1_l1_ (u"ࠪࡉࡒࡇࡄࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡀࠠࠨ㥽")+results)
	# l11ll1l1111_l1_ and l11111l1l1_l1_ common user l1ll11lll1ll_l1_ (l11l11111l1_l1_ l11ll11lll1_l1_)
	text = l11ll1_l1_ (u"ࠫࠬ㥾")
	url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡦࡥ࡫ࡦࡱࡵࡧ࠯ࡹ࡬ࡰࡱࡹࡨࡰࡷࡶࡩ࠳ࡩ࡯࡮࠱࠵࠴࠶࠸࠯࠱࠳࠲࠴࠸࠵࡭ࡰࡵࡷ࠱ࡨࡵ࡭࡮ࡱࡱ࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࡴ࠱ࠪ㥿")
	headers = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㦀"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㦁"),url,l11ll1_l1_ (u"ࠨࠩ㦂"),headers,l11ll1_l1_ (u"ࠩࠪ㦃"),l11ll1_l1_ (u"ࠪࠫ㦄"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ㦅"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11ll1_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭㦆"))
		if count>80:
			text = re.findall(l11ll1_l1_ (u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㦇"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㦈"),l11ll1_l1_ (u"ࠨࠩ㦉"),l11ll1_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ㦊"),l11ll1_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡗࡖࡉࡗ࠳ࡁࡈࡇࡑࡘࡘࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠪ㦋"))
	if not text:
		l1lll111ll1l_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㦌"),l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭㦍"))
		text = open(l1lll111ll1l_l1_,l11ll1_l1_ (u"࠭ࡲࡣࠩ㦎")).read()
		if kodi_version>18.99: text = text.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㦏"))
		text = text.replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ㦐"),l11ll1_l1_ (u"ࠩࠪ㦑"))
	l1lll1l11lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫ㦒"),text,re.DOTALL)
	l11l1l111l1_l1_ = []
	for line in l1lll1l11lll_l1_:
		l1ll1l1l111l_l1_ = line.lower()
		if l11ll1_l1_ (u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬ㦓") in l1ll1l1l111l_l1_: continue
		if l11ll1_l1_ (u"ࠬࡻࡢࡶࡰࡷࡹࠬ㦔") in l1ll1l1l111l_l1_: continue
		#if l11ll1_l1_ (u"࠭ࡨࡵ࡯࡯ࠫ㦕") in l1ll1l1l111l_l1_: continue
		l11l1l111l1_l1_.append(line)
	l111lll1ll_l1_ = random.sample(l11l1l111l1_l1_,1)
	l111lll1ll_l1_ = l111lll1ll_l1_[0]
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㦖"),l11ll1_l1_ (u"ࠨࠩ㦗"),str(len(l1lll1l11lll_l1_)),l111lll1ll_l1_)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㦘"),l11ll1_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㦙"),l111lll1ll_l1_,l1ll1ll1l_l1_)
	return l111lll1ll_l1_
def l11ll11llll_l1_(l1lllllll111_l1_):
	#if l11ll1_l1_ (u"ࠫ࡫ࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠩ㦚") in str(error).lower(): return
	#l1lllllll111_l1_ = traceback.format_exc()
	sys.stderr.write(l1lllllll111_l1_)
	lines = l1lllllll111_l1_.splitlines()
	error = lines[-1]
	l11111ll1ll_l1_ = open(l1lll1111lll_l1_,l11ll1_l1_ (u"ࠬࡸࡢࠨ㦛")).read()
	if kodi_version>18.99: l11111ll1ll_l1_ = l11111ll1ll_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㦜"))
	l11111ll1ll_l1_ = l11111ll1ll_l1_[-8000:]
	sep = l11ll1_l1_ (u"ࠧ࠾ࠩ㦝")*100
	if sep in l11111ll1ll_l1_: l11111ll1ll_l1_ = l11111ll1ll_l1_.rsplit(sep,1)[1]
	if error in l11111ll1ll_l1_: l11111ll1ll_l1_ = l11111ll1ll_l1_.rsplit(error,1)[0]
	#l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࠩ㦞"),error,l11111ll1ll_l1_)
	#l1l11l1lll1_l1_ = l11111ll1ll_l1_.splitlines()
	#for line in reversed(l1l11l1lll1_l1_):
	#	if l11ll1_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬ㦟") in line or l11ll1_l1_ (u"ࠪࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯ࠪ㦠") in line: continue
	#	if l11ll1_l1_ (u"ࠫࡒࡵࡤࡦ࠼ࠣ࡟ࠬ㦡") not in line: continue
	l1l1ll1lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫ㦢"),l11111ll1ll_l1_,re.DOTALL)
	for typ,source in reversed(l1l1ll1lll11_l1_):
		#if l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࠨ㦣") in source: continue
		#if l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࠪ㦤") in source: continue
		if source: break
	else: source = l11ll1_l1_ (u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨ㦥")
	#l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࠪ㦦"),source,str(l1l1ll1lll11_l1_))
	file,line,func = l11ll1_l1_ (u"ࠪࠫ㦧"),l11ll1_l1_ (u"ࠫࠬ㦨"),l11ll1_l1_ (u"ࠬ࠭㦩")
	l11l11ll111_l1_ = l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺว࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㦪")+error
	l1llll1ll11l_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆู่ิื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㦫")+source
	for l1ll1lll111l_l1_ in reversed(lines):
		if l11ll1_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠨ㦬") in l1ll1lll111l_l1_ and l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㦭") in l1ll1lll111l_l1_: break
	l1ll1lll111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࠩࠣ࡞࠯ࠤࡱ࡯࡮ࡦࠢࠫ࠲࠯ࡅࠩ࡝࠮ࠣ࡭ࡳࠦࠨ࠯ࠬࡂ࠭ࠩ࠭㦮"),l1ll1lll111l_l1_,re.DOTALL)
	if l1ll1lll111l_l1_:
		file,line,func = l1ll1lll111l_l1_[0]
		if l11ll1_l1_ (u"ࠫ࠴࠭㦯") in file: file = file.rsplit(l11ll1_l1_ (u"ࠬ࠵ࠧ㦰"),1)[1]
		else: file = file.rsplit(l11ll1_l1_ (u"࠭࡜࡝ࠩ㦱"),1)[1]
		l1l1l111l1l1_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่่ๆࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㦲")+file
		line2 = l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ื฼ื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㦳")+line
		l111ll11ll1_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊้ว็࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㦴")+func
		l1ll1ll1lll1_l1_ = l1l1l111l1l1_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭㦵")+line2+l11ll1_l1_ (u"ࠫࡡࡴࠧ㦶")+l111ll11ll1_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㦷")+l1llll1ll11l_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ㦸")+l11l11ll111_l1_
		l1ll11llllll_l1_ = line2+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㦹")+l1llll1ll11l_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㦺")+l11l11ll111_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㦻")+l1l1l111l1l1_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭㦼")+l111ll11ll1_l1_
		l11l1ll1111_l1_ = line2+l11ll1_l1_ (u"ࠫࡡࡴࠧ㦽")+l11l11ll111_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㦾")+l1l1l111l1l1_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ㦿")+l111ll11ll1_l1_
	else:
		l1l1l111l1l1_l1_,line2,l111ll11ll1_l1_ = l11ll1_l1_ (u"ࠧࠨ㧀"),l11ll1_l1_ (u"ࠨࠩ㧁"),l11ll1_l1_ (u"ࠩࠪ㧂")
		l1ll1ll1lll1_l1_ = l1llll1ll11l_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㧃")+l11l11ll111_l1_
		l1ll11llllll_l1_ = l1llll1ll11l_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㧄")+l11l11ll111_l1_
		l11l1ll1111_l1_ = l11l11ll111_l1_
	#l1llllll_l1_(file+line+func,error,l11ll1_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㧅"),time=2000)
	l111ll111l1_l1_ = l11ll1_l1_ (u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัࠪ㧆")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㧇")
	addons = l1111lll1l1_l1_()
	l1lll11111ll_l1_ = []
	results = addons[l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㧈")]
	l1ll1ll1ll11_l1_ = l1l11l1ll11l_l1_(addon_version)
	if l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㧉") in list(addons.keys()):
		for l1l1llll11ll_l1_,l1lllll1llll_l1_,l11l11ll11l_l1_ in results: l1lll11111ll_l1_ = max(l1lll11111ll_l1_,l1lllll1llll_l1_)
		if l1ll1ll1ll11_l1_<l1lll11111ll_l1_:
			header = l11ll1_l1_ (u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ั࠭㧊")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㧋"),l11ll1_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㧌"),l11ll1_l1_ (u"࠭สฮัํฯࠬ㧍"),l11ll1_l1_ (u"ࠧฯำ๋ะࠬ㧎"),l111ll111l1_l1_+header,l1ll1ll1lll1_l1_)
			if choice==0:
				l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㧏"),l11ll1_l1_ (u"ࠩัีําࠧ㧐"),l11ll1_l1_ (u"ࠪฮาี๊ฬࠩ㧑"),l11ll1_l1_ (u"ࠫࠬ㧒"),header)
				if l1ll111ll1_l1_==1: choice = 1
			if choice==1:
				import l1l111l11ll_l1_
				l1l111l11ll_l1_.l1ll1l1ll111_l1_()
			return
	l1l11l1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ㧓"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㧔"),l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ㧕"))
	if not l1l11l1l1111_l1_: l1l11l1l1111_l1_ = []
	l1ll11llllll_l1_ = l1ll11llllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㧖"),l11ll1_l1_ (u"ࠩ࡟ࡠࡳ࠭㧗")).replace(l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ㧘"),l11ll1_l1_ (u"ࠫࠬ㧙")).replace(l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㧚"),l11ll1_l1_ (u"࠭ࠧ㧛")).replace(l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㧜"),l11ll1_l1_ (u"ࠨࠩ㧝"))
	l11l1ll1111_l1_ = l11l1ll1111_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㧞"),l11ll1_l1_ (u"ࠪࡠࡡࡴࠧ㧟")).replace(l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㧠"),l11ll1_l1_ (u"ࠬ࠭㧡")).replace(l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㧢"),l11ll1_l1_ (u"ࠧࠨ㧣")).replace(l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㧤"),l11ll1_l1_ (u"ࠩࠪ㧥"))
	l1l11ll111ll_l1_ = addon_version+l11ll1_l1_ (u"ࠪ࠾࠿࠭㧦")+l11l1ll1111_l1_
	if l1l11ll111ll_l1_ in l1l11l1l1111_l1_:
		header = l11ll1_l1_ (u"้่ࠫฯࠡไ่ฮࠥอๆหࠢึหอ่วࠡสศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ㧧")
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㧨"),l11ll1_l1_ (u"࠭ฮา๊ฯࠫ㧩"),l11ll1_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ㧪"),l111ll111l1_l1_+header,l1ll1ll1lll1_l1_)
		#if l1ll111ll1_l1_==1: DIALOG_OK(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㧫"),l11ll1_l1_ (u"ࠩัีําࠧ㧬"),l11ll1_l1_ (u"ࠪࠫ㧭"),header)
		DIALOG_OK(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㧮"),l11ll1_l1_ (u"ࠬ࠭㧯"),l111ll111l1_l1_+header,l1ll1ll1lll1_l1_)
		return
	l1l11ll1lll1_l1_ = str(kodi_version).split(l11ll1_l1_ (u"࠭࠮ࠨ㧰"))[0]
	#l11l1ll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㧱"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㧲"),l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡋࡏࡑ࡚ࡒࡤࡋࡒࡓࡑࡕࡗࠬ㧳"))
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㧴")][6]
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㧵"),url,l11ll1_l1_ (u"ࠬ࠭㧶"),l11ll1_l1_ (u"࠭ࠧ㧷"),l11ll1_l1_ (u"ࠧࠨ㧸"),l11ll1_l1_ (u"ࠨࠩ㧹"),l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬ㧺"),False,False)
	html = response.content
	l11l1ll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ㧻"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㧼"),l11ll1_l1_ (u"ࠬࡇࡌࡍࡡࡎࡒࡔ࡝ࡎࡠࡇࡕࡖࡔࡘࡓࠨ㧽"),l11l1ll1l11_l1_,REGULAR_CACHE)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㧾"),line+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㧿")+error+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ㨀")+addon_version+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㨁")+l1l11ll1lll1_l1_)
	for l111l1llll1_l1_,l11l11l1lll_l1_,l1llll111111_l1_,l1ll11lllll1_l1_ in l11l1ll1l11_l1_:
		l111l1llll1_l1_ = l111l1llll1_l1_.split(l11ll1_l1_ (u"ࠪ࠯ࠬ㨂"))
		l1llll111111_l1_ = l1llll111111_l1_.split(l11ll1_l1_ (u"ࠫ࠰࠭㨃"))
		l1ll11lllll1_l1_ = l1ll11lllll1_l1_.split(l11ll1_l1_ (u"ࠬ࠱ࠧ㨄"))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㨅"),str(l111l1llll1_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㨆")+l11l11l1lll_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ㨇")+str(l1llll111111_l1_)+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㨈")+str(l1ll11lllll1_l1_))
		if line in l111l1llll1_l1_ and error==l11l11l1lll_l1_ and addon_version in l1llll111111_l1_ and l1l11ll1lll1_l1_ in l1ll11lllll1_l1_:
			header = l11ll1_l1_ (u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨ㨉")
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㨊"),l11ll1_l1_ (u"ࠬิั้ฮࠪ㨋"),l11ll1_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ㨌"),l111ll111l1_l1_+header,l1ll1ll1lll1_l1_)
			if l1ll111ll1_l1_==1: DIALOG_OK(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㨍"),l11ll1_l1_ (u"ࠨࠩ㨎"),l11ll1_l1_ (u"ࠩࠪ㨏"),header)
			return
	header = l11ll1_l1_ (u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ㨐")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㨑"),l11ll1_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㨒"),l111ll111l1_l1_+header,l1ll1ll1lll1_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㨓"),l11ll1_l1_ (u"ࠧไๆสࠫ㨔"),l11ll1_l1_ (u"ࠨ่฼้ࠬ㨕"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㨖"),l11ll1_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫ㨗"))
	if l1ll111ll1_l1_==1: l1l11ll11lll_l1_ = l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㨘")
	else:
		DIALOG_OK(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㨙"),l11ll1_l1_ (u"࠭ࠧ㨚"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㨛"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭㨜"))
		return
	message = l1ll11llllll_l1_
	l1ll1ll1l111_l1_ = l11ll1_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ㨝")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠪ࠱ࡊࡸࡲࡰࡴࡶࠫ㨞")
	import l1l111l11ll_l1_
	succeeded = l1l111l11ll_l1_.l111ll1l1ll_l1_(l1ll1ll1l111_l1_,message,True,l11ll1_l1_ (u"ࠫࠬ㨟"),l11ll1_l1_ (u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㨠"),l1l11ll11lll_l1_)
	if succeeded and l1l11ll11lll_l1_:
		l1l11l1l1111_l1_.append(l1l11ll111ll_l1_)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㨡"),l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ㨢"),l1l11l1l1111_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㨣"))
	filename = l11ll1_l1_ (u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤࡠࠩ㨤")+str(time.time())+l11ll1_l1_ (u"ࠪ࠲ࡩࡧࡴࠨ㨥")
	open(filename,l11ll1_l1_ (u"ࠫࡼࡨࠧ㨦")).write(data)
	return
def l11ll1111ll_l1_(l1111l1l111_l1_):
	if l1111l1l111_l1_:
		l1l1ll1ll1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ㨧"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㨨"),l11ll1_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㨩"))
		if l1l1ll1ll1l1_l1_: return l1l1ll1ll1l1_l1_
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㨪")][5]
	l1l1l1l11ll1_l1_ = l1l11l1l11l_l1_(32)
	l1llllll111l_l1_ = l11lll1l1ll_l1_()
	l1ll1l11ll1l_l1_ = l1llllll111l_l1_.split(l11ll1_l1_ (u"ࠩ࠯ࠫ㨫"))[2]
	l1ll11l11ll1_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㨬"))
	l1lll1l111ll_l1_ = l1l1l111111l_l1_()
	payload = {l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㨭"):l1l1l1l11ll1_l1_,l11ll1_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭㨮"):addon_version,l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㨯"):l1ll1l11ll1l_l1_,l11ll1_l1_ (u"ࠧࡪࡦࡶࠫ㨰"):l1ll11l11111_l1_(l1lll1l111ll_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㨱"),url,payload,l11ll1_l1_ (u"ࠩࠪ㨲"),l11ll1_l1_ (u"ࠪࠫ㨳"),l11ll1_l1_ (u"ࠫࠬ㨴"),l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠳࠱ࡴࡶࠪ㨵"))
	if not response.succeeded: return []
	html = response.content
	l1l1ll1ll1l1_l1_ = html.replace(l11ll1_l1_ (u"࠭࡜࡝ࡴࠪ㨶"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㨷")).replace(l11ll1_l1_ (u"ࠨ࡞࡟ࡲࠬ㨸"),l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㨹")).replace(l11ll1_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㨺"),l11ll1_l1_ (u"ࠫࡡࡴࠧ㨻")).replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ㨼"),l11ll1_l1_ (u"࠭࡜࡯ࠩ㨽"))
	l1l1ll1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡀ࠺ࠩ࡞ࡧ࠯࠮ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯ࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ㨾"),l1l1ll1ll1l1_l1_,re.DOTALL)
	if not l1l1ll1ll1l1_l1_: return []
	l1l1ll1ll1l1_l1_ = sorted(l1l1ll1ll1l1_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l11l1l1lll_l1_,l1l11lllll1l_l1_,l111l1ll1l1_l1_,l111l1l111l_l1_,reason = l1l1ll1ll1l1_l1_[0]
	#if l11ll1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㨿") in reason: l1ll11l1ll11_l1_,l1ll11l1ll1l_l1_,l1ll11l1lll1_l1_ = reason.split(l11ll1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㩀"),2)
	#else: l1ll11l1ll11_l1_,l1ll11l1ll1l_l1_,l1ll11l1lll1_l1_ = reason,reason,reason
	l1ll1l11111l_l1_ = reason if l11lllll111_l1_(l11ll1_l1_ (u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩ㩁")) else l1l11lllll1l_l1_
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㩂"),l1ll1l11111l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㩃"),l11ll1_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㩄"),l1l1ll1ll1l1_l1_,REGULAR_CACHE)
	return l1l1ll1ll1l1_l1_
def SPLIT_BIGLIST(items,l1l11ll1111l_l1_=0,l1lll11l1ll1_l1_=0):
	if l1l11ll1111l_l1_ and not l1lll11l1ll1_l1_: l1lll11l1ll1_l1_ = len(items)//l1l11ll1111l_l1_
	l1ll11l111ll_l1_,l11ll11111_l1_,l1ll1l1l11l1_l1_ = [],-1,0
	for item in items:
		if l1ll1l1l11l1_l1_%l1lll11l1ll1_l1_==0:
			l11ll11111_l1_ += 1
			l1ll11l111ll_l1_.append([])
		l1ll11l111ll_l1_[l11ll11111_l1_].append(item)
		l1ll1l1l11l1_l1_ += 1
	return l1ll11l111ll_l1_
	l11ll1_l1_ (u"ࠢࠣࠤࠐࠎࠎࡲࡥ࡯ࡩࡷ࡬ࠥࡃࠠ࡭ࡧࡱࠬࡧ࡯ࡧ࡭࡫ࡶࡸ࠮ࠓࠊࠊࡵࡳࡰ࡮ࡺࡴࡦࡦࠣࡁࠥࡡ࡝ࠎࠌࠌࡪࡴࡸࠠࡪ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭࠷ࠬࡴࡲ࡯࡭ࡹࡹ࡟ࡤࡱࡸࡲࡹ࠱࠱ࠪ࠼ࠐࠎࠎࠏࡩࡧࠢ࡬࡭ࠦࡃࡳࡱ࡮࡬ࡸࡸࡥࡣࡰࡷࡱࡸ࠿ࠓࠊࠊࠋࠌࡰ࡮ࡴࡥࡴ࠲ࠣࡁࠥࡨࡩࡨ࡮࡬ࡷࡹࡡ࠰࠻࡫ࡱࡸ࠭ࡲࡥ࡯ࡩࡷ࡬࠴ࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠭ࡢࠓࠊࠊࠋࠌࡨࡪࡲࠠࡣ࡫ࡪࡰ࡮ࡹࡴ࡜࠲࠽࡭ࡳࡺࠨ࡭ࡧࡱ࡫ࡹ࡮࠯ࡴࡲ࡯࡭ࡹࡹ࡟ࡤࡱࡸࡲࡹ࠯࡝ࠊࠏࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠑࠏࠏࠉࠊ࡮࡬ࡲࡪࡹ࠰ࠡ࠿ࠣࡦ࡮࡭࡬ࡪࡵࡷࠑࠏࠏࠉࠊࡦࡨࡰࠥࡨࡩࡨ࡮࡬ࡷࡹࠓࠊࠊࠋࡶࡴࡱ࡯ࡴࡵࡧࡧ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮ࡦࡵ࠳࠭ࠒࠐࠉࠊࡦࡨࡰࠥࡲࡩ࡯ࡧࡶ࠴ࠒࠐࠉࡳࡧࡷࡹࡷࡴࠠࡴࡲ࡯࡭ࡹࡺࡥࠎࠌࠌࠦࠧࠨ㩅")
def l1111ll11ll_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11ll1_l1_ (u"ࠨࡦࡸࡱࡲࡿ࡮ࡢ࡯ࡨࠫ㩆"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࠨ㩇") not in filename or l11ll1_l1_ (u"ࠪࡑ࠸࡛࡟ࠨ㩈") not in filename: text = str(data)
	else:
		l1ll11l111ll_l1_ = SPLIT_BIGLIST(data,8)
		text = l11ll1_l1_ (u"ࠫࠬ㩉")
		for split in l1ll11l111ll_l1_:
			text += str(split)+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㩊")
		text = text.strip(l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㩋"))
	l1l11l11111_l1_ = zlib.compress(text)
	open(filepath,l11ll1_l1_ (u"ࠧࡸࡤࠪ㩌")).write(l1l11l11111_l1_)
	return
def l11l1l11111_l1_(l1l11l11l1l_l1_,filename):
	if l1l11l11l1l_l1_==l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㩍"): data = {}
	elif l1l11l11l1l_l1_==l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㩎"): data = []
	elif l1l11l11l1l_l1_==l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ㩏"): data = l11ll1_l1_ (u"ࠫࠬ㩐")
	elif l1l11l11l1l_l1_==l11ll1_l1_ (u"ࠬ࡯࡮ࡵࠩ㩑"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l11l11111_l1_ = open(filepath,l11ll1_l1_ (u"࠭ࡲࡣࠩ㩒")).read()
	text = zlib.decompress(l1l11l11111_l1_)
	#open(l11ll1_l1_ (u"ࠧࡴ࠼࡟ࡠࡎࡖࡔࡗ࠳࠱ࡸࡽࡺࠧ㩓"),l11ll1_l1_ (u"ࠨࡹࡥࠫ㩔")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11ll1_l1_ (u"ࠩࡧࡹࡲࡳࡹ࡯ࡣࡰࡩࠬ㩕"))
	#if l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㩖") not in text: data = EVAL(l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ㩗"),text)
	if l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㩘") not in text: data = eval(text)
	else:
		l1ll11l111ll_l1_ = text.split(l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㩙"))
		del text
		data = []
		l111lll11ll_l1_ = l111l1lll1l_l1_()
		id = 0
		for split in l1ll11l111ll_l1_:
			#data += EVAL(l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ㩚"),split)
			l111lll11ll_l1_.l111l1l1111_l1_(str(id),eval,split)
			id += 1
		del l1ll11l111ll_l1_
		l111lll11ll_l1_.l1ll111l1ll1_l1_()
		l111lll11ll_l1_.l1l11ll11111_l1_()
		l1l11lllll11_l1_ = list(l111lll11ll_l1_.l1lll11ll111_l1_.keys())
		l1l1l1l1llll_l1_ = sorted(l1l11lllll11_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l1l1l1llll_l1_:
			data += l111lll11ll_l1_.l1lll11ll111_l1_[id]
	return data
def l1ll1l1l1lll_l1_(addon_id):
	l11l11l1111_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ㩛"),addon_id,l11ll1_l1_ (u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬ㩜"))
	try: l1lll1l11l1l_l1_ = open(l11l11l1111_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭㩝")).read()
	except:
		l1ll1l11lll1_l1_ = os.path.join(l1llll1l111l_l1_,l11ll1_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㩞"),addon_id,l11ll1_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ㩟"))
		try: l1lll1l11l1l_l1_ = open(l1ll1l11lll1_l1_,l11ll1_l1_ (u"࠭ࡲࡣࠩ㩠")).read()
		except: return l11ll1_l1_ (u"ࠧࠨ㩡"),[]
	if kodi_version>18.99: l1lll1l11l1l_l1_ = l1lll1l11l1l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㩢"))
	version = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭㩣"),l1lll1l11l1l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11ll1_l1_ (u"ࠪࠫ㩤"),[]
	l11ll1ll11l_l1_,l111l11ll1l_l1_ = version[0],l1l11l1ll11l_l1_(version[0])
	return l11ll1ll11l_l1_,l111l11ll1l_l1_
def l1111lll1l1_l1_():
	l111111l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㩥"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㩦"),l11ll1_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㩧"))
	if l111111l1l1_l1_: return l111111l1l1_l1_
	addons,l111111l1l1_l1_ = {},{}
	l1l1ll1lll11_l1_ = [l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㩨")][0]]
	if kodi_version>17.99: l1l1ll1lll11_l1_.append(l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㩩")][1])
	if kodi_version>18.99: l1l1ll1lll11_l1_.append(l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㩪")][2])
	for l1l1ll111111_l1_ in l1l1ll1lll11_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㩫"),l1l1ll111111_l1_,l11ll1_l1_ (u"ࠫࠬ㩬"),l11ll1_l1_ (u"ࠬ࠭㩭"),l11ll1_l1_ (u"࠭ࠧ㩮"),l11ll1_l1_ (u"ࠧࠨ㩯"),l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ㩰"))
		if response.succeeded:
			html = response.content
			l1l11ll1l1ll_l1_ = l1l1ll111111_l1_.rsplit(l11ll1_l1_ (u"ࠩ࠲ࠫ㩱"),1)[0]
			l111111ll11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㩲"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1111ll1111_l1_ in l111111ll11_l1_:
				l111l11lll1_l1_ = l1l11ll1l1ll_l1_+l11ll1_l1_ (u"ࠫ࠴࠭㩳")+addon_id+l11ll1_l1_ (u"ࠬ࠵ࠧ㩴")+addon_id+l11ll1_l1_ (u"࠭࠭ࠨ㩵")+l1111ll1111_l1_+l11ll1_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ㩶")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l111111l1l1_l1_[addon_id] = []
				l1llll111l11_l1_ = l1l11l1ll11l_l1_(l1111ll1111_l1_)
				addons[addon_id].append((l1111ll1111_l1_,l1llll111l11_l1_,l111l11lll1_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㩷"),str(addon_id)+l11ll1_l1_ (u"ࠩࠣࠤ࠳ࠦࠠࠨ㩸")+str(addons[addon_id]))
		l111111l1l1_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㩹"),l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ㩺"),l111111l1l1_l1_,REGULAR_CACHE)
	return l111111l1l1_l1_
	l11ll1_l1_ (u"ࠧࠨࠢࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡴࡪࡥࡣࡧࡵ࡫࠳ࡵࡲࡨ࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯ࡣࡴࡤࡲࡨ࡮࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡫ࡡ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡦࡷࡧ࡮ࡤࡪ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡧࡨ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠴࠲ࡶࡦࡽ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࠥࠦࠧ㩻")
def l1l11l1ll11l_l1_(l1111ll1111_l1_):
	l1llll111l11_l1_ = []
	l1ll1l11l11_l1_ = l1111ll1111_l1_.split(l11ll1_l1_ (u"࠭࠮ࠨ㩼"))
	for l1l1111ll1_l1_ in l1ll1l11l11_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ㩽"),l1l1111ll1_l1_,re.DOTALL)
		l1l11lllllll_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11lllllll_l1_.append(part)
		l1llll111l11_l1_.append(l1l11lllllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㩾"),str(l1111ll1111_l1_)+l11ll1_l1_ (u"ࠩࠣࠤ࠳ࠦࠠࠨ㩿")+str(l1llll111l11_l1_))
	return l1llll111l11_l1_
def l1ll11lll11l_l1_(l1llll111l11_l1_):
	l1111ll1111_l1_ = l11ll1_l1_ (u"ࠪࠫ㪀")
	for l1l1111ll1_l1_ in l1llll111l11_l1_:
		for part in l1l1111ll1_l1_: l1111ll1111_l1_ += str(part)
		l1111ll1111_l1_ += l11ll1_l1_ (u"ࠫ࠳࠭㪁")
	l1111ll1111_l1_ = l1111ll1111_l1_.strip(l11ll1_l1_ (u"ࠬ࠴ࠧ㪂"))
	return l1111ll1111_l1_
def l1lll1l1llll_l1_(l11l11lll1l_l1_):
	# l1l1ll1l11l1_l1_ not l11l11111ll_l1_ l1ll111l111l_l1_ l1l1l1111ll1_l1_ addons status l1llllll1ll_l1_ l11l111l11_l1_ l111l1ll1l_l1_ l111l111l11_l1_
	#l1l11ll1ll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡤࡪࡥࡷࠫ㪃"),l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㪄"),l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ㪅"))
	#if l1l11ll1ll1l_l1_: return l1l11ll1ll1l_l1_
	l1l11ll1ll1l_l1_ = {}
	addons = l1111lll1l1_l1_()
	l11l1lll11l_l1_ = l1ll111l1l1l_l1_(l11l11lll1l_l1_)
	for addon_id in l11l11lll1l_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l111111l1l1_l1_ = addons[addon_id]
		l1lll11111l1_l1_,l11l1l1lll1_l1_,l1l11l11ll11_l1_ = l111111l1l1_l1_[0]
		#l1lllllll1l1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩ㪆")+addon_id+l11ll1_l1_ (u"ࠪ࠭ࠬ㪇"))
		l1lllllll1l1_l1_,l111l11l11l_l1_ = l1ll1l1l1lll_l1_(addon_id)
		l11l111l1ll_l1_,l1lll11l11l1_l1_ = l11l1lll11l_l1_[addon_id]
		l11ll111l11_l1_ = l11l1l1lll1_l1_>l111l11l11l_l1_ and l11l111l1ll_l1_
		l1l11l11lll1_l1_ = True
		if not l11l111l1ll_l1_: l11ll1lll11_l1_ = l11ll1_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ㪈")
		elif not l1lll11l11l1_l1_: l11ll1lll11_l1_ = l11ll1_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ㪉")
		elif l11ll111l11_l1_: l11ll1lll11_l1_ = l11ll1_l1_ (u"࠭࡯࡭ࡦࠪ㪊")
		else:
			l11ll1lll11_l1_ = l11ll1_l1_ (u"ࠧࡨࡱࡲࡨࠬ㪋")
			l1l11l11lll1_l1_ = False
		l1l11ll1ll1l_l1_[addon_id] = (l1l11l11lll1_l1_,l1lllllll1l1_l1_,l111l11l11l_l1_,l1lll11111l1_l1_,l11l1l1lll1_l1_,l11ll1lll11_l1_,l1l11l11ll11_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㪌"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡊ࡟ࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ㪍"),l1l11ll1ll1l_l1_,REGULAR_CACHE)
	return l1l11ll1ll1l_l1_
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊࠥ࡬ࡪࠥࡼࡥࡳࡵ࡬ࡳࡳࡀࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠬࡪࡵࡢࡩࡽ࡯ࡳࡵ࠮࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣࡺࡪࡸࡳࡪࡱࡱ࠰࡙ࡸࡵࡦ࠮ࡗࡶࡺ࡫ࠍࠋࠋࠦࡩࡱࡹࡥ࠻ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳ࠮࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠰࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥ࠭ࠧ࠭ࡈࡤࡰࡸ࡫ࠬࡇࡣ࡯ࡷࡪࠓࠊࠊࠥ࡬ࡷࡤ࡫ࡸࡪࡵࡷࠤࡂࠦࠨࡹࡤࡰࡧ࠳࡭ࡥࡵࡅࡲࡲࡩ࡜ࡩࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠪࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪ࠭ࠬ࠯࠽࠾࠳ࠬࠑࠏࠏࠣࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲ࠿ࠩࠪࠑࠏࠏࠣࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠪࡻࡦࡲࡩ࠮ࡨࡧࡷࡇࡴࡴࡤࡗ࡫ࡶ࡭ࡧ࡯࡬ࡪࡶࡼ࡙ࠬࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱࡍࡸࡋ࡮ࡢࡤ࡯ࡩࡩ࠮ࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫ࠮࠭ࠩ࠾࠿࠴࠭ࠒࠐࠉࠤࡧ࡯ࡷࡪࡀࠠࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦ࡮ࡰࡶࠣࠬ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡥࡳࡪࠠ࡯ࡱࡷࠤ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡭࡯ࡧࡩࡧࡶࡸࡤࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡨࡪࡩ࡫ࡩࡸࡺ࡟ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵࡣࡨࡵ࡭ࡱࡣࡵࡩࠎࠏࠧࠬࡵࡷࡶ࠭࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠉࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡰ࡮ࡧࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡲࡰࡩ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠉࠊࠩ࠮ࡷࡹࡸࠨ࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡸࡺࡡࡵࡷࡶࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡴࡶࡤࡸࡺࡹࠩࠪࠏࠍࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࡸࡀࠠࠡࠩ࠮ࡷࡹࡸࠨࡢࡦࡧࡳࡳࡥࡩࡥࠫ࠮ࠫࠥࠦࠧࠬࡵࡷࡶ࠭࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡾࡩࡴࡶࠬ࠯ࠬࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠬ࠭ࠒࠐࠉࠣࠤࠥ㪎")
def PROGRESS_UPDATE(l11l1l1lll_l1_,l1lllll111ll_l1_,l111l1lll11_l1_=l11ll1_l1_ (u"ࠫࠬ㪏"),line2=l11ll1_l1_ (u"ࠬ࠭㪐"),l111l1llll1_l1_=l11ll1_l1_ (u"࠭ࠧ㪑")):
	if kodi_version<19: l11l1l1lll_l1_.update(l1lllll111ll_l1_,l111l1lll11_l1_,line2,l111l1llll1_l1_)
	else: l11l1l1lll_l1_.update(l1lllll111ll_l1_,l111l1lll11_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㪒")+line2+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㪓")+l111l1llll1_l1_)
	return
def l1ll111ll11l_l1_(l1ll1ll1l11l_l1_):
	# l11l11111ll_l1_ it for this:  function(p,a,c,k,e,d)
	# l1lll1lll1ll_l1_ l1l1lll11lll_l1_:  https://l1ll1lll1111_l1_.io
	def l1lll1l111l1_l1_(num,b,l1l1lllll1ll_l1_=l11ll1_l1_ (u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛ࠤ㪔")):
		return ((num == 0) and l1l1lllll1ll_l1_[0]) or (l1lll1l111l1_l1_(num // b, b, l1l1lllll1ll_l1_).lstrip(l1l1lllll1ll_l1_[0]) + l1l1lllll1ll_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11ll1_l1_ (u"ࠥࡠࡡࡨࠢ㪕") + l1lll1l111l1_l1_(c, a) + l11ll1_l1_ (u"ࠦࡡࡢࡢࠣ㪖"),  k[c], p)
		return p
	l1ll1ll1l11l_l1_ = l1ll1ll1l11l_l1_.split(l11ll1_l1_ (u"ࠬࢃࠨࠨ㪗"))[1][:-1]
	l1l1lll1llll_l1_ = eval(l11ll1_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧ㪘")+l1ll1ll1l11l_l1_,{l11ll1_l1_ (u"ࠧࡣࡣࡶࡩࡓ࠭㪙"):l1lll1l111l1_l1_,l11ll1_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠨ㪚"):unpack})   #,locals())
	return l1l1lll1llll_l1_
def l1ll1l1l11_l1_(url,l1ll1ll1111l_l1_=l11ll1_l1_ (u"ࠩࠪ㪛")):
	if l1ll1ll1111l_l1_==l11ll1_l1_ (u"ࠪࡰࡴࡽࡥࡳࠩ㪜"): url = re.sub(l11ll1_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫ㪝"),lambda l11ll11ll11_l1_: l11ll11ll11_l1_.group(0).lower(),url)
	elif l1ll1ll1111l_l1_==l11ll1_l1_ (u"ࠬࡻࡰࡱࡧࡵࠫ㪞"): url = re.sub(l11ll1_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭㪟"),lambda l11ll11ll11_l1_: l11ll11ll11_l1_.group(0).upper(),url)
	return url
def l1ll111l1l1l_l1_(l11l11lll1l_l1_):
	installed,l1llll1l11l1_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1ll1l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l11l11lll1l_l1_)==1: l1111lll11l_l1_ = l11ll1_l1_ (u"ࠧࠩࠤࠪ㪠")+l11l11lll1l_l1_[0]+l11ll1_l1_ (u"ࠨࠤࠬࠫ㪡")
	else: l1111lll11l_l1_ = str(tuple(l11l11lll1l_l1_))
	cc.execute(l11ll1_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩ㪢")+l1111lll11l_l1_+l11ll1_l1_ (u"ࠪࠤࡀ࠭㪣"))
	l1l111l111l_l1_ = cc.fetchall()
	l11l1lll11l_l1_ = {}
	for addon_id in l11l11lll1l_l1_: l11l1lll11l_l1_[addon_id] = (False,False)
	for addon_id,l1llll1l11l1_l1_ in l1l111l111l_l1_:
		installed = True
		l1llll1l11l1_l1_ = l1llll1l11l1_l1_==1
		l11l1lll11l_l1_[addon_id] = (installed,l1llll1l11l1_l1_)
	conn.close()
	return l11l1lll11l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11ll1_l1_ (u"ࠫࠬ㪤")
	if file==l1l11l1ll1l1_l1_: status = l111l1l11ll_l1_(True,False)
	if os.path.exists(file):
		l1l11111lll_l1_ = open(file,l11ll1_l1_ (u"ࠬࡸࡢࠨ㪥")).read()
		if kodi_version>18.99: l1l11111lll_l1_ = l1l11111lll_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㪦"))
		if file==l1l11l1ll1l1_l1_: results = l1l11111lll_l1_
		else:
			l1lllllllll1_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㪧"),l1l11111lll_l1_)
			if l1lllllllll1_l1_:
				results = {}
				for key in l1lllllllll1_l1_.keys():
					results[key] = []
					for l1lll1ll1111_l1_ in l1lllllllll1_l1_[key]:
						type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l11ll1_l1_ (u"ࠨࠩ㪨"),l11ll1_l1_ (u"ࠩࠪ㪩"),l11ll1_l1_ (u"ࠪࠫ㪪"),l11ll1_l1_ (u"ࠫࠬ㪫"),l11ll1_l1_ (u"ࠬ࠭㪬"),l11ll1_l1_ (u"࠭ࠧ㪭"),l11ll1_l1_ (u"ࠧࠨ㪮"),l11ll1_l1_ (u"ࠨࠩ㪯"),l11ll1_l1_ (u"ࠩࠪ㪰")
						type = l1lll1ll1111_l1_[0]
						name = l1lll1ll1111_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1lll1ll1111_l1_[2]
						mode = l1lll1ll1111_l1_[3]
						l111_l1_ = l1lll1ll1111_l1_[4]
						l1l1111_l1_ = l1lll1ll1111_l1_[5]
						if len(l1lll1ll1111_l1_)>6: text = l1lll1ll1111_l1_[6]
						if len(l1lll1ll1111_l1_)>7: context = l1lll1ll1111_l1_[7]
						if len(l1lll1ll1111_l1_)>8: l1ll1ll1l11_l1_ = l1lll1ll1111_l1_[8]
						if file==favoritesfile: l1l11lll1ll1_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11ll1_l1_ (u"ࠪࠫ㪱"),l1ll1ll1l11_l1_
						else: l1l11lll1ll1_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_
						results[key].append(l1l11lll1ll1_l1_)
			l11lllll1ll_l1_ = str(results)
			if kodi_version>18.99: l11lllll1ll_l1_ = l11lllll1ll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㪲"))
			open(file,l11ll1_l1_ (u"ࠬࡽࡢࠨ㪳")).write(l11lllll1ll_l1_)
	return results
def l1l1llll1ll_l1_(l1ll111l111_l1_):
	l1ll1111111_l1_ = l1ll111l111_l1_.split(l11ll1_l1_ (u"࠭࠭ࠨ㪴"),1)[0]
	l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l11ll1_l1_ (u"ࠧࠨ㪵"),l11ll1_l1_ (u"ࠨࠩ㪶"),l11ll1_l1_ (u"ࠩࠪ㪷")
	if   l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㪸")		:	from l11llll_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭㪹")	:	from l1l11l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㪺")		:	from l1llll1l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㪻")	:	from l1111lll_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㪼")	:	from l1ll111ll_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㪽")	: 	from l1l1l1l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㪾")	:	from l1l1l1l11_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㪿")	:	from l11l11l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㫀")		:	from l11111ll1_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㫁")	:	from l1llllll11_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ㫂")	:	from l1lll111l1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ㫃")	:	from l1ll1ll1l1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㫄")	:	from l1ll1l1ll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㫅"):	from l11l1l1l1l1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ㫆")		:	from l1ll11lllll_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㫇")		:	from l1ll11l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭㫈")	:	from l1ll1l1lll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㫉")	:	from l1lll111ll_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㫊")	:	from l1llllll1l1l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㫋")	:	from l1lllllll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㫌")	:	from l1l1l111l1l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㫍")	:	from l1llllllll_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㫎")		:	from l11l1llll11_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㫏")	:	from l1l1l1l1ll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㫐"):	from l1l11l11l_l1_	import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㫑")	:	from l111lll111_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㫒")	:	from l1ll1l1l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㫓"):	from l11lll1l1l_l1_	import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㫔")	:	from l11111l1ll_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㫕")	:	from l1lll1lll1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㫖")	:	from l1lll1lll11_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㫗")	:	from l1ll1l1l1l1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㫘")	:	from l1l1lll1ll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㫙")	:	from l1lll11l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㫚")		:	from l1l1lll1l1l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㫛")		:	from IPTV			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,menu_namee as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡒ࠹ࡕࠨ㫜")		:	from l1l1l11l11ll_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㫝")	:	from l1l1l1lll11_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㫞")	:	from l11ll1l1ll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㫟")	:	from l1ll1111111l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㫠")	:	from l1ll1l111l11_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㫡")	:	from l1l1ll1l1l11_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㫢")	:	from l1ll1l1l111_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㫣")	:	from l1ll1l1111l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㫤")		:	from l111ll1111l_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㫥")	:	from l1l1ll11ll1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㫦")	:	from l111ll11lll_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㫧")	:	from l11ll111l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㫨")	:	from l1l1l1l11l1l_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㫩")		:	from l1llll11lll1_l1_			import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㫪")	:	from l11l1ll1ll1_l1_		import MENU as l1l1lllllll_l1_,SEARCH as l1ll1111lll_l1_,l111l1_l1_ as l1ll11lll1l_l1_
	elif l1ll1111111_l1_==l11ll1_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㫫"):	from l11l11ll1l1_l1_	import MENU as l1l1lllllll_l1_
	return l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l11l11ll1l_l1_,headers,l1ll_l1_):
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ㫬"),l11ll1_l1_ (u"ࠧࠨ㫭"),l11ll1_l1_ (u"ࠨࠩ㫮"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㫯"),l11ll1_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆู็์อࠦๅ็ࠢส่ส์สา่อࠤํ่ฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠥࠬ㫰"))
	#if l1ll111ll1_l1_!=1: return l11ll1_l1_ (u"ࠫࠬ㫱")
	LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㫲"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧ࠻ࠢ࡞ࠤࠬ㫳")+l1l11l11ll1l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ㫴")+str(headers)+l11ll1_l1_ (u"ࠨࠢࡠࠫ㫵"))
	l11l1l1lll_l1_ = DIALOG_PROGRESS()
	l11l1l1lll_l1_.create(l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㫶"),l11ll1_l1_ (u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬ㫷"))
	l11ll11l11_l1_ = 1024*1024
	l11l11l1l1l_l1_ = bytes()
	chunk_size = 2*l11ll11l11_l1_
	import requests
	response = requests.get(l1l11l11ll1l_l1_,stream=True,headers=headers)
	l1l1l1l11l11_l1_ = response.headers
	response.close()
	if not l1l1l1l11l11_l1_:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㫸"),l11ll1_l1_ (u"ࠬ࠭㫹"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㫺"),l11ll1_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪ㫻"))
		l11l1l1lll_l1_.close()
	else:
		if l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ㫼") not in list(l1l1l1l11l11_l1_.keys()): filesize = 0
		else: filesize = int(l1l1l1l11l11_l1_[l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪ㫽")])
		l11l1llll1_l1_ = str(int(1000*filesize/l11ll11l11_l1_)/1000.0)
		l11l11l11l_l1_ = int(filesize/chunk_size)+1
		if l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪ㫾") in list(l1l1l1l11l11_l1_.keys()) and filesize>l11ll11l11_l1_:
			l1l1llll11l1_l1_ = True
			ranges = []
			l1l1ll1l1111_l1_ = 10
			ranges.append(str(0*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠫ࠲࠭㫿")+str(1*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(1*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠬ࠳ࠧ㬀")+str(2*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(2*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"࠭࠭ࠨ㬁")+str(3*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(3*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠧ࠮ࠩ㬂")+str(4*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(4*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠨ࠯ࠪ㬃")+str(5*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(5*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠩ࠰ࠫ㬄")+str(6*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(6*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠪ࠱ࠬ㬅")+str(7*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(7*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠫ࠲࠭㬆")+str(8*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(8*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"ࠬ࠳ࠧ㬇")+str(9*filesize//l1l1ll1l1111_l1_-1))
			ranges.append(str(9*filesize//l1l1ll1l1111_l1_)+l11ll1_l1_ (u"࠭࠭ࠨ㬈"))
			l11l1l1l111_l1_ = float(l11l11l11l_l1_)/l1l1ll1l1111_l1_
			l1llll11111l_l1_ = l11l1l1l111_l1_/int(1+l11l1l1l111_l1_)
		else:
			l1l1llll11l1_l1_ = False
			l1l1ll1l1111_l1_ = 1
			l1llll11111l_l1_ = 1
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㬉"),l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪ㬊")+str(l1l1llll11l1_l1_)+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ㬋")+str(filesize)+l11ll1_l1_ (u"ࠪࠤࡢ࠭㬌"))
		l11ll11111_l1_ = 0
		#t1 = time.time()-30
		for l1ll1l1l11l1_l1_ in range(l1l1ll1l1111_l1_):
			l1l1ll111_l1_ = headers
			if l1l1llll11l1_l1_: l1l1ll111_l1_[l11ll1_l1_ (u"ࠫࡗࡧ࡮ࡨࡧࠪ㬍")] = l11ll1_l1_ (u"ࠬࡨࡹࡵࡧࡶࡁࠬ㬎")+ranges[l1ll1l1l11l1_l1_]
			response = requests.get(l1l11l11ll1l_l1_,stream=True,headers=l1l1ll111_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1l1lll_l1_.iscanceled():
					LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㬏"),l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠨ㬐"))
					break
				l11ll11111_l1_ += l1llll11111l_l1_
				PROGRESS_UPDATE(l11l1l1lll_l1_,0+int(100*l11ll11111_l1_/l11l11l11l_l1_),l11ll1_l1_ (u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩ㬑"),str(int(l11ll11111_l1_*chunk_size//l11ll11l11_l1_))+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭㬒")+l11l1llll1_l1_+l11ll1_l1_ (u"ࠪࠤࡒࡈࠧ㬓"))
				l11l11l1l1l_l1_ += chunk
				#PROGRESS_UPDATE(l11l1l1lll_l1_,0+int(35*l11ll11111_l1_/l11l11l11l_l1_),l11ll1_l1_ (u"ࠫั๊ศࠡษ็้้็ࠠศๆิส๏ู๊࠻࠯ࠣห้าายࠢิๆ๊࠭㬔")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㬕")+str(l11ll11111_l1_*chunksize/l11ll11l11_l1_)+l11ll1_l1_ (u"࠭ࠠ࠰ࠢࠪ㬖")+l11l1llll1_l1_+l11ll1_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ㬗")+time.strftime(l11ll1_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ㬘")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㬙")+time.gmtime(l11l1111ll_l1_))+l11ll1_l1_ (u"ࠪࠤๅ࠭㬚"))
				#l11l111111_l1_ = time.time()
				#l111llll11_l1_ = l11l111111_l1_-t1
				#l111llllll_l1_ = l111llll11_l1_/l11ll11111_l1_
				#l11l1l111l_l1_ = l111llllll_l1_*(l11l11l11l_l1_+1)
				#l11l1111ll_l1_ = l11l1l111l_l1_-l111llll11_l1_
			response.close()
		l11l1l1lll_l1_.close()
		if len(l11l11l1l1l_l1_)<filesize and filesize>0:
			LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㬛"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩ㬜")+str(len(l11l11l1l1l_l1_)//l11ll11l11_l1_)+l11ll1_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫ㬝")+l11l1llll1_l1_+l11ll1_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㬞"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ㬟"),l11ll1_l1_ (u"ࠩศ่฿อม๊ࠡัีําࠧ㬠"),l11ll1_l1_ (u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪ㬡"),l11ll1_l1_ (u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭㬢"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㬣"),l11ll1_l1_ (u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪ㬤")+str(len(l11l11l1l1l_l1_)//l11ll11l11_l1_)+l11ll1_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭㬥")+l11l1llll1_l1_+l11ll1_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪ㬦"))
			if choice==2: l11l11l1l1l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l11ll1l_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㬧"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡏࡱࡷࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡧࡣࡤࡧࡳࡸࡪࡪࠠࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡦࠪ㬨"))
			else: return l11ll1_l1_ (u"ࠫࠬ㬩")
			if not l11l11l1l1l_l1_: return l11ll1_l1_ (u"ࠬ࠭㬪")
		else: LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㬫"),l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ㬬")+l11l1llll1_l1_+l11ll1_l1_ (u"ࠨࠢࡐࡆࠥࡣࠧ㬭"))
	return l11l11l1l1l_l1_
def l1llll111l1l_l1_(script_name):
	# old l1llll1l11ll_l1_ l1ll1ll11l1l_l1_ l1l1llll1lll_l1_
	# hit method:    https://l1l11ll11ll_l1_.l1l1l1ll11l1_l1_.com/l1l11l1l1ll_l1_/l1lll11l11ll_l1_/collection/protocol/l1l1llll1lll_l1_/l1lll11ll1ll_l1_
	#url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠴ࠪࡹ࡯ࡤ࠾ࡗࡄ࠱࠶࠸࠷࠱࠶࠸࠵࠵࠺࠭࠶ࠨࡦ࡭ࡩࡃࠧ㬮")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠪࠪࡹࡃࡥࡷࡧࡱࡸࠫࡹࡣ࠾ࡧࡱࡨࠫ࡫ࡣ࠾ࠩ㬯")+addon_version+l11ll1_l1_ (u"ࠫࠫࡧࡶ࠾ࠩ㬰")+addon_version+l11ll1_l1_ (u"ࠬࠬࡡ࡯࠿ࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࡡࡑࡉ࡜ࡉࡌࡊࡇࡑࡘࡎࡊࠦࡦࡣࡀࠫ㬱")+script_name+l11ll1_l1_ (u"࠭ࠦࡦ࡮ࡀࠫ㬲")+str(kodi_version)+l11ll1_l1_ (u"ࠧࠧࡼࡀࠫ㬳")+l1l1111111l_l1_
	#response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㬴"),url,l11ll1_l1_ (u"ࠩࠪ㬵"),l11ll1_l1_ (u"ࠪࠫ㬶"),l11ll1_l1_ (u"ࠫࠬ㬷"),l11ll1_l1_ (u"ࠬ࠭㬸"),l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㬹"))
	# new l1lll1l1l1l1_l1_ l1ll1ll11l1l_l1_ 4
	# l1l1llllll11_l1_ test:    https://l11l1lll111_l1_-l111ll1ll11_l1_-l11l111l111_l1_.l1l1l1ll11l1_l1_/l1ll1l1111l1_l1_/l11111l1l1l_l1_-l1l1llll1111_l1_
	# l1l1llllll11_l1_ json method:    https://l1l11ll11ll_l1_.l1l1l1ll11l1_l1_.com/l1l11l1l1ll_l1_/l1lll11l11ll_l1_/collection/protocol/l1ll1l1111l1_l1_/l1ll1lll1l1l_l1_/l1l1llllll11_l1_
	# l1l1llllll11_l1_ json method:    https://l1l11ll11ll_l1_.l1l1l1ll11l1_l1_.com/l1l11l1l1ll_l1_/l1lll11l11ll_l1_/collection/protocol/l1ll1l1111l1_l1_/l1ll1lll1l1l_l1_?l1l1l1l11lll_l1_=l1l1l1111111_l1_
	# l1l1llllll11_l1_ hit method:   https://www.l1lllll1ll11_l1_.com/l1ll1l1111l1_l1_-l11111l1lll_l1_-protocol-l1lll1llll1l_l1_
	# l1l1llllll11_l1_ hit method:   https://www.l1lllll1ll11_l1_.com/l11l111lll1_l1_-l11l11lllll_l1_-l1l1l1ll11l1_l1_-l1l11l1l1ll_l1_-l11111l1lll_l1_-protocol-version-2
	# l1l1llllll11_l1_ params:  https://data.l1l1l11l11l1_l1_.com
	# l1l1lllll11l_l1_ json method
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴ࡳࡰ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡤࡴ࡮ࡥࡳࡦࡥࡵࡩࡹࡃ࠰࠮ࡸ࠴࠹ࡆࡪࡣࡓࡉࡤࡔ࡬ࡷࡲࡰࡩ࡯࠹࠾ࡑࡁࠧ࡯ࡨࡥࡸࡻࡲࡦ࡯ࡨࡲࡹࡥࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠨ㬺")
	#headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㬻"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ㬼")}
	#params = {l11ll1_l1_ (u"ࠪࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㬽"):addon_version,l11ll1_l1_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ㬾"):kodi_version}
	#data = {l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡤ࡯ࡤࠨ㬿"):l1l11l1l11l_l1_(32),l11ll1_l1_ (u"࠭ࡥࡷࡧࡱࡸࡸ࠭㭀"):[{l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㭁"):script_name,l11ll1_l1_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ㭂"):params}]}
	#response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㭃"),url,str(data),headers,l11ll1_l1_ (u"ࠪࠫ㭄"),l11ll1_l1_ (u"ࠫࠬ㭅"),l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ㭆"))
	l11ll1_l1_ (u"ࠨࠢࠣࠏࠍࠍࡪࡼࡥ࡯ࡶࡑࡥࡲ࡫ࠍࠋࠋࡤࡴࡵ࡜ࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡱࡳࡩࡷࡧࡴࡪࡰࡪࡗࡾࡹࡴࡦ࡯࡙ࡩࡷࡹࡩࡰࡰࠐࠎࠎࡻࡡࡱࡸࠐࠎࠎࡻࡳࡦࡴࡢ࡭ࡩࠓࠊࠊࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢࡺࡪࡸࡳࡪࡱࡱࠑࠏࠏࡥࡷࡧࡱࡸࡤࡴࡡ࡮ࡧࠐࠎࠎࠨࠢࠣ㭇")
	# l1l1lllll11l_l1_ hit method (l11l11ll1l_l1_ l11lll11l1l_l1_ l1l1l1l111ll_l1_)
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡥ࡬ࡨࡂ࠭㭈")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠨࠨࡢࡷࡂ࠷ࠦࡦࡰࡀࠫ㭉")+script_name+l11ll1_l1_ (u"ࠩࠩࡹࡵ࠴ࡡࡷࡡࡹࡩࡷࡃࠧ㭊")+addon_version+l11ll1_l1_ (u"ࠪࠪࡺࡶ࠮࡬ࡱࡧ࡭ࡤࡼࡥࡳ࠿ࠪ㭋")+str(kodi_version)
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡡࡧࡦ࡬ࡃ࠱ࠧࡥ࡬ࡨࡂ࠷࠸࠶࠸࠳࠸࠽࠺࠹࠸࠰࠴࠺࠾࠶࠱࠵࠷࠷࠹࠼࠭㭌")
	#l1l1111111l_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡧ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠷ࠬࡴࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠨࡢࡨࡧ࡭࠽࠲ࠨࡦ࡭ࡩࡃࠧ㭍")+str(l1l1111111l_l1_)+l11ll1_l1_ (u"࠭࠮ࠨ㭎")+str(int(time.time()))
	#url += l11ll1_l1_ (u"ࠧࠧࡷࡤࡴࡻࡃ࠱࠺࠰࠴ࠪࡩࡺ࠽ࡌࡑࡇࡍࠪ࠸࠰ࡆࡏࡄࡈࠫ࡫࡮࠾ࡲࡤ࡫ࡪࡥࡶࡪࡧࡺࠪࡤ࡫ࡥ࠾࠳ࠩࡹ࡮ࡪ࠽࠳࠴࠵࠶࠲࠸࠲࠳࠴࠰࠷࠸࠹࠳ࠧࡡࡶࡷࡂ࠷ࠧ㭏")
	#response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㭐"),url,l11ll1_l1_ (u"ࠩࠪ㭑"),l11ll1_l1_ (u"ࠪࠫ㭒"),l11ll1_l1_ (u"ࠫࠬ㭓"),l11ll1_l1_ (u"ࠬ࠭㭔"),l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㭕"))
	# l1l1lllll11l_l1_ modified (not good l1l11lll111l_l1_)
	#l1l1111111l_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡥ࡬ࡨࡂ࠭㭖")+l1l11l1l11l_l1_(32)+l11ll1_l1_ (u"ࠨࠨࡢࡷࡂ࠷ࠦࡦࡰࡀࠫ㭗")+script_name+l11ll1_l1_ (u"ࠩࠩࡹࡵ࠴ࡡࡷࡡࡹࡩࡷࡃࠧ㭘")+addon_version+l11ll1_l1_ (u"ࠪࠪࡺࡧࡰࡷ࠿ࠪ㭙")+str(kodi_version)+l11ll1_l1_ (u"ࠫࠫࡥࡰ࠾ࠩ㭚")+l1l1111111l_l1_
	#l1l111l1ll1_l1_ = l11lll1l1ll_l1_()
	#l1ll111l11l1_l1_ = l1l111l1ll1_l1_.split(l11ll1_l1_ (u"ࠬ࠲ࠧ㭛"),1)[0]
	return response
def l11lll1l1ll_l1_(l1ll111l11l1_l1_=l11ll1_l1_ (u"࠭ࠧ㭜")):
	l1l1ll11ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ㭝"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㭞"),l11ll1_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭㭟"))
	if l1l1ll11ll11_l1_: return l1l1ll11ll11_l1_
	# url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡶ࡬ࡰࡥࡤࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ㭠")
	# l1l1llll1lll_l1_   url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡰࡸࡪࡲ࡭ࡸ࠴ࡡࡱࡲ࠲࡮ࡸࡵ࡮࠰ࠩ㭡")+l1ll111l11l1_l1_
	# l11lll1ll1l_l1_   url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࡀࡱࡸࡸࡵࡻࡴ࠾࡬ࡶࡳࡳࠬࡦࡪࡧ࡯ࡨࡸࡃࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡶࡪ࡭ࡩࡰࡰ࠯ࡧ࡮ࡺࡹ࠭ࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ㭢")
	l1ll111l11l1_l1_,l1l1ll1l1ll1_l1_,l1ll1l11ll1l_l1_,l11ll1llll1_l1_,l1ll1l11ll11_l1_,l1111111l1l_l1_,timezone = l11ll1_l1_ (u"࠭ࠧ㭣"),l11ll1_l1_ (u"ࠧࠨ㭤"),l11ll1_l1_ (u"ࠨࠩ㭥"),l11ll1_l1_ (u"ࠩࠪ㭦"),l11ll1_l1_ (u"ࠪࠫ㭧"),l11ll1_l1_ (u"ࠫࠬ㭨"),l11ll1_l1_ (u"ࠬ࠭㭩")
	url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡹ࡫ࡳ࠳࡯ࡳ࠰ࠩ㭪")+l1ll111l11l1_l1_+l11ll1_l1_ (u"ࠧࡀࡱࡸࡸࡵࡻࡴ࠾࡬ࡶࡳࡳࠬࡦࡪࡧ࡯ࡨࡸࡃࡩࡱ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩ࠱ࡸࡥࡨ࡫ࡲࡲ࠱ࡩࡩࡵࡻ࠯ࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㭫")
	response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㭬"),url,l11ll1_l1_ (u"ࠩࠪ㭭"),l11ll1_l1_ (u"ࠪࠫ㭮"),l11ll1_l1_ (u"ࠫࠬ㭯"),l11ll1_l1_ (u"ࠬ࠭㭰"),l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㭱"))
	if not response.succeeded: l1llllll111l_l1_ = l1ll111l11l1_l1_+l11ll1_l1_ (u"ࠧ࠭ࠩ㭲")+l1l1ll1l1ll1_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ㭳")+l1ll1l11ll1l_l1_+l11ll1_l1_ (u"ࠩ࠯ࠫ㭴")+l1ll1l11ll11_l1_+l11ll1_l1_ (u"ࠪ࠰ࠬ㭵")+l1111111l1l_l1_+l11ll1_l1_ (u"ࠫ࠱࠭㭶")+timezone
	else:
		html = response.content
		l111l1l1l1l_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ㭷"),html)
		if l11ll1_l1_ (u"࠭ࡩࡱࠩ㭸") in list(l111l1l1l1l_l1_.keys()): l1ll111l11l1_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠧࡪࡲࠪ㭹")]
		if l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ㭺") in list(l111l1l1l1l_l1_.keys()): l1l1ll1l1ll1_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ㭻")]
		if l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㭼") in list(l111l1l1l1l_l1_.keys()): l1ll1l11ll1l_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㭽")]
		if l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ㭾") in list(l111l1l1l1l_l1_.keys()): l11ll1llll1_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ㭿")]
		if l11ll1_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ㮀") in list(l111l1l1l1l_l1_.keys()): l1ll1l11ll11_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ㮁")]
		if l11ll1_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ㮂") in list(l111l1l1l1l_l1_.keys()): l1111111l1l_l1_ = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ㮃")]
		if l11ll1_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭㮄") in list(l111l1l1l1l_l1_.keys()):
			timezone = l111l1l1l1l_l1_[l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㮅")][l11ll1_l1_ (u"࠭ࡵࡵࡥࠪ㮆")]
			if timezone[0] not in [l11ll1_l1_ (u"ࠧ࠮ࠩ㮇"),l11ll1_l1_ (u"ࠨ࠭ࠪ㮈")]: timezone = l11ll1_l1_ (u"ࠩ࠮ࠫ㮉")+timezone
		l1llllll111l_l1_ = l1ll111l11l1_l1_+l11ll1_l1_ (u"ࠪ࠰ࠬ㮊")+l1l1ll1l1ll1_l1_+l11ll1_l1_ (u"ࠫ࠱࠭㮋")+l1ll1l11ll1l_l1_+l11ll1_l1_ (u"ࠬ࠲ࠧ㮌")+l1ll1l11ll11_l1_+l11ll1_l1_ (u"࠭ࠬࠨ㮍")+l1111111l1l_l1_+l11ll1_l1_ (u"ࠧ࠭ࠩ㮎")+timezone
		if kodi_version>18.99: l1llllll111l_l1_ = l1llllll111l_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㮏")).decode(l11ll1_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㮐"))
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㮑"),l11ll1_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ㮒"),l1llllll111l_l1_,l1ll1ll1l_l1_)
	return l1llllll111l_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11ll1_l1_ (u"ࠬ࠭㮓"),True
	if search.count(l11ll1_l1_ (u"࠭࡟ࠨ㮔"))>=2:
		search,options = search.split(l11ll1_l1_ (u"ࠧࡠࠩ㮕"),1)
		options = l11ll1_l1_ (u"ࠨࡡࠪ㮖")+options
		if l11ll1_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ㮗") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㮘"),l11ll1_l1_ (u"ࠫࠬ㮙"),search,options)
	return search,options,l1ll_l1_
def l1l1l111111l_l1_():
	l1ll11l11ll1_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㮚"))
	l1lll1l111ll_l1_ = 0
	if os.path.exists(l1ll11l11ll1_l1_):
		for filename in os.listdir(l1ll11l11ll1_l1_):
			if l11ll1_l1_ (u"࠭࠮ࡱࡻࡲࠫ㮛") in filename: continue
			if l11ll1_l1_ (u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬ㮜") in filename: continue
			l1l11l11ll_l1_ = os.path.join(l1ll11l11ll1_l1_,filename)
			size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
			l1lll1l111ll_l1_ += size
	return l1lll1l111ll_l1_
def l111l1l11ll_l1_(l1111l1l111_l1_,l1ll_l1_):
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㮝")][3]
	l1l1l1l11ll1_l1_ = l1l11l1l11l_l1_(32)
	l1llllll111l_l1_ = l11lll1l1ll_l1_()
	l1ll1l11ll1l_l1_ = l1llllll111l_l1_.split(l11ll1_l1_ (u"ࠩ࠯ࠫ㮞"))[2]
	l1lll1l111ll_l1_ = l1l1l111111l_l1_()
	payload = {l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㮟"):l1l1l1l11ll1_l1_,l11ll1_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㮠"):addon_version,l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㮡"):l1ll1l11ll1l_l1_,l11ll1_l1_ (u"࠭ࡩࡥࡵࠪ㮢"):l1ll11l11111_l1_(l1lll1l111ll_l1_)}
	if not l1111l1l111_l1_: DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ㮣"),(l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㮤"),url,payload,l11ll1_l1_ (u"ࠩࠪ㮥"),l11ll1_l1_ (u"ࠪࠫ㮦"),l11ll1_l1_ (u"ࠫࠬ㮧")))
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ㮨"),l11ll1_l1_ (u"࠭ࠧ㮩"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㮪"),url,payload,l11ll1_l1_ (u"ࠨࠩ㮫"),l11ll1_l1_ (u"ࠩࠪ㮬"),l11ll1_l1_ (u"ࠪࠫ㮭"),l11ll1_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㮮"),True,True)
	if not response.succeeded: l11l1llll1l_l1_ = l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㮯")
	else:
		l1l11111l11_l1_,l1lllllll11l_l1_,l1111111l11_l1_,l1lllllll1ll_l1_ = l11ll1_l1_ (u"࠭ࠧ㮰"),l11ll1_l1_ (u"ࠧࠨ㮱"),l11ll1_l1_ (u"ࠨࠩ㮲"),[]
		newfile = response.content
		if newfile:
			l1lllllll1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㮳"),newfile)
			for l1lll111l11l_l1_,l1l1ll1lll1l_l1_,message in l1lllllll1ll_l1_:
				if kodi_version>18.99: message = message.encode(l11ll1_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㮴")).decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㮵"))
				if l1lll111l11l_l1_==l11ll1_l1_ (u"ࠬ࠶ࠧ㮶"): l1l11111l11_l1_ += message+l11ll1_l1_ (u"࠭࠺࠻ࠩ㮷")
				else: l1lllllll11l_l1_ += message+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㮸")
			l1lllllll11l_l1_ = l1lllllll11l_l1_.strip(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㮹"))
			l1l11111l11_l1_ = l1l11111l11_l1_.strip(l11ll1_l1_ (u"ࠩ࠽࠾ࠬ㮺"))
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㮻"),l1l11111l11_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㮼"),l1ll11l11111_l1_(now))
		if os.path.exists(l1l11l1ll1l1_l1_): l1111111l11_l1_ = open(l1l11l1ll1l1_l1_,l11ll1_l1_ (u"ࠬࡸࡢࠨ㮽")).read()
		if kodi_version>18.99: l1lllllll11l_l1_ = l1lllllll11l_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮾"))
		if l1lllllll11l_l1_==l1111111l11_l1_: l11l1llll1l_l1_ = l11ll1_l1_ (u"ࠧࡐࡎࡇࠫ㮿")
		else:
			l11l1llll1l_l1_ = l11ll1_l1_ (u"ࠨࡐࡈ࡛ࠬ㯀")
			open(l1l11l1ll1l1_l1_,l11ll1_l1_ (u"ࠩࡺࡦࠬ㯁")).write(l1lllllll11l_l1_)
		if l1ll_l1_:
			l11l1llll1l_l1_ = l11ll1_l1_ (u"ࠪࡓࡑࡊࠧ㯂")
			l1lllllll1ll_l1_ = sorted(l1lllllll1ll_l1_,reverse=True,key=lambda key: int(key[0]))
			l11111111ll_l1_ = l11ll1_l1_ (u"ࠫࠬ㯃")
			for l1lll111l11l_l1_,l1l1ll1lll1l_l1_,message in l1lllllll1ll_l1_:
				if kodi_version>18.99: message = message.encode(l11ll1_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㯄")).decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㯅"))
				if l11111111ll_l1_: l11111111ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ㯆")
				if l1lll111l11l_l1_==l11ll1_l1_ (u"ࠨ࠲ࠪ㯇"): continue
				date = message.split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㯈"))[0]
				l1lll11ll_l1_ = l11ll1_l1_ (u"ࠪࠫ㯉")
				if l1l1ll1lll1l_l1_:
					l1lll11ll_l1_ = l11ll1_l1_ (u"ࠫึูวๅหࠣาฬ฻ษࠡๆๆࠤๆ่ืࠨ㯊")
					if kodi_version>18.99: l1lll11ll_l1_ = l1lll11ll_l1_.encode(l11ll1_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㯋")).decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㯌"))
				l11111111ll_l1_ += message.replace(date,l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㯍")+date+l1lll11ll_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㯎"))+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㯏")
			l11111111ll_l1_ = escapeUNICODE(l11111111ll_l1_)
			l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㯐"),l11ll1_l1_ (u"ࠫึูววๆ้๋ࠣࠦวๅ็หี๊าࠠฦๆ์ࠤู๊สฯั่๎ࠥอไษำ้ห๊าࠧ㯑"),l11111111ll_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㯒"))
	if l1ll_l1_ or l11l1llll1l_l1_!=l11ll1_l1_ (u"࠭ࡎࡆ࡙ࠪ㯓"):
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㯔"),l11l1llll1l_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㯕"))
	return l11l1llll1l_l1_
def l11l1lll11_l1_(url,l1l1l11l_l1_=l11ll1_l1_ (u"ࠩࠪ㯖")):
	l111lll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡺࡳࡽ࡞࠱ࡱࡵ࠺ࡼ࡝࠰ࡰ࠷ࡺࢂ࡜࠯࡯࠶ࡹ࠽ࢂ࡜࠯࡯ࡳࡨࢁࡢ࠮࡮࡭ࡹࢀࡡ࠴ࡦ࡭ࡸࡿࡠ࠳ࡳࡰ࠴ࡾ࡟࠲ࡼ࡫ࡢ࡮ࠫࠫࢀࡡࡅ࠮ࠫࡁࡿ࠳ࡡࡅ࠮ࠫࡁࡿࡠࢁ࠴ࠪࡀࠫࠧࠫ㯗"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111lll1l1_l1_: l111lll1l1_l1_ = l111lll1l1_l1_[0][0]
	else: l111lll1l1_l1_ = l11ll1_l1_ (u"ࠫࠬ㯘")
	return l111lll1l1_l1_
	#elif not l111lll1l1_l1_ and l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㯙") in l1l1l11l_l1_: l111lll1l1_l1_ = l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ㯚")
	#elif not l111lll1l1_l1_ and l11ll1_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㯛") in l1l1l11l_l1_: l111lll1l1_l1_ = l11ll1_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭㯜")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l1l1lll1l1_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l1l1lll1l1_l1_ = False
	l11l111111_l1_ = time.time()
	if l1l1l1lll1l1_l1_: resp = l11l111111_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ㯝"),l11ll1_l1_ (u"ࠪࠫ㯞"),l11ll1_l1_ (u"ࠫࠬ㯟"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㯠"),l11ll1_l1_ (u"࠭ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤ฾๋ไ๋หࠣห้ะๆู์ไࠤฬ๊ย็ࠢยࠥࠬ㯡"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11ll1_l1_ (u"ࠧ࠯ࡦࡥࠫ㯢")) and l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠭㯣") in filename:
				l1l1ll111l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l11lll1ll_l1_(l1l1ll111l_l1_)
				except: return
				cc.execute(l11ll1_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬ㯤"))
				cc.execute(l11ll1_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭㯥"))
				cc.execute(l11ll1_l1_ (u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬ㯦"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㯧"),l11ll1_l1_ (u"࠭ࠧ㯨"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㯩"),l11ll1_l1_ (u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩ㯪"))
	return
def l1ll11l11l11_l1_(word):
	if l11ll1_l1_ (u"ࠩ࡞ࠫ㯫") in word and l11ll1_l1_ (u"ࠪࡡࠬ㯬") in word:
		l11l1l111ll_l1_ = [l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㯭"),l11ll1_l1_ (u"ࠬࡡ࠯ࡓࡖࡏࡡࠬ㯮"),l11ll1_l1_ (u"࡛࠭࠰ࡎࡈࡊ࡙ࡣࠧ㯯"),l11ll1_l1_ (u"ࠧ࡜࠱ࡕࡍࡌࡎࡔ࡞ࠩ㯰"),l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡊࡔࡔࡆࡔࡠࠫ㯱"),l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ㯲"),l11ll1_l1_ (u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪ㯳"),l11ll1_l1_ (u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ㯴"),l11ll1_l1_ (u"ࠬࡡࡃࡆࡐࡗࡉࡗࡣࠧ㯵")]
		l1l1ll11l111_l1_ = re.findall(l11ll1_l1_ (u"࠭࡜࡜ࡅࡒࡐࡔࡘࠠ࠯ࠬࡂࡠࡢ࠭㯶"),word,re.DOTALL)
		l11l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝࡝ࡆࡓࡑࡕࡒࠤࠥࠦ࠲࠯ࡅ࡜࡞ࠩ㯷"),word,re.DOTALL)
		l1l1ll1ll11l_l1_ = l11l1l111ll_l1_+l1l1ll11l111_l1_+l11l111llll_l1_
		for tag in l1l1ll1ll11l_l1_: word = word.replace(tag,l11ll1_l1_ (u"ࠨࠩ㯸"))
	return word
def l1lll111ll11_l1_(l11lll111ll_l1_,l1llll1ll1ll_l1_,l1ll1l1lllll_l1_,l1l1llllll1l_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l11l11llll1_l1_,l111ll1l11l_l1_,l1l1l1l11111_l1_ = l11ll1_l1_ (u"ࠩࠪ㯹"),0,15000
	l11lll111ll_l1_ = l11lll111ll_l1_.replace(l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ㯺"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠧࠨࠩࠧ㯻"))
	l1l11lll1l11_l1_ = PIL.ImageFont.truetype(l1lllll1111l_l1_,size=l1llll1ll1ll_l1_)
	l1ll1l1lllll_l1_ -= l1llll1ll1ll_l1_*2
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠬࡘࡇࡃࡃࠪ㯼"),(l1ll1l1lllll_l1_,99),(255,255,255,0))
	l1111ll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l1l1llllll_l1_ in l11lll111ll_l1_.splitlines():
		l111ll1l11l_l1_ += l1l1llllll1l_l1_
		l1llll1lllll_l1_,newline = 0,l11ll1_l1_ (u"࠭ࠧ㯽")
		for word in l1l1l1llllll_l1_.split(l11ll1_l1_ (u"ࠧࠡࠩ㯾")):
			l1111l11111_l1_ = l1ll11l11l11_l1_(l11ll1_l1_ (u"ࠨࠢࠪ㯿")+word)
			l1l1ll1llll1_l1_,l1111l11lll_l1_ = l1111ll1l11_l1_.textsize(l1111l11111_l1_,font=l1l11lll1l11_l1_)
			if l1llll1lllll_l1_+l1l1ll1llll1_l1_<l1ll1l1lllll_l1_:
				if not newline: newline += word
				else: newline += l11ll1_l1_ (u"ࠩࠣࠫ㰀")+word
				l1llll1lllll_l1_ += l1l1ll1llll1_l1_
			else:
				if l1l1ll1llll1_l1_<l1ll1l1lllll_l1_:
					newline += l11ll1_l1_ (u"ࠪࡠࡳࠦࠧ㰁")+word
					l111ll1l11l_l1_ += l1l1llllll1l_l1_
					l1llll1lllll_l1_ = l1l1ll1llll1_l1_
				else:
					while l1l1ll1llll1_l1_>l1ll1l1lllll_l1_:
						for l11ll11111_l1_ in range(1,len(l11ll1_l1_ (u"ࠫࠥ࠭㰂")+word),1):
							l1111ll1lll_l1_ = l11ll1_l1_ (u"ࠬࠦࠧ㰃")+word[:l11ll11111_l1_]
							l11111ll11_l1_ = word[l11ll11111_l1_:]
							l1l1l111lll1_l1_ = l1ll11l11l11_l1_(l1111ll1lll_l1_)
							l11l11l1ll1_l1_,l111111l1ll_l1_ = l1111ll1l11_l1_.textsize(l1l1l111lll1_l1_,font=l1l11lll1l11_l1_)
							if l1llll1lllll_l1_+l11l11l1ll1_l1_>l1ll1l1lllll_l1_:
								l1ll1l11l1l1_l1_ = l1l1ll1llll1_l1_-l11l11l1ll1_l1_
								newline += l1111ll1lll_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ㰄")
								l111ll1l11l_l1_ += l1l1llllll1l_l1_
								l1l1ll1llll1_l1_ = l1ll1l11l1l1_l1_
								if l1ll1l11l1l1_l1_>l1ll1l1lllll_l1_:
									l1llll1lllll_l1_ = 0
									word = l11111ll11_l1_
								else:
									l1llll1lllll_l1_ = l1ll1l11l1l1_l1_
									newline += l11111ll11_l1_
								break
				if l111ll1l11l_l1_>l1l1l1l11111_l1_: break
		l11l11llll1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㰅")+newline
		if l111ll1l11l_l1_>l1l1l1l11111_l1_: break
	l11l11llll1_l1_ = l11l11llll1_l1_[1:]
	l11l11llll1_l1_ = l11l11llll1_l1_.replace(l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠤࠥࠦࠫ㰆"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ㰇"))
	return l11l11llll1_l1_
def l111llll111_l1_(text):
	text = text.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭㰈"),l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ㰉"))
	text = text.replace(l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ㰊"),l11ll1_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ㰋"))
	text = text.replace(l11ll1_l1_ (u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠧ㰌"),l11ll1_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡱ࡫ࡦࡵࡡࠪ㰍"))
	text = text.replace(l11ll1_l1_ (u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ㰎"),l11ll1_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡲࡪࡩ࡫ࡸࡤ࠭㰏"))
	text = text.replace(l11ll1_l1_ (u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭㰐"),l11ll1_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡥࡨࡲࡹ࡫ࡲࡠࠩ㰑"))
	text = text.replace(l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㰒"),l11ll1_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥࡥ࡯ࡦࡦࡳࡱࡵࡲࡠࠩ㰓"))
	l1lll1l11111_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢࠫ࠲࠯ࡅࠩ࡝࡟ࠪ㰔"),text,re.DOTALL)
	for l1ll1l1111ll_l1_ in l1lll1l11111_l1_: text = text.replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ㰕")+l1ll1l1111ll_l1_+l11ll1_l1_ (u"ࠪࡡࠬ㰖"),l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ㰗")+l1ll1l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࠧ㰘"))
	return text
def l1l1l11ll1ll_l1_(l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text,l11111lll1l_l1_,l11l11ll1ll_l1_,l1ll11ll1ll1_l1_,l1ll111l1l11_l1_):
	l11l1lll1l1_l1_ = [l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text]
	table_keyy = str(addon_version)+l11ll1_l1_ (u"࠭࡟ࡠࠩ㰙")+str(dest_lang)+l11ll1_l1_ (u"ࠧࡠࡡࠪ㰚")+str(l11l1lll1l1_l1_)
	contents = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㰛"),l11ll1_l1_ (u"ࠩࡗࡖࡆࡔࡓࡍࡃࡗࡉࡉࡥࡄࡊࡃࡏࡓࡌ࡙ࠧ㰜"),table_keyy)
	if not contents:
		if do_trans:
			contents = REVERSO_TRANSLATE(l11l1lll1l1_l1_)
			WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡘࡗࡇࡎࡔࡎࡄࡘࡊࡊ࡟ࡅࡋࡄࡐࡔࡍࡓࠨ㰝"),table_keyy,contents,VERYLONG_CACHE)
	if contents: [l111111ll1l_l1_,l1l1ll111ll1_l1_,l11111l11l1_l1_,header,text] = contents
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㰞"))
		header = header.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㰟"))
		l111111ll1l_l1_ = l111111ll1l_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㰠"))
		l1l1ll111ll1_l1_ = l1l1ll111ll1_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㰡"))
		l11111l11l1_l1_ = l11111l11l1_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㰢"))
	l1111l1l1ll_l1_ = 5
	l1l11lll1111_l1_ = 20
	l1lll1111111_l1_ = 20
	l1ll1l11llll_l1_ = 0
	l11lll11ll1_l1_ = l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㰣")
	l1l1l11l1l1l_l1_ = 0
	l1l1l1l1l1ll_l1_ = 19
	l111ll1l111_l1_ = 30
	l1ll1llll11l_l1_ = 8
	l1ll1l111lll_l1_ = True
	l1l1ll111lll_l1_ = 375
	l1l11llll1ll_l1_ = 410
	l1ll1111ll1l_l1_ = 50
	l1l1llllllll_l1_ = 280
	l111111111l_l1_ = 28
	l1l1l111ll1l_l1_ = 5
	l1llll11ll1l_l1_ = 0
	l1ll1l1llll1_l1_ = 31
	l111l11l111_l1_ = [36,32,28]
	if l11111lll1l_l1_ in [l11ll1_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ㰤"),l11ll1_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ㰥")]:
		if l11111lll1l_l1_==l11ll1_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㰦"):
			l11lll11111_l1_ = l11ll1_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ㰧")
			l11lll11ll1_l1_ = l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㰨")
			l1ll1l111lll_l1_ = True
			l1ll1l11llll_l1_ = 10
		else:
			l11lll11111_l1_ = 97+20
			l11lll11ll1_l1_ = l11ll1_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㰩")
			l1ll1l111lll_l1_ = False
		l111l11l111_l1_ = [33,33,33]
		l1lll1111111_l1_ = 20
		l1l11lll1111_l1_ = 0
		l111ll1l111_l1_ = 20
		l1l1l1l1l1ll_l1_ = 25+10
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭㰪"): l111l11l111_l1_ = [28,24,20] ; l11lll11111_l1_ = 500
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ㰫"): l111l11l111_l1_ = [32,28,24] ; l11lll11111_l1_ = 500
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭㰬"): l111l11l111_l1_ = [36,32,28] ; l11lll11111_l1_ = 500
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㰭"): l11lll11111_l1_ = 740
	elif l11111lll1l_l1_==l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ㰮"): l11lll11111_l1_ = l11ll1_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭㰯")
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭㰰"): l111l11l111_l1_ = [28,23,18] ; l11lll11111_l1_ = 740
	elif l11111lll1l_l1_==l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㰱"): l111l11l111_l1_ = [28,23,18] ; l11lll11111_l1_ = l11ll1_l1_ (u"࡙ࠪࡕࡖࡅࡓࠩ㰲")
	l1llll1ll111_l1_ = l111l11l111_l1_[0]
	l111l1ll11l_l1_ = l111l11l111_l1_[1]
	l11ll1ll1l1_l1_ = l111l11l111_l1_[2]
	l1lllll111l1_l1_ = PIL.ImageFont.truetype(l1lllll1111l_l1_,size=l1llll1ll111_l1_)
	l1lll1111ll1_l1_ = PIL.ImageFont.truetype(l1lllll1111l_l1_,size=l111l1ll11l_l1_)
	l1lll11lllll_l1_ = PIL.ImageFont.truetype(l1lllll1111l_l1_,size=l11ll1ll1l1_l1_)
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠫࡗࡍࡂࡂࠩ㰳"),(100,100),(255,255,255,0))
	l1111ll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	l1111l111ll_l1_,l1ll11l11lll_l1_ = l1111ll1l11_l1_.textsize(l11ll1_l1_ (u"ࠬࡎࡈࡉࠢࡅࡆࡇࠦ࠸࠹࠺ࠣ࠴࠵࠶ࠧ㰴"),font=l1lll1111ll1_l1_)
	l1l1ll1111l1_l1_,l111111l111_l1_ = l1111ll1l11_l1_.textsize(l11ll1_l1_ (u"࠭ࡈࡉࡊࠣࡆࡇࡈࠠ࠹࠺࠻ࠤ࠵࠶࠰ࠨ㰵"),font=l1lllll111l1_l1_)
	l1l1l11l1lll_l1_ = header.count(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㰶"))+1
	l1ll111ll111_l1_ = l1l11lll1111_l1_+l1l1l11l1lll_l1_*(l111111l111_l1_+l1ll1l11llll_l1_)-l1ll1l11llll_l1_
	l1l1l1l1111l_l1_ = {l11ll1_l1_ (u"ࠨࡦࡨࡰࡪࡺࡥࡠࡪࡤࡶࡦࡱࡡࡵࠩ㰷"):False,l11ll1_l1_ (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡢࡰ࡮࡭ࡡࡵࡷࡵࡩࡸ࠭㰸"):True,l11ll1_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࠣࡐࡎࡍࡁࡕࡗࡕࡉࠥࡇࡌࡍࡃࡋࠫ㰹"):False}
	l11l11l11ll_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l1l1l1111l_l1_)
	if text:
		l11ll1ll111_l1_ = l1ll11ll1ll1_l1_-l111ll1l111_l1_*2
		l1l1l1l1l11l_l1_ = l1ll11l11lll_l1_+l1ll1llll11l_l1_
		l1ll11llll11_l1_ = l11l11l11ll_l1_.reshape(text)
		if l1ll1l111lll_l1_:
			l1l11l1l11l1_l1_ = l1lll111ll11_l1_(l1ll11llll11_l1_,l111l1ll11l_l1_,l11ll1ll111_l1_,l1l1l1l1l11l_l1_)
			l1lll1lll11l_l1_ = l1ll11l11l11_l1_(l1l11l1l11l1_l1_)
			l1ll11lll111_l1_ = l1lll1lll11l_l1_.count(l11ll1_l1_ (u"ࠫࡡࡴࠧ㰺"))+1
			if l1ll11lll111_l1_<6:
				#l1l1ll11l11l_l1_ = int(0.8*l11ll1ll111_l1_) if l1ll11lll111_l1_<4 else int(0.9*l11ll1ll111_l1_)
				l1l1ll11l11l_l1_ = l11ll1ll111_l1_
				l1l11l1l11l1_l1_ = l1lll111ll11_l1_(l1ll11llll11_l1_,l111l1ll11l_l1_,l1l1ll11l11l_l1_,l1l1l1l1l11l_l1_)
				l1lll1lll11l_l1_ = l1ll11l11l11_l1_(l1l11l1l11l1_l1_)
				l1ll11lll111_l1_ = l1lll1lll11l_l1_.count(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㰻"))+1
			l11l1ll11l1_l1_ = l1l1l1l1l1ll_l1_+l1ll11lll111_l1_*l1l1l1l1l11l_l1_-l1ll1llll11l_l1_
		else:
			l11l1ll11l1_l1_ = l1l1l1l1l1ll_l1_+l1ll11l11lll_l1_
			l1lll1lll11l_l1_ = l1ll11llll11_l1_.split(l11ll1_l1_ (u"࠭࡜࡯ࠩ㰼"))[0]
			l1l11l1l11l1_l1_ = l1ll11llll11_l1_.split(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㰽"))[0]
	else: l11l1ll11l1_l1_ = l1l1l1l1l1ll_l1_
	l1ll1l1l1ll1_l1_ = l1llll11ll1l_l1_+l1ll1l1llll1_l1_
	if l1ll111l1l11_l1_:
		l1l1lll1l111_l1_ = l1l11llll1ll_l1_-l1l1ll111lll_l1_
		l1ll1l1l1ll1_l1_ += l1l1lll1l111_l1_
	else: l1l1lll1l111_l1_ = 0
	if l111111ll1l_l1_ or l1l1ll111ll1_l1_ or l11111l11l1_l1_: l1ll1l1l1ll1_l1_ += l1ll1111ll1l_l1_
	if l11lll11111_l1_!=l11ll1_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ㰾"): l111l1111ll_l1_ = l11lll11111_l1_
	else: l111l1111ll_l1_ = l1ll111ll111_l1_+l11l1ll11l1_l1_+l1ll1l1l1ll1_l1_
	l1lll1l1ll1l_l1_ = l111l1111ll_l1_-l1ll111ll111_l1_-l1ll1l1l1ll1_l1_-l1l1l1l1l1ll_l1_
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠩࡕࡋࡇࡇࠧ㰿"),(l1ll11ll1ll1_l1_,l111l1111ll_l1_),(255,255,255,0))
	l1111ll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l1ll111ll1_l1_ and l111111ll1l_l1_ and l11111l11l1_l1_:
		l111111111l_l1_ += 105
		l1l1l111ll1l_l1_ -= 110
	if header:
		l1111l1ll11_l1_ = l1l11lll1111_l1_
		header = bidi.algorithm.get_display(l11l11l11ll_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1ll1l111111_l1_ = l1111ll1l11_l1_.textsize(line,font=l1lllll111l1_l1_)
				if l11lll11ll1_l1_==l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㱀"): l1l1ll11lll1_l1_ = l1111l1l1ll_l1_+(l1ll11ll1ll1_l1_-width)/2
				elif l11lll11ll1_l1_==l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㱁"): l1l1ll11lll1_l1_ = l1111l1l1ll_l1_+l1ll11ll1ll1_l1_-width-l1lll1111111_l1_
				elif l11lll11ll1_l1_==l11ll1_l1_ (u"ࠬࡲࡥࡧࡶࠪ㱂"): l1l1ll11lll1_l1_ = l1111l1l1ll_l1_+l1lll1111111_l1_
				l1111ll1l11_l1_.text((l1l1ll11lll1_l1_,l1111l1ll11_l1_),line,font=l1lllll111l1_l1_,fill=l11ll1_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭㱃"))
			l1111l1ll11_l1_ += l1llll1ll111_l1_+l1ll1l11llll_l1_
	if l111111ll1l_l1_ or l1l1ll111ll1_l1_ or l11111l11l1_l1_:
		l11111111l1_l1_ = l1ll111ll111_l1_+l1lll1l1ll1l_l1_+l1l1l1l1l1ll_l1_+l1l1lll1l111_l1_+l1llll11ll1l_l1_
		if l111111ll1l_l1_:
			l111111ll1l_l1_ = bidi.algorithm.get_display(l11l11l11ll_l1_.reshape(l111111ll1l_l1_))
			l1ll11l1l1ll_l1_,l111l111111_l1_ = l1111ll1l11_l1_.textsize(l111111ll1l_l1_,font=l1lll11lllll_l1_)
			l111l111lll_l1_ = l111111111l_l1_+0*(l1l1l111ll1l_l1_+l1l1llllllll_l1_)+(l1l1llllllll_l1_-l1ll11l1l1ll_l1_)/2
			l1111ll1l11_l1_.text((l111l111lll_l1_,l11111111l1_l1_),l111111ll1l_l1_,font=l1lll11lllll_l1_,fill=l11ll1_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ㱄"))
		if l1l1ll111ll1_l1_:
			l1l1ll111ll1_l1_ = bidi.algorithm.get_display(l11l11l11ll_l1_.reshape(l1l1ll111ll1_l1_))
			l1ll1llll1l1_l1_,l1ll1ll111ll_l1_ = l1111ll1l11_l1_.textsize(l1l1ll111ll1_l1_,font=l1lll11lllll_l1_)
			l111l1ll111_l1_ = l111111111l_l1_+1*(l1l1l111ll1l_l1_+l1l1llllllll_l1_)+(l1l1llllllll_l1_-l1ll1llll1l1_l1_)/2
			l1111ll1l11_l1_.text((l111l1ll111_l1_,l11111111l1_l1_),l1l1ll111ll1_l1_,font=l1lll11lllll_l1_,fill=l11ll1_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ㱅"))
		if l11111l11l1_l1_:
			l11111l11l1_l1_ = bidi.algorithm.get_display(l11l11l11ll_l1_.reshape(l11111l11l1_l1_))
			l11l1111ll1_l1_,l11ll1ll1ll_l1_ = l1111ll1l11_l1_.textsize(l11111l11l1_l1_,font=l1lll11lllll_l1_)
			l1llll11l1l1_l1_ = l111111111l_l1_+2*(l1l1l111ll1l_l1_+l1l1llllllll_l1_)+(l1l1llllllll_l1_-l11l1111ll1_l1_)/2
			l1111ll1l11_l1_.text((l1llll11l1l1_l1_,l11111111l1_l1_),l11111l11l1_l1_,font=l1lll11lllll_l1_,fill=l11ll1_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ㱆"))
	if text:
		l1l11ll1l11l_l1_,l11l111ll1l_l1_ = [],[]
		l1l11l1l11l1_l1_ = l111llll111_l1_(l1l11l1l11l1_l1_)
		l1l1l1l1l1l1_l1_ = l1l11l1l11l1_l1_.split(l11ll1_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ㱇"))
		for l1l1l1111l11_l1_ in l1l1l1l1l1l1_l1_:
			l11l1ll1lll_l1_ = l11l11ll1ll_l1_
			if   l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭㱈") in l1l1l1111l11_l1_: l11l1ll1lll_l1_ = l11ll1_l1_ (u"ࠬࡲࡥࡧࡶࠪ㱉")
			elif l11ll1_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ㱊") in l1l1l1111l11_l1_: l11l1ll1lll_l1_ = l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㱋")
			elif l11ll1_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ㱌") in l1l1l1111l11_l1_: l11l1ll1lll_l1_ = l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㱍")
			l11ll111111_l1_ = l1l1l1111l11_l1_
			l11l1l111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ㱎"),l1l1l1111l11_l1_,re.DOTALL)
			for tag in l11l1l111ll_l1_: l11ll111111_l1_ = l11ll111111_l1_.replace(tag,l11ll1_l1_ (u"ࠫࠬ㱏"))
			if l11ll111111_l1_==l11ll1_l1_ (u"ࠬ࠭㱐"): width,l1ll1l111111_l1_ = 0,l1l1l1l1l11l_l1_
			else: width,l1ll1l111111_l1_ = l1111ll1l11_l1_.textsize(l11ll111111_l1_,font=l1lll1111ll1_l1_)
			if   l11l1ll1lll_l1_==l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ㱑"): l1llllll11ll_l1_ = l1l1l11l1l1l_l1_+l111ll1l111_l1_
			elif l11l1ll1lll_l1_==l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㱒"): l1llllll11ll_l1_ = l1l1l11l1l1l_l1_+l111ll1l111_l1_+l11ll1ll111_l1_-width
			elif l11l1ll1lll_l1_==l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㱓"): l1llllll11ll_l1_ = l1l1l11l1l1l_l1_+l111ll1l111_l1_+(l11ll1ll111_l1_-width)/2
			if l1llllll11ll_l1_<l111ll1l111_l1_: l1llllll11ll_l1_ = l1l1l11l1l1l_l1_+l111ll1l111_l1_
			l1l11ll1l11l_l1_.append(l1llllll11ll_l1_)
			l11l111ll1l_l1_.append(width)
		l1llllll11ll_l1_ = l1l11ll1l11l_l1_[0]
		l1l1ll11l1ll_l1_ = l1l11l1l11l1_l1_.split(l11ll1_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࠨ㱔"))
		l11ll11l1l1_l1_ = (255,255,255,255)
		l1lll111l1ll_l1_ = l11ll11l1l1_l1_
		l1l1l1l1l111_l1_,l1ll1lll11l1_l1_ = 0,0
		l1llll11l111_l1_ = False
		l11111ll11l_l1_ = 0
		l1l1l11l1ll1_l1_ = l1ll111ll111_l1_+l1l1l1l1l1ll_l1_/2
		if l11l1ll11l1_l1_<(l1lll1l1ll1l_l1_+l1l1l1l1l1ll_l1_):
			l1l1ll11111l_l1_ = (l1lll1l1ll1l_l1_+l1l1l1l1l1ll_l1_-l11l1ll11l1_l1_)/2
			l1l1l11l1ll1_l1_ = l1ll111ll111_l1_+l1l1l1l1l1ll_l1_+l1l1ll11111l_l1_-l1ll11l11lll_l1_/2
		for line in l1l1ll11l1ll_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1lll111l1_l1_ = line.split(l11ll1_l1_ (u"ࠪࡣࡳ࡫ࡷ࡭࡫ࡱࡩࡤ࠭㱕"),1)
			l1l1lll111ll_l1_ = line.split(l11ll1_l1_ (u"ࠫࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ㱖"),1)
			l1l1lll11l11_l1_ = line.split(l11ll1_l1_ (u"ࠬࡥࡥ࡯ࡦࡦࡳࡱࡵࡲࡠࠩ㱗"),1)
			l1lll11ll1l1_l1_ = line.split(l11ll1_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ㱘"),1)
			l1lll11lll11_l1_ = line.split(l11ll1_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ㱙"),1)
			l1lll11lll1l_l1_ = line.split(l11ll1_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫ࡲࡪࡩ࡫ࡸࡤ࠭㱚"),1)
			l1l1lll1111l_l1_ = line.split(l11ll1_l1_ (u"ࠩࡢࡰ࡮ࡴࡥࡤࡧࡱࡸࡪࡸ࡟ࠨ㱛"),1)
			if len(l1l1lll111l1_l1_)>1:
				l11111ll11l_l1_ += 1
				line = l1l1lll111l1_l1_[1]
				l1l1l1l1l111_l1_ = 0
				l1llllll11ll_l1_ = l1l11ll1l11l_l1_[l11111ll11l_l1_]
				l1ll1lll11l1_l1_ += l1l1l1l1l11l_l1_
				l1llll11l111_l1_ = False
			elif len(l1l1lll111ll_l1_)>1:
				line = l1l1lll111ll_l1_[1]
				l1lll111l1ll_l1_ = line[0:8]
				l1lll111l1ll_l1_ = l11ll1_l1_ (u"ࠪࠧࠬ㱜")+l1lll111l1ll_l1_[2:]
				line = line[9:]
			elif len(l1l1lll11l11_l1_)>1:
				line = l1l1lll11l11_l1_[1]
				l1lll111l1ll_l1_ = l11ll11l1l1_l1_
			elif len(l1lll11ll1l1_l1_)>1:
				line = l1lll11ll1l1_l1_[1]
				l1llll11l111_l1_ = True
				l1l1l1l1l111_l1_ = l11l111ll1l_l1_[l11111ll11l_l1_]
			elif len(l1lll11lll11_l1_)>1:
				line = l1lll11lll11_l1_[1]
			elif len(l1lll11lll1l_l1_)>1:
				line = l1lll11lll1l_l1_[1]
			elif len(l1l1lll1111l_l1_)>1:
				line = l1l1lll1111l_l1_[1]
			if line:
				l1l1lllllll1_l1_ = l1l1l11l1ll1_l1_+l1ll1lll11l1_l1_
				line = bidi.algorithm.get_display(line)
				width,l1ll1l111111_l1_ = l1111ll1l11_l1_.textsize(line,font=l1lll1111ll1_l1_)
				if l1llll11l111_l1_: l1l1l1l1l111_l1_ -= width
				l1llllll11l1_l1_ = l1llllll11ll_l1_+l1l1l1l1l111_l1_
				l1111ll1l11_l1_.text((l1llllll11l1_l1_,l1l1lllllll1_l1_),line,font=l1lll1111ll1_l1_,fill=l1lll111l1ll_l1_)
				if not l1llll11l111_l1_: l1l1l1l1l111_l1_ += width
				if l1l1lllllll1_l1_>l1lll1l1ll1l_l1_+l1l1l1l1l11l_l1_: break
	l1lll1lll111_l1_ = l1l11lll11l1_l1_.replace(l11ll1_l1_ (u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ㱝"),l11ll1_l1_ (u"ࠬࡥࠧ㱞")+str(time.time())+l11ll1_l1_ (u"࠭࡟ࠨ㱟"))
	l1lll1lll111_l1_ = l1lll1lll111_l1_.replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠪ㱠"),l11ll1_l1_ (u"ࠨ࡞࡟ࡠࡡ࠭㱡")).replace(l11ll1_l1_ (u"ࠩ࠲࠳ࠬ㱢"),l11ll1_l1_ (u"ࠪ࠳࠴࠵࠯ࠨ㱣"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1lll1lll111_l1_)
	return l1lll1lll111_l1_,l111l1111ll_l1_
def l1l111lll11_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l1l11l11_l1_=True,l1ll11l1l111_l1_=True):
	# should l1l11l1l1l11_l1_ ==l11ll1_l1_ (u"ࠫࠬ㱤") l1111l11ll_l1_ not l11l111l11_l1_ it to l11ll1_l1_ (u"ࠬࡴ࡯ࡵࠩ㱥")
	if allow_redirects==l11ll1_l1_ (u"࠭ࠧ㱦"): allow_redirects = True
	if l1ll_l1_==l11ll1_l1_ (u"ࠧࠨ㱧"): l1ll_l1_ = True
	if l11l1l11l11_l1_==l11ll1_l1_ (u"ࠨࠩ㱨"): l11l1l11l11_l1_ = True
	if l1ll11l1l111_l1_==l11ll1_l1_ (u"ࠩࠪ㱩"): l1ll11l1l111_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll1l111ll1_l1_ = list(headers.keys())
	if l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㱪") not in l1ll1l111ll1_l1_: headers[l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㱫")] = l11ll1_l1_ (u"ࠬࡆࡀࡁࡕࡎࡍࡕࡥࡈࡆࡃࡇࡉࡗࡆࡀࡁࠩ㱬")
	#if l11ll1_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ㱭") not in l1ll1l111ll1_l1_: headers[l11ll1_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ㱮")] = l11ll1_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠧ㱯")
	l111lll_l1_,l1l1l1l1lll1_l1_,l1ll11l1l1l1_l1_,l1ll1111ll11_l1_ = l1l1ll111l11_l1_(url)
	l1l11ll1llll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㱰"))
	l1l1l11ll1l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㱱"))
	l1l1l1llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㱲"))
	l1l11llll111_l1_ = (l1l1l1l1lll1_l1_==None and l1ll11l1l1l1_l1_==None and l1ll1111ll11_l1_==None)
	l1111l1l11l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㱳")]
	l1l1l11lllll_l1_ = l111lll_l1_ in l1111l1l11l_l1_
	l1111ll1ll1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㱴")]
	l11l1l1l11l_l1_ = l111lll_l1_ in l1111ll1ll1_l1_
	l1111llll11_l1_ = l1l1l11lllll_l1_ or l11l1l1l11l_l1_
	if l1l11llll111_l1_ and l1111llll11_l1_:
		if l1l1l11lllll_l1_:
			l1lll1l1l111_l1_ = l1111l1l11l_l1_.index(l111lll_l1_)
			l1llllll1l11_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㱵")][l1lll1l1l111_l1_]
			l11111l1l1l_l1_ = l1llllllll11_l1_[l1lll1l1l111_l1_]
		elif l11l1l1l11l_l1_:
			l1lll1l1l111_l1_ = l1111ll1ll1_l1_.index(l111lll_l1_)
			l1llllll1l11_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ㱶")][l1lll1l1l111_l1_]
			l11111l1l1l_l1_ = l111ll111ll_l1_[l1lll1l1l111_l1_]
	if l1ll11l1l1l1_l1_==l11ll1_l1_ (u"ࠩࠪ㱷"): l1ll11l1l1l1_l1_ = l1l11ll1llll_l1_
	elif l1ll11l1l1l1_l1_==None and l1l1l11ll1l1_l1_ in [l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㱸"),l11ll1_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㱹")] and l11l1l11l11_l1_: l1ll11l1l1l1_l1_ = l1l11ll1llll_l1_
	if l1l1l11lllll_l1_ or l11l1l1l11l_l1_: timeout = 10
	elif l11ll1_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠨ㱺") in source: timeout = 15
	elif l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍࠨ㱻") in source: timeout = 70
	elif l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㱼") in source: timeout = 75
	elif l11ll1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㱽") in source: timeout = 25
	elif l11ll1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㱾") in source: timeout = 20
	elif source in l1111ll1l1l_l1_: timeout = 5
	else: timeout = 10
	if l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㱿") in source and not data and l11ll1_l1_ (u"ࠫࠫ࠭㲀") not in l111lll_l1_ and l11ll1_l1_ (u"ࠬࡅࠧ㲁") not in l111lll_l1_: l111lll_l1_ = l111lll_l1_.rstrip(l11ll1_l1_ (u"࠭࠯ࠨ㲂"))+l11ll1_l1_ (u"ࠧ࠰ࠩ㲃")
	l11l1l1ll1l_l1_ = (l1l1l1l1lll1_l1_!=None)
	l1ll111lllll_l1_ = (l1ll11l1l1l1_l1_!=None and l1l1l11ll1l1_l1_!=l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭㲄"))
	if l11l1l1ll1l_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠩอๅ฾๐ไࠡสิ์ู่๊ࠡำๅ้ࠬ㲅"),l1l1l1l1lll1_l1_)
	elif l1ll111lllll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠪฮๆ฿๊ๅࠢࡇࡒࡘࠦัใ็ࠪ㲆"),l1ll11l1l1l1_l1_)
	if l11l1l1ll1l_l1_:
		proxies = {l11ll1_l1_ (u"ࠦ࡭ࡺࡴࡱࠤ㲇"):l1l1l1l1lll1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡴࡵࡲࡶࠦ㲈"):l1l1l1l1lll1_l1_}
		l1lll1ll1l1l_l1_ = l1l1l1l1lll1_l1_
	else: proxies,l1lll1ll1l1l_l1_ = {},l11ll1_l1_ (u"࠭ࠧ㲉")
	if l1ll111lllll_l1_:
		import urllib3.util.connection as connection
		l111l1l1l11_l1_ = l1l1l11111ll_l1_(connection,l1l11ll1llll_l1_)
	verify = True
	l1llllll1111_l1_,l1llll1ll11l_l1_,l11ll1111_l1_,l11l1llllll_l1_,l11l1l1l1ll_l1_ = allow_redirects,source,method,False,False
	if l1111llll11_l1_ or (method==l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㲊") and allow_redirects): l1llllll1111_l1_ = False
	if l1l1l11lllll_l1_: l11ll1111_l1_ = l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㲋")
	import requests
	for l11ll11111_l1_ in range(7):
		succeeded = False
		try:
			if l11ll11111_l1_: l1llll1ll11l_l1_ = l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠱ࡴࡶࠪ㲌")
			if not l11l1l1ll1l_l1_: l1l11l11ll1_l1_(False,l111lll_l1_,data,headers,l1llll1ll11l_l1_,l11ll1111_l1_)
			try: response.close()
			except: pass
			l11l111_l1_ = l111lll_l1_
			response = requests.request(l11ll1111_l1_,l111lll_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1llllll1111_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l1llllll_l1_:
					l1lll1lll1l1_l1_ = list(response.headers.keys())
					if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㲍") in l1lll1lll1l1_l1_: l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㲎")]
					elif l11ll1_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㲏") in l1lll1lll1l1_l1_: l111lll_l1_ = response.headers[l11ll1_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㲐")]
					else: l11l1llllll_l1_ = True
					if l1111llll11_l1_ and response.status_code==307:
						l1llllll1111_l1_ = allow_redirects
						l11ll1111_l1_ = method
						l11l1llllll_l1_ = True
						continue
				if not l11l1llllll_l1_ or allow_redirects:
					if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ㲑") not in l111lll_l1_:
						server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ㲒"))
						l111lll_l1_ = server+l111lll_l1_
				if not l11l1llllll_l1_ and allow_redirects:
					l111lll1l1_l1_ = l11l1lll11_l1_(l111lll_l1_)
					if l111lll1l1_l1_ not in [l11ll1_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㲓"),l11ll1_l1_ (u"ࠪ࠲ࡹࡹࠧ㲔"),l11ll1_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㲕"),l11ll1_l1_ (u"ࠬ࠴࡭࡬ࡸࠪ㲖"),l11ll1_l1_ (u"࠭࠮ࡧ࡮ࡹࠫ㲗"),l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ㲘"),l11ll1_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ㲙")]: continue
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11l1l1l1ll_l1_ = True
			l11l111_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status will write a log line: l11ll1_l1_ (u"ࠤࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧࠥ㲚")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			code = -1
			if kodi_version<19: reason = str(err.message).split(l11ll1_l1_ (u"ࠪ࠾ࠥ࠭㲛"))[1]
			else: reason = str(err).split(l11ll1_l1_ (u"ࠫ࠿ࠦࠧ㲜"))[1]
		except requests.exceptions.ConnectionError as err:
			code = -1
			reason = l11ll1_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ㲝")
			try:
				error = err.message[0]
				reason = error
				if l11ll1_l1_ (u"࠭ࡅࡳࡴࡱࡳࠬ㲞") in error: code,reason = re.findall(l11ll1_l1_ (u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤ㲟"),error)[0]
				elif l11ll1_l1_ (u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪ㲠") in error: code,reason = re.findall(l11ll1_l1_ (u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ㲡"),error)[0]
				elif error.count(l11ll1_l1_ (u"ࠪ࠾ࠬ㲢"))>=2: reason,code = re.findall(l11ll1_l1_ (u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧ㲣"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			code = -1
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			code = -1
			reason = l11ll1_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ㲤")
		if l1111llll11_l1_ and not l11l1l1l1ll_l1_ and code!=200:
			l111lll_l1_ = l1llllll1l11_l1_
			l11l1l1l1ll_l1_ = True
			continue
		break
	if l1ll11l1l1l1_l1_!=None and l1l1l11ll1l1_l1_!=l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ㲥"): connection.create_connection = l111l1l1l11_l1_
	if l1l1l11ll1l1_l1_==l11ll1_l1_ (u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧ㲦") and l11l1l11l11_l1_: l1ll11l1l1l1_l1_ = None
	if not succeeded and l1l1l1l1lll1_l1_==None and source not in l1111ll1l1l_l1_:
		l1lllllll111_l1_ = traceback.format_exc()
		sys.stderr.write(l1lllllll111_l1_)
	else: pass
	code = int(code)
	l1ll11111_l1_ = l1l11llll1l_l1_()
	l1ll11111_l1_.code = code
	l1ll11111_l1_.reason = reason
	try: l1ll11111_l1_.content = response.content
	except: l1ll11111_l1_.content = l11ll1_l1_ (u"ࠨࠩ㲧")
	if succeeded:
		l1ll11111_l1_.succeeded = True
		l1ll11111_l1_.headers 	= response.headers
		l1ll11111_l1_.cookies 	= response.cookies
		l1ll11111_l1_.url 	= l11l111_l1_
	#if l1ll11111_l1_.content:
	#	if l1ll11111_l1_.headers[l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ㲨")]==l11ll1_l1_ (u"ࠪ࡫ࡿ࡯ࡰࠨ㲩"):
	#		buffer = _1ll1l11l1ll_l1_(l1ll11111_l1_.content)
	#		l1l11ll11ll1_l1_ = l1l1lll1l11l_l1_.l1l1lll11ll1_l1_(fileobj=buffer)
	#		l1ll11111_l1_.content = l1l11ll11ll1_l1_.read()
	if kodi_version>18.99:
		try: l1ll11111_l1_.content = l1ll11111_l1_.content.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㲪"))
		except: pass
	l1l1l1l111l1_l1_ = l11ll1_l1_ (u"ࠬ࠭㲫")
	if kodi_version<19 or isinstance(l1ll11111_l1_.content,str): l1l1l1l111l1_l1_ = l1ll11111_l1_.content.lower()
	try: response.close()
	except: pass
	l1ll1lll1ll1_l1_ = (l11ll1_l1_ (u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪ㲬") in l1l1l1l111l1_l1_ or l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ㲭") in l1l1l1l111l1_l1_) and l1l1l1l111l1_l1_.count(l11ll1_l1_ (u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ㲮"))>2 and l11ll1_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㲯") not in source
	if code==200 and l1ll1lll1ll1_l1_: l1ll11111_l1_.succeeded = False
	if l1ll11111_l1_.succeeded and l1l11llll111_l1_ and l1111llll11_l1_:
		l1l1lllll_l1_ = l1l11llllll_l1_(l11111l1l1l_l1_)
	if not l1ll11111_l1_.succeeded and source in l1111ll1l1l_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㲰"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡬ࡱࡵࡵࡲࡵࡣࡱࡸࠥࡸࡥࡲࡷࡨࡷࡹࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㲱")+l111lll_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㲲")+source+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㲳"))
	if not l1ll11111_l1_.succeeded and l1l11llll111_l1_:
		l1ll1lll1l11_l1_ = (l11ll1_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㲴") in l1l1l1l111l1_l1_ and l11ll1_l1_ (u"ࠨࡴࡤࡽࠥ࡯ࡤ࠻ࠢࠪ㲵") in l1l1l1l111l1_l1_)
		l1lllll1l1l1_l1_ = (l11ll1_l1_ (u"ࠩ࠸ࠤࡸ࡫ࡣࠨ㲶") in l1l1l1l111l1_l1_ and l11ll1_l1_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ㲷") in l1l1l1l111l1_l1_)
		l1ll1lll1lll_l1_ = (code in [403] and l11ll1_l1_ (u"ࠫࡪࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢ࠴࠴࠷࠶ࠧ㲸") in l1l1l1l111l1_l1_)
		l1ll1llll111_l1_ = (l11ll1_l1_ (u"ࠬࡥࡣࡧࡡࡦ࡬ࡱࡥࠧ㲹") in l1l1l1l111l1_l1_ and l11ll1_l1_ (u"࠭ࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࠯ࠪ㲺") in l1l1l1l111l1_l1_)
		if   l1ll1lll1ll1_l1_: reason = l11ll1_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ㲻")
		elif l1ll1lll1l11_l1_: reason = l11ll1_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ㲼")
		elif l1lllll1l1l1_l1_: reason = l11ll1_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ㲽")
		elif l1ll1lll1lll_l1_: reason = l11ll1_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶࠤࡩ࡫࡮ࡪࡧࡧࠫ㲾")
		elif l1ll1llll111_l1_: reason = l11ll1_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭㲿")
		else: reason = str(reason)
		if source not in l1111ll1l1l_l1_:
			LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㳀"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ㳁")+str(code)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ㳂")+reason+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㳃")+source+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㳄")+l111lll_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭㳅"))
		l1llll1lll1l_l1_ = l1111_l1_(l111lll_l1_)
		if kodi_version<19 and isinstance(l1llll1lll1l_l1_,unicode): l1llll1lll1l_l1_ = l1llll1lll1l_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㳆"))
		if l1111llll11_l1_: l1llll1lll1l_l1_ = l1llll1lll1l_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ㳇"))[-1]
		reason = str(reason)+l11ll1_l1_ (u"࠭࡜࡯ࠪࠣࠫ㳈")+l1llll1lll1l_l1_+l11ll1_l1_ (u"ࠧࠡࠫࠪ㳉")
		if l1ll1lll1ll1_l1_ or l1ll1lll1l11_l1_ or l1lllll1l1l1_l1_ or l1ll1lll1lll_l1_ or l1ll1llll111_l1_:
			code = -2
			l1ll11111_l1_.code = code
			l1ll11111_l1_.reason = reason
		l1ll111ll1_l1_ = True
		if (l1l1l11ll1l1_l1_==l11ll1_l1_ (u"ࠨࡃࡖࡏࠬ㳊") or l1l1l1llll11_l1_==l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㳋")) and (l11l1l11l11_l1_ or l1ll11l1l111_l1_):
			l1ll111ll1_l1_ = l1lll11l1111_l1_(code,reason,source,l1ll_l1_)
			if l1ll111ll1_l1_ and l1l1l11ll1l1_l1_==l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㳌"): l1l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㳍")
			else: l1l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㳎")
			if l1ll111ll1_l1_ and l1l1l1llll11_l1_==l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ㳏"): l1l1l1llll11_l1_ = l11ll1_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㳐")
			else: l1l1l1llll11_l1_ = l11ll1_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㳑")
			settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㳒"),l1l1l11ll1l1_l1_)
			settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㳓"),l1l1l1llll11_l1_)
		if l1ll111ll1_l1_:
			l1lllll1lll1_l1_ = True
			if code==8 and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㳔") in l111lll_l1_ and l1lllll1lll1_l1_:
				if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬ㳕"),l11ll1_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㳖"),time=2000)
				l11l111_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠧࡽࡾࡐࡽࡘ࡙ࡌࡖࡴ࡯ࡁࠬ㳗")
				l1l1lllll_l1_ = l1l111lll11_l1_(method,l11l111_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1lllll_l1_.succeeded:
					l1ll11111_l1_ = l1l1lllll_l1_
					LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㳘"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㳙")+source+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㳚")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㳛"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠬ์ฬศฯࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩ㳜"),l11ll1_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㳝"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㳞"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㳟")+source+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㳠")+url+l11ll1_l1_ (u"ࠪࠤࡢ࠭㳡"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠫๆฺไࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧ㳢"),l11ll1_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㳣"),time=2000)
			if not l1ll11111_l1_.succeeded and l1l1l1llll11_l1_ in [l11ll1_l1_ (u"࠭ࡁࡖࡖࡒࠫ㳤"),l11ll1_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㳥")] and l1ll11l1l111_l1_:
				if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠨฬไ฽๏๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ㳦"),l11ll1_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㳧"),time=2000)
				l1l1lllll_l1_ = l11l1l11l1l_l1_(method,l111lll_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1lllll_l1_.succeeded:
					l1ll11111_l1_ = l1l1lllll_l1_
					LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㳨"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㳩")+source+l11ll1_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㳪")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㳫"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠧ็ฮสัู๊ࠥาใิหฯࠦศา๊ๆื๏࠭㳬"),l11ll1_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㳭"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㳮"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡐࡳࡱࡻ࡭ࡪࡹࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㳯")+source+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㳰")+url+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㳱"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"࠭แีๆࠣื๏ืแาษอࠤอื่ไีํࠫ㳲"),l11ll1_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㳳"),time=2000)
			if not l1ll11111_l1_.succeeded and l1l1l11ll1l1_l1_ in [l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭㳴"),l11ll1_l1_ (u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ㳵")] and l11l1l11l11_l1_:
				if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠪฮๆ฿๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㳶"),l11ll1_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㳷"),time=2000)
				l11l111_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠬࢂࡼࡎࡻࡇࡒࡘ࡛ࡲ࡭࠿ࠪ㳸")
				l1l1lllll_l1_ = l1l111lll11_l1_(method,l11l111_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1lllll_l1_.succeeded:
					l1ll11111_l1_ = l1l1lllll_l1_
					LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㳹"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ㳺")+l1l11ll1llll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㳻")+source+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㳼")+url+l11ll1_l1_ (u"ࠪࠤࡢ࠭㳽"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㳾"),l11ll1_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㳿"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㴀"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ㴁")+l1l11ll1llll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㴂")+source+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㴃")+url+l11ll1_l1_ (u"ࠪࠤࡢ࠭㴄"))
					if l1ll_l1_: l1llllll_l1_(l11ll1_l1_ (u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫ㴅"),l11ll1_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㴆"),time=2000)
		if l1l1l1llll11_l1_==l11ll1_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㴇") or l1l1l11ll1l1_l1_==l11ll1_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㴈"): l1ll_l1_ = False
		if not l1ll11111_l1_.succeeded:
			if l1ll_l1_: l11ll1111l1_l1_ = l1lll11l1111_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l111lll1ll1_l1_ and l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬ㴉") not in source:
				l1llll11l11l_l1_(l11ll1_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡹ࡬ࡸ࡭ࡀࠠࠨ㴊")+source)
	if settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㴋")) not in [l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㴌"),l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ㴍"),l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ㴎")]: settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㴏"),l11ll1_l1_ (u"ࠨࡃࡖࡏࠬ㴐"))
	if settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㴑")) not in [l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㴒"),l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㴓"),l11ll1_l1_ (u"ࠬࡇࡓࡌࠩ㴔")]: settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㴕"),l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ㴖"))
	return l1ll11111_l1_
def OPENURL_REQUESTS_CACHED(l1l11l11l11_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l1l11l11_l1_=True,l1ll11l1l111_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	response = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ㴗"),l11ll1_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㴘"),item)
	if response.succeeded:
		l1l11l11ll1_l1_(True,url,data,headers,source,method)
		return response
	response = l1l111lll11_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l1l11l11_l1_,l1ll11l1l111_l1_)
	if response.succeeded:
		if l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㴙") in source: response.content = DECODE_ADILBO_HTML(response.content)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧ㴚"),item,response,l1l11l11l11_l1_)
	return response
def OPENURL_CACHED(l1l11l11l11_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㴛")
	else:
		method = l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㴜")
		data = l1111_l1_(data)
		dummy,data = l1lll1l111_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1l11l11l11_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㴝"))
	html = str(html)
	return html
def l1l1ll111l11_l1_(url):
	l1l1l1lll11l_l1_ = url.split(l11ll1_l1_ (u"ࠨࡾࡿࠫ㴞"))
	l111lll_l1_,l1l1l1l1lll1_l1_,l1ll11l1l1l1_l1_,l1ll1111ll11_l1_ = l1l1l1lll11l_l1_[0],None,None,None
	for item in l1l1l1lll11l_l1_:
		if l11ll1_l1_ (u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㴟") in item: l1l1l1l1lll1_l1_ = item.split(l11ll1_l1_ (u"ࠪࡁࠬ㴠"))[1]
		elif l11ll1_l1_ (u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ㴡") in item: l1ll11l1l1l1_l1_ = item.split(l11ll1_l1_ (u"ࠬࡃࠧ㴢"))[1]
		elif l11ll1_l1_ (u"࠭ࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ㴣") in item: l1ll1111ll11_l1_ = item.split(l11ll1_l1_ (u"ࠧ࠾ࠩ㴤"))[1]
	return l111lll_l1_,l1l1l1l1lll1_l1_,l1ll11l1l1l1_l1_,l1ll1111ll11_l1_
def RESTORE_PATH_NAME(name):
	start,l1ll111l111_l1_,modified = l11ll1_l1_ (u"ࠨࠩ㴥"),l11ll1_l1_ (u"ࠩࠪ㴦"),l11ll1_l1_ (u"ࠪࠫ㴧")
	name = name.replace(ltr,l11ll1_l1_ (u"ࠫࠬ㴨")).replace(rtl,l11ll1_l1_ (u"ࠬ࠭㴩"))
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭㴪"),name,re.DOTALL)
	if tmp: start,l1ll111l111_l1_,name = tmp[0]
	if start not in [l11ll1_l1_ (u"ࠧࠡࠩ㴫"),l11ll1_l1_ (u"ࠨ࠮ࠪ㴬"),l11ll1_l1_ (u"ࠩࠪ㴭")]: modified = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㴮")
	if l1ll111l111_l1_: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡤ࠭㴯")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠬࡥࠧ㴰")
	#datetime = re.findall(l11ll1_l1_ (u"࠭ࠨࡠ࡞ࡧࡠࡩࡢ࠮࡝ࡦ࡟ࡨࡤࡢࡤ࡝ࡦ࡟࠾ࡡࡪ࡜ࡥࡡࠬࠫ㴱"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11ll1_l1_ (u"ࠧࠨ㴲"))
	name = l1ll111l111_l1_+modified+name
	return name
def l1ll1l1ll1l_l1_(url,l1ll11111ll1_l1_,l1ll111ll1l1_l1_,l1lll1l11l11_l1_,headers={}):
	l1l11l1lll11_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ㴳"))
	l111ll1l1l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㴴")+l1ll11111ll1_l1_)
	if l111ll1l1l1_l1_: l11l111_l1_ = url.replace(l1l11l1lll11_l1_,l111ll1l1l1_l1_)
	else:
		l11l111_l1_ = url
		l111ll1l1l1_l1_ = l1l11l1lll11_l1_
	l1l1lllll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㴵"),l11l111_l1_,l11ll1_l1_ (u"ࠫࠬ㴶"),headers,l11ll1_l1_ (u"ࠬ࠭㴷"),l11ll1_l1_ (u"࠭ࠧ㴸"),l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ㴹"))
	html = l1l1lllll_l1_.content
	try: html = html.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㴺"),l11ll1_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ㴻"))
	except: pass
	if not l1l1lllll_l1_.succeeded or l1lll1l11l11_l1_ not in html:
		l111lll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ㴼")+l1ll111ll1l1_l1_
		l1l1ll111_l1_ = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㴽"):l11ll1_l1_ (u"ࠬ࠭㴾")}
		l1ll11111_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㴿"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ㵀"),l1l1ll111_l1_,l11ll1_l1_ (u"ࠨࠩ㵁"),l11ll1_l1_ (u"ࠩࠪ㵂"),l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭㵃"))
		if l1ll11111_l1_.succeeded:
			html = l1ll11111_l1_.content
			if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㵄"),l11ll1_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㵅"))
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡸࡶࡱࡢ࠿ࡲ࠿ࠫ࠲࠯ࡅࠩࠣࠩ㵆"),html,re.DOTALL)
			l1lllll1l1ll_l1_ = [l111ll1l1l1_l1_]
			for l1lllll_l1_ in l1l1_l1_:
				if l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠫ㵇") in l1lllll_l1_: continue
				l111ll1l1l1_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ㵈"))
				if l111ll1l1l1_l1_ in l1lllll1l1ll_l1_: continue
				if len(l1lllll1l1ll_l1_)==7:
					LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㵉"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㵊")+l1ll11111ll1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ㵋")+l1l11l1lll11_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㵌"))
					settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ㵍")+l1ll11111ll1_l1_,l11ll1_l1_ (u"ࠧࠨ㵎"))
					break
				l1lllll1l1ll_l1_.append(l111ll1l1l1_l1_)
				l11l111_l1_ = url.replace(l1l11l1lll11_l1_,l111ll1l1l1_l1_)
				l1l1lllll_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㵏"),l11l111_l1_,l11ll1_l1_ (u"ࠩࠪ㵐"),headers,l11ll1_l1_ (u"ࠪࠫ㵑"),l11ll1_l1_ (u"ࠫࠬ㵒"),l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨ㵓"))
				html = l1l1lllll_l1_.content
				if l1l1lllll_l1_.succeeded and l1lll1l11l11_l1_ in html:
					LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㵔"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ㵕")+l1ll11111ll1_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ㵖")+l111ll1l1l1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ㵗")+l1l11l1lll11_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭㵘"))
					settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭㵙")+l1ll11111ll1_l1_,l111ll1l1l1_l1_)
					break
	return l111ll1l1l1_l1_,l11l111_l1_,l1l1lllll_l1_
def TRANSLATE(text):
	dict = {
	 l11ll1_l1_ (u"ࠬࡵ࡬ࡥࠩ㵚")			:l11ll1_l1_ (u"࠭โะ์่ࠫ㵛")
	,l11ll1_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㵜")		:l11ll1_l1_ (u"ࠨ็อ์็็ࠧ㵝")
	,l11ll1_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㵞")		:l11ll1_l1_ (u"้ࠪๆ่่ะࠩ㵟")
	,l11ll1_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ㵠")			:l11ll1_l1_ (u"ࠬา๊ะࠩ㵡")
	,l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㵢")		:l11ll1_l1_ (u"ࠧโึ็ࠫ㵣")
	,l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㵤")		:l11ll1_l1_ (u"่ࠩะ้ีࠧ㵥")
	,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㵦")		:l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊ࠪ㵧")
	,l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㵨")			:l11ll1_l1_ (u"࠭โ็ษฬࠫ㵩")
	,l11ll1_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠭㵪")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ㵫")
	,l11ll1_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㵬")		:l11ll1_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ㵭")
	,l11ll1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭㵮")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭㵯")
	,l11ll1_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭㵰")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ㵱")
	,l11ll1_l1_ (u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ㵲")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ㵳")
	,l11ll1_l1_ (u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭㵴")	:l11ll1_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ㵵")
	,l11ll1_l1_ (u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ㵶")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ㵷")
	,l11ll1_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㵸")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ㵹")
	,l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭㵺")	:l11ll1_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ㵻")
	,l11ll1_l1_ (u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭㵼")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣหู้๊็็สࠫ㵽")
	,l11ll1_l1_ (u"࠭ࡨࡦ࡮ࡤࡰࠬ㵾")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ㵿")
	,l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ㶀")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ㶁")
	,l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ㶂")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭㶃")
	,l11ll1_l1_ (u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧ㶄")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭㶅")
	,l11ll1_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ㶆")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ㶇")
	,l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㶈")		:l11ll1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ㶉")
	,l11ll1_l1_ (u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧ㶊")	:l11ll1_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ㶋")
	,l11ll1_l1_ (u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㶌")	:l11ll1_l1_ (u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭㶍")
	,l11ll1_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㶎")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ㶏")
	,l11ll1_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㶐")		:l11ll1_l1_ (u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪ㶑")
	,l11ll1_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㶒")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ㶓")
	,l11ll1_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ㶔")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ㶕")
	,l11ll1_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ㶖")		:l11ll1_l1_ (u"้ࠪํู่ࠡสๆีฬ࠭㶗")
	,l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭㶘")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭㶙")
	,l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠭㶚")		:l11ll1_l1_ (u"ࠧๆๆไࠫ㶛")
	,l11ll1_l1_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩ㶜")		:l11ll1_l1_ (u"่่ࠩๆ࠭㶝")
	,l11ll1_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ㶞")		:l11ll1_l1_ (u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭㶟")
	,l11ll1_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨ㶠")	:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫ㶡")
	,l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ㶢")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ㶣")
	,l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ㶤")		:l11ll1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬ㶥")
	,l11ll1_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ㶦")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬ㶧")
	,l11ll1_l1_ (u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧ㶨")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧ㶩")
	,l11ll1_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ㶪")		:l11ll1_l1_ (u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩ㶫")
	,l11ll1_l1_ (u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫ㶬")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪ㶭")
	,l11ll1_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ㶮")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭㶯")
	,l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ㶰")	:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩ㶱")
	,l11ll1_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭㶲")	:l11ll1_l1_ (u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫ㶳")
	,l11ll1_l1_ (u"ࠫ࡫ࡵࡳࡵࡣࠪ㶴")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣๅํูสศࠩ㶵")
	,l11ll1_l1_ (u"࠭ࡡࡩࡹࡤ࡯ࠬ㶶")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩ㶷")
	,l11ll1_l1_ (u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩ㶸")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠโสิ็ฮ࠭㶹")
	,l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬ㶺")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㶻")
	,l11ll1_l1_ (u"ࠬࡹࡨࡰࡨ࡫ࡥࠬ㶼")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨ㶽")
	,l11ll1_l1_ (u"ࠧࡣࡴࡶࡸࡪࡰࠧ㶾")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭㶿")
	,l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪ㷀")		:l11ll1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪ㷁")
	,l11ll1_l1_ (u"ࠫࡱࡧࡲࡰࡼࡤࠫ㷂")		:l11ll1_l1_ (u"๋่ࠬใ฻่ࠣฬื่ำษࠪ㷃")
	,l11ll1_l1_ (u"࠭ࡹࡢࡳࡲࡸࠬ㷄")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ㷅")
	,l11ll1_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ㷆")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭㷇")
	,l11ll1_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨ㷈")	:l11ll1_l1_ (u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭㷉")
	,l11ll1_l1_ (u"ࠬࡪࡲࡢ࡯ࡤࡷ࠼࠭㷊")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤิืวๆษูࠣา࠭㷋")
	,l11ll1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ㷌")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧ㷍")
	,l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡳࠫ㷎")		:l11ll1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫ㷏")
	,l11ll1_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯ࠪ㷐")				:l11ll1_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩ㷑")
	,l11ll1_l1_ (u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬ㷒")			:l11ll1_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩ㷓")
	,l11ll1_l1_ (u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨ㷔")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧ㷕")
	,l11ll1_l1_ (u"ࠪࡴࡦࡴࡥࡵࠩ㷖")				:l11ll1_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠨ㷗")
	,l11ll1_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ㷘")			:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩ㷙")
	,l11ll1_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭㷚")			:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭㷛")
	,l11ll1_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㷜")				:l11ll1_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨ㷝")
	,l11ll1_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬ㷞")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ㷟")
	,l11ll1_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ㷠")	:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫ㷡")
	,l11ll1_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㷢")		:l11ll1_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭㷣")
	,l11ll1_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠭㷤")			:l11ll1_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭㷥")
	,l11ll1_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡲࡨࡶࡸࡵ࡮ࡴࠩ㷦")	:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡไสีห࠭㷧")
	,l11ll1_l1_ (u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪ㷨")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩ㷩")
	,l11ll1_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬ㷪")		:l11ll1_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬ㷫")
	,l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㷬")			:l11ll1_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭㷭")
	,l11ll1_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡻ࡯ࡤࡦࡱࡶࠫ㷮")	:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪ㷯")
	,l11ll1_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ㷰"):l11ll1_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ㷱")
	,l11ll1_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㷲")	:l11ll1_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่ࠥๆ้ษอࠫ㷳")
	,l11ll1_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡸࡴࡶࡩࡤࡵࠪ㷴")	:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠๆ๊สฺ๏฿ࠧ㷵")
	,l11ll1_l1_ (u"ࠧࡪࡲࡷࡺࠬ㷶")					:l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠭㷷")
	,l11ll1_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬ㷸")			:l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧ㷹")
	,l11ll1_l1_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㷺")			:l11ll1_l1_ (u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩ㷻")
	,l11ll1_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㷼")			:l11ll1_l1_ (u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭㷽")
	,l11ll1_l1_ (u"ࠨ࡯࠶ࡹࠬ㷾")					:l11ll1_l1_ (u"ࠩࡐ࠷࡚࠭㷿")
	,l11ll1_l1_ (u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬ㸀")				:l11ll1_l1_ (u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧ㸁")
	,l11ll1_l1_ (u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㸂")			:l11ll1_l1_ (u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩ㸃")
	,l11ll1_l1_ (u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㸄")			:l11ll1_l1_ (u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭㸅")
	}
	try: result = dict[text.lower()]
	except: result = l11ll1_l1_ (u"ࠩࠪ㸆")
	return result
def l1llll11l11l_l1_(message=l11ll1_l1_ (u"ࠪࠫ㸇")):
	l1ll111lll11_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11ll1_l1_ (u"ࠫ࠿࠵ࠧ㸈")):
	return _1lll1111l11_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l111l11ll11_l1_(l1l111ll1_l1_):
	if l1l111ll1_l1_ in [l11ll1_l1_ (u"ࠬ࠭㸉"),l11ll1_l1_ (u"࠭࠰ࠨ㸊"),0]: return l11ll1_l1_ (u"ࠧࠨ㸋")
	l1l111ll1_l1_ = int(l1l111ll1_l1_)
	first = l1l111ll1_l1_^l1lllll1_l1_
	second = l1l111ll1_l1_^REGULAR_CACHE
	l1ll1lll1_l1_ = l1l111ll1_l1_^l1ll1ll1l_l1_
	result = str(first)+str(second)+str(l1ll1lll1_l1_)
	return result
def l1l1l111l111_l1_(l1l111ll1_l1_):
	if l1l111ll1_l1_ in [l11ll1_l1_ (u"ࠨࠩ㸌"),l11ll1_l1_ (u"ࠩ࠳ࠫ㸍"),0]: return l11ll1_l1_ (u"ࠪࠫ㸎")
	l1l111ll1_l1_ = str(l1l111ll1_l1_)
	result = l11ll1_l1_ (u"ࠫࠬ㸏")
	if len(l1l111ll1_l1_)==15:
		first,second,l1ll1lll1_l1_ = l1l111ll1_l1_[0:4],l1l111ll1_l1_[4:9],l1l111ll1_l1_[9:]
		first = int(first)^l1ll1ll1l_l1_
		second = int(second)^REGULAR_CACHE
		l1ll1lll1_l1_ = int(l1ll1lll1_l1_)^l1lllll1_l1_
		if first==second==l1ll1lll1_l1_: result = str(first*60)
	return result
def l1ll11l11111_l1_(l1l111ll1_l1_):
	if l1l111ll1_l1_ in [l11ll1_l1_ (u"ࠬ࠭㸐"),l11ll1_l1_ (u"࠭࠰ࠨ㸑"),0]: return l11ll1_l1_ (u"ࠧࠨ㸒")
	l1l111ll1_l1_ = int(l1l111ll1_l1_)+63841823
	first = l1l111ll1_l1_^l1lllll1_l1_
	second = l1l111ll1_l1_^REGULAR_CACHE
	l1ll1lll1_l1_ = l1l111ll1_l1_^l1ll1ll1l_l1_
	result = str(first)+str(second)+str(l1ll1lll1_l1_)
	return result
def l1llll111ll1_l1_(l1l111ll1_l1_):
	if l1l111ll1_l1_ in [l11ll1_l1_ (u"ࠨࠩ㸓"),l11ll1_l1_ (u"ࠩ࠳ࠫ㸔"),0]: return l11ll1_l1_ (u"ࠪࠫ㸕")
	l1l111ll1_l1_ = str(l1l111ll1_l1_)
	length = int(len(l1l111ll1_l1_)/3)
	first = int(l1l111ll1_l1_[0:length])^l1lllll1_l1_
	second = int(l1l111ll1_l1_[length:2*length])^REGULAR_CACHE
	l1ll1lll1_l1_ = int(l1l111ll1_l1_[2*length:3*length])^l1ll1ll1l_l1_
	result = l11ll1_l1_ (u"ࠫࠬ㸖")
	if first==second==l1ll1lll1_l1_: result = str(int(first)-63841823)
	return result
def l1l1l11ll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11l1ll_l1_(l1l1lll11111_l1_,l1l1ll1l1lll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭㸗"),l11ll1_l1_ (u"࠭ࠧ㸘"),l11ll1_l1_ (u"ࠧࠨ㸙"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㸚"),l1l1lll11111_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㸛")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㸜"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1lll11111_l1_):
		#os.chmod(l1l1lll11111_l1_,0o777)
		for root,dirs,files in os.walk(l1l1lll11111_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㸝"),l11ll1_l1_ (u"ࠬ࠭㸞"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㸟"),str(err))
					error = True
			if l1l1ll1l1lll_l1_:
				for dir in dirs:
					l1l11l1ll111_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l11l1ll111_l1_)
					except: pass
		if l1l1ll1l1lll_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㸠"),l11ll1_l1_ (u"ࠨࠩ㸡"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㸢"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ㸣"))
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㸤"),l11ll1_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ㸥"))
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㸦"))
	return
def l1ll111lll11_l1_(l1lllllll111_l1_=l11ll1_l1_ (u"ࠧࠨ㸧")):
	#if l1lllllll111_l1_:
	#	if l11ll1_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ㸨") in l1lllllll111_l1_:
	#		message  = l1lllllll111_l1_.split(l11ll1_l1_ (u"ࠩࡢࡣࡋࡕࡒࡄࡇࡇࡣࡊ࡞ࡉࡕࡡࡢࠫ㸩"))[1]
	#		LOG_THIS(l11ll1_l1_ (u"ࠪࠫ㸪"),l11ll1_l1_ (u"ࠫࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕࠢࠣࠤࠥ࠴ࠠࠡࠢࠪ㸫")+message)
	#		#sys.stderr.write(l11ll1_l1_ (u"ࠬࡌࡏࡓࡅࡈࡈࠥࡋࡘࡊࡖ࠽ࡠࡳ࠭㸬")+message+l11ll1_l1_ (u"࠭࡜࡯ࡡࠪ㸭"))
	#	else: l11ll11llll_l1_(l1lllllll111_l1_)
	if l1lllllll111_l1_: l11ll11llll_l1_(l1lllllll111_l1_)
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㸮"))
	if l1l11llll1_l1_==l11ll1_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ㸯"): settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㸰"),l11ll1_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㸱"))
	elif l1l11llll1_l1_==l11ll1_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㸲"): settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㸳"),l11ll1_l1_ (u"࠭ࠧ㸴"))
	if settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㸵")) not in [l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭㸶"),l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ㸷"),l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㸸")]: settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㸹"),l11ll1_l1_ (u"ࠬࡇࡓࡌࠩ㸺"))
	if settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㸻")) not in [l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ㸼"),l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭㸽"),l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㸾")]: settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㸿"),l11ll1_l1_ (u"ࠫࡆ࡙ࡋࠨ㹀"))
	l11ll11l11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㹁"))
	l111l1ll1ll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ㹂"))
	if l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭㹃") in str(l111l1ll1ll_l1_) and l11ll11l11l_l1_ in [l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫ㹄"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ㹅")]:
		#l1llllll_l1_(l11ll1_l1_ (u"ࠪࠫ㹆"),l11ll11l11l_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨ㹇"))
	#l11l1l1111l_l1_ = sys.version_info[0]
	#l111l11llll_l1_ = sys.version_info[1]
	#if l11l1l1111l_l1_==2: python_version = l11ll1_l1_ (u"ࠬ࠸࠷ࠨ㹈")
	#else: python_version = str(l11l1l1111l_l1_)+str(l111l11llll_l1_)
	#l11l1lllll1_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭㹉")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㹊"),l11ll1_l1_ (u"ࠨࠩ㹋"),l11ll1_l1_ (u"ࠩࠪ㹌"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llllll1ll1_l1_,l11l1l11lll_l1_)
	return
from EXCLUDES import *
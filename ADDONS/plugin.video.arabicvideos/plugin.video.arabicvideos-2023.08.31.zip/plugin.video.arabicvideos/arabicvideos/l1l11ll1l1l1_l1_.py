# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ䩤")
headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䩥") : l11ll1_l1_ (u"࠭ࠧ䩦") }
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡏ࡙࡞ࡤ࠭䩧")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11111_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llll11_l1_(url)
	elif mode==188: results = l11ll1l1l1ll_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11ll1l1l1ll_l1_():
	message = l11ll1_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭䩨")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䩩"),l11ll1_l1_ (u"ࠪࠫ䩪"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䩫"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䩬"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䩭"),l11ll1_l1_ (u"ࠧࠨ䩮"),189,l11ll1_l1_ (u"ࠨࠩ䩯"),l11ll1_l1_ (u"ࠩࠪ䩰"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䩱"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䩲"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䩳")+l111l1_l1_+l11ll1_l1_ (u"࠭ศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ีࠧ䩴"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠧࠨ䩵"),l11ll1_l1_ (u"ࠨࠩ䩶"),l11ll1_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭䩷"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䩸"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䩹")+l111l1_l1_+l11ll1_l1_ (u"ࠬษอะอࠣห้อแๅษ่ࠫ䩺"),l11l1l_l1_,181,l11ll1_l1_ (u"࠭ࠧ䩻"),l11ll1_l1_ (u"ࠧࠨ䩼"),l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䩽"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䩾"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䩿")+l111l1_l1_+l11ll1_l1_ (u"ࠫฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ัࠪ䪀"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠬ࠭䪁"),l11ll1_l1_ (u"࠭ࠧ䪂"),l11ll1_l1_ (u"ࠧࡵࡸࠪ䪃"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䪄"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䪅")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้อใฬำู้ࠣอ็ะหࠪ䪆"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠫࠬ䪇"),l11ll1_l1_ (u"ࠬ࠭䪈"),l11ll1_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䪉"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䪊"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䪋")+l111l1_l1_+l11ll1_l1_ (u"ࠩฦๆํ๏ࠠศๆสๅ้อๅࠡษ็ัฬ๊๊สࠩ䪌"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠪࠫ䪍"),l11ll1_l1_ (u"ࠫࠬ䪎"),l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䪏"))
	html = OPENURL_CACHED(l1lllll1_l1_,l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ䪐"),headers,l11ll1_l1_ (u"ࠧࠨ䪑"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䪒"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿࡬࠷ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䪓"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䪔"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䪕")+l111l1_l1_+title,l1lllll_l1_,181)
	return html
def l11111_l1_(url,type=l11ll1_l1_ (u"ࠬ࠭䪖")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"࠭ࠧ䪗"),headers,l11ll1_l1_ (u"ࠧࠨ䪘"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䪙"))
	if type==l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䪚"): block = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁวาีหࠡษ็วๆ๊วๆ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࡮࠱ࠨ䪛"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ䪜"): block = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ䪝"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䪞"): block = re.findall(l11ll1_l1_ (u"ࠧࡣࡶࡱ࠱࠷࠳࡯ࡷࡧࡵࡰࡦࡿࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬ䪟"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䪠"): block = re.findall(l11ll1_l1_ (u"ࠩࡥࡸࡳ࠳࠱ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽ࠭࠴ࠪࡀࠫࡥࡸࡳ࠳࠲ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽࠬ䪡"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠪࡸࡻ࠭䪢"): block = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱ࡫ࠧ࠭䪣"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䪤"),l11ll1_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䪥")]:
		items = re.findall(l11ll1_l1_ (u"ࠧࡴࡶࡼࡰࡪࡃࠢࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䪦"),block,re.DOTALL)
	else: items = re.findall(l11ll1_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴ࠾ࠤ࠶࡟࠵࠳࠹࡞࠭ࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵࡴࡵࡱࡰ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䪧"),block,re.DOTALL)
	l11l_l1_ = []
	l111ll1ll_l1_ = [l11ll1_l1_ (u"ࠩไ๎้๋ࠧ䪨"),l11ll1_l1_ (u"ࠪห้ำไใหࠪ䪩"),l11ll1_l1_ (u"ࠫฬ๊อๅไ๊ࠫ䪪"),l11ll1_l1_ (u"ࠬ฿ัืࠩ䪫"),l11ll1_l1_ (u"࠭ࡒࡢࡹࠪ䪬"),l11ll1_l1_ (u"ࠧࡔ࡯ࡤࡧࡰࡊ࡯ࡸࡰࠪ䪭"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ䪮"),l11ll1_l1_ (u"ࠩสะือมࠨ䪯")]
	for l1lll1_l1_,l11ll1l11111_l1_,l11ll1l1ll11_l1_,l11ll1l1ll1l_l1_ in items:
		if type in [l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䪰"),l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䪱")]:
			l1lll1_l1_,l1lllll_l1_,l1lllll111_l1_,title = l1lll1_l1_,l11ll1l11111_l1_,l11ll1l1ll11_l1_,l11ll1l1ll1l_l1_
		else: l1lll1_l1_,title,l1lllll_l1_,l1lllll111_l1_ = l1lll1_l1_,l11ll1l11111_l1_,l11ll1l1ll11_l1_,l11ll1l1ll1l_l1_
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࡅࡶࡪࡧࡺࡁࡹࡸࡵࡦࠩ䪲"),l11ll1_l1_ (u"࠭ࠧ䪳"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䪴"),l11ll1_l1_ (u"ࠨࠩ䪵"),l1lllll_l1_,l1lllll111_l1_)
		title = unescapeHTML(title)
		#l1lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠩสฯ์ิฯࡼษฮ๋ำ์࠯ࠧ䪶"),title,re.DOTALL)
		#if l1lll1l11_l1_: title = l1lll1l11_l1_[0][0]
		if l11ll1_l1_ (u"ࠪฬั๎ฯสࠢࠪ䪷") in title or l11ll1_l1_ (u"ࠫอา่ะ้ࠣࠫ䪸") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䪹") + title.replace(l11ll1_l1_ (u"࠭ศอ๊าอࠥ࠭䪺"),l11ll1_l1_ (u"ࠧࠨ䪻")).replace(l11ll1_l1_ (u"ࠨสฯ์ิํࠠࠨ䪼"),l11ll1_l1_ (u"ࠩࠪ䪽"))
		title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ䪾"))
		if l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫ䪿") in title or l11ll1_l1_ (u"ࠬอไฮๆๅ๋ࠬ䫀") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡝ࡦ࠮ࠫ䫁"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䫂") + l1ll1l1_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䫃"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111ll1ll_l1_):
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䫄") + l1lllll111_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䫅"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䫆") + l1lllll111_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䫇"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
	if type==l11ll1_l1_ (u"࠭ࠧ䫈"):
		items = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡰ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䫉"),html,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠨษ็ูๆำษࠡࠩ䫊"),l11ll1_l1_ (u"ࠩࠪ䫋"))
			if title!=l11ll1_l1_ (u"ࠪࠫ䫌"):
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䫍"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ䫎")+title,l1lllll_l1_,181)
	return
def l1llll11_l1_(url):
	l111lll_l1_ = url.split(l11ll1_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䫏"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ䫐"),headers,l11ll1_l1_ (u"ࠨࠩ䫑"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䫒"))
	block = re.findall(l11ll1_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡺ࡬ࡦࡀ࠱࠮ࡄ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䫓"),html,re.DOTALL)
	title,dummy,l1lll1_l1_ = block[0]
	name = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡡ࠰࠮࠻ࡠ࠯ࠬ䫔"),title,re.DOTALL)
	if name: name = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䫕") + name[0][0]
	else: name = title
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳࡏࡷࡰࡦࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䫖"),html,re.DOTALL)
	if l1l1l11_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䫗"),l11ll1_l1_ (u"ࠨࠩ䫘"),l111lll_l1_,str(l1l1l11_l1_))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫙"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			title = re.findall(l11ll1_l1_ (u"ࠪࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭࠲࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ䫚"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭䫛"))[-2],re.DOTALL)
			if not title: title = re.findall(l11ll1_l1_ (u"ࠬ࠮ࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䫜"),l1lllll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ䫝"))[-2],re.DOTALL)
			if title: title = l11ll1_l1_ (u"ࠧࠡࠩ䫞") + title[0][1]
			else: title = l11ll1_l1_ (u"ࠨࠩ䫟")
			title = name + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭䫠") + l11ll1_l1_ (u"ࠪห้ำไใหࠪ䫡") + title
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䫢"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䫣") in title or l11ll1_l1_ (u"࠭ศอ๊า๋ࠥ࠭䫤") in title:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䫥") + title.replace(l11ll1_l1_ (u"ࠨสฯ์ิฯࠠࠨ䫦"),l11ll1_l1_ (u"ࠩࠪ䫧")).replace(l11ll1_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䫨"),l11ll1_l1_ (u"ࠫࠬ䫩"))
		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䫪"),l111l1_l1_+title,url,182,l1lll1_l1_)
	return
def PLAY(url):
	l11ll1l1lll1_l1_ = url.split(l11ll1_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䫫"))
	l111lll_l1_ = l11ll1l1lll1_l1_[0]
	del l11ll1l1lll1_l1_[0]
	html = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ䫬"),headers,l11ll1_l1_ (u"ࠨࠩ䫭"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䫮"))
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡪࡴࡴࡴ࠮ࡵ࡬ࡾࡪࡀࠠ࠳࠷ࡳࡼࡀࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫯"),html,re.DOTALL)[0]
	if l1lllll_l1_ not in l11ll1l1lll1_l1_: l11ll1l1lll1_l1_.append(l1lllll_l1_)
	l1llll_l1_ = []
	# l11ll1l1l111_l1_
	for l1lllll_l1_ in l11ll1l1lll1_l1_:
		if l11ll1_l1_ (u"ࠫ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ䫰") in l1lllll_l1_:
			l11ll1l1l111_l1_ = l1lllll_l1_
			l1llll_l1_.append(l11ll1l1l111_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓࡡࡪࡰࠪ䫱"))
	# l11ll1l11lll_l1_
	for l1lllll_l1_ in l11ll1l1lll1_l1_:
		if l11ll1_l1_ (u"࠭࠺࠰࠱ࡹࡦ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠩ䫲") in l1lllll_l1_:
			html = OPENURL_CACHED(l1lllll1_l1_,l1lllll_l1_,l11ll1_l1_ (u"ࠧࠨ䫳"),headers,l11ll1_l1_ (u"ࠨࠩ䫴"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ䫵"))
			html = html.decode(l11ll1_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩ䫶")).encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䫷"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11ll11lllll_l1_><l11ll1l111ll_l1_ /><l11ll11lllll_l1_ l11ll1l1l1l1_l1_=l11ll1_l1_ (u"ࠧࡩࡥ࡯ࡶࡨࡶࠧ䫸")>(\*\*\*\*\*\*\*\*|13721411411.l11ll11lll1l_l1_|)
			html = html.replace(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡧࡴࡳ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䫹"),l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䫺"))
			html = html.replace(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䫻"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䫼"))
			html = html.replace(l11ll1_l1_ (u"ࠪࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡣࡴࠣ࠳ࡃࡂࡤࡪࡸࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࡂࠬ䫽"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䫾"))
			html = html.replace(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡢࡰࡴࡧࡩࡷࠨࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠨ䫿"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䬀"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ䬁"),html,re.DOTALL)
			if l1l1l11_l1_:
				#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䬂"),l11ll1_l1_ (u"ࠩࠪ䬃"),url,str(len(l1l1l11_l1_)))
				l11ll11llll1_l1_,l11ll1l11ll1_l1_ = [],[]
				if len(l1l1l11_l1_)==1:
					title = l11ll1_l1_ (u"ࠪࠫ䬄")
					block = html
				else:
					for block in l1l1l11_l1_:
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠰࠭ࡃࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮࠰࠮࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䬅"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䬆") + l111l_l1_[0][1]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴ࠤࠣ࠳ࡃ࠮࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䬇"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ䬈") + l111l_l1_[0]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃ࠮ࡂࡨࡳࠢࡶ࡭ࡿ࡫࠽ࠣ࠳ࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳࠼ࠢࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵ࠥࠤ࠴ࡄ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䬉"),block,re.DOTALL)
						if l111l_l1_: block = l111l_l1_[0] + l11ll1_l1_ (u"ࠩࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䬊")
						l11ll1l1l11l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀ࠭࠴ࠪࡀࠫ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰ࠩ䬋"),block,re.DOTALL)
						title = re.findall(l11ll1_l1_ (u"ࠫࡃࠦࠪࠩ࡝ࡡࡀࡃࡣࠫࠪࠢ࠭ࡀࠬ䬌"),l11ll1l1l11l_l1_[0][0],re.DOTALL)
						title = l11ll1_l1_ (u"ࠬࠦࠧ䬍").join(title)
						title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ䬎"))
						title = title.replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䬏"),l11ll1_l1_ (u"ࠨࠢࠪ䬐")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䬑"),l11ll1_l1_ (u"ࠪࠤࠬ䬒")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䬓"),l11ll1_l1_ (u"ࠬࠦࠧ䬔")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䬕"),l11ll1_l1_ (u"ࠧࠡࠩ䬖")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䬗"),l11ll1_l1_ (u"ࠩࠣࠫ䬘"))
						l11ll11llll1_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้ส࠽ࠫ䬙"), l11ll11llll1_l1_)
					if l1l_l1_ == -1 : return
					title = l11ll11llll1_l1_[l1l_l1_]
					block = l1l1l11_l1_[l1l_l1_]
				l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱ࠯ࠢࠨ䬚"),block,re.DOTALL)
				l11ll1l11l11_l1_ = l1lllll_l1_[0]
				l1llll_l1_.append(l11ll1l11l11_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡌ࡯ࡳࡷࡰࠫ䬛"))
				block = block.replace(l11ll1_l1_ (u"࠭เࠨ䬜"),l11ll1_l1_ (u"ࠧࠨ䬝"))
				block = block.replace(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ䬞"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䬟"))
				block = block.replace(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ䬠"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䬡"))
				block = block.replace(l11ll1_l1_ (u"ู๊ࠬาใิหฯࠦวๅฬะ้๏๊ࠧ䬢"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭䬣"))
				block = block.replace(l11ll1_l1_ (u"ࠧา๊สฬ฼ࠦวๅฬะ้๏๊ࠧ䬤"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ䬥"))
				block = block.replace(l11ll1_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้๋ิศ้าࠫ䬦"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䬧"))
				block = block.replace(l11ll1_l1_ (u"ࠫึ๎วษูࠣห้๋ิศ้าࠫ䬨"),l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ䬩"))
				l11ll1l1111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࡞ࡧ࠯ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䬪"),block,re.DOTALL)
				for l11ll1l11l1l_l1_ in l11ll1l1111l_l1_:
					#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䬫"),l11ll1_l1_ (u"ࠨࠩ䬬"),l11ll1_l1_ (u"ࠩࠪ䬭"),str(l11ll1l11l1l_l1_))
					type = re.findall(l11ll1_l1_ (u"ࠪࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࠨ䬮"),l11ll1l11l1l_l1_)
					if type:
						if type[0]!=l11ll1_l1_ (u"ࠫࡧࡵࡴࡩࠩ䬯"): type = l11ll1_l1_ (u"ࠬࡥ࡟ࠨ䬰")+type[0]
						else: type = l11ll1_l1_ (u"࠭ࠧ䬱")
					items = re.findall(l11ll1_l1_ (u"ࠧࠩࡁ࠿ࠥ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰ࠫࠫࡠࡼ࠱࡛ࠡ࡞ࡺࡡ࠯ࡂ࠯ࡧࡱࡱࡸࡃ࠴ࠪࡀࡾ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮ࡁࡨࡲࠡ࠱ࡁ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳࠳࠰࠿ࠪࠤࠪ䬲"),l11ll1l11l1l_l1_,re.DOTALL)
					for l11ll1l111l1_l1_,l1lllll_l1_ in items:
						title = re.findall(l11ll1_l1_ (u"ࠨࠪ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮࠮ࡂࠧ䬳"),l11ll1l111l1_l1_)
						title = title[-1]
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䬴") + title + type
						l1llll_l1_.append(l1lllll_l1_)
	# l11ll1l1llll_l1_
	l11l111_l1_ = l111lll_l1_.replace(l11l1l_l1_,l11lllll1l_l1_)
	html = OPENURL_CACHED(l1lllll1_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ䬵"),headers,l11ll1_l1_ (u"ࠫࠬ䬶"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ䬷"))
	items = re.findall(l11ll1_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬸"),html,re.DOTALL)
	#l11lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱ࡨࡱࡧ࡫ࡤࡎ࠯ࠫࡠࡼ࠱ࠩ࠮࠰࠭ࡃ࠳࡮ࡴ࡮࡮ࠬࠫ䬹"),html,re.DOTALL)
	#if l11lll1l11_l1_:
	if items:
		#l11ll1l1llll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ䬺") + l11lll1l11_l1_[-1] + l11ll1_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ䬻")
		l11ll1l1llll_l1_ = items[-1]
		l1llll_l1_.append(l11ll1l1llll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡴࡨࡩ࡭ࡧࠪ䬼"))
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䬽"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭䬾"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ䬿"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ䭀"),l11ll1_l1_ (u"ࠨ࠭ࠪ䭁"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䭂"),headers,l11ll1_l1_ (u"ࠪࠫ䭃"),l11ll1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䭄"))
	items = re.findall(l11ll1_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳࡄࠧ䭅"),html,re.DOTALL)
	l111ll11l_l1_ = [ l11ll1_l1_ (u"࠭ࠧ䭆") ]
	l111l111l_l1_ = [ l11ll1_l1_ (u"ࠧศๆๆ่ࠥ๎ศะ๊้ࠤๆ๊สาࠩ䭇") ]
	for category,title in items:
		l111ll11l_l1_.append(category)
		l111l111l_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ䭈"), l111l111l_l1_)
		if l1l_l1_ == -1 : return
		category = l111ll11l_l1_[l1l_l1_]
	else: category = l11ll1_l1_ (u"ࠩࠪ䭉")
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ䭊")+search+l11ll1_l1_ (u"ࠫࠫࡳࡣࡢࡶࡀࠫ䭋")+category
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䭌"),l11ll1_l1_ (u"࠭ࠧ䭍"),url,url)
	l11111_l1_(url)
	return
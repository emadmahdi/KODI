# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪᓟ")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡈ࠺ࡈࡠࠩᓠ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭ᓡ"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭ᓢ"),l11ll1_l1_ (u"࠭วๅษๅืฬ๋ࠧᓣ"),l11ll1_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫᓤ"),l11ll1_l1_ (u"ࠨࡅࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠬᓥ"),l11ll1_l1_ (u"ࠩࠪᓦ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l11111_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l1llll1_l1_(url,text)
	elif mode==694: results = l1l111_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᓧ"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬᓨ"),l11ll1_l1_ (u"ࠬ࠭ᓩ"),l11ll1_l1_ (u"࠭ࠧᓪ"),l11ll1_l1_ (u"ࠧࠨᓫ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᓬ"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓭ"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᓮ"),l11ll1_l1_ (u"ࠫࠬᓯ"),699,l11ll1_l1_ (u"ࠬ࠭ᓰ"),l11ll1_l1_ (u"࠭ࠧᓱ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᓲ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᓳ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᓴ"),l11ll1_l1_ (u"ࠪࠫᓵ"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓶ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᓷ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧᓸ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠧࠨᓹ"),l11ll1_l1_ (u"ࠨࠩᓺ"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᓻ"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓼ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᓽ")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫᓾ"),l11l1l_l1_,691,l11ll1_l1_ (u"࠭ࠧᓿ"),l11ll1_l1_ (u"ࠧࠨᔀ"),l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧᔁ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔂ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᔃ")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪᔄ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠬ࠭ᔅ"),l11ll1_l1_ (u"࠭ࠧᔆ"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫᔇ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔈ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔉ")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪᔊ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠫࠬᔋ"),l11ll1_l1_ (u"ࠬ࠭ᔌ"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᔍ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᔎ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᔏ"),l11ll1_l1_ (u"ࠩࠪᔐ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔑ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᔒ"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔓ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔔ")+l111l1_l1_+title,l1lllll_l1_,694)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᔕ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᔖ"),l11ll1_l1_ (u"ࠩࠪᔗ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᔘ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤᔙ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠬ࠭ᔚ"))
	#block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩᔛ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		title = title.replace(l11ll1_l1_ (u"ࠧ࠽ࡤࡁࠫᔜ"),l11ll1_l1_ (u"ࠨࠩᔝ")).strip(l11ll1_l1_ (u"ࠩࠣࠫᔞ"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔟ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᔠ")+l111l1_l1_+title,l1lllll_l1_,694)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᔡ"),url,l11ll1_l1_ (u"࠭ࠧᔢ"),l11ll1_l1_ (u"ࠧࠨᔣ"),l11ll1_l1_ (u"ࠨࠩᔤ"),l11ll1_l1_ (u"ࠩࠪᔥ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᔦ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔧ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ᔨ"),l11ll1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬᔩ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔪ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠨࠩᔫ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔬ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᔭ"),l11ll1_l1_ (u"ࠫࠬᔮ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᔯ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠩᔰ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔱ"),l111l1_l1_+title,l1lllll_l1_,691)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᔲ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᔳ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔴ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔵ"),l11ll1_l1_ (u"ࠬ࠭ᔶ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔷ"),l111l1_l1_+title,l1lllll_l1_,691)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠧࠨᔸ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᔹ"),l11ll1_l1_ (u"ࠩࠪᔺ"),request,url)
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨᔻ"):
		url,search = url.split(l11ll1_l1_ (u"ࠫࡄ࠭ᔼ"),1)
		data = l11ll1_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫᔽ")+search
		headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᔾ"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᔿ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᕀ"),url,data,headers,l11ll1_l1_ (u"ࠩࠪᕁ"),l11ll1_l1_ (u"ࠪࠫᕂ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᕃ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᕄ"),url,l11ll1_l1_ (u"࠭ࠧᕅ"),l11ll1_l1_ (u"ࠧࠨᕆ"),l11ll1_l1_ (u"ࠨࠩᕇ"),l11ll1_l1_ (u"ࠩࠪᕈ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᕉ"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠫࠬᕊ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩᕋ"))
	if request==l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᕌ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᕍ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩᕎ"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᕏ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᕐ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᕑ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᕒ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪᕓ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕔ"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᕕ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩᕖ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᕗ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠫࠬᕘ"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕙ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᕚ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧᕛ"),l11ll1_l1_ (u"ࠨใํ่๊࠭ᕜ"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨᕝ"),l11ll1_l1_ (u"ࠪ็้๐ศࠨᕞ"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪᕟ"),l11ll1_l1_ (u"ࠬํฯศใࠪᕠ"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭ᕡ"),l11ll1_l1_ (u"ฺࠧำูࠫᕢ"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨᕣ"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨᕤ"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪᕥ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭ᕦ"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᕧ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨᕨ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩᕩ"))
		#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᕪ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫᕫ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬᕬ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᕭ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨᕮ"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᕯ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᕰ"):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᕱ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᕲ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕳ"),l111l1_l1_+title,l1lllll_l1_,693,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩᕴ") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕵ"),l111l1_l1_+title,l1lllll_l1_,691,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕶ"),l111l1_l1_+title,l1lllll_l1_,693,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᕷ"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᕸ")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᕹ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᕺ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭ᕻ"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧᕼ")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨᕽ"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕾ"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧᕿ")+title,l1lllll_l1_,691)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᖀ"),l11ll1_l1_ (u"ࠪࠫᖁ"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨᖂ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᖃ"),url,l11ll1_l1_ (u"࠭ࠧᖄ"),l11ll1_l1_ (u"ࠧࠨᖅ"),l11ll1_l1_ (u"ࠨࠩᖆ"),l11ll1_l1_ (u"ࠩࠪᖇ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᖈ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧᖉ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖊ"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"࠭ࠧᖋ")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨᖌ"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫᖍ"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩࠦࠫᖎ"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖏ"),l111l1_l1_+title,url,693,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬᖐ"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪ࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᖑ"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧᖒ"),str(l1l1l11_l1_))
	block = l1l1l11_l1_[0]
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࠬᖓ")+l1l1l_l1_+l11ll1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᖔ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨᖕ")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᖖ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡕࡨࡥࡸࡵ࡮ࠨᖗ")+l1l1l_l1_+l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᖘ"),block,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧᖙ"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᖚ"),l11ll1_l1_ (u"ࠨࠩᖛ"),l11ll1_l1_ (u"ࠩࠪᖜ"),l11ll1_l1_ (u"ࠪ࠶࠷࠸࠲࠳ࠩᖝ"))
		if not l1l1l1l_l1_: l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨᖞ"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᖟ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠮࠰ࠩᖠ"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᖡ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᖢ"))
			title = title.replace(l11ll1_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧᖣ"),l11ll1_l1_ (u"ࠪࠤࠬᖤ"))
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᖥ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᖦ"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫᖧ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᖨ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᖩ"))
		#		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᖪ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l111_l1_,l1lll1ll_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᖫ"),l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡦ࠰ࡳ࡬ࡵ࠭ᖬ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᖭ"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧᖮ"),l11ll1_l1_ (u"ࠧࠨᖯ"),l11ll1_l1_ (u"ࠨࠩᖰ"),l11ll1_l1_ (u"ࠩࠪᖱ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᖲ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ᖳ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l11_l1_ l1lllll_l1_
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᖴ"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l111_l1_.append(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧᖵ"))
			l1llll_l1_.append(l1lllll_l1_)
		# l11l1l1l1_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡴࡴࡣ࡭࡫ࡦ࡯࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᖶ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪᖷ"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖸ")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᖹ"))
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᖺ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				title = title.strip(l11ll1_l1_ (u"ࠬࡢ࡮ࠨᖻ"))
				l1l11l111_l1_.append(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᖼ")+title+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᖽ"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l111_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1lll1ll_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᖾ"),l1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᖿ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫᗀ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬᗁ"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧᗂ"),l11ll1_l1_ (u"࠭ࠫࠨᗃ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨᗄ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨᗅ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭ᗆ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨᗇ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ抏")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪ抐")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l11l_l1_ = l1l1lll_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11111_l1_(url)
	elif mode==52: results = l1llll11_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1lll111ll1l1_l1_()
	elif mode==56: results = l1lll111l1ll1_l1_()
	elif mode==57: results = l1lll111l1lll_l1_(url,1)
	elif mode==58: results = l1lll111l1lll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ抑"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭抒"),l11ll1_l1_ (u"ࠧࠨ抓"),59,l11ll1_l1_ (u"ࠨࠩ抔"),l11ll1_l1_ (u"ࠩࠪ投"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ抖"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ抗"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ折"),l11ll1_l1_ (u"࠭ࠧ抙"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ抚"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ抛")+l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠬ抜"),l11ll1_l1_ (u"ࠪࠫ抝"),56)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ択"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ抟")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅษไ่ฬ๋ࠧ抠"),l11ll1_l1_ (u"ࠧࠨ抡"),55)
	return l11ll1_l1_ (u"ࠨࠩ抢")
def l1lll111ll1l1_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ抣"),l111l1_l1_+l11ll1_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩ护"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵࡮ࡦࡹࡨࡷࡹ࠭报"),51)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ抦"),l111l1_l1_+l11ll1_l1_ (u"࠭วโๆส้ࠥืววฮฬࠫ抧"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪ抨"),51)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ抩"),l111l1_l1_+l11ll1_l1_ (u"ࠩสาึࠦวืษไหฯࠦวๅษไ่ฬ๋ࠧ抪"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡲࡡࡵࡧࡶࡸࠬ披"),51)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ抬"),l111l1_l1_+l11ll1_l1_ (u"ࠬอแๅษ่ࠤ่๊วิ์ๆ๎ฮ࠭抭"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡥ࡯ࡥࡸࡹࡩࡤࠩ抮"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ抯"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ抰"),l11ll1_l1_ (u"ࠩࠪ抱"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ抲"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬิส๋ษิࠤฬ็ไศ็้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ抳"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡺࡱࡳࠫ抴"),57)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抵"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ抶"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡶࡪࡼࡩࡦࡹࠪ抷"),57)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ抸"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ抹"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡶࡪࡧࡺࡷࠬ抺"),57)
	return
def l1lll111l1ll1_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ抻"),l111l1_l1_+l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊ๅิๆึ่ฬะࠧ押"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡲࡪࡽࡥࡴࡶࠪ抽"),51)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ抾"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไศฬࠣีฬฬฬสࠩ抿"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡰࡰࡲࡸࡰࡦࡸࠧ拀"),51)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ拁"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮาࠢสฺฬ็วหࠢสู่๊ไิๆสฮࠬ拂"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱࡯ࡥࡹ࡫ࡳࡵࠩ拃"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拄"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠢๆ่ฬู๊ไ์ฬࠫ担"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡩ࡬ࡢࡵࡶ࡭ࡨ࠭拆"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ拇"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ拈"),l11ll1_l1_ (u"ࠬ࠭拉"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭拊"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะอ๎ฬืࠠๆี็ื้อสࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭拋"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡾࡵࡰࠨ拌"),57)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ拍"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ拎"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡳࡧࡹ࡭ࡪࡽࠧ拏"),57)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ拐"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ拑"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡺ࡮࡫ࡷࡴࠩ拒"),57)
	return
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ拓"),l11ll1_l1_ (u"ࠩࠪ拔"),url,url)
	if l11ll1_l1_ (u"ࠪࡃࠬ拕") in url:
		parts = url.split(l11ll1_l1_ (u"ࠫࡄ࠭拖"))
		url = parts[0]
		filter = l11ll1_l1_ (u"ࠬࡅࠧ拗") + QUOTE(parts[1],l11ll1_l1_ (u"࠭࠽ࠧ࠼࠲ࠩࠬ拘"))
	else: filter = l11ll1_l1_ (u"ࠧࠨ拙")
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ拚"),l11ll1_l1_ (u"ࠩࠪ招"),filter,l11ll1_l1_ (u"ࠪࠫ拜"))
	parts = url.split(l11ll1_l1_ (u"ࠫ࠴࠭拝"))
	sort,l1l1111_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11ll1_l1_ (u"ࠬࡿ࡯ࡱࠩ拞"),l11ll1_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭拟"),l11ll1_l1_ (u"ࠧࡷ࡫ࡨࡻࡸ࠭拠")]:
		if type==l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ拡"): l11ll1lll_l1_=l11ll1_l1_ (u"ࠩไ๎้๋ࠧ拢")
		elif type==l11ll1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ拣"): l11ll1lll_l1_=l11ll1_l1_ (u"ู๊ࠫไิๆࠪ拤")
		#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡷࡩࡷ࠳ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩ拥") + QUOTE(l11ll1lll_l1_) + l11ll1_l1_ (u"࠭࠯ࠨ拦") + l1l1111_l1_ + l11ll1_l1_ (u"ࠧ࠰ࠩ拧") + sort + filter
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩ拨") + QUOTE(l11ll1lll_l1_) + l11ll1_l1_ (u"ࠩ࠲ࠫ择") + l1l1111_l1_ + l11ll1_l1_ (u"ࠪ࠳ࠬ拪") + sort + filter
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ拫"),l11ll1_l1_ (u"ࠬ࠭括"),l11ll1_l1_ (u"࠭ࠧ拭"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠧࠨ拮"),l11ll1_l1_ (u"ࠨࠩ拯"),l11ll1_l1_ (u"ࠩࠪ拰"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ拱"))
		#items = re.findall(l11ll1_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡲࡺࡳࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡶࡪࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ拲"),html,re.DOTALL)
		items = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡱࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡶࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡳࡶࡪࡹࡢࡢࡵࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭拳"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,title,l1lll111l11l1_l1_,l1lll1_l1_ in items:
			l1l1l1llll1_l1_ += 1
			#l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭拴") + l1lll1_l1_ + l11ll1_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ拵")
			l1lll1_l1_ = l1l1ll1l11l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡹ࠶࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࡱࡦ࡯࡮࠰ࠩ拶") + l1lll1_l1_ + l11ll1_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ拷")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭拸") + id
			if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ拹"): addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ拺"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			if type==l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭拻"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拼"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊ࠠࠨ拽")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡩࡵࡃࠧ拾")+l1lll111l11l1_l1_+l11ll1_l1_ (u"ࠪࡁࠬ拿")+title+l11ll1_l1_ (u"ࠫࡂ࠭挀")+l1lll1_l1_,52,l1lll1_l1_)
	else:
		if type==l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ持"): l11ll1lll_l1_=l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭挂")
		elif type==l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ挃"): l11ll1lll_l1_=l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ挄")
		url = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠩ࠲࡮ࡸࡵ࡮࠰ࡵࡨࡰࡪࡩࡴࡦࡦ࠲ࠫ挅") + sort + l11ll1_l1_ (u"ࠪ࠱ࠬ挆") + l11ll1lll_l1_ + l11ll1_l1_ (u"ࠫ࠲࡝ࡗ࠯࡬ࡶࡳࡳ࠭指")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠬ࠭挈"),l11ll1_l1_ (u"࠭ࠧ按"),l11ll1_l1_ (u"ࠧࠨ挊"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ挋"))
		items = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ挌"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,l1lll111l11l1_l1_,l1lll1_l1_,title in items:
			l1l1l1llll1_l1_ += 1
			l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠪ࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ挍") + l1lll1_l1_ + l11ll1_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ挎")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ挏") + id
			if type==l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ挐"): addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭挑"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			elif type==l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ挒"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挓"),l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅࠢࠪ挔")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ挕")+l1lll111l11l1_l1_+l11ll1_l1_ (u"ࠬࡃࠧ挖")+title+l11ll1_l1_ (u"࠭࠽ࠨ挗")+l1lll1_l1_,52,l1lll1_l1_)
	title=l11ll1_l1_ (u"ࠧึใะอࠥ࠭挘")
	if l1l1l1llll1_l1_==16:
		for l1l1ll1l1l1_l1_ in range(1,13) :
			if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
				#url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠯ࡳࡶࡴ࡭ࡲࡢ࡯ࡶ࠳ࠬ挙")+type+l11ll1_l1_ (u"ࠩ࠲ࠫ挚")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠪ࠳ࠬ挛")+sort + filter
				url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ挜")+type+l11ll1_l1_ (u"ࠬ࠵ࠧ挝")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"࠭࠯ࠨ挞")+sort + filter
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ挟"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,51)
	return
def l1llll11_l1_(url):
	parts = url.split(l11ll1_l1_ (u"ࠨ࠿ࠪ挠"))
	l1lll111l11l1_l1_ = int(parts[1])
	name = l1111_l1_(parts[2])
	name = name.replace(l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ挡"),l11ll1_l1_ (u"ࠪࠫ挢"))
	l1lll1_l1_ = parts[3]
	url = url.split(l11ll1_l1_ (u"ࠫࡄ࠭挣"))[0]
	if l1lll111l11l1_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠬ࠭挤"),l11ll1_l1_ (u"࠭ࠧ挥"),l11ll1_l1_ (u"ࠧࠨ挦"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ挧"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ挨"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ挩"),block,re.DOTALL)
		l1lll111l11l1_l1_ = int(items[-1])
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ挪"),l11ll1_l1_ (u"ࠬ࠭挫"),l1lll111l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ挬"))
	#name = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠣ挭") )
	#l1lll1_l1_ = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠤ挮") )
	for l1ll1l1_l1_ in range(l1lll111l11l1_l1_,0,-1):
		l1lllll_l1_ = url + l11ll1_l1_ (u"ࠩࡂࡩࡵࡃࠧ振") + str(l1ll1l1_l1_)
		title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ挰")+name+l11ll1_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ挱")+str(l1ll1l1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ挲"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ挳"),l11ll1_l1_ (u"ࠧࠨ挴"),l11ll1_l1_ (u"ࠨࠩ挵"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭挶"))
	l1lll111l1l1l_l1_ = re.findall(l11ll1_l1_ (u"้ࠪฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำ࠳࠰࠿࡮ࡱࡰࡩࡳࡺ࡜ࠩࠤࠫ࠲࠯ࡅࠩࠣࠩ挷"),html,re.DOTALL)
	if l1lll111l1l1l_l1_:
		time = l1lll111l1l1l_l1_[1].replace(l11ll1_l1_ (u"࡙ࠫ࠭挸"),l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠪ挹"))
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ挺"),l11ll1_l1_ (u"ࠧࠨ挻"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠪ挼"),l11ll1_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠิ์ๆ์๋ࠦๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ้ࠡำหࠥอไ้ไอࠫ挽")+l11ll1_l1_ (u"ࠪࡠࡳ࠭挾")+time)
		return
	#if l11ll1_l1_ (u"๋ࠫ฿สัำࠣ฽้๏้ࠠไ๋฽ࠥิืฤࠩ挿") in html:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭捀"),l11ll1_l1_ (u"࠭ࠧ捁"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩ捂"),l11ll1_l1_ (u"ࠨ่฼ฮีืฺࠠๆ์ࠤํฺ่่ࠢั฻ศ࠭捃"))
	#	return
	l1lll111l1111_l1_,l1lll111ll111_l1_ = [],[]
	l1lll111ll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ捄"),html,re.DOTALL)[0]
	l1lll111l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ捅"),html,re.DOTALL)[0]
	# l1lll1lll_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ捆"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		if l11ll1_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ捇") in server:
			server = l11ll1_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭捈")
			url = l1lll111l1l11_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ捉")
			url = l1lll111ll11l_l1_ + l1lllll_l1_
		if l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ捊") in url:
			l1lll111l1111_l1_.append(url)
			l1lll111ll111_l1_.append(l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ捋")+server)
		l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸ࠩࡷࡵࡰ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟ࡶࡴ࡯࠲ࡦࡶࡰࡦࡰࡧࠬࡺࡸ࡬ࠪࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡴࡡ࡮ࡧ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫࡲ࠹ࡵ࠹ࠢࠣࠫ࠰ࡹࡥࡳࡸࡨࡶ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡣࡱ࡫ࡪ࠮࡬ࡦࡰࠫࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠩ࠻ࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥࡵࡳ࡮࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡠ࡯࡝ࠪࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹࡿࡰࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡷࡵࡲࡩࡵࠪࠪࠤࠬ࠯࡛࠱࡟ࠍࠍࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࡩ࡭ࡱ࡫ࡴࡺࡲࡨ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠡࠢࠣࠫ࠱࠭ࠠࠡࠩࠬࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡰࡤࡱࡪ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡦࡪ࡮ࡨࡸࡾࡶࡥࠬࠩࠣࠤࠬ࠱ࡳࡦࡴࡹࡩࡷ࠱ࠧࠡࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠢࠣࠤ捌")
	# l1111l11_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡤࡲࡩ࡯࡭࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭捍"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11ll1_l1_ (u"ࠬࡳࡰ࠵࠼࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭捎"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		filename = l1lllll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ捏"))[-1]
		filename = filename.replace(l11ll1_l1_ (u"ࠧࡧࡣ࡯ࡰࡧࡧࡣ࡬ࠩ捐"),l11ll1_l1_ (u"ࠨࠩ捑"))
		filename = filename.replace(l11ll1_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ捒"),l11ll1_l1_ (u"ࠪࠫ捓"))
		filename = filename.replace(l11ll1_l1_ (u"ࠫ࠲࠭捔"),l11ll1_l1_ (u"ࠬ࠭捕"))
		if l11ll1_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵ࠭捖") in server:
			server = l11ll1_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠠࡴࡧࡵࡺࡪࡸࠧ捗")
			url = l1lll111l1l11_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠨ࡯ࡤ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠭捘")
			url = l1lll111ll11l_l1_ + l1lllll_l1_
		l1lll111l1111_l1_.append(url)
		l1lll111ll111_l1_.append(l11ll1_l1_ (u"ࠩࡰࡴ࠹ࠦࠠࠨ捙")+server+l11ll1_l1_ (u"ࠪࠤࠥ࠭捚")+filename)
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤ࡛࡯ࡤࡦࡱࠣࡕࡺࡧ࡬ࡪࡶࡼ࠾ࠬ捛"), l1lll111ll111_l1_)
	if l1l_l1_ == -1 : return
	url = l1lll111l1111_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ捜"))
	return
def l1lll111l1lll_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ捝"),l11ll1_l1_ (u"ࠧࠨ捞"),url,url)
	if l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ损") in url: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ捠")
	else: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ捡")
	l111lll_l1_ = QUOTE(l111lll_l1_)
	html = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ换"),l11ll1_l1_ (u"ࠬ࠭捣"),l11ll1_l1_ (u"࠭ࠧ捤"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ捥"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ捦"),l11ll1_l1_ (u"ࠩࠪ捧"),url,html)
	if type==1: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡺࡨࡧࡦࡰࡵࡩ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭捨"),html,re.DOTALL)
	elif type==2: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭捩"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࠬ捪"),block,re.DOTALL)
	if type==1:
		for l1lll111l111l_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭捫"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠧࡀࡵࡸࡦ࡬࡫࡮ࡳࡧࡀࠫ捬")+l1lll111l111l_l1_,58)
	elif type==2:
		url,l1lll111l111l_l1_ = url.split(l11ll1_l1_ (u"ࠨࡁࠪ捭"))
		for l1ll1l11ll1l_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ据"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠪࡃࡨࡵࡵ࡯ࡶࡵࡽࡂ࠭捯")+l1ll1l11ll1l_l1_+l11ll1_l1_ (u"ࠫࠫ࠭捰")+l1lll111l111l_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭捱"),l11ll1_l1_ (u"࠭ࠧ捲"),search,search)
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ捳"),l11ll1_l1_ (u"ࠨࠧ࠵࠴ࠬ捴"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭捵"), l11l1l_l1_, l11ll1_l1_ (u"ࠪࠫ捶"), l11ll1_l1_ (u"ࠫࠬ捷"), True,l11ll1_l1_ (u"ࠬ࠭捸"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ捹"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l11lll_l1_ = cookies[l11ll1_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࠨ捺")]
	#l1lll111l11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡥࡶࡶ࡫ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ捻"),html,re.DOTALL)
	#l1lll111l11ll_l1_ = l1lll111l11ll_l1_[0]
	#payload = l11ll1_l1_ (u"ࠩࡢࡧࡸࡸࡦ࠾ࠩ捼") + l1lll111l11ll_l1_ + l11ll1_l1_ (u"ࠪࠪࡶࡃࠧ捽") + QUOTE(l1111ll_l1_)
	#headers = { l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ捾"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ捿") , l11ll1_l1_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭掀"):l11ll1_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠩ掁")+l11l11lll_l1_ }
	#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠣ࠱ࡶࡩࡦࡸࡣࡩࠤ掂")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ掃"), url, payload, headers, True,l11ll1_l1_ (u"ࠪࠫ掄"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠲࡯ࡦࠪ掅"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ掆")+l1111ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ掇"),url,l11ll1_l1_ (u"ࠧࠨ授"),l11ll1_l1_ (u"ࠨࠩ掉"),True,l11ll1_l1_ (u"ࠩࠪ掊"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ掋"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ掌"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ掍"),block,re.DOTALL)
	if items:
		for l1lllll_l1_,l1lll1_l1_,title in items:
			#title = title.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ掎")).encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ掏"))
			url = l11l1l_l1_ + l1lllll_l1_
			if l11ll1_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ掐") in url:
				if l11ll1_l1_ (u"ࠩࡂࡩࡵࡃࠧ掑") in url:
					title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ排")+title
					url = url.replace(l11ll1_l1_ (u"ࠫࡄ࡫ࡰ࠾࠳ࠪ掓"),l11ll1_l1_ (u"ࠬࡅࡥࡱ࠿࠳ࠫ掔"))
					url = url+l11ll1_l1_ (u"࠭࠽ࠨ掕")+QUOTE(title)+l11ll1_l1_ (u"ࠧ࠾ࠩ掖")+l1lll1_l1_
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ掗"),l111l1_l1_+title,url,52,l1lll1_l1_)
				else:
					title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟โ์็้ࠥ࠭掘")+title
					addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ掙"),l111l1_l1_+title,url,53,l1lll1_l1_)
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ掚"),l11ll1_l1_ (u"ࠬ࠭掛"),l11ll1_l1_ (u"࠭࡮ࡰࠢࡵࡩࡸࡻ࡬ࡵࡵࠪ掜"),l11ll1_l1_ (u"ࠧๅษࠣฮําฯ่ࠡอหหาࠠๅๆหัะ࠭掝"))
	return
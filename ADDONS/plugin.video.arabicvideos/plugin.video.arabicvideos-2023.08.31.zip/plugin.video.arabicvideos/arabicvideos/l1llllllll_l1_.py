# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫᏺ")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡂࡓࡕࡢࠫᏻ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨᏼ"),l11ll1_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨᏽ"),l11ll1_l1_ (u"ࠨษ็ห็ูวๆࠩ᏾"),l11ll1_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭᏿")]
def MAIN(mode,url,text):
	if   mode==650: results = MENU()
	elif mode==651: results = l11111_l1_(url,text)
	elif mode==652: results = PLAY(url)
	elif mode==653: results = l1llll1_l1_(url,text)
	elif mode==654: results = l1l111_l1_(url)
	elif mode==659: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ᐀"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬᐁ"),l11ll1_l1_ (u"ࠬ࠭ᐂ"),l11ll1_l1_ (u"࠭ࠧᐃ"),l11ll1_l1_ (u"ࠧࠨᐄ"),l11ll1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᐅ"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᐆ"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᐇ"),l11ll1_l1_ (u"ࠫࠬᐈ"),659,l11ll1_l1_ (u"ࠬ࠭ᐉ"),l11ll1_l1_ (u"࠭ࠧᐊ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᐋ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᐌ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐍ"),l11ll1_l1_ (u"ࠪࠫᐎ"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐏ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᐐ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧᐑ"),l11l1l_l1_,651,l11ll1_l1_ (u"ࠧࠨᐒ"),l11ll1_l1_ (u"ࠨࠩᐓ"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᐔ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐕ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᐖ")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫᐗ"),l11l1l_l1_,651,l11ll1_l1_ (u"࠭ࠧᐘ"),l11ll1_l1_ (u"ࠧࠨᐙ"),l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧᐚ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᐛ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᐜ")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪᐝ"),l11l1l_l1_,651,l11ll1_l1_ (u"ࠬ࠭ᐞ"),l11ll1_l1_ (u"࠭ࠧᐟ"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫᐠ"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐡ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᐢ")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪᐣ"),l11l1l_l1_,651,l11ll1_l1_ (u"ࠫࠬᐤ"),l11ll1_l1_ (u"ࠬ࠭ᐥ"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᐦ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᐧ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᐨ"),l11ll1_l1_ (u"ࠩࠪᐩ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᐪ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᐫ"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐬ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᐭ")+l111l1_l1_+title,l1lllll_l1_,654)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᐮ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᐯ"),l11ll1_l1_ (u"ࠩࠪᐰ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᐱ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤᐲ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠬ࠭ᐳ"))
	#block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩᐴ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		title = title.replace(l11ll1_l1_ (u"ࠧ࠽ࡤࡁࠫᐵ"),l11ll1_l1_ (u"ࠨࠩᐶ")).strip(l11ll1_l1_ (u"ࠩࠣࠫᐷ"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐸ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᐹ")+l111l1_l1_+title,l1lllll_l1_,654)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᐺ"),url,l11ll1_l1_ (u"࠭ࠧᐻ"),l11ll1_l1_ (u"ࠧࠨᐼ"),l11ll1_l1_ (u"ࠨࠩᐽ"),l11ll1_l1_ (u"ࠩࠪᐾ"),l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᐿ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑀ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ᑁ"),l11ll1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬᑂ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᑃ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠨࠩᑄ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᑅ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᑆ"),l11ll1_l1_ (u"ࠫࠬᑇ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᑈ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠩᑉ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᑊ"),l111l1_l1_+title,l1lllll_l1_,651)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᑋ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᑌ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᑍ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑎ"),l11ll1_l1_ (u"ࠬ࠭ᑏ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᑐ"),l111l1_l1_+title,l1lllll_l1_,651)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠧࠨᑑ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᑒ"),l11ll1_l1_ (u"ࠩࠪᑓ"),request,url)
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨᑔ"):
		url,search = url.split(l11ll1_l1_ (u"ࠫࡄ࠭ᑕ"),1)
		data = l11ll1_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫᑖ")+search
		headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᑗ"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᑘ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᑙ"),url,data,headers,l11ll1_l1_ (u"ࠩࠪᑚ"),l11ll1_l1_ (u"ࠪࠫᑛ"),l11ll1_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᑜ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᑝ"),url,l11ll1_l1_ (u"࠭ࠧᑞ"),l11ll1_l1_ (u"ࠧࠨᑟ"),l11ll1_l1_ (u"ࠨࠩᑠ"),l11ll1_l1_ (u"ࠩࠪᑡ"),l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᑢ"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠫࠬᑣ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩᑤ"))
	if request==l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᑥ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᑦ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩᑧ"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᑨ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᑩ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᑪ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᑫ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪᑬ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑭ"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᑮ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩᑯ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᑰ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠫࠬᑱ"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᑲ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᑳ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧᑴ"),l11ll1_l1_ (u"ࠨใํ่๊࠭ᑵ"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨᑶ"),l11ll1_l1_ (u"ࠪ็้๐ศࠨᑷ"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪᑸ"),l11ll1_l1_ (u"ࠬํฯศใࠪᑹ"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭ᑺ"),l11ll1_l1_ (u"ฺࠧำูࠫᑻ"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨᑼ"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨᑽ"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪᑾ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭ᑿ"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᒀ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨᒁ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩᒂ"))
		#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᒃ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫᒄ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬᒅ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᒆ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨᒇ"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᒈ"),l111l1_l1_+title,l1lllll_l1_,652,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᒉ"):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᒊ"),l111l1_l1_+title,l1lllll_l1_,652,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᒋ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒌ"),l111l1_l1_+title,l1lllll_l1_,653,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩᒍ") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒎ"),l111l1_l1_+title,l1lllll_l1_,651,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒏ"),l111l1_l1_+title,l1lllll_l1_,653,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᒐ"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᒑ")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᒒ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᒓ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭ᒔ"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧᒕ")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨᒖ"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᒗ"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧᒘ")+title,l1lllll_l1_,651)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᒙ"),l11ll1_l1_ (u"ࠪࠫᒚ"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨᒛ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᒜ"),url,l11ll1_l1_ (u"࠭ࠧᒝ"),l11ll1_l1_ (u"ࠧࠨᒞ"),l11ll1_l1_ (u"ࠨࠩᒟ"),l11ll1_l1_ (u"ࠩࠪᒠ"),l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᒡ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧᒢ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒣ"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"࠭ࠧᒤ")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ࠭ࠧᒥ"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࠪᒦ"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩࠦࠫᒧ"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒨ"),l111l1_l1_+title,url,653,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬᒩ"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪ࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᒪ"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧᒫ"),str(l1l1l11_l1_))
	block = l1l1l11_l1_[0]
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࠬᒬ")+l1l1l_l1_+l11ll1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒭ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨᒮ")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᒯ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡕࡨࡥࡸࡵ࡮ࠨᒰ")+l1l1l_l1_+l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᒱ"),block,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧᒲ"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᒳ"),l11ll1_l1_ (u"ࠨࠩᒴ"),l11ll1_l1_ (u"ࠩࠪᒵ"),l11ll1_l1_ (u"ࠪ࠶࠷࠸࠲࠳ࠩᒶ"))
		if not l1l1l1l_l1_: l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨᒷ"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᒸ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠮࠰ࠩᒹ"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᒺ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᒻ"))
			title = title.replace(l11ll1_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧᒼ"),l11ll1_l1_ (u"ࠪࠤࠬᒽ"))
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᒾ"),l111l1_l1_+title,l1lllll_l1_,652,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᒿ"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫᓀ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᓁ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᓂ"))
		#		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᓃ"),l111l1_l1_+title,l1lllll_l1_,652,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l111_l1_,l1lll1ll_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᓄ"),l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧᓅ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᓆ"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧᓇ"),l11ll1_l1_ (u"ࠧࠨᓈ"),l11ll1_l1_ (u"ࠨࠩᓉ"),l11ll1_l1_ (u"ࠩࠪᓊ"),l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᓋ"))
	html = response.content
	# l1l111l11_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᓌ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᓍ"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l111_l1_.append(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧᓎ"))
			l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᓏ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠭ࡶࡴ࡯ࡁࡠ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛ࠨࠤࡠ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩᓐ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᓑ"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l111_l1_.append(l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᓒ")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᓓ"))
				l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠦࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ࠯ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࡲ࡫ࡴࠬ࠯ࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠶࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡇࡘࡓࡕࡇࡍ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠿ࠐࠉࠊࠋࠌࡲࡦࡳࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠯ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤᓔ")
	l1111l_l1_ = zip(l1llll_l1_,l1l11l111_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1lll1ll_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᓕ"),l1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1ll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᓖ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩᓗ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪᓘ"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬᓙ"),l11ll1_l1_ (u"ࠫ࠰࠭ᓚ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ᓛ")+search
	l11111_l1_(url,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᓜ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫᓝ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᓞ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ⍸")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡉࡌࡔ࡟ࠨ⍹")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ⍺"),l11ll1_l1_ (u"ࠫฬ๊ใๅࠩ⍻"),l11ll1_l1_ (u"ࠬࡴ࠯ࡂࠩ⍼"),l11ll1_l1_ (u"࠭วๅ็ี๎ิ࠭⍽"),l11ll1_l1_ (u"ࠧใืฬࠤ฾ฺโࠨ⍾")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l11111_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1llll11_l1_(url)
	elif mode==434: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⍿")+text)
	elif mode==435: results = l1ll1lll_l1_(url,l11ll1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⎀")+text)
	elif mode==436: results = l1l111_l1_(url)
	elif mode==437: results = l1llll1111_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⎁"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫ⎂"),l11ll1_l1_ (u"ࠬ࠭⎃"),l11ll1_l1_ (u"࠭ࠧ⎄"),l11ll1_l1_ (u"ࠧࠨ⎅"),l11ll1_l1_ (u"ࠨࠩ⎆"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⎇"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡧ࡮ࡰࡰ࡬ࡧࡦࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⎈"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠫ࠴࠭⎉"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⎊"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎋"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⎌"),l11ll1_l1_ (u"ࠨࠩ⎍"),439,l11ll1_l1_ (u"ࠩࠪ⎎"),l11ll1_l1_ (u"ࠪࠫ⎏"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⎐"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎑"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⎒"),l1ll111_l1_,435)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎓"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ⎔"),l1ll111_l1_,434)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⎕"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⎖"),l11ll1_l1_ (u"ࠫࠬ⎗"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎘"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎙")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭⎚"),l1ll111_l1_,431)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎛"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⎜")+l111l1_l1_+l11ll1_l1_ (u"ࠪหๆ๊วๆࠢส์๋ࠦไศ์้ࠫ⎝"),l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶ࠵ࠬ⎞"),436)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎟"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎠")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡษ๋๊๊ࠥว๋่ࠪ⎡"),l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠯ࡤࡰࡱ࠷ࠧ⎢"),436)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎣"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⎤")+l111l1_l1_+l11ll1_l1_ (u"ࠫ็อฦๆหࠣฮๆ฻๊ๅ์ฬࠫ⎥"),l1ll111_l1_,437)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⎦"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⎧"),l11ll1_l1_ (u"ࠧࠨ⎨"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎩"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⎪")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ⎫"),l1ll111_l1_,431,l11ll1_l1_ (u"ࠫࠬ⎬"),l11ll1_l1_ (u"ࠬ࠭⎭"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⎮"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎯"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎰")+l111l1_l1_+l11ll1_l1_ (u"ࠩฦๅ้อๅࠨ⎱"),l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵ࠲ࠫ⎲"),436)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎳"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎴")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠧ⎵"),l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠮࠳࠲ࠫ⎶"),436)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖ࡭ࡹ࡫ࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡸࡣࡩࠤࠪ⎷"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⎸"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		#if title==l11ll1_l1_ (u"ࠪห้ืฦ๋ีํอࠬ⎹"): title = l11ll1_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ⎺")
		if title in l1l11l_l1_: continue
		if title==l11ll1_l1_ (u"ࠬอไาศํื๏ฯࠧ⎻"): continue
		if l11ll1_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠨ⎼") in title: continue
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎽"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎾")+l111l1_l1_+title,l1lllll_l1_,431)
	return
def l1llll1111_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"ࠩࠪ⎿")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⏀"),l1l1l11l_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫ⏁"),l11ll1_l1_ (u"ࠬ࠭⏂"),l11ll1_l1_ (u"࠭ࠧ⏃"),l11ll1_l1_ (u"ࠧࠨ⏄"),l11ll1_l1_ (u"ࠨࠩ⏅"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⏆"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡧ࡮ࡰࡰ࡬ࡧࡦࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⏇"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠫ࠴࠭⏈"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⏉"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡍ࡫ࡶࡸࡉࡸ࡯ࡱࡧࡧࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭⏊"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⏋"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l11l_l1_: continue
		l1lllll_l1_ = l1l1l11l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࡃࠬ⏌")+category+l11ll1_l1_ (u"ࠩࡀࠫ⏍")+value
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏎"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⏏")+l111l1_l1_+title,l1lllll_l1_,431)
	return
def	l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⏐"),l11ll1_l1_ (u"࠭ࠧ⏑"),l11ll1_l1_ (u"ࠧࡔࡗࡅࡑࡊࡔࡕࠨ⏒"),url)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ⏓"),l1lllll_l1_)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⏔"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⏕"),url,l11ll1_l1_ (u"ࠫࠬ⏖"),l11ll1_l1_ (u"ࠬ࠭⏗"),l11ll1_l1_ (u"࠭ࠧ⏘"),l11ll1_l1_ (u"ࠧࠨ⏙"),l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⏚"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏛"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠪ⏜"),url,431)
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࡇࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ⏝"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ⏞"),block,re.DOTALL)
	for l1lll1l11l_l1_,title in items:
		if title in l1l11l_l1_: continue
		l111lll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡍࡰࡸ࡬ࡩࡸ࠵ࡋࡦࡻࡶ࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡂ࠭⏟")+l1lll1l11l_l1_
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏠"),l111l1_l1_+title,l111lll_l1_,431)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⏡"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⏢"),l11ll1_l1_ (u"ࠪࠫ⏣"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡏ࡮࡯ࡧࡵࡔࡦ࡭ࡥࡇ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠫ⏤"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ⏥"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l11l_l1_: continue
	#	if l11ll1_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠵ࠧ⏦") in url: l111lll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡎࡱࡹ࡭ࡪࡹ࠯ࡕࡧࡵࡱࡸ࠴ࡰࡩࡲࡂࠫ⏧")+category+l11ll1_l1_ (u"ࠨ࠿ࠪ⏨")+value
	#	elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠰ࠫ⏩") in url: l111lll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗࡪࡸࡩࡦࡵ࠲ࡋࡪࡺ࠮ࡱࡪࡳࡃࠬ⏪")+category+l11ll1_l1_ (u"ࠫࡂ࠭⏫")+value
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏬"),l111l1_l1_+title,l111lll_l1_,431)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"࠭ࠧ⏭")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⏮"),l11ll1_l1_ (u"ࠨࠩ⏯"),request,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⏰"))
	items = []
	if l11ll1_l1_ (u"ࠪ࠳࡙࡫ࡲ࡮ࡵ࠱ࡴ࡭ࡶࠧ⏱") in url or l11ll1_l1_ (u"ࠫ࠴ࡍࡥࡵ࠰ࡳ࡬ࡵ࠭⏲") in url or l11ll1_l1_ (u"ࠬ࠵ࡋࡦࡻࡶ࠲ࡵ࡮ࡰࠨ⏳") in url:
		l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
		l1l1ll111_l1_ = {l11ll1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ⏴"):l11ll1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ⏵"),l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⏶"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ⏷")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⏸"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠫࠬ⏹"),l11ll1_l1_ (u"ࠬ࠭⏺"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⏻"))
		html = response.content
		block = html
	elif request==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⏼"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⏽"),url,l11ll1_l1_ (u"ࠩࠪ⏾"),l11ll1_l1_ (u"ࠪࠫ⏿"),l11ll1_l1_ (u"ࠫࠬ␀"),l11ll1_l1_ (u"ࠬ࠭␁"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ␂"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡏࡤ࡭ࡳ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡒࡧࡴࡤࡪࡨࡷ࡙ࡧࡢ࡭ࡧࠥࠫ␃"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ␄"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭␅"),url,l11ll1_l1_ (u"ࠪࠫ␆"),l11ll1_l1_ (u"ࠫࠬ␇"),l11ll1_l1_ (u"ࠬ࠭␈"),l11ll1_l1_ (u"࠭ࠧ␉"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ␊"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡖࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠨ␋"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ␌"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯࡭ࡢࡩࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␍"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ␎"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ␏"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ␐"),l11ll1_l1_ (u"ࠧไๆํฬࠬ␑"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ␒"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ␓"),l11ll1_l1_ (u"้ࠪออัศหࠪ␔"),l11ll1_l1_ (u"ࠫ฾ืึࠨ␕"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ␖"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ␗")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ␘"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ␙"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ␚"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ␛"),l111l1_l1_+title,l1lllll_l1_,432,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫ␜") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ␝") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␞"),l111l1_l1_+title,l1lllll_l1_,433,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ␟") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␠"),l111l1_l1_+title,l1lllll_l1_,431,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␡"),l111l1_l1_+title,l1lllll_l1_,433,l1lll1_l1_)
	if request!=l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ␢"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡖࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ␣"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ␤"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ␥") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
				l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
				title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠧࠨ␦"): addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␧"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ␨")+title,l1lllll_l1_,431)
		l1llll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷ࡭ࡵࡷ࡮ࡱࡵࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␩"),html,re.DOTALL)
		if l1llll1l1l_l1_:
			l1lllll_l1_ = l1llll1l1l_l1_[0]
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␪"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬิศ้าอࠥอไๆิํำࠬ␫"),l1lllll_l1_,431)
	return
def l1llll11_l1_(url):
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ␬"),l11ll1_l1_ (u"ࠧ࠲࠳࠴࠵ࠥࠦࠧ␭")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ␮"))
	l1l11l1_l1_,l1l111l_l1_ = [],[]
	if l11ll1_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠲ࡵ࡮ࡰࠨ␯") in url:
		l111lll_l1_,l11ll111l_l1_ = l1lll1l111_l1_(url)
		l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭␰"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ␱"),l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ␲"):l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭␳")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ␴"),l111lll_l1_,l11ll111l_l1_,l1l1ll111_l1_,l11ll1_l1_ (u"ࠨࠩ␵"),l11ll1_l1_ (u"ࠩࠪ␶"),l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ␷"))
		html = response.content
		l1l111l_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ␸"),url,l11ll1_l1_ (u"ࠬ࠭␹"),l11ll1_l1_ (u"࠭ࠧ␺"),l11ll1_l1_ (u"ࠧࠨ␻"),l11ll1_l1_ (u"ࠨࠩ␼"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ␽"))
		html = response.content
		l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭␾"),html,re.DOTALL)
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡋࡰࡪࡵࡲࡨࡪࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ␿"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡯ࡨ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑀"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⑁"),block,re.DOTALL)
		for post,l1lll1ll1l1_l1_,title in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡆࡲ࡬ࡷࡴࡪࡥࡴ࠰ࡳ࡬ࡵࡅࠧ⑂")+l11ll1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮࠾ࠩ⑃")+l1lll1ll1l1_l1_+l11ll1_l1_ (u"ࠩࠩࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ⑄")+post
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑅"),l111l1_l1_+title,l1lllll_l1_,433,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ⑆"))
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩ⑇"),block,re.DOTALL)
		for l1lllll_l1_,title,l1ll1l1_l1_ in items:
			title = title+l11ll1_l1_ (u"࠭ࠠࠨ⑈")+l1ll1l1_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⑉"),l111l1_l1_+title,l1lllll_l1_,432,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ⑊")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⑋"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ⑌"),l11ll1_l1_ (u"ࠫࠬ⑍"),l11ll1_l1_ (u"ࠬ࠭⑎"),l11ll1_l1_ (u"࠭ࠧ⑏"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⑐"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ⑑"))
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⑒"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1ll1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⑓"),block,re.DOTALL)
		if l1ll1lll1l_l1_:
			l1ll1lll1l_l1_ = l1ll1lll1l_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⑔"),l11ll1_l1_ (u"ࠬ࠭⑕"),l11ll1_l1_ (u"࠭ࠧ⑖"),l1ll1lll1l_l1_)
			items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭⑗"),block,re.DOTALL)
			for server,title in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࡄࡹࡥࡳࡸࡨࡶࡂ࠭⑘")+server+l11ll1_l1_ (u"ࠩࠩࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ⑙")+l1ll1lll1l_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⑚")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⑛")
				l1llll_l1_.append(l1lllll_l1_)
	# l1l111l11_l1_ l1lllll_l1_
	l1l111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯࡬ࡪࡷࡧ࡭ࡦࠤࡁࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⑜"),html,re.DOTALL)
	if l1l111l11_l1_:
		l1l111l11_l1_ = l1l111l11_l1_[0].replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ⑝"),l11ll1_l1_ (u"ࠧࠨ⑞"))
		title = SERVER(l1l111l11_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭⑟"))
		l1lllll_l1_ = l1l111l11_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ①")+title+l11ll1_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ②")
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ③"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ④"),block,re.DOTALL)
		for l1lllll_l1_,title,l111lll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ⑤"),l11ll1_l1_ (u"ࠧࠨ⑥"))
			if l111lll1_l1_!=l11ll1_l1_ (u"ࠨࠩ⑦"): l111lll1_l1_ = l11ll1_l1_ (u"ࠩࡢࡣࡤࡥࠧ⑧")+l111lll1_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⑨")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⑩")+l111lll1_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⑪"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⑫"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⑬"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⑭"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⑮"),l11ll1_l1_ (u"ࠪࠩ࠷࠶ࠧ⑯"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⑰")+search
	l11111_l1_(url)
	return
# ===========================================
#     l1lll1lll1_l1_ l1lll1ll1l_l1_ l1lll1llll_l1_
# ===========================================
def l1lllll1ll_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⑱"))[0]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ⑲"))
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⑳"),l1ll111_l1_,l11ll1_l1_ (u"ࠨࠩ⑴"),l11ll1_l1_ (u"ࠩࠪ⑵"),l11ll1_l1_ (u"ࠪࠫ⑶"),l11ll1_l1_ (u"ࠫࠬ⑷"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ⑸"))
	html = response.content
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡦࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࡪࡰࡪࡑࡦࡹࡴࡦࡴࠥࠫ⑹"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# name + options block + category
	l1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡦࡺࡺࡴࡰࡰࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪࠩ⑺"),block,re.DOTALL)
	return l1ll1ll1_l1_
def l1llll11l1_l1_(block):
	# value + name
	items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࡜ࡥ࠭ࠬࠦࠥࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⑻"),block,re.DOTALL)
	return items
def l1llll11ll_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠩࡦࡥࡹࡃࠧ⑼"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭⑽"))
	l1lllll11l_l1_ = url.split(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⑾"))[0]
	l1llll1l11_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⑿"))
	url = url.replace(l1lllll11l_l1_,l1llll1l11_l1_)
	url = url.replace(l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⒀"),l11ll1_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࡂࠫ⒁"))
	return url
def l1lll1ll1ll_l1_(l1l1ll11_l1_,url):
	l11llll1_l1_ = l11lllll_l1_(l1l1ll11_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⒂")) # l1llllll1ll_l1_ be l1lllllllll_l1_
	l11l111_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⒃")+l11llll1_l1_
	l11l111_l1_ = l1llll11ll_l1_(l11l111_l1_)
	return l11l111_l1_
l1l11l11_l1_ = [l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⒄"),l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ⒅"),l11ll1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ⒆"),l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ⒇")]
l1ll1111_l1_ = [l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ⒈"),l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ⒉"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ⒊"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⒋"),l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭⒌"),l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭⒍")]
def l1ll1lll_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⒎"),l11ll1_l1_ (u"ࠧࠨ⒏"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⒐"),l11ll1_l1_ (u"ࠩࠪ⒑"),filter,url)
	if l11ll1_l1_ (u"ࠪࡃࠬ⒒") in url: url = url.split(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⒓"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ⒔"),1)
	if filter==l11ll1_l1_ (u"࠭ࠧ⒕"): l1l111l1_l1_,l1l1111l_l1_ = l11ll1_l1_ (u"ࠧࠨ⒖"),l11ll1_l1_ (u"ࠨࠩ⒗")
	else: l1l111l1_l1_,l1l1111l_l1_ = filter.split(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭⒘"))
	if type==l11ll1_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⒙"):
		if l1l11l11_l1_[0]+l11ll1_l1_ (u"ࠫࡂ࠭⒚") not in l1l111l1_l1_: category = l1l11l11_l1_[0]
		for i in range(len(l1l11l11_l1_[0:-1])):
			if l1l11l11_l1_[i]+l11ll1_l1_ (u"ࠬࡃࠧ⒛") in l1l111l1_l1_: category = l1l11l11_l1_[i+1]
		l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ⒜")+category+l11ll1_l1_ (u"ࠧ࠾࠲ࠪ⒝")
		l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪ⒞")+category+l11ll1_l1_ (u"ࠩࡀ࠴ࠬ⒟")
		l1l11ll1_l1_ = l1l1llll_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ⒠"))+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ⒡")+l1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧ⒢"))
		l11llll1_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⒣")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⒤")+l11llll1_l1_
	elif type==l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ⒥"):
		l11ll11l_l1_ = l11lllll_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⒦")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l11ll11l_l1_ = l1111_l1_(l11ll11l_l1_)
		if l1l1111l_l1_!=l11ll1_l1_ (u"ࠪࠫ⒧"): l1l1111l_l1_ = l11lllll_l1_(l1l1111l_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⒨")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		if l1l1111l_l1_==l11ll1_l1_ (u"ࠬ࠭⒩"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⒪")+l1l1111l_l1_
		l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒫"),l111l1_l1_+l11ll1_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ⒬"),l111lll_l1_,431)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒭"),l111l1_l1_+l11ll1_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ⒮")+l11ll11l_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ⒯"),l111lll_l1_,431)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒰"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⒱"),l11ll1_l1_ (u"ࠧࠨ⒲"),9999)
	l1ll1ll1_l1_ = l1lllll1ll_l1_(url)
	dict = {}
	for name,block,l1ll1l11_l1_ in l1ll1ll1_l1_:
		name = name.replace(l11ll1_l1_ (u"ࠨ࠯࠰ࠫ⒳"),l11ll1_l1_ (u"ࠩࠪ⒴"))
		items = l1llll11l1_l1_(block)
		if l11ll1_l1_ (u"ࠪࡁࠬ⒵") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧⒶ"):
			if category!=l1ll1l11_l1_: continue
			elif len(items)<2:
				if l1ll1l11_l1_==l1l11l11_l1_[-1]:
					url = l1llll11ll_l1_(url)
					l11111_l1_(url)
				else: l1ll1lll_l1_(l111lll_l1_,l11ll1_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫⒷ")+l1l11ll1_l1_)
				return
			else:
				l111lll_l1_ = l1llll11ll_l1_(l111lll_l1_)
				if l1ll1l11_l1_==l1l11l11_l1_[-1]: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓒ"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨⒹ"),l111lll_l1_,431)
				else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⒺ"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪⒻ"),l111lll_l1_,435,l11ll1_l1_ (u"ࠪࠫⒼ"),l11ll1_l1_ (u"ࠫࠬⒽ"),l1l11ll1_l1_)
		elif type==l11ll1_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨⒾ"):
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨⒿ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠧ࠾࠲ࠪⓀ")
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠨࠨࠪⓁ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠩࡀ࠴ࠬⓂ")
			l1l11ll1_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠪࡣࡤࡥࠧⓃ")+l1l1ll11_l1_
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓄ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧⓅ")+name,l111lll_l1_,434,l11ll1_l1_ (u"࠭ࠧⓆ"),l11ll1_l1_ (u"ࠧࠨⓇ"),l1l11ll1_l1_)		# +l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪⓈ"))
		dict[l1ll1l11_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩⓉ"): option = l11ll1_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪⓊ")
			elif value==l11ll1_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫⓋ"): option = l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧⓌ")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬⓍ") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨⓎ"),value,re.DOTALL)[0]
			dict[l1ll1l11_l1_][value] = option
			l1l1llll_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪⓏ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠩࡀࠫⓐ")+option
			l1l1ll11_l1_ = l1l1111l_l1_+l11ll1_l1_ (u"ࠪࠪࠬⓑ")+l1ll1l11_l1_+l11ll1_l1_ (u"ࠫࡂ࠭ⓒ")+value
			l1ll11ll_l1_ = l1l1llll_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩⓓ")+l1l1ll11_l1_
			title = option+l11ll1_l1_ (u"࠭ࠠ࠻ࠩⓔ")#+dict[l1ll1l11_l1_][l11ll1_l1_ (u"ࠧ࠱ࠩⓕ")]
			title = option+l11ll1_l1_ (u"ࠨࠢ࠽ࠫⓖ")+name
			if type==l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬⓗ"): addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓘ"),l111l1_l1_+title,url,434,l11ll1_l1_ (u"ࠫࠬⓙ"),l11ll1_l1_ (u"ࠬ࠭ⓚ"),l1ll11ll_l1_)		# +l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⓛ"))
			elif type==l11ll1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪⓜ") and l1l11l11_l1_[-2]+l11ll1_l1_ (u"ࠨ࠿ࠪⓝ") in l1l111l1_l1_:
				l11l111_l1_ = l1lll1ll1ll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓞ"),l111l1_l1_+title,l11l111_l1_,431)
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓟ"),l111l1_l1_+title,url,435,l11ll1_l1_ (u"ࠫࠬⓠ"),l11ll1_l1_ (u"ࠬ࠭ⓡ"),l1ll11ll_l1_)
	return
def l11lllll_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧⓢ"),l11ll1_l1_ (u"ࠧࠨⓣ"),filters,l11ll1_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠱࠲ࠩⓤ"))
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫⓥ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ values
	# mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ⓦ")		l1l1ll1l_l1_ l1l1l111_l1_ l1l1l1l1_l1_ filters
	# mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩⓧ")			all l1l1l1l1_l1_ & l1llll1lll_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠬࡃࠦࠨⓨ"),l11ll1_l1_ (u"࠭࠽࠱ࠨࠪⓩ"))
	filters = filters.strip(l11ll1_l1_ (u"ࠧࠧࠩ⓪"))
	l1l111ll_l1_ = {}
	if l11ll1_l1_ (u"ࠨ࠿ࠪ⓫") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠩࠩࠫ⓬"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠪࡁࠬ⓭"))
			l1l111ll_l1_[var] = value
	l1ll11l1_l1_ = l11ll1_l1_ (u"ࠫࠬ⓮")
	for key in l1ll1111_l1_:
		if key in list(l1l111ll_l1_.keys()): value = l1l111ll_l1_[key]
		else: value = l11ll1_l1_ (u"ࠬ࠶ࠧ⓯")
		if l11ll1_l1_ (u"࠭ࠥࠨ⓰") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⓱") and value!=l11ll1_l1_ (u"ࠨ࠲ࠪ⓲"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠩࠣ࠯ࠥ࠭⓳")+value
		elif mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⓴") and value!=l11ll1_l1_ (u"ࠫ࠵࠭⓵"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠬࠬࠧ⓶")+key+l11ll1_l1_ (u"࠭࠽ࠨ⓷")+value
		elif mode==l11ll1_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⓸"): l1ll11l1_l1_ = l1ll11l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪ⓹")+key+l11ll1_l1_ (u"ࠩࡀࠫ⓺")+value
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠪࠤ࠰ࠦࠧ⓻"))
	l1ll11l1_l1_ = l1ll11l1_l1_.strip(l11ll1_l1_ (u"ࠫࠫ࠭⓼"))
	l1ll11l1_l1_ = l1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠬࡃ࠰ࠨ⓽"),l11ll1_l1_ (u"࠭࠽ࠨ⓾"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⓿"),l11ll1_l1_ (u"ࠨࠩ─"),filters,l11ll1_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠳࠴ࠪ━"))
	return l1ll11l1_l1_
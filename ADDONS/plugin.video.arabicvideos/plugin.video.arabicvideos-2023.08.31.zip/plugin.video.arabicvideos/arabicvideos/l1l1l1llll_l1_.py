# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡃࡍࡇࡄࡒࡊࡘࠧᯕ")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡅࡏࡒࡤ࠭ᯖ")
l1l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l11ll1_l1_ (u"ࠨࡶࡨࡱࡵ࠭ᯗ"))
l1l11l1ll1_l1_ = os.path.join(l1ll11llll_l1_,l11ll1_l1_ (u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫᯘ"))
l1l1ll1ll1_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬᯙ"),l11ll1_l1_ (u"࡙ࠫ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨᯚ"))
l1l1l1111l_l1_ = l1ll111lll_l1_
l1l11l1lll_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡸࡿࡳࡵࡧࡰ࠳ࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠨᯛ")
l1l11ll111_l1_ = l11ll1_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡹࡹࡴࡶࡨࡱ࠴ࡪࡲࡰࡲࡥࡳࡽ࠭ᯜ")
l1l1ll1l1l_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪᯝ")
l1l1lll11l_l1_ = l11ll1_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯࡭ࡱࡪ࡫ࡪࡸࠧᯞ")
l1l11ll1ll_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰࡮ࡲ࡫ࠬᯟ")
l1l11lll11_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡤࡲࡷ࠭ᯠ")
def MAIN(mode):
	if   mode==740: results = l1ll11lll1_l1_()
	elif mode==741: results = l1ll11l1ll_l1_(l1l1lll111_l1_,True,True)
	elif mode==742: results = l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,True)
	elif mode==743: results = l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,True)
	elif mode==744: results = l1l11lllll_l1_(l1l1l1111l_l1_,True)
	elif mode==745: results = l1l11l1l11_l1_(True)
	elif mode==750: results = l1l1l1lll1_l1_()
	elif mode==751: results = l1ll11l1ll_l1_(l1l11l1lll_l1_,False,True)
	elif mode==752: results = l1ll11l1ll_l1_(l1l11ll111_l1_,False,True)
	elif mode==753: results = l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,True)
	elif mode==754: results = l1ll11l1ll_l1_(l1l1lll11l_l1_,False,True)
	elif mode==755: results = l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,True)
	elif mode==756: results = l1ll11l1ll_l1_(l1l11lll11_l1_,False,True)
	elif mode==757: results = l1l1ll1111_l1_(True)
	elif mode==758: results = l1l1l1l1l1_l1_()
	else: results = False
	return results
def l1ll11lll1_l1_():
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l1lll111_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11l1ll1_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1ll1_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l1l11ll1_l1_(l1l1l1111l_l1_)
	l1ll11111l_l1_ -= 36864
	l1l1l111l1_l1_ -= 1
	l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠫࠥ࠮ࠧᯡ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩᯢ")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᯣ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠧࠡࠪࠪᯤ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᯥ")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴ᯦ࠫࠪ")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᯧ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨᯨ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᯩ")
	l1ll11ll1l_l1_ = l11ll1_l1_ (u"࠭ࠠࠩࠩᯪ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11ll1_l1_ (u"ࠧࠪࠩᯫ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_
	text = l11ll1_l1_ (u"ࠨࠢࠫࠫᯬ")+l1ll11ll11_l1_(size)+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ᯭ")+str(count)+l11ll1_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᯮ")
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᯯ"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮࠢส่ัฺ๋๊ࠩᯰ")+text,l11ll1_l1_ (u"࠭ࠧᯱ"),745)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯᯲ࠬ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞᯳ࠩ"),l11ll1_l1_ (u"ࠩࠪ᯴"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᯵"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫอࠡษ็้้็วหࠢส่๊สโหหࠪ᯶")+l1l11ll1l1_l1_,l11ll1_l1_ (u"ࠬ࠭᯷"),741)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᯸"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠧ᯹")+l1l1l1ll11_l1_,l11ll1_l1_ (u"ࠨࠩ᯺"),742)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᯻"),l111l1_l1_+l11ll1_l1_ (u"ุ้ࠪำࠠศๆุ์ึࠦวๅไา๎๊ฯࠧ᯼")+l1l1l1l1ll_l1_,l11ll1_l1_ (u"ࠫࠬ᯽"),743)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᯾"),l111l1_l1_+l11ll1_l1_ (u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨ᯿")+l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠧࠨᰀ"),744)
	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᰁ"),l11ll1_l1_ (u"ࠩࠪᰂ"))
	return
def l1l1l1lll1_l1_():
	l1ll11l11l_l1_ = True if l11ll1_l1_ (u"ࠪ࠳ࠬᰃ") in l1l1l11111_l1_ else False
	if not l1ll11l11l_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᰄ"),l11ll1_l1_ (u"ࠬ࠭ᰅ"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᰆ"),l11ll1_l1_ (u"ฺࠧ็็๎ฮࠦส็ฺํๅࠥอไอ้สึ๋ࠥส้ใิอࠥ็โุࠢ็วัําสࠢํ์๋้ำࠡ࠰࠱ࠤํา็ศิๆࠤ้๐ำࠡ็้ࠤ๋๎ูࠡ์ู๋๊่ࠧᰇ"))
		return
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᰈ"))
	if not l1l11llll1_l1_: l1l1l1l1l1_l1_()
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l11l1lll_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11ll111_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1l1l_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l11ll11l_l1_(l1l1lll11l_l1_)
	l1ll111111_l1_,l1l1l111ll_l1_ = l1l11ll11l_l1_(l1l11ll1ll_l1_)
	l1l1llllll_l1_,l1l1lll1l1_l1_ = l1l11ll11l_l1_(l1l11lll11_l1_)
	l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠩࠣࠬࠬᰉ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧᰊ")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᰋ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠬࠦࠨࠨᰌ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᰍ")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᰎ")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠨࠢࠫࠫᰏ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ᰐ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᰑ")
	l1ll11ll1l_l1_ = l11ll1_l1_ (u"ࠫࠥ࠮ࠧᰒ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩᰓ")+str(l1l1l111l1_l1_)+l11ll1_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᰔ")
	l1l1l11lll_l1_ = l11ll1_l1_ (u"ࠧࠡࠪࠪᰕ")+l1ll11ll11_l1_(l1ll111111_l1_)+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᰖ")+str(l1l1l111ll_l1_)+l11ll1_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᰗ")
	l1l1l1l11l_l1_ = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᰘ")+l1ll11ll11_l1_(l1l1llllll_l1_)+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨᰙ")+str(l1l1lll1l1_l1_)+l11ll1_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᰚ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_+l1ll111111_l1_+l1l1llllll_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_+l1l1l111ll_l1_+l1l1lll1l1_l1_
	text = l11ll1_l1_ (u"࠭ࠠࠩࠩᰛ")+l1ll11ll11_l1_(size)+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫᰜ")+str(count)+l11ll1_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᰝ")
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰞ"),l111l1_l1_+l11ll1_l1_ (u"ࠪษ฾฽วยࠢิาฺฯࠠใำสลฮ่ࠦไฬสฬฮ࠭ᰟ"),l11ll1_l1_ (u"ࠫࠬᰠ"),758)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰡ"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิฯࠣห้าๅ๋฻ࠪᰢ")+text,l11ll1_l1_ (u"ࠧࠨᰣ"),757)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰤ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᰥ"),l11ll1_l1_ (u"ࠪࠫᰦ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰧ"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬᰨ")+l1l11ll1l1_l1_,l11ll1_l1_ (u"࠭ࠧᰩ"),751)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰪ"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬᰫ")+l1l1l1ll11_l1_,l11ll1_l1_ (u"ࠩࠪᰬ"),752)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᰭ"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠫᰮ")+l1l1l1l1ll_l1_,l11ll1_l1_ (u"ࠬ࠭ᰯ"),753)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰰ"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࡧࡦࡴࠪᰱ")+l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠨࠩᰲ"),754)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰳ"),l111l1_l1_+l11ll1_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦ࡬ࡰࡩࠪᰴ")+l1l1l11lll_l1_,l11ll1_l1_ (u"ࠫࠬᰵ"),755)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰶ"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡤࡲࡷ᰷࠭")+l1l1l1l11l_l1_,l11ll1_l1_ (u"ࠧࠨ᰸"),756)
	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ᰹"),l11ll1_l1_ (u"ࠩࠪ᰺"))
	return
def l1l1l1l1l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ᰻"),l11ll1_l1_ (u"ࠫࠬ᰼"),l11ll1_l1_ (u"ࠬ࠭᰽"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᰾"),l11ll1_l1_ (u"ࠧๅๅํࠤ๏฿ๅๅࠢส่ฯ์ุ๋ใࠣ฽๋ีใࠡ࠰࠱ࠤอืๆศ็ฯࠤ฾๋วะࠢหัฬาษࠡว็ํࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอ๊ࠥไๆๆไหฯ่ࠦศๆ่ะ้ีวหࠢส่ฯ๐ࠠิ๊ไࠤ๏๋ำฮ้สࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ฾฽วย๊ࠢิ์ࠦวๅำัูฮࠦวๅฤ้ࠤฤࠧࠧ᰿"))
	if l1ll111ll1_l1_==-1: return
	if l1ll111ll1_l1_:
		l1ll11l111_l1_ = True
		import subprocess
		try: subprocess.Popen(l11ll1_l1_ (u"ࠨࡵࡸࠫ᱀"))
		except: l1ll11l111_l1_ = False
		if l1ll11l111_l1_:
			l1l1ll11l1_l1_ = l1l11l1lll_l1_+l11ll1_l1_ (u"ࠩࠣࠫ᱁")+l1l11ll111_l1_+l11ll1_l1_ (u"ࠪࠤࠬ᱂")+l1l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭᱃")+l1l1lll11l_l1_+l11ll1_l1_ (u"ࠬࠦࠧ᱄")+l1l11ll1ll_l1_+l11ll1_l1_ (u"࠭ࠠࠨ᱅")+l1l11lll11_l1_
			proc = subprocess.Popen(l11ll1_l1_ (u"ࠧࡴࡷࠣ࠱ࡨࠦࠢࡤࡪࡰࡳࡩࠦ࠭ࡓࠢ࠳࠻࠼࠽ࠠࠨ᱆")+l1l1ll11l1_l1_+l11ll1_l1_ (u"ࠨࠤࠪ᱇"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ᱈"),l11ll1_l1_ (u"ࠪࠫ᱉"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᱊"),l11ll1_l1_ (u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨ᱋"))
			settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ᱌"),l11ll1_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᱍ"))
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᱎ"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᱏ"),l11ll1_l1_ (u"ࠪࠫ᱐"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᱑"),l11ll1_l1_ (u"ࠬ฿ๅๅ์ฬࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤฯำสศฮࠣฬึ์วๆฮࠣࠤࡷࡵ࡯ࡵࠢࠣวํࠦࠠࡴࡷࡳࡩࡷࡻࡳࡦࡴࠣࠤศ๎ࠠࠡࡵࡸࠤࠥ๎ฬ่ษี็๊ࠥวࠡ์๋ะิࠦแ๋้๋ࠣีอࠠศๆหี๋อๅอࠢ࠱࠲ࠥษ่ࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠬ᱒"))
	return
def l1ll11ll11_l1_(size):
	for x in [l11ll1_l1_ (u"࠭ࡂࠨ᱓"),l11ll1_l1_ (u"ࠧࡌࡄࠪ᱔"),l11ll1_l1_ (u"ࠨࡏࡅࠫ᱕"),l11ll1_l1_ (u"ࠩࡊࡆࠬ᱖"),l11ll1_l1_ (u"ࠪࡘࡇ࠭᱗")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11ll1_l1_ (u"ࠦࠪ࠹࠮࠲ࡨࠣࠩࡸࠨ᱘")%(size,x)
	return text
def l1l11ll11l_l1_(l1ll111l1l_l1_=l11ll1_l1_ (u"ࠬ࠴ࠧ᱙")):
	global l1l1ll1l11_l1_,l1ll1111ll_l1_
	l1l1ll1l11_l1_,l1ll1111ll_l1_ = 0,0
	def l1l1ll1lll_l1_(l1ll111l1l_l1_):
		global l1l1ll1l11_l1_,l1ll1111ll_l1_
		if os.path.exists(l1ll111l1l_l1_):
			if 0 and l11ll1_l1_ (u"࠭ࡳࡤࡣࡱࡨ࡮ࡸࠧᱚ") in dir(os):
				# using l1l1lll1ll_l1_ l11ll1_l1_ (u"ࠧࡰࡵ࠱ࡷࡨࡧ࡮ࡥ࡫ࡵࠫᱛ") method (new in version 3.5)
				for l1l11l1l1l_l1_ in os.scandir(l1ll111l1l_l1_):
					if l1l11l1l1l_l1_.l1ll111l11_l1_(follow_symlinks=False):
						l1l1ll1lll_l1_(l1l11l1l1l_l1_.path)
					elif l1l11l1l1l_l1_.l1l1l1l111_l1_(follow_symlinks=False):
						l1l1ll1l11_l1_ += l1l11l1l1l_l1_.stat().st_size
						l1ll1111ll_l1_ += 1
			else:
				# using l11lll11l_l1_, l1l1l1ll1l_l1_ l1l11lll1l_l1_ l11ll1_l1_ (u"ࠨࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶࠬᱜ") method
				for l1l11l1l1l_l1_ in os.listdir(l1ll111l1l_l1_):
					l1l11l11ll_l1_ = os.path.abspath(os.path.join(l1ll111l1l_l1_,l1l11l1l1l_l1_))
					if os.path.isdir(l1l11l11ll_l1_):
						l1l1ll1lll_l1_(l1l11l11ll_l1_)
					elif os.path.isfile(l1l11l11ll_l1_):
						size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
						l1l1ll1l11_l1_ += size
						l1ll1111ll_l1_ += count
		return
	try: l1l1ll1lll_l1_(l1ll111l1l_l1_)
	except: pass
	return l1l1ll1l11_l1_,l1ll1111ll_l1_
def l1ll1111l1_l1_(l1l1ll11ll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪᱝ"),l11ll1_l1_ (u"ࠪࠫᱞ"),l11ll1_l1_ (u"ࠫࠬᱟ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᱠ"),l1l1ll11ll_l1_+l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫᱡ")+l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᱢ"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1ll11ll_l1_):
		try: os.remove(l1l1ll11ll_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᱣ"),l11ll1_l1_ (u"ࠩࠪᱤ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᱥ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᱦ"),l11ll1_l1_ (u"ࠬ࠭ᱧ"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᱨ"),l11ll1_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᱩ"))
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᱪ"),l11ll1_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᱫ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᱬ"))
	return
def l1l11l1l11_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬᱭ"),l11ll1_l1_ (u"ࠬ࠭ᱮ"),l11ll1_l1_ (u"࠭ࠧᱯ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱰ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อࠨᱱ")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬᱲ")+l11ll1_l1_ (u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠩᱳ")+l11ll1_l1_ (u"ࠫࡡࡴࠧᱴ")+l11ll1_l1_ (u"ࠬลࠡࠢࠩᱵ")+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᱶ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l1lll111_l1_,True,False)
	l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,False)
	l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,False)
	l1l11lllll_l1_(l1l1l1111l_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᱷ"),l11ll1_l1_ (u"ࠨࠩᱸ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᱹ"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᱺ"))
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᱻ"),l11ll1_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᱼ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᱽ"))
	return
def l1l1ll1111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ᱾"),l11ll1_l1_ (u"ࠨࠩ᱿"),l11ll1_l1_ (u"ࠩࠪᲀ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᲁ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪᲂ")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨᲃ")+l11ll1_l1_ (u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪᲄ")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪᲅ")+l11ll1_l1_ (u"ࠨࡁࠤࠥࠬᲆ")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᲇ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l11l1lll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll111_l1_,False,False)
	l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,False)
	l1ll11l1ll_l1_(l1l1lll11l_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11lll11_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᲈ"),l11ll1_l1_ (u"ࠫࠬᲉ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᲊ"),l11ll1_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧ᲋"))
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ᲌"),l11ll1_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫ᲍"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭᲎"))
	return
def l1l11lllll_l1_(l1l1ll111l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ᲏"),l11ll1_l1_ (u"ࠫࠬᲐ"),l11ll1_l1_ (u"ࠬ࠭Ბ"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᲒ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤࠥࠬᲓ")+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᲔ"))
		if l1ll111ll1_l1_!=1: return
	conn = sqlite3.connect(l1l1ll111l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭Ვ"))
	cc.execute(l11ll1_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨᲖ"))
	cc.execute(l11ll1_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫᲗ"))
	conn.commit()
	cc.execute(l11ll1_l1_ (u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭Ი"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᲙ"),l11ll1_l1_ (u"ࠧࠨᲚ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᲛ"),l11ll1_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᲜ"))
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᲝ"),l11ll1_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᲞ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᲟ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3
#import l1l11111111_l1_ as pickle
script_name = l11ll1_l1_ (u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧ㋔")
l1l11l111ll_l1_ = xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠧࡱࡣࡷ࡬ࠬ㋕"))
l11lll1lll1_l1_ = os.path.join(l1l11l111ll_l1_,l11ll1_l1_ (u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪ㋖"))
sys.path.append(l11lll1lll1_l1_)
l1l111ll1ll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣ㋗"))
kodi_version = re.findall(l11ll1_l1_ (u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧ㋘"),l1l111ll1ll_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11lll1l1l1_l1_ = xbmc.LOGINFO
	ltr,rtl = l11ll1_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬ㋙"),l11ll1_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭㋚")
	l1l111l11l1_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ㋛"))
	from urllib.parse import unquote as _1l111ll1l1_l1_
else:
	l11lll1l1l1_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l11ll1_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨ㋜").encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㋝")),l11ll1_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪ㋞").encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㋟"))
	l1l111l11l1_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ㋠"))
	from urllib import unquote as _1l111ll1l1_l1_
l1l11ll1l1l_l1_ = 60
HOUR = 60*l1l11ll1l1l_l1_
l11llll11ll_l1_ = 24*HOUR
l1l11l1llll_l1_ = 30*l11llll11ll_l1_
PERMANENT_CACHE = 12*l1l11l1llll_l1_
addon_id = sys.argv[0].split(l11ll1_l1_ (u"ࠬ࠵ࠧ㋡"))[2]	# plugin.video.l11llll111l_l1_
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
l1l11lll111_l1_ = addon_id.split(l11ll1_l1_ (u"࠭࠮ࠨ㋢"))[2]		# l11llll111l_l1_
addon_version = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧ㋣")+addon_id+l11ll1_l1_ (u"ࠨࠫࠪ㋤"))
addoncachefolder = os.path.join(l1l111l11l1_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤ࠲ࡩࡨࠧ㋥"))
l1l111ll111_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠪࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮ࡥࡣࡷࠫ㋦"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1lll1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㋧"),l11ll1_l1_ (u"ࠬ࠭㋨"),url,l11ll1_l1_ (u"࠭ࡕࡓࡎࡇࡉࡈࡕࡄࡆࠩ㋩"))
	if l11ll1_l1_ (u"ࠧ࠾ࠩ㋪") in url:
		if l11ll1_l1_ (u"ࠨࡁࠪ㋫") in url: l111lll_l1_,filters = url.split(l11ll1_l1_ (u"ࠩࡂࠫ㋬"))
		else: l111lll_l1_,filters = l11ll1_l1_ (u"ࠪࠫ㋭"),url
		filters = filters.split(l11ll1_l1_ (u"ࠫࠫ࠭㋮"))
		l11ll111l_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㋯"),l11ll1_l1_ (u"࠭ࠧ㋰"),filter,str(filters))
			key,value = filter.split(l11ll1_l1_ (u"ࠧ࠾ࠩ㋱"))
			l11ll111l_l1_[key] = value
	else: l111lll_l1_,l11ll111l_l1_ = url,{}
	return l111lll_l1_,l11ll111l_l1_
def l1111_l1_(urll):
	return _1l111ll1l1_l1_(urll)
	#return urllib2.unquote(urll)
def EXTRACT_KODI_PATH(l11llll11l1_l1_):
	l1l1l1111l1_l1_ = {l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠭㋲"):l11ll1_l1_ (u"ࠩࠪ㋳"),l11ll1_l1_ (u"ࠪࡱࡴࡪࡥࠨ㋴"):l11ll1_l1_ (u"ࠫࠬ㋵"),l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ㋶"):l11ll1_l1_ (u"࠭ࠧ㋷"),l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ㋸"):l11ll1_l1_ (u"ࠨࠩ㋹"),l11ll1_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ㋺"):l11ll1_l1_ (u"ࠪࠫ㋻"),l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㋼"):l11ll1_l1_ (u"ࠬ࠭㋽"),l11ll1_l1_ (u"࠭ࡩ࡮ࡣࡪࡩࠬ㋾"):l11ll1_l1_ (u"ࠧࠨ㋿"),l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ㌀"):l11ll1_l1_ (u"ࠩࠪ㌁"),l11ll1_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬ㌂"):l11ll1_l1_ (u"ࠫࠬ㌃")}
	if l11ll1_l1_ (u"ࠬࡅࠧ㌄") in l11llll11l1_l1_: l11llll11l1_l1_ = l11llll11l1_l1_.split(l11ll1_l1_ (u"࠭࠿ࠨ㌅"),1)[1]
	l111lll_l1_,l1l1l11111l_l1_ = l1lll1l111_l1_(l11llll11l1_l1_)
	args = dict(list(l1l1l1111l1_l1_.items())+list(l1l1l11111l_l1_.items()))
	l11lll1llll_l1_ = args[l11ll1_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ㌆")]
	l1l111lllll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ㌇")])
	l1l1111l1ll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࠧ㌈")])
	l11lll1l11l_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ㌉")])
	l11lll1l111_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ㌊")])
	l1l1111ll11_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㌋")])
	l1l11l1l111_l1_ = l1111_l1_(args[l11ll1_l1_ (u"࠭ࡩ࡮ࡣࡪࡩࠬ㌌")])
	l1l1111l11l_l1_ = args[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㌍")]
	l1l111ll11l_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪ㌎")])
	if l1l111ll11l_l1_: l1l111ll11l_l1_ = eval(l1l111ll11l_l1_)
	else: l1l111ll11l_l1_ = {}
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ㌏"))
	#l111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡏࡣࡰࡰࠪ㌐"))
	if not l11lll1llll_l1_: l11lll1l111_l1_ = l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌑") ; l11lll1llll_l1_ = l11ll1_l1_ (u"ࠬ࠸࠶࠱ࠩ㌒")
	return l11lll1l111_l1_,l1l1111ll11_l1_,l1l111lllll_l1_,l11lll1llll_l1_,l1l11l1l111_l1_,l11lll1l11l_l1_,l1l1111l1ll_l1_,l1l1111l11l_l1_,l1l111ll11l_l1_
def LOGGING(script_name):
	l1l1111l1l1_l1_ = sys._getframe(1).f_code.co_name
	if not script_name or not l1l1111l1l1_l1_ or l1l1111l1l1_l1_==l11ll1_l1_ (u"࠭࠼࡮ࡱࡧࡹࡱ࡫࠾ࠨ㌓"):
		return l11ll1_l1_ (u"ࠧ࡜ࠢࠪ㌔")+l1l11lll111_l1_.upper()+l11ll1_l1_ (u"ࠨ࠯ࠪ㌕")+addon_version+l11ll1_l1_ (u"ࠩ࠰ࠫ㌖")+str(kodi_version)+l11ll1_l1_ (u"ࠪࠤࡢ࠭㌗")
	return l11ll1_l1_ (u"ࠫ࠳ࠦࠠࠡࠩ㌘")+l1l1111l1l1_l1_
def LOG_THIS(level,message):
	l11llllll11_l1_ = l11lll1l1l1_l1_
	lines = [l11ll1_l1_ (u"ࠬ࠭㌙"),l11ll1_l1_ (u"࠭ࠧ㌚")]
	if level:
		message = message.replace(l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㌛"),l11ll1_l1_ (u"ࠨࠩ㌜")).replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㌝"),l11ll1_l1_ (u"ࠪࠫ㌞"))
		message = message.replace(l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㌟"),l11ll1_l1_ (u"ࠬ࠭㌠"))
	else: level = l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌡")
	l111l1ll11_l1_,sep,shift = l11ll1_l1_ (u"ࠧࠡࠢࠣࠤࠬ㌢"),l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ㌣"),l11ll1_l1_ (u"ࠩࠪ㌤")
	if l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㌥") in level: l11llllll11_l1_ = xbmc.LOGERROR
	if level==l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㌦"):
		message = message+sep
		lines = message.split(sep)
		shift = l111l1ll11_l1_
	elif level==l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㌧"):
		message = message.replace(l11ll1_l1_ (u"࠭࠮ࠨ㌨")+sep,l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠫ㌩"))
		lines = message.split(sep)
		shift = l111l1ll11_l1_+sep
	elif level in [l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㌪"),l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㌫")]: lines = message.split(l111l1ll11_l1_)
	shift += 6*l111l1ll11_l1_
	l11llllllll_l1_ = 3*l111l1ll11_l1_
	if kodi_version>17.99: shift += 11*l11ll1_l1_ (u"ࠪࠤࠬ㌬")
	l1l11l1lll1_l1_ = lines[0]
	for line in lines[1:]:
		if l11ll1_l1_ (u"ࠫࡡࡴࠧ㌭") in line: line = line.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㌮"),l11ll1_l1_ (u"࠭࡜࡯ࠩ㌯")+l111l1ll11_l1_+l111l1ll11_l1_)
		l11llllllll_l1_ += l111l1ll11_l1_
		l1l11l1lll1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡴࠪ㌰")+shift+l11llllllll_l1_+line
	l1l11l1lll1_l1_ += l11ll1_l1_ (u"ࠨࠢࡢࠫ㌱")
	if l11ll1_l1_ (u"ࠩࠨࠫ㌲") in l1l11l1lll1_l1_: l1l11l1lll1_l1_ = l1111_l1_(l1l11l1lll1_l1_)
	xbmc.log(l1l11l1lll1_l1_,level=l11llllll11_l1_)
	return
def l1l11lll1ll_l1_(l1l1ll111l_l1_):
	conn = sqlite3.connect(l1l1ll111l_l1_)
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩ㌳"))
	cc.execute(l11ll1_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧ㌴"))
	cc.execute(l11ll1_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧ㌵"))
	cc.execute(l11ll1_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪ㌶"))
	cc.execute(l11ll1_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ㌷"))
	cc.execute(l11ll1_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫ㌸"))
	conn.text_factory = str
	return conn,cc
def DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l1l111llll1_l1_=None):
	try: conn,cc = l1l11lll1ll_l1_(l1l1ll111l_l1_)
	except: return
	if l1l111llll1_l1_==None: cc.execute(l11ll1_l1_ (u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ㌹")+table+l11ll1_l1_ (u"ࠪࠦࠥࡁࠧ㌺"))
	else:
		tt = (str(l1l111llll1_l1_),)
		try:
			if l11ll1_l1_ (u"ࠫࠪ࠭㌻") in l1l111llll1_l1_: cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㌼")+table+l11ll1_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩ㌽"),tt)
			else: cc.execute(l11ll1_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㌾")+table+l11ll1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㌿"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l11ll1111_l1_(): pass
class l1l11llll1l_l1_(l1l11ll1111_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l11ll1_l1_ (u"ࠩࠪ㍀")
		self.content = l11ll1_l1_ (u"ࠪࠫ㍁")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l11ll1_l1_ (u"ࠫࠬ㍂")
def l1l111lll1l_l1_(type):
	if type==l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ㍃"): data = {}
	elif type==l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㍄"): data = []
	elif type==l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ㍅"): data = l11ll1_l1_ (u"ࠨࠩ㍆")
	elif type==l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࠭㍇"): data = 0
	elif type==l11ll1_l1_ (u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬ㍈"): data = l1l11llll1l_l1_()
	elif not type: data = None
	else: data = None
	return data
def READ_FROM_SQL3(l1l1ll111l_l1_,l1l11l11l1l_l1_,table,l1l111llll1_l1_=None):
	data = l1l111lll1l_l1_(l1l11l11l1l_l1_)
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㍉"))
	if l1l11llll1_l1_==l11ll1_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㍊") and table!=l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㍋") and l1l1ll111l_l1_==main_dbfile:
		DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l1l111llll1_l1_)
		return data
	l1l1l111l11_l1_ = 0
	cache = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㍌"))
	if cache==l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭㍍"): return data
	elif cache==l11ll1_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ㍎"): l1l1l111l11_l1_ = l11lllll1l1_l1_
	try: conn,cc = l1l11lll1ll_l1_(l1l1ll111l_l1_)
	except: return data
	l1l111l1lll_l1_ = True
	try: cc.execute(l11ll1_l1_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠦࠬ㍏")+table+l11ll1_l1_ (u"ࠫࠧࠦࡌࡊࡏࡌࡘࠥ࠷ࠠ࠼ࠩ㍐"))
	except: l1l111l1lll_l1_ = False
	if l1l111l1lll_l1_:
		if l1l1l111l11_l1_: cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㍑")+table+l11ll1_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠾ࠨ㍒")+str(now+l1l1l111l11_l1_)+l11ll1_l1_ (u"ࠧࠡ࠽ࠪ㍓"))
		conn.commit()
		cc.execute(l11ll1_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㍔")+table+l11ll1_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻ࠿ࠫ㍕")+str(now)+l11ll1_l1_ (u"ࠪࠤࡀ࠭㍖"))
		conn.commit()
		if l1l111llll1_l1_:
			tt = (str(l1l111llll1_l1_),)
			cc.execute(l11ll1_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ㍗")+table+l11ll1_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㍘"),tt)
			l1l111l111l_l1_ = cc.fetchall()
			if l1l111l111l_l1_:
				try:
					text = zlib.decompress(l1l111l111l_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11ll1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ㍙")+table+l11ll1_l1_ (u"ࠧࠣࠢ࠾ࠫ㍚"))
			l1l111l111l_l1_ = cc.fetchall()
			if l1l111l111l_l1_:
				data,l1l11lll1l1_l1_ = {},[]
				for l1l11l1ll1l_l1_,l11ll111l_l1_ in l1l111l111l_l1_:
					l1l1l1ll11_l1_ = zlib.decompress(l11ll111l_l1_)
					l11ll111l_l1_ = pickle.loads(l1l1l1ll11_l1_)
					data[l1l11l1ll1l_l1_] = l11ll111l_l1_
					l1l11lll1l1_l1_.append(l1l11l1ll1l_l1_)
				if l1l11lll1l1_l1_:
					data[l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ㍛")] = l1l11lll1l1_l1_
					if l1l11l11l1l_l1_==l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㍜"): data = l1l11lll1l1_l1_
	conn.close()
	return data
def l1l111l1l1l_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11l1l11l_l1_(length=32):
	l11llll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ㍝"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㍞"),l11ll1_l1_ (u"ࠬࡉࡌࡊࡇࡑࡘࡎࡊࠧ㍟"))
	if l11llll11l_l1_: return l11llll11l_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l11llll1ll1_l1_ = threading.Thread(target=l1l111l1l1l_l1_,args=())
	l11llll1ll1_l1_.start()
	for l11ll11111_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11ll1_l1_ (u"࠭࠰࠱࠳࠴࠶࠷࠹࠳࠵࠶࠸࠹࠻࠼࠷࠸ࠩ㍠")
	else:
		mac = mac.replace(l11ll1_l1_ (u"ࠧ࠻ࠩ㍡"),l11ll1_l1_ (u"ࠨࠩ㍢"))
		node = str(int(mac,16))
	node = re.findall(l11ll1_l1_ (u"ࠩ࡞࠴࠲࠿࡝ࠬࠩ㍣"),node,re.DOTALL)
	node = length*l11ll1_l1_ (u"ࠪ࠴ࠬ㍤")+node[0]
	node = node[-length:]
	mm,ss = l11ll1_l1_ (u"ࠫࠬ㍥"),l11ll1_l1_ (u"ࠬ࠭㍦")
	l1l1111lll1_l1_ = str(int(l11ll1_l1_ (u"࠭࠹ࠨ㍧")*(length+1))-int(node))[-length:]
	for l11ll11111_l1_ in list(range(0,length,4)):
		l11lllll11l_l1_ = l1l1111lll1_l1_[l11ll11111_l1_:l11ll11111_l1_+4]
		mm += l11lllll11l_l1_+l11ll1_l1_ (u"ࠧ࠮ࠩ㍨")
		ss += str(sum(map(int,node[l11ll11111_l1_:l11ll11111_l1_+4]))%10)
	l11llll11l_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㍩"),l11ll1_l1_ (u"ࠩࡆࡐࡎࡋࡎࡕࡋࡇࠫ㍪"),l11llll11l_l1_,PERMANENT_CACHE)
	return l11llll11l_l1_
def l11lllll111_l1_(l1l1l111111_l1_):
	l1l11111l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㍫"))
	#l1l1l111111_l1_ = l1l1l111111_l1_.encode(l11ll1_l1_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ㍬")).replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㍭"),l11ll1_l1_ (u"࠭ࠧ㍮"))
	user = l1l11l1l11l_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11ll1_l1_ (u"࡙ࠧ࠳࠼ࠫ㍯")+l1l1l111111_l1_+l11ll1_l1_ (u"ࠨ࠳࠻ࡁࠬ㍰")+user).encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㍱"))).hexdigest()[0:32]
	if md5 in l1l11111l11_l1_: return True
	return False
class l1l11l111l1_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11ll1_l1_ (u"ࠪࠫ㍲")
		if l11lllll111_l1_(l11ll1_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ㍳")) or not l11lllll111_l1_(l11ll1_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㍴")):
			self.status = l11ll1_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㍵")
			import l1l111l11ll_l1_
			l1l111l11ll_l1_.l1l11l1111l_l1_(False)
	def onPlayBackStopped(self):
		self.status=l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㍶")
	def onPlayBackStarted(self):
		self.status = l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㍷")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11ll1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㍸")
	def onPlayBackEnded(self):
		self.status = l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㍹")
def l1l11l11ll1_l1_(l1l11111ll1_l1_,url,data,headers,source,method):
	l1l1ll111_l1_ = str(headers)[0:250].replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ㍺"),l11ll1_l1_ (u"ࠬࡢ࡜࡯ࠩ㍻")).replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ㍼"),l11ll1_l1_ (u"ࠧ࡝࡞ࡵࠫ㍽")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠤࠥ࠭㍾"),l11ll1_l1_ (u"ࠩࠣࠫ㍿")).replace(l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ㎀"),l11ll1_l1_ (u"ࠫࠥ࠭㎁"))
	if len(str(headers))>250: l1l1ll111_l1_ = l1l1ll111_l1_+l11ll1_l1_ (u"ࠬࠦ࠮࠯࠰ࠪ㎂")
	l11ll111l_l1_ = str(data)[0:250].replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ㎃"),l11ll1_l1_ (u"ࠧ࡝࡞ࡱࠫ㎄")).replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ㎅"),l11ll1_l1_ (u"ࠩ࡟ࡠࡷ࠭㎆")).replace(l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠨ㎇"),l11ll1_l1_ (u"ࠫࠥ࠭㎈")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㎉"),l11ll1_l1_ (u"࠭ࠠࠨ㎊"))
	if len(str(data))>250: l11ll111l_l1_ = l11ll111l_l1_+l11ll1_l1_ (u"ࠧࠡ࠰࠱࠲ࠬ㎋")
	if l1l11111ll1_l1_: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㎌"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦࡃࡂࡅࡋࡉ࠿࡛ࠦࠡࠩ㎍")+url+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㎎")+source+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭㎏")+method+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ㎐")+str(l1l1ll111_l1_)+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭㎑")+l11ll111l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㎒"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㎓"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㎔")+url+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㎕")+source+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭㎖")+method+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ㎗")+str(l1l1ll111_l1_)+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭㎘")+l11ll111l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㎙"))
	return
def l1llll1ll1_l1_(method,url,data=l11ll1_l1_ (u"ࠨࠩ㎚"),headers=l11ll1_l1_ (u"ࠩࠪ㎛"),source=l11ll1_l1_ (u"ࠪࠫ㎜")):
	l1l11l11ll1_l1_(False,url,data,headers,source,l11ll1_l1_ (u"ࠫࠬ㎝"))
	if kodi_version>18.99: import urllib.request as l1l11ll11l1_l1_
	else: import urllib2 as l1l11ll11l1_l1_
	if not headers: headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㎞"):l11ll1_l1_ (u"࠭ࠧ㎟")}
	if not data: data = {}
	if method==l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㎠"):
		url = url+l11ll1_l1_ (u"ࠨࡁࠪ㎡")+l1ll1l111_l1_(data)
		data = None
	elif method==l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㎢"): data = data.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㎣"))
	try:
		req = l1l11ll11l1_l1_.Request(url,headers=headers,data=data)
		http_response = l1l11ll11l1_l1_.urlopen(req)
		html = http_response.read()
	except: html = l11ll1_l1_ (u"ࠫࠬ㎤")
	#try:
	#	req = l1l11ll11l1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l1l11ll11l1_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l11ll1_l1_ (u"ࠬ࠭㎥")
	return html
def l1l11llllll_l1_(script_name):
	# https://www.l1l11ll1lll_l1_.l1l11ll11ll_l1_.l1l111111l1_l1_.com/l1l11l1l1ll_l1_/l1l1111l111_l1_/http-l11lll1ll1l_l1_-l1l111l1l11_l1_
	# https://help.l1l111111l1_l1_.com/l1l11111l1l_l1_/l1l11l1ll11_l1_-l1lll1lllll_l1_/l1l11ll1l11_l1_/215562387-l1l1111ll1l_l1_-property-l11lll11lll_l1_
	# https://www.l1l11ll1lll_l1_.l1l11ll11ll_l1_.l1l111111l1_l1_.com/l1l11l1l1ll_l1_/l1l1111l111_l1_/l1l111111ll_l1_-rest-l1l111l1l11_l1_
	l1l1111111l_l1_ = str(random.randrange(111111111111,999999999999))
	#l1l111l1ll1_l1_ = l11lll1l1ll_l1_()
	#l1l11lllll1_l1_ = l1l111l1ll1_l1_.split(l11ll1_l1_ (u"࠭ࠬࠨ㎦"),1)[0]
	headers = {l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㎧"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ㎨")}
	data = {l11ll1_l1_ (u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ㎩"):l11ll1_l1_ (u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ㎪"),
			l11ll1_l1_ (u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ㎫"):l1l1111111l_l1_,
			l11ll1_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ㎬"): [{
				l11ll1_l1_ (u"ࠨࡵࡴࡧࡵࡣ࡮ࡪࠢ㎭"):l1l11l1l11l_l1_(32),
				l11ll1_l1_ (u"ࠢࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠦ㎮"):str(kodi_version),
				l11ll1_l1_ (u"ࠣࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ㎯"):addon_version,
				l11ll1_l1_ (u"ࠤࡦࡥࡷࡸࡩࡦࡴࠥ㎰"):addon_version,
				l11ll1_l1_ (u"ࠥࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠢ㎱"):script_name,
				l11ll1_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ㎲"):{l11ll1_l1_ (u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㎳"):script_name},
				l11ll1_l1_ (u"ࠨࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㎴"): {l11ll1_l1_ (u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㎵"):script_name},
				l11ll1_l1_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ㎶"): l11ll1_l1_ (u"ࠤࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࠤ㎷"),
				l11ll1_l1_ (u"ࠥࠨࡸࡱࡩࡱࡡࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࡣࡸࡿ࡮ࡤࠤ㎸"):False,
				l11ll1_l1_ (u"ࠦ࡮ࡶࠢ㎹"): l11ll1_l1_ (u"ࠧࠪࡲࡦ࡯ࡲࡸࡪࠨ㎺")
			}]
		}
	url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ㎻")
	import json
	data = json.dumps(data)
	#response = l1l111lll11_l1_(l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㎼"),url,data,headers,l11ll1_l1_ (u"ࠨࠩ㎽"),l11ll1_l1_ (u"ࠩࠪ㎾"),l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㎿"),False,False)
	response = l1llll1ll1_l1_(l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㏀"),url,data,headers,script_name)
	return response
def l1l11l1l1l1_l1_(url,script_name,type):
	l11lll1ll11_l1_ = xbmcgui.ListItem()
	l1l1111llll_l1_ = l1l11l111l1_l1_()
	if l1l1111llll_l1_.status: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㏁"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㏂")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㏃"))
	else:
		if type==l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㏄"):
			l11lll1ll11_l1_.setPath(url)
			LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㏅"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡓࡪ࡯ࡳࡰࡪࠦࡶࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㏆")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㏇"))
			xbmcplugin.setResolvedUrl(addon_handle,True,l11lll1ll11_l1_)
		else:
			LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㏈"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡖ࡭ࡲࡶ࡬ࡦࠢ࡯࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㏉")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㏊"))
			l1l1111llll_l1_.play(url,l11lll1ll11_l1_)
		l1l11l11lll_l1_()
		timeout = 5
		for l11ll11111_l1_ in range(timeout):
			# l11llll1111_l1_ l1l11llll11_l1_
			#	if using time.sleep() l11llll1l1l_l1_ of xbmc.sleep() l1l11lll11l_l1_ the l11llllll1l_l1_ status
			#	l11ll1_l1_ (u"ࠣ࡯ࡼࡴࡱࡧࡹࡦࡴ࠱ࡷࡹࡧࡴࡶࡵࠥ㏋") will stop l1l111l1111_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l1l1111ll_l1_ = l1l1111llll_l1_.status
			if l1l1l1111ll_l1_ in [l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㏌"),l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㏍")]: break
		if l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㏎"): response = l1l11llllll_l1_(script_name)
	return
def EVAL(l1l11l11l1l_l1_,text):
	#text = text.replace(l11ll1_l1_ (u"ࠧࡻࠧࠣ㏏"),l11ll1_l1_ (u"ࠨࠧࠣ㏐"))
	text = text.replace(l11ll1_l1_ (u"ࠧ࡯ࡷ࡯ࡰࠬ㏑"),l11ll1_l1_ (u"ࠨࡐࡲࡲࡪ࠭㏒"))
	text = text.replace(l11ll1_l1_ (u"ࠩࡷࡶࡺ࡫ࠧ㏓"),l11ll1_l1_ (u"ࠪࡘࡷࡻࡥࠨ㏔"))
	text = text.replace(l11ll1_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ㏕"),l11ll1_l1_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ㏖"))
	text = text.replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ㏗"),l11ll1_l1_ (u"ࠧ࠰ࠩ㏘"))
	try: l1l1l1ll11_l1_ = eval(text)
	except: l1l1l1ll11_l1_ = l1l111lll1l_l1_(l1l11l11l1l_l1_)
	return l1l1l1ll11_l1_
def l1l11l11lll_l1_():
	type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11ll1_l1_ (u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ㏙"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11ll1_l1_ (u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ㏚"),time.localtime(now))
	name = name+datetime
	l1ll1111l1l_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_
	if os.path.exists(l1l111ll111_l1_):
		l1l11111lll_l1_ = open(l1l111ll111_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭㏛")).read()
		if kodi_version>18.99: l1l11111lll_l1_ = l1l11111lll_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㏜"))
		l1l11111lll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ㏝"),l1l11111lll_l1_)
	else: l1l11111lll_l1_ = {}
	l11lllll1ll_l1_ = {}
	for l1l11ll1ll1_l1_ in list(l1l11111lll_l1_.keys()):
		if l1l11ll1ll1_l1_!=type: l11lllll1ll_l1_[l1l11ll1ll1_l1_] = l1l11111lll_l1_[l1l11ll1ll1_l1_]
		else:
			if name and name!=l11ll1_l1_ (u"࠭࠮࠯ࠩ㏞"):
				l11llll1lll_l1_ = l1l11111lll_l1_[l1l11ll1ll1_l1_]
				if l1ll1111l1l_l1_ in l11llll1lll_l1_:
					index = l11llll1lll_l1_.index(l1ll1111l1l_l1_)
					del l11llll1lll_l1_[index]
				l1llll11ll1_l1_ = [l1ll1111l1l_l1_]+l11llll1lll_l1_
				l1llll11ll1_l1_ = l1llll11ll1_l1_[:50]
				l11lllll1ll_l1_[l1l11ll1ll1_l1_] = l1llll11ll1_l1_
			else: l11lllll1ll_l1_[l1l11ll1ll1_l1_] = l1l11111lll_l1_[l1l11ll1ll1_l1_]
	if type not in list(l11lllll1ll_l1_.keys()): l11lllll1ll_l1_[type] = [l1ll1111l1l_l1_]
	l11lllll1ll_l1_ = str(l11lllll1ll_l1_)
	if kodi_version>18.99: l11lllll1ll_l1_ = l11lllll1ll_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㏟"))
	open(l1l111ll111_l1_,l11ll1_l1_ (u"ࠨࡹࡥࠫ㏠")).write(l11lllll1ll_l1_)
	return
def WRITE_TO_SQL3(l1l1ll111l_l1_,table,l1l111llll1_l1_,data,l1l11l11l11_l1_,l1l11ll111l_l1_=False):
	cache = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㏡"))
	if cache==l11ll1_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ㏢") and l1l11l11l11_l1_>l11lllll1l1_l1_: l1l11l11l11_l1_ = l11lllll1l1_l1_
	if l1l11ll111l_l1_:
		l11l1ll11_l1_,l11l1ll1l_l1_ = [],[]
		for l11ll11111_l1_ in range(len(l1l111llll1_l1_)):
			text = pickle.dumps(data[l11ll11111_l1_])
			l11lllllll1_l1_ = zlib.compress(text)
			l11l1ll11_l1_.append((l1l111llll1_l1_[l11ll11111_l1_],))
			l11l1ll1l_l1_.append((l1l11l11l11_l1_+now,str(l1l111llll1_l1_[l11ll11111_l1_]),l11lllllll1_l1_))
	else:
		text = pickle.dumps(data)
		l1l11l11111_l1_ = zlib.compress(text)
	try: conn,cc = l1l11lll1ll_l1_(l1l1ll111l_l1_)
	except: return
	while True:
		try:
			cc.execute(l11ll1_l1_ (u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭㏣"))
			break
		except: time.sleep(0.5)
	cc.execute(l11ll1_l1_ (u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㏤")+table+l11ll1_l1_ (u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪ㏥"))
	if l1l11ll111l_l1_:
		cc.executemany(l11ll1_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㏦")+table+l11ll1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㏧"),l11l1ll11_l1_)
		cc.executemany(l11ll1_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ㏨")+table+l11ll1_l1_ (u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ㏩"),l11l1ll1l_l1_)
	else:
		if l1l11l11l11_l1_:
			tt = (str(l1l111llll1_l1_),)
			cc.execute(l11ll1_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㏪")+table+l11ll1_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㏫"),tt)
			tt = (l1l11l11l11_l1_+now,str(l1l111llll1_l1_),l1l11l11111_l1_)
			cc.execute(l11ll1_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭㏬")+table+l11ll1_l1_ (u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ㏭"),tt)
		else:
			tt = (l1l11l11111_l1_,str(l1l111llll1_l1_))
			cc.execute(l11ll1_l1_ (u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ㏮")+table+l11ll1_l1_ (u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㏯"),tt)
	conn.commit()
	conn.close()
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ掞")
#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭掟"):l11ll1_l1_ (u"ࠪࠫ掠")}
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪ採")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๋ࠬีศำ฼อࠬ探"),l11ll1_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ掣")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11111_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llll11_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ掤"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ接"),l11ll1_l1_ (u"ࠩࠪ掦"),l11ll1_l1_ (u"ࠪࠫ控"),l11ll1_l1_ (u"ࠫࠬ推"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ掩"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ措"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠧ࠰ࠩ掫"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ掬"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掭"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ掮"),l1ll111_l1_,489,l11ll1_l1_ (u"ࠫࠬ掯"),l11ll1_l1_ (u"ࠬ࠭掰"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ掱"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ掲"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ掳"),l11ll1_l1_ (u"ࠩࠪ掴"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ掵"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭掶")+l111l1_l1_+l11ll1_l1_ (u"ࠬษอะอࠣห้๋่ศุํ฽ࠬ掷"),l1ll111_l1_,481)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫࠥࡱࡾࡇࡣࡤࡱࡸࡲࡹࠨࠧ掸"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ掹"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ掺"): continue
		if title in l1l11l_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掻"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ掼")+l111l1_l1_+title,l1lllll_l1_,481)
	return html
def l11111_l1_(url,l1lll1111ll1l_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ掽"),url,l11ll1_l1_ (u"ࠬ࠭掾"),l11ll1_l1_ (u"࠭ࠧ掿"),l11ll1_l1_ (u"ࠧࠨ揀"),l11ll1_l1_ (u"ࠨࠩ揁"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ揂"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡵࡳࡵࠪ࠱࠮ࡄ࠯ࠢࡧࡱࡲࡸࡪࡸࠢࠨ揃"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ揄"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ揅"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ揆"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭揇"),l11ll1_l1_ (u"ࠨล฽๊๏ฯࠧ揈"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧ揉"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩ揊"),l11ll1_l1_ (u"ࠫ์ีวโࠩ揋"),l11ll1_l1_ (u"๋ࠬศศำสอࠬ揌"),l11ll1_l1_ (u"ู࠭าุࠪ揍"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧ揎"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧ描"),l11ll1_l1_ (u"่ࠩืึำ๊สࠩ提")]
	l1lll1111lll1_l1_ = l11ll1_l1_ (u"ࠪ࠳ࠬ揑").join(l1lll1111ll1l_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭插")).split(l11ll1_l1_ (u"ࠬ࠵ࠧ揓"))[4:]).split(l11ll1_l1_ (u"࠭࠭ࠨ揔"))
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ揕"),title,re.DOTALL)
		if l1lll1111ll1l_l1_:
			l1lllll111_l1_ = l11ll1_l1_ (u"ࠨ࠱ࠪ揖").join(l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ揗")).split(l11ll1_l1_ (u"ࠪ࠳ࠬ揘"))[4:]).split(l11ll1_l1_ (u"ࠫ࠲࠭揙"))
			l1lll1111llll_l1_ = len([x for x in l1lll1111lll1_l1_ if x in l1lllll111_l1_])
			if l1lll1111llll_l1_>2 and l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ揚") in l1lllll_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ換"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
		else:
			if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ揜"),title,re.DOTALL)
			#if any(value in title for value in l1ll1l_l1_):
			if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ揝") not in title:
				addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ揞"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪั้่ษࠨ揟") in title:
				title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ揠") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ握"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ揢"),url)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揣"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ揤"),url)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠤࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ揥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ揦"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ揧"),l11ll1_l1_ (u"ࠬ࠭揨"))
			if title!=l11ll1_l1_ (u"࠭ࠧ揩"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揪"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ揫")+title,l1lllll_l1_,481,l11ll1_l1_ (u"ࠩࠪ揬"),l11ll1_l1_ (u"ࠪࠫ揭"),l1lll1111ll1l_l1_)
	return
def l1llll11_l1_(url,l111lll_l1_):
	headers = {l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ揮"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭揯")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ揰"),url,l11ll1_l1_ (u"ࠧࠨ揱"),headers,l11ll1_l1_ (u"ࠨࠩ揲"),l11ll1_l1_ (u"ࠩࠪ揳"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ援"))
	html = response.content
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ揵"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭揶"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ揷"))
	l1lll1111ll11_l1_ = True
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࡙ࡥࡢࡵࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ揸"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ揹") not in url:
		block = l1l11l1_l1_[0]
		count = block.count(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂ࠭揺"))
		if count==0: count = block.count(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠩ揻"))
		if count>1:
			l1lll1111ll11_l1_ = False
			if l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠩ揼") in block:
				items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭揽"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠳࠰ࡳ࡬ࡵࡅࡳ࡭ࡷࡪࡁࠬ揾")+id
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揿"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
			else:
				items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ搀"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠲ࡵ࡮ࡰࡀࡵࡨࡶ࡮࡫ࡳࡊࡆࡀࠫ搁")+id
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ搂"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
	# l1l11_l1_
	if l1lll1111ll11_l1_:
		block = l11ll1_l1_ (u"ࠫࠬ搃")
		if l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ搄") in url: block = html
		else:
			l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡦࡲ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ搅"),html,re.DOTALL)
			if l1l111l_l1_: block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭搆"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ搇"))
				addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ搈"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
	if not menuItemsLIST: l11111_l1_(l111lll_l1_,url)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ搉"))+l11ll1_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡺࡥࡹࡩࡨࠨ搊")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ搋"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ搌"),l11ll1_l1_ (u"ࠧࠨ損"),l11ll1_l1_ (u"ࠨࠩ搎"),l11ll1_l1_ (u"ࠩࠪ搏"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ搐"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ搑"))
	l1ll1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼ࡯ࡠࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ搒"),html,re.DOTALL)
	if not l1ll1lll1l_l1_: l1ll1lll1l_l1_ = re.findall(l11ll1_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ搓"),html,re.DOTALL)
	l1ll1lll1l_l1_ = l1ll1lll1l_l1_[0]
	# l11l1l1l1_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ搔"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭搕"),block,re.DOTALL)
		for l1lll1111l_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ搖"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳࡮࡬ࡲࡢ࡯ࡨ࠶࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭搗")+l1ll1lll1l_l1_+l11ll1_l1_ (u"ࠫࠫࡼࡩࡥࡧࡲࡁࠬ搘")+l1lll1111l_l1_[2:]+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭搙")+title+l11ll1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ搚")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l11_l1_ l11l1l1l1_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡩࡨࡸࡊࡳࡢࡦࡦࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ搛"),html,re.DOTALL)
	if l1lllll_l1_:
		title = SERVER(l1lllll_l1_[0],l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ搜"))
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ搝")+title+l11ll1_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ搞")
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠫ࠴࠭搟"))+l11ll1_l1_ (u"ࠬ࠵࠿ࡥࡱࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ搠")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ搡"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ搢"),l11ll1_l1_ (u"ࠨࠩ搣"),l11ll1_l1_ (u"ࠩࠪ搤"),l11ll1_l1_ (u"ࠪࠫ搥"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ搦"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡢࡤ࡯ࡩ࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ搧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ搨"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ搩"))
			if l11ll1_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ搪") in l1lllll_l1_: l1lll1l11_l1_ = l11ll1_l1_ (u"ࠩࡢࡣำอีࠨ搫")
			else: l1lll1l11_l1_ = l11ll1_l1_ (u"ࠪࠫ搬")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ搭")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ搮")+l1lll1l11_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ搯"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭搰"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"ࠨࠩ搱")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ搲"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ搳"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭搴"),l11ll1_l1_ (u"ࠬ࠱ࠧ搵"))
	if l1ll111_l1_==l11ll1_l1_ (u"࠭ࠧ搶"): l1ll111_l1_ = l11l1l_l1_
	url = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ搷")+search+l11ll1_l1_ (u"ࠨ࠱ࠪ搸")
	l11111_l1_(url,l11ll1_l1_ (u"ࠩࠪ搹"))
	return
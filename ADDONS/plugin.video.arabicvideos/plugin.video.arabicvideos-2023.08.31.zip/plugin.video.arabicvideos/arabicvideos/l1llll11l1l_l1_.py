# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ≊")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠷࠮ࡣࡧࡶࡸࠬ≋")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠵࠳ࡩ࡯࡮ࠩ≌")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ≍")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠶ࡥࡩࡸࡺ࠮ࡤࡱࡰࠫ≎")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠭ࡷ࡫ࡳ࠲ࡸ࡮࡯ࡧࡦࡤ࠲ࡨࡵ࡭ࠨ≏")
#l11l1l_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡱࡰࡩ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴࡮࡭ࠩ≐")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ≑")
script_name = l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ≒")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡉࡌ࡜࡟ࠨ≓")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l11111_l1_(url,l1l1111_l1_)
	elif mode==222: results = l1l111_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1ll1lll_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≔"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ≕"),l11ll1_l1_ (u"ࠬ࠭≖"),229,l11ll1_l1_ (u"࠭ࠧ≗"),l11ll1_l1_ (u"ࠧࠨ≘"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ≙"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ≚"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭≛"),l11l1l_l1_,226,l11ll1_l1_ (u"ࠫࠬ≜"),l11ll1_l1_ (u"ࠬ࠭≝"),l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭≞"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ≟"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ≠"),l11l1l_l1_,226,l11ll1_l1_ (u"ࠩࠪ≡"),l11ll1_l1_ (u"ࠪࠫ≢"),l11ll1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ≣"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ≤"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≥"),l11ll1_l1_ (u"ࠧࠨ≦"),9999)
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ≧"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ≨"),l11ll1_l1_ (u"ࠪࠫ≩"),l11ll1_l1_ (u"ࠫࠬ≪"),l11ll1_l1_ (u"ࠬ࠭≫"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ≬"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࠢ࡬࠱࡭ࡵ࡭ࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ≭"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ≮"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠩ࠿࠳࡮ࡄࠧ≯") in title: title = title.split(l11ll1_l1_ (u"ࠪࡀ࠴࡯࠾ࠨ≰"))[1]
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≱"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ≲")+l111l1_l1_+title,l1lllll_l1_,222)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ≳"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ≴"),l11ll1_l1_ (u"ࠨࠩ≵"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡥ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࠪ≶"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪࡴࡩࡧࠠࡣࡦࡥࠦࡃࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ≷"),html,re.DOTALL)
	for title,l1lllll_l1_ in items:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≸"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ≹")+l111l1_l1_+title,l1lllll_l1_,221)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ≺"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ≻"),l11ll1_l1_ (u"ࠨࠩ≼"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ≽"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡳ࡬ࠨ≾") not in l1lllll_l1_: continue
		if not l1lllll_l1_.endswith(l11ll1_l1_ (u"ࠫ࠴࠭≿")): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⊀"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⊁")+l111l1_l1_+title,l1lllll_l1_,221)
	return html
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩสฺ฿฽่่ࠠสࠤ้อึศใฬࠤฬูๅࠡัั์้่ࠦไๆ่อࠥอไิำࠪ࠰ࠬ࠭ࠬ࠳࠴࠸࠭ࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฯำะ๋ำࠪ࠰ࠬ࠭ࠬ࠳࠴࠹࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠱ࠦࡨࡵ࡯࡯࠭ࠏࠏࠣࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡱࡦ࡯࡮ࡍࡱࡤࡨࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠣࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡧࡱࡵࠤࡺࡸ࡬࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠨࠏࡩࡧࠢࡸࡶࡱࠧ࠽ࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲ࡵࡳ࡮࠯࠶࠷࠺ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ࠬࠨࠩ࠯࠶࠷࠿ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠰࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วๅลๆฯึࠦๅีษ๊ำฮ࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠮ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ࠭࠴࠵࠵࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠰࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วๅษไ่ฬ๋ࠧ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭ࠬ࠳࠴࠷࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอไๆี็ื้อสࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰࠭࠯ࡵࡸࠪ࠰࠷࠸࠴ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡤࠤࡲ࡭ࡢࠩ࠰࠭ࡃ࠮ࡄࡅࡨࡻࡅࡩࡸࡺ࠼࠰ࡣࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠰࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡪࡷࡱࡱࠐࠉࠤࠢࡨ࡫ࡾࡨࡥࡴࡶ࠴࠲ࡨࡵ࡭ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠩࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡝࠴࠳ࡢࡡࡩࠣ࡟ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭ࡴࡰࡴࡵࡩࡳࡺࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠳࠴࠴࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡷࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨࡶࡲࡶࡷ࡫࡮ࡵࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࠤࠥࠦ⊂")
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⊃"),url,l11ll1_l1_ (u"ࠩࠪ⊄"),l11ll1_l1_ (u"ࠪࠫ⊅"),l11ll1_l1_ (u"ࠫࠬ⊆"),l11ll1_l1_ (u"ࠬ࠭⊇"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⊈"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡵࡢࡷࡨࡸ࡯࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⊉"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⊊"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⊋"),l111l1_l1_+title,l1lllll_l1_,224)
	return
def l1ll1lll_l1_(url):
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⊌"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ⊍"),url,221)
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭⊎"),l11ll1_l1_ (u"࠭ࠧ⊏"),l11ll1_l1_ (u"ࠧࠨ⊐"),l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⊑"))
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨ࡭ࡢ࡫ࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠳࠴࠴࠭ࠏࠏࠢࠣࠤ⊒")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨ࡟࡯ࡣࡹࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷࠬ⊓"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⊔"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧ⊕"): name = title
			else:
				title = title + l11ll1_l1_ (u"࠭ࠠࠡ࠼ࠣࠤࠬ⊖") + l11ll1_l1_ (u"ࠧโๆอีࠥ࠭⊗") + name
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊘"),l111l1_l1_+title,l1lllll_l1_,221)
	else: l11111_l1_(url)
	return
def l11111_l1_(url,l1l1111_l1_=l11ll1_l1_ (u"ࠩ࠴ࠫ⊙")):
	if l1l1111_l1_==l11ll1_l1_ (u"ࠪࠫ⊚"): l1l1111_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭⊛")
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⊜"),l11ll1_l1_ (u"࠭ࠧ⊝"),str(url), str(l1l1111_l1_))
	if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ⊞") in url or l11ll1_l1_ (u"ࠨࡁࠪ⊟") in url: l111lll_l1_ = url + l11ll1_l1_ (u"ࠩࠩࠫ⊠")
	else: l111lll_l1_ = url + l11ll1_l1_ (u"ࠪࡃࠬ⊡")
	#l111lll_l1_ = l111lll_l1_ + l11ll1_l1_ (u"ࠫࡴࡻࡴࡱࡷࡷࡣ࡫ࡵࡲ࡮ࡣࡷࡁ࡯ࡹ࡯࡯ࠨࡲࡹࡹࡶࡵࡵࡡࡰࡳࡩ࡫࠽࡮ࡱࡹ࡭ࡪࡹ࡟࡭࡫ࡶࡸࠫࡶࡡࡨࡧࡀࠫ⊢")+l1l1111_l1_
	l111lll_l1_ = l111lll_l1_ + l11ll1_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫ⊣") + l1l1111_l1_
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ⊤"),l11ll1_l1_ (u"ࠧࠨ⊥"),l11ll1_l1_ (u"ࠨࠩ⊦"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⊧"))
	#name = l11ll1_l1_ (u"ࠪࠫ⊨")
	#if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࠬ⊩") in url:
	#	name = re.findall(l11ll1_l1_ (u"ࠬࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⊪"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l11ll1_l1_ (u"࠭ࠠࠨ⊫")) + l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ⊬")
	#	else: name = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠤ⊭") ) + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭⊮")
	if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫ⊯") in url:
		l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡪࡡࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ⊰"),html,re.DOTALL)
		block = l1l1l11_l1_[-1]
	# l1llll1111l_l1_ l1lll1l_l1_
	elif l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⊱") in url:
		l1l1l11_l1_=re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡯ࡸ࡮࠰ࡧࡦࡸ࡯ࡶࡵࡨࡰࠥࡵࡷ࡭࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ⊲"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	else:
		l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⊳"),html,re.DOTALL)
		block = l1l1l11_l1_[-1]
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⊴"),block,re.DOTALL)
	for l1lllll_l1_,l1lll1_l1_,title in items:
		l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࡪࡨࠣࠫ࠴ࡹࡥࡳ࡫ࡨࡷࠬࠦࡩ࡯ࠢࡸࡶࡱࠦࡡ࡯ࡦࠣࠫ࠴ࡹࡥࡢࡵࡲࡲࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴࡧࡤࡷࡴࡴࠧࠡ࡫ࡱࠤࡺࡸ࡬ࠡࡣࡱࡨࠥ࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡶ࡬ࡸࡱ࡫ࠬࠡࡵࡷࡶ࠭ࡲࡩ࡯࡭ࠬ࠭ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡰࡤࡱࡪࠦࠫࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠣࠤࠥ⊵")
		title = unescapeHTML(title)
		l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࠰ࠩ࠯ࠫ࠴࠭ࠩࠋࠋࠌ࡭ࡲ࡭ࠠ࠾ࠢ࡬ࡱ࡬࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯ࡦࠡࠩ࡫ࡸࡹࡶࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡫ࡰ࡫࠿ࠦࡩ࡮ࡩࠣࡁࠥ࠭ࡨࡵࡶࡳ࠾ࠬࠦࠫࠡ࡫ࡰ࡫ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡐࡒࡘࡎࡌࡉࡄࡃࡗࡍࡔࡔࠨࡪ࡯ࡪ࠰ࠬ࠭ࠩࠋࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡ࡮࡬ࡲࡰࠐࠉࠊࠤࠥࠦ⊶")
		if l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࠬ⊷") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ⊸") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⊹"),l111l1_l1_+title,l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠧ࠰ࠩ⊺")),223,l1lll1_l1_)
		else:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊻"),l111l1_l1_+title,l1lllll_l1_,221,l1lll1_l1_)
	if len(items)>=16:
		l1111ll11l_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ⊼"),l11ll1_l1_ (u"ࠪ࠳ࡹࡼࠧ⊽"),l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ⊾"),l11ll1_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ⊿")]
		l1l1111_l1_ = int(l1l1111_l1_)
		if any(value in url for value in l1111ll11l_l1_):
			for n in range(0,1000,100):
				if int(l1l1111_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1l1111_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1l1111_l1_==j and j!=0:
									addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋀"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭⋁")+str(j),url,221,l11ll1_l1_ (u"ࠨࠩ⋂"),str(j))
						elif i!=0: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋃"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ⋄")+str(i),url,221,l11ll1_l1_ (u"ࠫࠬ⋅"),str(i))
						else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⋆"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ⋇")+str(1),url,221,l11ll1_l1_ (u"ࠧࠨ⋈"),str(1))
				elif n!=0: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋉"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ⋊")+str(n),url,221,l11ll1_l1_ (u"ࠪࠫ⋋"),str(n))
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋌"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ⋍")+str(1),url,221)
	return
def PLAY(url):
	#global l11ll1_l1_ (u"࠭ࠧ⋎")
	l1lll111_l1_,l1llll_l1_ = [],[]
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⋏"),l11ll1_l1_ (u"ࠨࠩ⋐"),url, url[-45:])
	# https://l1llll1ll11_l1_.com/l1lllll111l_l1_/فيلم-the-l1lllll1l1l_l1_-l1llll111l1_l1_-2019-مترجم
	html = OPENURL_CACHED(l1lllll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ⋑"),l11ll1_l1_ (u"ࠪࠫ⋒"),l11ll1_l1_ (u"ࠫࠬ⋓"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⋔"))
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⋕"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# https://l111l11ll1_l1_.l1llll11111_l1_/l1lllll111l_l1_/فيلم-the-l1lllll1l1l_l1_-l1llll111l1_l1_-2019-مترجم
	l11l111l1_l1_,l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠧࠨ⋖"),l11ll1_l1_ (u"ࠨࠩ⋗")
	l1lllll1ll1_l1_,l1llll1l11l_l1_ = html,html
	l1llll1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶ࡬ࡴࡽ࡟ࡥ࡮ࠣࡥࡵ࡯ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⋘"),html,re.DOTALL)
	if l1llll1lll1_l1_:
		for l1lllll_l1_ in l1llll1lll1_l1_:
			if l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ⋙") in l1lllll_l1_: l11l111l1_l1_ = l1lllll_l1_
			elif l11ll1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ⋚") in l1lllll_l1_: l11ll1l1l_l1_ = l1lllll_l1_
		if l11l111l1_l1_!=l11ll1_l1_ (u"ࠬ࠭⋛"): l1lllll1ll1_l1_ = OPENURL_CACHED(l1lllll1_l1_,l11l111l1_l1_,l11ll1_l1_ (u"࠭ࠧ⋜"),l11ll1_l1_ (u"ࠧࠨ⋝"),l11ll1_l1_ (u"ࠨࠩ⋞"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ⋟"))
		if l11ll1l1l_l1_!=l11ll1_l1_ (u"ࠪࠫ⋠"): l1llll1l11l_l1_ = OPENURL_CACHED(l1lllll1_l1_,l11ll1l1l_l1_,l11ll1_l1_ (u"ࠫࠬ⋡"),l11ll1_l1_ (u"ࠬ࠭⋢"),l11ll1_l1_ (u"࠭ࠧ⋣"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭⋤"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⋥"),l11ll1_l1_ (u"ࠩࠪ⋦"),l11ll1l1l_l1_,l11l111l1_l1_)
	# https://l1llll1l111_l1_.l111l11ll1_l1_.download/?id=__1lllll1l11_l1_
	l1llll1llll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋧"),l1lllll1ll1_l1_,re.DOTALL)
	if l1llll1llll_l1_:
		l111lll_l1_ = l1llll1llll_l1_[0]#+l11ll1_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲࠻࠾࠴࠱࠷࠷࠱࠶࠹࠸࠮࠹࠶࠽࠸࠶࠺࠵ࠨ⋨")
		if l111lll_l1_!=l11ll1_l1_ (u"ࠬ࠭⋩") and l11ll1_l1_ (u"࠭ࡵࡱ࡮ࡲࡥࡩ࡫ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⋪") in l111lll_l1_ and l11ll1_l1_ (u"ࠧ࠰ࡁ࡬ࡨࡂࡥࠧ⋫") not in l111lll_l1_:
			l11ll1l1_l1_ = OPENURL_CACHED(l1lllll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ⋬"),l11ll1_l1_ (u"ࠩࠪ⋭"),l11ll1_l1_ (u"ࠪࠫ⋮"),l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ⋯"))
			l1lll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⋰"),l11ll1l1_l1_,re.DOTALL)
			if l1lll1llll1_l1_:
				for l1lllll_l1_,l111lll1_l1_ in l1lll1llll1_l1_:
					l1llll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡥࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࡴࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟࡮ࡲ࠷ࡣࡤ࠭⋱")+l111lll1_l1_)
			else:
				server = l111lll_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩ⋲"))[2]
				l1llll_l1_.append(l111lll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⋳")+server+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⋴"))
		elif l111lll_l1_!=l11ll1_l1_ (u"ࠪࠫ⋵"):
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⋶"),l11ll1_l1_ (u"ࠬ࠭⋷"),l111lll_l1_,str(l1llll1llll_l1_))
			server = l111lll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ⋸"))[2]
			l1llll_l1_.append(l111lll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⋹")+server+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⋺"))
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	l1llll11lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸࡦࡨ࡬ࡦࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡰࡸࡥࡴࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ⋻"),l1llll1l11l_l1_,re.DOTALL)
	if l1llll11lll_l1_:
		l1llll11lll_l1_ = l1llll11lll_l1_[0]
		l1llll1ll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡹࡪ࠾࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⋼"),l1llll11lll_l1_,re.DOTALL)
		if l1llll1ll1l_l1_:
			for l111lll1_l1_,l1lllll_l1_ in l1llll1ll1l_l1_:
				if l11ll1_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭⋽") not in l1lllll_l1_: continue
				if l1lllll_l1_.count(l11ll1_l1_ (u"ࠬ࠵ࠧ⋾"))>=2:
					server = l1lllll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ⋿"))[2]
					l1llll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⌀")+server+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡭ࡱ࠶ࡢࡣࠬ⌁")+l111lll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ⌂"), l1llll_l1_)
	#if l1l_l1_ == -1 : return
	l1llll11ll1_l1_ = []
	for l1lllll_l1_ in l1llll_l1_:
		# faselhd	https://l1llll111l_l1_.l111l11ll1_l1_.l1llll11111_l1_/l1lllll111l_l1_/l11l1l1l1_l1_/فيلم-the-l1lllll11l1_l1_-l1llll1l1ll_l1_-l1lll1lllll_l1_-2017-مترجم/l1llll1l1l1_l1_
		#if l11ll1_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ⌃") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࡁࡱࡥࡲ࡫ࠧ⌄") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠴ࡶࡪࡲࠪ⌅") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ⌆") not in l1lllll_l1_: continue
		l1llll11ll1_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⌇"), l1llll11ll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11ll1_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⌈"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ⌉"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ⌊"): return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭⌋"),l11ll1_l1_ (u"ࠬ࠱ࠧ⌌"))
	html = OPENURL_CACHED(l1ll1ll1l_l1_,l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ⌍"),l11ll1_l1_ (u"ࠧࠨ⌎"),l11ll1_l1_ (u"ࠨࠩ⌏"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ⌐"))
	token = re.findall(l11ll1_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡸࡴࡱࡥ࡯ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⌑"),html,re.DOTALL)
	if token:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡥࡴࡰ࡭ࡨࡲࡂ࠭⌒")+token[0]+l11ll1_l1_ (u"ࠬࠬࡱ࠾ࠩ⌓")+l1111ll_l1_
		l11111_l1_(url)
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⌔"),l11ll1_l1_ (u"ࠧࠨ⌕"),l11ll1_l1_ (u"ࠨࠩ⌖"), l11ll1_l1_ (u"ࠩࠪ⌗"))
	return
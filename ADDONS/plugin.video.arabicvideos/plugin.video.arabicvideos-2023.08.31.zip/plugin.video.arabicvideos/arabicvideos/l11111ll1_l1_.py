# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫፅ")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬፆ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫፇ"):l11ll1_l1_ (u"ࠨࠩፈ")}
l1l11l_l1_ = [l11ll1_l1_ (u"ࠩสๅ้อๅࠡๆ็็ออัࠨፉ"),l11ll1_l1_ (u"ࠪฬ่ืวࠡࡖ࡙ࠫፊ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l11111_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l11111l1l_l1_(url)
	elif mode==375: results = l1111111l_l1_(url)
	elif mode==376: results = l111111l1_l1_(0,url)
	elif mode==377: results = l111111l1_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨፋ"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭ፌ"),l11ll1_l1_ (u"࠭ࠧፍ"),l11ll1_l1_ (u"ࠧࠨፎ"),l11ll1_l1_ (u"ࠨࠩፏ"),l11ll1_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪፐ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪፑ"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫፒ"),l11ll1_l1_ (u"ࠬ࠭ፓ"),379,l11ll1_l1_ (u"࠭ࠧፔ"),l11ll1_l1_ (u"ࠧࠨፕ"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬፖ"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧፗ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪፘ"),l11ll1_l1_ (u"ࠫࠬፙ"),9999)
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷ࠱ࡸ࡯ࡤࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬፚ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ፛"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፜"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፝")+l111l1_l1_+title,l1lllll_l1_,371)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፞"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፟")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ፠"),l11l1l_l1_,375)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፡"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ።")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฦัิัࠧ፣"),l11l1l_l1_,376)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፤"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፥")+l111l1_l1_+l11ll1_l1_ (u"ࠪ๎ูอ็ะࠢส่ว์ࠧ፦"),l11l1l_l1_,377)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፧"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፨")+l111l1_l1_+l11ll1_l1_ (u"࠭โศศ่อࠥอไๆ็ฮ่๏์ࠧ፩"),l11l1l_l1_,374)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ፪"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ፫"),l11ll1_l1_ (u"ࠩࠪ፬"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡹࡵࡰ࠮࡯ࡨࡲࡺ࠭፭"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ፮"),block,re.DOTALL)
		for l1lllll_l1_,title in items[7:]:
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ፯"))
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭፰"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ፱")+l111l1_l1_+title,l1lllll_l1_,371)
		for l1lllll_l1_,title in items[0:7]:
			title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ፲"))
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፳"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፴")+l111l1_l1_+title,l1lllll_l1_,371)
	return
def l11111l1l_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"ࠫࠬ፵")):
	response = OPENURL_REQUESTS_CACHED(l1lllll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ፶"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ፷"),l11ll1_l1_ (u"ࠧࠨ፸"),l11ll1_l1_ (u"ࠨࠩ፹"),l11ll1_l1_ (u"ࠩࠪ፺"),l11ll1_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡄࡇ࡙ࡕࡒࡔࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ፻"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠡࡥࡤࡸ࡚ࠥࡡࡨࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ፼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ፽"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ፾") in l1lllll_l1_: continue
			else: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፿"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᎀ")+l111l1_l1_+title,l1lllll_l1_,371)
	return
def l1111111l_l1_(l1l1l11l_l1_=l11ll1_l1_ (u"ࠩࠪᎁ")):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᎂ"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬᎃ"),l11ll1_l1_ (u"ࠬ࠭ᎄ"),l11ll1_l1_ (u"࠭ࠧᎅ"),l11ll1_l1_ (u"ࠧࠨᎆ"),l11ll1_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡇࡇࡄࡘ࡚ࡘࡅࡅ࠯࠴ࡷࡹ࠭ᎇ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡄࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠵ࠫᎈ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡻ࡯ࡤࡱࡣࡪࡩࡤ࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨᎉ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠫ࠿࠵࠯ࠨᎊ"),l11ll1_l1_ (u"ࠬࡀ࠯࠰࠱ࠪᎋ")).replace(l11ll1_l1_ (u"࠭࠯࠰ࠩᎌ"),l11ll1_l1_ (u"ࠧ࠰ࠩᎍ")).replace(l11ll1_l1_ (u"ࠨࠢࠪᎎ"),l11ll1_l1_ (u"ࠩࠨ࠶࠵࠭ᎏ"))
				addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᎐"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᎑")+l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
	return
def l111111l1_l1_(id,l1l1l11l_l1_=l11ll1_l1_ (u"ࠬ࠭᎒")):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ᎓"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ᎔"),l11ll1_l1_ (u"ࠨࠩ᎕"),l11ll1_l1_ (u"ࠩࠪ᎖"),l11ll1_l1_ (u"ࠪࠫ᎗"),l11ll1_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰࡛ࡆ࡚ࡃࡉࡋࡑࡋࡓࡕࡗ࠮࠳ࡶࡸࠬ᎘"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡸ࡮ࡺ࡬ࡦ࠴ࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫ᎙"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[id]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿ࠩ᎚"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠧ࠻࠱࠲ࠫ᎛"),l11ll1_l1_ (u"ࠨ࠼࠲࠳࠴࠭᎜")).replace(l11ll1_l1_ (u"ࠩ࠲࠳ࠬ᎝"),l11ll1_l1_ (u"ࠪ࠳ࠬ᎞")).replace(l11ll1_l1_ (u"ࠫࠥ࠭᎟"),l11ll1_l1_ (u"ࠬࠫ࠲࠱ࠩᎠ"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᎡ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᎢ")+l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
	return
def l11111_l1_(url,l11ll1lll_l1_=l11ll1_l1_ (u"ࠨࠩᎣ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᎤ"),l11ll1_l1_ (u"ࠪࠫᎥ"),l11ll1lll_l1_,url)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᎦ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᎧ"),url,l11ll1_l1_ (u"࠭ࠧᎨ"),l11ll1_l1_ (u"ࠧࠨᎩ"),l11ll1_l1_ (u"ࠨࠩᎪ"),l11ll1_l1_ (u"ࠩࠪᎫ"),l11ll1_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭Ꭼ"))
	html = response.content
	if l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡱࡣࡪࡩࡤ࠭Ꭽ") in url:
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡁ࡭ࡤࡸࡱ࠲࠴ࠪࡀࠫࠥࠫᎮ"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
			l11111_l1_(l1lllll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࠠࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡱࡩ࠳࠳ࠨᎯ"),html,re.DOTALL)
	if l11ll1lll_l1_==l11ll1_l1_ (u"ࠧࠨᎰ") and l1l1l11_l1_ and l1l1l11_l1_[0].count(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫࠭Ꮁ"))>1:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎲ"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠪᎳ"),url,371,l11ll1_l1_ (u"ࠫࠬᎴ"),l11ll1_l1_ (u"ࠬ࠭Ꮅ"),l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡸ࠭Ꮆ"))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ꮇ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪᎸ")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᎹ"))
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎺ"),l111l1_l1_+title,l1lllll_l1_,371)
	else:
		l11l_l1_ = []
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭Ꮋ"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠾ࠢࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡻࡷ࠲࠷࠲ࠨᎼ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨᎽ"),block,re.DOTALL)
			l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࠎࠏࡩࡵࡧࡰࡷ࠷ࠦ࠽ࠡ࡝ࡠࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮࡬ࡱ࡬࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡺࡲࡺ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࡮ࡴࡴࠩࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭วๅฯ็ๆฮࠦࠫࠩ࡞ࡧ࠯࠮࠭ࠬࡵ࡫ࡷࡰࡪ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࡞࠴ࡢ࠯ࠊࠊࠋࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡩ࡯ࡶࡰࡷࠤࡂࠦ࠭࠲ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷ࠷࠴ࡡࡱࡲࡨࡲࡩ࠮ࠨ࡭࡫ࡱ࡯࠱࡯࡭ࡨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡥࡲࡹࡳࡺࠩࠪࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡩࡵࡧࡰࡷ࠷࠲ࠠࡳࡧࡹࡩࡷࡹࡥ࠾ࡈࡤࡰࡸ࡫ࠬࠡ࡭ࡨࡽࡂࡲࡡ࡮ࡤࡧࡥࠥࡱࡥࡺ࠼ࠣ࡯ࡪࡿ࡛࠴࡟ࠬࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮࡬ࡱ࡬࠲ࡴࡪࡶ࡯ࡩ࠱ࡩ࡯ࡶࡰࡷࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠦࠧࠨᎾ")
			for l1lllll_l1_,l1lll1_l1_,title in items:
				#LOG_THIS(l11ll1_l1_ (u"ࠨࠩᎿ"),l1lll1_l1_)
				l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᏀ"))
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠪ࠾࠴࠵ࠧᏁ"),l11ll1_l1_ (u"ࠫ࠿࠵࠯࠰ࠩᏂ")).replace(l11ll1_l1_ (u"ࠬ࠵࠯ࠨᏃ"),l11ll1_l1_ (u"࠭࠯ࠨᏄ")).replace(l11ll1_l1_ (u"ࠧࠡࠩᏅ"),l11ll1_l1_ (u"ࠨࠧ࠵࠴ࠬᏆ"))
				if l11ll1_l1_ (u"ࠩ࠲ࡥࡱࡥࠧᏇ") in l1lllll_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏈ"),l111l1_l1_+title,l1lllll_l1_,371,l1lll1_l1_)
				elif l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫᏉ") in title and (l11ll1_l1_ (u"ࠬ࠵ࡃࡢࡶ࠰ࠫᏊ") in url or l11ll1_l1_ (u"࠭࠯ࡔࡧࡤࡶࡨ࡮࠯ࠨᏋ") in url):
					l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦ࠭ࠡ࠭ส่า๊โสࠢ࠮ࡠࡩ࠱ࠧᏌ"),title,re.DOTALL)
					if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭Ꮝ")+l1ll1l1_l1_[0]
					if title not in l11l_l1_:
						l11l_l1_.append(title)
						addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏎ"),l111l1_l1_+title,l1lllll_l1_,371,l1lll1_l1_)
				else: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᏏ"),l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᏐ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᏑ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				title = l11ll1_l1_ (u"࠭ีโฯฬࠤࠬᏒ")+unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏓ"),l111l1_l1_+title,l1lllll_l1_,371,l11ll1_l1_ (u"ࠨࠩᏔ"),l11ll1_l1_ (u"ࠩࠪᏕ"),l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡵࠪᏖ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᏗ"),url,l11ll1_l1_ (u"ࠬ࠭Ꮨ"),l11ll1_l1_ (u"࠭ࠧᏙ"),l11ll1_l1_ (u"ࠧࠨᏚ"),l11ll1_l1_ (u"ࠨࠩᏛ"),l11ll1_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᏜ"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰࡦࡨࡥ࡭࠯ࡶࡹࡨࡩࡥࡴࡵࠣࡱࡷ࡭࠭ࡣࡶࡰ࠱࠺ࠦࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᏝ"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l11l111_l1_ = l11ll1_l1_ (u"ࠫࠬᏞ")
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼࡡࡳࠢࡸࡶࡱࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩᏟ"),html,re.DOTALL)
	if l111lll_l1_: l111lll_l1_ = l111lll_l1_[0]
	else: l111lll_l1_ = url.replace(l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠࠩᏠ"),l11ll1_l1_ (u"ࠧ࠰ࡒ࡯ࡥࡾ࠵ࠧᏡ"))
	if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭Ꮲ") not in l111lll_l1_: l111lll_l1_ = l11l1l_l1_+l111lll_l1_
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠩ࠰ࠫᏣ"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll1l_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᏤ"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬᏥ"),l11ll1_l1_ (u"ࠬ࠭Ꮶ"),l11ll1_l1_ (u"࠭ࠧᏧ"),l11ll1_l1_ (u"ࠧࠨᏨ"),l11ll1_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩᏩ"))
	l11ll1l1_l1_ = response.content
	l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᏪ"),l11ll1l1_l1_,re.DOTALL)
	if l11l111_l1_:
		l11l111_l1_ = l11l111_l1_[-1]
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᏫ") not in l11l111_l1_: l11l111_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᏬ")+l11l111_l1_
		if l11ll1_l1_ (u"ࠬ࠵ࡐࡍࡃ࡜࠳ࠬᏭ") not in l111lll_l1_:
			if l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠳ࡳࡩ࡯࠰࡭ࡷࠬᏮ") in l11l111_l1_:
				l111111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡲ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ꮿ"),l11ll1l1_l1_,re.DOTALL)
				if l111111ll_l1_:
					l11111111_l1_, l11111l11_l1_ = l111111ll_l1_[0]
					l11l111_l1_ = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᏰ"))+l11ll1_l1_ (u"ࠩ࠲ࡺ࠷࠵ࠧᏱ")+l11111111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡨࡵ࡮ࡧ࡫ࡪ࠳ࠬᏲ")+l11111l11_l1_+l11ll1_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪᏳ")
		import ll_l1_
		ll_l1_.l11_l1_([l11l111_l1_],script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᏴ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧᏵ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ᏶"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ᏷"),l11ll1_l1_ (u"ࠩ࠮ࠫᏸ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡘ࡫ࡡࡳࡥ࡫࠳ࠬᏹ")+search
	l11111_l1_(url)
	return
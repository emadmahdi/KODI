# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ༢")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪ༣")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==730: results = MENU()
	elif mode==731: results = l1lllll_l1_(url)
	elif mode==732: results = PLAY(url)
	elif mode==733: results = l1lll1ll_l1_(url)
	elif mode==734: results = l1l111ll1_l1_(url)
	elif mode==735: results = l1l111l11_l1_(url)
	elif mode==739: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ༤"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭༥"),l11l1l_l1_ (u"ࠧࠨ༦"),739,l11l1l_l1_ (u"ࠨࠩ༧"),l11l1l_l1_ (u"ࠩࠪ༨"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ༩"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ༪"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ༫"),l11l1l_l1_ (u"࠭ࠧ༬"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ༭"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ༮")+l1111l_l1_+l11l1l_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩ༯"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡹࡵࡰ࠯ࡲ࡫ࡴࠬ༰"),735)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ༱"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ༲")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠧ༳"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡶࡹࡵ࡯࡯࠰ࡳ࡬ࡵ࠭༴"),734)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ༵"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ༶")+l1111l_l1_+l11l1l_l1_ (u"ࠪหๆ๊วๆ༷ࠩ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠳ࡶࡨࡱࠩ༸"),731)
	return
def l1l111ll1_l1_(url):
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ༹ࠬ"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅๅ็ࠫ༺"),url,731)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ༻"),url,l11l1l_l1_ (u"ࠨࠩ༼"),l11l1l_l1_ (u"ࠩࠪ༽"),l11l1l_l1_ (u"ࠪࠫ༾"),l11l1l_l1_ (u"ࠫࠬ༿"),l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡗࡊࡘࡉࡆࡕࡢࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨཀ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࡬ࡢࡤࡨࡰࡂࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧཁ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤག"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪགྷ")+l1llll1_l1_
			title = l11l1l_l1_ (u"ࠩะีๆࠦࠧང")+title
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪཅ"),l1111l_l1_+title,l1llll1_l1_,731)
	return
def l1l111l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨཆ"),url,l11l1l_l1_ (u"ࠬ࠭ཇ"),l11l1l_l1_ (u"࠭ࠧ཈"),l11l1l_l1_ (u"ࠧࠨཉ"),l11l1l_l1_ (u"ࠨࠩཊ"),l11l1l_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡔࡇࡕࡍࡊ࡙࡟ࡇࡇࡄࡘ࡚ࡘࡅࡅ࠯࠵ࡲࡩ࠭ཋ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧཌ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪཌྷ"),block,re.DOTALL)
		for title,l1llll1_l1_,l1ll1l_l1_ in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧཎ")+l1llll1_l1_
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨཏ")+l1ll1l_l1_
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩཐ"))
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨད"),l1111l_l1_+title,l1llll1_l1_,733,l1ll1l_l1_)
	return
def l1lllll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪདྷ"),l11l1l_l1_ (u"ࠪࠫན"),request,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨཔ"),url,l11l1l_l1_ (u"ࠬ࠭ཕ"),l11l1l_l1_ (u"࠭ࠧབ"),l11l1l_l1_ (u"ࠧࠨབྷ"),l11l1l_l1_ (u"ࠨࠩམ"),l11l1l_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫཙ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡱࡴࡼࡩࡦࡵࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥཚ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡃ࠭ཛ"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧཛྷ")+l1llll1_l1_
		l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨཝ")+l1ll1l_l1_
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩཞ"))
		if l11l1l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳ࠯ࡲ࡫ࡴࠬཟ") in url: addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨའ"),l1111l_l1_+title,l1llll1_l1_,732,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪཡ"),l1111l_l1_+title,l1llll1_l1_,733,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬར"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[-1]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪལ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨཤ")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩཥ"))
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨས"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨཧ")+title,l1llll1_l1_,731)
	return
def l1lll1ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫཨ"),l11l1l_l1_ (u"ࠫࠬཀྵ"),l11l1l_l1_ (u"ࠬ࠭ཪ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪཫ"),url,l11l1l_l1_ (u"ࠧࠨཬ"),l11l1l_l1_ (u"ࠨࠩ཭"),l11l1l_l1_ (u"ࠩࠪ཮"),l11l1l_l1_ (u"ࠪࠫ཯"),l11l1l_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ཰"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡳ࡯ࡷ࡫ࡨࡷࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࡵࡦࡶ࡮ࡶࡴཱࠣ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡰࡸ࡬ࡩࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡀིࠪ"),block,re.DOTALL)
		for title,l1llll1_l1_,l1ll1l_l1_,l1l111l1l_l1_ in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ཱིࠩ")+l1llll1_l1_
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ུࠪ")+l1ll1l_l1_
			title = title.strip(l11l1l_l1_ (u"ཱུࠩࠣࠫ"))
			title = title+l11l1l_l1_ (u"ࠪࠤࠬྲྀ")+l1l111l1l_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭ཷ"))
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫླྀ"),l1111l_l1_+title,l1llll1_l1_,732,l1ll1l_l1_)
	return
def PLAY(url):
	#url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠵࡮ࡢࡷࡶ࡭ࡨࡧࡡ࠮࠵࠶࠴࠸࠻࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡴࡶࡵࡩࡦࡳࡩ࡯ࡩ࠱࡬ࡹࡳ࡬ࠨཹ")
	l1lll1l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗེࠫ"),url,l11l1l_l1_ (u"ࠨཻࠩ"),l11l1l_l1_ (u"ོࠩࠪ"),l11l1l_l1_ (u"ཽࠪࠫ"),l11l1l_l1_ (u"ࠫࠬཾ"),l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬཿ"))
	html = response.content
	# l1l1111ll_l1_ l1llll1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀྀࠫࠥࠫ"),html,re.DOTALL)
	if l1l1_l1_:
		l1llll1_l1_ = l1l1_l1_[0]
		l1lll1l1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨཱྀ"))
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ྂ"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨྃ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"྄ࠪࠫ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠫࠬ྅"): return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ྆"),l11l1l_l1_ (u"࠭ࠥ࠳࠲ࠪ྇"))
	l1lll1_l1_ = [l11l1l_l1_ (u"ࠧࠨྈ"),l11l1l_l1_ (u"ࠨ࡯ࠪྉ")]
	l1l111lll_l1_ = [l11l1l_l1_ (u"่ࠩืู้ไศฬࠪྊ"),l11l1l_l1_ (u"ࠪหๆ๊วๆࠩྋ")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪྌ"), l1l111lll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	type = l1lll1_l1_[l1l_l1_]
	url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡸࡨࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨྍ")+type+l11l1l_l1_ (u"࠭ࠦࡲ࠿ࠪྎ")+search
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫྏ"),url,l11l1l_l1_ (u"ࠨࠩྐ"),l11l1l_l1_ (u"ࠩࠪྑ"),l11l1l_l1_ (u"ࠪࠫྒ"),l11l1l_l1_ (u"ࠫࠬྒྷ"),l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧྔ"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬྕ"),html,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩྖ")+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪྗ"))
		if type==l11l1l_l1_ (u"ࠩࡰࠫ྘"): addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩྙ"),l1111l_l1_+title,l1llll1_l1_,732)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྚ"),l1111l_l1_+title,l1llll1_l1_,733)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭⍯")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡇࡊࡒࡤ࠭⍰")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭⍱"),l11l1l_l1_ (u"ࠩส่่๊ࠧ⍲"),l11l1l_l1_ (u"ࠪࡲ࠴ࡇࠧ⍳"),l11l1l_l1_ (u"ࠫฬ๊ๅำ์าࠫ⍴"),l11l1l_l1_ (u"่ࠬีสࠢ฼ุ็࠭⍵")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l1lllll_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1lll1ll_l1_(url)
	elif mode==434: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ⍶")+text)
	elif mode==435: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⍷")+text)
	elif mode==436: results = l11lll_l1_(url)
	elif mode==437: results = l1lll1l1ll_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⍸"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴࠩ⍹"),l11l1l_l1_ (u"ࠪࠫ⍺"),l11l1l_l1_ (u"ࠫࠬ⍻"),l11l1l_l1_ (u"ࠬ࠭⍼"),l11l1l_l1_ (u"࠭ࠧ⍽"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⍾"))
	html = response.content
	l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡳࡵ࡮ࡪࡥࡤࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⍿"),html,re.DOTALL)
	l1l1lll_l1_ = l1l1lll_l1_[0].strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⎀"))
	l1l1lll_l1_ = SERVER(l1l1lll_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ⎁"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎂"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⎃"),l11l1l_l1_ (u"࠭ࠧ⎄"),439,l11l1l_l1_ (u"ࠧࠨ⎅"),l11l1l_l1_ (u"ࠨࠩ⎆"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⎇"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎈"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ⎉"),l1l1lll_l1_,435)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎊"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ⎋"),l1l1lll_l1_,434)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎌"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎍"),l11l1l_l1_ (u"ࠩࠪ⎎"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎏"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⎐")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ⎑"),l1l1lll_l1_,431)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎒"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎓")+l1111l_l1_+l11l1l_l1_ (u"ࠨษไ่ฬ๋ࠠศ๊้ࠤ้อ๊็ࠩ⎔"),l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴ࠳ࠪ⎕"),436)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎖"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⎗")+l1111l_l1_+l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦว้่่ࠣฬ๐ๆࠨ⎘"),l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠭ࡢ࡮࡯࠵ࠬ⎙"),436)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎚"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎛")+l1111l_l1_+l11l1l_l1_ (u"ࠩๅหห๋ษࠡฬไู๏๊๊สࠩ⎜"),l1l1lll_l1_,437)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⎝"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⎞"),l11l1l_l1_ (u"ࠬ࠭⎟"),9999)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎠"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎡")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็้๊๐าสࠩ⎢"),l1l1lll_l1_,431,l11l1l_l1_ (u"ࠩࠪ⎣"),l11l1l_l1_ (u"ࠪࠫ⎤"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⎥"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎦"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎧")+l1111l_l1_+l11l1l_l1_ (u"ࠧฤใ็ห๊࠭⎨"),l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠰ࠩ⎩"),436)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎪"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⎫")+l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠬ⎬"),l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠳࠱࠰ࠩ⎭"),436)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡔ࡫ࡷࡩࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡶࡨ࡮ࠢࠨ⎮"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⎯"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		#if title==l11l1l_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⎰"): title = l11l1l_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨ⎱")
		if title in l1l111_l1_: continue
		if title==l11l1l_l1_ (u"ࠪห้ืฦ๋ีํอࠬ⎲"): continue
		if l11l1l_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋࠭⎳") in title: continue
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎴"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎵")+l1111l_l1_+title,l1llll1_l1_,431)
	return
def l1lll1l1ll_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠧࠨ⎶")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⎷"),l1l1l111_l1_+l11l1l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴࠩ⎸"),l11l1l_l1_ (u"ࠪࠫ⎹"),l11l1l_l1_ (u"ࠫࠬ⎺"),l11l1l_l1_ (u"ࠬ࠭⎻"),l11l1l_l1_ (u"࠭ࠧ⎼"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⎽"))
	html = response.content
	l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡳࡵ࡮ࡪࡥࡤࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⎾"),html,re.DOTALL)
	l1l1lll_l1_ = l1l1lll_l1_[0].strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⎿"))
	l1l1lll_l1_ = SERVER(l1l1lll_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ⏀"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡒࡩࡴࡶࡇࡶࡴࡶࡥࡥࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࡪࡰࡪࡑࡦࡹࡴࡦࡴࠥࠫ⏁"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⏂"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l111_l1_: continue
		l1llll1_l1_ = l1l1l111_l1_+l11l1l_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࠪ⏃")+category+l11l1l_l1_ (u"ࠧ࠾ࠩ⏄")+value
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏅"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⏆")+l1111l_l1_+title,l1llll1_l1_,431)
	return
def	l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⏇"),l11l1l_l1_ (u"ࠫࠬ⏈"),l11l1l_l1_ (u"࡙ࠬࡕࡃࡏࡈࡒ࡚࠭⏉"),url)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ⏊"),l1llll1_l1_)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⏋"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⏌"),url,l11l1l_l1_ (u"ࠩࠪ⏍"),l11l1l_l1_ (u"ࠪࠫ⏎"),l11l1l_l1_ (u"ࠫࠬ⏏"),l11l1l_l1_ (u"ࠬ࠭⏐"),l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⏑"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏒"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠨ⏓"),url,431)
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ⏔"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩ⏕"),block,re.DOTALL)
	for l1lll11l11_l1_,title in items:
		if title in l1l111_l1_: continue
		l111ll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡒࡵࡶࡪࡧࡶ࠳ࡐ࡫ࡹࡴ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡀࠫ⏖")+l1lll11l11_l1_
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏗"),l1111l_l1_+title,l111ll1_l1_,431)
	#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⏘"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⏙"),l11l1l_l1_ (u"ࠨࠩ⏚"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡍࡳࡴࡥࡳࡒࡤ࡫ࡪࡌࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠩ⏛"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ⏜"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l111_l1_: continue
	#	if l11l1l_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶ࠳ࠬ⏝") in url: l111ll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴ࡓ࡯ࡷ࡫ࡨࡷ࠴࡚ࡥࡳ࡯ࡶ࠲ࡵ࡮ࡰࡀࠩ⏞")+category+l11l1l_l1_ (u"࠭࠽ࠨ⏟")+value
	#	elif l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠮ࠩ⏠") in url: l111ll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡕࡨࡶ࡮࡫ࡳ࠰ࡉࡨࡸ࠳ࡶࡨࡱࡁࠪ⏡")+category+l11l1l_l1_ (u"ࠩࡀࠫ⏢")+value
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏣"),l1111l_l1_+title,l111ll1_l1_,431)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠫࠬ⏤")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⏥"),l11l1l_l1_ (u"࠭ࠧ⏦"),request,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⏧"))
	items = []
	if l11l1l_l1_ (u"ࠨ࠱ࡗࡩࡷࡳࡳ࠯ࡲ࡫ࡴࠬ⏨") in url or l11l1l_l1_ (u"ࠩ࠲ࡋࡪࡺ࠮ࡱࡪࡳࠫ⏩") in url or l11l1l_l1_ (u"ࠪ࠳ࡐ࡫ࡹࡴ࠰ࡳ࡬ࡵ࠭⏪") in url:
		l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ⏫"):l11l1l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭⏬"),l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⏭"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ⏮")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭⏯"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠩࠪ⏰"),l11l1l_l1_ (u"ࠪࠫ⏱"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⏲"))
		html = response.content
		block = html
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⏳"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ⏴"),url,l11l1l_l1_ (u"ࠧࠨ⏵"),l11l1l_l1_ (u"ࠨࠩ⏶"),l11l1l_l1_ (u"ࠩࠪ⏷"),l11l1l_l1_ (u"ࠪࠫ⏸"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⏹"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡐࡥࡹࡩࡨࡦࡵࡗࡥࡧࡲࡥࠣࠩ⏺"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ⏻"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⏼"),url,l11l1l_l1_ (u"ࠨࠩ⏽"),l11l1l_l1_ (u"ࠩࠪ⏾"),l11l1l_l1_ (u"ࠪࠫ⏿"),l11l1l_l1_ (u"ࠫࠬ␀"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ␁"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡔࡦ࡭ࡩ࡯ࡣࡷࡩࠧ࠭␂"),html,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧ␃"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ␄"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩ␅"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ␆"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪ␇"),l11l1l_l1_ (u"้ࠬไ๋สࠪ␈"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬ␉"),l11l1l_l1_ (u"่ࠧัสๅࠬ␊"),l11l1l_l1_ (u"ࠨ็หหึอษࠨ␋"),l11l1l_l1_ (u"ࠩ฼ี฻࠭␌"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪ␍"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪ␎")]
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ␏"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ␐"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ␑"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ␒"),l1111l_l1_+title,l1llll1_l1_,432,l1ll1l_l1_)
		elif l1ll1l1_l1_ and l11l1l_l1_ (u"ࠩส่า๊โสࠩ␓") in title:
			title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ␔") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␕"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ␖") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␗"),l1111l_l1_+title,l1llll1_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␘"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
	if request!=l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ␙"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡔࡦ࡭ࡩ࡯ࡣࡷࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ␚"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ␛"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ␜") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l1llll1_l1_
				l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
				title = unescapeHTML(title)
				if title!=l11l1l_l1_ (u"ࠬ࠭␝"): addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␞"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭␟")+title,l1llll1_l1_,431)
		l1llll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵ࡫ࡳࡼࡳ࡯ࡳࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ␠"),html,re.DOTALL)
		if l1llll1111_l1_:
			l1llll1_l1_ = l1llll1111_l1_[0]
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␡"),l1111l_l1_+l11l1l_l1_ (u"ู้ࠪอ็ะหࠣห้๋า๋ัࠪ␢"),l1llll1_l1_,431)
	return
def l1lll1ll_l1_(url):
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ␣"),l11l1l_l1_ (u"ࠬ࠷࠱࠲࠳ࠣࠤࠬ␤")+url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ␥"))
	l1l111l_l1_,l1l1111_l1_ = [],[]
	if l11l1l_l1_ (u"ࠧࡆࡲ࡬ࡷࡴࡪࡥࡴ࠰ࡳ࡬ࡵ࠭␦") in url:
		l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ␧"):l11l1l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ␨"),l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ␩"):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ␪")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ␫"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ␬"),l11l1l_l1_ (u"ࠧࠨ␭"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ␮"))
		html = response.content
		l1l1111_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭␯"),url,l11l1l_l1_ (u"ࠪࠫ␰"),l11l1l_l1_ (u"ࠫࠬ␱"),l11l1l_l1_ (u"ࠬ࠭␲"),l11l1l_l1_ (u"࠭ࠧ␳"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭␴"))
		html = response.content
		l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ␵"),html,re.DOTALL)
		l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡉࡵ࡯ࡳࡰࡦࡨࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭␶"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l111l_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡴ࡭࠺ࡪ࡯ࡤ࡫ࡪࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ␷"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ␸"),block,re.DOTALL)
		for post,l1lll1l1l11_l1_,title in items:
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴ࡋࡰࡪࡵࡲࡨࡪࡹ࠮ࡱࡪࡳࡃࠬ␹")+l11l1l_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡃࠧ␺")+l1lll1l1l11_l1_+l11l1l_l1_ (u"ࠧࠧࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ␻")+post
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␼"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
	# l11ll_l1_
	elif l1l1111_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ␽"))
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ␾"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l1_l1_ in items:
			title = title+l11l1l_l1_ (u"ࠫࠥ࠭␿")+l1ll1l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⑀"),l1111l_l1_+title,l1llll1_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l111ll1_l1_ = url+l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ⑁")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⑂"),l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ⑃"),l11l1l_l1_ (u"ࠩࠪ⑄"),l11l1l_l1_ (u"ࠪࠫ⑅"),l11l1l_l1_ (u"ࠫࠬ⑆"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⑇"))
	html = response.content
	l1lll1_l1_ = []
	l1l1lll_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ⑈"))
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱ࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⑉"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1ll1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⑊"),block,re.DOTALL)
		if l1ll1ll111_l1_:
			l1ll1ll111_l1_ = l1ll1ll111_l1_[0]
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ⑋"),l11l1l_l1_ (u"ࠪࠫ⑌"),l11l1l_l1_ (u"ࠫࠬ⑍"),l1ll1ll111_l1_)
			items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ⑎"),block,re.DOTALL)
			for server,title in items:
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂࡷࡪࡸࡶࡦࡴࡀࠫ⑏")+server+l11l1l_l1_ (u"ࠧࠧࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ⑐")+l1ll1ll111_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⑑")+title+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⑒")
				l1lll1_l1_.append(l1llll1_l1_)
	# l1l1111ll_l1_ l1llll1_l1_
	l1l1111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠭ࡪࡨࡵࡥࡲ࡫ࠢ࠿࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⑓"),html,re.DOTALL)
	if l1l1111ll_l1_:
		l1l1111ll_l1_ = l1l1111ll_l1_[0].replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ⑔"),l11l1l_l1_ (u"ࠬ࠭⑕"))
		title = SERVER(l1l1111ll_l1_,l11l1l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ⑖"))
		l1llll1_l1_ = l1l1111ll_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⑗")+title+l11l1l_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ⑘")
		l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⑙"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⑚"),block,re.DOTALL)
		for l1llll1_l1_,title,l111ll1l_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ⑛"),l11l1l_l1_ (u"ࠬ࠭⑜"))
			if l111ll1l_l1_!=l11l1l_l1_ (u"࠭ࠧ⑝"): l111ll1l_l1_ = l11l1l_l1_ (u"ࠧࡠࡡࡢࡣࠬ⑞")+l111ll1l_l1_
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⑟")+title+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭①")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ②"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ③"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭④"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ⑤"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ⑥"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ⑦"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⑧")+search
	l1lllll_l1_(url)
	return
# ===========================================
#     l1lll1l11l_l1_ l1lll1l111_l1_ l1lll1l1l1_l1_
# ===========================================
def l1llll1ll1_l1_(url):
	url = url.split(l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⑨"))[0]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ⑩"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⑪"),l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ⑫"),l11l1l_l1_ (u"ࠧࠨ⑬"),l11l1l_l1_ (u"ࠨࠩ⑭"),l11l1l_l1_ (u"ࠩࠪ⑮"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ⑯"))
	html = response.content
	# all l11111l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭ࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡤࡸࡸࡹࡵ࡮ࠣ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡵࡧ࡭࡯࡮ࡨࡏࡤࡷࡹ࡫ࡲࠣࠩ⑰"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	# name + options block + category
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡤࡸࡸࡹࡵ࡮ࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠯ࠧ⑱"),block,re.DOTALL)
	return l1ll1l1l_l1_
def l1lll1ll1l_l1_(block):
	# value + name
	items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬࡡࡪࠫࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⑲"),block,re.DOTALL)
	return items
def l1lll1lll1_l1_(url):
	#url = url.replace(l11l1l_l1_ (u"ࠧࡤࡣࡷࡁࠬ⑳"),l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⑴"))
	l1llll1l11_l1_ = url.split(l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⑵"))[0]
	l1lll1llll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ⑶"))
	url = url.replace(l1llll1l11_l1_,l1lll1llll_l1_)
	url = url.replace(l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⑷"),l11l1l_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩ⑸"))
	return url
def l1lll1l1l1l_l1_(l1l1l1ll_l1_,url):
	l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⑹")) # l1lllll1l1l_l1_ be l1llllll11l_l1_
	l111lll_l1_ = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⑺")+l11lll1l_l1_
	l111lll_l1_ = l1lll1lll1_l1_(l111lll_l1_)
	return l111lll_l1_
l1l111ll_l1_ = [l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⑻"),l11l1l_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ⑼"),l11l1l_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ⑽"),l11l1l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ⑾")]
l1l1llll_l1_ = [l11l1l_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭⑿"),l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ⒀"),l11l1l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭⒁"),l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⒂"),l11l1l_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ⒃"),l11l1l_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ⒄")]
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭⒅"),l11l1l_l1_ (u"ࠬ࠭⒆"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⒇"),l11l1l_l1_ (u"ࠧࠨ⒈"),filter,url)
	if l11l1l_l1_ (u"ࠨࡁࠪ⒉") in url: url = url.split(l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⒊"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ⒋"),1)
	if filter==l11l1l_l1_ (u"ࠫࠬ⒌"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠬ࠭⒍"),l11l1l_l1_ (u"࠭ࠧ⒎")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ⒏"))
	if type==l11l1l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⒐"):
		if l1l111ll_l1_[0]+l11l1l_l1_ (u"ࠩࡀࠫ⒑") not in l1l1111l_l1_: category = l1l111ll_l1_[0]
		for i in range(len(l1l111ll_l1_[0:-1])):
			if l1l111ll_l1_[i]+l11l1l_l1_ (u"ࠪࡁࠬ⒒") in l1l1111l_l1_: category = l1l111ll_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭⒓")+category+l11l1l_l1_ (u"ࠬࡃ࠰ࠨ⒔")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨ⒕")+category+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ⒖")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠪ⒗"))+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭⒘")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬ⒙"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⒚")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⒛")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⒜"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⒝")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠨࠩ⒞"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⒟")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		if l1l11111_l1_==l11l1l_l1_ (u"ࠪࠫ⒠"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⒡")+l1l11111_l1_
		l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒢"),l1111l_l1_+l11l1l_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ⒣"),l111ll1_l1_,431)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒤"),l1111l_l1_+l11l1l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ⒥")+l11ll111_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ⒦"),l111ll1_l1_,431)
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⒧"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⒨"),l11l1l_l1_ (u"ࠬ࠭⒩"),9999)
	l1ll1l1l_l1_ = l1llll1ll1_l1_(url)
	dict = {}
	for name,block,l1ll11ll_l1_ in l1ll1l1l_l1_:
		name = name.replace(l11l1l_l1_ (u"࠭࠭࠮ࠩ⒪"),l11l1l_l1_ (u"ࠧࠨ⒫"))
		items = l1lll1ll1l_l1_(block)
		if l11l1l_l1_ (u"ࠨ࠿ࠪ⒬") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⒭"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<2:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]:
					url = l1lll1lll1_l1_(url)
					l1lllll_l1_(url)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⒮")+l1l11l1l_l1_)
				return
			else:
				l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⒯"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭⒰"),l111ll1_l1_,431)
				else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒱"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ⒲"),l111ll1_l1_,435,l11l1l_l1_ (u"ࠨࠩ⒳"),l11l1l_l1_ (u"ࠩࠪ⒴"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⒵"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭Ⓐ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠬࡃ࠰ࠨⒷ")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨⒸ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾࠲ࠪⒹ")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬⒺ")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⒻ"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬⒼ")+name,l111ll1_l1_,434,l11l1l_l1_ (u"ࠫࠬⒽ"),l11l1l_l1_ (u"ࠬ࠭Ⓘ"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⒿ"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if value==l11l1l_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧⓀ"): option = l11l1l_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨⓁ")
			elif value==l11l1l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩⓂ"): option = l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬⓃ")
			if option in l1l111_l1_: continue
			#if l11l1l_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪⓄ") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⓟ"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨⓆ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾ࠩⓇ")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪⓈ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀࠫⓉ")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧⓊ")+l1l1l1ll_l1_
			title = option+l11l1l_l1_ (u"ࠫࠥࡀࠧⓋ")#+dict[l1ll11ll_l1_][l11l1l_l1_ (u"ࠬ࠶ࠧⓌ")]
			title = option+l11l1l_l1_ (u"࠭ࠠ࠻ࠩⓍ")+name
			if type==l11l1l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪⓎ"): addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓏ"),l1111l_l1_+title,url,434,l11l1l_l1_ (u"ࠩࠪⓐ"),l11l1l_l1_ (u"ࠪࠫⓑ"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ⓒ"))
			elif type==l11l1l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨⓓ") and l1l111ll_l1_[-2]+l11l1l_l1_ (u"࠭࠽ࠨⓔ") in l1l1111l_l1_:
				l111lll_l1_ = l1lll1l1l1l_l1_(l1l1l1ll_l1_,url)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⓕ"),l1111l_l1_+title,l111lll_l1_,431)
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓖ"),l1111l_l1_+title,url,435,l11l1l_l1_ (u"ࠩࠪⓗ"),l11l1l_l1_ (u"ࠪࠫⓘ"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬⓙ"),l11l1l_l1_ (u"ࠬ࠭ⓚ"),filters,l11l1l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧⓛ"))
	# mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩⓜ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫⓝ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧⓞ")			all l1l1l11l_l1_ & l1llll11l1_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠪࡁࠫ࠭ⓟ"),l11l1l_l1_ (u"ࠫࡂ࠶ࠦࠨⓠ"))
	filters = filters.strip(l11l1l_l1_ (u"ࠬࠬࠧⓡ"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"࠭࠽ࠨⓢ") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠧࠧࠩⓣ"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠨ࠿ࠪⓤ"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠩࠪⓥ")
	for key in l1l1llll_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠪ࠴ࠬⓦ")
		if l11l1l_l1_ (u"ࠫࠪ࠭ⓧ") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧⓨ") and value!=l11l1l_l1_ (u"࠭࠰ࠨⓩ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠧࠡ࠭ࠣࠫ⓪")+value
		elif mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⓫") and value!=l11l1l_l1_ (u"ࠩ࠳ࠫ⓬"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠪࠪࠬ⓭")+key+l11l1l_l1_ (u"ࠫࡂ࠭⓮")+value
		elif mode==l11l1l_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⓯"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨ⓰")+key+l11l1l_l1_ (u"ࠧ࠾ࠩ⓱")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠨࠢ࠮ࠤࠬ⓲"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠫ⓳"))
	l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠪࡁ࠵࠭⓴"),l11l1l_l1_ (u"ࠫࡂ࠭⓵"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⓶"),l11l1l_l1_ (u"࠭ࠧ⓷"),filters,l11l1l_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠸࠲ࠨ⓸"))
	return l1ll111l_l1_
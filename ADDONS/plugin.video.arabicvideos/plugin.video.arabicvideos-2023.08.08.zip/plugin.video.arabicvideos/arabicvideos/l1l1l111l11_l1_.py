﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#import unicodedata,simplejson
def MAIN(mode,l1l1l11l1ll_l1_):
	if l1l1l11l1ll_l1_==l11l1l_l1_ (u"ࠫࠬㅊ"): return
	if mode==1:
		l1l1l11l1l1_l1_ = xbmcgui.l1l1l11l11l_l1_()
		l1l1l11l111_l1_ = xbmcgui.l1l1l111111_l1_(l1l1l11l1l1_l1_)
		l1l1l11l1ll_l1_ = l1l1l111lll_l1_(l1l1l11l1ll_l1_)
		l1l1l11l111_l1_.getControl(311).l1l1l11ll1l_l1_(l1l1l11l1ll_l1_)
	if mode==0:
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ㅋ"))
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫㅌ"))
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㅍ"))
		l1l1l1111l1_l1_=l11l1l_l1_ (u"ࠨ࡚ࠪㅎ")
		if kodi_version>18.99: check = isinstance(l1l1l11l1ll_l1_,str)
		else: check = isinstance(l1l1l11l1ll_l1_,unicode)
		if check==True: l1l1l1111l1_l1_=l11l1l_l1_ (u"ࠩࡘࠫㅏ")
		l1l1l11111l_l1_=str(type(l1l1l11l1ll_l1_))+l11l1l_l1_ (u"ࠪࠤࠬㅐ")+l1l1l11l1ll_l1_+l11l1l_l1_ (u"ࠫࠥ࠭ㅑ")+l1l1l1111l1_l1_+l11l1l_l1_ (u"ࠬࠦࠧㅒ")
		for i in range(0,len(l1l1l11l1ll_l1_),1):
			l1l1l11111l_l1_ += hex(ord(l1l1l11l1ll_l1_[i])).replace(l11l1l_l1_ (u"࠭࠰ࡹࠩㅓ"),l11l1l_l1_ (u"ࠧࠨㅔ"))+l11l1l_l1_ (u"ࠨࠢࠪㅕ")
		l1l1l11l1ll_l1_ = l1l1l111lll_l1_(l1l1l11l1ll_l1_)
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㅖ"))
		l1l1l1111l1_l1_=l11l1l_l1_ (u"ࠪ࡜ࠬㅗ")
		if kodi_version>18.99: check = isinstance(l1l1l11l1ll_l1_, str)
		else: check = isinstance(l1l1l11l1ll_l1_, unicode)
		if check==True: l1l1l1111l1_l1_=l11l1l_l1_ (u"࡚ࠫ࠭ㅘ")
		l1l1l1111ll_l1_=str(type(l1l1l11l1ll_l1_))+l11l1l_l1_ (u"ࠬࠦࠧㅙ")+l1l1l11l1ll_l1_+l11l1l_l1_ (u"࠭ࠠࠨㅚ")+l1l1l1111l1_l1_+l11l1l_l1_ (u"ࠧࠡࠩㅛ")
		for i in range(0,len(l1l1l11l1ll_l1_),1):
			l1l1l1111ll_l1_ += hex(ord(l1l1l11l1ll_l1_[i])).replace(l11l1l_l1_ (u"ࠨ࠲ࡻࠫㅜ"),l11l1l_l1_ (u"ࠩࠪㅝ"))+l11l1l_l1_ (u"ࠪࠤࠬㅞ")
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬㅟ"),l11l1l_l1_ (u"ࠬ࠭ㅠ"),l1l1l11111l_l1_,l1l1l1111ll_l1_)
	return
	#for i in range(0,len(l1l1l11l1ll_l1_)-2,3):
	#	string=hex(ord(l1l1l11l1ll_l1_[i+0]))+l11l1l_l1_ (u"࠭ࠠࠡࠩㅡ")+hex(ord(l1l1l11l1ll_l1_[i+1]))+l11l1l_l1_ (u"ࠧࠡࠢࠪㅢ")+hex(ord(l1l1l11l1ll_l1_[i+2]))
	#	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㅣ"),l11l1l_l1_ (u"ࠩࠪㅤ"),l11l1l_l1_ (u"ࠪࠫㅥ"),string)
	#return
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㅦ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ㅧ"),l11l1l_l1_ (u"࠭ࠧㅨ"),l11l1l_l1_ (u"ࠧࠨㅩ"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l111lll_l1_(l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㅪ"))
	#l1l1l11l1ll_l1_ = unicodedata.normalize(l11l1l_l1_ (u"ࠩࡑࡊࡐࡊࠧㅫ"),l1l1l11l1ll_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫㅬ"),l11l1l_l1_ (u"ࠫࠬㅭ"),l11l1l_l1_ (u"ࠬ࠭ㅮ"),   hex(  unicodedata.combining(l1l1l11l1ll_l1_[0])  )   )
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧㅯ"),l11l1l_l1_ (u"ࠧࠨㅰ"),l1l1l11l1ll_l1_,   hex(ord(  l1l1l11l1ll_l1_[0]  ))   )
	#new = l11l1l_l1_ (u"ࠨࠩㅱ")
	#for l1l1l111l1l_l1_ in l1l1l11l1ll_l1_:
	#	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪㅲ"),l11l1l_l1_ (u"ࠪࠫㅳ"),l11l1l_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫㅴ"),unicodedata.decomposition(l1l1l111l1l_l1_) )
	#	new += l11l1l_l1_ (u"ࠬࡢࡵ࠱ࠩㅵ") + hex(ord(l1l1l111l1l_l1_)).replace(l11l1l_l1_ (u"࠭࠰ࡹࠩㅶ"),l11l1l_l1_ (u"ࠧࠨㅷ"))
	#l1l1l11l1ll_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㅸ"),l11l1l_l1_ (u"ࠩࠪㅹ"),l11l1l_l1_ (u"ࠪࠫㅺ"),l1l1l11l1ll_l1_)
	#new = l11l1l_l1_ (u"ࠫࠬㅻ")
	#for i in range(len(l1l1l11l1ll_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ㅼ"),l11l1l_l1_ (u"࠭ࠧㅽ"),l11l1l_l1_ (u"ࠧࠨㅾ"),str(i))
	#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1] + l1l1l11l1ll_l1_[i+2] + l1l1l11l1ll_l1_[i+3] + l1l1l11l1ll_l1_[i+4] + l1l1l11l1ll_l1_[i+5]
	#l1l1l11l1ll_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㅿ"),l11l1l_l1_ (u"ࠩࠪㆀ"),l11l1l_l1_ (u"ࠪࠫㆁ"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬㆂ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ㆃ"),l11l1l_l1_ (u"࠭ࠧㆄ"),l11l1l_l1_ (u"ࠧࠨㆅ"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㆆ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪㆇ"),l11l1l_l1_ (u"ࠪࠫㆈ"),l11l1l_l1_ (u"ࠫࠬㆉ"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l11l1l_l1_ (u"ࠬ࡫࡭ࡢࡦࠪㆊ")
	#l1l1l111ll1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠬㆋ")+l1l1l11l1ll_l1_+l11l1l_l1_ (u"ࠧࠣ࠮ࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪㆌ"))
	#simplejson.loads(l1l1l111ll1_l1_)
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㆍ"))
	#new = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪㆎ"))
	#l1l1l11l1ll_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㆏"),l11l1l_l1_ (u"ࠫࠬ㆐"),l11l1l_l1_ (u"ࠬ࠭㆑"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l111lll_l1_(l1l1l11l1ll_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㆒"),l11l1l_l1_ (u"ࠧࠨ㆓"),l11l1l_l1_ (u"ࠨࠩ㆔"),l1l1l11l1ll_l1_)
	#new = l11l1l_l1_ (u"ࠩࠪ㆕")
	#for i in range(len(l1l1l11l1ll_l1_)-2,-1,-2):
	#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1]
	#l1l1l11l1ll_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㆖"),l11l1l_l1_ (u"ࠫࠬ㆗"),l11l1l_l1_ (u"ࠬ࠭㆘"),l1l1l11l1ll_l1_)
	#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㆙"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㆚"),l11l1l_l1_ (u"ࠨࠩ㆛"),l11l1l_l1_ (u"ࠩࠪ㆜"),l1l1l11l1ll_l1_)
	#new = l11l1l_l1_ (u"ࠪࠫ㆝")
	#for i in range(len(l1l1l11l1ll_l1_)-2,-1,-2):
	#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1]
	#l1l1l11l1ll_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㆞"),l11l1l_l1_ (u"ࠬ࠭㆟"),l11l1l_l1_ (u"࠭ࠧㆠ"),l1l1l11l1ll_l1_)
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.replace(l11l1l_l1_ (u"ࠧࠡࠩㆡ"),l11l1l_l1_ (u"ࠨࠩㆢ"))
		#new = l11l1l_l1_ (u"ࠩࠪㆣ")
		#for i in range(len(l1l1l11l1ll_l1_)-3,-2,-3):
		#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1] + l1l1l11l1ll_l1_[i+2]
		#l1l1l11l1ll_l1_ = new
		#new = l11l1l_l1_ (u"ࠪࠫㆤ")
		#for i in range(len(l1l1l11l1ll_l1_)-2,-1,-2):
		#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1]
		#l1l1l11l1ll_l1_ = new
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬㆥ"),l11l1l_l1_ (u"ࠬ࠭ㆦ"),l11l1l_l1_ (u"࠭ࠧㆧ"),l1l1l11l1ll_l1_)
		#l1l1l11l1ll_l1_ = l1l1l11l1ll_l1_.l1l1l11ll11_l1_(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㆨ"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㆩ"),l11l1l_l1_ (u"ࠩࠪㆪ"),str(ord(l1l1l11l1ll_l1_[0]))+l11l1l_l1_ (u"ࠪࠤࠬㆫ")+str(ord(l1l1l11l1ll_l1_[1]))+l11l1l_l1_ (u"ࠫࠥ࠭ㆬ")+str(ord(l1l1l11l1ll_l1_[2])),str(len(l1l1l11l1ll_l1_)))
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ㆭ"),l11l1l_l1_ (u"࠭ࠧㆮ"),l11l1l_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠠࡍࡧࡷࡸࡪࡸࡳࠨㆯ"),l1l1l11l1ll_l1_)
		#new = l11l1l_l1_ (u"ࠨࠩㆰ")
		#for i in range(len(l1l1l11l1ll_l1_)-2,-1,-2):
		#	new += l1l1l11l1ll_l1_[i] + l1l1l11l1ll_l1_[i+1]
		#l1l1l11l1ll_l1_ = new
		#new = l1l1l11l1ll_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆱ"))
		#new = new.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㆲ"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬㆳ"),l11l1l_l1_ (u"ࠬ࠭ㆴ"),l11l1l_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭ㆵ"),new )
		#l1l1l11111l_l1_ = l11l1l_l1_ (u"ࠧࠨㆶ")
		#for l1l1l111l1l_l1_ in new:
		#	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㆷ"),l11l1l_l1_ (u"ࠩࠪㆸ"),l11l1l_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪㆹ"),unicodedata.decomposition(l1l1l111l1l_l1_) )
		#	l1l1l11111l_l1_ += l11l1l_l1_ (u"ࠫࡡࡻࠧㆺ") + hex(ord(l1l1l111l1l_l1_)).replace(l11l1l_l1_ (u"ࠬࡾࠧㆻ"),l11l1l_l1_ (u"࠭ࠧㆼ"))
		#l1l1l11111l_l1_ = l1l1l11111l_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨㆽ"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㆾ"),l11l1l_l1_ (u"ࠩࠪㆿ"),l11l1l_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㇀"),l1l1l11111l_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l1l111lll_l1_(new)
		#l1l1l11l1ll_l1_ = new.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇁"))
		#new = new.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇂")) #.decode(l11l1l_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㇃"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㇄"),l11l1l_l1_ (u"ࠨࠩ㇅"),l11l1l_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ㇆"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇇")))   )
		#l1l1l11l1ll_l1_ = l1l1l111lll_l1_(new)
		#l1l1l11l1ll_l1_ = l1l1l111lll_l1_(l1l1l11l1ll_l1_)
		#method=l11l1l_l1_ (u"ࠦࡎࡴࡰࡶࡶ࠱ࡗࡪࡴࡤࡕࡧࡻࡸࠧ㇈")
		#params=l11l1l_l1_ (u"ࠬࢁࠢࡵࡧࡻࡸࠧࡀࠢࠦࡵࠥ࠰ࠥࠨࡤࡰࡰࡨࠦ࠿࡬ࡡ࡭ࡵࡨࢁࠬ㇉") % l1l1l11l1ll_l1_
		#l1l1l111ll1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠤࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠠࠣࠧࡶࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࠢࠨࡷ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ㇊") % (method, params))
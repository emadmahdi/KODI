# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨ⭄")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡌࡒࡓࡠࠩ⭅")
def MAIN(mode,url,text,l11llll_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll111ll11_l1_(text)
	elif mode==542: results = l1ll1111111_l1_(text,url,l11llll_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭆"),l11l1l_l1_ (u"ࠬฮอฬࠢฯำ๏ีࠧ⭇"),l11l1l_l1_ (u"࠭ࠧ⭈"),549)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⭉"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๆะี๊ฮࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⭊"),l11l1l_l1_ (u"ࠩࠪ⭋"),9999)
	l1ll1111lll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⭌"),l11l1l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⭍"))
	if l1ll1111lll_l1_:
		l1ll1111lll_l1_ = l1ll1111lll_l1_[l11l1l_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭⭎")]
		for search in reversed(l1ll1111lll_l1_):
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭏"),search,l11l1l_l1_ (u"ࠧࠨ⭐"),549,l11l1l_l1_ (u"ࠨࠩ⭑"),l11l1l_l1_ (u"ࠩࠪ⭒"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1lllll1l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll11ll11_l1_ = search.replace(l1111l_l1_,l11l1l_l1_ (u"ࠪࠫ⭓"))
	l1l1llll111_l1_(l1lll11ll11_l1_)
	#l1l1lll11ll_l1_ = search+options+l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⭔")
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭕"),l11l1l_l1_ (u"ู࠭ๆๆࠣฬาัࠠอ็ส฽๏ࠦ࠭ࠡࠩ⭖")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⭗"),542,l11l1l_l1_ (u"ࠨࠩ⭘"),l11l1l_l1_ (u"ࠩࠪ⭙"),l1lll11ll11_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⭚"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭛"),l11l1l_l1_ (u"ࠬ࠭⭜"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭝"),l11l1l_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥแึๆฬࠤ࠲ࠦࠧ⭞")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⭟"),542,l11l1l_l1_ (u"ࠩࠪ⭠"),l11l1l_l1_ (u"ࠪࠫ⭡"),l1lll11ll11_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭢"),l11l1l_l1_ (u"ࠬ์สศศฯࠤฬ๊ศฮอ้ࠣ็ูๅสࠢ࠰ࠤࠬ⭣")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ⭤"),542,l11l1l_l1_ (u"ࠧࠨ⭥"),l11l1l_l1_ (u"ࠨࠩ⭦"),l1lll11ll11_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭧"),l11l1l_l1_ (u"ࠪฬาัࠠๆ่ไีิࠦ࠭ࠡࠩ⭨")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬ⭩"),541,l11l1l_l1_ (u"ࠬ࠭⭪"),l11l1l_l1_ (u"࠭ࠧ⭫"),l1lll11ll11_l1_)
	return
def l1l1llll111_l1_(l1ll11l111l_l1_):
	l1ll11l11ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⭬"),l11l1l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⭭"),l1ll11l111l_l1_)
	l1ll11l11l1_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⭮"),l11l1l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⭯"),l1111l_l1_+l1ll11l111l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⭰"),l1ll11l111l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⭱"),l1111l_l1_+l1ll11l111l_l1_)
	old_value = l1ll11l11ll_l1_+l1ll11l11l1_l1_
	if old_value: l1ll11l111l_l1_ = l1111l_l1_+l1ll11l111l_l1_
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⭲"),l1ll11l111l_l1_,old_value,VERYLONG_CACHE)
	return
def l1l1lllll11_l1_():
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ⭳"),l11l1l_l1_ (u"ࠨࠩ⭴"),l11l1l_l1_ (u"ࠩࠪ⭵"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⭶"),l11l1l_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ⭷"))
	if l1ll11111l_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⭸"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⭹"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭⭺"))
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ⭻"),l11l1l_l1_ (u"ࠩࠪ⭼"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⭽"),l11l1l_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ⭾"))
	return
def l1ll1111111_l1_(l1l1lllll1l_l1_,action,l1ll11111l1_l1_=l11l1l_l1_ (u"ࠬ࠭⭿")):
	l1ll11111ll_l1_,l1ll1111l11_l1_,l1ll111l11l_l1_,l1l1lll111l_l1_,l1l1lll1l11_l1_,l1ll111l111_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⮀"):
		if action==l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮁"): l1ll111l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮂"),l11l1l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮃"),l1111l_l1_+l1l1lllll1l_l1_)
		elif action==l11l1l_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮄"): l1ll111l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮅"),l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫ⮆"),l1l1lllll1l_l1_)
		elif action==l11l1l_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬ⮇"): l1ll111l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⮈"),l11l1l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⮉"),(l1ll11111l1_l1_,l1l1lllll1l_l1_))
	if not l1ll111l11l_l1_:
		l1ll111ll1l_l1_ = l11l1l_l1_ (u"๊ࠩิฬࠦวๅสะฯࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮࡝ࡰࠪ⮊")
		l1ll111lll1_l1_ = l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็ࠢส่อำหࠡใํࠤัฺ๋๊ࠢส่๊๎วใ฻ࠣ฽๋ࠦ࡜࡯ࠢࠥ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦࠧ⮋")+l1l1lllll1l_l1_+l11l1l_l1_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࠡ࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่อำหࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯ࠭⮌")
		if action==l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫ⮍"): message = l1ll111lll1_l1_
		else: message = l1ll111ll1l_l1_+l1ll111lll1_l1_
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧ⮎"),l11l1l_l1_ (u"ࠧࠨ⮏"),l11l1l_l1_ (u"ࠨࠩ⮐"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⮑"),message)
		if l1ll11111l_l1_!=1: return
		LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⮒"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ⮓")+l1l1lllll1l_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ⮔"))
		#global menuItemsLIST
		import threading
		#l1ll1111ll1_l1_ = [l11l1l_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ⮕"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ⮖"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ⮗")]
		l1ll11ll111_l1_ = 1
		for l1ll11111l1_l1_ in l1ll1111ll1_l1_:
			l1l1lll111l_l1_[l1ll11111l1_l1_] = []
			options = l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⮘")
			if l11l1l_l1_ (u"ࠪ࠱ࠬ⮙") in l1ll11111l1_l1_: options = options+l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⮚")+l1ll11111l1_l1_+l11l1l_l1_ (u"ࠬࡥࠧ⮛")
			l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_ = l1l1lll1l1l_l1_(l1ll11111l1_l1_)
			if l1ll11ll111_l1_:
				threads[l1ll11111l1_l1_] = threading.Thread(target=l1ll111111l_l1_,args=(l1l1lllll1l_l1_+options,))
				threads[l1ll11111l1_l1_].start()
			else: l1ll111111l_l1_(l1l1lllll1l_l1_+options)
			l1lllll1_l1_(TRANSLATE(l1ll11111l1_l1_),l11l1l_l1_ (u"࠭ࠧ⮜"),time=1000)
		if l1ll11ll111_l1_:
			time.sleep(2)
			for l1ll11111l1_l1_ in l1ll1111ll1_l1_:
				threads[l1ll11111l1_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⮝"),l11l1l_l1_ (u"ࠨࠩ⮞"),l11l1l_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠡࡨࡲࡹࡳࡪࡥࡥ࠼ࠪ⮟"),str(len(menuItemsLIST)))
		for l1ll11111l1_l1_ in l1ll1111ll1_l1_:
			l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_ = l1l1lll1l1l_l1_(l1ll11111l1_l1_)
			for l1l1lllllll_l1_ in menuItemsLIST:
				type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_ = l1l1lllllll_l1_
				if l1ll11l1lll_l1_ in name:
					if l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࠩ⮠") in l1ll11111l1_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⮡")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⮢")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⮣")]: continue
						if l11l1l_l1_ (u"ࠧึใะอࠬ⮤") not in name:
							if   type==l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⮥"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⮦")
							elif type==l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⮧"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⮨")
							elif type==l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮩"): l1ll11111l1_l1_ = l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⮪")
						else:
							if   l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ⮫") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⮬")
							elif l11l1l_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ⮭") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⮮")
							elif l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ⮯") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ⮰")
					elif l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࠫ⮱") in l1ll11111l1_l1_ and 729>=mode>=710:
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⮲")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⮳")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⮴")]: continue
						if l11l1l_l1_ (u"ูࠪๆำษࠨ⮵") not in name:
							if   type==l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⮶"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ⮷")
							elif type==l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⮸"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ⮹")
							elif type==l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮺"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⮻")
						else:
							if   l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ⮼") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭⮽")
							elif l11l1l_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ⮾") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⮿")
							elif l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ⯀") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ⯁")
					elif l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࠫ⯂") in l1ll11111l1_l1_ and 149>=mode>=140:
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯃")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯄")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯅")]: continue
						if l11l1l_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⯆") in name or l11l1l_l1_ (u"ࠧ࠻࠼ࠣࠫ⯇") in name:
							continue
							#if   l111_l1_==l11l1l_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯈"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯉")
							#elif l111_l1_==l11l1l_l1_ (u"ࠪࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭⯊"): l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯋")
							#else: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯌")
						else:
							if   mode==144 and l11l1l_l1_ (u"࠭ࡕࡔࡇࡕࠫ⯍") in name: l1ll11111l1_l1_ = l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯎")
							elif mode==144 and l11l1l_l1_ (u"ࠨࡅࡋࡒࡑ࠭⯏") in name: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯐")
							elif mode==144 and l11l1l_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ⯑") in name: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯒")
							elif mode==143: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⯓")
							else: continue
					elif l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࠬ⯔") in l1ll11111l1_l1_ and 419>=mode>=400:
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯕")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯖")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯗")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ⯘")]: continue
						if   mode in [401,405]: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯙")
						elif mode in [402,406]: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯚")
						elif mode in [403,404]: l1ll11111l1_l1_ = l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ⯛")
						elif mode in [412,413]: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ⯜")
					elif l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࠨ⯝") in l1ll11111l1_l1_ and 39>=mode>=30:
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ⯞")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯟")]: continue
						if   mode in [32,39]: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⯠")
						elif mode in [33,39]: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⯡")
					elif l11l1l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࠭⯢") in l1ll11111l1_l1_ and 29>=mode>=20:
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⯣")]: continue
						if l1l1lllllll_l1_ in l1l1lll111l_l1_[l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⯤")]: continue
						if   l11l1l_l1_ (u"ࠩ࠲ࡥࡷ࠴ࠧ⯥") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⯦")
						elif l11l1l_l1_ (u"ࠫ࠴࡫࡮࠯ࠩ⯧") in url: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⯨")
					#elif l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࠪ⯩") in l1ll11111l1_l1_ and 319>=mode>=310:
					#	if l1l1lllllll_l1_ in l1l1lll111l_l1_[l1ll11111l1_l1_]: continue
					#	if mode==312: l1ll11111l1_l1_ = l1l1llll1l1_l1_+l11l1l_l1_ (u"ࠧ࠮ࡃࡘࡈࡎࡕࡓࠨ⯪")
					#	elif l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࠳ࠧ⯫") in url: l1ll11111l1_l1_ = l1l1llll1l1_l1_+l11l1l_l1_ (u"ࠩ࠰ࡅࡑࡈࡕࡎࡕࠪ⯬")
					#	else: l1ll11111l1_l1_ = l1l1llll1l1_l1_+l11l1l_l1_ (u"ࠪ࠱ࡕࡋࡒࡔࡑࡑࡗࠬ⯭")
					l1l1lll111l_l1_[l1ll11111l1_l1_].append(l1l1lllllll_l1_)
		menuItemsLIST[:] = []
		for l1ll11111l1_l1_ in list(l1l1lll111l_l1_.keys()):
			l1l1lll1l11_l1_[l1ll11111l1_l1_] = []
			l1ll111l111_l1_[l1ll11111l1_l1_] = []
			for type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_ in l1l1lll111l_l1_[l1ll11111l1_l1_]:
				l1l1lllllll_l1_ = (type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_)
				if l11l1l_l1_ (u"ฺࠫ็อสࠩ⯮") in name and type==l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯯"): l1ll111l111_l1_[l1ll11111l1_l1_].append(l1l1lllllll_l1_)
				else: l1l1lll1l11_l1_[l1ll11111l1_l1_].append(l1l1lllllll_l1_)
		l1ll111l1ll_l1_ = [(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⯰"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⯱"),l11l1l_l1_ (u"ࠨࠩ⯲"),157,l11l1l_l1_ (u"ࠩࠪ⯳"),l11l1l_l1_ (u"ࠪࠫ⯴"),l11l1l_l1_ (u"ࠫࠬ⯵"),l11l1l_l1_ (u"ࠬ࠭⯶"),l11l1l_l1_ (u"࠭ࠧ⯷"))]
		for l1ll11111l1_l1_ in l1ll1111l1l_l1_:
			if l1ll11111l1_l1_==l1l1llll1ll_l1_[0]: l1ll111l1ll_l1_ = [(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⯸"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⯹"),l11l1l_l1_ (u"ࠩࠪ⯺"),157,l11l1l_l1_ (u"ࠪࠫ⯻"),l11l1l_l1_ (u"ࠫࠬ⯼"),l11l1l_l1_ (u"ࠬ࠭⯽"),l11l1l_l1_ (u"࠭ࠧ⯾"),l11l1l_l1_ (u"ࠧࠨ⯿"))]
			elif l1ll11111l1_l1_==l1ll11l1l11_l1_[0]: l1ll111l1ll_l1_ = [(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⰰ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰁ"),l11l1l_l1_ (u"ࠪࠫⰂ"),157,l11l1l_l1_ (u"ࠫࠬⰃ"),l11l1l_l1_ (u"ࠬ࠭Ⰴ"),l11l1l_l1_ (u"࠭ࠧⰅ"),l11l1l_l1_ (u"ࠧࠨⰆ"),l11l1l_l1_ (u"ࠨࠩⰇ"))]
			elif l1ll11111l1_l1_==l1l1lll11l1_l1_[0]: l1ll111l1ll_l1_ = [(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰈ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⰹ"),l11l1l_l1_ (u"ࠫࠬⰊ"),157,l11l1l_l1_ (u"ࠬ࠭Ⰻ"),l11l1l_l1_ (u"࠭ࠧⰌ"),l11l1l_l1_ (u"ࠧࠨⰍ"),l11l1l_l1_ (u"ࠨࠩⰎ"),l11l1l_l1_ (u"ࠩࠪⰏ"))]
			if l1ll11111l1_l1_ not in l1l1lll1l11_l1_.keys(): continue
			if l1l1lll1l11_l1_[l1ll11111l1_l1_]:
				l1l1lll1lll_l1_ = TRANSLATE(l1ll11111l1_l1_)
				l1l1llllll1_l1_ = [(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰐ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭Ⱁ")+l1l1lll1lll_l1_+l11l1l_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⱂ"),l11l1l_l1_ (u"࠭ࠧⰓ"),9999,l11l1l_l1_ (u"ࠧࠨⰔ"),l11l1l_l1_ (u"ࠨࠩⰕ"),l11l1l_l1_ (u"ࠩࠪⰖ"),l11l1l_l1_ (u"ࠪࠫⰗ"),l11l1l_l1_ (u"ࠫࠬⰘ"))]
				if 0:
					l1ll11l1l1l_l1_ = l1l1lllll1l_l1_+l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩⰙ")+l11l1l_l1_ (u"࠭ศฮอࠪⰚ")+l11l1l_l1_ (u"ࠧࠡࠩⰛ")+l1l1lll1lll_l1_
				else:
					l1ll11l1l1l_l1_ = l11l1l_l1_ (u"ࠨสะฯࠬⰜ")+l11l1l_l1_ (u"ࠩࠣࠫⰝ")+l1l1lll1lll_l1_+l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧⰞ")+l1l1lllll1l_l1_
				if len(l1l1lll1l11_l1_[l1ll11111l1_l1_])<8: l1ll111l1l1_l1_ = []
				else:
					l1ll11l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧⰟ")+l1ll11l1l1l_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰠ")
					l1ll111l1l1_l1_ = [(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱑ"),l1111l_l1_+l1ll11l1ll1_l1_,l11l1l_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⱒ"),542,l11l1l_l1_ (u"ࠨࠩⰣ"),l1ll11111l1_l1_,l1l1lllll1l_l1_,l11l1l_l1_ (u"ࠩࠪⰤ"),l11l1l_l1_ (u"ࠪࠫⰥ"))]
				l1ll111llll_l1_ = l1l1lll1l11_l1_[l1ll11111l1_l1_]+l1ll111l111_l1_[l1ll11111l1_l1_]
				l1ll1111l11_l1_ += l1ll111l1ll_l1_+l1l1llllll1_l1_+l1ll111llll_l1_[:7]+l1ll111l1l1_l1_
				l1l1lll1ll1_l1_ = [(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰦ"),l1111l_l1_+l1ll11l1l1l_l1_,l11l1l_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⰧ"),542,l11l1l_l1_ (u"࠭ࠧⰨ"),l1ll11111l1_l1_,l1l1lllll1l_l1_,l11l1l_l1_ (u"ࠧࠨⰩ"),l11l1l_l1_ (u"ࠨࠩⰪ"))]
				l1ll11111ll_l1_ += l1ll111l1ll_l1_+l1l1lll1ll1_l1_
				l1ll111l1ll_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⰫ"),(l1ll11111l1_l1_,l1l1lllll1l_l1_),l1ll111llll_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩⰬ"),l1l1lllll1l_l1_,l1ll1111l11_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩⰭ"),l1l1lllll1l_l1_)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⰮ"),l1111l_l1_+l1l1lllll1l_l1_,l1ll11111ll_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧⰯ"),l11l1l_l1_ (u"ࠧࠨⰰ"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⰱ"),l11l1l_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬⰲ"))
		if action==l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⰳ") and l1ll11111ll_l1_: l1ll111l11l_l1_ = l1ll11111ll_l1_
		else: l1ll111l11l_l1_ = l1ll1111l11_l1_
	if action!=l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪⰴ"):
		for type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_ in l1ll111l11l_l1_:
			if action in [l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⰵ"),l11l1l_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬⰶ")] and l11l1l_l1_ (u"ࠧึใะอࠬⰷ") in name and type==l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰸ"): continue
			addMenuItem(type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_)
	return
def l1ll111ll11_l1_(l1l1lllll1l_l1_=l11l1l_l1_ (u"ࠩࠪⰹ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1lllll1l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪⰺ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨⰻ")+search+l11l1l_l1_ (u"ࠬࠦ࡝ࠨⰼ"))
	l1111l1_l1_ = search+options
	if 0:
		l1ll11l1111_l1_,l1lll11ll11_l1_ = search+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪⰽ"),l11l1l_l1_ (u"ࠧࠨⰾ")
	else:
		l1ll11l1111_l1_,l1lll11ll11_l1_ = l11l1l_l1_ (u"ࠨࠩⰿ"),l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭ⱀ")+search
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱁ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱂ"),l11l1l_l1_ (u"ࠬ࠭ⱃ"),157)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱄ"),l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭ⱅ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯࠥࡓ࠳ࡖࠩⱆ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⱇ"),719,l11l1l_l1_ (u"ࠪࠫⱈ"),l11l1l_l1_ (u"ࠫࠬⱉ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱊ"),l11l1l_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬⱋ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤࡎࡖࡔࡗࠩⱌ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⱍ"),239,l11l1l_l1_ (u"ࠩࠪⱎ"),l11l1l_l1_ (u"ࠪࠫⱏ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱐ"),l11l1l_l1_ (u"ࠬࡥࡂࡌࡔࡢࠫⱑ")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสๆีฬ࠭ⱒ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࠨⱓ"),379,l11l1l_l1_ (u"ࠨࠩⱔ"),l11l1l_l1_ (u"ࠩࠪⱕ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱖ"),l11l1l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪⱗ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯ࠭ⱘ")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭ࠧⱙ"),39,l11l1l_l1_ (u"ࠧࠨⱚ"),l11l1l_l1_ (u"ࠨࠩⱛ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱜ"),l11l1l_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩⱝ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫⱞ"),l11l1l_l1_ (u"ࠬ࠭ⱟ"),39,l11l1l_l1_ (u"࠭ࠧⱠ"),l11l1l_l1_ (u"ࠧࠨⱡ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࡤ࠭Ɫ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱣ"),l11l1l_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩⱤ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ⱥ"),l11l1l_l1_ (u"ࠬ࠭ⱦ"),39,l11l1l_l1_ (u"࠭ࠧⱧ"),l11l1l_l1_ (u"ࠧࠨⱨ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭Ⱪ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱪ"),l11l1l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⱫ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨⱬ"),l11l1l_l1_ (u"ࠬ࠭Ɑ"),149,l11l1l_l1_ (u"࠭ࠧⱮ"),l11l1l_l1_ (u"ࠧࠨⱯ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨⱰ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱱ"),l11l1l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⱲ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬⱳ"),l11l1l_l1_ (u"ࠬ࠭ⱴ"),149,l11l1l_l1_ (u"࠭ࠧⱵ"),l11l1l_l1_ (u"ࠧࠨⱶ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫⱷ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱸ"),l11l1l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩⱹ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬⱺ"),l11l1l_l1_ (u"ࠬ࠭ⱻ"),149,l11l1l_l1_ (u"࠭ࠧⱼ"),l11l1l_l1_ (u"ࠧࠨⱽ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪⱾ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱿ"),l11l1l_l1_ (u"ࠪࡣࡐࡒࡁࡠࠩⲀ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨⲁ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠬ࠭Ⲃ"),19,l11l1l_l1_ (u"࠭ࠧⲃ"),l11l1l_l1_ (u"ࠧࠨⲄ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲅ"),l11l1l_l1_ (u"ࠩࡢࡅࡗ࡚࡟ࠨⲆ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩⲇ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬⲈ"),739,l11l1l_l1_ (u"ࠬ࠭ⲉ"),l11l1l_l1_ (u"࠭ࠧⲊ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲋ"),l11l1l_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧⲌ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩⲍ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⲎ"),329,l11l1l_l1_ (u"ࠫࠬⲏ"),l11l1l_l1_ (u"ࠬ࠭Ⲑ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l11l1l_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭Ⲓ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧⲓ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⲔ"),579,l11l1l_l1_ (u"ࠪࠫⲕ"),l11l1l_l1_ (u"ࠫࠬⲖ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲗ"),l11l1l_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬⲘ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠬⲙ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⲚ"),129,l11l1l_l1_ (u"ࠩࠪⲛ"),l11l1l_l1_ (u"ࠪࠫⲜ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲝ"),l11l1l_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⲞ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ⲟ"),l11l1l_l1_ (u"ࠧࠨⲠ"),409,l11l1l_l1_ (u"ࠨࠩⲡ"),l11l1l_l1_ (u"ࠩࠪⲢ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘࡥࠧⲣ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲤ"),l11l1l_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⲥ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪⲦ"),l11l1l_l1_ (u"ࠧࠨⲧ"),409,l11l1l_l1_ (u"ࠨࠩⲨ"),l11l1l_l1_ (u"ࠩࠪⲩ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪⲪ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲫ"),l11l1l_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫⲬ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪⲭ"),l11l1l_l1_ (u"ࠧࠨⲮ"),409,l11l1l_l1_ (u"ࠨࠩⲯ"),l11l1l_l1_ (u"ࠩࠪⲰ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩⲱ"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲲ"),l11l1l_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⲳ")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩⲴ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠧࠡࠢࠪⲵ"),l11l1l_l1_ (u"ࠨࠩⲶ"),29,l11l1l_l1_ (u"ࠩࠪⲷ"),l11l1l_l1_ (u"ࠪࠫⲸ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲹ"),l11l1l_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⲺ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬⲻ"),l11l1l_l1_ (u"ࠧࠨⲼ"),29,l11l1l_l1_ (u"ࠨࠩⲽ"),l11l1l_l1_ (u"ࠩࠪⲾ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉ࡟ࠨⲿ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳀ"),l11l1l_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳁ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨⳂ"),l11l1l_l1_ (u"ࠧࠨⳃ"),29,l11l1l_l1_ (u"ࠨࠩⳄ"),l11l1l_l1_ (u"ࠩࠪⳅ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࡠࠩⳆ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳇ"),l11l1l_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫⳈ")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧⳉ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࠨⳊ"),79,l11l1l_l1_ (u"ࠨࠩⳋ"),l11l1l_l1_ (u"ࠩࠪⳌ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳍ"),l11l1l_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪⳎ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ⳏ")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭ࠧⳐ"),249,l11l1l_l1_ (u"ࠧࠨⳑ"),l11l1l_l1_ (u"ࠨࠩⳒ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳓ"),l11l1l_l1_ (u"ࠪࡣࡒࡘࡆࠨⳔ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬⳕ"),l11l1l_l1_ (u"ࠬ࠭Ⳗ"),49,l11l1l_l1_ (u"࠭ࠧⳗ"),l11l1l_l1_ (u"ࠧࠨⳘ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳙ"),l11l1l_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨⳚ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧⳛ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬⳜ"),59,l11l1l_l1_ (u"ࠬ࠭ⳝ"),l11l1l_l1_ (u"࠭ࠧⳞ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳟ"),l11l1l_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧⳠ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬⳡ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⳢ"),69,l11l1l_l1_ (u"ࠫࠬⳣ"),l11l1l_l1_ (u"ࠬ࠭ⳤ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳥"),l11l1l_l1_ (u"ࠧࡠࡍ࡚ࡘࡤ࠭⳦")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็็ํััࠨ⳧"),l11l1l_l1_ (u"ࠩࠪ⳨"),139,l11l1l_l1_ (u"ࠪࠫ⳩"),l11l1l_l1_ (u"ࠫࠬ⳪"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳫ"),l11l1l_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬⳬ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭Ⳮ"),l11l1l_l1_ (u"ࠨࠩⳮ"),319,l11l1l_l1_ (u"ࠩࠪ⳯"),l11l1l_l1_ (u"ࠪࠫ⳰"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳱"),l11l1l_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫⳲ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪⳳ"),l11l1l_l1_ (u"ࠧࠨ⳴"),319,l11l1l_l1_ (u"ࠨࠩ⳵"),l11l1l_l1_ (u"ࠩࠪ⳶"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࡤ࠭⳷"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳸"),l11l1l_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ⳹")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ๋ࠥฬๅัࠪ⳺"),l11l1l_l1_ (u"ࠧࠨ⳻"),319,l11l1l_l1_ (u"ࠨࠩ⳼"),l11l1l_l1_ (u"ࠩࠪ⳽"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬ⳾"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳿"),l11l1l_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫⴀ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬⴁ"),l11l1l_l1_ (u"ࠧࠨⴂ"),319,l11l1l_l1_ (u"ࠨࠩⴃ"),l11l1l_l1_ (u"ࠩࠪⴄ"),l1111l1_l1_+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬⴅ"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⴆ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⴇ"),l11l1l_l1_ (u"࠭ࠧⴈ"),157)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴉ"),l11l1l_l1_ (u"ࠨࡡࡎࡘࡐࡥࠧⴊ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠪⴋ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⴌ"),679,l11l1l_l1_ (u"ࠫࠬⴍ"),l11l1l_l1_ (u"ࠬ࠭ⴎ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l11l1l_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭ⴐ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨࠢหัะࠦๅ้ไ฼ࠤๆาัࠡึ๋ࠫⴑ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠩࠣࠫⴒ"),l11l1l_l1_ (u"ࠪࠫⴓ"),399,l11l1l_l1_ (u"ࠫࠬⴔ"),l11l1l_l1_ (u"ࠬ࠭ⴕ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴖ"),l11l1l_l1_ (u"ࠧࡠࡖ࡙ࡊࡤ࠭ⴗ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬⴘ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⴙ"),469,l11l1l_l1_ (u"ࠪࠫⴚ"),l11l1l_l1_ (u"ࠫࠬⴛ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴜ"),l11l1l_l1_ (u"࠭࡟ࡍࡆࡑࡣࠬⴝ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ็์ิ๐ࠠ็ฬࠪⴞ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⴟ"),459,l11l1l_l1_ (u"ࠩࠪⴠ"),l11l1l_l1_ (u"ࠪࠫⴡ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴢ"),l11l1l_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫⴣ")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦๆศ๊ࠪⴤ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࠨⴥ"),309,l11l1l_l1_ (u"ࠨࠩ⴦"),l11l1l_l1_ (u"ࠩࠪⴧ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l11l1l_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ⴩")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿้ࠠ์ࠣื๏๋วࠨ⴪")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭ࠧ⴫"),569,l11l1l_l1_ (u"ࠧࠨ⴬"),l11l1l_l1_ (u"ࠨࠩⴭ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l11l1l_l1_ (u"ࠪࡣࡘࡎࡎࡠࠩ⴯")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩⴰ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠬ࠭ⴱ"),589,l11l1l_l1_ (u"࠭ࠧⴲ"),l11l1l_l1_ (u"ࠧࠨⴳ"),l1111l1_l1_+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ⴴ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴵ"),l11l1l_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩⴶ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨⴷ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠬ࠭ⴸ"),369,l11l1l_l1_ (u"࠭ࠧⴹ"),l11l1l_l1_ (u"ࠧࠨⴺ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴻ"),l11l1l_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨⴼ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭ⴽ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬⴾ"),489,l11l1l_l1_ (u"ࠬ࠭ⴿ"),l11l1l_l1_ (u"࠭ࠧⵀ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵁ"),l11l1l_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧⵂ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ⵃ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⵄ"),259,l11l1l_l1_ (u"ࠫࠬⵅ"),l11l1l_l1_ (u"ࠬ࠭ⵆ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵇ"),l11l1l_l1_ (u"ࠧࡠࡅ࠷࡙ࡤ࠭ⵈ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧⵉ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⵊ"),429,l11l1l_l1_ (u"ࠪࠫⵋ"),l11l1l_l1_ (u"ࠫࠬⵌ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵍ"),l11l1l_l1_ (u"࠭࡟ࡔࡊ࠷ࡣࠬⵎ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭ⵏ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⵐ"),119,l11l1l_l1_ (u"ࠩࠪⵑ"),l11l1l_l1_ (u"ࠪࠫⵒ"),l1111l1_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩⵓ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵔ"),l11l1l_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬⵕ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭ⵖ"),l11l1l_l1_ (u"ࠨࠩⵗ"),389,l11l1l_l1_ (u"ࠩࠪⵘ"),l11l1l_l1_ (u"ࠪࠫⵙ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵚ"),l11l1l_l1_ (u"ࠬࡥࡅࡈࡘࡢࠫⵛ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡวํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨⵜ"),l11l1l_l1_ (u"ࠧࠨⵝ"),229,l11l1l_l1_ (u"ࠨࠩⵞ"),l11l1l_l1_ (u"ࠩࠪⵟ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⵠ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⵡ"),l11l1l_l1_ (u"ࠬ࠭ⵢ"),157)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵣ"),l11l1l_l1_ (u"ࠧࡠࡎࡕ࡞ࡤ࠭ⵤ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻่ࠣฬื่ำษࠪⵥ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⵦ"),709,l11l1l_l1_ (u"ࠪࠫⵧ"),l11l1l_l1_ (u"ࠫࠬ⵨"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵩"),l11l1l_l1_ (u"࠭࡟ࡇࡕࡗࡣࠬ⵪")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไ์ุะวࠨ⵫")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩ⵬"),609,l11l1l_l1_ (u"ࠩࠪ⵭"),l11l1l_l1_ (u"ࠪࠫ⵮"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵯ"),l11l1l_l1_ (u"ࠬࡥࡆࡃࡍࡢࠫ⵰")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใหี่ฯࠧ⵱")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࠨ⵲"),629,l11l1l_l1_ (u"ࠨࠩ⵳"),l11l1l_l1_ (u"ࠩࠪ⵴"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵵"),l11l1l_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪ⵶")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋ࠠษๅ์ฯ࠭⵷")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭ࠧ⵸"),669,l11l1l_l1_ (u"ࠧࠨ⵹"),l11l1l_l1_ (u"ࠨࠩ⵺"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵻"),l11l1l_l1_ (u"ࠪࡣࡇࡘࡓࡠࠩ⵼")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศาีอ๎ั࠭⵽")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠬ࠭⵾"),659,l11l1l_l1_ (u"⵿࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨⶀ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶁ"),l11l1l_l1_ (u"ࠩࡢࡌࡑࡉ࡟ࠨⶂ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧⶃ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬⶄ"),89,l11l1l_l1_ (u"ࠬ࠭ⶅ"),l11l1l_l1_ (u"࠭ࠧⶆ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶇ"),l11l1l_l1_ (u"ࠨࡡࡇࡖ࠼ࡥࠧⶈ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤิืวๆษูࠣา࠭ⶉ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⶊ"),689,l11l1l_l1_ (u"ࠫࠬⶋ"),l11l1l_l1_ (u"ࠬ࠭ⶌ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶍ"),l11l1l_l1_ (u"ࠧࡠࡅࡐࡊࡤ࠭ⶎ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡใส๊ื࠭ⶏ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⶐ"),99,l11l1l_l1_ (u"ࠪࠫⶑ"),l11l1l_l1_ (u"ࠫࠬⶒ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶓ"),l11l1l_l1_ (u"࠭࡟ࡄࡏࡏࡣࠬⶔ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠๅษํฮࠬⶕ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⶖ"),479,l11l1l_l1_ (u"ࠩࠪ⶗"),l11l1l_l1_ (u"ࠪࠫ⶘"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⶙"),l11l1l_l1_ (u"ࠬࡥࡁࡃࡆࡢࠫ⶚")+l1ll11l1111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬูࠦษั๋ࠫ⶛")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠧࠨ⶜"),559,l11l1l_l1_ (u"ࠨࠩ⶝"),l11l1l_l1_ (u"ࠩࠪ⶞"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶟"),l11l1l_l1_ (u"ࠫࡤࡉ࠴ࡉࡡࠪⶠ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩⶡ")+l1lll11ll11_l1_,l11l1l_l1_ (u"࠭ࠧⶢ"),699,l11l1l_l1_ (u"ࠧࠨⶣ"),l11l1l_l1_ (u"ࠨࠩⶤ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶥ"),l11l1l_l1_ (u"ࠪࡣࡆࡎࡋࡠࠩⶦ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ⶧")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠬ࠭ⶨ"),619,l11l1l_l1_ (u"࠭ࠧⶩ"),l11l1l_l1_ (u"ࠧࠨⶪ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶫ"),l11l1l_l1_ (u"ࠩࡢࡇࡈࡈ࡟ࠨⶬ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨⶭ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠫࠬⶮ"),639,l11l1l_l1_ (u"ࠬ࠭⶯"),l11l1l_l1_ (u"࠭ࠧⶰ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶱ"),l11l1l_l1_ (u"ࠨࡡࡖࡌ࡙ࡥࠧⶲ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨⶳ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⶴ"),649,l11l1l_l1_ (u"ࠫࠬⶵ"),l11l1l_l1_ (u"ࠬ࠭ⶶ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⶷"),l11l1l_l1_ (u"ࠧࡠࡇࡊࡒࡤ࠭ⶸ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊่ࠡส์ࠬⶹ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⶺ"),439,l11l1l_l1_ (u"ࠪࠫⶻ"),l11l1l_l1_ (u"ࠫࠬⶼ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶽ"),l11l1l_l1_ (u"࠭࡟ࡇࡊ࠵ࡣࠬⶾ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧ⶿")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠨࠩⷀ"),599,l11l1l_l1_ (u"ࠩࠪⷁ"),l11l1l_l1_ (u"ࠪࠫⷂ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷃ"),l11l1l_l1_ (u"ࠬࡥࡅࡈࡆࡢࠫⷄ")+l1lll11ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡวํะ๏ࠦฯ๋ัࠪⷅ"),l11l1l_l1_ (u"ࠧࠨⷆ"),449,l11l1l_l1_ (u"ࠨࠩ⷇"),l11l1l_l1_ (u"ࠩࠪⷈ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷉ"),l11l1l_l1_ (u"ࠫࡤࡇࡋࡄࡡࠪⷊ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศๅ๋ห๊ࠦใศ็ࠪⷋ"),l11l1l_l1_ (u"࠭ࠧⷌ"),359,l11l1l_l1_ (u"ࠧࠨⷍ"),l11l1l_l1_ (u"ࠨࠩⷎ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⷏"),l11l1l_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩⷐ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩⷑ"),l11l1l_l1_ (u"ࠬ࠭ⷒ"),499,l11l1l_l1_ (u"࠭ࠧⷓ"),l11l1l_l1_ (u"ࠧࠨⷔ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷕ"),l11l1l_l1_ (u"ࠩࡢࡅࡗࡒ࡟ࠨⷖ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨ⷗"),l11l1l_l1_ (u"ࠫࠬⷘ"),209,l11l1l_l1_ (u"ࠬ࠭ⷙ"),l11l1l_l1_ (u"࠭ࠧⷚ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷛ"),l11l1l_l1_ (u"ࠨࡡࡋࡉࡑࡥࠧⷜ")+l1lll11ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩⷝ"),l11l1l_l1_ (u"ࠪࠫⷞ"),99,l11l1l_l1_ (u"ࠫࠬ⷟"),l11l1l_l1_ (u"ࠬ࠭ⷠ"),l1111l1_l1_)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷡ"),l11l1l_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭ⷢ")+search+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏ื๊ิࠢไ์ึ่ࠦหึࠪⷣ"),l11l1l_l1_ (u"ࠩࠪⷤ"),218,l11l1l_l1_ (u"ࠪࠫⷥ"),l11l1l_l1_ (u"ࠫࠬⷦ"),search) # 219
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷧ"),l11l1l_l1_ (u"࠭࡟ࡎࡘ࡝ࡣࠬⷨ")+search+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺ่ࠢ์ๆ๐าࠡๆส๊ิ࠭ⷩ"),l11l1l_l1_ (u"ࠨࠩⷪ"),188,l11l1l_l1_ (u"ࠩࠪⷫ"),l11l1l_l1_ (u"ࠪࠫⷬ"),search)# 189
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⷭ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⷮ"),l11l1l_l1_ (u"࠭ࠧⷯ"),157)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷰ"),l11l1l_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧⷱ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏๎ส๋๊หࠫⷲ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠪࠫⷳ"),149,l11l1l_l1_ (u"ࠫࠬⷴ"),l11l1l_l1_ (u"ࠬ࠭ⷵ"),l1111l1_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷶ"),l11l1l_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭ⷷ")+l1ll11l1111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭ⷸ")+l1lll11ll11_l1_,l11l1l_l1_ (u"ࠩࠪⷹ"),409,l11l1l_l1_ (u"ࠪࠫⷺ"),l11l1l_l1_ (u"ࠫࠬⷻ"),l1111l1_l1_)
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ẹ")
def MAIN(mode,url):
	if   mode==330: results = l11l1lll1l_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l11l111_l1_()
	elif mode==333: results = l111ll1lll_l1_()
	elif mode==334: results = l1l1llll1l_l1_(url)
	else: results = False
	return results
def l1l1llll1l_l1_(l11l11ll1l_l1_):
	try: os.remove(l11l11ll1l_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪẺ")))
	except: os.remove(l11l11ll1l_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬẻ"))
	return
def l111ll1lll_l1_():
	message = l11l1l_l1_ (u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭Ẽ")
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩẽ"),l11l1l_l1_ (u"ࠩࠪẾ"),l11l1l_l1_ (u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡษ็้้็วหࠩế"),message)
	return
def l11l1lll1l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩỀ"),l11l1l_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪề"),l11l1l_l1_ (u"࠭ࠧỂ"),333)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬể"),l11l1l_l1_ (u"ࠨฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨỄ"),l11l1l_l1_ (u"ࠩࠪễ"),332)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨỆ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫệ"),l11l1l_l1_ (u"ࠬ࠭Ỉ"),9999)
	l11l1l11ll_l1_ = l11l111ll1_l1_()
	mtime = os.stat(l11l1l11ll_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1l11l1_l1_ = os.listdir(l11l1l11ll_l1_.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫỉ")))
	else: l11l1l11l1_l1_ = os.listdir(l11l1l11ll_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬỊ")))
	for filename in l11l1l11l1_l1_:
		if kodi_version>18.99: filename = filename.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ị"))
		if not filename.startswith(l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨỌ")): continue
		filepath = os.path.join(l11l1l11ll_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11l1ll11l_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨọ"))
			except: pass
			filename = filename.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩỎ"))
		filepath = os.path.join(l11l1l11ll_l1_,filename)
		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫỏ"),filename,filepath,331)
	return
def l11l111ll1_l1_():
	l11l1l11ll_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩỐ"))
	if l11l1l11ll_l1_: return l11l1l11ll_l1_
	settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪố"),addoncachefolder)
	return addoncachefolder
def l11l11l111_l1_():
	l11l1l11ll_l1_ = l11l111ll1_l1_()
	l111lllll1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨỒ"),l11l1l_l1_ (u"ࠩࠪồ"),l11l1l_l1_ (u"ࠪࠫỔ"),l11l1l11ll_l1_,l11l1l_l1_ (u"ࠫ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨổ"))
	if l111lllll1_l1_==1:
		newpath = l11l11l1l1_l1_(3,l11l1l_l1_ (u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩỖ"),l11l1l_l1_ (u"࠭࡬ࡰࡥࡤࡰࠬỗ"),l11l1l_l1_ (u"ࠧࠨỘ"),False,True,l11l1l11ll_l1_)
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨộ"),l11l1l_l1_ (u"ࠩࠪỚ"),l11l1l_l1_ (u"ࠪࠫớ"),newpath,l11l1l_l1_ (u"ࠫ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨỜ"))
		if l1ll11111l_l1_==1:
			settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨờ"),newpath)
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧỞ"),l11l1l_l1_ (u"ࠧࠨở"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫỠ"),l11l1l_l1_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪỡ"))
	#if not l111lllll1_l1_ or not l1ll11111l_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫỢ"),l11l1l_l1_ (u"ࠫࠬợ"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨỤ"),l11l1l_l1_ (u"࠭สๆࠢส่฿อมࠡษ็฽๊๊๊สࠩụ"))
	return
def l11l11l11l_l1_(filename):
	l11l1lll11_l1_ = l11l1l_l1_ (u"ࠧࠨỦ").join(l11l1ll1l1_l1_ for l11l1ll1l1_l1_ in filename if l11l1ll1l1_l1_ not in l11l1l_l1_ (u"ࠨ࡞࠲ࠦ࠿࠰࠿࠽ࡀࡿࠫủ")+half_triangular_colon)
	return l11l1lll11_l1_
def l11l111l1l_l1_(url,l111ll1l11_l1_=l11l1l_l1_ (u"ࠩࠪỨ"),l1l1l111_l1_=l11l1l_l1_ (u"ࠪࠫứ")):
	#l1lllll1_l1_(l11l1l_l1_ (u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫỪ"),l11l1l_l1_ (u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬừ"))
	LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ử"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧử")+url+l11l1l_l1_ (u"ࠨࠢࡠࠫỮ"))
	if not l111ll1l11_l1_: l111ll1l11_l1_ = l11l1l1ll1_l1_(url,l1l1l111_l1_)
	#if not l111ll1l11_l1_:
	#	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪữ"),l11l1l_l1_ (u"ࠪࠫỰ"),l11l1l_l1_ (u"ࠫฯ์า๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨự"),l11l1l_l1_ (u"ࠬอไๆๆไࠤ๊์ࠠ็๊฼ࠤࠬỲ")+l111ll1l11_l1_+l11l1l_l1_ (u"้࠭ࠠษ็ฬึ์วๆฮࠣัฬ๊๊ศࠢ฽๎ึࠦฬศ้ีࠤ้ะอๆ์็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้๋ไโษอࠫỳ"))
	#	LOG_THIS(l11l1l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬỴ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡸࡾࡶࡥ࠰ࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪỵ")+url+l11l1l_l1_ (u"ࠩࠣࡡࠬỶ"))
	#	return False
	l11l1l11ll_l1_ = l11l111ll1_l1_()
	l11l1l1lll_l1_ = l11l1l1111_l1_()
	filename = l11l1l1lll_l1_.replace(l11l1l_l1_ (u"ࠪࠤࠬỷ"),l11l1l_l1_ (u"ࠫࡤ࠭Ỹ"))
	filename = l11l11l11l_l1_(filename)
	#l111ll1l11_l1_ = l111ll1l11_l1_.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪỹ"))
	filename = l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬỺ")+str(int(now))[-4:]+l11l1l_l1_ (u"ࠧࡠࠩỻ")+filename+l111ll1l11_l1_
	l111lll111_l1_ = os.path.join(l11l1l11ll_l1_,filename)
	headers = {}
	headers[l11l1l_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪỼ")] = l11l1l_l1_ (u"ࠩࠪỽ")
	headers[l11l1l_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶࠪỾ")] = l11l1l_l1_ (u"ࠫ࠯࠵ࠪࠨỿ")
	url = url.replace(l11l1l_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨἀ"),l11l1l_l1_ (u"࠭ࠧἁ"))
	if l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬἂ") in url:
		l111ll1_l1_,l111ll1l1l_l1_ = url.rsplit(l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ἃ"),1)
		l111ll1l1l_l1_ = l111ll1l1l_l1_.replace(l11l1l_l1_ (u"ࠩࡿࠫἄ"),l11l1l_l1_ (u"ࠪࠫἅ")).replace(l11l1l_l1_ (u"ࠫࠫ࠭ἆ"),l11l1l_l1_ (u"ࠬ࠭ἇ"))
	else: l111ll1_l1_,l111ll1l1l_l1_ = url,None
	if not l111ll1l1l_l1_: l111ll1l1l_l1_ = l11llll1l_l1_()
	if l111ll1l1l_l1_: headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪἈ")] = l111ll1l1l_l1_
	if l11l1l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩἉ") in l111ll1_l1_: l111ll1_l1_,l11l11111l_l1_ = l111ll1_l1_.rsplit(l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪἊ"),1)
	else: l111ll1_l1_,l11l11111l_l1_ = l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪἋ")
	l111ll1_l1_ = l111ll1_l1_.strip(l11l1l_l1_ (u"ࠪࢀࠬἌ")).strip(l11l1l_l1_ (u"ࠫࠫ࠭Ἅ")).strip(l11l1l_l1_ (u"ࠬࢂࠧἎ")).strip(l11l1l_l1_ (u"࠭ࠦࠨἏ"))
	l11l11111l_l1_ = l11l11111l_l1_.replace(l11l1l_l1_ (u"ࠧࡽࠩἐ"),l11l1l_l1_ (u"ࠨࠩἑ")).replace(l11l1l_l1_ (u"ࠩࠩࠫἒ"),l11l1l_l1_ (u"ࠪࠫἓ"))
	if l11l11111l_l1_:	headers[l11l1l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬἔ")] = l11l11111l_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬἕ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ἖")+l111ll1_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ἗")+str(headers)+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨἘ")+l111lll111_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬἙ"))
	l11l1llll1_l1_ = 1024*1024
	l11l1l1l1l_l1_ = 0
	try:
		l11l1l1l11_l1_ =	xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡫ࡥࡔࡲࡤࡧࡪ࠭Ἒ"))
		l11l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪࠫࠨἛ"),l11l1l1l11_l1_)
		l11l1l1l1l_l1_ = int(l11l1l1l11_l1_[0])
	except: pass
	if not l11l1l1l1l_l1_:
		try:
			l11l11lll1_l1_ = os.l111ll11ll_l1_(l11l1l11ll_l1_)
			l11l1l1l1l_l1_ = l11l11lll1_l1_.f_frsize*l11l11lll1_l1_.f_bavail//l11l1llll1_l1_
		except: pass
	if not l11l1l1l1l_l1_:
		try:
			l11l11lll1_l1_ = os.l11l1ll1ll_l1_(l11l1l11ll_l1_)
			l11l1l1l1l_l1_ = l11l11lll1_l1_.f_frsize*l11l11lll1_l1_.f_bavail//l11l1llll1_l1_
		except: pass
	if not l11l1l1l1l_l1_:
		try:
			import shutil
			total,l11l111lll_l1_,l11l111l11_l1_ = shutil.l11ll1111l_l1_(l11l1l11ll_l1_)
			l11l1l1l1l_l1_ = l11l111l11_l1_//l11l1llll1_l1_
		except: pass
	if not l11l1l1l1l_l1_:
		l11ll111l1_l1_(l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫἜ"),l11l1l_l1_ (u"࠭ๅิษะอࠥอไหะี๎๋ࠦๅอ้๋่ฮ࠭Ἕ"),l11l1l_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣว๋๊ࠦฮัาࠤ๊่ฯศำุ้ࠣออสࠢส่ฯิา๋่ࠣห้็วา฼ฬࠤๆ๐ࠠอ้สึฺ่่ࠦๆํ๋ࠥ็ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ๊ࠥๆࠡ์฼ู้้ࠦ็ัๆࠤส๊้ࠡล้ࠤ๏่่ๆ่ࠢฬึ๋ฬ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠษฯ็ࠤ์ึ็ࠡษ็ู้้ไสࠢ็ห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢๅำࠥ๐ำษสࠣห๊ะไศรࠣะ์อาไࠢหห้๋ไโษอࠤํํะศࠢไ๎์ࠦฮุ๊ิอࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ์้ํะศࠢสุ่ฮศࠡไส้ࠥอไๆสิ้ัࠦๅลไอหࠥฮๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫ἞"),l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ἟"))
		LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧἠ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥࡺࡨࡦࠢࡧ࡭ࡸࡱࠠࡧࡴࡨࡩࠥࡹࡰࡢࡥࡨࠫἡ"))
		return False
	import requests
	if l111ll1l11_l1_==l11l1l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪἢ"):
		l1ll1lll_l1_,l1lll1_l1_ = l11l1lllll_l1_(l111ll1_l1_,headers)
		#DIALOG_SELECT(l11l1l_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪἣ"), l1ll1lll_l1_)
		#DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫἤ"), l1lll1_l1_)
		if len(l1ll1lll_l1_)==0:
			l1lllll1_l1_(l11l1l_l1_ (u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫἥ"),l11l1l_l1_ (u"ࠨࠩἦ"))
			return False
		elif len(l1ll1lll_l1_)==1: l1l_l1_ = 0
		elif len(l1ll1lll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧἧ"), l1ll1lll_l1_)
			if l1l_l1_ == -1 :
				l1lllll1_l1_(l11l1l_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭Ἠ"),l11l1l_l1_ (u"ࠫࠬἩ"))
				return False
		l111ll1_l1_ = l1lll1_l1_[l1l_l1_]
	filesize = 0
	if l111ll1l11_l1_==l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫἪ"):
		l111lll111_l1_ = l111lll111_l1_.rsplit(l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬἫ"))[0]+l11l1l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬἬ")
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬἭ"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪἮ"),headers,l11l1l_l1_ (u"ࠪࠫἯ"),l11l1l_l1_ (u"ࠫࠬἰ"),l11l1l_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊ࠭ࡅࡑ࡚ࡒࡑࡕࡁࡅࡡ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬἱ"))
		l1lll1ll1_l1_ = response.content
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡜ࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨἲ"),l1lll1ll1_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡶࠬἳ"),re.DOTALL)
		if not l1l1_l1_:
			LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ἴ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬἵ")+l111ll1_l1_+l11l1l_l1_ (u"ࠪࠤࡢ࠭ἶ"))
			return False
		l1llll1_l1_ = l1l1_l1_[0]
		if not l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩἷ")):
			if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠬ࠵࠯ࠨἸ")): l1llll1_l1_ = l111ll1_l1_.split(l11l1l_l1_ (u"࠭࠺ࠨἹ"),1)[0]+l11l1l_l1_ (u"ࠧ࠻ࠩἺ")+l1llll1_l1_
			elif l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠨ࠱ࠪἻ")): l1llll1_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭Ἴ"))+l1llll1_l1_
			else: l1llll1_l1_ = l111ll1_l1_.rsplit(l11l1l_l1_ (u"ࠪ࠳ࠬἽ"),1)[0]+l11l1l_l1_ (u"ࠫ࠴࠭Ἶ")+l1llll1_l1_
		response = requests.request(l11l1l_l1_ (u"ࠬࡍࡅࡕࠩἿ"),l1llll1_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l1111ll_l1_ = len(l1l1_l1_)
		filesize = chunksize*l11l1111ll_l1_
	else:
		chunksize = 1*l11l1llll1_l1_
		response = requests.request(l11l1l_l1_ (u"࠭ࡇࡆࡖࠪὀ"),l111ll1_l1_,headers=headers,verify=False,stream=True)
		if l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨὁ") in response.headers: filesize = int(response.headers[l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩὂ")])
		l11l1111ll_l1_ = int(filesize//chunksize)
	#l11l1ll111_l1_ = l11l1111ll_l1_+1
	l11l1ll111_l1_ = int(filesize//l11l1llll1_l1_)+1
	if filesize<21000:
		LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧὃ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡴࡰࡱࠣࡷࡲࡧ࡬࡭ࠢࡲࡶࠥ࡯ࡴࠡ࡫ࡶࠤࡲ࠹ࡵ࠹ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬὄ")+l111ll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨὅ")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ὆")+str(l11l1l1l1l_l1_)+l11l1l_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ὇")+l111lll111_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪὈ"))
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩὉ"),l11l1l_l1_ (u"ࠩࠪὊ"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ὃ"),l11l1l_l1_ (u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭Ὄ"))
		return False
	l11l111111_l1_ = 400
	l111lll1ll_l1_ = l11l1l1l1l_l1_-l11l1ll111_l1_
	if l111lll1ll_l1_<l11l111111_l1_:
		LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪὍ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ὎")+l111ll1_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ὏")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧὐ")+str(l11l1l1l1l_l1_)+l11l1l_l1_ (u"ࠩࠣࡑࡇࠦ࠭ࠡࠩὑ")+str(l11l111111_l1_)+l11l1l_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ὒ")+l111lll111_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧὓ"))
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ὔ"),l11l1l_l1_ (u"࠭ࠧὕ"),l11l1l_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧὖ"),l11l1l_l1_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧὗ")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨ὘")+str(l11l1l1l1l_l1_)+l11l1l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪὙ")+str(l11l111111_l1_)+l11l1l_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭὚"))
		return False
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬὛ"),l11l1l_l1_ (u"࠭ࠧ὜"),l11l1l_l1_ (u"ࠧࠨὝ"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠภࠩ὞"),l11l1l_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢะะ๊ํࠠหไิ๎ออࠠࠨὟ")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡฬๅี๏ฮวࠡࠩὠ")+str(l11l1l1l1l_l1_)+l11l1l_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้้ࠠำหࠥอไๆๆไࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ็่ฯำๅ๋ๆ้๋ࠣࠦวๅว้ฮึ์สࠡว็ํࠥา็ศิๆࠤ࠳ࠦ็ๅࠢส๊ฯࠦๅหลๆำࠥ๎สา์าࠤฬ๊วิฬ่ีฬืࠠษฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥลࠧὡ"))
	if l1ll11111l_l1_!=1:
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ὢ"),l11l1l_l1_ (u"࠭ࠧὣ"),l11l1l_l1_ (u"ࠧࠨὤ"),l11l1l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ὥ"))
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩὦ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡷ࡫ࡦࡶࡵࡨࡨࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ὧ")+l111ll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫὨ")+l111lll111_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨὩ"))
		return False
	LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ὢ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬὫ"))
	l11l1l111l_l1_ = DIALOG_PROGRESS()
	l11l1l111l_l1_.create(l111lll111_l1_,l11l1l_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩὬ"))
	l11l1111l1_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111lll111_l1_,l11l1l_l1_ (u"ࠩࡺࡦࠬὭ"))
	else: file = open(l111lll111_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨὮ")),l11l1l_l1_ (u"ࠫࡼࡨࠧὯ"))
	if l111ll1l11_l1_==l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫὰ"): # l11l111lll_l1_ for l1lll1ll1_l1_ and l111llll11_l1_ chunks video files such as .l11l11llll_l1_
		for l11l1ll1l1_l1_ in range(1,l11l1111ll_l1_+1):
			l1llll1_l1_ = l1l1_l1_[l11l1ll1l1_l1_-1]
			if not l1llll1_l1_.startswith(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫά")):
				if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠧ࠰࠱ࠪὲ")): l1llll1_l1_ = l111ll1_l1_.split(l11l1l_l1_ (u"ࠨ࠼ࠪέ"),1)[0]+l11l1l_l1_ (u"ࠩ࠽ࠫὴ")+l1llll1_l1_
				elif l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠪ࠳ࠬή")): l1llll1_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨὶ"))+l1llll1_l1_
				else: l1llll1_l1_ = l111ll1_l1_.rsplit(l11l1l_l1_ (u"ࠬ࠵ࠧί"),1)[0]+l11l1l_l1_ (u"࠭࠯ࠨὸ")+l1llll1_l1_
			response = requests.request(l11l1l_l1_ (u"ࠧࡈࡇࡗࠫό"),l1llll1_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l111lll1l1_l1_ = time.time()
			l111ll1ll1_l1_ = l111lll1l1_l1_-t1
			l111lll11l_l1_ = l111ll1ll1_l1_//l11l1ll1l1_l1_
			l11l11l1ll_l1_ = l111lll11l_l1_*(l11l1111ll_l1_+1)
			l111llll1l_l1_ = l11l11l1ll_l1_-l111ll1ll1_l1_
			PROGRESS_UPDATE(l11l1l111l_l1_,int(100*l11l1ll1l1_l1_//(l11l1111ll_l1_+1)),l11l1l_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩὺ"),l11l1l_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩύ"),str(l11l1ll1l1_l1_*chunksize//l11l1llll1_l1_)+l11l1l_l1_ (u"ࠪ࠳ࠬὼ")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩώ")+time.strftime(l11l1l_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ὾"),time.gmtime(l111llll1l_l1_))+l11l1l_l1_ (u"࠭ࠠแࠩ὿"))
			if l11l1l111l_l1_.iscanceled():
				l11l1111l1_l1_ = False
				break
	else: # l11111ll_l1_ and other l11l11ll11_l1_ file l11ll11111_l1_
		l11l1ll1l1_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11l1ll1l1_l1_ = l11l1ll1l1_l1_+1
			l111lll1l1_l1_ = time.time()
			l111ll1ll1_l1_ = l111lll1l1_l1_-t1
			l111lll11l_l1_ = l111ll1ll1_l1_/l11l1ll1l1_l1_
			l11l11l1ll_l1_ = l111lll11l_l1_*(l11l1111ll_l1_+1)
			l111llll1l_l1_ = l11l11l1ll_l1_-l111ll1ll1_l1_
			PROGRESS_UPDATE(l11l1l111l_l1_,int(100*l11l1ll1l1_l1_/(l11l1111ll_l1_+1)),l11l1l_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᾀ"),l11l1l_l1_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨᾁ"),str(l11l1ll1l1_l1_*chunksize//l11l1llll1_l1_)+l11l1l_l1_ (u"ࠩ࠲ࠫᾂ")+str(l11l1ll111_l1_)+l11l1l_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨᾃ")+time.strftime(l11l1l_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᾄ"),time.gmtime(l111llll1l_l1_))+l11l1l_l1_ (u"ࠬࠦเࠨᾅ"))
			if l11l1l111l_l1_.iscanceled():
				l11l1111l1_l1_ = False
				break
		response.close()
	file.close()
	l11l1l111l_l1_.close()
	if not l11l1111l1_l1_:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᾆ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠲࡭ࡳࡺࡥࡳࡴࡸࡴࡹ࡫ࡤࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡱࡴࡲࡧࡪࡹࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᾇ")+l111ll1_l1_+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᾈ")+l111lll111_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬᾉ"))
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᾊ"),l11l1l_l1_ (u"ࠫࠬᾋ"),l11l1l_l1_ (u"ࠬ࠭ᾌ"),l11l1l_l1_ (u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫᾍ"))
		return True
	LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᾎ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᾏ")+l111ll1_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᾐ")+l111lll111_l1_+l11l1l_l1_ (u"ࠪࠤࡢ࠭ᾑ"))
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᾒ"),l11l1l_l1_ (u"ࠬ࠭ᾓ"),l11l1l_l1_ (u"࠭ࠧᾔ"),l11l1l_l1_ (u"ࠧห็ࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠษ่ฯหา࠭ᾕ"))
	return True
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ妱")
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭妲"):l11l1l_l1_ (u"ࠪࠫ妳")}
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ妴")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ妵"),l11l1l_l1_ (u"࠭ࡷࡸࡧࠪ妶")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1lllll_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1lll1ll_l1_(url,text)
	elif mode==564: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ妷")+text)
	elif mode==565: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ妸")+text)
	elif mode==566: results = l11lll_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭妹"),l11l11_l1_,l11l1l_l1_ (u"ࠪࠫ妺"),l11l1l_l1_ (u"ࠫࠬ妻"),False,l11l1l_l1_ (u"ࠬ࠭妼"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ妽"))
	#hostname = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ妾")]
	#hostname = hostname.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ妿"))
	#l1l1lll_l1_ = l11l11_l1_
	#url = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ姀")
	#url = l1l1lll_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ姁"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ姂"),l11l1l_l1_ (u"ࠬ࠭姃"),l11l1l_l1_ (u"࠭ࠧ姄"),l11l1l_l1_ (u"ࠧࠨ姅"),l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ姆"))
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ姇"),l1111l_l1_+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ姈"),l11l1l_l1_ (u"ࠫࠬ姉"),8)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ姊"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭始"),l11l1l_l1_ (u"ࠧࠨ姌"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姍"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ姎"),l11l11_l1_,569,l11l1l_l1_ (u"ࠪࠫ姏"),l11l1l_l1_ (u"ࠫࠬ姐"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ姑"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姒"),l1111l_l1_+l11l1l_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ姓"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ委"),564)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姕"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭姖"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ姗"),565)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ姘"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭姙"),l11l1l_l1_ (u"ࠧࠨ姚"),9999)
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ姛"):hostname,l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭姜"):l11l1l_l1_ (u"ࠪࠫ姝")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11l1l_l1_ (u"ࠫࡡ࠵ࠧ姞"),l11l1l_l1_ (u"ࠬ࠵ࠧ姟"))
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ姠"),html,re.DOTALL)
	#if l1l11ll_l1_:
	#	block = l1l11ll_l1_[0]
	#	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭姡"),block,re.DOTALL)
	#	for l1llll1_l1_,title in items:
	#		if l11l1l_l1_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ姢") in l1llll1_l1_: continue
	#		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姣"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ姤")+l1111l_l1_+title,l1llll1_l1_,566)
	#	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ姥"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ姦"),l11l1l_l1_ (u"࠭ࠧ姧"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ姨"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩ姩"),l11l1l_l1_ (u"ࠩࠪ姪"),l11l1l_l1_ (u"ࠪࠫ姫"),l11l1l_l1_ (u"ࠫࠬ姬"),l11l1l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ姭"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ姮"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ姯"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭姰") not in l1llll1_l1_:
			#	server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭姱"))
			#	l1llll1_l1_ = l1llll1_l1_.replace(server,l1l1lll_l1_)
			if title==l11l1l_l1_ (u"ࠪࠫ姲"): continue
			if any(value in title.lower() for value in l1l111_l1_): continue
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姳"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ姴")+l1111l_l1_+title,l1llll1_l1_,566)
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ姵"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ姶"),l11l1l_l1_ (u"ࠨࠩ姷"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ姸"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ姹"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姺"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ姻")+l1111l_l1_+title,l1llll1_l1_,566,l1ll1l_l1_)
	return html
def l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ姼"),l11l1l_l1_ (u"ࠧࠨ姽"),url,l11l1l_l1_ (u"ࠨࠩ姾"))
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ姿"):url,l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ娀"):l11l1l_l1_ (u"ࠫࠬ威")}
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ娂"),url,l11l1l_l1_ (u"࠭ࠧ娃"),l11l1l_l1_ (u"ࠧࠨ娄"),l11l1l_l1_ (u"ࠨࠩ娅"),l11l1l_l1_ (u"ࠩࠪ娆"),l11l1l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ娇"))
	html = response.content
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娈"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ娉"),url,564)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭娊"),l1111l_l1_+l11l1l_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ娋"),url,565)
	if l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ娌") in html:
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娍"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ娎"),url,561,l11l1l_l1_ (u"ࠫࠬ娏"),l11l1l_l1_ (u"ࠬ࠭娐"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ娑"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ娒"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ娓"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娔"),l1111l_l1_+title,l1llll1_l1_,561)
	return
def l1lllll_l1_(l111lll1lll_l1_,type=l11l1l_l1_ (u"ࠪࠫ娕")):
	if l11l1l_l1_ (u"ࠫ࠿ࡀࠧ娖") in l111lll1lll_l1_:
		l111lll_l1_,url = l111lll1lll_l1_.split(l11l1l_l1_ (u"ࠬࡀ࠺ࠨ娗"))
		server = SERVER(l111lll_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ娘"))
		url = server+url
	else: url,l111lll_l1_ = l111lll1lll_l1_,l111lll1lll_l1_
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ娙"):l111lll_l1_,l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ娚"):l11l1l_l1_ (u"ࠩࠪ娛")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ娜"),url,l11l1l_l1_ (u"ࠫࠬ娝"),l11l1l_l1_ (u"ࠬ࠭娞"),l11l1l_l1_ (u"࠭ࠧ娟"),l11l1l_l1_ (u"ࠧࠨ娠"),l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ娡"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ娢"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ娣"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ娤"):
		l1l11ll_l1_ = [html.replace(l11l1l_l1_ (u"ࠬࡢ࡜࠰ࠩ娥"),l11l1l_l1_ (u"࠭࠯ࠨ娦")).replace(l11l1l_l1_ (u"ࠧ࡝࡞ࠥࠫ娧"),l11l1l_l1_ (u"ࠨࠤࠪ娨"))]
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮࡙ࡨࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭娩"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ娪"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l1l111_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ娫"),l11l1l_l1_ (u"ࠬ࠭娬"))
			if l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ娭") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ娮"),l1111l_l1_+title,l1llll1_l1_,563,l1ll1l_l1_)
			elif l11l1l_l1_ (u"ࠨฯ็ๆฮ࠭娯") in title:
				l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ娰"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ娱") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娲"),l1111l_l1_+title,l1llll1_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ娳"),l1111l_l1_+title,l1llll1_l1_,562,l1ll1l_l1_)
		if type==l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ娴"):
			l1ll11lll11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ娵"),block,re.DOTALL)
			if l1ll11lll11_l1_:
				count = l1ll11lll11_l1_[0]
				l1llll1_l1_ = url+l11l1l_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ娶")+count
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娷"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡลัี๎࠭娸"),l1llll1_l1_,561,l11l1l_l1_ (u"ࠫࠬ娹"),l11l1l_l1_ (u"ࠬ࠭娺"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ娻"))
		elif type==l11l1l_l1_ (u"ࠧࠨ娼"):
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ娽"),html,re.DOTALL)
			if l1l11ll_l1_:
				block = l1l11ll_l1_[0]
				items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ娾"),block,re.DOTALL)
				for l1llll1_l1_,title in items:
					title = l11l1l_l1_ (u"ูࠪๆำษࠡࠩ娿")+unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婀"),l1111l_l1_+title,l1llll1_l1_,561)
	return
def l1lll1ll_l1_(url,type=l11l1l_l1_ (u"ࠬ࠭婁")):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ婂"),l11l1l_l1_ (u"ࠧࠨ婃"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ婄"),url,l11l1l_l1_ (u"ࠩࠪ婅"),l11l1l_l1_ (u"ࠪࠫ婆"),l11l1l_l1_ (u"ࠫࠬ婇"),l11l1l_l1_ (u"ࠬ࠭婈"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ婉"))
	html = response.content
	html = l1llll_l1_(html)
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࡟࠲࠷࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠱ࠬ࠲ࠧࠡࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫ࠴࠭ࠩࠋࠋ࡬ࡪࠥ࠭ๅ้ี่ࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡵࡻࡳࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ๅ้ี่ࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭อๅไฬࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࡀࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧฮๆๅอࠬ࠯࡛࠱࡟ࠍࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ๋ࠬࠬิศ้าอࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠤࠥࠦ婊")
	# l1lll1l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ婋"),html,re.DOTALL)
	if not type and l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ婌"),block,re.DOTALL)
		if len(items)>1:
			for l1llll1_l1_,title in items:
				#title = name+l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧ婍")+title
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婎"),l1111l_l1_+title,l1llll1_l1_,563,l11l1l_l1_ (u"ࠬ࠭婏"),l11l1l_l1_ (u"࠭ࠧ婐"),l11l1l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ婑"))
			return
	# l11ll_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ婒"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ婓"),block)
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠫ婔"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ婕"),str(items))
		for l1llll1_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ婖"))
			#title = name+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ婗")+title
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婘"),l1111l_l1_+title,l1llll1_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ婙"),html,re.DOTALL)
		if title: title = title[0].replace(l11l1l_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ婚"),l11l1l_l1_ (u"ࠪࠫ婛")).replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ婜"),l11l1l_l1_ (u"ࠬ࠭婝"))
		else: title = l11l1l_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ婞")
		addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婟"),l1111l_l1_+title,url,562)
	return
def PLAY(url):
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ婠"),url,l11l1l_l1_ (u"ࠩࠪ婡"),l11l1l_l1_ (u"ࠪࠫ婢"),l11l1l_l1_ (u"ࠫࠬ婣"),l11l1l_l1_ (u"ࠬ࠭婤"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ婥"))
	html = response.content
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ婦"),html,re.DOTALL)
	if l11l1l1_l1_:
		l11l1l1_l1_ = [l11l1l1_l1_[0][0],l11l1l1_l1_[0][1]]
		if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ婧"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ婨"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ婩") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if name==l11l1l_l1_ (u"ุࠫ๐ัโำࠣ์๏ࠦำ๋็สࠫ婪"): name = l11l1l_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ婫")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ婬")+name+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ婭")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭婮"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ婯"),block,re.DOTALL)
		for l1llll1_l1_,l111ll1l_l1_ in items:
			if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ婰") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ婱"),l111ll1l_l1_,re.DOTALL)
			if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ婲")+l111ll1l_l1_[0]
			else: l111ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ婳")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡸࡧࡦ࡭ࡲࡧࠧ婴")+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ婵")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ婶"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ婷"),url)
	return
def SEARCH(search,hostname=l11l1l_l1_ (u"ࠫࠬ婸")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭婹"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ婺"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ婻"),l11l1l_l1_ (u"ࠨ࠭ࠪ婼"))
	l1lll1_l1_ = [l11l1l_l1_ (u"ࠩ࠲ࠫ婽"),l11l1l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ婾"),l11l1l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ婿"),l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ媀"),l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ媁")]
	l1l111lll_l1_ = [l11l1l_l1_ (u"ࠧฤใ็ห๊࠭媂"),l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ媃"),l11l1l_l1_ (u"ࠩฦ๊๏๋๊๊ࠡๆีฯ๎ๆࠨ媄"),l11l1l_l1_ (u"ࠪฬึอๅอࠢอ่๏็า๋๊้ࠫ媅"),l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ร็์่๎ࠬ媆")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ媇"), l1l111lll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l11_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ媈"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ媉"),l11l1l_l1_ (u"ࠨࠩ媊"),False,l11l1l_l1_ (u"ࠩࠪ媋"),l11l1l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ媌"))
		#hostname = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭媍")]
		#hostname = response.url
		#hostname = hostname.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ媎"))
	l111ll1_l1_ = hostname+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ媏")+search+l1lll1_l1_[l1l_l1_]
	l1lllll_l1_(l111ll1_l1_)
	return
def l1ll1ll1_l1_(l111lll1lll_l1_,filter):
	if l11l1l_l1_ (u"ࠧࡀࡁࠪ媐") in l111lll1lll_l1_: url = l111lll1lll_l1_.split(l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ媑"))[0]
	else: url = l111lll1lll_l1_
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ媒"):l111lll1lll_l1_,l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ媓"):l11l1l_l1_ (u"ࠫࠬ媔")}
	filter = filter.replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ媕"),l11l1l_l1_ (u"࠭ࠧ媖"))
	type,filter = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ媗"),1)
	if filter==l11l1l_l1_ (u"ࠨࠩ媘"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠩࠪ媙"),l11l1l_l1_ (u"ࠪࠫ媚")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ媛"))
	if type==l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ媜"):
		if l1l1111l1_l1_[0]+l11l1l_l1_ (u"࠭࠽࠾ࠩ媝") not in l1l1111l_l1_: category = l1l1111l1_l1_[0]
		for i in range(len(l1l1111l1_l1_[0:-1])):
			if l1l1111l1_l1_[i]+l11l1l_l1_ (u"ࠧ࠾࠿ࠪ媞") in l1l1111l_l1_: category = l1l1111l1_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ媟")+category+l11l1l_l1_ (u"ࠩࡀࡁ࠵࠭媠")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭媡")+category+l11l1l_l1_ (u"ࠫࡂࡃ࠰ࠨ媢")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠬࠬࠦࠨ媣"))+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ媤")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ媥"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ媦"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ媧")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ媨"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭媩"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠬ࠭媪"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ媫"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠧࠨ媬"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ媭")+l1l11111_l1_
		l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_,l111lll1lll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媮"),l1111l_l1_+l11l1l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭媯"),l1lllll11_l1_,561,l11l1l_l1_ (u"ࠫࠬ媰"),l11l1l_l1_ (u"ࠬ࠭媱"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ媲"))
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媳"),l1111l_l1_+l11l1l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ媴")+l11ll111_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ媵"),l1lllll11_l1_,561,l11l1l_l1_ (u"ࠪࠫ媶"),l11l1l_l1_ (u"ࠫࠬ媷"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭媸"))
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ媹"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ媺"),l11l1l_l1_ (u"ࠨࠩ媻"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭媼"),url,l11l1l_l1_ (u"ࠪࠫ媽"),l11l1l_l1_ (u"ࠫࠬ媾"),l11l1l_l1_ (u"ࠬ࠭媿"),l11l1l_l1_ (u"࠭ࠧ嫀"),l11l1l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ嫁"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠦࠬ嫂"),l11l1l_l1_ (u"ࠩࠥࠫ嫃")).replace(l11l1l_l1_ (u"ࠪࡠࡡ࠵ࠧ嫄"),l11l1l_l1_ (u"ࠫ࠴࠭嫅"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ嫆"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嫇"),block+l11l1l_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嫈"),re.DOTALL)
	dict = {}
	for l1ll11ll_l1_,name,block in l1ll1l1l_l1_:
		name = escapeUNICODE(name)
		if l11l1l_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ嫉") in l1ll11ll_l1_: continue
		items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ嫊"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠪࡁࡂ࠭嫋") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ嫌"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<=1:
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]: l1lllll_l1_(l111ll1_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ嫍")+l1l11l1l_l1_)
				return
			else:
				l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_,l111lll1lll_l1_)
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]:
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫎"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠧ嫏"),l1lllll11_l1_,561,l11l1l_l1_ (u"ࠨࠩ嫐"),l11l1l_l1_ (u"ࠩࠪ嫑"),l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ嫒"))
				else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫓"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠬ嫔"),l111ll1_l1_,564,l11l1l_l1_ (u"࠭ࠧ嫕"),l11l1l_l1_ (u"ࠧࠨ嫖"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ嫗"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬ嫘")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠪࡁࡂ࠶ࠧ嫙")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ嫚")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠬࡃ࠽࠱ࠩ嫛")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ嫜")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫝"),l1111l_l1_+name+l11l1l_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ嫞"),l111ll1_l1_,565,l11l1l_l1_ (u"ࠩࠪ嫟"),l11l1l_l1_ (u"ࠪࠫ嫠"),l1l11l1l_l1_+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭嫡"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11l1l_l1_ (u"ࠬࡸࠧ嫢") or value==l11l1l_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ嫣"): continue
			if any(value in option.lower() for value in l1l111_l1_): continue
			if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫤") in option: continue
			if l11l1l_l1_ (u"ࠨษ็็้࠭嫥") in option: continue
			if l11l1l_l1_ (u"ࠩࡱ࠱ࡦ࠭嫦") in value: continue
			#if value in [l11l1l_l1_ (u"ࠪࡶࠬ嫧"),l11l1l_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ嫨"),l11l1l_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ嫩")]: continue
			#if l1ll11ll_l1_==l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ嫪"): option = value
			if option==l11l1l_l1_ (u"ࠧࠨ嫫"): option = value
			l11l11ll1_l1_ = option
			l1l1l1ll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭嫬"),option,re.DOTALL)
			if l1l1l1ll1ll_l1_: l11l11ll1_l1_ = l1l1l1ll1ll_l1_[0]
			l1lll11ll_l1_ = name+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ嫭")+l11l11ll1_l1_
			dict[l1ll11ll_l1_][value] = l1lll11ll_l1_
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭嫮")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠫࡂࡃࠧ嫯")+l11l11ll1_l1_
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ嫰")+l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠽࠾ࠩ嫱")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ嫲")+l1l1l1ll_l1_
			if type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ嫳"):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫴"),l1111l_l1_+l1lll11ll_l1_,url,565,l11l1l_l1_ (u"ࠪࠫ嫵"),l11l1l_l1_ (u"ࠫࠬ嫶"),l1ll11l1_l1_+l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ嫷"))
			elif type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ嫸") and l1l1111l1_l1_[-2]+l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嫹") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嫺"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ嫻"),l11l1l_l1_ (u"ࠪࠫ嫼"),l11lll1l_l1_,l1l1l1ll_l1_)
				l111lll_l1_ = url+l11l1l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ嫽")+l11lll1l_l1_
				l1lllll11_l1_ = l11ll11ll_l1_(l111lll_l1_,l111lll1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫾"),l1111l_l1_+l1lll11ll_l1_,l1lllll11_l1_,561,l11l1l_l1_ (u"࠭ࠧ嫿"),l11l1l_l1_ (u"ࠧࠨ嬀"),l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嬁"))
			else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬂"),l1111l_l1_+l1lll11ll_l1_,url,564,l11l1l_l1_ (u"ࠪࠫ嬃"),l11l1l_l1_ (u"ࠫࠬ嬄"),l1ll11l1_l1_)
	return
l1l1111l1_l1_ = [l11l1l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ嬅"),l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ嬆"),l11l1l_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ嬇")]
l11lllll1_l1_ = [l11l1l_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭嬈"),l11l1l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ嬉"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ嬊"),l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭嬋"),l11l1l_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭嬌"),l11l1l_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ嬍"),l11l1l_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ嬎"),l11l1l_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ嬏")]
def l11ll11ll_l1_(l111ll1_l1_,l111lll_l1_):
	if l11l1l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ嬐") in l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ嬑"),l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ嬒"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ嬓"),l11l1l_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ嬔"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嬕"),l11l1l_l1_ (u"ࠨ࠱ࠪ嬖"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠩࠩࠪࠬ嬗"),l11l1l_l1_ (u"ࠪ࠳ࠬ嬘"))
	return l111ll1_l1_
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ嬙"),l11l1l_l1_ (u"ࠬ࠭嬚"),filters,l11l1l_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭嬛")+mode)
	# mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ嬜")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嬝")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭嬞")					all filters (l11ll1ll_l1_ l1l1l11l_l1_ filter)
	filters = filters.strip(l11l1l_l1_ (u"ࠪࠪࠫ࠭嬟"))
	l1l111l1_l1_,l1ll111l_l1_ = {},l11l1l_l1_ (u"ࠫࠬ嬠")
	if l11l1l_l1_ (u"ࠬࡃ࠽ࠨ嬡") in filters:
		items = filters.split(l11l1l_l1_ (u"࠭ࠦࠧࠩ嬢"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嬣"))
			l1l111l1_l1_[var] = value
	for key in l11lllll1_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠨ࠲ࠪ嬤")
		if l11l1l_l1_ (u"ࠩࠨࠫ嬥") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ嬦") and value!=l11l1l_l1_ (u"ࠫ࠵࠭嬧"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠦࠫࠡࠩ嬨")+value
		elif mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嬩") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ嬪"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ嬫")+key+l11l1l_l1_ (u"ࠩࡀࡁࠬ嬬")+value
		elif mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ嬭"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ嬮")+key+l11l1l_l1_ (u"ࠬࡃ࠽ࠨ嬯")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠬࠢࠪ嬰"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ嬱"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ嬲"),l11l1l_l1_ (u"ࠩࠪ嬳"),l1ll111l_l1_,l11l1l_l1_ (u"ࠪࡓ࡚࡚ࠧ嬴"))
	return l1ll111l_l1_
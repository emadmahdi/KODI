# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧྛ")
headers = {l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྜ"):l11l1l_l1_ (u"ࠧࠨྜྷ")}
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧྞ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫྟ"),l11l1l_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪྠ"),l11l1l_l1_ (u"๊ࠫ฻วา฻๊ࠫྡ"),l11l1l_l1_ (u"ࠬอูๅ่้ࠣ฾์วࠡ⠕ࠣࡊࡴࡸࠠࡢࡦࡶࠫྡྷ"),l11l1l_l1_ (u"࠭ๅ้สส๎้อสࠨྣ"),l11l1l_l1_ (u"ࠧษำส้ัࠦใๆสํ์ฯืࠧྤ"),l11l1l_l1_ (u"ࠨษ็฽ฬฮࠠไ็ห๎ํะัࠨྥ"),l11l1l_l1_ (u"ࠩสื้อๅ๋ษอࠫྦ"),l11l1l_l1_ (u"ࠪหำื้ࠨྦྷ"),l11l1l_l1_ (u"ࠫฬ่ำศ็ࠣหำื๊ࠨྨ"),l11l1l_l1_ (u"ࠬอิหำส็ฬะࠧྩ")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l1lllll_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l1lll1ll_l1_(url)
	elif mode==254: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ྪ")+text)
	elif mode==255: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫྫ")+text)
	elif mode==256: results = l11lll_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬྫྷ"):l11llll1l_l1_()}
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ྭ"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩྮ"),l11l1l_l1_ (u"ࠫࠬྯ"),headers,l11l1l_l1_ (u"ࠬ࠭ྰ"),l11l1l_l1_ (u"࠭ࠧྱ"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫྲ"))
	html = response.content
	#l11l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧླ"),html,re.DOTALL)
	#if l11l111l_l1_: l11l111l_l1_ = SERVER(l11l111l_l1_[0],l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ྴ"))
	#else: l11l111l_l1_ = l11l11_l1_
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྵ"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫྶ"),l11l1l_l1_ (u"ࠬ࠭ྷ"),259,l11l1l_l1_ (u"࠭ࠧྸ"),l11l1l_l1_ (u"ࠧࠨྐྵ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬྺ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྻ"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ྼ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬ྽"),254)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ྾"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ྿"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ࿀"),255)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭࿁"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࿂"),l11l1l_l1_ (u"ࠪࠫ࿃"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿄"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆ็ํึฮ࠭࿅"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲ࿆ࠬ"),251,l11l1l_l1_ (u"ࠧࠨ࿇"),l11l1l_l1_ (u"ࠨࠩ࿈"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩ࿉"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿊"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿋")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ࿌"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿍"),251,l11l1l_l1_ (u"ࠧࠨ࿎"),l11l1l_l1_ (u"ࠨࠩ࿏"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭࿐"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿑"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿒")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ࿓"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿔"),251,l11l1l_l1_ (u"ࠧࠨ࿕"),l11l1l_l1_ (u"ࠨࠩ࿖"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࿗"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿘"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿙")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬ࿚"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧ࿛"),251,l11l1l_l1_ (u"ࠧࠨ࿜"),l11l1l_l1_ (u"ࠨࠩ࿝"),l11l1l_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪ࿞"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ࿟"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࿠"),l11l1l_l1_ (u"ࠬ࠭࿡"),9999)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡦࡰࡸࡌࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࿢"),html,re.DOTALL)
	l1ll111_l1_ = l1l1111_l1_[0]
	l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࿣"),l1ll111_l1_,re.DOTALL)
	for l1llll1_l1_,title in l1l1l11_l1_:
		title = unescapeHTML(title)
		if title not in l1l111_l1_ and title!=l11l1l_l1_ (u"ࠨࠩ࿤"):
			if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ࿥") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			#l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠪ࠳ࠬ࿦")).replace(SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ࿧")),l11l11_l1_)
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿨"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࿩")+l1111l_l1_+title,l1llll1_l1_,256)
	return html
def l11lll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ࿪"),l11l1l_l1_ (u"ࠨࠩ࿫"),l11l1l_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠣࠤࠥࠦࠠࠨ࿬")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ࿭"),url,l11l1l_l1_ (u"ࠫࠬ࿮"),headers,l11l1l_l1_ (u"ࠬ࠭࿯"),l11l1l_l1_ (u"࠭ࠧ࿰"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ࿱"))
	html = response.content
	if l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠪ࿲") in html: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿳"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪ࿴"),url,251,l11l1l_l1_ (u"ࠫࠬ࿵"),l11l1l_l1_ (u"ࠬ࠭࿶"),l11l1l_l1_ (u"࠭࡭ࡰࡵࡷࠫ࿷"))
	if l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠫ࿸") in html: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿹"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊๋๊ำหࠪ࿺"),url,251,l11l1l_l1_ (u"ࠪࠫ࿻"),l11l1l_l1_ (u"ࠫࠬ࿼"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ࿽"))
	if l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩ࿾") in html:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭࿿"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			if len(l1l11ll_l1_)>1 and type==l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧက"): block = l1l11ll_l1_[1]
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪခ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				l1lll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫဂ"),title,re.DOTALL)
				try: l11l1l1l1_l1_ = l1lll11ll_l1_[0][0]
				except: l11l1l1l1_l1_ = l11l1l_l1_ (u"ࠫࠬဃ")
				try: l11l1l1ll_l1_ = l1lll11ll_l1_[0][1]
				except: l11l1l1ll_l1_ = l11l1l_l1_ (u"ࠬ࠭င")
				l1lll11ll_l1_ = l11l1l1l1_l1_+l11l1l1ll_l1_
				l1lll11ll_l1_ = l1lll11ll_l1_.replace(l11l1l_l1_ (u"࠭࡜࡯ࠩစ"),l11l1l_l1_ (u"ࠧࠨဆ"))
				#LOG_THIS(l11l1l_l1_ (u"ࠨࠩဇ"),str(l1lll11ll_l1_))
				if l11l1l_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠫဈ") in title:
					l11l11l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧဉ"),title,re.DOTALL)
					if l11l11l1l_l1_: l1lll11ll_l1_ = l11l11l1l_l1_[0]
				if not l1lll11ll_l1_:
					l11l11l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩည"),title,re.DOTALL)
					if l11l11l1l_l1_: l1lll11ll_l1_ = l11l11l1l_l1_[0]
				if l1lll11ll_l1_:
					if l11l1l_l1_ (u"ࠬࡱࡥࡺ࠿ࠪဋ") in l1llll1_l1_: type = l1llll1_l1_.split(l11l1l_l1_ (u"࠭࡫ࡦࡻࡀࠫဌ"))[1]
					else: type = l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡩࡸࡺࠧဍ")
					#l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠨ࠱ࠪဎ")).replace(SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ဏ")),l11l11_l1_)
					l1lll11ll_l1_ = l1lll11ll_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬတ"))
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫထ"),l1111l_l1_+l1lll11ll_l1_,l1llll1_l1_,251,l11l1l_l1_ (u"ࠬ࠭ဒ"),l11l1l_l1_ (u"࠭ࠧဓ"),type)
	return
def l1lllll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨန"),l11l1l_l1_ (u"ࠨࠩပ"),l11l1l_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠢࠣࠤࠥࠦࠧဖ")+type,url)
	method,data,items = l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧဗ"),l11l1l_l1_ (u"ࠫࠬဘ"),[]
	if type==l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭မ"):
		if l11l1l_l1_ (u"࠭࠿ࠨယ") in url:
			l11l1lll1_l1_,l11ll1111_l1_ = l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬရ"),{}
			l111ll1_l1_,l11ll111l_l1_ = url.split(l11l1l_l1_ (u"ࠨࡁࠪလ"))
			lines = l11ll111l_l1_.split(l11l1l_l1_ (u"ࠩࠩࠫဝ"))
			for line in lines:
				key,value = line.split(l11l1l_l1_ (u"ࠪࡁࠬသ"))
				l11ll1111_l1_[key] = value
			if lines: method,url,data = l11l1lll1_l1_,l111ll1_l1_,l11ll1111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l11l1l_l1_ (u"ࠫࠬဟ"),l11l1l_l1_ (u"ࠬ࠭ဠ"),l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬအ"))
	html = response.content
	#html = html[99000:]
	if type==l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨဢ"): l1l11ll_l1_ = [html]
	elif l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪဣ") in type: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭ဤ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧဥ"): l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫัี๊ะࠢส่ฬ็ไศ็࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫဦ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫဧ"): l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ဨ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠧ࡮ࡱࡶࡸࠬဩ"): l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪဪ"),html,re.DOTALL)
	else: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡅࡰࡴࡩ࡫ࡴ࠯ࡘࡐࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡅࡧࡵࡅ࡭ࡕࡨࡩࡩࠨࠧါ"),html,re.DOTALL)
	if l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬာ") in type:
		block = l1l11ll_l1_[0]
		zz = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡰࡦࢀࡹ࠯ࠬࡂࠤ࠭ࡹࡲࡤࡾࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨိ"),block,re.DOTALL)
		if zz:
			l1lll1_l1_,l1ll1lll_l1_,l11ll1lll_l1_,l1l111111_l1_ = zip(*zz)
			items = zip(l1lll1_l1_,l1l111111_l1_,l1ll1lll_l1_)
	else:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࡇࡲࡦࡣ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳࡜ࡸࡽ࠶࠰࠺ࢃ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩီ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"࠭ࡗࡘࡇࠪု") in title: continue
		#l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠧ࠰ࠩူ")).replace(SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬေ")),l11l11_l1_)
		#l1ll1l_l1_ = l1ll1l_l1_.rstrip(l11l1l_l1_ (u"ࠩ࠲ࠫဲ")).replace(SERVER(l1ll1l_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧဳ")),l11l11_l1_)
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠫဴ") in title:
			l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨဵ"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬံ") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ့ࠧ"),l1111l_l1_+title,l1llll1_l1_,253,l1ll1l_l1_)
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧး"),l1111l_l1_+title,l1llll1_l1_,252,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲္ࠫ") in l1llll1_l1_ or l11l1l_l1_ (u"ุ้๊ࠪำๅ်ࠩ") in title:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫျ"),l1111l_l1_+title,l1llll1_l1_,253,l1ll1l_l1_)
		else:
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫြ"),l1111l_l1_+title,l1llll1_l1_,252,l1ll1l_l1_)
	if type in [l11l1l_l1_ (u"࠭࡮ࡦࡹࡨࡷࡹ࠭ွ"),l11l1l_l1_ (u"ࠧࡣࡧࡶࡸࠬှ"),l11l1l_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭ဿ")]:
		items = re.findall(l11l1l_l1_ (u"ࠩࡳࡥ࡬࡫࠭࡯ࡷࡰࡦࡪࡸࡳࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၀"),html,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ၁"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ၂")+title,l1llll1_l1_,251,l11l1l_l1_ (u"ࠬ࠭၃"),l11l1l_l1_ (u"࠭ࠧ၄"),type)
	return
def l1lll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ၅"),url,l11l1l_l1_ (u"ࠨࠩ၆"),headers,l11l1l_l1_ (u"ࠩࠪ၇"),l11l1l_l1_ (u"ࠪࠫ၈"),l11l1l_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ၉"))
	html = response.content
	#items = re.findall(l11l1l_l1_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡘ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ၊"),html,re.DOTALL)
	# the first 10000 character of the html file is l11l1ll11_l1_ l11lll111_l1_ in l11lll1l1_l1_ .. it l11ll1l1l_l1_ l11l1l11l_l1_
	html = html[10000:]
	items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ။"),html,re.DOTALL)
	if not items: return
	l1ll1l_l1_,name = items[0]
	if l11l1l_l1_ (u"ࠧศๆะ่็ฯࠧ၌") in name: name = name.split(l11l1l_l1_ (u"ࠨษ็ั้่ษࠨ၍"))[0].strip(l11l1l_l1_ (u"ࠩࠣࠫ၎"))
	elif l11l1l_l1_ (u"ࠪั้่ษࠨ၏") in name: name = name.split(l11l1l_l1_ (u"ࠫา๊โสࠩၐ"))[0].strip(l11l1l_l1_ (u"ࠬࠦࠧၑ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࡇࡳ࡭ࡸࡵࡤࡦࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬၒ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩၓ"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l1_l1_ in items:
			title = name+l11l1l_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤึ่ๅࠡࠩၔ")+l1ll1l1_l1_
			#l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠩ࠲ࠫၕ")).replace(SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧၖ")),l11l11_l1_)
			#l1ll1l_l1_ = l1ll1l_l1_.rstrip(l11l1l_l1_ (u"ࠫ࠴࠭ၗ")).replace(SERVER(l1ll1l_l1_,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩၘ")),l11l11_l1_)
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬၙ"),l1111l_l1_+title,l1llll1_l1_,252,l1ll1l_l1_)
	else: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ၚ"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭ၛ"),url,252,l1ll1l_l1_)
	return
def l111lllll_l1_(title,l1llll1_l1_):
	l1lll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡞ࡥ࠲ࢀࡁ࠮࡜࠰ࡡ࠰࠭ၜ"),title,re.DOTALL)
	if l1lll11ll_l1_: title = l1lll11ll_l1_[0]
	else: title = title+l11l1l_l1_ (u"ࠪࠤࠬၝ")+SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩၞ"))
	title = title.replace(l11l1l_l1_ (u"ࠬ฿ัษࠢึ๎ิ࠭ၟ"),l11l1l_l1_ (u"࠭ࠧၠ")).replace(l11l1l_l1_ (u"ࠧๆสสุึ࠭ၡ"),l11l1l_l1_ (u"ࠨࠩၢ")).replace(l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩၣ"),l11l1l_l1_ (u"ࠪࠫၤ"))
	title = title.replace(l11l1l_l1_ (u"ࠫ๒࠭ၥ"),l11l1l_l1_ (u"ࠬ࠭ၦ"))
	title = title.replace(l11l1l_l1_ (u"࠭ࠠࠡࠩၧ"),l11l1l_l1_ (u"ࠧࠡࠩၨ")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫၩ"),l11l1l_l1_ (u"ࠩࠣࠫၪ"))
	return title
def PLAY(url):
	# https://l11l1111l_l1_.l11l1llll_l1_/فيلم-l11l11lll_l1_-for-my-l111lll11_l1_-2022-مترجم/
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧၫ"),url,l11l1l_l1_ (u"ࠫࠬၬ"),headers,l11l1l_l1_ (u"ࠬ࠭ၭ"),l11l1l_l1_ (u"࠭ࠧၮ"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫၯ"))
	html = response.content
	l111llll1_l1_,l11ll1l11_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠨࠩၰ"),l11l1l_l1_ (u"ࠩࠪၱ"),[]
	# l11l1l111_l1_ & download l11l1111_l1_
	l11llllll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡄࡸࡸࡹࡵ࡮ࡴࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠭ࡽࡡࡵࡥ࡫࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࠬࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࠪࡀࠫࠥࠫၲ"),html,re.DOTALL)
	if l11llllll_l1_: l111llll1_l1_,l11ll1ll1_l1_,l11ll1l11_l1_,l11ll11l1_l1_ = l11llllll_l1_[0]
	else:
		l11llllll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡅࡹࡹࡺ࡯࡯ࡵࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࠮࠮ࠫࡁࠬࠦࠬၳ"),html,re.DOTALL)
		if l11llllll_l1_:
			l1llll1_l1_,l11ll1ll1_l1_ = l11llllll_l1_[0]
			if l11l1l_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫၴ") in l11ll1ll1_l1_: l111llll1_l1_ = l1llll1_l1_
			else: l11ll1l11_l1_ = l1llll1_l1_
	server = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪၵ"))
	#headers = {l11l1l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨၶ"):server,l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬၷ"):l11llll1l_l1_()}
	headers[l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪၸ")] = server
	if l111llll1_l1_:
		# l11l1l111_l1_ l1l1_l1_
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧၹ"),l111llll1_l1_,l11l1l_l1_ (u"ࠫࠬၺ"),headers,l11l1l_l1_ (u"ࠬ࠭ၻ"),l11l1l_l1_ (u"࠭ࠧၼ"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫၽ"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡥࡳࡃࡵࡩࡦࠨࠨ࠯ࠬࡂࡀ࠴ࡻ࡬࠿ࠫࠪၾ"),html,re.DOTALL)
		if l1l11ll_l1_:
			l111ll1l1_l1_ = l1l11ll_l1_[0]
			l111ll1l1_l1_ = l111ll1l1_l1_.replace(l11l1l_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨၿ"),l11l1l_l1_ (u"ࠪࡀ࡭࠹࠾ࠨႀ"))
			l111ll1l1_l1_ = l111ll1l1_l1_.replace(l11l1l_l1_ (u"ࠫࡁ࡮࠳࠿ࠩႁ"),l11l1l_l1_ (u"ࠬࡂࡨ࠴ࡀ࠿࡬࠸ࡄࠧႂ"))
			l11111l_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡩ࠵ࡁ࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࡬࠸ࡄࠧႃ"),l111ll1l1_l1_,re.DOTALL)
			if not l11111l_l1_: l11111l_l1_ = [(l11l1l_l1_ (u"ࠧࠨႄ"),l111ll1l1_l1_)]
			for l111ll1l_l1_,block in l11111l_l1_:
				if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭ႅ")+l111ll1l_l1_
				items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ႆ"),block,re.DOTALL)
				for l1llll1_l1_,name in items:
					if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨႇ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪႈ")+l1llll1_l1_
					#name = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠬ࡮࡯ࡴࡶࠪႉ"))
					l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧႊ")+name+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨႋ")+l111ll1l_l1_
					l1lll1_l1_.append(l1llll1_l1_)
		# l1l1111ll_l1_ l1llll1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႌ"),html,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࡎ࡬ࡲࡢ࡯ࡨࠦ࠳࠰࠿ࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡋࡉࡎࡍࡈࡕ࠿ࠥࠬ࠳࠰࠿ࠪࠤႍࠪ"),html,re.DOTALL)
		if l1l1_l1_:
			l1llll1_l1_,l111ll1l_l1_ = l1l1_l1_[0]
			name = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨႎ"))
			if l11l1l_l1_ (u"ࠫࠪ࠭ႏ") in l111ll1l_l1_: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭႐")+name+l11l1l_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩ႑")
			else: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ႒")+name+l11l1l_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࡡࡢࡣࡤ࠭႓")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	if l11ll1l11_l1_:
		# download l1l1_l1_
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭႔"),l11ll1l11_l1_,l11l1l_l1_ (u"ࠪࠫ႕"),headers,l11l1l_l1_ (u"ࠫࠬ႖"),l11l1l_l1_ (u"ࠬ࠭႗"),l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ႘"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡅࡱࡺࡲࡱࡵࡡࡥࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭႙"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨႚ"),block,re.DOTALL)
			for l1llll1_l1_,title,l111ll1l_l1_ in items:
				if not l1llll1_l1_: continue
				# l11l1ll1l_l1_ l111ll1ll_l1_ by l11l11111_l1_ .. it l11lll11l_l1_ a l11l11l11_l1_ from l11l11111_l1_ l1l11111l_l1_
				if l11l1l_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩႛ") in l1llll1_l1_: continue
				l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
				#title = l111lllll_l1_(title,l1llll1_l1_)
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫႜ")+title+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬႝ")+l111ll1l_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ႞"), l1lll1_l1_)
	l11l111ll_l1_ = str(l1lll1_l1_)
	l111l1l_l1_ = [l11l1l_l1_ (u"࠭࠮ࡻ࡫ࡳࡃࠬ႟"),l11l1l_l1_ (u"ࠧ࠯ࡴࡤࡶࡄ࠭Ⴀ"),l11l1l_l1_ (u"ࠨ࠰ࡷࡼࡹࡅࠧႡ"),l11l1l_l1_ (u"ࠩ࠱ࡴࡩ࡬࠿ࠨႢ"),l11l1l_l1_ (u"ࠪ࠲ࡹࡧࡲࡀࠩႣ"),l11l1l_l1_ (u"ࠫ࠳࡯ࡳࡰࡁࠪႤ"),l11l1l_l1_ (u"ࠬ࠴ࡺࡪࡲ࠱ࠫႥ"),l11l1l_l1_ (u"࠭࠮ࡳࡣࡵ࠲ࠬႦ"),l11l1l_l1_ (u"ࠧ࠯ࡶࡻࡸ࠳࠭Ⴇ"),l11l1l_l1_ (u"ࠨ࠰ࡳࡨ࡫࠴ࠧႨ"),l11l1l_l1_ (u"ࠩ࠱ࡸࡦࡸ࠮ࠨႩ"),l11l1l_l1_ (u"ࠪ࠲࡮ࡹ࡯࠯ࠩႪ")]
	if any(value in l11l111ll_l1_ for value in l111l1l_l1_):
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬႫ"),l11l1l_l1_ (u"ࠬ࠭Ⴌ"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႭ"),l11l1l_l1_ (u"ࠧอำหࠤึอศุ่ࠢาฯ๊แࠡๆฦ๊ࠥํะศࠢส่ึอศุࠢ็๎ุࠦๅ็้ࠢ์฾ࠦวๅำ๋หอ฽ࠠศๆอ๎ࠥ็๊่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤ้ษๆ้ࠡำหࠥอไๆ๊ๅ฽ࠥ็๊่ࠢัำ๊อสࠡลัี๎ฺ๋ࠦำ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪႮ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧႯ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫႰ"),l11l1l_l1_ (u"ࠪ࠯ࠬႱ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡬ࡩ࡯ࡦ࠲ࡃ࡫࡯࡮ࡥ࠿ࠪႲ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬႳ"))
	return
def l1ll1ll1_l1_(url,filter):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧႴ"),l11l1l_l1_ (u"ࠧࠨႵ"),filter,url)
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩႶ"):url,l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ⴗ"):l11l1l_l1_ (u"ࠪࠫႸ")}
	#l1l1l1lll_l1_ = l11l1l_l1_ (u"ࠫࠬႹ")
	#filter = filter.replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧႺ"),l11l1l_l1_ (u"࠭ࠧႻ"))
	if l11l1l_l1_ (u"ࠧࡀࡁࠪႼ") in url: url = url.split(l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧႽ"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭Ⴞ"),1)
	if filter==l11l1l_l1_ (u"ࠪࠫႿ"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠫࠬჀ"),l11l1l_l1_ (u"ࠬ࠭Ⴡ")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"࠭࡟ࡠࡡࠪჂ"))
	if type==l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫჃ"):
		if l1l1111l1_l1_[0]+l11l1l_l1_ (u"ࠨ࠿ࡀࠫჄ") not in l1l1111l_l1_: category = l1l1111l1_l1_[0]
		for i in range(len(l1l1111l1_l1_[0:-1])):
			if l1l1111l1_l1_[i]+l11l1l_l1_ (u"ࠩࡀࡁࠬჅ") in l1l1111l_l1_: category = l1l1111l1_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭჆")+category+l11l1l_l1_ (u"ࠫࡂࡃ࠰ࠨჇ")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ჈")+category+l11l1l_l1_ (u"࠭࠽࠾࠲ࠪ჉")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ჊"))+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ჋")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠪࠬ჌"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭Ⴭ"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ჎")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭჏"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨა"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠧࠨბ"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫგ"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠩࠪდ"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩე")+l1l11111_l1_
		l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫვ"),l1111l_l1_+l11l1l_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨზ"),l1lllll11_l1_,251,l11l1l_l1_ (u"࠭ࠧთ"),l11l1l_l1_ (u"ࠧࠨი"),l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩკ"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩლ"),l1111l_l1_+l11l1l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪმ")+l11ll111_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪნ"),l1lllll11_l1_,251,l11l1l_l1_ (u"ࠬ࠭ო"),l11l1l_l1_ (u"࠭ࠧპ"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨჟ"))
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭რ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩს"),l11l1l_l1_ (u"ࠪࠫტ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩუ"),url,l11l1l_l1_ (u"ࠬ࠭ფ"),headers,l11l1l_l1_ (u"࠭ࠧქ"),l11l1l_l1_ (u"ࠧࠨღ"),l11l1l_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ყ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡕࡧࡵࡱࡇ࡚ࡎࡴࠤࠪშ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l11llll11_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡘࡦࡾࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࡌࡸࡪࡳࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬჩ"),block,re.DOTALL)
	l11lll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡗࡧࡴࡪࡰࡪࡊ࡮ࡲࡴࡦࡴࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄ࠮ࠫࡁࠫࡀࡺࡲ࠾ࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬც"),block,re.DOTALL)
	l1ll1l1l_l1_ = l11llll11_l1_+l11lll1ll_l1_
	dict = {}
	for name,l1ll11ll_l1_,block in l1ll1l1l_l1_:
		#if l11l1l_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧძ") in l1ll11ll_l1_: continue
		items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧწ"),block,re.DOTALL)
		if name==l11l1l_l1_ (u"ࠧศะิํࠬჭ"): name = l11l1l_l1_ (u"ࠨษ็ห็ูวๆࠩხ")
		if not items:
			l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩჯ"),block,re.DOTALL)
			items = []
			for option,value in l1l1l11_l1_: items.append([option,l11l1l_l1_ (u"ࠪࠫჰ"),value])
			l1ll11ll_l1_ = l11l1l_l1_ (u"ࠫࡷࡧࡴࡦࠩჱ")
			name = l11l1l_l1_ (u"ࠬอไหไํ๎๊࠭ჲ")
		else: l1ll11ll_l1_ = items[0][1]
		if l11l1l_l1_ (u"࠭࠽࠾ࠩჳ") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫჴ"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<=1:
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]: l1lllll_l1_(l111ll1_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨჵ")+l1l11l1l_l1_)
				return
			else:
				l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_)
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩჶ"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้าๅ๋฻ࠣࠫჷ"),l1lllll11_l1_,251,l11l1l_l1_ (u"ࠫࠬჸ"),l11l1l_l1_ (u"ࠬ࠭ჹ"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧჺ"))
				else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ჻"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩჼ"),l111ll1_l1_,254,l11l1l_l1_ (u"ࠩࠪჽ"),l11l1l_l1_ (u"ࠪࠫჾ"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬჿ"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨᄀ")+l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠽࠾࠲ࠪᄁ")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪᄂ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠨ࠿ࡀ࠴ࠬᄃ")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭ᄄ")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄅ"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᄆ")+name,l111ll1_l1_,255,l11l1l_l1_ (u"ࠬ࠭ᄇ"),l11l1l_l1_ (u"࠭ࠧᄈ"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᄉ"))
		dict[l1ll11ll_l1_] = {}
		for option,dummy,value in items:
			if option in l1l111_l1_: continue
			if l11l1l_l1_ (u"ࠨษ็็้࠭ᄊ") in option: continue
			option = unescapeHTML(option)
			#if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᄋ") in option: continue
			#if l11l1l_l1_ (u"ࠪࡲ࠲ࡧࠧᄌ") in value: continue
			l11l11ll1_l1_,l1lll11ll_l1_ = option,option
			l1lll11ll_l1_ = name+l11l1l_l1_ (u"ࠫ࠿ࠦࠧᄍ")+l11l11ll1_l1_
			dict[l1ll11ll_l1_][value] = l1lll11ll_l1_
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨᄎ")+l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠽࠾ࠩᄏ")+l11l11ll1_l1_
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪᄐ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠨ࠿ࡀࠫᄑ")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭ᄒ")+l1l1l1ll_l1_
			if type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᄓ"):
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄔ"),l1111l_l1_+l1lll11ll_l1_,url,255,l11l1l_l1_ (u"ࠬ࠭ᄕ"),l11l1l_l1_ (u"࠭ࠧᄖ"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᄗ"))
			elif type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᄘ") and l1l1111l1_l1_[-2]+l11l1l_l1_ (u"ࠩࡀࡁࠬᄙ") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᄚ"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᄛ"),l11l1l_l1_ (u"ࠬ࠭ᄜ"),l11lll1l_l1_,l1l1l1ll_l1_)
				l111lll_l1_ = url+l11l1l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬᄝ")+l11lll1l_l1_
				l1lllll11_l1_ = l11ll11ll_l1_(l111lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᄞ"),l1111l_l1_+l1lll11ll_l1_,l1lllll11_l1_,251,l11l1l_l1_ (u"ࠨࠩᄟ"),l11l1l_l1_ (u"ࠩࠪᄠ"),l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫᄡ"))
			else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄢ"),l1111l_l1_+l1lll11ll_l1_,url,254,l11l1l_l1_ (u"ࠬ࠭ᄣ"),l11l1l_l1_ (u"࠭ࠧᄤ"),l1ll11l1_l1_)
	return
l1l1111l1_l1_ = [l11l1l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᄥ"),l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᄦ"),l11l1l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᄧ")]
l11lllll1_l1_ = [l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᄨ"),l11l1l_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᄩ"),l11l1l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫᄪ"),l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄫ"),l11l1l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩᄬ"),l11l1l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩᄭ"),l11l1l_l1_ (u"ࠩࡵࡥࡹ࡫ࠧᄮ")]
def l11ll11ll_l1_(url):
	l111lll1l_l1_ = l11l1l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠵࠴࠷࠷࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩᄯ")
	url = url.replace(l11l1l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࠨᄰ"),l111lll1l_l1_)
	url = url.replace(l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭ᄱ"),l11l1l_l1_ (u"࠭ࠧᄲ"))
	if l111lll1l_l1_ not in url: url = url+l111lll1l_l1_
	url = url.replace(l11l1l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ᄳ"),l11l1l_l1_ (u"ࠨࡻࡨࡥࡷ࠭ᄴ"))
	url = url.replace(l11l1l_l1_ (u"ࠩࡂࡃࠬᄵ"),l11l1l_l1_ (u"ࠪࡃࠬᄶ"))
	url = url.replace(l11l1l_l1_ (u"ࠫࠫࠬࠧᄷ"),l11l1l_l1_ (u"ࠬࠬࠧᄸ"))
	url = url.replace(l11l1l_l1_ (u"࠭࠽࠾ࠩᄹ"),l11l1l_l1_ (u"ࠧ࠾ࠩᄺ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩᄻ"),l11l1l_l1_ (u"ࠩࠪᄼ"),l11l1l_l1_ (u"ࠪࠫᄽ"),l11l1l_l1_ (u"ࠫࡕࡘࡅࡑࡃࡕࡉࡤࡌࡉࡍࡖࡈࡖࡤࡌࡉࡏࡃࡏࡣ࡚ࡘࡌࠨᄾ"))
	return url
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᄿ"),l11l1l_l1_ (u"࠭ࠧᅀ"),filters,l11l1l_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧᅁ")+mode)
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᅂ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᅃ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧᅄ")					all filters (l11ll1ll_l1_ l1l1l11l_l1_ filter)
	filters = filters.strip(l11l1l_l1_ (u"ࠫࠫࠬࠧᅅ"))
	l1l111l1_l1_,l1ll111l_l1_ = {},l11l1l_l1_ (u"ࠬ࠭ᅆ")
	if l11l1l_l1_ (u"࠭࠽࠾ࠩᅇ") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠧࠧࠨࠪᅈ"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠨ࠿ࡀࠫᅉ"))
			l1l111l1_l1_[var] = value
	for key in l11lllll1_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠩ࠳ࠫᅊ")
		if l11l1l_l1_ (u"ࠪࠩࠬᅋ") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᅌ") and value!=l11l1l_l1_ (u"ࠬ࠶ࠧᅍ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"࠭ࠠࠬࠢࠪᅎ")+value
		elif mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᅏ") and value!=l11l1l_l1_ (u"ࠨ࠲ࠪᅐ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬᅑ")+key+l11l1l_l1_ (u"ࠪࡁࡂ࠭ᅒ")+value
		elif mode==l11l1l_l1_ (u"ࠫࡦࡲ࡬ࠨᅓ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨᅔ")+key+l11l1l_l1_ (u"࠭࠽࠾ࠩᅕ")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠧࠡ࠭ࠣࠫᅖ"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠩࠫᅗ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪᅘ"),l11l1l_l1_ (u"ࠪࠫᅙ"),l1ll111l_l1_,l11l1l_l1_ (u"ࠫࡔ࡛ࡔࠨᅚ"))
	return l1ll111l_l1_
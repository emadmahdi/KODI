# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ事")
def MAIN(mode,text=l11l1l_l1_ (u"ࠫࠬ二")):
	if   mode==  0: l11llllll11l_l1_(text)
	elif mode==  2: l1l111l1lll1_l1_(text)
	elif mode==  3: l1l11l111111_l1_()
	elif mode==  4: l1l11l11lll1_l1_(text)
	elif mode==  5: l11lllll11ll_l1_()
	elif mode==  6: l1l11l11l111_l1_()
	elif mode==  7: l1l1111llll1_l1_()
	elif mode==  8: l11llll1l1ll_l1_()
	elif mode==  9: l11llll1ll1l_l1_()
	elif mode==150: l1l111lllll1_l1_()
	elif mode==151: l11ll11ll111_l1_()
	elif mode==152: l1l1111l1l1l_l1_()
	elif mode==153: l1l11llll1ll_l1_()
	elif mode==154: l1l11l1l1ll1_l1_()
	elif mode==155: l11lllllllll_l1_()
	elif mode==156: l11ll11l1l1l_l1_()
	elif mode==157: l1l11l11l11l_l1_()
	elif mode==158: l1l1111ll111_l1_()
	elif mode==159: l1l111ll1111_l1_(True)
	elif mode==170: l11lll1ll11l_l1_()
	elif mode==171: l1l111l1l1l1_l1_()
	elif mode==172: l1l11lll1111_l1_()
	elif mode==173: l1l111l11lll_l1_(l11l1l_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ亍"),True)
	elif mode==174: l1l111l11lll_l1_(l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ于"),True)
	elif mode==175: l1l11111l11l_l1_()
	elif mode==176: l11lll11ll11_l1_()
	elif mode==177: l1l11l1l111l_l1_(l11l1l_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ亏"))
	elif mode==178: l1l11l1l111l_l1_(l11l1l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ亐"))
	elif mode==179: l1l11l1l111l_l1_(l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ云"))
	elif mode==190: l11lllll1lll_l1_()
	elif mode==191: l11ll1lll1ll_l1_()
	elif mode==192: l11lll11ll1l_l1_()
	elif mode==193: l1l111l1ll11_l1_()
	elif mode==194: l11lll11l111_l1_()
	elif mode==195: l11lll1lllll_l1_()
	elif mode==196: l1l1111ll1ll_l1_()
	elif mode==197: l11llll11l1l_l1_()
	elif mode==198: l1l111l1l111_l1_()
	elif mode==199: l11ll1ll1ll1_l1_()
	elif mode==340: l11ll1ll111l_l1_(text)
	elif mode==341: l1l11l1l11ll_l1_()
	elif mode==342: l1l111111l11_l1_()
	elif mode==343: l11llll11ll1_l1_()
	elif mode==344: l11ll1llll1l_l1_(True)
	elif mode==345: l1l1111lllll_l1_()
	elif mode==346: l1l1111ll1l1_l1_()
	elif mode==347: l1l11l11111l_l1_(True)
	elif mode==348: l1l111l1l1ll_l1_()
	elif mode==349: l1l111llll11_l1_(l1l11ll1l11l_l1_)
	elif mode==500: l11ll1llllll_l1_()
	elif mode==501: l11ll1l11lll_l1_()
	elif mode==502: l1l111l11ll1_l1_(l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ互"),True)
	elif mode==503: l1l111llll11_l1_(l11l111llll_l1_)
	elif mode==504: l1l111llll11_l1_(favoritesfile)
	elif mode==505: l1l111111lll_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l11l1l1111_l1_(text,l11l1l_l1_ (u"ࠫࠬ亓"),True)
	elif mode==508: l1l111l1l11l_l1_()
	elif mode==509: l1l11lll1ll1_l1_()
	return
def l1l11lll1ll1_l1_():
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬ࠭五"),l11l1l_l1_ (u"࠭ࠧ井"),l11l1l_l1_ (u"ࠧࠨ亖"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ亗"),l11l1l_l1_ (u"๊่ࠩࠥะั๋ัࠣๅ฾๊วࠡ็ึัࠥาๅ๋฻ࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦ࠮࠯ุ๋้ࠢำࠠอ็ํ฽๋ࠥไโษอࠤฬ๊ศา่ส้ัࠦวๅไา๎๊ฯࠠ࠯࠰่่ࠣ๐๋ࠠ฻๋ำࠥอไษำ้ห๊าࠠฦๆ์ࠤาอไสࠢสฺ่็ัࠡ࠰࠱ࠤ๏฿ๆ๋ࠢอะิ๐ฯࠡษ็ฬึ์วๆฮࠣ์ฯ฻แ๋ำ๊ࠤํ๎ึฺ้ࠣฬาอไสࠢส่๊฻ๆฺࠢส่ฯ๐ุ้ࠠ฼๋ฬࠦวๅ็หี๊าࠠภࠣࠤࠫ亘"))
	if l1ll11111l_l1_:
		l11ll1llll1l_l1_(False)
		l1ll111ll1_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ亙"),l11l1l_l1_ (u"ࠫࠬ亚"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ些"),l11l1l_l1_ (u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ฿วะࠢส่อืๆศ็ฯࠤสู๊้๊ࠡ฽๏ฯࠠศๆุๅึࠦ࠮࠯ฺ๋ࠢ฾๐ษࠡษ็ฺ้์ูࠨ亜"))
	return
def l1l11l1l1111_l1_(addon_id,function,l1ll_l1_):
	conn = sqlite3.connect(l1l111llll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l11lll1l1111_l1_ = l11l1l_l1_ (u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪ亝")
	else: l11lll1l1111_l1_ = l11l1l_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧ亞")
	cc.execute(l11l1l_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪ亟")+l11lll1l1111_l1_+l11l1l_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ亠")+addon_id+l11l1l_l1_ (u"ࠫࠧࠦ࠻ࠨ亡"))
	l11lllll11l1_l1_ = cc.fetchall()
	if l11lllll11l1_l1_ and function in [l11l1l_l1_ (u"ࠬ࠭亢"),l11l1l_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭亣")]:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ交"),l11l1l_l1_ (u"ࠨࠩ亥"),l11l1l_l1_ (u"ࠩࠪ亦"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭产"),l11l1l_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ亨")+addon_id+l11l1l_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭亩"))
		if l1ll11111l_l1_!=1: return
		cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬ亪")+l11lll1l1111_l1_+l11l1l_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ享")+addon_id+l11l1l_l1_ (u"ࠨࠤࠣ࠿ࠬ京"))
	elif function in [l11l1l_l1_ (u"ࠩࠪ亭"),l11l1l_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࠫ亮")]:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࠬ亯"),l11l1l_l1_ (u"ࠬ࠭亰"),l11l1l_l1_ (u"࠭ࠧ亱"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ亲"),l11l1l_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ亳")+addon_id+l11l1l_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭亴"))
		if l1ll11111l_l1_!=1: return
		if kodi_version<19: cc.execute(l11l1l_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ亵")+addon_id+l11l1l_l1_ (u"ࠫࠧ࠯ࠠ࠼ࠩ亶"))
		else: cc.execute(l11l1l_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬ亷")+addon_id+l11l1l_l1_ (u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭亸"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ亹"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ人"),l11l1l_l1_ (u"ࠩࠪ亻"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭亼"),l11l1l_l1_ (u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨ亽"))
	if function in [l11l1l_l1_ (u"ࠬ࠭亾"),l11l1l_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭亿")]: l1l111ll1111_l1_(l1ll_l1_)
	return
def l1l111111lll_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ什"),l11l1l_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ仁"))
	l1l11l1111ll_l1_ = l1l11l1l11l1_l1_(True)
	l1l111l111ll_l1_ = l11l1l_l1_ (u"ࠩ࡟ࡲࠬ仂")
	l1l11lllll1l_l1_ = l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ仃")
	l1l11lllll11_l1_ = l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ仄")
	for id,l1l1111l1lll_l1_,l1l11lll1l11_l1_,l11l1ll1lll_l1_,l11ll1l11l11_l1_,reason in reversed(l1l11l1111ll_l1_):
		if id==l11l1l_l1_ (u"ࠬ࠶ࠧ仅"):
			l11llll1l1l1_l1_,l1l11ll11111_l1_ = l11l1ll1lll_l1_.split(l11l1l_l1_ (u"࠭࡜࡯࠽࠾ࠫ仆"))
			continue
		if l1l111l111ll_l1_!=l11l1l_l1_ (u"ࠧ࡝ࡰࠪ仇"): l1l111l111ll_l1_ += l1l11lllll11_l1_
		l1ll111ll1l_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ仈")+id+l11l1l_l1_ (u"ࠩࠣ࠾ࠥ࠭仉")+l11l1l_l1_ (u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭今")+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭介")+l1l11lll1l11_l1_
		l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠬࡢ࡮࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆฯ์ฬฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ仌")+l11l1ll1lll_l1_
		l1lll11l111l_l1_ = l11l1l_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺวࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ仍")+l11ll1l11l11_l1_
		l1lll11l11l1_l1_ = l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟สุ่ฮศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ从")+reason
		l1l111l111ll_l1_ += l1ll111ll1l_l1_+l1ll111lll1_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ仏")+l1l11lllll1l_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ仐")+l1lll11l111l_l1_+l1lll11l11l1_l1_+l11l1l_l1_ (u"ࠪࡠࡳ࠭仑")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ仒"),l1l11ll11111_l1_,l1l111l111ll_l1_,l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭仓"))
	return
def l1l111llll11_l1_(file):
	if file==favoritesfile: l1l11111ll1l_l1_ = l11l1l_l1_ (u"࠭โ้ษษ้ࠥอไๆใู่ฮ࠭仔")
	elif file==l1l11ll1l11l_l1_: l1l11111ll1l_l1_ = l11l1l_l1_ (u"ࠧศๆิืฬฬไࠨ仕")
	elif file==l11l111llll_l1_: l1l11111ll1l_l1_ = l11l1l_l1_ (u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨ他")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ仗"),l11l1l_l1_ (u"ุ้ࠪำࠧ付"),l11l1l_l1_ (u"ࠫส฻ไศฯࠪ仙"),l11l1l_l1_ (u"ࠬิั้ฮࠪ仚"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ仛"),l11l1l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬ仜")+l1l11111ll1l_l1_+l11l1l_l1_ (u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨ仝"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ仞"),l11l1l_l1_ (u"ࠪࠫ仟"),l11l1l_l1_ (u"ࠫࠬ仠"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭仡"),l11l1l_l1_ (u"࠭ࠧ仢"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ代"),l11l1l_l1_ (u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭令")+l1l11111ll1l_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ以"),l11l1l_l1_ (u"ࠪࠫ仦"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ仧"),l11l1l_l1_ (u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬ仨")+l1l11111ll1l_l1_)
	return
def l11ll1l11lll_l1_():
	if kodi_version<18:
		message = l11l1l_l1_ (u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩ仩")+str(kodi_version)+l11l1l_l1_ (u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨ仪")
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ仫"),l11l1l_l1_ (u"ࠩࠪ们"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭仭"),message)
		return
	l11ll1ll1111_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ仮"))
	l1l1l1l1l11l_l1_ = l1l111111l1l_l1_([l11l1l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ仯")])
	l11l1l11111_l1_,l1l111lll11l_l1_,l11ll1l1111l_l1_,l1l111lll1l1_l1_,l1l111ll1ll1_l1_,l11ll1l1llll_l1_,l1l111lll111_l1_ = l1l1l1l1l11l_l1_[l11l1l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ仰")]
	if l11l1l11111_l1_ or l11l1l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭仱") not in str(l11ll1ll1111_l1_):
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ仲"),l11l1l_l1_ (u"ࠩࠪ仳"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭仴"),l11l1l_l1_ (u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ仵"))
		succeeded = l1l111l11ll1_l1_(l11l1l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ件"),True)
		if not succeeded: return
	l1l111ll11ll_l1_(True)
	return
	l11l1l_l1_ (u"ࠨࠢࠣࠌࠌࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠧࠪࠌࠌ࡭࡫ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࡀࡁࠬ࠻࠴࠵ࠩ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩࠍࠍࡪࡲࡩࡧࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࡃ࠽ࠨ࠷࠸࠹ࠬࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤฬ๊ี้ำࠪࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡ็ฯ๋ํ๊ษࠨࠌࠌ࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠱࠼ࠌࠍࠨࠦࡡ࡯ࡻࠣࡳࡹ࡮ࡥࡳࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎࠏࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭ࠧࠋࠋࠌࠧ࡮ࡳࡰࡰࡴࡷࠤࡸࡷ࡬ࡪࡶࡨ࠷ࠏࠏࠉࡤࡱࡱࡲࠥࡃࠠࡴࡳ࡯࡭ࡹ࡫࠳࠯ࡥࡲࡲࡳ࡫ࡣࡵࠪࡹ࡭ࡪࡽࡳࡠࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࠍࡨࡩࠠ࠾ࠢࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪࠌࠌࠍࡨࡵ࡮࡯࠰ࡷࡩࡽࡺ࡟ࡧࡣࡦࡸࡴࡸࡹࠡ࠿ࠣࡷࡹࡸࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠳࠼࠻࠶࠷࠷ࠡ࠽ࠪ࠭ࠏࠏࠉࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࡻ࡯ࡥࡸࠤ࡛ࠣࡍࡋࡒࡆࠢࡹ࡭ࡪࡽࡍࡰࡦࡨࠤࡂࠦ࠶࠷࠲࠻࠴ࠥࡁࠧࠪࠌࠌࠍࡨࡵ࡮࡯࠰ࡦࡳࡲࡳࡩࡵࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࡥ࡭࡫ࡩࠤࡨ࡮࡯ࡪࡥࡨࡁࡂ࠷࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨ࠷࠷࠸ࠬࠏࠣࠡࠤࡏ࡭ࡸࡺࠠࡆ࡯ࡤࡨࠧࠦࡶࡪࡧࡺࡸࡾࡶࡥࠋࠋࡨࡰ࡮࡬ࠠࡤࡪࡲ࡭ࡨ࡫࠽࠾࠴࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠡ࠿ࠣࠫ࠺࠻࠵ࠨࠋࠦࠤࠧࡍࡡ࡭࡮ࡨࡶࡾࡥࡅ࡮ࡣࡧࠦࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠭ࠬࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇ࠭ࠏࠏࠢࠣࠤ价")
def l1l111ll11ll_l1_(l1ll_l1_=True):
	l11ll1ll1111_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ仸"))
	if l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ仹") not in str(l11ll1ll1111_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ仺"),l11l1l_l1_ (u"ࠪࠫ任"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ仼"),l11l1l_l1_ (u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ份"))
		return
	l1l11l111ll1_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭仾"),l11l1l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭仿"),l11l1l_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭伀"),l11l1l_l1_ (u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪ企"))
	if not os.path.exists(l1l11l111ll1_l1_): return
	l11lll1lll1l_l1_ = open(l1l11l111ll1_l1_,l11l1l_l1_ (u"ࠪࡶࡧ࠭伂")).read()
	if kodi_version>18.99: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ伃"))
	l11ll1l11111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠮࡜ࡥ࠭࠯ࡠࡩ࠱ࠬ࡝ࡦ࠮࠭࠱࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ伄"),l11lll1lll1l_l1_,re.DOTALL)
	l11ll1ll1l11_l1_,l1l11llll11l_l1_ = l11ll1l11111_l1_[0]
	l1l11l1ll1l1_l1_ = l11l1l_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ伅")+l11ll1ll1l11_l1_+l11l1l_l1_ (u"ࠧ࠭ࠩ伆")+l1l11llll11l_l1_+l11l1l_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ伇")
	if l1ll_l1_:
		l1l11l1llll1_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡜ࡩࡦࡹࡰࡳࡩ࡫ࠧ伈"))
		if l1l11l1llll1_l1_==l11l1l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭伉"): l1l11l1l1lll_l1_ = l11l1l_l1_ (u"ࠫ็๎วว็ࠣห้้สศสฬࠫ伊")
		elif l1l11l1llll1_l1_==l11l1l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ伋"): l1l11l1l1lll_l1_ = l11l1l_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ伌")
		else: l1l11l1l1lll_l1_ = l11l1l_l1_ (u"ࠧใ๊สส๊ࠦรฯำ์ࠫ伍")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ伎"),l11l1l_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭伏"),l11l1l_l1_ (u"ࠪๆํอฦๆࠢส่่ะวษหࠪ伐"),l11l1l_l1_ (u"ࠫ็๎วว็ࠣห้฻่าࠩ休"),l11l1l_l1_ (u"ࠬอๆหࠢะห้๐วࠡฬึฮำีๅࠡࠩ伒")+l1l11l1l1lll_l1_,l11l1l_l1_ (u"࠭ว็ฬࠣห้ศๆࠡฬึฮำีๅࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๋๋ࠢีอࠠๆ฻้ห์ࠦว็ๅࠣฮุะื๋฻ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦศะๆสࠤ๊์ࠠใ๊สส๊ࠦวๅๅอหอฯࠠ࠯๋ࠢว๏฼วࠡฬึฮ฼๐ูࠡวํๆฬ็็ศࠢไ๎ࠥษ๊๊ࠡๅฮࠥะิศรࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤศิสาࠢส่ว์ࠠ็๊฼ࠤฬ๊โ้ษษ้ࠥอไห์ࠣฮึ๐ฯࠡลึฮำีวๆ้สࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ伓"))
		if choice==1: l1l11111l1ll_l1_ = l11l1l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ伔")
		elif choice==2: l1l11111l1ll_l1_ = l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ伕")
		else: l1l11111l1ll_l1_ = l11l1l_l1_ (u"ࠩࠪ伖")
	else:
		l1l11l1llll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭众"))
		if   l1l11l1llll1_l1_==l11l1l_l1_ (u"ࠫࠬ优"): choice = 0
		elif l1l11l1llll1_l1_==l11l1l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ伙"): choice = 1
		elif l1l11l1llll1_l1_==l11l1l_l1_ (u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ会"): choice = 2
		l1l11111l1ll_l1_ = l1l11l1llll1_l1_
	if   choice==0: l11lllll1l1l_l1_ = l11l1l_l1_ (u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫ伛")
	elif choice==1: l11lllll1l1l_l1_ = l11l1l_l1_ (u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬ伜")
	elif choice==2: l11lllll1l1l_l1_ = l11l1l_l1_ (u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭伝")
	else: return
	settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭伞"),l1l11111l1ll_l1_)
	l11lll111l1l_l1_ = l11l1l_l1_ (u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬ伟")+l11lllll1l1l_l1_+l11l1l_l1_ (u"ࠬ࠲ࠧ传")+l1l11llll11l_l1_+l11l1l_l1_ (u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ伡")
	l11ll1llll11_l1_ = l11lll1lll1l_l1_.replace(l1l11l1ll1l1_l1_,l11lll111l1l_l1_)
	if kodi_version>18.99: l11ll1llll11_l1_ = l11ll1llll11_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ伢"))
	open(l1l11l111ll1_l1_,l11l1l_l1_ (u"ࠨࡹࡥࠫ伣")).write(l11ll1llll11_l1_)
	LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ伤"),l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࡔ࡭࡬ࡲࠥࡊࡥࡧࡣࡸࡰࡹࠦࡖࡪࡧࡺࡷ࠿࡛ࠦࠡࠩ伥")+l11lllll1l1l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ伦"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡘࡥ࡭ࡱࡤࡨࡘࡱࡩ࡯ࠪࠬࠫ伧"))
	return
def l11ll1llllll_l1_():
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧ伨"),l11l1l_l1_ (u"ࠧไๆสࠫ伩"),l11l1l_l1_ (u"ࠨ่฼้ࠬ伪"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ伫"),l11l1l_l1_ (u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨ伬"))
	if l1ll11111l_l1_==1: l1l1111llll1_l1_()
	return
def l11llll1l1ll_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ伭"),l11l1l_l1_ (u"ࠬ࠭伮"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ伯"),l11l1l_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆࠪ估"))
	return
def l1l111l1l1ll_l1_():
	l1ll111ll1l_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ伱")
	l1ll111ll1l_l1_ += l11l1l_l1_ (u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨ伲")
	l1ll111ll1l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭伳")
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ伴")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩ伵")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ伶")
	message = l11l1l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭伷")+l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭伸")+l1ll111lll1_l1_
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ伹"),l11l1l_l1_ (u"ࠪࠫ伺"),message)
	return
def l1l1111ll1l1_l1_():
	#DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ伻"),l11l1l_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ似"))
	l1l11l1111ll_l1_ = l1l11l1l11l1_l1_(True)
	#if not l1l11l1111ll_l1_: return
	id,l1l1111l1lll_l1_,l1l11lll1l11_l1_,l11l1ll1lll_l1_,l11ll1l11l11_l1_,reason = l1l11l1111ll_l1_[0]
	l11llll1l1l1_l1_,l1l11ll11111_l1_ = l11l1ll1lll_l1_.split(l11l1l_l1_ (u"࠭࡜࡯࠽࠾ࠫ伽"))
	l1ll111lll1_l1_,l1lll11l111l_l1_,l1lll11l11l1_l1_ = l11ll1l11l11_l1_.split(l11l1l_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ伾"))
	l1l11ll11ll1_l1_ = l11ll1l11l1l_l1_
	l1l1111l1ll1_l1_ = True
	while l1l1111l1ll1_l1_:
		l11llll1lll1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࠩ伿"),l11l1l_l1_ (u"ࠩๅหห๋ษࠡษ็ฮอืูࠨ佀"),l11l1l_l1_ (u"ࠪࠫ佁"),l11l1l_l1_ (u"ࠫำื่อࠩ佂"),l11l1l_l1_ (u"๊ࠬล๋ไสๅࠥอไฦ฻็ห๋อสࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอ่๊ࠢࠥา็ศิๆࠫ佃"),l1ll111lll1_l1_)
		if l11llll1lll1_l1_==0:
			l1ll11111l_l1_ = DIALOG_OK(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭佄"),l11l1l_l1_ (u"ฺ๊ࠧาอࠬ佅"),l11l1l_l1_ (u"ࠨษ็ห฾ะัศุࠣ฽้๏ࠠๆสาวࠥอไฦ฻็ห๋อสࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪ但"),l1lll11l111l_l1_)
			#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ佇"),l11l1l_l1_ (u"ࠪ฽ํีษࠨ佈"),l11l1l_l1_ (u"ࠫฯ๎ึ๋ฯࠪ佉"),l11l1l_l1_ (u"ࠬอไศ฻อีฬ฼ฺࠠๆ์ࠤ๊ฮฯฤࠢส่ส฿ไศ่สฮࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧ佊"),l1lll11l111l_l1_)
			#if l1ll11111l_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ佋"),l11l1l_l1_ (u"ฺ๊ࠧาอࠬ佌"),l11l1l_l1_ (u"ࠨ็็หา฾วหࠩ位"),l1lll11l11l1_l1_)
		if l11llll1lll1_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ低"),l1l11ll11ll1_l1_,l1l11ll11ll1_l1_,l11l1l_l1_ (u"ࠪหุะฮะ็๋ࠣีอࠠศๆีี๊ࠥไฯำ๋ะ๋ࠥๆࠡษ็ืษอไࠡสา์๋ࠦลอษหอࠥอไิฦส่ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ล๋࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴวิฬัำ๊ํࠠๅๅํࠤฯ฿ัโࠢส่ั๎วษࠢสฺ่ำ๊ฮ࡞ࡱࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ住")+l1l11ll11ll1_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭佐"))
		if l11llll1lll1_l1_==2: l1l1111l1ll1_l1_ = False
	return
def l11ll1llll1l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ佑"),l11l1l_l1_ (u"࠭ࠧ佒"),l11l1l_l1_ (u"ࠧࠨ体"),l11l1l_l1_ (u"ࠨีวห้࠭佔"),l11l1l_l1_ (u"๊่ࠩࠥษๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠๆีะࠤํะีโ์ิࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡฯํฯࠥะู้ัࠣะ๊๐ูࠡษ็ษ฾ีวะษอࠤสู๊้๊ࠡ฽๏ฯࠠหอห๎ฯࠦวๅสิ๊ฬ๋ฬࠡมࠪ何"))
	else: l1ll11111l_l1_ = True
	if l1ll11111l_l1_:
		succeeded = True
		if os.path.exists(l11lll1111l1_l1_):
			try: os.remove(l11lll1111l1_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ佖"),l11l1l_l1_ (u"ࠫࠬ佗"),l11l1l_l1_ (u"ࠬ࠭佘"),l11l1l_l1_ (u"࠭สๆࠢห๊ัออࠡ็ึัࠥ๎สึใํี๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭余"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ佚"),l11l1l_l1_ (u"ࠨࠩ佛"),l11l1l_l1_ (u"ࠩࠪ作"),l11l1l_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ佝"))
	return
def l1l1111lllll_l1_():
	l11lllll1lll_l1_()
	l1l11ll1l1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭佞"))
	message = {}
	message[l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ佟")] = l11l1l_l1_ (u"࠭วๅๅสุࠥอไหๆๅหห๐๋ࠠ฻่่ࠬ你")
	message[l11l1l_l1_ (u"ࠧࡔࡖࡒࡔࠬ佡")] = l11l1l_l1_ (u"ࠨษ็็ฬฺࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ佢")
	message[l11l1l_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ佣")] = l11l1l_l1_ (u"ࠪ็ฬฺࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡ࠰ࠣࠫ佤")+str(l11ll1lll1l1_l1_/60)+l11l1l_l1_ (u"ࠫࠥีโ๋ไฬࠤๆ่ืࠨ佥")
	l11lll1ll111_l1_ = message[l1l11ll1l1l1_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠬ࠭佦"),l11l1l_l1_ (u"࠭ใศึࠣࠫ佧")+str(l11ll1lll1l1_l1_/60)+l11l1l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ佨"),l11l1l_l1_ (u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧ佩"),l11l1l_l1_ (u"ࠩศ๎็อแࠡๅส้้࠭佪"),l11lll1ll111_l1_,l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥอไไษืࠤฬ๊ะไ์ࠣห้ะไใษษ๎ࠥษๅࠡฬิ๎ิࠦล๋ไสๅࠥอไไษืࠤออไไษ่่ࠥษๅࠡฬิ๎ิࠦใศึࠣ฽๊ื็ࠡไุ๎ึࠦฬะษࠣรࠦ࠭佫"))
	if choice==0: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ佬")
	elif choice==1: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ佭")
	elif choice==2: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"࠭ࡓࡕࡑࡓࠫ佮")
	else: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠧࠨ佯")
	if l11lll1l1l1l_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ佰"),l11lll1l1l1l_l1_)
		l11lll11l1l1_l1_ = message[l11lll1l1l1l_l1_]
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ佱"),l11l1l_l1_ (u"ࠪࠫ佲"),l11l1l_l1_ (u"ࠫࠬ佳"),l11lll11l1l1_l1_)
	return
def l11llll11ll1_l1_():
	message = {}
	message[l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ佴")] = l11l1l_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔࠢส่ฯ๊โศศํࠤ๏฿ๅๅ࠼ࠣࠫ併")
	message[l11l1l_l1_ (u"ࠧࡂࡕࡎࠫ佶")] = l11l1l_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้࠽ࠤࠬ佷")
	message[l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ佸")] = l11l1l_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭佹")
	l1l11l11l1ll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ佺"))
	l1l11ll1l1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ佻"))
	l11lll1ll111_l1_ = message[l1l11ll1l1l1_l1_]+l1l11l11l1ll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"࠭ࠧ佼"),l11l1l_l1_ (u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬ佽"),l11l1l_l1_ (u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧ佾"),l11l1l_l1_ (u"ࠩศ๎็อแࠡๅส้้࠭使"),l11lll1ll111_l1_,l11l1l_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯ๊ࠦใ๊่ࠤอะอ้์็ࠤศูๅศรࠣห้๋่ศไ฼ࠤํอไิ์ิๅึอสࠡว็ํࠥษัใษ่ࠤํ฿ๆะࠢห฽฻ࠦวๅ่สืࠥ๐โ้็ࠣฬาาศ๊่๊ࠡ฾่ࠦฮุิࠤอ฿ึࠡษ็้ํอโฺࠢ࠱ࠤ้ะิ฻์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠠใ็ࠣฬฬิส๋ษิࠤฬ๊ำ๋ำไีࠥอไๆ่สือࠦร้ࠢๅ้ࠥฮล๋ไสๅ์ࠦศศๆๆห๊๊ࠧ侀"))
	if choice==0: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ侁")
	elif choice==1: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ侂")
	elif choice==2: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"࠭ࡓࡕࡑࡓࠫ侃")
	if choice in [0,1]:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ侄"),l11l1l_l1_ (u"ࠨีํีๆื࠺ࠡࠩ侅")+l11lll111l11_l1_[1],l11l1l_l1_ (u"ࠩึ๎ึ็ั࠻ࠢࠪ來")+l11lll111l11_l1_[0],l11l1l_l1_ (u"ࠪࠫ侇"),l11l1l_l1_ (u"ࠫศิสศำࠣื๏ืแาࠢࡇࡒࡘࠦวๅ็้หุฮࠠๅๅࠪ侈"))
		if l1ll11111l_l1_==1: l1l111ll1lll_l1_ = l11lll111l11_l1_[0]
		else: l1l111ll1lll_l1_ = l11lll111l11_l1_[1]
	elif choice==2: l1l111ll1lll_l1_ = l11l1l_l1_ (u"ࠬ࠭侉")
	else: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"࠭ࠧ侊")
	if l11lll1l1l1l_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ例"),l11lll1l1l1l_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ侌"),l1l111ll1lll_l1_)
		l11lll11l1l1_l1_ = message[l11lll1l1l1l_l1_]+l1l111ll1lll_l1_
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ侍"),l11l1l_l1_ (u"ࠪࠫ侎"),l11l1l_l1_ (u"ࠫࠬ侏"),l11lll11l1l1_l1_)
	return
def l1l111111l11_l1_():
	l1l11ll1l1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ侐"))
	message = {}
	message[l11l1l_l1_ (u"࠭ࡁࡖࡖࡒࠫ侑")] = l11l1l_l1_ (u"ࠧศๆหีํ้ำ๋ࠢส่ฯ๊โศศํࠤัอ็ำࠢ็่฾๋ไࠨ侒")
	message[l11l1l_l1_ (u"ࠨࡃࡖࡏࠬ侓")] = l11l1l_l1_ (u"ࠩส่อื่ไีํࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้ࠪ侔")
	message[l11l1l_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ侕")] = l11l1l_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭侖")
	l11lll1ll111_l1_ = message[l1l11ll1l1l1_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠬ࠭侗"),l11l1l_l1_ (u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ侘"),l11l1l_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭侙"),l11l1l_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ侚"),l11lll1ll111_l1_,l11l1l_l1_ (u"ࠩส่อื่ไีํࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏฿ๅๅ๋ࠢื๏฽ࠠษ์้ࠤัํวำๅࠣ์ฬ๊ล็ฬิ๊๏ะࠠ࠯๊ࠢ์ࠥ๐ำหๆ่ࠤ฼๊ศศฬๆࠤํ๐โ้็ࠣฬุำศ่ษࠣฬิ๊วࠡ็้็ࠥัๅࠡ์ห฽ะํวࠡๆๆࠤ࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎้ࠦรๆࠢศ๎็อแࠡษ็ฬึ๎ใิ์ࠣรࠬ供"))
	if choice==0: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ侜")
	elif choice==1: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ依")
	elif choice==2: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ侞")
	else: l11lll1l1l1l_l1_ = l11l1l_l1_ (u"࠭ࠧ侟")
	if l11lll1l1l1l_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ侠"),l11lll1l1l1l_l1_)
		l11lll11l1l1_l1_ = message[l11lll1l1l1l_l1_]
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ価"),l11l1l_l1_ (u"ࠩࠪ侢"),l11l1l_l1_ (u"ࠪࠫ侣"),l11lll11l1l1_l1_)
	return
def l1l111l1l11l_l1_():
	l11lll11111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ侤"))
	if l11lll11111l_l1_==l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ侥"): header = l11l1l_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅห๊ๅๅࠬ侦")
	else: header = l11l1l_l1_ (u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆใ฼่ࠬ侧")
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࠩ侨"),l11l1l_l1_ (u"ࠩศ๎็อแࠨ侩"),l11l1l_l1_ (u"ࠪฮๆ฿๊ๅࠩ侪"),header,l11l1l_l1_ (u"ࠫ็๎วว็ࠣห้ฮั็ษ่ะࠥ๐สๆࠢอัิ๐ห่ษࠣวํะ่ๆษอ๎่๐วࠡส฼ำࠥ࠷࠶ࠡีส฽ฮࠦๅ็ࠢฦ์้ࠦริฬัำฬ๋ࠠ࠯࠰ࠣ์ส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣ๎ษี๊ࠡว็ํࠥะอะ์ฮ๋ฬࠦแ๋ࠢๆ่๋ࠥัสࠢํฮ๊ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤํํะศࠢํือฮࠠษูษࠤๆ๐ࠠโฬะࠤ็๎วว็ࠣห้ฮั็ษ่ะࡡࡴ࡜࡯้็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧ侫"))
	if l1ll11111l_l1_==-1: return
	elif l1ll11111l_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡲࡺࡹ࡟ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭侬"),l11l1l_l1_ (u"࠭ࠧ侭"))
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ侮"),l11l1l_l1_ (u"ࠨࠩ侯"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ侰"),l11l1l_l1_ (u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬ侱"))
	else:
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ侲"),l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ侳"))
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ侴"),l11l1l_l1_ (u"ࠧࠨ侵"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ侶"),l11l1l_l1_ (u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫ侷"))
	return
def l11llllll11l_l1_(text):
	if text!=l11l1l_l1_ (u"ࠪࠫ侸"):
		text = l1l1l111lll_l1_(text)
		text = text.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ侹")).encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ侺"))
		l1l1l11l1l1_l1_ = 10103
		l1l1l11l111_l1_ = xbmcgui.l1l1l111111_l1_(l1l1l11l1l1_l1_)
		l1l1l11l111_l1_.getControl(311).l1l1l11ll1l_l1_(text)
		#l1l11111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡑࡥࡺࡤࡲࡥࡷࡪ࠲࠳࠰ࡻࡱࡱ࠭侻"), xbmcaddon.Addon().getAddonInfo(l11l1l_l1_ (u"ࠧࡱࡣࡷ࡬ࠬ侼")).decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭侽")),l11l1l_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ侾"),l11l1l_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ便"))
		#l1l11111l1l1_l1_.show()
		#l1l11111l1l1_l1_.getControl(99991).setPosition(0,0)
		#l1l11111l1l1_l1_.getControl(311).l1l1l11ll1l_l1_(text)
		#l1l11111l1l1_l1_.getControl(5).l11ll11ll1l1_l1_(l1l11l111lll_l1_)
		#width = xbmcgui.l11lll1l11l1_l1_()
		#l1l11l111l1l_l1_ = xbmcgui.l1l1111l1l11_l1_()
		#resolution = (0.0+width)/l1l11l111l1l_l1_
		#l1l11111l1l1_l1_.getControl(5).l1l111l1llll_l1_(width-180)
		#l1l11111l1l1_l1_.getControl(5).setHeight(l1l11l111l1l_l1_-180)
		#l1l11111l1l1_l1_.doModal()
		#del l1l11111l1l1_l1_
	return
l11ll1lll111_l1_ = [
			 l11l1l_l1_ (u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࠨࠩࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤ俀")
			,l11l1l_l1_ (u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨ俁")
			,l11l1l_l1_ (u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨ係")
			,l11l1l_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩ促")
			,l11l1l_l1_ (u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩ俄")
			,l11l1l_l1_ (u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫ俅")
			,l11l1l_l1_ (u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠥࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨ俆")
			,l11l1l_l1_ (u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧ俇")
			,l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡂ࠶ࠦࡵࡧࡻࡸࡂ࠭俈")
			,l11l1l_l1_ (u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧ俉")
			,l11l1l_l1_ (u"ࠧ࡟ࡠࡡࡢࡣ࠭俊")
			,l11l1l_l1_ (u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭俋")
			]
def l11llll1l11l_l1_(line):
	if l11l1l_l1_ (u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧ俌") in line and l11l1l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ俍") in line: return True
	for text in l11ll1lll111_l1_:
		if text in line: return True
	return False
def l11ll11lll11_l1_(data):
	data = data.replace(l11l1l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ俎")+l11l1l_l1_ (u"ࠬࠦࠧ俏")*51+l11l1l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ俐"),l11l1l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ俑"))
	data = data.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ俒")+l11l1l_l1_ (u"ࠩࠣࠫ俓")*51+l11l1l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ俔"),l11l1l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ俕"))
	data = data.replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ俖")+l11l1l_l1_ (u"࠭ࠠࠨ俗")*51+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ俘"),l11l1l_l1_ (u"ࠨ࡞ࡱࠫ俙"))
	#data = data.replace(l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴࠴ࡇ࡮ࡥࡴࡲ࡭ࡩ࠵ࡤࡢࡶࡤ࠳ࡴࡸࡧ࠯ࡺࡥࡱࡨ࠴࡫ࡰࡦ࡬࠳࡫࡯࡬ࡦࡵ࠲࠲ࡰࡵࡤࡪ࠱ࡤࡨࡩࡵ࡮ࡴ࠱ࠪ俚"),l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠨ俛"))
	data = data.replace(l11l1l_l1_ (u"ࠫࠥࡂࡧࡦࡰࡨࡶࡦࡲ࠾࠻ࠢࠪ俜"),l11l1l_l1_ (u"ࠬࡀࠠࠨ保"))
	l11ll1111_l1_ = l11l1l_l1_ (u"࠭ࠧ俞")
	for line in data.splitlines():
		delete = re.findall(l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠥࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠩࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭俟"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11l1l_l1_ (u"ࠨࠩ俠"))
		l11ll1111_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ信")+line
	#WRITE_THIS(l11l1l_l1_ (u"ࠪࠫ俢"),l11ll1111_l1_)
	return l11ll1111_l1_
def l11ll1ll111l_l1_(l1l11111ll11_l1_):
	if l11l1l_l1_ (u"ࠫࡔࡒࡄࠨ俣") in l1l11111ll11_l1_:
		l1l11l11ll11_l1_ = l11ll1l1l1l1_l1_
		header = l11l1l_l1_ (u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣรࠬ俤")
	else:
		l1l11l11ll11_l1_ = l1l11l1l1l11_l1_
		header = l11l1l_l1_ (u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭俥")
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ俦"),l11l1l_l1_ (u"ࠨࠩ俧"),l11l1l_l1_ (u"ࠩࠪ俨"),header,l11l1l_l1_ (u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭俩"))
	if l1ll11111l_l1_!=1: return
	l11ll1l111l1_l1_,counts = [],0
	size,count = l1l1l1111l_l1_(l1l11l11ll11_l1_)
	#size = os.path.getsize(l1l11l11ll11_l1_)
	file = open(l1l11l11ll11_l1_,l11l1l_l1_ (u"ࠫࡷࡨࠧ俪"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ俫"))
	data = l11ll11lll11_l1_(data)
	lines = data.split(l11l1l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ俬"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ俭"))
		#if line.strip(l11l1l_l1_ (u"ࠨࠢࠪ修"))==l11l1l_l1_ (u"ࠩࠪ俯"): continue
		ignore = l11llll1l11l_l1_(line)
		if ignore: continue
		line = line.replace(l11l1l_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡࡡࠪ俰"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ俱"))
		line = line.replace(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠬ俲"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࡇࡕࡖࡔࡘ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ俳"))
		l11ll1ll1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠩࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ俴"),line,re.DOTALL)
		l1l11111llll_l1_ = l11l1l_l1_ (u"ࠨࠩ俵")
		if l11ll1ll1lll_l1_:
			line = line.replace(l11ll1ll1lll_l1_[0][0],l11l1l_l1_ (u"ࠩࠪ俶")).replace(l11ll1ll1lll_l1_[0][2],l11l1l_l1_ (u"ࠪࠫ俷"))
			l1l11111llll_l1_ = l11ll1ll1lll_l1_[0][1]
		else:
			l11ll1ll1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ俸"),line,re.DOTALL)
			if l11ll1ll1lll_l1_:
				line = line.replace(l11ll1ll1lll_l1_[0][1],l11l1l_l1_ (u"ࠬ࠭俹"))
				l1l11111llll_l1_ = l11ll1ll1lll_l1_[0][0]
		if l1l11111llll_l1_: line = line.replace(l1l11111llll_l1_,l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ俺")+l1l11111llll_l1_+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ俻"))
		l11ll1l111l1_l1_.append(line)
		if len(str(l11ll1l111l1_l1_))>50100: break
	l11ll1l111l1_l1_ = reversed(l11ll1l111l1_l1_)
	l1l11l111lll_l1_ = l11l1l_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭俼").join(l11ll1l111l1_l1_)
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ俽"),l11l1l_l1_ (u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ俾"),l1l11l111lll_l1_,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ俿"))
	return
def l11ll1ll1ll1_l1_():
	l1l11l11ll1l_l1_ = open(l1l1111l111l_l1_,l11l1l_l1_ (u"ࠬࡸࡢࠨ倀")).read()
	if kodi_version>18.99: l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ倁"))
	l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.replace(l11l1l_l1_ (u"ࠧ࡝ࡶࠪ倂"),l11l1l_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪ倃"))
	l1l1l1l1l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ倄"),l1l11l11ll1l_l1_,re.DOTALL)
	for line in l1l1l1l1l11l_l1_:
		l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.replace(line,l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭倅")+line+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倆"))
	DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭倇"),l1l11l11ll1l_l1_)
	return
def l1l111l1l111_l1_():
	l1ll111ll1l_l1_ = l11l1l_l1_ (u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ倈")
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ倉")
	l1lll11l111l_l1_ = l11l1l_l1_ (u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ倊")
	message = l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ個")+l1ll111lll1_l1_+l11l1l_l1_ (u"ࠪࠤ࠳ࠦࠧ倌")+l1lll11l111l_l1_
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ倍"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ倎"),message,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ倏"))
	return
def l1llll1ll1l1_l1_(l1ll11ll1l11_l1_,message,l1ll_l1_=True,url=l11l1l_l1_ (u"ࠧࠨ倐"),source=l11l1l_l1_ (u"ࠨࠩ們"),text=l11l1l_l1_ (u"ࠩࠪ倒"),l1llll11l11l_l1_=l11l1l_l1_ (u"ࠪࠫ倓")):
	if l11l1l_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ倔") in text: l1l1l1l111ll_l1_ = True
	else: l1l1l1l111ll_l1_ = False
	l11ll11l1ll1_l1_ = True
	if not l11llll111ll_l1_(l11l1l_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭倕")):
		if l1ll_l1_:
			#if message.count(l11l1l_l1_ (u"࠭࡜࡝ࡰࠪ倖"))>1: l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭倗")
			#else: l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ倘")
			l11lll1111ll_l1_ = (l11l1l_l1_ (u"ࠩสุ่฽ั࠻ࠩ候") in message and l11l1l_l1_ (u"ࠪห้๋ใศ่࠽ࠫ倚") in message and l11l1l_l1_ (u"ࠫฬ๊ๅๅใ࠽ࠫ倛") in message and l11l1l_l1_ (u"ࠬอไฯูฦࠫ倜") in message and l11l1l_l1_ (u"࠭วๅ็ุำึࡀࠧ倝") in message)
			if not l11lll1111ll_l1_: l11ll11l1ll1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ倞"),l11l1l_l1_ (u"ࠨࠩ借"),l11l1l_l1_ (u"ࠩࠪ倠"),l11l1l_l1_ (u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧ倡"),message.replace(l11l1l_l1_ (u"ࠫࡡࡢ࡮ࠨ倢"),l11l1l_l1_ (u"ࠬࡢ࡮ࠨ倣")))
	elif l1ll_l1_:
		message = l11l1l_l1_ (u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭値")
		l1l11ll1ll1l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ倥"),l11l1l_l1_ (u"ࠨࠩ倦"),l11l1l_l1_ (u"ࠩࠪ倧"),l11l1l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ倨")+l11l1l_l1_ (u"ࠫࠥࠦ࠱࠰࠷ࠪ倩"),l11l1l_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ倪"))
		l1l11ll1ll11_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭倫"),l11l1l_l1_ (u"ࠧࠨ倬"),l11l1l_l1_ (u"ࠨࠩ倭"),l11l1l_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ倮")+l11l1l_l1_ (u"ࠪࠤࠥ࠸࠯࠶ࠩ倯"),l11l1l_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ倰"))
		l1l11ll1l1ll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ倱"),l11l1l_l1_ (u"࠭ࠧ倲"),l11l1l_l1_ (u"ࠧࠨ倳"),l11l1l_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ倴")+l11l1l_l1_ (u"ࠩࠣࠤ࠸࠵࠵ࠨ倵"),l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ倶"))
		l1l11lll111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ倷"),l11l1l_l1_ (u"ࠬ࠭倸"),l11l1l_l1_ (u"࠭ࠧ倹"),l11l1l_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ债")+l11l1l_l1_ (u"ࠨࠢࠣ࠸࠴࠻ࠧ倻"),l11l1l_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ值"))
		l11ll11l1ll1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ倽"),l11l1l_l1_ (u"ࠫࠬ倾"),l11l1l_l1_ (u"ࠬ࠭倿"),l11l1l_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭偀")+l11l1l_l1_ (u"ࠧࠡࠢ࠸࠳࠺࠭偁"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭偂"))
	if l11ll11l1ll1_l1_!=1:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ偃"),l11l1l_l1_ (u"ࠪࠫ偄"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ偅"),l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ偆"))
		return False
	l1l11lll11l1_l1_ = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠧ假") )
	message += l11l1l_l1_ (u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭偈")+addon_version+l11l1l_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ偉")
	message += l11l1l_l1_ (u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪ偊")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ偋")+kodi_release+l11l1l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ偌")
	message += l11l1l_l1_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪ偍")+l1l11lll11l1_l1_
	#l1l1111111ll_l1_ = l11ll11llll1_l1_(l11l1l_l1_ (u"࠭࠷࠷࠰࠹࠹࠳࠷࠳࠹࠰࠵࠷࠵࠭偎"))
	l11llll1llll_l1_ = l11ll11llll1_l1_()
	l11llll1llll_l1_ = QUOTE(l11llll1llll_l1_)
	if l11llll1llll_l1_: message += l11l1l_l1_ (u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩ偏")+l11llll1llll_l1_
	if url: message += l11l1l_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬ偐")+url
	if source: message += l11l1l_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩ偑")+source
	message += l11l1l_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ偒")
	if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠫัอั๋ࠢส่สืำศๆࠪ偓"),l11l1l_l1_ (u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧ偔"))
	if l1llll11l11l_l1_:
		l1l11l111lll_l1_ = l1llll11l11l_l1_
		if kodi_version>18.99: l1l11l111lll_l1_ = l1l11l111lll_l1_.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ偕"))
		l1l11l111lll_l1_ = base64.b64encode(l1l11l111lll_l1_)
	elif l1l1l1l111ll_l1_:
		if l11l1l_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧ偖") in text: l1l11ll1l111_l1_ = l11ll1l1l1l1_l1_
		else: l1l11ll1l111_l1_ = l1l11l1l1l11_l1_
		if not os.path.exists(l1l11ll1l111_l1_):
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ偗"),l11l1l_l1_ (u"ࠩࠪ偘"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭偙"),l11l1l_l1_ (u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩ做"))
			return False
		l11ll1l111l1_l1_,counts = [],0
		size,count = l1l1l1111l_l1_(l1l11ll1l111_l1_)
		#size = os.path.getsize(l1l11ll1l111_l1_)
		file = open(l1l11ll1l111_l1_,l11l1l_l1_ (u"ࠬࡸࡢࠨ偛"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ停"))
		data = l11ll11lll11_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ偝"))
			ignore = l11llll1l11l_l1_(line)
			if ignore: continue
			l11ll1ll1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠭ࠪࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ偞"),line,re.DOTALL)
			if l11ll1ll1lll_l1_:
				line = line.replace(l11ll1ll1lll_l1_[0][0],l11l1l_l1_ (u"ࠩࠪ偟")).replace(l11ll1ll1lll_l1_[0][2],l11l1l_l1_ (u"ࠪࠫ偠"))
			else:
				l11ll1ll1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ偡"),line,re.DOTALL)
				if l11ll1ll1lll_l1_: line = line.replace(l11ll1ll1lll_l1_[0][1],l11l1l_l1_ (u"ࠬ࠭偢"))
			l11ll1l111l1_l1_.append(line)
			if len(str(l11ll1l111l1_l1_))>121000: break
		l11ll1l111l1_l1_ = reversed(l11ll1l111l1_l1_)
		l1l11l111lll_l1_ = l11l1l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ偣").join(l11ll1l111l1_l1_)
		l1l11l111lll_l1_ = l1l11l111lll_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ偤"))
		l1l11l111lll_l1_ = base64.b64encode(l1l11l111lll_l1_)
	else: l1l11l111lll_l1_ = l11l1l_l1_ (u"ࠨࠩ健")
	url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ偦")][2]
	payload = {l11l1l_l1_ (u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫ偧"):l1ll11ll1l11_l1_,l11l1l_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ偨"):message,l11l1l_l1_ (u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭偩"):l1l11l111lll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ偪"),url,payload,l11l1l_l1_ (u"ࠧࠨ偫"),l11l1l_l1_ (u"ࠨࠩ偬"),l11l1l_l1_ (u"ࠩࠪ偭"),l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭偮"))
	#succeeded = response.succeeded
	html = response.content
	if l11l1l_l1_ (u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭偯") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			l1lllll1_l1_(l11l1l_l1_ (u"ࠬะๅࠡษ็ษึูวๅࠩ偰"),l11l1l_l1_ (u"࠭ศ็ฮสัࠬ偱"))
			DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ偲"),l11l1l_l1_ (u"ࠨࠩ偳"),l11l1l_l1_ (u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨ側"),l11l1l_l1_ (u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬ偵"))
		else:
			l1lllll1_l1_(l11l1l_l1_ (u"้๊ࠫริใࠪ偶"),l11l1l_l1_ (u"ࠬ็ิๅࠢไ๎ࠥอไฦำึห้࠭偷"))
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ偸"),l11l1l_l1_ (u"ࠧࠨ偹"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ偺"),l11l1l_l1_ (u"ࠩั฻ศ่ࠦโึ็ࠤๆ๐ࠠฦำึห้ࠦวๅำึห้ฯࠧ偻"))
	return succeeded
def l11ll11ll111_l1_():
	l1ll111ll1l_l1_ = l11l1l_l1_ (u"ࠪ࠵࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡰࡳࡱࡥࡰࡪࡳࠠࡸ࡫ࡷ࡬ࠥࡇࡲࡢࡤ࡬ࡧࠥࡺࡥࡹࡶࠣࡸ࡭࡫࡮ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ偼")
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠫ࠶࠴ࠠࠡࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦวๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭偽")
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭偾"),l11l1l_l1_ (u"࠭ࠧ偿"),l11l1l_l1_ (u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ傀"),l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭傁")+l1ll111lll1_l1_)
	l1ll111ll1l_l1_ = l11l1l_l1_ (u"ࠩ࠵࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡦࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠨ傂")
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠪ࠶࠳ࠦࠠࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆ่ๅࠡสอ฾๏๐ัࠡษ็ะ้ีࠠฬ็ࠣๆ๊ࠦศห฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥอไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪ傃")
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ傄"),l11l1l_l1_ (u"ࠬ࠭傅"),l11l1l_l1_ (u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬ傆"),l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ傇")+l1ll111lll1_l1_)
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ傈"),l11l1l_l1_ (u"ࠩࠪ傉"),l11l1l_l1_ (u"ࠪࠫ傊"),l11l1l_l1_ (u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ傋"),l11l1l_l1_ (u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩ傌")+l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ傍")+l11l1l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧ傎"))
	if l1ll11111l_l1_==1: l1l11l11l111_l1_()
	return
def l1l11llll1ll_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ傏"),l11l1l_l1_ (u"ࠩࠪ傐"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭傑"),l11l1l_l1_ (u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪ傒"))
	return
def l1l11l1l1ll1_l1_():
	message = l11l1l_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬ傓")
	DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ傔"),l11l1l_l1_ (u"ࠧࠨ傕"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ傖"),message)
	return
def l11lllllllll_l1_():
	message = l11l1l_l1_ (u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭傗")
	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ傘"),l11l1l_l1_ (u"ࠫࠬ備"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ傚"),message)
	return
def l11ll11l1l1l_l1_():
	message = l11l1l_l1_ (u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪ傛")
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ傜"),l11l1l_l1_ (u"ࠨࠩ傝"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ傞"),l11l1l_l1_ (u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬ傟"),message)
	return
def l1l11l11l11l_l1_():
	message = l11l1l_l1_ (u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩ傠")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ傡"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ傢"),message,l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ傣"))
	return
def l1l1111ll111_l1_():
	l1ll111ll1l_l1_ = l11l1l_l1_ (u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩ傤")
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫ傥")
	l1lll11l111l_l1_ = l11l1l_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ傦")
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ傧"),l11l1l_l1_ (u"ࠬ࠭储"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ傩"),l1ll111ll1l_l1_,l1ll111lll1_l1_,l1lll11l111l_l1_)
	return
def l11lllll1lll_l1_():
	l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠧศๆๆหูࠦ็้่ࠢาื์ࠠๆฦๅฮ๊ࠥไๆ฻็์๊อสࠡ์ึฮำีๅ่ࠢส่อืๆศ็ฯࠤ้ิา็ุࠢๅาอสࠡษ็ษ๋ะั็์อࠤํื่ศสฺࠤฬ๊แ๋ัํ์์อสࠡๆ็์ฺ๎ไࠡว็๎์อࠠษีิ฽ฮ่ࠦษั๋๊ࠥหๆหำ้๎ฯ่ࠦศๆหี๋อๅอࠢํุ้ำ็ศࠢอ่็อฦ๋ษࠣฬ฾ีࠠศ่อ๋ฬวฺࠠ็ิ๋ฬ่ࠦฤ์ูหࠥ฿ๆะࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะࠥ๐ำหะาู้ࠥศฺหࠣว๋๎วฺࠢ็฽๊ืࠠศๆๆหูࠦ࠺ࠨ傪")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭傫") + l11l1l_l1_ (u"ࠩ࠴࠲ࠥัวษฬ่้ࠣ฻แฮษอࠤฬ๊ส๋่ࠢ฽ึ๎แࠡล้๋ฬࠦไศࠢอฮ฿๐ั่๊ࠡหห๐ว๊่ࠡำฯํࠠࠨ催") + str(PERMANENT_CACHE/60/60/24/30) + l11l1l_l1_ (u"ࠪࠤูํัࠨ傭")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠫࡡࡴࠧ傮") + l11l1l_l1_ (u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ傯") + str(VERYLONG_CACHE/60/60/24) + l11l1l_l1_ (u"๋๊่࠭ࠠࠫ傰")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ傱") + l11l1l_l1_ (u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ傲") + str(l1llll1l_l1_/60/60/24) + l11l1l_l1_ (u"ࠩࠣ๎ํ๋ࠧ傳")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠪࡠࡳ࠭傴") + l11l1l_l1_ (u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭債") + str(REGULAR_CACHE/60/60) + l11l1l_l1_ (u"ࠬࠦำศ฻ฬࠫ傶")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"࠭࡜࡯ࠩ傷") + l11l1l_l1_ (u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫ傸") + str(l1ll1ll11_l1_/60/60) + l11l1l_l1_ (u"ࠨࠢึห฾ฯࠧ傹")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ傺") + l11l1l_l1_ (u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫ傻") + str(l1111lll1l1_l1_/60) + l11l1l_l1_ (u"ࠫࠥีโ๋ไฬࠫ傼")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ࠨ傽") + l11l1l_l1_ (u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨ傾") + str(NO_CACHE) + l11l1l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ傿")
	l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭僀") + l11l1l_l1_ (u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭僁") + str(REGULAR_CACHE/60/60) + l11l1l_l1_ (u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫ僂") + str(l1llll1l_l1_/60/60/24) + l11l1l_l1_ (u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪ僃") + str(l1ll1ll11_l1_/60/60) + l11l1l_l1_ (u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩ僄") + str(l1111lll1l1_l1_/60) + l11l1l_l1_ (u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨ僅") + str(NO_CACHE) + l11l1l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ僆")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ僇"),l11l1l_l1_ (u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧ僈"),l1ll111lll1_l1_,l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭僉"))
	return
def l11ll1lll1ll_l1_():
	message = l11l1l_l1_ (u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧ僊")
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭僋"),l11l1l_l1_ (u"࠭ࠧ僌"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ働"),message)
	return
def l11lll11ll1l_l1_():
	message = l11l1l_l1_ (u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩ僎")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ像"),l11l1l_l1_ (u"ࠪࠫ僐"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ僑"),message)
	return
def l1l111l1ll11_l1_():
	message = l11l1l_l1_ (u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩ僒")
	DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ僓"),l11l1l_l1_ (u"ࠧࠨ僔"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ僕"),message)
	return
def l11lll11l111_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ僖"),l11l1l_l1_ (u"ࠪࠫ僗"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ僘"),l11l1l_l1_ (u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ僙"))
	l1l111l11lll_l1_(l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭僚"),True)
	return
def l11lll1lllll_l1_():
	message  = l11l1l_l1_ (u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩ僛")
	#message += l11l1l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๎็ัษࠣห้฿ววไ๋ࠣํࠦࡲࡦࡅࡄࡔ࡙ࡉࡈࡂࠢส่ำอีࠡสืี่ฯࠠอ๊ฯ่ࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ僜")
	#message += l11l1l_l1_ (u"๋ࠩห้ึ๊ࠡื้฽ฯํࠠีำๆอࠥา่อๆࠣาฺ๐ีศࠢ็้๋฿ࠠษำส้ัࠦๅฬๆࠣ็ํี๊ࠡ็้ࠤฯ฻แฮࠢส่ส์สา่อࠫ僝")
	message += l11l1l_l1_ (u"ࠪࠤํ์ส๋ฮฬࠤ้ํะศࠢส่฾อฦใࠢไห๋ํࠠหไิ๎ออࠠอ็ํ฽๋ࠥำหะา้๏ࠦศา่ส้ัࠦใ้ัํࠤ้อ๋ࠠีอ฻๏฿่็ࠢส่ิิ่ๅࠢ็ะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢะฮ๎ࠦๅฺࠢสืฯิฯศ็ࠪ僞")
	message += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞โࠣࠤ࡛ࡖࡎࠡࠢฦ์ࠥࠦࡐࡳࡱࡻࡽࠥࠦร้ࠢࠣࡈࡓ࡙ࠠࠡล๋ࠤศ๐ࠠฮๆࠣฬุ๐ืࠡฤัีࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ僟")
	message += l11l1l_l1_ (u"ࠬࡢ࡮ๅษ้ࠤ์ึวࠡๆ้ࠤ๏ำไࠡษ็ู้้ไส๋ࠢษ๋๋วࠡใๅ฻ู๊ࠥใ๊่ࠤอหีๅษะࠤอ฿ึࠡษ็้ํอโฺ๋ࠢษ฾อโส่ࠢ์ฬู่ࠡษัี๎ࠦใศ่อࠤฯ฿ๅๅࠢึหอ่วࠡสา์๋ࠦๅีษๆ่ࠬ僠")
	l11ll111l1_l1_(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ僡"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ僢"),message,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ僣"))
	message = l11l1l_l1_ (u"ࠩส่๊๎วใ฻ࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬ僤")
	message += l11l1l_l1_ (u"ࠪࡠࡳ࠭僥")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡡ࡬ࡱࡤࡱࠥࠦࡥࡨࡻࡥࡩࡸࡺࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠥࠦ࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠢࠣࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠢࠣࡷ࡭ࡧࡨࡪࡦ࠷ࡹࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭僦")
	message += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ僧")+l11l1l_l1_ (u"࠭วๅั๋่ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ僨")
	message += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ僩")+l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠฺ้ืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭僪")
	message += l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ僫")+l11l1l_l1_ (u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫ僬")
	message += l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣวาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ僭")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ僮"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ僯"),message,l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ僰"))
	#l1l111l1lll1_l1_(l11l1l_l1_ (u"ࠨࡋࡶࡔࡷࡵࡢ࡭ࡧࡰࡁࡋࡧ࡬ࡴࡧࠪ僱"))
	#message = l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ僲")+l11l1l_l1_ (u"ࠪ์้่ฯࠡๆสั฽์วࠡษํฺฬࠦร็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤฯิสๅใࠣฬฬิสๅษไࠤฬ๊ศๅัࠣ์ฯิสๅใࠣฬฬิสๅษไࠤูืใสࠢส่ฬ์สา่ํฮࠥ็๊ࠡา็็ࠥอไษๆาࠤํํะศ่ࠢ฽๋อ็ࠡษ้๋ࠥำส๊ࠢ็์ࠥะๅࠡษึฮำีวๆ࡙ࠢࡔࡓࠦร้ࠢࡓࡶࡴࡾࡹࠡล๋ࠤศ๐้ࠠีํ่ฮࠦวฯำ์ࠤๆอๆࠡษ็้ํอโฺࠢส่๊฿วใหࠣืํ็ࠠหะอ่ๆ่ࠦๅๅ้๋ฬࠦไ็ࠢอ฽๊๊ࠠอ็ํ฽์อࠧ僳")
	#message += l11l1l_l1_ (u"้ࠫำไࠡษ็ู้้ไสࠢๅ้ࠥฮูๆๆํ๊࠿ࠦࠠࠡࠢส่ศ๎ไ࠻ࠢฦีุ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠࠩ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯ࠭ࠥ๎วไฬหࠤ๊฿็ࠡษึ้ࠥฮไะๅࠣ์ฬูๅࠡึิ็ฮࠦวๅว้ฮึ์๊ห๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠧ僴")
	#message += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ僵")+l11l1l_l1_ (u"่࠭ศๆฮห๋๐࠺ࠡฮิฬࠥอำหะาห๊ࠦࡖࡑࡐࠣ์฾์ฯࠡษ็ฬ฾฼ࠠใัࠣฮาะวอࠢไๆ฼ࠦส฻์ํีࠥࡊࡎࡔ๋ࠢห้ษอิ่ࠣว๋๊ࠦไ๊้ࠤๆ๐ࠠษๆาࠤฬิัࠡ฻็้ฬࠦว็ࠢสืฯิฯศ็ࠣࡔࡷࡵࡸࡺࠢๅำࠥ๐อๅุ่่๊ࠢษࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦๅๅ้ࠤ้๐ำࠡใํࠤัฺ๋๊ࠢส่ิ๎ไࠨ僶")
	#DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠧๆึๆ่ฮูࠦ็ัࠣฬ฾฼ࠠศๆ้หุ࠭僷"),message)
	#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ僸"),l11l1l_l1_ (u"ࠩไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠬ價"),l11l1l_l1_ (u"๋ࠪีอࠠศๆไัฺࠦ็้ࠢ็้฾ืแส๊่ࠢࠥอไๆึๆ่ฮࠦๅ็ࠢ฼๊ิ้ࠠศ็้๋ࠣࠦวๅสิ๊ฬ๋ฬ࠯ࠢึ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสไัฺࠦๅ้ษๅ฽์ࠦๅาฬํ๊ࠥอไฤ๊็ํࠥฮ่ื฻ๆࠤฬ๊ืษ์฼๎ࠥ๎วๅอส๊๏ฯࠠษษึฮำีวๆࠢหีํ้ำ๋่ࠢะฬ์๊ࠡษ้ฮࠥะฮหษิ๋๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠิฬ฻๋ึࠦไศฯๅห࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำยࠫ僺"),l11l1l_l1_ (u"ࠫࠬ僻"),l11l1l_l1_ (u"ࠬ࠭僼"),l11l1l_l1_ (u"࠭ใๅษࠪ僽"),l11l1l_l1_ (u"ࠧ็฻่ࠫ僾"))
	#if l1ll11111l_l1_==1:
	#l1l11111l11l_l1_()
	return
def l1l1111ll1ll_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ僿"),l11l1l_l1_ (u"ࠩࠪ儀"),l11l1l_l1_ (u"ࠪฯ้อหูࠡิๆ๊ࠥไห๊สู้ࠦๅฺࠢส่๊ฮัๆฮࠪ儁"),l11l1l_l1_ (u"ࠫศืำๅࠢิืฬ๊ษࠡล๋ࠤฺ๊ใๅห้๋ࠣࠦโศศ่อࠥิฯๆษอࠤ์ึวࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴร้ࠢหหุะฮะษ่ࠤฬ๊แ๋ีห์่ࠦระ่ส๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡪࡷࡸࡵࡀ࠯࠰ࡨࡤࡧࡪࡨ࡯ࡰ࡭࠱ࡧࡴࡳ࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯࡞࠳ࡈࡕࡌࡐࡔࡠࠫ儂"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭儃"),l11l1l_l1_ (u"࠭ࠧ億"),l11l1l_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儅"),l11l1l_l1_ (u"ࠨ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࡠࡳࡢ࡮࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࡣ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ儆"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ儇"),l11l1l_l1_ (u"ࠪࠫ儈"),l11l1l_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儉"),l11l1l_l1_ (u"ࠬ࠶ࠠ࠱ࠢ࠳ࠤ࠵ࠦ࠰ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠲ࠢ࠴ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠶ࠥ࠸ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠳ࠡ࠵ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠷ࠤ࠹ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠻ࠠ࠶ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠸ࠣ࠺ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠼ࠦ࠷ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠹ࠢ࠻ࠤ࠾ࠦ࠹ࠡ࠻ࠣ࠽ࠥ࠿ࠠࡂࡃࡄࡅࡆ࠷࡟ࡃࡄࡅࡆࡇ࠷࡟ࡄࡅࡆࡇࡈ࠷࡟ࡅࡆࡇࡈࡉ࠷࡟ࡆࡇࡈࡉࡊ࠷࡟ࡇࡈࡉࡊࡋ࠷࡟ࡈࡉࡊࡋࡌ࠷࡟ࡉࡊࡋࡌࡍ࠷࡟ࡊࡋࡌࡍࡎ࠷࡟ࡋࡌࡍࡎࡏ࠷࡟ࡌࡍࡎࡏࡐ࠷࡟ࡍࡎࡏࡐࡑ࠷࡟ࡎࡏࡐࡑࡒ࠷ࠠ࠱࠲࠳࠴࠵ࠦ࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵ࠤ࠸࠹࠳࠴࠵ࠣ࠸࠹࠺࠴࠵ࠢࡄࡅࡆࡇࡁ࠳ࡡࡅࡆࡇࡈࡂ࠳ࡡࡆࡇࡈࡉࡃ࠳ࡡࡇࡈࡉࡊࡄ࠳ࡡࡈࡉࡊࡋࡅ࠳ࡡࡉࡊࡋࡌࡆ࠳ࡡࡊࡋࡌࡍࡇ࠳ࡡࡋࡌࡍࡎࡈ࠳ࡡࡌࡍࡎࡏࡉ࠳ࡡࡍࡎࡏࡐࡊ࠳ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤ࠺࠻࠵࠶࠷ࠣ࠺࠻࠼࠶࠷ࠢ࠺࠻࠼࠽࠷ࠡ࠺࠻࠼࠽࠾ࠠ࠺࠻࠼࠽࠾ࠦࡁࡂࡃࡄࡅࠥࡈࡂࡃࡄࡅࠫ儊"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ儋"),l11l1l_l1_ (u"ࠧࠨ儌"),l11l1l_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ儍"),l11l1l_l1_ (u"ࠩ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠨ儎"))
	#text = l11l1l_l1_ (u"ࠪࠬࠥࡇࡁࡂࡃࡄ࠵ࡤࡈࡂࡃࡄࡅ࠵ࡤࡉࡃࡄࡅࡆ࠵ࡤࡊࡄࡅࡆࡇ࠵ࡤࡋࡅࡆࡇࡈ࠵ࡤࡌࡆࡇࡈࡉ࠵ࡤࡍࡇࡈࡉࡊ࠵ࡤࡎࡈࡉࡊࡋ࠵ࡤࡏࡉࡊࡋࡌ࠵ࠥ࠯ࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࠣࡳࠥࡶࠠࡲࠢࡵࠤࡸࠦࡴࠡࡷࠣࡺࠥࡽࠠࡹࠢࡼࠤࡿࠦ࠰ࠡ࠳ࠣ࠶ࠥ࠹ࠠ࠵ࠢ࠸ࠤ࠻ࠦ࠷ࠡ࠺ࠣ࠽ࠥࡧࠠࡣࠢࡦࠤࡩࠦࡥࠡࡨࠣ࡫ࠥ࡮ࠠࡪࠢ࡭ࠤࡰࠦ࡬ࠡ࡯ࠣࡲࠥࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠥࡼࠠࡸࠢࡻࠤࡾࠦࡺࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺ࠭儏")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࠬ儐"),l11l1l_l1_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺࠲࠴࠶࠸࠺ࠧ儑"),l11l1l_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ儒"),l11l1l_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ儓"),l11l1l_l1_ (u"ࠨ࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵࠶࠷࠸࠲࠳ࠩ儔"),text,1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࠪ儕"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儖"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儗"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儘"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儙"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儚"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࠩ儛"),l11l1l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ儜"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儝"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儞"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ償"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭儠"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠧࠨ儡"),l11l1l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ儢"),l11l1l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ儣"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儤"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ儥"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ儦"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"࠭ࠧ儧"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儨"),l11l1l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ儩"),l11l1l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ優"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡢ࡮ࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儫"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儬"))
	return
def l11llll1ll1l_l1_():
	l11lllll1lll_l1_()
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ儭"),l11l1l_l1_ (u"࠭ࠧ儮"),l11l1l_l1_ (u"ࠧࠨ儯"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤฬ๊ใศึࠣรࠬ儰"),l11l1l_l1_ (u"ࠩส่่อิࠡ์ึี฾ูࠦๆๆࠣห้ฮั็ษ่ะࠥ๎ๅิฯ๊ࠤ๏฿๊ะࠢึัอࠦวๅืไัฬะࠠๆ่ࠣห้หๆหำ้ฮࠥ฿ๆะࠢส่าอฬสࠢศ่๏ํว๊ࠡสู่๊อࠡ์อ้ࠥะไใษษ๎ฬูࠦ็ัࠣห๋ะ็ศรࠣ฽๊ืࠠศๆุๅาอส๊ࠡสู่๊อࠡๆสࠤ๏฼ั๊่้่ࠡ์๋ࠠฯ็ࠤอ฿ึࠡษ็ู้อใๅࠩ儱"))
	if l1ll11111l_l1_==1:
		l11llllll111_l1_(True)
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ儲"),l11l1l_l1_ (u"ࠫࠬ儳"),l11l1l_l1_ (u"ࠬะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤออไไษ่่ࠬ儴"),l11l1l_l1_ (u"࠭ลัษࠣ็ฬ์สࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษะำࠥอไๆ๊สๆ฾ࠦแอำหࠤฬ๊ๅ้ไ฼ࠤฬ๊ย็ࠢ࠱࠲࠳่ࠦฤาสࠤฬ๊ๅีๅ็อ๋ࠥำห็ิอࠥ็ลั่ࠣหึูไࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠧ儵"))
	return l1ll11111l_l1_
def l1l11l11lll1_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ儶"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧ儷"),l11l1l_l1_ (u"ࠩࠪ儸"),l11l1l_l1_ (u"ࠪࠫ儹"),False,l11l1l_l1_ (u"ࠫࠬ儺"),l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ儻"))
	#html = response.content
	if not response.succeeded:
		l11lll1ll1ll_l1_ = False
		l11l1l1lll_l1_ = l11l1l1111_l1_()
		LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ儼"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬ儽")+l11l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࡟ࠪ儾"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ儿"),l11l1l_l1_ (u"ࠪࠫ兀"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ允"),l11l1l_l1_ (u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ兂"))
	else:
		l11lll1ll1ll_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ元"),l11l1l_l1_ (u"ࠧࠨ兄"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ充"),l11l1l_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢํ฽ฺ๊๊่ࠠา็ࠥ๎วๅสิ๊ฬ๋ฬࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭兆"))
	if not l11lll1ll1ll_l1_ and l1ll_l1_: l1l1111l1l1l_l1_()
	return l11lll1ll1ll_l1_
def l1l1111l1l1l_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ兇"),l11l1l_l1_ (u"ࠫࠬ先"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ光"),l11l1l_l1_ (u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬ兊"))
	#l1ll111lll1_l1_ = l11l1l_l1_ (u"ࠧี้สำฮࠦวๅฬืๅ๏ื่ࠠ์้้ࠣ็๋ࠠฯอ์๏ูࠦๅุ๋ࠣๆืษࠡะสูฮࠦร้ࠢอ์ฬฺ่๊ࠢัหฺฯࠠๅึิ็ฬะࠠๆ฻ิ์ๆฯ้ࠠๆ๊ࠤฯอั๋ะู้ࠣออ๋หࠣ์๋็วั๋ࠢห้เัื่๊ࠢ์ࠦ็้ࠢอฬฬีไࠡษ็้฾๊่ๆษอࠤอ฽ั๋ไฬࠤฺ๊แาหࠣ๎ฺ฿ศࠡษัฮึอโ่ษࠣ์ๆํๅ่ษࠪ克")
	l1l111l1ll1l_l1_()
	return
def l1l111l1lll1_l1_(text=l11l1l_l1_ (u"ࠨࠩ兌")):
	l1l1l1l111ll_l1_ = True
	if l11l1l_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ免") not in text:
		l1l1l1l111ll_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ兎"),l11l1l_l1_ (u"ࠫำื่อࠩ兏"),l11l1l_l1_ (u"ࠬหัิษ็ࠤฺ๊ใๅหࠪ児"),l11l1l_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠫ兑"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ兒"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫ兓"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l1l1l111ll_l1_ = True
			text = l11l1l_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ兔")
	if l1l1l1l111ll_l1_:
		#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ兕"),l11l1l_l1_ (u"ࠫࠬ兖"),l11l1l_l1_ (u"ࠬ࠭兗"),l11l1l_l1_ (u"࠭ลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ兘"),l11l1l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏ูสุ์฼ࠤฬ๊ๅษำ่ะู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ลึๆสั์อࠧ兙"))
		#if not l1ll11111l_l1_:
		#	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ党"),l11l1l_l1_ (u"ࠩࠪ兛"),l11l1l_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭兜"),l11l1l_l1_ (u"้๊ࠫริใࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ兝"))
		#	return
		l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡭ࡱࡪࡷࡂࡿࡥࡴࠩࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲่ࠧๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ࠬࠨไห่ࠥอัิษ็ࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾๊๊ไࠢส๊ࠥะโ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๎ࠠศๆิหอ฽ࠠศๆำ๎ࠥ๐ูุ์ๆࠤฬ๊ๅีๅ็อ๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅษั฻ฬว้ࠠษ็หุะฮะษ่࠲ࠥํไࠡฬิ๎ิࠦวๅษิืฬ๊ࠠศๆส๊ࠥลࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨๅ็หࠬ࠲ࠧ็฻่ࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡿࡥࡴ࠿ࡀ࠴࠿ࠐࠉࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไ฻ษฤࠤฬ๊วาีส่ࠬ࠯ࠊࠊࠋࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠊࠊࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠬࠨษำห้ࠥว็ฬ่ࠣิ๐ใࠡ็ื็้ฯࠠโษ็ีัอมࠡไิหฦฯࠠใี่ࠤฬ๊ๅีษๆ่ࠥ๎วๅษึส้ฯ้ࠠษำห๊ࠥๅࠡฬฯำࠥอไฮๆ๋๋ࠣอใࠡใะหํ๊ࠠไฬสฬฮࠦฬๆ์฼ࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࠭ࠏࠏࠉࠣࠤࠥ兞")
		if l11l1l_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭兟") not in text:
			l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ兠"),l11l1l_l1_ (u"ࠨࠩ兡"),l11l1l_l1_ (u"ࠩࠪ兢"),l11l1l_l1_ (u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪ兣"),l11l1l_l1_ (u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫ兤"))
			if l1ll11111l_l1_!=1:
				DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭入"),l11l1l_l1_ (u"࠭ࠧ兦"),l11l1l_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ內"),l11l1l_l1_ (u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ全"))
				return
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ兩"),l11l1l_l1_ (u"ࠪࠫ兪"),l11l1l_l1_ (u"่ࠫะวษหࠣ์ูือࠡษ็้ํ฼ฺ่ࠢ็่๊ฮัๆฮࠪ八"),l11l1l_l1_ (u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้อ๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ公"))
	search = OPEN_KEYBOARD(header=l11l1l_l1_ (u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ六"),source=l1ll1_l1_)
	if not search: return
	message = search
	if l1l1l1l111ll_l1_: type = l11l1l_l1_ (u"ࠧ࠮ࡒࡵࡳࡧࡲࡥ࡮ࠩ兮")
	else: type = l11l1l_l1_ (u"ࠨ࠯ࡐࡩࡸࡹࡡࡨࡧࠪ兯")
	l1ll11ll1l11_l1_ = l11l1l_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ兰")+l1l11llll11_l1_(32)+type
	succeeded = l1llll1ll1l1_l1_(l1ll11ll1l11_l1_,message,True,l11l1l_l1_ (u"ࠪࠫ共"),l11l1l_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧ兲"),text)
	#	url = l11l1l_l1_ (u"ࠬࡳࡹࠡࡃࡓࡍࠥࡧ࡮ࡥ࠱ࡲࡶ࡙ࠥࡍࡕࡒࠣࡷࡪࡸࡶࡦࡴࠪ关")
	#	payload = l11l1l_l1_ (u"࠭ࡻࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ࠽ࠦࡒ࡟ࠠࡂࡒࡌࠤࡐࡋ࡙ࠣ࠮ࠥࡸࡴࠨ࠺࡜ࠤࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠣ࡟࠯ࠦࡸ࡫࡮ࡥࡧࡵࠦ࠿ࠨ࡭ࡦࡂࡨࡱࡦ࡯࡬࠯ࡥࡲࡱࠧ࠲ࠢࡴࡷࡥ࡮ࡪࡩࡴࠣ࠼ࠥࡊࡷࡵ࡭ࠡࡃࡵࡥࡧ࡯ࡣࠡࡘ࡬ࡨࡪࡵࡳࠣ࠮ࠥࡸࡪࡾࡴࡠࡤࡲࡨࡾࠨ࠺ࠣࠩ兴")+message+l11l1l_l1_ (u"ࠧࠣࡿࠪ兵")
	#	#auth=(l11l1l_l1_ (u"ࠣࡣࡳ࡭ࠧ其"), l11l1l_l1_ (u"ࠤࡰࡽࠥࡶࡥࡳࡵࡲࡲࡦࡲࠠࡢࡲ࡬ࠤࡰ࡫ࡹࠣ具")),
	#	import requests
	#	response = requests.request(l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ典"),url, data=payload, headers=l11l1l_l1_ (u"ࠫࠬ兹"), auth=l11l1l_l1_ (u"ࠬ࠭兺"))
	#	response = requests.post(url, data=payload, headers=l11l1l_l1_ (u"࠭ࠧ养"), auth=l11l1l_l1_ (u"ࠧࠨ兼"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ兽"),l11l1l_l1_ (u"ࠩࠪ兾"),l11l1l_l1_ (u"ࠪࠫ兿"),l11l1l_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ冀"))
	#	else:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭冁"),l11l1l_l1_ (u"࠭ࠧ冂"),l11l1l_l1_ (u"ࠧฯูฦࠤๆ๐ࠠศๆศีุอไࠨ冃"),l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࡼࡿ࠽ࠤࢀࠧࡲࡾࠩ冄").format(response.status_code, response.content))
	#	l11lll1l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨ内")
	#	l11lllll1111_l1_ = l11l1l_l1_ (u"ࠪࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩ円")
	#	header = l11l1l_l1_ (u"ࠫࠬ冇")
	#	#header += l11l1l_l1_ (u"ࠬࡌࡲࡰ࡯࠽ࠤࠬ冈") + l11lll1l1ll1_l1_
	#	#header += l11l1l_l1_ (u"࠭࡜࡯ࡖࡲ࠾ࠥ࠭冉") + l11ll11l1l11_l1_
	#	#header += l11l1l_l1_ (u"ࠧ࡝ࡰࡆࡧ࠿ࠦࠧ冊") + l11ll11l1l11_l1_
	#	header += l11l1l_l1_ (u"ࠨ࡞ࡱࡗࡺࡨࡪࡦࡥࡷ࠾๋ࠥๆࠡๅ๋ำ๏ࠦวๅใํำ๏๎ࠠศๆ฼ีอ๐ࠧ冋")
	#	server = l1l11ll111l1_l1_.l11llll11111_l1_(l11l1l_l1_ (u"ࠩࡶࡱࡹࡶ࠭ࡴࡧࡵࡺࡪࡸࠧ册"),25)
	#	#server.l1l11111111l_l1_()
	#	server.l1l11111l111_l1_(l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬ再"),l11l1l_l1_ (u"ࠫࡵࡧࡳࡴࡹࡲࡶࡩ࠭冎"))
	#	response = server.l1l111l1111l_l1_(l11lll1l1ll1_l1_,l11lllll1111_l1_, header + l11l1l_l1_ (u"ࠬࡢ࡮ࠨ冏") + message)
	#	server.quit()
	return
def l1l11l111111_l1_():
	text = l11l1l_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์๋ะิࠦไ่ࠢฦ๎ู๊ࠥาใิࠤ๏ูสื์ไࠤศ๐ࠠๆฯอ์๏อส࠯ࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤึ๎วษูࠣ์ฯ฼ๅ๋่่๊ࠣำส้์สฮ๋ࠥัโ๊฼อࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣาฬืฬ๋ห࠱ࠤฬ๊ศา่ส้ัฺ๋ࠦำุ้ࠣส่ๅࠢ฼๊ࠥษ๊ࠡ็ะฮํ๐วหࠢอ้ࠥะอๆ์็๋ฬูࠦๅ๋ࠣื๏ืแาษอࠤํ๋่ศไ฼ࠤำอัอ์ฬࠤ๋่ࠧศไ฼ࠤ฼ืแࠡอส่ะࠨ࠮ࠡฮ่๎฾ࠦวๅลึ้ฬว้ࠠษ็้ฬืใศฬࠣ์ฬ๊ี้ำࠣ์ฬ๊ๅ็ึ๋ีฬะ่ࠠ์ࠣาฬ฻ษࠡสสูาอศ่ษ࠱ࠤฬ๊ศา่ส้ัࠦไศࠢํ๊ฯํใࠡฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠡࡆࡐࡇࡆࠦลัษࠣ็ฬ์ࠠๅัํ็ฺࠥใ้๋ࠣาฬ฻ษࠡสส่ึ๎วษูࠣ์ฬ๊สืษ่๎๋ࠦวๅะสีั๐ษࠡใส่ึาวยࠢส่ฯ๎วึๆ้ࠣ฾ࠦละษิอࠥํะ่ࠢสุ่๐ัโำสฮࠥ๎วๅ็๋ห็฿ࠠศๆัหึา๊ส࠰๋ࠣีอࠠศๆหี๋อๅอ๊ࠢ์ࠥฮศิษฺอ๋ࠥสึใะࠤ้๋่ศไ฼ࠤฬ๊่๋สࠪ冐")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭冑"),l11l1l_l1_ (u"ࠨฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠨ冒"),text,l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ冓"))
	text = l11l1l_l1_ (u"ࠪࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤ࡭ࡵࡳࡵࠢࡤࡲࡾࠦࡣࡰࡰࡷࡩࡳࡺࠠࡰࡰࠣࡥࡳࡿࠠࡴࡧࡵࡺࡪࡸ࠮ࠡࡋࡷࠤࡴࡴ࡬ࡺࠢࡸࡷࡪࡹࠠ࡭࡫ࡱ࡯ࡸࠦࡴࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡺࡨࡢࡶࠣࡻࡦࡹࠠࡶࡲ࡯ࡳࡦࡪࡥࡥࠢࡷࡳࠥࡶ࡯ࡱࡷ࡯ࡥࡷࠦ࡯࡯࡮࡬ࡲࡪࠦࡶࡪࡦࡨࡳࠥ࡮࡯ࡴࡶ࡬ࡲ࡬ࠦࡳࡪࡶࡨࡷ࠳ࠦࡁ࡭࡮ࠣࡸࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠬࠡࡸ࡬ࡨࡪࡵࡳ࠭ࠢࡷࡶࡦࡪࡥࠡࡰࡤࡱࡪࡹࠬࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡰࡥࡷࡱࡳ࠭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࡪࡪࠠࡸࡱࡵ࡯࠱ࠦ࡬ࡰࡩࡲࡷࠥࡸࡥࡧࡧࡵࡩࡳࡩࡥࡥࠢ࡫ࡩࡷ࡫ࡩ࡯ࠢࡥࡩࡱࡵ࡮ࡨࠢࡷࡳࠥࡺࡨࡦ࡫ࡵࠤࡷ࡫ࡳࡱࡧࡦࡸ࡮ࡼࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣࡧࡴࡳࡰࡢࡰ࡬ࡩࡸ࠴ࠠࡕࡪࡨࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡸ࡯ࡢ࡭ࡧࠣࡪࡴࡸࠠࡸࡪࡤࡸࠥࡵࡴࡩࡧࡵࠤࡵ࡫࡯ࡱ࡮ࡨࠤࡺࡶ࡬ࡰࡣࡧࠤࡹࡵࠠ࠴ࡴࡧࠤࡵࡧࡲࡵࡻࠣࡷ࡮ࡺࡥࡴ࠰࡛ࠣࡪࠦࡵࡳࡩࡨࠤࡦࡲ࡬ࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࠤࡴࡽ࡮ࡦࡴࡶ࠰ࠥࡺ࡯ࠡࡴࡨࡧࡴ࡭࡮ࡪࡼࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮ࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡤࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡢࡴࡨࠤࡱࡵࡣࡢࡶࡨࡨࠥࡹ࡯࡮ࡧࡺ࡬ࡪࡸࡥࠡࡧ࡯ࡷࡪࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡳࡷࠦࡶࡪࡦࡨࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡢࡴࡨࠤ࡫ࡸ࡯࡮ࠢࡲࡸ࡭࡫ࡲࠡࡸࡤࡶ࡮ࡵࡵࡴࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡢࡰࡼࠤࡱ࡫ࡧࡢ࡮ࠣ࡭ࡸࡹࡵࡦࡵࠣࡴࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡰࡩࡩ࡯ࡡࠡࡨ࡬ࡰࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡪࡲࡷࡹ࡫ࡲࡴ࠰ࠣࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡹࡩ࡮ࡲ࡯ࡽࠥࡧࠠࡸࡧࡥࠤࡧࡸ࡯ࡸࡵࡨࡶ࠳࠭冔")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ冕"),l11l1l_l1_ (u"ࠬࡊࡩࡨ࡫ࡷࡥࡱࠦࡍࡪ࡮࡯ࡩࡳࡴࡩࡶ࡯ࠣࡇࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦࡁࡤࡶࠣࠬࡉࡓࡃࡂࠫࠪ冖"),text,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ冗"))
	return
def l1l111111ll1_l1_(addon_id):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ冘"),l11l1l_l1_ (u"ࠨࠩ写"),l11l1l_l1_ (u"ࠩࠪ冚"),addon_id)
	result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭军")+addon_id+l11l1l_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡩࡥࡱࡹࡥࡾࡿࠪ农"))
	l1l11ll11l_l1_ = True
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡶ࡬ࡺࡺࡩ࡭ࠌࠌࡼࡧࡳࡣࡧ࡫࡯ࡩࠥࡃࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡸࡣ࡯ࡦࡪࡴࡲࡤࡦࡴ࠯ࠫࡦࡪࡤࡰࡰࡶࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠋࠋ࡬ࡪࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮ࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠪ࠼ࠍࠍࠎࡹࡨࡶࡶ࡬ࡰ࠳ࡸ࡭ࡵࡴࡨࡩ࠭ࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡶࡪ࡬ࡲࡦࡵ࡫ࠤࡂࠦࡔࡳࡷࡨࠎࠎࡻࡳࡦࡴࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡷࡶࡩࡷ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡶࡵࡨࡶ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡧࡤࡥࡱࡱࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡺࡥࡹࡶࡢࡪࡦࡩࡴࡰࡴࡼࠤࡂࠦࡳࡵࡴࠍࠍࡨࡩࠠ࠾ࠢࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪࠌࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡡࡥࡦࡲࡲࡸࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠣࠢ࠾ࠫ࠮ࠐࠉࠤࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡷ࡫ࡰࡰࡵ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫࠧࠦ࠻ࠨࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡳࡲࡳࡩࡵࠪࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠨࠢࠣ冝")
	if l1l11ll11l_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ冞"))
		time.sleep(1)
	return
def l1l111l1l1l1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ冟"),l11l1l_l1_ (u"ࠨࠩ冠"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ冡"),l11l1l_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨ冢"))
	l1l111l1ll11_l1_()
	return
def l1l111l1ll1l_l1_():
	#	https://l1llll1lll1l_l1_.tv/download/849
	#   https://play.l1l1ll1l1ll1_l1_.com/l11llll1l111_l1_/l1l111111111_l1_/details?id=l1lll1lll1l_l1_.xbmc.l1llll1lll1l_l1_
	#	http://mirror.l1l111l11l1l_l1_.l11lll1l1lll_l1_.l1l11lll1lll_l1_/l1l1111lll1l_l1_/xbmc/l11llll11l11_l1_/l11ll11ll1ll_l1_/l1l111l11111_l1_
	#	http://l11lll11l11l_l1_.l11ll1l1ll1l_l1_.l1l11lll1lll_l1_/l1llll1lll1l_l1_/l11llll11l11_l1_/l11ll11ll1ll_l1_/l1l111l11111_l1_
	url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩ冣")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ冤"),url,l11l1l_l1_ (u"࠭ࠧ冥"),l11l1l_l1_ (u"ࠧࠨ冦"),l11l1l_l1_ (u"ࠨࠩ冧"),l11l1l_l1_ (u"ࠩࠪ冨"),l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭冩"))
	html = response.content
	l11ll1l1l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪ冪"),html,re.DOTALL)
	l11ll1l1l11l_l1_ = l11ll1l1l11l_l1_[0].split(l11l1l_l1_ (u"ࠬ࠳ࠧ冫"))[0]
	l1l11ll1llll_l1_ = str(kodi_version)
	#l1lll11l11l1_l1_ = l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ冬")+l11l1l_l1_ (u"ࠧศๆหี๋อๅอࠢ็หࠥ๐ูๆๆ้ࠣ฾ࠦใ้ัํࠤส฻ฯศำࠣ࠵࠾่ࠦๆษࠣฬ฾ี็ࠨ冭")+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ冮")
	l1lll11l11l1_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ冯")+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭冰")+l11ll1l1l11l_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭冱")
	l1lll11l11l1_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ冲")+l11l1l_l1_ (u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ决")+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ冴")+l1l11ll1llll_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ况")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ冶"),l11l1l_l1_ (u"ࠪࠫ冷"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ冸"),l1lll11l11l1_l1_)
	return
def l11lll11ll11_l1_():
	# https://l1l11llll111_l1_-l11lll1l11ll_l1_-l11lllll1ll1_l1_.l1l11lllllll_l1_.com/request-l11llllll1l1_l1_
	# https://l1l11llll111_l1_-l11lll1l11ll_l1_-l11lllll1ll1_l1_.l1l11lllllll_l1_.com/query-l11ll1l1l1ll_l1_
	l1ll111ll1l_l1_,l1ll111lll1_l1_,l1lll11l111l_l1_,l1lll11l11l1_l1_,l1l111ll111l_l1_,l11ll1ll1l1l_l1_,l11llll1111l_l1_ = l11l1l_l1_ (u"ࠬ࠭冹"),l11l1l_l1_ (u"࠭ࠧ冺"),l11l1l_l1_ (u"ࠧࠨ冻"),l11l1l_l1_ (u"ࠨࠩ冼"),l11l1l_l1_ (u"ࠩࠪ冽"),l11l1l_l1_ (u"ࠪࠫ冾"),l11l1l_l1_ (u"ࠫࠬ冿")
	payload,l11ll1l1ll11_l1_,l1l1111lll11_l1_,l11ll11lll1l_l1_ = {l11l1l_l1_ (u"ࠬࡧࠧ净"):l11l1l_l1_ (u"࠭ࡡࠨ凁")},{},[],{}
	url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ凂")][1]
	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭凃"),url,payload,l11l1l_l1_ (u"ࠩࠪ凄"),l11l1l_l1_ (u"ࠪࠫ凅"),l11l1l_l1_ (u"ࠫࠬ准"),l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪ凇"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡓࡵࡣࡷࡩࡸ࠭凈"),l11l1l_l1_ (u"ࠧࡖࡕࡄࠫ凉"))
	html = html.replace(l11l1l_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡍ࡬ࡲ࡬ࡪ࡯࡮ࠩ凊"),l11l1l_l1_ (u"ࠩࡘࡏࠬ凋"))
	html = html.replace(l11l1l_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡅࡷࡧࡢࠡࡇࡰ࡭ࡷࡧࡴࡦࡵࠪ凌"),l11l1l_l1_ (u"࡚ࠫࡇࡅࠨ凍"))
	html = html.replace(l11l1l_l1_ (u"࡙ࠬࡡࡶࡦ࡬ࠤࡆࡸࡡࡣ࡫ࡤࠫ凎"),l11l1l_l1_ (u"࠭ࡋࡔࡃࠪ减"))
	html = html.replace(l11l1l_l1_ (u"ࠧࡏࡱࡵࡸ࡭ࠦࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ凐"),l11l1l_l1_ (u"ࠨࡐ࠱ࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭凑"))
	html = html.replace(l11l1l_l1_ (u"࡚ࠩࡩࡸࡺࡥࡳࡰࠣࡗࡦ࡮ࡡࡳࡣࠪ凒"),l11l1l_l1_ (u"࡛ࠪ࠳࡙ࡡࡩࡣࡵࡥࠬ凓"))
	html = html.replace(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ凔"),l11l1l_l1_ (u"ࠬࠦࠠࠨ凕"))
	try: l1l1111ll11l_l1_ = EVAL(l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ凖"),html)
	except:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ凗"),l11l1l_l1_ (u"ࠨࠩ凘"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ凙"),l11l1l_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪ凚"))
		return
	l1l11ll1111l_l1_,l1l11lll1l1l_l1_,l11lllll1l11_l1_ = l1l1111ll11l_l1_
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ凛"),str(l1l11ll1111l_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭凜"),str(l1l11lll1l1l_l1_))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ凝"),str(l11lllll1l11_l1_))
	l11ll11lll1l_l1_ = {}
	l1l1l1111111_l1_ = [l11l1l_l1_ (u"ࠧࡂࡎࡏࠫ凞"),l11l1l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ凟"),l11l1l_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ几"),l11l1l_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ凡"),l11l1l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ凢")]+l1l1111l1111_l1_
	for l1ll11111l1_l1_,l1l11ll111ll_l1_,l1l11l11llll_l1_ in l1l11lll1l1l_l1_:
		l1l11l11llll_l1_ = escapeUNICODE(l1l11l11llll_l1_)
		l1l11l11llll_l1_ = l1l11l11llll_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠧ凣")).strip(l11l1l_l1_ (u"࠭ࠠ࠯ࠩ凤"))
		l1lll11l11l1_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ凥")+l1ll11111l1_l1_+l11l1l_l1_ (u"ࠨ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ処")+l1l11l11llll_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ凧")
		if l1l11ll111ll_l1_.isdigit():
			l11ll11lll1l_l1_[l1ll11111l1_l1_] = int(l1l11ll111ll_l1_)
			if int(l1l11ll111ll_l1_)>100: l1l11ll111ll_l1_ = l11l1l_l1_ (u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭凨")
			else: l1l11ll111ll_l1_ = l11l1l_l1_ (u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭凩")
		if l1ll11111l1_l1_ not in l1l1l1111111_l1_:
			if   l1l11ll111ll_l1_==l11l1l_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ凪"): l1ll111ll1l_l1_ += l11l1l_l1_ (u"࠭ࠠࠡࠩ凫")+l1ll11111l1_l1_
			elif l1l11ll111ll_l1_==l11l1l_l1_ (u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩ凬"): l1ll111lll1_l1_ += l11l1l_l1_ (u"ࠨࠢࠣࠫ凭")+l1ll11111l1_l1_
	l1l11ll11l1l_l1_,l11lll1lll11_l1_,l11llll111l1_l1_ = list(zip(*l1l11lll1l1l_l1_))
	for l1ll11111l1_l1_ in sorted(l111l111ll1_l1_):
		if l1ll11111l1_l1_ not in l1l11ll11l1l_l1_:
			l1lll11l11l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ凮")+l1ll11111l1_l1_+l11l1l_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ凯")+l11l1l_l1_ (u"้ࠫอ๋๊ࠠฯำࠬ凰")+l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ凱")
			if l1ll11111l1_l1_ not in l1l1l1111111_l1_: l1lll11l111l_l1_ += l11l1l_l1_ (u"࠭ࠠࠡࠩ凲")+l1ll11111l1_l1_
	for l1l11l11llll_l1_,counts in l1l11ll1111l_l1_:
		l1l11l11llll_l1_ = escapeUNICODE(l1l11l11llll_l1_)
		l1l111ll111l_l1_ += l1l11l11llll_l1_+l11l1l_l1_ (u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ凳")+str(counts)+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭凴")
	l1ll111ll1l_l1_ = l1ll111ll1l_l1_.strip(l11l1l_l1_ (u"ࠩࠣࠫ凵"))
	l1ll111lll1_l1_ = l1ll111lll1_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ凶"))
	l1lll11l111l_l1_ = l1lll11l111l_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭凷"))
	l1lll11l1l11_l1_ = l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠨ凸")+l1ll111lll1_l1_
	#l1l1lllll1ll_l1_  = l11l1l_l1_ (u"࠭࡜࡯ࡊ࡬࡫࡭࡛ࡳࡢࡩࡨ࠾ࠥࡡࠠࠨ凹")+l1ll111ll1l_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ出")
	#l1l1lllll1ll_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࡐࡴࡽࡕࡴࡣࡪࡩࠥࡀࠠ࡜ࠢࠪ击")+l1ll111lll1_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬ凼")
	#l1l1lllll1ll_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡔ࡯ࡖࡵࡤ࡫ࡪࠦࠠ࠻ࠢ࡞ࠤࠬ函")+l1lll11l111l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ凾")
	l1lll11l11ll_l1_  = l11l1l_l1_ (u"๋่ࠬศไ฼ࠤูเไࠡ็้๋ฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ะ์๋๋ฬะࠠษั๋๊๋ࠥิศๅ็ࠫ凿")+l11l1l_l1_ (u"࠭࡜࡯ࠩ刀")+l11l1l_l1_ (u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠬ刁")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ刂")
	l1lll11l11ll_l1_ += l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ刃")+l1lll11l1l11_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ刄")
	l1lll11l11ll_l1_ += l11l1l_l1_ (u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤฬ๊ศศำะอࠥ࠮๊้็ࠣวู๊ࠩࠡลํࠤๆ๐ฯ๋๊๊หฯ࠭刅")+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ分")+l11l1l_l1_ (u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪ切")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ刈")
	l1lll11l11ll_l1_ += l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ刉")+l1lll11l111l_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ刊")
	l1l11l1lll11_l1_,l11lll11lll1_l1_,l1l111l11l11_l1_,l11lll111lll_l1_ = 0,0,0,0
	all = l11ll11lll1l_l1_[l11l1l_l1_ (u"ࠪࡅࡑࡒࠧ刋")]
	if l11l1l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ刌") in list(l11ll11lll1l_l1_.keys()): l1l11l1lll11_l1_ = l11ll11lll1l_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ刍")]
	if l11l1l_l1_ (u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ刎") in list(l11ll11lll1l_l1_.keys()): l11lll11lll1_l1_ = l11ll11lll1l_l1_[l11l1l_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ刏")]
	if l11l1l_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ刐") in list(l11ll11lll1l_l1_.keys()): l1l111l11l11_l1_ = l11ll11lll1l_l1_[l11l1l_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭刑")]
	if l11l1l_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ划") in list(l11ll11lll1l_l1_.keys()): l11lll111lll_l1_ = l11ll11lll1l_l1_[l11l1l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ刓")]
	l11l1l1l1ll_l1_ = all-l1l11l1lll11_l1_-l11lll11lll1_l1_-l1l111l11l11_l1_-l11lll111lll_l1_
	dummy,l1l1111l11ll_l1_ = l11lllll1l11_l1_[0]
	dummy,l11ll1lll11l_l1_ = l11lllll1l11_l1_[1]
	l11lllll111l_l1_ = l1l1111l11ll_l1_-l11ll1lll11l_l1_
	l11llll1111l_l1_ += l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ刔")+str(l11ll1lll11l_l1_)+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ刕")+l11l1l_l1_ (u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫ刖")
	l11llll1111l_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭列")+str(l11lllll111l_l1_)+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ刘")+l11l1l_l1_ (u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧ则")
	l11llll1111l_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ刚")+str(l1l1111l11ll_l1_)+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ创")+l11l1l_l1_ (u"࠭วๅ฻าำࠥอไไๆํࠤ้าๅ๋฻ࠣห้ษฬ่ิฬࠤ࠿ࠦࠧ刜")
	l11llll1111l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ初")+str(len(l11lllll1l11_l1_[2:]))+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ刞")+l11l1l_l1_ (u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧ刟")
	for l11llll1111_l1_,l1l1111l1lll_l1_ in l11lllll1l11_l1_[2:]:
		l11llll1111_l1_ = escapeUNICODE(l11llll1111_l1_)
		l11llll1111_l1_ = l11llll1111_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ删")).strip(l11l1l_l1_ (u"ࠫࠥ࠴ࠧ刡"))
		l11llll1111l_l1_ += l11llll1111_l1_+l11l1l_l1_ (u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ刢")+str(l1l1111l1lll_l1_)+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫ刣")
	#l11llll1111l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࠱ࠫ判")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ別")+str(l11l1l1l1ll_l1_)+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ刦")+l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥอิห฼็ฮࠥࡀࠠࠨ刧")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ刨")+str(l1l11l1lll11_l1_)+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ利")+l11l1l_l1_ (u"࠭ืๅสสฮู๊ࠥาใิࠤออ๊ฬ๊้ࠤ࠿ࠦࠧ刪")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ别")+str(l11lll111lll_l1_)+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ刬")+l11l1l_l1_ (u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่าฬุๆࠡ࠼ࠣࠫ刭")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ刮")+str(l11lll11lll1_l1_)+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭刯")+l11l1l_l1_ (u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩ到")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ刱")+str(l1l111l11l11_l1_)+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ刲")+l11l1l_l1_ (u"ࠨฬฮฬ๏ะࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠿ࠦࠧ刳")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ刴")+str(len(l1l11ll1111l_l1_))+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ刵")+l11l1l_l1_ (u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫ制")
	#l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ刷")+l11l1l_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦวๅ฻ส่๊๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ券")+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ刹")
	l11ll1ll1l1l_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭刺")+l1l111ll111l_l1_
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ刻"),l11l1l_l1_ (u"ࠪ฽ิีࠠศๆฦะ์ุษࠡษ็ฮ๏ࠦวิฬัำ๊ะ่ࠠาสࠤฬ๊ศา่ส้ัࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪ刼"),l11llll1111l_l1_,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ刽"))
	#l11ll111l1_l1_(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ刾"),l11l1l_l1_ (u"࠭ฬๆ์฼ࠤ์ึ็ࠡษ็วึ่วๆࠢอาฺࠦริฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦࠠโไฺࠤ๏๎ๅࠡล่ืࠥ࠮วๅสสีาฯࠩࠨ刿"),l11ll1ll1l1l_l1_,l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ剀"))
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ剁"),l11l1l_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪ剂"),l11ll1ll1l1l_l1_,l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭剃"))
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ剄"),l11l1l_l1_ (u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤฬ๊ศศำะอࠥ࠮๊้็ࠣวู๊ࠩࠡࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ剅"),l1lll11l11ll_l1_,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ剆"))
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ則"),l11l1l_l1_ (u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣห้ฮวาฯฬࠤ࠭๐่ๆࠢฦุ้࠯ࠠศีอาิ๋สࠡษ็ฬึ์วๆฮࠪ剈"),l1lll11l11l1_l1_,l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ剉"))
	return
def l11llll11l1l_l1_():
	message = l11l1l_l1_ (u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ่ࠠา๊ࠤฬ๊ัิษ็อࠥ๎ฺ๋ำ๊ห้ࠥห๋ำ้ࠣํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั่ࠦศๆ่ึ๏ีࠠฤ์ูห๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦรอ๊หอࠥอไษำ้ห๊าࠧ削")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ剋"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ剌"),message,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ前"))
	return
def l1l11l1l11ll_l1_():
	message = l11l1l_l1_ (u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅฯิ้ࠤ฾๋วะ๋ࠢๅ๏ํࠠฤ์ูหࠥาๅ๋฻ࠣห฾ีวะฬࠣ็ํี๊ࠡษ็้฼๊่ษห่ࠣ฾๋ไࠡสิ๊ฬ๋ฬࠡ฻่หิ่ࠦไๆ๊หࠥะสๆࠢส์ฯ๎ๅศฬํ็๏อ้ࠠๆสࠤฯำสศฮࠣว๏ࠦๆ้฻้๋ࠣࠦวๅะหีฮࠦแ๋ࠢๆ์ิ๐ࠠฤ๊ࠣห้ิศาหࠣๅ๏ࠦสฬสํฮࠥษึศใสฮ้่ࠥะ์ࠪ剎")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ剏")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ剐")+l1l1ll1_l1_[l11l1l_l1_ (u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ剑")][0]+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ剒")+l1l1ll1_l1_[l11l1l_l1_ (u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ剓")][1]+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ剔")
	message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼๐ๆࠡลา๊ฬํ่ࠠ็สࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ剕")+l1l1ll1_l1_[l11l1l_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ剖")][1]+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭剗")+l1l1ll1_l1_[l11l1l_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ剘")][0]+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭剙")
	message += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ剚")+l11l1l_l1_ (u"࠭࡜࡯ࠩ剛")+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ剜")+l1l1ll1_l1_[l11l1l_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ剝")][2]+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ剞")
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ剟"),l11l1l_l1_ (u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ剠"),message,l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ剡"))
	return
def l1l11l1l111l_l1_(l1l11l1l1l1l_l1_):
	xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬ剢")+l1l11l1l1l1l_l1_+l11l1l_l1_ (u"ࠧࠪࠩ剣"), True)
	return
def l1l11l11l111_l1_():
	l1ll11111_l1_(l11l1l_l1_ (u"ࠨࡵࡷࡳࡵ࠭剤"))
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣ剥"))
	return
def l11lllll11ll_l1_():
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩ剦"), True)
	return
def l1l111ll1111_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll11111l_l1_ = True
	else: l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ剧"),l11l1l_l1_ (u"ࠬ࠭剨"),l11l1l_l1_ (u"࠭ࠧ剩"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剪"),l11l1l_l1_ (u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨ剫"))
	if l1ll11111l_l1_==1:
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬ剬"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ剭"),l11l1l_l1_ (u"ࠫࠬ剮"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ副"),l11l1l_l1_ (u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆะี๊ࠥ฿ๅศัࠣ࠲ࠥ๐ัอ๋ࠣษ฾฽วยࠢๆ์ิ๐ࠠ࠶ࠢาๆฬฬโࠡล๋ࠤศ้หาࠢ็็๏๊ࠦ็้ํࠤ฾๋ไ๋หࠣห้ะอะ์ฮࠫ剰"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ剱"))
	l11l1l11111_l1_ = not l1ll11111l_l1_
	return l11l1l11111_l1_
def l11lll1ll11l_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ割"),l11l1l_l1_ (u"ࠩࠪ剳"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭剴"),l11l1l_l1_ (u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫ創"))
	return
def l1l111lllll1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭剶"),l11l1l_l1_ (u"࠭ࠧ剷"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剸"),l11l1l_l1_ (u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะึ฻ูࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ剹"))
	return
#l1l11l1ll111_l1_ 	  required	and l1l11l1ll111_l1_     installed	and		not l11l1l11111_l1_		ignore
#l1l11l1ll111_l1_ not required	and	l1l11l1ll111_l1_ not installed 	and 	    l11l1l11111_l1_		ignore
#l1l11l1ll111_l1_ not required	and	l1l11l1ll111_l1_ not installed 	and 	not l11l1l11111_l1_		ignore
#l1l11l1ll111_l1_ not required	and	l1l11l1ll111_l1_     installed 	and 	not l11l1l11111_l1_		ignore
#l1l11l1ll111_l1_     required	and	l1l11l1ll111_l1_ not installed 	and 	    l11l1l11111_l1_		l11111111l_l1_ l11lll11lll1_l1_	l11ll1l111ll_l1_
#l1l11l1ll111_l1_     required	and	l1l11l1ll111_l1_ not installed 	and 	not l11l1l11111_l1_		l11111111l_l1_ l11lll11lll1_l1_	l11ll1l111ll_l1_
#l1l11l1ll111_l1_     required 	and l1l11l1ll111_l1_     installed 	and 	    l11l1l11111_l1_		l11111111l_l1_ l1l11ll1lll1_l1_	l11ll1l111ll_l1_
#l1l11l1ll111_l1_ not required	and	l1l11l1ll111_l1_     installed 	and 	    l11l1l11111_l1_		l11111111l_l1_ l1l11ll1lll1_l1_	l11ll1l111ll_l1_
#l1l111l1111_l1_: required and not installed: l11111111l_l1_ l11lll11lll1_l1_
#l11lll11111_l1_: installed and l11111111l_l1_ update: l11111111l_l1_ l1l11ll1lll1_l1_
def l1l11l11111l_l1_(l1ll_l1_=True):
	l1l1l1l1l11l_l1_ = l1l111111l1l_l1_([l11l1l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ剺")])
	l1l111l111l1_l1_ = []
	for addon_id in [l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ剻")]:
		if addon_id not in list(l1l1l1l1l11l_l1_.keys()): continue
		l11l1l11111_l1_,l1l11111lll1_l1_,l11ll1l1111l_l1_,l1l111lll1l1_l1_,l1l111ll1ll1_l1_,l11ll1l1llll_l1_,l1l111lll111_l1_ = l1l1l1l1l11l_l1_[addon_id]
		if not l1l11111lll1_l1_ or (l1l11111lll1_l1_ and l11l1l11111_l1_): l1l111l111l1_l1_.append(addon_id)
	l11ll11l1lll_l1_ = len(l1l111l111l1_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l111llll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1l11l1111l1_l1_ = []
	for addon_id in l1l11llllll1_l1_:
		cc.execute(l11l1l_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࠥ࠵ࠧࠦࡡ࡯ࡦࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ剼")+addon_id+l11l1l_l1_ (u"ࠬࠨࠠ࠼ࠩ剽"))
		l11lllll11l1_l1_ = cc.fetchall()
		if l11lllll11l1_l1_: l1l11l1111l1_l1_.append(addon_id)
	l11llll1ll11_l1_ = len(l1l11l1111l1_l1_)>0
	for addon_id in l1l111lll1ll_l1_:
		cc.execute(l11l1l_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ剾")+addon_id+l11l1l_l1_ (u"ࠧࠣࠢ࠾ࠫ剿"))
		l1l1l111111l_l1_ = cc.fetchall()
		if l1l1l111111l_l1_ and l11l1l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ劀") not in str(l1l1l111111l_l1_): l1l111l111l1_l1_.append(addon_id)
	l11lll1l111l_l1_ = len(l1l111l111l1_l1_)>0
	l1l111l111l1_l1_ = list(set(l1l111l111l1_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ劁"),l11l1l_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡨ࡬ࡼ࡮ࡴࡧࡠࡴࡨࡴࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠣࠫ劂")+str(l11ll11l1lll_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ劃"),l11l1l_l1_ (u"ࠬࡴࡥࡦࡦࡢࡨࡪࡲࡥࡵ࡫ࡱ࡫ࡤࡵ࡬ࡥࡡࡤࡨࡩࡵ࡮ࡴ࠼ࠣࠤࠬ劄")+str(l11llll1ll11_l1_))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ劅"),l11l1l_l1_ (u"ࠧ࡯ࡧࡨࡨࡤ࡬ࡩࡹ࡫ࡱ࡫ࡤࡵࡲࡪࡩ࡬ࡲ࠿ࠦࠠࠨ劆")+str(l11lll1l111l_l1_))
	l11l1l11111_l1_ = False
	if l11llll1ll11_l1_ or l11lll1l111l_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ劇"),l11l1l_l1_ (u"ࠩࠪ劈"),l11l1l_l1_ (u"ࠪࠫ劉"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ劊"),l11l1l_l1_ (u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮࠯࠰ࠣๆิ๊ࠦไ๊้ࠤ๊฿ืๅࠢฦ์๊ࠥวࠡ์฼้้ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊่ࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠศๆล๊ࠥล࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ劋"))
		if l1ll11111l_l1_==1:
			l1l11ll11lll_l1_ = True
			if l11ll11l1lll_l1_:
				l1l11ll11lll_l1_ = l1l11lll1111_l1_(False)
			l11lll111111_l1_ = True
			if l11llll1ll11_l1_:
				for addon_id in l1l11l1111l1_l1_: l1l111111ll1_l1_(addon_id)
				l11lll111111_l1_ = True
			l11lllllll1l_l1_ = True
			if l11lll1l111l_l1_:
				conn = sqlite3.connect(l1l111llll1l_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1l111l111l1_l1_:
					if l11l1l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࠩ劌") in addon_id: l1l1l111111l_l1_ = addon_id
					else: l1l1l111111l_l1_ = l11l1l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ劍")
					try: cc.execute(l11l1l_l1_ (u"ࠨࡗࡓࡈࡆ࡚ࡅࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡘࡋࡔࠡࡱࡵ࡭࡬࡯࡮ࠡ࠿ࠣࠦࠬ劎")+l1l1l111111l_l1_+l11l1l_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ劏")+addon_id+l11l1l_l1_ (u"ࠪࠦࠥࡁࠧ劐"))
					except: l11lllllll1l_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11l1l_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ劑"))
			time.sleep(1)
			if l1l11ll11lll_l1_ or l11lll111111_l1_ or l11lllllll1l_l1_:
				l11l1l11111_l1_ = False
				DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭劒"),l11l1l_l1_ (u"࠭ࠧ劓"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ劔"),l11l1l_l1_ (u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣฮๆ฿๊ๅ๋ࠢษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥฬๆ์฼ࠤส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ劕"))
			else:
				l11l1l11111_l1_ = True
				DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ劖"),l11l1l_l1_ (u"ࠪࠫ劗"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ劘"),l11l1l_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ劙"))
	elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ劚"),l11l1l_l1_ (u"ࠧࠨ力"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ劜"),l11l1l_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ劝"))
	return l11l1l11111_l1_
def l11lll11llll_l1_():
	l11ll11lllll_l1_,l1l11l1lll1l_l1_,l11ll1l1l111_l1_ = False,l11l1l_l1_ (u"ࠪࠫ办"),l11l1l_l1_ (u"ࠫࠬ功")
	l1l11l1ll11l_l1_,l11llllllll1_l1_,l1l1111l11l1_l1_ = False,l11l1l_l1_ (u"ࠬ࠭加"),l11l1l_l1_ (u"࠭ࠧ务")
	l1l1l1l1l11l_l1_ = l1l111111l1l_l1_([l11l1l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ劢"),l11l1l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ劣"),l11l1l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ劤")])
	for addon_id in [l11l1l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ劥"),l11l1l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭劦"),l11l1l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ劧")]:
		if addon_id not in list(l1l1l1l1l11l_l1_.keys()): continue
		l11l1l11111_l1_,l1l11111lll1_l1_,l1l11ll11l11_l1_,l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l1l111ll11l1_l1_,l11ll11l11ll_l1_ = l1l1l1l1l11l_l1_[addon_id]
		if addon_id==l11l1l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ动"):
			l1l11l1ll11l_l1_ = l11l1l11111_l1_
			l11llllllll1_l1_ = l11l1l_l1_ (u"ࠧࠩࠩ助")+l1l11111lll1_l1_+l11l1l_l1_ (u"ࠨࠢࠪ努")+TRANSLATE(l1l111ll11l1_l1_)+l11l1l_l1_ (u"ࠩࠬࠫ劫")
			l1l1111l11l1_l1_ = l1l111ll1l1l_l1_
		elif addon_id==l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ劬"):
			l11ll11lllll_l1_ = l11ll11lllll_l1_ or l11l1l11111_l1_
			l1l11l1lll1l_l1_ += l11l1l_l1_ (u"ࠫࠥࠦࠬࠡࠢࠫࠫ劭")+l1l11111lll1_l1_+l11l1l_l1_ (u"ࠬࠦࠧ劮")+TRANSLATE(l1l111ll11l1_l1_)+l11l1l_l1_ (u"࠭ࠩࠨ劯")
			l11ll1l1l111_l1_ += l11l1l_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭劰")+l1l111ll1l1l_l1_
		elif addon_id==l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ励"):
			l11llll11lll_l1_ = l11l1l11111_l1_
			l11lll1llll1_l1_ = l11l1l_l1_ (u"ࠩࠫࠫ劲")+l1l11111lll1_l1_+l11l1l_l1_ (u"ࠪࠤࠬ劳")+TRANSLATE(l1l111ll11l1_l1_)+l11l1l_l1_ (u"ࠫ࠮࠭労")
			l11ll11ll11l_l1_ = l1l111ll1l1l_l1_
	l1l11l1lll1l_l1_ = l1l11l1lll1l_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠫ劵"))
	l11ll1l1l111_l1_ = l11ll1l1l111_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ劶"))
	l1l11l1l1l_l1_  = l11l1l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไษำ้ห๊าฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ劷")+l1l1111l11l1_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ劸")
	l1l11l1l1l_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ効")+l11l1l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ劺")+l11llllllll1_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭劻")
	l1l11l1l1l_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ劼")+l11l1l_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥๅฯิ้ࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ劽")+l11ll1l1l111_l1_+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ劾")
	l1l11l1l1l_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࠫ势")+l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้๋ฮำ่ࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ勀")+l1l11l1lll1l_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ勁")
	l1l11l1l1l_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ勂")+l11l1l_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ勃")+l11ll11ll11l_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ勄")
	l1l11l1l1l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ勅")+l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ勆")+l11lll1llll1_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ勇")
	l11l1l11111_l1_ = (l1l11l1ll11l_l1_ or l11ll11lllll_l1_)
	if l11l1l11111_l1_:
		header = l11l1l_l1_ (u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬ勈")
		l1l1l11lll_l1_ = l11l1l_l1_ (u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆะี๊ࠥ฿ๅศัࠪ勉")
	else:
		header = l11l1l_l1_ (u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ัึู๋ࠦๆษาࠫ勊")
		l1l1l11lll_l1_ = l11l1l_l1_ (u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨ勋")
	l1l1l11ll1_l1_ = l11l1l_l1_ (u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭勌")
	l1ll11l111_l1_ = l1l11l1l1l_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭勍")+l1l1l11lll_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ勎")+l1l1l11ll1_l1_
	l11ll111l1_l1_(l11l1l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ勏"),header,l1ll11l111_l1_,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ勐"))
	return
def l1l1111llll1_l1_(l1ll_l1_=True,l11lll1l1l11_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ勑"),l11l1l_l1_ (u"࠭ࡅࡎࡃࡇࡣࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ勒"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ勓"),l11l1l_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ勔"))
	if l1ll_l1_:
		l11lll11llll_l1_()
		l1l111l1ll1l_l1_()
	if l11lll1l1l11_l1_:
		l11ll1lllll1_l1_ = l1l11l11111l_l1_(False)
		l11ll1ll11l1_l1_ = l1l111ll1111_l1_(l1ll_l1_)
		if not l11ll1lllll1_l1_ and not l11ll1ll11l1_l1_:
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭動"))
	return
def l1l11lll1111_l1_(l1ll_l1_=True):
	l1l1l1l1l11l_l1_ = l1l111111l1l_l1_([l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ勖")])
	l1ll11111l_l1_,l1l11l1ll1ll_l1_,l1l11llll1l1_l1_ = True,True,True
	for addon_id in [l11l1l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭勗")]:
		l11l1l11111_l1_,l1l11111lll1_l1_,l1l11ll11l11_l1_,l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l1l111ll11l1_l1_,l11ll11l11ll_l1_ = l1l1l1l1l11l_l1_[addon_id]
		if l11l1l11111_l1_:
			l1l11l1ll1ll_l1_ = False
			break
	if l1l11l1ll1ll_l1_:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭勘"),l11l1l_l1_ (u"࠭ࠧ務"),l11l1l_l1_ (u"ࠧโฯุࠤ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩ勚"),l11l1l_l1_ (u"ࠨ็ัึู๋ࠦๆษาࠤ๊๎ฬ้ัࠣ฽๋ีใ๊่ࠡๅ฾๊้ࠠฮส๋ืࠦไๅษึฮำีวๆࠩ勛"))
		return
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ勜"),l11l1l_l1_ (u"ࠪࠫ勝"),l11l1l_l1_ (u"ࠫࠬ勞"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ募"),l11l1l_l1_ (u"࠭ๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࡠࡳࠦแู๋้้้ࠣไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤส๋วࠡไา๎๊ࠦร้่ࠢๅ็๎ฯࠡล๋ࠤ๊ะ่ใใࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำࠠศๆุ่่๊ษࠡษ็ฦ๋ࠦฟࠨ勠"))
		if l1ll11111l_l1_!=1: return
	if l1ll11111l_l1_==1:
		for addon_id in [l11l1l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ勡")]:
			if addon_id not in list(l1l1l1l1l11l_l1_.keys()): continue
			l11l1l11111_l1_,l1l11111lll1_l1_,l1l11ll11l11_l1_,l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l1l111ll11l1_l1_,l11ll11l11ll_l1_ = l1l1l1l1l11l_l1_[addon_id]
			succeeded = l11lll1ll1l1_l1_(addon_id,l11ll11l11ll_l1_,l1ll_l1_)
			l1l11llll1l1_l1_ = l1l11llll1l1_l1_ and succeeded
	if l1ll_l1_:
		if l1l11llll1l1_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ勢"),l11l1l_l1_ (u"ࠩࠪ勣"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭勤"),l11l1l_l1_ (u"ࠫฯ๋ࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ࡜࡯่ࠢาื์ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ勥"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭勦"),l11l1l_l1_ (u"࠭ࠧ勧"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ勨"),l11l1l_l1_ (u"ࠨๆ็วุ็ࠠๅ็ࠣ๎ฯ๋ใ็ࠢส่อืๆศ็ฯࠤ๊์ࠠฦื็หาࠦๅีๅ็อࡡࡴࠠๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ勩"))
	return l1l11llll1l1_l1_
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ勪")+sys.argv[0]+l11l1l_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿࠵࠺࠵࠭勫")+l11l1l_l1_ (u"ࠦ࠮ࠨ勬"))
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ勭"))
def l11lll1ll1l1_l1_(addon_id,l11ll11l11ll_l1_,l1ll_l1_=True):
	succeeded = False
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧ勮"),l11l1l_l1_ (u"ࠧࠨ勯"),l11l1l_l1_ (u"ࠨࠩ勰"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ勱"),l11l1l_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆุ฽์฼ࠦไๅวูหๆฯࠠศๆ่฻้๎ศสࠢ็็๏๊ࠦห็ࠣฮะฮ๊ห้ࠣ฽้๏ࠠไ๊า๎ࠥ࠴ࠠศๆ่่ๆࠦโะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥอไร่ࠣรࠦ࠭勲"))
		if l1ll11111l_l1_!=1: return False
	l11ll1l11ll1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11ll11l11ll_l1_)
	if l11ll1l11ll1_l1_:
		import zipfile,io
		l11llllll1ll_l1_ = io.BytesIO(l11ll1l11ll1_l1_)
		zf = zipfile.ZipFile(l11llllll1ll_l1_)
		zf.extractall(l1ll11l1l1_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ勳"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ勴")+addon_id+l11l1l_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ勵"))
		if l11l1l_l1_ (u"ࠧࡐࡍࠪ勶") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ勷"),l11l1l_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ勸"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ勹"),l11l1l_l1_ (u"ࠫࠬ勺"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ勻"),l11l1l_l1_ (u"࠭สๆࠢห๊ัออࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪ勼"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ勽"),l11l1l_l1_ (u"ࠨࠩ勾"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ勿"),l11l1l_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ匀"))
	return succeeded
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࠥ࡬ࡱࡵࡵࡲࡵࠢࡶࡵࡱ࡯ࡴࡦ࠵ࠍࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡡࡥࡦࡲࡲࡸࡥࡤࡣࡨ࡬ࡰࡪ࠯ࠊࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࡩࡣࠡ࠿ࠣࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫࠍࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࡙ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠫ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡯࡮࡯࡬ࡸ࠭࠯ࠊࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠤࠥࠦ匁")
def l1l111l11lll_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11l1l_l1_ (u"ࠬ࠭匂"): l1ll_l1_ = True
	#l1l11l1lllll_l1_ = xbmc.getCondVisibility(l11l1l_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠩ匃")+addon_id+l11l1l_l1_ (u"ࠧࠪࠩ匄"))
	l1l11l111l11_l1_ = l11lll11l1ll_l1_([addon_id])
	l1l111llllll_l1_,l1l11l1lllll_l1_ = l1l11l111l11_l1_[addon_id]
	if l1l11l1lllll_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ包"),l11l1l_l1_ (u"ࠩࠪ匆"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭匇"),l11l1l_l1_ (u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭匈")+addon_id+l11l1l_l1_ (u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨ匉"))
	else:
		succeeded = False
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭匊"),l11l1l_l1_ (u"ࠧࠨ匋"),l11l1l_l1_ (u"ࠨࠩ匌"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ匍"),l11l1l_l1_ (u"ࠪࠫ匎")+addon_id+l11l1l_l1_ (u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ฿๐ัࠡ็ไ฽้ฯࠠฤ๊ࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠ࠯ࠢํะอࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศࠢ็็๏ฺ๊ࠦ็็ࠤฬ๊ศา่ส้ัูࠦ็ัๆࠤอ฻่าหูࠣา๐อสࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩ匏"))
		if l1ll11111l_l1_==1:
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡏ࡮ࡴࡶࡤࡰࡱࡇࡤࡥࡱࡱࠬࠬ匐")+addon_id+l11l1l_l1_ (u"࠭ࠩࠨ匑"))
			time.sleep(1)
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧ匒"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11l1l_l1_ (u"ࠨ࡙࡬ࡲࡩࡵࡷ࠯ࡋࡶࡅࡨࡺࡩࡷࡧࠫࡴࡷࡵࡧࡳࡧࡶࡷࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ匓")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ匔")+addon_id+l11l1l_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ匕"))
			if l11l1l_l1_ (u"ࠫࡔࡑࠧ化") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭北"),l11l1l_l1_ (u"࠭ࠧ匘"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ匙"),l11l1l_l1_ (u"ࠨฬ่ࠤๆำีࠡล๋ࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ์์๐ࠠศๆล๊ࠥาว่ิฬࠤ้๊วิฬัำฬ๋ࠧ匚"))
			elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ匛"),l11l1l_l1_ (u"ࠪࠫ匜"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ匝"),l11l1l_l1_ (u"ࠬ็ิๅࠢไ๎ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ࠳่ࠦศๆะ่ࠥํ่ࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ๊์ࠠฯษิะࠥอไษำ้ห๊าࠧ匞"))
	return succeeded
def l11lllllll11_l1_(addon_id,l1ll_l1_=True):
	l1l1l1l1l11l_l1_ = l1l111111l1l_l1_([addon_id])
	if addon_id not in list(l1l1l1l1l11l_l1_.keys()): return False
	l11l1l11111_l1_,l1l11111lll1_l1_,l1l11ll11l11_l1_,l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l1l111ll11l1_l1_,l11ll11l11ll_l1_ = l1l1l1l1l11l_l1_[addon_id]
	succeeded,l1l111ll1l11_l1_ = False,l11l1l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭匟")
	if l1l111ll11l1_l1_==l11l1l_l1_ (u"ࠧࡨࡱࡲࡨࠬ匠"):
		succeeded = True
		l1l111ll1l11_l1_ = l11l1l_l1_ (u"ࠨࡩࡲࡳࡩ࠭匡")
	elif l1l111ll11l1_l1_==l11l1l_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ匢"):
		succeeded = False
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭匣")+addon_id+l11l1l_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ匤"))
		if l11l1l_l1_ (u"ࠬࡕࡋࠨ匥") in result: succeeded = True
		if succeeded: l1l111ll1l11_l1_ = l11l1l_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧ匦")
	elif l1l111ll11l1_l1_==l11l1l_l1_ (u"ࠧࡰ࡮ࡧࠫ匧"):
		succeeded = l11lll1ll1l1_l1_(addon_id,l11ll11l11ll_l1_,l1ll_l1_)
		if succeeded: l1l111ll1l11_l1_ = l11l1l_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩ匨")
	elif l1l111ll11l1_l1_==l11l1l_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ匩"):
		l1l1111111l1_l1_ = l1l11lll1111_l1_(l1ll_l1_)
		if l1l1111111l1_l1_:
			succeeded = l1l111l11lll_l1_(addon_id,l1ll_l1_)
			if succeeded: l1l111ll1l11_l1_ = l11l1l_l1_ (u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭匪")
	l11ll1ll11ll_l1_ = l1l111ll1l1l_l1_
	return succeeded,l1l111ll1l11_l1_,l11ll1ll11ll_l1_
def l1l111l11ll1_l1_(l1l11l11l1l1_l1_=l11l1l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ匫"),l1ll_l1_=True):
	l11ll1ll1111_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ匬"))
	import json
	data = json.loads(l11ll1ll1111_l1_)
	l11ll1l1lll1_l1_ = data[l11l1l_l1_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭匭")][l11l1l_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭匮")]
	if kodi_version<19: l11ll1l1lll1_l1_ = l11ll1l1lll1_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭匯"))
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࠪ匰"),l11l1l_l1_ (u"ࠪࠫ匱"),l11l1l_l1_ (u"ࠫࠬ匲"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ匳"),l11l1l_l1_ (u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫ匴")+l11ll1l1lll1_l1_+l11l1l_l1_ (u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩ匵")+l1l11l11l1l1_l1_+l11l1l_l1_ (u"ࠨࠢยࠥࠬ匶"))
		if l1ll11111l_l1_!=1: return False
	succeeded,l1l111ll1l11_l1_,l11ll1ll11ll_l1_ = l11lllllll11_l1_(l1l11l11l1l1_l1_,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ匷"),l11l1l_l1_ (u"ࠪࠫ匸"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ匹"),l11l1l_l1_ (u"ࠬะๅหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆฯ่ิࠦวๅฮา๎ิ่่๊ࠦࠣะฬําࠡๆ็หุะฮะษ่ࠤ࠳ࠦำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥะฺ๋์ิࠤส฿ฯศัสฮ้่ࠥะ์่่ࠣ๐๋ࠠีอ฽๊๊ࠠศๆฯ่ิࠦวๅฮา๎ิࠦศะๆสࠤ๊์ࠠศๆๅำ๏๋ࠧ区"))
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠤࠪ医")+l1l11l11l1l1_l1_+l11l1l_l1_ (u"ࠧࠣࡿࢀࠫ匼"))
		if l11l1l_l1_ (u"ࠨࡑࡎࠫ匽") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩ匾"))
	elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ匿"),l11l1l_l1_ (u"ࠫࠬ區"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ十"),l11l1l_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨ卂"))
	return succeeded
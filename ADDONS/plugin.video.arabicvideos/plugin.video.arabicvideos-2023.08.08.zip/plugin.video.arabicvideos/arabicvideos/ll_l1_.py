# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䓶")
#l1ll1lllllll_l1_ = [ l11l1l_l1_ (u"ࠨ࡯ࡼࡷࡹࡸࡥࡢ࡯ࠪ䓷"),l11l1l_l1_ (u"ࠩࡹ࡭ࡲࡶ࡬ࡦࠩ䓸"),l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡢࡰ࡯ࠪ䓹"),l11l1l_l1_ (u"ࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩ䓺") ]
l1ll1lllllll_l1_ = []
headers = {l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䓻"):l11l1l_l1_ (u"࠭ࠧ䓼")}
def l11_l1_(l1lll1l1_l1_,source,type,url):
	#DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไาษห฻ࠥอไๆ่สือ࠭䓽"),l1lll1l1_l1_)
	if not l1lll1l1_l1_:
		LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䓾"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䓿")+source+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ䔀")+type+l11l1l_l1_ (u"ࠫࠥࡣࠧ䔁"))
		l1llll111lll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡪࡩࡤࡶࠪ䔂"),l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䔃"),l11l1l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䔄"))
		datetime = time.strftime(l11l1l_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ䔅"),time.gmtime(now))
		line = datetime,url
		key = source+l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ䔆")+addon_version+l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠨ䔇")+str(kodi_version)
		if key not in list(l1llll111lll_l1_.keys()): l1llll111lll_l1_[key] = [line]
		else: l1llll111lll_l1_[key].append(line)
		total = 0
		for key in list(l1llll111lll_l1_.keys()):
			l1llll111lll_l1_[key] = list(set(l1llll111lll_l1_[key]))
			total += len(l1llll111lll_l1_[key])
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䔈"),l11l1l_l1_ (u"ࠬ࠭䔉"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䔊"),l11l1l_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠧ䔋")+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䔌")+l11l1l_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ䔍")+str(total))
		if total>=7:
			l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫ䔎"),l11l1l_l1_ (u"ࠫࠬ䔏"),l11l1l_l1_ (u"ࠬ࠭䔐"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䔑"),l11l1l_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ䔒"))
			if l1ll11111l_l1_==1:
				l1llll11l11l_l1_ = l11l1l_l1_ (u"ࠨࠩ䔓")
				for key in list(l1llll111lll_l1_.keys()):
					l1llll11l11l_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ䔔")+key
					l1l1ll1l1lll_l1_ = sorted(l1llll111lll_l1_[key],reverse=False,key=lambda l11ll1l1111_l1_: l11ll1l1111_l1_[0])
					for datetime,url in l1l1ll1l1lll_l1_:
						l1llll11l11l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳ࠭䔕")+datetime+l11l1l_l1_ (u"ࠫࠥࠦࠠࠡࠩ䔖")+l1llll_l1_(url)
					l1llll11l11l_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䔗")
				import l1l1l1lll1ll_l1_
				l1ll11ll1l11_l1_ = l11l1l_l1_ (u"࠭ࡁࡗ࠼ࠣࠫ䔘")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"ࠧ࠮ࡘ࡬ࡨࡪࡵࡳࠨ䔙")
				succeeded = l1l1l1lll1ll_l1_.l1llll1ll1l1_l1_(l1ll11ll1l11_l1_,l11l1l_l1_ (u"ࠨࠩ䔚"),False,l11l1l_l1_ (u"ࠩࠪ䔛"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䔜"),l11l1l_l1_ (u"ࠫࠬ䔝"),l1llll11l11l_l1_)
				if succeeded: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䔞"),l11l1l_l1_ (u"࠭ࠧ䔟"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䔠"),l11l1l_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫ䔡"))
				else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䔢"),l11l1l_l1_ (u"ࠪࠫ䔣"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䔤"),l11l1l_l1_ (u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪ䔥"))
			if l1ll11111l_l1_!=-1:
				l1llll111lll_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䔦"),l11l1l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䔧"))
		if l1llll111lll_l1_: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䔨"),l11l1l_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ䔩"),l1llll111lll_l1_,PERMANENT_CACHE)
		return
	l1lll1l1_l1_ = list(set(l1lll1l1_l1_))
	l1ll1lll_l1_,l1lll1_l1_ = l1l1llll1111_l1_(l1lll1l1_l1_,source)
	l1l1ll1l1l1l_l1_ = str(l1lll1_l1_).count(l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䔪"))
	l1l1llll11ll_l1_ = str(l1lll1_l1_).count(l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䔫"))
	l1l1ll1ll11l_l1_ = len(l1lll1_l1_)-l1l1ll1l1l1l_l1_-l1l1llll11ll_l1_
	l1l1llllllll_l1_ = l11l1l_l1_ (u"๋ࠬิศ้าอ࠿࠭䔬")+str(l1l1ll1l1l1l_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࠣฮา๋๊ๅ࠼ࠪ䔭")+str(l1l1llll11ll_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠤศิั๊࠼ࠪ䔮")+str(l1l1ll1ll11l_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䔯"),l11l1l_l1_ (u"ࠩࠪ䔰"),str(l1l1ll1l1l1l_l1_),str(l1l1llll11ll_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1l1llllllll_l1_, l1lll1_l1_)
	if not l1lll1_l1_:
		result = l11l1l_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䔱")
		l11111l1l1l_l1_ = l11l1l_l1_ (u"ࠫࠬ䔲")
	else:
		while True:
			l11111l1l1l_l1_ = l11l1l_l1_ (u"ࠬ࠭䔳")
			if len(l1lll1_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1l1llllllll_l1_,l1ll1lll_l1_)
			if l1l_l1_==-1: result = l11l1l_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ䔴")
			else:
				title = l1ll1lll_l1_[l1l_l1_]
				l1llll1_l1_ = l1lll1_l1_[l1l_l1_]
				#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䔵"),l11l1l_l1_ (u"ࠨࠩ䔶"),title,l1llll1_l1_)
				if l11l1l_l1_ (u"ࠩึ๎ึ็ัࠨ䔷") in title and l11l1l_l1_ (u"ࠪ࠶๊า็้ๆ࠵ࠫ䔸") in title:
					LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䔹"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ䔺")+title+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䔻")+l1llll1_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ䔼"))
					import l1l1l1lll1ll_l1_
					l1l1l1lll1ll_l1_.MAIN(156)
					result = l11l1l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䔽")
				else:
					LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䔾"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ䔿")+title+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䕀")+l1llll1_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ䕁"))
					result,l11111l1l1l_l1_,l11l11111l1_l1_ = l1ll1111ll1l_l1_(l1llll1_l1_,source,type)
					#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䕂"),l11l1l_l1_ (u"ࠧࠨ䕃"),result,l11111l1l1l_l1_)
			if l11l1l_l1_ (u"ࠨ࡞ࡱࠫ䕄") not in l11111l1l1l_l1_: l1lllllll1ll_l1_,l1lllllll1l1_l1_ = l11111l1l1l_l1_,l11l1l_l1_ (u"ࠩࠪ䕅")
			else: l1lllllll1ll_l1_,l1lllllll1l1_l1_ = l11111l1l1l_l1_.split(l11l1l_l1_ (u"ࠪࡠࡳ࠭䕆"),1)
			if result in [l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䕇"),l11l1l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䕈"),l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ䕉"),l11l1l_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ䕊")] or len(l1lll1_l1_)==1: break
			elif result in [l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ䕋"),l11l1l_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ䕌"),l11l1l_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ䕍")]: break
			elif result not in [l11l1l_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ䕎"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ䕏")]: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䕐"),l11l1l_l1_ (u"ࠧࠨ䕑"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䕒"),l11l1l_l1_ (u"ࠩสุ่๐ัโำฺ่๊๊ࠣࠦ็็ࠤัืศࠡีํีๆืࠠ฻์ิ๋ࠬ䕓")+l11l1l_l1_ (u"ࠪࡠࡳ࠭䕔")+l1lllllll1ll_l1_+l11l1l_l1_ (u"ࠫࡡࡴࠧ䕕")+l1lllllll1l1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䕖"),l11l1l_l1_ (u"࠭ࠧ䕗"),l11l1l_l1_ (u"ࠧࠨ䕘"),str(l11l11111l1_l1_))
	if result==l11l1l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䕙") and len(l1ll1lll_l1_)>0: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䕚"),l11l1l_l1_ (u"ࠪࠫ䕛"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕜"),l11l1l_l1_ (u"ู๊ࠬาใิࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣะึฮࠠโ์า๎ํฺ๋ࠦำ๊ࠫ䕝")+l11l1l_l1_ (u"࠭࡜࡯ࠩ䕞")+l11111l1l1l_l1_)
	elif result in [l11l1l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䕟"),l11l1l_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䕠")] and l11111l1l1l_l1_!=l11l1l_l1_ (u"ࠩࠪ䕡"): DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䕢"),l11l1l_l1_ (u"ࠫࠬ䕣"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䕤"),l11111l1l1l_l1_)
	#elif l11111l1l1l_l1_==l11l1l_l1_ (u"࠭ࡒࡆࡖࡘࡖࡓࡥࡔࡐࡡ࡜ࡓ࡚࡚ࡕࡃࡇࠪ䕥"): result = l11l11111l1_l1_
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࡵࡩࡸࡻ࡬ࡵࠢ࡬ࡲࠥࡡࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ࠱࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪࡡ࠿ࠐࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡘࡪࡹࡴ࠻ࠢࠣࠤࠬ࠱ࡳࡺࡵ࠱ࡥࡷ࡭ࡶ࡜࠲ࡠ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠲࡞ࠫࠍࠍࠎࡾࡢ࡮ࡥࡳࡰࡺ࡭ࡩ࡯࠰ࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫࡥࡩࡪ࡯࡯ࡡ࡫ࡥࡳࡪ࡬ࡦ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠣࡼࡧࡳࡣࡨࡷ࡬࠲ࡑ࡯ࡳࡵࡋࡷࡩࡲ࠮ࠩࠪࠌࠌࠍࡵࡲࡡࡺࡡ࡬ࡸࡪࡳࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭ࡶࡡࡵࡪࡀࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡄࡳ࡯ࡥࡧࡀ࠵࠹࠹ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࠫ࠳ࡇࡸࠨ࠷ࡉ࡭ࡷࡣ࠳ࡳࡼ࡛ࡺࡷ࠺ࡓࠪ࠭ࠏࠏࠉࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡱ࡮ࡤࡽ࠭࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡮ࡹ࠵࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮࠱࡬ࡴ࡭ࡵ࡮ࡦ࠱࠴࠶࠸࠺࠴࠸࠰ࡰࡴ࠹࠭ࠬࡱ࡮ࡤࡽࡤ࡯ࡴࡦ࡯ࠬࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪฮ๊ࠦวๅษ็฾ฬวࠧ࠭ࠩࠪ࠭ࠏࠏࠢࠣࠤ䕦")
	return result
	#if source==l11l1l_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ䕧"): l1111l_l1_ = l11l1l_l1_ (u"ࠩࡋࡐࡆ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䕨")
	#elif source==l11l1l_l1_ (u"ࠪ࠸ࡍࡋࡌࡂࡎࠪ䕩"): l1111l_l1_ = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡈࡆࡎࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䕪")
	#elif source==l11l1l_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䕫"): l1111l_l1_ = l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡃࡎࡑࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䕬")
	#elif source==l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ䕭"): l1111l_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡗࡍ࠺ࠠࠨ䕮")
	#size = len(l1ll1l1l11_l1_)
	#for i in range(0,size):
	#	title = l11111l11l1_l1_[i]
	#	l1llll1_l1_ = l1ll1l1l11_l1_[i]
	#	addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕯"),l1111l_l1_+title,l1llll1_l1_,160,l11l1l_l1_ (u"ࠪࠫ䕰"),l11l1l_l1_ (u"ࠫࠬ䕱"),source)
def l1ll1111ll1l_l1_(url,source,type=l11l1l_l1_ (u"ࠬ࠭䕲")):
	url = url.strip(l11l1l_l1_ (u"࠭ࠠࠨ䕳")).strip(l11l1l_l1_ (u"ࠧࠧࠩ䕴")).strip(l11l1l_l1_ (u"ࠨࡁࠪ䕵")).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ䕶"))
	l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll111l1l_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䕷"),l11l1l_l1_ (u"ࠫࠬ䕸"),url,l11111l1l1l_l1_)
	if l11111l1l1l_l1_==l11l1l_l1_ (u"ࠬࡋࡘࡊࡖࠪ䕹"): return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	elif l1lll1_l1_:
		while True:
			if len(l1lll1_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䕺"), l1ll1lll_l1_)
			if l1l_l1_==-1: result = l11l1l_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ䕻")
			else:
				l1ll1l1l111l_l1_ = l1lll1_l1_[l1l_l1_]
				title = l1ll1lll_l1_[l1l_l1_]
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䕼"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡳࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠾ࠥࡡࠠࠨ䕽")+title+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ䕾")+str(l1ll1l1l111l_l1_)+l11l1l_l1_ (u"ࠫࠥࡣࠧ䕿"))
				if l11l1l_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䖀") in l1ll1l1l111l_l1_ and l11l1l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭䖁") in l1ll1l1l111l_l1_:
					l1ll1lll11ll_l1_,l111llll1l1_l1_,l11l11111l1_l1_ = l1llll1l1l1l_l1_(l1ll1l1l111l_l1_)
					if l11l11111l1_l1_: l1ll1l1l111l_l1_ = l11l11111l1_l1_[0]
					else: l1ll1l1l111l_l1_ = l11l1l_l1_ (u"ࠧࠨ䖂")
				if not l1ll1l1l111l_l1_: result = l11l1l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䖃")
				else: result = PLAY_VIDEO(l1ll1l1l111l_l1_,source,type)
			if result in [l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䖄"),l11l1l_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ䖅")] or len(l1lll1_l1_)==1: break
			elif result in [l11l1l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䖆"),l11l1l_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭䖇"),l11l1l_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ䖈")]: break
			else: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䖉"),l11l1l_l1_ (u"ࠨࠩ䖊"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䖋"),l11l1l_l1_ (u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩ䖌"))
	else:
		result = l11l1l_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䖍")
		l111ll1l11_l1_ = l11l1l1ll1_l1_(url)
		if l111ll1l11_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11111l1l1l_l1_,l1lll1_l1_
	#title = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱࠨ䖎") )
	#if l11l1l_l1_ (u"࠭ำ๋ำไีࠥ฿วๆ่ࠢะ์๎ไࠨ䖏") in title:
	#	import l1l1l1lll1ll_l1_
	#	l1l1l1lll1ll_l1_.MAIN(156)
	#	return l11l1l_l1_ (u"ࠧࠨ䖐")
def l1l1l1l1ll11_l1_(url,source):
	# url = url+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䖑")+name+l11l1l_l1_ (u"ࠩࡢࡣࠬ䖒")+type+l11l1l_l1_ (u"ࠪࡣࡤ࠭䖓")+l11ll1l_l1_+l11l1l_l1_ (u"ࠫࡤࡥࠧ䖔")+l111ll1l_l1_
	# url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡫ࡸࡣࡰ࠲ࡳ࡫ࡴࡀࡰࡤࡱࡪࡪ࠽ࡢ࡭ࡺࡥࡲࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟࡮ࡲ࠷ࡣࡤ࠽࠲࠱ࠩ䖕")
	l111ll1_l1_,l1lllll111ll_l1_,server,l1ll1l1ll1ll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_ = url,l11l1l_l1_ (u"࠭ࠧ䖖"),l11l1l_l1_ (u"ࠧࠨ䖗"),l11l1l_l1_ (u"ࠨࠩ䖘"),l11l1l_l1_ (u"ࠩࠪ䖙"),l11l1l_l1_ (u"ࠪࠫ䖚"),l11l1l_l1_ (u"ࠫࠬ䖛"),l11l1l_l1_ (u"ࠬ࠭䖜")
	#source = source.lower()
	if l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䖝") in url:
		l111ll1_l1_,l1lllll111ll_l1_ = url.split(l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䖞"),1)
		l1lllll111ll_l1_ = l1lllll111ll_l1_+l11l1l_l1_ (u"ࠨࡡࡢࠫ䖟")+l11l1l_l1_ (u"ࠩࡢࡣࠬ䖠")+l11l1l_l1_ (u"ࠪࡣࡤ࠭䖡")+l11l1l_l1_ (u"ࠫࡤࡥࠧ䖢")
		l1lllll111ll_l1_ = l1lllll111ll_l1_.lower()
		name,type,l11ll1l_l1_,l111ll1l_l1_,l1l1ll1lll11_l1_ = l1lllll111ll_l1_.split(l11l1l_l1_ (u"ࠬࡥ࡟ࠨ䖣"))[:5]
	if l111ll1l_l1_==l11l1l_l1_ (u"࠭ࠧ䖤"): l111ll1l_l1_ = l11l1l_l1_ (u"ࠧ࠱ࠩ䖥")
	else: l111ll1l_l1_ = l111ll1l_l1_.replace(l11l1l_l1_ (u"ࠨࡲࠪ䖦"),l11l1l_l1_ (u"ࠩࠪ䖧")).replace(l11l1l_l1_ (u"ࠪࠤࠬ䖨"),l11l1l_l1_ (u"ࠫࠬ䖩"))
	l111ll1_l1_ = l111ll1_l1_.strip(l11l1l_l1_ (u"ࠬࡅࠧ䖪")).strip(l11l1l_l1_ (u"࠭࠯ࠨ䖫")).strip(l11l1l_l1_ (u"ࠧࠧࠩ䖬"))
	server = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠨࡪࡲࡷࡹ࠭䖭"))
	if name: l1ll1l1ll1ll_l1_ = name
	#elif source: l1ll1l1ll1ll_l1_ = source
	else: l1ll1l1ll1ll_l1_ = server
	l1ll1l1ll1ll_l1_ = SERVER(l1ll1l1ll1ll_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䖮"))
	name = name.replace(l11l1l_l1_ (u"้ࠪออิาࠩ䖯"),l11l1l_l1_ (u"ࠫࠬ䖰")).replace(l11l1l_l1_ (u"ู๊ࠬาใิࠫ䖱"),l11l1l_l1_ (u"࠭ࠧ䖲")).replace(l11l1l_l1_ (u"ࠧศๆࠣࠫ䖳"),l11l1l_l1_ (u"ࠨࠢࠪ䖴")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ䖵"),l11l1l_l1_ (u"ࠪࠤࠬ䖶"))
	l1lllll111ll_l1_ = l1lllll111ll_l1_.replace(l11l1l_l1_ (u"๊ࠫฮวีำࠪ䖷"),l11l1l_l1_ (u"ࠬ࠭䖸")).replace(l11l1l_l1_ (u"࠭ำ๋ำไีࠬ䖹"),l11l1l_l1_ (u"ࠧࠨ䖺")).replace(l11l1l_l1_ (u"ࠨษ็ࠤࠬ䖻"),l11l1l_l1_ (u"ࠩࠣࠫ䖼")).replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭䖽"),l11l1l_l1_ (u"ࠫࠥ࠭䖾"))
	l1ll1l1ll1ll_l1_ = l1ll1l1ll1ll_l1_.replace(l11l1l_l1_ (u"๋ࠬศศึิࠫ䖿"),l11l1l_l1_ (u"࠭ࠧ䗀")).replace(l11l1l_l1_ (u"ࠧิ์ิๅึ࠭䗁"),l11l1l_l1_ (u"ࠨࠩ䗂")).replace(l11l1l_l1_ (u"ࠩส่ࠥ࠭䗃"),l11l1l_l1_ (u"ࠪࠤࠬ䗄")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ䗅"),l11l1l_l1_ (u"ࠬࠦࠧ䗆"))
	return l111ll1_l1_,l1lllll111ll_l1_,server,l1ll1l1ll1ll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_
def l111111l1ll_l1_(url,source):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䗇"),l11l1l_l1_ (u"ࠧࠨ䗈"),url,l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡂࡄࡏࡉࠬ䗉"))
	# l1lll11l1_l1_	: سيرفر خاص
	# l1llllll11ll_l1_		: سيرفر محدد
	# l1lllll1111l_l1_		: سيرفر عام معروف
	# l1ll1l111_l1_	: سيرفر عام خارجي
	# l1l1ll1ll1ll_l1_	: سيرفر عام خارجي
	l1ll1l111lll_l1_,name,l1lll11l1_l1_,l1lllll1111l_l1_,l1ll1l111_l1_,l1llllll11ll_l1_,l1l1ll1ll1ll_l1_ = l11l1l_l1_ (u"ࠩࠪ䗊"),l11l1l_l1_ (u"ࠪࠫ䗋"),None,None,None,None,None
	l111ll1_l1_,l1lllll111ll_l1_,server,l1ll1l1ll1ll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_ = l1l1l1l1ll11_l1_(url,source)
	if l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䗌") in url:
		if   type==l11l1l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧࠫ䗍"): type = l11l1l_l1_ (u"࠭ࠠࠨ䗎")+l11l1l_l1_ (u"ࠧๆใู่ࠬ䗏")
		elif type==l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ䗐"): type = l11l1l_l1_ (u"ࠩࠣࠫ䗑")+l11l1l_l1_ (u"ฺ๊ࠪࠩว่ัฬࠫ䗒")
		elif type==l11l1l_l1_ (u"ࠫࡧࡵࡴࡩࠩ䗓"): type = l11l1l_l1_ (u"ࠬࠦࠧ䗔")+l11l1l_l1_ (u"࠭ࠥࠦ็ืห์ีษ๊ࠡอั๊๐ไࠨ䗕")
		elif type==l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䗖"): type = l11l1l_l1_ (u"ࠨࠢࠪ䗗")+l11l1l_l1_ (u"ࠩࠨࠩࠪะอๆ์็ࠫ䗘")
		elif type==l11l1l_l1_ (u"ࠪࠫ䗙"): type = l11l1l_l1_ (u"ࠫࠥ࠭䗚")+l11l1l_l1_ (u"ࠬࠫࠥࠦࠧࠪ䗛")
		if l11ll1l_l1_!=l11l1l_l1_ (u"࠭ࠧ䗜"):
			if l11l1l_l1_ (u"ࠧ࡮ࡲ࠷ࠫ䗝") not in l11ll1l_l1_: l11ll1l_l1_ = l11l1l_l1_ (u"ࠨࠧࠪ䗞")+l11ll1l_l1_
			l11ll1l_l1_ = l11l1l_l1_ (u"ࠩࠣࠫ䗟")+l11ll1l_l1_
		if l111ll1l_l1_!=l11l1l_l1_ (u"ࠪࠫ䗠"):
			l111ll1l_l1_ = l11l1l_l1_ (u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧ䗡")+l111ll1l_l1_
			l111ll1l_l1_ = l11l1l_l1_ (u"ࠬࠦࠧ䗢")+l111ll1l_l1_[-9:]
	#if any(value in server for value in l1ll1lllllll_l1_): return l11l1l_l1_ (u"࠭ࠧ䗣")
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䗤"),l11l1l_l1_ (u"ࠨࠩ䗥"),name,l1ll1l1ll1ll_l1_)
	if   l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䗦")		in source: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䗧")		in source: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ䗨")
	elif l11l1l_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䗩")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䗪")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭䗫")	in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ䗬")		in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䗭")
	#elif l11l1l_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡶࡸࡦࡺࡩࡰࡰࠪ䗮") in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䗯")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ䗰")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	#elif l11l1l_l1_ (u"࠭ࡰࡤࡴࡨࡺ࡮࡫ࡷࠨ䗱")	in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ䗲")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠨࡶ࠺ࡱࡪ࡫࡬ࠨ䗳")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ䗴")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ䗵")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䗶")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢࠨ䗷")	in name:   l1lll11l1_l1_	= l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨ䗸")
	elif l11l1l_l1_ (u"ࠧโฮิࠫ䗹")			in name:   l1lll11l1_l1_	= l11l1l_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䗺")
	elif l11l1l_l1_ (u"ࠩไุ่฽๊็ࠩ䗻")		in name:   l1lll11l1_l1_	= l11l1l_l1_ (u"ࠪࡴࡦࡲࡥࡴࡶ࡬ࡲࡪ࠭䗼")
	elif l11l1l_l1_ (u"ࠫ࡬ࡪࡲࡪࡸࡨࠫ䗽")		in l111ll1_l1_:   l1lll11l1_l1_	= l11l1l_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬ䗾")
	elif l11l1l_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䗿")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ䘀")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䘁")		in name:   l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ䘂")	in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ䘃")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䘄")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ䘅")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ䘆")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䘇")		in server: l1lll11l1_l1_	= l1ll1l1ll1ll_l1_
	#elif l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭䘈")	in l111ll1_l1_:   l1lll11l1_l1_	= l11l1l_l1_ (u"ࠩࠣࠫ䘉")
	elif l11l1l_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ䘊")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭䘋")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ䘌")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭䘍")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䘎")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ䘏")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ䘐")	 	in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ䘑")
	elif l11l1l_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ䘒")	 	in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䘓")
	elif l11l1l_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䘔")	in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ䘕")
	elif l11l1l_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ䘖")		in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ䘗")
	elif l11l1l_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ䘘")		in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䘙")
	elif l11l1l_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䘚")	in server: l1lll11l1_l1_	= l11l1l_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䘛")
	elif l11l1l_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ䘜")	in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ䘝")
	elif l11l1l_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䘞")		in server: l1lll11l1_l1_	= l11l1l_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䘟")
	elif l11l1l_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ䘠")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ䘡")
	elif l11l1l_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ䘢")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䘣")
	elif l11l1l_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䘤")	 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠩࡦࡥࡹࡩࡨࠨ䘥")
	elif l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䘦")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ䘧")
	elif l11l1l_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ䘨")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ䘩")
	elif l11l1l_l1_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭䘪")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧ䘫")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ䘬")		in server: l1llllll11ll_l1_	= l1ll1l1ll1ll_l1_
	elif l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ䘭")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䘮")
	elif l11l1l_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ䘯")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ䘰")
	elif l11l1l_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ䘱") 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ䘲")
	elif l11l1l_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ䘳")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䘴")
	elif l11l1l_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ䘵")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ䘶")
	elif l11l1l_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ䘷") 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ䘸")
	elif l11l1l_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ䘹")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䘺")
	elif l11l1l_l1_ (u"ࠪࡹࡵࡶࠧ䘻") 			in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ䘼")
	elif l11l1l_l1_ (u"ࠬࡻࡰࡣࠩ䘽") 			in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ䘾")
	elif l11l1l_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䘿") 		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䙀")
	elif l11l1l_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䙁") 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䙂")
	elif l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䙃")		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ䙄")
	elif l11l1l_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭䙅") 		in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ䙆")
	elif l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ䙇") 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䙈")
	elif l11l1l_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䙉")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ䙊")
	elif l11l1l_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ䙋")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䙌")
	#elif l11l1l_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ䙍") 	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ䙎")
	#elif l11l1l_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭䙏")	in server: l1lllll1111l_l1_	= l11l1l_l1_ (u"ࠪࡹࡵࡺ࡯ࡴࡶࡵࡩࡦࡳࠧ䙐")
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡶࡴ࡯࠯ࠬࡃ࠽࠾ࠩ࠮ࡹࡷࡲ࠲ࠪࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠴ࡈࡰࡵࡷࡩࡩࡓࡥࡥ࡫ࡤࡊ࡮ࡲࡥࠩࡷࡵࡰ࠷࠯࠮ࡷࡣ࡯࡭ࡩࡥࡵࡳ࡮ࠫ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࡴ࠽ࠎࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠱࠲࠳࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠭ࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡌࡡ࡭ࡵࡨࠎࠎࠏࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡲ࠮ࡰࡴࡪࠎࠎࠏࠉ࡭࡫ࡶࡸࡤࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡵࡦ࡯࠱ࡴࡸࡧ࠯ࡩ࡬ࡸ࡭ࡻࡢ࠯࡫ࡲ࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠰ࡵࡸࡴࡵࡵࡲࡵࡧࡧࡷ࡮ࡺࡥࡴ࠰࡫ࡸࡲࡲࠧࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮࡯࡭ࡸࡺ࡟ࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊ࡙ࡏࡍࡘࡄࡆࡑࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࡟࠵ࡣ࠮࡭ࡱࡺࡩࡷ࠮ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࡬ࡪࡀࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠳࠴࠵࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࠌࡴࡦࡸࡴࡴࠢࡀࠤࡸ࡫ࡲࡷࡧࡵ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠳࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡲࡤࡶࡹ࠯࠼࠵࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࠌࡩࡱ࡯ࡦࠡࡲࡤࡶࡹࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࠍࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠍࠎࠏࠉࠊࡤࡵࡩࡦࡱࠊࠊࠤࠥࠦ䙑")
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䙒"),l11l1l_l1_ (u"࠭ࠧ䙓"),url,l111ll1_l1_)
	if   l1lll11l1_l1_:	l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ࠧฯษุࠫ䙔"),l1lll11l1_l1_
	elif l1llllll11ll_l1_:		l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ࠨ่ࠧัิีࠧ䙕"),l1llllll11ll_l1_
	elif l1lllll1111l_l1_:		l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ䙖"),l1lllll1111l_l1_
	elif l1ll1l111_l1_:	l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ䙗"),l1ll1l111_l1_
	elif l1l1ll1ll1ll_l1_:	l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ䙘"),l1ll1l1ll1ll_l1_
	else:			l1ll1l111lll_l1_,name = l11l1l_l1_ (u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭䙙"),l1ll1l1ll1ll_l1_
	return l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_
	l11l1l_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉࡱࡴ࡬ࡺࡦࡺࡥࠡ࠿ࠣࠫ࡭࡫࡬ࡢ࡮ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠍࠍࡪࡲࡩࡧࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸࡨࡺࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠢࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡩࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠎࠎࠨࠢࠣ䙚")
def l1ll111ll1ll_l1_(url,source):
	l111ll1_l1_,l1lllll111ll_l1_,server,l1ll1l1ll1ll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_ = l1l1l1l1ll11_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䙛"),l11l1l_l1_ (u"ࠨࠩ䙜"),l1llllll11ll_l1_,server)
	#if l11l1l_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ䙝")	in server: l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ䙞"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䙟"))
	#if any(value in server for value in l1ll1lllllll_l1_): l1ll1lll_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡅࡔࡑࡏ࡚ࡊࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࠢࡷ࡬࡮ࡹࠠࡴࡧࡵࡺࡪࡸࠧ䙠")],[]
	if   l11l1l_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ䙡")		in source: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11lll1_l1_(l111ll1_l1_,name)
	elif l11l1l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭䙢")		in source: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll11_l1_(l111ll1_l1_,type,l111ll1l_l1_)
	elif l11l1l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䙣")		in source: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ䙤")		in source: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll1lll_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ䙥")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1l1111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ䙦")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l11l11_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ䙧")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11111111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ䙨")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1lll111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ䙩")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1lll111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ䙪")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1lll1l_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ䙫")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll1l1ll1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ䙬")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1ll1ll11_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ䙭")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1ll1ll11_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䙮")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1lll1111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䙯")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll11111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䙰")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll111lll_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䙱")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll11llll_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ䙲")			in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111llll111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䙳")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l11l11_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䙴")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l1111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡰ࡮࡭ࡨࡵࠩ䙵")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l111l_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ䙶")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l111l_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ䙷")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111lll1ll1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ䙸")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1lll1l111_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ䙹")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1111111l_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䙺")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11ll1llll_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䙻")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ䙼")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡺࡥࡤࡪࠪ䙽")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l111l1_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ䙾")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111l1l1l_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䙿")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠩࠪ䚀"),[l11l1l_l1_ (u"ࠪࠫ䚁")],[l111ll1_l1_]
	elif l11l1l_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䚂")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111111l1l_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ䚃")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll1lll1ll_l1_(l111ll1_l1_)
	elif l11l1l_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䚄") 		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠧࠨ䚅"),[l11l1l_l1_ (u"ࠨࠩ䚆")],[l111ll1_l1_]
	else: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䚇"),[l11l1l_l1_ (u"ࠪࠫ䚈")],[l111ll1_l1_]
	return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
def l1llll1lllll_l1_(url,source):
	server = SERVER(url,l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䚉"))
	#if l11l1l_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ䚊")	in server: l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭䚋"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䚌"))
	#if any(value in server for value in l1ll1lllllll_l1_): l1ll1lll_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ䚍")],[]
	l1ll111ll1l1_l1_ = False
	if   l11l1l_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ䚎")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111111ll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ䚏")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l111111ll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴࠨ䚐") in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l1lllll_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫ䚑")	in url: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll111111l_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ䚒")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l111l1_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䚓")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11ll1llll_l1_(url)
	elif l11l1l_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䚔")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll1l1l1l_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ䚕")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l111l1_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭䚖")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11ll1111_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䚗")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l11l11l1_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䚘")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l1111ll_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭䚙")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll1llll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭䚚")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll111111_l1_(url)
	elif l11l1l_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ䚛")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll111111_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ䚜")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䚝")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ䚞")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ䚟")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䚠")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"ࠧ࡭࡫࡬࡭ࡻ࡯ࡤࡦࡱࠪ䚡")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡴࡨࡡࠨ䚢")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1l1l111_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡹ࡭ࡩࡹࡰࡦࡧࡧࠫ䚣")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1l1l111_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ䚤") 		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠫࠬ䚥"),[l11l1l_l1_ (u"ࠬ࠭䚦")],[url]
	#elif l11l1l_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ䚧")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l11l111l_l1_(url)
	elif l11l1l_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ䚨") 	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1lllll11_l1_(url)
	elif l11l1l_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ䚩")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll11lllll_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࡨࡰࠩ䚪")in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l1l1ll1_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䚫") 	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll11ll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䚬")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11l11l11_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡻࡰࡣࠩ䚭") 			in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1111lll_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡵࡱࡲࠪ䚮") 			in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1111lll_l1_(url)
	#elif l11l1l_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ䚯") 	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11lllll1_l1_(url)
	#elif l11l1l_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ䚰")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11lllll1_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ䚱") 		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1lll1llll_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䚲") 	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1lll1ll1_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䚳")		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11l111ll_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ䚴") 		in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll11111lll_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ䚵") 	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1lll11l1l1l_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䚶")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1llll11l1_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䚷")	in server: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll1l1111l1_l1_(url)
	else: l1ll111ll1l1_l1_ = True
	if l1ll111ll1l1_l1_ or l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠫ䚸") in l11111l1l1l_l1_:
		l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠢࡉࡥ࡮ࡲࡥࡥࠩ䚹"),[],[]
	return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡉࡘ࡚ࡒࡆࡃࡐࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡈࡑࡘࡒࡑࡏࡍࡊࡖࡈࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡋࡑࡘࡔ࡛ࡐࡍࡑࡄࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡔࡉࡇ࡙ࡍࡉࡋࡏࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡦࡸ࠱࡭ࡴ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡈ࡚ࡎࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡍࡋࡌࡂࡎࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡍࡉࡈࡏࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡍࡊࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡘࡎࡁࡓࡇࠫࡹࡷࡲࠩࠋࠋࠥࠦࠧ䚺")
def	l1ll1ll1lll1_l1_(l11l111l1ll_l1_):
	if l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ䚻") in str(type(l11l111l1ll_l1_)):
		l1l1_l1_ = []
		for l1llll1_l1_ in l11l111l1ll_l1_:
			if l11l1l_l1_ (u"࠭ࡳࡵࡴࠪ䚼") in str(type(l1llll1_l1_)):
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧ࡝ࡴࠪ䚽"),l11l1l_l1_ (u"ࠨࠩ䚾")).replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ䚿"),l11l1l_l1_ (u"ࠪࠫ䛀")).strip(l11l1l_l1_ (u"ࠫࠥ࠭䛁"))
			l1l1_l1_.append(l1llll1_l1_)
	else: l1l1_l1_ = l11l111l1ll_l1_.replace(l11l1l_l1_ (u"ࠬࡢࡲࠨ䛂"),l11l1l_l1_ (u"࠭ࠧ䛃")).replace(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ䛄"),l11l1l_l1_ (u"ࠨࠩ䛅")).strip(l11l1l_l1_ (u"ࠩࠣࠫ䛆"))
	return l1l1_l1_
def l1l1ll111l1l_l1_(url,source):
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䛇"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䛈")+url+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ䛉"))
	l1l1ll1ll1ll_l1_,l1llll1_l1_,l1ll1ll1llll_l1_ = l11l1l_l1_ (u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䛊"),l11l1l_l1_ (u"ࠧࠨ䛋"),l11l1l_l1_ (u"ࠨࠩ䛌")
	l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1ll111ll1ll_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䛍"),l11l1l_l1_ (u"ࠪࠫ䛎"),l11l1l_l1_ (u"ࠫࠬ䛏"),l11111l1l1l_l1_)
	l1lll1_l1_ = l1ll1ll1lll1_l1_(l1lll1_l1_)
	if l11111l1l1l_l1_==l11l1l_l1_ (u"ࠬࡋࡘࡊࡖࠪ䛐"): return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	elif l1lll1_l1_: l1llll1_l1_ = l1lll1_l1_[0]
	if l11111l1l1l_l1_==l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䛑"):
		#l11111l1l1l_l1_ = l11111l1l1l_l1_.replace(l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䛒"),l11l1l_l1_ (u"ࠨࠩ䛓"))
		l1l1ll1ll1ll_l1_ = l11l1l_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ䛔")
		l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll1lllll_l1_(l1llll1_l1_,source)
		l1lll1_l1_ = l1ll1ll1lll1_l1_(l1lll1_l1_)
		if l11111l1l1l_l1_==l11l1l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䛕"): return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
		elif l11l1l_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠳ࠪ䛖") in l11111l1l1l_l1_:
			l1ll1ll1llll_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥ࠭䛗")+l11111l1l1l_l1_
			l1l1ll1ll1ll_l1_ = l11l1l_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ䛘")
			l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1llll1llll1_l1_(l1llll1_l1_,source)
			l1lll1_l1_ = l1ll1ll1lll1_l1_(l1lll1_l1_)
			if l11111l1l1l_l1_==l11l1l_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䛙"): return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
			elif l11l1l_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ䛚") in l11111l1l1l_l1_:
				l1ll1ll1llll_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠪ䛛")+l11111l1l1l_l1_
				l1l1ll1ll1ll_l1_ = l11l1l_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䛜")
				l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11111l1l11_l1_(l1llll1_l1_,source)
				l1lll1_l1_ = l1ll1ll1lll1_l1_(l1lll1_l1_)
				if l11111l1l1l_l1_==l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䛝"): return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
				elif l11l1l_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫ䛞") in l11111l1l1l_l1_:
					l1ll1ll1llll_l1_ += l11l1l_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠷࠿ࠦࠧ䛟")+l11111l1l1l_l1_
	elif l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠩ䛠") in l11111l1l1l_l1_: l1ll1ll1llll_l1_ = l11l1l_l1_ (u"ࠨࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠴࠿ࠦࠧ䛡")+l11111l1l1l_l1_
	if l1lll1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䛢"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨࠥࠦࠠࡓࡧࡶࡳࡱࡼࡥࡳ࠼ࠣ࡟ࠥ࠭䛣")+l1l1ll1ll1ll_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䛤")+url+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ䛥")+l1llll1_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡳࡶ࡮ࡷࡷ࠿࡛ࠦࠡࠩ䛦")+str(l1lll1_l1_)+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ䛧"))
	else: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䛨"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ䛩")+url+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䛪")+l1llll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡈࡶࡷࡵࡲࡴ࠼ࠣ࡟ࠥ࠭䛫")+l1ll1ll1llll_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ䛬"))
	l1ll1ll1llll_l1_ = l1llll_l1_(l1ll1ll1llll_l1_)
	return l1ll1ll1llll_l1_,l1ll1lll_l1_,l1lll1_l1_
def l1l1llll1111_l1_(l11l11111l1_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䛭"),l11l11111l1_l1_)
	l1l1ll1111l1_l1_ = l1llll1l_l1_
	data = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䛮"),l11l1l_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䛯"),l11l11111l1_l1_)
	if data:
		l1ll1lll_l1_,l1lll1_l1_ = list(zip(*data))
		return l1ll1lll_l1_,l1lll1_l1_
	l1ll1lll_l1_,l1lll1_l1_,l11111l11l1_l1_ = [],[],[]
	for l1llll1_l1_ in l11l11111l1_l1_:
		if l11l1l_l1_ (u"ࠩ࠲࠳ࠬ䛰") not in l1llll1_l1_: continue
		l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_ = l111111l1ll_l1_(l1llll1_l1_,source)
		l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡠࡩ࠱ࠧ䛱"),l111ll1l_l1_,re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = int(l111ll1l_l1_[0])
		else: l111ll1l_l1_ = 0
		#if l111ll1l_l1_:
		#	l1llll1l11ll_l1_ = sorted(l111ll1l_l1_,reverse=True,key=lambda key: int(key))
		#	l111ll1l_l1_ = int(l1llll1l11ll_l1_[0])
		#else: l111ll1l_l1_ = 0
		server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䛲"))
		l11111l11l1_l1_.append([l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_,l1llll1_l1_,server])
	if l11111l11l1_l1_:
		#l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_,l1llll1_l1_ = zip(*l11111l11l1_l1_)
		#name = reversed(name)
		#l11111l11l1_l1_ = zip(l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_,l1llll1_l1_)
		l1ll1lll1111_l1_ = sorted(l11111l11l1_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1ll1ll11lll_l1_ = []
		for line in l1ll1lll1111_l1_:
			if line not in l1ll1ll11lll_l1_:
				l1ll1ll11lll_l1_.append(line)
				#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭䛳"),str(line))
		for l1ll1l111lll_l1_,name,type,l11ll1l_l1_,l111ll1l_l1_,l1llll1_l1_,server in l1ll1ll11lll_l1_:
			if l111ll1l_l1_: l111ll1l_l1_ = str(l111ll1l_l1_)
			else: l111ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ䛴")
			#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䛵"),l11l1l_l1_ (u"ࠨࠩ䛶"),name,l1llll1_l1_)
			title = l11l1l_l1_ (u"ࠩึ๎ึ็ัࠨ䛷")+l11l1l_l1_ (u"ࠪࠤࠬ䛸")+type+l11l1l_l1_ (u"ࠫࠥ࠭䛹")+l1ll1l111lll_l1_+l11l1l_l1_ (u"ࠬࠦࠧ䛺")+l111ll1l_l1_+l11l1l_l1_ (u"࠭ࠠࠨ䛻")+l11ll1l_l1_+l11l1l_l1_ (u"ࠧࠡࠩ䛼")+name
			if server not in title: title = title+l11l1l_l1_ (u"ࠨࠢࠪ䛽")+server
			title = title.replace(l11l1l_l1_ (u"ࠩࠨࠫ䛾"),l11l1l_l1_ (u"ࠪࠫ䛿")).strip(l11l1l_l1_ (u"ࠫࠥ࠭䜀")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠨ䜁"),l11l1l_l1_ (u"࠭ࠠࠨ䜂")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ䜃"),l11l1l_l1_ (u"ࠨࠢࠪ䜄")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ䜅"),l11l1l_l1_ (u"ࠪࠤࠬ䜆"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1ll1lll_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		if l1lll1_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ䜇"),l1lll1_l1_)
			data = list(zip(l1ll1lll_l1_,l1lll1_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䜈"),l11l11111l1_l1_,data,l1l1ll1111l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䜉"),l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠿࠸࠺ࠡࠢࠣࠫ䜊")+str(data))
	return l1ll1lll_l1_,l1lll1_l1_
def	l1llll1llll1_l1_(url,source):
	#url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡇࡧࡗࡠ࡬ࡨࡲࡴࢀࡋࡤࠩ䜋")
	l1lll11111ll_l1_ = l11l1l_l1_ (u"ࠩࠪ䜌")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l1llllll1l11_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lll11111ll_l1_ = str(error)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䜍"),l11l1l_l1_ (u"ࠫࠬ䜎"),l11l1l_l1_ (u"ࠬ࠭䜏"),str(results))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䜐"),l11l1l_l1_ (u"ࠧࠨ䜑"),l11l1l_l1_ (u"ࠨࠩ䜒"),str(l1lll11111ll_l1_))
	# resolveurl l11111llll_l1_ l1lll11l1ll_l1_ l1ll1l1l1111_l1_ with l1l1l11lllll_l1_ error or l1ll1lll1l1l_l1_ value False
	if not results:
		if l1lll11111ll_l1_==l11l1l_l1_ (u"ࠩࠪ䜓"):
			l1lll11111ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll11111ll_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䜔"),l11l1l_l1_ (u"ࠫࠬ䜕"),l11l1l_l1_ (u"ࠬ࠭䜖"),str(l1lll11111ll_l1_))
		l11111l1l1l_l1_ = l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠥࡌࡡࡪ࡮ࡨࡨࠬ䜗")
		l11111l1l1l_l1_ += l11l1l_l1_ (u"ࠧࠡࠩ䜘")+l1lll11111ll_l1_.splitlines()[-1]
		return l11111l1l1l_l1_,[],[]
	return l11l1l_l1_ (u"ࠨࠩ䜙"),[l11l1l_l1_ (u"ࠩࠪ䜚")],[results]
def	l11111l1l11_l1_(url,source):
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡂࡢ࡙ࡢ࡮ࡪࡴ࡯ࡻࡍࡦࠫ䜛")
	#url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰ࠳ࡻ࡯ࡤࡦࡱ࠲ࡼ࠼ࡿࡹ࠵࠳ࡶࠫ䜜")
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䜝"),l11l1l_l1_ (u"࠭ࠧ䜞"),url,l11l1l_l1_ (u"ࠧࠨ䜟"))
	#return l11l1l_l1_ (u"ࠨࠩ䜠"),[],[]
	l1lll11111ll_l1_ = l11l1l_l1_ (u"ࠩࠪ䜡")
	results = False
	try:
		import youtube_dl
		l1111111l11_l1_ = youtube_dl.YoutubeDL({l11l1l_l1_ (u"ࠪࡲࡴࡥࡣࡰ࡮ࡲࡶࠬ䜢"): True})
		results = l1111111l11_l1_.extract_info(url,download=False)
	except Exception as error: l1lll11111ll_l1_ = str(error)
	# youtube_dl l11111llll_l1_ l1lll11l1ll_l1_ l1ll1l1l1111_l1_ with l1l1l11lllll_l1_ error or l1ll1lll1l1l_l1_ value False
	if not results or l11l1l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ䜣") not in list(results.keys()):
		if l1lll11111ll_l1_==l11l1l_l1_ (u"ࠬ࠭䜤"):
			l1lll11111ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll11111ll_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䜥"),l11l1l_l1_ (u"ࠧࠨ䜦"),l11l1l_l1_ (u"ࠨࠩ䜧"),l1lll11111ll_l1_)
		l11111l1l1l_l1_ = l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䜨")
		l11111l1l1l_l1_ += l11l1l_l1_ (u"ࠪࠤࠬ䜩")+l1lll11111ll_l1_.splitlines()[-1]
		return l11111l1l1l_l1_,[],[]
	else:
		l1ll1lll_l1_,l1lll1_l1_ = [],[]
		for l1llll1_l1_ in results[l11l1l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ䜪")]:
			l1ll1lll_l1_.append(l1llll1_l1_[l11l1l_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬ䜫")])
			l1lll1_l1_.append(l1llll1_l1_[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䜬")])
		return l11l1l_l1_ (u"ࠧࠨ䜭"),l1ll1lll_l1_,l1lll1_l1_
def l11111111l1_l1_(url):
	if l11l1l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䜮") in url:
		l1ll1lll_l1_,l1lll1_l1_ = l11l1lllll_l1_(url)
		if l1lll1_l1_: return l11l1l_l1_ (u"ࠩࠪ䜯"),l1ll1lll_l1_,l1lll1_l1_
		return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡌࡂࡔࡄࡆࠬ䜰"),[],[]
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䜱"),[l11l1l_l1_ (u"ࠬ࠭䜲")],[url]
def l1l1l1l1111_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䜳"),l11l1l_l1_ (u"ࠧࠨ䜴"),l11l1l_l1_ (u"ࠨࠩ䜵"),url)
	l1lll1l1_l1_,l1ll1l11lll1_l1_ = [],[]
	if l11l1l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵ࠱ࡱࡵ࠺࠿ࡷ࡫ࡧࡁࠬ䜶") in url:
		# l1lll11ll1ll_l1_:
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1l1ll1llll1_l1_.html
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l11ll11111_l1_.l11111ll_l1_?l1l1l1l1l11_l1_=49e3a27b4
		# l1ll11ll1lll_l1_: https://l1ll1llll11l_l1_.l1lll1ll11l_l1_.l1l1l11ll111_l1_.l1lll1lll1l_l1_/15/items/40animeHD/l1ll1lll111l_l1_.l11111ll_l1_
		# l1lll11ll1ll_l1_:
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1ll1111l111_l1_-l1lll111l11l_l1_.html
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l11ll11111_l1_.l11111ll_l1_?l1l1l1l1l11_l1_=l1l1l1ll1lll_l1_
		# l1ll11ll1lll_l1_: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l11ll11111_l1_/l1ll1ll1111l_l1_%20.l11111ll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䜷"),url,l11l1l_l1_ (u"ࠫࠬ䜸"),l11l1l_l1_ (u"ࠬ࠭䜹"),False,l11l1l_l1_ (u"࠭ࠧ䜺"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠷ࡳࡵࠩ䜻"))
		if l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䜼") in response.headers:
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䜽")]
			l1lll1l1_l1_.append(l1llll1_l1_)
			server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ䜾"))
			l1ll1l11lll1_l1_.append(server)
	elif l11l1l_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯ࠪ䜿") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l1lll11ll1ll_l1_:
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_1lllllll11l_l1_.html
		# l1llll1_l1_: https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1111111lll_l1_/?l1llll1_l1_=https://drive.l1l1ll1l1ll1_l1_.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l1lllll11ll1_l1_&l1l1l1l1llll_l1_=
		# l1lll11ll1ll_l1_:
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1llll1_l1_: https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1l1111ll_l1_.l1ll1l1lll_l1_?url=l1l1l1l111l1_l1_==&sub=https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1lll1l111l1_l1_/l1l1l1l11111_l1_.l1l1l1llll1l_l1_&l1l1l1l1llll_l1_=https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1l1lll1l11l_l1_/l1l1l111l1ll_l1_-1.l1ll111111l1_l1_
		# l1lll11ll1ll_l1_:
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1ll1l1lll1l_l1_.html
		# l1llll1_l1_: https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1ll1l111l11_l1_/?url=https://photos.l1llllll1111_l1_.l1lll11l1lll_l1_.l1111l1l11l_l1_/l1ll1llll111_l1_&sub=&l1l1l1l1llll_l1_=http://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1l1lll1l11l_l1_/4723b8ebe-1.l1ll111111l1_l1_
		# l1lll11ll1ll_l1_:
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l1111111111_l1_.html
		# https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1111111lll_l1_/?l1llll1_l1_=https://l1lll1l1l111_l1_.l1l1ll1l1ll1_l1_.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l1lllll11ll1_l1_&sub=&l1l1l1l1llll_l1_=https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1l1lll1l11l_l1_/2e8bc4c34-1.l1ll111111l1_l1_
		# l1lll11ll1ll_l1_:
		# https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1ll111l1lll_l1_.html
		# https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1111111lll_l1_/?l1llll1_l1_=https://drive.l1l1ll1l1ll1_l1_.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l1lllll1l111_l1_=l1lllll11l1l_l1_&l1l1l1l1llll_l1_=https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1l1lll1l11l_l1_/l1lll11ll1l1_l1_-1.l1ll111111l1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䝀"),url,l11l1l_l1_ (u"࠭ࠧ䝁"),l11l1l_l1_ (u"ࠧࠨ䝂"),l11l1l_l1_ (u"ࠨࠩ䝃"),l11l1l_l1_ (u"ࠩࠪ䝄"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠴ࡱࡨࠬ䝅"))
		html = response.content
		l1ll11ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࡨࡡ࠯࠮ࠫࡁ࡟࠭ࡡ࠯ࠩ࠯࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ䝆"),html,re.DOTALL)
		#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭䝇"),str(l1ll11ll1l1l_l1_))
		if l1ll11ll1l1l_l1_:
			l1ll11ll1l1l_l1_ = l1ll11ll1l1l_l1_[0]
			l1l1llll1l11_l1_ = l1ll11111l1l_l1_(l1ll11ll1l1l_l1_)
			#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䝈"),str(l1l1llll1l11_l1_))
			l1l1lll1l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬ䝉"),l1l1llll1l11_l1_,re.DOTALL)
			if l1l1lll1l1l1_l1_:
				l1l1lll1l1l1_l1_ = l1l1lll1l1l1_l1_[0]
				l1l1lll1l1l1_l1_ = EVAL(l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䝊"),l1l1lll1l1l1_l1_)
				for dict in l1l1lll1l1l1_l1_:
					l1llll1_l1_ = dict[l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠧ䝋")]
					l111ll1l_l1_ = dict[l11l1l_l1_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ䝌")]
					#l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࡤࡥࠧ䝍")+l111ll1l_l1_
					l1lll1l1_l1_.append(l1llll1_l1_)
					server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䝎"))
					l1ll1l11lll1_l1_.append(l111ll1l_l1_+l11l1l_l1_ (u"࠭ࠠࠨ䝏")+server)
		elif l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䝐") in response.headers:
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䝑")]
			l1lll1l1_l1_.append(l1llll1_l1_)
			server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䝒"))
			l1ll1l11lll1_l1_.append(server)
		# l1lll11ll1ll_l1_: 5
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1ll1l1lll1l_l1_.html
		# l1llll1_l1_: https://www.l1l1l1l11l1_l1_.com/l1l1l1ll1ll1_l1_/l1ll1l111l11_l1_/?url=https://photos.l1llllll1111_l1_.l1lll11l1lll_l1_.l1111l1l11l_l1_/l1ll1llll111_l1_&sub=&l1l1l1l1llll_l1_=http://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1ll11l111_l1_/l1l1lll1l11l_l1_/4723b8ebe-1.l1ll111111l1_l1_
		if l11l1l_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࡰࡱࠪ䝓") in url:
			l1llll1_l1_ = url.split(l11l1l_l1_ (u"ࠫࡄࡻࡲ࡭࠿ࠪ䝔"))[1]
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠬࠬࠧ䝕"))[0]
			if l1llll1_l1_:
				l1lll1l1_l1_.append(l1llll1_l1_)
				l1ll1l11lll1_l1_.append(l11l1l_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸࠦࡧࡰࡱࡪࡰࡪ࠭䝖"))
	else:
		# l1lll11ll1ll_l1_:
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1l1l1l1ll1l_l1_.html
		# l1llll1_l1_: http://ok.l1lll11ll111_l1_/l1lll1lll111_l1_/1676019108395
		# l1lll11ll1ll_l1_:
		# url: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1l1l1ll1l1l_l1_.html
		# l1llll1_l1_: https://drive.l1l1ll1l1ll1_l1_.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l1lllll11ll1_l1_
		l1lll1l1_l1_.append(url)
		server = SERVER(url,l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䝗"))
		l1ll1l11lll1_l1_.append(server)
	if not l1lll1l1_l1_: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ䝘"),[],[]
	elif len(l1lll1l1_l1_)==1: l1llll1_l1_ = l1lll1l1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䝙"),l1ll1l11lll1_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䝚"),[],[]
		l1llll1_l1_ = l1lll1l1_l1_[l1l_l1_]
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䝛"),[l11l1l_l1_ (u"ࠬ࠭䝜")],[l1llll1_l1_]
def l1ll1l1lllll_l1_(url):
	# test from: https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1lllll1l1ll_l1_-l1ll1ll111ll_l1_-l1ll11lll111_l1_-l1l1llll1lll_l1_-l1ll11111111_l1_-l11ll11111_l1_-1-date.html
	# url = https://l1llll11l1l1_l1_.l1l1l111ll11_l1_.com/l1ll11l1llll_l1_=l1lll1111l1l_l1_
	headers = {l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䝝"):l11l1l_l1_ (u"ࠧࡌࡱࡧ࡭࠴࠭䝞")+str(kodi_version)}
	for l11l1ll1l1_l1_ in range(50):
		time.sleep(0.100)
		response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䝟"),url,l11l1l_l1_ (u"ࠩࠪ䝠"),headers,False,l11l1l_l1_ (u"ࠪࠫ䝡"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ䝢"))
		if l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䝣") in list(response.headers.keys()):
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䝤")]
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭䝥")+headers[l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䝦")]
			return l11l1l_l1_ (u"ࠩࠪ䝧"),[l11l1l_l1_ (u"ࠪࠫ䝨")],[l1llll1_l1_]
		if response.code!=429: break
	return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪ䝩"),[],[]
def l1lll111111l_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䝪"),l11l1l_l1_ (u"࠭ࠧ䝫"),l11l1l_l1_ (u"ࠧࠨ䝬"),url)
	# https://photos.l1llllll1111_l1_.l1lll11l1lll_l1_.l1111l1l11l_l1_/l1ll1llll111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䝭"),url,l11l1l_l1_ (u"ࠩࠪ䝮"),l11l1l_l1_ (u"ࠪࠫ䝯"),l11l1l_l1_ (u"ࠫࠬ䝰"),l11l1l_l1_ (u"ࠬ࠭䝱"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅ࠮࠳ࡶࡸࠬ䝲"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳࠰࠿ࠪࠤ࠯࠲࠯ࡅࠬ࠯ࠬࡂ࠰࠭࠴ࠪࡀࠫ࠯ࠫ䝳"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_,l111ll1l_l1_ = l1llll1_l1_[0]
		return l11l1l_l1_ (u"ࠨࠩ䝴"),[l111ll1l_l1_],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡕࡎࡏࡕࡑࡖࡋࡔࡕࡇࡍࡇࠪ䝵"),[],[]
def l1ll1l111l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䝶"),l11l1l_l1_ (u"ࠫࠬ䝷"),l11l1l_l1_ (u"ࠬ࠭䝸"),url)
	#url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡵ࡮ࡦ࠱ࡹ࡭ࡩ࡫࡯ࡠࡲ࡯ࡥࡾ࡫ࡲࡀࡷ࡬ࡨࡂ࠶ࠦࡷ࡫ࡧࡁ࡫࡬ࡢ࠸࠲࠻ࡧ࠶࠿࠲ࡤ࠴࠻ࡨ࠶࠷࠲࠱࠴ࡤࡨ࠶࠾ࡤࡥ࠳࠵ࡧ࠻࠾࠰࠷ࠩ䝹")
	#url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡷࡪࡲࡨࡥ࠯ࡨࡱࡧ࡫ࡤ࠯ࡵࡦࡨࡳ࠴ࡴࡰ࠱ࡹ࡭ࡩ࡫࡯ࡠࡲ࡯ࡥࡾ࡫ࡲࡀࡷ࡬ࡨࡂ࠶ࠦࡷ࡫ࡧࡁࡧ࠶࠱࠶࠻࠳࠸ࡦ࠾ࡡࡤࡨ࠺࠽࠺࠼ࡤ࠲ࡧ࠺࠺࠸࠶ࡢࡦ࠳࠺࠺࠺࠾࠷࠴ࠩ䝺")
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䝻"),url,l11l1l_l1_ (u"ࠩࠪ䝼"),l11l1l_l1_ (u"ࠪࠫ䝽"),l11l1l_l1_ (u"ࠫࠬ䝾"),l11l1l_l1_ (u"ࠬ࠭䝿"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨ䞀"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11l1l_l1_ (u"ࠧࠨ䞁"),html)
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䞂"),html,re.DOTALL)
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠩࠪ䞃"),[l11l1l_l1_ (u"ࠪࠫ䞄")],[l1llll1_l1_[0]]
	return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ䞅"),[],[]
def l1llll1lll_l1_(url):
	if l11l1l_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ䞆") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䞇"),url,l11l1l_l1_ (u"ࠧࠨ䞈"),l11l1l_l1_ (u"ࠨࠩ䞉"),l11l1l_l1_ (u"ࠩࠪ䞊"),l11l1l_l1_ (u"ࠪࠫ䞋"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅ࠹࡛࠭࠲ࡵࡷࠫ䞌"))
		html = response.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䞍"),html,re.DOTALL)
		l1llll1_l1_ = l1llll1_l1_[0]
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䞎") in l1llll1_l1_: return l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䞏"),[l11l1l_l1_ (u"ࠨࠩ䞐")],[l1llll1_l1_]
		return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂ࠶ࡘࠫ䞑"),[],[]
	else: return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䞒"),[l11l1l_l1_ (u"ࠫࠬ䞓")],[url]
def l1lll1l1ll1_l1_(url):
	l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䞔"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䞕"),l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䞖"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䞗")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䞘"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ䞙"),l11l1l_l1_ (u"ࠫࠬ䞚"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡓࡕࡗ࠮࠳ࡶࡸࠬ䞛"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䞜"),html,re.DOTALL)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡔࡏࡘࠩ䞝"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䞞"),[l11l1l_l1_ (u"ࠩࠪ䞟")],[l1llll1_l1_]
def l1l1ll111lll_l1_(url):
	headers = {l11l1l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䞠"):l11l1l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䞡")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䞢"),url,l11l1l_l1_ (u"࠭ࠧ䞣"),headers,l11l1l_l1_ (u"ࠧࠨ䞤"),l11l1l_l1_ (u"ࠨࠩ䞥"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡑࡉࡔࡗࡕ࠭࠲ࡵࡷࠫ䞦"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䞧"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡑࡒࡊࡕࡘࡏࠨ䞨"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䞩"),[l11l1l_l1_ (u"࠭ࠧ䞪")],[l1llll1_l1_]
def l1l1lll1111_l1_(url):
	l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䞫"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䞬")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䞭"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ䞮"),l11l1l_l1_ (u"ࠫࠬ䞯"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡊࡄࡐࡆࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ䞰"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ䞱"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡋࡅࡑࡇࡃࡊࡏࡄࠫ䞲"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䞳") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䞴")+l1llll1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䞵"),l11l1l_l1_ (u"ࠫࠬ䞶"),l11l1l_l1_ (u"ࠬ࠭䞷"),l1llll1_l1_)
	return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䞸"),[l11l1l_l1_ (u"ࠧࠨ䞹")],[l1llll1_l1_]
def l1lll11111_l1_(url):
	l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䞺"):l11l1l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䞻")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䞼"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠫࠬ䞽"),l11l1l_l1_ (u"ࠬ࠭䞾"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨ䞿"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭䟀"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡂࡄࡇࡓࠬ䟁"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䟂"),[l11l1l_l1_ (u"ࠪࠫ䟃")],[l1llll1_l1_]
def l1ll1ll1ll11_l1_(url):
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䟄"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䟅"),url,l11l1l_l1_ (u"࠭ࠧ䟆"),l11l1l_l1_ (u"ࠧࠨ䟇"),l11l1l_l1_ (u"ࠨࠩ䟈"),l11l1l_l1_ (u"ࠩࠪ䟉"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ䟊"))
	html = response.content
	l1l1l1l1lll1_l1_ = re.findall(l11l1l_l1_ (u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ䟋"),html,re.DOTALL|re.IGNORECASE)
	if l1l1l1l1lll1_l1_:
		l1l1l1l1lll1_l1_ = l1l1l1l1lll1_l1_[0][2:]
		#l1l1l1l1lll1_l1_ = l1l1l1l1lll1_l1_.decode(l11l1l_l1_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬ䟌"))
		l1l1l1l1lll1_l1_ = base64.b64decode(l1l1l1l1lll1_l1_)
		if kodi_version>18.99: l1l1l1l1lll1_l1_ = l1l1l1l1lll1_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䟍"))
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䟎"),l1l1l1l1lll1_l1_,re.DOTALL)
	else: l1llll1_l1_ = l11l1l_l1_ (u"ࠨࠩ䟏")
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪ䟐"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䟑") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䟒")+l1llll1_l1_
	return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䟓"),[l11l1l_l1_ (u"࠭ࠧ䟔")],[l1llll1_l1_]
def l1l1ll11llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䟕"),url,l11l1l_l1_ (u"ࠨࠩ䟖"),l11l1l_l1_ (u"ࠩࠪ䟗"),l11l1l_l1_ (u"ࠪࠫ䟘"),l11l1l_l1_ (u"ࠫࠬ䟙"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧ䟚"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䟛"),html,re.DOTALL)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫ䟜"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䟝"),[l11l1l_l1_ (u"ࠩࠪ䟞")],[l1llll1_l1_]
def l11ll1llll_l1_(url):
	id = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ䟟"))[-1]
	if l11l1l_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ䟠") in url: url = url.replace(l11l1l_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ䟡"),l11l1l_l1_ (u"࠭ࠧ䟢"))
	url = url.replace(l11l1l_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴࠭䟣"),l11l1l_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩ䟤"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䟥"),url,l11l1l_l1_ (u"ࠪࠫ䟦"),l11l1l_l1_ (u"ࠫࠬ䟧"),l11l1l_l1_ (u"ࠬ࠭䟨"),l11l1l_l1_ (u"࠭ࠧ䟩"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ䟪"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ䟫"),url)
	l11111l1l1l_l1_ = l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ䟬")
	error = re.findall(l11l1l_l1_ (u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䟭"),html,re.DOTALL)
	if error: l11111l1l1l_l1_ = error[0]
	url = re.findall(l11l1l_l1_ (u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䟮"),html,re.DOTALL)
	if not url and l11111l1l1l_l1_:
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䟯"),l11l1l_l1_ (u"࠭ࠧ䟰"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠩ䟱"),l11111l1l1l_l1_)
		return l11111l1l1l_l1_,[],[]
	l1llll1_l1_ = url[0].replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ䟲"),l11l1l_l1_ (u"ࠩࠪ䟳"))
	l111llll1l1_l1_,l11l11111l1_l1_ = l11l1lllll_l1_(l1llll1_l1_)
	owner = re.findall(l11l1l_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䟴"),html,re.DOTALL)
	if owner: l1ll11l1ll11_l1_,l11111111ll_l1_,l1lll1l1llll_l1_ = owner[0]
	else: l1ll11l1ll11_l1_,l11111111ll_l1_,l1lll1l1llll_l1_ = l11l1l_l1_ (u"ࠫࠬ䟵"),l11l1l_l1_ (u"ࠬ࠭䟶"),l11l1l_l1_ (u"࠭ࠧ䟷")
	l1lll1l1llll_l1_ = l1lll1l1llll_l1_.replace(l11l1l_l1_ (u"ࠧ࡝࠱ࠪ䟸"),l11l1l_l1_ (u"ࠨ࠱ࠪ䟹"))
	l11111111ll_l1_ = escapeUNICODE(l11111111ll_l1_)
	l1ll1lll_l1_ = [l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭䟺")+l11111111ll_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䟻")]+l111llll1l1_l1_
	l1lll1_l1_ = [l1lll1l1llll_l1_]+l11l11111l1_l1_
	l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬ䟼")+str(len(l1lll1_l1_)-1)+l11l1l_l1_ (u"ࠬࠦๅๅใࠬࠫ䟽"),l1ll1lll_l1_)
	if l1l_l1_==-1: return l11l1l_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䟾"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11l1l_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭䟿")+l1lll1l1llll_l1_+l11l1l_l1_ (u"ࠨࠨࡷࡩࡽࡺ࠽ࠨ䠀")+l11111111ll_l1_
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ䠁")+new_path+l11l1l_l1_ (u"ࠥ࠭ࠧ䠂"))
		return l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䠃"),[],[]
	l1llll1_l1_ =  l1lll1_l1_[l1l_l1_]
	return l11l1l_l1_ (u"ࠬ࠭䠄"),[l11l1l_l1_ (u"࠭ࠧ䠅")],[l1llll1_l1_]
def l1111111l_l1_(l1llll1_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䠆"),l1llll1_l1_,l11l1l_l1_ (u"ࠨࠩ䠇"),l11l1l_l1_ (u"ࠩࠪ䠈"),l11l1l_l1_ (u"ࠪࠫ䠉"),l11l1l_l1_ (u"ࠫࠬ䠊"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄࡒࡏࡗࡇ࠭࠲ࡵࡷࠫ䠋"))
	html = response.content
	if l11l1l_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬ䠌") in l1llll1_l1_: url = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䠍"),html,re.DOTALL)
	else: url = re.findall(l11l1l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䠎"),html,re.DOTALL)
	if not url: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇࡕࡋࡓࡃࠪ䠏"),[],[]
	url = url[0]
	if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䠐") not in url: url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䠑")+url
	return l11l1l_l1_ (u"ࠬ࠭䠒"),[l11l1l_l1_ (u"࠭ࠧ䠓")],[url]
def l1llll1l1l1l_l1_(url):
	# http://l1ll111lll1l_l1_.l1l1ll1lll1l_l1_/l111111l1l1_l1_.html?l1llllll11ll_l1_=l1ll1ll11l1l_l1_
	# http://l1ll111lll1l_l1_.l1l1ll1lll1l_l1_/l1ll1l11l1l1_l1_?op=l1l1l11ll1ll_l1_&id=l111111l1l1_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䠔") : l11l1l_l1_ (u"ࠨࠩ䠕") }
	if l11l1l_l1_ (u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ䠖") in url:
		html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠪࠫ䠗"),headers,l11l1l_l1_ (u"ࠫࠬ䠘"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧ䠙"))
		#xbmc.log(html)
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䠚"),l11l1l_l1_ (u"ࠧࠨ䠛"),url,html)
		items = re.findall(l11l1l_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䠜"),html,re.DOTALL)
		if items: return l11l1l_l1_ (u"ࠩࠪ䠝"),[l11l1l_l1_ (u"ࠪࠫ䠞")],[items[0]]
		else:
			message = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䠟"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䠠"),l11l1l_l1_ (u"࠭ࠧ䠡"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩ䠢"),message[0])
				return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩ䠣")+message[0],[],[]
	else:
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䠤"),l11l1l_l1_ (u"ࠪࠫ䠥"),l1llll1_l1_,l11l1l_l1_ (u"ࠫࠬ䠦"))
		#url,l1ll1ll1l11_l1_ = url.split(l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䠧"))
		#l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_.lower()
		l1ll1ll1l11_l1_ = l11l1l_l1_ (u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠩ䠨")
		# l11l1l111_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ䠩"),headers,l11l1l_l1_ (u"ࠨࠩ䠪"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫ䠫"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ䠬"),html,re.DOTALL)
		if not l1l11ll_l1_: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ䠭"),[],[]
		l1llll11ll_l1_ = l1l11ll_l1_[0][0]
		block = l1l11ll_l1_[0][1]
		if l11l1l_l1_ (u"ࠬ࠴ࡲࡢࡴࠪ䠮") in block or l11l1l_l1_ (u"࠭࠮ࡻ࡫ࡳࠫ䠯") in block: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬ䠰"),[],[]
		items = re.findall(l11l1l_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䠱"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll11lll_l1_(payload)
		html = OPENURL_CACHED(l1ll1ll11_l1_,l1llll11ll_l1_,data,headers,l11l1l_l1_ (u"ࠩࠪ䠲"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬ䠳"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩ䠴"),html,re.DOTALL)
		if not l1l11ll_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ䠵"),[],[]
		download = l1l11ll_l1_[0][0]
		block = l1l11ll_l1_[0][1]
		items = re.findall(l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭䠶"),block,re.DOTALL)
		l1l1ll1ll111_l1_,l1ll1lll_l1_,l1lllll11l11_l1_,l1lll1_l1_,l1ll1111l1ll_l1_ = [],[],[],[],[]
		for l1llll1_l1_,title in items:
			if l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭䠷") in l1llll1_l1_:
				l1l1ll1ll111_l1_,l1lllll11l11_l1_ = l11l1lllll_l1_(l1llll1_l1_)
				l1lll1_l1_ = l1lll1_l1_ + l1lllll11l11_l1_
				if l1l1ll1ll111_l1_[0]==l11l1l_l1_ (u"ࠨ࠯࠴ࠫ䠸"): l1ll1lll_l1_.append(l11l1l_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ䠹")+l11l1l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ䠺")+l1ll1ll1l11_l1_)
				else:
					for title in l1l1ll1ll111_l1_:
						l1ll1lll_l1_.append(l11l1l_l1_ (u"ู๊ࠫࠥาใิࠤำอีࠡࠩ䠻")+l11l1l_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠫ䠼")+l1ll1ll1l11_l1_+l11l1l_l1_ (u"࠭ࠠࠨ䠽")+title)
			else:
				title = title.replace(l11l1l_l1_ (u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩ䠾"),l11l1l_l1_ (u"ࠨࠩ䠿"))
				title = title.strip(l11l1l_l1_ (u"ࠩࠥࠫ䡀"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䡁"),l11l1l_l1_ (u"ࠫࠬ䡂"),title,str(l1ll1111l1ll_l1_))
				title = l11l1l_l1_ (u"ࠬࠦำ๋ำไีࠥࠦฮศืࠣࠫ䡃")+l11l1l_l1_ (u"࠭ࠠ࡮ࡲ࠷ࠤࠬ䡄")+l1ll1ll1l11_l1_+l11l1l_l1_ (u"ࠧࠡࠩ䡅")+title
				l1ll1lll_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		# download l1l1_l1_
		l1llll1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧࠪ䡆") + download
		html = OPENURL_CACHED(l1ll1ll11_l1_,l1llll1_l1_,l11l1l_l1_ (u"ࠩࠪ䡇"),headers,l11l1l_l1_ (u"ࠪࠫ䡈"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠸ࡸ࡭࠭䡉"))
		items = re.findall(l11l1l_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭ࠤ䡊"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11l1l_l1_ (u"࠭ࠠิ์ิๅึࠦสฮ็ํ่ࠥิวึࠢࠪ䡋")+l11l1l_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭䡌")+l1ll1ll1l11_l1_+l11l1l_l1_ (u"ࠨࠢࠪ䡍")+resolution.split(l11l1l_l1_ (u"ࠩࡻࠫ䡎"))[1]
			l1llll1_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡪ࡬ࡀࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠪ࡮ࡪ࠽ࠨ䡏")+id+l11l1l_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ䡐")+mode+l11l1l_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ䡑")+hash
			l1ll1111l1ll_l1_.append(resolution)
			l1ll1lll_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		l1ll1111l1ll_l1_ = set(l1ll1111l1ll_l1_)
		l1ll11l1111l_l1_,l1lll1ll11ll_l1_ = [],[]
		for title in l1ll1lll_l1_:
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䡒"),l11l1l_l1_ (u"ࠧࠨ䡓"),title,l11l1l_l1_ (u"ࠨࠩ䡔"))
			res = re.findall(l11l1l_l1_ (u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤ䡕"),title+l11l1l_l1_ (u"ࠪࠪࠫ࠭䡖"),re.DOTALL)
			for resolution in l1ll1111l1ll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11l1l_l1_ (u"ࠫࡽ࠭䡗"))[1])
			l1ll11l1111l_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1lll1_l1_)):
			items = re.findall(l11l1l_l1_ (u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨ䡘"),l11l1l_l1_ (u"࠭ࠦࠧࠩ䡙")+l1ll11l1111l_l1_[i]+l11l1l_l1_ (u"ࠧࠧࠨࠪ䡚"),re.DOTALL)
			l1lll1ll11ll_l1_.append( [l1ll11l1111l_l1_[i],l1lll1_l1_[i],items[0][0],items[0][1]] )
		l1lll1ll11ll_l1_ = sorted(l1lll1ll11ll_l1_, key=lambda x: x[3], reverse=True)
		l1lll1ll11ll_l1_ = sorted(l1lll1ll11ll_l1_, key=lambda x: x[2], reverse=False)
		l1ll1lll_l1_,l1lll1_l1_ = [],[]
		for i in range(len(l1lll1ll11ll_l1_)):
			l1ll1lll_l1_.append(l1lll1ll11ll_l1_[i][0])
			l1lll1_l1_.append(l1lll1ll11ll_l1_[i][1])
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䡛"),[],[]
	return l11l1l_l1_ (u"ࠩࠪ䡜"),l1ll1lll_l1_,l1lll1_l1_
def l1lll1llll1l_l1_(url):
	# http://l1l1l11ll1l1_l1_.com/717254
	parts = url.split(l11l1l_l1_ (u"ࠪࡃࠬ䡝"))
	l111ll1_l1_ = parts[0]
	headers = { l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䡞") : l11l1l_l1_ (u"ࠬ࠭䡟") }
	html = OPENURL_CACHED(l1ll1ll11_l1_,l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧ䡠"),headers,l11l1l_l1_ (u"ࠧࠨ䡡"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨ䡢"))
	items = re.findall(l11l1l_l1_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ䡣"),html,re.DOTALL)
	url = items[0]
	#l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll11ll11_l1_(url)
	#return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䡤"),[l11l1l_l1_ (u"ࠫࠬ䡥")],[url]
def l1ll1l1111ll_l1_(url):
	# https://l1llll1l1l1_l1_.l1lll1lll1l_l1_/l1llll1ll1l_l1_
	# https://l1lll1llll1_l1_.cc/l1llll1ll1l_l1_
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䡦") : l11l1l_l1_ (u"࠭ࠧ䡧") }
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠧࠨ䡨"),headers,l11l1l_l1_ (u"ࠨࠩ䡩"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䡪"))
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䡫"),html,re.DOTALL)
	if l111ll1_l1_: return l11l1l_l1_ (u"ࠫࠬ䡬"),[l11l1l_l1_ (u"ࠬ࠭䡭")],[l111ll1_l1_[0]]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩ䡮"),[],[]
def l1llll111111_l1_(url):
	# https://l1llll1l1l1_l1_.l1lll1lll1l_l1_/l1llll1ll1l_l1_
	# https://l1lll1llll1_l1_.cc/l1llll1ll1l_l1_
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䡯") : l11l1l_l1_ (u"ࠨࠩ䡰") }
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠩࠪ䡱"),headers,l11l1l_l1_ (u"ࠪࠫ䡲"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ䡳"))
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࠥ࠰ࠧ࠮ࡨࡵࡶ࠱࠮ࡄ࠯ࠢࠨ䡴"),html,re.DOTALL)
	if l111ll1_l1_: return l11l1l_l1_ (u"࠭ࠧ䡵"),[l11l1l_l1_ (u"ࠧࠨ䡶")],[l111ll1_l1_[0]]
	else: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩ䡷"),[],[]
def l1ll1l11l11_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䡸"),l11l1l_l1_ (u"ࠪࠫ䡹"),l11l1l_l1_ (u"ࠫࠬ䡺"),url)
	# l11l1l111_l1_    https://show.l1ll11ll111l_l1_.com/l1ll11l11ll1_l1_-l1ll11l111l1_l1_/l1ll11l111l1_l1_-l1lll111l1ll_l1_.l1ll1l1lll_l1_?action=l1ll1111ll11_l1_&post=32513&l1ll1l11l1l_l1_=1&type=l1llll1l1ll_l1_
	# download https://show.l1ll11ll111l_l1_.com/l1l1_l1_/l1l1ll11l11l_l1_
	l1ll1lll_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"ࠬ࠭䡻")
	# l11l1l111_l1_
	if l11l1l_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࠪ䡼") in url:
		l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䡽"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䡾")}
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䡿"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ䢀"),l11l1l_l1_ (u"ࠫࠬ䢁"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨ䢂"))
		l11ll11l_l1_ = response.content
		if l11ll11l_l1_.startswith(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䢃")): l111ll1_l1_ = l11ll11l_l1_
		else:
			l111lll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨ䢄"),l11ll11l_l1_,re.DOTALL)
			if l111lll_l1_:
				l111ll1_l1_ = l111lll_l1_[0]
				l111lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䢅"),l111ll1_l1_,re.DOTALL)
				if l111lll_l1_:
					l111ll1_l1_ = l1llll_l1_(l111lll_l1_[0])
					return l11l1l_l1_ (u"ࠩࠪ䢆"),[l11l1l_l1_ (u"ࠪࠫ䢇")],[l111ll1_l1_]
	# download
	elif l11l1l_l1_ (u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬ䢈") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䢉"),url,l11l1l_l1_ (u"࠭ࠧ䢊"),l11l1l_l1_ (u"ࠧࠨ䢋"),True,l11l1l_l1_ (u"ࠨࠩ䢌"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬ䢍"))
		l11ll11l_l1_ = response.content
		if l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䢎") in list(response.headers.keys()): l111ll1_l1_ = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䢏")]
		else: l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䢐"),l11ll11l_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䢑"),l11l1l_l1_ (u"ࠧࠨ䢒"),l111ll1_l1_,str(2222))
	if l11l1l_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䢓") in l111ll1_l1_ or l11l1l_l1_ (u"ࠩ࠲ࡪ࠴࠭䢔") in l111ll1_l1_:
		l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠪ࠳࡫࠵ࠧ䢕"),l11l1l_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䢖"))
		l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䢗"),l11l1l_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䢘"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䢙"),l11l1l_l1_ (u"ࠨࠩ䢚"),l111ll1_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䢛"),l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫ䢜"),l11l1l_l1_ (u"ࠫࠬ䢝"),l11l1l_l1_ (u"ࠬ࠭䢞"),l11l1l_l1_ (u"࠭ࠧ䢟"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪ䢠"))
		l11ll11l_l1_ = response.content
		items = re.findall(l11l1l_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䢡"),l11ll11l_l1_,re.DOTALL)
		if items:
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠩ࡟ࡠࠬ䢢"),l11l1l_l1_ (u"ࠪࠫ䢣"))
				l1ll1lll_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䢤"),l11ll11l_l1_,re.DOTALL)
			if items:
				l1llll1_l1_ = items[0]
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࡢ࡜ࠨ䢥"),l11l1l_l1_ (u"࠭ࠧ䢦"))
				l1ll1lll_l1_.append(l11l1l_l1_ (u"ࠧࠨ䢧"))
				l1lll1_l1_.append(l1llll1_l1_)
	else: return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䢨"),[l11l1l_l1_ (u"ࠩࠪ䢩")],[l111ll1_l1_]
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䢪"),l11l1l_l1_ (u"ࠫࠬ䢫"),str(l11ll1111_l1_),l111ll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ䢬"),[],[]
	return l11l1l_l1_ (u"࠭ࠧ䢭"),l1ll1lll_l1_,l1lll1_l1_
def l111llll111_l1_(url):
	# l11l1l111_l1_ l11111ll_l1_  https://l1ll1l1ll1l1_l1_.l1lllll111l1_l1_.l1lll1lll1l_l1_/l1ll1111111l_l1_/l1l1l111l111_l1_.l1ll1l1lll_l1_?s=07&id=l11111ll111_l1_,&l1ll1l_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1ll111111l1_l1_&l1lll1l1l11l_l1_=l1l1l1l1l1ll_l1_&l1ll11llll1l_l1_=l1l1l11l11ll_l1_
	# l11l1l111_l1_ l1lll1ll1_l1_ https://l1lllll11lll_l1_.l1lllll111l1_l1_.l1lll1lll1l_l1_/l1ll1111111l_l1_/l1l1l1lll1l1_l1_.l1ll1l1lll_l1_?l1llll11l111_l1_=l1ll111llll1_l1_&l1ll1lll11l1_l1_=8a26a6cc61a884e89076504130c71626&l1ll1l_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1ll111111l1_l1_&l1lll1l1l11l_l1_=l1l1l1l1l1ll_l1_&l1ll1l_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1ll111111l1_l1_&l1lll1l1l11l_l1_=l1l1l1l1l1ll_l1_&l1ll11llll1l_l1_=l1l1lll11lll_l1_
	# download https://www.l1llll1l1l11_l1_.l1ll11l11lll_l1_/l1lll1ll1111_l1_?server=l1l1l1lll111_l1_&id=l1llll1111ll_l1_,,
	# l1l1111ll_l1_ https://l1llll1l1l11_l1_.l1ll1ll1ll_l1_/l1l1111ll_l1_/l1lll1l1111l_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䢮"),url,l11l1l_l1_ (u"ࠨࠩ䢯"),l11l1l_l1_ (u"ࠩࠪ䢰"),l11l1l_l1_ (u"ࠪࠫ䢱"),l11l1l_l1_ (u"ࠫࠬ䢲"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬ䢳"))
	html = response.content
	l1ll1lll_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"࠭ࠧ䢴")
	if l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ䢵") in url or l11l1l_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ䢶") in url:
		if l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ䢷") in url:
			l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䢸"),html,re.DOTALL)
			l111ll1_l1_ = l111ll1_l1_[0]
		else: l111ll1_l1_ = url
		if l11l1l_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ䢹") not in l111ll1_l1_: return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䢺"),[l11l1l_l1_ (u"࠭ࠧ䢻")],[l111ll1_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䢼"),l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䢽"),l11l1l_l1_ (u"ࠩࠪ䢾"),l11l1l_l1_ (u"ࠪࠫ䢿"),l11l1l_l1_ (u"ࠫࠬ䣀"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ䣁"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ䣂"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䣃"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,l1ll11l1lll1_l1_ in items:
				l1ll1lll_l1_.append(l1ll11l1lll1_l1_)
				l1lll1_l1_.append(l1llll1_l1_)
	elif l11l1l_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ䣄") in url:
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭䣅"),html,re.DOTALL)
		l111ll1_l1_ = l111ll1_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䣆"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ䣇"),l11l1l_l1_ (u"ࠬ࠭䣈"),l11l1l_l1_ (u"࠭ࠧ䣉"),l11l1l_l1_ (u"ࠧࠨ䣊"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨ䣋"))
		html = response.content
		l111lll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䣌"),html,re.DOTALL)
		l111lll_l1_ = l111lll_l1_[0]
		l1ll1lll_l1_.append(l11l1l_l1_ (u"ࠪࠫ䣍"))
		l1lll1_l1_.append(l111lll_l1_)
	elif l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ䣎") in url:
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䣏"),html,re.DOTALL)
		if l111ll1_l1_:
			l111ll1_l1_ = l111ll1_l1_[0]
			return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䣐"),[l11l1l_l1_ (u"ࠧࠨ䣑")],[l111ll1_l1_]
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪ䣒"),[],[]
	return l11l1l_l1_ (u"ࠩࠪ䣓"),l1ll1lll_l1_,l1lll1_l1_
def l111111l1l_l1_(url):
	# https://l1llll1111l1_l1_.l1ll1ll111l1_l1_/l1lllll1ll1l_l1_?call=l1lll1l11l11_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1llllll11ll_l1_=l1ll1ll11111_l1_
	# https://l1llll1111l1_l1_.l1ll1ll111l1_l1_/l1lllll1ll1l_l1_?call=l1lll1l11l11_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1llllll11ll_l1_=l1ll11l11l1l_l1_
	l111ll1_l1_ = url.split(l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䣔"),1)[0].strip(l11l1l_l1_ (u"ࠫࡄ࠭䣕")).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ䣖")).strip(l11l1l_l1_ (u"࠭ࠦࠨ䣗"))
	l1ll1lll_l1_,l1lll1_l1_,items,l111lll_l1_ = [],[],[],l11l1l_l1_ (u"ࠧࠨ䣘")
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䣙"):l11l1l_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩ䣚") }
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䣛"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ䣜"),headers,True,l11l1l_l1_ (u"ࠬ࠭䣝"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠵ࡸࡺࠧ䣞"))
	if l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䣟") in list(response.headers.keys()): l111lll_l1_ = response.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䣠")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䣡"),l111lll_l1_,l11l1l_l1_ (u"ࠪࠫ䣢"),headers,False,l11l1l_l1_ (u"ࠫࠬ䣣"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠵ࡲࡩ࠭䣤"))
	#if l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䣥") in response.headers: l111lll_l1_ = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䣦")]
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䣧"),l11l1l_l1_ (u"ࠩࠪ䣨"),l111lll_l1_,response.content)
	if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䣩") in l111lll_l1_:
		# https://l11111l1ll_l1_.top/f/l1lll11l1111_l1_/?l111l1l1l1_l1_=l1111l11l11_l1_
		# https://l11111l1ll_l1_.top/v/l1lll11l1111_l1_/?l111l1l1l1_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䣪") in url: l111lll_l1_ = l111lll_l1_.replace(l11l1l_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䣫"),l11l1l_l1_ (u"࠭࠯ࡷ࠱ࠪ䣬"))
		l1lllllll111_l1_ = l111ll1_l1_.split(l11l1l_l1_ (u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ䣭"))[1]
		headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䣮"):headers[l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䣯")] , l11l1l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䣰"):l11l1l_l1_ (u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ䣱")+l1lllllll111_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䣲"),l111lll_l1_,l11l1l_l1_ (u"࠭ࠧ䣳"),headers,False,l11l1l_l1_ (u"ࠧࠨ䣴"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䣵"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1ll11_l1_,l111lll_l1_,l11l1l_l1_ (u"ࠩࠪ䣶"),headers,l11l1l_l1_ (u"ࠪࠫ䣷"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠵ࡵࡨࠬ䣸"))
		if l11l1l_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䣹") in l111lll_l1_: items = re.findall(l11l1l_l1_ (u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䣺"),html,re.DOTALL)
		elif l11l1l_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䣻") in l111lll_l1_: items = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䣼"),html,re.DOTALL)
		if items: return [],[l11l1l_l1_ (u"ࠩࠪ䣽")],[ items[0] ]
		elif l11l1l_l1_ (u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩ䣾") in html:
			return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧ䣿"),[],[]
	else: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨ䤀"),[],[]
	#xbmc.log(html)
def l1lll1lll1ll_l1_(l1llll1_l1_):
	# https://l1111l11lll_l1_.net/?l11ll1l1_l1_=147043&l11lll11_l1_=5
	parts = re.findall(l11l1l_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䤁"),l1llll1_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪ䤂"),re.DOTALL|re.IGNORECASE)
	l11ll1l1_l1_,l11lll11_l1_ = parts[0]
	url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䤃")+l11ll1l1_l1_+l11l1l_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭䤄")+l11lll11_l1_
	headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䤅"):l11l1l_l1_ (u"ࠫࠬ䤆") , l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䤇"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䤈") }
	l111ll1_l1_ = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ䤉"),headers,l11l1l_l1_ (u"ࠨࠩ䤊"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ䤋"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䤌"),l11l1l_l1_ (u"ࠫࠬ䤍"),url,l111ll1_l1_)
	#l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll11ll11_l1_(l111ll1_l1_)
	#return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䤎"),[l11l1l_l1_ (u"࠭ࠧ䤏")],[l111ll1_l1_]
def l111lll1ll1_l1_(url):
	# https://l1l1l11l1lll_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1lll111llll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1lll1lll1l1_l1_=1608181746
	server = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䤐"))
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䤑"):server,l11l1l_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ䤒"):l11l1l_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ䤓")}
	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䤔"),url,l11l1l_l1_ (u"ࠬ࠭䤕"),l1l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ䤖"),l11l1l_l1_ (u"ࠧࠨ䤗"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ䤘"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ䤙"),html,re.DOTALL)
	l111ll1_l1_ = l11l1l_l1_ (u"ࠪࠫ䤚")
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䤛"),block,re.DOTALL)
		l1ll1lll_l1_,l1lll1_l1_ = [],[]
		for title,l1llll1_l1_ in items:
			l1ll1lll_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		if len(l1lll1_l1_)==1: l111ll1_l1_ = l1lll1_l1_[0]
		elif len(l1lll1_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䤜"), l1ll1lll_l1_)
			if l1l_l1_==-1: return l11l1l_l1_ (u"࠭ࠧ䤝"),[],[]
			l111ll1_l1_ = l1lll1_l1_[l1l_l1_]
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䤞"),html,re.DOTALL)
		if l1l11ll_l1_: l111ll1_l1_ = l1l11ll_l1_[0]
	if not l111ll1_l1_: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ䤟"),[],[]
	return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䤠"),[l11l1l_l1_ (u"ࠪࠫ䤡")],[l111ll1_l1_]
def l1l1lll1l111_l1_(url):
	# https://l1111l1l111_l1_.l1l1ll11lll1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1lll111llll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1lll1lll1l1_l1_=1608181746
	# https://l1111l1l111_l1_.l1ll1ll111l1_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l1lll111llll_l1_=l111111lll1_l1_&l1lll1lll1l1_l1_=1684182121
	server = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䤢"))
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䤣"):server,l11l1l_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䤤"):l11l1l_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䤥")}
	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䤦"),url,l11l1l_l1_ (u"ࠩࠪ䤧"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ䤨"),l11l1l_l1_ (u"ࠫࠬ䤩"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䤪"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䤫"),html,re.DOTALL)
	l111ll1_l1_ = l11l1l_l1_ (u"ࠧࠨ䤬")
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䤭"),block,re.DOTALL)
		l1ll1lll_l1_,l1lll1_l1_ = [],[]
		for title,l1llll1_l1_ in items:
			l1ll1lll_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		if len(l1lll1_l1_)==1: l111ll1_l1_ = l1lll1_l1_[0]
		elif len(l1lll1_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䤮"), l1ll1lll_l1_)
			if l1l_l1_==-1: return l11l1l_l1_ (u"ࠪࠫ䤯"),[],[]
			l111ll1_l1_ = l1lll1_l1_[l1l_l1_]
	if not l111ll1_l1_:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䤰"),html,re.DOTALL)
		if l1l11ll_l1_: l111ll1_l1_ = l1l11ll_l1_[0]
	if not l111ll1_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ䤱"),[],[]
	return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䤲"),[l11l1l_l1_ (u"ࠧࠨ䤳")],[l111ll1_l1_]
def l1l11l11_l1_(l1llll1_l1_):
	# https://w.l1ll111l1ll1_l1_.l1llll1ll11l_l1_/l1ll11l11ll1_l1_-content/l11111l1lll_l1_/l1ll111l111l_l1_/l1llll1l1lll_l1_/l1ll111l1111_l1_/l1ll1l1ll11l_l1_/l1ll11l1l11l_l1_.l1ll1l1lll_l1_?l11ll1l1_l1_=42869&l11lll11_l1_=4
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䤴"),l11l1l_l1_ (u"ࠩࠪ䤵"),l1llll1_l1_,html)
	parts = re.findall(l11l1l_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䤶"),l1llll1_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ䤷"),re.DOTALL)
	url,l11ll1l1_l1_,l11lll11_l1_ = parts[0]
	data = {l11l1l_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭䤸"):l11ll1l1_l1_,l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭䤹"):l11lll11_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䤺"),url,data,l11l1l_l1_ (u"ࠨࠩ䤻"),l11l1l_l1_ (u"ࠩࠪ䤼"),l11l1l_l1_ (u"ࠪࠫ䤽"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭䤾"))
	html = response.content
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤿"),html,re.DOTALL)[0]
	return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䥀"),[l11l1l_l1_ (u"ࠧࠨ䥁")],[l111ll1_l1_]
def l1ll1l111l_l1_(url):
	# https://l1lll1ll1l1l_l1_.l1ll1ll1l1_l1_-l1llll11111l_l1_.com/l1l1111ll_l1_.l1ll1l1lll_l1_?l1l1l1l1l11_l1_=l1ll11llllll_l1_
	# https://l.l1ll11l1l1l1_l1_.l1ll11l11lll_l1_/l1l1111ll_l1_.l1ll1l1lll_l1_?l1l1l1l1l11_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䥂"),url,l11l1l_l1_ (u"ࠩࠪ䥃"),l11l1l_l1_ (u"ࠪࠫ䥄"),l11l1l_l1_ (u"ࠫࠬ䥅"),l11l1l_l1_ (u"ࠬ࠭䥆"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࠷ࡳࡵࠩ䥇"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䥈"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_[0]
		if l1llll1_l1_: return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䥉"),[l11l1l_l1_ (u"ࠩࠪ䥊")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ䥋"),[],[]
def l1ll1lll1l_l1_(url):
	# https://l1ll1ll11l_l1_.l1ll1ll1l1_l1_-l1ll1ll1ll_l1_.l1ll1ll1ll_l1_/l1ll11l11ll1_l1_-content/l11111l1lll_l1_/old/l1lll11_l1_/server.l1ll1l1lll_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䥌"),url,l11l1l_l1_ (u"ࠬ࠭䥍"),l11l1l_l1_ (u"࠭ࠧ䥎"),l11l1l_l1_ (u"ࠧࠨ䥏"),l11l1l_l1_ (u"ࠨࠩ䥐"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ䥑"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䥒"),html,re.DOTALL)[0]
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䥓"),[l11l1l_l1_ (u"ࠬ࠭䥔")],[l1llll1_l1_]
def l1ll1l1111_l1_(url):
	# https://l1lll11llll1_l1_.l1l1l1ll11ll_l1_.cc/l1ll11l11ll1_l1_-content/l11111l1lll_l1_/l1l1lll11111_l1_%20Now%20New/l1l1ll111ll1_l1_.l1ll1l1lll_l1_?action=l1lll1lllll1_l1_&index=00&id=58504
	# https://l1lll111lll1_l1_.l1l1l1ll11ll_l1_.net/l1l1ll11l111_l1_/2021/04/05/_1ll1l11111l_l1_-l1111l111l1_l1_.l1l1l111l1l1_l1_ 200.l1l1l1lllll1_l1_.2020.l1l1ll1l11l1_l1_/[l1l1lll11111_l1_-l1111l111l1_l1_.l1l1llll111l_l1_] 200.l1l1l1lllll1_l1_.2020.l1l1ll1l11l1_l1_-360p.l11111ll_l1_
	l1llll1l11_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䥕"))
	if l11l1l_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ䥖") in url:
		headers = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䥗"):l1llll1l11_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䥘"),url,l11l1l_l1_ (u"ࠪࠫ䥙"),headers,l11l1l_l1_ (u"ࠫࠬ䥚"),l11l1l_l1_ (u"ࠬ࠭䥛"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ䥜"))
		html = response.content
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䥝"),html,re.DOTALL)
		if l111ll1_l1_:
			l111ll1_l1_ = l111ll1_l1_[0]
			if l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䥞") in l111ll1_l1_:
				l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ䥟"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ䥠"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䥡"),l111ll1_l1_,l11l1l_l1_ (u"ࠬ࠭䥢"),headers,l11l1l_l1_ (u"࠭ࠧ䥣"),l11l1l_l1_ (u"ࠧࠨ䥤"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ䥥"))
				l11ll11l_l1_ = response.content
				items = re.findall(l11l1l_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䥦"),l11ll11l_l1_,re.DOTALL)
				l1ll1lll_l1_,l1lll1_l1_ = [],[]
				l1lll1llll_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䥧"))
				for l1llll1_l1_,l111ll1l_l1_ in reversed(items):
					l1llll1_l1_ = l1lll1llll_l1_+l1llll1_l1_+l11l1l_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䥨")+l1lll1llll_l1_
					l1ll1lll_l1_.append(l111ll1l_l1_)
					l1lll1_l1_.append(l1llll1_l1_)
				return l11l1l_l1_ (u"ࠬ࠭䥩"),l1ll1lll_l1_,l1lll1_l1_
			else: return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䥪"),[l11l1l_l1_ (u"ࠧࠨ䥫")],[l111ll1_l1_]
	l111ll1_l1_ = url+l11l1l_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䥬")+l1llll1l11_l1_
	return l11l1l_l1_ (u"ࠩࠪ䥭"),[l11l1l_l1_ (u"ࠪࠫ䥮")],[l111ll1_l1_]
def l1ll1ll1ll1l_l1_(l1llll1_l1_):
	# https://l1l1l1ll11ll_l1_.l1llll1ll11l_l1_/l1ll11l11ll1_l1_-content/l11111l1lll_l1_/l1lll1llll11_l1_/l1l1ll11l1l1_l1_/server.l1ll1l1lll_l1_?l11ll1l1_l1_=42869&l11lll11_l1_=4
	# https://l1lllll1l1l1_l1_.l1l1l1ll11ll_l1_.net/l1l1ll11l111_l1_/2020/08/14/_1ll1l11111l_l1_-l1111l111l1_l1_.l1l1l111l1l1_l1_ l1l1llll1ll1_l1_.l1ll1ll11l11_l1_.2020.l1ll1l11l1ll_l1_-l1ll1ll1l11l_l1_/[l1l1lll11111_l1_-l1111l111l1_l1_.l1l1llll111l_l1_] l1l1llll1ll1_l1_.l1ll1ll11l11_l1_.2020.l1ll1l11l1ll_l1_-l1ll1ll1l11l_l1_-1080p.l11111ll_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䥯"),l11l1l_l1_ (u"ࠬ࠭䥰"),url,html)
	l1llll1l11_l1_ = SERVER(l1llll1_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䥱"))
	if l11l1l_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䥲") in l1llll1_l1_:
		parts = re.findall(l11l1l_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䥳"),l1llll1_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬ䥴"),re.DOTALL)
		url,l11ll1l1_l1_,l11lll11_l1_ = parts[0]
		data = {l11l1l_l1_ (u"ࠪ࡭ࡩ࠭䥵"):l11ll1l1_l1_,l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䥶"):l11lll11_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䥷"),url,data,l11l1l_l1_ (u"࠭ࠧ䥸"),l11l1l_l1_ (u"ࠧࠨ䥹"),l11l1l_l1_ (u"ࠨࠩ䥺"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ䥻"))
		html = response.content
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䥼"),html,re.DOTALL)[0]
		if l11l1l_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䥽") in l111ll1_l1_:
			headers = {l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䥾"):l1llll1l11_l1_,l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䥿"):l11l1l_l1_ (u"ࠧࠨ䦀")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䦁"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ䦂"),headers,l11l1l_l1_ (u"ࠪࠫ䦃"),l11l1l_l1_ (u"ࠫࠬ䦄"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䦅"))
			l11ll11l_l1_ = response.content
			items = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䦆"),l11ll11l_l1_,re.DOTALL)
			l1ll1lll_l1_,l1lll1_l1_ = [],[]
			l1lll1llll_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䦇"))
			for l1llll1_l1_,l111ll1l_l1_ in reversed(items):
				l1llll1_l1_ = l1lll1llll_l1_+l1llll1_l1_+l11l1l_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䦈")+l1lll1llll_l1_
				l1ll1lll_l1_.append(l111ll1l_l1_)
				l1lll1_l1_.append(l1llll1_l1_)
			return l11l1l_l1_ (u"ࠩࠪ䦉"),l1ll1lll_l1_,l1lll1_l1_
		else: return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䦊"),[l11l1l_l1_ (u"ࠫࠬ䦋")],[l111ll1_l1_]
	else:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䦌")+l1llll1l11_l1_
		return l11l1l_l1_ (u"࠭ࠧ䦍"),[l11l1l_l1_ (u"ࠧࠨ䦎")],[l1llll1_l1_]
def l111l1l1l_l1_(l1llll1_l1_):
	# http://l111111l11l_l1_.tv/?l11ll1l1_l1_=159485&l11lll11_l1_=0
	if l11l1l_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ䦏") in l1llll1_l1_:
		parts = re.findall(l11l1l_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䦐"),l1llll1_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭䦑"),re.DOTALL|re.IGNORECASE)
		l11ll1l1_l1_,l11lll11_l1_ = parts[0]
		host = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䦒"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䦓"),l11l1l_l1_ (u"࠭ࠧ䦔"),l1llll1_l1_,host)
		url = host+l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ䦕")+l11ll1l1_l1_+l11l1l_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ䦖")+l11lll11_l1_
		headers = { l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䦗"):l11l1l_l1_ (u"ࠪࠫ䦘") , l11l1l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䦙"):l11l1l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䦚") }
		l111ll1_l1_ = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"࠭ࠧ䦛"),headers,l11l1l_l1_ (u"ࠧࠨ䦜"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ䦝"))
		l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ䦞"),l11l1l_l1_ (u"ࠪࠫ䦟")).replace(l11l1l_l1_ (u"ࠫࡡࡸࠧ䦠"),l11l1l_l1_ (u"ࠬ࠭䦡"))
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䦢"),l11l1l_l1_ (u"ࠧࠨ䦣"),url,l111ll1_l1_)
		#l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1ll11ll11_l1_(l111ll1_l1_)
		#return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
		return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䦤"),[l11l1l_l1_ (u"ࠩࠪ䦥")],[l111ll1_l1_]
	elif l11l1l_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ䦦") in l1llll1_l1_:
		counts = 0
		while l11l1l_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ䦧") in l1llll1_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䦨"),l1llll1_l1_,l11l1l_l1_ (u"࠭ࠧ䦩"),l11l1l_l1_ (u"ࠧࠨ䦪"),l11l1l_l1_ (u"ࠨࠩ䦫"),l11l1l_l1_ (u"ࠩࠪ䦬"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬ䦭"))
			if l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䦮") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䦯")]
			counts += 1
		return l11l1l_l1_ (u"࠭ࠧ䦰"),[l11l1l_l1_ (u"ࠧࠨ䦱")],[l1llll1_l1_]
	else: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ䦲"),[],[]
def l11l111l1_l1_(url):
	# https://l1ll11ll1ll1_l1_.l1l1lll1lll1_l1_.me/l/l11111l111l_l1_=
	server = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䦳"))
	headers = {l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䦴"):server,l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䦵"):l11llll1l_l1_()}
	if l11l1l_l1_ (u"ࠬ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䦶") in url:
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䦷"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䦸")}
		l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭䦹"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,True,l11l1l_l1_ (u"ࠩࠪ䦺"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠳ࡶࡸࠬ䦻"))
		html = response.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䦼"),html,re.DOTALL|re.IGNORECASE)
		if l1llll1_l1_: return l11l1l_l1_ (u"ࠬ࠭䦽"),[l11l1l_l1_ (u"࠭ࠧ䦾")],[l1llll1_l1_[0]]
	elif l11l1l_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ䦿") in url:
		html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠨࠩ䧀"),headers,l11l1l_l1_ (u"ࠩࠪ䧁"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ䧂"))
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䧃"),html,re.DOTALL)
		if l1llll1_l1_: return l11l1l_l1_ (u"ࠬ࠭䧄"),[l11l1l_l1_ (u"࠭ࠧ䧅")],[l1llll1_l1_[0]]
	else:
		l1ll11lll11l_l1_ = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䧆"),url,l11l1l_l1_ (u"ࠨࠩ䧇"),headers,l11l1l_l1_ (u"ࠩࠪ䧈"),l11l1l_l1_ (u"ࠪࠫ䧉"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠶ࡶࡩ࠭䧊"))
		html = l1ll11lll11l_l1_.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ䧋"),html,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])+l11l1l_l1_ (u"࠭ࠦࡥ࠿࠴ࠫ䧌")
			l1l1lllll_l1_ = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䧍"),l1llll1_l1_,l11l1l_l1_ (u"ࠨࠩ䧎"),headers,l11l1l_l1_ (u"ࠩࠪ䧏"),l11l1l_l1_ (u"ࠪࠫ䧐"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠷ࡸ࡭࠭䧑"))
			html = l1l1lllll_l1_.content
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡥࡸࡳࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䧒"),html,re.DOTALL)
			if l1llll1_l1_:
				l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])
				return l11l1l_l1_ (u"࠭ࠧ䧓"),[l11l1l_l1_ (u"ࠧࠨ䧔")],[l1llll1_l1_]
		if l11l1l_l1_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ䧕") in list(l1ll11lll11l_l1_.headers.keys()):
			cookies = l1ll11lll11l_l1_.headers[l11l1l_l1_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭䧖")]
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡣࡱࡴ࡫ࡠ࠰࠭ࡃࡂ࠮࠮ࠫࡁࠬ࠿ࠬ䧗"),cookies,re.DOTALL)
			if l1llll1_l1_:
				l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])
				return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䧘"),[l11l1l_l1_ (u"ࠬ࠭䧙")],[l1llll1_l1_]
	return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ䧚"),[],[]
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠩࠠ࡯ࡱࡷࠤࡼࡵࡲ࡬࡫ࡱ࡫ࠏࠏࠉࠤࠢ࡬ࡸࠥࡴࡥࡦࡦࡶࠤࡨࡵ࡯࡬࡫ࡨࠤ࡫ࡸ࡯࡮ࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠐࠉࠊࠥࠣࡇࡴࡵ࡫ࡪࡧ࠽ࠤࡨ࡬࡟ࡤ࡮ࡨࡥࡷࡧ࡮ࡤࡧࡀࡇࡒ࡫࠮ࡉࡍࡊࡕࡰࡳࡷ࡯ࡕ࡙ࡹࡳࢀࡖࡊࡲࡴࡳࡼࡷࡓࡂ࡜ࡦࡴࡳࡌ࠷࡫ࡄࡓ࡙ࡔࡗࡢ࡚ࡄࡉ࠴࠲࠷࠶࠷࠵࠴࠵࠷࠶࠰࠷࠯࠳࠱࠷࠻࠰ࠋࠋࠌࡷࡪࡸࡶࡦࡴࠣࡁ࡙ࠥࡅࡓࡘࡈࡖ࠭ࡻࡲ࡭࠮ࠪࡹࡷࡲࠧࠪࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࠺ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠫ࠭࠱࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠻ࡵࡨࡶࡻ࡫ࡲࡾࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ࠭ࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠎࡲࡩ࡯࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡱ࡯࡮࡬࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐࢁࡸࡥ࠯ࡋࡊࡒࡔࡘࡅࡄࡃࡖࡉ࠮ࠐࠉࠊ࡫ࡩࠤࡱ࡯࡮࡬ࡵ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡨࡱࡧ࡫ࡤ࠮ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡡࠧࠨ࡟࠯࡟ࡱ࡯࡮࡬࡟ࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠰࡭ࡺ࡭࡭ࠫࠍࠍࠎࠩ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࡟࠵ࡣࠊࠊࠋࠦ࡭࡫ࠦࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠨࠏࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠧࠎࡸࡥࡵࡷࡵࡲࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠏࠏࠉࠤࡧ࡯ࡷࡪࡀࠠࡶࡴ࡯ࠤࡂࠦ࡬ࡪࡰ࡮ࠎࠎࠨࠢࠣ䧛")
	#if l11l1l_l1_ (u"ࠨ࠰ࡰࡴ࠹࠴ࡨࡵ࡯࡯ࠫ䧜") in url:
	#	l1ll1111l11l_l1_ = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ䧝"))
	#	url = l11l1l_l1_ (u"ࠪ࠳ࠬ䧞").join(l1ll1111l11l_l1_[:4])
	#	tmp = re.findall(l11l1l_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠵࠯࠯ࠬࡂ࠳࠮࠮࠮ࠫࡁࠬࠨࠬ䧟"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11l1l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䧠")+tmp[0][1]+l11l1l_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ䧡")
	#	#return l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䧢"),[l11l1l_l1_ (u"ࠨࠩ䧣")],[url]
	#	#l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l1l1l1ll111l_l1_(url)
	#	#return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
	# l1l1111ll_l1_ l1llll1_l1_
	#return l11l1l_l1_ (u"ࠩࠪ䧤"),[l11l1l_l1_ (u"ࠪࠫ䧥")],[l1llll1_l1_]
def l1l1lll111l1_l1_(l1llll1_l1_):
	# https://l1ll1l1l11ll_l1_.l1ll1ll1l1ll_l1_/l1l1l1111l1l_l1_?_1l1llll1l1l_l1_=l1l1l1l1111l_l1_&_1ll1111lll1_l1_=86046&l11lll11_l1_=0
	if l11l1l_l1_ (u"ࠫࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠨ䧦") in l1llll1_l1_:
		headers = {l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䧧"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䧨")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䧩"),l1llll1_l1_,l11l1l_l1_ (u"ࠨࠩ䧪"),headers,l11l1l_l1_ (u"ࠩࠪ䧫"),l11l1l_l1_ (u"ࠪࠫ䧬"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭䧭"))
		url = response.content
		if url: return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䧮"),[l11l1l_l1_ (u"࠭ࠧ䧯")],[url]
	else:
		# https://l1l1ll1l1l11_l1_.net/?l11ll1l1_l1_=142302&l11lll11_l1_=4
		parts = re.findall(l11l1l_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䧰"),l1llll1_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11l1l_l1_ (u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ䧱"),l1llll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1l1_l1_,l11lll11_l1_ = parts[0]
		server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䧲"))
		#url = server+l11l1l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䧳")
		url = server+l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡷ࡬ࡪࡳࡥ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䧴")
		#url = server+l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䧵")+l11ll1l1_l1_+l11l1l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䧶")+l11lll11_l1_
		#data = {l11l1l_l1_ (u"ࠧࡪࡦࠪ䧷"):l11ll1l1_l1_,l11l1l_l1_ (u"ࠨ࡫ࠪ䧸"):l11lll11_l1_,l11l1l_l1_ (u"ࠩࡰࡩࡹࡧࠧ䧹"):l11l1l_l1_ (u"ࠪࡳࡱࡪ࡟ࡴࡧࡵࡺࡪࡸࡳࠨ䧺"),l11l1l_l1_ (u"ࠫࡹࡿࡰࡦࠩ䧻"):l11l1l_l1_ (u"ࠬࡵ࡬ࡥࠩ䧼")}
		data = {l11l1l_l1_ (u"࠭ࡩࡥࠩ䧽"):l11ll1l1_l1_,l11l1l_l1_ (u"ࠧࡪࠩ䧾"):l11lll11_l1_}
		headers = {l11l1l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䧿"):l11l1l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䨀"),l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䨁"):l1llll1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䨂"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭䨃"),l11l1l_l1_ (u"࠭ࠧ䨄"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠸࡮ࡥࠩ䨅"))
		l11ll11l_l1_ = response.content
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䨆"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		if l111ll1_l1_:
			l111ll1_l1_ = l111ll1_l1_[0]
			return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䨇"),[l11l1l_l1_ (u"ࠪࠫ䨈")],[l111ll1_l1_]
	return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ䨉"),[],[]
def l1llll11_l1_(url,type,l111ll1l_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䨊"),l11l1l_l1_ (u"࠭ࠧ䨋"),l111ll1_l1_,type)
	# http://l1ll11ll11l1_l1_.l1llllll1lll_l1_.io/l1llll1_l1_/136530
	l1lll1l1_l1_,l1ll1l11lll1_l1_ = [],[]
	l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠧࠨ䨌"),l11l1l_l1_ (u"ࠨࠩ䨍"),True,l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨ䨎"))
	l11111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠾࠲ࡥࡃ࠭䨏"),l11ll11l_l1_,re.DOTALL)
	for block in l11111l_l1_:
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䨐"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1l1_l1_ and (l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭䨑") in l1llll1_l1_ or l11l1l_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ䨒") in l1llll1_l1_):
				title = title.replace(l11l1l_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨ䨓"),l11l1l_l1_ (u"ࠨࠩ䨔")).replace(l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭䨕"),l11l1l_l1_ (u"ࠪࠫ䨖")).strip(l11l1l_l1_ (u"ࠫࠥ࠭䨗")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠨ䨘"),l11l1l_l1_ (u"࠭ࠠࠨ䨙"))
				l1lll1l1_l1_.append(l1llll1_l1_)
				l1ll1l11lll1_l1_.append(title)
	if not l1lll1l1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䨚"),[],[]
	if len(l1lll1l1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䨛"),l1ll1l11lll1_l1_)
		if l1l_l1_==-1: l1l_l1_ = 0
	else: l1l_l1_ = 0
	l111lll_l1_ = l1lll1l1_l1_[l1l_l1_]
	l1lll1_l1_,l1ll1lll_l1_ = [],[]
	if type==l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䨜"):
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䨝"),l111lll_l1_,l11l1l_l1_ (u"ࠫࠬ䨞"),l11l1l_l1_ (u"ࠬ࠭䨟"),l11l1l_l1_ (u"࠭ࠧ䨠"),True,l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠵ࡲࡩ࠭䨡"))
		l1l1ll111_l1_ = response.content
		l1lllll11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䨢"),l1l1ll111_l1_,re.DOTALL)
		if l1lllll11_l1_:
			l1llll1_l1_ = l1llll_l1_(l1lllll11_l1_[0])
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1lll_l1_.append(l111ll1l_l1_)
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䨣"),l11l1l_l1_ (u"ࠪࠫ䨤"),l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䨥"),l1llll1_l1_)
	elif type==l11l1l_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䨦"):
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䨧"),l111lll_l1_,l11l1l_l1_ (u"ࠧࠨ䨨"),l11l1l_l1_ (u"ࠨࠩ䨩"),l11l1l_l1_ (u"ࠩࠪ䨪"),True,l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠹ࡲࡥࠩ䨫"))
		l1l1ll111_l1_ = response.content
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䨬"),l1l1ll111_l1_,re.DOTALL)
		for l1llll1_l1_,size in l1l1_l1_:
			if l111ll1l_l1_ in size:
				l1ll1lll_l1_.append(size)
				l1lll1_l1_.append(l1llll1_l1_)
				#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䨭"),l11l1l_l1_ (u"࠭ࠧ䨮"),l11l1l_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭䨯"),l1llll1_l1_)
				break
		if not l1lll1_l1_:
			for l1llll1_l1_,size in l1l1_l1_:
				l1ll1lll_l1_.append(size)
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨࡖࡈࡗ࡙࠭䨰"),l1lll1_l1_)
	if not l1lll1_l1_: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ䨱"),[],[]
	return l11l1l_l1_ (u"ࠪࠫ䨲"),l1ll1lll_l1_,l1lll1_l1_
def l11lll1_l1_(url,name):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䨳"),l11l1l_l1_ (u"ࠬ࠭䨴"),url,l1llllll11ll_l1_)
	# http://l1111l1l1l1_l1_.l1ll111l1ll1_l1_.net/5cf68c23e6e79			?l1llllll11ll_l1_=			__11111lllll_l1_
	# http://w.l11l1ll1_l1_.l1lll1lll1l_l1_/5e14fd0a2806e			?l1llllll11ll_l1_=			ok.l1ll11llll11_l1_
	#l1llllll11ll_l1_ = l1llllll11ll_l1_.replace(l11l1l_l1_ (u"࠭ࡡ࡬ࡱࡤࡱࡤࡥࠧ䨵"),l11l1l_l1_ (u"ࠧࠨ䨶")).split(l11l1l_l1_ (u"ࠨࡡࡢࠫ䨷"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䨸"),url,l11l1l_l1_ (u"ࠪࠫ䨹"),l11l1l_l1_ (u"ࠫࠬ䨺"),True,l11l1l_l1_ (u"ࠬ࠭䨻"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ䨼"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ䨽") in list(cookies.keys()):
		l11l11l11_l1_ = cookies[l11l1l_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ䨾")]
		l11l11l11_l1_ = l1llll_l1_(escapeUNICODE(l11l11l11_l1_))
		items = re.findall(l11l1l_l1_ (u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䨿"),l11l11l11_l1_,re.DOTALL)
		l111ll1_l1_ = items[0].replace(l11l1l_l1_ (u"ࠪࡠ࠴࠭䩀"),l11l1l_l1_ (u"ࠫ࠴࠭䩁"))
		l111ll1_l1_ = escapeUNICODE(l111ll1_l1_)
	else: l111ll1_l1_ = url
	if l11l1l_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䩂") in l111ll1_l1_:
		id = l111ll1_l1_.split(l11l1l_l1_ (u"࠭ࠥ࠳ࡈࠪ䩃"))[-1]
		l111ll1_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ䩄")+id
		return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䩅"),[l11l1l_l1_ (u"ࠩࠪ䩆")],[l111ll1_l1_]
	else:
		l1l1l111_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䩇")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䩈"),l1l1l111_l1_,l11l1l_l1_ (u"ࠬ࠭䩉"),l11l1l_l1_ (u"࠭ࠧ䩊"),True,l11l1l_l1_ (u"ࠧࠨ䩋"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ䩌"))
		l1llllll111l_l1_ = response.url
		#l1llllll111l_l1_ = response.headers[l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䩍")]
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䩎"),l11l1l_l1_ (u"ࠫࠬ䩏"),response.url,l1l1l111_l1_)
		l1ll1l11ll11_l1_ = l111ll1_l1_.split(l11l1l_l1_ (u"ࠬ࠵ࠧ䩐"))[2]#.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䩑"))
		l1111l1l1ll_l1_ = l1llllll111l_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䩒"))[2]#.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䩓"))
		l111lll_l1_ = l111ll1_l1_.replace(l1ll1l11ll11_l1_,l1111l1l1ll_l1_)
		headers = { l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䩔"):l11l1l_l1_ (u"ࠪࠫ䩕") , l11l1l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䩖"):l11l1l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䩗") , l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䩘"):l111lll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䩙"), l111lll_l1_, l11l1l_l1_ (u"ࠨࠩ䩚"), headers, False,l11l1l_l1_ (u"ࠩࠪ䩛"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠹ࡲࡥࠩ䩜"))
		html = response.content
		#xbmc.log(str(l111lll_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11l1l_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䩝"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䩞"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11l1l_l1_ (u"࠭࠼ࡦ࡯ࡥࡩࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䩟"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䩠"),l11l1l_l1_ (u"ࠨࠩ䩡"),str(items),html)
		if items:
			l1llll1_l1_ = items[0].replace(l11l1l_l1_ (u"ࠩ࡟࠳ࠬ䩢"),l11l1l_l1_ (u"ࠪ࠳ࠬ䩣"))
			l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠫ࠴࠭䩤"))
			if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䩥") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䩦") + l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䩧"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ䩨"))
			if name==l11l1l_l1_ (u"ࠩࠪ䩩"): l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠪࠫ䩪"),[l11l1l_l1_ (u"ࠫࠬ䩫")],[l1llll1_l1_]
			else: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䩬"),[l11l1l_l1_ (u"࠭ࠧ䩭")],[l1llll1_l1_]
		else: l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏࡔࡇࡍࠨ䩮"),[],[]
		return l11111l1l1l_l1_,l1ll1lll_l1_,l1lll1_l1_
def l1llll11ll1l_l1_(url):
	# https://www.l1llll1lll11_l1_.com/e/l1l1ll1ll1l1_l1_
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䩯") : l11l1l_l1_ (u"ࠩࠪ䩰") }
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠪࠫ䩱"),headers,l11l1l_l1_ (u"ࠫࠬ䩲"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ䩳"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䩴"),l11l1l_l1_ (u"ࠧࠨ䩵"),url,html)
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䩶"),html,re.DOTALL)
	l1ll1lll_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"ࠩࠪ䩷")
	if items:
		for l1llll1_l1_,l1ll11l1lll1_l1_ in items:
			l1ll1lll_l1_.append(l1ll11l1lll1_l1_)
			l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩ䩸"),[],[]
	return l11l1l_l1_ (u"ࠫࠬ䩹"),l1ll1lll_l1_,l1lll1_l1_
def l1l1lll1llll_l1_(url):
	# https://l1ll11l11111_l1_.com/l1l1111ll_l1_-l1lll1l11ll1_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䩺"),l11l1l_l1_ (u"࠭ࠧ䩻"))
	headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䩼") : l11l1l_l1_ (u"ࠨࠩ䩽") }
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ䩾"),headers,l11l1l_l1_ (u"ࠪࠫ䩿"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ䪀"))
	items = re.findall(l11l1l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ䪁"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䪂"),l11l1l_l1_ (u"ࠧࠨ䪃"),url,items[0])
	if items:
		url = items[0]+l11l1l_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䪄")+url
		return l11l1l_l1_ (u"ࠩࠪ䪅"),[l11l1l_l1_ (u"ࠪࠫ䪆")],[url]
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭䪇"),[],[]
def l1ll1lll1ll1_l1_(url):
	# https://l1l1l1111ll1_l1_.to/l1l1111ll_l1_/5c83f14297d62
	url = url.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ䪈"))
	if l11l1l_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ䪉") in url: id = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䪊"))[4]
	else: id = url.split(l11l1l_l1_ (u"ࠨ࠱ࠪ䪋"))[-1]
	url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭䪌") + id
	headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䪍") : l11l1l_l1_ (u"ࠫࠬ䪎") }
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠬ࠭䪏"),headers,l11l1l_l1_ (u"࠭ࠧ䪐"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ䪑"))
	html = html.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ䪒"),l11l1l_l1_ (u"ࠩࠪ䪓"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䪔"),l11l1l_l1_ (u"ࠫࠬ䪕"),url,html)
	items = re.findall(l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䪖"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"࠭ࠧ䪗"),[l11l1l_l1_ (u"ࠧࠨ䪘")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ䪙"),[],[]
def l1ll11111lll_l1_(url):
	# https://l1111111ll1_l1_.net/l1l1111ll_l1_-l1lll1lll11l_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䪚"),l11l1l_l1_ (u"ࠪࠫ䪛"))
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠫࠬ䪜"),l11l1l_l1_ (u"ࠬ࠭䪝"),l11l1l_l1_ (u"࠭ࠧ䪞"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ䪟"))
	items = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䪠"),html,re.DOTALL)
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	for l1llll1_l1_,l1ll11l1lll1_l1_,res in items:
		l1ll1lll_l1_.append(l1ll11l1lll1_l1_+l11l1l_l1_ (u"ࠩࠣࠫ䪡")+res)
		l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ䪢"),[],[]
	return l11l1l_l1_ (u"ࠫࠬ䪣"),l1ll1lll_l1_,l1lll1_l1_
def l1lll11l1l1l_l1_(url):
	# https://l11111l1ll1_l1_.l1lll1ll11l_l1_/l1l1111ll_l1_-l1ll111l1l11_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䪤"),l11l1l_l1_ (u"࠭ࠧ䪥"))
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ䪦"),l11l1l_l1_ (u"ࠨࠩ䪧"),l11l1l_l1_ (u"ࠩࠪ䪨"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ䪩"))
	items = re.findall(l11l1l_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ䪪"),html,re.DOTALL)
	items = set(items)
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	for id,mode,hash,l1ll11l1lll1_l1_,res in items:
		url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ䪫")+id+l11l1l_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭䪬")+mode+l11l1l_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ䪭")+hash
		html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠨࠩ䪮"),l11l1l_l1_ (u"ࠩࠪ䪯"),l11l1l_l1_ (u"ࠪࠫ䪰"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ䪱"))
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䪲"),html,re.DOTALL)
		for l1llll1_l1_ in items:
			l1ll1lll_l1_.append(l1ll11l1lll1_l1_+l11l1l_l1_ (u"࠭ࠠࠨ䪳")+res)
			l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭䪴"),[],[]
	return l11l1l_l1_ (u"ࠨࠩ䪵"),l1ll1lll_l1_,l1lll1_l1_
def l1l1l1111lll_l1_(url):
	# https://l1l1l1l11l11_l1_.com:2053/l1l1l1l11lll_l1_/l1ll1111llll_l1_.l1lll1l111ll_l1_.l1111l11l1l_l1_.1080p.l11111lll1l_l1_.l1llllll11l1_l1_.l1l1l11l1ll1_l1_.l11111ll_l1_.html?l1lll111llll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l1lll1lll1l1_l1_=1624070560
	# http://l1l1ll1111ll_l1_.l1lllll1l11l_l1_/l1lll11lll11_l1_/l1lll1l11lll_l1_.l1ll1l1lll11_l1_.l1lll1ll1l11_l1_.2018.1080p.l1ll1l11l1ll_l1_-l1ll1ll1l11l_l1_.l1l1ll111111_l1_.l11111ll_l1_.html
	l1llll1_l1_ = l11l1l_l1_ (u"ࠩࠪ䪶")
	if 1 or l11l1l_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ䪷") not in url:
		l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ䪸"),l11l1l_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ䪹"))
		l111ll1_l1_ = l111ll1_l1_.split(l11l1l_l1_ (u"࠭࠯ࠨ䪺"))
		id = l111ll1_l1_[3]
		l111ll1_l1_ = l11l1l_l1_ (u"ࠧ࠰ࠩ䪻").join(l111ll1_l1_[0:4])
		#headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䪼"):l11llll1l_l1_(),l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䪽"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䪾")}
		payload = {l11l1l_l1_ (u"ࠫ࡮ࡪࠧ䪿"):id,l11l1l_l1_ (u"ࠬࡵࡰࠨ䫀"):l11l1l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ䫁"),l11l1l_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ䫂"):l11l1l_l1_ (u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ䫃")}
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䫄"),l111ll1_l1_,payload,l11l1l_l1_ (u"ࠪࠫ䫅"),l11l1l_l1_ (u"ࠫࠬ䫆"),l11l1l_l1_ (u"ࠬ࠭䫇"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬ䫈"))
		if l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䫉") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䫊")]
		if not l1llll1_l1_ and response.succeeded:
			html = response.content
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫋"),html,re.DOTALL)
			if l1llll1_l1_: l1llll1_l1_ = l1llll1_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䫌"),url,l11l1l_l1_ (u"ࠫࠬ䫍"),l11l1l_l1_ (u"ࠬ࠭䫎"),l11l1l_l1_ (u"࠭ࠧ䫏"),l11l1l_l1_ (u"ࠧࠨ䫐"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ䫑"))
		if l11l1l_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ䫒") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ䫓")]
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠫࠬ䫔"),[l11l1l_l1_ (u"ࠬ࠭䫕")],[l1llll1_l1_]
	return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧ䫖"),[],[]
def l1ll1lllll11_l1_(url):
	# https://www.l1ll1l1l1l1l_l1_.com/012ocyw9li6g.html
	headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䫗") : l11l1l_l1_ (u"ࠨࠩ䫘") }
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ䫙"),headers,l11l1l_l1_ (u"ࠪࠫ䫚"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡋࡌ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭䫛"))
	items = re.findall(l11l1l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦ࠭࠴ࠪࡀࠫࠥࠫ䫜"),html,re.DOTALL)
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	if items:
		l1ll1lll_l1_.append(l11l1l_l1_ (u"࠭࡭ࡱ࠶ࠪ䫝"))
		l1lll1_l1_.append(items[0][1])
		l1ll1lll_l1_.append(l11l1l_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ䫞"))
		l1lll1_l1_.append(items[0][0])
		return l11l1l_l1_ (u"ࠨࠩ䫟"),l1ll1lll_l1_,l1lll1_l1_
	else: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡏࡉࡗࡋࡇࡉࡔ࠭䫠"),[],[]
def l111111ll1l_l1_(url):
	# l1lll1l111l1_l1_ l1llll1ll111_l1_			url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࡚࠹࡚࠸࠶࡜ࡍࡹࡻࡔࡉࠬ䫡")
	# l1l1l1ll11l1_l1_ .l1111l11111_l1_ l1llll1ll111_l1_		url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡚ࡹࡱࡘࡔࡁࡺࡧࡼࡊࡎ࠭䫢")
	# l1lll11lll1l_l1_ l11l11llll_l1_ .l1lll1ll1_l1_ l1llll1ll111_l1_		url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡊࡪ࠷࠳ࡎࡔࡶࡖࡷࡓࡽࠧ䫣")
	# l1lll11111l1_l1_ l1llll1ll111_l1_			url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ䫤")
	# l1111lllll_l1_ files have l1ll1lll1lll_l1_ l1l1l1l111ll_l1_		url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࠶ࡽࡄࡓࡗ࡙ࡧࡘࡿ࡟ࡒࠩ䫥")
	# url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࡪࡊ࡬࡛࠷ࡹࡅࡓࡗࡕࡨࠩ䫦")
	# url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼ࠶ࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ䫧")
	# url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ䫨")
	# url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭䫩")
	# url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡳࡊࡊࡲ࡫ࡪࡡࡍ࠵࡞ࡱࠦࡢࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡁࡌࡵ࡬ࡥࡧࡱࡐ࡮ࡴࡥࡧࡱࡵࡘ࡛ࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡣࡱࡨࡉ࡯ࡳࡵࡴ࡬ࡦࡺࡺࡩࡰࡰࡂࡷࡾࡴࡤࡪࡥࡤࡸ࡮ࡵ࡮࠾࠴࠺࠻࠺࠽࠵ࠨ䫪")
	# l1ll1l1ll_l1_ l1l1lll1l1ll_l1_ details   https://l1ll111l11ll_l1_.me/l1l1l11llll1_l1_/l1l1l111llll_l1_-l1l1l11lll1l_l1_-l1l1lll11ll1_l1_
	id = url.split(l11l1l_l1_ (u"࠭࠯ࠨ䫫"))[-1]
	id = id.split(l11l1l_l1_ (u"ࠧࠧࠩ䫬"))[0]
	id = id.replace(l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ䫭"),l11l1l_l1_ (u"ࠩࠪ䫮"))
	#id = l11l1l_l1_ (u"ࠪࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ䫯")
	#url = l11l1l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ䫰")+id
	#return l11l1l_l1_ (u"ࠬ࠭䫱"),[l11l1l_l1_ (u"࠭ࠧ䫲")],[url]
	l111ll1_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䫳")][0]+l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ䫴")+id
	l1l1l111l11l_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬ䫵")+id
	l1ll1l1llll1_l1_,l1l1l1l11ll1_l1_,l1111l11ll1_l1_,l1l1l1lll11l_l1_ = l11l1l_l1_ (u"ࠪࠫ䫶"),l11l1l_l1_ (u"ࠫࠬ䫷"),l11l1l_l1_ (u"ࠬ࠭䫸"),l11l1l_l1_ (u"࠭ࠧ䫹")
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡝ࠩ࠯ࠫࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠫ࠲࠯ࡅࠩࡥࡧࡩࡥࡺࡲࡴࡂࡷࡧ࡭ࡴ࡚ࡲࡢࡥ࡮ࡍࡳࡪࡥࡹࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠩࠫ࠮ࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡼࠤ࡯ࡥࡳ࡭ࡵࡢࡩࡨࡇࡴࡪࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ࡟࠯࡟ࠬ࠭࡝ࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮ࡤࡲ࡬࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭ࡣࡱ࡫࠮ࠐࠉࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ࠰ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠌࠌࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡳࡵࡴࠡ࡫ࡱࠤࡠ࠶ࠬ࠮࠳ࡠ࠾ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࠍࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍ࡝࠳ࡡ࠰࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬ࠱࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠼ࠣࡨࡦࡹࡨࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࡨࡰࡸ࡫࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡵ࠲ࠫ࠱࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡫ࡰࡸ࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠤࡪࡷࡱࡱ࠸ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡪ࡯ࡷ࡚ࡘࡌ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ࠯ࠊࠊࠋࠦ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬࡛ࠩࠩ࠱ࡒࡋࡄࡊࡃ࠽࡙ࡗࡏ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࡖ࡜ࡔࡊࡃࡓࡖࡄࡗࡍ࡙ࡒࡅࡔ࠮ࡊࡖࡔ࡛ࡐ࠮ࡋࡇࡁࠧࡼࡴࡵࠩ࠯࡬ࡹࡳ࡬࠳࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠣࠬࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠪࡹࡿࡰࡦ࠿ࡷࡶࡦࡩ࡫ࠧࡶ࡯ࡥࡳ࡭࠽ࠨࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠯ࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࢀࢃࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡵࡳ࡮ࡢࡩࡳࡩ࡯ࡥࡧࡧࡣ࡫ࡳࡴࡠࡵࡷࡶࡪࡧ࡭ࡠ࡯ࡤࡴࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡡࡩࡱࡹࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡮࡬ࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨࡰࡸࡤࡲࡩࡴࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡦࡴࡤࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠧ࠽࡜ࠩࠪࡡ࠿ࠐࠉࠊࠋࡩࡱࡹࡥ࡬ࡪࡵࡷࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌࡪࡲࡺ࡟ࡪࡶࡤ࡫ࡸࠦ࠽ࠡࡨࡰࡸࡤࡲࡩࡴࡶ࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡨࡰࡸࡤ࡯ࡴࡢࡩࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡸࡦ࡭ࠬࡴ࡫ࡽࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪࠌࠌࠍࠎࠏࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࡡࡩࡵࡣࡪࡡࠥࡃࠠࡴ࡫ࡽࡩࠏࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࡲࡩ࡯ࡧࡶࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠲ࠧࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡪࠦࡩ࡯ࠢ࡯࡭ࡳ࡫ࡳ࠻ࠌࠌࠍࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠱ࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࠊࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭ࡲࡩ࡯ࡧ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉ࡭࡫ࡱࡩࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡪ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴࠡ࠿ࠣࡿࢂࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡰ࡮ࡴࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨࠨࠩࠫ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍࡰ࡫ࡹ࠭ࡸࡤࡰࡺ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠾ࠩ࠯࠵࠮ࠐࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜࡭ࡨࡽࡢࠦ࠽ࠡࡸࡤࡰࡺ࡫ࠊࠊࠋࠌ࡭࡫ࠦࠧࡴ࡫ࡽࡩࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࠬࡹࡩࡻࡧࠪࡡࠥࡃࠠࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࡛ࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࡣࠊࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴࠪࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦ࡫ࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠨࠩࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠾ࠤࠪ࠰ࠬࡃࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠧࠨࠧ࠭ࠩࠥࠫ࠮ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠾ࡹࡸࡵࡦࠩ࠯ࠫ࠿࡚ࡲࡶࡧࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠻ࡨࡤࡰࡸ࡫ࠧ࠭ࠩ࠽ࡊࡦࡲࡳࡦࠩࠬࠎࠎࠏࡩࡧࠢࠪ࡟ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡢ࡭ࡱࡦ࡯ࠥࡃࠠࠨ࡝ࠪ࠯ࡧࡲ࡯ࡤ࡭࠮ࠫࡢ࠭ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡉ࡛ࡇࡌࠩࠩ࡯࡭ࡸࡺࠧ࠭ࡤ࡯ࡳࡨࡱࠩࠋࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠋࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠪࠌࠌࠍࠎࡪࡩࡤࡶ࡞ࠫࡹࡿࡰࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂ࠭ࠬࠨ࠿ࠥࠫ࠮࠱ࠧࠣࠩࠍࠍࠎࠏࡩࡧࠢࠪࡪࡵࡹࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡨࡳࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡬ࡰࡴࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡹ࡬ࡨࡹ࡮ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡵ࡬ࡾࡪ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡷࡪࡦࡷ࡬ࠬࡣࠩࠬࠩࡻࠫ࠰ࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡪࡨ࡭࡬࡮ࡴࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡪࡴࡤࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡷࡹࡧࡲࡵࠩࡠ࠯ࠬ࠳ࠧࠬࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡦࡰࡧࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࡀ࠴࠵࠶࠸࠲࠳࠵࠶࠷࠿ࠦࡤࡦ࡮ࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡣࡪࡲ࡫ࡩࡷࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩࡠ࠲ࡸࡶ࡬ࡪࡶࠫࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣࡧ࡮ࡶࡨࡦࡴ࠽ࠎࠎࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛࡬ࡧࡼࡡࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡸࡤࡰࡺ࡫ࠩࠋࠋࠌࠍࠨ࡯ࡦࠡࠩࡸࡶࡱ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡶࡴ࡯ࠫࡢࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࡛ࠨࡷࡵࡰࠬࡣࠩࠋࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵࠫࠍࠍࡺࡸ࡬ࡠ࡮࡬ࡷࡹ࠲ࡳࡵࡴࡨࡥࡲࡹ࠰࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠳࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠶ࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲ࠢࡤࡲࡩࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࡀࠊࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷ࠵ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠻ࠌࠌࠍࠎࡻࡲ࡭࠳ࠣࡁࠥࡪࡩࡤࡶ࠴࡟ࠬࡻࡲ࡭ࠩࡠ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠣࡶࡴ࡯࠵ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࠱࡜ࠩࡸࡶࡱ࠭࡝ࠪࠫ࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺ࠲ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡧ࡭ࡨࡺ࠲࡜ࠩࡸࡶࡱ࠭࡝࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍࠨࡻࡲ࡭࠴ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡶࡴ࡯࠵ࡂࡃࡵࡳ࡮࠵ࠤࡦࡴࡤࠡࡷࡵࡰ࠶ࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠻ࠌࠌࠍࠎࠏࠉࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠷ࠩࠋࠋࠌࠍࠎࠏࡤࡪࡥࡷ࠵࠳ࡻࡰࡥࡣࡷࡩ࠭ࡪࡩࡤࡶ࠵࠭ࠏࠏࠉࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶ࠴࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶ࠴࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡹࡴࡳࡧࡤࡱࡸ࠶ࠠ࠾ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠭ࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳ࠌࠌࠦࠧࠨ䫺")
	# l1l1l1llllll_l1_ json data
	# l1l1111ll_l1_ url l1llll1ll111_l1_:    https://www.l1ll1l1ll_l1_.com/l1l1111ll_l1_/l1lll1ll11l1_l1_
	# list of l1llll1ll1ll_l1_ & l1l1l1l1l11l_l1_
	# https://github.com/l1l1lll11l1l_l1_-l1ll11l1ll1l_l1_/l1l1lll11l1l_l1_-l1ll11l1ll1l_l1_/blob/master/l1llll11lll1_l1_/l1ll1l1l1lll_l1_/l1ll1l1ll_l1_.py
	# all the below l1ll111111ll_l1_ were l1ll1llll1ll_l1_ using:	https://www.l1ll1l1ll_l1_.com/l1llllllll11_l1_/l1l1lllll11l_l1_/l1ll1111111l_l1_?l1l1l111lll1_l1_=l1l1l1l1l1ll_l1_	&	l1llll111l11_l1_ = l1lll1ll11l1_l1_
	# 3 l11lll1l1ll_l1_:	13KB:	l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䫻"): l11l1l_l1_ (u"ࠩࡌࡓࡘࡥࡃࡓࡇࡄࡘࡔࡘࠧ䫼"),l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䫽"): l11l1l_l1_ (u"ࠫ࠷࠸࠮࠴࠵࠱࠵࠵࠷ࠧ䫾")
	# 7 l11lll1l1ll_l1_		44KB:	l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䫿"): l11l1l_l1_ (u"࠭ࡉࡐࡕࡢࡑࡊ࡙ࡓࡂࡉࡈࡗࡤࡋࡘࡕࡇࡑࡗࡎࡕࡎࠨ䬀"),l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䬁"): l11l1l_l1_ (u"ࠨ࠳࠺࠲࠸࠹࠮࠳ࠩ䬂")
	# 7 l11lll1l1ll_l1_		58KB:	l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䬃"): l11l1l_l1_ (u"ࠪࡍࡔ࡙ࠧ䬄"),l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䬅"): l11l1l_l1_ (u"ࠬ࠷࠷࠯࠵࠶࠲࠷࠭䬆")
	# 9 l11lll1l1ll_l1_		24KB:	l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䬇"): l11l1l_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ䬈"),l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䬉"): l11l1l_l1_ (u"ࠩ࠵࠶࠳࠹࠰࠯࠳࠳࠴ࠬ䬊")
	# no json file:		21 l11lll1l1ll_l1_	95KB:	l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䬋"): l11l1l_l1_ (u"ࠫ࡜ࡋࡂࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ䬌"),l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䬍"): l11l1l_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠸࠱࠴࠵࠴࠰࠱ࠩ䬎")
	# no json file:		21 l11lll1l1ll_l1_	121KB:	l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䬏"): l11l1l_l1_ (u"ࠨ࡙ࡈࡆࠬ䬐"),l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䬑"): l11l1l_l1_ (u"ࠪ࠶࠳࠸࠰࠳࠴࠳࠼࠵࠷࠮࠱࠲࠱࠴࠵࠭䬒")
	# no json file: 	26 l11lll1l1ll_l1_	115KB:	l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䬓"): l11l1l_l1_ (u"ࠬࡓࡗࡆࡄࠪ䬔"),l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䬕"): l11l1l_l1_ (u"ࠧ࠳࠰࠵࠴࠷࠸࠰࠹࠲࠴࠲࠵࠶࠮࠱࠲ࠪ䬖")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䬗"): l11l1l_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࠪ䬘"),l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䬙"): l11l1l_l1_ (u"ࠫ࠶࠽࠮࠴࠳࠱࠷࠺࠭䬚")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䬛"): l11l1l_l1_ (u"࠭ࡗࡆࡄࡢࡖࡊࡓࡉ࡙ࠩ䬜"),l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䬝"): l11l1l_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠵࠻࠳࠶࠱࠯࠲࠳ࠫ䬞")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䬟"): l11l1l_l1_ (u"࡛ࠪࡊࡈ࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ䬠"),l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䬡"): l11l1l_l1_ (u"ࠬ࠷࠮࠳࠲࠵࠶࠵࠽࠳࠲࠰࠳࠴࠳࠶࠰ࠨ䬢")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䬣"): l11l1l_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡇࡐࡆࡊࡊࡄࡆࡆࡢࡔࡑࡇ࡙ࡆࡔࠪ䬤"),l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䬥"): l11l1l_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ䬦")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䬧"): l11l1l_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡓࡕࡔࡋࡆࠫ䬨"),l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䬩"): l11l1l_l1_ (u"࠭࠵࠯࠳࠹࠲࠺࠷ࠧ䬪")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䬫"): l11l1l_l1_ (u"ࠨࡖ࡙ࡌ࡙ࡓࡌ࠶ࡡࡖࡍࡒࡖࡌ࡚ࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ䬬"),l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䬭"): l11l1l_l1_ (u"ࠪ࠶࠳࠶ࠧ䬮")
	# l111l1llll1_l1_:	l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䬯"): l11l1l_l1_ (u"ࠬࡏࡏࡔࡡࡐ࡙ࡘࡏࡃࠨ䬰"),l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䬱"): l11l1l_l1_ (u"ࠧ࠶࠰࠵࠵ࠬ䬲")
	# l111ll1_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䬳")][0]+l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡲࡵࡩࡹࡺࡹࡑࡴ࡬ࡲࡹࡃࡴࡳࡷࡨࠫ䬴")  # l1l1l1l1l1ll_l1_ l1ll1l11l111_l1_ l1l1l1l1l1l1_l1_ and l1l1lll1ll1l_l1_ l1ll11ll11ll_l1_ l1l1l1l111_l1_ l1l1ll1l11ll_l1_ file size
	#l11ll1111_l1_ = l11l1l_l1_ (u"ࠪࡿࠬ䬵")l1l1l111ll1l_l1_ (u"ࠫ࠿࡯ࡤ࠭ࠩ䬶")l1ll1l11ll1l_l1_ (u"ࠬࡀࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠥࡅࡓࡊࡒࡐࡋࡇࠦ࠱ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠣ࠳࠺࠲࠸࠷࠮࠴࠷ࠥࢁࢂࢃࠧ䬷")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ䬸"),l111ll1_l1_,l11ll1111_l1_,l11l1l_l1_ (u"ࠧࠨ䬹"),l11l1l_l1_ (u"ࠨࠩ䬺"),l11l1l_l1_ (u"ࠩࠪ䬻"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ䬼"))
	#html = response.content
	for l11l1ll1l1_l1_ in range(5):
		#l1lllll1_l1_(l11l1l_l1_ (u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็࠽ࠤࠥ࠭䬽")+str(l11l1ll1l1_l1_+1),l11l1l_l1_ (u"ࠬ࠭䬾"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䬿"),l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨ䭀"),l11l1l_l1_ (u"ࠨࠩ䭁"),l11l1l_l1_ (u"ࠩࠪ䭂"),l11l1l_l1_ (u"ࠪࠫ䭃"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ䭄"))
		html = response.content
		if l11l1l_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䭅") in html: break
		time.sleep(2)
	#WRITE_THIS(l11l1l_l1_ (u"࠭ࠧ䭆"),html)
	l11ll1ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ䭇"),html,re.DOTALL)
	if l11ll1ll11_l1_: l11ll1ll11_l1_ = l11ll1ll11_l1_[0]
	else: l11ll1ll11_l1_ = html
	l11ll1ll11_l1_ = l11ll1ll11_l1_.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ䭈"),l11l1l_l1_ (u"ࠩࠩࠫ䭉"))
	l1l1lll1111l_l1_ = EVAL(l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䭊"),l11ll1ll11_l1_)
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬ䭋"),str(l1l1lll1111l_l1_))
	# l1l1l1llllll_l1_ l1lll1ll1lll_l1_ & l11111ll1ll_l1_
	# l1ll1l1ll_l1_ l1lll1l111l1_l1_ l1llll1_l1_ l11lll11l_l1_ l11l1l_l1_ (u"ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠧ䭌") to l111l111l1_l1_ on l1llll1lll1l_l1_
	l1ll1lll_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ䭍")],[l11l1l_l1_ (u"ࠧࠨ䭎")]
	try:
		l1lll1ll1lll_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪ䭏")][l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䭐")][l11l1l_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪ䭑")]
		for l1lll1111l11_l1_ in l1lll1ll1lll_l1_:
			l1llll1_l1_ = l1lll1111l11_l1_[l11l1l_l1_ (u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ䭒")]
			try: title = l1lll1111l11_l1_[l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䭓")][l11l1l_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪ䭔")]
			except: title = l1lll1111l11_l1_[l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䭕")][l11l1l_l1_ (u"ࠨࡴࡸࡲࡸ࠭䭖")][0][l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࠧ䭗")]
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1lll_l1_.append(title)
	except: pass
	if len(l1ll1lll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ䭘"), l1ll1lll_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䭙"),[],[]
		elif l1l_l1_!=0:
			l1llll1_l1_ = l1lll1_l1_[l1l_l1_]+l11l1l_l1_ (u"ࠬࠬࠧ䭚")
			l1ll111lll11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ䭛"),l1llll1_l1_)
			if l1ll111lll11_l1_: l1llll1_l1_ = l1llll1_l1_.replace(l1ll111lll11_l1_[0],l11l1l_l1_ (u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ䭜"))
			else: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ䭝")
			l1ll1l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠫ䭞"))
	formats,l11111ll11l_l1_,l1llll1l1111_l1_,l1llll1l111l_l1_,l1llll11llll_l1_ = [],[],[],[],[]
	# l1l1l1llllll_l1_ l1ll1ll11ll1_l1_ l11lll1l1ll_l1_
	try: l1l1l1l11ll1_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ䭟")][l11l1l_l1_ (u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭䭠")]
	except: pass
	# l1l1l1llllll_l1_ l1lll11lll1l_l1_ stream
	try: l1111l11ll1_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ䭡")][l11l1l_l1_ (u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ䭢")]
	except: pass
	# l1l1l1llllll_l1_ l1ll11lll1_l1_ l11111ll_l1_ l11lll1l1ll_l1_
	try: formats = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ䭣")][l11l1l_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ䭤")]
	except: pass
	# l1l1l1llllll_l1_ l1ll11lll1_l1_ l1111l11111_l1_ l11lll1l1ll_l1_
	try: l11111ll11l_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ䭥")][l11l1l_l1_ (u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ䭦")]
	except: pass
	l1lll11ll11l_l1_ = formats+l11111ll11l_l1_
	for dict in l1lll11ll11l_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䭧"),str(dict))
		if l11l1l_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䭨") in list(dict.keys()): dict[l11l1l_l1_ (u"࠭ࡩࡵࡣࡪࠫ䭩")] = str(dict[l11l1l_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ䭪")])
		if l11l1l_l1_ (u"ࠨࡨࡳࡷࠬ䭫") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠩࡩࡴࡸ࠭䭬")] = str(dict[l11l1l_l1_ (u"ࠪࡪࡵࡹࠧ䭭")])
		if l11l1l_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭䭮") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠬࡺࡹࡱࡧࠪ䭯")] = dict[l11l1l_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ䭰")]		#.replace(l11l1l_l1_ (u"ࠧ࠾ࠩ䭱"),l11l1l_l1_ (u"ࠨ࠿ࠪ䭲"))+l11l1l_l1_ (u"ࠩࠥࠫ䭳")
		if l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ䭴") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ䭵")] = str(dict[l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ䭶")])
		if l11l1l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䭷") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ䭸")] = str(dict[l11l1l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ䭹")])
		if l11l1l_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ䭺") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ䭻")] = str(dict[l11l1l_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ䭼")])+l11l1l_l1_ (u"ࠬࡾࠧ䭽")+str(dict[l11l1l_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭䭾")])
		if l11l1l_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ䭿") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䮀")] = dict[l11l1l_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ䮁")][l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ䮂")]+l11l1l_l1_ (u"ࠫ࠲࠭䮃")+dict[l11l1l_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ䮄")][l11l1l_l1_ (u"࠭ࡥ࡯ࡦࠪ䮅")]
		if l11l1l_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ䮆") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ䮇")] = dict[l11l1l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭䮈")][l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ䮉")]+l11l1l_l1_ (u"ࠫ࠲࠭䮊")+dict[l11l1l_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ䮋")][l11l1l_l1_ (u"࠭ࡥ࡯ࡦࠪ䮌")]
		if l11l1l_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ䮍") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䮎")] = dict[l11l1l_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ䮏")]
		if l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䮐") in list(dict.keys()) and int(dict[l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䮑")])>111222333: del dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䮒")]
		if l11l1l_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ䮓") in list(dict.keys()):
			cipher = dict[l11l1l_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ䮔")].split(l11l1l_l1_ (u"ࠨࠨࠪ䮕"))
			for item in cipher:
				key,value = item.split(l11l1l_l1_ (u"ࠩࡀࠫ䮖"),1)
				dict[key] = l1llll_l1_(value)
		if l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䮗") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䮘")] = l1llll_l1_(dict[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䮙")])
		#if l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸࡃࠧ䮚") in dict[l11l1l_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ䮛")]: dict[l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䮜")] = dict[l11l1l_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ䮝")].split(l11l1l_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࡀࡠࠧ࠭䮞"))[1].strip(l11l1l_l1_ (u"ࠫࡡࠨࠧ䮟"))
		#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭䮠"),dict[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࠫ䮡")]+l11l1l_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠࠨ䮢")+dict[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭䮣")])
		l1llll1l1111_l1_.append(dict)
	l11l1l11l_l1_ = l11l1l_l1_ (u"ࠩࠪ䮤")
	if l11l1l_l1_ (u"ࠪࡷࡵࡃࡳࡪࡩࠪ䮥") in l11ll1ll11_l1_:
		#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡾࡺࡳ࠰࡬ࡶࡦ࡮ࡴ࠯ࡱ࡮ࡤࡽࡪࡸ࡟࠯ࠬࡂ࠭ࠧ࠭䮦"),html,re.DOTALL)
		# l1llll1ll111_l1_:	/s/l1ll1111111l_l1_/6dde7fb4/l1l1ll1l111l_l1_.l1ll1l111ll1_l1_/l1ll1ll1l1l1_l1_/base.l1l1ll11ll1l_l1_
		#l1lllll1ll11_l1_ = [l11l1l_l1_ (u"ࠬ࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰ࡦ࠻࠻ࡩ࠻࠸࠲ࡨ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࡙ࡘ࠵ࡢࡢࡵࡨ࠲࡯ࡹࠧ䮧")]
		l1lllll1ll11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ䮨"),html,re.DOTALL)
		if l1lllll1ll11_l1_:
			l1lllll1ll11_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䮩")][0]+l1lllll1ll11_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䮪"),l1lllll1ll11_l1_,l11l1l_l1_ (u"ࠩࠪ䮫"),l11l1l_l1_ (u"ࠪࠫ䮬"),l11l1l_l1_ (u"ࠫࠬ䮭"),l11l1l_l1_ (u"ࠬ࠭䮮"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ䮯"))
			l11l1l11l_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1l1ll111l11_l1_ = cipher._load_javascript(l11l1l11l_l1_)
			l1l1l1l11l1l_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ䮰"),str(l1l1ll111l11_l1_))
			l1l1llllll11_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l1l1l11l1l_l1_)
	for dict in l1llll1l1111_l1_:
		url = dict[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䮱")]
		if l11l1l_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭䮲") in url or url.count(l11l1l_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ䮳"))>1:
			l1llll1l111l_l1_.append(dict)
		elif l11l1l11l_l1_ and l11l1l_l1_ (u"ࠫࡸ࠭䮴") in list(dict.keys()) and l11l1l_l1_ (u"ࠬࡹࡰࠨ䮵") in list(dict.keys()):
			l1lll11111l1_l1_ = l1l1llllll11_l1_.execute(dict[l11l1l_l1_ (u"࠭ࡳࠨ䮶")])
			if l1lll11111l1_l1_!=dict[l11l1l_l1_ (u"ࠧࡴࠩ䮷")]:
				dict[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䮸")] = url+l11l1l_l1_ (u"ࠩࠩࠫ䮹")+dict[l11l1l_l1_ (u"ࠪࡷࡵ࠭䮺")]+l11l1l_l1_ (u"ࠫࡂ࠭䮻")+l1lll11111l1_l1_
				l1llll1l111l_l1_.append(dict)
	for dict in l1llll1l111l_l1_:
		l11ll1l_l1_,l1l1lll111ll_l1_,l1ll111lllll_l1_,l11ll11l1_l1_,codecs,l1lllllllll1_l1_ = l11l1l_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭䮼"),l11l1l_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ䮽"),l11l1l_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ䮾"),l11l1l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ䮿"),l11l1l_l1_ (u"ࠩࠪ䯀"),l11l1l_l1_ (u"ࠪ࠴ࠬ䯁")
		try:
			l1llll1l11l1_l1_ = dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦࠩ䯂")]
			l1llll1l11l1_l1_ = l1llll1l11l1_l1_.replace(l11l1l_l1_ (u"ࠬ࠱ࠧ䯃"),l11l1l_l1_ (u"࠭ࠧ䯄"))
			items = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䯅"),l1llll1l11l1_l1_,re.DOTALL)
			l11ll11l1_l1_,l11ll1l_l1_,codecs = items[0]
			l111111llll_l1_ = codecs.split(l11l1l_l1_ (u"ࠨ࠮ࠪ䯆"))
			l1l1lll111ll_l1_ = l11l1l_l1_ (u"ࠩࠪ䯇")
			for item in l111111llll_l1_: l1l1lll111ll_l1_ += item.split(l11l1l_l1_ (u"ࠪ࠲ࠬ䯈"))[0]+l11l1l_l1_ (u"ࠫ࠱࠭䯉")
			l1l1lll111ll_l1_ = l1l1lll111ll_l1_.strip(l11l1l_l1_ (u"ࠬ࠲ࠧ䯊"))
			if l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䯋") in list(dict.keys()): l1lllllllll1_l1_ = str(float(dict[l11l1l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䯌")]*10)//1024/10)+l11l1l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ䯍")
			else: l1lllllllll1_l1_ = l11l1l_l1_ (u"ࠩࠪ䯎")
			if l11ll11l1_l1_==l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࠨ䯏"): continue
			elif l11l1l_l1_ (u"ࠫ࠱࠭䯐") in l1llll1l11l1_l1_:
				l11ll11l1_l1_ = l11l1l_l1_ (u"ࠬࡇࠫࡗࠩ䯑")
				l1ll111lllll_l1_ = l11ll1l_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠩ䯒")+l1lllllllll1_l1_+dict[l11l1l_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ䯓")].split(l11l1l_l1_ (u"ࠨࡺࠪ䯔"))[1]
			elif l11ll11l1_l1_==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䯕"):
				l11ll11l1_l1_ = l11l1l_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ䯖")
				l1ll111lllll_l1_ = l1lllllllll1_l1_+dict[l11l1l_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ䯗")].split(l11l1l_l1_ (u"ࠬࡾࠧ䯘"))[1]+l11l1l_l1_ (u"࠭ࠠࠡࠩ䯙")+dict[l11l1l_l1_ (u"ࠧࡧࡲࡶࠫ䯚")]+l11l1l_l1_ (u"ࠨࡨࡳࡷࠬ䯛")+l11l1l_l1_ (u"ࠩࠣࠤࠬ䯜")+l11ll1l_l1_
			elif l11ll11l1_l1_==l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䯝"):
				l11ll11l1_l1_ = l11l1l_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ䯞")
				l1ll111lllll_l1_ = l1lllllllll1_l1_+str(int(dict[l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ䯟")])/1000)+l11l1l_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ䯠")+dict[l11l1l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ䯡")]+l11l1l_l1_ (u"ࠨࡥ࡫ࠫ䯢")+l11l1l_l1_ (u"ࠩࠣࠤࠬ䯣")+l11ll1l_l1_
		except:
			l1lll11111ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll11111ll_l1_)
		if l11l1l_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ䯤") in dict[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䯥")]: l1l11ll11_l1_ = round(0.5+float(dict[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䯦")].split(l11l1l_l1_ (u"࠭ࡤࡶࡴࡀࠫ䯧"),1)[1].split(l11l1l_l1_ (u"ࠧࠧࠩ䯨"),1)[0]))
		elif l11l1l_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ䯩") in list(dict.keys()): l1l11ll11_l1_ = round(0.5+float(dict[l11l1l_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ䯪")])/1000)
		else: l1l11ll11_l1_ = l11l1l_l1_ (u"ࠪ࠴ࠬ䯫")
		if l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䯬") not in list(dict.keys()): l1lllllllll1_l1_ = dict[l11l1l_l1_ (u"ࠬࡹࡩࡻࡧࠪ䯭")].split(l11l1l_l1_ (u"࠭ࡸࠨ䯮"))[1]
		else: l1lllllllll1_l1_ = dict[l11l1l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䯯")]
		if l11l1l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䯰") not in list(dict.keys()): dict[l11l1l_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ䯱")] = l11l1l_l1_ (u"ࠪ࠴࠲࠶ࠧ䯲")
		dict[l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䯳")] = l11ll11l1_l1_+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ䯴")+l1ll111lllll_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠪࠪ䯵")+l1l1lll111ll_l1_+l11l1l_l1_ (u"ࠧ࠭ࠩ䯶")+dict[l11l1l_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭䯷")]+l11l1l_l1_ (u"ࠩࠬࠫ䯸")
		dict[l11l1l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ䯹")] = l1ll111lllll_l1_.split(l11l1l_l1_ (u"ࠫࠥࠦࠧ䯺"))[0].split(l11l1l_l1_ (u"ࠬࡱࡢࡱࡵࠪ䯻"))[0]
		dict[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ䯼")] = l11ll11l1_l1_
		dict[l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䯽")] = l11ll1l_l1_
		dict[l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䯾")] = codecs
		dict[l11l1l_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ䯿")] = l1l11ll11_l1_
		dict[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰀")] = l1lllllllll1_l1_
		l1llll11llll_l1_.append(dict)
	l1lll11l1ll1_l1_,l1lllll1lll1_l1_,l1111l1111l_l1_,l1ll1l11llll_l1_,l1lll1llllll_l1_ = [],[],[],[],[]
	l1ll11lll1ll_l1_,l1llll1l1ll1_l1_,l1ll111l1l1l_l1_,l111111ll11_l1_,l11111lll11_l1_ = [],[],[],[],[]
	if l1l1l1l11ll1_l1_:
		dict = {}
		dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䰁")] = l11l1l_l1_ (u"ࠬࡇࠫࡗࠩ䰂")
		dict[l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䰃")] = l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠫ䰄")
		dict[l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䰅")] = dict[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䰆")]+l11l1l_l1_ (u"ࠪ࠾ࠥࠦࠧ䰇")+dict[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䰈")]+l11l1l_l1_ (u"ࠬࠦࠠࠨ䰉")+l11l1l_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ䰊")
		dict[l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䰋")] = l1l1l1l11ll1_l1_
		dict[l11l1l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䰌")] = l11l1l_l1_ (u"ࠩ࠳ࠫ䰍") # for l11l11ll11_l1_ l1l1l1l11ll1_l1_ any l1l111l1l_l1_ will l1111l1ll11_l1_ l1l1lllllll1_l1_ sort l1l1l1l1lll_l1_
		dict[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰎")] = l11l1l_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ䰏") # 20
		l1llll11llll_l1_.append(dict)
	if l1111l11ll1_l1_:
		l1l1ll1ll111_l1_,l1lllll11l11_l1_ = l11l1lllll_l1_(l1111l11ll1_l1_)
		l1llllllll1l_l1_ = list(zip(l1l1ll1ll111_l1_,l1lllll11l11_l1_))
		for title,l1llll1_l1_ in l1llllllll1l_l1_:
			dict = {}
			dict[l11l1l_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䰐")] = l11l1l_l1_ (u"࠭ࡁࠬࡘࠪ䰑")
			dict[l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䰒")] = l11l1l_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭䰓")
			dict[l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䰔")] = l1llll1_l1_
			#if l11l1l_l1_ (u"ࠪࡆ࡜ࡀࠠࠨ䰕") in title: dict[l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䰖")] = title.split(l11l1l_l1_ (u"ࠬࠦࠠࠨ䰗"))[1].split(l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠫ䰘"))[0]
			#if l11l1l_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭䰙") in title: dict[l11l1l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䰚")] = title.split(l11l1l_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ䰛"))[1]
			# title = l11l1l_l1_ (u"ࠥ࠸࠷࠼࠷࡬ࡤࡳࡷࠥࠦ࠷࠳࠲ࠣࠤ࠳ࡳ࠳ࡶ࠺ࠥ䰜")
			if l11l1l_l1_ (u"ࠫࡰࡨࡰࡴࠩ䰝") in title: dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䰞")] = title.split(l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠫ䰟"))[0].rsplit(l11l1l_l1_ (u"ࠧࠡࠢࠪ䰠"))[-1]
			else: dict[l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䰡")] = l11l1l_l1_ (u"ࠩ࠴࠴ࠬ䰢")
			if title.count(l11l1l_l1_ (u"ࠪࠤࠥ࠭䰣"))>1:
				l111ll1l_l1_ = title.rsplit(l11l1l_l1_ (u"ࠫࠥࠦࠧ䰤"))[-3]
				if l111ll1l_l1_.isdigit(): dict[l11l1l_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭䰥")] = l111ll1l_l1_
				else: dict[l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䰦")] = l11l1l_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ䰧")
			#dict[l11l1l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䰨")] = title
			if title==l11l1l_l1_ (u"ࠩ࠰࠵ࠬ䰩"): dict[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䰪")] = dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䰫")]+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ䰬")+dict[l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䰭")]+l11l1l_l1_ (u"ࠧࠡࠢࠪ䰮")+l11l1l_l1_ (u"ࠨฮ๋ำฮࠦะไ์ฬࠫ䰯")
			else: dict[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䰰")] = dict[l11l1l_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䰱")]+l11l1l_l1_ (u"ࠫ࠿ࠦࠠࠨ䰲")+dict[l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䰳")]+l11l1l_l1_ (u"࠭ࠠࠡࠩ䰴")+dict[l11l1l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䰵")]+l11l1l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ䰶")+dict[l11l1l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ䰷")]
			l1llll11llll_l1_.append(dict)
	l1llll11llll_l1_ = sorted(l1llll11llll_l1_,reverse=True,key=lambda key: float(key[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰸")]))
	if not l1llll11llll_l1_:
		l1ll111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䰹"),html,re.DOTALL)
		l1ll111lll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰺"),html,re.DOTALL)
		l1lll11l111l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䰻"),html,re.DOTALL)
		l1lll11l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰼"),html,re.DOTALL)
		try: l1lll11l11ll_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䰽")][l11l1l_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ䰾")][l11l1l_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ䰿")][l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䱀")][l11l1l_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ䱁")][0][l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࠫ䱂")]
		except: l1lll11l11ll_l1_ = l11l1l_l1_ (u"ࠧࠨ䱃")
		try: l1lll11l1l11_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䱄")][l11l1l_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ䱅")][l11l1l_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ䱆")][l11l1l_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬ䱇")][0][l11l1l_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ䱈")][0][l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࠫ䱉")]
		except: l1lll11l1l11_l1_ = l11l1l_l1_ (u"ࠧࠨ䱊")
		try: l1l1lllll1ll_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䱋")][l11l1l_l1_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩ䱌")]
		except: l1l1lllll1ll_l1_ = l11l1l_l1_ (u"ࠪࠫ䱍")
		if l1ll111ll1l_l1_ or l1ll111lll1_l1_ or l1lll11l111l_l1_ or l1lll11l11l1_l1_ or l1lll11l11ll_l1_ or l1lll11l1l11_l1_ or l1l1lllll1ll_l1_:
			if   l1ll111ll1l_l1_: message = l1ll111ll1l_l1_[0]
			elif l1ll111lll1_l1_: message = l1ll111lll1_l1_[0]
			elif l1lll11l111l_l1_: message = l1lll11l111l_l1_[0]
			elif l1lll11l11l1_l1_: message = l1lll11l11l1_l1_[0]
			elif l1lll11l11ll_l1_: message = l1lll11l11ll_l1_
			elif l1lll11l1l11_l1_: message = l1lll11l1l11_l1_
			elif l1l1lllll1ll_l1_: message = l1l1lllll1ll_l1_
			l1ll111ll111_l1_ = message.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ䱎"),l11l1l_l1_ (u"ࠬ࠭䱏")).strip(l11l1l_l1_ (u"࠭ࠠࠨ䱐"))
			l1lll1ll111l_l1_ = l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊ิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䱑")
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䱒"),l11l1l_l1_ (u"ࠩࠪ䱓"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧ䱔"),l1lll1ll111l_l1_+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䱕")+l1ll111ll111_l1_)
			return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧ䱖")+l1ll111ll111_l1_,[],[]
		else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭䱗"),[],[]
	l1l1llllll1l_l1_,l1l1l11l1l11_l1_,l1ll1llllll1_l1_ = [],[],[]
	for dict in l1llll11llll_l1_:
		if dict[l11l1l_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭䱘")]==l11l1l_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ䱙"):
			l1lll11l1ll1_l1_.append(dict[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䱚")])
			l1ll11lll1ll_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䱛")]==l11l1l_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ䱜"):
			l1lllll1lll1_l1_.append(dict[l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䱝")])
			l1llll1l1ll1_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䱞")]==l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠫ䱟"):
			title = dict[l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䱠")].replace(l11l1l_l1_ (u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ䱡"),l11l1l_l1_ (u"ࠪࠫ䱢"))
			if l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䱣") not in list(dict.keys()): l1lllllllll1_l1_ = l11l1l_l1_ (u"ࠬ࠶ࠧ䱤")
			else: l1lllllllll1_l1_ = dict[l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䱥")]
			l1l1llllll1l_l1_.append([dict,{},title,l1lllllllll1_l1_])
		else:
			title = dict[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䱦")].replace(l11l1l_l1_ (u"ࠨࡃ࠮࡚࠿ࠦࠠࠨ䱧"),l11l1l_l1_ (u"ࠩࠪ䱨"))
			if l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䱩") not in list(dict.keys()): l1lllllllll1_l1_ = l11l1l_l1_ (u"ࠫ࠵࠭䱪")
			else: l1lllllllll1_l1_ = dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䱫")]
			l1l1llllll1l_l1_.append([dict,{},title,l1lllllllll1_l1_])
			l1111l1111l_l1_.append(title)
			l1ll111l1l1l_l1_.append(dict)
		l111111111l_l1_ = True
		if l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䱬") in list(dict.keys()):
			if l11l1l_l1_ (u"ࠧࡢࡸ࠳ࠫ䱭") in dict[l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䱮")]: l111111111l_l1_ = False
			elif kodi_version<18:
				if l11l1l_l1_ (u"ࠩࡤࡺࡨ࠭䱯") not in dict[l11l1l_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䱰")] and l11l1l_l1_ (u"ࠫࡲࡶ࠴ࡢࠩ䱱") not in dict[l11l1l_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ䱲")]: l111111111l_l1_ = False
		if dict[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ䱳")]==l11l1l_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭䱴") and dict[l11l1l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䱵")]!=l11l1l_l1_ (u"ࠩ࠳࠱࠵࠭䱶") and l111111111l_l1_==True:
			l1lll1llllll_l1_.append(dict[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䱷")])
			l11111lll11_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䱸")]==l11l1l_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ䱹") and dict[l11l1l_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䱺")]!=l11l1l_l1_ (u"ࠧ࠱࠯࠳ࠫ䱻") and l111111111l_l1_==True:
			l1ll1l11llll_l1_.append(dict[l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䱼")])
			l111111ll11_l1_.append(dict)
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ䱽"),l11l1l_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ䱾")+dict[l11l1l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䱿")])
	for l1llllll1ll1_l1_ in l111111ll11_l1_:
		l1ll1l1l11l1_l1_ = l1llllll1ll1_l1_[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䲀")]
		for l1lll111ll11_l1_ in l11111lll11_l1_:
			l1l1lll1ll11_l1_ = l1lll111ll11_l1_[l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䲁")]
			l1lllllllll1_l1_ = l1l1lll1ll11_l1_+l1ll1l1l11l1_l1_
			title = l1lll111ll11_l1_[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䲂")].replace(l11l1l_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ䲃"),l11l1l_l1_ (u"ࠩࡰࡴࡩࠦࠠࠨ䲄"))
			title = title.replace(l1lll111ll11_l1_[l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䲅")]+l11l1l_l1_ (u"ࠫࠥࠦࠧ䲆"),l11l1l_l1_ (u"ࠬ࠭䲇"))
			title = title.replace(str((float(l1l1lll1ll11_l1_*10)//1024/10))+l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠫ䲈"),str((float(l1lllllllll1_l1_*10)//1024/10))+l11l1l_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ䲉"))
			title = title+l11l1l_l1_ (u"ࠨࠪࠪ䲊")+l1llllll1ll1_l1_[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䲋")].split(l11l1l_l1_ (u"ࠪࠬࠬ䲌"),1)[1]
			l1l1llllll1l_l1_.append([l1lll111ll11_l1_,l1llllll1ll1_l1_,title,l1lllllllll1_l1_])
	l1l1llllll1l_l1_ = sorted(l1l1llllll1l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1lll111ll11_l1_,l1llllll1ll1_l1_,title,l1lllllllll1_l1_ in l1l1llllll1l_l1_:
		l1llll11ll11_l1_ = l1lll111ll11_l1_[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䲍")]
		if l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䲎") in list(l1llllll1ll1_l1_.keys()):
			l1llll11ll11_l1_ = l11l1l_l1_ (u"࠭࡭ࡱࡦࠪ䲏")
			#l1llll11ll11_l1_ = l1llll11ll11_l1_+l1llllll1ll1_l1_[l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䲐")]
		if l1llll11ll11_l1_ not in l1ll1llllll1_l1_:
			l1ll1llllll1_l1_.append(l1llll11ll11_l1_)
			l1l1l11l1l11_l1_.append([l1lll111ll11_l1_,l1llllll1ll1_l1_,title,l1lllllllll1_l1_])
			#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ䲑"),str(l1lllllllll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭䲒")+title)
	#l1l1l11l1l11_l1_ = sorted(l1l1l11l1l11_l1_, reverse=True, key=lambda key: int(key[3]))
	l1l1lllll1l1_l1_,l1ll1l111l1l_l1_,shift = [],[],0
	l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡰࡹࡱࡩࡷࠨ࠺࠯ࠬࡂࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶ࠿ࠐࠉࠊࡵ࡫࡭࡫ࡺࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࠫࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠳ࡡ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠱࡞ࠌࠌࠍࡸ࡫࡬ࡦࡥࡷࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡧ࡭ࡵࡩࡤࡧࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ䲓")
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡱࡺࡲࡪࡸ࡟ࡤࡪࡤࡲࡳ࡫࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲ࡟࡫ࡵࡲࡲ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡸࡸ࡭ࡵࡲࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮ࡢ࡮ࡸࡵ࡮࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡲࡻࡳ࡫ࡲࡠࡰࡤࡱࡪࡀࠊࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡡ࡭࡮ࡲࡻࡗࡧࡴࡪࡰࡪࡷࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࠍ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡩࡧࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࡀࠠࡪ࡯ࡤ࡫ࡪࠦ࠽ࠡ࡫ࡰࡥ࡬࡫ࡳࡠࡷࡵࡰࡠ࠳࠱࡞ࠌࠌࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦ࡝࠳ࡡࠏࠏࠉࡴࡪ࡬ࡪࡹࠦࠫ࠾ࠢ࠴ࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ࠱࡯ࡸࡰࡨࡶ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡜ࡋࡂࡔࡋࡗࡉࡘࡡ࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ࡟࡞࠴ࡢ࠱ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ࠯ࡴࡽ࡮ࡦࡴࡢࡧ࡭ࡧ࡮࡯ࡧ࡯࡟࠵ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ䲔")
	l11111111ll_l1_,l1llll111l1l_l1_ = l11l1l_l1_ (u"ࠬ࠭䲕"),l11l1l_l1_ (u"࠭ࠧ䲖")
	try: l11111111ll_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭䲗")][l11l1l_l1_ (u"ࠨࡣࡸࡸ࡭ࡵࡲࠨ䲘")]
	except: l11111111ll_l1_ = l11l1l_l1_ (u"ࠩࠪ䲙")
	try: l1ll111ll11l_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ䲚")][l11l1l_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧ䲛")]
	except: l1ll111ll11l_l1_ = l11l1l_l1_ (u"ࠬ࠭䲜")
	if l11111111ll_l1_ and l1ll111ll11l_l1_:
		shift += 1
		title = l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ䲝")+l11111111ll_l1_+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䲞")
		l1llll1_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䲟")][0]+l11l1l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ䲠")+l1ll111ll11l_l1_
		l1l1lllll1l1_l1_.append(title)
		l1ll1l111l1l_l1_.append(l1llll1_l1_)
		try: l1llll111l1l_l1_ = l1l1lll1111l_l1_[l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ䲡")][l11l1l_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ䲢")][l11l1l_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩ䲣")][-1][l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䲤")]
		except: pass
	#if l1l1l1l11ll1_l1_:
	#	shift += 1
	#	l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠤั๎ฯสࠢำ็๏ฯࠧ䲥")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠨࡦࡤࡷ࡭࠭䲦"))
	for l1lll111ll11_l1_,l1llllll1ll1_l1_,title,l1lllllllll1_l1_ in l1l1l11l1l11_l1_:
		l1l1lllll1l1_l1_.append(title) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ䲧"))
	if l1111l1111l_l1_: l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ䲨")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ䲩"))
	if l1l1llllll1l_l1_: l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ䲪")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"࠭ࡡ࡭࡮ࠪ䲫"))
	if l1lll1llllll_l1_: l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ䲬")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠨ࡯ࡳࡨࠬ䲭"))
	if l1lll11l1ll1_l1_: l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ䲮")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䲯"))
	if l1lllll1lll1_l1_: l1l1lllll1l1_l1_.append(l11l1l_l1_ (u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ䲰")) ; l1ll1l111l1l_l1_.append(l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ䲱"))
	l1111l111ll_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1l1l111l11l_l1_, l1l1lllll1l1_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䲲"),[],[]
		elif l1l_l1_==0 and l11111111ll_l1_:
			l1llll1_l1_ = l1ll1l111l1l_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11l1l_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ䲳")+QUOTE(l11111111ll_l1_)+l11l1l_l1_ (u"ࠨࠨࡸࡶࡱࡃࠧ䲴")+l1llll1_l1_
			if l1llll111l1l_l1_: new_path = new_path+l11l1l_l1_ (u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ䲵")+QUOTE(l1llll111l1l_l1_)
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ䲶")+new_path+l11l1l_l1_ (u"ࠦ࠮ࠨ䲷"))
			return l11l1l_l1_ (u"ࠬࡋࡘࡊࡖࠪ䲸"),[],[]
		choice = l1ll1l111l1l_l1_[l1l_l1_]
		l1l1ll1l1111_l1_ = l1l1lllll1l1_l1_[l1l_l1_]
		if choice==l11l1l_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ䲹"):
			l1l1l1lll11l_l1_ = l1l1l1l11ll1_l1_
			break
		elif choice in [l11l1l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭䲺"),l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䲻"),l11l1l_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ䲼")]:
			if choice==l11l1l_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ䲽"): l1ll1lll_l1_,l1ll11l1l111_l1_ = l1111l1111l_l1_,l1ll111l1l1l_l1_
			elif choice==l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䲾"): l1ll1lll_l1_,l1ll11l1l111_l1_ = l1lll11l1ll1_l1_,l1ll11lll1ll_l1_
			elif choice==l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ䲿"): l1ll1lll_l1_,l1ll11l1l111_l1_ = l1lllll1lll1_l1_,l1llll1l1ll1_l1_
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䳀"), l1ll1lll_l1_)
			if l1l_l1_!=-1:
				l1l1l1lll11l_l1_ = l1ll11l1l111_l1_[l1l_l1_][l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䳁")]
				l1l1ll1l1111_l1_ = l1ll1lll_l1_[l1l_l1_]
				break
		elif choice==l11l1l_l1_ (u"ࠨ࡯ࡳࡨࠬ䳂"):
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอ࠿࠭䳃"), l1lll1llllll_l1_)
			if l1l_l1_!=-1:
				l1l1ll1l1111_l1_ = l1lll1llllll_l1_[l1l_l1_]
				l1llll111ll1_l1_ = l11111lll11_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ฮ࠿࠭䳄"), l1ll1l11llll_l1_)
				if l1l_l1_!=-1:
					l1l1ll1l1111_l1_ += l11l1l_l1_ (u"ࠫࠥ࠱ࠠࠨ䳅")+l1ll1l11llll_l1_[l1l_l1_]
					l1lll111l1l1_l1_ = l111111ll11_l1_[l1l_l1_]
					l1111l111ll_l1_ = True
					break
		elif choice==l11l1l_l1_ (u"ࠬࡧ࡬࡭ࠩ䳆"):
			l1lllll11111_l1_,l1ll1l1ll111_l1_,l1l1l11ll11l_l1_,l1lll1l1ll1l_l1_ = list(zip(*l1l1llllll1l_l1_))
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䳇"), l1l1l11ll11l_l1_)
			if l1l_l1_!=-1:
				l1l1ll1l1111_l1_ = l1l1l11ll11l_l1_[l1l_l1_]
				l1llll111ll1_l1_ = l1lllll11111_l1_[l1l_l1_]
				if l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠫ䳈") in l1l1l11ll11l_l1_[l1l_l1_] and l1llll111ll1_l1_[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䳉")]!=l1l1l1l11ll1_l1_:
					l1lll111l1l1_l1_ = l1ll1l1ll111_l1_[l1l_l1_]
					l1111l111ll_l1_ = True
				else: l1l1l1lll11l_l1_ = l1llll111ll1_l1_[l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䳊")]
				break
		elif choice==l11l1l_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ䳋"):
			#shift += 1
			l1lllll11111_l1_,l1ll1l1ll111_l1_,l1l1l11ll11l_l1_,l1lll1l1ll1l_l1_ = list(zip(*l1l1l11l1l11_l1_))
			l1llll111ll1_l1_ = l1lllll11111_l1_[l1l_l1_-shift]
			if l11l1l_l1_ (u"ࠫࡲࡶࡤࠨ䳌") in l1l1l11ll11l_l1_[l1l_l1_-shift] and l1llll111ll1_l1_[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䳍")]!=l1l1l1l11ll1_l1_:
				l1lll111l1l1_l1_ = l1ll1l1ll111_l1_[l1l_l1_-shift]
				l1111l111ll_l1_ = True
			else: l1l1l1lll11l_l1_ = l1llll111ll1_l1_[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䳎")]
			l1l1ll1l1111_l1_ = l1l1l11ll11l_l1_[l1l_l1_-shift]
			break
	if not l1111l111ll_l1_: l1l1l1ll1l11_l1_ = l1l1l1lll11l_l1_
	else: l1l1l1ll1l11_l1_ = l11l1l_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠨ䳏")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䳐")]+l11l1l_l1_ (u"ࠩࠣ࠯ࠥࡇࡵࡥ࡫ࡲ࠾ࠥ࠭䳑")+l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䳒")]
	if l1111l111ll_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䳓"),l11l1l_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ䳔")+str(l1llll111ll1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䳕"),l11l1l_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ䳖")+str(l1lll111l1l1_l1_))
		#if l11111ll1l1_l1_>l1ll1llll1l1_l1_: l1l11ll11_l1_ = str(l11111ll1l1_l1_)
		#else: l1l11ll11_l1_ = str(l1ll1llll1l1_l1_)
		#l1l11ll11_l1_ = str(l11111ll1l1_l1_) if l11111ll1l1_l1_>l1ll1llll1l1_l1_ else str(l1ll1llll1l1_l1_)
		l11111ll1l1_l1_ = int(l1llll111ll1_l1_[l11l1l_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ䳗")])
		l1ll1llll1l1_l1_ = int(l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ䳘")])
		l1l11ll11_l1_ = str(max(l11111ll1l1_l1_,l1ll1llll1l1_l1_))
		l1ll1ll1l111_l1_ = l1llll111ll1_l1_[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䳙")].replace(l11l1l_l1_ (u"ࠫࠫ࠭䳚"),l11l1l_l1_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫ䳛"))		# +l11l1l_l1_ (u"࠭ࠦࡳࡣࡱ࡫ࡪࡃ࠰࠮࠳࠳࠴࠵࠶࠰࠱࠲ࠪ䳜")
		l1lllll1llll_l1_ = l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䳝")].replace(l11l1l_l1_ (u"ࠨࠨࠪ䳞"),l11l1l_l1_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ䳟"))		# +l11l1l_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠰࠱࠲࠳࠴࠵࠶ࠧ䳠")
		l1111l11111_l1_ = l11l1l_l1_ (u"ࠫࡁࡅࡸ࡮࡮ࠣࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠷࠮࠱ࠤࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࡂࠨࡕࡕࡈ࠰࠼ࠧࡅ࠾࡝ࡰࠪ䳡")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠬࡂࡍࡑࡆࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡷ࡮ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠷࠶࠰࠲࠱࡛ࡑࡑ࡙ࡣࡩࡧࡰࡥ࠲࡯࡮ࡴࡶࡤࡲࡨ࡫ࠢࠡࡺࡰࡰࡳࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠥࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡱ࡯࡮࡬࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠲࠻࠼࠽࠴ࡾ࡬ࡪࡰ࡮ࠦࠥࡾࡳࡪ࠼ࡶࡧ࡭࡫࡭ࡢࡎࡲࡧࡦࡺࡩࡰࡰࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠦࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡱࡨࡦࡸࡤࡴ࠰࡬ࡷࡴ࠴࡯ࡳࡩ࠲࡭ࡹࡺࡦ࠰ࡒࡸࡦࡱ࡯ࡣ࡭ࡻࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡘࡺࡡ࡯ࡦࡤࡶࡩࡹ࠯ࡎࡒࡈࡋ࠲ࡊࡁࡔࡊࡢࡷࡨ࡮ࡥ࡮ࡣࡢࡪ࡮ࡲࡥࡴ࠱ࡇࡅࡘࡎ࠭ࡎࡒࡇ࠲ࡽࡹࡤࠣࠢࡰ࡭ࡳࡈࡵࡧࡨࡨࡶ࡙࡯࡭ࡦ࠿ࠥࡔ࡙࠷࠮࠶ࡕࠥࠤࡲ࡫ࡤࡪࡣࡓࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࡅࡷࡵࡥࡹ࡯࡯࡯࠿ࠥࡔ࡙࠭䳢")+l1l11ll11_l1_+l11l1l_l1_ (u"࠭ࡓࠣࠢࡷࡽࡵ࡫࠽ࠣࡵࡷࡥࡹ࡯ࡣࠣࠢࡳࡶࡴ࡬ࡩ࡭ࡧࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡶࡲࡰࡨ࡬ࡰࡪࡀࡩࡴࡱࡩࡪ࠲ࡳࡡࡪࡰ࠽࠶࠵࠷࠱ࠣࡀ࡟ࡲࠬ䳣")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ䳤")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠰ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬ䳥")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䳦")]+l11l1l_l1_ (u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁࠧࡺࡲࡶࡧࠥࡂࡡࡴࠧ䳧")		# l1lll1111111_l1_=l11l1l_l1_ (u"ࠦ࠶ࠨ䳨") l11111llll1_l1_=l11l1l_l1_ (u"ࠧࡺࡲࡶࡧࠥ䳩") default=l11l1l_l1_ (u"ࠨࡴࡳࡷࡨࠦ䳪")>\n
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ䳫")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ䳬")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ䳭")]+l11l1l_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ䳮")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䳯")]+l11l1l_l1_ (u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨ䳰")+str(l1llll111ll1_l1_[l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䳱")])+l11l1l_l1_ (u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪ䳲")+str(l1llll111ll1_l1_[l11l1l_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ䳳")])+l11l1l_l1_ (u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭䳴")+str(l1llll111ll1_l1_[l11l1l_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ䳵")])+l11l1l_l1_ (u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫ䳶")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠬ࡬ࡰࡴࠩ䳷")]+l11l1l_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ䳸")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ䳹")+l1ll1ll1l111_l1_+l11l1l_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ䳺")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ䳻")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ䳼")]+l11l1l_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ䳽")	# l1l1l11l1l1l_l1_=l11l1l_l1_ (u"ࠧࡺࡲࡶࡧࠥ䳾")>\n
		l1111l11111_l1_ += l11l1l_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ䳿")+l1llll111ll1_l1_[l11l1l_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ䴀")]+l11l1l_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ䴁")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ䴂")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ䴃")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ䴄")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠵ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡤࡹࡩ࡯࡯࠰ࠩ䴅")+l1lll111l1l1_l1_[l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䴆")]+l11l1l_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ䴇")		# l1lll1111111_l1_=l11l1l_l1_ (u"ࠣ࠳ࠥ䴈") l11111llll1_l1_=l11l1l_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ䴉") default=l11l1l_l1_ (u"ࠥࡸࡷࡻࡥࠣ䴊")>\n
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ䴋")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ䴌")+l1lll111l1l1_l1_[l11l1l_l1_ (u"࠭ࡩࡵࡣࡪࠫ䴍")]+l11l1l_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ䴎")+l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䴏")]+l11l1l_l1_ (u"ࠩࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣ࠳࠶࠴࠹࠽࠵ࠣࡀ࡟ࡲࠬ䴐")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠪࡀࡆࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻࠴࠶࠴࠵࠹࠺࠴࠼ࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠩ䴑")+l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䴒")]+l11l1l_l1_ (u"ࠬࠨ࠯࠿࡞ࡱࠫ䴓")
		l1111l11111_l1_ += l11l1l_l1_ (u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩ䴔")+l1lllll1llll_l1_+l11l1l_l1_ (u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭䴕")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭䴖")+l1lll111l1l1_l1_[l11l1l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ䴗")]+l11l1l_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ䴘")	# l1l1l11l1l1l_l1_=l11l1l_l1_ (u"ࠦࡹࡸࡵࡦࠤ䴙")>\n
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ䴚")+l1lll111l1l1_l1_[l11l1l_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䴛")]+l11l1l_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ䴜")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ䴝")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ䴞")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ䴟")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ䴠")
		l1111l11111_l1_ += l11l1l_l1_ (u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴࠧ䴡")
		#open(l11l1l_l1_ (u"࠭ࡳ࠻࡞࡟ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ䴢"),l11l1l_l1_ (u"ࠧࡸࡤࠪ䴣")).write(l1111l11111_l1_)
		#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ䴤"),l1111l11111_l1_)
		#l1111l11111_l1_ = OPENURL_CACHED(NO_CACHE,l1l1l1l11ll1_l1_,l11l1l_l1_ (u"ࠩࠪ䴥"),l11l1l_l1_ (u"ࠪࠫ䴦"),l11l1l_l1_ (u"ࠫࠬ䴧"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠼ࡸ࡭࠭䴨"))
		if kodi_version>18.99:
			import http.server as l1lll1l11111_l1_
			import http.client as l1l1lllll111_l1_
		else:
			import BaseHTTPServer as l1lll1l11111_l1_
			import httplib as l1l1lllll111_l1_
		class l1l1ll11l1ll_l1_(l1lll1l11111_l1_.HTTPServer):
			#l1111l11111_l1_ = l11l1l_l1_ (u"࠭࠼࠿ࠩ䴩")
			def __init__(self,l1ll11111l11_l1_=l11l1l_l1_ (u"ࠧ࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶࠪ䴪"),port=55055,l1111l11111_l1_=l11l1l_l1_ (u"ࠨ࠾ࡁࠫ䴫")):
				self.l1ll11111l11_l1_ = l1ll11111l11_l1_
				self.port = port
				self.l1111l11111_l1_ = l1111l11111_l1_
				l1lll1l11111_l1_.HTTPServer.__init__(self,(self.l1ll11111l11_l1_,self.port),l1ll1l11l11l_l1_)
				self.l1l1ll11111l_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ䴬")+l1ll11111l11_l1_+l11l1l_l1_ (u"ࠪ࠾ࠬ䴭")+str(port)+l11l1l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ䴮")
				#print(l11l1l_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡷࡳࠤࡳࡵࡷࠡ࡮࡬ࡷࡹ࡫࡮ࡪࡰࡪࠤࡴࡴࠠࡱࡱࡵࡸ࠿ࠦࠧ䴯")+str(port))
			def start(self):
				self.threads = l1llll11l1ll_l1_(False)
				self.threads.start_new_thread(1,self.l1ll1lll1l11_l1_)
			def l1ll1lll1l11_l1_(self):
				#print(l11l1l_l1_ (u"࠭ࡳࡦࡴࡹ࡭ࡳ࡭ࠠࡳࡧࡴࡹࡪࡹࡴࡴࠢࡶࡸࡦࡸࡴࡦࡦࠪ䴰"))
				self.l1l1l11l1111_l1_ = True
				#l1l1l1ll11l_l1_ = 0
				while self.l1l1l11l1111_l1_:
					#l1l1l1ll11l_l1_ += 1
					#print(l11l1l_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠡࡣࠣࡷ࡮ࡴࡧ࡭ࡧࠣ࡬ࡦࡴࡤ࡭ࡧࡢࡶࡪࡷࡵࡦࡵࡷࠬ࠮ࠦ࡮ࡰࡹ࠽ࠤࠬ䴱")+str(l1l1l1ll11l_l1_)+l11l1l_l1_ (u"ࠨࠩ䴲"))
					#settimeout l1111l1l1l_l1_ not l111l111l1_l1_ l1ll111l11l1_l1_ to error message if it l1l1ll1lllll_l1_ l1l1l11lllll_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l1ll1lll1l11_l1_ l1ll1lllll1l_l1_ request l1l1l1llll11_l1_ 60 seconds)
					self.handle_request()
				#print(l11l1l_l1_ (u"ࠩࡶࡩࡷࡼࡩ࡯ࡩࠣࡶࡪࡷࡵࡦࡵࡷࡷࠥࡹࡴࡰࡲࡳࡩࡩࡢ࡮ࠨ䴳"))
			def stop(self):
				self.l1l1l11l1111_l1_ = False
				self.l1lll111ll1l_l1_()	# needed to l11111l1111_l1_ self.handle_request() to l1ll1lll1l11_l1_ l1lll1ll1ll1_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11l1l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡤࡰࡹࡱࠤࡳࡵࡷ࡝ࡰࠪ䴴"))
			def load(self,l1111l11111_l1_):
				self.l1111l11111_l1_ = l1111l11111_l1_
			def l1lll111ll1l_l1_(self):
				conn = l1l1lllll111_l1_.HTTPConnection(self.l1ll11111l11_l1_+l11l1l_l1_ (u"ࠫ࠿࠭䴵")+str(self.port))
				conn.request(l11l1l_l1_ (u"ࠧࡎࡅࡂࡆࠥ䴶"), l11l1l_l1_ (u"ࠨ࠯ࠣ䴷"))
		class l1ll1l11l11l_l1_(l1lll1l11111_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11l1l_l1_ (u"ࠧࡥࡱ࡬ࡲ࡬ࠦࡇࡆࡖࠣࠤࠬ䴸")+self.path)
				self.send_response(200)
				self.send_header(l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ䴹"),l11l1l_l1_ (u"ࠩࡷࡩࡽࡺ࠯ࡱ࡮ࡤ࡭ࡳ࠭䴺"))
				self.end_headers()
				#self.wfile.write(self.path+l11l1l_l1_ (u"ࠪࡠࡳ࠭䴻"))
				self.wfile.write(self.server.l1111l11111_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䴼")))
				time.sleep(1)
				if self.path==l11l1l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ䴽"): self.server.shutdown()
				if self.path==l11l1l_l1_ (u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ䴾"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11l1l_l1_ (u"ࠧࡥࡱ࡬ࡲ࡬ࠦࡈࡆࡃࡇࠤࠥ࠭䴿")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1l1ll11l1ll_l1_(l11l1l_l1_ (u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫ䵀"),55055,l1111l11111_l1_)
		#httpd.load(l1111l11111_l1_)
		l1l1l1lll11l_l1_ = httpd.l1l1ll11111l_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1l1l1lll11l_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰ࡮ࡼࡥࡴ࡫ࡰ࠲ࡩࡧࡳࡩ࡫ࡩ࠲ࡴࡸࡧ࠰࡮࡬ࡺࡪࡹࡩ࡮࠱ࡦ࡬ࡺࡴ࡫ࡥࡷࡵࡣ࠶࠵ࡡࡵࡱࡢ࠻࠴ࡺࡥࡴࡶࡳ࡭ࡨ࠺࡟࠹ࡵ࠲ࡑࡦࡴࡩࡧࡧࡶࡸ࠳ࡳࡰࡥࠩ䵁")
		#l1l1l1lll11l_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡧࡳࡩ࠰ࡤ࡯ࡦࡳࡡࡪࡼࡨࡨ࠳ࡴࡥࡵ࠱ࡧࡥࡸ࡮࠲࠷࠶࠲ࡘࡪࡹࡴࡄࡣࡶࡩࡸ࠵࠲ࡤ࠱ࡴࡹࡦࡲࡣࡰ࡯ࡰ࠳࠶࠵ࡍࡶ࡮ࡷ࡭ࡗ࡫ࡳࡎࡒࡈࡋ࠷࠴࡭ࡱࡦࠪ䵂")
		#l1l1l1lll11l_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡴ࡫࠱ࡸࡪࡲࡥࡤࡱࡰ࠱ࡵࡧࡲࡪࡵࡷࡩࡨ࡮࠮ࡧࡴ࠲࡫ࡵࡧࡣ࠰ࡆࡄࡗࡍࡥࡃࡐࡐࡉࡓࡗࡓࡁࡏࡅࡈ࠳࡙࡫࡬ࡦࡥࡲࡱࡕࡧࡲࡪࡵࡗࡩࡨ࡮࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠱ࡰࡴ࠹࠳࡬ࡪࡸࡨ࠱ࡲࡶࡤ࠮ࡃ࡙࠱ࡇ࡙࠮࡮ࡲࡧࠫ䵃")
		#l1l1l1lll11l_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡸࡤ࡮ࡧࡧ࡭ࡦ࠴ࡢࡣࡥ࠱ࡧࡴ࠴ࡵ࡬࠱ࡧࡥࡸ࡮࠯ࡰࡰࡧࡩࡲࡧ࡮ࡥ࠱ࡷࡩࡸࡺࡣࡢࡴࡧ࠳࠶࠵ࡣ࡭࡫ࡨࡲࡹࡥ࡭ࡢࡰ࡬ࡪࡪࡹࡴ࠮ࡧࡹࡩࡳࡺࡳ࠮࡯ࡸࡰࡹ࡯࡬ࡢࡰࡪ࠲ࡲࡶࡤࠨ䵄")
		#l1l1l1lll11l_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ࠼࠸࠹࠵࠻࠵࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭䵅")
	else: httpd = l11l1l_l1_ (u"ࠧࠨ䵆")
	if not l1l1l1lll11l_l1_: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䵇"),[],[]
	return l11l1l_l1_ (u"ࠩࠪ䵈"),[l11l1l_l1_ (u"ࠪࠫ䵉")],[[l1l1l1lll11l_l1_,l1ll1l1llll1_l1_,httpd]]
def l1ll11l111ll_l1_(url):
	# https://l111111l111_l1_.com/l1ll11lll1l1_l1_
	headers = { l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䵊") : l11l1l_l1_ (u"ࠬ࠭䵋") }
	#url = url.replace(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䵌"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ䵍"))
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠨࠩ䵎"),headers,l11l1l_l1_ (u"ࠩࠪ䵏"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡅࡓࡇ࠳࠱ࡴࡶࠪ䵐"))
	items = re.findall(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࢀ࠮ࡢࡽࠨ䵑"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l1ll1ll111_l1_,l1ll1lll_l1_,l1lllll11l11_l1_,l1lll1_l1_ = [],[],[],[]
	if items:
		for l1llll1_l1_,dummy,l1ll11l1lll1_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ䵒"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䵓"))
			if l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭䵔") in l1llll1_l1_:
				l1l1ll1ll111_l1_,l1lllll11l11_l1_ = l11l1lllll_l1_(l1llll1_l1_)
				#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䵕"),l11l1l_l1_ (u"ࠩࠪ䵖"),str(l1lll1_l1_),str(l1lllll11l11_l1_))
				l1lll1_l1_ = l1lll1_l1_ + l1lllll11l11_l1_
				if l1l1ll1ll111_l1_[0]==l11l1l_l1_ (u"ࠪ࠱࠶࠭䵗"): l1ll1lll_l1_.append(l11l1l_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ䵘")+l11l1l_l1_ (u"ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭䵙"))
				else:
					for title in l1l1ll1ll111_l1_:
						l1ll1lll_l1_.append(l11l1l_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ䵚")+l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ䵛")+title)
			else:
				title = l11l1l_l1_ (u"ࠨีํีๆืࠠฯษุࠫ䵜")+l11l1l_l1_ (u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬ䵝")+l1ll11l1lll1_l1_
				l1lll1_l1_.append(l1llll1_l1_)
				l1ll1lll_l1_.append(title)
		return l11l1l_l1_ (u"ࠪࠫ䵞"),l1ll1lll_l1_,l1lll1_l1_
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡅࡓࡇ࠭䵟"),[],[]
def	l1l1l1l1l111_l1_(url):
	# https://l11111l11ll_l1_.cc/l1l1111ll_l1_-1qrpoobdg7bu.html
	# https://l1lll111l111_l1_.cc//l1l1111ll_l1_-l1lll1l1lll1_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䵠"),url,l11l1l_l1_ (u"࠭ࠧ䵡"),l11l1l_l1_ (u"ࠧࠨ䵢"),l11l1l_l1_ (u"ࠨࠩ䵣"),l11l1l_l1_ (u"ࠩࠪ䵤"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡗࡋࡇࡉࡔ࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ䵥"))
	html = response.content
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䵦"),html,re.DOTALL)
	if l1l1_l1_:
		l1llll1_l1_ = l1l1_l1_[0]
		return l11l1l_l1_ (u"ࠬ࠭䵧"),[l11l1l_l1_ (u"࠭ࠧ䵨")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠧࠨ䵩"),[],[]
def	l1l1l1ll111l_l1_(url):
	# https://l1l1l1ll1111_l1_.in/l1l1lll11l11_l1_
	# https://l1l1l1ll1111_l1_.in/l1l1111ll_l1_-l1l1lll11l11_l1_.html
	# https://l1lll1l11l1l_l1_.l1ll11111ll1_l1_/l1llllllllll_l1_
	# https://l1lll1l11l1l_l1_.l1ll11111ll1_l1_/l1l1111ll_l1_-l1llllllllll_l1_.html
	# https://www.l1111111l1l_l1_.com/l1l1111ll_l1_-l1ll1l1l1l11_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ䵪"),l11l1l_l1_ (u"ࠩࠪ䵫")).replace(l11l1l_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ䵬"),l11l1l_l1_ (u"ࠫࠬ䵭"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䵮"),url,l11l1l_l1_ (u"࠭ࠧ䵯"),l11l1l_l1_ (u"ࠧࠨ䵰"),l11l1l_l1_ (u"ࠨࠩ䵱"),l11l1l_l1_ (u"ࠩࠪ䵲"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ䵳"))
	html = response.content
	l1ll11ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࡨࡡ࠯࠮ࠫࡁ࡟࠭ࡡ࠯࡜ࠪࠫࠪ䵴"),html,re.DOTALL)
	if l1ll11ll1l1l_l1_:
		l1ll11ll1l1l_l1_ = l1ll11ll1l1l_l1_[0]
		l1l1llll1l11_l1_ = l1ll11111l1l_l1_(l1ll11ll1l1l_l1_)
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䵵"),l1l1llll1l11_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠯ࡽࠨ䵶"),l1l1llll1l11_l1_,re.DOTALL)
		l1ll1lll_l1_,l1lll1_l1_ = [],[]
		for l1llll1_l1_,title in l1l1_l1_:
			if not title: title = l1llll1_l1_.rsplit(l11l1l_l1_ (u"ࠧ࠯ࠩ䵷"),1)[1]
			l1ll1lll_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		return l11l1l_l1_ (u"ࠨࠩ䵸"),l1ll1lll_l1_,l1lll1_l1_
	id = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ䵹"))[3]
	headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䵺"):l11l1l_l1_ (u"ࠫࠬ䵻") , l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䵼"):l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䵽") }
	payload = { l11l1l_l1_ (u"ࠧࡪࡦࠪ䵾"):id , l11l1l_l1_ (u"ࠨࡱࡳࠫ䵿"):l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ䶀") }
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䶁"),url,payload,headers,l11l1l_l1_ (u"ࠫࠬ䶂"),l11l1l_l1_ (u"ࠬ࠭䶃"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬ䶄"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䶅"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠨࠩ䶆"),[l11l1l_l1_ (u"ࠩࠪ䶇")],[ items[0] ]
	return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡞ࡆࡊࡎࡈࡗࡍࡇࡒࡊࡐࡊࠫ䶈"),[],[]
l11l1l_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡌࡕࡖࡊࡆࠫࡹࡷࡲࠩ࠻ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡰࡸ࡬ࡨ࠳ࡩ࡯࠰ࡸ࡬ࡨࡪࡵ࠯ࡱ࡮ࡤࡽ࠴ࡇࡁࡗࡇࡑࡨࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࠣ࠾ࠥ࠭ࠧࠡࡿࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡘࡌࡈ࠲࠷ࡳࡵࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵ࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࡡ࡝ࠋࠋ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍ࡮࡬ࠠࠨ࠰ࡰ࠷ࡺ࠾ࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵ࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹ࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶ࡛࠱࡟ࡀࡁࠬ࠳࠱ࠨ࠼ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭ࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵࡀࠊࠊࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࠫ࠰ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ุࠣࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥࡳࡰ࠵ࠩࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࠩࠪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡗࡋࡇࠫ࠱ࡡ࡝࠭࡝ࡠࠎࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠴ࡱ࠳࡭࡯ࡷ࡫ࡧ࠲ࡨࡵ࠯ࡴࡶࡵࡩࡦࡳ࠯࠳࠴࠼࠲ࡲ࠹ࡵ࠹ࠌࠥࠦࠧ䶉")
#####################################################
#    l1llllll1l1l_l1_ l1ll1l111111_l1_ l1ll1111l1l1_l1_
#    16-06-2019
#####################################################
def l1ll11ll1111_l1_(url):
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠬ࠭䶊"),l11l1l_l1_ (u"࠭ࠧ䶋"),l11l1l_l1_ (u"ࠧࠨ䶌"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡎࡒࡅࡉ࡙࠭࠲ࡵࡷࠫ䶍"))
	items = re.findall(l11l1l_l1_ (u"ࠩࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䶎"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠪࠫ䶏"),[l11l1l_l1_ (u"ࠫࠬ䶐")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪ䶑"),[],[]
def l1ll11l11l11_l1_(url):
	return l11l1l_l1_ (u"࠭ࠧ䶒"),[l11l1l_l1_ (u"ࠧࠨ䶓")],[ url ]
def l1ll1l1111l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䶔"),l11l1l_l1_ (u"ࠩࠪ䶕"),url,l11l1l_l1_ (u"ࠪࠫ䶖"))
	server = url.split(l11l1l_l1_ (u"ࠫ࠴࠭䶗"))
	basename = l11l1l_l1_ (u"ࠬ࠵ࠧ䶘").join(server[0:3])
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"࠭ࠧ䶙"),l11l1l_l1_ (u"ࠧࠨ䶚"),l11l1l_l1_ (u"ࠨࠩ䶛"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭䶜"))
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䶝"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䶞"),l11l1l_l1_ (u"ࠬ࠭䶟"),url,str(var))
	if items:
		l111lllll11_l1_,l11l111l11l_l1_,l11l111l1l1_l1_,l1lll1l1l1ll_l1_,l1lll1l1ll11_l1_,l1lll1l1l1l1_l1_ = items[0]
		var = int(l11l111l11l_l1_) % int(l11l111l1l1_l1_) + int(l1lll1l1l1ll_l1_) % int(l1lll1l1ll11_l1_)
		url = basename + l111lllll11_l1_ + str(var) + l1lll1l1l1l1_l1_
		return l11l1l_l1_ (u"࠭ࠧ䶠"),[l11l1l_l1_ (u"ࠧࠨ䶡")],[url]
	else: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋࠧ䶢"),[],[]
def l1lll11lllll_l1_(url):
	url = url.replace(l11l1l_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䶣"),l11l1l_l1_ (u"ࠪࠫ䶤"))
	url = url.replace(l11l1l_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ䶥"),l11l1l_l1_ (u"ࠬ࠭䶦"))
	id = url.split(l11l1l_l1_ (u"࠭࠯ࠨ䶧"))[-1]
	headers = { l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䶨") : l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䶩") }
	payload = { l11l1l_l1_ (u"ࠤ࡬ࡨࠧ䶪"):id , l11l1l_l1_ (u"ࠥࡳࡵࠨ䶫"):l11l1l_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠢ䶬") }
	request = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䶭"), url, payload, headers, l11l1l_l1_ (u"࠭ࠧ䶮"),l11l1l_l1_ (u"ࠧࠨ䶯"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡖ࠴ࡖࡒࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ䶰"))
	if l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䶱") in list(request.headers.keys()): l1llll1_l1_ = request.headers[l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䶲")]
	else: l1llll1_l1_ = url
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠫࠬ䶳"),[l11l1l_l1_ (u"ࠬ࠭䶴")],[l1llll1_l1_]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡓ࠸࡚ࡖࡌࡐࡃࡇࠫ䶵"),[],[]
def l1l1llll11l1_l1_(url):
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ䶶"),l11l1l_l1_ (u"ࠨࠩ䶷"),l11l1l_l1_ (u"ࠩࠪ䶸"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡊࡐࡗ࡚ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭䶹"))
	items = re.findall(l11l1l_l1_ (u"ࠫࡲࡶ࠴࠻ࠢ࡟࡟ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ䶺"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠬ࠭䶻"),[l11l1l_l1_ (u"࠭ࠧ䶼")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡍࡓ࡚ࡖࡍࡋ࡙ࡉࠬ䶽"),[],[]
def l1l1l11l11l1_l1_(url):
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠨࠩ䶾"),l11l1l_l1_ (u"ࠩࠪ䶿"),l11l1l_l1_ (u"ࠪࠫ䷀"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬ䷁"))
	items = re.findall(l11l1l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䷂"),html,re.DOTALL)
	#l1lll1111lll_l1_.l1l1l11lll11_l1_(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬ䷃") + items[0])
	if items:
		url = url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭䷄") + items[0]
		return l11l1l_l1_ (u"ࠨࠩ䷅"),[l11l1l_l1_ (u"ࠩࠪ䷆")],[ url ]
	else: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡄࡊࡌ࡚ࡊ࠭䷇"),[],[]
def l1ll1l1l1ll1_l1_(url):
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠫࠬ䷈"),l11l1l_l1_ (u"ࠬ࠭䷉"),l11l1l_l1_ (u"࠭ࠧ䷊"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘ࠲࠷ࡳࡵࠩ䷋"))
	items = re.findall(l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷌"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䷍"),l11l1l_l1_ (u"ࠪࠫ䷎"),str(items),html)
	if items: return l11l1l_l1_ (u"ࠫࠬ䷏"),[l11l1l_l1_ (u"ࠬ࠭䷐")],[ items[0] ]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖࠪ䷑"),[],[]
def l1ll11l1l1ll_l1_(url):
	#url = url.replace(l11l1l_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䷒"),l11l1l_l1_ (u"ࠨࠩ䷓"))
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ䷔"),l11l1l_l1_ (u"ࠪࠫ䷕"),l11l1l_l1_ (u"ࠫࠬ䷖"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭䷗"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷘"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䷙"),l11l1l_l1_ (u"ࠨࠩ䷚"),items[0],items[0])
	if items: return l11l1l_l1_ (u"ࠩࠪ䷛"),[l11l1l_l1_ (u"ࠪࠫ䷜")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡔࡖࡕࡉࡆࡓࠧ䷝"),[],[]
l11l1l_l1_ (u"ࠧࠨࠢࠋࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠐࠣࠡࠢࠣࠤࡓࡕࡔ࡙ࠡࡒࡖࡐࡏࡎࡈࠢࡄࡒ࡞ࡓࡏࡓࡇࠍࠧࠥࠦࠠࠡ࠲࠵࠱ࡋࡋࡂ࠮࠴࠳࠶࠶ࠐࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠎࠏࠐࠊࠋࠤࠥࠦ䷞")
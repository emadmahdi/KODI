# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ廭")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ廮")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
#headers = l11l1l_l1_ (u"࠭ࠧ廯")
#headers = {l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ廰"):l11l1l_l1_ (u"ࠨࠩ廱")}
def MAIN(mode,url,text,type,l11llll_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l11lllll1l_l1_(url)
	#elif mode==142: results = l11l11l1l1l1_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l11llll_l1_)
	elif mode==145: results = l11l1ll11ll1_l1_(url)
	elif mode==146: results = l11l11l111ll_l1_(url)
	elif mode==147: results = l11l1l1l11l1_l1_()
	elif mode==148: results = l11l1l1l1l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡅ࠵࡛ࡧ࡝ࡑࡂࡖࡵࡽࡰࡇࡺࡍࡔࡹࡉࡪ࡟ࡠࡖࡕࡎࡓࡏࡿࢀࡰࡳࡺࡒࡗࠬ廲")
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廳"),l1111l_l1_+l11l1l_l1_ (u"࡙ࠫࡋࡓࡕࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠪ廴"),url,144)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廵"),l1111l_l1_+l11l1l_l1_ (u"࠭࡯࡭ࡦࡨࡶࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠠ࡯ࡱࡷࠤࡱ࡯ࡳࡵ࡫ࡱ࡫ࠥࡴࡥࡸࡧࡵࠤࡵࡲࡹࡢ࡮࡬ࡷࡹ࠭延"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡝ࡌࡰࡲࡧ࡜ࡾ࡝ࡠࡦ࡬ࠨ࡯࡭ࡸࡺ࠽ࡓࡆࡔࡑ࠻࠹ࡶࡉ࡬ࡓ࠴࡭࡫ࡔࡴࠩ廷"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廸"),l1111l_l1_+l11l1l_l1_ (u"่ࠩ์็฿ࠠโษิ฾ࠬ廹"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡵࡑࡹࡳࡳࡰ࠴ࡈࡻࡲࡴࡒ࡚ࡍࡃࡣ࠵࠷ࡶ࡛ࡣࡸࠩ建"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廻"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ廼"),l11l1l_l1_ (u"࠭ࠧ廽"),149,l11l1l_l1_ (u"ࠧࠨ廾"),l11l1l_l1_ (u"ࠨࠩ廿"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭开"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弁"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭异")+l11l1l_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ弃")+l11l1l_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬࠦวๅ็หี๊าࠧ弄"),l11l1l_l1_ (u"ࠧࠨ弅"),290)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弆"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弇")+l1111l_l1_+l11l1l_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣ๎ํะ๊้สࠪ弈"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ弉"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弊"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ弋")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ弌"),l11l11_l1_,144,l11l1l_l1_ (u"ࠨࠩ弍"),l11l1l_l1_ (u"ࠩࠪ弎"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ式"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弐"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弑")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ะฮํ๏ࠠศๆิหหาࠧ弒"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ弓"),146)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭弔"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ引"),l11l1l_l1_ (u"ࠪࠫ弖"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弗"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弘")+l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ弙"),l11l1l_l1_ (u"ࠧࠨ弚"),147)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弛"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弜")+l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ弝"),l11l1l_l1_ (u"ࠫࠬ弞"),148)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弟"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ张")+l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ弡"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ弢"),144)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弣"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ弤")+l1111l_l1_+l11l1l_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ弥"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ弦"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弧"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ弨")+l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭弩"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ弪"),144)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弫"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭弬")+l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ弭"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ弮"),144)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弯"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ弰")+l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ弱"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ弲"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弳"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弴")+l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ張"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭弶"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ強"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弸")+l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ弹"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ强"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弻"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ弼")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ฼ีฬ่ࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ弽"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐ࠹ࡰࡕࡲ࠸ࡳࡲࡌ࠹࠶ࡒ࡬ࡸ࡜ࡉ࡮ࡎ࡯ࡋ࡯ࡶ࡮ࡻࡺࡳࡱࡗࡊࡹࡳࡦࡳࠩ弾"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弿"),l1111l_l1_+l11l1l_l1_ (u"ࠪห฾ีวะษอࠤฬ฼วโหࠣ๎ํะ๊้สࠪ彀"),l11l1l_l1_ (u"ࠫࠬ彁"),144)
	#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ彂"),l11l1l_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ彃"),l11l1l_l1_ (u"่ࠧาสࠤฬ๊วฯฬํหึࠦำ้ใࠣ๎ำืฬไ่๊ࠢࠥอไษำ้ห๊าࠧ彄"),l11l1l_l1_ (u"ࠨๆฦ๊์ࠦำ้ใࠣ๎็๎ๅࠡสอุ฿๐ไࠡสิ๊ฬ๋ฬࠡ์๋ฮ๏๎ศࠨ彅"))
	#if l1ll11111l_l1_==1:
	#	url = l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ彆")
	#	xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ彇"))
	#	xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡗ࡫ࡰ࡭ࡣࡦࡩ࡜࡯࡮ࡥࡱࡺࠬࡻ࡯ࡤࡦࡱࡶ࠰ࠬ彈")+url+l11l1l_l1_ (u"ࠬ࠯ࠧ彉"))
	#	#xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡒࡶࡰࡄࡨࡩࡵ࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠪࠩ彊"))
	return
l11l1l_l1_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡎࡃࡌࡒࡕࡇࡇࡆࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠬࡤࡥ࠯ࡨࡦࡺࡡࠡ࠿ࠣࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃࠫࡹࡷࡲࠩࠋࠋ࡬ࡪࠥ࠭ࡒࡦࡨࡤࡥࡹࠦࡁ࡭࠯ࡊࡥࡲࡳࡡ࡭ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡿࡥࡴࠩࠬࠎࠎࡪࡤࠡ࠿ࠣࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠐࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡲࡦ࡭ࡥࠩ࡮ࡨࡲ࠭ࡪࡤࠪࠫ࠽ࠎࠎࠏࡩࡵࡧࡰࠤࡂࠦࡤࡥ࡝࡬ࡡࠏࠏࠉࡊࡐࡖࡉࡗ࡚࡟ࡊࡖࡈࡑࡤ࡚ࡏࡠࡏࡈࡒ࡚࠮ࡩࡵࡧࡰ࠭ࠏࠏࡉࡕࡇࡐࡗ࠭ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ彋")
def l11l1l1l11l1_l1_():
	ITEMS(l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ彌"))
	return
def l11l1l1l1l11_l1_():
	ITEMS(l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ彍"))
	return
def PLAY(url,type):
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬ彎")
	#items = re.findall(l11l1l_l1_ (u"ࠫࡻࡃࠨ࠯ࠬࡂ࠭ࠩ࠭彏"),url,re.DOTALL)
	#id = items[0]
	#l1llll1_l1_ = l11l1l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯ࡱ࡮ࡤࡽ࠴ࡅࡶࡪࡦࡨࡳࡤ࡯ࡤ࠾ࠩ彐")+id
	#PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ彑"))
	#return
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠩࡷࡵࡰ࠮ࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࡶࡼࡴࡪ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ归")
	import ll_l1_
	ll_l1_.l11_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11l111ll_l1_(url):
	html,cc,data = l11l1l11ll1l_l1_(url)
	dd = cc[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ当")][l11l1l_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ彔")][l11l1l_l1_ (u"ࠪࡸࡦࡨࡳࠨ录")]
	for l11l1ll1l1_l1_ in range(len(dd)):
		item = dd[l11l1ll1l1_l1_]
		l11l1ll1111l_l1_(item,url,str(l11l1ll1l1_l1_))
	ee = dd[0][l11l1l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ彖")][l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭彗")][l11l1l_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ彘")][l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ彙")]
	s = 0
	for l11l1ll1l1_l1_ in range(len(ee)):
		item = ee[l11l1ll1l1_l1_][l11l1l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彚")][l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ彛")][0]
		if list(item[l11l1l_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彜")][l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ彝")].keys())[0]==l11l1l_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彞"): continue
		succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_ = l11l1ll1l1l1_l1_(item)
		if not title:
			s += 1
			title = l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡำสสัฯࠠࠨ彟")+str(s)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彠"),l1111l_l1_+title,url,144,l11l1l_l1_ (u"ࠨࠩ彡"),str(l11l1ll1l1_l1_))
	key = re.findall(l11l1l_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ形"),html,re.DOTALL)
	l111ll1_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ彣")+key[0]
	html,cc,l11ll1111_l1_ = l11l1l11ll1l_l1_(l111ll1_l1_)
	for l11llll1lll_l1_ in range(3,4):
		dd = cc[l11l1l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ彤")][l11llll1lll_l1_][l11l1l_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ彥")][l11l1l_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ彦")]
		for l11l1ll1l1_l1_ in range(len(dd)):
			item = dd[l11l1ll1l1_l1_]
			if l11l1l_l1_ (u"࡚ࠧࡱࡸࡘࡺࡨࡥࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩ彧") in str(item): continue
			l11l1ll1111l_l1_(item)
	return
def ITEMS(url,data=l11l1l_l1_ (u"ࠨࠩ彨"),index=0):
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ彩"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ彪"),l11l1l_l1_ (u"ࠫࠬ彫"))
	html,cc,l11ll1111_l1_ = l11l1l11ll1l_l1_(url,data)
	l11llll1l1_l1_,ff = l11l1l_l1_ (u"ࠬ࠭彬"),l11l1l_l1_ (u"࠭ࠧ彭")
	#if l11l1l_l1_ (u"ࠧࡰࡹࡱࡩࡷ࠭彮") in html.lower(): DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ彯"),l11l1l_l1_ (u"ࠩࠪ彰"),l11l1l_l1_ (u"ࠪࡳࡼࡴࡥࡳࠢࡨࡼ࡮ࡹࡴࠨ影"),l11l1l_l1_ (u"ࠫ࡮ࡴࠠࡩࡶࡰࡰࠬ彲"))
	owner = re.findall(l11l1l_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ彳"),html,re.DOTALL)
	if not owner: owner = re.findall(l11l1l_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ彴"),html,re.DOTALL)
	if not owner: owner = re.findall(l11l1l_l1_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ彵"),html,re.DOTALL)
	if owner:
		l11llll1l1_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ彶")+owner[0][0]+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ彷")
		l1llll1_l1_ = owner[0][1]
		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ彸") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		#if l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ役") in url and l11l1l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ彺") not in url and l11l1l_l1_ (u"࠭࠯ࡤ࠱ࠪ彻") not in url and l11l1l_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ彼") not in url:
		if l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ彽") in url: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彾"),l1111l_l1_+l11llll1l1_l1_,l1llll1_l1_,144)
	#if cc==l11l1l_l1_ (u"ࠪࠫ彿"): l11l11l1l111_l1_(url,html) ; return
	l11l11l11ll1_l1_ = [l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ往"),l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭征"),l11l1l_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ徂"),l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ徃"),l11l1l_l1_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ径"),l11l1l_l1_ (u"ࠩࡶࡷࡂ࠭待"),l11l1l_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ徆"),l11l1l_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ徇"),l11l1l_l1_ (u"ࠬࡨࡰ࠾ࠩ很"),l11l1l_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ徉")]
	l11l11l1111l_l1_ = not any(value in url for value in l11l11l11ll1_l1_)
	if l11l11l1111l_l1_ and l11llll1l1_l1_:
		l11l11ll1_l1_ = l11l1l_l1_ (u"ࠧศๆหัะ࠭徊")
		l1lll11ll_l1_ = l11l1l_l1_ (u"ࠨไ๋หห๋ࠠศๆอุ฿๐ไࠨ律")
		l11l11l1l_l1_ = l11l1l_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯ࠭後")
		l11l11l111l1_l1_ = l11l1l_l1_ (u"ࠪห้่ๆ้ษอࠫ徍")
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ徎"),l1111l_l1_+l11llll1l1_l1_,url,9999)
		if l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢษฯฮࠦࠬ徏") in html: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徐"),l1111l_l1_+l11l11ll1_l1_,url,145,l11l1l_l1_ (u"ࠧࠨ徑"),l11l1l_l1_ (u"ࠨࠩ徒"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭従"))
		if l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭徔") in html: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徕"),l1111l_l1_+l1lll11ll_l1_,url+l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ徖"),144)
		if l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭得") in html: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徘"),l1111l_l1_+l11l11l1l_l1_,url+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ徙"),144)
		if l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭徚") in html: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ徛"),l1111l_l1_+l11l11l111l1_l1_,url+l11l1l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ徜"),144)
		if l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡔࡧࡤࡶࡨ࡮ࠢࠨ徝") in html: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭從"),l1111l_l1_+l11l11ll1_l1_,url,145,l11l1l_l1_ (u"ࠧࠨ徟"),l11l1l_l1_ (u"ࠨࠩ徠"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭御"))
		if l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ徢") in html: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徣"),l1111l_l1_+l1lll11ll_l1_,url+l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ徤"),144)
		if l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ徥") in html: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徦"),l1111l_l1_+l11l11l1l_l1_,url+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ徧"),144)
		if l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ徨") in html: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ復"),l1111l_l1_+l11l11l111l1_l1_,url+l11l1l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ循"),144)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ徫"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徬"),l11l1l_l1_ (u"ࠧࠨ徭"),9999)
	if l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ微") in url:
		dd = cc[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ徯")][l11l1l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭徰")][l11l1l_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭徱")][l11l1l_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ徲")][l11l1l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ徳")]
		l11l111lllll_l1_ = 0
		for i in range(len(dd)):
			if l11l1l_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭徴") in list(dd[i].keys()):
				l11l111llll1_l1_ = dd[i][l11l1l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ徵")]
				length = len(str(l11l111llll1_l1_))
				if length>l11l111lllll_l1_:
					l11l111lllll_l1_ = length
					ff = l11l111llll1_l1_
		if l11l111lllll_l1_==0: return
	elif l11l1l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ徶") in url or l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ德") in url or l11l1l_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ徸") in url or l11l1l_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭徹") in url or l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ徺") in url or url==l11l11_l1_:
		l11l11lll111_l1_ = []
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ徻"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ徼"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ徽"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ徾"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ徿"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠭࠲࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ忀"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ忁"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࠧ忂"))
		l11l11l11l1l_l1_,ff = l11l11l1ll1l_l1_(cc,l11l1l_l1_ (u"ࠨࠩ心"),l11l11lll111_l1_)
	if not ff:
		try:
			dd = cc[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ忄")][l11l1l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭必")][l11l1l_l1_ (u"ࠫࡹࡧࡢࡴࠩ忆")]
			l1l111l1111_l1_ = l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭忇") in url or l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ忈") in url or l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ忉") in url
			l11l11ll111l_l1_ = l11l1l_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ忊") in html or l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ忋") in html or l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ忌") in html
			l11l11ll1111_l1_ = l11l1l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ忍") in html or l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ忎") in html or l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ忏") in html
			if l1l111l1111_l1_ and (l11l11ll111l_l1_ or l11l11ll1111_l1_):
				for l11l1ll1l1_l1_ in range(len(dd)):
					if l11l1l_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ忐") not in list(dd[l11l1ll1l1_l1_].keys()): continue
					ee = dd[l11l1ll1l1_l1_][l11l1l_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忑")]
					try: gg = ee[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ忒")][l11l1l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ忓")][l11l1l_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ忔")][l11l1l_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忕")][l11l1l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩ忖")][l11l1ll1l1_l1_]
					except: gg = ee
					try: l1llll1_l1_ = gg[l11l1l_l1_ (u"ࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩ志")][l11l1l_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ忘")][l11l1l_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ忙")][l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ忚")]
					except: continue
					if   l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ忛")		in l1llll1_l1_	and l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭応")		in url: ee = dd[l11l1ll1l1_l1_] ; break
					elif l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ忝")	in l1llll1_l1_	and l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ忞")	in url: ee = dd[l11l1ll1l1_l1_] ; break
					elif l11l1l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ忟")	in l1llll1_l1_	and l11l1l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ忠")		in url: ee = dd[l11l1ll1l1_l1_] ; break
					else: ee = dd[0]
			elif l11l1l_l1_ (u"ࠪࡦࡵࡃࠧ忡") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11l1l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ忢")][l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭忣")]
		except: pass
	if not ff: return
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ忤"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ忥"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ忦"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ忧"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ忨"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ忩"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ忪"))
	if l11l1l_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ快") not in url: l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡶࡤࡐࡩࡳࡻࠧ࡞࡝ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫࡢࠨ忬"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ忭"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ忮"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ忯"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ忰"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ忱"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ忲"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ忳"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ忴"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࠧ念"))
	l11l11l1l11l_l1_ = l1111llllll_l1_(l11l1l_l1_ (u"ࡸ่๊ࠫࠠใ๊สส๊ࠦวๅฬื฾๏๊ࠧ忶"))
	l11l11l11111_l1_ = l1111llllll_l1_(l11l1l_l1_ (u"ࡹ้ࠬไࠡษ็ๅ๏ี๊้้สฮࠬ忷"))
	l11l11l11l11_l1_ = l1111llllll_l1_(l11l1l_l1_ (u"ࡺ࠭ใๅࠢส่็์่ศฬࠪ忸"))
	l111l11lll1_l1_ = [l11l11l1l11l_l1_,l11l11l11111_l1_,l11l11l11l11_l1_,l11l1l_l1_ (u"࠭ࡁ࡭࡮ࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭忹"),l11l1l_l1_ (u"ࠧࡂ࡮࡯ࠤࡻ࡯ࡤࡦࡱࡶࠫ忺"),l11l1l_l1_ (u"ࠨࡃ࡯ࡰࠥࡩࡨࡢࡰࡱࡩࡱࡹࠧ忻")]
	l11l11l11lll_l1_,gg = l11l11l1ll1l_l1_(ff,index,l11l11lll111_l1_)
	if l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ忼") in str(type(gg)) and any(value in str(gg[0]) for value in l111l11lll1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l11l11lll111_l1_ = []
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ忽"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ忾"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ忿"))
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ怀"))		#4
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ态"))		#7
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ怂"))		#6
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ怃"))		#5
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣࠢ怄"))
		l11l11l11l1l_l1_,item = l11l11l1ll1l_l1_(gg,index2,l11l11lll111_l1_)
		#if l11l11l11l1l_l1_ not in [l11l1l_l1_ (u"ࠫ࠷࠭怅"),l11l1l_l1_ (u"ࠬ࠺ࠧ怆"),l11l1l_l1_ (u"࠭࠵ࠨ怇")]: l11l1ll1111l_l1_(item)		# 2,4,7
		#else: l11l1ll1111l_l1_(item,url,str(index2))
		l11l1ll1111l_l1_(item,url,str(index2))
		if l11l11l11l1l_l1_==l11l1l_l1_ (u"ࠧ࠵ࠩ怈"):
			try:
				hh = item[l11l1l_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ怉")][l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ怊")][l11l1l_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怋")][l11l1l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ怌")]
				for l11l1l1l1111_l1_ in range(len(hh)):
					l11l11l1l1ll_l1_ = hh[l11l1l1l1111_l1_]
					l11l1ll1111l_l1_(l11l11l1l1ll_l1_)
			except: pass
	l11l1l11111l_l1_ = False
	if l11l1l_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ怍") not in url and l11l11l11lll_l1_==l11l1l_l1_ (u"࠭࠸ࠨ怎"): l11l1l11111l_l1_ = True
	if l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ怏") in l11ll1111_l1_: l11l1l1ll11l_l1_,key,l11l1l1l1lll_l1_,l11l1l1l11ll_l1_,token,l11l1l111l1l_l1_ = l11ll1111_l1_.split(l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ怐"))
	else: l11l1l1ll11l_l1_,key,l11l1l1l1lll_l1_,l11l1l1l11ll_l1_,token,l11l1l111l1l_l1_ = l11l1l_l1_ (u"ࠩࠪ怑"),l11l1l_l1_ (u"ࠪࠫ怒"),l11l1l_l1_ (u"ࠫࠬ怓"),l11l1l_l1_ (u"ࠬ࠭怔"),l11l1l_l1_ (u"࠭ࠧ怕"),l11l1l_l1_ (u"ࠧࠨ怖")
	l111ll1_l1_,l1ll11lll11_l1_ = l11l1l_l1_ (u"ࠨࠩ怗"),l11l1l_l1_ (u"ࠩࠪ怘")
	if menuItemsLIST:
		l11l11l1llll_l1_ = str(menuItemsLIST[-1][1])
		if   l1111l_l1_+l11l1l_l1_ (u"ࠪࡇࡍࡔࡌࠨ怙") in l11l11l1llll_l1_: l1ll11lll11_l1_ = l11l1l_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭怚")
		elif l1111l_l1_+l11l1l_l1_ (u"࡛ࠬࡓࡆࡔࠪ怛") in l11l11l1llll_l1_: l1ll11lll11_l1_ = l11l1l_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ怜")
		elif l1111l_l1_+l11l1l_l1_ (u"ࠧࡍࡋࡖࡘࠬ思") in l11l11l1llll_l1_: l1ll11lll11_l1_ = l11l1l_l1_ (u"ࠨࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ怞")
	if l11l1l_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠥࠫ怟") in html and l11l1l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ怠") not in url and not l11l1l11111l_l1_ and l11l1l_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩ࠭怡") not in url:	# and (index!=l11l1l_l1_ (u"ࠬ࠭怢") or l11l1l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ怣") in url or l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭怤") in url or l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ急") in url or l11l1l_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ怦") in url):
		l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ性")+l11l1l1l1lll_l1_
	elif l11l1l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ怨") in html and l11l1l_l1_ (u"ࠬࡨࡰ࠾ࠩ怩") not in url and l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ怪") in url or l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ怫") in url:
		l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ怬")+key
	elif l11l1l_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ怭") in html and l11l1l_l1_ (u"ࠪࡦࡵࡃࠧ怮") not in url:
		l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ怯")+key
	if l111ll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怰"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ怱"),l111ll1_l1_,144,l1ll11lll11_l1_,l11l1l_l1_ (u"ࠧࠨ怲"),l11ll1111_l1_)
	return
def l11l11l1ll1l_l1_(l111lllll11_l1_,l11l111l11l_l1_,l11l1l1111l1_l1_):
	cc = l111lllll11_l1_
	ff,index = l111lllll11_l1_,l11l111l11l_l1_
	gg,index2 = l111lllll11_l1_,l11l111l11l_l1_
	item,render = l111lllll11_l1_,l11l111l11l_l1_
	count = len(l11l1l1111l1_l1_)
	for l11l1ll1l1_l1_ in range(count):
		try:
			out = eval(l11l1l1111l1_l1_[l11l1ll1l1_l1_])
			#if isinstance(out,dict): out = l11l1l_l1_ (u"ࠨࠩ怳")
			return str(l11l1ll1l1_l1_+1),out
		except: pass
	return l11l1l_l1_ (u"ࠩࠪ怴"),l11l1l_l1_ (u"ࠪࠫ怵")
def l11l1ll1l1l1_l1_(item):
	try: l11l1l1lll1l_l1_ = list(item.keys())[0]
	except: return False,l11l1l_l1_ (u"ࠫࠬ怶"),l11l1l_l1_ (u"ࠬ࠭怷"),l11l1l_l1_ (u"࠭ࠧ怸"),l11l1l_l1_ (u"ࠧࠨ怹"),l11l1l_l1_ (u"ࠨࠩ怺"),l11l1l_l1_ (u"ࠩࠪ总"),l11l1l_l1_ (u"ࠪࠫ怼")
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_ = False,l11l1l_l1_ (u"ࠫࠬ怽"),l11l1l_l1_ (u"ࠬ࠭怾"),l11l1l_l1_ (u"࠭ࠧ怿"),l11l1l_l1_ (u"ࠧࠨ恀"),l11l1l_l1_ (u"ࠨࠩ恁"),l11l1l_l1_ (u"ࠩࠪ恂"),l11l1l_l1_ (u"ࠪࠫ恃")
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬ恄"),str(item))
	render = item[l11l1l1lll1l_l1_]
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恅"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恆"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恇"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ恈"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恉"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ恊"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ恋"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ恌"))
	l11l11l11l1l_l1_,title = l11l11l1ll1l_l1_(item,render,l11l11lll111_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ恍"),l11l1l_l1_ (u"ࠧࠨ恎"),l11l1l_l1_ (u"ࠨࠩ恏"),title)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恐"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ恑"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恒"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ恓")) # required for l111ll1ll11_l1_ l11l1l11111l_l1_
	l11l11l11l1l_l1_,l1llll1_l1_ = l11l11l1ll1l_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恔"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ恕"))
	l11l11l11l1l_l1_,l1ll1l_l1_ = l11l11l1ll1l_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ恖"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ恗"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ恘"))
	l11l11l11l1l_l1_,count = l11l11l1ll1l_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ恙"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ恚"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ恛"))
	l11l11l11l1l_l1_,l1l11ll11_l1_ = l11l11l1ll1l_l1_(item,render,l11l11lll111_l1_)
	if l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ恜") in l1l11ll11_l1_: l1l11ll11_l1_,l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠨࠩ恝"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ恞")
	if l11l1l_l1_ (u"้ࠪออิาࠩ恟") in l1l11ll11_l1_: l1l11ll11_l1_,l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠫࠬ恠"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭恡")
	if l11l1l_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭恢") in list(render.keys()):
		l11l1ll111l1_l1_ = str(render[l11l1l_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ恣")])
		if l11l1l_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ恤") in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠩࠧ࠾ࠬ恥")
		if l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ恦") in l11l1ll111l1_l1_: l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ恧")
		if l11l1l_l1_ (u"ࠬࡈࡵࡺࠩ恨") in l11l1ll111l1_l1_ or l11l1l_l1_ (u"࠭ࡒࡦࡰࡷࠫ恩") in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠧࠥࠦ࠽ࠫ恪")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡶ่ࠩฬฬฺัࠨ恫")) in l11l1ll111l1_l1_: l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ恬")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡸูࠫืวยࠩ恭")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠫࠩࠪ࠺ࠨ恮")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡺ࠭วิฬษะฬืࠧ息")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"࠭ࠤࠥ࠼ࠪ恰")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ恱")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠨࠦ࠽ࠫ恲")
	l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
	if l1llll1_l1_ and l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ恳") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠪࡃࠬ恴"))[0]
	if  l1ll1l_l1_ and l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ恵") not in l1ll1l_l1_: l1ll1l_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ恶")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l11lll1_l1_: title = l11l1l11lll1_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠩ恷")+title
	#title = unescapeHTML(title)
	l1l11ll11_l1_ = l1l11ll11_l1_.replace(l11l1l_l1_ (u"ࠧ࠭ࠩ恸"),l11l1l_l1_ (u"ࠨࠩ恹"))
	count = count.replace(l11l1l_l1_ (u"ࠩ࠯ࠫ恺"),l11l1l_l1_ (u"ࠪࠫ恻"))
	count = re.findall(l11l1l_l1_ (u"ࠫࡡࡪࠫࠨ恼"),count)
	if count: count = count[0]
	else: count = l11l1l_l1_ (u"ࠬ࠭恽")
	return True,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_
def l11l1ll1111l_l1_(item,url=l11l1l_l1_ (u"࠭ࠧ恾"),index=l11l1l_l1_ (u"ࠧࠨ恿")):
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_ = l11l1ll1l1l1_l1_(item)
	#if l11l1l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ悀") in url and index==l11l1l_l1_ (u"ࠩ࠳ࠫ悁"):
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悂"),l1111l_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悃") in str(item): return	# l11l1l1l1lll_l1_ not items
	elif l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ悄") in str(item): return			# l11l1l1lllll_l1_ not items
	elif not l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ悅") in url: return			# separator l11l111lll1l_l1_ list not items
	elif title and not l1llll1_l1_ and (l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭悆") in url or l11l1l_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悇") in str(item) or url==l11l11_l1_):
		title = l11l1l_l1_ (u"ࠩࡀࡁࡂࠦࠧ悈")+title+l11l1l_l1_ (u"ࠪࠤࡂࡃ࠽ࠨ悉")
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ悊"),l1111l_l1_+title,l11l1l_l1_ (u"ࠬ࠭悋"),9999)
	elif title and l11l1l_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悌") in str(item):
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ悍"),l1111l_l1_+title,l11l1l_l1_ (u"ࠨࠩ悎"),9999)
	elif l11l1l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ悏") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悐"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l1lllll1l11l_l1_: addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ悑"),l1111l_l1_+l1lllll1l11l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_)
	#elif l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ悒") in l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭悓") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠧࡵ࠿࠳ࠫ悔") not in l1llll1_l1_:
	#	l11l1l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠨ࠯ࠬࡂ࠭ࠩ࠭悕"),l1llll1_l1_,re.DOTALL)
	#	l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ悖")+l11l1l11llll_l1_[0]
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悗"),l1111l_l1_+l11l1l_l1_ (u"ࠫࡑࡏࡓࡕࠩ悘")+count+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ悙")+title,l1llll1_l1_,144,l1ll1l_l1_)
	elif l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ悚") in l1llll1_l1_ or l11l1l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ悛") in l1llll1_l1_:
		if l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ悜") in l1llll1_l1_ and l11l1l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ悝") not in l1llll1_l1_:
			l11l1l11llll_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ悞"),1)[1]
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭悟")+l11l1l11llll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悠"),l1111l_l1_+l11l1l_l1_ (u"࠭ࡌࡊࡕࡗࠫ悡")+count+l11l1l_l1_ (u"ࠧ࠻ࠢࠣࠫ悢")+title,l1llll1_l1_,144,l1ll1l_l1_)
		else:
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ患"),1)[0]
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ悤"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11ll11_l1_)
	else:
		type = l11l1l_l1_ (u"ࠪࠫ悥")
		if not l1llll1_l1_: l1llll1_l1_ = url
		#if l11l1l_l1_ (u"ࠫࡸࡹ࠽ࠨ悦") in l1llll1_l1_: l1llll1_l1_ = url
		#elif l11l1l_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ悧") in l1llll1_l1_: l1llll1_l1_ = url		# not needed it will stop l11l11l1ll11_l1_ l111ll1ll11_l1_ l11l1l11111l_l1_
		elif not any(value in l1llll1_l1_ for value in [l11l1l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ您"),l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ悩"),l11l1l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ悪"),l11l1l_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ悫"),l11l1l_l1_ (u"ࠪࡷࡸࡃࠧ悬"),l11l1l_l1_ (u"ࠫࡧࡶ࠽ࠨ悭")]):
			if l11l1l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ悮")	in l1llll1_l1_ or l11l1l_l1_ (u"࠭࠯ࡤ࠱ࠪ悯") in l1llll1_l1_: type = l11l1l_l1_ (u"ࠧࡄࡊࡑࡐࠬ悰")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ悱")
			if l11l1l_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ悲") in l1llll1_l1_: type = l11l1l_l1_ (u"࡙ࠪࡘࡋࡒࠨ悳")+count+l11l1l_l1_ (u"ࠫ࠿ࠦࠠࠨ悴")
			index,l11l1ll1l11l_l1_ = l11l1l_l1_ (u"ࠬ࠭悵"),l11l1l_l1_ (u"࠭ࠧ悶")
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ悷"),l1111l_l1_+type+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	return
def l11l1l11ll1l_l1_(url,data=l11l1l_l1_ (u"ࠨࠩ悸"),request=l11l1l_l1_ (u"ࠩࠪ悹")):
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ悺"))
	#if l11l1l_l1_ (u"ࠫࡤࡥࠧ悻") in l11l1ll1l11l_l1_: l11l1ll1l11l_l1_ = l11l1l_l1_ (u"ࠬ࠭悼")
	#if l11l1l_l1_ (u"࠭ࡳࡴ࠿ࠪ悽") in url: url = url.split(l11l1l_l1_ (u"ࠧࡴࡵࡀࠫ悾"))[0]
	if request==l11l1l_l1_ (u"ࠨࠩ悿"): request = l11l1l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ惀")
	l111ll1l1l_l1_ = l11llll1l_l1_()
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ惁"):l111ll1l1l_l1_,l11l1l_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ惂"):l11l1l_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ惃")}
	#l1l1l1lll_l1_ = headers.copy()
	if l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ惄") in data: l11l1l1ll11l_l1_,key,l11l1l1l1lll_l1_,l11l1l1l11ll_l1_,token,l11l1l111l1l_l1_ = data.split(l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ情"))
	else: l11l1l1ll11l_l1_,key,l11l1l1l1lll_l1_,l11l1l1l11ll_l1_,token,l11l1l111l1l_l1_ = l11l1l_l1_ (u"ࠨࠩ惆"),l11l1l_l1_ (u"ࠩࠪ惇"),l11l1l_l1_ (u"ࠪࠫ惈"),l11l1l_l1_ (u"ࠫࠬ惉"),l11l1l_l1_ (u"ࠬ࠭惊"),l11l1l_l1_ (u"࠭ࠧ惋")
	if l11l1l_l1_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ惌") in url:
		l11ll1111_l1_ = {}
		l11ll1111_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ惍")] = {l11l1l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ惎"):{l11l1l_l1_ (u"ࠥ࡬ࡱࠨ惏"):l11l1l_l1_ (u"ࠦࡦࡸࠢ惐"),l11l1l_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ惑"):l11l1l_l1_ (u"ࠨࡗࡆࡄࠥ惒"),l11l1l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ惓"):l11l1l1l11ll_l1_}}
		l11ll1111_l1_ = str(l11ll1111_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭惔"),url,l11ll1111_l1_,l1l1l1lll_l1_,True,True,l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ惕"))
	elif l11l1l_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ惖") in url and l11l1l1ll11l_l1_:
		l11ll1111_l1_ = {l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ惗"):token}
		l11ll1111_l1_[l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭惘")] = {l11l1l_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ惙"):{l11l1l_l1_ (u"ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ惚"):l11l1l1ll11l_l1_,l11l1l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ惛"):l11l1l_l1_ (u"ࠤ࡚ࡉࡇࠨ惜"),l11l1l_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ惝"):l11l1l1l11ll_l1_}}
		l11ll1111_l1_ = str(l11ll1111_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ惞"),url,l11ll1111_l1_,l1l1l1lll_l1_,True,True,l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ惟"))
	elif l11l1l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ惠") in url and l11l1l111l1l_l1_:
		l1l1l1lll_l1_.update({l11l1l_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ惡"):l11l1l_l1_ (u"ࠨ࠳ࠪ惢"),l11l1l_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭惣"):l11l1l1l11ll_l1_})
		l1l1l1lll_l1_.update({l11l1l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ惤"):l11l1l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ惥")+l11l1l111l1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ惦"),url,l11l1l_l1_ (u"࠭ࠧ惧"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠧࠨ惨"),l11l1l_l1_ (u"ࠨࠩ惩"),l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ惪"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ惫"),url,l11l1l_l1_ (u"ࠫࠬ惬"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠬ࠭惭"),l11l1l_l1_ (u"࠭ࠧ惮"),l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ惯"))
	html = response.content
	tmp = re.findall(l11l1l_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惰"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惱"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l11ll_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ惲"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ想"),html,re.DOTALL|re.I)
	if tmp: l11l1l1ll11l_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ惴"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l1lll_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ惵") in list(cookies.keys()): l11l1l111l1l_l1_ = cookies[l11l1l_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ惶")]
	data = l11l1l1ll11l_l1_+l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ惷")+key+l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭惸")+l11l1l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠾࠿ࡀࠧ惹")+l11l1l1l11ll_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ惺")+token+l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ惻")+l11l1l111l1l_l1_
	if request==l11l1l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭惼") and l11l1l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ惽") in html:
		l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ惾"),html,re.DOTALL)
		if not l111ll111l_l1_: l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ惿"),html,re.DOTALL)
		l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ愀"),l111ll111l_l1_[0])
	elif request==l11l1l_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ愁") and l11l1l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ愂") in html:
		l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ愃"),html,re.DOTALL)
		l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ愄"),l111ll111l_l1_[0])
	elif l11l1l_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ愅") not in html: l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭愆"),html)
	else: l11l11lll11l_l1_ = l11l1l_l1_ (u"ࠪࠫ愇")
	#open(l11l1l_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡮ࡸࡵ࡮ࠨ愈"),l11l1l_l1_ (u"ࠬࡽࠧ愉")).write(str(l11l11lll11l_l1_))
	#open(l11l1l_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ愊"),l11l1l_l1_ (u"ࠧࡸࠩ愋")).write(html)
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ愌"),data)
	return html,l11l11lll11l_l1_,data
def l11l1ll11ll1_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ愍"),l11l1l_l1_ (u"ࠪ࠯ࠬ愎"))
	l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ意")+search
	ITEMS(l111ll1_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ愐"),l11l1l_l1_ (u"࠭ࠫࠨ愑"))
	l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ愒")+search
	if not l1ll_l1_:
		if l11l1l_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ愓") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ愔")
		elif l11l1l_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ愕") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ愖")
		elif l11l1l_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ愗") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭愘")
		l111lll_l1_ = l111ll1_l1_+l11l1l111lll_l1_
	else:
		l11l1l111ll1_l1_,l11l11ll1l1l_l1_,l1lll11ll_l1_ = [],[],l11l1l_l1_ (u"ࠧࠨ愙")
		l11l11ll1lll_l1_ = [l11l1l_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ愚"),l11l1l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ愛"),l11l1l_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭愜"),l11l1l_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ愝"),l11l1l_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ愞")]
		l11l1l1llll1_l1_ = [l11l1l_l1_ (u"࠭ࠧ感"),l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭愠"),l11l1l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ愡"),l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ愢"),l11l1l_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ愣")]
		l11l1ll111ll_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ愤"),l11l11ll1lll_l1_)
		if l11l1ll111ll_l1_ == -1: return
		l11l1l111l11_l1_ = l11l1l1llll1_l1_[l11l1ll111ll_l1_]
		html,c,data = l11l1l11ll1l_l1_(l111ll1_l1_+l11l1l111l11_l1_)
		if c:
			d = c[l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ愥")][l11l1l_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ愦")][l11l1l_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ愧")][l11l1l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ愨")][l11l1l_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ愩")][l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ愪")][l11l1l_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ愫")]
			for l11l11ll1l11_l1_ in range(len(d)):
				group = d[l11l11ll1l11_l1_][l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ愬")][l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ愭")]
				for l11l1ll11lll_l1_ in range(len(group)):
					render = group[l11l1ll11lll_l1_][l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ愮")]
					if l11l1l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭愯") in list(render.keys()):
						l1llll1_l1_ = render[l11l1l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ愰")][l11l1l_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ愱")][l11l1l_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ愲")][l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ愳")]
						l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭愴"),l11l1l_l1_ (u"ࠧࠧࠩ愵"))
						title = render[l11l1l_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ愶")]
						title = title.replace(l11l1l_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ愷"),l11l1l_l1_ (u"ࠪࠫ愸"))
						if l11l1l_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ愹") in title: continue
						if l11l1l_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ愺") in title:
							title = l11l1l_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ愻")+title
							l1lll11ll_l1_ = title
							l1llll11ll_l1_ = l1llll1_l1_
						if l11l1l_l1_ (u"ࠧหำอ๎อࠦอิสࠪ愼") in title: continue
						title = title.replace(l11l1l_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭愽"),l11l1l_l1_ (u"ࠩࠪ愾"))
						if l11l1l_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ愿") in title: continue
						if l11l1l_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭慀") in title:
							title = l11l1l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭慁")+title
							l1lll11ll_l1_ = title
							l1llll11ll_l1_ = l1llll1_l1_
						if l11l1l_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ慂") in title: continue
						l11l1l111ll1_l1_.append(escapeUNICODE(title))
						l11l11ll1l1l_l1_.append(l1llll1_l1_)
		if not l1lll11ll_l1_: l11l1l1ll1ll_l1_ = l11l1l_l1_ (u"ࠧࠨ慃")
		else:
			l11l1l111ll1_l1_ = [l11l1l_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ慄"),l1lll11ll_l1_]+l11l1l111ll1_l1_
			l11l11ll1l1l_l1_ = [l11l1l_l1_ (u"ࠩࠪ慅"),l1llll11ll_l1_]+l11l11ll1l1l_l1_
			l11l1ll11l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ慆"),l11l1l111ll1_l1_)
			if l11l1ll11l1l_l1_ == -1: return
			l11l1l1ll1ll_l1_ = l11l11ll1l1l_l1_[l11l1ll11l1l_l1_]
		if l11l1l1ll1ll_l1_: l111lll_l1_ = l11l11_l1_+l11l1l1ll1ll_l1_
		elif l11l1l111l11_l1_: l111lll_l1_ = l111ll1_l1_+l11l1l111l11_l1_
		else: l111lll_l1_ = l111ll1_l1_
		l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩ࡭ࡱࡺࡥࡳ࠯ࡧࡶࡴࡶࡤࡰࡹࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡳࡦࡥࡷ࡭ࡴࡴࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡲࡵࡶࡦࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡱࡵࡸࠥࡨࡹࠨ࠮ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ࠱ࡴࡪࡶ࡯ࡩࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠨࠢࠣ慇")
	ITEMS(l111lll_l1_)
	return
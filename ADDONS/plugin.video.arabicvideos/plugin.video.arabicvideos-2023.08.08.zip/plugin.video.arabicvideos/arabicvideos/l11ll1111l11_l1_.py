# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ嗱")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ嗲")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嗳"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1lllll_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l11ll11111ll_l1_(url)
	elif mode==314: results = l1llll11l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗴"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ嗵"),l11l1l_l1_ (u"ࠬ࠭嗶"),319,l11l1l_l1_ (u"࠭ࠧ嗷"),l11l1l_l1_ (u"ࠧࠨ嗸"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嗹"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗺"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠨ嗻"),l11l1l_l1_ (u"ࠫࠬ嗼"),114,l11l11_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ嗽"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ嗾"),l11l1l_l1_ (u"ࠧࠨ嗿"),l11l1l_l1_ (u"ࠨࠩ嘀"),l11l1l_l1_ (u"ࠩࠪ嘁"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嘂"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嘃"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嘄"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嘅"),l11l1l_l1_ (u"ࠧࠨ嘆"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾࡫࠹ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠵࠿ࠩ嘇"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11l1l_l1_ (u"ࠩࠣࠫ嘈"))
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘉"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嘊")+l1111l_l1_+title,l11l11_l1_,314,l11l1l_l1_ (u"ࠬ࠭嘋"),l11l1l_l1_ (u"࠭ࠧ嘌"),str(seq+1))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘍"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嘎")+l1111l_l1_+l11l1l_l1_ (u"่ࠩๆฬ฽ูࠡึ๊ีࠬ嘏"),l11l11_l1_,314,l11l1l_l1_ (u"ࠪࠫ嘐"),l11l1l_l1_ (u"ࠫࠬ嘑"),l11l1l_l1_ (u"ࠬ࠶ࠧ嘒"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嘓"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嘔"),l11l1l_l1_ (u"ࠨࠩ嘕"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡇࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂ࠿ࠩ嘖"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ嘗")+l1llll1_l1_
		#title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭嘘"))
		#url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫ嘙")
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘚"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嘛")+l1111l_l1_+title,l1llll1_l1_,311)
	return html
def l1llll11l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嘜"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ嘝"),l11l1l_l1_ (u"ࠪࠫ嘞"),l11l1l_l1_ (u"ࠫࠬ嘟"),l11l1l_l1_ (u"ࠬ࠭嘠"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭嘡"))
	html = response.content
	if seq==l11l1l_l1_ (u"ࠧ࠱ࠩ嘢"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭嘣"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嘤"),block,re.DOTALL)
		for l1llll1_l1_,name,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ嘥")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭嘦"))
			name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ嘧"))
			title = title+l11l1l_l1_ (u"࠭ࠠࠩࠩ嘨")+name+l11l1l_l1_ (u"ࠧࠪࠩ嘩")
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嘪"),l1111l_l1_+title,l1llll1_l1_,312)
	elif seq in [l11l1l_l1_ (u"ࠩ࠴ࠫ嘫"),l11l1l_l1_ (u"ࠪ࠶ࠬ嘬"),l11l1l_l1_ (u"ࠫ࠸࠭嘭")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ嘮"),html,re.DOTALL)
		l11ll11111l1_l1_ = int(seq)-1
		block = l1l11ll_l1_[l11ll11111l1_l1_]
		if seq==l11l1l_l1_ (u"࠭࠱ࠨ嘯"): items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嘰"),block,re.DOTALL)
		else: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嘱"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ嘲")+l1ll1l_l1_
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ嘳")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭嘴"))
			name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ嘵"))
			title = title+l11l1l_l1_ (u"࠭ࠠࠩࠩ嘶")+name+l11l1l_l1_ (u"ࠧࠪࠩ嘷")
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘸"),l1111l_l1_+title,l1llll1_l1_,311,l1ll1l_l1_)
	elif seq in [l11l1l_l1_ (u"ࠩ࠷ࠫ嘹"),l11l1l_l1_ (u"ࠪ࠹ࠬ嘺"),l11l1l_l1_ (u"ࠫ࠻࠭嘻")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ嘼"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l11ll_l1_[seq]
		items = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嘽"),block,re.DOTALL)
		for l1ll1l_l1_,l1llll1_l1_,l1l1l1ll1ll_l1_,title,l1ll1ll1l11_l1_ in items:
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ嘾")+l1ll1l_l1_
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ嘿")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ噀"))
			l1l1l1ll1ll_l1_ = l1l1l1ll1ll_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ噁"))
			l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭噂"))
			if l1l1l1ll1ll_l1_: name = l1l1l1ll1ll_l1_
			else: name = l1ll1ll1l11_l1_
			title = title+l11l1l_l1_ (u"ࠬࠦࠨࠨ噃")+name+l11l1l_l1_ (u"࠭ࠩࠨ噄")
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭噅"),l1111l_l1_+title,l1llll1_l1_,312,l1ll1l_l1_)
	return
def l1lllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ噆"),url,l11l1l_l1_ (u"ࠩࠪ噇"),l11l1l_l1_ (u"ࠪࠫ噈"),l11l1l_l1_ (u"ࠫࠬ噉"),l11l1l_l1_ (u"ࠬ࠭噊"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭噋"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ噌"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	if l11l1l_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ噍") in block:
		items = re.findall(l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ噎"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1llll1_l1_,title,count in items:
				l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ噏")+l1ll1l_l1_
				l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࠭噐")+l1llll1_l1_
				count = count.replace(l11l1l_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ噑"),l11l1l_l1_ (u"࠭࠺ࠨ噒"))
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ噓"))
				title = title+l11l1l_l1_ (u"ࠨࠢࠫࠫ噔")+count+l11l1l_l1_ (u"ࠩࠬࠫ噕")
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噖"),l1111l_l1_+title,l1llll1_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l11l1l_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ噗"),block,re.DOTALL)
		for l1llll1_l1_,title,l11ll1111l1l_l1_,l1l11ll11_l1_ in items:
			if title==l11l1l_l1_ (u"ࠬ࠭噘") or l11ll1111l1l_l1_==l11l1l_l1_ (u"࠭ࠧ噙"): continue
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ噚")+l1llll1_l1_
			title = title+l11l1l_l1_ (u"ࠨࠢࠫࠫ噛")+l1l11ll11_l1_+l11l1l_l1_ (u"ࠩࠬࠫ噜")
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ噝"),l1111l_l1_+title,l1llll1_l1_,312)
	if not items: l1lll1ll_l1_(html)
	return
def l1lll1ll_l1_(html):
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ噞"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噟"),block,re.DOTALL)
	for l1llll1_l1_,title,name,count,l1l11ll11_l1_ in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨ噠")+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ噡"))
		name = name.strip(l11l1l_l1_ (u"ࠨࠢࠪ噢"))
		title = title+l11l1l_l1_ (u"ࠩࠣࠬࠬ噣")+name+l11l1l_l1_ (u"ࠪ࠭ࠬ噤")
		addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ噥"),l1111l_l1_+title,l1llll1_l1_,312,l11l1l_l1_ (u"ࠬ࠭噦"),l1l11ll11_l1_)
	return
def l11ll11111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ噧"),url,l11l1l_l1_ (u"ࠧࠨ器"),l11l1l_l1_ (u"ࠨࠩ噩"),l11l1l_l1_ (u"ࠩࠪ噪"),l11l1l_l1_ (u"ࠪࠫ噫"),l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ噬"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭噭"),html,re.DOTALL)
	if not l1l11ll_l1_:
		l1lllll_l1_(url)
		return
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ噮"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ噯")+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ噰"))
		if l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ噱") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ噲"),l1111l_l1_+title,l1llll1_l1_,312)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ噳"),l1111l_l1_+title,l1llll1_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ噴"),url,l11l1l_l1_ (u"࠭ࠧ噵"),l11l1l_l1_ (u"ࠧࠨ噶"),l11l1l_l1_ (u"ࠨࠩ噷"),l11l1l_l1_ (u"ࠩࠪ噸"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ噹"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噺"),html,re.DOTALL)
	if not l1llll1_l1_: l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ噻"),html,re.DOTALL)
	l1llll1_l1_ = l11l11_l1_+l1llll1_l1_[0]
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ噼"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ噽"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ噾"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ噿"),l11l1l_l1_ (u"ࠪ࠯ࠬ嚀"))
	l11ll1lll1l_l1_ = [l11l1l_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ嚁"),l11l1l_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ嚂"),l11l1l_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ嚃")]
	if l1ll_l1_:
		l1l1111111l_l1_ = [l11l1l_l1_ (u"ࠧใษิสࠬ嚄"),l11l1l_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ嚅"),l11l1l_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ嚆")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ嚇"), l1l1111111l_l1_)
		if l1l_l1_ == -1: return
	elif l11l1l_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ嚈") in options: l1l_l1_ = 0
	elif l11l1l_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ嚉") in options: l1l_l1_ = 1
	elif l11l1l_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ嚊") in options: l1l_l1_ = 2
	else: return
	type = l11ll1lll1l_l1_[l1l_l1_]
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ嚋")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嚌"),url,l11l1l_l1_ (u"ࠩࠪ嚍"),l11l1l_l1_ (u"ࠪࠫ嚎"),l11l1l_l1_ (u"ࠫࠬ嚏"),l11l1l_l1_ (u"ࠬ࠭嚐"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭嚑"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ嚒"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嚓"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ嚔"))
				name = name.strip(l11l1l_l1_ (u"ࠪࠤࠬ嚕"))
				title = title+l11l1l_l1_ (u"ࠫࠥ࠮ࠧ嚖")+name+l11l1l_l1_ (u"ࠬ࠯ࠧ嚗")
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚘"),l1111l_l1_+title,l1llll1_l1_,313,l1ll1l_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嚙"),block,re.DOTALL)
			for l1llll1_l1_,title,name in items:
				title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ嚚"))
				name = name.strip(l11l1l_l1_ (u"ࠩࠣࠫ嚛"))
				title = title+l11l1l_l1_ (u"ࠪࠤ࠭࠭嚜")+name+l11l1l_l1_ (u"ࠫ࠮࠭嚝")
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嚞"),l1111l_l1_+title,l1llll1_l1_,312)
	return
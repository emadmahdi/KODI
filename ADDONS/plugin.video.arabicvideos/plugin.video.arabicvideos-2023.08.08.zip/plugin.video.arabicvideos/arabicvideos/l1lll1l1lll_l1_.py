# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ⌏")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨ⌐")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ฺ้ࠪอัฺหࠪ⌑"),l11l1l_l1_ (u"ࠫฬำฯฬࠢส่อืวๆฮࠪ⌒"),l11l1l_l1_ (u"ࠬออะอࠣห้อไฺษหࠫ⌓"),l11l1l_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ⌔"),l11l1l_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭⌕")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l1lllll_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l1lll1ll_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⌖"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ⌗"),l11l1l_l1_ (u"ࠪࠫ⌘"),l11l1l_l1_ (u"ࠫࠬ⌙"),l11l1l_l1_ (u"ࠬ࠭⌚"),l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⌛"))
	html = response.content
	l1l1lll_l1_ = SERVER(l11l11_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⌜"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌝"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⌞"),l11l1l_l1_ (u"ࠪࠫ⌟"),449,l11l1l_l1_ (u"ࠫࠬ⌠"),l11l1l_l1_ (u"ࠬ࠭⌡"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⌢"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌣"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⌤")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ⌥"),l11l11_l1_,441)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⌦"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⌧"),l11l1l_l1_ (u"ࠬ࠭⌨"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡤࡳࡥ࡯ࡷࡢࡶ࡮࡭ࡨࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ〈"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ〉"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if l1llll1_l1_==l11l1l_l1_ (u"ࠨࠥࠪ⌫"): continue
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌬"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⌭")+l1111l_l1_+title,l1llll1_l1_,441)
	return
def l1lllll_l1_(url,l111l11l_l1_=l11l1l_l1_ (u"ࠫࠬ⌮")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⌯"),url,l11l1l_l1_ (u"࠭ࠧ⌰"),l11l1l_l1_ (u"ࠧࠨ⌱"),l11l1l_l1_ (u"ࠨࠩ⌲"),l11l1l_l1_ (u"ࠩࠪ⌳"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⌴"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭⌵"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬࡂ࡬ࡪࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠶ࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⌶"),block,re.DOTALL)
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		if l11l1l_l1_ (u"࠭࠯ࡶࡴ࡯࠳ࠬ⌷") in l1llll1_l1_: continue
		elif l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ⌸") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌹"),l1111l_l1_+title,l1llll1_l1_,443,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ⌺") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌻"),l1111l_l1_+title,l1llll1_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⌼"),l1111l_l1_+title,l1llll1_l1_,442,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⌽"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⌾"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌿"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ⍀")+title,l1llll1_l1_,441)
	return
l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࡡ࡭࡮ࡗ࡭ࡹࡲࡥࡴࠢࡀࠤࡠࡣࠊࠊࡸ࡬ࡨࡪࡵࡌࡊࡕࡗࠤࡂ࡛ࠦࠨ็ืห์ีษࠨ࠮ࠪๅ๏๊ๅࠨ࠮ࠪห฿์๊สࠩ࠯่๊๊ࠫษࠩ࠯ࠫฬ฿ไศ่ࠪ࠰ࠬํฯศใࠪ࠰๋ࠬศศำสอࠬ࠲ฺࠧำูࠫ࠱࠭ๅ่ำฯห๋࠭ࠬࠨษ็ฬํ๋ࠧ࡞ࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨ࠰࡮ࡳࡧࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡶࡰࡨࡷࡨࡧࡰࡦࡊࡗࡑࡑ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪ࡯࡭ࡳࡱࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨ࠱ࠪ࠭ࠏࠏࠉࡦࡲ࡬ࡷࡴࡪࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡡ࡯ࡻࠫࡺࡦࡲࡵࡦࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡤࡰࡺ࡫ࠠࡪࡰࠣࡺ࡮ࡪࡥࡰࡎࡌࡗ࡙࠯࠺ࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠸ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࡫ࡰࡪࡵࡲࡨࡪࠦࡡ࡯ࡦࠣࠫฬ๊อๅไฬࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭࡟ࡎࡑࡇࡣࠬࠦࠫࠡࡧࡳ࡭ࡸࡵࡤࡦ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࠣࡲࡴࡺࠠࡪࡰࠣࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࡀࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠳࠭࡫ࡰ࡫࠮ࠐࠉࠊࠋࠌࡥࡱࡲࡔࡪࡶ࡯ࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡧ࡯࡭࡫ࠦࠧ࠰ࡣࡶࡷࡪࡳࡢ࡭ࡻ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠱࠭࡫ࡰ࡫࠮ࠐࠉࠊࡧ࡯࡭࡫ࠦࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠸࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠺࠴࠴࠮࡬ࡱ࡬࠯ࠊࠊ࡫ࡩࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࡃ࠽ࠨࠩ࠽ࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ⍁")
def l1lll1ll_l1_(url):
	data = {l11l1l_l1_ (u"࡚ࠪ࡮࡫ࡷࠨ⍂"):1}
	headers = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⍃"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ⍄")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ⍅"),url,data,headers,l11l1l_l1_ (u"ࠧࠨ⍆"),l11l1l_l1_ (u"ࠨࠩ⍇"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⍈"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡸ࡫ࡡࡴࡱࡱࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ⍉"),html,re.DOTALL)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡫ࡰࡪࡵࡲࡨࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪ⍊"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⍋"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⍌"),l1111l_l1_+title,l1llll1_l1_,443,l1ll1l_l1_)
	# l11ll_l1_
	elif l1l1111_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡱࡪ࠾࡮ࡳࡡࡨࡧࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⍍"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⍎"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ⍏"),l11l1l_l1_ (u"ࠪࠫ⍐")).strip(l11l1l_l1_ (u"ࠫࠥ࠭⍑"))
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⍒"),l1111l_l1_+title,l1llll1_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l11l1l_l1_ (u"࠭ࡖࡪࡧࡺࠫ⍓"):1}
	headers = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⍔"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ⍕")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⍖"),url,data,headers,l11l1l_l1_ (u"ࠪࠫ⍗"),l11l1l_l1_ (u"ࠫࠬ⍘"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⍙"))
	html = response.content
	l1lll1_l1_ = []
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡸࡣࡷࡧ࡭ࡇࡲࡦࡣࡐࡥࡸࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⍚"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ⍛"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ⍜"),l11l1l_l1_ (u"ࠩࠪ⍝")).strip(l11l1l_l1_ (u"ࠪࠤࠬ⍞"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⍟")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⍠")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡥࡱࡱࡻࡱࡵࡡࡥ࠯ࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⍡"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡨࡶ࠲ࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⍢"),block,re.DOTALL)
		for title,l111ll1l_l1_,l1llll1_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ⍣"),l11l1l_l1_ (u"ࠩࠪ⍤"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⍥")+title+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⍦")+l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ⍧")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ⍨"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⍩"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩ⍪"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪ⍫"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ⍬"),l11l1l_l1_ (u"ࠫ࠰࠭⍭"))
	#search = unescapeHTML(search)
	url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ⍮")+search
	l1lllll_l1_(url)
	return
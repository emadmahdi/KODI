# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
import bs4
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ⓹")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡉࡑࡉ࡟ࠨ⓺")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1ll1l1ll1l_l1_(url)
	elif mode==512: results = l1lll1l11l1_l1_(url)
	elif mode==513: results = l1lll1l111l_l1_(url)
	elif mode==514: results = l1ll1l1llll_l1_(url,l11l1l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⓻")+text)
	elif mode==515: results = l1ll1l1llll_l1_(url,l11l1l_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⓼")+text)
	elif mode==516: results = l1lll111111_l1_(text)
	elif mode==517: results = l1lll11l11l_l1_(url)
	elif mode==518: results = l1lll11l1l1_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1lll1111ll_l1_(url)
	elif mode==521: results = l1ll1l1ll11_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1ll1ll11l1_l1_(text)
	elif mode==524: results = l1ll1ll1l1l_l1_()
	elif mode==525: results = l1lll1l1111_l1_()
	elif mode==526: results = l1lll1111l1_l1_()
	elif mode==527: results = l1ll1ll1ll1_l1_()
	else: results = False
	return results
def MENU(l1l1l111_l1_=l11l1l_l1_ (u"ࠬ࠭⓽")):
	if not l1l1l111_l1_:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⓾"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⓿"),l11l1l_l1_ (u"ࠨࠩ─"),519)
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ━"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ│"),l11l1l_l1_ (u"ࠫࠬ┃"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┄"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅล฼้ฬ๊ࠧ┅"),l11l1l_l1_ (u"ࠧࠨ┆"),525)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┇"),l1111l_l1_+l11l1l_l1_ (u"่ࠩ์ุ๎ูสࠢส่ศฺฮศืࠪ┈"),l11l1l_l1_ (u"ࠪࠫ┉"),526)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┊"),l1111l_l1_+l11l1l_l1_ (u"๋่ࠬิ๊฼อࠥอไๆื้ๅฬะࠧ┋"),l11l1l_l1_ (u"࠭ࠧ┌"),527)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┍"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็้๋๎ูศฬࠪ┎"),l11l1l_l1_ (u"ࠩࠪ┏"),524)
	return
def l1ll1ll1l1l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┐"),l1111l_l1_+l11l1l_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠ࠮ࠢัหฺฯࠧ┑"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࠬ┒"),520)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),l1111l_l1_+l11l1l_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศำฯฬࠩ└"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰࡮ࡤࡸࡪࡹࡴࠨ┕"),521)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┖"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠳ࠠฤไา้ࠬ┗"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࡴࡲࡤࡦࡵࡷࠫ┘"),521)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┙"),l1111l_l1_+l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡ࠯ࠣว่ััࠡ็ืห์ีษࠨ┚"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯ࡷ࡫ࡨࡻࡸ࠭┛"),521)
	return
def l1lll1l1111_l1_():
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡴࡺࡲࡨࠤࡂࠦ࠱ࠡࠥࠣࡥࡨࡺ࡯ࡳࡵࠐࠎࠎࡺࡹࡱࡧࠣࡁࠥ࠸ࠠࠤࠢࡹ࡭ࡩ࡫࡯ࡴࠏࠍࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡ࠳ࠣࠧࠥࡳ࡯ࡷ࡫ࡨࡷࠒࠐࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤ࠸ࠦࠣࠡࡵࡨࡶ࡮࡫ࡳࠎࠌࠌࡪࡴࡸࡥࡪࡩࡱࠤࡂࠦࡦࡢ࡮ࡶࡩࠥࠩࠠࡢࡴࡤࡦ࡮ࡩࠍࠋࠋࡩࡳࡷ࡫ࡩࡨࡰࠣࡁࠥࡺࡲࡶࡧࠣࠧࠥ࡫࡮ࡨ࡮࡬ࡷ࡭ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦรโๆส้ࠥ฿ัษ์ࠪ࠰ࡱ࡯࡮࡬࠴࠯࠹࠶࠷ࠩࠎࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨ็่ฯ้๐ๆࠡ็ึุ่๊วหࠢ฼ีอ๐ࠧ࠭࡮࡬ࡲࡰ࠹ࠬ࠶࠳࠴࠭ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊ࠥษแๅษ่ࠤฬาๆษ์ࠪ࠰ࡱ࡯࡮࡬࠶࠯࠹࠶࠷ࠩࠎࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨ็่ฯ้๐ๆࠡ็ึุ่๊วหࠢสะ๋ฮ๊ࠨ࠮࡯࡭ࡳࡱ࠵࠭࠷࠴࠵࠮ࠓࠊࠊ࡮࡬ࡲࡰ࠷ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭ࠍࠋࠋ࡯࡭ࡳࡱ࠲ࠡ࠿ࠣࡰ࡮ࡴ࡫࠱࠭ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭ࠍࠋࠋ࡯࡭ࡳࡱ࠳ࠡ࠿ࠣࡰ࡮ࡴ࡫࠱࠭ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭ࠍࠋࠋ࡯࡭ࡳࡱ࠴ࠡ࠿ࠣࡰ࡮ࡴ࡫࠱࠭ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠻ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉࠣࠤࠥ├")
	l1ll1ll1111_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠫ┝")
	l1ll1llll11_l1_ = l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭┞")
	l1lll11llll_l1_ = l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧ┟")
	l1ll1ll1lll_l1_ = l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠳ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧ┠")
	l1ll1lll111_l1_ = l1ll1ll1111_l1_+l11l1l_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠶ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨ┡")
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┢"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ุ๊ๆอสࠡลไ่ฬฺ๋ࠠำห๎ࠬ┣"),l1ll1llll11_l1_,511)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┤"),l1111l_l1_+l11l1l_l1_ (u"ฺ้ࠪ์แศฬุ้๊ࠣำๅษอࠤ฾ืศ๋ࠩ┥"),l1lll11llll_l1_,511)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┦"),l1111l_l1_+l11l1l_l1_ (u"๋ࠬี็ใสฮࠥษแๅษ่ࠤฬาๆษ์ࠪ┧"),l1ll1ll1lll_l1_,511)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┨"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆื้ๅฬะࠠๆี็ื้อสࠡษฯ๊อ๐ࠧ┩"),l1ll1lll111_l1_,511)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭┪"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ┫"),l11l1l_l1_ (u"ࠪࠫ┬"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┭"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็็าีࠣว฾๋วๅࠢฦฬัี๊ࠨ┮"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡦࡲࡰࡩࡣࡥࡩࡹ࠭┯"),517)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┰"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ๊ีุࠦࠠษๆาࠤฬ๊ล็ฬสะࠬ┱"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡤࡱࡸࡲࡹࡸࡹࠨ┲"),517)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┳"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆํัิࠢส่้เษࠨ┴"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡰࡦࡴࡧࡶࡣࡪࡩࠬ┵"),517)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┶"),l1111l_l1_+l11l1l_l1_ (u"ࠧโ้ิื๋ࠥี็ใสฮࠥอไฺ็็ࠫ┷"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡧࡦࡰࡵࡩࠬ┸"),517)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┹"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ์ืำࠡี้อࠥอไฦืาหึ࠭┺"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡵࡩࡱ࡫ࡡࡴࡧࡢࡽࡪࡧࡲࠨ┻"),517)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ┼"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠸࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ┽"),l11l1l_l1_ (u"ࠧࠨ┾"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┿"),l1111l_l1_+l11l1l_l1_ (u"่ࠩ์ฬูๅࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭╀"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ╁"),515)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╂"),l1111l_l1_+l11l1l_l1_ (u"๋่ࠬศี่ࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ╃"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ╄"),514)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╅"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠷ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠴࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ╆"),l11l1l_l1_ (u"ࠩࠪ╇"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╈"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ๊ำฯะࠩ╉"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭╊"),515)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╋"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆื้ๅฬะࠠ࠮ࠢไ่ฯืࠠไษ่่ࠬ╌"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ╍"),514)
	return
def l1ll1ll1ll1_l1_():
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭╎"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ╏"),l11l1l_l1_ (u"ࠫࠬ═"),l11l1l_l1_ (u"ࠬ࠭║"),l11l1l_l1_ (u"࠭ࠧ╒"),l11l1l_l1_ (u"ࠧࠨ╓"),l11l1l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ╔"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ╕"),multi_valued_attributes=None)
	block = l1ll1l1l1ll_l1_.find(l11l1l_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶࠪ╖"),attrs={l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ╗"):l11l1l_l1_ (u"ࠬࡺࡡࡨࠩ╘")})	# <select name=l11l1l_l1_ (u"࠭ࡴࡢࡩࠪ╙")>
	options = block.find_all(l11l1l_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠧ╚"))
	for option in options:
		value = option.get(l11l1l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ╛"))		# or option[l11l1l_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ╜")] l1l1l1l111_l1_ it will l1lll11l1ll_l1_ if not l1l11lll1_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ╝"))
			value = value.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ╞"))
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵࡅࡵࡵࡨ࠻ࡁࠪࡋ࠲ࠦ࠻ࡆࠩ࠾࠹ࠦࡵࡻࡳࡩࡂࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࠪࡹࡧࡧ࠾ࠩ╟")+value
		title = title.replace(l11l1l_l1_ (u"࠭โศศ่อࠥ࠭╠"),l11l1l_l1_ (u"ࠧࠨ╡"))
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╢"),l1111l_l1_+title,l1llll1_l1_,511)
	return
def l1lll1111l1_l1_():
	l1ll1ll1111_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠫ╣")
	l1ll1lll1ll_l1_ = l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧ╤")
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╥"),l1111l_l1_+l11l1l_l1_ (u"๋ࠬี็ใสฮࠥษิฯษุࠫ╦"),l1ll1lll1ll_l1_,511)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ╧"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ╨"),l11l1l_l1_ (u"ࠨࠩ╩"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╪"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ์ืำࠡลืาฬ฻ࠠฤสฯำ๏࠭╫"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡦࡲࡰࡩࡣࡥࡩࡹ࠭╬"),517)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ╭"),l1111l_l1_+l11l1l_l1_ (u"࠭แ่ำึࠤ๊๎ื็ࠩ╮"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯࡯ࡣࡷ࡭ࡴࡴࡡ࡭࡫ࡷࡽࠬ╯"),517)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╰"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ๋ึูࠠࠡฬสี๏ิࠠศๆ่๎้อฯࠨ╱"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡦ࡮ࡸࡴࡩࡡࡼࡩࡦࡸࠧ╲"),517)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╳"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็็าีࠣࠤฯอั๋ะࠣห้๎แศหࠪ╴"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵ࡤࡦࡣࡷ࡬ࡤࡿࡥࡢࡴࠪ╵"),517)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╶"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠳࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ╷"),l11l1l_l1_ (u"ࠩࠪ╸"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╹"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ๊ำฯะࠩ╺"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭╻"),515)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╼"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆื้ๅฬะࠠ࠮ࠢไ่ฯืࠠไษ่่ࠬ╽"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ╾"),514)
	return
def l1ll1l1ll1l_l1_(url):
	if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭╿") in url: index = 0
	elif l11l1l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ▀") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ▁"),url,l11l1l_l1_ (u"ࠬ࠭▂"),l11l1l_l1_ (u"࠭ࠧ▃"),l11l1l_l1_ (u"ࠧࠨ▄"),l11l1l_l1_ (u"ࠨࠩ▅"),l11l1l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ▆"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ▇"),multi_valued_attributes=None)
	l11111l_l1_ = l1ll1l1l1ll_l1_.find_all(class_=l11l1l_l1_ (u"ࠫ࡯ࡻ࡭ࡣࡱ࠰ࡸ࡭࡫ࡡࡵࡧࡵࠤࡨࡲࡥࡢࡴࡩ࡭ࡽ࠭█"))
	for block in l11111l_l1_:
		title = block.find_all(l11l1l_l1_ (u"ࠬࡧࠧ▉"))[index].text
		l1llll1_l1_ = l11l11_l1_+block.find_all(l11l1l_l1_ (u"࠭ࡡࠨ▊"))[index].get(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࠬ▋"))
		if kodi_version<19:
			title = title.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭▌"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▍"))
		if not l11111l_l1_:
			l1lll1l11l1_l1_(l1llll1_l1_)
			return
		else:
			title = title.replace(l11l1l_l1_ (u"ࠪๆฬฬๅสࠢࠪ▎"),l11l1l_l1_ (u"ࠫࠬ▏"))
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▐"),l1111l_l1_+title,l1llll1_l1_,512)
	PAGINATION(l1ll1l1l1ll_l1_,511)
	return
def PAGINATION(l1ll1l1l1ll_l1_,mode):
	block = l1ll1l1l1ll_l1_.find(class_=l11l1l_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ░"))
	if block:
		l1l1l1l1l_l1_ = block.find_all(l11l1l_l1_ (u"ࠧࡢࠩ▒"))
		l1ll1l1l1l1_l1_ = block.find_all(l11l1l_l1_ (u"ࠨ࡮࡬ࠫ▓"))
		l1lll11111l_l1_ = list(zip(l1l1l1l1l_l1_,l1ll1l1l1l1_l1_))
		l11l1ll1l1_l1_ = -1
		length = len(l1lll11111l_l1_)
		for l1ll1111l_l1_,l1ll1ll111l_l1_ in l1lll11111l_l1_:
			l11l1ll1l1_l1_ += 1
			l1ll1ll111l_l1_ = l1ll1ll111l_l1_[l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳࠨ▔")]
			if l11l1l_l1_ (u"ࠪࡹࡳࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࠨ▕") in l1ll1ll111l_l1_ or l11l1l_l1_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࠬ▖") in l1ll1ll111l_l1_: continue
			l1ll1ll1l11_l1_ = l1ll1111l_l1_.text
			l1llll11ll_l1_ = l11l11_l1_+l1ll1111l_l1_.get(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ▗"))
			if kodi_version<19:
				l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ▘"))
				l1llll11ll_l1_ = l1llll11ll_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ▙"))
			if   l11l1ll1l1_l1_==0: l1ll1ll1l11_l1_ = l11l1l_l1_ (u"ࠨล๋่๎࠭▚")
			elif l11l1ll1l1_l1_==1: l1ll1ll1l11_l1_ = l11l1l_l1_ (u"ࠩึหอ่ษࠨ▛")
			elif l11l1ll1l1_l1_==length-2: l1ll1ll1l11_l1_ = l11l1l_l1_ (u"่ࠪฬำโสࠩ▜")
			elif l11l1ll1l1_l1_==length-1: l1ll1ll1l11_l1_ = l11l1l_l1_ (u"ࠫศิ๊าหࠪ▝")
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▞"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ▟")+l1ll1ll1l11_l1_,l1llll11ll_l1_,mode)
	return
def l1lll1l11l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ■"),url,l11l1l_l1_ (u"ࠨࠩ□"),l11l1l_l1_ (u"ࠩࠪ▢"),l11l1l_l1_ (u"ࠪࠫ▣"),l11l1l_l1_ (u"ࠫࠬ▤"),l11l1l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠱࠮࠳ࡶࡸࠬ▥"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ▦"),multi_valued_attributes=None)
	l11111l_l1_ = l1ll1l1l1ll_l1_.find_all(class_=l11l1l_l1_ (u"ࠧࡳࡱࡺࠫ▧"))
	items,first = [],True
	for block in l11111l_l1_:
		if not block.find(class_=l11l1l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠱ࡼࡸࡡࡱࡲࡨࡶࠬ▨")): continue
		if first: first = False ; continue
		l1lll11l111_l1_ = []
		l1ll1l1l11l_l1_ = block.find_all(class_=[l11l1l_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡲࡦࡦࠪ▩"),l11l1l_l1_ (u"ࠪࡧࡪࡴࡳࡰࡴࡶ࡬࡮ࡶࠠࡱࡷࡵࡴࡱ࡫ࠧ▪")])
		for l1ll1ll11ll_l1_ in l1ll1l1l11l_l1_:
			l1ll1l11l1_l1_ = l1ll1ll11ll_l1_.find_all(l11l1l_l1_ (u"ࠫࡱ࡯ࠧ▫"))[1].text
			if kodi_version<19:
				l1ll1l11l1_l1_ = l1ll1l11l1_l1_.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ▬"))
			l1lll11l111_l1_.append(l1ll1l11l1_l1_)
		if not l11l11l_l1_(l1ll1_l1_,l11l1l_l1_ (u"࠭ࠧ▭"),l1lll11l111_l1_,False):
			l111_l1_ = block.find(l11l1l_l1_ (u"ࠧࡪ࡯ࡪࠫ▮")).get(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ▯"))
			title = block.find(l11l1l_l1_ (u"ࠩ࡫࠷ࠬ▰"))
			name = title.find(l11l1l_l1_ (u"ࠪࡥࠬ▱")).text
			l1llll1_l1_ = l11l11_l1_+title.find(l11l1l_l1_ (u"ࠫࡦ࠭▲")).get(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ△"))
			l1ll1lll11l_l1_ = block.find(class_=l11l1l_l1_ (u"࠭࡮ࡰ࠯ࡰࡥࡷ࡭ࡩ࡯ࠩ▴"))
			l1ll1lll1l1_l1_ = block.find(class_=l11l1l_l1_ (u"ࠧ࡭ࡧࡪࡩࡳࡪࠧ▵"))
			if l1ll1lll11l_l1_: l1ll1lll11l_l1_ = l1ll1lll11l_l1_.text
			if l1ll1lll1l1_l1_: l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.text
			if kodi_version<19:
				l111_l1_ = l111_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭▶"))
				name = name.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▷"))
				l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▸"))
				if l1ll1lll11l_l1_: l1ll1lll11l_l1_ = l1ll1lll11l_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ▹"))
			l1ll1l1lll1_l1_ = {}
			if l1ll1lll1l1_l1_: l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠬࡹࡴࡢࡴࡶࠫ►")] = l1ll1lll1l1_l1_
			if l1ll1lll11l_l1_:
				l1ll1lll11l_l1_ = l1ll1lll11l_l1_.replace(l11l1l_l1_ (u"࠭࡜࡯ࠩ▻"),l11l1l_l1_ (u"ࠧࠡ࠰࠱ࠤࠬ▼"))
				l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠨࡲ࡯ࡳࡹ࠭▽")] = l1ll1lll11l_l1_.replace(l11l1l_l1_ (u"ࠩ࠱࠲࠳อโาลࠣห้๋า๋ัࠪ▾"),l11l1l_l1_ (u"ࠪࠫ▿"))
			if l11l1l_l1_ (u"ࠫ࠴ࡽ࡯ࡳ࡭࠲ࠫ◀") in l1llll1_l1_:
				#name = l11l1l_l1_ (u"ࠬฮอฬࠢ฼๊ࠥ࠭◁")+name
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◂"),l1111l_l1_+name,l1llll1_l1_,516,l111_l1_,l11l1l_l1_ (u"ࠧࠨ◃"),name,l11l1l_l1_ (u"ࠨࠩ◄"),l1ll1l1lll1_l1_)
			elif l11l1l_l1_ (u"ࠩ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ◅") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◆"),l1111l_l1_+name,l1llll1_l1_,513,l111_l1_,l11l1l_l1_ (u"ࠫࠬ◇"),name,l11l1l_l1_ (u"ࠬ࠭◈"),l1ll1l1lll1_l1_)
	PAGINATION(l1ll1l1l1ll_l1_,512)
	return
def l1lll1l111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ◉"),url,l11l1l_l1_ (u"ࠧࠨ◊"),l11l1l_l1_ (u"ࠨࠩ○"),l11l1l_l1_ (u"ࠩࠪ◌"),l11l1l_l1_ (u"ࠪࠫ◍"),l11l1l_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠸࠭࠲ࡵࡷࠫ◎"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ●"),multi_valued_attributes=None)
	l11111l_l1_ = l1ll1l1l1ll_l1_.find_all(l11l1l_l1_ (u"࠭࡬ࡪࠩ◐"))
	names,items = [],[]
	for block in l11111l_l1_:
		if not block.find(class_=l11l1l_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫ◑")): continue
		if not block.find(class_=[l11l1l_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠪ◒"),l11l1l_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠤࡹ࡫ࡸࡵ࠯ࡦࡩࡳࡺࡥࡳࠩ◓")]): continue
		if block.find(class_=l11l1l_l1_ (u"ࠪ࡬࡮ࡪࡥࠨ◔")): continue
		title = block.find(class_=[l11l1l_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩ࠭◕"),l11l1l_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠠࡵࡧࡻࡸ࠲ࡩࡥ࡯ࡶࡨࡶࠬ◖")])
		name = title.find(l11l1l_l1_ (u"࠭ࡡࠨ◗")).text
		if name in names: continue
		names.append(name)
		l1llll1_l1_ = l11l11_l1_+title.find(l11l1l_l1_ (u"ࠧࡢࠩ◘")).get(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫࠭◙"))
		if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡻࡴࡸ࡫࠰ࠩ◚") in url: l111_l1_ = block.find(l11l1l_l1_ (u"ࠪ࡭ࡲ࡭ࠧ◛")).get(l11l1l_l1_ (u"ࠫࡸࡸࡣࠨ◜"))
		elif l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ◝") in url: l111_l1_ = block.find(l11l1l_l1_ (u"࠭ࡩ࡮ࡩࠪ◞")).get(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ◟"))
		elif l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ◠") in url: l111_l1_ = block.find(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬࠭◡")).get(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ◢"))
		else: l111_l1_ = block.find(l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠨ◣")).get(l11l1l_l1_ (u"ࠬࡹࡲࡤࠩ◤"))
		if kodi_version<19:
			name = name.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ◥"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ◦"))
			l111_l1_ = l111_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭◧"))
		name = name.strip(l11l1l_l1_ (u"ࠩࠣࠫ◨"))
		items.append((name,l1llll1_l1_,l111_l1_))
	if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ◩") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1llll1_l1_,l111_l1_ in items:
		if l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡼࡩࡥࡧࡲ࠳ࠬ◪") in url: addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ◫"),l1111l_l1_+name,l1llll1_l1_,522,l111_l1_)
		elif l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ◬") in url: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◭"),l1111l_l1_+name,l1llll1_l1_,513,l111_l1_,l11l1l_l1_ (u"ࠨࠩ◮"),name)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◯"),l1111l_l1_+name,l1llll1_l1_,516,l111_l1_,l11l1l_l1_ (u"ࠪࠫ◰"),name)
	return
def l1lll111111_l1_(text):
	text = text.replace(l11l1l_l1_ (u"ࠫฬ๊ลฺๆส๊ࠬ◱"),l11l1l_l1_ (u"ࠬ࠭◲")).replace(l11l1l_l1_ (u"࠭ไโ์็้ࠬ◳"),l11l1l_l1_ (u"ࠧࠨ◴")).replace(l11l1l_l1_ (u"ࠨษ็ีุ๋๊ࠨ◵"),l11l1l_l1_ (u"ࠩࠪ◶"))
	text = text.replace(l11l1l_l1_ (u"ࠪษ฾๊ว็ࠩ◷"),l11l1l_l1_ (u"ࠫࠬ◸")).replace(l11l1l_l1_ (u"ࠬ็๊ๅ็ࠪ◹"),l11l1l_l1_ (u"࠭ࠧ◺")).replace(l11l1l_l1_ (u"ࠧศๆหีํ๋่ࠨ◻"),l11l1l_l1_ (u"ࠨࠩ◼"))
	text = text.replace(l11l1l_l1_ (u"ࠩส่ฯฺ่๋ไํࠫ◽"),l11l1l_l1_ (u"ࠪࠫ◾")).replace(l11l1l_l1_ (u"้๋ࠫำๅี็ࠫ◿"),l11l1l_l1_ (u"ࠬ࠭☀")).replace(l11l1l_l1_ (u"࠭ๅิๆึ่ࠬ☁"),l11l1l_l1_ (u"ࠧࠨ☂"))
	text = text.replace(l11l1l_l1_ (u"ࠨ࠼ࠪ☃"),l11l1l_l1_ (u"ࠩࠪ☄")).replace(l11l1l_l1_ (u"ࠪ࠭ࠬ★"),l11l1l_l1_ (u"ࠫࠬ☆")).replace(l11l1l_l1_ (u"ࠬ࠮ࠧ☇"),l11l1l_l1_ (u"࠭ࠧ☈")).replace(l11l1l_l1_ (u"ࠧ࠭ࠩ☉"),l11l1l_l1_ (u"ࠨࠩ☊"))
	text = text.replace(l11l1l_l1_ (u"ࠩࡢࠫ☋"),l11l1l_l1_ (u"ࠪࠫ☌")).replace(l11l1l_l1_ (u"ࠫࡀ࠭☍"),l11l1l_l1_ (u"ࠬ࠭☎")).replace(l11l1l_l1_ (u"࠭࠭ࠨ☏"),l11l1l_l1_ (u"ࠧࠨ☐")).replace(l11l1l_l1_ (u"ࠨ࠰ࠪ☑"),l11l1l_l1_ (u"ࠩࠪ☒"))
	text = text.replace(l11l1l_l1_ (u"ࠪࡠࠬ࠭☓"),l11l1l_l1_ (u"ࠫࠬ☔")).replace(l11l1l_l1_ (u"ࠬࡢࠢࠨ☕"),l11l1l_l1_ (u"࠭ࠧ☖"))
	text = text.replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠬ☗"),l11l1l_l1_ (u"ࠨࠢࠪ☘")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭☙"),l11l1l_l1_ (u"ࠪࠤࠬ☚")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ☛"),l11l1l_l1_ (u"ࠬࠦࠧ☜"))
	text = text.strip(l11l1l_l1_ (u"࠭ࠠࠨ☝"))
	l1lll11lll1_l1_ = text.count(l11l1l_l1_ (u"ࠧࠡࠩ☞"))+1
	if l1lll11lll1_l1_==1:
		l1ll1ll11l1_l1_(text)
		return
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭☟"),l1111l_l1_+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾ࠢๆ่๊อสࠡๆ็ฬาัࠠ࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭☠"),l11l1l_l1_ (u"ࠪࠫ☡"),9999)
	l1ll1lllll1_l1_ = text.split(l11l1l_l1_ (u"ࠫࠥ࠭☢"))
	l1lll11ll1l_l1_ = pow(2,l1lll11lll1_l1_)
	l1lll111l1l_l1_ = []
	def l1ll1llll1l_l1_(a,b):
		if a==l11l1l_l1_ (u"ࠬ࠷ࠧ☣"): return b
		return l11l1l_l1_ (u"࠭ࠧ☤")
	for l11l1ll1l1_l1_ in range(l1lll11ll1l_l1_,0,-1):
		l1lll111l11_l1_ = list(l1lll11lll1_l1_*l11l1l_l1_ (u"ࠧ࠱ࠩ☥")+bin(l11l1ll1l1_l1_)[2:])[-l1lll11lll1_l1_:]
		l1lll111l11_l1_ = reversed(l1lll111l11_l1_)
		result = map(l1ll1llll1l_l1_,l1lll111l11_l1_,l1ll1lllll1_l1_)
		title = l11l1l_l1_ (u"ࠨࠢࠪ☦").join(filter(None,result))
		if kodi_version<19: l1lll11ll_l1_ = title.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ☧"))
		else: l1lll11ll_l1_ = title
		if len(l1lll11ll_l1_)>2 and title not in l1lll111l1l_l1_:
			l1lll111l1l_l1_.append(title)
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☨"),l1111l_l1_+title,l11l1l_l1_ (u"ࠫࠬ☩"),523,l11l1l_l1_ (u"ࠬ࠭☪"),l11l1l_l1_ (u"࠭ࠧ☫"),title)
	return
def l1ll1ll11l1_l1_(l1lll11ll11_l1_):
	if kodi_version<19:
		l1lll11ll11_l1_ = l1lll11ll11_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ☬"))
		import arabic_reshaper
		l1lll11ll11_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1lll11ll11_l1_)
		l1lll11ll11_l1_ = bidi.algorithm.get_display(l1lll11ll11_l1_)
	import l1lll111lll_l1_
	l1lll11ll11_l1_ = OPEN_KEYBOARD(default=l1lll11ll11_l1_)
	l1lll111lll_l1_.SEARCH(l1lll11ll11_l1_)
	return
def l1lll11l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ☭"),url,l11l1l_l1_ (u"ࠩࠪ☮"),l11l1l_l1_ (u"ࠪࠫ☯"),l11l1l_l1_ (u"ࠫࠬ☰"),l11l1l_l1_ (u"ࠬ࠭☱"),l11l1l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡋࡑࡈࡊ࡞ࡅࡔࡡࡏࡍࡘ࡚ࡓ࠮࠳ࡶࡸࠬ☲"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ☳"),multi_valued_attributes=None)
	block = l1ll1l1l1ll_l1_.find(class_=l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠳ࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࠢ࡯࡭ࡸࡺ࠭ࡵ࡫ࡷࡰࡪ࠭☴"))
	l11ll1_l1_ = block.find_all(l11l1l_l1_ (u"ࠩࡤࠫ☵"))
	items = []
	for title in l11ll1_l1_:
		name = title.text
		l1llll1_l1_ = l11l11_l1_+title.get(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ☶"))
		if kodi_version<19:
			name = name.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ☷"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ☸"))
		if l11l1l_l1_ (u"࠭ࠣࠨ☹") not in l1llll1_l1_: items.append((name,l1llll1_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1llll1_l1_ = item
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☺"),l1111l_l1_+name,l1llll1_l1_,518)
	return
def l1lll11l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ☻"),url,l11l1l_l1_ (u"ࠩࠪ☼"),l11l1l_l1_ (u"ࠪࠫ☽"),l11l1l_l1_ (u"ࠫࠬ☾"),l11l1l_l1_ (u"ࠬ࠭☿"),l11l1l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡋࡑࡈࡊ࡞ࡅࡔࡡࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭♀"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ♁"),multi_valued_attributes=None)
	l11111l_l1_ = l1ll1l1l1ll_l1_.find(class_=l11l1l_l1_ (u"ࠨࡧࡻࡴࡦࡴࡤࠨ♂")).find_all(l11l1l_l1_ (u"ࠩࡷࡶࠬ♃"))
	for block in l11111l_l1_:
		l1ll1llllll_l1_ = block.find_all(l11l1l_l1_ (u"ࠪࡥࠬ♄"))
		if not l1ll1llllll_l1_: continue
		l111_l1_ = block.find(l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠨ♅")).get(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ♆"))
		name = l1ll1llllll_l1_[1].text
		l1llll1_l1_ = l11l11_l1_+l1ll1llllll_l1_[1].get(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࠫ♇"))
		l1ll1lll1l1_l1_ = block.find(class_=l11l1l_l1_ (u"ࠧ࡭ࡧࡪࡩࡳࡪࠧ♈"))
		if l1ll1lll1l1_l1_: l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.text
		if kodi_version<19:
			name = name.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭♉"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♊"))
			l111_l1_ = l111_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♋"))
		l1ll1l1lll1_l1_ = {}
		if l1ll1lll1l1_l1_: l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠫࡸࡺࡡࡳࡵࠪ♌")] = l1ll1lll1l1_l1_
		if l11l1l_l1_ (u"ࠬ࠵ࡷࡰࡴ࡮࠳ࠬ♍") in l1llll1_l1_:
			#name = l11l1l_l1_ (u"࠭ศฮอࠣ฽๋ࠦࠧ♎")+name
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♏"),l1111l_l1_+name,l1llll1_l1_,516,l111_l1_,l11l1l_l1_ (u"ࠨࠩ♐"),name,l11l1l_l1_ (u"ࠩࠪ♑"),l1ll1l1lll1_l1_)
		elif l11l1l_l1_ (u"ࠪ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ♒") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♓"),l1111l_l1_+name,l1llll1_l1_,513,l111_l1_,l11l1l_l1_ (u"ࠬ࠭♔"),name,l11l1l_l1_ (u"࠭ࠧ♕"),l1ll1l1lll1_l1_)
	PAGINATION(l1ll1l1l1ll_l1_,518)
	return
def l1lll1111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ♖"),url,l11l1l_l1_ (u"ࠨࠩ♗"),l11l1l_l1_ (u"ࠩࠪ♘"),l11l1l_l1_ (u"ࠪࠫ♙"),l11l1l_l1_ (u"ࠫࠬ♚"),l11l1l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡗࡋࡇࡉࡔ࡙࡟ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪ♛"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ♜"),multi_valued_attributes=None)
	l11ll1_l1_ = l1ll1l1l1ll_l1_.find_all(class_=l11l1l_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡶ࡬ࡸࡱ࡫ࠠࡪࡰ࡯࡭ࡳ࡫ࠧ♝"))
	l1l1_l1_ = l1ll1l1l1ll_l1_.find_all(class_=l11l1l_l1_ (u"ࠨࡤࡸࡸࡹࡵ࡮ࠡࡩࡵࡩࡪࡴࠠࡴ࡯ࡤࡰࡱࠦࡲࡪࡩ࡫ࡸࠬ♞"))
	items = zip(l11ll1_l1_,l1l1_l1_)
	for title,l1llll1_l1_ in items:
		title = title.text
		l1llll1_l1_ = l11l11_l1_+l1llll1_l1_.get(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ♟"))
		if kodi_version<19:
			title = title.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♠"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♡"))
		title = title.replace(l11l1l_l1_ (u"ࠬࠦࠠࠡࠢࠪ♢"),l11l1l_l1_ (u"࠭ࠠࠨ♣")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ♤"),l11l1l_l1_ (u"ࠨࠢࠪ♥")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ♦"),l11l1l_l1_ (u"ࠪࠤࠬ♧"))
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♨"),l1111l_l1_+title,l1llll1_l1_,521)
	return
def l1ll1l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ♩"),url,l11l1l_l1_ (u"࠭ࠧ♪"),l11l1l_l1_ (u"ࠧࠨ♫"),l11l1l_l1_ (u"ࠨࠩ♬"),l11l1l_l1_ (u"ࠩࠪ♭"),l11l1l_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡜ࡉࡅࡇࡒࡗࡤ࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ♮"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ♯"),multi_valued_attributes=None)
	l1lll1l11ll_l1_ = l1ll1l1l1ll_l1_.find(class_=l11l1l_l1_ (u"ࠬࡲࡡࡳࡩࡨ࠱ࡧࡲ࡯ࡤ࡭࠰࡫ࡷ࡯ࡤ࠮࠶ࠣࡱࡪࡪࡩࡶ࡯࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠵ࠢࡶࡱࡦࡲ࡬࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠸ࠧ♰"))
	l11111l_l1_ = l1lll1l11ll_l1_.find_all(l11l1l_l1_ (u"࠭࡬ࡪࠩ♱"))
	for block in l11111l_l1_:
		title = block.find(class_=l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭♲")).text
		l1llll1_l1_ = l11l11_l1_+block.find(l11l1l_l1_ (u"ࠨࡣࠪ♳")).get(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ♴"))
		l111_l1_ = block.find(l11l1l_l1_ (u"ࠪ࡭ࡲ࡭ࠧ♵")).get(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭♶"))
		l1l11ll11_l1_ = block.find(class_=l11l1l_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ♷")).text
		if kodi_version<19:
			title = title.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♸"))
			l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♹"))
			l111_l1_ = l111_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭♺"))
			l1l11ll11_l1_ = l1l11ll11_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♻"))
		l1l11ll11_l1_ = l1l11ll11_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭♼"),l11l1l_l1_ (u"ࠫࠬ♽")).strip(l11l1l_l1_ (u"ࠬࠦࠧ♾"))
		addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ♿"),l1111l_l1_+title,l1llll1_l1_,522,l111_l1_,l1l11ll11_l1_)
	PAGINATION(l1ll1l1l1ll_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⚀"),url,l11l1l_l1_ (u"ࠨࠩ⚁"),l11l1l_l1_ (u"ࠩࠪ⚂"),l11l1l_l1_ (u"ࠪࠫ⚃"),l11l1l_l1_ (u"ࠫࠬ⚄"),l11l1l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⚅"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ⚆"),multi_valued_attributes=None)
	l1llll1_l1_ = l1ll1l1l1ll_l1_.find(class_=l11l1l_l1_ (u"ࠧࡧ࡮ࡨࡼ࠲ࡼࡩࡥࡧࡲࠫ⚇")).find(l11l1l_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠨ⚈")).get(l11l1l_l1_ (u"ࠩࡶࡶࡨ࠭⚉"))
	if kodi_version<19: l1llll1_l1_ = l1llll1_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚊"))
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⚋"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭⚌"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ⚍"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ⚎"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ⚏"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡃࡶࡃࠧ⚐")+search
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ⚑"),url,l11l1l_l1_ (u"ࠫࠬ⚒"),l11l1l_l1_ (u"ࠬ࠭⚓"),l11l1l_l1_ (u"࠭ࠧ⚔"),l11l1l_l1_ (u"ࠧࠨ⚕"),l11l1l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ⚖"))
	html = response.content
	l1ll1l1l1ll_l1_ = bs4.BeautifulSoup(html,l11l1l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ⚗"),multi_valued_attributes=None)
	l11111l_l1_ = l1ll1l1l1ll_l1_.find_all(class_=l11l1l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱ࠱ࡹ࡯ࡴ࡭ࡧࠣࡰࡪ࡬ࡴࠨ⚘"))
	for block in l11111l_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚙"))
		title = title.split(l11l1l_l1_ (u"ࠬ࠮ࠧ⚚"),1)[0].strip(l11l1l_l1_ (u"࠭ࠠࠨ⚛"))
		if   l11l1l_l1_ (u"ࠧฤ฻่ห้࠭⚜") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⚝"),l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡻࡴࡸ࡫࠰ࠩ⚞"))
		elif l11l1l_l1_ (u"ࠪวูิวึࠩ⚟") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⚠"),l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ⚡"))
		#elif l11l1l_l1_ (u"࠭รฮัสฯࠬ⚢") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⚣"),l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡨࡺࡪࡴࡴ࠰ࠩ⚤"))
		#elif l11l1l_l1_ (u"่๋ࠩึาว็ษอࠫ⚥") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⚦"),l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࡬ࡥࡴࡶ࡬ࡺࡦࡲ࠯ࠨ⚧"))
		elif l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠧ⚨") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⚩"),l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ⚪"))
		#elif l11l1l_l1_ (u"ࠨลัฬฬืࠧ⚫") in title: l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⚬"),l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡹࡵࡰࡪࡥ࠲ࠫ⚭"))
		else: continue
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚮"),l1111l_l1_+title,l1llll1_l1_,513)
	return
# ===========================================
#     l1lll1l11l_l1_ l1lll1l111_l1_ l1lll1l1l1_l1_
# ===========================================
def l1ll1l1llll_l1_(url,text):
	global l1l111ll_l1_,l1l1llll_l1_
	if l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡧ࡬ࡴࠩ⚯") in url:
		l1l111ll_l1_ = [l11l1l_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⚰"),l11l1l_l1_ (u"ࠧࡺࡧࡤࡶࠬ⚱"),l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⚲")]
		l1l1llll_l1_ = [l11l1l_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ⚳"),l11l1l_l1_ (u"ࠪࡽࡪࡧࡲࠨ⚴"),l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⚵")]
	elif l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭⚶") in url:
		l1l111ll_l1_ = [l11l1l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⚷"),l11l1l_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ⚸"),l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭⚹")]
		l1l1llll_l1_ = [l11l1l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⚺"),l11l1l_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ⚻"),l11l1l_l1_ (u"ࠫࡹࡿࡰࡦࠩ⚼")]
	l1ll1ll1_l1_(url,text)
	return
def l1llll1ll1_l1_(url):
	url = url.split(l11l1l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⚽"))[0]
	#l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ⚾"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⚿"),url,l11l1l_l1_ (u"ࠨࠩ⛀"),l11l1l_l1_ (u"ࠩࠪ⛁"),l11l1l_l1_ (u"ࠪࠫ⛂"),l11l1l_l1_ (u"ࠫࠬ⛃"),l11l1l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ⛄"))
	html = response.content
	# all l11111l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡦࡰࡴࡰࠤࡦࡩࡴࡪࡱࡱࡁࠧ࠵ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡦࡰࡴࡰࡂࠬ⛅"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	# name + category + options block
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠡࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⛆"),block,re.DOTALL)
	return l1ll1l1l_l1_
def l1lll1ll1l_l1_(block):
	# value + name
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⛇"),block,re.DOTALL)
	return items
def l1lll1lll1_l1_(url):
	#url = url.replace(l11l1l_l1_ (u"ࠩࡦࡥࡹࡃࠧ⛈"),l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭⛉"))
	l1llll1l11_l1_ = url.split(l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⛊"))[0]
	l1lll1llll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ⛋"))
	#url = url.replace(l1llll1l11_l1_,l1lll1llll_l1_)
	url = url.replace(l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⛌"),l11l1l_l1_ (u"ࠧ࠰ࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠩࠫ⛍"))
	return url
def l111111lll_l1_(l1l1l1ll_l1_,url):
	l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⛎")) # l1lllll1l1l_l1_ be l1llllll11l_l1_
	l111lll_l1_ = url+l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⛏")+l11lll1l_l1_
	l111lll_l1_ = l1lll1lll1_l1_(l111lll_l1_)
	return l111lll_l1_
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⛐"),l11l1l_l1_ (u"ࠫࠬ⛑"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⛒"),l11l1l_l1_ (u"࠭ࠧ⛓"),filter,url)
	if l11l1l_l1_ (u"ࠧࡀࠩ⛔") in url: url = url.split(l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⛕"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭⛖"),1)
	if filter==l11l1l_l1_ (u"ࠪࠫ⛗"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠫࠬ⛘"),l11l1l_l1_ (u"ࠬ࠭⛙")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ⛚"))
	if type==l11l1l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⛛"):
		if l1l111ll_l1_[0]+l11l1l_l1_ (u"ࠨ࠿ࠪ⛜") not in l1l1111l_l1_: category = l1l111ll_l1_[0]
		for i in range(len(l1l111ll_l1_[0:-1])):
			if l1l111ll_l1_[i]+l11l1l_l1_ (u"ࠩࡀࠫ⛝") in l1l1111l_l1_: category = l1l111ll_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠪࠪࠬ⛞")+category+l11l1l_l1_ (u"ࠫࡂ࠶ࠧ⛟")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠧ⛠")+category+l11l1l_l1_ (u"࠭࠽࠱ࠩ⛡")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩ⛢"))+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ⛣")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠫ⛤"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⛥")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⛦")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⛧"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⛨")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠧࠨ⛩"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⛪")) # l1lllll1l11_l1_ l11111ll1l_l1_ not l111lllll1_l1_
		if l1l11111_l1_==l11l1l_l1_ (u"ࠩࠪ⛫"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⛬")+l1l11111_l1_
		l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛭"),l1111l_l1_+l11l1l_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ⛮"),l111ll1_l1_,511)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛯"),l1111l_l1_+l11l1l_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ⛰")+l11ll111_l1_+l11l1l_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ⛱"),l111ll1_l1_,511)
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⛲"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⛳"),l11l1l_l1_ (u"ࠫࠬ⛴"),9999)
	l1ll1l1l_l1_ = l1llll1ll1_l1_(url)
	dict = {}
	for name,l1ll11ll_l1_,block in l1ll1l1l_l1_:
		name = name.replace(l11l1l_l1_ (u"ࠬ࠳࠭ࠨ⛵"),l11l1l_l1_ (u"࠭ࠧ⛶"))
		items = l1lll1ll1l_l1_(block)
		if l11l1l_l1_ (u"ࠧ࠾ࠩ⛷") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⛸"):
			if l1ll11ll_l1_ not in l1l111ll_l1_: continue
			if category!=l1ll11ll_l1_: continue
			elif len(items)<2:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]:
					url = l1lll1lll1_l1_(url)
					l1lll1l11l1_l1_(url)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⛹")+l1l11l1l_l1_)
				return
			else:
				l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛺"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ⛻"),l111ll1_l1_,511)
				else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛼"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅฮ่๎฾࠭⛽"),l111ll1_l1_,515,l11l1l_l1_ (u"ࠧࠨ⛾"),l11l1l_l1_ (u"ࠨࠩ⛿"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ✀"):
			if l1ll11ll_l1_ not in l1l1llll_l1_: continue
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠪࠪࠬ✁")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠫࡂ࠶ࠧ✂")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠧ✃")+l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠽࠱ࠩ✄")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ✅")+l1l1l1ll_l1_
			if   name==l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭✆"): name = l11l1l_l1_ (u"ࠩส่๋๎ูࠨ✇")
			elif name==l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ✈"): name = l11l1l_l1_ (u"ࠫฬู๊ๆๆࠪ✉")
			elif name==l11l1l_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭✊"): name = l11l1l_l1_ (u"࠭วๅๆ฽อࠬ✋")
			elif name==l11l1l_l1_ (u"ࠧࡺࡧࡤࡶࠬ✌"): name = l11l1l_l1_ (u"ࠨษ็ื๋ฯࠧ✍")
			elif name==l11l1l_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ✎"): name = l11l1l_l1_ (u"ࠪห้๋่ิ็ࠪ✏")
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✐"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽࠿ࠦࠧ✑")+name,l111ll1_l1_,514,l11l1l_l1_ (u"࠭ࠧ✒"),l11l1l_l1_ (u"ࠧࠨ✓"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ✔"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if option in l1l111_l1_: continue
			if l11l1l_l1_ (u"ู่๋ࠩ็วหࠢฦาึ๏ࠧ✕") in option: continue
			if l11l1l_l1_ (u"ࠪห้้ไࠨ✖") in option: continue
			if l11l1l_l1_ (u"ࠫฬ๊ไ฻หࠪ✗") in option: continue
			option = option.replace(l11l1l_l1_ (u"่ࠬวว็ฬࠤࠬ✘"),l11l1l_l1_ (u"࠭ࠧ✙"))
			if   name==l11l1l_l1_ (u"ࠧࡵࡻࡳࡩࠬ✚"): name = l11l1l_l1_ (u"ࠨษ็๊ํ฿ࠧ✛")
			elif name==l11l1l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ✜"): name = l11l1l_l1_ (u"ࠪห้฿ๅๅࠩ✝")
			elif name==l11l1l_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ✞"): name = l11l1l_l1_ (u"ࠬอไๅ฼ฬࠫ✟")
			elif name==l11l1l_l1_ (u"࠭ࡹࡦࡣࡵࠫ✠"): name = l11l1l_l1_ (u"ࠧศๆึ๊ฮ࠭✡")
			elif name==l11l1l_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ✢"): name = l11l1l_l1_ (u"ࠩส่๊๎ำๆࠩ✣")
			#if l11l1l_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ✤") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬ✥"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠬࠬࠧ✦")+l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠽ࠨ✧")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠧࠧࠩ✨")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠨ࠿ࠪ✩")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭✪")+l1l1l1ll_l1_
			if name: title = option+l11l1l_l1_ (u"ࠪࠤ࠿࠭✫")+name
			else: title = option   #+dict[l1ll11ll_l1_][l11l1l_l1_ (u"ࠫ࠵࠭✬")]
			if type==l11l1l_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ✭"): addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✮"),l1111l_l1_+title,url,514,l11l1l_l1_ (u"ࠧࠨ✯"),l11l1l_l1_ (u"ࠨࠩ✰"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ✱"))
			elif type==l11l1l_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭✲") and l1l111ll_l1_[-2]+l11l1l_l1_ (u"ࠫࡂ࠭✳") in l1l1111l_l1_:
				l111lll_l1_ = l111111lll_l1_(l1l1l1ll_l1_,url)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✴"),l1111l_l1_+title,l111lll_l1_,511)
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✵"),l1111l_l1_+title,url,515,l11l1l_l1_ (u"ࠧࠨ✶"),l11l1l_l1_ (u"ࠨࠩ✷"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ✸"),l11l1l_l1_ (u"ࠪࠫ✹"),filters,l11l1l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬ✺"))
	# mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ✻")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ✼")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ✽")			all l1l1l11l_l1_ & l1llll11l1_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠨ࠿ࠩࠫ✾"),l11l1l_l1_ (u"ࠩࡀ࠴ࠫ࠭✿"))
	filters = filters.strip(l11l1l_l1_ (u"ࠪࠪࠬ❀"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"ࠫࡂ࠭❁") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠬࠬࠧ❂"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"࠭࠽ࠨ❃"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠧࠨ❄")
	for key in l1l1llll_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠨ࠲ࠪ❅")
		if l11l1l_l1_ (u"ࠩࠨࠫ❆") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ❇") and value!=l11l1l_l1_ (u"ࠫ࠵࠭❈"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠦࠫࠡࠩ❉")+value
		elif mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ❊") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ❋"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠨࠪ❌")+key+l11l1l_l1_ (u"ࠩࡀࠫ❍")+value
		elif mode==l11l1l_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ❎"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭❏")+key+l11l1l_l1_ (u"ࠬࡃࠧ❐")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠬࠢࠪ❑"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩ❒"))
	l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠨ࠿࠳ࠫ❓"),l11l1l_l1_ (u"ࠩࡀࠫ❔"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ❕"),l11l1l_l1_ (u"ࠫࠬ❖"),filters,l11l1l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭❗"))
	return l1ll111l_l1_
l1l111ll_l1_ = []
l1l1llll_l1_ = []
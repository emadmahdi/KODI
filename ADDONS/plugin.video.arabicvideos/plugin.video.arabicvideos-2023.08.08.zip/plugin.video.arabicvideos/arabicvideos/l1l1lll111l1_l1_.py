# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ千")
headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ卄") : l11l1l_l1_ (u"ࠩࠪ卅") }
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩ卆")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩ升"),l11l1l_l1_ (u"ࠬอไไๆࠪ午"),l11l1l_l1_ (u"࠭วโๆส้ࠬ卉"),l11l1l_l1_ (u"ࠧ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠫ半"),l11l1l_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ卋")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1lllll_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1lll1ll_l1_(url,True)
	elif mode==114: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ卌")+text)
	elif mode==115: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ卍")+text)
	elif mode==116: results = l1lll1ll_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1l1lll_l1_,response = l1ll1l11lll_l1_(l11l11_l1_,l11l1l_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭华"),l11l1l_l1_ (u"ฺࠬว่ัࠣๅํื๋๊ࠠࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨ࠹ࡻࠧ协"),headers)
	html = response.content
	l11l111l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ卐"),html,re.DOTALL)
	if l11l111l_l1_: l11l111l_l1_ = l11l111l_l1_[0].strip(l11l1l_l1_ (u"ࠧ࠰ࠩ卑"))
	else: l11l111l_l1_ = l11l11_l1_
	l1l1lll_l1_ = SERVER(l11l111l_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ卒"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ卓"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ協"),l11l1l_l1_ (u"ࠫࠬ单"),119,l11l1l_l1_ (u"ࠬ࠭卖"),l11l1l_l1_ (u"࠭ࠧ南"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ単"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ卙"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ博"),l11l111l_l1_,115)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ卛"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ卜"),l11l111l_l1_,114)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ卝"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭卞"),l11l1l_l1_ (u"ࠧࠨ卟"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ占"),l11l111l_l1_,l11l1l_l1_ (u"ࠩࠪ卡"),headers,l11l1l_l1_ (u"ࠪࠫ卢"),l11l1l_l1_ (u"ࠫࠬ卣"),l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ卤"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡴࡧࡤࡶࡨ࡮ࠧ卥"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ卦"),block,re.DOTALL)
		for filter,title in items:
			#url = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ卧")
			#url = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡈࡰ࡯ࡨ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡈࡰ࡯ࡨ࠲ࡵ࡮ࡰࠨ卨")
			url = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࠧ卩")+filter
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ卪"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ卫")+l1111l_l1_+title,url,111,l11l1l_l1_ (u"࠭ࠧ卬"),l11l1l_l1_ (u"ࠧࠨ卭"),filter)
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭卮"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ卯"),l11l1l_l1_ (u"ࠪࠫ印"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ危"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ卲"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title in l1l111_l1_: continue
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ即") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ却"))
			if l11l1l_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ卵") in l1llll1_l1_: title = l11l1l_l1_ (u"้ࠩ๎ฯ็ไไีࠪ卶")
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ卷"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭卸")+l1111l_l1_+title,l1llll1_l1_,111)
	return html
def l1lllll_l1_(url,l1lll11l11_l1_=l11l1l_l1_ (u"ࠬ࠭卹")):
	if l11l1l_l1_ (u"࠭࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡖ࡬ࡴࡽࡳ࠯ࡲ࡫ࡴࡄ࠭卺") in url:
		url,data = l1lll111ll_l1_(url)
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭卻"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ卼"),l11l1l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ卽"):l11l1l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ卾")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ卿"),url,data,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠬ࠭厀"),l11l1l_l1_ (u"࠭ࠧ厁"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭厂"))
		html = response.content
		block = html
	elif l11l1l_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ厃") in url:
		data = {l11l1l_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ厄"):l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡧࡲ࡯ࡤ࡭ࠪ厅"),l11l1l_l1_ (u"ࠫࡰ࡫ࡹࠨ历"):l1lll11l11_l1_}
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ厇"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ厈")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ厉"),url,data,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠨࠩ厊"),l11l1l_l1_ (u"ࠩࠪ压"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ厌"))
		html = response.content
		block = html
	elif l11l1l_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧ厍") in url:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ厎"),url,l11l1l_l1_ (u"࠭ࠧ厏"),l11l1l_l1_ (u"ࠧࠨ厐"),l11l1l_l1_ (u"ࠨࠩ厑"),l11l1l_l1_ (u"ࠩࠪ厒"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ厓"))
		html = response.content
		block = html
	else:
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ厔"):l11l1l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭厕")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ厖"),url,l11l1l_l1_ (u"ࠧࠨ厗"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠨࠩ厘"),l11l1l_l1_ (u"ࠩࠪ厙"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠺ࡴࡩࠩ厚"))
		html = response.content
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡵࡣࡪࡷ࠲ࡩ࡬ࡰࡷࡧࠫ厛"),html,re.DOTALL)
		if not l1l11ll_l1_: return
		block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ厜"),block,re.DOTALL)
	items = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭࡝ࡹ࠮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ厝"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ厞"),l11l1l_l1_ (u"ࠨใํ่๊࠭原"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ厠"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ厡"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ厢"),l11l1l_l1_ (u"ࠬํฯศใࠪ厣"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭厤"),l11l1l_l1_ (u"ฺࠧำูࠫ厥"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ厦"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ厧")]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ厨") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭厩") in l1llll1_l1_: continue
		#l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࠬࠣ࠱࠵࠻࠿ࠬ厪"),l11l1l_l1_ (u"࠭ࠦࠨ厫"))
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩ厬"))
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ厭"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ厮"),title,re.DOTALL)
		if l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ厯") in l1llll1_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ厰"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
		elif l1ll1l1_l1_ and l11l1l_l1_ (u"ࠬอไฮๆๅอࠬ厱") in title and l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ厲") not in url:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭厳") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ厴"),l1111l_l1_+title,l1llll1_l1_,113,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ厵") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ厶"),l1111l_l1_+title,l1llll1_l1_,111,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭厷") in l1llll1_l1_ and l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ厸") not in url:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ厹")
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ厺"),l1111l_l1_+title,l1llll1_l1_,111,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ去") in url and l11l1l_l1_ (u"ࠩะ่็ฯࠧ厼") in title:
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ厽"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ厾"),l1111l_l1_+title,l1llll1_l1_,113,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ县"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ叀"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叁"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠨษ็ูๆำษࠡࠩ参"),l11l1l_l1_ (u"ࠩࠪ參"))
			if title!=l11l1l_l1_ (u"ࠪࠫ叄"): addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ叅"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ叆")+title,l1llll1_l1_,111)
	l1llll1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ叇"),html,re.DOTALL)
	if l1llll1111_l1_:
		l1llll1_l1_ = l1llll1111_l1_[0]
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ又"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ叉"),l1llll1_l1_,111)
	return
def l1lll1ll_l1_(url,l11ll11l11l1_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭及"),url,l11l1l_l1_ (u"ࠪࠫ友"),headers,l11l1l_l1_ (u"ࠫࠬ双"),l11l1l_l1_ (u"ࠬ࠭反"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ収"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࠢ࡬ࡨࡂࠨࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡺࡡࡨࡵ࠰ࡧࡱࡵࡵࡥࠩ叏"),html,re.DOTALL)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ叐"),html,re.DOTALL)
	if l1l111l_l1_:
		# l1lll1l_l1_
		if l1l111l_l1_ and l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ发") not in url:
			block = l1l111l_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡟ࡻ࠰ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叒"),block,re.DOTALL)
			if items:
				for l1llll1_l1_,l1ll1l_l1_,title in items:
					title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭叓"))
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ叔"),l1111l_l1_+title,l1llll1_l1_,116,l1ll1l_l1_)
		# l11ll_l1_
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡢࡷࠬ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叕"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ取"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ受"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
	else:
		# l1lll1l_l1_ & l11ll_l1_
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡴࡽࠠࡨࡷࡷࡸࡪࡸ࠭ࡴ࡯ࡤࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ变"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1:
			if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ叙") in l1l11ll_l1_[0]: l1lll1l_l1_,l11ll_l1_ = l1l11ll_l1_[0],l1l11ll_l1_[1]
			else: l1lll1l_l1_,l11ll_l1_ = l1l11ll_l1_[1],l1l11ll_l1_[0]
		else: l1lll1l_l1_,l11ll_l1_ = l1l11ll_l1_[0],l1l11ll_l1_[0]
		for l11l1ll1l1_l1_ in range(2):
			if l11ll11l11l1_l1_: mode,type,name,block = 116,l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ叚"),l11l1l_l1_ (u"ࠬอไๆ๊ึ้ࠥ࠭叛"),l1lll1l_l1_
			else: mode,type,name,block = 112,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ叜"),l11l1l_l1_ (u"ࠧศๆะ่็ฯࠠࠨ叝"),l11ll_l1_
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ叞"),block,re.DOTALL)
			if l11ll11l11l1_l1_ and len(items)<2:
				l11ll11l11l1_l1_ = False
				continue
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ叟"))
				title = name+title
				addMenuItem(type,l1111l_l1_+title,l1llll1_l1_,mode)
			break
	# l11ll_l1_ l11l11l1_l1_
	if not items and l11l1l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ叠") in html:
		l1l11ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡸࡥࡢࡦࡦࡶࡺࡳࡢࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭叡"),html,re.DOTALL)
		if l1l11ll1l_l1_:
			block = l1l11ll1l_l1_[0]
			l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ叢"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1llll1_l1_ = l1l1_l1_[2]+l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ口")
				l1lllll_l1_(l1llll1_l1_)
	return
def PLAY(url):
	l1lll1_l1_ = []
	l1lllll11_l1_ = url.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ古"))
	hostname = SERVER(l1lllll11_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ句"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭另"),l1lllll11_l1_,l11l1l_l1_ (u"ࠪࠫ叧"),headers,l11l1l_l1_ (u"ࠫࠬ叨"),l11l1l_l1_ (u"ࠬ࠭叩"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ只"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ叫"))
	id = re.findall(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ召"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ叭"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠪࡴࡴࡹࡴ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ叮"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l11l1l_l1_ (u"ࠫࠬ可")
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭台"),l11l1l_l1_ (u"࠭ࠧ叱"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ史"),l11l1l_l1_ (u"ࠨ์ิะ๎ࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ右"))
	if l11l1l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠥࠫ叴") in html:
		#parts = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ叵"))
		#l111ll1_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ叶"))
		l111ll1_l1_ = l1lllll11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࠬ号")
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ司"),l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨ叹"),headers,l11l1l_l1_ (u"ࠨࠩ叺"),l11l1l_l1_ (u"ࠩࠪ叻"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ叼"))
		l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ叽"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ叾"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_: l1ll111_l1_ = l1l11ll_l1_[0]
		else: l1ll111_l1_ = l11ll11l_l1_
		if not id:
			id = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡃࠢ࠱ࠤࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ叿"),l1ll111_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l11l1l_l1_ (u"ࠧࠨ吀")
		l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吁"),l11ll11l_l1_,re.DOTALL)
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ吂"),l11ll11l_l1_,re.DOTALL)
		l11111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ吃"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ各"),l11ll11l_l1_)
		l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭吅"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		l111l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ吆"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		l11ll111llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ吇"),l1ll111_l1_,re.DOTALL|re.IGNORECASE)
		l11ll111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ合"),l1ll111_l1_,re.DOTALL|re.IGNORECASE)
		items = l11111l1l_l1_+l1l1l11_l1_+l11111ll1_l1_+l111111ll_l1_+l111111l1_l1_+l111l1111_l1_+l11ll111llll_l1_+l11ll111ll1l_l1_
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吉"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠪࡠࡹ࠭吊"),l11l1l_l1_ (u"ࠫࠬ吋")).replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ同"),l11l1l_l1_ (u"࠭ࠧ名")).strip(l11l1l_l1_ (u"ࠧࠡࠩ后"))
			#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ吏"),title)
			if l11l1l_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ吐") in server: continue
			if l11l1l_l1_ (u"ࠪ࠲࡯ࡶࡧࠨ向") in server: continue
			if l11l1l_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ吒") in server: continue
			l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭吓"),title,re.DOTALL)
			if l111ll1l_l1_:
				l111ll1l_l1_ = l111ll1l_l1_[0]
				if l111ll1l_l1_ in title: title = title.replace(l111ll1l_l1_+l11l1l_l1_ (u"࠭ࡰࠨ吔"),l11l1l_l1_ (u"ࠧࠨ吕")).replace(l111ll1l_l1_,l11l1l_l1_ (u"ࠨࠩ吖")).strip(l11l1l_l1_ (u"ࠩࠣࠫ吗"))
				l111ll1l_l1_ = l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ吘")+l111ll1l_l1_
			else: l111ll1l_l1_ = l11l1l_l1_ (u"ࠫࠬ吙")
			if server.isdigit(): l1llll1_l1_ = hostname+l11l1l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ吚")+id+l11l1l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ君")+server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ吜")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ吝")+l111ll1l_l1_
			else:
				if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ吞") not in server: server = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ吟")+server
				l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ吠"),title,re.DOTALL)
				if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ吡")+l111ll1l_l1_[0]
				else: l111ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ吢")
				l1llll1_l1_ = server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨ吣")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭吤"),l1lll1_l1_)
	#l1lll1_l1_ = []
	if l11l1l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴ࠨࠧ吥") in html:
		#parts = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ否"))
		#l111ll1_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭吧"))
		l111ll1_l1_ = l1lllll11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨ吨")
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ吩"),l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨ吪"),headers,l11l1l_l1_ (u"ࠨࠩ含"),l11l1l_l1_ (u"ࠩࠪ听"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ吭"))
		l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ吮"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡳࡥࡥ࡫ࡤ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠫ࠱ࡀ࠴ࡪࡩࡷࡀࠪ启"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_: l1ll111_l1_ = l1l11ll_l1_[0]
		else: l1ll111_l1_ = l11ll11l_l1_
		l11111l_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ吰"),l1ll111_l1_,re.DOTALL)
		for title,block in l11111l_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ吱"))
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ吲"),block,re.DOTALL)
			for l1llll1_l1_,name,l111ll1l_l1_ in items:
				l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡟ࡨ࠰࠭吳"),l111ll1l_l1_,re.DOTALL)
				if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ吴")+l111ll1l_l1_[0]
				else:
					l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪࠫࠨ吵"),title,re.DOTALL)
					if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ吶")+l111ll1l_l1_[0]
					else: l111ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ吷")
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ吸")+name+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ吹")+l111ll1l_l1_
				l1lll1_l1_.append(l1llll1_l1_)
		if not l11111l_l1_:
			#l111ll1_l1_ = hostname +l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡔࡪࡤ࡬࡮ࡪ࠴ࡶ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵ࡮ࡰࠨ吺")
			l111ll1_l1_ = hostname +l11l1l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡅࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭吻")
			l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ吼"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ吽")}
			l11ll1111_l1_ = {l11l1l_l1_ (u"࠭ࡩࡥࠩ吾"):id}
			response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ吿"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠨࠩ呀"),l11l1l_l1_ (u"ࠩࠪ呁"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ呂"))
			l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ呃"))
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ呄"),l11ll11l_l1_,re.DOTALL)
			for l1llll1_l1_,name,l111ll1l_l1_ in items:
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ呅")+name+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ呆")+l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭呇")+l111ll1l_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ呈"),l1lll1_l1_)
	elif l11l1l_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡓࡵࡷࠨ呉") in html:
		l1l1l1lll_l1_ = { l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ告"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ呋") }
		l111ll1_l1_ = l1lllll11_l1_.replace(parts[3],l11l1l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ呌"))
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ呍"),l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ呎"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠩࠪ呏"),l11l1l_l1_ (u"ࠪࠫ呐"),l11l1l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ呑"))
		l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ呒"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ呓"),l11ll11l_l1_,re.DOTALL)
		for block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩ呔"),block,re.DOTALL)
			for l1llll1_l1_,name,l111ll1l_l1_ in items:
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ呕")+name+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭呖")+l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ呗")+l111ll1l_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	elif l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ员") in html:
		l1l1l1lll_l1_ = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ呙"):l11l1l_l1_ (u"࠭ࠧ呚") , l11l1l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ呛"):l11l1l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ呜") }
		l111ll1_l1_ = hostname + l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ呝")+id
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ呞"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ呟"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠬ࠭呠"),l11l1l_l1_ (u"࠭ࠧ呡"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ呢"))
		l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭呣"))
		if l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱ࡧࡺ࡮ࡴࠩ呤") in l11ll11l_l1_:
			l11111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ呥"),l11ll11l_l1_,re.DOTALL)
			for l111lll_l1_ in l11111ll1_l1_:
				if l11l1l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ呦") not in l111lll_l1_ and l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ呧") in l111lll_l1_:
					l111lll_l1_ = l111lll_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ周")
					l1lll1_l1_.append(l111lll_l1_)
				elif l11l1l_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ呩") in l111lll_l1_:
					l111ll1l_l1_ = l11l1l_l1_ (u"ࠨࠩ呪")
					response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭呫"),l111lll_l1_,l11l1l_l1_ (u"ࠪࠫ呬"),headers,l11l1l_l1_ (u"ࠫࠬ呭"),l11l1l_l1_ (u"ࠬ࠭呮"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪ呯"))
					l1111l1ll_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ呰"))
					l11111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭呱"),l1111l1ll_l1_,re.DOTALL)
					for l111ll111_l1_ in l11111l_l1_:
						l1111ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪ呲")
						l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬ味"),l111ll111_l1_,re.DOTALL)
						for l111l11l1_l1_ in l111111ll_l1_:
							item = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ呴"),l111l11l1_l1_,re.DOTALL)
							if item:
								l111ll1l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ呵")+item[0]
								break
						for l111l11l1_l1_ in reversed(l111111ll_l1_):
							item = re.findall(l11l1l_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬ呶"),l111l11l1_l1_,re.DOTALL)
							if item:
								l1111ll1l_l1_ = item[0]
								break
						l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭呷"),l111ll111_l1_,re.DOTALL)
						for l1111llll_l1_ in l111111l1_l1_:
							l1111llll_l1_ = l1111llll_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ呸")+l1111ll1l_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭呹")+l111ll1l_l1_
							l1lll1_l1_.append(l1111llll_l1_)
		elif l11l1l_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠨ呺") in l11ll11l_l1_:
			l11ll11l_l1_ = l11ll11l_l1_.replace(l11l1l_l1_ (u"ࠫࡁ࡮࠶ࠡࠩ呻"),l11l1l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩ呼"))+l11l1l_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧ命")
			l11ll11l_l1_ = l11ll11l_l1_.replace(l11l1l_l1_ (u"ࠧ࠽ࡪ࠶ࠤࠬ呾"),l11l1l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬ呿"))+l11l1l_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪ咀")
			l11111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠮࠮ࠫࡁࠬࡁࡂࡋࡎࡅ࠿ࡀࠫ咁"),l11ll11l_l1_,re.DOTALL)
			if l11111l11_l1_:
				for l111ll111_l1_ in l11111l11_l1_:
					if l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ咂") not in l111ll111_l1_: continue
					l111l11ll_l1_ = l11l1l_l1_ (u"ࠬ࠭咃")
					l111111ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ咄"),l111ll111_l1_,re.DOTALL)
					for l111l11l1_l1_ in l111111ll_l1_:
						item = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ咅"),l111l11l1_l1_,re.DOTALL)
						if item:
							l111l11ll_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭咆")+item[0]
							break
					l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ咇"),l111ll111_l1_,re.DOTALL)
					if l111111ll_l1_:
						for l1111ll1l_l1_,l1111lll1_l1_ in l111111ll_l1_:
							l1111lll1_l1_ = l1111lll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ咈")+l1111ll1l_l1_+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ咉")+l111l11ll_l1_
							l1lll1_l1_.append(l1111lll1_l1_)
					else:
						l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ咊"),l111ll111_l1_,re.DOTALL)
						for l1111lll1_l1_,l1111ll1l_l1_ in l111111ll_l1_:
							l1111lll1_l1_ = l1111lll1_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠨ咋"))+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ和")+l1111ll1l_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ咍")+l111l11ll_l1_
							l1lll1_l1_.append(l1111lll1_l1_)
			else:
				l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭ࡢࡷࠬࠫ࠿ࠫ咎"),l11ll11l_l1_,re.DOTALL)
				for l1111lll1_l1_,l1111ll1l_l1_ in l111111ll_l1_:
					l1111lll1_l1_ = l1111lll1_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ咏"))+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ咐")+l1111ll1l_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ咑")
					l1lll1_l1_.append(l1111lll1_l1_)
	if l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ咒") in html:
		# l11l1l111_l1_
		l11ll11l1111_l1_ = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ咓"))[3]
		l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠨ࠱ࠪ咔")+l11ll11l1111_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ咕"),l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ咖"))
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ咗"),l111ll1_l1_,l11l1l_l1_ (u"ࠬ࠭咘"),l11l1l_l1_ (u"࠭ࠧ咙"),l11l1l_l1_ (u"ࠧࠨ咚"),l11l1l_l1_ (u"ࠨࠩ咛"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠻ࡸ࡭࠭咜"))
		l11ll11l_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ咝"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ咞"),l11ll11l_l1_,re.DOTALL|re.IGNORECASE)
		l1ll111_l1_ = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡂ࡬ࡪ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ咟"),l1ll111_l1_,re.DOTALL)
		for server,title in items:
			title = title.replace(l11l1l_l1_ (u"࠭࡜ࡵࠩ咠"),l11l1l_l1_ (u"ࠧࠨ咡")).replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ咢"),l11l1l_l1_ (u"ࠩࠪ咣")).strip(l11l1l_l1_ (u"ࠪࠤࠬ咤"))
			l111ll1_l1_ = hostname+l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ咥")+id+l11l1l_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ咦")+server
			l1llll1_l1_ = l111ll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ咧")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ咨")
			l1lll1_l1_.append(l1llll1_l1_)
		# l1l1111ll_l1_
		l1l1111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ咩"),l11ll11l_l1_,re.DOTALL)
		if l1l1111ll_l1_:
			l1llll1_l1_ = l1l1111ll_l1_[0]+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ咪")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ咫"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ咬"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ咭"),l11l1l_l1_ (u"࠭ࠫࠨ咮"))
	if 0 and l1ll_l1_:
		l1111ll11_l1_ = [l11l1l_l1_ (u"ࠧศใ็ห๊࠭咯"),l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ咰"),l11l1l_l1_ (u"่้ࠩะ๊๊็ࠩ咱"),l11l1l_l1_ (u"ࠪห้้ไࠨ咲")]
		l1l1lll1l_l1_ = [l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ咳"),l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ咴"),l11l1l_l1_ (u"࠭ࡡࡤࡶࡲࡶࠬ咵"),l11l1l_l1_ (u"ࠧࠨ咶")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠣ࠱ࠥอฮหำࠣห้็ไหำࠣห้๋ๆศีหࠫ咷"), l1111ll11_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lll1l_l1_[l1l_l1_]
	else: type = l11l1l_l1_ (u"ࠩࠪ咸")
	l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡪࡲࡱࡪ࠭ࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡰࡤࡱࡪࡃࠢࡵࡻࡳࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳࠪ࠮ࡶࡸࡷ࠮࡬ࡦࡰࠫ࡬ࡹࡳ࡬ࠪࠫࠬࠎࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠ࡜ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ࡞࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡨࡰࡸ࡫࠺ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠭ࠧࠋࠋࠦࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠤࠥࠦ咹")
	#url = l1l1lll_l1_ + l11l1l_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ咺")+search+l11l1l_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ咻")+type
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ咼")+search
	l111ll1_l1_,l1l1lllll_l1_ = l1ll1l11lll_l1_(url,l11l1l_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ咽"),l11l1l_l1_ (u"ࠨึส๋ิࠦแ้ำࠣ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ咾"),headers)
	l1lllll_l1_(l111ll1_l1_)
	return
# ===========================================
#     l1lll1l11l_l1_ l1lll1l111_l1_ l1lll1l1l1_l1_
# ===========================================
def l1llll1ll1_l1_(url):
	url = url.split(l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭咿"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ哀"),url,l11l1l_l1_ (u"ࠫࠬ品"),headers,l11l1l_l1_ (u"ࠬ࠭哂"),l11l1l_l1_ (u"࠭ࠧ哃"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ哄"))
	html = response.content
	# all l11111l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠦ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ哅"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		# name + category + options block
		l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡳࡻ࠮ࠫࡁࡵࡳࡺࡴࡤࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡩ࡯ࡲࡸࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ哆"),block,re.DOTALL)
		return l1ll1l1l_l1_
	return []
def l1lll1ll1l_l1_(block):
	# id + title
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡥࡤࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡫ࡩࡨࡱ࡭ࡢࡴ࡮࠱ࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ哇"),block,re.DOTALL)
	return items
def l11ll111ll11_l1_(url):
	url = url.replace(l11l1l_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ哈"),l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ哉"))
	if l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ哊") not in url: url = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ哋")
	l1llll1l11_l1_ = url.split(l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ哌"))[0]
	l1lll1llll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭响"))
	url = url.replace(l1llll1l11_l1_,l1lll1llll_l1_)
	#url = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ哎"),l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡖ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡘ࡮࡯ࡸࡵ࠱ࡴ࡭ࡶ࠿ࠨ哏"))
	#url = url.replace(l11l1l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ哐"),l11l1l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡗ࡭ࡵࡷࡴ࠰ࡳ࡬ࡵࡅࠧ哑"))
	url = url.replace(l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ哒"),l11l1l_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬ哓"))
	return url
l11ll111lll1_l1_ = [l11l1l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ哔"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ哕"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ哖"),l11l1l_l1_ (u"ࠬࡩࡡࡵࠩ哗")]
l11ll11l111l_l1_ = [l11l1l_l1_ (u"࠭ࡣࡢࡶࠪ哘"),l11l1l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭哙"),l11l1l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ哚")]
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ哛"),l11l1l_l1_ (u"ࠪࠫ哜"))
	url = url.split(l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ哝"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩ哞"),1)
	if filter==l11l1l_l1_ (u"࠭ࠧ哟"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠧࠨ哠"),l11l1l_l1_ (u"ࠨࠩ員")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭哢"))
	if type==l11l1l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ哣"):
		if l11ll11l111l_l1_[0]+l11l1l_l1_ (u"ࠫࡂ࠭哤") not in l1l1111l_l1_: category = l11ll11l111l_l1_[0]
		for i in range(len(l11ll11l111l_l1_[0:-1])):
			if l11ll11l111l_l1_[i]+l11l1l_l1_ (u"ࠬࡃࠧ哥") in l1l1111l_l1_: category = l11ll11l111l_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨ哦")+category+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ哧")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪ哨")+category+l11l1l_l1_ (u"ࠩࡀ࠴ࠬ哩")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬ哪"))+l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ哫")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠬࠬࠧ哬"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ哭"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ哮")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭哯"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ哰"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠪࠫ哱"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ哲"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠬ࠭哳"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ哴")+l1l11111_l1_
		l111lll_l1_ = l11ll111ll11_l1_(l111ll1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ哵"),l1111l_l1_+l11l1l_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ哶"),l111lll_l1_,111)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ哷"),l1111l_l1_+l11l1l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ哸")+l11ll111_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ哹"),l111lll_l1_,111)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ哺"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭哻"),l11l1l_l1_ (u"ࠧࠨ哼"),9999)
	l1ll1l1l_l1_ = l1llll1ll1_l1_(url)
	dict = {}
	for name,l1ll11ll_l1_,block in l1ll1l1l_l1_:
		name = name.replace(l11l1l_l1_ (u"ࠨ࠯࠰ࠫ哽"),l11l1l_l1_ (u"ࠩࠪ哾"))
		items = l1lll1ll1l_l1_(block)
		if l11l1l_l1_ (u"ࠪࡁࠬ哿") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ唀"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<2:
				if l1ll11ll_l1_==l11ll11l111l_l1_[-1]:
					l111lll_l1_ = l11ll111ll11_l1_(l111ll1_l1_)
					l1lllll_l1_(l111lll_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ唁")+l1l11l1l_l1_)
				return
			else:
				if l1ll11ll_l1_==l11ll11l111l_l1_[-1]:
					l111lll_l1_ = l11ll111ll11_l1_(l111ll1_l1_)
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭唂"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ唃"),l111lll_l1_,111)
				else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ唄"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ唅"),l111ll1_l1_,115,l11l1l_l1_ (u"ࠪࠫ唆"),l11l1l_l1_ (u"ࠫࠬ唇"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ唈"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨ唉")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ唊")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪ唋")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀ࠴ࠬ唌")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ唍")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唎"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ唏")+name,l111ll1_l1_,114,l11l1l_l1_ (u"࠭ࠧ唐"),l11l1l_l1_ (u"ࠧࠨ唑"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ唒"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if value==l11l1l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ唓"): option = l11l1l_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ唔")
			elif value==l11l1l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ唕"): option = l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ唖")
			if option in l1l111_l1_: continue
			#if l11l1l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ唗") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ唘"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠨࠨࠪ唙")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀࠫ唚")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠬ唛")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠫࡂ࠭唜")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩ唝")+l1l1l1ll_l1_
			title = option+l11l1l_l1_ (u"࠭ࠠ࠻ࠩ唞")#+dict[l1ll11ll_l1_][l11l1l_l1_ (u"ࠧ࠱ࠩ唟")]
			title = option+l11l1l_l1_ (u"ࠨࠢ࠽ࠫ唠")+name
			if type==l11l1l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ唡"): addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唢"),l1111l_l1_+title,url,114,l11l1l_l1_ (u"ࠫࠬ唣"),l11l1l_l1_ (u"ࠬ࠭唤"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ唥"))
			elif type==l11l1l_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ唦") and l11ll11l111l_l1_[-2]+l11l1l_l1_ (u"ࠨ࠿ࠪ唧") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ唨"))
				l111ll1_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ唩")+l11lll1l_l1_
				l111lll_l1_ = l11ll111ll11_l1_(l111ll1_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唪"),l1111l_l1_+title,l111lll_l1_,111)
			else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ唫"),l1111l_l1_+title,url,115,l11l1l_l1_ (u"࠭ࠧ唬"),l11l1l_l1_ (u"ࠧࠨ唭"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ售")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ唯")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ唰")					all l1l1l11l_l1_ & l1llll11l1_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠫࡂࠬࠧ唱"),l11l1l_l1_ (u"ࠬࡃ࠰ࠧࠩ唲"))
	filters = filters.strip(l11l1l_l1_ (u"࠭ࠦࠨ唳"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"ࠧ࠾ࠩ唴") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠨࠨࠪ唵"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠩࡀࠫ唶"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠪࠫ唷")
	for key in l11ll111lll1_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠫ࠵࠭唸")
		if l11l1l_l1_ (u"ࠬࠫࠧ唹") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ唺") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ唻"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠢ࠮ࠤࠬ唼")+value
		elif mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ唽") and value!=l11l1l_l1_ (u"ࠪ࠴ࠬ唾"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭唿")+key+l11l1l_l1_ (u"ࠬࡃࠧ啀")+value
		elif mode==l11l1l_l1_ (u"࠭ࡡ࡭࡮ࠪ啁"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠧࠧࠩ啂")+key+l11l1l_l1_ (u"ࠨ࠿ࠪ啃")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠩࠣ࠯ࠥ࠭啄"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬ啅"))
	l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠫࡂ࠶ࠧ商"),l11l1l_l1_ (u"ࠬࡃࠧ啇"))
	return l1ll111l_l1_
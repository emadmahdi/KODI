# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
headers = { l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨহ") : l11l1l_l1_ (u"ࠬ࠭঺") }
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ঻")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡃࡎࡇࡤ়࠭")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
#l11ll11_l1_ = [l11l1l_l1_ (u"ࠨใํ่๊࠭ঽ"),l11l1l_l1_ (u"ࠩๆ่๏ฮࠧা"),l11l1l_l1_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫি"),l11l1l_l1_ (u"ู๊ࠫัฮ์ฬࠫী"),l11l1l_l1_ (u"๋ࠬำาฯํ๋ࠬু"),l11l1l_l1_ (u"࠭ว฻่ํอࠬূ"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭ৃ"),l11l1l_l1_ (u"ࠨๆๅหฦ࠭ৄ")]
#proxy = l11l1l_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱࠴࠹࠾࠴࠲࠱࠵࠱࠼࠼࠴࠱࠴࠲࠽࠷࠶࠸࠸ࠨ৅")
#proxy = l11l1l_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ৆")+l11l1l1l_l1_[6][1]
#l1l111_l1_ = [l11l1l_l1_ (u"ࠫอืวๆฮࠪে"),l11l1l_l1_ (u"ࠬษไฺษหࠫৈ"),l11l1l_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧ৉"),l11l1l_l1_ (u"ࠧศๆฦะ์ุษࠡษ็่ํำ๊สࠩ৊"),l11l1l_l1_ (u"ࠨษ็็ํืำศฬࠣห้ะูๅ์่๎ฮ࠭ো"),l11l1l_l1_ (u"ࠩหีฬ๋ฬࠡษ็ฮฺ๋๊ๆࠩৌ"),l11l1l_l1_ (u"ࠪห้฿วษࠢๅฮฬ্๊ࠧ"),l11l1l_l1_ (u"ࠫฬู๊ศสࠣห้้ๅษ์๋ฮึࠦࡐࡄࠩৎ"),l11l1l_l1_ (u"ࠬอไษำส้ั࠭৏")]
l1l111_l1_ = [l11l1l_l1_ (u"࠭ๅึษิ฽ฮ࠭৐")]
def MAIN(mode,url,text):
	if   mode==350: results = MENU(url)
	elif mode==351: results = l1lllll_l1_(url,text)
	elif mode==352: results = l1lll1ll_l1_(url)
	elif mode==353: results = PLAY(url)
	elif mode==354: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ৑")+text)
	elif mode==355: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ৒")+text)
	elif mode==356: results = l1l1ll1l_l1_(url)
	elif mode==357: results = l11l1l11_l1_(url)
	elif mode==359: results = SEARCH(text)
	else: results = False
	return results
def MENU(l1l1l111_l1_=l11l1l_l1_ (u"ࠩࠪ৓")):
	if l1l1l111_l1_==l11l1l_l1_ (u"ࠪࠫ৔"):
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ৕"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ৖"),l11l1l_l1_ (u"࠭ࠧৗ"),8)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ৘"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ৙"),l11l1l_l1_ (u"ࠩࠪ৚"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ৛"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫড়"),l11l1l_l1_ (u"ࠬ࠭ঢ়"),359,l11l1l_l1_ (u"࠭ࠧ৞"),l11l1l_l1_ (u"ࠧࠨয়"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬৠ"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩৡ"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ৢ"),l11l11_l1_,356)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫৣ"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ৤"),l11l11_l1_,357)
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ৥"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ০"),l11l1l_l1_ (u"ࠨࠩ১"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ২"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ৩")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅำ์าࠫ৪"),l11l11_l1_,352,l11l1l_l1_ (u"ࠬ࠭৫"),l11l1l_l1_ (u"࠭ࠧ৬"),l11l1l_l1_ (u"ࠧ࡮ࡱࡵࡩࠬ৭"))
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ৮"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ৯")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้อฮษษิࠫৰ"),l11l11_l1_,352,l11l1l_l1_ (u"ࠫࠬৱ"),l11l1l_l1_ (u"ࠬ࠭৲"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡶࠫ৳"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ৴"),headers,l11l1l_l1_ (u"ࠨࠩ৵"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭৶"))
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡶࡪࡩࡥ࡯ࡶ࡯ࡽ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৷"),html,re.DOTALL)
	if l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_[0]
	else: l111ll1_l1_ = l11l11_l1_
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ৸"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ৹")+l1111l_l1_+l11l1l_l1_ (u"࠭วื์ไࠤาี๊ฬษࠪ৺"),l111ll1_l1_,351)
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡁ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৻"),html,re.DOTALL)
	if l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_[0]
	else: l111ll1_l1_ = l11l11_l1_
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨৼ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ৽")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ৾"),l111ll1_l1_,351,l11l1l_l1_ (u"ࠫࠬ৿"),l11l1l_l1_ (u"ࠬ࠭਀"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨਁ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠫਂ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡳࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪਃ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title not in l1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ਄"),l1111l_l1_+title,l1llll1_l1_,351)
		if l1l1l111_l1_==l11l1l_l1_ (u"ࠪࠫਅ"): addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩਆ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬਇ"),l11l1l_l1_ (u"࠭ࠧਈ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡧࡵࡸࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷ࠭ਉ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫਊ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			if title not in l1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ਋"),l1111l_l1_+title,l1llll1_l1_,351)
	return html
def l1l1ll1l_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠪࠫ਌")):
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ਍"),headers,l11l1l_l1_ (u"ࠬ࠭਎"),l11l1l_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪਏ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧਐ"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ਑"),l11l1l_l1_ (u"ࠩࠪ਒"),l1llll1_l1_,l1l11ll_l1_][0])
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਓ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬਔ"),l11l1l_l1_ (u"ࠬ࠭ਕ"),l1llll1_l1_,title)
			if title not in l1l111_l1_:
				title = title+l11l1l_l1_ (u"࠭ࠠๆื้ๅฮ࠭ਖ")
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧਗ"),l1111l_l1_+title,l1llll1_l1_,355)
		if l1l1l111_l1_==l11l1l_l1_ (u"ࠨࠩਘ"): addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧਙ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਚ"),l11l1l_l1_ (u"ࠫࠬਛ"),9999)
	return html
def l11l1l11_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠬ࠭ਜ")):
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"࠭ࠧਝ"),headers,l11l1l_l1_ (u"ࠧࠨਞ"),l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬਟ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩਠ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਡ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title not in l1l111_l1_:
				title = title+l11l1l_l1_ (u"๋ࠫࠥแๅฬิอࠬਢ")
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਣ"),l1111l_l1_+title,l1llll1_l1_,354)
		if l1l1l111_l1_==l11l1l_l1_ (u"࠭ࠧਤ"): addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬਥ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨਦ"),l11l1l_l1_ (u"ࠩࠪਧ"),9999)
	return html
def l1lllll_l1_(url,type=l11l1l_l1_ (u"ࠪࠫਨ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ਩"),l11l1l_l1_ (u"ࠬ࠭ਪ"),url,type)
	html = OPENURL_CACHED(NO_CACHE,url,l11l1l_l1_ (u"࠭ࠧਫ"),headers,True,l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ਬ"))
	if type==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪਭ"): l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧਮ"),html,re.DOTALL)
	else: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩਯ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡽࡲࡩ࡯࡭࠽࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਰ"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭਱"),l11l1l_l1_ (u"࠭ࠧਲ"),str(len(block)),url)
		l11l_l1_ = []
		for l1ll1l_l1_,l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			if l11l1l_l1_ (u"ࠧศๆะ่็ฯࠧਲ਼") in title or l11l1l_l1_ (u"ࠨษ็ั้่็ࠨ਴") in title:
				l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧਵ"),title,re.DOTALL)
				if l1ll1l1_l1_:
					title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩਸ਼") + l1ll1l1_l1_[0][0]
					if title not in l11l_l1_:
						addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ਷"),l1111l_l1_+title,l1llll1_l1_,352,l1ll1l_l1_)
						l11l_l1_.append(title)
			elif l11l1l_l1_ (u"๋ࠬำๅี็ࠫਸ") in title:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਹ"),l1111l_l1_+title,l1llll1_l1_,352,l1ll1l_l1_)
			else: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭਺"),l1111l_l1_+title,l1llll1_l1_,353,l1ll1l_l1_)
			#if l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ਻") in l1llll1_l1_ or l11l1l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡷࡴ࠱਼ࠪ") in l1llll1_l1_:
			#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ਽"),l1111l_l1_+title,l1llll1_l1_,352,l1ll1l_l1_)
			#elif l11l1l_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨਾ") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠬ࠵ࡧࡢ࡯ࡨࡷ࠴࠭ਿ") not in l1llll1_l1_:
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧੀ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪੁ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"ࠨࠨ࡯ࡷࡦࡷࡵࡰ࠽ࠪੂ") in title: title = l11l1l_l1_ (u"ุࠩๅาฯࠠิษหๆฮ࠭੃")
			#if l11l1l_l1_ (u"ࠪࠪࡷࡹࡡࡲࡷࡲ࠿ࠬ੄") in title: title = l11l1l_l1_ (u"ฺࠫ็อสࠢ็หา่ษࠨ੅")
			#if l11l1l_l1_ (u"ࠬࠬ࡬ࡢࡳࡸࡳࠬ੆") in title: title = l11l1l_l1_ (u"࠭วๅืไัฮࠦวๅฬส่๏ฯࠧੇ")
			#if l11l1l_l1_ (u"ࠧึใะอࠬੈ") not in title: title = l11l1l_l1_ (u"ࠨืไัฮࠦࠧ੉")+title
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੊"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩੋ")+title,l1llll1_l1_,351)
	return
def SEARCH(search):
	# https://l11l1ll1_l1_.net/search?q=%l11l1lll_l1_%l1l1l1l1_l1_%l11l1lll_l1_%l1ll1111_l1_%l11l1lll_l1_%l1l11ll1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬੌ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"੍ࠬ࠭"): return
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ੎"),l11l1l_l1_ (u"ࠧࠬࠩ੏"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭੐")+l1111l1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪੑ"),l11l1l_l1_ (u"ࠪࠫ੒"),url,l11l1l_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࡣࡆࡑࡏࡂࡏࠪ੓"))
	results = l1lllll_l1_(url)
	return
def l1lll1ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭੔"),l11l1l_l1_ (u"࠭ࠧ੕"),url,l11l1l_l1_ (u"ࠧࡆࡒࡌࡗࡔࡊࡅࡔࡡࡄࡏ࡜ࡇࡍࠨ੖"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ੗"),headers,True,l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ੘"))
	#if l11l1l_l1_ (u"ࠪ࠱ࡪࡶࡩࡴࡱࡧࡩࡸ࠭ਖ਼") not in html:
	#	l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫਗ਼"))
	#	addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫਜ਼"),l1111l_l1_+l11l1l_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬੜ"),url,353,l1ll1l_l1_)
	#else:
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃอไฮๆๅหฯ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࠫ੝"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਫ਼"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in l11ll_l1_:
			if l11l1l_l1_ (u"ࠩส่า๊โสࠩ੟") in title or l11l1l_l1_ (u"ࠪห้ำไใ้ࠪ੠") in title: addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ੡"),l1111l_l1_+title,l1llll1_l1_,353,l1ll1l_l1_)
			#else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ੢"),l1111l_l1_+title,l1llll1_l1_,352,l1ll1l_l1_)
	else:
		l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡋࡦࡳࡳ࠭੣"))
		if html.count(l11l1l_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠨ੤"))>1: title = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ੥"),html,re.DOTALL)[1]
		else: title = l11l1l_l1_ (u"ࠩิหอ฽ࠠศๆอุ฿๐ไࠨ੦")
		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ੧"),l1111l_l1_+title,url,353,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1ll1lll_l1_ = [],[]
	l1ll1l11_l1_ = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ੨"),url,l11l1l_l1_ (u"ࠬ࠭੩"),l11l1l_l1_ (u"࠭ࠧ੪"),l11l1l_l1_ (u"ࠧࠨ੫"),l11l1l_l1_ (u"ࠨࠩ੬"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭੭"))
	html = l1ll1l11_l1_.content
	l11ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫ੮"),html,re.DOTALL)
	if l11ll1l1_l1_:
		l11ll1l1_l1_ = l11ll1l1_l1_[0]
		headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੯"):l11l1l_l1_ (u"ࠬ࠭ੰ"),l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬੱ"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ੲ")}
		data = {l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩੳ"):l11ll1l1_l1_}
		l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡝ࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨੴ")
		l11lllll_l1_ = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨੵ"),l111ll1_l1_,data,headers,l11l1l_l1_ (u"ࠫࠬ੶"),l11l1l_l1_ (u"ࠬ࠭੷"),l11l1l_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ੸"))
		l11ll11l_l1_ = l11lllll_l1_.content
		items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ੹"),l11ll11l_l1_,re.DOTALL)
		for l11lll11_l1_,name in items:
			#data = {l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩ੺"):l11ll1l1_l1_,l11l1l_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ੻"):l11lll11_l1_}
			l1llll1_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ੼")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭੽")+l11ll1l1_l1_+l11l1l_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ੾")+l11lll11_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ੿")+name+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ઀")
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1lll_l1_.append(name)
		l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪઁ")
		l11lllll_l1_ = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧં"),l111ll1_l1_,data,headers,l11l1l_l1_ (u"ࠪࠫઃ"),l11l1l_l1_ (u"ࠫࠬ઄"),l11l1l_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩઅ"))
		l11ll11l_l1_ = l11lllll_l1_.content
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭આ"),l11ll11l_l1_,re.DOTALL)
		for l1llll1_l1_,title in items:
			#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨઇ"),l11l1l_l1_ (u"ࠨࠩઈ"),l1llll1_l1_,title)
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩࠣࠫઉ"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫઊ")+title+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨઋ")
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1lll_l1_.append(title)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫઌ"),url)
	return
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨઍ"),l11l1l_l1_ (u"ࠧࠨ઎"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩએ"),l11l1l_l1_ (u"ࠩࠪઐ"),filter,url)
	l1l111ll_l1_ = [l11l1l_l1_ (u"ࠪࡧࡦࡺࠧઑ"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ઒"),l11l1l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫઓ"),l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧઔ"),l11l1l_l1_ (u"ࠧࡰࡴࡧࡩࡷࡨࡹࠨક")]
	if l11l1l_l1_ (u"ࠨࡁࠪખ") in url: url = url.split(l11l1l_l1_ (u"ࠩࡂࠫગ"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠪࡣࡤࡥࠧઘ"),1)
	if filter==l11l1l_l1_ (u"ࠫࠬઙ"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠬ࠭ચ"),l11l1l_l1_ (u"࠭ࠧછ")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫજ"))
	if type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬઝ"):
		if l1l111ll_l1_[0]+l11l1l_l1_ (u"ࠩࡀࠫઞ") not in l1l1111l_l1_: category = l1l111ll_l1_[0]
		for i in range(len(l1l111ll_l1_[0:-1])):
			if l1l111ll_l1_[i]+l11l1l_l1_ (u"ࠪࡁࠬટ") in l1l1111l_l1_: category = l1l111ll_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭ઠ")+category+l11l1l_l1_ (u"ࠬࡃ࠰ࠨડ")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨઢ")+category+l11l1l_l1_ (u"ࠧ࠾࠲ࠪણ")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠪત"))+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭થ")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬદ"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠫࡦࡲ࡬ࠨધ"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠬࡅࠧન")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ઩"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩપ"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠨࠩફ"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭બ"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠪࠫભ"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫࡄ࠭મ")+l1l11111_l1_
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬય"),l1111l_l1_+l11l1l_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠨર"),l111ll1_l1_,351,l11l1l_l1_ (u"ࠧࠨ઱"),l11l1l_l1_ (u"ࠨ࠳ࠪલ"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩળ"),l1111l_l1_+l11l1l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ઴")+l11ll111_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪવ"),l111ll1_l1_,351,l11l1l_l1_ (u"ࠬ࠭શ"),l11l1l_l1_ (u"࠭࠱ࠨષ"))
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬસ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨહ"),l11l1l_l1_ (u"ࠩࠪ઺"),9999)
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠪࠫ઻"),headers,True,l11l1l_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵ઼ࠩ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡦࡰࡴࡰࠤ࡮ࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡦࡰࡴࡰࡂࠬઽ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺ࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬા"),block,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨિ"),l11l1l_l1_ (u"ࠨࠩી"),l11l1l_l1_ (u"ࠩࠪુ"),str(l1ll1l1l_l1_))
	dict = {}
	for l1ll11ll_l1_,name,block in l1ll1l1l_l1_:
		#name = name.replace(l11l1l_l1_ (u"ࠪ࠱࠲࠭ૂ"),l11l1l_l1_ (u"ࠫࠬૃ"))
		items = re.findall(l11l1l_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡂ࠭࠴ࠪࡀࠫ࠿ࠫૄ"),block,re.DOTALL)
		if l11l1l_l1_ (u"࠭࠽ࠨૅ") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ૆"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<=1:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: l1lllll_l1_(l111ll1_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨે")+l1l11l1l_l1_)
				return
			else:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩૈ"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้าๅ๋฻ࠪૉ"),l111ll1_l1_,351,l11l1l_l1_ (u"ࠫࠬ૊"),l11l1l_l1_ (u"ࠬ࠷ࠧો"))
				else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ૌ"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿્ࠧ"),l111ll1_l1_,355,l11l1l_l1_ (u"ࠨࠩ૎"),l11l1l_l1_ (u"ࠩࠪ૏"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫૐ"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭૑")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠬࡃ࠰ࠨ૒")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨ૓")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ૔")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ૕")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ૖"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠥ࠭૗")+name,l111ll1_l1_,354,l11l1l_l1_ (u"ࠫࠬ૘"),l11l1l_l1_ (u"ࠬ࠭૙"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ૚"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if option in l1l111_l1_: continue
			if l11l1l_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭૛") not in value: value = option
			else: value = re.findall(l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩࠣࠩ૜"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࠫ૝")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠪࡁࠬ૞")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭૟")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠬࡃࠧૠ")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪૡ")+l1l1l1ll_l1_
			title = option+l11l1l_l1_ (u"ࠧࠡ࠼ࠣࠫૢ")#+dict[l1ll11ll_l1_][l11l1l_l1_ (u"ࠨ࠲ࠪૣ")]
			title = option+l11l1l_l1_ (u"ࠩࠣ࠾ࠥ࠭૤")+name
			if type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ૥"): addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ૦"),l1111l_l1_+title,url,354,l11l1l_l1_ (u"ࠬ࠭૧"),l11l1l_l1_ (u"࠭ࠧ૨"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ૩"))
			elif type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ૪") and l1l111ll_l1_[-2]+l11l1l_l1_ (u"ࠩࡀࠫ૫") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ૬"))
				l111lll_l1_ = url+l11l1l_l1_ (u"ࠫࡄ࠭૭")+l11lll1l_l1_
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૮"),l1111l_l1_+title,l111lll_l1_,351,l11l1l_l1_ (u"࠭ࠧ૯"),l11l1l_l1_ (u"ࠧ࠲ࠩ૰"))
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૱"),l1111l_l1_+title,url,355,l11l1l_l1_ (u"ࠩࠪ૲"),l11l1l_l1_ (u"ࠪࠫ૳"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ૴"),l11l1l_l1_ (u"ࠬ࠭૵"),filters,l11l1l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧ૶"))
	# mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ૷")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ૸")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭ૹ")					all filters (l11ll1ll_l1_ l1l1l11l_l1_ filter)
	#filters = filters.replace(l11l1l_l1_ (u"ࠪࡁࠫ࠭ૺ"),l11l1l_l1_ (u"ࠫࡂ࠶ࠦࠨૻ"))
	filters = filters.strip(l11l1l_l1_ (u"ࠬࠬࠧૼ"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"࠭࠽ࠨ૽") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠧࠧࠩ૾"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠨ࠿ࠪ૿"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠩࠪ଀")
	l1l1llll_l1_ = [l11l1l_l1_ (u"ࠪࡧࡦࡺࠧଁ"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪଂ"),l11l1l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫଃ"),l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ଄"),l11l1l_l1_ (u"ࠧࡰࡴࡧࡩࡷࡨࡹࠨଅ")]
	for key in l1l1llll_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠨ࠲ࠪଆ")
		#if l11l1l_l1_ (u"ࠩࠨࠫଇ") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬଈ") and value!=l11l1l_l1_ (u"ࠫ࠵࠭ଉ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠦࠫࠡࠩଊ")+value
		elif mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩଋ") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩଌ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠨࠪ଍")+key+l11l1l_l1_ (u"ࠩࡀࠫ଎")+value
		elif mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧଏ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭ଐ")+key+l11l1l_l1_ (u"ࠬࡃࠧ଑")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠬࠢࠪ଒"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩଓ"))
	#l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠨ࠿࠳ࠫଔ"),l11l1l_l1_ (u"ࠩࡀࠫକ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫଖ"),l11l1l_l1_ (u"ࠫࠬଗ"),filters,l11l1l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ଘ"))
	return l1ll111l_l1_
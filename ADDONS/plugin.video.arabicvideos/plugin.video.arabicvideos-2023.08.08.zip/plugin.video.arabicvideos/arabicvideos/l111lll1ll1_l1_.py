# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ䀜")
headers = {l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䀝"):l11l1l_l1_ (u"࠭ࠧ䀞")}
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭䀟")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ䀠"),l11l1l_l1_ (u"ࠩࡺࡻࡪ࠭䀡")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1lllll_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1lll1ll_l1_(url,text)
	elif mode==364: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ䀢")+text)
	elif mode==365: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ䀣")+text)
	elif mode==366: results = l11lll_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䀤"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ䀥"),l11l1l_l1_ (u"ࠧࠨ䀦"),False,l11l1l_l1_ (u"ࠨࠩ䀧"),l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䀨"))
	#hostname = response.headers[l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䀩")]
	#hostname = hostname.strip(l11l1l_l1_ (u"ࠫ࠴࠭䀪"))
	#l1l1lll_l1_ = l11l11_l1_
	#url = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䀫")
	#url = l1l1lll_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䀬"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ䀭"),l11l1l_l1_ (u"ࠨࠩ䀮"),l11l1l_l1_ (u"ࠩࠪ䀯"),l11l1l_l1_ (u"ࠪࠫ䀰"),l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䀱"))
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䀲"),l1111l_l1_+l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้ำหࠥอไๆ๊ๅ฽ฺ๋ࠥๅไ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀳"),l11l1l_l1_ (u"ࠧࠨ䀴"),8)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䀵"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䀶"),l11l1l_l1_ (u"ࠪࠫ䀷"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䀸"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䀹"),l11l11_l1_,369,l11l1l_l1_ (u"࠭ࠧ䀺"),l11l1l_l1_ (u"ࠧࠨ䀻"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䀼"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀽"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭䀾"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䀿"),364)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁀"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䁁"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䁂"),365)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䁃"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䁄"),l11l1l_l1_ (u"ࠪࠫ䁅"),9999)
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䁆"):hostname,l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䁇"):l11l1l_l1_ (u"࠭ࠧ䁈")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11l1l_l1_ (u"ࠧ࡝࠱ࠪ䁉"),l11l1l_l1_ (u"ࠨ࠱ࠪ䁊"))
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࡣࡣࡵࠬ࠳࠰࠿ࠪࡨ࡬ࡰࡹ࡫ࡲࠨ䁋"),html,re.DOTALL)
	#if l1l11ll_l1_:
	#	block = l1l11ll_l1_[0]
	#	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䁌"),block,re.DOTALL)
	#	for l1llll1_l1_,title in items:
	#		if l11l1l_l1_ (u"ࠫࠪࡪ࠹ࠦ࠺࠸ࠩࡩ࠾ࠥࡣ࠷ࠨࡨ࠽ࠫࡡ࠸ࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡧ࠿ࠥࡥ࠺ࠨࡥ࠾࠳ࠥࡥ࠺ࠨࡥࡩࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡣ࠼ࠫ䁍") in l1llll1_l1_: continue
	#		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁎"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䁏")+l1111l_l1_+title,l1llll1_l1_,366)
	#	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䁐"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䁑"),l11l1l_l1_ (u"ࠩࠪ䁒"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䁓"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ䁔"),l11l1l_l1_ (u"ࠬ࠭䁕"),l11l1l_l1_ (u"࠭ࠧ䁖"),l11l1l_l1_ (u"ࠧࠨ䁗"),l11l1l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ䁘"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡒࡵࡳࡩࡻࡣࡵ࡫ࡲࡲࡸࡒࡩࡴࡶࡅࡹࡹࡺ࡯࡯ࠤࠪ䁙"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁚"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䁛") not in l1llll1_l1_:
			#	server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䁜"))
			#	l1llll1_l1_ = l1llll1_l1_.replace(server,l1l1lll_l1_)
			if title==l11l1l_l1_ (u"࠭ࠧ䁝"): continue
			if any(value in title.lower() for value in l1l111_l1_): continue
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁞"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䁟")+l1111l_l1_+title,l1llll1_l1_,366)
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䁠"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䁡"),l11l1l_l1_ (u"ࠫࠬ䁢"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠧ䁣"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䁤"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁥"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䁦")+l1111l_l1_+title,l1llll1_l1_,366,l1ll1l_l1_)
	return html
def l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䁧"),l11l1l_l1_ (u"ࠪࠫ䁨"),url,l11l1l_l1_ (u"ࠫࠬ䁩"))
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䁪"):url,l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䁫"):l11l1l_l1_ (u"ࠧࠨ䁬")}
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䁭"),url,l11l1l_l1_ (u"ࠩࠪ䁮"),l11l1l_l1_ (u"ࠪࠫ䁯"),l11l1l_l1_ (u"ࠫࠬ䁰"),l11l1l_l1_ (u"ࠬ࠭䁱"),l11l1l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䁲"))
	html = response.content
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁳"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ䁴"),url,364)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䁵"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭䁶"),url,365)
	if l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ䁷") in html:
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁸"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็่๎ืฯࠧ䁹"),url,361,l11l1l_l1_ (u"ࠧࠨ䁺"),l11l1l_l1_ (u"ࠨࠩ䁻"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䁼"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䁽"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁾"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁿"),l1111l_l1_+title,l1llll1_l1_,361)
	return
def l1lllll_l1_(l111lll1lll_l1_,type=l11l1l_l1_ (u"࠭ࠧ䂀")):
	if l11l1l_l1_ (u"ࠧ࠻࠼ࠪ䂁") in l111lll1lll_l1_:
		l111lll_l1_,url = l111lll1lll_l1_.split(l11l1l_l1_ (u"ࠨ࠼࠽ࠫ䂂"))
		server = SERVER(l111lll_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䂃"))
		url = server+url
	else: url,l111lll_l1_ = l111lll1lll_l1_,l111lll1lll_l1_
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䂄"):l111lll_l1_,l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䂅"):l11l1l_l1_ (u"ࠬ࠭䂆")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䂇"),url,l11l1l_l1_ (u"ࠧࠨ䂈"),l11l1l_l1_ (u"ࠨࠩ䂉"),l11l1l_l1_ (u"ࠩࠪ䂊"),l11l1l_l1_ (u"ࠪࠫ䂋"),l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䂌"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䂍"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ䂎"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䂏"):
		l1l11ll_l1_ = [html.replace(l11l1l_l1_ (u"ࠨ࡞࡟࠳ࠬ䂐"),l11l1l_l1_ (u"ࠩ࠲ࠫ䂑")).replace(l11l1l_l1_ (u"ࠪࡠࡡࠨࠧ䂒"),l11l1l_l1_ (u"ࠫࠧ࠭䂓"))]
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡍࡲࡪࡦ࠰࠱ࡒࡿࡣࡪ࡯ࡤࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䂔"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡇࡳ࡫ࡧࡍࡹ࡫࡭ࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ䂕"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l1l111_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11l1l_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䂖"),l11l1l_l1_ (u"ࠨࠩ䂗"))
			if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䂘") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂙"),l1111l_l1_+title,l1llll1_l1_,363,l1ll1l_l1_)
			elif l11l1l_l1_ (u"ࠫา๊โสࠩ䂚") in title:
				l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠰ำไใหࠣ࠯ࡡࡪࠫࠨ䂛"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䂜") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂝"),l1111l_l1_+title,l1llll1_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䂞"),l1111l_l1_+title,l1llll1_l1_,362,l1ll1l_l1_)
		if type==l11l1l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䂟"):
			l1ll11lll11_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ䂠"),block,re.DOTALL)
			if l1ll11lll11_l1_:
				count = l1ll11lll11_l1_[0]
				l1llll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭䂡")+count
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂢"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ䂣"),l1llll1_l1_,361,l11l1l_l1_ (u"ࠧࠨ䂤"),l11l1l_l1_ (u"ࠨࠩ䂥"),l11l1l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䂦"))
		elif type==l11l1l_l1_ (u"ࠪࠫ䂧"):
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䂨"),html,re.DOTALL)
			if l1l11ll_l1_:
				block = l1l11ll_l1_[0]
				items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䂩"),block,re.DOTALL)
				for l1llll1_l1_,title in items:
					title = l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ䂪")+unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂫"),l1111l_l1_+title,l1llll1_l1_,361)
	return
def l1lll1ll_l1_(url,type=l11l1l_l1_ (u"ࠨࠩ䂬")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䂭"),url,l11l1l_l1_ (u"ࠪࠫ䂮"),l11l1l_l1_ (u"ࠫࠬ䂯"),l11l1l_l1_ (u"ࠬ࠭䂰"),l11l1l_l1_ (u"࠭ࠧ䂱"),l11l1l_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䂲"))
	html = response.content
	html = l1llll_l1_(html)
	name = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭䂳"),html,re.DOTALL)
	if name: name = name[-1].replace(l11l1l_l1_ (u"ࠩ࠰ࠫ䂴"),l11l1l_l1_ (u"ࠪࠤࠬ䂵")).strip(l11l1l_l1_ (u"ࠫ࠴࠭䂶"))
	if l11l1l_l1_ (u"๋่ࠬิ็ࠪ䂷") in name and type==l11l1l_l1_ (u"࠭ࠧ䂸"):
		name = name.split(l11l1l_l1_ (u"ࠧๆ๊ึ้ࠬ䂹"))[0]
		name = name.replace(l11l1l_l1_ (u"ࠨ็ืห์ีษࠨ䂺"),l11l1l_l1_ (u"ࠩࠪ䂻")).strip(l11l1l_l1_ (u"ࠪࠤࠬ䂼"))
	elif l11l1l_l1_ (u"ࠫา๊โสࠩ䂽") in name:
		name = name.split(l11l1l_l1_ (u"ࠬำไใหࠪ䂾"))[0]
		name = name.replace(l11l1l_l1_ (u"࠭ๅีษ๊ำฮ࠭䂿"),l11l1l_l1_ (u"ࠧࠨ䃀")).strip(l11l1l_l1_ (u"ࠨࠢࠪ䃁"))
	else: name = name
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳ࠭䃂"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		if type==l11l1l_l1_ (u"ࠪࠫ䃃"):
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䃄"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࠫ䃅") in title: continue
				if l11l1l_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ䃆") in title: continue
				title = name+l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ䃇")+title
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃈"),l1111l_l1_+title,l1llll1_l1_,363,l11l1l_l1_ (u"ࠩࠪ䃉"),l11l1l_l1_ (u"ࠪࠫ䃊"),l11l1l_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䃋"))
		if len(menuItemsLIST)==0:
			l1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠪࠫ࠭䃌"),block+l11l1l_l1_ (u"࠭ࠦࠧࠩ䃍"),re.DOTALL)
			if l1ll111_l1_: block = l1ll111_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䃎"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ䃏"))
				title = name+l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭䃐")+title
				addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䃑"),l1111l_l1_+title,l1llll1_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11l1l_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䃒"),html,re.DOTALL)
		if title: title = title[0].replace(l11l1l_l1_ (u"ࠬࠦ࠭ࠡ็ส๎ู๊ࠥๆษࠪ䃓"),l11l1l_l1_ (u"࠭ࠧ䃔")).replace(l11l1l_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䃕"),l11l1l_l1_ (u"ࠨࠩ䃖"))
		else: title = l11l1l_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ䃗")
		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䃘"),l1111l_l1_+title,url,362)
	return
def PLAY(url):
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䃙"),url,l11l1l_l1_ (u"ࠬ࠭䃚"),l11l1l_l1_ (u"࠭ࠧ䃛"),l11l1l_l1_ (u"ࠧࠨ䃜"),l11l1l_l1_ (u"ࠨࠩ䃝"),l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䃞"))
	html = response.content
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀส่ฯ฻ๆ๋ใ࠿࠲࠯ࡅ࠼ࡢ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䃟"),html,re.DOTALL)
	if l11l1l1_l1_:
		l11l1l1_l1_ = [l11l1l1_l1_[0][0],l11l1l1_l1_[0][1]]
		if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡉࡲࡨࡥࡥࠤࠪ䃠"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䃡"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䃢") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if name==l11l1l_l1_ (u"ࠧิ์ิๅึࠦๅศ์ࠣื๏๋วࠨ䃣"): name = l11l1l_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䃤")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䃥")+name+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䃦")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯ࡳࡵ࠯࠰ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䃧"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䃨"),block,re.DOTALL)
		for l1llll1_l1_,l111ll1l_l1_ in items:
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䃩") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ䃪"),l111ll1l_l1_,re.DOTALL)
			if l111ll1l_l1_: l111ll1l_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭䃫")+l111ll1l_l1_[0]
			else: l111ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪ䃬")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡱࡾࡩࡩ࡮ࡣࠪ䃭")+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䃮")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䃯"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䃰"),url)
	return
def SEARCH(search,hostname=l11l1l_l1_ (u"ࠧࠨ䃱")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩ䃲"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪ䃳"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ䃴"),l11l1l_l1_ (u"ࠫ࠰࠭䃵"))
	l1lll1_l1_ = [l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ䃶"),l11l1l_l1_ (u"࠭࠯ࠨ䃷"),l11l1l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡳࡦࡴ࡬ࡩࡸ࠭䃸"),l11l1l_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡢࡰ࡬ࡱࡪ࠭䃹"),l11l1l_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡶࡹࠫ䃺")]
	l1l111lll_l1_ = [l11l1l_l1_ (u"ࠪห้้ไࠨ䃻"),l11l1l_l1_ (u"ࠫฬ๊รโๆส้ࠬ䃼"),l11l1l_l1_ (u"ࠬอไๆี็ื้อสࠨ䃽"),l11l1l_l1_ (u"࠭วๅษ้๎๊๐้ࠠࠢส่่ืส้่ࠪ䃾"),l11l1l_l1_ (u"ࠧศๆหีฬ๋ฬࠡฬ็๎ๆุ๊้่ํอࠬ䃿")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ䄀"), l1l111lll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11l1l_l1_ (u"ࠩࠪ䄁"):
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䄂"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ䄃"),l11l1l_l1_ (u"ࠬ࠭䄄"),False,l11l1l_l1_ (u"࠭ࠧ䄅"),l11l1l_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䄆"))
		hostname = response.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䄇")]
		hostname = hostname.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ䄈"))
	l111ll1_l1_ = hostname+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ䄉")+search+l1lll1_l1_[l1l_l1_]
	l1lllll_l1_(l111ll1_l1_)
	return
def l1ll1ll1_l1_(l111lll1lll_l1_,filter):
	if l11l1l_l1_ (u"ࠫࡄࡅࠧ䄊") in l111lll1lll_l1_: url = l111lll1lll_l1_.split(l11l1l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䄋"))[0]
	else: url = l111lll1lll_l1_
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䄌"):l111lll1lll_l1_,l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䄍"):l11l1l_l1_ (u"ࠨࠩ䄎")}
	filter = filter.replace(l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䄏"),l11l1l_l1_ (u"ࠪࠫ䄐"))
	type,filter = filter.split(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ䄑"),1)
	if filter==l11l1l_l1_ (u"ࠬ࠭䄒"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"࠭ࠧ䄓"),l11l1l_l1_ (u"ࠧࠨ䄔")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ䄕"))
	if type==l11l1l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䄖"):
		if l1l1111l1_l1_[0]+l11l1l_l1_ (u"ࠪࡁࡂ࠭䄗") not in l1l1111l_l1_: category = l1l1111l1_l1_[0]
		for i in range(len(l1l1111l1_l1_[0:-1])):
			if l1l1111l1_l1_[i]+l11l1l_l1_ (u"ࠫࡂࡃࠧ䄘") in l1l1111l_l1_: category = l1l1111l1_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ䄙")+category+l11l1l_l1_ (u"࠭࠽࠾࠲ࠪ䄚")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪ䄛")+category+l11l1l_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䄜")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠪࠬ䄝"))+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ䄞")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠫࠫࠬࠧ䄟"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䄠"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䄡")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䄢"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䄣"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"ࠩࠪ䄤"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䄥"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠫࠬ䄦"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䄧")+l1l11111_l1_
		l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_,l111lll1lll_l1_)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄨"),l1111l_l1_+l11l1l_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ䄩"),l1lllll11_l1_,361,l11l1l_l1_ (u"ࠨࠩ䄪"),l11l1l_l1_ (u"ࠩࠪ䄫"),l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䄬"))
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䄭"),l1111l_l1_+l11l1l_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ䄮")+l11ll111_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ䄯"),l1lllll11_l1_,361,l11l1l_l1_ (u"ࠧࠨ䄰"),l11l1l_l1_ (u"ࠨࠩ䄱"),l11l1l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䄲"))
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄳"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䄴"),l11l1l_l1_ (u"ࠬ࠭䄵"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䄶"),url,l11l1l_l1_ (u"ࠧࠨ䄷"),l11l1l_l1_ (u"ࠨࠩ䄸"),l11l1l_l1_ (u"ࠩࠪ䄹"),l11l1l_l1_ (u"ࠪࠫ䄺"),l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䄻"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"ࠬࡢ࡜ࠣࠩ䄼"),l11l1l_l1_ (u"࠭ࠢࠨ䄽")).replace(l11l1l_l1_ (u"ࠧ࡝࡞࠲ࠫ䄾"),l11l1l_l1_ (u"ࠨ࠱ࠪ䄿"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ䅀"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䅁"),block+l11l1l_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䅂"),re.DOTALL)
	dict = {}
	for l1ll11ll_l1_,name,block in l1ll1l1l_l1_:
		name = escapeUNICODE(name)
		if l11l1l_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ䅃") in l1ll11ll_l1_: continue
		items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ䅄"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠧ࠾࠿ࠪ䅅") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䅆"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<=1:
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]: l1lllll_l1_(l111ll1_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ䅇")+l1l11l1l_l1_)
				return
			else:
				l1lllll11_l1_ = l11ll11ll_l1_(l111ll1_l1_,l111lll1lll_l1_)
				if l1ll11ll_l1_==l1l1111l1_l1_[-1]:
					addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䅈"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ䅉"),l1lllll11_l1_,361,l11l1l_l1_ (u"ࠬ࠭䅊"),l11l1l_l1_ (u"࠭ࠧ䅋"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䅌"))
				else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅍"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠩ䅎"),l111ll1_l1_,364,l11l1l_l1_ (u"ࠪࠫ䅏"),l11l1l_l1_ (u"ࠫࠬ䅐"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䅑"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"࠭ࠦࠧࠩ䅒")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾࠿࠳ࠫ䅓")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ䅔")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀࡁ࠵࠭䅕")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ䅖")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䅗"),l1111l_l1_+name+l11l1l_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ䅘"),l111ll1_l1_,365,l11l1l_l1_ (u"࠭ࠧ䅙"),l11l1l_l1_ (u"ࠧࠨ䅚"),l1l11l1l_l1_+l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䅛"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11l1l_l1_ (u"ࠩࡵࠫ䅜") or value==l11l1l_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ䅝"): continue
			if any(value in option.lower() for value in l1l111_l1_): continue
			if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䅞") in option: continue
			if l11l1l_l1_ (u"ࠬอไไๆࠪ䅟") in option: continue
			if l11l1l_l1_ (u"࠭࡮࠮ࡣࠪ䅠") in value: continue
			#if value in [l11l1l_l1_ (u"ࠧࡳࠩ䅡"),l11l1l_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䅢"),l11l1l_l1_ (u"ࠩࡷࡺ࠲ࡳࡡࠨ䅣")]: continue
			#if l1ll11ll_l1_==l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䅤"): option = value
			if option==l11l1l_l1_ (u"ࠫࠬ䅥"): option = value
			l11l11ll1_l1_ = option
			l1l1l1ll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ䅦"),option,re.DOTALL)
			if l1l1l1ll1ll_l1_: l11l11ll1_l1_ = l1l1l1ll1ll_l1_[0]
			l1lll11ll_l1_ = name+l11l1l_l1_ (u"࠭࠺ࠡࠩ䅧")+l11l11ll1_l1_
			dict[l1ll11ll_l1_][value] = l1lll11ll_l1_
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪ䅨")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠨ࠿ࡀࠫ䅩")+l11l11ll1_l1_
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬ䅪")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠪࡁࡂ࠭䅫")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ䅬")+l1l1l1ll_l1_
			if type==l11l1l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䅭"):
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅮"),l1111l_l1_+l1lll11ll_l1_,url,365,l11l1l_l1_ (u"ࠧࠨ䅯"),l11l1l_l1_ (u"ࠨࠩ䅰"),l1ll11l1_l1_+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䅱"))
			elif type==l11l1l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䅲") and l1l1111l1_l1_[-2]+l11l1l_l1_ (u"ࠫࡂࡃࠧ䅳") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䅴"))
				#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䅵"),l11l1l_l1_ (u"ࠧࠨ䅶"),l11lll1l_l1_,l1l1l1ll_l1_)
				l111lll_l1_ = url+l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䅷")+l11lll1l_l1_
				l1lllll11_l1_ = l11ll11ll_l1_(l111lll_l1_,l111lll1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅸"),l1111l_l1_+l1lll11ll_l1_,l1lllll11_l1_,361,l11l1l_l1_ (u"ࠪࠫ䅹"),l11l1l_l1_ (u"ࠫࠬ䅺"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䅻"))
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅼"),l1111l_l1_+l1lll11ll_l1_,url,364,l11l1l_l1_ (u"ࠧࠨ䅽"),l11l1l_l1_ (u"ࠨࠩ䅾"),l1ll11l1_l1_)
	return
l1l1111l1_l1_ = [l11l1l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ䅿"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䆀"),l11l1l_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ䆁")]
l11lllll1_l1_ = [l11l1l_l1_ (u"ࠬࡳࡰࡢࡣࠪ䆂"),l11l1l_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ䆃"),l11l1l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭䆄"),l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ䆅"),l11l1l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ䆆"),l11l1l_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䆇"),l11l1l_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ䆈"),l11l1l_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ䆉")]
def l11ll11ll_l1_(l111ll1_l1_,l111lll_l1_):
	if l11l1l_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䆊") in l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䆋"),l11l1l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ䆌"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䆍"),l11l1l_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ䆎"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠫࡂࡃࠧ䆏"),l11l1l_l1_ (u"ࠬ࠵ࠧ䆐"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"࠭ࠦࠧࠩ䆑"),l11l1l_l1_ (u"ࠧ࠰ࠩ䆒"))
	return l111ll1_l1_
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䆓"),l11l1l_l1_ (u"ࠩࠪ䆔"),filters,l11l1l_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ䆕")+mode)
	# mode==l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䆖")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䆗")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"࠭ࡡ࡭࡮ࠪ䆘")					all filters (l11ll1ll_l1_ l1l1l11l_l1_ filter)
	filters = filters.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ䆙"))
	l1l111l1_l1_,l1ll111l_l1_ = {},l11l1l_l1_ (u"ࠨࠩ䆚")
	if l11l1l_l1_ (u"ࠩࡀࡁࠬ䆛") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠪࠪࠫ࠭䆜"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠫࡂࡃࠧ䆝"))
			l1l111l1_l1_[var] = value
	for key in l11lllll1_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠬ࠶ࠧ䆞")
		if l11l1l_l1_ (u"࠭ࠥࠨ䆟") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䆠") and value!=l11l1l_l1_ (u"ࠨ࠲ࠪ䆡"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠩࠣ࠯ࠥ࠭䆢")+value
		elif mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䆣") and value!=l11l1l_l1_ (u"ࠫ࠵࠭䆤"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ䆥")+key+l11l1l_l1_ (u"࠭࠽࠾ࠩ䆦")+value
		elif mode==l11l1l_l1_ (u"ࠧࡢ࡮࡯ࠫ䆧"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ䆨")+key+l11l1l_l1_ (u"ࠩࡀࡁࠬ䆩")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠪࠤ࠰ࠦࠧ䆪"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠫࠫࠬࠧ䆫"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䆬"),l11l1l_l1_ (u"࠭ࠧ䆭"),l1ll111l_l1_,l11l1l_l1_ (u"ࠧࡐࡗࡗࠫ䆮"))
	return l1ll111l_l1_
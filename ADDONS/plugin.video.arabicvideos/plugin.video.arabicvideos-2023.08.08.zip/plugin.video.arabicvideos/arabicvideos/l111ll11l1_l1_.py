# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩᾖ")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡈࡗ࠽࡟ࠨᾗ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᾘ"),l11l1l_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬᾙ"),l11l1l_l1_ (u"ࠬะำอ์็ࠫᾚ")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l1lllll_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l1111_l1_(url,text)
	elif mode==684: results = l11lll_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᾛ"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨᾜ"),l11l1l_l1_ (u"ࠨࠩᾝ"),l11l1l_l1_ (u"ࠩࠪᾞ"),l11l1l_l1_ (u"ࠪࠫᾟ"),l11l1l_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᾠ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᾡ"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᾢ"),l11l1l_l1_ (u"ࠧࠨᾣ"),689,l11l1l_l1_ (u"ࠨࠩᾤ"),l11l1l_l1_ (u"ࠩࠪᾥ"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᾦ"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᾧ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᾨ"),l11l1l_l1_ (u"࠭ࠧᾩ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᾪ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᾫ")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊๋๊ำหࠪᾬ"),l11l11_l1_,681,l11l1l_l1_ (u"ࠪࠫᾭ"),l11l1l_l1_ (u"ࠫࠬᾮ"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᾯ"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾰ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᾱ")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧᾲ"),l11l11_l1_,681,l11l1l_l1_ (u"ࠩࠪᾳ"),l11l1l_l1_ (u"ࠪࠫᾴ"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ᾵"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᾶ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᾷ")+l1111l_l1_+l11l1l_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭Ᾰ"),l11l11_l1_,681,l11l1l_l1_ (u"ࠨࠩᾹ"),l11l1l_l1_ (u"ࠩࠪᾺ"),l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩΆ"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᾼ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᾽")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪι"),l11l11_l1_,681,l11l1l_l1_ (u"ࠧࠨ᾿"),l11l1l_l1_ (u"ࠨࠩ῀"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ῁"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨῂ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫῃ"),l11l1l_l1_ (u"ࠬ࠭ῄ"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ῅"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨῆ"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨῇ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫῈ")+l1111l_l1_+title,l1llll1_l1_,684)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨΈ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫῊ"),l11l1l_l1_ (u"ࠬ࠭Ή"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪῌ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ῍"),html,re.DOTALL)
	for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠨࠩ῎"))
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ῏"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῐ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ῑ")+l1111l_l1_+title,l1llll1_l1_,684)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩῒ"),url,l11l1l_l1_ (u"࠭ࠧΐ"),l11l1l_l1_ (u"ࠧࠨ῔"),l11l1l_l1_ (u"ࠨࠩ῕"),l11l1l_l1_ (u"ࠩࠪῖ"),l11l1l_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩῗ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨῘ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭Ῑ"),l11l1l_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬῚ"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫΊ"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠨࠩ῜"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ῝"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ῞"),l11l1l_l1_ (u"ࠫࠬ῟"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪῠ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"࠭࠺ࠡࠩῡ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧῢ"),l1111l_l1_+title,l1llll1_l1_,681)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬΰ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫῤ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨῥ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫῦ"),l11l1l_l1_ (u"ࠬ࠭ῧ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ῠ"),l1111l_l1_+title,l1llll1_l1_,681)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠧࠨῩ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩῪ"),l11l1l_l1_ (u"ࠩࠪΎ"),request,url)
	if request==l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨῬ"):
		url,search = url.split(l11l1l_l1_ (u"ࠫࡄ࠭῭"),1)
		data = l11l1l_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ΅")+search
		headers = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ`"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ῰")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭῱"),url,data,headers,l11l1l_l1_ (u"ࠩࠪῲ"),l11l1l_l1_ (u"ࠪࠫῳ"),l11l1l_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩῴ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ῵"),url,l11l1l_l1_ (u"࠭ࠧῶ"),l11l1l_l1_ (u"ࠧࠨῷ"),l11l1l_l1_ (u"ࠨࠩῸ"),l11l1l_l1_ (u"ࠩࠪΌ"),l11l1l_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨῺ"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠫࠬΏ"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩῼ"))
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ´"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ῾"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠨࠩ῿"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ "):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ "),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ "):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ "),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ "):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ "),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ "):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ "),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ "),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠫࠬ "),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ "),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ​"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ‌"),l11l1l_l1_ (u"ࠨใํ่๊࠭‍"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ‎"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ‏"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ‐"),l11l1l_l1_ (u"ࠬํฯศใࠪ‑"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭‒"),l11l1l_l1_ (u"ฺࠧำูࠫ–"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ—"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ―"),l11l1l_l1_ (u"ุ้ࠪือ๋หࠪ‖")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠫ࠴࠭‗"))
		#if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ‘") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨ’")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ‚"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭‛") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ“")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ”"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭„"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ‟"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ†"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭‡"):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ•"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ‣") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ․"),l1111l_l1_+title,l1llll1_l1_,683,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ‥") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ…"),l1111l_l1_+title,l1llll1_l1_,681,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭‧"),l1111l_l1_+title,l1llll1_l1_,683,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ "),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ ")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ‪"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ‫"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭‬"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ‭")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ‮"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ "),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ‰")+title,l1llll1_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ‱"),l11l1l_l1_ (u"ࠪࠫ′"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ″"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ‴"),url,l11l1l_l1_ (u"࠭ࠧ‵"),l11l1l_l1_ (u"ࠧࠨ‶"),l11l1l_l1_ (u"ࠨࠩ‷"),l11l1l_l1_ (u"ࠩࠪ‸"),l11l1l_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ‹"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ›"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ※"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ‼")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࠨࠩࡲࡲࡨࡲࡩࡤ࡭ࡀࠦࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ࠭ࠧ‽"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠨࠥࠪ‾"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‿"),l1111l_l1_+title,url,683,l1ll1l_l1_,l11l1l_l1_ (u"ࠪࠫ⁀"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩ⁁")+l1l11_l1_+l11l1l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⁂"),html,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧ⁃"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⁄"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ⁅")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⁆"))
			title = title.replace(l11l1l_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨ⁇"),l11l1l_l1_ (u"ࠫࠥ࠭⁈"))
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⁉"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ⁊"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ⁋") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ⁌")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⁍"))
		#		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⁎"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ⁏"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⁐"),url,l11l1l_l1_ (u"࠭ࠧ⁑"),l11l1l_l1_ (u"ࠧࠨ⁒"),l11l1l_l1_ (u"ࠨࠩ⁓"),l11l1l_l1_ (u"ࠩࠪ⁔"),l11l1l_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⁕"))
	html = response.content
	# l1lll11_l1_ l11llll_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⁖"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	post = l1llll1_l1_.split(l11l1l_l1_ (u"ࠬࡶ࡯ࡴࡶࡀࠫ⁗"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⁘"))
	post = post.replace(l11l1l_l1_ (u"ࠧ࡝࠱ࠪ⁙"),l11l1l_l1_ (u"ࠨ࠱ࠪ⁚"))
	post = EVAL(l11l1l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ⁛"),post)
	l1l1_l1_ = post[l11l1l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡶࠫ⁜")]
	l11ll1_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l11111_l1_ = zip(l11ll1_l1_,l1l1_l1_)
	for title,l1llll1_l1_ in l11111_l1_:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⁝")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⁞")
		l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠨࠢࠣࠌࠌࠧ࡮࡬ࠠ࡭࡫ࡱ࡯ࠥࡧ࡮ࡥࠢࠪ࡬ࡹࡺࡰࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡ࡮࡬ࡲࡰࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺ࠨ࠭࡯࡭ࡳࡱࠊࠊࡪࡤࡷ࡭ࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࡨࡢࡵ࡫ࡁࠬ࠯࡛࠲࡟ࠍࠍࡵࡧࡲࡵࡵࠣࡁࠥ࡮ࡡࡴࡪ࠱ࡷࡵࡲࡩࡵࠪࠪࡣࡤ࠭ࠩࠋࠋࡱࡩࡼࡥࡰࡢࡴࡷࡷࠥࡃࠠ࡜࡟ࠍࠍ࡫ࡵࡲࠡࡲࡤࡶࡹࠦࡩ࡯ࠢࡳࡥࡷࡺࡳ࠻ࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎࡶࡡࡳࡶࠣࡁࠥࡨࡡࡴࡧ࠹࠸࠳ࡨ࠶࠵ࡦࡨࡧࡴࡪࡥࠩࡲࡤࡶࡹ࠱ࠧ࠾ࠩࠬࠎࠎࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢࡳࡥࡷࡺࠠ࠾ࠢࡳࡥࡷࡺ࠮ࡥࡧࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠋࠋࠌࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡱࡣࡵࡸ࠮ࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠊࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࠪࡂࠬ࠴ࡪࡰ࡫ࡱࠬࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠩࠋࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡰ࡮ࡴ࡫ࡴ࠰ࡶࡴࡱ࡯ࡴ࡭࡫ࡱࡩࡸ࠮ࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠶ࠥ࡯࡮ࠡࡼࡽࡾ࠿ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠷࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠠ࠾ࡀࠣࠫ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡼࡧࡴࡤࡪࠪࠎࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠤࠥࠦ ")
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⁠"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⁡"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ⁢"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ⁣"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭⁤"),l11l1l_l1_ (u"ࠬ࠱ࠧ⁥"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ⁦")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⁧"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ⁨")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ⁩"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡆࡐࡊࡇࡎࡆࡔࠪᯊ")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡈࡒࡎࡠࠩᯋ")
l1l1ll11ll_l1_ = os.path.join(l1ll11l1l1_l1_,l11l1l_l1_ (u"ࠫࡹ࡫࡭ࡱࠩᯌ"))
l1l11l111l_l1_ = os.path.join(l1ll11l1l1_l1_,l11l1l_l1_ (u"ࠬࡶࡡࡤ࡭ࡤ࡫ࡪࡹࠧᯍ"))
l1l1ll111l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨᯎ"),l11l1l_l1_ (u"ࠧࡕࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫᯏ"))
l1l11lll11_l1_ = l1ll1111l1_l1_
l1l11l11l1_l1_ = l11l1l_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠫᯐ")
l1l11l11ll_l1_ = l11l1l_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡵࡼࡷࡹ࡫࡭࠰ࡦࡵࡳࡵࡨ࡯ࡹࠩᯑ")
l1l1ll1111_l1_ = l11l1l_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡷࡳࡲࡨࡳࡵࡱࡱࡩࡸ࠭ᯒ")
l1l1ll1l11_l1_ = l11l1l_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࡧࡦࡴࠪᯓ")
l1l11l1ll1_l1_ = l11l1l_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡱࡵࡧࠨᯔ")
l1l11l1lll_l1_ = l11l1l_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡧ࡮ࡳࠩᯕ")
def MAIN(mode):
	if   mode==740: results = l1ll11l11l_l1_()
	elif mode==741: results = l1ll111ll1_l1_(l1l1ll11ll_l1_,True,True)
	elif mode==742: results = l1ll111ll1_l1_(l1l11l111l_l1_,True,True)
	elif mode==743: results = l1ll111ll1_l1_(l1l1ll111l_l1_,False,True)
	elif mode==744: results = l1l11ll1l1_l1_(l1l11lll11_l1_,True)
	elif mode==745: results = l1l111llll_l1_(True)
	elif mode==750: results = l1l1l1l11l_l1_()
	elif mode==751: results = l1ll111ll1_l1_(l1l11l11l1_l1_,False,True)
	elif mode==752: results = l1ll111ll1_l1_(l1l11l11ll_l1_,False,True)
	elif mode==753: results = l1ll111ll1_l1_(l1l1ll1111_l1_,False,True)
	elif mode==754: results = l1ll111ll1_l1_(l1l1ll1l11_l1_,False,True)
	elif mode==755: results = l1ll111ll1_l1_(l1l11l1ll1_l1_,False,True)
	elif mode==756: results = l1ll111ll1_l1_(l1l11l1lll_l1_,False,True)
	elif mode==757: results = l1l1l1l1ll_l1_(True)
	elif mode==758: results = l1l1l11l1l_l1_()
	else: results = False
	return results
def l1ll11l11l_l1_():
	l1l1lll11l_l1_,l1ll111l1l_l1_ = l1l11l1l11_l1_(l1l1ll11ll_l1_)
	l1l1lll111_l1_,l1l11lllll_l1_ = l1l11l1l11_l1_(l1l11l111l_l1_)
	l1l1ll1lll_l1_,l1l1l11111_l1_ = l1l11l1l11_l1_(l1l1ll111l_l1_)
	l1l1llll11_l1_,l1l11lll1l_l1_ = l1l1l1111l_l1_(l1l11lll11_l1_)
	l1l1llll11_l1_ -= 36864
	l1l11lll1l_l1_ -= 1
	l1l11l1l1l_l1_ = l11l1l_l1_ (u"ࠧࠡࠪࠪᯖ")+l1ll111lll_l1_(l1l1lll11l_l1_)+l11l1l_l1_ (u"ࠨࠢ࠰ࠤࠬᯗ")+str(l1ll111l1l_l1_)+l11l1l_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᯘ")
	l1l1l11lll_l1_ = l11l1l_l1_ (u"ࠪࠤ࠭࠭ᯙ")+l1ll111lll_l1_(l1l1lll111_l1_)+l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨᯚ")+str(l1l11lllll_l1_)+l11l1l_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᯛ")
	l1l1l11ll1_l1_ = l11l1l_l1_ (u"࠭ࠠࠩࠩᯜ")+l1ll111lll_l1_(l1l1ll1lll_l1_)+l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫᯝ")+str(l1l1l11111_l1_)+l11l1l_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᯞ")
	l1ll11l111_l1_ = l11l1l_l1_ (u"ࠩࠣࠬࠬᯟ")+l1ll111lll_l1_(l1l1llll11_l1_)+l11l1l_l1_ (u"ࠪ࠭ࠬᯠ")
	size = l1l1lll11l_l1_+l1l1lll111_l1_+l1l1ll1lll_l1_+l1l1llll11_l1_
	count = l1ll111l1l_l1_+l1l11lllll_l1_+l1l1l11111_l1_+l1l11lll1l_l1_
	text = l11l1l_l1_ (u"ࠫࠥ࠮ࠧᯡ")+l1ll111lll_l1_(size)+l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩᯢ")+str(count)+l11l1l_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᯣ")
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᯤ"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึัࠥอไอ็ํ฽ࠬᯥ")+text,l11l1l_l1_ (u"᯦ࠩࠪ"),745)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᯧ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᯨ"),l11l1l_l1_ (u"ࠬ࠭ᯩ"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᯪ"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ᯫ")+l1l11l1l1l_l1_,l11l1l_l1_ (u"ࠨࠩᯬ"),741)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᯭ"),l1111l_l1_+l11l1l_l1_ (u"ุ้ࠪำࠠศๆ่่ๆอสࠡษ็้฻เุ่หࠪᯮ")+l1l1l11lll_l1_,l11l1l_l1_ (u"ࠫࠬᯯ"),742)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᯰ"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪᯱ")+l1l1l11ll1_l1_,l11l1l_l1_ (u"ࠧࠨ᯲"),743)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ᯳࠭"),l1111l_l1_+l11l1l_l1_ (u"ࠩอๅึ๐ฺࠡ็็ๅࠥ฻่าࠢส่ส฼วโษอࠫ᯴")+l1ll11l111_l1_,l11l1l_l1_ (u"ࠪࠫ᯵"),744)
	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᯶"),l11l1l_l1_ (u"ࠬ࠭᯷"))
	return
def l1l1l1l11l_l1_():
	l1ll111l11_l1_ = True if l11l1l_l1_ (u"࠭࠯ࠨ᯸") in l1l11ll1ll_l1_ else False
	if not l1ll111l11_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ᯹"),l11l1l_l1_ (u"ࠨࠩ᯺"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᯻"),l11l1l_l1_ (u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪ᯼"))
		return
	l1l11ll11l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᯽"))
	if not l1l11ll11l_l1_: l1l1l11l1l_l1_()
	l1l1lll11l_l1_,l1ll111l1l_l1_ = l1l11l1l11_l1_(l1l11l11l1_l1_)
	l1l1lll111_l1_,l1l11lllll_l1_ = l1l11l1l11_l1_(l1l11l11ll_l1_)
	l1l1ll1lll_l1_,l1l1l11111_l1_ = l1l11l1l11_l1_(l1l1ll1111_l1_)
	l1l1llll11_l1_,l1l11lll1l_l1_ = l1l11l1l11_l1_(l1l1ll1l11_l1_)
	l1l1lll1ll_l1_,l1l11llll1_l1_ = l1l11l1l11_l1_(l1l11l1ll1_l1_)
	l1l1lll1l1_l1_,l1l1ll1l1l_l1_ = l1l11l1l11_l1_(l1l11l1lll_l1_)
	l1l11l1l1l_l1_ = l11l1l_l1_ (u"ࠬࠦࠨࠨ᯾")+l1ll111lll_l1_(l1l1lll11l_l1_)+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ᯿")+str(l1ll111l1l_l1_)+l11l1l_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᰀ")
	l1l1l11lll_l1_ = l11l1l_l1_ (u"ࠨࠢࠫࠫᰁ")+l1ll111lll_l1_(l1l1lll111_l1_)+l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭ᰂ")+str(l1l11lllll_l1_)+l11l1l_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᰃ")
	l1l1l11ll1_l1_ = l11l1l_l1_ (u"ࠫࠥ࠮ࠧᰄ")+l1ll111lll_l1_(l1l1ll1lll_l1_)+l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩᰅ")+str(l1l1l11111_l1_)+l11l1l_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᰆ")
	l1ll11l111_l1_ = l11l1l_l1_ (u"ࠧࠡࠪࠪᰇ")+l1ll111lll_l1_(l1l1llll11_l1_)+l11l1l_l1_ (u"ࠨࠢ࠰ࠤࠬᰈ")+str(l1l11lll1l_l1_)+l11l1l_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᰉ")
	l1l1l111l1_l1_ = l11l1l_l1_ (u"ࠪࠤ࠭࠭ᰊ")+l1ll111lll_l1_(l1l1lll1ll_l1_)+l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨᰋ")+str(l1l11llll1_l1_)+l11l1l_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᰌ")
	l1l1l11l11_l1_ = l11l1l_l1_ (u"࠭ࠠࠩࠩᰍ")+l1ll111lll_l1_(l1l1lll1l1_l1_)+l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫᰎ")+str(l1l1ll1l1l_l1_)+l11l1l_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᰏ")
	size = l1l1lll11l_l1_+l1l1lll111_l1_+l1l1ll1lll_l1_+l1l1llll11_l1_+l1l1lll1ll_l1_+l1l1lll1l1_l1_
	count = l1ll111l1l_l1_+l1l11lllll_l1_+l1l1l11111_l1_+l1l11lll1l_l1_+l1l11llll1_l1_+l1l1ll1l1l_l1_
	text = l11l1l_l1_ (u"ࠩࠣࠬࠬᰐ")+l1ll111lll_l1_(size)+l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧᰑ")+str(count)+l11l1l_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᰒ")
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰓ"),l1111l_l1_+l11l1l_l1_ (u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩᰔ"),l11l1l_l1_ (u"ࠧࠨᰕ"),758)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰖ"),l1111l_l1_+l11l1l_l1_ (u"่ࠩืาࠦวๅฮ่๎฾࠭ᰗ")+text,l11l1l_l1_ (u"ࠪࠫᰘ"),757)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰙ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᰚ"),l11l1l_l1_ (u"࠭ࠧᰛ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰜ"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠨᰝ")+l1l11l1l1l_l1_,l11l1l_l1_ (u"ࠩࠪᰞ"),751)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᰟ"),l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡥࡴࡲࡴࡧࡵࡸࠨᰠ")+l1l1l11lll_l1_,l11l1l_l1_ (u"ࠬ࠭ᰡ"),752)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰢ"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠧᰣ")+l1l1l11ll1_l1_,l11l1l_l1_ (u"ࠨࠩᰤ"),753)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰥ"),l1111l_l1_+l11l1l_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦ࡬ࡰࡩࡪࡩࡷ࠭ᰦ")+l1ll11l111_l1_,l11l1l_l1_ (u"ࠫࠬᰧ"),754)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰨ"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ᰩ")+l1l1l111l1_l1_,l11l1l_l1_ (u"ࠧࠨᰪ"),755)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰫ"),l1111l_l1_+l11l1l_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩᰬ")+l1l1l11l11_l1_,l11l1l_l1_ (u"ࠪࠫᰭ"),756)
	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᰮ"),l11l1l_l1_ (u"ࠬ࠭ᰯ"))
	return
def l1l1l11l1l_l1_():
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧᰰ"),l11l1l_l1_ (u"ࠧࠨᰱ"),l11l1l_l1_ (u"ࠨࠩᰲ"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᰳ"),l11l1l_l1_ (u"่่ࠪ๐๋ࠠ฻่่ࠥอไห่฻๎ๆูࠦ็ัๆࠤ࠳࠴ࠠษำ้ห๊าฺࠠ็สำࠥฮอศฮฬࠤส๊้ࠡว฼฻ฬวࠠาะุอࠥอไใำสลฮ่ࠦศๆๆฮฬฮษࠡๆ็้้็วห๋ࠢห้๋ฬๅัสฮࠥอไห์ࠣืํ็๋ࠠ็ึั์อࠠศๆหี๋อๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลฺูสลࠥํะ่ࠢส่ึิีสࠢส่ว์ࠠภࠣࠪᰴ"))
	if l1ll11111l_l1_==-1: return
	if l1ll11111l_l1_:
		l1ll1111ll_l1_ = True
		import subprocess
		try: subprocess.Popen(l11l1l_l1_ (u"ࠫࡸࡻࠧᰵ"))
		except: l1ll1111ll_l1_ = False
		if l1ll1111ll_l1_:
			l1l1l1ll1l_l1_ = l1l11l11l1_l1_+l11l1l_l1_ (u"ࠬࠦࠧᰶ")+l1l11l11ll_l1_+l11l1l_l1_ (u"࠭ࠠࠨ᰷")+l1l1ll1111_l1_+l11l1l_l1_ (u"ࠧࠡࠩ᰸")+l1l1ll1l11_l1_+l11l1l_l1_ (u"ࠨࠢࠪ᰹")+l1l11l1ll1_l1_+l11l1l_l1_ (u"ࠩࠣࠫ᰺")+l1l11l1lll_l1_
			proc = subprocess.Popen(l11l1l_l1_ (u"ࠪࡷࡺࠦ࠭ࡤࠢࠥࡧ࡭ࡳ࡯ࡥࠢ࠰ࡖࠥ࠶࠷࠸࠹ࠣࠫ᰻")+l1l1l1ll1l_l1_+l11l1l_l1_ (u"ࠫࠧ࠭᰼"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭᰽"),l11l1l_l1_ (u"࠭ࠧ᰾"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᰿"),l11l1l_l1_ (u"ࠨ่ฯัฯูࠦๆๆํอࠥหูุษฤࠤฬ๊ัฯืฬࠫ᱀"))
			settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭᱁"),l11l1l_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭᱂"))
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ᱃"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭᱄"),l11l1l_l1_ (u"࠭ࠧ᱅"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᱆"),l11l1l_l1_ (u"ࠨ฻่่๏ฯࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠหฯอหัࠦศา่ส้ัࠦࠠࡳࡱࡲࡸࠥࠦร้ࠢࠣࡷࡺࡶࡥࡳࡷࡶࡩࡷࠦࠠฤ๊ࠣࠤࡸࡻ๊ࠠࠡฯ๋ฬุใࠡๆสࠤ๏๎ฬะࠢไ๎์ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴࠮ࠡล๋ࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠨ᱇"))
	return
def l1ll111lll_l1_(size):
	for x in [l11l1l_l1_ (u"ࠩࡅࠫ᱈"),l11l1l_l1_ (u"ࠪࡏࡇ࠭᱉"),l11l1l_l1_ (u"ࠫࡒࡈࠧ᱊"),l11l1l_l1_ (u"ࠬࡍࡂࠨ᱋"),l11l1l_l1_ (u"࠭ࡔࡃࠩ᱌")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11l1l_l1_ (u"ࠢࠦ࠵࠱࠵࡫ࠦࠥࡴࠤᱍ")%(size,x)
	return text
def l1l11l1l11_l1_(l1ll111111_l1_=l11l1l_l1_ (u"ࠨ࠰ࠪᱎ")):
	global l1l1l1llll_l1_,l1l1lllll1_l1_
	l1l1l1llll_l1_,l1l1lllll1_l1_ = 0,0
	def l1l1ll11l1_l1_(l1ll111111_l1_):
		global l1l1l1llll_l1_,l1l1lllll1_l1_
		if os.path.exists(l1ll111111_l1_):
			if 0 and l11l1l_l1_ (u"ࠩࡶࡧࡦࡴࡤࡪࡴࠪᱏ") in dir(os):
				# using l1l1ll1ll1_l1_ l11l1l_l1_ (u"ࠪࡳࡸ࠴ࡳࡤࡣࡱࡨ࡮ࡸࠧ᱐") method (new in version 3.5)
				for l1l11l1111_l1_ in os.scandir(l1ll111111_l1_):
					if l1l11l1111_l1_.l1l1llllll_l1_(follow_symlinks=False):
						l1l1ll11l1_l1_(l1l11l1111_l1_.path)
					elif l1l11l1111_l1_.l1l1l111ll_l1_(follow_symlinks=False):
						l1l1l1llll_l1_ += l1l11l1111_l1_.stat().st_size
						l1l1lllll1_l1_ += 1
			else:
				# using l11lll111_l1_, l1l1l1l111_l1_ l1l11ll111_l1_ l11l1l_l1_ (u"ࠫࡴࡹ࠮࡭࡫ࡶࡸࡩ࡯ࡲࠨ᱑") method
				for l1l11l1111_l1_ in os.listdir(l1ll111111_l1_):
					l1l111lll1_l1_ = os.path.abspath(os.path.join(l1ll111111_l1_,l1l11l1111_l1_))
					if os.path.isdir(l1l111lll1_l1_):
						l1l1ll11l1_l1_(l1l111lll1_l1_)
					elif os.path.isfile(l1l111lll1_l1_):
						size,count = l1l1l1111l_l1_(l1l111lll1_l1_)
						l1l1l1llll_l1_ += size
						l1l1lllll1_l1_ += count
		return
	try: l1l1ll11l1_l1_(l1ll111111_l1_)
	except: pass
	return l1l1l1llll_l1_,l1l1lllll1_l1_
def l1l1llll1l_l1_(l1l1l1lll1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬ࠭᱒"),l11l1l_l1_ (u"࠭ࠧ᱓"),l11l1l_l1_ (u"ࠧࠨ᱔"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᱕"),l1l1l1lll1_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ᱖")+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᱗"))
		if l1ll11111l_l1_!=1: return
	error = False
	if os.path.exists(l1l1l1lll1_l1_):
		try: os.remove(l1l1l1lll1_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ᱘"),l11l1l_l1_ (u"ࠬ࠭᱙"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᱚ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨᱛ"),l11l1l_l1_ (u"ࠨࠩᱜ"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᱝ"),l11l1l_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᱞ"))
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᱟ"),l11l1l_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᱠ"))
		xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᱡ"))
	return
def l1l111llll_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨᱢ"),l11l1l_l1_ (u"ࠨࠩᱣ"),l11l1l_l1_ (u"ࠩࠪᱤ"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᱥ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠫᱦ")+l11l1l_l1_ (u"ࠬࡢ࡮ࠨᱧ")+l11l1l_l1_ (u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬᱨ")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪᱩ")+l11l1l_l1_ (u"ࠨมࠤࠥࠬᱪ")+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᱫ"))
		if l1ll11111l_l1_!=1: return
	l1ll111ll1_l1_(l1l1ll11ll_l1_,True,False)
	l1ll111ll1_l1_(l1l11l111l_l1_,True,False)
	l1ll111ll1_l1_(l1l1ll111l_l1_,False,False)
	l1l11ll1l1_l1_(l1l11lll11_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᱬ"),l11l1l_l1_ (u"ࠫࠬᱭ"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᱮ"),l11l1l_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧᱯ"))
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᱰ"),l11l1l_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᱱ"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ᱲ"))
	return
def l1l1l1l1ll_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫᱳ"),l11l1l_l1_ (u"ࠫࠬᱴ"),l11l1l_l1_ (u"ࠬ࠭ᱵ"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᱶ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ᱷ")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫᱸ")+l11l1l_l1_ (u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ᱹ")+l11l1l_l1_ (u"ࠪࡠࡳ࠭ᱺ")+l11l1l_l1_ (u"ࠫࡄࠧࠡࠨᱻ")+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᱼ"))
		if l1ll11111l_l1_!=1: return
	l1ll111ll1_l1_(l1l11l11l1_l1_,False,False)
	l1ll111ll1_l1_(l1l11l11ll_l1_,False,False)
	l1ll111ll1_l1_(l1l1ll1111_l1_,False,False)
	l1ll111ll1_l1_(l1l1ll1l11_l1_,False,False)
	l1ll111ll1_l1_(l1l11l1ll1_l1_,False,False)
	l1ll111ll1_l1_(l1l11l1lll_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧᱽ"),l11l1l_l1_ (u"ࠧࠨ᱾"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᱿"),l11l1l_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᲀ"))
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᲁ"),l11l1l_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᲂ"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᲃ"))
	return
def l1l11ll1l1_l1_(l1l1l1ll11_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧᲄ"),l11l1l_l1_ (u"ࠧࠨᲅ"),l11l1l_l1_ (u"ࠨࠩᲆ"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᲇ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨᲈ")+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ᲊ"))
		if l1ll11111l_l1_!=1: return
	conn = sqlite3.connect(l1l1l1ll11_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11l1l_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩᲊ"))
	cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫ᲋"))
	cc.execute(l11l1l_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧ᲌"))
	conn.commit()
	cc.execute(l11l1l_l1_ (u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩ᲍"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ᲎"),l11l1l_l1_ (u"ࠪࠫ᲏"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᲐ"),l11l1l_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭Ბ"))
		settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᲒ"),l11l1l_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᲓ"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᲔ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
headers = { l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪଙ") : l11l1l_l1_ (u"ࠧࠨଚ") }
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧଛ")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡅࡐ࡝࡟ࠨଜ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
#l11ll11_l1_ = [l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨଝ"),l11l1l_l1_ (u"่๊๊ࠫษࠩଞ"),l11l1l_l1_ (u"ࠬอไฺำูࠤฬ๊วิส๋฽๏࠭ଟ"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭ଠ"),l11l1l_l1_ (u"ࠧๆีิั๏ํࠧଡ"),l11l1l_l1_ (u"ࠨษ฽๊๏ฯࠧଢ"),l11l1l_l1_ (u"ࠩส฽้อๆࠨଣ"),l11l1l_l1_ (u"่ࠪ็อมࠨତ")]
#proxy = l11l1l_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶࠻࠹࠯࠴࠳࠷࠳࠾࠷࠯࠳࠶࠴࠿࠹࠱࠳࠺ࠪଥ")
#proxy = l11l1l_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬଦ")+l11l1l1l_l1_[6][1]
proxy = l11l1l_l1_ (u"࠭ࠧଧ")
l1l111_l1_ = [l11l1l_l1_ (u"ࠧฤๆ฼หอ࠭ନ"),l11l1l_l1_ (u"ࠨษ็ฺ้อัฺหࠣห้ำัสࠩ଩"),l11l1l_l1_ (u"ࠩส่็ืว็ࠢส่่ื๊ๆࠩପ"),l11l1l_l1_ (u"ࠪห้้สษ๋ࠢࠤฬ๊วษฯสฯࠬଫ"),l11l1l_l1_ (u"ࠫฬ๊ี้ำࠣ์ࠥอไฯๆไ๎ฬะࠧବ"),l11l1l_l1_ (u"ࠬอไๆี็ื้อสࠡษ็หีอู๋หࠪଭ")]
def MAIN(mode,url,text):
	if   mode==240: results = MENU()
	elif mode==241: results = l1lllll_l1_(url,text)
	elif mode==242: results = l1lll1ll_l1_(url)
	elif mode==243: results = PLAY(url)
	elif mode==244: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪମ")+text)
	elif mode==245: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧଯ")+text)
	elif mode==246: results = l1l1ll1l_l1_(url)
	elif mode==247: results = l11l1l11_l1_(url)
	elif mode==248: results = l111llll_l1_()
	elif mode==249: results = SEARCH(text)
	else: results = False
	return results
def l111llll_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩର"),l11l1l_l1_ (u"ࠩࠪ଱"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଲ"),l11l1l_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡࠤฦ็ํอๅࠡษ็ะิ๐ฯࠣࠢไ๎ࠥฮูืࠢส่ศำ๊ศ่ࠣๅ๏ํࠠ็๊฼ࠤ๊์ࠠศๆะะอࠦึะࠢส่อืวๆฮࠣ࠲ࠥ๎็ัษࠣ๎ุฮศࠡ็ื็้ฯࠠโ์ࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦ࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦำษส๊ห๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊๊๊ࠡ๎ࠥะุ่ำࠣ์ฯิสโ์ࠣฬฺ๎ัสࠢ฼ุํอฦ๋หࠪଳ"))
	return
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ଴"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧଵ"),headers,l11l1l_l1_ (u"ࠧࠨଶ"),l11l1l_l1_ (u"ࠨࠩଷ"),l11l1l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪସ"))
	html = response.content
	l11l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡴࡳࡥ࠮ࡵ࡬ࡸࡪ࠳ࡢࡵࡰ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧହ"),html,re.DOTALL)
	if l11l111l_l1_: l11l111l_l1_ = l11l111l_l1_[0]
	else: l11l111l_l1_ = l11l11_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ଺"),l11l111l_l1_,l11l1l_l1_ (u"ࠬ࠭଻"),headers,l11l1l_l1_ (u"଼࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨଽ"),l11l1l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩା"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩି"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪୀ"),l11l1l_l1_ (u"ࠫࠬୁ"),249,l11l1l_l1_ (u"ࠬ࠭ୂ"),l11l1l_l1_ (u"࠭ࠧୃ"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫୄ"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୅"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ୆"),l11l11_l1_,246)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪେ"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧୈ"),l11l11_l1_,247)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ୉"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୊"),l11l1l_l1_ (u"ࠧࠨୋ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨୌ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ୍ࠫ")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ୎"),l11l111l_l1_,241,l11l1l_l1_ (u"ࠫࠬ୏"),l11l1l_l1_ (u"ࠬ࠭୐"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ୑"))
	l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭୒"),html,re.DOTALL)
	l1llll1_l1_ = l111ll11_l1_[0]
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୓"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ୔")+l1111l_l1_+l11l1l_l1_ (u"ࠪว฻๐แࠡฯา๎ะอࠧ୕"),l1llll1_l1_,241)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩୖ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬୗ"),l11l1l_l1_ (u"࠭ࠧ୘"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡮ࡤ࠰࠸ࠥࡪ࠭ࡧ࡮ࡨࡼࠥࡧ࡬ࡪࡩࡱ࠱࡮ࡺࡥ࡮ࡵ࠰ࡧࡪࡴࡴࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧࡩࡷ࠳࡬ࡪࡰ࡮ࠤࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ୙"),html,re.DOTALL)
	for l1llll1_l1_,name,block in l1l11ll_l1_:
		if name in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୚"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ୛")+l1111l_l1_+name,l1llll1_l1_,241)
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩଡ଼"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title in l1l111_l1_: continue
			title = name+l11l1l_l1_ (u"ࠫࠥ࠭ଢ଼")+title
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୞"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨୟ")+l1111l_l1_+title,l1llll1_l1_,241)
	return
def l1l1ll1l_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠧࠨୠ")):
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠨࠩୡ"),headers,l11l1l_l1_ (u"ࠩࠪୢ"),l11l1l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫୣ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࡯ࡣࡹࠫ୤"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ୥"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title not in l1l111_l1_:
				title = title+l11l1l_l1_ (u"࠭ࠠๆื้ๅฮ࠭୦")
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ୧"),l1111l_l1_+title,l1llll1_l1_,245)
		if l1l1l111_l1_==l11l1l_l1_ (u"ࠨࠩ୨"): addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ୩"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ୪"),l11l1l_l1_ (u"ࠫࠬ୫"),9999)
	return html
def l11l1l11_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠬ࠭୬")):
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ୭"),headers,l11l1l_l1_ (u"ࠧࠨ୮"),l11l1l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ୯"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩ୰"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪୱ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title not in l1l111_l1_:
				title = title+l11l1l_l1_ (u"๋ࠫࠥแๅฬิอࠬ୲")
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୳"),l1111l_l1_+title,l1llll1_l1_,244)
		if l1l1l111_l1_==l11l1l_l1_ (u"࠭ࠧ୴"): addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ୵"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ୶"),l11l1l_l1_ (u"ࠩࠪ୷"),9999)
	return html
def l1lllll_l1_(url,type=l11l1l_l1_ (u"ࠪࠫ୸")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ୹"),l11l1l_l1_ (u"ࠬ࠭୺"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧ୻"),headers,True,l11l1l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ୼"))
	if type==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ୽"): l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧ୾"),html,re.DOTALL)
	else: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡦࡰࡱࡷࡩࡷ࠭୿"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ஀"),block,re.DOTALL)
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஁"),block,re.DOTALL)
		for l1ll1l_l1_,l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨஂ") in l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠫஃ"))[1]
			if l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ஄") in l1llll1_l1_ or l11l1l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡷࡴ࠱ࠪஅ") in l1llll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஆ"),l1111l_l1_+title,l1llll1_l1_,242,l1ll1l_l1_)
			elif l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭இ") in l1llll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫஈ"),l1111l_l1_+title,l1llll1_l1_,243,l1ll1l_l1_)
			elif l11l1l_l1_ (u"࠭࠯ࡨࡣࡰࡩࡸ࠵ࠧஉ") not in l1llll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ஊ"),l1111l_l1_+title,l1llll1_l1_,243,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ஋"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஌"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title==l11l1l_l1_ (u"ࠪࠪࡱࡹࡡࡲࡷࡲ࠿ࠬ஍"): title = l11l1l_l1_ (u"ุࠫอศใหࠪஎ")
			if title==l11l1l_l1_ (u"ࠬࠬࡲࡴࡣࡴࡹࡴࡁࠧஏ"): title = l11l1l_l1_ (u"࠭ไศฯๅอࠬஐ")
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஑"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧஒ")+title,l1llll1_l1_,241)
	return
def SEARCH(search):
	# https://l11l1ll1_l1_.net/search?q=%l11l1lll_l1_%l1l1l1l1_l1_%l11l1lll_l1_%l1ll1111_l1_%l11l1lll_l1_%l1l11ll1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪஓ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫஔ"): return
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭க"),l11l1l_l1_ (u"ࠬࠫ࠲࠱ࠩ஖"))
	url = l11l11_l1_ + l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ஗")+l1111l1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ஘"),l11l1l_l1_ (u"ࠨࠩங"),url,l11l1l_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࡡࡄࡏࡔࡇࡍࠨச"))
	results = l1lllll_l1_(url)
	return
def l1lll1ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ஛"),l11l1l_l1_ (u"ࠫࠬஜ"),url,l11l1l_l1_ (u"ࠬࡋࡐࡊࡕࡒࡈࡊ࡙࡟ࡂࡍ࡚ࡅࡒ࠭஝"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧஞ"),headers,True,l11l1l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬட"))
	if l11l1l_l1_ (u"ࠨ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦࡃ࠭஠") not in html:
		l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ஡"))
		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ஢"),l1111l_l1_+l11l1l_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪண"),url,243,l1ll1l_l1_)
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸ࠲࠺ࠧத"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ஥"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in l11ll_l1_:
			#if l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ஦") in l1llll1_l1_: continue
			if l11l1l_l1_ (u"ࠨษ็ั้่วหࠩ஧") in title or l11l1l_l1_ (u"่ࠩ์ฬูๅࠡษัี๎࠭ந") in title: continue
			if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬன") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫப"),l1111l_l1_+title,l1llll1_l1_,242,l1ll1l_l1_)
			else: addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ஫"),l1111l_l1_+title,l1llll1_l1_,243,l1ll1l_l1_)
	return
def PLAY(url):
	#l111llll_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l11l1l_l1_ (u"࠭ࡓ࠻࡞࡟ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭஬"), l11l1l_l1_ (u"ࠧࡸࠩ஭")).write(html)
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠨࠩம"),headers,True,l11l1l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪய"))
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡦࡦࡪࡧࡦ࠯ࡧࡥࡳ࡭ࡥࡳ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬர"),html,re.DOTALL)
	if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	l11l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ற"),html,re.DOTALL)
	#l11l1111_l1_ = ([l11l1l_l1_ (u"ࠬ࠭ல"),l11l1l_l1_ (u"࠭ࠧள")],[l11l1l_l1_ (u"ࠧࠨழ"),l11l1l_l1_ (u"ࠨࠩவ")])
	l1lll1_l1_,l1ll1lll_l1_,l11111l_l1_,l11l11ll_l1_ = [],[],[],[]
	if l11l1111_l1_:
		l11ll1l_l1_ = l11l1l_l1_ (u"ࠩࡰࡴ࠹࠭ஶ")
		for l11l11l1_l1_,l111ll1l_l1_ in l11l1111_l1_:
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡸࡦࡨ࠭ࡤࡱࡱࡸࡪࡴࡴࠡࡳࡸࡥࡱ࡯ࡴࡺࠤࠣ࡭ࡩࡃࠢࠨஷ")+l11l11l1_l1_+l11l1l_l1_ (u"ࠫࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾࠯࡞ࡶ࠮ࡁ࠵ࡤࡪࡸࡁࠫஸ"),html,re.DOTALL)
			block = l1l11ll_l1_[0]
			l11111l_l1_.append(block)
			l11l11ll_l1_.append(l111ll1l_l1_)
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡷࡵࡢ࡮࡬ࡸ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬஹ"),html,re.DOTALL)
		if not l1l11ll_l1_:
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ஺"),l11l1l_l1_ (u"ࠧࠨ஻"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ஼"),l11l1l_l1_ (u"ࠩ็หࠥ๐่อั้้ࠣ็ࠠโ์า๎ํࠦแ๋๊ࠢิฬࠦวๅำสฬ฼࠭஽"))
			return
		else:
			block,filename = l1l11ll_l1_[0]
			l111l1l_l1_ = [l11l1l_l1_ (u"ࠪࡾ࡮ࡶࠧா"),l11l1l_l1_ (u"ࠫࡷࡧࡲࠨி"),l11l1l_l1_ (u"ࠬࡺࡸࡵࠩீ"),l11l1l_l1_ (u"࠭ࡰࡥࡨࠪு"),l11l1l_l1_ (u"ࠧࡩࡶࡰࠫூ"),l11l1l_l1_ (u"ࠨࡶࡤࡶࠬ௃"),l11l1l_l1_ (u"ࠩ࡬ࡷࡴ࠭௄"),l11l1l_l1_ (u"ࠪ࡬ࡹࡳ࡬ࠨ௅")]
			l11ll1l_l1_ = filename.rsplit(l11l1l_l1_ (u"ࠫ࠳࠭ெ"),1)[1].strip(l11l1l_l1_ (u"ࠬࠦࠧே"))
			if l11ll1l_l1_ in l111l1l_l1_:
				DIALOG_OK(l11l1l_l1_ (u"࠭ࠧை"),l11l1l_l1_ (u"ࠧࠨ௉"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫொ"),l11l1l_l1_ (u"ࠩส่๊๊แࠡๆํืࠥ็๊ะ์๋ࠤํ๊วࠡื๋ฮࠬோ"))
				return
		l11111l_l1_.append(block)
		l11l11ll_l1_.append(l11l1l_l1_ (u"ࠪࠫௌ"))
	for i in range(len(l11111l_l1_)):
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯ࡣࡰࡰ࠰ࠬ࠳࠰࠿ࠪࠤ்ࠪ"),l11111l_l1_[i],re.DOTALL)
		for l1llll1_l1_,l111lll1_l1_ in l1l1_l1_:
			if l11l1l_l1_ (u"ࠬࡺ࡯ࡳࡴࡨࡲࡹ࠭௎") in l111lll1_l1_: continue
			#elif l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࠫ௏") in l111lll1_l1_: continue
			elif l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩௐ") in l111lll1_l1_: type = l11l1l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ௑")
			elif l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࠧ௒") in l111lll1_l1_: type = l11l1l_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ௓")
			else: type = l11l1l_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ௔")
			#title = l11l11ll_l1_[i]+l11l1l_l1_ (u"ࠬࠦๅๅใࠣࠫ௕")+type
			#l1ll1lll_l1_.append(title)
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࠩ௖")+type+l11l1l_l1_ (u"ࠧࡠࡡࡢࡣࠬௗ")+l11l11ll_l1_[i]+l11l1l_l1_ (u"ࠨࡡࡢࡥࡰࡽࡡ࡮ࠩ௘")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ௙"),l1ll1lll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ௚"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ௛"),url)
	return
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ௜"),l11l1l_l1_ (u"࠭ࠧ௝"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ௞"),l11l1l_l1_ (u"ࠨࠩ௟"),filter,url)
	l1l111ll_l1_ = [l11l1l_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ௠"),l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ௡"),l11l1l_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ௢"),l11l1l_l1_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ௣")]
	if l11l1l_l1_ (u"࠭࠿ࠨ௤") in url: url = url.split(l11l1l_l1_ (u"ࠧࡀࠩ௥"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ௦"),1)
	if filter==l11l1l_l1_ (u"ࠩࠪ௧"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠪࠫ௨"),l11l1l_l1_ (u"ࠫࠬ௩")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩ௪"))
	if type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ௫"):
		if l1l111ll_l1_[0]+l11l1l_l1_ (u"ࠧ࠾ࠩ௬") not in l1l1111l_l1_: category = l1l111ll_l1_[0]
		for i in range(len(l1l111ll_l1_[0:-1])):
			if l1l111ll_l1_[i]+l11l1l_l1_ (u"ࠨ࠿ࠪ௭") in l1l1111l_l1_: category = l1l111ll_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࠫ௮")+category+l11l1l_l1_ (u"ࠪࡁ࠵࠭௯")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭௰")+category+l11l1l_l1_ (u"ࠬࡃ࠰ࠨ௱")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"࠭ࠦࠨ௲"))+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ௳")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠪ௴"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭௵"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠪࡃࠬ௶")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ௷"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ௸"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"࠭ࠧ௹"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠧࡢ࡮࡯ࠫ௺"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠨࠩ௻"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠩࡂࠫ௼")+l1l11111_l1_
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ௽"),l1111l_l1_+l11l1l_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬ࠭௾"),l111ll1_l1_,241,l11l1l_l1_ (u"ࠬ࠭௿"),l11l1l_l1_ (u"࠭࠱ࠨఀ"))
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧఁ"),l1111l_l1_+l11l1l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨం")+l11ll111_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨః"),l111ll1_l1_,241,l11l1l_l1_ (u"ࠪࠫఄ"),l11l1l_l1_ (u"ࠫ࠶࠭అ"))
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪఆ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ఇ"),l11l1l_l1_ (u"ࠧࠨఈ"),9999)
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠨࠩఉ"),headers,True,l11l1l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫఊ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢ࡬ࡨ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪఋ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪఌ"),block,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭఍"),l11l1l_l1_ (u"࠭ࠧఎ"),l11l1l_l1_ (u"ࠧࠨఏ"),str(l1ll1l1l_l1_))
	dict = {}
	for l1ll11ll_l1_,name,block in l1ll1l1l_l1_:
		#name = name.replace(l11l1l_l1_ (u"ࠨ࠯࠰ࠫఐ"),l11l1l_l1_ (u"ࠩࠪ఑"))
		items = re.findall(l11l1l_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡀࠫ࠲࠯ࡅࠩ࠽ࠩఒ"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠫࡂ࠭ఓ") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩఔ"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<=1:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: l1lllll_l1_(l111ll1_l1_)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭క")+l1l11l1l_l1_)
				return
			else:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧఖ"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠨగ"),l111ll1_l1_,241,l11l1l_l1_ (u"ࠩࠪఘ"),l11l1l_l1_ (u"ࠪ࠵ࠬఙ"))
				else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫచ"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠬఛ"),l111ll1_l1_,245,l11l1l_l1_ (u"࠭ࠧజ"),l11l1l_l1_ (u"ࠧࠨఝ"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩఞ"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࠫట")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠪࡁ࠵࠭ఠ")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭డ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠬࡃ࠰ࠨఢ")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪణ")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧత"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠣࠫథ")+name,l111ll1_l1_,244,l11l1l_l1_ (u"ࠩࠪద"),l11l1l_l1_ (u"ࠪࠫధ"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭న"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if option in l1l111_l1_: continue
			if l11l1l_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ఩") not in value: value = option
			else: value = re.findall(l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧప"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠧࠧࠩఫ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠨ࠿ࠪబ")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠩࠩࠫభ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠪࡁࠬమ")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨయ")+l1l1l1ll_l1_
			title = option+l11l1l_l1_ (u"ࠬࠦ࠺ࠡࠩర")#+dict[l1ll11ll_l1_][l11l1l_l1_ (u"࠭࠰ࠨఱ")]
			title = option+l11l1l_l1_ (u"ࠧࠡ࠼ࠣࠫల")+name
			if type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩళ"): addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩఴ"),l1111l_l1_+title,url,244,l11l1l_l1_ (u"ࠪࠫవ"),l11l1l_l1_ (u"ࠫࠬశ"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧష"))
			elif type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪస") and l1l111ll_l1_[-2]+l11l1l_l1_ (u"ࠧ࠾ࠩహ") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠨࡣ࡯ࡰࠬ఺"))
				l111lll_l1_ = url+l11l1l_l1_ (u"ࠩࡂࠫ఻")+l11lll1l_l1_
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ఼ࠪ"),l1111l_l1_+title,l111lll_l1_,241,l11l1l_l1_ (u"ࠫࠬఽ"),l11l1l_l1_ (u"ࠬ࠷ࠧా"))
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ి"),l1111l_l1_+title,url,245,l11l1l_l1_ (u"ࠧࠨీ"),l11l1l_l1_ (u"ࠨࠩు"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪూ"),l11l1l_l1_ (u"ࠪࠫృ"),filters,l11l1l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬౄ"))
	# mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ౅")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩె")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠧࡢ࡮࡯ࠫే")					all filters (l11ll1ll_l1_ l1l1l11l_l1_ filter)
	#filters = filters.replace(l11l1l_l1_ (u"ࠨ࠿ࠩࠫై"),l11l1l_l1_ (u"ࠩࡀ࠴ࠫ࠭౉"))
	filters = filters.strip(l11l1l_l1_ (u"ࠪࠪࠬొ"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"ࠫࡂ࠭ో") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠬࠬࠧౌ"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"࠭࠽ࠨ్"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠧࠨ౎")
	l1l1llll_l1_ = [l11l1l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࠩ౏"),l11l1l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ౐"),l11l1l_l1_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ౑"),l11l1l_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ౒"),l11l1l_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ౓"),l11l1l_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ౔"),l11l1l_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨౕ")]
	for key in l1l1llll_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠨ࠲ౖࠪ")
		#if l11l1l_l1_ (u"ࠩࠨࠫ౗") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬౘ") and value!=l11l1l_l1_ (u"ࠫ࠵࠭ౙ"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠬࠦࠫࠡࠩౚ")+value
		elif mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ౛") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ౜"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠨࠨࠪౝ")+key+l11l1l_l1_ (u"ࠩࡀࠫ౞")+value
		elif mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ౟"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠫࠫ࠭ౠ")+key+l11l1l_l1_ (u"ࠬࡃࠧౡ")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠬࠢࠪౢ"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩౣ"))
	#l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠨ࠿࠳ࠫ౤"),l11l1l_l1_ (u"ࠩࡀࠫ౥"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ౦"),l11l1l_l1_ (u"ࠫࠬ౧"),filters,l11l1l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭౨"))
	return l1ll111l_l1_
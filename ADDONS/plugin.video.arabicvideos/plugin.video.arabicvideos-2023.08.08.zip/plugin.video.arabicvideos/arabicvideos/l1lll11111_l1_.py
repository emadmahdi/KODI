# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪᝆ")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨᝇ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠪห้ืฦ๋ีํอࠬᝈ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l1lllll_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l1lll1ll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᝉ"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᝊ"),l11l1l_l1_ (u"࠭ࠧᝋ"),l11l1l_l1_ (u"ࠧࠨᝌ"),l11l1l_l1_ (u"ࠨࠩᝍ"),l11l1l_l1_ (u"ࠩࠪᝎ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᝏ"))
	html = response.content
	l1l1lll_l1_ = SERVER(l11l11_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨᝐ"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᝑ"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᝒ"),l11l1l_l1_ (u"ࠧࠨᝓ"),559,l11l1l_l1_ (u"ࠨࠩ᝔"),l11l1l_l1_ (u"ࠩࠪ᝕"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᝖"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᝗"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᝘"),l11l1l_l1_ (u"࠭ࠧ᝙"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᝚"),l1111l_l1_+l11l1l_l1_ (u"ࠨษัฮึ์วࠡๆๆࠫ᝛"),l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ᝜"),551,l11l1l_l1_ (u"ࠪࠫ᝝"),l11l1l_l1_ (u"ࠫࠬ᝞"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ᝟"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᝠ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᝡ"),block,re.DOTALL)
	for l1lll11l11_l1_,title in items:
		l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࡀ࡫ࡷࡩࡲࡃࠧᝢ")+l1lll11l11_l1_+l11l1l_l1_ (u"ࠩࠩࡅ࡯ࡧࡸ࠾࠳ࠪᝣ")
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᝤ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᝥ")+l1111l_l1_+title,l1llll1_l1_,551)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᝦ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᝧ"),l11l1l_l1_ (u"ࠧࠨᝨ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡱࡥࡻ࠳࡭ࡢ࡫ࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧࡶ࠿ࠩᝩ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᝪ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l1llll1_l1_==l11l1l_l1_ (u"ࠪࠧࠬᝫ"): continue
		if title in l1l111_l1_: continue
		if l11l1l_l1_ (u"ู๊ࠫไิๆࠣࠫᝬ") in title: continue
		if l11l1l_l1_ (u"ࠬษอะอࠪ᝭") in title: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝮ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᝯ")+l1111l_l1_+title,l1llll1_l1_,551)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᝰ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᝱"),l11l1l_l1_ (u"ࠪࠫᝲ"),9999)
	for l1llll1_l1_,title in items:
		if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭ᝳ"): continue
		if title in l1l111_l1_: continue
		if l11l1l_l1_ (u"๋ࠬำๅี็ࠤࠬ᝴") in title: continue
		if l11l1l_l1_ (u"࠭รฮัฮࠫ᝵") not in title: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᝶"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᝷")+l1111l_l1_+title,l1llll1_l1_,551)
	return
def l1lllll_l1_(url,l1lll11l11_l1_=l11l1l_l1_ (u"ࠩࠪ᝸")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ᝹"),l11l1l_l1_ (u"ࠫࠬ᝺"),url)
	items = []
	# l1lll1111l_l1_ l1lll111l1_l1_
	if l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ᝻") in url or l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧ᝼") in url:
		l111ll1_l1_,l11ll1111_l1_ = l1lll111ll_l1_(url)
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭᝽"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ᝾")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ᝿"),l111ll1_l1_,l11ll1111_l1_,l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫក"),l11l1l_l1_ (u"ࠫࠬខ"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫគ"))
		html = response.content
		l1l11ll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪឃ"),url,l11l1l_l1_ (u"ࠧࠨង"),l11l1l_l1_ (u"ࠨࠩច"),l11l1l_l1_ (u"ࠩࠪឆ"),l11l1l_l1_ (u"ࠪࠫជ"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪឈ"))
		html = response.content
		# l1lll11l11_l1_ items
		if l1lll11l11_l1_==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧញ"):
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ដ"),html,re.DOTALL)
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ឋ"),block,re.DOTALL)
			#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩឌ"),l11l1l_l1_ (u"ࠩࠪឍ"),l11l1l_l1_ (u"ࠪࠫណ"))
		# l1lll1ll11_l1_ l111l111_l1_
		elif l11l1l_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠫត") in html:
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧថ"),html,re.DOTALL)
		else:
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫទ"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	if not items:
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩធ"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧន"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩប"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨផ"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪព"),l11l1l_l1_ (u"้ࠬไ๋สࠪភ"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬម"),l11l1l_l1_ (u"่ࠧัสๅࠬយ"),l11l1l_l1_ (u"ࠨ็หหึอษࠨរ"),l11l1l_l1_ (u"ࠩ฼ี฻࠭ល"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪវ"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪឝ")]
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧឞ"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩស"),title,re.DOTALL)
		if l11l1l_l1_ (u"ࠧิๆสื้࠭ហ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧឡ"),l1111l_l1_+title,l1llll1_l1_,552,l1ll1l_l1_)
		elif l1ll1l1_l1_ and l11l1l_l1_ (u"ࠩส่า๊โสࠩអ") in title:
			title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩឣ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឤ"),l1111l_l1_+title,l1llll1_l1_,553,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧឥ") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឦ"),l1111l_l1_+title,l1llll1_l1_,551,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧឧ"),l1111l_l1_+title,l1llll1_l1_,553,l1ll1l_l1_)
	if l1lll11l11_l1_==l11l1l_l1_ (u"ࠨࠩឨ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷ࠭ឩ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬឪ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠦࠧឫ"): continue
				#title = unescapeHTML(title)
				if title!=l11l1l_l1_ (u"ࠬ࠭ឬ"): addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឭ"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭ឮ")+title,l1llll1_l1_,551)
	if l11l1l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨឯ") in url or l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪឰ") in url:
		if l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪឱ") in url:
			url = url.replace(l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫឲ"),l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ឳ"))+l11l1l_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽࠳࠲ࠪ឴")
		elif l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ឵") in url:
			url,offset = url.split(l11l1l_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪា"))
			offset = int(offset)+20
			url = url+l11l1l_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫិ")+str(offset)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪី"),l1111l_l1_+l11l1l_l1_ (u"ࠫ์์วไࠢสุ่๊๊ะࠩឹ"),url,551)
	return
def l1lll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩឺ"),url,l11l1l_l1_ (u"࠭ࠧុ"),l11l1l_l1_ (u"ࠧࠨូ"),l11l1l_l1_ (u"ࠨࠩួ"),l11l1l_l1_ (u"ࠩࠪើ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫឿ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡭ࡥࡵࡕࡨࡥࡸࡵ࡮ࡴࡄࡼࡗࡪࡸࡩࡦࡵࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬៀ"),html,re.DOTALL)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨ࡬ࡪࡵࡷ࠱ࡪࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩេ"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l111l_l1_ and l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨែ") not in url:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ៃ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨោ"),l1111l_l1_+title,l1llll1_l1_,553,l1ll1l_l1_)
	# l11ll_l1_
	elif l1l1111_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥ࡭ࡲࡧࡧࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨៅ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩំ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#title = title.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧះ"),l11l1l_l1_ (u"ࠬ࠭ៈ")).strip(l11l1l_l1_ (u"࠭ࠠࠨ៉"))
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭៊"),l1111l_l1_+title,l1llll1_l1_,552,l1ll1l_l1_)
	return
def PLAY(url):
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ់"),l11l1l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ៌"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ៍"),l11l1l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ៎"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ៏"),l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧ័"),l11l1l_l1_ (u"ࠧࠨ៑"),l11l1l_l1_ (u"ࠨ្ࠩ"),l11l1l_l1_ (u"ࠩࠪ៓"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ។"))
	html = response.content
	l1l1lll_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ៕"))
	l1lll1_l1_ = []
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ៖"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l11ll1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡰࡰࡵࡷࡍࡉࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩៗ"),html,re.DOTALL)
		l11ll1l1_l1_ = l11ll1l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠢࡨࡧࡷࡔࡱࡧࡹࡦࡴ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ៘"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ៙"),l11l1l_l1_ (u"ࠩࠪ៚")).strip(l11l1l_l1_ (u"ࠪࠤࠬ៛"))
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡅࡳࡦࡴࡹࡩࡷࡃࠧៜ")+server+l11l1l_l1_ (u"ࠬࠬࡰࡰࡵࡷࡍࡉࡃࠧ៝")+l11ll1l1_l1_+l11l1l_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧ៞")
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ៟")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ០")
				l1lll1_l1_.append(l1llll1_l1_)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠤࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡇࡿࡎࡢ࡯ࡨࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡟ࠦࡸ࡫ࡲࡷࡧࡵࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ១"),block,re.DOTALL)
			for server,l1ll1lllll_l1_,title in items:
				title = title.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭២"),l11l1l_l1_ (u"ࠫࠬ៣")).strip(l11l1l_l1_ (u"ࠬࠦࠧ៤"))
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡃࡻࡑࡥࡲ࡫࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ៥")+server+l11l1l_l1_ (u"ࠧࠧ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࡖࡩࡷࡼࡥࡳࡵࡀࠫ៦")+l1ll1lllll_l1_+l11l1l_l1_ (u"ࠨࠨࡳࡳࡸࡺࡉࡅ࠿ࠪ៧")+l11ll1l1_l1_+l11l1l_l1_ (u"ࠩࠩࡅ࡯ࡧࡸ࠾࠳ࠪ៨")
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ៩")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ៪")
				l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡤࡰࡹࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ៫"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ៬"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ៭")+name+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ៮")
			if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ៯") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ៰")+l1llll1_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ៱"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ៲"),url)
	return
l11l1l_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡐࡍࡃ࡜ࡣࡔࡒࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࡦࡤࡸࡦࠦ࠽ࠡࡽ࡚ࠪ࡮࡫ࡷࠨ࠼࠴ࢁࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࠾ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫࢂࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡒࡒࡗ࡙࠭ࠬࡶࡴ࡯࠰ࡩࡧࡴࡢ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠊࠊࠥࠣࡻࡦࡺࡣࡩࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡹࡤࡸࡨ࡮ࡁࡳࡧࡤࡑࡦࡹࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡲࡼࡲ࡯ࡢࡦ࠰ࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡸ࡫ࡲ࠮ࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩ࠱ࡷࡵࡢ࡮࡬ࡸࡾ࠲࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠱ࠧࡠࡡࡢࡣࠬ࠱ࡱࡶࡣ࡯࡭ࡹࡿࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊ࡫ࡩࠤࡱ࡫࡮ࠩ࡮࡬ࡲࡰࡒࡉࡔࡖࠬࡁࡂ࠶࠺ࠡࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠭ࠩส่ึอศุࠢ็๎ุࠦแ๋้ࠣๅ๏ี๊้ࠩࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࠍࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦ៳")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ៴"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ៵"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ៶"),l11l1l_l1_ (u"ࠪ࠱ࠬ៷"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭៸")+search+l11l1l_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ៹")
	l1lllll_l1_(url)
	return
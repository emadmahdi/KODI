# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᖽ")
headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᖾ"):l11l1l_l1_ (u"ࠩࠪᖿ")}
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡈ࠺ࡕࡠࠩᗀ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨᗁ"),l11l1l_l1_ (u"ࠬอฮา์ࠪᗂ"),l11l1l_l1_ (u"࠭วฯำ์ࠫᗃ"),l11l1l_l1_ (u"ࠧศๆิส๏ู๊สࠩᗄ"),l11l1l_l1_ (u"ࠨสา์๋ࠦลฯฬํหึ࠭ᗅ"),l11l1l_l1_ (u"ࠩสๅ้อๅࠨᗆ"),l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠫᗇ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l1lllll_l1_(url,text)
	elif mode==422: results = l1lll11lll_l1_(url)
	elif mode==423: results = l1lll1ll_l1_(url)
	elif mode==424: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗈ")+text)
	elif mode==425: results = l1ll1ll1_l1_(url,l11l1l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᗉ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l1lll1l1ll_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1llll111l_l1_(l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᗊ"),l11l11_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠧࠨᗋ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᗌ"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪᗍ"),l11l1l_l1_ (u"ࠪࠫᗎ"),l11l1l_l1_ (u"ࠫࠬᗏ"),l11l1l_l1_ (u"ࠬ࠭ᗐ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᗑ"))
	html = response.content
	l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗒ"),html,re.DOTALL)
	l1l1lll_l1_ = l1l1lll_l1_[0].strip(l11l1l_l1_ (u"ࠨ࠱ࠪᗓ"))
	l1l1lll_l1_ = SERVER(l1l1lll_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ᗔ"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗕ"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᗖ"),l11l1l_l1_ (u"ࠬ࠭ᗗ"),429,l11l1l_l1_ (u"࠭ࠧᗘ"),l11l1l_l1_ (u"ࠧࠨᗙ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᗚ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗛ"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᗜ"),l1l1lll_l1_,425)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗝ"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᗞ"),l1l1lll_l1_,424)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᗟ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗠ"),l11l1l_l1_ (u"ࠨࠩᗡ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗣ")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᗤ"),l1l1lll_l1_,421)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗥ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗦ")+l1111l_l1_+l11l1l_l1_ (u"ࠧฤใ็ห๊ࠦวๅ่ฯ์๊࠭ᗧ"),l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴ࠱ࠪᗨ"),421)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗩ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗪ")+l1111l_l1_+l11l1l_l1_ (u"๋ࠫ๐สโๆๆืࠬᗫ"),l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾ࠯ࠨᗬ"),421)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᗭ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗮ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if l11l1l_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴࠩᗯ") in l1llll1_l1_: title = l11l1l_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨᗰ")
		elif l11l1l_l1_ (u"ࠪ࠳ࡳ࡫ࡴࡧ࡮࡬ࡼࠬᗱ") in l1llll1_l1_: title = l11l1l_l1_ (u"ࠫศ็ไศ็ࠣ์ู๊ไิๆสฮࠥ์๊หใ็็ุ࠭ᗲ")
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗳ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗴ")+l1111l_l1_+title,l1llll1_l1_,421)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗵ"),l1111l_l1_+l11l1l_l1_ (u"ࠨไสส๊ฯࠠหใุ๎้๐ษࠨᗶ"),l1l1lll_l1_,427)
	return
def l1lll1l1ll_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠩࠪᗷ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᗸ"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬᗹ"),l11l1l_l1_ (u"ࠬ࠭ᗺ"),l11l1l_l1_ (u"࠭ࠧᗻ"),l11l1l_l1_ (u"ࠧࠨᗼ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᗽ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪᗾ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪࠡࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠪ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗿ"),block,re.DOTALL)
	for category,id,l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if l11l1l_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᘀ") in l1llll1_l1_: title = l11l1l_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬᘁ")
		elif l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠳࡮ࡦࡶࡩࡰ࡮ࡾࠧᘂ") in l1llll1_l1_: title = l11l1l_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩᘃ")
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘄ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᘅ")+l1111l_l1_+title,l1llll1_l1_,421,l11l1l_l1_ (u"ࠪࠫᘆ"),l11l1l_l1_ (u"ࠫࠬᘇ"),category+l11l1l_l1_ (u"ࠬࢂࠧᘈ")+id)
	return
def l1lllll_l1_(url,l1lll11l11_l1_=l11l1l_l1_ (u"࠭ࠧᘉ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨᘊ"),l11l1l_l1_ (u"ࠨࠩᘋ"),l1lll11l11_l1_,url)
	if l11l1l_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᘌ") in url: url = url.strip(l11l1l_l1_ (u"ࠪ࠳ࠬᘍ"))+l11l1l_l1_ (u"ࠫ࠴ࡳࡰࡢࡣ࠲ࡪࡦࡳࡩ࡭ࡻ࠲ࠫᘎ")
	items = []
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩᘏ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᘐ"),url,l11l1l_l1_ (u"ࠧࠨᘑ"),headers,l11l1l_l1_ (u"ࠨࠩᘒ"),l11l1l_l1_ (u"ࠩࠪᘓ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᘔ"))
	html = response.content
	if not l1lll11l11_l1_ or l11l1l_l1_ (u"ࠫࢁ࠭ᘕ") in l1lll11l11_l1_:
		#if l11l1l_l1_ (u"ࠬࡓࡵ࡭ࡶ࡬ࡊ࡮ࡲࡴࡦࡴࠪᘖ") in html:
		#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘗ"),l1111l_l1_+l11l1l_l1_ (u"ࠧโๆอี๋ࠥอะัࠪᘘ"),url,425)
		#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘙ"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬᘚ"),url,424)
		#	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘛ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘜ"),l11l1l_l1_ (u"ࠬ࠭ᘝ"),9999)
		if l11l1l_l1_ (u"࠭ࡼࠨᘞ") not in l1lll11l11_l1_: l1lll11ll1_l1_ = l11l1l_l1_ (u"ࠧࠨᘟ")
		else: l1lll11ll1_l1_ = l11l1l_l1_ (u"ࠨ࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠲ࠫᘠ")+l1lll11l11_l1_
		separator = False
		if l11l1l_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶࠬᘡ") in html:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘢ"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᘣ"),url,421,l11l1l_l1_ (u"ࠬ࠭ᘤ"),l11l1l_l1_ (u"࠭ࠧᘥ"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᘦ"))
			separator = True
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠭ᘧ"),html,re.DOTALL)
		if l1l11ll_l1_:
			l1ll111_l1_ = l1l11ll_l1_[0]
			l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡥࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘨ"),l1ll111_l1_,re.DOTALL)
			for l1llll1l1l_l1_,l1lll11ll_l1_ in l1l1l11_l1_:
				l1llll11ll_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡥࡨࡲࡹ࡫ࡲ࠰ࡣࡦࡸ࡮ࡵ࡮࠰ࡊࡲࡱࡪࡶࡡࡨࡧࡏࡳࡦࡪࡥࡳ࠱ࡷࡥࡧ࠵ࠧᘩ")+l1llll1l1l_l1_+l1lll11ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭ᘪ")
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘫ"),l1111l_l1_+l1lll11ll_l1_,l1llll11ll_l1_,421)
				separator = True
		if separator: addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᘬ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᘭ"),l11l1l_l1_ (u"ࠨࠩᘮ"),9999)
	if l1lll11l11_l1_==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᘯ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡲࡴࡪࡈ࡬ࡰࡹ࡫ࡲࠨᘰ"),html,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡕ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᘱ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		else: block = l11l1l_l1_ (u"ࠬ࠭ᘲ")
	elif l11l1l_l1_ (u"࠭࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᘳ") in url or l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡤࡧࡱࡸࡪࡸ࠯ࠨᘴ") in url:
		block = html
	elif l11l1l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪᘵ") in url:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡓࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠯ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠭ࠫᘶ"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	elif l11l1l_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫᘷ") in url:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠪࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠯࠭ᘸ"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡆࡩࡴࡰࡴࡑࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘹ"),block,re.DOTALL)
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡃࡪ࡯ࡤ࠸ࡺࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭ᘺ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		else: block = l11l1l_l1_ (u"ࠧࠨᘻ")
	if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨࠪ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠯ࠬࡂࡆࡴࡾࡔࡪࡶ࡯ࡩࡎࡴࡦࡰ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩᘼ"),block,re.DOTALL)
	if not items: items = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᘽ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if not title: continue
		if l11l1l_l1_ (u"ࠪࡃࡳ࡫ࡷࡴ࠿ࠪᘾ") in l1llll1_l1_: continue
		title = title.replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬᘿ"),l11l1l_l1_ (u"ࠬ࠭ᙀ"))
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧᙁ"),title,re.DOTALL)
		if l1ll1l1_l1_ and l11l1l_l1_ (u"ࠧฮๆๅอࠬᙂ") in title:
			title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᙃ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙄ"),l1111l_l1_+title,l1llll1_l1_,422,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴ࠲ࠫᙅ") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙆ"),l1111l_l1_+title,l1llll1_l1_,421,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙇ"),l1111l_l1_+title,l1llll1_l1_,422,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙈ"),html,re.DOTALL)
	if l1l11ll_l1_ and l1lll11l11_l1_!=l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᙉ"):
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛࡝ࠩ࡟ࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭࡜ࠣ࡟ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙊ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠩสฺ่็อสࠢࠪᙋ"),l11l1l_l1_ (u"ࠪࠫᙌ"))
			if title!=l11l1l_l1_ (u"ࠫࠬᙍ"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙎ"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬᙏ")+title,l1llll1_l1_,421)
	l1llll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽࠱࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙐ"),html,re.DOTALL)
	if l1llll1111_l1_:
		l1llll1_l1_,title = l1llll1111_l1_[0]
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙑ"),l1111l_l1_+title,l1llll1_l1_,421)
	return
def l1lll11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ᙒ"),url,l11l1l_l1_ (u"ࠪࠫᙓ"),l11l1l_l1_ (u"ࠫࠬᙔ"),l11l1l_l1_ (u"ࠬ࠭ᙕ"),l11l1l_l1_ (u"࠭ࠧᙖ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠳ࡶࡸࠬᙗ"))
	html = response.content
	# l11l1l111_l1_/download main l11l11l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡎࡰࡹࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᙘ"),html,re.DOTALL)
	if l1l11ll_l1_:
		url = l1l11ll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ᙙ"),url,l11l1l_l1_ (u"ࠪࠫᙚ"),l11l1l_l1_ (u"ࠫࠬᙛ"),l11l1l_l1_ (u"ࠬ࠭ᙜ"),l11l1l_l1_ (u"࠭ࠧᙝ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠴ࡱࡨࠬᙞ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᙟ"),l11l1l_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᙠ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡗࡪࡧࡳࡰࡰࡶࡗࡪࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᙡ"),html,re.DOTALL)
	# l1lll1ll11_l1_ l1lll11l1l_l1_
	if l11l1l_l1_ (u"ࠫ࠴ࡺࡡࡨ࠱ࠪᙢ") in url or l11l1l_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࠬᙣ") in url:
		l1lllll_l1_(url)
	# l1lll1l_l1_
	elif l1l11ll_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᙤ"))
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨᙥ"),block,re.DOTALL)
		l1lllll111_l1_ = [l11l1l_l1_ (u"ࠨ็ึุ่๊ࠧᙦ"),l11l1l_l1_ (u"่ࠩ์ุ๋ࠧᙧ"),l11l1l_l1_ (u"ࠪฬึ์วๆฮࠪᙨ"),l11l1l_l1_ (u"ࠫา๊โสࠩᙩ")]
		for l1llll1_l1_,title in items:
			if any(value in title for value in l1lllll111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙪ"),l1111l_l1_+title,l1llll1_l1_,423,l1ll1l_l1_)
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᙫ"),l1111l_l1_+title,l1llll1_l1_,426,l1ll1l_l1_)
	else: l1lll1ll_l1_(url)
	return
def l1lll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫᙬ"),url,l11l1l_l1_ (u"ࠨࠩ᙭"),l11l1l_l1_ (u"ࠩࠪ᙮"),l11l1l_l1_ (u"ࠪࠫᙯ"),l11l1l_l1_ (u"ࠫࠬᙰ"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᙱ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᙲ"),l11l1l_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᙳ"))
	l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᙴ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪᙵ")
	# l11ll_l1_
	l1l11ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࡷࡘ࡫ࡣࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᙶ"),html,re.DOTALL)
	if l1l11ll1l_l1_:
		block = l1l11ll1l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙷ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l1_l1_ in items:
			title = title+l11l1l_l1_ (u"ࠬࠦࠧᙸ")+l1ll1l1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᙹ"),l1111l_l1_+title,l1llll1_l1_,426,l1ll1l_l1_)
	else: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᙺ"),l1111l_l1_+l11l1l_l1_ (u"ࠨำสฬ฼ࠦวๅฬื฾๏๊ࠧᙻ"),url,426,l1ll1l_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ᙼ"),url,l11l1l_l1_ (u"ࠪࠫᙽ"),headers,l11l1l_l1_ (u"ࠫࠬᙾ"),l11l1l_l1_ (u"ࠬ࠭ᙿ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ "))
	html = response.content
	#newurl = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡷࡽࡱ࡫ࡳࡩࡧࡨࡸࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚁ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᚂ"))
	l1l1lll_l1_ = SERVER(newurl,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ᚃ"))
	l1lll1_l1_ = []
	# l11l1l111_l1_ l1l1_l1_
	#if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᚄ"),l11l1l_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᚅ"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡝ࡡࡵࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᚆ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚇ"),block,re.DOTALL)
		for l11lll11_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩᚈ"))
			if l11l1l_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧᚉ") in title.lower(): title = l11l1l_l1_ (u"ࠩัหฺࠦࠧᚊ")+title
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸࡺࡲࡶࡥࡷࡹࡷ࡫࠯ࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨᚋ")+l11lll11_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᚌ")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᚍ")
			#l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡦ࠺ࡵ࠯࡫ࡦࡹࠬᚎ"),l11l1l_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻ࠮࡮ࡺࠪᚏ"))
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠨ࡞ࡵࠫᚐ"),l11l1l_l1_ (u"ࠩࠪᚑ"))
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨᚒ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚓ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧᚔ"))
			if l11l1l_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬᚕ") in title.lower(): l1lll11ll_l1_ = l11l1l_l1_ (u"ࠧࡠࡡัหฺ࠭ᚖ")
			else: l1lll11ll_l1_ = l11l1l_l1_ (u"ࠨࠩᚗ")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᚘ")+title+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᚙ")+l1lll11ll_l1_
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠫࡡࡸࠧᚚ"),l11l1l_l1_ (u"ࠬ࠭᚛"))
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ᚜"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᚝"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩ᚞"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪ᚟"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬᚠ"),l11l1l_l1_ (u"ࠫ࠰࠭ᚡ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧᚢ")+search+l11l1l_l1_ (u"࠭࠯ࠨᚣ")
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧᚤ"))
	return
# ===========================================
#     l1lll1l11l_l1_ l1lll1l111_l1_ l1lll1l1l1_l1_
# ===========================================
def l1llll1ll1_l1_(url):
	if l11l1l_l1_ (u"ࠨࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࠪᚥ") not in url: url = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ᚦ"))
	else: url = url.split(l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᚧ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᚨ"),url,l11l1l_l1_ (u"ࠬ࠭ᚩ"),l11l1l_l1_ (u"࠭ࠧᚪ"),l11l1l_l1_ (u"ࠧࠨᚫ"),l11l1l_l1_ (u"ࠨࠩᚬ"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫᚭ"))
	html = response.content
	# all l11111l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡑࡺࡲࡴࡪࡈ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡖࡡࡨࡧࡗ࡭ࡹࡲࡥࠨᚮ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	# name + options block + category
	l1ll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡍࡵࡶࡦࡴࡤࡦࡱ࡫࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࠥࡥࡱࡲࠢ࠯ࠬࡂࠬࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᚯ"),block,re.DOTALL)
	return l1ll1l1l_l1_
def l1lll1ll1l_l1_(block):
	# id + title
	items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᚰ"),block,re.DOTALL)
	return items
def l1lll1lll1_l1_(url):
	l1llll1l11_l1_ = url.split(l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᚱ"))[0]
	l1lll1llll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫᚲ"))
	url = url.replace(l1llll1l11_l1_,l1lll1llll_l1_)
	url = url.replace(l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᚳ"),l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡤࡧࡱࡸࡪࡸ࠯ࡢࡥࡷ࡭ࡴࡴ࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᚴ"))
	url = url.replace(l11l1l_l1_ (u"ࠪࡁࠬᚵ"),l11l1l_l1_ (u"ࠫ࠴࠭ᚶ")).replace(l11l1l_l1_ (u"ࠬࠬࠧᚷ"),l11l1l_l1_ (u"࠭࠯ࠨᚸ"))
	url = url+l11l1l_l1_ (u"ࠧ࠰ࠩᚹ")
	return url
l1l111ll_l1_ = [l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᚺ"),l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫ࡳࠨᚻ"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᚼ")]
l1l1llll_l1_ = [l11l1l_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬᚽ"),l11l1l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᚾ"),l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࡷࠬᚿ"),l11l1l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᛀ")]
def l1ll1ll1_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᛁ"),l11l1l_l1_ (u"ࠩࠪᛂ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᛃ"),l11l1l_l1_ (u"ࠫࠬᛄ"),filter,url)
	if l11l1l_l1_ (u"ࠬࡅࠧᛅ") in url: url = url.split(l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᛆ"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫᛇ"),1)
	if filter==l11l1l_l1_ (u"ࠨࠩᛈ"): l1l1111l_l1_,l1l11111_l1_ = l11l1l_l1_ (u"ࠩࠪᛉ"),l11l1l_l1_ (u"ࠪࠫᛊ")
	else: l1l1111l_l1_,l1l11111_l1_ = filter.split(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨᛋ"))
	if type==l11l1l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᛌ"):
		if l11l1l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪᛍ") in url:
			global l1l111ll_l1_
			l1l111ll_l1_ = l1l111ll_l1_[1:]
		if l1l111ll_l1_[0]+l11l1l_l1_ (u"ࠧ࠾ࠩᛎ") not in l1l1111l_l1_: category = l1l111ll_l1_[0]
		for i in range(len(l1l111ll_l1_[0:-1])):
			if l1l111ll_l1_[i]+l11l1l_l1_ (u"ࠨ࠿ࠪᛏ") in l1l1111l_l1_: category = l1l111ll_l1_[i+1]
		l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࠫᛐ")+category+l11l1l_l1_ (u"ࠪࡁ࠵࠭ᛑ")
		l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭ᛒ")+category+l11l1l_l1_ (u"ࠬࡃ࠰ࠨᛓ")
		l1l11l1l_l1_ = l1l1lll1_l1_.strip(l11l1l_l1_ (u"࠭ࠦࠨᛔ"))+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫᛕ")+l1l1l1ll_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠪᛖ"))
		l11lll1l_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᛗ"))
		l111ll1_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᛘ")+l11lll1l_l1_
	elif type==l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᛙ"):
		l11ll111_l1_ = l11llll1_l1_(l1l1111l_l1_,l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᛚ"))
		l11ll111_l1_ = l1llll_l1_(l11ll111_l1_)
		if l1l11111_l1_!=l11l1l_l1_ (u"࠭ࠧᛛ"): l1l11111_l1_ = l11llll1_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᛜ"))
		if l1l11111_l1_==l11l1l_l1_ (u"ࠨࠩᛝ"): l111ll1_l1_ = url
		else: l111ll1_l1_ = url+l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᛞ")+l1l11111_l1_
		l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᛟ"),l1111l_l1_+l11l1l_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧᛠ"),l111ll1_l1_,421,l11l1l_l1_ (u"ࠬ࠭ᛡ"),l11l1l_l1_ (u"࠭ࠧᛢ"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᛣ"))
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᛤ"),l1111l_l1_+l11l1l_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩᛥ")+l11ll111_l1_+l11l1l_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩᛦ"),l111ll1_l1_,421,l11l1l_l1_ (u"ࠫࠬᛧ"),l11l1l_l1_ (u"ࠬ࠭ᛨ"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᛩ"))
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᛪ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᛫"),l11l1l_l1_ (u"ࠩࠪ᛬"),9999)
	l1ll1l1l_l1_ = l1llll1ll1_l1_(url)
	dict = {}
	for name,block,l1ll11ll_l1_ in l1ll1l1l_l1_:
		if l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧ᛭") in url and l1ll11ll_l1_==l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᛮ"): continue
		name = name.replace(l11l1l_l1_ (u"ࠬ࠳࠭ࠨᛯ"),l11l1l_l1_ (u"࠭ࠧᛰ"))
		items = l1lll1ll1l_l1_(block)
		if l11l1l_l1_ (u"ࠧ࠾ࠩᛱ") not in l111ll1_l1_: l111ll1_l1_ = url
		if type==l11l1l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫᛲ"):
			if category!=l1ll11ll_l1_: continue
			elif len(items)<2:
				if l1ll11ll_l1_==l1l111ll_l1_[-1]:
					url = l1lll1lll1_l1_(url)
					l1lllll_l1_(url)
				else: l1ll1ll1_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨᛳ")+l1l11l1l_l1_)
				return
			else:
				l111ll1_l1_ = l1lll1lll1_l1_(l111ll1_l1_)
				if l1ll11ll_l1_==l1l111ll_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᛴ"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫᛵ"),l111ll1_l1_,421,l11l1l_l1_ (u"ࠬ࠭ᛶ"),l11l1l_l1_ (u"࠭ࠧᛷ"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᛸ"))
				else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᛹"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠩ᛺"),l111ll1_l1_,425,l11l1l_l1_ (u"ࠪࠫ᛻"),l11l1l_l1_ (u"ࠫࠬ᛼"),l1l11l1l_l1_)
		elif type==l11l1l_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ᛽"):
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨ᛾")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ᛿")
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪᜀ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀ࠴ࠬᜁ")
			l1l11l1l_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧᜂ")+l1l1l1ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᜃ"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧᜄ")+name,l111ll1_l1_,424,l11l1l_l1_ (u"࠭ࠧᜅ"),l11l1l_l1_ (u"ࠧࠨᜆ"),l1l11l1l_l1_)		# +l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᜇ"))
		dict[l1ll11ll_l1_] = {}
		for value,option in items:
			if value==l11l1l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩᜈ"): option = l11l1l_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪᜉ")
			elif value==l11l1l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫᜊ"): option = l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧᜋ")
			if option in l1l111_l1_: continue
			#if l11l1l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬᜌ") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨᜍ"),value,re.DOTALL)[0]
			dict[l1ll11ll_l1_][value] = option
			l1l1lll1_l1_ = l1l1111l_l1_+l11l1l_l1_ (u"ࠨࠨࠪᜎ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠩࡀࠫᜏ")+option
			l1l1l1ll_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠬᜐ")+l1ll11ll_l1_+l11l1l_l1_ (u"ࠫࡂ࠭ᜑ")+value
			l1ll11l1_l1_ = l1l1lll1_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩᜒ")+l1l1l1ll_l1_
			title = option+l11l1l_l1_ (u"࠭ࠠ࠻ࠩᜓ")#+dict[l1ll11ll_l1_][l11l1l_l1_ (u"ࠧ࠱᜔ࠩ")]
			title = option+l11l1l_l1_ (u"ࠨࠢ࠽᜕ࠫ")+name
			if type==l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ᜖"): addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᜗"),l1111l_l1_+title,url,424,l11l1l_l1_ (u"ࠫࠬ᜘"),l11l1l_l1_ (u"ࠬ࠭᜙"),l1ll11l1_l1_)		# +l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᜚"))
			elif type==l11l1l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ᜛") and l1l111ll_l1_[-2]+l11l1l_l1_ (u"ࠨ࠿ࠪ᜜") in l1l1111l_l1_:
				l11lll1l_l1_ = l11llll1_l1_(l1l1l1ll_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ᜝"))
				l111lll_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ᜞")+l11lll1l_l1_
				l111lll_l1_ = l1lll1lll1_l1_(l111lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᜟ"),l1111l_l1_+title,l111lll_l1_,421,l11l1l_l1_ (u"ࠬ࠭ᜠ"),l11l1l_l1_ (u"࠭ࠧᜡ"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᜢ"))
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜣ"),l1111l_l1_+title,url,425,l11l1l_l1_ (u"ࠩࠪᜤ"),l11l1l_l1_ (u"ࠪࠫᜥ"),l1ll11l1_l1_)
	return
def l11llll1_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᜦ"),l11l1l_l1_ (u"ࠬ࠭ᜧ"),filters,l11l1l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧᜨ"))
	# mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᜩ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ values
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᜪ")		l1l1ll11_l1_ l1l11lll_l1_ l1l1l11l_l1_ filters
	# mode==l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭ᜫ")					all l1l1l11l_l1_ & l1llll11l1_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠪࡁࠫ࠭ᜬ"),l11l1l_l1_ (u"ࠫࡂ࠶ࠦࠨᜭ"))
	filters = filters.strip(l11l1l_l1_ (u"ࠬࠬࠧᜮ"))
	l1l111l1_l1_ = {}
	if l11l1l_l1_ (u"࠭࠽ࠨᜯ") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠧࠧࠩᜰ"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠨ࠿ࠪᜱ"))
			l1l111l1_l1_[var] = value
	l1ll111l_l1_ = l11l1l_l1_ (u"ࠩࠪᜲ")
	for key in l1l1llll_l1_:
		if key in list(l1l111l1_l1_.keys()): value = l1l111l1_l1_[key]
		else: value = l11l1l_l1_ (u"ࠪ࠴ࠬᜳ")
		if l11l1l_l1_ (u"᜴ࠫࠪ࠭") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ᜵") and value!=l11l1l_l1_ (u"࠭࠰ࠨ᜶"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠧࠡ࠭ࠣࠫ᜷")+value
		elif mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ᜸") and value!=l11l1l_l1_ (u"ࠩ࠳ࠫ᜹"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"ࠪࠪࠬ᜺")+key+l11l1l_l1_ (u"ࠫࡂ࠭᜻")+value
		elif mode==l11l1l_l1_ (u"ࠬࡧ࡬࡭ࠩ᜼"): l1ll111l_l1_ = l1ll111l_l1_+l11l1l_l1_ (u"࠭ࠦࠨ᜽")+key+l11l1l_l1_ (u"ࠧ࠾ࠩ᜾")+value
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠨࠢ࠮ࠤࠬ᜿"))
	l1ll111l_l1_ = l1ll111l_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠫᝀ"))
	l1ll111l_l1_ = l1ll111l_l1_.replace(l11l1l_l1_ (u"ࠪࡁ࠵࠭ᝁ"),l11l1l_l1_ (u"ࠫࡂ࠭ᝂ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᝃ"),l11l1l_l1_ (u"࠭ࠧᝄ"),filters,l11l1l_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠸࠲ࠨᝅ"))
	return l1ll111l_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙ࠫ㊽")
l11l11_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㊾")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11l1l_l1_ (u"࠭࠰ࠨ㊿"),True)
	elif mode==102: results = ITEMS(l11l1l_l1_ (u"ࠧ࠲ࠩ㋀"),True)
	elif mode==103: results = ITEMS(l11l1l_l1_ (u"ࠨ࠴ࠪ㋁"),True)
	elif mode==104: results = ITEMS(l11l1l_l1_ (u"ࠩ࠶ࠫ㋂"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11l1l_l1_ (u"ࠪ࠸ࠬ㋃"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋄"),l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ㋅")+l11l1l_l1_ (u"࠭ไๅ็ืฮึ้๊็ࠢหาิ๋ษࠡࡏ࠶࡙ࠬ㋆"),l11l1l_l1_ (u"ࠧࠨ㋇"),710)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋈"),l11l1l_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ㋉")+l11l1l_l1_ (u"่้๋ࠪิหำๆ๎๋ࠦศฯั่อࠥࡏࡐࡕࡘࠪ㋊"),l11l1l_l1_ (u"ࠫࠬ㋋"),230)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋌"),l11l1l_l1_ (u"࠭࡟ࡕࡘ࠳ࡣࠬ㋍")+l11l1l_l1_ (u"ࠧใ่๋หฯࠦๅ็่ࠢ์ฬู่่ษࠣห้ษีๅ์ฬࠫ㋎"),l11l1l_l1_ (u"ࠨࠩ㋏"),101)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋐"),l11l1l_l1_ (u"ࠪࡣ࡙࡜࠴ࡠࠩ㋑")+l11l1l_l1_ (u"ࠫ็์่ศฬ้ࠣำะวาห้๋๊้ࠣࠦฬํ์อ࠭㋒"),l11l1l_l1_ (u"ࠬ࠭㋓"),106)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋔"),l11l1l_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㋕")+l11l1l_l1_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㋖"),l11l1l_l1_ (u"ࠩࠪ㋗"),147)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋘"),l11l1l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㋙")+l11l1l_l1_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㋚"),l11l1l_l1_ (u"࠭ࠧ㋛"),148)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋜"),l11l1l_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ㋝")+l11l1l_l1_ (u"ࠩࠣࠤ็์วสࠢล๎ࠥ็๊ๅ็้๋ࠣࠦๅ้ไ฼๋๊ࠦࠠࠨ㋞"),l11l1l_l1_ (u"ࠪࠫ㋟"),28)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㋠"),l11l1l_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ㋡")+l11l1l_l1_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㋢"),l11l1l_l1_ (u"ࠧࠨ㋣"),41)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㋤"),l11l1l_l1_ (u"ࠩࡢࡏ࡜࡚࡟ࠨ㋥")+l11l1l_l1_ (u"ࠪๆ๋อษࠡษ็็ํััࠡ็้ࠤ๊๎โฺ้่ࠫ㋦"),l11l1l_l1_ (u"ࠫࠬ㋧"),135)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㋨"),l11l1l_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ㋩")+l11l1l_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ㋪"),l11l1l_l1_ (u"ࠨࠩ㋫"),38)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㋬"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㋭"),l11l1l_l1_ (u"ࠫࠬ㋮"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋯"),l11l1l_l1_ (u"࠭࡟ࡕࡘ࠴ࡣࠬ㋰")+l11l1l_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ฼ห๊ฯࠧ㋱"),l11l1l_l1_ (u"ࠨࠩ㋲"),102)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋳"),l11l1l_l1_ (u"ࠪࡣ࡙࡜࠲ࡠࠩ㋴")+l11l1l_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦฮศืฬࠫ㋵"),l11l1l_l1_ (u"ࠬ࠭㋶"),103)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋷"),l11l1l_l1_ (u"ࠧࡠࡖ࡙࠷ࡤ࠭㋸")+l11l1l_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋ห่้ࠣ็อึࠩ㋹"),l11l1l_l1_ (u"ࠩࠪ㋺"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣ࡙࡜ࠧ㋻")+menu+l11l1l_l1_ (u"ࠫࡤ࠭㋼")
	client = l1l11llll11_l1_(32)
	payload = {l11l1l_l1_ (u"ࠬ࡯ࡤࠨ㋽"):l11l1l_l1_ (u"࠭ࠧ㋾"),l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࠬ㋿"):client,l11l1l_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㌀"):l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㌁"),l11l1l_l1_ (u"ࠪࡱࡪࡴࡵࠨ㌂"):menu}
	#data = l1ll11lll_l1_(payload)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㌃"),str(payload))
	#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㌄"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㌅"), l11l11_l1_, payload, l11l1l_l1_ (u"ࠧࠨ㌆"), True,l11l1l_l1_ (u"ࠨࠩ㌇"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㌈"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㌉"),l11l11_l1_,payload,l11l1l_l1_ (u"ࠫࠬ㌊"),l11l1l_l1_ (u"ࠬ࠭㌋"),l11l1l_l1_ (u"࠭ࠧ㌌"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ㌍"))
	html = response.content
	#html = html.replace(l11l1l_l1_ (u"ࠨ࡞ࡵࠫ㌎"),l11l1l_l1_ (u"ࠩࠪ㌏"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㌐"),l11l1l_l1_ (u"ࠫࠬ㌑"),html,html)
	#file = open(l11l1l_l1_ (u"ࠬࡹ࠺࠰ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ㌒"), l11l1l_l1_ (u"࠭ࡷࠨ㌓"))
	#file.write(html)
	#file.close()
	items = re.findall(l11l1l_l1_ (u"ࠧࠩ࡝ࡡ࠿ࡡࡸ࡜࡯࡟࠮ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠨ㌔"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11l1l_l1_ (u"ࠨࡣ࡯ࠫ㌕"),l11l1l_l1_ (u"ࠩࡄࡰࠬ㌖"))
			start = start.replace(l11l1l_l1_ (u"ࠪࡉࡱ࠭㌗"),l11l1l_l1_ (u"ࠫࡆࡲࠧ㌘"))
			start = start.replace(l11l1l_l1_ (u"ࠬࡇࡌࠨ㌙"),l11l1l_l1_ (u"࠭ࡁ࡭ࠩ㌚"))
			start = start.replace(l11l1l_l1_ (u"ࠧࡆࡎࠪ㌛"),l11l1l_l1_ (u"ࠨࡃ࡯ࠫ㌜"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11l1l_l1_ (u"ࠩࡄࡰ࠲࠭㌝"),l11l1l_l1_ (u"ࠪࡅࡱ࠭㌞"))
			start = start.replace(l11l1l_l1_ (u"ࠫࡆࡲࠠࠨ㌟"),l11l1l_l1_ (u"ࠬࡇ࡬ࠨ㌠"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11ll1lll1_l1_,name,l1ll1l_l1_ in items:
			if l11l1l_l1_ (u"࠭ࠣࠨ㌡") in source: continue
			#if source in [l11l1l_l1_ (u"ࠧࡏࡖࠪ㌢"),l11l1l_l1_ (u"ࠨ࡛ࡘࠫ㌣"),l11l1l_l1_ (u"࡚ࠩࡗ࠵࠭㌤"),l11l1l_l1_ (u"ࠪࡖࡑ࠷ࠧ㌥"),l11l1l_l1_ (u"ࠫࡗࡒ࠲ࠨ㌦")]: continue
			if source!=l11l1l_l1_ (u"࡛ࠬࡒࡍࠩ㌧"): name = name+l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࠣࠤࠬ㌨")+source+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㌩")
			url = source+l11l1l_l1_ (u"ࠨ࠽࠾ࠫ㌪")+server+l11l1l_l1_ (u"ࠩ࠾࠿ࠬ㌫")+l11ll1lll1_l1_+l11l1l_l1_ (u"ࠪ࠿ࡀ࠭㌬")+menu
			addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㌭"),l1111l_l1_+l11l1l_l1_ (u"ࠬ࠭㌮")+name,url,105,l1ll1l_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㌯"),l1111l_l1_+l11l1l_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㌰"),l11l1l_l1_ (u"ࠨࠩ㌱"),9999)
		#if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㌲"),l11l1l_l1_ (u"ࠪࠫ㌳"),l11l1l_l1_ (u"ࠫࠬ㌴"),l11l1l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㌵"))
		#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㌶"),l1111l_l1_+l11l1l_l1_ (u"ࠧๅๆฦืๆࠦไศࠢอ์ัีࠠใ่๋หฯࠦสๅใี์๋๐ษࠡๆๆࠫ㌷"),l11l1l_l1_ (u"ࠨࠩ㌸"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㌹"),l1111l_l1_+l11l1l_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅษๅีออม๊ࠡส่ฬ฻ฯใษฤࠤๆ่ืࠨ㌺"),l11l1l_l1_ (u"ࠫࠬ㌻"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㌼"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㌽"),l11l1l_l1_ (u"ࠧࠨ㌾"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㌿"),l1111l_l1_+l11l1l_l1_ (u"ࠩࡘࡲ࡫ࡵࡲࡵࡷࡱࡥࡹ࡫࡬ࡺ࠮ࠣࡲࡴࠦࡔࡗࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠤ࡫ࡵࡲࠡࡻࡲࡹࠬ㍀"),l11l1l_l1_ (u"ࠪࠫ㍁"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㍂"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡏࡴࠡ࡫ࡶࠤ࡫ࡵࡲࠡࡴࡨࡰࡦࡺࡩࡷࡧࡶࠤࠫࠦࡦࡳ࡫ࡨࡲࡩࡹࠠࡰࡰ࡯ࡽࠬ㍃"),l11l1l_l1_ (u"࠭ࠧ㍄"),9999)
	return
def PLAY(id):
	source,server,l11ll1lll1_l1_,menu = id.split(l11l1l_l1_ (u"ࠧ࠼࠽ࠪ㍅"))
	url = l11l1l_l1_ (u"ࠨࠩ㍆")
	if source==l11l1l_l1_ (u"ࠩࡘࡖࡑ࠭㍇"): url = l11ll1lll1_l1_
	elif source==l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㍈"):
		url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㍉")][0]+l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㍊")+l11ll1lll1_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],l1ll1_l1_,l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ㍋"),url)
		return
	elif source==l11l1l_l1_ (u"ࠧࡈࡃࠪ㍌"):
		payload = { l11l1l_l1_ (u"ࠨ࡫ࡧࠫ㍍") : l11l1l_l1_ (u"ࠩࠪ㍎"), l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㍏") : l1l11llll11_l1_(32) , l11l1l_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㍐") : l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠶࠭㍑") , l11l1l_l1_ (u"࠭࡭ࡦࡰࡸࠫ㍒") : l11l1l_l1_ (u"ࠧࠨ㍓") }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ㍔"),l11l11_l1_,payload,l11l1l_l1_ (u"ࠩࠪ㍕"),False,l11l1l_l1_ (u"ࠪࠫ㍖"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㍗"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㍘"),l11l1l_l1_ (u"࠭ࠧ㍙"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㍚"),l11l1l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㍛"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l11lll1l1_l1_ = cookies[l11l1l_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩ࠭㍜")]
		url = response.headers[l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㍝")]
		payload = { l11l1l_l1_ (u"ࠫ࡮ࡪࠧ㍞") : l11ll1lll1_l1_ , l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࠪ㍟") : l1l11llll11_l1_(32) , l11l1l_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㍠") : l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠲ࠨ㍡") , l11l1l_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㍢") : l11l1l_l1_ (u"ࠩࠪ㍣") }
		headers = { l11l1l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ㍤") : l11l1l_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤ࠾ࠩ㍥")+l1l11lll1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㍦"),l11l11_l1_,payload,headers,l11l1l_l1_ (u"࠭ࠧ㍧"),l11l1l_l1_ (u"ࠧࠨ㍨"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㍩"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㍪"),l11l1l_l1_ (u"ࠪࠫ㍫"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㍬"),l11l1l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㍭"))
			return
		html = response.content
		url = re.findall(l11l1l_l1_ (u"࠭ࡲࡦࡵࡳࠦ࠿ࠨࠨࡩࡶࡷࡴ࠳࠰࠿࡮࠵ࡸ࠼࠮࠮࠮ࠫࡁࠬࠦࠬ㍮"),html,re.DOTALL)
		l1llll1_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ㍯"),l11l1l_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠡࠩ㍰")+l1llll1_l1_)
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ㍱"),l11l1l_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠫ㍲")+params)
		l1l11lll11l_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠸࠾࠮ࠨ㍳")+server+l11l1l_l1_ (u"ࠬ࠽࠷࠸࠱ࠪ㍴")+l11ll1lll1_l1_+l11l1l_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㍵")+params
		l1l11lllll1_l1_ = l1l11lll11l_l1_.replace(l11l1l_l1_ (u"ࠧ࠴࠸࠽࠻ࠬ㍶"),l11l1l_l1_ (u"ࠨ࠶࠳࠾࠼࠭㍷")).replace(l11l1l_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㍸"),l11l1l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㍹"))
		l1l11llll1l_l1_ = l1l11lll11l_l1_.replace(l11l1l_l1_ (u"ࠫ࠸࠼࠺࠸ࠩ㍺"),l11l1l_l1_ (u"ࠬ࠺࠲࠻࠹ࠪ㍻")).replace(l11l1l_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㍼"),l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㍽"))
		l1ll1lll_l1_ = [l11l1l_l1_ (u"ࠨࡊࡇࠫ㍾"),l11l1l_l1_ (u"ࠩࡖࡈ࠶࠭㍿"),l11l1l_l1_ (u"ࠪࡗࡉ࠸ࠧ㎀")]
		l1lll1_l1_ = [l1l11lll11l_l1_,l1l11lllll1_l1_,l1l11llll1l_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㎁"), l1ll1lll_l1_)
		if l1l_l1_ == -1: return
		else: url = l1lll1_l1_[l1l_l1_]
	elif source==l11l1l_l1_ (u"ࠬࡔࡔࠨ㎂"):
		headers = { l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㎃") : l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㎄") }
		payload = { l11l1l_l1_ (u"ࠨ࡫ࡧࠫ㎅") : l11ll1lll1_l1_ , l11l1l_l1_ (u"ࠩࡸࡷࡪࡸࠧ㎆") : l1l11llll11_l1_(32) , l11l1l_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㎇") : l11l1l_l1_ (u"ࠫࡵࡲࡡࡺࡐࡗࠫ㎈") , l11l1l_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㎉") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㎊"), l11l11_l1_, payload, headers, False,l11l1l_l1_ (u"ࠧࠨ㎋"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㎌"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㎍"),l11l1l_l1_ (u"ࠪࠫ㎎"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㎏"),l11l1l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㎐"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㎑")]
		url = url.replace(l11l1l_l1_ (u"ࠧࠦ࠴࠳ࠫ㎒"),l11l1l_l1_ (u"ࠨࠢࠪ㎓"))
		url = url.replace(l11l1l_l1_ (u"ࠩࠨ࠷ࡉ࠭㎔"),l11l1l_l1_ (u"ࠪࡁࠬ㎕"))
		if l11l1l_l1_ (u"ࠫࡑ࡫ࡡࡳࡰࠪ㎖") in l11ll1lll1_l1_:
			url = url.replace(l11l1l_l1_ (u"ࠬࡔࡔࡏࡐ࡬ࡰࡪ࠭㎗"),l11l1l_l1_ (u"࠭ࠧ㎘"))
			url = url.replace(l11l1l_l1_ (u"ࠧ࡭ࡧࡤࡶࡳ࡯࡮ࡨ࠳ࠪ㎙"),l11l1l_l1_ (u"ࠨࡎࡨࡥࡷࡴࡩ࡯ࡩࠪ㎚"))
	elif source==l11l1l_l1_ (u"ࠩࡓࡐࠬ㎛"):
		#headers = { l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㎜") : l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㎝") }
		payload = { l11l1l_l1_ (u"ࠬ࡯ࡤࠨ㎞") : l11ll1lll1_l1_ , l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࠫ㎟") : l1l11llll11_l1_(32) , l11l1l_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㎠") : l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾࡖࡌࠨ㎡") , l11l1l_l1_ (u"ࠩࡰࡩࡳࡻࠧ㎢") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㎣"), l11l11_l1_, payload, l11l1l_l1_ (u"ࠫࠬ㎤"),False,l11l1l_l1_ (u"ࠬ࠭㎥"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ㎦"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㎧"),l11l1l_l1_ (u"ࠨࠩ㎨"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㎩"),l11l1l_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㎪"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㎫")]
		headers = {l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㎬"):response.headers[l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㎭")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㎮"),url, l11l1l_l1_ (u"ࠨࠩ㎯"),headers , l11l1l_l1_ (u"ࠩࠪ㎰"),l11l1l_l1_ (u"ࠪࠫ㎱"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭㎲"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㎳"),l11l1l_l1_ (u"࠭ࠧ㎴"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㎵"),l11l1l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㎶"))
			return
		html = response.content
		items = re.findall(l11l1l_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㎷"),html,re.DOTALL)
		url = items[0]
	elif source in [l11l1l_l1_ (u"ࠪࡘࡆ࠭㎸"),l11l1l_l1_ (u"ࠫࡋࡓࠧ㎹"),l11l1l_l1_ (u"ࠬ࡟ࡕࠨ㎺"),l11l1l_l1_ (u"࠭ࡗࡔ࠳ࠪ㎻"),l11l1l_l1_ (u"ࠧࡘࡕ࠵ࠫ㎼"),l11l1l_l1_ (u"ࠨࡔࡏ࠵ࠬ㎽"),l11l1l_l1_ (u"ࠩࡕࡐ࠷࠭㎾")]:
		if source==l11l1l_l1_ (u"ࠪࡘࡆ࠭㎿"): l11ll1lll1_l1_ = id
		headers = { l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㏀") : l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㏁") }
		payload = { l11l1l_l1_ (u"࠭ࡩࡥࠩ㏂") : l11ll1lll1_l1_ , l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࠬ㏃") : l1l11llll11_l1_(32) , l11l1l_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㏄") : l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࠧ㏅")+source , l11l1l_l1_ (u"ࠪࡱࡪࡴࡵࠨ㏆") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㏇"),l11l11_l1_,payload,headers,l11l1l_l1_ (u"ࠬ࠭㏈"),l11l1l_l1_ (u"࠭ࠧ㏉"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ㏊"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㏋"),l11l1l_l1_ (u"ࠩࠪ㏌"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㏍"),l11l1l_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㏎"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㏏")]
		if source==l11l1l_l1_ (u"࠭ࡆࡎࠩ㏐"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ㏑"), url, l11l1l_l1_ (u"ࠨࠩ㏒"), l11l1l_l1_ (u"ࠩࠪ㏓"), False,l11l1l_l1_ (u"ࠪࠫ㏔"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠺ࡸ࡭࠭㏕"))
			url = response.headers[l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㏖")]
			url = url.replace(l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ㏗"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ㏘"))
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㏙"))
	return
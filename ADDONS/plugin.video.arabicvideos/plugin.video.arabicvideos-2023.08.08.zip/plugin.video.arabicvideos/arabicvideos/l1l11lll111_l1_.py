# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㏚")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ㏛")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㏜"),l11l1l_l1_ (u"ࠬอำหใึหึะใๆ๋ࠢࠤฬ๊ืๅสสฮࠬ㏝")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1lllll_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll11lll_l1_(url)
	elif mode==454: results = l1lll1ll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㏞"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ㏟"),l11l1l_l1_ (u"ࠨࠩ㏠"),l11l1l_l1_ (u"ࠩࠪ㏡"),l11l1l_l1_ (u"ࠪࠫ㏢"),l11l1l_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㏣"))
	html = response.content
	l1l1lll_l1_ = SERVER(l11l11_l1_,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ㏤"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㏥"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㏦"),l11l1l_l1_ (u"ࠨࠩ㏧"),459,l11l1l_l1_ (u"ࠩࠪ㏨"),l11l1l_l1_ (u"ࠪࠫ㏩"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㏪"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㏫"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㏬")+l1111l_l1_+l11l1l_l1_ (u"ࠧๆอหฮฬะࠠๅ๊า๎ࠥ์สࠨ㏭"),l1l1lll_l1_,451,l11l1l_l1_ (u"ࠨࠩ㏮"),l11l1l_l1_ (u"ࠩࠪ㏯"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㏰"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏱"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㏲")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ㏳"),l1l1lll_l1_,451,l11l1l_l1_ (u"ࠧࠨ㏴"),l11l1l_l1_ (u"ࠨࠩ㏵"),l11l1l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㏶"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㏷"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㏸")+l1111l_l1_+l11l1l_l1_ (u"๋ࠬๅฬๆํ๊ࠬ㏹"),l1l1lll_l1_,451,l11l1l_l1_ (u"࠭ࠧ㏺"),l11l1l_l1_ (u"ࠧࠨ㏻"),l11l1l_l1_ (u"ࠨࡣࡦࡸࡴࡸࡳࠨ㏼"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㏽"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㏾")+l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥํๆะ์ฬࠫ㏿"),l1l1lll_l1_,451,l11l1l_l1_ (u"ࠬ࠭㐀"),l11l1l_l1_ (u"࠭ࠧ㐁"),l11l1l_l1_ (u"ࠧ࠱ࠩ㐂"))
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㐃"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㐄")+l1111l_l1_+l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤ์์ฯ๋ห้ࠣิฮไอหࠪ㐅"),l1l1lll_l1_,451,l11l1l_l1_ (u"ࠫࠬ㐆"),l11l1l_l1_ (u"ࠬ࠭㐇"),l11l1l_l1_ (u"࠭࠱ࠨ㐈"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐉"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㐊")+l1111l_l1_+l11l1l_l1_ (u"ࠩสๅ้อๅ้้ࠡำ๏ฯࠧ㐋"),l1l1lll_l1_,451,l11l1l_l1_ (u"ࠪࠫ㐌"),l11l1l_l1_ (u"ࠫࠬ㐍"),l11l1l_l1_ (u"ࠬ࠸ࠧ㐎"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㐏"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㐐"),l11l1l_l1_ (u"ࠨࠩ㐑"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠩ㐒"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㐓"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭㐔"): continue
			if title in l1l111_l1_: continue
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐕"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㐖")+l1111l_l1_+title,l1llll1_l1_,451)
	return
def l1lllll_l1_(url,l1lll11l11_l1_=l11l1l_l1_ (u"ࠧࠨ㐗")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㐘"),l11l1l_l1_ (u"ࠩࠪ㐙"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ㐚"),url,l11l1l_l1_ (u"ࠫࠬ㐛"),l11l1l_l1_ (u"ࠬ࠭㐜"),l11l1l_l1_ (u"࠭ࠧ㐝"),l11l1l_l1_ (u"ࠧࠨ㐞"),l11l1l_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭㐟"))
	html = response.content
	if l1lll11l11_l1_==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㐠"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡸࡣࡹࡩࡸࠨࠧ㐡"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	elif l1lll11l11_l1_==l11l1l_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㐢"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡒࡦࡥࡨࡲࡹࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ㐣"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	elif l11l1l_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㐤") in html:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㐥"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࠧࡇࡣࡵࡱࡵࡒࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㐦"),block,re.DOTALL)
	elif l1lll11l11_l1_ in [l11l1l_l1_ (u"ࠩ࠳ࠫ㐧"),l11l1l_l1_ (u"ࠪ࠵ࠬ㐨"),l11l1l_l1_ (u"ࠫ࠷࠭㐩")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩ㐪"),html,re.DOTALL)
		block = l1l11ll_l1_[int(l1lll11l11_l1_)]
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭㐫"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ㐬"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠨ็ืห์ีษࠨ㐭"),l11l1l_l1_ (u"ࠩไ๎้๋ࠧ㐮"),l11l1l_l1_ (u"ࠪห฿์๊สࠩ㐯"),l11l1l_l1_ (u"ࠫศเๆ๋หࠪ㐰"),l11l1l_l1_ (u"้ࠬไ๋สࠪ㐱"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬ㐲"),l11l1l_l1_ (u"่ࠧัสๅࠬ㐳"),l11l1l_l1_ (u"ࠨ็หหึอษࠨ㐴"),l11l1l_l1_ (u"ࠩ฼ี฻࠭㐵"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪ㐶"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪ㐷")]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠫ㐸") in html and l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠫ㐹") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㐺"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠨ࠱ࠪ㐻"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㐼"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭㐽"),title,re.DOTALL)
		#if any(value in title for value in l1ll11_l1_):
		if set(title.split()) & set(l1ll11_l1_) and l11l1l_l1_ (u"ู๊ࠫไิๆࠪ㐾") not in title:
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㐿"),l1111l_l1_+title,l1llll1_l1_,452,l1ll1l_l1_)
		elif l1ll1l1_l1_ and l11l1l_l1_ (u"࠭อๅไฬࠫ㑀") in title:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㑁") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㑂"),l1111l_l1_+title,l1llll1_l1_,453,l1ll1l_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑃"),l1111l_l1_+title,l1llll1_l1_,453,l1ll1l_l1_)
	if l1lll11l11_l1_ in [l11l1l_l1_ (u"ࠪࠫ㑄"),l11l1l_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㑅")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㑆"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㑇"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				#if l1llll1_l1_==l11l1l_l1_ (u"ࠢࠣ㑈"): continue
				title = unescapeHTML(title)
				#if title!=l11l1l_l1_ (u"ࠨࠩ㑉"):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑊"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩ㑋")+title,l1llll1_l1_,451)
	return
def l1lll11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㑌"),url,l11l1l_l1_ (u"ࠬ࠭㑍"),l11l1l_l1_ (u"࠭ࠧ㑎"),l11l1l_l1_ (u"ࠧࠨ㑏"),l11l1l_l1_ (u"ࠨࠩ㑐"),l11l1l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㑑"))
	html = response.content
	# l1lll1l_l1_
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡈࡧࡴࡦࡩࡲࡶࡾ࡙ࡵࡣࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㑒"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ㑓") in str(l1l111l_l1_):
		title = re.findall(l11l1l_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬ࠱ࠬ㑔"),html,re.DOTALL)
		title = title[0].strip(l11l1l_l1_ (u"࠭ࠠࠨ㑕"))
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㑖"),l1111l_l1_+title,url,454)
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㑗"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑘"),l1111l_l1_+title,l1llll1_l1_,454)
	else: l1lll1ll_l1_(url)
	return
def l1lll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ㑙"),url,l11l1l_l1_ (u"ࠫࠬ㑚"),l11l1l_l1_ (u"ࠬ࠭㑛"),l11l1l_l1_ (u"࠭ࠧ㑜"),l11l1l_l1_ (u"ࠧࠨ㑝"),l11l1l_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㑞"))
	html = response.content
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡄࡶࡪࡧࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㑟"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂࠬ㑠"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㑡"),l1111l_l1_+title,l1llll1_l1_,452,l1ll1l_l1_)
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㑢"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㑣"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				#if l1llll1_l1_==l11l1l_l1_ (u"ࠢࠣ㑤"): continue
				title = unescapeHTML(title)
				#if title!=l11l1l_l1_ (u"ࠨࠩ㑥"):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑦"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩ㑧")+title,l1llll1_l1_,454)
	return
def PLAY(url):
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭㑨"),l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤࡳ࡯ࡷ࡫ࡨࡷ࠴࠭㑩"))
	l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ㑪"),l11l1l_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ㑫"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ㑬"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ㑭"),l11l1l_l1_ (u"ࠪࠫ㑮"),l11l1l_l1_ (u"ࠫࠬ㑯"),l11l1l_l1_ (u"ࠬ࠭㑰"),l11l1l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㑱"))
	html = response.content
	l1l1lll_l1_ = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ㑲"))
	l1lll1_l1_ = []
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡕ࡫ࡷࡰࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࡴ࡫ࡧࡩࡃ࠭㑳"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ㑴"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㑵")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ㑶")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡹࡥ࡭ࡣࡵࡽࠧ࠭㑷"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ㑸"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			name = unescapeHTML(name)
			l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ㑹"),name,re.DOTALL)
			if l111ll1l_l1_:
				l111ll1l_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭㑺")+l111ll1l_l1_[0]
				name = l11l1l_l1_ (u"ࠩࠪ㑻")
			else: l111ll1l_l1_ = l11l1l_l1_ (u"ࠪࠫ㑼")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㑽")+name+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㑾")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㑿"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㒀"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩ㒁"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪ㒂"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ㒃"),l11l1l_l1_ (u"ࠫ࠰࠭㒄"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ㒅")+search
	l1lllll_l1_(url)
	return
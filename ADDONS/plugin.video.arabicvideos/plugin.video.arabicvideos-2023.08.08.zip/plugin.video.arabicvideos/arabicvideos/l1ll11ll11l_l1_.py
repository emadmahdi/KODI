# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ⩱")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡊࡘ࡚࡟ࠨ⩲")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ⩳"),l11l1l_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ⩴"),l11l1l_l1_ (u"ࠬะฬ่์ีࠤฬ๊อๅไสฮࠥอไใษา้ฮ࠭⩵")]
def MAIN(mode,url,text):
	if   mode==600: results = MENU()
	elif mode==601: results = l1lllll_l1_(url,text)
	elif mode==602: results = PLAY(url)
	elif mode==603: results = l1111_l1_(url,text)
	elif mode==604: results = l11lll_l1_(url)
	elif mode==609: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1l1lll_l1_,response = l1ll1l11lll_l1_(l11l11_l1_,l11l1l_l1_ (u"࠭ࡦࡰࡵࡷࡥࠬ⩶"),l11l1l_l1_ (u"ࠧࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠠโ๊ึฮฬ࠭⩷"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩸"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⩹"),l11l1l_l1_ (u"ࠪࠫ⩺"),609,l11l1l_l1_ (u"ࠫࠬ⩻"),l11l1l_l1_ (u"ࠬ࠭⩼"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⩽"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⩾"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⩿"),l11l1l_l1_ (u"ࠩࠪ⪀"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪁"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⪂")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆ็ํึฮ࠭⪃"),l1l1lll_l1_,601,l11l1l_l1_ (u"࠭ࠧ⪄"),l11l1l_l1_ (u"ࠧࠨ⪅"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⪆"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⪇"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⪈")+l1111l_l1_+l11l1l_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ⪉"),l1l1lll_l1_,601,l11l1l_l1_ (u"ࠬ࠭⪊"),l11l1l_l1_ (u"࠭ࠧ⪋"),l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⪌"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⪍"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⪎")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ⪏"),l1l1lll_l1_,601,l11l1l_l1_ (u"ࠫࠬ⪐"),l11l1l_l1_ (u"ࠬ࠭⪑"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ⪒"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⪓"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⪔")+l1111l_l1_+l11l1l_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭⪕"),l1l1lll_l1_,601,l11l1l_l1_ (u"ࠪࠫ⪖"),l11l1l_l1_ (u"ࠫࠬ⪗"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ⪘"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⪙"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⪚"),l11l1l_l1_ (u"ࠨࠩ⪛"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⪜"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⪝"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪞"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⪟")+l1111l_l1_+title,l1llll1_l1_,604)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⪠"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⪡"),l11l1l_l1_ (u"ࠨࠩ⪢"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭⪣"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ⪤"),html,re.DOTALL)
	for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠫࠬ⪥"))
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⪦"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⪧"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⪨")+l1111l_l1_+title,l1llll1_l1_,604)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⪩"),url,l11l1l_l1_ (u"ࠩࠪ⪪"),l11l1l_l1_ (u"ࠪࠫ⪫"),l11l1l_l1_ (u"ࠫࠬ⪬"),l11l1l_l1_ (u"ࠬ࠭⪭"),l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⪮"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⪯"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ⪰"),l11l1l_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ⪱"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⪲"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠫࠬ⪳"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⪴"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⪵"),l11l1l_l1_ (u"ࠧࠨ⪶"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⪷"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ⪸")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪹"),l1111l_l1_+title,l1llll1_l1_,601)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⪺"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⪻"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⪼"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⪽"),l11l1l_l1_ (u"ࠨࠩ⪾"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⪿"),l1111l_l1_+title,l1llll1_l1_,601)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠪࠫ⫀")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ⫁"),l11l1l_l1_ (u"ࠬ࠭⫂"),request,url)
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ⫃"):
		url,search = url.split(l11l1l_l1_ (u"ࠧࡀࠩ⫄"),1)
		data = l11l1l_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ⫅")+search
		headers = {l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⫆"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ⫇")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ⫈"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭⫉"),l11l1l_l1_ (u"࠭ࠧ⫊"),l11l1l_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⫋"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⫌"),url,l11l1l_l1_ (u"ࠩࠪ⫍"),l11l1l_l1_ (u"ࠪࠫ⫎"),l11l1l_l1_ (u"ࠫࠬ⫏"),l11l1l_l1_ (u"ࠬ࠭⫐"),l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⫑"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠧࠨ⫒"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⫓"))
	if request==l11l1l_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ⫔"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⫕"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠫࠬ⫖"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⫗"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⫘"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⫙"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⫚"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⫛"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⫝̸"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⫝"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ⫞"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⫟"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠧࠨ⫠"),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⫡"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⫢"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪ⫣"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩ⫤"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫ⫥"),l11l1l_l1_ (u"࠭ใๅ์หࠫ⫦"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭⫧"),l11l1l_l1_ (u"ࠨ้าหๆ࠭⫨"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩ⫩"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧ⫪"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫ⫫"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫ⫬"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭⫭")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩ⫮"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭⫯") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ⫰")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ⫱"))
		#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⫲") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ⫳")+l1ll1l_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ⫴"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ⫵"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ⫶"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⫷"),l1111l_l1_+title,l1llll1_l1_,602,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⫸"):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⫹"),l1111l_l1_+title,l1llll1_l1_,602,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⫺") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⫻"),l1111l_l1_+title,l1llll1_l1_,603,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⫼") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⫽"),l1111l_l1_+title,l1llll1_l1_,601,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⫾"),l1111l_l1_+title,l1llll1_l1_,603,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⫿"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⬀")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⬁"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⬂"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠧࠤࠩ⬃"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ⬄")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⬅"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⬆"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ⬇")+title,l1llll1_l1_,601)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⬈"),l11l1l_l1_ (u"࠭ࠧ⬉"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⬊"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⬋"),url,l11l1l_l1_ (u"ࠩࠪ⬌"),l11l1l_l1_ (u"ࠪࠫ⬍"),l11l1l_l1_ (u"ࠫࠬ⬎"),l11l1l_l1_ (u"ࠬ࠭⬏"),l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ⬐"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ⬑"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⬒"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪ⬓")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡵ࡮ࡤ࡮࡬ࡧࡰࡃࠢࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ⬔"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠫࠨ࠭⬕"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬖"),l1111l_l1_+title,url,603,l1ll1l_l1_,l11l1l_l1_ (u"࠭ࠧ⬗"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࠬ⬘")+l1l11_l1_+l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⬙"),html,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣ⬚"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⬛"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴࠭⬜")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ⬝"))
			title = title.replace(l11l1l_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫ⬞"),l11l1l_l1_ (u"ࠧࠡࠩ⬟"))
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⬠"),l1111l_l1_+title,l1llll1_l1_,602,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ⬡"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⬢") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴࠭⬣")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ⬤"))
		#		addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⬥"),l1111l_l1_+title,l1llll1_l1_,602,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⬦"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⬧"),url,l11l1l_l1_ (u"ࠩࠪ⬨"),l11l1l_l1_ (u"ࠪࠫ⬩"),l11l1l_l1_ (u"ࠫࠬ⬪"),l11l1l_l1_ (u"ࠬ࠭⬫"),l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⬬"))
	html = response.content
	# l1lll11_l1_ l11llll_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⬭"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	post = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡃࠧ⬮"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⬯"))
	post = post.replace(l11l1l_l1_ (u"ࠪࡠ࠴࠭⬰"),l11l1l_l1_ (u"ࠫ࠴࠭⬱"))
	post = EVAL(l11l1l_l1_ (u"ࠬࡪࡩࡤࡶࠪ⬲"),post)
	if l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡹࠧ⬳") in list(post.keys()):
		l1l1_l1_ = post[l11l1l_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳࠨ⬴")]
		l11ll1_l1_ = list(l1l1_l1_.keys())
		l1l1_l1_ = list(l1l1_l1_.values())
		l11111_l1_ = zip(l11ll1_l1_,l1l1_l1_)
		for title,l1llll1_l1_ in l11111_l1_:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⬵")+title+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⬶")
			l1lll1_l1_.append(l1llll1_l1_)
		l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠊࠥ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡥࡳࡪࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠭ࠫ࡭࡫ࡱ࡯ࠏࠏࠉࡩࡣࡶ࡬ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࡮ࡡࡴࡪࡀࠫ࠮ࡡ࠱࡞ࠌࠌࠍࡵࡧࡲࡵࡵࠣࡁࠥ࡮ࡡࡴࡪ࠱ࡷࡵࡲࡩࡵࠪࠪࡣࡤ࠭ࠩࠋࠋࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸࠦ࠽ࠡ࡝ࡠࠎࠎࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊࠋࡳࡥࡷࡺࠠ࠾ࠢࡥࡥࡸ࡫࠶࠵࠰ࡥ࠺࠹ࡪࡥࡤࡱࡧࡩ࠭ࡶࡡࡳࡶ࠮ࠫࡂ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡱࡣࡵࡸࠥࡃࠠࡱࡣࡵࡸ࠳ࡪࡥࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊࠋࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡰࡢࡴࡷ࠭ࠏࠏࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠊࠊࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࠫࡃ࠭࠮࡫ࡱ࡬ࡲ࠭ࡴࡥࡸࡡࡳࡥࡷࡺࡳࠪࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱ࠲ࠡ࡫ࡱࠤࡿࢀࡺ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠴࠱ࡷࡵࡲࡩࡵࠪࠪࠤࡂࡄࠠࠨࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡺࡥࡹࡩࡨࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠤࠥࠦ⬷")
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⬸"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⬹"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧ⬺"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨ⬻"): return
	search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪ⬼"),l11l1l_l1_ (u"ࠩ࠮ࠫ⬽"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ⬾")+search
	l111ll1_l1_,l1l1lllll_l1_ = l1ll1l11lll_l1_(url,l11l1l_l1_ (u"ࠫ࡫ࡵࡳࡵࡣࠪ⬿"),l11l1l_l1_ (u"ࠬࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠥ็่ิฬสࠫ⭀"))
	l1lllll_l1_(l111ll1_l1_,l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭⭁"))
	#url = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫ⭂")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭⭃"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡍ࠴ࡗࠪ㒆")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㒇")
l11lll11ll1_l1_ = [
		 l11l1l_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࠩ㒈")
		,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㒉"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㒊")
		,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㒋"),l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㒌")
		#,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㒍"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㒎"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㒏")
		,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㒐"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㒑")
		,l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㒒"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ㒓"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ㒔")
		,l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㒕"),l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㒖")
		,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ㒗"),l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㒘")
		,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ㒙"),l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭㒚"),l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭㒛")
		]
l11ll1lllll_l1_ = 4
def MAIN(mode,url,text,type,l11llll_l1_,l1ll1l1lll1_l1_):
	global l1111l_l1_
	try:
		l1l11l1l11l_l1_ = str(l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒜")])
		l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡐ࡙ࠬ㒝")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㒞")
	except: l1l11l1l11l_l1_ = l11l1l_l1_ (u"ࠪࠫ㒟")
	try: l111l11l_l1_ = str(l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭㒠")])
	except: l111l11l_l1_ = l11l1l_l1_ (u"ࠬ࠭㒡")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1l11l1l11l_l1_,l111l11l_l1_)
	elif mode==712: results = l1l1111lll1_l1_(l1l11l1l11l_l1_)
	elif mode==713: results = GROUPS(l1l11l1l11l_l1_,url,text,l11llll_l1_)
	elif mode==714: results = ITEMS(l1l11l1l11l_l1_,url,text,l11llll_l1_)
	elif mode==715: results = PLAY(l1l11l1l11l_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1l11l1l11l_l1_,True)
	elif mode==717: results = l1l11l1l1l1_l1_(l1l11l1l11l_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1l11l1l11l_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1l11l1l11l_l1_,url,l11llll_l1_)
	elif mode==720: results = MENU(l1l11l1l11l_l1_)
	elif mode==721: results = l11llllll1l_l1_(l1l11l1l11l_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1l11l1l11l_l1_)
	elif mode==723: results = ADD_USERAGENT(l1l11l1l11l_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1l11l1l11l_l1_,url,l11llll_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1l11l1l11l_l1_ in range(1,FOLDERS_COUNT+1):
		l11lll11lll_l1_ = l11l1l_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ㒢")+str(l1l11l1l11l_l1_)
		l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡏࡘࠫ㒣")+str(l1l11l1l11l_l1_)+l11l1l_l1_ (u"ࠨࡡࠪ㒤")
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㒥"),l1111l_l1_+l11l1l_l1_ (u"้ࠪั๊ฯࠡࠩ㒦")+text_numbers[l1l11l1l11l_l1_]+l11lll11lll_l1_,l11l1l_l1_ (u"ࠫࠬ㒧"),720,l11l1l_l1_ (u"ࠬ࠭㒨"),l11l1l_l1_ (u"࠭ࠧ㒩"),l11l1l_l1_ (u"ࠧࠨ㒪"),l11l1l_l1_ (u"ࠨࠩ㒫"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㒬"):l1l11l1l11l_l1_})
	return
def SECTIONS_MENU():
	global l1111l_l1_
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㒭"),l1111l_l1_+l11l1l_l1_ (u"ࠫัฺ๋๊ࠢฦๆุอๅࠨ㒮"),l11l1l_l1_ (u"ࠬ࠭㒯"),165,l11l1l_l1_ (u"࠭ࠧ㒰"),l11l1l_l1_ (u"ࠧࠨ㒱"),l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㒲"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㒳"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㒴"),l11l1l_l1_ (u"ࠫࠬ㒵"),9999)
	for l1l11l1l11l_l1_ in range(1,FOLDERS_COUNT+1):
		l11lll11lll_l1_ = l11l1l_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ㒶")+str(l1l11l1l11l_l1_)
		l1111l_l1_ = l11l1l_l1_ (u"࠭࡟ࡎࡗࠪ㒷")+str(l1l11l1l11l_l1_)+l11l1l_l1_ (u"ࠧࡠࠩ㒸")
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㒹"),l1111l_l1_+l11l1l_l1_ (u"ࠩฦๆุอๅࠡ็ฯ่ิࠦࠧ㒺")+text_numbers[l1l11l1l11l_l1_]+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࠫ㒻"),165,l11l1l_l1_ (u"ࠫࠬ㒼"),l11l1l_l1_ (u"ࠬ࠭㒽"),l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ㒾"),l11l1l_l1_ (u"ࠧࠨ㒿"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㓀"):l1l11l1l11l_l1_})
	return
def MENU(l1l11l1l11l_l1_=l11l1l_l1_ (u"ࠩࠪ㓁")):
	if l1l11l1l11l_l1_:
		l11ll11l111_l1_ = {l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓂"):l1l11l1l11l_l1_}
		l11lll11lll_l1_ = l11l1l_l1_ (u"ࠫࠬ㓃")  # l11l1l_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ㓄")+str(l1l11l1l11l_l1_)
	else:
		l11ll11l111_l1_ = l11l1l_l1_ (u"࠭ࠧ㓅")
		l11lll11lll_l1_ = l11l1l_l1_ (u"ࠧࠨ㓆")
	if CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True):
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㓇"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋่่ࠢๆอสࠨ㓈")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࠫ㓉"),729,l11l1l_l1_ (u"ࠫࠬ㓊"),l11l1l_l1_ (u"ࠬ࠭㓋"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㓌"),l11l1l_l1_ (u"ࠧࠨ㓍"),l11ll11l111_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㓎"),l1111l_l1_+l11l1l_l1_ (u"ࠩๅหห๋ษࠡลๅืฬ๋ࠧ㓏")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࠫ㓐"),165,l11l1l_l1_ (u"ࠫࠬ㓑"),l11l1l_l1_ (u"ࠬ࠭㓒"),l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ㓓"),l11l1l_l1_ (u"ࠧࠨ㓔"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㓕"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㓖"),l11l1l_l1_ (u"ࠪࠫ㓗"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓘"),l1111l_l1_+l11l1l_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโหࠪ㓙")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ㓚"),713,l11l1l_l1_ (u"ࠧࠨ㓛"),l11l1l_l1_ (u"ࠨࠩ㓜"),l11l1l_l1_ (u"ࠩࠪ㓝"),l11l1l_l1_ (u"ࠪࠫ㓞"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓟"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮ࠭㓠")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㓡"),713,l11l1l_l1_ (u"ࠧࠨ㓢"),l11l1l_l1_ (u"ࠨࠩ㓣"),l11l1l_l1_ (u"ࠩࠪ㓤"),l11l1l_l1_ (u"ࠪࠫ㓥"),l11ll11l111_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓦"),l1111l_l1_+l11l1l_l1_ (u"ࠬษแๅษ่ࠤ๊฻ๆโหࠪ㓧")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㓨"),713,l11l1l_l1_ (u"ࠧࠨ㓩"),l11l1l_l1_ (u"ࠨࠩ㓪"),l11l1l_l1_ (u"ࠩࠪ㓫"),l11l1l_l1_ (u"ࠪࠫ㓬"),l11ll11l111_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓭"),l1111l_l1_+l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦๅึ่ไอࠬ㓮")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㓯"),713,l11l1l_l1_ (u"ࠧࠨ㓰"),l11l1l_l1_ (u"ࠨࠩ㓱"),l11l1l_l1_ (u"ࠩࠪ㓲"),l11l1l_l1_ (u"ࠪࠫ㓳"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓴"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯࠧ㓵")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ㓶"),713,l11l1l_l1_ (u"ࠧࠨ㓷"),l11l1l_l1_ (u"ࠨࠩ㓸"),l11l1l_l1_ (u"ࠩࠪ㓹"),l11l1l_l1_ (u"ࠪࠫ㓺"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓻"),l1111l_l1_+l11l1l_l1_ (u"่ࠬๆ้ษอࠤ๊า็้ๆฬࠫ㓼")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭㓽"),713,l11l1l_l1_ (u"ࠧࠨ㓾"),l11l1l_l1_ (u"ࠨࠩ㓿"),l11l1l_l1_ (u"ࠩࠪ㔀"),l11l1l_l1_ (u"ࠪࠫ㔁"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㔂"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㔃"),l11l1l_l1_ (u"࠭ࠧ㔄"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔅"),l1111l_l1_+l11l1l_l1_ (u"ࠨไ้์ฬะࠠๆื้ๅฮ่ࠦๆำอฬฮ࠭㔆")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㔇"),713,l11l1l_l1_ (u"ࠪࠫ㔈"),l11l1l_l1_ (u"ࠫࠬ㔉"),l11l1l_l1_ (u"ࠬ࠭㔊"),l11l1l_l1_ (u"࠭ࠧ㔋"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔌"),l1111l_l1_+l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬฺ้ࠣ์แส๋้ࠢึะศสࠩ㔍")+l11lll11lll_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㔎"),713,l11l1l_l1_ (u"ࠪࠫ㔏"),l11l1l_l1_ (u"ࠫࠬ㔐"),l11l1l_l1_ (u"ࠬ࠭㔑"),l11l1l_l1_ (u"࠭ࠧ㔒"),l11ll11l111_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔓"),l1111l_l1_+l11l1l_l1_ (u"ࠨลไ่ฬ๋ࠠๆื้ๅฮ่ࠦๆำอฬฮ࠭㔔")+l11lll11lll_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㔕"),713,l11l1l_l1_ (u"ࠪࠫ㔖"),l11l1l_l1_ (u"ࠫࠬ㔗"),l11l1l_l1_ (u"ࠬ࠭㔘"),l11l1l_l1_ (u"࠭ࠧ㔙"),l11ll11l111_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔚"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊วหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ㔛")+l11lll11lll_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㔜"),713,l11l1l_l1_ (u"ࠪࠫ㔝"),l11l1l_l1_ (u"ࠫࠬ㔞"),l11l1l_l1_ (u"ࠬ࠭㔟"),l11l1l_l1_ (u"࠭ࠧ㔠"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔡"),l1111l_l1_+l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬ้ࠣัํ่ๅหࠣ์๊ืสษหࠪ㔢")+l11lll11lll_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㔣"),713,l11l1l_l1_ (u"ࠪࠫ㔤"),l11l1l_l1_ (u"ࠫࠬ㔥"),l11l1l_l1_ (u"ࠬ࠭㔦"),l11l1l_l1_ (u"࠭ࠧ㔧"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔨"),l1111l_l1_+l11l1l_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯ้ࠠ็ิฮอฯࠧ㔩")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㔪"),713,l11l1l_l1_ (u"ࠪࠫ㔫"),l11l1l_l1_ (u"ࠫࠬ㔬"),l11l1l_l1_ (u"ࠬ࠭㔭"),l11l1l_l1_ (u"࠭ࠧ㔮"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㔯"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㔰"),l11l1l_l1_ (u"ࠩࠪ㔱"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㔲"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊โ็๊สฮࠥอไฤื็๎ฮࠦศะ๊้ࠤฯเ๊๋ำࠪ㔳")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㔴"),713,l11l1l_l1_ (u"࠭ࠧ㔵"),l11l1l_l1_ (u"ࠧࠨ㔶"),l11l1l_l1_ (u"ࠨࠩ㔷"),l11l1l_l1_ (u"ࠩࠪ㔸"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㔹"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠡษ็วฺ๊๊สࠢหำํ์ࠠห฼ํ๎ึ࠭㔺")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㔻"),713,l11l1l_l1_ (u"࠭ࠧ㔼"),l11l1l_l1_ (u"ࠧࠨ㔽"),l11l1l_l1_ (u"ࠨࠩ㔾"),l11l1l_l1_ (u"ࠩࠪ㔿"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㕀"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㕁"),l11l1l_l1_ (u"ࠬ࠭㕂"),9999)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕃"),l1111l_l1_+l11l1l_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอ๋ࠥๆࠡลึ้ฬฬ็ศ๋้ࠢึะศสࠩ㕄")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡓࡇࡍࡆࡡࡖࡓࡗ࡚ࡅࡅࠩ㕅"),713,l11l1l_l1_ (u"ࠩࠪ㕆"),l11l1l_l1_ (u"ࠪࠫ㕇"),l11l1l_l1_ (u"ࠫࠬ㕈"),l11l1l_l1_ (u"ࠬ࠭㕉"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕊"),l1111l_l1_+l11l1l_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠡ็้ࠤศูๅศศ๊หࠥ๎ๅาฬหอࠬ㕋")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡒࡆࡓࡅࡠࡕࡒࡖ࡙ࡋࡄࠨ㕌"),713,l11l1l_l1_ (u"ࠩࠪ㕍"),l11l1l_l1_ (u"ࠪࠫ㕎"),l11l1l_l1_ (u"ࠫࠬ㕏"),l11l1l_l1_ (u"ࠬ࠭㕐"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㕑"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㕒"),l11l1l_l1_ (u"ࠨࠩ㕓"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕔"),l1111l_l1_+l11l1l_l1_ (u"ࠪๆ๋๎วหู่๋ࠢ็ษࠡ็้ࠤศ่ำศ็๊หࠥ๎ๅาฬหอࠬ㕕")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭㕖"),713,l11l1l_l1_ (u"ࠬ࠭㕗"),l11l1l_l1_ (u"࠭ࠧ㕘"),l11l1l_l1_ (u"ࠧࠨ㕙"),l11l1l_l1_ (u"ࠨࠩ㕚"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕛"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥี็ใฬࠤ๊์ࠠฤไึห๊ํว๊่ࠡีฯฮษࠨ㕜")+l11lll11lll_l1_,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࠬ㕝"),713,l11l1l_l1_ (u"ࠬ࠭㕞"),l11l1l_l1_ (u"࠭ࠧ㕟"),l11l1l_l1_ (u"ࠧࠨ㕠"),l11l1l_l1_ (u"ࠨࠩ㕡"),l11ll11l111_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㕢"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㕣"),l11l1l_l1_ (u"ࠫࠬ㕤"),9999)
	for seq in range(1,l11ll1lllll_l1_+1):
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㕥"),l1111l_l1_+l11l1l_l1_ (u"࠭ลืษไอࠥ๎ส฻์ํีࠥืวษูࠪ㕦")+l11lll11lll_l1_+l11l1l_l1_ (u"ࠧࠡࠩ㕧")+text_numbers[seq],l11l1l_l1_ (u"ࠨࠩ㕨"),711,l11l1l_l1_ (u"ࠩࠪ㕩"),l11l1l_l1_ (u"ࠪࠫ㕪"),l11l1l_l1_ (u"ࠫࠬ㕫"),l11l1l_l1_ (u"ࠬ࠭㕬"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕭"):l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࠩ㕮"):seq})
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕯"),l1111l_l1_+l11l1l_l1_ (u"ࠩหีฬ๋ฬࠡษ็ๆ๋๎วหࠢࠫะิ๎ไࠡใๅ฻࠮࠭㕰")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡇࡓࡋࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㕱"),713,l11l1l_l1_ (u"ࠫࠬ㕲"),l11l1l_l1_ (u"ࠬ࠭㕳"),l11l1l_l1_ (u"࠭ࠧ㕴"),l11l1l_l1_ (u"ࠧࠨ㕵"),l11ll11l111_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕶"),l1111l_l1_+l11l1l_l1_ (u"ࠩฦีู๐แࠡษ็ๆ๋๎วหࠢ็่ศ๐วๆࠢส่๊อึ๋หࠪ㕷")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㕸"),713,l11l1l_l1_ (u"ࠫࠬ㕹"),l11l1l_l1_ (u"ࠬ࠭㕺"),l11l1l_l1_ (u"࠭ࠧ㕻"),l11l1l_l1_ (u"ࠧࠨ㕼"),l11ll11l111_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕽"),l1111l_l1_+l11l1l_l1_ (u"ࠩฦีู๐แࠡสิห๊าࠠศๆๅ๊ํอสࠡๆ็ว๏อๅࠡษ็้ฬ฼๊สࠩ㕾")+l11lll11lll_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㕿"),713,l11l1l_l1_ (u"ࠫࠬ㖀"),l11l1l_l1_ (u"ࠬ࠭㖁"),l11l1l_l1_ (u"࠭ࠧ㖂"),l11l1l_l1_ (u"ࠧࠨ㖃"),l11ll11l111_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㖄"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㖅"),l11l1l_l1_ (u"ࠪࠫ㖆"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖇"),l1111l_l1_+l11l1l_l1_ (u"ࠬหึศใฬࠤศ๎ࠠห฼ํ๎ึࠦวีฬิห่࠭㖈")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖉"),711,l11l1l_l1_ (u"ࠧࠨ㖊"),l11l1l_l1_ (u"ࠨࠩ㖋"),l11l1l_l1_ (u"ࠩࠪ㖌"),l11l1l_l1_ (u"ࠪࠫ㖍"),l11ll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖎"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฿ฯะࠢไ๎ิ๐่่ษอࠫ㖏")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖐"),721,l11l1l_l1_ (u"ࠧࠨ㖑"),l11l1l_l1_ (u"ࠨࠩ㖒"),l11l1l_l1_ (u"ࠩࠪ㖓"),l11l1l_l1_ (u"ࠪࠫ㖔"),l11ll11l111_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖕"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็อึࠢสุฯืวไࠩ㖖")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖗"),716,l11l1l_l1_ (u"ࠧࠨ㖘"),l11l1l_l1_ (u"ࠨࠩ㖙"),l11l1l_l1_ (u"ࠩࠪ㖚"),l11l1l_l1_ (u"ࠪࠫ㖛"),l11ll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖜"),l1111l_l1_+l11l1l_l1_ (u"ࠬาไษ่่ࠢๆอสࠨ㖝")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖞"),712,l11l1l_l1_ (u"ࠧࠨ㖟"),l11l1l_l1_ (u"ࠨࠩ㖠"),l11l1l_l1_ (u"ࠩࠪ㖡"),l11l1l_l1_ (u"ࠪࠫ㖢"),l11ll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖣"),l1111l_l1_+l11l1l_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠨ㖤")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖥"),717,l11l1l_l1_ (u"ࠧࠨ㖦"),l11l1l_l1_ (u"ࠨࠩ㖧"),l11l1l_l1_ (u"ࠩࠪ㖨"),l11l1l_l1_ (u"ࠪࠫ㖩"),l11ll11l111_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖪"),l1111l_l1_+l11l1l_l1_ (u"ࠬอำหะาห๊ࠦวๅีํีๆืࠠศๆฦืึ฿ࠧ㖫")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖬"),722,l11l1l_l1_ (u"ࠧࠨ㖭"),l11l1l_l1_ (u"ࠨࠩ㖮"),l11l1l_l1_ (u"ࠩࠪ㖯"),l11l1l_l1_ (u"ࠪࠫ㖰"),l11ll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㖱"),l1111l_l1_+l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠢอ฾๏๐ัࠨ㖲")+l11lll11lll_l1_,l11l1l_l1_ (u"࠭ࠧ㖳"),723,l11l1l_l1_ (u"ࠧࠨ㖴"),l11l1l_l1_ (u"ࠨࠩ㖵"),l11l1l_l1_ (u"ࠩࠪ㖶"),l11l1l_l1_ (u"ࠪࠫ㖷"),l11ll11l111_l1_)
	return
def CHECK_ACCOUNT(l1l11l1l11l_l1_,l1ll_l1_=True):
	ok,status = False,l11l1l_l1_ (u"ࠫࠬ㖸")
	l11ll111ll1_l1_,l1l11l1ll1l_l1_ = l11l1l_l1_ (u"ࠬ࠭㖹"),l11l1l_l1_ (u"࠭ࠧ㖺")
	l11l1lll1ll_l1_,l11lll111l1_l1_,server,username,password = GET_URL(l1l11l1l11l_l1_)
	if username==l11l1l_l1_ (u"ࠧࠨ㖻"): return
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭㖼")+l1l11l1l11l_l1_)
	headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㖽"):l111ll1l1l_l1_}
	if l11l1lll1ll_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ㖾"),l11l1lll1ll_l1_,l11l1l_l1_ (u"ࠫࠬ㖿"),headers,False,l11l1l_l1_ (u"ࠬ࠭㗀"),l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ㗁"))
		html = response.content
		if response.succeeded:
			timestamp,l11ll11111l_l1_,l11l1lll1l1_l1_,l11l1l1l1l1_l1_,l11lll11l1l_l1_ = 0,0,l11l1l_l1_ (u"ࠧࠨ㗂"),l11l1l_l1_ (u"ࠨࠩ㗃"),l11l1l_l1_ (u"ࠩࠪ㗄")
			try:
				dict = EVAL(l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㗅"),html)
				status = dict[l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ㗆")][l11l1l_l1_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ㗇")]
				ok = True
				l11l1lll1l1_l1_ = dict[l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠫ㗈")][l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡤࡴ࡯ࡸࠩ㗉")]
			except: pass
			if l11l1lll1l1_l1_:
				try:
					struct = time.strptime(l11l1lll1l1_l1_,l11l1l_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ㗊"))
					timestamp = int(time.mktime(struct))
					l11ll11111l_l1_ = int(now-timestamp)
					l11ll11111l_l1_ = int((l11ll11111l_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11l1l_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ㗋")][l11l1l_l1_ (u"ࠪࡧࡷ࡫ࡡࡵࡧࡧࡣࡦࡺࠧ㗌")]))
					l11l1l1l1l1_l1_ = time.strftime(l11l1l_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨ㗍"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㗎")][l11l1l_l1_ (u"࠭ࡥࡹࡲࡢࡨࡦࡺࡥࠨ㗏")]))
					l11lll11l1l_l1_ = time.strftime(l11l1l_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ㗐"),struct)
				except: pass
			settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࡤ࠭㗑")+l1l11l1l11l_l1_,str(now))
			settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡥ࡫ࡩࡪࡤ࠭㗒")+l1l11l1l11l_l1_,str(l11ll11111l_l1_))
			try:
				l11lll1lll1_l1_ = l11l1l_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡴࡦࡰࠤ࠽ࠫ㗓")+html.split(l11l1l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡤ࡯࡮ࡧࡱࠥ࠾ࠬ㗔"))[1]
				l11lll1lll1_l1_ = l11lll1lll1_l1_.replace(l11l1l_l1_ (u"ࠬࡀࠧ㗕"),l11l1l_l1_ (u"࠭࠺ࠡࠩ㗖")).replace(l11l1l_l1_ (u"ࠧ࠭ࠩ㗗"),l11l1l_l1_ (u"ࠨ࠮ࠣࠫ㗘")).replace(l11l1l_l1_ (u"ࠩࢀࢁࠬ㗙"),l11l1l_l1_ (u"ࠪࢁࠬ㗚"))
				new = re.findall(l11l1l_l1_ (u"ࠫࠧࡻࡲ࡭ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࠢࡱࡱࡵࡸࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㗛"),l11lll1lll1_l1_,re.DOTALL)
				l11ll111ll1_l1_,l1l11l1ll1l_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㗜")][l11l1l_l1_ (u"࠭࡭ࡢࡺࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࡳࠨ㗝")]
				l11llll1l1l_l1_ = dict[l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ㗞")][l11l1l_l1_ (u"ࠨࡣࡦࡸ࡮ࡼࡥࡠࡥࡲࡲࡸ࠭㗟")]
				l1l11111l1l_l1_ = dict[l11l1l_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ㗠")][l11l1l_l1_ (u"ࠪ࡭ࡸࡥࡴࡳ࡫ࡤࡰࠬ㗡")]
				parts = l11l1lll1ll_l1_.split(l11l1l_l1_ (u"ࠫࡄ࠭㗢"),1)
				message = l11l1l_l1_ (u"࡛ࠬࡒࡍ࠼ࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㗣")+l11l1lll1ll_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗤")
				message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡘࡺࡡࡵࡷࡶ࠾ࠥࠦࠧ㗥")+l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㗦")+status+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㗧")
				message += l11l1l_l1_ (u"ࠪࡠࡳ࡚ࡲࡪࡣ࡯࠾ࠥࠦࠠࠡࠩ㗨")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㗩")+str(l1l11111l1l_l1_==l11l1l_l1_ (u"ࠬ࠷ࠧ㗪"))+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗫")
				message += l11l1l_l1_ (u"ࠧ࡝ࡰࡆࡶࡪࡧࡴࡦࡦࠣࠤࡆࡺ࠺ࠡࠢࠪ㗬")+l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㗭")+l11l1l1l1l1_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㗮")
				message += l11l1l_l1_ (u"ࠪࡠࡳࡋࡸࡱ࡫ࡵࡽࠥࡊࡡࡵࡧ࠽ࠤࠥ࠭㗯")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㗰")+l11lll11l1l_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㗱")
				message += l11l1l_l1_ (u"࠭࡜࡯ࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࡸࠦࠠࠡࠪࠣࡅࡨࡺࡩࡷࡧࠣ࠳ࠥࡓࡡࡹ࡫ࡰࡹࡲࠦࠩࠡ࠼ࠣࠤࠬ㗲")+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㗳")+l11llll1l1l_l1_+l11l1l_l1_ (u"ࠨࠢ࠲ࠤࠬ㗴")+max+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㗵")
				message += l11l1l_l1_ (u"ࠪࡠࡳࡇ࡬࡭ࡱࡺࡩࡩࠦࡏࡶࡶࡳࡹࡹࡹ࠺ࠡࠢࠣࠫ㗶")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㗷")+l11l1l_l1_ (u"ࠧࠦࠬࠡࠤ㗸").join(dict[l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ㗹")][l11l1l_l1_ (u"ࠧࡢ࡮࡯ࡳࡼ࡫ࡤࡠࡱࡸࡸࡵࡻࡴࡠࡨࡲࡶࡲࡧࡴࡴࠩ㗺")])+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㗻")
				message += l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㗼")+l11lll1lll1_l1_
				if status==l11l1l_l1_ (u"ࠪࡅࡨࡺࡩࡷࡧࠪ㗽"): DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠫฬ๊วีฬิหฺ่๊ࠦ็็ࠤอี่็ุ่ࠢฬ้ไࠨ㗾"),message)
				else: DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠬ๐ศะ๊ࠣว๋ࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅษืฮึอใࠨ㗿"),message)
	if l11l1lll1ll_l1_ and ok and status==l11l1l_l1_ (u"࠭ࡁࡤࡶ࡬ࡺࡪ࠭㘀"):
		LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㘁"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡊࡒࡗ࡚࡛ࠥࡒࡍࠢࠣࠤࡠࠦࡉࡑࡖ࡙ࠤࡦࡩࡣࡰࡷࡱࡸࠥ࡯ࡳࠡࡑࡎࠤࡢࠦࠠࠡ࡝ࠣࠫ㘂")+l11l1lll1ll_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬ㘃"))
		succeeded = True
	else:
		LOG_THIS(l11l1l_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㘄"),l11l1l_l1_ (u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡉࡑࡖ࡙ࠤ࡚ࡘࡌࠡࠢࠣ࡟ࠥࡊ࡯ࡦࡵࠣࡲࡴࡺࠠࡸࡱࡵ࡯ࠥࡣࠠࠡࠢ࡞ࠤࠬ㘅")+l11l1lll1ll_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ㘆"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㘇"),l11l1l_l1_ (u"ࠧࠨ㘈"),l11l1l_l1_ (u"ࠨใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠫ㘉"),l11l1l_l1_ (u"ࠩิหอ฽ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦวๅาํࠤ็๋สࠡษ้ฮࠥฮลืษไฮ์ࠦลๅ๋ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์฼้้ࠦร้ࠢส่ึอศุࠢ฽๎ึࠦๅ้ฮ๋ำࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲ࠥษะ่สࠣษ้๏ࠠใษษ้ฮࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ๎โๆࠢหษ฻อแสࠢิหอ฽ࠠแࡋࡓࡘ࡛ࠦฬะ์าࠤศ๎ࠠใ็ࠣฬส฻ไศฯࠣห้ืวษูࠣห้่ฯ๋็ࠪ㘊"))
		succeeded = False
	return succeeded,l11ll111ll1_l1_,l1l11l1ll1l_l1_
def ITEMS(l1l11l1l11l_l1_,l11l1l11l11_l1_,l11lll111ll_l1_,l11ll11l1ll_l1_,l1ll_l1_=True):
	if not l11ll11l1ll_l1_: l11ll11l1ll_l1_ = l11l1l_l1_ (u"ࠪ࠵ࠬ㘋")
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,l1ll_l1_): return
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l11l11_l1_)
	l11lll1l1ll_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㘌"),l11l1l11l11_l1_,l11lll111ll_l1_)
	end = int(l11ll11l1ll_l1_)*100
	start = end-100
	for context,title,url,l1ll1l_l1_ in l11lll1l1ll_l1_[start:end]:
		l1l111l1111_l1_ = (l11l1l_l1_ (u"ࠬࡍࡒࡐࡗࡓࡉࡉ࠭㘍") in l11l1l11l11_l1_ or l11l1l11l11_l1_==l11l1l_l1_ (u"࠭ࡁࡍࡎࠪ㘎"))
		l11lll11111_l1_ = (l11l1l_l1_ (u"ࠧࡈࡔࡒ࡙ࡕࡋࡄࠨ㘏") not in l11l1l11l11_l1_ and l11l1l11l11_l1_!=l11l1l_l1_ (u"ࠨࡃࡏࡐࠬ㘐"))
		if l1l111l1111_l1_ or l11lll11111_l1_:
			if   l11l1l_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ㘑")  in l11l1l11l11_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘒"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠫࠬ㘓"),l11l1l_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ㘔"),l11l1l_l1_ (u"࠭ࠧ㘕"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㘖"):l1l11l1l11l_l1_}])
			elif l11l1l_l1_ (u"ࠨࡇࡓࡋࠬ㘗") 		 in l11l1l11l11_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㘘"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠪࠫ㘙"),l11l1l_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭㘚"),l11l1l_l1_ (u"ࠬ࠭㘛"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘜"):l1l11l1l11l_l1_}])
			elif l11l1l_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ㘝") in l11l1l11l11_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘞"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠩࠪ㘟"),l11l1l_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭㘠"),l11l1l_l1_ (u"ࠫࠬ㘡"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㘢"):l1l11l1l11l_l1_}])
			elif l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࠫ㘣") 	 in l11l1l11l11_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㘤"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠨࠩ㘥"),l11l1l_l1_ (u"ࠩࠪ㘦"),context,{l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘧"):l1l11l1l11l_l1_}])
			else: menuItemsLIST.append([l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㘨"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠬ࠭㘩"),l11l1l_l1_ (u"࠭ࠧ㘪"),l11l1l_l1_ (u"ࠧࠨ㘫"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘬"):l1l11l1l11l_l1_}])
	total = len(l11lll1l1ll_l1_)
	PAGINATION(l1l11l1l11l_l1_,l11ll11l1ll_l1_,l11l1l11l11_l1_,714,total,l11lll111ll_l1_)
	return
def SHOW_EMPTY(l11l1lll111_l1_):
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㘭"),l11l1lll111_l1_+l11l1l_l1_ (u"๋ࠪีํࠠศๆๅหห๋ษࠡว่หࠥ็วา฼ฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠫ㘮"),l11l1l_l1_ (u"ࠫࠬ㘯"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㘰"),l11l1lll111_l1_+l11l1l_l1_ (u"࠭ร้ࠢส่ำีๅสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢสุฯืวไๅࠪ㘱"),l11l1l_l1_ (u"ࠧࠨ㘲"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㘳"),l11l1lll111_l1_+l11l1l_l1_ (u"ࠩฦ์ࠥืวษูࠣࡑ࠸࡛เࠡษ็ิ๏ࠦร็ฬࠣว฻็ส่ࠢ฽๎ึࠦีฮ์ะࠫ㘴"),l11l1l_l1_ (u"ࠪࠫ㘵"),9999)
	return
def GROUPS(l1l11l1l11l_l1_,l11l1l11l11_l1_,l11lll111ll_l1_,l11ll11l1ll_l1_,l1l1l111_l1_=l11l1l_l1_ (u"ࠫࠬ㘶"),l1ll_l1_=True):
	if not l11ll11l1ll_l1_: l11ll11l1ll_l1_ = l11l1l_l1_ (u"ࠬ࠷ࠧ㘷")
	l11l1lll111_l1_ = l1111l_l1_
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,l1ll_l1_): return False
	if l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㘸") in l11lll111ll_l1_: l11ll11llll_l1_,l11l1ll1l11_l1_ = l11lll111ll_l1_.split(l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㘹"))
	else: l11ll11llll_l1_,l11l1ll1l11_l1_ = l11lll111ll_l1_,l11l1l_l1_ (u"ࠨࠩ㘺")
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l11l11_l1_)
	l11lllll11l_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㘻"),l11l1l11l11_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ㘼"))
	if not l11lllll11l_l1_: return False
	l1l111llll1_l1_ = []
	for group,l1ll1l_l1_ in l11lllll11l_l1_:
		if l1l1l111_l1_:
			if l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㘽") in group: l11l1lll111_l1_ = l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ㘾")
			elif l11l1l_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡤࠧࠡࠨ㘿") in group: l11l1lll111_l1_ = l11l1l_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ㙀")
			elif l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㙁") in l11l1l11l11_l1_: l11l1lll111_l1_ = l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㙂")
			else: l11l1lll111_l1_ = l11l1l_l1_ (u"࡚ࠪࡎࡊࡅࡐࡕࠪ㙃")
			l11l1lll111_l1_ = l11l1l_l1_ (u"ࠫ࠱ࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㙄")+l11l1lll111_l1_+l11l1l_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㙅")
		if l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㙆") in group: l1l1111l1ll_l1_,l11l1l111ll_l1_ = group.split(l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㙇"))
		else: l1l1111l1ll_l1_,l11l1l111ll_l1_ = group,l11l1l_l1_ (u"ࠨࠩ㙈")
		if not l11lll111ll_l1_:
			if l1l1111l1ll_l1_ in l1l111llll1_l1_: continue
			l1l111llll1_l1_.append(l1l1111l1ll_l1_)
			if l11l1l_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࠩ㙉") in l1l1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㙊"),l11l1lll111_l1_+l1l1111l1ll_l1_,l11l1l11l11_l1_,168,l11l1l_l1_ (u"ࠫࠬ㙋"),l11l1l_l1_ (u"ࠬ࠷ࠧ㙌"),group,l11l1l_l1_ (u"࠭ࠧ㙍"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙎"):l1l11l1l11l_l1_})
			elif l11l1l_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㙏") in group: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙐"),l11l1lll111_l1_+l1l1111l1ll_l1_,l11l1l11l11_l1_,713,l11l1l_l1_ (u"ࠪࠫ㙑"),l11l1l_l1_ (u"ࠫ࠶࠭㙒"),group,l11l1l_l1_ (u"ࠬ࠭㙓"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙔"):l1l11l1l11l_l1_})
			else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙕"),l11l1lll111_l1_+l1l1111l1ll_l1_,l11l1l11l11_l1_,714,l11l1l_l1_ (u"ࠨࠩ㙖"),l11l1l_l1_ (u"ࠩ࠴ࠫ㙗"),group,l11l1l_l1_ (u"ࠪࠫ㙘"),{l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㙙"):l1l11l1l11l_l1_})
		elif l11l1l_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ㙚") in group and l1l1111l1ll_l1_==l11ll11llll_l1_:
			if l11l1l111ll_l1_ in l1l111llll1_l1_: continue
			l1l111llll1_l1_.append(l11l1l111ll_l1_)
			if l11l1l_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࠭㙛") in l1l1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙜"),l11l1lll111_l1_+l11l1l111ll_l1_,l11l1l11l11_l1_,168,l11l1l_l1_ (u"ࠨࠩ㙝"),l11l1l_l1_ (u"ࠩ࠴ࠫ㙞"),group,l11l1l_l1_ (u"ࠪࠫ㙟"),{l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㙠"):l1l11l1l11l_l1_})
			else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㙡"),l11l1lll111_l1_+l11l1l111ll_l1_,l11l1l11l11_l1_,714,l1ll1l_l1_,l11l1l_l1_ (u"࠭࠱ࠨ㙢"),group,l11l1l_l1_ (u"ࠧࠨ㙣"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㙤"):l1l11l1l11l_l1_})
	#if l11l1l_l1_ (u"ࠩࡖࡓࡗ࡚ࡅࡅࠩ㙥") in l11l1l11l11_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1l111_l1_:
		end = int(l11ll11l1ll_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1l11l1l11l_l1_,l11ll11l1ll_l1_,l11l1l11l11_l1_,713,total,l11lll111ll_l1_)
	return True
def EPG_ITEMS(l1l11l1l11l_l1_,url,function):
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ㙦")+l1l11l1l11l_l1_)
	headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㙧"):l111ll1l1l_l1_}
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True): return
	timestamp = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡡࠪ㙨")+l1l11l1l11l_l1_)
	if not timestamp or now-int(timestamp)>24*l11l1ll1ll1_l1_:
		succeeded,l11ll111ll1_l1_,l1l11l1ll1l_l1_ = CHECK_ACCOUNT(l1l11l1l11l_l1_,False)
		if not succeeded: return
	l11ll11111l_l1_ = int(settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡵ࡫ࡰࡩࡩ࡯ࡦࡧࡡࠪ㙩")+l1l11l1l11l_l1_))
	server = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ㙪")+l1l11l1l11l_l1_)
	username = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡣࠬ㙫")+l1l11l1l11l_l1_)
	password = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡴࡦࡹࡳࡸࡱࡵࡨࡤ࠭㙬")+l1l11l1l11l_l1_)
	l11ll111l11_l1_ = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ㙭"))
	l11l1l1l111_l1_ = l11ll111l11_l1_[-1].replace(l11l1l_l1_ (u"ࠫ࠳ࡺࡳࠨ㙮"),l11l1l_l1_ (u"ࠬ࠭㙯")).replace(l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㙰"),l11l1l_l1_ (u"ࠧࠨ㙱"))
	if function==l11l1l_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ㙲"): l1l11l11l1l_l1_ = l11l1l_l1_ (u"ࠩࡪࡩࡹࡥࡳࡩࡱࡵࡸࡤ࡫ࡰࡨࠩ㙳")
	else: l1l11l11l1l_l1_ = l11l1l_l1_ (u"ࠪ࡫ࡪࡺ࡟ࡴ࡫ࡰࡴࡱ࡫࡟ࡥࡣࡷࡥࡤࡺࡡࡣ࡮ࡨࠫ㙴")
	l11l1lll1ll_l1_,l11lll111l1_l1_,server,username,password = GET_URL(l1l11l1l11l_l1_)
	if not username: return
	l11ll1l11l1_l1_ = l11l1lll1ll_l1_+l11l1l_l1_ (u"ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࠭㙵")+l1l11l11l1l_l1_+l11l1l_l1_ (u"ࠬࠬࡳࡵࡴࡨࡥࡲࡥࡩࡥ࠿ࠪ㙶")+l11l1l1l111_l1_
	html = OPENURL_CACHED(NO_CACHE,l11ll1l11l1_l1_,l11l1l_l1_ (u"࠭ࠧ㙷"),headers,l11l1l_l1_ (u"ࠧࠨ㙸"),l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡅࡑࡉࡢࡍ࡙ࡋࡍࡔ࠯࠵ࡲࡩ࠭㙹"))
	l11lll1ll11_l1_ = EVAL(l11l1l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㙺"),html)
	l11l1ll11ll_l1_ = l11lll1ll11_l1_[l11l1l_l1_ (u"ࠪࡩࡵ࡭࡟࡭࡫ࡶࡸ࡮ࡴࡧࡴࠩ㙻")]
	l11ll1ll1l1_l1_ = []
	if function in [l11l1l_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㙼"),l11l1l_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ㙽")]:
		for dict in l11l1ll11ll_l1_:
			if dict[l11l1l_l1_ (u"࠭ࡨࡢࡵࡢࡥࡷࡩࡨࡪࡸࡨࠫ㙾")]==1:
				l11ll1ll1l1_l1_.append(dict)
				if function in [l11l1l_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ㙿")]: break
		if not l11ll1ll1l1_l1_: return
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㚀"),l1111l_l1_+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬ๊ๅๅใสฮࠥอไฤ๊็๎ࠥฮ็ั้ࠣห้่วว็ฬࠤ็ีࠠๅษࠣฮ฾๋ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㚁"),l11l1l_l1_ (u"ࠪࠫ㚂"),9999)
		if function in [l11l1l_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㚃")]:
			l1l11l1l111_l1_ = 2
			l11l1ll1l1l_l1_ = l1l11l1l111_l1_*l11l1ll1ll1_l1_
			l11ll1ll1l1_l1_ = []
			l1l11ll11ll_l1_ = int(int(dict[l11l1l_l1_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ㚄")])/l11l1ll1l1l_l1_)*l11l1ll1l1l_l1_
			l1l1111l11l_l1_ = now+l11l1ll1l1l_l1_
			l11l1l1l1ll_l1_ = int((l1l1111l11l_l1_-l1l11ll11ll_l1_)/l11l1ll1ll1_l1_)
			for count in range(l11l1l1l1ll_l1_):
				if count>=6:
					if count%l1l11l1l111_l1_!=0: continue
					l1l11ll11_l1_ = l11l1ll1l1l_l1_
				else: l1l11ll11_l1_ = l11l1ll1l1l_l1_//2
				l11l1l1lll1_l1_ = l1l11ll11ll_l1_+count*l11l1ll1ll1_l1_
				dict = {}
				dict[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㚅")] = l11l1l_l1_ (u"ࠧࠨ㚆")
				struct = time.localtime(l11l1l1lll1_l1_-l11ll11111l_l1_-l11l1ll1ll1_l1_)
				dict[l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ㚇")] = time.strftime(l11l1l_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭㚈"),struct)
				dict[l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ㚉")] = str(l11l1l1lll1_l1_)
				dict[l11l1l_l1_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ㚊")] = str(l11l1l1lll1_l1_+l1l11ll11_l1_)
				l11ll1ll1l1_l1_.append(dict)
	elif function in [l11l1l_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ㚋"),l11l1l_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ㚌")]: l11ll1ll1l1_l1_ = l11l1ll11ll_l1_
	if function==l11l1l_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ㚍") and len(l11ll1ll1l1_l1_)>0:
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㚎"),l1111l_l1_+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึ็ࠡไสส๊ฯࠠษำส้ัࠦวๅไ้์ฬะࠠࠩฮา์้ࠦแใูࠬไࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㚏"),l11l1l_l1_ (u"ࠪࠫ㚐"),9999)
	l11ll1l1lll_l1_ = []
	l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ㚑"))
	for dict in l11ll1ll1l1_l1_:
		title = base64.b64decode(dict[l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㚒")])
		if kodi_version>18.99: title = title.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㚓"))
		l11l1l1lll1_l1_ = int(dict[l11l1l_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ㚔")])
		l1l111l11l1_l1_ = int(dict[l11l1l_l1_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ㚕")])
		l1l1111ll11_l1_ = str(int((l1l111l11l1_l1_-l11l1l1lll1_l1_+59)/60))
		l1l11ll1lll_l1_ = dict[l11l1l_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㚖")].replace(l11l1l_l1_ (u"ࠪࠤࠬ㚗"),l11l1l_l1_ (u"ࠫ࠿࠭㚘"))
		struct = time.localtime(l11l1l1lll1_l1_-l11l1ll1ll1_l1_)
		l1l111111l1_l1_ = time.strftime(l11l1l_l1_ (u"ࠬࠫࡈ࠻ࠧࡐࠫ㚙"),struct)
		l1l1111ll1l_l1_ = time.strftime(l11l1l_l1_ (u"࠭ࠥࡢࠩ㚚"),struct)
		if function==l11l1l_l1_ (u"ࠧࡔࡊࡒࡖ࡙ࡥࡅࡑࡉࠪ㚛"): title = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㚜")+l1l111111l1_l1_+l11l1l_l1_ (u"ࠩࠣไࠥ࠭㚝")+title+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㚞")
		elif function==l11l1l_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㚟"): title = l1l1111ll1l_l1_+l11l1l_l1_ (u"ࠬࠦࠧ㚠")+l1l111111l1_l1_+l11l1l_l1_ (u"࠭ࠠࠩࠩ㚡")+l1l1111ll11_l1_+l11l1l_l1_ (u"ࠧ࡮࡫ࡱ࠭ࠬ㚢")
		else: title = l1l1111ll1l_l1_+l11l1l_l1_ (u"ࠨࠢࠪ㚣")+l1l111111l1_l1_+l11l1l_l1_ (u"ࠩࠣࠬࠬ㚤")+l1l1111ll11_l1_+l11l1l_l1_ (u"ࠪࡱ࡮ࡴࠩࠡࠢࠣࠫ㚥")+title+l11l1l_l1_ (u"ࠫࠥๆࠧ㚦")
		if function in [l11l1l_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ㚧"),l11l1l_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ㚨"),l11l1l_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ㚩")]:
			l11lll1ll1l_l1_ = server+l11l1l_l1_ (u"ࠨ࠱ࡷ࡭ࡲ࡫ࡳࡩ࡫ࡩࡸ࠴࠭㚪")+username+l11l1l_l1_ (u"ࠩ࠲ࠫ㚫")+password+l11l1l_l1_ (u"ࠪ࠳ࠬ㚬")+l1l1111ll11_l1_+l11l1l_l1_ (u"ࠫ࠴࠭㚭")+l1l11ll1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ㚮")+l11l1l1l111_l1_+l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㚯")
			if function==l11l1l_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ㚰"): addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㚱"),l1111l_l1_+title,l11lll1ll1l_l1_,9999,l1ll1l_l1_,l11l1l_l1_ (u"ࠩࠪ㚲"),l11l1l_l1_ (u"ࠪࠫ㚳"),l11l1l_l1_ (u"ࠫࠬ㚴"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㚵"):l1l11l1l11l_l1_})
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㚶"),l1111l_l1_+title,l11lll1ll1l_l1_,235,l1ll1l_l1_,l11l1l_l1_ (u"ࠧࠨ㚷"),l11l1l_l1_ (u"ࠨࠩ㚸"),l11l1l_l1_ (u"ࠩࠪ㚹"),{l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㚺"):l1l11l1l11l_l1_})
		l11ll1l1lll_l1_.append(title)
	if function==l11l1l_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ㚻") and l11ll1l1lll_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11ll1l1lll_l1_)
	return l11ll1l1lll_l1_
def USE_FASTER_SERVER(l1l11l1l11l_l1_):
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True): return
	server,l11ll111l1l_l1_,l1l11ll1l1l_l1_ = l11l1l_l1_ (u"ࠬ࠭㚼"),0,0
	succeeded,l11ll111ll1_l1_,l1l11l1ll1l_l1_ = CHECK_ACCOUNT(l1l11l1l11l_l1_,False)
	if succeeded:
		l1l11l11l11_l1_ = DNS_RESOLVER(l11ll111ll1_l1_)
		l11ll111l1l_l1_ = PING(l1l11l11l11_l1_[0],int(l1l11l1ll1l_l1_))
		l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ㚽"))
		groups = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㚾"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ㚿"))
		l11lll1l1ll_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㛀"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㛁"),groups[1])
		url = l11lll1l1ll_l1_[0][2]
		l1l11111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ㛂"),url,re.DOTALL)
		l1l11111l11_l1_ = l1l11111l11_l1_[0]
		if l11l1l_l1_ (u"ࠬࡀࠧ㛃") in l1l11111l11_l1_: l11llll111l_l1_,l1l111ll11l_l1_ = l1l11111l11_l1_.split(l11l1l_l1_ (u"࠭࠺ࠨ㛄"))
		else: l11llll111l_l1_,l1l111ll11l_l1_ = l1l11111l11_l1_,l11l1l_l1_ (u"ࠧ࠹࠲ࠪ㛅")
		l11l1l1ll11_l1_ = DNS_RESOLVER(l11llll111l_l1_)
		l1l11ll1l1l_l1_ = PING(l11l1l1ll11_l1_[0],int(l1l111ll11l_l1_))
	if l11ll111l1l_l1_ and l1l11ll1l1l_l1_:
		message = l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊รึๆํࠤศ๋ࠠศๆึ๎ึ็ัࠡษ็วุืูࠡมࠤࠥࠬ㛆")
		message += l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㛇")+l11l1l_l1_ (u"ࠪ์็ะࠠืษษ฽ࠥ็๊ࠡษ็ื๏ืแาࠢส่ศ฻ไ๋ࠩ㛈")+l11l1l_l1_ (u"ࠫࡡࡴࠧ㛉")+str(int(l1l11ll1l1l_l1_*1000))+l11l1l_l1_ (u"ࠬࠦๅๅ์ࠣฯฬ์๊สࠩ㛊")
		message += l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ㛋")+l11l1l_l1_ (u"้ࠧไอࠤ฻อฦฺࠢไ๎ࠥอไิ์ิๅึࠦวๅสา๎้࠭㛌")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ㛍")+str(int(l11ll111l1l_l1_*1000))+l11l1l_l1_ (u"้้ࠩࠣ๐ࠠฬษ้๎ฮ࠭㛎")
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㛏"),l11l1l_l1_ (u"ࠫฬ๊ำ๋ำไีࠥอไฤื็๎ࠬ㛐"),l11l1l_l1_ (u"ࠬอไิ์ิๅึࠦวๅลึี฾࠭㛑"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㛒"),message)
		if l1ll11111l_l1_==1 and l11ll111l1l_l1_<l1l11ll1l1l_l1_: server = l11ll111ll1_l1_+l11l1l_l1_ (u"ࠧ࠻ࠩ㛓")+l1l11l1ll1l_l1_
	else: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㛔"),l11l1l_l1_ (u"ࠩࠪ㛕"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㛖"),l11l1l_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํะิࠦวๅีํีๆืࠠศๆหำ๏๊ࠧ㛗"))
	settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ㛘")+l1l11l1l11l_l1_,server)
	return
def PLAY(l1l11l1l11l_l1_,url,type):
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㛙")+l1l11l1l11l_l1_)
	if l111ll1l1l_l1_: url = url+l11l1l_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭㛚")+l111ll1l1l_l1_
	#l11111lll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ㛛")+l1l11l1l11l_l1_)
	#if l11111lll1_l1_:
	#	l11lllll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬ㛜"),url,re.DOTALL)
	#	url = url.replace(l11lllll1ll_l1_[0],l11111lll1_l1_)
	PLAY_VIDEO(url,l1ll1_l1_,type)
	return
def ADD_USERAGENT(l1l11l1l11l_l1_):
	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㛝"),l11l1l_l1_ (u"ࠫࠬ㛞"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㛟"),l11l1l_l1_ (u"࠭สฮาํี๋ࠥ็ๆ๋๋ࠢฬ๋ࠠอัสࠤ࠳๊ࠦาฮ์ࠤ฾ีๅࠡฬ฽๎๏ื็ࠡวำห้ࠥๆหࠢ็หࠥะูาใ้ࠣฬࠦ็้ࠢ࠱ࠤࠥ๎ูะ็ࠣฮ฿๐๊า้ࠣษ้อฺ่ࠠาࠤฬ๊ึา๊ิอࠥอไใื๋ํࠥ࠴ࠠศๆะหัฯࠠๅ้ำหࠥอไห฼ํ๎ึࠦ็๋ࠢไๆ฼ࠦลัษࠣ฻้ฮสࠡ็้็ฺࠥัไหࠣไࡒ࠹ࡕࠡล้ࠤฯ฿ๅๅ๊ࠢิฬࠦวๅฬ฽๎๏ืࠠ࠯๋ࠢๅ็฽ฺ่ࠠา้ฬࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡓ࠳ࡖࠢอัฯอฬࠡโࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฮศืࠪ㛠"))
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㛡")+l1l11l1l11l_l1_)
	l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㛢"),l11l1l_l1_ (u"ࠩสืฯิฯศ็ࠣห้ษีๅ์ࠪ㛣"),l11l1l_l1_ (u"ࠪฮ฾ี๊ๅࠢส่็ี๊ๆࠩ㛤"),l111ll1l1l_l1_,l11l1l_l1_ (u"ࠫ์ึว้๋ࠡࠤๅ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠢสู่๊สฯั่ࠤาอไ๋ษ้ࠣ฾ࠦเࡎ࠵ࡘࠤฬ๊ะ๋ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฻า๎้ํࠠฤ็ࠣฮึ๐ฯࠡว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊สฬสํฮࠥอไฤื็๎ࠥ๎วๅฬํࠤฯ่ั๋สสࠤฯ์วิสࠣะ๊๐ูࠡึิ็ฬะࠠแࡏ࠶࡙ࠥลࠡࠨ㛥"))
	if l11l1ll1lll_l1_==1: l111ll1l1l_l1_ = OPEN_KEYBOARD(l11l1l_l1_ (u"ࠬษใหสࠣไࡒ࠹ࡕࠡࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥาฯ๋ัࠪ㛦"),l111ll1l1l_l1_,True)
	else: l111ll1l1l_l1_ = l11l1l_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ㛧")
	if l111ll1l1l_l1_==l11l1l_l1_ (u"ࠧࠡࠩ㛨"):
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㛩"),l11l1l_l1_ (u"ࠩࠪ㛪"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㛫"),l11l1l_l1_ (u"ࠫ฿๐ัࠡ็ึ้ํำࠠฤีอาิอๅࠡใิห฿ࠦไ้ฯา๋ࠥษ่ࠡ฻าอࠥ็ัศ฼สฮ๊่ࠥฮั๊หࠥ࠴࠮࠯ࠢํะอࠦลๆษࠣฮึ้็ࠡใสี฿ࠦสๆษ่หࠥษ่ࠡวูหๆฯࠠฮำไࠤศ๎ࠠฤ์ุࠣ๏ࠦยฯำ้ࠣ฾ํวࠨ㛬"))
		return
	l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㛭"),l11l1l_l1_ (u"࠭ࠧ㛮"),l11l1l_l1_ (u"ࠧࠨ㛯"),l111ll1l1l_l1_,l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็๋ࠣีอࠠแࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥฮฯๅษ้๋ࠣࠦࠠศๆๅำ๏๋ࠠภࠩ㛰"))
	if l11l1ll1lll_l1_!=1:
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㛱"),l11l1l_l1_ (u"ࠪࠫ㛲"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㛳"),l11l1l_l1_ (u"ࠬะๅࠡษ็ษ้เวยࠩ㛴"))
		return
	settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㛵")+l1l11l1l11l_l1_,l111ll1l1l_l1_)
	l1l1111lll1_l1_(l1l11l1l11l_l1_)
	return
def GET_URL(l1l11l1l11l_l1_,l11l1lllll1_l1_=l11l1l_l1_ (u"ࠧࠨ㛶")):
	if not l11l1lllll1_l1_: l11l1lllll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡶࡱࡥࠧ㛷")+l1l11l1l11l_l1_)
	server = SERVER(l11l1lllll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭㛸"))
	username = re.findall(l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠮࠮ࠫࡁࠬࠪࠬ㛹"),l11l1lllll1_l1_+l11l1l_l1_ (u"ࠫࠫ࠭㛺"),re.DOTALL)
	password = re.findall(l11l1l_l1_ (u"ࠬࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ㛻"),l11l1lllll1_l1_+l11l1l_l1_ (u"࠭ࠦࠨ㛼"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㛽"),l11l1l_l1_ (u"ࠨࠩ㛾"),l11l1l_l1_ (u"ࠩไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠬ㛿"),l11l1l_l1_ (u"ࠪีฬฮืࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡋࡓࡘ่࡛ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡌࡔ࡙࡜ࠠอัํำࠥษ่ࠡไ่ࠤอหีๅษะࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠫ㜀"))
		return l11l1l_l1_ (u"ࠫࠬ㜁"),l11l1l_l1_ (u"ࠬ࠭㜂"),l11l1l_l1_ (u"࠭ࠧ㜃"),l11l1l_l1_ (u"ࠧࠨ㜄"),l11l1l_l1_ (u"ࠨࠩ㜅")
	username = username[0]
	password = password[0]
	l11l1lll1ll_l1_ = server+l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹࡦࡴࡢࡥࡵ࡯࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧ㜆")+username+l11l1l_l1_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧ㜇")+password
	l11lll111l1_l1_ = server+l11l1l_l1_ (u"ࠫ࠴࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ㜈")+username+l11l1l_l1_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ㜉")+password+l11l1l_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂࡳ࠳ࡶࡡࡳࡰࡺࡹࠧ㜊")
	return l11l1lll1ll_l1_,l11lll111l1_l1_,server,username,password
def GET_FILENAME(l1l11l1l11l_l1_,l1l11l111ll_l1_=l11l1l_l1_ (u"ࠧࠨ㜋")):
	l11llll1l11_l1_ = l1l11l111ll_l1_.replace(l11l1l_l1_ (u"ࠨ࠱ࠪ㜌"),l11l1l_l1_ (u"ࠩࡢࠫ㜍")).replace(l11l1l_l1_ (u"ࠪ࠾ࠬ㜎"),l11l1l_l1_ (u"ࠫࡤ࠭㜏")).replace(l11l1l_l1_ (u"ࠬ࠴ࠧ㜐"),l11l1l_l1_ (u"࠭࡟ࠨ㜑"))
	l11llll1l11_l1_ = l11llll1l11_l1_.replace(l11l1l_l1_ (u"ࠧࡀࠩ㜒"),l11l1l_l1_ (u"ࠨࡡࠪ㜓")).replace(l11l1l_l1_ (u"ࠩࡀࠫ㜔"),l11l1l_l1_ (u"ࠪࡣࠬ㜕")).replace(l11l1l_l1_ (u"ࠫࠫ࠭㜖"),l11l1l_l1_ (u"ࠬࡥࠧ㜗"))
	l11llll1l11_l1_ = os.path.join(addoncachefolder,l11llll1l11_l1_).strip(l11l1l_l1_ (u"࠭࠮࡮࠵ࡸࠫ㜘"))+l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹࠬ㜙")
	return l11llll1l11_l1_
def ADD_ACCOUNT(l1l11l1l11l_l1_,l111l11l_l1_):
	l1l1111l111_l1_ = l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㜚")
	if l111l11l_l1_: l1l1111l111_l1_ = l11l1l_l1_ (u"ࠩศฺฬ็ษ๊ࠡอ฾๏๐ัࠡำสฬ฼ࠦࠧ㜛")+text_numbers[int(l111l11l_l1_)]
	l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㜜"),l11l1l_l1_ (u"ࠫࠬ㜝"),l11l1l_l1_ (u"ࠬ࠭㜞"),l1l1111l111_l1_,l11l1l_l1_ (u"࠭็ัษࠣห้าาย่๊ࠢࠥอไษำ้ห๊า๋ࠠฯอหัࠦัศสฺࠤๆ๐ฯ๋๊๊หฯࠦๅ็ࠢส่ส์สา่อࠤศ๎ࠠฤึอีฬ้ࠠๆัไ์฾ࠦๅ็ࠢสู่ืใศฬࠣห้ะ๊ࠡฬห๎฾ํ้ࠠษ็ีฬฮืࠡ็้ࠤ๋๎ูࠡ࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࡭࠴ࡷ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯๋๋ࠢีอࠠๆอส่๊ࠥสุ้ํัฺࠥใๅ๊ࠢิฬࠦวๅำสฬ฼ࠦ࡜࡯ࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡵࡺࡶ࠮ࡱࡵ࡫࠳࡭ࡩࡵࡪࡸࡦ࠳࡯࡯࠰࡫ࡳࡸࡻ࠵࡬ࡢࡰࡪࡹࡦ࡭ࡥࡴ࠱ࡤࡶࡦ࠴࡭࠴ࡷࠣࡠࡳࠦ็ๅࠢอี๏ีࠠฦุสๅฮࠦร้ࠢอ฾๏๐ัࠡล๋ࠤู๊อࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨ㜟"))
	if l11l1ll1lll_l1_!=1: return
	l1l111lllll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ㜠")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠨࡡࠪ㜡")+l111l11l_l1_)
	l1l11l11111_l1_ = True
	if l1l111lllll_l1_:
		l11l1ll1lll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜢"),l11l1l_l1_ (u"ࠪ็ฯอศสࠢฯำ๏ีࠧ㜣"),l11l1l_l1_ (u"ࠫฯ฿ฯ๋ๆࠣห้่ฯ๋็ࠪ㜤"),l11l1l_l1_ (u"๋ࠬำฮࠢส่็ี๊ๆࠩ㜥"),l11l1l_l1_ (u"࠭วๅำสฬ฼ࠦวๅฯส่๏ࠦ็้࠼ࠪ㜦"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㜧")+l1l111lllll_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜨")+l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴ่ࠠาสࠤ์๎ࠠาษห฻ࠥๆࡍ࠴ࡗࠣห้๋ำอๆࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦสฺัํ่์ࠦรๆࠢอี๏ีࠠไฬสฬฮࠦัศสฺࠤัี๊ะࠢยࠥࠬ㜩"))
		if l11l1ll1lll_l1_==-1: return
		elif l11l1ll1lll_l1_==0: l1l111lllll_l1_ = l11l1l_l1_ (u"ࠪࠫ㜪")
		elif l11l1ll1lll_l1_==2:
			l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㜫"),l11l1l_l1_ (u"ࠬ࠭㜬"),l11l1l_l1_ (u"࠭ࠧ㜭"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㜮"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦวๅำสฬ฼ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ㜯"))
			if l11l1ll1lll_l1_ in [-1,0]: return
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㜰"),l11l1l_l1_ (u"ࠪࠫ㜱"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㜲"),l11l1l_l1_ (u"ࠬะๅࠡ็ึัࠥอไาษห฻ࠬ㜳"))
			l1l11l11111_l1_ = False
			l11ll1ll111_l1_ = l11l1l_l1_ (u"࠭ࠧ㜴")
	if l1l11l11111_l1_:
		l11ll1ll111_l1_ = OPEN_KEYBOARD(l11l1l_l1_ (u"ࠧศๅอฬࠥืวษูࠣไࡒ࠹ࡕࠡๅส้้อࠧ㜵"),l1l111lllll_l1_)
		l11ll1ll111_l1_ = l11ll1ll111_l1_.strip(l11l1l_l1_ (u"ࠨࠢࠪ㜶"))
		if not l11ll1ll111_l1_:
			l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜷"),l11l1l_l1_ (u"ࠪࠫ㜸"),l11l1l_l1_ (u"ࠫࠬ㜹"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㜺"),l11l1l_l1_ (u"࠭ไใัࠣๆ๊ะࠠษวาาฬ๊ࠠาษห฻ࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฬ๊ัศสฺࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠬ㜻"))
			if l11l1ll1lll_l1_ in [-1,0]: return
			DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㜼"),l11l1l_l1_ (u"ࠨࠩ㜽"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㜾"),l11l1l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣห้ืวษูࠪ㜿"))
		else:
			#l11l1lll1ll_l1_,l11lll111l1_l1_,server,username,password = GET_URL(l1l11l1l11l_l1_)
			#if not username: return
			message = l11l1l_l1_ (u"ࠫ์ึ็ࠡษ็้฾๊่ๆษอࠤฯ๋ࠠฤะำ๋ฬࠦๅ็ࠢิหอ฽ࠠแࡏ࠶࡙ࠥอไั์ࠣห๋ะࠠไฬหฮ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊หࠥลࠡ࡝ࡰࠪ㝀")
			#message += l11l1l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㝁")+server+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ฺ่๋ห๋ࠦวๅีํีๆื࠺ࠡࠩ㝂")
			#message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㝃")+username+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟สื๊ࠦวๅ็ึฮำีๅ࠻ࠢࠪ㝄")
			#message += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㝅")+password+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ่๊ๅสࠢสุ่ื࠺ࠡࠩ㝆")
			l11l1ll1lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࠬ㝇"),l11l1l_l1_ (u"ࠬ࠭㝈"),l11l1l_l1_ (u"࠭ࠧ㝉"),l11l1l_l1_ (u"ࠧศๆิหอ฽ࠠศๆฯำ๏ี่๊ࠠ࠽ࠫ㝊"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㝋")+l11ll1ll111_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㝌")+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㝍")+message)
			if l11l1ll1lll_l1_!=1:
				DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㝎"),l11l1l_l1_ (u"ࠬ࠭㝏"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㝐"),l11l1l_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ㝑"))
				return
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㝒")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㝓")+l111l11l_l1_,l11ll1ll111_l1_)
	#settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࡟ࠨ㝔")+l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠫࠬ㝕"))
	#settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ㝖")+l1l11l1l11l_l1_,l11l1l_l1_ (u"࠭ࠧ㝗"))
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㝘")+l1l11l1l11l_l1_)
	if not l111ll1l1l_l1_: settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ㝙")+l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ㝚"))
	#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝛"),l11l1l_l1_ (u"ࠫࠬ㝜"),l11l1l_l1_ (u"ࠬ࠭㝝"),l11l1l_l1_ (u"࠭ࠧ㝞"),l11ll1ll111_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲฯ๋ࠠห฼ํีࠥืวษูࠣหูะัศๅࠣไࡒ࠹ࡕࠡว็ํࠥํะศࠢส่ึอศุࠢส่ัี๊ะࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤ์ึวࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨ㝟"))
	#if l1ll11111l_l1_==1: ok,l11ll111ll1_l1_,l1l11l1ll1l_l1_ = CHECK_ACCOUNT(l1l11l1l11l_l1_,True)
	l1l1111lll1_l1_(l1l11l1l11l_l1_)
	return
def READ_ALL_LINES(lines,l1l11l111l1_l1_,l11llll11l1_l1_,l11l1l111l_l1_,length,l11llll1lll_l1_,l11lll111l1_l1_):
	l11lll1l1ll_l1_,l11l1ll11l1_l1_ = [],[]
	l11l1llll11_l1_ = [l11l1l_l1_ (u"ࠨ࠰ࡤࡺ࡮࠭㝠"),l11l1l_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ㝡"),l11l1l_l1_ (u"ࠪ࠲ࡲࡱࡶࠨ㝢"),l11l1l_l1_ (u"ࠫ࠳࡬࡬ࡷࠩ㝣"),l11l1l_l1_ (u"ࠬ࠴࡭ࡱ࠵ࠪ㝤"),l11l1l_l1_ (u"࠭࠮ࡸࡧࡥࡱࠬ㝥")]
	for line in lines:
		if l11llll1lll_l1_%473==0:
			PROGRESS_UPDATE(l11l1l111l_l1_,40+int(10*l11llll1lll_l1_/length),l11l1l_l1_ (u"ࠧใำสลฮࠦวๅใํำ๏๎็ศฬࠪ㝦"),l11l1l_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢิๆ๊ࡀ࠭ࠨ㝧"),str(l11llll1lll_l1_)+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭㝨")+str(length))
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return None,None,None
		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ㝩") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㝪"),1)
			url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㝫")+url
		elif l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㝬") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ㝭"),1)
			url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㝮")+url
		elif l11l1l_l1_ (u"ࠩࡵࡸࡲࡶ࠺ࠨ㝯") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠪࡶࡹࡳࡰ࠻ࠩ㝰"),1)
			url = l11l1l_l1_ (u"ࠫࡷࡺ࡭ࡱ࠼ࠪ㝱")+url
		else:
			l11l1ll11l1_l1_.append({l11l1l_l1_ (u"ࠬࡲࡩ࡯ࡧࠪ㝲"):line})
			continue
		l1l11111ll1_l1_,context,group,title,type,l11llllllll_l1_ = {},l11l1l_l1_ (u"࠭ࠧ㝳"),l11l1l_l1_ (u"ࠧࠨ㝴"),l11l1l_l1_ (u"ࠨࠩ㝵"),l11l1l_l1_ (u"ࠩࠪ㝶"),False
		try:
			line,title = line.rsplit(l11l1l_l1_ (u"ࠪࠦ࠱࠭㝷"),1)
			line = line+l11l1l_l1_ (u"ࠫࠧ࠭㝸")
		except:
			try: line,title = line.rsplit(l11l1l_l1_ (u"ࠬ࠷ࠬࠨ㝹"),1)
			except: title = l11l1l_l1_ (u"࠭ࠧ㝺")
		l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ㝻")] = url
		params = re.findall(l11l1l_l1_ (u"ࠨࠢࠫ࠲࠯ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㝼"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11l1l_l1_ (u"ࠩࠥࠫ㝽"),l11l1l_l1_ (u"ࠪࠫ㝾")).strip(l11l1l_l1_ (u"ࠫࠥ࠭㝿"))
			l1l11111ll1_l1_[key] = value.strip(l11l1l_l1_ (u"ࠬࠦࠧ㞀"))
		keys = list(l1l11111ll1_l1_.keys())
		if not title:
			if l11l1l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㞁") in keys and l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㞂")]: title = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭㞃")]
		l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㞄")] = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ㞅")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ㞆"),l11l1l_l1_ (u"ࠬࠦࠧ㞇")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ㞈"),l11l1l_l1_ (u"ࠧࠡࠩ㞉"))
		if l11l1l_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭㞊") in keys:
			l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩ࡬ࡱ࡬࠭㞋")] = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠪࡰࡴ࡭࡯ࠨ㞌")]
			del l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫࡱࡵࡧࡰࠩ㞍")]
		else: l1l11111ll1_l1_[l11l1l_l1_ (u"ࠬ࡯࡭ࡨࠩ㞎")] = l11l1l_l1_ (u"࠭ࠧ㞏")
		if l11l1l_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭㞐") in keys and l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㞑")]: group = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ㞒")]
		if any(value in url.lower() for value in l11l1llll11_l1_): l11llllllll_l1_ = True
		if l11llllllll_l1_ or l11l1l_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㞓") in group or l11l1l_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ㞔") in group:
			type = l11l1l_l1_ (u"ࠬ࡜ࡏࡅࠩ㞕")
			if l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㞖") in group: type = type+l11l1l_l1_ (u"ࠧࡠࡕࡈࡖࡎࡋࡓࠨ㞗")
			elif l11l1l_l1_ (u"ࠨࡡࡢࡑࡔ࡜ࡉࡆࡕࡢࡣࠬ㞘") in group: type = type+l11l1l_l1_ (u"ࠩࡢࡑࡔ࡜ࡉࡆࡕࠪ㞙")
			else: type = type+l11l1l_l1_ (u"ࠪࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬ㞚")
			group = group.replace(l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㞛"),l11l1l_l1_ (u"ࠬ࠭㞜")).replace(l11l1l_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ㞝"),l11l1l_l1_ (u"ࠧࠨ㞞"))
		else:
			type = l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㞟")
			if title in l1l11l111l1_l1_: context = context+l11l1l_l1_ (u"ࠩࡢࡉࡕࡍࠧ㞠")
			if title in l11llll11l1_l1_: context = context+l11l1l_l1_ (u"ࠪࡣࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㞡")
			if not group: type = type+l11l1l_l1_ (u"ࠫࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭㞢")
			else: type = type+context
		group = group.strip(l11l1l_l1_ (u"ࠬࠦࠧ㞣")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ㞤"),l11l1l_l1_ (u"ࠧࠡࠩ㞥")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ㞦"),l11l1l_l1_ (u"ࠩࠣࠫ㞧"))
		if l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࠩ㞨") in type: group = l11l1l_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡏࡍ࡛ࡋ࡟ࡠࠣࠤࠫ㞩")
		elif l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪ㞪") in type: group = l11l1l_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣ࡛ࡕࡄࡠࡡࠤࠥࠬ㞫")
		elif l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࠫ㞬") in type:
			l1l111lll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠ࡜ࡕࡶࡡࡡࡪࠫࠡ࠭࡞ࡉࡪࡣ࡜ࡥ࠭ࠪ㞭"),l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㞮")],re.DOTALL)
			if l1l111lll1l_l1_: l1l111lll1l_l1_ = l1l111lll1l_l1_[0]
			else: l1l111lll1l_l1_ = l11l1l_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡕࡈࡖࡎࡋࡓࡠࡡࠤࠥࠬ㞯")
			group = group+l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㞰")+l1l111lll1l_l1_
		l11ll1lll1_l1_ = l11l1l_l1_ (u"ࠬ࠭㞱")
		if l11l1l_l1_ (u"࠭ࡩࡥࠩ㞲") in keys:
			l11ll1lll1_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧࡪࡦࠪ㞳")]
			del l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨ࡫ࡧࠫ㞴")]
		if l11l1l_l1_ (u"ࠩࡌࡈࠬ㞵") in keys:
			l11ll1lll1_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠪࡍࡉ࠭㞶")]
			del l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫࡎࡊࠧ㞷")]
		if l11l1l_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡳࡷ࡭ࠧ㞸") in l11lll111l1_l1_ and l11l1l_l1_ (u"࠭࠮ࠨ㞹") in l11ll1lll1_l1_:
			l11ll1lll1_l1_ = l11ll1lll1_l1_.rsplit(l11l1l_l1_ (u"ࠧ࠯ࠩ㞺"),1)[1]
			l11ll1lll1_l1_ = l11l1l_l1_ (u"ࠨࡾࠪ㞻")+l11ll1lll1_l1_.upper()+l11l1l_l1_ (u"ࠩࡿࠤࠬ㞼")
		if l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ㞽") in keys: del l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㞾")]
		title = l11ll1lll1_l1_+l1l11111ll1_l1_[l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㞿")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l11llll1111_l1_,title = SPLIT_NAME(title)
		l1l11111ll1_l1_[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࠫ㟀")] = type
		l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㟁")] = context
		l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㟂")] = group.upper()
		l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㟃")] = title.upper()
		try: l1l11111ll1_l1_[l11l1l_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㟄")] = COUNTRIES_CODES[l11llll1111_l1_.upper()]
		except: l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㟅")] = l11llll1111_l1_.upper()
		#dictt1[l11l1l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㟆")] = countryy.upper()
		l1l11111ll1_l1_[l11l1l_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ㟇")] = language.upper()
		l11lll1l1ll_l1_.append(l1l11111ll1_l1_)
		l11llll1lll_l1_ += 1
	return l11lll1l1ll_l1_,l11llll1lll_l1_,l11l1ll11l1_l1_
def CLEAN_NAME(title):
	title = title.replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ㟈"),l11l1l_l1_ (u"ࠨࠢࠪ㟉")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ㟊"),l11l1l_l1_ (u"ࠪࠤࠬ㟋")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ㟌"),l11l1l_l1_ (u"ࠬࠦࠧ㟍"))
	title = title.replace(l11l1l_l1_ (u"࠭ࡼࡽࠩ㟎"),l11l1l_l1_ (u"ࠧࡽࠩ㟏")).replace(l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ㟐"),l11l1l_l1_ (u"ࠩ࠽ࠫ㟑")).replace(l11l1l_l1_ (u"ࠪ࠱࠲࠭㟒"),l11l1l_l1_ (u"ࠫ࠲࠭㟓"))
	title = title.replace(l11l1l_l1_ (u"ࠬࡡ࡛ࠨ㟔"),l11l1l_l1_ (u"࡛࠭ࠨ㟕")).replace(l11l1l_l1_ (u"ࠧ࡞࡟ࠪ㟖"),l11l1l_l1_ (u"ࠨ࡟ࠪ㟗"))
	title = title.replace(l11l1l_l1_ (u"ࠩࠫࠬࠬ㟘"),l11l1l_l1_ (u"ࠪࠬࠬ㟙")).replace(l11l1l_l1_ (u"ࠫ࠮࠯ࠧ㟚"),l11l1l_l1_ (u"ࠬ࠯ࠧ㟛"))
	title = title.replace(l11l1l_l1_ (u"࠭࠼࠽ࠩ㟜"),l11l1l_l1_ (u"ࠧ࠽ࠩ㟝")).replace(l11l1l_l1_ (u"ࠨࡀࡁࠫ㟞"),l11l1l_l1_ (u"ࠩࡁࠫ㟟"))
	title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ㟠"))
	return title
def CREATE_GROUPED_STREAMS(l11ll1ll1ll_l1_,l11l1l111l_l1_,l111l11l_l1_):
	l11llll11ll_l1_ = {}
	for l11ll1ll1_l1_ in l11lll11ll1_l1_: l11llll11ll_l1_[l11ll1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࠭㟡")+l111l11l_l1_] = []
	length = len(l11ll1ll1ll_l1_)
	l1l1l11ll1_l1_ = str(length)
	l11llll1lll_l1_ = 0
	l11l1ll11l1_l1_ = []
	for l1l11111ll1_l1_ in l11ll1ll1ll_l1_:
		if l11llll1lll_l1_%873==0:
			PROGRESS_UPDATE(l11l1l111l_l1_,50+int(5*l11llll1lll_l1_/length),l11l1l_l1_ (u"ࠬะี็์ไࠤฬ๊แ๋ัํ์์อสࠡษ็฾๏ืࠠๆำอฬฮ࠭㟢"),l11l1l_l1_ (u"࠭วๅใํำ๏๎ࠠาไ่࠾࠲࠭㟣"),str(l11llll1lll_l1_)+l11l1l_l1_ (u"ࠧࠡ࠱ࠣࠫ㟤")+l1l1l11ll1_l1_)
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return None,None
		group,context,title,url,l1ll1l_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㟥")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ㟦")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㟧")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ㟨")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠬ࡯࡭ࡨࠩ㟩")]
		l11llll1111_l1_,language,l11ll1ll1_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㟪")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ㟫")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭㟬")]
		l1l111l1lll_l1_ = (group,context,title,url,l1ll1l_l1_)
		l1lll11l1ll_l1_ = False
		if l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㟭") in l11ll1ll1_l1_:
			if l11l1l_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ㟮") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ㟯")+l111l11l_l1_].append(l1l111l1lll_l1_)
			elif l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࠪ㟰") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭㟱")+l111l11l_l1_].append(l1l111l1lll_l1_)
			else: l1lll11l1ll_l1_ = True
			l11llll11ll_l1_[l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ㟲")+l111l11l_l1_].append(l1l111l1lll_l1_)
		elif l11l1l_l1_ (u"ࠨࡘࡒࡈࠬ㟳") in l11ll1ll1_l1_:
			if l11l1l_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ㟴") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㟵")+l111l11l_l1_].append(l1l111l1lll_l1_)
			elif l11l1l_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫ㟶") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ㟷")+l111l11l_l1_].append(l1l111l1lll_l1_)
			elif l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭㟸") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭㟹")+l111l11l_l1_].append(l1l111l1lll_l1_)
			else: l1lll11l1ll_l1_ = True
			l11llll11ll_l1_[l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ㟺")+l111l11l_l1_].append(l1l111l1lll_l1_)
		else: l1lll11l1ll_l1_ = True
		if l1lll11l1ll_l1_: l11l1ll11l1_l1_.append(l1l11111ll1_l1_)
		l11llll1lll_l1_ += 1
	l11lll1l1l1_l1_ = sorted(l11ll1ll1ll_l1_,reverse=False,key=lambda key: key[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㟻")].lower())
	del l11ll1ll1ll_l1_
	l1l1l11ll1_l1_ = str(length)
	l11llll1lll_l1_ = 0
	for l1l11111ll1_l1_ in l11lll1l1l1_l1_:
		l11llll1lll_l1_ += 1
		if l11llll1lll_l1_%873==0:
			PROGRESS_UPDATE(l11l1l111l_l1_,55+int(5*l11llll1lll_l1_/length),l11l1l_l1_ (u"ࠪฮฺ์๊โࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ิฮอฯࠧ㟼"),l11l1l_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ㟽"),str(l11llll1lll_l1_)+l11l1l_l1_ (u"ࠬࠦ࠯ࠡࠩ㟾")+l1l1l11ll1_l1_)
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return None,None
		l11ll1ll1_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࠫ㟿")]
		group,context,title,url,l1ll1l_l1_ = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭㠀")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ㠁")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㠂")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ㠃")],l1l11111ll1_l1_[l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠨ㠄")]
		l11llll1111_l1_,language = l1l11111ll1_l1_[l11l1l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㠅")],l1l11111ll1_l1_[l11l1l_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ㠆")]
		l1l111ll111_l1_ = (group,context+l11l1l_l1_ (u"ࠧࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㠇"),title,url,l1ll1l_l1_)
		l1l111l1lll_l1_ = (group,context,title,url,l1ll1l_l1_)
		l1l111l1ll1_l1_ = (l11llll1111_l1_,context,title,url,l1ll1l_l1_)
		l1l111l1l1l_l1_ = (language,context,title,url,l1ll1l_l1_)
		if l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㠈") in l11ll1ll1_l1_:
			if l11l1l_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ㠉") in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠊")+l111l11l_l1_].append(l1l111l1lll_l1_)
			else: l11llll11ll_l1_[l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠋")+l111l11l_l1_].append(l1l111l1lll_l1_)
			if l11l1l_l1_ (u"ࠬࡋࡐࡈࠩ㠌")		in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡊࡖࡇࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㠍")+l111l11l_l1_].append(l1l111l1lll_l1_)
			if l11l1l_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ㠎")	in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡁࡓࡅࡋࡍ࡛ࡋࡄࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㠏")+l111l11l_l1_].append(l1l111l1lll_l1_)
			if l11l1l_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ㠐")	in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭㠑")+l111l11l_l1_].append(l1l111ll111_l1_)
			l11llll11ll_l1_[l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭㠒")+l111l11l_l1_].append(l1l111l1ll1_l1_)
			l11llll11ll_l1_[l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠓")+l111l11l_l1_].append(l1l111l1l1l_l1_)
		elif l11l1l_l1_ (u"࠭ࡖࡐࡆࠪ㠔") in l11ll1ll1_l1_:
			if   l11l1l_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ㠕")	in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠖")+l111l11l_l1_].append(l1l111l1lll_l1_)
			elif l11l1l_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ㠗")	in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㠘")+l111l11l_l1_].append(l1l111l1lll_l1_)
			elif l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ㠙")	in l11ll1ll1_l1_: l11llll11ll_l1_[l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠚")+l111l11l_l1_].append(l1l111l1lll_l1_)
			l11llll11ll_l1_[l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉࡥࠧ㠛")+l111l11l_l1_].append(l1l111l1ll1_l1_)
			l11llll11ll_l1_[l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㠜")+l111l11l_l1_].append(l1l111l1l1l_l1_)
	return l11llll11ll_l1_,l11l1ll11l1_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l11ll1_l1_,sep = l11l1l_l1_ (u"ࠨࠩ㠝"),l11l1l_l1_ (u"ࠩࠪ㠞")
	l1lll11ll_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11l1l_l1_ (u"ࠪࠬࠬ㠟"): sep = l11l1l_l1_ (u"ࠫ࠮࠭㠠")
	elif first==l11l1l_l1_ (u"ࠬࡡࠧ㠡"): sep = l11l1l_l1_ (u"࠭࡝ࠨ㠢")
	elif first==l11l1l_l1_ (u"ࠧ࠽ࠩ㠣"): sep = l11l1l_l1_ (u"ࠨࡀࠪ㠤")
	elif first==l11l1l_l1_ (u"ࠩࡿࠫ㠥"): sep = l11l1l_l1_ (u"ࠪࢀࠬ㠦")
	if sep and (sep in rest):
		l11l1llll1l_l1_,l11l1l11lll_l1_ = rest.split(sep,1)
		l1ll1l11ll1_l1_ = l11l1llll1l_l1_
		l1lll11ll_l1_ = first+l11l1llll1l_l1_+sep+l11l1l_l1_ (u"ࠫࠥ࠭㠧")+l11l1l11lll_l1_
	elif title.count(l11l1l_l1_ (u"ࠬࢂࠧ㠨"))>=2:
		l11l1llll1l_l1_,l11l1l11lll_l1_ = title.split(l11l1l_l1_ (u"࠭ࡼࠨ㠩"),1)
		l1ll1l11ll1_l1_ = l11l1llll1l_l1_
		l1lll11ll_l1_ = l11l1llll1l_l1_+l11l1l_l1_ (u"ࠧࠡࡾࠪ㠪")+l11l1l11lll_l1_
	else:
		sep = re.findall(l11l1l_l1_ (u"ࠨࡠ࡟ࡻࢀ࠸ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ㠫"),title,re.DOTALL)
		if not sep: sep = re.findall(l11l1l_l1_ (u"ࠩࡡࡠࡼࢁ࠳ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ㠬"),title,re.DOTALL)
		if not sep: sep = re.findall(l11l1l_l1_ (u"ࠪࡢࡡࡽࡻ࠵ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬ㠭"),title,re.DOTALL)
		if sep:
			l11l1llll1l_l1_,l11l1l11lll_l1_ = title.split(sep[0],1)
			l1ll1l11ll1_l1_ = l11l1llll1l_l1_
			l1lll11ll_l1_ = l11l1llll1l_l1_+l11l1l_l1_ (u"ࠫࠥ࠭㠮")+sep[0]+l11l1l_l1_ (u"ࠬࠦࠧ㠯")+l11l1l11lll_l1_
	l1lll11ll_l1_ = l1lll11ll_l1_.replace(l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ㠰"),l11l1l_l1_ (u"ࠧࠡࠩ㠱")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ㠲"),l11l1l_l1_ (u"ࠩࠣࠫ㠳"))
	l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭㠴"),l11l1l_l1_ (u"ࠫࠥ࠭㠵"))
	if not l1ll1l11ll1_l1_: l1ll1l11ll1_l1_ = l11l1l_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ㠶")
	l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠨ㠷"))
	l1lll11ll_l1_ = l1lll11ll_l1_.strip(l11l1l_l1_ (u"ࠧࠡࠩ㠸"))
	return l1ll1l11ll1_l1_,l1lll11ll_l1_
def CREATE_STREAMS(l1l11l1l11l_l1_,l111l11l_l1_):
	global l11l1l111l_l1_,l11llll11ll_l1_,l11l1l11ll1_l1_,l1l11l1lll1_l1_,l1l11l11lll_l1_,groups,l11l1llllll_l1_,l11ll1l1111_l1_,l1l11l11ll1_l1_
	l11lll111l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㠹")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㠺")+l111l11l_l1_)
	#l11l1lll1ll_l1_,l11lll111l1_l1_,server,username,password = GET_URL(l1l11l1l11l_l1_)
	#if not username: return
	l111ll1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ㠻")+l1l11l1l11l_l1_)
	headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㠼"):l111ll1l1l_l1_}
	#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㠽"),l11l1l_l1_ (u"࠭ࠧ㠾"),l11l1l_l1_ (u"ࠧࠨ㠿"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㡀"),l11l1l_l1_ (u"ࠩ฼้้๐ษࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠡไาࠤฯำสศฮࠣ฽ิฯࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๅสࠣห้๋ไโษอࠤฬ๊ย็ࠢยࠫ㡁"))
	#if l1ll11111l_l1_!=1: return
	l11llll1l11_l1_ = l1l111l1l11_l1_.replace(l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ㡂"),l11l1l_l1_ (u"ࠫࡤ࠭㡃")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠬࡥࠧ㡄")+l111l11l_l1_)
	if 1:
		succeeded,l11ll111ll1_l1_,l1l11l1ll1l_l1_ = True,l11l1l_l1_ (u"࠭ࠧ㡅"),l11l1l_l1_ (u"ࠧࠨ㡆")
		if not succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㡇"),l11l1l_l1_ (u"ࠩࠪ㡈"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㡉"),l11l1l_l1_ (u"ࠫๆฺไࠡสึัอࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣ࠲ࠥษอห็ส่ࠥืวษูࠣไࡒ࠹ࡕࠡ฼ํีࠥ฻อ๋ฯࠣวํࠦโะ์่ࠤศ๎ࠠๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ฾๊ๅศࠢฦ๊ࠥํะ่ࠢส่ำีๅสࠢอัฯอฬࠡษืฮึอใࠡ็าๅํ฿้ࠠืะ๎า่๋ࠦฮหࠤศ์ࠠหุํๅࠥืวษูࠣห้อิหำส็ࠥฮๆโีๆࠤ้๊ศา่ส้ัࠦศศีอาิอๅࠡไสส๊ฯࠠแࡏ࠶࡙ࠥอไๆ๊ฯ์ิฯࠠษ้ำหࠥอไษำ้ห๊าࠧ㡊"))
			if not l11lll111l1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㡋"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡑࡳࠥࡓ࠳ࡖࠢࡘࡖࡑࠦࡦࡰࡷࡱࡨࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡑ࠸࡛ࠠࡧ࡫࡯ࡩࡸ࠭㡌"))
			else: LOG_THIS(l11l1l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㡍"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡐ࠷࡚ࠦࡦࡪ࡮ࡨࡷࠬ㡎"))
			return
		l1l11ll1ll1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11lll111l1_l1_,headers,True)
		if not l1l11ll1ll1_l1_: return
		open(l11llll1l11_l1_,l11l1l_l1_ (u"ࠩࡺࡦࠬ㡏")).write(l1l11ll1ll1_l1_)
	else: l1l11ll1ll1_l1_ = open(l11llll1l11_l1_,l11l1l_l1_ (u"ࠪࡶࡧ࠭㡐")).read()
	if kodi_version>18.99 and l1l11ll1ll1_l1_: l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㡑"))
	#l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_[33000111:77000111]
	l11l1l111l_l1_ = DIALOG_PROGRESS()
	l11l1l111l_l1_.create(l11l1l_l1_ (u"ࠬาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ㡒"),l11l1l_l1_ (u"࠭ࠧ㡓"))
	PROGRESS_UPDATE(l11l1l111l_l1_,15,l11l1l_l1_ (u"ࠧห่฻๎ๆࠦวๅ็็ๅࠥอไาศํื๏࠭㡔"),l11l1l_l1_ (u"ࠨࠩ㡕"))
	l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.replace(l11l1l_l1_ (u"ࠩࠥࡸࡻ࡭࠭ࠨ㡖"),l11l1l_l1_ (u"ࠪࠦࠥࡺࡶࡨ࠯ࠪ㡗"))
	l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.replace(l11l1l_l1_ (u"ࠫ๓࠭㡘"),l11l1l_l1_ (u"ࠬ࠭㡙")).replace(l11l1l_l1_ (u"๋࠭ࠨ㡚"),l11l1l_l1_ (u"ࠧࠨ㡛")).replace(l11l1l_l1_ (u"ࠨ๑ࠪ㡜"),l11l1l_l1_ (u"ࠩࠪ㡝")).replace(l11l1l_l1_ (u"ࠪ๐ࠬ㡞"),l11l1l_l1_ (u"ࠫࠬ㡟"))
	l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.replace(l11l1l_l1_ (u"ࠬ๗ࠧ㡠"),l11l1l_l1_ (u"࠭ࠧ㡡")).replace(l11l1l_l1_ (u"ࠧ๑ࠩ㡢"),l11l1l_l1_ (u"ࠨࠩ㡣")).replace(l11l1l_l1_ (u"ࠩ๐ࠫ㡤"),l11l1l_l1_ (u"ࠪࠫ㡥")).replace(l11l1l_l1_ (u"ࠫ๗࠭㡦"),l11l1l_l1_ (u"ࠬ࠭㡧"))
	l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.replace(l11l1l_l1_ (u"࠭ࡧࡳࡱࡸࡴ࠲ࡺࡩࡵ࡮ࡨࡁࠬ㡨"),l11l1l_l1_ (u"ࠧࡨࡴࡲࡹࡵࡃࠧ㡩")).replace(l11l1l_l1_ (u"ࠨࡶࡹ࡫࠲࠭㡪"),l11l1l_l1_ (u"ࠩࠪ㡫"))
	l11llll11l1_l1_,l1l11l111l1_l1_ = [],[]
	l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࡑࡔࡒࡋࡗࡋࡓࡔࡡࡘࡔࡉࡇࡔࡆࠪࡳࡈ࡮ࡧ࡬ࡰࡩ࠯࠶࠵࠲ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯࠧ࠭ࠩส่๊๊แࠡำๅ้࠿࠳ࠧ࠭ࠩ࠴ࠤ࠴ࠦ࠳ࠨࠫࠍࠍ࡮࡬ࠠࡱࡆ࡬ࡥࡱࡵࡧ࠯࡫ࡶࡧࡦࡴࡣࡦ࡮ࡨࡨ࠭࠯࠺ࠋࠋࠌࡴࡉ࡯ࡡ࡭ࡱࡪ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠉࡳࡧࡷࡹࡷࡴࠊࠊࡷࡵࡰࠥࡃࠠࡖࡔࡏࡣࡵࡲࡡࡺࡧࡵ࠯ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡢࡷࡪࡸࡩࡦࡵࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡐ࠷࡚࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡸ࡫ࡲࡪࡧࡶࡣ࡬ࡸ࡯ࡶࡲࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶࡾࡥ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣ࡫ࡷࡵࡵࡱࠢ࡬ࡲࠥࡹࡥࡳ࡫ࡨࡷࡤ࡭ࡲࡰࡷࡳࡷ࠿ࠐࠉࠊࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯࠾࠴࠽࠿ࠦࡧࡳࡱࡸࡴࠥࡃࠠࡨࡴࡲࡹࡵ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯࠮ࡦࡰࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠋࠋࠌࡱ࠸ࡻ࡟ࡵࡧࡻࡸࠥࡃࠠ࡮࠵ࡸࡣࡹ࡫ࡸࡵ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࡬ࡸ࡯ࡶࡲࡀࠦࠬ࠱ࡧࡳࡱࡸࡴ࠰࠭ࠢࠨ࠮ࠪ࡫ࡷࡵࡵࡱ࠿ࠥࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠭ࠏࠏࡤࡦ࡮ࠣࡷࡪࡸࡩࡦࡵࡢ࡫ࡷࡵࡵࡱࡵࠍࠍࡕࡘࡏࡈࡔࡈࡗࡘࡥࡕࡑࡆࡄࡘࡊ࠮ࡰࡅ࡫ࡤࡰࡴ࡭ࠬ࠳࠷࠯ࠫั๊ศࠡษ็้้็วหࠢส่ะอๆ้์ฬࠫ࠱࠭วๅ็็ๅࠥืโๆ࠼࠰ࠫ࠱࠭࠲ࠡ࠱ࠣ࠷ࠬ࠯ࠊࠊ࡫ࡩࠤࡵࡊࡩࡢ࡮ࡲ࡫࠳࡯ࡳࡤࡣࡱࡧࡪࡲࡥࡥࠪࠬ࠾ࠏࠏࠉࡱࡆ࡬ࡥࡱࡵࡧ࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤ࡚ࡘࡌࡠࡲ࡯ࡥࡾ࡫ࡲࠬࠩࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟ࡷࡱࡧࡣࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡑ࠸࡛࠭ࡄࡔࡈࡅ࡙ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓ࠮࠴ࡱࡨࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭࡮ࡴ࡮࡮ࠬࠎࠎࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡩࡵࡳࡺࡶࠠࡪࡰࠣࡺࡴࡪ࡟ࡨࡴࡲࡹࡵࡹ࠺ࠋࠋࠌ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡀ࠶࠿࠺ࠡࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࡳ࠳ࡶࡡࡷࡩࡽࡺࠠ࠾ࠢࡰ࠷ࡺࡥࡴࡦࡺࡷ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡧࡳࡱࡸࡴࡂࠨࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠰ࠬ࡭ࡲࡰࡷࡳࡁࠧࡥ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡠࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠯ࠊࠊࡦࡨࡰࠥࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴࠌࠌࡔࡗࡕࡇࡓࡇࡖࡗࡤ࡛ࡐࡅࡃࡗࡉ࠭ࡶࡄࡪࡣ࡯ࡳ࡬࠲࠳࠱࠮ࠪะ้ฮࠠศๆ่่ๆอสࠡษ็ฯฬ์่๋หࠪ࠰ࠬอไๆๆไࠤึ่ๅ࠻࠯ࠪ࠰ࠬ࠹ࠠ࠰ࠢ࠶ࠫ࠮ࠐࠉࡪࡨࠣࡴࡉ࡯ࡡ࡭ࡱࡪ࠲࡮ࡹࡣࡢࡰࡦࡩࡱ࡫ࡤࠩࠫ࠽ࠎࠎࠏࡰࡅ࡫ࡤࡰࡴ࡭࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠍࠍࡺࡸ࡬ࠡ࠿࡙ࠣࡗࡒ࡟ࡱ࡮ࡤࡽࡪࡸࠫࠨࠨࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡥ࡬ࡪࡸࡨࡣࡸࡺࡲࡦࡣࡰࡷࠬࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡎ࠵ࡘ࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠹ࡲࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩࠋࠋ࡯࡭ࡻ࡫࡟ࡢࡴࡦ࡬࡮ࡼࡥࡥࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡷࡡࡤࡶࡨ࡮ࡩࡷࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡴࡡ࡮ࡧ࠯ࡥࡷࡩࡨࡪࡸࡨࡨࠥ࡯࡮ࠡ࡮࡬ࡺࡪࡥࡡࡳࡥ࡫࡭ࡻ࡫ࡤ࠻ࠌࠌࠍ࡮࡬ࠠࡢࡴࡦ࡬࡮ࡼࡥࡥ࠿ࡀࠫ࠶࠭࠺ࠡ࡮࡬ࡺࡪࡥࡡࡳࡥ࡫࡭ࡻ࡫ࡤࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡲࡦࡳࡥࠪࠌࠌࡨࡪࡲࠠ࡭࡫ࡹࡩࡤࡧࡲࡤࡪ࡬ࡺࡪࡪࠊࠊ࡮࡬ࡺࡪࡥࡥࡱࡩࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡦࡲࡪࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡤࡦ࡮ࠣ࡬ࡹࡳ࡬ࠋࠋࡩࡳࡷࠦ࡮ࡢ࡯ࡨ࠰ࡪࡶࡧࠡ࡫ࡱࠤࡱ࡯ࡶࡦࡡࡨࡴ࡬ࡀࠊࠊࠋ࡬ࡪࠥ࡫ࡰࡨࠣࡀࠫࡳࡻ࡬࡭ࠩ࠽ࠤࡱ࡯ࡶࡦࡡࡨࡴ࡬ࡥࡣࡩࡣࡱࡲࡪࡲࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡰࡤࡱࡪ࠯ࠊࠊࡦࡨࡰࠥࡲࡩࡷࡧࡢࡩࡵ࡭ࠊࠊࠤࠥࠦ㡬")
	lines = re.findall(l11l1l_l1_ (u"ࠫࡓࡌ࠺ࠩ࠰࠮ࡃ࠮ࠩࡅ࡙ࡖࡌࠫ㡭"),l1l11ll1ll1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠤࡇ࡛ࡘࡎࡔࡆ࠻ࠩ㡮"),re.DOTALL)
	if not lines:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㡯"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡊࡴࡲࡤࡦࡴ࠽ࠫ㡰")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠨࠢࠣࡗࡪࡷࡵࡦࡰࡦࡩ࠿࠭㡱")+l111l11l_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡔ࡯ࠡࡸ࡬ࡨࡪࡵࠠ࡭࡫ࡱ࡯ࡸࠦࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡏ࠶࡙ࠥ࡬ࡩ࡭ࡧࠪ㡲"))
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㡳"),l11l1l_l1_ (u"ࠫࠬ㡴"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㡵"),l11l1l_l1_ (u"࠭ัศสฺࠤๅࡓ࠳ࡖࠢส่ี๐ࠠฤ่อࠤศ฼แห้่ࠣฬࠦส้ฮาࠤๆ๐็ࠡใํำ๏๎็ศฬࠣ࠲࠳ࠦวฮฬ่ห้ࠦัศสฺࠤๅࡓ࠳ࡖࠢ฽๎ึࠦีฮ์ะࠫ㡶")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ㡷")+l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㡸")+l11l1l_l1_ (u"ࠩิหอ฽ࠠาไ่ࠤࠬ㡹")+str(int(l111l11l_l1_)+1)+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㡺"))
		l11l1l111l_l1_.close()
		return
	l11l1llll1_l1_ = 1024*1024
	l11ll1l1l1l_l1_ = 1+len(l1l11ll1ll1_l1_)//l11l1llll1_l1_//10
	del l1l11ll1ll1_l1_
	l11l1l1l11l_l1_ = len(lines)
	l11l1ll111l_l1_ = SPLIT_BIGLIST(lines,l11ll1l1l1l_l1_)
	del lines
	for l11l1ll1l1_l1_ in range(l11ll1l1l1l_l1_):
		PROGRESS_UPDATE(l11l1l111l_l1_,35+int(5*l11l1ll1l1_l1_/l11ll1l1l1l_l1_),l11l1l_l1_ (u"ࠫฯ่ื๋฻ࠣห้๋ไโࠢส่ึฬ๊ิ์ࠪ㡻"),l11l1l_l1_ (u"ࠬอไอิฤࠤึ่ๅ࠻࠯ࠪ㡼"),str(l11l1ll1l1_l1_+1)+l11l1l_l1_ (u"࠭ࠠ࠰ࠢࠪ㡽")+str(l11ll1l1l1l_l1_))
		if l11l1l111l_l1_.iscanceled():
			l11l1l111l_l1_.close()
			return
		l11lll1l11l_l1_ = str(l11l1ll111l_l1_[l11l1ll1l1_l1_])
		if kodi_version>18.99: l11lll1l11l_l1_ = l11lll1l11l_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㡾"))
		l11lll1l11l_l1_ = l11lll1l11l_l1_.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࡶࠬ㡿"),l11l1l_l1_ (u"ࠩࠪ㢀")).replace(l11l1l_l1_ (u"ࠪࡠࡡࡴࠧ㢁"),l11l1l_l1_ (u"ࠫࠬ㢂"))
		open(l11llll1l11_l1_+l11l1l_l1_ (u"ࠬ࠴࠰࠱ࠩ㢃")+str(l11l1ll1l1_l1_),l11l1l_l1_ (u"࠭ࡷࡣࠩ㢄")).write(l11lll1l11l_l1_)
	del l11l1ll111l_l1_,l11lll1l11l_l1_
	l11l1l1ll1l_l1_,l11ll1ll1ll_l1_,l11llll1lll_l1_ = [],[],0
	for l11l1ll1l1_l1_ in range(l11ll1l1l1l_l1_):
		if l11l1l111l_l1_.iscanceled():
			l11l1l111l_l1_.close()
			return
		l11lll1l11l_l1_ = open(l11llll1l11_l1_+l11l1l_l1_ (u"ࠧ࠯࠲࠳ࠫ㢅")+str(l11l1ll1l1_l1_),l11l1l_l1_ (u"ࠨࡴࡥࠫ㢆")).read()
		time.sleep(1)
		try: os.remove(l11llll1l11_l1_+l11l1l_l1_ (u"ࠩ࠱࠴࠵࠭㢇")+str(l11l1ll1l1_l1_))
		except: pass
		if kodi_version>18.99: l11lll1l11l_l1_ = l11lll1l11l_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㢈"))
		lines = EVAL(l11l1l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㢉"),l11lll1l11l_l1_)
		del l11lll1l11l_l1_
		l11lll1l1ll_l1_,l11llll1lll_l1_,l11l1ll11l1_l1_ = READ_ALL_LINES(lines,l1l11l111l1_l1_,l11llll11l1_l1_,l11l1l111l_l1_,l11l1l1l11l_l1_,l11llll1lll_l1_,l11lll111l1_l1_)
		if l11l1l111l_l1_.iscanceled():
			l11l1l111l_l1_.close()
			return
		if not l11lll1l1ll_l1_:
			l11l1l111l_l1_.close()
			return
		l11ll1ll1ll_l1_ += l11lll1l1ll_l1_
		l11l1l1ll1l_l1_ += l11l1ll11l1_l1_
	del lines,l11lll1l1ll_l1_
	l11llll11ll_l1_,l11l1ll11l1_l1_ = CREATE_GROUPED_STREAMS(l11ll1ll1ll_l1_,l11l1l111l_l1_,l111l11l_l1_)
	if l11l1l111l_l1_.iscanceled():
		l11l1l111l_l1_.close()
		return
	l11l1l1ll1l_l1_ += l11l1ll11l1_l1_
	del l11ll1ll1ll_l1_,l11l1ll11l1_l1_
	l1l11l1lll1_l1_,l1l11l11lll_l1_,groups,l11l1llllll_l1_,l11ll1l1111_l1_ = {},{},{},0,0
	l11ll1111ll_l1_ = list(l11llll11ll_l1_.keys())
	l1l11l11ll1_l1_ = len(l11ll1111ll_l1_)*3
	import threading
	if 1:
		threads = {}
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			threads[l11l1l11l11_l1_] = threading.Thread(target=CREATE_MENUS,args=(l11l1l11l11_l1_,))
			threads[l11l1l11l11_l1_].start()
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			threads[l11l1l11l11_l1_].join()
		if l11l1l111l_l1_.iscanceled():
			l11l1l111l_l1_.close()
			return
	else:
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			CREATE_MENUS(l11l1l11l11_l1_)
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return
	DELETE_FILES(l1l11l1l11l_l1_,l111l11l_l1_,False)
	l11ll1111ll_l1_ = list(l1l11l1lll1_l1_.keys())
	l11l1l11ll1_l1_ = 0
	if 1:
		threads = {}
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			threads[l11l1l11l11_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1l11l1l11l_l1_,l11l1l11l11_l1_))
			threads[l11l1l11l11_l1_].start()
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			threads[l11l1l11l11_l1_].join()
		if l11l1l111l_l1_.iscanceled():
			l11l1l111l_l1_.close()
			return
	else:
		for l11l1l11l11_l1_ in l11ll1111ll_l1_:
			SAVE_MENUS(l1l11l1l11l_l1_,l11l1l11l11_l1_)
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return
	l11l1ll1l1_l1_ = 0
	l1l11ll1111_l1_ = len(l11l1l1ll1l_l1_)
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭㢊"))
	for stream in l11l1l1ll1l_l1_:
		if l11l1ll1l1_l1_%27==0:
			PROGRESS_UPDATE(l11l1l111l_l1_,95+int(5*l11l1ll1l1_l1_//l1l11ll1111_l1_),l11l1l_l1_ (u"࠭สฯิํ๊ࠥอไๆ้่่ฮ࠭㢋"),l11l1l_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ㢌"),str(l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠨࠢ࠲ࠤࠬ㢍")+str(l1l11ll1111_l1_))
			if l11l1l111l_l1_.iscanceled():
				l11l1l111l_l1_.close()
				return
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࡢࠫ㢎")+l111l11l_l1_,str(stream),l11l1l_l1_ (u"ࠪࠫ㢏"),PERMANENT_CACHE)
		l11l1ll1l1_l1_ += 1
	WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࡤ࠭㢐")+l111l11l_l1_,l11l1l_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㢑"),str(l1l11ll1111_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࡤ࠭㢒")+l111l11l_l1_,l11l1l_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ㢓"),l11l1l_l1_ (u"ࠨ࠳ࠪ㢔"),PERMANENT_CACHE)
	#open(l1l1111llll_l1_,l11l1l_l1_ (u"ࠩࡺࠫ㢕")).write(l11l1l_l1_ (u"ࠪࠫ㢖"))
	l11l1l111l_l1_.close()
	time.sleep(1)
	#l11ll11ll11_l1_ = COUNTS(l1l11l1l11l_l1_,l111l11l_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㢗"),l11l1l_l1_ (u"ࠬ࠭㢘"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㢙"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㢚")+l11l1l_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㢛")+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㢜")+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㢝")+l11ll11ll11_l1_)
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㢞"))
	return
def CREATE_MENUS(l11l1l11l11_l1_):
	global l11l1l111l_l1_,l11llll11ll_l1_,l11l1l11ll1_l1_,l1l11l1lll1_l1_,l1l11l11lll_l1_,groups,l11l1llllll_l1_,l11ll1l1111_l1_,l1l11l11ll1_l1_
	l1l11l1lll1_l1_[l11l1l11l11_l1_] = {}
	l11ll11l11l_l1_,l1l111111ll_l1_ = {},[]
	l11l1l1llll_l1_ = len(l11llll11ll_l1_[l11l1l11l11_l1_])
	l1l11l1lll1_l1_[l11l1l11l11_l1_][l11l1l_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㢟")] = l11l1l1llll_l1_
	if l11l1l1llll_l1_>0:
		l1l111l111l_l1_,l1l11ll1l11_l1_,l11l1l1111l_l1_,l1l11ll111l_l1_,l11lllll1l1_l1_ = zip(*l11llll11ll_l1_[l11l1l11l11_l1_])
		del l1l11ll1l11_l1_,l11l1l1111l_l1_,l1l11ll111l_l1_
		l11ll1lll11_l1_ = list(set(l1l111l111l_l1_))
		for group in l11ll1lll11_l1_:
			l11ll11l11l_l1_[group] = l11l1l_l1_ (u"࠭ࠧ㢠")
			l1l11l1lll1_l1_[l11l1l11l11_l1_][group] = []
		PROGRESS_UPDATE(l11l1l111l_l1_,60+int(15*l11ll1l1111_l1_//l1l11l11ll1_l1_),l11l1l_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ㢡"),l11l1l_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭㢢"),str(l11ll1l1111_l1_)+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭㢣")+str(l1l11l11ll1_l1_))
		if l11l1l111l_l1_.iscanceled(): return
		l11ll1l1111_l1_ += 1
		l11ll1111l1_l1_ = len(l11ll1lll11_l1_)
		del l11ll1lll11_l1_
		l1l111111ll_l1_ = list(set(zip(l1l111l111l_l1_,l11lllll1l1_l1_)))
		del l1l111l111l_l1_,l11lllll1l1_l1_
		for group,l111_l1_ in l1l111111ll_l1_:
			if not l11ll11l11l_l1_[group] and l111_l1_: l11ll11l11l_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l1l111l_l1_,60+int(15*l11ll1l1111_l1_//l1l11l11ll1_l1_),l11l1l_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่็๎วว็ࠪ㢤"),l11l1l_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ㢥"),str(l11ll1l1111_l1_)+l11l1l_l1_ (u"ࠬࠦ࠯ࠡࠩ㢦")+str(l1l11l11ll1_l1_))
		if l11l1l111l_l1_.iscanceled(): return
		l11ll1l1111_l1_ += 1
		l11ll1l1ll1_l1_ = list(l11ll11l11l_l1_.keys())
		l11ll111111_l1_ = list(l11ll11l11l_l1_.values())
		del l11ll11l11l_l1_
		l1l111111ll_l1_ = list(zip(l11ll1l1ll1_l1_,l11ll111111_l1_))
		del l11ll1l1ll1_l1_,l11ll111111_l1_
		l1l111111ll_l1_ = sorted(l1l111111ll_l1_)
	else: l11ll1l1111_l1_ += 2
	l1l11l1lll1_l1_[l11l1l11l11_l1_][l11l1l_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㢧")] = l1l111111ll_l1_
	del l1l111111ll_l1_
	for group,context,title,url,l1ll1l_l1_ in l11llll11ll_l1_[l11l1l11l11_l1_]:
		l1l11l1lll1_l1_[l11l1l11l11_l1_][group].append((context,title,url,l1ll1l_l1_))
	PROGRESS_UPDATE(l11l1l111l_l1_,60+int(15*l11ll1l1111_l1_//l1l11l11ll1_l1_),l11l1l_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ㢨"),l11l1l_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭㢩"),str(l11ll1l1111_l1_)+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭㢪")+str(l1l11l11ll1_l1_))
	if l11l1l111l_l1_.iscanceled(): return
	l11ll1l1111_l1_ += 1
	del l11llll11ll_l1_[l11l1l11l11_l1_]
	groups[l11l1l11l11_l1_] = list(l1l11l1lll1_l1_[l11l1l11l11_l1_].keys())
	l1l11l11lll_l1_[l11l1l11l11_l1_] = len(groups[l11l1l11l11_l1_])
	l11l1llllll_l1_ += l1l11l11lll_l1_[l11l1l11l11_l1_]
	return
def SAVE_MENUS(l1l11l1l11l_l1_,l11l1l11l11_l1_):
	global l11l1l111l_l1_,l11llll11ll_l1_,l11l1l11ll1_l1_,l1l11l1lll1_l1_,l1l11l11lll_l1_,groups,l11l1llllll_l1_,l11ll1l1111_l1_,l1l11l11ll1_l1_
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l11l11_l1_)
	for l11llll1lll_l1_ in range(1+l1l11l11lll_l1_[l11l1l11l11_l1_]//173):
		l11l1lll11l_l1_ = []
		l1l11111lll_l1_ = groups[l11l1l11l11_l1_][0:273]
		for group in l1l11111lll_l1_:
			l11l1lll11l_l1_.append(l1l11l1lll1_l1_[l11l1l11l11_l1_][group])
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l11l11_l1_,l1l11111lll_l1_,l11l1lll11l_l1_,PERMANENT_CACHE,True)
		l11l1l11ll1_l1_ += len(l1l11111lll_l1_)
		PROGRESS_UPDATE(l11l1l111l_l1_,75+int(20*l11l1l11ll1_l1_//l11l1llllll_l1_),l11l1l_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็ࠪ㢫"),l11l1l_l1_ (u"ࠫฬ๊โศศ่อࠥืโๆ࠼࠰ࠫ㢬"),str(l11l1l11ll1_l1_)+l11l1l_l1_ (u"ࠬࠦ࠯ࠡࠩ㢭")+str(l11l1llllll_l1_))
		if l11l1l111l_l1_.iscanceled(): return
		del groups[l11l1l11l11_l1_][0:273]
	del l1l11l1lll1_l1_[l11l1l11l11_l1_],groups[l11l1l11l11_l1_],l1l11l11lll_l1_[l11l1l11l11_l1_]
	return
def COUNTS(l1l11l1l11l_l1_,l111l11l_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,l1ll_l1_): return
	l1l1111l111_l1_ = l11l1l_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠥาๅ๋฻ࠣห้ื่ศสฺࠫ㢮")
	l11ll11ll1l_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㢯"))
	l11llll1ll1_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㢰"))
	if l111l11l_l1_:
		l1l1111l111_l1_ = l11l1l_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠡำสฬ฼ࠦࠧ㢱")+text_numbers[int(l111l11l_l1_)]
		l111l11l_l1_ = l11l1l_l1_ (u"ࠪࡣࠬ㢲")+l111l11l_l1_
	l1l11ll1111_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠫ࡮ࡴࡴࠨ㢳"),l11l1l_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭㢴")+l111l11l_l1_,l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㢵"))
	l11lllllll1_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠧࡪࡰࡷࠫ㢶"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㢷")+l111l11l_l1_,l11l1l_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㢸"))
	l11l1l111l1_l1_ = READ_FROM_SQL3(l11llll1ll1_l1_,l11l1l_l1_ (u"ࠪ࡭ࡳࡺࠧ㢹"),l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ㢺")+l111l11l_l1_,l11l1l_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㢻"))
	l11lll1llll_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"࠭ࡩ࡯ࡶࠪ㢼"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭㢽")+l111l11l_l1_,l11l1l_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㢾"))
	l11ll111lll_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠩ࡬ࡲࡹ࠭㢿"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㣀")+l111l11l_l1_,l11l1l_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㣁"))
	l1l111l11ll_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠬ࡯࡮ࡵࠩ㣂"),l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㣃")+l111l11l_l1_,l11l1l_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㣄"))
	l1l11l1llll_l1_ = READ_FROM_SQL3(l11llll1ll1_l1_,l11l1l_l1_ (u"ࠨ࡫ࡱࡸࠬ㣅"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ㣆")+l111l11l_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㣇"))
	l11ll1l1l11_l1_ = READ_FROM_SQL3(l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠫ࡮ࡴࡴࠨ㣈"),l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ㣉")+l111l11l_l1_,l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㣊"))
	groups = READ_FROM_SQL3(l11llll1ll1_l1_,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㣋"),l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㣌")+l111l11l_l1_,l11l1l_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭㣍"))
	l11lll11l11_l1_ = []
	for group,l1ll1l_l1_ in groups:
		l11ll1llll1_l1_ = group.split(l11l1l_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㣎"))[1]
		l11lll11l11_l1_.append(l11ll1llll1_l1_)
	l11lllll111_l1_ = len(l11lll11l11_l1_)
	total = int(l1l111l11ll_l1_)+int(l1l11l1llll_l1_)+int(l11ll1l1l11_l1_)+int(l11ll111lll_l1_)+int(l11lll1llll_l1_)
	l11ll11ll11_l1_ = l11l1l_l1_ (u"ࠫࠬ㣏")
	l11ll11ll11_l1_ += l11l1l_l1_ (u"่ࠬๆ้ษอ࠾ࠥ࠭㣐")+str(l11lll1llll_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦรโๆส้࠿ࠦࠧ㣑")+str(l1l111l11ll_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ่ืู้ไศฬ࠽ࠤࠬ㣒")+str(l11lllll111_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡฯ็ๆฬะ࠺ࠡࠩ㣓")+str(l1l11l1llll_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲ็์่ศฬ้ࠣัํ่ๅห࠽ࠤࠬ㣔")+str(l11ll111lll_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣๅ๏ี่่ษอࠤ๊า็้ๆฬ࠾ࠥ࠭㣕")+str(l11ll1l1l11_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠫࡡࡴๅอ็๋฽ࠥอไใ่๋หฯࡀࠠࠨ㣖")+str(l11lllllll1_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤ๋ࠥฬๆ๊฼ࠤฬ๊แ๋ัํ์์อส࠻ࠢࠪ㣗")+str(l11l1l111l1_l1_)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡞ࡱ้ัฺ๋่ࠢส่๊฼วโห࠽ࠤࠬ㣘")+str(total)
	l11ll11ll11_l1_ += l11l1l_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠๆฮ่์฾ࠦวๅ็๊้้ฯ࠺ࠡࠩ㣙")+str(l1l11ll1111_l1_)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㣚"),l11l1l_l1_ (u"ࠩࠪ㣛"),l1l1111l111_l1_,l11ll11ll11_l1_)
	l11ll1l11ll_l1_ = l11ll11ll11_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㣜"),l11l1l_l1_ (u"ࠫࡡࡴࠧ㣝"))
	if not l111l11l_l1_: l111l11l_l1_ = l11l1l_l1_ (u"ࠬࡇ࡬࡭ࠩ㣞")
	else: l111l11l_l1_ = l111l11l_l1_[1]
	LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㣟"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡈࡵࡵ࡯ࡶࡶࠤࡴ࡬ࠠࡎ࠵ࡘࠤࡻ࡯ࡤࡦࡱࡶࠤࠥࠦࡆࡰ࡮ࡧࡩࡷࡀࠠࠨ㣠")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠨࠢࠣࠤࡘ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ㣡")+l111l11l_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ㣢")+l11ll1l11ll_l1_)
	return l11ll11ll11_l1_
def DELETE_FILES(l1l11l1l11l_l1_,l111l11l_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㣣"),l11l1l_l1_ (u"ࠫࠬ㣤"),l11l1l_l1_ (u"ࠬ࠭㣥"),l11l1l_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢใࡑ࠸࡛ࠧ㣦"),l11l1l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯࠣห้๋ไโษอࠤฬ๊โะ์่อࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠠ࠯࠰ࠣ฽้๋วࠡษ้็ࠥะำหูํ฽ࠥ็๊ࠡลํࠤํ่สࠡษ็ำำ๎ไࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖ๋ࠢะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ㣧"))
		if l1ll11111l_l1_!=1: return
		file = l1l111l1l11_l1_.replace(l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ㣨"),l11l1l_l1_ (u"ࠩࡢࠫ㣩")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㣪")+l111l11l_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l11111111_l1_)
	#except: pass
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠫࠬ㣫"))
	if l111l11l_l1_:
		l11lll1l111_l1_ = []
		for l11ll11l1_l1_ in l11lll11ll1_l1_:
			l11lll1l111_l1_.append(l11ll11l1_l1_+l11l1l_l1_ (u"ࠬࡥࠧ㣬")+l111l11l_l1_)
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ㣭")+l111l11l_l1_)
	else:
		l11lll1l111_l1_ = l11lll11ll1_l1_
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭㣮"))
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡕࡓ࡚ࡖࡓࠨ㣯"))
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩࡌࡘࡊࡓࡓࠨ㣰"))
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࠪ㣱"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㣲"),l11l1l_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ㣳")+l1l11l1l11l_l1_)
	for l11l1l11l11_l1_ in l11lll1l111_l1_:
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,l11l1l11l11_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㣴"),l11l1l_l1_ (u"ࠧࠨ㣵"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㣶"),l11l1l_l1_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ㣷"))
	return
def CHECK_TABLES_EXIST(l1l11l1l11l_l1_=l11l1l_l1_ (u"ࠪࠫ㣸"),l1ll_l1_=True):
	if l1l11l1l11l_l1_:
		l1l1l1ll11_l1_ = GET_DBFILE_NAME(str(l1l11l1l11l_l1_),l11l1l_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㣹"))
		dummy = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠬࡹࡴࡳࠩ㣺"),l11l1l_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ㣻"),l11l1l_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ㣼"))
		if dummy: return True
	else:
		for l1l11l1l11l_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1l1ll11_l1_ = GET_DBFILE_NAME(str(l1l11l1l11l_l1_),l11l1l_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ㣽"))
			dummy = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭㣾"),l11l1l_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ㣿"),l11l1l_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ㤀"))
			if dummy: return True
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㤁"),l11l1l_l1_ (u"࠭ࠧ㤂"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㤃"),l11l1l_l1_ (u"ࠨษ้ฮࠥฮอศฮฬࠤส๊้ࠡษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣวูหๆฯࠠาษห฻ࠥษ่ࠡษืฮึอใࠡโࡐ࠷࡚ࠨࠠ࠯࠰๋ࠣีํࠠศๆิ์ฬฮืࠡษะฮ๊อไࠡฬฯำ์อࠠโ์ࠣห้หๆหำ้ฮࠥษ่ࠡฬืฮึ๐็ศฺ่๊ࠢࠥัไหࠣๅ๏ี๊้้สฮࠥࡢ࡮࡝ࡰࠣว๊อࠠฦาสࠤ็๋สࠡใ฼่ฬࠦศฦุสๅฮࠦวๅำสฬ฼ࠦแฦา้ࠤศ์สࠡสะหัฯࠠๅฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖ๋ࠢิ้้ࠠษษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠤ࠱ࠫ㤄"))
	#SHOW_EMPTY(l1111l_l1_)
	return False
def SEARCH(l1l1lllll1l_l1_,l1l11l1l11l_l1_=l11l1l_l1_ (u"ࠩࠪ㤅"),l11l1l11l11_l1_=l11l1l_l1_ (u"ࠪࠫ㤆"),l11ll11l1ll_l1_=l11l1l_l1_ (u"ࠫࠬ㤇")):
	if not l11ll11l1ll_l1_: l11ll11l1ll_l1_ = l11l1l_l1_ (u"ࠬ࠷ࠧ㤈")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1lllll1l_l1_)
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1lll1l_l1_ = [l11l1l_l1_ (u"࠭ࠧ㤉"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㤊"),l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㤋"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㤌"),l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㤍"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㤎")]
	if not l11l1l11l11_l1_:
		if not l1ll_l1_:
			if   l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࡠࠩ㤏") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[1]
			elif l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㤐") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[2]
			elif l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㤑") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[3]
			else: l11l1l11l11_l1_ = l11ll1lll1l_l1_[0]
		else:
			l1l1111111l_l1_ = [l11l1l_l1_ (u"ࠨษ็็้࠭㤒"),l11l1l_l1_ (u"ࠩๅ๊ํอสࠨ㤓"),l11l1l_l1_ (u"ࠪวๆ๊วๆࠩ㤔"),l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠬ㤕"),l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯࠧ㤖"),l11l1l_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ㤗")]
			choice = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ㤘"), l1l1111111l_l1_)
			if choice==-1: return
			l11l1l11l11_l1_ = l11ll1lll1l_l1_[choice]
	search = search+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㤙")
	if l1l11l1l11l_l1_: SEARCH_ONE_FOLDER(search,l1l11l1l11l_l1_,l11l1l11l11_l1_,l11ll11l1ll_l1_)
	else:
		for l1l11l1l11l_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1l11l1l11l_l1_),l11l1l11l11_l1_,l11ll11l1ll_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1l1lllll1l_l1_,l1l11l1l11l_l1_,l11l1l11l11_l1_=l11l1l_l1_ (u"ࠩࠪ㤚"),l11ll11l1ll_l1_=l11l1l_l1_ (u"ࠪࠫ㤛")):
	if not l11ll11l1ll_l1_: l11ll11l1ll_l1_ = l11l1l_l1_ (u"ࠫ࠶࠭㤜")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1lllll1l_l1_)
	if not l1l11l1l11l_l1_: return
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1lll1l_l1_ = [l11l1l_l1_ (u"ࠬ࠭㤝"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㤞"),l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㤟"),l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㤠"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㤡"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㤢")]
	if not l11l1l11l11_l1_:
		if not l1ll_l1_:
			if   l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋ࡟ࠨ㤣") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[1]
			elif l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㤤") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[2]
			elif l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㤥") in options: l11l1l11l11_l1_ = l11ll1lll1l_l1_[3]
			else: l11l1l11l11_l1_ = l11ll1lll1l_l1_[0]
		else:
			l1l1111111l_l1_ = [l11l1l_l1_ (u"ࠧศๆๆ่ࠬ㤦"),l11l1l_l1_ (u"ࠨไ้์ฬะࠧ㤧"),l11l1l_l1_ (u"ࠩฦๅ้อๅࠨ㤨"),l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠫ㤩"),l11l1l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅอ้๋่ฮ࠭㤪"),l11l1l_l1_ (u"่ࠬๆ้ษอࠤ๊า็้ๆฬࠫ㤫")]
			choice = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㤬"), l1l1111111l_l1_)
			if choice==-1: return
			l11l1l11l11_l1_ = l11ll1lll1l_l1_[choice]
	l11l1l11l1l_l1_ = search.lower()
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ㤭"))
	results = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㤮"),l11l1l_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ㤯"),(l11l1l11l11_l1_,l11l1l11l1l_l1_))
	if not results:
		l1l11l1111l_l1_,l11lll1111l_l1_ = [],[]
		if not l11l1l11l11_l1_: l11ll1l111l_l1_ = [1,2,3,4,5]
		else: l11ll1l111l_l1_ = [l11ll1lll1l_l1_.index(l11l1l11l11_l1_)]
		for l11l1ll1l1_l1_ in l11ll1l111l_l1_:
			#l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11ll1lll1l_l1_[l11l1ll1l1_l1_])
			if l11l1ll1l1_l1_!=3:
				l11lll1l1ll_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㤰"),l11ll1lll1l_l1_[l11l1ll1l1_l1_])
				del l11lll1l1ll_l1_[l11l1l_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㤱")]
				del l11lll1l1ll_l1_[l11l1l_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ㤲")]
				del l11lll1l1ll_l1_[l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ㤳")]
				groups = list(l11lll1l1ll_l1_.keys())
				for group in groups:
					for context,title,url,l1ll1l_l1_ in l11lll1l1ll_l1_[group]:
						if l11l1l11l1l_l1_ in title.lower(): l11lll1111l_l1_.append((title,url,l1ll1l_l1_))
					del l11lll1l1ll_l1_[group]
				del l11lll1l1ll_l1_
			else: groups = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㤴"),l11ll1lll1l_l1_[l11l1ll1l1_l1_],l11l1l_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ㤵"))
			for group in groups:
				try: group,l1ll1l_l1_ = group
				except: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪ㤶")
				if l11l1l11l1l_l1_ in group.lower():
					if l11l1ll1l1_l1_!=3: l1l1111l1l1_l1_ = group
					else:
						l1l1111l1ll_l1_,l11l1l111ll_l1_ = group.split(l11l1l_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㤷"))
						if l11l1l11l1l_l1_ in l1l1111l1ll_l1_.lower(): l1l1111l1l1_l1_ = l1l1111l1ll_l1_
						else: l1l1111l1l1_l1_ = l11l1l111ll_l1_
					l1l11l1111l_l1_.append((group,l1l1111l1l1_l1_,l11ll1lll1l_l1_[l11l1ll1l1_l1_],l1ll1l_l1_))
			del groups
		l1l11l1111l_l1_ = set(l1l11l1111l_l1_)
		l11lll1111l_l1_ = set(l11lll1111l_l1_)
		l1l11l1111l_l1_ = sorted(l1l11l1111l_l1_,reverse=False,key=lambda key: key[1])
		l11lll1111l_l1_ = sorted(l11lll1111l_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ㤸"),(l11l1l11l11_l1_,l11l1l11l1l_l1_),(l1l11l1111l_l1_,l11lll1111l_l1_),PERMANENT_CACHE)
	else: l1l11l1111l_l1_,l11lll1111l_l1_ = results
	groups = len(l1l11l1111l_l1_)
	l11ll1_l1_ = len(l11lll1111l_l1_)
	l11llll_l1_ = int(l11ll11l1ll_l1_)
	s1 = max(0,(l11llll_l1_-1)*100)
	e1 = max(0,l11llll_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l1111l1l1_l1_,l1l111lll11_l1_,l1ll1l_l1_ in l1l11l1111l_l1_[s1:e1]:
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㤹"),l1111l_l1_+l1l1111l1l1_l1_,l1l111lll11_l1_,714,l1ll1l_l1_,l11l1l_l1_ (u"࠭࠱ࠨ㤺"),group,l11l1l_l1_ (u"ࠧࠨ㤻"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㤼"):l1l11l1l11l_l1_})
	del l1l11l1111l_l1_
	for title,url,l1ll1l_l1_ in l11lll1111l_l1_[s2:e2]:
		l1l111ll1ll_l1_ = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ㤽"))[-1]
		if l11l1l_l1_ (u"ࠪ࠲ࠬ㤾") in l1l111ll1ll_l1_ and l11l1l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㤿") not in l1l111ll1ll_l1_: addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㥀"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"࠭ࠧ㥁"),l11l1l_l1_ (u"ࠧࠨ㥂"),l11l1l_l1_ (u"ࠨࠩ㥃"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㥄"):l1l11l1l11l_l1_})
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㥅"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠫࠬ㥆"),l11l1l_l1_ (u"ࠬ࠭㥇"),l11l1l_l1_ (u"࠭ࠧ㥈"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㥉"):l1l11l1l11l_l1_})
	del l11lll1111l_l1_
	PAGINATION(l1l11l1l11l_l1_,l11ll11l1ll_l1_,l11l1l11l11_l1_,719,groups+l11ll1_l1_,search+l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㥊"))
	return
def PAGINATION(l1l11l1l11l_l1_,l11ll11l1ll_l1_,l11l1l11l11_l1_,mode,total,text):
	if not l11ll11l1ll_l1_: l11ll11l1ll_l1_ = l11l1l_l1_ (u"ࠩ࠴ࠫ㥋")
	if l11ll11l1ll_l1_!=l11l1l_l1_ (u"ࠪ࠵ࠬ㥌"): addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㥍"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ㥎")+str(1),l11l1l11l11_l1_,mode,l11l1l_l1_ (u"࠭ࠧ㥏"),str(1),text,l11l1l_l1_ (u"ࠧࠨ㥐"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㥑"):l1l11l1l11l_l1_})
	if not total: total = 0
	l1l1l1l1l_l1_ = int(total/100)+1
	for l11llll_l1_ in range(2,l1l1l1l1l_l1_):
		l1l111l1111_l1_ = (l11llll_l1_%10==0 or int(l11ll11l1ll_l1_)-4<l11llll_l1_<int(l11ll11l1ll_l1_)+4)
		l11lll11111_l1_ = (l1l111l1111_l1_ and int(l11ll11l1ll_l1_)-40<l11llll_l1_<int(l11ll11l1ll_l1_)+40)
		if str(l11llll_l1_)!=l11ll11l1ll_l1_ and (l11llll_l1_%100==0 or l11lll11111_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㥒"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩ㥓")+str(l11llll_l1_),l11l1l11l11_l1_,mode,l11l1l_l1_ (u"ࠫࠬ㥔"),str(l11llll_l1_),text,l11l1l_l1_ (u"ࠬ࠭㥕"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㥖"):l1l11l1l11l_l1_})
	if str(l1l1l1l1l_l1_)!=l11ll11l1ll_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㥗"),l1111l_l1_+l11l1l_l1_ (u"ࠨลัีࠥ฻แฮหࠣࠫ㥘")+str(l1l1l1l1l_l1_),l11l1l11l11_l1_,mode,l11l1l_l1_ (u"ࠩࠪ㥙"),str(l1l1l1l1l_l1_),text,l11l1l_l1_ (u"ࠪࠫ㥚"),{l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㥛"):l1l11l1l11l_l1_})
	return
def GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l11l11_l1_):
	#if l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ㥜") in l11l1l11l11_l1_ or l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࠬ㥝") in l11l1l11l11_l1_: l1l1l1ll11_l1_ = iptv2_dbfile
	#else: l1l1l1ll11_l1_ = iptv1_dbfile
	l1l1l1ll11_l1_ = l11l1ll1111_l1_.replace(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ㥞"),l11l1l_l1_ (u"ࠨࡡࠪ㥟")+l1l11l1l11l_l1_)
	return l1l1l1ll11_l1_
def l1l1111lll1_l1_(l1l11l1l11l_l1_):
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠩࠪ㥠"))
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㥡"),l11l1l_l1_ (u"ࠫࠬ㥢"),l11l1l_l1_ (u"ࠬ࠭㥣"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㥤"),l11l1l_l1_ (u"ฺࠧ็็๎ฮࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮࠦโะࠢอัฯอฬࠡ฻าอࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮั๊ศࠡษ็้้็วหࠢส่ว์ࠠภࠩ㥥"))
	if l1ll11111l_l1_!=1: return
	l1l11l1l1l1_l1_(l1l11l1l11l_l1_,False)
	counts = [0]
	for seq in range(1,l11ll1lllll_l1_+1):
		l1l11l111ll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㥦")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㥧")+str(seq))
		if l1l11l111ll_l1_: CREATE_STREAMS(l1l11l1l11l_l1_,str(seq))
		counts.append(0)
	for l11l1l11l11_l1_ in l11lll11ll1_l1_:
		l11ll11l1l1_l1_,l11ll11lll1_l1_,l1l11ll11l1_l1_,l11ll1ll11l_l1_,l11ll11l11l_l1_ = 0,{},[],[],[]
		for seq in range(1,l11ll1lllll_l1_+1):
			l1l111lll11_l1_ = l11l1l11l11_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㥨")+str(seq)
			l11llll11ll_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㥩"),l1l111lll11_l1_)
			try:
				l1l11l1l1ll_l1_ = l11llll11ll_l1_[l11l1l_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ㥪")]
				count = l11llll11ll_l1_[l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㥫")]
			except:
				l1l11l1l1ll_l1_ = []
				count = l11l1l_l1_ (u"ࠧ࠱ࠩ㥬")
			for tuple in l1l11l1l1ll_l1_:
				group,l111_l1_ = tuple
				l11lll1l1ll_l1_ = l11llll11ll_l1_[group]
				if group not in l11ll1ll11l_l1_:
					l11ll1ll11l_l1_.append(group)
					l11ll11l11l_l1_.append(tuple)
					l11ll11lll1_l1_[group] = []
				l11ll11lll1_l1_[group] += l11lll1l1ll_l1_
			DELETE_FROM_SQL3(l1l1l1ll11_l1_,l1l111lll11_l1_)
			WRITE_TO_SQL3(l1l1l1ll11_l1_,l1l111lll11_l1_,l11l1l_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㥭"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11ll1ll11l_l1_:
			l11lll1l1ll_l1_ = list(set(l11ll11lll1_l1_[group]))
			l11ll11l1l1_l1_ += len(l11lll1l1ll_l1_)
			l1l11ll11l1_l1_.append(l11lll1l1ll_l1_)
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l11l11_l1_,l11l1l_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㥮"),str(l11ll11l1l1_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l11l11_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ㥯"),l11ll11l11l_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l11l11_l1_,l11ll1ll11l_l1_,l1l11ll11l1_l1_,PERMANENT_CACHE,True)
	l11llllll11_l1_ = False
	for seq in range(1,l11ll1lllll_l1_+1):
		if int(counts[seq])>0:
			l1l11l111ll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡸ࡬ࡠࠩ㥰")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠬࡥࠧ㥱")+str(seq))
			WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ㥲")+str(seq),l11l1l_l1_ (u"ࠧࡠࡡࡏࡍࡓࡑ࡟ࡠࠩ㥳"),l1l11l111ll_l1_,PERMANENT_CACHE)
			l11llllll11_l1_ = True
	WRITE_TO_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ㥴"),l11l1l_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ㥵"),l11l1l_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ㥶"),PERMANENT_CACHE)
	if l11llllll11_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㥷"),l11l1l_l1_ (u"ࠬ࠭㥸"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㥹"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㥺")+l11l1l_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㥻")+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㥼"))
		l11llllll1l_l1_(l1l11l1l11l_l1_)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㥽"))
	else: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㥾"),l11l1l_l1_ (u"ࠬ࠭㥿"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㦀"),l11l1l_l1_ (u"ࠧโึ็ࠤอูอษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦ࠮ࠡละฮ๊อไࠡำ๋หอ฽ࠠแࡏ࠶࡙ࠥอไห์ࠣว๋ะࠠฤุไฮ์อࠠๅๆหี๋อๅอࠢ฽๎ึࠦีฮ์ะอࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะ๋ࠥๆไࠢฦ๊ࠥะึ๋ใࠣห้ืวษูࠣฬ๋็ำไࠢ็่อืๆศ็ฯࠤออำหะาห๊ࠦโศศ่อࠥๆࡍ࠴ࡗࠣห้๋่อ๊าอࠥฮ็ัษࠣห้ฮั็ษ่ะࠬ㦁"))
	return
def l11llllll1l_l1_(l1l11l1l11l_l1_):
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠨࠩ㦂"))
	if not CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True): return
	for seq in range(1,l11ll1lllll_l1_+1):
		l1l11l111ll_l1_ = READ_FROM_SQL3(l1l1l1ll11_l1_,l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭㦃"),l11l1l_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ㦄")+str(seq),l11l1l_l1_ (u"ࠫࡤࡥࡌࡊࡐࡎࡣࡤ࠭㦅"))
		if l1l11l111ll_l1_: l11ll11ll11_l1_ = COUNTS(l1l11l1l11l_l1_,str(seq))
	COUNTS(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠬ࠭㦆"))
	return
def l1l11l1l1l1_l1_(l1l11l1l11l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㦇"),l11l1l_l1_ (u"ࠧࠨ㦈"),l11l1l_l1_ (u"ࠨࠩ㦉"),l11l1l_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ㦊"),l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭㦋"))
		if l1ll11111l_l1_!=1: return
	#for seq in range(1,l11ll1lllll_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11l1l_l1_ (u"ࠫࠬ㦌"),False)
	l1l1l1ll11_l1_ = GET_DBFILE_NAME(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠬ࠭㦍"))
	try: os.remove(l1l1l1ll11_l1_)
	except: pass
	for seq in range(1,l11ll1lllll_l1_+1):
		filename = l1l111l1l11_l1_.replace(l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ㦎"),l11l1l_l1_ (u"ࠧࡠࠩ㦏")+l1l11l1l11l_l1_+l11l1l_l1_ (u"ࠨࡡࠪ㦐")+str(seq))
		l1l11l1ll11_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1l11l1ll11_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㦑"),l11l1l_l1_ (u"ࠪࠫ㦒"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㦓"),l11l1l_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ㦔"))
	return
COUNTRIES_CODES = {
 l11l1l_l1_ (u"࠭ࡁࡇࠩ㦕"):l11l1l_l1_ (u"ࠧࡂࡨࡪ࡬ࡦࡴࡩࡴࡶࡤࡲࠬ㦖")
,l11l1l_l1_ (u"ࠨࡃࡏࠫ㦗"):l11l1l_l1_ (u"ࠩࡄࡰࡧࡧ࡮ࡪࡣࠪ㦘")
,l11l1l_l1_ (u"ࠪࡈ࡟࠭㦙"):l11l1l_l1_ (u"ࠫࡆࡲࡧࡦࡴ࡬ࡥࠬ㦚")
,l11l1l_l1_ (u"ࠬࡇࡓࠨ㦛"):l11l1l_l1_ (u"࠭ࡁ࡮ࡧࡵ࡭ࡨࡧ࡮ࠡࡕࡤࡱࡴࡧࠧ㦜")
,l11l1l_l1_ (u"ࠧࡂࡆࠪ㦝"):l11l1l_l1_ (u"ࠨࡃࡱࡨࡴࡸࡲࡢࠩ㦞")
,l11l1l_l1_ (u"ࠩࡄࡓࠬ㦟"):l11l1l_l1_ (u"ࠪࡅࡳ࡭࡯࡭ࡣࠪ㦠")
,l11l1l_l1_ (u"ࠫࡆࡏࠧ㦡"):l11l1l_l1_ (u"ࠬࡇ࡮ࡨࡷ࡬ࡰࡱࡧࠧ㦢")
,l11l1l_l1_ (u"࠭ࡁࡒࠩ㦣"):l11l1l_l1_ (u"ࠧࡂࡰࡷࡥࡷࡩࡴࡪࡥࡤࠫ㦤")
,l11l1l_l1_ (u"ࠨࡃࡊࠫ㦥"):l11l1l_l1_ (u"ࠩࡄࡲࡹ࡯ࡧࡶࡣࠣࡥࡳࡪࠠࡃࡣࡵࡦࡺࡪࡡࠨ㦦")
,l11l1l_l1_ (u"ࠪࡅࡗ࠭㦧"):l11l1l_l1_ (u"ࠫࡆࡸࡧࡦࡰࡷ࡭ࡳࡧࠧ㦨")
,l11l1l_l1_ (u"ࠬࡇࡍࠨ㦩"):l11l1l_l1_ (u"࠭ࡁࡳ࡯ࡨࡲ࡮ࡧࠧ㦪")
,l11l1l_l1_ (u"ࠧࡂ࡙ࠪ㦫"):l11l1l_l1_ (u"ࠨࡃࡵࡹࡧࡧࠧ㦬")
,l11l1l_l1_ (u"ࠩࡄ࡙ࠬ㦭"):l11l1l_l1_ (u"ࠪࡅࡺࡹࡴࡳࡣ࡯࡭ࡦ࠭㦮")
,l11l1l_l1_ (u"ࠫࡆ࡚ࠧ㦯"):l11l1l_l1_ (u"ࠬࡇࡵࡴࡶࡵ࡭ࡦ࠭㦰")
,l11l1l_l1_ (u"࠭ࡁ࡛ࠩ㦱"):l11l1l_l1_ (u"ࠧࡂࡼࡨࡶࡧࡧࡩ࡫ࡣࡱࠫ㦲")
,l11l1l_l1_ (u"ࠨࡄࡖࠫ㦳"):l11l1l_l1_ (u"ࠩࡅࡥ࡭ࡧ࡭ࡢࡵࠪ㦴")
,l11l1l_l1_ (u"ࠪࡆࡍ࠭㦵"):l11l1l_l1_ (u"ࠫࡇࡧࡨࡳࡣ࡬ࡲࠬ㦶")
,l11l1l_l1_ (u"ࠬࡈࡄࠨ㦷"):l11l1l_l1_ (u"࠭ࡂࡢࡰࡪࡰࡦࡪࡥࡴࡪࠪ㦸")
,l11l1l_l1_ (u"ࠧࡃࡄࠪ㦹"):l11l1l_l1_ (u"ࠨࡄࡤࡶࡧࡧࡤࡰࡵࠪ㦺")
,l11l1l_l1_ (u"ࠩࡅ࡝ࠬ㦻"):l11l1l_l1_ (u"ࠪࡆࡪࡲࡡࡳࡷࡶࠫ㦼")
,l11l1l_l1_ (u"ࠫࡇࡋࠧ㦽"):l11l1l_l1_ (u"ࠬࡈࡥ࡭ࡩ࡬ࡹࡲ࠭㦾")
,l11l1l_l1_ (u"࠭ࡂ࡛ࠩ㦿"):l11l1l_l1_ (u"ࠧࡃࡧ࡯࡭ࡿ࡫ࠧ㧀")
,l11l1l_l1_ (u"ࠨࡄࡍࠫ㧁"):l11l1l_l1_ (u"ࠩࡅࡩࡳ࡯࡮ࠨ㧂")
,l11l1l_l1_ (u"ࠪࡆࡒ࠭㧃"):l11l1l_l1_ (u"ࠫࡇ࡫ࡲ࡮ࡷࡧࡥࠬ㧄")
,l11l1l_l1_ (u"ࠬࡈࡔࠨ㧅"):l11l1l_l1_ (u"࠭ࡂࡩࡷࡷࡥࡳ࠭㧆")
,l11l1l_l1_ (u"ࠧࡃࡑࠪ㧇"):l11l1l_l1_ (u"ࠨࡄࡲࡰ࡮ࡼࡩࡢࠩ㧈")
,l11l1l_l1_ (u"ࠩࡅࡕࠬ㧉"):l11l1l_l1_ (u"ࠪࡆࡴࡴࡡࡪࡴࡨࠫ㧊")
,l11l1l_l1_ (u"ࠫࡇࡇࠧ㧋"):l11l1l_l1_ (u"ࠬࡈ࡯ࡴࡰ࡬ࡥࠥࡧ࡮ࡥࠢࡋࡩࡷࢀࡥࡨࡱࡹ࡭ࡳࡧࠧ㧌")
,l11l1l_l1_ (u"࠭ࡂࡘࠩ㧍"):l11l1l_l1_ (u"ࠧࡃࡱࡷࡷࡼࡧ࡮ࡢࠩ㧎")
,l11l1l_l1_ (u"ࠨࡄ࡙ࠫ㧏"):l11l1l_l1_ (u"ࠩࡅࡳࡺࡼࡥࡵࠢࡌࡷࡱࡧ࡮ࡥࠩ㧐")
,l11l1l_l1_ (u"ࠪࡆࡗ࠭㧑"):l11l1l_l1_ (u"ࠫࡇࡸࡡࡻ࡫࡯ࠫ㧒")
,l11l1l_l1_ (u"ࠬࡏࡏࠨ㧓"):l11l1l_l1_ (u"࠭ࡂࡳ࡫ࡷ࡭ࡸ࡮ࠠࡊࡰࡧ࡭ࡦࡴࠠࡐࡥࡨࡥࡳࠦࡔࡦࡴࡵ࡭ࡹࡵࡲࡺࠩ㧔")
,l11l1l_l1_ (u"ࠧࡗࡉࠪ㧕"):l11l1l_l1_ (u"ࠨࡄࡵ࡭ࡹ࡯ࡳࡩ࡙ࠢ࡭ࡷ࡭ࡩ࡯ࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ㧖")
,l11l1l_l1_ (u"ࠩࡅࡒࠬ㧗"):l11l1l_l1_ (u"ࠪࡆࡷࡻ࡮ࡦ࡫ࠪ㧘")
,l11l1l_l1_ (u"ࠫࡇࡍࠧ㧙"):l11l1l_l1_ (u"ࠬࡈࡵ࡭ࡩࡤࡶ࡮ࡧࠧ㧚")
,l11l1l_l1_ (u"࠭ࡂࡇࠩ㧛"):l11l1l_l1_ (u"ࠧࡃࡷࡵ࡯࡮ࡴࡡࠡࡈࡤࡷࡴ࠭㧜")
,l11l1l_l1_ (u"ࠨࡄࡌࠫ㧝"):l11l1l_l1_ (u"ࠩࡅࡹࡷࡻ࡮ࡥ࡫ࠪ㧞")
,l11l1l_l1_ (u"ࠪࡏࡍ࠭㧟"):l11l1l_l1_ (u"ࠫࡈࡧ࡭ࡣࡱࡧ࡭ࡦ࠭㧠")
,l11l1l_l1_ (u"ࠬࡉࡍࠨ㧡"):l11l1l_l1_ (u"࠭ࡃࡢ࡯ࡨࡶࡴࡵ࡮ࠨ㧢")
,l11l1l_l1_ (u"ࠧࡄࡃࠪ㧣"):l11l1l_l1_ (u"ࠨࡅࡤࡲࡦࡪࡡࠨ㧤")
,l11l1l_l1_ (u"ࠩࡆ࡚ࠬ㧥"):l11l1l_l1_ (u"ࠪࡇࡦࡶࡥࠡࡘࡨࡶࡩ࡫ࠧ㧦")
,l11l1l_l1_ (u"ࠫࡐ࡟ࠧ㧧"):l11l1l_l1_ (u"ࠬࡉࡡࡺ࡯ࡤࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧨")
,l11l1l_l1_ (u"࠭ࡃࡇࠩ㧩"):l11l1l_l1_ (u"ࠧࡄࡧࡱࡸࡷࡧ࡬ࠡࡃࡩࡶ࡮ࡩࡡ࡯ࠢࡕࡩࡵࡻࡢ࡭࡫ࡦࠫ㧪")
,l11l1l_l1_ (u"ࠨࡖࡇࠫ㧫"):l11l1l_l1_ (u"ࠩࡆ࡬ࡦࡪࠧ㧬")
,l11l1l_l1_ (u"ࠪࡇࡑ࠭㧭"):l11l1l_l1_ (u"ࠫࡈ࡮ࡩ࡭ࡧࠪ㧮")
,l11l1l_l1_ (u"ࠬࡉࡎࠨ㧯"):l11l1l_l1_ (u"࠭ࡃࡩ࡫ࡱࡥࠬ㧰")
,l11l1l_l1_ (u"ࠧࡄ࡚ࠪ㧱"):l11l1l_l1_ (u"ࠨࡅ࡫ࡶ࡮ࡹࡴ࡮ࡣࡶࠤࡎࡹ࡬ࡢࡰࡧࠫ㧲")
,l11l1l_l1_ (u"ࠩࡆࡇࠬ㧳"):l11l1l_l1_ (u"ࠪࡇࡴࡩ࡯ࡴࠢࠫࡏࡪ࡫࡬ࡪࡰࡪ࠭ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧴")
,l11l1l_l1_ (u"ࠫࡈࡕࠧ㧵"):l11l1l_l1_ (u"ࠬࡉ࡯࡭ࡱࡰࡦ࡮ࡧࠧ㧶")
,l11l1l_l1_ (u"࠭ࡋࡎࠩ㧷"):l11l1l_l1_ (u"ࠧࡄࡱࡰࡳࡷࡵࡳࠨ㧸")
,l11l1l_l1_ (u"ࠨࡅࡎࠫ㧹"):l11l1l_l1_ (u"ࠩࡆࡳࡴࡱࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㧺")
,l11l1l_l1_ (u"ࠪࡇࡗ࠭㧻"):l11l1l_l1_ (u"ࠫࡈࡵࡳࡵࡣࠣࡖ࡮ࡩࡡࠨ㧼")
,l11l1l_l1_ (u"ࠬࡎࡒࠨ㧽"):l11l1l_l1_ (u"࠭ࡃࡳࡱࡤࡸ࡮ࡧࠧ㧾")
,l11l1l_l1_ (u"ࠧࡄࡗࠪ㧿"):l11l1l_l1_ (u"ࠨࡅࡸࡦࡦ࠭㨀")
,l11l1l_l1_ (u"ࠩࡆ࡛ࠬ㨁"):l11l1l_l1_ (u"ࠪࡇࡺࡸࡡࡤࡣࡲࠫ㨂")
,l11l1l_l1_ (u"ࠫࡈ࡟ࠧ㨃"):l11l1l_l1_ (u"ࠬࡉࡹࡱࡴࡸࡷࠬ㨄")
,l11l1l_l1_ (u"࠭ࡃ࡛ࠩ㨅"):l11l1l_l1_ (u"ࠧࡄࡼࡨࡧ࡭ࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠨ㨆")
,l11l1l_l1_ (u"ࠨࡅࡇࠫ㨇"):l11l1l_l1_ (u"ࠩࡇࡩࡲࡵࡣࡳࡣࡷ࡭ࡨࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠡࡱࡩࠤࡹ࡮ࡥࠡࡅࡲࡲ࡬ࡵࠧ㨈")
,l11l1l_l1_ (u"ࠪࡈࡐ࠭㨉"):l11l1l_l1_ (u"ࠫࡉ࡫࡮࡮ࡣࡵ࡯ࠬ㨊")
,l11l1l_l1_ (u"ࠬࡊࡊࠨ㨋"):l11l1l_l1_ (u"࠭ࡄ࡫࡫ࡥࡳࡺࡺࡩࠨ㨌")
,l11l1l_l1_ (u"ࠧࡅࡏࠪ㨍"):l11l1l_l1_ (u"ࠨࡆࡲࡱ࡮ࡴࡩࡤࡣࠪ㨎")
,l11l1l_l1_ (u"ࠩࡇࡓࠬ㨏"):l11l1l_l1_ (u"ࠪࡈࡴࡳࡩ࡯࡫ࡦࡥࡳࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠨ㨐")
,l11l1l_l1_ (u"࡙ࠫࡒࠧ㨑"):l11l1l_l1_ (u"ࠬࡋࡡࡴࡶࠣࡘ࡮ࡳ࡯ࡳࠩ㨒")
,l11l1l_l1_ (u"࠭ࡅࡄࠩ㨓"):l11l1l_l1_ (u"ࠧࡆࡥࡸࡥࡩࡵࡲࠨ㨔")
,l11l1l_l1_ (u"ࠨࡇࡊࠫ㨕"):l11l1l_l1_ (u"ࠩࡈ࡫ࡾࡶࡴࠨ㨖")
,l11l1l_l1_ (u"ࠪࡗ࡛࠭㨗"):l11l1l_l1_ (u"ࠫࡊࡲࠠࡔࡣ࡯ࡺࡦࡪ࡯ࡳࠩ㨘")
,l11l1l_l1_ (u"ࠬࡍࡑࠨ㨙"):l11l1l_l1_ (u"࠭ࡅࡲࡷࡤࡸࡴࡸࡩࡢ࡮ࠣࡋࡺ࡯࡮ࡦࡣࠪ㨚")
,l11l1l_l1_ (u"ࠧࡆࡔࠪ㨛"):l11l1l_l1_ (u"ࠨࡇࡵ࡭ࡹࡸࡥࡢࠩ㨜")
,l11l1l_l1_ (u"ࠩࡈࡉࠬ㨝"):l11l1l_l1_ (u"ࠪࡉࡸࡺ࡯࡯࡫ࡤࠫ㨞")
,l11l1l_l1_ (u"ࠫࡊ࡚ࠧ㨟"):l11l1l_l1_ (u"ࠬࡋࡴࡩ࡫ࡲࡴ࡮ࡧࠧ㨠")
,l11l1l_l1_ (u"࠭ࡆࡌࠩ㨡"):l11l1l_l1_ (u"ࠧࡇࡣ࡯࡯ࡱࡧ࡮ࡥࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ㨢")
,l11l1l_l1_ (u"ࠨࡈࡒࠫ㨣"):l11l1l_l1_ (u"ࠩࡉࡥࡷࡵࡥࠡࡋࡶࡰࡦࡴࡤࡴࠩ㨤")
,l11l1l_l1_ (u"ࠪࡊࡏ࠭㨥"):l11l1l_l1_ (u"ࠫࡋ࡯ࡪࡪࠩ㨦")
,l11l1l_l1_ (u"ࠬࡌࡉࠨ㨧"):l11l1l_l1_ (u"࠭ࡆࡪࡰ࡯ࡥࡳࡪࠧ㨨")
,l11l1l_l1_ (u"ࠧࡇࡔࠪ㨩"):l11l1l_l1_ (u"ࠨࡈࡵࡥࡳࡩࡥࠨ㨪")
,l11l1l_l1_ (u"ࠩࡊࡊࠬ㨫"):l11l1l_l1_ (u"ࠪࡊࡷ࡫࡮ࡤࡪࠣࡋࡺ࡯ࡡ࡯ࡣࠪ㨬")
,l11l1l_l1_ (u"ࠫࡕࡌࠧ㨭"):l11l1l_l1_ (u"ࠬࡌࡲࡦࡰࡦ࡬ࠥࡖ࡯࡭ࡻࡱࡩࡸ࡯ࡡࠨ㨮")
,l11l1l_l1_ (u"࠭ࡔࡇࠩ㨯"):l11l1l_l1_ (u"ࠧࡇࡴࡨࡲࡨ࡮ࠠࡔࡱࡸࡸ࡭࡫ࡲ࡯ࠢࡗࡩࡷࡸࡩࡵࡱࡵ࡭ࡪࡹࠧ㨰")
,l11l1l_l1_ (u"ࠨࡉࡄࠫ㨱"):l11l1l_l1_ (u"ࠩࡊࡥࡧࡵ࡮ࠨ㨲")
,l11l1l_l1_ (u"ࠪࡋࡒ࠭㨳"):l11l1l_l1_ (u"ࠫࡌࡧ࡭ࡣ࡫ࡤࠫ㨴")
,l11l1l_l1_ (u"ࠬࡍࡅࠨ㨵"):l11l1l_l1_ (u"࠭ࡇࡦࡱࡵ࡫࡮ࡧࠧ㨶")
,l11l1l_l1_ (u"ࠧࡅࡇࠪ㨷"):l11l1l_l1_ (u"ࠨࡉࡨࡶࡲࡧ࡮ࡺࠩ㨸")
,l11l1l_l1_ (u"ࠩࡊࡌࠬ㨹"):l11l1l_l1_ (u"ࠪࡋ࡭ࡧ࡮ࡢࠩ㨺")
,l11l1l_l1_ (u"ࠫࡌࡏࠧ㨻"):l11l1l_l1_ (u"ࠬࡍࡩࡣࡴࡤࡰࡹࡧࡲࠨ㨼")
,l11l1l_l1_ (u"࠭ࡇࡓࠩ㨽"):l11l1l_l1_ (u"ࠧࡈࡴࡨࡩࡨ࡫ࠧ㨾")
,l11l1l_l1_ (u"ࠨࡉࡏࠫ㨿"):l11l1l_l1_ (u"ࠩࡊࡶࡪ࡫࡮࡭ࡣࡱࡨࠬ㩀")
,l11l1l_l1_ (u"ࠪࡋࡉ࠭㩁"):l11l1l_l1_ (u"ࠫࡌࡸࡥ࡯ࡣࡧࡥࠬ㩂")
,l11l1l_l1_ (u"ࠬࡍࡐࠨ㩃"):l11l1l_l1_ (u"࠭ࡇࡶࡣࡧࡩࡱࡵࡵࡱࡧࠪ㩄")
,l11l1l_l1_ (u"ࠧࡈࡗࠪ㩅"):l11l1l_l1_ (u"ࠨࡉࡸࡥࡲ࠭㩆")
,l11l1l_l1_ (u"ࠩࡊࡘࠬ㩇"):l11l1l_l1_ (u"ࠪࡋࡺࡧࡴࡦ࡯ࡤࡰࡦ࠭㩈")
,l11l1l_l1_ (u"ࠫࡌࡍࠧ㩉"):l11l1l_l1_ (u"ࠬࡍࡵࡦࡴࡱࡷࡪࡿࠧ㩊")
,l11l1l_l1_ (u"࠭ࡇࡏࠩ㩋"):l11l1l_l1_ (u"ࠧࡈࡷ࡬ࡲࡪࡧࠧ㩌")
,l11l1l_l1_ (u"ࠨࡉ࡚ࠫ㩍"):l11l1l_l1_ (u"ࠩࡊࡹ࡮ࡴࡥࡢ࠯ࡅ࡭ࡸࡹࡡࡶࠩ㩎")
,l11l1l_l1_ (u"ࠪࡋ࡞࠭㩏"):l11l1l_l1_ (u"ࠫࡌࡻࡹࡢࡰࡤࠫ㩐")
,l11l1l_l1_ (u"ࠬࡎࡔࠨ㩑"):l11l1l_l1_ (u"࠭ࡈࡢ࡫ࡷ࡭ࠬ㩒")
,l11l1l_l1_ (u"ࠧࡉࡏࠪ㩓"):l11l1l_l1_ (u"ࠨࡊࡨࡥࡷࡪࠠࡊࡵ࡯ࡥࡳࡪࠠࡢࡰࡧࠤࡒࡩࡄࡰࡰࡤࡰࡩࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㩔")
,l11l1l_l1_ (u"ࠩࡋࡒࠬ㩕"):l11l1l_l1_ (u"ࠪࡌࡴࡴࡤࡶࡴࡤࡷࠬ㩖")
,l11l1l_l1_ (u"ࠫࡍࡑࠧ㩗"):l11l1l_l1_ (u"ࠬࡎ࡯࡯ࡩࠣࡏࡴࡴࡧࠨ㩘")
,l11l1l_l1_ (u"࠭ࡈࡖࠩ㩙"):l11l1l_l1_ (u"ࠧࡉࡷࡱ࡫ࡦࡸࡹࠨ㩚")
,l11l1l_l1_ (u"ࠨࡋࡖࠫ㩛"):l11l1l_l1_ (u"ࠩࡌࡧࡪࡲࡡ࡯ࡦࠪ㩜")
,l11l1l_l1_ (u"ࠪࡍࡓ࠭㩝"):l11l1l_l1_ (u"ࠫࡎࡴࡤࡪࡣࠪ㩞")
,l11l1l_l1_ (u"ࠬࡏࡄࠨ㩟"):l11l1l_l1_ (u"࠭ࡉ࡯ࡦࡲࡲࡪࡹࡩࡢࠩ㩠")
,l11l1l_l1_ (u"ࠧࡊࡔࠪ㩡"):l11l1l_l1_ (u"ࠨࡋࡵࡥࡳ࠭㩢")
,l11l1l_l1_ (u"ࠩࡌࡕࠬ㩣"):l11l1l_l1_ (u"ࠪࡍࡷࡧࡱࠨ㩤")
,l11l1l_l1_ (u"ࠫࡎࡋࠧ㩥"):l11l1l_l1_ (u"ࠬࡏࡲࡦ࡮ࡤࡲࡩ࠭㩦")
,l11l1l_l1_ (u"࠭ࡉࡎࠩ㩧"):l11l1l_l1_ (u"ࠧࡊࡵ࡯ࡩࠥࡵࡦࠡࡏࡤࡲࠬ㩨")
,l11l1l_l1_ (u"ࠨࡋࡏࠫ㩩"):l11l1l_l1_ (u"ࠩࡌࡷࡷࡧࡥ࡭ࠩ㩪")
,l11l1l_l1_ (u"ࠪࡍ࡙࠭㩫"):l11l1l_l1_ (u"ࠫࡎࡺࡡ࡭ࡻࠪ㩬")
,l11l1l_l1_ (u"ࠬࡉࡉࠨ㩭"):l11l1l_l1_ (u"࠭ࡉࡷࡱࡵࡽࠥࡉ࡯ࡢࡵࡷࠫ㩮")
,l11l1l_l1_ (u"ࠧࡋࡏࠪ㩯"):l11l1l_l1_ (u"ࠨࡌࡤࡱࡦ࡯ࡣࡢࠩ㩰")
,l11l1l_l1_ (u"ࠩࡍࡔࠬ㩱"):l11l1l_l1_ (u"ࠪࡎࡦࡶࡡ࡯ࠩ㩲")
,l11l1l_l1_ (u"ࠫࡏࡋࠧ㩳"):l11l1l_l1_ (u"ࠬࡐࡥࡳࡵࡨࡽࠬ㩴")
,l11l1l_l1_ (u"࠭ࡊࡐࠩ㩵"):l11l1l_l1_ (u"ࠧࡋࡱࡵࡨࡦࡴࠧ㩶")
,l11l1l_l1_ (u"ࠨࡍ࡝ࠫ㩷"):l11l1l_l1_ (u"ࠩࡎࡥࡿࡧ࡫ࡩࡵࡷࡥࡳ࠭㩸")
,l11l1l_l1_ (u"ࠪࡏࡊ࠭㩹"):l11l1l_l1_ (u"ࠫࡐ࡫࡮ࡺࡣࠪ㩺")
,l11l1l_l1_ (u"ࠬࡑࡉࠨ㩻"):l11l1l_l1_ (u"࠭ࡋࡪࡴ࡬ࡦࡦࡺࡩࠨ㩼")
,l11l1l_l1_ (u"࡙ࠧࡍࠪ㩽"):l11l1l_l1_ (u"ࠨࡍࡲࡷࡴࡼ࡯ࠨ㩾")
,l11l1l_l1_ (u"ࠩࡎ࡛ࠬ㩿"):l11l1l_l1_ (u"ࠪࡏࡺࡽࡡࡪࡶࠪ㪀")
,l11l1l_l1_ (u"ࠫࡐࡍࠧ㪁"):l11l1l_l1_ (u"ࠬࡑࡹࡳࡩࡼࡾࡸࡺࡡ࡯ࠩ㪂")
,l11l1l_l1_ (u"࠭ࡌࡂࠩ㪃"):l11l1l_l1_ (u"ࠧࡍࡣࡲࡷࠬ㪄")
,l11l1l_l1_ (u"ࠨࡎ࡙ࠫ㪅"):l11l1l_l1_ (u"ࠩࡏࡥࡹࡼࡩࡢࠩ㪆")
,l11l1l_l1_ (u"ࠪࡐࡇ࠭㪇"):l11l1l_l1_ (u"ࠫࡑ࡫ࡢࡢࡰࡲࡲࠬ㪈")
,l11l1l_l1_ (u"ࠬࡒࡓࠨ㪉"):l11l1l_l1_ (u"࠭ࡌࡦࡵࡲࡸ࡭ࡵࠧ㪊")
,l11l1l_l1_ (u"ࠧࡍࡔࠪ㪋"):l11l1l_l1_ (u"ࠨࡎ࡬ࡦࡪࡸࡩࡢࠩ㪌")
,l11l1l_l1_ (u"ࠩࡏ࡝ࠬ㪍"):l11l1l_l1_ (u"ࠪࡐ࡮ࡨࡹࡢࠩ㪎")
,l11l1l_l1_ (u"ࠫࡑࡏࠧ㪏"):l11l1l_l1_ (u"ࠬࡒࡩࡦࡥ࡫ࡸࡪࡴࡳࡵࡧ࡬ࡲࠬ㪐")
,l11l1l_l1_ (u"࠭ࡌࡕࠩ㪑"):l11l1l_l1_ (u"ࠧࡍ࡫ࡷ࡬ࡺࡧ࡮ࡪࡣࠪ㪒")
,l11l1l_l1_ (u"ࠨࡎࡘࠫ㪓"):l11l1l_l1_ (u"ࠩࡏࡹࡽ࡫࡭ࡣࡱࡸࡶ࡬࠭㪔")
,l11l1l_l1_ (u"ࠪࡑࡔ࠭㪕"):l11l1l_l1_ (u"ࠫࡒࡧࡣࡢࡱࠪ㪖")
,l11l1l_l1_ (u"ࠬࡓࡇࠨ㪗"):l11l1l_l1_ (u"࠭ࡍࡢࡦࡤ࡫ࡦࡹࡣࡢࡴࠪ㪘")
,l11l1l_l1_ (u"ࠧࡎ࡙ࠪ㪙"):l11l1l_l1_ (u"ࠨࡏࡤࡰࡦࡽࡩࠨ㪚")
,l11l1l_l1_ (u"ࠩࡐ࡝ࠬ㪛"):l11l1l_l1_ (u"ࠪࡑࡦࡲࡡࡺࡵ࡬ࡥࠬ㪜")
,l11l1l_l1_ (u"ࠫࡒ࡜ࠧ㪝"):l11l1l_l1_ (u"ࠬࡓࡡ࡭ࡦ࡬ࡺࡪࡹࠧ㪞")
,l11l1l_l1_ (u"࠭ࡍࡍࠩ㪟"):l11l1l_l1_ (u"ࠧࡎࡣ࡯࡭ࠬ㪠")
,l11l1l_l1_ (u"ࠨࡏࡗࠫ㪡"):l11l1l_l1_ (u"ࠩࡐࡥࡱࡺࡡࠨ㪢")
,l11l1l_l1_ (u"ࠪࡑࡍ࠭㪣"):l11l1l_l1_ (u"ࠫࡒࡧࡲࡴࡪࡤࡰࡱࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㪤")
,l11l1l_l1_ (u"ࠬࡓࡑࠨ㪥"):l11l1l_l1_ (u"࠭ࡍࡢࡴࡷ࡭ࡳ࡯ࡱࡶࡧࠪ㪦")
,l11l1l_l1_ (u"ࠧࡎࡔࠪ㪧"):l11l1l_l1_ (u"ࠨࡏࡤࡹࡷ࡯ࡴࡢࡰ࡬ࡥࠬ㪨")
,l11l1l_l1_ (u"ࠩࡐ࡙ࠬ㪩"):l11l1l_l1_ (u"ࠪࡑࡦࡻࡲࡪࡶ࡬ࡹࡸ࠭㪪")
,l11l1l_l1_ (u"ࠫ࡞࡚ࠧ㪫"):l11l1l_l1_ (u"ࠬࡓࡡࡺࡱࡷࡸࡪ࠭㪬")
,l11l1l_l1_ (u"࠭ࡍ࡙ࠩ㪭"):l11l1l_l1_ (u"ࠧࡎࡧࡻ࡭ࡨࡵࠧ㪮")
,l11l1l_l1_ (u"ࠨࡈࡐࠫ㪯"):l11l1l_l1_ (u"ࠩࡐ࡭ࡨࡸ࡯࡯ࡧࡶ࡭ࡦ࠭㪰")
,l11l1l_l1_ (u"ࠪࡑࡉ࠭㪱"):l11l1l_l1_ (u"ࠫࡒࡵ࡬ࡥࡱࡹࡥࠬ㪲")
,l11l1l_l1_ (u"ࠬࡓࡃࠨ㪳"):l11l1l_l1_ (u"࠭ࡍࡰࡰࡤࡧࡴ࠭㪴")
,l11l1l_l1_ (u"ࠧࡎࡐࠪ㪵"):l11l1l_l1_ (u"ࠨࡏࡲࡲ࡬ࡵ࡬ࡪࡣࠪ㪶")
,l11l1l_l1_ (u"ࠩࡐࡉࠬ㪷"):l11l1l_l1_ (u"ࠪࡑࡴࡴࡴࡦࡰࡨ࡫ࡷࡵࠧ㪸")
,l11l1l_l1_ (u"ࠫࡒ࡙ࠧ㪹"):l11l1l_l1_ (u"ࠬࡓ࡯࡯ࡶࡶࡩࡷࡸࡡࡵࠩ㪺")
,l11l1l_l1_ (u"࠭ࡍࡂࠩ㪻"):l11l1l_l1_ (u"ࠧࡎࡱࡵࡳࡨࡩ࡯ࠨ㪼")
,l11l1l_l1_ (u"ࠨࡏ࡝ࠫ㪽"):l11l1l_l1_ (u"ࠩࡐࡳࡿࡧ࡭ࡣ࡫ࡴࡹࡪ࠭㪾")
,l11l1l_l1_ (u"ࠪࡑࡒ࠭㪿"):l11l1l_l1_ (u"ࠫࡒࡿࡡ࡯࡯ࡤࡶࠥ࠮ࡂࡶࡴࡰࡥ࠮࠭㫀")
,l11l1l_l1_ (u"ࠬࡔࡁࠨ㫁"):l11l1l_l1_ (u"࠭ࡎࡢ࡯࡬ࡦ࡮ࡧࠧ㫂")
,l11l1l_l1_ (u"ࠧࡏࡔࠪ㫃"):l11l1l_l1_ (u"ࠨࡐࡤࡹࡷࡻࠧ㫄")
,l11l1l_l1_ (u"ࠩࡑࡔࠬ㫅"):l11l1l_l1_ (u"ࠪࡒࡪࡶࡡ࡭ࠩ㫆")
,l11l1l_l1_ (u"ࠫࡓࡒࠧ㫇"):l11l1l_l1_ (u"ࠬࡔࡥࡵࡪࡨࡶࡱࡧ࡮ࡥࡵࠪ㫈")
,l11l1l_l1_ (u"࠭ࡎࡄࠩ㫉"):l11l1l_l1_ (u"ࠧࡏࡧࡺࠤࡈࡧ࡬ࡦࡦࡲࡲ࡮ࡧࠧ㫊")
,l11l1l_l1_ (u"ࠨࡐ࡝ࠫ㫋"):l11l1l_l1_ (u"ࠩࡑࡩࡼ࡚ࠦࡦࡣ࡯ࡥࡳࡪࠧ㫌")
,l11l1l_l1_ (u"ࠪࡒࡎ࠭㫍"):l11l1l_l1_ (u"ࠫࡓ࡯ࡣࡢࡴࡤ࡫ࡺࡧࠧ㫎")
,l11l1l_l1_ (u"ࠬࡔࡅࠨ㫏"):l11l1l_l1_ (u"࠭ࡎࡪࡩࡨࡶࠬ㫐")
,l11l1l_l1_ (u"ࠧࡏࡉࠪ㫑"):l11l1l_l1_ (u"ࠨࡐ࡬࡫ࡪࡸࡩࡢࠩ㫒")
,l11l1l_l1_ (u"ࠩࡑ࡙ࠬ㫓"):l11l1l_l1_ (u"ࠪࡒ࡮ࡻࡥࠨ㫔")
,l11l1l_l1_ (u"ࠫࡓࡌࠧ㫕"):l11l1l_l1_ (u"ࠬࡔ࡯ࡳࡨࡲࡰࡰࠦࡉࡴ࡮ࡤࡲࡩ࠭㫖")
,l11l1l_l1_ (u"࠭ࡋࡑࠩ㫗"):l11l1l_l1_ (u"ࠧࡏࡱࡵࡸ࡭ࠦࡋࡰࡴࡨࡥࠬ㫘")
,l11l1l_l1_ (u"ࠨࡏࡎࠫ㫙"):l11l1l_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ㫚")
,l11l1l_l1_ (u"ࠪࡑࡕ࠭㫛"):l11l1l_l1_ (u"ࠫࡓࡵࡲࡵࡪࡨࡶࡳࠦࡍࡢࡴ࡬ࡥࡳࡧࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㫜")
,l11l1l_l1_ (u"ࠬࡔࡏࠨ㫝"):l11l1l_l1_ (u"࠭ࡎࡰࡴࡺࡥࡾ࠭㫞")
,l11l1l_l1_ (u"ࠧࡐࡏࠪ㫟"):l11l1l_l1_ (u"ࠨࡑࡰࡥࡳ࠭㫠")
,l11l1l_l1_ (u"ࠩࡓࡏࠬ㫡"):l11l1l_l1_ (u"ࠪࡔࡦࡱࡩࡴࡶࡤࡲࠬ㫢")
,l11l1l_l1_ (u"ࠫࡕ࡝ࠧ㫣"):l11l1l_l1_ (u"ࠬࡖࡡ࡭ࡣࡸࠫ㫤")
,l11l1l_l1_ (u"࠭ࡐࡔࠩ㫥"):l11l1l_l1_ (u"ࠧࡑࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪ㫦")
,l11l1l_l1_ (u"ࠨࡒࡄࠫ㫧"):l11l1l_l1_ (u"ࠩࡓࡥࡳࡧ࡭ࡢࠩ㫨")
,l11l1l_l1_ (u"ࠪࡔࡌ࠭㫩"):l11l1l_l1_ (u"ࠫࡕࡧࡰࡶࡣࠣࡒࡪࡽࠠࡈࡷ࡬ࡲࡪࡧࠧ㫪")
,l11l1l_l1_ (u"ࠬࡖ࡙ࠨ㫫"):l11l1l_l1_ (u"࠭ࡐࡢࡴࡤ࡫ࡺࡧࡹࠨ㫬")
,l11l1l_l1_ (u"ࠧࡑࡇࠪ㫭"):l11l1l_l1_ (u"ࠨࡒࡨࡶࡺ࠭㫮")
,l11l1l_l1_ (u"ࠩࡓࡌࠬ㫯"):l11l1l_l1_ (u"ࠪࡔ࡭࡯࡬ࡪࡲࡳ࡭ࡳ࡫ࡳࠨ㫰")
,l11l1l_l1_ (u"ࠫࡕࡔࠧ㫱"):l11l1l_l1_ (u"ࠬࡖࡩࡵࡥࡤ࡭ࡷࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㫲")
,l11l1l_l1_ (u"࠭ࡐࡍࠩ㫳"):l11l1l_l1_ (u"ࠧࡑࡱ࡯ࡥࡳࡪࠧ㫴")
,l11l1l_l1_ (u"ࠨࡒࡗࠫ㫵"):l11l1l_l1_ (u"ࠩࡓࡳࡷࡺࡵࡨࡣ࡯ࠫ㫶")
,l11l1l_l1_ (u"ࠪࡔࡗ࠭㫷"):l11l1l_l1_ (u"ࠫࡕࡻࡥࡳࡶࡲࠤࡗ࡯ࡣࡰࠩ㫸")
,l11l1l_l1_ (u"ࠬࡗࡁࠨ㫹"):l11l1l_l1_ (u"࠭ࡑࡢࡶࡤࡶࠬ㫺")
,l11l1l_l1_ (u"ࠧࡄࡉࠪ㫻"):l11l1l_l1_ (u"ࠨࡔࡨࡴࡺࡨ࡬ࡪࡥࠣࡳ࡫ࠦࡴࡩࡧࠣࡇࡴࡴࡧࡰࠩ㫼")
,l11l1l_l1_ (u"ࠩࡕࡓࠬ㫽"):l11l1l_l1_ (u"ࠪࡖࡴࡳࡡ࡯࡫ࡤࠫ㫾")
,l11l1l_l1_ (u"ࠫࡗ࡛ࠧ㫿"):l11l1l_l1_ (u"ࠬࡘࡵࡴࡵ࡬ࡥࠬ㬀")
,l11l1l_l1_ (u"࠭ࡒࡘࠩ㬁"):l11l1l_l1_ (u"ࠧࡓࡹࡤࡲࡩࡧࠧ㬂")
,l11l1l_l1_ (u"ࠨࡔࡈࠫ㬃"):l11l1l_l1_ (u"ࠩࡕ࣭ࡺࡴࡩࡰࡰࠪ㬄")
,l11l1l_l1_ (u"ࠪࡆࡑ࠭㬅"):l11l1l_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡆࡦࡸࡴࡩ࣫࡯ࡩࡲࡿࠧ㬆")
,l11l1l_l1_ (u"࡙ࠬࡈࠨ㬇"):l11l1l_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡎࡥ࡭ࡧࡱࡥࠬ㬈")
,l11l1l_l1_ (u"ࠧࡌࡐࠪ㬉"):l11l1l_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡌ࡫ࡷࡸࡸࠦࡡ࡯ࡦࠣࡒࡪࡼࡩࡴࠩ㬊")
,l11l1l_l1_ (u"ࠩࡏࡇࠬ㬋"):l11l1l_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡏࡹࡨ࡯ࡡࠨ㬌")
,l11l1l_l1_ (u"ࠫࡒࡌࠧ㬍"):l11l1l_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡒࡧࡲࡵ࡫ࡱࠫ㬎")
,l11l1l_l1_ (u"࠭ࡐࡎࠩ㬏"):l11l1l_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡐࡪࡧࡵࡶࡪࠦࡡ࡯ࡦࠣࡑ࡮ࡷࡵࡦ࡮ࡲࡲࠬ㬐")
,l11l1l_l1_ (u"ࠨࡘࡆࠫ㬑"):l11l1l_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡘ࡬ࡲࡨ࡫࡮ࡵࠢࡤࡲࡩࠦࡴࡩࡧࠣࡋࡷ࡫࡮ࡢࡦ࡬ࡲࡪࡹࠧ㬒")
,l11l1l_l1_ (u"࡛ࠪࡘ࠭㬓"):l11l1l_l1_ (u"ࠫࡘࡧ࡭ࡰࡣࠪ㬔")
,l11l1l_l1_ (u"࡙ࠬࡍࠨ㬕"):l11l1l_l1_ (u"࠭ࡓࡢࡰࠣࡑࡦࡸࡩ࡯ࡱࠪ㬖")
,l11l1l_l1_ (u"ࠧࡔࡃࠪ㬗"):l11l1l_l1_ (u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧ㬘")
,l11l1l_l1_ (u"ࠩࡖࡒࠬ㬙"):l11l1l_l1_ (u"ࠪࡗࡪࡴࡥࡨࡣ࡯ࠫ㬚")
,l11l1l_l1_ (u"ࠫࡗ࡙ࠧ㬛"):l11l1l_l1_ (u"࡙ࠬࡥࡳࡤ࡬ࡥࠬ㬜")
,l11l1l_l1_ (u"࠭ࡓࡄࠩ㬝"):l11l1l_l1_ (u"ࠧࡔࡧࡼࡧ࡭࡫࡬࡭ࡧࡶࠫ㬞")
,l11l1l_l1_ (u"ࠨࡕࡏࠫ㬟"):l11l1l_l1_ (u"ࠩࡖ࡭ࡪࡸࡲࡢࠢࡏࡩࡴࡴࡥࠨ㬠")
,l11l1l_l1_ (u"ࠪࡗࡌ࠭㬡"):l11l1l_l1_ (u"ࠫࡘ࡯࡮ࡨࡣࡳࡳࡷ࡫ࠧ㬢")
,l11l1l_l1_ (u"࡙ࠬࡘࠨ㬣"):l11l1l_l1_ (u"࠭ࡓࡪࡰࡷࠤࡒࡧࡡࡳࡶࡨࡲࠬ㬤")
,l11l1l_l1_ (u"ࠧࡔࡍࠪ㬥"):l11l1l_l1_ (u"ࠨࡕ࡯ࡳࡻࡧ࡫ࡪࡣࠪ㬦")
,l11l1l_l1_ (u"ࠩࡖࡍࠬ㬧"):l11l1l_l1_ (u"ࠪࡗࡱࡵࡶࡦࡰ࡬ࡥࠬ㬨")
,l11l1l_l1_ (u"ࠫࡘࡈࠧ㬩"):l11l1l_l1_ (u"࡙ࠬ࡯࡭ࡱࡰࡳࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㬪")
,l11l1l_l1_ (u"࠭ࡓࡐࠩ㬫"):l11l1l_l1_ (u"ࠧࡔࡱࡰࡥࡱ࡯ࡡࠨ㬬")
,l11l1l_l1_ (u"ࠨ࡜ࡄࠫ㬭"):l11l1l_l1_ (u"ࠩࡖࡳࡺࡺࡨࠡࡃࡩࡶ࡮ࡩࡡࠨ㬮")
,l11l1l_l1_ (u"ࠪࡋࡘ࠭㬯"):l11l1l_l1_ (u"ࠫࡘࡵࡵࡵࡪࠣࡋࡪࡵࡲࡨ࡫ࡤࠤࡦࡴࡤࠡࡶ࡫ࡩ࡙ࠥ࡯ࡶࡶ࡫ࠤࡘࡧ࡮ࡥࡹ࡬ࡧ࡭ࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㬰")
,l11l1l_l1_ (u"ࠬࡑࡒࠨ㬱"):l11l1l_l1_ (u"࠭ࡓࡰࡷࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ㬲")
,l11l1l_l1_ (u"ࠧࡔࡕࠪ㬳"):l11l1l_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡔࡷࡧࡥࡳ࠭㬴")
,l11l1l_l1_ (u"ࠩࡈࡗࠬ㬵"):l11l1l_l1_ (u"ࠪࡗࡵࡧࡩ࡯ࠩ㬶")
,l11l1l_l1_ (u"ࠫࡑࡑࠧ㬷"):l11l1l_l1_ (u"࡙ࠬࡲࡪࠢࡏࡥࡳࡱࡡࠨ㬸")
,l11l1l_l1_ (u"࠭ࡓࡅࠩ㬹"):l11l1l_l1_ (u"ࠧࡔࡷࡧࡥࡳ࠭㬺")
,l11l1l_l1_ (u"ࠨࡕࡕࠫ㬻"):l11l1l_l1_ (u"ࠩࡖࡹࡷ࡯࡮ࡢ࡯ࡨࠫ㬼")
,l11l1l_l1_ (u"ࠪࡗࡏ࠭㬽"):l11l1l_l1_ (u"ࠫࡘࡼࡡ࡭ࡤࡤࡶࡩࠦࡡ࡯ࡦࠣࡎࡦࡴࠠࡎࡣࡼࡩࡳ࠭㬾")
,l11l1l_l1_ (u"࡙࡚ࠬࠨ㬿"):l11l1l_l1_ (u"࠭ࡓࡸࡣࡽ࡭ࡱࡧ࡮ࡥࠩ㭀")
,l11l1l_l1_ (u"ࠧࡔࡇࠪ㭁"):l11l1l_l1_ (u"ࠨࡕࡺࡩࡩ࡫࡮ࠨ㭂")
,l11l1l_l1_ (u"ࠩࡆࡌࠬ㭃"):l11l1l_l1_ (u"ࠪࡗࡼ࡯ࡴࡻࡧࡵࡰࡦࡴࡤࠨ㭄")
,l11l1l_l1_ (u"ࠫࡘ࡟ࠧ㭅"):l11l1l_l1_ (u"࡙ࠬࡹࡳ࡫ࡤࠫ㭆")
,l11l1l_l1_ (u"࠭ࡓࡕࠩ㭇"):l11l1l_l1_ (u"ࠧࡔࣥࡲࠤ࡙ࡵ࡭࣪ࠢࡤࡲࡩࠦࡐࡳ࣯ࡱࡧ࡮ࡶࡥࠨ㭈")
,l11l1l_l1_ (u"ࠨࡖ࡚ࠫ㭉"):l11l1l_l1_ (u"ࠩࡗࡥ࡮ࡽࡡ࡯ࠩ㭊")
,l11l1l_l1_ (u"ࠪࡘࡏ࠭㭋"):l11l1l_l1_ (u"࡙ࠫࡧࡪࡪ࡭࡬ࡷࡹࡧ࡮ࠨ㭌")
,l11l1l_l1_ (u"࡚࡚ࠬࠨ㭍"):l11l1l_l1_ (u"࠭ࡔࡢࡰࡽࡥࡳ࡯ࡡࠨ㭎")
,l11l1l_l1_ (u"ࠧࡕࡊࠪ㭏"):l11l1l_l1_ (u"ࠨࡖ࡫ࡥ࡮ࡲࡡ࡯ࡦࠪ㭐")
,l11l1l_l1_ (u"ࠩࡗࡋࠬ㭑"):l11l1l_l1_ (u"ࠪࡘࡴ࡭࡯ࠨ㭒")
,l11l1l_l1_ (u"࡙ࠫࡑࠧ㭓"):l11l1l_l1_ (u"࡚ࠬ࡯࡬ࡧ࡯ࡥࡺ࠭㭔")
,l11l1l_l1_ (u"࠭ࡔࡐࠩ㭕"):l11l1l_l1_ (u"ࠧࡕࡱࡱ࡫ࡦ࠭㭖")
,l11l1l_l1_ (u"ࠨࡖࡗࠫ㭗"):l11l1l_l1_ (u"ࠩࡗࡶ࡮ࡴࡩࡥࡣࡧࠤࡦࡴࡤࠡࡖࡲࡦࡦ࡭࡯ࠨ㭘")
,l11l1l_l1_ (u"ࠪࡘࡓ࠭㭙"):l11l1l_l1_ (u"࡙ࠫࡻ࡮ࡪࡵ࡬ࡥࠬ㭚")
,l11l1l_l1_ (u"࡚ࠬࡒࠨ㭛"):l11l1l_l1_ (u"࠭ࡔࡶࡴ࡮ࡩࡾ࠭㭜")
,l11l1l_l1_ (u"ࠧࡕࡏࠪ㭝"):l11l1l_l1_ (u"ࠨࡖࡸࡶࡰࡳࡥ࡯࡫ࡶࡸࡦࡴࠧ㭞")
,l11l1l_l1_ (u"ࠩࡗࡇࠬ㭟"):l11l1l_l1_ (u"ࠪࡘࡺࡸ࡫ࡴࠢࡤࡲࡩࠦࡃࡢ࡫ࡦࡳࡸࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㭠")
,l11l1l_l1_ (u"࡙ࠫ࡜ࠧ㭡"):l11l1l_l1_ (u"࡚ࠬࡵࡷࡣ࡯ࡹࠬ㭢")
,l11l1l_l1_ (u"࠭ࡕࡎࠩ㭣"):l11l1l_l1_ (u"ࠧࡖ࠰ࡖ࠲ࠥࡓࡩ࡯ࡱࡵࠤࡔࡻࡴ࡭ࡻ࡬ࡲ࡬ࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㭤")
,l11l1l_l1_ (u"ࠨࡘࡌࠫ㭥"):l11l1l_l1_ (u"ࠩࡘ࠲ࡘ࠴ࠠࡗ࡫ࡵ࡫࡮ࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㭦")
,l11l1l_l1_ (u"࡙ࠪࡌ࠭㭧"):l11l1l_l1_ (u"࡚ࠫ࡭ࡡ࡯ࡦࡤࠫ㭨")
,l11l1l_l1_ (u"࡛ࠬࡁࠨ㭩"):l11l1l_l1_ (u"࠭ࡕ࡬ࡴࡤ࡭ࡳ࡫ࠧ㭪")
,l11l1l_l1_ (u"ࠧࡂࡇࠪ㭫"):l11l1l_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨ㭬")
,l11l1l_l1_ (u"ࠩࡘࡏࠬ㭭"):l11l1l_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ㭮")
,l11l1l_l1_ (u"࡚࡙ࠫࠧ㭯"):l11l1l_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ㭰")
,l11l1l_l1_ (u"࠭ࡕ࡚ࠩ㭱"):l11l1l_l1_ (u"ࠧࡖࡴࡸ࡫ࡺࡧࡹࠨ㭲")
,l11l1l_l1_ (u"ࠨࡗ࡝ࠫ㭳"):l11l1l_l1_ (u"ࠩࡘࡾࡧ࡫࡫ࡪࡵࡷࡥࡳ࠭㭴")
,l11l1l_l1_ (u"࡚࡚ࠪ࠭㭵"):l11l1l_l1_ (u"࡛ࠫࡧ࡮ࡶࡣࡷࡹࠬ㭶")
,l11l1l_l1_ (u"ࠬ࡜ࡁࠨ㭷"):l11l1l_l1_ (u"࠭ࡖࡢࡶ࡬ࡧࡦࡴࠠࡄ࡫ࡷࡽࠬ㭸")
,l11l1l_l1_ (u"ࠧࡗࡇࠪ㭹"):l11l1l_l1_ (u"ࠨࡘࡨࡲࡪࢀࡵࡦ࡮ࡤࠫ㭺")
,l11l1l_l1_ (u"࡙ࠩࡒࠬ㭻"):l11l1l_l1_ (u"࡚ࠪ࡮࡫ࡴ࡯ࡣࡰࠫ㭼")
,l11l1l_l1_ (u"ࠫ࡜ࡌࠧ㭽"):l11l1l_l1_ (u"ࠬ࡝ࡡ࡭࡮࡬ࡷࠥࡧ࡮ࡥࠢࡉࡹࡹࡻ࡮ࡢࠩ㭾")
,l11l1l_l1_ (u"࠭ࡅࡉࠩ㭿"):l11l1l_l1_ (u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨ㮀")
,l11l1l_l1_ (u"ࠨ࡛ࡈࠫ㮁"):l11l1l_l1_ (u"ࠩ࡜ࡩࡲ࡫࡮ࠨ㮂")
,l11l1l_l1_ (u"ࠪ࡞ࡒ࠭㮃"):l11l1l_l1_ (u"ࠫ࡟ࡧ࡭ࡣ࡫ࡤࠫ㮄")
,l11l1l_l1_ (u"ࠬࡠࡗࠨ㮅"):l11l1l_l1_ (u"࡚࠭ࡪ࡯ࡥࡥࡧࡽࡥࠨ㮆")
,l11l1l_l1_ (u"ࠧࡂ࡚ࠪ㮇"):l11l1l_l1_ (u"ࠨࣇ࡯ࡥࡳࡪࠧ㮈")
}
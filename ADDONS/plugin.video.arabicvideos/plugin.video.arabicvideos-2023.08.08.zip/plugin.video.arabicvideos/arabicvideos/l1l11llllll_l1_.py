# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㇋")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡏࡖ࡟ࡥࠧ㇌")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ㇍"),l11l1l_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫ㇎"),l11l1l_l1_ (u"ࠫฬ๊วใีส้ࠬ㇏"),l11l1l_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩ㇐")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l1lllll_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l1111_l1_(url,text)
	elif mode==704: results = l11lll_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㇑"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ㇒"),l11l1l_l1_ (u"ࠨࠩ㇓"),l11l1l_l1_ (u"ࠩࠪ㇔"),l11l1l_l1_ (u"ࠪࠫ㇕"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㇖"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㇗"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㇘"),l11l1l_l1_ (u"ࠧࠨ㇙"),709,l11l1l_l1_ (u"ࠨࠩ㇚"),l11l1l_l1_ (u"ࠩࠪ㇛"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㇜"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㇝"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㇞"),l11l1l_l1_ (u"࠭ࠧ㇟"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇠"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㇡")+l1111l_l1_+l11l1l_l1_ (u"่้ࠩ๏ุࠧ㇢"),l11l11_l1_,701,l11l1l_l1_ (u"ࠪࠫ㇣"),l11l1l_l1_ (u"ࠫࠬ㇤"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㇥"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㇦"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㇧")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ㇨"),l11l11_l1_,701,l11l1l_l1_ (u"ࠩࠪ㇩"),l11l1l_l1_ (u"ࠪࠫ㇪"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㇫"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㇬"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㇭")+l1111l_l1_+l11l1l_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭㇮"),l11l11_l1_,701,l11l1l_l1_ (u"ࠨࠩ㇯"),l11l1l_l1_ (u"ࠩࠪㇰ"),l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧㇱ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㇲ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧㇳ")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ㇴ"),l11l11_l1_,701,l11l1l_l1_ (u"ࠧࠨㇵ"),l11l1l_l1_ (u"ࠨࠩㇶ"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫㇷ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㇸ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㇹ"),l11l1l_l1_ (u"ࠬ࠭ㇺ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰ࡮࠯ࡷࡳࡵ࠳࡮ࡢࡸࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠨㇻ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧㇼ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		title = title.replace(l11l1l_l1_ (u"ࠨ࠾ࡥࡂࠬㇽ"),l11l1l_l1_ (u"ࠩࠪㇾ")).strip(l11l1l_l1_ (u"ࠪࠤࠬㇿ"))
		if title in l1l111_l1_: continue
		if l1llll1_l1_.endswith(l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠪ㈀")): continue
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㈁"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㈂")+l1111l_l1_+title,l1llll1_l1_,704)
	#addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㈃"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㈄"),l11l1l_l1_ (u"ࠩࠪ㈅"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ㈆"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ㈇"),html,re.DOTALL)
	#for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠬ࠭㈈"))
	#block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ㈉"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	title = title.replace(l11l1l_l1_ (u"ࠧ࠽ࡤࡁࠫ㈊"),l11l1l_l1_ (u"ࠨࠩ㈋")).strip(l11l1l_l1_ (u"ࠩࠣࠫ㈌"))
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㈍"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㈎")+l1111l_l1_+title,l1llll1_l1_,704)
	return
def l11lll_l1_(url):
	l1ll1l11l_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㈏"),url,l11l1l_l1_ (u"࠭ࠧ㈐"),l11l1l_l1_ (u"ࠧࠨ㈑"),l11l1l_l1_ (u"ࠨࠩ㈒"),l11l1l_l1_ (u"ࠩࠪ㈓"),l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㈔"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡷࡵ࡬ࡦ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㈕"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭㈖"),l11l1l_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ㈗"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㈘"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠨࠩ㈙"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㈚"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㈛"),l11l1l_l1_ (u"ࠫࠬ㈜"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㈝"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"࠭࠺ࠡࠩ㈞")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈟"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l11l_l1_ = True
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㈠"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㈡"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1l11l_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㈢"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㈣"),l11l1l_l1_ (u"ࠬ࠭㈤"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈥"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l11l_l1_ = True
	l1l11ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡪࡴࡵࡴࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㈦"),html,re.DOTALL)
	if l1l11ll1l_l1_:
		block = l1l11ll1l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㈧"),block,re.DOTALL)
		if 1:
			if l1ll1l11l_l1_: addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㈨"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈩"),l11l1l_l1_ (u"ࠫࠬ㈪"),9999)
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ㈫"))
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈬"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l11l_l1_ = True
	if not l1ll1l11l_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠧࠨ㈭")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㈮"),l11l1l_l1_ (u"ࠩࠪ㈯"),request,url)
	if request==l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ㈰"):
		url,search = url.split(l11l1l_l1_ (u"ࠫࡄ࠭㈱"),1)
		data = l11l1l_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ㈲")+search
		headers = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㈳"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ㈴")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㈵"),url,data,headers,l11l1l_l1_ (u"ࠩࠪ㈶"),l11l1l_l1_ (u"ࠪࠫ㈷"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ㈸"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㈹"),url,l11l1l_l1_ (u"࠭ࠧ㈺"),l11l1l_l1_ (u"ࠧࠨ㈻"),l11l1l_l1_ (u"ࠨࠩ㈼"),l11l1l_l1_ (u"ࠩࠪ㈽"),l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㈾"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠫࠬ㈿"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ㉀"))
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ㉁"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㉂"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠨࠩ㉃"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㉄"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㉅"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㉆"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㉇"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ㉈"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㉉"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ㉊"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩ㉋"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㉌"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠫࠬ㉍"),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㉎"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㉏"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ㉐"),l11l1l_l1_ (u"ࠨใํ่๊࠭㉑"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ㉒"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ㉓"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ㉔"),l11l1l_l1_ (u"ࠬํฯศใࠪ㉕"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭㉖"),l11l1l_l1_ (u"ฺࠧำูࠫ㉗"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ㉘"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ㉙"),l11l1l_l1_ (u"ุ้ࠪือ๋หࠪ㉚")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠫ࠴࠭㉛"))
		if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㉜") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨ㉝")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ㉞"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭㉟") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ㉠")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ㉡"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭㉢"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ㉣"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㉤"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㉥"):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㉦"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㉧") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㉨"),l1111l_l1_+title,l1llll1_l1_,703,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ㉩") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㉪"),l1111l_l1_+title,l1llll1_l1_,701,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㉫"),l1111l_l1_+title,l1llll1_l1_,703,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㉬"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ㉭")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㉮"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㉯"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭㉰"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ㉱")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ㉲"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉳"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ㉴")+title,l1llll1_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㉵"),l11l1l_l1_ (u"ࠪࠫ㉶"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ㉷"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㉸"),url,l11l1l_l1_ (u"࠭ࠧ㉹"),l11l1l_l1_ (u"ࠧࠨ㉺"),l11l1l_l1_ (u"ࠨࠩ㉻"),l11l1l_l1_ (u"ࠩࠪ㉼"),l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㉽"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ㉾"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㉿"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"࠭ࠧ㊀")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ㊁"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㊂"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠩࠦࠫ㊃"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㊄"),l1111l_l1_+title,url,703,l1ll1l_l1_,l11l1l_l1_ (u"ࠫࠬ㊅"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࡁࠫ㊆"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ㊇"),str(l1l11ll_l1_))
	block = l1l11ll_l1_[0]
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࠬ㊈")+l1l11_l1_+l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㊉"),block,re.DOTALL)
	if not l1l1111_l1_: l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨ㊊")+l1l11_l1_+l11l1l_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㊋"),block,re.DOTALL)
	if not l1l1111_l1_: l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡕࡨࡥࡸࡵ࡮ࠨ㊌")+l1l11_l1_+l11l1l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㊍"),block,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧ㊎"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㊏"),l11l1l_l1_ (u"ࠨࠩ㊐"),l11l1l_l1_ (u"ࠩࠪ㊑"),l11l1l_l1_ (u"ࠪ࠶࠷࠸࠲࠳ࠩ㊒"))
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ㊓"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㊔"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠮࠰ࠩ㊕"))
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ㊖")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ㊗"))
			title = title.replace(l11l1l_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧ㊘"),l11l1l_l1_ (u"ࠪࠤࠬ㊙"))
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㊚"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭㊛"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ㊜") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ㊝")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ㊞"))
		#		addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㊟"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111lll_l1_,l1lll1l1_l1_ = [],[],[]
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㊠"),l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ㊡"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㊢"),l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧ㊣"),l11l1l_l1_ (u"ࠧࠨ㊤"),l11l1l_l1_ (u"ࠨࠩ㊥"),l11l1l_l1_ (u"ࠩࠪ㊦"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㊧"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ㊨"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		# l1l1111ll_l1_ l1llll1_l1_
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㊩"),block,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll1_l1_[0]
			l1l111lll_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ㊪"))
			l1lll1_l1_.append(l1llll1_l1_)
		# l11l1l111_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠢࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠣ㊫"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ㊬"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㊭")+title+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ㊮"))
				l1lll1_l1_.append(l1llll1_l1_)
		# download l1l1_l1_
		#l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㊯"),block,re.DOTALL)
		#for l1llll1_l1_,title in l1l1_l1_:
		#	if l1llll1_l1_ not in l1lll1_l1_:
		#		title = title.strip(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ㊰"))
		#		l1l111lll_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㊱")+title+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㊲"))
		#		l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111lll_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll1l1_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㊳"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㊴"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠪࠫ㊵"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠫࠬ㊶"): return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ㊷"),l11l1l_l1_ (u"࠭ࠫࠨ㊸"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ㊹")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ㊺"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭㊻")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ㊼"))
	return
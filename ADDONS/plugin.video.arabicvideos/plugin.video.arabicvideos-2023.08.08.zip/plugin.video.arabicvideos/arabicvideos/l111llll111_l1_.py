# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㾇")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩ㾈")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠫฬ์่ศ฻ࠣหๆ๊วๆࠩ㾉"),l11l1l_l1_ (u"ࠬา่ะษอࠤฬ็ไศ็ࠪ㾊")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1lllll_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1lll1ll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾋"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㾌"),l11l1l_l1_ (u"ࠨࠩ㾍"),389,l11l1l_l1_ (u"ࠩࠪ㾎"),l11l1l_l1_ (u"ࠪࠫ㾏"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㾐"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㾑"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㾒"),l11l1l_l1_ (u"ࠧࠨ㾓"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾔"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㾕")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ㾖"),l11l11_l1_,381,l11l1l_l1_ (u"ࠫࠬ㾗"),l11l1l_l1_ (u"ࠬ࠭㾘"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㾙"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㾚"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㾛")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัอๆษ์ฬࠫ㾜"),l11l11_l1_,381,l11l1l_l1_ (u"ࠪࠫ㾝"),l11l1l_l1_ (u"ࠫࠬ㾞"),l11l1l_l1_ (u"ࠬࡹࡩࡥࡧࡵࠫ㾟"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㾠"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ㾡"),l11l1l_l1_ (u"ࠨࠩ㾢"),l11l1l_l1_ (u"ࠩࠪ㾣"),l11l1l_l1_ (u"ࠪࠫ㾤"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㾥"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㾦"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾧"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㾨")+l1111l_l1_+title,l11l11_l1_,381,l11l1l_l1_ (u"ࠨࠩ㾩"),l11l1l_l1_ (u"ࠩࠪ㾪"),l11l1l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㾫")+str(seq))
	block = l11l1l_l1_ (u"ࠫࠬ㾬")
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪ㾭"),html,re.DOTALL)
	if l1l11ll_l1_: block += l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ㾮"),html,re.DOTALL)
	if l1l11ll_l1_: block += l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㾯"),block,re.DOTALL)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㾰"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㾱"),l11l1l_l1_ (u"ࠪࠫ㾲"),9999)
	first = True
	for l1llll1_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11l1l_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫ㾳"):
			if first:
				title = l11l1l_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ㾴")+title
				first = False
			else: title = l11l1l_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ㾵")+title
		if title not in l1l111_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㾶"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㾷")+l1111l_l1_+title,l1llll1_l1_,381)
	return html
def l1lllll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㾸"),l11l1l_l1_ (u"ࠪࠫ㾹"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㾺"),url,l11l1l_l1_ (u"ࠬ࠭㾻"),l11l1l_l1_ (u"࠭ࠧ㾼"),l11l1l_l1_ (u"ࠧࠨ㾽"),l11l1l_l1_ (u"ࠨࠩ㾾"),l11l1l_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭㾿"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ㿀"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ㿁"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿂"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ㿃"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ㿄"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		z = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㿅"),block,re.DOTALL)
		l1lll1_l1_,l1l111111_l1_,l1ll1lll_l1_ = zip(*z)
		items = zip(l1l111111_l1_,l1lll1_l1_,l1ll1lll_l1_)
	elif type==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㿆"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ㿇"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㿈"),block,re.DOTALL)
	elif l11l1l_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㿉") in type:
		seq = int(type[-1:])
		html = html.replace(l11l1l_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ㿊"),l11l1l_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭㿋"))
		html = html.replace(l11l1l_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ㿌"),l11l1l_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭㿍"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ㿎"),html,re.DOTALL)
		block = l1l11ll_l1_[seq]
		if seq==2: items = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㿏"),block,re.DOTALL)
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ㿐"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0][0]
			if l11l1l_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ㿑") in url:
				items = re.findall(l11l1l_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㿒"),block,re.DOTALL)
			elif l11l1l_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ㿓") in url:
				items = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿔"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㿕"),block,re.DOTALL)
	l11l_l1_ = []
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࠪ㿖") in title:
			title = re.findall(l11l1l_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡨࡶ࡮࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿗"),title,re.DOTALL)
			title = title[0][1]#+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ㿘")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㿙")+title
		l1lll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ㿚"),title,re.DOTALL)
		if l1lll11ll_l1_: title = l1lll11ll_l1_[0]
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ㿛") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㿜"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㿝") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿞"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ㿟") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿠"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ㿡") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㿢"),l1111l_l1_+title,l1llll1_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㿣"),l1111l_l1_+title,l1llll1_l1_,382,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡕࡧࡧࡦࠢࠫ࠲࠯ࡅࠩࠡࡱࡩࠤ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㿤"),html,re.DOTALL)
	if l1l11ll_l1_:
		current = l1l11ll_l1_[0][0]
		last = l1l11ll_l1_[0][1]
		block = l1l11ll_l1_[0][2]
		items = re.findall(l11l1l_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ㿥"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title==l11l1l_l1_ (u"࠭ࠧ㿦") or title==last: continue
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿧"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ㿨")+title,l1llll1_l1_,381,l11l1l_l1_ (u"ࠩࠪ㿩"),l11l1l_l1_ (u"ࠪࠫ㿪"),type)
		#if title==last:
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ㿫")+title+l11l1l_l1_ (u"ࠬ࠵ࠧ㿬"),l11l1l_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭㿭")+last+l11l1l_l1_ (u"ࠧ࠰ࠩ㿮"))
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿯"),l1111l_l1_+l11l1l_l1_ (u"ࠩสาึࠦีโฯฬࠤࠬ㿰")+last,l1llll1_l1_,381,l11l1l_l1_ (u"ࠪࠫ㿱"),l11l1l_l1_ (u"ࠫࠬ㿲"),type)
	return
def l1lll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㿳"),url,l11l1l_l1_ (u"࠭ࠧ㿴"),l11l1l_l1_ (u"ࠧࠨ㿵"),l11l1l_l1_ (u"ࠨࠩ㿶"),l11l1l_l1_ (u"ࠩࠪ㿷"),l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㿸"))
	html = response.content
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㿹"),html,re.DOTALL)
	if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_,False):
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㿺"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ึุ่๊ࠠๅๆๆฬฬื้ࠠษ็้อืๅอ่๊ࠢ฾ํࠧ㿻"),l11l1l_l1_ (u"ࠧࠨ㿼"),9999)
		return
	if l11l1l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ㿽") in url or l11l1l_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ㿾") in url:
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡯ࡴࡦ࡯ࠪࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ㿿"),html,re.DOTALL)
		if l111ll1_l1_:
			l111ll1_l1_ = l111ll1_l1_[1]
			l1lll1ll_l1_(l111ll1_l1_)
			return
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠩࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡧࡳࡵࠤࠪࠫࠬ䀀"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ䀁"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1l1_l1_,l1llll1_l1_,name in items:
			title = l1ll1l1_l1_+l11l1l_l1_ (u"࠭ࠠ࠻ࠢࠪ䀂")+name+l11l1l_l1_ (u"ࠧࠡษ็ั้่ษࠨ䀃")
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䀄"),l1111l_l1_+title,l1llll1_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䀅"),url,l11l1l_l1_ (u"ࠪࠫ䀆"),l11l1l_l1_ (u"ࠫࠬ䀇"),l11l1l_l1_ (u"ࠬ࠭䀈"),l11l1l_l1_ (u"࠭ࠧ䀉"),l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䀊"))
	html = response.content
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䀋"),html,re.DOTALL)
	if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	l1lll1_l1_ = []
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠤࠥࠦ࡮ࡪ࠽ࠨࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠪࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠩࠤࡶ࡬ࡪࡧࡤࡦࡴࠥࢀࠬࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࠮ࠨࠢࠣ䀌"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0][0]
		items = re.findall(l11l1l_l1_ (u"ࠥࡨࡦࡺࡡ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡵࡨࡶࡻ࡫ࡲࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ䀍"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䀎")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䀏")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡮ࡱࡧࡥࡱ࠳ࡣ࡭ࡱࡶࡩࠧ࠭䀐"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡠࡡࡢࡨࡱࡥࡧࡥࡴ࡬ࡺࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䀑"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䀒")+title+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䀓")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䀔"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䀕"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭䀖"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ䀗"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ䀘"),l11l1l_l1_ (u"ࠨ࠭ࠪ䀙"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ䀚")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ䀛"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧፈ")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨፉ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
headers = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧፊ"):l11l1l_l1_ (u"ࠫࠬፋ")}
l1l111_l1_ = [l11l1l_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫፌ"),l11l1l_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧፍ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l1lllll_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l11111111_l1_(url)
	elif mode==375: results = l1llllll11_l1_(url)
	elif mode==376: results = l1llllll1l_l1_(0,url)
	elif mode==377: results = l1llllll1l_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫፎ"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩፏ"),l11l1l_l1_ (u"ࠩࠪፐ"),l11l1l_l1_ (u"ࠪࠫፑ"),l11l1l_l1_ (u"ࠫࠬፒ"),l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ፓ"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ፔ"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧፕ"),l11l1l_l1_ (u"ࠨࠩፖ"),379,l11l1l_l1_ (u"ࠩࠪፗ"),l11l1l_l1_ (u"ࠪࠫፘ"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨፙ"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪፚ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭፛"),l11l1l_l1_ (u"ࠧࠨ፜"),9999)
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ፝"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ፞"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ፟"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭፠")+l1111l_l1_+title,l1llll1_l1_,371)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፡"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ።")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่้๏ุษࠨ፣"),l11l11_l1_,375)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፤"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፥")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้ษอะอࠪ፦"),l11l11_l1_,376)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፧"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፨")+l1111l_l1_+l11l1l_l1_ (u"๊࠭ีษ๊ำࠥอไร่ࠪ፩"),l11l11_l1_,377)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፪"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፫")+l1111l_l1_+l11l1l_l1_ (u"ࠩๅหห๋ษࠡษ็้๊ัไ๋่ࠪ፬"),l11l11_l1_,374)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ፭"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ፮"),l11l1l_l1_ (u"ࠬ࠭፯"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡵࡱࡳ࠱ࡲ࡫࡮ࡶࠩ፰"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭፱"),block,re.DOTALL)
		for l1llll1_l1_,title in items[7:]:
			title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ፲"))
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፳"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፴")+l1111l_l1_+title,l1llll1_l1_,371)
		for l1llll1_l1_,title in items[0:7]:
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭፵"))
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፶"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ፷")+l1111l_l1_+title,l1llll1_l1_,371)
	return
def l11111111_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠧࠨ፸")):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ፹"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ፺"),l11l1l_l1_ (u"ࠪࠫ፻"),l11l1l_l1_ (u"ࠫࠬ፼"),l11l1l_l1_ (u"ࠬ࠭፽"),l11l1l_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡇࡃࡕࡑࡕࡗࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭፾"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡖࡤ࡫ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ፿"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᎀ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᎁ") in l1llll1_l1_: continue
			else: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎂ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᎃ")+l1111l_l1_+title,l1llll1_l1_,371)
	return
def l1llllll11_l1_(l1l1l111_l1_=l11l1l_l1_ (u"ࠬ࠭ᎄ")):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᎅ"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨᎆ"),l11l1l_l1_ (u"ࠨࠩᎇ"),l11l1l_l1_ (u"ࠩࠪᎈ"),l11l1l_l1_ (u"ࠪࠫᎉ"),l11l1l_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡊࡊࡇࡔࡖࡔࡈࡈ࠲࠷ࡳࡵࠩᎊ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠧᎋ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫᎌ"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᎍ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᎎ")+l1111l_l1_+title,l1llll1_l1_,372,l1ll1l_l1_)
	return
def l1llllll1l_l1_(id,l1l1l111_l1_=l11l1l_l1_ (u"ࠩࠪᎏ")):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ᎐"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ᎑"),l11l1l_l1_ (u"ࠬ࠭᎒"),l11l1l_l1_ (u"࠭ࠧ᎓"),l11l1l_l1_ (u"ࠧࠨ᎔"),l11l1l_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡘࡃࡗࡇࡍࡏࡎࡈࡐࡒ࡛࠲࠷ࡳࡵࠩ᎕"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨ᎖"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[id]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭᎗"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if not any(value in title for value in l1l111_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᎘"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᎙")+l1111l_l1_+title,l1llll1_l1_,372,l1ll1l_l1_)
	return
def l1lllll_l1_(url,l11ll1ll1_l1_=l11l1l_l1_ (u"࠭ࠧ᎚")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ᎛"),l11l1l_l1_ (u"ࠨࠩ᎜"),l11ll1ll1_l1_,url)
	#LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ᎝"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ᎞"),url,l11l1l_l1_ (u"ࠫࠬ᎟"),l11l1l_l1_ (u"ࠬ࠭Ꭰ"),l11l1l_l1_ (u"࠭ࠧᎡ"),l11l1l_l1_ (u"ࠧࠨᎢ"),l11l1l_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᎣ"))
	html = response.content
	if l11l1l_l1_ (u"ࠩࡹ࡭ࡩࡶࡡࡨࡧࡢࠫᎤ") in url:
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡆࡲࡢࡶ࡯࠰࠲࠯ࡅࠩࠣࠩᎥ"),html,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_[0]
			l1lllll_l1_(l1llll1_l1_)
			return
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࠥࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠭Ꭶ"),html,re.DOTALL)
	if l11ll1ll1_l1_==l11l1l_l1_ (u"ࠬ࠭Ꭷ") and l1l11ll_l1_ and l1l11ll_l1_[0].count(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࠫᎨ"))>1:
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᎩ"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠨᎪ"),url,371,l11l1l_l1_ (u"ࠩࠪᎫ"),l11l1l_l1_ (u"ࠪࠫᎬ"),l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡶࠫᎭ"))
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᎮ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨᎯ")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩᎰ"))
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎱ"),l1111l_l1_+title,l1llll1_l1_,371)
	else:
		l11l_l1_ = []
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫᎲ"),html,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠼ࠧ࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭Ꮃ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭Ꮄ"),block,re.DOTALL)
			l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵ࠤࡂ࡛ࠦ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸࡷࡿ࠺ࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࡬ࡲࡹ࠮ࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫฬ๊อๅไฬࠤ࠰࠮࡜ࡥ࠭ࠬࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠ࠭ࠏࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࠲࠷ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵࠲ࡦࡶࡰࡦࡰࡧࠬ࠭ࡲࡩ࡯࡭࠯࡭ࡲ࡭ࠬࡵ࡫ࡷࡰࡪ࠲ࡣࡰࡷࡱࡸ࠮࠯ࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠵࠰ࠥࡸࡥࡷࡧࡵࡷࡪࡃࡆࡢ࡮ࡶࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠹࡝ࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠤࠥࠦᎵ")
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_[:10]+l1ll1l_l1_[10:].replace(l11l1l_l1_ (u"࠭࠯࠰ࠩᎶ"),l11l1l_l1_ (u"ࠧ࠰ࠩᎷ")).replace(l11l1l_l1_ (u"ࠨࠢࠪᎸ"),l11l1l_l1_ (u"ࠩࠨ࠶࠵࠭Ꮉ"))
				#LOG_THIS(l11l1l_l1_ (u"ࠪࠫᎺ"),l1ll1l_l1_)
				l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
				title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭Ꮋ"))
				if l11l1l_l1_ (u"ࠬ࠵ࡡ࡭ࡡࠪᎼ") in l1llll1_l1_:
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮍ"),l1111l_l1_+title,l1llll1_l1_,371,l1ll1l_l1_)
				elif l11l1l_l1_ (u"ࠧศๆะ่็ฯࠧᎾ") in title and (l11l1l_l1_ (u"ࠨ࠱ࡆࡥࡹ࠳ࠧᎿ") in url or l11l1l_l1_ (u"ࠩ࠲ࡗࡪࡧࡲࡤࡪ࠲ࠫᏀ") in url):
					l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠰ࠤ࠰อไฮๆๅอࠥ࠱࡜ࡥ࠭ࠪᏁ"),title,re.DOTALL)
					if l1ll1l1_l1_: title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩᏂ")+l1ll1l1_l1_[0]
					if title not in l11l_l1_:
						l11l_l1_.append(title)
						addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏃ"),l1111l_l1_+title,l1llll1_l1_,371,l1ll1l_l1_)
				else: addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᏄ"),l1111l_l1_+title,l1llll1_l1_,372,l1ll1l_l1_)
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᏅ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏆ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
				title = l11l1l_l1_ (u"ุࠩๅาฯࠠࠨᏇ")+unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏈ"),l1111l_l1_+title,l1llll1_l1_,371,l11l1l_l1_ (u"ࠫࠬᏉ"),l11l1l_l1_ (u"ࠬ࠭Ꮚ"),l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡸ࠭Ꮛ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫᏌ"),url,l11l1l_l1_ (u"ࠨࠩᏍ"),l11l1l_l1_ (u"ࠩࠪᏎ"),l11l1l_l1_ (u"ࠪࠫᏏ"),l11l1l_l1_ (u"ࠫࠬᏐ"),l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ꮡ"))
	html = response.content
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡬ࡢࡤࡨࡰ࠲ࡹࡵࡤࡥࡨࡷࡸࠦ࡭ࡳࡩ࠰ࡦࡹࡳ࠭࠶ࠢࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏒ"),html,re.DOTALL)
	if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	l111lll_l1_ = l11l1l_l1_ (u"ࠧࠨᏓ")
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡶࠥࡻࡲ࡭ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᏔ"),html,re.DOTALL)
	if l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_[0]
	else: l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡰࡢࡩࡨࡣࠬᏕ"),l11l1l_l1_ (u"ࠪ࠳ࡕࡲࡡࡺ࠱ࠪᏖ"))
	if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᏗ") not in l111ll1_l1_: l111ll1_l1_ = l11l11_l1_+l111ll1_l1_
	l111ll1_l1_ = l111ll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠳ࠧᏘ"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᏙ"),l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨᏚ"),l11l1l_l1_ (u"ࠨࠩᏛ"),l11l1l_l1_ (u"ࠩࠪᏜ"),l11l1l_l1_ (u"ࠪࠫᏝ"),l11l1l_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᏞ"))
	l11ll11l_l1_ = response.content
	l111lll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᏟ"),l11ll11l_l1_,re.DOTALL)
	if l111lll_l1_:
		l111lll_l1_ = l111lll_l1_[-1]
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫᏠ") not in l111lll_l1_: l111lll_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭Ꮱ")+l111lll_l1_
		if l11l1l_l1_ (u"ࠨ࠱ࡓࡐࡆ࡟࠯ࠨᏢ") not in l111ll1_l1_:
			if l11l1l_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠯࡯࡬ࡲ࠳ࡰࡳࠨᏣ") in l111lll_l1_:
				l1lllllll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡲࡸࡦࡱ࡯ࡳࡩࡧࡵ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᏤ"),l11ll11l_l1_,re.DOTALL)
				if l1lllllll1_l1_:
					l1lllll1ll_l1_, l1llllllll_l1_ = l1lllllll1_l1_[0]
					l111lll_l1_ = SERVER(l111lll_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨᏥ"))+l11l1l_l1_ (u"ࠬ࠵ࡶ࠳࠱ࠪᏦ")+l1lllll1ll_l1_+l11l1l_l1_ (u"࠭࠯ࡤࡱࡱࡪ࡮࡭࠯ࠨᏧ")+l1llllllll_l1_+l11l1l_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭Ꮸ")
		import ll_l1_
		ll_l1_.l11_l1_([l111lll_l1_],l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᏩ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪᏪ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫᏫ"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭Ꮼ"),l11l1l_l1_ (u"ࠬ࠱ࠧᏭ"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡔࡧࡤࡶࡨ࡮࠯ࠨᏮ")+search
	l1lllll_l1_(url)
	return
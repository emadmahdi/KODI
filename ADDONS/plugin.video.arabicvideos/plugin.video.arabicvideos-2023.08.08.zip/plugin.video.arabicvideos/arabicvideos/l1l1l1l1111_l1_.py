# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫと")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩど")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭な"),l11l1l_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭に"),l11l1l_l1_ (u"࠭วๅลๅืฬ๋ࠧぬ")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l1lllll_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l1111_l1_(url,text)
	elif mode==674: results = l11lll_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫね"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩの"),l11l1l_l1_ (u"ࠩࠪは"),l11l1l_l1_ (u"ࠪࠫば"),l11l1l_l1_ (u"ࠫࠬぱ"),l11l1l_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩひ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭び"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧぴ"),l11l1l_l1_ (u"ࠨࠩふ"),679,l11l1l_l1_ (u"ࠩࠪぶ"),l11l1l_l1_ (u"ࠪࠫぷ"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨへ"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪべ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ぺ"),l11l1l_l1_ (u"ࠧࠨほ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨぼ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫぽ")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫま"),l11l11_l1_,671,l11l1l_l1_ (u"ࠫࠬみ"),l11l1l_l1_ (u"ࠬ࠭む"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨめ"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧも"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪゃ")+l1111l_l1_+l11l1l_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨや"),l11l11_l1_,671,l11l1l_l1_ (u"ࠪࠫゅ"),l11l1l_l1_ (u"ࠫࠬゆ"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫょ"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭よ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩら")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧり"),l11l11_l1_,671,l11l1l_l1_ (u"ࠩࠪる"),l11l1l_l1_ (u"ࠪࠫれ"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨろ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬゎ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨわ")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫゐ"),l11l11_l1_,671,l11l1l_l1_ (u"ࠨࠩゑ"),l11l1l_l1_ (u"ࠩࠪを"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬん"))
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩゔ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬゕ"),l11l1l_l1_ (u"࠭ࠧゖ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ゗"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ゘"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if title==l11l1l_l1_ (u"ࠩส่ศ่ำศ็゙ࠪ"): mode = 675
		else: mode = 674
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ゚ࠪ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭゛")+l1111l_l1_+title,l1llll1_l1_,mode)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ゜"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ゝ"),l11l1l_l1_ (u"ࠧࠨゞ"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬゟ"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ゠"),html,re.DOTALL)
	#for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠪࠫァ"))
	#items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩア"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬィ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨイ")+l1111l_l1_+title,l1llll1_l1_,674)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬゥ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨウ"),l11l1l_l1_ (u"ࠩࠪェ"),9999)
	items = CATEGORIES(l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࡦࡷࡵࡷࡴࡧ࠱࡬ࡹࡳ࡬ࠨエ"))
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫォ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧオ")+l1111l_l1_+title,l1llll1_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1ll11l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫカ"),l11l1l_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩガ"),l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬキ"))
	if l1ll11l1ll_l1_: return l1ll11l1ll_l1_
	#DIALOG_OK()
	l1ll11l1ll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ギ"),url,l11l1l_l1_ (u"ࠪࠫク"),l11l1l_l1_ (u"ࠫࠬグ"),l11l1l_l1_ (u"ࠬ࠭ケ"),l11l1l_l1_ (u"࠭ࠧゲ"),l11l1l_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪコ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱࡭࡫ࡡࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࡁࠫゴ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1ll11l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭サ"),block,re.DOTALL)
		if l1ll11l1ll_l1_: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬザ"),l11l1l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨシ"),l1ll11l1ll_l1_,l1llll1l_l1_)
	return l1ll11l1ll_l1_
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩジ"),url,l11l1l_l1_ (u"࠭ࠧス"),l11l1l_l1_ (u"ࠧࠨズ"),l11l1l_l1_ (u"ࠨࠩセ"),l11l1l_l1_ (u"ࠩࠪゼ"),l11l1l_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪソ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨゾ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭タ"),l11l1l_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬダ"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫチ"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠨࠩヂ"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧッ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨツ"),l11l1l_l1_ (u"ࠫࠬヅ"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪテ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"࠭࠺ࠡࠩデ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧト"),l1111l_l1_+title,l1llll1_l1_,671)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬド"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫナ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨニ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫヌ"),l11l1l_l1_ (u"ࠬ࠭ネ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ノ"),l1111l_l1_+title,l1llll1_l1_,671)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠧࠨハ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩバ"),l11l1l_l1_ (u"ࠩࠪパ"),request,url)
	if request==l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨヒ"):
		url,search = url.split(l11l1l_l1_ (u"ࠫࡄ࠭ビ"),1)
		data = l11l1l_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫピ")+search
		headers = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬフ"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧブ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭プ"),url,data,headers,l11l1l_l1_ (u"ࠩࠪヘ"),l11l1l_l1_ (u"ࠪࠫベ"),l11l1l_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪペ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩホ"),url,l11l1l_l1_ (u"࠭ࠧボ"),l11l1l_l1_ (u"ࠧࠨポ"),l11l1l_l1_ (u"ࠨࠩマ"),l11l1l_l1_ (u"ࠩࠪミ"),l11l1l_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩム"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠫࠬメ"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩモ"))
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫャ"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩヤ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠨࠩュ"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫユ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫョ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪヨ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬラ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪリ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧル"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪレ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫロ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬヮ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠫࠬワ"),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヰ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧヱ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧヲ"),l11l1l_l1_ (u"ࠨใํ่๊࠭ン"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨヴ"),l11l1l_l1_ (u"ࠪ็้๐ศࠨヵ"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪヶ"),l11l1l_l1_ (u"ࠬํฯศใࠪヷ"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭ヸ"),l11l1l_l1_ (u"ฺࠧำูࠫヹ"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨヺ"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ・"),l11l1l_l1_ (u"ุ้ࠪือ๋หࠪー"),l11l1l_l1_ (u"ࠫๆ๊ๅࠨヽ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧヾ"))
		#if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫヿ") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ㄀")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ㄁"))
		#if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㄂") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ㄃")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭㄄"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧㄅ"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩㄆ"),title,re.DOTALL)
		#addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㄇ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㄈ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㄉ"):
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄊ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪㄋ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄌ"),l1111l_l1_+title,l1llll1_l1_,673,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫㄍ") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄎ"),l1111l_l1_+title,l1llll1_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄏ"),l1111l_l1_+title,l1llll1_l1_,673,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄐ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨㄑ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭ㄒ"): continue
			if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪㄓ") not in l1llll1_l1_:
				l111ll1_l1_ = url.rsplit(l11l1l_l1_ (u"࠭࠯ࠨㄔ"),1)[0]
				l1llll1_l1_ = l111ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩㄕ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪㄖ"))
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄗ"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩㄘ")+title,l1llll1_l1_,671,l11l1l_l1_ (u"ࠫࠬㄙ"),l11l1l_l1_ (u"ࠬ࠭ㄚ"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧㄛ"),l11l1l_l1_ (u"ࠧࠨㄜ"),l1l11_l1_,url)
	addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㄝ"),l1111l_l1_+l11l1l_l1_ (u"ࠩอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩㄞ"),url,672)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㄟ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㄠ"),l11l1l_l1_ (u"ࠬ࠭ㄡ"),9999)
	l1ll11l1ll_l1_ = CATEGORIES(l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡢࡳࡱࡺࡷࡪ࠴ࡨࡵ࡯࡯ࠫㄢ"))
	l1l1l11llll_l1_,l1l1l11lll1_l1_,l1l1l1l1l1l_l1_ = zip(*l1ll11l1ll_l1_)
	l1l1l1l111l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫㄣ"),url,l11l1l_l1_ (u"ࠨࠩㄤ"),l11l1l_l1_ (u"ࠩࠪㄥ"),l11l1l_l1_ (u"ࠪࠫㄦ"),l11l1l_l1_ (u"ࠫࠬㄧ"),l11l1l_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ㄨ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠪㄩ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡻࡅࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽ࠩㄪ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1l1l11llll_l1_:
				item = (l1llll1_l1_,title)
				l1l1l1l111l_l1_.append(item)
		if len(l1l1l1l111l_l1_)==1:
			l1llll1_l1_,title = l1l1l1l111l_l1_[0]
			l1lllll_l1_(l1llll1_l1_,l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㄫ"))
			return
		else:
			for l1llll1_l1_,title in l1l1l1l111l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄬ"),l1111l_l1_+title,l1llll1_l1_,671,l11l1l_l1_ (u"ࠪࠫㄭ"),l11l1l_l1_ (u"ࠫࠬㄮ"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫㄯ"))
	if not l1l1l1l111l_l1_: l1lllll_l1_(url,l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㄰"))
	return
#https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l11ll11111_l1_.l1ll1l1lll_l1_?l1l1l1l1l11_l1_=l1l1l1l11ll_l1_
#https://www.l1l1l1l11l1_l1_.com/l11l1l111_l1_/l1l1111ll_l1_.l1ll1l1lll_l1_?l1l1l1l1l11_l1_=l1l1l1l11ll_l1_
def PLAY(url):
	l1lll1l1_l1_ = []
	#url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩ࠱ไ๎้๋࠭ไำอ์๋࠳ศศำห๎࠲็๊࠮็฽ห๊ืษ࠮็อ่ศ๊ฦส࠯่ำอࡥࡤ࠺࠹࠸ࡧࡧ࠽࠵࠴࠰࡫ࡸࡲࡲࠧㄱ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬㄲ"),url,l11l1l_l1_ (u"ࠩࠪㄳ"),l11l1l_l1_ (u"ࠪࠫㄴ"),l11l1l_l1_ (u"ࠫࠬㄵ"),l11l1l_l1_ (u"ࠬ࠭ㄶ"),l11l1l_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪㄷ"))
	html = response.content
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡦ࡭ࡣࡶ࡬ࡵࡲࡡࡺࡧࡵࠫㄸ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫㄹ"),block,re.DOTALL)
		for l1llll1_l1_,l111ll1l_l1_ in l1l1_l1_:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࡢࡣࠬㄺ")+l111ll1l_l1_
			l1lll1l1_l1_.append(l1llll1_l1_)
	# l1l1111ll_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㄻ"),html,re.DOTALL)
	if not l1l1_l1_: l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠦ࡫࡯࡬ࡦ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦㄼ"),html,re.DOTALL)
	if l1l1_l1_:
		l1llll1_l1_ = l1l1_l1_[0]
		if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪㄽ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬㄾ")+l1llll1_l1_
		l1lll1l1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨㄿ"))
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ㅀ"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㅁ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠪࠫㅂ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠫࠬㅃ"): return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧㅄ"),l11l1l_l1_ (u"࠭ࠫࠨㅅ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧㅆ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨㅇ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭ㅈ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨㅉ"))
	return
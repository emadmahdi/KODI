# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧᏯ")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧᏰ")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᏱ"),l11l1l_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫᏲ"),l11l1l_l1_ (u"ࠫฬ๊วใีส้ࠬᏳ"),l11l1l_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩᏴ")]
def MAIN(mode,url,text):
	if   mode==650: results = MENU()
	elif mode==651: results = l1lllll_l1_(url,text)
	elif mode==652: results = PLAY(url)
	elif mode==653: results = l1111_l1_(url,text)
	elif mode==654: results = l11lll_l1_(url)
	elif mode==659: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᏵ"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ᏶"),l11l1l_l1_ (u"ࠨࠩ᏷"),l11l1l_l1_ (u"ࠩࠪᏸ"),l11l1l_l1_ (u"ࠪࠫᏹ"),l11l1l_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᏺ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏻ"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᏼ"),l11l1l_l1_ (u"ࠧࠨᏽ"),659,l11l1l_l1_ (u"ࠨࠩ᏾"),l11l1l_l1_ (u"ࠩࠪ᏿"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᐀"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᐁ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᐂ"),l11l1l_l1_ (u"࠭ࠧᐃ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᐅ")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊๋๊ำหࠪᐆ"),l11l11_l1_,651,l11l1l_l1_ (u"ࠪࠫᐇ"),l11l1l_l1_ (u"ࠫࠬᐈ"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᐉ"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐊ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐋ")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᐌ"),l11l11_l1_,651,l11l1l_l1_ (u"ࠩࠪᐍ"),l11l1l_l1_ (u"ࠪࠫᐎ"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᐏ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐐ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᐑ")+l1111l_l1_+l11l1l_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᐒ"),l11l11_l1_,651,l11l1l_l1_ (u"ࠨࠩᐓ"),l11l1l_l1_ (u"ࠩࠪᐔ"),l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᐕ"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐖ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᐗ")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᐘ"),l11l11_l1_,651,l11l1l_l1_ (u"ࠧࠨᐙ"),l11l1l_l1_ (u"ࠨࠩᐚ"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᐛ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐜ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐝ"),l11l1l_l1_ (u"ࠬ࠭ᐞ"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐟ"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᐠ"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐡ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᐢ")+l1111l_l1_+title,l1llll1_l1_,654)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐣ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐤ"),l11l1l_l1_ (u"ࠬ࠭ᐥ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᐦ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᐧ"),html,re.DOTALL)
	#for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠨࠩᐨ"))
	#block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᐩ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		title = title.replace(l11l1l_l1_ (u"ࠪࡀࡧࡄࠧᐪ"),l11l1l_l1_ (u"ࠫࠬᐫ")).strip(l11l1l_l1_ (u"ࠬࠦࠧᐬ"))
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐭ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐮ")+l1111l_l1_+title,l1llll1_l1_,654)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᐯ"),url,l11l1l_l1_ (u"ࠩࠪᐰ"),l11l1l_l1_ (u"ࠪࠫᐱ"),l11l1l_l1_ (u"ࠫࠬᐲ"),l11l1l_l1_ (u"ࠬ࠭ᐳ"),l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᐴ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐵ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᐶ"),l11l1l_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᐷ"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᐸ"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠫࠬᐹ"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᐺ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐻ"),l11l1l_l1_ (u"ࠧࠨᐼ"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᐽ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࠬᐾ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐿ"),l1111l_l1_+title,l1llll1_l1_,651)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑀ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᑁ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᑂ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑃ"),l11l1l_l1_ (u"ࠨࠩᑄ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑅ"),l1111l_l1_+title,l1llll1_l1_,651)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠪࠫᑆ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᑇ"),l11l1l_l1_ (u"ࠬ࠭ᑈ"),request,url)
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᑉ"):
		url,search = url.split(l11l1l_l1_ (u"ࠧࡀࠩᑊ"),1)
		data = l11l1l_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᑋ")+search
		headers = {l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᑌ"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᑍ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩᑎ"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭ᑏ"),l11l1l_l1_ (u"࠭ࠧᑐ"),l11l1l_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᑑ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᑒ"),url,l11l1l_l1_ (u"ࠩࠪᑓ"),l11l1l_l1_ (u"ࠪࠫᑔ"),l11l1l_l1_ (u"ࠫࠬᑕ"),l11l1l_l1_ (u"ࠬ࠭ᑖ"),l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᑗ"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠧࠨᑘ"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬᑙ"))
	if request==l11l1l_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᑚ"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᑛ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠫࠬᑜ"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᑝ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑞ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᑟ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑠ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᑡ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᑢ"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᑣ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᑤ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᑥ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠧࠨᑦ"),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᑧ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᑨ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪᑩ"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩᑪ"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫᑫ"),l11l1l_l1_ (u"࠭ใๅ์หࠫᑬ"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭ᑭ"),l11l1l_l1_ (u"ࠨ้าหๆ࠭ᑮ"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩᑯ"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧᑰ"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫᑱ"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫᑲ"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭ᑳ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩᑴ"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᑵ") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫᑶ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬᑷ"))
		#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᑸ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧᑹ")+l1ll1l_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨᑺ"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩᑻ"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᑼ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᑽ"),l1111l_l1_+title,l1llll1_l1_,652,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᑾ"):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᑿ"),l1111l_l1_+title,l1llll1_l1_,652,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᒀ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒁ"),l1111l_l1_+title,l1llll1_l1_,653,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᒂ") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒃ"),l1111l_l1_+title,l1llll1_l1_,651,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒄ"),l1111l_l1_+title,l1llll1_l1_,653,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᒅ"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᒆ")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒇ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᒈ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠧࠤࠩᒉ"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪᒊ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫᒋ"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒌ"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪᒍ")+title,l1llll1_l1_,651)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᒎ"),l11l1l_l1_ (u"࠭ࠧᒏ"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫᒐ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᒑ"),url,l11l1l_l1_ (u"ࠩࠪᒒ"),l11l1l_l1_ (u"ࠪࠫᒓ"),l11l1l_l1_ (u"ࠫࠬᒔ"),l11l1l_l1_ (u"ࠬ࠭ᒕ"),l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᒖ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᒗ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᒘ"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪᒙ")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫᒚ"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᒛ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠬࠩࠧᒜ"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒝ"),l1111l_l1_+title,url,653,l1ll1l_l1_,l11l1l_l1_ (u"ࠧࠨᒞ"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᒟ"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪᒠ"),str(l1l11ll_l1_))
	block = l1l11ll_l1_[0]
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᒡ")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᒢ"),block,re.DOTALL)
	if not l1l1111_l1_: l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᒣ")+l1l11_l1_+l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᒤ"),block,re.DOTALL)
	if not l1l1111_l1_: l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᒥ")+l1l11_l1_+l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒦ"),block,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᒧ"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᒨ"),l11l1l_l1_ (u"ࠫࠬᒩ"),l11l1l_l1_ (u"ࠬ࠭ᒪ"),l11l1l_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᒫ"))
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᒬ"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒭ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠱࠳ࠬᒮ"))
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬᒯ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᒰ"))
			title = title.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᒱ"),l11l1l_l1_ (u"࠭ࠠࠨᒲ"))
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᒳ"),l1111l_l1_+title,l1llll1_l1_,652,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᒴ"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᒵ") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬᒶ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᒷ"))
		#		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᒸ"),l1111l_l1_+title,l1llll1_l1_,652,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111lll_l1_,l1lll1l1_l1_ = [],[],[]
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᒹ"),l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪᒺ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᒻ"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪᒼ"),l11l1l_l1_ (u"ࠪࠫᒽ"),l11l1l_l1_ (u"ࠫࠬᒾ"),l11l1l_l1_ (u"ࠬ࠭ᒿ"),l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᓀ"))
	html = response.content
	# l1l1111ll_l1_ l1llll1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᓁ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᓂ"),block,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll1_l1_[0]
			l1l111lll_l1_.append(l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᓃ"))
			l1lll1_l1_.append(l1llll1_l1_)
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᓄ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠤᓅ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧᓆ"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᓇ")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᓈ"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ࠲ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨࠫࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲ࠲࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡃࡔࡖࡘࡊࡐ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡵࡳ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍࠎࠏ࡮ࡢ࡯ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧᓉ")
	l11111_l1_ = zip(l1lll1_l1_,l1l111lll_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll1l1_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᓊ"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᓋ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬᓌ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭ᓍ"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨᓎ"),l11l1l_l1_ (u"ࠧࠬࠩᓏ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩᓐ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᓑ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧᓒ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᓓ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ៺")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡅࡆࡆࡤ࠭៻")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ៼"),l11l1l_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ៽"),l11l1l_l1_ (u"ࠪฮุา๊ๅࠩ៾"),l11l1l_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩ៿")]
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l1lllll_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l1111_l1_(url,text)
	elif mode==634: results = l11lll_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ᠀"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ᠁"),l11l1l_l1_ (u"ࠧࠨ᠂"),l11l1l_l1_ (u"ࠨࠩ᠃"),l11l1l_l1_ (u"ࠩࠪ᠄"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ᠅"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠆"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ᠇"),l11l1l_l1_ (u"࠭ࠧ᠈"),639,l11l1l_l1_ (u"ࠧࠨ᠉"),l11l1l_l1_ (u"ࠨࠩ᠊"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᠋"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᠌"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᠍"),l11l1l_l1_ (u"ࠬ࠭᠎"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠏"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᠐")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็้๊๐าสࠩ᠑"),l11l11_l1_,631,l11l1l_l1_ (u"ࠩࠪ᠒"),l11l1l_l1_ (u"ࠪࠫ᠓"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭᠔"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᠕"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᠖")+l1111l_l1_+l11l1l_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭᠗"),l11l11_l1_,631,l11l1l_l1_ (u"ࠨࠩ᠘"),l11l1l_l1_ (u"ࠩࠪ᠙"),l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ᠚"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠛"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᠜")+l1111l_l1_+l11l1l_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬ᠝"),l11l11_l1_,631,l11l1l_l1_ (u"ࠧࠨ᠞"),l11l1l_l1_ (u"ࠨࠩ᠟"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᠠ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠡ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᠢ")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠩᠣ"),l11l11_l1_,631,l11l1l_l1_ (u"࠭ࠧᠤ"),l11l1l_l1_ (u"ࠧࠨᠥ"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᠦ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᠧ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᠨ"),l11l1l_l1_ (u"ࠫࠬᠩ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡹࡵࡥࡵࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᠪ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᠫ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if title==l11l1l_l1_ (u"ࠧฤฯาฯࠥอไฮๆๅหฯ࠭ᠬ"): mode,request = 631,l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧᠭ")
		else: mode,request = 634,l11l1l_l1_ (u"ࠩࠪᠮ")
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠯ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᠰ")+l1111l_l1_+title,l1llll1_l1_,mode,l11l1l_l1_ (u"ࠬ࠭ᠱ"),l11l1l_l1_ (u"࠭ࠧᠲ"),request)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᠳ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᠴ"),l11l1l_l1_ (u"ࠩࠪᠵ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧᠶ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤᠷ"),html,re.DOTALL)
	for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠬ࠭ᠸ"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᠹ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᠺ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᠻ")+l1111l_l1_+title,l1llll1_l1_,634)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ᠼ"),url,l11l1l_l1_ (u"ࠪࠫᠽ"),l11l1l_l1_ (u"ࠫࠬᠾ"),l11l1l_l1_ (u"ࠬ࠭ᠿ"),l11l1l_l1_ (u"࠭ࠧᡀ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᡁ"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᡂ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪᡃ"),l11l1l_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩᡄ"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᡅ"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠬ࠭ᡆ"),block)]
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᡇ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᡈ"),l11l1l_l1_ (u"ࠨࠩᡉ"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᡊ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠪ࠾ࠥ࠭ᡋ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡌ"),l1111l_l1_+title,l1llll1_l1_,631)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᡍ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᡎ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᡏ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᡐ"),l11l1l_l1_ (u"ࠩࠪᡑ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᡒ"),l1111l_l1_+title,l1llll1_l1_,631)
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸ࠹ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡲࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲ࠲࡮ࡥࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸ࠹࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠵࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡰࡪࡴࠨࡪࡶࡨࡱࡸ࠯࠼࠴࠲࠽ࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭࡬ࡪࡰ࡮ࠫ࠱࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬࠨࠩ࠯࠽࠾࠿࠹ࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠺࠸࠷ࠩࠋࠋ࡬ࡪࠥࡴ࡯ࡵࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠱ࠡࡣࡱࡨࠥࡴ࡯ࡵࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠲ࠡࡣࡱࡨࠥࡴ࡯ࡵࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠳࠻ࠢࡗࡍ࡙ࡒࡅࡔࠪࡸࡶࡱ࠯ࠊࠊࠤࠥࠦᡓ")
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠬ࠭ᡔ")):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧᡕ"),l11l1l_l1_ (u"ࠧࠨᡖ"),request,url)
	if request==l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᡗ"):
		url,search = url.split(l11l1l_l1_ (u"ࠩࡂࠫᡘ"),1)
		data = l11l1l_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩᡙ")+search
		headers = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᡚ"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᡛ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫᡜ"),url,data,headers,l11l1l_l1_ (u"ࠧࠨᡝ"),l11l1l_l1_ (u"ࠨࠩᡞ"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᡟ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᡠ"),url,l11l1l_l1_ (u"ࠫࠬᡡ"),l11l1l_l1_ (u"ࠬ࠭ᡢ"),l11l1l_l1_ (u"࠭ࠧᡣ"),l11l1l_l1_ (u"ࠧࠨᡤ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᡥ"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠩࠪᡦ"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧᡧ"))
	if request==l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᡨ"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᡩ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l11l1l_l1_ (u"࠭ࠧᡪ")))
	elif request==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᡫ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡳࡱࡸࡷࡪࡲ࡟ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᡬ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠩࠪࠫࠧࡶ࡯ࡴࡶࡅࡰࡴࡩ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠬ࠭ࠧᡭ"),block,re.DOTALL)
	elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᡮ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᡯ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩᡰ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᡱ"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᡲ"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪᡳ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᡴ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l11l1l_l1_ (u"ࠪࠫᡵ")))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᡶ"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᡷ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"࠭ๅีษ๊ำฮ࠭ᡸ"),l11l1l_l1_ (u"ࠧโ์็้ࠬ᡹"),l11l1l_l1_ (u"ࠨษ฽๊๏ฯࠧ᡺"),l11l1l_l1_ (u"ࠩๆ่๏ฮࠧ᡻"),l11l1l_l1_ (u"ࠪห฾๊ว็ࠩ᡼"),l11l1l_l1_ (u"ࠫ์ีวโࠩ᡽"),l11l1l_l1_ (u"๋ࠬศศำสอࠬ᡾"),l11l1l_l1_ (u"ู࠭าุࠪ᡿"),l11l1l_l1_ (u"ࠧๆ้ิะฬ์ࠧᢀ"),l11l1l_l1_ (u"ࠨษ็ฬํ๋ࠧᢁ"),l11l1l_l1_ (u"่ࠩืึำ๊สࠩᢂ")]
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫᢃ"),l1llll1_l1_)
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠫ࠴࠭ᢄ"))
		#if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᢅ") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨᢆ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩᢇ"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᢈ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫᢉ")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬᢊ"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭ᢋ"))
		title = title.replace(l11l1l_l1_ (u"ࠬࠦำ๋็สࠤ่๊่ษࠩᢌ"),l11l1l_l1_ (u"࠭ࠧᢍ"))
		title = title.replace(l11l1l_l1_ (u"ࠧࠡษ๋๊๊ࠥว๋่ࠪᢎ"),l11l1l_l1_ (u"ࠨࠩᢏ"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬᢐ"),title,re.DOTALL)
		if l11l1l_l1_ (u"࡛ࠪ࡜ࡋࠧᢑ") in title: continue
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᢒ"),l1111l_l1_+title,l1llll1_l1_,632,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᢓ"):
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᢔ"),l1111l_l1_+title,l1llll1_l1_,632,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᢕ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢖ"),l1111l_l1_+title,l1llll1_l1_,633,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᢗ") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᢘ"),l1111l_l1_+title,l1llll1_l1_,631,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢙ"),l1111l_l1_+title,l1llll1_l1_,633,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᢚ"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᢛ")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᢜ"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᢝ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠩࠦࠫᢞ"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬᢟ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᢠ"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᢡ"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬᢢ")+title,l1llll1_l1_,631)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨᢣ"),l11l1l_l1_ (u"ࠨࠩᢤ"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ᢥ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᢦ"),url,l11l1l_l1_ (u"ࠫࠬᢧ"),l11l1l_l1_ (u"ࠬ࠭ᢨ"),l11l1l_l1_ (u"ᢩ࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨᢪ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ᢫"))
	html = response.content
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᢬"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠪࠫ᢭")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ᢮"),html,re.DOTALL)
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࠭ࠧࡰࡰࡦࡰ࡮ࡩ࡫࠾ࠤࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰࠳࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬ᢯"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"࠭ࠣࠨᢰ"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢱ"),l1111l_l1_+title,url,633,l1ll1l_l1_,l11l1l_l1_ (u"ࠨࠩᢲ"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࠧᢳ")+l1l11_l1_+l11l1l_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᢴ"),html,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᢵ"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᢶ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			#l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨᢷ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩᢸ"))
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪᢹ"))
			title = title.replace(l11l1l_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧᢺ"),l11l1l_l1_ (u"ࠪࠤࠬᢻ"))
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᢼ"),l1111l_l1_+title,l1llll1_l1_,632,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᢽ"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫᢾ") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩᢿ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪᣀ"))
		#		addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᣁ"),l1111l_l1_+title,l1llll1_l1_,632,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111lll_l1_,l1lll1l1_l1_ = [],[],[]
	# l11l1l111_l1_ l1l1_l1_
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᣂ"),l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧᣃ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩᣄ"),l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧᣅ"),l11l1l_l1_ (u"ࠧࠨᣆ"),l11l1l_l1_ (u"ࠨࠩᣇ"),l11l1l_l1_ (u"ࠩࠪᣈ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᣉ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᣊ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠢᣋ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᣌ")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᣍ"))
				l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᣎ"),l11l1l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪᣏ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᣐ"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬᣑ"),l11l1l_l1_ (u"ࠬ࠭ᣒ"),l11l1l_l1_ (u"࠭ࠧᣓ"),l11l1l_l1_ (u"ࠧࠨᣔ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᣕ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣖ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ᣗ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᣘ")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᣙ"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111lll_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll1l1_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᣚ"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᣛ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩᣜ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪᣝ"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬᣞ"),l11l1l_l1_ (u"ࠫ࠰࠭ᣟ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ᣠ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᣡ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫᣢ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᣣ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭嚟")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭嚠")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ嚡"),l11l1l_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ嚢"),l11l1l_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭嚣")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1lllll_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l1111_l1_(url,text)
	elif mode==644: results = l11lll_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ嚤"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭嚥"),l11l1l_l1_ (u"࠭ࠧ嚦"),l11l1l_l1_ (u"ࠧࠨ嚧"),l11l1l_l1_ (u"ࠨࠩ嚨"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ嚩"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚪"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ嚫"),l11l1l_l1_ (u"ࠬ࠭嚬"),649,l11l1l_l1_ (u"࠭ࠧ嚭"),l11l1l_l1_ (u"ࠧࠨ嚮"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嚯"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ嚰"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嚱"),l11l1l_l1_ (u"ࠫࠬ嚲"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚳"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ嚴")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่้๏ุษࠨ嚵"),l11l11_l1_,641,l11l1l_l1_ (u"ࠨࠩ嚶"),l11l1l_l1_ (u"ࠩࠪ嚷"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ嚸"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚹"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ嚺")+l1111l_l1_+l11l1l_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫ嚻"),l11l11_l1_,641,l11l1l_l1_ (u"ࠧࠨ嚼"),l11l1l_l1_ (u"ࠨࠩ嚽"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ嚾"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚿"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭囀")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ囁"),l11l11_l1_,641,l11l1l_l1_ (u"࠭ࠧ囂"),l11l1l_l1_ (u"ࠧࠨ囃"),l11l1l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ囄"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囅"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ囆")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ囇"),l11l11_l1_,641,l11l1l_l1_ (u"ࠬ࠭囈"),l11l1l_l1_ (u"࠭ࠧ囉"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ囊"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囋"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ囌"),l11l1l_l1_ (u"ࠪࠫ囍"),9999)
	#l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囎"),html,re.DOTALL)
	#block = l1l11ll_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭囏"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囐"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ囑")+l1111l_l1_+title,l1llll1_l1_,644)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囒"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ囓"),l11l1l_l1_ (u"ࠪࠫ囔"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ囕"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ囖"),html,re.DOTALL)
	for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"࠭ࠧ囗"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ囘"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囙"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ囚")+l1111l_l1_+title,l1llll1_l1_,644)
	return
def l11lll_l1_(url):
	l11111l1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ四"),url,l11l1l_l1_ (u"ࠫࠬ囜"),l11l1l_l1_ (u"ࠬ࠭囝"),l11l1l_l1_ (u"࠭ࠧ回"),l11l1l_l1_ (u"ࠧࠨ囟"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭因"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭囡"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ团"),l11l1l_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ団"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囤"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"࠭ࠧ囥"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ囦"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭囧"),l11l1l_l1_ (u"ࠩࠪ囨"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ囩"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠫ࠿ࠦࠧ囪")
			for l1llll1_l1_,title in l11111l1l_l1_:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ囫"),l1111l_l1_+title,l1llll1_l1_,641)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ囬"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ园"),block,re.DOTALL)
		if len(l1l1l11_l1_)<30:
			if l11111l1l_l1_: addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囮"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ囯"),l11l1l_l1_ (u"ࠪࠫ困"),9999)
			for l1llll1_l1_,title in l1l1l11_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囱"),l1111l_l1_+title,l1llll1_l1_,641)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠬ࠭囲")):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ図"),l11l1l_l1_ (u"ࠧࠨ围"),request,url)
	if request==l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭囵"):
		url,search = url.split(l11l1l_l1_ (u"ࠩࡂࠫ囶"),1)
		data = l11l1l_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ囷")+search
		headers = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ囸"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ囹")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ固"),url,data,headers,l11l1l_l1_ (u"ࠧࠨ囻"),l11l1l_l1_ (u"ࠨࠩ囼"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭国"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ图"),url,l11l1l_l1_ (u"ࠫࠬ囿"),l11l1l_l1_ (u"ࠬ࠭圀"),l11l1l_l1_ (u"࠭ࠧ圁"),l11l1l_l1_ (u"ࠧࠨ圂"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ圃"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠩࠪ圄"),[]
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ圅"))
	if request==l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ圆"):
		block = html
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ圇"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"࠭ࠧ圈"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ圉"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ圊"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ國"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ圌"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ圍"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圎"),html,re.DOTALL)
		if len(l1l11ll_l1_)>1: block = l1l11ll_l1_[1]
	elif request==l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ圏"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ圐"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ圑"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l11l1l_l1_ (u"ࠩࠪ園"),l1llll1_l1_,title))
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ圓"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭圔"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"๋ࠬิศ้าอࠬ圕"),l11l1l_l1_ (u"࠭แ๋ๆ่ࠫ圖"),l11l1l_l1_ (u"ࠧศ฼้๎ฮ࠭圗"),l11l1l_l1_ (u"ࠨๅ็๎อ࠭團"),l11l1l_l1_ (u"ࠩส฽้อๆࠨ圙"),l11l1l_l1_ (u"๋ࠪิอแࠨ圚"),l11l1l_l1_ (u"๊ࠫฮวาษฬࠫ圛"),l11l1l_l1_ (u"ࠬ฿ัืࠩ圜"),l11l1l_l1_ (u"࠭ๅ่ำฯห๋࠭圝"),l11l1l_l1_ (u"ࠧศๆห์๊࠭圞"),l11l1l_l1_ (u"ࠨ็ึีา๐ษࠨ土")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ圠"))
		#if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ圡") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴࠭圢")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ圣"))
		#if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ圤") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ圥")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ圦"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ圧"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭在"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ圩"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ圪"):
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ圫"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		elif l1ll1l1_l1_:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭圬") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圭"),l1111l_l1_+title,l1llll1_l1_,643,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ圮") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ圯"),l1111l_l1_+title,l1llll1_l1_,641,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ地"),l1111l_l1_+title,l1llll1_l1_,643,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ圱"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ圲")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ圳"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭圴"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠩࠦࠫ圵"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ圶")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭圷"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圸"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ圹")+title,l1llll1_l1_,641)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ场"),l11l1l_l1_ (u"ࠨࠩ圻"),l1l11_l1_,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭圼"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ圽"),url,l11l1l_l1_ (u"ࠫࠬ圾"),l11l1l_l1_ (u"ࠬ࠭圿"),l11l1l_l1_ (u"࠭ࠧ址"),l11l1l_l1_ (u"ࠧࠨ坁"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ坂"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ坃"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ坄"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠫࠬ坅")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ坆"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"࠭ࠣࠨ均"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坈"),l1111l_l1_+title,url,643,l1ll1l_l1_,l11l1l_l1_ (u"ࠨࠩ坉"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ坊")+l1l11_l1_+l11l1l_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ坋"),html,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭坌"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l1l11_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		#if not items: items = re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ坍"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨ坎")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ坏"))
			title = title.replace(l11l1l_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿࠾ࡨࡱࡃ࠭坐"),l11l1l_l1_ (u"ࠩࠣࠫ坑"))
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ坒"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ坓"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ坔") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨ坕")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ坖"))
		#		addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ块"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111lll_l1_,l1lll1l1_l1_ = [],[],[]
	l111ll1_l1_ = url.replace(l11l1l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭坘"),l11l1l_l1_ (u"ࠪ࠳ࡻ࡯ࡥࡸ࠰ࡳ࡬ࡵ࠭坙"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ坚"),l111ll1_l1_,l11l1l_l1_ (u"ࠬ࠭坛"),l11l1l_l1_ (u"࠭ࠧ坜"),l11l1l_l1_ (u"ࠧࠨ坝"),l11l1l_l1_ (u"ࠨࠩ坞"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ坟"))
	html = response.content
	# l1l1111ll_l1_ l1llll1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ坠"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ坡"),block,re.DOTALL)
		if l1l1_l1_:
			l1llll1_l1_ = l1l1_l1_[0]
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭坢"))
				l1lll1_l1_.append(l1llll1_l1_)
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ坣"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1lllllll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧ坤"),block,re.DOTALL)
		block = block.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠦࠬ坥"),l11l1l_l1_ (u"ࠩࠥࠫ坦")).replace(l11l1l_l1_ (u"ࠪࡠ࠴࠭坧"),l11l1l_l1_ (u"ࠫ࠴࠭坨"))
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨ࠼ࡪࡨࡵࡥࡲ࡫࠮ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ坩"),block,re.DOTALL)
		if len(l1lllllll1_l1_)==len(l1l1_l1_):
			for id,title in l1lllllll1_l1_:
				l1llll1_l1_ = l1l1_l1_[int(id)]
				if l1llll1_l1_ not in l1lll1_l1_:
					l1l111lll_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ坪")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ坫"))
					l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ坬"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ坭"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111lll_l1_.append(l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ坮")+title+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ坯"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111lll_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll1l1_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ坰"),l1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1l1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ坱"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ坲"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ坳"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ坴"),l11l1l_l1_ (u"ࠪ࠯ࠬ坵"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ坶")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ坷"))
	#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ坸")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ坹"))
	return
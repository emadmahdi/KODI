# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ㺝")
headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㺞") : l11l1l_l1_ (u"ࠨࠩ㺟") }
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡑ࡛ࡠ࡟ࠨ㺠")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l11lll1lll_l1_ = l1l1ll1_l1_[l1ll1_l1_][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l1lllll_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1lll1ll_l1_(url)
	elif mode==188: results = l11l111l111_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11l111l111_l1_():
	message = l11l1l_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ㺡")
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㺢"),l11l1l_l1_ (u"ࠬ࠭㺣"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㺤"),message)
	return
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㺥"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㺦"),l11l1l_l1_ (u"ࠩࠪ㺧"),189,l11l1l_l1_ (u"ࠪࠫ㺨"),l11l1l_l1_ (u"ࠫࠬ㺩"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㺪"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺫"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㺬")+l1111l_l1_+l11l1l_l1_ (u"ࠨส๋็ุࠦว้ใํื๋่ࠥโ์ีࠤ้อๆะࠩ㺭"),l11l11_l1_,181,l11l1l_l1_ (u"ࠩࠪ㺮"),l11l1l_l1_ (u"ࠪࠫ㺯"),l11l1l_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ㺰"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺱"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㺲")+l1111l_l1_+l11l1l_l1_ (u"ࠧฤฯาฯࠥอไศใ็ห๊࠭㺳"),l11l11_l1_,181,l11l1l_l1_ (u"ࠨࠩ㺴"),l11l1l_l1_ (u"ࠩࠪ㺵"),l11l1l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ㺶"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺷"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㺸")+l1111l_l1_+l11l1l_l1_ (u"࠭สๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࠬ㺹"),l11l11_l1_,181,l11l1l_l1_ (u"ࠧࠨ㺺"),l11l1l_l1_ (u"ࠨࠩ㺻"),l11l1l_l1_ (u"ࠩࡷࡺࠬ㺼"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺽"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㺾")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬ㺿"),l11l11_l1_,181,l11l1l_l1_ (u"࠭ࠧ㻀"),l11l1l_l1_ (u"ࠧࠨ㻁"),l11l1l_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ㻂"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻃"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㻄")+l1111l_l1_+l11l1l_l1_ (u"ࠫศ่่๊ࠢส่ฬ็ไศ็ࠣห้ำวๅ์ฬࠫ㻅"),l11l11_l1_,181,l11l1l_l1_ (u"ࠬ࠭㻆"),l11l1l_l1_ (u"࠭ࠧ㻇"),l11l1l_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ㻈"))
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠨࠩ㻉"),headers,l11l1l_l1_ (u"ࠩࠪ㻊"),l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㻋"))
	items = re.findall(l11l1l_l1_ (u"ࠫࡁ࡮࠲࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㻌"),html,re.DOTALL)
	for l1llll1_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㻍"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㻎")+l1111l_l1_+title,l1llll1_l1_,181)
	return html
def l1lllll_l1_(url,type=l11l1l_l1_ (u"ࠧࠨ㻏")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ㻐"),headers,l11l1l_l1_ (u"ࠩࠪ㻑"),l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㻒"))
	if type==l11l1l_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ㻓"): block = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃษอะอࠣห้ษแๅษ่ࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ㻔"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ㻕"): block = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧ㻖"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㻗"): block = re.findall(l11l1l_l1_ (u"ࠩࡥࡸࡳ࠳࠲࠮ࡱࡹࡩࡷࡲࡡࡺࠪ࠱࠮ࡄ࠯࠼ࡴࡶࡼࡰࡪࡄࠧ㻘"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭㻙"): block = re.findall(l11l1l_l1_ (u"ࠫࡧࡺ࡮࠮࠳ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠨ࠯ࠬࡂ࠭ࡧࡺ࡮࠮࠴ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠧ㻚"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠬࡺࡶࠨ㻛"): block = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄสๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳ࡭ࠢࠨ㻜"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11l1l_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ㻝"),l11l1l_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㻞")]:
		items = re.findall(l11l1l_l1_ (u"ࠩࡶࡸࡾࡲࡥ࠾ࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㻟"),block,re.DOTALL)
	else: items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠸ࡡ࠰࠮࠻ࡠ࠯ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㻠"),block,re.DOTALL)
	l11l_l1_ = []
	l111l1ll1_l1_ = [l11l1l_l1_ (u"ࠫๆ๐ไๆࠩ㻡"),l11l1l_l1_ (u"ࠬอไฮๆๅอࠬ㻢"),l11l1l_l1_ (u"࠭วๅฯ็ๆ์࠭㻣"),l11l1l_l1_ (u"ฺࠧำูࠫ㻤"),l11l1l_l1_ (u"ࠨࡔࡤࡻࠬ㻥"),l11l1l_l1_ (u"ࠩࡖࡱࡦࡩ࡫ࡅࡱࡺࡲࠬ㻦"),l11l1l_l1_ (u"ࠪห฾๊ว็ࠩ㻧"),l11l1l_l1_ (u"ࠫฬาาศรࠪ㻨")]
	for l1ll1l_l1_,l111lllll11_l1_,l11l111l11l_l1_,l11l111l1l1_l1_ in items:
		if type in [l11l1l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ㻩"),l11l1l_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ㻪")]:
			l1ll1l_l1_,l1llll1_l1_,l1llll11ll_l1_,title = l1ll1l_l1_,l111lllll11_l1_,l11l111l11l_l1_,l11l111l1l1_l1_
		else: l1ll1l_l1_,title,l1llll1_l1_,l1llll11ll_l1_ = l1ll1l_l1_,l111lllll11_l1_,l11l111l11l_l1_,l11l111l1l1_l1_
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧࡀࡸ࡬ࡩࡼࡃࡴࡳࡷࡨࠫ㻫"),l11l1l_l1_ (u"ࠨࠩ㻬"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㻭"),l11l1l_l1_ (u"ࠪࠫ㻮"),l1llll1_l1_,l1llll11ll_l1_)
		title = unescapeHTML(title)
		#l1lll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠫฬั๎ฯสࡾหะํี็ࠪࠩ㻯"),title,re.DOTALL)
		#if l1lll11ll_l1_: title = l1lll11ll_l1_[0][0]
		if l11l1l_l1_ (u"ࠬฮฬ้ัฬࠤࠬ㻰") in title or l11l1l_l1_ (u"࠭ศอ๊า๋ࠥ࠭㻱") in title:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㻲") + title.replace(l11l1l_l1_ (u"ࠨสฯ์ิฯࠠࠨ㻳"),l11l1l_l1_ (u"ࠩࠪ㻴")).replace(l11l1l_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ㻵"),l11l1l_l1_ (u"ࠫࠬ㻶"))
		title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ㻷"))
		if l11l1l_l1_ (u"࠭วๅฯ็ๆฮ࠭㻸") in title or l11l1l_l1_ (u"ࠧศๆะ่็ํࠧ㻹") in title:
			l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡟ࡨ࠰࠭㻺"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㻻") + l1ll1l1_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㻼"),l1111l_l1_+title,l1llll1_l1_,183,l1ll1l_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111l1ll1_l1_):
			l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ㻽") + l1llll11ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㻾"),l1111l_l1_+title,l1llll1_l1_,182,l1ll1l_l1_)
		else:
			l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ㻿") + l1llll11ll_l1_
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㼀"),l1111l_l1_+title,l1llll1_l1_,183,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"ࠨࠩ㼁"):
		items = re.findall(l11l1l_l1_ (u"ࠩ࡟ࡲࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㼂"),html,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠪห้฻แฮหࠣࠫ㼃"),l11l1l_l1_ (u"ࠫࠬ㼄"))
			if title!=l11l1l_l1_ (u"ࠬ࠭㼅"):
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㼆"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭㼇")+title,l1llll1_l1_,181)
	return
def l1lll1ll_l1_(url):
	l111ll1_l1_ = url.split(l11l1l_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ㼈"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ㼉"),headers,l11l1l_l1_ (u"ࠪࠫ㼊"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㼋"))
	block = re.findall(l11l1l_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂ࠳࠰࠿ࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࡞࠴࠲࠿࡝ࠬࠫࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㼌"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡜࠲࠰࠽ࡢ࠱ࠧ㼍"),title,re.DOTALL)
	if name: name = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㼎") + name[0][0]
	else: name = title
	items = []
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࡑࡹࡲࡨࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㼏"),html,re.DOTALL)
	if l1l11ll_l1_:
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㼐"),l11l1l_l1_ (u"ࠪࠫ㼑"),l111ll1_l1_,str(l1l11ll_l1_))
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㼒"),block,re.DOTALL)
		for l1llll1_l1_ in items:
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
			title = re.findall(l11l1l_l1_ (u"ࠬ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ㼓"),l1llll1_l1_.split(l11l1l_l1_ (u"࠭࠯ࠨ㼔"))[-2],re.DOTALL)
			if not title: title = re.findall(l11l1l_l1_ (u"ࠧࠩࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ㼕"),l1llll1_l1_.split(l11l1l_l1_ (u"ࠨ࠱ࠪ㼖"))[-2],re.DOTALL)
			if title: title = l11l1l_l1_ (u"ࠩࠣࠫ㼗") + title[0][1]
			else: title = l11l1l_l1_ (u"ࠪࠫ㼘")
			title = name + l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨ㼙") + l11l1l_l1_ (u"ࠬอไฮๆๅอࠬ㼚") + title
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㼛"),l1111l_l1_+title,l1llll1_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠧษฮ๋ำฮࠦࠧ㼜") in title or l11l1l_l1_ (u"ࠨสฯ์ิํࠠࠨ㼝") in title:
			title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㼞") + title.replace(l11l1l_l1_ (u"ࠪฬั๎ฯสࠢࠪ㼟"),l11l1l_l1_ (u"ࠫࠬ㼠")).replace(l11l1l_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ㼡"),l11l1l_l1_ (u"࠭ࠧ㼢"))
		addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㼣"),l1111l_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l11l111l1ll_l1_ = url.split(l11l1l_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ㼤"))
	l111ll1_l1_ = l11l111l1ll_l1_[0]
	del l11l111l1ll_l1_[0]
	html = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ㼥"),headers,l11l1l_l1_ (u"ࠪࠫ㼦"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㼧"))
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡬࡯࡯ࡶ࠰ࡷ࡮ࢀࡥ࠻ࠢ࠵࠹ࡵࡾ࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㼨"),html,re.DOTALL)[0]
	if l1llll1_l1_ not in l11l111l1ll_l1_: l11l111l1ll_l1_.append(l1llll1_l1_)
	l1lll1_l1_ = []
	# l11l1111l1l_l1_
	for l1llll1_l1_ in l11l111l1ll_l1_:
		if l11l1l_l1_ (u"࠭࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ㼩") in l1llll1_l1_:
			l11l1111l1l_l1_ = l1llll1_l1_
			l1lll1_l1_.append(l11l1111l1l_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡣ࡬ࡲࠬ㼪"))
	# l11l11111ll_l1_
	for l1llll1_l1_ in l11l111l1ll_l1_:
		if l11l1l_l1_ (u"ࠨ࠼࠲࠳ࡻࡨ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠫ㼫") in l1llll1_l1_:
			html = OPENURL_CACHED(l1llll1l_l1_,l1llll1_l1_,l11l1l_l1_ (u"ࠩࠪ㼬"),headers,l11l1l_l1_ (u"ࠪࠫ㼭"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㼮"))
			html = html.decode(l11l1l_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡸ࠳࠱࠳࠷࠹ࠫ㼯")).encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㼰"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l111llll1ll_l1_><l111lllllll_l1_ /><l111llll1ll_l1_ l11l1111lll_l1_=l11l1l_l1_ (u"ࠢࡤࡧࡱࡸࡪࡸࠢ㼱")>(\*\*\*\*\*\*\*\*|13721411411.l111llll11l_l1_|)
			html = html.replace(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㼲"),l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㼳"))
			html = html.replace(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㼴"),l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㼵"))
			html = html.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ㼶"),l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㼷"))
			html = html.replace(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ㼸"),l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㼹"))
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ㼺"),html,re.DOTALL)
			if l1l11ll_l1_:
				#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㼻"),l11l1l_l1_ (u"ࠫࠬ㼼"),url,str(len(l1l11ll_l1_)))
				l111llll1l1_l1_,l11l11111l1_l1_ = [],[]
				if len(l1l11ll_l1_)==1:
					title = l11l1l_l1_ (u"ࠬ࠭㼽")
					block = html
				else:
					for block in l1l11ll_l1_:
						l1ll111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠲࠯ࡅ࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰ࠫࠩ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ㼾"),block,re.DOTALL)
						if l1ll111_l1_: block = l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ㼿") + l1ll111_l1_[0][1]
						l1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅ࠼ࡩࡴࠣࡷ࡮ࢀࡥ࠾ࠤ࠴ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴࠽ࠣࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶ࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ㽀"),block,re.DOTALL)
						if l1ll111_l1_: block = l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ㽁") + l1ll111_l1_[0]
						l1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࠩ࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࠧࠦ࠯࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ㽂"),block,re.DOTALL)
						if l1ll111_l1_: block = l1ll111_l1_[0] + l11l1l_l1_ (u"ࠫࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㽃")
						l11l1111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࠨ࠯ࠬࡂ࠭࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲ࠫ㽄"),block,re.DOTALL)
						title = re.findall(l11l1l_l1_ (u"࠭࠾ࠡࠬࠫ࡟ࡣࡂ࠾࡞࠭ࠬࠤ࠯ࡂࠧ㽅"),l11l1111ll1_l1_[0][0],re.DOTALL)
						title = l11l1l_l1_ (u"ࠧࠡࠩ㽆").join(title)
						title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ㽇"))
						title = title.replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ㽈"),l11l1l_l1_ (u"ࠪࠤࠬ㽉")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ㽊"),l11l1l_l1_ (u"ࠬࠦࠧ㽋")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ㽌"),l11l1l_l1_ (u"ࠧࠡࠩ㽍")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ㽎"),l11l1l_l1_ (u"ࠩࠣࠫ㽏")).replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭㽐"),l11l1l_l1_ (u"ࠫࠥ࠭㽑"))
						l111llll1l1_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬ࠿࠭㽒"), l111llll1l1_l1_)
					if l1l_l1_ == -1 : return
					title = l111llll1l1_l1_[l1l_l1_]
					block = l1l11ll_l1_[l1l_l1_]
				l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠪࠤࠪ㽓"),block,re.DOTALL)
				l11l1111111_l1_ = l1llll1_l1_[0]
				l1lll1_l1_.append(l11l1111111_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡇࡱࡵࡹࡲ࠭㽔"))
				block = block.replace(l11l1l_l1_ (u"ࠨโࠪ㽕"),l11l1l_l1_ (u"ࠩࠪ㽖"))
				block = block.replace(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠸࠵࠼࠺࠱࠳࠳࠺࠹࠷࠿࠶࠯ࡲࡱ࡫ࠧ࠭㽗"),l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ㽘"))
				block = block.replace(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ㽙"),l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ㽚"))
				block = block.replace(l11l1l_l1_ (u"ࠧิ์ิๅึอสࠡษ็ฮา๋๊ๅࠩ㽛"),l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ㽜"))
				block = block.replace(l11l1l_l1_ (u"ࠩิ์ฬฮืࠡษ็ฮา๋๊ๅࠩ㽝"),l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ㽞"))
				block = block.replace(l11l1l_l1_ (u"ุࠫ๐ัโำสฮࠥอไๆึส๋ิ࠭㽟"),l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ㽠"))
				block = block.replace(l11l1l_l1_ (u"࠭ั้ษห฻ࠥอไๆึส๋ิ࠭㽡"),l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ㽢"))
				l111lllll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲ࡠࡩ࠱ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ㽣"),block,re.DOTALL)
				for l11l111111l_l1_ in l111lllll1l_l1_:
					#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㽤"),l11l1l_l1_ (u"ࠪࠫ㽥"),l11l1l_l1_ (u"ࠫࠬ㽦"),str(l11l111111l_l1_))
					type = re.findall(l11l1l_l1_ (u"ࠬࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠪ㽧"),l11l111111l_l1_)
					if type:
						if type[0]!=l11l1l_l1_ (u"࠭ࡢࡰࡶ࡫ࠫ㽨"): type = l11l1l_l1_ (u"ࠧࡠࡡࠪ㽩")+type[0]
						else: type = l11l1l_l1_ (u"ࠨࠩ㽪")
					items = re.findall(l11l1l_l1_ (u"ࠩࠫࡃࡁࠧࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠭࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽࠱ࡩࡳࡳࡺ࠾࠯ࠬࡂࢀࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰࠼ࡣࡴࠣ࠳ࡃ࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࠬ㽫"),l11l111111l_l1_,re.DOTALL)
					for l111llllll1_l1_,l1llll1_l1_ in items:
						title = re.findall(l11l1l_l1_ (u"ࠪࠬࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰ࠩ࠽ࠩ㽬"),l111llllll1_l1_)
						title = title[-1]
						l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㽭") + title + type
						l1lll1_l1_.append(l1llll1_l1_)
	# l11l111ll11_l1_
	l111lll_l1_ = l111ll1_l1_.replace(l11l11_l1_,l11lll1lll_l1_)
	html = OPENURL_CACHED(l1llll1l_l1_,l111lll_l1_,l11l1l_l1_ (u"ࠬ࠭㽮"),headers,l11l1l_l1_ (u"࠭ࠧ㽯"),l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㽰"))
	items = re.findall(l11l1l_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㽱"),html,re.DOTALL)
	#l11ll1lll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡪࡳࡢࡦࡦࡐ࠱࠭ࡢࡷࠬࠫ࠰࠲࠯ࡅ࠮ࡩࡶࡰࡰ࠮࠭㽲"),html,re.DOTALL)
	#if l11ll1lll1_l1_:
	if items:
		#l11l111ll11_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴࠭㽳") + l11ll1lll1_l1_[-1] + l11l1l_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ㽴")
		l11l111ll11_l1_ = items[-1]
		l1lll1_l1_.append(l11l111ll11_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ㽵"))
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㽶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ㽷"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ㽸"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ㽹"),l11l1l_l1_ (u"ࠪ࠯ࠬ㽺"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ㽻"),headers,l11l1l_l1_ (u"ࠬ࠭㽼"),l11l1l_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㽽"))
	items = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ㽾"),html,re.DOTALL)
	l111l1l11_l1_ = [ l11l1l_l1_ (u"ࠨࠩ㽿") ]
	l1111ll11_l1_ = [ l11l1l_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ㾀") ]
	for category,title in items:
		l111l1l11_l1_.append(category)
		l1111ll11_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ㾁"), l1111ll11_l1_)
		if l1l_l1_ == -1 : return
		category = l111l1l11_l1_[l1l_l1_]
	else: category = l11l1l_l1_ (u"ࠫࠬ㾂")
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ㾃")+search+l11l1l_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭㾄")+category
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㾅"),l11l1l_l1_ (u"ࠨࠩ㾆"),url,url)
	l1lllll_l1_(url)
	return
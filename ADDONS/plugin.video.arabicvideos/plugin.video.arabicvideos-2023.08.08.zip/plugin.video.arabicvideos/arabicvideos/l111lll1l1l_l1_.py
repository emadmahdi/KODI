# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ䆯")
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䆰"):l11l1l_l1_ (u"ࠪࠫ䆱")}
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ䆲")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ䆳")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11llll_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11l1l_l1_ (u"࠭࠳ࠨ䆴"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11l1l_l1_ (u"ࠧ࠲ࠩ䆵"))
	elif mode==36: results = CATEGORIES(url,l11l1l_l1_ (u"ࠨ࠴ࠪ䆶"))
	elif mode==37: results = CATEGORIES(url,l11l1l_l1_ (u"ࠩ࠷ࠫ䆷"))
	elif mode==38: results = l1l1ll11l_l1_()
	elif mode==39: results = SEARCH(text,l11llll_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䆸"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䆹"),l11l1l_l1_ (u"ࠬ࠭䆺"),39,l11l1l_l1_ (u"࠭ࠧ䆻"),l11l1l_l1_ (u"ࠧࠨ䆼"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䆽"))
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䆾"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆿"),l11l1l_l1_ (u"ࠫࠬ䇀"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ䇁"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䇂")+l1111l_l1_+l11l1l_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ䇃"),l11l1l_l1_ (u"ࠨࠩ䇄"),38)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇅"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䇆")+l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ศาษ่ะࠬ䇇"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䇈"),31)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䇉"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䇊")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊วไอิࠤฺ๊ว่ัฬࠫ䇋"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䇌"),37)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇍"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䇎")+l1111l_l1_+l11l1l_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็๊ํ฿ࠧ䇏"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ䇐"),35)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇑"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䇒")+l1111l_l1_+l11l1l_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไๆ็ฮ่ࠬ䇓"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ䇔"),36)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇕"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䇖")+l1111l_l1_+l11l1l_l1_ (u"࠭วฮัฮࠤฬ๊วโๆส้ࠬ䇗"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ䇘"),32)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇙"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䇚")+l1111l_l1_+l11l1l_l1_ (u"ุ้ࠪือ๋ษอࠫ䇛"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳࠹࠵࠱ࠨ䇜"),32)
	return l11l1l_l1_ (u"ࠬ࠭䇝")
def CATEGORIES(url,select=l11l1l_l1_ (u"࠭ࠧ䇞")):
	type = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䇟"))[3]
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䇠"),l11l1l_l1_ (u"ࠩࠪ䇡"),type, url)
	if type==l11l1l_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䇢"):
		html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠫࠬ䇣"),headers,l11l1l_l1_ (u"ࠬ࠭䇤"),l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹ࠭䇥"))
		if select==l11l1l_l1_ (u"ࠧ࠴ࠩ䇦"):
			l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯ࡳࡦࡴ࡬ࡩࡸࡌ࡯ࡳ࡯ࠪ䇧"),html,re.DOTALL)
			block= l1l11ll_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䇨"),block,re.DOTALL)
			for l1llll1_l1_,name in items:
				if l11l1l_l1_ (u"ࠪ็้๐ศศฬ้ࠣ฻ำใสࠩ䇩") in name: continue
				url = l11l11_l1_ + l1llll1_l1_
				name = name.strip(l11l1l_l1_ (u"ࠫࠥ࠭䇪"))
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇫"),l1111l_l1_+name,url,32)
		if select==l11l1l_l1_ (u"࠭࠴ࠨ䇬"):
			l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡤࡦࡶࡤ࡭ࡱࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡺࡃࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䇭"),html,re.DOTALL)
			block= l1l11ll_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䇮"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				url = l11l11_l1_ + l1llll1_l1_
				title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ䇯"))
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇰"),l1111l_l1_+title,url,32,l1ll1l_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䇱"),l11l1l_l1_ (u"ࠬ࠭䇲"),url,l11l1l_l1_ (u"࠭ࠧ䇳"))
	if type==l11l1l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䇴"):
		html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠨࠩ䇵"),headers,l11l1l_l1_ (u"ࠩࠪ䇶"),l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠲࡯ࡦࠪ䇷"))
		if select==l11l1l_l1_ (u"ࠫ࠶࠭䇸"):
			l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡌ࡫࡮ࡥࡧࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ䇹"),html,re.DOTALL)
			block = l1l11ll_l1_[0]
			items=re.findall(l11l1l_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䇺"),block,re.DOTALL)
			for value,name in items:
				url = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯ࠨ䇻") + value
				name = name.strip(l11l1l_l1_ (u"ࠨࠢࠪ䇼"))
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇽"),l1111l_l1_+name,url,32)
		elif select==l11l1l_l1_ (u"ࠪ࠶ࠬ䇾"):
			l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡅࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䇿"),html,re.DOTALL)
			block = l1l11ll_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䈀"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11l1l_l1_ (u"࠭ࠠࠨ䈁"))
				url = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡣࡦࡸࡴࡸ࠯ࠨ䈂") + value
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈃"),l1111l_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䈄"),l11l1l_l1_ (u"ࠪࠫ䈅"),url,l11l1l_l1_ (u"ࠫࠬ䈆"))
	type = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ䈇"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧ䈈"),headers,l11l1l_l1_ (u"ࠧࠨ䈉"),l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ䈊"))
	if l11l1l_l1_ (u"ࠩ࡫ࡳࡲ࡫ࠧ䈋") in url: type=l11l1l_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䈌")
	if type==l11l1l_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䈍"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠩ࠰࠭ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ䈎"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䈏"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,name in items:
				url = l11l11_l1_ + l1llll1_l1_
				name = name.strip(l11l1l_l1_ (u"ࠧࠡࠩ䈐"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈑"),l1111l_l1_+name,url,32,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䈒"):
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䈓"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨ䈔"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ䈕"))
			url = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䈖"),l1111l_l1_+name,url,33,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䈗"):
		l11llll_l1_ = url.split(l11l1l_l1_ (u"ࠨ࠱ࠪ䈘"))[-1]
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䈙"),l11l1l_l1_ (u"ࠪࠫ䈚"),url,l11l1l_l1_ (u"ࠫࠬ䈛"))
		if l11llll_l1_==l11l1l_l1_ (u"ࠬ࠷ࠧ䈜"):
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠫ䈝"),html,re.DOTALL)
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶࠨ䈞"),block,re.DOTALL)
			count = 0
			for l1llll1_l1_,l1ll1l_l1_,l1ll1l1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11l1l_l1_ (u"ࠨࠢ࠰ࠤࠬ䈟") + l1ll1l1_l1_
				url = l11l11_l1_ + l1llll1_l1_
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䈠"),l1111l_l1_+name,url,33,l1ll1l_l1_)
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹ࠮ࠫࡁࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䈡"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࠬ䈢"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title,l1ll1l1_l1_ in items:
			l1ll1l1_l1_ = l1ll1l1_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠧ䈣"))
			title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ䈤"))
			name = title + l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ䈥") + l1ll1l1_l1_
			url = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䈦"),l1111l_l1_+name,url,33,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡪࡰࡾࡶࡨࡪࡥࡲࡲ࠲ࡩࡨࡦࡸࡵࡳࡳ࠳ࡲࡪࡩ࡫ࡸ࠭࠴ࠫࡀࠫࡧࡥࡹࡧ࠭ࡳࡧࡹ࡭ࡻ࡫࠭ࡻࡱࡱࡩ࡮ࡪ࠽ࠣ࠶ࠥࠫ䈧"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䈨"),block,re.DOTALL)
	for l1llll1_l1_,l11llll_l1_ in items:
		url = l11l11_l1_ + l1llll1_l1_
		name = l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ䈩") + l11llll_l1_
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈪"),l1111l_l1_+name,url,32)
	return
def PLAY(url):
	if l11l1l_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䈫") in url:
		url = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸ࠴ࡼ࠱࠰ࡵࡨࡶ࡮࡫ࡳࡍ࡫ࡱ࡯࠴࠭䈬") + url.split(l11l1l_l1_ (u"ࠨ࠱ࠪ䈭"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䈮"),url,l11l1l_l1_ (u"ࠪࠫ䈯"),headers,l11l1l_l1_ (u"ࠫࠬ䈰"),l11l1l_l1_ (u"ࠬ࠭䈱"),l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䈲"))
		html = response.content
		items = re.findall(l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䈳"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11l1l_l1_ (u"ࠨ࡞࠲ࠫ䈴"),l11l1l_l1_ (u"ࠩ࠲ࠫ䈵"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䈶"),url,l11l1l_l1_ (u"ࠫࠬ䈷"),headers,l11l1l_l1_ (u"ࠬ࠭䈸"),l11l1l_l1_ (u"࠭ࠧ䈹"),l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ䈺"))
		html = response.content
		items = re.findall(l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡗࡕࡐࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䈻"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䈼"))
	return
def SEARCH(search,l11llll_l1_=l11l1l_l1_ (u"ࠪࠫ䈽")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭䈾"),l11l1l_l1_ (u"ࠬࠫ࠲࠱ࠩ䈿"))
	l1l1lll1l_l1_ = [l11l1l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䉀"),l11l1l_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䉁")]
	if not l11llll_l1_: l11llll_l1_ = l11l1l_l1_ (u"ࠨ࠳ࠪ䉂")
	else: l11llll_l1_,type = l11llll_l1_.split(l11l1l_l1_ (u"ࠩ࠲ࠫ䉃"))
	if l1ll_l1_:
		l1l111lll_l1_ = [ l11l1l_l1_ (u"ࠪฬาัฺ่ࠠࠣหๆ๊วๆࠩ䉄") , l11l1l_l1_ (u"ࠫอำหࠡ฻้ࠤู๊ไิๆสฮࠬ䉅")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢ࠰ࠤฬิสาࠢส่อำหࠨ䉆"), l1l111lll_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lll1l_l1_[l1l_l1_]
	else:
		if l11l1l_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧ䉇") in options: type = l11l1l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䉈")
		elif l11l1l_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࡠࠩ䉉") in options: type = l11l1l_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䉊")
		else: return
	headers[l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䉋")] = l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䉌")
	data = {l11l1l_l1_ (u"ࠬࡷࡵࡦࡴࡼࠫ䉍"):l1111l1_l1_ , l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡊ࡯࡮ࡣ࡬ࡲࠬ䉎"):type}
	if l11llll_l1_!=l11l1l_l1_ (u"ࠧ࠲ࠩ䉏"): data[l11l1l_l1_ (u"ࠨࡨࡵࡳࡲ࠭䉐")] = l11llll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䉑"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ䉒"),data,headers,l11l1l_l1_ (u"ࠫࠬ䉓"),l11l1l_l1_ (u"ࠬ࠭䉔"),l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䉕"))
	html = response.content
	items=re.findall(l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䉖"),html,re.DOTALL)
	if items:
		for title,l1llll1_l1_ in items:
			url = l11l11_l1_ + l1llll1_l1_.replace(l11l1l_l1_ (u"ࠨ࡞࠲ࠫ䉗"),l11l1l_l1_ (u"ࠩ࠲ࠫ䉘"))
			if l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ䉙") in url: addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䉚"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็๊ๅ็ࠣࠫ䉛")+title,url,33)
			elif l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䉜") in url:
				url = url.replace(l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䉝"),l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࠧ䉞"))
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉟"),l1111l_l1_+l11l1l_l1_ (u"ุ้๊ࠪำๅࠢࠪ䉠")+title,url+l11l1l_l1_ (u"ࠫ࠴࠷ࠧ䉡"),32)
	count=re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡰࡶࡤࡰࠧࡀࠨ࠯ࠬࡂ࠭ࢂ࠭䉢"),html,re.DOTALL)
	if count:
		l1l1l1l1l_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll1111l_l1_ in range(1,l1l1l1l1l_l1_):
			l1ll1111l_l1_ = str(l1ll1111l_l1_)
			if l1ll1111l_l1_!=l11llll_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䉣"),l11l1l_l1_ (u"ࠧึใะอࠥ࠭䉤")+l1ll1111l_l1_,l11l1l_l1_ (u"ࠨࠩ䉥"),39,l11l1l_l1_ (u"ࠩࠪ䉦"),l1ll1111l_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ䉧")+type,search)
	return
def l1l1ll11l_l1_():
	l1llll1_l1_ = l11l1l_l1_ (u"ࠫࡦࡎࡒ࠱ࡥࡇࡳࡻࡒ࠲ࡥࡼࡧࡌࡏࡲ࡙ࡘ࠲࠳ࡐࡳࡈࡨࡣ࡯࡙࠴ࡑࡳࡎࡷࡎࡰࡰࡸࡒ࠲ࡗ࡭࡝࠶࡛࡬࡙ࡘࡌࡼࡐ࠷࡮ࡨࡣࡉࡉ࡙࡛࡯࠹ࡸࡤࡊࡊ࠺ࡨࡇ࡭ࡼࡧࡇ࠺ࡺࡍ࠴ࡗ࠷ࠫ䉨")
	l1llll1_l1_ = base64.b64decode(l1llll1_l1_)
	l1llll1_l1_ = l1llll1_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䉩"))
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ䉪"))
	return
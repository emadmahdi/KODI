# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ啈")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭啉")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨไ้์ฬะࠠโุสส๏ฯࠧ啊"),l11l1l_l1_ (u"ࠩไหึูใ้ࠩ啋"),l11l1l_l1_ (u"ࠪࡗ࡭ࡵࡷࠡ࡯ࡲࡶࡪ࠭啌")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l1lllll_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1lll1ll_l1_(url,text)
	elif mode==584: results = l11lll_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ啍"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭啎"),l11l1l_l1_ (u"࠭ࠧ問"),l11l1l_l1_ (u"ࠧࠨ啐"),l11l1l_l1_ (u"ࠨࠩ啑"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ啒"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啓"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ啔"),l11l1l_l1_ (u"ࠬ࠭啕"),589,l11l1l_l1_ (u"࠭ࠧ啖"),l11l1l_l1_ (u"ࠧࠨ啗"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ啘"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ啙"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ啚"),l11l1l_l1_ (u"ࠫࠬ啛"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ啜"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ啝"),html,re.DOTALL)
	for l1ll111_l1_ in l1l11ll_l1_: block = block.replace(l1ll111_l1_,l11l1l_l1_ (u"ࠧࠨ啞"))
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭啟"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ啠"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ啡")+l1111l_l1_+title,l1llll1_l1_,584)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ啢"),url,l11l1l_l1_ (u"ࠬ࠭啣"),l11l1l_l1_ (u"࠭ࠧ啤"),l11l1l_l1_ (u"ࠧࠨ啥"),l11l1l_l1_ (u"ࠨࠩ啦"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ啧"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ啨"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ啩"),l11l1l_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ啪"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ啫"),block,re.DOTALL)
		if not l1l11ll_l1_: l1l11ll_l1_ = [(l11l1l_l1_ (u"ࠧࠨ啬"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭啭"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ啮"),l11l1l_l1_ (u"ࠪࠫ啯"),9999)
		for l111l1_l1_,block in l1l11ll_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ啰"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠬࡀࠠࠨ啱")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭啲"),l1111l_l1_+title,l1llll1_l1_,581)
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ啳"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ啴"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ啵"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ啶"),l11l1l_l1_ (u"ࠫࠬ啷"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ啸"),l1111l_l1_+title,l1llll1_l1_,581)
	if not l1l111l_l1_ and not l1l1111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"࠭ࠧ啹")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ啺"),l11l1l_l1_ (u"ࠨࠩ啻"),request,url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭啼"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ啽"),url,l11l1l_l1_ (u"ࠫࠬ啾"),l11l1l_l1_ (u"ࠬ࠭啿"),l11l1l_l1_ (u"࠭ࠧ喀"),l11l1l_l1_ (u"ࠧࠨ喁"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ喂"))
	html = response.content
	items = []
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喃"),html,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪ善"),html,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭喅"),html,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喆"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ喇"),block,re.DOTALL)
	if not items: items = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ喈"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠨ็ืห์ีษࠨ喉"),l11l1l_l1_ (u"ࠩไ๎้๋ࠧ喊"),l11l1l_l1_ (u"ࠪห฿์๊สࠩ喋"),l11l1l_l1_ (u"่๊๊ࠫษࠩ喌"),l11l1l_l1_ (u"ࠬอูๅษ้ࠫ喍"),l11l1l_l1_ (u"࠭็ะษไࠫ喎"),l11l1l_l1_ (u"ࠧๆสสีฬฯࠧ喏"),l11l1l_l1_ (u"ࠨ฻ิฺࠬ喐"),l11l1l_l1_ (u"่๋ࠩึาว็ࠩ喑"),l11l1l_l1_ (u"ࠪห้ฮ่ๆࠩ喒"),l11l1l_l1_ (u"ู๊ࠫัฮ์ฬࠫ喓")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ喔"))
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ喕") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ喖")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ喗"))
		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ喘") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ喙")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭喚"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ喛"))
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ喜"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭喝"),l1111l_l1_+title,l1llll1_l1_,582,l1ll1l_l1_)
		elif l1ll1l1_l1_ and l11l1l_l1_ (u"ࠨษ็ั้่ษࠨ喞") in title:
			title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ喟") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喠"),l1111l_l1_+title,l1llll1_l1_,583,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ喡") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喢"),l1111l_l1_+title,l1llll1_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喣"),l1111l_l1_+title,l1llll1_l1_,583,l1ll1l_l1_)
	if request not in [l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ喤"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ喥")]:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喦"),html,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ喧"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭喨"): continue
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ喩")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ喪"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ喫"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ喬")+title,l1llll1_l1_,581)
		l1llll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ喭"),html,re.DOTALL)
		if l1llll1111_l1_:
			l1llll1_l1_ = l1llll1111_l1_[0]
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ單"),l1111l_l1_+l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ喯"),l1llll1_l1_,581)
	return
def l1lll1ll_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭喰"),l11l1l_l1_ (u"࠭ࠧ喱"),l1l11_l1_,url)
	#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ喲"),l11l1l_l1_ (u"ࠨ࠳࠴࠵࠶ࠦࠠࠨ喳")+url)
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭喴"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ喵"),url,l11l1l_l1_ (u"ࠫࠬ営"),l11l1l_l1_ (u"ࠬ࠭喷"),l11l1l_l1_ (u"࠭ࠧ喸"),l11l1l_l1_ (u"ࠧࠨ喹"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ喺"))
	html = response.content
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡱࡥࡻ࠳ࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ喻"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ喼"),str(l1l11_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ喽"),str(l1l1111_l1_))
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l111l_l1_ and not l1l11_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ喾"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"࠭ࠣࠨ喿"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗀"),l1111l_l1_+title,url,583,l11l1l_l1_ (u"ࠨࠩ嗁"),l11l1l_l1_ (u"ࠩࠪ嗂"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ嗃")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嗄"),html,re.DOTALL)
	if l1l1111_l1_ and l111l_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ嗅"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"࠭࠯ࠨ嗆")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ嗇"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嗈"),l1111l_l1_+title,l1llll1_l1_,582)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ嗉"),block,re.DOTALL)
			for l1llll1_l1_,title,l1ll1l_l1_ in items:
				if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嗊") not in l1llll1_l1_: l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴࠭嗋")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ嗌"))
				addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嗍"),l1111l_l1_+title,l1llll1_l1_,582)
	return
def PLAY(url):
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ嗎"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嗏"),url,l11l1l_l1_ (u"ࠩࠪ嗐"),l11l1l_l1_ (u"ࠪࠫ嗑"),l11l1l_l1_ (u"ࠫࠬ嗒"),l11l1l_l1_ (u"ࠬ࠭嗓"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嗔"))
	html = response.content
	# l1lll11_l1_ l11llll_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗕"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	if l1llll1_l1_ and l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭嗖") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ嗗")+l1llll1_l1_
	#//www.l11ll1111lll_l1_.l11ll1111ll1_l1_/l11ll111l111_l1_/?l11ll111l1ll_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࡬ࡦࡹࡨ࠾ࠩ嗘"))[1]
	parts = hash.split(l11l1l_l1_ (u"ࠫࡤࡥࠧ嗙"))
	l11ll111l1l1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11l1l_l1_ (u"ࠬࡃࠧ嗚"))
			if kodi_version>18.99: part = part.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ嗛"))
			l11ll111l1l1_l1_.append(part)
		except: pass
	l1l1_l1_ = l11l1l_l1_ (u"ࠧ࠿ࠩ嗜").join(l11ll111l1l1_l1_)
	l1l1_l1_ = l1l1_l1_.splitlines()
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ嗝"),str(l1l1_l1_))
	if l11l1l_l1_ (u"ࠩࡩࡥࡷࡹ࡯࡭ࠩ嗞") not in str(l1l1_l1_):
		for l1llll1_l1_ in l1l1_l1_:
			title,l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࠤࡂࡄࠠࠨ嗟"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嗠")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嗡")
			l1lll1_l1_.append(l1llll1_l1_)
		#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ嗢"),l1lll1_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嗣"),url)
	else:
		title,l1llll1_l1_ = l1l1_l1_[0].split(l11l1l_l1_ (u"ࠨࠢࡀࡂࠥ࠭嗤"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ嗥"),l11l1l_l1_ (u"ࠪࠫ嗦"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ嗧"),l11l1l_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫ嗨")+l11l1l_l1_ (u"࠭࡜࡯ࠩ嗩")+l11l1l_l1_ (u"๋ࠧำฯํࠥอไๆฯส์้ฯࠠๅษะๆฬ࠭嗪")+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭嗫")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ嗬"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ嗭"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭嗮"),l11l1l_l1_ (u"ࠬ࠱ࠧ嗯"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ嗰")+search
	l1lllll_l1_(url)
	return
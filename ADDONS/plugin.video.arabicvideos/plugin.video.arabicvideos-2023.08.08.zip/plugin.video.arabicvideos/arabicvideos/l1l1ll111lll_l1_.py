# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ墉")
#headers = {l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ墊"):l11l1l_l1_ (u"ࠨࠩ墋")}
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨ墌")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ฺ้ࠪอัฺหࠪ墍"),l11l1l_l1_ (u"ࠫอัࠠๆสสุึ࠭墎")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l1lllll_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1lll1ll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ墏"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ墐"),l11l1l_l1_ (u"ࠧࠨ墑"),l11l1l_l1_ (u"ࠨࠩ墒"),l11l1l_l1_ (u"ࠩࠪ墓"),l11l1l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ墔"))
	html = response.content
	l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ墕"),html,re.DOTALL)
	l1l1lll_l1_ = l1l1lll_l1_[0].strip(l11l1l_l1_ (u"ࠬ࠵ࠧ墖"))
	l1l1lll_l1_ = SERVER(l1l1lll_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ増"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墘"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ墙"),l1l1lll_l1_,489,l11l1l_l1_ (u"ࠩࠪ墚"),l11l1l_l1_ (u"ࠪࠫ墛"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ墜"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ墝"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭增"),l11l1l_l1_ (u"ࠧࠨ墟"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墠"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ墡")+l1111l_l1_+l11l1l_l1_ (u"ࠪวาีหࠡษ็้ํอึ๋฻ࠪ墢"),l1l1lll_l1_,481)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩࠣ࡯ࡼࡅࡨࡩ࡯ࡶࡰࡷࠦࠬ墣"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭墤"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l1llll1_l1_==l11l1l_l1_ (u"࠭ࠣࠨ墥"): continue
		if title in l1l111_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墦"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ墧")+l1111l_l1_+title,l1llll1_l1_,481)
	return html
def l1lllll_l1_(url,l11l1lll11l1_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭墨"),url,l11l1l_l1_ (u"ࠪࠫ墩"),l11l1l_l1_ (u"ࠫࠬ墪"),l11l1l_l1_ (u"ࠬ࠭墫"),l11l1l_l1_ (u"࠭ࠧ墬"),l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭墭"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡳࡸࡺࠨ࠯ࠬࡂ࠭ࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭墮"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ墯"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪ墰"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩ墱"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫ墲"),l11l1l_l1_ (u"࠭ร฻่ํอࠬ墳"),l11l1l_l1_ (u"ࠧไๆํฬࠬ墴"),l11l1l_l1_ (u"ࠨษ฼่ฬ์ࠧ墵"),l11l1l_l1_ (u"๊ࠩำฬ็ࠧ墶"),l11l1l_l1_ (u"้ࠪออัศหࠪ墷"),l11l1l_l1_ (u"ࠫ฾ืึࠨ墸"),l11l1l_l1_ (u"๋ࠬ็าฮส๊ࠬ墹"),l11l1l_l1_ (u"࠭วๅส๋้ࠬ墺"),l11l1l_l1_ (u"ࠧๆีิั๏ฯࠧ墻")]
	l11l1lll11ll_l1_ = l11l1l_l1_ (u"ࠨ࠱ࠪ墼").join(l11l1lll11l1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ墽")).split(l11l1l_l1_ (u"ࠪ࠳ࠬ墾"))[4:]).split(l11l1l_l1_ (u"ࠫ࠲࠭墿"))
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭壀"),title,re.DOTALL)
		if l11l1lll11l1_l1_:
			l1llll11ll_l1_ = l11l1l_l1_ (u"࠭࠯ࠨ壁").join(l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ壂")).split(l11l1l_l1_ (u"ࠨ࠱ࠪ壃"))[4:]).split(l11l1l_l1_ (u"ࠩ࠰ࠫ壄"))
			l11l1lll1l11_l1_ = len([x for x in l11l1lll11ll_l1_ if x in l1llll11ll_l1_])
			if l11l1lll1l11_l1_>2 and l11l1l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ壅") in l1llll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ壆"),l1111l_l1_+title,l1llll1_l1_,482,l1ll1l_l1_)
		else:
			if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ壇"),title,re.DOTALL)
			#if any(value in title for value in l1ll11_l1_):
			if set(title.split()) & set(l1ll11_l1_) and l11l1l_l1_ (u"࠭ๅิๆึ่ࠬ壈") not in title:
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭壉"),l1111l_l1_+title,l1llll1_l1_,482,l1ll1l_l1_)
			elif l1ll1l1_l1_ and l11l1l_l1_ (u"ࠨฯ็ๆฮ࠭壊") in title:
				title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ壋") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壌"),l1111l_l1_+title,l1llll1_l1_,483,l1ll1l_l1_,l11l1l_l1_ (u"ࠫࠬ壍"),url)
					l11l_l1_.append(title)
			else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壎"),l1111l_l1_+title,l1llll1_l1_,483,l1ll1l_l1_,l11l1l_l1_ (u"࠭ࠧ壏"),url)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠢࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠥ壐"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ壑"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠩสฺ่็อสࠢࠪ壒"),l11l1l_l1_ (u"ࠪࠫ壓"))
			if title!=l11l1l_l1_ (u"ࠫࠬ壔"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壕"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ壖")+title,l1llll1_l1_,481,l11l1l_l1_ (u"ࠧࠨ壗"),l11l1l_l1_ (u"ࠨࠩ壘"),l11l1lll11l1_l1_)
	return
def l1lll1ll_l1_(url,l111ll1_l1_):
	headers = {l11l1l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ壙"):l11l1l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ壚")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ壛"),url,l11l1l_l1_ (u"ࠬ࠭壜"),headers,l11l1l_l1_ (u"࠭ࠧ壝"),l11l1l_l1_ (u"ࠧࠨ壞"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ壟"))
	html = response.content
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭壠"))
	l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦ࡮ࡳࡧ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ壡"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ壢"))
	l11l1lll111l_l1_ = True
	l1l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨ࡬ࡪࡵࡷࡗࡪࡧࡳࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ壣"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l111l_l1_ and l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠭壤") not in url:
		block = l1l111l_l1_[0]
		count = block.count(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠫ壥"))
		if count==0: count = block.count(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠧ壦"))
		if count>1:
			l11l1lll111l_l1_ = False
			if l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂࠨࠧ壧") in block:
				items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ壨"),block,re.DOTALL)
				for id,title in items:
					l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠸࠮ࡱࡪࡳࡃࡸࡲࡵࡨ࠿ࠪ壩")+id
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壪"),l1111l_l1_+title,l1llll1_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ士"),block,re.DOTALL)
				for id,title in items:
					l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠰ࡳ࡬ࡵࡅࡳࡦࡴ࡬ࡩࡸࡏࡄ࠾ࠩ壬")+id
					addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壭"),l1111l_l1_+title,l1llll1_l1_,483,l1ll1l_l1_)
	# l11ll_l1_
	if l11l1lll111l_l1_:
		block = l11l1l_l1_ (u"ࠩࠪ壮")
		if l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ壯") in url: block = html
		else:
			l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡫ࡰ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ声"),html,re.DOTALL)
			if l1l1111_l1_: block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ壱"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ売"))
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭壳"),l1111l_l1_+title,l1llll1_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lllll_l1_(l111ll1_l1_,url)
	return
def PLAY(url):
	l111ll1_l1_ = url.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ壴"))+l11l1l_l1_ (u"ࠩ࠲ࡃࡩࡵ࠽ࡸࡣࡷࡧ࡭࠭壵")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ壶"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ壷"),l11l1l_l1_ (u"ࠬ࠭壸"),l11l1l_l1_ (u"࠭ࠧ壹"),l11l1l_l1_ (u"ࠧࠨ壺"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ壻"))
	html = response.content
	l1lll1_l1_ = []
	l1l1lll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭壼"))
	l1ll1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡺࡴࡥࡰࡰࡵࡷࡍࡉࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ壽"),html,re.DOTALL)
	if not l1ll1ll111_l1_: l1ll1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡ࠮ࡴࡩ࡫ࡶࡠ࠳࡯ࡤ࡝࠮࠳ࡠ࠱࠮࠮ࠫࡁࠬࡠ࠮࠭壾"),html,re.DOTALL)
	l1ll1ll111_l1_ = l1ll1ll111_l1_[0]
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ壿"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ夀"),block,re.DOTALL)
		for l1ll1lll11_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ夁"))
			l1llll1_l1_ = l1l1lll_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱࡬ࡪࡷࡧ࡭ࡦ࠴࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ夂")+l1ll1ll111_l1_+l11l1l_l1_ (u"ࠩࠩࡺ࡮ࡪࡥࡰ࠿ࠪ夃")+l1ll1lll11_l1_[2:]+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ处")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ夅")
			l1lll1_l1_.append(l1llll1_l1_)
	# l1l1111ll_l1_ l11l1l111_l1_ l1llll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡧࡦࡶࡈࡱࡧ࡫ࡤࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ夆"),html,re.DOTALL)
	if l1llll1_l1_:
		title = SERVER(l1llll1_l1_[0],l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ备"))
		l1llll1_l1_ = l1llll1_l1_[0]+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ夈")+title+l11l1l_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ変")
		l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l111ll1_l1_ = url.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ夊"))+l11l1l_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ夋")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ夌"),l111ll1_l1_,l11l1l_l1_ (u"ࠬ࠭复"),l11l1l_l1_ (u"࠭ࠧ夎"),l11l1l_l1_ (u"ࠧࠨ夏"),l11l1l_l1_ (u"ࠨࠩ夐"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭夑"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡧࡢ࡭ࡧ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ夒"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夓"),block,re.DOTALL)
		for title,l1llll1_l1_ in items:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ夔"))
			if l11l1l_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ夕") in l1llll1_l1_: l1lll11ll_l1_ = l11l1l_l1_ (u"ࠧࡠࡡัหฺ࠭外")
			else: l1lll11ll_l1_ = l11l1l_l1_ (u"ࠨࠩ夗")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ夘")+title+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ夙")+l1lll11ll_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ多"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ夛"),url)
	return
def SEARCH(search,l1l1lll_l1_=l11l1l_l1_ (u"࠭ࠧ夜")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ夝"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ夞"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ够"),l11l1l_l1_ (u"ࠪ࠯ࠬ夠"))
	if l1l1lll_l1_==l11l1l_l1_ (u"ࠫࠬ夡"): l1l1lll_l1_ = l11l11_l1_
	url = l1l1lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ夢")+search+l11l1l_l1_ (u"࠭࠯ࠨ夣")
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࠨ夤"))
	return
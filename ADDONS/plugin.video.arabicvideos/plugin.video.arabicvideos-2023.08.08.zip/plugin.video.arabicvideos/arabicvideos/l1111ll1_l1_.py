# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰ࡸ࡬ࡩࡼ࠳࠱࠰ษไ่ฬฺ๋࠭ำห๎ฮ࠭౩")
#l11l11_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ౪")
#l11l11_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠵࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ౫")
#l11l11_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵ࠭౬")
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ౭")
headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ౮"):l11l1l_l1_ (u"ࠬ࠭౯")}
l1111l_l1_ = l11l1l_l1_ (u"࠭࡟ࡌࡎࡄࡣࠬ౰")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==10: results = MENU()
	elif mode==11: results = l1lllll_l1_(url)
	elif mode==12: results = PLAY(url)
	elif mode==13: results = l1lll1ll_l1_(url)
	elif mode==14: results = l1llll11l_l1_()
	elif mode==15: results = l1lllll1l_l1_()
	elif mode==16: results = l1111l11_l1_()
	elif mode==19: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౱"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ౲"),l11l1l_l1_ (u"ࠩࠪ౳"),19,l11l1l_l1_ (u"ࠪࠫ౴"),l11l1l_l1_ (u"ࠫࠬ౵"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ౶"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ౷"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ౸"),l11l1l_l1_ (u"ࠨࠩ౹"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౺"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ౻")+l1111l_l1_+l11l1l_l1_ (u"ࠫวิัࠡษ็ษ฻อแศฬࠪ౼"),l11l1l_l1_ (u"ࠬ࠭౽"),14)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౾"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ౿")+l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠨಀ"),l11l1l_l1_ (u"ࠩࠪಁ"),15)
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠪࠫಂ"),headers,l11l1l_l1_ (u"ࠫࠬಃ"),l11l1l_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ಄"))
	l1l11ll_l1_=re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࡲࡦࡼ࠭ࡴ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬಅ"),html,re.DOTALL)
	l111l1l1_l1_ = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩಆ"),l111l1l1_l1_,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪಇ"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಈ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬಉ")+l1111l_l1_+title,l1llll1_l1_,11)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩಊ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬಋ"),l11l1l_l1_ (u"࠭ࠧಌ"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡳࡧࡶࡣࡣࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ಍"),html,re.DOTALL)
	l1ll111_l1_ = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪಎ"),l1ll111_l1_,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಏ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬಐ")+l1111l_l1_+title,l1llll1_l1_,11)
	return html
def l1lllll1l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ಑"),l1111l_l1_+l11l1l_l1_ (u"ࠬาๅ๋฻ࠣห้๋ำๅี็หฯࠦวๅ฻ิฬ๏ฯࠧಒ"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠲࠾࠯ๆี็ื้อส࠮฻ิฬ๏ฯࠧಓ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಔ"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠢสุ่์ษࠡษ็วำ๐ัสࠩಕ"),l11l1l_l1_ (u"ࠩࠪಖ"),16)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಗ"),l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤฬ๊รฯ์ิอࠥ࠷ࠧಘ"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠱࠽࠵ๅิๆึ่ฬะ࠭า็ูห๋࠳࠲࠱࠴࠵ࠫಙ"),11)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಚ"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠศๆฦา๏ืษࠡ࠴ࠪಛ"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡪࡽ࠭࠹࠱่ืู้ไศฬ࠰ี๊฼ว็࠯࠵࠴࠷࠹ࠧಜ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಝ"),l1111l_l1_+l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠳ࠨಞ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠳࠵࠲ฺ้ื๊สࠩಟ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಠ"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠴࠵ࠫಡ"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠶࠷࠵ๅึำํอࠬಢ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಣ"),l1111l_l1_+l11l1l_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠷࠷ࠧತ"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠲࠲࠱ู่ึ๐ษࠨಥ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫದ"),l1111l_l1_+l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠳࠲ࠪಧ"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠵࠴࠴๋ีา์ฬࠫನ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ಩"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠾࠭ಪ"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠹࠰็ุี๏ฯࠧಫ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಬ"),l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠱࠹ࠩಭ"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠳࠻࠳๊฻ั๋หࠪಮ"),11)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಯ"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠴࠻ࠬರ"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠶࠽࠯ๆืิ๎ฮ࠭ಱ"),11)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಲ"),l1111l_l1_+l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠷࠶ࠨಳ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠲࠸࠲ฺ้ื๊สࠩ಴"),11)
	return
def l1llll11l_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭ವ"),headers,True,l11l1l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪಶ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨಷ"),l11l1l_l1_ (u"ࠨࠩಸ"),l11l1l_l1_ (u"ࠩࠪಹ"),html)
	l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠪ࡬ࡪࡧࡤࡪࡰࡪ࠱ࡹࡵࡰࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠩ಺"),html,re.DOTALL)
	block = l1l11ll_l1_[0]+l1l11ll_l1_[1]
	items=re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭಻"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		url = l11l11_l1_ + l1llll1_l1_
		if l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ಼ࠬ") in url: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಽ"),l1111l_l1_+title,url,11,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ಾ"),l1111l_l1_+title,url,12,l1ll1l_l1_)
	return
def l1lllll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩಿ"),l11l1l_l1_ (u"ࠩࠪೀ"),l11l1l_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪು"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨೂ"),url,l11l1l_l1_ (u"ࠬ࠭ೃ"),headers,True,True,l11l1l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪೄ"))
	html = response.content
	#open(l11l1l_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ೅"),l11l1l_l1_ (u"ࠨࡹࠪೆ")).write(str(html))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻࠫ࠲࠯ࡅࠩࡳ࡫ࡪ࡬ࡹࡥࡣࡰࡰࡷࡩࡳࡺࠧೇ"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	block = l1l11ll_l1_[0]
	l1ll1l11l_l1_ = False
	#items = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࡞࠹࠷ࡣ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨೈ"),block,re.DOTALL)
	items = re.findall(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡦࡴࡾ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ೉"),block,re.DOTALL)
	l11l_l1_,l1111l1l_l1_ = [],[]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if title==l11l1l_l1_ (u"ࠬ࠭ೊ"): title = l1llll1_l1_.split(l11l1l_l1_ (u"࠭࠯ࠨೋ"))[-1].replace(l11l1l_l1_ (u"ࠧ࠮ࠩೌ"),l11l1l_l1_ (u"ࠨ್ࠢࠪ"))
		l111l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡠࡩ࠱ࠩࠨ೎"),title,re.DOTALL)
		if l111l11l_l1_: l111l11l_l1_ = int(l111l11l_l1_[0])
		else: l111l11l_l1_ = 0
		l1111l1l_l1_.append([l1ll1l_l1_,l1llll1_l1_,title,l111l11l_l1_])
	l1111l1l_l1_ = sorted(l1111l1l_l1_, reverse=True, key=lambda key: key[3])
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ೏"),l11l1l_l1_ (u"ࠫࠬ೐"),l11l1l_l1_ (u"ࠬ࠸࠲࠳ࠩ೑"),url)
	for l1ll1l_l1_,l1llll1_l1_,title,l111l11l_l1_ in l1111l1l_l1_:
		l1llll1_l1_ = l11l11_l1_ + l1llll1_l1_
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ೒"),l11l1l_l1_ (u"ࠧࠨ೓"),url,title)
		title = title.replace(l11l1l_l1_ (u"ࠨ็ืห์ีษࠡ็ึุ่๊ࠧ೔"),l11l1l_l1_ (u"่ࠩืู้ไࠨೕ"))
		title = title.replace(l11l1l_l1_ (u"ู้ࠪอ็ะหࠣห้๋ำๅี็ࠫೖ"),l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ࠬ೗"))
		title = title.replace(l11l1l_l1_ (u"๋ࠬิศ้าอࠥ็๊ๅ็ࠪ೘"),l11l1l_l1_ (u"࠭แ๋ๆ่ࠫ೙"))
		title = title.replace(l11l1l_l1_ (u"ࠧๆึส๋ิฯࠠศๆไ๎้๋ࠧ೚"),l11l1l_l1_ (u"ࠨษ็ๅ๏๊ๅࠨ೛"))
		title = title.replace(l11l1l_l1_ (u"่ࠩฬฬฺัสࠢๆ์ฬ๊๊ห์ࠪ೜"),l11l1l_l1_ (u"ࠪࠫೝ"))
		title = title.replace(l11l1l_l1_ (u"ࠫ฾อไ๋หࠣ฽้๏ࠠศๆ฼ีอ࠭ೞ"),l11l1l_l1_ (u"ࠬ࠭೟"))
		title = title.replace(l11l1l_l1_ (u"࠭ๅีษ๊ำฮࠦๅษษืีฮ࠭ೠ"),l11l1l_l1_ (u"ࠧࠨೡ"))
		title = title.replace(l11l1l_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠪೢ"),l11l1l_l1_ (u"ࠩࠪೣ"))
		title = title.replace(l11l1l_l1_ (u"ࠪหํ์ไศ์้ࠫ೤"),l11l1l_l1_ (u"ࠫࠬ೥"))
		title = title.replace(l11l1l_l1_ (u"ࠬฮฬ้ัฬࠤ฾อไ๋หࠪ೦"),l11l1l_l1_ (u"࠭ࠧ೧"))
		title = title.replace(l11l1l_l1_ (u"ࠧอ๊าอࠥ฿วๅ์ฬࠫ೨"),l11l1l_l1_ (u"ࠨࠩ೩"))
		title = title.replace(l11l1l_l1_ (u"ࠩหำํ์ࠠหฯ่๎้࠭೪"),l11l1l_l1_ (u"ࠪࠫ೫"))
		title = title.replace(l11l1l_l1_ (u"ࠫ฾๊้ࠡษ็฽ึฮࠧ೬"),l11l1l_l1_ (u"ࠬ࠭೭"))
		title = title.replace(l11l1l_l1_ (u"࠭ๅษษืีฮ࠭೮"),l11l1l_l1_ (u"ࠧࠨ೯"))
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ೰")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬೱ"),l11l1l_l1_ (u"ࠪࠤࠬೲ")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧೳ"),l11l1l_l1_ (u"ࠬࠦࠧ೴"))
		title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ೵")+title
		l1lll11ll_l1_ = title
		if l11l1l_l1_ (u"ࠧ࠰ࡳ࠲ࠫ೶") in url and (l11l1l_l1_ (u"ࠨษ็ั้่ษࠨ೷") in title or l11l1l_l1_ (u"ࠩส่า๊โ่ࠩ೸") in title):
			l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭೹"),title,re.DOTALL)
			if l1ll1l1_l1_: l1lll11ll_l1_ = l1ll1l1_l1_[0]
			#if l11l1l_l1_ (u"ู๊ࠫไิๆࠪ೺") not in l1lll11ll_l1_: l1lll11ll_l1_ = l11l1l_l1_ (u"๋ࠬำๅี็ࠤࠬ೻")+l1lll11ll_l1_
		if l1lll11ll_l1_ not in l11l_l1_:
			l11l_l1_.append(l1lll11ll_l1_)
			#xbmc.log(l1lll11ll_l1_, level=xbmc.LOGNOTICE)
			if l11l1l_l1_ (u"࠭࠯ࡲ࠱ࠪ೼") in url and (l11l1l_l1_ (u"ࠧศๆะ่็ฯࠧ೽") in title or l11l1l_l1_ (u"ࠨษ็ั้่็ࠨ೾") in title):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೿"),l1111l_l1_+l1lll11ll_l1_,l1llll1_l1_,13,l1ll1l_l1_)
				l1ll1l11l_l1_ = True
			elif l11l1l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪഀ") in l1llll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഁ"),l1111l_l1_+title,l1llll1_l1_,11,l1ll1l_l1_)
				l1ll1l11l_l1_ = True
			else:
				#if l11l1l_l1_ (u"๋ࠬำๅี็ࠫം") not in title and l11l1l_l1_ (u"࠭วๅฯ็ๆฮ࠭ഃ") in title: title = l11l1l_l1_ (u"ࠧๆี็ื้ࠦࠧഄ")+title
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧഅ"),l1111l_l1_+title,l1llll1_l1_,12,l1ll1l_l1_)
				l1ll1l11l_l1_ = True
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪആ"),l11l1l_l1_ (u"ࠪࠫഇ"),l11l1l_l1_ (u"ࠫ࠸࠹࠳ࠨഈ"),url)
	if l1ll1l11l_l1_:
		items = re.findall(l11l1l_l1_ (u"ࠬࡺࡳࡤࡡ࠶ࡨࡤࡨࡵࡵࡶࡲࡲࠥࡸࡥࡥ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪഉ"),block,re.DOTALL)
		for l1llll1_l1_,l11llll_l1_ in items:
			url = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ഊ"),l1111l_l1_+l11llll_l1_,url,11)
	return
def l1lll1ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠧࠨഋ"),headers,True,l11l1l_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧഌ"))
	l111l111_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡷࡪࡸࡩࡦࡵ࠱࠮ࡄ࠯ࠢࠨ഍"),html,re.DOTALL)
	l111ll1_l1_ = l11l11_l1_+l111l111_l1_[0]
	results = l1lllll_l1_(l111ll1_l1_)
	return
l11l1l_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡉࡕࡏࡓࡐࡆࡈࡗࡤࡕࡌࡅࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰࡙ࡸࡵࡦ࠮ࠪࡅࡑࡇࡒࡂࡄ࠰ࡉࡕࡏࡓࡐࡆࡈࡗࡤࡕࡌࡅ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡣࡣࡱࡲࡪࡸ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࡫ࡦ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡷࡹ࡫ࡰࠡ࠴ࠪ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠭ࠩࡶࡸࡪࡶࠠ࠴ࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡩࡵࡧࡰࡷ࠱ࠦࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠷࡝ࠪࠌࠌࠧࡳࡧ࡭ࡦࠢࡀࠤࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡏ࡮ࡧࡱࡏࡥࡧ࡫࡬ࠩࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠺ࠧࠪࠌࠌࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࠦ࠽ࠡ࡝ࡠࠎࠎ࡬࡯ࡳࠢ࡬ࡱ࡬࠲࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࠣࡲࡴࡺࠠࡪࡰࠣࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡸ࡬ࡨࡪࡵࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬำๅี็ࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠵࠷࠲ࡩ࡮ࡩࠬࠎࠎࠏࠉࡢ࡮࡯ࡘ࡮ࡺ࡬ࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡹࡴࡦࡲࠣ࠹ࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦഎ")
def PLAY(url):
	l1lll1_l1_ = []
	html = OPENURL_CACHED(l1ll1ll11_l1_,url,l11l1l_l1_ (u"ࠫࠬഏ"),headers,True,l11l1l_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧഐ"))
	# l1lll1ll1_l1_ l1lll11l1_l1_ server
	# https://l111l1ll_l1_.l1lll1l11_l1_.com/l1lll1111_l1_-_حلقة_1ll1l1l1_l1_حكايتي_1llllll1_l1_رمضان_111111l_l1_
	# https://l1111lll_l1_.l1lll1l11_l1_.com/numeric/110272.l11111ll_l1_/l1111111_l1_.l1lll1ll1_l1_
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦࡵࡳ࠱࡮࡬ࡲࡢ࡯ࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ഑"),html,re.DOTALL)
	if l111ll1_l1_:
		l111ll1_l1_ = l111ll1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠪࠧഒ"),l111ll1_l1_,re.DOTALL)
		if l1l1_l1_:
			first = l1l1_l1_[0][0]
			second,l1ll1ll1l_l1_ = l1l1_l1_[0][1].rsplit(l11l1l_l1_ (u"ࠨ࠱ࠪഓ"),1)
			l111lll_l1_ = second+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪഔ")
			l1lll1_l1_.append(l111lll_l1_)
			l1lllll11_l1_ = first+l1ll1ll1l_l1_
		else:
			l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫക"),headers,False,l11l1l_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ഖ"))
			l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ഗ"),l11ll11l_l1_,re.DOTALL)
			if l111ll1_l1_:
				l111ll1_l1_ = l111ll1_l1_[0]+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯࠶ࡹ࠽࠭ഘ")
				l1lll1_l1_.append(l111ll1_l1_)
	# l1ll1l111_l1_ server - l1lllllll_l1_ - https://l111l1ll_l1_.l1lll1l11_l1_.com/l1lll111l_l1_-_الذئب_حلقة_1ll1llll_l1_
	# l1ll1l111_l1_ server - l1ll1l1ll_l1_ - https://l111l1ll_l1_.l1lll1l11_l1_.com/l11111l1_l1_-_1ll1lll1_l1_فيلم_اكشن_1llll1l1_l1_
	# l1ll1l111_l1_ server - l1llll111_l1_ - https://l111l1ll_l1_.l1lll1l11_l1_.com/l1lll1lll_l1_-_لحلقة_1llll1ll_l1_السجين_مترجمة_1lll1l1l_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡂࡰࡺࠫ࠲࠯ࡅࠩ࠽ࡵࡷࡽࡱ࡫࠾ࠨങ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧച"),block,re.DOTALL)
		if l111ll1_l1_:
			l111ll1_l1_ = l111ll1_l1_[0]+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪഛ")
			l1lll1_l1_.append(l111ll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩജ"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪഝ"),url)
	return
def l1111l11_l1_():
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭ഞ"),headers,True,l11l1l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡒࡂࡏࡄࡈࡆࡔ࠭࠲ࡵࡷࠫട"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࡤࡹࡥࡤࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡱ࡫ࡦࡵࡡࡦࡳࡳࡺࡥ࡯ࡶࠥࠫഠ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪഡ"),block,re.DOTALL)
	year = re.findall(l11l1l_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱࠬࡠ࠶࠭࠺࡟࠮࠭࠴࠭ഢ"),str(items),re.DOTALL)
	year = year[0]
	for l1llll1_l1_,title in items:
		url = l11l11_l1_+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬണ"))+l11l1l_l1_ (u"ࠫࠥ࠭ത")+year
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬഥ"),l1111l_l1_+title,url,11)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧദ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨധ"): return
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"ࠨࠢࠪന"),l11l1l_l1_ (u"ࠩ࠮ࠫഩ"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠥ࠳ࡶ࠵ࠢപ") + l1111l1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬഫ"),l11l1l_l1_ (u"ࠬ࠭ബ"),l11l1l_l1_ (u"࠭࠳࠴࠵ࠪഭ"),url)
	results = l1lllll_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟ࠧ摮")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l11111l111ll_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ摯"))
	l1l11ll1ll_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ摰"))
	l111l1l1ll1l_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭摱"))
	l1llll11ll1l1_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ摲"))
	l111l111llll_l1_ = xbmc.LOGINFO
	l1l111llll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭摳"),l11l1l_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ摴"),l11l1l_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ摵"))
	l111ll11l11l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ摶"),l11l1l_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ摷"),l11l1l_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ摸"))
	l1ll1111l1_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ摹"),l11l1l_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭摺"),l11l1l_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ摻"))
	ltr,rtl = l11l1l_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ摼"),l11l1l_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ摽")
	half_triangular_colon = l11l1l_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ摾")
	from urllib.parse import quote as _1lllll1ll1ll_l1_
	from urllib.parse import unquote as _111ll1l1111_l1_
else:
	l11111l111ll_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ摿"))
	l1l11ll1ll_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ撀"))
	l111l1l1ll1l_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ撁"))
	l1llll11ll1l1_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭撂"))
	l111l111llll_l1_ = xbmc.LOGNOTICE
	l1l111llll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ撃"),l11l1l_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ撄"),l11l1l_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭撅"))
	l111ll11l11l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ撆"),l11l1l_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ撇"),l11l1l_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ撈"))
	l1ll1111l1_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ撉"),l11l1l_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ撊"),l11l1l_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ撋"))
	ltr,rtl = l11l1l_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩ撌").encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ撍")),l11l1l_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫ撎").encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ撏"))
	half_triangular_colon = l11l1l_l1_ (u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭撐").encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ撑"))
	from urllib import quote as _1lllll1ll1ll_l1_
	from urllib import unquote as _111ll1l1111_l1_
addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split(l11l1l_l1_ (u"ࠧ࠰ࠩ撒"))[2]	# plugin.video.l1111111l11l_l1_
l1lll11ll1lll_l1_ = addon_id.split(l11l1l_l1_ (u"ࠨ࠰ࠪ撓"))[2]		# l1111111l11l_l1_
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
#l111lll1llll_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l1111111l11l_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡋࡵ࡬ࡥࡧࡵࡔࡦࡺࡨࠨ撔"))
addon_version = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠪ撕")+addon_id+l11l1l_l1_ (u"ࠫ࠮࠭撖"))
settings = xbmcaddon.Addon(id=addon_id)
dest_lang = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ撗"))
do_trans = False if not dest_lang or dest_lang==l11l1l_l1_ (u"࠭ࡡࡳࡣࠪ撘") else True
l1l11l1l1l11_l1_ = os.path.join(l111l1l1ll1l_l1_,l11l1l_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ撙"))
l11ll1l1l1l1_l1_ = os.path.join(l111l1l1ll1l_l1_,l11l1l_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧ撚"))
l1l11llllll1_l1_ = [l11l1l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ撛"),l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ撜"),l11l1l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧ撝"),l11l1l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧ撞"),l11l1l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧ撟"),l11l1l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࠫ撠")]
l1l111lll1ll_l1_ = l1l11llllll1_l1_+[l11l1l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ撡"),l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ撢"),l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ撣"),l11l1l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡳ࡬ࡪࡴ࡯࡮ࡧࡱࡥࡱࡋࡍࡂࡆࠪ撤")]		# ,l11l1l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱࡭ࡳࡹࡴࡢ࡮࡯ࡉࡒࡇࡄࠨ撥")
addoncachefolder = os.path.join(l1llll11ll1l1_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫ撦"))
iptv1_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ撧"))
iptv2_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ撨"))
l11l1ll1111_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ撩"))
#l1111111l1l1_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠪࡼࡹࡸࡥࡢ࡯ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭撪"))
l11l111llll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠫࡱࡧࡳࡵࡸ࡬ࡨࡪࡵࡳ࠯ࡦࡤࡸࠬ撫"))
#l1lllllllllll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠬࡲࡡࡴࡶࡰࡩࡳࡻ࠮ࡥࡣࡷࠫ撬"))
favoritesfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ播"))
#dummyiptvfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠧࡥࡷࡰࡱࡾ࡯ࡰࡵࡸ࠱ࡨࡦࡺࠧ撮"))
fulliptvfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ撯"))
l1l111l1l11_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ撰"))
l1l11ll1l11l_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡪࡡࡵࠩ撱"))
l1ll1lll1l1ll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ撲"))
addonfolder = xbmcaddon.Addon().getAddonInfo(l11l1l_l1_ (u"ࠬࡶࡡࡵࡪࠪ撳"))
defaulticon = os.path.join(addonfolder,l11l1l_l1_ (u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ撴"))
defaultthumb = os.path.join(addonfolder,l11l1l_l1_ (u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ撵"))
defaultfanart = os.path.join(addonfolder,l11l1l_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯࡬ࡳ࡫ࠬ撶"))
l1l1111l111l_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩ撷"))
l1ll11l1l1_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ撸"))
l11lll1111l1_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭撹"),l11l1l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ撺"),addon_id,l11l1l_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ撻"))
l11111ll1111_l1_ = os.path.join(l11111l111ll_l1_,l11l1l_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭撼"),l11l1l_l1_ (u"ࠨࡈࡲࡲࡹࡹࠧ撽"),l11l1l_l1_ (u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬ撾"))
l1l1111l1111_l1_ = [l11l1l_l1_ (u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬ撿"),l11l1l_l1_ (u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬ擀"),l11l1l_l1_ (u"ࠬࡋࡍࡂࡋࡏࡗࠬ擁"),l11l1l_l1_ (u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ擂"),l11l1l_l1_ (u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩ擃"),l11l1l_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ擄"),l11l1l_l1_ (u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧ擅")]
l111l1l11l11_l1_ = [l11l1l_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࠪ擆"),l11l1l_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭擇"),l11l1l_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ擈")]
FOLDERS_COUNT = 5
text_numbers = [l11l1l_l1_ (u"࠭ีโำࠪ擉"),l11l1l_l1_ (u"ࠧฤ๊็ࠫ擊"),l11l1l_l1_ (u"ࠨอส๊๏࠭擋"),l11l1l_l1_ (u"ࠩฮห้ัࠧ擌"),l11l1l_l1_ (u"ࠪีฬฮูࠨ操"),l11l1l_l1_ (u"ࠫำอๅิࠩ擎"),l11l1l_l1_ (u"ูࠬวะีࠪ擏"),l11l1l_l1_ (u"࠭ำศส฼ࠫ擐"),l11l1l_l1_ (u"ࠧฬษ่๊ࠬ擑"),l11l1l_l1_ (u"ࠨฬสื฾࠭擒"),l11l1l_l1_ (u"ࠩ฼หูืࠧ擓")]
l11ll1l11l1l_l1_ = l11l1l_l1_ (u"ࠪ⸿ࠥ⼣ࠠ⸫ࠢ⸾ࠫ擔")
now = int(time.time())
l111lllll1l1_l1_ = 60
HOUR = 60*l111lllll1l1_l1_
l1ll1ll1l11ll_l1_ = 24*HOUR
l1111ll11lll_l1_ = 30*l1ll1ll1l11ll_l1_
NO_CACHE = 0
l1111lll1l1_l1_ = 30*l111lllll1l1_l1_
l1ll1ll11_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l1llll1l_l1_ = 3*l1ll1ll1l11ll_l1_
VERYLONG_CACHE = 30*l1ll1ll1l11ll_l1_
PERMANENT_CACHE = 12*l1111ll11lll_l1_
l11ll1lll1l1_l1_ = 1*HOUR
l1lll11ll1l11_l1_ = [l11l1l_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭擕"),l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ擖")]
l111111111l1_l1_ = [l11l1l_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ擗")]
l11111l111l1_l1_ = [l11l1l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ擘"),l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ擙"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭據"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ擛"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ擜"),l11l1l_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ擝"),l11l1l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭擞")]
l11111l111l1_l1_ += [l11l1l_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭擟"),l11l1l_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ擠"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ擡"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ擢"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭擣"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ擤"),l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ擥")]
l1ll1ll1ll11l_l1_ = [l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ擦"),l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ擧"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ擨"),l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ擩")]
l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"ࠫࡒ࠹ࡕࠨ擪"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ擫"),l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ擬"),l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ擭")]
l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ擮"),l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ擯"),l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ擰")]
l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭擱"),l11l1l_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ擲"),l11l1l_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ擳"),l11l1l_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ擴")]		# l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ擵")
l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ擶"),l11l1l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ擷"),l11l1l_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ擸"),l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ擹"),l11l1l_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ擺"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ擻")]
#l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ擼"),l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ擽"),l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩ擾"),l11l1l_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ擿")]
#l1ll1ll1ll11l_l1_ += [l11l1l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ攀"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࠩ攁"),l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࠫ攂"),l11l1l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࠫ攃")]
l1l1lll11l1_l1_ = [l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ攄"),l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ攅"),l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ攆"),l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ攇")]
l1l1lll11l1_l1_ += [l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ攈"),l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ攉"),l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ攊"),l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ攋"),l11l1l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ攌")]
l1l1llll1ll_l1_ = [l11l1l_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ攍"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭攎"),l11l1l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ攏"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ攐"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ攑"),l11l1l_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ攒")]
l1l1llll1ll_l1_ += [l11l1l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ攓"),l11l1l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭攔"),l11l1l_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ攕"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭攖")]
#l1l1llll1ll_l1_ += [l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓࠫ攗"),l11l1l_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ攘")]
l1ll11l1l11_l1_ = [l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ攙"),l11l1l_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ攚"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭攛"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ攜"),l11l1l_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ攝"),l11l1l_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭攞"),l11l1l_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ攟"),l11l1l_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ攠")]	# ,l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ攡")
l1ll11l1l11_l1_ += [l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭攢"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ攣"),l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭攤"),l11l1l_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭攥"),l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ攦"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ攧"),l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ攨")]
#l1ll11l1l11_l1_ += [l11l1l_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭攩"),l11l1l_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ攪"),l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ攫"),l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ攬"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ攭"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ攮"),l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ支")]
l1llll1111111_l1_  = [l11l1l_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ攰"),l11l1l_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ攱"),l11l1l_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ攲"),l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ攳"),l11l1l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ攴"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ攵"),l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ收"),l11l1l_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭攷")]
l1llll1111111_l1_ += [l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ攸"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ改"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ攺"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ攻"),l11l1l_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ攼"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ攽"),l11l1l_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ放"),l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ政"),l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ敀")]
l1llll1111111_l1_ += [l11l1l_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ敁"),l11l1l_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ敂"),l11l1l_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ敃")]		# l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ敄"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ故"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ敆")
l1llll1111111_l1_ += [l11l1l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ敇"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ效"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ敉"),l11l1l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ敊"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ敋"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭敌"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ敍")]
l1llll1111111_l1_ += [l11l1l_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭敎"),l11l1l_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭敏"),l11l1l_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ敐"),l11l1l_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ救"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ敒"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ敓"),l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ敔")]
l1lll11l1111l_l1_  = [l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ敕"),l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ敖"),l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ敗"),l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ敘")]
l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ教"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ敚")]
l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭敛"),l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ敜"),l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ敝")]
l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ敞"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ敟"),l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ敠")]
l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭敡"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ敢"),l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ散")]
#l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭敤"),l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙ࠧ敥")]
#l1lll11l1111l_l1_ += [l11l1l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭敦"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘ࠭敧"),l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡗࡇࡍࡔ࡙ࠧ敨")]
l1lll1l11111l_l1_ = [l11l1l_l1_ (u"ࠬࡓ࠳ࡖࠩ敩"),l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ敪"),l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ敫"),l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ敬"),l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ敭")]		# l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ敮"),l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ敯")
l1ll1111ll1_l1_ = l1llll1111111_l1_+l1lll11l1111l_l1_
l111l111ll1_l1_ = l1llll1111111_l1_+l1lll1l11111l_l1_
l111ll1ll1l_l1_ = l1llll1111111_l1_+l1lll1l11111l_l1_+l1lll11ll1l11_l1_
l1ll1111l1l_l1_ = l1ll1ll1ll11l_l1_+l1l1llll1ll_l1_+l1ll11l1l11_l1_+l1l1lll11l1_l1_
l111l1ll1l1l_l1_ = [ l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ数")
				,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ敱")
				,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ敲")
				,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫ敳")
				,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬ整")
				,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭敵")
				,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭敶")
				,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧ敷")
				,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨ數")
				,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ敹")
				,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ敺")
				,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ敻")
				,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ敼")
				,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ敽")
				,l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ敾")
				,l11l1l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩ敿")
				,l11l1l_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪ斀")
				,l11l1l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭斁")
				,l11l1l_l1_ (u"ࠩࡐࡉࡓ࡛ࡓ࠮ࡕࡋࡓ࡜ࡥࡍࡆࡕࡖࡅࡌࡋࡓ࠮࠳ࡶࡸࠬ斂")
				,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫ斃")
				,l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭斄")
				,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ斅")
				,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ斆")
				#,l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ文")
				#,l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭斈")
				#,l11l1l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ斉")
				#,l11l1l_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ斊")
				#,l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭斋")
				#,l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡈࡇࡗࡣࡑࡇࡔࡆࡕࡗࡣ࡛ࡋࡒࡔࡋࡒࡒࡤࡔࡕࡎࡄࡈࡖࡘ࠳࠱ࡴࡶࠪ斌")
				#,l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ斍")
				#,l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭斎")
				#,l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ斏")
				]
# l11111111lll_l1_ will not show l1111l1ll111_l1_ errors
l1111lllll11_l1_ = [
						l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ斐")
						,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ斑")
						,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ斒")
						,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭斓")
						,l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ斔")
						,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ斕")
						,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ斖")
						,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬ斗")
						,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭斘")
						,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ料")
						,l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ斚")
						]
l11lll111l11_l1_ = [l11l1l_l1_ (u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ斛"),l11l1l_l1_ (u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨ斜"),l11l1l_l1_ (u"ࠨ࠳࠱࠴࠳࠶࠮࠲ࠩ斝"),l11l1l_l1_ (u"ࠩ࠻࠲࠽࠴࠴࠯࠶ࠪ斞"),l11l1l_l1_ (u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠸࠮࠳࠴࠵ࠫ斟"),l11l1l_l1_ (u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠰࠯࠴࠵࠴ࠬ斠")]
l1l1ll1_l1_ = {
			#,l11l1l_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ斡")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ斢")]
			#,l11l1l_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ斣")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡ࡭࡭ࡤࡻࡹ࡮ࡡࡳࡶࡹ࠲࡮ࡸࠧ斤")]
			#,l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ斥")	:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴࡮ࡦࡶࠪ斦")]
			#,l11l1l_l1_ (u"ࠫࡊࡍ࡙࠵ࡄࡈࡗ࡙࠭斧")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ斨")]
			#,l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ斩")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ斪")]
			#,l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ斫")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ斬")]
			#,l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ断")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡨ࡫ࡾࡴ࡯ࡸ࠰࡯࡭ࡻ࡫ࠧ斮")]
			#,l11l1l_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ斯")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠵ࡪࡨࡰࡦࡲ࠮࡮ࡧࠪ新")]
			#,l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ斱")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩࠬ斲"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥࠨ斳")]
			#,l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ斴")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡳࡻࡹ࠴ࡶ࠰ࡺࡷࠬ斵")]
			#,l11l1l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ斶")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡱࠪ斷")]
			#,l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭斸"):[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸࠬ方")]
			#,l11l1l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ斺")	:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠮ࡤࡱࡰࠫ斻")]
			#,l11l1l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭於")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣ࠯ࡵ࡫ࡳࡴ࡬ࡰࡳࡱ࠱ࡳࡳࡲࡩ࡯ࡧࠪ施")]    #	l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡶࡲࡰ࠰ࡦࡳࡲ࠭斾")
			 l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭斿")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ旀")]
			,l11l1l_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ旁")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬ旂")]
			,l11l1l_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ旃")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬ࡹࡤࡱ࠳ࡴࡥࡵࠩ旄")]
			,l11l1l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭旅")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ旆")]
			,l11l1l_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ旇")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ旈")]
			,l11l1l_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ旉")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ旊")]
			,l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ旋")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭旌")]
			,l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ旍")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ旎")]
			,l11l1l_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ族")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ旐")]
			,l11l1l_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ旑")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ旒")]
			,l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ旓")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭旔")]
			,l11l1l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ旕")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ旖")]
			,l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ旗")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡤࡦࡩࡵ࠮ࡤࡱࡰࠫ旘")]
			,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ旙")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡥ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡽ࡯ࡳ࡭ࠪ旚")]
			,l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ旛")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦ࠳࡯࡯ࠨ旜")]
			,l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ旝")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧ旞")]
			,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ旟")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵ࠰ࡦࡳࡲ࠭无")]
			,l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ旡")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳࡮ࡰࡹ࠱ࡧࡴࡳࠧ既")]
			,l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭旣")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ旤"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ日")]
			,l11l1l_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ旦")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧ旧")]
			,l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ旨")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ早")]
			,l11l1l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ旪")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ旫")]
			,l11l1l_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ旬")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࠷ࡢࡤ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪ旭")]
			,l11l1l_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ旮")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫ旯")]
			,l11l1l_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ旰")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡷ࡫ࡳࠫ旱")]
			,l11l1l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ旲")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭旳")]
			,l11l1l_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ旴")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡰࡵࡷࡥ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬ旵")]
			,l11l1l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ时")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡹࡸ࠭旷")]
			,l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ旸")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ旹"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ旺"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ旻"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ旼"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭旽")]
			,l11l1l_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ旾")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩ旿")]
			,l11l1l_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ昀")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ昁")]
			,l11l1l_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ昂")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ昃"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࡫ࡷ࠲ࡱࡿ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ昄")]
			,l11l1l_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ昅")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡥࡷࡵࡺࡢ࠰ࡲࡲࡪ࠭昆")]
			,l11l1l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ昇")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡩࡡ࡮ࠩ昈")]
			,l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ昉")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧ昊")]
			,l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ昋")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷ࠱ࡦࡪࡺࠧ昌")]
			,l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ昍")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࠳ࡹࡨ࠵ࡷ࠱ࡲࡪࡽࡳࠨ明")]
			,l11l1l_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ昏")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪ昐")]
			,l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ昑")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭昒"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ易"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ昔")]
			,l11l1l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ昕")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨ昖")]
			,l11l1l_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ昗")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡴࡶࡤࡨࠫ昘")]
			,l11l1l_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ昙")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬ昚")]
			,l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ昛")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ昜")]
			#,l11l1l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ昝")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ昞"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭星"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ映"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ昡"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ昢"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ昣"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ昤")]
			#,l11l1l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ春")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ昦"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ昧"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ昨"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ昩"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ昪"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ昫"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭昬")]
			#,l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ昭")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ昮"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭是"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ昰"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ昱"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ昲"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ昳"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ昴")]
			#,l11l1l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭昵")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ昶"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ昷"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭昸"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ昹"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ昺"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ昻"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ昼")]
			#,l11l1l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ昽")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ显"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ昿"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ晀"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ晁"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ時"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭晃"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ晄")]
			,l11l1l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ晅")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ晆"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ晇"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ晈"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ晉"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ晊"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭晋"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ晌")]
			,l11l1l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭晍")	:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭晎"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ晏"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ晐"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ晑"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ晒"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ晓"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ晔")]
			,l11l1l_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ晕")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ晖"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ晗"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ晘")]
			,l11l1l_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ晙")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭晚"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ晛"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ晜")]
			,l11l1l_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ晝")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ晞"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪࠩ晟"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ晠")]
			}
class l1lllll1l1lll_l1_(): pass
class l1111llll11l_l1_(l1lllll1l1lll_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l11l1l_l1_ (u"ࠨࠩ晡")
		self.content = l11l1l_l1_ (u"ࠩࠪ晢")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l11l1l_l1_ (u"ࠪࠫ晣")
class l111l1l11l1l_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l1111l111_l1_ = -1
	def onClick(self,l11111ll11ll_l1_):
		if l11111ll11ll_l1_>=9010: self.l11l1111l111_l1_ = l11111ll11ll_l1_-9010
		self.delete()
	def l111l1l111l1_l1_(self,*args):
		#self.getControl(9001).l1l1l11ll1l_l1_(header)
		#self.getControl(9009).l11ll11ll1l1_l1_(text)
		#self.getControl(9010).l1l1l11ll1l_l1_(l1111l1l11l1_l1_)
		#self.getControl(9011).l1l1l11ll1l_l1_(l1lll11ll1l1l_l1_)
		#self.getControl(9012).l1l1l11ll1l_l1_(l1111l1l1lll_l1_)
		self.l1111l1l11l1_l1_,self.l1lll11ll1l1l_l1_,self.l1111l1l1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.l1111ll111l1_l1_,self.l11lll111ll1_l1_ = args[5],args[6]
		self.l1llll11l1l11_l1_,self.l1ll1ll1l11l1_l1_,self.l1lll1111l11l_l1_ = args[7],args[8],args[9]
		if self.l1ll1ll1l11l1_l1_>0 or self.l1lll1111l11l_l1_>0: self.l1lll1lll1ll1_l1_ = True
		else: self.l1lll1lll1ll1_l1_ = False
		self.l1111111l1ll_l1_,self.l111l111l1ll_l1_ = l1lll1111llll_l1_(self.l1111l1l11l1_l1_,self.l1lll11ll1l1l_l1_,self.l1111l1l1lll_l1_,self.header,self.text,self.l1111ll111l1_l1_,self.l11lll111ll1_l1_,self.l1llll11l1l11_l1_,self.l1lll1lll1ll1_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1111111l1ll_l1_)
		self.getControl(9050).setHeight(self.l111l111l1ll_l1_)
		if not self.l1lll11ll1l1l_l1_ and self.l1111l1l11l1_l1_ and self.l1111l1l1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1111111l1ll_l1_,self.l111l111l1ll_l1_
	def l11l11111l11_l1_(self):
		if self.l1ll1ll1l11l1_l1_:
			import threading
			self.l1lll1ll1l111_l1_ = threading.Thread(target=self.l1llll1l11ll1_l1_,args=())
			self.l1lll1ll1l111_l1_.start()
			#self.l1lll1ll1l111_l1_.join()
		else: self.enableButtons()
	def l1llll1l11ll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11l1ll1l1_l1_ in range(1,self.l1ll1ll1l11l1_l1_+1):
			time.sleep(1)
			l1ll1ll1l1ll1_l1_ = int(100*l11l1ll1l1_l1_/self.l1ll1ll1l11l1_l1_)
			self.l1lllll1lllll_l1_(l1ll1ll1l1ll1_l1_)
			if self.l11l1111l111_l1_>0: break
		self.enableButtons()
	def l111lll1ll1l_l1_(self):
		if self.l1lll1111l11l_l1_:
			import threading
			self.l1lll1ll1l11l_l1_ = threading.Thread(target=self.l111111l1111_l1_,args=())
			self.l1lll1ll1l11l_l1_.start()
			#self.l1lll1ll1l11l_l1_.join()
		else: self.enableButtons()
	def l111111l1111_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll1ll1l11l1_l1_)
		for l11l1ll1l1_l1_ in range(self.l1lll1111l11l_l1_-1,-1,-1):
			time.sleep(1)
			l1ll1ll1l1ll1_l1_ = int(100*l11l1ll1l1_l1_/self.l1lll1111l11l_l1_)
			self.l1lllll1lllll_l1_(l1ll1ll1l1ll1_l1_)
			if self.l11l1111l111_l1_>0: break
		if self.l1lll1111l11l_l1_>0: self.l11l1111l111_l1_ = 10
		self.delete()
	def l1lllll1lllll_l1_(self,l1ll1ll1l1ll1_l1_):
		self.l11111111l1l_l1_ = l1ll1ll1l1ll1_l1_
		self.getControl(9020).setPercent(self.l11111111l1l_l1_)
	def enableButtons(self):
		if self.l1111l1l11l1_l1_!=l11l1l_l1_ (u"ࠫࠬ晤"): self.getControl(9010).setEnabled(True)
		if self.l1lll11ll1l1l_l1_!=l11l1l_l1_ (u"ࠬ࠭晥"): self.getControl(9011).setEnabled(True)
		if self.l1111l1l1lll_l1_!=l11l1l_l1_ (u"࠭ࠧ晦"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1111111l1ll_l1_)
		except: pass
		#del self
	l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎࡪࡥࡧࠢࡸࡴࡩࡧࡴࡦࠪࡶࡩࡱ࡬ࠬࡱࡧࡵࡧࡪࡴࡴ࠭ࠬࡤࡶ࡬ࡹࠩ࠻ࠏࠍࠍࠎࡺࡥࡹࡶࠣࡁࠥࡧࡲࡨࡵ࡞࠴ࡢࠓࠊࠊࠋ࡬ࡪࠥࡲࡥ࡯ࠪࡤࡶ࡬ࡹࠩ࠿࠳࠽ࠤࡹ࡫ࡸࡵࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࡥࡷ࡭ࡳ࡜࠳ࡠࠑࠏࠏࠉࡪࡨࠣࡰࡪࡴࠨࡢࡴࡪࡷ࠮ࡄ࠲࠻ࠢࡷࡩࡽࡺࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࡣࡵ࡫ࡸࡡ࠲࡞ࠏࠍࠍࠎࡹࡥ࡭ࡨ࠱ࡴࡪࡸࡣࡦࡰࡷ࠰ࡸ࡫࡬ࡧ࠰ࡷࡩࡽࡺࠠ࠾ࠢࡳࡩࡷࡩࡥ࡯ࡶ࠯ࡸࡪࡾࡴࠎࠌࠌࠍࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡩࡧ࡬࡫࡭ࡺࠠ࠾ࠢࡶࡩࡱ࡬࠮ࡤࡴࡨࡥࡹ࡫ࡓࡩࡱࡺࡍࡲࡧࡧࡦࠪࡶࡩࡱ࡬࠮ࡣࡷࡷࡸࡴࡴ࠰࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳ࠷ࠬࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲ࠷࠲ࡳࡦ࡮ࡩ࠲࡭࡫ࡡࡥࡧࡵ࠰ࡸ࡫࡬ࡧ࠰ࡷࡩࡽࡺࠬࡴࡧ࡯ࡪ࠳ࡶࡲࡰࡨ࡬ࡰࡪ࠲ࡳࡦ࡮ࡩ࠲ࡩ࡯ࡲࡦࡥࡷ࡭ࡴࡴࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣࡼ࡯ࡤࡵࡪ࠯ࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮ࡴࡶ࡬ࡱࡪࡵࡵࡵ࠮ࡶࡩࡱ࡬࠮ࡤ࡮ࡲࡷࡪࡺࡩ࡮ࡧࡲࡹࡹ࠯ࠍࠋࠋࠌࡷࡪࡲࡦ࠯ࡷࡳࡨࡦࡺࡥࡑࡴࡲ࡫ࡷ࡫ࡳࡴࡄࡤࡶ࠭ࡶࡥࡳࡥࡨࡲࡹ࠯ࠍࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡧ࡫࡯ࡩࡳࡧ࡭ࡦ࠮ࡶࡩࡱ࡬࠮ࡪ࡯ࡤ࡫ࡪࡥࡨࡦ࡫ࡪ࡬ࡹࠓࠊࠊࠤࠥࠦ晧")
class l1llll1l1llll_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11l1l_l1_ (u"ࠨࠩ晨")
		if l11llll111ll_l1_(l11l1l_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ晩")) or not l11llll111ll_l1_(l11l1l_l1_ (u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫ晪")): self.status = l11l1l_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ晫")
	def onPlayBackStopped(self):
		self.status=l11l1l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ晬")
	def onPlayBackStarted(self):
		self.status = l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ晭")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11l1l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ普")
	def onPlayBackEnded(self):
		self.status = l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ景")
class l1llll11l1ll_l1_():
	def __init__(self,l1ll_l1_=False,l1lll1llll111_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1lll1llll111_l1_ = l1lll1llll111_l1_
		self.l111l1l1lll1_l1_,self.l11l111l1ll1_l1_ = [],[]
		self.l11111ll1l11_l1_,self.l1llllll1ll11_l1_ = {},{}
		self.l1111lll11ll_l1_ = []
		self.l11111l1lll1_l1_,self.l1ll1llllllll_l1_,self.l111lllllll1_l1_ = {},{},{}
	def l111l11ll111_l1_(self,id,func,*args):
		id = str(id)
		self.l11111ll1l11_l1_[id] = l11l1l_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ晰")
		if self.l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠪࠫ晱"),id)
		# l1l11l1lll11_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1l11l1lll11_l1_ 2 & 3
		import threading
		l11l1111l1ll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1111lll11ll_l1_.append(l11l1111l1ll_l1_)
		#l11l1111l1ll_l1_.start()
		return l11l1111l1ll_l1_
	def start_new_thread(self,id,func,*args):
		l11l1111l1ll_l1_ = self.l111l11ll111_l1_(id,func,*args)
		l11l1111l1ll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l11111l1lll1_l1_[id] = time.time()
		#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ晲"),l11l1l_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡩࡥ࠼ࠣࠫ晳")+id)
		try:
			#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ晴"),l11l1l_l1_ (u"ࠧࡆࡏࡄࡈ࠿ࡀࠠࠨ晵")+str(func))
			self.l1llllll1ll11_l1_[id] = func(*args)
			if l11l1l_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ晶") in str(func) and not self.l1llllll1ll11_l1_[id].succeeded:
				l111111ll1ll_l1_(l11l1l_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠࡵࡪࡵࡩࡦࡪࡥࡥࠢࡒࡔࡊࡔࡕࡓࡎࠣࡪࡦ࡯࡬ࠨ晷"))
			self.l111l1l1lll1_l1_.append(id)
			self.l11111ll1l11_l1_[id] = l11l1l_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ晸")
			#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ晹"),l11l1l_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠠࡪࡦ࠽ࠤࠬ智")+id)
		except Exception as err:
			#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭晻"),l11l1l_l1_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡪࡦ࠽ࠤࠬ晼")+id)
			if self.l1lll1llll111_l1_:
				l1lll11111ll_l1_ = traceback.format_exc()
				sys.stderr.write(l1lll11111ll_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l111l1ll1_l1_.append(id)
			self.l11111ll1l11_l1_[id] = l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ晽")
		self.l1ll1llllllll_l1_[id] = time.time()
		self.l111lllllll1_l1_[id] = self.l1ll1llllllll_l1_[id] - self.l11111l1lll1_l1_[id]
	def l1lll1lll1lll_l1_(self):
		for proc in self.l1111lll11ll_l1_:
			proc.start()
	def l1ll1ll1ll1ll_l1_(self):
		while l11l1l_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ晾") in list(self.l11111ll1l11_l1_.values()): time.sleep(1.000)
def l1llll111l111_l1_():
	l1lll1l1ll111_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ晿"))
	l1111l11lll1_l1_ = True
	if l1lll1l1ll111_l1_==addon_version:
		status = l11l1l_l1_ (u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧ暀")
		l1111l11lll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11l1l_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ暁")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11l1l_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭暂")
	else:
		status = l11l1l_l1_ (u"ࠧࡇࡗࡏࡐࡤ࡛ࡐࡅࡃࡗࡉࠬ暃")
		l111ll11l111_l1_ = [l11l1l_l1_ (u"ࠨ࠺࠱࠹࠳࠶ࠧ暄"),l11l1l_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠲࠱࠵࠾࠭暅"),l11l1l_l1_ (u"ࠪ࠶࠵࠸࠱࠯࠳࠴࠲࠷࠺ࡡࠨ暆"),l11l1l_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠶࠳࠹࠰ࠨ暇"),l11l1l_l1_ (u"ࠬ࠸࠰࠳࠴࠱࠴࠷࠴࠰࠳ࠩ暈"),l11l1l_l1_ (u"࠭࠲࠱࠴࠵࠲࠶࠶࠮࠳࠴ࠪ暉"),l11l1l_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠳࠯࠲࠹ࠫ暊"),l11l1l_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠰࠶࠰࠴࠺ࠬ暋"),l11l1l_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠸࠱࠴࠻࠭暌")]
		l1llllll1111l_l1_ = l111ll11l111_l1_[-1]
		l1111l1ll1ll_l1_ = l1ll1ll1l1l1l_l1_(l1llllll1111l_l1_)
		l1lllll1111ll_l1_ = l1ll1ll1l1l1l_l1_(addon_version)
		if l1lllll1111ll_l1_>l1111l1ll1ll_l1_:
			status = l11l1l_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ暍")
			l11l1l_l1_ (u"ࠦࠧࠨࠍࠋࠋࠌࠍ࡫࡯࡬ࡦࡵࠣࡁࠥࡵࡳ࠯࡮࡬ࡷࡹࡪࡩࡳࠪࡤࡨࡩࡵ࡮ࡤࡣࡦ࡬ࡪ࡬࡯࡭ࡦࡨࡶ࠮ࠓࠊࠊࠋࠌࡪ࡮ࡲࡥࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡫࡯࡬ࡦࡵ࠯ࡶࡪࡼࡥࡳࡵࡨࡁ࡙ࡸࡵࡦࠫࠐࠎࠎࠏࠉࡧࡱࡵࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࠦࡩ࡯ࠢࡩ࡭ࡱ࡫ࡳ࠻ࠏࠍࠍࠎࠏࠉࡪࡨࠣࠫࡩࡧࡴࡢࡡࠪࠤ࡮ࡴࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢࡤࡲࡩࠦࠧ࠯ࡦࡥࠫࠥ࡯࡮ࠡࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠽ࠑࠏࠏࠉࠊࠋࠌࡳࡱࡪ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦࡥࠨ࠯ࠬࡂ࠭ࡡ࠴ࡤࡣࠩ࠯ࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࠦ࠽ࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡡ࠰࡞ࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠠ࠾࡙ࠢࡉࡗ࡙ࡉࡐࡐࡢࡇࡔࡓࡐࡂࡔࡈࡣࡕࡇࡒࡔࡇࡕࠬࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠫࠐࠎࠎࠏࠉࠊࠋ࡬ࡪࠥ࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡࡠࠩࠣ࡭ࡳࠦࡦࡪ࡮ࡨࡲࡦࡳࡥ࠻ࠏࠍࠍࠎࠏࠉࠊࠋ࡬ࡪࠥࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰࡢࡧࡴࡳࡰࡢࡴࡨࡂࡂࡲࡡࡴࡶࡩࡹࡱࡲ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࡠࡥࡲࡱࡵࡧࡲࡦ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࡴࡲࡤࡠࡦࡥࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡤࡨࡩࡵ࡮ࡤࡣࡦ࡬ࡪ࡬࡯࡭ࡦࡨࡶ࠱࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠩࠎࠌࠌࠍࠎࠏࠉࠊࠋࡷࡶࡾࡀࠍࠋࠋࠌࠍࠎࠏࠉࠊࠋ࡬ࡪࠥࡵ࡬ࡥࡡࡧࡦ࡫࡯࡬ࡦࠣࡀࡱࡦ࡯࡮ࡠࡦࡥࡪ࡮ࡲࡥ࠻ࠢࡲࡷ࠳ࡸࡥ࡯ࡣࡰࡩ࠭ࡵ࡬ࡥࡡࡧࡦ࡫࡯࡬ࡦ࠮ࡰࡥ࡮ࡴ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠎࠌࠌࠍࠎࠏࠉࠊࠋࠌࡷࡹࡧࡴࡶࡵࠣࡁࠥ࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭ࠍࠋࠋࠌࠍࠎࠏࠉࠊࠋࡥࡶࡪࡧ࡫ࠎࠌࠌࠍࠎࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠍࠎࠨࠢࠣ暎")
	return status,l1111l11lll1_l1_
def l111111ll11l_l1_():
	l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡓࡁࡊࡐࡐࡉࡓ࡛ࠧ暏")
	succeeded,l11111lllll1_l1_,l111lll111ll_l1_ = True,False,False
	l1l1lllllll_l1_ = EXTRACT_KODI_PATH(addon_path)
	type,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,mode,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,text,context,l1ll1l1lll1_l1_ = l1l1lllllll_l1_
	l1lll11l11ll1_l1_ = type,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,mode,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,text,l11l1l_l1_ (u"࠭ࠧ暐"),l1ll1l1lll1_l1_
	l1lll1ll1lll1_l1_ = int(mode)
	l111l111ll1l_l1_ = int(l1lll1ll1lll1_l1_%10)
	l111ll11111_l1_ = int(l1lll1ll1lll1_l1_/10)
	l11lll11111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ暑"))
	l1111l1111ll_l1_,l1111l11lll1_l1_ = l1llll111l111_l1_()
	if l1111l11lll1_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ暒"),l11l1l_l1_ (u"ࠩࠪ暓"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭暔"),l11l1l_l1_ (u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫ暕")+addon_version)
		settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨ暖"),l11l1l_l1_ (u"࠭ࠧ暗"))
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧ暘"),l11l1l_l1_ (u"ࠨࠩ暙"))
		settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫ暚"),l11l1l_l1_ (u"ࠪࠫ暛"))
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳ࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ暜"),l11l1l_l1_ (u"ࠬ࠭暝"))
		settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ暞"),l11l1l_l1_ (u"ࠧࠨ暟"))
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ暠"),l11l1l_l1_ (u"ࠩࠪ暡"))
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ暢"),l11l1l_l1_ (u"ࠫࠬ暣"))
		settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ暤"),l11l1l_l1_ (u"࠭ࠧ暥"))
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ暦"),l11l1l_l1_ (u"ࠨࠩ暧"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ暨"),l11l1l_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭暩"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ暪"),l11l1l_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭暫"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ暬"),l11l1l_l1_ (u"ࠧࡂࡗࡗࡌࠬ暭"))
		if not l11lll11111l_l1_: settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ暮"),l11l1l_l1_ (u"ࠩࠪ暯"))
		#l1lll1l1ll111_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ暰"))
		#if l1lll1l1ll111_l1_:
		#	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ暱"),l11l1l_l1_ (u"ࠬ࠭暲"))
		#	xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ暳"))
		#	return
		#l11llllll111_l1_([main_dbfile])
		import l1l1l1lll1ll_l1_
		if l1111l1111ll_l1_==l11l1l_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ暴"):
			LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ暵"),l11l1l_l1_ (u"ࠩ࠱ࠤࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ暶")+addon_path+l11l1l_l1_ (u"ࠪࠤࡢ࠭暷"))
			DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ暸"),l11l1l_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭暹"))
			for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ暺"),l11l1l_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ暻")+str(l1l11l1l11l_l1_))
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ暼"),l11l1l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ暽")+str(l1l11l1l11l_l1_))
		else:
			LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ暾"),l11l1l_l1_ (u"ࠫ࠳ࠦࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡇࡗࡏࡐ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ暿")+addon_path+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ曀"))
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ曁"),l11l1l_l1_ (u"ࠧࠨ曂"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ曃"),l11l1l_l1_ (u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ曄"))
			l11llllll111_l1_()
			FIX_ALL_DATABASES(False)
			l111l11lll1l_l1_ = l1l11llll11_l1_(32)
			l1l1l1lll1ll_l1_.l1l11l1l11ll_l1_()
			l1l1l1lll1ll_l1_.l1l111l11lll_l1_(l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ曅"),False)
			l1l1l1lll1ll_l1_.l1l111l11lll_l1_(l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ曆"),False)
			l1l1l1lll1ll_l1_.l1l11l11lll1_l1_(False)
			l1l1l1lll1ll_l1_.l1l11l11111l_l1_(False)
			l1l1l1lll1ll_l1_.l1l11l1l1111_l1_(l11l1l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ曇"),l11l1l_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭曈"),False)
			l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡵࡴࡼ࠾ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࡫࡯࡬ࡦ࠴ࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡺࡹࡥࡳࡨࡲࡰࡩ࡫ࡲ࠭ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ࠱࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ࠰ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ࠲ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳ࠢࡀࠤࡽࡨ࡭ࡤࡣࡧࡨࡴࡴ࠮ࡂࡦࡧࡳࡳ࠮ࡩࡥ࠿ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ࠭ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠷࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡰࡵࡤࡪࡱࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡵࡺࡧ࡬ࡪࡶࡼ࠲ࡦࡹ࡫ࠨ࠮ࠪࡸࡷࡻࡥࠨࠫࠐࠎࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠋࠌࠦࠧࠨ曉")
			try:
				l111l1llll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ曊"),l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭曋"),l11l1l_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ曌"),l11l1l_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ曍"))
				l1ll1llll11l1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ曎"))
				l1ll1llll11l1_l1_.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡤࡹࡹࡵ࡟ࡱ࡫ࡦ࡯ࠬ曏"),l11l1l_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭曐"))
			except: pass
			try:
				l111l1llll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ曑"),l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭曒"),l11l1l_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ曓"),l11l1l_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ曔"))
				l1ll1llll11l1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ曕"))
				l1ll1llll11l1_l1_.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡹ࡭ࡩ࡫࡯ࡠࡳࡸࡥࡱ࡯ࡴࡺࠩ曖"),l11l1l_l1_ (u"ࠧ࠴ࠩ曗"))
			except: pass
			try:
				l111l1llll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ曘"),l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭曙"),l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ曚"),l11l1l_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ曛"))
				l1ll1llll11l1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ曜"))
				l1ll1llll11l1_l1_.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡖࡘࡗࡋࡁࡎࡕࡈࡐࡊࡉࡔࡊࡑࡑࠫ曝"),l11l1l_l1_ (u"ࠧ࠳ࠩ曞"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ曟"),l11l1l_l1_ (u"ࠩࠪ曠"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭曡"),l11l1l_l1_ (u"ࠫสึวࠡๅ้ฮࠥะำหะา้ࠥิฯๆหࠣไࡎࡖࡔࡗࠢส่๊๎ฬ้ัฬࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦแิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢอ่็อฦ๋ษࠣฬั๊ศࠡ็็ๅฬะࠠแࡋࡓࡘ࡛ࠦฬะ์าอࠬ曢"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1l1111llll_l1_):
			#	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭曣"),l11l1l_l1_ (u"࠭ࠧ曤"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ曥"),l11l1l_l1_ (u"ࠨวำห้ࠥๆหࠢอืฯิฯๆࠢัำ๊ฯࠠแࡏ࠶࡙ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ曦"))
			#	import l1l111ll1l1_l1_
			#	l1l111ll1l1_l1_.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11l111llll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l11ll1l11l_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭曧"),addon_version)
		l1l1l1lll1ll_l1_.l1l111ll11ll_l1_(False)
		#return
	#l11l1l1lll_l1_ = l11l1l1111_l1_()
	l1ll11l1lll1_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ曨"))
	l1ll11l1lll1_l1_ = l1ll11l1lll1_l1_.replace(ltr,l11l1l_l1_ (u"ࠫࠬ曩")).replace(rtl,l11l1l_l1_ (u"ࠬ࠭曪"))
	if l1lll1ll1lll1_l1_==260: message = l11l1l_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ曫")+addon_version+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ曬")+kodi_release+l11l1l_l1_ (u"ࠨࠢࡠࠫ曭")
	else:
		l111llll1ll1_l1_ = l1llll_l1_(addon_path).replace(l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ曮"),l11l1l_l1_ (u"ࠪࠫ曯")).replace(l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ曰"),l11l1l_l1_ (u"ࠬ࠭曱"))
		l111llll1ll1_l1_ = l111llll1ll1_l1_.replace(l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ曲"),l11l1l_l1_ (u"ࠧࠨ曳")).strip(l11l1l_l1_ (u"ࠨࠢࠪ更"))
		l111llll1ll1_l1_ = l111llll1ll1_l1_.replace(l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ曵"),l11l1l_l1_ (u"ࠪࠤࠬ曶")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ曷"),l11l1l_l1_ (u"ࠬࠦࠧ書")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ曹"),l11l1l_l1_ (u"ࠧࠡࠩ曺"))
		message = l11l1l_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ曻")+l1ll11l1lll1_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ曼")+mode+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ曽")+l111llll1ll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ曾")
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ替"),LOGGING(l1ll1_l1_)+message)
	#text = text.replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ最"),l11l1l_l1_ (u"ࠧࠨ朁"))
	l1l11ll11l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ朂"))
	l11l1l1lll_l1_ = RESTORE_PATH_NAME(l1ll11l1lll1_l1_)
	l111l1lll1ll_l1_ = RESTORE_PATH_NAME(l111l1lll1ll_l1_)
	l111111lll1l_l1_ = [0,15,17,19,26,34,50,53]
	l1llll11l11l1_l1_ = [0,15,17,19,26,34,50,53]
	l11l111111l1_l1_ = l111ll11111_l1_ not in l1llll11l11l1_l1_
	l1ll1ll1lll1l_l1_ = l111ll11111_l1_ in [23,28,71,72]
	l1llll1ll1l1l_l1_ = l1lll1ll1lll1_l1_ in [265,270]
	l1lllllll11ll_l1_ = (l11l111111l1_l1_ or l1ll1ll1lll1l_l1_) and not l1llll1ll1l1l_l1_
	l11l1111ll11_l1_ = l1l11ll11l_l1_!=l11l1l_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ會") and (l1l11ll11l_l1_!=l11l1l_l1_ (u"ࠪࠫ朄") or context==l11l1l_l1_ (u"ࠫࠬ朅"))
	l1lll1lll1l11_l1_ = l11l1l_l1_ (u"ࠬࡺࡹࡱࡧࡀࠫ朆") in l1l11ll11l_l1_
	l1111ll1ll1_l1_ = l1lll1ll1lll1_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l111l111ll1l_l1_==9 or l1lll1ll1lll1_l1_ in [145,516,523]
	l111llll1111_l1_ = not l1111ll1ll1_l1_
	l111l1l1l1ll_l1_ = not SEARCH
	l1111111lll1_l1_ = l11l1l1lll_l1_ in [l11l1l_l1_ (u"࠭ࠧ朇"),l11l1l_l1_ (u"ࠧ࠯࠰ࠪ月")]
	l11l111ll11l_l1_ = l1111111lll1_l1_ or l111llll1111_l1_
	l11111l11111_l1_ = l1111111lll1_l1_ or l111l1l1l1ll_l1_ or l1lll1lll1l11_l1_
	l1lll111111ll_l1_ = l1lll1ll1lll1_l1_ not in [260,265,270,330,540]
	if l11lll11111l_l1_: l1111l1l11ll_l1_ = SEARCH or l1111ll1ll1_l1_
	else: l1111l1l11ll_l1_ = True
	l1l1l1l1l1_l1_ = l111ll11111_l1_ in [74,75]
	l1111ll11l11_l1_ = not l1l1l1l1l1_l1_ and not l1ll1ll1lll1l_l1_
	l1111l11111l_l1_ = l11l111ll11l_l1_ and l11111l11111_l1_ and l1lll111111ll_l1_ and l1111l1l11ll_l1_ and l1111ll11l11_l1_
	l1llll11l11ll_l1_ = l1lll111111ll_l1_ and l1111l1l11ll_l1_ and l1111ll11l11_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ有"),l11l1l_l1_ (u"ࠩࠪ朊"),l11l1l_l1_ (u"ࠪࠫ朋"),type+l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ朌")+l1l11ll11l_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ服")+str(l1llll11l11ll_l1_))
	if 1 and l11l1111ll11_l1_ and l1111l11111l_l1_:
		l1llllll1l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ朎"),l11l1l_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ朏"),l1lll11l11ll1_l1_)
		if l1llllll1l11l_l1_:
			#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠨࠩ朐"),l11l1l_l1_ (u"ࠩࡵࡩࡦࡪࡩ࡯ࡩࠣࡧࡦࡩࡨࡦࠩ朑"),l11l1l_l1_ (u"ࠪࠫ朒"),100,False)
			#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ朓"),l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠠࠡࠢࡕࡩࡦࡪࡩ࡯ࡩࠣࡧࡦࡩࡨࡦࡦࠣࡱࡪࡴࡵࠨ朔"))
			if 1 and l1lll1lll1l11_l1_:
				#xbmcgui.Dialog().notification(l11l1l_l1_ (u"࠭ࠧ朕"),l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫ࡿࡩ࡯ࡩࠣࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭朖"),l11l1l_l1_ (u"ࠨࠩ朗"),100,False)
				l111lll1l1ll_l1_ = []
				import l11l11ll11l_l1_,FAVORITES
				l1llll1llll1l_l1_ = l11l11ll11l_l1_.l11l11lll1l_l1_
				l111lll11lll_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l11111ll1l1l_l1_ = l1l11ll11l_l1_
				l111l1l11ll1_l1_,l111l1l1llll_l1_,l111lll1lll_l1_,l1lll1ll11lll_l1_,l1lll111l1111_l1_,l111111l1ll1_l1_,l111l1ll1111_l1_,l1llll11ll11l_l1_,l111111l11l1_l1_ = EXTRACT_KODI_PATH(l11111ll1l1l_l1_)
				l1llll1llllll_l1_ = l111l1l11ll1_l1_,l111l1l1llll_l1_,l111lll1lll_l1_,l1lll1ll11lll_l1_,l1lll111l1111_l1_,l111111l1ll1_l1_,l111l1ll1111_l1_,l11l1l_l1_ (u"ࠩࠪ朘"),l111111l11l1_l1_
				#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ朙"),str(l1llll1llllll_l1_))
				for l1llll11111l1_l1_ in l1llllll1l11l_l1_:
					l1lll1l111ll1_l1_ = l1llll11111l1_l1_[l11l1l_l1_ (u"ࠫࡲ࡫࡮ࡶࡋࡷࡩࡲ࠭朚")]
					#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭望"),str(l1lll1l111ll1_l1_))
					if l1lll1l111ll1_l1_==l1llll1llllll_l1_ or l1llll11111l1_l1_[l11l1l_l1_ (u"࠭࡭ࡰࡦࡨࠫ朜")] in [265,270]:
						l1llll11111l1_l1_ = GET_LIST_ITEM(l1lll1l111ll1_l1_,l1llll1llll1l_l1_,l111lll11lll_l1_)
						if l1llll11111l1_l1_[l11l1l_l1_ (u"ࠧࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࠪ朝")]:
							#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠨࠩ朞"),l11l1l_l1_ (u"ࠩࡸࡴࡩࡧࡴࡪࡰࡪࠤࡨࡵ࡮ࡵࡧࡻࡸࠬ期"),l11l1l_l1_ (u"ࠪࠫ朠"),100,False)
							l1lll1l1ll11l_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111lll11lll_l1_,l1lll1l111ll1_l1_,l1llll11111l1_l1_[l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬ朡")])
							#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭朢"),str(l1lll1l1ll11l_l1_))
							#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ朣"),str(l1llll11111l1_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭朤")]))
							l1llll11111l1_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ朥")] = l1lll1l1ll11l_l1_+l1llll11111l1_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ朦")]
					l111lll1l1ll_l1_.append(l1llll11111l1_l1_)
				settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ朧"),l11l1l_l1_ (u"ࠫࠬ木"))
				if type==l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朩"): WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࠫ未"),l1lll11l11ll1_l1_,l111lll1l1ll_l1_,REGULAR_CACHE)
			else: l111lll1l1ll_l1_ = l1llllll1l11l_l1_
			if type==l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ末") and l11l1l1lll_l1_!=l11l1l_l1_ (u"ࠨ࠰࠱ࠫ本") and l1lllllll11ll_l1_: l1111l11ll1l_l1_()
			l111l1lll11l_l1_ = CREATE_KODI_MENU(l1lll11l11ll1_l1_,l111lll1l1ll_l1_,succeeded,l11111lllll1_l1_,l111lll111ll_l1_)
			#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠩࠪ札"),l11l1l_l1_ (u"ࠪࡧࡷ࡫ࡡࡵ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠪ朮"),l11l1l_l1_ (u"ࠫࠬ术"),100,False)
			return
	elif type==l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朰") and l1l11ll11l_l1_==l11l1l_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ朱") and l1llll11l11ll_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ朲"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࠣࠤࠥࡊࡥ࡭ࡧࡷ࡭ࡳ࡭ࠠࡰ࡮ࡧࠤࡨࡧࡣࡩࡧࡧࠤࡲ࡫࡮ࡶࠩ朳"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠧ朴"),l1lll11l11ll1_l1_)
	#context = l11l1l_l1_ (u"ࠪࠫ朵")
	if l11l1l_l1_ (u"ࠫࡤ࠭朶") in context: l1llll11l1l1l_l1_,l111ll1l1lll_l1_ = context.split(l11l1l_l1_ (u"ࠬࡥࠧ朷"),1)
	else: l1llll11l1l1l_l1_,l111ll1l1lll_l1_ = context,l11l1l_l1_ (u"࠭ࠧ朸")
	if l1llll11l1l1l_l1_ in [l11l1l_l1_ (u"ࠧ࠲ࠩ朹"),l11l1l_l1_ (u"ࠨ࠴ࠪ机"),l11l1l_l1_ (u"ࠩ࠶ࠫ朻"),l11l1l_l1_ (u"ࠪ࠸ࠬ朼"),l11l1l_l1_ (u"ࠫ࠺࠭朽")] and l111ll1l1lll_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ朾") l11l111lll_l1_ l1lll11l11l1l_l1_ l1ll1llll1lll_l1_ is no addon_handle l1l111l1l_l1_ to l111ll111l11_l1_ for l1lllllll1ll1_l1_ directory
		#l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠩ朿") l11l111lll_l1_ to open a menu list using l1lll11l1l1l1_l1_ addon_path
		#xbmc.executebuiltin(l11l1l_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ杀")+sys.argv[0]+addon_path.split(l11l1l_l1_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀࠫ杁"))[0]+l11l1l_l1_ (u"ࠩࠩࡧࡴࡴࡴࡦࡺࡷࡁ࠵࠭杂")+l11l1l_l1_ (u"ࠥ࠭ࠧ权"))
		#xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ杄")+addon_id+l11l1l_l1_ (u"ࠬ࠵࠿ࡵࡧࡻࡸࡂࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠩࠨ杅"))
		# l11111ll1l_l1_ not remove addon_path .. it is needed to update l1lll1l1ll1l1_l1_ status
		settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ杆"),addon_path)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ杇"))
		return
	elif l1llll11l1l1l_l1_==l11l1l_l1_ (u"ࠨ࠸ࠪ杈"):
		if l111ll1l1lll_l1_==l11l1l_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ杉"): l1lllll1_l1_(l11l1l_l1_ (u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪ杊"),l11l1l_l1_ (u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫ杋"))
		elif l111ll1l1lll_l1_==l11l1l_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠬ杌"): mode = 334
		results = l111l11l1ll_l1_(type,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,mode,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,text,context,l1ll1l1lll1_l1_)
		xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ杍"))
		return
	elif context==l11l1l_l1_ (u"ࠧ࠸ࠩ李"):
		import l1lll111lll_l1_
		l1lll111lll_l1_.l1l1lllll11_l1_()
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ杏"))
		return
	elif context==l11l1l_l1_ (u"ࠩ࠻ࠫ材"):
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ村")+addon_id+l11l1l_l1_ (u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ杒")+str(mode)+l11l1l_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ杓"))
		return
	elif context==l11l1l_l1_ (u"࠭࠹ࠨ杔"):
		# l1llll111111l_l1_ update the l1ll1lll11l1l_l1_ menu
		#results = l111l11l1ll_l1_(type,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,mode,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,text,context,l1ll1l1lll1_l1_)
		# l1llll111111l_l1_ update the l1111lll1lll_l1_ menu
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ杕"),l11l1l_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ杖"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭杗"))
		return
	if settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ杘")) not in [l11l1l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ杙"),l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ杚"),l11l1l_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ杛")]: settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ杜"),l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭杝"))
	if not settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ杞")): settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ束"),l11lll111l11_l1_[0])
	l111111111ll_l1_ = l111111ll111_l1_(settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ杠")))
	l111111111ll_l1_ = 0 if not l111111111ll_l1_ else int(l111111111ll_l1_)
	if not l111111111ll_l1_ or now-l111111111ll_l1_<=0 or now-l111111111ll_l1_>REGULAR_CACHE:
		#l11llllll111_l1_([main_dbfile,iptv1_dbfile,iptv2_dbfile])
		#settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ条"),l11l1l_l1_ (u"࠭ࠧ杢"))
		l11l11l1l11_l1_ = l11l11l11ll_l1_(False)
	l111llllllll_l1_ = l111111ll111_l1_(settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ杣")))
	l111llllllll_l1_ = 0 if not l111llllllll_l1_ else int(l111llllllll_l1_)
	l111l1l1ll11_l1_ = l111111ll111_l1_(settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ杤")))
	l111l1l1ll11_l1_ = 0 if not l111l1l1ll11_l1_ else int(l111l1l1ll11_l1_)
	if not l111llllllll_l1_ or not l111l1l1ll11_l1_ or now-l111l1l1ll11_l1_<0 or now-l111l1l1ll11_l1_>l111llllllll_l1_:
		auth = 1
		if not l11llll111ll_l1_(l11l1l_l1_ (u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪ来")):
			# https://www.l11111l1l1l1_l1_.com/l1lll11l1llll_l1_/l111l1111ll1_l1_
			# unescapeHTML(l11l1l_l1_ (u"ࠪࠤࠫࠩࡸ࠳࠸࠶ࡆࡀࠦࠦࠤࡺ࠵࠻࠶ࡊ࠻ࠡࠨࠦࡼ࠷࠼࠲ࡂ࠽ࠣࠪࠨࡾ࠲࠷࠵ࡅ࠿ࠬ杦"))
			#l1lllll11111l_l1_ = l11l1l_l1_ (u"ࠫ⹀ࠦ⼝ࠡࠢ⾍ࠤࠥ⸰ࠠ⸼ࠩ杧")
			#l1lllll111111_l1_ = l11l1l_l1_ (u"ࠬ⹁ࠠ⼞ࠢࠣ⾏ࠥࠦ⸪ࠡ⸽ࠪ杨")
			l1l11l1111ll_l1_ = l1l11l1l11l1_l1_(False)
			if len(l1l11l1111ll_l1_)>1:
				LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭杩"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ杪")+addon_path+l11l1l_l1_ (u"ࠨࠢࡠࠫ杫"))
				id,l1l1111l1lll_l1_,l1l11lll1l11_l1_,l11l1ll1lll_l1_,l11ll1l11l11_l1_,reason = l1l11l1111ll_l1_[0]
				#if l11l1l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ杬") in reason: l1llll111l1ll_l1_,l1llll111ll11_l1_,l1llll111ll1l_l1_ = reason.split(l11l1l_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ杭"),2)
				#else: l1llll111l1ll_l1_,l1llll111ll11_l1_,l1llll111ll1l_l1_ = reason,reason,reason
				l11llll1l1l1_l1_,l1l11ll11111_l1_ = l11l1ll1lll_l1_.split(l11l1l_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ杮"))
				del l1l11l1111ll_l1_[0]
				l1lll1ll1llll_l1_ = random.sample(l1l11l1111ll_l1_,1)
				id,l1l1111l1lll_l1_,l1l11lll1l11_l1_,l11l1ll1lll_l1_,l11ll1l11l11_l1_,reason = l1lll1ll1llll_l1_[0]
				l1l11lll1l11_l1_ = l11l1l_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠺ࠡࠩ杯")+id+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ杰")+l1l11lll1l11_l1_
				l1111l1l11l1_l1_,l1lll11ll1l1l_l1_ = l11l1ll1lll_l1_,l11ll1l11l11_l1_
				l11l1111_l1_ = [l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l11ll1l11l1l_l1_]
				choice = -9
				while choice<0:
					l111l1ll1l11_l1_ = random.sample(l11l1111_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠧࠨ東"),l111l1ll1l11_l1_[0],l111l1ll1l11_l1_[1],l111l1ll1l11_l1_[2],l11llll1l1l1_l1_,l1l11lll1l11_l1_,5,60)
					if choice==10: break
					if choice>=0 and l111l1ll1l11_l1_[choice]==l11l1111_l1_[1]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࠩ杲"),l11l1l_l1_ (u"ࠩࠪ杳"),l11l1l_l1_ (u"ࠪ฽ํีษࠨ杴"),l11l1l_l1_ (u"ࠫࠬ杵"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ杶"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ杷")+reason,20)
						if choice>=0: choice = -9
					elif choice>=0 and l111l1ll1l11_l1_[choice]==l11l1111_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠧࠨ杸"),l11l1l_l1_ (u"ࠨࠩ杹"),l11ll1l11l1l_l1_,l11l1l_l1_ (u"ࠩࠪ杺"),l11llll1l1l1_l1_,l1l11lll1l11_l1_+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ杻")+l11l1111_l1_[0]+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭杼"),30)
					if choice==-1: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭杽"),l11l1l_l1_ (u"࠭ࠧ松"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ板"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠาึ๎ฬࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩ枀"))
				auth = 1
			else: auth = 0
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ极"),l11l1l_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ枂"),auth,PERMANENT_CACHE)
	# l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ枃")	l111ll111l11_l1_ file to read/write the l111l1l1l1l_l1_ menu list
	# l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ构")		no l1111l1l1l1_l1_ l1lll11l11l11_l1_ to the l111l1l1l1l_l1_ menu list
	l11l1l_l1_ (u"ࠨࠢࠣࠏࠍࠍࡘࡏࡔࡆࡕࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡏࡔࡆࡕࡢࡑࡔࡊࡅࡔࠢࡤࡲࡩࠦ࡭ࡰࡦࡨ࠵ࡂࡃ࠹ࠎࠌࠌࡓ࡙ࡎࡅࡓࡡࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡱࡴࡪࡥ࠱ࠢ࡬ࡲࠥࡡ࠱࠵࠷࠯࠹࠶࠼ࠬ࠶࠴࠶ࡡࠒࠐࠉࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡌࡘࡊ࡙࡟ࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࡯ࡳࠢࡒࡘࡍࡋࡒࡠࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙ࠍࠋࠋࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡱࡴࡪࡥ࠳࠿ࡀ࠵࠻ࠦࡡ࡯ࡦࠣࡱࡴࡪࡥ࠱ࠣࡀ࠵࠻࠶ࠍࠋࠋ࡜ࡓ࡚࡚ࡕࡃࡇࡢࡑࡊࡔࡕࡔࠢࡀࠤࡲࡵࡤࡦ࠲ࠣ࡭ࡳ࡛ࠦ࠲࠶࠷ࡡࠒࠐࠉࠤࡰࡤࡱࡪࡥࠠ࠾ࠢࡆࡐࡊࡇࡎࡠࡏࡈࡒ࡚ࡥࡌࡂࡄࡈࡐ࠭ࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉ࡯ࡣࡰࡩࡤࠦ࠽ࠡࡔࡈࡗ࡙ࡕࡒࡆࡡࡓࡅ࡙ࡎ࡟ࡏࡃࡐࡉ࠭ࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉࡓࡇࡐࡉࡒࡈࡅࡓࡡࡕࡉࡘ࡛ࡌࡕࡕࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡳࡷࠦࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗࠥࡵࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࡡࡐࡉࡓ࡛ࡓࠎࠌࠌ࡭࡫ࠦࡒࡆࡏࡈࡑࡇࡋࡒࡠࡔࡈࡗ࡚ࡒࡔࡔࡡࡐࡓࡉࡋࡓ࠻ࠏࠍࠍࠎࠩࡩࡧࠢࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓ࠻ࠢࡦࡳࡳࡪ࠱ࠡ࠿ࠣࠬࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠡ࡫ࡱࠤࡠ࠭࠮࠯ࠩ࠯ࠫࡒࡧࡩ࡯ࠢࡐࡩࡳࡻࠧ࡞ࠫࠐࠎࠎࠏࠣࡦ࡮࡬ࡪ࡙ࠥࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖ࠾ࠥࡩ࡯࡯ࡦ࠴ࠤࡂࠦࠨ࡮ࡧࡱࡹࡤࡲࡡࡣࡧ࡯ࠥࡂࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉࠊ࡫ࡩࠤࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠣ࡭ࡳࠦࡴࡦࡺࡷࠤࡦࡴࡤࠡ࡯ࡨࡲࡺࡥ࡬ࡢࡤࡨࡰࠦࡃ࡮ࡢ࡯ࡨࡣࠥࡧ࡮ࡥࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦࠫ࠽ࠑࠏࠏࠉࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠮ࠡࠢࠣࡖࡪࡧࡤࡪࡰࡪࠤࡱࡧࡳࡵࠢࡰࡩࡳࡻࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ࠰ࡧࡤࡥࡱࡱࡣࡵࡧࡴࡩ࠭ࠪࠤࡢ࠭ࠩࠎࠌࠌࠍࠎࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱࡳࡩࡳ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠱࠭ࡲࡣࠩࠬ࠲ࡷ࡫ࡡࡥࠪࠬࠑࠏࠏࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡳࡱࡪࡆࡊࡎࡈࠤࡂࠦ࡯࡭ࡦࡉࡍࡑࡋ࠮ࡥࡧࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠎࠌࠌࠍࠎࡳࡥ࡯ࡷࡌࡸࡪࡳࡳࡍࡋࡖࡘࡠࡀ࡝ࠡ࠿ࠣࡉ࡛ࡇࡌࠩࠩ࡯࡭ࡸࡺࠧ࠭ࡱ࡯ࡨࡋࡏࡌࡆࠫࠐࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠒࠐࠉࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠯ࠢࠣࠤ࡜ࡸࡩࡵ࡫ࡱ࡫ࠥࡲࡡࡴࡶࠣࡱࡪࡴࡵࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ࠱ࡡࡥࡦࡲࡲࡤࡶࡡࡵࡪ࠮ࠫࠥࡣࠧࠪࠏࠍࠍࠎࠏࡲࡦࡵࡸࡰࡹࡹࠠ࠾ࠢࡐࡅࡎࡔ࡟ࡅࡋࡖࡔࡆ࡚ࡃࡉࡇࡕࠬࡹࡿࡰࡦ࠮ࡱࡥࡲ࡫࡟࠭ࡷࡵࡰࡤ࠲࡭ࡰࡦࡨ࠰࡮ࡳࡡࡨࡧࡢ࠰ࡵࡧࡧࡦࡡ࠯ࡸࡪࡾࡴ࠭ࡥࡲࡲࡹ࡫ࡸࡵ࠮࡬ࡲ࡫ࡵࡤࡪࡥࡷ࠭ࠒࠐࠉࠊࠋࡱࡩࡼࡌࡉࡍࡇࠣࡁࠥࡹࡴࡳࠪࡰࡩࡳࡻࡉࡵࡧࡰࡷࡑࡏࡓࡕࠫࠐࠎࠎࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢࡱࡩࡼࡌࡉࡍࡇࠣࡁࠥࡴࡥࡸࡈࡌࡐࡊ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠍࠋࠋࠌࠍࡴࡶࡥ࡯ࠪ࡯ࡥࡸࡺ࡭ࡦࡰࡸࡪ࡮ࡲࡥ࠭ࠩࡺࡦࠬ࠯࠮ࡸࡴ࡬ࡸࡪ࠮࡮ࡦࡹࡉࡍࡑࡋࠩࠎࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡁࠥࡓࡁࡊࡐࡢࡈࡎ࡙ࡐࡂࡖࡆࡌࡊࡘࠨࡵࡻࡳࡩ࠱ࡴࡡ࡮ࡧࡢ࠰ࡺࡸ࡬ࡠ࠮ࡰࡳࡩ࡫ࠬࡪ࡯ࡤ࡫ࡪࡥࠬࡱࡣࡪࡩࡤ࠲ࡴࡦࡺࡷ࠰ࡨࡵ࡮ࡵࡧࡻࡸ࠱࡯࡮ࡧࡱࡧ࡭ࡨࡺࠩࠎࠌࠌࠦࠧࠨ枅")
	results = l111l11l1ll_l1_(type,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,mode,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,text,context,l1ll1l1lll1_l1_)
	# l1llll1lll1l_l1_ l111llll11l1_l1_: succeeded,l11111lllll1_l1_,l111lll111ll_l1_ = True,False,True
	# l11111lllll1_l1_ = True => l1ll1l11l111_l1_ this list is l1lll1l1lllll_l1_ and will exit to main menu
	# l11111lllll1_l1_ = False => l1ll1l11l111_l1_ this list is l1111llll111_l1_ and will exit to l111l1l1l1l_l1_ menu
	# l111lll111ll_l1_ = True => will cause the l1lll1lll11l1_l1_ status to l1lllllllll1l_l1_ l1lll1lll1111_l1_
	# l111lll111ll_l1_ = False => will l1lll1ll1l1l1_l1_ the l1lll1lll11l1_l1_ status to l111ll1111l1_l1_ l1111l1ll11l_l1_
	#succeeded,l11111lllll1_l1_,l111lll111ll_l1_ = True,False,True
	#if not l11l111l11l1_l1_: l111lll111ll_l1_ = False
	if l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ枆") in text: l11111lllll1_l1_ = True
	if type==l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枇"):
		if l11l1l1lll_l1_!=l11l1l_l1_ (u"ࠩ࠱࠲ࠬ枈") and l1lllllll11ll_l1_: l1111l11ll1l_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪ࡭ࡳࡺࠧ枉"),l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ枊"),l11l1l_l1_ (u"ࠬࡇࡕࡕࡊࠪ枋")) or l1lll1ll1lll1_l1_ not in l111111lll1l_l1_) and not l11llll111ll_l1_(l11l1l_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ枌")):
				import l11l11ll11l_l1_
				l1llllll1l11l_l1_ = GET_ALL_LIST_ITEMS(l11l11ll11l_l1_.l11l11lll1l_l1_)
				l111l1lll11l_l1_ = CREATE_KODI_MENU(l1lll11l11ll1_l1_,l1llllll1l11l_l1_,succeeded,l11111lllll1_l1_,l111lll111ll_l1_)
				if 1 and l1llllll1l11l_l1_ and l1llll11l11ll_l1_:
					WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ枍"),l1lll11l11ll1_l1_,l1llllll1l11l_l1_,REGULAR_CACHE)
				#elif 1 and not l1llllll1l11l_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊ࠭枎"),l1lll11l11ll1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ枏")+addon_id+l11l1l_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ析"),xbmcgui.ListItem(l11l1l_l1_ (u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪ枑")))
				xbmcplugin.addDirectoryItem(addon_handle,l11l1l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ枒")+addon_id+l11l1l_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭枓"),xbmcgui.ListItem(l11l1l_l1_ (u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭枔")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l11111lllll1_l1_,l111lll111ll_l1_)
	return
def l111l11l1ll_l1_(type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_):
	l1lll1ll1lll1_l1_ = int(mode)
	l111ll11111_l1_ = int(l1lll1ll1lll1_l1_//10)
	if   l111ll11111_l1_==0:  import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==1:  import l1111ll1_l1_ 		; results = l1111ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==2:  import l1l1ll1llll_l1_ 		; results = l1l1ll1llll_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==3:  import l111lll1l1l_l1_ 		; results = l111lll1l1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==4:  import l1l1l11ll_l1_ 	; results = l1l1l11ll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==5:  import l11l1lll1ll1_l1_ 	; results = l11l1lll1ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==6:  import l1ll111l1_l1_ 	; results = l1ll111l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==7:  import l11lll1_l1_ 		; results = l11lll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==8:  import l1l1lll1111_l1_ 	; results = l1l1lll1111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==9:  import l1ll1l1l1l_l1_		; results = l1ll1l1l1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==10: import l1l11lll1ll_l1_ 		; results = l1l11lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,url)
	elif l111ll11111_l1_==11: import l1l1lll111l1_l1_ 	; results = l1l1lll111l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==12: import l111111l1l_l1_ 		; results = l111111l1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==13: import l1l1l1l11_l1_	; results = l1l1l1l11_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==14: import l111111ll1l_l1_ 		; results = l111111ll1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_,name,l111_l1_)
	elif l111ll11111_l1_==15: import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==16: import l1111ll1ll1_l1_	 	; results = l1111ll1ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,l11llll_l1_,l1ll1l1lll1_l1_)
	elif l111ll11111_l1_==17: import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==18: import l11l1111l11_l1_	; results = l11l1111l11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==19: import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==20: import l111l1l1l_l1_		; results = l111l1l1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==21: import l1lll1lll1ll_l1_ ; results = l1lll1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==22: import l1lll1lllll_l1_ 	; results = l1lll1lllll_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==23: import IPTV 		; results = IPTV.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_,l1ll1l1lll1_l1_)
	elif l111ll11111_l1_==24: import l1llll11_l1_ 		; results = l1llll11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==25: import l11l111l1_l1_ 	; results = l11l111l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==26: import l11l11ll11l_l1_ 		; results = l11l11ll11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1lll1ll1lll1_l1_,context)
	elif l111ll11111_l1_==28: import IPTV 		; results = IPTV.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_,l1ll1l1lll1_l1_)
	elif l111ll11111_l1_==29: import l11l111ll1ll_l1_	; results = l11l111ll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,url,l11llll_l1_,text)
	elif l111ll11111_l1_==30: import l1ll1l1111_l1_		; results = l1ll1l1111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==31: import l11ll1111l11_l1_	; results = l11ll1111l11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==32: import l1l1l1l1ll1_l1_	; results = l1l1l1l1ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==33: import l111llllll_l1_		; results = l111llllll_l1_.MAIN(l1lll1ll1lll1_l1_,url)
	elif l111ll11111_l1_==34: import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==35: import l1l11l11_l1_		; results = l1l11l11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==36: import l111lll1ll1_l1_		; results = l111lll1ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==37: import l1111111l_l1_		; results = l1111111l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==38: import l111llll111_l1_ 		; results = l111llll111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==39: import l1ll1l11l11_l1_	; results = l1ll1l11l11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==40: import l11ll1llll_l1_	; results = l11ll1llll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_)
	elif l111ll11111_l1_==41: import l11ll1llll_l1_	; results = l11ll1llll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_)
	elif l111ll11111_l1_==42: import l1llll1lll_l1_		; results = l1llll1lll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==43: import l1lll1l1ll1_l1_		; results = l1lll1l1ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==44: import l1lll1l1lll_l1_		; results = l1lll1l1lll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==45: import l1l11lll111_l1_		; results = l1l11lll111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==46: import l1ll1ll1ll11_l1_		; results = l1ll1ll1ll11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==47: import l1ll1l111l_l1_	; results = l1ll1l111l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==48: import l1l1ll111lll_l1_		; results = l1l1ll111lll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==49: import l1ll1lll1l_l1_		; results = l1ll1lll1l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==50: import l1l1l1lll1ll_l1_ 	; results = l1l1l1lll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,text)
	elif l111ll11111_l1_==51: import l1lll111ll1_l1_ 	; results = l1lll111ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==52: import l1lll111ll1_l1_ 	; results = l1lll111ll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==53: import l11l11ll11l_l1_ 		; results = l11l11ll11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==54: import l1lll111lll_l1_	; results = l1lll111lll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,l11llll_l1_)
	elif l111ll11111_l1_==55: import l1lll11111_l1_ 	; results = l1lll11111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==56: import l1l1lll1l111_l1_		; results = l1l1lll1l111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==57: import l1ll1l111l1_l1_		; results = l1ll1l111l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==58: import l11ll111l11l_l1_	; results = l11ll111l11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==59: import l1ll11ll1ll_l1_		; results = l1ll11ll1ll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==60: import l1ll11ll11l_l1_		; results = l1ll11ll11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==61: import l1ll11l_l1_		; results = l1ll11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==62: import l1ll1l1l111_l1_		; results = l1ll1l1l111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==63: import l1ll1llll1_l1_		; results = l1ll1llll1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==64: import l11ll111111l_l1_		; results = l11ll111111l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==65: import l1lllll1l1_l1_		; results = l1lllll1l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==66: import l11l1ll1ll11_l1_		; results = l11l1ll1ll11_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==67: import l1l1l1l1111_l1_		; results = l1l1l1l1111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==68: import l111ll11l1_l1_		; results = l111ll11l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==69: import l1lllll11l_l1_		; results = l1lllll11l_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==70: import l1l11llllll_l1_		; results = l1l11llllll_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==71: import l1l111ll1l1_l1_			; results = l1l111ll1l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_,l1ll1l1lll1_l1_)
	elif l111ll11111_l1_==72: import l1l111ll1l1_l1_			; results = l1l111ll1l1_l1_.MAIN(l1lll1ll1lll1_l1_,url,text,type,l11llll_l1_,l1ll1l1lll1_l1_)
	elif l111ll11111_l1_==73: import l1l11l111_l1_	; results = l1l11l111_l1_.MAIN(l1lll1ll1lll1_l1_,url,text)
	elif l111ll11111_l1_==74: import l1l1l1l1l1_l1_		; results = l1l1l1l1l1_l1_.MAIN(l1lll1ll1lll1_l1_)
	elif l111ll11111_l1_==75: import l1l1l1l1l1_l1_		; results = l1l1l1l1l1_l1_.MAIN(l1lll1ll1lll1_l1_)
	else: results = None
	return results
def l11l1l1111_l1_(name=l11l1l_l1_ (u"ࠨࠩ枕")):
	if not name: name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ枖"))
	name = name.replace(l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ林"),l11l1l_l1_ (u"ࠫࠬ枘"))
	name = name.replace(l11l1l_l1_ (u"ࠬࠦࠠࠡࠢࠪ枙"),l11l1l_l1_ (u"࠭ࠠࠨ枚")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ枛"),l11l1l_l1_ (u"ࠨࠢࠪ果")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ枝"),l11l1l_l1_ (u"ࠪࠤࠬ枞")).strip(l11l1l_l1_ (u"ࠫࠥ࠭枟"))
	name = name.replace(l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ枠"),l11l1l_l1_ (u"࠭ࠧ枡")).replace(l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ枢"),l11l1l_l1_ (u"ࠨࠩ枣"))
	tmp = re.findall(l11l1l_l1_ (u"ࠩ࡟ࡨࡡࡪ࠺࡝ࡦ࡟ࡨࠥ࠭枤"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11l1l_l1_ (u"ࠪࡑࡦ࡯࡮ࠡࡏࡨࡲࡺ࠭枥")
	return name
def l1llllll11ll1_l1_(code,reason,source,l1ll_l1_):
	if l11l1l_l1_ (u"ࠫ࠲࠭枦") in source: l1ll11111l1_l1_ = source.split(l11l1l_l1_ (u"ࠬ࠳ࠧ枧"),1)[0]
	else: l1ll11111l1_l1_ = source
	l111l1llll11_l1_ = code in [7,11001,11002,10054]
	l1ll1ll1lllll_l1_ = reason.lower()
	l1lllll1l1l1l_l1_ = code in [0,104,10061,111]
	l1lllll1l1l11_l1_ = l11l1l_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ枨") in l1ll1ll1lllll_l1_
	l1lllll1l11ll_l1_ = l11l1l_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ枩") in l1ll1ll1lllll_l1_
	l1lllll1l11l1_l1_ = l11l1l_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ枪") in l1ll1ll1lllll_l1_
	l1lllll1l111l_l1_ = l11l1l_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ枫") in l1ll1ll1lllll_l1_
	l1lll11l1ll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ枬"))
	l1lll111l1l11_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ枭"))
	l11111l11lll_l1_ = l11l1l_l1_ (u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ枮")
	l1lll1l1111ll_l1_ = l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥ࠭枯")+str(code)+l11l1l_l1_ (u"ࠧ࠻ࠢࠪ枰")+reason
	l1lll1l1111ll_l1_ = l1llll_l1_(l1lll1l1111ll_l1_)
	if l1lllll1l1l1l_l1_ or l1lllll1l1l11_l1_ or l1lllll1l11ll_l1_ or l1lllll1l11l1_l1_ or l1lllll1l111l_l1_:
		l11111l11lll_l1_ += l11l1l_l1_ (u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ枱")
	if l111l1llll11_l1_: l11111l11lll_l1_ += l11l1l_l1_ (u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ枲")
	l1lll1l1111ll_l1_ = l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ枳")+l1lll1l1111ll_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭枴")
	if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠬࡇࡓࡌࠩ枵") or l1lll111l1l11_l1_==l11l1l_l1_ (u"࠭ࡁࡔࡍࠪ架"):
		l11111l11lll_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ枷")
	l111lllll111_l1_ = False
	if l1ll_l1_ and source not in l1111lllll11_l1_:
		if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠨࡃࡖࡏࠬ枸") or l1lll111l1l11_l1_==l11l1l_l1_ (u"ࠩࡄࡗࡐ࠭枹"):
			#if kodi_version<19: l1lll1l1111ll_l1_ = l1lll1l1111ll_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ枺"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ枻"),l11l1l_l1_ (u"ࠬิั้ฮࠪ枼"),l11l1l_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠫ枽"),l11l1l_l1_ (u"ࠧฦื็หาࠦวๅ็ื็้ฯࠧ枾"),l1ll11111l1_l1_+l11l1l_l1_ (u"ࠨࠢࠣࠤࠬ枿")+TRANSLATE(l1ll11111l1_l1_),l11111l11lll_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ柀")+l1lll1l1111ll_l1_)
			if choice==1:
				import l1l1l1lll1ll_l1_
				l1l1l1lll1ll_l1_.l1l111l1lll1_l1_()
			elif choice==2: l111lllll111_l1_ = True
		else: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ柁"),l11l1l_l1_ (u"ࠫࠬ柂"),l1ll11111l1_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ柃")+TRANSLATE(l1ll11111l1_l1_),l11111l11lll_l1_,l1lll1l1111ll_l1_)
	#if reason.endswith(l11l1l_l1_ (u"࠭ࠠࠪࠩ柄")): reason = reason.rsplit(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ柅"))[0]
	#if l111lllll111_l1_: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭柆"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ柇")+str(code)+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ柈")+reason+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭柉")+source+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡅࡗࡇࡂࡊࡅ࠽ࠤࡠࠦࠧ柊")+l11111l11lll_l1_+l11l1l_l1_ (u"࠭ࠠ࡞࡟ࠣࠤࠥࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ柋")+l1lll1l1111ll_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ柌"))
	return l111lllll111_l1_
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡧࡲࡸࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠴ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠳ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠹࠺ࠎࠌࠌࠍࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨ่๋฽๋ࠥๆࠡษ็ััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆ࠲ࠬࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥ࠱࠽๋้ࠡࠩࠣࠦสา์าࠤฯ็วึ์็ࠤฬ้หาࠢยࠫࠒࠐࠉࠊ࡫ࡩࠤࡩࡴࡳ࠻ࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽ࠡࠩ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄࠢ࠮ࡁ้ࠥ࠭ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽๊ࠡࠩิฬࠦวๅ็๋ๆ฾ࠦแ๋้ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡰࡷࡵࡧࡪ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠰࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠏࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲ࡳࡪࡶࡨ࠯ࠬࠦࠠࠡࠩ࠮ࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠮ࡳࡪࡶࡨ࠭࠱ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠱࠻ࠢ࡬ࡱࡵࡵࡲࡵࠢࡖࡉࡗ࡜ࡉࡄࡇࡖࠤࡀࠦࡓࡆࡔ࡙ࡍࡈࡋࡓ࠯ࡏࡄࡍࡓ࠮࠱࠺࠷ࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠐࠎࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠠ࠾ࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤ࠳ࠦ็ๅࠢอี๏ีࠠๆ฻ิๅฮࠦวๅลึฬฬฮ้ࠠษ็ั้๎ไࠡมࠪࠑࠏࠏࠉࡺࡧࡶࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥ࡙ࡆࡕࡑࡓ࠭࠭ࡣࡦࡰࡷࡩࡷ࠭ࠬࡴ࡫ࡷࡩ࠰࠭ࠠࠡࠢࠪ࠯࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋࠨࡴ࡫ࡷࡩ࠮࠲࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠲࠼ࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠿ࠣࠫ็ี๋ࠠๅ๋๊ࠥํๆศๅ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢ฼๊ิ้ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤ๊็ี้ๆฬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠๅษࠣ๎฾๋ไࠡ฻้ำ่࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํีࠥํะ่ࠢสฺ่็อส๋ࠢห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࡠࡳ࠭ࠫࠨฮิฬ๋ࠥำฮࠢส่่อิ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠำๅࠤึ็ูࠡษ็ััฮࠠࠩ็ฮ่ฬࠦࡖࡑࡐࠣ࠰ࠥࡖࡲࡰࡺࡼࠤ࠱ࠦࡄࡏࡕࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ไษ๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศฯๅหࠬࠓࠊࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡘࡊ࡞ࡔࡗࡋࡈ࡛ࡊࡘࠨࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗ࠮ࠓࠊࠊࠤࠥࠦ柍")
def l11llllll111_l1_(l1lll1111lll1_l1_=False):
	l11111l1ll11_l1_ = [l11l111llll_l1_,favoritesfile,l1l11ll1l11l_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1lll1111lll1_l1_ and (filename.startswith(l11l1l_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ柎")) or filename.startswith(l11l1l_l1_ (u"ࠪࡱ࠸ࡻࠧ柏"))): continue
		if filename.startswith(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪ某")): continue
		l1l11l1ll11_l1_ = os.path.join(addoncachefolder,filename)
		if l1l11l1ll11_l1_ in l11111l1ll11_l1_: continue
		try: os.remove(l1l11l1ll11_l1_)
		except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(l1lll1ll1111l_l1_=addon_path):
	l111l1111111_l1_ = {l11l1l_l1_ (u"ࠬࡺࡹࡱࡧࠪ柑"):l11l1l_l1_ (u"࠭ࠧ柒"),l11l1l_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ染"):l11l1l_l1_ (u"ࠨࠩ柔"),l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭柕"):l11l1l_l1_ (u"ࠪࠫ柖"),l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ柗"):l11l1l_l1_ (u"ࠬ࠭柘"),l11l1l_l1_ (u"࠭ࡰࡢࡩࡨࠫ柙"):l11l1l_l1_ (u"ࠧࠨ柚"),l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭柛"):l11l1l_l1_ (u"ࠩࠪ柜"),l11l1l_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ柝"):l11l1l_l1_ (u"ࠫࠬ柞"),l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭柟"):l11l1l_l1_ (u"࠭ࠧ柠"),l11l1l_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ柡"):l11l1l_l1_ (u"ࠨࠩ柢")}
	if l11l1l_l1_ (u"ࠩࡂࠫ柣") in l1lll1ll1111l_l1_: l1lll1ll1111l_l1_ = l1lll1ll1111l_l1_.split(l11l1l_l1_ (u"ࠪࡃࠬ柤"),1)[1]
	l111ll1_l1_,l1111lllllll_l1_ = l1lll111ll_l1_(l1lll1ll1111l_l1_)
	args = dict(list(l111l1111111_l1_.items())+list(l1111lllllll_l1_.items()))
	l1lll1l1llll1_l1_ = args[l11l1l_l1_ (u"ࠫࡲࡵࡤࡦࠩ查")]
	l1llll1l1ll11_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ柦")])
	l111l1lll1l1_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࠫ柧")])
	l1llllllll1ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠧࡱࡣࡪࡩࠬ柨")])
	l11l11ll1ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭柩")])
	l111l1lll1ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ柪")])
	l1lll111ll1l1_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ柫")])
	l1ll1ll1ll1l1_l1_ = args[l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ柬")]
	l1llll1l11l1l_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ柭")])
	if l1llll1l11l1l_l1_: l1llll1l11l1l_l1_ = eval(l1llll1l11l1l_l1_)
	else: l1llll1l11l1l_l1_ = {}
	#name = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ柮"))
	#l111_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ柯"))
	if not l1lll1l1llll1_l1_: l11l11ll1ll_l1_ = l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ柰") ; l1lll1l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࠵࠺࠵࠭柱")
	return l11l11ll1ll_l1_,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,l1lll1l1llll1_l1_,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,l111l1lll1l1_l1_,l1ll1ll1ll1l1_l1_,l1llll1l11l1l_l1_
def l1llll1l1lll1_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111lll1111l_l1_=True,l1llll1111lll_l1_=True):
	l1lll11llllll_l1_,l1llll1ll1111_l1_ = proxy.split(l11l1l_l1_ (u"ࠪ࠾ࠬ柲"))
	#l1lllll1_l1_(l11l1l_l1_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ柳"),l11l1l_l1_ (u"ูࠬรอำหࠤࠬ柴")+name,time=2000)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭柵"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ柶")+name+l11l1l_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ柷")+proxy+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ柸")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭柹"))
	url = url+l11l1l_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ柺")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111lll1111l_l1_,l1llll1111lll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ査"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ柼")+name+l11l1l_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭柽")+proxy+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ柾")+url+l11l1l_l1_ (u"ࠩࠣࡡࠬ柿"))
		l111111ll1ll_l1_(l11l1l_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ栀"))
	#else: LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ栁"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ栂")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ栃")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ栄"))
	return response
def l1lll111l111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ栅"),url,l11l1l_l1_ (u"ࠩࠪ栆"),l11l1l_l1_ (u"ࠪࠫ标"),True,l11l1l_l1_ (u"ࠫࠬ栈"),l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭栉"),True,False)
	l1111l1l1l11_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l1lllll1_l1_
		l1lll1lllll1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ栊"),html)
		#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ栋"),str(l1lll1lllll1l_l1_))
		if l1lll1lllll1l_l1_: html = l11l1l_l1_ (u"ࠨ࡞ࡱࠫ栌").join(l1lll1lllll1l_l1_)
		proxies = html.replace(l11l1l_l1_ (u"ࠩ࡟ࡶࠬ栍"),l11l1l_l1_ (u"ࠪࠫ栎")).strip(l11l1l_l1_ (u"ࠫࡡࡴࠧ栏")).split(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ栐"))
		l1111l1l1l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l11l1l_l1_ (u"࠭࠮ࠨ树"))==3: l1111l1l1l11_l1_.append(proxy)
	return l1111l1l1l11_l1_
def l111lll111l1_l1_(*args):
	#l1llll111llll_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠵࠷࠱࠷࠸࠴࠱࠸࠰࠴࠶࠼࠵ࡡࡱ࡫࠲ࡴࡷࡵࡸࡺࡁࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡹࡰࡦࡧࡧࡁ࠶࠶ࠦ࡭ࡣࡶࡸࡤࡩࡨࡦࡥ࡮ࡁ࠶࠶ࠦࡩࡶࡷࡴࡸࡃࡴࡳࡷࡨࠪࡵࡵࡳࡵ࠿ࡷࡶࡺ࡫ࠦࡧࡱࡵࡱࡦࡺ࠽ࡵࡺࡷࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ栒")
	l11l11111111_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ栓")
	l1lllll1lll11_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭栔")
	#l1111l1l1l1l_l1_ = l1lll111l111l_l1_(l1llll111llll_l1_)
	l1111l1l1l1l_l1_ = l1lll111l111l_l1_(l1lllll1lll11_l1_)
	l1111l1l1l11_l1_ = l1lll111l111l_l1_(l11l11111111_l1_)
	l11l1111ll1l_l1_ = l1111l1l1l1l_l1_+l1111l1l1l11_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ栕"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ栖")+str(len(l1111l1l1l1l_l1_))+l11l1l_l1_ (u"ࠬ࠱ࠧ栗")+str(len(l1111l1l1l11_l1_))+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栘"))
	proxy = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ栙"))
	response = l1111llll11l_l1_()
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ栚"),l11l1l_l1_ (u"ࠩࠪ栛"))
	if proxy or l11l1111ll1l_l1_:
		id,timeout = 0,10
		l1lll11l11lll_l1_ = len(l11l1111ll1l_l1_)
		l111l1111l11_l1_ = timeout
		if l1lll11l11lll_l1_>l111l1111l11_l1_: counts = l111l1111l11_l1_
		else: counts = l1lll11l11lll_l1_
		l111l1ll11ll_l1_ = random.sample(l11l1111ll1l_l1_,counts)
		if proxy: l111l1ll11ll_l1_ = [proxy]+l111l1ll11ll_l1_
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ栜"),str(l111l1ll11ll_l1_))
		threads = l1llll11l1ll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l111l1l1lll1_l1_:
			if id<counts:
				proxy = l111l1ll11ll_l1_[id]
				threads.start_new_thread(id,l1llll1l1lll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ栝"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ栞")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栟"))
		l111l1l1lll1_l1_ = threads.l111l1l1lll1_l1_
		if l111l1l1lll1_l1_:
			l1llllll1ll11_l1_ = threads.l1llllll1ll11_l1_
			l111111l1l1l_l1_ = l111l1l1lll1_l1_[0]
			response = l1llllll1ll11_l1_[l111111l1l1l_l1_]
			proxy = l111l1ll11ll_l1_[int(l111111l1l1l_l1_)]
			settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ栠"),proxy)
			if l111111l1l1l_l1_!=0: LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ校"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ栢")+proxy+l11l1l_l1_ (u"ࠪࠤࡢ࠭栣"))
			else: LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ栤"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ栥")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栦"))
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ栧"),l11l1l_l1_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙࠸ࠠ࠻࠼ࠣࠫ栨")+str(l111l1ll11ll_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ栩"),l11l1l_l1_ (u"ࠪࡴࡷࡵࡸࡪࡧࡶࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ株")+str(l11l1111ll1l_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ栫"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ栬")+str(threads.l111l1l1lll1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭栭"),l11l1l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ栮")+str(threads.l11l111l1ll1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ栯"),l11l1l_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࡵࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ栰")+str(threads.l1llllll1ll11_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ栱"),l11l1l_l1_ (u"ࠫࡪࡲࡰࡢࡵࡨࡨࡹ࡯࡭ࡦࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ栲")+str(threads.l111lllllll1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ栳"),l11l1l_l1_ (u"࠭ࡳࡰࡴࡷࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ栴")+str(l1ll1lll1111_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ栵"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࠬ栶")+l1lll11l11111_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭样")+str(l1ll1lll1111_l1_))
	return response
def l1ll1lllll1l1_l1_(connection,l1ll1lll11lll_l1_):
	l111l11ll1l1_l1_ = connection.create_connection
	def l1lll1l11l1l1_l1_(address,*args,**kwargs):
		host,port = address
		l1ll11111l11_l1_ = DNS_RESOLVER(host,l1ll1lll11lll_l1_)
		if l1ll11111l11_l1_: host = l1ll11111l11_l1_[0]
		else:
			if l1ll1lll11lll_l1_ in l11lll111l11_l1_: l11lll111l11_l1_.remove(l1ll1lll11lll_l1_)
			if l11lll111l11_l1_:
				l1111lll1l1l_l1_ = l11lll111l11_l1_[0]
				#LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ核"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡗࡪ࡮࡯ࠤࡹࡸࡹࠡࡶ࡫ࡩࠥࡵࡴࡩࡧࡵࠤࡉࡔࡓ࠻࡝ࠣࠫ根")+l1111lll1l1l_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡴࡹࡴ࠻࡝ࠣࠫ栺")+str(host)+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栻"))
				l1ll11111l11_l1_ = DNS_RESOLVER(host,l1111lll1l1l_l1_)
				if l1ll11111l11_l1_: host = l1ll11111l11_l1_[0]
		address = (host,port)
		return l111l11ll1l1_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll1l11l1l1_l1_
	return l111l11ll1l1_l1_
def l1ll11ll1l_l1_(l1l1ll1111l1_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ格"),l11l1l_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ栽"),(method,url,data,headers))
	if html:
		l1llll1ll1ll1_l1_(True,url,data,headers,source,l11l1l_l1_ (u"ࠩࠪ栾"))
		return html
	html = l1llll111l_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ栿"),(method,url,data,headers),html,l1l1ll1111l1_l1_)
	return html
def l1llll111l_l1_(method,url,data=l11l1l_l1_ (u"ࠫࠬ桀"),headers=l11l1l_l1_ (u"ࠬ࠭桁"),source=l11l1l_l1_ (u"࠭ࠧ桂")):
	l1llll1ll1ll1_l1_(False,url,data,headers,source,l11l1l_l1_ (u"ࠧࠨ桃"))
	if kodi_version>18.99: import urllib.request as l1lll11l1l11l_l1_
	else: import urllib2 as l1lll11l1l11l_l1_
	if not headers: headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ桄"):l11l1l_l1_ (u"ࠩࠪ桅")}
	if not data: data = {}
	if method==l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ框"):
		url = url+l11l1l_l1_ (u"ࠫࡄ࠭桇")+l1ll11lll_l1_(data)
		data = None
	try:
		req = l1lll11l1l11l_l1_.Request(url,headers=headers,data=data)
		http_response = l1lll11l1l11l_l1_.urlopen(req)
		html = http_response.read()
	except: html = l11l1l_l1_ (u"ࠬ࠭案")
	#try:
	#	req = l1lll11l1l11l_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l1lll11l1l11l_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l11l1l_l1_ (u"࠭ࠧ桉")
	return html
def l1ll1lll111l1_l1_(url):
	l111ll111l1l_l1_,l111ll11llll_l1_ = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ桊"))[2],80
	if l11l1l_l1_ (u"ࠨ࠼ࠪ桋") in l111ll111l1l_l1_: l111ll111l1l_l1_,l111ll11llll_l1_ = l111ll111l1l_l1_.split(l11l1l_l1_ (u"ࠩ࠽ࠫ桌"))
	l111l11l11l1_l1_ = l11l1l_l1_ (u"ࠪ࠳ࠬ桍")+l11l1l_l1_ (u"ࠫ࠴࠭桎").join(url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ桏"))[3:])
	request = l11l1l_l1_ (u"࠭ࡇࡆࡖࠣࠫ桐")+l111l11l11l1_l1_+l11l1l_l1_ (u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ桑")
	#request += l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸ࠿ࠦ࡜ࡳ࡞ࡱࠫ桒")
	request += l11l1l_l1_ (u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ桓")+l111ll111l1l_l1_+l11l1l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ桔")
	request += l11l1l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ桕")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l111ll111l1l_l1_,l111ll11llll_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11l1l_l1_ (u"ࠬ࠭桖")
	return html
def SERVER(l1llll1_l1_,type):
	# url:	http://www.l1111l1lll1l_l1_.com
	# host:	www.l1111l1lll1l_l1_.com
	# name:	l1111l1lll1l_l1_
	#server = l11l1l_l1_ (u"࠭࠯ࠨ桗").join(l1llll1_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩ桘"))[:3])
	if l11l1l_l1_ (u"ࠨ࠰ࠪ桙") not in l1llll1_l1_: return l1llll1_l1_
	l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ桚")
	l11l1llll1l_l1_,l11l1l11lll_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࠲ࠬ桛"),1)
	l1lll1l1l1l11_l1_,l1lll1l1l11ll_l1_ = l11l1l11lll_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭桜"),1)
	server = l11l1llll1l_l1_+l11l1l_l1_ (u"ࠬ࠴ࠧ桝")+l1lll1l1l1l11_l1_
	if type in [l11l1l_l1_ (u"࠭ࡨࡰࡵࡷࠫ桞"),l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ桟")] and l11l1l_l1_ (u"ࠨ࠱ࠪ桠") in server: server = server.rsplit(l11l1l_l1_ (u"ࠩ࠲ࠫ桡"),1)[1]
	if type==l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ桢") and l11l1l_l1_ (u"ࠫ࠳࠭档") in server:
		l1lll11llll1l_l1_ = server.split(l11l1l_l1_ (u"ࠬ࠴ࠧ桤"))
		length = len(l1lll11llll1l_l1_)
		if length<=2 or l11l1l_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ桥") in server: l1lll11llll1l_l1_ = l1lll11llll1l_l1_[0]
		elif length>=3: l1lll11llll1l_l1_ = l1lll11llll1l_l1_[1]
		if len(l1lll11llll1l_l1_)>1: server = l1lll11llll1l_l1_
	return server
	l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥ࠭࠯ࠨ࠭ࡸࡶࡱ࠸ࠫࠨ࠱ࠪࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡯ࡧࡷ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤࡱࡰ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡰࡴࡪ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡭࡫ࡹࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡶࡹ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡸࡵ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡴࡰ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡳࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡵ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡶࡺ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡦࡥࡲ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡲࡩࡷࡧ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣ࡭ࡷࡥ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡭࡫ࡩࡩ࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡯ࡻ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡪࡰ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡷࡸࡹ࠱ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵࡭࠯ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡪࡳࡢࡦࡦ࠱ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࠨࠢࠣ桦")
def l1111llllll_l1_(l11l11l1l11l_l1_):
	l11l11l11111_l1_ = repr(l11l11l1l11l_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭桧"))).replace(l11l1l_l1_ (u"ࠤࠪࠦ桨"),l11l1l_l1_ (u"ࠪࠫ桩"))
	return l11l11l11111_l1_
def l1l1l111lll_l1_(string):
	#if l11l1l_l1_ (u"ࠫࡡࡻࠧ桪") in string:
	#	string = string.decode(l11l1l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭桫"))
	#	l1llllllll1l1_l1_=re.findall(l11l1l_l1_ (u"ࡸࠧ࡝ࡷ࡞࠴࠲࠿ࡁ࠮ࡈࡠࠫ桬"),string)
	#	for unicode in l1llllllll1l1_l1_
	#		char = l1ll1ll11llll_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ桭"))
	l1ll1llllll11_l1_ = l11l1l_l1_ (u"ࠨࠩ桮")
	if kodi_version<19: string = string.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ桯"))
	import unicodedata
	for l1l1l111l1l_l1_ in string:
		if   l1l1l111l1l_l1_==l11l1l_l1_ (u"ࡸࠫว࠭桰"): l111111lllll_l1_ = l11l1l_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ桱")
		elif l1l1l111l1l_l1_==l11l1l_l1_ (u"ࡺ࠭รࠨ桲"): l111111lllll_l1_ = l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ桳")
		elif l1l1l111l1l_l1_==l11l1l_l1_ (u"ࡵࠨฦࠪ桴"): l111111lllll_l1_ = l11l1l_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ桵")
		elif l1l1l111l1l_l1_==l11l1l_l1_ (u"ࡷࠪษࠬ桶"): l111111lllll_l1_ = l11l1l_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ桷")
		elif l1l1l111l1l_l1_==l11l1l_l1_ (u"ࡹࠬฬࠧ桸"): l111111lllll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭桹")
		else:
			l1ll1ll11l1l1_l1_ = unicodedata.decomposition(l1l1l111l1l_l1_)
			if l11l1l_l1_ (u"࠭ࠠࠨ桺") in l1ll1ll11l1l1_l1_: l111111lllll_l1_ = l11l1l_l1_ (u"ࠧ࡝࡞ࡸࠫ桻")+l1ll1ll11l1l1_l1_.split(l11l1l_l1_ (u"ࠨࠢࠪ桼"),1)[1]
			else:
				l111111lllll_l1_ = l11l1l_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ桽")+hex(ord(l1l1l111l1l_l1_)).replace(l11l1l_l1_ (u"ࠪ࠴ࡽ࠭桾"),l11l1l_l1_ (u"ࠫࠬ桿"))
				l111111lllll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡜ࡶࠩ梀")+l111111lllll_l1_[-4:]
			#if ord(l1l1l111l1l_l1_)<256: l111111lllll_l1_ = l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠴ࠬ梁")+l1lll1l1l1lll_l1_
			#elif ord(l1l1l111l1l_l1_)<4096: l111111lllll_l1_ = l11l1l_l1_ (u"ࠧ࡝࡞ࡸ࠴ࠬ梂")+l1lll1l1l1lll_l1_
			#elif l11l1l_l1_ (u"ࠨࠢࠪ梃") in l1ll1ll11l1l1_l1_: l111111lllll_l1_ = l11l1l_l1_ (u"ࠩ࡟ࡠࡺ࠭梄")+l1ll1ll11l1l1_l1_.split(l11l1l_l1_ (u"ࠪࠤࠬ梅"),1)[1]
			#else: l111111lllll_l1_ = l11l1l_l1_ (u"ࠫࡡࡢࡵࠨ梆")+l1lll1l1l1lll_l1_
		l1ll1llllll11_l1_ += l111111lllll_l1_
	l1ll1llllll11_l1_ = l1ll1llllll11_l1_.replace(l11l1l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭梇"),l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧ梈"))
	if kodi_version<19: l1ll1llllll11_l1_ = l1ll1llllll11_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ梉")).encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭梊"))
	else: l1ll1llllll11_l1_ = l1ll1llllll11_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ梋")).decode(l11l1l_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ梌"))
	return l1ll1llllll11_l1_
def OPEN_KEYBOARD(header=l11l1l_l1_ (u"้ࠫ๎อสࠢส่๊็วห์ะࠫ梍"),default=l11l1l_l1_ (u"ࠬ࠭梎"),l111l11111l1_l1_=False,source=l11l1l_l1_ (u"࠭ࠧ梏")):
	text = l111ll1l11l1_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ梐"),l11l1l_l1_ (u"ࠨࠢࠪ梑")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ梒"),l11l1l_l1_ (u"ࠪࠤࠬ梓")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ梔"),l11l1l_l1_ (u"ࠬࠦࠧ梕"))
	if not text and not l111l11111l1_l1_:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭梖"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ梗")+text+l11l1l_l1_ (u"ࠨࠤࠪ梘"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ梙"),l11l1l_l1_ (u"ࠪࠫ梚"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ梛"),l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨ梜"))
		return l11l1l_l1_ (u"࠭ࠧ條")
	if text not in [l11l1l_l1_ (u"ࠧࠨ梞"),l11l1l_l1_ (u"ࠨࠢࠪ梟")]:
		text = text.strip(l11l1l_l1_ (u"ࠩࠣࠫ梠"))
		text = l1l1l111lll_l1_(text)
	if source!=l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ梡") and l11l11l_l1_(l11l1l_l1_ (u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭梢"),l11l1l_l1_ (u"ࠬ࠭梣"),[text],False):
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭梤"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ梥")+text+l11l1l_l1_ (u"ࠨࠤࠪ梦"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ梧"),l11l1l_l1_ (u"ࠪࠫ梨"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ梩"),l11l1l_l1_ (u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧ梪"))
		return l11l1l_l1_ (u"࠭ࠧ梫")
	LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ梬"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ梭")+text+l11l1l_l1_ (u"ࠩࠥࠫ梮"))
	return text
def l1111l11ll1l_l1_():
	type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11l1l_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪ梯"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11l1l_l1_ (u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫ械"),time.localtime(now))
	name = name+datetime
	l1l1lllllll_l1_ = type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_
	if os.path.exists(l11l111llll_l1_):
		l11lll1lll1l_l1_ = open(l11l111llll_l1_,l11l1l_l1_ (u"ࠬࡸࡢࠨ梱")).read()
		if kodi_version>18.99: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ梲"))
		l11lll1lll1l_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ梳"),l11lll1lll1l_l1_)
	else: l11lll1lll1l_l1_ = {}
	l11ll1llll11_l1_ = {}
	for l1lll11l1lll1_l1_ in list(l11lll1lll1l_l1_.keys()):
		if l1lll11l1lll1_l1_!=type: l11ll1llll11_l1_[l1lll11l1lll1_l1_] = l11lll1lll1l_l1_[l1lll11l1lll1_l1_]
		else:
			if name and name!=l11l1l_l1_ (u"ࠨ࠰࠱ࠫ梴"):
				l111111l111l_l1_ = l11lll1lll1l_l1_[l1lll11l1lll1_l1_]
				if l1l1lllllll_l1_ in l111111l111l_l1_:
					index = l111111l111l_l1_.index(l1l1lllllll_l1_)
					del l111111l111l_l1_[index]
				l1llll11111_l1_ = [l1l1lllllll_l1_]+l111111l111l_l1_
				l1llll11111_l1_ = l1llll11111_l1_[:50]
				l11ll1llll11_l1_[l1lll11l1lll1_l1_] = l1llll11111_l1_
			else: l11ll1llll11_l1_[l1lll11l1lll1_l1_] = l11lll1lll1l_l1_[l1lll11l1lll1_l1_]
	if type not in list(l11ll1llll11_l1_.keys()): l11ll1llll11_l1_[type] = [l1l1lllllll_l1_]
	l11ll1llll11_l1_ = str(l11ll1llll11_l1_)
	if kodi_version>18.99: l11ll1llll11_l1_ = l11ll1llll11_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ梵"))
	open(l11l111llll_l1_,l11l1l_l1_ (u"ࠪࡻࡧ࠭梶")).write(l11ll1llll11_l1_)
	return
def l11l1lllll_l1_(l111ll1_l1_,headers={}):
	#if headers[l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ梷")]==l11l1l_l1_ (u"ࠬ࠭梸"): headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ梹")] = l11l1l_l1_ (u"ࠧࠡࠩ梺")
	#l11111111111_l1_ = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ梻") : l11l1l_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠷࠶࠰࠳࠲࠸࠽࠷࠱࠰࠴࠸࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭梼") }
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡪ࠸࠵࠰ࡰࡽࡨࡪ࡮࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠱ࡱ࠸ࡻ࠸ࠨ梽")
	#open(l11l1l_l1_ (u"ࠫࡘࡀ࡜࡝ࡶࡨࡷࡹ࠸࠮࡮࠵ࡸ࠼ࠬ梾"), l11l1l_l1_ (u"ࠬࡸࠧ梿")).read()
	url,params = l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧ检")
	if l11l1l_l1_ (u"ࠧࡽࠩ棁") in l111ll1_l1_:
		url,params = l111ll1_l1_.split(l11l1l_l1_ (u"ࠨࡾࠪ棂"),1)
		if l11l1l_l1_ (u"ࠩࡀࠫ棃") not in params: url,params = l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫ棄")
	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ棅"),url,l11l1l_l1_ (u"ࠬ࠭棆"),headers,l11l1l_l1_ (u"࠭ࠧ棇"),l11l1l_l1_ (u"ࠧࠨ棈"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ棉"),False,False)
	html = response.content
	if l11l1l_l1_ (u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭棊") not in html: return [l11l1l_l1_ (u"ࠪ࠱࠶࠭棋")],[l111ll1_l1_]
	#	if l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ棌") in list(headers.keys()): del headers[l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ棍")]
	#	else: headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ棎")] = l11l1l_l1_ (u"ࠧࠨ棏")
	#	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ棐"),url,l11l1l_l1_ (u"ࠩࠪ棑"),headers,l11l1l_l1_ (u"ࠪࠫ棒"),l11l1l_l1_ (u"ࠫࠬ棓"),l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠸࡮ࡥࠩ棔"),False,False)
	#	html = response.content
	if l11l1l_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ棕") in html: return [l11l1l_l1_ (u"ࠧ࠮࠳ࠪ棖")],[l111ll1_l1_]
	if l11l1l_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ棗") in html: return [l11l1l_l1_ (u"ࠩ࠰࠵ࠬ棘")],[l111ll1_l1_]
	#if l11l1l_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖࠫ棙") in html: return [l11l1l_l1_ (u"ࠫ࠲࠷ࠧ棚")],[l111ll1_l1_]
	l1ll1lll_l1_,l1lll1_l1_,l1111ll1111l_l1_,l1llll111lll1_l1_ = [],[],[],[]
	lines = re.findall(l11l1l_l1_ (u"ࠬࡢࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ棛"),html+l11l1l_l1_ (u"࠭࡜࡯࡞ࡵࠫ棜"),re.DOTALL)
	if not lines: return [l11l1l_l1_ (u"ࠧ࠮࠳ࠪ棝")],[l111ll1_l1_]
	for line,l1llll1_l1_ in lines:
		l1ll1llll1l11_l1_,l1lllllllll1_l1_,l111ll1l_l1_ = {},-1,-1
		title = l11l1l_l1_ (u"ࠨࠩ棞")
		#hostname = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ棟"))
		#title = title+l11l1l_l1_ (u"ࠪࠤࠥ࠭棠")+hostname+l11l1l_l1_ (u"ࠫࠥࠦࠧ棡")
		#line = line.lower()
		items = line.split(l11l1l_l1_ (u"ࠬ࠲ࠧ棢"))
		for item in items:
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ棣"),l11l1l_l1_ (u"ࠧࠨ棤"),item,l11l1l_l1_ (u"ࠨࠩ棥"))
			#if l11l1l_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ棦") in item: l1ll1llll1l11_l1_[key] = value
			if l11l1l_l1_ (u"ࠪࡁࠬ棧") in item:
				key,value = item.split(l11l1l_l1_ (u"ࠫࡂ࠭棨"),1)
				l1ll1llll1l11_l1_[key.lower()] = value
		if l11l1l_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ棩") in line.lower():
			l1lllllllll1_l1_ = int(l1ll1llll1l11_l1_[l11l1l_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ棪")])//1024
			#title += l11l1l_l1_ (u"ࠧࡂࡸࡪࡆ࡜ࡀࠠࠨ棫")+str(l1lllllllll1_l1_)+l11l1l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ棬")
			title += str(l1lllllllll1_l1_)+l11l1l_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ棭")
		elif l11l1l_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭森") in line.lower():
			l1lllllllll1_l1_ = int(l1ll1llll1l11_l1_[l11l1l_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ棯")])//1024
			#title += l11l1l_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ棰")+str(l1lllllllll1_l1_)+l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭棱")
			title += str(l1lllllllll1_l1_)+l11l1l_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ棲")
		if l11l1l_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ棳") in line.lower():
			l111ll1l_l1_ = int(l1ll1llll1l11_l1_[l11l1l_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭棴")].split(l11l1l_l1_ (u"ࠪࡼࠬ棵"))[1])
			#title += l11l1l_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ棶")+str(l111ll1l_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠨ棷")
			title += str(l111ll1l_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠩ棸")
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠢࠪ棹"))
		if not title: title = l11l1l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ棺")
		if not l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ棻")):
			if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠪ࠳࠴࠭棼")): l1llll1_l1_ = url.split(l11l1l_l1_ (u"ࠫ࠿࠭棽"),1)[0]+l11l1l_l1_ (u"ࠬࡀࠧ棾")+l1llll1_l1_
			elif l1llll1_l1_.startswith(l11l1l_l1_ (u"࠭࠯ࠨ棿")): l1llll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ椀"))+l1llll1_l1_
			else: l1llll1_l1_ = url.rsplit(l11l1l_l1_ (u"ࠨ࠱ࠪ椁"),1)[0]+l11l1l_l1_ (u"ࠩ࠲ࠫ椂")+l1llll1_l1_
		if params!=l11l1l_l1_ (u"ࠪࠫ椃"): l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࢁ࠭椄")+params
		if l11l1l_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ椅") in list(l1ll1llll1l11_l1_.keys()):
			l1llll11ll_l1_ = l1ll1llll1l11_l1_[l11l1l_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ椆")]
			l1llll11ll_l1_ = l1llll11ll_l1_.replace(l11l1l_l1_ (u"ࠧࠣࠩ椇"),l11l1l_l1_ (u"ࠨࠩ椈")).replace(l11l1l_l1_ (u"ࠤࠪࠦ椉"),l11l1l_l1_ (u"ࠪࠫ椊")).split(l11l1l_l1_ (u"ࠫࠨ࠭椋"),1)[0]
			l111ll1l11_l1_ = l11l1l1ll1_l1_(l1llll11ll_l1_)
			if l111ll1l11_l1_: l1lll11ll_l1_ = title+l11l1l_l1_ (u"ࠬࠦࠠࠨ椌")+l111ll1l11_l1_
			else: l1lll11ll_l1_ = title
			l1lll11ll_l1_ = l1lll11ll_l1_+l11l1l_l1_ (u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭植")
			l1lll11ll_l1_ = l1lll11ll_l1_+l11l1l_l1_ (u"ࠧࠡࠢࠪ椎")+SERVER(l1llll11ll_l1_,l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭椏"))
			l1ll1lll_l1_.append(l1lll11ll_l1_)
			l1lll1_l1_.append(l1llll11ll_l1_)
			l1111ll1111l_l1_.append(l111ll1l_l1_)
			l1llll111lll1_l1_.append(l1lllllllll1_l1_)
		l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠩࠦࠫ椐"),1)[0]
		l111ll1l11_l1_ = l11l1l1ll1_l1_(l1llll1_l1_)
		if l111ll1l11_l1_: title = title+l11l1l_l1_ (u"ࠪࠤࠥ࠭椑")+l111ll1l11_l1_
		title = title+l11l1l_l1_ (u"ࠫࠥࠦࠧ椒")+SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ椓"))
		l1ll1lll_l1_.append(title)
		l1lll1_l1_.append(l1llll1_l1_)
		l1111ll1111l_l1_.append(l111ll1l_l1_)
		l1llll111lll1_l1_.append(l1lllllllll1_l1_)
	zz = list(zip(l1ll1lll_l1_,l1lll1_l1_,l1111ll1111l_l1_,l1llll111lll1_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1ll1lll_l1_,l1lll1_l1_,l1111ll1111l_l1_,l1llll111lll1_l1_ = list(zip(*zz))
	l1ll1lll_l1_,l1lll1_l1_ = list(l1ll1lll_l1_),list(l1lll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭ࠧ椔"), l1ll1lll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧࠨ椕"), l1lll1_l1_)
	return l1ll1lll_l1_,l1lll1_l1_
mac = l11l1l_l1_ (u"ࠨࠩ椖")
def l11111lll1l1_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11llll11_l1_(length=32):
	l11lll11ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭椗"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭椘"),l11l1l_l1_ (u"ࠫࡈࡒࡉࡆࡐࡗࡍࡉ࠭椙"))
	if l11lll11ll_l1_: return l11lll11ll_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l1lll1ll1l111_l1_ = threading.Thread(target=l11111lll1l1_l1_,args=())
	l1lll1ll1l111_l1_.start()
	for l11l1ll1l1_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11l1l_l1_ (u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ椚")
	else:
		mac = mac.replace(l11l1l_l1_ (u"࠭࠺ࠨ椛"),l11l1l_l1_ (u"ࠧࠨ検"))
		node = str(int(mac,16))
	node = re.findall(l11l1l_l1_ (u"ࠨ࡝࠳࠱࠾ࡣࠫࠨ椝"),node,re.DOTALL)
	node = length*l11l1l_l1_ (u"ࠩ࠳ࠫ椞")+node[0]
	node = node[-length:]
	mm,ss = l11l1l_l1_ (u"ࠪࠫ椟"),l11l1l_l1_ (u"ࠫࠬ椠")
	l111llllll1l_l1_ = str(int(l11l1l_l1_ (u"ࠬ࠿ࠧ椡")*(length+1))-int(node))[-length:]
	for l11l1ll1l1_l1_ in list(range(0,length,4)):
		l1ll1ll1l1lll_l1_ = l111llllll1l_l1_[l11l1ll1l1_l1_:l11l1ll1l1_l1_+4]
		mm += l1ll1ll1l1lll_l1_+l11l1l_l1_ (u"࠭࠭ࠨ椢")
		ss += str(sum(map(int,node[l11l1ll1l1_l1_:l11l1ll1l1_l1_+4]))%10)
	l11lll11ll_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ椣"),l11l1l_l1_ (u"ࠨࡅࡏࡍࡊࡔࡔࡊࡆࠪ椤"),l11lll11ll_l1_,PERMANENT_CACHE)
	return l11lll11ll_l1_
def DNS_RESOLVER(host,l1ll1lll11lll_l1_=l11lll111l11_l1_[0]):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ椥"),l11l1l_l1_ (u"ࠪࠫ椦"),str(l1ll1lll11lll_l1_),str(host))
	if host.replace(l11l1l_l1_ (u"ࠫ࠳࠭椧"),l11l1l_l1_ (u"ࠬ࠭椨")).isdigit(): return [host]
	import struct,socket
	try:
		l111l1l11lll_l1_ = struct.pack(l11l1l_l1_ (u"ࠨ࠾ࡉࠤ椩"), 12049)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠢ࠿ࡊࠥ椪"), 256)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠣࡀࡋࠦ椫"), 1)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠤࡁࡌࠧ椬"), 0)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠥࡂࡍࠨ椭"), 0)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠦࡃࡎࠢ椮"), 0)
		if kodi_version>18.99: l1llllll11l1l_l1_ = host.split(l11l1l_l1_ (u"ࠬ࠴ࠧ椯"))
		else: l1llllll11l1l_l1_ = host.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ椰")).split(l11l1l_l1_ (u"ࠧ࠯ࠩ椱"))
		for part in l1llllll11l1l_l1_:
			parts = part.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭椲"))
			l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠤࡅࠦ椳"), len(part))
			for l1111l111l1l_l1_ in part:
				l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠥࡧࠧ椴"), l1111l111l1l_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ椵")))
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠧࡈࠢ椶"), 0)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠨ࠾ࡉࠤ椷"), 1)
		l111l1l11lll_l1_ += struct.pack(l11l1l_l1_ (u"ࠢ࠿ࡊࠥ椸"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l111l1l11lll_l1_), (l1ll1lll11lll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l111l1lll111_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ椹"), data, 0)
		l1111lll1111_l1_ = l111l1lll111_l1_[3]
		offset = len(host)+18
		l11l1ll1lll_l1_ = []
		for _ in range(l1111lll1111_l1_):
			l1111l1lllll_l1_ = offset
			l1llll1ll1lll_l1_ = 1
			l11111l11ll1_l1_ = False
			while True:
				l1111l111l1l_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠤࡁࡆࠧ椺"), data, l1111l1lllll_l1_)[0]
				if l1111l111l1l_l1_ == 0:
					l1111l1lllll_l1_ += 1
					break
				# l1lll1l1l1111_l1_ the field l1lll11lll1l1_l1_ the first l111ll111111_l1_ bits l1lll1lll11ll_l1_ to 1, l1lll1ll1ll1_l1_ a pointer
				if l1111l111l1l_l1_ >= 192:
					l11111llllll_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠥࡂࡇࠨ椻"), data, l1111l1lllll_l1_ + 1)[0]
					# l1ll1lll1ll11_l1_ the pointer
					l1111l1lllll_l1_ = ((l1111l111l1l_l1_ << 8) + l11111llllll_l1_ - 0xc000) - 1
					l11111l11ll1_l1_ = True
				l1111l1lllll_l1_ += 1
				if l11111l11ll1_l1_ == False: l1llll1ll1lll_l1_ += 1
			if l11111l11ll1_l1_ == True: l1llll1ll1lll_l1_ += 1
			offset = offset + l1llll1ll1lll_l1_
			l11l1111l11l_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠦࡃࡎࡈࡊࡊࠥ椼"), data, offset)
			offset = offset + 10
			l111ll11111l_l1_ = l11l1111l11l_l1_[0]
			l11111l1l111_l1_ = l11l1111l11l_l1_[3]
			if l111ll11111l_l1_ == 1: # l111l11lll11_l1_ type
				l1111l111ll1_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠧࡄࠢ椽")+l11l1l_l1_ (u"ࠨࡂࠣ椾")*l11111l1l111_l1_, data, offset)
				l1ll11111l11_l1_ = l11l1l_l1_ (u"ࠧࠨ椿")
				for l1111l111l1l_l1_ in l1111l111ll1_l1_: l1ll11111l11_l1_ += str(l1111l111l1l_l1_) + l11l1l_l1_ (u"ࠨ࠰ࠪ楀")
				l1ll11111l11_l1_ = l1ll11111l11_l1_[0:-1]
				l11l1ll1lll_l1_.append(l1ll11111l11_l1_)
			if l111ll11111l_l1_ in [1,2,5,6,15,28]: offset = offset + l11111l1l111_l1_
	except: l11l1ll1lll_l1_ = []
	if not l11l1ll1lll_l1_: LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ楁"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ楂")+host+l11l1l_l1_ (u"ࠫࠥࡣࠧ楃"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭楄"),l11l1l_l1_ (u"࠭ࠧ楅"),str(host),str(l11l1ll1lll_l1_))
	return l11l1ll1lll_l1_
def l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_,l1ll_l1_=True):
	if l11l1l1_l1_:
		l111l1ll1ll1_l1_ = [l11l1l_l1_ (u"ࠧไสสีࠬ楆"),l11l1l_l1_ (u"ࠨสส่฿࠭楇"),l11l1l_l1_ (u"ࠩࡤࡨࡺࡲࡴࠨ楈"),l11l1l_l1_ (u"ࠪࡼࡽ࠭楉"),l11l1l_l1_ (u"ࠫࡸ࡫ࡸࠨ楊")]
		if l1ll1_l1_!=l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ楋"):
			l111l1ll1ll1_l1_ += [l11l1l_l1_ (u"࠭ࡲ࠻ࠩ楌"),l11l1l_l1_ (u"ࠧࡳ࠯ࠪ楍"),l11l1l_l1_ (u"ࠨ࠯ࡰࡥࠬ楎")]
			l111l1ll1ll1_l1_ += [l11l1l_l1_ (u"ࠩ࠽ࡶࠬ楏"),l11l1l_l1_ (u"ࠪ࠱ࡷ࠭楐"),l11l1l_l1_ (u"ࠫࡲࡧ࠭ࠨ楑")]
		for l1ll1l11l1_l1_ in l11l1l1_l1_:
			if l11l1l_l1_ (u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ楒") in l1ll1l11l1_l1_: continue
			if l11l1l_l1_ (u"࠭อๅไฬࠫ楓") in l1ll1l11l1_l1_: continue
			l1ll1l11l1_l1_ = l1ll1l11l1_l1_.lower()
			if kodi_version<19: l1ll1l11l1_l1_ = l1ll1l11l1_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ楔")).encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭楕"))
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ楖"),l11l1l_l1_ (u"ࠪࠫ楗"),l11l1l_l1_ (u"ࠫࠬ楘"),str(l1ll1l11l1_l1_))
			#l1111ll1l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡤࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ楙"),l1ll1l11l1_l1_,re.DOTALL)
			#l1111ll1ll11_l1_ = re.findall(l11l1l_l1_ (u"࠭࡞࡝࠭ࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ楚"),l1ll1l11l1_l1_,re.DOTALL)
			#l1111ll1l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫ࡟࠯ࠩ࠭楛"),l1ll1l11l1_l1_,re.DOTALL)
			#l111l11ll11l_l1_ = any(l1111ll1l1l1_l1_,l1111ll1ll11_l1_,l1111ll1l1ll_l1_,l1111ll1l111_l1_)
			l1ll1l11l1_l1_ = l1ll1l11l1_l1_.replace(l11l1l_l1_ (u"ࠨ࠼ࠪ楜"),l11l1l_l1_ (u"ࠩࠪ楝"))
			l111l11ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ楞"),l1ll1l11l1_l1_,re.DOTALL)
			l1llll11l111l_l1_ = False
			for digits in l111l11ll11l_l1_:
				if len(digits)==2:
					l1llll11l111l_l1_ = True
					break
			if l11l1l_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ楟") in l1ll1l11l1_l1_: continue
			elif l11l1l_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭楠") in l1ll1l11l1_l1_: continue
			elif l11l1l_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ楡") in l1ll1l11l1_l1_: continue
			elif l11llll111ll_l1_(l11l1l_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ楢")): continue
			elif l1ll1l11l1_l1_ in [l11l1l_l1_ (u"ࠨࡴࠪ楣")] or l1llll11l111l_l1_ or any(value in l1ll1l11l1_l1_ for value in l111l1ll1ll1_l1_):
				LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ楤"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ楥")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ楦"))
				if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ楧"),l11l1l_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ楨"))
				return True
	return False
def l1ll11lll_l1_(data):
	if kodi_version>18.99: import urllib.parse as l11l1111l1l1_l1_
	else: import urllib as l11l1111l1l1_l1_
	l111l1111l1l_l1_ = l11l1111l1l1_l1_.urlencode(data)
	return l111l1111l1l_l1_
def l1lll111ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ楩"),l11l1l_l1_ (u"ࠨࠩ楪"),url,l11l1l_l1_ (u"ࠩࡘࡖࡑࡊࡅࡄࡑࡇࡉࠬ楫"))
	if l11l1l_l1_ (u"ࠪࡁࠬ楬") in url:
		if l11l1l_l1_ (u"ࠫࡄ࠭業") in url: l111ll1_l1_,filters = url.split(l11l1l_l1_ (u"ࠬࡅࠧ楮"))
		else: l111ll1_l1_,filters = l11l1l_l1_ (u"࠭ࠧ楯"),url
		filters = filters.split(l11l1l_l1_ (u"ࠧࠧࠩ楰"))
		l11ll1111_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ楱"),l11l1l_l1_ (u"ࠩࠪ楲"),filter,str(filters))
			key,value = filter.split(l11l1l_l1_ (u"ࠪࡁࠬ楳"))
			l11ll1111_l1_[key] = value
	else: l111ll1_l1_,l11ll1111_l1_ = url,{}
	return l111ll1_l1_,l11ll1111_l1_
def l1ll1lllllll1_l1_(l111lll_l1_,l1l1l111_l1_=l11l1l_l1_ (u"ࠫࠬ楴"),l11l11ll1ll_l1_=l11l1l_l1_ (u"ࠬ࠭極")):
	global l111l1111lll_l1_
	import threading
	l1lll1ll1l111_l1_ = threading.Thread(target=l1111ll11ll1_l1_,args=(l111lll_l1_,l1l1l111_l1_,l11l11ll1ll_l1_))
	l1lll1ll1l111_l1_.start()
	l1lll1ll1l111_l1_.join()
	return l111l1111lll_l1_
def PLAY_VIDEO(l111lll_l1_,l1l1l111_l1_=l11l1l_l1_ (u"࠭ࠧ楶"),l11l11ll1ll_l1_=l11l1l_l1_ (u"ࠧࠨ楷")):
	global l111l1111lll_l1_
	if not l11l11ll1ll_l1_: l11l11ll1ll_l1_ = l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ楸")
	l111l1111lll_l1_,l111l1llllll_l1_,httpd = l11l1l_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ楹"),l11l1l_l1_ (u"ࠪࠫ楺"),l11l1l_l1_ (u"ࠫࠬ楻")
	if len(l111lll_l1_)==3:
		url,l1llll1l111l1_l1_,httpd = l111lll_l1_
		if l1llll1l111l1_l1_: l111l1llllll_l1_ = l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ楼")+l1llll1l111l1_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ楽")
	else: url,l1llll1l111l1_l1_,httpd = l111lll_l1_,l11l1l_l1_ (u"ࠧࠨ楾"),l11l1l_l1_ (u"ࠨࠩ楿")
	#url = l1llll_l1_(url)		# cause l1ll1ll1l111l_l1_ for l1ll1l1ll_l1_ l1lll1ll1_l1_ l1lllll1l11l_l1_ l11lll1l1ll_l1_
	url = url.replace(l11l1l_l1_ (u"ࠩࠨ࠶࠵࠭榀"),l11l1l_l1_ (u"ࠪࠤࠬ榁"))	# needed for l1l1l1ll11ll_l1_
	l111ll1l11_l1_ = l11l1l1ll1_l1_(url,l1l1l111_l1_)
	if l1l1l111_l1_ not in [l11l1l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭概"),l11l1l_l1_ (u"ࠬࡏࡐࡕࡘࠪ榃")]:
		if l1l1l111_l1_!=l11l1l_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ榄"): url = url.replace(l11l1l_l1_ (u"ࠧࠡࠩ榅"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ榆"))
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ榇"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ榈")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ榉")+l111l1llllll_l1_)
		if l111ll1l11_l1_==l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ榊") and l1l1l111_l1_ not in [l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ榋"),l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ榌")]:
			headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ榍"):l11l1l_l1_ (u"ࠩࠪ榎")}
			l1ll1lll_l1_,l1lll1_l1_ = l11l1lllll_l1_(url,headers)
			count = len(l1lll1_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ榏")+str(count)+l11l1l_l1_ (u"๋ࠫࠥไโࠫࠪ榐"), l1ll1lll_l1_)
				if l1l_l1_ == -1:
					l1lllll1_l1_(l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ榑"),l11l1l_l1_ (u"࠭ࠧ榒"))
					return l111l1111lll_l1_
			else: l1l_l1_ = 0
			url = l1lll1_l1_[l1l_l1_]
			if l1ll1lll_l1_[0]!=l11l1l_l1_ (u"ࠧ࠮࠳ࠪ榓"):
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ榔"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ榕")+l1ll1lll_l1_[l1l_l1_]+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ榖")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ榗"))
		#url = url+l11l1l_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠳࠻࠺࠵࠶࠰࠱ࠩ榘")
		#url = url+l11l1l_l1_ (u"࠭ࡼࡅࡐࡗࡁ࠶ࠬࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠶ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࡁ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠪࡆࡩࡣࡦࡲࡷࡁ࠯࠵ࠪࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬࡑ࡯࡮ࡶࡺ࠾ࠤࡆࡴࡤࡳࡱ࡬ࡨࠥ࠽࠮࠱࠽ࠣࡗࡒ࠳ࡇ࠹࠻࠵ࡅࠥࡈࡵࡪ࡮ࡧ࠳ࡓࡘࡄ࠺࠲ࡐ࠿ࠥࡽࡶࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠯࠵࠰࠳ࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠽࠮࠱࠰࠶࠷࠾࠼࠮࠹࠹ࠣࡑࡴࡨࡩ࡭ࡧࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ榙")
		if l11l1l_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ榚") in url: url = url+l11l1l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ榛")
		elif l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ榜") in url.lower() and l11l1l_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ榝") not in url and l11l1l_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ榞") not in url:
			if l11l1l_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ榟") not in url and l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ榠") in url.lower():
				if l11l1l_l1_ (u"ࠧࡽࠩ榡") not in url: url = url+l11l1l_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ榢")
				else: url = url+l11l1l_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭榣")
			if l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ榤") not in url.lower() and l1l1l111_l1_ not in [l11l1l_l1_ (u"ࠫࡎࡖࡔࡗࠩ榥"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖࠩ榦")]:
				if l11l1l_l1_ (u"࠭ࡼࠨ榧") not in url: url = url+l11l1l_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ榨")
				else: url = url+l11l1l_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ榩")
		#url = url.replace(l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ榪"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ榫"))
	LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ榬"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ榭")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ榮"))
	l1ll1ll11ll11_l1_ = xbmcgui.ListItem()
	#l1ll1ll11ll11_l1_ = xbmcgui.ListItem(l11l1l_l1_ (u"ࠧࡵࡧࡶࡸࠬ榯"))
	l11l11ll1ll_l1_,l111l1lll1ll_l1_,l1llll1l1ll11_l1_,l1lll1l1llll1_l1_,l1lll111ll1l1_l1_,l1llllllll1ll_l1_,l111l1lll1l1_l1_,l1ll1ll1ll1l1_l1_,l1llll1l11l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1l111_l1_ not in [l11l1l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ榰"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ榱")]:
		if kodi_version<19: l1ll1ll1l1111_l1_ = l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭榲")
		else: l1ll1ll1l1111_l1_ = l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ榳")
		#l1ll1ll11ll11_l1_ = xbmcgui.ListItem(path=url)
		l1ll1ll11ll11_l1_.setProperty(l1ll1ll1l1111_l1_, l11l1l_l1_ (u"ࠬ࠭榴"))
		l1ll1ll11ll11_l1_.setMimeType(l11l1l_l1_ (u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ榵"))
		if kodi_version<20: l1ll1ll11ll11_l1_.setInfo(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭榶"),{l11l1l_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ榷"):l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ榸")})
		else:
			l1lll11111lll_l1_ = l1ll1ll11ll11_l1_.getVideoInfoTag()
			l1lll11111lll_l1_.setMediaType(l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ榹"))
		#l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡩࡤࡱࡱࠫ榺"))
		#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭榻"),l11l1l_l1_ (u"࠭ࡅࡎࡃࡇ࠾࠿ࡀ࠺࠻ࠢࠪ榼")+l111_l1_)
		#l1ll1ll11ll11_l1_.setArt({l11l1l_l1_ (u"ࠧࡪࡥࡲࡲࠬ榽"):l111_l1_,l11l1l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ榾"):l111_l1_,l11l1l_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ榿"):l111_l1_})
		l1ll1ll11ll11_l1_.setArt({l11l1l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ槀"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ槁"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ槂"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭槃"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ槄"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ槅"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ槆"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ槇"):l1lll111ll1l1_l1_})
		#l1ll1ll11ll11_l1_.setInfo(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ槈"),{l11l1l_l1_ (u"࡚ࠬࡩࡵ࡮ࡨࠫ槉"):name})
		#name = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ槊"))
		#name = name.strip(l11l1l_l1_ (u"ࠧࠡࠩ構"))
		# when set to l11l1l_l1_ (u"ࠣࡈࡤࡰࡸ࡫ࠢ槌") it l111ll11lll1_l1_ l1lll1ll1ll1l_l1_ l1ll11ll11ll_l1_ and l1lll1ll1l1l1_l1_ l111l11l11ll_l1_ l1ll1llll1111_l1_ l1l1ll1ll1_l1_
		if l111ll1l11_l1_ in [l11l1l_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ槍"),l11l1l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ槎")]: l1ll1ll11ll11_l1_.setContentLookup(True)
		else: l1ll1ll11ll11_l1_.setContentLookup(False)
		#if l111ll1l11_l1_ in [l11l1l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ槏")]: l1ll1ll11ll11_l1_.setContentLookup(False)
		if l11l1l_l1_ (u"ࠬࡸࡴ࡮ࡲࠪ槐") in url:
			import l1l1l1lll1ll_l1_
			l1l1l1lll1ll_l1_.l1l111l11lll_l1_(l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ槑"),False)
		elif l111ll1l11_l1_==l11l1l_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ槒") or l11l1l_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ槓") in url:
			import l1l1l1lll1ll_l1_
			l1l1l1lll1ll_l1_.l1l111l11lll_l1_(l11l1l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ槔"),False)
			l1ll1ll11ll11_l1_.setProperty(l1ll1ll1l1111_l1_,l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ槕"))
			l1ll1ll11ll11_l1_.setProperty(l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫ槖"),l11l1l_l1_ (u"ࠬࡳࡰࡥࠩ槗"))
			#l1ll1ll11ll11_l1_.setMimeType(l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡩࡧࡳࡩ࠭ࡻࡱࡱ࠭様"))
			#l1ll1ll11ll11_l1_.setContentLookup(False)
		if l1llll1l111l1_l1_:
			l1ll1ll11ll11_l1_.setSubtitles([l1llll1l111l1_l1_])
			#xbmc.log(LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠥࠦࡁࡥࡦࡨࡨࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀ࡛ࠨ槙")+l1llll1l111l1_l1_+l11l1l_l1_ (u"ࠨ࡟ࠪ槚"), level=xbmc.LOGNOTICE)
	if l11l11ll1ll_l1_==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ槛") and l1l1l111_l1_==l11l1l_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ槜"):
		l111l1111lll_l1_ = l11l1l_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ槝")
		l1l1l111_l1_ = l11l1l_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬ槞")
	elif l11l11ll1ll_l1_==l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ槟") and l1ll1ll1ll1l1_l1_.startswith(l11l1l_l1_ (u"ࠧ࠷ࠩ槠")):
		l111l1111lll_l1_ = l11l1l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ槡")
		l1l1l111_l1_ = l1l1l111_l1_+l11l1l_l1_ (u"ࠩࡢࡈࡑ࠭槢")
	# l11111111ll1_l1_ l1llllll1l1l1_l1_
	#	l1lll11111ll1_l1_ = l1llll1l1llll_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l111lll_l1_ with xbmc.sleep(step*1000)
	if l111l1111lll_l1_!=l11l1l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ槣"): l1111l11ll1l_l1_()
	l1lll11111ll1_l1_ = l1llll1l1llll_l1_()
	if l1lll11111ll1_l1_.status:
		l111l1111lll_l1_ == l11l1l_l1_ (u"ࠫࠬ槤")
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭槥"),l11l1l_l1_ (u"࠭ࠧ槦"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ槧"),l11l1l_l1_ (u"ࠨๆๅำ่ࠥวๆࠢส่๊ฮัๆฮࠣฬส๐โศใࠣฮูเ๊ๅ๋ࠢฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋๊ࠢิฬࠦวๅฮ๊หื࠭槨"))
	elif l11l11ll1ll_l1_==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ槩") and not l1ll1ll1ll1l1_l1_.startswith(l11l1l_l1_ (u"ࠪ࠺ࠬ槪")):
		#title = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠬ槫"))
		#l1ll1ll11ll11_l1_.setInfo(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ槬"),{l11l1l_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ槭"): 3600})
		#xbmcplugin.setContent(addon_handle,l11l1l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ槮"))
		#l1ll1ll11ll11_l1_.setInfo(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ槯"),{l11l1l_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ槰"):l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ槱")})
		#l1ll1ll11ll11_l1_.setProperty(l11l1l_l1_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ槲"),l11l1l_l1_ (u"ࠬࡺࡲࡶࡧࠪ槳"))
		#l1ll1ll11ll11_l1_.setInfo(type=l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ槴"),l1lll1111111l_l1_={l11l1l_l1_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ槵"):l11l1l_l1_ (u"ࠨࡪࡨࡰࡱࡵࠠࡸࡱࡵࡰࡩ࠭槶")})
		l1ll1ll11ll11_l1_.setPath(url)
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ槷"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ槸")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ槹"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1ll1ll11ll11_l1_)
	elif l11l11ll1ll_l1_==l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ槺"):
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭槻"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ槼")+url+l11l1l_l1_ (u"ࠨࠢࡠࠫ槽"))
		l1lll11111ll1_l1_.play(url,l1ll1ll11ll11_l1_)
		#xbmc.Player().play(url,l1ll1ll11ll11_l1_)
	succeeded = False
	if l111l1111lll_l1_==l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ槾"):
		import l111llllll_l1_
		succeeded = l111llllll_l1_.l11l111l1l_l1_(url,l111ll1l11_l1_,l1l1l111_l1_)
		if succeeded: l1111l11ll1l_l1_()
	else:
		timeout,l111l1111lll_l1_ = 10,l11l1l_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ槿")
		for l11l1ll1l1_l1_ in range(timeout):
			# l11111111ll1_l1_ l1llllll1l1l1_l1_
			#	if using time.sleep() l111l1l1ll1_l1_ of xbmc.sleep() l1111lll1ll1_l1_ the l1ll1111111l_l1_ status
			#	l11l1l_l1_ (u"ࠦࡲࡿࡰ࡭ࡣࡼࡩࡷ࠴ࡳࡵࡣࡷࡹࡸࠨ樀") will stop l111ll1111ll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l111l1111lll_l1_ = l1lll11111ll1_l1_.status
			if l111l1111lll_l1_==l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭樁"):
				l1lllll1_l1_(l11l1l_l1_ (u"࠭วๅใํำ๏๎๋ࠠ฻่่ࠬ樂"),l11l1l_l1_ (u"ࠧࠨ樃"),time=500)
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ樄"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࡷ࡫ࡧࡩࡴࠦࡩࡴࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭樅")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭樆")+l111l1llllll_l1_)
				break
			elif l111l1111lll_l1_==l11l1l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ樇"):
				LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ樈"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ樉")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ樊")+l111l1llllll_l1_)
				l1lllll1_l1_(l11l1l_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ樋"),l11l1l_l1_ (u"ࠩࠪ樌"),time=500)
				break
			l1lllll1_l1_(l11l1l_l1_ (u"ࠪะฬื๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ樍"),l11l1l_l1_ (u"ࠫออโ๋ࠢࠪ樎")+str(timeout-l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠬࠦหศ่ํอࠬ樏"))
		else:
			l1lllll1_l1_(l11l1l_l1_ (u"࠭วๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠨ樐"),l11l1l_l1_ (u"ࠧࠨ樑"),time=500)
			if l111l1111lll_l1_: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭樒"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡊࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡤ࡯ࡳࡨࡱࡥࡥࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ樓")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭樔")+l111l1llllll_l1_)
			else: LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ樕"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡖ࡬ࡱࡪࡵࡵࡵࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ樖")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ樗")+l111l1llllll_l1_)
			l111l1111lll_l1_ = l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ樘")
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢ࡫ࡸࡹࡶࡤ࠻ࠏࠍࠍࠎࠩࠠࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠯ࠍࠋࠋࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪ࠭ࠒࠐࠉࠊࡶ࡬ࡱࡪ࠴ࡳ࡭ࡧࡨࡴ࠭࠷ࠩࠎࠌࠌࠍ࡭ࡺࡴࡱࡦ࠱ࡷ࡭ࡻࡴࡥࡱࡺࡲ࠭࠯ࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳ࠭ࠬࠨࠩࠬࠑࠏࠏࠢࠣࠤ標")
	if l111l1111lll_l1_ in [l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ樚"),l11l1l_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ樛")] or succeeded: response = l11l1111llll_l1_(l1l1l111_l1_)
	else: l1lll11111ll1_l1_.stop()
	#if l111l1111lll_l1_ in [l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭樜"),l11l1l_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ樝"),l11l1l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭樞"),l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ樟"),l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ樠")]: l111ll111lll_l1_(l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠳ࡰࡧࠫ模"),False)
	#l111ll111lll_l1_(l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏ࠮࠵ࡵࡨࠬ樢"))
	#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭樣") in url and l111l1111lll_l1_ in [l11l1l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ樤"),l11l1l_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ樥")]:
	#	l111ll1111ll_l1_ = HTTPS(False)
	#	if not l111ll1111ll_l1_:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ樦"),l11l1l_l1_ (u"ࠨࠩ樧"),l11l1l_l1_ (u"ࠩส่ฬะีศๆู้ࠣ็ัࠨ樨"),l11l1l_l1_ (u"ู้้ࠪไสࠢ࠱࠲࠳ࠦ็ัษࠣห้็๊ะ์๋ࠤ๏ำสศฮࠣห้๏ࠠศฬุห้ࠦๅีใิࠤ࠭ืศุุ่ࠢๆื๊ࠩࠡ็็๋ࠦไๅลึๅࠥอไศฬุห้ࠦวๅ็ืๅึࠦไศࠢํ฽ฺ๊๊ࠠๆ์ࠤัํวำๅࠪ権"))
	#		return l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ横")
	#sys.exit()
	if 0 and l111l1111lll_l1_==l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭樫"):
		LOG_THIS(l11l1l_l1_ (u"࠭ࠧ樬"),l11l1l_l1_ (u"ࠧࡑࡎࡄ࡝ࡤ࡙ࡔࡂࡖࡘࡗ࠿ࡀࠠࠡࠢࠪ樭")+l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ樮"))
		while True:
			l111l1111lll_l1_ = l1lll11111ll1_l1_.status
			#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ樯"),l11l1l_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡕࡗࡅ࡙࡛ࡓ࠻࠼ࠣࠤࠥ࠭樰")+l111l1111lll_l1_)
			if l111l1111lll_l1_!=l11l1l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ樱"): break
			xbmc.sleep(1000)
		LOG_THIS(l11l1l_l1_ (u"ࠬ࠭樲"),l11l1l_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ樳")+l11l1l_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ樴"))
	return l111l1111lll_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l11lll111ll1_l1_ = args[0]
		l11l11l1_l1_ = args[1]
		if not l11lll111ll1_l1_: l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ樵")
		if not l11l11l1_l1_: l11l11l1_l1_ = l11l1l_l1_ (u"ࠩสืฯ๋ัศำࠪ樶")
		header = args[2]
		text = l11l1l_l1_ (u"ࠪࡠࡳ࠭樷").join(args[3:])
	else: l11lll111ll1_l1_,l11l11l1_l1_,header,text = l11l1l_l1_ (u"ࠫࠬ樸"),l11l1l_l1_ (u"ࠬࡕࡋࠨ樹"),l11l1l_l1_ (u"࠭ࠧ樺"),l11l1l_l1_ (u"ࠧࠨ樻")
	DIALOG_THREEBUTTONS_TIMEOUT(l11lll111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ樼"),l11l11l1_l1_,l11l1l_l1_ (u"ࠩࠪ樽"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l11lll111ll1_l1_ = args[0]
	l1lllll11l11l_l1_ = args[1]
	l1llll1ll11ll_l1_ = args[2]
	if l1llll1ll11ll_l1_ or l1lllll11l11l_l1_: l1lllll111l11_l1_ = True
	else: l1lllll111l11_l1_ = False
	header = args[3]
	text = args[4]
	if not l11lll111ll1_l1_: l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ樾")
	if not l1lllll11l11l_l1_: l1lllll11l11l_l1_ = l11l1l_l1_ (u"่๊ࠫวࠨ樿")
	if not l1llll1ll11ll_l1_: l1llll1ll11ll_l1_ = l11l1l_l1_ (u"ࠬ์ูๆࠩ橀")
	if len(args)>=6: text += l11l1l_l1_ (u"࠭࡜࡯ࠩ橁")+args[5]
	if len(args)>=7: text += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ橂")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll111ll1_l1_,l1lllll11l11l_l1_,l11l1l_l1_ (u"ࠨࠩ橃"),l1llll1ll11ll_l1_,header,text)
	if choice==-1 and l1lllll111l11_l1_: choice = -1
	elif choice==-1 and not l1lllll111l11_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l111111llll1_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1lllll1_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11l1l_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ橄") in list(kwargs.keys()): l11l111l1l11_l1_ = kwargs[l11l1l_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ橅")]
	else: l11l111l1l11_l1_ = 1000
	if len(args)>2 and l11l1l_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ橆") not in args[2]: l1111ll111l1_l1_ = args[2]
	else: l1111ll111l1_l1_ = l11l1l_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ橇")
	l1l11111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭橈"),addonfolder,l11l1l_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ橉"),l11l1l_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭橊"))
	l1111111l1ll_l1_,l111l111l1ll_l1_ = l1lll1111llll_l1_(l11l1l_l1_ (u"ࠩࠪ橋"),l11l1l_l1_ (u"ࠪࠫ橌"),l11l1l_l1_ (u"ࠫࠬ橍"),header,text,l1111ll111l1_l1_,l11l1l_l1_ (u"ࠬࡲࡥࡧࡶࠪ橎"),720,False)
	#time.sleep(0.200)
	l1l11111l1l1_l1_.show()
	if l1111ll111l1_l1_==l11l1l_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ橏"):
		l1l11111l1l1_l1_.getControl(9040).setHeight(215)
		l1l11111l1l1_l1_.getControl(9040).setPosition(55,-80)
		l1l11111l1l1_l1_.getControl(9050).setPosition(120,-60)
		l1l11111l1l1_l1_.getControl(400).setPosition(90,-35)
	l1l11111l1l1_l1_.getControl(401).setVisible(False)
	l1l11111l1l1_l1_.getControl(402).setVisible(False)
	l1l11111l1l1_l1_.getControl(9050).setImage(l1111111l1ll_l1_)
	l1l11111l1l1_l1_.getControl(9050).setHeight(l111l111l1ll_l1_)
	import threading
	l11l1111l1ll_l1_ = threading.Thread(target=l1ll1llllll1l_l1_,args=(l1l11111l1l1_l1_,l1111111l1ll_l1_,l11l111l1l11_l1_))
	l11l1111l1ll_l1_.start()
	#l11l1111l1ll_l1_.join()
	return
	#return xbmcgui.Dialog().notification(l1llll1111l11_l1_=False,*args,**kwargs)
def l1ll1llllll1l_l1_(l1l11111l1l1_l1_,l1111111l1ll_l1_,l11l111l1l11_l1_):
	time.sleep(l11l111l1l11_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1111111l1ll_l1_):
		try: os.remove(l1111111l1ll_l1_)
		except: pass
	#del l1l11111l1l1_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,l1111ll111l1_l1_,l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠧࠨ橐"),l11l1l_l1_ (u"ࠨࠩ橑"),l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ橒"),l11l1l_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ橓")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: l1111ll111l1_l1_ = args[2]
	if len(args)>=4: l11lll111ll1_l1_ = args[3]
	return l11ll111l1_l1_(l11lll111ll1_l1_,header,text,l1111ll111l1_l1_)
	#return xbmcgui.Dialog().l1lllll1ll111_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1lll1l1l1ll1_l1_(*args,**kwargs)
def l11l11l1l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111ll1l11l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text,l1111ll111l1_l1_,l11lll111ll1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l11111l1l1_l1_ = l111l1l11l1l_l1_(l11l1l_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭橔"),addonfolder,l11l1l_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭橕"),l11l1l_l1_ (u"࠭࠷࠳࠲ࡳࠫ橖"))
	#l1l11111l1l1_l1_.l111l1l111l1_l1_(l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text,l1111ll111l1_l1_,l11lll111ll1_l1_,855)
	#return l1l11111l1l1_l1_
	l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡶ࡬ࡱࡪࡵࡵࡵࡀ࠳࠾ࠥࡪࡩࡢ࡮ࡲ࡫࠳ࡹࡴࡢࡴࡷࡆࡺࡺࡴࡰࡰࡶࡘ࡮ࡳࡥࡰࡷࡷࠬࡹ࡯࡭ࡦࡱࡸࡸ࠮ࠓࠊࠊࡧ࡯ࡷࡪࡀࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡦࡰࡤࡦࡱ࡫ࡂࡶࡶࡷࡳࡳࡹࠨࠪࠏࠍࠍࠨࡪࡩࡢ࡮ࡲ࡫࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪ࠺࠴࠮ࠏࠣࠡ࠹࠳ࠩࠒࠐࠉࡥ࡫ࡤࡰࡴ࡭࠮ࡥࡱࡐࡳࡩࡧ࡬ࠩࠫࠐࠎࠎࡩࡨࡰ࡫ࡦࡩࠥࡃࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡤࡪࡲ࡭ࡨ࡫ࡉࡅࠏࠍࠍࡹࡸࡹ࠻ࠢࡲࡷ࠳ࡸࡥ࡮ࡱࡹࡩ࠭ࡪࡩࡢ࡮ࡲ࡫࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠯ࠍࠋࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠧࡩ࡫࡬ࠡࡦ࡬ࡥࡱࡵࡧࠎࠌࠌࡶࡪࡺࡵࡳࡰࠣࡧ࡭ࡵࡩࡤࡧࠐࠎࠎࠨࠢࠣ橗")
def l1ll11111_l1_(l1llll1l1l111_l1_):
	if kodi_version>17.99: l1l11111l1l1_l1_ = l11l1l_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭橘")
	else: l1l11111l1l1_l1_ = l11l1l_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭橙")
	l1llll1l1l111_l1_ = l1llll1l1l111_l1_.lower()
	if l1llll1l1l111_l1_==l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ橚"): xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭橛")+l1l11111l1l1_l1_+l11l1l_l1_ (u"ࠬ࠯ࠧ橜"))
	elif l1llll1l1l111_l1_==l11l1l_l1_ (u"࠭ࡳࡵࡱࡳࠫ橝"): xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧ橞")+l1l11111l1l1_l1_+l11l1l_l1_ (u"ࠨࠫࠪ機"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l11lll111ll1_l1_,l1111l1l11l1_l1_=l11l1l_l1_ (u"ࠩࠪ橠"),l1lll11ll1l1l_l1_=l11l1l_l1_ (u"ࠪࠫ橡"),l1111l1l1lll_l1_=l11l1l_l1_ (u"ࠫࠬ橢"),header=l11l1l_l1_ (u"ࠬ࠭橣"),text=l11l1l_l1_ (u"࠭ࠧ橤"),l1lllll1111l1_l1_=0,l1lll1ll1l1ll_l1_=0,l1111ll111l1_l1_=l11l1l_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ橥")):
	if not l11lll111ll1_l1_: l11lll111ll1_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ橦")
	l1l11111l1l1_l1_ = l111l1l11l1l_l1_(l11l1l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ橧"),addonfolder,l11l1l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ橨"),l11l1l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ橩"))
	l1l11111l1l1_l1_.l111l1l111l1_l1_(l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text,l1111ll111l1_l1_,l11lll111ll1_l1_,900,l1lllll1111l1_l1_,l1lll1ll1l1ll_l1_)
	if l1lllll1111l1_l1_>0: l1l11111l1l1_l1_.l11l11111l11_l1_()
	if l1lll1ll1l1ll_l1_>0: l1l11111l1l1_l1_.l111lll1ll1l_l1_()
	if l1lllll1111l1_l1_==0 and l1lll1ll1l1ll_l1_==0: l1l11111l1l1_l1_.enableButtons()
	l1l11111l1l1_l1_.doModal()
	choice = l1l11111l1l1_l1_.l11l1111l111_l1_
	return choice
def l11ll111l1_l1_(l11lll111ll1_l1_,header,text,l1111ll111l1_l1_=l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭橪")):
	if not l11lll111ll1_l1_: l11lll111ll1_l1_ = l11l1l_l1_ (u"࠭࡬ࡦࡨࡷࠫ橫")
	#text = l11l1l_l1_ (u"ࠧ࡝ࡰࠪ橬").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11l1l_l1_ (u"ࠨࠩ橭")
	l1l11111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ橮"),addonfolder,l11l1l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ橯"),l11l1l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ橰"))
	l1111111l1ll_l1_,l111l111l1ll_l1_ = l1lll1111llll_l1_(l11l1l_l1_ (u"ࠬ࠭橱"),l11l1l_l1_ (u"࠭ࠧ橲"),l11l1l_l1_ (u"ࠧࠨ橳"),header,text,l1111ll111l1_l1_,l11lll111ll1_l1_,1270,False)
	l1l11111l1l1_l1_.show()
	#time.sleep(1)
	#l1l11111l1l1_l1_.getControl(9050).l1l111l1llll_l1_(1270-60)
	l1l11111l1l1_l1_.getControl(9050).setHeight(l111l111l1ll_l1_)
	l1l11111l1l1_l1_.getControl(9050).setImage(l1111111l1ll_l1_)
	result = l1l11111l1l1_l1_.doModal()
	#del l1l11111l1l1_l1_
	try: os.remove(l1111111l1ll_l1_)
	except: pass
	return result
def l11llll1l_l1_(l1lll1l1lll11_l1_=True):
	if l1lll1l1lll11_l1_:
		l111ll1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡵࡷࡶࠬ橴"),l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ橵"),l11l1l_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭橶"))
		if l111ll1l1l_l1_: return l111ll1l1l_l1_
	#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ橷"),l11l1l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡻࡳࡦࡴࡤ࡫ࡪࡴࡴ࠻ࠢࠪ橸")+results)
	# l11l11111lll_l1_ and l111111l11_l1_ common user l1llll11ll1ll_l1_ (l111ll1111l1_l1_ l11l11111l1l_l1_)
	text = l11l1l_l1_ (u"࠭ࠧ橹")
	url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡨࡧ࡭ࡨ࡬ࡰࡩ࠱ࡻ࡮ࡲ࡬ࡴࡪࡲࡹࡸ࡫࠮ࡤࡱࡰ࠳࠷࠶࠱࠳࠱࠳࠵࠴࠶࠳࠰࡯ࡲࡷࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡶ࠳ࠬ橺")
	headers = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ橻"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭橼"),url,l11l1l_l1_ (u"ࠪࠫ橽"),headers,l11l1l_l1_ (u"ࠫࠬ橾"),l11l1l_l1_ (u"ࠬ࠭橿"),l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧ檀"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11l1l_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ檁"))
		if count>80:
			text = re.findall(l11l1l_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ檂"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ檃"),l11l1l_l1_ (u"ࠪࠫ檄"),l11l1l_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠧ檅"),l11l1l_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࡙ࠣࡘࡋࡒ࠮ࡃࡊࡉࡓ࡚ࡓࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠬ檆"))
	if not text:
		l1llllll11l11_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ檇"),l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨ檈"))
		text = open(l1llllll11l11_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ檉")).read()
		if kodi_version>18.99: text = text.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ檊"))
		text = text.replace(l11l1l_l1_ (u"ࠪࡠࡷ࠭檋"),l11l1l_l1_ (u"ࠫࠬ檌"))
	l1lllllllll11_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡍࡰࡼ࡬ࡰࡱࡧ࠮ࠫࡁࠬࡠࡳ࠭檍"),text,re.DOTALL)
	l111ll1lllll_l1_ = []
	for line in l1lllllllll11_l1_:
		l1llll1l1ll1l_l1_ = line.lower()
		if l11l1l_l1_ (u"࠭ࡡ࡯ࡦࡵࡳ࡮ࡪࠧ檎") in l1llll1l1ll1l_l1_: continue
		if l11l1l_l1_ (u"ࠧࡶࡤࡸࡲࡹࡻࠧ檏") in l1llll1l1ll1l_l1_: continue
		#if l11l1l_l1_ (u"ࠨࡪࡷࡱࡱ࠭檐") in l1llll1l1ll1l_l1_: continue
		l111ll1lllll_l1_.append(line)
	l111ll1l1l_l1_ = random.sample(l111ll1lllll_l1_,1)
	l111ll1l1l_l1_ = l111ll1l1l_l1_[0]
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ檑"),l11l1l_l1_ (u"ࠪࠫ檒"),str(len(l1lllllllll11_l1_)),l111ll1l1l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ檓"),l11l1l_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ檔"),l111ll1l1l_l1_,l1ll1ll11_l1_)
	return l111ll1l1l_l1_
def l111l1l1l111_l1_(l1lll11111ll_l1_):
	#if l11l1l_l1_ (u"࠭ࡦࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠫ檕") in str(error).lower(): return
	#l1lll11111ll_l1_ = traceback.format_exc()
	sys.stderr.write(l1lll11111ll_l1_)
	lines = l1lll11111ll_l1_.splitlines()
	error = lines[-1]
	l1111ll11111_l1_ = open(l1l11l1l1l11_l1_,l11l1l_l1_ (u"ࠧࡳࡤࠪ檖")).read()
	if kodi_version>18.99: l1111ll11111_l1_ = l1111ll11111_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭檗"))
	l1111ll11111_l1_ = l1111ll11111_l1_[-8000:]
	sep = l11l1l_l1_ (u"ࠩࡀࠫ檘")*100
	if sep in l1111ll11111_l1_: l1111ll11111_l1_ = l1111ll11111_l1_.rsplit(sep,1)[1]
	if error in l1111ll11111_l1_: l1111ll11111_l1_ = l1111ll11111_l1_.rsplit(error,1)[0]
	#l11ll111l1_l1_(l11l1l_l1_ (u"ࠪࠫ檙"),error,l1111ll11111_l1_)
	#l111llll111l_l1_ = l1111ll11111_l1_.splitlines()
	#for line in reversed(l111llll111l_l1_):
	#	if l11l1l_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹࠧ檚") in line or l11l1l_l1_ (u"ࠬࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱࠬ檛") in line: continue
	#	if l11l1l_l1_ (u"࠭ࡍࡰࡦࡨ࠾ࠥࡡࠧ檜") not in line: continue
	l1l1lll1l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭檝"),l1111ll11111_l1_,re.DOTALL)
	for typ,source in reversed(l1l1lll1l1l1_l1_):
		#if l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࠪ檞") in source: continue
		#if l11l1l_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࠬ檟") in source: continue
		if source: break
	else: source = l11l1l_l1_ (u"ࠪࡒࡔ࡚ࠠࡔࡒࡈࡇࡎࡌࡉࡆࡆࠪ檠")
	#l11ll111l1_l1_(l11l1l_l1_ (u"ࠫࠬ檡"),source,str(l1l1lll1l1l1_l1_))
	file,line,func = l11l1l_l1_ (u"ࠬ࠭檢"),l11l1l_l1_ (u"࠭ࠧ檣"),l11l1l_l1_ (u"ࠧࠨ檤")
	l1lllllll1l1_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษ࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ檥")+error
	l1l1ll1lll11_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊฻ฯา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭檦")+source
	for l1lllll111ll1_l1_ in reversed(lines):
		if l11l1l_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠪ檧") in l1lllll111ll1_l1_ and l11l1l_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ檨") in l1lllll111ll1_l1_: break
	l1lllll111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ檩"),l1lllll111ll1_l1_,re.DOTALL)
	if l1lllll111ll1_l1_:
		file,line,func = l1lllll111ll1_l1_[0]
		if l11l1l_l1_ (u"࠭࠯ࠨ檪") in file: file = file.rsplit(l11l1l_l1_ (u"ࠧ࠰ࠩ檫"),1)[1]
		else: file = file.rsplit(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ檬"),1)[1]
		l1lll111111l1_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊๊แ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ檭")+file
		line2 = l11l1l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ืา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭檮")+line
		l11l11111ll1_l1_ = l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅไษ้࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ檯")+func
		l1111ll111ll_l1_ = l1lll111111l1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ檰")+line2+l11l1l_l1_ (u"࠭࡜࡯ࠩ檱")+l11l11111ll1_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ檲")+l1l1ll1lll11_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ檳")+l1lllllll1l1_l1_
		l1llll11llll1_l1_ = line2+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ檴")+l1l1ll1lll11_l1_+l11l1l_l1_ (u"ࠪࡠࡳ࠭檵")+l1lllllll1l1_l1_+l11l1l_l1_ (u"ࠫࡡࡴࠧ檶")+l1lll111111l1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ檷")+l11l11111ll1_l1_
		l111lll1l11l_l1_ = line2+l11l1l_l1_ (u"࠭࡜࡯ࠩ檸")+l1lllllll1l1_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ檹")+l1lll111111l1_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ檺")+l11l11111ll1_l1_
	else:
		l1lll111111l1_l1_,line2,l11l11111ll1_l1_ = l11l1l_l1_ (u"ࠩࠪ檻"),l11l1l_l1_ (u"ࠪࠫ檼"),l11l1l_l1_ (u"ࠫࠬ檽")
		l1111ll111ll_l1_ = l1l1ll1lll11_l1_+l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ檾")+l1lllllll1l1_l1_
		l1llll11llll1_l1_ = l1l1ll1lll11_l1_+l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ檿")+l1lllllll1l1_l1_
		l111lll1l11l_l1_ = l1lllllll1l1_l1_
	#l1lllll1_l1_(file+line+func,error,l11l1l_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ櫀"),time=2000)
	l1llllll1ll1l_l1_ = l11l1l_l1_ (u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬ櫁")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ櫂")
	addons = l111l111111l_l1_()
	l1lllll1ll1l1_l1_ = []
	results = addons[l11l1l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ櫃")]
	l1lllll1111ll_l1_ = l1ll1ll1l1l1l_l1_(addon_version)
	if l11l1l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ櫄") in list(addons.keys()):
		for l1lll1l1ll111_l1_,l11111lll11l_l1_,l111ll1ll111_l1_ in results: l1lllll1ll1l1_l1_ = max(l1lllll1ll1l1_l1_,l11111lll11l_l1_)
		if l1lllll1111ll_l1_<l1lllll1ll1l1_l1_:
			header = l11l1l_l1_ (u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨ櫅")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ櫆"),l11l1l_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ櫇"),l11l1l_l1_ (u"ࠨฬะำ๏ัࠧ櫈"),l11l1l_l1_ (u"ࠩัีําࠧ櫉"),l1llllll1ll1l_l1_+header,l1111ll111ll_l1_)
			if choice==0:
				l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ櫊"),l11l1l_l1_ (u"ࠫำื่อࠩ櫋"),l11l1l_l1_ (u"ࠬะอะ์ฮࠫ櫌"),l11l1l_l1_ (u"࠭ࠧ櫍"),header)
				if l1ll11111l_l1_==1: choice = 1
			if choice==1:
				import l1l1l1lll1ll_l1_
				l1l1l1lll1ll_l1_.l1l1111llll1_l1_()
			return
	l1ll1ll11l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ櫎"),l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ櫏"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ櫐"))
	if not l1ll1ll11l1ll_l1_: l1ll1ll11l1ll_l1_ = []
	l1llll11llll1_l1_ = l1llll11llll1_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭櫑"),l11l1l_l1_ (u"ࠫࡡࡢ࡮ࠨ櫒")).replace(l11l1l_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ櫓"),l11l1l_l1_ (u"࠭ࠧ櫔")).replace(l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ櫕"),l11l1l_l1_ (u"ࠨࠩ櫖")).replace(l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ櫗"),l11l1l_l1_ (u"ࠪࠫ櫘"))
	l111lll1l11l_l1_ = l111lll1l11l_l1_.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ櫙"),l11l1l_l1_ (u"ࠬࡢ࡜࡯ࠩ櫚")).replace(l11l1l_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ櫛"),l11l1l_l1_ (u"ࠧࠨ櫜")).replace(l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ櫝"),l11l1l_l1_ (u"ࠩࠪ櫞")).replace(l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ櫟"),l11l1l_l1_ (u"ࠫࠬ櫠"))
	l1ll1ll1llll1_l1_ = addon_version+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ櫡")+l111lll1l11l_l1_
	if l1ll1ll1llll1_l1_ in l1ll1ll11l1ll_l1_:
		header = l11l1l_l1_ (u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ櫢")
		#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭櫣"),l11l1l_l1_ (u"ࠨะิ์ั࠭櫤"),l11l1l_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭櫥"),l1llllll1ll1l_l1_+header,l1111ll111ll_l1_)
		#if l1ll11111l_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ櫦"),l11l1l_l1_ (u"ࠫำื่อࠩ櫧"),l11l1l_l1_ (u"ࠬ࠭櫨"),header)
		DIALOG_OK(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ櫩"),l11l1l_l1_ (u"ࠧࠨ櫪"),l1llllll1ll1l_l1_+header,l1111ll111ll_l1_)
		return
	l1ll1lll11ll1_l1_ = str(kodi_version).split(l11l1l_l1_ (u"ࠨ࠰ࠪ櫫"))[0]
	#l111lll1ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ櫬"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭櫭"),l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡍࡑࡓ࡜ࡔ࡟ࡆࡔࡕࡓࡗ࡙ࠧ櫮"))
	url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ櫯")][6]
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ櫰"),url,l11l1l_l1_ (u"ࠧࠨ櫱"),l11l1l_l1_ (u"ࠨࠩ櫲"),l11l1l_l1_ (u"ࠩࠪ櫳"),l11l1l_l1_ (u"ࠪࠫ櫴"),l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧ櫵"),False,False)
	html = response.content
	l111lll1ll11_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ櫶"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ櫷"),l11l1l_l1_ (u"ࠧࡂࡎࡏࡣࡐࡔࡏࡘࡐࡢࡉࡗࡘࡏࡓࡕࠪ櫸"),l111lll1ll11_l1_,REGULAR_CACHE)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ櫹"),line+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭櫺")+error+l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ櫻")+addon_version+l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ櫼")+l1ll1lll11ll1_l1_)
	for l111l1l1111l_l1_,l111ll1l1ll1_l1_,l111111l11ll_l1_,l1llll11lll1l_l1_ in l111lll1ll11_l1_:
		l111l1l1111l_l1_ = l111l1l1111l_l1_.split(l11l1l_l1_ (u"ࠬ࠱ࠧ櫽"))
		l111111l11ll_l1_ = l111111l11ll_l1_.split(l11l1l_l1_ (u"࠭ࠫࠨ櫾"))
		l1llll11lll1l_l1_ = l1llll11lll1l_l1_.split(l11l1l_l1_ (u"ࠧࠬࠩ櫿"))
		#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ欀"),str(l111l1l1111l_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭欁")+l111ll1l1ll1_l1_+l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ欂")+str(l111111l11ll_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ欃")+str(l1llll11lll1l_l1_))
		if line in l111l1l1111l_l1_ and error==l111ll1l1ll1_l1_ and addon_version in l111111l11ll_l1_ and l1ll1lll11ll1_l1_ in l1llll11lll1l_l1_:
			header = l11l1l_l1_ (u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪ欄")
			l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ欅"),l11l1l_l1_ (u"ࠧฯำ๋ะࠬ欆"),l11l1l_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ欇"),l1llllll1ll1l_l1_+header,l1111ll111ll_l1_)
			if l1ll11111l_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ欈"),l11l1l_l1_ (u"ࠪࠫ欉"),l11l1l_l1_ (u"ࠫࠬ權"),header)
			return
	header = l11l1l_l1_ (u"ࠬอไาฮสลࠥหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ欋")
	DIALOG_OK(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ欌"),l11l1l_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ欍"),l1llllll1ll1l_l1_+header,l1111ll111ll_l1_)
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ欎"),l11l1l_l1_ (u"ࠩๆ่ฬ࠭欏"),l11l1l_l1_ (u"๊ࠪ฾๋ࠧ欐"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ欑"),l11l1l_l1_ (u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭欒"))
	if l1ll11111l_l1_==1: l1l1l1l111ll_l1_ = l11l1l_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ欓")
	else:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ欔"),l11l1l_l1_ (u"ࠨࠩ欕"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ欖"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨ欗"))
		return
	message = l1llll11llll1_l1_
	l1ll11ll1l11_l1_ = l11l1l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ欘")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"ࠬ࠳ࡅࡳࡴࡲࡶࡸ࠭欙")
	import l1l1l1lll1ll_l1_
	succeeded = l1l1l1lll1ll_l1_.l1llll1ll1l1_l1_(l1ll11ll1l11_l1_,message,True,l11l1l_l1_ (u"࠭ࠧ欚"),l11l1l_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ欛"),l1l1l1l111ll_l1_)
	if succeeded and l1l1l1l111ll_l1_:
		l1ll1ll11l1ll_l1_.append(l1ll1ll1llll1_l1_)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ欜"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ欝"),l1ll1ll11l1ll_l1_,PERMANENT_CACHE)
	return
def l11llll111ll_l1_(l1lllllll11l1_l1_):
	l111llll1lll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ欞"))
	#l1lllllll11l1_l1_ = l1lllllll11l1_l1_.encode(l11l1l_l1_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ欟")).replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ欠"),l11l1l_l1_ (u"࠭ࠧ次"))
	user = l1l11llll11_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11l1l_l1_ (u"࡙ࠧ࠳࠼ࠫ欢")+l1lllllll11l1_l1_+l11l1l_l1_ (u"ࠨ࠳࠻ࡁࠬ欣")+user).encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ欤"))).hexdigest()[0:32]
	if md5 in l111llll1lll_l1_: return True
	return False
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ欥"))
	filename = l11l1l_l1_ (u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ欦")+str(time.time())+l11l1l_l1_ (u"ࠬ࠴ࡤࡢࡶࠪ欧")
	open(filename,l11l1l_l1_ (u"࠭ࡷࡣࠩ欨")).write(data)
	return
def l1l11l1l11l1_l1_(l1ll_l1_):
	if not l1ll_l1_:
		l1l11l1111ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ欩"),l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ欪"),l11l1l_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ欫"))
		if l1l11l1111ll_l1_: return l1l11l1111ll_l1_
	url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ欬")][5]
	l1lll111ll11l_l1_ = l1l11llll11_l1_(32)
	l11llll1llll_l1_ = l11ll11llll1_l1_()
	l11llll1111_l1_ = l11llll1llll_l1_.split(l11l1l_l1_ (u"ࠫ࠱࠭欭"))[2]
	l1llll1111l1l_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ欮"))
	l111l111l11l_l1_ = l1ll1lllll11l_l1_()
	payload = {l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࠫ欯"):l1lll111ll11l_l1_,l11l1l_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ欰"):addon_version,l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ欱"):l11llll1111_l1_,l11l1l_l1_ (u"ࠩ࡬ࡨࡸ࠭欲"):l1lll1lllllll_l1_(l111l111l11l_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ欳"),url,payload,l11l1l_l1_ (u"ࠫࠬ欴"),l11l1l_l1_ (u"ࠬ࠭欵"),l11l1l_l1_ (u"࠭ࠧ欶"),l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬ欷"))
	if not response.succeeded: return []
	html = response.content
	l1l11l1111ll_l1_ = html.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࡶࠬ欸"),l11l1l_l1_ (u"ࠩ࡟ࡲࠬ欹")).replace(l11l1l_l1_ (u"ࠪࡠࡡࡴࠧ欺"),l11l1l_l1_ (u"ࠫࡡࡴࠧ欻")).replace(l11l1l_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ欼"),l11l1l_l1_ (u"࠭࡜࡯ࠩ欽")).replace(l11l1l_l1_ (u"ࠧ࡝ࡴࠪ款"),l11l1l_l1_ (u"ࠨ࡞ࡱࠫ欿"))
	l1l11l1111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ歀"),l1l11l1111ll_l1_,re.DOTALL)
	if not l1l11l1111ll_l1_: return []
	l1l11l1111ll_l1_ = sorted(l1l11l1111ll_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1111l1lll_l1_,l1l11lll1l11_l1_,l11l1ll1lll_l1_,l11ll1l11l11_l1_,reason = l1l11l1111ll_l1_[0]
	#if l11l1l_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ歁") in reason: l1llll111l1ll_l1_,l1llll111ll11_l1_,l1llll111ll1l_l1_ = reason.split(l11l1l_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ歂"),2)
	#else: l1llll111l1ll_l1_,l1llll111ll11_l1_,l1llll111ll1l_l1_ = reason,reason,reason
	l1llll11lllll_l1_ = reason if l11llll111ll_l1_(l11l1l_l1_ (u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ歃")) else l1l11lll1l11_l1_
	settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ歄"),l1llll11lllll_l1_)
	settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ歅"),l1lll1lllllll_l1_(now))
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ歆"),l11l1l_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ歇"),l1l11l1111ll_l1_,REGULAR_CACHE)
	return l1l11l1111ll_l1_
def SPLIT_BIGLIST(items,l11ll1l1l1l_l1_=0,l1llllll1l1ll_l1_=0):
	if l11ll1l1l1l_l1_ and not l1llllll1l1ll_l1_: l1llllll1l1ll_l1_ = len(items)//l11ll1l1l1l_l1_
	l1ll1111l11l_l1_,l11l1ll1l1_l1_,l11llll1lll_l1_ = [],-1,0
	for item in items:
		if l11llll1lll_l1_%l1llllll1l1ll_l1_==0:
			l11l1ll1l1_l1_ += 1
			l1ll1111l11l_l1_.append([])
		l1ll1111l11l_l1_[l11l1ll1l1_l1_].append(item)
		l11llll1lll_l1_ += 1
	return l1ll1111l11l_l1_
	l11l1l_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡮ࡨࡲ࡬ࡺࡨࠡ࠿ࠣࡰࡪࡴࠨࡣ࡫ࡪࡰ࡮ࡹࡴࠪࠏࠍࠍࡸࡶ࡬ࡪࡶࡷࡩࡩࠦ࠽ࠡ࡝ࡠࠑࠏࠏࡦࡰࡴࠣ࡭࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࠳࠯ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵ࠭࠴࠭࠿ࠓࠊࠊࠋ࡬ࡪࠥ࡯ࡩࠢ࠿ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴ࠻ࠏࠍࠍࠎࠏ࡬ࡪࡰࡨࡷ࠵ࠦ࠽ࠡࡤ࡬࡫ࡱ࡯ࡳࡵ࡝࠳࠾࡮ࡴࡴࠩ࡮ࡨࡲ࡬ࡺࡨ࠰ࡵࡳࡰ࡮ࡺࡳࡠࡥࡲࡹࡳࡺࠩ࡞ࠏࠍࠍࠎࠏࡤࡦ࡮ࠣࡦ࡮࡭࡬ࡪࡵࡷ࡟࠵ࡀࡩ࡯ࡶࠫࡰࡪࡴࡧࡵࡪ࠲ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵࠫࡠࠍࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡱ࡯࡮ࡦࡵ࠳ࠤࡂࠦࡢࡪࡩ࡯࡭ࡸࡺࠍࠋࠋࠌࠍࡩ࡫࡬ࠡࡤ࡬࡫ࡱ࡯ࡳࡵࠏࠍࠍࠎࡹࡰ࡭࡫ࡷࡸࡪࡪ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱࡩࡸ࠶ࠩࠎࠌࠌࠍࡩ࡫࡬ࠡ࡮࡬ࡲࡪࡹ࠰ࠎࠌࠌࡶࡪࡺࡵࡳࡰࠣࡷࡵࡲࡩࡵࡶࡨࠑࠏࠏࠢࠣࠤ歈")
def l1111llll1l1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11l1l_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ歉"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11l1l_l1_ (u"ࠬࡏࡐࡕࡘࡢࠫ歊") not in filename or l11l1l_l1_ (u"࠭ࡍ࠴ࡗࡢࠫ歋") not in filename: text = str(data)
	else:
		l1ll1111l11l_l1_ = SPLIT_BIGLIST(data,8)
		text = l11l1l_l1_ (u"ࠧࠨ歌")
		for split in l1ll1111l11l_l1_:
			text += str(split)+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ歍")
		text = text.strip(l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ歎"))
	l111ll1lll11_l1_ = zlib.compress(text)
	open(filepath,l11l1l_l1_ (u"ࠪࡻࡧ࠭歏")).write(l111ll1lll11_l1_)
	return
def l111ll1lll1l_l1_(l1lll111ll111_l1_,filename):
	if l1lll111ll111_l1_==l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ歐"): data = {}
	elif l1lll111ll111_l1_==l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ歑"): data = []
	elif l1lll111ll111_l1_==l11l1l_l1_ (u"࠭ࡳࡵࡴࠪ歒"): data = l11l1l_l1_ (u"ࠧࠨ歓")
	elif l1lll111ll111_l1_==l11l1l_l1_ (u"ࠨ࡫ࡱࡸࠬ歔"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l111ll1lll11_l1_ = open(filepath,l11l1l_l1_ (u"ࠩࡵࡦࠬ歕")).read()
	text = zlib.decompress(l111ll1lll11_l1_)
	#open(l11l1l_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡊࡒࡗ࡚࠶࠴ࡴࡹࡶࠪ歖"),l11l1l_l1_ (u"ࠫࡼࡨࠧ歗")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11l1l_l1_ (u"ࠬࡪࡵ࡮࡯ࡼࡲࡦࡳࡥࠨ歘"))
	#if l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ歙") not in text: data = EVAL(l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ歚"),text)
	if l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ歛") not in text: data = eval(text)
	else:
		l1ll1111l11l_l1_ = text.split(l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ歜"))
		del text
		data = []
		l111l1ll11l1_l1_ = l1llll11l1ll_l1_()
		id = 0
		for split in l1ll1111l11l_l1_:
			#data += EVAL(l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ歝"),split)
			l111l1ll11l1_l1_.l111l11ll111_l1_(str(id),eval,split)
			id += 1
		del l1ll1111l11l_l1_
		l111l1ll11l1_l1_.l1lll1lll1lll_l1_()
		l111l1ll11l1_l1_.l1ll1ll1ll1ll_l1_()
		l1ll1llll1ll1_l1_ = list(l111l1ll11l1_l1_.l1llllll1ll11_l1_.keys())
		l1lll11l111ll_l1_ = sorted(l1ll1llll1ll1_l1_,reverse=False,key=lambda key: int(key))
		for id in l1lll11l111ll_l1_:
			data += l111l1ll11l1_l1_.l1llllll1ll11_l1_[id]
	return data
def l1llll1ll11l1_l1_(addon_id):
	l111ll11ll1l_l1_ = os.path.join(l1l11ll1ll_l1_,l11l1l_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ歞"),addon_id,l11l1l_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ歟"))
	try: l1llllllll11l_l1_ = open(l111ll11ll1l_l1_,l11l1l_l1_ (u"࠭ࡲࡣࠩ歠")).read()
	except:
		l1llll1l1l1l1_l1_ = os.path.join(l11111l111ll_l1_,l11l1l_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ歡"),addon_id,l11l1l_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ止"))
		try: l1llllllll11l_l1_ = open(l1llll1l1l1l1_l1_,l11l1l_l1_ (u"ࠩࡵࡦࠬ正")).read()
		except: return l11l1l_l1_ (u"ࠪࠫ此"),[]
	if kodi_version>18.99: l1llllllll11l_l1_ = l1llllllll11l_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ步"))
	version = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩ武"),l1llllllll11l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11l1l_l1_ (u"࠭ࠧ歧"),[]
	l11l111l1111_l1_,l111l11l1l1l_l1_ = version[0],l1ll1ll1l1l1l_l1_(version[0])
	return l11l111l1111_l1_,l111l11l1l1l_l1_
def l111l111111l_l1_():
	l1111l11llll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ歨"),l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ歩"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ歪"))
	if l1111l11llll_l1_: return l1111l11llll_l1_
	addons,l1111l11llll_l1_ = {},{}
	l1l1lll1l1l1_l1_ = [l1l1ll1_l1_[l11l1l_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ歫")][0]]
	if kodi_version>17.99: l1l1lll1l1l1_l1_.append(l1l1ll1_l1_[l11l1l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ歬")][1])
	if kodi_version>18.99: l1l1lll1l1l1_l1_.append(l1l1ll1_l1_[l11l1l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ歭")][2])
	for l1lll11ll111l_l1_ in l1l1lll1l1l1_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ歮"),l1lll11ll111l_l1_,l11l1l_l1_ (u"ࠧࠨ歯"),l11l1l_l1_ (u"ࠨࠩ歰"),l11l1l_l1_ (u"ࠩࠪ歱"),l11l1l_l1_ (u"ࠪࠫ歲"),l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ歳"))
		if response.succeeded:
			html = response.content
			l1ll1lll11l11_l1_ = l1lll11ll111l_l1_.rsplit(l11l1l_l1_ (u"ࠬ࠵ࠧ歴"),1)[0]
			l1111l1l111l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ歵"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1111lll1l11_l1_ in l1111l1l111l_l1_:
				l111l11l1ll1_l1_ = l1ll1lll11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ歶")+addon_id+l11l1l_l1_ (u"ࠨ࠱ࠪ歷")+addon_id+l11l1l_l1_ (u"ࠩ࠰ࠫ歸")+l1111lll1l11_l1_+l11l1l_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ歹")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1111l11llll_l1_[addon_id] = []
				l1llll1ll1l11_l1_ = l1ll1ll1l1l1l_l1_(l1111lll1l11_l1_)
				addons[addon_id].append((l1111lll1l11_l1_,l1llll1ll1l11_l1_,l111l11l1ll1_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ歺"),str(addon_id)+l11l1l_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫ死")+str(addons[addon_id]))
		l1111l11llll_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ歼"),l11l1l_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ歽"),l1111l11llll_l1_,REGULAR_CACHE)
	return l1111l11llll_l1_
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ࠯ࠍࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡰࡦࡨࡦࡪࡸࡧ࠯ࡱࡵ࡫࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡦࡷࡧ࡮ࡤࡪ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡧࡤ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡢࡳࡣࡱࡧ࡭࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸࡪ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠷࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࠨࠢࠣ歾")
def l1ll1ll1l1l1l_l1_(l1111lll1l11_l1_):
	l1llll1ll1l11_l1_ = []
	l1ll11llll1_l1_ = l1111lll1l11_l1_.split(l11l1l_l1_ (u"ࠩ࠱ࠫ歿"))
	for l1l1111111_l1_ in l1ll11llll1_l1_:
		parts = re.findall(l11l1l_l1_ (u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧ殀"),l1l1111111_l1_,re.DOTALL)
		l11ll111l1l1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l11ll111l1l1_l1_.append(part)
		l1llll1ll1l11_l1_.append(l11ll111l1l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ殁"),str(l1111lll1l11_l1_)+l11l1l_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫ殂")+str(l1llll1ll1l11_l1_))
	return l1llll1ll1l11_l1_
def l1llll11l1lll_l1_(l1llll1ll1l11_l1_):
	l1111lll1l11_l1_ = l11l1l_l1_ (u"࠭ࠧ殃")
	for l1l1111111_l1_ in l1llll1ll1l11_l1_:
		for part in l1l1111111_l1_: l1111lll1l11_l1_ += str(part)
		l1111lll1l11_l1_ += l11l1l_l1_ (u"ࠧ࠯ࠩ殄")
	l1111lll1l11_l1_ = l1111lll1l11_l1_.strip(l11l1l_l1_ (u"ࠨ࠰ࠪ殅"))
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ殆"),str(l1llll1ll1l11_l1_)+l11l1l_l1_ (u"ࠪࠤࠥ࠴ࠠࠡࠩ殇")+str(l1111lll1l11_l1_))
	return l1111lll1l11_l1_
def l1l111111l1l_l1_(l111ll1ll1l1_l1_=l1l111lll1ll_l1_):
	# l1lll1l1111l1_l1_ not l111ll111l11_l1_ l1lll1lll1l1l_l1_ l1lll11l11l1l_l1_ addons status l1lllll1l1l_l1_ l111lllll1_l1_ l111l11lll_l1_ l111l111ll11_l1_
	#l1l1l1l1l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ殈"),l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ殉"),l11l1l_l1_ (u"࠭ࡅࡎࡃࡇࡣࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ殊"))
	#if l1l1l1l1l11l_l1_: return l1l1l1l1l11l_l1_
	l1l1l1l1l11l_l1_ = {}
	addons = l111l111111l_l1_()
	l1l11l111l11_l1_ = l11lll11l1ll_l1_(l111ll1ll1l1_l1_)
	for addon_id in l111ll1ll1l1_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1111l11llll_l1_ = addons[addon_id]
		l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l11ll11l11ll_l1_ = l1111l11llll_l1_[0]
		#l1l11111lll1_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧ残")+addon_id+l11l1l_l1_ (u"ࠨࠫࠪ殌"))
		l1l11111lll1_l1_,l1l11ll11l11_l1_ = l1llll1ll11l1_l1_(addon_id)
		l1l111llllll_l1_,l1l11l1lllll_l1_ = l1l11l111l11_l1_[addon_id]
		l111lllll1ll_l1_ = l1l11lll11ll_l1_>l1l11ll11l11_l1_ and l1l111llllll_l1_
		l11l1l11111_l1_ = True
		if not l1l111llllll_l1_: l1l111ll11l1_l1_ = l11l1l_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ殍")
		elif not l1l11l1lllll_l1_: l1l111ll11l1_l1_ = l11l1l_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ殎")
		elif l111lllll1ll_l1_: l1l111ll11l1_l1_ = l11l1l_l1_ (u"ࠫࡴࡲࡤࠨ殏")
		else:
			l1l111ll11l1_l1_ = l11l1l_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ殐")
			l11l1l11111_l1_ = False
		l1l1l1l1l11l_l1_[addon_id] = (l11l1l11111_l1_,l1l11111lll1_l1_,l1l11ll11l11_l1_,l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l1l111ll11l1_l1_,l11ll11l11ll_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ殑"),l11l1l_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭殒"),l1l1l1l1l11l_l1_,REGULAR_CACHE)
	return l1l1l1l1l11l_l1_
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࠣࡪࡨࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠱࡯ࡳࡠࡧࡻ࡭ࡸࡺࠬࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡࡸࡨࡶࡸ࡯࡯࡯࠮ࡗࡶࡺ࡫ࠬࡕࡴࡸࡩࠒࠐࠉࠤࡧ࡯ࡷࡪࡀࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠬࡪࡵࡢࡩࡽ࡯ࡳࡵ࠮࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣࠫࠬ࠲ࡆࡢ࡮ࡶࡩ࠱ࡌࡡ࡭ࡵࡨࠑࠏࠏࠣࡪࡵࡢࡩࡽ࡯ࡳࡵࠢࡀࠤ࠭ࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡃࡰࡰࡧ࡚࡮ࡹࡩࡣ࡫࡯࡭ࡹࡿࠨࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠫࠪ࠭ࡂࡃ࠱ࠪࠏࠍࠍࠨ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡂࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡄࠧࠨࠏࠍࠍࠨ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦࠨࡹࡤࡰࡧ࠳࡭ࡥࡵࡅࡲࡲࡩ࡜ࡩࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠪࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡋࡶࡉࡳࡧࡢ࡭ࡧࡧࠬࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠬࠫ࠮ࡃ࠽࠲ࠫࠐࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࡳࡵࡴࠡࠪ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡣࡱࡨࠥࡴ࡯ࡵࠢ࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡫࡭࡬࡮ࡥࡴࡶࡢࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨࠍࠎ࠭ࠫࡴࡶࡵࠬ࡭࡯ࡧࡩࡧࡶࡸࡤࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨࠎࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡵ࡬ࡥࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡰ࡮ࡧ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧ࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩࠎࠏࠧࠬࡵࡷࡶ࠭ࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠋࠌࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡹࡴࡢࡶࡸࡷ࠮࠯ࠍࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡹࡩࡷࡹࡩࡰࡰࡶ࠾ࠥࠦࠧࠬࡵࡷࡶ࠭ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࠬ࠯ࠬࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡼ࡮ࡹࡴࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠪࠫࠐࠎࠎࠨࠢࠣ殓")
def PROGRESS_UPDATE(l11l1l111l_l1_,l11111ll11l1_l1_,l111l1l11111_l1_=l11l1l_l1_ (u"ࠩࠪ殔"),line2=l11l1l_l1_ (u"ࠪࠫ殕"),l111l1l1111l_l1_=l11l1l_l1_ (u"ࠫࠬ殖")):
	if kodi_version<19: l11l1l111l_l1_.update(l11111ll11l1_l1_,l111l1l11111_l1_,line2,l111l1l1111l_l1_)
	else: l11l1l111l_l1_.update(l11111ll11l1_l1_,l111l1l11111_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ殗")+line2+l11l1l_l1_ (u"࠭࡜࡯ࠩ殘")+l111l1l1111l_l1_)
	return
def l1ll11111l1l_l1_(l1ll11ll1l1l_l1_):
	# l111ll111l11_l1_ it for this:  function(p,a,c,k,e,d)
	# l1l1ll1lll1l_l1_ l1lll1l1l111l_l1_:  https://l1lllll111l1l_l1_.io
	def l1lllllll1lll_l1_(num,b,l1lll1ll11111_l1_=l11l1l_l1_ (u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠢ殙")):
		return ((num == 0) and l1lll1ll11111_l1_[0]) or (l1lllllll1lll_l1_(num // b, b, l1lll1ll11111_l1_).lstrip(l1lll1ll11111_l1_[0]) + l1lll1ll11111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11l1l_l1_ (u"ࠣ࡞࡟ࡦࠧ殚") + l1lllllll1lll_l1_(c, a) + l11l1l_l1_ (u"ࠤ࡟ࡠࡧࠨ殛"),  k[c], p)
		return p
	l1ll11ll1l1l_l1_ = l1ll11ll1l1l_l1_.split(l11l1l_l1_ (u"ࠪࢁ࠭࠭殜"))[1][:-1]
	l1l1llll1l11_l1_ = eval(l11l1l_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬ殝")+l1ll11ll1l1l_l1_,{l11l1l_l1_ (u"ࠬࡨࡡࡴࡧࡑࠫ殞"):l1lllllll1lll_l1_,l11l1l_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭殟"):unpack})   #,locals())
	return l1l1llll1l11_l1_
def l1ll11llll_l1_(url,l1llll1lll1ll_l1_=l11l1l_l1_ (u"ࠧࠨ殠")):
	if l1llll1lll1ll_l1_==l11l1l_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧ殡"): url = re.sub(l11l1l_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩ殢"),lambda l11l111111ll_l1_: l11l111111ll_l1_.group(0).lower(),url)
	elif l1llll1lll1ll_l1_==l11l1l_l1_ (u"ࠪࡹࡵࡶࡥࡳࠩ殣"): url = re.sub(l11l1l_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫ殤"),lambda l11l111111ll_l1_: l11l111111ll_l1_.group(0).upper(),url)
	return url
def l11lll11l1ll_l1_(l111ll1ll1l1_l1_):
	installed,l11111l11l11_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l111llll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll1ll1l1_l1_)==1: l1lllll1llll1_l1_ = l11l1l_l1_ (u"ࠬ࠮ࠢࠨ殥")+l111ll1ll1l1_l1_[0]+l11l1l_l1_ (u"࠭ࠢࠪࠩ殦")
	else: l1lllll1llll1_l1_ = str(tuple(l111ll1ll1l1_l1_))
	cc.execute(l11l1l_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧ殧")+l1lllll1llll1_l1_+l11l1l_l1_ (u"ࠨࠢ࠾ࠫ殨"))
	l11lllll11l1_l1_ = cc.fetchall()
	l1l11l111l11_l1_ = {}
	for addon_id in l111ll1ll1l1_l1_: l1l11l111l11_l1_[addon_id] = (False,False)
	for addon_id,l11111l11l11_l1_ in l11lllll11l1_l1_:
		installed = True
		l11111l11l11_l1_ = l11111l11l11_l1_==1
		l1l11l111l11_l1_[addon_id] = (installed,l11111l11l11_l1_)
	conn.close()
	return l1l11l111l11_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	if file==l1l11ll1l11l_l1_: l11l11l11ll_l1_(False)
	else: results = {}
	if os.path.exists(file):
		l11lll1lll1l_l1_ = open(file,l11l1l_l1_ (u"ࠩࡵࡦࠬ殩")).read()
		if kodi_version>18.99: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ殪"))
		if file==l1l11ll1l11l_l1_: results = l11lll1lll1l_l1_
		else:
			l1111l111l11_l1_ = EVAL(l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ殫"),l11lll1lll1l_l1_)
			if l1111l111l11_l1_:
				for key in l1111l111l11_l1_.keys():
					results[key] = []
					for l11111111l11_l1_ in l1111l111l11_l1_[key]:
						type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_ = l11l1l_l1_ (u"ࠬ࠭殬"),l11l1l_l1_ (u"࠭ࠧ殭"),l11l1l_l1_ (u"ࠧࠨ殮"),l11l1l_l1_ (u"ࠨࠩ殯"),l11l1l_l1_ (u"ࠩࠪ殰"),l11l1l_l1_ (u"ࠪࠫ殱"),l11l1l_l1_ (u"ࠫࠬ殲"),l11l1l_l1_ (u"ࠬ࠭殳"),l11l1l_l1_ (u"࠭ࠧ殴")
						type = l11111111l11_l1_[0]
						name = l11111111l11_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l11111111l11_l1_[2]
						mode = l11111111l11_l1_[3]
						l111_l1_ = l11111111l11_l1_[4]
						l11llll_l1_ = l11111111l11_l1_[5]
						if len(l11111111l11_l1_)>6: text = l11111111l11_l1_[6]
						if len(l11111111l11_l1_)>7: context = l11111111l11_l1_[7]
						if len(l11111111l11_l1_)>8: l1ll1l1lll1_l1_ = l11111111l11_l1_[8]
						if file==favoritesfile: l1ll1lll1llll_l1_ = type,name,url,mode,l111_l1_,l11llll_l1_,text,l11l1l_l1_ (u"ࠧࠨ段"),l1ll1l1lll1_l1_
						else: l1ll1lll1llll_l1_ = type,name,url,mode,l111_l1_,l11llll_l1_,text,context,l1ll1l1lll1_l1_
						results[key].append(l1ll1lll1llll_l1_)
			l11ll1llll11_l1_ = str(results)
			if kodi_version>18.99: l11ll1llll11_l1_ = l11ll1llll11_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭殶"))
			open(file,l11l1l_l1_ (u"ࠩࡺࡦࠬ殷")).write(l11ll1llll11_l1_)
	return results
def l1l1lll1l1l_l1_(l1ll11111l1_l1_):
	l1l1llll1l1_l1_ = l1ll11111l1_l1_.split(l11l1l_l1_ (u"ࠪ࠱ࠬ殸"),1)[0]
	l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_ = l11l1l_l1_ (u"ࠫࠬ殹"),l11l1l_l1_ (u"ࠬ࠭殺"),l11l1l_l1_ (u"࠭ࠧ殻")
	if   l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭殼")		:	from l11lll1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ殽")	:	from l1l11l11_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ殾")		:	from l1llll11_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ殿")	:	from l1111ll1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭毀")	:	from l1ll111l1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ毁")	: 	from l1l1l1l11_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ毂")	:	from l1l1l11ll_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ毃")	:	from l11l111l1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ毄")		:	from l1111111l_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ毅")	:	from l1llll1lll_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ毆")	:	from l1ll1lll1l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭毇")	:	from l1ll1l1l1l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ毈")	:	from l1ll1l111l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ毉"):	from l11ll111l11l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭毊")		:	from l1ll11ll11l_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ毋")		:	from l1ll11l_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ毌")	:	from l1ll1l1l111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ母")	:	from l1ll1llll1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ毎")	:	from l11ll111111l_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭每")	:	from l1lllll11l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭毐")	:	from l1l11llllll_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ毑")	:	from l1lllll1l1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ毒")		:	from l11l1ll1ll11_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ毓")	:	from l1l1l1l1111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ比"):	from l1l11l111_l1_	import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ毕")	:	from l111ll11l1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭毖")	:	from l1ll1l1111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ毗"):	from l11ll1llll_l1_	import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ毘")	:	from l111111l1l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ毙")	:	from l1lll1l1lll_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ毚")	:	from l1lll1l1ll1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭毛")	:	from l1ll1l11l11_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭毜")	:	from l1l1lll1111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ毝")	:	from l1lll11111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ毞")		:	from l1l1ll1llll_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ毟")		:	from IPTV			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,menu_namee as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡏ࠶࡙ࠬ毠")		:	from l1l111ll1l1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ毡")	:	from l1l1l1l1ll1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ毢")	:	from l1l11lll111_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ毣")	:	from l111llll111_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ毤")	:	from l111lll1ll1_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭毥")	:	from l1l1lll1l111_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ毦")	:	from l1ll1l111l1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ毧")	:	from l1ll11ll1ll_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ毨")		:	from l111lll1l1l_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ毩")	:	from l1l1lll111l1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ毪")	:	from l11ll1111l11_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ毫")	:	from l11l1lll1ll1_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ毬")	:	from l1l1ll111lll_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭毭")		:	from l1ll1ll1ll11_l1_			import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ毮")	:	from l111111ll1l_l1_		import MENU as l1l1llll11l_l1_,SEARCH as l1ll111111l_l1_,l1111l_l1_ as l1ll11l1lll_l1_
	elif l1l1llll1l1_l1_==l11l1l_l1_ (u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ毯"):	from l11l111ll1ll_l1_	import MENU as l1l1llll11l_l1_
	return l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1ll1ll11l11l_l1_,headers={},l1ll_l1_=True):
	#l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫ毰"),l11l1l_l1_ (u"ࠫࠬ毱"),l11l1l_l1_ (u"ࠬ࠭毲"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ毳"),l11l1l_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฽ไ้ส้๋ࠣࠦวๅว้ฮึ์ส๊ࠡๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠢࠩ毴"))
	#if l1ll11111l_l1_!=1: return l11l1l_l1_ (u"ࠨࠩ毵")
	LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ毶"),l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩ毷")+l1ll1ll11l11l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ毸")+str(headers)+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ毹"))
	l11l1l111l_l1_ = DIALOG_PROGRESS()
	l11l1l111l_l1_.create(l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ毺"),l11l1l_l1_ (u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ毻"))
	l11l1llll1_l1_ = 1024*1024
	l111ll1l11ll_l1_ = bytes()
	chunk_size = 1*l11l1llll1_l1_
	import requests
	response = requests.get(l1ll1ll11l11l_l1_,stream=True,headers=headers)
	l1lll111l1lll_l1_ = response.headers
	response.close()
	if l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ毼") not in list(l1lll111l1lll_l1_.keys()):
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ毽"),l11l1l_l1_ (u"ࠪࠫ毾"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ毿"),l11l1l_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨ氀"))
		l11l1l111l_l1_.close()
		return l11l1l_l1_ (u"࠭ࠧ氁")
	filesize = int(l1lll111l1lll_l1_[l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ氂")])
	l11l1ll111_l1_ = str(int(1000*filesize/l11l1llll1_l1_)/1000.0)
	l11l1111ll_l1_ = int(filesize/chunk_size)+1
	if l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨ氃") in list(l1lll111l1lll_l1_.keys()) and filesize>l11l1llll1_l1_:
		l1lll11ll11l1_l1_ = True
		ranges = []
		l1lll1l111111_l1_ = 10
		ranges.append(str(0*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠩ࠰ࠫ氄")+str(1*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(1*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠪ࠱ࠬ氅")+str(2*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(2*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠫ࠲࠭氆")+str(3*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(3*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠬ࠳ࠧ氇")+str(4*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(4*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"࠭࠭ࠨ氈")+str(5*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(5*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠧ࠮ࠩ氉")+str(6*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(6*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠨ࠯ࠪ氊")+str(7*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(7*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠩ࠰ࠫ氋")+str(8*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(8*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠪ࠱ࠬ氌")+str(9*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(9*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠫ࠲࠭氍"))
		l111lll11l11_l1_ = float(l11l1111ll_l1_)/l1lll1l111111_l1_
		l111111l1l11_l1_ = l111lll11l11_l1_/int(1+l111lll11l11_l1_)
	else:
		l1lll11ll11l1_l1_ = False
		l1lll1l111111_l1_ = 1
		l111111l1l11_l1_ = 1
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ氎"),l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨ氏")+str(l1lll11ll11l1_l1_)+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ氐")+str(filesize)+l11l1l_l1_ (u"ࠨࠢࡠࠫ民"))
	l11l1ll1l1_l1_ = 0
	#t1 = time.time()-30
	for l11llll1lll_l1_ in range(l1lll1l111111_l1_):
		l1l1l1lll_l1_ = headers
		if l1lll11ll11l1_l1_: l1l1l1lll_l1_[l11l1l_l1_ (u"ࠩࡕࡥࡳ࡭ࡥࠨ氒")] = l11l1l_l1_ (u"ࠪࡦࡾࡺࡥࡴ࠿ࠪ氓")+ranges[l11llll1lll_l1_]
		response = requests.get(l1ll1ll11l11l_l1_,stream=True,headers=l1l1l1lll_l1_,timeout=300)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if l11l1l111l_l1_.iscanceled():
				LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ气"),l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭氕"))
				break
			l11l1ll1l1_l1_ += l111111l1l11_l1_
			PROGRESS_UPDATE(l11l1l111l_l1_,0+int(100*l11l1ll1l1_l1_/l11l1111ll_l1_),l11l1l_l1_ (u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ氖"),str(int(l11l1ll1l1_l1_*chunk_size//l11l1llll1_l1_))+l11l1l_l1_ (u"ࠧࠡ࠱ࠣࠫ気")+l11l1ll111_l1_+l11l1l_l1_ (u"ࠨࠢࡐࡆࠬ氘"))
			l111ll1l11ll_l1_ += chunk
			#PROGRESS_UPDATE(l11l1l111l_l1_,0+int(35*l11l1ll1l1_l1_/l11l1111ll_l1_),l11l1l_l1_ (u"ࠩฯ่อࠦวๅ็็ๅࠥอไาศํื๏ࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ氙")+l11l1l_l1_ (u"ࠪࡠࡳ࠭氚")+str(l11l1ll1l1_l1_*chunksize/l11l1llll1_l1_)+l11l1l_l1_ (u"ࠫࠥ࠵ࠠࠨ氛")+l11l1ll111_l1_+l11l1l_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪ氜")+time.strftime(l11l1l_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣ氝")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ氞")+time.gmtime(l111llll1l_l1_))+l11l1l_l1_ (u"ࠨࠢใࠫ氟"))
			#l111lll1l1_l1_ = time.time()
			#l111ll1ll1_l1_ = l111lll1l1_l1_-t1
			#l111lll11l_l1_ = l111ll1ll1_l1_/l11l1ll1l1_l1_
			#l11l11l1ll_l1_ = l111lll11l_l1_*(l11l1111ll_l1_+1)
			#l111llll1l_l1_ = l11l11l1ll_l1_-l111ll1ll1_l1_
		response.close()
	l11l1l111l_l1_.close()
	if len(l111ll1l11ll_l1_)<filesize:
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ氠"),l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ氡")+str(len(l111ll1l11ll_l1_)//l11l1llll1_l1_)+l11l1l_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩ氢")+l11l1ll111_l1_+l11l1l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ氣"))
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"࠭ࠧ氤"),l11l1l_l1_ (u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬ氥"),l11l1l_l1_ (u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨ氦"),l11l1l_l1_ (u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫ氧"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭氨"),l11l1l_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨ氩")+str(len(l111ll1l11ll_l1_)//l11l1llll1_l1_)+l11l1l_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫ氪")+l11l1ll111_l1_+l11l1l_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨ氫"))
		if choice==2: l111ll1l11ll_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1ll1ll11l11l_l1_,headers)
		elif choice==1: LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ氬"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ氭"))
		else: return l11l1l_l1_ (u"ࠩࠪ氮")
		if not l111ll1l11ll_l1_: return l11l1l_l1_ (u"ࠪࠫ氯")
	else: LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ氰"),l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ氱")+l11l1ll111_l1_+l11l1l_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ氲"))
	return l111ll1l11ll_l1_
def l11l1111llll_l1_(l1ll1_l1_):
	# https://www.l1lll1l1l111_l1_.l1ll1ll1l1l11_l1_.l11111l1111l_l1_.com/l1lllll111lll_l1_/l1ll1lll1l1l1_l1_/http-l1lll1l1ll1ll_l1_-l1lllll1ll1l_l1_
	# https://help.l11111l1111l_l1_.com/l1ll1lll1l111_l1_/l1lll11llll1_l1_-l1lll1ll11l_l1_/l1111ll1llll_l1_/215562387-l1ll1llll11ll_l1_-property-l111l111l1l1_l1_
	# https://www.l1lll1l1l111_l1_.l1ll1ll1l1l11_l1_.l11111l1111l_l1_.com/l1lllll111lll_l1_/l1ll1lll1l1l1_l1_/l1lll1llll1ll_l1_-rest-l1lllll1ll1l_l1_
	l1ll1lll1111l_l1_ = str(random.randrange(111111111111,999999999999))
	#l1l1111111ll_l1_ = l11ll11llll1_l1_()
	#l111llllll11_l1_ = l1l1111111ll_l1_.split(l11l1l_l1_ (u"ࠧ࠭ࠩ氳"),1)[0]
	headers = {l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ水"):l11l1l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ氵")}
	data = {l11l1l_l1_ (u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ氶"):l11l1l_l1_ (u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩ氷"),
			l11l1l_l1_ (u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤࠣ永"):l1ll1lll1111l_l1_,
			l11l1l_l1_ (u"ࠨࡥࡷࡧࡱࡸࡸࠨ氹"): [{
				l11l1l_l1_ (u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣ氺"):l1l11llll11_l1_(32),
				l11l1l_l1_ (u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ氻"):str(kodi_version),
				l11l1l_l1_ (u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ氼"):addon_version,
				l11l1l_l1_ (u"ࠥࡧࡦࡸࡲࡪࡧࡵࠦ氽"):addon_version,
				l11l1l_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣ氾"):l1ll1_l1_,
				l11l1l_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ氿"):{l11l1l_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ汀"):l1ll1_l1_},
				l11l1l_l1_ (u"ࠢࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ汁"): {l11l1l_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ求"):l1ll1_l1_},
				l11l1l_l1_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࠦ汃"): l11l1l_l1_ (u"ࠥࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࠥ汄"),
				l11l1l_l1_ (u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥ汅"):False,
				l11l1l_l1_ (u"ࠧ࡯ࡰࠣ汆"): l11l1l_l1_ (u"ࠨࠤࡳࡧࡰࡳࡹ࡫ࠢ汇")
			}]
		}
	url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩ汈")
	import json
	data = json.dumps(data)
	response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭汉"),url,data,headers,l11l1l_l1_ (u"ࠩࠪ汊"),l11l1l_l1_ (u"ࠪࠫ汋"),l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ汌"),False,False)
	return response
def l111111l1lll_l1_(l1ll1_l1_):
	# old l11111l11l1l_l1_ l1llll1lllll1_l1_ l1l1lllll11l_l1_
	# hit method:    https://l1ll1ll1l1l11_l1_.l1l1ll1l1ll1_l1_.com/l1lllll111lll_l1_/l1llllll11lll_l1_/collection/protocol/l1l1lllll11l_l1_/l1lllllll1111_l1_
	#url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳ࡩ࡯࡮࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡺࡂ࠷ࠦࡵ࡫ࡧࡁ࡚ࡇ࠭࠲࠴࠺࠴࠹࠻࠱࠱࠶࠰࠹ࠫࡩࡩࡥ࠿ࠪ汍")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"࠭ࠦࡵ࠿ࡨࡺࡪࡴࡴࠧࡵࡦࡁࡪࡴࡤࠧࡧࡦࡁࠬ汎")+addon_version+l11l1l_l1_ (u"ࠧࠧࡣࡹࡁࠬ汏")+addon_version+l11l1l_l1_ (u"ࠨࠨࡤࡲࡂࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࡤࡔࡅࡘࡅࡏࡍࡊࡔࡔࡊࡆࠩࡩࡦࡃࠧ汐")+l1ll1_l1_+l11l1l_l1_ (u"ࠩࠩࡩࡱࡃࠧ汑")+str(kodi_version)+l11l1l_l1_ (u"ࠪࠪࡿࡃࠧ汒")+l1ll1lll1111l_l1_
	#response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ汓"),url,l11l1l_l1_ (u"ࠬ࠭汔"),l11l1l_l1_ (u"࠭ࠧ汕"),l11l1l_l1_ (u"ࠧࠨ汖"),l11l1l_l1_ (u"ࠨࠩ汗"),l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ汘"))
	# new l1llllllllll1_l1_ l1llll1lllll1_l1_ 4
	# l1lll1ll111l1_l1_ test:    https://l1l11llll111_l1_-l11lll1l11ll_l1_-l11lllll1ll1_l1_.l1l1ll1l1ll1_l1_/l1llll1l11111_l1_/l1111l1ll1l1_l1_-l1lll1l1l1l1l_l1_
	# l1lll1ll111l1_l1_ json method:    https://l1ll1ll1l1l11_l1_.l1l1ll1l1ll1_l1_.com/l1lllll111lll_l1_/l1llllll11lll_l1_/collection/protocol/l1llll1l11111_l1_/l1lllll11l1l1_l1_/l1lll1ll111l1_l1_
	# l1lll1ll111l1_l1_ json method:    https://l1ll1ll1l1l11_l1_.l1l1ll1l1ll1_l1_.com/l1lllll111lll_l1_/l1llllll11lll_l1_/collection/protocol/l1llll1l11111_l1_/l1lllll11l1l1_l1_?l1lll111ll1ll_l1_=l1ll1lllll111_l1_
	# l1lll1ll111l1_l1_ hit method:   https://www.l11111lll111_l1_.com/l1llll1l11111_l1_-l1111l1lll11_l1_-protocol-l1111111llll_l1_
	# l1lll1ll111l1_l1_ hit method:   https://www.l11111lll111_l1_.com/l1llllll1111_l1_-l1lll1ll11l11_l1_-l1l1ll1l1ll1_l1_-l1lllll111lll_l1_-l1111l1lll11_l1_-protocol-version-2
	# l1lll1ll111l1_l1_ params:  https://data.l1lll1111l111_l1_.com
	# l1lll1l1lll1l_l1_ json method
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰࡯ࡳ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡧࡰࡪࡡࡶࡩࡨࡸࡥࡵ࠿࠳࠱ࡻ࠷࠵ࡂࡦࡦࡖࡌࡧࡐࡨࡳࡵࡳ࡬ࡲ࠵࠺ࡍࡄࠪࡲ࡫ࡡࡴࡷࡵࡩࡲ࡫࡮ࡵࡡ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠫ汙")
	#headers = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ汚"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ汛")}
	#params = {l11l1l_l1_ (u"࠭ࡡࡱࡲࡢࡺࡪࡸࡳࡪࡱࡱࠫ汜"):addon_version,l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡡࡹࡩࡷࡹࡩࡰࡰࠪ汝"):kodi_version}
	#data = {l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡠ࡫ࡧࠫ汞"):l1l11llll11_l1_(32),l11l1l_l1_ (u"ࠩࡨࡺࡪࡴࡴࡴࠩ江"):[{l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ池"):l1ll1_l1_,l11l1l_l1_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ污"):params}]}
	#response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ汢"),url,str(data),headers,l11l1l_l1_ (u"࠭ࠧ汣"),l11l1l_l1_ (u"ࠧࠨ汤"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭汥"))
	l11l1l_l1_ (u"ࠤࠥࠦࠒࠐࠉࡦࡸࡨࡲࡹࡔࡡ࡮ࡧࠐࠎࠎࡧࡰࡱࡘࡨࡶࡸ࡯࡯࡯ࠏࠍࠍࡴࡶࡥࡳࡣࡷ࡭ࡳ࡭ࡓࡺࡵࡷࡩࡲ࡜ࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡷࡤࡴࡻࠓࠊࠊࡷࡶࡩࡷࡥࡩࡥࠏࠍࠍࡦࡶࡰࡠࡸࡨࡶࡸ࡯࡯࡯ࠏࠍࠍࡵࡲࡡࡵࡨࡲࡶࡲࡥࡶࡦࡴࡶ࡭ࡴࡴࠍࠋࠋࡨࡺࡪࡴࡴࡠࡰࡤࡱࡪࠓࠊࠊࠤࠥࠦ汦")
	# l1lll1l1lll1l_l1_ hit method (l11l111lll_l1_ l1111l1l1ll1_l1_ l1lll111l1ll1_l1_)
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡩ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠲ࠧࡶ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠪࡨ࡯ࡤ࠾ࠩ汧")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"ࠫࠫࡥࡳ࠾࠳ࠩࡩࡳࡃࠧ汨")+l1ll1_l1_+l11l1l_l1_ (u"ࠬࠬࡵࡱ࠰ࡤࡺࡤࡼࡥࡳ࠿ࠪ汩")+addon_version+l11l1l_l1_ (u"࠭ࠦࡶࡲ࠱࡯ࡴࡪࡩࡠࡸࡨࡶࡂ࠭汪")+str(kodi_version)
	#url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡩ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠲ࠧࡶ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠪࡤࡪࡢࡨ࠿࠴ࠪࡨ࡯ࡤ࠾࠳࠻࠹࠻࠶࠴࠹࠶࠼࠻࠳࠷࠶࠺࠲࠴࠸࠺࠺࠵࠸ࠩ汫")
	#l1ll1lll1111l_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡪ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠳ࠨࡷ࡭ࡩࡃࡇ࠮ࡔࡓ࠻ࡖ࡟ࡅࡋ࠻ࡊ࠽ࠫࡥࡤࡣࡩࡀ࠵ࠫࡩࡩࡥ࠿ࠪ汬")+str(l1ll1lll1111l_l1_)+l11l1l_l1_ (u"ࠩ࠱ࠫ汭")+str(int(time.time()))
	#url += l11l1l_l1_ (u"ࠪࠪࡺࡧࡰࡷ࠿࠴࠽࠳࠷ࠦࡥࡶࡀࡏࡔࡊࡉࠦ࠴࠳ࡉࡒࡇࡄࠧࡧࡱࡁࡵࡧࡧࡦࡡࡹ࡭ࡪࡽࠦࡠࡧࡨࡁ࠶ࠬࡵࡪࡦࡀ࠶࠷࠸࠲࠮࠴࠵࠶࠷࠳࠳࠴࠵࠶ࠪࡤࡹࡳ࠾࠳ࠪ汮")
	#response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ汯"),url,l11l1l_l1_ (u"ࠬ࠭汰"),l11l1l_l1_ (u"࠭ࠧ汱"),l11l1l_l1_ (u"ࠧࠨ汲"),l11l1l_l1_ (u"ࠨࠩ汳"),l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ汴"))
	# l1lll1l1lll1l_l1_ modified (not good l1llll1lll1l1_l1_)
	#l1ll1lll1111l_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡩ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠲ࠧࡶ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠪࡨ࡯ࡤ࠾ࠩ汵")+l1l11llll11_l1_(32)+l11l1l_l1_ (u"ࠫࠫࡥࡳ࠾࠳ࠩࡩࡳࡃࠧ汶")+l1ll1_l1_+l11l1l_l1_ (u"ࠬࠬࡵࡱ࠰ࡤࡺࡤࡼࡥࡳ࠿ࠪ汷")+addon_version+l11l1l_l1_ (u"࠭ࠦࡶࡣࡳࡺࡂ࠭汸")+str(kodi_version)+l11l1l_l1_ (u"ࠧࠧࡡࡳࡁࠬ汹")+l1ll1lll1111l_l1_
	#l1l1111111ll_l1_ = l11ll11llll1_l1_()
	#l1ll11111l11_l1_ = l1l1111111ll_l1_.split(l11l1l_l1_ (u"ࠨ࠮ࠪ決"),1)[0]
	return response
def l11ll11llll1_l1_(l1ll11111l11_l1_=l11l1l_l1_ (u"ࠩࠪ汻")):
	l1lll11llll11_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ汼"),l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ汽"),l11l1l_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ汾"))
	if l1lll11llll11_l1_: return l1lll11llll11_l1_
	# url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲ࡯ࡳࡨࡧࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ汿")
	# l1l1lllll11l_l1_   url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡻ࡭ࡵࡩࡴ࠰ࡤࡴࡵ࠵ࡪࡴࡱࡱ࠳ࠬ沀")+l1ll11111l11_l1_
	# l1lll1l1ll1ll_l1_   url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭沁")
	l1ll11111l11_l1_,l1lll1l111l11_l1_,l11llll1111_l1_,l11l111l11ll_l1_,l1llll1l1l11l_l1_,l1111l11l1l1_l1_,timezone = l11l1l_l1_ (u"ࠩࠪ沂"),l11l1l_l1_ (u"ࠪࠫ沃"),l11l1l_l1_ (u"ࠫࠬ沄"),l11l1l_l1_ (u"ࠬ࠭沅"),l11l1l_l1_ (u"࠭ࠧ沆"),l11l1l_l1_ (u"ࠧࠨ沇"),l11l1l_l1_ (u"ࠨࠩ沈")
	url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬ沉")+l1ll11111l11_l1_+l11l1l_l1_ (u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ沊")
	response = l1lll1111ll1_l1_(l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ沋"),url,l11l1l_l1_ (u"ࠬ࠭沌"),l11l1l_l1_ (u"࠭ࠧ沍"),l11l1l_l1_ (u"ࠧࠨ沎"),l11l1l_l1_ (u"ࠨࠩ沏"),l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ沐"))
	if not response.succeeded: l11llll1llll_l1_ = l1ll11111l11_l1_+l11l1l_l1_ (u"ࠪ࠰ࠬ沑")+l1lll1l111l11_l1_+l11l1l_l1_ (u"ࠫ࠱࠭沒")+l11llll1111_l1_+l11l1l_l1_ (u"ࠬ࠲ࠧ沓")+l1llll1l1l11l_l1_+l11l1l_l1_ (u"࠭ࠬࠨ沔")+l1111l11l1l1_l1_+l11l1l_l1_ (u"ࠧ࠭ࠩ沕")+timezone
	else:
		html = response.content
		l111l11ll1ll_l1_ = EVAL(l11l1l_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭沖"),html)
		if l11l1l_l1_ (u"ࠩ࡬ࡴࠬ沗") in list(l111l11ll1ll_l1_.keys()): l1ll11111l11_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠪ࡭ࡵ࠭沘")]
		if l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ沙") in list(l111l11ll1ll_l1_.keys()): l1lll1l111l11_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨ沚")]
		if l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ沛") in list(l111l11ll1ll_l1_.keys()): l11llll1111_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ沜")]
		if l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧ沝") in list(l111l11ll1ll_l1_.keys()): l11l111l11ll_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨ沞")]
		if l11l1l_l1_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ沟") in list(l111l11ll1ll_l1_.keys()): l1llll1l1l11l_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠫࡷ࡫ࡧࡪࡱࡱࠫ沠")]
		if l11l1l_l1_ (u"ࠬࡩࡩࡵࡻࠪ没") in list(l111l11ll1ll_l1_.keys()): l1111l11l1l1_l1_ = l111l11ll1ll_l1_[l11l1l_l1_ (u"࠭ࡣࡪࡶࡼࠫ沢")]
		if l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ沣") in list(l111l11ll1ll_l1_.keys()):
			timezone = l111l11ll1ll_l1_[l11l1l_l1_ (u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ沤")][l11l1l_l1_ (u"ࠩࡸࡸࡨ࠭沥")]
			if timezone[0] not in [l11l1l_l1_ (u"ࠪ࠱ࠬ沦"),l11l1l_l1_ (u"ࠫ࠰࠭沧")]: timezone = l11l1l_l1_ (u"ࠬ࠱ࠧ沨")+timezone
		l11llll1llll_l1_ = l1ll11111l11_l1_+l11l1l_l1_ (u"࠭ࠬࠨ沩")+l1lll1l111l11_l1_+l11l1l_l1_ (u"ࠧ࠭ࠩ沪")+l11llll1111_l1_+l11l1l_l1_ (u"ࠨ࠮ࠪ沫")+l1llll1l1l11l_l1_+l11l1l_l1_ (u"ࠩ࠯ࠫ沬")+l1111l11l1l1_l1_+l11l1l_l1_ (u"ࠪ࠰ࠬ沭")+timezone
		if kodi_version>18.99: l11llll1llll_l1_ = l11llll1llll_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ沮")).decode(l11l1l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭沯"))
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ沰"),l11l1l_l1_ (u"ࠧࡊࡒࡏࡓࡈࡇࡔࡊࡑࡑࠫ沱"),l11llll1llll_l1_,l1ll1ll11_l1_)
	return l11llll1llll_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11l1l_l1_ (u"ࠨࠩ沲"),True
	if search.count(l11l1l_l1_ (u"ࠩࡢࠫ河"))>=2:
		search,options = search.split(l11l1l_l1_ (u"ࠪࡣࠬ沴"),1)
		options = l11l1l_l1_ (u"ࠫࡤ࠭沵")+options
		if l11l1l_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ沶") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ沷"),l11l1l_l1_ (u"ࠧࠨ沸"),search,options)
	return search,options,l1ll_l1_
def l1ll1lllll11l_l1_():
	l1llll1111l1l_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ油"))
	l111l111l11l_l1_ = 0
	if os.path.exists(l1llll1111l1l_l1_):
		for filename in os.listdir(l1llll1111l1l_l1_):
			if l11l1l_l1_ (u"ࠩ࠱ࡴࡾࡵࠧ沺") in filename: continue
			if l11l1l_l1_ (u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨ治") in filename: continue
			l1l111lll1_l1_ = os.path.join(l1llll1111l1l_l1_,filename)
			size,count = l1l1l1111l_l1_(l1l111lll1_l1_)
			l111l111l11l_l1_ += size
	return l111l111l11l_l1_
def l11l11l11ll_l1_(l1ll_l1_):
	url = l1l1ll1_l1_[l11l1l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ沼")][3]
	l1lll111ll11l_l1_ = l1l11llll11_l1_(32)
	l11llll1llll_l1_ = l11ll11llll1_l1_()
	l11llll1111_l1_ = l11llll1llll_l1_.split(l11l1l_l1_ (u"ࠬ࠲ࠧ沽"))[2]
	l111l111l11l_l1_ = l1ll1lllll11l_l1_()
	payload = {l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࠫ沾"):l1lll111ll11l_l1_,l11l1l_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ沿"):addon_version,l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ泀"):l11llll1111_l1_,l11l1l_l1_ (u"ࠩ࡬ࡨࡸ࠭況"):l1lll1lllllll_l1_(l111l111l11l_l1_)}
	if l1ll_l1_: DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭泂"),(l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ泃"),url,payload,l11l1l_l1_ (u"ࠬ࠭泄"),l11l1l_l1_ (u"࠭ࠧ泅"),l11l1l_l1_ (u"ࠧࠨ泆")))
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ泇"),l11l1l_l1_ (u"ࠩࠪ泈"))
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ泉"),url,payload,l11l1l_l1_ (u"ࠫࠬ泊"),l11l1l_l1_ (u"ࠬ࠭泋"),l11l1l_l1_ (u"࠭ࠧ泌"),l11l1l_l1_ (u"ࠧࡎࡇࡑ࡙ࡘ࠳ࡓࡉࡑ࡚ࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪ泍"),True,True)
	if not response.succeeded: l11l11l1l11_l1_ = l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘࠧ泎")
	else:
		l111llll1lll_l1_,l1111l111111_l1_,l1111l11l11l_l1_,l1111l1111l1_l1_ = l11l1l_l1_ (u"ࠩࠪ泏"),l11l1l_l1_ (u"ࠪࠫ泐"),l11l1l_l1_ (u"ࠫࠬ泑"),[]
		newfile = response.content
		if newfile:
			l1111l1111l1_l1_ = EVAL(l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ泒"),newfile)
			for l1llllll11111_l1_,l1lll1l11l111_l1_,message in l1111l1111l1_l1_:
				if kodi_version>18.99: message = message.encode(l11l1l_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ泓")).decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ泔"))
				if l1llllll11111_l1_==l11l1l_l1_ (u"ࠨ࠲ࠪ法"): l111llll1lll_l1_ += message+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ泖")
				else: l1111l111111_l1_ += message+l11l1l_l1_ (u"ࠪࡠࡳ࠭泗")
			l1111l111111_l1_ = l1111l111111_l1_.strip(l11l1l_l1_ (u"ࠫࡡࡴࠧ泘"))
			l111llll1lll_l1_ = l111llll1lll_l1_.strip(l11l1l_l1_ (u"ࠬࡀ࠺ࠨ泙"))
		settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭泚"),l111llll1lll_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ泛"),l1lll1lllllll_l1_(now))
		if os.path.exists(l1l11ll1l11l_l1_): l1111l11l11l_l1_ = open(l1l11ll1l11l_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ泜")).read()
		if kodi_version>18.99: l1111l111111_l1_ = l1111l111111_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ泝"))
		if l1111l111111_l1_==l1111l11l11l_l1_: l11l11l1l11_l1_ = l11l1l_l1_ (u"ࠪࡓࡑࡊࠧ泞")
		else:
			l11l11l1l11_l1_ = l11l1l_l1_ (u"ࠫࡓࡋࡗࠨ泟")
			open(l1l11ll1l11l_l1_,l11l1l_l1_ (u"ࠬࡽࡢࠨ泠")).write(l1111l111111_l1_)
		if l1ll_l1_:
			l11l11l1l11_l1_ = l11l1l_l1_ (u"࠭ࡏࡍࡆࠪ泡")
			l1111l1111l1_l1_ = sorted(l1111l1111l1_l1_,reverse=True,key=lambda key: int(key[0]))
			l1l111l111ll_l1_ = l11l1l_l1_ (u"ࠧࠨ波")
			for l1llllll11111_l1_,l1lll1l11l111_l1_,message in l1111l1111l1_l1_:
				if kodi_version>18.99: message = message.encode(l11l1l_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭泣")).decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ泤"))
				if l1l111l111ll_l1_: l1l111l111ll_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ泥")
				if l1llllll11111_l1_==l11l1l_l1_ (u"ࠫ࠵࠭泦"): continue
				date = message.split(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ泧"))[0]
				l1lll11l1_l1_ = l11l1l_l1_ (u"࠭ࠧ注")
				if l1lll1l11l111_l1_:
					l1lll11l1_l1_ = l11l1l_l1_ (u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫ泩")
					if kodi_version>18.99: l1lll11l1_l1_ = l1lll11l1_l1_.encode(l11l1l_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭泪")).decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ泫"))
				l1l111l111ll_l1_ += message.replace(date,l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭泬")+date+l1lll11l1_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭泭"))+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ泮")
			l1l111l111ll_l1_ = escapeUNICODE(l1l111l111ll_l1_)
			l11ll111l1_l1_(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ泯"),l11l1l_l1_ (u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪ泰"),l1l111l111ll_l1_,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ泱"))
	settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ泲"),l11l11l1l11_l1_)
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ泳"))
	return l11l11l1l11_l1_
def l111ll1l1l11_l1_(type):
	if type==l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ泴"): data = {}
	elif type==l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ泵"): data = []
	elif type==l11l1l_l1_ (u"࠭ࡳࡵࡴࠪ泶"): data = l11l1l_l1_ (u"ࠧࠨ泷")
	elif type==l11l1l_l1_ (u"ࠨ࡫ࡱࡸࠬ泸"): data = 0
	elif type==l11l1l_l1_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ泹"): data = l1111llll11l_l1_()
	elif not type: data = None
	else: data = None
	return data
def l11l1l1ll1_l1_(url,l1l1l111_l1_=l11l1l_l1_ (u"ࠪࠫ泺")):
	l111ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭ࡢ࠮ࡢࡸ࡬ࢀࡡ࠴ࡴࡴࡾ࡟࠲ࡲࡶ࠴ࡽ࡞࠱ࡱ࠸ࡻࡼ࡝࠰ࡰ࠷ࡺ࠾ࡼ࡝࠰ࡰࡴࡩࢂ࡜࠯࡯࡮ࡺࢁࡢ࠮ࡧ࡮ࡹࢀࡡ࠴࡭ࡱ࠵ࡿࡠ࠳ࡽࡥࡣ࡯ࠬࠬࢁࡢ࠿࠯ࠬࡂࢀ࠴ࡢ࠿࠯ࠬࡂࢀࡡࢂ࠮ࠫࡁࠬࠨࠬ泻"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111ll1l11_l1_: l111ll1l11_l1_ = l111ll1l11_l1_[0][0]
	else: l111ll1l11_l1_ = l11l1l_l1_ (u"ࠬ࠭泼")
	return l111ll1l11_l1_
	#elif not l111ll1l11_l1_ and l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ泽") in l1l1l111_l1_: l111ll1l11_l1_ = l11l1l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ泾")
	#elif not l111ll1l11_l1_ and l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ泿") in l1l1l111_l1_: l111ll1l11_l1_ = l11l1l_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ洀")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l11l11llll11_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l11l11llll11_l1_ = False
	l111lll1l1_l1_ = time.time()
	if l11l11llll11_l1_: resp = l111lll1l1_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫ洁"),l11l1l_l1_ (u"ࠫࠬ洂"),l11l1l_l1_ (u"ࠬ࠭洃"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ洄"),l11l1l_l1_ (u"ࠧิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥ฿ๅๅ์ฬࠤฬ๊ส็ฺํๅࠥอไร่ࠣรࠦ࠭洅"))
	else: l1ll11111l_l1_ = True
	if l1ll11111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11l1l_l1_ (u"ࠨ࠰ࡧࡦࠬ洆")) and l11l1l_l1_ (u"ࠩࡧࡥࡹࡧࠧ洇") in filename:
				l1l1l1ll11_l1_ = os.path.join(addoncachefolder,filename)
				conn = sqlite3.connect(l1l1l1ll11_l1_)
				cc = conn.cursor()
				l111lllll11l_l1_(cc)
				cc.execute(l11l1l_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭洈"))
				cc.execute(l11l1l_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧ洉"))
				cc.execute(l11l1l_l1_ (u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭洊"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ洋"),l11l1l_l1_ (u"ࠧࠨ洌"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ洍"),l11l1l_l1_ (u"ࠩอ้ฯࠦศ็ฮสัࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠪ洎"))
	return
def EVAL(l1lll111ll111_l1_,text):
	#text = text.replace(l11l1l_l1_ (u"ࠥࡹࠬࠨ洏"),l11l1l_l1_ (u"ࠦࠬࠨ洐"))
	text = text.replace(l11l1l_l1_ (u"ࠬࡴࡵ࡭࡮ࠪ洑"),l11l1l_l1_ (u"࠭ࡎࡰࡰࡨࠫ洒"))
	text = text.replace(l11l1l_l1_ (u"ࠧࡵࡴࡸࡩࠬ洓"),l11l1l_l1_ (u"ࠨࡖࡵࡹࡪ࠭洔"))
	text = text.replace(l11l1l_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ洕"),l11l1l_l1_ (u"ࠪࡊࡦࡲࡳࡦࠩ洖"))
	try: l1l1l11lll_l1_ = eval(text)
	except: l1l1l11lll_l1_ = l111ll1l1l11_l1_(l1lll111ll111_l1_)
	return l1l1l11lll_l1_
def l1llll11111ll_l1_(word):
	if l11l1l_l1_ (u"ࠫࡠ࠭洗") in word and l11l1l_l1_ (u"ࠬࡣࠧ洘") in word:
		l1llll1llll11_l1_ = [l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ洙"),l11l1l_l1_ (u"ࠧ࡜࠱ࡕࡘࡑࡣࠧ洚"),l11l1l_l1_ (u"ࠨ࡝࠲ࡐࡊࡌࡔ࡞ࠩ洛"),l11l1l_l1_ (u"ࠩ࡞࠳ࡗࡏࡇࡉࡖࡠࠫ洜"),l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡅࡏࡖࡈࡖࡢ࠭洝"),l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ洞"),l11l1l_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ洟"),l11l1l_l1_ (u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ洠"),l11l1l_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ洡")]
		l111ll11l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢ࠱࠮ࡄࡢ࡝ࠨ洢"),word,re.DOTALL)
		l111ll11ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠴ࠪࡀ࡞ࡠࠫ洣"),word,re.DOTALL)
		l1lll1l111lll_l1_ = l1llll1llll11_l1_+l111ll11l1ll_l1_+l111ll11ll11_l1_
		for tag in l1lll1l111lll_l1_: word = word.replace(tag,l11l1l_l1_ (u"ࠪࠫ洤"))
	return word
def l1llllll111ll_l1_(l11l111l1lll_l1_,l11111l1l1ll_l1_,l1llll1lll11l_l1_,l1lll1ll111ll_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll1ll1ll_l1_,l111l1l1l1l1_l1_,l1lll111l11ll_l1_ = l11l1l_l1_ (u"ࠫࠬ津"),0,15000
	l11l111l1lll_l1_ = l11l111l1lll_l1_.replace(l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭洦"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠩࠣࠤࠩ洧"))
	l1ll1lll1ll1l_l1_ = PIL.ImageFont.truetype(l11111ll1111_l1_,size=l11111l1l1ll_l1_)
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠧࡓࡉࡅࡅࠬ洨"),(l1llll1lll11l_l1_,99),(255,255,255,0))
	l1111llll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	l1llll1lll11l_l1_ -= l11111l1l1ll_l1_
	for l1lll11ll1111_l1_ in l11l111l1lll_l1_.splitlines():
		l111l1l1l1l1_l1_ += l1lll1ll111ll_l1_
		l11111l1llll_l1_,newline = 0,l11l1l_l1_ (u"ࠨࠩ洩")
		for word in l1lll11ll1111_l1_.split(l11l1l_l1_ (u"ࠩࠣࠫ洪")):
			l1111ll11l1l_l1_ = l1llll11111ll_l1_(l11l1l_l1_ (u"ࠪࠤࠬ洫")+word)
			l1lll1l11l11l_l1_,l1111ll1ll1l_l1_ = l1111llll1ll_l1_.textsize(l1111ll11l1l_l1_,font=l1ll1lll1ll1l_l1_)
			if l11111l1llll_l1_+l1lll1l11l11l_l1_<l1llll1lll11l_l1_:
				if not newline: newline += word
				else: newline += l11l1l_l1_ (u"ࠫࠥ࠭洬")+word
				l11111l1llll_l1_ += l1lll1l11l11l_l1_
			else:
				if l1lll1l11l11l_l1_<l1llll1lll11l_l1_:
					newline += l11l1l_l1_ (u"ࠬࡢ࡮ࠡࠩ洭")+word
					l111l1l1l1l1_l1_ += l1lll1ll111ll_l1_
					l11111l1llll_l1_ = l1lll1l11l11l_l1_
				else:
					while l1lll1l11l11l_l1_>=l1llll1lll11l_l1_:
						for l11l1ll1l1_l1_ in range(1,len(l11l1l_l1_ (u"࠭ࠠࠨ洮")+word),1):
							l1111llllll1_l1_ = l11l1l_l1_ (u"ࠧࠡࠩ洯")+word[:l11l1ll1l1_l1_]
							l111111ll1_l1_ = word[l11l1ll1l1_l1_:]
							l1lll11111l1l_l1_ = l1llll11111ll_l1_(l1111llllll1_l1_)
							l111ll1l1l1l_l1_,l1111l1l1111_l1_ = l1111llll1ll_l1_.textsize(l1lll11111l1l_l1_,font=l1ll1lll1ll1l_l1_)
							if l11111l1llll_l1_+l111ll1l1l1l_l1_>=l1llll1lll11l_l1_:
								l1llll1l11lll_l1_ = l1lll1l11l11l_l1_-l111ll1l1l1l_l1_
								newline += l1111llllll1_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ洰")
								l111l1l1l1l1_l1_ += l1lll1ll111ll_l1_
								l1lll1l11l11l_l1_ = l1llll1l11lll_l1_
								if l1llll1l11lll_l1_>=l1llll1lll11l_l1_:
									l11111l1llll_l1_ = 0
									word = l111111ll1_l1_
								else:
									l11111l1llll_l1_ = l1llll1l11lll_l1_
									newline += l111111ll1_l1_
								break
				if l111l1l1l1l1_l1_>l1lll111l11ll_l1_: break
		l111ll1ll1ll_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ洱")+newline
		if l111l1l1l1l1_l1_>l1lll111l11ll_l1_: break
	l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_[1:]
	l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_.replace(l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠭洲"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ洳"))
	return l111ll1ll1ll_l1_
def l111l1ll1lll_l1_(text):
	text = text.replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ洴"),l11l1l_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ洵"))
	text = text.replace(l11l1l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭洶"),l11l1l_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ洷"))
	text = text.replace(l11l1l_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ洸"),l11l1l_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ洹"))
	text = text.replace(l11l1l_l1_ (u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ洺"),l11l1l_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ活"))
	text = text.replace(l11l1l_l1_ (u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ洼"),l11l1l_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ洽"))
	text = text.replace(l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ派"),l11l1l_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ洿"))
	l1lllllll1l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ浀"),text,re.DOTALL)
	for l1llll1l1111l_l1_ in l1lllllll1l1l_l1_: text = text.replace(l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ流")+l1llll1l1111l_l1_+l11l1l_l1_ (u"ࠬࡣࠧ浂"),l11l1l_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ浃")+l1llll1l1111l_l1_+l11l1l_l1_ (u"ࠧࡠࠩ浄"))
	return text
def l1lll1111llll_l1_(l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text,l1111ll111l1_l1_,l111ll1ll11l_l1_,l1llll11l1l11_l1_,l1lll1lll1ll1_l1_):
	l1lll11l1l111_l1_ = [l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text]
	table_keyy = str(addon_version)+l11l1l_l1_ (u"ࠨࡡࡢࠫ浅")+str(dest_lang)+l11l1l_l1_ (u"ࠩࡢࡣࠬ浆")+str(l1lll11l1l111_l1_)
	contents = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ浇"),l11l1l_l1_ (u"࡙ࠫࡘࡁࡏࡕࡏࡅ࡙ࡋࡄࡠࡆࡌࡅࡑࡕࡇࡔࠩ浈"),table_keyy)
	if not contents:
		if do_trans:
			contents = REVERSO_TRANSLATE(l1lll11l1l111_l1_)
			WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࡚ࠬࡒࡂࡐࡖࡐࡆ࡚ࡅࡅࡡࡇࡍࡆࡒࡏࡈࡕࠪ浉"),table_keyy,contents,VERYLONG_CACHE)
	if contents: [l1111l1l11l1_l1_,l1lll11ll1l1l_l1_,l1111l1l1lll_l1_,header,text] = contents
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ浊"))
		header = header.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ测"))
		l1111l1l11l1_l1_ = l1111l1l11l1_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭浌"))
		l1lll11ll1l1l_l1_ = l1lll11ll1l1l_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ浍"))
		l1111l1l1lll_l1_ = l1111l1l1lll_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ济"))
	l1111lll111l_l1_ = 5
	l1ll1lll1l11l_l1_ = 20
	l1lllll1l1ll1_l1_ = 20
	l1llll1l1l1ll_l1_ = 0
	l11l111ll111_l1_ = l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ浏")
	l1lll1111l1ll_l1_ = 10
	l1lll111lllll_l1_ = 19
	l111l1l1l11l_l1_ = 30
	l1lllll11lll1_l1_ = 8
	l1llll1l11l11_l1_ = True
	l1lll11ll1ll1_l1_ = 375
	l1ll1llll1l1l_l1_ = 410
	l1llllll1llll_l1_ = 50
	l1lll1ll11ll1_l1_ = 280
	l1111l111lll_l1_ = 28
	l1lll11111l11_l1_ = 5
	l111l111lll1_l1_ = 0
	l1llll1lll111_l1_ = 31
	l111l11l111l_l1_ = [36,32,28]
	if l1111ll111l1_l1_ in [l11l1l_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ浐"),l11l1l_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ浑")]:
		if l1111ll111l1_l1_==l11l1l_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ浒"):
			l11l111l1l1l_l1_ = l11l1l_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ浓")
			l11l111ll111_l1_ = l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ浔")
			l1llll1l11l11_l1_ = True
			l1llll1l1l1ll_l1_ = 10
		else:
			l11l111l1l1l_l1_ = 97+20
			l11l111ll111_l1_ = l11l1l_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ浕")
			l1llll1l11l11_l1_ = False
		l111l11l111l_l1_ = [33,33,33]
		l1lllll1l1ll1_l1_ = 20
		l1ll1lll1l11l_l1_ = 0
		l111l1l1l11l_l1_ = 20
		l1lll111lllll_l1_ = 25+10
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭浖"): l11l111l1l1l_l1_ = 500
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩ浗"): l111l11l111l_l1_ = [28,23,18] ; l11l111l1l1l_l1_ = 500
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ浘"): l11l111l1l1l_l1_ = 740
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ浙"): l11l111l1l1l_l1_ = l11l1l_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ浚")
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ浛"): l111l11l111l_l1_ = [28,23,18] ; l11l111l1l1l_l1_ = 740
	elif l1111ll111l1_l1_==l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭浜"): l111l11l111l_l1_ = [28,23,18] ; l11l111l1l1l_l1_ = l11l1l_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ浝")
	l11111l1l11l_l1_ = l111l11l111l_l1_[0]
	l111l11lllll_l1_ = l111l11l111l_l1_[1]
	l11l111l111l_l1_ = l111l11l111l_l1_[2]
	l11111ll111l_l1_ = PIL.ImageFont.truetype(l11111ll1111_l1_,size=l11111l1l11l_l1_)
	l1lllll1lll1l_l1_ = PIL.ImageFont.truetype(l11111ll1111_l1_,size=l111l11lllll_l1_)
	l1lllllll1l11_l1_ = PIL.ImageFont.truetype(l11111ll1111_l1_,size=l11l111l111l_l1_)
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠬࡘࡇࡃࡃࠪ浞"),(100,100),(255,255,255,0))
	l1111llll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	l1111ll1l11l_l1_,l1llll1111ll1_l1_ = l1111llll1ll_l1_.textsize(l11l1l_l1_ (u"࠭ࡈࡉࡊࠣࡆࡇࡈࠠ࠹࠺࠻ࠤ࠵࠶࠰ࠨ浟"),font=l1lllll1lll1l_l1_)
	l1111111ll1l_l1_,l1111l11ll11_l1_ = l1111llll1ll_l1_.textsize(l11l1l_l1_ (u"ࠧࡉࡊࡋࠤࡇࡈࡂࠡ࠺࠻࠼ࠥ࠶࠰࠱ࠩ浠"),font=l11111ll111l_l1_)
	l1lll1111ll1l_l1_ = header.count(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ浡"))+1
	l1lll1llll11l_l1_ = l1ll1lll1l11l_l1_+l1lll1111ll1l_l1_*(l1111l11ll11_l1_+l1llll1l1l1ll_l1_)-l1llll1l1l1ll_l1_
	l1llll11ll111_l1_ = {l11l1l_l1_ (u"ࠩࡧࡩࡱ࡫ࡴࡦࡡ࡫ࡥࡷࡧ࡫ࡢࡶࠪ浢"):False,l11l1l_l1_ (u"ࠪࡷࡺࡶࡰࡰࡴࡷࡣࡱ࡯ࡧࡢࡶࡸࡶࡪࡹࠧ浣"):True,l11l1l_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࠤࡑࡏࡇࡂࡖࡘࡖࡊࠦࡁࡍࡎࡄࡌࠬ浤"):False}
	l111ll1l111l_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1llll11ll111_l1_)
	if text:
		l11l1111lll1_l1_ = l1llll11l1l11_l1_-l111l1l1l11l_l1_*2
		l1lll111lll1l_l1_ = l1llll1111ll1_l1_+l1lllll11lll1_l1_
		l1llll11lll11_l1_ = l111ll1l111l_l1_.reshape(text)
		if l1llll1l11l11_l1_:
			l1ll1ll11ll1l_l1_ = l1llllll111ll_l1_(l1llll11lll11_l1_,l111l11lllll_l1_,l11l1111lll1_l1_,l1lll111lll1l_l1_)
			l1111111ll11_l1_ = l1llll11111ll_l1_(l1ll1ll11ll1l_l1_)
			l1llll11l1ll1_l1_ = l1111111ll11_l1_.count(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ浥"))+1
			if l1llll11l1ll1_l1_<6:
				if l1llll11l1ll1_l1_<4: l1lll11lll11l_l1_ = int(0.8*l11l1111lll1_l1_)
				else: l1lll11lll11l_l1_ = int(0.9*l11l1111lll1_l1_)
				l1ll1ll11ll1l_l1_ = l1llllll111ll_l1_(l1llll11lll11_l1_,l111l11lllll_l1_,l1lll11lll11l_l1_,l1lll111lll1l_l1_)
				l1111111ll11_l1_ = l1llll11111ll_l1_(l1ll1ll11ll1l_l1_)
				l1llll11l1ll1_l1_ = l1111111ll11_l1_.count(l11l1l_l1_ (u"࠭࡜࡯ࠩ浦"))+1
			l111lll1l1l1_l1_ = l1lll111lllll_l1_+l1llll11l1ll1_l1_*l1lll111lll1l_l1_-l1lllll11lll1_l1_
		else:
			l111lll1l1l1_l1_ = l1lll111lllll_l1_+l1llll1111ll1_l1_
			l1111111ll11_l1_ = l1llll11lll11_l1_.split(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ浧"))[0]
			l1ll1ll11ll1l_l1_ = l1llll11lll11_l1_.split(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ浨"))[0]
	else: l111lll1l1l1_l1_ = l1lll111lllll_l1_
	l1llll1ll111l_l1_ = l111l111lll1_l1_+l1llll1lll111_l1_
	if l1lll1lll1ll1_l1_:
		l1lll1l1l11l1_l1_ = l1ll1llll1l1l_l1_-l1lll11ll1ll1_l1_
		l1llll1ll111l_l1_ += l1lll1l1l11l1_l1_
	else: l1lll1l1l11l1_l1_ = 0
	if l1111l1l11l1_l1_ or l1lll11ll1l1l_l1_ or l1111l1l1lll_l1_: l1llll1ll111l_l1_ += l1llllll1llll_l1_
	if l11l111l1l1l_l1_!=l11l1l_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ浩"): l111l111l1ll_l1_ = l11l111l1l1l_l1_
	else: l111l111l1ll_l1_ = l1lll1llll11l_l1_+l111lll1l1l1_l1_+l1llll1ll111l_l1_
	l1111111111l_l1_ = l111l111l1ll_l1_-l1lll1llll11l_l1_-l1llll1ll111l_l1_-l1lll111lllll_l1_
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠪࡖࡌࡈࡁࠨ浪"),(l1llll11l1l11_l1_,l111l111l1ll_l1_),(255,255,255,0))
	l1111llll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1lll11ll1l1l_l1_ and l1111l1l11l1_l1_ and l1111l1l1lll_l1_:
		l1111l111lll_l1_ += 105
		l1lll11111l11_l1_ -= 110
	if header:
		l1111lll11l1_l1_ = l1ll1lll1l11l_l1_
		header = bidi.algorithm.get_display(l111ll1l111l_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1l11l111l1l_l1_ = l1111llll1ll_l1_.textsize(line,font=l11111ll111l_l1_)
				if l11l111ll111_l1_==l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ浫"): l1lll11lllll1_l1_ = l1111lll111l_l1_+(l1llll11l1l11_l1_-width)/2
				elif l11l111ll111_l1_==l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ浬"): l1lll11lllll1_l1_ = l1111lll111l_l1_+l1llll11l1l11_l1_-width-l1lllll1l1ll1_l1_
				elif l11l111ll111_l1_==l11l1l_l1_ (u"࠭࡬ࡦࡨࡷࠫ浭"): l1lll11lllll1_l1_ = l1111lll111l_l1_+l1lllll1l1ll1_l1_
				l1111llll1ll_l1_.text((l1lll11lllll1_l1_,l1111lll11l1_l1_),line,font=l11111ll111l_l1_,fill=l11l1l_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ浮"))
			l1111lll11l1_l1_ += l11111l1l11l_l1_+l1llll1l1l1ll_l1_
	if l1111l1l11l1_l1_ or l1lll11ll1l1l_l1_ or l1111l1l1lll_l1_:
		l1111l11l111_l1_ = l1lll1llll11l_l1_+l1111111111l_l1_+l1lll111lllll_l1_+l1lll1l1l11l1_l1_+l111l111lll1_l1_
		if l1111l1l11l1_l1_:
			l1111l1l11l1_l1_ = bidi.algorithm.get_display(l111ll1l111l_l1_.reshape(l1111l1l11l1_l1_))
			l1llll111l1l1_l1_,l111l111l111_l1_ = l1111llll1ll_l1_.textsize(l1111l1l11l1_l1_,font=l1lllllll1l11_l1_)
			l111l11l1111_l1_ = l1111l111lll_l1_+0*(l1lll11111l11_l1_+l1lll1ll11ll1_l1_)+(l1lll1ll11ll1_l1_-l1llll111l1l1_l1_)/2
			l1111llll1ll_l1_.text((l111l11l1111_l1_,l1111l11l111_l1_),l1111l1l11l1_l1_,font=l1lllllll1l11_l1_,fill=l11l1l_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ浯"))
		if l1lll11ll1l1l_l1_:
			l1lll11ll1l1l_l1_ = bidi.algorithm.get_display(l111ll1l111l_l1_.reshape(l1lll11ll1l1l_l1_))
			l1lllll11llll_l1_,l111lll11111_l1_ = l1111llll1ll_l1_.textsize(l1lll11ll1l1l_l1_,font=l1lllllll1l11_l1_)
			l111l11llll1_l1_ = l1111l111lll_l1_+1*(l1lll11111l11_l1_+l1lll1ll11ll1_l1_)+(l1lll1ll11ll1_l1_-l1lllll11llll_l1_)/2
			l1111llll1ll_l1_.text((l111l11llll1_l1_,l1111l11l111_l1_),l1lll11ll1l1l_l1_,font=l1lllllll1l11_l1_,fill=l11l1l_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ浰"))
		if l1111l1l1lll_l1_:
			l1111l1l1lll_l1_ = bidi.algorithm.get_display(l111ll1l111l_l1_.reshape(l1111l1l1lll_l1_))
			l111ll111ll1_l1_,l1111l11l1ll_l1_ = l1111llll1ll_l1_.textsize(l1111l1l1lll_l1_,font=l1lllllll1l11_l1_)
			l111111lll11_l1_ = l1111l111lll_l1_+2*(l1lll11111l11_l1_+l1lll1ll11ll1_l1_)+(l1lll1ll11ll1_l1_-l111ll111ll1_l1_)/2
			l1111llll1ll_l1_.text((l111111lll11_l1_,l1111l11l111_l1_),l1111l1l1lll_l1_,font=l1lllllll1l11_l1_,fill=l11l1l_l1_ (u"ࠪࡽࡪࡲ࡬ࡰࡹࠪ浱"))
	if text:
		l1ll1lll111ll_l1_,l111ll11l1l1_l1_ = [],[]
		l1ll1ll11ll1l_l1_ = l111l1ll1lll_l1_(l1ll1ll11ll1l_l1_)
		l1lll111llll1_l1_ = l1ll1ll11ll1l_l1_.split(l11l1l_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ浲"))
		for l1ll1lllll1ll_l1_ in l1lll111llll1_l1_:
			l111lll1lll1_l1_ = l111ll1ll11l_l1_
			if   l11l1l_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ浳") in l1ll1lllll1ll_l1_: l111lll1lll1_l1_ = l11l1l_l1_ (u"࠭࡬ࡦࡨࡷࠫ浴")
			elif l11l1l_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ浵") in l1ll1lllll1ll_l1_: l111lll1lll1_l1_ = l11l1l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ浶")
			elif l11l1l_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭海") in l1ll1lllll1ll_l1_: l111lll1lll1_l1_ = l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ浸")
			l111llll1l1l_l1_ = l1ll1lllll1ll_l1_
			l1llll1llll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢ࠲࠯ࡅ࡟ࠨ浹"),l1ll1lllll1ll_l1_,re.DOTALL)
			for tag in l1llll1llll11_l1_: l111llll1l1l_l1_ = l111llll1l1l_l1_.replace(tag,l11l1l_l1_ (u"ࠬ࠭浺"))
			if l111llll1l1l_l1_==l11l1l_l1_ (u"࠭ࠧ浻"): width,l1l11l111l1l_l1_ = 0,l1lll111lll1l_l1_
			else: width,l1l11l111l1l_l1_ = l1111llll1ll_l1_.textsize(l111llll1l1l_l1_,font=l1lllll1lll1l_l1_)
			if   l111lll1lll1_l1_==l11l1l_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ浼"): l11111llll11_l1_ = l1lll1111l1ll_l1_+l111l1l1l11l_l1_
			elif l111lll1lll1_l1_==l11l1l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ浽"): l11111llll11_l1_ = l1lll1111l1ll_l1_+l111l1l1l11l_l1_+l11l1111lll1_l1_-width
			elif l111lll1lll1_l1_==l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ浾"): l11111llll11_l1_ = l1lll1111l1ll_l1_+l111l1l1l11l_l1_+(l11l1111lll1_l1_-width)/2
			if l11111llll11_l1_<l111l1l1l11l_l1_: l11111llll11_l1_ = l1lll1111l1ll_l1_+l111l1l1l11l_l1_
			l1ll1lll111ll_l1_.append(l11111llll11_l1_)
			l111ll11l1l1_l1_.append(width)
		l11111llll11_l1_ = l1ll1lll111ll_l1_[0]
		l1lll11lll1ll_l1_ = l1ll1ll11ll1l_l1_.split(l11l1l_l1_ (u"ࠪࡣࡸࡹࡳࡠࠩ浿"))
		l11l1111111l_l1_ = (255,255,255,255)
		l1llllll111l1_l1_ = l11l1111111l_l1_
		l1lll111lll11_l1_,l1lllll11l111_l1_ = 0,0
		l111111ll1l1_l1_ = False
		l1111l1llll1_l1_ = 0
		l1lll1111ll11_l1_ = l1lll1llll11l_l1_+l1lll111lllll_l1_/2
		if l111lll1l1l1_l1_<(l1111111111l_l1_+l1lll111lllll_l1_):
			l1111ll1lll1_l1_ = (l1111111111l_l1_+l1lll111lllll_l1_-l111lll1l1l1_l1_)/2
			l1lll1111ll11_l1_ = l1lll1llll11l_l1_+l1lll111lllll_l1_+l1111ll1lll1_l1_-l1llll1111ll1_l1_/2
		for line in l1lll11lll1ll_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1lll1l11ll1l_l1_ = line.split(l11l1l_l1_ (u"ࠫࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ涀"),1)
			l1lll1l11lll1_l1_ = line.split(l11l1l_l1_ (u"ࠬࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨ涁"),1)
			l1lll1l11llll_l1_ = line.split(l11l1l_l1_ (u"࠭࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ涂"),1)
			l1llllll1lll1_l1_ = line.split(l11l1l_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ涃"),1)
			l1lllllll111l_l1_ = line.split(l11l1l_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ涄"),1)
			l1llllllll111_l1_ = line.split(l11l1l_l1_ (u"ࠩࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ涅"),1)
			l1lll1l11ll11_l1_ = line.split(l11l1l_l1_ (u"ࠪࡣࡱ࡯࡮ࡦࡥࡨࡲࡹ࡫ࡲࡠࠩ涆"),1)
			if len(l1lll1l11ll1l_l1_)>1:
				l1111l1llll1_l1_ += 1
				line = l1lll1l11ll1l_l1_[1]
				l1lll111lll11_l1_ = 0
				l11111llll11_l1_ = l1ll1lll111ll_l1_[l1111l1llll1_l1_]
				l1lllll11l111_l1_ += l1lll111lll1l_l1_
				l111111ll1l1_l1_ = False
			elif len(l1lll1l11lll1_l1_)>1:
				line = l1lll1l11lll1_l1_[1]
				l1llllll111l1_l1_ = line[0:8]
				l1llllll111l1_l1_ = l11l1l_l1_ (u"ࠫࠨ࠭涇")+l1llllll111l1_l1_[2:]
				line = line[9:]
			elif len(l1lll1l11llll_l1_)>1:
				line = l1lll1l11llll_l1_[1]
				l1llllll111l1_l1_ = l11l1111111l_l1_
			elif len(l1llllll1lll1_l1_)>1:
				line = l1llllll1lll1_l1_[1]
				l111111ll1l1_l1_ = True
				l1lll111lll11_l1_ = l111ll11l1l1_l1_[l1111l1llll1_l1_]
			elif len(l1lllllll111l_l1_)>1:
				line = l1lllllll111l_l1_[1]
			elif len(l1llllllll111_l1_)>1:
				line = l1llllllll111_l1_[1]
			elif len(l1lll1l11ll11_l1_)>1:
				line = l1lll1l11ll11_l1_[1]
			if line:
				l1lll1ll11l1l_l1_ = l1lll1111ll11_l1_+l1lllll11l111_l1_
				line = bidi.algorithm.get_display(line)
				width,l1l11l111l1l_l1_ = l1111llll1ll_l1_.textsize(line,font=l1lllll1lll1l_l1_)
				if l111111ll1l1_l1_: l1lll111lll11_l1_ -= width
				l11111lll1ll_l1_ = l11111llll11_l1_+l1lll111lll11_l1_
				l1111llll1ll_l1_.text((l11111lll1ll_l1_,l1lll1ll11l1l_l1_),line,font=l1lllll1lll1l_l1_,fill=l1llllll111l1_l1_)
				if not l111111ll1l1_l1_: l1lll111lll11_l1_ += width
				if l1lll1ll11l1l_l1_>l1111111111l_l1_+l1lll111lll1l_l1_: break
	l1111111l1ll_l1_ = l1ll1lll1l1ll_l1_.replace(l11l1l_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ消"),l11l1l_l1_ (u"࠭࡟ࠨ涉")+str(time.time())+l11l1l_l1_ (u"ࠧࡠࠩ涊"))
	l1111111l1ll_l1_ = l1111111l1ll_l1_.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ涋"),l11l1l_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ涌")).replace(l11l1l_l1_ (u"ࠪ࠳࠴࠭涍"),l11l1l_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ涎"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1111111l1ll_l1_)
	return l1111111l1ll_l1_,l111l111l1ll_l1_
def l111lllll11l_l1_(cc):
	cc.execute(l11l1l_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫ涏"))
	cc.execute(l11l1l_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟࡬ࡧࡼࡷࡂࡴ࡯࠼ࠩ涐"))
	cc.execute(l11l1l_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳ࠼ࠩ涑"))
	cc.execute(l11l1l_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉ࠿ࠬ涒"))
	cc.execute(l11l1l_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧ涓"))
	cc.execute(l11l1l_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࡀ࠭涔"))
	return
def WRITE_TO_SQL3(l1l1l1ll11_l1_,table,l1lll1111l1l1_l1_,data,l1l1ll1111l1_l1_,l1lllll1ll11l_l1_=False):
	cache = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭涕"))
	if cache==l11l1l_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭涖") and l1l1ll1111l1_l1_>l11ll1lll1l1_l1_: l1l1ll1111l1_l1_ = l11ll1lll1l1_l1_
	if l1lllll1ll11l_l1_:
		l11l1l1l1_l1_,l11l1l1ll_l1_ = [],[]
		for l11l1ll1l1_l1_ in range(len(l1lll1111l1l1_l1_)):
			text = pickle.dumps(data[l11l1ll1l1_l1_])
			l1ll1ll1lll11_l1_ = zlib.compress(text)
			l11l1l1l1_l1_.append((l1lll1111l1l1_l1_[l11l1ll1l1_l1_],))
			l11l1l1ll_l1_.append((l1l1ll1111l1_l1_+now,str(l1lll1111l1l1_l1_[l11l1ll1l1_l1_]),l1ll1ll1lll11_l1_))
	else:
		text = pickle.dumps(data)
		l111ll1lll11_l1_ = zlib.compress(text)
	conn = sqlite3.connect(l1l1l1ll11_l1_)
	cc = conn.cursor()
	l111lllll11l_l1_(cc)
	conn.text_factory = str
	while True:
		try:
			cc.execute(l11l1l_l1_ (u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨ涗"))
			break
		except: time.sleep(0.5)
	cc.execute(l11l1l_l1_ (u"ࠧࡄࡔࡈࡅ࡙ࡋࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡑࡓ࡙ࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ涘")+table+l11l1l_l1_ (u"ࠨࠤࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠣ࠿ࠬ涙"))
	if l1lllll1ll11l_l1_:
		cc.executemany(l11l1l_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ涚")+table+l11l1l_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ涛"),l11l1l1l1_l1_)
		cc.executemany(l11l1l_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ涜")+table+l11l1l_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ涝"),l11l1l1ll_l1_)
	else:
		if l1l1ll1111l1_l1_:
			tt = (str(l1lll1111l1l1_l1_),)
			cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭涞")+table+l11l1l_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ涟"),tt)
			tt = (l1l1ll1111l1_l1_+now,str(l1lll1111l1l1_l1_),l111ll1lll11_l1_)
			cc.execute(l11l1l_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ涠")+table+l11l1l_l1_ (u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ涡"),tt)
		else:
			tt = (l111ll1lll11_l1_,str(l1lll1111l1l1_l1_))
			cc.execute(l11l1l_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣࠦࠬ涢")+table+l11l1l_l1_ (u"ࠫࠧࠦࡓࡆࡖࠣࡨࡦࡺࡡࠡ࠿ࠣࡃࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ涣"),tt)
	conn.commit()
	conn.close()
	return
def READ_FROM_SQL3(l1l1l1ll11_l1_,l1lll111ll111_l1_,table,l1lll1111l1l1_l1_=None):
	data = l111ll1l1l11_l1_(l1lll111ll111_l1_)
	l1l11ll11l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ涤"))
	if l1l11ll11l_l1_==l11l1l_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ涥") and table!=l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ润") and l1l1l1ll11_l1_==main_dbfile:
		DELETE_FROM_SQL3(l1l1l1ll11_l1_,table,l1lll1111l1l1_l1_)
		return data
	l11l111ll1l1_l1_ = 0
	cache = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ涧"))
	if cache==l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ涨"): return data
	elif cache==l11l1l_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ涩"): l11l111ll1l1_l1_ = l11ll1lll1l1_l1_
	try: conn = sqlite3.connect(l1l1l1ll11_l1_)
	except: return data
	cc = conn.cursor()
	l111lllll11l_l1_(cc)
	conn.text_factory = str
	l1llll1l111ll_l1_ = True
	try: cc.execute(l11l1l_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠧ࠭涪")+table+l11l1l_l1_ (u"ࠬࠨࠠࡍࡋࡐࡍ࡙ࠦ࠱ࠡ࠽ࠪ涫"))
	except: l1llll1l111ll_l1_ = False
	if l1llll1l111ll_l1_:
		if l11l111ll1l1_l1_: cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭涬")+table+l11l1l_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠿ࠩ涭")+str(now+l11l111ll1l1_l1_)+l11l1l_l1_ (u"ࠨࠢ࠾ࠫ涮"))
		conn.commit()
		cc.execute(l11l1l_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ涯")+table+l11l1l_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡀࠬ涰")+str(now)+l11l1l_l1_ (u"ࠫࠥࡁࠧ涱"))
		conn.commit()
		if l1lll1111l1l1_l1_:
			tt = (str(l1lll1111l1l1_l1_),)
			cc.execute(l11l1l_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠤࠪ液")+table+l11l1l_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭涳"),tt)
			l11lllll11l1_l1_ = cc.fetchall()
			if l11lllll11l1_l1_:
				try:
					text = zlib.decompress(l11lllll11l1_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11l1l_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬ涴")+table+l11l1l_l1_ (u"ࠨࠤࠣ࠿ࠬ涵"))
			l11lllll11l1_l1_ = cc.fetchall()
			if l11lllll11l1_l1_:
				data,l1llllll1l111_l1_ = {},[]
				for l1lllll11ll1l_l1_,l11ll1111_l1_ in l11lllll11l1_l1_:
					l1l1l11lll_l1_ = zlib.decompress(l11ll1111_l1_)
					l11ll1111_l1_ = pickle.loads(l1l1l11lll_l1_)
					data[l1lllll11ll1l_l1_] = l11ll1111_l1_
					l1llllll1l111_l1_.append(l1lllll11ll1l_l1_)
				if l1llllll1l111_l1_:
					data[l11l1l_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ涶")] = l1llllll1l111_l1_
					if l1lll111ll111_l1_==l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ涷"): data = l1llllll1l111_l1_
	conn.close()
	return data
def DELETE_FROM_SQL3(l1l1l1ll11_l1_,table,l1lll1111l1l1_l1_=None):
	conn = sqlite3.connect(l1l1l1ll11_l1_)
	cc = conn.cursor()
	l111lllll11l_l1_(cc)
	conn.text_factory = str
	if l1lll1111l1l1_l1_==None: cc.execute(l11l1l_l1_ (u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭涸")+table+l11l1l_l1_ (u"ࠬࠨࠠ࠼ࠩ涹"))
	else:
		tt = (str(l1lll1111l1l1_l1_),)
		try: cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭涺")+table+l11l1l_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ涻"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
def l1lll1111ll1_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111lll1111l_l1_=True,l1llll1111lll_l1_=True):
	# should l1l1111l1ll1_l1_ ==l11l1l_l1_ (u"ࠨࠩ涼") l11111ll1l_l1_ not l111lllll1_l1_ it to l11l1l_l1_ (u"ࠩࡱࡳࡹ࠭涽")
	if allow_redirects==l11l1l_l1_ (u"ࠪࠫ涾"): allow_redirects = True
	if l1ll_l1_==l11l1l_l1_ (u"ࠫࠬ涿"): l1ll_l1_ = True
	if l111lll1111l_l1_==l11l1l_l1_ (u"ࠬ࠭淀"): l111lll1111l_l1_ = True
	if l1llll1111lll_l1_==l11l1l_l1_ (u"࠭ࠧ淁"): l1llll1111lll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	if l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ淂") not in list(headers.keys()): headers[l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ淃")] = l11l1l_l1_ (u"ࠩࡃࡄࡅ࡙ࡋࡊࡒࡢࡌࡊࡇࡄࡆࡔࡃࡄࡅ࠭淄")
	l111ll1_l1_,l1lll11l111l1_l1_,l1llll111l11l_l1_,l1lll1lll111l_l1_ = l1lll11ll11ll_l1_(url)
	l1ll1lll11lll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ淅"))
	l1lll111l1l11_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ淆"))
	l1lll11l1ll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ淇"))
	l1ll1llll111l_l1_ = (l1lll11l111l1_l1_==None and l1llll111l11l_l1_==None and l1lll1lll111l_l1_==None)
	l1lllll1l1111_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭淈")]
	l1lll111l11l1_l1_ = l111ll1_l1_ in l1lllll1l1111_l1_
	l1111lllll1l_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭淉")]
	l111lll11l1l_l1_ = l111ll1_l1_ in l1111lllll1l_l1_
	l111l11111ll_l1_ = l1lll111l11l1_l1_ or l111lll11l1l_l1_
	if l1ll1llll111l_l1_ and l111l11111ll_l1_:
		if l1lll111l11l1_l1_:
			l1ll1lll11111_l1_ = l1lllll1l1111_l1_.index(l111ll1_l1_)
			l11111llll1l_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ淊")][l1ll1lll11111_l1_]
			l1111l1ll1l1_l1_ = l1l1111l1111_l1_[l1ll1lll11111_l1_]
		elif l111lll11l1l_l1_:
			l1ll1lll11111_l1_ = l1111lllll1l_l1_.index(l111ll1_l1_)
			l11111llll1l_l1_ = l1l1ll1_l1_[l11l1l_l1_ (u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ淋")][l1ll1lll11111_l1_]
			l1111l1ll1l1_l1_ = l111l1l11l11_l1_[l1ll1lll11111_l1_]
	if l1llll111l11l_l1_==l11l1l_l1_ (u"ࠪࠫ淌"): l1llll111l11l_l1_ = l1ll1lll11lll_l1_
	elif l1llll111l11l_l1_==None and l1lll111l1l11_l1_ in [l11l1l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ淍"),l11l1l_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ淎")] and l111lll1111l_l1_: l1llll111l11l_l1_ = l1ll1lll11lll_l1_
	if l1lll111l11l1_l1_ or l111lll11l1l_l1_: timeout = 10
	elif l11l1l_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ淏") in source: timeout = 15
	elif l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ淐") in source: timeout = 25
	elif l11l1l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ淑") in source: timeout = 20
	elif source in l1111lllll11_l1_: timeout = 5
	else: timeout = 10
	if l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ淒") in source and not data and l11l1l_l1_ (u"ࠪࠪࠬ淓") not in l111ll1_l1_ and l11l1l_l1_ (u"ࠫࡄ࠭淔") not in l111ll1_l1_: l111ll1_l1_ = l111ll1_l1_.rstrip(l11l1l_l1_ (u"ࠬ࠵ࠧ淕"))+l11l1l_l1_ (u"࠭࠯ࠨ淖")
	l111lll1l111_l1_ = (l1lll11l111l1_l1_!=None)
	l1lll1llllll1_l1_ = (l1llll111l11l_l1_!=None and l1lll111l1l11_l1_!=l11l1l_l1_ (u"ࠧࡔࡖࡒࡔࠬ淗"))
	if l111lll1l111_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠨฬไ฽๏๊ࠠษำ๋็ุ๐ࠠาไ่ࠫ淘"),l1lll11l111l1_l1_)
	elif l1lll1llllll1_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠩอๅ฾๐ไࠡࡆࡑࡗࠥืโๆࠩ淙"),l1llll111l11l_l1_)
	if l111lll1l111_l1_:
		proxies = {l11l1l_l1_ (u"ࠥ࡬ࡹࡺࡰࠣ淚"):l1lll11l111l1_l1_,l11l1l_l1_ (u"ࠦ࡭ࡺࡴࡱࡵࠥ淛"):l1lll11l111l1_l1_}
		l1111111l111_l1_ = l1lll11l111l1_l1_
	else: proxies,l1111111l111_l1_ = {},l11l1l_l1_ (u"ࠬ࠭淜")
	if l1lll1llllll1_l1_:
		import urllib3.util.connection as connection
		l111l11ll1l1_l1_ = l1ll1lllll1l1_l1_(connection,l1ll1lll11lll_l1_)
	verify = True
	l1lll11lll111_l1_,l1l1ll1lll11_l1_,l11l1lll1_l1_,l111llll1l11_l1_,l111lll11ll1_l1_ = allow_redirects,source,method,False,False
	if l111l11111ll_l1_ or (method==l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ淝") and allow_redirects): l1lll11lll111_l1_ = False
	if l1lll111l11l1_l1_: l11l1lll1_l1_ = l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ淞")
	import requests
	for l11l1ll1l1_l1_ in range(7):
		succeeded = False
		try:
			if l11l1ll1l1_l1_: l1l1ll1lll11_l1_ = l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩ淟")
			if not l111lll1l111_l1_: l1llll1ll1ll1_l1_(False,l111ll1_l1_,data,headers,l1l1ll1lll11_l1_,l11l1lll1_l1_)
			try: response.close()
			except: pass
			l111lll_l1_ = l111ll1_l1_
			response = requests.request(l11l1lll1_l1_,l111ll1_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll11lll111_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l111llll1l11_l1_:
					if l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ淠") in list(response.headers.keys()): l111ll1_l1_ = response.headers[l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ淡")]
					elif l11l1l_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭淢") in list(response.headers.keys()): l111ll1_l1_ = response.headers[l11l1l_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ淣")]
					else: l111llll1l11_l1_ = True
					if l111l11111ll_l1_ and response.status_code==307:
						l1lll11lll111_l1_ = allow_redirects
						l11l1lll1_l1_ = method
						l111llll1l11_l1_ = True
						continue
				if not l111llll1l11_l1_ or allow_redirects:
					if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ淤") not in l111ll1_l1_:
						server = SERVER(l111lll_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ淥"))
						l111ll1_l1_ = server+l111ll1_l1_
				if not l111llll1l11_l1_ and allow_redirects:
					l111ll1l11_l1_ = l11l1l1ll1_l1_(l111ll1_l1_)
					if l111ll1l11_l1_ not in [l11l1l_l1_ (u"ࠨ࠰ࡤࡺ࡮࠭淦"),l11l1l_l1_ (u"ࠩ࠱ࡸࡸ࠭淧"),l11l1l_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ淨"),l11l1l_l1_ (u"ࠫ࠳ࡳ࡫ࡷࠩ淩"),l11l1l_l1_ (u"ࠬ࠴ࡦ࡭ࡸࠪ淪"),l11l1l_l1_ (u"࠭࠮࡮ࡲ࠶ࠫ淫"),l11l1l_l1_ (u"ࠧ࠯ࡹࡨࡦࡲ࠭淬")]: continue
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111lll11ll1_l1_ = True
			l111lll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status will write a log line: l11l1l_l1_ (u"ࠣࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦࠤ淭")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			code = -1
			if kodi_version<19: reason = str(err.message).split(l11l1l_l1_ (u"ࠩ࠽ࠤࠬ淮"))[1]
			else: reason = str(err).split(l11l1l_l1_ (u"ࠪ࠾ࠥ࠭淯"))[1]
		except requests.exceptions.ConnectionError as err:
			code = -1
			reason = l11l1l_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫ淰")
			try:
				error = err.message[0]
				reason = error
				if l11l1l_l1_ (u"ࠬࡋࡲࡳࡰࡲࠫ深") in error: code,reason = re.findall(l11l1l_l1_ (u"ࠨ࡜࡜ࡇࡵࡶࡳࡵࠠࠩ࡞ࡧ࠯࠮ࡢ࡝ࠡࠪ࠱࠮ࡄ࠯ࠧࠣ淲"),error)[0]
				elif l11l1l_l1_ (u"ࠧ࠭ࠢࡨࡶࡷࡵࡲࠩࠩ淳") in error: code,reason = re.findall(l11l1l_l1_ (u"ࠣ࠮ࠣࡩࡷࡸ࡯ࡳ࡞ࠫࠬࡡࡪࠫࠪ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ淴"),error)[0]
				elif error.count(l11l1l_l1_ (u"ࠩ࠽ࠫ淵"))>=2: reason,code = re.findall(l11l1l_l1_ (u"ࠪ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮࠭淶"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			code = -1
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			code = -1
			reason = l11l1l_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫ混")
		if l111l11111ll_l1_ and not l111lll11ll1_l1_ and code!=200:
			l111ll1_l1_ = l11111llll1l_l1_
			l111lll11ll1_l1_ = True
			continue
		break
	if l1llll111l11l_l1_!=None and l1lll111l1l11_l1_!=l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ淸"): connection.create_connection = l111l11ll1l1_l1_
	if l1lll111l1l11_l1_==l11l1l_l1_ (u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭淹") and l111lll1111l_l1_: l1llll111l11l_l1_ = None
	if not succeeded and l1lll11l111l1_l1_==None and source not in l1111lllll11_l1_:
		l1lll11111ll_l1_ = traceback.format_exc()
		sys.stderr.write(l1lll11111ll_l1_)
	else: pass
	code = int(code)
	l1l1lllll_l1_ = l1111llll11l_l1_()
	l1l1lllll_l1_.code = code
	l1l1lllll_l1_.reason = reason
	try: l1l1lllll_l1_.content = response.content
	except: l1l1lllll_l1_.content = l11l1l_l1_ (u"ࠧࠨ淺")
	if kodi_version>18.99:
		try: l1l1lllll_l1_.content = l1l1lllll_l1_.content.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭添"))
		except: pass
	l1lll111l1l1l_l1_ = l11l1l_l1_ (u"ࠩࠪ淼")
	if kodi_version<19 or isinstance(l1l1lllll_l1_.content,str):
		l1lll111l1l1l_l1_ = l1l1lllll_l1_.content.lower()
	if succeeded:
		l1l1lllll_l1_.succeeded = True
		l1l1lllll_l1_.headers 	= response.headers
		l1l1lllll_l1_.cookies 	= response.cookies
		l1l1lllll_l1_.url 	= l111lll_l1_
	try: response.close()
	except: pass
	l1l111l1111_l1_ = (l11l1l_l1_ (u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ淽") in l1lll111l1l1l_l1_ or l11l1l_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ淾") in l1lll111l1l1l_l1_) and l1lll111l1l1l_l1_.count(l11l1l_l1_ (u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ淿"))>2 and l11l1l_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ渀") not in source
	if code==200 and l1l111l1111_l1_: l1l1lllll_l1_.succeeded = False
	if l1l1lllll_l1_.succeeded and l1ll1llll111l_l1_ and l111l11111ll_l1_:
		l1l1llll1_l1_ = l11l1111llll_l1_(l1111l1ll1l1_l1_)
	if not l1l1lllll_l1_.succeeded and source in l1111lllll11_l1_:
		LOG_THIS(l11l1l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ渁"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤ࡚ࡴࡩ࡮ࡲࡲࡶࡹࡧ࡮ࡵࠢࡵࡩࡶࡻࡥࡴࡶࠣࡪࡦ࡯࡬ࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭渂")+l111ll1_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ渃")+source+l11l1l_l1_ (u"ࠪࠤࡢ࠭渄"))
	if not l1l1lllll_l1_.succeeded and l1ll1llll111l_l1_:
		l11lll11111_l1_ = (l11l1l_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ清") in l1lll111l1l1l_l1_ and l11l1l_l1_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ渆") in l1lll111l1l1l_l1_)
		l11111ll1ll1_l1_ = (l11l1l_l1_ (u"࠭࠵ࠡࡵࡨࡧࠬ渇") in l1lll111l1l1l_l1_ and l11l1l_l1_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ済") in l1lll111l1l1l_l1_)
		l1lllll11l1ll_l1_ = (code in [403] and l11l1l_l1_ (u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫ渉") in l1lll111l1l1l_l1_)
		l1lllll11ll11_l1_ = (l11l1l_l1_ (u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫ渊") in l1lll111l1l1l_l1_ and l11l1l_l1_ (u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧ渋") in l1lll111l1l1l_l1_)
		if   l1l111l1111_l1_: reason = l11l1l_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ渌")
		elif l11lll11111_l1_: reason = l11l1l_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭渍")
		elif l11111ll1ll1_l1_: reason = l11l1l_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭渎")
		elif l1lllll11l1ll_l1_: reason = l11l1l_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨ渏")
		elif l1lllll11ll11_l1_: reason = l11l1l_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ渐")
		else: reason = str(reason)
		if source not in l1111lllll11_l1_:
			LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ渑"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ渒")+str(code)+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭渓")+reason+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ渔")+source+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ渕")+l111ll1_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ渖"))
		l11111l1ll1l_l1_ = l1llll_l1_(l111ll1_l1_)
		if kodi_version<19 and isinstance(l11111l1ll1l_l1_,unicode): l11111l1ll1l_l1_ = l11111l1ll1l_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭渗"))
		if l111l11111ll_l1_: l11111l1ll1l_l1_ = l11111l1ll1l_l1_.split(l11l1l_l1_ (u"ࠩ࠲ࠫ渘"))[-1]
		reason = str(reason)+l11l1l_l1_ (u"ࠪࡠࡳ࠮ࠠࠨ渙")+l11111l1ll1l_l1_+l11l1l_l1_ (u"ࠫࠥ࠯ࠧ渚")
		if l1l111l1111_l1_ or l11lll11111_l1_ or l11111ll1ll1_l1_ or l1lllll11l1ll_l1_ or l1lllll11ll11_l1_:
			code = -2
			l1l1lllll_l1_.code = code
			l1l1lllll_l1_.reason = reason
		l1ll11111l_l1_ = True
		if (l1lll111l1l11_l1_==l11l1l_l1_ (u"ࠬࡇࡓࡌࠩ減") or l1lll11l1ll1l_l1_==l11l1l_l1_ (u"࠭ࡁࡔࡍࠪ渜")) and (l111lll1111l_l1_ or l1llll1111lll_l1_):
			l1ll11111l_l1_ = l1llllll11ll1_l1_(code,reason,source,l1ll_l1_)
			if l1ll11111l_l1_ and l1lll111l1l11_l1_==l11l1l_l1_ (u"ࠧࡂࡕࡎࠫ渝"): l1lll111l1l11_l1_ = l11l1l_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ渞")
			else: l1lll111l1l11_l1_ = l11l1l_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ渟")
			if l1ll11111l_l1_ and l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ渠"): l1lll11l1ll1l_l1_ = l11l1l_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭渡")
			else: l1lll11l1ll1l_l1_ = l11l1l_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ渢")
			settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭渣"),l1lll111l1l11_l1_)
			settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ渤"),l1lll11l1ll1l_l1_)
		if l1ll11111l_l1_:
			l1ll1lll1lll1_l1_ = True
			if code==8 and l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ渥") in l111ll1_l1_ and l1ll1lll1lll1_l1_:
				if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ渦"),l11l1l_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ渧"),time=2000)
				l111lll_l1_ = l111ll1_l1_+l11l1l_l1_ (u"ࠫࢁࢂࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ渨")
				l1l1llll1_l1_ = l1lll1111ll1_l1_(method,l111lll_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1llll1_l1_.succeeded:
					l1l1lllll_l1_ = l1l1llll1_l1_
					LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ温"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ渪")+source+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭渫")+url+l11l1l_l1_ (u"ࠨࠢࡠࠫ測"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭渭"),l11l1l_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ渮"),time=2000)
				else:
					LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ港"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ渰")+source+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ渱")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ渲"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫ渳"),l11l1l_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ渴"),time=2000)
			if not l1l1lllll_l1_.succeeded and l1lll11l1ll1l_l1_ in [l11l1l_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ渵"),l11l1l_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭渶")] and l1llll1111lll_l1_:
				if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ渷"),l11l1l_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ游"),time=2000)
				l1l1llll1_l1_ = l111lll111l1_l1_(method,l111ll1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1llll1_l1_.succeeded:
					l1l1lllll_l1_ = l1l1llll1_l1_
					LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭渹"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ渺")+source+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ渻")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭渼"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ渽"),l11l1l_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ渾"),time=2000)
				else:
					LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ渿"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ湀")+source+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ湁")+url+l11l1l_l1_ (u"ࠩࠣࡡࠬ湂"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ湃"),l11l1l_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭湄"),time=2000)
			if not l1l1lllll_l1_.succeeded and l1lll111l1l11_l1_ in [l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ湅"),l11l1l_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ湆")] and l111lll1111l_l1_:
				if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩ湇"),l11l1l_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ湈"),time=2000)
				l111lll_l1_ = l111ll1_l1_+l11l1l_l1_ (u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ湉")
				l1l1llll1_l1_ = l1lll1111ll1_l1_(method,l111lll_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1l1llll1_l1_.succeeded:
					l1l1lllll_l1_ = l1l1llll1_l1_
					LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ湊"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ湋")+l1ll1lll11lll_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ湌")+source+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ湍")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ湎"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩ湏"),l11l1l_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ湐"),time=2000)
				else:
					LOG_THIS(l11l1l_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ湑"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ湒")+l1ll1lll11lll_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ湓")+source+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ湔")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ湕"))
					if l1ll_l1_: l1lllll1_l1_(l11l1l_l1_ (u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨ湖"),l11l1l_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ湗"),time=2000)
		if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ湘") or l1lll111l1l11_l1_==l11l1l_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭湙"): l1ll_l1_ = False
		if not l1l1lllll_l1_.succeeded:
			if l1ll_l1_: l111lllll111_l1_ = l1llllll11ll1_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l111l1ll1l1l_l1_ and l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩ湚") not in source:
				l111111ll1ll_l1_(l11l1l_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬ湛")+source)
	if settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ湜")) not in [l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭湝"),l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ湞"),l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ湟")]: settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ湠"),l11l1l_l1_ (u"ࠬࡇࡓࡌࠩ湡"))
	if settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ湢")) not in [l11l1l_l1_ (u"ࠧࡂࡗࡗࡓࠬ湣"),l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭湤"),l11l1l_l1_ (u"ࠩࡄࡗࡐ࠭湥")]: settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ湦"),l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ湧"))
	return l1l1lllll_l1_
def OPENURL_REQUESTS_CACHED(l1l1ll1111l1_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111lll1111l_l1_=True,l1llll1111lll_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	response = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ湨"),l11l1l_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ湩"),item)
	if response.succeeded:
		l1llll1ll1ll1_l1_(True,url,data,headers,source,method)
		return response
	response = l1lll1111ll1_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111lll1111l_l1_,l1llll1111lll_l1_)
	if response.succeeded:
		if l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ湪") in source: response.content = DECODE_ADILBO_HTML(response.content)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫ湫"),item,response,l1l1ll1111l1_l1_)
	return response
def OPENURL_CACHED(l1l1ll1111l1_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭湬")
	else:
		method = l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ湭")
		data = l1llll_l1_(data)
		dummy,data = l1lll111ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1l1ll1111l1_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ湮"))
	html = str(html)
	return html
def l1lll11ll11ll_l1_(url):
	l1lll11l1l1ll_l1_ = url.split(l11l1l_l1_ (u"ࠬࢂࡼࠨ湯"))
	l111ll1_l1_,l1lll11l111l1_l1_,l1llll111l11l_l1_,l1lll1lll111l_l1_ = l1lll11l1l1ll_l1_[0],None,None,None
	for item in l1lll11l1l1ll_l1_:
		if l11l1l_l1_ (u"࠭ࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ湰") in item: l1lll11l111l1_l1_ = item.split(l11l1l_l1_ (u"ࠧ࠾ࠩ湱"))[1]
		elif l11l1l_l1_ (u"ࠨࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ湲") in item: l1llll111l11l_l1_ = item.split(l11l1l_l1_ (u"ࠩࡀࠫ湳"))[1]
		elif l11l1l_l1_ (u"ࠪࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭湴") in item: l1lll1lll111l_l1_ = item.split(l11l1l_l1_ (u"ࠫࡂ࠭湵"))[1]
	return l111ll1_l1_,l1lll11l111l1_l1_,l1llll111l11l_l1_,l1lll1lll111l_l1_
def RESTORE_PATH_NAME(name):
	start,l1ll11111l1_l1_,modified = l11l1l_l1_ (u"ࠬ࠭湶"),l11l1l_l1_ (u"࠭ࠧ湷"),l11l1l_l1_ (u"ࠧࠨ湸")
	name = name.replace(ltr,l11l1l_l1_ (u"ࠨࠩ湹")).replace(rtl,l11l1l_l1_ (u"ࠩࠪ湺"))
	tmp = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠯࡜࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡞ࡠࠬࡡࡽ࡜ࡸ࡞ࡺ࠭ࠥ࠱࡜࡜࡞࠲ࡇࡔࡒࡏࡓ࡞ࡠࠬ࠳࠰࠿ࠪࠦࠪ湻"),name,re.DOTALL)
	if tmp: start,l1ll11111l1_l1_,name = tmp[0]
	if start not in [l11l1l_l1_ (u"ࠫࠥ࠭湼"),l11l1l_l1_ (u"ࠬ࠲ࠧ湽"),l11l1l_l1_ (u"࠭ࠧ湾")]: modified = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭湿")
	if l1ll11111l1_l1_: l1ll11111l1_l1_ = l11l1l_l1_ (u"ࠨࡡࠪ満")+l1ll11111l1_l1_+l11l1l_l1_ (u"ࠩࡢࠫ溁")
	#datetime = re.findall(l11l1l_l1_ (u"ࠪࠬࡤࡢࡤ࡝ࡦ࡟࠲ࡡࡪ࡜ࡥࡡ࡟ࡨࡡࡪ࡜࠻࡞ࡧࡠࡩࡥࠩࠨ溂"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11l1l_l1_ (u"ࠫࠬ溃"))
	name = l1ll11111l1_l1_+modified+name
	return name
def l1ll1l11lll_l1_(url,l1lll1ll1ll11_l1_,l1lll1llll1l1_l1_,headers={}):
	l1ll1ll1ll111_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ溄"))
	l1l111ll1lll_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ溅")+l1lll1ll1ll11_l1_)
	if l1l111ll1lll_l1_: l111lll_l1_ = url.replace(l1ll1ll1ll111_l1_,l1l111ll1lll_l1_)
	else: l111lll_l1_ = url
	l1l1llll1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ溆"),l111lll_l1_,l11l1l_l1_ (u"ࠨࠩ溇"),headers,l11l1l_l1_ (u"ࠩࠪ溈"),l11l1l_l1_ (u"ࠪࠫ溉"),l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧ溊"))
	if not l1l1llll1_l1_.succeeded:
		l111ll1_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ溋")+l1lll1llll1l1_l1_
		l1l1l1lll_l1_ = {l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ溌"):l11l1l_l1_ (u"ࠧࠨ溍")}
		l1l1lllll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ溎"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ溏"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ源"),l11l1l_l1_ (u"ࠫࠬ溑"),l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠷ࡴࡤࠨ溒"))
		if l1l1lllll_l1_.succeeded:
			html = l1l1lllll_l1_.content
			if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ溓"),l11l1l_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ溔"))
			l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡺࡸ࡬࡝ࡁࡴࡁ࠭࠴ࠪࡀࠫࠥࠫ溕"),html,re.DOTALL)
			l11111ll1lll_l1_ = [l1l111ll1lll_l1_]
			for l1llll1_l1_ in l1l1_l1_:
				l1l111ll1lll_l1_ = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭準"))
				if l1l111ll1lll_l1_ in l11111ll1lll_l1_: continue
				if len(l11111ll1lll_l1_)==6: break
				l11111ll1lll_l1_.append(l1l111ll1lll_l1_)
				l111lll_l1_ = url.replace(l1ll1ll1ll111_l1_,l1l111ll1lll_l1_)
				l1l1llll1_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ溗"),l111lll_l1_,l11l1l_l1_ (u"ࠫࠬ溘"),headers,l11l1l_l1_ (u"ࠬ࠭溙"),l11l1l_l1_ (u"࠭ࠧ溚"),l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ溛"))
				if l1l1llll1_l1_.succeeded:
					LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭溜"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ溝")+l1lll1ll1ll11_l1_+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩ溞")+l1l111ll1lll_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ溟")+l1ll1ll1ll111_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ溠"))
					settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ溡")+l1lll1ll1ll11_l1_,l1l111ll1lll_l1_)
					break
	return l111lll_l1_,l1l1llll1_l1_
def LOG_THIS(level,message):
	l111l1l111ll_l1_ = l111l111llll_l1_
	lines = [l11l1l_l1_ (u"ࠧࠨ溢"),l11l1l_l1_ (u"ࠨࠩ溣")]
	if level:
		message = message.replace(l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ溤"),l11l1l_l1_ (u"ࠪࠫ溥")).replace(l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ溦"),l11l1l_l1_ (u"ࠬ࠭溧"))
		message = message.replace(l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ溨"),l11l1l_l1_ (u"ࠧࠨ溩"))
	else: level = l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ溪")
	if level==l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ溫"):
		l111l1l111ll_l1_ = xbmc.LOGERROR
		lines = message.strip(l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࠨ溬")).split(l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ溭"))
	elif level==l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ溮"):
		lines = message.strip(l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࠫ溯")).split(l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ溰"))
	elif level==l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ溱"):
		lines = message.split(l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ溲"))
	l111l11ll1_l1_ = l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠨ溳")
	l1ll1ll11lll1_l1_ = l111l11ll1_l1_+l111l11ll1_l1_+l111l11ll1_l1_
	shift = l1ll1ll11lll1_l1_+l1ll1ll11lll1_l1_
	if kodi_version>17.99: shift = shift+l11l1l_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩ溴")
	l111llll111l_l1_ = lines[0]
	for line in lines[1:]:
		if l11l1l_l1_ (u"ࠬࡢ࡮ࠨ溵") in line: line = line.replace(l11l1l_l1_ (u"࠭࡜࡯ࠩ溶"),l11l1l_l1_ (u"ࠧ࡝ࡰࠪ溷")+l111l11ll1_l1_+l111l11ll1_l1_)
		l1ll1ll11lll1_l1_ = l1ll1ll11lll1_l1_+l111l11ll1_l1_
		l111llll111l_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡵࠫ溸")+shift+l1ll1ll11lll1_l1_+line
	l111llll111l_l1_ += l11l1l_l1_ (u"ࠩࠣࡣࠬ溹")
	if l11l1l_l1_ (u"ࠪࠩࠬ溺") in l111llll111l_l1_: l111llll111l_l1_ = l1llll_l1_(l111llll111l_l1_)
	xbmc.log(l111llll111l_l1_,level=l111l1l111ll_l1_)
	return
def l1llll1ll1ll1_l1_(l111l1ll111l_l1_,url,data,headers,source,method):
	l1l1l1lll_l1_ = str(headers)[0:250].replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ溻"),l11l1l_l1_ (u"ࠬࡢ࡜࡯ࠩ溼")).replace(l11l1l_l1_ (u"࠭࡜ࡳࠩ溽"),l11l1l_l1_ (u"ࠧ࡝࡞ࡵࠫ溾")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠤࠥ࠭溿"),l11l1l_l1_ (u"ࠩࠣࠫ滀")).replace(l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ滁"),l11l1l_l1_ (u"ࠫࠥ࠭滂"))
	if len(str(headers))>250: l1l1l1lll_l1_ = l1l1l1lll_l1_+l11l1l_l1_ (u"ࠬࠦ࠮࠯࠰ࠪ滃")
	l11ll1111_l1_ = str(data)[0:250].replace(l11l1l_l1_ (u"࠭࡜࡯ࠩ滄"),l11l1l_l1_ (u"ࠧ࡝࡞ࡱࠫ滅")).replace(l11l1l_l1_ (u"ࠨ࡞ࡵࠫ滆"),l11l1l_l1_ (u"ࠩ࡟ࡠࡷ࠭滇")).replace(l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠨ滈"),l11l1l_l1_ (u"ࠫࠥ࠭滉")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ滊"),l11l1l_l1_ (u"࠭ࠠࠨ滋"))
	if len(str(data))>250: l11ll1111_l1_ = l11ll1111_l1_+l11l1l_l1_ (u"ࠧࠡ࠰࠱࠲ࠬ滌")
	if l111l1ll111l_l1_: LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ滍"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦࡃࡂࡅࡋࡉ࠿࡛ࠦࠡࠩ滎")+url+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ滏")+source+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭滐")+method+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ滑")+str(l1l1l1lll_l1_)+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭滒")+l11ll1111_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ滓"))
	else: LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ滔"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ滕")+url+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ滖")+source+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭滗")+method+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ滘")+str(l1l1l1lll_l1_)+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭滙")+l11ll1111_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ滚"))
	return
def TRANSLATE(text):
	dict = {
	 l11l1l_l1_ (u"ࠨࡱ࡯ࡨࠬ滛")			:l11l1l_l1_ (u"ࠩๅำ๏๋ࠧ滜")
	,l11l1l_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ滝")		:l11l1l_l1_ (u"๊ࠫะ่ใใࠪ滞")
	,l11l1l_l1_ (u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭滟")		:l11l1l_l1_ (u"࠭ๅโไ๋ำࠬ滠")
	,l11l1l_l1_ (u"ࠧࡨࡱࡲࡨࠬ满")			:l11l1l_l1_ (u"ࠨฮํำࠬ滢")
	,l11l1l_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ滣")		:l11l1l_l1_ (u"ࠪๅู๊ࠧ滤")
	,l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ滥")		:l11l1l_l1_ (u"๋ࠬฬๅัࠪ滦")
	,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ滧")		:l11l1l_l1_ (u"ࠧโ์า๎ํ࠭滨")
	,l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭滩")			:l11l1l_l1_ (u"ࠩๅ๊ฬฯࠧ滪")
	,l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ滫")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨ滬")
	,l11l1l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ滭")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪ滮")
	,l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ滯")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ滰")
	,l11l1l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ滱")		:l11l1l_l1_ (u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪ滲")
	,l11l1l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭滳")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫ滴")
	,l11l1l_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ滵")	:l11l1l_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪ滶")
	,l11l1l_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ滷")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭滸")
	,l11l1l_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ滹")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢ฼ีอࠦไ๋๊้ึࠬ滺")
	,l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ滻")	:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫ滼")
	,l11l1l_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ滽")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦวๅีํ๊๊อࠧ滾")
	,l11l1l_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ滿")		:l11l1l_l1_ (u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭漀")
	,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭漁")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡใส๊ื࠭漂")
	,l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ漃")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩ漄")
	,l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ漅")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩ漆")
	,l11l1l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ漇")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢ฼ีอࠦำ๋์าࠫ漈")
	,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭漉")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭漊")
	,l11l1l_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ漋")	:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫ漌")
	,l11l1l_l1_ (u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ漍")	:l11l1l_l1_ (u"้ࠪํอโฺࠢํ์ฯ๐่ษࠩ漎")
	,l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ漏")		:l11l1l_l1_ (u"๋่ࠬใ฻้ࠣฬ๐ࠠิ์่หࠬ漐")
	,l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭漑")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭漒")
	,l11l1l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ漓")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫ演")
	,l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ漕")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧ漖")
	,l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ漗")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤอ้ัศࠩ漘")
	,l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ漙")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩ漚")
	,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗࠩ漛")		:l11l1l_l1_ (u"้้ࠪ็ࠧ漜")
	,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝ࠬ漝")		:l11l1l_l1_ (u"๋ࠬไโࠩ漞")
	,l11l1l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭漟")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩ漠")
	,l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ漡")	:l11l1l_l1_ (u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧ漢")
	,l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ漣")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬ漤")
	,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ漥")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨ漦")
	,l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ漧")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨ漨")
	,l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ漩")		:l11l1l_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ漪")
	,l11l1l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭漫")		:l11l1l_l1_ (u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬ漬")
	,l11l1l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ漭")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭漮")
	,l11l1l_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ漯")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ漰")
	,l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭漱")	:l11l1l_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠๅษํฮࠬ漲")
	,l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ漳")	:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧ漴")
	,l11l1l_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭漵")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦแ้ีอหࠬ漶")
	,l11l1l_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ漷")		:l11l1l_l1_ (u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬ漸")
	,l11l1l_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ漹")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣๅอืใสࠩ漺")
	,l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ漻")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ漼")
	,l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ漽")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ漾")
	,l11l1l_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ漿")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢหีุะ๊อࠩ潀")
	,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭潁")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭潂")
	,l11l1l_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ潃")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭潄")
	,l11l1l_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ潅")		:l11l1l_l1_ (u"้ࠪํู่ࠡ์สๆํะࠧ潆")
	,l11l1l_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭潇")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠩ潈")
	,l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ潉")	:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩ潊")
	,l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ潋")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩ潌")
	,l11l1l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ潍")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪ潎")
	,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ潏")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧ潐")
	,l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭潑")				:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ潒")
	,l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ潓")			:l11l1l_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬ潔")
	,l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ潕")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪ潖")
	,l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ潗")					:l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ潘")
	,l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ潙")			:l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭潚")
	,l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ潛")			:l11l1l_l1_ (u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨ潜")
	,l11l1l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ潝")			:l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬ潞")
	,l11l1l_l1_ (u"ࠧࡎ࠵ࡘࠫ潟")					:l11l1l_l1_ (u"ࠨࡏ࠶࡙ࠬ潠")
	,l11l1l_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ潡")				:l11l1l_l1_ (u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭潢")
	,l11l1l_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ潣")			:l11l1l_l1_ (u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨ潤")
	,l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ潥")			:l11l1l_l1_ (u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬ潦")
	,l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ潧")				:l11l1l_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭潨")
	,l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩ潩")			:l11l1l_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧ潪")
	,l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ潫")			:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫ潬")
	,l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ潭")				:l11l1l_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭潮")
	,l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ潯")		:l11l1l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪ潰")
	,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ潱")	:l11l1l_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩ潲")
	,l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ潳")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫ潴")
	,l11l1l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ潵")			:l11l1l_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫ潶")
	,l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ潷")	:l11l1l_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫ潸")
	,l11l1l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࠨ潹")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧ潺")
	,l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࠪ潻")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪ潼")
	,l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ潽")			:l11l1l_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠫ潾")
	,l11l1l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ潿")	:l11l1l_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨ澀")
	,l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ澁"):l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧ澂")
	,l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ澃")	:l11l1l_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆ๋๎วหࠩ澄")
	,l11l1l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ澅")	:l11l1l_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬ澆")
	}
	if text in list(dict.keys()): return dict[text]
	return l11l1l_l1_ (u"ࠬ࠭澇")
def LOGGING(l1ll1_l1_):
	l1llll11l1111_l1_ = sys._getframe(1).f_code.co_name
	if l1ll1_l1_==l11l1l_l1_ (u"࠭ࡍࡂࡋࡑࡑࡊࡔࡕࠨ澈") and l1llll11l1111_l1_==l11l1l_l1_ (u"ࠧࡎࡃࡌࡒࡒࡋࡎࡖࠩ澉"):
		return l11l1l_l1_ (u"ࠨ࡝ࠣࠫ澊")+l1lll11ll1lll_l1_.upper()+l11l1l_l1_ (u"ࠩ࠰ࠫ澋")+addon_version+l11l1l_l1_ (u"ࠪ࠱ࠬ澌")+l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠲࠭澍")+l1llll11l1111_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ澎")
	return l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࠫ澏")+l1llll11l1111_l1_
def l111111ll1ll_l1_(message):
	l1lll1lllll11_l1_(l11l1l_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ澐")+message)
	sys.exit()
	return
def QUOTE(urll,exceptions=l11l1l_l1_ (u"ࠨ࠼࠲ࠫ澑")):
	return _1lllll1ll1ll_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l1llll_l1_(urll):
	return _111ll1l1111_l1_(urll)
	#return urllib2.unquote(urll)
def l111l11l1l11_l1_(l1l111l1l_l1_):
	if l1l111l1l_l1_ in [l11l1l_l1_ (u"ࠩࠪ澒"),l11l1l_l1_ (u"ࠪ࠴ࠬ澓"),0]: return l11l1l_l1_ (u"ࠫࠬ澔")
	l1l111l1l_l1_ = int(l1l111l1l_l1_)
	first = l1l111l1l_l1_^l1llll1l_l1_
	second = l1l111l1l_l1_^REGULAR_CACHE
	l1ll1ll1l_l1_ = l1l111l1l_l1_^l1ll1ll11_l1_
	result = str(first)+str(second)+str(l1ll1ll1l_l1_)
	return result
def l1lll11111111_l1_(l1l111l1l_l1_):
	if l1l111l1l_l1_ in [l11l1l_l1_ (u"ࠬ࠭澕"),l11l1l_l1_ (u"࠭࠰ࠨ澖"),0]: return l11l1l_l1_ (u"ࠧࠨ澗")
	l1l111l1l_l1_ = str(l1l111l1l_l1_)
	result = l11l1l_l1_ (u"ࠨࠩ澘")
	if len(l1l111l1l_l1_)==15:
		first,second,l1ll1ll1l_l1_ = l1l111l1l_l1_[0:4],l1l111l1l_l1_[4:9],l1l111l1l_l1_[9:]
		first = int(first)^l1ll1ll11_l1_
		second = int(second)^REGULAR_CACHE
		l1ll1ll1l_l1_ = int(l1ll1ll1l_l1_)^l1llll1l_l1_
		if first==second==l1ll1ll1l_l1_: result = str(first*60)
	return result
def l1lll1lllllll_l1_(l1l111l1l_l1_):
	if l1l111l1l_l1_ in [l11l1l_l1_ (u"ࠩࠪ澙"),l11l1l_l1_ (u"ࠪ࠴ࠬ澚"),0]: return l11l1l_l1_ (u"ࠫࠬ澛")
	l1l111l1l_l1_ = int(l1l111l1l_l1_)+63841823
	first = l1l111l1l_l1_^l1llll1l_l1_
	second = l1l111l1l_l1_^REGULAR_CACHE
	l1ll1ll1l_l1_ = l1l111l1l_l1_^l1ll1ll11_l1_
	result = str(first)+str(second)+str(l1ll1ll1l_l1_)
	return result
def l111111ll111_l1_(l1l111l1l_l1_):
	if l1l111l1l_l1_ in [l11l1l_l1_ (u"ࠬ࠭澜"),l11l1l_l1_ (u"࠭࠰ࠨ澝"),0]: return l11l1l_l1_ (u"ࠧࠨ澞")
	l1l111l1l_l1_ = str(l1l111l1l_l1_)
	length = int(len(l1l111l1l_l1_)/3)
	first = int(l1l111l1l_l1_[0:length])^l1llll1l_l1_
	second = int(l1l111l1l_l1_[length:2*length])^REGULAR_CACHE
	l1ll1ll1l_l1_ = int(l1l111l1l_l1_[2*length:3*length])^l1ll1ll11_l1_
	result = l11l1l_l1_ (u"ࠨࠩ澟")
	if first==second==l1ll1ll1l_l1_: result = str(int(first)-63841823)
	return result
def l11l11l1ll1_l1_(l111ll1ll1l1_l1_):
	addons = l111l111111l_l1_()
	l11l1l11111_l1_ = False
	for addon_id in l111ll1ll1l1_l1_:
		if addon_id not in list(addons.keys()): continue
		l1111l11llll_l1_ = addons[addon_id]
		l1l111ll1l1l_l1_,l1l11lll11ll_l1_,l11ll11l11ll_l1_ = l1111l11llll_l1_[0]
		l1l11111lll1_l1_,l1l11ll11l11_l1_ = l1llll1ll11l1_l1_(addon_id)
		if not l1l11111lll1_l1_:
			l11l1l11111_l1_ = True
			break
		else:
			l111lllll1ll_l1_ = l1l11lll11ll_l1_>l1l11ll11l11_l1_
			if l111lllll1ll_l1_:
				l11l1l11111_l1_ = True
				break
	return l11l1l11111_l1_
def l1l1l1111l_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll111ll1_l1_(l1lll1l11l1ll_l1_,l1lll1l111l1l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࠪ澠"),l11l1l_l1_ (u"ࠪࠫ澡"),l11l1l_l1_ (u"ࠫࠬ澢"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ澣"),l1lll1l11l1ll_l1_+l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ澤")+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ澥"))
		if l1ll11111l_l1_!=1: return
	error = False
	if os.path.exists(l1lll1l11l1ll_l1_):
		#os.chmod(l1lll1l11l1ll_l1_,0o777)
		for root,dirs,files in os.walk(l1lll1l11l1ll_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ澦"),filepath)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ澧"),l11l1l_l1_ (u"ࠪࠫ澨"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ澩"),str(err))
					error = True
			if l1lll1l111l1l_l1_:
				for dir in dirs:
					l1lll11l1ll11_l1_ = os.path.join(root,dir)
					#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭澪"),l1lll11l1ll11_l1_)
					os.rmdir(l1lll11l1ll11_l1_)
		if l1lll1l111l1l_l1_: os.rmdir(root)
	if l1ll_l1_ and not error:
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ澫"),l11l1l_l1_ (u"ࠧࠨ澬"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ澭"),l11l1l_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ澮"))
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ澯"),l11l1l_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ澰"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ澱"))
	return
def l1lll1lllll11_l1_(l1lll11111ll_l1_):
	l1ll11111_l1_(l11l1l_l1_ (u"࠭ࡳࡵࡱࡳࠫ澲"))
	if l1lll11111ll_l1_:
		if l11l1l_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ澳") in l1lll11111ll_l1_:
			message  = l1lll11111ll_l1_.split(l11l1l_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ澴"))[1]
			LOG_THIS(l11l1l_l1_ (u"ࠩࠪ澵"),l11l1l_l1_ (u"ࠪࡊࡔࡘࡃࡆࡆࠣࡉ࡝ࡏࡔࠡࠢࠣࠤ࠳ࠦࠠࠡࠩ澶")+message)
			#sys.stderr.write(l11l1l_l1_ (u"ࠫࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕ࠼࡟ࡲࠬ澷")+message+l11l1l_l1_ (u"ࠬࡢ࡮ࡠࠩ澸"))
		else: l111l1l1l111_l1_(l1lll11111ll_l1_)
	l1l11ll11l_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ澹"))
	if l1l11ll11l_l1_==l11l1l_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ澺"): settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ澻"),l11l1l_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ澼"))
	elif l1l11ll11l_l1_==l11l1l_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭澽"): settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ澾"),l11l1l_l1_ (u"ࠬ࠭澿"))
	if settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭激")) not in [l11l1l_l1_ (u"ࠧࡂࡗࡗࡓࠬ濁"),l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭濂"),l11l1l_l1_ (u"ࠩࡄࡗࡐ࠭濃")]: settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ濄"),l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ濅"))
	if settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ濆")) not in [l11l1l_l1_ (u"࠭ࡁࡖࡖࡒࠫ濇"),l11l1l_l1_ (u"ࠧࡔࡖࡒࡔࠬ濈"),l11l1l_l1_ (u"ࠨࡃࡖࡏࠬ濉")]: settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ濊"),l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ濋"))
	l1l11l1l1lll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ濌"))
	l11ll1ll1111_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ濍"))
	if l11l1l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ濎") in str(l11ll1ll1111_l1_) and l1l11l1l1lll_l1_ in [l11l1l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ濏"),l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ濐")]:
		#l1lllll1_l1_(l11l1l_l1_ (u"ࠩࠪ濑"),l1l11l1l1lll_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧ濒"))
	#l111ll1llll1_l1_ = sys.version_info[0]
	#l111l11l1lll_l1_ = sys.version_info[1]
	#if l111ll1llll1_l1_==2: python_version = l11l1l_l1_ (u"ࠫ࠷࠽ࠧ濓")
	#else: python_version = str(l111ll1llll1_l1_)+str(l111l11l1lll_l1_)
	#l111llll11ll_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ濔")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ濕"),l11l1l_l1_ (u"ࠧࠨ濖"),l11l1l_l1_ (u"ࠨࠩ濗"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l11111lllll1_l1_,l111lll111ll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l11111lllll1_l1_,l111lll111ll_l1_)
	return
if __name__==l11l1l_l1_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫ濘"):
	# should l111l111l1_l1_ l1l1ll11_l1_ when l1ll1ll11l111_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ濙"),l11l1l_l1_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠩ濚"))
	l1lll11111ll_l1_ = l11l1l_l1_ (u"ࠬ࠭濛")
	if 0:
		url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡵ࡮ࡦ࠱ࡹ࡭ࡩ࡫࡯ࡠࡲ࡯ࡥࡾ࡫ࡲࡀࡷ࡬ࡨࡂ࠶ࠦࡷ࡫ࡧࡁ࡫࡬ࡢ࠸࠲࠻ࡧ࠶࠿࠲ࡤ࠴࠻ࡨ࠶࠷࠲࠱࠴ࡤࡨ࠶࠾ࡤࡥ࠳࠵ࡧ࠻࠾࠰࠷ࠩ濜")
		import ll_l1_
		a,b,c = ll_l1_.l1ll1l111l1_l1_(url)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ濝"),l11l1l_l1_ (u"ࠨࠩ濞"),l11l1l_l1_ (u"ࠩࠪ濟"),str(c))
		l1l1l1l1l11_l1_ = c[0][0]
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ濠"),l1l1l1l1l11_l1_)
		l1l1l1l1l11_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸ࠲࠴࠯࠰ࡦࡰࡿࡣࡧࡥ࡯࡮࠳ࡩ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡵࡷࡶࡪࡧ࡭࠰ࡸ࠴࠳࡭ࡲࡳ࠰࠵ࡧ࡙࡙ࡌ࠷࡚࠹ࡈࡆࡌࡲࡕࡳࡘࡍࡎࡹ࠸ࡋࡘࡩ࠲࠵࠻࠾࠳࠷࠻࠼࠶࠾࠺࠯ࡢ࡮࡯࠳ࡦࡲ࡬࠰࠳࠳࠻࠳࠷࠵࠺࠰࠴࠸࠳࠺࠳࠰ࡻࡨࡷ࠴ࡉࡁ࠰࠲࠲࠴࠻࠳࠰࠳࠱࠵࠳࡫࡬ࡢ࠸࠲࠻ࡧ࠶࠿࠲ࡤ࠴࠻ࡨ࠶࠷࠲࠱࠴ࡤࡨ࠶࠾ࡤࡥ࠳࠵ࡧ࠻࠾࠰࠷࠱࠴࠹࠺ࡥࡨࡥ࠹࠵࠴ࡧࡥࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯࡯࠶ࡹ࠽࠭濡")
		#PLAY_VIDEO(l1l1l1l1l11_l1_)
		l1ll1ll11ll11_l1_ = xbmcgui.ListItem()
		#l1ll1ll11ll11_l1_.setPath(l1l1l1l1l11_l1_)
		#xbmcplugin.setResolvedUrl(addon_handle,True,l1ll1ll11ll11_l1_)
		xbmc.Player().play(l1l1l1l1l11_l1_,l1ll1ll11ll11_l1_)
	else:
		l1ll11111_l1_(l11l1l_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ濢"))
		try: l111111ll11l_l1_()
		except Exception as error: l1lll11111ll_l1_ = traceback.format_exc()
	l1lll1lllll11_l1_(l1lll11111ll_l1_)
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ᫹")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡉࡍࡏࡡࠪ᫺")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"่ࠬวว็อ๎ࠬ᫻")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l11lll_l1_(url)
	elif mode==302: results = l1lllll_l1_(url)
	elif mode==303: results = l1lll11lll_l1_(url)
	elif mode==304: results = l1lll1ll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll11ll11_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᫼"),l1111l_l1_+l11l1l_l1_ (u"ࠧๅ็สิฬࠦวๅ็๋ๆ฾ࠦศุ์ฤࠫ᫽"),l11l1l_l1_ (u"ࠨࠩ᫾"),306)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᫿"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᬀ"),l11l1l_l1_ (u"ࠫࠬᬁ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬂ"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᬃ"),l11l1l_l1_ (u"ࠧࠨᬄ"),309,l11l1l_l1_ (u"ࠨࠩᬅ"),l11l1l_l1_ (u"ࠩࠪᬆ"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᬇ"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᬈ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᬉ"),l11l1l_l1_ (u"࠭ࠧᬊ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫᬋ"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᬌ"),l11l1l_l1_ (u"ࠩࠪᬍ"),l11l1l_l1_ (u"ࠪࠫᬎ"),l11l1l_l1_ (u"ࠫࠬᬏ"),l11l1l_l1_ (u"ࠬ࠭ᬐ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᬑ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11l1l_l1_ (u"ࠧࠨᬒ"),html)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫ࡩࡦࡪࡥࡳࡀࠪᬓ"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᬔ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		#l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬᬕ"))
		#if title==l11l1l_l1_ (u"ࠫึ๋ึศ่ࠪᬖ"): l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ำฺ่ฬ์࠯ࠨᬗ")
		if not any(value in title for value in l1l111_l1_):
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬘ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᬙ")+l1111l_l1_+title,l1llll1_l1_,301)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᬚ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᬛ"),l11l1l_l1_ (u"ࠪࠫᬜ"),9999)
	l11lll_l1_(l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᬝ"),html)
	return html
def l1ll11ll11_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᬞ"),l11l1l_l1_ (u"࠭ࠧᬟ"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᬠ"),l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠡสฺ๎ฦࠦๅ็ࠢส่๊฻ฯาࠢ࠱࠲ࠥฮำษสࠣๆ๏อๅࠡลุัฬฮࠠศๆ่์็฿ࠠษฬืๅ๏ืࠠๆฯอ์๏อสࠡฮ่๎฾ࠦีโฯสฮࠥอไๆ๊ๅ฽ࠥ࠴࠮๊ࠡส่ํ่สࠡษ็ฺฬฬูࠡ์ำ๋อࠦแ๋่ࠢ฽ฬ๊ฬสࠢอุๆ๐ัࠡษ็ูๆำวหࠢสฺ่๊แาหࠣๆอฺ๊ࠠำูࠤ๊ำส้์สฮ์อࠠโ์ࠣๆํอฦๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠨᬡ"))
	return
def l11lll_l1_(url,html=l11l1l_l1_ (u"ࠩࠪᬢ")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᬣ"),url,l11l1l_l1_ (u"ࠫࠬᬤ"),l11l1l_l1_ (u"ࠬ࠭ᬥ"),l11l1l_l1_ (u"࠭ࠧᬦ"),l11l1l_l1_ (u"ࠧࠨᬧ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᬨ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴ࠪࡀ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂ࠮࠭ᬩ"),html,re.DOTALL)
	if l1l11ll_l1_:
		for block in l1l11ll_l1_:
			seq += 1
			items = re.findall(l11l1l_l1_ (u"ࠪࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᬪ"),block,re.DOTALL)
			for title,test,l1llll1_l1_ in items:
				title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭ᬫ"))
				if title==l11l1l_l1_ (u"ࠬ࠭ᬬ"): title = l11l1l_l1_ (u"࠭ศ้๊๋์ํ࠭ᬭ")
				if l11l1l_l1_ (u"ࠧࡦ࡯ࡁࡀࡦ࠭ᬮ") not in test:
					if block.count(l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬᬯ"))>0:
						l1ll11l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᬰ"),block,re.DOTALL)
						for l1llll1_l1_ in l1ll11l1ll_l1_:
							title = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࠳ࠬᬱ"))[-2]
							addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬲ"),l1111l_l1_+title,l1llll1_l1_,301)
						continue
					else: l1llll1_l1_ = url+l11l1l_l1_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩᬳ")+str(seq)
				#l1111l1l1_l1_ = [l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ᬴"),l11l1l_l1_ (u"ࠧศใ็ห๊ࠦࠧᬵ"),l11l1l_l1_ (u"ࠨสิห๊าࠧᬶ"),l11l1l_l1_ (u"ࠩ฼ีํ฼ࠧᬷ"),l11l1l_l1_ (u"ࠪ็้๐ศศฬࠪᬸ"),l11l1l_l1_ (u"ࠫฬเว็๋ࠪᬹ")]
				#if any(value in title for value in l1111l1l1_l1_):
				if not any(value in title for value in l1l111_l1_):
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬺ"),l1111l_l1_+title,l1llll1_l1_,302)
	else: l1lllll_l1_(url,html)
	return
def l1lllll_l1_(url,html=l11l1l_l1_ (u"࠭ࠧᬻ")):
	if html==l11l1l_l1_ (u"ࠧࠨᬼ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᬽ"),url,l11l1l_l1_ (u"ࠩࠪᬾ"),l11l1l_l1_ (u"ࠪࠫᬿ"),l11l1l_l1_ (u"ࠫࠬᭀ"),l11l1l_l1_ (u"ࠬ࠭ᭁ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᭂ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11l1l_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫᭃ") in url:
		url,seq = url.split(l11l1l_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁ᭄ࠬ"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴ࠪࡀ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂ࠮࠭ᭅ"),html,re.DOTALL)
		block = l1l11ll_l1_[int(seq)-1]
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡴࡪࡹ࠿ࠩᭆ"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫࡁࡧ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᭇ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1llll1_l1_,data,l1ll1l_l1_ in items:
		title = re.findall(l11l1l_l1_ (u"ࠬࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠰࠭ࡃࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡰࡂࠬᭈ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11l1l_l1_ (u"࠭࡜࡯ࠩᭉ"),l11l1l_l1_ (u"ࠧࠨᭊ")).strip(l11l1l_l1_ (u"ࠨࠢࠪᭋ"))
		if not title or title==l11l1l_l1_ (u"ࠩࠪᭌ"):
			title = re.findall(l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤࡁ࠲࠯ࡅ࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᭍"),data,re.DOTALL)
			if title: title = title[0].replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ᭎"),l11l1l_l1_ (u"ࠬ࠭᭏")).strip(l11l1l_l1_ (u"࠭ࠠࠨ᭐"))
			if not title or title==l11l1l_l1_ (u"ࠧࠨ᭑"):
				title = re.findall(l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᭒"),data,re.DOTALL)
				title = title[0].replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ᭓"),l11l1l_l1_ (u"ࠪࠫ᭔")).strip(l11l1l_l1_ (u"ࠫࠥ࠭᭕"))
		title = unescapeHTML(title)
		#if title==l11l1l_l1_ (u"ࠬ࠭᭖"): continue
		if title not in l11l_l1_:
			l11l_l1_.append(title)
			l1ll111_l1_ = l1llll1_l1_+data+l1ll1l_l1_
			if l11l1l_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ᭗") in l1ll111_l1_ or l11l1l_l1_ (u"ࠧๆี็ื้࠭᭘") in l1ll111_l1_ or l11l1l_l1_ (u"ࠨࠤࡨࡴ࡮ࡹ࡯ࡥࡧࠥࠫ᭙") in l1ll111_l1_:
				if l11l1l_l1_ (u"ࠩหีฬ๋ฬࠨ᭚") in data: title = l11l1l_l1_ (u"ࠪฬึ์วๆฮࠣࠫ᭛")+title
				elif l11l1l_l1_ (u"ู๊ࠫไิๆࠪ᭜") in data or l11l1l_l1_ (u"๋่ࠬิ็ࠪ᭝") in data: title = l11l1l_l1_ (u"࠭ๅิๆึ่ࠥ࠭᭞")+title
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᭟"),l1111l_l1_+title,l1llll1_l1_,303,l1ll1l_l1_)
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᭠"),l1111l_l1_+title,l1llll1_l1_,305,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᭡"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᭢"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᭣"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ᭤")+title,l1llll1_l1_,302)
	return
def l1lll11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ᭥"),url,l11l1l_l1_ (u"ࠧࠨ᭦"),l11l1l_l1_ (u"ࠨࠩ᭧"),l11l1l_l1_ (u"ࠩࠪ᭨"),l11l1l_l1_ (u"ࠪࠫ᭩"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪ᭪"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11l1l_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂࠬ᭫"),html,re.DOTALL)
	name = name[0].replace(l11l1l_l1_ (u"࠭ࡼࠡีํ้ฬࠦๆศ๊᭬ࠪ"),l11l1l_l1_ (u"ࠧࠨ᭭")).replace(l11l1l_l1_ (u"ࠨࡅ࡬ࡱࡦࠦࡎࡰࡹࠪ᭮"),l11l1l_l1_ (u"ࠩࠪ᭯")).strip(l11l1l_l1_ (u"ࠪࠤࠬ᭰")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ᭱"),l11l1l_l1_ (u"ࠬࠦࠧ᭲"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡴࡧࡤࡷࡴࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡧࡹ࡯࡯࡯ࡀࠪ᭳"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᭴"),block,re.DOTALL)
		if len(items)>1:
			for l1llll1_l1_,title in items:
				#title = name+l11l1l_l1_ (u"ࠨࠢࠪ᭵")+title.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ᭶"),l11l1l_l1_ (u"ࠪࠫ᭷")).strip(l11l1l_l1_ (u"ࠫࠥ࠭᭸"))
				title = title.replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ᭹"),l11l1l_l1_ (u"࠭ࠧ᭺")).strip(l11l1l_l1_ (u"ࠧࠡࠩ᭻"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᭼"),l1111l_l1_+title,l1llll1_l1_,304)
		else: l1lll1ll_l1_(url)
	return
def l1lll1ll_l1_(url):
	if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫ᭽") not in url: url = url.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ᭾"))+l11l1l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࡭ࡳ࡭ࠧ᭿")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩᮀ"),url,l11l1l_l1_ (u"࠭ࠧᮁ"),l11l1l_l1_ (u"ࠧࠨᮂ"),l11l1l_l1_ (u"ࠨࠩᮃ"),l11l1l_l1_ (u"ࠩࠪᮄ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᮅ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬᮆ"),html)
	if l11l1l_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧᮇ") not in url:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᮈ"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᮉ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫᮊ"),l11l1l_l1_ (u"ࠩࠪᮋ")).strip(l11l1l_l1_ (u"ࠪࠤࠬᮌ"))
			title = l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠤࠬᮍ")+title
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᮎ"),l1111l_l1_+title,l1llll1_l1_,305)
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡥࡧࡷࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩᮏ"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᮐ"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫᮑ"),l11l1l_l1_ (u"ࠩࠪᮒ")).strip(l11l1l_l1_ (u"ࠪࠤࠬᮓ"))
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᮔ"),l1111l_l1_+title,l1llll1_l1_,305,l1ll1l_l1_)
	return
def PLAY(url):
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࠩࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡮ࡩ࡯ࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ࠯ࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡇࡉࡈࡕࡄࡆࡡࡄࡈࡎࡒࡂࡐࡡࡋࡘࡒࡒࠨࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠩࠋࠋࡦࡳࡴࡱࡩࡦࡵࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡲ࡯࡮࡫ࡳ࠯ࡩࡨࡸࡤࡪࡩࡤࡶࠫ࠭ࠏࠏࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࠢࡀࠤࡨࡵ࡯࡬࡫ࡨࡷࡠ࠭ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࠩࡠࠎࠎࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠥ࡬ࡷ࡫ࡦࠡ࠿ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ࠱ࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿ࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠱࠭ࡃࡰࡱ࡮࡭ࡪ࠭࠺ࠨࡒࡋࡔࡘࡋࡓࡔࡋࡇࡁࠬ࠱ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭ࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡥࡩࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡡࡥࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡤࡨࡤࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࠤࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡧࡤࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨࠫࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࠩࡡࡥࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡇࡉࡈࡕࡄࡆࡡࡄࡈࡎࡒࡂࡐࡡࡋࡘࡒࡒࠨࡢࡦࡢ࡬ࡹࡳ࡬ࠪࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡦࡹࡴࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡦ࡬ࡷࡵࡲࡡࡺ࠼ࠣࡲࡴࡴࡥ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࡟࠵ࡣࠫࠨ࠱ࠪࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡥ࠲ࡨ࡯࡭ࡢࡸ࡬ࡨࡸ࠴࡬ࡪࡸࡨ࠳ࠬࢃࠊࠊࠤࠥࠦᮕ")
	l111ll1_l1_ = url+l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬࡮ࡴࡧ࠰ࠩᮖ")
	#server = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫᮗ"))
	#l1l1l1lll_l1_ = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᮘ"):None,l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᮙ"):server}
	response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᮚ"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬᮛ"),l11l1l_l1_ (u"ࠬ࠭ᮜ"),l11l1l_l1_ (u"࠭ࠧᮝ"),l11l1l_l1_ (u"ࠧࠨᮞ"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫᮟ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l111ll1_l1_ = l1ll11llll_l1_(l111ll1_l1_,l11l1l_l1_ (u"ࠩ࡯ࡳࡼ࡫ࡲࠨᮠ"))
	#html = l1ll11ll1l_l1_(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᮡ"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬᮢ"),l11l1l_l1_ (u"ࠬ࠭ᮣ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩᮤ"))
	#if html and kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᮥ"))
	#html = DECODE_ADILBO_HTML(html)
	l1lll1_l1_ = []
	# download l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᮦ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᮧ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭ᮨ"),l11l1l_l1_ (u"ࠫࠬᮩ")).strip(l11l1l_l1_ (u"᮪ࠬࠦࠧ"))
			l111ll1l_l1_ = re.findall(l11l1l_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱᮫ࠧ"),title,re.DOTALL)
			if l111ll1l_l1_:
				l111ll1l_l1_ = l11l1l_l1_ (u"ࠧࡠࡡࡢࡣࠬᮬ")+l111ll1l_l1_[0]
				#title = l11l1l_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᮭ")
				title = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧᮮ"))
			else: l111ll1l_l1_ = l11l1l_l1_ (u"ࠪࠫᮯ")
			l1llll11ll_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᮰")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ᮱")+l111ll1l_l1_
			l1lll1_l1_.append(l1llll11ll_l1_)
	# l11l1l111_l1_ l1l1_l1_
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡸࡣࡷࡧ࡭ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᮲"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		# l1l1111ll_l1_ l11l1l111_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠱࠲࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭᮳"),block,re.DOTALL)
		for l1llll1_l1_ in l1l1_l1_:
			l1llll1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ᮴")+l1llll1_l1_
			title = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ᮵"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᮶")+title+l11l1l_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬ᮷")
			l1lll1_l1_.append(l1llll1_l1_)
		# l1ll11lll1_l1_ l11l1l111_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡧࡪࡢࡺ࡟ࠬࢀࡻࡲ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ᮸"),html,re.DOTALL)
		if l1l1_l1_:
			items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡴࡤࡦࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ᮹"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11l1l_l1_ (u"ࠧ࡝ࡰࠪᮺ"),l11l1l_l1_ (u"ࠨࠩᮻ")).strip(l11l1l_l1_ (u"ࠩࠣࠫᮼ"))
				title = title.replace(l11l1l_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬᮽ"),l11l1l_l1_ (u"ࠫࡈ࡯࡭ࡢࡐࡲࡻࠬᮾ"))
				l1llll1_l1_ = l1l1_l1_[0]+l11l1l_l1_ (u"ࠬࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡸ࡫ࡷࡧ࡭ࠬࡩ࡯ࡦࡨࡼࡂ࠭ᮿ")+index+l11l1l_l1_ (u"࠭ࠦࡪࡦࡀࠫᯀ")+id+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᯁ")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᯂ")
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᯃ"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᯄ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬᯅ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭ᯆ"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨᯇ"),l11l1l_l1_ (u"ࠧࠬࠩᯈ"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭ᯉ")+search
	l1lllll_l1_(url)
	return
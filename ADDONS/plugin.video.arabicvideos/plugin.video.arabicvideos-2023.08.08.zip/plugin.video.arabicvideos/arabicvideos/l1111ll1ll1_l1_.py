# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨ䉫")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡏࡗ࡙ࡥࠧ䉬")
l111ll11lll_l1_ = 5
l111l1ll11l_l1_ = 10
def MAIN(mode,url,text,l11llll_l1_,l1ll1l1lll1_l1_):
	try: l1l11l1l11l_l1_ = str(l1ll1l1lll1_l1_[l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉭")])
	except: l1l11l1l11l_l1_ = l11l1l_l1_ (u"ࠪࠫ䉮")
	if   mode==160: results = MENU()
	elif mode==161: results = l111lll1l11_l1_(text)
	elif mode==162: results = l111l11ll11_l1_(text,162)
	elif mode==163: results = l111l11ll11_l1_(text,163)
	elif mode==164: results = l111lll11l1_l1_(text)
	elif mode==165: results = l111ll11l11_l1_(l1l11l1l11l_l1_,text,l11llll_l1_)
	elif mode==166: results = l111ll1l1ll_l1_(url,text)
	elif mode==167: results = l1111lllll1_l1_(url,text)
	elif mode==168: results = l1111ll111l_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉯"),l11l1l_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭䉰"),l11l1l_l1_ (u"࠭ࠧ䉱"),161,l11l1l_l1_ (u"ࠧࠨ䉲"),l11l1l_l1_ (u"ࠨࠩ䉳"),l11l1l_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䉴"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉵"),l11l1l_l1_ (u"ࠫ็ูๅࠡ฻ื์ฬฬ๊ࠨ䉶"),l11l1l_l1_ (u"ࠬ࠭䉷"),162,l11l1l_l1_ (u"࠭ࠧ䉸"),l11l1l_l1_ (u"ࠧࠨ䉹"),l11l1l_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䉺"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉻"),l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭䉼"),l11l1l_l1_ (u"ࠫࠬ䉽"),163,l11l1l_l1_ (u"ࠬ࠭䉾"),l11l1l_l1_ (u"࠭ࠧ䉿"),l11l1l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䊀"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊁"),l11l1l_l1_ (u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ䊂"),l11l1l_l1_ (u"ࠪࠫ䊃"),164,l11l1l_l1_ (u"ࠫࠬ䊄"),l11l1l_l1_ (u"ࠬ࠭䊅"),l11l1l_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䊆"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊇"),l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䊈"),l11l1l_l1_ (u"ࠩࠪ䊉"),165,l11l1l_l1_ (u"ࠪࠫ䊊"),l11l1l_l1_ (u"ࠫࠬ䊋"),l11l1l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ䊌"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䊍"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䊎"),l11l1l_l1_ (u"ࠨࠩ䊏"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊐"),l11l1l_l1_ (u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ䊑"),l11l1l_l1_ (u"ࠫࠬ䊒"),163,l11l1l_l1_ (u"ࠬ࠭䊓"),l11l1l_l1_ (u"࠭ࠧ䊔"),l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䊕"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"),l11l1l_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ䊗"),l11l1l_l1_ (u"ࠪࠫ䊘"),163,l11l1l_l1_ (u"ࠫࠬ䊙"),l11l1l_l1_ (u"ࠬ࠭䊚"),l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䊛"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊜"),l11l1l_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䊝"),l11l1l_l1_ (u"ࠩࠪ䊞"),162,l11l1l_l1_ (u"ࠪࠫ䊟"),l11l1l_l1_ (u"ࠫࠬ䊠"),l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䊡"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊢"),l11l1l_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ䊣"),l11l1l_l1_ (u"ࠨࠩ䊤"),162,l11l1l_l1_ (u"ࠩࠪ䊥"),l11l1l_l1_ (u"ࠪࠫ䊦"),l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䊧"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊨"),l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩ䊩"),l11l1l_l1_ (u"ࠧࠨ䊪"),164,l11l1l_l1_ (u"ࠨࠩ䊫"),l11l1l_l1_ (u"ࠩࠪ䊬"),l11l1l_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䊭"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊮"),l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䊯"),l11l1l_l1_ (u"࠭ࠧ䊰"),165,l11l1l_l1_ (u"ࠧࠨ䊱"),l11l1l_l1_ (u"ࠨࠩ䊲"),l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䊳"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䊴"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䊵"),l11l1l_l1_ (u"ࠬ࠭䊶"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊷"),l11l1l_l1_ (u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ䊸"),l11l1l_l1_ (u"ࠨࠩ䊹"),163,l11l1l_l1_ (u"ࠩࠪ䊺"),l11l1l_l1_ (u"ࠪࠫ䊻"),l11l1l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䊼"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊽"),l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ䊾"),l11l1l_l1_ (u"ࠧࠨ䊿"),163,l11l1l_l1_ (u"ࠨࠩ䋀"),l11l1l_l1_ (u"ࠩࠪ䋁"),l11l1l_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䋂"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋃"),l11l1l_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䋄"),l11l1l_l1_ (u"࠭ࠧ䋅"),162,l11l1l_l1_ (u"ࠧࠨ䋆"),l11l1l_l1_ (u"ࠨࠩ䋇"),l11l1l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋈"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋉"),l11l1l_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ䋊"),l11l1l_l1_ (u"ࠬ࠭䋋"),162,l11l1l_l1_ (u"࠭ࠧ䋌"),l11l1l_l1_ (u"ࠧࠨ䋍"),l11l1l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䋎"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋏"),l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧ䋐"),l11l1l_l1_ (u"ࠫࠬ䋑"),164,l11l1l_l1_ (u"ࠬ࠭䋒"),l11l1l_l1_ (u"࠭ࠧ䋓"),l11l1l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋔"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䋕"),l11l1l_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䋖"),l11l1l_l1_ (u"ࠪࠫ䋗"),165,l11l1l_l1_ (u"ࠫࠬ䋘"),l11l1l_l1_ (u"ࠬ࠭䋙"),l11l1l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䋚"))
	return
def l111lll1l11_l1_(options):
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䋛"),l11l1l_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫ䋜"),l11l1l_l1_ (u"ࠩࠪ䋝"),161,l11l1l_l1_ (u"ࠪࠫ䋞"),l11l1l_l1_ (u"ࠫࠬ䋟"),l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䋠"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䋡"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䋢"),l11l1l_l1_ (u"ࠨࠩ䋣"),9999)
	l111l1l1l1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋤"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䋥")+l11l1l_l1_ (u"ࠫ็์่ศฬࠣ฽ึฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ䋦"),l11l1l_l1_ (u"ࠬ࠭䋧"),147)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋨"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣ࡝࡚࡚ࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䋩")+l11l1l_l1_ (u"ࠨไ้์ฬะࠠฤฮ้ฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ䋪"),l11l1l_l1_ (u"ࠩࠪ䋫"),148)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋬"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡊࡈࡏࠤࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䋭")+l11l1l_l1_ (u"่ࠬๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ䋮"),l11l1l_l1_ (u"࠭ࠧ䋯"),28)
	#addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䋰"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡒࡘࡆࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䋱")+l11l1l_l1_ (u"ࠩๅ๊ฬฯࠠศๆ่฽ฬืแࠡ็้ࠤ๊๎โฺ้่ࠫ䋲"),l11l1l_l1_ (u"ࠪࠫ䋳"),41)
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䋴"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡࡍ࡚ࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䋵")+l11l1l_l1_ (u"࠭โ็ษฬࠤฬ๊ใ้อิࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ䋶"),l11l1l_l1_ (u"ࠧࠨ䋷"),135)
	import l1l11lll1ll_l1_
	l1l11lll1ll_l1_.ITEMS(l11l1l_l1_ (u"ࠨ࠲ࠪ䋸"),False)
	l1l11lll1ll_l1_.ITEMS(l11l1l_l1_ (u"ࠩ࠴ࠫ䋹"),False)
	l1l11lll1ll_l1_.ITEMS(l11l1l_l1_ (u"ࠪ࠶ࠬ䋺"),False)
	#l1l11lll1ll_l1_.ITEMS(l11l1l_l1_ (u"ࠫ࠸࠭䋻"),False)
	if l11l1l_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䋼") in options:
		menuItemsLIST[:] = l111l11llll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l111ll11lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l111ll11lll_l1_)
	menuItemsLIST[:] = l111l1l1l1l_l1_+menuItemsLIST
	return
def l111lll11l1_l1_(options):
	options = options.replace(l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䋽"),l11l1l_l1_ (u"ࠧࠨ䋾")).replace(l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䋿"),l11l1l_l1_ (u"ࠩࠪ䌀"))
	headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䌁") : l11l1l_l1_ (u"ࠫࠬ䌂") }
	url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫ䌃")
	payload = { l11l1l_l1_ (u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨ䌄") : l11l1l_l1_ (u"ࠧ࠶࠲ࠪ䌅") }
	data = l1ll11lll_l1_(payload)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䌆"),l11l1l_l1_ (u"ࠩࠪ䌇"),l11l1l_l1_ (u"ࠪࠫ䌈"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1111lll1l1_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䌉"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭䌊"),l11l1l_l1_ (u"࠭ࠧ䌋"),l11l1l_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩ䌌"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ䌍"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ䌎"),block,re.DOTALL)
	l1111l1lll1_l1_,l1111llll11_l1_ = list(zip(*items))
	l111ll111ll_l1_ = []
	l111lll111l_l1_ = [l11l1l_l1_ (u"ࠪࠤࠬ䌏"),l11l1l_l1_ (u"ࠫࠧ࠭䌐"),l11l1l_l1_ (u"ࠬࡦࠧ䌑"),l11l1l_l1_ (u"࠭ࠬࠨ䌒"),l11l1l_l1_ (u"ࠧ࠯ࠩ䌓"),l11l1l_l1_ (u"ࠨ࠼ࠪ䌔"),l11l1l_l1_ (u"ࠩ࠾ࠫ䌕"),l11l1l_l1_ (u"ࠥࠫࠧ䌖"),l11l1l_l1_ (u"ࠫ࠲࠭䌗")]
	l111l111lll_l1_ = l1111llll11_l1_+l1111l1lll1_l1_
	for word in l111l111lll_l1_:
		if word in l1111llll11_l1_: l111l1lll11_l1_ = 2
		if word in l1111l1lll1_l1_: l111l1lll11_l1_ = 4
		l111ll1lll1_l1_ = [i in word for i in l111lll111l_l1_]
		if any(l111ll1lll1_l1_):
			index = l111ll1lll1_l1_.index(True)
			l111l1111l1_l1_ = l111lll111l_l1_[index]
			l111ll1l11l_l1_ = l11l1l_l1_ (u"ࠬ࠭䌘")
			if word.count(l111l1111l1_l1_)>1: l111ll1l1l1_l1_,l111ll1l111_l1_,l111ll1l11l_l1_ = word.split(l111l1111l1_l1_,2)
			else: l111ll1l1l1_l1_,l111ll1l111_l1_ = word.split(l111l1111l1_l1_,1)
			if len(l111ll1l1l1_l1_)>l111l1lll11_l1_: l111ll111ll_l1_.append(l111ll1l1l1_l1_.lower())
			if len(l111ll1l111_l1_)>l111l1lll11_l1_: l111ll111ll_l1_.append(l111ll1l111_l1_.lower())
			if len(l111ll1l11l_l1_)>l111l1lll11_l1_: l111ll111ll_l1_.append(l111ll1l11l_l1_.lower())
		elif len(word)>l111l1lll11_l1_: l111ll111ll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l111ll111ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l111ll111ll_l1_)),l111ll111ll_l1_)
	l11l1l_l1_ (u"ࠨࠢࠣࠌࠌࡰ࡮ࡹࡴࠡ࠿ࠣ࡟้ࠬไๆษอࠤ฾ฺ่ศศํอࠥ฿ัษ์ฬࠫ࠱࠭ใๅ็สฮࠥ฿ิ้ษษ๎ฮࠦล็ๅ็๎ื๐ษࠨ࡟ࠍࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢๆ่๊ฯࠠๅๆหัะูࠦ็้ส࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠷࠯ࠊࠊ࡮࡬ࡷࡹ࠷ࠠ࠾ࠢ࡞ࡡࠏࠏࡣࡰࡷࡱࡸࡸࠦ࠽ࠡ࡮ࡨࡲ࠭ࡲࡩࡴࡶ࠵࠭ࠏࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨࡤࡱࡸࡲࡹࡹࠪ࠶ࠫ࠽ࠤࡷࡧ࡮ࡥࡱࡰ࠲ࡸ࡮ࡵࡧࡨ࡯ࡩ࠭ࡲࡩࡴࡶ࠵࠭ࠏࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࡭ࡧࡱ࡫ࡹ࡮ࠩ࠻ࠢ࡯࡭ࡸࡺ࠱࠯ࡣࡳࡴࡪࡴࡤࠩࠩๆ่๊ฯฺࠠึ๋หห๐ษࠡำๅ้ࠥ࠭ࠫࡴࡶࡵࠬ࡮࠯ࠩࠋࠋࡺ࡬࡮ࡲࡥࠡࡖࡵࡹࡪࡀࠊࠊࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆ็฾ฮࡀࠧ࠭ࠢ࡯࡭ࡸࡺࠩࠋࠋࠌࠧ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠎࠩࡥ࡭࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠽࠾࠲࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥࡧࡲࡣࡎࡌࡗ࡙ࠐࠉࠊࠥࡨࡰࡸ࡫࠺ࠡ࡮࡬ࡷࡹ࠸ࠠ࠾ࠢࡨࡲ࡬ࡒࡉࡔࡖࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢๆ่๊ฯࠠๅๆหัะูࠦ็้ส࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠶࠯ࠊࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࠣࡀࠤ࠲࠷࠺ࠡࡤࡵࡩࡦࡱࠊࠊࠋࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࡸ࡫ࡡࡳࡥ࡫ࠤࡂࠦ࡬ࡪࡵࡷ࠶ࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠦࠧࠨ䌙")
	if l11l1l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䌚") in options:
		l111l1l1l11_l1_ = l111l111ll1_l1_
	elif l11l1l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䌛") in options:
		l111l1l1l11_l1_ = [l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ䌜")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠪࠫ䌝"),True): return
	elif l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䌞") in options:
		l111l1l1l11_l1_ = [l11l1l_l1_ (u"ࠬࡓ࠳ࡖࠩ䌟")]
		import l1l111ll1l1_l1_
		if not l1l111ll1l1_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"࠭ࠧ䌠"),True): return
	count,l1111l1llll_l1_ = 0,0
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䌡"),l11l1l_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣ࠾ࠥࡡࠠࠡ࡟ࠪ䌢"),l11l1l_l1_ (u"ࠩࠪ䌣"),164,l11l1l_l1_ (u"ࠪࠫ䌤"),l11l1l_l1_ (u"ࠫࠬ䌥"),l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌦")+options)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䌧"),l11l1l_l1_ (u"ࠧฦ฻สำฮࠦวๅสะฯࠥอไฺึ๋หห๐ࠧ䌨"),l11l1l_l1_ (u"ࠨࠩ䌩"),164,l11l1l_l1_ (u"ࠩࠪ䌪"),l11l1l_l1_ (u"ࠪࠫ䌫"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䌬")+options)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䌭"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䌮"),l11l1l_l1_ (u"ࠧࠨ䌯"),9999)
	l1111l1ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l111lll1111_l1_ = []
	for word in l111ll111ll_l1_:
		l111ll1l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀ࡝ࠥ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭䌰"),word,re.DOTALL)
		if l111ll1l111_l1_: word = word.split(l111ll1l111_l1_[0],1)[0]
		l111ll111l1_l1_ = word.replace(l11l1l_l1_ (u"ࠩ๔ࠫ䌱"),l11l1l_l1_ (u"ࠪࠫ䌲")).replace(l11l1l_l1_ (u"ࠫ๓࠭䌳"),l11l1l_l1_ (u"ࠬ࠭䌴")).replace(l11l1l_l1_ (u"๋࠭ࠨ䌵"),l11l1l_l1_ (u"ࠧࠨ䌶")).replace(l11l1l_l1_ (u"ࠨ๑ࠪ䌷"),l11l1l_l1_ (u"ࠩࠪ䌸")).replace(l11l1l_l1_ (u"ࠪ๐ࠬ䌹"),l11l1l_l1_ (u"ࠫࠬ䌺"))
		l111ll111l1_l1_ = l111ll111l1_l1_.replace(l11l1l_l1_ (u"ࠬ๖ࠧ䌻"),l11l1l_l1_ (u"࠭ࠧ䌼")).replace(l11l1l_l1_ (u"ࠧ๎ࠩ䌽"),l11l1l_l1_ (u"ࠨࠩ䌾")).replace(l11l1l_l1_ (u"ࠩ๕ࠫ䌿"),l11l1l_l1_ (u"ࠪࠫ䍀")).replace(l11l1l_l1_ (u"ࠫฑ࠭䍁"),l11l1l_l1_ (u"ࠬ࠭䍂")).replace(l11l1l_l1_ (u"࠭เࠨ䍃"),l11l1l_l1_ (u"ࠧࠨ䍄"))
		if l111ll111l1_l1_: l111lll1111_l1_.append(l111ll111l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l111lll1111_l1_)),l111lll1111_l1_)
	l111l1lllll_l1_ = []
	for l11l1ll1l1_l1_ in range(0,20):
		search = random.sample(l111lll1111_l1_,1)[0]
		if search in l111l1lllll_l1_: continue
		l111l1lllll_l1_.append(search)
		l1ll11111l1_l1_ = random.sample(l111l1l1l11_l1_,1)[0]
		LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䍅"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬ䍆")+str(l1ll11111l1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭䍇")+search)
		#results = l111l11l1ll_l1_(l11l1l_l1_ (u"ࠫࠬ䍈"),l11l1l_l1_ (u"ࠬ࠭䍉"),l11l1l_l1_ (u"࠭ࠧ䍊"),l1ll11111l1_l1_,l11l1l_l1_ (u"ࠧࠨ䍋"),l11l1l_l1_ (u"ࠨࠩ䍌"),search+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䍍"),l11l1l_l1_ (u"ࠪࠫ䍎"),l11l1l_l1_ (u"ࠫࠬ䍏"))
		l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_ = l1l1lll1l1l_l1_(l1ll11111l1_l1_)
		l1ll111111l_l1_(search+l11l1l_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ䍐"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䍑"),l11l1l_l1_ (u"ࠧࠨ䍒"))
	l1111l1ll1l_l1_[0][1] = l11l1l_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䍓")+search+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊ศฮอࠣ฽๋ࠦ࠺ࠡ࡝ࠣࠫ䍔")
	menuItemsLIST[:] = l111l11llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l111ll11lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l111ll11lll_l1_)
	menuItemsLIST[:] = l1111l1ll1l_l1_+menuItemsLIST
	#import l1lll111lll_l1_
	#l1lll111lll_l1_.SEARCH(search)
	return
def l111ll1llll_l1_(l1ll11111l1_l1_):
	l1l1llll11l_l1_,l1ll111111l_l1_,l1ll11l1lll_l1_ = l1l1lll1l1l_l1_(l1ll11111l1_l1_)
	try:
		if l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ䍕") in l1ll11111l1_l1_: l1l1llll11l_l1_(l1ll11111l1_l1_)
		else: l1l1llll11l_l1_()
		l111l1llll1_l1_ = False
	except: l111l1llll1_l1_ = True
	if l111l1llll1_l1_: l1lllll1_l1_(l1ll11111l1_l1_,l11l1l_l1_ (u"ࠫๆฺไࠡส๊ิฬࠦวๅ็๋ๆ฾࠭䍖"),time=2000)
	else: l1lllll1_l1_(l1ll11111l1_l1_,l11l1l_l1_ (u"ࠬะๅࠡฮ็ฬࠥอไฤไึห๊࠭䍗"),time=2000)
	return l111l1llll1_l1_
def l1111ll1l11_l1_(l111l1ll1l1_l1_=True):
	if not l111l1ll1l1_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡤࡪࡥࡷࠫ䍘"),l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䍙"),l11l1l_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䍚"))
		if results:
			contentsDICT = results
			return
	l1ll11111l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䍛"),l11l1l_l1_ (u"ࠪࠫ䍜"),l11l1l_l1_ (u"ࠫࠬ䍝"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䍞"),l11l1l_l1_ (u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ䍟"))
	if l1ll11111l_l1_!=1: return
	l1111ll1lll_l1_ = menuItemsLIST[:]
	l111l1l11l1_l1_,l111l1l1111_l1_ = 0,l11l1l_l1_ (u"ࠧࠨ䍠")
	for l1ll11111l1_l1_ in l111ll1ll1l_l1_:
		l111l1llll1_l1_ = l111ll1llll_l1_(l1ll11111l1_l1_)
		if l111l1llll1_l1_:
			l111l1l11l1_l1_ += 1
			l111l1l1111_l1_ += l11l1l_l1_ (u"ࠨࠢࠪ䍡")+l1ll11111l1_l1_
			if l111l1l11l1_l1_>=l111l1ll11l_l1_: break
	menuItemsLIST[:] = l1111ll1lll_l1_
	if l111l1l11l1_l1_>=l111l1ll11l_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䍢"),l11l1l_l1_ (u"ࠪࠫ䍣"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䍤"),l11l1l_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไสࠢไ๎ࠥ࠭䍥")+str(l111l1l11l1_l1_)+l11l1l_l1_ (u"࠭ࠠๆ๊สๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้ࠠีหฬ์อࠠใัࠣ๎่๎ๆࠡ฻า้ࠥ๎ฬ้ัࠣษ๋ะั็์อࠤๆ๐ࠠอ้สึ่่่ࠦ์࠽ࠫ䍦")+l111l1l1111_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䍧"),l11l1l_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䍨"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䍩"),l11l1l_l1_ (u"ࠪࠫ䍪"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䍫"),l11l1l_l1_ (u"ࠬะๅࠡฮ็ฬࠥาๅ๋฻ࠣห้ษโิษ่ࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่อืๆศ็ฯࠫ䍬"))
	return
def l111l11l11l_l1_(l1l11l1l11l_l1_,options):
	if l11l1l_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䍭") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䍮"),l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䍯"),l11l1l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䍰")+l1l11l1l11l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11l1l_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ䍱")
	import IPTV
	if l11l1l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䍲") in options and l11l1l_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䍳") not in options:
		try: IPTV.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䍴"),l11l1l_l1_ (u"ࠧࠨ䍵"),l11l1l_l1_ (u"ࠨࠩ䍶"),options+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍷"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䍸"),l11l1l_l1_ (u"ࠫࠬ䍹"),l11l1l_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䍺"),message)
		try: IPTV.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䍻"),l11l1l_l1_ (u"ࠧࠨ䍼"),l11l1l_l1_ (u"ࠨࠩ䍽"),options+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍾"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䍿"),l11l1l_l1_ (u"ࠫࠬ䎀"),l11l1l_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䎁"),message)
		try: IPTV.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䎂"),l11l1l_l1_ (u"ࠧࠨ䎃"),l11l1l_l1_ (u"ࠨࠩ䎄"),options+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䎅"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䎆"),l11l1l_l1_ (u"ࠫࠬ䎇"),l11l1l_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䎈"),message)
	if l11l1l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䎉") in options and l11l1l_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䎊") not in options:
		try: IPTV.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䎋"),l11l1l_l1_ (u"ࠩࠪ䎌"),l11l1l_l1_ (u"ࠪࠫ䎍"),options+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䎎"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䎏"),l11l1l_l1_ (u"࠭ࠧ䎐"),l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䎑"),message)
		try: IPTV.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䎒"),l11l1l_l1_ (u"ࠩࠪ䎓"),l11l1l_l1_ (u"ࠪࠫ䎔"),options+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䎕"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䎖"),l11l1l_l1_ (u"࠭ࠧ䎗"),l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䎘"),message)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䎙"),l11l1l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䎚")+l1l11l1l11l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l111l1l1lll_l1_(l1l11l1l11l_l1_,options):
	if l11l1l_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䎛") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䎜"),l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䎝"),l11l1l_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䎞")+l1l11l1l11l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11l1l_l1_ (u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ䎟")
	import l1l111ll1l1_l1_
	if l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䎠") in options and l11l1l_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䎡") not in options:
		try: l1l111ll1l1_l1_.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䎢"),l11l1l_l1_ (u"ࠫࠬ䎣"),l11l1l_l1_ (u"ࠬ࠭䎤"),options+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䎥"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䎦"),l11l1l_l1_ (u"ࠨࠩ䎧"),l11l1l_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䎨"),message)
		try: l1l111ll1l1_l1_.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䎩"),l11l1l_l1_ (u"ࠫࠬ䎪"),l11l1l_l1_ (u"ࠬ࠭䎫"),options+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䎬"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䎭"),l11l1l_l1_ (u"ࠨࠩ䎮"),l11l1l_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䎯"),message)
		try: l1l111ll1l1_l1_.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䎰"),l11l1l_l1_ (u"ࠫࠬ䎱"),l11l1l_l1_ (u"ࠬ࠭䎲"),options+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䎳"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䎴"),l11l1l_l1_ (u"ࠨࠩ䎵"),l11l1l_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䎶"),message)
	if l11l1l_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䎷") in options and l11l1l_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䎸") not in options:
		try: l1l111ll1l1_l1_.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䎹"),l11l1l_l1_ (u"࠭ࠧ䎺"),l11l1l_l1_ (u"ࠧࠨ䎻"),options+l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䎼"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䎽"),l11l1l_l1_ (u"ࠪࠫ䎾"),l11l1l_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䎿"),message)
		try: l1l111ll1l1_l1_.GROUPS(l1l11l1l11l_l1_,l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䏀"),l11l1l_l1_ (u"࠭ࠧ䏁"),l11l1l_l1_ (u"ࠧࠨ䏂"),options+l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䏃"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䏄"),l11l1l_l1_ (u"ࠪࠫ䏅"),l11l1l_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䏆"),message)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䏇"),l11l1l_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䏈")+l1l11l1l11l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l111ll11l11_l1_(l1l11l1l11l_l1_,options,l111l11111l_l1_):
	if l11l1l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䏉") in options:
		if l11l1l_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䏊") in options and l111l11111l_l1_==l11l1l_l1_ (u"ࠩࠪ䏋"): l1111ll1l11_l1_(True)
		elif l111l11111l_l1_: l1111ll1l11_l1_(False)
		#if contentsDICT=={}: return
	l111l1ll1ll_l1_ = options.replace(l11l1l_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䏌"),l11l1l_l1_ (u"ࠫࠬ䏍")).replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䏎"),l11l1l_l1_ (u"࠭ࠧ䏏")).replace(l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䏐"),l11l1l_l1_ (u"ࠨࠩ䏑"))
	if not l111l11111l_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䏒"),l11l1l_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䏓"),l11l1l_l1_ (u"ࠫࠬ䏔"),165,l11l1l_l1_ (u"ࠬ࠭䏕"),l11l1l_l1_ (u"࠭ࠧ䏖"),l11l1l_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䏗")+l111l1ll1ll_l1_,l11l1l_l1_ (u"ࠨࠩ䏘"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏙"):l1l11l1l11l_l1_})
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䏚"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䏛"),l11l1l_l1_ (u"ࠬ࠭䏜"),9999)
	if l11l1l_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䏝") in options:
		l1ll11l1ll_l1_ = [l11l1l_l1_ (u"ࠧฤใ็ห๊࠭䏞"),l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ䏟"),l11l1l_l1_ (u"่ࠩืึำ๊ศฬࠪ䏠"),l11l1l_l1_ (u"ࠪฬึอๅอࠩ䏡"),l11l1l_l1_ (u"ࠫศ฽แศๆࠣ์่ืส้่ࠪ䏢"),l11l1l_l1_ (u"ࠬืๅืษ้ࠫ䏣"),l11l1l_l1_ (u"࠭รฮัฮ࠱ศิัࠨ䏤"),l11l1l_l1_ (u"ࠧิๆสื้࠭䏥"),l11l1l_l1_ (u"ࠨ็๋ื๏่้ࠨ䏦"),l11l1l_l1_ (u"ࠩฦุ์ื࠭ฤๅฮีࠬ䏧"),l11l1l_l1_ (u"ࠪห้ศๆࠨ䏨"),l11l1l_l1_ (u"ࠫ฻ำใࠨ䏩"),l11l1l_l1_ (u"ࠬื๊ศุฬࠫ䏪"),l11l1l_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䏫"),l11l1l_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䏬"),l11l1l_l1_ (u"ࠨสฮࠤา๐ࠧ䏭"),l11l1l_l1_ (u"ࠩา๎๋๐ษࠨ䏮"),l11l1l_l1_ (u"ࠪื๋๎วหࠩ䏯"),l11l1l_l1_ (u"ࠫศิั๊ࠩ䏰")]
		l1111lll111_l1_ = [l11l1l_l1_ (u"ࠬอแๅษ่ࠫ䏱"),l11l1l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ䏲"),l11l1l_l1_ (u"ࠧโ์็้ࠬ䏳"),l11l1l_l1_ (u"ࠨใ็้ࠬ䏴")]
		l111ll11ll1_l1_ = [l11l1l_l1_ (u"่ࠩืู้ไࠨ䏵"),l11l1l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䏶")]
		l111lll11ll_l1_ = [l11l1l_l1_ (u"ู๊ࠫวาฯࠪ䏷"),l11l1l_l1_ (u"๋ࠬำาฯํหฯ࠭䏸")]
		l111l1111ll_l1_ = [l11l1l_l1_ (u"࠭ศาษ่ะࠬ䏹"),l11l1l_l1_ (u"ࠧࡴࡪࡲࡻࠬ䏺"),l11l1l_l1_ (u"ࠨฬ็ๅื๐่็ࠩ䏻"),l11l1l_l1_ (u"ࠩอ่๏็า๋๊้ࠫ䏼")]
		l111ll1111l_l1_ = [l11l1l_l1_ (u"ࠪห๋๋๊ࠨ䏽"),l11l1l_l1_ (u"่ࠫืส้่ࠪ䏾"),l11l1l_l1_ (u"้ࠬวาฬ๋๊ࠬ䏿"),l11l1l_l1_ (u"࠭࡫ࡪࡦࡶࠫ䐀"),l11l1l_l1_ (u"ุࠧใ็ࠫ䐁"),l11l1l_l1_ (u"ࠨษฺๅฬ๊ࠧ䐂")]
		l1111l11_l1_ = [l11l1l_l1_ (u"ࠩิ้฻อๆࠨ䐃")]
		l1llll11l_l1_ = [l11l1l_l1_ (u"ࠪหาีหࠨ䐄"),l11l1l_l1_ (u"ࠫฬิัࠨ䐅"),l11l1l_l1_ (u"๋่ࠬฯำࠪ䐆"),l11l1l_l1_ (u"࠭ฬะ์าࠫ䐇"),l11l1l_l1_ (u"ࠧๆุสๅࠬ䐈"),l11l1l_l1_ (u"ࠨฯา๎ะ࠭䐉")]
		l111l11l1l1_l1_ = [l11l1l_l1_ (u"ࠩึ่ฬูไࠨ䐊"),l11l1l_l1_ (u"ࠪืู้ไ่ࠩ䐋")]
		l1111ll1111_l1_ = [l11l1l_l1_ (u"ࠫฬเว็์ࠪ䐌"),l11l1l_l1_ (u"๋่ࠬิ์ๅํࠬ䐍"),l11l1l_l1_ (u"࠭ใๅ์หࠫ䐎"),l11l1l_l1_ (u"ࠧฮใ็ࠫ䐏"),l11l1l_l1_ (u"ࠨ࡯ࡸࡷ࡮ࡩࠧ䐐")]
		l1llllll11_l1_ = [l11l1l_l1_ (u"ࠩส็ะืࠧ䐑"),l11l1l_l1_ (u"ࠪหูํัࠨ䐒"),l11l1l_l1_ (u"๊๋๊ࠫำ้ࠪ䐓"),l11l1l_l1_ (u"ࠬอูๅ๋ࠪ䐔"),l11l1l_l1_ (u"࠭ๅฯฬสี์࠭䐕"),l11l1l_l1_ (u"ࠧๆะอหึอสࠨ䐖"),l11l1l_l1_ (u"ࠨษๅ์๎࠭䐗")]
		l1111ll1l1l_l1_ = [l11l1l_l1_ (u"ࠩส่ฬ์ࠧ䐘"),l11l1l_l1_ (u"ࠪัฬ๊๊ࠨ䐙"),l11l1l_l1_ (u"๊ࠫัศหࠩ䐚"),l11l1l_l1_ (u"ࠬืววฮࠪ䐛")]
		l1111ll11ll_l1_ = [l11l1l_l1_ (u"࠭ึฮๅࠪ䐜"),l11l1l_l1_ (u"ࠧไ๊่๎ิ๐ࠧ䐝")]
		l1111lll11l_l1_ = [l11l1l_l1_ (u"ࠨำํห฻ํࠧ䐞"),l11l1l_l1_ (u"ࠩๆ์ึํࠧ䐟"),l11l1l_l1_ (u"ฺ้ࠪอัฺ้ࠪ䐠"),l11l1l_l1_ (u"ูࠫ๎สࠨ䐡"),l11l1l_l1_ (u"ࠬื๊ศุฬࠫ䐢")]
		l111l1lll1l_l1_ = [l11l1l_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䐣"),l11l1l_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ䐤"),l11l1l_l1_ (u"ࠨ่ํฮๆ๊๊ไีࠪ䐥")]
		l111l111l11_l1_ = [l11l1l_l1_ (u"่้ࠩะ๊๊็ࠩ䐦"),l11l1l_l1_ (u"ࠪหูิวึࠩ䐧"),l11l1l_l1_ (u"๋ࠫา่ๆࠩ䐨")]
		l1l1ll11l_l1_ = [l11l1l_l1_ (u"ࠬฮหࠡฯํࠫ䐩"),l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ䐪"),l11l1l_l1_ (u"ࠧใ่ส๋ࠬ䐫"),l11l1l_l1_ (u"ࠨไ้์ฬะࠧ䐬")]
		l111l1ll111_l1_ = [l11l1l_l1_ (u"ࠩา๎๋࠭䐭"),l11l1l_l1_ (u"ࠪหิ฿๊่ࠩ䐮"),l11l1l_l1_ (u"ࠫื๐วาษอࠫ䐯"),l11l1l_l1_ (u"๊ࠬืๆ์สฮࠬ䐰"),l11l1l_l1_ (u"࠭ฯฺษฤࠫ䐱"),l11l1l_l1_ (u"ࠧใำส๊ࠬ䐲"),l11l1l_l1_ (u"ࠨไุหหีࠧ䐳"),l11l1l_l1_ (u"ࠩิฯฬวࠧ䐴"),l11l1l_l1_ (u"้ࠪึาู๋้ࠪ䐵"),l11l1l_l1_ (u"ࠫฬึว็ࠩ䐶"),l11l1l_l1_ (u"ࠬอำๅษ่ࠫ䐷"),l11l1l_l1_ (u"࠭ส้ษื๎า࠭䐸"),l11l1l_l1_ (u"ࠧฯูหࠫ䐹"),l11l1l_l1_ (u"ࠨฯ๋ึํ๐ࠧ䐺"),l11l1l_l1_ (u"ࠩ฼ฮออสࠨ䐻"),l11l1l_l1_ (u"้ࠪํอไ๋ัࠪ䐼"),l11l1l_l1_ (u"๋ࠫ๎วฺ์ࠪ䐽"),l11l1l_l1_ (u"ࠬ฿โศศาࠫ䐾"),l11l1l_l1_ (u"࠭ว็ษื๎ิ࠭䐿")]
		l111ll11l1l_l1_ = [l11l1l_l1_ (u"ࠧ࠲࠻ࠪ䑀"),l11l1l_l1_ (u"ࠨ࠴࠳ࠫ䑁"),l11l1l_l1_ (u"ࠩ࠵࠵ࠬ䑂"),l11l1l_l1_ (u"ࠪ࠶࠷࠭䑃"),l11l1l_l1_ (u"ࠫ࠷࠹ࠧ䑄"),l11l1l_l1_ (u"ࠬ࠸࠴ࠨ䑅"),l11l1l_l1_ (u"࠭࠲࠶ࠩ䑆"),l11l1l_l1_ (u"ࠧ࠳࠸ࠪ䑇")]
		if not l111l11111l_l1_:
			l111l11111l_l1_ = 0
			for l111l1l11ll_l1_ in l1ll11l1ll_l1_:
				l111l11111l_l1_ += 1
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑈"),l1111l_l1_+l111l1l11ll_l1_,l11l1l_l1_ (u"ࠩࠪ䑉"),165,l11l1l_l1_ (u"ࠪࠫ䑊"),str(l111l11111l_l1_),l111l1ll1ll_l1_,l11l1l_l1_ (u"ࠫࠬ䑋"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑌"):l1l11l1l11l_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1ll1l11_l1_ = name.lower()
				category = []
				if any(value in l1ll1ll1l11_l1_ for value in l1111lll111_l1_): category.append(1)
				if any(value in l1ll1ll1l11_l1_ for value in l111ll11ll1_l1_): category.append(2)
				if any(value in l1ll1ll1l11_l1_ for value in l111lll11ll_l1_): category.append(3)
				if any(value in l1ll1ll1l11_l1_ for value in l111l1111ll_l1_): category.append(4)
				if any(value in l1ll1ll1l11_l1_ for value in l111ll1111l_l1_): category.append(5)
				if any(value in l1ll1ll1l11_l1_ for value in l1111l11_l1_): category.append(6)
				if any(value in l1ll1ll1l11_l1_ for value in l1llll11l_l1_) and l1ll1ll1l11_l1_ not in [l11l1l_l1_ (u"࠭วฯำ์ࠫ䑍")]: category.append(7)
				if any(value in l1ll1ll1l11_l1_ for value in l111l11l1l1_l1_): category.append(8)
				if any(value in l1ll1ll1l11_l1_ for value in l1111ll1111_l1_): category.append(9)
				if any(value in l1ll1ll1l11_l1_ for value in l1llllll11_l1_): category.append(10)
				if any(value in l1ll1ll1l11_l1_ for value in l1111ll1l1l_l1_): category.append(11)
				if any(value in l1ll1ll1l11_l1_ for value in l1111ll11ll_l1_): category.append(12)
				if any(value in l1ll1ll1l11_l1_ for value in l1111lll11l_l1_): category.append(13)
				if any(value in l1ll1ll1l11_l1_ for value in l111l1lll1l_l1_): category.append(14)
				if any(value in l1ll1ll1l11_l1_ for value in l111l111l11_l1_): category.append(15)
				if any(value in l1ll1ll1l11_l1_ for value in l1l1ll11l_l1_): category.append(16)
				if any(value in l1ll1ll1l11_l1_ for value in l111l1ll111_l1_): category.append(17)
				if any(value in l1ll1ll1l11_l1_ for value in l111ll11l1l_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l111l11111l_l1_:
						addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑎"),l1111l_l1_+name,name,166,l11l1l_l1_ (u"ࠨࠩ䑏"),l11l1l_l1_ (u"ࠩࠪ䑐"),l111l1ll1ll_l1_+l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䑑"))
	elif l11l1l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䑒") in options:
		import IPTV
		#if l11l1l_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䑓") in options:
		l1111ll11l1_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1l11l1l11l_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True): return
			l111l11l11l_l1_(l1l11l1l11l_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"࠭ࠧ䑔"),True): return
			for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
				l111l11l11l_l1_(str(l1l11l1l11l_l1_),options)
			#else: l1111ll11l1_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1111ll11l1_l1_+menuItemsLIST[:]
	elif l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䑕") in options:
		import l1l111ll1l1_l1_
		#if l11l1l_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䑖") in options:
		l1111ll11l1_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1l11l1l11l_l1_:
			if not l1l111ll1l1_l1_.CHECK_TABLES_EXIST(l1l11l1l11l_l1_,True): return
			l111l1l1lll_l1_(l1l11l1l11l_l1_,options)
		else:
			if not l1l111ll1l1_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠩࠪ䑗"),True): return
			for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
				l111l1l1lll_l1_(str(l1l11l1l11l_l1_),options)
			#else: l1111ll11l1_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1111ll11l1_l1_+menuItemsLIST[:]
	return
def l111ll1l1ll_l1_(l111l111111_l1_,options):
	l111l111111_l1_ = l111l111111_l1_.replace(l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䑘"),l11l1l_l1_ (u"ࠫࠬ䑙"))
	options = options.replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䑚"),l11l1l_l1_ (u"࠭ࠧ䑛")).replace(l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䑜"),l11l1l_l1_ (u"ࠨࠩ䑝"))
	l1111ll1l11_l1_(False)
	if contentsDICT=={}: return
	if l11l1l_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䑞") in options:
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑟"),l11l1l_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䑠")+l111l111111_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ䑡"),l111l111111_l1_,166,l11l1l_l1_ (u"࠭ࠧ䑢"),l11l1l_l1_ (u"ࠧࠨ䑣"),l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䑤")+options)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑥"),l11l1l_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䑦"),l111l111111_l1_,166,l11l1l_l1_ (u"ࠫࠬ䑧"),l11l1l_l1_ (u"ࠬ࠭䑨"),l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䑩")+options)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䑪"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䑫"),l11l1l_l1_ (u"ࠩࠪ䑬"),9999)
	for l1l1l111_l1_ in sorted(list(contentsDICT[l111l111111_l1_].keys())):
		type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ = contentsDICT[l111l111111_l1_][l1l1l111_l1_]
		if l11l1l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䑭") in options or len(contentsDICT[l111l111111_l1_])==1:
			l111l11l1ll_l1_(type,l11l1l_l1_ (u"ࠫࠬ䑮"),url,l111ll11111_l1_,l11l1l_l1_ (u"ࠬ࠭䑯"),l11llll_l1_,text,l11l1l_l1_ (u"࠭ࠧ䑰"),l11l1l_l1_ (u"ࠧࠨ䑱"))
			menuItemsLIST[:] = l111l11llll_l1_(menuItemsLIST)
			l1111ll11l1_l1_,l1llll11111_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1llll11111_l1_)
			if l11l1l_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䑲") in options: menuItemsLIST[:] = l1111ll11l1_l1_+l1llll11111_l1_[:l111ll11lll_l1_]
			else: menuItemsLIST[:] = l1111ll11l1_l1_+l1llll11111_l1_
		elif l11l1l_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䑳") in options: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑴"),l1l1l111_l1_,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_)
	return
def l111l11ll11_l1_(options,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䑵"),l11l1l_l1_ (u"ࠬ࠭䑶"),str(mode),options)
	options = options.replace(l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䑷"),l11l1l_l1_ (u"ࠧࠨ䑸")).replace(l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䑹"),l11l1l_l1_ (u"ࠩࠪ䑺"))
	name,l111l11l111_l1_ = l11l1l_l1_ (u"ࠪࠫ䑻"),[]
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑼"),l11l1l_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䑽")+name+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ䑾"),l11l1l_l1_ (u"ࠧࠨ䑿"),mode,l11l1l_l1_ (u"ࠨࠩ䒀"),l11l1l_l1_ (u"ࠩࠪ䒁"),l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䒂")+options)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䒃"),l11l1l_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไึ้ࠥ฿ิ้ษษ๎ࠬ䒄"),l11l1l_l1_ (u"࠭ࠧ䒅"),mode,l11l1l_l1_ (u"ࠧࠨ䒆"),l11l1l_l1_ (u"ࠨࠩ䒇"),l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䒈")+options)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䒉"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䒊"),l11l1l_l1_ (u"ࠬ࠭䒋"),9999)
	l1111ll11l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11l1l_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䒌") in options:
		l1111ll1l11_l1_(False)
		if contentsDICT=={}: return
		l111l11lll1_l1_ = list(contentsDICT.keys())
		l111l111111_l1_ = random.sample(l111l11lll1_l1_,1)[0]
		l111ll111ll_l1_ = list(contentsDICT[l111l111111_l1_].keys())
		l1l1l111_l1_ = random.sample(l111ll111ll_l1_,1)[0]
		type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ = contentsDICT[l111l111111_l1_][l1l1l111_l1_]
		LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䒍"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫ䒎")+l1l1l111_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䒏")+name+l11l1l_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䒐")+url+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䒑")+str(l111ll11111_l1_))
	elif l11l1l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䒒") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"࠭ࠧ䒓"),True): return
		for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
			l111l11l11l_l1_(str(l1l11l1l11l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䒔"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䒕")+name+l11l1l_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䒖")+url+l11l1l_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䒗")+str(l111ll11111_l1_))
	elif l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䒘") in options:
		import l1l111ll1l1_l1_
		if not l1l111ll1l1_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠬ࠭䒙"),True): return
		for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
			l111l1l1lll_l1_(str(l1l11l1l11l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䒚"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䒛")+name+l11l1l_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䒜")+url+l11l1l_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䒝")+str(l111ll11111_l1_))
	l111l111l1l_l1_ = name
	l111l1l111l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䒞"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䒟")+name+l11l1l_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䒠")+url+l11l1l_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䒡")+str(l111ll11111_l1_))
		menuItemsLIST[:] = []
		if l111ll11111_l1_==234 and l11l1l_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䒢") in text: l111ll11111_l1_ = 233
		if l111ll11111_l1_==714 and l11l1l_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䒣") in text: l111ll11111_l1_ = 713
		if l111ll11111_l1_==144: l111ll11111_l1_ = 291
		html = l111l11l1ll_l1_(type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_)
		#if l11l1l_l1_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥࠧ䒤") in html: l111l11ll11_l1_(options,mode)
		if l11l1l_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䒥") in options and l111ll11111_l1_==167: del menuItemsLIST[:3]
		if l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䒦") in options and l111ll11111_l1_==168: del menuItemsLIST[:3]
		l111l11l111_l1_[:] = l111l11llll_l1_(menuItemsLIST)
		if l111l1l111l_l1_ and l1111llllll_l1_(l11l1l_l1_ (u"ࡺ࠭อๅไฬࠫ䒧")) in str(l111l11l111_l1_) or l1111llllll_l1_(l11l1l_l1_ (u"ࡻࠧฮๆๅ๋ࠬ䒨")) in str(l111l11l111_l1_):
			name = l111l111l1l_l1_
			l111l11l111_l1_[:] = l111l1l111l_l1_
			break
		l111l111l1l_l1_ = name
		l111l1l111l_l1_ = l111l11l111_l1_[:]
		if str(l111l11l111_l1_).count(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䒩"))>0: break
		if str(l111l11l111_l1_).count(l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䒪"))>0: break
		if l111ll11111_l1_==233: break	# iptv l111l111_l1_ names l111l1l1ll1_l1_ of l11ll_l1_ name
		if l111ll11111_l1_==713: break	# l1111llll1l_l1_ l111l111_l1_ names l111l1l1ll1_l1_ of l11ll_l1_ name
		if l111ll11111_l1_==291: break	# l1ll1l1ll_l1_ l111ll1ll11_l1_ names l111l1l1ll1_l1_ of l1ll1l1ll_l1_ l111ll1ll11_l1_ contents
		if l111l11l111_l1_: type,name,url,l111ll11111_l1_,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ = random.sample(l111l11l111_l1_,1)[0]
	if not name: name = l11l1l_l1_ (u"ࠩ࠱࠲࠳࠴ࠧ䒫")
	elif name.count(l11l1l_l1_ (u"ࠪࡣࠬ䒬"))>1: name = name.split(l11l1l_l1_ (u"ࠫࡤ࠭䒭"),2)[2]
	name = name.replace(l11l1l_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨ䒮"),l11l1l_l1_ (u"࠭ࠧ䒯"))#.replace(l11l1l_l1_ (u"ࠧ࠭ࡏࡒ࡚ࡎࡋࡓ࠻ࠢࠪ䒰"),l11l1l_l1_ (u"ࠨࠩ䒱")).replace(l11l1l_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䒲"),l11l1l_l1_ (u"ࠪࠫ䒳")).replace(l11l1l_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ䒴"),l11l1l_l1_ (u"ࠬ࠭䒵"))
	name = name.replace(l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䒶"),l11l1l_l1_ (u"ࠧࠨ䒷"))
	l1111ll11l1_l1_[0][1] = l11l1l_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䒸")+name+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊โิ็ࠣ࠾ࠥࡡࠠࠨ䒹")
	for i in range(9): random.shuffle(l111l11l111_l1_)
	if l11l1l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䒺") in options: menuItemsLIST[:] = l1111ll11l1_l1_+l111l11l111_l1_[:l111ll11lll_l1_]
	else: menuItemsLIST[:] = l1111ll11l1_l1_+l111l11l111_l1_
	return
def l1111lllll1_l1_(l11l1l11l11_l1_,l11lll111ll_l1_):
	l11lll111ll_l1_ = l11lll111ll_l1_.replace(l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䒻"),l11l1l_l1_ (u"ࠬ࠭䒼")).replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䒽"),l11l1l_l1_ (u"ࠧࠨ䒾"))
	l111l11ll1l_l1_ = l11lll111ll_l1_
	if l11l1l_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䒿") in l11lll111ll_l1_:
		l111l11ll1l_l1_ = l11lll111ll_l1_.split(l11l1l_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䓀"))[0]
		type = l11l1l_l1_ (u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭䓁")
	elif l11l1l_l1_ (u"࡛ࠫࡕࡄࠨ䓂") in l11l1l11l11_l1_: type = l11l1l_l1_ (u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨ䓃")
	elif l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࠫ䓄") in l11l1l11l11_l1_: type = l11l1l_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ䓅")
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓆"),l11l1l_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䓇")+type+l111l11ll1l_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ䓈"),l11l1l11l11_l1_,167,l11l1l_l1_ (u"ࠫࠬ䓉"),l11l1l_l1_ (u"ࠬ࠭䓊"),l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓋")+l11lll111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓌"),l11l1l_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䓍"),l11l1l11l11_l1_,167,l11l1l_l1_ (u"ࠩࠪ䓎"),l11l1l_l1_ (u"ࠪࠫ䓏"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䓐")+l11lll111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓑"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓒"),l11l1l_l1_ (u"ࠧࠨ䓓"),9999)
	import IPTV
	for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
		if l11l1l_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䓔") in l11lll111ll_l1_: IPTV.GROUPS(str(l1l11l1l11l_l1_),l11l1l11l11_l1_,l11lll111ll_l1_,l11l1l_l1_ (u"ࠩࠪ䓕"),False)
		else: IPTV.ITEMS(str(l1l11l1l11l_l1_),l11l1l11l11_l1_,l11lll111ll_l1_,l11l1l_l1_ (u"ࠪࠫ䓖"),False)
	menuItemsLIST[:] = l111l11llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l111ll11lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l111ll11lll_l1_)
	return
def l1111ll111l_l1_(l11l1l11l11_l1_,l11lll111ll_l1_):
	l11lll111ll_l1_ = l11lll111ll_l1_.replace(l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䓗"),l11l1l_l1_ (u"ࠬ࠭䓘")).replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䓙"),l11l1l_l1_ (u"ࠧࠨ䓚"))
	l111l11ll1l_l1_ = l11lll111ll_l1_
	if l11l1l_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䓛") in l11lll111ll_l1_:
		l111l11ll1l_l1_ = l11lll111ll_l1_.split(l11l1l_l1_ (u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䓜"))[0]
		type = l11l1l_l1_ (u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭䓝")
	elif l11l1l_l1_ (u"࡛ࠫࡕࡄࠨ䓞") in l11l1l11l11_l1_: type = l11l1l_l1_ (u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨ䓟")
	elif l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࠫ䓠") in l11l1l11l11_l1_: type = l11l1l_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ䓡")
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓢"),l11l1l_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䓣")+type+l111l11ll1l_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ䓤"),l11l1l11l11_l1_,168,l11l1l_l1_ (u"ࠫࠬ䓥"),l11l1l_l1_ (u"ࠬ࠭䓦"),l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓧")+l11lll111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓨"),l11l1l_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䓩"),l11l1l11l11_l1_,168,l11l1l_l1_ (u"ࠩࠪ䓪"),l11l1l_l1_ (u"ࠪࠫ䓫"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䓬")+l11lll111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓭"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓮"),l11l1l_l1_ (u"ࠧࠨ䓯"),9999)
	import l1l111ll1l1_l1_
	for l1l11l1l11l_l1_ in range(FOLDERS_COUNT):
		if l11l1l_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䓰") in l11lll111ll_l1_: l1l111ll1l1_l1_.GROUPS(str(l1l11l1l11l_l1_),l11l1l11l11_l1_,l11lll111ll_l1_,l11l1l_l1_ (u"ࠩࠪ䓱"),False)
		else: l1l111ll1l1_l1_.ITEMS(str(l1l11l1l11l_l1_),l11l1l11l11_l1_,l11lll111ll_l1_,l11l1l_l1_ (u"ࠪࠫ䓲"),False)
	menuItemsLIST[:] = l111l11llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l111ll11lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l111ll11lll_l1_)
	return
def l111l11llll_l1_(menuItemsLIST):
	l111l11l111_l1_ = []
	for type,name,url,mode,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_ in menuItemsLIST:
		if l11l1l_l1_ (u"ฺࠫ็อสࠩ䓳") in name or l11l1l_l1_ (u"ࠬ฻แฮ้ࠪ䓴") in name or l11l1l_l1_ (u"࠭ࡰࡢࡩࡨࠫ䓵") in name.lower(): continue
		l111l11l111_l1_.append([type,name,url,mode,l111_l1_,l11llll_l1_,text,l1111lll1ll_l1_,l1ll1l1lll1_l1_])
	return l111l11l111_l1_
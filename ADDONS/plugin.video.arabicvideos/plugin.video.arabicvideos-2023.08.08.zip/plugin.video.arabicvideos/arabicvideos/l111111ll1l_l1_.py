# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ尙")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ尚")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
#headers = l11l1l_l1_ (u"ࠪࠫ尛")
#headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ尜"):l11l1l_l1_ (u"ࠬ࠭尝")}
l11l11lllll1_l1_ = 0
def MAIN(mode,url,text,type,l11llll_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l11l11lll1ll_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1lllll_l1_(url,l11llll_l1_,text)
	elif mode==145: results = l11l1ll11ll1_l1_(url,l11llll_l1_)
	elif mode==147: results = l11l1l1l11l1_l1_()
	elif mode==148: results = l11l1l1l1l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭尞"),l1111l_l1_+l11l1l_l1_ (u"ࠧใษษ้ฮ࠭尟"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡆࡰ࠵ࡈࡵ࠻ࡊࡍ࠾࡚࡯ࡗࡥࡊ࠵ࡘࡖ࠮࠹ࡊ࠷ࡇࡵࡱࡊࡻ࡝ࡅ࠹ࡻࡓࡂࠩ尠"),144)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ尡"),l1111l_l1_+l11l1l_l1_ (u"ุࠪำ฻ࠧ尢"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࡘࡈࡔ࡯ࡧࡨ࡬ࡧ࡮ࡧ࡬ࠨ尣"),144)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ尤"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅ้ไ฼ࠫ尥"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡶ࠻࠹ࡢࡉࡑࡷࡶ࠿ࡢࡣࡪࡺ࡚࡙ࡷ࠱ࡖࡶࡹ࡫ࡼ࠭尦"),144)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尧"),l1111l_l1_+l11l1l_l1_ (u"ࠩะืฬฮࠧ尨"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡅ࡚ࡨࡦࡕࡲࡧ࡮ࡧ࡬ࡄࡖ࡙ࠫ尩"),144)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ尪"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไฺษหࠫ尫"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ尬"),144)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ尭"),l1111l_l1_+l11l1l_l1_ (u"ࠨษไ่ฬ๋ࠧ尮"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ尯"),144)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ尰"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫิสศำสฮࠬ就"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ尲"),144)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭尳"),l1111l_l1_+l11l1l_l1_ (u"ࠧใืํีฮ࠭尴"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ尵"),144,l11l1l_l1_ (u"ࠩࠪ尶"),l11l1l_l1_ (u"ࠪࠫ尷"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ尸"))
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ尹"),l1111l_l1_+l11l1l_l1_ (u"࠭สึใะࠫ尺"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ尻"),144)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尼"),l1111l_l1_+l11l1l_l1_ (u"ࠩิส๏ู๊สࠩ尽"),l11l11_l1_+l11l1l_l1_ (u"ࠪࠫ尾"),144)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ尿"),l1111l_l1_+l11l1l_l1_ (u"ࠬืววฮࠪ局"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠿ࡣࡲࡀࠫ屁"),144)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ层"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ屃"),l11l1l_l1_ (u"ࠩࠪ屄"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ居"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ屆"),l11l1l_l1_ (u"ࠬ࠭屇"),149,l11l1l_l1_ (u"࠭ࠧ屈"),l11l1l_l1_ (u"ࠧࠨ屉"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ届"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屋"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้ืฦ๋ีํอࠬ屌"),l11l11_l1_+l11l1l_l1_ (u"ࠫࠬ屍"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屎"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅำสสัฯࠧ屏"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ屐"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屑"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ฯ฻แฮࠩ屒"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭屓"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屔"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไใืํีฮ࠭展"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ屖"),144,l11l1l_l1_ (u"ࠧࠨ屗"),l11l1l_l1_ (u"ࠨࠩ屘"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭屙"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屚"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫิสศำสฮࠥ๐่ห์๋ฬࠬ屛"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ屜"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屝"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆะอหึอสࠡษ็ฬึ์วๆฮࠪ属"),l11l1l_l1_ (u"ࠨࠩ屟"),290)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ屠"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ屡"),l11l1l_l1_ (u"ࠫࠬ屢"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屣"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ層"),l11l1l_l1_ (u"ࠧࠨ履"),147)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屦"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠใ่๋หฯࠦรอ่ห๎ฮ࠭屧"),l11l1l_l1_ (u"ࠪࠫ屨"),148)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屩"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ屪"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ屫"),144)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ屬"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ屭"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ屮"),144)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屯"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ屰"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭山"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屲"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯูࠦาสํอࠬ屳"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืู้ไࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭屴"),144)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屵"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ屶"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ屷"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屸"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ屹"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭屺"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屻"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ屼"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭ๆีอ๊วย࠭ส่ๆ฼วว์ฬ࠯ำ฽ศส࠭ส่ัู๋สࠨࡶࡴࡂࡉࡁࡊࡕࡄ࡬ࡆࡈࠧ屽"),144)
	return
def l11l11lll1ll_l1_(url,name,l111_l1_):
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屾"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡉࡈࡏࡎ࠽ࠤࠥ࠭屿")+name,url,144,l111_l1_)
	return
def l11l1l1l11l1_l1_():
	l1lllll_l1_(l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭岀"))
	return
def l11l1l1l1l11_l1_():
	l1lllll_l1_(l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ岁"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ岂"),l11l1l_l1_ (u"ࠩࠪ岃"),l11l1l_l1_ (u"ࠪࠫ岄"),url)
	#url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭岅")
	#items = re.findall(l11l1l_l1_ (u"ࠬࡼ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ岆"),url,re.DOTALL)
	#id = items[0]
	#l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ岇")+id
	#PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭岈"))
	#return
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠪࡸࡶࡱ࠯ࠊࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࠭࠮࠯࠰࠱ࠫࠡࠢࠪ࠯ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩࠪࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠮ࡵࡳ࡮ࠬࠎࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࠱ࠫࠬ࠭࠮࠯ࠥࠦࠧࠬࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠮ࠐࠉࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒࠬࡱ࡯࡮࡬ࡵ࡞࠴ࡢ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࡹࡿࡰࡦࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࠨࠢࠣ岉")
	url = url.split(l11l1l_l1_ (u"ࠩࠩࠫ岊"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],l1ll1_l1_,type,url)
	return
def l11l1l11l1l1_l1_(cc,url,index):
	level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = index.split(l11l1l_l1_ (u"ࠪ࠾࠿࠭岋"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ岌"),l11l1l_l1_ (u"ࠬ࠭岍"),index,l11l1l_l1_ (u"࠭ࡆࡊࡔࡖࡘࠬ岎")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ岏")+url)
	l11l11lll111_l1_,l11l11lll1l1_l1_ = [],[]
	# l1lllll1ll1l_l1_ l1lllll1l1ll_l1_    should be the first item in the l11l11lll111_l1_ list
	if l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ岐") in url: l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࠨ岑"))
	# l1lllll1ll1l_l1_ search l11l1l1l1lll_l1_      should be the first item in the l11l11lll111_l1_ list
	if l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ岒") in url: l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡉ࡯࡮࡯ࡤࡲࡩࡹࠧ࡞ࠤ岓"))
	# main l11llll_l1_
	if level==l11l1l_l1_ (u"ࠬ࠷ࠧ岔"): l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ岕"))
	# search results
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ岖"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞ࠤ岗"))
	# l11l1l1l1ll1_l1_ l11l1l1l111l_l1_ & main l11llll_l1_ l11l1l1l111l_l1_ l11l1l1l1lll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠭ࡥ࡯ࡶࡵ࡭ࡪࡹࠧ࡞ࠤ岘"))
	# l11l1l11l1ll_l1_ menu
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡧࡨࡡࠧࡪࡶࡨࡱࡸ࠭࡝࡜࠵ࡠ࡟ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ岙"))
	l11l1l1ll111_l1_,dd,l11l11ll11l1_l1_ = l11l11ll1ll1_l1_(cc,l11l1l_l1_ (u"ࠫࠬ岚"),l11l11lll111_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭岛"),str(dd))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ岜"),l11l1l_l1_ (u"ࠧࠨ岝"),l11l1l_l1_ (u"ࠨࠩ岞"),str(len(dd)))
	if level==l11l1l_l1_ (u"ࠩ࠴ࠫ岟") and l11l1l1ll111_l1_:
		if len(dd)>1 and l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ岠") not in url:
			for zz in range(len(dd)):
				l11l1l1111ll_l1_ = str(zz)
				l11l11lll111_l1_ = []
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡩࡪ࡛ࠣ岡")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ岢"))
				# l11l1l1l1ll1_l1_ l11l1l1l111l_l1_
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡤࡥ࡝ࠥ岣")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠢ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࠫࡢࠨ岤"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡦࡧ࡟ࠧ岥")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠤࡠࠦ岦"))
				succeeded,item,l111l11l_l1_ = l11l11ll1ll1_l1_(dd,l11l1l_l1_ (u"ࠪࠫ岧"),l11l11lll111_l1_)
				if succeeded: l11l11lll1l1_l1_.append([item,url,l11l1l_l1_ (u"ࠫ࠷ࡀ࠺ࠨ岨")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ岩")])
				#l11l11llll11_l1_ = l11l1ll1111l_l1_(item,url,l11l1l_l1_ (u"࠭࠲࠻࠼ࠪ岪")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ岫"))
				#if l11l11llll11_l1_: l1ll111l1l_l1_ += 1
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token = l11l1ll1l1l1_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岬"),l1111l_l1_+title,l1llll1_l1_,144,l11l1l_l1_ (u"ࠩࠪ岭"),l11l1l_l1_ (u"ࠪ࠶࠿ࡀࠧ岮")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠰࠻࠼࠳ࠫ岯"))
				#l1ll111l1l_l1_ += 1
			# main l11llll_l1_ l11l1l1l111l_l1_ l11l1l1l1lll_l1_
			l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠࠦ岰"))
			succeeded,item,l111l11l_l1_ = l11l11ll1ll1_l1_(cc,l11l1l_l1_ (u"࠭ࠧ岱"),l11l11lll111_l1_)
			#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ岲"),str(cc))
			if succeeded and l11l11lll1l1_l1_ and l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ岳") in list(item.keys()):
				l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ岴")
				l11l11lll1l1_l1_.append([item,l1llll1_l1_,l11l1l_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ岵")])
	return dd,l11l1l1ll111_l1_,l11l11lll1l1_l1_,l11l11ll11l1_l1_
def l11l11ll11ll_l1_(cc,dd,url,index):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ岶"),l11l1l_l1_ (u"ࠬ࠭岷"),index,l11l1l_l1_ (u"࠭ࡓࡆࡅࡒࡒࡉ࠭岸")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ岹")+url)
	level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = index.split(l11l1l_l1_ (u"ࠨ࠼࠽ࠫ岺"))
	l11l11lll111_l1_,l11l1l11ll11_l1_ = [],[]
	# search results
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ岻"))
	# main l11llll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ岼")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ岽"))
	# l111ll1ll11_l1_ l11l1l1l111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜࠳ࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ岾"))
	# l1lllll1ll1l_l1_ search & l1lllll1l1ll_l1_ & l11l1l1l1lll_l1_
	if l11l1l_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ岿") in url: l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ峀"))
	elif l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ峁") in url: l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峂"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ峃")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ峄"))
	# l111ll1ll11_l1_ l11ll11111_l1_ & l11l1l1l111l_l1_ filters
	if l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭峅") in url or (l11l1l_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ峆") in url and l11l1l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ峇") not in url):
		l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡦࡧ࡟ࠧ峈")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ峉"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ峊")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峋"))
	# l11l1l1l1ll1_l1_ search
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜ࠤ峌")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠨ࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峍"))
	# main l11llll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡥࡦ࡞ࠦ峎")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ峏"))
	# l1lllll1ll1l_l1_ l1lllll1l1ll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠࠨ峐")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠥࡡࠧ峑"))
	l11l1l1l1l1l_l1_,ee,l11l1l11l111_l1_ = l11l11ll1ll1_l1_(dd,l11l1l_l1_ (u"ࠫࠬ峒"),l11l11lll111_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭峓"),str(ee))
	#DIALOG_OK()
	if level==l11l1l_l1_ (u"࠭࠲ࠨ峔") and l11l1l1l1l1l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l11l11lll111_l1_ = []
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞ࠦ峕")+index2+l11l1l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ峖"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ峗")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ峘"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ峙")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ峚"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝ࠥ峛")+index2+l11l1l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ峜"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟ࠧ峝")+index2+l11l1l_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ峞"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡩࡪࡡࠢ峟")+index2+l11l1l_l1_ (u"ࠦࡢࠨ峠"))
				succeeded,item,l111l11l_l1_ = l11l11ll1ll1_l1_(ee,l11l1l_l1_ (u"ࠬ࠭峡"),l11l11lll111_l1_)
				if succeeded: l11l1l11ll11_l1_.append([item,url,l11l1l_l1_ (u"࠭࠳࠻࠼ࠪ峢")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ峣")+index2+l11l1l_l1_ (u"ࠨ࠼࠽࠴ࠬ峤")])
				#l11l11llll11_l1_ = l11l1ll1111l_l1_(item,url,l11l1l_l1_ (u"ࠩ࠶࠾࠿࠭峥")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠪ࠾࠿࠭峦")+index2+l11l1l_l1_ (u"ࠫ࠿ࡀ࠰ࠨ峧"))
				#if l11l11llll11_l1_: l1l11lllll_l1_ += 1
				#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭峨"),str(l111l11l_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ峩")+str(item))
				#l1l11lllll_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token = l11l1ll1l1l1_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峪"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,l11l1l_l1_ (u"ࠨ࠵࠽࠾ࠬ峫")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ峬")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠶ࠧ峭"))
			# search l11l1l1l1lll_l1_
			l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠳ࡠࠦ峮"))
			# search l11l1l1l1lll_l1_
			l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜࠳ࡠࠦ峯"))
			succeeded,item,l111l11l_l1_ = l11l11ll1ll1_l1_(dd,l11l1l_l1_ (u"࠭ࠧ峰"),l11l11lll111_l1_)
			if succeeded and l11l1l11ll11_l1_ and l11l1l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ峱") in list(item.keys()):
				l11l1l11ll11_l1_.append([item,url,l11l1l_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ峲")])
			#l11l11llll11_l1_ = l11l1ll1111l_l1_(item,url,l11l1l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭峳"))
			#if l11l11llll11_l1_: l1l11lllll_l1_ += 1
			#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ峴"),str(item))
			#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ峵"),l1llll1_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ島")+token)
	return ee,l11l1l1l1l1l_l1_,l11l1l11ll11_l1_,l11l1l11l111_l1_
def l11l11llll1l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ峷"),l11l1l_l1_ (u"ࠧࠨ峸"),index,l11l1l_l1_ (u"ࠨࡖࡋࡍࡗࡊࠧ峹")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ峺")+url)
	level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = index.split(l11l1l_l1_ (u"ࠪ࠾࠿࠭峻"))
	l11l11lll111_l1_,l11l1l111111_l1_ = [],[]
	# search results
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ峼")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ峽"))
	# l1lllll1ll1l_l1_ l1lllll1l1ll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝ࠥ峾")+index2+l11l1l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ峿"))
	# l11l1ll11111_l1_ menu l11l1l1l111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟ࠧ崀")+index2+l11l1l_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崁"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡩࡪࡡࠢ崂")+index2+l11l1l_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崃"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ崄")+index2+l11l1l_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崅"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞ࠦ崆")+index2+l11l1l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崇"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ崈")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ崉"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ崊")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崋"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崌"))
	# l11l1l1l1ll1_l1_ l11l1ll1l1ll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崍"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崎"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ崏")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崐"))
	# main l11llll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ崑")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崒"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦࠤ崓"))
	l11l1l1ll1l1_l1_,ff,l11l1ll1l111_l1_ = l11l11ll1ll1_l1_(ee,l11l1l_l1_ (u"ࠧࠨ崔"),l11l11lll111_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ崕"),str(ff))
	if level==l11l1l_l1_ (u"ࠩ࠶ࠫ崖") and l11l1l1ll1l1_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l11l1l1l1111_l1_ = str(zz)
				#DIALOG_OK()
				l11l11lll111_l1_ = []
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠢ崗")+l11l1l1l1111_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ崘"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠤ崙")+l11l1l1l1111_l1_+l11l1l_l1_ (u"ࠨ࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ崚"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠦ崛")+l11l1l1l1111_l1_+l11l1l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ崜"))
				l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠࠨ崝")+l11l1l1l1111_l1_+l11l1l_l1_ (u"ࠥࡡࠧ崞"))
				succeeded,item,l111l11l_l1_ = l11l11ll1ll1_l1_(ff,l11l1l_l1_ (u"ࠫࠬ崟"),l11l11lll111_l1_)
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token = l11l1ll1l1l1_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ崠"),l1111l_l1_+l1llll1_l1_,l1llll1_l1_,143,l1ll1l_l1_)
				if succeeded: l11l1l111111_l1_.append([item,url,l11l1l_l1_ (u"࠭࠴࠻࠼ࠪ崡")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ崢")+index2+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ崣")+l11l1l1l1111_l1_])
				#l11l11llll11_l1_ = l11l1ll1111l_l1_(item,url,l11l1l_l1_ (u"ࠩ࠷࠾࠿࠭崤")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠪ࠾࠿࠭崥")+index2+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ崦")+l11l1l1l1111_l1_)
				#if l11l11llll11_l1_: l1l1l11111_l1_ += 1
	return ff,l11l1l1ll1l1_l1_,l11l1l111111_l1_,l11l1ll1l111_l1_
def l11l11ll1ll1_l1_(l111lllll11_l1_,l11l111l11l_l1_,l11l1l1111l1_l1_):
	cc,l11l111l11l_l1_ = l111lllll11_l1_,l11l111l11l_l1_
	dd,l11l111l11l_l1_ = l111lllll11_l1_,l11l111l11l_l1_
	ee,l11l111l11l_l1_ = l111lllll11_l1_,l11l111l11l_l1_
	ff,l11l111l11l_l1_ = l111lllll11_l1_,l11l111l11l_l1_
	item,render = l111lllll11_l1_,l11l111l11l_l1_
	count = len(l11l1l1111l1_l1_)
	for l11l1ll1l1_l1_ in range(count):
		try:
			out = eval(l11l1l1111l1_l1_[l11l1ll1l1_l1_])
			#if isinstance(out,dict): out = l11l1l_l1_ (u"ࠬ࠭崧")
			return True,out,l11l1ll1l1_l1_+1
		except: pass
	return False,l11l1l_l1_ (u"࠭ࠧ崨"),0
def l1lllll_l1_(url,index=l11l1l_l1_ (u"ࠧࠨ崩"),data=l11l1l_l1_ (u"ࠨࠩ崪")):
	l11l11lll1l1_l1_,l11l1l11ll11_l1_,l11l1l111111_l1_ = [],[],[]
	if l11l1l_l1_ (u"ࠩ࠽࠾ࠬ崫") not in index: index = l11l1l_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ崬")
	level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = index.split(l11l1l_l1_ (u"ࠫ࠿ࡀࠧ崭"))
	if level==l11l1l_l1_ (u"ࠬ࠺ࠧ崮"): level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ崯"),l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ崰"),l11l1l_l1_ (u"ࠨࠩ崱"),index,url)
	data = data.replace(l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭崲"),l11l1l_l1_ (u"ࠪࠫ崳"))
	html,cc,l11ll1111_l1_ = l11l1l11ll1l_l1_(url,data)
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡩࠤࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨࠢ࡬ࡲࠥࡻࡲ࡭ࠢࡲࡶࠥ࠭࠯ࡶࡵࡨࡶ࠴࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠧࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣࡲࡴࡺࠠࡰࡹࡱࡩࡷࡀࠠࠋࠋࠌࡳࡼࡴࡥࡳࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡩࡧࠢࡱࡳࡹࠦ࡯ࡸࡰࡨࡶ࠿ࠦ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡶࡪࡦࡨࡳࡔࡽ࡮ࡦࡴࠥ࠲࠯ࡅࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡳࡼࡴࡥࡳ࠼ࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠰࡞ࠫࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ࠭ࡲࡻࡳ࡫ࡲࡏࡃࡐࡉ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠲࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡬ࡹࡺࡰࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࡱ࡯࡮࡬ࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡱࡺࡲࡪࡸࡎࡂࡏࡈ࠰ࡱ࡯࡮࡬࠮࠴࠸࠹࠯ࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࠢࠣࠤ崴")
	index = level+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ崵")+l11l1l1111ll_l1_+l11l1l_l1_ (u"࠭࠺࠻ࠩ崶")+index2+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ崷")+l11l1l1l1111_l1_
	if level in [l11l1l_l1_ (u"ࠨ࠳ࠪ崸"),l11l1l_l1_ (u"ࠩ࠵ࠫ崹"),l11l1l_l1_ (u"ࠪ࠷ࠬ崺")]:
		dd,l11l1l1ll111_l1_,l11l11lll1l1_l1_,l11l11ll11l1_l1_ = l11l1l11l1l1_l1_(cc,url,index)
		if not l11l1l1ll111_l1_: return
		l1ll111l1l_l1_ = len(l11l11lll1l1_l1_)
		if l1ll111l1l_l1_<2:
			if level==l11l1l_l1_ (u"ࠫ࠶࠭崻"): level = l11l1l_l1_ (u"ࠬ࠸ࠧ崼")
			l11l11lll1l1_l1_ = []
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ崽"),l11l1l_l1_ (u"ࠧࠨ崾"),index,l11l1l_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠳࡟ࡲࠬ崿")+l11l1l_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭嵀")+str(l11l11ll11l1_l1_)+l11l1l_l1_ (u"ࠪࡠࡳ࠭嵁")+l11l1l_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭嵂")+str(len(dd))+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ嵃")+l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ嵄")+str(l1ll111l1l_l1_)+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嵅")+url)
	index = level+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ嵆")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嵇")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠭嵈")+l11l1l1l1111_l1_
	if level in [l11l1l_l1_ (u"ࠫ࠷࠭嵉"),l11l1l_l1_ (u"ࠬ࠹ࠧ嵊")]:
		ee,l11l1l1l1l1l_l1_,l11l1l11ll11_l1_,l11l1l11l111_l1_ = l11l11ll11ll_l1_(cc,dd,url,index)
		if not l11l1l1l1l1l_l1_: return
		l1l11lllll_l1_ = len(l11l1l11ll11_l1_)
		if l1l11lllll_l1_<2:
			if level==l11l1l_l1_ (u"࠭࠲ࠨ嵋"): level = l11l1l_l1_ (u"ࠧ࠴ࠩ嵌")
			l11l1l11ll11_l1_ = []
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ嵍"),l11l1l_l1_ (u"ࠩࠪ嵎"),index,l11l1l_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠶ࡡࡴࠧ嵏")+l11l1l_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ嵐")+str(l11l1l11l111_l1_)+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ嵑")+l11l1l_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ嵒")+str(len(ee))+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嵓")+l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ嵔")+str(l1l11lllll_l1_)+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ嵕")+url)
	index = level+l11l1l_l1_ (u"ࠪ࠾࠿࠭嵖")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嵗")+index2+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嵘")+l11l1l1l1111_l1_
	if level in [l11l1l_l1_ (u"࠭࠳ࠨ嵙")]:
		ff,l11l1l1ll1l1_l1_,l11l1l111111_l1_,l11l1ll1l111_l1_ = l11l11llll1l_l1_(cc,ee,url,index)
		if not l11l1l1ll1l1_l1_: return
		l1l1l11111_l1_ = len(l11l1l111111_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ嵚"),l11l1l_l1_ (u"ࠨࠩ嵛"),index,l11l1l_l1_ (u"ࠩ࡯ࡩࡻ࡫࡬࠻ࠢ࠶ࡠࡳ࠭嵜")+l11l1l_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩ࠿ࠦࠧ嵝")+str(l11l1ll1l111_l1_)+l11l1l_l1_ (u"ࠫࡡࡴࠧ嵞")+l11l1l_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬࠿ࠦࠧ嵟")+str(len(ff))+l11l1l_l1_ (u"࠭࡜࡯ࠩ嵠")+l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡀࠠࠨ嵡")+str(l1l1l11111_l1_)+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ嵢")+url)
	for item,url,index in l11l11lll1l1_l1_+l11l1l11ll11_l1_+l11l1l111111_l1_:
		l11l11llll11_l1_ = l11l1ll1111l_l1_(item,url,index)
	return
def l11l1ll1111l_l1_(item,url=l11l1l_l1_ (u"ࠩࠪ嵣"),index=l11l1l_l1_ (u"ࠪࠫ嵤")):
	if l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嵥") in index: level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = index.split(l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嵦"))
	else: level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ嵧"),l11l1l_l1_ (u"ࠧ࠱ࠩ嵨"),l11l1l_l1_ (u"ࠨ࠲ࠪ嵩"),l11l1l_l1_ (u"ࠩ࠳ࠫ嵪")
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,l11l1ll11l11_l1_ = l11l1ll1l1l1_l1_(item)
	#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ嵫"),url)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ嵬"),l1llll1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭嵭"),l1llll1_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ嵮")+title)
	# needed for l11l1l1l1ll1_l1_ l11l1ll1l1ll_l1_ next l11llll_l1_
	# and needed for l11l1l1l1ll1_l1_ l11l1ll1l1ll_l1_ sub-menu
	#if (l11l1l_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠻࠰ࠨ嵯") in l1llll1_l1_ or l11l1l_l1_ (u"ࠨࡸ࡬ࡩࡼࡃ࠴࠺ࠩ嵰") in l1llll1_l1_) and (l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸࡅࠧ嵱") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࡅࠧ嵲") in l1llll1_l1_): l1llll1_l1_ = url
	l1l111l1111_l1_ = l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࡄ࠭嵳") in l1llll1_l1_ or l11l1l_l1_ (u"ࠬ࠵ࡳࡵࡴࡨࡥࡲࡹ࠿ࠨ嵴") in l1llll1_l1_ or l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࡂࠫ嵵") in l1llll1_l1_
	l11lll11111_l1_ = l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡂࠫ嵶") in l1llll1_l1_ or l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࡁࠪ嵷") in l1llll1_l1_
	if l1l111l1111_l1_ or l11lll11111_l1_: l1llll1_l1_ = url
	l1l111l1111_l1_ = l11l1l_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ嵸") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ嵹") not in l1llll1_l1_
	l11lll11111_l1_ = l11l1l_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ嵺") not in l1llll1_l1_  and l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ嵻") not in l1llll1_l1_
	if index[0:5]==l11l1l_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠭嵼") and l1l111l1111_l1_ and l11lll11111_l1_: l1llll1_l1_ = url
	if l11l1l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ嵽") in url or l11l1l_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ嵾") in l1llll1_l1_:
		level,l11l1l1111ll_l1_,index2,l11l1l1l1111_l1_ = l11l1l_l1_ (u"ࠩ࠴ࠫ嵿"),l11l1l_l1_ (u"ࠪ࠴ࠬ嶀"),l11l1l_l1_ (u"ࠫ࠵࠭嶁"),l11l1l_l1_ (u"ࠬ࠶ࠧ嶂")
		index = l11l1l_l1_ (u"࠭ࠧ嶃")
	l11ll1111_l1_ = l11l1l_l1_ (u"ࠧࠨ嶄")
	if l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ嶅") in l1llll1_l1_ or l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ嶆") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ嶇") in url:
		data = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭嶈"))
		if data.count(l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ嶉"))==4:
			l11l1l1ll11l_l1_,key,l11l1l1l11ll_l1_,l11l1l111l1l_l1_,token = data.split(l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ嶊"))
			l11ll1111_l1_ = l11l1l1ll11l_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ嶋")+key+l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ嶌")+l11l1l1l11ll_l1_+l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭嶍")+l11l1l111l1l_l1_+l11l1l_l1_ (u"ࠪ࠾࠿ࡀࠧ嶎")+l11l1ll11l11_l1_
			if l11l1l_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ嶏") in url and not l1llll1_l1_: l1llll1_l1_ = url
			else: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ嶐")+key
	if not title:
		global l11l11lllll1_l1_
		l11l11lllll1_l1_ += 1
		title = l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡࠩ嶑")+str(l11l11lllll1_l1_)
		index = l11l1l_l1_ (u"ࠧ࠴ࠩ嶒")+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ嶓")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嶔")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠭嶕")+l11l1l1l1111_l1_
	#if l11l1l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ嶖") in url: l1llll1_l1_ = url
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭嶗"),l11l1l_l1_ (u"࠭ࠧ嶘"),title,index+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嶙")+l1llll1_l1_)
	#if not l1llll1_l1_: l1llll1_l1_ = url
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ嶚"),l11l1l_l1_ (u"ࠩࠪ嶛"),str(succeeded),title+l11l1l_l1_ (u"ࠪࠤ࠿ࡀ࠺ࠡࠩ嶜")+l1llll1_l1_)
	#if l11l1l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ嶝") in url and index==l11l1l_l1_ (u"ࠬ࠶ࠧ嶞"):
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶟"),l1111l_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ嶠") in str(item): return False			# l11l1l1lllll_l1_ not items
	elif l11l1l_l1_ (u"ࠨ࠱ࡤࡦࡴࡻࡴࠨ嶡") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠩ࠲ࡧࡴࡳ࡭ࡶࡰ࡬ࡸࡾ࠭嶢") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶣") in list(item.keys()) or l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪ嶤") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嶥")+l11l1l1111ll_l1_+l11l1l_l1_ (u"࠭࠺࠻ࠩ嶦")+index2+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ嶧")+l11l1l1l1111_l1_
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嶨"),l1111l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠥ࠭嶩")+l11l1l_l1_ (u"ูࠪๆำษࠡลัี๎࠭嶪"),l1llll1_l1_,144,l1ll1l_l1_,index,l11ll1111_l1_)
	elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ嶫") in l1llll1_l1_:
		title = l11l1l_l1_ (u"ࠬࡀ࠺ࠡࠩ嶬")+title
		index = l11l1l_l1_ (u"࠭࠳ࠨ嶭")+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ嶮")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ嶯")+index2+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嶰")+l11l1l1l1111_l1_
		url = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ嶱"),l11l1l_l1_ (u"ࠫࠬ嶲"))
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶳"),l1111l_l1_+title,url,145,l11l1l_l1_ (u"࠭ࠧ嶴"),index,l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ嶵"))
	elif l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ嶶") in url and not l1llll1_l1_:
		index = l11l1l_l1_ (u"ࠩ࠶ࠫ嶷")+l11l1l_l1_ (u"ࠪ࠾࠿࠭嶸")+l11l1l1111ll_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嶹")+index2+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嶺")+l11l1l1l1111_l1_
		title = l11l1l_l1_ (u"࠭࠺࠻ࠢࠪ嶻")+title
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶼"),l1111l_l1_+title,url,144,l1ll1l_l1_,index,l11ll1111_l1_)
	#elif l11l1l_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ嶽") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࠪ嶾") in l1llll1_l1_ and url==l11l11_l1_:
		title = l11l1l_l1_ (u"ࠪ࠾࠿ࠦࠧ嶿")+title
		index = l11l1l_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ巀")
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巁"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index,l11ll1111_l1_)
	elif not l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭巂") in str(item):
		title = l11l1l_l1_ (u"ࠧ࠻࠼ࠣࠫ巃")+title
		index = l11l1l_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ巄")
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巅"),l1111l_l1_+title,url,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ巆") in str(item):
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ巇"),l1111l_l1_+title,l11l1l_l1_ (u"ࠬ࠭巈"),9999)
	#elif l11l1l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ巉") in l1llll1_l1_ and l11l1l_l1_ (u"ࠧࡣࡲࡀࠫ巊") not in l1llll1_l1_:
	#	title = l11l1l_l1_ (u"ࠨ࠼࠽ࠤࠬ巋")+title
	#	index = l11l1l_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭巌")
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ巍"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l1lllll1l11l_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ巎"),l1111l_l1_+l1lllll1l11l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_)
	elif l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ巏") in l1llll1_l1_:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巐"),l1111l_l1_+l11l1l_l1_ (u"ࠧࡍࡋࡖࡘࠬ巑")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ巒")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	#elif l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ巓") in l1llll1_l1_ and l11l1l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ巔") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠫࡹࡃ࠰ࠨ巕") not in l1llll1_l1_:
	#	l11l1l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࡀࠬ࠳࠰࠿ࠪࠦࠪ巖"),l1llll1_l1_,re.DOTALL)
	#	l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ巗")+l11l1l11llll_l1_[0]
	#	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巘"),l1111l_l1_+l11l1l_l1_ (u"ࠨࡎࡌࡗ࡙࠭巙")+count+l11l1l_l1_ (u"ࠩ࠽ࠤࠥ࠭巚")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ巛") in l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ巜"),1)[0]
		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ川"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11ll11_l1_)
	elif l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ州") in l1llll1_l1_:
		if l11l1l_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ巟") in l1llll1_l1_ and count:
			l11l1l11llll_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ巠"),1)[1]
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ巡")+l11l1l11llll_l1_
			index = l11l1l_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ巢")
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巣"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡒࡉࡔࡖࠪ巤")+count+l11l1l_l1_ (u"࠭࠺ࠡࠢࠪ工")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
		else:
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ左"),1)[0]
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ巧"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11ll11_l1_)
	elif l11l1l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ巨") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡨ࠵ࠧ巩") in l1llll1_l1_ or (l11l1l_l1_ (u"ࠫ࠴ࡆࠧ巪") in l1llll1_l1_ and l1llll1_l1_.count(l11l1l_l1_ (u"ࠬ࠵ࠧ巫"))==3):
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巬"),l1111l_l1_+l11l1l_l1_ (u"ࠧࡄࡊࡑࡐࠬ巭")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ差")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ巯") in l1llll1_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ巰"),l1111l_l1_+l11l1l_l1_ (u"࡚࡙ࠫࡅࡓࠩ己")+count+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ已")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1llll1_l1_: l1llll1_l1_ = url
		title = l11l1l_l1_ (u"࠭࠺࠻ࠢࠪ巳")+title
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巴"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index,l11ll1111_l1_)
	return True
def l11l1ll1l1l1_l1_(item):
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token = False,l11l1l_l1_ (u"ࠨࠩ巵"),l11l1l_l1_ (u"ࠩࠪ巶"),l11l1l_l1_ (u"ࠪࠫ巷"),l11l1l_l1_ (u"ࠫࠬ巸"),l11l1l_l1_ (u"ࠬ࠭巹"),l11l1l_l1_ (u"࠭ࠧ巺"),l11l1l_l1_ (u"ࠧࠨ巻"),l11l1l_l1_ (u"ࠨࠩ巼")
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ巽"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token
	for l11l1l1lll1l_l1_ in list(item.keys()):
		render = item[l11l1l1lll1l_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11l1l_l1_ (u"ࠪࠫ巾"),str(render))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ巿"),str(render))
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡌࡪࡵࡷࡌࡪࡧࡤࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ帀"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ币"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩࡲࡩ࡯ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ市"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ布"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帄"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ帅"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ帆"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帇"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ师"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ帉"))
	# required for l111ll1ll11_l1_ l11l1l11l11l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ帊"))
	# l11l1l1l1ll1_l1_ l11l1l1l111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡴࡨࡩࡱ࡝ࡡࡵࡥ࡫ࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡸ࡬ࡨࡪࡵࡉࡥࠩࡠࠦ帋"))
	succeeded,title,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ希"),l11l1l_l1_ (u"ࠫࠬ帍"),l11l1l_l1_ (u"ࠬ࠭帎"),str(l111l11l_l1_))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ帏"),str(l111l11l_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ帐")+str(title))
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ帑"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帒"))
	# l11l1l1l1lll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ帓"))
	# header feed
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡧࡰࡪࡗࡵࡰࠬࡣࠢ帔"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帕"))
	# required for l111ll1ll11_l1_ l11l1l11111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ帖"))
	# l11l1l1l1ll1_l1_ l11l1l1l111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ帗"))
	succeeded,l1llll1_l1_,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帘"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ帙"))
	# l11l1l1l1ll1_l1_ l11l1l1l111l_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帚"))
	succeeded,l1ll1l_l1_,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ帛"),str(l111l11l_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ帜")+l1ll1l_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ帝"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ帞"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ帟"))
	succeeded,count,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ帠"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ帡"))
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ帢"))
	# l11l1l1lll11_l1_ l11l1l1l1ll1_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡣࡰࡰࠪࡡࡠ࠭ࡩࡤࡱࡱࡘࡾࡶࡥࠨ࡟ࠥ帣"))
	# l11l1l1lll11_l1_ l11l1l1l1ll1_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡵࡻ࡯ࡩࠬࡣࠢ帤"))
	succeeded,l1l11ll11_l1_,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	#l11l11lll111_l1_ = []
	# l11l1l1l1lll_l1_
	#l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡲࡩࡤ࡭ࡗࡶࡦࡩ࡫ࡪࡰࡪࡔࡦࡸࡡ࡮ࡵࠪࡡࠧ帥"))
	# l1lllll1ll1l_l1_ l1lllll1l1ll_l1_
	#l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸࡷࡧࡣ࡬࡫ࡱ࡫ࡕࡧࡲࡢ࡯ࡶࠫࡢࠨ带"))
	#succeeded,l11l11llllll_l1_,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	l11l11lll111_l1_ = []
	# l1lllll1ll1l_l1_ l1lllll1l1ll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ帧"))
	# l11l1l1l1lll_l1_
	l11l11lll111_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡷࡳࡰ࡫࡮ࠨ࡟ࠥ帨"))
	succeeded,token,l111l11l_l1_ = l11l11ll1ll1_l1_(item,render,l11l11lll111_l1_)
	if l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࠩ帩") in l1l11ll11_l1_: l1l11ll11_l1_,l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠬ࠭帪"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ師")
	if l11l1l_l1_ (u"ࠧๆสสุึ࠭帬") in l1l11ll11_l1_: l1l11ll11_l1_,l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠨࠩ席"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ帮")
	if l11l1l_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ帯") in list(render.keys()):
		l11l1ll111l1_l1_ = str(render[l11l1l_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ帰")])
		if l11l1l_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ帱") in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ帲")
		if l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ帳") in l11l1ll111l1_l1_: l1lllll1l11l_l1_ = l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ帴")
		if l11l1l_l1_ (u"ࠩࡅࡹࡾ࠭帵") in l11l1ll111l1_l1_ or l11l1l_l1_ (u"ࠪࡖࡪࡴࡴࠨ帶") in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ帷")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡺ࠭ๅษษืีࠬ常")) in l11l1ll111l1_l1_: l1lllll1l11l_l1_ = l11l1l_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ帹")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡵࠨึิหฦ࠭帺")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ帻")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡷࠪหุะฦอษิࠫ帼")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ帽")
		if l1111llllll_l1_(l11l1l_l1_ (u"ࡹࠬหูๅษ้หฯ࠭帾")) in l11l1ll111l1_l1_: l11l1l11lll1_l1_ = l11l1l_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ帿")
	l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
	if l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ幀") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠧࡀࠩ幁"))[0]
	if  l1ll1l_l1_ and l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭幂") not in l1ll1l_l1_: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ幃")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l11lll1_l1_: title = l11l1l11lll1_l1_+title
	#title = unescapeHTML(title)
	l1l11ll11_l1_ = l1l11ll11_l1_.replace(l11l1l_l1_ (u"ࠪ࠰ࠬ幄"),l11l1l_l1_ (u"ࠫࠬ幅"))
	count = count.replace(l11l1l_l1_ (u"ࠬ࠲ࠧ幆"),l11l1l_l1_ (u"࠭ࠧ幇"))
	count = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࠮ࠫ幈"),count)
	if count: count = count[0]
	else: count = l11l1l_l1_ (u"ࠨࠩ幉")
	return True,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11ll11_l1_,l1lllll1l11l_l1_,l11l1l11lll1_l1_,token
def l11l1l11ll1l_l1_(url,data=l11l1l_l1_ (u"ࠩࠪ幊"),request=l11l1l_l1_ (u"ࠪࠫ幋")):
	if request==l11l1l_l1_ (u"ࠫࠬ幌"): request = l11l1l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ幍")
	#if l11l1l_l1_ (u"࠭࡟ࡠࠩ幎") in l11l1ll1l11l_l1_: l11l1ll1l11l_l1_ = l11l1l_l1_ (u"ࠧࠨ幏")
	#if l11l1l_l1_ (u"ࠨࡵࡶࡁࠬ幐") in url: url = url.split(l11l1l_l1_ (u"ࠩࡶࡷࡂ࠭幑"))[0]
	l111ll1l1l_l1_ = l11llll1l_l1_()
	#l111ll1l1l_l1_ = l11l1l_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠲࠼࠲࠵࠴࠰࠯࠲ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠣࡉࡩ࡭࠯࠲࠲࠼࠲࠵࠴࠱࠶࠳࠻࠲࠼࠶ࠧ幒")
	l1l1l1lll_l1_ = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ幓"):l111ll1l1l_l1_,l11l1l_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ幔"):l11l1l_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ幕")}
	#l1l1l1lll_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ幖"))
	if data.count(l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ幗"))==4: l11l1l1ll11l_l1_,key,l11l1l1l11ll_l1_,l11l1l111l1l_l1_,token = data.split(l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭幘"))
	else: l11l1l1ll11l_l1_,key,l11l1l1l11ll_l1_,l11l1l111l1l_l1_,token = l11l1l_l1_ (u"ࠪࠫ幙"),l11l1l_l1_ (u"ࠫࠬ幚"),l11l1l_l1_ (u"ࠬ࠭幛"),l11l1l_l1_ (u"࠭ࠧ幜"),l11l1l_l1_ (u"ࠧࠨ幝")
	l11ll1111_l1_ = {l11l1l_l1_ (u"ࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ幞"):{l11l1l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ幟"):{l11l1l_l1_ (u"ࠥ࡬ࡱࠨ幠"):l11l1l_l1_ (u"ࠦࡦࡸࠢ幡"),l11l1l_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ幢"):l11l1l_l1_ (u"ࠨࡗࡆࡄࠥ幣"),l11l1l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ幤"):l11l1l1l11ll_l1_}}}
	if url==l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ幥") or l11l1l_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ幦") in url:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡵࡩࡪࡲ࠯ࡳࡧࡨࡰࡤࡽࡡࡵࡥ࡫ࡣࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭幧")+l11l1l_l1_ (u"ࠫࡄࡱࡥࡺ࠿ࠪ幨")+key
		l11ll1111_l1_[l11l1l_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫ࡐࡢࡴࡤࡱࡸ࠭幩")] = l11l1l1ll11l_l1_
		l11ll1111_l1_ = str(l11ll1111_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ幪"),url,l11ll1111_l1_,l1l1l1lll_l1_,True,True,l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ幫"))
	elif l11l1l_l1_ (u"ࠨ࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭幬") in url:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ幭")+key
		l11ll1111_l1_ = str(l11ll1111_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ幮"),url,l11ll1111_l1_,l1l1l1lll_l1_,True,True,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ幯"))
	elif l11l1l_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ幰") in url and l11l1l1ll11l_l1_:
		l11ll1111_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ幱")] = token
		l11ll1111_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ干")][l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࠨ平")][l11l1l_l1_ (u"ࠩࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠧ年")] = l11l1l1ll11l_l1_
		l11ll1111_l1_ = str(l11ll1111_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ幵"),url,l11ll1111_l1_,l1l1l1lll_l1_,True,True,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ并"))
	elif l11l1l_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭幷") in url and l11l1l111l1l_l1_:
		l1l1l1lll_l1_.update({l11l1l_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯ࡑࡥࡲ࡫ࠧ幸"):l11l1l_l1_ (u"ࠧ࠲ࠩ幹"),l11l1l_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱࡛࡫ࡲࡴ࡫ࡲࡲࠬ幺"):l11l1l1l11ll_l1_})
		l1l1l1lll_l1_.update({l11l1l_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ幻"):l11l1l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅ࠾ࠩ幼")+l11l1l111l1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ幽"),url,l11l1l_l1_ (u"ࠬ࠭幾"),l1l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ广"),l11l1l_l1_ (u"ࠧࠨ庀"),l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠸ࡸ࡭࠭庁"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭庂"),url,l11l1l_l1_ (u"ࠪࠫ広"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠫࠬ庄"),l11l1l_l1_ (u"ࠬ࠭庅"),l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠷ࡶ࡫ࠫ庆"))
	html = response.content
	tmp = re.findall(l11l1l_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ庇"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡺࡪࡸࠢ࠯ࠬࡂࠦࡻࡧ࡬ࡶࡧࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ庈"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l11ll_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ庉"),html,re.DOTALL|re.I)
	if tmp: l11l1l1ll11l_l1_ = tmp[0]
	#tmp = re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ床"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11l1l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ庋"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠧࡀࡻࠣࡶࡲ࡯ࡪࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ庌"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ庍"),l11l1l_l1_ (u"ࠧࠨ庎"),l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ序"),str(len(tmp)))
	#if tmp: l11l1l1l1lll_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ庐") in list(cookies.keys()): l11l1l111l1l_l1_ = cookies[l11l1l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ庑")]
	l11ll111l_l1_ = l11l1l1ll11l_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ庒")+key+l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ库")+l11l1l1l11ll_l1_+l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ应")+l11l1l111l1l_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ底")+token
	if request==l11l1l_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ庖") and l11l1l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ店") in html:
		l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ庘"),html,re.DOTALL)
		if not l111ll111l_l1_: l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ庙"),html,re.DOTALL)
		l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠬࡹࡴࡳࠩ庚"),l111ll111l_l1_[0])
	elif request==l11l1l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ庛") and l11l1l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ府") in html:
		l111ll111l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ庝"),html,re.DOTALL)
		l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭庞"),l111ll111l_l1_[0])
	elif l11l1l_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭废") not in html: l11l11lll11l_l1_ = EVAL(l11l1l_l1_ (u"ࠫࡸࡺࡲࠨ庠"),html)
	else: l11l11lll11l_l1_ = l11l1l_l1_ (u"ࠬ࠭庡")
	if 0:
		cc = str(l11l11lll11l_l1_)
		if kodi_version>18.99: cc = cc.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ庢"))
		open(l11l1l_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡤࡢࡶࠪ庣"),l11l1l_l1_ (u"ࠨࡹࡥࠫ庤")).write(cc)
		#open(l11l1l_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭庥"),l11l1l_l1_ (u"ࠪࡻࠬ度")).write(html)
	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭座"),l11ll111l_l1_)
	return html,l11l11lll11l_l1_,l11ll111l_l1_
def l11l1ll11ll1_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ庨"),l11l1l_l1_ (u"࠭ࠫࠨ庩"))
	l111ll1_l1_ = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ庪")+search
	l1lllll_l1_(l111ll1_l1_,index)
	return
def SEARCH(search):
	#search = l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭庫")+l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࠧ庬")+l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭庭")+l11l1l_l1_ (u"ࠫࡤ࠭庮")+search
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭庯"),l11l1l_l1_ (u"࠭ࠧ庰"),l11l1l_l1_ (u"ࠧࠨ庱"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ庲"),l11l1l_l1_ (u"ࠩࠪ庳"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ庴"),l11l1l_l1_ (u"ࠫ࠰࠭庵"))
	l111ll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ庶")+search
	if not l1ll_l1_:
		if l11l1l_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ康") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ庸")
		elif l11l1l_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ庹") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ庺")
		elif l11l1l_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ庻") in options: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ庼")
		else: l11l1l111lll_l1_ = l11l1l_l1_ (u"ࠬ࠭庽")
		l111lll_l1_ = l111ll1_l1_+l11l1l111lll_l1_
	else:
		l11l1l111ll1_l1_,l11l11ll1l1l_l1_,l1lll11ll_l1_ = [],[],l11l1l_l1_ (u"࠭ࠧ庾")
		l11l11ll1lll_l1_ = [l11l1l_l1_ (u"ࠧษั๋๊ࠥะัห์หࠫ庿"),l11l1l_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ๊ี้ࠡษ็ู้ฯࠧ廀"),l11l1l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥะวา์ัࠤฬ๊สฮ็ํ่ࠬ廁"),l11l1l_l1_ (u"ࠪฮึะ๊ษࠢะือูࠦะัࠣห้๋ิศ้าหฯ࠭廂"),l11l1l_l1_ (u"ࠫฯืส๋สࠣัุฮࠠศๆอๆ๏๐ๅࠨ廃")]
		l11l1l1llll1_l1_ = [l11l1l_l1_ (u"ࠬ࠭廄"),l11l1l_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡇࠥ࠳࠷࠶ࡈࠬ廅"),l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡉࠦ࠴࠸࠷ࡉ࠭廆"),l11l1l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡎࠧ࠵࠹࠸ࡊࠧ廇"),l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡇࠨ࠶࠺࠹ࡄࠨ廈")]
		l11l1ll111ll_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ฮึะ๊ษࠩ廉"),l11l11ll1lll_l1_)
		if l11l1ll111ll_l1_ == -1: return
		l11l1l111l11_l1_ = l11l1l1llll1_l1_[l11l1ll111ll_l1_]
		html,c,data = l11l1l11ll1l_l1_(l111ll1_l1_+l11l1l111l11_l1_)
		if c:
			try:
				d = c[l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭廊")][l11l1l_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ廋")][l11l1l_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ廌")][l11l1l_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廍")][l11l1l_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ廎")][l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ廏")][l11l1l_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࡵࠪ廐")]
				for l11l11ll1l11_l1_ in range(len(d)):
					group = d[l11l11ll1l11_l1_][l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡊࡶࡴࡻࡰࡓࡧࡱࡨࡪࡸࡥࡳࠩ廑")][l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭廒")]
					for l11l1ll11lll_l1_ in range(len(group)):
						render = group[l11l1ll11lll_l1_][l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廓")]
						if l11l1l_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ廔") in list(render.keys()):
							l1llll1_l1_ = render[l11l1l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭廕")][l11l1l_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ廖")][l11l1l_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ廗")][l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ廘")]
							l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࡢࡵ࠱࠲࠵࠺ࠬ廙"),l11l1l_l1_ (u"࠭ࠦࠨ廚"))
							title = render[l11l1l_l1_ (u"ࠧࡵࡱࡲࡰࡹ࡯ࡰࠨ廛")]
							title = title.replace(l11l1l_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣࠫ廜"),l11l1l_l1_ (u"ࠩࠪ廝"))
							if l11l1l_l1_ (u"ࠪษือไสࠢส่ๆ๊สาࠩ廞") in title: continue
							if l11l1l_l1_ (u"ࠫ็อฦๆหࠣฮูเ๊ๅࠩ廟") in title:
								title = l11l1l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭廠")+title
								l1lll11ll_l1_ = title
								l1llll11ll_l1_ = l1llll1_l1_
							if l11l1l_l1_ (u"࠭สาฬํฬࠥำำษࠩ廡") in title: continue
							title = title.replace(l11l1l_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠤࠬ廢"),l11l1l_l1_ (u"ࠨࠩ廣"))
							if l11l1l_l1_ (u"ࠩࡕࡩࡲࡵࡶࡦࠩ廤") in title: continue
							if l11l1l_l1_ (u"ࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ廥") in title:
								title = l11l1l_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ廦")+title
								l1lll11ll_l1_ = title
								l1llll11ll_l1_ = l1llll1_l1_
							if l11l1l_l1_ (u"࡙ࠬ࡯ࡳࡶࠣࡦࡾ࠭廧") in title: continue
							l11l1l111ll1_l1_.append(escapeUNICODE(title))
							l11l11ll1l1l_l1_.append(l1llll1_l1_)
			except: pass
		if not l1lll11ll_l1_: l11l1l1ll1ll_l1_ = l11l1l_l1_ (u"࠭ࠧ廨")
		else:
			l11l1l111ll1_l1_ = [l11l1l_l1_ (u"ࠧษั๋๊ࠥ็ไหำࠪ廩"),l1lll11ll_l1_]+l11l1l111ll1_l1_
			l11l11ll1l1l_l1_ = [l11l1l_l1_ (u"ࠨࠩ廪"),l1llll11ll_l1_]+l11l11ll1l1l_l1_
			l11l1ll11l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆไ่ฯืࠧ廫"),l11l1l111ll1_l1_)
			if l11l1ll11l1l_l1_ == -1: return
			l11l1l1ll1ll_l1_ = l11l11ll1l1l_l1_[l11l1ll11l1l_l1_]
		if l11l1l1ll1ll_l1_: l111lll_l1_ = l11l11_l1_+l11l1l1ll1ll_l1_
		elif l11l1l111l11_l1_: l111lll_l1_ = l111ll1_l1_+l11l1l111l11_l1_
		else: l111lll_l1_ = l111ll1_l1_
		l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨ࡬ࡰࡹ࡫ࡲ࠮ࡦࡵࡳࡵࡪ࡯ࡸࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱ࠲ࡹࡥࡤࡶ࡬ࡳࡳ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡔࡨࡱࡴࡼࡥࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠪ࠰࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡰࡴࡷࠤࡧࡿࠧ࠭ࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ࠰ࡺࡩࡵ࡮ࡨࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩࠪࠌࠌࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠧࠨࠢ廬")
	#DIALOG_OK()
	l1lllll_l1_(l111lll_l1_)
	return
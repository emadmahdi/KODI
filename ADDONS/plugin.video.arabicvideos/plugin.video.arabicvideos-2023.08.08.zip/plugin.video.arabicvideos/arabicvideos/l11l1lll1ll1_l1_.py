# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ坺")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ坻")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
l11lll1lll_l1_ = l1l1ll1_l1_[l1ll1_l1_][1]
l1l1ll111ll_l1_ = l1l1ll1_l1_[l1ll1_l1_][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1lllll_l1_(url)
	elif mode==52: results = l1lll1ll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l11ll1111111_l1_()
	elif mode==56: results = l11l1llll1ll_l1_()
	elif mode==57: results = l11l1lllll11_l1_(url,1)
	elif mode==58: results = l11l1lllll11_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坼"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ坽"),l11l1l_l1_ (u"ࠬ࠭坾"),59,l11l1l_l1_ (u"࠭ࠧ坿"),l11l1l_l1_ (u"ࠧࠨ垀"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ垁"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ垂"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ垃"),l11l1l_l1_ (u"ࠫࠬ垄"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垅"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ垆")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ垇"),l11l1l_l1_ (u"ࠨࠩ垈"),56)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垉"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ垊")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊วโๆส้ࠬ型"),l11l1l_l1_ (u"ࠬ࠭垌"),55)
	return l11l1l_l1_ (u"࠭ࠧ垍")
def l11ll1111111_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垎"),l1111l_l1_+l11l1l_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ垏"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ垐"),51)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垑"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ垒"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ垓"),51)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垔"),l1111l_l1_+l11l1l_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ垕"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ垖"),51)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垗"),l1111l_l1_+l11l1l_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ垘"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ垙"),51)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ垚"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭垛"),l11l1l_l1_ (u"ࠧࠨ垜"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垝"),l1111l_l1_+l11l1l_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭垞"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ垟"),57)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垠"),l1111l_l1_+l11l1l_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ垡"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ垢"),57)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垣"),l1111l_l1_+l11l1l_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ垤"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ垥"),57)
	return
def l11l1llll1ll_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垦"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ垧"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ垨"),51)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垩"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ垪"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ垫"),51)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垬"),l1111l_l1_+l11l1l_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ垭"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ垮"),51)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垯"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ垰"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ垱"),51)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭垲"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ垳"),l11l1l_l1_ (u"ࠪࠫ垴"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垵"),l1111l_l1_+l11l1l_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ垶"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭垷"),57)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垸"),l1111l_l1_+l11l1l_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ垹"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ垺"),57)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垻"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ垼"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ垽"),57)
	return
def l1lllll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ垾"),l11l1l_l1_ (u"ࠧࠨ垿"),url,url)
	if l11l1l_l1_ (u"ࠨࡁࠪ埀") in url:
		parts = url.split(l11l1l_l1_ (u"ࠩࡂࠫ埁"))
		url = parts[0]
		filter = l11l1l_l1_ (u"ࠪࡃࠬ埂") + QUOTE(parts[1],l11l1l_l1_ (u"ࠫࡂࠬ࠺࠰ࠧࠪ埃"))
	else: filter = l11l1l_l1_ (u"ࠬ࠭埄")
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ埅"),l11l1l_l1_ (u"ࠧࠨ埆"),filter,l11l1l_l1_ (u"ࠨࠩ埇"))
	parts = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ埈"))
	sort,l11llll_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11l1l_l1_ (u"ࠪࡽࡴࡶࠧ埉"),l11l1l_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ埊"),l11l1l_l1_ (u"ࠬࡼࡩࡦࡹࡶࠫ埋")]:
		if type==l11l1l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ埌"): l11ll1ll1_l1_=l11l1l_l1_ (u"ࠧโ์็้ࠬ埍")
		elif type==l11l1l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ城"): l11ll1ll1_l1_=l11l1l_l1_ (u"่ࠩืู้ไࠨ埏")
		#url = l11l11_l1_ + l11l1l_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ埐") + QUOTE(l11ll1ll1_l1_) + l11l1l_l1_ (u"ࠫ࠴࠭埑") + l11llll_l1_ + l11l1l_l1_ (u"ࠬ࠵ࠧ埒") + sort + filter
		url = l11l11_l1_ + l11l1l_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ埓") + QUOTE(l11ll1ll1_l1_) + l11l1l_l1_ (u"ࠧ࠰ࠩ埔") + l11llll_l1_ + l11l1l_l1_ (u"ࠨ࠱ࠪ埕") + sort + filter
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ埖"),l11l1l_l1_ (u"ࠪࠫ埗"),l11l1l_l1_ (u"ࠫࠬ埘"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭埙"),l11l1l_l1_ (u"࠭ࠧ埚"),l11l1l_l1_ (u"ࠧࠨ埛"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ埜"))
		#items = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿ࠣࡰࡸࡱࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡴࡨࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埝"),html,re.DOTALL)
		items = re.findall(l11l1l_l1_ (u"ࠪࠦࡵ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡶࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡴࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡱࡴࡨࡷࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ埞"),html,re.DOTALL)
		l1l1l1ll111_l1_=0
		for id,title,l11l1lll1lll_l1_,l1ll1l_l1_ in items:
			l1l1l1ll111_l1_ += 1
			#l1ll1l_l1_ = l11lll1lll_l1_ + l11l1l_l1_ (u"ࠫ࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ域") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ埠")
			l1ll1l_l1_ = l1l1ll111ll_l1_ + l11l1l_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ埡") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ埢")
			l1llll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ埣") + id
			if type==l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ埤"): addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ埥"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
			if type==l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ埦"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埧"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ࠥ࠭埨")+title,l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ埩")+l11l1lll1lll_l1_+l11l1l_l1_ (u"ࠨ࠿ࠪ埪")+title+l11l1l_l1_ (u"ࠩࡀࠫ埫")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ埬"): l11ll1ll1_l1_=l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ埭")
		elif type==l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ埮"): l11ll1ll1_l1_=l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭埯")
		url = l11lll1lll_l1_ + l11l1l_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ埰") + sort + l11l1l_l1_ (u"ࠨ࠯ࠪ埱") + l11ll1ll1_l1_ + l11l1l_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ埲")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫ埳"),l11l1l_l1_ (u"ࠫࠬ埴"),l11l1l_l1_ (u"ࠬ࠭埵"),l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ埶"))
		items = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ執"),html,re.DOTALL)
		l1l1l1ll111_l1_=0
		for id,l11l1lll1lll_l1_,l1ll1l_l1_,title in items:
			l1l1l1ll111_l1_ += 1
			l1ll1l_l1_ = l11lll1lll_l1_ + l11l1l_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ埸") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ培")
			l1llll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭基") + id
			if type==l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ埻"): addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埼"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
			elif type==l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭埽"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ埾"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊ࠠࠨ埿")+title,l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡩࡵࡃࠧ堀")+l11l1lll1lll_l1_+l11l1l_l1_ (u"ࠪࡁࠬ堁")+title+l11l1l_l1_ (u"ࠫࡂ࠭堂")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ堃")
	if l1l1l1ll111_l1_==16:
		for l1l1ll11l11_l1_ in range(1,13) :
			if not l11llll_l1_==str(l1l1ll11l11_l1_):
				#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠭ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪ堄")+type+l11l1l_l1_ (u"ࠧ࠰ࠩ堅")+str(l1l1ll11l11_l1_)+l11l1l_l1_ (u"ࠨ࠱ࠪ堆")+sort + filter
				url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ堇")+type+l11l1l_l1_ (u"ࠪ࠳ࠬ堈")+str(l1l1ll11l11_l1_)+l11l1l_l1_ (u"ࠫ࠴࠭堉")+sort + filter
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堊"),l1111l_l1_+title+str(l1l1ll11l11_l1_),url,51)
	return
def l1lll1ll_l1_(url):
	parts = url.split(l11l1l_l1_ (u"࠭࠽ࠨ堋"))
	l11l1lll1lll_l1_ = int(parts[1])
	name = l1llll_l1_(parts[2])
	name = name.replace(l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ堌"),l11l1l_l1_ (u"ࠨࠩ堍"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l11l1l_l1_ (u"ࠩࡂࠫ堎"))[0]
	if l11l1lll1lll_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫ堏"),l11l1l_l1_ (u"ࠫࠬ堐"),l11l1l_l1_ (u"ࠬ࠭堑"),l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ堒"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨ堓"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ堔"),block,re.DOTALL)
		l11l1lll1lll_l1_ = int(items[-1])
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ堕"),l11l1l_l1_ (u"ࠪࠫ堖"),l11l1lll1lll_l1_,l11l1l_l1_ (u"ࠫࠬ堗"))
	#name = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕ࡫ࡷࡰࡪࠨ堘") )
	#l1ll1l_l1_ = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠢ堙") )
	for l1ll1l1_l1_ in range(l11l1lll1lll_l1_,0,-1):
		l1llll1_l1_ = url + l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ堚") + str(l1ll1l1_l1_)
		title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭堛")+name+l11l1l_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭堜")+str(l1ll1l1_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ堝"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠫࠬ堞"),l11l1l_l1_ (u"ࠬ࠭堟"),l11l1l_l1_ (u"࠭ࠧ堠"),l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ堡"))
	l11l1llll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堢"),html,re.DOTALL)
	if l11l1llll1l1_l1_:
		time = l11l1llll1l1_l1_[1].replace(l11l1l_l1_ (u"ࠩࡗࠫ堣"),l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠨ堤"))
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ堥"),l11l1l_l1_ (u"ࠬ࠭堦"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ堧"),l11l1l_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ堨")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ堩")+time)
		return
	#if l11l1l_l1_ (u"้ࠩ฽ฯึัࠡ฻็ํࠥ๎โ้฻ࠣา฼ษࠧ堪") in html:
	#	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ堫"),l11l1l_l1_ (u"ࠫࠬ堬"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ堭"),l11l1l_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ堮"))
	#	return
	l11l1lll1l1l_l1_,l11l1lllll1l_l1_ = [],[]
	l11l1lllllll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡷࡣࡵࠤࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ堯"),html,re.DOTALL)[0]
	l11l1llll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡶࠥࡨࡡࡤ࡭ࡸࡴࡤࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堰"),html,re.DOTALL)[0]
	# l1lll1ll1_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡰࡸࡀࠠࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭報"),html,re.DOTALL)
	for server,l1llll1_l1_ in l1l1_l1_:
		if l11l1l_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ堲") in server:
			server = l11l1l_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ堳")
			url = l11l1llll11l_l1_ + l1llll1_l1_
		else:
			server = l11l1l_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ場")
			url = l11l1lllllll_l1_ + l1llll1_l1_
		if l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ堵") in url:
			l11l1lll1l1l_l1_.append(url)
			l11l1lllll1l_l1_.append(l11l1l_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥࠦࠧ堶")+server)
		l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡ࠰࡞࠿ࡀࠫ࠲࠷ࠧ࠻ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠯ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡰ࠷ࡺ࠾ࠠࠡࠩ࠮ࡷࡪࡸࡶࡦࡴࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡱ࡫࡮ࠩࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭࠮ࡀࠊࠊࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡺࡸ࡬࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞࡭ࡢ࠯ࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࠪ࠭ࡠ࠶࡝ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࡭ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࡧ࡫࡯ࡩࡹࡿࡰࡦ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠠࠡࠩ࠯ࠫࠥࠦࠧࠪࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥ࡮ࡢ࡯ࡨ࠲ࡦࡶࡰࡦࡰࡧࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠱ࠧࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠯ࠬࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠧࠨࠢ堷")
	# l11111ll_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ堸"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11l1l_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ堹"),html,re.DOTALL)
	for server,l1llll1_l1_ in l1l1_l1_:
		filename = l1llll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭堺"))[-1]
		filename = filename.replace(l11l1l_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ堻"),l11l1l_l1_ (u"࠭ࠧ堼"))
		filename = filename.replace(l11l1l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ堽"),l11l1l_l1_ (u"ࠨࠩ堾"))
		filename = filename.replace(l11l1l_l1_ (u"ࠩ࠰ࠫ堿"),l11l1l_l1_ (u"ࠪࠫ塀"))
		if l11l1l_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ塁") in server:
			server = l11l1l_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ塂")
			url = l11l1llll11l_l1_ + l1llll1_l1_
		else:
			server = l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ塃")
			url = l11l1lllllll_l1_ + l1llll1_l1_
		l11l1lll1l1l_l1_.append(url)
		l11l1lllll1l_l1_.append(l11l1l_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭塄")+server+l11l1l_l1_ (u"ࠨࠢࠣࠫ塅")+filename)
	l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ塆"), l11l1lllll1l_l1_)
	if l1l_l1_ == -1 : return
	url = l11l1lll1l1l_l1_[l1l_l1_]
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ塇"))
	return
def l11l1lllll11_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ塈"),l11l1l_l1_ (u"ࠬ࠭塉"),url,url)
	if l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭塊") in url: l111ll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ๆี็ื้࠭塋")
	else: l111ll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ใํ่๊࠭塌")
	l111ll1_l1_ = QUOTE(l111ll1_l1_)
	html = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ塍"),l11l1l_l1_ (u"ࠪࠫ塎"),l11l1l_l1_ (u"ࠫࠬ塏"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡇࡋࡏࡘࡊࡘࡓ࠮࠳ࡶࡸࠬ塐"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ塑"),l11l1l_l1_ (u"ࠧࠨ塒"),url,html)
	if type==1: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ塓"),html,re.DOTALL)
	elif type==2: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ塔"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ塕"),block,re.DOTALL)
	if type==1:
		for l11l1llllll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ塖"),l1111l_l1_+title,url+l11l1l_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ塗")+l11l1llllll1_l1_,58)
	elif type==2:
		url,l11l1llllll1_l1_ = url.split(l11l1l_l1_ (u"࠭࠿ࠨ塘"))
		for l11llll1111_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塙"),l1111l_l1_+title,url+l11l1l_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ塚")+l11llll1111_l1_+l11l1l_l1_ (u"ࠩࠩࠫ塛")+l11l1llllll1_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ塜"),l11l1l_l1_ (u"ࠫࠬ塝"),search,search)
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ塞"),l11l1l_l1_ (u"࠭ࠥ࠳࠲ࠪ塟"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1ll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ塠"), l11l11_l1_, l11l1l_l1_ (u"ࠨࠩ塡"), l11l1l_l1_ (u"ࠩࠪ塢"), True,l11l1l_l1_ (u"ࠪࠫ塣"),l11l1l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ塤"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l11l11_l1_ = cookies[l11l1l_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳ࠭塥")]
	#l11l1llll111_l1_ = re.findall(l11l1l_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡣࡴࡴࡩࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭塦"),html,re.DOTALL)
	#l11l1llll111_l1_ = l11l1llll111_l1_[0]
	#payload = l11l1l_l1_ (u"ࠧࡠࡥࡶࡶ࡫ࡃࠧ塧") + l11l1llll111_l1_ + l11l1l_l1_ (u"ࠨࠨࡴࡁࠬ塨") + QUOTE(l1111l1_l1_)
	#headers = { l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ塩"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ塪") , l11l1l_l1_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ填"):l11l1l_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ塬")+l11l11l11_l1_ }
	#url = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠯ࡴࡧࡤࡶࡨ࡮ࠢ塭")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ塮"), url, payload, headers, True,l11l1l_l1_ (u"ࠨࠩ塯"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ塰"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ塱")+l1111l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ塲"),url,l11l1l_l1_ (u"ࠬ࠭塳"),l11l1l_l1_ (u"࠭ࠧ塴"),True,l11l1l_l1_ (u"ࠧࠨ塵"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧ塶"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡪࡩࡳ࡫ࡲࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡹࡥࡢࡴࡦ࡬࠲ࡨ࡯ࡵࡶࡲࡱ࠲ࡶࡡࡥࡦ࡬ࡲ࡬࠭塷"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ塸"),block,re.DOTALL)
	if items:
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			#title = title.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ塹")).encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ塺"))
			url = l11l11_l1_ + l1llll1_l1_
			if l11l1l_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ塻") in url:
				if l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ塼") in url:
					title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭塽")+title
					url = url.replace(l11l1l_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ塾"),l11l1l_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ塿"))
					url = url+l11l1l_l1_ (u"ࠫࡂ࠭墀")+QUOTE(title)+l11l1l_l1_ (u"ࠬࡃࠧ墁")+l1ll1l_l1_
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭墂"),l1111l_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ境")+title
					addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ墄"),l1111l_l1_+title,url,53,l1ll1l_l1_)
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ墅"),l11l1l_l1_ (u"ࠪࠫ墆"),l11l1l_l1_ (u"ࠫࡳࡵࠠࡳࡧࡶࡹࡱࡺࡳࠨ墇"),l11l1l_l1_ (u"๊ࠬวࠡฬ๋ะิࠦๆหษษะ๊ࠥไษฯฮࠫ墈"))
	return
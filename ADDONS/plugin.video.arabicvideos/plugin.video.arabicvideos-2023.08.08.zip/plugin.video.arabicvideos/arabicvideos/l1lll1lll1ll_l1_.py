# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ䷟")
headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䷠") : l11l1l_l1_ (u"ࠨࠩ䷡") }
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨ䷢")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1lllll_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1lll1ll_l1_(url)
	elif mode==214: results = l1l1l11111l1_l1_(url)
	elif mode==215: results = l1l1l11111ll_l1_(url)
	elif mode==218: results = l11l111l111_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11l111l111_l1_():
	message = l11l1l_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ䷣")
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䷤"),l11l1l_l1_ (u"ࠬ࠭䷥"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䷦"),l11l1l_l1_ (u"ࠧศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้࠭䷧"),message)
	return
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷨"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䷩"),l11l1l_l1_ (u"ࠪࠫ䷪"),219,l11l1l_l1_ (u"ࠫࠬ䷫"),l11l1l_l1_ (u"ࠬ࠭䷬"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䷭"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䷮"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึ࠭䷯"),l11l1l_l1_ (u"ࠩࠪ䷰"),114,l11l11_l1_)
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡖࡩ࡯ࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࡳ࡭ࡳࠬ࡬ࡪ࡯࡬ࡸࡂ࠸࠵ࠨ䷱")
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷲"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䷳")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็่๎ืฯࠧ䷴"),url,211)
	html = OPENURL_CACHED(l1llll1l_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ䷵"),headers,l11l1l_l1_ (u"ࠨࠩ䷶"),l11l1l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䷷"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡊ࡮ࡲࡴࡦࡴࡶࡆࡺࡺࡴࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䷸"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡪࡩࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䷹"),block,re.DOTALL)
	for l1llll1_l1_,title in items:#[1:-1]:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࠩ䷺")+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷻"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䷼")+l1111l_l1_+title,url,211)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䷽"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䷾"),block,re.DOTALL)
	l1l111_l1_ = [l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩ䷿"),l11l1l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭一")]
	#l1111l1l1_l1_ = [l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦࠧ丁"),l11l1l_l1_ (u"࠭วโๆส้ࠥ࠭丂"),l11l1l_l1_ (u"ࠧษำส้ั࠭七"),l11l1l_l1_ (u"ࠨ฻ิ์฻࠭丄"),l11l1l_l1_ (u"ࠩๆ่๏ฮวหࠩ丅"),l11l1l_l1_ (u"ࠪห฿อๆ๊ࠩ丆")]
	for l1llll1_l1_,title in items:
		title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭万"))
		if not any(value in title for value in l1l111_l1_):
		#	if any(value in title for value in l1111l1l1_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丈"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ三")+l1111l_l1_+title,l1llll1_l1_,211)
	return html
def l1lllll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠧࠨ上"),headers,l11l1l_l1_ (u"ࠨࠩ下"),l11l1l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ丌"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ不"),l11l1l_l1_ (u"ࠫࠬ与"),url,html)
	if l11l1l_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ丏") in url or l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ丐") in url: block = html
	else:
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭丑"),html,re.DOTALL)
		if l1l11ll_l1_: block = l1l11ll_l1_[0]
		else: return
	items = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭丒"),block,re.DOTALL)
	l11l_l1_ = []
	l111l1ll1_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩ专"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ且"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪ丕"),l11l1l_l1_ (u"้ࠬไ๋สࠪ世"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬ丗"),l11l1l_l1_ (u"่ࠧัสๅࠬ丘"),l11l1l_l1_ (u"ࠨ็หหึอษࠨ丙"),l11l1l_l1_ (u"ࠩ฼ี฻࠭业"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪ丛"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪ东")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ丝") in l1llll1_l1_: continue
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"࠭࠯ࠨ丞"))
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ丟"))
		if l11l1l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ丠") in l1llll1_l1_ or any(value in title for value in l111l1ll1_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ両"),l1111l_l1_+title,l1llll1_l1_,212,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭丢") in l1llll1_l1_ and l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠫ丣") in title:
			l1ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ两"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ严") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ並"),l1111l_l1_+title,l1llll1_l1_,213,l1ll1l_l1_)
					l11l_l1_.append(title)
		else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丧"),l1111l_l1_+title,l1llll1_l1_,213,l1ll1l_l1_)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ丨"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭丩"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ个"),l11l1l_l1_ (u"ࠬ࠭丫"))
			if title!=l11l1l_l1_ (u"࠭ࠧ丬"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ中"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ丮")+title,l1llll1_l1_,211)
	return
def l1lll1ll_l1_(url):
	l111ll11l_l1_,items,l1111l1l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠩࠪ丯"),headers,l11l1l_l1_ (u"ࠪࠫ丰"),l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ丱"))
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ串"),html,re.DOTALL)
	if l1l11ll_l1_:
		l11111l_l1_ = l11l1l_l1_ (u"࠭ࠧ丳").join(l1l11ll_l1_)
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭临"),l11111l_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ丵"))
	for l1llll1_l1_ in items:
		l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ丶"))
		title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ丷") + l1llll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭丸"))[-1].replace(l11l1l_l1_ (u"ࠬ࠳ࠧ丹"),l11l1l_l1_ (u"࠭ࠠࠨ为"))
		l111l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧศๆะ่็ฯ࠭ࠩ࡞ࡧ࠯࠮࠭主"),l1llll1_l1_.split(l11l1l_l1_ (u"ࠨ࠱ࠪ丼"))[-1],re.DOTALL)
		if l111l11l_l1_: l111l11l_l1_ = l111l11l_l1_[0]
		else: l111l11l_l1_ = l11l1l_l1_ (u"ࠩ࠳ࠫ丽")
		l1111l1l_l1_.append([l1llll1_l1_,title,l111l11l_l1_])
	items = sorted(l1111l1l_l1_, reverse=False, key=lambda key: int(key[2]))
	l111l1lll_l1_ = str(items).count(l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ举"))
	l111ll11l_l1_ = str(items).count(l11l1l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ丿"))
	if l111l1lll_l1_>1 and l111ll11l_l1_>0 and l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ乀") not in url:
		for l1llll1_l1_,title,l111l11l_l1_ in items:
			if l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ乁") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乂"),l1111l_l1_+title,l1llll1_l1_,213)
	else:
		for l1llll1_l1_,title,l111l11l_l1_ in items:
			if l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ乃") not in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ乄"),l1111l_l1_+title,l1llll1_l1_,212)
	return
def PLAY(url):
	l1lll1_l1_ = []
	parts = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ久"))
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠫࠬ乆"),headers,l11l1l_l1_ (u"ࠬ࠭乇"),l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ么"))
	# l11l1l111_l1_ l1l1_l1_
	if l11l1l_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ义") in html:
		l111ll1_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ乊"))
		l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ之"),headers,l11l1l_l1_ (u"ࠪࠫ乌"),l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ乍"))
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ乎"),l11ll11l_l1_,re.DOTALL)
		if l1l11ll_l1_:
			block = l1l11ll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡧࡵࡺࡪࡸ࡟ࡪ࡯ࡤ࡫ࡪࠨ࠾࡝ࡰࠫ࠲࠯ࡅࠩ࡝ࡰࠪ乏"),block,re.DOTALL)
			if items:
				id = re.findall(l11l1l_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ乐"),l11ll11l_l1_,re.DOTALL)
				if id:
					l11ll1lll1_l1_ = id[0]
					for l1llll1_l1_,title in items:
						l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫ乑")+l11ll1lll1_l1_+l11l1l_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭乒")+l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ乓")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ乔")
						l1lll1_l1_.append(l1llll1_l1_)
			else:
				# https://l1l1l1111l11_l1_.tv/l11l1l111_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭乕"),block,re.DOTALL)
				for l1llll1_l1_,dummy in items:
					l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	if l11l1l_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ乖") in html:
		l111ll1_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ乗"))
		l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ乘"),headers,l11l1l_l1_ (u"ࠩࠪ乙"),l11l1l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ乚"))
		id = re.findall(l11l1l_l1_ (u"ࠫࡵࡵࡳࡵࡋࡧ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ乛"),l11ll11l_l1_,re.DOTALL)
		if id:
			l11ll1lll1_l1_ = id[0]
			l1l1l1lll_l1_ = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ乜"):l11l1l_l1_ (u"࠭ࠧ九") , l11l1l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ乞"):l11l1l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ也") }
			l111ll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ习")+l11ll1lll1_l1_
			l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫ乡"),l1l1l1lll_l1_,l11l1l_l1_ (u"ࠫࠬ乢"),l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭乣"))
			l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ乤"),l11ll11l_l1_,re.DOTALL)
			if l1l11ll_l1_:
				for resolution,block in l1l11ll_l1_:
					items = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ乥"),block,re.DOTALL)
					for name,l1llll1_l1_ in items:
						l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ书")+name+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭乧")+l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ乨")+resolution)
			else:
				l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁ࡮࠶ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ乩"),l11ll11l_l1_,re.DOTALL)
				if not l1l11ll_l1_: l1l11ll_l1_ = [l11ll11l_l1_]
				for block in l1l11ll_l1_:
					l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡸ࡫ࡲࡷࡧࡵࡷ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡳࡧ࡭ࡦ࠼ࠍࠍࠎࠏࠉࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࡛࠮࠳ࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭วๅัๅอࠥ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫ࠡ࠾ࠩࠪ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧࠣ࠯ࠥ࠭ࠠแࠢࠪࠎࠎࠏࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࠩࠪࠎࠎࠏࠉࠊࠋࠥࠦࠧ乪")
					name = l11l1l_l1_ (u"࠭ࠧ乫")
					items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ乬"),block,re.DOTALL)
					for l1llll1_l1_ in items:
						server = l11l1l_l1_ (u"ࠨࠨࠩࠫ乭") + l1llll1_l1_.split(l11l1l_l1_ (u"ࠩ࠲ࠫ乮"))[2].lower() + l11l1l_l1_ (u"ࠪࠪࠫ࠭乯")
						server = server.replace(l11l1l_l1_ (u"ࠫ࠳ࡩ࡯࡮ࠨࠩࠫ买"),l11l1l_l1_ (u"ࠬ࠭乱")).replace(l11l1l_l1_ (u"࠭࠮ࡤࡱࠩࠪࠬ乲"),l11l1l_l1_ (u"ࠧࠨ乳"))
						server = server.replace(l11l1l_l1_ (u"ࠨ࠰ࡱࡩࡹࠬࠦࠨ乴"),l11l1l_l1_ (u"ࠩࠪ乵")).replace(l11l1l_l1_ (u"ࠪ࠲ࡴࡸࡧࠧࠨࠪ乶"),l11l1l_l1_ (u"ࠫࠬ乷"))
						server = server.replace(l11l1l_l1_ (u"ࠬ࠴࡬ࡪࡸࡨࠪࠫ࠭乸"),l11l1l_l1_ (u"࠭ࠧ乹")).replace(l11l1l_l1_ (u"ࠧ࠯ࡱࡱࡰ࡮ࡴࡥࠧࠨࠪ乺"),l11l1l_l1_ (u"ࠨࠩ乻"))
						server = server.replace(l11l1l_l1_ (u"ࠩࠩࠪ࡭ࡪ࠮ࠨ乼"),l11l1l_l1_ (u"ࠪࠫ乽")).replace(l11l1l_l1_ (u"ࠫࠫࠬࡷࡸࡹ࠱ࠫ乾"),l11l1l_l1_ (u"ࠬ࠭乿"))
						server = server.replace(l11l1l_l1_ (u"࠭ࠦࠧࠩ亀"),l11l1l_l1_ (u"ࠧࠨ亁"))
						l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ亂") + name + server + l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭亃")
						l1lll1_l1_.append(l1llll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ亄"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ亅"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭了"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ亇"),l11l1l_l1_ (u"ࠧࠬࠩ予"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ争")+search
	l1lllll_l1_(url)
	return
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡷࡪࡧࡲࡤࡪࠣࡷࡪࡩ࡯࡯ࡦࡤࡶࡾ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡩࡡࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩࡨࡦࡥ࡮ࡱࡦࡸ࡫࠮ࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠰࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌࠍ࡫ࡵࡲࠡࡥࡤࡸࡪ࡭࡯ࡳࡻ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࠌࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠋࡗࡍ࡙ࡒࡅࡔࠪࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ亊")
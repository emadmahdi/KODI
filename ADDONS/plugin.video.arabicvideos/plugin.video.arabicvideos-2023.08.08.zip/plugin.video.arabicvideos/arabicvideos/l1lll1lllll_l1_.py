# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l11l1_l1_
    l1l1l1l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l1l_l1_ % len (l1l1l1_l1_)
    l1ll1ll_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l1l_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ≁")
#l11l11_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠵࠳ࡨࡥࡴࡶࠪ≂")
#l11l11_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠳࠱ࡧࡴࡳࠧ≃")
#l11l11_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ≄")
#l11l11_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠴ࡣࡧࡶࡸ࠳ࡩ࡯࡮ࠩ≅")
#l11l11_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠲ࡼࡩࡱ࠰ࡶ࡬ࡴ࡬ࡤࡢ࠰ࡦࡳࡲ࠭≆")
#l11l11_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸ࡯࡮ࡧ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡳࡲࠧ≇")
#l11l11_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ≈")
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ≉")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡇࡊ࡚ࡤ࠭≊")
l11l11_l1_ = l1l1ll1_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11llll_l1_,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l1lllll_l1_(url,l11llll_l1_)
	elif mode==222: results = l11lll_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1ll1ll1_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ≋"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ≌"),l11l1l_l1_ (u"ࠪࠫ≍"),229,l11l1l_l1_ (u"ࠫࠬ≎"),l11l1l_l1_ (u"ࠬ࠭≏"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ≐"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ≑"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ≒"),l11l11_l1_,226,l11l1l_l1_ (u"ࠩࠪ≓"),l11l1l_l1_ (u"ࠪࠫ≔"),l11l1l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ≕"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ≖"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ≗"),l11l11_l1_,226,l11l1l_l1_ (u"ࠧࠨ≘"),l11l1l_l1_ (u"ࠨࠩ≙"),l11l1l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭≚"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ≛"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ≜"),l11l1l_l1_ (u"ࠬ࠭≝"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ≞"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ≟"),l11l1l_l1_ (u"ࠨࠩ≠"),l11l1l_l1_ (u"ࠩࠪ≡"),l11l1l_l1_ (u"ࠪࠫ≢"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ≣"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࠠࡪ࠯࡫ࡳࡲ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ≤"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ≥"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠧ࠽࠱࡬ࡂࠬ≦") in title: title = title.split(l11l1l_l1_ (u"ࠨ࠾࠲࡭ࡃ࠭≧"))[1]
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ≨"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ≩")+l1111l_l1_+title,l1llll1_l1_,222)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ≪"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ≫"),l11l1l_l1_ (u"࠭ࠧ≬"),9999)
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡣࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨ≭"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨࡲࡧࡥࠥࡨࡤࡣࠤࡁࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ≮"),html,re.DOTALL)
	for title,l1llll1_l1_ in items:
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ≯"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ≰")+l1111l_l1_+title,l1llll1_l1_,221)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ≱"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ≲"),l11l1l_l1_ (u"࠭ࠧ≳"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ≴"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠨࡪࡷࡱࡱ࠭≵") not in l1llll1_l1_: continue
		if not l1llll1_l1_.endswith(l11l1l_l1_ (u"ࠩ࠲ࠫ≶")): addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≷"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭≸")+l1111l_l1_+title,l1llll1_l1_,221)
	return html
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧศุ฽฻ࠥํๆศࠢ็ห฻อแสࠢสื๊ࠦฯฯ๊็ࠤํ้ไๆหࠣหู้ัࠨ࠮ࠪࠫ࠱࠸࠲࠶ࠫࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩอัี๐ัࠨ࠮ࠪࠫ࠱࠸࠲࠷ࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠤ࡭ࡺ࡭࡭ࠫࠍࠍࠨ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳࡒ࡯ࡢࡦࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠤࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠨ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡠࡳ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨ࡬࡯ࡳࠢࡸࡶࡱ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠦࠍ࡮࡬ࠠࡶࡴ࡯ࠥࡂࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠴࠵࠸࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࠱࠭ࠧ࠭࠴࠵࠽࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ๊รไอิࠤฺ๊ว่ัฬࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ࠲࠲࠳࠳ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ๊วโๆส้ࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ࠱࠸࠲࠵ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้๋ำๅี็หฯ࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠮ࠫ࠴ࡺࡶࠨ࠮࠵࠶࠹࠯ࠊࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡢࠢࡰ࡫ࡧ࠮࠮ࠫࡁࠬࡂࡊ࡭ࡹࡃࡧࡶࡸࡁ࠵ࡡ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠳࠴࠴࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠦࡨࡵ࡯࡯ࠎࠎࠩࠠࡦࡩࡼࡦࡪࡹࡴ࠲࠰ࡦࡳࡲࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠧ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡛࠲࠱ࡠ࡟࡮ࠨ࡝࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫࡹࡵࡲࡳࡧࡱࡸࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡵࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭ࡴࡰࡴࡵࡩࡳࡺࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠳࠴࠴࠭ࠏࠏࠢࠣࠤ≹")
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ≺"),url,l11l1l_l1_ (u"ࠧࠨ≻"),l11l1l_l1_ (u"ࠨࠩ≼"),l11l1l_l1_ (u"ࠩࠪ≽"),l11l1l_l1_ (u"ࠪࠫ≾"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭≿"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡳࡠࡵࡦࡶࡴࡲ࡬ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⊀"),html,re.DOTALL)
	block = l1l11ll_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⊁"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊂"),l1111l_l1_+title,l1llll1_l1_,224)
	return
def l1ll1ll1_l1_(url):
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊃"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠩ⊄"),url,221)
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠪࠫ⊅"),l11l1l_l1_ (u"ࠫࠬ⊆"),l11l1l_l1_ (u"ࠬ࠭⊇"),l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⊈"))
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡲࡧࡩ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࠧࠨࠢ⊉")
	l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡸࡦࡤࡴࡡࡷࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵࠪ⊊"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⊋"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠪࠧࠬ⊌"): name = title
			else:
				title = title + l11l1l_l1_ (u"ࠫࠥࠦ࠺ࠡࠢࠪ⊍") + l11l1l_l1_ (u"ࠬ็ไหำࠣࠫ⊎") + name
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊏"),l1111l_l1_+title,l1llll1_l1_,221)
	else: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,l11llll_l1_=l11l1l_l1_ (u"ࠧ࠲ࠩ⊐")):
	if l11llll_l1_==l11l1l_l1_ (u"ࠨࠩ⊑"): l11llll_l1_ = l11l1l_l1_ (u"ࠩ࠴ࠫ⊒")
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⊓"),l11l1l_l1_ (u"ࠫࠬ⊔"),str(url), str(l11llll_l1_))
	if l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭⊕") in url or l11l1l_l1_ (u"࠭࠿ࠨ⊖") in url: l111ll1_l1_ = url + l11l1l_l1_ (u"ࠧࠧࠩ⊗")
	else: l111ll1_l1_ = url + l11l1l_l1_ (u"ࠨࡁࠪ⊘")
	#l111ll1_l1_ = l111ll1_l1_ + l11l1l_l1_ (u"ࠩࡲࡹࡹࡶࡵࡵࡡࡩࡳࡷࡳࡡࡵ࠿࡭ࡷࡴࡴࠦࡰࡷࡷࡴࡺࡺ࡟࡮ࡱࡧࡩࡂࡳ࡯ࡷ࡫ࡨࡷࡤࡲࡩࡴࡶࠩࡴࡦ࡭ࡥ࠾ࠩ⊙")+l11llll_l1_
	l111ll1_l1_ = l111ll1_l1_ + l11l1l_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩ⊚") + l11llll_l1_
	html = OPENURL_CACHED(REGULAR_CACHE,l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ⊛"),l11l1l_l1_ (u"ࠬ࠭⊜"),l11l1l_l1_ (u"࠭ࠧ⊝"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⊞"))
	#name = l11l1l_l1_ (u"ࠨࠩ⊟")
	#if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪ⊠") in url:
	#	name = re.findall(l11l1l_l1_ (u"ࠪࡀ࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⊡"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l11l1l_l1_ (u"ࠫࠥ࠭⊢")) + l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩ⊣")
	#	else: name = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠢ⊤") ) + l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ⊥")
	if l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩ⊦") in url:
		l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡨࡦࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ⊧"),html,re.DOTALL)
		block = l1l11ll_l1_[-1]
	# l1lll1ll1ll_l1_ l1lll1l_l1_
	elif l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⊨") in url:
		l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡴࡽ࡬࠮ࡥࡤࡶࡴࡻࡳࡦ࡮ࠣࡳࡼࡲ࠭ࡤࡣࡵࡳࡺࡹࡥ࡭ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ⊩"),html,re.DOTALL)
		block = l1l11ll_l1_[0]
	else:
		l1l11ll_l1_=re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⊪"),html,re.DOTALL)
		block = l1l11ll_l1_[-1]
	items = re.findall(l11l1l_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⊫"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡯ࡦࠡࠩ࠲ࡷࡪࡸࡩࡦࡵࠪࠤ࡮ࡴࠠࡶࡴ࡯ࠤࡦࡴࡤࠡࠩ࠲ࡷࡪࡧࡳࡰࡰࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࡪࡨࠣࠫ࠴ࡹࡥࡢࡵࡲࡲࠬࠦࡩ࡯ࠢࡸࡶࡱࠦࡡ࡯ࡦࠣࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡴࡪࡶ࡯ࡩ࠱ࠦࡳࡵࡴࠫࡰ࡮ࡴ࡫ࠪࠫࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦ࡮ࡢ࡯ࡨࠤ࠰ࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫࠍࠍࠎࠨࠢࠣ⊬")
		title = unescapeHTML(title)
		l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࠊ࡫ࡰ࡫ࠥࡃࠠࡪ࡯ࡪ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࠰ࠩ࠯ࠫ࠴࠭ࠩࠋࠋࠌ࡭࡫ࠦࠧࡩࡶࡷࡴࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡩ࡮ࡩ࠽ࠤ࡮ࡳࡧࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪࠤ࠰ࠦࡩ࡮ࡩࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡎࡐࡖࡌࡊࡎࡉࡁࡕࡋࡒࡒ࠭࡯࡭ࡨ࠮ࠪࠫ࠮ࠐࠉࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤ࠰ࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠢࠣࠤ⊭")
		if l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪ⊮") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࠬ⊯") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⊰"),l1111l_l1_+title,l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠬ࠵ࠧ⊱")),223,l1ll1l_l1_)
		else:
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊲"),l1111l_l1_+title,l1llll1_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l1111l11ll_l1_ = [l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⊳"),l11l1l_l1_ (u"ࠨ࠱ࡷࡺࠬ⊴"),l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ⊵"),l11l1l_l1_ (u"ࠪ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭⊶")]
		l11llll_l1_ = int(l11llll_l1_)
		if any(value in url for value in l1111l11ll_l1_):
			for n in range(0,1000,100):
				if int(l11llll_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l11llll_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l11llll_l1_==j and j!=0:
									addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊷"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ⊸")+str(j),url,221,l11l1l_l1_ (u"࠭ࠧ⊹"),str(j))
						elif i!=0: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊺"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ⊻")+str(i),url,221,l11l1l_l1_ (u"ࠩࠪ⊼"),str(i))
						else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⊽"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ⊾")+str(1),url,221,l11l1l_l1_ (u"ࠬ࠭⊿"),str(1))
				elif n!=0: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋀"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭⋁")+str(n),url,221,l11l1l_l1_ (u"ࠨࠩ⋂"),str(n))
				else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋃"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩ⋄")+str(1),url,221)
	return
def PLAY(url):
	#global l11l1l_l1_ (u"ࠫࠬ⋅")
	l1ll1lll_l1_,l1lll1_l1_ = [],[]
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⋆"),l11l1l_l1_ (u"࠭ࠧ⋇"),url, url[-45:])
	# https://l1llll11ll1_l1_.com/l1llll1l1ll_l1_/فيلم-the-l1llll1llll_l1_-l1lll1lll11_l1_-2019-مترجم
	html = OPENURL_CACHED(l1llll1l_l1_,url,l11l1l_l1_ (u"ࠧࠨ⋈"),l11l1l_l1_ (u"ࠨࠩ⋉"),l11l1l_l1_ (u"ࠩࠪ⋊"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⋋"))
	l11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡺࡤ࠿ษ็ฮฺ์๊โ࠾࠲ࡸࡩࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⋌"),html,re.DOTALL)
	if l11l1l1_l1_ and l11l11l_l1_(l1ll1_l1_,url,l11l1l1_l1_): return
	# https://l111l11111_l1_.l1lll1ll1l1_l1_/l1llll1l1ll_l1_/فيلم-the-l1llll1llll_l1_-l1lll1lll11_l1_-2019-مترجم
	l111llll1_l1_,l11ll1l11_l1_ = l11l1l_l1_ (u"ࠬ࠭⋍"),l11l1l_l1_ (u"࠭ࠧ⋎")
	l1lllll1111_l1_,l1llll111ll_l1_ = html,html
	l1llll1l111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡪࡲࡻࡤࡪ࡬ࠡࡣࡳ࡭ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋏"),html,re.DOTALL)
	if l1llll1l111_l1_:
		for l1llll1_l1_ in l1llll1l111_l1_:
			if l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ⋐") in l1llll1_l1_: l111llll1_l1_ = l1llll1_l1_
			elif l11l1l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭⋑") in l1llll1_l1_: l11ll1l11_l1_ = l1llll1_l1_
		if l111llll1_l1_!=l11l1l_l1_ (u"ࠪࠫ⋒"): l1lllll1111_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111llll1_l1_,l11l1l_l1_ (u"ࠫࠬ⋓"),l11l1l_l1_ (u"ࠬ࠭⋔"),l11l1l_l1_ (u"࠭ࠧ⋕"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭⋖"))
		if l11ll1l11_l1_!=l11l1l_l1_ (u"ࠨࠩ⋗"): l1llll111ll_l1_ = OPENURL_CACHED(l1llll1l_l1_,l11ll1l11_l1_,l11l1l_l1_ (u"ࠩࠪ⋘"),l11l1l_l1_ (u"ࠪࠫ⋙"),l11l1l_l1_ (u"ࠫࠬ⋚"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ⋛"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⋜"),l11l1l_l1_ (u"ࠧࠨ⋝"),l11ll1l11_l1_,l111llll1_l1_)
	# https://l1llll111l1_l1_.l111l11111_l1_.download/?id=__1llll1lll1_l1_
	l1llll1l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⋞"),l1lllll1111_l1_,re.DOTALL)
	if l1llll1l11l_l1_:
		l111ll1_l1_ = l1llll1l11l_l1_[0]#+l11l1l_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡀ࠯࠰࠹࠼࠲࠶࠼࠵࠯࠴࠷࠶࠳࠾࠴࠻࠶࠴࠸࠺࠭⋟")
		if l111ll1_l1_!=l11l1l_l1_ (u"ࠪࠫ⋠") and l11l1l_l1_ (u"ࠫࡺࡶ࡬ࡰࡣࡧࡩࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࡱࡺࡲࡱࡵࡡࡥࠩ⋡") in l111ll1_l1_ and l11l1l_l1_ (u"ࠬ࠵࠿ࡪࡦࡀࡣࠬ⋢") not in l111ll1_l1_:
			l11ll11l_l1_ = OPENURL_CACHED(l1llll1l_l1_,l111ll1_l1_,l11l1l_l1_ (u"࠭ࠧ⋣"),l11l1l_l1_ (u"ࠧࠨ⋤"),l11l1l_l1_ (u"ࠨࠩ⋥"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ⋦"))
			l1lll1ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⋧"),l11ll11l_l1_,re.DOTALL)
			if l1lll1ll111_l1_:
				for l1llll1_l1_,l111ll1l_l1_ in l1lll1ll111_l1_:
					l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡪࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࡲࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢࠫ⋨")+l111ll1l_l1_)
			else:
				server = l111ll1_l1_.split(l11l1l_l1_ (u"ࠬ࠵ࠧ⋩"))[2]
				l1lll1_l1_.append(l111ll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋪")+server+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⋫"))
		elif l111ll1_l1_!=l11l1l_l1_ (u"ࠨࠩ⋬"):
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ⋭"),l11l1l_l1_ (u"ࠪࠫ⋮"),l111ll1_l1_,str(l1llll1l11l_l1_))
			server = l111ll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭⋯"))[2]
			l1lll1_l1_.append(l111ll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⋰")+server+l11l1l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⋱"))
	# https://l1lll1llll1_l1_.cc/l1llll1ll1l_l1_
	# https://l1llll1l1l1_l1_.l1lll1lll1l_l1_/l1llll1ll1l_l1_
	l1llll1111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡶࡤࡦࡱ࡫ࠠࡤ࡮ࡤࡷࡸࡃࠢࡥ࡮ࡶࡣࡹࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ⋲"),l1llll111ll_l1_,re.DOTALL)
	if l1llll1111l_l1_:
		l1llll1111l_l1_ = l1llll1111l_l1_[0]
		l1llll11lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡷࡨࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⋳"),l1llll1111l_l1_,re.DOTALL)
		if l1llll11lll_l1_:
			for l111ll1l_l1_,l1llll1_l1_ in l1llll11lll_l1_:
				if l11l1l_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ⋴") not in l1llll1_l1_: continue
				if l1llll1_l1_.count(l11l1l_l1_ (u"ࠪ࠳ࠬ⋵"))>=2:
					server = l1llll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭⋶"))[2]
					l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⋷")+server+l11l1l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡲࡶ࠴ࡠࡡࠪ⋸")+l111ll1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ⋹"), l1lll1_l1_)
	#if l1l_l1_ == -1 : return
	l1llll11111_l1_ = []
	for l1llll1_l1_ in l1lll1_l1_:
		# faselhd	https://l1lll1ll11_l1_.l111l11111_l1_.l1lll1ll1l1_l1_/l1llll1l1ll_l1_/l11l1l111_l1_/فيلم-the-l1llll1ll11_l1_-l1llll11l1l_l1_-l1lll1ll11l_l1_-2017-مترجم/l1llll11l11_l1_
		#if l11l1l_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ⋺") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶ࠿࡯ࡣࡰࡩࠬ⋻") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ⋼") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭⋽") not in l1llll1_l1_: continue
		l1llll11111_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⋾"), l1llll11111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11111_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⋿"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ⌀"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ⌁"): return
	l1111l1_l1_ = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ⌂"),l11l1l_l1_ (u"ࠪ࠯ࠬ⌃"))
	html = OPENURL_CACHED(l1ll1ll11_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ⌄"),l11l1l_l1_ (u"ࠬ࠭⌅"),l11l1l_l1_ (u"࠭ࠧ⌆"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ⌇"))
	token = re.findall(l11l1l_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡶࡲ࡯ࡪࡴࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⌈"),html,re.DOTALL)
	if token:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡣࡹࡵ࡫ࡦࡰࡀࠫ⌉")+token[0]+l11l1l_l1_ (u"ࠪࠪࡶࡃࠧ⌊")+l1111l1_l1_
		l1lllll_l1_(url)
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ⌋"),l11l1l_l1_ (u"ࠬ࠭⌌"),l11l1l_l1_ (u"࠭ࠧ⌍"), l11l1l_l1_ (u"ࠧࠨ⌎"))
	return
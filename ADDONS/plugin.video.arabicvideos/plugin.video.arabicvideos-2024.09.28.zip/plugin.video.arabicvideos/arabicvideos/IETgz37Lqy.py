# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'IFILM'
j0jSEdTPJuG4XNvfpO = '_IFL_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
p2tHwDRfg16WJ0IYF5xLXGa9S7us = PhpFa6EdVS[bIPsOxjEpoH][1]
iHXu7vrG8q = PhpFa6EdVS[bIPsOxjEpoH][2]
OOSeUghnmsB5Mo8qN4 = PhpFa6EdVS[bIPsOxjEpoH][3]
def mp9gnhjBIoA8Rz3SylG(mode,url,wlxviMOuNeQVct4ULsCEHXZm6yR2p,text):
	if   mode==20: CsaNhTtGm8 = lWdrPf2o5mb9hvckt0QTOFX17M()
	elif mode==21: CsaNhTtGm8 = bELNFKS6fCB(url)
	elif mode==22: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==23: CsaNhTtGm8 = dHjny9tTucrO(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==24: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url,text)
	elif mode==25: CsaNhTtGm8 = rqZcdC6Rultp(url)
	elif mode==27: CsaNhTtGm8 = nHNoV6BMsIPWhxt2FKC(url)
	elif mode==28: CsaNhTtGm8 = gt3Y94FR2uNIbqvk()
	elif mode==29: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def lWdrPf2o5mb9hvckt0QTOFX17M():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'عربي',qfzHe2Yr49,21,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'English',p2tHwDRfg16WJ0IYF5xLXGa9S7us,21,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فارسى',iHXu7vrG8q,21,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فارسى 2',OOSeUghnmsB5Mo8qN4,21,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	return
def gt3Y94FR2uNIbqvk():
	A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'عربي',qfzHe2Yr49,27)
	A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'English',p2tHwDRfg16WJ0IYF5xLXGa9S7us,27)
	A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'فارسى',iHXu7vrG8q,27)
	A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'فارسى 2',OOSeUghnmsB5Mo8qN4,27)
	return
def bELNFKS6fCB(gbfBRGAX3jdx9DNIwouqF):
	bIPsOxjEpoH = gbfBRGAX3jdx9DNIwouqF
	if gbfBRGAX3jdx9DNIwouqF=='IFILM-ARABIC': gbfBRGAX3jdx9DNIwouqF = qfzHe2Yr49
	elif gbfBRGAX3jdx9DNIwouqF=='IFILM-ENGLISH': gbfBRGAX3jdx9DNIwouqF = p2tHwDRfg16WJ0IYF5xLXGa9S7us
	else: bIPsOxjEpoH = Zg9FeADE84jSRIvPCrzYulw3sL
	Zxh5l1rNem = WQCUHyEib1(gbfBRGAX3jdx9DNIwouqF)
	if Zxh5l1rNem=='ar' or bIPsOxjEpoH=='IFILM-ARABIC':
		z63gGkn7Bs459 = 'بحث في الموقع'
		VgGC5zyJMN6lEtIu8D7b = 'مسلسلات - حالية'
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'مسلسلات - أحدث'
		uGgbzHI7ro = 'مسلسلات - أبجدي'
		PwyKMQjINVkvY0AZ5 = 'بث حي آي فيلم'
		zY5iQ80l1eBDU = 'أفلام'
		qMaWl9o6egZXShPYydwkLQtTOr4xN = 'موسيقى'
		j96XwzNRck3mxdCes5yvPnLI = 'برامج'
	elif Zxh5l1rNem=='en' or bIPsOxjEpoH=='IFILM-ENGLISH':
		z63gGkn7Bs459 = 'Search in site'
		VgGC5zyJMN6lEtIu8D7b = 'Series - Current'
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'Series - Latest'
		uGgbzHI7ro = 'Series - Alphabet'
		PwyKMQjINVkvY0AZ5 = 'Live iFilm channel'
		zY5iQ80l1eBDU = 'Movies'
		qMaWl9o6egZXShPYydwkLQtTOr4xN = 'Music'
		j96XwzNRck3mxdCes5yvPnLI = 'Shows'
	elif Zxh5l1rNem in ['fa','fa2']:
		z63gGkn7Bs459 = 'جستجو در سایت'
		VgGC5zyJMN6lEtIu8D7b = 'سريال - جاری'
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'سريال - آخرین'
		uGgbzHI7ro = 'سريال - الفبا'
		PwyKMQjINVkvY0AZ5 = 'پخش زنده اي فيلم'
		zY5iQ80l1eBDU = 'فيلم'
		qMaWl9o6egZXShPYydwkLQtTOr4xN = 'موسيقى'
		j96XwzNRck3mxdCes5yvPnLI = 'برنامه ها'
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+z63gGkn7Bs459,gbfBRGAX3jdx9DNIwouqF,29,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('live',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+PwyKMQjINVkvY0AZ5,gbfBRGAX3jdx9DNIwouqF,27)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	trgU5GIRQc = ['Series','Program','Music']
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,gbfBRGAX3jdx9DNIwouqF+'/home',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-MENU-1st')
	HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('button-menu(.*?)/Contact',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in yDTPzhEBKVJl7CX81 for B251BPiLbvG9UxszKtlI7YQHmoWw in trgU5GIRQc):
				url = gbfBRGAX3jdx9DNIwouqF+yDTPzhEBKVJl7CX81
				if 'Series' in yDTPzhEBKVJl7CX81:
					A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'100')
					A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+W4KwrJtUfaNF2Q3Coqsl869V1dbm,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
					A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+uGgbzHI7ro,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'201')
				elif 'Film' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+zY5iQ80l1eBDU,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'100')
				elif 'Music' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+qMaWl9o6egZXShPYydwkLQtTOr4xN,url,25,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
				elif 'Program' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+j96XwzNRck3mxdCes5yvPnLI,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def rqZcdC6Rultp(url):
	gbfBRGAX3jdx9DNIwouqF = smKnw6PSe9i0aBlyIzdTY(url)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-MUSIC_MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Music-tools-header(.*?)Music-body',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<p>(.*?)</p>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,22,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		yDTPzhEBKVJl7CX81 = gbfBRGAX3jdx9DNIwouqF + yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,23,Zg9FeADE84jSRIvPCrzYulw3sL,'101')
	return
def mbzIyKNqMVt0FQeOsPWc(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	gbfBRGAX3jdx9DNIwouqF = smKnw6PSe9i0aBlyIzdTY(url)
	Zxh5l1rNem = WQCUHyEib1(url)
	type = url.split('/')[-1]
	s5tY6dqCaviP1p3XV9zRQjLGInwgE7 = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)//100)
	wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)%100)
	if type=='Series' and wlxviMOuNeQVct4ULsCEHXZm6yR2p=='0':
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-TITLES-1st')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('serial-body(.*?)class="row',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			title = BtKvPnEQJx32Z(title)
			yDTPzhEBKVJl7CX81 = gbfBRGAX3jdx9DNIwouqF + yDTPzhEBKVJl7CX81
			W8KBRzkdhlCxvF5sY2T = gbfBRGAX3jdx9DNIwouqF + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,23,W8KBRzkdhlCxvF5sY2T,s5tY6dqCaviP1p3XV9zRQjLGInwgE7+'01')
	xxnJoUvf2cSybhl=0
	if type=='Series': WWdHIOCPeKmgRstXk4c='3'
	if type=='Film': WWdHIOCPeKmgRstXk4c='5'
	if type=='Program': WWdHIOCPeKmgRstXk4c='7'
	if type in ['Series','Program','Film'] and wlxviMOuNeQVct4ULsCEHXZm6yR2p!='0':
		hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Home/PageingItem?category='+WWdHIOCPeKmgRstXk4c+'&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&orderby='+s5tY6dqCaviP1p3XV9zRQjLGInwgE7
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-TITLES-2nd')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,title,W8KBRzkdhlCxvF5sY2T in items:
			title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			title = title.replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
			title = title.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			xxnJoUvf2cSybhl += 1
			yDTPzhEBKVJl7CX81 = gbfBRGAX3jdx9DNIwouqF + '/' + type + '/Content/' + id
			W8KBRzkdhlCxvF5sY2T = gbfBRGAX3jdx9DNIwouqF + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
			if type=='Film': A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,24,W8KBRzkdhlCxvF5sY2T,s5tY6dqCaviP1p3XV9zRQjLGInwgE7+'01')
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,23,W8KBRzkdhlCxvF5sY2T,s5tY6dqCaviP1p3XV9zRQjLGInwgE7+'01')
	if type=='Music':
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,gbfBRGAX3jdx9DNIwouqF+'/Music/Index?page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-TITLES-3rd')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination-demo(.*?)pagination-demo',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			xxnJoUvf2cSybhl += 1
			W8KBRzkdhlCxvF5sY2T = gbfBRGAX3jdx9DNIwouqF + W8KBRzkdhlCxvF5sY2T
			yDTPzhEBKVJl7CX81 = gbfBRGAX3jdx9DNIwouqF + yDTPzhEBKVJl7CX81
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,23,W8KBRzkdhlCxvF5sY2T,'101')
	if xxnJoUvf2cSybhl>20:
		title='صفحة '
		if Zxh5l1rNem=='en': title = 'Page '
		if Zxh5l1rNem=='fa': title = 'صفحه '
		if Zxh5l1rNem=='fa2': title = 'صفحه '
		for wwybmRCecB4fsZp in range(1,11) :
			if not wlxviMOuNeQVct4ULsCEHXZm6yR2p==str(wwybmRCecB4fsZp):
				aUbmpskYHZX3P4g2VMBEGuD70AnRcw = '0'+str(wwybmRCecB4fsZp)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title+str(wwybmRCecB4fsZp),url,22,Zg9FeADE84jSRIvPCrzYulw3sL,s5tY6dqCaviP1p3XV9zRQjLGInwgE7+aUbmpskYHZX3P4g2VMBEGuD70AnRcw[-2:])
	return
def dHjny9tTucrO(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	if not wlxviMOuNeQVct4ULsCEHXZm6yR2p: wlxviMOuNeQVct4ULsCEHXZm6yR2p = 0
	gbfBRGAX3jdx9DNIwouqF = smKnw6PSe9i0aBlyIzdTY(url)
	P78WGtDibKXjkIsexnHFqhM9l1w = smKnw6PSe9i0aBlyIzdTY(url)
	Zxh5l1rNem = WQCUHyEib1(url)
	Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('/')
	id,type = Gi82lgtIxVsjSyqZU5EmBLkKw[-1],Gi82lgtIxVsjSyqZU5EmBLkKw[3]
	s5tY6dqCaviP1p3XV9zRQjLGInwgE7 = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)//100)
	wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)%100)
	xxnJoUvf2cSybhl = 0
	if type=='Series':
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-1st')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		title = ' - الحلقة '
		if Zxh5l1rNem=='en': title = ' - Episode '
		if Zxh5l1rNem=='fa': title = ' - قسمت '
		if Zxh5l1rNem=='fa2': title = ' - قسمت '
		if Zxh5l1rNem=='fa': h3GZqkpBMw6FaNdnbVsyrKEXjxWI1m = Zg9FeADE84jSRIvPCrzYulw3sL
		else: h3GZqkpBMw6FaNdnbVsyrKEXjxWI1m = Zxh5l1rNem
		a9GhY75sKbySuZMv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for name,count,W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81 in items:
			for jjYXOr8QJsNUZv0PGL27ARSDceiq4 in range(int(count),0,-1):
				aaS58W3uAFHKtmp = W8KBRzkdhlCxvF5sY2T + h3GZqkpBMw6FaNdnbVsyrKEXjxWI1m + id + '/' + str(jjYXOr8QJsNUZv0PGL27ARSDceiq4) + '.png'
				VgGC5zyJMN6lEtIu8D7b = name + title + str(jjYXOr8QJsNUZv0PGL27ARSDceiq4)
				VgGC5zyJMN6lEtIu8D7b = BtKvPnEQJx32Z(VgGC5zyJMN6lEtIu8D7b)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,url,24,aaS58W3uAFHKtmp,Zg9FeADE84jSRIvPCrzYulw3sL,str(jjYXOr8QJsNUZv0PGL27ARSDceiq4))
	elif type=='Program':
		hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&orderby=1'
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-2nd')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		title = ' - الحلقة '
		if Zxh5l1rNem=='en': title = ' - Episode '
		if Zxh5l1rNem=='fa': title = ' - قسمت '
		if Zxh5l1rNem=='fa2': title = ' - قسمت '
		for jjYXOr8QJsNUZv0PGL27ARSDceiq4,W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,ee1IzWwCUO,name in items:
			xxnJoUvf2cSybhl += 1
			aaS58W3uAFHKtmp = P78WGtDibKXjkIsexnHFqhM9l1w + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
			name = uumhMi6O4pk7Gjd5aTQqy2Z(name)
			VgGC5zyJMN6lEtIu8D7b = name + title + str(jjYXOr8QJsNUZv0PGL27ARSDceiq4)
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,hc5ePKxl4LJvEjDgTm,24,aaS58W3uAFHKtmp,Zg9FeADE84jSRIvPCrzYulw3sL,str(xxnJoUvf2cSybhl))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Music/GetTracksBy?id='+str(id)+'&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&type=0'
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-3rd')
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,name,title in items:
				xxnJoUvf2cSybhl += 1
				aaS58W3uAFHKtmp = P78WGtDibKXjkIsexnHFqhM9l1w + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
				VgGC5zyJMN6lEtIu8D7b = name + ' - ' + title
				VgGC5zyJMN6lEtIu8D7b = VgGC5zyJMN6lEtIu8D7b.strip(wjs26GpVfNiCUERHJ)
				VgGC5zyJMN6lEtIu8D7b = uumhMi6O4pk7Gjd5aTQqy2Z(VgGC5zyJMN6lEtIu8D7b)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,hc5ePKxl4LJvEjDgTm,24,aaS58W3uAFHKtmp,Zg9FeADE84jSRIvPCrzYulw3sL,str(xxnJoUvf2cSybhl))
		elif 'Clips' in url:
			hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Music/GetTracksBy?id=0&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&type=15'
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-4th')
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for W8KBRzkdhlCxvF5sY2T,title,yDTPzhEBKVJl7CX81 in items:
				xxnJoUvf2cSybhl += 1
				aaS58W3uAFHKtmp = P78WGtDibKXjkIsexnHFqhM9l1w + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
				VgGC5zyJMN6lEtIu8D7b = title.strip(wjs26GpVfNiCUERHJ)
				VgGC5zyJMN6lEtIu8D7b = uumhMi6O4pk7Gjd5aTQqy2Z(VgGC5zyJMN6lEtIu8D7b)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,hc5ePKxl4LJvEjDgTm,24,aaS58W3uAFHKtmp,Zg9FeADE84jSRIvPCrzYulw3sL,str(xxnJoUvf2cSybhl))
		elif 'category' in url:
			if 'category=6' in url:
				hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Music/GetTracksBy?id=0&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&type=6'
				yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				hc5ePKxl4LJvEjDgTm = gbfBRGAX3jdx9DNIwouqF+'/Music/GetTracksBy?id=0&page='+wlxviMOuNeQVct4ULsCEHXZm6yR2p+'&size=30&type=4'
				yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-EPISODES-6th')
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,name,title in items:
				xxnJoUvf2cSybhl += 1
				aaS58W3uAFHKtmp = P78WGtDibKXjkIsexnHFqhM9l1w + OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
				VgGC5zyJMN6lEtIu8D7b = name + ' - ' + title
				VgGC5zyJMN6lEtIu8D7b = VgGC5zyJMN6lEtIu8D7b.strip(wjs26GpVfNiCUERHJ)
				VgGC5zyJMN6lEtIu8D7b = uumhMi6O4pk7Gjd5aTQqy2Z(VgGC5zyJMN6lEtIu8D7b)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+VgGC5zyJMN6lEtIu8D7b,hc5ePKxl4LJvEjDgTm,24,aaS58W3uAFHKtmp,Zg9FeADE84jSRIvPCrzYulw3sL,str(xxnJoUvf2cSybhl))
	if type=='Music' or type=='Program':
		if xxnJoUvf2cSybhl>25:
			title='صفحة '
			if Zxh5l1rNem=='en': title = ' Page '
			if Zxh5l1rNem=='fa': title = ' صفحه '
			if Zxh5l1rNem=='fa2': title = ' صفحه '
			for wwybmRCecB4fsZp in range(1,11):
				if not wlxviMOuNeQVct4ULsCEHXZm6yR2p==str(wwybmRCecB4fsZp):
					aUbmpskYHZX3P4g2VMBEGuD70AnRcw = '0'+str(wwybmRCecB4fsZp)
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title+str(wwybmRCecB4fsZp),url,23,Zg9FeADE84jSRIvPCrzYulw3sL,s5tY6dqCaviP1p3XV9zRQjLGInwgE7+aUbmpskYHZX3P4g2VMBEGuD70AnRcw[-2:])
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url,jjYXOr8QJsNUZv0PGL27ARSDceiq4):
	P78WGtDibKXjkIsexnHFqhM9l1w = smKnw6PSe9i0aBlyIzdTY(url)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-PLAY-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		Zxh5l1rNem = WQCUHyEib1(url)
		Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('/')
		id,type = Gi82lgtIxVsjSyqZU5EmBLkKw[-1],Gi82lgtIxVsjSyqZU5EmBLkKw[3]
		yDTPzhEBKVJl7CX81 = items[0][0]+Zxh5l1rNem+id+'/,'+jjYXOr8QJsNUZv0PGL27ARSDceiq4+','+jjYXOr8QJsNUZv0PGL27ARSDceiq4+'_'+items[0][2]
		nnhWEIa6Tm.append('m3u8')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		Zxh5l1rNem = WQCUHyEib1(url)
		Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('/')
		id,type = Gi82lgtIxVsjSyqZU5EmBLkKw[-1],Gi82lgtIxVsjSyqZU5EmBLkKw[3]
		yDTPzhEBKVJl7CX81 = items[0][0]+Zxh5l1rNem+id+'/'+jjYXOr8QJsNUZv0PGL27ARSDceiq4+items[0][2]
		nnhWEIa6Tm.append('mp4 url')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81 in items:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('//','/')
		nnhWEIa6Tm.append('mp4 src')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('VideoAddress":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		yDTPzhEBKVJl7CX81 = items[int(jjYXOr8QJsNUZv0PGL27ARSDceiq4)-1]
		yDTPzhEBKVJl7CX81 = P78WGtDibKXjkIsexnHFqhM9l1w+OJYiDeyvSPTNI9(yDTPzhEBKVJl7CX81)
		nnhWEIa6Tm.append('mp4 address')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('VoiceAddress":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		yDTPzhEBKVJl7CX81 = items[int(jjYXOr8QJsNUZv0PGL27ARSDceiq4)-1]
		yDTPzhEBKVJl7CX81 = P78WGtDibKXjkIsexnHFqhM9l1w+OJYiDeyvSPTNI9(yDTPzhEBKVJl7CX81)
		nnhWEIa6Tm.append('mp3 address')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==1: yDTPzhEBKVJl7CX81 = fo6s53yEnbklLpaJOzgR4Q01wxB[0]
	else:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الفيديو المناسب:', nnhWEIa6Tm)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1 : return
		yDTPzhEBKVJl7CX81 = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	nTdpZOCUe7l(yDTPzhEBKVJl7CX81,bIPsOxjEpoH,'video')
	return
def smKnw6PSe9i0aBlyIzdTY(url):
	if qfzHe2Yr49 in url: FLqQoZwdAngNkz49RMGUHJXW3bDC = qfzHe2Yr49
	elif p2tHwDRfg16WJ0IYF5xLXGa9S7us in url: FLqQoZwdAngNkz49RMGUHJXW3bDC = p2tHwDRfg16WJ0IYF5xLXGa9S7us
	elif iHXu7vrG8q in url: FLqQoZwdAngNkz49RMGUHJXW3bDC = iHXu7vrG8q
	elif OOSeUghnmsB5Mo8qN4 in url: FLqQoZwdAngNkz49RMGUHJXW3bDC = OOSeUghnmsB5Mo8qN4
	else: FLqQoZwdAngNkz49RMGUHJXW3bDC = Zg9FeADE84jSRIvPCrzYulw3sL
	return FLqQoZwdAngNkz49RMGUHJXW3bDC
def WQCUHyEib1(url):
	if   qfzHe2Yr49 in url: Zxh5l1rNem = 'ar'
	elif p2tHwDRfg16WJ0IYF5xLXGa9S7us in url: Zxh5l1rNem = 'en'
	elif iHXu7vrG8q in url: Zxh5l1rNem = 'fa'
	elif OOSeUghnmsB5Mo8qN4 in url: Zxh5l1rNem = 'fa2'
	else: Zxh5l1rNem = Zg9FeADE84jSRIvPCrzYulw3sL
	return Zxh5l1rNem
def nHNoV6BMsIPWhxt2FKC(url):
	Zxh5l1rNem = WQCUHyEib1(url)
	hc5ePKxl4LJvEjDgTm = url + '/Home/Live'
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-LIVE-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	JaqiYfEglZDvmwQNS8zR = items[0]
	nTdpZOCUe7l(JaqiYfEglZDvmwQNS8zR,bIPsOxjEpoH,'live')
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'+')
	if showDialogs:
		OS16IiQ5q3rgK4VeML29EHWJwhzo = [ qfzHe2Yr49 , p2tHwDRfg16WJ0IYF5xLXGa9S7us , iHXu7vrG8q , OOSeUghnmsB5Mo8qN4 ]
		Z2fh9I3eLMO = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر اللغة المناسبة:', Z2fh9I3eLMO)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1 : return
		website = OS16IiQ5q3rgK4VeML29EHWJwhzo[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	else:
		if '_IFILM-ARABIC_' in NNYRDot8vC: website = qfzHe2Yr49
		elif '_IFILM-ENGLISH_' in NNYRDot8vC: website = p2tHwDRfg16WJ0IYF5xLXGa9S7us
		else: website = Zg9FeADE84jSRIvPCrzYulw3sL
	if not website: return
	Zxh5l1rNem = WQCUHyEib1(website)
	hc5ePKxl4LJvEjDgTm = website + "/Home/Search?searchstring=" + IGh3FSLfnog2BjN8s
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'IFILM-SEARCH-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		for W8KBRzkdhlCxvF5sY2T,WWdHIOCPeKmgRstXk4c,id,title in items:
			if WWdHIOCPeKmgRstXk4c in ['3','7']:
				title = title.replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
				title = title.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
				if WWdHIOCPeKmgRstXk4c=='3':
					type = 'Series'
					if Zxh5l1rNem=='ar': name = 'مسلسل : '
					elif Zxh5l1rNem=='en': name = 'Series : '
					elif Zxh5l1rNem=='fa': name = 'سريال ها : '
					elif Zxh5l1rNem=='fa2': name = 'سريال ها : '
				elif WWdHIOCPeKmgRstXk4c=='5':
					type = 'Film'
					if Zxh5l1rNem=='ar': name = 'فيلم : '
					elif Zxh5l1rNem=='en': name = 'Movie : '
					elif Zxh5l1rNem=='fa': name = 'فيلم : '
					elif Zxh5l1rNem=='fa2': name = 'فلم ها : '
				elif WWdHIOCPeKmgRstXk4c=='7':
					type = 'Program'
					if Zxh5l1rNem=='ar': name = 'برنامج : '
					elif Zxh5l1rNem=='en': name = 'Program : '
					elif Zxh5l1rNem=='fa': name = 'برنامه ها : '
					elif Zxh5l1rNem=='fa2': name = 'برنامه ها : '
				title = name + title
				yDTPzhEBKVJl7CX81 = website + '/' + type + '/Content/' + id
				W8KBRzkdhlCxvF5sY2T = OJYiDeyvSPTNI9(W8KBRzkdhlCxvF5sY2T)
				W8KBRzkdhlCxvF5sY2T = website+W8KBRzkdhlCxvF5sY2T
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,23,W8KBRzkdhlCxvF5sY2T,'101')
	return
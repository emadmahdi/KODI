# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
import xbmc as Zz9SeICTbPksXy6nuOtLGWhN2V,re as aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ,sys as cbzwJ3rLm0XhR52W7xoqE8Qljk,xbmcaddon as exMAFyUdlHcYb4RSk8I,random as pJ5tI2GD1jSPgdzO7qBuFk60Rni93,os as brAUlZfdFmt3TRJW2xX4,xbmcvfs as PVqhLze0sFTyf,time as LNma2eq3vEguwVtHjn,pickle as kKEliXCwv1DuWNRTb,zlib as aGHUATkRiwgYe0Dzu9d7jWh,xbmcgui as HqjWaYEzp0D8eyQRud,xbmcplugin as j9wel7aIxL2EJn1rTKOXYNCqfMzRhg,sqlite3 as rNIFwicQYy7ZKf4XlzoP9Rj,traceback as CFzcuYA4GMkOi1qXSoLQ2x3Ry,threading as I9IjKTbgiCVvuWJLAB2wP3rXOQ,hashlib as GIWbQnAEXrDLaKHwZcgNhfkFj1,json as lSD9w50N6VBOHbfT2WRiPsM
import XcPLKthYTV
bIPsOxjEpoH = ykE045Tatx(u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧ१")
Zg9FeADE84jSRIvPCrzYulw3sL = E3i1eCBtN2w(u"ࠧࠨ२")
wjs26GpVfNiCUERHJ = JP65RzKaScIf(u"ࠨࠢࠪ३")
F4skx1A3wOEh9lmPuZMnpCzR = wjs26GpVfNiCUERHJ*ttC4VURALPYKh(u"࠵ଫ")
Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J = wjs26GpVfNiCUERHJ*eCpDE6wJtYUHn0GqK5(u"࠷ବ")
z1LI6x7aofZnmb = wjs26GpVfNiCUERHJ*ykE045Tatx(u"࠹ଭ")
CR6in9cZKo2SqGFmrHOLdhYEVTjsBy = DKmLTA2yGtj(u"ࡔࡳࡷࡨ୵")
vvglE69OFKBm817Nkc = ykE045Tatx(u"ࡇࡣ࡯ࡷࡪ୶")
UwCT5Oz6Wo0BP = jozVWcERh91GOF2NHXQiSwKqe8x(u"࠶ମ")
Mn5NGAdz6xc42s0 = dn9ouNryjHiBFQOhASvX(u"࠱ଯ")
DpahB8cwl4ZeKVsg71RuibSAfx0Ejr = jozVWcERh91GOF2NHXQiSwKqe8x(u"࠳ର")
O4dklMvZ8ULcS = qdEKO42r3GhwmCDcHtxzJUR(u"࠵଱")
NEc173Pr0jAwLF5OS = vGg1hAkzqi8exVbN(u"࠷ଲ")
PPQORjT2lc7SVkKwFI4D = eCpDE6wJtYUHn0GqK5(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬ४")
U2bWzwG8VdJsBqtR74ErDi3cg1v = eCpDE6wJtYUHn0GqK5(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭५")
xqPlYeVsWSkB703w9 = wFYiVd4r12x7CAQBL5SPof(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠲ࡆࡅࡉ࠶ࡊࡣࠧ६")
mmJCaDuIX10 = E3i1eCBtN2w(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨ७")
u4IRSmrYMKkaHUBnDiLWh = wFYiVd4r12x7CAQBL5SPof(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ८")
nJ5QfkKIG9C3e7Ozq61MU8Dmhc = lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡶࡶࡩ࠼ࠬ९")
JfQX7SAvVrxZyRDgT = yNBjYsgc23xoW(u"ࠨࡐࡒࡘࡎࡉࡅࠨ॰")
ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9 = JP65RzKaScIf(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨॱ")
C1CRH4W2eukIOP7rjbw6xscQpdDN = dn9ouNryjHiBFQOhASvX(u"ࠪࡉࡗࡘࡏࡓࠩॲ")
ETdv5ONS01nK4Lw6ZC9AXjpiH723P = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩॳ")
SmFfh9kPpeoNBdcV7WnJ1LHMuXZO = KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡢ࡮ࠨॴ")
mqBPGuVIYZbStQejFowJh2 = vhZ5qjay1z94JmcMOgXe(u"࠭࡜ࡳࠩॵ")
SSWrcswxYdB9p = exMAFyUdlHcYb4RSk8I.Addon().getAddonInfo(Vi1oNCM5kI7yJ0(u"ࠧࡱࡣࡷ࡬ࠬॶ"))
Wn2cjhN3Ht04YzUaKAGEBw = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,vGg1hAkzqi8exVbN(u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪॷ"))
cbzwJ3rLm0XhR52W7xoqE8Qljk.path.append(Wn2cjhN3Ht04YzUaKAGEBw)
UP58QEGLitwdp4qBDJozTu6V = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣॸ"))
NGiBmYp8vX9T426lHn7ue = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧॹ"),UP58QEGLitwdp4qBDJozTu6V,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
NGiBmYp8vX9T426lHn7ue = float(NGiBmYp8vX9T426lHn7ue[UwCT5Oz6Wo0BP])
RKcWEHLlzoSdUPNZwa12 = Zz9SeICTbPksXy6nuOtLGWhN2V.Player
j9ldCL3Ibp = HqjWaYEzp0D8eyQRud.WindowXMLDialog
HByjTem6EJP5sZb = NGiBmYp8vX9T426lHn7ue<UixkloZbzGw28ujW56X(u"࠵࠾ଳ")
GGfPQnrJKEqMv2ZVxdD = NGiBmYp8vX9T426lHn7ue>vv3sNE8XCU2RAiyVaueTbD950pz(u"࠶࠾࠮࠺࠻଴")
if GGfPQnrJKEqMv2ZVxdD:
	IG93vr12yp4FdOteTKfB0mwP = Zz9SeICTbPksXy6nuOtLGWhN2V.LOGINFO
	MVtOGEXYcJLSjm4,FEftnphOJQY9dWI5iCoMj43zKbA = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬॺ"),wFYiVd4r12x7CAQBL5SPof(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭ॻ")
	wYm3OK9s420b = PVqhLze0sFTyf.translatePath(qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧॼ"))
	from urllib.parse import unquote as _GcFNMEiHlsbvougqn
else:
	IG93vr12yp4FdOteTKfB0mwP = Zz9SeICTbPksXy6nuOtLGWhN2V.LOGNOTICE
	MVtOGEXYcJLSjm4,FEftnphOJQY9dWI5iCoMj43zKbA = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨॽ").encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc),Vi1oNCM5kI7yJ0(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩॾ").encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	wYm3OK9s420b = Zz9SeICTbPksXy6nuOtLGWhN2V.translatePath(ReLGYUQjz7C9iEd(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪॿ"))
	from urllib import unquote as _GcFNMEiHlsbvougqn
PPAyuG07roL59l2nxNjRYwVkq8 = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠼࠰ଵ")
qJEmpHPg3IWhvS9b5lGC48n0rYs6f = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠶࠱ଶ")*PPAyuG07roL59l2nxNjRYwVkq8
ufANkpln7j9r = YXm2qAbu8Qsx(u"࠳࠶ଷ")*qJEmpHPg3IWhvS9b5lGC48n0rYs6f
xBGrVSeqmvFHQY6MJucNOZsE = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠵࠳ସ")*ufANkpln7j9r
FFP5vTqk3nDlEuGdIy = UwCT5Oz6Wo0BP
Xo8KxLn4tlPM7GWbjwmF = Vi1oNCM5kI7yJ0(u"࠶࠴ହ")*PPAyuG07roL59l2nxNjRYwVkq8
fA1u9wd7EkGBObjDhvWa = DpahB8cwl4ZeKVsg71RuibSAfx0Ejr*qJEmpHPg3IWhvS9b5lGC48n0rYs6f
E8RabFm1Kp5O0s = YXm2qAbu8Qsx(u"࠵࠻଺")*qJEmpHPg3IWhvS9b5lGC48n0rYs6f
ggWsYrlq8fy2v = O4dklMvZ8ULcS*ufANkpln7j9r
uWf6FZMyi2NxL7bYlDCX80RO9pkTB = yyZPkLCRX1xcBDN(u"࠸࠶଻")*ufANkpln7j9r
B4GWT7zonF5yipbIwJmNUf6Vavg = jozVWcERh91GOF2NHXQiSwKqe8x(u"࠷࠲଼")*xBGrVSeqmvFHQY6MJucNOZsE
KeJnzmh3VI4jRfC6Bgy0L = qJEmpHPg3IWhvS9b5lGC48n0rYs6f
Knc8GLhkpePT7xzH3gZtv1jbiEIRAs = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[UwCT5Oz6Wo0BP].split(dn9ouNryjHiBFQOhASvX(u"ࠪ࠳ࠬঀ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
xTMIUH9jL2w4mspJkyrR = int(cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[Mn5NGAdz6xc42s0])
ijrVgHOUMs5Bo0ehTA8FtvcyXJDa = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
F4klMfT7jno0WvH6meq92JKz = Knc8GLhkpePT7xzH3gZtv1jbiEIRAs.split(ttC4VURALPYKh(u"ࠫ࠳࠭ঁ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
kI8qwbo6yER = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(lU1fSmncFWjizwqZugyYBANML0(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬং")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+E3i1eCBtN2w(u"࠭ࠩࠨঃ"))
cc6p0YbTjFzgyG3aRw = brAUlZfdFmt3TRJW2xX4.path.join(wYm3OK9s420b,Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
zfdqH9nKtc3Sy6lbeWDm = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ykE045Tatx(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬ঄"))
UbCmKIdEjMa5lr0 = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,IYC4iPxkTRUE85namF6(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩঅ"))
PPc8zbiVZnFkfXLBRv = int(LNma2eq3vEguwVtHjn.time())
yUTYoAgth5iC43uLrdBH = exMAFyUdlHcYb4RSk8I.Addon(id=Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
fZNGDWOFM9ksEr3jnXT4bPhJdp = yUTYoAgth5iC43uLrdBH.getSetting(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭আ"))
c7cZwUErDWgMbzvl51CVfsXYReA = vvglE69OFKBm817Nkc if fZNGDWOFM9ksEr3jnXT4bPhJdp==kI8qwbo6yER else CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
riaG0KXkbpxm = vvglE69OFKBm817Nkc
def I28IrfmVwu4JkOXhGB(ZTG4ruxXUsc9N,BMRhxlqKtgFC6AUZWe5Tpd0b2rSn=E3i1eCBtN2w(u"ࠪࡃࠬই")):
	if ZYTyoA483N(u"ࠫࡂ࠭ঈ") in ZTG4ruxXUsc9N:
		if BMRhxlqKtgFC6AUZWe5Tpd0b2rSn in ZTG4ruxXUsc9N: hc5ePKxl4LJvEjDgTm,fKC2GqUBrvwITEVnHtFb = ZTG4ruxXUsc9N.split(BMRhxlqKtgFC6AUZWe5Tpd0b2rSn,YXm2qAbu8Qsx(u"࠱ଽ"))
		else: hc5ePKxl4LJvEjDgTm,fKC2GqUBrvwITEVnHtFb = Zg9FeADE84jSRIvPCrzYulw3sL,ZTG4ruxXUsc9N
		fKC2GqUBrvwITEVnHtFb = fKC2GqUBrvwITEVnHtFb.split(wFYiVd4r12x7CAQBL5SPof(u"ࠬࠬࠧউ"))
		mrn4jdBuXKIw7N2lvh = {}
		for yNiCx2TVPJz3MI8GKlwuZ7r6gU5 in fKC2GqUBrvwITEVnHtFb:
			aOf4PbHpSiUm6eGDA1u0ky5wMvdln,qYpW1vyJKaeTI3P7tF0oLXR2r = yNiCx2TVPJz3MI8GKlwuZ7r6gU5.split(ykE045Tatx(u"࠭࠽ࠨঊ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"࠲ା"))
			mrn4jdBuXKIw7N2lvh[aOf4PbHpSiUm6eGDA1u0ky5wMvdln] = qYpW1vyJKaeTI3P7tF0oLXR2r
	else: hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = ZTG4ruxXUsc9N,{}
	return hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh
def rBzf3emckoV5bh7wl4nuastES(Wo5ZqMiTYmSgUCvalXhRer4OjpP7):
	lnrNJVZ9IwBGFX0epSgD,FLqQoZwdAngNkz49RMGUHJXW3bDC,jdnlbaHR952LC = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = Wo5ZqMiTYmSgUCvalXhRer4OjpP7.replace(MVtOGEXYcJLSjm4,Zg9FeADE84jSRIvPCrzYulw3sL).replace(FEftnphOJQY9dWI5iCoMj43zKbA,Zg9FeADE84jSRIvPCrzYulw3sL)
	OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆ࠱࠺ࡆ࠵ࡋࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧঋ"),Wo5ZqMiTYmSgUCvalXhRer4OjpP7,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if OQ1FgC3a5ZLX4unm7Ebx8ji: lnrNJVZ9IwBGFX0epSgD,FLqQoZwdAngNkz49RMGUHJXW3bDC,Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = OQ1FgC3a5ZLX4unm7Ebx8ji[UwCT5Oz6Wo0BP]
	if lnrNJVZ9IwBGFX0epSgD not in [wjs26GpVfNiCUERHJ,A2MHFvoqpZ64gNbB(u"ࠨ࠮ࠪঌ"),Zg9FeADE84jSRIvPCrzYulw3sL]: jdnlbaHR952LC = qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡢࡑࡔࡊ࡟ࠨ঍")
	if FLqQoZwdAngNkz49RMGUHJXW3bDC: FLqQoZwdAngNkz49RMGUHJXW3bDC = JP65RzKaScIf(u"ࠪࡣࠬ঎")+FLqQoZwdAngNkz49RMGUHJXW3bDC+x9PULjztJOpu7b(u"ࠫࡤ࠭এ")
	Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = FLqQoZwdAngNkz49RMGUHJXW3bDC+jdnlbaHR952LC+Wo5ZqMiTYmSgUCvalXhRer4OjpP7
	return Wo5ZqMiTYmSgUCvalXhRer4OjpP7
def UAjMPLdITqWChbrcB(ZTG4ruxXUsc9N):
	return _GcFNMEiHlsbvougqn(ZTG4ruxXUsc9N)
def d2ickGMz45euLXJwAIxs7N(N67eTc8f1n5mCWiq9LElKvyGV):
	mmXFy2JN6lKDA81UjIbCx = {ReLGYUQjz7C9iEd(u"ࠬࡺࡹࡱࡧࠪঐ"):Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"࠭࡭ࡰࡦࡨࠫ঑"):Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠧࡶࡴ࡯ࠫ঒"):Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡶࡨࡼࡹ࠭ও"):Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠩࡳࡥ࡬࡫ࠧঔ"):Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠪࡲࡦࡳࡥࠨক"):Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫ࡮ࡳࡡࡨࡧࠪখ"):Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭গ"):Zg9FeADE84jSRIvPCrzYulw3sL,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨঘ"):Zg9FeADE84jSRIvPCrzYulw3sL}
	if lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡀࠩঙ") in N67eTc8f1n5mCWiq9LElKvyGV: N67eTc8f1n5mCWiq9LElKvyGV = N67eTc8f1n5mCWiq9LElKvyGV.split(x9PULjztJOpu7b(u"ࠨࡁࠪচ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
	hc5ePKxl4LJvEjDgTm,najqRV7ivtl2Q3Z4mTuhcYA = I28IrfmVwu4JkOXhGB(N67eTc8f1n5mCWiq9LElKvyGV)
	aargs = dict(list(mmXFy2JN6lKDA81UjIbCx.items())+list(najqRV7ivtl2Q3Z4mTuhcYA.items()))
	XzDcCO9R4Unv0ZLAYquj1rkbQTlBo = aargs[eCpDE6wJtYUHn0GqK5(u"ࠩࡰࡳࡩ࡫ࠧছ")]
	e096EDGtfOL = UAjMPLdITqWChbrcB(aargs[ReLGYUQjz7C9iEd(u"ࠪࡹࡷࡲࠧজ")])
	rB1I842qHtvMzTusV9K0me5oQ = UAjMPLdITqWChbrcB(aargs[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡹ࡫ࡸࡵࠩঝ")])
	mmRjeA1J7LIdwDina8KSBc4TVUp = UAjMPLdITqWChbrcB(aargs[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡶࡡࡨࡧࠪঞ")])
	AL8Xqj6JN3V7tvkRaI9zT2ewYD = UAjMPLdITqWChbrcB(aargs[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡴࡺࡲࡨࠫট")])
	spmUYd3OZa87BGlf = UAjMPLdITqWChbrcB(aargs[UixkloZbzGw28ujW56X(u"ࠧ࡯ࡣࡰࡩࠬঠ")])
	RP17pN52FxDJYCq = UAjMPLdITqWChbrcB(aargs[NIBsHMvSXb(u"ࠨ࡫ࡰࡥ࡬࡫ࠧড")])
	bnrweaVZ4RKkCIBENzA5S6DMsy81 = aargs[IYC4iPxkTRUE85namF6(u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪঢ")]
	F7tRiquHYKJL48 = UAjMPLdITqWChbrcB(aargs[ZYTyoA483N(u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬণ")])
	if F7tRiquHYKJL48: F7tRiquHYKJL48 = eval(F7tRiquHYKJL48)
	else: F7tRiquHYKJL48 = {}
	if not XzDcCO9R4Unv0ZLAYquj1rkbQTlBo: AL8Xqj6JN3V7tvkRaI9zT2ewYD = DKmLTA2yGtj(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫত") ; XzDcCO9R4Unv0ZLAYquj1rkbQTlBo = dn9ouNryjHiBFQOhASvX(u"ࠬ࠸࠶࠱ࠩথ")
	return AL8Xqj6JN3V7tvkRaI9zT2ewYD,spmUYd3OZa87BGlf,e096EDGtfOL,XzDcCO9R4Unv0ZLAYquj1rkbQTlBo,RP17pN52FxDJYCq,mmRjeA1J7LIdwDina8KSBc4TVUp,rB1I842qHtvMzTusV9K0me5oQ,bnrweaVZ4RKkCIBENzA5S6DMsy81,F7tRiquHYKJL48
def VsYiARtQ2WToMq(bIPsOxjEpoH):
	yC2vqOSmkFD4 = cbzwJ3rLm0XhR52W7xoqE8Qljk._getframe(Mn5NGAdz6xc42s0).f_code.co_name
	if not bIPsOxjEpoH or not yC2vqOSmkFD4 or yC2vqOSmkFD4==yyZPkLCRX1xcBDN(u"࠭࠼࡮ࡱࡧࡹࡱ࡫࠾ࠨদ"):
		return x9PULjztJOpu7b(u"ࠧ࡜ࠢࠪধ")+F4klMfT7jno0WvH6meq92JKz.upper()+IYC4iPxkTRUE85namF6(u"ࠨ࠯ࠪন")+kI8qwbo6yER+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩ࠰ࠫ঩")+str(NGiBmYp8vX9T426lHn7ue)+ykE045Tatx(u"ࠪࠤࡢ࠭প")
	return ZYTyoA483N(u"ࠫ࠳ࡢࡴࠨফ")+yC2vqOSmkFD4
def zOgQjNGH9yk1bXVRnofPvs(IIWAzXmPRLV61lq,vvOzwTgFtar):
	if HByjTem6EJP5sZb: vvOzwTgFtar = vvOzwTgFtar.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	CCEl1J9AS86543RsrZ = IG93vr12yp4FdOteTKfB0mwP
	nRTS1iIwBy0MrzcuXDqH8kOC = [Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL]
	if IIWAzXmPRLV61lq: vvOzwTgFtar = vvOzwTgFtar.replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,Zg9FeADE84jSRIvPCrzYulw3sL).replace(PPQORjT2lc7SVkKwFI4D,Zg9FeADE84jSRIvPCrzYulw3sL).replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)
	else: IIWAzXmPRLV61lq = JfQX7SAvVrxZyRDgT
	fyFeo8zaNMwK1Wu,BMRhxlqKtgFC6AUZWe5Tpd0b2rSn = ttC4VURALPYKh(u"ࠬࡢࡴࠨব"),Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J
	BdAifjEWrcQ = UQS9lVew50DIyXrinWsMxTzA(u"࠷࠶ୀ")*wjs26GpVfNiCUERHJ if GGfPQnrJKEqMv2ZVxdD else Vi1oNCM5kI7yJ0(u"࠵࠴ି")*wjs26GpVfNiCUERHJ
	EAlUKVu5ng2Oyp = NEc173Pr0jAwLF5OS*fyFeo8zaNMwK1Wu
	if vvOzwTgFtar.startswith(JP65RzKaScIf(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧভ")): vvOzwTgFtar = JP65RzKaScIf(u"ࠧ࠯࡞ࡷࠫম")+vvOzwTgFtar
	if C1CRH4W2eukIOP7rjbw6xscQpdDN in IIWAzXmPRLV61lq: CCEl1J9AS86543RsrZ = Zz9SeICTbPksXy6nuOtLGWhN2V.LOGERROR
	if IIWAzXmPRLV61lq in [JfQX7SAvVrxZyRDgT,C1CRH4W2eukIOP7rjbw6xscQpdDN]: nRTS1iIwBy0MrzcuXDqH8kOC = [vvOzwTgFtar]
	elif IIWAzXmPRLV61lq==ETdv5ONS01nK4Lw6ZC9AXjpiH723P: nRTS1iIwBy0MrzcuXDqH8kOC = vvOzwTgFtar.split(BMRhxlqKtgFC6AUZWe5Tpd0b2rSn)
	elif IIWAzXmPRLV61lq==ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9:
		xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = vvOzwTgFtar.split(BMRhxlqKtgFC6AUZWe5Tpd0b2rSn)
		nRTS1iIwBy0MrzcuXDqH8kOC = [xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[UwCT5Oz6Wo0BP]]
		for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(Mn5NGAdz6xc42s0,len(xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL),DpahB8cwl4ZeKVsg71RuibSAfx0Ejr):
			try: E8iGxp7YePCsKRg2QwbmMO0F = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[ZZxHfvyXBmYVjQ9rdAT8RaSKG]+BMRhxlqKtgFC6AUZWe5Tpd0b2rSn+xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[ZZxHfvyXBmYVjQ9rdAT8RaSKG+x9PULjztJOpu7b(u"࠵ୁ")]
			except: E8iGxp7YePCsKRg2QwbmMO0F = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
			nRTS1iIwBy0MrzcuXDqH8kOC.append(E8iGxp7YePCsKRg2QwbmMO0F)
	hXkCKxc1B3wDuRIlesAO = nRTS1iIwBy0MrzcuXDqH8kOC[UwCT5Oz6Wo0BP]
	for zXbvQ6ajdGw1kYI in nRTS1iIwBy0MrzcuXDqH8kOC[Mn5NGAdz6xc42s0:]:
		if IIWAzXmPRLV61lq in [ETdv5ONS01nK4Lw6ZC9AXjpiH723P,ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9]: EAlUKVu5ng2Oyp += fyFeo8zaNMwK1Wu
		hXkCKxc1B3wDuRIlesAO += mqBPGuVIYZbStQejFowJh2+BdAifjEWrcQ+EAlUKVu5ng2Oyp+zXbvQ6ajdGw1kYI
	hXkCKxc1B3wDuRIlesAO += okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࠢࡢࠫয")
	if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࠨࠫর") in hXkCKxc1B3wDuRIlesAO: hXkCKxc1B3wDuRIlesAO = UAjMPLdITqWChbrcB(hXkCKxc1B3wDuRIlesAO)
	Zz9SeICTbPksXy6nuOtLGWhN2V.log(hXkCKxc1B3wDuRIlesAO,level=CCEl1J9AS86543RsrZ)
	return
def KKN3FYextA(w32cbMhWTreVNRq84K):
	KAyrTaiwVmYnCS2NbPp = rNIFwicQYy7ZKf4XlzoP9Rj.connect(w32cbMhWTreVNRq84K,check_same_thread=qdEKO42r3GhwmCDcHtxzJUR(u"ࡈࡤࡰࡸ࡫୷"))
	KAyrTaiwVmYnCS2NbPp.text_factory = str
	wxljEVBYCes0uWnzdZKDbhyI = KAyrTaiwVmYnCS2NbPp.cursor()
	wxljEVBYCes0uWnzdZKDbhyI.execute(UixkloZbzGw28ujW56X(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩ঱"))
	wxljEVBYCes0uWnzdZKDbhyI.execute(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭ল"))
	wxljEVBYCes0uWnzdZKDbhyI.execute(DKmLTA2yGtj(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩ঳"))
	wxljEVBYCes0uWnzdZKDbhyI.execute(eCpDE6wJtYUHn0GqK5(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡳࡺࡰࡦ࡬ࡷࡵ࡮ࡰࡷࡶࡁࡔࡌࡆ࠼ࠩ঴"))
	LUuIzEwBV9Kti6ZXF782 = BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,x9PULjztJOpu7b(u"ࠧࡃࡇࡊࡍࡓࠦࡉࡎࡏࡈࡈࡎࡇࡔࡆࠢࡗࡖࡆࡔࡓࡂࡅࡗࡍࡔࡔࠠ࠼ࠩ঵"))
	if LUuIzEwBV9Kti6ZXF782: KAyrTaiwVmYnCS2NbPp.commit()
	else:
		import V1VREBsj92
		V1VREBsj92.I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫশ"),JP65RzKaScIf(u"ࠩส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํืฯิฯๆࠢส่๊๊แࠡษ็าฬ฻ࠠษไส฽ิฯࠠษ์ส๊ฬะ็ࠡ࠰࠱ࠤํูศษ๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣ๎่๎ๆࠡษ็าึ๎ฬࠡ็้ࠤฬ๊ศา่ส้ัࠦศึ๊ิอࠥเ๊าุࠢั๏ำษࠡ࡞ࡱࡠࡳࠦไฮๆࠣห้๋ิไๆฬࠤัืศࠡวฺๅฬวࠠไ๊า๎ࠥ๎ลฺษาอࠥะิ฻์็๋ࠥ࠴࠮ࠡล๋ࠤัืศࠡวฺๅฬวࠠศๆฯ๋ฬุ้ࠠว฼หิฯࠠหึ฽๎้ํࠧষ"))
		Sma2pEt5wTK()
	return KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI
def BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,Rd4IAvxuO8pXUVt37D5k2,XNhPd0O1gU4yntE3cVbvL2SkmKj9G,siMoVJyUI6BmfEFbr2R1cGwhl=()):
	try:
		if Rd4IAvxuO8pXUVt37D5k2: wxljEVBYCes0uWnzdZKDbhyI.executemany(XNhPd0O1gU4yntE3cVbvL2SkmKj9G,siMoVJyUI6BmfEFbr2R1cGwhl)
		else: wxljEVBYCes0uWnzdZKDbhyI.execute(XNhPd0O1gU4yntE3cVbvL2SkmKj9G,siMoVJyUI6BmfEFbr2R1cGwhl)
		KAyrTaiwVmYnCS2NbPp.commit()
		LUuIzEwBV9Kti6ZXF782 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	except:
		LUuIzEwBV9Kti6ZXF782,timeout = vvglE69OFKBm817Nkc,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠺ୂ")
		aahTvKy1FeXbGBkAqM7wNxt8 = LNma2eq3vEguwVtHjn.time()
		while LNma2eq3vEguwVtHjn.time()-aahTvKy1FeXbGBkAqM7wNxt8<timeout and not LUuIzEwBV9Kti6ZXF782:
			try:
				if Rd4IAvxuO8pXUVt37D5k2: wxljEVBYCes0uWnzdZKDbhyI.executemany(XNhPd0O1gU4yntE3cVbvL2SkmKj9G,siMoVJyUI6BmfEFbr2R1cGwhl)
				else: wxljEVBYCes0uWnzdZKDbhyI.execute(XNhPd0O1gU4yntE3cVbvL2SkmKj9G,siMoVJyUI6BmfEFbr2R1cGwhl)
				KAyrTaiwVmYnCS2NbPp.commit()
				LUuIzEwBV9Kti6ZXF782 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			except: LNma2eq3vEguwVtHjn.sleep(UQS9lVew50DIyXrinWsMxTzA(u"࠶࠮࠳࠷ୃ"))
		if not LUuIzEwBV9Kti6ZXF782:
			zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,x9PULjztJOpu7b(u"ࠪ࠲ࡡࡺࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡺࡶ࡮ࡺࡥࠡࡶࡲࠤࡹ࡮ࡥࠡࡦࡤࡸࡦࡨࡡࡴࡧࠣࡪ࡮ࡲࡥࠡࠢࠣࠫস")+w32cbMhWTreVNRq84K+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡸࡪࡨࡲࠥ࡫ࡸࡦࡥࡸࡸ࡮ࡴࡧࠡࡶ࡫࡭ࡸࠦࡳࡵࡣࡷࡩࡲ࡫࡮ࡵࠢࠣࠤࠬহ")+XNhPd0O1gU4yntE3cVbvL2SkmKj9G+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
			import V1VREBsj92
			V1VREBsj92.ZXWeI01flR(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬ็ิๅࠢไ๎่ࠥวฺัฬࠤฬ๊ศ๋ษ้หฯ࠭঺"),dn9ouNryjHiBFQOhASvX(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧ঻"))
	return LUuIzEwBV9Kti6ZXF782
def zZlsxj57ThCH(w32cbMhWTreVNRq84K,LwhdPNZ37p9clMKn,xMT04CeUz8XR,jUfNmT1JRdqPEsKeuaC=None):
	WR7gIlwo5ik9zJv3CK4sS = vXOBA3MN5D1WUzK2JjLS0ycxhIFd(LwhdPNZ37p9clMKn)
	csmodNjArLZfC1v8PuKxU2Tg36JpI = yUTYoAgth5iC43uLrdBH.getSetting(A2MHFvoqpZ64gNbB(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ়࠭"))
	if xMT04CeUz8XR not in [yNBjYsgc23xoW(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫঽ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡅࡑࡒࠧা"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡌࡕࡏࡈࡎࡈࠫি")] and w32cbMhWTreVNRq84K==zfdqH9nKtc3Sy6lbeWDm and jUfNmT1JRdqPEsKeuaC!=ykE045Tatx(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ী"):
		if csmodNjArLZfC1v8PuKxU2Tg36JpI==IK4zTnSMyGQpxEaesJAPVDY(u"࡙ࠬࡔࡐࡒࠪু"): return WR7gIlwo5ik9zJv3CK4sS
		eemiN1oSxUJ = yUTYoAgth5iC43uLrdBH.getSetting(E3i1eCBtN2w(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪূ"))
		if eemiN1oSxUJ==NIBsHMvSXb(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧৃ"):
			nnWvBsbfxdHYJNLPAct(w32cbMhWTreVNRq84K,xMT04CeUz8XR,jUfNmT1JRdqPEsKeuaC)
			return WR7gIlwo5ik9zJv3CK4sS
	HHVUPcmZBly6wTiWY = UwCT5Oz6Wo0BP
	if csmodNjArLZfC1v8PuKxU2Tg36JpI==wFYiVd4r12x7CAQBL5SPof(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩৄ"): HHVUPcmZBly6wTiWY = KeJnzmh3VI4jRfC6Bgy0L
	KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI = KKN3FYextA(w32cbMhWTreVNRq84K)
	ItcqGJSrsOzmyeVU9gKPpH3u58M = wxljEVBYCes0uWnzdZKDbhyI.execute(ZYTyoA483N(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡱࡥࡲ࡫ࠠࡇࡔࡒࡑࠥࡹࡱ࡭࡫ࡷࡩࡤࡳࡡࡴࡶࡨࡶࠥ࡝ࡈࡆࡔࡈࠤࡹࡿࡰࡦ࠿ࠥࡸࡦࡨ࡬ࡦࠤࠣࡅࡓࡊࠠ࡯ࡣࡰࡩࡂࠨࠧ৅")+xMT04CeUz8XR+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࠦࠥࡁࠧ৆")).fetchall()
	if ItcqGJSrsOzmyeVU9gKPpH3u58M:
		if HHVUPcmZBly6wTiWY: BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,Vi1oNCM5kI7yJ0(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫে")+xMT04CeUz8XR+yNBjYsgc23xoW(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡄࠧৈ")+str(PPc8zbiVZnFkfXLBRv+HHVUPcmZBly6wTiWY)+x9PULjztJOpu7b(u"࠭ࠠ࠼ࠩ৉"))
		BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,ykE045Tatx(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ৊")+xMT04CeUz8XR+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺ࠾ࠪো")+str(PPc8zbiVZnFkfXLBRv)+ZYTyoA483N(u"ࠩࠣ࠿ࠬৌ"))
		if jUfNmT1JRdqPEsKeuaC:
			oEgy0KjTY7N1GBP = (str(jUfNmT1JRdqPEsKeuaC),)
			wxljEVBYCes0uWnzdZKDbhyI.execute(vhZ5qjay1z94JmcMOgXe(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ্")+xMT04CeUz8XR+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫৎ"),oEgy0KjTY7N1GBP)
			eyGQZ6IzfoLwHdJajxUgC4ROW2pP = wxljEVBYCes0uWnzdZKDbhyI.fetchall()
			if eyGQZ6IzfoLwHdJajxUgC4ROW2pP:
				try:
					xQXoDIqn4Ucsthb2G7YpzwPTymi = aGHUATkRiwgYe0Dzu9d7jWh.decompress(eyGQZ6IzfoLwHdJajxUgC4ROW2pP[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP])
					WR7gIlwo5ik9zJv3CK4sS = kKEliXCwv1DuWNRTb.loads(xQXoDIqn4Ucsthb2G7YpzwPTymi)
				except: pass
		else:
			wxljEVBYCes0uWnzdZKDbhyI.execute(vhZ5qjay1z94JmcMOgXe(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠤࠪ৏")+xMT04CeUz8XR+A2MHFvoqpZ64gNbB(u"࠭ࠢࠡ࠽ࠪ৐"))
			eyGQZ6IzfoLwHdJajxUgC4ROW2pP = wxljEVBYCes0uWnzdZKDbhyI.fetchall()
			if eyGQZ6IzfoLwHdJajxUgC4ROW2pP:
				WR7gIlwo5ik9zJv3CK4sS,LnB8jCozyXx73McGrDdOh2E = {},[]
				for Ge4rI6zZ83HkogRmDQ9,mrn4jdBuXKIw7N2lvh in eyGQZ6IzfoLwHdJajxUgC4ROW2pP:
					tKDGiWXJhlvcV14wr3E = aGHUATkRiwgYe0Dzu9d7jWh.decompress(mrn4jdBuXKIw7N2lvh)
					mrn4jdBuXKIw7N2lvh = kKEliXCwv1DuWNRTb.loads(tKDGiWXJhlvcV14wr3E)
					WR7gIlwo5ik9zJv3CK4sS[Ge4rI6zZ83HkogRmDQ9] = mrn4jdBuXKIw7N2lvh
					LnB8jCozyXx73McGrDdOh2E.append(Ge4rI6zZ83HkogRmDQ9)
				if LnB8jCozyXx73McGrDdOh2E:
					WR7gIlwo5ik9zJv3CK4sS[JP65RzKaScIf(u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ৑")] = LnB8jCozyXx73McGrDdOh2E
					if LwhdPNZ37p9clMKn==UQS9lVew50DIyXrinWsMxTzA(u"ࠨ࡮࡬ࡷࡹ࠭৒"): WR7gIlwo5ik9zJv3CK4sS = LnB8jCozyXx73McGrDdOh2E
	KAyrTaiwVmYnCS2NbPp.close()
	return WR7gIlwo5ik9zJv3CK4sS
def cb76opH5VXk2fjWqzExS0yTBGsen(w32cbMhWTreVNRq84K,xMT04CeUz8XR,jUfNmT1JRdqPEsKeuaC,WR7gIlwo5ik9zJv3CK4sS,PPQvsXBcDj,wPk6TUiE3rotMKzh2W4a5yjufq=vvglE69OFKBm817Nkc):
	csmodNjArLZfC1v8PuKxU2Tg36JpI = yUTYoAgth5iC43uLrdBH.getSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ৓"))
	if csmodNjArLZfC1v8PuKxU2Tg36JpI==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ৔") and PPQvsXBcDj>KeJnzmh3VI4jRfC6Bgy0L: PPQvsXBcDj = KeJnzmh3VI4jRfC6Bgy0L
	if wPk6TUiE3rotMKzh2W4a5yjufq:
		nnm3Asbhj8z4IDdSXMC1Vx,LnFEqM9SgCd = [],[]
		for OEJ3PT81KtbZ in range(len(jUfNmT1JRdqPEsKeuaC)):
			xQXoDIqn4Ucsthb2G7YpzwPTymi = kKEliXCwv1DuWNRTb.dumps(WR7gIlwo5ik9zJv3CK4sS[OEJ3PT81KtbZ])
			DqLC75xXnBYyGd2Q = aGHUATkRiwgYe0Dzu9d7jWh.compress(xQXoDIqn4Ucsthb2G7YpzwPTymi)
			nnm3Asbhj8z4IDdSXMC1Vx.append((jUfNmT1JRdqPEsKeuaC[OEJ3PT81KtbZ],))
			LnFEqM9SgCd.append((PPQvsXBcDj+PPc8zbiVZnFkfXLBRv,str(jUfNmT1JRdqPEsKeuaC[OEJ3PT81KtbZ]),DqLC75xXnBYyGd2Q))
	else:
		xQXoDIqn4Ucsthb2G7YpzwPTymi = kKEliXCwv1DuWNRTb.dumps(WR7gIlwo5ik9zJv3CK4sS)
		PJU0dt4TlqbI = aGHUATkRiwgYe0Dzu9d7jWh.compress(xQXoDIqn4Ucsthb2G7YpzwPTymi)
	KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI = KKN3FYextA(w32cbMhWTreVNRq84K)
	BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,yyZPkLCRX1xcBDN(u"ࠫࡈࡘࡅࡂࡖࡈࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡎࡐࡖࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬ৕")+xMT04CeUz8XR+DKmLTA2yGtj(u"ࠬࠨࠠࠩࡧࡻࡴ࡮ࡸࡹ࠭ࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦ࠯ࠠ࠼ࠩ৖"))
	if wPk6TUiE3rotMKzh2W4a5yjufq:
		BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,ReLGYUQjz7C9iEd(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ৗ")+xMT04CeUz8XR+IYC4iPxkTRUE85namF6(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ৘"),nnm3Asbhj8z4IDdSXMC1Vx)
		BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ৙")+xMT04CeUz8XR+vGg1hAkzqi8exVbN(u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ৚"),LnFEqM9SgCd)
	else:
		if PPQvsXBcDj:
			oEgy0KjTY7N1GBP = (str(jUfNmT1JRdqPEsKeuaC),)
			BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ৛")+xMT04CeUz8XR+NIBsHMvSXb(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫড়"),oEgy0KjTY7N1GBP)
			oEgy0KjTY7N1GBP = (PPQvsXBcDj+PPc8zbiVZnFkfXLBRv,str(jUfNmT1JRdqPEsKeuaC),PJU0dt4TlqbI)
			BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬঢ়")+xMT04CeUz8XR+UQS9lVew50DIyXrinWsMxTzA(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ৞"),oEgy0KjTY7N1GBP)
		else:
			oEgy0KjTY7N1GBP = (PJU0dt4TlqbI,str(jUfNmT1JRdqPEsKeuaC))
			BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࠣࠩয়")+xMT04CeUz8XR+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠤࠣࡗࡊ࡚ࠠࡥࡣࡷࡥࠥࡃࠠࡀ࡚ࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧৠ"),oEgy0KjTY7N1GBP)
	KAyrTaiwVmYnCS2NbPp.close()
	return
def nnWvBsbfxdHYJNLPAct(w32cbMhWTreVNRq84K,xMT04CeUz8XR,jUfNmT1JRdqPEsKeuaC=None):
	KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI = KKN3FYextA(w32cbMhWTreVNRq84K)
	if jUfNmT1JRdqPEsKeuaC==None: BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,eCpDE6wJtYUHn0GqK5(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫৡ")+xMT04CeUz8XR+ykE045Tatx(u"ࠪࠦࠥࡁࠧৢ"))
	else:
		ItcqGJSrsOzmyeVU9gKPpH3u58M = wxljEVBYCes0uWnzdZKDbhyI.execute(NIBsHMvSXb(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡳࡧ࡭ࡦࠢࡉࡖࡔࡓࠠࡴࡳ࡯࡭ࡹ࡫࡟࡮ࡣࡶࡸࡪࡸࠠࡘࡊࡈࡖࡊࠦࡴࡺࡲࡨࡁࠧࡺࡡࡣ࡮ࡨࠦࠥࡇࡎࡅࠢࡱࡥࡲ࡫࠽ࠣࠩৣ")+xMT04CeUz8XR+A2MHFvoqpZ64gNbB(u"ࠬࠨࠠ࠼ࠩ৤")).fetchall()
		if ItcqGJSrsOzmyeVU9gKPpH3u58M:
			oEgy0KjTY7N1GBP = (str(jUfNmT1JRdqPEsKeuaC),)
			if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࠥࠨ৥") in jUfNmT1JRdqPEsKeuaC: BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,UixkloZbzGw28ujW56X(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ০")+xMT04CeUz8XR+NIBsHMvSXb(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫ১"),oEgy0KjTY7N1GBP)
			else: BuVJkW4DZN(w32cbMhWTreVNRq84K,KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI,vvglE69OFKBm817Nkc,x9PULjztJOpu7b(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ২")+xMT04CeUz8XR+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৩"),oEgy0KjTY7N1GBP)
	KAyrTaiwVmYnCS2NbPp.close()
	return
class QG9OhJv2ugdF1xIzk6Yy(): pass
class dA2JDHpu6O0kGt7M1fY4aVQbBKn(QG9OhJv2ugdF1xIzk6Yy):
	def __init__(aFldbEymq0z6HUQcXK7Cr51):
		aFldbEymq0z6HUQcXK7Cr51.url = Zg9FeADE84jSRIvPCrzYulw3sL
		aFldbEymq0z6HUQcXK7Cr51.code = -ttC4VURALPYKh(u"࠹࠺ୄ")
		aFldbEymq0z6HUQcXK7Cr51.reason = Zg9FeADE84jSRIvPCrzYulw3sL
		aFldbEymq0z6HUQcXK7Cr51.content = Zg9FeADE84jSRIvPCrzYulw3sL
		aFldbEymq0z6HUQcXK7Cr51.headers = {}
		aFldbEymq0z6HUQcXK7Cr51.cookies = {}
		aFldbEymq0z6HUQcXK7Cr51.succeeded = vvglE69OFKBm817Nkc
def vXOBA3MN5D1WUzK2JjLS0ycxhIFd(TeDLBxpO03aonZFfQbNuK9S):
	if TeDLBxpO03aonZFfQbNuK9S==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡩ࡯ࡣࡵࠩ৪"): WR7gIlwo5ik9zJv3CK4sS = {}
	elif TeDLBxpO03aonZFfQbNuK9S==vGg1hAkzqi8exVbN(u"ࠬࡲࡩࡴࡶࠪ৫"): WR7gIlwo5ik9zJv3CK4sS = []
	elif TeDLBxpO03aonZFfQbNuK9S==lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡴࡶࡲ࡯ࡩࠬ৬"): WR7gIlwo5ik9zJv3CK4sS = ()
	elif TeDLBxpO03aonZFfQbNuK9S==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡴࡶࡵࠫ৭"): WR7gIlwo5ik9zJv3CK4sS = Zg9FeADE84jSRIvPCrzYulw3sL
	elif TeDLBxpO03aonZFfQbNuK9S==UixkloZbzGw28ujW56X(u"ࠨ࡫ࡱࡸࠬ৮"): WR7gIlwo5ik9zJv3CK4sS = UwCT5Oz6Wo0BP
	elif TeDLBxpO03aonZFfQbNuK9S==UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ৯"): WR7gIlwo5ik9zJv3CK4sS = dA2JDHpu6O0kGt7M1fY4aVQbBKn()
	elif not TeDLBxpO03aonZFfQbNuK9S: WR7gIlwo5ik9zJv3CK4sS = None
	else: WR7gIlwo5ik9zJv3CK4sS = None
	return WR7gIlwo5ik9zJv3CK4sS
def ZE3oYw0NMipGVt1zJ8yAULgq7nbdx(nJU3VO0tZ1iqhNy6GYDMXcFmk):
	NNkoD9s0RiTbMl6c1u = yUTYoAgth5iC43uLrdBH.getSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ৰ"))
	JJb5DwBiqHemoygZ1j3VERXM = fs60XkagtWFJ.splitlines()
	FkolLW18Vt3bS2iU9jPTKf = UwCT5Oz6Wo0BP
	OmyQoW6Gkh2sx = len(nJU3VO0tZ1iqhNy6GYDMXcFmk)
	TTKgIZWHL0Aw72 = [vvglE69OFKBm817Nkc]*OmyQoW6Gkh2sx
	for OIExfFoS5NkYdq in [PPc8zbiVZnFkfXLBRv,PPc8zbiVZnFkfXLBRv-fA1u9wd7EkGBObjDhvWa]:
		Ia8BzAiwS9NCrbu7p0tRHqhojcl = str(OIExfFoS5NkYdq*Vi1oNCM5kI7yJ0(u"࠳࠳࠴࠵࠶࠰࠯࠲୆")/vv3sNE8XCU2RAiyVaueTbD950pz(u"࠵࠵࠵࠴࠵࠶୅"))[UwCT5Oz6Wo0BP:IK4zTnSMyGQpxEaesJAPVDY(u"࠷େ")]
		if Ia8BzAiwS9NCrbu7p0tRHqhojcl!=FkolLW18Vt3bS2iU9jPTKf:
			for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(OmyQoW6Gkh2sx):
				if not TTKgIZWHL0Aw72[ZZxHfvyXBmYVjQ9rdAT8RaSKG]:
					ScVZNf7CoTk6PD4A = vvglE69OFKBm817Nkc
					for bpGIsMZ16fCWvUa3iROAchJL in JJb5DwBiqHemoygZ1j3VERXM:
						kZiDBgTdG81 = DKmLTA2yGtj(u"ࠫ࡝࠷࠹ࠨৱ")+nJU3VO0tZ1iqhNy6GYDMXcFmk[ZZxHfvyXBmYVjQ9rdAT8RaSKG]+Vi1oNCM5kI7yJ0(u"ࠬ࠷࠸࠾ࠩ৲")+bpGIsMZ16fCWvUa3iROAchJL[-ee3tnwl7avk(u"࠶࠹ୈ"):]+kI8qwbo6yER+Ia8BzAiwS9NCrbu7p0tRHqhojcl
						kZiDBgTdG81 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(kZiDBgTdG81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()[:yNBjYsgc23xoW(u"࠸࠸୉")]
						if kZiDBgTdG81 in NNkoD9s0RiTbMl6c1u:
							ScVZNf7CoTk6PD4A = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
							break
					TTKgIZWHL0Aw72[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = ScVZNf7CoTk6PD4A
		FkolLW18Vt3bS2iU9jPTKf = Ia8BzAiwS9NCrbu7p0tRHqhojcl
	return TTKgIZWHL0Aw72
class c6orXChaFMiG8DKYyjs03dfWBVQA(RKcWEHLlzoSdUPNZwa12):
	def __init__(aFldbEymq0z6HUQcXK7Cr51): pass
	def Y6TXlktz0yFfgMqKj7(aFldbEymq0z6HUQcXK7Cr51,UlT5rR4SO0LNYvyu2eCk3cZM96s):
		aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = yNBjYsgc23xoW(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ৳") if XcPLKthYTV.zyKW1Eow48ek0 else Zg9FeADE84jSRIvPCrzYulw3sL
		aFldbEymq0z6HUQcXK7Cr51.UlT5rR4SO0LNYvyu2eCk3cZM96s = UlT5rR4SO0LNYvyu2eCk3cZM96s
		if not XcPLKthYTV.dMeaPykZB3Ln8DGuS:
			import V1VREBsj92
			V1VREBsj92.HsN3gRJ1Z9ahWqTPwj(Xo8KxLn4tlPM7GWbjwmF)
	def onPlayBackStopped(aFldbEymq0z6HUQcXK7Cr51): aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = A2MHFvoqpZ64gNbB(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ৴")
	def onPlayBackError(aFldbEymq0z6HUQcXK7Cr51): aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = ykE045Tatx(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ৵")
	def onPlayBackEnded(aFldbEymq0z6HUQcXK7Cr51): aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ৶")
	def onPlayBackStarted(aFldbEymq0z6HUQcXK7Cr51):
		aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = wFYiVd4r12x7CAQBL5SPof(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ৷")
		QcO5GzTt4k1VE329dgSPpj8fvZJHn = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=aFldbEymq0z6HUQcXK7Cr51.tJdZKhkjsxD,args=())
		QcO5GzTt4k1VE329dgSPpj8fvZJHn.start()
	def onAVStarted(aFldbEymq0z6HUQcXK7Cr51):
		if XcPLKthYTV.dMeaPykZB3Ln8DGuS: aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = JP65RzKaScIf(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ৸")
		else: aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = A2MHFvoqpZ64gNbB(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭৹")
	def tJdZKhkjsxD(aFldbEymq0z6HUQcXK7Cr51):
		LpTv52e4Icnwms0OXRW6oACix(ttC4VURALPYKh(u"࠭ࡳࡵࡱࡳࠫ৺"))
		SSsWzf6qXtDA = UwCT5Oz6Wo0BP
		while not eval(E3i1eCBtN2w(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬ৻"),{A2MHFvoqpZ64gNbB(u"ࠨࡺࡥࡱࡨ࠭ৼ"):Zz9SeICTbPksXy6nuOtLGWhN2V}) and aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg==vhZ5qjay1z94JmcMOgXe(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ৽"):
			Zz9SeICTbPksXy6nuOtLGWhN2V.sleep(UixkloZbzGw28ujW56X(u"࠷࠰࠱࠲୊"))
			SSsWzf6qXtDA += Mn5NGAdz6xc42s0
			if SSsWzf6qXtDA>ttC4VURALPYKh(u"࠶࠱ୋ"): return
		if XcPLKthYTV.zyKW1Eow48ek0: aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৾")
		elif XcPLKthYTV.dMeaPykZB3Ln8DGuS: aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = ttC4VURALPYKh(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ৿")
		elif XcPLKthYTV.BdihkDomH03OAKgcaCM:
			import V1VREBsj92
			aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = DKmLTA2yGtj(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭਀")
			K2mcVPqMYAJl6tpZOWQTLyusFUwh8 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=V1VREBsj92.L8YzQPxF9OjJ6G,args=(aFldbEymq0z6HUQcXK7Cr51.UlT5rR4SO0LNYvyu2eCk3cZM96s,))
			K2mcVPqMYAJl6tpZOWQTLyusFUwh8.start()
			XvkhMyzRF5CuSgtmaOUQbB2iH = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=V1VREBsj92.Vhwb3zUBZ18qNM7Evp4sIyRAf,args=())
			XvkhMyzRF5CuSgtmaOUQbB2iH.start()
		else: aFldbEymq0z6HUQcXK7Cr51.ff6oGwZFLOkpdNCryg = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧਁ")
def vsWVM3TRcpn1P0tZ5SJ():
	cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	ooeXQmtlbKqLdH4E = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭ਂ"))
	try:
		rmHRBGtzcMjwCyNEUed1k6W = open(qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨਃ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡵࡦࠬ਄")).read()
		if GGfPQnrJKEqMv2ZVxdD: rmHRBGtzcMjwCyNEUed1k6W = rmHRBGtzcMjwCyNEUed1k6W.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		cpH6JgjEx4BiTaokVY2P3 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ZYTyoA483N(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧਅ"),rmHRBGtzcMjwCyNEUed1k6W,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if cpH6JgjEx4BiTaokVY2P3: cmXHJysLOjIt81epu4F5P = cpH6JgjEx4BiTaokVY2P3[UwCT5Oz6Wo0BP]
	except: pass
	try:
		import subprocess as nr0q4U2vgwCY3b
		t0tnfbmTohLaFP7JMDVZEX2 = nr0q4U2vgwCY3b.Popen(lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩਆ"),shell=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,stdin=nr0q4U2vgwCY3b.PIPE,stdout=nr0q4U2vgwCY3b.PIPE,stderr=nr0q4U2vgwCY3b.PIPE)
		oHkCq7bisyzj0WO = t0tnfbmTohLaFP7JMDVZEX2.stdout.read()
		if oHkCq7bisyzj0WO:
			if GGfPQnrJKEqMv2ZVxdD:
				oHkCq7bisyzj0WO = oHkCq7bisyzj0WO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,UQS9lVew50DIyXrinWsMxTzA(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬਇ"))
			l37lsotCWgEbu0PieON12Bk4a8mML = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(DKmLTA2yGtj(u"࠭ࠠࠩ࡞ࡧࡿ࠶࠶ࡽࠪࠢࠪਈ"),oHkCq7bisyzj0WO,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
			if l37lsotCWgEbu0PieON12Bk4a8mML: UJ9ysXOWw4lPbz3Ftq12vZ = min(l37lsotCWgEbu0PieON12Bk4a8mML)
	except: pass
	return ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ
def EELfq0dKnyhZPxpA2jJrFsvXU(ydZJfMI90bRSc=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,b6pDh28nQRtHylFIf5C=IYC4iPxkTRUE85namF6(u"࠴࠴ୌ")):
	TWeNJX7vOF8 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if ydZJfMI90bRSc:
		M4adL7ifmGsVWFpYN = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,yNBjYsgc23xoW(u"ࠧ࡭࡫ࡶࡸࠬਉ"),JP65RzKaScIf(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਊ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ਋"))
		if M4adL7ifmGsVWFpYN:
			JJb5DwBiqHemoygZ1j3VERXM,pUg1TSvXbNlC4k,R8SoOj0bwPIalxmipJ4FztnUkNyr,uugRmbJE3rAylF6x0KUfatIqhs = M4adL7ifmGsVWFpYN
			TWeNJX7vOF8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡰ࡮ࡹࡴࠨ਌"),JP65RzKaScIf(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ਍"),ttC4VURALPYKh(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫ਎"))
			if TWeNJX7vOF8: ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ = TWeNJX7vOF8
			else: ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ = vsWVM3TRcpn1P0tZ5SJ()
			if (pUg1TSvXbNlC4k,R8SoOj0bwPIalxmipJ4FztnUkNyr,uugRmbJE3rAylF6x0KUfatIqhs)==(ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ): return SmFfh9kPpeoNBdcV7WnJ1LHMuXZO.join(JJb5DwBiqHemoygZ1j3VERXM)
	if TWeNJX7vOF8: ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ = vsWVM3TRcpn1P0tZ5SJ()
	global iwVx2HZ6S7h,wwxcg2OtQXi7a9qY4eNo1MSuTU
	iwVx2HZ6S7h,wwxcg2OtQXi7a9qY4eNo1MSuTU,CTDbWOXS2F = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	b6pDh28nQRtHylFIf5C = b6pDh28nQRtHylFIf5C//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
	I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=RvLCTts24j).start()
	I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=kkHhqdEfxTS8uYLobyZG23jt).start()
	for OEJ3PT81KtbZ in range(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠳࠳୍")):
		LNma2eq3vEguwVtHjn.sleep(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠳࠲࠺୎"))
		if not CTDbWOXS2F:
			try:
				NHC6fkAJGEQI5smbq08leTP2c3 = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(YXm2qAbu8Qsx(u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡎࡣࡦࡅࡩࡪࡲࡦࡵࡶࠫਏ"))
				if NHC6fkAJGEQI5smbq08leTP2c3.count(eCpDE6wJtYUHn0GqK5(u"ࠧ࠻ࠩਐ"))==qdEKO42r3GhwmCDcHtxzJUR(u"࠺୐") and NHC6fkAJGEQI5smbq08leTP2c3.count(E3i1eCBtN2w(u"ࠨ࠲ࠪ਑"))<KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠽୏"):
					NHC6fkAJGEQI5smbq08leTP2c3 = NHC6fkAJGEQI5smbq08leTP2c3.lower().replace(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࠽ࠫ਒"),Zg9FeADE84jSRIvPCrzYulw3sL)
					CTDbWOXS2F = str(int(NHC6fkAJGEQI5smbq08leTP2c3,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠷࠶୑")))
			except: pass
		if iwVx2HZ6S7h and wwxcg2OtQXi7a9qY4eNo1MSuTU and CTDbWOXS2F: break
	OrbfBlQA2k5StNHoY = [iwVx2HZ6S7h,wwxcg2OtQXi7a9qY4eNo1MSuTU,CTDbWOXS2F,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭ਓ")]
	if cmXHJysLOjIt81epu4F5P or UJ9ysXOWw4lPbz3Ftq12vZ:
		Nvs7xTHQ6U9 = [(NEc173Pr0jAwLF5OS,cmXHJysLOjIt81epu4F5P),(eCpDE6wJtYUHn0GqK5(u"࠵୒"),UJ9ysXOWw4lPbz3Ftq12vZ)]
		for aOf4PbHpSiUm6eGDA1u0ky5wMvdln,qYpW1vyJKaeTI3P7tF0oLXR2r in Nvs7xTHQ6U9:
			qYpW1vyJKaeTI3P7tF0oLXR2r = qYpW1vyJKaeTI3P7tF0oLXR2r.strip(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࠵࠭ਔ"))
			if qYpW1vyJKaeTI3P7tF0oLXR2r:
				if GGfPQnrJKEqMv2ZVxdD: qYpW1vyJKaeTI3P7tF0oLXR2r = qYpW1vyJKaeTI3P7tF0oLXR2r.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				qYpW1vyJKaeTI3P7tF0oLXR2r = str(int(GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(qYpW1vyJKaeTI3P7tF0oLXR2r).hexdigest(),vhZ5qjay1z94JmcMOgXe(u"࠴࠸୓")))
				vJL7xe0VMXkDrEG = [int(qYpW1vyJKaeTI3P7tF0oLXR2r[fVcTxBoEpAtMFbWvmrYwk:fVcTxBoEpAtMFbWvmrYwk+eCpDE6wJtYUHn0GqK5(u"࠴࠹୕")]) for fVcTxBoEpAtMFbWvmrYwk in range(len(qYpW1vyJKaeTI3P7tF0oLXR2r)) if fVcTxBoEpAtMFbWvmrYwk%eCpDE6wJtYUHn0GqK5(u"࠴࠹୕")==ReLGYUQjz7C9iEd(u"࠲୔")]
				OrbfBlQA2k5StNHoY[aOf4PbHpSiUm6eGDA1u0ky5wMvdln-Mn5NGAdz6xc42s0] = str(sum(vJL7xe0VMXkDrEG))
	JJb5DwBiqHemoygZ1j3VERXM,PNpmRbU0YOx1vakn5g8Dloi = [],vvglE69OFKBm817Nkc
	for O0CSjitXBmxcUMyHPKfRYQg in range(len(OrbfBlQA2k5StNHoY)):
		vJL7xe0VMXkDrEG = OrbfBlQA2k5StNHoY[O0CSjitXBmxcUMyHPKfRYQg]
		if not vJL7xe0VMXkDrEG: continue
		if PNpmRbU0YOx1vakn5g8Dloi and vJL7xe0VMXkDrEG==OrbfBlQA2k5StNHoY[-Mn5NGAdz6xc42s0]: continue
		PNpmRbU0YOx1vakn5g8Dloi = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		vJL7xe0VMXkDrEG = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠶ࠧਕ")*b6pDh28nQRtHylFIf5C+vJL7xe0VMXkDrEG
		vJL7xe0VMXkDrEG = vJL7xe0VMXkDrEG[-b6pDh28nQRtHylFIf5C:]
		SUVExcikXWmsjp8,TTr8du7QSAO9elCp = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
		arlmjP5YVtBkRJoKGu6EL = str(int(ee3tnwl7avk(u"࠭࠹ࠨਖ")*(b6pDh28nQRtHylFIf5C+Mn5NGAdz6xc42s0))-int(vJL7xe0VMXkDrEG))[-b6pDh28nQRtHylFIf5C:]
		for ZZxHfvyXBmYVjQ9rdAT8RaSKG in list(range(UwCT5Oz6Wo0BP,b6pDh28nQRtHylFIf5C,NEc173Pr0jAwLF5OS)):
			SUVExcikXWmsjp8 += arlmjP5YVtBkRJoKGu6EL[ZZxHfvyXBmYVjQ9rdAT8RaSKG:ZZxHfvyXBmYVjQ9rdAT8RaSKG+NEc173Pr0jAwLF5OS]+UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࠮ࠩਗ")
			TTr8du7QSAO9elCp += str(sum(map(int,vJL7xe0VMXkDrEG[ZZxHfvyXBmYVjQ9rdAT8RaSKG:ZZxHfvyXBmYVjQ9rdAT8RaSKG+NEc173Pr0jAwLF5OS]))%ee3tnwl7avk(u"࠵࠵ୖ"))
		bpGIsMZ16fCWvUa3iROAchJL = str(O0CSjitXBmxcUMyHPKfRYQg)+SUVExcikXWmsjp8+TTr8du7QSAO9elCp
		JJb5DwBiqHemoygZ1j3VERXM.append(bpGIsMZ16fCWvUa3iROAchJL)
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਘ"),ReLGYUQjz7C9iEd(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨਙ"),[ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ],E8RabFm1Kp5O0s)
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,yyZPkLCRX1xcBDN(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ਚ"),vhZ5qjay1z94JmcMOgXe(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩਛ"),[JJb5DwBiqHemoygZ1j3VERXM,ooeXQmtlbKqLdH4E,cmXHJysLOjIt81epu4F5P,UJ9ysXOWw4lPbz3Ftq12vZ],ggWsYrlq8fy2v)
	return SmFfh9kPpeoNBdcV7WnJ1LHMuXZO.join(JJb5DwBiqHemoygZ1j3VERXM)
def BTKlfsON6tEUDkyLVvRQHezhcC4(TeDLBxpO03aonZFfQbNuK9S,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT,TgrlAZFKOMEcHt5d):
	Y3OmVPp2ARgBCjn = str(Ay2hPpbZC7XmtQlwnfBT8)[UwCT5Oz6Wo0BP:A2MHFvoqpZ64gNbB(u"࠷࠻࠰ୗ")].replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,NIBsHMvSXb(u"ࠬࡢ࡜࡯ࠩਜ")).replace(mqBPGuVIYZbStQejFowJh2,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭࡜࡝ࡴࠪਝ")).replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ)
	if len(str(Ay2hPpbZC7XmtQlwnfBT8))>A2MHFvoqpZ64gNbB(u"࠸࠵࠱୘"): Y3OmVPp2ARgBCjn = Y3OmVPp2ARgBCjn+eCpDE6wJtYUHn0GqK5(u"ࠧࠡ࠰࠱࠲ࠬਞ")
	mrn4jdBuXKIw7N2lvh = str(WR7gIlwo5ik9zJv3CK4sS)[UwCT5Oz6Wo0BP:dn9ouNryjHiBFQOhASvX(u"࠲࠶࠲୙")].replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨ࡞࡟ࡲࠬਟ")).replace(mqBPGuVIYZbStQejFowJh2,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ࡟ࡠࡷ࠭ਠ")).replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ)
	if len(str(WR7gIlwo5ik9zJv3CK4sS))>OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠳࠷࠳୚"): mrn4jdBuXKIw7N2lvh = mrn4jdBuXKIw7N2lvh+x9PULjztJOpu7b(u"ࠪࠤ࠳࠴࠮ࠨਡ")
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࠭ਢ")+TeDLBxpO03aonZFfQbNuK9S+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨਣ")+ZTG4ruxXUsc9N+UixkloZbzGw28ujW56X(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨਤ")+iojW2gVFfT+A2MHFvoqpZ64gNbB(u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡵࡪࡲࡨ࠿࡛ࠦࠡࠩਥ")+TgrlAZFKOMEcHt5d+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫਦ")+str(Y3OmVPp2ARgBCjn)+ee3tnwl7avk(u"ࠩࠣࡡࠥࠦࠠࡅࡣࡷࡥ࠿࡛ࠦࠡࠩਧ")+mrn4jdBuXKIw7N2lvh+DKmLTA2yGtj(u"ࠪࠤࡢ࠭ਨ"))
	return
def RvLCTts24j():
	global iwVx2HZ6S7h
	import getmac82 as Ti4HaDANYzXQb5owGOvn2Ix7
	try:
		zCMqhJ4iPvGr2b7g = Ti4HaDANYzXQb5owGOvn2Ix7.get_mac_address()
		if zCMqhJ4iPvGr2b7g.count(ZYTyoA483N(u"ࠫ࠿࠭਩"))==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠸ଡ଼") and zCMqhJ4iPvGr2b7g.count(IYC4iPxkTRUE85namF6(u"ࠬ࠶ࠧਪ"))<NIBsHMvSXb(u"࠻୛"):
			zCMqhJ4iPvGr2b7g = zCMqhJ4iPvGr2b7g.lower().replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭࠺ࠨਫ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			iwVx2HZ6S7h = str(int(zCMqhJ4iPvGr2b7g,wFYiVd4r12x7CAQBL5SPof(u"࠵࠻ଢ଼")))
	except: pass
	return
def kkHhqdEfxTS8uYLobyZG23jt():
	global wwxcg2OtQXi7a9qY4eNo1MSuTU
	import getmac94 as MRGHyvmihzkeOEn3L5Jl8d9UTAYcFt
	try:
		xYZJ0oh9OcsuLyH = MRGHyvmihzkeOEn3L5Jl8d9UTAYcFt.get_mac_address()
		if xYZJ0oh9OcsuLyH.count(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧ࠻ࠩਬ"))==jozVWcERh91GOF2NHXQiSwKqe8x(u"࠻ୟ") and xYZJ0oh9OcsuLyH.count(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࠲ࠪਭ"))<yyZPkLCRX1xcBDN(u"࠾୞"):
			xYZJ0oh9OcsuLyH = xYZJ0oh9OcsuLyH.lower().replace(Vi1oNCM5kI7yJ0(u"ࠩ࠽ࠫਮ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			wwxcg2OtQXi7a9qY4eNo1MSuTU = str(int(xYZJ0oh9OcsuLyH,ykE045Tatx(u"࠱࠷ୠ")))
	except: pass
	return
def aOouqVcDHpnlR2Cz(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS=Zg9FeADE84jSRIvPCrzYulw3sL,Ay2hPpbZC7XmtQlwnfBT8=Zg9FeADE84jSRIvPCrzYulw3sL,iojW2gVFfT=Zg9FeADE84jSRIvPCrzYulw3sL):
	BTKlfsON6tEUDkyLVvRQHezhcC4(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࡙ࠪࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡏࡑࡇࡑࡣ࡚ࡘࡌࠨਯ"),ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT,TgrlAZFKOMEcHt5d)
	if GGfPQnrJKEqMv2ZVxdD: import urllib.request as Uk7q6CNx3arTKoLp2e
	else: import urllib2 as Uk7q6CNx3arTKoLp2e
	if not Ay2hPpbZC7XmtQlwnfBT8: Ay2hPpbZC7XmtQlwnfBT8 = {UixkloZbzGw28ujW56X(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਰ"):Zg9FeADE84jSRIvPCrzYulw3sL}
	if not WR7gIlwo5ik9zJv3CK4sS: WR7gIlwo5ik9zJv3CK4sS = {}
	if TgrlAZFKOMEcHt5d==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡍࡅࡕࠩ਱"):
		ZTG4ruxXUsc9N = ZTG4ruxXUsc9N+vhZ5qjay1z94JmcMOgXe(u"࠭࠿ࠨਲ")+nWw3GirR9qxCFBOa5Dt1gdXmJMpy(WR7gIlwo5ik9zJv3CK4sS)
		WR7gIlwo5ik9zJv3CK4sS = None
	elif TgrlAZFKOMEcHt5d==vGg1hAkzqi8exVbN(u"ࠧࡑࡑࡖࡘࠬਲ਼") and qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡬ࡶࡳࡳ࠭਴") in str(Ay2hPpbZC7XmtQlwnfBT8):
		WR7gIlwo5ik9zJv3CK4sS = lSD9w50N6VBOHbfT2WRiPsM.dumps(WR7gIlwo5ik9zJv3CK4sS)
		WR7gIlwo5ik9zJv3CK4sS = str(WR7gIlwo5ik9zJv3CK4sS).encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	elif TgrlAZFKOMEcHt5d==UixkloZbzGw28ujW56X(u"ࠩࡓࡓࡘ࡚ࠧਵ"):
		WR7gIlwo5ik9zJv3CK4sS = nWw3GirR9qxCFBOa5Dt1gdXmJMpy(WR7gIlwo5ik9zJv3CK4sS)
		WR7gIlwo5ik9zJv3CK4sS = WR7gIlwo5ik9zJv3CK4sS.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	try:
		YkocjWQzSF5e9EKIgXbtiN0x2PAn = Uk7q6CNx3arTKoLp2e.Request(ZTG4ruxXUsc9N,headers=Ay2hPpbZC7XmtQlwnfBT8,data=WR7gIlwo5ik9zJv3CK4sS)
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = Uk7q6CNx3arTKoLp2e.urlopen(YkocjWQzSF5e9EKIgXbtiN0x2PAn)
		qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.read()
		POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H = vGg1hAkzqi8exVbN(u"࠳࠲࠳ୡ"),dn9ouNryjHiBFQOhASvX(u"ࠪࡓࡐ࠭ਸ਼")
	except:
		qHn7Qbi61UB = Zg9FeADE84jSRIvPCrzYulw3sL
		POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H = -Mn5NGAdz6xc42s0,ee3tnwl7avk(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫ਷")
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,yNBjYsgc23xoW(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇࡢࡴ࡝ࡶࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧਸ")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+IYC4iPxkTRUE85namF6(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨਹ")+BBkxwFGyasvQphqZ4H+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ਺")+iojW2gVFfT+JP65RzKaScIf(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ਻")+ZTG4ruxXUsc9N+vhZ5qjay1z94JmcMOgXe(u"ࠩࠣࡡ਼ࠬ"))
	if qHn7Qbi61UB and GGfPQnrJKEqMv2ZVxdD: qHn7Qbi61UB = qHn7Qbi61UB.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	return qHn7Qbi61UB
def OUL6Pt2KxZSJd13IrDm(fLBpkDZRaeUNOGhoH1Y):
	kgSw8ZsKcVbeJYhu3GyoQ4iLlFpUdO = {
		okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ਽"):qhr1Job3MC,
		ykE045Tatx(u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣਾ"):str(NGiBmYp8vX9T426lHn7ue),
		x9PULjztJOpu7b(u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥਿ"):kI8qwbo6yER,
		Vi1oNCM5kI7yJ0(u"ࠨࡤࡦࡸ࡬ࡧࡪࡥࡦࡢ࡯࡬ࡰࡾࠨੀ"):kI8qwbo6yER,
		wFYiVd4r12x7CAQBL5SPof(u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤੁ"): kI8qwbo6yER,
		ttC4VURALPYKh(u"ࠣࡥࡤࡶࡷ࡯ࡥࡳࠤੂ"):A2MHFvoqpZ64gNbB(u"ࠤࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࠤ੃"),
		YXm2qAbu8Qsx(u"ࠥ࡭ࡵࠨ੄"): ZYTyoA483N(u"ࠦࠩࡸࡥ࡮ࡱࡷࡩࠧ੅"),
		vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࠪࡳ࡬࡫ࡳࡣࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࡥࡳࡺࡰࡦࠦ੆"):vvglE69OFKBm817Nkc
	}
	ZZeDErbOAPYGFT = []
	for zMsqA2SVtdHLJDx8gpFGw in fLBpkDZRaeUNOGhoH1Y:
		yjOBkgfH84 = kgSw8ZsKcVbeJYhu3GyoQ4iLlFpUdO.copy()
		yjOBkgfH84[KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪੇ")] = zMsqA2SVtdHLJDx8gpFGw
		yjOBkgfH84[NIBsHMvSXb(u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪੈ")] = {YXm2qAbu8Qsx(u"ࠣࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ੉"):zMsqA2SVtdHLJDx8gpFGw}
		yjOBkgfH84[wFYiVd4r12x7CAQBL5SPof(u"ࠩࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫ੊")] = {UixkloZbzGw28ujW56X(u"࡙ࠥࡸ࡫ࡲࡠࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧੋ"):zMsqA2SVtdHLJDx8gpFGw}
		ZZeDErbOAPYGFT.append(yjOBkgfH84)
	JJHXLKfURMO = str(pJ5tI2GD1jSPgdzO7qBuFk60Rni93.randrange(Vi1oNCM5kI7yJ0(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷ୢ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ୣ")))
	WR7gIlwo5ik9zJv3CK4sS = {
		vGg1hAkzqi8exVbN(u"ࠦࡦࡶࡩࡠ࡭ࡨࡽࠧੌ"):ykE045Tatx(u"ࠬ࠸࠵࠵ࡦࡧ࠷ࡦ࠺࠰࠺ࡦ࠻ࡦ࠻࠾࠱ࡥ࠶ࡨ࠵࠶࠽ࡥࡦ࠹࠻ࡧࡪࡨࡦ࠳࠻੍ࠪ"),
		OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡩ࡯ࡵࡨࡶࡹࡥࡩࡥࠤ੎"):JJHXLKfURMO,
		vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠢࡦࡸࡨࡲࡹࡹࠢ੏"): ZZeDErbOAPYGFT
	}
	Ay2hPpbZC7XmtQlwnfBT8 = {ZYTyoA483N(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ੐"):JP65RzKaScIf(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬੑ")}
	ZTG4ruxXUsc9N = UQS9lVew50DIyXrinWsMxTzA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠳࠰ࡤࡱࡵࡲࡩࡵࡷࡧࡩ࠳ࡩ࡯࡮࠱࠵࠳࡭ࡺࡴࡱࡣࡳ࡭ࠬ੒")
	qHn7Qbi61UB = aOouqVcDHpnlR2Cz(x9PULjztJOpu7b(u"ࠫࡕࡕࡓࡕࠩ੓"),ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Vi1oNCM5kI7yJ0(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࡙࠭࠲ࡵࡷࠫ੔"))
	return qHn7Qbi61UB
def JGmfjhoyKZUl(LwhdPNZ37p9clMKn,xQXoDIqn4Ucsthb2G7YpzwPTymi):
	xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(NIBsHMvSXb(u"࠭࡮ࡶ࡮࡯ࠫ੕"),Vi1oNCM5kI7yJ0(u"ࠧࡏࡱࡱࡩࠬ੖"))
	xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(ReLGYUQjz7C9iEd(u"ࠨࡶࡵࡹࡪ࠭੗"),UixkloZbzGw28ujW56X(u"ࠩࡗࡶࡺ࡫ࠧ੘"))
	xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(x9PULjztJOpu7b(u"ࠪࡪࡦࡲࡳࡦࠩਖ਼"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡋࡧ࡬ࡴࡧࠪਗ਼"))
	xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(eCpDE6wJtYUHn0GqK5(u"ࠬࡢ࠯ࠨਜ਼"),Vi1oNCM5kI7yJ0(u"࠭࠯ࠨੜ"))
	try: tKDGiWXJhlvcV14wr3E = eval(xQXoDIqn4Ucsthb2G7YpzwPTymi)
	except: tKDGiWXJhlvcV14wr3E = vXOBA3MN5D1WUzK2JjLS0ycxhIFd(LwhdPNZ37p9clMKn)
	return tKDGiWXJhlvcV14wr3E
def rsfHM53TBgcQAjN7ZJtKzPGnSxeu():
	TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧ੝"),Wo5ZqMiTYmSgUCvalXhRer4OjpP7,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if OQ1FgC3a5ZLX4unm7Ebx8ji: Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = Wo5ZqMiTYmSgUCvalXhRer4OjpP7.split(OQ1FgC3a5ZLX4unm7Ebx8ji[UwCT5Oz6Wo0BP],IK4zTnSMyGQpxEaesJAPVDY(u"࠵୤"))[Mn5NGAdz6xc42s0]
	II79SczUa2VOMP8DXBtmgA4Yq6KxZo = LNma2eq3vEguwVtHjn.strftime(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨਫ਼"),LNma2eq3vEguwVtHjn.localtime(PPc8zbiVZnFkfXLBRv))
	Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = Wo5ZqMiTYmSgUCvalXhRer4OjpP7+II79SczUa2VOMP8DXBtmgA4Yq6KxZo
	CCNbwm7MIjKiv2q9RJn = TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
	if brAUlZfdFmt3TRJW2xX4.path.exists(UbCmKIdEjMa5lr0):
		EXmDZJu7BtVLwj4 = open(UbCmKIdEjMa5lr0,NIBsHMvSXb(u"ࠩࡵࡦࠬ੟")).read()
		if GGfPQnrJKEqMv2ZVxdD: EXmDZJu7BtVLwj4 = EXmDZJu7BtVLwj4.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		EXmDZJu7BtVLwj4 = JGmfjhoyKZUl(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡨ࡮ࡩࡴࠨ੠"),EXmDZJu7BtVLwj4)
	else: EXmDZJu7BtVLwj4 = {}
	jd3r4eqQKWnYAGEJtDoy = {}
	for xZw1mTJAkYU8RdeFz24cqb9QivXEyM in list(EXmDZJu7BtVLwj4.keys()):
		if xZw1mTJAkYU8RdeFz24cqb9QivXEyM!=TeDLBxpO03aonZFfQbNuK9S: jd3r4eqQKWnYAGEJtDoy[xZw1mTJAkYU8RdeFz24cqb9QivXEyM] = EXmDZJu7BtVLwj4[xZw1mTJAkYU8RdeFz24cqb9QivXEyM]
		else:
			if Wo5ZqMiTYmSgUCvalXhRer4OjpP7 and Wo5ZqMiTYmSgUCvalXhRer4OjpP7!=ttC4VURALPYKh(u"ࠫ࠳࠴ࠧ੡"):
				YYesH7IdZJRxF0GOryQCp9 = EXmDZJu7BtVLwj4[xZw1mTJAkYU8RdeFz24cqb9QivXEyM]
				if CCNbwm7MIjKiv2q9RJn in YYesH7IdZJRxF0GOryQCp9:
					I5ycituE8YxBLn = YYesH7IdZJRxF0GOryQCp9.index(CCNbwm7MIjKiv2q9RJn)
					del YYesH7IdZJRxF0GOryQCp9[I5ycituE8YxBLn]
				Xg0VS4uIxmvy2bNGpTrY = [CCNbwm7MIjKiv2q9RJn]+YYesH7IdZJRxF0GOryQCp9
				Xg0VS4uIxmvy2bNGpTrY = Xg0VS4uIxmvy2bNGpTrY[:OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠺࠶୥")]
				jd3r4eqQKWnYAGEJtDoy[xZw1mTJAkYU8RdeFz24cqb9QivXEyM] = Xg0VS4uIxmvy2bNGpTrY
			else: jd3r4eqQKWnYAGEJtDoy[xZw1mTJAkYU8RdeFz24cqb9QivXEyM] = EXmDZJu7BtVLwj4[xZw1mTJAkYU8RdeFz24cqb9QivXEyM]
	if TeDLBxpO03aonZFfQbNuK9S not in list(jd3r4eqQKWnYAGEJtDoy.keys()): jd3r4eqQKWnYAGEJtDoy[TeDLBxpO03aonZFfQbNuK9S] = [CCNbwm7MIjKiv2q9RJn]
	jd3r4eqQKWnYAGEJtDoy = str(jd3r4eqQKWnYAGEJtDoy)
	if GGfPQnrJKEqMv2ZVxdD: jd3r4eqQKWnYAGEJtDoy = jd3r4eqQKWnYAGEJtDoy.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	open(UbCmKIdEjMa5lr0,vhZ5qjay1z94JmcMOgXe(u"ࠬࡽࡢࠨ੢")).write(jd3r4eqQKWnYAGEJtDoy)
	return
def nWw3GirR9qxCFBOa5Dt1gdXmJMpy(WR7gIlwo5ik9zJv3CK4sS):
	if GGfPQnrJKEqMv2ZVxdD: import urllib.parse as rnmTE1JAGY
	else: import urllib as rnmTE1JAGY
	HIG38Mnep5vg = rnmTE1JAGY.urlencode(WR7gIlwo5ik9zJv3CK4sS)
	return HIG38Mnep5vg
def nTdpZOCUe7l(JaqiYfEglZDvmwQNS8zR,P78WGtDibKXjkIsexnHFqhM9l1w=Zg9FeADE84jSRIvPCrzYulw3sL,AL8Xqj6JN3V7tvkRaI9zT2ewYD=Zg9FeADE84jSRIvPCrzYulw3sL):
	K9V1YZ0wi7 = P78WGtDibKXjkIsexnHFqhM9l1w not in [yNBjYsgc23xoW(u"࠭ࡍ࠴ࡗࠪ੣"),ykE045Tatx(u"ࠧࡊࡒࡗ࡚ࠬ੤")]
	if not AL8Xqj6JN3V7tvkRaI9zT2ewYD: AL8Xqj6JN3V7tvkRaI9zT2ewYD = JP65RzKaScIf(u"ࠨࡸ࡬ࡨࡪࡵࠧ੥")
	pJu045bGMOea,weRLK29C6n,U3DI1pSatT9GbyXeP6Rd = UixkloZbzGw28ujW56X(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ੦"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if len(JaqiYfEglZDvmwQNS8zR)==O4dklMvZ8ULcS:
		ZTG4ruxXUsc9N,XwROkPvSVAtdpMKIzniH3C,U3DI1pSatT9GbyXeP6Rd = JaqiYfEglZDvmwQNS8zR
		if XwROkPvSVAtdpMKIzniH3C: weRLK29C6n = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻ࠢ࡞ࠤࠬ੧")+XwROkPvSVAtdpMKIzniH3C+UQS9lVew50DIyXrinWsMxTzA(u"ࠫࠥࡣࠧ੨")
	else: ZTG4ruxXUsc9N,XwROkPvSVAtdpMKIzniH3C,U3DI1pSatT9GbyXeP6Rd = JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	ZTG4ruxXUsc9N = ZTG4ruxXUsc9N.replace(yyZPkLCRX1xcBDN(u"ࠬࠫ࠲࠱ࠩ੩"),wjs26GpVfNiCUERHJ)
	uVqMYescRCnSJyDlF7Hb = wzX1klOfLVhb2B4ita(ZTG4ruxXUsc9N)
	if P78WGtDibKXjkIsexnHFqhM9l1w not in [NIBsHMvSXb(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ੪"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡊࡒࡗ࡚ࠬ੫")]:
		if P78WGtDibKXjkIsexnHFqhM9l1w!=jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ੬"): ZTG4ruxXUsc9N = ZTG4ruxXUsc9N.replace(wjs26GpVfNiCUERHJ,ee3tnwl7avk(u"ࠩࠨ࠶࠵࠭੭"))
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+Vi1oNCM5kI7yJ0(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ੮")+ZTG4ruxXUsc9N+vGg1hAkzqi8exVbN(u"ࠫࠥࡣࠧ੯")+weRLK29C6n)
		if uVqMYescRCnSJyDlF7Hb==x9PULjztJOpu7b(u"ࠬ࠴࡭࠴ࡷ࠻ࠫੰ") and P78WGtDibKXjkIsexnHFqhM9l1w not in [yyZPkLCRX1xcBDN(u"࠭ࡉࡑࡖ࡙ࠫੱ"),lU1fSmncFWjizwqZugyYBANML0(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨੲ")]:
			from V1VREBsj92 import zKaqs0n5ZdrvWSTJYhy7,WXZLgSfpV2jzRFTNiyroc,ZXWeI01flR
			nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zKaqs0n5ZdrvWSTJYhy7(ZTG4ruxXUsc9N)
			Ahcb3XWMIz0JYT6g7jEpmsq = len(fo6s53yEnbklLpaJOzgR4Q01wxB)
			if Ahcb3XWMIz0JYT6g7jEpmsq>Mn5NGAdz6xc42s0:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(IK4zTnSMyGQpxEaesJAPVDY(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩੳ")+str(Ahcb3XWMIz0JYT6g7jEpmsq)+qdEKO42r3GhwmCDcHtxzJUR(u"้้ࠩࠣ็ࠩࠨੴ"), nnhWEIa6Tm)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0:
					ZXWeI01flR(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪษ้เวยࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨੵ"),JP65RzKaScIf(u"ࠫࡈࡧ࡮ࡤࡧ࡯ࠫ੶"))
					return pJu045bGMOea
			else: lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			ZTG4ruxXUsc9N = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
			if nnhWEIa6Tm[UwCT5Oz6Wo0BP]!=okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬ࠳࠱ࠨ੷"):
				zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+dn9ouNryjHiBFQOhASvX(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ੸")+nnhWEIa6Tm[lqQvOUWodZnhXLS2Vcuj6EtairFN]+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ੹")+ZTG4ruxXUsc9N+ee3tnwl7avk(u"ࠨࠢࡠࠫ੺"))
		if qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪ੻") in ZTG4ruxXUsc9N: ZTG4ruxXUsc9N = ZTG4ruxXUsc9N+yyZPkLCRX1xcBDN(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ੼")
		elif ykE045Tatx(u"ࠫ࡭ࡺࡴࡱࠩ੽") in ZTG4ruxXUsc9N.lower() and ZYTyoA483N(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ੾") not in ZTG4ruxXUsc9N and tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ੿") not in ZTG4ruxXUsc9N:
			ZTG4ruxXUsc9N = ZTG4ruxXUsc9N+DKmLTA2yGtj(u"ࠧࡽࠩ઀") if ZYTyoA483N(u"ࠨࡾࠪઁ") not in ZTG4ruxXUsc9N else ZTG4ruxXUsc9N+ttC4VURALPYKh(u"ࠩࠩࠫં")
			if NIBsHMvSXb(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨઃ") not in ZTG4ruxXUsc9N and IYC4iPxkTRUE85namF6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭઄") in ZTG4ruxXUsc9N.lower(): ZTG4ruxXUsc9N += lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠧࠩઅ")
			if eCpDE6wJtYUHn0GqK5(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡀࠫઆ") not in ZTG4ruxXUsc9N.lower() and P78WGtDibKXjkIsexnHFqhM9l1w not in [UixkloZbzGw28ujW56X(u"ࠧࡊࡒࡗ࡚ࠬઇ"),yyZPkLCRX1xcBDN(u"ࠨࡏ࠶࡙ࠬઈ")]: ZTG4ruxXUsc9N += okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨઉ")
			if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡶࡪ࡬ࡥࡳࡧࡵࡁࠬઊ") not in ZTG4ruxXUsc9N.lower(): ZTG4ruxXUsc9N += ReLGYUQjz7C9iEd(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲࠩࠫઋ")
	zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+yNBjYsgc23xoW(u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ઌ")+ZTG4ruxXUsc9N+qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࠠ࡞ࠩઍ"))
	VtuRqoFBUs5iezY9WSnflPGc7ap = HqjWaYEzp0D8eyQRud.ListItem()
	AL8Xqj6JN3V7tvkRaI9zT2ewYD,spmUYd3OZa87BGlf,e096EDGtfOL,XzDcCO9R4Unv0ZLAYquj1rkbQTlBo,RP17pN52FxDJYCq,mmRjeA1J7LIdwDina8KSBc4TVUp,rB1I842qHtvMzTusV9K0me5oQ,bnrweaVZ4RKkCIBENzA5S6DMsy81,F7tRiquHYKJL48 = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	if P78WGtDibKXjkIsexnHFqhM9l1w not in [yyZPkLCRX1xcBDN(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ઎"),ttC4VURALPYKh(u"ࠨࡋࡓࡘ࡛࠭એ")]:
		if HByjTem6EJP5sZb: kINpclALQGKm1HWCB = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬઐ")
		else: kINpclALQGKm1HWCB = E3i1eCBtN2w(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨઑ")
		VtuRqoFBUs5iezY9WSnflPGc7ap.setProperty(kINpclALQGKm1HWCB, Zg9FeADE84jSRIvPCrzYulw3sL)
		VtuRqoFBUs5iezY9WSnflPGc7ap.setMimeType(IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡲ࡯࡭ࡦ࠱ࡻ࠱ࡹࡿࡰࡦࠩ઒"))
		if NGiBmYp8vX9T426lHn7ue<DKmLTA2yGtj(u"࠸࠰୦"): VtuRqoFBUs5iezY9WSnflPGc7ap.setInfo(IYC4iPxkTRUE85namF6(u"ࠬࡼࡩࡥࡧࡲࠫઓ"),{lU1fSmncFWjizwqZugyYBANML0(u"࠭࡭ࡦࡦ࡬ࡥࡹࡿࡰࡦࠩઔ"):Vi1oNCM5kI7yJ0(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭ક")})
		else:
			uWvte6kj5bndFw1NXo8fSQA = VtuRqoFBUs5iezY9WSnflPGc7ap.getVideoInfoTag()
			uWvte6kj5bndFw1NXo8fSQA.setMediaType(wFYiVd4r12x7CAQBL5SPof(u"ࠨ࡯ࡲࡺ࡮࡫ࠧખ"))
		VtuRqoFBUs5iezY9WSnflPGc7ap.setArt({Vi1oNCM5kI7yJ0(u"ࠩࡷ࡬ࡺࡳࡢࠨગ"):RP17pN52FxDJYCq,YXm2qAbu8Qsx(u"ࠪࡴࡴࡹࡴࡦࡴࠪઘ"):RP17pN52FxDJYCq,x9PULjztJOpu7b(u"ࠫࡧࡧ࡮࡯ࡧࡵࠫઙ"):RP17pN52FxDJYCq,ee3tnwl7avk(u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬચ"):RP17pN52FxDJYCq,eCpDE6wJtYUHn0GqK5(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨછ"):RP17pN52FxDJYCq,ZYTyoA483N(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪજ"):RP17pN52FxDJYCq,ReLGYUQjz7C9iEd(u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫઝ"):RP17pN52FxDJYCq,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࡬ࡧࡴࡴࠧઞ"):RP17pN52FxDJYCq})
		if uVqMYescRCnSJyDlF7Hb in [KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࠲ࡲࡶࡤࠨટ"),IYC4iPxkTRUE85namF6(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪઠ")]: VtuRqoFBUs5iezY9WSnflPGc7ap.setContentLookup(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		else: VtuRqoFBUs5iezY9WSnflPGc7ap.setContentLookup(vvglE69OFKBm817Nkc)
		from XUbpWe5mRd import M9ZaLYTqERCo2
		if ykE045Tatx(u"ࠬࡸࡴ࡮ࡲࠪડ") in ZTG4ruxXUsc9N:
			M9ZaLYTqERCo2(IYC4iPxkTRUE85namF6(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩઢ"),vvglE69OFKBm817Nkc)
		elif uVqMYescRCnSJyDlF7Hb==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠯࡯ࡳࡨࠬણ") or vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨત") in ZTG4ruxXUsc9N:
			M9ZaLYTqERCo2(dn9ouNryjHiBFQOhASvX(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩથ"),vvglE69OFKBm817Nkc)
			VtuRqoFBUs5iezY9WSnflPGc7ap.setProperty(kINpclALQGKm1HWCB,eCpDE6wJtYUHn0GqK5(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪદ"))
			VtuRqoFBUs5iezY9WSnflPGc7ap.setProperty(ttC4VURALPYKh(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫધ"),E3i1eCBtN2w(u"ࠬࡳࡰࡥࠩન"))
		if XwROkPvSVAtdpMKIzniH3C:
			VtuRqoFBUs5iezY9WSnflPGc7ap.setSubtitles([XwROkPvSVAtdpMKIzniH3C])
	if AL8Xqj6JN3V7tvkRaI9zT2ewYD==YXm2qAbu8Qsx(u"࠭ࡶࡪࡦࡨࡳࠬ઩") and P78WGtDibKXjkIsexnHFqhM9l1w==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩપ"):
		pJu045bGMOea = qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨફ")
		P78WGtDibKXjkIsexnHFqhM9l1w = DKmLTA2yGtj(u"ࠩࡓࡐࡆ࡟࡟ࡅࡎࡢࡊࡎࡒࡅࡔࠩબ")
	elif AL8Xqj6JN3V7tvkRaI9zT2ewYD==DKmLTA2yGtj(u"ࠪࡺ࡮ࡪࡥࡰࠩભ") and bnrweaVZ4RKkCIBENzA5S6DMsy81.startswith(DKmLTA2yGtj(u"ࠫ࠻࠭મ")):
		pJu045bGMOea = ee3tnwl7avk(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠪય")
		P78WGtDibKXjkIsexnHFqhM9l1w = P78WGtDibKXjkIsexnHFqhM9l1w+KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭࡟ࡅࡎࠪર")
	if pJu045bGMOea!=IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬ઱"): rsfHM53TBgcQAjN7ZJtKzPGnSxeu()
	cFyv1OrHzwKe3UxiCb2.Y6TXlktz0yFfgMqKj7(P78WGtDibKXjkIsexnHFqhM9l1w)
	if cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg: return Vi1oNCM5kI7yJ0(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩલ")
	if AL8Xqj6JN3V7tvkRaI9zT2ewYD==IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡹ࡭ࡩ࡫࡯ࠨળ") and not bnrweaVZ4RKkCIBENzA5S6DMsy81.startswith(IYC4iPxkTRUE85namF6(u"ࠪ࠺ࠬ઴")):
		VtuRqoFBUs5iezY9WSnflPGc7ap.setPath(ZTG4ruxXUsc9N)
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+eCpDE6wJtYUHn0GqK5(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫવ")+ZTG4ruxXUsc9N+YXm2qAbu8Qsx(u"ࠬࠦ࡝ࠨશ"))
		j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.setResolvedUrl(xTMIUH9jL2w4mspJkyrR,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,VtuRqoFBUs5iezY9WSnflPGc7ap)
	elif AL8Xqj6JN3V7tvkRaI9zT2ewYD==yyZPkLCRX1xcBDN(u"࠭࡬ࡪࡸࡨࠫષ"):
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+YXm2qAbu8Qsx(u"ࠧࠡࠢࠣࡐ࡮ࡼࡥࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡶ࡬ࡢࡻࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪસ")+ZTG4ruxXUsc9N+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࠢࡠࠫહ"))
		cFyv1OrHzwKe3UxiCb2.play(ZTG4ruxXUsc9N,VtuRqoFBUs5iezY9WSnflPGc7ap)
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
	if pJu045bGMOea==YXm2qAbu8Qsx(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧ઺"):
		from NOm3axJBXc import fIPxNkKvy64OsA9
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = fIPxNkKvy64OsA9(ZTG4ruxXUsc9N,uVqMYescRCnSJyDlF7Hb,P78WGtDibKXjkIsexnHFqhM9l1w)
		if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: rsfHM53TBgcQAjN7ZJtKzPGnSxeu()
	else:
		HTPdhx6IsYmGjeZ5nbtkUy47ACvruK,pJu045bGMOea,muBiOEJ6KL5WDAcQ821vU,srRDtq6lknf3yS9IgGECQ2K,uAqyZlT4C3Yct2azd = UwCT5Oz6Wo0BP,ee3tnwl7avk(u"ࠪࡸࡷ࡯ࡥࡥࠩ઻"),vvglE69OFKBm817Nkc,JP65RzKaScIf(u"࠲࠲࠳࠴୨"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠴࠶࠲࠳࠴୧")
		if K9V1YZ0wi7: from V1VREBsj92 import ZXWeI01flR
		while HTPdhx6IsYmGjeZ5nbtkUy47ACvruK<uAqyZlT4C3Yct2azd:
			Zz9SeICTbPksXy6nuOtLGWhN2V.sleep(srRDtq6lknf3yS9IgGECQ2K)
			HTPdhx6IsYmGjeZ5nbtkUy47ACvruK += srRDtq6lknf3yS9IgGECQ2K
			if cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg==ZYTyoA483N(u"ࠫࡸࡺࡡࡳࡶࡨࡨ઼ࠬ") and not muBiOEJ6KL5WDAcQ821vU:
				if K9V1YZ0wi7: ZXWeI01flR(vGg1hAkzqi8exVbN(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ๎ัอฯࠡษ็ๅ๏ี๊้ࠩઽ"),ee3tnwl7avk(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧા"),LNma2eq3vEguwVtHjn=ReLGYUQjz7C9iEd(u"࠹࠸࠴୩"))
				zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+vhZ5qjay1z94JmcMOgXe(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫિ")+ZTG4ruxXUsc9N+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠢࡠࠫી")+weRLK29C6n)
				muBiOEJ6KL5WDAcQ821vU = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			elif cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg in [IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")]:
				zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+ykE045Tatx(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨૃ")+ZTG4ruxXUsc9N+IYC4iPxkTRUE85namF6(u"ࠬࠦ࡝ࠨૄ")+weRLK29C6n)
				break
			elif cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg==qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ૅ"):
				zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ૆")+ZTG4ruxXUsc9N+ReLGYUQjz7C9iEd(u"ࠨࠢࡠࠫે")+weRLK29C6n)
				if K9V1YZ0wi7: ZXWeI01flR(DKmLTA2yGtj(u"ࠩไุ้ะฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭ૈ"),JP65RzKaScIf(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫૉ"),LNma2eq3vEguwVtHjn=yNBjYsgc23xoW(u"࠺࠹࠵୪"))
				break
			elif cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg==Vi1oNCM5kI7yJ0(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊"):
				zOgQjNGH9yk1bXVRnofPvs(C1CRH4W2eukIOP7rjbw6xscQpdDN,VsYiARtQ2WToMq(bIPsOxjEpoH)+Vi1oNCM5kI7yJ0(u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪો")+ZTG4ruxXUsc9N+Vi1oNCM5kI7yJ0(u"࠭ࠠ࡞ࠩૌ"))
				break
		else: pJu045bGMOea = A2MHFvoqpZ64gNbB(u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ્")
	if pJu045bGMOea in [IYC4iPxkTRUE85namF6(u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ૎")] or cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg in [zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ૏"),ee3tnwl7avk(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૐ")] or oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: FajoeBMP8wQp3RyVUXbvrDtT6nc0z(P78WGtDibKXjkIsexnHFqhM9l1w)
	else: exec(UixkloZbzGw28ujW56X(u"ࠫ࡮ࡳࡰࡰࡴࡷࠤࡽࡨ࡭ࡤ࠽ࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ૑"))
	Iloc8jMgSqmUrGW2y5Cu3XF = Zz9SeICTbPksXy6nuOtLGWhN2V.Player().isPlaying()
	if not Iloc8jMgSqmUrGW2y5Cu3XF and pJu045bGMOea not in [x9PULjztJOpu7b(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠪ૒")]:
		msg = lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧ૓") if pJu045bGMOea==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ૔") else YXm2qAbu8Qsx(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ૕")
		if K9V1YZ0wi7: ZXWeI01flR(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩไุ้ะฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭૖"),msg,LNma2eq3vEguwVtHjn=zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠻࠺࠶୫"))
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+UQS9lVew50DIyXrinWsMxTzA(u"ࠪࠤࠥࠦࠧ૗")+msg+YXm2qAbu8Qsx(u"ࠫ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ૘")+ZTG4ruxXUsc9N+eCpDE6wJtYUHn0GqK5(u"ࠬࠦ࡝ࠨ૙")+weRLK29C6n)
	return cFyv1OrHzwKe3UxiCb2.ff6oGwZFLOkpdNCryg
def wzX1klOfLVhb2B4ita(ZTG4ruxXUsc9N):
	if GGfPQnrJKEqMv2ZVxdD: from urllib.parse import urlparse as ELIly8iAMbU90xeZ
	else: from urlparse import urlparse as ELIly8iAMbU90xeZ
	path = ELIly8iAMbU90xeZ(ZTG4ruxXUsc9N).path
	z8qO7eSUgamRJyp9ZXNDnl2kKMxsHu = Zg9FeADE84jSRIvPCrzYulw3sL if vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠮ࠨ૚") not in path else path.rsplit(lU1fSmncFWjizwqZugyYBANML0(u"ࠧ࠯ࠩ૛"),wFYiVd4r12x7CAQBL5SPof(u"࠶୬"))[Mn5NGAdz6xc42s0]
	if z8qO7eSUgamRJyp9ZXNDnl2kKMxsHu in [qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡣࡹ࡭ࠬ૜"),ykE045Tatx(u"ࠩࡷࡷࠬ૝"),vhZ5qjay1z94JmcMOgXe(u"ࠪࡥࡦࡩࠧ૞"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡲࡶ࠴ࠨ૟"),yyZPkLCRX1xcBDN(u"ࠬࡳ࠳ࡶࠩૠ"),IYC4iPxkTRUE85namF6(u"࠭࡭࠴ࡷ࠻ࠫૡ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࡮ࡲࡧࠫૢ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࡯࡮ࡺࠬૣ"),yyZPkLCRX1xcBDN(u"ࠩࡩࡰࡻ࠭૤"),ykE045Tatx(u"ࠪࡱࡵ࠹ࠧ૥"),x9PULjztJOpu7b(u"ࠫࡼ࡫ࡢ࡮ࠩ૦")]: return jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬ࠴ࠧ૧")+z8qO7eSUgamRJyp9ZXNDnl2kKMxsHu
	return Zg9FeADE84jSRIvPCrzYulw3sL
def FajoeBMP8wQp3RyVUXbvrDtT6nc0z(yjOBkgfH84):
	if not XcPLKthYTV.dMeaPykZB3Ln8DGuS: yjOBkgfH84 += x9PULjztJOpu7b(u"࠭࡟ࡕࡕࠪ૨")
	TSbmULh6HJNxjRYV.append(yjOBkgfH84)
	return
def Sma2pEt5wTK(oowZaKjfLDVgBpGP5zI=vvglE69OFKBm817Nkc):
	zUax4FJqAIfO5iWd(oowZaKjfLDVgBpGP5zI,ZYTyoA483N(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪ૩"))
	cbzwJ3rLm0XhR52W7xoqE8Qljk.exit()
def zUax4FJqAIfO5iWd(oowZaKjfLDVgBpGP5zI,o4be19ApMtCrdf5):
	if o4be19ApMtCrdf5:
		if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫ૪") in o4be19ApMtCrdf5: zOgQjNGH9yk1bXVRnofPvs(Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬ૫"))
		else:
			e5tpxWUIR07haVwbJSY2cFz4NmMfXA = yUTYoAgth5iC43uLrdBH.getSetting(ReLGYUQjz7C9iEd(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૬"))
			yUTYoAgth5iC43uLrdBH.setSetting(NIBsHMvSXb(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ૭"),Zg9FeADE84jSRIvPCrzYulw3sL)
			import V1VREBsj92
			V1VREBsj92.TS2jM0Dl7syHeh3o8tPvxN5i9Lb(o4be19ApMtCrdf5)
			yUTYoAgth5iC43uLrdBH.setSetting(dn9ouNryjHiBFQOhASvX(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭૮"),e5tpxWUIR07haVwbJSY2cFz4NmMfXA)
	LpTv52e4Icnwms0OXRW6oACix(E3i1eCBtN2w(u"࠭ࡳࡵࡱࡳࠫ૯"))
	eemiN1oSxUJ = yUTYoAgth5iC43uLrdBH.getSetting(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ૰"))
	if eemiN1oSxUJ==vhZ5qjay1z94JmcMOgXe(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡡࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૱"): yUTYoAgth5iC43uLrdBH.setSetting(dn9ouNryjHiBFQOhASvX(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭૲"),x9PULjztJOpu7b(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ૳"))
	elif eemiN1oSxUJ==NIBsHMvSXb(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ૴"): yUTYoAgth5iC43uLrdBH.setSetting(x9PULjztJOpu7b(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩ૵"),Zg9FeADE84jSRIvPCrzYulw3sL)
	if yUTYoAgth5iC43uLrdBH.getSetting(A2MHFvoqpZ64gNbB(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ૶")) not in [vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡂࡗࡗࡓࠬ૷"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡕࡗࡓࡕ࠭૸"),vhZ5qjay1z94JmcMOgXe(u"ࠩࡄࡗࡐ࠭ૹ")]: yUTYoAgth5iC43uLrdBH.setSetting(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ૺ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡆ࡙ࡋࠨૻ"))
	if yUTYoAgth5iC43uLrdBH.getSetting(Vi1oNCM5kI7yJ0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪૼ")) not in [OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡁࡖࡖࡒࠫ૽"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡔࡖࡒࡔࠬ૾"),NIBsHMvSXb(u"ࠨࡃࡖࡏࠬ૿")]: yUTYoAgth5iC43uLrdBH.setSetting(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ଀"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡅࡘࡑࠧଁ"))
	AihfLS072gGKwl = yUTYoAgth5iC43uLrdBH.getSetting(x9PULjztJOpu7b(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩଂ"))
	thz5sHXldkV3L = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(JP65RzKaScIf(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨଃ"))
	if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ଄") in str(thz5sHXldkV3L) and AihfLS072gGKwl in [qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪଅ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧଆ")]:
		LNma2eq3vEguwVtHjn.sleep(UixkloZbzGw28ujW56X(u"࠶࠮࠲࠲࠳୭"))
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(x9PULjztJOpu7b(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭ଇ"))
	if UwCT5Oz6Wo0BP and xTMIUH9jL2w4mspJkyrR>-Mn5NGAdz6xc42s0:
		j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.setResolvedUrl(xTMIUH9jL2w4mspJkyrR,vvglE69OFKBm817Nkc,HqjWaYEzp0D8eyQRud.ListItem())
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8 = vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc
		j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.endOfDirectory(xTMIUH9jL2w4mspJkyrR,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8)
	if TSbmULh6HJNxjRYV:
		if vGg1hAkzqi8exVbN(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ଈ") in str(TSbmULh6HJNxjRYV) and OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧଉ") in str(TSbmULh6HJNxjRYV) and tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧଊ") in str(TSbmULh6HJNxjRYV):
			for yjOBkgfH84 in [NIBsHMvSXb(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨଋ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪଌ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭଍"),DKmLTA2yGtj(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨ଎")]:
				if yjOBkgfH84 in TSbmULh6HJNxjRYV: TSbmULh6HJNxjRYV.remove(yjOBkgfH84)
		K2mcVPqMYAJl6tpZOWQTLyusFUwh8 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=OUL6Pt2KxZSJd13IrDm,args=(TSbmULh6HJNxjRYV,))
		K2mcVPqMYAJl6tpZOWQTLyusFUwh8.start()
	nntIe2prFNdZ = yC2N01GBUPZAD()
	Iloc8jMgSqmUrGW2y5Cu3XF = Zz9SeICTbPksXy6nuOtLGWhN2V.Player().isPlaying()
	if nntIe2prFNdZ and Iloc8jMgSqmUrGW2y5Cu3XF:
		VbC5kOBHYGSvceMlti = zOmWR8ohCEk6BrLaS9dZc()
		if VbC5kOBHYGSvceMlti:
			XcPLKthYTV.resolveonly = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			LNma2eq3vEguwVtHjn.sleep(DKmLTA2yGtj(u"࠶࠱୮"))
			Iloc8jMgSqmUrGW2y5Cu3XF = Zz9SeICTbPksXy6nuOtLGWhN2V.Player().isPlaying()
			if Iloc8jMgSqmUrGW2y5Cu3XF:
				TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = d2ickGMz45euLXJwAIxs7N(VbC5kOBHYGSvceMlti)
				import V1VREBsj92
				if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in Wo5ZqMiTYmSgUCvalXhRer4OjpP7 for B251BPiLbvG9UxszKtlI7YQHmoWw in V1VREBsj92.NOT_TO_TEST_ALL_SERVERS):
					V1VREBsj92.ZXWeI01flR(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫଏ"),yNBjYsgc23xoW(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩଐ"),LNma2eq3vEguwVtHjn=KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠳࠲࠳࠴୯"))
					LNma2eq3vEguwVtHjn.sleep(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠴୰"))
					if HByjTem6EJP5sZb:
						ZTG4ruxXUsc9N = ZTG4ruxXUsc9N.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
					CsaNhTtGm8 = V1VREBsj92.v50uoKxSgEjaATet7DwzLZJyXk2CmR(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
					V1VREBsj92.ZXWeI01flR(NIBsHMvSXb(u"ࠬ࠭଑"),UixkloZbzGw28ujW56X(u"࠭ว็ฬ๊ํࠥ็อึࠢสุ่๐ัโำสฮࠬ଒"),LNma2eq3vEguwVtHjn=Vi1oNCM5kI7yJ0(u"࠵࠴࠵࠶ୱ"))
	if oowZaKjfLDVgBpGP5zI: Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(ZYTyoA483N(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫଓ"))
	return
def zOmWR8ohCEk6BrLaS9dZc():
	Ep1BVa4nlfqmGsW = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(ykE045Tatx(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡊࡩࡹࡏࡴࡦ࡯ࡶࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ࠻࡝ࠥࡸ࡮ࡺ࡬ࡦࠤ࠯ࠦ࡫࡯࡬ࡦࠤ࠯ࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࡞ࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫଔ"))
	CsaNhTtGm8 = lSD9w50N6VBOHbfT2WRiPsM.loads(Ep1BVa4nlfqmGsW)[E3i1eCBtN2w(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩକ")]
	VbC5kOBHYGSvceMlti = Zg9FeADE84jSRIvPCrzYulw3sL
	try: items = CsaNhTtGm8[Vi1oNCM5kI7yJ0(u"ࠪ࡭ࡹ࡫࡭ࡴࠩଖ")]
	except: return Zg9FeADE84jSRIvPCrzYulw3sL
	if items:
		for pfQhOaqwdBS2k8ZiRA5MeXYUK,file in enumerate(items):
			path = file[Vi1oNCM5kI7yJ0(u"ࠫ࡫࡯࡬ࡦࠩଗ")]
			if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs not in path: continue
			path = path.split(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)[Mn5NGAdz6xc42s0][Mn5NGAdz6xc42s0:]
			if path==ijrVgHOUMs5Bo0ehTA8FtvcyXJDa: break
		count = CsaNhTtGm8[ykE045Tatx(u"ࠬࡲࡩ࡮࡫ࡷࡷࠬଘ")][NIBsHMvSXb(u"࠭ࡴࡰࡶࡤࡰࠬଙ")]
		if pfQhOaqwdBS2k8ZiRA5MeXYUK+Mn5NGAdz6xc42s0<count: VbC5kOBHYGSvceMlti = items[pfQhOaqwdBS2k8ZiRA5MeXYUK+Mn5NGAdz6xc42s0][zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡧ࡫࡯ࡩࠬଚ")]
	return VbC5kOBHYGSvceMlti
def yC2N01GBUPZAD():
	LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢࡾࡿࠪଛ"))
	JJ5z0Fier2SQyRONG1 = vvglE69OFKBm817Nkc if x9PULjztJOpu7b(u"ࠩ࡞ࡡࠬଜ") in str(LUuIzEwBV9Kti6ZXF782) else CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return JJ5z0Fier2SQyRONG1
def LpTv52e4Icnwms0OXRW6oACix(pKTqSyVP8dkFRE):
	global riaG0KXkbpxm
	if riaG0KXkbpxm:
		if pKTqSyVP8dkFRE==x9PULjztJOpu7b(u"ࠪࡷࡹࡵࡰࠨଝ"):
			qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM = NIBsHMvSXb(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩଞ") if NGiBmYp8vX9T426lHn7ue>A2MHFvoqpZ64gNbB(u"࠵࠼࠴࠹࠺୲") else qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩଟ")
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠭ଠ")+qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࠪࠩଡ"))
			riaG0KXkbpxm = vvglE69OFKBm817Nkc
	else:
		if pKTqSyVP8dkFRE==jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡵࡷࡥࡷࡺࠧଢ"):
			qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM = x9PULjztJOpu7b(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧଣ") if NGiBmYp8vX9T426lHn7ue>lU1fSmncFWjizwqZugyYBANML0(u"࠶࠽࠮࠺࠻୳") else qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧତ")
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(wFYiVd4r12x7CAQBL5SPof(u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭ଥ")+qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM+A2MHFvoqpZ64gNbB(u"ࠬ࠯ࠧଦ"))
			riaG0KXkbpxm = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return
ppbnL7jQMfPAU4IJSHTZG2dz1,Ow4B7PYozLC2hnT6ZlrqaekSb = None,None
TSbmULh6HJNxjRYV = []
fs60XkagtWFJ = EELfq0dKnyhZPxpA2jJrFsvXU()
qhr1Job3MC = fs60XkagtWFJ.splitlines()[UwCT5Oz6Wo0BP][-dn9ouNryjHiBFQOhASvX(u"࠸࠴୴"):]
XcPLKthYTV.zyKW1Eow48ek0,XcPLKthYTV.dMeaPykZB3Ln8DGuS,XcPLKthYTV.BdihkDomH03OAKgcaCM,XcPLKthYTV.opJSrWfgHQ7 = ZE3oYw0NMipGVt1zJ8yAULgq7nbdx([lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧଧ"),ttC4VURALPYKh(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨନ"),wFYiVd4r12x7CAQBL5SPof(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭଩"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪପ")])
ySqfAUYh0x8BPDio1MQsOLedzWN = Zg9FeADE84jSRIvPCrzYulw3sL
XcPLKthYTV.resolveonly = vvglE69OFKBm817Nkc
cFyv1OrHzwKe3UxiCb2 = c6orXChaFMiG8DKYyjs03dfWBVQA()
XcPLKthYTV.showDialogs = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
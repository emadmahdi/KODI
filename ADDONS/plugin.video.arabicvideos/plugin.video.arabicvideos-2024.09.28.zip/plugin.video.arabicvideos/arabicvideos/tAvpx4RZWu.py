# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'DAILYMOTION'
j0jSEdTPJuG4XNvfpO = '_DLM_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
p2tHwDRfg16WJ0IYF5xLXGa9S7us = PhpFa6EdVS[bIPsOxjEpoH][1]
def mp9gnhjBIoA8Rz3SylG(mode,url,text,type,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	if	 mode==400: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==401: CsaNhTtGm8 = Qx3BgESqFf649mb0eOdMHI(url,text)
	elif mode==402: CsaNhTtGm8 = KgeLyYbGhiTurSxta0E15Unfz(url,text)
	elif mode==403: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url,text)
	elif mode==404: CsaNhTtGm8 = ACgZ5RDLyJqlXfzSBMmutIrxs72o(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==405: CsaNhTtGm8 = zz5hHqtaYim2NgXB4PybECLQ8nZe(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==406: CsaNhTtGm8 = qXu9erUAF4R7OY0cvn(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==407: CsaNhTtGm8 = NmKLAyTu59b7vO6d(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==408: CsaNhTtGm8 = dscvV6AbmQeMCuUq(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==409: CsaNhTtGm8 = KkZtb4lhPd(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==411: CsaNhTtGm8 = AiSbx8NdGU3sWOk5Mt7Kn6BF(url,text)
	elif mode==414: CsaNhTtGm8 = i8AozMlXrwuh(text)
	elif mode==415: CsaNhTtGm8 = SBDeLN3gZsRXQJKVHx4ul8b(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==416: CsaNhTtGm8 = OOksGLd123hra7oMuti(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==417: CsaNhTtGm8 = RRmWyFH89k4OD3VQJwSZb(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الرئيسية',Zg9FeADE84jSRIvPCrzYulw3sL,414)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن فيديوهات',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'videos?sortBy=','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن آخر الفيديوهات',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن الفيديوهات الأكثر مشاهدة',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن قوائم التشغيل',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'playlists','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن مستخدم',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'channels','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن بث حي',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'lives','_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن هاشتاك',Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,'hashtags','_REMEMBERRESULTS_')
	return
def KgeLyYbGhiTurSxta0E15Unfz(url,mmZyA7ped4FXBEiuD):
	if '/dm_' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,False,Zg9FeADE84jSRIvPCrzYulw3sL,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = Pa6Q2LRkbtY0Id7nUNsZ.headers
		if 'Location' in list(headers.keys()): url = qfzHe2Yr49+headers['Location']
	mmZyA7ped4FXBEiuD = PPQORjT2lc7SVkKwFI4D+mmZyA7ped4FXBEiuD+u4IRSmrYMKkaHUBnDiLWh
	mmZyA7ped4FXBEiuD = ylesctgbK2pAz6(mmZyA7ped4FXBEiuD)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: بث حي',url,411,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'channel_lives_now')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: آخر الفيديوهات',url+'/videos',408)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: المميزة',url,411,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'channel_featured_videos')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: قوائم التشغيل',url+'/playlists',407)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: قنوات ذات صلة',url,411,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'channel_related_channel')
	return
def ylesctgbK2pAz6(title):
	title = title.rstrip('\\').strip(wjs26GpVfNiCUERHJ).replace('\\\\','\\')
	title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
	return title
def npRzZYjSm35wucxNPFlsTibVJeqI(url,Mles4QpWJtb0vzDZCj):
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([url],bIPsOxjEpoH,'video',url)
	return
def ACgZ5RDLyJqlXfzSBMmutIrxs72o(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = Zg9FeADE84jSRIvPCrzYulw3sL
	search = search.split('/videos')[0]
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	if sort==Zg9FeADE84jSRIvPCrzYulw3sL: YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysortmethod',Zg9FeADE84jSRIvPCrzYulw3sL)
	else: YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = qfzHe2Yr49+'/search/'+search+'/videos'
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"videos"(.*?)"VideoConnection"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,title,Y6lNcDd5gI18,mmZyA7ped4FXBEiuD,NAdtOanYBmF0IWbMvXxz7lERiTjo,W8KBRzkdhlCxvF5sY2T in items:
			if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in title: title = title.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in Y6lNcDd5gI18: Y6lNcDd5gI18 = Y6lNcDd5gI18.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in mmZyA7ped4FXBEiuD: mmZyA7ped4FXBEiuD = mmZyA7ped4FXBEiuD.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+id
			title = ylesctgbK2pAz6(title)
			Mles4QpWJtb0vzDZCj = Y6lNcDd5gI18+'::'+mmZyA7ped4FXBEiuD
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo,Mles4QpWJtb0vzDZCj)
		if '"hasNextPage":true' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,404,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def zz5hHqtaYim2NgXB4PybECLQ8nZe(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	url = qfzHe2Yr49+'/search/'+search+'/playlists'
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for id,name,Jw6bnsxBdmP0yhjfk9YtOolXAKUZ,Y6lNcDd5gI18,mmZyA7ped4FXBEiuD,W8KBRzkdhlCxvF5sY2T,count in items:
		if '"' in Jw6bnsxBdmP0yhjfk9YtOolXAKUZ: Jw6bnsxBdmP0yhjfk9YtOolXAKUZ = Jw6bnsxBdmP0yhjfk9YtOolXAKUZ.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in Y6lNcDd5gI18: Y6lNcDd5gI18 = Y6lNcDd5gI18.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in mmZyA7ped4FXBEiuD: mmZyA7ped4FXBEiuD = mmZyA7ped4FXBEiuD.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in name: name = name.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"' in count: count = count.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = ylesctgbK2pAz6(title)
		Mles4QpWJtb0vzDZCj = Y6lNcDd5gI18+'::'+mmZyA7ped4FXBEiuD
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,401,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,Mles4QpWJtb0vzDZCj)
	if '"hasNextPage":true' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,405,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def qXu9erUAF4R7OY0cvn(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	url = qfzHe2Yr49+'/search/'+search+'/channels'
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"channels"(.*?)"ChannelConnection"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,name,W8KBRzkdhlCxvF5sY2T in items:
			if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in name: name = name.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+id
			title = 'USER:  '+name
			title = ylesctgbK2pAz6(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,402,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,name)
		if '"hasNextPage":true' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,406,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def i8AozMlXrwuh(AwgQRsnlVuh9Gj0FL4):
	YYAz8aPFGR2n = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['home']['neon']['sections']['edges']
		if not AwgQRsnlVuh9Gj0FL4:
			SdMTDnaHyG2WOg3QmF0hbul = []
			for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
				B0pPeTEc4MFan2y5buH = xwbLg7DFQ0['node']['title']
				if B0pPeTEc4MFan2y5buH not in SdMTDnaHyG2WOg3QmF0hbul: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+B0pPeTEc4MFan2y5buH,Zg9FeADE84jSRIvPCrzYulw3sL,414,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,B0pPeTEc4MFan2y5buH)
				SdMTDnaHyG2WOg3QmF0hbul.append(B0pPeTEc4MFan2y5buH)
		else:
			for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
				B0pPeTEc4MFan2y5buH = xwbLg7DFQ0['node']['title']
				if B0pPeTEc4MFan2y5buH==AwgQRsnlVuh9Gj0FL4:
					H42kJjcnpQudyA5e6NwP7K0Tvfi = xwbLg7DFQ0['node']['components']['edges']
					for TIkrgw7vA4xF3SW in H42kJjcnpQudyA5e6NwP7K0Tvfi:
						NAdtOanYBmF0IWbMvXxz7lERiTjo = str(TIkrgw7vA4xF3SW['node']['duration'])
						title = uumhMi6O4pk7Gjd5aTQqy2Z(TIkrgw7vA4xF3SW['node']['title'])
						title = title.replace('\/','/')
						uVnxLzlHiOM0vCN9 = TIkrgw7vA4xF3SW['node']['xid']
						W8KBRzkdhlCxvF5sY2T = TIkrgw7vA4xF3SW['node']['thumbnailx480']
						W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('\/','/')
						yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+uVnxLzlHiOM0vCN9
						A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	return
def SBDeLN3gZsRXQJKVHx4ul8b(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	url = qfzHe2Yr49+'/search/'+search+'/lives'
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		try: Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['search']['lives']['edges']
		except: Qo1s0MfpanNSyVhxtDu4738jO56Kb = []
		for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
			name = xwbLg7DFQ0['node']['title']
			name = uumhMi6O4pk7Gjd5aTQqy2Z(name)
			uVnxLzlHiOM0vCN9 = xwbLg7DFQ0['node']['xid']
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+uVnxLzlHiOM0vCN9
			A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'LIVE: '+name,yDTPzhEBKVJl7CX81,403)
		if '"hasNextPage":true' in LWBtsX3i8TfPJxF:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,415,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def vvc2WTYiKxQVuXZhL7ma6DJIgOp8fq(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	url = qfzHe2Yr49+'/search/'+search+'/topics'
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		try: Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['search']['topics']['edges']
		except: Qo1s0MfpanNSyVhxtDu4738jO56Kb = []
		for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
			name = xwbLg7DFQ0['node']['name']
			uVnxLzlHiOM0vCN9 = xwbLg7DFQ0['node']['xid']
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/topic/'+uVnxLzlHiOM0vCN9
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'TOPIC: '+name,yDTPzhEBKVJl7CX81,413)
		if '"hasNextPage":true' in LWBtsX3i8TfPJxF:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,412,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def qaugyDMoiVmN59YhwsvU(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	uVnxLzlHiOM0vCN9 = url.split('/')[-1]
	YYAz8aPFGR2n = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mytopicid',uVnxLzlHiOM0vCN9)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['topic']['videos']['edges']
		for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
			NAdtOanYBmF0IWbMvXxz7lERiTjo = str(xwbLg7DFQ0['node']['duration'])
			title = uumhMi6O4pk7Gjd5aTQqy2Z(xwbLg7DFQ0['node']['title'])
			title = title.replace('\/','/')
			uVnxLzlHiOM0vCN9 = xwbLg7DFQ0['node']['xid']
			W8KBRzkdhlCxvF5sY2T = xwbLg7DFQ0['node']['thumbnailx480']
			W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('\/','/')
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+uVnxLzlHiOM0vCN9
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
		if '"hasNextPage":true' in LWBtsX3i8TfPJxF:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,413,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	return
def Qx3BgESqFf649mb0eOdMHI(url,Mles4QpWJtb0vzDZCj):
	id = url.split('/')[-1]
	Y6lNcDd5gI18,mmZyA7ped4FXBEiuD = Mles4QpWJtb0vzDZCj.split('::',1)
	yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+Y6lNcDd5gI18
	mmZyA7ped4FXBEiuD = ylesctgbK2pAz6(mmZyA7ped4FXBEiuD)
	title = PPQORjT2lc7SVkKwFI4D+'OWNER:  '+mmZyA7ped4FXBEiuD+u4IRSmrYMKkaHUBnDiLWh
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,402,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,mmZyA7ped4FXBEiuD)
	YYAz8aPFGR2n = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('myplaylistid',id)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"collection_videos"(.*?)"SectionEdge"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,title,NAdtOanYBmF0IWbMvXxz7lERiTjo,W8KBRzkdhlCxvF5sY2T,Y6lNcDd5gI18,mmZyA7ped4FXBEiuD in items:
			if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in title: title = title.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in Y6lNcDd5gI18: Y6lNcDd5gI18 = Y6lNcDd5gI18.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in mmZyA7ped4FXBEiuD: mmZyA7ped4FXBEiuD = mmZyA7ped4FXBEiuD.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+id
			title = ylesctgbK2pAz6(title)
			Mles4QpWJtb0vzDZCj = Y6lNcDd5gI18+'::'+mmZyA7ped4FXBEiuD
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo,Mles4QpWJtb0vzDZCj)
	return
def dscvV6AbmQeMCuUq(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	qS1RW5ZtAkYb = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	YYAz8aPFGR2n = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mychannelid',qS1RW5ZtAkYb)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysortmethod',sort)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,title,NAdtOanYBmF0IWbMvXxz7lERiTjo,Y6lNcDd5gI18,mmZyA7ped4FXBEiuD,W8KBRzkdhlCxvF5sY2T in items:
			if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in title: title = title.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in Y6lNcDd5gI18: Y6lNcDd5gI18 = Y6lNcDd5gI18.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in mmZyA7ped4FXBEiuD: mmZyA7ped4FXBEiuD = mmZyA7ped4FXBEiuD.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+id
			title = ylesctgbK2pAz6(title)
			Mles4QpWJtb0vzDZCj = Y6lNcDd5gI18+'::'+mmZyA7ped4FXBEiuD
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo,Mles4QpWJtb0vzDZCj)
		if '"hasNextPage":true' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,408,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	return
def NmKLAyTu59b7vO6d(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	qS1RW5ZtAkYb = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	YYAz8aPFGR2n = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mychannelid',qS1RW5ZtAkYb)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysortmethod',sort)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,name,W8KBRzkdhlCxvF5sY2T,count,Jw6bnsxBdmP0yhjfk9YtOolXAKUZ,Y6lNcDd5gI18,mmZyA7ped4FXBEiuD in items:
			if '"' in id: id = id.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in name: name = name.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in count: count = count.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in Jw6bnsxBdmP0yhjfk9YtOolXAKUZ: Jw6bnsxBdmP0yhjfk9YtOolXAKUZ = Jw6bnsxBdmP0yhjfk9YtOolXAKUZ.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in Y6lNcDd5gI18: Y6lNcDd5gI18 = Y6lNcDd5gI18.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '"' in mmZyA7ped4FXBEiuD: mmZyA7ped4FXBEiuD = mmZyA7ped4FXBEiuD.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = ylesctgbK2pAz6(title)
			Mles4QpWJtb0vzDZCj = Y6lNcDd5gI18+'::'+mmZyA7ped4FXBEiuD
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,401,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,Mles4QpWJtb0vzDZCj)
		if '"hasNextPage":true' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,407,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	return
def AiSbx8NdGU3sWOk5Mt7Kn6BF(url,uuGzjflWmRVtZ6wbMT9I2):
	qS1RW5ZtAkYb = url.split('/')[3]
	YYAz8aPFGR2n = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mychannelid',qS1RW5ZtAkYb)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	pp1RbYumgqyUZCXoFTcx = lSD9w50N6VBOHbfT2WRiPsM.loads(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	try: items = pp1RbYumgqyUZCXoFTcx['data']['channel'][uuGzjflWmRVtZ6wbMT9I2]['edges']
	except: items = []
	if not items: A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+'لا توجد نتائج',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	else:
		for r1OMYvp0ViTG in items:
			BaqEItKNyPwGgn = r1OMYvp0ViTG['node']
			uVnxLzlHiOM0vCN9 = BaqEItKNyPwGgn['xid']
			keys = list(BaqEItKNyPwGgn.keys())
			n3nImxtb9ukqT = BaqEItKNyPwGgn['__typename'].lower()
			if n3nImxtb9ukqT=='channel':
				name = BaqEItKNyPwGgn['name']
				WAJjiqLhtIYlm1fQEr67 = BaqEItKNyPwGgn['displayName']
				title = 'USER:  '+WAJjiqLhtIYlm1fQEr67
				W8KBRzkdhlCxvF5sY2T = BaqEItKNyPwGgn['coverURLx375']
			else:
				name = BaqEItKNyPwGgn['channel']['name']
				WAJjiqLhtIYlm1fQEr67 = BaqEItKNyPwGgn['channel']['displayName']
				title = BaqEItKNyPwGgn['title']
				W8KBRzkdhlCxvF5sY2T = BaqEItKNyPwGgn['thumbnailx360']
				if n3nImxtb9ukqT=='live': title = 'LIVE:  '+title
			title = ylesctgbK2pAz6(title)
			Mles4QpWJtb0vzDZCj = name+'::'+WAJjiqLhtIYlm1fQEr67
			if HByjTem6EJP5sZb:
				title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				Mles4QpWJtb0vzDZCj = Mles4QpWJtb0vzDZCj.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			if n3nImxtb9ukqT=='channel':
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+uVnxLzlHiOM0vCN9
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,402,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,Mles4QpWJtb0vzDZCj)
			else:
				if n3nImxtb9ukqT=='video': NAdtOanYBmF0IWbMvXxz7lERiTjo = str(BaqEItKNyPwGgn['duration'])
				else: NAdtOanYBmF0IWbMvXxz7lERiTjo = Zg9FeADE84jSRIvPCrzYulw3sL
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+uVnxLzlHiOM0vCN9
				A9Z3Ci2PQhFUwBXvI(n3nImxtb9ukqT,j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo,Mles4QpWJtb0vzDZCj)
	return
def OOksGLd123hra7oMuti(search,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	YYAz8aPFGR2n = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mysearchwords',search)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagelimit','40')
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	url = qfzHe2Yr49+'/search/'+search+'/hashtags'
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		try: Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['search']['hashtags']['edges']
		except: Qo1s0MfpanNSyVhxtDu4738jO56Kb = []
		for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
			name = xwbLg7DFQ0['node']['name']
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/hashtag/'+name[1:]
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'HSHTG: '+name,yDTPzhEBKVJl7CX81,417)
		if '"hasNextPage":true' in LWBtsX3i8TfPJxF:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,416,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,search)
	return
def RRmWyFH89k4OD3VQJwSZb(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p=Zg9FeADE84jSRIvPCrzYulw3sL):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	name = url.split('/')[-1]
	YYAz8aPFGR2n = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('myhashtagname',name)
	YYAz8aPFGR2n = YYAz8aPFGR2n.replace('mypagenumber',wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	LWBtsX3i8TfPJxF = PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n)
	if LWBtsX3i8TfPJxF:
		UZTziq1xNbtmHLK = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
		Qo1s0MfpanNSyVhxtDu4738jO56Kb = UZTziq1xNbtmHLK['data']['contentFeed']['edges']
		for xwbLg7DFQ0 in Qo1s0MfpanNSyVhxtDu4738jO56Kb:
			NAdtOanYBmF0IWbMvXxz7lERiTjo = str(xwbLg7DFQ0['node']['post']['duration'])
			title = uumhMi6O4pk7Gjd5aTQqy2Z(xwbLg7DFQ0['node']['post']['title'])
			title = title.replace('\/','/')
			uVnxLzlHiOM0vCN9 = xwbLg7DFQ0['node']['post']['xid']
			W8KBRzkdhlCxvF5sY2T = xwbLg7DFQ0['node']['post']['thumbnailx480']
			W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('\/','/')
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/video/'+uVnxLzlHiOM0vCN9
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,403,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
		if '"hasNextPage":true' in LWBtsX3i8TfPJxF:
			wlxviMOuNeQVct4ULsCEHXZm6yR2p = str(int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)+1)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+wlxviMOuNeQVct4ULsCEHXZm6yR2p,url,416,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	return
def PwXpdgRfC2BNS9Aiahr1qcGT(YYAz8aPFGR2n,search=Zg9FeADE84jSRIvPCrzYulw3sL):
	if GGfPQnrJKEqMv2ZVxdD: YYAz8aPFGR2n = YYAz8aPFGR2n.encode('utf-8')
	kOMewSQD5RX9VoFW7TB = kfnyQ49a6Owbc7HPgJjo()
	headers = {"Authorization":kOMewSQD5RX9VoFW7TB,"Origin":qfzHe2Yr49,'Content-Type':'text/plain; charset=utf-8'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',p2tHwDRfg16WJ0IYF5xLXGa9S7us,YYAz8aPFGR2n,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DAILYMOTION-GET_PAGEDATA-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def kfnyQ49a6Owbc7HPgJjo():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DAILYMOTION-GET_AUTHINTICATION-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	WpL8wjgNir7fDQT1GvEV = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var r="(.*?)",o="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	PjtafJIyk13QH5EqRVFcUClMxv8i,cOxIvVMDjGYn = WpL8wjgNir7fDQT1GvEV[-1]
	kpmIO90Bv4VDCuozPxf8GUdgN = 'https://graphql.api.dailymotion.com/oauth/token'
	ZEPzmr4ngh = 'client_credentials'
	data = {'client_id':PjtafJIyk13QH5EqRVFcUClMxv8i,'client_secret':cOxIvVMDjGYn,'grant_type':ZEPzmr4ngh}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',kpmIO90Bv4VDCuozPxf8GUdgN,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	WpL8wjgNir7fDQT1GvEV = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	qRfeXTH8ot5uCN0DzywlnW,WEDFwjUvhB4V6grYOHd5uPapItG9mL = WpL8wjgNir7fDQT1GvEV[0]
	kOMewSQD5RX9VoFW7TB = WEDFwjUvhB4V6grYOHd5uPapItG9mL+" "+qRfeXTH8ot5uCN0DzywlnW
	return kOMewSQD5RX9VoFW7TB
def KkZtb4lhPd(search,dycYjuzoBkZxN96TmG173VRqLs=Zg9FeADE84jSRIvPCrzYulw3sL):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not dycYjuzoBkZxN96TmG173VRqLs and showDialogs:
		hh7SKmegDAkMXBn = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('موقع ديلي موشن - اختر البحث',hh7SKmegDAkMXBn)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-1: return
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==0: dycYjuzoBkZxN96TmG173VRqLs = 'videos?sortBy='
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==1: dycYjuzoBkZxN96TmG173VRqLs = 'videos?sortBy=RECENT'
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==2: dycYjuzoBkZxN96TmG173VRqLs = 'videos?sortBy=VIEW_COUNT'
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==3: dycYjuzoBkZxN96TmG173VRqLs = 'playlists'
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==4: dycYjuzoBkZxN96TmG173VRqLs = 'channels'
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==5: dycYjuzoBkZxN96TmG173VRqLs = 'lives'
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==6: dycYjuzoBkZxN96TmG173VRqLs = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in NNYRDot8vC: dycYjuzoBkZxN96TmG173VRqLs = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in NNYRDot8vC: dycYjuzoBkZxN96TmG173VRqLs = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in NNYRDot8vC: dycYjuzoBkZxN96TmG173VRqLs = 'channels'
	elif '_DAILYMOTION-LIVES_' in NNYRDot8vC: dycYjuzoBkZxN96TmG173VRqLs = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in NNYRDot8vC: dycYjuzoBkZxN96TmG173VRqLs = 'hashtags'
	elif not dycYjuzoBkZxN96TmG173VRqLs: dycYjuzoBkZxN96TmG173VRqLs = 'videos?sortBy='
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	if 'videos' in dycYjuzoBkZxN96TmG173VRqLs: ACgZ5RDLyJqlXfzSBMmutIrxs72o(search+'/'+dycYjuzoBkZxN96TmG173VRqLs)
	elif 'playlists' in dycYjuzoBkZxN96TmG173VRqLs: zz5hHqtaYim2NgXB4PybECLQ8nZe(search)
	elif 'channels' in dycYjuzoBkZxN96TmG173VRqLs: qXu9erUAF4R7OY0cvn(search)
	elif 'lives' in dycYjuzoBkZxN96TmG173VRqLs: SBDeLN3gZsRXQJKVHx4ul8b(search)
	elif 'hashtags' in dycYjuzoBkZxN96TmG173VRqLs: OOksGLd123hra7oMuti(search)
	return
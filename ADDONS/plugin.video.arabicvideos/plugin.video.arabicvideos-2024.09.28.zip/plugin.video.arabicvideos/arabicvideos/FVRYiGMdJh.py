# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'CIMA4U'
headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
j0jSEdTPJuG4XNvfpO = '_C4U_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==420: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==421: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==422: CsaNhTtGm8 = gnvaFiNZjGSeMdPcTQzlVrfy84t9(url)
	elif mode==423: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==424: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==427: CsaNhTtGm8 = GGxUD2pWO3hmf5FQV7unBjiewcXrHy(url)
	elif mode==429: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Wtu1ZQ5yrA2KVlPs76EgbRvz = Wtu1ZQ5yrA2KVlPs76EgbRvz[0].strip('/')
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(Wtu1ZQ5yrA2KVlPs76EgbRvz,'url')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,429,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر محدد',Wtu1ZQ5yrA2KVlPs76EgbRvz,425)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر كامل',Wtu1ZQ5yrA2KVlPs76EgbRvz,424)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الرئيسية',Wtu1ZQ5yrA2KVlPs76EgbRvz,421)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('NavigationMenu(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="*(.*?)"*>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		if '/actors' in yDTPzhEBKVJl7CX81: title = 'أفلام النجوم'
		elif '/netflix' in yDTPzhEBKVJl7CX81: title = 'أفلام ومسلسلات نيتفلكس'
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,421)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'قائمة تفصيلية',Wtu1ZQ5yrA2KVlPs76EgbRvz,427)
	return
def GGxUD2pWO3hmf5FQV7unBjiewcXrHy(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('FilteringTitle(.*?)PageTitle',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for WWdHIOCPeKmgRstXk4c,id,yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		if 'netflix-movies' in yDTPzhEBKVJl7CX81: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in yDTPzhEBKVJl7CX81: title = 'مسلسلات نيتفلكس'
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,WWdHIOCPeKmgRstXk4c+'|'+id)
	return
def mbzIyKNqMVt0FQeOsPWc(url,AxYL8hm1sni5ej=Zg9FeADE84jSRIvPCrzYulw3sL):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if not AxYL8hm1sni5ej or '|' in AxYL8hm1sni5ej:
		if '|' not in AxYL8hm1sni5ej: CRAyWvqHKn8PZ7ucmIwfBXbsktzUj = Zg9FeADE84jSRIvPCrzYulw3sL
		else: CRAyWvqHKn8PZ7ucmIwfBXbsktzUj = '/archive/'+AxYL8hm1sni5ej
		BMRhxlqKtgFC6AUZWe5Tpd0b2rSn = False
		if 'PinSlider' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'المميزة',url,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
			BMRhxlqKtgFC6AUZWe5Tpd0b2rSn = True
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('PageTitle(.*?)PageContent',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			idOhoxawsrWQVgTMfGC6lBmDN7XEK = HNRenB3EZX62qgSKMd4f[0]
			QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-tab="(.*?)".*?<span>(.*?)<',idOhoxawsrWQVgTMfGC6lBmDN7XEK,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for zLFxyWN8i7E6oDm3uRZbalfTYKe,wUpHn5IfzaQ8g4j in QaVoNlxzSUORpb:
				WOry7DZPocFhH8p4 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/ajaxcenter/action/HomepageLoader/tab/'+zLFxyWN8i7E6oDm3uRZbalfTYKe+CRAyWvqHKn8PZ7ucmIwfBXbsktzUj+'/'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4,421)
				BMRhxlqKtgFC6AUZWe5Tpd0b2rSn = True
		if BMRhxlqKtgFC6AUZWe5Tpd0b2rSn: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	if AxYL8hm1sni5ej=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('PinSlider(.*?)MultiFilter',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('PinSlider(.*?)PageTitle',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		else: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Zg9FeADE84jSRIvPCrzYulw3sL
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	elif '/filter/' in url:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('PageContent(.*?)class="*pagination"*',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif '/actors' in url:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('PageContent(.*?)class="*pagination"*',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Cima4uBlocks(.*?)</li></ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		else: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Zg9FeADE84jSRIvPCrzYulw3sL
	if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		if not title: continue
		if '?news=' in yDTPzhEBKVJl7CX81: continue
		title = title.replace('مشاهدة ',Zg9FeADE84jSRIvPCrzYulw3sL)
		title = BtKvPnEQJx32Z(title)
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) حلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'حلقة' in title:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,422,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/actor/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,421,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,422,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f and AxYL8hm1sni5ej!='featured':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,421)
	g63NE7IqjuxsXknTw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('</li><a href="(.*?)".*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if g63NE7IqjuxsXknTw:
		yDTPzhEBKVJl7CX81,title = g63NE7IqjuxsXknTw[0]
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,421)
	return
def gnvaFiNZjGSeMdPcTQzlVrfy84t9(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-SEASONS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="WatchNow".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		url = HNRenB3EZX62qgSKMd4f[0]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-SEASONS-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('SeasonsSections(.*?)</div></div></div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if '/tag/' in url or '/actor' in url:
		mbzIyKNqMVt0FQeOsPWc(url)
	elif HNRenB3EZX62qgSKMd4f:
		W8KBRzkdhlCxvF5sY2T = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Thumb')
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href='(.*?)'>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nD2CjGuklAoYm8Ed4ZxBX = ['مسلسل','موسم','برنامج','حلقة']
		for yDTPzhEBKVJl7CX81,title in items:
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in nD2CjGuklAoYm8Ed4ZxBX):
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,423,W8KBRzkdhlCxvF5sY2T)
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,426,W8KBRzkdhlCxvF5sY2T)
	else: dHjny9tTucrO(url)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"background-image:url\((.*?)\)',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0]
	else: W8KBRzkdhlCxvF5sY2T = Zg9FeADE84jSRIvPCrzYulw3sL
	pB694VZaim183untF2dcM = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('EpisodesSection(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if pB694VZaim183untF2dcM:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = pB694VZaim183untF2dcM[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title,jjYXOr8QJsNUZv0PGL27ARSDceiq4 in items:
			title = title+wjs26GpVfNiCUERHJ+jjYXOr8QJsNUZv0PGL27ARSDceiq4
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,426,W8KBRzkdhlCxvF5sY2T)
	else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+'رابط التشغيل',url,426,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	QwMC0fvXn93UWV = Pa6Q2LRkbtY0Id7nUNsZ.url
	if HByjTem6EJP5sZb: QwMC0fvXn93UWV = QwMC0fvXn93UWV.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(QwMC0fvXn93UWV,'url')
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('WatchSection(.*?)</div></div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-link="(.*?)".*? />(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for B6xEjq29ihy4rDnfGLFC,title in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			if 'myvid' in title.lower(): title = 'خاص '+title
			yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/structure/server.php?id='+B6xEjq29ihy4rDnfGLFC+'?named='+title+'__watch'
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('DownloadServers(.*?)</div></div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*? />(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			if 'myvid' in title.lower(): wUpHn5IfzaQ8g4j = '__خاص'
			else: wUpHn5IfzaQ8g4j = Zg9FeADE84jSRIvPCrzYulw3sL
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'+wUpHn5IfzaQ8g4j
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/Search?q='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
def N3feaqwRugp50CJUtScZ781QBT(url):
	if 'smartemadfilter' not in url: url = G9GCDqXJFAc(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('MultiFilter(.*?)PageTitle',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	wAsQoW6l1DitrY7MC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	return wAsQoW6l1DitrY7MC
def b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA):
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-id="(.*?)".*?</div>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	return items
def GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(url):
	oWd0XOQnlD1PHbYmR = url.split('/smartemadfilter?')[0]
	G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(url,'url')
	url = url.replace(oWd0XOQnlD1PHbYmR,G7lNnPYTc3Am8jLxp)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
yycVIo28p69ZU3XRaCbYdP = ['category','types','release-year']
A7qnSMrihGeFTKZL8zmODNv1U = ['Quality','release-year','types','category']
def sF8AGonNID9x0J3TSUL2hd1Qjv(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Zg9FeADE84jSRIvPCrzYulw3sL: oorcIqYuTf6,LeoFXqubIsNmlZ0 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	else: oorcIqYuTf6,LeoFXqubIsNmlZ0 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global yycVIo28p69ZU3XRaCbYdP
			yycVIo28p69ZU3XRaCbYdP = yycVIo28p69ZU3XRaCbYdP[1:]
		if yycVIo28p69ZU3XRaCbYdP[0]+'=' not in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[0]
		for YjZN3ADmertFahUQIECW in range(len(yycVIo28p69ZU3XRaCbYdP[0:-1])):
			if yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW]+'=' in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW+1]
		PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL.strip('&')+'___'+OOYBCTKMVyFR3lpLNP.strip('&')
		YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
	elif type=='ALL_ITEMS_FILTER':
		KK2pncrBCsGVagozjlQIb5dAD7k = kt4gOnZ7y6A0ifpW1L8VJFDaR(oorcIqYuTf6,'modified_values')
		KK2pncrBCsGVagozjlQIb5dAD7k = UAjMPLdITqWChbrcB(KK2pncrBCsGVagozjlQIb5dAD7k)
		if LeoFXqubIsNmlZ0!=Zg9FeADE84jSRIvPCrzYulw3sL: LeoFXqubIsNmlZ0 = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		if LeoFXqubIsNmlZ0==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+LeoFXqubIsNmlZ0
		hc5ePKxl4LJvEjDgTm = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(hc5ePKxl4LJvEjDgTm)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أظهار قائمة الفيديو التي تم اختيارها ',hc5ePKxl4LJvEjDgTm,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'filter')
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' [[   '+KK2pncrBCsGVagozjlQIb5dAD7k+'   ]]',hc5ePKxl4LJvEjDgTm,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'filter')
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	wAsQoW6l1DitrY7MC = N3feaqwRugp50CJUtScZ781QBT(url)
	dict = {}
	for name,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,ddFeJa6wxq2zNMPsjth9bZAmVO in wAsQoW6l1DitrY7MC:
		if '/category/' in url and ddFeJa6wxq2zNMPsjth9bZAmVO=='category': continue
		name = name.replace('--',Zg9FeADE84jSRIvPCrzYulw3sL)
		items = b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
		if '=' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = url
		if type=='SPECIFIED_FILTER':
			if WWdHIOCPeKmgRstXk4c!=ddFeJa6wxq2zNMPsjth9bZAmVO: continue
			elif len(items)<2:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]:
					url = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(url)
					mbzIyKNqMVt0FQeOsPWc(url)
				else: sF8AGonNID9x0J3TSUL2hd1Qjv(hc5ePKxl4LJvEjDgTm,'SPECIFIED_FILTER___'+JDm4zR9r37vHg)
				return
			else:
				hc5ePKxl4LJvEjDgTm = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(hc5ePKxl4LJvEjDgTm)
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'filter')
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,425,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		elif type=='ALL_ITEMS_FILTER':
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع :'+name,hc5ePKxl4LJvEjDgTm,424,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		dict[ddFeJa6wxq2zNMPsjth9bZAmVO] = {}
		for B251BPiLbvG9UxszKtlI7YQHmoWw,xWfrLDQiMOA358ghbsZk6PtSK in items:
			if B251BPiLbvG9UxszKtlI7YQHmoWw=='196533': xWfrLDQiMOA358ghbsZk6PtSK = 'أفلام نيتفلكس'
			elif B251BPiLbvG9UxszKtlI7YQHmoWw=='196531': xWfrLDQiMOA358ghbsZk6PtSK = 'مسلسلات نيتفلكس'
			if xWfrLDQiMOA358ghbsZk6PtSK in Uhe07PlWNakHDZc1t: continue
			dict[ddFeJa6wxq2zNMPsjth9bZAmVO][B251BPiLbvG9UxszKtlI7YQHmoWw] = xWfrLDQiMOA358ghbsZk6PtSK
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+xWfrLDQiMOA358ghbsZk6PtSK
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
			OOiZSE1AIGsxBp0PqUo4bHgQ8u7 = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			title = xWfrLDQiMOA358ghbsZk6PtSK+' :'#+dict[ddFeJa6wxq2zNMPsjth9bZAmVO]['0']
			title = xWfrLDQiMOA358ghbsZk6PtSK+' :'+name
			if type=='ALL_ITEMS_FILTER': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,424,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
			elif type=='SPECIFIED_FILTER' and yycVIo28p69ZU3XRaCbYdP[-2]+'=' in oorcIqYuTf6:
				YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(OOYBCTKMVyFR3lpLNP,'modified_filters')
				JaqiYfEglZDvmwQNS8zR = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
				JaqiYfEglZDvmwQNS8zR = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(JaqiYfEglZDvmwQNS8zR)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,JaqiYfEglZDvmwQNS8zR,421,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'filter')
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,425,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
	return
def kt4gOnZ7y6A0ifpW1L8VJFDaR(fn9dgJ0v1KVrZ,mode):
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.replace('=&','=0&')
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.strip('&')
	vJfWILDinBuPZjcUamEHlq = {}
	if '=' in fn9dgJ0v1KVrZ:
		items = fn9dgJ0v1KVrZ.split('&')
		for r1OMYvp0ViTG in items:
			MnwlGZ9Ef3S7kv5sxtzRiFaoCIb,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=')
			vJfWILDinBuPZjcUamEHlq[MnwlGZ9Ef3S7kv5sxtzRiFaoCIb] = B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = Zg9FeADE84jSRIvPCrzYulw3sL
	for key in A7qnSMrihGeFTKZL8zmODNv1U:
		if key in list(vJfWILDinBuPZjcUamEHlq.keys()): B251BPiLbvG9UxszKtlI7YQHmoWw = vJfWILDinBuPZjcUamEHlq[key]
		else: B251BPiLbvG9UxszKtlI7YQHmoWw = '0'
		if '%' not in B251BPiLbvG9UxszKtlI7YQHmoWw: B251BPiLbvG9UxszKtlI7YQHmoWw = OJYiDeyvSPTNI9(B251BPiLbvG9UxszKtlI7YQHmoWw)
		if mode=='modified_values' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+' + '+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='modified_filters' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='all': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip(' + ')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip('&')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.replace('=0','=')
	return PJlIOHanFyNWTgfswRdYXvei4x0Vh
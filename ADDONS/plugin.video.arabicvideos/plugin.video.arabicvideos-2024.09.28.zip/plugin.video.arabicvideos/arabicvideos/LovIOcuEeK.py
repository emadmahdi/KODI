# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'FARESKO'
j0jSEdTPJuG4XNvfpO = '_FSK_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['الرئيسية','يلا شوت']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==990: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==991: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==992: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==993: CsaNhTtGm8 = YiI6CZGR28s1fyjbF5XeToc7uS9(url)
	elif mode==999: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,999,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"primary-links"(.*?)</u',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<span>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,991)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"list-categories"(.*?)</u',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81.lstrip('/')
			if title in Uhe07PlWNakHDZc1t: continue
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,991)
	return
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"home-content"(.*?)"footer"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('"overlay"','"duration"><')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		cfUCuhJwZijTLxQX3gHayn89RqGrP = []
		for W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo,yDTPzhEBKVJl7CX81,title in items:
			title = title.strip(' ')
			title = BtKvPnEQJx32Z(title)
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if 'episodes' not in type and jjYXOr8QJsNUZv0PGL27ARSDceiq4:
				title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
				title = title.replace('اون لاين',Zg9FeADE84jSRIvPCrzYulw3sL)
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,993,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,992,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''["']pagination["'](.*?)["']footer["']''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,991,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
	else:
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('load-next-button" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة جديدة',yDTPzhEBKVJl7CX81[0],991,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
	return
def YiI6CZGR28s1fyjbF5XeToc7uS9(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-SERIES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="eplist"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		bbl9kf1oL2 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in bbl9kf1oL2:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,992)
	else:
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"category".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
			mbzIyKNqMVt0FQeOsPWc(yDTPzhEBKVJl7CX81,'episodes')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0,EaK7fXz6F9AbMJptQ12HlweoBd = [],[]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if 'hash=' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		U1JgZe0prK4SbaAEylvz5iu = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('hash=(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		U1JgZe0prK4SbaAEylvz5iu = list(set(U1JgZe0prK4SbaAEylvz5iu))
		for L1LtcvTxI4q in U1JgZe0prK4SbaAEylvz5iu:
			fZRyFowAQ270d3k6icH = []
			Gi82lgtIxVsjSyqZU5EmBLkKw = L1LtcvTxI4q.split('__')
			for Tfv3JCqQc5mht04EzpUn in Gi82lgtIxVsjSyqZU5EmBLkKw:
				try:
					Tfv3JCqQc5mht04EzpUn = JDMo92nlwsAZydBPkpNzFvU.b64decode(Tfv3JCqQc5mht04EzpUn+'=')
					if GGfPQnrJKEqMv2ZVxdD: Tfv3JCqQc5mht04EzpUn = Tfv3JCqQc5mht04EzpUn.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
					fZRyFowAQ270d3k6icH.append(Tfv3JCqQc5mht04EzpUn)
				except: pass
			CPv45ibdnBc = '>'.join(fZRyFowAQ270d3k6icH)
			CPv45ibdnBc = CPv45ibdnBc.splitlines()
			for yDTPzhEBKVJl7CX81 in CPv45ibdnBc:
				if ' => ' in yDTPzhEBKVJl7CX81:
					title,yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split(' => ')
					yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	elif 'post_id' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		BmVyhAve6X2PYuI = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("post_id = '(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if BmVyhAve6X2PYuI:
			BmVyhAve6X2PYuI = BmVyhAve6X2PYuI[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			egkm3G4QjapLvH1fITb = qfzHe2Yr49+'/wp-admin/admin-ajax.php?action=video_info&post_id='+BmVyhAve6X2PYuI
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',egkm3G4QjapLvH1fITb,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-PLAY-2nd')
			RvsO9pXSDybKA7fJuWtxnm = Pa6Q2LRkbtY0Id7nUNsZ.content
			e0np6rIOl9ZASdYGuWgBy = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"name":"(.*?)","src":"(.*?)"',RvsO9pXSDybKA7fJuWtxnm,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not e0np6rIOl9ZASdYGuWgBy:
				e0np6rIOl9ZASdYGuWgBy = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"src":"(.*?)"',RvsO9pXSDybKA7fJuWtxnm,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if e0np6rIOl9ZASdYGuWgBy:
					gbELxf98dUqYMBrslDvoPuh4meK = ['']*len(e0np6rIOl9ZASdYGuWgBy)
					e0np6rIOl9ZASdYGuWgBy = list(zip(gbELxf98dUqYMBrslDvoPuh4meK,e0np6rIOl9ZASdYGuWgBy))
			for name,yDTPzhEBKVJl7CX81 in e0np6rIOl9ZASdYGuWgBy:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\/','/')
				yDTPzhEBKVJl7CX81 = OJYiDeyvSPTNI9(yDTPzhEBKVJl7CX81)
				if yDTPzhEBKVJl7CX81 in EaK7fXz6F9AbMJptQ12HlweoBd: continue
				else: EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+name+'__watch')
			WOry7DZPocFhH8p4 = qfzHe2Yr49+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+BmVyhAve6X2PYuI+'&video_id=null&video_url=null&video_source=custom'
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',WOry7DZPocFhH8p4,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FARESKO-PLAY-3rd')
			CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
			XIjfZxROq83HGaP = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if XIjfZxROq83HGaP:
				CltK3qQFZNOXUj,kKhaHMXT9VLfGz = zip(*XIjfZxROq83HGaP)
				XIjfZxROq83HGaP = list(zip(kKhaHMXT9VLfGz,CltK3qQFZNOXUj))
			for name,yDTPzhEBKVJl7CX81 in XIjfZxROq83HGaP:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\/','/')
				yDTPzhEBKVJl7CX81 = OJYiDeyvSPTNI9(yDTPzhEBKVJl7CX81)
				if yDTPzhEBKVJl7CX81 in EaK7fXz6F9AbMJptQ12HlweoBd: continue
				else: EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+name+'__download')
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/?s='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
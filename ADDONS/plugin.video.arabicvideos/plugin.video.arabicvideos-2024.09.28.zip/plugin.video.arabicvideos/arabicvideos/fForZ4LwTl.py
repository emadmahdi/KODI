# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'CIMACLUP'
j0jSEdTPJuG4XNvfpO = '_CMC_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['موقع نتفليكس']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==490: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==491: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==492: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==493: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==494: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==499: CsaNhTtGm8 = KkZtb4lhPd(text,url)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Wtu1ZQ5yrA2KVlPs76EgbRvz = Wtu1ZQ5yrA2KVlPs76EgbRvz[0].strip('/')
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(Wtu1ZQ5yrA2KVlPs76EgbRvz,'url')
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"filter AjaxifyFilter"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-filter="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/wp-content/themes/old/filter/'+yDTPzhEBKVJl7CX81+'.php'
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,491)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'أفلام',Wtu1ZQ5yrA2KVlPs76EgbRvz+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'مسلسلات',Wtu1ZQ5yrA2KVlPs76EgbRvz+'/category/مسلسلات/مسلسلات-اجنبى',494,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="navigation-menu"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if yDTPzhEBKVJl7CX81=='/': continue
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+yDTPzhEBKVJl7CX81
		if title in Uhe07PlWNakHDZc1t: continue
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,491)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def hkO9B6NystZxC1VDvWe(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"filter"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,491)
	return
def mbzIyKNqMVt0FQeOsPWc(url,AxYL8hm1sni5ej=Zg9FeADE84jSRIvPCrzYulw3sL):
	items = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Zg9FeADE84jSRIvPCrzYulw3sL
	if '.php' in url: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	elif '?s=' in url:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"blocks(.*?)"manifest"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"Blocks(.*?)"manifest"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if not nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA: return
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		title = BtKvPnEQJx32Z(title)
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) حلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not jjYXOr8QJsNUZv0PGL27ARSDceiq4: jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not jjYXOr8QJsNUZv0PGL27ARSDceiq4 or any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,492,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'حلقة' in title:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,493,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,493,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<li><a href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,491)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"ButtonsBarCo".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm:
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[0]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-EPISODES-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"img-responsive" src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0]
	else: W8KBRzkdhlCxvF5sY2T = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Thumb')
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"filter"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"Blocks(.*?)class="pagination"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr and '/series/' not in url:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,493,W8KBRzkdhlCxvF5sY2T)
	elif sQPyfIOFgKLTU4u23XB6dmS9:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
				title = title.strip(wjs26GpVfNiCUERHJ)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,492,W8KBRzkdhlCxvF5sY2T)
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				title = BtKvPnEQJx32Z(title)
				title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
				if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,491)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	hc5ePKxl4LJvEjDgTm = url.strip('/')+'/?view=1'
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMACLUP-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	WWfE1V8SsQ2Ry6jpXbBkC9znM40q = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("data: 'q=(.*?)&",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	WWfE1V8SsQ2Ry6jpXbBkC9znM40q = WWfE1V8SsQ2Ry6jpXbBkC9znM40q[0]
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"serversList"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-server="(.*?)">(.*?)</li>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for AKCwXZzMN6,title in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/wp-content/themes/old/servers/server.php?q='+WWfE1V8SsQ2Ry6jpXbBkC9znM40q+'&i='+AKCwXZzMN6+'?named='+title+'__watch'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"embedServer".*?SRC="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		title = 'مفضل'
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]+'?named=__embed__'+title
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"downloadsList"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<td>(.*?)</td>.*?href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for title,yDTPzhEBKVJl7CX81 in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			if 'anavidz' in yDTPzhEBKVJl7CX81: wUpHn5IfzaQ8g4j = '__خاص'
			else: wUpHn5IfzaQ8g4j = Zg9FeADE84jSRIvPCrzYulw3sL
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'+wUpHn5IfzaQ8g4j
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search,Wtu1ZQ5yrA2KVlPs76EgbRvz=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not Wtu1ZQ5yrA2KVlPs76EgbRvz: Wtu1ZQ5yrA2KVlPs76EgbRvz = qfzHe2Yr49
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/index.php?s='+search
	mbzIyKNqMVt0FQeOsPWc(url)
	return
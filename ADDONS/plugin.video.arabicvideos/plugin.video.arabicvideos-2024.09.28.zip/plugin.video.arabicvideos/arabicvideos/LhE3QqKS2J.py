# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'SHOOFMAX'
j0jSEdTPJuG4XNvfpO = '_SHM_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
p2tHwDRfg16WJ0IYF5xLXGa9S7us = PhpFa6EdVS[bIPsOxjEpoH][1]
iHXu7vrG8q = PhpFa6EdVS[bIPsOxjEpoH][2]
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==50: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==51: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	elif mode==52: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==53: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==55: CsaNhTtGm8 = oWi1R5q4YtgUj6()
	elif mode==56: CsaNhTtGm8 = WbvlInFDQco()
	elif mode==57: CsaNhTtGm8 = rciJ8GmyFHAlos0ba(url,1)
	elif mode==58: CsaNhTtGm8 = rciJ8GmyFHAlos0ba(url,2)
	elif mode==59: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,59,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المسلسلات',Zg9FeADE84jSRIvPCrzYulw3sL,56)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الافلام',Zg9FeADE84jSRIvPCrzYulw3sL,55)
	return Zg9FeADE84jSRIvPCrzYulw3sL
def oWi1R5q4YtgUj6():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أفلام مرتبة بسنة الإنتاج',qfzHe2Yr49+'/movie/1/yop',57)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أفلام مرتبة بالأفضل تقييم',qfzHe2Yr49+'/movie/1/review',57)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أفلام مرتبة بالأكثر مشاهدة',qfzHe2Yr49+'/movie/1/views',57)
	return
def WbvlInFDQco():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مسلسلات مرتبة بسنة الإنتاج',qfzHe2Yr49+'/series/1/yop',57)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مسلسلات مرتبة بالأفضل تقييم',qfzHe2Yr49+'/series/1/review',57)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مسلسلات مرتبة بالأكثر مشاهدة',qfzHe2Yr49+'/series/1/views',57)
	return
def mbzIyKNqMVt0FQeOsPWc(url):
	if '?' in url:
		Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('?')
		url = Gi82lgtIxVsjSyqZU5EmBLkKw[0]
		filter = '?' + OJYiDeyvSPTNI9(Gi82lgtIxVsjSyqZU5EmBLkKw[1],'=&:/%')
	else: filter = Zg9FeADE84jSRIvPCrzYulw3sL
	type,wlxviMOuNeQVct4ULsCEHXZm6yR2p,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': wAmCd4R5vU='فيلم'
		elif type=='series': wAmCd4R5vU='مسلسل'
		url = qfzHe2Yr49 + '/genre/filter/' + OJYiDeyvSPTNI9(wAmCd4R5vU) + '/' + wlxviMOuNeQVct4ULsCEHXZm6yR2p + '/' + sort + filter
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-TITLES-1st')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		xxnJoUvf2cSybhl=0
		for id,title,GGSoUqCcbHrE0ZmlsDwX,W8KBRzkdhlCxvF5sY2T in items:
			xxnJoUvf2cSybhl += 1
			W8KBRzkdhlCxvF5sY2T = iHXu7vrG8q + '/v2/img/program/main/' + W8KBRzkdhlCxvF5sY2T + '-2.jpg'
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + '/program/' + id
			if type=='movie': A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,53,W8KBRzkdhlCxvF5sY2T)
			if type=='series': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مسلسل '+title,yDTPzhEBKVJl7CX81+'?ep='+GGSoUqCcbHrE0ZmlsDwX+'='+title+'='+W8KBRzkdhlCxvF5sY2T,52,W8KBRzkdhlCxvF5sY2T)
	else:
		if type=='movie': wAmCd4R5vU='movies'
		elif type=='series': wAmCd4R5vU='series'
		url = p2tHwDRfg16WJ0IYF5xLXGa9S7us + '/json/selected/' + sort + '-' + wAmCd4R5vU + '-WW.json'
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-TITLES-2nd')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		xxnJoUvf2cSybhl=0
		for id,GGSoUqCcbHrE0ZmlsDwX,W8KBRzkdhlCxvF5sY2T,title in items:
			xxnJoUvf2cSybhl += 1
			W8KBRzkdhlCxvF5sY2T = p2tHwDRfg16WJ0IYF5xLXGa9S7us + '/img/program/' + W8KBRzkdhlCxvF5sY2T + '-2.jpg'
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + '/program/' + id
			if type=='movie': A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,53,W8KBRzkdhlCxvF5sY2T)
			elif type=='series': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مسلسل '+title,yDTPzhEBKVJl7CX81+'?ep='+GGSoUqCcbHrE0ZmlsDwX+'='+title+'='+W8KBRzkdhlCxvF5sY2T,52,W8KBRzkdhlCxvF5sY2T)
	title='صفحة '
	if xxnJoUvf2cSybhl==16:
		for wwybmRCecB4fsZp in range(1,13) :
			if not wlxviMOuNeQVct4ULsCEHXZm6yR2p==str(wwybmRCecB4fsZp):
				url = qfzHe2Yr49+'/genre/filter/'+type+'/'+str(wwybmRCecB4fsZp)+'/'+sort+filter
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title+str(wwybmRCecB4fsZp),url,51)
	return
def dHjny9tTucrO(url):
	Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('=')
	GGSoUqCcbHrE0ZmlsDwX = int(Gi82lgtIxVsjSyqZU5EmBLkKw[1])
	name = UAjMPLdITqWChbrcB(Gi82lgtIxVsjSyqZU5EmBLkKw[2])
	name = name.replace('_MOD_مسلسل ',Zg9FeADE84jSRIvPCrzYulw3sL)
	W8KBRzkdhlCxvF5sY2T = Gi82lgtIxVsjSyqZU5EmBLkKw[3]
	url = url.split('?')[0]
	if GGSoUqCcbHrE0ZmlsDwX==0:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-EPISODES-1st')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<select(.*?)</select>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('option value="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		GGSoUqCcbHrE0ZmlsDwX = int(items[-1])
	for jjYXOr8QJsNUZv0PGL27ARSDceiq4 in range(GGSoUqCcbHrE0ZmlsDwX,0,-1):
		yDTPzhEBKVJl7CX81 = url + '?ep=' + str(jjYXOr8QJsNUZv0PGL27ARSDceiq4)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(jjYXOr8QJsNUZv0PGL27ARSDceiq4)
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,53,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-PLAY-1st')
	HjBxCWwqduUSkg4P3Fv9fcnzOh = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HjBxCWwqduUSkg4P3Fv9fcnzOh:
		LNma2eq3vEguwVtHjn = HjBxCWwqduUSkg4P3Fv9fcnzOh[1].replace('T',z1LI6x7aofZnmb)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+LNma2eq3vEguwVtHjn)
		return
	bblfzZ1KqP35tCiwR9Erx40VjHc7mA,A4dez9lSKWNiIHkFPZ8pf = [],[]
	kuiRLZM5SlVxC6PjOd = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var origin_link = "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	EEwj6W7lQrzCXiD2J0PNBV = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var backup_origin_link = "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('hls: (.*?)_link\+"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for m0t48jnKhrQFJViguoMl9NBPp,yDTPzhEBKVJl7CX81 in CPv45ibdnBc:
		if 'backup' in m0t48jnKhrQFJViguoMl9NBPp:
			m0t48jnKhrQFJViguoMl9NBPp = 'backup server'
			url = EEwj6W7lQrzCXiD2J0PNBV + yDTPzhEBKVJl7CX81
		else:
			m0t48jnKhrQFJViguoMl9NBPp = 'main server'
			url = kuiRLZM5SlVxC6PjOd + yDTPzhEBKVJl7CX81
		if '.m3u8' in url:
			bblfzZ1KqP35tCiwR9Erx40VjHc7mA.append(url)
			A4dez9lSKWNiIHkFPZ8pf.append('m3u8  '+m0t48jnKhrQFJViguoMl9NBPp)
	CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	CPv45ibdnBc += aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for m0t48jnKhrQFJViguoMl9NBPp,yDTPzhEBKVJl7CX81 in CPv45ibdnBc:
		filename = yDTPzhEBKVJl7CX81.split('/')[-1]
		filename = filename.replace('fallback',Zg9FeADE84jSRIvPCrzYulw3sL)
		filename = filename.replace('.mp4',Zg9FeADE84jSRIvPCrzYulw3sL)
		filename = filename.replace('-',Zg9FeADE84jSRIvPCrzYulw3sL)
		if 'backup' in m0t48jnKhrQFJViguoMl9NBPp:
			m0t48jnKhrQFJViguoMl9NBPp = 'backup server'
			url = EEwj6W7lQrzCXiD2J0PNBV + yDTPzhEBKVJl7CX81
		else:
			m0t48jnKhrQFJViguoMl9NBPp = 'main server'
			url = kuiRLZM5SlVxC6PjOd + yDTPzhEBKVJl7CX81
		bblfzZ1KqP35tCiwR9Erx40VjHc7mA.append(url)
		A4dez9lSKWNiIHkFPZ8pf.append('mp4  '+m0t48jnKhrQFJViguoMl9NBPp+F4skx1A3wOEh9lmPuZMnpCzR+filename)
	lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('Select Video Quality:', A4dez9lSKWNiIHkFPZ8pf)
	if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1 : return
	url = bblfzZ1KqP35tCiwR9Erx40VjHc7mA[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	nTdpZOCUe7l(url,bIPsOxjEpoH,'video')
	return
def rciJ8GmyFHAlos0ba(url,type):
	if 'series' in url: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49 + '/genre/مسلسل'
	else: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49 + '/genre/فيلم'
	hc5ePKxl4LJvEjDgTm = OJYiDeyvSPTNI9(hc5ePKxl4LJvEjDgTm)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-FILTERS-1st')
	if type==1: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('subgenre(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif type==2: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('country(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('option value="(.*?)">(.*?)</option',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if type==1:
		for QQIKWNBwqp2xf6hr,title in items:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url+'?subgenre='+QQIKWNBwqp2xf6hr,58)
	elif type==2:
		url,QQIKWNBwqp2xf6hr = url.split('?')
		for yZ8XuBSf1M0NvqILAnYQGd36,title in items:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url+'?country='+yZ8XuBSf1M0NvqILAnYQGd36+'&'+QQIKWNBwqp2xf6hr,51)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search: search = EnxNsqevtM28mpkZ5RG0()
	if not search: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'%20')
	url = qfzHe2Yr49+'/search?q='+IGh3FSLfnog2BjN8s
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOOFMAX-SEARCH-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('general-body(.*?)search-bottom-padding',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			url = qfzHe2Yr49 + yDTPzhEBKVJl7CX81
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+OJYiDeyvSPTNI9(title)+'='+W8KBRzkdhlCxvF5sY2T
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,52,W8KBRzkdhlCxvF5sY2T)
				else:
					title = '_MOD_فيلم '+title
					A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,url,53,W8KBRzkdhlCxvF5sY2T)
	return
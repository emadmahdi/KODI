# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'TVFUN'
j0jSEdTPJuG4XNvfpO = '_TVF_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['بث مباشر']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==460: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==461: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==462: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==463: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==469: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'TVFUN-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,469,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"menu-btn"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<span>(.*?)</span>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in Uhe07PlWNakHDZc1t: continue
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,461)
	return
def mbzIyKNqMVt0FQeOsPWc(url,AxYL8hm1sni5ej=Zg9FeADE84jSRIvPCrzYulw3sL):
	items = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'TVFUN-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="head-title"(.*?)id="footer"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		cfUCuhJwZijTLxQX3gHayn89RqGrP = []
		uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			title = '_MOD_'+title.replace('<br>',wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).strip(wjs26GpVfNiCUERHJ)
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81)
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,462,W8KBRzkdhlCxvF5sY2T)
			elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'الحلقة' in title:
				title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,463,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,463,W8KBRzkdhlCxvF5sY2T)
	if AxYL8hm1sni5ej!='latest':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<a href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.strip(wjs26GpVfNiCUERHJ)
				if yDTPzhEBKVJl7CX81=="": continue
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
				if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,461)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'TVFUN-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="head-title"(.*?)id="footer"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
				title = '_MOD_'+title.replace('<br>',wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).strip(wjs26GpVfNiCUERHJ)
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,462,W8KBRzkdhlCxvF5sY2T)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="episode.*?href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,462)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.strip(wjs26GpVfNiCUERHJ)
			if yDTPzhEBKVJl7CX81=="": continue
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,463)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	hc5ePKxl4LJvEjDgTm = url.replace('/video/','/watch/')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'TVFUN-PLAY-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('VideoServers"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for Y65YT7juUnzFIJwGcyZMpO,name in CPv45ibdnBc:
			Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO[2:]
			if HByjTem6EJP5sZb: Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			Y65YT7juUnzFIJwGcyZMpO = JDMo92nlwsAZydBPkpNzFvU.b64decode(Y65YT7juUnzFIJwGcyZMpO)
			if GGfPQnrJKEqMv2ZVxdD: Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',Y65YT7juUnzFIJwGcyZMpO,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
			if 'http' not in yDTPzhEBKVJl7CX81:
				if '//' in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
				else: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+name+'__watch'
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	if wjs26GpVfNiCUERHJ in search:
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = qfzHe2Yr49+'/q/'+search+'/'
	mbzIyKNqMVt0FQeOsPWc(url)
	return
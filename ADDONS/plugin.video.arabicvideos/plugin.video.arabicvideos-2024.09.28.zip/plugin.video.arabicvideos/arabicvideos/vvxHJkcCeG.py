# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'LIVETV'
qfzHe2Yr49 = PhpFa6EdVS['PYTHON'][0]
def mp9gnhjBIoA8Rz3SylG(mode,url):
	if   mode==100: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==101: CsaNhTtGm8 = yfWYTB58bDO('0',True)
	elif mode==102: CsaNhTtGm8 = yfWYTB58bDO('1',True)
	elif mode==103: CsaNhTtGm8 = yfWYTB58bDO('2',True)
	elif mode==104: CsaNhTtGm8 = yfWYTB58bDO('3',True)
	elif mode==105: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==106: CsaNhTtGm8 = yfWYTB58bDO('4',True)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder','_M3U_'+'قوائم فيديوهات M3U',Zg9FeADE84jSRIvPCrzYulw3sL,762)
	A9Z3Ci2PQhFUwBXvI('folder','_IPT_'+'قوائم فيديوهات IPTV',Zg9FeADE84jSRIvPCrzYulw3sL,761)
	A9Z3Ci2PQhFUwBXvI('folder','_TV0_'+'قنوات من مواقعها الأصلية',Zg9FeADE84jSRIvPCrzYulw3sL,101)
	A9Z3Ci2PQhFUwBXvI('folder','_TV4_'+'قنوات مختارة من يوتيوب',Zg9FeADE84jSRIvPCrzYulw3sL,106)
	A9Z3Ci2PQhFUwBXvI('folder','_YUT_'+'قنوات عربية من يوتيوب',Zg9FeADE84jSRIvPCrzYulw3sL,147)
	A9Z3Ci2PQhFUwBXvI('folder','_YUT_'+'قنوات أجنبية من يوتيوب',Zg9FeADE84jSRIvPCrzYulw3sL,148)
	A9Z3Ci2PQhFUwBXvI('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',Zg9FeADE84jSRIvPCrzYulw3sL,28)
	A9Z3Ci2PQhFUwBXvI('live','_MRF_'+'قناة المعارف من موقعهم',Zg9FeADE84jSRIvPCrzYulw3sL,41)
	A9Z3Ci2PQhFUwBXvI('live','_PNT_'+'قناة هلا من موقع بانيت',Zg9FeADE84jSRIvPCrzYulw3sL,38)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','_TV1_'+'قنوات تلفزيونية عامة',Zg9FeADE84jSRIvPCrzYulw3sL,102)
	A9Z3Ci2PQhFUwBXvI('folder','_TV2_'+'قنوات تلفزيونية خاصة',Zg9FeADE84jSRIvPCrzYulw3sL,103)
	A9Z3Ci2PQhFUwBXvI('folder','_TV3_'+'قنوات تلفزيونية للفحص',Zg9FeADE84jSRIvPCrzYulw3sL,104)
	return
def yfWYTB58bDO(trgU5GIRQc,showDialogs=True):
	j0jSEdTPJuG4XNvfpO = '_TV'+trgU5GIRQc+'_'
	EEFf6enQDxk = {'id':Zg9FeADE84jSRIvPCrzYulw3sL,'user':fs60XkagtWFJ,'function':'list','menu':trgU5GIRQc}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',qfzHe2Yr49,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-ITEMS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		for YjZN3ADmertFahUQIECW in range(len(items)):
			name = items[YjZN3ADmertFahUQIECW][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[YjZN3ADmertFahUQIECW] = items[YjZN3ADmertFahUQIECW][0],items[YjZN3ADmertFahUQIECW][1],items[YjZN3ADmertFahUQIECW][2],name,items[YjZN3ADmertFahUQIECW][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for iojW2gVFfT,m0t48jnKhrQFJViguoMl9NBPp,qS1RW5ZtAkYb,name,W8KBRzkdhlCxvF5sY2T in items:
			if '#' in iojW2gVFfT: continue
			if iojW2gVFfT!='URL': name = name+PPQORjT2lc7SVkKwFI4D+Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J+iojW2gVFfT+u4IRSmrYMKkaHUBnDiLWh
			url = iojW2gVFfT+';;'+m0t48jnKhrQFJViguoMl9NBPp+';;'+qS1RW5ZtAkYb+';;'+trgU5GIRQc
			A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+Zg9FeADE84jSRIvPCrzYulw3sL+name,url,105,W8KBRzkdhlCxvF5sY2T)
	else:
		if showDialogs: A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+'هذه الخدمة مخصصة للمبرمج فقط',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(id):
	iojW2gVFfT,m0t48jnKhrQFJViguoMl9NBPp,qS1RW5ZtAkYb,trgU5GIRQc = id.split(';;')
	url = Zg9FeADE84jSRIvPCrzYulw3sL
	if iojW2gVFfT=='URL': url = qS1RW5ZtAkYb
	elif iojW2gVFfT=='YOUTUBE':
		url = PhpFa6EdVS['YOUTUBE'][0]+'/watch?v='+qS1RW5ZtAkYb
		import XabeJODuZn
		XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([url],bIPsOxjEpoH,'live',url)
		return
	elif iojW2gVFfT=='GA':
		EEFf6enQDxk = { 'id' : Zg9FeADE84jSRIvPCrzYulw3sL, 'user' : fs60XkagtWFJ , 'function' : 'playGA1' , 'menu' : Zg9FeADE84jSRIvPCrzYulw3sL }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,False,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-1st')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
		ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = cookies['ASP.NET_SessionId']
		url = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		EEFf6enQDxk = { 'id' : qS1RW5ZtAkYb , 'user' : fs60XkagtWFJ , 'function' : 'playGA2' , 'menu' : Zg9FeADE84jSRIvPCrzYulw3sL }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,EEFf6enQDxk,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-2nd')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('resp":"(http.*?m3u8)(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		yDTPzhEBKVJl7CX81 = url[0][0]
		uUOrTzxoL3lhmftZnwRpHPaj = url[0][1]
		wvne1TCbfi8GNdSpFABW74Dr56 = 'http://38.'+m0t48jnKhrQFJViguoMl9NBPp+'777/'+qS1RW5ZtAkYb+'_HD.m3u8'+uUOrTzxoL3lhmftZnwRpHPaj
		nn6rPyYeUk7FwRMBDTE = wvne1TCbfi8GNdSpFABW74Dr56.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		LaHlC5K48xJmv63 = wvne1TCbfi8GNdSpFABW74Dr56.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		nnhWEIa6Tm = ['HD','SD1','SD2']
		fo6s53yEnbklLpaJOzgR4Q01wxB = [wvne1TCbfi8GNdSpFABW74Dr56,nn6rPyYeUk7FwRMBDTE,LaHlC5K48xJmv63]
		lqQvOUWodZnhXLS2Vcuj6EtairFN = 0
		if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1: return
		else: url = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	elif iojW2gVFfT=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		EEFf6enQDxk = { 'id' : qS1RW5ZtAkYb , 'user' : fs60XkagtWFJ , 'function' : 'playNT' , 'menu' : trgU5GIRQc }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST', qfzHe2Yr49, EEFf6enQDxk, headers, False,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-3rd')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		url = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		url = url.replace('%20',wjs26GpVfNiCUERHJ)
		url = url.replace('%3D','=')
		if 'Learn' in qS1RW5ZtAkYb:
			url = url.replace('NTNNile',Zg9FeADE84jSRIvPCrzYulw3sL)
			url = url.replace('learning1','Learning')
	elif iojW2gVFfT=='PL':
		EEFf6enQDxk = { 'id' : qS1RW5ZtAkYb , 'user' : fs60XkagtWFJ , 'function' : 'playPL' , 'menu' : trgU5GIRQc }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST', qfzHe2Yr49, EEFf6enQDxk, Zg9FeADE84jSRIvPCrzYulw3sL,False,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-4th')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		url = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		headers = {'Referer':Pa6Q2LRkbtY0Id7nUNsZ.headers['Referer']}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',url, Zg9FeADE84jSRIvPCrzYulw3sL,headers , Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-5th')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url = items[0]
	elif iojW2gVFfT in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if iojW2gVFfT=='TA': qS1RW5ZtAkYb = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		EEFf6enQDxk = { 'id' : qS1RW5ZtAkYb , 'user' : fs60XkagtWFJ , 'function' : 'play'+iojW2gVFfT , 'menu' : trgU5GIRQc }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',qfzHe2Yr49,EEFf6enQDxk,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-6th')
		if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		url = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		if iojW2gVFfT=='FM':
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET', url, Zg9FeADE84jSRIvPCrzYulw3sL, Zg9FeADE84jSRIvPCrzYulw3sL, False,Zg9FeADE84jSRIvPCrzYulw3sL,'LIVETV-PLAY-7th')
			url = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
			url = url.replace('https','http')
	nTdpZOCUe7l(url,bIPsOxjEpoH,'live')
	return
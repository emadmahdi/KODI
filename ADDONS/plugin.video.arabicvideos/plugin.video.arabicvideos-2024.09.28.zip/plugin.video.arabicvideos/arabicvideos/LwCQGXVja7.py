﻿# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'ALMAAREF'
headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
j0jSEdTPJuG4XNvfpO = '_MRF_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def mp9gnhjBIoA8Rz3SylG(mode,url,text,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	if   mode==40: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==41: CsaNhTtGm8 = nHNoV6BMsIPWhxt2FKC()
	elif mode==42: CsaNhTtGm8 = CqNc4TtOIXgiW283PrALYnU(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==43: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==44: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==49: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,49)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+'البث الحي لقناة المعارف',Zg9FeADE84jSRIvPCrzYulw3sL,41)
	CqNc4TtOIXgiW283PrALYnU(Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	return
def jjygvxtCK9W1UuNQMVDYz5w(NNYRDot8vC,qPDocIHCSmftG5izsJ0nX4):
	search,sort,iieGNzLtajuAx1o,WWdHIOCPeKmgRstXk4c,qfReajQAlyZhC = Zg9FeADE84jSRIvPCrzYulw3sL,[],[],[],[]
	DMKySWniQ0HqtCsrg65dmb2Tha,YAvNcrxpseWE37iLFbTGnyoC6 = I28IrfmVwu4JkOXhGB(NNYRDot8vC)
	for xWfrLDQiMOA358ghbsZk6PtSK in list(YAvNcrxpseWE37iLFbTGnyoC6.keys()):
		B251BPiLbvG9UxszKtlI7YQHmoWw = YAvNcrxpseWE37iLFbTGnyoC6[xWfrLDQiMOA358ghbsZk6PtSK]
		if not B251BPiLbvG9UxszKtlI7YQHmoWw: continue
		if   xWfrLDQiMOA358ghbsZk6PtSK=='sort': sort = [B251BPiLbvG9UxszKtlI7YQHmoWw]
		elif xWfrLDQiMOA358ghbsZk6PtSK=='series': iieGNzLtajuAx1o = [B251BPiLbvG9UxszKtlI7YQHmoWw]
		elif xWfrLDQiMOA358ghbsZk6PtSK=='search': search = B251BPiLbvG9UxszKtlI7YQHmoWw
		elif xWfrLDQiMOA358ghbsZk6PtSK=='category': WWdHIOCPeKmgRstXk4c = [B251BPiLbvG9UxszKtlI7YQHmoWw]
		elif xWfrLDQiMOA358ghbsZk6PtSK=='specialist': qfReajQAlyZhC = [B251BPiLbvG9UxszKtlI7YQHmoWw]
	EEFf6enQDxk = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":WWdHIOCPeKmgRstXk4c,"specialist":qfReajQAlyZhC,"series":iieGNzLtajuAx1o,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(qPDocIHCSmftG5izsJ0nX4)}}
	EEFf6enQDxk = lSD9w50N6VBOHbfT2WRiPsM.dumps(EEFf6enQDxk)
	yDTPzhEBKVJl7CX81 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',yDTPzhEBKVJl7CX81,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	data = JGmfjhoyKZUl('dict',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	return data
def CqNc4TtOIXgiW283PrALYnU(NNYRDot8vC,level):
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = jjygvxtCK9W1UuNQMVDYz5w(NNYRDot8vC,'1')
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = qLx93JtrVCHlKaZW2hXc7dpiNmDR['facets']
	if level=='1':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['video_categories']
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<div(.*?)/div>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for r1OMYvp0ViTG in items:
			OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',r1OMYvp0ViTG+'<',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not OQ1FgC3a5ZLX4unm7Ebx8ji: OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-value=\\"(.*?)\\">(.*?)<',r1OMYvp0ViTG+'<',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			WWdHIOCPeKmgRstXk4c,title = OQ1FgC3a5ZLX4unm7Ebx8ji[0]
			if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			if not NNYRDot8vC: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,42,Zg9FeADE84jSRIvPCrzYulw3sL,'2','?category='+WWdHIOCPeKmgRstXk4c)
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,42,Zg9FeADE84jSRIvPCrzYulw3sL,'2',NNYRDot8vC+'&category='+WWdHIOCPeKmgRstXk4c)
	if level=='2':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['specialist']
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('value="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for qfReajQAlyZhC,title in items:
			if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			if not qfReajQAlyZhC: title = title = 'الجميع'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,42,Zg9FeADE84jSRIvPCrzYulw3sL,'3',NNYRDot8vC+'&specialist='+qfReajQAlyZhC)
	elif level=='3':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['series']
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('value="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for iieGNzLtajuAx1o,title in items:
			if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			if not iieGNzLtajuAx1o: title = title = 'الجميع'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,42,Zg9FeADE84jSRIvPCrzYulw3sL,'4',NNYRDot8vC+'&series='+iieGNzLtajuAx1o)
	elif level=='4':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['sort_video']
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('value="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for sort,title in items:
			if not sort: continue
			if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,44,Zg9FeADE84jSRIvPCrzYulw3sL,'1',NNYRDot8vC+'&sort='+sort)
	return
def mbzIyKNqMVt0FQeOsPWc(NNYRDot8vC,qPDocIHCSmftG5izsJ0nX4):
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = jjygvxtCK9W1UuNQMVDYz5w(NNYRDot8vC,qPDocIHCSmftG5izsJ0nX4)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = qLx93JtrVCHlKaZW2hXc7dpiNmDR['template']
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,43,W8KBRzkdhlCxvF5sY2T)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = qLx93JtrVCHlKaZW2hXc7dpiNmDR['facets']['pagination']
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-page="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for wlxviMOuNeQVct4ULsCEHXZm6yR2p,title in items:
		if qPDocIHCSmftG5izsJ0nX4==wlxviMOuNeQVct4ULsCEHXZm6yR2p: continue
		if HByjTem6EJP5sZb: title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,Zg9FeADE84jSRIvPCrzYulw3sL,44,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,NNYRDot8vC)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ALMAAREF-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<video src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('youtube_url.*?(http.*?)&',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	ZZH6czYDb0 = []
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0].replace('\/','/')
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def nHNoV6BMsIPWhxt2FKC():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49+'/بث-مباشر',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ALMAAREF-LIVE-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"svpPlayer".*?(http.*?)&',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url = url[0].replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
	nTdpZOCUe7l(url,bIPsOxjEpoH,'live')
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	bv3lUxCtVoYsJm5ikw = False
	if search==Zg9FeADE84jSRIvPCrzYulw3sL:
		search = EnxNsqevtM28mpkZ5RG0()
		bv3lUxCtVoYsJm5ikw = True
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	if not bv3lUxCtVoYsJm5ikw: mbzIyKNqMVt0FQeOsPWc('?search='+search,'1')
	else: CqNc4TtOIXgiW283PrALYnU('?search='+search,'1')
	return
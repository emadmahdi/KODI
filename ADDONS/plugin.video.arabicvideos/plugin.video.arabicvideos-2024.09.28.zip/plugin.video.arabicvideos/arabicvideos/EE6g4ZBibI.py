# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'MOVS4U'
j0jSEdTPJuG4XNvfpO = '_M4U_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['انواع افلام','جودات افلام']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==380: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==381: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==382: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==383: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==389: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,389,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',qfzHe2Yr49,381,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الجانبية',qfzHe2Yr49,381,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'sider')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVS4U-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<header>.*?<h2>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for pfQhOaqwdBS2k8ZiRA5MeXYUK in range(len(items)):
		title = items[pfQhOaqwdBS2k8ZiRA5MeXYUK]
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,qfzHe2Yr49,381,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'latest'+str(pfQhOaqwdBS2k8ZiRA5MeXYUK))
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Zg9FeADE84jSRIvPCrzYulw3sL
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="menu"(.*?)id="contenedor"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA += HNRenB3EZX62qgSKMd4f[0]
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="sidebar(.*?)aside',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA += HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	Ur0vIJYXQ3bWs = True
	for yDTPzhEBKVJl7CX81,title in items:
		title = BtKvPnEQJx32Z(title)
		if title=='الأعلى مشاهدة':
			if Ur0vIJYXQ3bWs:
				title = 'الافلام '+title
				Ur0vIJYXQ3bWs = False
			else: title = 'المسلسلات '+title
		if title not in Uhe07PlWNakHDZc1t:
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,381)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url,type):
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,items = [],[]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVS4U-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if type=='search':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="search-page"(.*?)class="sidebar',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif type=='sider':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="widget(.*?)class="widget',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		YYHa0LEbfAe1o = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		fo6s53yEnbklLpaJOzgR4Q01wxB,ERxKv1oPysT6AcaMG4ktpFm,nnhWEIa6Tm = zip(*YYHa0LEbfAe1o)
		items = zip(ERxKv1oPysT6AcaMG4ktpFm,fo6s53yEnbklLpaJOzgR4Q01wxB,nnhWEIa6Tm)
	elif type=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="slider-movies-tvshows"(.*?)<header>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif 'latest' in type:
		pfQhOaqwdBS2k8ZiRA5MeXYUK = int(type[-1:])
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('<header>','<end><start>')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('<div class="sidebar','<end><div class="sidebar')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<start>(.*?)<end>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[pfQhOaqwdBS2k8ZiRA5MeXYUK]
		if pfQhOaqwdBS2k8ZiRA5MeXYUK==2: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="content"(.*?)class="(pagination|sidebar)',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0][0]
			if '/collection/' in url:
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			elif '/quality/' in url:
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items and nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		if 'serie' in title:
			title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.*?)<.*?serie">(.*?)<',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			title = title[0][1]
			if title in cfUCuhJwZijTLxQX3gHayn89RqGrP: continue
			cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
			title = '_MOD_'+title
		wUpHn5IfzaQ8g4j = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.*?)<',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if wUpHn5IfzaQ8g4j: title = wUpHn5IfzaQ8g4j[0]
		title = BtKvPnEQJx32Z(title)
		if '/tvshows/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,383,W8KBRzkdhlCxvF5sY2T)
		elif '/episodes/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,383,W8KBRzkdhlCxvF5sY2T)
		elif '/seasons/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,383,W8KBRzkdhlCxvF5sY2T)
		elif '/collection/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,381,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,382,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		EXymi764zax = HNRenB3EZX62qgSKMd4f[0][0]
		Sw3AGUBqjXQdarvcRsz8hy2TOp0C = HNRenB3EZX62qgSKMd4f[0][1]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0][2]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href='(.*?)'.*?>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title==Zg9FeADE84jSRIvPCrzYulw3sL or title==Sw3AGUBqjXQdarvcRsz8hy2TOp0C: continue
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,381,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('/page/'+title+'/','/page/'+Sw3AGUBqjXQdarvcRsz8hy2TOp0C+'/')
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'اخر صفحة '+Sw3AGUBqjXQdarvcRsz8hy2TOp0C,yDTPzhEBKVJl7CX81,381,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVS4U-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="C rated".*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50,False):
		A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+'المسلسل للكبار والمبرمج منعه',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''class='item'><a href="(.*?)"''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[1]
			dHjny9tTucrO(hc5ePKxl4LJvEjDgTm)
			return
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''class='episodios'(.*?)id="cast"''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,jjYXOr8QJsNUZv0PGL27ARSDceiq4,yDTPzhEBKVJl7CX81,name in items:
			title = jjYXOr8QJsNUZv0PGL27ARSDceiq4+' : '+name+' الحلقة'
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,382)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVS4U-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="C rated".*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0][0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("data-url='(.*?)'.*?class='server'>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="remodal"(.*?)class="remodal-close"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/?s='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
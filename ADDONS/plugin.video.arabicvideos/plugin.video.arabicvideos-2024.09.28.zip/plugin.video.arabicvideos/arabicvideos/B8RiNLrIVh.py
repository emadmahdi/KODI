# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'SERIES4WATCH'
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
j0jSEdTPJuG4XNvfpO = '_SFW_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==210: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==211: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	elif mode==212: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==213: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==214: CsaNhTtGm8 = oawJVqAt5Ul8X(url)
	elif mode==215: CsaNhTtGm8 = BR3QY7UXdWHGinMOvhN(url)
	elif mode==218: CsaNhTtGm8 = XzHvmJrO3PeBWN7oqu1pwE6jZK()
	elif mode==219: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def XzHvmJrO3PeBWN7oqu1pwE6jZK():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,219,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	url = qfzHe2Yr49+'/getpostsPin?type=one&data=pin&limit=25'
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',url,211)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('FiltersButtons(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-get="(.*?)".*?</i>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		url = qfzHe2Yr49+'/getposts?type=one&data='+yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,url,211)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('navigation-menu(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Uhe07PlWNakHDZc1t = ['مسلسلات انمي','الرئيسية']
	for yDTPzhEBKVJl7CX81,title in items:
		title = title.strip(wjs26GpVfNiCUERHJ)
		if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,211)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('MediaGrid"(.*?)class="pagination"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		else: return
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	odEpDjOFTcz39bsiAwVUKXMkQ8u51 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		if '/series/' in yDTPzhEBKVJl7CX81: continue
		yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81).strip('/')
		title = BtKvPnEQJx32Z(title)
		title = title.strip(wjs26GpVfNiCUERHJ)
		if '/film/' in yDTPzhEBKVJl7CX81 or any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in odEpDjOFTcz39bsiAwVUKXMkQ8u51):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,212,W8KBRzkdhlCxvF5sY2T)
		elif '/episode/' in yDTPzhEBKVJl7CX81 and 'الحلقة' in title:
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if jjYXOr8QJsNUZv0PGL27ARSDceiq4:
				title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,213,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,213,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = BtKvPnEQJx32Z(yDTPzhEBKVJl7CX81)
			title = BtKvPnEQJx32Z(title)
			title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,211)
	return
def dHjny9tTucrO(url):
	VGKI0UyjdnEHvLwDoPxSX1lB4e,items,GGRIHTPjFczBqOsD0WuKMXh = -1,[],[]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-EPISODES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ti-list-numbered(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		qLx93JtrVCHlKaZW2hXc7dpiNmDR = Zg9FeADE84jSRIvPCrzYulw3sL.join(HNRenB3EZX62qgSKMd4f)
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',qLx93JtrVCHlKaZW2hXc7dpiNmDR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items.append(url)
	items = set(items)
	for yDTPzhEBKVJl7CX81 in items:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.strip('/')
		title = '_MOD_' + yDTPzhEBKVJl7CX81.split('/')[-1].replace('-',wjs26GpVfNiCUERHJ)
		hxEOR0DB6rPG9ky5itpoausvwYFJ4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('الحلقة-(\d+)',yDTPzhEBKVJl7CX81.split('/')[-1],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hxEOR0DB6rPG9ky5itpoausvwYFJ4: hxEOR0DB6rPG9ky5itpoausvwYFJ4 = hxEOR0DB6rPG9ky5itpoausvwYFJ4[0]
		else: hxEOR0DB6rPG9ky5itpoausvwYFJ4 = '0'
		GGRIHTPjFczBqOsD0WuKMXh.append([yDTPzhEBKVJl7CX81,title,hxEOR0DB6rPG9ky5itpoausvwYFJ4])
	items = sorted(GGRIHTPjFczBqOsD0WuKMXh, reverse=False, key=lambda key: int(key[2]))
	jV41h2Sfktr5IC0lQZ = str(items).count('/season/')
	VGKI0UyjdnEHvLwDoPxSX1lB4e = str(items).count('/episode/')
	if jV41h2Sfktr5IC0lQZ>1 and VGKI0UyjdnEHvLwDoPxSX1lB4e>0 and '/season/' not in url:
		for yDTPzhEBKVJl7CX81,title,hxEOR0DB6rPG9ky5itpoausvwYFJ4 in items:
			if '/season/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,213)
	else:
		for yDTPzhEBKVJl7CX81,title,hxEOR0DB6rPG9ky5itpoausvwYFJ4 in items:
			if '/season/' not in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,212)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('/')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		hc5ePKxl4LJvEjDgTm = url.replace(Gi82lgtIxVsjSyqZU5EmBLkKw[3],'watch')
		CNhQcnS0dI6UFjbvLoyx = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-PLAY-2nd')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="servers-list(.*?)</div>',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if items:
				id = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('post_id=(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if id:
					qS1RW5ZtAkYb = id[0]
					for yDTPzhEBKVJl7CX81,title in items:
						yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/?postid='+qS1RW5ZtAkYb+'&serverid='+yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
						fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			else:
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-embedd=".*?(http.*?)("|&quot;)',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				for yDTPzhEBKVJl7CX81,DMKySWniQ0HqtCsrg65dmb2Tha in items:
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if '/download/' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		hc5ePKxl4LJvEjDgTm = url.replace(Gi82lgtIxVsjSyqZU5EmBLkKw[3],'download')
		CNhQcnS0dI6UFjbvLoyx = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-PLAY-3rd')
		id = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('postId:"(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if id:
			qS1RW5ZtAkYb = id[0]
			Y3OmVPp2ARgBCjn = { 'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL , 'X-Requested-With':'XMLHttpRequest' }
			hc5ePKxl4LJvEjDgTm = qfzHe2Yr49 + '/ajaxCenter?_action=getdownloadlinks&postId='+qS1RW5ZtAkYb
			CNhQcnS0dI6UFjbvLoyx = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,'SERIES4WATCH-PLAY-4th')
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h3.*?(\d+)(.*?)</div>',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if HNRenB3EZX62qgSKMd4f:
				for uo2MTB486ONdtnQIfHl,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
					items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<td>(.*?)<.*?href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					for name,yDTPzhEBKVJl7CX81 in items:
						fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81+'?named='+name+'__download'+'____'+uo2MTB486ONdtnQIfHl)
			else:
				HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h6(.*?)</table>',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = [CNhQcnS0dI6UFjbvLoyx]
				for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
					name = Zg9FeADE84jSRIvPCrzYulw3sL
					items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					for yDTPzhEBKVJl7CX81 in items:
						m0t48jnKhrQFJViguoMl9NBPp = '&&' + yDTPzhEBKVJl7CX81.split('/')[2].lower() + '&&'
						m0t48jnKhrQFJViguoMl9NBPp = m0t48jnKhrQFJViguoMl9NBPp.replace('.com&&',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.co&&',Zg9FeADE84jSRIvPCrzYulw3sL)
						m0t48jnKhrQFJViguoMl9NBPp = m0t48jnKhrQFJViguoMl9NBPp.replace('.net&&',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.org&&',Zg9FeADE84jSRIvPCrzYulw3sL)
						m0t48jnKhrQFJViguoMl9NBPp = m0t48jnKhrQFJViguoMl9NBPp.replace('.live&&',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.online&&',Zg9FeADE84jSRIvPCrzYulw3sL)
						m0t48jnKhrQFJViguoMl9NBPp = m0t48jnKhrQFJViguoMl9NBPp.replace('&&hd.',Zg9FeADE84jSRIvPCrzYulw3sL).replace('&&www.',Zg9FeADE84jSRIvPCrzYulw3sL)
						m0t48jnKhrQFJViguoMl9NBPp = m0t48jnKhrQFJViguoMl9NBPp.replace('&&',Zg9FeADE84jSRIvPCrzYulw3sL)
						yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81 + '?named=' + name + m0t48jnKhrQFJViguoMl9NBPp + '__download'
						fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49 + '/search?s='+search
	mbzIyKNqMVt0FQeOsPWc(url)
	return
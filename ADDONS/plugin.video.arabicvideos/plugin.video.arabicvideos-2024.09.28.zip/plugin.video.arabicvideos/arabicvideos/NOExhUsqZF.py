# -*- coding: utf-8 -*-
from V1VREBsj92 import *
import bs4 as bblP9iWXDhpyIHENTFKr01fGgckYoq
bIPsOxjEpoH = 'ELCINEMA'
j0jSEdTPJuG4XNvfpO = '_ELC_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
headers = {'Referer':qfzHe2Yr49}
Uhe07PlWNakHDZc1t = []
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==510: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==511: CsaNhTtGm8 = S136Y8xVukrb7mpjJqyBsLhGvXdQME(url)
	elif mode==512: CsaNhTtGm8 = pfJ6FjwE0WlSMIBC(url)
	elif mode==513: CsaNhTtGm8 = kTpon4XqiA(url)
	elif mode==514: CsaNhTtGm8 = zEGg8fInoVTW(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: CsaNhTtGm8 = zEGg8fInoVTW(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: CsaNhTtGm8 = YaNWDEk4iU(text)
	elif mode==517: CsaNhTtGm8 = AsXO91eti8oFNnWmDHuh7UQ0Kkb3vV(url)
	elif mode==518: CsaNhTtGm8 = SSHLURFZNGhfKlm1wcX4DI3nb(url)
	elif mode==519: CsaNhTtGm8 = KkZtb4lhPd(text)
	elif mode==520: CsaNhTtGm8 = EHKO6oakw14exXy2W9qZp7zPB(url)
	elif mode==521: CsaNhTtGm8 = PvMdXjQzKci0yk4w9BUh6W3aqFl7(url)
	elif mode==522: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==523: CsaNhTtGm8 = o1kmENYAviPJHd7(text)
	elif mode==524: CsaNhTtGm8 = NRhoCUru84dZzO3LXE57VPys()
	elif mode==525: CsaNhTtGm8 = Gu0Y7fPOv3I8()
	elif mode==526: CsaNhTtGm8 = T38ZLhBAgRiIfPc5tm()
	elif mode==527: CsaNhTtGm8 = hfKJzi52MBdHukamgCeGO()
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث بموسوعة السينما',Zg9FeADE84jSRIvPCrzYulw3sL,519)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'موسوعة الأعمال',Zg9FeADE84jSRIvPCrzYulw3sL,525)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'موسوعة الأشخاص',Zg9FeADE84jSRIvPCrzYulw3sL,526)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'موسوعة المصنفات',Zg9FeADE84jSRIvPCrzYulw3sL,527)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'موسوعة المنوعات',Zg9FeADE84jSRIvPCrzYulw3sL,524)
	return
def NRhoCUru84dZzO3LXE57VPys():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' فيديوهات - خاصة',qfzHe2Yr49+'/video',520)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فيديوهات - أحدث',qfzHe2Yr49+'/video/latest',521)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فيديوهات - أقدم',qfzHe2Yr49+'/video/oldest',521)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فيديوهات - أكثر مشاهدة',qfzHe2Yr49+'/video/views',521)
	return
def Gu0Y7fPOv3I8():
	COdDX7xQVsE5BPA6WHeLugrGz = qfzHe2Yr49+'/lineup?utf8=%E2%9C%93'
	DHZncaXq6UKkMeP8GR0 = COdDX7xQVsE5BPA6WHeLugrGz+'&type=2&category=1&foreign=false&tag='
	DqLGxvKkS9juC5zyceMPwTaUZYVBR6 = COdDX7xQVsE5BPA6WHeLugrGz+'&type=2&category=3&foreign=false&tag='
	Ikdwl0oazHfq3pc = COdDX7xQVsE5BPA6WHeLugrGz+'&type=2&category=1&foreign=true&tag='
	cjGU1MSf3AWHz2eF0J = COdDX7xQVsE5BPA6WHeLugrGz+'&type=2&category=3&foreign=true&tag='
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات أفلام عربي',DHZncaXq6UKkMeP8GR0,511)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات مسلسلات عربي',DqLGxvKkS9juC5zyceMPwTaUZYVBR6,511)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات أفلام اجنبي',Ikdwl0oazHfq3pc,511)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات مسلسلات اجنبي',cjGU1MSf3AWHz2eF0J,511)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس أعمال أبجدي',qfzHe2Yr49+'/index/work/alphabet',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس  بلد الإنتاج',qfzHe2Yr49+'/index/work/country',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس اللغة',qfzHe2Yr49+'/index/work/language',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس مصنفات العمل',qfzHe2Yr49+'/index/work/genre',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس سنة الإصدار',qfzHe2Yr49+'/index/work/release_year',517)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مواسم - فلتر محدد',qfzHe2Yr49+'/seasonals',515)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مواسم - فلتر كامل',qfzHe2Yr49+'/seasonals',514)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات - فلتر محدد',qfzHe2Yr49+'/lineup',515)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات - فلتر كامل',qfzHe2Yr49+'/lineup',514)
	return
def hfKJzi52MBdHukamgCeGO():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49+'/lineup',Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Cwy6gjPtcz3xpaLKkUH8sRf.find('select',attrs={'name':'tag'})
	NNYRDot8vC = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('option')
	for xWfrLDQiMOA358ghbsZk6PtSK in NNYRDot8vC:
		B251BPiLbvG9UxszKtlI7YQHmoWw = xWfrLDQiMOA358ghbsZk6PtSK.get('value')
		if not B251BPiLbvG9UxszKtlI7YQHmoWw: continue
		title = xWfrLDQiMOA358ghbsZk6PtSK.text
		if HByjTem6EJP5sZb:
			title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			B251BPiLbvG9UxszKtlI7YQHmoWw = B251BPiLbvG9UxszKtlI7YQHmoWw.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+B251BPiLbvG9UxszKtlI7YQHmoWw
		title = title.replace('قائمة ',Zg9FeADE84jSRIvPCrzYulw3sL)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,511)
	return
def T38ZLhBAgRiIfPc5tm():
	COdDX7xQVsE5BPA6WHeLugrGz = qfzHe2Yr49+'/lineup?utf8=%E2%9C%93'
	egkm3G4QjapLvH1fITb = COdDX7xQVsE5BPA6WHeLugrGz+'&type=1&category=&foreign=&tag='
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات أشخاص',egkm3G4QjapLvH1fITb,511)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس أشخاص أبجدي',qfzHe2Yr49+'/index/person/alphabet',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس موطن',qfzHe2Yr49+'/index/person/nationality',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس  تاريخ الميلاد',qfzHe2Yr49+'/index/person/birth_year',517)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فهرس  تاريخ الوفاة',qfzHe2Yr49+'/index/person/death_year',517)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات - فلتر محدد',qfzHe2Yr49+'/lineup',515)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مصنفات - فلتر كامل',qfzHe2Yr49+'/lineup',514)
	return
def S136Y8xVukrb7mpjJqyBsLhGvXdQME(url):
	if '/seasonals' in url: I5ycituE8YxBLn = 0
	elif '/lineup' in url: I5ycituE8YxBLn = 1
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-LISTS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = Cwy6gjPtcz3xpaLKkUH8sRf.find_all(class_='jumbo-theater clearfix')
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		title = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('a')[I5ycituE8YxBLn].text
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('a')[I5ycituE8YxBLn].get('href')
		if HByjTem6EJP5sZb:
			title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR:
			pfJ6FjwE0WlSMIBC(yDTPzhEBKVJl7CX81)
			return
		else:
			title = title.replace('قائمة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,512)
	jj8VN1sfnlLR52J(Cwy6gjPtcz3xpaLKkUH8sRf,511)
	return
def jj8VN1sfnlLR52J(Cwy6gjPtcz3xpaLKkUH8sRf,mode):
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Cwy6gjPtcz3xpaLKkUH8sRf.find(class_='pagination')
	if nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA:
		llMH1EuRFPrIZkbVWgXy = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('a')
		Q0yXqcoHhJmAYzVk9IMDGZWwUNRbC = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('li')
		J0cT6QGthjDl8 = list(zip(llMH1EuRFPrIZkbVWgXy,Q0yXqcoHhJmAYzVk9IMDGZWwUNRbC))
		OEJ3PT81KtbZ = -1
		OmyQoW6Gkh2sx = len(J0cT6QGthjDl8)
		for W2yRvbsquF5XAMzd3jIPom,uu0WZmXLgC8MrIpvy3fiG5 in J0cT6QGthjDl8:
			OEJ3PT81KtbZ += 1
			uu0WZmXLgC8MrIpvy3fiG5 = uu0WZmXLgC8MrIpvy3fiG5['class']
			if 'unavailable' in uu0WZmXLgC8MrIpvy3fiG5 or 'current' in uu0WZmXLgC8MrIpvy3fiG5: continue
			W4KwrJtUfaNF2Q3Coqsl869V1dbm = W2yRvbsquF5XAMzd3jIPom.text
			WOry7DZPocFhH8p4 = qfzHe2Yr49+W2yRvbsquF5XAMzd3jIPom.get('href')
			if HByjTem6EJP5sZb:
				W4KwrJtUfaNF2Q3Coqsl869V1dbm = W4KwrJtUfaNF2Q3Coqsl869V1dbm.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				WOry7DZPocFhH8p4 = WOry7DZPocFhH8p4.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			if   OEJ3PT81KtbZ==0: W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'أولى'
			elif OEJ3PT81KtbZ==1: W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'سابقة'
			elif OEJ3PT81KtbZ==OmyQoW6Gkh2sx-2: W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'لاحقة'
			elif OEJ3PT81KtbZ==OmyQoW6Gkh2sx-1: W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'أخيرة'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+W4KwrJtUfaNF2Q3Coqsl869V1dbm,WOry7DZPocFhH8p4,mode)
	return
def pfJ6FjwE0WlSMIBC(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-TITLES1-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = Cwy6gjPtcz3xpaLKkUH8sRf.find_all(class_='row')
	items,Ur0vIJYXQ3bWs = [],True
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		if not nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='thumbnail-wrapper'): continue
		if Ur0vIJYXQ3bWs: Ur0vIJYXQ3bWs = False ; continue
		ZcGjA5vHnK7XrfO = []
		Gko6UaEX0ixDpSK = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all(class_=['censorship red','censorship purple'])
		for NEbuHMk1x9l in Gko6UaEX0ixDpSK:
			KeSlIpkUvPOfbaQVsu89EJB0gy = NEbuHMk1x9l.find_all('li')[1].text
			if HByjTem6EJP5sZb:
				KeSlIpkUvPOfbaQVsu89EJB0gy = KeSlIpkUvPOfbaQVsu89EJB0gy.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			ZcGjA5vHnK7XrfO.append(KeSlIpkUvPOfbaQVsu89EJB0gy)
		if not aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,Zg9FeADE84jSRIvPCrzYulw3sL,ZcGjA5vHnK7XrfO,False):
			EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('data-src')
			title = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('h3')
			name = title.find('a').text
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+title.find('a').get('href')
			RBq7Yzgkp2nXrSev5dJm = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='no-margin')
			y86p0HCXPcz5bAQRVrEita = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='legend')
			if RBq7Yzgkp2nXrSev5dJm: RBq7Yzgkp2nXrSev5dJm = RBq7Yzgkp2nXrSev5dJm.text
			if y86p0HCXPcz5bAQRVrEita: y86p0HCXPcz5bAQRVrEita = y86p0HCXPcz5bAQRVrEita.text
			if HByjTem6EJP5sZb:
				EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				name = name.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				if RBq7Yzgkp2nXrSev5dJm: RBq7Yzgkp2nXrSev5dJm = RBq7Yzgkp2nXrSev5dJm.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			QsWU0ew5xMjBozVtqHAGDTNyL4Ia = {}
			if y86p0HCXPcz5bAQRVrEita: QsWU0ew5xMjBozVtqHAGDTNyL4Ia['stars'] = y86p0HCXPcz5bAQRVrEita
			if RBq7Yzgkp2nXrSev5dJm:
				RBq7Yzgkp2nXrSev5dJm = RBq7Yzgkp2nXrSev5dJm.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,' .. ')
				QsWU0ew5xMjBozVtqHAGDTNyL4Ia['plot'] = RBq7Yzgkp2nXrSev5dJm.replace('...اقرأ المزيد',Zg9FeADE84jSRIvPCrzYulw3sL)
			if '/work/' in yDTPzhEBKVJl7CX81:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,516,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
			elif '/person/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,513,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	jj8VN1sfnlLR52J(Cwy6gjPtcz3xpaLKkUH8sRf,512)
	return
def kTpon4XqiA(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-TITLES2-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = Cwy6gjPtcz3xpaLKkUH8sRf.find_all('li')
	S2hbYR5w0m7k68OHDyBgCnjA4izlJ,items = [],[]
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		if not nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='thumbnail-wrapper'): continue
		if not nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_=['unstyled','unstyled text-center']): continue
		if nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='hide'): continue
		title = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in S2hbYR5w0m7k68OHDyBgCnjA4izlJ: continue
		S2hbYR5w0m7k68OHDyBgCnjA4izlJ.append(name)
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+title.find('a').get('href')
		if '/search/work/' in url: EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('src')
		elif '/search/person/' in url: EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('data-src')
		elif '/search/video/' in url: EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('data-src')
		else: EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('src')
		if HByjTem6EJP5sZb:
			name = name.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		name = name.strip(wjs26GpVfNiCUERHJ)
		items.append((name,yDTPzhEBKVJl7CX81,EELGungxe6wKPar9hyRv5FUMpIB))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,yDTPzhEBKVJl7CX81,EELGungxe6wKPar9hyRv5FUMpIB in items:
		if '/search/video/' in url: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,522,EELGungxe6wKPar9hyRv5FUMpIB)
		elif '/search/person/' in url: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,513,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,516,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name)
	return
def YaNWDEk4iU(text):
	text = text.replace('الإعلان',Zg9FeADE84jSRIvPCrzYulw3sL).replace('لفيلم',Zg9FeADE84jSRIvPCrzYulw3sL).replace('الرسمي',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace('إعلان',Zg9FeADE84jSRIvPCrzYulw3sL).replace('فيلم',Zg9FeADE84jSRIvPCrzYulw3sL).replace('البرومو',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace('التشويقي',Zg9FeADE84jSRIvPCrzYulw3sL).replace('لمسلسل',Zg9FeADE84jSRIvPCrzYulw3sL).replace('مسلسل',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace(':',Zg9FeADE84jSRIvPCrzYulw3sL).replace(')',Zg9FeADE84jSRIvPCrzYulw3sL).replace('(',Zg9FeADE84jSRIvPCrzYulw3sL).replace(',',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace('_',Zg9FeADE84jSRIvPCrzYulw3sL).replace(';',Zg9FeADE84jSRIvPCrzYulw3sL).replace('-',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace('\'',Zg9FeADE84jSRIvPCrzYulw3sL).replace('\"',Zg9FeADE84jSRIvPCrzYulw3sL)
	text = text.replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	text = text.strip(wjs26GpVfNiCUERHJ)
	Ad0ukHFWXmhqB4T8e = text.count(wjs26GpVfNiCUERHJ)+1
	if Ad0ukHFWXmhqB4T8e==1:
		o1kmENYAviPJHd7(text)
		return
	A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+PPQORjT2lc7SVkKwFI4D+'==== كلمات للبحث ===='+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	oonX3EPDkxNQ8 = text.split(wjs26GpVfNiCUERHJ)
	WCyiNvgQdelLRP3ZxaVIBz76EqkJ5 = pow(2,Ad0ukHFWXmhqB4T8e)
	m6d2XNHPKFVSE = []
	def OVHGIjscNpEqKdXPQrZ3A6hg(ex0nfistDmp36Q,htOrekVmZ92):
		if ex0nfistDmp36Q=='1': return htOrekVmZ92
		return Zg9FeADE84jSRIvPCrzYulw3sL
	for OEJ3PT81KtbZ in range(WCyiNvgQdelLRP3ZxaVIBz76EqkJ5,0,-1):
		P6ImLxironD = list(Ad0ukHFWXmhqB4T8e*'0'+bin(OEJ3PT81KtbZ)[2:])[-Ad0ukHFWXmhqB4T8e:]
		P6ImLxironD = reversed(P6ImLxironD)
		Tbl0qZIrG9p = map(OVHGIjscNpEqKdXPQrZ3A6hg,P6ImLxironD,oonX3EPDkxNQ8)
		title = wjs26GpVfNiCUERHJ.join(filter(None,Tbl0qZIrG9p))
		if HByjTem6EJP5sZb: wUpHn5IfzaQ8g4j = title.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		else: wUpHn5IfzaQ8g4j = title
		if len(wUpHn5IfzaQ8g4j)>2 and title not in m6d2XNHPKFVSE:
			m6d2XNHPKFVSE.append(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,523,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,title)
	return
def o1kmENYAviPJHd7(ZDUovIyE74YS2x):
	if HByjTem6EJP5sZb:
		ZDUovIyE74YS2x = ZDUovIyE74YS2x.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		import arabic_reshaper as vUlfJYoDtwC5,bidi.algorithm as R75ODtZqmK3kox
		ZDUovIyE74YS2x = vUlfJYoDtwC5.ArabicReshaper().reshape(ZDUovIyE74YS2x)
		ZDUovIyE74YS2x = R75ODtZqmK3kox.get_display(ZDUovIyE74YS2x)
	import bmdRh0UM1W
	ZDUovIyE74YS2x = EnxNsqevtM28mpkZ5RG0(YYPIsEk1LfiFBZ38JlXVm=ZDUovIyE74YS2x)
	bmdRh0UM1W.KkZtb4lhPd(ZDUovIyE74YS2x)
	return
def AsXO91eti8oFNnWmDHuh7UQ0Kkb3vV(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-INDEXES_LISTS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Cwy6gjPtcz3xpaLKkUH8sRf.find(class_='list-separator list-title')
	WWuctLSlqizGgrK = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('a')
	items = []
	for title in WWuctLSlqizGgrK:
		name = title.text
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+title.get('href')
		if HByjTem6EJP5sZb:
			name = name.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		if '#' not in yDTPzhEBKVJl7CX81: items.append((name,yDTPzhEBKVJl7CX81))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for r1OMYvp0ViTG in items:
		name,yDTPzhEBKVJl7CX81 = r1OMYvp0ViTG
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,518)
	return
def SSHLURFZNGhfKlm1wcX4DI3nb(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-INDEXES_TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = Cwy6gjPtcz3xpaLKkUH8sRf.find(class_='expand').find_all('tr')
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		AHQSZWjrEMpRyx6Dwzk = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find_all('a')
		if not AHQSZWjrEMpRyx6Dwzk: continue
		EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('data-src')
		name = AHQSZWjrEMpRyx6Dwzk[1].text
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+AHQSZWjrEMpRyx6Dwzk[1].get('href')
		y86p0HCXPcz5bAQRVrEita = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='legend')
		if y86p0HCXPcz5bAQRVrEita: y86p0HCXPcz5bAQRVrEita = y86p0HCXPcz5bAQRVrEita.text
		if HByjTem6EJP5sZb:
			name = name.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		QsWU0ew5xMjBozVtqHAGDTNyL4Ia = {}
		if y86p0HCXPcz5bAQRVrEita: QsWU0ew5xMjBozVtqHAGDTNyL4Ia['stars'] = y86p0HCXPcz5bAQRVrEita
		if '/work/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,516,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
		elif '/person/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,513,EELGungxe6wKPar9hyRv5FUMpIB,Zg9FeADE84jSRIvPCrzYulw3sL,name,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	jj8VN1sfnlLR52J(Cwy6gjPtcz3xpaLKkUH8sRf,518)
	return
def EHKO6oakw14exXy2W9qZp7zPB(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-VIDEOS_LISTS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	WWuctLSlqizGgrK = Cwy6gjPtcz3xpaLKkUH8sRf.find_all(class_='section-title inline')
	CPv45ibdnBc = Cwy6gjPtcz3xpaLKkUH8sRf.find_all(class_='button green small right')
	items = zip(WWuctLSlqizGgrK,CPv45ibdnBc)
	for title,yDTPzhEBKVJl7CX81 in items:
		title = title.text
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81.get('href')
		if HByjTem6EJP5sZb:
			title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		title = title.replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,521)
	return
def PvMdXjQzKci0yk4w9BUh6W3aqFl7(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-VIDEOS_TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	xT4rnmMDf5 = Cwy6gjPtcz3xpaLKkUH8sRf.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = xT4rnmMDf5.find_all('li')
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		title = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='title').text
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('a').get('href')
		EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find('img').get('data-src')
		NAdtOanYBmF0IWbMvXxz7lERiTjo = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.find(class_='duration').text
		if HByjTem6EJP5sZb:
			title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,522,EELGungxe6wKPar9hyRv5FUMpIB,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	jj8VN1sfnlLR52J(Cwy6gjPtcz3xpaLKkUH8sRf,521)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	yDTPzhEBKVJl7CX81 = Cwy6gjPtcz3xpaLKkUH8sRf.find(class_='flex-video').find('iframe').get('src')
	if HByjTem6EJP5sZb: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([yDTPzhEBKVJl7CX81],bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'%20')
	url = qfzHe2Yr49+'/search/?q='+search
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-SEARCH-1st')
	if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
		egkm3G4QjapLvH1fITb = qfzHe2Yr49+'/search_entity/?q='+search+'&entity=work'
		WOry7DZPocFhH8p4 = qfzHe2Yr49+'/search_entity/?q='+search+'&entity=person'
		Lx0JNzMogifQkWXa5KvGmcITEt = qfzHe2Yr49+'/search_entity/?q='+search+'&entity=video'
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن أعمال',egkm3G4QjapLvH1fITb,513,Zg9FeADE84jSRIvPCrzYulw3sL,search)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن أشخاص',WOry7DZPocFhH8p4,513,Zg9FeADE84jSRIvPCrzYulw3sL,search)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث عن فيديوهات',Lx0JNzMogifQkWXa5KvGmcITEt,513,Zg9FeADE84jSRIvPCrzYulw3sL,search)
		return
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Cwy6gjPtcz3xpaLKkUH8sRf = bblP9iWXDhpyIHENTFKr01fGgckYoq.BeautifulSoup(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,'html.parser',multi_valued_attributes=None)
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = Cwy6gjPtcz3xpaLKkUH8sRf.find_all(class_='section-title left')
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		title = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.text
		if HByjTem6EJP5sZb:
			title = title.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		title = title.split('(',1)[0].strip(wjs26GpVfNiCUERHJ)
		if   'أعمال' in title: yDTPzhEBKVJl7CX81 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: yDTPzhEBKVJl7CX81 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: yDTPzhEBKVJl7CX81 = url.replace('/search/','/search/video/')
		else: continue
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,513)
	return
def zEGg8fInoVTW(url,text):
	global yycVIo28p69ZU3XRaCbYdP,A7qnSMrihGeFTKZL8zmODNv1U
	if '/seasonals' in url:
		yycVIo28p69ZU3XRaCbYdP = ['seasonal','year','category']
		A7qnSMrihGeFTKZL8zmODNv1U = ['seasonal','year','category']
	elif '/lineup' in url:
		yycVIo28p69ZU3XRaCbYdP = ['category','foreign','type']
		A7qnSMrihGeFTKZL8zmODNv1U = ['category','foreign','type']
	sF8AGonNID9x0J3TSUL2hd1Qjv(url,text)
	return
def N3feaqwRugp50CJUtScZ781QBT(url):
	url = url.split('/smartemadfilter?')[0]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('form action="/(.*?)</form>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	wAsQoW6l1DitrY7MC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	return wAsQoW6l1DitrY7MC
def b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA):
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<option value="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	return items
def GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(url):
	oWd0XOQnlD1PHbYmR = url.split('/smartemadfilter?')[0]
	G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def vgsT6DpfZJPw4FbRe8a2loQ(OOYBCTKMVyFR3lpLNP,url):
	YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(OOYBCTKMVyFR3lpLNP,'all_filters')
	JaqiYfEglZDvmwQNS8zR = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
	JaqiYfEglZDvmwQNS8zR = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(JaqiYfEglZDvmwQNS8zR)
	return JaqiYfEglZDvmwQNS8zR
def sF8AGonNID9x0J3TSUL2hd1Qjv(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Zg9FeADE84jSRIvPCrzYulw3sL: oorcIqYuTf6,LeoFXqubIsNmlZ0 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	else: oorcIqYuTf6,LeoFXqubIsNmlZ0 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if yycVIo28p69ZU3XRaCbYdP[0]+'=' not in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[0]
		for YjZN3ADmertFahUQIECW in range(len(yycVIo28p69ZU3XRaCbYdP[0:-1])):
			if yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW]+'=' in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW+1]
		PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL.strip('&')+'___'+OOYBCTKMVyFR3lpLNP.strip('&')
		YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
	elif type=='ALL_ITEMS_FILTER':
		KK2pncrBCsGVagozjlQIb5dAD7k = kt4gOnZ7y6A0ifpW1L8VJFDaR(oorcIqYuTf6,'modified_values')
		KK2pncrBCsGVagozjlQIb5dAD7k = UAjMPLdITqWChbrcB(KK2pncrBCsGVagozjlQIb5dAD7k)
		if LeoFXqubIsNmlZ0!=Zg9FeADE84jSRIvPCrzYulw3sL: LeoFXqubIsNmlZ0 = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		if LeoFXqubIsNmlZ0==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+LeoFXqubIsNmlZ0
		hc5ePKxl4LJvEjDgTm = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(hc5ePKxl4LJvEjDgTm)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أظهار قائمة الفيديو التي تم اختيارها ',hc5ePKxl4LJvEjDgTm,511)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' [[   '+KK2pncrBCsGVagozjlQIb5dAD7k+'   ]]',hc5ePKxl4LJvEjDgTm,511)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	wAsQoW6l1DitrY7MC = N3feaqwRugp50CJUtScZ781QBT(url)
	dict = {}
	for name,ddFeJa6wxq2zNMPsjth9bZAmVO,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in wAsQoW6l1DitrY7MC:
		name = name.replace('--',Zg9FeADE84jSRIvPCrzYulw3sL)
		items = b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
		if '=' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = url
		if type=='SPECIFIED_FILTER':
			if ddFeJa6wxq2zNMPsjth9bZAmVO not in yycVIo28p69ZU3XRaCbYdP: continue
			if WWdHIOCPeKmgRstXk4c!=ddFeJa6wxq2zNMPsjth9bZAmVO: continue
			elif len(items)<2:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]:
					url = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(url)
					pfJ6FjwE0WlSMIBC(url)
				else: sF8AGonNID9x0J3TSUL2hd1Qjv(hc5ePKxl4LJvEjDgTm,'SPECIFIED_FILTER___'+JDm4zR9r37vHg)
				return
			else:
				hc5ePKxl4LJvEjDgTm = GUtFsHDhXuYx7zgPj6LZd3RS8imo9I(hc5ePKxl4LJvEjDgTm)
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,511)
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,515,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		elif type=='ALL_ITEMS_FILTER':
			if ddFeJa6wxq2zNMPsjth9bZAmVO not in A7qnSMrihGeFTKZL8zmODNv1U: continue
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع: '+name,hc5ePKxl4LJvEjDgTm,514,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		dict[ddFeJa6wxq2zNMPsjth9bZAmVO] = {}
		for B251BPiLbvG9UxszKtlI7YQHmoWw,xWfrLDQiMOA358ghbsZk6PtSK in items:
			if xWfrLDQiMOA358ghbsZk6PtSK in Uhe07PlWNakHDZc1t: continue
			if 'مصنفات أخرى' in xWfrLDQiMOA358ghbsZk6PtSK: continue
			if 'الكل' in xWfrLDQiMOA358ghbsZk6PtSK: continue
			if 'اللغة' in xWfrLDQiMOA358ghbsZk6PtSK: continue
			xWfrLDQiMOA358ghbsZk6PtSK = xWfrLDQiMOA358ghbsZk6PtSK.replace('قائمة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[ddFeJa6wxq2zNMPsjth9bZAmVO][B251BPiLbvG9UxszKtlI7YQHmoWw] = xWfrLDQiMOA358ghbsZk6PtSK
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+xWfrLDQiMOA358ghbsZk6PtSK
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
			OOiZSE1AIGsxBp0PqUo4bHgQ8u7 = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			if name: title = xWfrLDQiMOA358ghbsZk6PtSK+' :'+name
			else: title = xWfrLDQiMOA358ghbsZk6PtSK
			if type=='ALL_ITEMS_FILTER': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,514,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
			elif type=='SPECIFIED_FILTER' and yycVIo28p69ZU3XRaCbYdP[-2]+'=' in oorcIqYuTf6:
				JaqiYfEglZDvmwQNS8zR = vgsT6DpfZJPw4FbRe8a2loQ(OOYBCTKMVyFR3lpLNP,url)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,JaqiYfEglZDvmwQNS8zR,511)
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,515,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
	return
def kt4gOnZ7y6A0ifpW1L8VJFDaR(fn9dgJ0v1KVrZ,mode):
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.replace('=&','=0&')
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.strip('&')
	vJfWILDinBuPZjcUamEHlq = {}
	if '=' in fn9dgJ0v1KVrZ:
		items = fn9dgJ0v1KVrZ.split('&')
		for r1OMYvp0ViTG in items:
			MnwlGZ9Ef3S7kv5sxtzRiFaoCIb,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=')
			vJfWILDinBuPZjcUamEHlq[MnwlGZ9Ef3S7kv5sxtzRiFaoCIb] = B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = Zg9FeADE84jSRIvPCrzYulw3sL
	for key in A7qnSMrihGeFTKZL8zmODNv1U:
		if key in list(vJfWILDinBuPZjcUamEHlq.keys()): B251BPiLbvG9UxszKtlI7YQHmoWw = vJfWILDinBuPZjcUamEHlq[key]
		else: B251BPiLbvG9UxszKtlI7YQHmoWw = '0'
		if '%' not in B251BPiLbvG9UxszKtlI7YQHmoWw: B251BPiLbvG9UxszKtlI7YQHmoWw = OJYiDeyvSPTNI9(B251BPiLbvG9UxszKtlI7YQHmoWw)
		if mode=='modified_values' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+' + '+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='modified_filters' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='all_filters': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip(' + ')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip('&')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.replace('=0','=')
	return PJlIOHanFyNWTgfswRdYXvei4x0Vh
yycVIo28p69ZU3XRaCbYdP = []
A7qnSMrihGeFTKZL8zmODNv1U = []
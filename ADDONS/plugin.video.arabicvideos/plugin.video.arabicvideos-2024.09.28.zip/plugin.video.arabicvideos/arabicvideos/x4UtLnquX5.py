# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'CIMAFANS'
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
j0jSEdTPJuG4XNvfpO = '_CMF_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==90: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==91: CsaNhTtGm8 = yfWYTB58bDO(url)
	elif mode==92: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==94: CsaNhTtGm8 = xxSIompNHlMPkB63nRVLsTaJAbrZKg()
	elif mode==95: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==99: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,99,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المضاف حديثا',Zg9FeADE84jSRIvPCrzYulw3sL,94)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الأحدث',qfzHe2Yr49+'/?type=latest',91)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الأعلى تقيماً',qfzHe2Yr49+'/?type=imdb',91)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الأكثر مشاهدة',qfzHe2Yr49+'/?type=view',91)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المثبت',qfzHe2Yr49+'/?type=pin',91)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'جديد الأفلام',qfzHe2Yr49+'/?type=newMovies',91)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'جديد الحلقات',qfzHe2Yr49+'/?type=newEpisodes',91)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="mainmenu(.*?)nav',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<li><a href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Uhe07PlWNakHDZc1t = ['افلام للكبار فقط']
	for yDTPzhEBKVJl7CX81,title in items:
		title = title.strip(wjs26GpVfNiCUERHJ)
		if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,91)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="f-cats"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<li><a href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		title = title.strip(wjs26GpVfNiCUERHJ)
		if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,91)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def yfWYTB58bDO(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-ITEMS-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	else:
		headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-ITEMS-2nd')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="movies-items(.*?)class="listfoot"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	else: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = Zg9FeADE84jSRIvPCrzYulw3sL
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة [0-9]+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if jjYXOr8QJsNUZv0PGL27ARSDceiq4:
				title = '_MOD_'+jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,95,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/video/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,92,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,91,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pagination(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<a href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,91)
	return
def dHjny9tTucrO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-EPISODES-1st')
	W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('img src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0]
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="episodes-panel(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		name = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('itemprop="title">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if name: name = name[1]
		else:
			name = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Label')
			if u4IRSmrYMKkaHUBnDiLWh in name: name = name.split(u4IRSmrYMKkaHUBnDiLWh,1)[1]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?name">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+name+' - '+title,yDTPzhEBKVJl7CX81,92,W8KBRzkdhlCxvF5sY2T)
	else:
		OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="movietitle"><a href="(.*?)">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if OQ1FgC3a5ZLX4unm7Ebx8ji: yDTPzhEBKVJl7CX81,title = OQ1FgC3a5ZLX4unm7Ebx8ji[0]
		else: yDTPzhEBKVJl7CX81,title = url,name
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,92,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB,OS16IiQ5q3rgK4VeML29EHWJwhzo = [],[]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-PLAY-1st')
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('text-shadow: none;">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="links-panel(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?__download'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('nav-tabs"(.*?)video-panel-more',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="(.*?)".*?embed src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,yDTPzhEBKVJl7CX81 in items:
			title = 'سيرفر '+id
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-server-src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def xxSIompNHlMPkB63nRVLsTaJAbrZKg():
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAFANS-LATEST-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="index-last-movie(.*?)id="index-slider-movie',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		if '/video/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,92,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,91,W8KBRzkdhlCxvF5sY2T)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49 + '/search.php?t='+search
	yfWYTB58bDO(url)
	return
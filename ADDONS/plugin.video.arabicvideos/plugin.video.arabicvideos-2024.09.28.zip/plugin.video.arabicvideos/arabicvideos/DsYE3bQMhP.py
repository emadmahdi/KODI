# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'KATKOTTV'
j0jSEdTPJuG4XNvfpO = '_KTV_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = []
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==810: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==811: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==812: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==813: CsaNhTtGm8 = YiI6CZGR28s1fyjbF5XeToc7uS9(url)
	elif mode==819: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOTTV-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,819,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"primary-links"(.*?)"most-viewed"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<span>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,811)
	return
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOTTV-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"home-content"(.*?)"footer"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		cfUCuhJwZijTLxQX3gHayn89RqGrP = []
		for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if 'episodes' not in type and jjYXOr8QJsNUZv0PGL27ARSDceiq4:
				title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
				title = title.replace('اون لاين',Zg9FeADE84jSRIvPCrzYulw3sL)
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,813,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,812,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("'pagination'(.*?)footer",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,811,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
	return
def YiI6CZGR28s1fyjbF5XeToc7uS9(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOTTV-SERIES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"category".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81: mbzIyKNqMVt0FQeOsPWc(yDTPzhEBKVJl7CX81[0],'episodes')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0 = []
	hc5ePKxl4LJvEjDgTm = url+'?do=watch'
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOTTV-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('" src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOTTV-PLAY-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		L1LtcvTxI4q = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('post=(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if L1LtcvTxI4q:
			L1LtcvTxI4q = JDMo92nlwsAZydBPkpNzFvU.b64decode(L1LtcvTxI4q[0])
			if GGfPQnrJKEqMv2ZVxdD: L1LtcvTxI4q = L1LtcvTxI4q.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			L1LtcvTxI4q = JGmfjhoyKZUl('dict',L1LtcvTxI4q)
			CPv45ibdnBc = L1LtcvTxI4q['servers']
			WWuctLSlqizGgrK = list(CPv45ibdnBc.keys())
			CPv45ibdnBc = list(CPv45ibdnBc.values())
			F5nZmIVxBz3 = zip(WWuctLSlqizGgrK,CPv45ibdnBc)
			for title,yDTPzhEBKVJl7CX81 in F5nZmIVxBz3:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/?s='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
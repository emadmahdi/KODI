# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'GLOBALSEARCH'
j0jSEdTPJuG4XNvfpO = '_GLS_'
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	if   LfnWDFgRdJH4lZvt7yo28N==540: CsaNhTtGm8 = bELNFKS6fCB()
	elif LfnWDFgRdJH4lZvt7yo28N==541: CsaNhTtGm8 = QDzSioLwyhVZ5If2lqJHC(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==542: CsaNhTtGm8 = K2oYJvSEPQiz(Tbwq7kJ4vRSNVyUFcdMzirG,tUHrEcLYK30N,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif LfnWDFgRdJH4lZvt7yo28N==543: CsaNhTtGm8 = l3fBmndMXVvGurShH()
	elif LfnWDFgRdJH4lZvt7yo28N==548: CsaNhTtGm8 = cERvJI4wPyfgYFN(tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==549: CsaNhTtGm8 = KkZtb4lhPd(Tbwq7kJ4vRSNVyUFcdMzirG)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder','بحث جديد لجميع المواقع',Zg9FeADE84jSRIvPCrzYulw3sL,549)
	A9Z3Ci2PQhFUwBXvI('link','كيف يعمل بحث جميع المواقع','',543)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'==== كلمات البحث المخزنة ===='+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	pJK32uYjB69RdQqr45b7Oxci8PM = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if pJK32uYjB69RdQqr45b7Oxci8PM:
		pJK32uYjB69RdQqr45b7Oxci8PM = pJK32uYjB69RdQqr45b7Oxci8PM['__SEQUENCED_COLUMNS__']
		for He8xrotiaD0spXjL in reversed(pJK32uYjB69RdQqr45b7Oxci8PM):
			A9Z3Ci2PQhFUwBXvI('folder',He8xrotiaD0spXjL,Zg9FeADE84jSRIvPCrzYulw3sL,549,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,He8xrotiaD0spXjL)
	return
def KkZtb4lhPd(He8xrotiaD0spXjL):
	if not He8xrotiaD0spXjL:
		He8xrotiaD0spXjL = EnxNsqevtM28mpkZ5RG0()
		if not He8xrotiaD0spXjL: return
		He8xrotiaD0spXjL = He8xrotiaD0spXjL.lower()
	ZDUovIyE74YS2x = He8xrotiaD0spXjL.replace(j0jSEdTPJuG4XNvfpO,Zg9FeADE84jSRIvPCrzYulw3sL)
	tg4swfAUF2QmuOlDe68n9(ZDUovIyE74YS2x,'_ALL',True)
	A9Z3Ci2PQhFUwBXvI('link','بحث جماعي للمواقع - '+ZDUovIyE74YS2x,'search_sites_all',542,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('folder','بحث منفرد للمواقع - '+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,541,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','نتائج البحث مفصلة - '+ZDUovIyE74YS2x,'opened_sites_all',542,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('folder','نتائج البحث مقسمة - '+ZDUovIyE74YS2x,'listed_sites_all',542,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	return
def tg4swfAUF2QmuOlDe68n9(zPmAa2e0yR5ktGwpsFgNv,XXyfLnSPZmUc,ccN6l0ysukqbfTRE1do):
	if XXyfLnSPZmUc=='_ALL': nkypJjSCaX3G09DrdTi2vKNMgEBZP = '_GLS_'
	elif XXyfLnSPZmUc=='_GOOGLE': nkypJjSCaX3G09DrdTi2vKNMgEBZP = '_GOS_'
	rWxEH6LJowZzFNDGKlcM8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,zPmAa2e0yR5ktGwpsFgNv)
	JHWwo4ZcYsgzMG8SlBmeKX = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,nkypJjSCaX3G09DrdTi2vKNMgEBZP+zPmAa2e0yR5ktGwpsFgNv)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,zPmAa2e0yR5ktGwpsFgNv)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,nkypJjSCaX3G09DrdTi2vKNMgEBZP+zPmAa2e0yR5ktGwpsFgNv)
	n36DuKAeY7liy540BqgVLZv = rWxEH6LJowZzFNDGKlcM8+JHWwo4ZcYsgzMG8SlBmeKX
	if n36DuKAeY7liy540BqgVLZv and ccN6l0ysukqbfTRE1do: zPmAa2e0yR5ktGwpsFgNv = nkypJjSCaX3G09DrdTi2vKNMgEBZP+zPmAa2e0yR5ktGwpsFgNv
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,zPmAa2e0yR5ktGwpsFgNv,n36DuKAeY7liy540BqgVLZv,uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
	return
def N4knYsmEdB9i(XXyfLnSPZmUc):
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if jzydmKVUWrCv9D34F!=1: return
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DETAILED'+XXyfLnSPZmUc)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DIVIDED'+XXyfLnSPZmUc)
	if XXyfLnSPZmUc=='_GOOGLE': nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GOOGLESEARCH_RESULTS')
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def K2oYJvSEPQiz(uNoEG019ZIJn6itfSRr4wTvVM2F3s,uuQBhfgDrb,slALxHMEeFT7=Zg9FeADE84jSRIvPCrzYulw3sL,LZIYcvosVdDlp2PziaemKtrybHq1=o9tYLx4qFuPG,hAxtWZpsw1y2lSXUDkBRqQrJuc8={}):
	ccMA4K85fBixPzkseLNaVEo1wZ2bU,mp1SbQfnI7ZFve65MROK,sv8BnytCSm1bDiI2HTVuQ7Z,m1mrqgbZEcIJ,Ot8hbcxDfu6dv = [],{},{},{},{}
	if '_all' in uuQBhfgDrb: XXyfLnSPZmUc,ynVak3xzErGlC,nkypJjSCaX3G09DrdTi2vKNMgEBZP = '_ALL','_all','_GLS_'
	elif '_google' in uuQBhfgDrb: XXyfLnSPZmUc,ynVak3xzErGlC,nkypJjSCaX3G09DrdTi2vKNMgEBZP = '_GOOGLE','_google','_GOS_'
	if uuQBhfgDrb in ['listed_sites'+ynVak3xzErGlC,'opened_sites'+ynVak3xzErGlC,'closed_sites'+ynVak3xzErGlC]:
		if uuQBhfgDrb=='listed_sites'+ynVak3xzErGlC: ccMA4K85fBixPzkseLNaVEo1wZ2bU = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,nkypJjSCaX3G09DrdTi2vKNMgEBZP+uNoEG019ZIJn6itfSRr4wTvVM2F3s)
		elif uuQBhfgDrb=='opened_sites'+ynVak3xzErGlC: ccMA4K85fBixPzkseLNaVEo1wZ2bU = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_DETAILED'+XXyfLnSPZmUc,uNoEG019ZIJn6itfSRr4wTvVM2F3s)
		elif uuQBhfgDrb=='closed_sites'+ynVak3xzErGlC: ccMA4K85fBixPzkseLNaVEo1wZ2bU = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_DIVIDED'+XXyfLnSPZmUc,(slALxHMEeFT7,uNoEG019ZIJn6itfSRr4wTvVM2F3s))
	if not ccMA4K85fBixPzkseLNaVEo1wZ2bU:
		qS5lWUzuCiJjxwyAo1EdtD6nprV = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = 'هل تريد الآن البحث في جميع المواقع عن \n "'+U2bWzwG8VdJsBqtR74ErDi3cg1v+wjs26GpVfNiCUERHJ+uNoEG019ZIJn6itfSRr4wTvVM2F3s+wjs26GpVfNiCUERHJ+u4IRSmrYMKkaHUBnDiLWh+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if uuQBhfgDrb=='search_sites'+ynVak3xzErGlC: oHkimLnwDKNxlheUuGAMQIg9jY7dz = VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6
		else: oHkimLnwDKNxlheUuGAMQIg9jY7dz = qS5lWUzuCiJjxwyAo1EdtD6nprV+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		if jzydmKVUWrCv9D34F!=1: return
		Tk5CeWKZwqrnxjO40(False,False,False)
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Search For: [ '+uNoEG019ZIJn6itfSRr4wTvVM2F3s+' ]')
		yHZMcAP9Jjl3VT = 1
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in LZIYcvosVdDlp2PziaemKtrybHq1:
			eojZsYRl39 = hAxtWZpsw1y2lSXUDkBRqQrJuc8[FLqQoZwdAngNkz49RMGUHJXW3bDC] if hAxtWZpsw1y2lSXUDkBRqQrJuc8 else uNoEG019ZIJn6itfSRr4wTvVM2F3s
			try: AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			except: continue
			mp1SbQfnI7ZFve65MROK[FLqQoZwdAngNkz49RMGUHJXW3bDC] = []
			zIaSNiZbOTGWrcQE79gX = '_NODIALOGS_'
			if '-' in FLqQoZwdAngNkz49RMGUHJXW3bDC: zIaSNiZbOTGWrcQE79gX = zIaSNiZbOTGWrcQE79gX+'_REMEMBERRESULTS__'+FLqQoZwdAngNkz49RMGUHJXW3bDC+'_'
			if yHZMcAP9Jjl3VT:
				LNma2eq3vEguwVtHjn.sleep(0.75)
				Ot8hbcxDfu6dv[FLqQoZwdAngNkz49RMGUHJXW3bDC] = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=BZNYcxOXAElzS2IPf0aji,args=(eojZsYRl39+zIaSNiZbOTGWrcQE79gX,))
				Ot8hbcxDfu6dv[FLqQoZwdAngNkz49RMGUHJXW3bDC].start()
			else: BZNYcxOXAElzS2IPf0aji(eojZsYRl39+zIaSNiZbOTGWrcQE79gX)
			ZXWeI01flR(ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC),Zg9FeADE84jSRIvPCrzYulw3sL,LNma2eq3vEguwVtHjn=1000)
		if yHZMcAP9Jjl3VT:
			LNma2eq3vEguwVtHjn.sleep(2)
			for FLqQoZwdAngNkz49RMGUHJXW3bDC in LZIYcvosVdDlp2PziaemKtrybHq1: Ot8hbcxDfu6dv[FLqQoZwdAngNkz49RMGUHJXW3bDC].join(10)
			LNma2eq3vEguwVtHjn.sleep(2)
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in LZIYcvosVdDlp2PziaemKtrybHq1:
			try: AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			except: continue
			for CCNbwm7MIjKiv2q9RJn in AhBFVbK7LzNinwrg65JjpRP:
				RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = CCNbwm7MIjKiv2q9RJn
				if j8mQOhzZPXTwfLVM63riBa in VaOH2318eP5yQWXrkcx:
					if 'IPTV-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and (239>=LfnWDFgRdJH4lZvt7yo28N>=230 or 289>=LfnWDFgRdJH4lZvt7yo28N>=280):
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['IPTV-LIVE']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['IPTV-MOVIES']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['IPTV-SERIES']: continue
						if 'صفحة' not in VaOH2318eP5yQWXrkcx:
							if   RR5KdNtJEBT=='live': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-LIVE'
							elif RR5KdNtJEBT=='video': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-MOVIES'
							elif RR5KdNtJEBT=='folder': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-SERIES'
						else:
							if   'LIVE' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-LIVE'
							elif 'MOVIES' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-MOVIES'
							elif 'SERIES' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IPTV-SERIES'
					elif 'M3U-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and 729>=LfnWDFgRdJH4lZvt7yo28N>=710:
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['M3U-LIVE']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['M3U-MOVIES']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['M3U-SERIES']: continue
						if 'صفحة' not in VaOH2318eP5yQWXrkcx:
							if   RR5KdNtJEBT=='live': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-LIVE'
							elif RR5KdNtJEBT=='video': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-MOVIES'
							elif RR5KdNtJEBT=='folder': FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-SERIES'
						else:
							if   'LIVE' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-LIVE'
							elif 'MOVIES' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-MOVIES'
							elif 'SERIES' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'M3U-SERIES'
					elif 'YOUTUBE-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and 149>=LfnWDFgRdJH4lZvt7yo28N>=140:
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['YOUTUBE-CHANNELS']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['YOUTUBE-PLAYLISTS']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in VaOH2318eP5yQWXrkcx or ':: ' in VaOH2318eP5yQWXrkcx:
							continue
						else:
							if   LfnWDFgRdJH4lZvt7yo28N==144 and 'USER' in VaOH2318eP5yQWXrkcx: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'YOUTUBE-CHANNELS'
							elif LfnWDFgRdJH4lZvt7yo28N==144 and 'CHNL' in VaOH2318eP5yQWXrkcx: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'YOUTUBE-CHANNELS'
							elif LfnWDFgRdJH4lZvt7yo28N==144 and 'LIST' in VaOH2318eP5yQWXrkcx: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'YOUTUBE-PLAYLISTS'
							elif LfnWDFgRdJH4lZvt7yo28N==143: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and 419>=LfnWDFgRdJH4lZvt7yo28N>=400:
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['DAILYMOTION-PLAYLISTS']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['DAILYMOTION-CHANNELS']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['DAILYMOTION-VIDEOS']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['DAILYMOTION-LIVES']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['DAILYMOTION-HASHTAGS']: continue
						if   LfnWDFgRdJH4lZvt7yo28N in [401,405]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'DAILYMOTION-PLAYLISTS'
						elif LfnWDFgRdJH4lZvt7yo28N in [402,406]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'DAILYMOTION-CHANNELS'
						elif LfnWDFgRdJH4lZvt7yo28N in [404]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'DAILYMOTION-VIDEOS'
						elif LfnWDFgRdJH4lZvt7yo28N in [415]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'DAILYMOTION-LIVES'
						elif LfnWDFgRdJH4lZvt7yo28N in [416]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and 39>=LfnWDFgRdJH4lZvt7yo28N>=30:
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['PANET-SERIES']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['PANET-MOVIES']: continue
						if   LfnWDFgRdJH4lZvt7yo28N in [32,39]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'PANET-SERIES'
						elif LfnWDFgRdJH4lZvt7yo28N in [33,39]: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'PANET-MOVIES'
					elif 'IFILM-' in FLqQoZwdAngNkz49RMGUHJXW3bDC and 29>=LfnWDFgRdJH4lZvt7yo28N>=20:
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['IFILM-ARABIC']: continue
						if CCNbwm7MIjKiv2q9RJn in mp1SbQfnI7ZFve65MROK['IFILM-ENGLISH']: continue
						if   '/ar.' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IFILM-ARABIC'
						elif '/en.' in tUHrEcLYK30N: FLqQoZwdAngNkz49RMGUHJXW3bDC = 'IFILM-ENGLISH'
					mp1SbQfnI7ZFve65MROK[FLqQoZwdAngNkz49RMGUHJXW3bDC].append(CCNbwm7MIjKiv2q9RJn)
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in list(mp1SbQfnI7ZFve65MROK.keys()):
			sv8BnytCSm1bDiI2HTVuQ7Z[FLqQoZwdAngNkz49RMGUHJXW3bDC] = []
			m1mrqgbZEcIJ[FLqQoZwdAngNkz49RMGUHJXW3bDC] = []
			for RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in mp1SbQfnI7ZFve65MROK[FLqQoZwdAngNkz49RMGUHJXW3bDC]:
				CCNbwm7MIjKiv2q9RJn = (RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
				if 'صفحة' in VaOH2318eP5yQWXrkcx and RR5KdNtJEBT=='folder': m1mrqgbZEcIJ[FLqQoZwdAngNkz49RMGUHJXW3bDC].append(CCNbwm7MIjKiv2q9RJn)
				else: sv8BnytCSm1bDiI2HTVuQ7Z[FLqQoZwdAngNkz49RMGUHJXW3bDC].append(CCNbwm7MIjKiv2q9RJn)
		MMsYxuI9EikPK1,IHjuFiEesxz = [],[]
		YY1P4CAqJlQDc6fbg = list(sv8BnytCSm1bDiI2HTVuQ7Z.keys())
		jH7iXopROeWL = Eh0QVwABIdie(YY1P4CAqJlQDc6fbg)
		MiarL1JjhEyxmKqp5IkY8A = []
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in jH7iXopROeWL:
			if 'tuple' in str(type(FLqQoZwdAngNkz49RMGUHJXW3bDC)):
				MiarL1JjhEyxmKqp5IkY8A = [FLqQoZwdAngNkz49RMGUHJXW3bDC]
				continue
			if FLqQoZwdAngNkz49RMGUHJXW3bDC not in LZIYcvosVdDlp2PziaemKtrybHq1: continue
			if sv8BnytCSm1bDiI2HTVuQ7Z[FLqQoZwdAngNkz49RMGUHJXW3bDC]:
				hjDcd9U5gsX21uyWFaOtiN = ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC)
				RQZgtO5FCvypMe1Urikuhdlq3s = [('link',U2bWzwG8VdJsBqtR74ErDi3cg1v+'===== '+hjDcd9U5gsX21uyWFaOtiN+' ====='+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)]
				if 0: MLqAGYSXuRnOh9bW = uNoEG019ZIJn6itfSRr4wTvVM2F3s+' - '+'بحث'+wjs26GpVfNiCUERHJ+hjDcd9U5gsX21uyWFaOtiN
				else: MLqAGYSXuRnOh9bW = 'بحث'+wjs26GpVfNiCUERHJ+hjDcd9U5gsX21uyWFaOtiN+' - '+uNoEG019ZIJn6itfSRr4wTvVM2F3s
				if len(sv8BnytCSm1bDiI2HTVuQ7Z[FLqQoZwdAngNkz49RMGUHJXW3bDC])<8: jU2TpdkH6mo = []
				else:
					U7GhZjDbXS5FYaAxugzIMBe4 = PPQORjT2lc7SVkKwFI4D+MLqAGYSXuRnOh9bW+u4IRSmrYMKkaHUBnDiLWh
					jU2TpdkH6mo = [('folder',nkypJjSCaX3G09DrdTi2vKNMgEBZP+U7GhZjDbXS5FYaAxugzIMBe4,'closed_sites'+ynVak3xzErGlC,542,Zg9FeADE84jSRIvPCrzYulw3sL,FLqQoZwdAngNkz49RMGUHJXW3bDC,uNoEG019ZIJn6itfSRr4wTvVM2F3s,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)]
				uNAi5hFl7Ox4 = sv8BnytCSm1bDiI2HTVuQ7Z[FLqQoZwdAngNkz49RMGUHJXW3bDC]+m1mrqgbZEcIJ[FLqQoZwdAngNkz49RMGUHJXW3bDC]
				ibRZfXwjalVC9sKxgLdryI = MiarL1JjhEyxmKqp5IkY8A+RQZgtO5FCvypMe1Urikuhdlq3s+uNAi5hFl7Ox4[:7]+jU2TpdkH6mo
				MMsYxuI9EikPK1 += ibRZfXwjalVC9sKxgLdryI
				nqPmA4fxzbkT1vcMBQdCLlj3upea0 = [('folder',nkypJjSCaX3G09DrdTi2vKNMgEBZP+MLqAGYSXuRnOh9bW,'closed_sites'+ynVak3xzErGlC,542,Zg9FeADE84jSRIvPCrzYulw3sL,FLqQoZwdAngNkz49RMGUHJXW3bDC,uNoEG019ZIJn6itfSRr4wTvVM2F3s,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)]
				M38D6O5oPS4WhprZjlbK = MiarL1JjhEyxmKqp5IkY8A+nqPmA4fxzbkT1vcMBQdCLlj3upea0
				IHjuFiEesxz += M38D6O5oPS4WhprZjlbK
				cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DIVIDED'+XXyfLnSPZmUc,(FLqQoZwdAngNkz49RMGUHJXW3bDC,uNoEG019ZIJn6itfSRr4wTvVM2F3s),uNAi5hFl7Ox4,uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
				MiarL1JjhEyxmKqp5IkY8A = []
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DETAILED'+XXyfLnSPZmUc,uNoEG019ZIJn6itfSRr4wTvVM2F3s,MMsYxuI9EikPK1,uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
		nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,uNoEG019ZIJn6itfSRr4wTvVM2F3s)
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_SPLITTED'+XXyfLnSPZmUc,nkypJjSCaX3G09DrdTi2vKNMgEBZP+uNoEG019ZIJn6itfSRr4wTvVM2F3s,IHjuFiEesxz,uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		ccMA4K85fBixPzkseLNaVEo1wZ2bU = IHjuFiEesxz if uuQBhfgDrb=='listed_sites'+ynVak3xzErGlC and IHjuFiEesxz else MMsYxuI9EikPK1
	if uuQBhfgDrb in ['listed_sites'+ynVak3xzErGlC,'opened_sites'+ynVak3xzErGlC,'closed_sites'+ynVak3xzErGlC]:
		for RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in ccMA4K85fBixPzkseLNaVEo1wZ2bU:
			if uuQBhfgDrb in ['listed_sites'+ynVak3xzErGlC,'opened_sites'+ynVak3xzErGlC] and 'صفحة' in VaOH2318eP5yQWXrkcx and RR5KdNtJEBT=='folder': continue
			A9Z3Ci2PQhFUwBXvI(RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	Tk5CeWKZwqrnxjO40(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
	return
def QDzSioLwyhVZ5If2lqJHC(search):
	YY1P4CAqJlQDc6fbg = FtIMQicPuz4ZHJAW
	jH7iXopROeWL = Eh0QVwABIdie(YY1P4CAqJlQDc6fbg)
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in jH7iXopROeWL:
		if '-' in FLqQoZwdAngNkz49RMGUHJXW3bDC: continue
		if 'tuple' in str(type(FLqQoZwdAngNkz49RMGUHJXW3bDC)):
			AhBFVbK7LzNinwrg65JjpRP.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			continue
		AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		name = ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC)+' - '+search
		A9Z3Ci2PQhFUwBXvI('folder',j8mQOhzZPXTwfLVM63riBa+name,FLqQoZwdAngNkz49RMGUHJXW3bDC,548,'','',search)
	return
def cERvJI4wPyfgYFN(FLqQoZwdAngNkz49RMGUHJXW3bDC,search):
	AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
	BZNYcxOXAElzS2IPf0aji(search)
	return
def l3fBmndMXVvGurShH():
	I3kpd28CgLtrVEcuAXiZ('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def Eh0QVwABIdie(YY1P4CAqJlQDc6fbg):
	jH7iXopROeWL,MiarL1JjhEyxmKqp5IkY8A = [],None
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in FtIMQicPuz4ZHJAW:
		if FLqQoZwdAngNkz49RMGUHJXW3bDC=='PRIVATE': MiarL1JjhEyxmKqp5IkY8A = ('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات خاصة - قليلة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
		elif FLqQoZwdAngNkz49RMGUHJXW3bDC=='MIXED': MiarL1JjhEyxmKqp5IkY8A = ('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
		elif FLqQoZwdAngNkz49RMGUHJXW3bDC=='PUBLIC': MiarL1JjhEyxmKqp5IkY8A = ('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات عامة - كثيرة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
		if FLqQoZwdAngNkz49RMGUHJXW3bDC not in YY1P4CAqJlQDc6fbg: continue
		if MiarL1JjhEyxmKqp5IkY8A:
			jH7iXopROeWL.append(MiarL1JjhEyxmKqp5IkY8A)
			MiarL1JjhEyxmKqp5IkY8A = None
		if FLqQoZwdAngNkz49RMGUHJXW3bDC not in ['PRIVATE','MIXED','PUBLIC']: jH7iXopROeWL.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
	return jH7iXopROeWL
def xTNbI3ORMEfLmJ7GdnaKFlQ(uNoEG019ZIJn6itfSRr4wTvVM2F3s=Zg9FeADE84jSRIvPCrzYulw3sL):
	He8xrotiaD0spXjL,zIaSNiZbOTGWrcQE79gX,showDialogs = xXQLatdZbuT1H6(uNoEG019ZIJn6itfSRr4wTvVM2F3s)
	if not He8xrotiaD0spXjL:
		He8xrotiaD0spXjL = EnxNsqevtM28mpkZ5RG0()
		if not He8xrotiaD0spXjL: return
		He8xrotiaD0spXjL = He8xrotiaD0spXjL.lower()
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Search For: [ '+He8xrotiaD0spXjL+' ]')
	IGh3FSLfnog2BjN8s = He8xrotiaD0spXjL+zIaSNiZbOTGWrcQE79gX
	if 0: Zg670FIpDj5WA9RPYziNxnC,ZDUovIyE74YS2x = He8xrotiaD0spXjL+' - ',Zg9FeADE84jSRIvPCrzYulw3sL
	else: Zg670FIpDj5WA9RPYziNxnC,ZDUovIyE74YS2x = Zg9FeADE84jSRIvPCrzYulw3sL,' - '+He8xrotiaD0spXjL
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات خاصة - قليلة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157)
	A9Z3Ci2PQhFUwBXvI('folder','_M3U_'+Zg670FIpDj5WA9RPYziNxnC+'بحث M3U'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,719,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_IPT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث IPTV'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,239,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_BKR_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع بكرا'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,379,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_ART_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع تونز عربية'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,739,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_KRB_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع قناة كربلاء'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,329,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FH2_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فاصل الثاني'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,599,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_KTV_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع كتكوت تيفي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,819,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_EB1_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع ايجي بيست 1'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,779,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_EB2_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع ايجي بيست 2'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,789,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_IFL_'+Zg670FIpDj5WA9RPYziNxnC+'  بحث موقع قناة آي فيلم'+ZDUovIyE74YS2x+F4skx1A3wOEh9lmPuZMnpCzR,Zg9FeADE84jSRIvPCrzYulw3sL,29,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_AKO_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع أكوام القديم'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,79,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_AKW_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع أكوام الجديد'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,249,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_MRF_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع قناة المعارف'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SHM_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شوف ماكس'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,59,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157)
	A9Z3Ci2PQhFUwBXvI('folder','_LRZ_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع لاروزا'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,709,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FJS_'+Zg670FIpDj5WA9RPYziNxnC+' بحث موقع فجر شو'+ZDUovIyE74YS2x+wjs26GpVfNiCUERHJ,Zg9FeADE84jSRIvPCrzYulw3sL,399,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_TVF_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع تيفي فان'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,469,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_LDN_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع لودي نت'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,459,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CMN_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما ناو'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,309,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SHN_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شاهد نيوز'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,589,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s+'_NODIALOGS_')
	A9Z3Ci2PQhFUwBXvI('folder','_ARS_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع عرب سييد'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,259,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CCB_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما كلوب'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,829,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SH4_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شاهد فوريو'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,119,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s+'_NODIALOGS_')
	A9Z3Ci2PQhFUwBXvI('folder','_SHT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شوفها تيفي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,649,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_WC1_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع وي سيما 1'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,569,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_WC2_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع وي سيما 2'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,1009,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات عامة - كثيرة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157)
	A9Z3Ci2PQhFUwBXvI('folder','_TKT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع تكات'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,949,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FST_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فوستا'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,609,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FBK_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فبركة'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,629,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_YQT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع ياقوت'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,669,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SHB_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شبكتي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,969,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_VRB_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فاربون'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,879,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_BRS_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع برستيج'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,659,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_KRM_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع كرمالك'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,929,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_ANZ_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع انمي زد'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,979,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FSK_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فاريسكو'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,999,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_HLC_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع هلا سيما'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,89,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_MST_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع المصطبة'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,869,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SNT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع شوف نت'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,849,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_DR7_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع دراما صح'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,689,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CFR_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما فري'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,839,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CMF_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما فانز'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,99,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CML_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما لايت'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,479,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_C4H_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما 400'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,699,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_ABD_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما عبدو'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,559,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_AKT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع اكوام تيوب'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,859,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_DCF_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع دراما كافيه'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,939,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FTV_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فوشار تيفي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,919,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_CWB_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما وبس'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,989,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_AHK_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع أهواك تيفي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,619,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_SRT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيريس تايم'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,899,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_FVD_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع فوشار فيديو'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,909,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_C4P_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع سيما فور بي'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,889,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_EB4_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع ايجي بيست 4'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,809,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'مواقع سيرفرات خاصة - قليلة المشاكل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,157)
	A9Z3Ci2PQhFUwBXvI('folder','_YUT_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع يوتيوب'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,149,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	A9Z3Ci2PQhFUwBXvI('folder','_DLM_'+Zg670FIpDj5WA9RPYziNxnC+'بحث موقع دايلي موشن'+ZDUovIyE74YS2x,Zg9FeADE84jSRIvPCrzYulw3sL,409,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IGh3FSLfnog2BjN8s)
	return
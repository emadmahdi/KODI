# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from V1VREBsj92 import *
bIPsOxjEpoH = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
j0jSEdTPJuG4XNvfpO = IYC4iPxkTRUE85namF6(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
G0ElB6IpJjHAorWe2sVK584f3MPntz = brAUlZfdFmt3TRJW2xX4.path.join(VlhreQLGKx3zN,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
AAh2vP1eJCNuoLws7fnU = brAUlZfdFmt3TRJW2xX4.path.join(VlhreQLGKx3zN,UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
FuvVDThNEon = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
FFdgX0CowUKWmzDAMfNR1p7GiJksbV = LcUmF0zYN5j9uQB
F5cIAyxYT9KGLNPlVg2bE6Dem = UixkloZbzGw28ujW56X(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
gLobmQGPSEw = E3i1eCBtN2w(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
ZZci2qrgHKR = vGg1hAkzqi8exVbN(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
hbeKJGW5ptQnBr16TDjiRF0UzMd4 = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
QOGiyq0JNRP6soWL3c4F7k2lmrnd = IK4zTnSMyGQpxEaesJAPVDY(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
IKpx4sEvBW8hAGiHOqVQnRJ = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N):
	if   LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠻࠹࠶ࡾ"): CsaNhTtGm8 = IcViK1rmYty7PgWM4JNDHe5SXf()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠼࠺࠱ࡿ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(G0ElB6IpJjHAorWe2sVK584f3MPntz,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==E3i1eCBtN2w(u"࠽࠴࠳ࢀ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(AAh2vP1eJCNuoLws7fnU,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==lU1fSmncFWjizwqZugyYBANML0(u"࠷࠵࠵ࢁ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(FuvVDThNEon,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠸࠶࠷ࢂ"): CsaNhTtGm8 = XC9UMvn3SaApYBygfzxWc(FFdgX0CowUKWmzDAMfNR1p7GiJksbV,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠹࠷࠹ࢃ"): CsaNhTtGm8 = tgauNP2vJnihoyQLHSqd(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==NIBsHMvSXb(u"࠺࠹࠵ࢄ"): CsaNhTtGm8 = y1pmFvgr5wsh7QdzYeVO()
	elif LfnWDFgRdJH4lZvt7yo28N==JP65RzKaScIf(u"࠻࠺࠷ࢅ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(F5cIAyxYT9KGLNPlVg2bE6Dem,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==ykE045Tatx(u"࠼࠻࠲ࢆ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(gLobmQGPSEw,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠽࠵࠴ࢇ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(ZZci2qrgHKR,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠷࠶࠶࢈"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(hbeKJGW5ptQnBr16TDjiRF0UzMd4,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==ykE045Tatx(u"࠸࠷࠸ࢉ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(QOGiyq0JNRP6soWL3c4F7k2lmrnd,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==NIBsHMvSXb(u"࠹࠸࠺ࢊ"): CsaNhTtGm8 = eeiLrhbIvwnTuMo89ZOgEkJ(IKpx4sEvBW8hAGiHOqVQnRJ,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==E3i1eCBtN2w(u"࠺࠹࠼ࢋ"): CsaNhTtGm8 = fjzDGs952yJOo6v3pXMekWU7KVdEng(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠻࠺࠾ࢌ"): CsaNhTtGm8 = ywURMSPvzpqYdIJ9ksxTNacWuQbhD6()
	else: CsaNhTtGm8 = vvglE69OFKBm817Nkc
	return CsaNhTtGm8
def IcViK1rmYty7PgWM4JNDHe5SXf():
	lVbT7w3YmvaZ6MqKBoD,bsqTpV4OQjJczKkWXoUl2AwMn5u0I = zdiyUp7vEfuGDn5STb(G0ElB6IpJjHAorWe2sVK584f3MPntz)
	yyogdSc8EAxa2,NLDvlhU49deiaEKz3 = zdiyUp7vEfuGDn5STb(AAh2vP1eJCNuoLws7fnU)
	w8KIzfZNM9COlgAXE,YakAPr4jBe = zdiyUp7vEfuGDn5STb(FuvVDThNEon)
	kTuGF618BVmY7o2c,F3nAUc0CadMQEwRuZLBXoPV = M0VZ1cU2uDToibE6yj37RzCxkX5L(FFdgX0CowUKWmzDAMfNR1p7GiJksbV)
	kTuGF618BVmY7o2c -= A2MHFvoqpZ64gNbB(u"࠸࠼࠸࠷࠶ࢍ")
	F3nAUc0CadMQEwRuZLBXoPV -= vv3sNE8XCU2RAiyVaueTbD950pz(u"࠷ࢎ")
	JJtaBWqkQOiCMsGofLxHurbNA4 = dn9ouNryjHiBFQOhASvX(u"ࠩࠣࠬࠬࠌ")+A4rcYdw6klDWyq9K(lVbT7w3YmvaZ6MqKBoD)+ReLGYUQjz7C9iEd(u"ࠪࠤ࠲ࠦࠧࠍ")+str(bsqTpV4OQjJczKkWXoUl2AwMn5u0I)+ee3tnwl7avk(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	tKDGiWXJhlvcV14wr3E = yyZPkLCRX1xcBDN(u"ࠬࠦࠨࠨࠏ")+A4rcYdw6klDWyq9K(yyogdSc8EAxa2)+ZYTyoA483N(u"࠭ࠠ࠮ࠢࠪࠐ")+str(NLDvlhU49deiaEKz3)+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	SoVXgAKrvukHyD98szGm = qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࠢࠫࠫࠒ")+A4rcYdw6klDWyq9K(w8KIzfZNM9COlgAXE)+IYC4iPxkTRUE85namF6(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(YakAPr4jBe)+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	pWDA1s7LXiP5SCm = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࠥ࠮ࠧࠕ")+A4rcYdw6klDWyq9K(kTuGF618BVmY7o2c)+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠯ࠧࠖ")
	EmyXaqkijMezRglFPIHAChTY = lVbT7w3YmvaZ6MqKBoD+yyogdSc8EAxa2+w8KIzfZNM9COlgAXE+kTuGF618BVmY7o2c
	P5k0vocszejAwGT1tSdN6DU = bsqTpV4OQjJczKkWXoUl2AwMn5u0I+NLDvlhU49deiaEKz3+YakAPr4jBe+F3nAUc0CadMQEwRuZLBXoPV
	Tbwq7kJ4vRSNVyUFcdMzirG = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࠠࠩࠩࠗ")+A4rcYdw6klDWyq9K(EmyXaqkijMezRglFPIHAChTY)+JP65RzKaScIf(u"ࠧࠡ࠯ࠣࠫ࠘")+str(P5k0vocszejAwGT1tSdN6DU)+ZYTyoA483N(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	A9Z3Ci2PQhFUwBXvI(wFYiVd4r12x7CAQBL5SPof(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),j0jSEdTPJuG4XNvfpO+ZYTyoA483N(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"࠷࠵࠷࢏"))
	A9Z3Ci2PQhFUwBXvI(dn9ouNryjHiBFQOhASvX(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),PPQORjT2lc7SVkKwFI4D+UixkloZbzGw28ujW56X(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠺࠻࠼࠽࢐"))
	A9Z3Ci2PQhFUwBXvI(yyZPkLCRX1xcBDN(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),j0jSEdTPJuG4XNvfpO+ReLGYUQjz7C9iEd(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+JJtaBWqkQOiCMsGofLxHurbNA4,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"࠹࠷࠵࢑"))
	A9Z3Ci2PQhFUwBXvI(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),j0jSEdTPJuG4XNvfpO+vGg1hAkzqi8exVbN(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+tKDGiWXJhlvcV14wr3E,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"࠺࠸࠷࢒"))
	A9Z3Ci2PQhFUwBXvI(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),j0jSEdTPJuG4XNvfpO+ZYTyoA483N(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+SoVXgAKrvukHyD98szGm,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"࠻࠹࠹࢓"))
	A9Z3Ci2PQhFUwBXvI(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),j0jSEdTPJuG4XNvfpO+IK4zTnSMyGQpxEaesJAPVDY(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+pWDA1s7LXiP5SCm,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"࠼࠺࠴࢔"))
	yUTYoAgth5iC43uLrdBH.setSetting(yNBjYsgc23xoW(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	return
def y1pmFvgr5wsh7QdzYeVO():
	SPzw7GN30M4Q28nlpAjhB = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if ReLGYUQjz7C9iEd(u"ࠨ࠱ࠪࠧ") in C8ik4xAOE2Y53qZRJy6nbUVm else vvglE69OFKBm817Nkc
	if not SPzw7GN30M4Q28nlpAjhB:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	eemiN1oSxUJ = yUTYoAgth5iC43uLrdBH.getSetting(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not eemiN1oSxUJ: ywURMSPvzpqYdIJ9ksxTNacWuQbhD6()
	lVbT7w3YmvaZ6MqKBoD,bsqTpV4OQjJczKkWXoUl2AwMn5u0I = zdiyUp7vEfuGDn5STb(F5cIAyxYT9KGLNPlVg2bE6Dem)
	yyogdSc8EAxa2,NLDvlhU49deiaEKz3 = zdiyUp7vEfuGDn5STb(gLobmQGPSEw)
	w8KIzfZNM9COlgAXE,YakAPr4jBe = zdiyUp7vEfuGDn5STb(ZZci2qrgHKR)
	kTuGF618BVmY7o2c,F3nAUc0CadMQEwRuZLBXoPV = zdiyUp7vEfuGDn5STb(hbeKJGW5ptQnBr16TDjiRF0UzMd4)
	xDj6OC5inc7l0,FwUHMsiD9ar7xIk = zdiyUp7vEfuGDn5STb(QOGiyq0JNRP6soWL3c4F7k2lmrnd)
	cBKidj6WNtoPsqOF78ICU92hH5nz,E12N5MfSz0b7TCIHmhlZAKWJ = zdiyUp7vEfuGDn5STb(IKpx4sEvBW8hAGiHOqVQnRJ)
	JJtaBWqkQOiCMsGofLxHurbNA4 = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࠦࠨࠨࠫ")+A4rcYdw6klDWyq9K(lVbT7w3YmvaZ6MqKBoD)+ee3tnwl7avk(u"࠭ࠠ࠮ࠢࠪࠬ")+str(bsqTpV4OQjJczKkWXoUl2AwMn5u0I)+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	tKDGiWXJhlvcV14wr3E = IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࠢࠫࠫ࠮")+A4rcYdw6klDWyq9K(yyogdSc8EAxa2)+lU1fSmncFWjizwqZugyYBANML0(u"ࠩࠣ࠱ࠥ࠭࠯")+str(NLDvlhU49deiaEKz3)+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	SoVXgAKrvukHyD98szGm = lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠥ࠮ࠧ࠱")+A4rcYdw6klDWyq9K(w8KIzfZNM9COlgAXE)+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࠦ࠭ࠡࠩ࠲")+str(YakAPr4jBe)+yNBjYsgc23xoW(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	pWDA1s7LXiP5SCm = lU1fSmncFWjizwqZugyYBANML0(u"ࠧࠡࠪࠪ࠴")+A4rcYdw6klDWyq9K(kTuGF618BVmY7o2c)+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠢ࠰ࠤࠬ࠵")+str(F3nAUc0CadMQEwRuZLBXoPV)+UixkloZbzGw28ujW56X(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	apWRhxJgkIfoP0 = ee3tnwl7avk(u"ࠪࠤ࠭࠭࠷")+A4rcYdw6klDWyq9K(xDj6OC5inc7l0)+IYC4iPxkTRUE85namF6(u"ࠫࠥ࠳ࠠࠨ࠸")+str(FwUHMsiD9ar7xIk)+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	WAV5EBjUiu0mq = yNBjYsgc23xoW(u"࠭ࠠࠩࠩ࠺")+A4rcYdw6klDWyq9K(cBKidj6WNtoPsqOF78ICU92hH5nz)+JP65RzKaScIf(u"ࠧࠡ࠯ࠣࠫ࠻")+str(E12N5MfSz0b7TCIHmhlZAKWJ)+yyZPkLCRX1xcBDN(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	EmyXaqkijMezRglFPIHAChTY = lVbT7w3YmvaZ6MqKBoD+yyogdSc8EAxa2+w8KIzfZNM9COlgAXE+kTuGF618BVmY7o2c+xDj6OC5inc7l0+cBKidj6WNtoPsqOF78ICU92hH5nz
	P5k0vocszejAwGT1tSdN6DU = bsqTpV4OQjJczKkWXoUl2AwMn5u0I+NLDvlhU49deiaEKz3+YakAPr4jBe+F3nAUc0CadMQEwRuZLBXoPV+FwUHMsiD9ar7xIk+E12N5MfSz0b7TCIHmhlZAKWJ
	Tbwq7kJ4vRSNVyUFcdMzirG = ee3tnwl7avk(u"ࠩࠣࠬࠬ࠽")+A4rcYdw6klDWyq9K(EmyXaqkijMezRglFPIHAChTY)+ReLGYUQjz7C9iEd(u"ࠪࠤ࠲ࠦࠧ࠾")+str(P5k0vocszejAwGT1tSdN6DU)+ttC4VURALPYKh(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	A9Z3Ci2PQhFUwBXvI(UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),j0jSEdTPJuG4XNvfpO+yyZPkLCRX1xcBDN(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"࠽࠵࠹࢕"))
	A9Z3Ci2PQhFUwBXvI(ee3tnwl7avk(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),j0jSEdTPJuG4XNvfpO+UixkloZbzGw28ujW56X(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"࠷࠶࠹࢖"))
	A9Z3Ci2PQhFUwBXvI(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),PPQORjT2lc7SVkKwFI4D+vGg1hAkzqi8exVbN(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"࠺࠻࠼࠽ࢗ"))
	A9Z3Ci2PQhFUwBXvI(vGg1hAkzqi8exVbN(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),j0jSEdTPJuG4XNvfpO+E3i1eCBtN2w(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+JJtaBWqkQOiCMsGofLxHurbNA4,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"࠹࠸࠵࢘"))
	A9Z3Ci2PQhFUwBXvI(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),j0jSEdTPJuG4XNvfpO+IK4zTnSMyGQpxEaesJAPVDY(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+tKDGiWXJhlvcV14wr3E,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠺࠹࠷࢙"))
	A9Z3Ci2PQhFUwBXvI(ttC4VURALPYKh(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),j0jSEdTPJuG4XNvfpO+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+SoVXgAKrvukHyD98szGm,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"࠻࠺࠹࢚"))
	A9Z3Ci2PQhFUwBXvI(UixkloZbzGw28ujW56X(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),j0jSEdTPJuG4XNvfpO+ReLGYUQjz7C9iEd(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+pWDA1s7LXiP5SCm,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠼࠻࠴࢛"))
	A9Z3Ci2PQhFUwBXvI(lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),j0jSEdTPJuG4XNvfpO+ee3tnwl7avk(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+apWRhxJgkIfoP0,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠽࠵࠶࢜"))
	A9Z3Ci2PQhFUwBXvI(eCpDE6wJtYUHn0GqK5(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),j0jSEdTPJuG4XNvfpO+ttC4VURALPYKh(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+WAV5EBjUiu0mq,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠷࠶࠸࢝"))
	yUTYoAgth5iC43uLrdBH.setSetting(ReLGYUQjz7C9iEd(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	return
def ywURMSPvzpqYdIJ9ksxTNacWuQbhD6():
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),Vi1oNCM5kI7yJ0(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if jzydmKVUWrCv9D34F==-yyZPkLCRX1xcBDN(u"࠲࢞"): return
	if jzydmKVUWrCv9D34F:
		import subprocess as nr0q4U2vgwCY3b
		try:
			nr0q4U2vgwCY3b.Popen(ykE045Tatx(u"ࠬࡹࡵࠨࡕ"))
			X7XASoZOnihamYFRcCKM = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		except: X7XASoZOnihamYFRcCKM = vvglE69OFKBm817Nkc
		if X7XASoZOnihamYFRcCKM:
			DzsXxZNqWRMro9YIbcQhC5Sk6eJ8 = F5cIAyxYT9KGLNPlVg2bE6Dem+wjs26GpVfNiCUERHJ+gLobmQGPSEw+wjs26GpVfNiCUERHJ+ZZci2qrgHKR+wjs26GpVfNiCUERHJ+hbeKJGW5ptQnBr16TDjiRF0UzMd4+wjs26GpVfNiCUERHJ+QOGiyq0JNRP6soWL3c4F7k2lmrnd+wjs26GpVfNiCUERHJ+IKpx4sEvBW8hAGiHOqVQnRJ
			qiJrjtOz6NkwBUlsPAQhHYS7gba = nr0q4U2vgwCY3b.Popen(eCpDE6wJtYUHn0GqK5(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+DzsXxZNqWRMro9YIbcQhC5Sk6eJ8+E3i1eCBtN2w(u"ࠧࠣࠩࡗ"),shell=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,stdin=nr0q4U2vgwCY3b.PIPE,stdout=nr0q4U2vgwCY3b.PIPE,stderr=nr0q4U2vgwCY3b.PIPE)
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),dn9ouNryjHiBFQOhASvX(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def A4rcYdw6klDWyq9K(EmyXaqkijMezRglFPIHAChTY):
	for zambDVfyYtWTNnu8jdsoIA1G in [ttC4VURALPYKh(u"ࠬࡈࠧ࡜"),ee3tnwl7avk(u"࠭ࡋࡃࠩ࡝"),UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡎࡄࠪ࡞"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡉࡅࠫ࡟"),ttC4VURALPYKh(u"ࠩࡗࡆࠬࡠ")]:
		if EmyXaqkijMezRglFPIHAChTY<tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠳࠳࠶࠹࢟"): break
		else: EmyXaqkijMezRglFPIHAChTY /= yNBjYsgc23xoW(u"࠴࠴࠷࠺࠮࠱ࢠ")
	Tbwq7kJ4vRSNVyUFcdMzirG = Vi1oNCM5kI7yJ0(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(EmyXaqkijMezRglFPIHAChTY,zambDVfyYtWTNnu8jdsoIA1G)
	return Tbwq7kJ4vRSNVyUFcdMzirG
def zdiyUp7vEfuGDn5STb(NNduB5zFwI=vhZ5qjay1z94JmcMOgXe(u"ࠫ࠳࠭ࡢ")):
	global ckr6adjCsKwQTyZHWno,TnX4dRBe9FtSOKZuLU
	ckr6adjCsKwQTyZHWno,TnX4dRBe9FtSOKZuLU = E3i1eCBtN2w(u"࠴ࢡ"),E3i1eCBtN2w(u"࠴ࢡ")
	def nsh1fougFabNPwyDZ6UQBt(NNduB5zFwI):
		global ckr6adjCsKwQTyZHWno,TnX4dRBe9FtSOKZuLU
		if brAUlZfdFmt3TRJW2xX4.path.exists(NNduB5zFwI):
			if jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵ࢢ") and OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(brAUlZfdFmt3TRJW2xX4):
				for up2yiDfmbPegw47XqYN8nHEG1 in brAUlZfdFmt3TRJW2xX4.scandir(NNduB5zFwI):
					if up2yiDfmbPegw47XqYN8nHEG1.is_dir(follow_symlinks=vvglE69OFKBm817Nkc):
						nsh1fougFabNPwyDZ6UQBt(up2yiDfmbPegw47XqYN8nHEG1.path)
					elif up2yiDfmbPegw47XqYN8nHEG1.is_file(follow_symlinks=vvglE69OFKBm817Nkc):
						ckr6adjCsKwQTyZHWno += up2yiDfmbPegw47XqYN8nHEG1.stat().st_size
						TnX4dRBe9FtSOKZuLU += A2MHFvoqpZ64gNbB(u"࠷ࢣ")
			else:
				for up2yiDfmbPegw47XqYN8nHEG1 in brAUlZfdFmt3TRJW2xX4.listdir(NNduB5zFwI):
					aLCfkjG24NFqbPYv7s1y8xK = brAUlZfdFmt3TRJW2xX4.path.abspath(brAUlZfdFmt3TRJW2xX4.path.join(NNduB5zFwI,up2yiDfmbPegw47XqYN8nHEG1))
					if brAUlZfdFmt3TRJW2xX4.path.isdir(aLCfkjG24NFqbPYv7s1y8xK):
						nsh1fougFabNPwyDZ6UQBt(aLCfkjG24NFqbPYv7s1y8xK)
					elif brAUlZfdFmt3TRJW2xX4.path.isfile(aLCfkjG24NFqbPYv7s1y8xK):
						EmyXaqkijMezRglFPIHAChTY,P5k0vocszejAwGT1tSdN6DU = M0VZ1cU2uDToibE6yj37RzCxkX5L(aLCfkjG24NFqbPYv7s1y8xK)
						ckr6adjCsKwQTyZHWno += EmyXaqkijMezRglFPIHAChTY
						TnX4dRBe9FtSOKZuLU += P5k0vocszejAwGT1tSdN6DU
		return
	try: nsh1fougFabNPwyDZ6UQBt(NNduB5zFwI)
	except: pass
	return ckr6adjCsKwQTyZHWno,TnX4dRBe9FtSOKZuLU
def szcl4TmkUMZgP(rihYIp1JFC,showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),rihYIp1JFC+UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࡝ࡰ࡟ࡲࠬࡥ")+PPQORjT2lc7SVkKwFI4D+yNBjYsgc23xoW(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࠬࡦ")+u4IRSmrYMKkaHUBnDiLWh)
		if jzydmKVUWrCv9D34F!=YXm2qAbu8Qsx(u"࠱ࢤ"): return
	uunaWoJjrMmG = vvglE69OFKBm817Nkc
	if brAUlZfdFmt3TRJW2xX4.path.exists(rihYIp1JFC):
		try: brAUlZfdFmt3TRJW2xX4.remove(rihYIp1JFC)
		except Exception as PjKYan9qS0cAhrQImfue:
			if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡧ"),str(PjKYan9qS0cAhrQImfue))
			uunaWoJjrMmG = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if showDialogs and not uunaWoJjrMmG:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),wFYiVd4r12x7CAQBL5SPof(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def tgauNP2vJnihoyQLHSqd(showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),PPQORjT2lc7SVkKwFI4D+ee3tnwl7avk(u"࠭็ๅࠢอี๏ีࠠๆีะࠫ࡫")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭࡬")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨมࠤࠥࠬ࡭")+u4IRSmrYMKkaHUBnDiLWh)
		if jzydmKVUWrCv9D34F!=qdEKO42r3GhwmCDcHtxzJUR(u"࠲ࢥ"): return
	eeiLrhbIvwnTuMo89ZOgEkJ(G0ElB6IpJjHAorWe2sVK584f3MPntz,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(AAh2vP1eJCNuoLws7fnU,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(FuvVDThNEon,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	XC9UMvn3SaApYBygfzxWc(FFdgX0CowUKWmzDAMfNR1p7GiJksbV,vvglE69OFKBm817Nkc)
	if showDialogs:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def fjzDGs952yJOo6v3pXMekWU7KVdEng(showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),PPQORjT2lc7SVkKwFI4D+UQS9lVew50DIyXrinWsMxTzA(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩࡱ")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ykE045Tatx(u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪࡲ")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+vhZ5qjay1z94JmcMOgXe(u"ࠧࡀࠣࠤࠫࡳ")+u4IRSmrYMKkaHUBnDiLWh)
		if jzydmKVUWrCv9D34F!=IK4zTnSMyGQpxEaesJAPVDY(u"࠳ࢦ"): return
	eeiLrhbIvwnTuMo89ZOgEkJ(F5cIAyxYT9KGLNPlVg2bE6Dem,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(gLobmQGPSEw,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(ZZci2qrgHKR,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(hbeKJGW5ptQnBr16TDjiRF0UzMd4,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(QOGiyq0JNRP6soWL3c4F7k2lmrnd,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	eeiLrhbIvwnTuMo89ZOgEkJ(IKpx4sEvBW8hAGiHOqVQnRJ,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	if showDialogs:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡴ"),ee3tnwl7avk(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࡵ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def XC9UMvn3SaApYBygfzxWc(w32cbMhWTreVNRq84K,showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),PPQORjT2lc7SVkKwFI4D+x9PULjztJOpu7b(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรࠦࠧࠧࡷ")+u4IRSmrYMKkaHUBnDiLWh)
		if jzydmKVUWrCv9D34F!=ZYTyoA483N(u"࠴ࢧ"): return
	KAyrTaiwVmYnCS2NbPp = rNIFwicQYy7ZKf4XlzoP9Rj.connect(w32cbMhWTreVNRq84K)
	KAyrTaiwVmYnCS2NbPp.text_factory = str
	wxljEVBYCes0uWnzdZKDbhyI = KAyrTaiwVmYnCS2NbPp.cursor()
	wxljEVBYCes0uWnzdZKDbhyI.execute(YXm2qAbu8Qsx(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࡸ"))
	wxljEVBYCes0uWnzdZKDbhyI.execute(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࡹ"))
	wxljEVBYCes0uWnzdZKDbhyI.execute(ttC4VURALPYKh(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࡺ"))
	KAyrTaiwVmYnCS2NbPp.commit()
	wxljEVBYCes0uWnzdZKDbhyI.execute(IYC4iPxkTRUE85namF6(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࡻ"))
	KAyrTaiwVmYnCS2NbPp.close()
	if showDialogs:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),DKmLTA2yGtj(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫࡽ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'YOUTUBE'
j0jSEdTPJuG4XNvfpO = '_YUT_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,text,type,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	if	 mode==140: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==143: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url,type)
	elif mode==144: CsaNhTtGm8 = yfWYTB58bDO(url,text,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==145: CsaNhTtGm8 = FlAhOu94bM0(url)
	elif mode==146: CsaNhTtGm8 = LM5G0cuE3fCkmFt7sSP6oX(url)
	elif mode==147: CsaNhTtGm8 = pO14eqnEmrW6PDyRYUNfta()
	elif mode==148: CsaNhTtGm8 = JDkx34LlheQO1cTfsVNSWyo()
	elif mode==149: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,149,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج',Zg9FeADE84jSRIvPCrzYulw3sL,290)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'مواقع اختارها يوتيوب',qfzHe2Yr49+'/feed/guide_builder',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الصفحة الرئيسية',qfzHe2Yr49,144,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المحتوى الرائج',qfzHe2Yr49+'/feed/trending',146)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: قنوات عربية',Zg9FeADE84jSRIvPCrzYulw3sL,147)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: قنوات أجنبية',Zg9FeADE84jSRIvPCrzYulw3sL,148)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: افلام عربية',qfzHe2Yr49+'/results?search_query=فيلم',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: افلام اجنبية',qfzHe2Yr49+'/results?search_query=movie',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: مسرحيات عربية',qfzHe2Yr49+'/results?search_query=مسرحية',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات عربية',qfzHe2Yr49+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات اجنبية',qfzHe2Yr49+'/results?search_query=series&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات كارتون',qfzHe2Yr49+'/results?search_query=كارتون&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بحث: خطبة المرجعية',qfzHe2Yr49+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def pO14eqnEmrW6PDyRYUNfta():
	yfWYTB58bDO(qfzHe2Yr49+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JDkx34LlheQO1cTfsVNSWyo():
	yfWYTB58bDO(qfzHe2Yr49+'/results?search_query=tv&sp=EgJAAQ==')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url,type):
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([url],bIPsOxjEpoH,type,url)
	return
def LM5G0cuE3fCkmFt7sSP6oX(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,wxljEVBYCes0uWnzdZKDbhyI,data = Zy7Ic8LBx6V(url)
	bUKcqWhZ4E = wxljEVBYCes0uWnzdZKDbhyI['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for OEJ3PT81KtbZ in range(len(bUKcqWhZ4E)):
		r1OMYvp0ViTG = bUKcqWhZ4E[OEJ3PT81KtbZ]
		ujNowMQmCZX5(r1OMYvp0ViTG,url,str(OEJ3PT81KtbZ))
	Nl7J28ywXDWOe = bUKcqWhZ4E[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	VEsh8BwK5ey4J19MUSOLkNalZC = 0
	for OEJ3PT81KtbZ in range(len(Nl7J28ywXDWOe)):
		r1OMYvp0ViTG = Nl7J28ywXDWOe[OEJ3PT81KtbZ]['itemSectionRenderer']['contents'][0]
		if list(r1OMYvp0ViTG['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = p69zNbLrhMJECknqXaics7Pt21(r1OMYvp0ViTG)
		if not title:
			VEsh8BwK5ey4J19MUSOLkNalZC += 1
			title = 'فيديوهات رائجة '+str(VEsh8BwK5ey4J19MUSOLkNalZC)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,144,Zg9FeADE84jSRIvPCrzYulw3sL,str(OEJ3PT81KtbZ))
	key = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"innertubeApiKey":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,wxljEVBYCes0uWnzdZKDbhyI,mrn4jdBuXKIw7N2lvh = Zy7Ic8LBx6V(hc5ePKxl4LJvEjDgTm)
	for V8lpkbt69RLE1Nd5jAYizJOge in range(3,4):
		bUKcqWhZ4E = wxljEVBYCes0uWnzdZKDbhyI['items'][V8lpkbt69RLE1Nd5jAYizJOge]['guideSectionRenderer']['items']
		for OEJ3PT81KtbZ in range(len(bUKcqWhZ4E)):
			r1OMYvp0ViTG = bUKcqWhZ4E[OEJ3PT81KtbZ]
			if 'YouTube Premium' in str(r1OMYvp0ViTG): continue
			ujNowMQmCZX5(r1OMYvp0ViTG)
	return
def yfWYTB58bDO(url,data=Zg9FeADE84jSRIvPCrzYulw3sL,index=0):
	global yUTYoAgth5iC43uLrdBH
	if not data: data = yUTYoAgth5iC43uLrdBH.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,wxljEVBYCes0uWnzdZKDbhyI,mrn4jdBuXKIw7N2lvh = Zy7Ic8LBx6V(url,data)
	mmZyA7ped4FXBEiuD,f478LQrMHSPNVED2neo = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	Mles4QpWJtb0vzDZCj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not Mles4QpWJtb0vzDZCj: Mles4QpWJtb0vzDZCj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not Mles4QpWJtb0vzDZCj: Mles4QpWJtb0vzDZCj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if Mles4QpWJtb0vzDZCj:
		mmZyA7ped4FXBEiuD = PPQORjT2lc7SVkKwFI4D+Mles4QpWJtb0vzDZCj[0][0]+u4IRSmrYMKkaHUBnDiLWh
		yDTPzhEBKVJl7CX81 = Mles4QpWJtb0vzDZCj[0][1]
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
		if 'list=' in url: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+mmZyA7ped4FXBEiuD,yDTPzhEBKVJl7CX81,144)
	zFUaSclqsph7NZEJ = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	VVia842usHrLCKqZ = not any(B251BPiLbvG9UxszKtlI7YQHmoWw in url for B251BPiLbvG9UxszKtlI7YQHmoWw in zFUaSclqsph7NZEJ)
	if VVia842usHrLCKqZ and mmZyA7ped4FXBEiuD:
		kHDNMKGBw6pdeJ0WZi4 = 'البحث'
		wUpHn5IfzaQ8g4j = 'قوائم التشغيل'
		TMWIQ9soPr = 'الفيديوهات'
		SPBdzpmsOvKf = 'القنوات'
		A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+mmZyA7ped4FXBEiuD,url,9999)
		if '"title":"بحث"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+kHDNMKGBw6pdeJ0WZi4,url,145,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+wUpHn5IfzaQ8g4j,url+'/playlists',144)
		if '"title":"الفيديوهات"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+TMWIQ9soPr,url+'/videos',144)
		if '"title":"القنوات"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+SPBdzpmsOvKf,url+'/channels',144)
		if '"title":"Search"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+kHDNMKGBw6pdeJ0WZi4,url,145,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
		if '"title":"Playlists"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+wUpHn5IfzaQ8g4j,url+'/playlists',144)
		if '"title":"Videos"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+TMWIQ9soPr,url+'/videos',144)
		if '"title":"Channels"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+SPBdzpmsOvKf,url+'/channels',144)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	if 'search_query' in url:
		bUKcqWhZ4E = wxljEVBYCes0uWnzdZKDbhyI['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		V6TI7XQbcf = 0
		for YjZN3ADmertFahUQIECW in range(len(bUKcqWhZ4E)):
			if 'itemSectionRenderer' in list(bUKcqWhZ4E[YjZN3ADmertFahUQIECW].keys()):
				iiUVc9hW7kEdowFguOaq0QeJs3 = bUKcqWhZ4E[YjZN3ADmertFahUQIECW]['itemSectionRenderer']
				OmyQoW6Gkh2sx = len(str(iiUVc9hW7kEdowFguOaq0QeJs3))
				if OmyQoW6Gkh2sx>V6TI7XQbcf:
					V6TI7XQbcf = OmyQoW6Gkh2sx
					f478LQrMHSPNVED2neo = iiUVc9hW7kEdowFguOaq0QeJs3
		if V6TI7XQbcf==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==qfzHe2Yr49:
		TIK6UbCFHmWd4s5DJS = []
		TIK6UbCFHmWd4s5DJS.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		TIK6UbCFHmWd4s5DJS.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		TIK6UbCFHmWd4s5DJS.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		TIK6UbCFHmWd4s5DJS.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		TIK6UbCFHmWd4s5DJS.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		TIK6UbCFHmWd4s5DJS.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		TIK6UbCFHmWd4s5DJS.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		TIK6UbCFHmWd4s5DJS.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		ovDj4C7lYwGT5BHQE,f478LQrMHSPNVED2neo = CErNhTp9IJjGfcBUnA(wxljEVBYCes0uWnzdZKDbhyI,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
	if not f478LQrMHSPNVED2neo:
		try:
			bUKcqWhZ4E = wxljEVBYCes0uWnzdZKDbhyI['contents']['twoColumnBrowseResultsRenderer']['tabs']
			qL8lfNzH5aXv1FmI907nGYtsKUp3 = '/videos' in url or '/playlists' in url or '/channels' in url
			QkevIoz23BcMHuZpEFYLAxw6mh = '"title":"الفيديوهات"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG or '"title":"قوائم التشغيل"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG or '"title":"القنوات"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
			fSI9UvCA5p8PuV0QbkolRwan21 = '"title":"Videos"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG or '"title":"Playlists"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG or '"title":"Channels"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
			if qL8lfNzH5aXv1FmI907nGYtsKUp3 and (QkevIoz23BcMHuZpEFYLAxw6mh or fSI9UvCA5p8PuV0QbkolRwan21):
				for OEJ3PT81KtbZ in range(len(bUKcqWhZ4E)):
					if 'tabRenderer' not in list(bUKcqWhZ4E[OEJ3PT81KtbZ].keys()): continue
					Nl7J28ywXDWOe = bUKcqWhZ4E[OEJ3PT81KtbZ]['tabRenderer']
					try: ROJHnuli0dAhUG84k2TsV7bEtz = Nl7J28ywXDWOe['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][OEJ3PT81KtbZ]
					except: ROJHnuli0dAhUG84k2TsV7bEtz = Nl7J28ywXDWOe
					try: yDTPzhEBKVJl7CX81 = ROJHnuli0dAhUG84k2TsV7bEtz['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in yDTPzhEBKVJl7CX81	and '/videos'		in url: Nl7J28ywXDWOe = bUKcqWhZ4E[OEJ3PT81KtbZ] ; break
					elif '/playlists'	in yDTPzhEBKVJl7CX81	and '/playlists'	in url: Nl7J28ywXDWOe = bUKcqWhZ4E[OEJ3PT81KtbZ] ; break
					elif '/channels'	in yDTPzhEBKVJl7CX81	and '/channels'		in url: Nl7J28ywXDWOe = bUKcqWhZ4E[OEJ3PT81KtbZ] ; break
					else: Nl7J28ywXDWOe = bUKcqWhZ4E[0]
			elif 'bp=' in url: Nl7J28ywXDWOe = bUKcqWhZ4E[index]
			else: Nl7J28ywXDWOe = bUKcqWhZ4E[0]
			f478LQrMHSPNVED2neo = Nl7J28ywXDWOe['tabRenderer']['content']
		except: pass
	if not f478LQrMHSPNVED2neo: return
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("ff['sectionListRenderer']")
	TIK6UbCFHmWd4s5DJS.append("ff['richGridRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("ff['contents']")
	TIK6UbCFHmWd4s5DJS.append("ff")
	Cz2nTVw9EUJ = nWsGkOX74PMJ(u'كل قوائم التشغيل')
	KdOvHuRoT6yVFSgBqQ7i54Ex1se = nWsGkOX74PMJ(u'كل الفيديوهات')
	JiEFB4ZegyDw6N7ptQ = nWsGkOX74PMJ(u'كل القنوات')
	E9EGNWlTumKQeHz = [Cz2nTVw9EUJ,KdOvHuRoT6yVFSgBqQ7i54Ex1se,JiEFB4ZegyDw6N7ptQ,'All playlists','All videos','All channels']
	ll4qwsz5DimCuPIxG0R6bOXoJ3d1AZ,ROJHnuli0dAhUG84k2TsV7bEtz = CErNhTp9IJjGfcBUnA(f478LQrMHSPNVED2neo,index,TIK6UbCFHmWd4s5DJS)
	if 'list' in str(type(ROJHnuli0dAhUG84k2TsV7bEtz)) and any(B251BPiLbvG9UxszKtlI7YQHmoWw in str(ROJHnuli0dAhUG84k2TsV7bEtz[0]) for B251BPiLbvG9UxszKtlI7YQHmoWw in E9EGNWlTumKQeHz): del ROJHnuli0dAhUG84k2TsV7bEtz[0]
	for ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo in range(len(ROJHnuli0dAhUG84k2TsV7bEtz)):
		TIK6UbCFHmWd4s5DJS = []
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['itemSectionRenderer']['header']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['horizontalCardListRenderer']['header']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['richSectionRenderer']['content']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['richItemRenderer']['content']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]['gameCardRenderer']['game']")
		TIK6UbCFHmWd4s5DJS.append("gg[index2]")
		ovDj4C7lYwGT5BHQE,r1OMYvp0ViTG = CErNhTp9IJjGfcBUnA(ROJHnuli0dAhUG84k2TsV7bEtz,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,TIK6UbCFHmWd4s5DJS)
		ujNowMQmCZX5(r1OMYvp0ViTG,url,str(ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo))
		if ovDj4C7lYwGT5BHQE=='4':
			try:
				RbEea9TOgmwLtpdJZDWsnx = r1OMYvp0ViTG['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for CYQDmvEFh2wuSAdaG in range(len(RbEea9TOgmwLtpdJZDWsnx)):
					l21p6EPJTbjNarG9Z = RbEea9TOgmwLtpdJZDWsnx[CYQDmvEFh2wuSAdaG]
					ujNowMQmCZX5(l21p6EPJTbjNarG9Z)
			except: pass
	RtyHnUF927GqVs5p0NgZ3 = False
	if 'view=' not in url and ll4qwsz5DimCuPIxG0R6bOXoJ3d1AZ=='8': RtyHnUF927GqVs5p0NgZ3 = True
	if ':::' in mrn4jdBuXKIw7N2lvh: I0uARYmrbH,key,o6UAaqsHzNfgkYrCKBFL,KKBkbifw0rHsxMO,dkKX8zLCs6yqBlD7Y5geZEpAicua20,JzCR5e4cNODUlSwhryx = mrn4jdBuXKIw7N2lvh.split(':::')
	else: I0uARYmrbH,key,o6UAaqsHzNfgkYrCKBFL,KKBkbifw0rHsxMO,dkKX8zLCs6yqBlD7Y5geZEpAicua20,JzCR5e4cNODUlSwhryx = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	hc5ePKxl4LJvEjDgTm,aGhnZkfYXLqx2i5FJrBbDU = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if AhBFVbK7LzNinwrg65JjpRP:
		bh1uOBmLvsWgjUctqVeI = str(AhBFVbK7LzNinwrg65JjpRP[-1][1])
		if   j0jSEdTPJuG4XNvfpO+'CHNL' in bh1uOBmLvsWgjUctqVeI: aGhnZkfYXLqx2i5FJrBbDU = 'CHANNELS'
		elif j0jSEdTPJuG4XNvfpO+'USER' in bh1uOBmLvsWgjUctqVeI: aGhnZkfYXLqx2i5FJrBbDU = 'CHANNELS'
		elif j0jSEdTPJuG4XNvfpO+'LIST' in bh1uOBmLvsWgjUctqVeI: aGhnZkfYXLqx2i5FJrBbDU = 'PLAYLISTS'
	if '"continuations"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG and '&list=' not in url and not RtyHnUF927GqVs5p0NgZ3 and 'shelf_id' not in url:
		hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/browse_ajax?ctoken='+o6UAaqsHzNfgkYrCKBFL
	elif '"token"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/youtubei/v1/search?key='+key
	elif '"token"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG and 'bp=' not in url:
		hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/youtubei/v1/browse?key='+key
	if hc5ePKxl4LJvEjDgTm: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة أخرى',hc5ePKxl4LJvEjDgTm,144,aGhnZkfYXLqx2i5FJrBbDU,Zg9FeADE84jSRIvPCrzYulw3sL,mrn4jdBuXKIw7N2lvh)
	return
def CErNhTp9IJjGfcBUnA(uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,y9yjOtLpFC7kNXn):
	wxljEVBYCes0uWnzdZKDbhyI = uNy4ZJUMEiTj5aS0Rxf619YPzrk
	f478LQrMHSPNVED2neo,index = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	ROJHnuli0dAhUG84k2TsV7bEtz,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	count = len(y9yjOtLpFC7kNXn)
	for OEJ3PT81KtbZ in range(count):
		try:
			PSBDMWlY6NQ1JbthzsEA28jrny = eval(y9yjOtLpFC7kNXn[OEJ3PT81KtbZ])
			return str(OEJ3PT81KtbZ+1),PSBDMWlY6NQ1JbthzsEA28jrny
		except: pass
	return Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
def p69zNbLrhMJECknqXaics7Pt21(r1OMYvp0ViTG):
	try: UQ5w87jKFg3xfZB24 = list(r1OMYvp0ViTG.keys())[0]
	except: return False,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = False,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	AAYwlR5v3MobImasCj1L4kpgScVK = r1OMYvp0ViTG[UQ5w87jKFg3xfZB24]
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("render['unplayableText']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['formattedTitle']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['title']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['title']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("render['text']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['text']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("render['title']")
	TIK6UbCFHmWd4s5DJS.append("item['title']")
	ovDj4C7lYwGT5BHQE,title = CErNhTp9IJjGfcBUnA(r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	ovDj4C7lYwGT5BHQE,yDTPzhEBKVJl7CX81 = CErNhTp9IJjGfcBUnA(r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("render['thumbnail']['thumbnails'][0]['url']")
	TIK6UbCFHmWd4s5DJS.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	ovDj4C7lYwGT5BHQE,W8KBRzkdhlCxvF5sY2T = CErNhTp9IJjGfcBUnA(r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("render['videoCount']")
	TIK6UbCFHmWd4s5DJS.append("render['videoCountText']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	ovDj4C7lYwGT5BHQE,count = CErNhTp9IJjGfcBUnA(r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("render['lengthText']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	ovDj4C7lYwGT5BHQE,NAdtOanYBmF0IWbMvXxz7lERiTjo = CErNhTp9IJjGfcBUnA(r1OMYvp0ViTG,AAYwlR5v3MobImasCj1L4kpgScVK,TIK6UbCFHmWd4s5DJS)
	if 'LIVE' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW = Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE:  '
	if 'مباشر' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW = Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE:  '
	if 'badges' in list(AAYwlR5v3MobImasCj1L4kpgScVK.keys()):
		JWedSOVDfHFmzPCl4jIiv9MK5Y8 = str(AAYwlR5v3MobImasCj1L4kpgScVK['badges'])
		if 'Free with Ads' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$:'
		if 'LIVE NOW' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: TEXIUNJc7iyHKkav94rmZQW = 'LIVE:  '
		if 'Buy' in JWedSOVDfHFmzPCl4jIiv9MK5Y8 or 'Rent' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:'
		if nWsGkOX74PMJ(u'مباشر') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: TEXIUNJc7iyHKkav94rmZQW = 'LIVE:  '
		if nWsGkOX74PMJ(u'شراء') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:'
		if nWsGkOX74PMJ(u'استئجار') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:'
		if nWsGkOX74PMJ(u'إعلانات') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$:'
	yDTPzhEBKVJl7CX81 = uumhMi6O4pk7Gjd5aTQqy2Z(yDTPzhEBKVJl7CX81)
	if yDTPzhEBKVJl7CX81 and 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
	W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.split('?')[0]
	if  W8KBRzkdhlCxvF5sY2T and 'http' not in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = 'https:'+W8KBRzkdhlCxvF5sY2T
	title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
	if sQ1LAcp3TKzZry9i27ovuMGND4HgfJ: title = sQ1LAcp3TKzZry9i27ovuMGND4HgfJ+F4skx1A3wOEh9lmPuZMnpCzR+title
	NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace(',',Zg9FeADE84jSRIvPCrzYulw3sL)
	count = count.replace(',',Zg9FeADE84jSRIvPCrzYulw3sL)
	count = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\d+',count)
	if count: count = count[0]
	else: count = Zg9FeADE84jSRIvPCrzYulw3sL
	return True,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ
def ujNowMQmCZX5(r1OMYvp0ViTG,url=Zg9FeADE84jSRIvPCrzYulw3sL,index=Zg9FeADE84jSRIvPCrzYulw3sL):
	Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = p69zNbLrhMJECknqXaics7Pt21(r1OMYvp0ViTG)
	if not Gr0K5RUTIpstSm1wdle7bAxBXHLkVM: return
	elif 'continuationItemRenderer' in str(r1OMYvp0ViTG): return
	elif 'searchPyvRenderer' in str(r1OMYvp0ViTG): return
	elif not yDTPzhEBKVJl7CX81 and 'search_query' in url: return
	elif title and not yDTPzhEBKVJl7CX81 and ('search_query' in url or 'horizontalMovieListRenderer' in str(r1OMYvp0ViTG) or url==qfzHe2Yr49):
		title = '=== '+title+' ==='
		A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	elif title and 'messageRenderer' in str(r1OMYvp0ViTG):
		A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	elif '/feed/trending' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,index)
	elif not title: return
	elif TEXIUNJc7iyHKkav94rmZQW: A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+TEXIUNJc7iyHKkav94rmZQW+title,yDTPzhEBKVJl7CX81,143,W8KBRzkdhlCxvF5sY2T)
	elif 'watch?v=' in yDTPzhEBKVJl7CX81 or '/shorts/' in yDTPzhEBKVJl7CX81:
		if '&list=' in yDTPzhEBKVJl7CX81 and 'index=' not in yDTPzhEBKVJl7CX81:
			iiyTIU3vuegMr = yDTPzhEBKVJl7CX81.split('&list=',1)[1]
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/playlist?list='+iiyTIU3vuegMr
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'LIST'+count+':  '+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T)
		else:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&list=',1)[0]
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,143,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	else:
		type = Zg9FeADE84jSRIvPCrzYulw3sL
		if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = url
		elif not any(B251BPiLbvG9UxszKtlI7YQHmoWw in yDTPzhEBKVJl7CX81 for B251BPiLbvG9UxszKtlI7YQHmoWw in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in yDTPzhEBKVJl7CX81 or '/c/' in yDTPzhEBKVJl7CX81: type = 'CHNL'+count+':  '
			if '/user/' in yDTPzhEBKVJl7CX81: type = 'USER'+count+':  '
			index,TmcICRsBzVGrM0PAq7L2ojpHtigdZ = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+type+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,index)
	return
def Zy7Ic8LBx6V(url,data=Zg9FeADE84jSRIvPCrzYulw3sL,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	global yUTYoAgth5iC43uLrdBH
	if not data: data = yUTYoAgth5iC43uLrdBH.getSetting('av.youtube.data')
	if YYAz8aPFGR2n==Zg9FeADE84jSRIvPCrzYulw3sL: YYAz8aPFGR2n = 'ytInitialData'
	qoCMENGx4WgKp = lAfzvsbYy7oQ3r28EMe()
	Y3OmVPp2ARgBCjn = {'User-Agent':qoCMENGx4WgKp,'Cookie':'PREF=hl=ar'}
	if ':::' in data: I0uARYmrbH,key,o6UAaqsHzNfgkYrCKBFL,KKBkbifw0rHsxMO,dkKX8zLCs6yqBlD7Y5geZEpAicua20,JzCR5e4cNODUlSwhryx = data.split(':::')
	else: I0uARYmrbH,key,o6UAaqsHzNfgkYrCKBFL,KKBkbifw0rHsxMO,dkKX8zLCs6yqBlD7Y5geZEpAicua20,JzCR5e4cNODUlSwhryx = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if 'guide?key=' in url:
		mrn4jdBuXKIw7N2lvh = {}
		mrn4jdBuXKIw7N2lvh['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":KKBkbifw0rHsxMO}}
		mrn4jdBuXKIw7N2lvh = str(mrn4jdBuXKIw7N2lvh)
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and I0uARYmrbH:
		mrn4jdBuXKIw7N2lvh = {'continuation':dkKX8zLCs6yqBlD7Y5geZEpAicua20}
		mrn4jdBuXKIw7N2lvh['context'] = {"client":{"visitorData":I0uARYmrbH,"clientName":"WEB","clientVersion":KKBkbifw0rHsxMO}}
		mrn4jdBuXKIw7N2lvh = str(mrn4jdBuXKIw7N2lvh)
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and JzCR5e4cNODUlSwhryx:
		Y3OmVPp2ARgBCjn.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':KKBkbifw0rHsxMO})
		Y3OmVPp2ARgBCjn.update({'Cookie':'VISITOR_INFO1_LIVE='+JzCR5e4cNODUlSwhryx})
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'YOUTUBE-GET_PAGE_DATA-4th')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"innertubeApiKey".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: key = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0]
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"cver".*?"value".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: KKBkbifw0rHsxMO = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0]
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"token".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: dkKX8zLCs6yqBlD7Y5geZEpAicua20 = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0]
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"visitorData".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: I0uARYmrbH = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0]
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"continuation".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: o6UAaqsHzNfgkYrCKBFL = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0]
	cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): JzCR5e4cNODUlSwhryx = cookies['VISITOR_INFO1_LIVE']
	data = I0uARYmrbH+':::'+key+':::'+o6UAaqsHzNfgkYrCKBFL+':::'+KKBkbifw0rHsxMO+':::'+dkKX8zLCs6yqBlD7Y5geZEpAicua20+':::'+JzCR5e4cNODUlSwhryx
	if YYAz8aPFGR2n=='ytInitialData' and 'ytInitialData' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('window\["ytInitialData"\] = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not KHErs7vLe0CUQ6wXBnNpz1iohfkg4: KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var ytInitialData = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',KHErs7vLe0CUQ6wXBnNpz1iohfkg4[0])
	elif YYAz8aPFGR2n=='ytInitialGuideData' and 'ytInitialGuideData' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var ytInitialGuideData = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',KHErs7vLe0CUQ6wXBnNpz1iohfkg4[0])
	elif '</script>' not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	else: K0Hn1gbiTqGLEt = Zg9FeADE84jSRIvPCrzYulw3sL
	yUTYoAgth5iC43uLrdBH.setSetting('av.youtube.data',data)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,K0Hn1gbiTqGLEt,data
def FlAhOu94bM0(url):
	search = EnxNsqevtM28mpkZ5RG0()
	if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	hc5ePKxl4LJvEjDgTm = url+'/search?query='+search
	yfWYTB58bDO(hc5ePKxl4LJvEjDgTm)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAg%253D%253D'
		JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+vjCZJNa4kXpt6IPWYDuf
	else:
		NNupnIw4g9ByUtHSJOeL,M8qodsbQklm3hR1tiOa0jYUIX29ev,wUpHn5IfzaQ8g4j = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
		eZhipVABmx3HqsM9F = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		COutq01MLJ65nPd7fNgGoE = [Zg9FeADE84jSRIvPCrzYulw3sL,'&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		usM4AonktOcXFwedJyZ0B1lP2 = WXZLgSfpV2jzRFTNiyroc('موقع يوتيوب - اختر الترتيب',eZhipVABmx3HqsM9F)
		if usM4AonktOcXFwedJyZ0B1lP2 == -1: return
		D2dMz7KX9hUpHsg0Txvuen = COutq01MLJ65nPd7fNgGoE[usM4AonktOcXFwedJyZ0B1lP2]
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,f4hGlHiK3uMxwUg62o9J,data = Zy7Ic8LBx6V(hc5ePKxl4LJvEjDgTm+D2dMz7KX9hUpHsg0Txvuen)
		if f4hGlHiK3uMxwUg62o9J:
			SQkWUPdDbyaYs532uX = f4hGlHiK3uMxwUg62o9J['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for WrqsI7kQ3GZiTzFBd2HKL in range(len(SQkWUPdDbyaYs532uX)):
				group = SQkWUPdDbyaYs532uX[WrqsI7kQ3GZiTzFBd2HKL]['searchFilterGroupRenderer']['filters']
				for ilQ9oXS1jTFVU28 in range(len(group)):
					AAYwlR5v3MobImasCj1L4kpgScVK = group[ilQ9oXS1jTFVU28]['searchFilterRenderer']
					if 'navigationEndpoint' in list(AAYwlR5v3MobImasCj1L4kpgScVK.keys()):
						yDTPzhEBKVJl7CX81 = AAYwlR5v3MobImasCj1L4kpgScVK['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\u0026','&')
						title = AAYwlR5v3MobImasCj1L4kpgScVK['tooltip']
						title = title.replace('البحث عن ',Zg9FeADE84jSRIvPCrzYulw3sL)
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							wUpHn5IfzaQ8g4j = title
							WOry7DZPocFhH8p4 = yDTPzhEBKVJl7CX81
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ',Zg9FeADE84jSRIvPCrzYulw3sL)
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							wUpHn5IfzaQ8g4j = title
							WOry7DZPocFhH8p4 = yDTPzhEBKVJl7CX81
						if 'Sort by' in title: continue
						NNupnIw4g9ByUtHSJOeL.append(uumhMi6O4pk7Gjd5aTQqy2Z(title))
						M8qodsbQklm3hR1tiOa0jYUIX29ev.append(yDTPzhEBKVJl7CX81)
		if not wUpHn5IfzaQ8g4j: Ny32JuHp8SzGUjeR9WidLaEBlYhVZ = Zg9FeADE84jSRIvPCrzYulw3sL
		else:
			NNupnIw4g9ByUtHSJOeL = ['بدون فلتر',wUpHn5IfzaQ8g4j]+NNupnIw4g9ByUtHSJOeL
			M8qodsbQklm3hR1tiOa0jYUIX29ev = [Zg9FeADE84jSRIvPCrzYulw3sL,WOry7DZPocFhH8p4]+M8qodsbQklm3hR1tiOa0jYUIX29ev
			xyFTQnSOXljMp97W4RYG8t0bzreAmL = WXZLgSfpV2jzRFTNiyroc('موقع يوتيوب - اختر الفلتر',NNupnIw4g9ByUtHSJOeL)
			if xyFTQnSOXljMp97W4RYG8t0bzreAmL == -1: return
			Ny32JuHp8SzGUjeR9WidLaEBlYhVZ = M8qodsbQklm3hR1tiOa0jYUIX29ev[xyFTQnSOXljMp97W4RYG8t0bzreAmL]
		if Ny32JuHp8SzGUjeR9WidLaEBlYhVZ: JaqiYfEglZDvmwQNS8zR = qfzHe2Yr49+Ny32JuHp8SzGUjeR9WidLaEBlYhVZ
		elif D2dMz7KX9hUpHsg0Txvuen: JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+D2dMz7KX9hUpHsg0Txvuen
		else: JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm
	yfWYTB58bDO(JaqiYfEglZDvmwQNS8zR)
	return
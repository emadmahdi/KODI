# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'CIMALIGHT'
j0jSEdTPJuG4XNvfpO = '_CML_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['قنوات فضائية']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==470: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==471: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==472: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==473: CsaNhTtGm8 = DhjI5w2TgXo(url,text)
	elif mode==474: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==479: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"url": "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Wtu1ZQ5yrA2KVlPs76EgbRvz = Wtu1ZQ5yrA2KVlPs76EgbRvz[0].strip('/')
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(Wtu1ZQ5yrA2KVlPs76EgbRvz,'url')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,479,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"content"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?</i>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		title = title.replace(F4skx1A3wOEh9lmPuZMnpCzR,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('cat=online-movies1','cat=online-movies')
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,474)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('/category.php">(.*?)"navslide-divider"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("'dropdown-menu'(.*?)</ul>",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,474)
	return
def hkO9B6NystZxC1VDvWe(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if 'topvideos.php' in url: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"caret"(.*?)id="pm-grid"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"caret"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if 'topvideos.php' in yDTPzhEBKVJl7CX81:
				if 'topvideos.php?c=english-movies' in yDTPzhEBKVJl7CX81: continue
				if 'topvideos.php?c=online-movies1' in yDTPzhEBKVJl7CX81: continue
				if 'topvideos.php?c=misc' in yDTPzhEBKVJl7CX81: continue
				if 'topvideos.php?c=tv-channel' in yDTPzhEBKVJl7CX81: continue
				if 'منذ البداية' in title and 'do=rating' not in yDTPzhEBKVJl7CX81: continue
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,471)
	else: mbzIyKNqMVt0FQeOsPWc(url)
	return
def mbzIyKNqMVt0FQeOsPWc(url,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	items = []
	if YYAz8aPFGR2n=='featured_movies':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"container-fluid"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		CPv45ibdnBc,WWuctLSlqizGgrK,XemJb32uvAqRkxoVBH5I = zip(*items)
		items = zip(XemJb32uvAqRkxoVBH5I,CPv45ibdnBc,WWuctLSlqizGgrK)
	elif YYAz8aPFGR2n=='featured_series':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('المسلسلات المميزة(.*?)<style>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		CPv45ibdnBc,WWuctLSlqizGgrK,XemJb32uvAqRkxoVBH5I = zip(*items)
		items = zip(XemJb32uvAqRkxoVBH5I,CPv45ibdnBc,WWuctLSlqizGgrK)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(data-echo=".*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"BlocksList"(.*?)"titleSectionCon"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="pm-grid"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="pm-related"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pm-ul-browse-videos(.*?)clearfix',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: return
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81).strip('/')
		title = title.replace('ماي سيما',Zg9FeADE84jSRIvPCrzYulw3sL).replace('مشاهدة',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
		if 'http' not in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+W8KBRzkdhlCxvF5sY2T.strip('/')
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة) \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			title = '_MOD_'+title
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,472,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'حلقة' in title:
			title = '_MOD_'+jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,473,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/movseries/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,471,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,473,W8KBRzkdhlCxvF5sY2T)
	if YYAz8aPFGR2n not in ['featured_movies','featured_series']:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81=='#': continue
				yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
				title = BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,471)
		g63NE7IqjuxsXknTw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('showmore" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if g63NE7IqjuxsXknTw:
			yDTPzhEBKVJl7CX81 = g63NE7IqjuxsXknTw[0]
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مشاهدة المزيد',yDTPzhEBKVJl7CX81,471)
	return
def DhjI5w2TgXo(url,fAzmnhNw7ToKEV6u4e5HUj):
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-EPISODES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"SeasonsBox"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = []
	if vXCcUPg6OoWFdYSr and not fAzmnhNw7ToKEV6u4e5HUj:
		W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"series-header".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0] if W8KBRzkdhlCxvF5sY2T else Zg9FeADE84jSRIvPCrzYulw3sL
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(items)==1: fAzmnhNw7ToKEV6u4e5HUj = items[0][0]
		elif len(items)>1:
			for fAzmnhNw7ToKEV6u4e5HUj,title in items: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,473,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,fAzmnhNw7ToKEV6u4e5HUj)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="'+fAzmnhNw7ToKEV6u4e5HUj+'"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9 and len(items)<2:
		W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"series-header".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0] if W8KBRzkdhlCxvF5sY2T else Zg9FeADE84jSRIvPCrzYulw3sL
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,title in items:
				title = title.replace('ماي سيما',Zg9FeADE84jSRIvPCrzYulw3sL).replace('مسلسل',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,472,W8KBRzkdhlCxvF5sY2T)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,472,W8KBRzkdhlCxvF5sY2T)
	if 'id="pm-related"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		if items: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مواضيع ذات صلة',url,471)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<div itemprop="description">(.*?)href=',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<p>(.*?)</p>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50,True): return
	hc5ePKxl4LJvEjDgTm = url.replace('/watch.php','/play.php')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-PLAY-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HgfBs1b5k4LzTFNZ = []
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"embedURL" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
		if yDTPzhEBKVJl7CX81 and yDTPzhEBKVJl7CX81 not in HgfBs1b5k4LzTFNZ:
			HgfBs1b5k4LzTFNZ.append(yDTPzhEBKVJl7CX81)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named=__embed'
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if yDTPzhEBKVJl7CX81 not in HgfBs1b5k4LzTFNZ:
			HgfBs1b5k4LzTFNZ.append(yDTPzhEBKVJl7CX81)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	hc5ePKxl4LJvEjDgTm = url.replace('/watch.php','/downloads.php')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMALIGHT-PLAY-3rd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"downloadlist"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<strong>(.*?)</strong>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if yDTPzhEBKVJl7CX81 not in HgfBs1b5k4LzTFNZ:
				HgfBs1b5k4LzTFNZ.append(yDTPzhEBKVJl7CX81)
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(qfzHe2Yr49,'url')
	url = m0t48jnKhrQFJViguoMl9NBPp+'/search.php?keywords='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
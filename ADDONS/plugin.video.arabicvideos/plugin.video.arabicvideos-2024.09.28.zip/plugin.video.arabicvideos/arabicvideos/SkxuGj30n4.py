# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'SHOFHA'
j0jSEdTPJuG4XNvfpO = '_SHT_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==640: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==641: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==642: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==644: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==645: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==649: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,649,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',qfzHe2Yr49,641,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'جديد الموقع',qfzHe2Yr49+'/newvideos.php',641,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"navslide-divider"></div>(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,644)
	return
def hkO9B6NystZxC1VDvWe(url):
	EmOvl4MXRJDCjyd1igQWtPLF9NK8 = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"caret"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('"presentation"','</ul>')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = [(Zg9FeADE84jSRIvPCrzYulw3sL,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)]
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' فرز أو فلتر أو ترتيب '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		for K8L06TpijdQJUhz5co,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
			EmOvl4MXRJDCjyd1igQWtPLF9NK8 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if K8L06TpijdQJUhz5co: K8L06TpijdQJUhz5co = K8L06TpijdQJUhz5co+': '
			for yDTPzhEBKVJl7CX81,title in EmOvl4MXRJDCjyd1igQWtPLF9NK8:
				title = K8L06TpijdQJUhz5co+title
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,641)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-category-subcats"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(QaVoNlxzSUORpb)<30:
			if EmOvl4MXRJDCjyd1igQWtPLF9NK8: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,641)
	if not vXCcUPg6OoWFdYSr and not sQPyfIOFgKLTU4u23XB6dmS9: mbzIyKNqMVt0FQeOsPWc(url)
	return
def mbzIyKNqMVt0FQeOsPWc(url,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	if YYAz8aPFGR2n=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-TITLES-1st')
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-TITLES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,items = Zg9FeADE84jSRIvPCrzYulw3sL,[]
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	if YYAz8aPFGR2n=='ajax-search':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((Zg9FeADE84jSRIvPCrzYulw3sL,yDTPzhEBKVJl7CX81,title))
	elif YYAz8aPFGR2n=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-video-watch-featured"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_episodes':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_movies':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(HNRenB3EZX62qgSKMd4f)>1: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[1]
	elif YYAz8aPFGR2n=='featured_series':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((Zg9FeADE84jSRIvPCrzYulw3sL,yDTPzhEBKVJl7CX81,title))
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(data-echo=".*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA and not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items: return
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,642,W8KBRzkdhlCxvF5sY2T)
		elif YYAz8aPFGR2n=='new_episodes':
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,642,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,645,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,645,W8KBRzkdhlCxvF5sY2T)
	if 1:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81=='#': continue
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
				title = BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,641)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	EELGungxe6wKPar9hyRv5FUMpIB = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"og:image" content="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if EELGungxe6wKPar9hyRv5FUMpIB: W8KBRzkdhlCxvF5sY2T = EELGungxe6wKPar9hyRv5FUMpIB[0]
	else: W8KBRzkdhlCxvF5sY2T = Zg9FeADE84jSRIvPCrzYulw3sL
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('episodeNumber.*?</div>(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="eplist"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?><span>(.*?)</em>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = title.replace('</span><em>',wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,642,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB,Z2fh9I3eLMO,ZZH6czYDb0 = [],[],[]
	if '/watch.php' in url: hc5ePKxl4LJvEjDgTm = url.replace('/watch.php','/view.php')
	else: hc5ePKxl4LJvEjDgTm = url
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHOFHA-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if 'embedded-video' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"embedded-video"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if CPv45ibdnBc:
				yDTPzhEBKVJl7CX81 = CPv45ibdnBc[0]
				if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
					Z2fh9I3eLMO.append('?named=__embed')
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if 'WatchServers' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"WatchServers"(.*?)</script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			ZI27xz6yocas4bWlLgmtpAq3R = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="(.*?)".*?</span>(.*?)</button>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('\\"','"').replace('\/','/')
			CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"<iframe.src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if len(ZI27xz6yocas4bWlLgmtpAq3R)==len(CPv45ibdnBc):
				for id,title in ZI27xz6yocas4bWlLgmtpAq3R:
					yDTPzhEBKVJl7CX81 = CPv45ibdnBc[int(id)]
					if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
						Z2fh9I3eLMO.append('?named='+title+'__watch')
						fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if 'DownloadServer' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"DownloadServer"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?</i>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not CPv45ibdnBc: CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
			for yDTPzhEBKVJl7CX81,title in CPv45ibdnBc:
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+yDTPzhEBKVJl7CX81
				if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
					Z2fh9I3eLMO.append('?named='+title+'__download')
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	F5nZmIVxBz3 = zip(fo6s53yEnbklLpaJOzgR4Q01wxB,Z2fh9I3eLMO)
	for yDTPzhEBKVJl7CX81,name in F5nZmIVxBz3: ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+name)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/search.php?keywords='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
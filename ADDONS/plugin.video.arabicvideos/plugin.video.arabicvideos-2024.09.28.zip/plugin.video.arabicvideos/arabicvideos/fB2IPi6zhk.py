# -*- coding: utf-8 -*-
from V1VREBsj92 import *
d1AeaJNg4IXzTv6ER0nicLUrf = 'EXCLUDES'
def ccfAK8Q45OJoBGXEuHZUWV9NPbC(VaOH2318eP5yQWXrkcx,T3wqrjSzoPXxl):
	T3wqrjSzoPXxl = T3wqrjSzoPXxl.replace(PPQORjT2lc7SVkKwFI4D,Zg9FeADE84jSRIvPCrzYulw3sL).replace(' '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)[1:]
	Bufinlad906sGRHeVFEq1XbcUN = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('[a-zA-Z]',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if 'بحث IPTV - ' in VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('بحث IPTV - ',FEftnphOJQY9dWI5iCoMj43zKbA+'بحث IPTV - '+FEftnphOJQY9dWI5iCoMj43zKbA)
	elif ' IPTV' in VaOH2318eP5yQWXrkcx and T3wqrjSzoPXxl=='IPT': VaOH2318eP5yQWXrkcx = FEftnphOJQY9dWI5iCoMj43zKbA+VaOH2318eP5yQWXrkcx
	elif 'بحث M3U - ' in VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('بحث M3U - ',FEftnphOJQY9dWI5iCoMj43zKbA+'بحث M3U - '+FEftnphOJQY9dWI5iCoMj43zKbA)
	elif ' M3U' in VaOH2318eP5yQWXrkcx and T3wqrjSzoPXxl=='M3U': VaOH2318eP5yQWXrkcx = FEftnphOJQY9dWI5iCoMj43zKbA+VaOH2318eP5yQWXrkcx
	elif 'بحث ' in VaOH2318eP5yQWXrkcx and ' - ' in VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = FEftnphOJQY9dWI5iCoMj43zKbA+VaOH2318eP5yQWXrkcx
	elif not Bufinlad906sGRHeVFEq1XbcUN:
		XxmqjLaHR9g = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^( *?)(.*?)( *?)$',VaOH2318eP5yQWXrkcx)
		HkpIV58d0qPjlZrYAE1Ny7Q2U,PPQ5XnM732mdCyi8sN0GRYopK,rgAzL3ncby = XxmqjLaHR9g[0]
		eKDhNdyFgBP5jzAsoJ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^([!-~])',PPQ5XnM732mdCyi8sN0GRYopK)
		if eKDhNdyFgBP5jzAsoJ: VaOH2318eP5yQWXrkcx = HkpIV58d0qPjlZrYAE1Ny7Q2U+MVtOGEXYcJLSjm4+PPQ5XnM732mdCyi8sN0GRYopK+rgAzL3ncby
		else: VaOH2318eP5yQWXrkcx = rgAzL3ncby+FEftnphOJQY9dWI5iCoMj43zKbA+PPQ5XnM732mdCyi8sN0GRYopK+HkpIV58d0qPjlZrYAE1Ny7Q2U
	else:
		import bidi.algorithm as R75ODtZqmK3kox
		if 1:
			vhbCQFoUGm = VaOH2318eP5yQWXrkcx
			ETo0Jg9jamMrHtcUyWxDOLqw = R75ODtZqmK3kox.get_display(VaOH2318eP5yQWXrkcx,base_dir='L')
			if HByjTem6EJP5sZb: vhbCQFoUGm = vhbCQFoUGm.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			if HByjTem6EJP5sZb: ETo0Jg9jamMrHtcUyWxDOLqw = ETo0Jg9jamMrHtcUyWxDOLqw.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			kVMgmzRUvAKlH6XTuycwNx = vhbCQFoUGm.split(wjs26GpVfNiCUERHJ)
			X3V1S6skCroQ = ETo0Jg9jamMrHtcUyWxDOLqw.split(wjs26GpVfNiCUERHJ)
			IpeHy1F6zRYTlZS8idj,aFkAZbU6RQ7nqJ9VtYe,EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0,DNvWwa1Ju8zUs = [],[],Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
			pqkBwDzELFRs5STAf4vVU6Ool = zip(kVMgmzRUvAKlH6XTuycwNx,X3V1S6skCroQ)
			for xxmeal7YvOjqwWTcyZL,GGV42vxkuY63IeJFsy0AcfMXNhjH in pqkBwDzELFRs5STAf4vVU6Ool:
				if xxmeal7YvOjqwWTcyZL==GGV42vxkuY63IeJFsy0AcfMXNhjH==Zg9FeADE84jSRIvPCrzYulw3sL and DNvWwa1Ju8zUs:
					EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0 += wjs26GpVfNiCUERHJ
					continue
				if xxmeal7YvOjqwWTcyZL==GGV42vxkuY63IeJFsy0AcfMXNhjH:
					S5ymYo7uUW0f4BqDehZak2POTHX = 'EN'
					if DNvWwa1Ju8zUs==S5ymYo7uUW0f4BqDehZak2POTHX: EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0 += wjs26GpVfNiCUERHJ+xxmeal7YvOjqwWTcyZL
					elif xxmeal7YvOjqwWTcyZL:
						if EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0:
							aFkAZbU6RQ7nqJ9VtYe.append(EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0)
							IpeHy1F6zRYTlZS8idj.append(Zg9FeADE84jSRIvPCrzYulw3sL)
						EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0 = xxmeal7YvOjqwWTcyZL
				else:
					S5ymYo7uUW0f4BqDehZak2POTHX = 'AR'
					if DNvWwa1Ju8zUs==S5ymYo7uUW0f4BqDehZak2POTHX: EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0 += wjs26GpVfNiCUERHJ+xxmeal7YvOjqwWTcyZL
					elif xxmeal7YvOjqwWTcyZL:
						if EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0:
							IpeHy1F6zRYTlZS8idj.append(EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0)
							aFkAZbU6RQ7nqJ9VtYe.append(Zg9FeADE84jSRIvPCrzYulw3sL)
						EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0 = xxmeal7YvOjqwWTcyZL
				DNvWwa1Ju8zUs = S5ymYo7uUW0f4BqDehZak2POTHX
			if S5ymYo7uUW0f4BqDehZak2POTHX=='EN':
				IpeHy1F6zRYTlZS8idj.append(EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0)
				aFkAZbU6RQ7nqJ9VtYe.append(Zg9FeADE84jSRIvPCrzYulw3sL)
			else:
				aFkAZbU6RQ7nqJ9VtYe.append(EGQ3MNOP2a6TAnuBlhiFsqW8y5mf0)
				IpeHy1F6zRYTlZS8idj.append(Zg9FeADE84jSRIvPCrzYulw3sL)
			KjcC2gYhQU = Zg9FeADE84jSRIvPCrzYulw3sL
			pqkBwDzELFRs5STAf4vVU6Ool = zip(IpeHy1F6zRYTlZS8idj,aFkAZbU6RQ7nqJ9VtYe)
			import bidi.mirror as FEb6ahyAn1
			for IzXPjnyswG3cNULV,vzTwYOkhUeDKI5R7Pl3ZaJ in pqkBwDzELFRs5STAf4vVU6Ool:
				if IzXPjnyswG3cNULV: KjcC2gYhQU += wjs26GpVfNiCUERHJ+IzXPjnyswG3cNULV
				else:
					eKDhNdyFgBP5jzAsoJ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('([!-~]) *$',vzTwYOkhUeDKI5R7Pl3ZaJ)
					if eKDhNdyFgBP5jzAsoJ:
						eKDhNdyFgBP5jzAsoJ = eKDhNdyFgBP5jzAsoJ[0]
						try:
							l1xAyHhc0sMYLmpC895az = FEb6ahyAn1.MIRRORED[eKDhNdyFgBP5jzAsoJ]
							XxmqjLaHR9g = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^( *?)(.*?)( *?)$',vzTwYOkhUeDKI5R7Pl3ZaJ)
							if XxmqjLaHR9g: HkpIV58d0qPjlZrYAE1Ny7Q2U,vzTwYOkhUeDKI5R7Pl3ZaJ,rgAzL3ncby = XxmqjLaHR9g[0]
							vzTwYOkhUeDKI5R7Pl3ZaJ = HkpIV58d0qPjlZrYAE1Ny7Q2U+l1xAyHhc0sMYLmpC895az+vzTwYOkhUeDKI5R7Pl3ZaJ[:-1]+rgAzL3ncby
						except: pass
					KjcC2gYhQU += wjs26GpVfNiCUERHJ+vzTwYOkhUeDKI5R7Pl3ZaJ
			VaOH2318eP5yQWXrkcx = KjcC2gYhQU[1:]
			if HByjTem6EJP5sZb: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		else:
			if HByjTem6EJP5sZb: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			VaOH2318eP5yQWXrkcx = R75ODtZqmK3kox.get_display(VaOH2318eP5yQWXrkcx)
			vhbCQFoUGm,ETo0Jg9jamMrHtcUyWxDOLqw = VaOH2318eP5yQWXrkcx,VaOH2318eP5yQWXrkcx
			if 1:
				DNvWwa1Ju8zUs,dlw784n0g92eS = Zg9FeADE84jSRIvPCrzYulw3sL,[]
				EANeG6bc2i9Kx = VaOH2318eP5yQWXrkcx.split(wjs26GpVfNiCUERHJ)
				for KWNpHe6lrMP937Tn4qBvL8 in EANeG6bc2i9Kx:
					if not KWNpHe6lrMP937Tn4qBvL8:
						if dlw784n0g92eS: dlw784n0g92eS[-1] += wjs26GpVfNiCUERHJ
						else: dlw784n0g92eS.append(Zg9FeADE84jSRIvPCrzYulw3sL)
						continue
					M0qTPx4GFVY7Krd2BC9mE = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('[!-~]',KWNpHe6lrMP937Tn4qBvL8[0])
					if M0qTPx4GFVY7Krd2BC9mE==DNvWwa1Ju8zUs and dlw784n0g92eS: dlw784n0g92eS[-1] += wjs26GpVfNiCUERHJ+KWNpHe6lrMP937Tn4qBvL8
					else:
						if dlw784n0g92eS:
							fCpONLyeBqWu1j3zkX = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('[^!-~]',dlw784n0g92eS[-1])
							if fCpONLyeBqWu1j3zkX:
								dlw784n0g92eS[-1] = R75ODtZqmK3kox.get_display(dlw784n0g92eS[-1])
								Im3oO4cYVwBD6kUCLjvSrN = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^ +',dlw784n0g92eS[-1])
								if Im3oO4cYVwBD6kUCLjvSrN: dlw784n0g92eS[-1] = dlw784n0g92eS[-1].lstrip(wjs26GpVfNiCUERHJ)+Im3oO4cYVwBD6kUCLjvSrN[0]
						dlw784n0g92eS.append(KWNpHe6lrMP937Tn4qBvL8)
					DNvWwa1Ju8zUs = M0qTPx4GFVY7Krd2BC9mE
				if dlw784n0g92eS: dlw784n0g92eS[-1] = R75ODtZqmK3kox.get_display(dlw784n0g92eS[-1])
				VaOH2318eP5yQWXrkcx = wjs26GpVfNiCUERHJ.join(dlw784n0g92eS)
			if HByjTem6EJP5sZb: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	return VaOH2318eP5yQWXrkcx
def WWvFT8MZ1QthpRrXz(Vo8UMGRpWnI,XXDtFJpiyN75nS,yzoZg2teG7bL3P):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Qc2dAT3X9nH5LCtBY,XXylIHqrKhZAMwFf,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = Vo8UMGRpWnI
	LfnWDFgRdJH4lZvt7yo28N = int(LfnWDFgRdJH4lZvt7yo28N)
	W8TyOS9bZsU = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if W8TyOS9bZsU:
		W8TyOS9bZsU,d3tw6K1Pn7WsjC,UPrms5Zfk47SIlEgxjvKNXwz = W8TyOS9bZsU[0]
		VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(W8TyOS9bZsU,Zg9FeADE84jSRIvPCrzYulw3sL)
	O9KyAatziEp7kJ0qS8vQFDe6wY = VaOH2318eP5yQWXrkcx
	T3wqrjSzoPXxl = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^_(\w\w\w)_(.*?)$',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if T3wqrjSzoPXxl:
		T3wqrjSzoPXxl,VaOH2318eP5yQWXrkcx = T3wqrjSzoPXxl[0]
		ey6txWA45gISEG = '_MOD_' in VaOH2318eP5yQWXrkcx
		g5gJiUkIKOqRBj = RR5KdNtJEBT=='folder'
		if ey6txWA45gISEG and g5gJiUkIKOqRBj: JJiHyeSP5NpC2wWzgE4IQr = ';'
		elif ey6txWA45gISEG and not g5gJiUkIKOqRBj: JJiHyeSP5NpC2wWzgE4IQr = n7eguYlER0J5
		elif not ey6txWA45gISEG and g5gJiUkIKOqRBj: JJiHyeSP5NpC2wWzgE4IQr = ','
		elif not ey6txWA45gISEG and not g5gJiUkIKOqRBj: JJiHyeSP5NpC2wWzgE4IQr = wjs26GpVfNiCUERHJ
		VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('_MOD_',Zg9FeADE84jSRIvPCrzYulw3sL)
		T3wqrjSzoPXxl = JJiHyeSP5NpC2wWzgE4IQr+PPQORjT2lc7SVkKwFI4D+T3wqrjSzoPXxl+' '+u4IRSmrYMKkaHUBnDiLWh
	else: T3wqrjSzoPXxl = Zg9FeADE84jSRIvPCrzYulw3sL
	if W8TyOS9bZsU:
		if HByjTem6EJP5sZb:
			W8TyOS9bZsU = U2bWzwG8VdJsBqtR74ErDi3cg1v+d3tw6K1Pn7WsjC+wjs26GpVfNiCUERHJ+UPrms5Zfk47SIlEgxjvKNXwz+u4IRSmrYMKkaHUBnDiLWh
			if T3wqrjSzoPXxl: VaOH2318eP5yQWXrkcx = W8TyOS9bZsU+wjs26GpVfNiCUERHJ+FEftnphOJQY9dWI5iCoMj43zKbA+T3wqrjSzoPXxl+VaOH2318eP5yQWXrkcx
			else: VaOH2318eP5yQWXrkcx = W8TyOS9bZsU+FEftnphOJQY9dWI5iCoMj43zKbA+VaOH2318eP5yQWXrkcx+wjs26GpVfNiCUERHJ
		elif GGfPQnrJKEqMv2ZVxdD:
			if T3wqrjSzoPXxl:
				W8TyOS9bZsU = U2bWzwG8VdJsBqtR74ErDi3cg1v+d3tw6K1Pn7WsjC+wjs26GpVfNiCUERHJ+UPrms5Zfk47SIlEgxjvKNXwz+u4IRSmrYMKkaHUBnDiLWh
				VaOH2318eP5yQWXrkcx = W8TyOS9bZsU+wjs26GpVfNiCUERHJ+T3wqrjSzoPXxl+VaOH2318eP5yQWXrkcx
			else:
				W8TyOS9bZsU = U2bWzwG8VdJsBqtR74ErDi3cg1v+UPrms5Zfk47SIlEgxjvKNXwz+wjs26GpVfNiCUERHJ+d3tw6K1Pn7WsjC+u4IRSmrYMKkaHUBnDiLWh
				VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx+wjs26GpVfNiCUERHJ+FEftnphOJQY9dWI5iCoMj43zKbA+W8TyOS9bZsU
	elif T3wqrjSzoPXxl:
		VaOH2318eP5yQWXrkcx = ccfAK8Q45OJoBGXEuHZUWV9NPbC(VaOH2318eP5yQWXrkcx,T3wqrjSzoPXxl)
		VaOH2318eP5yQWXrkcx = T3wqrjSzoPXxl+VaOH2318eP5yQWXrkcx
	Vo8UMGRpWnI = RR5KdNtJEBT,O9KyAatziEp7kJ0qS8vQFDe6wY,tUHrEcLYK30N,str(LfnWDFgRdJH4lZvt7yo28N),feRw3p6MLob90H4J,Qc2dAT3X9nH5LCtBY,XXylIHqrKhZAMwFf,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN
	NSisPv2ybeJgtuVU1Kr = {'type':Zg9FeADE84jSRIvPCrzYulw3sL,'mode':Zg9FeADE84jSRIvPCrzYulw3sL,'url':Zg9FeADE84jSRIvPCrzYulw3sL,'text':Zg9FeADE84jSRIvPCrzYulw3sL,'page':Zg9FeADE84jSRIvPCrzYulw3sL,'name':Zg9FeADE84jSRIvPCrzYulw3sL,'image':Zg9FeADE84jSRIvPCrzYulw3sL,'context':Zg9FeADE84jSRIvPCrzYulw3sL,'infodict':Zg9FeADE84jSRIvPCrzYulw3sL}
	NSisPv2ybeJgtuVU1Kr['name'] = OJYiDeyvSPTNI9(O9KyAatziEp7kJ0qS8vQFDe6wY)
	NSisPv2ybeJgtuVU1Kr['type'] = RR5KdNtJEBT.strip(wjs26GpVfNiCUERHJ)
	NSisPv2ybeJgtuVU1Kr['mode'] = str(LfnWDFgRdJH4lZvt7yo28N).strip(wjs26GpVfNiCUERHJ)
	if RR5KdNtJEBT=='folder' and Qc2dAT3X9nH5LCtBY: NSisPv2ybeJgtuVU1Kr['page'] = OJYiDeyvSPTNI9(Qc2dAT3X9nH5LCtBY.strip(wjs26GpVfNiCUERHJ))
	if NSWD3RyE8gmLnhApqVTCM: NSisPv2ybeJgtuVU1Kr['context'] = NSWD3RyE8gmLnhApqVTCM.strip(wjs26GpVfNiCUERHJ)
	if XXylIHqrKhZAMwFf: NSisPv2ybeJgtuVU1Kr['text'] = OJYiDeyvSPTNI9(XXylIHqrKhZAMwFf.strip(wjs26GpVfNiCUERHJ))
	if feRw3p6MLob90H4J: NSisPv2ybeJgtuVU1Kr['image'] = OJYiDeyvSPTNI9(feRw3p6MLob90H4J.strip(wjs26GpVfNiCUERHJ))
	if puVFor385ci9gvjUDnflEXqmJ7wPN:
		puVFor385ci9gvjUDnflEXqmJ7wPN = str(puVFor385ci9gvjUDnflEXqmJ7wPN)
		NSisPv2ybeJgtuVU1Kr['infodict'] = OJYiDeyvSPTNI9(puVFor385ci9gvjUDnflEXqmJ7wPN.strip(wjs26GpVfNiCUERHJ))
		puVFor385ci9gvjUDnflEXqmJ7wPN = eval(puVFor385ci9gvjUDnflEXqmJ7wPN)
	else: puVFor385ci9gvjUDnflEXqmJ7wPN = {}
	if tUHrEcLYK30N: NSisPv2ybeJgtuVU1Kr['url'] = OJYiDeyvSPTNI9(tUHrEcLYK30N.strip(wjs26GpVfNiCUERHJ))
	VcZ2edUaXFqwkOmYtJx5 = {'name':Zg9FeADE84jSRIvPCrzYulw3sL,'context_menu':Zg9FeADE84jSRIvPCrzYulw3sL,'plot':Zg9FeADE84jSRIvPCrzYulw3sL,'stars':Zg9FeADE84jSRIvPCrzYulw3sL,'image':Zg9FeADE84jSRIvPCrzYulw3sL,'type':Zg9FeADE84jSRIvPCrzYulw3sL,'isFolder':Zg9FeADE84jSRIvPCrzYulw3sL,'newpath':Zg9FeADE84jSRIvPCrzYulw3sL,'duration':Zg9FeADE84jSRIvPCrzYulw3sL}
	cgrXUpOKsv95SNCoJhlEfF = []
	mbQ3DMW9vxjBTtAI = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'/?type='+NSisPv2ybeJgtuVU1Kr['type']+'&mode='+NSisPv2ybeJgtuVU1Kr['mode']
	if NSisPv2ybeJgtuVU1Kr['page']: mbQ3DMW9vxjBTtAI += '&page='+NSisPv2ybeJgtuVU1Kr['page']
	if NSisPv2ybeJgtuVU1Kr['name']: mbQ3DMW9vxjBTtAI += '&name='+NSisPv2ybeJgtuVU1Kr['name']
	if NSisPv2ybeJgtuVU1Kr['text']: mbQ3DMW9vxjBTtAI += '&text='+NSisPv2ybeJgtuVU1Kr['text']
	if NSisPv2ybeJgtuVU1Kr['infodict']: mbQ3DMW9vxjBTtAI += '&infodict='+NSisPv2ybeJgtuVU1Kr['infodict']
	if NSisPv2ybeJgtuVU1Kr['image']: mbQ3DMW9vxjBTtAI += '&image='+NSisPv2ybeJgtuVU1Kr['image']
	if NSisPv2ybeJgtuVU1Kr['url']: mbQ3DMW9vxjBTtAI += '&url='+NSisPv2ybeJgtuVU1Kr['url']
	if LfnWDFgRdJH4lZvt7yo28N!=265: VcZ2edUaXFqwkOmYtJx5['favorites'] = True
	else: VcZ2edUaXFqwkOmYtJx5['favorites'] = False
	if NSisPv2ybeJgtuVU1Kr['context']: mbQ3DMW9vxjBTtAI += '&context='+NSisPv2ybeJgtuVU1Kr['context']
	if LfnWDFgRdJH4lZvt7yo28N in [235,238] and RR5KdNtJEBT=='live' and 'EPG' in NSWD3RyE8gmLnhApqVTCM:
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?mode=238&text=SHORT_EPG&url='+tUHrEcLYK30N
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'البرامج القادمة'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if LfnWDFgRdJH4lZvt7yo28N==265:
		mDNbhUof6PjiMSgR2eY1A90pw = XXDtFJpiyN75nS(XXylIHqrKhZAMwFf,True)
		if mDNbhUof6PjiMSgR2eY1A90pw>0:
			WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?mode=266&text='+XXylIHqrKhZAMwFf
			yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'مسح قائمة آخر 50 '+ulj9JfWhc0EgZbsm(XXylIHqrKhZAMwFf)+u4IRSmrYMKkaHUBnDiLWh
			SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
			cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if RR5KdNtJEBT=='video' and LfnWDFgRdJH4lZvt7yo28N!=331:
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=6_DOWNLOAD'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'تحميل ملف الفيديو'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if LfnWDFgRdJH4lZvt7yo28N==331:
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=6_DELETE'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'حذف ملف الفيديو'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if RR5KdNtJEBT=='folder' and LfnWDFgRdJH4lZvt7yo28N==540:
		VWZtev9FCEqm = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_SPLITTED_ALL')
		if VWZtev9FCEqm:
			WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?context=7'
			yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'مسح كلمات بحث المواقع'+u4IRSmrYMKkaHUBnDiLWh
			SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
			cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if RR5KdNtJEBT=='folder' and LfnWDFgRdJH4lZvt7yo28N==1010:
		VWZtev9FCEqm = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if VWZtev9FCEqm:
			WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?context=10'
			yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'مسح كلمات بحث جوجل'+u4IRSmrYMKkaHUBnDiLWh
			SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
			cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	zzsTDXOpaRhyQK7IJZ3CvB = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010]
	if LfnWDFgRdJH4lZvt7yo28N not in zzsTDXOpaRhyQK7IJZ3CvB:
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?context=8&mode=260'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'القائمة الرئيسية'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	lILyfgK7RTdpYczPMiE4x = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	Lb7uGYvIDk0Rst1C52aylf = LfnWDFgRdJH4lZvt7yo28N-LfnWDFgRdJH4lZvt7yo28N%10
	if LfnWDFgRdJH4lZvt7yo28N%10:
		if Lb7uGYvIDk0Rst1C52aylf==280: Lb7uGYvIDk0Rst1C52aylf = 230
		if Lb7uGYvIDk0Rst1C52aylf==410: Lb7uGYvIDk0Rst1C52aylf = 400
		if Lb7uGYvIDk0Rst1C52aylf==520: Lb7uGYvIDk0Rst1C52aylf = 510
		if Lb7uGYvIDk0Rst1C52aylf not in lILyfgK7RTdpYczPMiE4x:
			WJ591Xm7lGAY0x3FbBChetdMrRqSVv = 'plugin://'+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+'?context=8&mode='+str(Lb7uGYvIDk0Rst1C52aylf)
			yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'قائمة الموقع'+u4IRSmrYMKkaHUBnDiLWh
			SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
			cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=9'
	yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'تحديث القائمة (ترتيب أصلي)'+u4IRSmrYMKkaHUBnDiLWh
	SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
	cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if LfnWDFgRdJH4lZvt7yo28N%10 and Lb7uGYvIDk0Rst1C52aylf not in lILyfgK7RTdpYczPMiE4x:
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=14'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'ترتيب عكسي مؤقت'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=15'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'ترتيب تصاعدي مؤقت'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=16'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'ترتيب تنازلي مؤقت'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
		WJ591Xm7lGAY0x3FbBChetdMrRqSVv = mbQ3DMW9vxjBTtAI+'&context=17'
		yrpS0B9I1D = U2bWzwG8VdJsBqtR74ErDi3cg1v+'ترتيب عشوائي مؤقت'+u4IRSmrYMKkaHUBnDiLWh
		SJl3G6mcpO4ELCUX5jk8wr2x = (yrpS0B9I1D,'RunPlugin('+WJ591Xm7lGAY0x3FbBChetdMrRqSVv+')')
		cgrXUpOKsv95SNCoJhlEfF.append(SJl3G6mcpO4ELCUX5jk8wr2x)
	if RR5KdNtJEBT in ['link','video','live']: jja5hLnrkgCZdA8YOuyEBDi1x = False
	elif RR5KdNtJEBT=='folder': jja5hLnrkgCZdA8YOuyEBDi1x = True
	VcZ2edUaXFqwkOmYtJx5['name'] = VaOH2318eP5yQWXrkcx
	VcZ2edUaXFqwkOmYtJx5['context_menu'] = cgrXUpOKsv95SNCoJhlEfF
	if 'plot' in list(puVFor385ci9gvjUDnflEXqmJ7wPN.keys()): VcZ2edUaXFqwkOmYtJx5['plot'] = puVFor385ci9gvjUDnflEXqmJ7wPN['plot']
	if 'stars' in list(puVFor385ci9gvjUDnflEXqmJ7wPN.keys()): VcZ2edUaXFqwkOmYtJx5['stars'] = puVFor385ci9gvjUDnflEXqmJ7wPN['stars']
	if feRw3p6MLob90H4J: VcZ2edUaXFqwkOmYtJx5['image'] = feRw3p6MLob90H4J
	if RR5KdNtJEBT=='video' and Qc2dAT3X9nH5LCtBY:
		AzL6vhB4kJofiM7UWZjaRb1eN9SgXD = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('[\d:]+',Qc2dAT3X9nH5LCtBY,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if AzL6vhB4kJofiM7UWZjaRb1eN9SgXD:
			AzL6vhB4kJofiM7UWZjaRb1eN9SgXD = '0:0:0:0:0:'+AzL6vhB4kJofiM7UWZjaRb1eN9SgXD[0]
			KtnlUTb3Vw,v7n6xHwFzBIT8,NRMoerkn4A9xu,KOpZSF0EdqBwxuXJc,oKaVwAfpqMEHnOzS0Jd1FUc3GWD = AzL6vhB4kJofiM7UWZjaRb1eN9SgXD.rsplit(':',4)
			GUAnX4gc6fJvTrwNOFKhq = int(v7n6xHwFzBIT8)*24*qJEmpHPg3IWhvS9b5lGC48n0rYs6f+int(NRMoerkn4A9xu)*qJEmpHPg3IWhvS9b5lGC48n0rYs6f+int(KOpZSF0EdqBwxuXJc)*60+int(oKaVwAfpqMEHnOzS0Jd1FUc3GWD)
			VcZ2edUaXFqwkOmYtJx5['duration'] = GUAnX4gc6fJvTrwNOFKhq
	VcZ2edUaXFqwkOmYtJx5['type'] = RR5KdNtJEBT
	VcZ2edUaXFqwkOmYtJx5['isFolder'] = jja5hLnrkgCZdA8YOuyEBDi1x
	VcZ2edUaXFqwkOmYtJx5['newpath'] = mbQ3DMW9vxjBTtAI
	VcZ2edUaXFqwkOmYtJx5['menuItem'] = Vo8UMGRpWnI
	VcZ2edUaXFqwkOmYtJx5['mode'] = LfnWDFgRdJH4lZvt7yo28N
	return VcZ2edUaXFqwkOmYtJx5
def RgzVFQlnIC0wxfShKmE8WLoUG4bji(XXDtFJpiyN75nS):
	ZHe0cgfpIs9 = []
	from DxXprMnf5t import xFrhTvB4g5WHDIO0L7Q81n,d7d8GsiMUPnuN
	yzoZg2teG7bL3P = xFrhTvB4g5WHDIO0L7Q81n()
	eemiN1oSxUJ = yUTYoAgth5iC43uLrdBH.getSetting('av.status.refresh')
	if ijrVgHOUMs5Bo0ehTA8FtvcyXJDa and (not eemiN1oSxUJ or eemiN1oSxUJ=='REFRESH_CACHE'): eemiN1oSxUJ = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'str','FOLDERS_SORT',ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	if   eemiN1oSxUJ in ['1','MENU_REVERSED']: AhBFVbK7LzNinwrg65JjpRP[:] = reversed(AhBFVbK7LzNinwrg65JjpRP)
	elif eemiN1oSxUJ in ['2','MENU_ASCENDED']: AhBFVbK7LzNinwrg65JjpRP[:] = sorted(AhBFVbK7LzNinwrg65JjpRP,reverse=vvglE69OFKBm817Nkc,key=lambda key:key[Mn5NGAdz6xc42s0])
	elif eemiN1oSxUJ in ['3','MENU_DESCENDED']: AhBFVbK7LzNinwrg65JjpRP[:] = sorted(AhBFVbK7LzNinwrg65JjpRP,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key:key[Mn5NGAdz6xc42s0])
	elif eemiN1oSxUJ in ['4','MENU_RANDOMIZED']: pJ5tI2GD1jSPgdzO7qBuFk60Rni93.shuffle(AhBFVbK7LzNinwrg65JjpRP)
	if eemiN1oSxUJ.startswith('MENU_') and eemiN1oSxUJ.endswith('ED'): yUTYoAgth5iC43uLrdBH.setSetting('av.status.refresh',Zg9FeADE84jSRIvPCrzYulw3sL)
	TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	lILyfgK7RTdpYczPMiE4x = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	LfnWDFgRdJH4lZvt7yo28N = int(My3un1OVBNfSQm)
	Lb7uGYvIDk0Rst1C52aylf = LfnWDFgRdJH4lZvt7yo28N-LfnWDFgRdJH4lZvt7yo28N%10
	if LfnWDFgRdJH4lZvt7yo28N%10 and Lb7uGYvIDk0Rst1C52aylf not in lILyfgK7RTdpYczPMiE4x:
		AhBFVbK7LzNinwrg65JjpRP[:] = [('link',PPQORjT2lc7SVkKwFI4D+'===== ===== ====='+u4IRSmrYMKkaHUBnDiLWh,'',9999,'','','','','')]+AhBFVbK7LzNinwrg65JjpRP
		AhBFVbK7LzNinwrg65JjpRP[:] = [('link',U2bWzwG8VdJsBqtR74ErDi3cg1v+'الترتيب الدائمي لهذه القائمة'+u4IRSmrYMKkaHUBnDiLWh,'',533,'','',ijrVgHOUMs5Bo0ehTA8FtvcyXJDa,'','')]+AhBFVbK7LzNinwrg65JjpRP
	for Vo8UMGRpWnI in AhBFVbK7LzNinwrg65JjpRP:
		VcZ2edUaXFqwkOmYtJx5 = WWvFT8MZ1QthpRrXz(Vo8UMGRpWnI,XXDtFJpiyN75nS,yzoZg2teG7bL3P)
		if VcZ2edUaXFqwkOmYtJx5['favorites']:
			ulEFZCm72dnqQrz = d7d8GsiMUPnuN(yzoZg2teG7bL3P,VcZ2edUaXFqwkOmYtJx5['menuItem'],VcZ2edUaXFqwkOmYtJx5['newpath'])
			VcZ2edUaXFqwkOmYtJx5['context_menu'] = ulEFZCm72dnqQrz+VcZ2edUaXFqwkOmYtJx5['context_menu']
		ZHe0cgfpIs9.append(VcZ2edUaXFqwkOmYtJx5)
	return ZHe0cgfpIs9
def Y81YzFxJ3sO4CA6Zb(K2Qe8NmokbrnE7WMy6OZ3LHY):
	JJiHyeSP5NpC2wWzgE4IQr,YzEN1olk9wxGA80OWT, = [],Zg9FeADE84jSRIvPCrzYulw3sL
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		if not oPlAXTViOL4Fw: JJiHyeSP5NpC2wWzgE4IQr.append(Zg9FeADE84jSRIvPCrzYulw3sL)
		else: break
	K2Qe8NmokbrnE7WMy6OZ3LHY = K2Qe8NmokbrnE7WMy6OZ3LHY[len(JJiHyeSP5NpC2wWzgE4IQr):]
	Tbwq7kJ4vRSNVyUFcdMzirG = '\n\n\n\n'.join(K2Qe8NmokbrnE7WMy6OZ3LHY)
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('===== ===== =====','000001')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(PPQORjT2lc7SVkKwFI4D,'000002')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,'000003')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(u4IRSmrYMKkaHUBnDiLWh,'000004')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RIGHT]','000005')
	D0wIcOgK6BJtoEys2U = 100000
	b4XxG9RdJrUfO1h2C5 = {}
	faNKpQXrw3dnm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('http.*?[\r\n ]',Tbwq7kJ4vRSNVyUFcdMzirG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for AEXgqBjS21znMe7OwClJyTdpGPY in faNKpQXrw3dnm:
		D0wIcOgK6BJtoEys2U += 1
		Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(AEXgqBjS21znMe7OwClJyTdpGPY,str(D0wIcOgK6BJtoEys2U))
		b4XxG9RdJrUfO1h2C5[str(D0wIcOgK6BJtoEys2U)] = AEXgqBjS21znMe7OwClJyTdpGPY
	for WN2aAnXwst in range(0,len(Tbwq7kJ4vRSNVyUFcdMzirG),4800):
		OXBq1ZbuC0YkwxRNpfT9mI = Tbwq7kJ4vRSNVyUFcdMzirG[WN2aAnXwst:WN2aAnXwst+4800]
		C1syQtWVAK = yUTYoAgth5iC43uLrdBH.getSetting('av.language.code')
		tUHrEcLYK30N = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+C1syQtWVAK
		z1MkhcyLvUeR0jKGg3t = {'Content-Type':'text/plain'}
		HweIkWc2LNsbYP = OXBq1ZbuC0YkwxRNpfT9mI.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		t2P8jbfzoXhmWAe = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',tUHrEcLYK30N,HweIkWc2LNsbYP,z1MkhcyLvUeR0jKGg3t,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if t2P8jbfzoXhmWAe.succeeded:
			SfV7RHudvkPDq = t2P8jbfzoXhmWAe.content
			U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = JGmfjhoyKZUl('str',SfV7RHudvkPDq)
			if U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta:
				U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta['translation']
				U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = uumhMi6O4pk7Gjd5aTQqy2Z(U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta)
				for U26DYydTWoMlnxH4Cg1Pztj8suFw in range(len(U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta)):
					YzEN1olk9wxGA80OWT += U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta[U26DYydTWoMlnxH4Cg1Pztj8suFw][0]
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000001','===== ===== =====')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000002',PPQORjT2lc7SVkKwFI4D)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000003',U2bWzwG8VdJsBqtR74ErDi3cg1v)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000004',u4IRSmrYMKkaHUBnDiLWh)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000005','[RIGHT]')
	for D0wIcOgK6BJtoEys2U in list(b4XxG9RdJrUfO1h2C5.keys()):
		AEXgqBjS21znMe7OwClJyTdpGPY = b4XxG9RdJrUfO1h2C5[D0wIcOgK6BJtoEys2U]
		YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace(D0wIcOgK6BJtoEys2U,AEXgqBjS21znMe7OwClJyTdpGPY)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.split('\n\n\n\n')
	return JJiHyeSP5NpC2wWzgE4IQr+YzEN1olk9wxGA80OWT
def InCTO439hSmFUVBuYDpx(K2Qe8NmokbrnE7WMy6OZ3LHY):
	JJiHyeSP5NpC2wWzgE4IQr,YzEN1olk9wxGA80OWT, = [],Zg9FeADE84jSRIvPCrzYulw3sL
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		if not oPlAXTViOL4Fw: JJiHyeSP5NpC2wWzgE4IQr.append(Zg9FeADE84jSRIvPCrzYulw3sL)
		else: break
	K2Qe8NmokbrnE7WMy6OZ3LHY = K2Qe8NmokbrnE7WMy6OZ3LHY[len(JJiHyeSP5NpC2wWzgE4IQr):]
	Tbwq7kJ4vRSNVyUFcdMzirG = '\\n\\n\\n\\n'.join(K2Qe8NmokbrnE7WMy6OZ3LHY)
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('كلا','no')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('استمرار','continue')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('===== ===== =====','000001')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(PPQORjT2lc7SVkKwFI4D,'000002')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,'000003')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(u4IRSmrYMKkaHUBnDiLWh,'000004')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RIGHT]','000005')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[CENTER]','000006')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RTL]','000007')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace("'","\\\\\\'")
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('"','\\\\\\"')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,'\\n')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(mqBPGuVIYZbStQejFowJh2,'\\\\r')
	for WN2aAnXwst in range(0,len(Tbwq7kJ4vRSNVyUFcdMzirG),4800):
		OXBq1ZbuC0YkwxRNpfT9mI = Tbwq7kJ4vRSNVyUFcdMzirG[WN2aAnXwst:WN2aAnXwst+4800]
		tUHrEcLYK30N = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		z1MkhcyLvUeR0jKGg3t = {'Content-Type':'application/x-www-form-urlencoded'}
		C1syQtWVAK = yUTYoAgth5iC43uLrdBH.getSetting('av.language.code')
		HweIkWc2LNsbYP = 'f.req='+OJYiDeyvSPTNI9('[[["MkEWBc","[[\\"'+OXBq1ZbuC0YkwxRNpfT9mI+'\\",\\"ar\\",\\"'+C1syQtWVAK+'\\",1],[]]",null,"generic"]]]',Zg9FeADE84jSRIvPCrzYulw3sL)
		HweIkWc2LNsbYP = HweIkWc2LNsbYP.replace('%5Cn','%5C%5Cn')
		t2P8jbfzoXhmWAe = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',tUHrEcLYK30N,HweIkWc2LNsbYP,z1MkhcyLvUeR0jKGg3t,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if t2P8jbfzoXhmWAe.succeeded:
			SfV7RHudvkPDq = t2P8jbfzoXhmWAe.content
			SfV7RHudvkPDq = SfV7RHudvkPDq.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)[-1]
			U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = JGmfjhoyKZUl('str',SfV7RHudvkPDq)[0][2]
			if U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta:
				U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = JGmfjhoyKZUl('str',U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta)[1][0][0][5]
				U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta = uumhMi6O4pk7Gjd5aTQqy2Z(U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta)
				for U26DYydTWoMlnxH4Cg1Pztj8suFw in range(len(U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta)):
					YzEN1olk9wxGA80OWT += U2Rw4Ly8fS9dVQ1TrAHWeCmYbcqta[U26DYydTWoMlnxH4Cg1Pztj8suFw][0]
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('00000','0000').replace('0000','000')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0001','===== ===== =====')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0002',PPQORjT2lc7SVkKwFI4D)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0003',U2bWzwG8VdJsBqtR74ErDi3cg1v)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0004',u4IRSmrYMKkaHUBnDiLWh)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0005','[RIGHT]')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0006','[CENTER]')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0007','[RTL]')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.split('\n\n\n\n')
	return JJiHyeSP5NpC2wWzgE4IQr+YzEN1olk9wxGA80OWT
def Niu8OUaHmc7CVFXQvl(K2Qe8NmokbrnE7WMy6OZ3LHY):
	JJiHyeSP5NpC2wWzgE4IQr,FwQyCLKRz5ZiVAf = [],[]
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		if not oPlAXTViOL4Fw: JJiHyeSP5NpC2wWzgE4IQr.append(Zg9FeADE84jSRIvPCrzYulw3sL)
		else: break
	K2Qe8NmokbrnE7WMy6OZ3LHY = K2Qe8NmokbrnE7WMy6OZ3LHY[len(JJiHyeSP5NpC2wWzgE4IQr):]
	Tbwq7kJ4vRSNVyUFcdMzirG = '\n\n\n\n'.join(K2Qe8NmokbrnE7WMy6OZ3LHY)
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('كلا','no')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('استمرار','continue')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('أدناه','below')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(PPQORjT2lc7SVkKwFI4D,'00001')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,'00002')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(u4IRSmrYMKkaHUBnDiLWh,'00003')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('=====','00004')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(',','00005')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RTL]','00009')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[CENTER]','0000A')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(mqBPGuVIYZbStQejFowJh2,'0000B')
	K2Qe8NmokbrnE7WMy6OZ3LHY = Tbwq7kJ4vRSNVyUFcdMzirG.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
	Tbwq7kJ4vRSNVyUFcdMzirG,YzEN1olk9wxGA80OWT = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		if len(Tbwq7kJ4vRSNVyUFcdMzirG+oPlAXTViOL4Fw)<1800: Tbwq7kJ4vRSNVyUFcdMzirG += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+oPlAXTViOL4Fw
		else:
			FwQyCLKRz5ZiVAf.append(Tbwq7kJ4vRSNVyUFcdMzirG)
			Tbwq7kJ4vRSNVyUFcdMzirG = oPlAXTViOL4Fw
	FwQyCLKRz5ZiVAf.append(Tbwq7kJ4vRSNVyUFcdMzirG)
	for oPlAXTViOL4Fw in FwQyCLKRz5ZiVAf:
		z1MkhcyLvUeR0jKGg3t = {'Content-Type':'application/json','User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
		tUHrEcLYK30N = 'https://api.reverso.net/translate/v1/translation'
		C1syQtWVAK = yUTYoAgth5iC43uLrdBH.getSetting('av.language.code')
		HweIkWc2LNsbYP = {"format":"text","from":"ara","to":C1syQtWVAK,"input":oPlAXTViOL4Fw,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		HweIkWc2LNsbYP = lSD9w50N6VBOHbfT2WRiPsM.dumps(HweIkWc2LNsbYP)
		t2P8jbfzoXhmWAe = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',tUHrEcLYK30N,HweIkWc2LNsbYP,z1MkhcyLvUeR0jKGg3t,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'LIBRARY-REVERSO_TRANSLATE-1st')
		if t2P8jbfzoXhmWAe.succeeded:
			SfV7RHudvkPDq = t2P8jbfzoXhmWAe.content
			SfV7RHudvkPDq = JGmfjhoyKZUl('dict',SfV7RHudvkPDq)
			YzEN1olk9wxGA80OWT += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+Zg9FeADE84jSRIvPCrzYulw3sL.join(SfV7RHudvkPDq['translation'])
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT[2:]
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000000','00000').replace('00000','0000').replace('0000','000')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0001',PPQORjT2lc7SVkKwFI4D)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0002',U2bWzwG8VdJsBqtR74ErDi3cg1v)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0003',u4IRSmrYMKkaHUBnDiLWh)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0004','=====')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0005',',')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('0009','[RTL]')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000A','[CENTER]')
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.replace('000B',mqBPGuVIYZbStQejFowJh2)
	YzEN1olk9wxGA80OWT = YzEN1olk9wxGA80OWT.split('\n\n\n\n')
	return JJiHyeSP5NpC2wWzgE4IQr+YzEN1olk9wxGA80OWT
def msPLqiKcMzJvVBwDYQSr6XWHEG(K2Qe8NmokbrnE7WMy6OZ3LHY):
	oC2tTBmNnMSGE40kvrVI6HsX = yUTYoAgth5iC43uLrdBH.getSetting('av.language.translate')
	if not oC2tTBmNnMSGE40kvrVI6HsX or not K2Qe8NmokbrnE7WMy6OZ3LHY: return K2Qe8NmokbrnE7WMy6OZ3LHY
	GSnYqw72jvkE0fC84eXFHJN = yUTYoAgth5iC43uLrdBH.getSetting('av.language.provider')
	C1syQtWVAK = yUTYoAgth5iC43uLrdBH.getSetting('av.language.code')
	jT3o2sydxhaCiKz = C1syQtWVAK+'__'+str(K2Qe8NmokbrnE7WMy6OZ3LHY)
	yUTYoAgth5iC43uLrdBH.setSetting('av.language.translate',Zg9FeADE84jSRIvPCrzYulw3sL)
	YzEN1olk9wxGA80OWT = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','TRANSLATE_'+GSnYqw72jvkE0fC84eXFHJN,jT3o2sydxhaCiKz)
	if not YzEN1olk9wxGA80OWT:
		if GSnYqw72jvkE0fC84eXFHJN=='GOOGLE': YzEN1olk9wxGA80OWT = InCTO439hSmFUVBuYDpx(K2Qe8NmokbrnE7WMy6OZ3LHY)
		elif GSnYqw72jvkE0fC84eXFHJN=='REVERSO': YzEN1olk9wxGA80OWT = Niu8OUaHmc7CVFXQvl(K2Qe8NmokbrnE7WMy6OZ3LHY)
		elif GSnYqw72jvkE0fC84eXFHJN=='GLOSBE': YzEN1olk9wxGA80OWT = Y81YzFxJ3sO4CA6Zb(K2Qe8NmokbrnE7WMy6OZ3LHY)
		if len(K2Qe8NmokbrnE7WMy6OZ3LHY)==len(YzEN1olk9wxGA80OWT):
			cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'TRANSLATE_'+GSnYqw72jvkE0fC84eXFHJN,jT3o2sydxhaCiKz,YzEN1olk9wxGA80OWT,uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
		else:
			YzEN1olk9wxGA80OWT = K2Qe8NmokbrnE7WMy6OZ3LHY
			ZXWeI01flR('الترجمة فشلت','Translation Failed')
	yUTYoAgth5iC43uLrdBH.setSetting('av.language.translate','1')
	return YzEN1olk9wxGA80OWT
def kQphjx9Ob4sVB1fCSTrGiYLyXHR20(Vo8UMGRpWnI,ZHe0cgfpIs9,Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,cAsibjSH8C5JaT3RqUlk4v,ThJRvMt9cWeS23wiy):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = Vo8UMGRpWnI
	c2oOKFpnmJUPaAZX = []
	oC2tTBmNnMSGE40kvrVI6HsX = yUTYoAgth5iC43uLrdBH.getSetting('av.language.translate')
	if oC2tTBmNnMSGE40kvrVI6HsX:
		KqPZxyhWkoat1bi,GLiycDbKBzhJ,RRHd2Iu7qVmX69UEn4j = [],[],[]
		if not c2oOKFpnmJUPaAZX:
			for VcZ2edUaXFqwkOmYtJx5 in ZHe0cgfpIs9:
				VaOH2318eP5yQWXrkcx = VcZ2edUaXFqwkOmYtJx5['name'].replace(FEftnphOJQY9dWI5iCoMj43zKbA,Zg9FeADE84jSRIvPCrzYulw3sL).replace(MVtOGEXYcJLSjm4,Zg9FeADE84jSRIvPCrzYulw3sL)
				W8TyOS9bZsU = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if W8TyOS9bZsU:
					JJiHyeSP5NpC2wWzgE4IQr,d3tw6K1Pn7WsjC,UPrms5Zfk47SIlEgxjvKNXwz,vXH2IfnLek3gZi,VaOH2318eP5yQWXrkcx = W8TyOS9bZsU[0]
					W8TyOS9bZsU = JJiHyeSP5NpC2wWzgE4IQr+d3tw6K1Pn7WsjC+wjs26GpVfNiCUERHJ+UPrms5Zfk47SIlEgxjvKNXwz+vXH2IfnLek3gZi+wjs26GpVfNiCUERHJ
				else:
					W8TyOS9bZsU = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if W8TyOS9bZsU:
						VaOH2318eP5yQWXrkcx,JJiHyeSP5NpC2wWzgE4IQr,UPrms5Zfk47SIlEgxjvKNXwz,d3tw6K1Pn7WsjC,vXH2IfnLek3gZi = W8TyOS9bZsU[0]
						W8TyOS9bZsU = JJiHyeSP5NpC2wWzgE4IQr+d3tw6K1Pn7WsjC+wjs26GpVfNiCUERHJ+UPrms5Zfk47SIlEgxjvKNXwz+vXH2IfnLek3gZi+wjs26GpVfNiCUERHJ
					else: W8TyOS9bZsU = Zg9FeADE84jSRIvPCrzYulw3sL
				T3wqrjSzoPXxl = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if T3wqrjSzoPXxl: T3wqrjSzoPXxl,VaOH2318eP5yQWXrkcx = T3wqrjSzoPXxl[0]
				else: T3wqrjSzoPXxl = Zg9FeADE84jSRIvPCrzYulw3sL
				KqPZxyhWkoat1bi.append(W8TyOS9bZsU+T3wqrjSzoPXxl)
				GLiycDbKBzhJ.append(VaOH2318eP5yQWXrkcx)
			RRHd2Iu7qVmX69UEn4j = msPLqiKcMzJvVBwDYQSr6XWHEG(GLiycDbKBzhJ)
			if RRHd2Iu7qVmX69UEn4j:
				for WN2aAnXwst in range(len(ZHe0cgfpIs9)):
					VcZ2edUaXFqwkOmYtJx5 = ZHe0cgfpIs9[WN2aAnXwst]
					VcZ2edUaXFqwkOmYtJx5['name'] = KqPZxyhWkoat1bi[WN2aAnXwst]+RRHd2Iu7qVmX69UEn4j[WN2aAnXwst]
					c2oOKFpnmJUPaAZX.append(VcZ2edUaXFqwkOmYtJx5)
	if c2oOKFpnmJUPaAZX: ZHe0cgfpIs9 = c2oOKFpnmJUPaAZX
	DMrA5bBX6pegz1ilNjKd7PxOQF,pUjNZeMLowHh,ugdZPIE4e9SXlrs6R1NTt0xW = [],0,0
	uD7JAmkb0vP8XfK4VUjY = yUTYoAgth5iC43uLrdBH.getSetting('av.status.menusimages')
	NiOeJapRCKSqP7M049WG3ys = uD7JAmkb0vP8XfK4VUjY!='STOP'
	if NiOeJapRCKSqP7M049WG3ys:
		ffiYjhG5aHkyIC2ubUptR8sKl1w = brAUlZfdFmt3TRJW2xX4.path.join(bhliCPq5mvAg19sIF,LfnWDFgRdJH4lZvt7yo28N)
		try: JR4VZu3lqtaQiMfCYKTvDbgWk = brAUlZfdFmt3TRJW2xX4.listdir(ffiYjhG5aHkyIC2ubUptR8sKl1w)
		except:
			if not brAUlZfdFmt3TRJW2xX4.path.exists(ffiYjhG5aHkyIC2ubUptR8sKl1w):
				try: brAUlZfdFmt3TRJW2xX4.makedirs(ffiYjhG5aHkyIC2ubUptR8sKl1w)
				except: pass
			JR4VZu3lqtaQiMfCYKTvDbgWk = []
	jtbRSw70TuXafqsUQ = ESB78Xz6uNCLd3YTjJtGo4fr15('menu_item')
	for VcZ2edUaXFqwkOmYtJx5 in ZHe0cgfpIs9:
		VaOH2318eP5yQWXrkcx = VcZ2edUaXFqwkOmYtJx5['name']
		cgrXUpOKsv95SNCoJhlEfF = VcZ2edUaXFqwkOmYtJx5['context_menu']
		N6PqRBjiQhdEzvLnr12 = VcZ2edUaXFqwkOmYtJx5['plot']
		jLUEIsYhHB1uMJ759wmFRZOov = VcZ2edUaXFqwkOmYtJx5['stars']
		feRw3p6MLob90H4J = VcZ2edUaXFqwkOmYtJx5['image']
		RR5KdNtJEBT = VcZ2edUaXFqwkOmYtJx5['type']
		AzL6vhB4kJofiM7UWZjaRb1eN9SgXD = VcZ2edUaXFqwkOmYtJx5['duration']
		jja5hLnrkgCZdA8YOuyEBDi1x = VcZ2edUaXFqwkOmYtJx5['isFolder']
		mbQ3DMW9vxjBTtAI = VcZ2edUaXFqwkOmYtJx5['newpath']
		djt5g9pnRlT6xPJEqK8f = HqjWaYEzp0D8eyQRud.ListItem(VaOH2318eP5yQWXrkcx)
		djt5g9pnRlT6xPJEqK8f.addContextMenuItems(cgrXUpOKsv95SNCoJhlEfF)
		pblSJn2u0qZORDz = False if NiOeJapRCKSqP7M049WG3ys else True
		if feRw3p6MLob90H4J:
			djt5g9pnRlT6xPJEqK8f.setArt({'icon':feRw3p6MLob90H4J,'thumb':feRw3p6MLob90H4J,'fanart':feRw3p6MLob90H4J,'banner':feRw3p6MLob90H4J,'clearart':feRw3p6MLob90H4J,'poster':feRw3p6MLob90H4J,'clearlogo':feRw3p6MLob90H4J,'landscape':feRw3p6MLob90H4J})
			pblSJn2u0qZORDz = False
		elif not pblSJn2u0qZORDz:
			pblSJn2u0qZORDz = True
			VaOH2318eP5yQWXrkcx = pVZOH6lyXU(vvglE69OFKBm817Nkc,VaOH2318eP5yQWXrkcx)
			VaOH2318eP5yQWXrkcx = MwKxpYbB1gfk6RWQhl5F0sOAH4(VaOH2318eP5yQWXrkcx)
			GnL1tAT36RuSCbrJg5wEUhM72po = VaOH2318eP5yQWXrkcx+'.png'
			m90btCKlFhE1TANUX3WepvDV = brAUlZfdFmt3TRJW2xX4.path.join(ffiYjhG5aHkyIC2ubUptR8sKl1w,GnL1tAT36RuSCbrJg5wEUhM72po)
			if GnL1tAT36RuSCbrJg5wEUhM72po in JR4VZu3lqtaQiMfCYKTvDbgWk:
				djt5g9pnRlT6xPJEqK8f.setArt({'icon':m90btCKlFhE1TANUX3WepvDV,'thumb':m90btCKlFhE1TANUX3WepvDV,'fanart':m90btCKlFhE1TANUX3WepvDV,'banner':m90btCKlFhE1TANUX3WepvDV,'clearart':m90btCKlFhE1TANUX3WepvDV,'poster':m90btCKlFhE1TANUX3WepvDV,'clearlogo':m90btCKlFhE1TANUX3WepvDV,'landscape':m90btCKlFhE1TANUX3WepvDV})
				pblSJn2u0qZORDz = False
			elif pUjNZeMLowHh<40 and ugdZPIE4e9SXlrs6R1NTt0xW<=3:
				try:
					Ml7dohDsEIgJ9 = r3fDUvCypFzLQYauAkhbK96(jtbRSw70TuXafqsUQ,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,VaOH2318eP5yQWXrkcx,'menu_item','center',False,m90btCKlFhE1TANUX3WepvDV)
					djt5g9pnRlT6xPJEqK8f.setArt({'icon':m90btCKlFhE1TANUX3WepvDV,'thumb':m90btCKlFhE1TANUX3WepvDV,'fanart':m90btCKlFhE1TANUX3WepvDV,'banner':m90btCKlFhE1TANUX3WepvDV,'clearart':m90btCKlFhE1TANUX3WepvDV,'poster':m90btCKlFhE1TANUX3WepvDV,'clearlogo':m90btCKlFhE1TANUX3WepvDV,'landscape':m90btCKlFhE1TANUX3WepvDV})
					pUjNZeMLowHh += 1
					pblSJn2u0qZORDz = False
					JR4VZu3lqtaQiMfCYKTvDbgWk.append(GnL1tAT36RuSCbrJg5wEUhM72po)
					if pUjNZeMLowHh==5: ZXWeI01flR('إضافة الكتابة لصور القائمة','انتظار',LNma2eq3vEguwVtHjn=500)
				except: ugdZPIE4e9SXlrs6R1NTt0xW += 1
		if pblSJn2u0qZORDz:
			djt5g9pnRlT6xPJEqK8f.setArt({'icon':MKA6jlwszI2LeWgqEQ,'thumb':MKA6jlwszI2LeWgqEQ,'fanart':MKA6jlwszI2LeWgqEQ,'banner':MKA6jlwszI2LeWgqEQ,'clearart':MKA6jlwszI2LeWgqEQ,'poster':MKA6jlwszI2LeWgqEQ,'clearlogo':MKA6jlwszI2LeWgqEQ,'landscape':MKA6jlwszI2LeWgqEQ})
		if NGiBmYp8vX9T426lHn7ue<20:
			if N6PqRBjiQhdEzvLnr12: djt5g9pnRlT6xPJEqK8f.setInfo('video',{'Plot':N6PqRBjiQhdEzvLnr12,'PlotOutline':N6PqRBjiQhdEzvLnr12})
			if jLUEIsYhHB1uMJ759wmFRZOov: djt5g9pnRlT6xPJEqK8f.setInfo('video',{'Rating':jLUEIsYhHB1uMJ759wmFRZOov})
			if not feRw3p6MLob90H4J:
				djt5g9pnRlT6xPJEqK8f.setInfo('video',{'Title':VaOH2318eP5yQWXrkcx})
			if RR5KdNtJEBT=='video':
				djt5g9pnRlT6xPJEqK8f.setInfo('video',{'mediatype':'tvshow'})
				if AzL6vhB4kJofiM7UWZjaRb1eN9SgXD: djt5g9pnRlT6xPJEqK8f.setInfo('video',{'duration':AzL6vhB4kJofiM7UWZjaRb1eN9SgXD})
				djt5g9pnRlT6xPJEqK8f.setProperty('IsPlayable','true')
		else:
			vvXeckJWbDK23Up6r = djt5g9pnRlT6xPJEqK8f.getVideoInfoTag()
			if jLUEIsYhHB1uMJ759wmFRZOov: vvXeckJWbDK23Up6r.setRating(float(jLUEIsYhHB1uMJ759wmFRZOov))
			if not feRw3p6MLob90H4J:
				vvXeckJWbDK23Up6r.setTitle(VaOH2318eP5yQWXrkcx)
			if RR5KdNtJEBT=='video':
				vvXeckJWbDK23Up6r.setMediaType('tvshow')
				if AzL6vhB4kJofiM7UWZjaRb1eN9SgXD: vvXeckJWbDK23Up6r.setDuration(AzL6vhB4kJofiM7UWZjaRb1eN9SgXD)
				djt5g9pnRlT6xPJEqK8f.setProperty('IsPlayable','true')
		DMrA5bBX6pegz1ilNjKd7PxOQF.append((mbQ3DMW9vxjBTtAI,djt5g9pnRlT6xPJEqK8f,jja5hLnrkgCZdA8YOuyEBDi1x))
	j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.setContent(xTMIUH9jL2w4mspJkyrR,'tvshows')
	ePXLwFni0AqvG65fc = j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.addDirectoryItems(xTMIUH9jL2w4mspJkyrR,DMrA5bBX6pegz1ilNjKd7PxOQF)
	j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.endOfDirectory(xTMIUH9jL2w4mspJkyrR,Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,cAsibjSH8C5JaT3RqUlk4v,ThJRvMt9cWeS23wiy)
	return ePXLwFni0AqvG65fc
def A9Z3Ci2PQhFUwBXvI(RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J=Zg9FeADE84jSRIvPCrzYulw3sL,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP=Zg9FeADE84jSRIvPCrzYulw3sL,Tbwq7kJ4vRSNVyUFcdMzirG=Zg9FeADE84jSRIvPCrzYulw3sL,NSWD3RyE8gmLnhApqVTCM=Zg9FeADE84jSRIvPCrzYulw3sL,puVFor385ci9gvjUDnflEXqmJ7wPN={}):
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace('\t',Zg9FeADE84jSRIvPCrzYulw3sL)
	tUHrEcLYK30N = tUHrEcLYK30N.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace('\t',Zg9FeADE84jSRIvPCrzYulw3sL)
	if '_SCRIPT_' in VaOH2318eP5yQWXrkcx: d1AeaJNg4IXzTv6ER0nicLUrf,VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.split('_SCRIPT_',1)
	else: d1AeaJNg4IXzTv6ER0nicLUrf,VaOH2318eP5yQWXrkcx = Zg9FeADE84jSRIvPCrzYulw3sL,VaOH2318eP5yQWXrkcx
	if d1AeaJNg4IXzTv6ER0nicLUrf:
		Kgt9nUoXy5 = VaOH2318eP5yQWXrkcx
		if not Kgt9nUoXy5: Kgt9nUoXy5 = '....'
		elif Kgt9nUoXy5.count('_')>1: Kgt9nUoXy5 = Kgt9nUoXy5.split('_',2)[2]
		Kgt9nUoXy5 = Kgt9nUoXy5.replace(' ',Zg9FeADE84jSRIvPCrzYulw3sL)
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('ـ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ة','ه').replace('ؤ','و')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('َ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ً',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ُ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٌ',Zg9FeADE84jSRIvPCrzYulw3sL)
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('ِ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٍ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ْ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ّ',Zg9FeADE84jSRIvPCrzYulw3sL)
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('|',Zg9FeADE84jSRIvPCrzYulw3sL).replace('~',Zg9FeADE84jSRIvPCrzYulw3sL)
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('اون لاين',Zg9FeADE84jSRIvPCrzYulw3sL).replace('سيما لايت',Zg9FeADE84jSRIvPCrzYulw3sL)
		DnL8NzmpIS6ZbeP92 = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(rLYn0O75xM8GNE in Kgt9nUoXy5 for rLYn0O75xM8GNE in DnL8NzmpIS6ZbeP92): Kgt9nUoXy5 = Kgt9nUoXy5.replace('ال',Zg9FeADE84jSRIvPCrzYulw3sL)
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		Kgt9nUoXy5 = Kgt9nUoXy5.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).strip(wjs26GpVfNiCUERHJ)
		d1AeaJNg4IXzTv6ER0nicLUrf = '_LST_'+ulj9JfWhc0EgZbsm(d1AeaJNg4IXzTv6ER0nicLUrf)
		if Kgt9nUoXy5 not in list(Als2YrFfpG6.keys()): Als2YrFfpG6[Kgt9nUoXy5] = {}
		Als2YrFfpG6[Kgt9nUoXy5][d1AeaJNg4IXzTv6ER0nicLUrf] = [RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN]
	AhBFVbK7LzNinwrg65JjpRP.append([RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN])
	return
def BtKvPnEQJx32Z(Y5ksIL4FJy8WXZ2rmhgBVOe63A):
	if GGfPQnrJKEqMv2ZVxdD: from html import unescape as _gKwjm1oA9FHxq6h3QbivR
	else:
		from HTMLParser import HTMLParser as jNDIFbHl28EVhRoYJPpnMws93vL4C
		_gKwjm1oA9FHxq6h3QbivR = jNDIFbHl28EVhRoYJPpnMws93vL4C().unescape
	if '&' in Y5ksIL4FJy8WXZ2rmhgBVOe63A and ';' in Y5ksIL4FJy8WXZ2rmhgBVOe63A:
		if HByjTem6EJP5sZb: Y5ksIL4FJy8WXZ2rmhgBVOe63A = Y5ksIL4FJy8WXZ2rmhgBVOe63A.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		Y5ksIL4FJy8WXZ2rmhgBVOe63A = _gKwjm1oA9FHxq6h3QbivR(Y5ksIL4FJy8WXZ2rmhgBVOe63A)
		if HByjTem6EJP5sZb: Y5ksIL4FJy8WXZ2rmhgBVOe63A = Y5ksIL4FJy8WXZ2rmhgBVOe63A.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	return Y5ksIL4FJy8WXZ2rmhgBVOe63A
def uumhMi6O4pk7Gjd5aTQqy2Z(Y5ksIL4FJy8WXZ2rmhgBVOe63A):
	if '\\u' in Y5ksIL4FJy8WXZ2rmhgBVOe63A:
		if HByjTem6EJP5sZb: Y5ksIL4FJy8WXZ2rmhgBVOe63A = Y5ksIL4FJy8WXZ2rmhgBVOe63A.decode('unicode_escape','ignore').encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		elif GGfPQnrJKEqMv2ZVxdD: Y5ksIL4FJy8WXZ2rmhgBVOe63A = Y5ksIL4FJy8WXZ2rmhgBVOe63A.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).decode('unicode_escape','ignore')
	return Y5ksIL4FJy8WXZ2rmhgBVOe63A
def BEf8XIaMFVmj(D3wpZkW51BSrnuQfhVgPabe7sFJ,wv6pS1teU5RNd4GLMqO,nh2b0lqz6oLX3NBgwTZ,VcmG4eQSUI92LB,Tbwq7kJ4vRSNVyUFcdMzirG,KsmeNU7RgEXhnpTGZ0dIM98lw,wlUYTh9NG70QfZ2pjxkIiA,BqXhzNaLnQkZJr6dbYolgeH0jSCIDM,XopRI3tu54T1Gl0mjQdcfn2MbLArz):
	hPAjbf9Zu3n2FvC0zIq7we4iOLy = brAUlZfdFmt3TRJW2xX4.path.dirname(XopRI3tu54T1Gl0mjQdcfn2MbLArz)
	if not brAUlZfdFmt3TRJW2xX4.path.exists(hPAjbf9Zu3n2FvC0zIq7we4iOLy):
		try: brAUlZfdFmt3TRJW2xX4.makedirs(hPAjbf9Zu3n2FvC0zIq7we4iOLy)
		except: pass
	cZa5BuRsLw = ESB78Xz6uNCLd3YTjJtGo4fr15(KsmeNU7RgEXhnpTGZ0dIM98lw)
	Ml7dohDsEIgJ9 = r3fDUvCypFzLQYauAkhbK96(cZa5BuRsLw,D3wpZkW51BSrnuQfhVgPabe7sFJ,wv6pS1teU5RNd4GLMqO,nh2b0lqz6oLX3NBgwTZ,VcmG4eQSUI92LB,Tbwq7kJ4vRSNVyUFcdMzirG,KsmeNU7RgEXhnpTGZ0dIM98lw,wlUYTh9NG70QfZ2pjxkIiA,BqXhzNaLnQkZJr6dbYolgeH0jSCIDM,XopRI3tu54T1Gl0mjQdcfn2MbLArz)
	return Ml7dohDsEIgJ9
def ESB78Xz6uNCLd3YTjJtGo4fr15(KsmeNU7RgEXhnpTGZ0dIM98lw):
	qqZKpimsCVBGXDIYWUn = 5
	IzCtrjR4VPcTJk63QD851qx9MAFKvU = 20
	HycedAiZTjKzu4MaGrlt6wpPRmLD = 20
	PimpDRcKLua8A7e94w3Cd1OIQJh = 0
	UKX7mhQMOVifPj = 'center'
	CrGkjhvmS4JdWtZQDoqNbp = 0
	DIhpSMl7W6cQJrjiYdsX9B = 19
	fAp27YDiczML3vl = 30
	VMthzU3Ow27HGKvpymnY80dcfA = 8
	ahO68nqCDIvG9kgWzrZQTPFHsi = True
	WWglzGUAHNLyoFDt = 375
	zOKR6FWs59 = 410
	B2Tpi6U89bLSaczhZ = 50
	vvQBYDmqLy8tzok7XU2rZAEhjHaI = 280
	ZfvATFQ3sNzVR = 28
	i2iuKeS5QUxwk = 5
	aVRCImgZ4GiPolDb6USWTe = 0
	Ea9X5qTpdbLDOIiscS = 31
	h8UYgEoNtmZdeTAlVqPfcOIG = [36,32,28]
	from PIL import ImageDraw as VF5hbdCzyiXtuJl,ImageFont as fLCvJouZB5d,Image as SlNEv8bZReYo5yA2nrJX6Ux3g
	if 'notification' in KsmeNU7RgEXhnpTGZ0dIM98lw:
		if KsmeNU7RgEXhnpTGZ0dIM98lw=='notification_regular':
			V6VwTqxSur8Bngvf7hOUHyK0Q = 117
			UKX7mhQMOVifPj = 'left'
			ahO68nqCDIvG9kgWzrZQTPFHsi = False
		elif KsmeNU7RgEXhnpTGZ0dIM98lw=='notification_auto':
			V6VwTqxSur8Bngvf7hOUHyK0Q = 'UPPER'
			UKX7mhQMOVifPj = 'right'
			PimpDRcKLua8A7e94w3Cd1OIQJh = 10
		NPlbxwcktHo5niyLKpu96T0Yvj4Q = 720
		h8UYgEoNtmZdeTAlVqPfcOIG = [33,33,33]
		HycedAiZTjKzu4MaGrlt6wpPRmLD = 20
		IzCtrjR4VPcTJk63QD851qx9MAFKvU = 0
		fAp27YDiczML3vl = 20
		DIhpSMl7W6cQJrjiYdsX9B = 35
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='menu_item':
		h8UYgEoNtmZdeTAlVqPfcOIG,NPlbxwcktHo5niyLKpu96T0Yvj4Q,V6VwTqxSur8Bngvf7hOUHyK0Q = [28,28,28],200,250
		CrGkjhvmS4JdWtZQDoqNbp,fAp27YDiczML3vl,DIhpSMl7W6cQJrjiYdsX9B, = 0,-12,-30
		IzCtrjR4VPcTJk63QD851qx9MAFKvU = 0
		JC3Akf46MenUG = SlNEv8bZReYo5yA2nrJX6Ux3g.open(MKA6jlwszI2LeWgqEQ)
		aMPULYhCF6SglJ = SlNEv8bZReYo5yA2nrJX6Ux3g.new('RGBA',(NPlbxwcktHo5niyLKpu96T0Yvj4Q,V6VwTqxSur8Bngvf7hOUHyK0Q),(255,0,0,255))
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='confirm_smallfont': h8UYgEoNtmZdeTAlVqPfcOIG,V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = [28,24,20],500,900
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='confirm_mediumfont': h8UYgEoNtmZdeTAlVqPfcOIG,V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = [32,28,24],500,900
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='confirm_bigfont': h8UYgEoNtmZdeTAlVqPfcOIG,V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = [36,32,28],500,900
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='textview_bigfont': V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = 740,1270
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='textview_bigfont_long': V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = 'UPPER',1270
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='textview_smallfont': h8UYgEoNtmZdeTAlVqPfcOIG,V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = [28,23,18],740,1270
	elif KsmeNU7RgEXhnpTGZ0dIM98lw=='textview_smallfont_long': h8UYgEoNtmZdeTAlVqPfcOIG,V6VwTqxSur8Bngvf7hOUHyK0Q,NPlbxwcktHo5niyLKpu96T0Yvj4Q = [28,23,18],'UPPER',1270
	qqw4adOoIFQRALtWyCmBsvexEbnp,RW7ALDQC4yorP1fHSV2,fvzpMDF0uiGmwaS8seJ9nxNyP1krX = h8UYgEoNtmZdeTAlVqPfcOIG
	IdMYQwkJ5SK = fLCvJouZB5d.truetype(E5ESVm9Qa6ruPLRDntWMz0sOXKfAd,size=qqw4adOoIFQRALtWyCmBsvexEbnp)
	Nsr64ViWzwuL = fLCvJouZB5d.truetype(E5ESVm9Qa6ruPLRDntWMz0sOXKfAd,size=RW7ALDQC4yorP1fHSV2)
	QEBrficKu32wy8 = fLCvJouZB5d.truetype(E5ESVm9Qa6ruPLRDntWMz0sOXKfAd,size=fvzpMDF0uiGmwaS8seJ9nxNyP1krX)
	IHrfkjNDn7YBLduOV0TzvltgmcSG = NPlbxwcktHo5niyLKpu96T0Yvj4Q-fAp27YDiczML3vl*2
	Sl4kY3amC7oTg9LMdx = SlNEv8bZReYo5yA2nrJX6Ux3g.new('RGBA',(IHrfkjNDn7YBLduOV0TzvltgmcSG,100),(255,255,255,0))
	gzXBp1uIbM2oHNdWxkOyKRQFmfAv = VF5hbdCzyiXtuJl.Draw(Sl4kY3amC7oTg9LMdx)
	iiAmXyUODP2j6zGe8,Zb1mugwHMRiQoSdVYl = gzXBp1uIbM2oHNdWxkOyKRQFmfAv.textsize('HHH BBB 888 000',font=IdMYQwkJ5SK)
	qvlDzGpsfF9CPb704Zh,OIsqlFakjnmZR5cTYNBCAoV7zP = gzXBp1uIbM2oHNdWxkOyKRQFmfAv.textsize('HHH BBB 888 000',font=Nsr64ViWzwuL)
	dZiyDIWrkgXGt5QYNvaFfjqx = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as O317uaw0Zm4nJAqK6NWP
	VN8xbulwpeZvzmU5 = O317uaw0Zm4nJAqK6NWP(configuration=dZiyDIWrkgXGt5QYNvaFfjqx)
	cZa5BuRsLw = {}
	epQo8UWTydYAazX3k5RwLP = locals()
	for bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r in epQo8UWTydYAazX3k5RwLP: cZa5BuRsLw[bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r] = epQo8UWTydYAazX3k5RwLP[bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r]
	return cZa5BuRsLw
def r3fDUvCypFzLQYauAkhbK96(cZa5BuRsLw,D3wpZkW51BSrnuQfhVgPabe7sFJ,wv6pS1teU5RNd4GLMqO,nh2b0lqz6oLX3NBgwTZ,VcmG4eQSUI92LB,Tbwq7kJ4vRSNVyUFcdMzirG,KsmeNU7RgEXhnpTGZ0dIM98lw,wlUYTh9NG70QfZ2pjxkIiA,BqXhzNaLnQkZJr6dbYolgeH0jSCIDM,XopRI3tu54T1Gl0mjQdcfn2MbLArz):
	for bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r in cZa5BuRsLw: globals()[bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r] = cZa5BuRsLw[bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r]
	global ZfvATFQ3sNzVR,i2iuKeS5QUxwk
	if KsmeNU7RgEXhnpTGZ0dIM98lw!='menu_item':
		oC2tTBmNnMSGE40kvrVI6HsX = yUTYoAgth5iC43uLrdBH.getSetting('av.language.translate')
		if oC2tTBmNnMSGE40kvrVI6HsX:
			if D3wpZkW51BSrnuQfhVgPabe7sFJ=='نعم  Yes': D3wpZkW51BSrnuQfhVgPabe7sFJ = 'Yes'
			elif D3wpZkW51BSrnuQfhVgPabe7sFJ=='كلا  No': D3wpZkW51BSrnuQfhVgPabe7sFJ = 'No'
			if wv6pS1teU5RNd4GLMqO=='نعم  Yes': wv6pS1teU5RNd4GLMqO = 'Yes'
			elif wv6pS1teU5RNd4GLMqO=='كلا  No': wv6pS1teU5RNd4GLMqO = 'No'
			if nh2b0lqz6oLX3NBgwTZ=='نعم  Yes': nh2b0lqz6oLX3NBgwTZ = 'Yes'
			elif nh2b0lqz6oLX3NBgwTZ=='كلا  No': nh2b0lqz6oLX3NBgwTZ = 'No'
			x3HQ4Fyra7dZjWcJsvCPUmAT = msPLqiKcMzJvVBwDYQSr6XWHEG([D3wpZkW51BSrnuQfhVgPabe7sFJ,wv6pS1teU5RNd4GLMqO,nh2b0lqz6oLX3NBgwTZ,VcmG4eQSUI92LB,Tbwq7kJ4vRSNVyUFcdMzirG])
			if x3HQ4Fyra7dZjWcJsvCPUmAT: D3wpZkW51BSrnuQfhVgPabe7sFJ,wv6pS1teU5RNd4GLMqO,nh2b0lqz6oLX3NBgwTZ,VcmG4eQSUI92LB,Tbwq7kJ4vRSNVyUFcdMzirG = x3HQ4Fyra7dZjWcJsvCPUmAT
	if HByjTem6EJP5sZb:
		Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		VcmG4eQSUI92LB = VcmG4eQSUI92LB.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		D3wpZkW51BSrnuQfhVgPabe7sFJ = D3wpZkW51BSrnuQfhVgPabe7sFJ.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		wv6pS1teU5RNd4GLMqO = wv6pS1teU5RNd4GLMqO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		nh2b0lqz6oLX3NBgwTZ = nh2b0lqz6oLX3NBgwTZ.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	C6wpvR5DNmF2eO = VcmG4eQSUI92LB.count(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)+1
	MUIKZJd4kQacTpD3mSgFX0Oi = IzCtrjR4VPcTJk63QD851qx9MAFKvU+C6wpvR5DNmF2eO*(Zb1mugwHMRiQoSdVYl+PimpDRcKLua8A7e94w3Cd1OIQJh)-PimpDRcKLua8A7e94w3Cd1OIQJh
	if Tbwq7kJ4vRSNVyUFcdMzirG:
		PAGBnHJ5d8 = OIsqlFakjnmZR5cTYNBCAoV7zP+VMthzU3Ow27HGKvpymnY80dcfA
		rr2uyjqzkGKd3txwpX1Z5U = VN8xbulwpeZvzmU5.reshape(Tbwq7kJ4vRSNVyUFcdMzirG)
		if ahO68nqCDIvG9kgWzrZQTPFHsi:
			aOGZegfVqSvjlTJ9ARhrY0uxmc = uuA8fcIxBPnoChEQ4dFNm1OR(gzXBp1uIbM2oHNdWxkOyKRQFmfAv,Nsr64ViWzwuL,rr2uyjqzkGKd3txwpX1Z5U,RW7ALDQC4yorP1fHSV2,IHrfkjNDn7YBLduOV0TzvltgmcSG,PAGBnHJ5d8)
			B39BSpVQ4TNqCnwE = xzm39ObGAMoE5SgpB(aOGZegfVqSvjlTJ9ARhrY0uxmc)
			OfnwWp8Aa6NV4ELvMImyFjXlKbZz = B39BSpVQ4TNqCnwE.count(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)+1
			dl57wpH486zMSarjQYgNVFJsqL = DIhpSMl7W6cQJrjiYdsX9B+OfnwWp8Aa6NV4ELvMImyFjXlKbZz*PAGBnHJ5d8-VMthzU3Ow27HGKvpymnY80dcfA
		else:
			dl57wpH486zMSarjQYgNVFJsqL = DIhpSMl7W6cQJrjiYdsX9B+OIsqlFakjnmZR5cTYNBCAoV7zP
			B39BSpVQ4TNqCnwE = rr2uyjqzkGKd3txwpX1Z5U.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)[0]
			aOGZegfVqSvjlTJ9ARhrY0uxmc = rr2uyjqzkGKd3txwpX1Z5U.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)[0]
	else: dl57wpH486zMSarjQYgNVFJsqL = DIhpSMl7W6cQJrjiYdsX9B
	grLTDuYIMi6 = aVRCImgZ4GiPolDb6USWTe+Ea9X5qTpdbLDOIiscS
	if BqXhzNaLnQkZJr6dbYolgeH0jSCIDM:
		EG4IYKdvpWmZkqDih0uB79 = zOKR6FWs59-WWglzGUAHNLyoFDt
		grLTDuYIMi6 += EG4IYKdvpWmZkqDih0uB79
	else: EG4IYKdvpWmZkqDih0uB79 = 0
	if D3wpZkW51BSrnuQfhVgPabe7sFJ or wv6pS1teU5RNd4GLMqO or nh2b0lqz6oLX3NBgwTZ: grLTDuYIMi6 += B2Tpi6U89bLSaczhZ
	Ml7dohDsEIgJ9 = V6VwTqxSur8Bngvf7hOUHyK0Q if V6VwTqxSur8Bngvf7hOUHyK0Q!='UPPER' else MUIKZJd4kQacTpD3mSgFX0Oi+dl57wpH486zMSarjQYgNVFJsqL+grLTDuYIMi6
	Sl4kY3amC7oTg9LMdx = SlNEv8bZReYo5yA2nrJX6Ux3g.new('RGBA',(NPlbxwcktHo5niyLKpu96T0Yvj4Q,Ml7dohDsEIgJ9),(255,255,255,0))
	QNKt8bfnVOL = VF5hbdCzyiXtuJl.Draw(Sl4kY3amC7oTg9LMdx)
	TgiF1mShbDVGvJ = Ml7dohDsEIgJ9-MUIKZJd4kQacTpD3mSgFX0Oi-grLTDuYIMi6-DIhpSMl7W6cQJrjiYdsX9B
	if not wv6pS1teU5RNd4GLMqO and D3wpZkW51BSrnuQfhVgPabe7sFJ and nh2b0lqz6oLX3NBgwTZ:
		ZfvATFQ3sNzVR += 105
		i2iuKeS5QUxwk -= 110
	import bidi.algorithm as R75ODtZqmK3kox
	if VcmG4eQSUI92LB:
		Z3LtKFwye2 = IzCtrjR4VPcTJk63QD851qx9MAFKvU
		VcmG4eQSUI92LB = R75ODtZqmK3kox.get_display(VN8xbulwpeZvzmU5.reshape(VcmG4eQSUI92LB))
		K2Qe8NmokbrnE7WMy6OZ3LHY = VcmG4eQSUI92LB.splitlines()
		for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
			if oPlAXTViOL4Fw:
				FRI2pPds896jNeYW,S8Sityn9O7FBpaNK5 = QNKt8bfnVOL.textsize(oPlAXTViOL4Fw,font=IdMYQwkJ5SK)
				if UKX7mhQMOVifPj=='center': L3LFjVdtA27ZHivrS = qqZKpimsCVBGXDIYWUn+(NPlbxwcktHo5niyLKpu96T0Yvj4Q-FRI2pPds896jNeYW)/2
				elif UKX7mhQMOVifPj=='right': L3LFjVdtA27ZHivrS = qqZKpimsCVBGXDIYWUn+NPlbxwcktHo5niyLKpu96T0Yvj4Q-FRI2pPds896jNeYW-HycedAiZTjKzu4MaGrlt6wpPRmLD
				elif UKX7mhQMOVifPj=='left': L3LFjVdtA27ZHivrS = qqZKpimsCVBGXDIYWUn+HycedAiZTjKzu4MaGrlt6wpPRmLD
				QNKt8bfnVOL.text((L3LFjVdtA27ZHivrS,Z3LtKFwye2),oPlAXTViOL4Fw,font=IdMYQwkJ5SK,fill='yellow')
			Z3LtKFwye2 += qqw4adOoIFQRALtWyCmBsvexEbnp+PimpDRcKLua8A7e94w3Cd1OIQJh
	if D3wpZkW51BSrnuQfhVgPabe7sFJ or wv6pS1teU5RNd4GLMqO or nh2b0lqz6oLX3NBgwTZ:
		ipnWTbx784PBcYHf2LK = MUIKZJd4kQacTpD3mSgFX0Oi+TgiF1mShbDVGvJ+DIhpSMl7W6cQJrjiYdsX9B+EG4IYKdvpWmZkqDih0uB79+aVRCImgZ4GiPolDb6USWTe
		if D3wpZkW51BSrnuQfhVgPabe7sFJ:
			D3wpZkW51BSrnuQfhVgPabe7sFJ = R75ODtZqmK3kox.get_display(VN8xbulwpeZvzmU5.reshape(D3wpZkW51BSrnuQfhVgPabe7sFJ))
			KV2dGwb0IxW6TRafJFZ,yP7Kw9c4uRojeZQkH6v0nIlGpEhsN = QNKt8bfnVOL.textsize(D3wpZkW51BSrnuQfhVgPabe7sFJ,font=QEBrficKu32wy8)
			jTk7XlVsNhq6cBD = ZfvATFQ3sNzVR+0*(i2iuKeS5QUxwk+vvQBYDmqLy8tzok7XU2rZAEhjHaI)+(vvQBYDmqLy8tzok7XU2rZAEhjHaI-KV2dGwb0IxW6TRafJFZ)/2
			QNKt8bfnVOL.text((jTk7XlVsNhq6cBD,ipnWTbx784PBcYHf2LK),D3wpZkW51BSrnuQfhVgPabe7sFJ,font=QEBrficKu32wy8,fill='yellow')
		if wv6pS1teU5RNd4GLMqO:
			wv6pS1teU5RNd4GLMqO = R75ODtZqmK3kox.get_display(VN8xbulwpeZvzmU5.reshape(wv6pS1teU5RNd4GLMqO))
			bZGSzK7jcBi0HenVR1qaQlTv8MJ,bbzc5ftd9nmRF3ATwYro0i = QNKt8bfnVOL.textsize(wv6pS1teU5RNd4GLMqO,font=QEBrficKu32wy8)
			VVjgNPGpUWbxJOmwF3KlQCLen9 = ZfvATFQ3sNzVR+1*(i2iuKeS5QUxwk+vvQBYDmqLy8tzok7XU2rZAEhjHaI)+(vvQBYDmqLy8tzok7XU2rZAEhjHaI-bZGSzK7jcBi0HenVR1qaQlTv8MJ)/2
			QNKt8bfnVOL.text((VVjgNPGpUWbxJOmwF3KlQCLen9,ipnWTbx784PBcYHf2LK),wv6pS1teU5RNd4GLMqO,font=QEBrficKu32wy8,fill='yellow')
		if nh2b0lqz6oLX3NBgwTZ:
			nh2b0lqz6oLX3NBgwTZ = R75ODtZqmK3kox.get_display(VN8xbulwpeZvzmU5.reshape(nh2b0lqz6oLX3NBgwTZ))
			mHI3CjhOw8WLtvRpYg5FoU6V0,miPYduqljbXxKHg7ZMvnoekLD8Qh = QNKt8bfnVOL.textsize(nh2b0lqz6oLX3NBgwTZ,font=QEBrficKu32wy8)
			YMpT0GS6Jl4Ci = ZfvATFQ3sNzVR+2*(i2iuKeS5QUxwk+vvQBYDmqLy8tzok7XU2rZAEhjHaI)+(vvQBYDmqLy8tzok7XU2rZAEhjHaI-mHI3CjhOw8WLtvRpYg5FoU6V0)/2
			QNKt8bfnVOL.text((YMpT0GS6Jl4Ci,ipnWTbx784PBcYHf2LK),nh2b0lqz6oLX3NBgwTZ,font=QEBrficKu32wy8,fill='yellow')
	if Tbwq7kJ4vRSNVyUFcdMzirG:
		KqMlRJwbD6SU,jek2X8TsL0cl419RuiQMnBZv = [],[]
		aOGZegfVqSvjlTJ9ARhrY0uxmc = QQtky6hDF5bPARqWp9c0zKB4m2Jw8(aOGZegfVqSvjlTJ9ARhrY0uxmc)
		OODc5d2r16oIQsP4Blu9FXK = aOGZegfVqSvjlTJ9ARhrY0uxmc.split('_sss__newline_')
		for fuyP4G3NHQasFK1VtO6vxwCciL7 in OODc5d2r16oIQsP4Blu9FXK:
			aBRqGh0HlojW5 = wlUYTh9NG70QfZ2pjxkIiA
			if   '_sss__lineleft_' in fuyP4G3NHQasFK1VtO6vxwCciL7: aBRqGh0HlojW5 = 'left'
			elif '_sss__lineright_' in fuyP4G3NHQasFK1VtO6vxwCciL7: aBRqGh0HlojW5 = 'right'
			elif '_sss__linecenter_' in fuyP4G3NHQasFK1VtO6vxwCciL7: aBRqGh0HlojW5 = 'center'
			m3CaPys0kvAu9Y6ReOzrK = fuyP4G3NHQasFK1VtO6vxwCciL7
			rr6elEJwR0Ut5igDsXhOzoLAFc4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('_sss__.*?_',fuyP4G3NHQasFK1VtO6vxwCciL7,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for Ox4vATLWb1 in rr6elEJwR0Ut5igDsXhOzoLAFc4: m3CaPys0kvAu9Y6ReOzrK = m3CaPys0kvAu9Y6ReOzrK.replace(Ox4vATLWb1,Zg9FeADE84jSRIvPCrzYulw3sL)
			if m3CaPys0kvAu9Y6ReOzrK==Zg9FeADE84jSRIvPCrzYulw3sL: FRI2pPds896jNeYW,S8Sityn9O7FBpaNK5 = 0,PAGBnHJ5d8
			else: FRI2pPds896jNeYW,S8Sityn9O7FBpaNK5 = QNKt8bfnVOL.textsize(m3CaPys0kvAu9Y6ReOzrK,font=Nsr64ViWzwuL)
			if   aBRqGh0HlojW5=='left': nQ5qbai1YmWp7hzOuv = CrGkjhvmS4JdWtZQDoqNbp+fAp27YDiczML3vl
			elif aBRqGh0HlojW5=='right': nQ5qbai1YmWp7hzOuv = CrGkjhvmS4JdWtZQDoqNbp+fAp27YDiczML3vl+IHrfkjNDn7YBLduOV0TzvltgmcSG-FRI2pPds896jNeYW
			elif aBRqGh0HlojW5=='center': nQ5qbai1YmWp7hzOuv = CrGkjhvmS4JdWtZQDoqNbp+fAp27YDiczML3vl+(IHrfkjNDn7YBLduOV0TzvltgmcSG-FRI2pPds896jNeYW)/2
			if nQ5qbai1YmWp7hzOuv<fAp27YDiczML3vl: nQ5qbai1YmWp7hzOuv = CrGkjhvmS4JdWtZQDoqNbp+fAp27YDiczML3vl
			KqMlRJwbD6SU.append(nQ5qbai1YmWp7hzOuv)
			jek2X8TsL0cl419RuiQMnBZv.append(FRI2pPds896jNeYW)
		nQ5qbai1YmWp7hzOuv = KqMlRJwbD6SU[0]
		k02s7upebMtGar6EvqPOlAQSL3 = aOGZegfVqSvjlTJ9ARhrY0uxmc.split('_sss_')
		MigL5UjHxBz6vnWchE = (255,255,255,255)
		MAGwdUmTeo2 = MigL5UjHxBz6vnWchE
		Kx1MbrBS5Uo,XXEdi0rgueDH = 0,0
		Ocmtz1XCNSvolJfyAH6Q0r8EgkDUs = False
		tUPaJQkEWdm0Oo3K8L2shCfqy = 0
		DJlEbhKZCodw = MUIKZJd4kQacTpD3mSgFX0Oi+DIhpSMl7W6cQJrjiYdsX9B/2
		if dl57wpH486zMSarjQYgNVFJsqL<(TgiF1mShbDVGvJ+DIhpSMl7W6cQJrjiYdsX9B):
			BFbx7ie2klXE6yWgfuG1S3qAmLZj = (TgiF1mShbDVGvJ+DIhpSMl7W6cQJrjiYdsX9B-dl57wpH486zMSarjQYgNVFJsqL)/2
			DJlEbhKZCodw = MUIKZJd4kQacTpD3mSgFX0Oi+DIhpSMl7W6cQJrjiYdsX9B+BFbx7ie2klXE6yWgfuG1S3qAmLZj-OIsqlFakjnmZR5cTYNBCAoV7zP/2
		for oPlAXTViOL4Fw in k02s7upebMtGar6EvqPOlAQSL3:
			if not oPlAXTViOL4Fw or (oPlAXTViOL4Fw and ord(oPlAXTViOL4Fw[0])==65279): continue
			c4WBlkVJE6UAwG9o = oPlAXTViOL4Fw.split('_newline_',1)
			Kun9fULzv73Cakl0 = oPlAXTViOL4Fw.split('_newcolor',1)
			lN2XsVxLUnmSbDaWdG1hjC = oPlAXTViOL4Fw.split('_endcolor_',1)
			wOrgayTFji = oPlAXTViOL4Fw.split('_linertl_',1)
			wP1lH5m8oAvDkXcsSjB = oPlAXTViOL4Fw.split('_lineleft_',1)
			wDW8sj2hzOKideGN3up9L6AkH7Zvm = oPlAXTViOL4Fw.split('_lineright_',1)
			qtdHSBGszKRbyPmu7hD23Z5U = oPlAXTViOL4Fw.split('_linecenter_',1)
			if len(c4WBlkVJE6UAwG9o)>1:
				tUPaJQkEWdm0Oo3K8L2shCfqy += 1
				oPlAXTViOL4Fw = c4WBlkVJE6UAwG9o[1]
				Kx1MbrBS5Uo = 0
				nQ5qbai1YmWp7hzOuv = KqMlRJwbD6SU[tUPaJQkEWdm0Oo3K8L2shCfqy]
				XXEdi0rgueDH += PAGBnHJ5d8
				Ocmtz1XCNSvolJfyAH6Q0r8EgkDUs = False
			elif len(Kun9fULzv73Cakl0)>1:
				oPlAXTViOL4Fw = Kun9fULzv73Cakl0[1]
				MAGwdUmTeo2 = oPlAXTViOL4Fw[0:8]
				MAGwdUmTeo2 = '#'+MAGwdUmTeo2[2:]
				oPlAXTViOL4Fw = oPlAXTViOL4Fw[9:]
			elif len(lN2XsVxLUnmSbDaWdG1hjC)>1:
				oPlAXTViOL4Fw = lN2XsVxLUnmSbDaWdG1hjC[1]
				MAGwdUmTeo2 = MigL5UjHxBz6vnWchE
			elif len(wOrgayTFji)>1:
				oPlAXTViOL4Fw = wOrgayTFji[1]
				Ocmtz1XCNSvolJfyAH6Q0r8EgkDUs = True
				Kx1MbrBS5Uo = jek2X8TsL0cl419RuiQMnBZv[tUPaJQkEWdm0Oo3K8L2shCfqy]
			elif len(wP1lH5m8oAvDkXcsSjB)>1: oPlAXTViOL4Fw = wP1lH5m8oAvDkXcsSjB[1]
			elif len(wDW8sj2hzOKideGN3up9L6AkH7Zvm)>1: oPlAXTViOL4Fw = wDW8sj2hzOKideGN3up9L6AkH7Zvm[1]
			elif len(qtdHSBGszKRbyPmu7hD23Z5U)>1: oPlAXTViOL4Fw = qtdHSBGszKRbyPmu7hD23Z5U[1]
			if oPlAXTViOL4Fw:
				D8N541f27RY = DJlEbhKZCodw+XXEdi0rgueDH
				oPlAXTViOL4Fw = R75ODtZqmK3kox.get_display(oPlAXTViOL4Fw)
				FRI2pPds896jNeYW,S8Sityn9O7FBpaNK5 = QNKt8bfnVOL.textsize(oPlAXTViOL4Fw,font=Nsr64ViWzwuL)
				if Ocmtz1XCNSvolJfyAH6Q0r8EgkDUs: Kx1MbrBS5Uo -= FRI2pPds896jNeYW
				kbpwh391KA = nQ5qbai1YmWp7hzOuv+Kx1MbrBS5Uo
				QNKt8bfnVOL.text((kbpwh391KA,D8N541f27RY),oPlAXTViOL4Fw,font=Nsr64ViWzwuL,fill=MAGwdUmTeo2)
				if KsmeNU7RgEXhnpTGZ0dIM98lw=='menu_item': QNKt8bfnVOL.text((kbpwh391KA+1,D8N541f27RY+1),oPlAXTViOL4Fw,font=Nsr64ViWzwuL,fill=MAGwdUmTeo2)
				if not Ocmtz1XCNSvolJfyAH6Q0r8EgkDUs: Kx1MbrBS5Uo += FRI2pPds896jNeYW
				if D8N541f27RY>TgiF1mShbDVGvJ+PAGBnHJ5d8: break
	if KsmeNU7RgEXhnpTGZ0dIM98lw=='menu_item':
		fT582Eit4sQIK71dC = JC3Akf46MenUG.copy()
		LNma2eq3vEguwVtHjn.sleep(0.05)
		fT582Eit4sQIK71dC.paste(aMPULYhCF6SglJ,(0,0),mask=Sl4kY3amC7oTg9LMdx)
	else: fT582Eit4sQIK71dC = Sl4kY3amC7oTg9LMdx
	if HByjTem6EJP5sZb: XopRI3tu54T1Gl0mjQdcfn2MbLArz = XopRI3tu54T1Gl0mjQdcfn2MbLArz.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	try: fT582Eit4sQIK71dC.save(XopRI3tu54T1Gl0mjQdcfn2MbLArz)
	except UnicodeError:
		if HByjTem6EJP5sZb:
			XopRI3tu54T1Gl0mjQdcfn2MbLArz = XopRI3tu54T1Gl0mjQdcfn2MbLArz.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			fT582Eit4sQIK71dC.save(XopRI3tu54T1Gl0mjQdcfn2MbLArz)
	return Ml7dohDsEIgJ9
def uuA8fcIxBPnoChEQ4dFNm1OR(gzXBp1uIbM2oHNdWxkOyKRQFmfAv,Nsr64ViWzwuL,cXz5R0VbmvsoKDwF3,mb23xw9yzQMdlOjnK,IHrfkjNDn7YBLduOV0TzvltgmcSG,Jz2AKTZwDUfjepx0lC8tHuFEW3iX):
	A1v4QPDoUYgSjqdcN9rh8TByGO,JF0boxKLOr16,ttwAKXRGST3rkNPC8p6 = Zg9FeADE84jSRIvPCrzYulw3sL,0,15000
	cXz5R0VbmvsoKDwF3 = cXz5R0VbmvsoKDwF3.replace('[COLOR ','[COLOR:::')
	rrZ9Y1N6f4i = IHrfkjNDn7YBLduOV0TzvltgmcSG-mb23xw9yzQMdlOjnK*2
	for qsRh1yap7iJdKfXwg5rxM in cXz5R0VbmvsoKDwF3.splitlines():
		JF0boxKLOr16 += Jz2AKTZwDUfjepx0lC8tHuFEW3iX
		bb2BmpwIuxt9T87hk1FVLYlnz3K,QmcyoE2p5KdB = 0,Zg9FeADE84jSRIvPCrzYulw3sL
		for KWNpHe6lrMP937Tn4qBvL8 in qsRh1yap7iJdKfXwg5rxM.split(wjs26GpVfNiCUERHJ):
			lkdZ4c37I0OyafApmRP1 = xzm39ObGAMoE5SgpB(wjs26GpVfNiCUERHJ+KWNpHe6lrMP937Tn4qBvL8)
			pB4v7GRiMnhSE,Kvz3umH1hgSyaAEci0ql = gzXBp1uIbM2oHNdWxkOyKRQFmfAv.textsize(lkdZ4c37I0OyafApmRP1,font=Nsr64ViWzwuL)
			if bb2BmpwIuxt9T87hk1FVLYlnz3K+pB4v7GRiMnhSE<rrZ9Y1N6f4i:
				if not QmcyoE2p5KdB: QmcyoE2p5KdB += KWNpHe6lrMP937Tn4qBvL8
				else: QmcyoE2p5KdB += wjs26GpVfNiCUERHJ+KWNpHe6lrMP937Tn4qBvL8
				bb2BmpwIuxt9T87hk1FVLYlnz3K += pB4v7GRiMnhSE
			else:
				if pB4v7GRiMnhSE<rrZ9Y1N6f4i:
					QmcyoE2p5KdB += '\n '+KWNpHe6lrMP937Tn4qBvL8
					JF0boxKLOr16 += Jz2AKTZwDUfjepx0lC8tHuFEW3iX
					bb2BmpwIuxt9T87hk1FVLYlnz3K = pB4v7GRiMnhSE
				else:
					while pB4v7GRiMnhSE>rrZ9Y1N6f4i:
						for WN2aAnXwst in range(1,len(wjs26GpVfNiCUERHJ+KWNpHe6lrMP937Tn4qBvL8),1):
							FEZ8otYAIj3 = wjs26GpVfNiCUERHJ+KWNpHe6lrMP937Tn4qBvL8[:WN2aAnXwst]
							ZgMXBbDptlokVc3RI2G = KWNpHe6lrMP937Tn4qBvL8[WN2aAnXwst:]
							orOwm0VkYIK9xZXU4qaNHhCb = xzm39ObGAMoE5SgpB(FEZ8otYAIj3)
							JPNCM2psAv4utn0y8fbTYqUOiSoZF,ASlmz1DxnvGjotUrwZFEWMH359T4 = gzXBp1uIbM2oHNdWxkOyKRQFmfAv.textsize(orOwm0VkYIK9xZXU4qaNHhCb,font=Nsr64ViWzwuL)
							if bb2BmpwIuxt9T87hk1FVLYlnz3K+JPNCM2psAv4utn0y8fbTYqUOiSoZF>rrZ9Y1N6f4i:
								N1FKL9tQapM6ZYyCnW8V0iwkmIh = pB4v7GRiMnhSE-JPNCM2psAv4utn0y8fbTYqUOiSoZF
								QmcyoE2p5KdB += FEZ8otYAIj3+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
								JF0boxKLOr16 += Jz2AKTZwDUfjepx0lC8tHuFEW3iX
								pB4v7GRiMnhSE = N1FKL9tQapM6ZYyCnW8V0iwkmIh
								if N1FKL9tQapM6ZYyCnW8V0iwkmIh>rrZ9Y1N6f4i:
									bb2BmpwIuxt9T87hk1FVLYlnz3K = 0
									KWNpHe6lrMP937Tn4qBvL8 = ZgMXBbDptlokVc3RI2G
								else:
									bb2BmpwIuxt9T87hk1FVLYlnz3K = N1FKL9tQapM6ZYyCnW8V0iwkmIh
									QmcyoE2p5KdB += ZgMXBbDptlokVc3RI2G
								break
				if JF0boxKLOr16>ttwAKXRGST3rkNPC8p6: break
		A1v4QPDoUYgSjqdcN9rh8TByGO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+QmcyoE2p5KdB
		if JF0boxKLOr16>ttwAKXRGST3rkNPC8p6: break
	A1v4QPDoUYgSjqdcN9rh8TByGO = A1v4QPDoUYgSjqdcN9rh8TByGO[1:]
	A1v4QPDoUYgSjqdcN9rh8TByGO = A1v4QPDoUYgSjqdcN9rh8TByGO.replace('[COLOR:::','[COLOR ')
	return A1v4QPDoUYgSjqdcN9rh8TByGO
def xzm39ObGAMoE5SgpB(KWNpHe6lrMP937Tn4qBvL8):
	if '[' in KWNpHe6lrMP937Tn4qBvL8 and ']' in KWNpHe6lrMP937Tn4qBvL8:
		rr6elEJwR0Ut5igDsXhOzoLAFc4 = [u4IRSmrYMKkaHUBnDiLWh,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		rG5z4TXaos8jxcFdA9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\[COLOR .*?\]',KWNpHe6lrMP937Tn4qBvL8,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		itHynC8QdoBbr7XEKlv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\[COLOR:::.*?\]',KWNpHe6lrMP937Tn4qBvL8,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		EjWTitxqI3KSOlG17oP = rr6elEJwR0Ut5igDsXhOzoLAFc4+rG5z4TXaos8jxcFdA9+itHynC8QdoBbr7XEKlv
		for Ox4vATLWb1 in EjWTitxqI3KSOlG17oP: KWNpHe6lrMP937Tn4qBvL8 = KWNpHe6lrMP937Tn4qBvL8.replace(Ox4vATLWb1,Zg9FeADE84jSRIvPCrzYulw3sL)
	return KWNpHe6lrMP937Tn4qBvL8
def QQtky6hDF5bPARqWp9c0zKB4m2Jw8(Tbwq7kJ4vRSNVyUFcdMzirG):
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,'_sss__newline_')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RTL]','_sss__linertl_')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[LEFT]','_sss__lineleft_')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[RIGHT]','_sss__lineright_')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[CENTER]','_sss__linecenter_')
	Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace(u4IRSmrYMKkaHUBnDiLWh,'_sss__endcolor_')
	k4JTaHtAgryDS = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\[COLOR (.*?)\]',Tbwq7kJ4vRSNVyUFcdMzirG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for xvZIr4UsaBmD7CygqkRLt0Xp in k4JTaHtAgryDS: Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.replace('[COLOR '+xvZIr4UsaBmD7CygqkRLt0Xp+']','_sss__newcolor'+xvZIr4UsaBmD7CygqkRLt0Xp+'_')
	return Tbwq7kJ4vRSNVyUFcdMzirG
def pVZOH6lyXU(W7WDxqiv2dHCXgf5Rkj93pGcewbrMI,VaOH2318eP5yQWXrkcx=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Label')
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).strip(wjs26GpVfNiCUERHJ)
	if W7WDxqiv2dHCXgf5Rkj93pGcewbrMI: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('[COLOR ',Zg9FeADE84jSRIvPCrzYulw3sL).replace(']',Zg9FeADE84jSRIvPCrzYulw3sL)
	else: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,Zg9FeADE84jSRIvPCrzYulw3sL).replace(PPQORjT2lc7SVkKwFI4D,Zg9FeADE84jSRIvPCrzYulw3sL).replace(xqPlYeVsWSkB703w9,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mmJCaDuIX10,Zg9FeADE84jSRIvPCrzYulw3sL)
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)
	kYMdGJq5AihbzEvHDpN8m = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\d\d:\d\d ',VaOH2318eP5yQWXrkcx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if kYMdGJq5AihbzEvHDpN8m: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.split(kYMdGJq5AihbzEvHDpN8m[0],1)[1]
	if not VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = 'Main Menu'
	return VaOH2318eP5yQWXrkcx
def MwKxpYbB1gfk6RWQhl5F0sOAH4(GWOwzaVUyAH5JIC):
	TnZQApP7U3LOiRvkzFDJEyq9u416 = Zg9FeADE84jSRIvPCrzYulw3sL.join(WN2aAnXwst for WN2aAnXwst in GWOwzaVUyAH5JIC if WN2aAnXwst not in '\/":*?<>|'+n7eguYlER0J5)
	return TnZQApP7U3LOiRvkzFDJEyq9u416
def NkJiXgtIB5ECy(Kkpm8izMrSFTGBcyUWHvtCYdxQaRP):
	HweIkWc2LNsbYP = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.S)
	if HweIkWc2LNsbYP:
		R1RUr6u4bc,ppJrAtLeCEZDX = HweIkWc2LNsbYP[0]
		R1RUr6u4bc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("=[\r\n\s\t]+'(.*?)';", R1RUr6u4bc, aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.S)[0]
		if R1RUr6u4bc and ppJrAtLeCEZDX:
			g52RhPD0sTluCEq6Fwxp3tWIcdG = R1RUr6u4bc.replace("'",Zg9FeADE84jSRIvPCrzYulw3sL).replace("+",Zg9FeADE84jSRIvPCrzYulw3sL).replace("\n",Zg9FeADE84jSRIvPCrzYulw3sL).replace("\r",Zg9FeADE84jSRIvPCrzYulw3sL)
			HHcqm2Tw7GxSJVguYdz0fXUQDr = g52RhPD0sTluCEq6Fwxp3tWIcdG.split('.')
			Kkpm8izMrSFTGBcyUWHvtCYdxQaRP = Zg9FeADE84jSRIvPCrzYulw3sL
			for WY0KDbaTzAm89G in HHcqm2Tw7GxSJVguYdz0fXUQDr:
				K1Kr6DeGY4zakWbVwU9gxIOd = JDMo92nlwsAZydBPkpNzFvU.b64decode(WY0KDbaTzAm89G+'==').decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
				Ia3P7Abk4QDMlJnVjmwU1px = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\d+', K1Kr6DeGY4zakWbVwU9gxIOd, aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.S)
				if Ia3P7Abk4QDMlJnVjmwU1px:
					vRohQkMJ03HCS1w9xEc7DGgtTIBV = int(Ia3P7Abk4QDMlJnVjmwU1px[0])
					vRohQkMJ03HCS1w9xEc7DGgtTIBV += int(ppJrAtLeCEZDX)
					Kkpm8izMrSFTGBcyUWHvtCYdxQaRP = Kkpm8izMrSFTGBcyUWHvtCYdxQaRP + chr(vRohQkMJ03HCS1w9xEc7DGgtTIBV)
			if GGfPQnrJKEqMv2ZVxdD: Kkpm8izMrSFTGBcyUWHvtCYdxQaRP = Kkpm8izMrSFTGBcyUWHvtCYdxQaRP.encode('iso-8859-1').decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	return Kkpm8izMrSFTGBcyUWHvtCYdxQaRP
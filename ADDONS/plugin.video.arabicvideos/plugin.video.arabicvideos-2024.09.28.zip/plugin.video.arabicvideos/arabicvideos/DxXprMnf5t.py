# -*- coding: utf-8 -*-
from V1VREBsj92 import *
d1AeaJNg4IXzTv6ER0nicLUrf = 'FAVORITES'
def ut1mDygn8U6fzQhaMrBYK9l(LfnWDFgRdJH4lZvt7yo28N,LK9mWEGoYzd4bnle20DRvixXM):
	if   LfnWDFgRdJH4lZvt7yo28N==270: x3HQ4Fyra7dZjWcJsvCPUmAT = bbR3FyrsBGSoft(LK9mWEGoYzd4bnle20DRvixXM)
	else: x3HQ4Fyra7dZjWcJsvCPUmAT = False
	return x3HQ4Fyra7dZjWcJsvCPUmAT
def ofJQjaukKYsph58G9(NSWD3RyE8gmLnhApqVTCM,LK9mWEGoYzd4bnle20DRvixXM,AGucrkbdpFBwUOK46S9iMPQHx):
	if not NSWD3RyE8gmLnhApqVTCM: return
	if   AGucrkbdpFBwUOK46S9iMPQHx=='UP1'	: MM1RNrIbKXYqUoesJf5mk4p62it(LK9mWEGoYzd4bnle20DRvixXM,True,Mn5NGAdz6xc42s0)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='DOWN1'	: MM1RNrIbKXYqUoesJf5mk4p62it(LK9mWEGoYzd4bnle20DRvixXM,False,Mn5NGAdz6xc42s0)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='UP4'	: MM1RNrIbKXYqUoesJf5mk4p62it(LK9mWEGoYzd4bnle20DRvixXM,True,NEc173Pr0jAwLF5OS)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='DOWN4'	: MM1RNrIbKXYqUoesJf5mk4p62it(LK9mWEGoYzd4bnle20DRvixXM,False,NEc173Pr0jAwLF5OS)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='ADD1'	: CmlKd6ihe87kput3POqc(LK9mWEGoYzd4bnle20DRvixXM)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='REMOVE1': jKDiEW8ZkeOhwVSlq23sH5UA4(LK9mWEGoYzd4bnle20DRvixXM)
	elif AGucrkbdpFBwUOK46S9iMPQHx=='DELETELIST': QNZ0W6aITmo4Vr8sYuy(LK9mWEGoYzd4bnle20DRvixXM)
	return
def bbR3FyrsBGSoft(LK9mWEGoYzd4bnle20DRvixXM):
	Tgab9lmZMV73Aeh = xFrhTvB4g5WHDIO0L7Q81n()
	if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()):
		try:
			lvCEAruYmtWTih = Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]
			if UwCT5Oz6Wo0BP and LK9mWEGoYzd4bnle20DRvixXM in ['5','11','12','13']:
				for RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN in lvCEAruYmtWTih:
					if RR5KdNtJEBT=='video':
						A9Z3Ci2PQhFUwBXvI('video',PPQORjT2lc7SVkKwFI4D+'تشغيل من الأعلى إلى الأسفل'+u4IRSmrYMKkaHUBnDiLWh,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM)
						A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
						break
			for RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN in lvCEAruYmtWTih:
				A9Z3Ci2PQhFUwBXvI(RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN)
		except:
			Tgab9lmZMV73Aeh = wRZbDkg3X6Qhc(tJuIjTFl9cwGz2dishvoUm4SPK3ArB)
			lvCEAruYmtWTih = Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]
			for RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN in lvCEAruYmtWTih:
				A9Z3Ci2PQhFUwBXvI(RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN)
	return
def CmlKd6ihe87kput3POqc(LK9mWEGoYzd4bnle20DRvixXM):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	if LK9mWEGoYzd4bnle20DRvixXM in ['5','11','12','13'] and RR5KdNtJEBT!='video':
		I3kpd28CgLtrVEcuAXiZ('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	Vo8UMGRpWnI = RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,puVFor385ci9gvjUDnflEXqmJ7wPN
	Tgab9lmZMV73Aeh = xFrhTvB4g5WHDIO0L7Q81n()
	DehTQBMu3yLaFocmJSRpdjNtUvskz = {}
	for VCKPWkO5aMITti4mHl8YszJ in list(Tgab9lmZMV73Aeh.keys()):
		if VCKPWkO5aMITti4mHl8YszJ!=LK9mWEGoYzd4bnle20DRvixXM: DehTQBMu3yLaFocmJSRpdjNtUvskz[VCKPWkO5aMITti4mHl8YszJ] = Tgab9lmZMV73Aeh[VCKPWkO5aMITti4mHl8YszJ]
		else:
			if VaOH2318eP5yQWXrkcx and VaOH2318eP5yQWXrkcx!='..':
				rr5zQLh1OMS = Tgab9lmZMV73Aeh[VCKPWkO5aMITti4mHl8YszJ]
				if Vo8UMGRpWnI in rr5zQLh1OMS:
					TjRYq0vln9WHMf7LGKEX = rr5zQLh1OMS.index(Vo8UMGRpWnI)
					del rr5zQLh1OMS[TjRYq0vln9WHMf7LGKEX]
				PPUtohZNsiyV = rr5zQLh1OMS+[Vo8UMGRpWnI]
				DehTQBMu3yLaFocmJSRpdjNtUvskz[VCKPWkO5aMITti4mHl8YszJ] = PPUtohZNsiyV
			else: DehTQBMu3yLaFocmJSRpdjNtUvskz[VCKPWkO5aMITti4mHl8YszJ] = Tgab9lmZMV73Aeh[VCKPWkO5aMITti4mHl8YszJ]
	if LK9mWEGoYzd4bnle20DRvixXM not in list(DehTQBMu3yLaFocmJSRpdjNtUvskz.keys()): DehTQBMu3yLaFocmJSRpdjNtUvskz[LK9mWEGoYzd4bnle20DRvixXM] = [Vo8UMGRpWnI]
	TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = str(DehTQBMu3yLaFocmJSRpdjNtUvskz)
	if GGfPQnrJKEqMv2ZVxdD: TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = TDzVFcUBk7ubhWAypqNG5H3l4fsrZ.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	open(tJuIjTFl9cwGz2dishvoUm4SPK3ArB,'wb').write(TDzVFcUBk7ubhWAypqNG5H3l4fsrZ)
	return
def jKDiEW8ZkeOhwVSlq23sH5UA4(LK9mWEGoYzd4bnle20DRvixXM):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	Vo8UMGRpWnI = RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,puVFor385ci9gvjUDnflEXqmJ7wPN
	Tgab9lmZMV73Aeh = xFrhTvB4g5WHDIO0L7Q81n()
	if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()) and Vo8UMGRpWnI in Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]:
		Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM].remove(Vo8UMGRpWnI)
		if len(Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM])==UwCT5Oz6Wo0BP: del Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]
		TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = str(Tgab9lmZMV73Aeh)
		if GGfPQnrJKEqMv2ZVxdD: TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = TDzVFcUBk7ubhWAypqNG5H3l4fsrZ.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open(tJuIjTFl9cwGz2dishvoUm4SPK3ArB,'wb').write(TDzVFcUBk7ubhWAypqNG5H3l4fsrZ)
	return
def MM1RNrIbKXYqUoesJf5mk4p62it(LK9mWEGoYzd4bnle20DRvixXM,Va0QDeg7Ix8wGdcXqpkO,FvwqgofhIBLxmC7jHD):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	Vo8UMGRpWnI = RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,puVFor385ci9gvjUDnflEXqmJ7wPN
	Tgab9lmZMV73Aeh = xFrhTvB4g5WHDIO0L7Q81n()
	if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()):
		rr5zQLh1OMS = Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]
		if Vo8UMGRpWnI not in rr5zQLh1OMS: return
		EmyXaqkijMezRglFPIHAChTY = len(rr5zQLh1OMS)
		for WN2aAnXwst in range(UwCT5Oz6Wo0BP,FvwqgofhIBLxmC7jHD):
			bbRkjOuF6WVxAtDI7qEJYMSv1H = rr5zQLh1OMS.index(Vo8UMGRpWnI)
			if Va0QDeg7Ix8wGdcXqpkO: hXvV7yqN0H1sWr = bbRkjOuF6WVxAtDI7qEJYMSv1H-Mn5NGAdz6xc42s0
			else: hXvV7yqN0H1sWr = bbRkjOuF6WVxAtDI7qEJYMSv1H+Mn5NGAdz6xc42s0
			if hXvV7yqN0H1sWr>=EmyXaqkijMezRglFPIHAChTY: hXvV7yqN0H1sWr = hXvV7yqN0H1sWr-EmyXaqkijMezRglFPIHAChTY
			if hXvV7yqN0H1sWr<UwCT5Oz6Wo0BP: hXvV7yqN0H1sWr = hXvV7yqN0H1sWr+EmyXaqkijMezRglFPIHAChTY
			rr5zQLh1OMS.insert(hXvV7yqN0H1sWr, rr5zQLh1OMS.pop(bbRkjOuF6WVxAtDI7qEJYMSv1H))
		Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM] = rr5zQLh1OMS
		TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = str(Tgab9lmZMV73Aeh)
		if GGfPQnrJKEqMv2ZVxdD: TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = TDzVFcUBk7ubhWAypqNG5H3l4fsrZ.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open(tJuIjTFl9cwGz2dishvoUm4SPK3ArB,'wb').write(TDzVFcUBk7ubhWAypqNG5H3l4fsrZ)
	return
def fCUFZTdXEpHwIak2jGsRvVehzrqDl(LK9mWEGoYzd4bnle20DRvixXM):
	if LK9mWEGoYzd4bnle20DRvixXM in ['1','2','3','4']: J9JZ3Y7nA6qWbeELsF8NM1k,zBqfoU8mKbG = 'مفضلة',LK9mWEGoYzd4bnle20DRvixXM
	elif LK9mWEGoYzd4bnle20DRvixXM in ['5']: J9JZ3Y7nA6qWbeELsF8NM1k,zBqfoU8mKbG = 'تشغيل','1'
	elif LK9mWEGoYzd4bnle20DRvixXM in ['11']: J9JZ3Y7nA6qWbeELsF8NM1k,zBqfoU8mKbG = 'تشغيل','2'
	else: J9JZ3Y7nA6qWbeELsF8NM1k,zBqfoU8mKbG = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	ToZq7UhRz8Nj3ciAbJBFaMgGKYm = J9JZ3Y7nA6qWbeELsF8NM1k+wjs26GpVfNiCUERHJ+zBqfoU8mKbG
	return ToZq7UhRz8Nj3ciAbJBFaMgGKYm
def QNZ0W6aITmo4Vr8sYuy(LK9mWEGoYzd4bnle20DRvixXM):
	ToZq7UhRz8Nj3ciAbJBFaMgGKYm = fCUFZTdXEpHwIak2jGsRvVehzrqDl(LK9mWEGoYzd4bnle20DRvixXM)
	xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+ToZq7UhRz8Nj3ciAbJBFaMgGKYm+' ؟!')
	if xLiq4khYySNP26cwgn8pa!=1: return
	Tgab9lmZMV73Aeh = xFrhTvB4g5WHDIO0L7Q81n()
	if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()):
		del Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]
		TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = str(Tgab9lmZMV73Aeh)
		if GGfPQnrJKEqMv2ZVxdD: TDzVFcUBk7ubhWAypqNG5H3l4fsrZ = TDzVFcUBk7ubhWAypqNG5H3l4fsrZ.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open(tJuIjTFl9cwGz2dishvoUm4SPK3ArB,'wb').write(TDzVFcUBk7ubhWAypqNG5H3l4fsrZ)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+ToZq7UhRz8Nj3ciAbJBFaMgGKYm)
	return
def xFrhTvB4g5WHDIO0L7Q81n():
	Tgab9lmZMV73Aeh = {}
	if brAUlZfdFmt3TRJW2xX4.path.exists(tJuIjTFl9cwGz2dishvoUm4SPK3ArB):
		nmeR1FJMqQDo9 = open(tJuIjTFl9cwGz2dishvoUm4SPK3ArB,'rb').read()
		if GGfPQnrJKEqMv2ZVxdD: nmeR1FJMqQDo9 = nmeR1FJMqQDo9.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		Tgab9lmZMV73Aeh = JGmfjhoyKZUl('dict',nmeR1FJMqQDo9)
	return Tgab9lmZMV73Aeh
def d7d8GsiMUPnuN(Tgab9lmZMV73Aeh,Vo8UMGRpWnI,De3vm8SOwqnA):
	RR5KdNtJEBT,VaOH2318eP5yQWXrkcx,tUHrEcLYK30N,LfnWDFgRdJH4lZvt7yo28N,feRw3p6MLob90H4J,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,Tbwq7kJ4vRSNVyUFcdMzirG,NSWD3RyE8gmLnhApqVTCM,puVFor385ci9gvjUDnflEXqmJ7wPN = Vo8UMGRpWnI
	if not LfnWDFgRdJH4lZvt7yo28N: RR5KdNtJEBT,LfnWDFgRdJH4lZvt7yo28N = 'folder','260'
	J2wi4KFTQpErPab98tDvk75,LK9mWEGoYzd4bnle20DRvixXM = [],Zg9FeADE84jSRIvPCrzYulw3sL
	if 'context=' in ijrVgHOUMs5Bo0ehTA8FtvcyXJDa:
		kYMdGJq5AihbzEvHDpN8m = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('context=(\d+)',ijrVgHOUMs5Bo0ehTA8FtvcyXJDa,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if kYMdGJq5AihbzEvHDpN8m: LK9mWEGoYzd4bnle20DRvixXM = str(kYMdGJq5AihbzEvHDpN8m[UwCT5Oz6Wo0BP])
	if LfnWDFgRdJH4lZvt7yo28N=='270':
		LK9mWEGoYzd4bnle20DRvixXM = NSWD3RyE8gmLnhApqVTCM
		if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()):
			ToZq7UhRz8Nj3ciAbJBFaMgGKYm = fCUFZTdXEpHwIak2jGsRvVehzrqDl(LK9mWEGoYzd4bnle20DRvixXM)
			J2wi4KFTQpErPab98tDvk75.append(('مسح قائمة '+ToZq7UhRz8Nj3ciAbJBFaMgGKYm,'RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_DELETELIST'+')'))
	else:
		if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()):
			count = len(Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM])
			if count>Mn5NGAdz6xc42s0: J2wi4KFTQpErPab98tDvk75.append(('تحريك 1 للأعلى','RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_UP1)'))
			if count>NEc173Pr0jAwLF5OS: J2wi4KFTQpErPab98tDvk75.append(('تحريك 4 للأعلى','RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_UP4)'))
			if count>Mn5NGAdz6xc42s0: J2wi4KFTQpErPab98tDvk75.append(('تحريك 1 للأسفل','RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_DOWN1)'))
			if count>NEc173Pr0jAwLF5OS: J2wi4KFTQpErPab98tDvk75.append(('تحريك 4 للأسفل','RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_DOWN4)'))
		for LK9mWEGoYzd4bnle20DRvixXM in ['1','2','3','4','5','11']:
			ToZq7UhRz8Nj3ciAbJBFaMgGKYm = fCUFZTdXEpHwIak2jGsRvVehzrqDl(LK9mWEGoYzd4bnle20DRvixXM)
			if LK9mWEGoYzd4bnle20DRvixXM in list(Tgab9lmZMV73Aeh.keys()) and Vo8UMGRpWnI in Tgab9lmZMV73Aeh[LK9mWEGoYzd4bnle20DRvixXM]:
				J2wi4KFTQpErPab98tDvk75.append(('مسح من '+ToZq7UhRz8Nj3ciAbJBFaMgGKYm,'RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_REMOVE1)'))
			else: J2wi4KFTQpErPab98tDvk75.append(('إضافة ل'+ToZq7UhRz8Nj3ciAbJBFaMgGKYm,'RunPlugin('+De3vm8SOwqnA+'&context='+LK9mWEGoYzd4bnle20DRvixXM+'_ADD1)'))
	JMGNznCX1Fm4eWZa = []
	for Zs6dJNL1c02HAXe87S5m,P7RAU1na5xyiXYGskMdcWhDIOHC in J2wi4KFTQpErPab98tDvk75:
		Zs6dJNL1c02HAXe87S5m = U2bWzwG8VdJsBqtR74ErDi3cg1v+Zs6dJNL1c02HAXe87S5m+u4IRSmrYMKkaHUBnDiLWh
		JMGNznCX1Fm4eWZa.append((Zs6dJNL1c02HAXe87S5m,P7RAU1na5xyiXYGskMdcWhDIOHC,))
	return JMGNznCX1Fm4eWZa
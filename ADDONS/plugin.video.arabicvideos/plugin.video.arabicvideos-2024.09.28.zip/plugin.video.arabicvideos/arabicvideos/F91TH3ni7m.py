# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'CIMAABDO'
j0jSEdTPJuG4XNvfpO = '_ABD_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['الرئيسية']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==550: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==551: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==552: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==553: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==559: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49+'/home',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(qfzHe2Yr49,'url')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,559,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'اخترنا لك',Wtu1ZQ5yrA2KVlPs76EgbRvz+'/home',551,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('main-content(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-name="(.*?)".*?</i>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for AxYL8hm1sni5ej,title in items:
		yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/ajax/getItem?item='+AxYL8hm1sni5ej+'&Ajax=1'
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,551)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"nav-main"(.*?)</nav>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if yDTPzhEBKVJl7CX81=='#': continue
		if title in Uhe07PlWNakHDZc1t: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,551)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	for yDTPzhEBKVJl7CX81,title in items:
		if yDTPzhEBKVJl7CX81=='#': continue
		if title in Uhe07PlWNakHDZc1t: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,551)
	return
def mbzIyKNqMVt0FQeOsPWc(url,AxYL8hm1sni5ej=Zg9FeADE84jSRIvPCrzYulw3sL):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
		Y3OmVPp2ARgBCjn = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-TITLES-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = [yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG]
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-TITLES-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		if AxYL8hm1sni5ej=='featured':
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"container"(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		elif '"section-post mb-10"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"section-post mb-10"(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		else:
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<article(.*?)"pagination"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f: return
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if not items:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
		yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81).strip('/')
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if 'سلاسل' not in url and any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,552,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'الحلقة' in title:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,553,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/movies/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,551,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,553,W8KBRzkdhlCxvF5sY2T)
	if AxYL8hm1sni5ej==Zg9FeADE84jSRIvPCrzYulw3sL:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)<footer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81=="": continue
				if title!=Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'هناك المزيد',url,551)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"getSeasonsBySeries(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"list-episodes"(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr and '/series/' not in url:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,553,W8KBRzkdhlCxvF5sY2T)
	elif sQPyfIOFgKLTU4u23XB6dmS9:
		W8KBRzkdhlCxvF5sY2T = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"image" src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T[0]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,552,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	JaqiYfEglZDvmwQNS8zR = url.replace('/movies/','/watch_movies/')
	JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR.replace('/episodes/','/watch_episodes/')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(JaqiYfEglZDvmwQNS8zR,'url')
	ZZH6czYDb0 = []
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''<iframe.*?src=["'](.*?)["']''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'url')
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__embed')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"servers"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		BmVyhAve6X2PYuI = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('postID = "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		BmVyhAve6X2PYuI = BmVyhAve6X2PYuI[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for m0t48jnKhrQFJViguoMl9NBPp,title in items:
				title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
				yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/ajax/getPlayer?server='+m0t48jnKhrQFJViguoMl9NBPp+'&postID='+BmVyhAve6X2PYuI+'&Ajax=1'
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if items:
				m0t48jnKhrQFJViguoMl9NBPp,shJA5gCN8xe3IMiLr9wuEktGj,title = items[0]
				yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/ajax/getPlayerByName?server='+m0t48jnKhrQFJViguoMl9NBPp+'&multipleServers='+shJA5gCN8xe3IMiLr9wuEktGj+'&postID='+BmVyhAve6X2PYuI+'&Ajax=1'
				hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(yDTPzhEBKVJl7CX81)
				Y3OmVPp2ARgBCjn = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-PLAY-2nd')
				yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
				xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''<iframe src=["'](.*?)["']''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
				WOry7DZPocFhH8p4 = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[0] if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL else Zg9FeADE84jSRIvPCrzYulw3sL
				if '/iframe/' in WOry7DZPocFhH8p4:
					Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',WOry7DZPocFhH8p4,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-PLAY-3rd')
					yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
					VLtSCaoNIclOsWMZu = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('version&quot;:&quot;(.*?)&',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					VLtSCaoNIclOsWMZu = VLtSCaoNIclOsWMZu[0]
					Y3OmVPp2ARgBCjn = {}
					Y3OmVPp2ARgBCjn['X-Inertia-Partial-Component'] = 'files/mirror/video'
					Y3OmVPp2ARgBCjn['X-Inertia'] = 'true'
					Y3OmVPp2ARgBCjn['X-Inertia-Partial-Data'] = 'streams'
					Y3OmVPp2ARgBCjn['X-Inertia-Version'] = VLtSCaoNIclOsWMZu
					Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',WOry7DZPocFhH8p4,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'CIMAABDO-PLAY-4th')
					yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
					G3mSCzExg241eN9btoR7AnLl = JGmfjhoyKZUl('dict',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
					groups = G3mSCzExg241eN9btoR7AnLl['props']['streams']['data']
					for group in groups:
						YUCPADxT3NrgM = group['label'].replace(' (source)',Zg9FeADE84jSRIvPCrzYulw3sL)
						hdFOT5RDX6nYaHQ19viBtsCozm = group['mirrors']
						for llQ2OdoWhItvKc9AsVDa in hdFOT5RDX6nYaHQ19viBtsCozm:
							m0t48jnKhrQFJViguoMl9NBPp = llQ2OdoWhItvKc9AsVDa['driver']
							yDTPzhEBKVJl7CX81 = 'http:'+llQ2OdoWhItvKc9AsVDa['link']+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__watch____'+YUCPADxT3NrgM
							ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"downs"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,name in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+name+'__download'
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'-')
	url = qfzHe2Yr49+'/search/'+search+'.html'
	mbzIyKNqMVt0FQeOsPWc(url)
	return
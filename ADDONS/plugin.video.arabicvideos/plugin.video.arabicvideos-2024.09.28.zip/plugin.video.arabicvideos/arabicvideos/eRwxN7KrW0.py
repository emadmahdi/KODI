# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'YOUTUBE'
j0jSEdTPJuG4XNvfpO = '_YUT_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
DtUJ5dBK4ALqvlGEykm2a = 0
def mp9gnhjBIoA8Rz3SylG(mode,url,text,type,wlxviMOuNeQVct4ULsCEHXZm6yR2p,name,EELGungxe6wKPar9hyRv5FUMpIB):
	if	 mode==140: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==141: CsaNhTtGm8 = JnfGNZkvELDwcKMOARp(url,name,EELGungxe6wKPar9hyRv5FUMpIB)
	elif mode==143: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url,type)
	elif mode==144: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p,text)
	elif mode==145: CsaNhTtGm8 = FlAhOu94bM0(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==147: CsaNhTtGm8 = pO14eqnEmrW6PDyRYUNfta()
	elif mode==148: CsaNhTtGm8 = JDkx34LlheQO1cTfsVNSWyo()
	elif mode==149: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	if 0:
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'قائمة 1',qfzHe2Yr49+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'قائمة 2',qfzHe2Yr49+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'شخص',qfzHe2Yr49+'/user/TCNofficial',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'موقع',qfzHe2Yr49+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'حساب',qfzHe2Yr49+'/@TheSocialCTV',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'العاب',qfzHe2Yr49+'/gaming',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'افلام',qfzHe2Yr49+'/feed/storefront',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مختارات',qfzHe2Yr49+'/feed/guide_builder',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'قصيرة',qfzHe2Yr49+'/shorts',144,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'تصفح',qfzHe2Yr49+'/youtubei/v1/guide?key=',144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'رئيسية',qfzHe2Yr49+Zg9FeADE84jSRIvPCrzYulw3sL,144)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'رائج',qfzHe2Yr49+'/feed/trending?bp=',144)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,149,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الرائجة',qfzHe2Yr49+'/feed/trending',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'التصفح',qfzHe2Yr49+'/youtubei/v1/guide?key=',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'القصيرة',qfzHe2Yr49+'/shorts',144,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مختارات يوتيوب',qfzHe2Yr49+'/feed/guide_builder',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'مختارات البرنامج',Zg9FeADE84jSRIvPCrzYulw3sL,290)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: قنوات عربية',Zg9FeADE84jSRIvPCrzYulw3sL,147)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: قنوات أجنبية',Zg9FeADE84jSRIvPCrzYulw3sL,148)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: افلام عربية',qfzHe2Yr49+'/results?search_query=فيلم',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: افلام اجنبية',qfzHe2Yr49+'/results?search_query=movie',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: مسرحيات عربية',qfzHe2Yr49+'/results?search_query=مسرحية',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات عربية',qfzHe2Yr49+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات اجنبية',qfzHe2Yr49+'/results?search_query=series&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: مسلسلات كارتون',qfzHe2Yr49+'/results?search_query=كارتون&sp=EgIQAw==',144)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث: خطبة المرجعية',qfzHe2Yr49+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def JnfGNZkvELDwcKMOARp(url,name,EELGungxe6wKPar9hyRv5FUMpIB):
	name = rBzf3emckoV5bh7wl4nuastES(name)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'CHNL:  '+name,url,144,EELGungxe6wKPar9hyRv5FUMpIB)
	return
def pO14eqnEmrW6PDyRYUNfta():
	mbzIyKNqMVt0FQeOsPWc(qfzHe2Yr49+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JDkx34LlheQO1cTfsVNSWyo():
	mbzIyKNqMVt0FQeOsPWc(qfzHe2Yr49+'/results?search_query=tv&sp=EgJAAQ==')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url,type):
	url = url.split('&',1)[0]
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([url],bIPsOxjEpoH,type,url)
	return
def aabxETQSZ8YCUBJ(yuli6EPZXAq03m5YoQFCV,url,I5ycituE8YxBLn):
	level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = I5ycituE8YxBLn.split('::')
	TIK6UbCFHmWd4s5DJS,dAVf07xhMDygk13neCGKZIrt = [],[]
	if '/youtubei/v1/browse' in url: TIK6UbCFHmWd4s5DJS.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: TIK6UbCFHmWd4s5DJS.append("yccc['onResponseReceivedCommands']")
	TIK6UbCFHmWd4s5DJS.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': TIK6UbCFHmWd4s5DJS.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	TIK6UbCFHmWd4s5DJS.append("yccc['entries']")
	TIK6UbCFHmWd4s5DJS.append("yccc['items'][3]['guideSectionRenderer']['items']")
	l98atBZhpA,wiZYdQSsxVnXAMemcUhFCt7J,yRWQvnYJ5idpMhP9 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(yuli6EPZXAq03m5YoQFCV,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
	if level=='1' and l98atBZhpA:
		if len(wiZYdQSsxVnXAMemcUhFCt7J)>1 and 'search_query' not in url:
			for MeDOXJmjA87lkLfn in range(len(wiZYdQSsxVnXAMemcUhFCt7J)):
				KIRFQSDuUECZA = str(MeDOXJmjA87lkLfn)
				TIK6UbCFHmWd4s5DJS = []
				TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['reloadContinuationItemsCommand']['continuationItems']")
				TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['command']")
				TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]")
				oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,r1OMYvp0ViTG,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(wiZYdQSsxVnXAMemcUhFCt7J,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
				if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: dAVf07xhMDygk13neCGKZIrt.append([r1OMYvp0ViTG,url,'2::'+KIRFQSDuUECZA+'::0::0'])
			TIK6UbCFHmWd4s5DJS.append("yccc['continuationEndpoint']")
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,r1OMYvp0ViTG,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(yuli6EPZXAq03m5YoQFCV,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
			if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD and dAVf07xhMDygk13neCGKZIrt and 'continuationCommand' in list(r1OMYvp0ViTG.keys()):
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/my_main_page_shorts_link'
				dAVf07xhMDygk13neCGKZIrt.append([r1OMYvp0ViTG,yDTPzhEBKVJl7CX81,'1::0::0::0'])
	return wiZYdQSsxVnXAMemcUhFCt7J,l98atBZhpA,dAVf07xhMDygk13neCGKZIrt,yRWQvnYJ5idpMhP9
def Xixt2EoVmOqvARfnjzhJrWs(yuli6EPZXAq03m5YoQFCV,wiZYdQSsxVnXAMemcUhFCt7J,url,I5ycituE8YxBLn):
	level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = I5ycituE8YxBLn.split('::')
	TIK6UbCFHmWd4s5DJS,g3N0Zr7DfuLteEqSzbcYM6lnKJWmB = [],[]
	TIK6UbCFHmWd4s5DJS.append("yddd[0]['itemSectionRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['reloadContinuationItemsCommand']['continuationItems']")
	TIK6UbCFHmWd4s5DJS.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: TIK6UbCFHmWd4s5DJS.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: TIK6UbCFHmWd4s5DJS.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yddd["+KIRFQSDuUECZA+"]")
	hGpdZD3aFgu8r9zOToN572K,o1BCv3HinkmlSA6qdbDK8QxjacXt,NBRFGsxvPIZW10twrlYEUOydj = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(wiZYdQSsxVnXAMemcUhFCt7J,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
	if level=='2' and hGpdZD3aFgu8r9zOToN572K:
		if len(o1BCv3HinkmlSA6qdbDK8QxjacXt)>1:
			for MeDOXJmjA87lkLfn in range(len(o1BCv3HinkmlSA6qdbDK8QxjacXt)):
				ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo = str(MeDOXJmjA87lkLfn)
				TIK6UbCFHmWd4s5DJS = []
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['richSectionRenderer']['content']")
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]")
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['richItemRenderer']['content']")
				TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]")
				oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,r1OMYvp0ViTG,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(o1BCv3HinkmlSA6qdbDK8QxjacXt,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
				if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: g3N0Zr7DfuLteEqSzbcYM6lnKJWmB.append([r1OMYvp0ViTG,url,'3::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::0'])
			TIK6UbCFHmWd4s5DJS.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			TIK6UbCFHmWd4s5DJS.append("yddd[1]")
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,r1OMYvp0ViTG,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(wiZYdQSsxVnXAMemcUhFCt7J,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
			if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD and g3N0Zr7DfuLteEqSzbcYM6lnKJWmB and 'continuationItemRenderer' in list(r1OMYvp0ViTG.keys()):
				g3N0Zr7DfuLteEqSzbcYM6lnKJWmB.append([r1OMYvp0ViTG,url,'3::0::0::0'])
	return o1BCv3HinkmlSA6qdbDK8QxjacXt,hGpdZD3aFgu8r9zOToN572K,g3N0Zr7DfuLteEqSzbcYM6lnKJWmB,NBRFGsxvPIZW10twrlYEUOydj
def Kz8SmoEcWig1nNItZR7v2Udh0GlO(yuli6EPZXAq03m5YoQFCV,o1BCv3HinkmlSA6qdbDK8QxjacXt,url,I5ycituE8YxBLn):
	level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = I5ycituE8YxBLn.split('::')
	TIK6UbCFHmWd4s5DJS,v6vA3Cl1V0DJYgBHPNayoWL = [],[]
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['reelShelfRenderer']['items']")
	TIK6UbCFHmWd4s5DJS.append("yeee["+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	TIK6UbCFHmWd4s5DJS.append("yeee")
	i30CZqmtpjIskrYSDvGVg7,PQ34ogxbIzCMd1wsXE8U70jt5m,Q3O4zNdAMrfsvV96 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(o1BCv3HinkmlSA6qdbDK8QxjacXt,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
	if level=='3' and i30CZqmtpjIskrYSDvGVg7:
		if len(PQ34ogxbIzCMd1wsXE8U70jt5m)>0:
			for MeDOXJmjA87lkLfn in range(len(PQ34ogxbIzCMd1wsXE8U70jt5m)):
				CYQDmvEFh2wuSAdaG = str(MeDOXJmjA87lkLfn)
				TIK6UbCFHmWd4s5DJS = []
				TIK6UbCFHmWd4s5DJS.append("yfff["+CYQDmvEFh2wuSAdaG+"]['richItemRenderer']['content']")
				TIK6UbCFHmWd4s5DJS.append("yfff["+CYQDmvEFh2wuSAdaG+"]['gameCardRenderer']['game']")
				TIK6UbCFHmWd4s5DJS.append("yfff["+CYQDmvEFh2wuSAdaG+"]['itemSectionRenderer']['contents'][0]")
				TIK6UbCFHmWd4s5DJS.append("yfff["+CYQDmvEFh2wuSAdaG+"]")
				TIK6UbCFHmWd4s5DJS.append("yfff")
				oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,r1OMYvp0ViTG,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(PQ34ogxbIzCMd1wsXE8U70jt5m,Zg9FeADE84jSRIvPCrzYulw3sL,TIK6UbCFHmWd4s5DJS)
				if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: v6vA3Cl1V0DJYgBHPNayoWL.append([r1OMYvp0ViTG,url,'4::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG])
	return PQ34ogxbIzCMd1wsXE8U70jt5m,i30CZqmtpjIskrYSDvGVg7,v6vA3Cl1V0DJYgBHPNayoWL,Q3O4zNdAMrfsvV96
def Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,y9yjOtLpFC7kNXn):
	yuli6EPZXAq03m5YoQFCV,YswlgoudyzkW8hARTP09tDG16a = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	wiZYdQSsxVnXAMemcUhFCt7J,YswlgoudyzkW8hARTP09tDG16a = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	o1BCv3HinkmlSA6qdbDK8QxjacXt,YswlgoudyzkW8hARTP09tDG16a = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	PQ34ogxbIzCMd1wsXE8U70jt5m,YswlgoudyzkW8hARTP09tDG16a = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg = uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a
	count = len(y9yjOtLpFC7kNXn)
	for OEJ3PT81KtbZ in range(count):
		try:
			PSBDMWlY6NQ1JbthzsEA28jrny = eval(y9yjOtLpFC7kNXn[OEJ3PT81KtbZ])
			return True,PSBDMWlY6NQ1JbthzsEA28jrny,OEJ3PT81KtbZ+1
		except: pass
	return False,Zg9FeADE84jSRIvPCrzYulw3sL,0
def mbzIyKNqMVt0FQeOsPWc(url,I5ycituE8YxBLn=Zg9FeADE84jSRIvPCrzYulw3sL,data=Zg9FeADE84jSRIvPCrzYulw3sL):
	dAVf07xhMDygk13neCGKZIrt,g3N0Zr7DfuLteEqSzbcYM6lnKJWmB,v6vA3Cl1V0DJYgBHPNayoWL = [],[],[]
	if '::' not in I5ycituE8YxBLn: I5ycituE8YxBLn = '1::0::0::0'
	level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = I5ycituE8YxBLn.split('::')
	if level=='4': level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = '1',KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG
	data = data.replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,yuli6EPZXAq03m5YoQFCV,mrn4jdBuXKIw7N2lvh = Zy7Ic8LBx6V(url,data)
	I5ycituE8YxBLn = level+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
	if level in ['1','2','3']:
		wiZYdQSsxVnXAMemcUhFCt7J,l98atBZhpA,dAVf07xhMDygk13neCGKZIrt,yRWQvnYJ5idpMhP9 = aabxETQSZ8YCUBJ(yuli6EPZXAq03m5YoQFCV,url,I5ycituE8YxBLn)
		if not l98atBZhpA: return
		bsqTpV4OQjJczKkWXoUl2AwMn5u0I = len(dAVf07xhMDygk13neCGKZIrt)
		if bsqTpV4OQjJczKkWXoUl2AwMn5u0I<2:
			if level=='1': level = '2'
			dAVf07xhMDygk13neCGKZIrt = []
	I5ycituE8YxBLn = level+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
	if level in ['2','3']:
		o1BCv3HinkmlSA6qdbDK8QxjacXt,hGpdZD3aFgu8r9zOToN572K,g3N0Zr7DfuLteEqSzbcYM6lnKJWmB,NBRFGsxvPIZW10twrlYEUOydj = Xixt2EoVmOqvARfnjzhJrWs(yuli6EPZXAq03m5YoQFCV,wiZYdQSsxVnXAMemcUhFCt7J,url,I5ycituE8YxBLn)
		if not hGpdZD3aFgu8r9zOToN572K: return
		NLDvlhU49deiaEKz3 = len(g3N0Zr7DfuLteEqSzbcYM6lnKJWmB)
		if NLDvlhU49deiaEKz3<2:
			if level=='2': level = '3'
			g3N0Zr7DfuLteEqSzbcYM6lnKJWmB = []
	I5ycituE8YxBLn = level+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
	if level in ['3']:
		PQ34ogxbIzCMd1wsXE8U70jt5m,i30CZqmtpjIskrYSDvGVg7,v6vA3Cl1V0DJYgBHPNayoWL,Q3O4zNdAMrfsvV96 = Kz8SmoEcWig1nNItZR7v2Udh0GlO(yuli6EPZXAq03m5YoQFCV,o1BCv3HinkmlSA6qdbDK8QxjacXt,url,I5ycituE8YxBLn)
		if not i30CZqmtpjIskrYSDvGVg7: return
		YakAPr4jBe = len(v6vA3Cl1V0DJYgBHPNayoWL)
	for r1OMYvp0ViTG,url,I5ycituE8YxBLn in dAVf07xhMDygk13neCGKZIrt+g3N0Zr7DfuLteEqSzbcYM6lnKJWmB+v6vA3Cl1V0DJYgBHPNayoWL:
		ScVZNf7CoTk6PD4A = ujNowMQmCZX5(r1OMYvp0ViTG,url,I5ycituE8YxBLn)
	return
def ujNowMQmCZX5(r1OMYvp0ViTG,url=Zg9FeADE84jSRIvPCrzYulw3sL,I5ycituE8YxBLn=Zg9FeADE84jSRIvPCrzYulw3sL):
	if '::' in I5ycituE8YxBLn: level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = I5ycituE8YxBLn.split('::')
	else: level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = '1','0','0','0'
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ,IVicenQqgr5ECpYFK4PwNZ = p69zNbLrhMJECknqXaics7Pt21(r1OMYvp0ViTG)
	qL8lfNzH5aXv1FmI907nGYtsKUp3 = '/videos?' in yDTPzhEBKVJl7CX81 or '/streams?' in yDTPzhEBKVJl7CX81 or '/playlists?' in yDTPzhEBKVJl7CX81
	LmlWYocwRBTh7KZUjkV1dnO = '/channels?' in yDTPzhEBKVJl7CX81 or '/shorts?' in yDTPzhEBKVJl7CX81
	if qL8lfNzH5aXv1FmI907nGYtsKUp3 or LmlWYocwRBTh7KZUjkV1dnO: yDTPzhEBKVJl7CX81 = url
	qL8lfNzH5aXv1FmI907nGYtsKUp3 = 'watch?v=' not in yDTPzhEBKVJl7CX81 and '/playlist?list=' not in yDTPzhEBKVJl7CX81
	LmlWYocwRBTh7KZUjkV1dnO = '/gaming' not in yDTPzhEBKVJl7CX81  and '/feed/storefront' not in yDTPzhEBKVJl7CX81
	if I5ycituE8YxBLn[0:5]=='3::0::' and qL8lfNzH5aXv1FmI907nGYtsKUp3 and LmlWYocwRBTh7KZUjkV1dnO: yDTPzhEBKVJl7CX81 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in yDTPzhEBKVJl7CX81:
		level,KIRFQSDuUECZA,ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo,CYQDmvEFh2wuSAdaG = '1','0','0','0'
		I5ycituE8YxBLn = Zg9FeADE84jSRIvPCrzYulw3sL
	mrn4jdBuXKIw7N2lvh = Zg9FeADE84jSRIvPCrzYulw3sL
	if '/youtubei/v1/browse' in yDTPzhEBKVJl7CX81 or '/youtubei/v1/search' in yDTPzhEBKVJl7CX81 or '/my_main_page_shorts_link' in url:
		data = yUTYoAgth5iC43uLrdBH.getSetting('av.youtube.data')
		if data.count(':::')==4:
			I0uARYmrbH,key,KKBkbifw0rHsxMO,JzCR5e4cNODUlSwhryx,dkKX8zLCs6yqBlD7Y5geZEpAicua20 = data.split(':::')
			mrn4jdBuXKIw7N2lvh = I0uARYmrbH+':::'+key+':::'+KKBkbifw0rHsxMO+':::'+JzCR5e4cNODUlSwhryx+':::'+IVicenQqgr5ECpYFK4PwNZ
			if '/my_main_page_shorts_link' in url and not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = url
			else: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?key='+key
	if not title:
		global DtUJ5dBK4ALqvlGEykm2a
		DtUJ5dBK4ALqvlGEykm2a += 1
		title = 'فيديوهات '+str(DtUJ5dBK4ALqvlGEykm2a)
		I5ycituE8YxBLn = '3'+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
	if not oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: return False
	elif 'searchPyvRenderer' in str(r1OMYvp0ViTG): return False
	elif '/about' in yDTPzhEBKVJl7CX81: return False
	elif '/community' in yDTPzhEBKVJl7CX81: return False
	elif 'continuationItemRenderer' in list(r1OMYvp0ViTG.keys()) or 'continuationCommand' in list(r1OMYvp0ViTG.keys()):
		if int(level)>1: level = str(int(level)-1)
		I5ycituE8YxBLn = level+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+':: '+'صفحة أخرى',yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn,mrn4jdBuXKIw7N2lvh)
	elif '/search' in yDTPzhEBKVJl7CX81:
		title = ':: '+title
		I5ycituE8YxBLn = '3'+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
		url = url.replace('/search',Zg9FeADE84jSRIvPCrzYulw3sL)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,145,Zg9FeADE84jSRIvPCrzYulw3sL,I5ycituE8YxBLn,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not yDTPzhEBKVJl7CX81:
		I5ycituE8YxBLn = '3'+'::'+KIRFQSDuUECZA+'::'+ZBKaRA04sIP8TwLk1jbWJ9N3Ogvo+'::'+CYQDmvEFh2wuSAdaG
		title = ':: '+title
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn,mrn4jdBuXKIw7N2lvh)
	elif '/browse' in yDTPzhEBKVJl7CX81 and url==qfzHe2Yr49:
		title = ':: '+title
		I5ycituE8YxBLn = '2::0::0::0'
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn,mrn4jdBuXKIw7N2lvh)
	elif not yDTPzhEBKVJl7CX81 and 'horizontalMovieListRenderer' in str(r1OMYvp0ViTG):
		title = ':: '+title
		I5ycituE8YxBLn = '3::0::0::0'
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn)
	elif 'messageRenderer' in str(r1OMYvp0ViTG):
		A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+title,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	elif TEXIUNJc7iyHKkav94rmZQW:
		A9Z3Ci2PQhFUwBXvI('live',j0jSEdTPJuG4XNvfpO+TEXIUNJc7iyHKkav94rmZQW+title,yDTPzhEBKVJl7CX81,143,W8KBRzkdhlCxvF5sY2T)
	elif '/playlist?list=' in yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('&playnext=1',Zg9FeADE84jSRIvPCrzYulw3sL)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'LIST'+count+':  '+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn)
	elif '/shorts/' in yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&list=',1)[0]
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,143,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	elif '/watch?v=' in yDTPzhEBKVJl7CX81:
		if '&list=' in yDTPzhEBKVJl7CX81 and count:
			iiyTIU3vuegMr = yDTPzhEBKVJl7CX81.split('&list=',1)[1]
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/playlist?list='+iiyTIU3vuegMr
			I5ycituE8YxBLn = '1::0::0::0'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'LIST'+count+':  '+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn)
		else:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&list=',1)[0]
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,143,W8KBRzkdhlCxvF5sY2T,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	elif '/channel/' in yDTPzhEBKVJl7CX81 or '/c/' in yDTPzhEBKVJl7CX81 or ('/@' in yDTPzhEBKVJl7CX81 and yDTPzhEBKVJl7CX81.count('/')==3):
		if HByjTem6EJP5sZb:
			title = title.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).encode('raw_unicode_escape')
			title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'CHNL'+count+':  '+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn)
	elif '/user/' in yDTPzhEBKVJl7CX81:
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'USER'+count+':  '+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn)
	else:
		if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = url
		title = ':: '+title
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,144,W8KBRzkdhlCxvF5sY2T,I5ycituE8YxBLn,mrn4jdBuXKIw7N2lvh)
	return True
def p69zNbLrhMJECknqXaics7Pt21(r1OMYvp0ViTG):
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ,dkKX8zLCs6yqBlD7Y5geZEpAicua20 = False,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if not isinstance(r1OMYvp0ViTG,dict): return oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ,dkKX8zLCs6yqBlD7Y5geZEpAicua20
	for UQ5w87jKFg3xfZB24 in list(r1OMYvp0ViTG.keys()):
		X7ALVcTWiZrvyDlEuSKwB0O9Qjeg = r1OMYvp0ViTG[UQ5w87jKFg3xfZB24]
		if isinstance(X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,dict): break
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['header']['richListHeaderRenderer']['title']")
	TIK6UbCFHmWd4s5DJS.append("yrender['headline']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['unplayableText']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['formattedTitle']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['title']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['title']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("yrender['text']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['text']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("yrender['title']['content']")
	TIK6UbCFHmWd4s5DJS.append("yrender['title']")
	TIK6UbCFHmWd4s5DJS.append("item['title']")
	TIK6UbCFHmWd4s5DJS.append("item['reelWatchEndpoint']['videoId']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,title,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	TIK6UbCFHmWd4s5DJS.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	TIK6UbCFHmWd4s5DJS.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	TIK6UbCFHmWd4s5DJS.append("item['commandMetadata']['webCommandMetadata']['url']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,yDTPzhEBKVJl7CX81,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnail']['thumbnails'][0]['url']")
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	TIK6UbCFHmWd4s5DJS.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,W8KBRzkdhlCxvF5sY2T,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("yrender['videoCountShortText']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['videoCountText']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("yrender['videoCount']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,count,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['lengthText']['simpleText']")
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	TIK6UbCFHmWd4s5DJS.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,NAdtOanYBmF0IWbMvXxz7lERiTjo,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	TIK6UbCFHmWd4s5DJS = []
	TIK6UbCFHmWd4s5DJS.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	TIK6UbCFHmWd4s5DJS.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,dkKX8zLCs6yqBlD7Y5geZEpAicua20,hxEOR0DB6rPG9ky5itpoausvwYFJ4 = Uga5IkeNHiA8LyDsEFfvZOK1wu2Pc3(r1OMYvp0ViTG,X7ALVcTWiZrvyDlEuSKwB0O9Qjeg,TIK6UbCFHmWd4s5DJS)
	if 'LIVE' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW = Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE:  '
	if 'مباشر' in NAdtOanYBmF0IWbMvXxz7lERiTjo: NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW = Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE:  '
	if 'badges' in list(X7ALVcTWiZrvyDlEuSKwB0O9Qjeg.keys()):
		JWedSOVDfHFmzPCl4jIiv9MK5Y8 = str(X7ALVcTWiZrvyDlEuSKwB0O9Qjeg['badges'])
		if 'Free with Ads' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$:  '
		if 'LIVE' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: TEXIUNJc7iyHKkav94rmZQW = 'LIVE:  '
		if 'Buy' in JWedSOVDfHFmzPCl4jIiv9MK5Y8 or 'Rent' in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:  '
		if nWsGkOX74PMJ(u'مباشر') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: TEXIUNJc7iyHKkav94rmZQW = 'LIVE:  '
		if nWsGkOX74PMJ(u'شراء') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:  '
		if nWsGkOX74PMJ(u'استئجار') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$$:  '
		if nWsGkOX74PMJ(u'إعلانات') in JWedSOVDfHFmzPCl4jIiv9MK5Y8: sQ1LAcp3TKzZry9i27ovuMGND4HgfJ = '$:  '
	yDTPzhEBKVJl7CX81 = uumhMi6O4pk7Gjd5aTQqy2Z(yDTPzhEBKVJl7CX81)
	if yDTPzhEBKVJl7CX81 and 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
	W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.split('?')[0]
	if  W8KBRzkdhlCxvF5sY2T and 'http' not in W8KBRzkdhlCxvF5sY2T: W8KBRzkdhlCxvF5sY2T = 'https:'+W8KBRzkdhlCxvF5sY2T
	title = uumhMi6O4pk7Gjd5aTQqy2Z(title)
	if sQ1LAcp3TKzZry9i27ovuMGND4HgfJ: title = sQ1LAcp3TKzZry9i27ovuMGND4HgfJ+title
	NAdtOanYBmF0IWbMvXxz7lERiTjo = NAdtOanYBmF0IWbMvXxz7lERiTjo.replace(',',Zg9FeADE84jSRIvPCrzYulw3sL)
	count = count.replace(',',Zg9FeADE84jSRIvPCrzYulw3sL)
	count = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\d+',count)
	if count: count = count[0]
	else: count = Zg9FeADE84jSRIvPCrzYulw3sL
	return True,title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,count,NAdtOanYBmF0IWbMvXxz7lERiTjo,TEXIUNJc7iyHKkav94rmZQW,sQ1LAcp3TKzZry9i27ovuMGND4HgfJ,dkKX8zLCs6yqBlD7Y5geZEpAicua20
def Zy7Ic8LBx6V(url,data=Zg9FeADE84jSRIvPCrzYulw3sL,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	if YYAz8aPFGR2n==Zg9FeADE84jSRIvPCrzYulw3sL: YYAz8aPFGR2n = 'ytInitialData'
	qoCMENGx4WgKp = lAfzvsbYy7oQ3r28EMe()
	Y3OmVPp2ARgBCjn = {'User-Agent':qoCMENGx4WgKp,'Cookie':'PREF=hl=ar'}
	global yUTYoAgth5iC43uLrdBH
	if not data: data = yUTYoAgth5iC43uLrdBH.getSetting('av.youtube.data')
	if data.count(':::')==4: I0uARYmrbH,key,KKBkbifw0rHsxMO,JzCR5e4cNODUlSwhryx,dkKX8zLCs6yqBlD7Y5geZEpAicua20 = data.split(':::')
	else: I0uARYmrbH,key,KKBkbifw0rHsxMO,JzCR5e4cNODUlSwhryx,dkKX8zLCs6yqBlD7Y5geZEpAicua20 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	mrn4jdBuXKIw7N2lvh = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":KKBkbifw0rHsxMO}}}
	if url==qfzHe2Yr49+'/shorts' or '/my_main_page_shorts_link' in url:
		url = qfzHe2Yr49+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		mrn4jdBuXKIw7N2lvh['sequenceParams'] = I0uARYmrbH
		mrn4jdBuXKIw7N2lvh = str(mrn4jdBuXKIw7N2lvh)
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = qfzHe2Yr49+'/youtubei/v1/guide?key='+key
		mrn4jdBuXKIw7N2lvh = str(mrn4jdBuXKIw7N2lvh)
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and I0uARYmrbH:
		mrn4jdBuXKIw7N2lvh['continuation'] = dkKX8zLCs6yqBlD7Y5geZEpAicua20
		mrn4jdBuXKIw7N2lvh['context']['client']['visitorData'] = I0uARYmrbH
		mrn4jdBuXKIw7N2lvh = str(mrn4jdBuXKIw7N2lvh)
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and JzCR5e4cNODUlSwhryx:
		Y3OmVPp2ARgBCjn.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':KKBkbifw0rHsxMO})
		Y3OmVPp2ARgBCjn.update({'Cookie':'VISITOR_INFO1_LIVE='+JzCR5e4cNODUlSwhryx})
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'YOUTUBE-GET_PAGE_DATA-6th')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"innertubeApiKey".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if OQ1FgC3a5ZLX4unm7Ebx8ji: key = OQ1FgC3a5ZLX4unm7Ebx8ji[0]
	OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"cver".*?"value".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if OQ1FgC3a5ZLX4unm7Ebx8ji: KKBkbifw0rHsxMO = OQ1FgC3a5ZLX4unm7Ebx8ji[0]
	OQ1FgC3a5ZLX4unm7Ebx8ji = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"visitorData".*?"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.I)
	if OQ1FgC3a5ZLX4unm7Ebx8ji: I0uARYmrbH = OQ1FgC3a5ZLX4unm7Ebx8ji[0]
	cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): JzCR5e4cNODUlSwhryx = cookies['VISITOR_INFO1_LIVE']
	a8ayG4wjQhRPdF3Os = I0uARYmrbH+':::'+key+':::'+KKBkbifw0rHsxMO+':::'+JzCR5e4cNODUlSwhryx+':::'+dkKX8zLCs6yqBlD7Y5geZEpAicua20
	if YYAz8aPFGR2n=='ytInitialData' and 'ytInitialData' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('window\["ytInitialData"\] = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not KHErs7vLe0CUQ6wXBnNpz1iohfkg4: KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var ytInitialData = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',KHErs7vLe0CUQ6wXBnNpz1iohfkg4[0])
	elif YYAz8aPFGR2n=='ytInitialGuideData' and 'ytInitialGuideData' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		KHErs7vLe0CUQ6wXBnNpz1iohfkg4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var ytInitialGuideData = ({.*?});',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',KHErs7vLe0CUQ6wXBnNpz1iohfkg4[0])
	elif '</script>' not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: K0Hn1gbiTqGLEt = JGmfjhoyKZUl('str',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	else: K0Hn1gbiTqGLEt = Zg9FeADE84jSRIvPCrzYulw3sL
	if 0:
		yuli6EPZXAq03m5YoQFCV = str(K0Hn1gbiTqGLEt)
		if GGfPQnrJKEqMv2ZVxdD: yuli6EPZXAq03m5YoQFCV = yuli6EPZXAq03m5YoQFCV.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open('S:\\0000emad.dat','wb').write(yuli6EPZXAq03m5YoQFCV)
	yUTYoAgth5iC43uLrdBH.setSetting('av.youtube.data',a8ayG4wjQhRPdF3Os)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,K0Hn1gbiTqGLEt,a8ayG4wjQhRPdF3Os
def FlAhOu94bM0(url,I5ycituE8YxBLn):
	search = EnxNsqevtM28mpkZ5RG0()
	if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	hc5ePKxl4LJvEjDgTm = url+'/search?query='+search
	mbzIyKNqMVt0FQeOsPWc(hc5ePKxl4LJvEjDgTm,I5ycituE8YxBLn)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in NNYRDot8vC: vjCZJNa4kXpt6IPWYDuf = '&sp=EgIQAg%253D%253D'
		else: vjCZJNa4kXpt6IPWYDuf = Zg9FeADE84jSRIvPCrzYulw3sL
		JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+vjCZJNa4kXpt6IPWYDuf
	else:
		NNupnIw4g9ByUtHSJOeL,M8qodsbQklm3hR1tiOa0jYUIX29ev,wUpHn5IfzaQ8g4j = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
		eZhipVABmx3HqsM9F = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		COutq01MLJ65nPd7fNgGoE = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		usM4AonktOcXFwedJyZ0B1lP2 = WXZLgSfpV2jzRFTNiyroc('اختر البحث المناسب',eZhipVABmx3HqsM9F)
		if usM4AonktOcXFwedJyZ0B1lP2 == -1: return
		D2dMz7KX9hUpHsg0Txvuen = COutq01MLJ65nPd7fNgGoE[usM4AonktOcXFwedJyZ0B1lP2]
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,f4hGlHiK3uMxwUg62o9J,data = Zy7Ic8LBx6V(hc5ePKxl4LJvEjDgTm+D2dMz7KX9hUpHsg0Txvuen)
		if f4hGlHiK3uMxwUg62o9J:
			try:
				SQkWUPdDbyaYs532uX = f4hGlHiK3uMxwUg62o9J['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for WrqsI7kQ3GZiTzFBd2HKL in range(len(SQkWUPdDbyaYs532uX)):
					group = SQkWUPdDbyaYs532uX[WrqsI7kQ3GZiTzFBd2HKL]['searchFilterGroupRenderer']['filters']
					for ilQ9oXS1jTFVU28 in range(len(group)):
						X7ALVcTWiZrvyDlEuSKwB0O9Qjeg = group[ilQ9oXS1jTFVU28]['searchFilterRenderer']
						if 'navigationEndpoint' in list(X7ALVcTWiZrvyDlEuSKwB0O9Qjeg.keys()):
							yDTPzhEBKVJl7CX81 = X7ALVcTWiZrvyDlEuSKwB0O9Qjeg['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\u0026','&')
							title = X7ALVcTWiZrvyDlEuSKwB0O9Qjeg['tooltip']
							title = title.replace('البحث عن ',Zg9FeADE84jSRIvPCrzYulw3sL)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								wUpHn5IfzaQ8g4j = title
								WOry7DZPocFhH8p4 = yDTPzhEBKVJl7CX81
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',Zg9FeADE84jSRIvPCrzYulw3sL)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								wUpHn5IfzaQ8g4j = title
								WOry7DZPocFhH8p4 = yDTPzhEBKVJl7CX81
							if 'Sort by' in title: continue
							NNupnIw4g9ByUtHSJOeL.append(uumhMi6O4pk7Gjd5aTQqy2Z(title))
							M8qodsbQklm3hR1tiOa0jYUIX29ev.append(yDTPzhEBKVJl7CX81)
			except: pass
		if not wUpHn5IfzaQ8g4j: Ny32JuHp8SzGUjeR9WidLaEBlYhVZ = Zg9FeADE84jSRIvPCrzYulw3sL
		else:
			NNupnIw4g9ByUtHSJOeL = ['بدون فلتر',wUpHn5IfzaQ8g4j]+NNupnIw4g9ByUtHSJOeL
			M8qodsbQklm3hR1tiOa0jYUIX29ev = [Zg9FeADE84jSRIvPCrzYulw3sL,WOry7DZPocFhH8p4]+M8qodsbQklm3hR1tiOa0jYUIX29ev
			xyFTQnSOXljMp97W4RYG8t0bzreAmL = WXZLgSfpV2jzRFTNiyroc('موقع يوتيوب - اختر الفلتر',NNupnIw4g9ByUtHSJOeL)
			if xyFTQnSOXljMp97W4RYG8t0bzreAmL == -1: return
			Ny32JuHp8SzGUjeR9WidLaEBlYhVZ = M8qodsbQklm3hR1tiOa0jYUIX29ev[xyFTQnSOXljMp97W4RYG8t0bzreAmL]
		if Ny32JuHp8SzGUjeR9WidLaEBlYhVZ: JaqiYfEglZDvmwQNS8zR = qfzHe2Yr49+Ny32JuHp8SzGUjeR9WidLaEBlYhVZ
		elif D2dMz7KX9hUpHsg0Txvuen: JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+D2dMz7KX9hUpHsg0Txvuen
		else: JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm
	mbzIyKNqMVt0FQeOsPWc(JaqiYfEglZDvmwQNS8zR)
	return
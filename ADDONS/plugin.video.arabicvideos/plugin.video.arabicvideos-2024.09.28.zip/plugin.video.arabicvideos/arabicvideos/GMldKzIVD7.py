# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'ALKAWTHAR'
j0jSEdTPJuG4XNvfpO = '_KWT_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,wlxviMOuNeQVct4ULsCEHXZm6yR2p,text):
	if   mode==130: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==131: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	elif mode==132: CsaNhTtGm8 = hj3nmoDds5i679V2qKRN1vBMpAS8(url)
	elif mode==133: CsaNhTtGm8 = dHjny9tTucrO(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==134: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==135: CsaNhTtGm8 = nHNoV6BMsIPWhxt2FKC()
	elif mode==139: CsaNhTtGm8 = KkZtb4lhPd(text,url)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,139,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-MENU-1st')
	HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('dropdown-menu(.*?)dropdown-toggle',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[1]
	items=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if '/conductor' in yDTPzhEBKVJl7CX81: continue
		title = title.strip(wjs26GpVfNiCUERHJ)
		url = qfzHe2Yr49+yDTPzhEBKVJl7CX81
		if '/category/' in url: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,132)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,131)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المسلسلات',qfzHe2Yr49+'/category/543',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الأفلام',qfzHe2Yr49+'/category/628',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'برامج الصغار والشباب',qfzHe2Yr49+'/category/517',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'ابرز البرامج',qfzHe2Yr49+'/category/1763',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المحاضرات',qfzHe2Yr49+'/category/943',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'عاشوراء',qfzHe2Yr49+'/category/1353',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'البرامج الاجتماعية',qfzHe2Yr49+'/category/501',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'البرامج الدينية',qfzHe2Yr49+'/category/509',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'البرامج الوثائقية',qfzHe2Yr49+'/category/553',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'البرامج السياسية',qfzHe2Yr49+'/category/545',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'كتب',qfzHe2Yr49+'/category/291',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'تعلم الفارسية',qfzHe2Yr49+'/category/88',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'أرشيف البرامج',qfzHe2Yr49+'/category/1279',132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	return
def mbzIyKNqMVt0FQeOsPWc(url):
	vcAfrsTaPDVyIque9ME7B4QNH2kLRt = ['/religious','/social','/political','/films','/series']
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-TITLES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('titlebar(.*?)titlebar',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if any(B251BPiLbvG9UxszKtlI7YQHmoWw in url for B251BPiLbvG9UxszKtlI7YQHmoWw in vcAfrsTaPDVyIque9ME7B4QNH2kLRt):
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + yDTPzhEBKVJl7CX81
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,133,W8KBRzkdhlCxvF5sY2T,'1')
	elif '/docs' in url:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,title,yDTPzhEBKVJl7CX81 in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + yDTPzhEBKVJl7CX81
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,133,W8KBRzkdhlCxvF5sY2T,'1')
	return
def hj3nmoDds5i679V2qKRN1vBMpAS8(url):
	WWdHIOCPeKmgRstXk4c = url.split('/')[-1]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-CATEGORIES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('parentcat(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f:
		dHjny9tTucrO(url,'1')
		return
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href='(.*?)'.*?>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		title = title.strip(wjs26GpVfNiCUERHJ)
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,132,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
	return
def dHjny9tTucrO(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-EPISODES-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('totalpagecount=[\'"](.*?)[\'"]',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items:
		url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="news-detail-body".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,url,134)
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	QUnJe05ghYEBfjN8Ho = int(items[0])
	name = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('main-title.*?</a> >(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if name: name = name[0].strip(wjs26GpVfNiCUERHJ)
	else: name = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		WWdHIOCPeKmgRstXk4c = url.split('/')[-1]
		if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49 + '/category/' + WWdHIOCPeKmgRstXk4c + '/' + wlxviMOuNeQVct4ULsCEHXZm6yR2p
		CNhQcnS0dI6UFjbvLoyx = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-EPISODES-2nd')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('currentpagenumber(.*?)pagination',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,type,yDTPzhEBKVJl7CX81,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',Zg9FeADE84jSRIvPCrzYulw3sL)
			title = title.strip(wjs26GpVfNiCUERHJ)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49 + yDTPzhEBKVJl7CX81
			if WWdHIOCPeKmgRstXk4c=='628': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,133,W8KBRzkdhlCxvF5sY2T,'1')
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,134,W8KBRzkdhlCxvF5sY2T)
	elif '/episode/' in url:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('playlist(.*?)col-md-12',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
				title = title.strip(wjs26GpVfNiCUERHJ)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,134,W8KBRzkdhlCxvF5sY2T)
		elif '/category/628' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
				title = '_MOD_' + 'ملف التشغيل'
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,url,134)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="Categories.*?href=\'(.*?)\'',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			WWdHIOCPeKmgRstXk4c = items[0].split('/')[-1]
			url = qfzHe2Yr49 + '/category/' + WWdHIOCPeKmgRstXk4c
			hj3nmoDds5i679V2qKRN1vBMpAS8(url)
			return
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		llMH1EuRFPrIZkbVWgXy = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in llMH1EuRFPrIZkbVWgXy:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('&amp;','&')
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,133)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	if '/news/' in url or '/episode/' in url:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-PLAY-1st')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("mobilevideopath.*?value='(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items: url = items[0]
	nTdpZOCUe7l(url,bIPsOxjEpoH,'video')
	return
def nHNoV6BMsIPWhxt2FKC():
	url = qfzHe2Yr49+'/live'
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-LIVE-1st')
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('live-container.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[0]
	Y3OmVPp2ARgBCjn = {'Referer':qfzHe2Yr49}
	zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALKAWTHAR-LIVE-2nd')
	CNhQcnS0dI6UFjbvLoyx = zCDbxZtwOE6.content
	dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('csrf-token" content="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	dkKX8zLCs6yqBlD7Y5geZEpAicua20 = dkKX8zLCs6yqBlD7Y5geZEpAicua20[0]
	h3jl1RYSbPitZo792E6dTz = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,'url')
	JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("playUrl = '(.*?)'",CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	JaqiYfEglZDvmwQNS8zR = h3jl1RYSbPitZo792E6dTz+JaqiYfEglZDvmwQNS8zR[0]
	Ne4k6g70sUroCTiSVQ = {'X-CSRF-TOKEN':dkKX8zLCs6yqBlD7Y5geZEpAicua20}
	PPnXgJjB8cedw9YG5a2txu = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,Ne4k6g70sUroCTiSVQ,False,True,'ALKAWTHAR-LIVE-3rd')
	rTnGBeHzo9RV84NvmjsfI6EyAuX5YF = PPnXgJjB8cedw9YG5a2txu.content
	N2dklZ3LF7DEe = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(.*?)"',rTnGBeHzo9RV84NvmjsfI6EyAuX5YF,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	N2dklZ3LF7DEe = N2dklZ3LF7DEe[0].replace('\/','/')
	nTdpZOCUe7l(N2dklZ3LF7DEe,bIPsOxjEpoH,'live')
	return
def KkZtb4lhPd(search,url=Zg9FeADE84jSRIvPCrzYulw3sL):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if url==Zg9FeADE84jSRIvPCrzYulw3sL:
		if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
		if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
		search = OJYiDeyvSPTNI9(search)
		url = qfzHe2Yr49+'/search?q='+search
		dHjny9tTucrO(url,Zg9FeADE84jSRIvPCrzYulw3sL)
		return
# -*- coding: utf-8 -*-
from V1VREBsj92 import *
d1AeaJNg4IXzTv6ER0nicLUrf = 'M3U'
XZCQDjv9WNEA2SPdB3cTObaMI7qxl0 = '_M3U_'
lA6cxNd9HkqmeR = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
OORhF2IYc1ZurfLn = 4
def ut1mDygn8U6fzQhaMrBYK9l(LfnWDFgRdJH4lZvt7yo28N,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG,RR5KdNtJEBT,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP,puVFor385ci9gvjUDnflEXqmJ7wPN):
	global XZCQDjv9WNEA2SPdB3cTObaMI7qxl0
	try:
		g5gJiUkIKOqRBj = str(puVFor385ci9gvjUDnflEXqmJ7wPN['folder'])
		XZCQDjv9WNEA2SPdB3cTObaMI7qxl0 = '_MU'+g5gJiUkIKOqRBj+'_'
	except: g5gJiUkIKOqRBj = Zg9FeADE84jSRIvPCrzYulw3sL
	try: XyE5GFSoQsxDVwAu = str(puVFor385ci9gvjUDnflEXqmJ7wPN['sequence'])
	except: XyE5GFSoQsxDVwAu = Zg9FeADE84jSRIvPCrzYulw3sL
	if   LfnWDFgRdJH4lZvt7yo28N==710: x3HQ4Fyra7dZjWcJsvCPUmAT = auimz9OUkxCP()
	elif LfnWDFgRdJH4lZvt7yo28N==711: x3HQ4Fyra7dZjWcJsvCPUmAT = kC2z7EYmpJb0a(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu)
	elif LfnWDFgRdJH4lZvt7yo28N==712: x3HQ4Fyra7dZjWcJsvCPUmAT = sO1NzKoRHmVY2BwySJGc5kCupv(g5gJiUkIKOqRBj)
	elif LfnWDFgRdJH4lZvt7yo28N==713: x3HQ4Fyra7dZjWcJsvCPUmAT = UUzCA532dhqKblQoYgJs(g5gJiUkIKOqRBj,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP)
	elif LfnWDFgRdJH4lZvt7yo28N==714: x3HQ4Fyra7dZjWcJsvCPUmAT = yfWYTB58bDO(g5gJiUkIKOqRBj,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP)
	elif LfnWDFgRdJH4lZvt7yo28N==715: x3HQ4Fyra7dZjWcJsvCPUmAT = npRzZYjSm35wucxNPFlsTibVJeqI(g5gJiUkIKOqRBj,tUHrEcLYK30N,RR5KdNtJEBT)
	elif LfnWDFgRdJH4lZvt7yo28N==716: x3HQ4Fyra7dZjWcJsvCPUmAT = uUtFWOksGxAHTz7ejw2oEd5(g5gJiUkIKOqRBj,True)
	elif LfnWDFgRdJH4lZvt7yo28N==717: x3HQ4Fyra7dZjWcJsvCPUmAT = wRYQPfobqUD0N9(g5gJiUkIKOqRBj,True)
	elif LfnWDFgRdJH4lZvt7yo28N==718: x3HQ4Fyra7dZjWcJsvCPUmAT = Rk76gYXSlq9uordaP3ZfDbLCJBhT(g5gJiUkIKOqRBj,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==719: x3HQ4Fyra7dZjWcJsvCPUmAT = kkjBRKDdmEAuncTUShs1M2GrC6g3(Tbwq7kJ4vRSNVyUFcdMzirG,g5gJiUkIKOqRBj,tUHrEcLYK30N,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP)
	elif LfnWDFgRdJH4lZvt7yo28N==720: x3HQ4Fyra7dZjWcJsvCPUmAT = bbR3FyrsBGSoft(g5gJiUkIKOqRBj,True)
	elif LfnWDFgRdJH4lZvt7yo28N==721: x3HQ4Fyra7dZjWcJsvCPUmAT = o2XWqTVDKrFMPag7JAEIjLnRvG(g5gJiUkIKOqRBj)
	elif LfnWDFgRdJH4lZvt7yo28N==722: x3HQ4Fyra7dZjWcJsvCPUmAT = lgeMsXynBk2UYiQ56F8(g5gJiUkIKOqRBj)
	elif LfnWDFgRdJH4lZvt7yo28N==723: x3HQ4Fyra7dZjWcJsvCPUmAT = CSMz1e7PIbvlXd(g5gJiUkIKOqRBj)
	elif LfnWDFgRdJH4lZvt7yo28N==726: x3HQ4Fyra7dZjWcJsvCPUmAT = zl3rbtZmqKDYQOFGs6h09kRv7X(g5gJiUkIKOqRBj)
	elif LfnWDFgRdJH4lZvt7yo28N==729: x3HQ4Fyra7dZjWcJsvCPUmAT = hCb2JBrT8wVQ(Tbwq7kJ4vRSNVyUFcdMzirG,g5gJiUkIKOqRBj,tUHrEcLYK30N,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP)
	else: x3HQ4Fyra7dZjWcJsvCPUmAT = False
	return x3HQ4Fyra7dZjWcJsvCPUmAT
def auimz9OUkxCP():
	for g5gJiUkIKOqRBj in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
		XZCQDjv9WNEA2SPdB3cTObaMI7qxl0 = '_MU'+str(g5gJiUkIKOqRBj)+'_'
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قائمة مجلد '+YOjp8EZx4D[g5gJiUkIKOqRBj],Zg9FeADE84jSRIvPCrzYulw3sL,720,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	return
def bbR3FyrsBGSoft(g5gJiUkIKOqRBj=Zg9FeADE84jSRIvPCrzYulw3sL,aM2tUZzCX4nNGhBV6DcSF7um=Zg9FeADE84jSRIvPCrzYulw3sL):
	if g5gJiUkIKOqRBj:
		OO6tWYrH0LEnbVdhio = {'folder':g5gJiUkIKOqRBj}
		SShsfX8r2uUAVwQ0zBRMv = Zg9FeADE84jSRIvPCrzYulw3sL
	else:
		OO6tWYrH0LEnbVdhio = Zg9FeADE84jSRIvPCrzYulw3sL
		SShsfX8r2uUAVwQ0zBRMv = Zg9FeADE84jSRIvPCrzYulw3sL
	kDwqIyKnYZdX01xTNr3W = sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um)
	if not kDwqIyKnYZdX01xTNr3W:
		A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+U2bWzwG8VdJsBqtR74ErDi3cg1v+' إضافة وتغيير رابط'+SShsfX8r2uUAVwQ0zBRMv+wjs26GpVfNiCUERHJ+YOjp8EZx4D[1]+' '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,711,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj,'sequence':1})
		A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+U2bWzwG8VdJsBqtR74ErDi3cg1v+' جلب ملفات'+SShsfX8r2uUAVwQ0zBRMv+' '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,712,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	else:
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'بحث في الملفات'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,729,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مصنفة مرتبة'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_GROUPED_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مصنفة من القسم'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_FROM_GROUP_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مصنفة من الاسم'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_FROM_NAME_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مصنفة بلا ترتيب'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_GROUPED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات بلا ترتيب'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_ORIGINAL_GROUPED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مجهولة مرتبة'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_UNKNOWN_GROUPED_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'قنوات مجهولة بلا ترتيب'+SShsfX8r2uUAVwQ0zBRMv,'LIVE_UNKNOWN_GROUPED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'فيديوهات بلا ترتيب'+SShsfX8r2uUAVwQ0zBRMv,'VOD_ORIGINAL_GROUPED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'فيديوهات مصنفة القسم'+SShsfX8r2uUAVwQ0zBRMv,'VOD_FROM_GROUP_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'فيديوهات مصنفة من الاسم'+SShsfX8r2uUAVwQ0zBRMv,'VOD_FROM_NAME_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'فيديوهات مجهولة بلا ترتيب'+SShsfX8r2uUAVwQ0zBRMv,'VOD_UNKNOWN_GROUPED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'فيديوهات مجهولة مرتبة'+SShsfX8r2uUAVwQ0zBRMv,'VOD_UNKNOWN_GROUPED_SORTED',713,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
		A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'إضافة وتغيير رابط'+SShsfX8r2uUAVwQ0zBRMv+wjs26GpVfNiCUERHJ+YOjp8EZx4D[D0wIcOgK6BJtoEys2U],Zg9FeADE84jSRIvPCrzYulw3sL,711,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj,'sequence':D0wIcOgK6BJtoEys2U})
	A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'جلب ملفات'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,712,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
	A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'مسح ملفات'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,717,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
	A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'عدد فيديوهات'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,721,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
	A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'Referer تغيير'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,726,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
	A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'User-Agent تغيير'+SShsfX8r2uUAVwQ0zBRMv,Zg9FeADE84jSRIvPCrzYulw3sL,723,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OO6tWYrH0LEnbVdhio)
	return
def uUtFWOksGxAHTz7ejw2oEd5(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um=True):
	u4ivWtQRT7oYl6F31MHDc,bKWUm8TSAlhiYD7PIj6JynVC3x = False,Zg9FeADE84jSRIvPCrzYulw3sL
	Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	Uhlg0oRGYds9HOw7TMzJ5N,EEzc9mBObVjvNeyGJZqTrWiRn4f7so,lM8ytp0xNZdSLrEazQFBI95ic,QL2cqIzr0bEWPNdtiYo4JZDvwjXa,iiEWL321NtmRlGb0ZkznJrwMvuI = YH9qy5BJQV(g5gJiUkIKOqRBj)
	if QL2cqIzr0bEWPNdtiYo4JZDvwjXa==Zg9FeADE84jSRIvPCrzYulw3sL: return False,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	z1MkhcyLvUeR0jKGg3t = zwp6FQr1qESsajO(g5gJiUkIKOqRBj)
	if Uhlg0oRGYds9HOw7TMzJ5N:
		t2P8jbfzoXhmWAe = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',Uhlg0oRGYds9HOw7TMzJ5N,Zg9FeADE84jSRIvPCrzYulw3sL,z1MkhcyLvUeR0jKGg3t,False,Zg9FeADE84jSRIvPCrzYulw3sL,'M3U-CHECK_ACCOUNT-1st')
		SfV7RHudvkPDq = t2P8jbfzoXhmWAe.content
		if t2P8jbfzoXhmWAe.succeeded:
			LB8luVrePRpyDsG0ok2WQU7Awi,QdzOwU7Zu9K2X,gNknZrlYBdy8Quc9I6qRx,JJl9AEZ3dgzsG1QW0F4,ixYZ2PsbtQze0TR69jgCcwFaDfyLU = 0,0,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
			try:
				vQNVqXSzl5n3AUOpr6 = JGmfjhoyKZUl('dict',SfV7RHudvkPDq)
				bKWUm8TSAlhiYD7PIj6JynVC3x = vQNVqXSzl5n3AUOpr6['user_info']['status']
				u4ivWtQRT7oYl6F31MHDc = True
				gNknZrlYBdy8Quc9I6qRx = vQNVqXSzl5n3AUOpr6['server_info']['time_now']
			except: pass
			if gNknZrlYBdy8Quc9I6qRx:
				try:
					vvoA3Xw8SYWnHf = LNma2eq3vEguwVtHjn.strptime(gNknZrlYBdy8Quc9I6qRx,'%Y.%m.%d %H:%M:%S')
					LB8luVrePRpyDsG0ok2WQU7Awi = int(LNma2eq3vEguwVtHjn.mktime(vvoA3Xw8SYWnHf))
					QdzOwU7Zu9K2X = int(PPc8zbiVZnFkfXLBRv-LB8luVrePRpyDsG0ok2WQU7Awi)
					QdzOwU7Zu9K2X = int((QdzOwU7Zu9K2X+900)/1800)*1800
				except: pass
				try:
					vvoA3Xw8SYWnHf = LNma2eq3vEguwVtHjn.localtime(int(vQNVqXSzl5n3AUOpr6['user_info']['created_at']))
					JJl9AEZ3dgzsG1QW0F4 = LNma2eq3vEguwVtHjn.strftime('%Y.%m.%d %H:%M:%S',vvoA3Xw8SYWnHf)
				except: pass
				try:
					vvoA3Xw8SYWnHf = LNma2eq3vEguwVtHjn.localtime(int(vQNVqXSzl5n3AUOpr6['user_info']['exp_date']))
					ixYZ2PsbtQze0TR69jgCcwFaDfyLU = LNma2eq3vEguwVtHjn.strftime('%Y.%m.%d %H:%M:%S',vvoA3Xw8SYWnHf)
				except: pass
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.timestamp_'+g5gJiUkIKOqRBj,str(PPc8zbiVZnFkfXLBRv))
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.timediff_'+g5gJiUkIKOqRBj,str(QdzOwU7Zu9K2X))
			try:
				A4XQM8BSP0Y6OtcGI1EjknmVJsouvd = '"server_info":'+SfV7RHudvkPDq.split('"server_info":')[1]
				A4XQM8BSP0Y6OtcGI1EjknmVJsouvd = A4XQM8BSP0Y6OtcGI1EjknmVJsouvd.replace(':',': ').replace(',',', ').replace('}}','}')
				ssFKfBwG4aO6cZHlYzkNCURQprW = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"url": "(.*?)", "port": "(.*?)"',A4XQM8BSP0Y6OtcGI1EjknmVJsouvd,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R = ssFKfBwG4aO6cZHlYzkNCURQprW[0]
			except: u4ivWtQRT7oYl6F31MHDc = False
			if u4ivWtQRT7oYl6F31MHDc and aM2tUZzCX4nNGhBV6DcSF7um:
				max = vQNVqXSzl5n3AUOpr6['user_info']['max_connections']
				v4N9pzVJGA2xUDPS60eYHkEIusf = vQNVqXSzl5n3AUOpr6['user_info']['active_cons']
				BReyNFuWjP0blZmc3TD5vQfoLA7zw = vQNVqXSzl5n3AUOpr6['user_info']['is_trial']
				OrFpgsv5bhLViwH = Uhlg0oRGYds9HOw7TMzJ5N.split('?',1)
				oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'URL:  '+PPQORjT2lc7SVkKwFI4D+Uhlg0oRGYds9HOw7TMzJ5N+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\n\nStatus:  '+PPQORjT2lc7SVkKwFI4D+bKWUm8TSAlhiYD7PIj6JynVC3x+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\nTrial:    '+PPQORjT2lc7SVkKwFI4D+str(BReyNFuWjP0blZmc3TD5vQfoLA7zw=='1')+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\nCreated  At:  '+PPQORjT2lc7SVkKwFI4D+JJl9AEZ3dgzsG1QW0F4+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\nExpiry Date:  '+PPQORjT2lc7SVkKwFI4D+ixYZ2PsbtQze0TR69jgCcwFaDfyLU+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\nConnections   ( Active / Maximum ) :  '+PPQORjT2lc7SVkKwFI4D+v4N9pzVJGA2xUDPS60eYHkEIusf+' / '+max+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\nAllowed Outputs:   '+PPQORjT2lc7SVkKwFI4D+" , ".join(vQNVqXSzl5n3AUOpr6['user_info']['allowed_output_formats'])+u4IRSmrYMKkaHUBnDiLWh
				oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\n\n'+A4XQM8BSP0Y6OtcGI1EjknmVJsouvd
				if bKWUm8TSAlhiYD7PIj6JynVC3x=='Active': eelI82pRmObUdPNsj6tcT3Wx9F('الاشتراك يعمل بدون مشاكل',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
				else: eelI82pRmObUdPNsj6tcT3Wx9F('يبدو أن هناك مشكلة في الاشتراك',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	if Uhlg0oRGYds9HOw7TMzJ5N and u4ivWtQRT7oYl6F31MHDc and bKWUm8TSAlhiYD7PIj6JynVC3x=='Active':
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+Uhlg0oRGYds9HOw7TMzJ5N+' ]')
		Gr0K5RUTIpstSm1wdle7bAxBXHLkVM = True
	else:
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,'Checking M3U URL   [ Does not work ]   [ '+Uhlg0oRGYds9HOw7TMzJ5N+' ]')
		if aM2tUZzCX4nNGhBV6DcSF7um: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		Gr0K5RUTIpstSm1wdle7bAxBXHLkVM = False
	return Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R
def yfWYTB58bDO(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,R9o60qgiHv5uX1kwytSsYmx,tFHbpvdKm5POJryxzSLR7cEuV,aM2tUZzCX4nNGhBV6DcSF7um=True):
	if not tFHbpvdKm5POJryxzSLR7cEuV: tFHbpvdKm5POJryxzSLR7cEuV = '1'
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um): return
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
	EI3TqZtMDSyWnXV6bPh8s = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list',bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,R9o60qgiHv5uX1kwytSsYmx)
	vXH2IfnLek3gZi = int(tFHbpvdKm5POJryxzSLR7cEuV)*100
	JJiHyeSP5NpC2wWzgE4IQr = vXH2IfnLek3gZi-100
	for NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox in EI3TqZtMDSyWnXV6bPh8s[JJiHyeSP5NpC2wWzgE4IQr:vXH2IfnLek3gZi]:
		yBt5YugIEmo = ('GROUPED' in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL or bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL=='ALL')
		Go4jMxfqB3Q9CL7Uir = ('GROUPED' not in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL and bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL!='ALL')
		if yBt5YugIEmo or Go4jMxfqB3Q9CL7Uir:
			if   'ARCHIVED'  in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: AhBFVbK7LzNinwrg65JjpRP.append(['folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,718,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,'ARCHIVED',Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj}])
			elif 'EPG' 		 in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: AhBFVbK7LzNinwrg65JjpRP.append(['folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,718,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,'FULL_EPG',Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj}])
			elif 'TIMESHIFT' in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: AhBFVbK7LzNinwrg65JjpRP.append(['folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,718,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,'TIMESHIFT',Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj}])
			elif 'LIVE' 	 in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: AhBFVbK7LzNinwrg65JjpRP.append(['live',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,715,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NSWD3RyE8gmLnhApqVTCM,{'folder':g5gJiUkIKOqRBj}])
			else: AhBFVbK7LzNinwrg65JjpRP.append(['video',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,715,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj}])
	tvce9XhVdC8n4HjPgIqiA2r31TL = len(EI3TqZtMDSyWnXV6bPh8s)
	jj8VN1sfnlLR52J(g5gJiUkIKOqRBj,tFHbpvdKm5POJryxzSLR7cEuV,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,714,tvce9XhVdC8n4HjPgIqiA2r31TL,R9o60qgiHv5uX1kwytSsYmx)
	return
def jvbanUI2wVyhDoSz8PqCis(EEPBc0j3m1):
	A9Z3Ci2PQhFUwBXvI('link',EEPBc0j3m1+'هذه القائمة إما فارغة أو غير موجودة',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('link',EEPBc0j3m1+'أو الخدمة غير موجودة في اشتراكك',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('link',EEPBc0j3m1+'أو رابط M3U الذي أنت أضفته غير صحيح',Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return
def UUzCA532dhqKblQoYgJs(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,R9o60qgiHv5uX1kwytSsYmx,tFHbpvdKm5POJryxzSLR7cEuV,X4ofwahNQudDk=Zg9FeADE84jSRIvPCrzYulw3sL,aM2tUZzCX4nNGhBV6DcSF7um=True):
	if not tFHbpvdKm5POJryxzSLR7cEuV: tFHbpvdKm5POJryxzSLR7cEuV = '1'
	EEPBc0j3m1 = XZCQDjv9WNEA2SPdB3cTObaMI7qxl0
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um): return False
	if '__SERIES__' in R9o60qgiHv5uX1kwytSsYmx: r4ACRWp6xbdzyU1F8gtOP2KfJ,xld2wHZJNiDUIgmAnC4Gk7fXcEbB = R9o60qgiHv5uX1kwytSsYmx.split('__SERIES__')
	else: r4ACRWp6xbdzyU1F8gtOP2KfJ,xld2wHZJNiDUIgmAnC4Gk7fXcEbB = R9o60qgiHv5uX1kwytSsYmx,Zg9FeADE84jSRIvPCrzYulw3sL
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
	NTzC9PUdKi = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list',bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,'__GROUPS__')
	if not NTzC9PUdKi: return False
	L0fs65YWAvPyd41ai = []
	for QB7i2mLD9w,rr16KeaUPObJuLM7RlFzCXox in NTzC9PUdKi:
		if '===== ===== =====' in QB7i2mLD9w:
			A9Z3Ci2PQhFUwBXvI('link',EEPBc0j3m1+QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			A9Z3Ci2PQhFUwBXvI('link',EEPBc0j3m1+QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			continue
		if X4ofwahNQudDk:
			if '__SERIES__' in QB7i2mLD9w: EEPBc0j3m1 = 'SERIES'
			elif '!!__UNKNOWN__!!' in QB7i2mLD9w: EEPBc0j3m1 = 'UNKNOWN'
			elif 'LIVE' in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: EEPBc0j3m1 = 'LIVE'
			else: EEPBc0j3m1 = 'VIDEOS'
			EEPBc0j3m1 = ','+PPQORjT2lc7SVkKwFI4D+EEPBc0j3m1+': '+u4IRSmrYMKkaHUBnDiLWh
		if '__SERIES__' in QB7i2mLD9w: MOjJw2gyhVdcIFti1e4,i1OQoWu5kVH6K = QB7i2mLD9w.split('__SERIES__')
		else: MOjJw2gyhVdcIFti1e4,i1OQoWu5kVH6K = QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL
		if not R9o60qgiHv5uX1kwytSsYmx:
			if MOjJw2gyhVdcIFti1e4 in L0fs65YWAvPyd41ai: continue
			L0fs65YWAvPyd41ai.append(MOjJw2gyhVdcIFti1e4)
			if 'RANDOM' in X4ofwahNQudDk: A9Z3Ci2PQhFUwBXvI('folder',EEPBc0j3m1+MOjJw2gyhVdcIFti1e4,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,168,Zg9FeADE84jSRIvPCrzYulw3sL,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
			elif '__SERIES__' in QB7i2mLD9w: A9Z3Ci2PQhFUwBXvI('folder',EEPBc0j3m1+MOjJw2gyhVdcIFti1e4,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,713,Zg9FeADE84jSRIvPCrzYulw3sL,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
			else: A9Z3Ci2PQhFUwBXvI('folder',EEPBc0j3m1+MOjJw2gyhVdcIFti1e4,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,714,Zg9FeADE84jSRIvPCrzYulw3sL,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
		elif '__SERIES__' in QB7i2mLD9w and MOjJw2gyhVdcIFti1e4==r4ACRWp6xbdzyU1F8gtOP2KfJ:
			if i1OQoWu5kVH6K in L0fs65YWAvPyd41ai: continue
			L0fs65YWAvPyd41ai.append(i1OQoWu5kVH6K)
			if 'RANDOM' in X4ofwahNQudDk: A9Z3Ci2PQhFUwBXvI('folder',EEPBc0j3m1+i1OQoWu5kVH6K,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,168,Zg9FeADE84jSRIvPCrzYulw3sL,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
			else: A9Z3Ci2PQhFUwBXvI('folder',EEPBc0j3m1+i1OQoWu5kVH6K,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,714,rr16KeaUPObJuLM7RlFzCXox,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	AhBFVbK7LzNinwrg65JjpRP[:] = sorted(AhBFVbK7LzNinwrg65JjpRP,reverse=False,key=lambda bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r: bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r[1].lower())
	if not X4ofwahNQudDk:
		vXH2IfnLek3gZi = int(tFHbpvdKm5POJryxzSLR7cEuV)*100
		JJiHyeSP5NpC2wWzgE4IQr = vXH2IfnLek3gZi-100
		tvce9XhVdC8n4HjPgIqiA2r31TL = len(AhBFVbK7LzNinwrg65JjpRP)
		AhBFVbK7LzNinwrg65JjpRP[:] = AhBFVbK7LzNinwrg65JjpRP[JJiHyeSP5NpC2wWzgE4IQr:vXH2IfnLek3gZi]
		jj8VN1sfnlLR52J(g5gJiUkIKOqRBj,tFHbpvdKm5POJryxzSLR7cEuV,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,713,tvce9XhVdC8n4HjPgIqiA2r31TL,R9o60qgiHv5uX1kwytSsYmx)
	return True
def Rk76gYXSlq9uordaP3ZfDbLCJBhT(g5gJiUkIKOqRBj,tUHrEcLYK30N,N4PzJfxBHmX):
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,True): return
	z1MkhcyLvUeR0jKGg3t = zwp6FQr1qESsajO(g5gJiUkIKOqRBj)
	LB8luVrePRpyDsG0ok2WQU7Awi = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.timestamp_'+g5gJiUkIKOqRBj)
	if not LB8luVrePRpyDsG0ok2WQU7Awi or PPc8zbiVZnFkfXLBRv-int(LB8luVrePRpyDsG0ok2WQU7Awi)>24*qJEmpHPg3IWhvS9b5lGC48n0rYs6f:
		Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R = uUtFWOksGxAHTz7ejw2oEd5(g5gJiUkIKOqRBj,False)
		if not Gr0K5RUTIpstSm1wdle7bAxBXHLkVM: return
	QdzOwU7Zu9K2X = int(yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.timediff_'+g5gJiUkIKOqRBj))
	lM8ytp0xNZdSLrEazQFBI95ic = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.server_'+g5gJiUkIKOqRBj)
	QL2cqIzr0bEWPNdtiYo4JZDvwjXa = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.username_'+g5gJiUkIKOqRBj)
	iiEWL321NtmRlGb0ZkznJrwMvuI = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.password_'+g5gJiUkIKOqRBj)
	TTQNKLOptMSvy05jCzi2W = tUHrEcLYK30N.split('/')
	ahXtfyPRreQA4 = TTQNKLOptMSvy05jCzi2W[-1].replace('.ts',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.m3u8',Zg9FeADE84jSRIvPCrzYulw3sL)
	if N4PzJfxBHmX=='SHORT_EPG': nFQb1oUP8CDhJgLmfqHYBe = 'get_short_epg'
	else: nFQb1oUP8CDhJgLmfqHYBe = 'get_simple_data_table'
	Uhlg0oRGYds9HOw7TMzJ5N,EEzc9mBObVjvNeyGJZqTrWiRn4f7so,lM8ytp0xNZdSLrEazQFBI95ic,QL2cqIzr0bEWPNdtiYo4JZDvwjXa,iiEWL321NtmRlGb0ZkznJrwMvuI = YH9qy5BJQV(g5gJiUkIKOqRBj)
	if not QL2cqIzr0bEWPNdtiYo4JZDvwjXa: return
	rwzQWuLTUOsYP58c93pMokmVEvdtj = Uhlg0oRGYds9HOw7TMzJ5N+'&action='+nFQb1oUP8CDhJgLmfqHYBe+'&stream_id='+ahXtfyPRreQA4
	SfV7RHudvkPDq = Y9ICWNKEO7rZR4U2(FFP5vTqk3nDlEuGdIy,rwzQWuLTUOsYP58c93pMokmVEvdtj,Zg9FeADE84jSRIvPCrzYulw3sL,z1MkhcyLvUeR0jKGg3t,Zg9FeADE84jSRIvPCrzYulw3sL,'M3U-EPG_ITEMS-2nd')
	zHhmSOpdIb1xwC2tqP7XEFT9Ue = JGmfjhoyKZUl('dict',SfV7RHudvkPDq)
	Ehm2JO6oqAesNyrWGU8zDRlVj = zHhmSOpdIb1xwC2tqP7XEFT9Ue['epg_listings']
	wTpIzZFMuYbQcPNAy9E8 = []
	if N4PzJfxBHmX in ['ARCHIVED','TIMESHIFT']:
		for vQNVqXSzl5n3AUOpr6 in Ehm2JO6oqAesNyrWGU8zDRlVj:
			if vQNVqXSzl5n3AUOpr6['has_archive']==1:
				wTpIzZFMuYbQcPNAy9E8.append(vQNVqXSzl5n3AUOpr6)
				if N4PzJfxBHmX in ['TIMESHIFT']: break
		if not wTpIzZFMuYbQcPNAy9E8: return
		A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+PPQORjT2lc7SVkKwFI4D+'الملفات الأولي بهذه القائمة قد لا تعمل'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		if N4PzJfxBHmX in ['TIMESHIFT']:
			ffbO6gcGUS8WYjMetnNlHraKZd = 2
			ifao1VdPmwL4hZB = ffbO6gcGUS8WYjMetnNlHraKZd*qJEmpHPg3IWhvS9b5lGC48n0rYs6f
			wTpIzZFMuYbQcPNAy9E8 = []
			sl2Wqc3j6n7rIwMAmpgEB = int(int(vQNVqXSzl5n3AUOpr6['start_timestamp'])/ifao1VdPmwL4hZB)*ifao1VdPmwL4hZB
			fkIjC3xe5pV6qdG9sYOvc7bAhZ = PPc8zbiVZnFkfXLBRv+ifao1VdPmwL4hZB
			IEgfX1u6KOLjNY0HAp = int((fkIjC3xe5pV6qdG9sYOvc7bAhZ-sl2Wqc3j6n7rIwMAmpgEB)/qJEmpHPg3IWhvS9b5lGC48n0rYs6f)
			for P5k0vocszejAwGT1tSdN6DU in range(IEgfX1u6KOLjNY0HAp):
				if P5k0vocszejAwGT1tSdN6DU>=6:
					if P5k0vocszejAwGT1tSdN6DU%ffbO6gcGUS8WYjMetnNlHraKZd!=0: continue
					AzL6vhB4kJofiM7UWZjaRb1eN9SgXD = ifao1VdPmwL4hZB
				else: AzL6vhB4kJofiM7UWZjaRb1eN9SgXD = ifao1VdPmwL4hZB//2
				hxkZ9G2DQl8beJ = sl2Wqc3j6n7rIwMAmpgEB+P5k0vocszejAwGT1tSdN6DU*qJEmpHPg3IWhvS9b5lGC48n0rYs6f
				vQNVqXSzl5n3AUOpr6 = {}
				vQNVqXSzl5n3AUOpr6['title'] = Zg9FeADE84jSRIvPCrzYulw3sL
				vvoA3Xw8SYWnHf = LNma2eq3vEguwVtHjn.localtime(hxkZ9G2DQl8beJ-QdzOwU7Zu9K2X-qJEmpHPg3IWhvS9b5lGC48n0rYs6f)
				vQNVqXSzl5n3AUOpr6['start'] = LNma2eq3vEguwVtHjn.strftime('%Y.%m.%d %H:%M:%S',vvoA3Xw8SYWnHf)
				vQNVqXSzl5n3AUOpr6['start_timestamp'] = str(hxkZ9G2DQl8beJ)
				vQNVqXSzl5n3AUOpr6['stop_timestamp'] = str(hxkZ9G2DQl8beJ+AzL6vhB4kJofiM7UWZjaRb1eN9SgXD)
				wTpIzZFMuYbQcPNAy9E8.append(vQNVqXSzl5n3AUOpr6)
	elif N4PzJfxBHmX in ['SHORT_EPG','FULL_EPG']: wTpIzZFMuYbQcPNAy9E8 = Ehm2JO6oqAesNyrWGU8zDRlVj
	if N4PzJfxBHmX=='FULL_EPG' and len(wTpIzZFMuYbQcPNAy9E8)>0:
		A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+PPQORjT2lc7SVkKwFI4D+'هذه قائمة برامج القنوات (جدول فقط)ـ'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	ubCKrsc01mOf8R = []
	rr16KeaUPObJuLM7RlFzCXox = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Icon')
	for vQNVqXSzl5n3AUOpr6 in wTpIzZFMuYbQcPNAy9E8:
		YbnX8EkeydvLzKmWHRf = JDMo92nlwsAZydBPkpNzFvU.b64decode(vQNVqXSzl5n3AUOpr6['title'])
		if GGfPQnrJKEqMv2ZVxdD: YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		hxkZ9G2DQl8beJ = int(vQNVqXSzl5n3AUOpr6['start_timestamp'])
		bN6Gz23lcyx4vIo7AwS1Zpg = int(vQNVqXSzl5n3AUOpr6['stop_timestamp'])
		yUBl9iRVnbwqp5LZ3dfPgMhsTD1 = str(int((bN6Gz23lcyx4vIo7AwS1Zpg-hxkZ9G2DQl8beJ+59)/60))
		c6u2oXn75aIde1A = vQNVqXSzl5n3AUOpr6['start'].replace(wjs26GpVfNiCUERHJ,':')
		vvoA3Xw8SYWnHf = LNma2eq3vEguwVtHjn.localtime(hxkZ9G2DQl8beJ-qJEmpHPg3IWhvS9b5lGC48n0rYs6f)
		OSnkWiMgluyC3F6bfZNjYE8DHQKeh = LNma2eq3vEguwVtHjn.strftime('%H:%M',vvoA3Xw8SYWnHf)
		UuH5l7oSZqkFzCa4yTi83Pvbe = LNma2eq3vEguwVtHjn.strftime('%a',vvoA3Xw8SYWnHf)
		if N4PzJfxBHmX=='SHORT_EPG': YbnX8EkeydvLzKmWHRf = U2bWzwG8VdJsBqtR74ErDi3cg1v+OSnkWiMgluyC3F6bfZNjYE8DHQKeh+' ـ '+YbnX8EkeydvLzKmWHRf+u4IRSmrYMKkaHUBnDiLWh
		elif N4PzJfxBHmX=='TIMESHIFT': YbnX8EkeydvLzKmWHRf = UuH5l7oSZqkFzCa4yTi83Pvbe+wjs26GpVfNiCUERHJ+OSnkWiMgluyC3F6bfZNjYE8DHQKeh+' ('+yUBl9iRVnbwqp5LZ3dfPgMhsTD1+'min)'
		else: YbnX8EkeydvLzKmWHRf = UuH5l7oSZqkFzCa4yTi83Pvbe+wjs26GpVfNiCUERHJ+OSnkWiMgluyC3F6bfZNjYE8DHQKeh+' ('+yUBl9iRVnbwqp5LZ3dfPgMhsTD1+'min)   '+YbnX8EkeydvLzKmWHRf+' ـ'
		if N4PzJfxBHmX in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			YAB6vGeKpLOmZ8 = lM8ytp0xNZdSLrEazQFBI95ic+'/timeshift/'+QL2cqIzr0bEWPNdtiYo4JZDvwjXa+'/'+iiEWL321NtmRlGb0ZkznJrwMvuI+'/'+yUBl9iRVnbwqp5LZ3dfPgMhsTD1+'/'+c6u2oXn75aIde1A+'/'+ahXtfyPRreQA4+'.m3u8'
			if N4PzJfxBHmX=='FULL_EPG': A9Z3Ci2PQhFUwBXvI('link',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,YAB6vGeKpLOmZ8,9999,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
			else: A9Z3Ci2PQhFUwBXvI('video',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,YAB6vGeKpLOmZ8,715,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
		ubCKrsc01mOf8R.append(YbnX8EkeydvLzKmWHRf)
	if N4PzJfxBHmX=='SHORT_EPG' and ubCKrsc01mOf8R: CwEheKOcMblkJ = cch7AIZa3zlrSLvBiRCHqpd(ubCKrsc01mOf8R)
	return ubCKrsc01mOf8R
def lgeMsXynBk2UYiQ56F8(g5gJiUkIKOqRBj):
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,True): return
	lM8ytp0xNZdSLrEazQFBI95ic,nsFVCzBpja9SYi,Rdpx0TyY6qWrCIVEmGlFo = Zg9FeADE84jSRIvPCrzYulw3sL,0,0
	Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R = uUtFWOksGxAHTz7ejw2oEd5(g5gJiUkIKOqRBj,False)
	if Gr0K5RUTIpstSm1wdle7bAxBXHLkVM:
		ApFN3rnxzfGlVoYg8RJ = MWojhtvAgL8ikb0U7OrI(Uyo8uxTe6k3GzYLilWHXIQat1DnS)
		nsFVCzBpja9SYi = YYF54nVR1W9XAmL2hg0scCtNO(ApFN3rnxzfGlVoYg8RJ[0],int(h6UrDofQXN4Vy2ckMGej0qYJspvP9R))
		kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,'LIVE_GROUPED')
		vabonPe0BZ = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list','LIVE_GROUPED')
		EI3TqZtMDSyWnXV6bPh8s = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list','LIVE_GROUPED',vabonPe0BZ[1])
		tUHrEcLYK30N = EI3TqZtMDSyWnXV6bPh8s[0][2]
		u78u3AC1jRO9GeTZoiJ2wXWlqNk = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('://(.*?)/',tUHrEcLYK30N,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		u78u3AC1jRO9GeTZoiJ2wXWlqNk = u78u3AC1jRO9GeTZoiJ2wXWlqNk[0]
		if ':' in u78u3AC1jRO9GeTZoiJ2wXWlqNk: dMqDbCQTpuk4XSrP1A3KOZ,eXmHUa1hCxA = u78u3AC1jRO9GeTZoiJ2wXWlqNk.split(':')
		else: dMqDbCQTpuk4XSrP1A3KOZ,eXmHUa1hCxA = u78u3AC1jRO9GeTZoiJ2wXWlqNk,'80'
		PsLOVXu3d7pNt5kM = MWojhtvAgL8ikb0U7OrI(dMqDbCQTpuk4XSrP1A3KOZ)
		Rdpx0TyY6qWrCIVEmGlFo = YYF54nVR1W9XAmL2hg0scCtNO(PsLOVXu3d7pNt5kM[0],int(eXmHUa1hCxA))
	if nsFVCzBpja9SYi and Rdpx0TyY6qWrCIVEmGlFo:
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\n\n'+'وقت ضائع في السيرفر الأصلي'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+str(int(Rdpx0TyY6qWrCIVEmGlFo*1000))+' ملي ثانية'
		oHkimLnwDKNxlheUuGAMQIg9jY7dz += '\n\n'+'وقت ضائع في السيرفر البديل'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+str(int(nsFVCzBpja9SYi*1000))+' ملي ثانية'
		xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		if xLiq4khYySNP26cwgn8pa==1 and nsFVCzBpja9SYi<Rdpx0TyY6qWrCIVEmGlFo: lM8ytp0xNZdSLrEazQFBI95ic = Uyo8uxTe6k3GzYLilWHXIQat1DnS+':'+h6UrDofQXN4Vy2ckMGej0qYJspvP9R
	else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.server_'+g5gJiUkIKOqRBj,lM8ytp0xNZdSLrEazQFBI95ic)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(g5gJiUkIKOqRBj,tUHrEcLYK30N,RR5KdNtJEBT):
	vmduVHSDzn71EAbPN = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj)
	M6wgApoFtkqIX = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.referer_'+g5gJiUkIKOqRBj)
	if vmduVHSDzn71EAbPN or M6wgApoFtkqIX:
		tUHrEcLYK30N += '|'
		if vmduVHSDzn71EAbPN: tUHrEcLYK30N += '&User-Agent='+vmduVHSDzn71EAbPN
		if M6wgApoFtkqIX: tUHrEcLYK30N += '&Referer='+M6wgApoFtkqIX
		tUHrEcLYK30N = tUHrEcLYK30N.replace('|&','|')
	nTdpZOCUe7l(tUHrEcLYK30N,d1AeaJNg4IXzTv6ER0nicLUrf,RR5KdNtJEBT)
	return
def CSMz1e7PIbvlXd(g5gJiUkIKOqRBj):
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	vmduVHSDzn71EAbPN = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj)
	TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center','استخدام الأصلي','تعديل القديم',vmduVHSDzn71EAbPN,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if TJ3Q4VCadtnvkz==1: vmduVHSDzn71EAbPN = EnxNsqevtM28mpkZ5RG0('أكتب ـM3U User-Agent جديد',vmduVHSDzn71EAbPN,True)
	else: vmduVHSDzn71EAbPN = 'Unknown'
	if vmduVHSDzn71EAbPN==wjs26GpVfNiCUERHJ:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vmduVHSDzn71EAbPN,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if TJ3Q4VCadtnvkz!=1:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم الإلغاء')
		return
	yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj,vmduVHSDzn71EAbPN)
	StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj)
	return
def zl3rbtZmqKDYQOFGs6h09kRv7X(g5gJiUkIKOqRBj):
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	M6wgApoFtkqIX = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.referer_'+g5gJiUkIKOqRBj)
	TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center','استخدام الأصلي','تعديل القديم',M6wgApoFtkqIX,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if TJ3Q4VCadtnvkz==1: M6wgApoFtkqIX = EnxNsqevtM28mpkZ5RG0('أكتب ـM3U Referer جديد',M6wgApoFtkqIX,True)
	else: M6wgApoFtkqIX = Zg9FeADE84jSRIvPCrzYulw3sL
	if M6wgApoFtkqIX==wjs26GpVfNiCUERHJ:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,M6wgApoFtkqIX,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if TJ3Q4VCadtnvkz!=1:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم الإلغاء')
		return
	yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.referer_'+g5gJiUkIKOqRBj,M6wgApoFtkqIX)
	StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj)
	return
def YH9qy5BJQV(g5gJiUkIKOqRBj,rKO2v3MzYXG5uA4pNcntQqh=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not jr0k4pob1WPq3VEs: jr0k4pob1WPq3VEs = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.url_'+g5gJiUkIKOqRBj)
	lM8ytp0xNZdSLrEazQFBI95ic = G9GCDqXJFAc(jr0k4pob1WPq3VEs,'url')
	QL2cqIzr0bEWPNdtiYo4JZDvwjXa = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('username=(.*?)&',jr0k4pob1WPq3VEs+'&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	iiEWL321NtmRlGb0ZkznJrwMvuI = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('password=(.*?)&',jr0k4pob1WPq3VEs+'&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not QL2cqIzr0bEWPNdtiYo4JZDvwjXa or not iiEWL321NtmRlGb0ZkznJrwMvuI:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	QL2cqIzr0bEWPNdtiYo4JZDvwjXa = QL2cqIzr0bEWPNdtiYo4JZDvwjXa[0]
	iiEWL321NtmRlGb0ZkznJrwMvuI = iiEWL321NtmRlGb0ZkznJrwMvuI[0]
	Uhlg0oRGYds9HOw7TMzJ5N = lM8ytp0xNZdSLrEazQFBI95ic+'/player_api.php?username='+QL2cqIzr0bEWPNdtiYo4JZDvwjXa+'&password='+iiEWL321NtmRlGb0ZkznJrwMvuI
	EEzc9mBObVjvNeyGJZqTrWiRn4f7so = lM8ytp0xNZdSLrEazQFBI95ic+'/get.php?username='+QL2cqIzr0bEWPNdtiYo4JZDvwjXa+'&password='+iiEWL321NtmRlGb0ZkznJrwMvuI+'&type=m3u_plus'
	return Uhlg0oRGYds9HOw7TMzJ5N,EEzc9mBObVjvNeyGJZqTrWiRn4f7so,lM8ytp0xNZdSLrEazQFBI95ic,QL2cqIzr0bEWPNdtiYo4JZDvwjXa,iiEWL321NtmRlGb0ZkznJrwMvuI
def AzMCPnkoit(g5gJiUkIKOqRBj,IydGcHrn4YOX1suSqJb8f=Zg9FeADE84jSRIvPCrzYulw3sL):
	TjSWy4MG0OeU = IydGcHrn4YOX1suSqJb8f.replace('/','_').replace(':','_').replace('.','_')
	TjSWy4MG0OeU = TjSWy4MG0OeU.replace('?','_').replace('=','_').replace('&','_')
	TjSWy4MG0OeU = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,TjSWy4MG0OeU).strip('.m3u')+'.m3u'
	return TjSWy4MG0OeU
def kC2z7EYmpJb0a(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu):
	cnweAr0KE5YbgMCIQm = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.url_'+g5gJiUkIKOqRBj+'_'+XyE5GFSoQsxDVwAu)
	M5EnolNe7vd6gTZIfuhUz9 = True
	if cnweAr0KE5YbgMCIQm:
		TJ3Q4VCadtnvkz = wCuDBb85Gjl36RAQnUEZd('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',PPQORjT2lc7SVkKwFI4D+cnweAr0KE5YbgMCIQm+u4IRSmrYMKkaHUBnDiLWh+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if TJ3Q4VCadtnvkz==-1: return
		elif TJ3Q4VCadtnvkz==0: cnweAr0KE5YbgMCIQm = Zg9FeADE84jSRIvPCrzYulw3sL
		elif TJ3Q4VCadtnvkz==2:
			TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if TJ3Q4VCadtnvkz in [-1,0]: return
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم مسح الرابط')
			M5EnolNe7vd6gTZIfuhUz9 = False
			cmuI4kRJeSyDHTi = Zg9FeADE84jSRIvPCrzYulw3sL
	if M5EnolNe7vd6gTZIfuhUz9:
		cmuI4kRJeSyDHTi = EnxNsqevtM28mpkZ5RG0('اكتب رابط M3U كاملا',cnweAr0KE5YbgMCIQm)
		cmuI4kRJeSyDHTi = cmuI4kRJeSyDHTi.strip(wjs26GpVfNiCUERHJ)
		if not cmuI4kRJeSyDHTi:
			TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if TJ3Q4VCadtnvkz in [-1,0]: return
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم مسح الرابط')
		else:
			oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			TJ3Q4VCadtnvkz = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'الرابط الجديد هو:',PPQORjT2lc7SVkKwFI4D+cmuI4kRJeSyDHTi+u4IRSmrYMKkaHUBnDiLWh+'\n\n'+oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			if TJ3Q4VCadtnvkz!=1:
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم الإلغاء')
				return
	yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.url_'+g5gJiUkIKOqRBj+'_'+XyE5GFSoQsxDVwAu,cmuI4kRJeSyDHTi)
	vmduVHSDzn71EAbPN = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj)
	if not vmduVHSDzn71EAbPN: yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj,'Unknown')
	StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj)
	return
def Do2eWl6y089BtzvKAXf(K2Qe8NmokbrnE7WMy6OZ3LHY,y2a8DQvof7UMIP,U1UqMkFnc9rJvNVTjP,Mfzx50qhbnwv1kpaNLEOYUVJ,mDNbhUof6PjiMSgR2eY1A90pw,U26DYydTWoMlnxH4Cg1Pztj8suFw,EEzc9mBObVjvNeyGJZqTrWiRn4f7so):
	EI3TqZtMDSyWnXV6bPh8s,hKby5sqWHfG8Sxa0jN = [],[]
	eeT9ivsltrG = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		if U26DYydTWoMlnxH4Cg1Pztj8suFw%473==0:
			OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,40+int(10*U26DYydTWoMlnxH4Cg1Pztj8suFw/mDNbhUof6PjiMSgR2eY1A90pw),'قراءة الفيديوهات','الفيديو رقم:-',str(U26DYydTWoMlnxH4Cg1Pztj8suFw)+' / '+str(mDNbhUof6PjiMSgR2eY1A90pw))
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return None,None,None
		tUHrEcLYK30N = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.*?)\n+((http|https|rtmp).*?)$',oPlAXTViOL4Fw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if tUHrEcLYK30N:
			oPlAXTViOL4Fw,tUHrEcLYK30N,KtnlUTb3Vw = tUHrEcLYK30N[0]
			tUHrEcLYK30N = tUHrEcLYK30N.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL)
			oPlAXTViOL4Fw = oPlAXTViOL4Fw.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL)
		else:
			hKby5sqWHfG8Sxa0jN.append({'line':oPlAXTViOL4Fw})
			continue
		kU8wlYCxA2hjzoBsdG1EOnSbp,NSWD3RyE8gmLnhApqVTCM,QB7i2mLD9w,YbnX8EkeydvLzKmWHRf,RR5KdNtJEBT,caAQv60eCSHVLUtblWzxET = {},Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,False
		try:
			oPlAXTViOL4Fw,YbnX8EkeydvLzKmWHRf = oPlAXTViOL4Fw.rsplit('",',1)
			oPlAXTViOL4Fw = oPlAXTViOL4Fw+'"'
		except:
			try: oPlAXTViOL4Fw,YbnX8EkeydvLzKmWHRf = oPlAXTViOL4Fw.rsplit('1,',1)
			except: YbnX8EkeydvLzKmWHRf = Zg9FeADE84jSRIvPCrzYulw3sL
		kU8wlYCxA2hjzoBsdG1EOnSbp['url'] = tUHrEcLYK30N
		l79ifbQsUoMWdNGq = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(' (.*?)="(.*?)"',oPlAXTViOL4Fw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r,rLYn0O75xM8GNE in l79ifbQsUoMWdNGq:
			bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r = bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r.replace('"',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			kU8wlYCxA2hjzoBsdG1EOnSbp[bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r] = rLYn0O75xM8GNE.strip(wjs26GpVfNiCUERHJ)
		tocVBF0nfqWGHOT1 = list(kU8wlYCxA2hjzoBsdG1EOnSbp.keys())
		if not YbnX8EkeydvLzKmWHRf:
			if 'name' in tocVBF0nfqWGHOT1 and kU8wlYCxA2hjzoBsdG1EOnSbp['name']: YbnX8EkeydvLzKmWHRf = kU8wlYCxA2hjzoBsdG1EOnSbp['name']
		kU8wlYCxA2hjzoBsdG1EOnSbp['title'] = YbnX8EkeydvLzKmWHRf.strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
		if 'logo' in tocVBF0nfqWGHOT1:
			kU8wlYCxA2hjzoBsdG1EOnSbp['img'] = kU8wlYCxA2hjzoBsdG1EOnSbp['logo']
			del kU8wlYCxA2hjzoBsdG1EOnSbp['logo']
		else: kU8wlYCxA2hjzoBsdG1EOnSbp['img'] = Zg9FeADE84jSRIvPCrzYulw3sL
		if 'group' in tocVBF0nfqWGHOT1 and kU8wlYCxA2hjzoBsdG1EOnSbp['group']: QB7i2mLD9w = kU8wlYCxA2hjzoBsdG1EOnSbp['group']
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in tUHrEcLYK30N.lower() for B251BPiLbvG9UxszKtlI7YQHmoWw in eeT9ivsltrG):
			caAQv60eCSHVLUtblWzxET = True if 'm3u' not in tUHrEcLYK30N else False
		if caAQv60eCSHVLUtblWzxET or '__SERIES__' in QB7i2mLD9w or '__MOVIES__' in QB7i2mLD9w:
			RR5KdNtJEBT = 'VOD'
			if '__SERIES__' in QB7i2mLD9w: RR5KdNtJEBT = RR5KdNtJEBT+'_SERIES'
			elif '__MOVIES__' in QB7i2mLD9w: RR5KdNtJEBT = RR5KdNtJEBT+'_MOVIES'
			else: RR5KdNtJEBT = RR5KdNtJEBT+'_UNKNOWN'
			QB7i2mLD9w = QB7i2mLD9w.replace('__SERIES__',Zg9FeADE84jSRIvPCrzYulw3sL).replace('__MOVIES__',Zg9FeADE84jSRIvPCrzYulw3sL)
		else:
			RR5KdNtJEBT = 'LIVE'
			if YbnX8EkeydvLzKmWHRf in y2a8DQvof7UMIP: NSWD3RyE8gmLnhApqVTCM = NSWD3RyE8gmLnhApqVTCM+'_EPG'
			if YbnX8EkeydvLzKmWHRf in U1UqMkFnc9rJvNVTjP: NSWD3RyE8gmLnhApqVTCM = NSWD3RyE8gmLnhApqVTCM+'_ARCHIVED'
			if not QB7i2mLD9w: RR5KdNtJEBT = RR5KdNtJEBT+'_UNKNOWN'
			else: RR5KdNtJEBT = RR5KdNtJEBT+NSWD3RyE8gmLnhApqVTCM
		QB7i2mLD9w = QB7i2mLD9w.strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
		if 'LIVE_UNKNOWN' in RR5KdNtJEBT: QB7i2mLD9w = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in RR5KdNtJEBT: QB7i2mLD9w = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in RR5KdNtJEBT:
			GGTYNRaA9h7bjoX = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) [Ss]\d+ +[Ee]\d+',kU8wlYCxA2hjzoBsdG1EOnSbp['title'],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if GGTYNRaA9h7bjoX: GGTYNRaA9h7bjoX = GGTYNRaA9h7bjoX[0]
			else: GGTYNRaA9h7bjoX = '!!__UNKNOWN_SERIES__!!'
			QB7i2mLD9w = QB7i2mLD9w+'__SERIES__'+GGTYNRaA9h7bjoX
		if 'id' in tocVBF0nfqWGHOT1: del kU8wlYCxA2hjzoBsdG1EOnSbp['id']
		if 'ID' in tocVBF0nfqWGHOT1: del kU8wlYCxA2hjzoBsdG1EOnSbp['ID']
		if 'name' in tocVBF0nfqWGHOT1: del kU8wlYCxA2hjzoBsdG1EOnSbp['name']
		YbnX8EkeydvLzKmWHRf = kU8wlYCxA2hjzoBsdG1EOnSbp['title']
		YbnX8EkeydvLzKmWHRf = uumhMi6O4pk7Gjd5aTQqy2Z(YbnX8EkeydvLzKmWHRf)
		YbnX8EkeydvLzKmWHRf = zzEVhqsHDOA6X1pvF7LKeBn(YbnX8EkeydvLzKmWHRf)
		oXaOreK0RWY1PQ4B35gEvUFq8T,QB7i2mLD9w = AADydwimg31e7FRbQ(QB7i2mLD9w)
		qqCcVxS5B7bfPInp9ZMWT,YbnX8EkeydvLzKmWHRf = AADydwimg31e7FRbQ(YbnX8EkeydvLzKmWHRf)
		kU8wlYCxA2hjzoBsdG1EOnSbp['type'] = RR5KdNtJEBT
		kU8wlYCxA2hjzoBsdG1EOnSbp['context'] = NSWD3RyE8gmLnhApqVTCM
		kU8wlYCxA2hjzoBsdG1EOnSbp['group'] = QB7i2mLD9w.upper()
		kU8wlYCxA2hjzoBsdG1EOnSbp['title'] = YbnX8EkeydvLzKmWHRf.upper()
		kU8wlYCxA2hjzoBsdG1EOnSbp['country'] = qqCcVxS5B7bfPInp9ZMWT.upper()
		kU8wlYCxA2hjzoBsdG1EOnSbp['language'] = oXaOreK0RWY1PQ4B35gEvUFq8T.upper()
		EI3TqZtMDSyWnXV6bPh8s.append(kU8wlYCxA2hjzoBsdG1EOnSbp)
		U26DYydTWoMlnxH4Cg1Pztj8suFw += 1
	return EI3TqZtMDSyWnXV6bPh8s,U26DYydTWoMlnxH4Cg1Pztj8suFw,hKby5sqWHfG8Sxa0jN
def zzEVhqsHDOA6X1pvF7LKeBn(YbnX8EkeydvLzKmWHRf):
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.replace('||','|').replace('___',':').replace('--','-')
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.replace('[[','[').replace(']]',']')
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.replace('((','(').replace('))',')')
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.replace('<<','<').replace('>>','>')
	YbnX8EkeydvLzKmWHRf = YbnX8EkeydvLzKmWHRf.strip(wjs26GpVfNiCUERHJ)
	return YbnX8EkeydvLzKmWHRf
def kMxUubehEcdLA(iPZg8WYek5HK3fSsEa1LvRlnop4,Mfzx50qhbnwv1kpaNLEOYUVJ,XyE5GFSoQsxDVwAu):
	VLKA7qNlZUbhYFsg = {}
	for JFGOcpn2IuYDAhb6Krf in lA6cxNd9HkqmeR: VLKA7qNlZUbhYFsg[JFGOcpn2IuYDAhb6Krf+'_'+XyE5GFSoQsxDVwAu] = []
	mDNbhUof6PjiMSgR2eY1A90pw = len(iPZg8WYek5HK3fSsEa1LvRlnop4)
	aN2viTQ84urDI = str(mDNbhUof6PjiMSgR2eY1A90pw)
	U26DYydTWoMlnxH4Cg1Pztj8suFw = 0
	hKby5sqWHfG8Sxa0jN = []
	for kU8wlYCxA2hjzoBsdG1EOnSbp in iPZg8WYek5HK3fSsEa1LvRlnop4:
		if U26DYydTWoMlnxH4Cg1Pztj8suFw%873==0:
			OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,50+int(5*U26DYydTWoMlnxH4Cg1Pztj8suFw/mDNbhUof6PjiMSgR2eY1A90pw),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(U26DYydTWoMlnxH4Cg1Pztj8suFw)+' / '+aN2viTQ84urDI)
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return None,None
		QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox = kU8wlYCxA2hjzoBsdG1EOnSbp['group'],kU8wlYCxA2hjzoBsdG1EOnSbp['context'],kU8wlYCxA2hjzoBsdG1EOnSbp['title'],kU8wlYCxA2hjzoBsdG1EOnSbp['url'],kU8wlYCxA2hjzoBsdG1EOnSbp['img']
		qqCcVxS5B7bfPInp9ZMWT,oXaOreK0RWY1PQ4B35gEvUFq8T,JFGOcpn2IuYDAhb6Krf = kU8wlYCxA2hjzoBsdG1EOnSbp['country'],kU8wlYCxA2hjzoBsdG1EOnSbp['language'],kU8wlYCxA2hjzoBsdG1EOnSbp['type']
		gsFqNS69vJYeM8K = (QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox)
		hXkZb6UOJQEgWB19o0FqifKTwaeL4I = False
		if 'LIVE' in JFGOcpn2IuYDAhb6Krf:
			if 'UNKNOWN' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_UNKNOWN_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			elif 'LIVE' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			else: hXkZb6UOJQEgWB19o0FqifKTwaeL4I = True
			VLKA7qNlZUbhYFsg['LIVE_ORIGINAL_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
		elif 'VOD' in JFGOcpn2IuYDAhb6Krf:
			if 'UNKNOWN' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_UNKNOWN_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			elif 'MOVIES' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_MOVIES_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			elif 'SERIES' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_SERIES_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			else: hXkZb6UOJQEgWB19o0FqifKTwaeL4I = True
			VLKA7qNlZUbhYFsg['VOD_ORIGINAL_GROUPED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
		else: hXkZb6UOJQEgWB19o0FqifKTwaeL4I = True
		if hXkZb6UOJQEgWB19o0FqifKTwaeL4I: hKby5sqWHfG8Sxa0jN.append(kU8wlYCxA2hjzoBsdG1EOnSbp)
		U26DYydTWoMlnxH4Cg1Pztj8suFw += 1
	AdMKzwgUpB4I9q2 = sorted(iPZg8WYek5HK3fSsEa1LvRlnop4,reverse=False,key=lambda bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r: bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r['title'].lower())
	del iPZg8WYek5HK3fSsEa1LvRlnop4
	aN2viTQ84urDI = str(mDNbhUof6PjiMSgR2eY1A90pw)
	U26DYydTWoMlnxH4Cg1Pztj8suFw = 0
	for kU8wlYCxA2hjzoBsdG1EOnSbp in AdMKzwgUpB4I9q2:
		U26DYydTWoMlnxH4Cg1Pztj8suFw += 1
		if U26DYydTWoMlnxH4Cg1Pztj8suFw%873==0:
			OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,55+int(5*U26DYydTWoMlnxH4Cg1Pztj8suFw/mDNbhUof6PjiMSgR2eY1A90pw),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(U26DYydTWoMlnxH4Cg1Pztj8suFw)+' / '+aN2viTQ84urDI)
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return None,None
		JFGOcpn2IuYDAhb6Krf = kU8wlYCxA2hjzoBsdG1EOnSbp['type']
		QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox = kU8wlYCxA2hjzoBsdG1EOnSbp['group'],kU8wlYCxA2hjzoBsdG1EOnSbp['context'],kU8wlYCxA2hjzoBsdG1EOnSbp['title'],kU8wlYCxA2hjzoBsdG1EOnSbp['url'],kU8wlYCxA2hjzoBsdG1EOnSbp['img']
		qqCcVxS5B7bfPInp9ZMWT,oXaOreK0RWY1PQ4B35gEvUFq8T = kU8wlYCxA2hjzoBsdG1EOnSbp['country'],kU8wlYCxA2hjzoBsdG1EOnSbp['language']
		sVGHIAgTMPe71ju4o3O9UkRbD = (QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM+'_TIMESHIFT',YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox)
		gsFqNS69vJYeM8K = (QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox)
		iWPnZfdC8VQg5lx1opkMI = (qqCcVxS5B7bfPInp9ZMWT,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox)
		Hc8n1QOqtu7L6RM = (oXaOreK0RWY1PQ4B35gEvUFq8T,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox)
		if 'LIVE' in JFGOcpn2IuYDAhb6Krf:
			if 'UNKNOWN' in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_UNKNOWN_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			else: VLKA7qNlZUbhYFsg['LIVE_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			if 'EPG'		in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_EPG_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			if 'ARCHIVED'	in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_ARCHIVED_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			if 'ARCHIVED'	in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['LIVE_TIMESHIFT_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(sVGHIAgTMPe71ju4o3O9UkRbD)
			VLKA7qNlZUbhYFsg['LIVE_FROM_NAME_SORTED_'+XyE5GFSoQsxDVwAu].append(iWPnZfdC8VQg5lx1opkMI)
			VLKA7qNlZUbhYFsg['LIVE_FROM_GROUP_SORTED_'+XyE5GFSoQsxDVwAu].append(Hc8n1QOqtu7L6RM)
		elif 'VOD' in JFGOcpn2IuYDAhb6Krf:
			if   'UNKNOWN'	in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_UNKNOWN_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			elif 'MOVIES'	in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_MOVIES_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			elif 'SERIES'	in JFGOcpn2IuYDAhb6Krf: VLKA7qNlZUbhYFsg['VOD_SERIES_GROUPED_SORTED_'+XyE5GFSoQsxDVwAu].append(gsFqNS69vJYeM8K)
			VLKA7qNlZUbhYFsg['VOD_FROM_NAME_SORTED_'+XyE5GFSoQsxDVwAu].append(iWPnZfdC8VQg5lx1opkMI)
			VLKA7qNlZUbhYFsg['VOD_FROM_GROUP_SORTED_'+XyE5GFSoQsxDVwAu].append(Hc8n1QOqtu7L6RM)
	return VLKA7qNlZUbhYFsg,hKby5sqWHfG8Sxa0jN
def AADydwimg31e7FRbQ(YbnX8EkeydvLzKmWHRf):
	if len(YbnX8EkeydvLzKmWHRf)<3: return YbnX8EkeydvLzKmWHRf,YbnX8EkeydvLzKmWHRf
	S5ymYo7uUW0f4BqDehZak2POTHX,BwY7XtJcK3 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	jHI6r2Yw08zKBhEDAt = YbnX8EkeydvLzKmWHRf
	foDGsgxkYj = YbnX8EkeydvLzKmWHRf[:1]
	GCabVX6ysWFqEK5Menx4kl2DoIh = YbnX8EkeydvLzKmWHRf[1:]
	if   foDGsgxkYj=='(': BwY7XtJcK3 = ')'
	elif foDGsgxkYj=='[': BwY7XtJcK3 = ']'
	elif foDGsgxkYj=='<': BwY7XtJcK3 = '>'
	elif foDGsgxkYj=='|': BwY7XtJcK3 = '|'
	if BwY7XtJcK3 and (BwY7XtJcK3 in GCabVX6ysWFqEK5Menx4kl2DoIh):
		BK9RjF42kamdZHOfxMT7iPwvY,CCo1dme9vsb5HNxyhQ4 = GCabVX6ysWFqEK5Menx4kl2DoIh.split(BwY7XtJcK3,1)
		S5ymYo7uUW0f4BqDehZak2POTHX = BK9RjF42kamdZHOfxMT7iPwvY
		jHI6r2Yw08zKBhEDAt = foDGsgxkYj+BK9RjF42kamdZHOfxMT7iPwvY+BwY7XtJcK3+wjs26GpVfNiCUERHJ+CCo1dme9vsb5HNxyhQ4
	elif YbnX8EkeydvLzKmWHRf.count('|')>=2:
		BK9RjF42kamdZHOfxMT7iPwvY,CCo1dme9vsb5HNxyhQ4 = YbnX8EkeydvLzKmWHRf.split('|',1)
		S5ymYo7uUW0f4BqDehZak2POTHX = BK9RjF42kamdZHOfxMT7iPwvY
		jHI6r2Yw08zKBhEDAt = BK9RjF42kamdZHOfxMT7iPwvY+' |'+CCo1dme9vsb5HNxyhQ4
	else:
		BwY7XtJcK3 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',YbnX8EkeydvLzKmWHRf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not BwY7XtJcK3: BwY7XtJcK3 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',YbnX8EkeydvLzKmWHRf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not BwY7XtJcK3: BwY7XtJcK3 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',YbnX8EkeydvLzKmWHRf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if BwY7XtJcK3:
			BK9RjF42kamdZHOfxMT7iPwvY,CCo1dme9vsb5HNxyhQ4 = YbnX8EkeydvLzKmWHRf.split(BwY7XtJcK3[0],1)
			S5ymYo7uUW0f4BqDehZak2POTHX = BK9RjF42kamdZHOfxMT7iPwvY
			jHI6r2Yw08zKBhEDAt = BK9RjF42kamdZHOfxMT7iPwvY+wjs26GpVfNiCUERHJ+BwY7XtJcK3[0]+wjs26GpVfNiCUERHJ+CCo1dme9vsb5HNxyhQ4
	jHI6r2Yw08zKBhEDAt = jHI6r2Yw08zKBhEDAt.replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	S5ymYo7uUW0f4BqDehZak2POTHX = S5ymYo7uUW0f4BqDehZak2POTHX.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	if not S5ymYo7uUW0f4BqDehZak2POTHX: S5ymYo7uUW0f4BqDehZak2POTHX = '!!__UNKNOWN__!!'
	S5ymYo7uUW0f4BqDehZak2POTHX = S5ymYo7uUW0f4BqDehZak2POTHX.strip(wjs26GpVfNiCUERHJ)
	jHI6r2Yw08zKBhEDAt = jHI6r2Yw08zKBhEDAt.strip(wjs26GpVfNiCUERHJ)
	return S5ymYo7uUW0f4BqDehZak2POTHX,jHI6r2Yw08zKBhEDAt
def zwp6FQr1qESsajO(g5gJiUkIKOqRBj):
	z1MkhcyLvUeR0jKGg3t = {}
	vmduVHSDzn71EAbPN = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj)
	if vmduVHSDzn71EAbPN: z1MkhcyLvUeR0jKGg3t['User-Agent'] = vmduVHSDzn71EAbPN
	M6wgApoFtkqIX = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.referer_'+g5gJiUkIKOqRBj)
	if M6wgApoFtkqIX: z1MkhcyLvUeR0jKGg3t['Referer'] = M6wgApoFtkqIX
	return z1MkhcyLvUeR0jKGg3t
def o4jkLCRwBgYvPdJMZW6rfGpX0OAe(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu):
	global Mfzx50qhbnwv1kpaNLEOYUVJ,VLKA7qNlZUbhYFsg,uWnY68DxTch,spycEleFVzq,iYrVcxI97JWRqAotONe8Ub,vabonPe0BZ,L8PSWgNEn3clVribx1Oj,BPpKY4ZMbVSrE3tUgHOLFXDehuq,nTmNhLlebMkjJtRvD9
	EEzc9mBObVjvNeyGJZqTrWiRn4f7so = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.url_'+g5gJiUkIKOqRBj+'_'+XyE5GFSoQsxDVwAu)
	vmduVHSDzn71EAbPN = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.useragent_'+g5gJiUkIKOqRBj)
	z1MkhcyLvUeR0jKGg3t = {'User-Agent':vmduVHSDzn71EAbPN}
	TjSWy4MG0OeU = w1wAdy5GghQiZKpzI.replace('___','_'+g5gJiUkIKOqRBj+'_'+XyE5GFSoQsxDVwAu)
	if 1:
		Gr0K5RUTIpstSm1wdle7bAxBXHLkVM,Uyo8uxTe6k3GzYLilWHXIQat1DnS,h6UrDofQXN4Vy2ckMGej0qYJspvP9R = True,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
		if not Gr0K5RUTIpstSm1wdle7bAxBXHLkVM:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not EEzc9mBObVjvNeyGJZqTrWiRn4f7so: zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   No M3U URL found to download M3U files')
			else: zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(d1AeaJNg4IXzTv6ER0nicLUrf)+'   Failed to download M3U files')
			return
		ttFcxV8q5BgRv = seYEjxGn1qkDZbXQtifpJLP3R(EEzc9mBObVjvNeyGJZqTrWiRn4f7so,z1MkhcyLvUeR0jKGg3t,True)
		if not ttFcxV8q5BgRv: return
		open(TjSWy4MG0OeU,'wb').write(ttFcxV8q5BgRv)
	else: ttFcxV8q5BgRv = open(TjSWy4MG0OeU,'rb').read()
	if GGfPQnrJKEqMv2ZVxdD and ttFcxV8q5BgRv: ttFcxV8q5BgRv = ttFcxV8q5BgRv.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	Mfzx50qhbnwv1kpaNLEOYUVJ = Rr8woplmSQWXIZcGFfA()
	Mfzx50qhbnwv1kpaNLEOYUVJ.create('جلب ملفات M3U جديدة',Zg9FeADE84jSRIvPCrzYulw3sL)
	OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,15,'تنظيف الملف الرئيسي',Zg9FeADE84jSRIvPCrzYulw3sL)
	ttFcxV8q5BgRv = ttFcxV8q5BgRv.replace('"tvg-','" tvg-')
	ttFcxV8q5BgRv = ttFcxV8q5BgRv.replace('َ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ً',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ُ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٌ',Zg9FeADE84jSRIvPCrzYulw3sL)
	ttFcxV8q5BgRv = ttFcxV8q5BgRv.replace('ّ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ِ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٍ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ْ',Zg9FeADE84jSRIvPCrzYulw3sL)
	ttFcxV8q5BgRv = ttFcxV8q5BgRv.replace('group-title=','group=').replace('tvg-',Zg9FeADE84jSRIvPCrzYulw3sL)
	U1UqMkFnc9rJvNVTjP,y2a8DQvof7UMIP = [],[]
	ttFcxV8q5BgRv = ttFcxV8q5BgRv.replace(mqBPGuVIYZbStQejFowJh2,SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
	K2Qe8NmokbrnE7WMy6OZ3LHY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('NF:(.+?)'+'#'+'EXTI',ttFcxV8q5BgRv+'\n+'+'#'+'EXTINF:',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not K2Qe8NmokbrnE7WMy6OZ3LHY:
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(d1AeaJNg4IXzTv6ER0nicLUrf)+'   Folder:'+g5gJiUkIKOqRBj+'  Sequence:'+XyE5GFSoQsxDVwAu+'   No video links found in M3U file')
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+'مجلد رقم '+g5gJiUkIKOqRBj+'      رابط رقم '+XyE5GFSoQsxDVwAu+u4IRSmrYMKkaHUBnDiLWh)
		Mfzx50qhbnwv1kpaNLEOYUVJ.close()
		return
	Ve5dcGyMArI63lJp82Yo = []
	for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
		lltYBARxqOZ0rjhJCXnI8QyT9FdDHf = oPlAXTViOL4Fw.lower()
		if 'adult' in lltYBARxqOZ0rjhJCXnI8QyT9FdDHf: continue
		if 'xxx' in lltYBARxqOZ0rjhJCXnI8QyT9FdDHf: continue
		Ve5dcGyMArI63lJp82Yo.append(oPlAXTViOL4Fw)
	K2Qe8NmokbrnE7WMy6OZ3LHY = Ve5dcGyMArI63lJp82Yo
	del Ve5dcGyMArI63lJp82Yo
	if 'iptv-org' in EEzc9mBObVjvNeyGJZqTrWiRn4f7so:
		Ve5dcGyMArI63lJp82Yo,wvEzsSJNTkBfL0Qg9cObWmZM4rV = [],[]
		for oPlAXTViOL4Fw in K2Qe8NmokbrnE7WMy6OZ3LHY:
			vabonPe0BZ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('group="(.*?)"',oPlAXTViOL4Fw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if vabonPe0BZ:
				vabonPe0BZ = vabonPe0BZ[0]
				HSXVdDiPFgafs5CjwUWqA = vabonPe0BZ.split(';')
				if 'region' in EEzc9mBObVjvNeyGJZqTrWiRn4f7so: lVkjCD0r7m6 = '1_'
				elif 'category' in EEzc9mBObVjvNeyGJZqTrWiRn4f7so: lVkjCD0r7m6 = '2_'
				elif 'language' in EEzc9mBObVjvNeyGJZqTrWiRn4f7so: lVkjCD0r7m6 = '3_'
				elif 'country' in EEzc9mBObVjvNeyGJZqTrWiRn4f7so: lVkjCD0r7m6 = '4_'
				else: lVkjCD0r7m6 = '5_'
				mWysti5bHISBxa4OuMYK = oPlAXTViOL4Fw.replace('group="'+vabonPe0BZ+'"','group="'+lVkjCD0r7m6+'~'+PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh+'"')
				Ve5dcGyMArI63lJp82Yo.append(mWysti5bHISBxa4OuMYK)
				for QB7i2mLD9w in HSXVdDiPFgafs5CjwUWqA:
					mWysti5bHISBxa4OuMYK = oPlAXTViOL4Fw.replace('group="'+vabonPe0BZ+'"','group="'+lVkjCD0r7m6+QB7i2mLD9w+'"')
					Ve5dcGyMArI63lJp82Yo.append(mWysti5bHISBxa4OuMYK)
			else: Ve5dcGyMArI63lJp82Yo.append(oPlAXTViOL4Fw)
		K2Qe8NmokbrnE7WMy6OZ3LHY = Ve5dcGyMArI63lJp82Yo
		del Ve5dcGyMArI63lJp82Yo,wvEzsSJNTkBfL0Qg9cObWmZM4rV
	MJ3LO4D6eKhdPjbTozFC1f = 1024*1024
	ckpVwbn7JTFvjO5lf = 1+len(ttFcxV8q5BgRv)//MJ3LO4D6eKhdPjbTozFC1f//10
	del ttFcxV8q5BgRv
	X9Bw6lQoykiJVDNmAUrh0PxcugKM8O = len(K2Qe8NmokbrnE7WMy6OZ3LHY)
	wvEzsSJNTkBfL0Qg9cObWmZM4rV = AAMdFjOkSDyec648zgBUpfiwQbm(K2Qe8NmokbrnE7WMy6OZ3LHY,ckpVwbn7JTFvjO5lf)
	del K2Qe8NmokbrnE7WMy6OZ3LHY
	for WN2aAnXwst in range(ckpVwbn7JTFvjO5lf):
		OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,35+int(5*WN2aAnXwst/ckpVwbn7JTFvjO5lf),'تقطيع الملف الرئيسي','الجزء رقم:-',str(WN2aAnXwst+1)+' / '+str(ckpVwbn7JTFvjO5lf))
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
		WpGF0josz8Qkn = str(wvEzsSJNTkBfL0Qg9cObWmZM4rV[WN2aAnXwst])
		if GGfPQnrJKEqMv2ZVxdD: WpGF0josz8Qkn = WpGF0josz8Qkn.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open(TjSWy4MG0OeU+'.00'+str(WN2aAnXwst),'wb').write(WpGF0josz8Qkn)
	del wvEzsSJNTkBfL0Qg9cObWmZM4rV,WpGF0josz8Qkn
	sjSvKAgZYz5eiW46k,iPZg8WYek5HK3fSsEa1LvRlnop4,U26DYydTWoMlnxH4Cg1Pztj8suFw = [],[],0
	for WN2aAnXwst in range(ckpVwbn7JTFvjO5lf):
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
		WpGF0josz8Qkn = open(TjSWy4MG0OeU+'.00'+str(WN2aAnXwst),'rb').read()
		LNma2eq3vEguwVtHjn.sleep(1)
		try: brAUlZfdFmt3TRJW2xX4.remove(TjSWy4MG0OeU+'.00'+str(WN2aAnXwst))
		except: pass
		if GGfPQnrJKEqMv2ZVxdD: WpGF0josz8Qkn = WpGF0josz8Qkn.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		VLXlYqQ405MOubZoycf = JGmfjhoyKZUl('list',WpGF0josz8Qkn)
		del WpGF0josz8Qkn
		EI3TqZtMDSyWnXV6bPh8s,U26DYydTWoMlnxH4Cg1Pztj8suFw,hKby5sqWHfG8Sxa0jN = Do2eWl6y089BtzvKAXf(VLXlYqQ405MOubZoycf,y2a8DQvof7UMIP,U1UqMkFnc9rJvNVTjP,Mfzx50qhbnwv1kpaNLEOYUVJ,X9Bw6lQoykiJVDNmAUrh0PxcugKM8O,U26DYydTWoMlnxH4Cg1Pztj8suFw,EEzc9mBObVjvNeyGJZqTrWiRn4f7so)
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
		if not EI3TqZtMDSyWnXV6bPh8s:
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
		iPZg8WYek5HK3fSsEa1LvRlnop4 += EI3TqZtMDSyWnXV6bPh8s
		sjSvKAgZYz5eiW46k += hKby5sqWHfG8Sxa0jN
	del VLXlYqQ405MOubZoycf,EI3TqZtMDSyWnXV6bPh8s
	VLKA7qNlZUbhYFsg,hKby5sqWHfG8Sxa0jN = kMxUubehEcdLA(iPZg8WYek5HK3fSsEa1LvRlnop4,Mfzx50qhbnwv1kpaNLEOYUVJ,XyE5GFSoQsxDVwAu)
	if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
		Mfzx50qhbnwv1kpaNLEOYUVJ.close()
		return
	sjSvKAgZYz5eiW46k += hKby5sqWHfG8Sxa0jN
	del iPZg8WYek5HK3fSsEa1LvRlnop4,hKby5sqWHfG8Sxa0jN
	spycEleFVzq,iYrVcxI97JWRqAotONe8Ub,vabonPe0BZ,L8PSWgNEn3clVribx1Oj,BPpKY4ZMbVSrE3tUgHOLFXDehuq = {},{},{},0,0
	WgUlLd9OoNKxwha5z7J1PXuRBQjeb = list(VLKA7qNlZUbhYFsg.keys())
	nTmNhLlebMkjJtRvD9 = len(WgUlLd9OoNKxwha5z7J1PXuRBQjeb)*3
	if 1:
		Ot8hbcxDfu6dv = {}
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL] = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=dNmWPfXM43,args=(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,))
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL].start()
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL].join()
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
	else:
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			dNmWPfXM43(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return
	sgbPXp8CzQS9mt0D1(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu,False)
	WgUlLd9OoNKxwha5z7J1PXuRBQjeb = list(spycEleFVzq.keys())
	uWnY68DxTch = 0
	if 1:
		Ot8hbcxDfu6dv = {}
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL] = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=Oq5NYGVCyfmdx3egEbAQLpc7,args=(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL))
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL].start()
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			Ot8hbcxDfu6dv[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL].join()
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
			Mfzx50qhbnwv1kpaNLEOYUVJ.close()
			return
	else:
		for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in WgUlLd9OoNKxwha5z7J1PXuRBQjeb:
			Oq5NYGVCyfmdx3egEbAQLpc7(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return
	WN2aAnXwst = 0
	aX9QilDujp3GMxAhSdcNHPUoYI2 = len(sjSvKAgZYz5eiW46k)
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,'IGNORED')
	for czl2yUM0LHJ7u5V9sahSb in sjSvKAgZYz5eiW46k:
		if WN2aAnXwst%27==0:
			OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,95+int(5*WN2aAnXwst//aX9QilDujp3GMxAhSdcNHPUoYI2),'تخزين المهملة','الفيديو رقم:-',str(WN2aAnXwst)+' / '+str(aX9QilDujp3GMxAhSdcNHPUoYI2))
			if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled():
				Mfzx50qhbnwv1kpaNLEOYUVJ.close()
				return
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,'IGNORED_'+XyE5GFSoQsxDVwAu,str(czl2yUM0LHJ7u5V9sahSb),Zg9FeADE84jSRIvPCrzYulw3sL,B4GWT7zonF5yipbIwJmNUf6Vavg)
		WN2aAnXwst += 1
	cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,'IGNORED_'+XyE5GFSoQsxDVwAu,'__COUNT__',str(aX9QilDujp3GMxAhSdcNHPUoYI2),B4GWT7zonF5yipbIwJmNUf6Vavg)
	Mfzx50qhbnwv1kpaNLEOYUVJ.close()
	LNma2eq3vEguwVtHjn.sleep(1)
	StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj)
	return
def dNmWPfXM43(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL):
	global Mfzx50qhbnwv1kpaNLEOYUVJ,VLKA7qNlZUbhYFsg,uWnY68DxTch,spycEleFVzq,iYrVcxI97JWRqAotONe8Ub,vabonPe0BZ,L8PSWgNEn3clVribx1Oj,BPpKY4ZMbVSrE3tUgHOLFXDehuq,nTmNhLlebMkjJtRvD9
	spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL] = {}
	S4HxdQRVhP6jzBtUMGpLmC8f7i9,ONmUokBi1Xy87hGunI = {},[]
	T9QV72XoJInab834y = len(VLKA7qNlZUbhYFsg[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL])
	spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]['__COUNT__'] = T9QV72XoJInab834y
	if T9QV72XoJInab834y>0:
		YJDT4cWrSao,E4gnTspDOFqj5AhBH,O0SkaIDjq5nEA3FYCtvKwbdcg6,jp65gMcbiY9UBfSL0H8TtR2nAQ,q62qxBwGDNLR = zip(*VLKA7qNlZUbhYFsg[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL])
		del E4gnTspDOFqj5AhBH,O0SkaIDjq5nEA3FYCtvKwbdcg6,jp65gMcbiY9UBfSL0H8TtR2nAQ
		HSXVdDiPFgafs5CjwUWqA = list(set(YJDT4cWrSao))
		for QB7i2mLD9w in HSXVdDiPFgafs5CjwUWqA:
			S4HxdQRVhP6jzBtUMGpLmC8f7i9[QB7i2mLD9w] = Zg9FeADE84jSRIvPCrzYulw3sL
			spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL][QB7i2mLD9w] = []
		OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,60+int(15*BPpKY4ZMbVSrE3tUgHOLFXDehuq//nTmNhLlebMkjJtRvD9),'تصنيع القوائم','الجزء رقم:-',str(BPpKY4ZMbVSrE3tUgHOLFXDehuq)+' / '+str(nTmNhLlebMkjJtRvD9))
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled(): return
		BPpKY4ZMbVSrE3tUgHOLFXDehuq += 1
		TkgxAY0bce = len(HSXVdDiPFgafs5CjwUWqA)
		del HSXVdDiPFgafs5CjwUWqA
		ONmUokBi1Xy87hGunI = list(set(zip(YJDT4cWrSao,q62qxBwGDNLR)))
		del YJDT4cWrSao,q62qxBwGDNLR
		for QB7i2mLD9w,feRw3p6MLob90H4J in ONmUokBi1Xy87hGunI:
			if not S4HxdQRVhP6jzBtUMGpLmC8f7i9[QB7i2mLD9w] and feRw3p6MLob90H4J: S4HxdQRVhP6jzBtUMGpLmC8f7i9[QB7i2mLD9w] = feRw3p6MLob90H4J
		OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,60+int(15*BPpKY4ZMbVSrE3tUgHOLFXDehuq//nTmNhLlebMkjJtRvD9),'تصنيع القوائم','الجزء رقم:-',str(BPpKY4ZMbVSrE3tUgHOLFXDehuq)+' / '+str(nTmNhLlebMkjJtRvD9))
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled(): return
		BPpKY4ZMbVSrE3tUgHOLFXDehuq += 1
		ww1zRPGfkqELmI0ASgu = list(S4HxdQRVhP6jzBtUMGpLmC8f7i9.keys())
		jlfo9SVTwEyqhs8WUX7 = list(S4HxdQRVhP6jzBtUMGpLmC8f7i9.values())
		del S4HxdQRVhP6jzBtUMGpLmC8f7i9
		ONmUokBi1Xy87hGunI = list(zip(ww1zRPGfkqELmI0ASgu,jlfo9SVTwEyqhs8WUX7))
		del ww1zRPGfkqELmI0ASgu,jlfo9SVTwEyqhs8WUX7
		ONmUokBi1Xy87hGunI = sorted(ONmUokBi1Xy87hGunI)
	else: BPpKY4ZMbVSrE3tUgHOLFXDehuq += 2
	spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]['__GROUPS__'] = ONmUokBi1Xy87hGunI
	del ONmUokBi1Xy87hGunI
	for QB7i2mLD9w,NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox in VLKA7qNlZUbhYFsg[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]:
		spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL][QB7i2mLD9w].append((NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox))
	OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,60+int(15*BPpKY4ZMbVSrE3tUgHOLFXDehuq//nTmNhLlebMkjJtRvD9),'تصنيع القوائم','الجزء رقم:-',str(BPpKY4ZMbVSrE3tUgHOLFXDehuq)+' / '+str(nTmNhLlebMkjJtRvD9))
	if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled(): return
	BPpKY4ZMbVSrE3tUgHOLFXDehuq += 1
	del VLKA7qNlZUbhYFsg[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]
	vabonPe0BZ[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL] = list(spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL].keys())
	iYrVcxI97JWRqAotONe8Ub[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL] = len(vabonPe0BZ[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL])
	L8PSWgNEn3clVribx1Oj += iYrVcxI97JWRqAotONe8Ub[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]
	return
def Oq5NYGVCyfmdx3egEbAQLpc7(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL):
	global Mfzx50qhbnwv1kpaNLEOYUVJ,VLKA7qNlZUbhYFsg,uWnY68DxTch,spycEleFVzq,iYrVcxI97JWRqAotONe8Ub,vabonPe0BZ,L8PSWgNEn3clVribx1Oj,BPpKY4ZMbVSrE3tUgHOLFXDehuq,nTmNhLlebMkjJtRvD9
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
	for U26DYydTWoMlnxH4Cg1Pztj8suFw in range(1+iYrVcxI97JWRqAotONe8Ub[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]//273):
		NjPVlCRwSsLZfEqBzDrGb5A4OUpe1m = []
		tGkFOB5bCNAs0MTEdXJzRWpHl = vabonPe0BZ[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL][0:273]
		for QB7i2mLD9w in tGkFOB5bCNAs0MTEdXJzRWpHl:
			NjPVlCRwSsLZfEqBzDrGb5A4OUpe1m.append(spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL][QB7i2mLD9w])
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,tGkFOB5bCNAs0MTEdXJzRWpHl,NjPVlCRwSsLZfEqBzDrGb5A4OUpe1m,B4GWT7zonF5yipbIwJmNUf6Vavg,True)
		uWnY68DxTch += len(tGkFOB5bCNAs0MTEdXJzRWpHl)
		OpsLGCQJ9nbVthERxuAY1e(Mfzx50qhbnwv1kpaNLEOYUVJ,75+int(20*uWnY68DxTch//L8PSWgNEn3clVribx1Oj),'تخزين القوائم','القائمة رقم:-',str(uWnY68DxTch)+' / '+str(L8PSWgNEn3clVribx1Oj))
		if Mfzx50qhbnwv1kpaNLEOYUVJ.iscanceled(): return
		del vabonPe0BZ[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL][0:273]
	del spycEleFVzq[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL],vabonPe0BZ[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL],iYrVcxI97JWRqAotONe8Ub[bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL]
	return
def anUm1Py2qpI(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu,aM2tUZzCX4nNGhBV6DcSF7um=True):
	LZmMRs9gfb8yB = 'عدد فيديوهات جميع الروابط'
	ZiYKlk8x2S46H1UyIB9arf = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,'LIVE_ORIGINAL_GROUPED')
	u6jtoQNAxZ7pwJnSqsBMVrvLH1T0 = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,'VOD_ORIGINAL_GROUPED')
	if XyE5GFSoQsxDVwAu:
		LZmMRs9gfb8yB = 'عدد فيديوهات رابط '+YOjp8EZx4D[int(XyE5GFSoQsxDVwAu)]
		XyE5GFSoQsxDVwAu = '_'+XyE5GFSoQsxDVwAu
	aX9QilDujp3GMxAhSdcNHPUoYI2 = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','IGNORED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	ggv4QpUwICu0sibO9c1RFlYk8fzJG = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','LIVE_ORIGINAL_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	wS2rRd0Wc3Xjuh6eO = zZlsxj57ThCH(u6jtoQNAxZ7pwJnSqsBMVrvLH1T0,'int','VOD_ORIGINAL_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	hKx2jeo1IJLMBwfQRDiYTz = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','LIVE_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	EyXf7pRYB5VsrajeWhcA3xgiTb = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','LIVE_UNKNOWN_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	EAR6qhu7VHxizo3e9bG8dyXKt5F = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','VOD_MOVIES_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	WICKwXO48ljxmG1BDbV9S = zZlsxj57ThCH(u6jtoQNAxZ7pwJnSqsBMVrvLH1T0,'int','VOD_SERIES_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	tFLDhUZwnP = zZlsxj57ThCH(ZiYKlk8x2S46H1UyIB9arf,'int','VOD_UNKNOWN_GROUPED'+XyE5GFSoQsxDVwAu,'__COUNT__')
	vabonPe0BZ = zZlsxj57ThCH(u6jtoQNAxZ7pwJnSqsBMVrvLH1T0,'list','VOD_SERIES_GROUPED'+XyE5GFSoQsxDVwAu,'__GROUPS__')
	hDfZGr1Sa6tek7XqHVUxOAm3LcPQ = []
	for QB7i2mLD9w,rr16KeaUPObJuLM7RlFzCXox in vabonPe0BZ:
		aujrinK67tlTPJpSFVevk8C35hAc4 = QB7i2mLD9w.split('__SERIES__')[1]
		hDfZGr1Sa6tek7XqHVUxOAm3LcPQ.append(aujrinK67tlTPJpSFVevk8C35hAc4)
	PPq1sdrv5w2fcCnX = len(hDfZGr1Sa6tek7XqHVUxOAm3LcPQ)
	tvce9XhVdC8n4HjPgIqiA2r31TL = int(EAR6qhu7VHxizo3e9bG8dyXKt5F)+int(WICKwXO48ljxmG1BDbV9S)+int(tFLDhUZwnP)+int(EyXf7pRYB5VsrajeWhcA3xgiTb)+int(hKx2jeo1IJLMBwfQRDiYTz)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ = Zg9FeADE84jSRIvPCrzYulw3sL
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += 'قنوات: '+str(hKx2jeo1IJLMBwfQRDiYTz)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '   .   أفلام: '+str(EAR6qhu7VHxizo3e9bG8dyXKt5F)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '\nمسلسلات: '+str(PPq1sdrv5w2fcCnX)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '   .   حلقات: '+str(WICKwXO48ljxmG1BDbV9S)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '\nقنوات مجهولة: '+str(EyXf7pRYB5VsrajeWhcA3xgiTb)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '   .   فيدوهات مجهولة: '+str(tFLDhUZwnP)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '\nمجموع القنوات: '+str(ggv4QpUwICu0sibO9c1RFlYk8fzJG)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '   .   مجموع الفيديوهات: '+str(wS2rRd0Wc3Xjuh6eO)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '\n\nمجموع المضافة: '+str(tvce9XhVdC8n4HjPgIqiA2r31TL)
	kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ += '   .   مجموع المهملة: '+str(aX9QilDujp3GMxAhSdcNHPUoYI2)
	if aM2tUZzCX4nNGhBV6DcSF7um: I3kpd28CgLtrVEcuAXiZ('center',Zg9FeADE84jSRIvPCrzYulw3sL,LZmMRs9gfb8yB,kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ)
	HKF9OjJQG0MzhiL4RS3 = kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ.replace('\n\n',SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
	if not XyE5GFSoQsxDVwAu: XyE5GFSoQsxDVwAu = 'All'
	else: XyE5GFSoQsxDVwAu = XyE5GFSoQsxDVwAu[1]
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,'.\tCounts of M3U videos   Folder: '+g5gJiUkIKOqRBj+'   Sequence: '+XyE5GFSoQsxDVwAu+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+HKF9OjJQG0MzhiL4RS3)
	return kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ
def sgbPXp8CzQS9mt0D1(g5gJiUkIKOqRBj,XyE5GFSoQsxDVwAu,aM2tUZzCX4nNGhBV6DcSF7um=True):
	if aM2tUZzCX4nNGhBV6DcSF7um:
		xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if xLiq4khYySNP26cwgn8pa!=1: return
		UMPufVb9KJFELp1rtQigl6BoxzqCY = w1wAdy5GghQiZKpzI.replace('___','_'+g5gJiUkIKOqRBj+'_'+XyE5GFSoQsxDVwAu)
		try: brAUlZfdFmt3TRJW2xX4.remove(UMPufVb9KJFELp1rtQigl6BoxzqCY)
		except: pass
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,Zg9FeADE84jSRIvPCrzYulw3sL)
	if XyE5GFSoQsxDVwAu:
		utAxSDPawC9 = []
		for UtMiXsqkjPZfl in lA6cxNd9HkqmeR:
			utAxSDPawC9.append(UtMiXsqkjPZfl+'_'+XyE5GFSoQsxDVwAu)
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,'LINK_'+XyE5GFSoQsxDVwAu)
	else:
		utAxSDPawC9 = lA6cxNd9HkqmeR
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,'DUMMY')
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,'GROUPS')
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,'ITEMS')
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,'SEARCH')
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_'+g5gJiUkIKOqRBj)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in utAxSDPawC9:
		nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)
	O1o4Qh6m2gWpdP0qwUaFTDMvnEi9yG(False)
	StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj)
	if aM2tUZzCX4nNGhBV6DcSF7um: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj=Zg9FeADE84jSRIvPCrzYulw3sL,aM2tUZzCX4nNGhBV6DcSF7um=True):
	if g5gJiUkIKOqRBj:
		kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(str(g5gJiUkIKOqRBj),'DUMMY')
		KtnlUTb3Vw = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'str','DUMMY','__DUMMY__')
		if KtnlUTb3Vw: return True
	else:
		g5gJiUkIKOqRBj = '1'
		for SShsfX8r2uUAVwQ0zBRMv in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
			kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(str(SShsfX8r2uUAVwQ0zBRMv),'DUMMY')
			KtnlUTb3Vw = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'str','DUMMY','__DUMMY__')
			if KtnlUTb3Vw: return True
	if aM2tUZzCX4nNGhBV6DcSF7um:
		op8TAHywScqzLM1jPl6GWZEObki4xg = 'https://iptv-org.github.io/iptv/index.region.m3u'
		QJpSYdzWXU4r32Fsb = 'https://iptv-org.github.io/iptv/index.category.m3u'
		aaqXbrZ4SEjWm = 'https://iptv-org.github.io/iptv/index.language.m3u'
		ooi4by0h1YWfgx58mG6pEVTPXkz2s = 'https://iptv-org.github.io/iptv/index.country.m3u'
		xojpk5ndmyAur7M2gsYBOXa = op8TAHywScqzLM1jPl6GWZEObki4xg+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+QJpSYdzWXU4r32Fsb+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+aaqXbrZ4SEjWm+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ooi4by0h1YWfgx58mG6pEVTPXkz2s
		xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n'+PPQORjT2lc7SVkKwFI4D+'http://github.com/iptv-org/iptv'+u4IRSmrYMKkaHUBnDiLWh+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+PPQORjT2lc7SVkKwFI4D+xojpk5ndmyAur7M2gsYBOXa+u4IRSmrYMKkaHUBnDiLWh,profile='confirm_mediumfont')
		if xLiq4khYySNP26cwgn8pa==1:
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.url_'+str(g5gJiUkIKOqRBj)+'_1',op8TAHywScqzLM1jPl6GWZEObki4xg)
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.url_'+str(g5gJiUkIKOqRBj)+'_2',QJpSYdzWXU4r32Fsb)
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.url_'+str(g5gJiUkIKOqRBj)+'_3',aaqXbrZ4SEjWm)
			yUTYoAgth5iC43uLrdBH.setSetting('av.m3u.url_'+str(g5gJiUkIKOqRBj)+'_4',ooi4by0h1YWfgx58mG6pEVTPXkz2s)
			xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if xLiq4khYySNP26cwgn8pa==1:
				VDnvyIRguOZABk = sO1NzKoRHmVY2BwySJGc5kCupv(g5gJiUkIKOqRBj)
				return VDnvyIRguOZABk
		else:
			LZmMRs9gfb8yB = 'إضافة وتغيير رابط '+YOjp8EZx4D[1]+' (مجلد '+YOjp8EZx4D[int(g5gJiUkIKOqRBj)]+')'
			xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,LZmMRs9gfb8yB,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if xLiq4khYySNP26cwgn8pa==1: kC2z7EYmpJb0a(g5gJiUkIKOqRBj,'1')
	return False
def kkjBRKDdmEAuncTUShs1M2GrC6g3(WA36YGktVQzBHUuCPsX0oDLyq8,g5gJiUkIKOqRBj=Zg9FeADE84jSRIvPCrzYulw3sL,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL=Zg9FeADE84jSRIvPCrzYulw3sL,tFHbpvdKm5POJryxzSLR7cEuV=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not tFHbpvdKm5POJryxzSLR7cEuV: tFHbpvdKm5POJryxzSLR7cEuV = '1'
	He8xrotiaD0spXjL,zIaSNiZbOTGWrcQE79gX,aM2tUZzCX4nNGhBV6DcSF7um = xXQLatdZbuT1H6(WA36YGktVQzBHUuCPsX0oDLyq8)
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um): return
	if not He8xrotiaD0spXjL:
		He8xrotiaD0spXjL = EnxNsqevtM28mpkZ5RG0()
		if not He8xrotiaD0spXjL: return
	aaje68fgtIWJ = [Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL:
		if not aM2tUZzCX4nNGhBV6DcSF7um:
			if   '_M3U-LIVE_' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[1]
			elif '_M3U-MOVIES' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[2]
			elif '_M3U-SERIES' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[3]
			else: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[0]
		else:
			xqSykNM16BPZOjY9FfgQ5LpuTHA = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			KPAgkny9rSD0Xdx6CUse1a2LG = WXZLgSfpV2jzRFTNiyroc('أختر البحث المناسب', xqSykNM16BPZOjY9FfgQ5LpuTHA)
			if KPAgkny9rSD0Xdx6CUse1a2LG==-1: return
			bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[KPAgkny9rSD0Xdx6CUse1a2LG]
	He8xrotiaD0spXjL = He8xrotiaD0spXjL+'_NODIALOGS_'
	if g5gJiUkIKOqRBj: hCb2JBrT8wVQ(He8xrotiaD0spXjL,g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,tFHbpvdKm5POJryxzSLR7cEuV)
	else:
		for g5gJiUkIKOqRBj in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
			hCb2JBrT8wVQ(He8xrotiaD0spXjL,str(g5gJiUkIKOqRBj),bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,tFHbpvdKm5POJryxzSLR7cEuV)
		AhBFVbK7LzNinwrg65JjpRP[:] = sorted(AhBFVbK7LzNinwrg65JjpRP,reverse=False,key=lambda bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r: bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r[1].lower())
	return
def hCb2JBrT8wVQ(WA36YGktVQzBHUuCPsX0oDLyq8,g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL=Zg9FeADE84jSRIvPCrzYulw3sL,tFHbpvdKm5POJryxzSLR7cEuV=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not tFHbpvdKm5POJryxzSLR7cEuV: tFHbpvdKm5POJryxzSLR7cEuV = '1'
	He8xrotiaD0spXjL,zIaSNiZbOTGWrcQE79gX,aM2tUZzCX4nNGhBV6DcSF7um = xXQLatdZbuT1H6(WA36YGktVQzBHUuCPsX0oDLyq8)
	if not g5gJiUkIKOqRBj: return
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um): return
	if not He8xrotiaD0spXjL:
		He8xrotiaD0spXjL = EnxNsqevtM28mpkZ5RG0()
		if not He8xrotiaD0spXjL: return
	aaje68fgtIWJ = [Zg9FeADE84jSRIvPCrzYulw3sL,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL:
		if not aM2tUZzCX4nNGhBV6DcSF7um:
			if   '_M3U-LIVE_' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[1]
			elif '_M3U-MOVIES' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[2]
			elif '_M3U-SERIES' in zIaSNiZbOTGWrcQE79gX: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[3]
			else: bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[0]
		else:
			xqSykNM16BPZOjY9FfgQ5LpuTHA = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			KPAgkny9rSD0Xdx6CUse1a2LG = WXZLgSfpV2jzRFTNiyroc('أختر البحث المناسب', xqSykNM16BPZOjY9FfgQ5LpuTHA)
			if KPAgkny9rSD0Xdx6CUse1a2LG==-1: return
			bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL = aaje68fgtIWJ[KPAgkny9rSD0Xdx6CUse1a2LG]
	IT5dwne2cutWD0 = He8xrotiaD0spXjL.lower()
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,'SEARCH')
	x3HQ4Fyra7dZjWcJsvCPUmAT = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list','SEARCH',(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,IT5dwne2cutWD0))
	if not x3HQ4Fyra7dZjWcJsvCPUmAT:
		rzROfkLjUhNMwHtX91gquAYyeJ3,U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK = [],[]
		if not bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: iMND40oqweKCGWskp239dbyhBgRm = [1,2,3,4,5]
		else: iMND40oqweKCGWskp239dbyhBgRm = [aaje68fgtIWJ.index(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL)]
		for WN2aAnXwst in iMND40oqweKCGWskp239dbyhBgRm:
			if WN2aAnXwst!=3:
				EI3TqZtMDSyWnXV6bPh8s = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'dict',aaje68fgtIWJ[WN2aAnXwst])
				del EI3TqZtMDSyWnXV6bPh8s['__COUNT__']
				del EI3TqZtMDSyWnXV6bPh8s['__GROUPS__']
				del EI3TqZtMDSyWnXV6bPh8s['__SEQUENCED_COLUMNS__']
				vabonPe0BZ = list(EI3TqZtMDSyWnXV6bPh8s.keys())
				for QB7i2mLD9w in vabonPe0BZ:
					for NSWD3RyE8gmLnhApqVTCM,YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox in EI3TqZtMDSyWnXV6bPh8s[QB7i2mLD9w]:
						if IT5dwne2cutWD0 in YbnX8EkeydvLzKmWHRf.lower(): U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK.append((YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox))
					del EI3TqZtMDSyWnXV6bPh8s[QB7i2mLD9w]
				del EI3TqZtMDSyWnXV6bPh8s
			else: vabonPe0BZ = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'list',aaje68fgtIWJ[WN2aAnXwst],'__GROUPS__')
			for QB7i2mLD9w in vabonPe0BZ:
				try: QB7i2mLD9w,rr16KeaUPObJuLM7RlFzCXox = QB7i2mLD9w
				except: rr16KeaUPObJuLM7RlFzCXox = Zg9FeADE84jSRIvPCrzYulw3sL
				if IT5dwne2cutWD0 in QB7i2mLD9w.lower():
					if WN2aAnXwst!=3: T6fHlju7iv0 = QB7i2mLD9w
					else:
						MOjJw2gyhVdcIFti1e4,i1OQoWu5kVH6K = QB7i2mLD9w.split('__SERIES__')
						if IT5dwne2cutWD0 in MOjJw2gyhVdcIFti1e4.lower(): T6fHlju7iv0 = MOjJw2gyhVdcIFti1e4
						else: T6fHlju7iv0 = i1OQoWu5kVH6K
					rzROfkLjUhNMwHtX91gquAYyeJ3.append((QB7i2mLD9w,T6fHlju7iv0,aaje68fgtIWJ[WN2aAnXwst],rr16KeaUPObJuLM7RlFzCXox))
			del vabonPe0BZ
		rzROfkLjUhNMwHtX91gquAYyeJ3 = set(rzROfkLjUhNMwHtX91gquAYyeJ3)
		U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK = set(U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK)
		rzROfkLjUhNMwHtX91gquAYyeJ3 = sorted(rzROfkLjUhNMwHtX91gquAYyeJ3,reverse=False,key=lambda bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r: bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r[1])
		U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK = sorted(U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK,reverse=False,key=lambda bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r: bq8fVuIDCP1gwh6RiKY3Mvt7ZOQ5r[0])
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,'SEARCH',(bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,IT5dwne2cutWD0),(rzROfkLjUhNMwHtX91gquAYyeJ3,U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK),B4GWT7zonF5yipbIwJmNUf6Vavg)
	else: rzROfkLjUhNMwHtX91gquAYyeJ3,U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK = x3HQ4Fyra7dZjWcJsvCPUmAT
	vabonPe0BZ = len(rzROfkLjUhNMwHtX91gquAYyeJ3)
	SSc5AyT7vJDRdgHFB2sqjMu = len(U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK)
	Kkpm8izMrSFTGBcyUWHvtCYdxQaRP = int(tFHbpvdKm5POJryxzSLR7cEuV)
	Zg3NFmBhjwkzX198yRnWeEoG = max(0,(Kkpm8izMrSFTGBcyUWHvtCYdxQaRP-1)*100)
	pUdGgBHQ8mkM4n5J1Zb = max(0,Kkpm8izMrSFTGBcyUWHvtCYdxQaRP*100)
	mRjUlc8Wrk06TaXIVgLqD25x = max(0,Zg3NFmBhjwkzX198yRnWeEoG-vabonPe0BZ)
	S9cULfjQwuGBIZDM2neq1J = max(0,pUdGgBHQ8mkM4n5J1Zb-vabonPe0BZ)
	for QB7i2mLD9w,T6fHlju7iv0,KbZkEVGmOq7z9xJnNafAgTB,rr16KeaUPObJuLM7RlFzCXox in rzROfkLjUhNMwHtX91gquAYyeJ3[Zg3NFmBhjwkzX198yRnWeEoG:pUdGgBHQ8mkM4n5J1Zb]:
		A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+T6fHlju7iv0,KbZkEVGmOq7z9xJnNafAgTB,714,rr16KeaUPObJuLM7RlFzCXox,'1',QB7i2mLD9w,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	del rzROfkLjUhNMwHtX91gquAYyeJ3
	for YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,rr16KeaUPObJuLM7RlFzCXox in U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK[mRjUlc8Wrk06TaXIVgLqD25x:S9cULfjQwuGBIZDM2neq1J]:
		PTO8N1zkldYQAsyaZMIw = wzX1klOfLVhb2B4ita(tUHrEcLYK30N)
		RR5KdNtJEBT = 'live'
		if '.mkv' in PTO8N1zkldYQAsyaZMIw or 'VOD' in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: RR5KdNtJEBT = 'video'
		A9Z3Ci2PQhFUwBXvI(RR5KdNtJEBT,XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+YbnX8EkeydvLzKmWHRf,tUHrEcLYK30N,715,rr16KeaUPObJuLM7RlFzCXox,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	del U9wbVNlqsWpIB4Yd1Ar6zLxmiCOK
	jj8VN1sfnlLR52J(g5gJiUkIKOqRBj,tFHbpvdKm5POJryxzSLR7cEuV,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,719,vabonPe0BZ+SSc5AyT7vJDRdgHFB2sqjMu,He8xrotiaD0spXjL+'_NODIALOGS_')
	return
def jj8VN1sfnlLR52J(g5gJiUkIKOqRBj,tFHbpvdKm5POJryxzSLR7cEuV,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,LfnWDFgRdJH4lZvt7yo28N,tvce9XhVdC8n4HjPgIqiA2r31TL,Tbwq7kJ4vRSNVyUFcdMzirG):
	if not tFHbpvdKm5POJryxzSLR7cEuV: tFHbpvdKm5POJryxzSLR7cEuV = '1'
	if tFHbpvdKm5POJryxzSLR7cEuV!='1': A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'صفحة '+str(1),bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,LfnWDFgRdJH4lZvt7yo28N,Zg9FeADE84jSRIvPCrzYulw3sL,str(1),Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	if not tvce9XhVdC8n4HjPgIqiA2r31TL: tvce9XhVdC8n4HjPgIqiA2r31TL = 0
	XGqkJT4sledUvtgF3xD8 = int(tvce9XhVdC8n4HjPgIqiA2r31TL/100)+1
	for Kkpm8izMrSFTGBcyUWHvtCYdxQaRP in range(2,XGqkJT4sledUvtgF3xD8):
		yBt5YugIEmo = (Kkpm8izMrSFTGBcyUWHvtCYdxQaRP%10==0 or int(tFHbpvdKm5POJryxzSLR7cEuV)-4<Kkpm8izMrSFTGBcyUWHvtCYdxQaRP<int(tFHbpvdKm5POJryxzSLR7cEuV)+4)
		Go4jMxfqB3Q9CL7Uir = (yBt5YugIEmo and int(tFHbpvdKm5POJryxzSLR7cEuV)-40<Kkpm8izMrSFTGBcyUWHvtCYdxQaRP<int(tFHbpvdKm5POJryxzSLR7cEuV)+40)
		if str(Kkpm8izMrSFTGBcyUWHvtCYdxQaRP)!=tFHbpvdKm5POJryxzSLR7cEuV and (Kkpm8izMrSFTGBcyUWHvtCYdxQaRP%100==0 or Go4jMxfqB3Q9CL7Uir):
			A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'صفحة '+str(Kkpm8izMrSFTGBcyUWHvtCYdxQaRP),bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,LfnWDFgRdJH4lZvt7yo28N,Zg9FeADE84jSRIvPCrzYulw3sL,str(Kkpm8izMrSFTGBcyUWHvtCYdxQaRP),Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	if str(XGqkJT4sledUvtgF3xD8)!=tFHbpvdKm5POJryxzSLR7cEuV: A9Z3Ci2PQhFUwBXvI('folder',XZCQDjv9WNEA2SPdB3cTObaMI7qxl0+'أخر صفحة '+str(XGqkJT4sledUvtgF3xD8),bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,LfnWDFgRdJH4lZvt7yo28N,Zg9FeADE84jSRIvPCrzYulw3sL,str(XGqkJT4sledUvtgF3xD8),Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':g5gJiUkIKOqRBj})
	return
def gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL):
	kqB5bPjyZI8QumW9a = dVgLfY13X2.replace('___','_'+g5gJiUkIKOqRBj)
	return kqB5bPjyZI8QumW9a
def sO1NzKoRHmVY2BwySJGc5kCupv(g5gJiUkIKOqRBj):
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,Zg9FeADE84jSRIvPCrzYulw3sL)
	xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if xLiq4khYySNP26cwgn8pa!=1: return False
	wRYQPfobqUD0N9(g5gJiUkIKOqRBj,False)
	CAY3obPUuTZpfHQl = [0]
	for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
		IydGcHrn4YOX1suSqJb8f = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.url_'+g5gJiUkIKOqRBj+'_'+str(D0wIcOgK6BJtoEys2U))
		if IydGcHrn4YOX1suSqJb8f: o4jkLCRwBgYvPdJMZW6rfGpX0OAe(g5gJiUkIKOqRBj,str(D0wIcOgK6BJtoEys2U))
		CAY3obPUuTZpfHQl.append(0)
	for bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL in lA6cxNd9HkqmeR:
		EWuOkwVnLJm8hjbP5r13Aqgei0t2,a6Rh537bzlTyrZdSCOLNWYJsonjPQg,qewRP70XW3LBjQE,QN6idwzhgBxqSE,S4HxdQRVhP6jzBtUMGpLmC8f7i9 = 0,{},[],[],[]
		for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
			KbZkEVGmOq7z9xJnNafAgTB = bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL+'_'+str(D0wIcOgK6BJtoEys2U)
			VLKA7qNlZUbhYFsg = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'dict',KbZkEVGmOq7z9xJnNafAgTB)
			try:
				QIfBmXyjCJ0 = VLKA7qNlZUbhYFsg['__GROUPS__']
				P5k0vocszejAwGT1tSdN6DU = VLKA7qNlZUbhYFsg['__COUNT__']
			except: QIfBmXyjCJ0,P5k0vocszejAwGT1tSdN6DU = [],'0'
			for qapkzKN7CdtxTiYcW in QIfBmXyjCJ0:
				QB7i2mLD9w,feRw3p6MLob90H4J = qapkzKN7CdtxTiYcW
				EI3TqZtMDSyWnXV6bPh8s = VLKA7qNlZUbhYFsg[QB7i2mLD9w]
				if QB7i2mLD9w not in QN6idwzhgBxqSE:
					QN6idwzhgBxqSE.append(QB7i2mLD9w)
					S4HxdQRVhP6jzBtUMGpLmC8f7i9.append(qapkzKN7CdtxTiYcW)
					a6Rh537bzlTyrZdSCOLNWYJsonjPQg[QB7i2mLD9w] = []
				a6Rh537bzlTyrZdSCOLNWYJsonjPQg[QB7i2mLD9w] += EI3TqZtMDSyWnXV6bPh8s
			nnWvBsbfxdHYJNLPAct(kqB5bPjyZI8QumW9a,KbZkEVGmOq7z9xJnNafAgTB)
			cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,KbZkEVGmOq7z9xJnNafAgTB,'__COUNT__',P5k0vocszejAwGT1tSdN6DU,B4GWT7zonF5yipbIwJmNUf6Vavg)
			CAY3obPUuTZpfHQl[D0wIcOgK6BJtoEys2U] += int(P5k0vocszejAwGT1tSdN6DU)
		for QB7i2mLD9w in QN6idwzhgBxqSE:
			EI3TqZtMDSyWnXV6bPh8s = list(set(a6Rh537bzlTyrZdSCOLNWYJsonjPQg[QB7i2mLD9w]))
			if 'SORTED' in bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL: EI3TqZtMDSyWnXV6bPh8s = sorted(EI3TqZtMDSyWnXV6bPh8s,reverse=False,key=lambda key: key[1].lower())
			EWuOkwVnLJm8hjbP5r13Aqgei0t2 += len(EI3TqZtMDSyWnXV6bPh8s)
			qewRP70XW3LBjQE.append(EI3TqZtMDSyWnXV6bPh8s)
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,'__COUNT__',str(EWuOkwVnLJm8hjbP5r13Aqgei0t2),B4GWT7zonF5yipbIwJmNUf6Vavg)
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,'__GROUPS__',S4HxdQRVhP6jzBtUMGpLmC8f7i9,B4GWT7zonF5yipbIwJmNUf6Vavg)
		cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,bJZ0u5MGicsYeCwUrSk9oIaVpBA7WL,QN6idwzhgBxqSE,qewRP70XW3LBjQE,B4GWT7zonF5yipbIwJmNUf6Vavg,True)
	LLab4ZvoDsrTtqE = False
	for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
		if int(CAY3obPUuTZpfHQl[D0wIcOgK6BJtoEys2U])>0:
			IydGcHrn4YOX1suSqJb8f = yUTYoAgth5iC43uLrdBH.getSetting('av.m3u.url_'+g5gJiUkIKOqRBj+'_'+str(D0wIcOgK6BJtoEys2U))
			cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,'LINK_'+str(D0wIcOgK6BJtoEys2U),'__LINK__',IydGcHrn4YOX1suSqJb8f,B4GWT7zonF5yipbIwJmNUf6Vavg)
			LLab4ZvoDsrTtqE = True
	cb76opH5VXk2fjWqzExS0yTBGsen(kqB5bPjyZI8QumW9a,'DUMMY','__DUMMY__','DUMMY',B4GWT7zonF5yipbIwJmNUf6Vavg)
	if not LLab4ZvoDsrTtqE:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	o2XWqTVDKrFMPag7JAEIjLnRvG(g5gJiUkIKOqRBj)
	O1o4Qh6m2gWpdP0qwUaFTDMvnEi9yG(False)
	i5xGCIRvcQlMemuO4jaYkWSwtD(False)
	return True
def o2XWqTVDKrFMPag7JAEIjLnRvG(g5gJiUkIKOqRBj):
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,Zg9FeADE84jSRIvPCrzYulw3sL)
	if not sudMiALnIV6pOlvta78QmJCUK(g5gJiUkIKOqRBj,True): return
	for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
		IydGcHrn4YOX1suSqJb8f = zZlsxj57ThCH(kqB5bPjyZI8QumW9a,'str','LINK_'+str(D0wIcOgK6BJtoEys2U),'__LINK__')
		if IydGcHrn4YOX1suSqJb8f: kk1U2oeQTlJO9VK4tp0uxGWzawmqvZ = anUm1Py2qpI(g5gJiUkIKOqRBj,str(D0wIcOgK6BJtoEys2U))
	anUm1Py2qpI(g5gJiUkIKOqRBj,Zg9FeADE84jSRIvPCrzYulw3sL)
	return
def wRYQPfobqUD0N9(g5gJiUkIKOqRBj,aM2tUZzCX4nNGhBV6DcSF7um):
	if aM2tUZzCX4nNGhBV6DcSF7um:
		xLiq4khYySNP26cwgn8pa = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if xLiq4khYySNP26cwgn8pa!=1: return
	kqB5bPjyZI8QumW9a = gsl7p1DcG5v2mHM(g5gJiUkIKOqRBj,Zg9FeADE84jSRIvPCrzYulw3sL)
	try: brAUlZfdFmt3TRJW2xX4.remove(kqB5bPjyZI8QumW9a)
	except: pass
	for D0wIcOgK6BJtoEys2U in range(1,OORhF2IYc1ZurfLn+1):
		GWOwzaVUyAH5JIC = w1wAdy5GghQiZKpzI.replace('___','_'+g5gJiUkIKOqRBj+'_'+str(D0wIcOgK6BJtoEys2U))
		YOJMgva7N9CkzGIht6d0jR2icbQP = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,GWOwzaVUyAH5JIC)
		try: brAUlZfdFmt3TRJW2xX4.remove(YOJMgva7N9CkzGIht6d0jR2icbQP)
		except: pass
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_'+g5gJiUkIKOqRBj)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if aM2tUZzCX4nNGhBV6DcSF7um:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		i5xGCIRvcQlMemuO4jaYkWSwtD(False)
	return
def StswF6Ve0dYI2yKj(g5gJiUkIKOqRBj):
	GSnYqw72jvkE0fC84eXFHJN = yUTYoAgth5iC43uLrdBH.getSetting('av.language.provider')
	C1syQtWVAK = yUTYoAgth5iC43uLrdBH.getSetting('av.language.code')
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'MENUS_CACHE_'+GSnYqw72jvkE0fC84eXFHJN+'_'+C1syQtWVAK,'%_MU'+g5gJiUkIKOqRBj+'_%')
	return
NTr8K9HgqUIOmfno = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
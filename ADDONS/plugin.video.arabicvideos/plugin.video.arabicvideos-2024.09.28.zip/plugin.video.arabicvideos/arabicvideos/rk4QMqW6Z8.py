# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'EGYBESTVIP'
j0jSEdTPJuG4XNvfpO = '_EGV_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,wlxviMOuNeQVct4ULsCEHXZm6yR2p,text):
	if   mode==220: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==221: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif mode==222: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==223: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==224: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url)
	elif mode==229: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,229,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBEST-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="i i-home"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,222)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="ba(.*?)<script',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for title,yDTPzhEBKVJl7CX81 in items:
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,221)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if 'html' not in yDTPzhEBKVJl7CX81: continue
			if not yDTPzhEBKVJl7CX81.endswith('/'): A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,221)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def hkO9B6NystZxC1VDvWe(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="rs_scroll"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?</i>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,224)
	return
def sF8AGonNID9x0J3TSUL2hd1Qjv(url):
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',url,221)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-FILTERS_MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="sub_nav(.*?)id="movies',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".+?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if yDTPzhEBKVJl7CX81=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,221)
	else: mbzIyKNqMVt0FQeOsPWc(url)
	return
def mbzIyKNqMVt0FQeOsPWc(url,wlxviMOuNeQVct4ULsCEHXZm6yR2p='1'):
	if wlxviMOuNeQVct4ULsCEHXZm6yR2p==Zg9FeADE84jSRIvPCrzYulw3sL: wlxviMOuNeQVct4ULsCEHXZm6yR2p = '1'
	if '/search' in url or '?' in url: hc5ePKxl4LJvEjDgTm = url + '&'
	else: hc5ePKxl4LJvEjDgTm = url + '?'
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm + 'page=' + wlxviMOuNeQVct4ULsCEHXZm6yR2p
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pda"(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[-1]
	elif '/series/' in url:
		HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="owl-carousel owl-carousel(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	else:
		HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="movies(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[-1]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		title = BtKvPnEQJx32Z(title)
		if '/movie/' in yDTPzhEBKVJl7CX81 or '/episode' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81.rstrip('/'),223,W8KBRzkdhlCxvF5sY2T)
		else:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,221,W8KBRzkdhlCxvF5sY2T)
	if len(items)>=16:
		WSxlsytkmPAopDnK6NEbZX89iBVfh1 = ['/movies','/tv','/search','/trending']
		wlxviMOuNeQVct4ULsCEHXZm6yR2p = int(wlxviMOuNeQVct4ULsCEHXZm6yR2p)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in url for B251BPiLbvG9UxszKtlI7YQHmoWw in WSxlsytkmPAopDnK6NEbZX89iBVfh1):
			for U6osjRDOqInL in range(0,1000,100):
				if int(wlxviMOuNeQVct4ULsCEHXZm6yR2p/100)*100==U6osjRDOqInL:
					for YjZN3ADmertFahUQIECW in range(U6osjRDOqInL,U6osjRDOqInL+100,10):
						if int(wlxviMOuNeQVct4ULsCEHXZm6yR2p/10)*10==YjZN3ADmertFahUQIECW:
							for ppRxt5ilkfHrGQFZ3 in range(YjZN3ADmertFahUQIECW,YjZN3ADmertFahUQIECW+10,1):
								if not wlxviMOuNeQVct4ULsCEHXZm6yR2p==ppRxt5ilkfHrGQFZ3 and ppRxt5ilkfHrGQFZ3!=0:
									A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+str(ppRxt5ilkfHrGQFZ3),url,221,Zg9FeADE84jSRIvPCrzYulw3sL,str(ppRxt5ilkfHrGQFZ3))
						elif YjZN3ADmertFahUQIECW!=0: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+str(YjZN3ADmertFahUQIECW),url,221,Zg9FeADE84jSRIvPCrzYulw3sL,str(YjZN3ADmertFahUQIECW))
						else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+str(1),url,221,Zg9FeADE84jSRIvPCrzYulw3sL,str(1))
				elif U6osjRDOqInL!=0: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+str(U6osjRDOqInL),url,221,Zg9FeADE84jSRIvPCrzYulw3sL,str(U6osjRDOqInL))
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+str(1),url,221)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-PLAY-1st')
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<td>التصنيف</td>.*?">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	Uk6P7mSl8sz1iKtq42caxuwRbJECAf,SBwiqPpnQYHTN = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	dG9ykeTSu1vx5g4p7DE8h,x31xQVfYFSwzdXouAWC = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	mmWuTRXAkFD9HOtf0hG6xybIJ2Zvrq = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('show_dl api" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if mmWuTRXAkFD9HOtf0hG6xybIJ2Zvrq:
		for yDTPzhEBKVJl7CX81 in mmWuTRXAkFD9HOtf0hG6xybIJ2Zvrq:
			if '/watch/' in yDTPzhEBKVJl7CX81: Uk6P7mSl8sz1iKtq42caxuwRbJECAf = yDTPzhEBKVJl7CX81
			elif '/download/' in yDTPzhEBKVJl7CX81: SBwiqPpnQYHTN = yDTPzhEBKVJl7CX81
		if Uk6P7mSl8sz1iKtq42caxuwRbJECAf!=Zg9FeADE84jSRIvPCrzYulw3sL: dG9ykeTSu1vx5g4p7DE8h = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,Uk6P7mSl8sz1iKtq42caxuwRbJECAf,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-PLAY-2nd')
		if SBwiqPpnQYHTN!=Zg9FeADE84jSRIvPCrzYulw3sL: x31xQVfYFSwzdXouAWC = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,SBwiqPpnQYHTN,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-PLAY-3rd')
	vqTQPxzCoMO4Ygn6w0 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="video".*?data-src="(.*?)"',dG9ykeTSu1vx5g4p7DE8h,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vqTQPxzCoMO4Ygn6w0:
		hc5ePKxl4LJvEjDgTm = vqTQPxzCoMO4Ygn6w0[0]
		if hc5ePKxl4LJvEjDgTm!=Zg9FeADE84jSRIvPCrzYulw3sL and 'uploaded.egybest.download' in hc5ePKxl4LJvEjDgTm and '/?id=_' not in hc5ePKxl4LJvEjDgTm:
			CNhQcnS0dI6UFjbvLoyx = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-PLAY-4th')
			SDHqlUrwN5RMv4Zb9CYn2JWAEou13k = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)" title="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if SDHqlUrwN5RMv4Zb9CYn2JWAEou13k:
				for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in SDHqlUrwN5RMv4Zb9CYn2JWAEou13k:
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81+'?named=ed.egybest.do__watch__mp4__'+YUCPADxT3NrgM)
			else:
				m0t48jnKhrQFJViguoMl9NBPp = hc5ePKxl4LJvEjDgTm.split('/')[2]
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(hc5ePKxl4LJvEjDgTm+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__watch')
		elif hc5ePKxl4LJvEjDgTm!=Zg9FeADE84jSRIvPCrzYulw3sL:
			m0t48jnKhrQFJViguoMl9NBPp = hc5ePKxl4LJvEjDgTm.split('/')[2]
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(hc5ePKxl4LJvEjDgTm+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__watch')
	iYLFwp64hP = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<table class="dls_table(.*?)</table>',x31xQVfYFSwzdXouAWC,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if iYLFwp64hP:
		iYLFwp64hP = iYLFwp64hP[0]
		iZbkKXB6n4E3cl9eJ08rCLuMUv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',iYLFwp64hP,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if iZbkKXB6n4E3cl9eJ08rCLuMUv:
			for YUCPADxT3NrgM,yDTPzhEBKVJl7CX81 in iZbkKXB6n4E3cl9eJ08rCLuMUv:
				if 'myegyvip' not in yDTPzhEBKVJl7CX81: continue
				if yDTPzhEBKVJl7CX81.count('/')>=2:
					m0t48jnKhrQFJViguoMl9NBPp = yDTPzhEBKVJl7CX81.split('/')[2]
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__download__mp4__'+YUCPADxT3NrgM)
	Xg0VS4uIxmvy2bNGpTrY = []
	for yDTPzhEBKVJl7CX81 in fo6s53yEnbklLpaJOzgR4Q01wxB:
		Xg0VS4uIxmvy2bNGpTrY.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(Xg0VS4uIxmvy2bNGpTrY,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'+')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBESTVIP-SEARCH-1st')
	dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('name="_token" value="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if dkKX8zLCs6yqBlD7Y5geZEpAicua20:
		url = qfzHe2Yr49+'/search?_token='+dkKX8zLCs6yqBlD7Y5geZEpAicua20[0]+'&q='+IGh3FSLfnog2BjN8s
		mbzIyKNqMVt0FQeOsPWc(url)
	return
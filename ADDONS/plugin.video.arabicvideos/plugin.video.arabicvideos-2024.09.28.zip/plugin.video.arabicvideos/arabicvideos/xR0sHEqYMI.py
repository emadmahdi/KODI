﻿# -*- coding: utf-8 -*-
from V1VREBsj92 import *
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,lZBvycDdmNaCrI0MXixV1kO5b4HRte):
	if lZBvycDdmNaCrI0MXixV1kO5b4HRte==Zg9FeADE84jSRIvPCrzYulw3sL: return
	if LfnWDFgRdJH4lZvt7yo28N==1:
		F9beXQjL6grmcWOdfJkN8S17PwE5 = HqjWaYEzp0D8eyQRud.getCurrentWindowDialogId()
		LLR7anYON6lK8mcuyv = HqjWaYEzp0D8eyQRud.Window(F9beXQjL6grmcWOdfJkN8S17PwE5)
		lZBvycDdmNaCrI0MXixV1kO5b4HRte = VikRx6TtEdzKFbBoeOHpSvg7PLlq(lZBvycDdmNaCrI0MXixV1kO5b4HRte)
		LLR7anYON6lK8mcuyv.getControl(311).setLabel(lZBvycDdmNaCrI0MXixV1kO5b4HRte)
	if LfnWDFgRdJH4lZvt7yo28N==0:
		TeDLBxpO03aonZFfQbNuK9S='X'
		if GGfPQnrJKEqMv2ZVxdD: u3QnjXsBkbhNcK0RO5Zf2PlvEUT = isinstance(lZBvycDdmNaCrI0MXixV1kO5b4HRte,str)
		else: u3QnjXsBkbhNcK0RO5Zf2PlvEUT = isinstance(lZBvycDdmNaCrI0MXixV1kO5b4HRte,unicode)
		if u3QnjXsBkbhNcK0RO5Zf2PlvEUT==True: TeDLBxpO03aonZFfQbNuK9S='U'
		VVrKHTnUxDkt0ISFERh=str(type(lZBvycDdmNaCrI0MXixV1kO5b4HRte))+wjs26GpVfNiCUERHJ+lZBvycDdmNaCrI0MXixV1kO5b4HRte+wjs26GpVfNiCUERHJ+TeDLBxpO03aonZFfQbNuK9S+wjs26GpVfNiCUERHJ
		for YjZN3ADmertFahUQIECW in range(0,len(lZBvycDdmNaCrI0MXixV1kO5b4HRte),1):
			VVrKHTnUxDkt0ISFERh += hex(ord(lZBvycDdmNaCrI0MXixV1kO5b4HRte[YjZN3ADmertFahUQIECW])).replace('0x',Zg9FeADE84jSRIvPCrzYulw3sL)+wjs26GpVfNiCUERHJ
		lZBvycDdmNaCrI0MXixV1kO5b4HRte = VikRx6TtEdzKFbBoeOHpSvg7PLlq(lZBvycDdmNaCrI0MXixV1kO5b4HRte)
		TeDLBxpO03aonZFfQbNuK9S='X'
		if GGfPQnrJKEqMv2ZVxdD: u3QnjXsBkbhNcK0RO5Zf2PlvEUT = isinstance(lZBvycDdmNaCrI0MXixV1kO5b4HRte, str)
		else: u3QnjXsBkbhNcK0RO5Zf2PlvEUT = isinstance(lZBvycDdmNaCrI0MXixV1kO5b4HRte, unicode)
		if u3QnjXsBkbhNcK0RO5Zf2PlvEUT==True: TeDLBxpO03aonZFfQbNuK9S='U'
		yWIVhzeOHqlnd=str(type(lZBvycDdmNaCrI0MXixV1kO5b4HRte))+wjs26GpVfNiCUERHJ+lZBvycDdmNaCrI0MXixV1kO5b4HRte+wjs26GpVfNiCUERHJ+TeDLBxpO03aonZFfQbNuK9S+wjs26GpVfNiCUERHJ
		for YjZN3ADmertFahUQIECW in range(0,len(lZBvycDdmNaCrI0MXixV1kO5b4HRte),1):
			yWIVhzeOHqlnd += hex(ord(lZBvycDdmNaCrI0MXixV1kO5b4HRte[YjZN3ADmertFahUQIECW])).replace('0x',Zg9FeADE84jSRIvPCrzYulw3sL)+wjs26GpVfNiCUERHJ
	return
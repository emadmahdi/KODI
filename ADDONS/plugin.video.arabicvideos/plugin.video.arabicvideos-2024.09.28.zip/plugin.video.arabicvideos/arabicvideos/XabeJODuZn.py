# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from V1VREBsj92 import *
bIPsOxjEpoH = qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᪐")
KSvGVmHDLlIuUZfJ = []
headers = {KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᪑"):Zg9FeADE84jSRIvPCrzYulw3sL}
def hdo2ZN5RuFYfynCUxMkAgWVSQ9X(source,TeDLBxpO03aonZFfQbNuK9S,url):
	zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+lU1fSmncFWjizwqZugyYBANML0(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ᪒")+source+IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ᪓")+TeDLBxpO03aonZFfQbNuK9S+vGg1hAkzqi8exVbN(u"ࠧࠡ࡟ࠪ᪔"))
	SMTDPAE4eWq6g8ZiCdft = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"ࠨࡦ࡬ࡧࡹ࠭᪕"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ᪖"),dn9ouNryjHiBFQOhASvX(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ᪗"))
	II79SczUa2VOMP8DXBtmgA4Yq6KxZo = LNma2eq3vEguwVtHjn.strftime(vhZ5qjay1z94JmcMOgXe(u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ᪘"),LNma2eq3vEguwVtHjn.gmtime(PPc8zbiVZnFkfXLBRv))
	Eh9DwNXB3LFnz1P = II79SczUa2VOMP8DXBtmgA4Yq6KxZo,url
	key = source+z1LI6x7aofZnmb+kI8qwbo6yER+z1LI6x7aofZnmb+str(NGiBmYp8vX9T426lHn7ue)
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = Zg9FeADE84jSRIvPCrzYulw3sL
	if key not in list(SMTDPAE4eWq6g8ZiCdft.keys()): SMTDPAE4eWq6g8ZiCdft[key] = [Eh9DwNXB3LFnz1P]
	else:
		if url not in str(SMTDPAE4eWq6g8ZiCdft[key]): SMTDPAE4eWq6g8ZiCdft[key].append(Eh9DwNXB3LFnz1P)
		else: oHkimLnwDKNxlheUuGAMQIg9jY7dz = A2MHFvoqpZ64gNbB(u"ࠬࡢ࡮้ࠡำหࠥอไโ์า๎ํࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥะูๆๆࠪ᪙")
	CSq3HMRKbsLnUZA1zV5e4cGQrDp = UwCT5Oz6Wo0BP
	for key in list(SMTDPAE4eWq6g8ZiCdft.keys()):
		SMTDPAE4eWq6g8ZiCdft[key] = list(set(SMTDPAE4eWq6g8ZiCdft[key]))
		CSq3HMRKbsLnUZA1zV5e4cGQrDp += len(SMTDPAE4eWq6g8ZiCdft[key])
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪚"),JP65RzKaScIf(u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ᪛")+oHkimLnwDKNxlheUuGAMQIg9jY7dz+ee3tnwl7avk(u"ࠨ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠧ᪜")+ykE045Tatx(u"ࠩ࡟ࡲࡡࡴࠧ᪝")+vhZ5qjay1z94JmcMOgXe(u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠศๆๅหห๋ษࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥ࠭᪞")+str(CSq3HMRKbsLnUZA1zV5e4cGQrDp))
	if CSq3HMRKbsLnUZA1zV5e4cGQrDp>=YXm2qAbu8Qsx(u"࠺७"):
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪟"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠷ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭᪠"))
		if jzydmKVUWrCv9D34F==vhZ5qjay1z94JmcMOgXe(u"࠷८"):
			QMDFxHB98NcLjbfdsvIJhRog0 = Zg9FeADE84jSRIvPCrzYulw3sL
			for key in list(SMTDPAE4eWq6g8ZiCdft.keys()):
				QMDFxHB98NcLjbfdsvIJhRog0 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+key
				ukmadLUcENb47iIhpzV1J = sorted(SMTDPAE4eWq6g8ZiCdft[key],reverse=vvglE69OFKBm817Nkc,key=lambda YHcj1fekJSbi908n6WZL4AyhT: YHcj1fekJSbi908n6WZL4AyhT[UwCT5Oz6Wo0BP])
				for II79SczUa2VOMP8DXBtmgA4Yq6KxZo,url in ukmadLUcENb47iIhpzV1J:
					QMDFxHB98NcLjbfdsvIJhRog0 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+II79SczUa2VOMP8DXBtmgA4Yq6KxZo+z1LI6x7aofZnmb+UAjMPLdITqWChbrcB(url)
				QMDFxHB98NcLjbfdsvIJhRog0 += x9PULjztJOpu7b(u"࠭࡜࡯࡞ࡱࠫ᪡")
			import XUbpWe5mRd
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = XUbpWe5mRd.XO1DeBA3qJgjH0syEZua(IYC4iPxkTRUE85namF6(u"ࠧࡗ࡫ࡧࡩࡴࡹࠧ᪢"),Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᪣"),Zg9FeADE84jSRIvPCrzYulw3sL,QMDFxHB98NcLjbfdsvIJhRog0)
			if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,A2MHFvoqpZ64gNbB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪤"),ZYTyoA483N(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭᪥"))
			else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪦"),ttC4VURALPYKh(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪᪧ"))
		if jzydmKVUWrCv9D34F!=-Mn5NGAdz6xc42s0:
			SMTDPAE4eWq6g8ZiCdft = {}
			nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ᪨"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭᪩"))
	if SMTDPAE4eWq6g8ZiCdft: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ᪪"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ᪫"),SMTDPAE4eWq6g8ZiCdft,B4GWT7zonF5yipbIwJmNUf6Vavg)
	return
def PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,source,TeDLBxpO03aonZFfQbNuK9S,url):
	if not ZZH6czYDb0:
		hdo2ZN5RuFYfynCUxMkAgWVSQ9X(source,TeDLBxpO03aonZFfQbNuK9S,url)
		return
	ZZH6czYDb0 = list(set(ZZH6czYDb0))
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = VVPSsRdu7YDg84qJLK(ZZH6czYDb0,source)
	if XcPLKthYTV.resolveonly:
		poekHjyF8V1J2KYWLZBQwnNsfEx = oMgiPWkxtO(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,source,vvglE69OFKBm817Nkc)
		return
	l1lNPhenH0T7fMFK2zBkGJu3LAd9,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,O5F0WEMl4PZVgNDakQweY8Bu,poekHjyF8V1J2KYWLZBQwnNsfEx = vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,[]
	o8ud1WkCTD3iNAqR6vB = not any(B251BPiLbvG9UxszKtlI7YQHmoWw in source for B251BPiLbvG9UxszKtlI7YQHmoWw in KfBl67yc98)
	if o8ud1WkCTD3iNAqR6vB:
		gLkmyn16BoRW92 = UwCT5Oz6Wo0BP
		tqaDEckgoWLVzU1yhA6TJNZwd5SHp = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,IYC4iPxkTRUE85namF6(u"ࠪࡰ࡮ࡹࡴࠨ᪬"),UixkloZbzGw28ujW56X(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡖࡅࡆࡉࡊࡊࡅࡅࠩ᪭"))
		UDRboaCuMEpz50rL3i = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡲࡩࡴࡶࠪ᪮"),ZYTyoA483N(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨ᪯"))
		pfQhOaqwdBS2k8ZiRA5MeXYUK = UwCT5Oz6Wo0BP
		for title,yDTPzhEBKVJl7CX81 in zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB):
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split(dn9ouNryjHiBFQOhASvX(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᪰"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
			if yDTPzhEBKVJl7CX81 in tqaDEckgoWLVzU1yhA6TJNZwd5SHp:
				gLkmyn16BoRW92 += Mn5NGAdz6xc42s0
				nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK] = xqPlYeVsWSkB703w9+title+u4IRSmrYMKkaHUBnDiLWh
			elif yDTPzhEBKVJl7CX81 in UDRboaCuMEpz50rL3i:
				gLkmyn16BoRW92 += Mn5NGAdz6xc42s0
				nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK] = PPQORjT2lc7SVkKwFI4D+title+u4IRSmrYMKkaHUBnDiLWh
			pfQhOaqwdBS2k8ZiRA5MeXYUK += Mn5NGAdz6xc42s0
		r1OMYvp0ViTG = [U2bWzwG8VdJsBqtR74ErDi3cg1v+UQS9lVew50DIyXrinWsMxTzA(u"ࠨใะูࠥาๅ๋฻ࠣหู้๊าใิหฯ࠭᪱")+u4IRSmrYMKkaHUBnDiLWh]
	else: gCdVXMcJEARlIkUr6KOBjZumvsYfyx = U2bWzwG8VdJsBqtR74ErDi3cg1v+ReLGYUQjz7C9iEd(u"ࠩฦาฯืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠩ᪲")+u4IRSmrYMKkaHUBnDiLWh
	while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
		iilB57Ff0Mhu8UqpXKzrtnaWoyLSw = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if o8ud1WkCTD3iNAqR6vB:
			if len(nnhWEIa6Tm)==Mn5NGAdz6xc42s0: lqQvOUWodZnhXLS2Vcuj6EtairFN = Mn5NGAdz6xc42s0
			else:
				NAJFrmGWfq2UVMPt = str(nnhWEIa6Tm).count(xqPlYeVsWSkB703w9)
				xK1QVT2GH76spmPegkru93UtaLiS = str(nnhWEIa6Tm).count(PPQORjT2lc7SVkKwFI4D)
				VnZSzKJsuctFLRBGf9oEal = len(nnhWEIa6Tm)-NAJFrmGWfq2UVMPt-xK1QVT2GH76spmPegkru93UtaLiS
				if HByjTem6EJP5sZb: gCdVXMcJEARlIkUr6KOBjZumvsYfyx = PPQORjT2lc7SVkKwFI4D+Vi1oNCM5kI7yJ0(u"ࠪࠤࠥࠦำ๋ศฬ࠾ࠬ᪳")+str(xK1QVT2GH76spmPegkru93UtaLiS)+u4IRSmrYMKkaHUBnDiLWh+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࠥࠦࠠๆฮ๊์้ฯ࠺ࠨ᪴")+str(VnZSzKJsuctFLRBGf9oEal)+xqPlYeVsWSkB703w9+ttC4VURALPYKh(u"ࠬา๊ะห࠽᪵ࠫ")+str(NAJFrmGWfq2UVMPt)+u4IRSmrYMKkaHUBnDiLWh
				else: gCdVXMcJEARlIkUr6KOBjZumvsYfyx = xqPlYeVsWSkB703w9+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ฬ๋ัฬ࠾᪶ࠬ")+str(NAJFrmGWfq2UVMPt)+u4IRSmrYMKkaHUBnDiLWh+ee3tnwl7avk(u"้ࠧࠡࠢࠣัํ่ๅห࠽᪷ࠫ")+str(VnZSzKJsuctFLRBGf9oEal)+PPQORjT2lc7SVkKwFI4D+eCpDE6wJtYUHn0GqK5(u"ࠨࠢࠣࠤุ๐ฦส࠼᪸ࠪ")+str(xK1QVT2GH76spmPegkru93UtaLiS)+u4IRSmrYMKkaHUBnDiLWh
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(gCdVXMcJEARlIkUr6KOBjZumvsYfyx,r1OMYvp0ViTG+nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP:
				iilB57Ff0Mhu8UqpXKzrtnaWoyLSw = vvglE69OFKBm817Nkc
				start,end = UwCT5Oz6Wo0BP,len(nnhWEIa6Tm)-Mn5NGAdz6xc42s0
				poekHjyF8V1J2KYWLZBQwnNsfEx = oMgiPWkxtO(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,source,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
				O5F0WEMl4PZVgNDakQweY8Bu = IYC4iPxkTRUE85namF6(u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࡣࡦࡲ࡬ࠨ᪹") if poekHjyF8V1J2KYWLZBQwnNsfEx else ykE045Tatx(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨ᪺ࠫ")
			elif lqQvOUWodZnhXLS2Vcuj6EtairFN>UwCT5Oz6Wo0BP: start,end = lqQvOUWodZnhXLS2Vcuj6EtairFN-Mn5NGAdz6xc42s0,lqQvOUWodZnhXLS2Vcuj6EtairFN-Mn5NGAdz6xc42s0
		else:
			if len(nnhWEIa6Tm)==Mn5NGAdz6xc42s0: lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			else: lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(gCdVXMcJEARlIkUr6KOBjZumvsYfyx,nnhWEIa6Tm)
			start,end = lqQvOUWodZnhXLS2Vcuj6EtairFN,lqQvOUWodZnhXLS2Vcuj6EtairFN
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0:
			O5F0WEMl4PZVgNDakQweY8Bu = UixkloZbzGw28ujW56X(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭᪻")
			break
		if iilB57Ff0Mhu8UqpXKzrtnaWoyLSw:
			O5F0WEMl4PZVgNDakQweY8Bu = IYC4iPxkTRUE85namF6(u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪ࡟ࡰࡰࡨࠫ᪼")
			poekHjyF8V1J2KYWLZBQwnNsfEx = oMgiPWkxtO([nnhWEIa6Tm[start]],[fo6s53yEnbklLpaJOzgR4Q01wxB[start]],source,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
			title,yDTPzhEBKVJl7CX81,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,WWuctLSlqizGgrK,CPv45ibdnBc = poekHjyF8V1J2KYWLZBQwnNsfEx[UwCT5Oz6Wo0BP]
			pJu045bGMOea,mVAXlhIxkUfWPzRHDYuNqi = a9ur1teAScibOZBKzgvFmyCUpo(title,yDTPzhEBKVJl7CX81,WWuctLSlqizGgrK,CPv45ibdnBc,source,TeDLBxpO03aonZFfQbNuK9S)
			if pJu045bGMOea in [vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ᪽ࠫ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ᪾"),A2MHFvoqpZ64gNbB(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨᪿࠩ")]:
				l1lNPhenH0T7fMFK2zBkGJu3LAd9 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				break
			else:
				if not VLa3Uijkb0vXeJSWcrPf8KOlz4uA: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = vGg1hAkzqi8exVbN(u"࡙ࠩ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡦࡢ࡫࡯ࡩࡩᫀ࠭")
				title = PPQORjT2lc7SVkKwFI4D+title+u4IRSmrYMKkaHUBnDiLWh
				poekHjyF8V1J2KYWLZBQwnNsfEx[UwCT5Oz6Wo0BP] = title,yDTPzhEBKVJl7CX81,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,WWuctLSlqizGgrK,CPv45ibdnBc
				lJCeZswAUfTWL = yDTPzhEBKVJl7CX81.split(eCpDE6wJtYUHn0GqK5(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᫁"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
				nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,ee3tnwl7avk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡖࡅࡆࡉࡊࡊࡅࡅࠩ᫂"),lJCeZswAUfTWL)
				cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡇࡃࡌࡐࡊࡊ᫃ࠧ"),lJCeZswAUfTWL,[VLa3Uijkb0vXeJSWcrPf8KOlz4uA,title,yDTPzhEBKVJl7CX81],E8RabFm1Kp5O0s)
			if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖ᫄ࠫ"): break
			EEVI25dSbDOyjv1xsXW = YXm2qAbu8Qsx(u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠠࠡࠩ᫅")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,ttC4VURALPYKh(u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬ᫆")) if VLa3Uijkb0vXeJSWcrPf8KOlz4uA.count(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)>lU1fSmncFWjizwqZugyYBANML0(u"࠳९") else SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+VLa3Uijkb0vXeJSWcrPf8KOlz4uA
			if wFYiVd4r12x7CAQBL5SPof(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ᫇") not in source: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᫈"),eCpDE6wJtYUHn0GqK5(u"ࠫฬ๊ำ๋ำไี๊ࠥๅࠡ์฼้้ࠦฬาสࠣื๏ืแาࠢ฽๎ึํࠧ᫉")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+EEVI25dSbDOyjv1xsXW,profile=E3i1eCBtN2w(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶ᫊ࠪ"))
			if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0 and VLa3Uijkb0vXeJSWcrPf8KOlz4uA: break
		for pfQhOaqwdBS2k8ZiRA5MeXYUK in range(start,end+Mn5NGAdz6xc42s0):
			XjW43kloBrmhYsCdML1xJAEZQzV = UwCT5Oz6Wo0BP if iilB57Ff0Mhu8UqpXKzrtnaWoyLSw else pfQhOaqwdBS2k8ZiRA5MeXYUK
			title,yDTPzhEBKVJl7CX81,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,WWuctLSlqizGgrK,CPv45ibdnBc = poekHjyF8V1J2KYWLZBQwnNsfEx[XjW43kloBrmhYsCdML1xJAEZQzV]
			nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK] = nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK].replace(PPQORjT2lc7SVkKwFI4D,Zg9FeADE84jSRIvPCrzYulw3sL).replace(xqPlYeVsWSkB703w9,Zg9FeADE84jSRIvPCrzYulw3sL).replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)
			if VLa3Uijkb0vXeJSWcrPf8KOlz4uA: nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK] = PPQORjT2lc7SVkKwFI4D+nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK]+u4IRSmrYMKkaHUBnDiLWh
			else: nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK] = xqPlYeVsWSkB703w9+nnhWEIa6Tm[pfQhOaqwdBS2k8ZiRA5MeXYUK]+u4IRSmrYMKkaHUBnDiLWh
	if O5F0WEMl4PZVgNDakQweY8Bu==dn9ouNryjHiBFQOhASvX(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧ᫋"): I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᫌ"),x9PULjztJOpu7b(u"ࠨๆ็วุ็ࠠๅษࠣ๎ําฯࠡีํีๆืวหࠢฯ๎ิฯࠠโ์๋ࠣีอࠠศๆไ๎ิ๐่ࠡ࠰࠱ࠤาอ่ๅࠢฦ๊ࠥะศฮอࠣ฽๋ࠦ็ัษࠣห้็๊ะ์๋ࠤๆ๐ࠠๆ๊สๆ฾ࠦรฯำ์ࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ั࠭ᫍ"))
	if not l1lNPhenH0T7fMFK2zBkGJu3LAd9 or O5F0WEMl4PZVgNDakQweY8Bu in [IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫᫎ"),ykE045Tatx(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨࠫ᫏")] or VLa3Uijkb0vXeJSWcrPf8KOlz4uA:
		LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(DKmLTA2yGtj(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡉ࡬ࡦࡣࡵࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲ࡿࢀࠫ᫐"))
	return
HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2,AAf5ycPR0xYZml1GNeDKBqM = [],[],[],[],[],[]
def oMgiPWkxtO(joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0,source,showDialogs):
	global HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2,AAf5ycPR0xYZml1GNeDKBqM
	CsaNhTtGm8,W8WxayiRHKzd,new = [],[],[]
	Tk5CeWKZwqrnxjO40(vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	count = len(ZZH6czYDb0)
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(count):
		HcoMfIznqXR3CaVuJKdTk.append(None)
		zbp604dB9TAc.append(None)
		LSv6gYwMc1uynOEWiNtrJeCA.append(None)
		ccoXKVLtw9egnRisNaz.append(None)
		T5C3sw1yW64okRAu9gG7HcE2.append(None)
		AAf5ycPR0xYZml1GNeDKBqM.append(UwCT5Oz6Wo0BP)
		title = joaMtxEpGfDXFPRHQgLKizyOT2b93[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[ZZxHfvyXBmYVjQ9rdAT8RaSKG].strip(wjs26GpVfNiCUERHJ).strip(ZYTyoA483N(u"ࠬࠬࠧ᫑")).strip(vhZ5qjay1z94JmcMOgXe(u"࠭࠿ࠨ᫒")).strip(yNBjYsgc23xoW(u"ࠧ࠰ࠩ᫓"))
		if count>Mn5NGAdz6xc42s0 and showDialogs: ZXWeI01flR(dn9ouNryjHiBFQOhASvX(u"ࠨใะูู๊ࠥาใิࠤึ่ๅࠡࠢࠪ᫔")+str(ZZxHfvyXBmYVjQ9rdAT8RaSKG+E3i1eCBtN2w(u"࠲॰")),title)
		nnCDcq4rubN9PgVxRY = [zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ᫕"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ᫖"),vhZ5qjay1z94JmcMOgXe(u"ࠫࡆࡑࡗࡂࡏࠪ᫗")]
		if source in nnCDcq4rubN9PgVxRY: HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = ExrB3z6q0LMHan(title,yDTPzhEBKVJl7CX81,source,ZZxHfvyXBmYVjQ9rdAT8RaSKG)
		else:
			if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠳ॱ"):
				awpK2Fx4zPMRu9l3 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=ExrB3z6q0LMHan,args=(title,yDTPzhEBKVJl7CX81,source,ZZxHfvyXBmYVjQ9rdAT8RaSKG))
				awpK2Fx4zPMRu9l3.start()
				W8WxayiRHKzd.append(awpK2Fx4zPMRu9l3)
				new.append(ZZxHfvyXBmYVjQ9rdAT8RaSKG)
				LNma2eq3vEguwVtHjn.sleep(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠴ॲ"))
	timeout = vGg1hAkzqi8exVbN(u"࠺࠵ॳ") if source==qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡇࡋࡘࡃࡐࠫ᫘") else vGg1hAkzqi8exVbN(u"࠸࠶ॴ")
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	for awpK2Fx4zPMRu9l3 in W8WxayiRHKzd: awpK2Fx4zPMRu9l3.join(timeout)
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(count):
		title = joaMtxEpGfDXFPRHQgLKizyOT2b93[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[ZZxHfvyXBmYVjQ9rdAT8RaSKG].strip(wjs26GpVfNiCUERHJ).strip(eCpDE6wJtYUHn0GqK5(u"࠭ࠦࠨ᫙")).strip(yyZPkLCRX1xcBDN(u"ࠧࡀࠩ᫚")).strip(yyZPkLCRX1xcBDN(u"ࠨ࠱ࠪ᫛"))
		lQoWVn5cyIsJFgY = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if AAf5ycPR0xYZml1GNeDKBqM[ZZxHfvyXBmYVjQ9rdAT8RaSKG]+Mn5NGAdz6xc42s0>timeout else vvglE69OFKBm817Nkc
		if HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG] and len(HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG])==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠹ॵ") and (HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG][UwCT5Oz6Wo0BP] or HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		elif lQoWVn5cyIsJFgY: EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = dn9ouNryjHiBFQOhASvX(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙࡯࡭ࡦࡦࠣࡓࡺࡺࠠࠩࠩ᫜")+str(timeout)+A2MHFvoqpZ64gNbB(u"ࠪࠤࡸ࡫ࡣࡰࡰࡧࡷ࠮࠭᫝"),[],[]
		else: EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = vGg1hAkzqi8exVbN(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡃࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨ᫞"),[],[]
		CsaNhTtGm8.append([title,yDTPzhEBKVJl7CX81,EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4])
		if ZZxHfvyXBmYVjQ9rdAT8RaSKG in new:
			lJCeZswAUfTWL = yDTPzhEBKVJl7CX81.split(dn9ouNryjHiBFQOhASvX(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᫟"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
			if not EEVI25dSbDOyjv1xsXW: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,yyZPkLCRX1xcBDN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇࠫ᫠"),lJCeZswAUfTWL,[EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4],E8RabFm1Kp5O0s)
			else: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,E3i1eCBtN2w(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡉࡅࡎࡒࡅࡅࠩ᫡"),lJCeZswAUfTWL,[EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4],E8RabFm1Kp5O0s)
	Tk5CeWKZwqrnxjO40(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
	return CsaNhTtGm8
def ExrB3z6q0LMHan(m0t48jnKhrQFJViguoMl9NBPp,url,source,D0wIcOgK6BJtoEys2U):
	global HcoMfIznqXR3CaVuJKdTk,AAf5ycPR0xYZml1GNeDKBqM
	AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = UwCT5Oz6Wo0BP
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ᫢")+m0t48jnKhrQFJViguoMl9NBPp+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭᫣")+url+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࠤࡢ࠭᫤"))
	yDTPzhEBKVJl7CX81,N9X3WLOct6aUVs0MEYAvxr = url,Zg9FeADE84jSRIvPCrzYulw3sL
	IIMvGtR0hwmYXVWA7HNP3eEJQS2 = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨ᫥")
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gzbrLIBSXAF2oVU4aJcK3iftWd75P(url,source)
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==NIBsHMvSXb(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᫦"):
		HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = yNBjYsgc23xoW(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᫧"),[],[]
		AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
		return HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U]
	elif A2MHFvoqpZ64gNbB(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᫨") in VLa3Uijkb0vXeJSWcrPf8KOlz4uA:
		N9X3WLOct6aUVs0MEYAvxr = lU1fSmncFWjizwqZugyYBANML0(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠫ᫩")
		yDTPzhEBKVJl7CX81 = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)[UwCT5Oz6Wo0BP]
		IIMvGtR0hwmYXVWA7HNP3eEJQS2,N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = OO0nZSWq5H4rJw(N9X3WLOct6aUVs0MEYAvxr,yDTPzhEBKVJl7CX81,source,D0wIcOgK6BJtoEys2U)
		if N9X3WLOct6aUVs0MEYAvxr==ZYTyoA483N(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫪"):
			AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
			return N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	elif VLa3Uijkb0vXeJSWcrPf8KOlz4uA: N9X3WLOct6aUVs0MEYAvxr = qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪ᫫")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:eCpDE6wJtYUHn0GqK5(u"࠸࠱ॶ")]
	if fo6s53yEnbklLpaJOzgR4Q01wxB:
		fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
		zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ᫬")+m0t48jnKhrQFJViguoMl9NBPp+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩ᫭")+IIMvGtR0hwmYXVWA7HNP3eEJQS2+Vi1oNCM5kI7yJ0(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ᫮")+url+JP65RzKaScIf(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ᫯")+yDTPzhEBKVJl7CX81+dn9ouNryjHiBFQOhASvX(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࡸࡀࠠ࡜ࠢࠪ᫰")+str(fo6s53yEnbklLpaJOzgR4Q01wxB)+ttC4VURALPYKh(u"ࠩࠣࡡࠬ᫱"))
	else: zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+dn9ouNryjHiBFQOhASvX(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪ᫲")+m0t48jnKhrQFJViguoMl9NBPp+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ᫳")+url+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ᫴")+yDTPzhEBKVJl7CX81+yNBjYsgc23xoW(u"࠭ࠠ࡞ࠢࠣࠤࡊࡸࡲࡰࡴࡶ࠾ࠥࡡࠠࠨ᫵")+N9X3WLOct6aUVs0MEYAvxr+NIBsHMvSXb(u"ࠧࠡ࡟ࠪ᫶"))
	N9X3WLOct6aUVs0MEYAvxr = UAjMPLdITqWChbrcB(N9X3WLOct6aUVs0MEYAvxr)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
	return N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def a9ur1teAScibOZBKzgvFmyCUpo(title,yDTPzhEBKVJl7CX81,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,source,TeDLBxpO03aonZFfQbNuK9S=Zg9FeADE84jSRIvPCrzYulw3sL):
	if fo6s53yEnbklLpaJOzgR4Q01wxB:
		while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			else: lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(vGg1hAkzqi8exVbN(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ᫷"), nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: Tbl0qZIrG9p = wFYiVd4r12x7CAQBL5SPof(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ᫸")
			else:
				mQ1H5zbKPevwuRZUVAYDp42N = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ᫹")+title+vhZ5qjay1z94JmcMOgXe(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ᫺")+yDTPzhEBKVJl7CX81+ee3tnwl7avk(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭᫻")+str(mQ1H5zbKPevwuRZUVAYDp42N)+qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࠠ࡞ࠩ᫼"))
				if YXm2qAbu8Qsx(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ᫽") in mQ1H5zbKPevwuRZUVAYDp42N and ZYTyoA483N(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ᫾") in mQ1H5zbKPevwuRZUVAYDp42N:
					EEVI25dSbDOyjv1xsXW,F9mNlIL0VX5uOT18sf,A7TBFRkU8Q3 = SpaWQdMNH9XqLt0z(mQ1H5zbKPevwuRZUVAYDp42N)
					if A7TBFRkU8Q3: mQ1H5zbKPevwuRZUVAYDp42N = A7TBFRkU8Q3[UwCT5Oz6Wo0BP]
					else: mQ1H5zbKPevwuRZUVAYDp42N = Zg9FeADE84jSRIvPCrzYulw3sL
				if not mQ1H5zbKPevwuRZUVAYDp42N: Tbl0qZIrG9p = UixkloZbzGw28ujW56X(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭᫿")
				else: Tbl0qZIrG9p = nTdpZOCUe7l(mQ1H5zbKPevwuRZUVAYDp42N,source,TeDLBxpO03aonZFfQbNuK9S)
			if Tbl0qZIrG9p in [UixkloZbzGw28ujW56X(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫᬀ"),ykE045Tatx(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬᬁ"),ttC4VURALPYKh(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠪᬂ"),vGg1hAkzqi8exVbN(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨᬃ")] or len(fo6s53yEnbklLpaJOzgR4Q01wxB)==jozVWcERh91GOF2NHXQiSwKqe8x(u"࠲ॷ"): break
			elif Tbl0qZIrG9p in [ykE045Tatx(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᬄ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩᬅ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡷࡶ࡮࡫ࡤࠨᬆ")]: break
			else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᬇ"),ttC4VURALPYKh(u"ࠫฬ๊ๅๅใฺ่๊๊ࠣࠦ็็ࠤัืศࠡ็็ๅࠥเ๊า้ࠪᬈ"))
	else:
		Tbl0qZIrG9p = ykE045Tatx(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩᬉ")
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81): Tbl0qZIrG9p = nTdpZOCUe7l(yDTPzhEBKVJl7CX81,source,TeDLBxpO03aonZFfQbNuK9S)
	return Tbl0qZIrG9p,fo6s53yEnbklLpaJOzgR4Q01wxB
def R7XmiIPODa6k8VxMFQlZtS(url,source):
	hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if ee3tnwl7avk(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᬊ") in url:
		hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5 = url.split(UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᬋ"),Mn5NGAdz6xc42s0)
		bbY0rUvML9u7TkPS8eofB5 = bbY0rUvML9u7TkPS8eofB5+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡡࡢࠫᬌ")+vhZ5qjay1z94JmcMOgXe(u"ࠩࡢࡣࠬᬍ")+yNBjYsgc23xoW(u"ࠪࡣࡤ࠭ᬎ")+lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡤࡥࠧᬏ")+A2MHFvoqpZ64gNbB(u"ࠬࡥ࡟ࠨᬐ")
		VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg,YlxJjQSZsg, = bbY0rUvML9u7TkPS8eofB5.split(x9PULjztJOpu7b(u"࠭࡟ࡠࠩᬑ"))[:E3i1eCBtN2w(u"࠸ॸ")]
	if not YUCPADxT3NrgM: YUCPADxT3NrgM = UixkloZbzGw28ujW56X(u"ࠧ࠱ࠩᬒ")
	else: YUCPADxT3NrgM = YUCPADxT3NrgM.replace(x9PULjztJOpu7b(u"ࠨࡲࠪᬓ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(wjs26GpVfNiCUERHJ,Zg9FeADE84jSRIvPCrzYulw3sL)
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.strip(x9PULjztJOpu7b(u"ࠩࡂࠫᬔ")).strip(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠳ࠬᬕ")).strip(NIBsHMvSXb(u"ࠫࠫ࠭ᬖ"))
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,eCpDE6wJtYUHn0GqK5(u"ࠬ࡮࡯ࡴࡶࠪᬗ"))
	if VaOH2318eP5yQWXrkcx: S41FAgod7yKYwPjLx0NIt9knMQ = VaOH2318eP5yQWXrkcx
	else: S41FAgod7yKYwPjLx0NIt9knMQ = m0t48jnKhrQFJViguoMl9NBPp
	S41FAgod7yKYwPjLx0NIt9knMQ = G9GCDqXJFAc(S41FAgod7yKYwPjLx0NIt9knMQ,JP65RzKaScIf(u"࠭࡮ࡢ࡯ࡨࠫᬘ"))
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace(A2MHFvoqpZ64gNbB(u"ࠧๆสสุึ࠭ᬙ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨีํีๆืࠧᬚ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩส่ࠥ࠭ᬛ"),wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	bbY0rUvML9u7TkPS8eofB5 = bbY0rUvML9u7TkPS8eofB5.replace(Vi1oNCM5kI7yJ0(u"้ࠪออิาࠩᬜ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(Vi1oNCM5kI7yJ0(u"ุࠫ๐ัโำࠪᬝ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬอไࠡࠩᬞ"),wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	S41FAgod7yKYwPjLx0NIt9knMQ = S41FAgod7yKYwPjLx0NIt9knMQ.replace(ReLGYUQjz7C9iEd(u"࠭ๅษษืีࠬᬟ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧิ์ิๅึ࠭ᬠ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(A2MHFvoqpZ64gNbB(u"ࠨษ็ࠤࠬᬡ"),wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	return hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg
def AKBoT7vNy1sGCSq98HWL2Rlc(url,source):
	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,feKw2ynYhdXcFt,VigSj1dHsDzNfLtkhvECeXy4c,fVMmZsFWPO4ljeEdSw,EtfLVkdeJgcUWASqCK8F1yTIzu9l,IIMvGtR0hwmYXVWA7HNP3eEJQS2 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,None,None,None,None,None
	hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = R7XmiIPODa6k8VxMFQlZtS(url,source)
	if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᬢ") in url:
		if   TeDLBxpO03aonZFfQbNuK9S==yNBjYsgc23xoW(u"ࠪࡩࡲࡨࡥࡥࠩᬣ"): TeDLBxpO03aonZFfQbNuK9S = wjs26GpVfNiCUERHJ+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"๊ࠫ็ึๅࠩᬤ")
		elif TeDLBxpO03aonZFfQbNuK9S==YXm2qAbu8Qsx(u"ࠬࡽࡡࡵࡥ࡫ࠫᬥ"): TeDLBxpO03aonZFfQbNuK9S = wjs26GpVfNiCUERHJ+wFYiVd4r12x7CAQBL5SPof(u"࠭ࠥๆึส๋ิฯࠧᬦ")
		elif TeDLBxpO03aonZFfQbNuK9S==E3i1eCBtN2w(u"ࠧࡣࡱࡷ࡬ࠬᬧ"): TeDLBxpO03aonZFfQbNuK9S = wjs26GpVfNiCUERHJ+lU1fSmncFWjizwqZugyYBANML0(u"ࠨࠧࠨู้อ็ะหࠣ์ฯำๅ๋ๆࠪᬨ")
		elif TeDLBxpO03aonZFfQbNuK9S==x9PULjztJOpu7b(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᬩ"): TeDLBxpO03aonZFfQbNuK9S = wjs26GpVfNiCUERHJ+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࠩࠪࠫสฮ็ํ่ࠬᬪ")
		elif TeDLBxpO03aonZFfQbNuK9S==Zg9FeADE84jSRIvPCrzYulw3sL: TeDLBxpO03aonZFfQbNuK9S = wjs26GpVfNiCUERHJ+UQS9lVew50DIyXrinWsMxTzA(u"ࠫࠪࠫࠥࠦࠩᬫ")
		if QAHN1PzTaF!=Zg9FeADE84jSRIvPCrzYulw3sL:
			if UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡳࡰ࠵ࠩᬬ") not in QAHN1PzTaF: QAHN1PzTaF = KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࠥࠨᬭ")+QAHN1PzTaF
			QAHN1PzTaF = wjs26GpVfNiCUERHJ+QAHN1PzTaF
		if YUCPADxT3NrgM!=Zg9FeADE84jSRIvPCrzYulw3sL:
			YUCPADxT3NrgM = NIBsHMvSXb(u"ࠧࠦࠧࠨࠩࠪࠫࠥࠦࠧࠪᬮ")+YUCPADxT3NrgM
			YUCPADxT3NrgM = wjs26GpVfNiCUERHJ+YUCPADxT3NrgM[-JP65RzKaScIf(u"࠼ॹ"):]
	if   jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡃࡎࡓࡆࡓࠧᬯ")		in source: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡄࡏ࡜ࡇࡍࠨᬰ")		in source: feKw2ynYhdXcFt	= ee3tnwl7avk(u"ࠪࡥࡰࡽࡡ࡮ࠩᬱ")
	elif OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ᬲ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫᬳ")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif YXm2qAbu8Qsx(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ᬴")		in source: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ZYTyoA483N(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧᬵ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif yyZPkLCRX1xcBDN(u"ࠨࡨࡤࡷࡪࡲࠧᬶ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif vGg1hAkzqi8exVbN(u"ࠩࡷ࠻ࡲ࡫ࡥ࡭ࠩᬷ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif vGg1hAkzqi8exVbN(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪᬸ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif UixkloZbzGw28ujW56X(u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭ᬹ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ReLGYUQjz7C9iEd(u"ࠬ࡬ࡡ࡫ࡧࡵࠫᬺ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ee3tnwl7avk(u"࠭แอำࠪᬻ")			in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡧࡣ࡭ࡩࡷ࠭ᬼ")
	elif ttC4VURALPYKh(u"ࠨใ็ื฼๐ๆࠨᬽ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬᬾ")
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪ࡫ࡩࡸࡩࡷࡧࠪᬿ")		in hc5ePKxl4LJvEjDgTm:   feKw2ynYhdXcFt	= UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᭀ")
	elif IYC4iPxkTRUE85namF6(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬᭁ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif yNBjYsgc23xoW(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭ᭂ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif Vi1oNCM5kI7yJ0(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᭃ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ZYTyoA483N(u"ࠨࡰࡨࡻࡨ࡯࡭ࡢ᭄ࠩ")		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif UixkloZbzGw28ujW56X(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧᭅ")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ZYTyoA483N(u"ࠪࡦࡴࡱࡲࡢࠩᭆ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ReLGYUQjz7C9iEd(u"ࠫࡹࡼࡦࡶࡰࠪᭇ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif wFYiVd4r12x7CAQBL5SPof(u"ࠬࡺࡶ࡬ࡵࡤࠫᭈ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif JP65RzKaScIf(u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧᭉ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᭊ")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif NIBsHMvSXb(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᭋ")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫᭌ")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif ReLGYUQjz7C9iEd(u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ᭍")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ᭎")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif dn9ouNryjHiBFQOhASvX(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ᭏")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif DKmLTA2yGtj(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ᭐")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡳࡧࡧࡱࡴࡪࡸࠨ᭑")	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= NIBsHMvSXb(u"ࠨࡴࡨࡨࡲࡵࡤࡹࠩ᭒")
	elif wFYiVd4r12x7CAQBL5SPof(u"ࠩࡼࡳࡺࡺࡵࠨ᭓")	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= vGg1hAkzqi8exVbN(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ᭔")
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ᭕")	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= UixkloZbzGw28ujW56X(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭᭖")
	elif okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ᭗")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif A2MHFvoqpZ64gNbB(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ᭘")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= vGg1hAkzqi8exVbN(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᭙")
	elif ee3tnwl7avk(u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ᭚")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬ᭛")
	elif ykE045Tatx(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ᭜")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= JP65RzKaScIf(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ᭝")
	elif UQS9lVew50DIyXrinWsMxTzA(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ᭞")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= YXm2qAbu8Qsx(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ᭟")
	elif YXm2qAbu8Qsx(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ᭠")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= yNBjYsgc23xoW(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ᭡")
	elif YXm2qAbu8Qsx(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭᭢")	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= ReLGYUQjz7C9iEd(u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ᭣")
	elif eCpDE6wJtYUHn0GqK5(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭᭤")		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ᭥")
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ᭦")	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ᭧")
	elif eCpDE6wJtYUHn0GqK5(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ᭨")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ee3tnwl7avk(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ᭩")
	elif ttC4VURALPYKh(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭᭪")	 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= A2MHFvoqpZ64gNbB(u"ࠬࡩࡡࡵࡥ࡫ࠫ᭫")
	elif JP65RzKaScIf(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵ᭬ࠧ")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ᭭")
	elif OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡸ࡬ࡨࡧࡳࠧ᭮")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡹ࡭ࡩࡨ࡭ࠨ᭯")
	elif A2MHFvoqpZ64gNbB(u"ࠪࡺ࡮ࡪࡨࡥࠩ᭰")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif UixkloZbzGw28ujW56X(u"ࠫࡲࡿࡶࡪࡦࠪ᭱")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif UixkloZbzGw28ujW56X(u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ᭲")		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ᭳")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ReLGYUQjz7C9iEd(u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ᭴")
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡩࡲࡺ࡮ࡪࠧ᭵")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= YXm2qAbu8Qsx(u"ࠩࡪࡳࡻ࡯ࡤࠨ᭶")
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ᭷") 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭᭸")
	elif DKmLTA2yGtj(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ᭹")	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= A2MHFvoqpZ64gNbB(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ᭺")
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ᭻")	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= JP65RzKaScIf(u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭᭼")
	elif lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭᭽") 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ᭾")
	elif ZYTyoA483N(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ᭿")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= IYC4iPxkTRUE85namF6(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ᮀ")
	elif IYC4iPxkTRUE85namF6(u"࠭ࡵࡱࡲࠪᮁ") 			in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡶࡲࡥࡳࡲ࠭ᮂ")
	elif DKmLTA2yGtj(u"ࠨࡷࡳࡦࠬᮃ") 			in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ykE045Tatx(u"ࠩࡸࡴࡧࡵ࡭ࠨᮄ")
	elif IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪᮅ") 		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ykE045Tatx(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫᮆ")
	elif E3i1eCBtN2w(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧᮇ") 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= IYC4iPxkTRUE85namF6(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨᮈ")
	elif yNBjYsgc23xoW(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᮉ")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= wFYiVd4r12x7CAQBL5SPof(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨᮊ")
	elif JP65RzKaScIf(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩᮋ") 		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= Vi1oNCM5kI7yJ0(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪᮌ")
	elif ee3tnwl7avk(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨᮍ") 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩᮎ")
	elif ttC4VURALPYKh(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪᮏ")	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫᮐ")
	elif OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬᮑ")	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ZYTyoA483N(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭ᮒ")
	elif NIBsHMvSXb(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪᮓ")		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= ttC4VURALPYKh(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫᮔ")
	if   feKw2ynYhdXcFt:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = YXm2qAbu8Qsx(u"ࠬิวึࠩᮕ"),feKw2ynYhdXcFt
	elif EtfLVkdeJgcUWASqCK8F1yTIzu9l:		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = vGg1hAkzqi8exVbN(u"࠭ࠥๆฯาำࠬᮖ"),EtfLVkdeJgcUWASqCK8F1yTIzu9l
	elif VigSj1dHsDzNfLtkhvECeXy4c:		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬᮗ"),VigSj1dHsDzNfLtkhvECeXy4c
	elif fVMmZsFWPO4ljeEdSw:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = yyZPkLCRX1xcBDN(u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧᮘ"),fVMmZsFWPO4ljeEdSw
	elif IIMvGtR0hwmYXVWA7HNP3eEJQS2:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = NIBsHMvSXb(u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩᮙ"),S41FAgod7yKYwPjLx0NIt9knMQ
	else:			rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = dn9ouNryjHiBFQOhASvX(u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫᮚ"),S41FAgod7yKYwPjLx0NIt9knMQ
	return rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM
def gzbrLIBSXAF2oVU4aJcK3iftWd75P(url,source):
	hc5ePKxl4LJvEjDgTm,EtfLVkdeJgcUWASqCK8F1yTIzu9l,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = R7XmiIPODa6k8VxMFQlZtS(url,source)
	if   qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡆࡑࡏࡂࡏࠪᮛ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = pQ1ZiwXaM0(hc5ePKxl4LJvEjDgTm,VaOH2318eP5yQWXrkcx)
	elif ttC4VURALPYKh(u"ࠬࡇࡋࡘࡃࡐࠫᮜ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = IyYirQzZGv(hc5ePKxl4LJvEjDgTm,TeDLBxpO03aonZFfQbNuK9S,YUCPADxT3NrgM)
	elif lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᮝ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = xVvmRMp79W(hc5ePKxl4LJvEjDgTm)
	elif yyZPkLCRX1xcBDN(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᮞ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᮟ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	elif KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡼࡳࡺࡺࡵࠨᮠ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = E3i1eCBtN2w(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᮡ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫᮢ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yNBjYsgc23xoW(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᮣ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᮤ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FVRYiGMdJh(hc5ePKxl4LJvEjDgTm)
	elif IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩᮥ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Ym4jT1kfeg(hc5ePKxl4LJvEjDgTm)
	elif qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪᮦ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yJTdSCOX7x(hc5ePKxl4LJvEjDgTm)
	elif Vi1oNCM5kI7yJ0(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫᮧ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = F91TH3ni7m(hc5ePKxl4LJvEjDgTm)
	elif A2MHFvoqpZ64gNbB(u"ࠪࡗࡍࡕࡆࡉࡃࠪᮨ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SkxuGj30n4(hc5ePKxl4LJvEjDgTm)
	elif Vi1oNCM5kI7yJ0(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ᮩ")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = AUPfVWo8Bn(hc5ePKxl4LJvEjDgTm,NNIKbSVi6Om372dg)
	elif UixkloZbzGw28ujW56X(u"ࠬࡇࡌࡎࡕࡗࡆࡆ᮪࠭")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = TUXrq2Wucb(hc5ePKxl4LJvEjDgTm)
	elif dn9ouNryjHiBFQOhASvX(u"࠭ࡌࡂࡔࡒ࡞ࡆ᮫࠭")		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SdHpbQKWze(hc5ePKxl4LJvEjDgTm)
	elif yyZPkLCRX1xcBDN(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩᮬ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = k560CXdIMv(hc5ePKxl4LJvEjDgTm)
	elif UixkloZbzGw28ujW56X(u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫᮭ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Szw076nNGR(hc5ePKxl4LJvEjDgTm)
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡤࡰࡦࡸࡡࡣࠩᮮ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = nFh5kfeVbduoPp9lz(hc5ePKxl4LJvEjDgTm)
	elif qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬᮯ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yeiIX36zJo(hc5ePKxl4LJvEjDgTm)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭᮰")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yeiIX36zJo(hc5ePKxl4LJvEjDgTm)
	elif wFYiVd4r12x7CAQBL5SPof(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ᮱")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = urBoEOnx02(hc5ePKxl4LJvEjDgTm)
	elif wFYiVd4r12x7CAQBL5SPof(u"࠭ࡴࡷࡨࡸࡲࠬ᮲")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡵࡸ࡮ࡷࡦ࠭᮳")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡶࡹ࠱࡫࠴ࡣࡰ࡯ࠪ᮴")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ᮵")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = QQHduikc5f(hc5ePKxl4LJvEjDgTm)
	elif OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ᮶")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fHmezsZOGV(hc5ePKxl4LJvEjDgTm)
	elif UixkloZbzGw28ujW56X(u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭᮷")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = hhALjcYd2fWB(hc5ePKxl4LJvEjDgTm)
	elif okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡼࡳ࠵ࡷࠪ᮸")			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = EE6g4ZBibI(hc5ePKxl4LJvEjDgTm)
	elif IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡦࡢ࡬ࡨࡶࠬ᮹")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = P4zITBLrK0(hc5ePKxl4LJvEjDgTm)
	elif yNBjYsgc23xoW(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᮺ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fAYMmzEO20(hc5ePKxl4LJvEjDgTm)
	elif E3i1eCBtN2w(u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩᮻ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fAYMmzEO20(hc5ePKxl4LJvEjDgTm)
	elif IYC4iPxkTRUE85namF6(u"ࠩࡦ࡭ࡲࡧ࠭࡭࡫ࡪ࡬ࡹ࠭ᮼ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gNX7Y4t0Sb(hc5ePKxl4LJvEjDgTm)
	elif vGg1hAkzqi8exVbN(u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭ᮽ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gNX7Y4t0Sb(hc5ePKxl4LJvEjDgTm)
	elif ttC4VURALPYKh(u"ࠫࡲࡿࡣࡪ࡯ࡤࠫᮾ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = wwKvyLS7uU(hc5ePKxl4LJvEjDgTm)
	elif Vi1oNCM5kI7yJ0(u"ࠬࡽࡥࡤ࡫ࡰࡥࠬᮿ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = CmrYlk2Py3bgvZu106neDaWzpcEs(hc5ePKxl4LJvEjDgTm)
	elif JP65RzKaScIf(u"࠭ࡢࡰ࡭ࡵࡥࠬᯀ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Y9cjIvMwV2(hc5ePKxl4LJvEjDgTm)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬᯁ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = tAvpx4RZWu(hc5ePKxl4LJvEjDgTm)
	elif vhZ5qjay1z94JmcMOgXe(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪᯂ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = R9Rm6XscNg(hc5ePKxl4LJvEjDgTm)
	elif UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨᯃ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = r1IcxTB74l(hc5ePKxl4LJvEjDgTm)
	elif ZYTyoA483N(u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨᯄ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif YXm2qAbu8Qsx(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬᯅ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = nI3TcUWd10(hc5ePKxl4LJvEjDgTm)
	elif yyZPkLCRX1xcBDN(u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫᯆ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = B8RiNLrIVh(hc5ePKxl4LJvEjDgTm)
	elif jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡵࡱࡤࡤࡱࠬᯇ") 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ykE045Tatx(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᯈ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA and VLa3Uijkb0vXeJSWcrPf8KOlz4uA!=dn9ouNryjHiBFQOhASvX(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯉ"): VLa3Uijkb0vXeJSWcrPf8KOlz4uA = vhZ5qjay1z94JmcMOgXe(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬᯊ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def PQdFebAH57halw1M(VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB):
	WWuctLSlqizGgrK,CPv45ibdnBc = [],[]
	for title,yDTPzhEBKVJl7CX81 in zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB):
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81):
			WWuctLSlqizGgrK.append(title)
			CPv45ibdnBc.append(yDTPzhEBKVJl7CX81)
	if not CPv45ibdnBc and not VLa3Uijkb0vXeJSWcrPf8KOlz4uA: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = ttC4VURALPYKh(u"ࠪࡊࡦ࡯࡬ࡦࡦࠪᯋ")
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,WWuctLSlqizGgrK,CPv45ibdnBc
def OO0nZSWq5H4rJw(N9X3WLOct6aUVs0MEYAvxr,url,source,D0wIcOgK6BJtoEys2U):
	global HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2
	ulNBWMPEiF = []
	for IIMvGtR0hwmYXVWA7HNP3eEJQS2 in [zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2]: IIMvGtR0hwmYXVWA7HNP3eEJQS2[D0wIcOgK6BJtoEys2U] = (lU1fSmncFWjizwqZugyYBANML0(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬᯌ"),[],[])
	II1HJTbh6XFp,pmSCifAcDwGkJrzsb1T4Euq = [j7HldantU8TLXsSQ,Xy7tcwx3hAQYoGm,PPEHU7VyJ5wBqWzKCMm4hSslxk9,jVOnHTRa4EAmzsy7h],[]
	if wFYiVd4r12x7CAQBL5SPof(u"ࠬ࡬ࡲࡥ࡮ࠪᯍ") in url: II1HJTbh6XFp,pmSCifAcDwGkJrzsb1T4Euq = [j7HldantU8TLXsSQ,Xy7tcwx3hAQYoGm,jVOnHTRa4EAmzsy7h],[ccoXKVLtw9egnRisNaz]
	if vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᯎ") in url: II1HJTbh6XFp,pmSCifAcDwGkJrzsb1T4Euq = [j7HldantU8TLXsSQ],[LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2]
	for IIMvGtR0hwmYXVWA7HNP3eEJQS2 in pmSCifAcDwGkJrzsb1T4Euq: IIMvGtR0hwmYXVWA7HNP3eEJQS2[D0wIcOgK6BJtoEys2U] = (Vi1oNCM5kI7yJ0(u"ࠧࡔ࡭࡬ࡴࡵ࡫ࡤࠨᯏ"),[],[])
	for IIMvGtR0hwmYXVWA7HNP3eEJQS2 in II1HJTbh6XFp:
		XfZIObwvneJGjkdRyrU = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=IIMvGtR0hwmYXVWA7HNP3eEJQS2,args=(url,source,D0wIcOgK6BJtoEys2U))
		ulNBWMPEiF.append(XfZIObwvneJGjkdRyrU)
		XfZIObwvneJGjkdRyrU.start()
		LNma2eq3vEguwVtHjn.sleep(NIBsHMvSXb(u"࠵ॺ"))
	AVetbzU9Nso1fCB4x,qIgoai8kcbZOd,D6mqeuc8v3YLoU0pkX27JQHbMBTSR,MDdL38tUwuhsFe = vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc
	timeout,step = ZYTyoA483N(u"࠸࠶ॻ"),DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
	for TAE1KYHWmGzoR in range(timeout//step):
		if not AVetbzU9Nso1fCB4x and zbp604dB9TAc[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]!=YXm2qAbu8Qsx(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩᯐ"): AVetbzU9Nso1fCB4x = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if not qIgoai8kcbZOd and LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]!=vhZ5qjay1z94JmcMOgXe(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪᯑ"): qIgoai8kcbZOd = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if not D6mqeuc8v3YLoU0pkX27JQHbMBTSR and ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]!=eCpDE6wJtYUHn0GqK5(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫᯒ"): D6mqeuc8v3YLoU0pkX27JQHbMBTSR = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if not MDdL38tUwuhsFe and T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]!=IK4zTnSMyGQpxEaesJAPVDY(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬᯓ"): MDdL38tUwuhsFe = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if AVetbzU9Nso1fCB4x and qIgoai8kcbZOd and D6mqeuc8v3YLoU0pkX27JQHbMBTSR and MDdL38tUwuhsFe: break
		if not zbp604dB9TAc[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and zbp604dB9TAc[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]: break
		if not LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]: break
		if not ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]: break
		if not T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]: break
		LNma2eq3vEguwVtHjn.sleep(step)
	for XfZIObwvneJGjkdRyrU in ulNBWMPEiF: XfZIObwvneJGjkdRyrU.join(wFYiVd4r12x7CAQBL5SPof(u"࠷ॼ"))
	jY1R9tQPzXcnoTBsJLHe = dn9ouNryjHiBFQOhASvX(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫᯔ")
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zbp604dB9TAc[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==DKmLTA2yGtj(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᯕ") or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += E3i1eCBtN2w(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠡࠩᯖ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠸࠱ॽ")]
	jY1R9tQPzXcnoTBsJLHe = UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧᯗ")
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==vGg1hAkzqi8exVbN(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᯘ") or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += x9PULjztJOpu7b(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠤࠬᯙ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:ttC4VURALPYKh(u"࠹࠲ॾ")]
	jY1R9tQPzXcnoTBsJLHe = DKmLTA2yGtj(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪᯚ")
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==vGg1hAkzqi8exVbN(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᯛ") or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += ttC4VURALPYKh(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠸࠿ࠦࠠࠨᯜ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:Vi1oNCM5kI7yJ0(u"࠺࠳ॿ")]
	jY1R9tQPzXcnoTBsJLHe = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠺࠭ᯝ")
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==JP65RzKaScIf(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯞ") or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += IK4zTnSMyGQpxEaesJAPVDY(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠵࠻ࠢࠣࠫᯟ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:wFYiVd4r12x7CAQBL5SPof(u"࠻࠴ঀ")]
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return jY1R9tQPzXcnoTBsJLHe,N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def j7HldantU8TLXsSQ(url,source,D0wIcOgK6BJtoEys2U):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,YXm2qAbu8Qsx(u"ࠪࡲࡦࡳࡥࠨᯠ"))
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	if qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᯡ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = tAvpx4RZWu(url)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࡺࡹࡥࡳࡥࡲࠫᯢ") in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = oU2fiWIkqgMjzrO(url)
	elif vhZ5qjay1z94JmcMOgXe(u"࠭ࡹࡰࡷࡷࡹࠬᯣ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(url)
	elif ee3tnwl7avk(u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧᯤ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(url)
	elif E3i1eCBtN2w(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧᯥ")	in url   : VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = End4XYrWitLP(url)
	elif ee3tnwl7avk(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤ᯦ࠫ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SpaWQdMNH9XqLt0z(url)
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫᯧ")		in url   : VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = xVvmRMp79W(url)
	elif ttC4VURALPYKh(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧᯨ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ETZDzC3rpIfuhALVRkSUlxXW21QNoH(url)
	elif A2MHFvoqpZ64gNbB(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭ᯩ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = rxR7qJpG2lFV6i(url)
	elif IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧᯪ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = J1J6LlmAnuXeOVBka(url)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡦ࠷ࡷࡷࡦࡸࠧᯫ")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = XnusLo18E03YSp9dctTNZ7FxP(url)
	elif UixkloZbzGw28ujW56X(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧᯬ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SU6JCeR1nYVaAqj3hgi(url)
	elif ykE045Tatx(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬᯭ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SU6JCeR1nYVaAqj3hgi(url)
	elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡹࡵࡨࡡ࡮ࠩᯮ") 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	elif wFYiVd4r12x7CAQBL5SPof(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭ᯯ") 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = grAa8UdWkpub(url)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨᯰ")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = qL7uoRwbpI2QFjHP51S(url)
	elif ReLGYUQjz7C9iEd(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪᯱ") 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = x1yIRrBg8Sf(url)
	elif KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ᯲")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ptDGgdlni7a5fVoxEjKYON6XC(url)
	elif yyZPkLCRX1xcBDN(u"ࠨࡷࡳࡦ᯳ࠬ") 			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url)
	elif ee3tnwl7avk(u"ࠩࡸࡴࡵ࠭᯴") 			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url)
	elif UixkloZbzGw28ujW56X(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ᯵") 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = pdvXniJubODEGh1fRVA2SHIM8c(url)
	elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭᯶") 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FFxdlpqBmr8V(url)
	elif eCpDE6wJtYUHn0GqK5(u"ࠬࡼࡩࡥࡤࡲࡦࠬ᯷")		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FF5NbecBfM1ED36lQ(url)
	elif YXm2qAbu8Qsx(u"࠭ࡶࡪࡦࡲࡾࡦ࠭᯸") 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Z89zqsFYGhdOw3ADCl5VtoSiQNXg(url)
	elif vGg1hAkzqi8exVbN(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ᯹") 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = RT28FCeLrhH01x(url)
	elif IYC4iPxkTRUE85namF6(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ᯺")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = NF9nrM2hfP3WIw(url)
	elif dn9ouNryjHiBFQOhASvX(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭᯻")	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = B17B4reZUshzTbcxEG8RCAop(url)
	else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	global zbp604dB9TAc
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA and VLa3Uijkb0vXeJSWcrPf8KOlz4uA!=eCpDE6wJtYUHn0GqK5(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᯼"): VLa3Uijkb0vXeJSWcrPf8KOlz4uA = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ᯽")
	zbp604dB9TAc[D0wIcOgK6BJtoEys2U] = VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def Xy7tcwx3hAQYoGm(url,source,D0wIcOgK6BJtoEys2U):
	global LSv6gYwMc1uynOEWiNtrJeCA
	if UixkloZbzGw28ujW56X(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭᯾") in url:
		LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = E3i1eCBtN2w(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡕ࡮࡭ࡵࡶࡥࡥࠩ᯿"),[],[]
		return
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	if wzX1klOfLVhb2B4ita(url): VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = hHGKjWOTmg8FVLqyCJQMtUeA7BaEI(url)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = T5T0LfYeA6(url)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB:
		if VLa3Uijkb0vXeJSWcrPf8KOlz4uA==ykE045Tatx(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᰀ"): VLa3Uijkb0vXeJSWcrPf8KOlz4uA = Zg9FeADE84jSRIvPCrzYulw3sL
		LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = yNBjYsgc23xoW(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᰁ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
		return
	LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def PPEHU7VyJ5wBqWzKCMm4hSslxk9(url,source,D0wIcOgK6BJtoEys2U):
	o4be19ApMtCrdf5 = Zg9FeADE84jSRIvPCrzYulw3sL
	CsaNhTtGm8 = vvglE69OFKBm817Nkc
	try:
		import resolveurl as KKUsV0CbeNfgyP7h6
		CsaNhTtGm8 = KKUsV0CbeNfgyP7h6.resolve(url)
	except Exception as dSBk0vXsUeruCTV9y2IQlJhKRx: o4be19ApMtCrdf5 = str(dSBk0vXsUeruCTV9y2IQlJhKRx)
	global ccoXKVLtw9egnRisNaz
	if not CsaNhTtGm8:
		if o4be19ApMtCrdf5==Zg9FeADE84jSRIvPCrzYulw3sL:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!=JP65RzKaScIf(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᰂ"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA = o4be19ApMtCrdf5.splitlines()[-Mn5NGAdz6xc42s0]
		ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U] = JP65RzKaScIf(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ᰃ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
		return
	ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U] = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[CsaNhTtGm8]
	return
def jVOnHTRa4EAmzsy7h(url,source,D0wIcOgK6BJtoEys2U):
	o4be19ApMtCrdf5 = Zg9FeADE84jSRIvPCrzYulw3sL
	CsaNhTtGm8 = vvglE69OFKBm817Nkc
	try:
		import yt_dlp as wNK2e1XjbvRq0TxACEMdQt7knp
		DHGTZgtxV6JLWSkb = wNK2e1XjbvRq0TxACEMdQt7knp.YoutubeDL({qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭ᰄ"): CR6in9cZKo2SqGFmrHOLdhYEVTjsBy})
		CsaNhTtGm8 = DHGTZgtxV6JLWSkb.extract_info(url,download=vvglE69OFKBm817Nkc)
	except Exception as dSBk0vXsUeruCTV9y2IQlJhKRx: o4be19ApMtCrdf5 = str(dSBk0vXsUeruCTV9y2IQlJhKRx)
	global T5C3sw1yW64okRAu9gG7HcE2
	if not CsaNhTtGm8 or NIBsHMvSXb(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ᰅ") not in list(CsaNhTtGm8.keys()):
		if o4be19ApMtCrdf5==Zg9FeADE84jSRIvPCrzYulw3sL:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!=ykE045Tatx(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩᰆ"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA = o4be19ApMtCrdf5.splitlines()[-Mn5NGAdz6xc42s0]
		T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U] = ee3tnwl7avk(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪᰇ")+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
	else:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for yDTPzhEBKVJl7CX81 in CsaNhTtGm8[eCpDE6wJtYUHn0GqK5(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩᰈ")]:
			nnhWEIa6Tm.append(yDTPzhEBKVJl7CX81[ReLGYUQjz7C9iEd(u"ࠩࡩࡳࡷࡳࡡࡵࠩᰉ")])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81[x9PULjztJOpu7b(u"ࠪࡹࡷࡲࠧᰊ")])
		T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U] = Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def hHGKjWOTmg8FVLqyCJQMtUeA7BaEI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡌࡋࡔࠨᰋ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡈࡎࡘࡅࡄࡖࡢ࡙ࡗࡒ࠭࠲ࡵࡷࠫᰌ"))
	headers = Pa6Q2LRkbtY0Id7nUNsZ.headers
	if YXm2qAbu8Qsx(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᰍ") in list(headers.keys()):
		yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[UixkloZbzGw28ujW56X(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᰎ")]
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81): return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return JP65RzKaScIf(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᰏ"),[],[]
def fAqtZCBGpF5rRl741IVSk2NuWY(XrEQ2VJFc6KxMwvdqGH5oUhICOu1):
	if wFYiVd4r12x7CAQBL5SPof(u"ࠩ࡯࡭ࡸࡺࠧᰐ") in str(type(XrEQ2VJFc6KxMwvdqGH5oUhICOu1)):
		CPv45ibdnBc = []
		for yDTPzhEBKVJl7CX81 in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
			if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡷࡹࡸࠧᰑ") in str(type(yDTPzhEBKVJl7CX81)): yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			CPv45ibdnBc.append(yDTPzhEBKVJl7CX81)
	else: CPv45ibdnBc = XrEQ2VJFc6KxMwvdqGH5oUhICOu1.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
	return CPv45ibdnBc
def VVPSsRdu7YDg84qJLK(A7TBFRkU8Q3,source):
	data = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡱ࡯ࡳࡵࠩᰒ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭ᰓ"),A7TBFRkU8Q3)
	if data:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zip(*data)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = list(nnhWEIa6Tm),list(fo6s53yEnbklLpaJOzgR4Q01wxB)
		return nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,CzJQSxB3rIlUY9sOH1X = [],[],[]
	for yDTPzhEBKVJl7CX81 in A7TBFRkU8Q3:
		if DKmLTA2yGtj(u"࠭࠯࠰ࠩᰔ") not in yDTPzhEBKVJl7CX81: continue
		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM = AKBoT7vNy1sGCSq98HWL2Rlc(yDTPzhEBKVJl7CX81,source)
		YUCPADxT3NrgM = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠧ࡝ࡦ࠮ࠫᰕ"),YUCPADxT3NrgM,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if YUCPADxT3NrgM: YUCPADxT3NrgM = int(YUCPADxT3NrgM[UwCT5Oz6Wo0BP])
		else: YUCPADxT3NrgM = UwCT5Oz6Wo0BP
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,Vi1oNCM5kI7yJ0(u"ࠨࡰࡤࡱࡪ࠭ᰖ"))
		CzJQSxB3rIlUY9sOH1X.append([rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp])
	if CzJQSxB3rIlUY9sOH1X:
		uLm9NQjaOevl1YWZ7RK5bghTSoE6tA = sorted(CzJQSxB3rIlUY9sOH1X,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: (key[NEc173Pr0jAwLF5OS],key[UwCT5Oz6Wo0BP],key[O4dklMvZ8ULcS],key[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],key[Mn5NGAdz6xc42s0],key[qdEKO42r3GhwmCDcHtxzJUR(u"࠹ঁ")],key[vhZ5qjay1z94JmcMOgXe(u"࠻ং")]))
		EaK7fXz6F9AbMJptQ12HlweoBd,qfXLp7dntsOZUhyIPW = [],[]
		for Eh9DwNXB3LFnz1P in uLm9NQjaOevl1YWZ7RK5bghTSoE6tA:
			rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp = Eh9DwNXB3LFnz1P
			if vhZ5qjay1z94JmcMOgXe(u"่ࠩๅ฻๊ࠧᰗ") in TeDLBxpO03aonZFfQbNuK9S:
				qfXLp7dntsOZUhyIPW.append(Eh9DwNXB3LFnz1P)
				continue
			if Eh9DwNXB3LFnz1P not in EaK7fXz6F9AbMJptQ12HlweoBd: EaK7fXz6F9AbMJptQ12HlweoBd.append(Eh9DwNXB3LFnz1P)
		EaK7fXz6F9AbMJptQ12HlweoBd = qfXLp7dntsOZUhyIPW+EaK7fXz6F9AbMJptQ12HlweoBd
		pfQhOaqwdBS2k8ZiRA5MeXYUK = UwCT5Oz6Wo0BP
		for rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,TeDLBxpO03aonZFfQbNuK9S,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp in EaK7fXz6F9AbMJptQ12HlweoBd:
			YUCPADxT3NrgM = str(YUCPADxT3NrgM) if YUCPADxT3NrgM else Zg9FeADE84jSRIvPCrzYulw3sL
			title = dn9ouNryjHiBFQOhASvX(u"ࠪื๏ืแาࠩᰘ")+wjs26GpVfNiCUERHJ+TeDLBxpO03aonZFfQbNuK9S+wjs26GpVfNiCUERHJ+rroVc9aI2diKHO1kbEe3s4tGWwX5q+wjs26GpVfNiCUERHJ+YUCPADxT3NrgM+wjs26GpVfNiCUERHJ+QAHN1PzTaF+wjs26GpVfNiCUERHJ+VaOH2318eP5yQWXrkcx
			if m0t48jnKhrQFJViguoMl9NBPp not in title: title = title+wjs26GpVfNiCUERHJ+m0t48jnKhrQFJViguoMl9NBPp
			title = title.replace(IYC4iPxkTRUE85namF6(u"ࠫࠪ࠭ᰙ"),Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
			pfQhOaqwdBS2k8ZiRA5MeXYUK += Mn5NGAdz6xc42s0
			title = str(pfQhOaqwdBS2k8ZiRA5MeXYUK)+A2MHFvoqpZ64gNbB(u"ࠬ࠴ࠠࠨᰚ")+title
			if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if fo6s53yEnbklLpaJOzgR4Q01wxB:
			data = zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB)
			if data: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,A2MHFvoqpZ64gNbB(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧᰛ"),A7TBFRkU8Q3,data,ggWsYrlq8fy2v)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = list(nnhWEIa6Tm),list(fo6s53yEnbklLpaJOzgR4Q01wxB)
	return nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def nFh5kfeVbduoPp9lz(url):
	if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠯࡯࠶ࡹ࠽࠭ᰜ") in url:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zKaqs0n5ZdrvWSTJYhy7(url)
		if fo6s53yEnbklLpaJOzgR4Q01wxB: return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
		return IYC4iPxkTRUE85namF6(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨᰝ"),[],[]
	return IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᰞ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def k560CXdIMv(url):
	ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93 = [],[]
	if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭ᰟ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,x9PULjztJOpu7b(u"ࠫࡌࡋࡔࠨᰠ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧᰡ"))
		if yyZPkLCRX1xcBDN(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᰢ") in Pa6Q2LRkbtY0Id7nUNsZ.headers:
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[ReLGYUQjz7C9iEd(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᰣ")]
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
			m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,YXm2qAbu8Qsx(u"ࠨࡰࡤࡱࡪ࠭ᰤ"))
			joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
	elif ykE045Tatx(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨᰥ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,dn9ouNryjHiBFQOhASvX(u"ࠪࡋࡊ࡚ࠧᰦ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭ᰧ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬᰨ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			nmytzfOdMhHY6Ao1KSx5NL = nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP]
			LE9gRTxzt856dh3K1F = Uu6MqoJxLtkimFsdYhc2Nvef(nmytzfOdMhHY6Ao1KSx5NL)
			OOm4vpntLQ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫᰩ"),LE9gRTxzt856dh3K1F,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if OOm4vpntLQ:
				OOm4vpntLQ = OOm4vpntLQ[UwCT5Oz6Wo0BP]
				OOm4vpntLQ = JGmfjhoyKZUl(vhZ5qjay1z94JmcMOgXe(u"ࠧ࡭࡫ࡶࡸࠬᰪ"),OOm4vpntLQ)
				for dict in OOm4vpntLQ:
					yDTPzhEBKVJl7CX81 = dict[ReLGYUQjz7C9iEd(u"ࠨࡨ࡬ࡰࡪ࠭ᰫ")]
					YUCPADxT3NrgM = dict[NIBsHMvSXb(u"ࠩ࡯ࡥࡧ࡫࡬ࠨᰬ")]
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,ReLGYUQjz7C9iEd(u"ࠪࡲࡦࡳࡥࠨᰭ"))
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(YUCPADxT3NrgM+wjs26GpVfNiCUERHJ+m0t48jnKhrQFJViguoMl9NBPp)
		elif vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᰮ") in Pa6Q2LRkbtY0Id7nUNsZ.headers:
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[yyZPkLCRX1xcBDN(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᰯ")]
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
			m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,DKmLTA2yGtj(u"࠭࡮ࡢ࡯ࡨࠫᰰ"))
			joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
		if Vi1oNCM5kI7yJ0(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧᰱ") in url:
			yDTPzhEBKVJl7CX81 = url.split(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡁࡸࡶࡱࡃࠧᰲ"))[Mn5NGAdz6xc42s0]
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࠩࠫᰳ"))[UwCT5Oz6Wo0BP]
			if yDTPzhEBKVJl7CX81:
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
				joaMtxEpGfDXFPRHQgLKizyOT2b93.append(UixkloZbzGw28ujW56X(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪᰴ"))
	else:
		ZZH6czYDb0.append(url)
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,ZYTyoA483N(u"ࠫࡳࡧ࡭ࡦࠩᰵ"))
		joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
	if not ZZH6czYDb0: return yyZPkLCRX1xcBDN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩᰶ"),[],[]
	elif len(ZZH6czYDb0)==Mn5NGAdz6xc42s0: yDTPzhEBKVJl7CX81 = ZZH6czYDb0[UwCT5Oz6Wo0BP]
	else:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(IK4zTnSMyGQpxEaesJAPVDY(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห᰷ࠫ"),joaMtxEpGfDXFPRHQgLKizyOT2b93)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return ttC4VURALPYKh(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᰸"),[],[]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	return eCpDE6wJtYUHn0GqK5(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᰹"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def oU2fiWIkqgMjzrO(url):
	headers = {eCpDE6wJtYUHn0GqK5(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᰺"):YXm2qAbu8Qsx(u"ࠪࡏࡴࡪࡩ࠰ࠩ᰻")+str(NGiBmYp8vX9T426lHn7ue)}
	for OEJ3PT81KtbZ in range(wFYiVd4r12x7CAQBL5SPof(u"࠻࠰ঃ")):
		LNma2eq3vEguwVtHjn.sleep(A2MHFvoqpZ64gNbB(u"࠰࠯࠳࠳࠴঄"))
		Pa6Q2LRkbtY0Id7nUNsZ = f9z23hDRKaHvgGoSCpX5u4i(YXm2qAbu8Qsx(u"ࠫࡌࡋࡔࠨ᰼"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ᰽"))
		if wFYiVd4r12x7CAQBL5SPof(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ᰾") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()):
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[A2MHFvoqpZ64gNbB(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ᰿")]
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ᱀")+headers[ykE045Tatx(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᱁")]
			return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		if Pa6Q2LRkbtY0Id7nUNsZ.code!=IYC4iPxkTRUE85namF6(u"࠵࠴࠼অ"): break
	return okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ᱂"),[],[]
def End4XYrWitLP(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ee3tnwl7avk(u"ࠫࡌࡋࡔࠨ᱃"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫ᱄"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ᱅"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81,YUCPADxT3NrgM = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		return Zg9FeADE84jSRIvPCrzYulw3sL,[YUCPADxT3NrgM],[yDTPzhEBKVJl7CX81]
	return yNBjYsgc23xoW(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ᱆"),[],[]
def g9dJL8N73E(url):
	if DKmLTA2yGtj(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࠪ᱇") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡊࡉ࡙࠭᱈"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫ᱉"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(YXm2qAbu8Qsx(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨ᱊"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		else: return vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨ᱋"),[],[]
	return UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᱌"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def TUXrq2Wucb(url):
	if ykE045Tatx(u"ࠧࡴࡧࡵࡺࡂ࠭ᱍ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡉࡈࡘࠬᱎ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡌࡎࡕࡗࡆࡆ࠳࠱ࡴࡶࠪᱏ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᱐"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		else:
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠦࡆࡲࡢࡢࡒ࡯ࡥࡾ࡫ࡲࡄࡱࡱࡸࡷࡵ࡬࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩࠥ᱑"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
				url = JDMo92nlwsAZydBPkpNzFvU.b64decode(url)
				if GGfPQnrJKEqMv2ZVxdD: url = url.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			else: return KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡐࡗ࡙ࡈࡁࠨ᱒"),[],[]
	return ykE045Tatx(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᱓"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def xVvmRMp79W(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,ttC4VURALPYKh(u"ࠧࡈࡇࡗࠫ᱔"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪ᱕"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = NkJiXgtIB5ECy(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ᱖"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	return eCpDE6wJtYUHn0GqK5(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ᱗"),[],[]
def SdHpbQKWze(url):
	if len(url)>vv3sNE8XCU2RAiyVaueTbD950pz(u"࠴࠳࠴আ"):
		url = url.strip(YXm2qAbu8Qsx(u"ࠫ࠴࠭᱘"))+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠵ࠧ᱙")
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,Vi1oNCM5kI7yJ0(u"࠭ࡇࡆࡖࠪᱚ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡆࡘࡏ࡛ࡃ࠰࠵ࡸࡺࠧᱛ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		if UwCT5Oz6Wo0BP and vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩᱜ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UixkloZbzGw28ujW56X(u"ࠩࠥࡰࡴࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᱝ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if HNRenB3EZX62qgSKMd4f:
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[ee3tnwl7avk(u"࠳ই")]
				HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡀࡸࡩࡲࡪࡲࡷࡂࡻࡧࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺࠧᱞ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if HNRenB3EZX62qgSKMd4f:
					nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = YE6NfDK7nZtwTs(HNRenB3EZX62qgSKMd4f[YXm2qAbu8Qsx(u"࠴ঈ")])
		elif len(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)<E3i1eCBtN2w(u"࠹࠶࠰উ"): yDTPzhEBKVJl7CX81 = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		else: return jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡂࡔࡒ࡞ࡆ࠭ᱟ"),[],[]
		return UixkloZbzGw28ujW56X(u"ࠬ࠭ᱠ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱡ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def SkxuGj30n4(url):
	if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧ࠰ࡦࡲࡻࡳ࠴ࡰࡩࡲࠪᱢ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,yNBjYsgc23xoW(u"ࠨࡉࡈࡘࠬᱣ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡈࡋࡅ࠲࠷ࡳࡵࠩᱤ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(dn9ouNryjHiBFQOhASvX(u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡺࡶࡦࡶࡰࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᱥ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᱦ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def FVRYiGMdJh(url):
	if UixkloZbzGw28ujW56X(u"ࠬࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩᱧ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,x9PULjztJOpu7b(u"࠭ࡇࡆࡖࠪᱨ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁ࠵ࡗ࠰࠵ࡸࡺࠧᱩ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(A2MHFvoqpZ64gNbB(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᱪ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		if eCpDE6wJtYUHn0GqK5(u"ࠩ࡫ࡸࡹࡶࠧᱫ") in yDTPzhEBKVJl7CX81: return lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᱬ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		return DKmLTA2yGtj(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭ᱭ"),[],[]
	return ykE045Tatx(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᱮ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def urBoEOnx02(url):
	hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
	Y3OmVPp2ARgBCjn = {OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᱯ"):zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᱰ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᱱ"):yyZPkLCRX1xcBDN(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᱲ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡔࡔ࡙ࡔࠨᱳ"),hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫᱴ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᱵ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: return A2MHFvoqpZ64gNbB(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨᱶ"),[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return yyZPkLCRX1xcBDN(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᱷ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def fHmezsZOGV(url):
	headers = {ZYTyoA483N(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫᱸ"):ReLGYUQjz7C9iEd(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᱹ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,JP65RzKaScIf(u"ࠪࡋࡊ࡚ࠧᱺ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭ᱻ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᱼ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if not yDTPzhEBKVJl7CX81: return yyZPkLCRX1xcBDN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪᱽ"),[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᱾"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def QQHduikc5f(url):
	hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
	Y3OmVPp2ARgBCjn = {x9PULjztJOpu7b(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ᱿"):OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᲀ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,vhZ5qjay1z94JmcMOgXe(u"ࠪࡔࡔ࡙ࡔࠨᲁ"),hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,A2MHFvoqpZ64gNbB(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ᲂ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧᲃ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if not yDTPzhEBKVJl7CX81: return x9PULjztJOpu7b(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪᲄ"),[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	if A2MHFvoqpZ64gNbB(u"ࠧࡩࡶࡷࡴࠬᲅ") not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = yyZPkLCRX1xcBDN(u"ࠨࡪࡷࡸࡵࡀࠧᲆ")+yDTPzhEBKVJl7CX81
	return ZYTyoA483N(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲇ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def F91TH3ni7m(url):
	WOry7DZPocFhH8p4,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = url,[],[]
	if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࠳ࡦࡰࡡࡹ࠱ࠪᲈ") in url:
		hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
		Y3OmVPp2ARgBCjn = {ZYTyoA483N(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᲉ"):YXm2qAbu8Qsx(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᲊ")}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ZYTyoA483N(u"࠭ࡐࡐࡕࡗࠫ᲋"),hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩ᲌"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀ࡟ࠧ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢࠨ࡟ࠪࠫࠬ᲍"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: WOry7DZPocFhH8p4 = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[UwCT5Oz6Wo0BP]
	return ReLGYUQjz7C9iEd(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᲎"),[Zg9FeADE84jSRIvPCrzYulw3sL],[WOry7DZPocFhH8p4]
def L1PV8IBk34(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ttC4VURALPYKh(u"ࠪࡋࡊ࡚ࠧ᲏"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪᲐ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Y65YT7juUnzFIJwGcyZMpO = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᲑ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if Y65YT7juUnzFIJwGcyZMpO:
		Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO[UwCT5Oz6Wo0BP][ttC4VURALPYKh(u"࠸ঊ"):]
		Y65YT7juUnzFIJwGcyZMpO = JDMo92nlwsAZydBPkpNzFvU.b64decode(Y65YT7juUnzFIJwGcyZMpO)
		if GGfPQnrJKEqMv2ZVxdD: Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲒ"),Y65YT7juUnzFIJwGcyZMpO,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL
	if not yDTPzhEBKVJl7CX81: return zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡗ࡚ࡋ࡛ࡎࠨᲓ"),[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	if E3i1eCBtN2w(u"ࠨࡪࡷࡸࡵ࠭Ე") not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = YXm2qAbu8Qsx(u"ࠩ࡫ࡸࡹࡶ࠺ࠨᲕ")+yDTPzhEBKVJl7CX81
	return jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ზ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def hhALjcYd2fWB(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,yNBjYsgc23xoW(u"ࠫࡌࡋࡔࠨᲗ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧᲘ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲙ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: return wFYiVd4r12x7CAQBL5SPof(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫᲚ"),[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᲛ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def tAvpx4RZWu(url):
	id = url.split(JP65RzKaScIf(u"ࠩ࠲ࠫᲜ"))[-tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱ঋ")]
	if yyZPkLCRX1xcBDN(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪᲝ") in url: url = url.replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫ࠴࡫࡭ࡣࡧࡧࠫᲞ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	url = url.replace(IYC4iPxkTRUE85namF6(u"ࠬ࠴ࡣࡰ࡯࠲ࠫᲟ"),ykE045Tatx(u"࠭࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡲ࡫ࡴࡢࡦࡤࡸࡦ࠵ࠧᲠ"))
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡈࡇࡗࠫᲡ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭Ტ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA = Vi1oNCM5kI7yJ0(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩᲣ")
	dSBk0vXsUeruCTV9y2IQlJhKRx = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᲤ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if dSBk0vXsUeruCTV9y2IQlJhKRx: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = dSBk0vXsUeruCTV9y2IQlJhKRx[UwCT5Oz6Wo0BP]
	url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲥ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not url and VLa3Uijkb0vXeJSWcrPf8KOlz4uA:
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
	yDTPzhEBKVJl7CX81 = url[UwCT5Oz6Wo0BP].replace(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡢ࡜ࠨᲦ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	F9mNlIL0VX5uOT18sf,A7TBFRkU8Q3 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
	Mles4QpWJtb0vzDZCj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(DKmLTA2yGtj(u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺࡝ࡽࠥ࡭ࡩࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡸࡩࡲࡦࡧࡱࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪᲧ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if Mles4QpWJtb0vzDZCj: YriOlGaJ7fHPov9b,Cvz4PanE5N,T8trGu27K3ohHA = Mles4QpWJtb0vzDZCj[UwCT5Oz6Wo0BP]
	else: YriOlGaJ7fHPov9b,Cvz4PanE5N,T8trGu27K3ohHA = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	T8trGu27K3ohHA = T8trGu27K3ohHA.replace(dn9ouNryjHiBFQOhASvX(u"ࠧ࡝࠱ࠪᲨ"),Vi1oNCM5kI7yJ0(u"ࠨ࠱ࠪᲩ"))
	Cvz4PanE5N = uumhMi6O4pk7Gjd5aTQqy2Z(Cvz4PanE5N)
	nnhWEIa6Tm = [PPQORjT2lc7SVkKwFI4D+ykE045Tatx(u"ࠩࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫᲪ")+Cvz4PanE5N+u4IRSmrYMKkaHUBnDiLWh]+F9mNlIL0VX5uOT18sf
	fo6s53yEnbklLpaJOzgR4Q01wxB = [T8trGu27K3ohHA]+A7TBFRkU8Q3
	lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫᲫ")+str(len(fo6s53yEnbklLpaJOzgR4Q01wxB)-DKmLTA2yGtj(u"࠲ঌ"))+lU1fSmncFWjizwqZugyYBANML0(u"๋ࠫࠥไโࠫࠪᲬ"),nnhWEIa6Tm)
	if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return JP65RzKaScIf(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᲭ"),[],[]
	elif lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP:
		EEHGwO3V8XjP651npWNz4gmlMABS = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[UwCT5Oz6Wo0BP]+eCpDE6wJtYUHn0GqK5(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠸࠵࠸ࠦࡶࡴ࡯ࡁࠬᲮ")+T8trGu27K3ohHA+ee3tnwl7avk(u"ࠧࠧࡶࡨࡼࡹࡺ࠽ࠨᲯ")+Cvz4PanE5N
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(wFYiVd4r12x7CAQBL5SPof(u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧᲰ")+EEHGwO3V8XjP651npWNz4gmlMABS+x9PULjztJOpu7b(u"ࠤࠬࠦᲱ"))
		return JP65RzKaScIf(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᲲ"),[],[]
	yDTPzhEBKVJl7CX81 =  fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def Y9cjIvMwV2(yDTPzhEBKVJl7CX81):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,x9PULjztJOpu7b(u"ࠫࡌࡋࡔࠨᲳ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄࡒࡏࡗࡇ࠭࠲ࡵࡷࠫᲴ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if x9PULjztJOpu7b(u"࠭࠮࡫ࡵࡲࡲࠬᲵ") in yDTPzhEBKVJl7CX81: url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(JP65RzKaScIf(u"ࠧࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧᲶ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ჷ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not url: return Vi1oNCM5kI7yJ0(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇࡕࡋࡓࡃࠪᲸ"),[],[]
	url = url[UwCT5Oz6Wo0BP]
	if UixkloZbzGw28ujW56X(u"ࠪ࡬ࡹࡺࡰࠨᲹ") not in url: url = ttC4VURALPYKh(u"ࠫ࡭ࡺࡴࡱ࠼ࠪᲺ")+url
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def SpaWQdMNH9XqLt0z(url):
	headers = { eCpDE6wJtYUHn0GqK5(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᲻") : Zg9FeADE84jSRIvPCrzYulw3sL }
	if qdEKO42r3GhwmCDcHtxzJUR(u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ᲼") in url:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠷ࡳࡵࠩᲽ"))
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᲾ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[items[UwCT5Oz6Wo0BP]]
		else:
			oHkimLnwDKNxlheUuGAMQIg9jY7dz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᲿ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if oHkimLnwDKNxlheUuGAMQIg9jY7dz:
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไศื็๎ࠬ᳀"),oHkimLnwDKNxlheUuGAMQIg9jY7dz[UwCT5Oz6Wo0BP])
				return E3i1eCBtN2w(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࠬ᳁")+oHkimLnwDKNxlheUuGAMQIg9jY7dz[UwCT5Oz6Wo0BP],[],[]
	else:
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = Vi1oNCM5kI7yJ0(u"ࠬࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠨ᳂")
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ᳃"))
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ᳄"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: return UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ᳅"),[],[]
		WOry7DZPocFhH8p4 = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]
		if IK4zTnSMyGQpxEaesJAPVDY(u"ࠩ࠱ࡶࡦࡸࠧ᳆") in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA or x9PULjztJOpu7b(u"ࠪ࠲ࡿ࡯ࡰࠨ᳇") in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA: return ykE045Tatx(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ᳈"),[],[]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ZYTyoA483N(u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᳉"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		EEFf6enQDxk = {}
		for VaOH2318eP5yQWXrkcx,B251BPiLbvG9UxszKtlI7YQHmoWw in items:
			EEFf6enQDxk[VaOH2318eP5yQWXrkcx] = B251BPiLbvG9UxszKtlI7YQHmoWw
		data = nWw3GirR9qxCFBOa5Dt1gdXmJMpy(EEFf6enQDxk)
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,WOry7DZPocFhH8p4,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠸ࡸࡤࠨ᳊"))
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥ࡙ࠢ࡭ࡩ࡫࡯࠯ࠬࡂ࡫ࡪࡺ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡯࡭ࡢࡩࡨ࠾ࠬ᳋"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: return lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ᳌"),[],[]
		download = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤ࠱࠮ࡄࠨࡼࠪࠩ᳍"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		ORuP1Qjt7DETJvNHKr,nnhWEIa6Tm,VRzd5ahswMGUtuCKpLjroP9T6kx47,fo6s53yEnbklLpaJOzgR4Q01wxB,xDHj9fZiWoTanbkBcG8FPwSm = [],[],[],[],[]
		for yDTPzhEBKVJl7CX81,title in items:
			if UixkloZbzGw28ujW56X(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ᳎") in yDTPzhEBKVJl7CX81:
				ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
				fo6s53yEnbklLpaJOzgR4Q01wxB = fo6s53yEnbklLpaJOzgR4Q01wxB + VRzd5ahswMGUtuCKpLjroP9T6kx47
				if ORuP1Qjt7DETJvNHKr[UwCT5Oz6Wo0BP]==dn9ouNryjHiBFQOhASvX(u"ࠫ࠲࠷ࠧ᳏"): nnhWEIa6Tm.append(ReLGYUQjz7C9iEd(u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ᳐")+wFYiVd4r12x7CAQBL5SPof(u"࠭࡭࠴ࡷ࠻ࠤࠬ᳑")+W4KwrJtUfaNF2Q3Coqsl869V1dbm)
				else:
					for title in ORuP1Qjt7DETJvNHKr:
						nnhWEIa6Tm.append(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࠡีํีๆืࠠฯษุࠤࠬ᳒")+vGg1hAkzqi8exVbN(u"ࠨ࡯࠶ࡹ࠽ࠦࠧ᳓")+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+title)
			else:
				title = title.replace(vhZ5qjay1z94JmcMOgXe(u"ࠩ࠯ࡰࡦࡨࡥ࡭࠼᳔ࠥࠫ"),Zg9FeADE84jSRIvPCrzYulw3sL)
				title = title.strip(vv3sNE8XCU2RAiyVaueTbD950pz(u"᳕ࠪࠦࠬ"))
				title = NIBsHMvSXb(u"ู๊ࠫࠥาใิࠤࠥิวึ᳖ࠢࠪ")+vGg1hAkzqi8exVbN(u"ࠬࠦ࡭ࡱ࠶᳗ࠣࠫ")+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+title
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		yDTPzhEBKVJl7CX81 = ykE045Tatx(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨ᳘") + download
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠻ࡴࡩ᳙ࠩ"))
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰ࠧ᳚"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,LfnWDFgRdJH4lZvt7yo28N,hash,uo2MTB486ONdtnQIfHl in items:
			title = qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࠣื๏ืแาࠢอั๊๐ไࠡะสูࠥ࠭᳛")+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࠤࡲࡶ࠴᳜ࠡࠩ")+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+uo2MTB486ONdtnQIfHl.split(JP65RzKaScIf(u"ࠫࡽ᳝࠭"))[Mn5NGAdz6xc42s0]
			yDTPzhEBKVJl7CX81 = lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿᳞ࠪ")+id+UQS9lVew50DIyXrinWsMxTzA(u"࠭ࠦ࡮ࡱࡧࡩࡂ᳟࠭")+LfnWDFgRdJH4lZvt7yo28N+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ᳠")+hash
			xDHj9fZiWoTanbkBcG8FPwSm.append(uo2MTB486ONdtnQIfHl)
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		xDHj9fZiWoTanbkBcG8FPwSm = set(xDHj9fZiWoTanbkBcG8FPwSm)
		B0TvEN4Dubzkt8K2la,xhnJiBWP4jftFcaTrdm = [],[]
		for title in nnhWEIa6Tm:
			W8q6caR1ouAm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IYC4iPxkTRUE85namF6(u"ࠣࠢࠫࡠࡩ࠰ࡸࡽ࡞ࡧ࠮࠮ࠬࠦࠣ᳡"),title+A2MHFvoqpZ64gNbB(u"᳢ࠩࠩࠪࠬ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for uo2MTB486ONdtnQIfHl in xDHj9fZiWoTanbkBcG8FPwSm:
				if W8q6caR1ouAm[UwCT5Oz6Wo0BP] in uo2MTB486ONdtnQIfHl:
					title = title.replace(W8q6caR1ouAm[UwCT5Oz6Wo0BP],uo2MTB486ONdtnQIfHl.split(Vi1oNCM5kI7yJ0(u"ࠪࡼ᳣ࠬ"))[Mn5NGAdz6xc42s0])
			B0TvEN4Dubzkt8K2la.append(title)
		for YjZN3ADmertFahUQIECW in range(len(fo6s53yEnbklLpaJOzgR4Q01wxB)):
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠦࠫࠬࠨ࠯ࠬࡂ࠭࠭ࡢࡤ᳤ࠫࠫࠩࠪࠧ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠬࠬࠦࠨ᳥")+B0TvEN4Dubzkt8K2la[YjZN3ADmertFahUQIECW]+jozVWcERh91GOF2NHXQiSwKqe8x(u"᳦࠭ࠦࠧࠩ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			xhnJiBWP4jftFcaTrdm.append( [B0TvEN4Dubzkt8K2la[YjZN3ADmertFahUQIECW],fo6s53yEnbklLpaJOzgR4Q01wxB[YjZN3ADmertFahUQIECW],items[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP],items[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]] )
		xhnJiBWP4jftFcaTrdm = sorted(xhnJiBWP4jftFcaTrdm, key=lambda zambDVfyYtWTNnu8jdsoIA1G: zambDVfyYtWTNnu8jdsoIA1G[O4dklMvZ8ULcS], reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		xhnJiBWP4jftFcaTrdm = sorted(xhnJiBWP4jftFcaTrdm, key=lambda zambDVfyYtWTNnu8jdsoIA1G: zambDVfyYtWTNnu8jdsoIA1G[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr], reverse=vvglE69OFKBm817Nkc)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for YjZN3ADmertFahUQIECW in range(len(xhnJiBWP4jftFcaTrdm)):
			nnhWEIa6Tm.append(xhnJiBWP4jftFcaTrdm[YjZN3ADmertFahUQIECW][UwCT5Oz6Wo0BP])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(xhnJiBWP4jftFcaTrdm[YjZN3ADmertFahUQIECW][Mn5NGAdz6xc42s0])
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return dn9ouNryjHiBFQOhASvX(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄ᳧ࠫ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def XnusLo18E03YSp9dctTNZ7FxP(url):
	Gi82lgtIxVsjSyqZU5EmBLkKw = url.split(ykE045Tatx(u"ࠨࡁ᳨ࠪ"))
	hc5ePKxl4LJvEjDgTm = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	headers = { A2MHFvoqpZ64gNbB(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᳩ") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࠶ࡖࡖࡅࡗ࠳࠱ࡴࡶࠪᳪ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vGg1hAkzqi8exVbN(u"ࠫࡕࡲࡥࡢࡵࡨࠤࡼࡧࡩࡵ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬᳫ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url = items[UwCT5Oz6Wo0BP]
	return JP65RzKaScIf(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᳬ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def J1J6LlmAnuXeOVBka(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	headers = { E3i1eCBtN2w(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ᳭ࠪ") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭ᳮ"))
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᳯ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]]
	else: return IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇ࡛࡚࡛ࡘࡕࡐࠬᳰ"),[],[]
def SU6JCeR1nYVaAqj3hgi(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	headers = { JP65RzKaScIf(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᳱ") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪᳲ"))
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠬ࡮ࡲࡦࡨࠥ࠰ࠧ࠮ࡨࡵࡶ࠱࠮ࡄ࠯ࠢࠨᳳ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]]
	else: return UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ᳴"),[],[]
def P4zITBLrK0(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if YXm2qAbu8Qsx(u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࠫᳵ") in url:
		hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
		Y3OmVPp2ARgBCjn = {x9PULjztJOpu7b(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᳶ"):ZYTyoA483N(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ᳷")}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡔࡔ࡙ࡔࠨ᳸"),hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠶ࡳࡪࠧ᳹"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		if CNhQcnS0dI6UFjbvLoyx.startswith(ttC4VURALPYKh(u"ࠬ࡮ࡴࡵࡲࠪᳺ")): hc5ePKxl4LJvEjDgTm = CNhQcnS0dI6UFjbvLoyx
		else:
			JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(A2MHFvoqpZ64gNbB(u"࠭ࠧࠨࡵࡵࡧࡂࡡࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜ࠩࠥࡡࠬ࠭ࠧ᳻"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if JaqiYfEglZDvmwQNS8zR:
				hc5ePKxl4LJvEjDgTm = JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP]
				JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠧࡴࡱࡸࡶࡨ࡫࠽ࠩ࠰࠭ࡃ࠮ࡡࠦࠥ࡟ࠪ᳼"),hc5ePKxl4LJvEjDgTm,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if JaqiYfEglZDvmwQNS8zR:
					hc5ePKxl4LJvEjDgTm = UAjMPLdITqWChbrcB(JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP])
					return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif yyZPkLCRX1xcBDN(u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩ᳽") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,ZYTyoA483N(u"ࠩࡊࡉ࡙࠭᳾"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠴ࡷࡹ࠭᳿"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		if NIBsHMvSXb(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᴀ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): hc5ePKxl4LJvEjDgTm = Pa6Q2LRkbtY0Id7nUNsZ.headers[x9PULjztJOpu7b(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᴁ")]
		else: hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴂ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	if A2MHFvoqpZ64gNbB(u"ࠧ࠰ࡸ࠲ࠫᴃ") in hc5ePKxl4LJvEjDgTm or yyZPkLCRX1xcBDN(u"ࠨ࠱ࡩ࠳ࠬᴄ") in hc5ePKxl4LJvEjDgTm:
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace(UQS9lVew50DIyXrinWsMxTzA(u"ࠩ࠲ࡪ࠴࠭ᴅ"),dn9ouNryjHiBFQOhASvX(u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩᴆ"))
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace(A2MHFvoqpZ64gNbB(u"ࠫ࠴ࡼ࠯ࠨᴇ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫᴈ"))
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,dn9ouNryjHiBFQOhASvX(u"࠭ࡐࡐࡕࡗࠫᴉ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪᴊ"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vhZ5qjay1z94JmcMOgXe(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᴋ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,title in items:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(YXm2qAbu8Qsx(u"ࠩ࡟ࡠࠬᴌ"),Zg9FeADE84jSRIvPCrzYulw3sL)
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᴍ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if items:
				yDTPzhEBKVJl7CX81 = items[UwCT5Oz6Wo0BP]
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(ttC4VURALPYKh(u"ࠫࡡࡢࠧᴎ"),Zg9FeADE84jSRIvPCrzYulw3sL)
				nnhWEIa6Tm.append(Zg9FeADE84jSRIvPCrzYulw3sL)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	else: return lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴏ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return DKmLTA2yGtj(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫᴐ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def EE6g4ZBibI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,yyZPkLCRX1xcBDN(u"ࠧࡈࡇࡗࠫᴑ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨᴒ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if IYC4iPxkTRUE85namF6(u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬᴓ") in url or IK4zTnSMyGQpxEaesJAPVDY(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫᴔ") in url:
		if UixkloZbzGw28ujW56X(u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧᴕ") in url:
			hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(A2MHFvoqpZ64gNbB(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴖ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
		else: hc5ePKxl4LJvEjDgTm = url
		if yyZPkLCRX1xcBDN(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭ᴗ") not in hc5ePKxl4LJvEjDgTm: return ReLGYUQjz7C9iEd(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴘ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡉࡈࡘࠬᴙ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩᴚ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭ᴛ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(E3i1eCBtN2w(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᴜ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a in items:
				nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	elif E3i1eCBtN2w(u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧᴝ") in url:
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪᴞ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,ZYTyoA483N(u"ࠧࡈࡇࡗࠫᴟ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨᴠ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IYC4iPxkTRUE85namF6(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᴡ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP]
		nnhWEIa6Tm.append(Zg9FeADE84jSRIvPCrzYulw3sL)
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(JaqiYfEglZDvmwQNS8zR)
	elif IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡲࡩ࡯࡭ࠪᴢ") in url:
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠫࡁࡩࡥ࡯ࡶࡨࡶࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᴣ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			return NIBsHMvSXb(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴤ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒ࡚ࡘ࠺ࡕࠨᴥ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def Ym4jT1kfeg(url):
	if dn9ouNryjHiBFQOhASvX(u"ࠧࡀࡩࡨࡸࡂ࠭ᴦ") in url:
		yDTPzhEBKVJl7CX81 = url.split(ykE045Tatx(u"ࠨࡁࡪࡩࡹࡃࠧᴧ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
		yDTPzhEBKVJl7CX81 = JDMo92nlwsAZydBPkpNzFvU.b64decode(yDTPzhEBKVJl7CX81)
		if GGfPQnrJKEqMv2ZVxdD: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,DKmLTA2yGtj(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᴨ"))
		return eCpDE6wJtYUHn0GqK5(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᴩ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	website = PhpFa6EdVS[ee3tnwl7avk(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ᴪ")][UwCT5Oz6Wo0BP]
	headers = {tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᴫ"):website}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡇࡆࡖࠪᴬ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡆ࠲࠸࡮ࡥࠩᴭ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,x9PULjztJOpu7b(u"ࠨࡷࡵࡰࠬᴮ"))
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴯ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠥࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠨࠪ࠱࠮ࡄ࠯ࠧࠣᴰ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠦ࡫࡯࡬ࡦ࠼ࠪࠬ࠳࠰࠿ࠪࠩࠥᴱ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᴲ")+website
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	if Vi1oNCM5kI7yJ0(u"࠭࡮ࡢ࡯ࡨࡁࠧ࡞ࡴࡰ࡭ࡨࡲࠧ࠭ᴳ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		lR0EwfcTGVZjuhqFk5eJoQ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᴴ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if lR0EwfcTGVZjuhqFk5eJoQ:
			yDTPzhEBKVJl7CX81 = lR0EwfcTGVZjuhqFk5eJoQ[UwCT5Oz6Wo0BP]
			yDTPzhEBKVJl7CX81 = JDMo92nlwsAZydBPkpNzFvU.b64decode(yDTPzhEBKVJl7CX81)
			if GGfPQnrJKEqMv2ZVxdD: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᴵ"))
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠩ࡫ࡸࡹࡶ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠱࠭ᴶ"),yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᴷ")+website
				return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return eCpDE6wJtYUHn0GqK5(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᴸ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def AUPfVWo8Bn(url,NNIKbSVi6Om372dg):
	joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = [],[]
	if ee3tnwl7avk(u"ࠬ࠵࠱࠰ࠩᴹ") in url:
		yDTPzhEBKVJl7CX81 = url.replace(lU1fSmncFWjizwqZugyYBANML0(u"࠭࠯࠲࠱ࠪᴺ"),dn9ouNryjHiBFQOhASvX(u"ࠧ࠰࠶࠲ࠫᴻ"))
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,vGg1hAkzqi8exVbN(u"ࠨࡉࡈࡘࠬᴼ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠲ࡵࡷࠫᴽ"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠪࡀࡻ࡯ࡤࡦࡱࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡩ࡫࡯࠿ࠩᴾ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴿ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in items:
				if yDTPzhEBKVJl7CX81 not in ZZH6czYDb0:
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,Vi1oNCM5kI7yJ0(u"ࠬࡴࡡ࡮ࡧࠪᵀ"))
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp+F4skx1A3wOEh9lmPuZMnpCzR+YUCPADxT3NrgM)
			return Zg9FeADE84jSRIvPCrzYulw3sL,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
	elif YXm2qAbu8Qsx(u"࠭࠯ࡥ࠱ࠪᵁ") in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,wFYiVd4r12x7CAQBL5SPof(u"ࠧࡈࡇࡗࠫᵂ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠲࡯ࡦࠪᵃ"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵄ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace(vhZ5qjay1z94JmcMOgXe(u"ࠪ࠳࠶࠵ࠧᵅ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫ࠴࠺࠯ࠨᵆ"))
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,A2MHFvoqpZ64gNbB(u"ࠬࡍࡅࡕࠩᵇ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠸ࡸࡤࠨᵈ"))
			CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(E3i1eCBtN2w(u"ࠧࡤ࡮ࡤࡷࡸ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᵉ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81: return yyZPkLCRX1xcBDN(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᵊ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	elif vhZ5qjay1z94JmcMOgXe(u"ࠩ࠲ࡶࡴࡲࡥ࠰ࠩᵋ") in url:
		headers = {ee3tnwl7avk(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᵌ"):NNIKbSVi6Om372dg}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,vhZ5qjay1z94JmcMOgXe(u"ࠫࡌࡋࡔࠨᵍ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠸ࡹ࡮ࠧᵎ"))
		yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[wFYiVd4r12x7CAQBL5SPof(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᵏ")]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,UixkloZbzGw28ujW56X(u"ࠧࡈࡇࡗࠫᵐ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠵ࡵࡪࠪᵑ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = ymNcGjZfWdUuv2sSpelH(yDTPzhEBKVJl7CX81,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
	elif Vi1oNCM5kI7yJ0(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ᵒ") in url:
		hc5ePKxl4LJvEjDgTm = url.replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧᵓ"),yyZPkLCRX1xcBDN(u"ࠫ࠴ࡹࡣࡳ࡫ࡳࡸ࠴࠭ᵔ"))
		Y3OmVPp2ARgBCjn = {zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᵕ"):NNIKbSVi6Om372dg}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,JP65RzKaScIf(u"࠭ࡇࡆࡖࠪᵖ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠼ࡴࡩࠩᵗ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᵘ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡊࡉ࡙࠭ᵙ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠹ࡷ࡬ࠬᵚ"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			if yNBjYsgc23xoW(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᵛ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()):
				yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᵜ")]
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,wFYiVd4r12x7CAQBL5SPof(u"࠭ࡇࡆࡖࠪᵝ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠾ࡴࡩࠩᵞ"))
				yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
				VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = ymNcGjZfWdUuv2sSpelH(yDTPzhEBKVJl7CX81,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
				if ZZH6czYDb0: return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
			elif tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩᵟ") in yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(Vi1oNCM5kI7yJ0(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪᵠ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠪ࠳࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧᵡ"))
				return wFYiVd4r12x7CAQBL5SPof(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᵢ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return DKmLTA2yGtj(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᵣ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	return dn9ouNryjHiBFQOhASvX(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪᵤ"),[],[]
def nI3TcUWd10(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,A2MHFvoqpZ64gNbB(u"ࠧࡈࡇࡗࠫᵥ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳࠱ࡴࡶࠪᵦ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	data = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠩࠥࡥࡨࡺࡩࡰࡰࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵧ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if data:
		cB10urUPnl,id,uODM6CAnSGgIxastoEph = data[UwCT5Oz6Wo0BP]
		data = ee3tnwl7avk(u"ࠪࡳࡵࡃࠧᵨ")+cB10urUPnl+qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࠫ࡯ࡤ࠾ࠩᵩ")+id+yNBjYsgc23xoW(u"ࠬࠬࡦ࡯ࡣࡰࡩࡂ࠭ᵪ")+uODM6CAnSGgIxastoEph
		headers = {ee3tnwl7avk(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᵫ"):ykE045Tatx(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ᵬ")}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,YXm2qAbu8Qsx(u"ࠨࡒࡒࡗ࡙࠭ᵭ"),url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠳ࡰࡧࠫᵮ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠪࠦࡷ࡫ࡦࡦࡴࡨࡶࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᵯ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: return ee3tnwl7avk(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᵰ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	return IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩᵱ"),[],[]
def r1IcxTB74l(url):
	headers = {A2MHFvoqpZ64gNbB(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᵲ"):KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᵳ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,DKmLTA2yGtj(u"ࠨࡉࡈࡘࠬᵴ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭࠲ࡵࡷࠫᵵ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᵶ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL)
		return eCpDE6wJtYUHn0GqK5(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᵷ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return DKmLTA2yGtj(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩᵸ"),[],[]
def jaOvDTcmbZ(url):
	hc5ePKxl4LJvEjDgTm = url.split(IYC4iPxkTRUE85namF6(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᵹ"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP].strip(ee3tnwl7avk(u"ࠧࡀࠩᵺ")).strip(yyZPkLCRX1xcBDN(u"ࠨ࠱ࠪᵻ")).strip(x9PULjztJOpu7b(u"ࠩࠩࠫᵼ"))
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,items,JaqiYfEglZDvmwQNS8zR = [],[],[],Zg9FeADE84jSRIvPCrzYulw3sL
	headers = { dn9ouNryjHiBFQOhASvX(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᵽ"):IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫᵾ") }
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,E3i1eCBtN2w(u"ࠬࡍࡅࡕࠩᵿ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠵ࡸࡺࠧᶀ"))
	if zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᶁ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): JaqiYfEglZDvmwQNS8zR = Pa6Q2LRkbtY0Id7nUNsZ.headers[dn9ouNryjHiBFQOhASvX(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᶂ")]
	if lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࡫ࡸࡹࡶࠧᶃ") in JaqiYfEglZDvmwQNS8zR:
		if UixkloZbzGw28ujW56X(u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᶄ") in url: JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR.replace(DKmLTA2yGtj(u"ࠫ࠴࡬࠯ࠨᶅ"),yNBjYsgc23xoW(u"ࠬ࠵ࡶ࠰ࠩᶆ"))
		cIeOo9suKM7g21TiQwqFtbUyW = hc5ePKxl4LJvEjDgTm.split(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠿ࡑࡊࡓࡗࡎࡊ࠽ࠨᶇ"))[Mn5NGAdz6xc42s0]
		headers = { dn9ouNryjHiBFQOhASvX(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᶈ"):headers[dn9ouNryjHiBFQOhASvX(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᶉ")] , ee3tnwl7avk(u"ࠩࡆࡳࡴࡱࡩࡦࠩᶊ"):tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡔࡍࡖࡓࡊࡆࡀࠫᶋ")+cIeOo9suKM7g21TiQwqFtbUyW }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡌࡋࡔࠨᶌ"),JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨᶍ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		if E3i1eCBtN2w(u"࠭࠯ࡧ࠱ࠪᶎ") in JaqiYfEglZDvmwQNS8zR: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࠽ࡪ࠵ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᶏ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		elif vGg1hAkzqi8exVbN(u"ࠨ࠱ࡹ࠳ࠬᶐ") in JaqiYfEglZDvmwQNS8zR: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vGg1hAkzqi8exVbN(u"ࠩ࡬ࡨࡂࠨࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᶑ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items: return [],[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
		elif ykE045Tatx(u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩᶒ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			return ZYTyoA483N(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧᶓ"),[],[]
	else: return vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨᶔ"),[],[]
def B8RiNLrIVh(yDTPzhEBKVJl7CX81):
	Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨᶕ"),yDTPzhEBKVJl7CX81+x9PULjztJOpu7b(u"ࠧࠧࠨࠪᶖ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	url = IYC4iPxkTRUE85namF6(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩᶗ")+BmVyhAve6X2PYuI+ZYTyoA483N(u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭ᶘ")+B6xEjq29ihy4rDnfGLFC
	headers = { yyZPkLCRX1xcBDN(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᶙ"):Zg9FeADE84jSRIvPCrzYulw3sL , eCpDE6wJtYUHn0GqK5(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧᶚ"):tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ᶛ") }
	hc5ePKxl4LJvEjDgTm = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮࠳ࡶࡸࠬᶜ"))
	return yyZPkLCRX1xcBDN(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᶝ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def wwKvyLS7uU(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,UixkloZbzGw28ujW56X(u"ࠨࡷࡵࡰࠬᶞ"))
	Y3OmVPp2ARgBCjn = {A2MHFvoqpZ64gNbB(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᶟ"):m0t48jnKhrQFJViguoMl9NBPp,UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬᶠ"):E3i1eCBtN2w(u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫᶡ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,dn9ouNryjHiBFQOhASvX(u"ࠬࡍࡅࡕࠩᶢ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ᶣ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨᶤ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = Zg9FeADE84jSRIvPCrzYulw3sL
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᶥ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for title,yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[UwCT5Oz6Wo0BP]
		elif len(fo6s53yEnbklLpaJOzgR4Q01wxB)>Mn5NGAdz6xc42s0:
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(ee3tnwl7avk(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧᶦ"), nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return yNBjYsgc23xoW(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᶧ"),[],[]
			hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᶨ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: hc5ePKxl4LJvEjDgTm = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
	if not hc5ePKxl4LJvEjDgTm: return x9PULjztJOpu7b(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧᶩ"),[],[]
	return ZYTyoA483N(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᶪ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def CmrYlk2Py3bgvZu106neDaWzpcEs(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,ReLGYUQjz7C9iEd(u"ࠧࡶࡴ࡯ࠫᶫ"))
	Y3OmVPp2ARgBCjn = {x9PULjztJOpu7b(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᶬ"):m0t48jnKhrQFJViguoMl9NBPp,DKmLTA2yGtj(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫᶭ"):ee3tnwl7avk(u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪᶮ")}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡌࡋࡔࠨᶯ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬᶰ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧᶱ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = Zg9FeADE84jSRIvPCrzYulw3sL
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᶲ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for title,yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[UwCT5Oz6Wo0BP]
		elif len(fo6s53yEnbklLpaJOzgR4Q01wxB)>Mn5NGAdz6xc42s0:
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(x9PULjztJOpu7b(u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ᶳ"), nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᶴ"),[],[]
			hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	if not hc5ePKxl4LJvEjDgTm:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᶵ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: hc5ePKxl4LJvEjDgTm = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
	if not hc5ePKxl4LJvEjDgTm: return ykE045Tatx(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡆࡅࡌࡑࡆ࠭ᶶ"),[],[]
	return qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᶷ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def Szw076nNGR(yDTPzhEBKVJl7CX81):
	Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬᶸ"),yDTPzhEBKVJl7CX81+eCpDE6wJtYUHn0GqK5(u"ࠧࠧࠨࠪᶹ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url,BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	data = {YXm2qAbu8Qsx(u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩᶺ"):BmVyhAve6X2PYuI,ZYTyoA483N(u"ࠩࡶࡩࡷࡼࡥࡳࠩᶻ"):B6xEjq29ihy4rDnfGLFC}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,NIBsHMvSXb(u"ࠪࡔࡔ࡙ࡔࠨᶼ"),url,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭ᶽ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᶾ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	return tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᶿ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def gNX7Y4t0Sb(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ykE045Tatx(u"ࠧࡈࡇࡗࠫ᷀"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ᷁"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ᷂ࠪ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		if yDTPzhEBKVJl7CX81: return KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᷃"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ᷄"),[],[]
def fForZ4LwTl(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ReLGYUQjz7C9iEd(u"ࠬࡍࡅࡕࠩ᷅"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ᷆"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᷇"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	return Vi1oNCM5kI7yJ0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᷈"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def fAYMmzEO20(url):
	oWd0XOQnlD1PHbYmR = G9GCDqXJFAc(url,qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡸࡶࡱ࠭᷉"))
	if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪ࡭ࡳࡪࡥࡹ࠿᷊ࠪ") in url:
		headers = {DKmLTA2yGtj(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ᷋"):oWd0XOQnlD1PHbYmR}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ykE045Tatx(u"ࠬࡍࡅࡕࠩ᷌"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ᷍"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁ᷎ࠬࠦࠬ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			if NIBsHMvSXb(u"ࠨࡪࡷࡸࡵ᷏࠭") not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = wFYiVd4r12x7CAQBL5SPof(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᷐")+hc5ePKxl4LJvEjDgTm
			if wFYiVd4r12x7CAQBL5SPof(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ᷑") in hc5ePKxl4LJvEjDgTm:
				hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace(vGg1hAkzqi8exVbN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭᷒"),Vi1oNCM5kI7yJ0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᷓ"))
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ykE045Tatx(u"࠭ࡇࡆࡖࠪᷔ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨᷕ"))
				CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷖ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
				G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡸࡶࡱ࠭ᷗ"))
				for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in reversed(items):
					yDTPzhEBKVJl7CX81 = G7lNnPYTc3Am8jLxp+yDTPzhEBKVJl7CX81+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᷘ")+G7lNnPYTc3Am8jLxp
					nnhWEIa6Tm.append(YUCPADxT3NrgM)
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
				return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
			else: return JP65RzKaScIf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᷙ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	hc5ePKxl4LJvEjDgTm = url+IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᷚ")+oWd0XOQnlD1PHbYmR
	if E3i1eCBtN2w(u"࠭ࡨࡵࡶࡳࠫᷛ") not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = vGg1hAkzqi8exVbN(u"ࠧࡩࡶࡷࡴ࠿࠭ᷜ")+hc5ePKxl4LJvEjDgTm
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def bGV3Ay8d9nCW2mUHuf6vD1eE(yDTPzhEBKVJl7CX81):
	oWd0XOQnlD1PHbYmR = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡷࡵࡰࠬᷝ"))
	if vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡳࡳࡸࡺࡩࡥࠩᷞ") in yDTPzhEBKVJl7CX81:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩᷟ"),yDTPzhEBKVJl7CX81+yyZPkLCRX1xcBDN(u"ࠫࠫࠬࠧᷠ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url,BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		data = {DKmLTA2yGtj(u"ࠬ࡯ࡤࠨᷡ"):BmVyhAve6X2PYuI,wFYiVd4r12x7CAQBL5SPof(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ᷢ"):B6xEjq29ihy4rDnfGLFC}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,UixkloZbzGw28ujW56X(u"ࠧࡑࡑࡖࡘࠬᷣ"),url,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩᷤ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷥ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
		if vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫᷦ") in hc5ePKxl4LJvEjDgTm:
			headers = {A2MHFvoqpZ64gNbB(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᷧ"):oWd0XOQnlD1PHbYmR,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᷨ"):Zg9FeADE84jSRIvPCrzYulw3sL}
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ttC4VURALPYKh(u"࠭ࡇࡆࡖࠪᷩ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨᷪ"))
			CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷫ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
			G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,yyZPkLCRX1xcBDN(u"ࠩࡸࡶࡱ࠭ᷬ"))
			for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in reversed(items):
				yDTPzhEBKVJl7CX81 = G7lNnPYTc3Am8jLxp+yDTPzhEBKVJl7CX81+x9PULjztJOpu7b(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᷭ")+G7lNnPYTc3Am8jLxp
				nnhWEIa6Tm.append(YUCPADxT3NrgM)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
		else: return yyZPkLCRX1xcBDN(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᷮ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+NIBsHMvSXb(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᷯ")+oWd0XOQnlD1PHbYmR
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def R9Rm6XscNg(yDTPzhEBKVJl7CX81):
	if eCpDE6wJtYUHn0GqK5(u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭ᷰ") in yDTPzhEBKVJl7CX81:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩᷱ"),yDTPzhEBKVJl7CX81+yNBjYsgc23xoW(u"ࠨࠨࠩࠫᷲ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		G6qYBaPENlLtckHTvhCR4d7A = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,A2MHFvoqpZ64gNbB(u"ࠩࡸࡶࡱ࠭ᷳ"))
		url = G6qYBaPENlLtckHTvhCR4d7A+NIBsHMvSXb(u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨᷴ")+BmVyhAve6X2PYuI+lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ᷵")+B6xEjq29ihy4rDnfGLFC
		headers = { OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᷶"):Zg9FeADE84jSRIvPCrzYulw3sL , YXm2qAbu8Qsx(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩ᷷ࠩ"):E3i1eCBtN2w(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ᷸") }
		hc5ePKxl4LJvEjDgTm = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶ᷹ࠪ"))
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
		return Vi1oNCM5kI7yJ0(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ᷺ࠬ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif vGg1hAkzqi8exVbN(u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ᷻") in yDTPzhEBKVJl7CX81:
		dQT46gLOHsewaMC7iAxp3KBIb1N0 = UwCT5Oz6Wo0BP
		while DKmLTA2yGtj(u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ᷼") in yDTPzhEBKVJl7CX81 and dQT46gLOHsewaMC7iAxp3KBIb1N0<yyZPkLCRX1xcBDN(u"࠷঍"):
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,eCpDE6wJtYUHn0GqK5(u"ࠬࡍࡅࡕ᷽ࠩ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨ᷾"))
			if vhZ5qjay1z94JmcMOgXe(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯᷿ࠩ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[yNBjYsgc23xoW(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪḀ")]
			dQT46gLOHsewaMC7iAxp3KBIb1N0 += Mn5NGAdz6xc42s0
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡂࡍࡋࡒࡒ࡟࠭ḁ"),[],[]
def yJTdSCOX7x(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡹࡷࡲࠧḂ"))
	headers = {IYC4iPxkTRUE85namF6(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬḃ"):m0t48jnKhrQFJViguoMl9NBPp,yyZPkLCRX1xcBDN(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩḄ"):lAfzvsbYy7oQ3r28EMe()}
	if vhZ5qjay1z94JmcMOgXe(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧḅ") in url:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩḆ"))
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧḇ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࡫ࡸࡹࡶࡳࠨḈ"),DKmLTA2yGtj(u"ࠪ࡬ࡹࡺࡰࠨḉ"))
			return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else:
		w1TQtjmOINLSfBcUWvoa7q3RV26X0A = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,wFYiVd4r12x7CAQBL5SPof(u"ࠫࡌࡋࡔࠨḊ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠷ࡷࡪࠧḋ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = w1TQtjmOINLSfBcUWvoa7q3RV26X0A.content
		Y3OmVPp2ARgBCjn = headers.copy()
		if UQS9lVew50DIyXrinWsMxTzA(u"࠭࡟࡭ࡰ࡮ࡣࠬḌ") in str(w1TQtjmOINLSfBcUWvoa7q3RV26X0A.cookies):
			cookies = w1TQtjmOINLSfBcUWvoa7q3RV26X0A.cookies
			Y3OmVPp2ARgBCjn[ykE045Tatx(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧḍ")] = UAjMPLdITqWChbrcB(nWw3GirR9qxCFBOa5Dt1gdXmJMpy(cookies))
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫḎ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not yDTPzhEBKVJl7CX81: return ttC4VURALPYKh(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬḏ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
		else:
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP])+UQS9lVew50DIyXrinWsMxTzA(u"ࠪࠪࡩࡃ࠱ࠨḐ")
			zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,yyZPkLCRX1xcBDN(u"ࠫࡌࡋࡔࠨḑ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠸ࡹ࡮ࠧḒ"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = zCDbxZtwOE6.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡩࡥ࠿ࠥࡦࡹࡴࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḓ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP])
				if yyZPkLCRX1xcBDN(u"ࠧ࡮ࡲ࠷ࠫḔ") in yDTPzhEBKVJl7CX81 and okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ࠱ࡧ࠳ࠬḕ") in yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
				else: return ee3tnwl7avk(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬḖ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧḗ"),[],[]
def yeiIX36zJo(yDTPzhEBKVJl7CX81):
	if ReLGYUQjz7C9iEd(u"ࠫࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠨḘ") in yDTPzhEBKVJl7CX81:
		headers = {ttC4VURALPYKh(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨḙ"):qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧḚ")}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,yyZPkLCRX1xcBDN(u"ࠧࡈࡇࡗࠫḛ"),yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪḜ"))
		url = Pa6Q2LRkbtY0Id7nUNsZ.content
		if url: return x9PULjztJOpu7b(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬḝ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫḞ"),yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if not Gi82lgtIxVsjSyqZU5EmBLkKw: Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠫࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧḟ"),yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,yNBjYsgc23xoW(u"ࠬࡻࡲ࡭ࠩḠ"))
		url = m0t48jnKhrQFJViguoMl9NBPp+yNBjYsgc23xoW(u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧḡ")
		data = {KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡪࡦࠪḢ"):BmVyhAve6X2PYuI,lU1fSmncFWjizwqZugyYBANML0(u"ࠨ࡫ࠪḣ"):B6xEjq29ihy4rDnfGLFC}
		headers = {eCpDE6wJtYUHn0GqK5(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬḤ"):vGg1hAkzqi8exVbN(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫḥ"),JP65RzKaScIf(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬḦ"):yDTPzhEBKVJl7CX81}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡖࡏࡔࡖࠪḧ"),url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠷ࡴࡤࠨḨ"))
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IYC4iPxkTRUE85namF6(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬḩ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			return vGg1hAkzqi8exVbN(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫḪ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	return qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭ḫ"),[],[]
def wwiCDIvs9P(GwcehBCRflA2MgH):
	osGpLivVOZ9mgSkAD4uyhec3U0P = yUTYoAgth5iC43uLrdBH.getSetting(wFYiVd4r12x7CAQBL5SPof(u"ࠪࡥࡻ࠴ࡡ࡬ࡹࡤࡱ࠳ࡼࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫḬ"))
	headers = {IYC4iPxkTRUE85namF6(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫḭ"):osGpLivVOZ9mgSkAD4uyhec3U0P} if osGpLivVOZ9mgSkAD4uyhec3U0P else Zg9FeADE84jSRIvPCrzYulw3sL
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡍࡅࡕࠩḮ"),GwcehBCRflA2MgH,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠴ࡷࡹ࠭ḯ"))
	wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
	Vs9M1kaPJlZowdfWDt = str(Pa6Q2LRkbtY0Id7nUNsZ.headers)
	ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR = Vs9M1kaPJlZowdfWDt+wxIqRGu1yTCf
	if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠯࡯ࡳ࠸ࠬḰ") in ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR: L9GkAl40jOgC6nf7ixqhU3YQcJK1 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else:
		Xl69gbpxUTS4RCImzN8,dkKX8zLCs6yqBlD7Y5geZEpAicua20,ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64,L9GkAl40jOgC6nf7ixqhU3YQcJK1 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc
		captcha = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ḱ"),wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if captcha: ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64 = captcha[UwCT5Oz6Wo0BP]
		vq6X1PusA0CdEwtZf = PhpFa6EdVS[YXm2qAbu8Qsx(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩḲ")][ttC4VURALPYKh(u"࠺঎")]
		if UwCT5Oz6Wo0BP:
			data = {ykE045Tatx(u"ࠪࡹࡸ࡫ࡲࠨḳ"):fs60XkagtWFJ,IYC4iPxkTRUE85namF6(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬḴ"):kI8qwbo6yER,JP65RzKaScIf(u"ࠬࡻࡲ࡭ࠩḵ"):GwcehBCRflA2MgH,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭࡫ࡦࡻࠪḶ"):c8yHSJkT64,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡪࡦࠪḷ"):Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"ࠨ࡬ࡲࡦࠬḸ"):NIBsHMvSXb(u"ࠩࡪࡩࡹࡻࡲ࡭ࡵࠪḹ")}
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,YXm2qAbu8Qsx(u"ࠪࡔࡔ࡙ࡔࠨḺ"),vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠳ࡰࡧࠫḻ"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Zg9FeADE84jSRIvPCrzYulw3sL
		if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith(vv3sNE8XCU2RAiyVaueTbD950pz(u"࡛ࠬࡒࡍࡕࡀࠫḼ")):
			XrEQ2VJFc6KxMwvdqGH5oUhICOu1 = JGmfjhoyKZUl(yNBjYsgc23xoW(u"࠭࡬ࡪࡵࡷࠫḽ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.split(dn9ouNryjHiBFQOhASvX(u"ࠧࡖࡔࡏࡗࡂ࠭Ḿ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0])
			for YYAz8aPFGR2n in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
				url = YYAz8aPFGR2n[IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡷࡵࡰࠬḿ")]
				G1hbAR8Yxkp0zeCoMdaB4Dqw = YYAz8aPFGR2n[wFYiVd4r12x7CAQBL5SPof(u"ࠩࡰࡩࡹ࡮࡯ࡥࠩṀ")]
				data = YYAz8aPFGR2n[Vi1oNCM5kI7yJ0(u"ࠪࡨࡦࡺࡡࠨṁ")]
				headers = YYAz8aPFGR2n[eCpDE6wJtYUHn0GqK5(u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬṂ")]
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,G1hbAR8Yxkp0zeCoMdaB4Dqw,url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬṃ"))
				wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
				if ykE045Tatx(u"࠭࠮࡮ࡲ࠷ࠫṄ") in wxIqRGu1yTCf:
					L9GkAl40jOgC6nf7ixqhU3YQcJK1 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					break
				Vs9M1kaPJlZowdfWDt = str(Pa6Q2LRkbtY0Id7nUNsZ.headers)
				ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR = Vs9M1kaPJlZowdfWDt+wxIqRGu1yTCf
				Xl69gbpxUTS4RCImzN8 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡽࠫࠪ࠰࠭ࡃࠧ࠮ࡥࡺࡌ࠱࠮ࡄ࠯ࠢࠨṅ"),ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(DKmLTA2yGtj(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰ࠱࠮ࡄࠨࠨ࠱࠵ࡄ࠲࠯ࡅࠩࠣࠩṆ"),ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if dkKX8zLCs6yqBlD7Y5geZEpAicua20: dkKX8zLCs6yqBlD7Y5geZEpAicua20 = dkKX8zLCs6yqBlD7Y5geZEpAicua20[UwCT5Oz6Wo0BP]
				if Xl69gbpxUTS4RCImzN8 or dkKX8zLCs6yqBlD7Y5geZEpAicua20: break
		if not L9GkAl40jOgC6nf7ixqhU3YQcJK1:
			if not Xl69gbpxUTS4RCImzN8:
				if captcha and not dkKX8zLCs6yqBlD7Y5geZEpAicua20:
					if Mn5NGAdz6xc42s0: dkKX8zLCs6yqBlD7Y5geZEpAicua20 = e4XT9Vp5sNIP8M0lyFd7orGUhJ2Ou(c8yHSJkT64,ee3tnwl7avk(u"ࠩࡤࡶࠬṇ"),GwcehBCRflA2MgH)
					else:
						if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith(ZYTyoA483N(u"ࠪࡍࡉࡃࠧṈ")):
							data = {ttC4VURALPYKh(u"ࠫࡺࡹࡥࡳࠩṉ"):fs60XkagtWFJ,lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭Ṋ"):kI8qwbo6yER,JP65RzKaScIf(u"࠭ࡵࡳ࡮ࠪṋ"):GwcehBCRflA2MgH,YXm2qAbu8Qsx(u"ࠧ࡬ࡧࡼࠫṌ"):c8yHSJkT64,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡫ࡧࠫṍ"):Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠩ࡭ࡳࡧ࠭Ṏ"):KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࡫ࡪࡺࡩࡥࠩṏ")}
							Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,vhZ5qjay1z94JmcMOgXe(u"ࠫࡕࡕࡓࡕࠩṐ"),vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠶ࡷ࡬ࠬṑ"))
							yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
						else: yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = E3i1eCBtN2w(u"࠭ࡉࡅ࠿࠴࠶࠸࠺࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠹࠻ࠧṒ")
						if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith(UixkloZbzGw28ujW56X(u"ࠧࡊࡆࡀࠫṓ")):
							XQsiFUaSgDCLro = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡋࡇࡁ࠭࠴ࠪࡀࠫ࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽ࠩ࠰࠭ࡃ࠮ࠪࠧṔ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
							ItDYZ781iSzo,HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = XQsiFUaSgDCLro[UwCT5Oz6Wo0BP]
							oHkimLnwDKNxlheUuGAMQIg9jY7dz = ZYTyoA483N(u"๊ࠩิ์ࠦวๅ฻่่๏ฯࠠหฯอหั่ࠦใฬ้๋ࠣࠦ࠱࠱ࠢศ่๎ࠦࠧṕ")+HTPdhx6IsYmGjeZ5nbtkUy47ACvruK+x9PULjztJOpu7b(u"ࠪࠤะอๆ๋หࠪṖ")
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS = Rr8woplmSQWXIZcGFfA()
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS.create(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ์ู้สࠡสิ๊ฬ๋ฬࠡๅ๋้อ๐่หำࠪṗ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
							uuAgLD1dr7s = LNma2eq3vEguwVtHjn.time()
							i8OdhkMvDrt1Fzx0fJXKgVyEl4p,ePJSwbWn1QRuilDZg8a = UwCT5Oz6Wo0BP,UwCT5Oz6Wo0BP
							while i8OdhkMvDrt1Fzx0fJXKgVyEl4p<int(HTPdhx6IsYmGjeZ5nbtkUy47ACvruK):
								OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,int(i8OdhkMvDrt1Fzx0fJXKgVyEl4p/int(HTPdhx6IsYmGjeZ5nbtkUy47ACvruK)*ReLGYUQjz7C9iEd(u"࠵࠵࠶এ")),oHkimLnwDKNxlheUuGAMQIg9jY7dz,Zg9FeADE84jSRIvPCrzYulw3sL,HTPdhx6IsYmGjeZ5nbtkUy47ACvruK+IYC4iPxkTRUE85namF6(u"ࠬࠦ࠯ࠡࠩṘ")+str(int(i8OdhkMvDrt1Fzx0fJXKgVyEl4p))+yyZPkLCRX1xcBDN(u"࠭ࠠࠡอส๊๏ฯࠧṙ"))
								if i8OdhkMvDrt1Fzx0fJXKgVyEl4p>ePJSwbWn1QRuilDZg8a+jozVWcERh91GOF2NHXQiSwKqe8x(u"࠶࠶ঐ"):
									data = {JP65RzKaScIf(u"ࠧࡶࡵࡨࡶࠬṚ"):fs60XkagtWFJ,dn9ouNryjHiBFQOhASvX(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩṛ"):kI8qwbo6yER,E3i1eCBtN2w(u"ࠩࡸࡶࡱ࠭Ṝ"):GwcehBCRflA2MgH,ee3tnwl7avk(u"ࠪ࡯ࡪࡿࠧṝ"):c8yHSJkT64,eCpDE6wJtYUHn0GqK5(u"ࠫ࡮ࡪࠧṞ"):ItDYZ781iSzo,dn9ouNryjHiBFQOhASvX(u"ࠬࡰ࡯ࡣࠩṟ"):okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡧࡦࡶࡷࡳࡰ࡫࡮ࠨṠ")}
									Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡑࡑࡖࡘࠬṡ"),vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨṢ"))
									yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
									if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith(ttC4VURALPYKh(u"ࠩࡗࡓࡐࡋࡎ࠾ࠩṣ")):
										dkKX8zLCs6yqBlD7Y5geZEpAicua20 = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.split(yyZPkLCRX1xcBDN(u"ࠪࡘࡔࡑࡅࡏ࠿ࠪṤ"),IK4zTnSMyGQpxEaesJAPVDY(u"࠷঑"))[Mn5NGAdz6xc42s0]
										break
									ePJSwbWn1QRuilDZg8a = i8OdhkMvDrt1Fzx0fJXKgVyEl4p
								else: LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
								i8OdhkMvDrt1Fzx0fJXKgVyEl4p = LNma2eq3vEguwVtHjn.time()-uuAgLD1dr7s
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS.close()
				if dkKX8zLCs6yqBlD7Y5geZEpAicua20:
					cwOlXoA1krih5LKjQ = Pa6Q2LRkbtY0Id7nUNsZ.cookies
					ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IYC4iPxkTRUE85namF6(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ࠭࠴ࠪࡀࠫ࠾ࠫṥ"),ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if A2MHFvoqpZ64gNbB(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬṦ") in list(cwOlXoA1krih5LKjQ.keys()): ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = cwOlXoA1krih5LKjQ[dn9ouNryjHiBFQOhASvX(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ṧ")]
					elif ZZqwLUcVuJkAIl8SjNHOsEd5ipM6: ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = ZZqwLUcVuJkAIl8SjNHOsEd5ipM6[UwCT5Oz6Wo0BP]
					captcha = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬṨ"),wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if captcha: ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64 = captcha[UwCT5Oz6Wo0BP]
					if ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 and captcha:
						headers = {JP65RzKaScIf(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨṩ"):DKmLTA2yGtj(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࠪṪ")+ZZqwLUcVuJkAIl8SjNHOsEd5ipM6,UixkloZbzGw28ujW56X(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫṫ"):GwcehBCRflA2MgH,E3i1eCBtN2w(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪṬ"):A2MHFvoqpZ64gNbB(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫṭ")}
						data = wFYiVd4r12x7CAQBL5SPof(u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡃࠧṮ")+dkKX8zLCs6yqBlD7Y5geZEpAicua20
						Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,ReLGYUQjz7C9iEd(u"ࠧࡑࡑࡖࡘࠬṯ"),ykHvcOoTYS8hQsVPqGZ0mAKLN,data,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠻ࡺࡨࠨṰ"))
						wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
						try: cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
						except: cookies = {}
						Xl69gbpxUTS4RCImzN8 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠤࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࠯ࠬࡂ࠭ࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣṱ"),str(cookies),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if Xl69gbpxUTS4RCImzN8:
				VaOH2318eP5yQWXrkcx,Xl69gbpxUTS4RCImzN8 = Xl69gbpxUTS4RCImzN8[UwCT5Oz6Wo0BP]
				osGpLivVOZ9mgSkAD4uyhec3U0P = VaOH2318eP5yQWXrkcx+JP65RzKaScIf(u"ࠪࡁࠬṲ")+Xl69gbpxUTS4RCImzN8
				yUTYoAgth5iC43uLrdBH.setSetting(JP65RzKaScIf(u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬṳ"),osGpLivVOZ9mgSkAD4uyhec3U0P)
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṴ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤส์ำศ่ࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ๋ะววฮ๋ࠣีอࠠศๆไัฺࠦไไ์ࠣ๎ุะฮะ็๊ห๊ࠥวฮไสࠤ࠳࠴้ࠠๆสࠤฯ๎ฬะࠢะหัฯࠠๅว฼หิฯ่ࠠาสࠤฬ๊แฮื่ࠣ฾ีษࠡลื๋ึࠦ࡜࡯࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่ๆำีࠡี๋ๅࠥ๐สไำิࠤๆ๐ࠠฮษ็อࠥะฺ๋ำࠣีอ฽ࠠศๆฯ๋ฬุࠠษษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฻ๆอมࠡำส์ฯืࠠศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡใุู่ࠥไไࠢส่ึอ่หำࠣ࠲࠳ࠦร้ࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣฬึ๎ใิ์ࠪṵ"))
				if ReLGYUQjz7C9iEd(u"ࠧ࠯࡯ࡳ࠸ࠬṶ") not in wxIqRGu1yTCf:
					headers = {yNBjYsgc23xoW(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨṷ"):osGpLivVOZ9mgSkAD4uyhec3U0P}
					Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,YXm2qAbu8Qsx(u"ࠩࡊࡉ࡙࠭Ṹ"),GwcehBCRflA2MgH,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠷ࡵࡪࠪṹ"))
					wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
	if not L9GkAl40jOgC6nf7ixqhU3YQcJK1 and not osGpLivVOZ9mgSkAD4uyhec3U0P: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧṺ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢไัฺࠦร็ษࠣวู๋ว็ࠢ࠱࠲ࠥำว้ๆࠣษ฾อฯสࠢส่฾๋ไ๋ห้ࠣึฯࠠฤะิํࠥฮวิฬัำฬ๋ࠠ็ใึࠤฬ๊แ๋ัํ์ࠥษ่ࠡใํำ๏๎ࠠ฻์ิ๋๋ࠥๆ่ࠡไืࠥอไๆ๊ๅ฽ࠬṻ"))
	return wxIqRGu1yTCf
def IyYirQzZGv(url,TeDLBxpO03aonZFfQbNuK9S,YUCPADxT3NrgM):
	ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93 = [],[]
	GwcehBCRflA2MgH = url
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,ttC4VURALPYKh(u"࠭ࡇࡆࡖࠪṼ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭ṽ"))
	CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
	KqSR7WPb0FXlsD6UNpfg = []
	if ReLGYUQjz7C9iEd(u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩṾ") in CNhQcnS0dI6UFjbvLoyx or qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ṿ") in CNhQcnS0dI6UFjbvLoyx:
		qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(dn9ouNryjHiBFQOhASvX(u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠱࠮ࡄࡂ࠯ࡢࡀࠪẀ"),CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if qLx93JtrVCHlKaZW2hXc7dpiNmDR:
			for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
				CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(NIBsHMvSXb(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨẁ"),nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				for yDTPzhEBKVJl7CX81,title in CPv45ibdnBc:
					if yDTPzhEBKVJl7CX81 in ZZH6czYDb0: continue
					if UixkloZbzGw28ujW56X(u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭Ẃ") not in yDTPzhEBKVJl7CX81 and ykE045Tatx(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪẃ") not in yDTPzhEBKVJl7CX81: continue
					if wFYiVd4r12x7CAQBL5SPof(u"ࠧศࠩẄ") not in title:
						KqSR7WPb0FXlsD6UNpfg.append((title,yDTPzhEBKVJl7CX81))
						continue
					title = title.replace(ReLGYUQjz7C9iEd(u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩẅ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࠣ࠱ࠥ࠭Ẇ"),Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
					if YXm2qAbu8Qsx(u"ࠪࡷࡵࡧ࡮ࠨẇ") in title: continue
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
			for title,yDTPzhEBKVJl7CX81 in KqSR7WPb0FXlsD6UNpfg:
				if yDTPzhEBKVJl7CX81 not in ZZH6czYDb0:
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
			lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			if len(ZZH6czYDb0)>Mn5NGAdz6xc42s0:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(NIBsHMvSXb(u"ࠫอ฿ึ่ษࠣ๎าะวอࠢ࠹࠴ࠥัว็์ฬࠫẈ"),joaMtxEpGfDXFPRHQgLKizyOT2b93)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪẉ"),[],[]
			if ZZH6czYDb0 and lqQvOUWodZnhXLS2Vcuj6EtairFN>=UwCT5Oz6Wo0BP: GwcehBCRflA2MgH = ZZH6czYDb0[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	wxIqRGu1yTCf = wwiCDIvs9P(GwcehBCRflA2MgH)
	fo6s53yEnbklLpaJOzgR4Q01wxB,nnhWEIa6Tm = [],[]
	if TeDLBxpO03aonZFfQbNuK9S==ReLGYUQjz7C9iEd(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨẊ"):
		hjLBiG9rbkvJ45pHUZRyKf38Qn = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬẋ"),wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hjLBiG9rbkvJ45pHUZRyKf38Qn:
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(hjLBiG9rbkvJ45pHUZRyKf38Qn[UwCT5Oz6Wo0BP])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(YUCPADxT3NrgM)
	elif TeDLBxpO03aonZFfQbNuK9S==dn9ouNryjHiBFQOhASvX(u"ࠨࡹࡤࡸࡨ࡮ࠧẌ"):
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(YXm2qAbu8Qsx(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫẍ"),wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,size in CPv45ibdnBc:
			if not yDTPzhEBKVJl7CX81: continue
			if YUCPADxT3NrgM in size:
				nnhWEIa6Tm.append(size)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
				break
		if not fo6s53yEnbklLpaJOzgR4Q01wxB:
			for yDTPzhEBKVJl7CX81,size in CPv45ibdnBc:
				if not yDTPzhEBKVJl7CX81: continue
				nnhWEIa6Tm.append(size)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: return ZYTyoA483N(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫẎ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def pQ1ZiwXaM0(url,VaOH2318eP5yQWXrkcx):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡌࡋࡔࠨẏ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫẐ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
	if qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭ẑ") in list(cookies.keys()):
		osGpLivVOZ9mgSkAD4uyhec3U0P = cookies[x9PULjztJOpu7b(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧẒ")]
		osGpLivVOZ9mgSkAD4uyhec3U0P = UAjMPLdITqWChbrcB(uumhMi6O4pk7Gjd5aTQqy2Z(osGpLivVOZ9mgSkAD4uyhec3U0P))
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩẓ"),osGpLivVOZ9mgSkAD4uyhec3U0P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		hc5ePKxl4LJvEjDgTm = items[UwCT5Oz6Wo0BP].replace(A2MHFvoqpZ64gNbB(u"ࠩ࡟࠳ࠬẔ"),E3i1eCBtN2w(u"ࠪ࠳ࠬẕ"))
		hc5ePKxl4LJvEjDgTm = uumhMi6O4pk7Gjd5aTQqy2Z(hc5ePKxl4LJvEjDgTm)
	else: hc5ePKxl4LJvEjDgTm = url
	if YXm2qAbu8Qsx(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭ẖ") in hc5ePKxl4LJvEjDgTm:
		bUct2lM4esE8mVBILAXJOZ = hc5ePKxl4LJvEjDgTm.split(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࠫ࠲ࡇࠩẗ"))[-Mn5NGAdz6xc42s0]
		hc5ePKxl4LJvEjDgTm = UixkloZbzGw28ujW56X(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩẘ")+bUct2lM4esE8mVBILAXJOZ
		return OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪẙ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else:
		website = PhpFa6EdVS[IYC4iPxkTRUE85namF6(u"ࠨࡃࡎࡓࡆࡓࠧẚ")][UwCT5Oz6Wo0BP]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,ZYTyoA483N(u"ࠩࡊࡉ࡙࠭ẛ"),website,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠸࡮ࡥࠩẜ"))
		rHCZ02fmNhGS = Pa6Q2LRkbtY0Id7nUNsZ.url
		YAQCdqosX2z5lOGc3 = hc5ePKxl4LJvEjDgTm.split(qdEKO42r3GhwmCDcHtxzJUR(u"ࠫ࠴࠭ẝ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		kTVy5DAjqHmM8Q = rHCZ02fmNhGS.split(ZYTyoA483N(u"ࠬ࠵ࠧẞ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm.replace(YAQCdqosX2z5lOGc3,kTVy5DAjqHmM8Q)
		headers = { yNBjYsgc23xoW(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪẟ"):Zg9FeADE84jSRIvPCrzYulw3sL , NIBsHMvSXb(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪẠ"):UQS9lVew50DIyXrinWsMxTzA(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩạ") , IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪẢ"):JaqiYfEglZDvmwQNS8zR }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,vGg1hAkzqi8exVbN(u"ࠪࡔࡔ࡙ࡔࠨả"), JaqiYfEglZDvmwQNS8zR, Zg9FeADE84jSRIvPCrzYulw3sL, headers, vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪẤ"))
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vGg1hAkzqi8exVbN(u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬấ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if not items:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧẦ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
			if not items:
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧầ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if items:
			yDTPzhEBKVJl7CX81 = items[UwCT5Oz6Wo0BP].replace(DKmLTA2yGtj(u"ࠨ࡞࠲ࠫẨ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩ࠲ࠫẩ"))
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.rstrip(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࠳ࠬẪ"))
			if JP65RzKaScIf(u"ࠫ࡭ࡺࡴࡱࠩẫ") not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = x9PULjztJOpu7b(u"ࠬ࡮ࡴࡵࡲ࠽ࠫẬ") + yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(eCpDE6wJtYUHn0GqK5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧậ"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩẮ"))
			if VaOH2318eP5yQWXrkcx==Zg9FeADE84jSRIvPCrzYulw3sL: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
			else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = IYC4iPxkTRUE85namF6(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫắ"),[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡏࡂࡏࠪẰ"),[],[]
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def x1yIRrBg8Sf(url):
	headers = { vv3sNE8XCU2RAiyVaueTbD950pz(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧằ") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨẲ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ẳ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if items:
		for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a in items:
			nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓࠬẴ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def pdvXniJubODEGh1fRVA2SHIM8c(url):
	headers = {wFYiVd4r12x7CAQBL5SPof(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫẵ"):Zg9FeADE84jSRIvPCrzYulw3sL}
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨẶ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧặ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		url = items[UwCT5Oz6Wo0BP]+ee3tnwl7avk(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭Ẹ")+url
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else: return ReLGYUQjz7C9iEd(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭ẹ"),[],[]
def FFxdlpqBmr8V(url):
	url = url.strip(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠵ࠧẺ"))
	if vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧẻ") in url: bUct2lM4esE8mVBILAXJOZ = url.split(lU1fSmncFWjizwqZugyYBANML0(u"ࠧ࠰ࠩẼ"))[NEc173Pr0jAwLF5OS]
	else: bUct2lM4esE8mVBILAXJOZ = url.split(x9PULjztJOpu7b(u"ࠨ࠱ࠪẽ"))[-Mn5NGAdz6xc42s0]
	url = DKmLTA2yGtj(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭Ế") + bUct2lM4esE8mVBILAXJOZ
	headers = { ReLGYUQjz7C9iEd(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧế") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡅࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭Ề"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(E3i1eCBtN2w(u"ࠬࡢ࡜ࠨề"),Zg9FeADE84jSRIvPCrzYulw3sL)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(YXm2qAbu8Qsx(u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ể"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡇࡘ࡚ࡒࡆࡃࡐࠫể"),[],[]
def Z89zqsFYGhdOw3ADCl5VtoSiQNXg(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,A2MHFvoqpZ64gNbB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡐ࡜ࡄ࠱࠶ࡹࡴࠨỄ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠩࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࡷ࡫ࡳ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩễ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a,W8q6caR1ouAm in items:
		nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a+wjs26GpVfNiCUERHJ+W8q6caR1ouAm)
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return ee3tnwl7avk(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬỆ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def RT28FCeLrhH01x(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨệ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥỈ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = set(items)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	for bUct2lM4esE8mVBILAXJOZ,LfnWDFgRdJH4lZvt7yo28N,Jjr796Gdo12WzI0BwTuC84asPhv,cwMyvBgJuRXLWH48kpndbG7q2a,W8q6caR1ouAm in items:
		url = ee3tnwl7avk(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪỉ")+bUct2lM4esE8mVBILAXJOZ+vGg1hAkzqi8exVbN(u"ࠧࠧ࡯ࡲࡨࡪࡃࠧỊ")+LfnWDFgRdJH4lZvt7yo28N+ee3tnwl7avk(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨị")+Jjr796Gdo12WzI0BwTuC84asPhv
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ReLGYUQjz7C9iEd(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭Ọ"))
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩọ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a+wjs26GpVfNiCUERHJ+W8q6caR1ouAm)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑࠪỎ"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url):
	yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL
	if Mn5NGAdz6xc42s0 or okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡑࡥࡺ࠿ࠪỏ") not in url:
		hc5ePKxl4LJvEjDgTm = url.replace(eCpDE6wJtYUHn0GqK5(u"࠭ࡵࡱࡤࡲࡱ࠳ࡲࡩࡷࡧࠪỐ"),NIBsHMvSXb(u"ࠧࡶࡲࡳࡳࡲ࠴࡬ࡪࡸࡨࠫố"))
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.split(vGg1hAkzqi8exVbN(u"ࠨ࠱ࠪỒ"))
		bUct2lM4esE8mVBILAXJOZ = hc5ePKxl4LJvEjDgTm[O4dklMvZ8ULcS]
		hc5ePKxl4LJvEjDgTm = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࠲ࠫồ").join(hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP:NEc173Pr0jAwLF5OS])
		EEFf6enQDxk = {YXm2qAbu8Qsx(u"ࠪ࡭ࡩ࠭Ổ"):bUct2lM4esE8mVBILAXJOZ,eCpDE6wJtYUHn0GqK5(u"ࠫࡴࡶࠧổ"):yNBjYsgc23xoW(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨỖ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࡭ࡦࡶ࡫ࡳࡩࡥࡦࡳࡧࡨࠫỗ"):UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡇࡴࡨࡩ࠰ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠫࠦ࠵ࡈࠩ࠸ࡋࠧỘ")}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡒࡒࡗ࡙࠭ộ"),hc5ePKxl4LJvEjDgTm,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠶ࡹࡴࠨỚ"))
		if NIBsHMvSXb(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬớ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭Ờ")]
		if not yDTPzhEBKVJl7CX81 and Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠬ࡯ࡤ࠾ࠤࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩờ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,yNBjYsgc23xoW(u"࠭ࡇࡆࡖࠪỞ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡕࡈࡏࡎ࠯࠵ࡲࡩ࠭ở"))
		if ykE045Tatx(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪỠ") in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫỡ")]
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return UixkloZbzGw28ujW56X(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫỢ"),[],[]
def grAa8UdWkpub(url):
	headers = { YXm2qAbu8Qsx(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨợ") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡌࡍ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧỤ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧ࠮࠮ࠫࡁࠬࠦࠬụ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	if items:
		nnhWEIa6Tm.append(ZYTyoA483N(u"ࠧ࡮ࡲ࠷ࠫỦ"))
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(items[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0])
		nnhWEIa6Tm.append(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨ࡯࠶ࡹ࠽࠭ủ"))
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(items[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP])
		return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	else: return vhZ5qjay1z94JmcMOgXe(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡏࡉࡗࡋࡇࡉࡔ࠭Ứ"),[],[]
def eRwxN7KrW0(url):
	bUct2lM4esE8mVBILAXJOZ = url.split(DKmLTA2yGtj(u"ࠪ࠳ࠬứ"))[-Mn5NGAdz6xc42s0]
	bUct2lM4esE8mVBILAXJOZ = bUct2lM4esE8mVBILAXJOZ.split(ykE045Tatx(u"ࠫࠫ࠭Ừ"))[UwCT5Oz6Wo0BP]
	bUct2lM4esE8mVBILAXJOZ = bUct2lM4esE8mVBILAXJOZ.replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧừ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	hc5ePKxl4LJvEjDgTm = PhpFa6EdVS[DKmLTA2yGtj(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧỬ")][UwCT5Oz6Wo0BP]+lU1fSmncFWjizwqZugyYBANML0(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪử")+bUct2lM4esE8mVBILAXJOZ
	joIuF3TtfVUdby7K2N = yyZPkLCRX1xcBDN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡻࡲࡹࡹࡻ࠮ࡣࡧ࠲ࠫỮ")+bUct2lM4esE8mVBILAXJOZ
	aXT8hF9ylD6pMHj7BZsYQnA,DpgrWvF3wOCI5MEn4dXaGx,zUOoIHnWacwMtFr3yGkN2xu4gi,MhpvcyiPkbw0atNDXBURgl = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	headers = {Vi1oNCM5kI7yJ0(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ữ"):Zg9FeADE84jSRIvPCrzYulw3sL}
	if UwCT5Oz6Wo0BP:
		for OEJ3PT81KtbZ in range(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵঒")):
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,ee3tnwl7avk(u"ࠪࡋࡊ࡚ࠧỰ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,A2MHFvoqpZ64gNbB(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬự"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			if vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࡯ࡴࡢࡩࠪỲ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: break
			LNma2eq3vEguwVtHjn.sleep(DpahB8cwl4ZeKVsg71RuibSAfx0Ejr)
		LWBtsX3i8TfPJxF = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡖ࡬ࡢࡻࡨࡶࡗ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪỳ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if LWBtsX3i8TfPJxF: LWBtsX3i8TfPJxF = LWBtsX3i8TfPJxF[UwCT5Oz6Wo0BP]
		else: LWBtsX3i8TfPJxF = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	else:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Zg9FeADE84jSRIvPCrzYulw3sL
		headers[IYC4iPxkTRUE85namF6(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭Ỵ")] = JP65RzKaScIf(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫỵ")
		JaqiYfEglZDvmwQNS8zR = PhpFa6EdVS[eCpDE6wJtYUHn0GqK5(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪỶ")][UwCT5Oz6Wo0BP]+yNBjYsgc23xoW(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࠩỷ")
		a8ayG4wjQhRPdF3Os = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࢀࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫỸ")+bUct2lM4esE8mVBILAXJOZ+NIBsHMvSXb(u"ࠬࠨࠬࠡࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠳࠰࠵࠴࠷࠸࠰࠺࠳࠻ࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠦࠢࡎ࡙ࡈࡆࠧࢃࡽࡾࠩỹ")
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,JP65RzKaScIf(u"࠭ࡐࡐࡕࡗࠫỺ"),JaqiYfEglZDvmwQNS8zR,a8ayG4wjQhRPdF3Os,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨỻ"))
		LWBtsX3i8TfPJxF = Pa6Q2LRkbtY0Id7nUNsZ.content
	LWBtsX3i8TfPJxF = LWBtsX3i8TfPJxF.replace(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩỼ"),ReLGYUQjz7C9iEd(u"ࠩࠩࠫỽ"))
	SiMblPt0wfKdhvx = JGmfjhoyKZUl(ee3tnwl7avk(u"ࠪࡨ࡮ࡩࡴࠨỾ"),LWBtsX3i8TfPJxF)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨỿ")],[Zg9FeADE84jSRIvPCrzYulw3sL]
	try:
		UOQSuNkawVxYW0j = SiMblPt0wfKdhvx[ykE045Tatx(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳࡹࠧἀ")][dn9ouNryjHiBFQOhASvX(u"࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪἁ")][IYC4iPxkTRUE85namF6(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡕࡴࡤࡧࡰࡹࠧἂ")]
		for zEMeLmF5g1tHIGKThqnZv43r in UOQSuNkawVxYW0j:
			yDTPzhEBKVJl7CX81 = zEMeLmF5g1tHIGKThqnZv43r[JP65RzKaScIf(u"ࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠩἃ")]
			try: title = zEMeLmF5g1tHIGKThqnZv43r[IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡱࡥࡲ࡫ࠧἄ")][UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧἅ")]
			except: title = zEMeLmF5g1tHIGKThqnZv43r[yNBjYsgc23xoW(u"ࠫࡳࡧ࡭ࡦࠩἆ")][YXm2qAbu8Qsx(u"ࠬࡸࡵ࡯ࡵࠪἇ")][UwCT5Oz6Wo0BP][zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡴࡦࡺࡷࡸࠬἈ")]
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(title)
	except: pass
	if len(nnhWEIa6Tm)>Mn5NGAdz6xc42s0:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(lU1fSmncFWjizwqZugyYBANML0(u"ࠧศะอีࠥอไหำฯ้ฮࠦࠨࠨἉ")+str(len(nnhWEIa6Tm))+UQS9lVew50DIyXrinWsMxTzA(u"ࠨ่่ࠢๆ࠯ࠧἊ"), nnhWEIa6Tm)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return E3i1eCBtN2w(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧἋ"),[],[]
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN!=UwCT5Oz6Wo0BP:
			yDTPzhEBKVJl7CX81 = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]+eCpDE6wJtYUHn0GqK5(u"ࠪࠪࠬἌ")
			tmvza0UiZy = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(YXm2qAbu8Qsx(u"ࠫࠫ࠮ࡦ࡮ࡶࡀ࠲࠯ࡅࠩࠧࠩἍ"),yDTPzhEBKVJl7CX81)
			if tmvza0UiZy: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(tmvza0UiZy[UwCT5Oz6Wo0BP],DKmLTA2yGtj(u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭Ἆ"))
			else: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧἏ")
			aXT8hF9ylD6pMHj7BZsYQnA = yDTPzhEBKVJl7CX81.strip(NIBsHMvSXb(u"ࠧࠧࠩἐ"))
	vvy6dnOMNsB3ZCWU09YQu,qtJ7YwyzuUsml4x0jM,an5GQFpEJxW9,TNPEAmKFYZJjsktnx5eIoSM,aTZNB9SyUCpHrPgK8lDE0xhA = [],[],[],[],[]
	try: DpgrWvF3wOCI5MEn4dXaGx = SiMblPt0wfKdhvx[ReLGYUQjz7C9iEd(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨἑ")][A2MHFvoqpZ64gNbB(u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫἒ")]
	except: pass
	try: zUOoIHnWacwMtFr3yGkN2xu4gi = SiMblPt0wfKdhvx[A2MHFvoqpZ64gNbB(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪἓ")][OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬἔ")]
	except: pass
	try: vvy6dnOMNsB3ZCWU09YQu = SiMblPt0wfKdhvx[Vi1oNCM5kI7yJ0(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬἕ")][wFYiVd4r12x7CAQBL5SPof(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ἖")]
	except: pass
	try: qtJ7YwyzuUsml4x0jM = SiMblPt0wfKdhvx[DKmLTA2yGtj(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ἗")][zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪἘ")]
	except: pass
	dnD40ZjBAsiGLEp8Qy = vvy6dnOMNsB3ZCWU09YQu+qtJ7YwyzuUsml4x0jM
	for dict in dnD40ZjBAsiGLEp8Qy:
		if YXm2qAbu8Qsx(u"ࠩ࡬ࡸࡦ࡭ࠧἙ") in list(dict.keys()): dict[eCpDE6wJtYUHn0GqK5(u"ࠪ࡭ࡹࡧࡧࠨἚ")] = str(dict[qdEKO42r3GhwmCDcHtxzJUR(u"ࠫ࡮ࡺࡡࡨࠩἛ")])
		if zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࡬ࡰࡴࠩἜ") in list(dict.keys()): dict[E3i1eCBtN2w(u"࠭ࡦࡱࡵࠪἝ")] = str(dict[vGg1hAkzqi8exVbN(u"ࠧࡧࡲࡶࠫ἞")])
		if ReLGYUQjz7C9iEd(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ἟") in list(dict.keys()): dict[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡷࡽࡵ࡫ࠧἠ")] = dict[x9PULjztJOpu7b(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬἡ")]
		if ykE045Tatx(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭ἢ") in list(dict.keys()): dict[A2MHFvoqpZ64gNbB(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩἣ")] = str(dict[ttC4VURALPYKh(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨἤ")])
		if yNBjYsgc23xoW(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧἥ") in list(dict.keys()): dict[JP65RzKaScIf(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩἦ")] = str(dict[YXm2qAbu8Qsx(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩἧ")])
		if jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡻ࡮ࡪࡴࡩࠩἨ") in list(dict.keys()): dict[vhZ5qjay1z94JmcMOgXe(u"ࠫࡸ࡯ࡺࡦࠩἩ")] = str(dict[eCpDE6wJtYUHn0GqK5(u"ࠬࡽࡩࡥࡶ࡫ࠫἪ")])+qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡸࠨἫ")+str(dict[lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡩࡧ࡬࡫࡭ࡺࠧἬ")])
		if ykE045Tatx(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫἭ") in list(dict.keys()): dict[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩ࡬ࡲ࡮ࡺࠧἮ")] = dict[UixkloZbzGw28ujW56X(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭Ἧ")][KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡸࡺࡡࡳࡶࠪἰ")]+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࠳ࠧἱ")+dict[YXm2qAbu8Qsx(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩἲ")][yyZPkLCRX1xcBDN(u"ࠧࡦࡰࡧࠫἳ")]
		if YXm2qAbu8Qsx(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬἴ") in list(dict.keys()): dict[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩ࡬ࡲࡩ࡫ࡸࠨἵ")] = dict[ZYTyoA483N(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧἶ")][A2MHFvoqpZ64gNbB(u"ࠫࡸࡺࡡࡳࡶࠪἷ")]+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠳ࠧἸ")+dict[jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪἹ")][vGg1hAkzqi8exVbN(u"ࠧࡦࡰࡧࠫἺ")]
		if jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩἻ") in list(dict.keys()): dict[ZYTyoA483N(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪἼ")] = dict[E3i1eCBtN2w(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫἽ")]
		if Vi1oNCM5kI7yJ0(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬἾ") in list(dict.keys()) and int(dict[eCpDE6wJtYUHn0GqK5(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭Ἷ")])>ee3tnwl7avk(u"࠲࠳࠴࠶࠷࠸࠳࠴࠵ও"): del dict[KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧὀ")]
		if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩὁ") in list(dict.keys()):
			SS5sovXA2zyC3GQUWu0m = dict[UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪὂ")].split(IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࠩࠫὃ"))
			for r1OMYvp0ViTG in SS5sovXA2zyC3GQUWu0m:
				key,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡁࠬὄ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠳ঔ"))
				dict[key] = UAjMPLdITqWChbrcB(B251BPiLbvG9UxszKtlI7YQHmoWw)
		if yNBjYsgc23xoW(u"ࠫࡺࡸ࡬ࠨὅ") in list(dict.keys()): dict[ykE045Tatx(u"ࠬࡻࡲ࡭ࠩ὆")] = UAjMPLdITqWChbrcB(dict[E3i1eCBtN2w(u"࠭ࡵࡳ࡮ࠪ὇")])
		an5GQFpEJxW9.append(dict)
	GmX8rCfsEjogehqyFR = Zg9FeADE84jSRIvPCrzYulw3sL
	if yyZPkLCRX1xcBDN(u"ࠧࡴࡲࡀࡷ࡮࡭ࠧὈ") in LWBtsX3i8TfPJxF:
		if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,ReLGYUQjz7C9iEd(u"ࠨࡉࡈࡘࠬὉ"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠳ࡳࡦࠪὊ"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		Ok0lZfciATo6V = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩὋ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if Ok0lZfciATo6V:
			Ok0lZfciATo6V = PhpFa6EdVS[wFYiVd4r12x7CAQBL5SPof(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬὌ")][UwCT5Oz6Wo0BP]+Ok0lZfciATo6V[UwCT5Oz6Wo0BP]
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,E3i1eCBtN2w(u"ࠬࡍࡅࡕࠩὍ"),Ok0lZfciATo6V,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠸ࡹ࡮ࠧ὎"))
			GmX8rCfsEjogehqyFR = Pa6Q2LRkbtY0Id7nUNsZ.content
			import youtube_signature.cipher as q8nULG1RsHEYmOxCzlVJ7v,youtube_signature.json_script_engine as JdQHChX2Arzi6eBNDEk8gaVo4s
			SS5sovXA2zyC3GQUWu0m = KmFLAGNDghfX5eliOHxq8.SS5sovXA2zyC3GQUWu0m.Cipher()
			SS5sovXA2zyC3GQUWu0m._object_cache = {}
			BiFoDOTxMpgPN2JRH1wYLe0sCm3Qr = SS5sovXA2zyC3GQUWu0m._load_javascript(GmX8rCfsEjogehqyFR)
			aqsVK05Omyz14doteSpg76xG8rMUX = JGmfjhoyKZUl(ykE045Tatx(u"ࠧࡴࡶࡵࠫ὏"),str(BiFoDOTxMpgPN2JRH1wYLe0sCm3Qr))
			ZS3dYTk2B7grwie = KmFLAGNDghfX5eliOHxq8.GGPS7bixueVYWJtN5F9wkfo13L.JsonScriptEngine(aqsVK05Omyz14doteSpg76xG8rMUX)
	for dict in an5GQFpEJxW9:
		url = dict[lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡷࡵࡰࠬὐ")]
		if Vi1oNCM5kI7yJ0(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭ὑ") in url or url.count(ZYTyoA483N(u"ࠪࡷ࡮࡭࠽ࠨὒ"))>Mn5NGAdz6xc42s0:
			TNPEAmKFYZJjsktnx5eIoSM.append(dict)
		elif GmX8rCfsEjogehqyFR and qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡸ࠭ὓ") in list(dict.keys()) and UixkloZbzGw28ujW56X(u"ࠬࡹࡰࠨὔ") in list(dict.keys()):
			y2fatnIZjMK6FNwvLhBXGb4gzC = ZS3dYTk2B7grwie.execute(dict[yyZPkLCRX1xcBDN(u"࠭ࡳࠨὕ")])
			if y2fatnIZjMK6FNwvLhBXGb4gzC!=dict[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡴࠩὖ")]:
				dict[ee3tnwl7avk(u"ࠨࡷࡵࡰࠬὗ")] = url+IYC4iPxkTRUE85namF6(u"ࠩࠩࠫ὘")+dict[JP65RzKaScIf(u"ࠪࡷࡵ࠭Ὑ")]+vGg1hAkzqi8exVbN(u"ࠫࡂ࠭὚")+y2fatnIZjMK6FNwvLhBXGb4gzC
				TNPEAmKFYZJjsktnx5eIoSM.append(dict)
	for dict in TNPEAmKFYZJjsktnx5eIoSM:
		QAHN1PzTaF,S4IGfrgeiNY1,chflIRAL6C0k7Tpd5VsM83E2X4,dycYjuzoBkZxN96TmG173VRqLs,Zl1ERx3MtqoBb0gypuIF,W8M9s7e13Gf2LkyDmPdjlxQAaC = lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭Ὓ"),NIBsHMvSXb(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ὜"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨὝ"),vhZ5qjay1z94JmcMOgXe(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ὞"),Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠩ࠳ࠫὟ")
		try:
			VFbwiHyWrCkom8SBGxv = dict[IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡸࡾࡶࡥࠨὠ")]
			VFbwiHyWrCkom8SBGxv = VFbwiHyWrCkom8SBGxv.replace(IYC4iPxkTRUE85namF6(u"ࠫ࠰࠭ὡ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(JP65RzKaScIf(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧὢ"),VFbwiHyWrCkom8SBGxv,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			dycYjuzoBkZxN96TmG173VRqLs,QAHN1PzTaF,Zl1ERx3MtqoBb0gypuIF = items[UwCT5Oz6Wo0BP]
			EEO4ehLyWXkYs9Vv = Zl1ERx3MtqoBb0gypuIF.split(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࠬࠨὣ"))
			S4IGfrgeiNY1 = Zg9FeADE84jSRIvPCrzYulw3sL
			for r1OMYvp0ViTG in EEO4ehLyWXkYs9Vv: S4IGfrgeiNY1 += r1OMYvp0ViTG.split(dn9ouNryjHiBFQOhASvX(u"ࠧ࠯ࠩὤ"))[UwCT5Oz6Wo0BP]+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨ࠮ࠪὥ")
			S4IGfrgeiNY1 = S4IGfrgeiNY1.strip(IYC4iPxkTRUE85namF6(u"ࠩ࠯ࠫὦ"))
			if ZYTyoA483N(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫὧ") in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = str(float(dict[ReLGYUQjz7C9iEd(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬὨ")]*UixkloZbzGw28ujW56X(u"࠴࠴ক"))//A2MHFvoqpZ64gNbB(u"࠵࠵࠸࠴খ")/UixkloZbzGw28ujW56X(u"࠴࠴ক"))+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡱࡢࡱࡵࠣࠤࠬὩ")
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = Zg9FeADE84jSRIvPCrzYulw3sL
			if dycYjuzoBkZxN96TmG173VRqLs==ZYTyoA483N(u"࠭ࡴࡦࡺࡷࡸࠬὪ"): continue
			elif vhZ5qjay1z94JmcMOgXe(u"ࠧ࠭ࠩὫ") in VFbwiHyWrCkom8SBGxv:
				dycYjuzoBkZxN96TmG173VRqLs = qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡃ࠮࡚ࠬὬ")
				chflIRAL6C0k7Tpd5VsM83E2X4 = QAHN1PzTaF+F4skx1A3wOEh9lmPuZMnpCzR+W8M9s7e13Gf2LkyDmPdjlxQAaC+dict[ZYTyoA483N(u"ࠩࡶ࡭ࡿ࡫ࠧὭ")].split(ee3tnwl7avk(u"ࠪࡼࠬὮ"))[Mn5NGAdz6xc42s0]
			elif dycYjuzoBkZxN96TmG173VRqLs==Vi1oNCM5kI7yJ0(u"ࠫࡻ࡯ࡤࡦࡱࠪὯ"):
				dycYjuzoBkZxN96TmG173VRqLs = IYC4iPxkTRUE85namF6(u"ࠬ࡜ࡩࡥࡧࡲࠫὰ")
				chflIRAL6C0k7Tpd5VsM83E2X4 = W8M9s7e13Gf2LkyDmPdjlxQAaC+dict[JP65RzKaScIf(u"࠭ࡳࡪࡼࡨࠫά")].split(UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡹࠩὲ"))[Mn5NGAdz6xc42s0]+F4skx1A3wOEh9lmPuZMnpCzR+dict[E3i1eCBtN2w(u"ࠨࡨࡳࡷࠬέ")]+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡩࡴࡸ࠭ὴ")+F4skx1A3wOEh9lmPuZMnpCzR+QAHN1PzTaF
			elif dycYjuzoBkZxN96TmG173VRqLs==dn9ouNryjHiBFQOhASvX(u"ࠪࡥࡺࡪࡩࡰࠩή"):
				dycYjuzoBkZxN96TmG173VRqLs = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡆࡻࡤࡪࡱࠪὶ")
				chflIRAL6C0k7Tpd5VsM83E2X4 = W8M9s7e13Gf2LkyDmPdjlxQAaC+str(int(dict[IYC4iPxkTRUE85namF6(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩί")])/dn9ouNryjHiBFQOhASvX(u"࠶࠶࠰࠱গ"))+E3i1eCBtN2w(u"࠭࡫ࡩࡼࠣࠤࠬὸ")+dict[DKmLTA2yGtj(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨό")]+qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡥ࡫ࠫὺ")+F4skx1A3wOEh9lmPuZMnpCzR+QAHN1PzTaF
		except:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!=IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬύ"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		if JP65RzKaScIf(u"ࠪࡨࡺࡸ࠽ࠨὼ") in dict[qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡺࡸ࡬ࠨώ")]: NAdtOanYBmF0IWbMvXxz7lERiTjo = round(UixkloZbzGw28ujW56X(u"࠰࠯࠷ঙ")+float(dict[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡻࡲ࡭ࠩ὾")].split(yyZPkLCRX1xcBDN(u"࠭ࡤࡶࡴࡀࠫ὿"),ykE045Tatx(u"࠷ঘ"))[Mn5NGAdz6xc42s0].split(ReLGYUQjz7C9iEd(u"ࠧࠧࠩᾀ"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]))
		elif ZYTyoA483N(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫᾁ") in list(dict.keys()): NAdtOanYBmF0IWbMvXxz7lERiTjo = round(x9PULjztJOpu7b(u"࠱࠰࠸চ")+float(dict[UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬᾂ")])/KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠳࠳࠴࠵ছ"))
		else: NAdtOanYBmF0IWbMvXxz7lERiTjo = vGg1hAkzqi8exVbN(u"ࠪ࠴ࠬᾃ")
		if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬᾄ") not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = dict[vGg1hAkzqi8exVbN(u"ࠬࡹࡩࡻࡧࠪᾅ")].split(qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡸࠨᾆ"))[Mn5NGAdz6xc42s0]
		else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict[ykE045Tatx(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨᾇ")]
		if ReLGYUQjz7C9iEd(u"ࠨ࡫ࡱ࡭ࡹ࠭ᾈ") not in list(dict.keys()): dict[lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࡬ࡲ࡮ࡺࠧᾉ")] = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠴࠲࠶ࠧᾊ")
		dict[Vi1oNCM5kI7yJ0(u"ࠫࡹ࡯ࡴ࡭ࡧࠪᾋ")] = dycYjuzoBkZxN96TmG173VRqLs+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡀࠠࠡࠩᾌ")+chflIRAL6C0k7Tpd5VsM83E2X4+jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࠠࠡࠪࠪᾍ")+S4IGfrgeiNY1+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧ࠭ࠩᾎ")+dict[E3i1eCBtN2w(u"ࠨ࡫ࡷࡥ࡬࠭ᾏ")]+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࠬࠫᾐ")
		dict[NIBsHMvSXb(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫᾑ")] = chflIRAL6C0k7Tpd5VsM83E2X4.split(F4skx1A3wOEh9lmPuZMnpCzR)[UwCT5Oz6Wo0BP].split(E3i1eCBtN2w(u"ࠫࡰࡨࡰࡴࠩᾒ"))[UwCT5Oz6Wo0BP]
		dict[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡺࡹࡱࡧ࠵ࠫᾓ")] = dycYjuzoBkZxN96TmG173VRqLs
		dict[E3i1eCBtN2w(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨᾔ")] = QAHN1PzTaF
		dict[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡤࡱࡧࡩࡨࡹࠧᾕ")] = Zl1ERx3MtqoBb0gypuIF
		dict[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪᾖ")] = NAdtOanYBmF0IWbMvXxz7lERiTjo
		dict[IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪᾗ")] = W8M9s7e13Gf2LkyDmPdjlxQAaC
		aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	xHDsCzmVNBSuU7aAbyFXrwe9d4c,DONT46Rds9tg5cjybnH2r0hmBkzF,JJXr91fnmitVRBAxMh4SpuToN6g,EQw4Jx6FMmSpaHyizo,XXMbhDNk8tH9OodvE4uxjcK = [],[],[],[],[]
	BUnmlTkZRarM48dEL,ZFjH5017tIOn93W,ZZOfoDtXWbm6y4zFGMJqUVue,UVJLGFuSn3m76IcoAfNCqRkXPxzD,MVshf93imc7N8qRJeQwG4P2aSxpB = [],[],[],[],[]
	if DpgrWvF3wOCI5MEn4dXaGx:
		dict = {}
		dict[UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡸࡾࡶࡥ࠳ࠩᾘ")] = vhZ5qjay1z94JmcMOgXe(u"ࠫࡆ࠱ࡖࠨᾙ")
		dict[NIBsHMvSXb(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧᾚ")] = lU1fSmncFWjizwqZugyYBANML0(u"࠭࡭ࡱࡦࠪᾛ")
		dict[E3i1eCBtN2w(u"ࠧࡵ࡫ࡷࡰࡪ࠭ᾜ")] = dict[NIBsHMvSXb(u"ࠨࡶࡼࡴࡪ࠸ࠧᾝ")]+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࠽ࠤࠥ࠭ᾞ")+dict[ZYTyoA483N(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬᾟ")]+F4skx1A3wOEh9lmPuZMnpCzR+ttC4VURALPYKh(u"ࠫั๎ฯสࠢำ็๏ฯࠧᾠ")
		dict[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡻࡲ࡭ࠩᾡ")] = DpgrWvF3wOCI5MEn4dXaGx
		dict[vGg1hAkzqi8exVbN(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᾢ")] = DKmLTA2yGtj(u"ࠧ࠱ࠩᾣ")
		dict[eCpDE6wJtYUHn0GqK5(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩᾤ")] = E3i1eCBtN2w(u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭ᾥ")
		aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	if zUOoIHnWacwMtFr3yGkN2xu4gi:
		ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(zUOoIHnWacwMtFr3yGkN2xu4gi)
		jhtuNW60MDJegGloFPUXa5CB3T = list(zip(ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47))
		for title,yDTPzhEBKVJl7CX81 in jhtuNW60MDJegGloFPUXa5CB3T:
			dict = {}
			dict[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡸࡾࡶࡥ࠳ࠩᾦ")] = eCpDE6wJtYUHn0GqK5(u"ࠫࡆ࠱ࡖࠨᾧ")
			dict[eCpDE6wJtYUHn0GqK5(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧᾨ")] = ee3tnwl7avk(u"࠭࡭࠴ࡷ࠻ࠫᾩ")
			dict[wFYiVd4r12x7CAQBL5SPof(u"ࠧࡶࡴ࡯ࠫᾪ")] = yDTPzhEBKVJl7CX81
			if jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨ࡭ࡥࡴࡸ࠭ᾫ") in title: dict[E3i1eCBtN2w(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪᾬ")] = title.split(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪ࡯ࡧࡶࡳࠨᾭ"))[UwCT5Oz6Wo0BP].rsplit(F4skx1A3wOEh9lmPuZMnpCzR)[-Mn5NGAdz6xc42s0]
			else: dict[ZYTyoA483N(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬᾮ")] = A2MHFvoqpZ64gNbB(u"ࠬ࠷࠰ࠨᾯ")
			if title.count(F4skx1A3wOEh9lmPuZMnpCzR)>Mn5NGAdz6xc42s0:
				YUCPADxT3NrgM = title.rsplit(F4skx1A3wOEh9lmPuZMnpCzR)[-O4dklMvZ8ULcS]
				if YUCPADxT3NrgM.isdigit(): dict[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᾰ")] = YUCPADxT3NrgM
				else: dict[vGg1hAkzqi8exVbN(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᾱ")] = A2MHFvoqpZ64gNbB(u"ࠨ࠲࠳࠴࠵࠭ᾲ")
			if title==qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠰࠵ࠬᾳ"): dict[vGg1hAkzqi8exVbN(u"ࠪࡸ࡮ࡺ࡬ࡦࠩᾴ")] = dict[JP65RzKaScIf(u"ࠫࡹࡿࡰࡦ࠴ࠪ᾵")]+ReLGYUQjz7C9iEd(u"ࠬࡀࠠࠡࠩᾶ")+dict[NIBsHMvSXb(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨᾷ")]+F4skx1A3wOEh9lmPuZMnpCzR+YXm2qAbu8Qsx(u"ࠧอ๊าอࠥึใ๋หࠪᾸ")
			else: dict[JP65RzKaScIf(u"ࠨࡶ࡬ࡸࡱ࡫ࠧᾹ")] = dict[IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡷࡽࡵ࡫࠲ࠨᾺ")]+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠾ࠥࠦࠧΆ")+dict[x9PULjztJOpu7b(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ᾼ")]+F4skx1A3wOEh9lmPuZMnpCzR+dict[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭᾽")]+yyZPkLCRX1xcBDN(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ι")+dict[ReLGYUQjz7C9iEd(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ᾿")]
			aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	aTZNB9SyUCpHrPgK8lDE0xhA = sorted(aTZNB9SyUCpHrPgK8lDE0xhA,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: float(key[ReLGYUQjz7C9iEd(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ῀")]))
	if not aTZNB9SyUCpHrPgK8lDE0xhA:
		if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,x9PULjztJOpu7b(u"ࠩࡊࡉ࡙࠭῁"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠶ࡶ࡫ࠫῂ"))
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		qS5lWUzuCiJjxwyAo1EdtD6nprV = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IYC4iPxkTRUE85namF6(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧῃ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧῄ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		i68iLkExJaX = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ttC4VURALPYKh(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ῅"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		JXhn2P97BCK4yN1eWbLv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩῆ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		try: L9Ha8UpTPxvZSj0l = SiMblPt0wfKdhvx[ee3tnwl7avk(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬῇ")][E3i1eCBtN2w(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧῈ")][IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫΈ")][UixkloZbzGw28ujW56X(u"ࠫࡹ࡯ࡴ࡭ࡧࠪῊ")][OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡸࡵ࡯ࡵࠪΉ")][UwCT5Oz6Wo0BP][dn9ouNryjHiBFQOhASvX(u"࠭ࡴࡦࡺࡷࡸࠬῌ")]
		except: L9Ha8UpTPxvZSj0l = Zg9FeADE84jSRIvPCrzYulw3sL
		try: t0xhejPsHTO5WQfSlDJ3oFia6ZU7L = SiMblPt0wfKdhvx[eCpDE6wJtYUHn0GqK5(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ῍")][OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭῎")][DKmLTA2yGtj(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ῏")][ZYTyoA483N(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡐࡩࡸࡹࡡࡨࡧࡶࠫῐ")][UwCT5Oz6Wo0BP][IYC4iPxkTRUE85namF6(u"ࠫࡷࡻ࡮ࡴࠩῑ")][UwCT5Oz6Wo0BP][vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡺࡥࡹࡶࡷࠫῒ")]
		except: t0xhejPsHTO5WQfSlDJ3oFia6ZU7L = Zg9FeADE84jSRIvPCrzYulw3sL
		try: lt6Naxkn0dE2jp = SiMblPt0wfKdhvx[yNBjYsgc23xoW(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪΐ")][UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡳࡧࡤࡷࡴࡴࠧ῔")]
		except: lt6Naxkn0dE2jp = Zg9FeADE84jSRIvPCrzYulw3sL
		if qS5lWUzuCiJjxwyAo1EdtD6nprV or VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 or i68iLkExJaX or JXhn2P97BCK4yN1eWbLv or L9Ha8UpTPxvZSj0l or t0xhejPsHTO5WQfSlDJ3oFia6ZU7L or lt6Naxkn0dE2jp:
			if   qS5lWUzuCiJjxwyAo1EdtD6nprV: oHkimLnwDKNxlheUuGAMQIg9jY7dz = qS5lWUzuCiJjxwyAo1EdtD6nprV[UwCT5Oz6Wo0BP]
			elif VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6: oHkimLnwDKNxlheUuGAMQIg9jY7dz = VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6[UwCT5Oz6Wo0BP]
			elif i68iLkExJaX: oHkimLnwDKNxlheUuGAMQIg9jY7dz = i68iLkExJaX[UwCT5Oz6Wo0BP]
			elif JXhn2P97BCK4yN1eWbLv: oHkimLnwDKNxlheUuGAMQIg9jY7dz = JXhn2P97BCK4yN1eWbLv[UwCT5Oz6Wo0BP]
			elif L9Ha8UpTPxvZSj0l: oHkimLnwDKNxlheUuGAMQIg9jY7dz = L9Ha8UpTPxvZSj0l
			elif t0xhejPsHTO5WQfSlDJ3oFia6ZU7L: oHkimLnwDKNxlheUuGAMQIg9jY7dz = t0xhejPsHTO5WQfSlDJ3oFia6ZU7L
			elif lt6Naxkn0dE2jp: oHkimLnwDKNxlheUuGAMQIg9jY7dz = lt6Naxkn0dE2jp
			SMcIzDwl6ZYH5apGqtJWs = oHkimLnwDKNxlheUuGAMQIg9jY7dz.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			R4sklnAbdw6CvMu = PPQORjT2lc7SVkKwFI4D+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ้ำหࠥอไโ์า๎ํࠦแู๋้้้ࠣไสࠢ࠱࠲ࠥษ่ࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦ࠮࠯ࠢฦ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋ࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥ๐อหษฯࠤู๐มࠡ็ะำิࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎ูเไࠡษ็ๅ๏ี๊้ࠢส่ว์ࠧ῕")+u4IRSmrYMKkaHUBnDiLWh
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭ῖ"),R4sklnAbdw6CvMu+x9PULjztJOpu7b(u"ࠪࡠࡳࡢ࡮ࠨῗ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+UixkloZbzGw28ujW56X(u"ࠫึูวๅห้๋๊้ࠣࠦฬํ์อ࠭Ῐ")+u4IRSmrYMKkaHUBnDiLWh+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+SMcIzDwl6ZYH5apGqtJWs)
			return tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧῙ")+SMcIzDwl6ZYH5apGqtJWs,[],[]
		else: return ttC4VURALPYKh(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭Ὶ"),[],[]
	ccrMYZf56WKNl7kyeRu,cc9G7EPUaOZN,sQJ4oGWx9LvO6jUdFVzwit3EqTgK = [],[],[]
	for dict in aTZNB9SyUCpHrPgK8lDE0xhA:
		if dict[E3i1eCBtN2w(u"ࠧࡵࡻࡳࡩ࠷࠭Ί")]==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡘ࡬ࡨࡪࡵࠧ῜"):
			xHDsCzmVNBSuU7aAbyFXrwe9d4c.append(dict[Vi1oNCM5kI7yJ0(u"ࠩࡷ࡭ࡹࡲࡥࠨ῝")])
			BUnmlTkZRarM48dEL.append(dict)
		elif dict[wFYiVd4r12x7CAQBL5SPof(u"ࠪࡸࡾࡶࡥ࠳ࠩ῞")]==wFYiVd4r12x7CAQBL5SPof(u"ࠫࡆࡻࡤࡪࡱࠪ῟"):
			DONT46Rds9tg5cjybnH2r0hmBkzF.append(dict[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡺࡩࡵ࡮ࡨࠫῠ")])
			ZFjH5017tIOn93W.append(dict)
		elif dict[yNBjYsgc23xoW(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨῡ")]==YXm2qAbu8Qsx(u"ࠧ࡮ࡲࡧࠫῢ"):
			title = dict[ykE045Tatx(u"ࠨࡶ࡬ࡸࡱ࡫ࠧΰ")].replace(UixkloZbzGw28ujW56X(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩῤ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			if jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫῥ") not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = lU1fSmncFWjizwqZugyYBANML0(u"ࠫ࠵࠭ῦ")
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict[ykE045Tatx(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ῧ")]
			ccrMYZf56WKNl7kyeRu.append([dict,{},title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
		else:
			title = dict[ReLGYUQjz7C9iEd(u"࠭ࡴࡪࡶ࡯ࡩࠬῨ")].replace(YXm2qAbu8Qsx(u"ࠧࡂ࡙࠭࠾ࠥࠦࠧῩ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			if IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩῪ") not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = E3i1eCBtN2w(u"ࠩ࠳ࠫΎ")
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict[NIBsHMvSXb(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫῬ")]
			ccrMYZf56WKNl7kyeRu.append([dict,{},title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
			JJXr91fnmitVRBAxMh4SpuToN6g.append(title)
			ZZOfoDtXWbm6y4zFGMJqUVue.append(dict)
		MiLAY1z26vj5UTK = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if ttC4VURALPYKh(u"ࠫࡨࡵࡤࡦࡥࡶࠫ῭") in list(dict.keys()):
			if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡧࡶ࠱ࠩ΅") in dict[yyZPkLCRX1xcBDN(u"࠭ࡣࡰࡦࡨࡧࡸ࠭`")]: MiLAY1z26vj5UTK = vvglE69OFKBm817Nkc
			elif NGiBmYp8vX9T426lHn7ue<qdEKO42r3GhwmCDcHtxzJUR(u"࠴࠼জ"):
				if x9PULjztJOpu7b(u"ࠧࡢࡸࡦࠫ῰") not in dict[Vi1oNCM5kI7yJ0(u"ࠨࡥࡲࡨࡪࡩࡳࠨ῱")] and A2MHFvoqpZ64gNbB(u"ࠩࡰࡴ࠹ࡧࠧῲ") not in dict[ee3tnwl7avk(u"ࠪࡧࡴࡪࡥࡤࡵࠪῳ")]: MiLAY1z26vj5UTK = vvglE69OFKBm817Nkc
		if dict[ReLGYUQjz7C9iEd(u"ࠫࡹࡿࡰࡦ࠴ࠪῴ")]==x9PULjztJOpu7b(u"ࠬ࡜ࡩࡥࡧࡲࠫ῵") and dict[vGg1hAkzqi8exVbN(u"࠭ࡩ࡯࡫ࡷࠫῶ")]!=tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠱࠯࠳ࠫῷ") and MiLAY1z26vj5UTK==CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			XXMbhDNk8tH9OodvE4uxjcK.append(dict[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡶ࡬ࡸࡱ࡫ࠧῸ")])
			MVshf93imc7N8qRJeQwG4P2aSxpB.append(dict)
		elif dict[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡷࡽࡵ࡫࠲ࠨΌ")]==dn9ouNryjHiBFQOhASvX(u"ࠪࡅࡺࡪࡩࡰࠩῺ") and dict[UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࡮ࡴࡩࡵࠩΏ")]!=lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࠶࠭࠱ࠩῼ") and MiLAY1z26vj5UTK==CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			EQw4Jx6FMmSpaHyizo.append(dict[x9PULjztJOpu7b(u"࠭ࡴࡪࡶ࡯ࡩࠬ´")])
			UVJLGFuSn3m76IcoAfNCqRkXPxzD.append(dict)
	for giEV3vqyDHPaCklUreh in UVJLGFuSn3m76IcoAfNCqRkXPxzD:
		KAXSetWLral6y2 = giEV3vqyDHPaCklUreh[yNBjYsgc23xoW(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ῾")]
		for qIMNa2nOfgdkPxKETc0WJLZY in MVshf93imc7N8qRJeQwG4P2aSxpB:
			hX3J4Scy8FionrlDG1A = qIMNa2nOfgdkPxKETc0WJLZY[dn9ouNryjHiBFQOhASvX(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ῿")]
			W8M9s7e13Gf2LkyDmPdjlxQAaC = hX3J4Scy8FionrlDG1A+KAXSetWLral6y2
			title = qIMNa2nOfgdkPxKETc0WJLZY[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡹ࡯ࡴ࡭ࡧࠪࠀ")].replace(x9PULjztJOpu7b(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧࠁ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭࡭ࡱࡦࠣࠤࠬࠂ"))
			title = title.replace(qIMNa2nOfgdkPxKETc0WJLZY[UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩࠃ")]+F4skx1A3wOEh9lmPuZMnpCzR,Zg9FeADE84jSRIvPCrzYulw3sL)
			title = title.replace(str((float(hX3J4Scy8FionrlDG1A*Vi1oNCM5kI7yJ0(u"࠵࠵ঝ"))//DKmLTA2yGtj(u"࠶࠶࠲࠵ঞ")/Vi1oNCM5kI7yJ0(u"࠵࠵ঝ")))+ttC4VURALPYKh(u"ࠨ࡭ࡥࡴࡸ࠭ࠄ"),str((float(W8M9s7e13Gf2LkyDmPdjlxQAaC*Vi1oNCM5kI7yJ0(u"࠵࠵ঝ"))//DKmLTA2yGtj(u"࠶࠶࠲࠵ঞ")/Vi1oNCM5kI7yJ0(u"࠵࠵ঝ")))+JP65RzKaScIf(u"ࠩ࡮ࡦࡵࡹࠧࠅ"))
			title = title+A2MHFvoqpZ64gNbB(u"ࠪࠬࠬࠆ")+giEV3vqyDHPaCklUreh[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡹ࡯ࡴ࡭ࡧࠪࠇ")].split(YXm2qAbu8Qsx(u"ࠬ࠮ࠧࠈ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
			ccrMYZf56WKNl7kyeRu.append([qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
	ccrMYZf56WKNl7kyeRu = sorted(ccrMYZf56WKNl7kyeRu, reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy, key=lambda key: float(key[O4dklMvZ8ULcS]))
	for qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC in ccrMYZf56WKNl7kyeRu:
		AMv3D891O07rwVsYgb5tkziNxd2 = qIMNa2nOfgdkPxKETc0WJLZY[jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࠉ")]
		if eCpDE6wJtYUHn0GqK5(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩࠊ") in list(giEV3vqyDHPaCklUreh.keys()):
			AMv3D891O07rwVsYgb5tkziNxd2 = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨ࡯ࡳࡨࠬࠋ")
		if AMv3D891O07rwVsYgb5tkziNxd2 not in sQJ4oGWx9LvO6jUdFVzwit3EqTgK:
			sQJ4oGWx9LvO6jUdFVzwit3EqTgK.append(AMv3D891O07rwVsYgb5tkziNxd2)
			cc9G7EPUaOZN.append([qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
	SHVNdQ2ypFUZAMCtE7gOow9K,PTB6i0GMySIgqQlvd2UFZ3,BdAifjEWrcQ = [],[],UwCT5Oz6Wo0BP
	Cvz4PanE5N,cQOHCwI3nBsf24tRZ5hizLDSo = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	try: Cvz4PanE5N = SiMblPt0wfKdhvx[A2MHFvoqpZ64gNbB(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨࠌ")][YXm2qAbu8Qsx(u"ࠪࡥࡺࡺࡨࡰࡴࠪࠍ")]
	except: Cvz4PanE5N = Zg9FeADE84jSRIvPCrzYulw3sL
	try: d1lvAHTkc0RqX69s8zrO = SiMblPt0wfKdhvx[lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪࠎ")][zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨࠏ")]
	except: d1lvAHTkc0RqX69s8zrO = Zg9FeADE84jSRIvPCrzYulw3sL
	if Cvz4PanE5N and d1lvAHTkc0RqX69s8zrO:
		BdAifjEWrcQ += Mn5NGAdz6xc42s0
		title = PPQORjT2lc7SVkKwFI4D+ReLGYUQjz7C9iEd(u"࠭ࡏࡘࡐࡈࡖ࠿ࠦࠠࠨࠐ")+Cvz4PanE5N+u4IRSmrYMKkaHUBnDiLWh
		yDTPzhEBKVJl7CX81 = PhpFa6EdVS[vv3sNE8XCU2RAiyVaueTbD950pz(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨࠑ")][UwCT5Oz6Wo0BP]+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫࠒ")+d1lvAHTkc0RqX69s8zrO
		SHVNdQ2ypFUZAMCtE7gOow9K.append(title)
		PTB6i0GMySIgqQlvd2UFZ3.append(yDTPzhEBKVJl7CX81)
		try: cQOHCwI3nBsf24tRZ5hizLDSo = SiMblPt0wfKdhvx[ZYTyoA483N(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨࠓ")][yyZPkLCRX1xcBDN(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭ࠔ")][UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨࠕ")][-Mn5NGAdz6xc42s0][A2MHFvoqpZ64gNbB(u"ࠬࡻࡲ࡭ࠩࠖ")]
		except: pass
	for qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC in cc9G7EPUaOZN:
		SHVNdQ2ypFUZAMCtE7gOow9K.append(title) ; PTB6i0GMySIgqQlvd2UFZ3.append(Vi1oNCM5kI7yJ0(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧࠗ"))
	if JJXr91fnmitVRBAxMh4SpuToN6g: SHVNdQ2ypFUZAMCtE7gOow9K.append(dn9ouNryjHiBFQOhASvX(u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩ࠘")) ; PTB6i0GMySIgqQlvd2UFZ3.append(UQS9lVew50DIyXrinWsMxTzA(u"ࠨ࡯ࡸࡼࡪࡪࠧ࠙"))
	if ccrMYZf56WKNl7kyeRu: SHVNdQ2ypFUZAMCtE7gOow9K.append(YXm2qAbu8Qsx(u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭ࠚ")) ; PTB6i0GMySIgqQlvd2UFZ3.append(yyZPkLCRX1xcBDN(u"ࠪࡥࡱࡲࠧࠛ"))
	if XXMbhDNk8tH9OodvE4uxjcK: SHVNdQ2ypFUZAMCtE7gOow9K.append(IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡲࡶࡤࠡษัฮึࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭ࠜ")) ; PTB6i0GMySIgqQlvd2UFZ3.append(UixkloZbzGw28ujW56X(u"ࠬࡳࡰࡥࠩࠝ"))
	if xHDsCzmVNBSuU7aAbyFXrwe9d4c: SHVNdQ2ypFUZAMCtE7gOow9K.append(IK4zTnSMyGQpxEaesJAPVDY(u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭ࠞ")) ; PTB6i0GMySIgqQlvd2UFZ3.append(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡷ࡫ࡧࡩࡴ࠭ࠟ"))
	if DONT46Rds9tg5cjybnH2r0hmBkzF: SHVNdQ2ypFUZAMCtE7gOow9K.append(ykE045Tatx(u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨࠠ")) ; PTB6i0GMySIgqQlvd2UFZ3.append(wFYiVd4r12x7CAQBL5SPof(u"ࠩࡤࡹࡩ࡯࡯ࠨࠡ"))
	ktgDwbcXMKnVUBure5y3i6ToZFq = vvglE69OFKBm817Nkc
	while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(joIuF3TtfVUdby7K2N, SHVNdQ2ypFUZAMCtE7gOow9K)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return E3i1eCBtN2w(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࠢ"),[],[]
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP and Cvz4PanE5N:
			yDTPzhEBKVJl7CX81 = PTB6i0GMySIgqQlvd2UFZ3[lqQvOUWodZnhXLS2Vcuj6EtairFN]
			EEHGwO3V8XjP651npWNz4gmlMABS = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[UwCT5Oz6Wo0BP]+yyZPkLCRX1xcBDN(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫࠣ")+OJYiDeyvSPTNI9(Cvz4PanE5N)+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࠬࡵࡳ࡮ࡀࠫࠤ")+yDTPzhEBKVJl7CX81
			if cQOHCwI3nBsf24tRZ5hizLDSo: EEHGwO3V8XjP651npWNz4gmlMABS = EEHGwO3V8XjP651npWNz4gmlMABS+E3i1eCBtN2w(u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧࠥ")+OJYiDeyvSPTNI9(cQOHCwI3nBsf24tRZ5hizLDSo)
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(dn9ouNryjHiBFQOhASvX(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦࠦ")+EEHGwO3V8XjP651npWNz4gmlMABS+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠣࠫࠥࠧ"))
			return UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠨ"),[],[]
		KPAgkny9rSD0Xdx6CUse1a2LG = PTB6i0GMySIgqQlvd2UFZ3[lqQvOUWodZnhXLS2Vcuj6EtairFN]
		wq16EVmW5ezHgZj4MPxNsGA9Yn = SHVNdQ2ypFUZAMCtE7gOow9K[lqQvOUWodZnhXLS2Vcuj6EtairFN]
		if KPAgkny9rSD0Xdx6CUse1a2LG==yNBjYsgc23xoW(u"ࠪࡨࡦࡹࡨࠨࠩ"):
			MhpvcyiPkbw0atNDXBURgl = DpgrWvF3wOCI5MEn4dXaGx
			break
		elif KPAgkny9rSD0Xdx6CUse1a2LG in [YXm2qAbu8Qsx(u"ࠫࡦࡻࡤࡪࡱࠪࠪ"),ttC4VURALPYKh(u"ࠬࡼࡩࡥࡧࡲࠫࠫ"),NIBsHMvSXb(u"࠭࡭ࡶࡺࡨࡨࠬࠬ")]:
			if KPAgkny9rSD0Xdx6CUse1a2LG==JP65RzKaScIf(u"ࠧ࡮ࡷࡻࡩࡩ࠭࠭"): nnhWEIa6Tm,lYurfDCiEO8 = JJXr91fnmitVRBAxMh4SpuToN6g,ZZOfoDtXWbm6y4zFGMJqUVue
			elif KPAgkny9rSD0Xdx6CUse1a2LG==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡸ࡬ࡨࡪࡵࠧ࠮"): nnhWEIa6Tm,lYurfDCiEO8 = xHDsCzmVNBSuU7aAbyFXrwe9d4c,BUnmlTkZRarM48dEL
			elif KPAgkny9rSD0Xdx6CUse1a2LG==x9PULjztJOpu7b(u"ࠩࡤࡹࡩ࡯࡯ࠨ࠯"): nnhWEIa6Tm,lYurfDCiEO8 = DONT46Rds9tg5cjybnH2r0hmBkzF,ZFjH5017tIOn93W
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(wFYiVd4r12x7CAQBL5SPof(u"ࠪหำะัࠡษ็้้็ࠠࠩࠩ࠰")+str(len(nnhWEIa6Tm))+DKmLTA2yGtj(u"๋ࠫࠥไโࠫࠪ࠱"), nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				MhpvcyiPkbw0atNDXBURgl = lYurfDCiEO8[lqQvOUWodZnhXLS2Vcuj6EtairFN][YXm2qAbu8Qsx(u"ࠬࡻࡲ࡭ࠩ࠲")]
				wq16EVmW5ezHgZj4MPxNsGA9Yn = nnhWEIa6Tm[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				break
		elif KPAgkny9rSD0Xdx6CUse1a2LG==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭࡭ࡱࡦࠪ࠳"):
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(E3i1eCBtN2w(u"ࠧศะอีࠥา่ะหࠣห้฻่าหࠣࠬࠬ࠴")+str(len(XXMbhDNk8tH9OodvE4uxjcK))+x9PULjztJOpu7b(u"ࠨ่่ࠢๆ࠯ࠧ࠵"), XXMbhDNk8tH9OodvE4uxjcK)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				wq16EVmW5ezHgZj4MPxNsGA9Yn = XXMbhDNk8tH9OodvE4uxjcK[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				STY4hGQDjBcJqiz60RM8x2vFdWLlw = MVshf93imc7N8qRJeQwG4P2aSxpB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(wFYiVd4r12x7CAQBL5SPof(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊อࠤ࠭࠭࠶")+str(len(EQw4Jx6FMmSpaHyizo))+ZYTyoA483N(u"ࠪࠤ๊๊แࠪࠩ࠷"), EQw4Jx6FMmSpaHyizo)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
					wq16EVmW5ezHgZj4MPxNsGA9Yn += KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࠥ࠱ࠠࠨ࠸")+EQw4Jx6FMmSpaHyizo[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					Z9dKgxe7Nb1fsQrSjO5lanp = UVJLGFuSn3m76IcoAfNCqRkXPxzD[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					break
		elif KPAgkny9rSD0Xdx6CUse1a2LG==A2MHFvoqpZ64gNbB(u"ࠬࡧ࡬࡭ࠩ࠹"):
			YyEr2JT4sik9K0N,mmGJreUkZgyC5MWdpulA,QYUCZbet7qns,EEViDU6MofmWjqcXw = list(zip(*ccrMYZf56WKNl7kyeRu))
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬ࠺")+str(len(QYUCZbet7qns))+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࠡ็็ๅ࠮࠭࠻"), QYUCZbet7qns)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				wq16EVmW5ezHgZj4MPxNsGA9Yn = QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				STY4hGQDjBcJqiz60RM8x2vFdWLlw = YyEr2JT4sik9K0N[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				if ee3tnwl7avk(u"ࠨ࡯ࡳࡨࠬ࠼") in QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN] and STY4hGQDjBcJqiz60RM8x2vFdWLlw[JP65RzKaScIf(u"ࠩࡸࡶࡱ࠭࠽")]!=DpgrWvF3wOCI5MEn4dXaGx:
					Z9dKgxe7Nb1fsQrSjO5lanp = mmGJreUkZgyC5MWdpulA[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				else: MhpvcyiPkbw0atNDXBURgl = STY4hGQDjBcJqiz60RM8x2vFdWLlw[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡹࡷࡲࠧ࠾")]
				break
		elif KPAgkny9rSD0Xdx6CUse1a2LG==lU1fSmncFWjizwqZugyYBANML0(u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ࠿"):
			YyEr2JT4sik9K0N,mmGJreUkZgyC5MWdpulA,QYUCZbet7qns,EEViDU6MofmWjqcXw = list(zip(*cc9G7EPUaOZN))
			STY4hGQDjBcJqiz60RM8x2vFdWLlw = YyEr2JT4sik9K0N[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
			if x9PULjztJOpu7b(u"ࠬࡳࡰࡥࠩࡀ") in QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ] and STY4hGQDjBcJqiz60RM8x2vFdWLlw[jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡵࡳ࡮ࠪࡁ")]!=DpgrWvF3wOCI5MEn4dXaGx:
				Z9dKgxe7Nb1fsQrSjO5lanp = mmGJreUkZgyC5MWdpulA[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
				ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			else: MhpvcyiPkbw0atNDXBURgl = STY4hGQDjBcJqiz60RM8x2vFdWLlw[NIBsHMvSXb(u"ࠧࡶࡴ࡯ࠫࡂ")]
			wq16EVmW5ezHgZj4MPxNsGA9Yn = QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
			break
	if not ktgDwbcXMKnVUBure5y3i6ToZFq: c9RjgrzQxZ4YHJ5iT = MhpvcyiPkbw0atNDXBURgl
	else: c9RjgrzQxZ4YHJ5iT = Vi1oNCM5kI7yJ0(u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠩࡃ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡸࡶࡱ࠭ࡄ")]+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࠤ࠰ࠦࡁࡶࡦ࡬ࡳ࠿ࠦࠧࡅ")+Z9dKgxe7Nb1fsQrSjO5lanp[UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡺࡸ࡬ࠨࡆ")]
	if ktgDwbcXMKnVUBure5y3i6ToZFq:
		jp5HefdQzXwxV81myK6oGDEg = int(STY4hGQDjBcJqiz60RM8x2vFdWLlw[ReLGYUQjz7C9iEd(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧࡇ")])
		vTG7bx2PuBWEKYpXflOjs = int(Z9dKgxe7Nb1fsQrSjO5lanp[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨࡈ")])
		NAdtOanYBmF0IWbMvXxz7lERiTjo = str(max(jp5HefdQzXwxV81myK6oGDEg,vTG7bx2PuBWEKYpXflOjs))
		ZhjVrDwMlL2BdNU5skzHyC0cPpaFX1 = STY4hGQDjBcJqiz60RM8x2vFdWLlw[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡶࡴ࡯ࠫࡉ")].replace(vhZ5qjay1z94JmcMOgXe(u"ࠨࠨࠪࡊ"),UixkloZbzGw28ujW56X(u"ࠩࠩࡥࡲࡶ࠻ࠨࡋ"))
		DqUbITsrEQ = Z9dKgxe7Nb1fsQrSjO5lanp[IYC4iPxkTRUE85namF6(u"ࠪࡹࡷࡲࠧࡌ")].replace(x9PULjztJOpu7b(u"ࠫࠫ࠭ࡍ"),yNBjYsgc23xoW(u"ࠬࠬࡡ࡮ࡲ࠾ࠫࡎ"))
		mpd = UQS9lVew50DIyXrinWsMxTzA(u"࠭࠼ࡀࡺࡰࡰࠥࡼࡥࡳࡵ࡬ࡳࡳࡃࠢ࠲࠰࠳ࠦࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࠣࡗࡗࡊ࠲࠾ࠢࡀࡀ࡟ࡲࠬࡏ")
		mpd += wFYiVd4r12x7CAQBL5SPof(u"ࠧ࠽ࡏࡓࡈࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡹࡩ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠲࠱࠲࠴࠳࡝ࡓࡌࡔࡥ࡫ࡩࡲࡧ࠭ࡪࡰࡶࡸࡦࡴࡣࡦࠤࠣࡼࡲࡲ࡮ࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠧࠦࡸ࡮࡮ࡱࡷ࠿ࡾ࡬ࡪࡰ࡮ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠴࠽࠾࠿࠯ࡹ࡮࡬ࡲࡰࠨࠠࡹࡵ࡬࠾ࡸࡩࡨࡦ࡯ࡤࡐࡴࡩࡡࡵ࡫ࡲࡲࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠡࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡳࡪࡡࡳࡦࡶ࠲࡮ࡹ࡯࠯ࡱࡵ࡫࠴࡯ࡴࡵࡨ࠲ࡔࡺࡨ࡬ࡪࡥ࡯ࡽࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࡓࡵࡣࡱࡨࡦࡸࡤࡴ࠱ࡐࡔࡊࡍ࠭ࡅࡃࡖࡌࡤࡹࡣࡩࡧࡰࡥࡤ࡬ࡩ࡭ࡧࡶ࠳ࡉࡇࡓࡉ࠯ࡐࡔࡉ࠴ࡸࡴࡦࠥࠤࡲ࡯࡮ࡃࡷࡩࡪࡪࡸࡔࡪ࡯ࡨࡁࠧࡖࡔ࠲࠰࠸ࡗࠧࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨࡐ")+NAdtOanYBmF0IWbMvXxz7lERiTjo+vhZ5qjay1z94JmcMOgXe(u"ࠨࡕࠥࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࡂࡡࡴࠧࡑ")
		mpd += ttC4VURALPYKh(u"ࠩ࠿ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭ࡒ")
		mpd += A2MHFvoqpZ64gNbB(u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠲ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡷ࡫ࡧࡩࡴ࠵ࠧࡓ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[eCpDE6wJtYUHn0GqK5(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࡔ")]+vGg1hAkzqi8exVbN(u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡕࡴࡸࡩࠧࡄ࡜࡯ࠩࡕ")
		mpd += eCpDE6wJtYUHn0GqK5(u"࠭࠼ࡓࡱ࡯ࡩࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡄࡂࡕࡋ࠾ࡷࡵ࡬ࡦ࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣ࡯ࡤ࡭ࡳࠨ࠯࠿࡞ࡱࠫࡖ")
		mpd += NIBsHMvSXb(u"ࠧ࠽ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠢ࡬ࡨࡂࠨࠧࡗ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[Vi1oNCM5kI7yJ0(u"ࠨ࡫ࡷࡥ࡬࠭ࡘ")]+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁ࡙ࠧ࠭")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡧࡴࡪࡥࡤࡵ࡚ࠪ")]+ee3tnwl7avk(u"ࠫࠧࠦࡳࡵࡣࡵࡸ࡜࡯ࡴࡩࡕࡄࡔࡂࠨ࠱ࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࡛ࠧ")+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw[qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡜")])+ttC4VURALPYKh(u"࠭ࠢࠡࡹ࡬ࡨࡹ࡮࠽ࠣࠩ࡝")+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw[ee3tnwl7avk(u"ࠧࡸ࡫ࡧࡸ࡭࠭࡞")])+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࠤࠣ࡬ࡪ࡯ࡧࡩࡶࡀࠦࠬ࡟")+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw[dn9ouNryjHiBFQOhASvX(u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩࡠ")])+DKmLTA2yGtj(u"ࠪࠦࠥ࡬ࡲࡢ࡯ࡨࡖࡦࡺࡥ࠾ࠤࠪࡡ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[yyZPkLCRX1xcBDN(u"ࠫ࡫ࡶࡳࠨࡢ")]+x9PULjztJOpu7b(u"ࠬࠨ࠾࡝ࡰࠪࡣ")
		mpd += ZYTyoA483N(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩࡤ")+ZhjVrDwMlL2BdNU5skzHyC0cPpaFX1+vhZ5qjay1z94JmcMOgXe(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭ࡥ")
		mpd += IK4zTnSMyGQpxEaesJAPVDY(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭ࡦ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ࡬ࡲࡩ࡫ࡸࠨࡧ")]+vGg1hAkzqi8exVbN(u"ࠪࠦࡃࡢ࡮ࠨࡨ")
		mpd += E3i1eCBtN2w(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧࡩ")+STY4hGQDjBcJqiz60RM8x2vFdWLlw[IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࡯࡮ࡪࡶࠪࡪ")]+yyZPkLCRX1xcBDN(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭࡫")
		mpd += vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ࡬")
		mpd += yNBjYsgc23xoW(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ࡭")
		mpd += vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ࡮")
		mpd += IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠳ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧ࡯")+Z9dKgxe7Nb1fsQrSjO5lanp[UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ࡰ")]+lU1fSmncFWjizwqZugyYBANML0(u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡕࡴࡸࡩࠧࡄ࡜࡯ࠩࡱ")
		mpd += tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭࠼ࡓࡱ࡯ࡩࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡄࡂࡕࡋ࠾ࡷࡵ࡬ࡦ࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣ࡯ࡤ࡭ࡳࠨ࠯࠿࡞ࡱࠫࡲ")
		mpd += eCpDE6wJtYUHn0GqK5(u"ࠧ࠽ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠢ࡬ࡨࡂࠨࠧࡳ")+Z9dKgxe7Nb1fsQrSjO5lanp[ZYTyoA483N(u"ࠨ࡫ࡷࡥ࡬࠭ࡴ")]+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭ࡵ")+Z9dKgxe7Nb1fsQrSjO5lanp[qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡧࡴࡪࡥࡤࡵࠪࡶ")]+eCpDE6wJtYUHn0GqK5(u"ࠫࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥ࠵࠸࠶࠴࠸࠷ࠥࡂࡡࡴࠧࡷ")
		mpd += lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡂࡁࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽࠶࠸࠶࠰࠴࠼࠶࠾ࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠫࡸ")+Z9dKgxe7Nb1fsQrSjO5lanp[IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧࡹ")]+IYC4iPxkTRUE85namF6(u"ࠧࠣ࠱ࡁࡠࡳ࠭ࡺ")
		mpd += ttC4VURALPYKh(u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫࡻ")+DqUbITsrEQ+ttC4VURALPYKh(u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨࡼ")
		mpd += vGg1hAkzqi8exVbN(u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨࡽ")+Z9dKgxe7Nb1fsQrSjO5lanp[ee3tnwl7avk(u"ࠫ࡮ࡴࡤࡦࡺࠪࡾ")]+UQS9lVew50DIyXrinWsMxTzA(u"ࠬࠨ࠾࡝ࡰࠪࡿ")
		mpd += UQS9lVew50DIyXrinWsMxTzA(u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩࢀ")+Z9dKgxe7Nb1fsQrSjO5lanp[yyZPkLCRX1xcBDN(u"ࠧࡪࡰ࡬ࡸࠬࢁ")]+ReLGYUQjz7C9iEd(u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨࢂ")
		mpd += ee3tnwl7avk(u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬࢃ")
		mpd += E3i1eCBtN2w(u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩࢄ")
		mpd += lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩࢅ")
		mpd += vGg1hAkzqi8exVbN(u"ࠬࡂ࠯ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪࢆ")
		mpd += yNBjYsgc23xoW(u"࠭࠼࠰ࡏࡓࡈࡃࡢ࡮ࠨࢇ")
		if GGfPQnrJKEqMv2ZVxdD:
			import http.server as ddg7f8JuRIBPzQkhFOXsECKjTGnp3o
			import http.client as ss0f1CFxiL
		else:
			import BaseHTTPServer as ddg7f8JuRIBPzQkhFOXsECKjTGnp3o
			import httplib as ss0f1CFxiL
		class y4yNqHekmVoFOr7TdYn(ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.HTTPServer):
			def __init__(rX4tN2IJPD0yYa1jw8WlSmCL,ip=JP65RzKaScIf(u"ࠧ࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶࠪ࢈"),port=dn9ouNryjHiBFQOhASvX(u"࠻࠵࠱࠷࠸ট"),mpd=IYC4iPxkTRUE85namF6(u"ࠨ࠾ࡁࠫࢉ")):
				rX4tN2IJPD0yYa1jw8WlSmCL.ip = ip
				rX4tN2IJPD0yYa1jw8WlSmCL.port = port
				rX4tN2IJPD0yYa1jw8WlSmCL.mpd = mpd
				ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.HTTPServer.__init__(rX4tN2IJPD0yYa1jw8WlSmCL,(rX4tN2IJPD0yYa1jw8WlSmCL.ip,rX4tN2IJPD0yYa1jw8WlSmCL.port),BXNDfIuhWrctnSo1v4)
				rX4tN2IJPD0yYa1jw8WlSmCL.mpdurl = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪࢊ")+ip+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪ࠾ࠬࢋ")+str(port)+eCpDE6wJtYUHn0GqK5(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪࢌ")
			def start(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.threads = fZLqV6xaCWsTItK2ngd(vvglE69OFKBm817Nkc)
				rX4tN2IJPD0yYa1jw8WlSmCL.threads.FHEp9T3OzwUf6BSq(Mn5NGAdz6xc42s0,rX4tN2IJPD0yYa1jw8WlSmCL.FFDyejL7S46)
			def FFDyejL7S46(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				while rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning:
					rX4tN2IJPD0yYa1jw8WlSmCL.handle_request()
			def stop(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning = vvglE69OFKBm817Nkc
				rX4tN2IJPD0yYa1jw8WlSmCL.Ig1jWXvabcN7P()
			def ETwjFlzhWc(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.stop()
				rX4tN2IJPD0yYa1jw8WlSmCL.M8hdlBv4XYT.close()
				rX4tN2IJPD0yYa1jw8WlSmCL.server_close()
			def fzaC0BNKvxpdwbmgn5l6Eo78Rqs2jV(rX4tN2IJPD0yYa1jw8WlSmCL,mpd):
				rX4tN2IJPD0yYa1jw8WlSmCL.mpd = mpd
			def Ig1jWXvabcN7P(rX4tN2IJPD0yYa1jw8WlSmCL):
				KAyrTaiwVmYnCS2NbPp = ss0f1CFxiL.HTTPConnection(rX4tN2IJPD0yYa1jw8WlSmCL.ip+A2MHFvoqpZ64gNbB(u"ࠬࡀࠧࢍ")+str(rX4tN2IJPD0yYa1jw8WlSmCL.port))
				KAyrTaiwVmYnCS2NbPp.request(ttC4VURALPYKh(u"ࠨࡈࡆࡃࡇࠦࢎ"), zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠢ࠰ࠤ࢏"))
		class BXNDfIuhWrctnSo1v4(ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.BaseHTTPRequestHandler):
			def LqfeBsNQymvY5hK1lEpju9(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.send_response(A2MHFvoqpZ64gNbB(u"࠲࠱࠲ঠ"))
				rX4tN2IJPD0yYa1jw8WlSmCL.send_header(A2MHFvoqpZ64gNbB(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ࢐"),dn9ouNryjHiBFQOhASvX(u"ࠩࡷࡩࡽࡺࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ࢑"))
				rX4tN2IJPD0yYa1jw8WlSmCL.end_headers()
				rX4tN2IJPD0yYa1jw8WlSmCL.wfile.write(rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.mpd.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
				LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
				if rX4tN2IJPD0yYa1jw8WlSmCL.path==NIBsHMvSXb(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ࢒"): rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.ETwjFlzhWc()
				if rX4tN2IJPD0yYa1jw8WlSmCL.path==IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ࢓"): rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.ETwjFlzhWc()
			def IYxNW2RDMBnFrTc7JV(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.send_response(IYC4iPxkTRUE85namF6(u"࠳࠲࠳ড"))
				rX4tN2IJPD0yYa1jw8WlSmCL.end_headers()
		U3DI1pSatT9GbyXeP6Rd = y4yNqHekmVoFOr7TdYn(UQS9lVew50DIyXrinWsMxTzA(u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ࢔"),UixkloZbzGw28ujW56X(u"࠷࠸࠴࠺࠻ঢ"),mpd)
		MhpvcyiPkbw0atNDXBURgl = U3DI1pSatT9GbyXeP6Rd.mpdurl
		U3DI1pSatT9GbyXeP6Rd.start()
	else: U3DI1pSatT9GbyXeP6Rd = Zg9FeADE84jSRIvPCrzYulw3sL
	if not MhpvcyiPkbw0atNDXBURgl: return eCpDE6wJtYUHn0GqK5(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭࢕"),[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[[MhpvcyiPkbw0atNDXBURgl,aXT8hF9ylD6pMHj7BZsYQnA,U3DI1pSatT9GbyXeP6Rd]]
def FF5NbecBfM1ED36lQ(url):
	headers = { OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࢖") : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨࢗ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭࢘"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = set(items)
	items = sorted(items, reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy, key=lambda key: key[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr])
	ORuP1Qjt7DETJvNHKr,nnhWEIa6Tm,VRzd5ahswMGUtuCKpLjroP9T6kx47,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[],[],[]
	if not items: return vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡄࡒࡆ࢙ࠬ"),[],[]
	for yDTPzhEBKVJl7CX81,DMKySWniQ0HqtCsrg65dmb2Tha,cwMyvBgJuRXLWH48kpndbG7q2a in items:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(qdEKO42r3GhwmCDcHtxzJUR(u"ࠫ࡭ࡺࡴࡱࡵ࠽࢚ࠫ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࡮ࡴࡵࡲ࠽࢛ࠫ"))
		if NIBsHMvSXb(u"࠭࠮࡮࠵ࡸ࠼ࠬ࢜") in yDTPzhEBKVJl7CX81:
			ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
			fo6s53yEnbklLpaJOzgR4Q01wxB = fo6s53yEnbklLpaJOzgR4Q01wxB + VRzd5ahswMGUtuCKpLjroP9T6kx47
			if ORuP1Qjt7DETJvNHKr[UwCT5Oz6Wo0BP]==x9PULjztJOpu7b(u"ࠧ࠮࠳ࠪ࢝"): nnhWEIa6Tm.append(ZYTyoA483N(u"ࠨีํีๆืࠠฯษุࠫ࢞")+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ࢟"))
			else:
				for title in ORuP1Qjt7DETJvNHKr:
					nnhWEIa6Tm.append(IK4zTnSMyGQpxEaesJAPVDY(u"ࠪื๏ืแาࠢัหฺ࠭ࢠ")+Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J+title)
		else:
			title = x9PULjztJOpu7b(u"ุࠫ๐ัโำࠣาฬ฻ࠧࢡ")+yNBjYsgc23xoW(u"ࠬࠦࠠࠡ࡯ࡳ࠸ࠥࠦࠠࠨࢢ")+cwMyvBgJuRXLWH48kpndbG7q2a
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(title)
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def ymNcGjZfWdUuv2sSpelH(url,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG):
	joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0,R6R2SncUg57LCAFd0,ffCVRQTFby24aYhA3szw8W,CPv45ibdnBc = [],[],[],[],[]
	if UixkloZbzGw28ujW56X(u"࠭ࡳࡵࡴࠪࢣ") not in str(type(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)): yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,UixkloZbzGw28ujW56X(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧࢤ"))
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠨ࠾ࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢥ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢦ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢧ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		title = yDTPzhEBKVJl7CX81.rsplit(yNBjYsgc23xoW(u"ࠫ࠳࠭ࢨ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠴ণ"))[Mn5NGAdz6xc42s0]
		joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	else:
		qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠࠫࠪ࡟࡟࠳࠰࠿࡝࡟ࠬࠫࢩ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vhZ5qjay1z94JmcMOgXe(u"࠭ࡶࡢࡴࠣࡷࡴࡻࡲࡤࡧࡶࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪࠩࢪ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ZYTyoA483N(u"ࠧࡷࡣࡵࠤ࡯ࡽࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬࢫ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(DKmLTA2yGtj(u"ࠨࡸࡤࡶࠥࡶ࡬ࡢࡻࡨࡶࠥࡃࠠ࠯ࠬࡂࡠ࠭࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩ࡝ࠫࠪࢬ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if qLx93JtrVCHlKaZW2hXc7dpiNmDR:
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = qLx93JtrVCHlKaZW2hXc7dpiNmDR[UwCT5Oz6Wo0BP]
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࡴࠪࠬࡠࡢࡻ࡝࠮ࡠ࡟ࡡࡺ࡜ࡴ࡞ࡱࡠࡷࡣࠪࠪࠪ࡟ࡻ࠰ࡡ࡜ࡵ࡞ࡶࡡ࠯࠯࠺ࠨࢭ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࡵࠫࡡ࠷ࠢ࡝࠴ࠥ࠾ࠬࢮ"),qLx93JtrVCHlKaZW2hXc7dpiNmDR)
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = JGmfjhoyKZUl(lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡩ࡯ࡣࡵࠩࢯ"),qLx93JtrVCHlKaZW2hXc7dpiNmDR)
			if isinstance(qLx93JtrVCHlKaZW2hXc7dpiNmDR,dict): qLx93JtrVCHlKaZW2hXc7dpiNmDR = [qLx93JtrVCHlKaZW2hXc7dpiNmDR]
			for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
				zF90fUaVNHqwh5CK,yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
				if isinstance(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,dict):
					keys = list(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.keys())
					if   OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡺࡹࡱࡧࠪࢰ") in keys: zF90fUaVNHqwh5CK = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡴࡺࡲࡨࠫࢱ")])
					if   DKmLTA2yGtj(u"ࠧࡧ࡫࡯ࡩࠬࢲ") in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[JP65RzKaScIf(u"ࠨࡨ࡬ࡰࡪ࠭ࢳ")]
					elif UixkloZbzGw28ujW56X(u"ࠩ࡫ࡰࡸ࠭ࢴ") in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[NIBsHMvSXb(u"ࠪ࡬ࡱࡹࠧࢵ")]
					elif KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡸࡸࡣࠨࢶ") in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[ttC4VURALPYKh(u"ࠬࡹࡲࡤࠩࢷ")]
					if   vhZ5qjay1z94JmcMOgXe(u"࠭࡬ࡢࡤࡨࡰࠬࢸ") in keys: title = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[YXm2qAbu8Qsx(u"ࠧ࡭ࡣࡥࡩࡱ࠭ࢹ")])
					elif x9PULjztJOpu7b(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡩࡧ࡬࡫࡭ࡺࠧࢺ") in keys: title = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[UixkloZbzGw28ujW56X(u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡪࡨ࡭࡬࡮ࡴࠨࢻ")])
					elif A2MHFvoqpZ64gNbB(u"ࠪ࠲ࠬࢼ") in yDTPzhEBKVJl7CX81: title = yDTPzhEBKVJl7CX81.rsplit(dn9ouNryjHiBFQOhASvX(u"ࠫ࠳࠭ࢽ"),UixkloZbzGw28ujW56X(u"࠵ত"))[Mn5NGAdz6xc42s0]
					else: title = yDTPzhEBKVJl7CX81
				elif isinstance(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,str):
					yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA
					title = yDTPzhEBKVJl7CX81.rsplit(yNBjYsgc23xoW(u"ࠬ࠴ࠧࢾ"),ykE045Tatx(u"࠶থ"))[Mn5NGAdz6xc42s0]
				if Mn5NGAdz6xc42s0:
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title+F4skx1A3wOEh9lmPuZMnpCzR+zF90fUaVNHqwh5CK)
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	for yDTPzhEBKVJl7CX81,title in zip(ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93):
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(ykE045Tatx(u"࠭࡜࡝࠱ࠪࢿ"),yNBjYsgc23xoW(u"ࠧ࠰ࠩࣀ"))
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,Vi1oNCM5kI7yJ0(u"ࠨࡷࡵࡰࠬࣁ"))
		qoCMENGx4WgKp = lAfzvsbYy7oQ3r28EMe()
		if IYC4iPxkTRUE85namF6(u"ࠩ࡫ࡸࡹࡶࠧࣂ") not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = m0t48jnKhrQFJViguoMl9NBPp+yDTPzhEBKVJl7CX81
		if vGg1hAkzqi8exVbN(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩࣃ") in yDTPzhEBKVJl7CX81:
			headers = {KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣄ"):qoCMENGx4WgKp,UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ࣅ"):m0t48jnKhrQFJViguoMl9NBPp}
			ipStRL9IF7O31elgsNdhKxu,il7RMnzUYqN3XPw = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81,headers)
			ffCVRQTFby24aYhA3szw8W += il7RMnzUYqN3XPw
			R6R2SncUg57LCAFd0 += ipStRL9IF7O31elgsNdhKxu
		else:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+A2MHFvoqpZ64gNbB(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬࣆ")+qoCMENGx4WgKp+ZYTyoA483N(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣇ")+m0t48jnKhrQFJViguoMl9NBPp
			ffCVRQTFby24aYhA3szw8W.append(yDTPzhEBKVJl7CX81)
			R6R2SncUg57LCAFd0.append(title)
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	if ffCVRQTFby24aYhA3szw8W: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = Zg9FeADE84jSRIvPCrzYulw3sL,R6R2SncUg57LCAFd0,ffCVRQTFby24aYhA3szw8W
	else:
		if UQS9lVew50DIyXrinWsMxTzA(u"ࠨ࠾ࠪࣈ") not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG and len(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)<yNBjYsgc23xoW(u"࠷࠰࠱দ") and yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		else:
			msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠿ࡨ࡮ࡼࠠࡴࡶࡼࡰࡪࡃࠢ࠯ࠬࡂࠦࡃ࠮ࡆࡪ࡮ࡨ࠲࠯ࡅࠩ࠽ࠩࣉ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not msg: msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡸࡳࡣࡻ࡯ࡤࡦࡱࡢࡷࡹࡻࡢࡠࡶࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭࣊"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not msg: msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡁ࡮࠲࠿ࠪࡖࡳࡷࡸࡹ࠯ࠬࡂ࠭ࡁ࠭࣋"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if msg: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = msg[UwCT5Oz6Wo0BP]
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
def vv9RFhuai06TJOHnoYBd7wVI1(OYJSXhfiyznTILqxurj2cwZU,url):
	global xxvdQOw03tRrG6
	url = url.strip(ykE045Tatx(u"ࠬ࠵ࠧ࣌"))
	LE9gRTxzt856dh3K1F,EEFf6enQDxk = Zg9FeADE84jSRIvPCrzYulw3sL,{}
	headers = {ee3tnwl7avk(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࣍"):lAfzvsbYy7oQ3r28EMe()}
	headers[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࣎")] = G9GCDqXJFAc(url,NIBsHMvSXb(u"ࠨࡷࡵࡰ࣏ࠬ"))
	headers[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨ࣐ࠫ")] = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼࣑ࠫ")
	headers[ykE045Tatx(u"ࠫࡘ࡫ࡣ࠮ࡈࡨࡸࡨ࡮࠭ࡅࡧࡶࡸ࣒ࠬ")] = ZYTyoA483N(u"ࠬ࡯ࡦࡳࡣࡰࡩ࣓ࠬ")
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡇࡆࡖࠪࣔ"),url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,yNBjYsgc23xoW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩࣕ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	OxJ3WCimXvjuMZ6Fk = Pa6Q2LRkbtY0Id7nUNsZ.code
	if not isinstance(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,str): yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,ykE045Tatx(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨࣖ"))
	if yyZPkLCRX1xcBDN(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࠨࣗ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮࡞ࡨࡷࡣ࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭ࣘ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			try: LE9gRTxzt856dh3K1F = Uu6MqoJxLtkimFsdYhc2Nvef(nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP])
			except: LE9gRTxzt856dh3K1F = Zg9FeADE84jSRIvPCrzYulw3sL
	if NIBsHMvSXb(u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠭ࠬࣙ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡪ࠯ࡹ࠱ࡴࠬࡵ࠮ࡨ࠰ࡷ࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬࣚ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			try: LE9gRTxzt856dh3K1F = YE6NfDK7nZtwTs(nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP])
			except: LE9gRTxzt856dh3K1F = Zg9FeADE84jSRIvPCrzYulw3sL
	CNhQcnS0dI6UFjbvLoyx = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG+LE9gRTxzt856dh3K1F
	if vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࠢࡪࡦ࠵ࠦࠬࣛ") in CNhQcnS0dI6UFjbvLoyx or okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࠣ࡫ࡧࠦࠬࣜ") in CNhQcnS0dI6UFjbvLoyx:
		wjEFWihDBaM = url.split(vGg1hAkzqi8exVbN(u"ࠨ࠱ࠪࣝ"))[O4dklMvZ8ULcS].replace(IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩࣞ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(yNBjYsgc23xoW(u"ࠪ࠲࡭ࡺ࡭࡭ࠩࣟ"),Zg9FeADE84jSRIvPCrzYulw3sL)
		if x9PULjztJOpu7b(u"ࠫࠧ࡯ࡤ࠳ࠤࠪ࣠") in CNhQcnS0dI6UFjbvLoyx: EEFf6enQDxk = {UixkloZbzGw28ujW56X(u"ࠬ࡯ࡤ࠳ࠩ࣡"):wjEFWihDBaM,Vi1oNCM5kI7yJ0(u"࠭࡯ࡱࠩ࣢"):IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࣣࠪ")}
		elif UixkloZbzGw28ujW56X(u"ࠨࠤ࡬ࡨࠧ࠭ࣤ") in CNhQcnS0dI6UFjbvLoyx: EEFf6enQDxk = {lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࡬ࡨࠬࣥ"):wjEFWihDBaM,ttC4VURALPYKh(u"ࠪࡳࡵࣦ࠭"):vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧࣧ")}
		Y3OmVPp2ARgBCjn = headers.copy()
		Y3OmVPp2ARgBCjn[DKmLTA2yGtj(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫࣨ")] = x9PULjztJOpu7b(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࣩࠬ")
		zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,JP65RzKaScIf(u"ࠧࡑࡑࡖࡘࠬ࣪"),url,EEFf6enQDxk,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ࣫"))
		CNhQcnS0dI6UFjbvLoyx = zCDbxZtwOE6.content
	CUcuT2nrbsJwY9GQdI37K,nnhRcEpIPOr7k4L1UHldzuBfg8KMj,l8ochfSOAkKMRPCUaW7 = ymNcGjZfWdUuv2sSpelH(url,CNhQcnS0dI6UFjbvLoyx)
	xxvdQOw03tRrG6[OYJSXhfiyznTILqxurj2cwZU] = CUcuT2nrbsJwY9GQdI37K,nnhRcEpIPOr7k4L1UHldzuBfg8KMj,l8ochfSOAkKMRPCUaW7,OxJ3WCimXvjuMZ6Fk
	return
xxvdQOw03tRrG6,VzeEkWnN6Rl = {},UwCT5Oz6Wo0BP
def T5T0LfYeA6(url):
	global xxvdQOw03tRrG6,VzeEkWnN6Rl
	CPv45ibdnBc,threads = [],[]
	VzeEkWnN6Rl += eCpDE6wJtYUHn0GqK5(u"࠱࠱࠲ধ")
	bbEU3QqZpXGfs = VzeEkWnN6Rl
	CPv45ibdnBc.append([Mn5NGAdz6xc42s0,url])
	xxvdQOw03tRrG6[bbEU3QqZpXGfs+Mn5NGAdz6xc42s0] = [None,None,None,None]
	bB5kF8zAXr6nUmL = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=vv9RFhuai06TJOHnoYBd7wVI1,args=(bbEU3QqZpXGfs+Mn5NGAdz6xc42s0,url))
	bB5kF8zAXr6nUmL.start()
	bB5kF8zAXr6nUmL.join(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠲࠲ন"))
	if not xxvdQOw03tRrG6[bbEU3QqZpXGfs+IK4zTnSMyGQpxEaesJAPVDY(u"࠳঩")][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]:
		hc5ePKxl4LJvEjDgTm = url.replace(qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ࣬"),NIBsHMvSXb(u"ࠪ࠳࣭ࠬ"))
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(JP65RzKaScIf(u"ࠫࡣ࠮࠮ࠫࡁ࠽࠳࠴࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅ࣮ࠩࠥࠩ"),hc5ePKxl4LJvEjDgTm+vGg1hAkzqi8exVbN(u"ࠬ࠵࣯ࠧ"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		start,FE6Ugdau8WbYP,end = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		end = end.strip(yNBjYsgc23xoW(u"࠭࠯ࠨࣰ"))
		YafkZxvGitNEVuKBlWwohIp = len(FE6Ugdau8WbYP)<NEc173Pr0jAwLF5OS or FE6Ugdau8WbYP in [KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡧ࡫࡯ࡩࣱࠬ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡸ࡬ࡨࡪࡵࣲࠧ"),ee3tnwl7avk(u"ࠩࡹ࡭ࡩ࡫࡯ࡦ࡯ࡥࡩࡩ࠭ࣳ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡥ࡯ࡧࡸࠨࣴ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫࣵ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡳࡩࡳࡴࡲࡶࣶࠬ")]
		if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([DpahB8cwl4ZeKVsg71RuibSAfx0Ejr,start+ReLGYUQjz7C9iEd(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧࣷ")+FE6Ugdau8WbYP+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠰ࠩࣸ")+end])
		if end: CPv45ibdnBc.append([O4dklMvZ8ULcS,start+vhZ5qjay1z94JmcMOgXe(u"ࠨ࠱ࣹࠪ")+FE6Ugdau8WbYP+E3i1eCBtN2w(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࣺࠪ")+end])
		if dn9ouNryjHiBFQOhASvX(u"ࠪ࠲࡭ࡺ࡭࡭ࠩࣻ") in FE6Ugdau8WbYP:
			wYkMpSyTjdorCxvWXJZqentfsLU0 = FE6Ugdau8WbYP.replace(qdEKO42r3GhwmCDcHtxzJUR(u"ࠫ࠳࡮ࡴ࡮࡮ࠪࣼ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			CPv45ibdnBc.append([NEc173Pr0jAwLF5OS,start+lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࠵ࠧࣽ")+wYkMpSyTjdorCxvWXJZqentfsLU0+qdEKO42r3GhwmCDcHtxzJUR(u"࠭࠯ࠨࣾ")+end])
			CPv45ibdnBc.append([x9PULjztJOpu7b(u"࠸প"),start+ReLGYUQjz7C9iEd(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨࣿ")+wYkMpSyTjdorCxvWXJZqentfsLU0+dn9ouNryjHiBFQOhASvX(u"ࠨ࠱ࠪऀ")+end])
			if end: CPv45ibdnBc.append([UixkloZbzGw28ujW56X(u"࠺ফ"),start+x9PULjztJOpu7b(u"ࠩ࠲ࠫँ")+wYkMpSyTjdorCxvWXJZqentfsLU0+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫं")+end])
		elif IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࠳࡮ࡴ࡮࡮ࠪः") in end:
			EyfIJ2FB4orR1iXV8h0 = end.replace(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠴ࡨࡵ࡯࡯ࠫऄ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			CPv45ibdnBc.append([vv3sNE8XCU2RAiyVaueTbD950pz(u"࠼ব"),start+x9PULjztJOpu7b(u"࠭࠯ࠨअ")+FE6Ugdau8WbYP+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧ࠰ࠩआ")+EyfIJ2FB4orR1iXV8h0])
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([wFYiVd4r12x7CAQBL5SPof(u"࠾ভ"),start+A2MHFvoqpZ64gNbB(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩइ")+FE6Ugdau8WbYP+dn9ouNryjHiBFQOhASvX(u"ࠩ࠲ࠫई")+EyfIJ2FB4orR1iXV8h0])
			CPv45ibdnBc.append([Vi1oNCM5kI7yJ0(u"࠹ম"),start+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪ࠳ࠬउ")+FE6Ugdau8WbYP+vGg1hAkzqi8exVbN(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬऊ")+EyfIJ2FB4orR1iXV8h0])
		else:
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠲࠲য"),start+IYC4iPxkTRUE85namF6(u"ࠬ࠵ࠧऋ")+FE6Ugdau8WbYP+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭࠮ࡩࡶࡰࡰࠬऌ")])
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([IYC4iPxkTRUE85namF6(u"࠳࠴র"),start+vhZ5qjay1z94JmcMOgXe(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨऍ")+FE6Ugdau8WbYP+ReLGYUQjz7C9iEd(u"ࠨ࠰࡫ࡸࡲࡲࠧऎ")])
			if end: CPv45ibdnBc.append([eCpDE6wJtYUHn0GqK5(u"࠴࠶঱"),start+vhZ5qjay1z94JmcMOgXe(u"ࠩ࠲ࠫए")+FE6Ugdau8WbYP+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࠳ࠬऐ")+end+UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࠳࡮ࡴ࡮࡮ࠪऑ")])
			if end: CPv45ibdnBc.append([qdEKO42r3GhwmCDcHtxzJUR(u"࠵࠸ল"),start+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠵ࠧऒ")+FE6Ugdau8WbYP+NIBsHMvSXb(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧओ")+end+wFYiVd4r12x7CAQBL5SPof(u"ࠧ࠯ࡪࡷࡱࡱ࠭औ")])
		if YafkZxvGitNEVuKBlWwohIp and end:
			end = end.replace(yNBjYsgc23xoW(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩक"),E3i1eCBtN2w(u"ࠩ࠲ࠫख"))
			CPv45ibdnBc.append([E3i1eCBtN2w(u"࠶࠺঳"),start+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠳ࠬग")+end])
			CPv45ibdnBc.append([jozVWcERh91GOF2NHXQiSwKqe8x(u"࠷࠵঴"),start+yyZPkLCRX1xcBDN(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬघ")+end])
			if ttC4VURALPYKh(u"ࠬ࠴ࡨࡵ࡯࡯ࠫङ") in end:
				EyfIJ2FB4orR1iXV8h0 = end.replace(dn9ouNryjHiBFQOhASvX(u"࠭࠮ࡩࡶࡰࡰࠬच"),Zg9FeADE84jSRIvPCrzYulw3sL)
				CPv45ibdnBc.append([qdEKO42r3GhwmCDcHtxzJUR(u"࠱࠷঵"),start+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧ࠰ࠩछ")+EyfIJ2FB4orR1iXV8h0])
				CPv45ibdnBc.append([Vi1oNCM5kI7yJ0(u"࠲࠹শ"),start+UQS9lVew50DIyXrinWsMxTzA(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩज")+EyfIJ2FB4orR1iXV8h0])
			else:
				CPv45ibdnBc.append([E3i1eCBtN2w(u"࠳࠻ষ"),start+lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠲ࠫझ")+end+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠲࡭ࡺ࡭࡭ࠩञ")])
				CPv45ibdnBc.append([ee3tnwl7avk(u"࠴࠽স"),start+A2MHFvoqpZ64gNbB(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬट")+end+Vi1oNCM5kI7yJ0(u"ࠬ࠴ࡨࡵ࡯࡯ࠫठ")])
		f9ZLzC56UOFywvm2Q70gDRK3uoIYN = []
		for qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81 in CPv45ibdnBc[Mn5NGAdz6xc42s0:]:
			xxvdQOw03tRrG6[bbEU3QqZpXGfs+qS1RW5ZtAkYb] = [None,None,None,None]
			IXU6zAnudWi7FDYweOtvqysaCcE9 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=vv9RFhuai06TJOHnoYBd7wVI1,args=(bbEU3QqZpXGfs+qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81))
			IXU6zAnudWi7FDYweOtvqysaCcE9.start()
			f9ZLzC56UOFywvm2Q70gDRK3uoIYN.append(IXU6zAnudWi7FDYweOtvqysaCcE9)
			LNma2eq3vEguwVtHjn.sleep(YXm2qAbu8Qsx(u"࠴࠳࠽࠵হ"))
		for IXU6zAnudWi7FDYweOtvqysaCcE9 in f9ZLzC56UOFywvm2Q70gDRK3uoIYN: IXU6zAnudWi7FDYweOtvqysaCcE9.join(ReLGYUQjz7C9iEd(u"࠶࠶঺"))
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	EEPAJVu7U2vBMlDS4 = []
	for qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81 in CPv45ibdnBc:
		xxgAEcKoNC5T0kwuV,SPBdzpmsOvKf,EJik7MPjH5apctxF94bVgLqf,nnAkHiSJN7CxWD4QuZL8fYUpgr = xxvdQOw03tRrG6[bbEU3QqZpXGfs+qS1RW5ZtAkYb]
		if not fo6s53yEnbklLpaJOzgR4Q01wxB and EJik7MPjH5apctxF94bVgLqf: nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SPBdzpmsOvKf,EJik7MPjH5apctxF94bVgLqf
		if not VLa3Uijkb0vXeJSWcrPf8KOlz4uA and xxgAEcKoNC5T0kwuV: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = xxgAEcKoNC5T0kwuV
		if nnAkHiSJN7CxWD4QuZL8fYUpgr: EEPAJVu7U2vBMlDS4.append(nnAkHiSJN7CxWD4QuZL8fYUpgr)
	EEPAJVu7U2vBMlDS4 = list(set(EEPAJVu7U2vBMlDS4))
	if not VLa3Uijkb0vXeJSWcrPf8KOlz4uA and len(EEPAJVu7U2vBMlDS4)==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠷঻"):
		OxJ3WCimXvjuMZ6Fk = EEPAJVu7U2vBMlDS4[UwCT5Oz6Wo0BP]
		if OxJ3WCimXvjuMZ6Fk!=YXm2qAbu8Qsx(u"࠲࠱࠲়"):
			if OxJ3WCimXvjuMZ6Fk<UwCT5Oz6Wo0BP: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = vhZ5qjay1z94JmcMOgXe(u"࠭ࡖࡪࡦࡨࡳࠥࡶࡡࡨࡧ࠲ࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࡨࡩࡥࡴࡵ࡬ࡦࡱ࡫ࠧड")
			else:
				VLa3Uijkb0vXeJSWcrPf8KOlz4uA = UixkloZbzGw28ujW56X(u"ࠧࡉࡖࡗࡔࠥࡋࡲࡳࡱࡵ࠾ࠥ࠭ढ")+str(OxJ3WCimXvjuMZ6Fk)
				if GGfPQnrJKEqMv2ZVxdD: import http.client as ss0f1CFxiL
				else: import httplib as ss0f1CFxiL
				try: VLa3Uijkb0vXeJSWcrPf8KOlz4uA += ReLGYUQjz7C9iEd(u"ࠨࠢࠫࠤࠬण")+ss0f1CFxiL.responses[OxJ3WCimXvjuMZ6Fk]+A2MHFvoqpZ64gNbB(u"ࠩࠣ࠭ࠬत")
				except: pass
	LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
class sz7cmkAhjaL8NlMg6EWKdV(HqjWaYEzp0D8eyQRud.WindowDialog):
	def __init__(rX4tN2IJPD0yYa1jw8WlSmCL, *args, **gyrQSCWPzi5D6dTIOZEv9AF8t):
		H4hmknQqlf39Z = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, NIBsHMvSXb(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭थ"), okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨद"), IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡧ࡭࠮ࡱࡰࡪࠫध"))
		KKc5By6rYFDdhMWziPj20eHA1O = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩन"), ee3tnwl7avk(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫऩ"), E3i1eCBtN2w(u"ࠨࡵࡨࡰࡪࡩࡴࡦࡦ࠱ࡴࡳ࡭ࠧप"))
		HFuAgNr6dJ = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬफ"), x9PULjztJOpu7b(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧब"), tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡧࡻࡴࡵࡱࡱࡪࡴ࠴ࡰ࡯ࡩࠪभ"))
		cX96nDARZfCuN2bsWrvqME8 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨम"), IYC4iPxkTRUE85namF6(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪय"), ykE045Tatx(u"ࠧࡣࡷࡷࡸࡴࡴ࡮ࡧ࠰ࡳࡲ࡬࠭र"))
		pqQUDotCaY76eObznwWj4XFS = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫऱ"), Vi1oNCM5kI7yJ0(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭ल"), wFYiVd4r12x7CAQBL5SPof(u"ࠪࡦࡺࡺࡴࡰࡰࡥ࡫࠳ࡶ࡮ࡨࠩळ"))
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = vvglE69OFKBm817Nkc
		rX4tN2IJPD0yYa1jw8WlSmCL.chk = [UwCT5Oz6Wo0BP] * dn9ouNryjHiBFQOhASvX(u"࠺ঽ")
		rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton = [UwCT5Oz6Wo0BP] * YXm2qAbu8Qsx(u"࠻া")
		rX4tN2IJPD0yYa1jw8WlSmCL.chkstate = [vvglE69OFKBm817Nkc] * KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠼ি")
		C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf = qdEKO42r3GhwmCDcHtxzJUR(u"࠶࠺࠶ী"), UwCT5Oz6Wo0BP, Vi1oNCM5kI7yJ0(u"࠼࠶࠰ু"), x9PULjztJOpu7b(u"࠽࠶࠱ূ")
		jtOrUwX4csM7vKyk0CpqN2ITlbD = C8LKAyqbQB9DMWvrxS16VXJktzo+Gd6hSozXglT0Z//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel = ttC4VURALPYKh(u"࠴࠷࠸ৄ"), YXm2qAbu8Qsx(u"࠱࠳࠲ৃ"), vGg1hAkzqi8exVbN(u"࠷࠳࠴৅"), vGg1hAkzqi8exVbN(u"࠷࠳࠴৅")
		UdoKWkiCRy5F0TaXDqpGfVurSZOE2 = DxdsFza9bqrlZLIOpNgCS3oy+HGkU4hJrTpf8ND7Z2Ycsvy//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		ImHC54ei6l3bsSxTVor, Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK, Js829nHb6FWucwOP0m, UPwfKWh54kZNvoB = x9PULjztJOpu7b(u"࠵࠵࠶ে"), IYC4iPxkTRUE85namF6(u"࠻࠻࠵ৈ"), YXm2qAbu8Qsx(u"࠴࠹࠵৆"), jozVWcERh91GOF2NHXQiSwKqe8x(u"࠻࠰৉")
		WLr0TljBFDvXyIaVcR = jtOrUwX4csM7vKyk0CpqN2ITlbD-Js829nHb6FWucwOP0m-ImHC54ei6l3bsSxTVor//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		yYv4JScLOkw3Xah876nlRobHpjQ = jtOrUwX4csM7vKyk0CpqN2ITlbD+ImHC54ei6l3bsSxTVor//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv = E3i1eCBtN2w(u"࠳࠶࠷৊"), vv3sNE8XCU2RAiyVaueTbD950pz(u"࠴࠲ো"), ZYTyoA483N(u"࠸࠴࠵্"), E3i1eCBtN2w(u"࠷࠳ৌ")
		pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby = vGg1hAkzqi8exVbN(u"࠷࠺࠻ৎ"), A2MHFvoqpZ64gNbB(u"࠷࠱৑"), IYC4iPxkTRUE85namF6(u"࠻࠰࠱৐"), zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠺࠶৏")
		EEe7lM4CPfypz9G1JHXRgaY = DKmLTA2yGtj(u"࠱࠰࠼৒")
		C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf = int(C8LKAyqbQB9DMWvrxS16VXJktzo*EEe7lM4CPfypz9G1JHXRgaY), int(QBhnMgDdPiFacI3p*EEe7lM4CPfypz9G1JHXRgaY), int(Gd6hSozXglT0Z*EEe7lM4CPfypz9G1JHXRgaY), int(NawPUTA7lQYLx3FWunf*EEe7lM4CPfypz9G1JHXRgaY)
		DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel = int(DxdsFza9bqrlZLIOpNgCS3oy*EEe7lM4CPfypz9G1JHXRgaY), int(NVsFQHu4bEhy7xjYUvZeG39Rrp0J*EEe7lM4CPfypz9G1JHXRgaY), int(HGkU4hJrTpf8ND7Z2Ycsvy*EEe7lM4CPfypz9G1JHXRgaY), int(OOzuYXkwIMN5Lo2fKh4dZSianbel*EEe7lM4CPfypz9G1JHXRgaY)
		WLr0TljBFDvXyIaVcR, EEVFjaqIOGygobDXZ, lB1q2At0zbVdX8GcQPOse, V6ZYaEHwkT8hWjev = int(WLr0TljBFDvXyIaVcR*EEe7lM4CPfypz9G1JHXRgaY), int(Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK*EEe7lM4CPfypz9G1JHXRgaY), int(Js829nHb6FWucwOP0m*EEe7lM4CPfypz9G1JHXRgaY), int(UPwfKWh54kZNvoB*EEe7lM4CPfypz9G1JHXRgaY)
		yYv4JScLOkw3Xah876nlRobHpjQ, GUWC1Opf9sq3Mv0e8nugALxXb, PP37ZuzYgkwUrnbTMx5, ssX9lvENKiSm7QRodPUM = int(yYv4JScLOkw3Xah876nlRobHpjQ*EEe7lM4CPfypz9G1JHXRgaY), int(Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK*EEe7lM4CPfypz9G1JHXRgaY), int(Js829nHb6FWucwOP0m*EEe7lM4CPfypz9G1JHXRgaY), int(UPwfKWh54kZNvoB*EEe7lM4CPfypz9G1JHXRgaY)
		TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv = int(TumopOkWSlB3tIvZnVXMsdK*EEe7lM4CPfypz9G1JHXRgaY), int(xAzbmYgDyvjpW*EEe7lM4CPfypz9G1JHXRgaY), int(KCta3OfYpS1F*EEe7lM4CPfypz9G1JHXRgaY), int(H4WmA0OMqCQyijuxv*EEe7lM4CPfypz9G1JHXRgaY)
		pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby = int(pgcW1Y0udyzTDSC*EEe7lM4CPfypz9G1JHXRgaY), int(BAi2OW7pchDx1t*EEe7lM4CPfypz9G1JHXRgaY), int(bjc08326tGUSiA4RXC*EEe7lM4CPfypz9G1JHXRgaY), int(Sau0gLfeWxqp9cCAmby*EEe7lM4CPfypz9G1JHXRgaY)
		xxB32TXgSfC7y = HqjWaYEzp0D8eyQRud.ControlImage(C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf, H4hmknQqlf39Z)
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(xxB32TXgSfC7y)
		rX4tN2IJPD0yYa1jw8WlSmCL.iteration = gyrQSCWPzi5D6dTIOZEv9AF8t.get(A2MHFvoqpZ64gNbB(u"ࠫ࡮ࡺࡥࡳࡣࡷ࡭ࡴࡴࠧऴ"))
		VVHQWDNc9BUpOT38o2i0x = U2bWzwG8VdJsBqtR74ErDi3cg1v+wFYiVd4r12x7CAQBL5SPof(u"ࠬ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ๎ไิฬࠣีํฮ่หࠢࠣࠤࠥࠦࠠࠡࠢࠣࠫव")+JP65RzKaScIf(u"࠭วๅ็ะหํ๊ษࠡำๅ้ࠥࠦࠧश")+str(rX4tN2IJPD0yYa1jw8WlSmCL.iteration)+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo = HqjWaYEzp0D8eyQRud.ControlLabel(TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv, VVHQWDNc9BUpOT38o2i0x, tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧष"))
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo)
		W8KBRzkdhlCxvF5sY2T = HqjWaYEzp0D8eyQRud.ControlImage(DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel, gyrQSCWPzi5D6dTIOZEv9AF8t.get(dn9ouNryjHiBFQOhASvX(u"ࠨࡥࡤࡴࡹࡩࡨࡢࠩस")))
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(W8KBRzkdhlCxvF5sY2T)
		JK5lBaj9fR1ztCnoIUXG8xQ2Ow = U2bWzwG8VdJsBqtR74ErDi3cg1v+gyrQSCWPzi5D6dTIOZEv9AF8t.get(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡰࡷ࡬࠭ह"))+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo = HqjWaYEzp0D8eyQRud.ControlLabel(pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby, JK5lBaj9fR1ztCnoIUXG8xQ2Ow, IYC4iPxkTRUE85namF6(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪऺ"))
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo)
		text = U2bWzwG8VdJsBqtR74ErDi3cg1v+YXm2qAbu8Qsx(u"ࠫำื่อࠩऻ")+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton = HqjWaYEzp0D8eyQRud.ControlButton(WLr0TljBFDvXyIaVcR, EEVFjaqIOGygobDXZ, lB1q2At0zbVdX8GcQPOse, V6ZYaEHwkT8hWjev, text, focusTexture=pqQUDotCaY76eObznwWj4XFS, noFocusTexture=HFuAgNr6dJ, alignment=tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠴৓"))
		text = U2bWzwG8VdJsBqtR74ErDi3cg1v+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬอำห็ิหึ़࠭")+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton = HqjWaYEzp0D8eyQRud.ControlButton(yYv4JScLOkw3Xah876nlRobHpjQ, GUWC1Opf9sq3Mv0e8nugALxXb, PP37ZuzYgkwUrnbTMx5, ssX9lvENKiSm7QRodPUM, text, focusTexture=pqQUDotCaY76eObznwWj4XFS, noFocusTexture=HFuAgNr6dJ, alignment=DKmLTA2yGtj(u"࠵৔"))
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		m0ENcaf43WGqz6P, ZZp9X1nkucf5ljChPxsIb = OOzuYXkwIMN5Lo2fKh4dZSianbel//O4dklMvZ8ULcS, HGkU4hJrTpf8ND7Z2Ycsvy//O4dklMvZ8ULcS
		for YjZN3ADmertFahUQIECW in range(wFYiVd4r12x7CAQBL5SPof(u"࠽৕")):
			sunLqYwZXvKVbh5ANzCo = YjZN3ADmertFahUQIECW // O4dklMvZ8ULcS
			P08KTbhMB9qmwoND3IzFfUxX = YjZN3ADmertFahUQIECW % O4dklMvZ8ULcS
			zcpgViqlHuQkPSsWGY74xdjOAf3BF = DxdsFza9bqrlZLIOpNgCS3oy + (ZZp9X1nkucf5ljChPxsIb * P08KTbhMB9qmwoND3IzFfUxX)
			bK2FwMazi8kpgn3rls79mSoJQVeR = NVsFQHu4bEhy7xjYUvZeG39Rrp0J + (m0ENcaf43WGqz6P * sunLqYwZXvKVbh5ANzCo)
			rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW] = HqjWaYEzp0D8eyQRud.ControlImage(zcpgViqlHuQkPSsWGY74xdjOAf3BF, bK2FwMazi8kpgn3rls79mSoJQVeR, ZZp9X1nkucf5ljChPxsIb, m0ENcaf43WGqz6P, KKc5By6rYFDdhMWziPj20eHA1O)
			rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW])
			rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW].setVisible(vvglE69OFKBm817Nkc)
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW] = HqjWaYEzp0D8eyQRud.ControlButton(zcpgViqlHuQkPSsWGY74xdjOAf3BF, bK2FwMazi8kpgn3rls79mSoJQVeR, ZZp9X1nkucf5ljChPxsIb, m0ENcaf43WGqz6P, str(YjZN3ADmertFahUQIECW + Mn5NGAdz6xc42s0), font=ReLGYUQjz7C9iEd(u"࠭ࡦࡰࡰࡷ࠵࠸࠭ऽ"), focusTexture=HFuAgNr6dJ, noFocusTexture=cX96nDARZfCuN2bsWrvqME8)
			rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW])
		for YjZN3ADmertFahUQIECW in range(eCpDE6wJtYUHn0GqK5(u"࠾৖")):
			MLVJYNgw6Bs = (YjZN3ADmertFahUQIECW // O4dklMvZ8ULcS) * O4dklMvZ8ULcS
			NlEwy1coZ8iPAVMze745rmSGnF = MLVJYNgw6Bs + (YjZN3ADmertFahUQIECW + Mn5NGAdz6xc42s0) % O4dklMvZ8ULcS
			Q3MHvd4hr7 = MLVJYNgw6Bs + (YjZN3ADmertFahUQIECW - Mn5NGAdz6xc42s0) % O4dklMvZ8ULcS
			BCM7bhIvsfTJ3anQXFYge5zOt6wl = (YjZN3ADmertFahUQIECW - O4dklMvZ8ULcS) % Vi1oNCM5kI7yJ0(u"࠿ৗ")
			LflpkH4xgSZToKcuzIyMJ69Y1DhB = (YjZN3ADmertFahUQIECW + O4dklMvZ8ULcS) % lU1fSmncFWjizwqZugyYBANML0(u"࠹৘")
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[NlEwy1coZ8iPAVMze745rmSGnF])
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[Q3MHvd4hr7])
			if YjZN3ADmertFahUQIECW <= DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
			else:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[BCM7bhIvsfTJ3anQXFYge5zOt6wl])
			if YjZN3ADmertFahUQIECW >= ttC4VURALPYKh(u"࠷৙"):
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
			else:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[LflpkH4xgSZToKcuzIyMJ69Y1DhB])
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr])
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[wFYiVd4r12x7CAQBL5SPof(u"࠺৚")])
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[UwCT5Oz6Wo0BP])
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[wFYiVd4r12x7CAQBL5SPof(u"࠹৛")])
		rX4tN2IJPD0yYa1jw8WlSmCL.setFocus(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
	def get(rX4tN2IJPD0yYa1jw8WlSmCL):
		rX4tN2IJPD0yYa1jw8WlSmCL.doModal()
		rX4tN2IJPD0yYa1jw8WlSmCL.close()
		if not rX4tN2IJPD0yYa1jw8WlSmCL.cancelled:
			return [YjZN3ADmertFahUQIECW for YjZN3ADmertFahUQIECW in range(wFYiVd4r12x7CAQBL5SPof(u"࠽ড়")) if rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[YjZN3ADmertFahUQIECW]]
	def onControl(rX4tN2IJPD0yYa1jw8WlSmCL, M6BhQE5fSnOUZk7NPA2Dm83cuWL1):
		if M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getId() == rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.getId() and any(rX4tN2IJPD0yYa1jw8WlSmCL.chkstate):
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
		elif M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getId() == rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.getId():
			rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
		else:
			cwMyvBgJuRXLWH48kpndbG7q2a = M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getLabel()
			if cwMyvBgJuRXLWH48kpndbG7q2a.isnumeric():
				index = int(cwMyvBgJuRXLWH48kpndbG7q2a) - Mn5NGAdz6xc42s0
				rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index] = not rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index]
				rX4tN2IJPD0yYa1jw8WlSmCL.chk[index].setVisible(rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index])
	def onAction(rX4tN2IJPD0yYa1jw8WlSmCL, zMsqA2SVtdHLJDx8gpFGw):
		if zMsqA2SVtdHLJDx8gpFGw == ee3tnwl7avk(u"࠶࠶ঢ়"):
			rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
def e4XT9Vp5sNIP8M0lyFd7orGUhJ2Ou(key,Zxh5l1rNem,url):
	headers = {vhZ5qjay1z94JmcMOgXe(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨा"):url,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪि"):Zxh5l1rNem}
	J2zpHd3wU9s = A2MHFvoqpZ64gNbB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠵ࡡࡱ࡫࠲ࡪࡦࡲ࡬ࡣࡣࡦ࡯ࡄࡱ࠽ࠨी")+key
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡋࡊ࡚ࠧु"),J2zpHd3wU9s,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠲ࡵࡷࠫू"))
	dkKX8zLCs6yqBlD7Y5geZEpAicua20,iteration = Zg9FeADE84jSRIvPCrzYulw3sL,UwCT5Oz6Wo0BP
	while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		EEFf6enQDxk = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠬࠨࠨ࠰ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠳ࡦࡶࡩ࠳࠱ࡳࡥࡾࡲ࡯ࡢࡦ࡞ࡢࠧࡣࠫࠪࠩृ"), yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		iteration += Mn5NGAdz6xc42s0
		message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UixkloZbzGw28ujW56X(u"࠭࠼࡭ࡣࡥࡩࡱࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡴࡦࡺࡷࠦࡠࡤ࠾࡞ࠬࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰࡦࡨࡥ࡭ࡀࠪॄ"), yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		if not message: message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠽ࡦ࡬ࡺࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲࡫ࡲࡳࡱࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪॅ"), yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		if not message:
			dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(JP65RzKaScIf(u"ࠨࡴࡨࡥࡩࡵ࡮࡭ࡻࡁࠬ࠳࠰࠿ࠪ࠾ࠪॆ"), yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)[UwCT5Oz6Wo0BP]
			break
		else:
			message = message[UwCT5Oz6Wo0BP]
			EEFf6enQDxk = EEFf6enQDxk[UwCT5Oz6Wo0BP]
		iAUKN2hp8XojexOZVGu4fa0TLS = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࡴࠪࡲࡦࡳࡥ࠾ࠤࡦࠦࡡࡹࠫࡷࡣ࡯ࡹࡪࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠨे"), yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)[UwCT5Oz6Wo0BP]
		ssmj6TJAIYlo8n = vhZ5qjay1z94JmcMOgXe(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱࠪࡹࠧै") % (EEFf6enQDxk.replace(DKmLTA2yGtj(u"ࠫࠫࡧ࡭ࡱ࠽ࠪॉ"), eCpDE6wJtYUHn0GqK5(u"ࠬࠬࠧॊ")))
		message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭࠼࠰ࡁࠫࡨ࡮ࡼࡼࡴࡶࡵࡳࡳ࡭ࠩ࡜ࡠࡁࡡ࠯ࡄࠧो"), Zg9FeADE84jSRIvPCrzYulw3sL, message)
		A1UqLd35XVtkHu7 = sz7cmkAhjaL8NlMg6EWKdV(captcha=ssmj6TJAIYlo8n, msg=message, iteration=iteration)
		EcOPrVSsGvT = A1UqLd35XVtkHu7.get()
		if not EcOPrVSsGvT: break
		data = {dn9ouNryjHiBFQOhASvX(u"ࠧࡤࠩौ"): iAUKN2hp8XojexOZVGu4fa0TLS, DKmLTA2yGtj(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧ्ࠪ"): EcOPrVSsGvT}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,E3i1eCBtN2w(u"ࠩࡓࡓࡘ࡚ࠧॎ"),J2zpHd3wU9s,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠲࡯ࡦࠪॏ"))
	return dkKX8zLCs6yqBlD7Y5geZEpAicua20
def ETZDzC3rpIfuhALVRkSUlxXW21QNoH(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡑࡕࡁࡅࡕ࠰࠵ࡸࡺࠧॐ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vGg1hAkzqi8exVbN(u"ࠬࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ॑"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖ॒ࠫ"),[],[]
def ptDGgdlni7a5fVoxEjKYON6XC(url):
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def B17B4reZUshzTbcxEG8RCAop(url):
	m0t48jnKhrQFJViguoMl9NBPp = url.split(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧ࠰ࠩ॓"))
	yy1Zn4ovHpRqmKzjIfa = vhZ5qjay1z94JmcMOgXe(u"ࠨ࠱ࠪ॔").join(m0t48jnKhrQFJViguoMl9NBPp[UwCT5Oz6Wo0BP:O4dklMvZ8ULcS])
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭ॕ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ReLGYUQjz7C9iEd(u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬॖ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,Bmxi32K6Taz90GXCreMD48wb,EsVf1Kpd2UQojJ3nG8B5IAxL9vSq,hlbwqNiv4xUA2EWOHZ5ejY,E5OVouZa6tIKv4fSzWnY3bBQMj = items[UwCT5Oz6Wo0BP]
		MnwlGZ9Ef3S7kv5sxtzRiFaoCIb = int(YswlgoudyzkW8hARTP09tDG16a) % int(Bmxi32K6Taz90GXCreMD48wb) + int(EsVf1Kpd2UQojJ3nG8B5IAxL9vSq) % int(hlbwqNiv4xUA2EWOHZ5ejY)
		url = yy1Zn4ovHpRqmKzjIfa + uNy4ZJUMEiTj5aS0Rxf619YPzrk + str(MnwlGZ9Ef3S7kv5sxtzRiFaoCIb) + E5OVouZa6tIKv4fSzWnY3bBQMj
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else: return dn9ouNryjHiBFQOhASvX(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࡚ࠦࡊࡒࡓ࡝ࡘࡎࡁࡓࡇࠪॗ"),[],[]
def qL7uoRwbpI2QFjHP51S(url):
	id = url.split(yyZPkLCRX1xcBDN(u"ࠬ࠵ࠧक़"))[-Mn5NGAdz6xc42s0]
	headers = { UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬख़") : vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ग़") }
	EEFf6enQDxk = { x9PULjztJOpu7b(u"ࠣ࡫ࡧࠦज़"):id , E3i1eCBtN2w(u"ࠤࡲࡴࠧड़"):NIBsHMvSXb(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷ࠨढ़") }
	YYAz8aPFGR2n = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,ReLGYUQjz7C9iEd(u"ࠫࡕࡕࡓࡕࠩफ़"), url, EEFf6enQDxk, headers, Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡓ࠸࡚ࡖࡌࡐࡃࡇ࠱࠶ࡹࡴࠨय़"))
	if yyZPkLCRX1xcBDN(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨॠ") in list(YYAz8aPFGR2n.headers.keys()): yDTPzhEBKVJl7CX81 = YYAz8aPFGR2n.headers[yyZPkLCRX1xcBDN(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩॡ")]
	else: yDTPzhEBKVJl7CX81 = url
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return Vi1oNCM5kI7yJ0(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭ॢ"),[],[]
def NF9nrM2hfP3WIw(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬॣ"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"ࠪࡱࡵ࠺࠺ࠡ࡞࡞ࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭।"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return vGg1hAkzqi8exVbN(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡊࡐࡗ࡚ࡑࡏࡖࡆࠩ॥"),[],[]
def rxR7qJpG2lFV6i(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭०"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ१"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		url = url = IYC4iPxkTRUE85namF6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭२") + items[UwCT5Oz6Wo0BP]
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ url ]
	else: return UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ३"),[],[]
def ryWH7UVAMO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ४"))
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ५"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return JP65RzKaScIf(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡔࡖࡕࡉࡆࡓࠧ६"),[],[]
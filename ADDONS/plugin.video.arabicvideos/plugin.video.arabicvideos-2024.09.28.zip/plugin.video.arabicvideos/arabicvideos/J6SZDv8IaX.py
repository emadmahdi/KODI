# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'SHIAVOICE'
j0jSEdTPJuG4XNvfpO = '_SHV_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
headers = {'User-Agent':None}
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==310: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==311: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	elif mode==312: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==313: CsaNhTtGm8 = WNZHFMtATQvx7g(url)
	elif mode==314: CsaNhTtGm8 = xxSIompNHlMPkB63nRVLsTaJAbrZKg(text)
	elif mode==319: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,319,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="menulinks"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h5>(.*?)</h5>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	for pfQhOaqwdBS2k8ZiRA5MeXYUK in range(len(items)):
		title = items[pfQhOaqwdBS2k8ZiRA5MeXYUK].strip(wjs26GpVfNiCUERHJ)
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,qfzHe2Yr49,314,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,str(pfQhOaqwdBS2k8ZiRA5MeXYUK+1))
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'مقاطع شهر',qfzHe2Yr49,314,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'0')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<B>(.*?)</B>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,311)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def xxSIompNHlMPkB63nRVLsTaJAbrZKg(pfQhOaqwdBS2k8ZiRA5MeXYUK):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-LATEST-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if pfQhOaqwdBS2k8ZiRA5MeXYUK=='0':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="tab-content"(.*?)</table>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,name,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title.strip(wjs26GpVfNiCUERHJ)
			name = name.strip(wjs26GpVfNiCUERHJ)
			title = title+' ('+name+')'
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312)
	elif pfQhOaqwdBS2k8ZiRA5MeXYUK in ['1','2','3']:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(<h5>.*?)<div class="col-lg',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		mLiP65TR2A0fwe = int(pfQhOaqwdBS2k8ZiRA5MeXYUK)-1
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[mLiP65TR2A0fwe]
		if pfQhOaqwdBS2k8ZiRA5MeXYUK=='1': items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		else: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title,name in items:
			W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title.strip(wjs26GpVfNiCUERHJ)
			name = name.strip(wjs26GpVfNiCUERHJ)
			title = title+' ('+name+')'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,311,W8KBRzkdhlCxvF5sY2T)
	elif pfQhOaqwdBS2k8ZiRA5MeXYUK in ['4','5','6']:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(<h5>.*?)</table>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		pfQhOaqwdBS2k8ZiRA5MeXYUK = int(pfQhOaqwdBS2k8ZiRA5MeXYUK)-4
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[pfQhOaqwdBS2k8ZiRA5MeXYUK]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,VgGC5zyJMN6lEtIu8D7b,title,W4KwrJtUfaNF2Q3Coqsl869V1dbm in items:
			W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title.strip(wjs26GpVfNiCUERHJ)
			VgGC5zyJMN6lEtIu8D7b = VgGC5zyJMN6lEtIu8D7b.strip(wjs26GpVfNiCUERHJ)
			W4KwrJtUfaNF2Q3Coqsl869V1dbm = W4KwrJtUfaNF2Q3Coqsl869V1dbm.strip(wjs26GpVfNiCUERHJ)
			if VgGC5zyJMN6lEtIu8D7b: name = VgGC5zyJMN6lEtIu8D7b
			else: name = W4KwrJtUfaNF2Q3Coqsl869V1dbm
			title = title+' ('+name+')'
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312,W8KBRzkdhlCxvF5sY2T)
	return
def mbzIyKNqMVt0FQeOsPWc(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ibox-heading"(.*?)class="float-right',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if 'catsum-mobile' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title,count in items:
				W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
				count = count.replace(' الصوتية: ',':')
				title = title.strip(wjs26GpVfNiCUERHJ)
				title = title+' ('+count+')'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,311,W8KBRzkdhlCxvF5sY2T)
	else:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title,iiynATvNzWmFsHkZIu6rbaw0f1XP,NAdtOanYBmF0IWbMvXxz7lERiTjo in items:
			if title==Zg9FeADE84jSRIvPCrzYulw3sL or iiynATvNzWmFsHkZIu6rbaw0f1XP==Zg9FeADE84jSRIvPCrzYulw3sL: continue
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title+' ('+NAdtOanYBmF0IWbMvXxz7lERiTjo+')'
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312)
	if not items: dHjny9tTucrO(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	return
def dHjny9tTucrO(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG):
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="ibox-content"(.*?)class="pagination',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title,name,count,NAdtOanYBmF0IWbMvXxz7lERiTjo in items:
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
		title = title.strip(wjs26GpVfNiCUERHJ)
		name = name.strip(wjs26GpVfNiCUERHJ)
		title = title+' ('+name+')'
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312,Zg9FeADE84jSRIvPCrzYulw3sL,NAdtOanYBmF0IWbMvXxz7lERiTjo)
	return
def WNZHFMtATQvx7g(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-SEARCH_ITEMS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="ibox-content p-1"(.*?)class="ibox-content"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f:
		mbzIyKNqMVt0FQeOsPWc(url)
		return
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<strong>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
		title = title.strip(wjs26GpVfNiCUERHJ)
		if '/play-' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,311)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<audio.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<video.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81[0]
	nTdpZOCUe7l(yDTPzhEBKVJl7CX81,bIPsOxjEpoH,'video')
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	wjmg5G2MfvQ0VI68ZhpL = ['&t=a','&t=c','&t=s']
	if showDialogs:
		mBbFYkWfJXjMlQUinD8A57HCgVazy = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('موقع صوت الشيعة - أختر البحث', mBbFYkWfJXjMlQUinD8A57HCgVazy)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1: return
	elif '_SHIAVOICE-PERSONS_' in NNYRDot8vC: lqQvOUWodZnhXLS2Vcuj6EtairFN = 0
	elif '_SHIAVOICE-ALBUMS_' in NNYRDot8vC: lqQvOUWodZnhXLS2Vcuj6EtairFN = 1
	elif '_SHIAVOICE-AUDIOS_' in NNYRDot8vC: lqQvOUWodZnhXLS2Vcuj6EtairFN = 2
	else: return
	type = wjmg5G2MfvQ0VI68ZhpL[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	url = qfzHe2Yr49+'/search.php?q='+search+type
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHIAVOICE-SEARCH-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="ibox-content"(.*?)class="ibox-content"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		if lqQvOUWodZnhXLS2Vcuj6EtairFN in [0,1]:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title,name in items:
				title = title.strip(wjs26GpVfNiCUERHJ)
				name = name.strip(wjs26GpVfNiCUERHJ)
				title = title+' ('+name+')'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,313,W8KBRzkdhlCxvF5sY2T)
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==2:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title,name in items:
				title = title.strip(wjs26GpVfNiCUERHJ)
				name = name.strip(wjs26GpVfNiCUERHJ)
				title = title+' ('+name+')'
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,312)
	return
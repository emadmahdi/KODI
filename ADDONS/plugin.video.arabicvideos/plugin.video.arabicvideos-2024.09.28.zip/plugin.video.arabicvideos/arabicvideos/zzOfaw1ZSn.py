# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'ARABICTOONS'
j0jSEdTPJuG4XNvfpO = '_ART_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==730: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==731: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	elif mode==732: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==733: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==734: CsaNhTtGm8 = JCQebnMKzoIRi0skT52(url)
	elif mode==735: CsaNhTtGm8 = AntsyMqeBwF(url)
	elif mode==739: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,739,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'مسلسلات مميزة',qfzHe2Yr49+'/top.php',735)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'مسلسلات',qfzHe2Yr49+'/cartoon.php',734)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'افلام',qfzHe2Yr49+'/movies.php',731)
	return
def JCQebnMKzoIRi0skT52(url):
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الكل',url,731)
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-SERIES_SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('label="navigation"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href='(.*?)'>(.*?)</a>",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = 'حرف '+title
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,731)
	return
def AntsyMqeBwF(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-SERIES_FEATURED-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="slider"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
			title = title.strip(wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,733,W8KBRzkdhlCxvF5sY2T)
	return
def mbzIyKNqMVt0FQeOsPWc(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("class='moviesBlocks(.*?)navigation",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
		W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
		title = title.strip(wjs26GpVfNiCUERHJ)
		if 'movies.php' in url: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,732,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,733,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[-1]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title.strip(wjs26GpVfNiCUERHJ)
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,731)
	return
def dHjny9tTucrO(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("class='moviesBlocks(.*?)script",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for title,yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,kT6I0rNCb9EjLz in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			W8KBRzkdhlCxvF5sY2T = qfzHe2Yr49+'/'+W8KBRzkdhlCxvF5sY2T
			title = title.strip(wjs26GpVfNiCUERHJ)
			title = title+wjs26GpVfNiCUERHJ+kT6I0rNCb9EjLz.strip(wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,732,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0 = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if CPv45ibdnBc:
		yDTPzhEBKVJl7CX81 = CPv45ibdnBc[0]
		if 'Referer=' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'|Referer=https://www.arabic-toons.com'
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named=__embed')
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'%20')
	fo6s53yEnbklLpaJOzgR4Q01wxB = [Zg9FeADE84jSRIvPCrzYulw3sL,'m']
	Z2fh9I3eLMO = ['مسلسلات','افلام']
	if showDialogs:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر النوع المطلوب:', Z2fh9I3eLMO)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-1: return
	else: lqQvOUWodZnhXLS2Vcuj6EtairFN = 0
	type = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	url = qfzHe2Yr49+'/livesearch.php?'+type+'&q='+search
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ARABICTOONS-SEARCH-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
		title = title.strip(wjs26GpVfNiCUERHJ)
		if type=='m': A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,732)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,733)
	return
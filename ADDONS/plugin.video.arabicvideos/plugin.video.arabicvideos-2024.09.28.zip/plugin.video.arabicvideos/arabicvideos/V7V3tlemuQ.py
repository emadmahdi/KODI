# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'RANDOMS'
j0jSEdTPJuG4XNvfpO = '_LST_'
mq7rgp6FRO = 4
Alxof8pdM03umF = 10
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,url,Tbwq7kJ4vRSNVyUFcdMzirG,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia):
	try: fpegTIEPJKtW = str(QsWU0ew5xMjBozVtqHAGDTNyL4Ia['folder'])
	except: fpegTIEPJKtW = Zg9FeADE84jSRIvPCrzYulw3sL
	if   LfnWDFgRdJH4lZvt7yo28N==160: CsaNhTtGm8 = bELNFKS6fCB()
	elif LfnWDFgRdJH4lZvt7yo28N==161: CsaNhTtGm8 = ssFCMcQlIdmxzw(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==162: CsaNhTtGm8 = VK9dy20XhC1e368uiROGgzsQ(Tbwq7kJ4vRSNVyUFcdMzirG,162)
	elif LfnWDFgRdJH4lZvt7yo28N==163: CsaNhTtGm8 = VK9dy20XhC1e368uiROGgzsQ(Tbwq7kJ4vRSNVyUFcdMzirG,163)
	elif LfnWDFgRdJH4lZvt7yo28N==164: CsaNhTtGm8 = OVTFsgclRG4DKdAWCS(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==165: CsaNhTtGm8 = H1pCLql39Yu87Q(url,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==166: CsaNhTtGm8 = DDnkS9vmzO7G5hCLY3AebJixplgM4(url,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==167: CsaNhTtGm8 = RRhUq7cOMmu65kaIzDpPbov(url,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==168: CsaNhTtGm8 = iU1jhMzVbxItsyAlCL8nrvDd(url,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==761: CsaNhTtGm8 = xXakgLKlyDdEQ4qR065tCuNzpce()
	elif LfnWDFgRdJH4lZvt7yo28N==762: CsaNhTtGm8 = u7pEU03hkF58HICAY2scVl4vNTt()
	elif LfnWDFgRdJH4lZvt7yo28N==763: CsaNhTtGm8 = IV0J26giKvahkmXwdQTo1cSC3DpWFZ(fpegTIEPJKtW,Tbwq7kJ4vRSNVyUFcdMzirG,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif LfnWDFgRdJH4lZvt7yo28N==764: CsaNhTtGm8 = on1w97DfhO0uycbmBsgd(fpegTIEPJKtW,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==765: CsaNhTtGm8 = qq1AV3GDJjZoBEOmWSFX0fC9z(fpegTIEPJKtW,Tbwq7kJ4vRSNVyUFcdMzirG)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder','قنوات تلفزيون عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,161,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_LIVETV__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','قسم عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,162,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_SITES__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,163,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_SITES__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات بحث عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,164,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_SITES__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات عشوائية من قسم',Zg9FeADE84jSRIvPCrzYulw3sL,763,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_SITES__RANDOM_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','قنوات M3U عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,163,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات M3U عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,163,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','قسم قنوات M3U عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,162,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__LIVE__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','قسم فيديو M3U عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,162,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__VOD__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات M3U بحث عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,164,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات M3U عشوائية من قسم',Zg9FeADE84jSRIvPCrzYulw3sL,765,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_M3U__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','قنوات IPTV عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,163,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات IPTV عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,163,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','قسم قنوات IPTV عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,162,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__LIVE__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','قسم فيديو IPTV عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,162,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__VOD__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات IPTV بحث عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,164,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__RANDOM__REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder','فيديوهات IPTV عشوائية من قسم',Zg9FeADE84jSRIvPCrzYulw3sL,764,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def xXakgLKlyDdEQ4qR065tCuNzpce():
	A9Z3Ci2PQhFUwBXvI('folder','_IPT_'+'فيديوهات جميع IPTV',Zg9FeADE84jSRIvPCrzYulw3sL,764)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
		j0jSEdTPJuG4XNvfpO = '_IP'+str(fpegTIEPJKtW)+'_'
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' فيديوهات مجلد '+YOjp8EZx4D[fpegTIEPJKtW],Zg9FeADE84jSRIvPCrzYulw3sL,764,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
	return
def u7pEU03hkF58HICAY2scVl4vNTt():
	A9Z3Ci2PQhFUwBXvI('folder','_M3U_'+'فيديوهات جميع M3U',Zg9FeADE84jSRIvPCrzYulw3sL,765)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
		j0jSEdTPJuG4XNvfpO = '_MU'+str(fpegTIEPJKtW)+'_'
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' فيديوهات مجلد '+YOjp8EZx4D[fpegTIEPJKtW],Zg9FeADE84jSRIvPCrzYulw3sL,765,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
	return
def gJdXsizrTLP8eb75uO9RV13(FLqQoZwdAngNkz49RMGUHJXW3bDC):
	global ZCdQPNmGRaVbIjwoOgyYk,JHRQvZL9Sif
	AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
	try:
		if 'IFILM' in FLqQoZwdAngNkz49RMGUHJXW3bDC: AxIs6lqNDCuzmEwoKg475J(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		else: AxIs6lqNDCuzmEwoKg475J()
		CLp1WnihXcBYmZz = False
	except:
		TS2jM0Dl7syHeh3o8tPvxN5i9Lb()
		CLp1WnihXcBYmZz = True
	FLqQoZwdAngNkz49RMGUHJXW3bDC = ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC)
	if CLp1WnihXcBYmZz:
		ZXWeI01flR(FLqQoZwdAngNkz49RMGUHJXW3bDC,'فشل للأسف',LNma2eq3vEguwVtHjn=2000)
		ZCdQPNmGRaVbIjwoOgyYk += 1
		JHRQvZL9Sif += wjs26GpVfNiCUERHJ+FLqQoZwdAngNkz49RMGUHJXW3bDC
	else: ZXWeI01flR(FLqQoZwdAngNkz49RMGUHJXW3bDC,Zg9FeADE84jSRIvPCrzYulw3sL,LNma2eq3vEguwVtHjn=1000)
	return
def PY7y3Iwatle2mJFWROkGzVAbqMUTEh(XP4mNYMQRy01rZFx8kf=True):
	global ZCdQPNmGRaVbIjwoOgyYk,JHRQvZL9Sif
	if not XP4mNYMQRy01rZFx8kf:
		global Als2YrFfpG6
		CsaNhTtGm8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if CsaNhTtGm8:
			Als2YrFfpG6 = CsaNhTtGm8
			return
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW('center',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if jzydmKVUWrCv9D34F!=1: return
	Tk5CeWKZwqrnxjO40(False,False,False)
	TbmRoqHaYjv = AhBFVbK7LzNinwrg65JjpRP
	ZCdQPNmGRaVbIjwoOgyYk,JHRQvZL9Sif,threads = 0,Zg9FeADE84jSRIvPCrzYulw3sL,{}
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in h97Pjsutv1rcV4zekJX:
		LNma2eq3vEguwVtHjn.sleep(0.75)
		threads[FLqQoZwdAngNkz49RMGUHJXW3bDC] = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=gJdXsizrTLP8eb75uO9RV13,args=(FLqQoZwdAngNkz49RMGUHJXW3bDC,))
		threads[FLqQoZwdAngNkz49RMGUHJXW3bDC].start()
		if ZCdQPNmGRaVbIjwoOgyYk>=Alxof8pdM03umF: break
	else:
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in list(threads.keys()): threads[FLqQoZwdAngNkz49RMGUHJXW3bDC].join()
	AhBFVbK7LzNinwrg65JjpRP[:] = TbmRoqHaYjv
	if ZCdQPNmGRaVbIjwoOgyYk>=Alxof8pdM03umF: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','لديك مشكلة في '+str(ZCdQPNmGRaVbIjwoOgyYk)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+JHRQvZL9Sif)
	else:
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_SITES','SECTIONS_SITES_ALL',Als2YrFfpG6,B4GWT7zonF5yipbIwJmNUf6Vavg)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	Tk5CeWKZwqrnxjO40(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
	KVirvJ58C1PjHyxel6FdwX()
	return
def LipZmGc2ox7Ij(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX):
	k2x5IYN9dH1FfSytmDMEGChLsX = False
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU = AhBFVbK7LzNinwrg65JjpRP
	AhBFVbK7LzNinwrg65JjpRP[:] = []
	if k2x5IYN9dH1FfSytmDMEGChLsX and '_CREATENEW_' not in zIaSNiZbOTGWrcQE79gX:
		CsaNhTtGm8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+fpegTIEPJKtW)
	elif '_LIVE_' not in zIaSNiZbOTGWrcQE79gX or '_VOD_' not in zIaSNiZbOTGWrcQE79gX:
		import OAJRx3Djkr
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in zIaSNiZbOTGWrcQE79gX:
			try: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_UNKNOWN_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـIPTV للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_MOVIES_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـIPTV للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_SERIES_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـIPTV للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		if '_VOD_' not in zIaSNiZbOTGWrcQE79gX:
			try: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'LIVE_UNKNOWN_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـIPTV للقنوات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'LIVE_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـIPTV للقنوات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		CsaNhTtGm8 = AhBFVbK7LzNinwrg65JjpRP
		if k2x5IYN9dH1FfSytmDMEGChLsX: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_IPTV','SECTIONS_IPTV_'+fpegTIEPJKtW,CsaNhTtGm8,B4GWT7zonF5yipbIwJmNUf6Vavg)
	AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU
	return CsaNhTtGm8
def EeqPGOS6ivn(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX):
	k2x5IYN9dH1FfSytmDMEGChLsX = False
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU = AhBFVbK7LzNinwrg65JjpRP
	AhBFVbK7LzNinwrg65JjpRP[:] = []
	if k2x5IYN9dH1FfSytmDMEGChLsX and '_CREATENEW_' not in zIaSNiZbOTGWrcQE79gX:
		CsaNhTtGm8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS_M3U','SECTIONS_M3U_'+fpegTIEPJKtW)
	elif '_LIVE_' not in zIaSNiZbOTGWrcQE79gX or '_VOD_' not in zIaSNiZbOTGWrcQE79gX:
		import Lb65UCfP20
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in zIaSNiZbOTGWrcQE79gX:
			try: Lb65UCfP20.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_UNKNOWN_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـM3U للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: Lb65UCfP20.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_MOVIES_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـM3U للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: Lb65UCfP20.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'VOD_SERIES_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـM3U للفيديوهات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		if '_VOD_' not in zIaSNiZbOTGWrcQE79gX:
			try: Lb65UCfP20.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'LIVE_UNKNOWN_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـM3U للقنوات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			try: Lb65UCfP20.UUzCA532dhqKblQoYgJs(fpegTIEPJKtW,'LIVE_GROUPED_SORTED',Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zIaSNiZbOTGWrcQE79gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع ـM3U للقنوات',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		CsaNhTtGm8 = AhBFVbK7LzNinwrg65JjpRP
		if k2x5IYN9dH1FfSytmDMEGChLsX: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_'+fpegTIEPJKtW,CsaNhTtGm8,B4GWT7zonF5yipbIwJmNUf6Vavg)
	AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU
	return CsaNhTtGm8
def IV0J26giKvahkmXwdQTo1cSC3DpWFZ(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX,tU43BcCiGTV85pL):
	if '_CREATENEW_' in zIaSNiZbOTGWrcQE79gX and tU43BcCiGTV85pL==Zg9FeADE84jSRIvPCrzYulw3sL: PY7y3Iwatle2mJFWROkGzVAbqMUTEh(True)
	elif tU43BcCiGTV85pL: PY7y3Iwatle2mJFWROkGzVAbqMUTEh(False)
	GNlry8K3bT = zIaSNiZbOTGWrcQE79gX.replace('_CREATENEW_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	if not tU43BcCiGTV85pL:
		A9Z3Ci2PQhFUwBXvI('link','تحديث هذه القائمة',Zg9FeADE84jSRIvPCrzYulw3sL,763,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_CREATENEW_'+GNlry8K3bT,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	i3EyRQuIhemBb = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	sY4k1JTnjFS0DB = ['افلام','movie','فيلم','فلم']
	YiI6CZGR28s1fyjbF5XeToc7uS9 = ['مسلسل','series']
	ocvSdU6zfGpjQrBKV = ['مسارح','مسرحيات']
	Akl1pSibnH9xQuYdV5M7tU4jef8cL = ['برامج','show','تلفزيون','تليفزيون']
	rgz12eJuDG9FN8AIsP6 = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	zBfmuqGeXZ2rK4TvboDMF1x395WHSA = ['رمضان']
	xxSIompNHlMPkB63nRVLsTaJAbrZKg = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	wh3XJAG0HotFruvs15K = ['سلاسل','سلسله']
	wmnA6Pf4BZhdiSEMgqK = ['اغاني','موسيقى','كليب','حفل','music']
	k4ux8SUIXlwpAHznoWPf3JFLOGmd2 = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	L1ADMS6lZ2fbGxPJgKutOmVs8earn = ['الان','حالي','مثبت','رائج']
	boexXhJYHSTUfjD7Nc = ['ضحك','كوميدي']
	YYK1L8v4myEPFAkctpHb2GUref = ['رياضه','كوره','مصارعه','شوت','رياضة']
	WtnKLmVQjri = ['نيتفلكس','netflix','نيتفليكس']
	gzSI7QZK36HEovjTPLW = ['ممثلين','اشخاص','نجوم']
	nHNoV6BMsIPWhxt2FKC = ['بث حي','live','قناه','قنوات']
	cc4FsG75euqXVa3HCk = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	OOsmnJv16WxNQtwMUDI8KGa = ['19','20','21','22','23','24','25','26']
	if not tU43BcCiGTV85pL:
		tU43BcCiGTV85pL = 0
		for WBZ8j9fqGn0PCTdFALVDK in i3EyRQuIhemBb:
			tU43BcCiGTV85pL += 1
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+WBZ8j9fqGn0PCTdFALVDK,Zg9FeADE84jSRIvPCrzYulw3sL,763,Zg9FeADE84jSRIvPCrzYulw3sL,str(tU43BcCiGTV85pL),GNlry8K3bT,Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
	else:
		for VaOH2318eP5yQWXrkcx in sorted(list(Als2YrFfpG6.keys())):
			W4KwrJtUfaNF2Q3Coqsl869V1dbm = VaOH2318eP5yQWXrkcx.lower()
			WWdHIOCPeKmgRstXk4c = []
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in sY4k1JTnjFS0DB): WWdHIOCPeKmgRstXk4c.append(1)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in YiI6CZGR28s1fyjbF5XeToc7uS9): WWdHIOCPeKmgRstXk4c.append(2)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in ocvSdU6zfGpjQrBKV): WWdHIOCPeKmgRstXk4c.append(3)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in Akl1pSibnH9xQuYdV5M7tU4jef8cL): WWdHIOCPeKmgRstXk4c.append(4)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in rgz12eJuDG9FN8AIsP6): WWdHIOCPeKmgRstXk4c.append(5)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in zBfmuqGeXZ2rK4TvboDMF1x395WHSA): WWdHIOCPeKmgRstXk4c.append(6)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in xxSIompNHlMPkB63nRVLsTaJAbrZKg) and W4KwrJtUfaNF2Q3Coqsl869V1dbm not in ['اخرى']: WWdHIOCPeKmgRstXk4c.append(7)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in wh3XJAG0HotFruvs15K): WWdHIOCPeKmgRstXk4c.append(8)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in wmnA6Pf4BZhdiSEMgqK): WWdHIOCPeKmgRstXk4c.append(9)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in k4ux8SUIXlwpAHznoWPf3JFLOGmd2): WWdHIOCPeKmgRstXk4c.append(10)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in L1ADMS6lZ2fbGxPJgKutOmVs8earn): WWdHIOCPeKmgRstXk4c.append(11)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in boexXhJYHSTUfjD7Nc): WWdHIOCPeKmgRstXk4c.append(12)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in YYK1L8v4myEPFAkctpHb2GUref): WWdHIOCPeKmgRstXk4c.append(13)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in WtnKLmVQjri): WWdHIOCPeKmgRstXk4c.append(14)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in gzSI7QZK36HEovjTPLW): WWdHIOCPeKmgRstXk4c.append(15)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in nHNoV6BMsIPWhxt2FKC): WWdHIOCPeKmgRstXk4c.append(16)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in cc4FsG75euqXVa3HCk): WWdHIOCPeKmgRstXk4c.append(17)
			if any(B251BPiLbvG9UxszKtlI7YQHmoWw in W4KwrJtUfaNF2Q3Coqsl869V1dbm for B251BPiLbvG9UxszKtlI7YQHmoWw in OOsmnJv16WxNQtwMUDI8KGa): WWdHIOCPeKmgRstXk4c.append(18)
			if not WWdHIOCPeKmgRstXk4c: WWdHIOCPeKmgRstXk4c = [19]
			for zosuEtyPVpXKqO2H7xa in WWdHIOCPeKmgRstXk4c:
				if str(zosuEtyPVpXKqO2H7xa)==tU43BcCiGTV85pL:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+VaOH2318eP5yQWXrkcx,VaOH2318eP5yQWXrkcx,166,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,GNlry8K3bT+'_REMEMBERRESULTS_')
	return
def on1w97DfhO0uycbmBsgd(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX):
	k2x5IYN9dH1FfSytmDMEGChLsX = False
	if k2x5IYN9dH1FfSytmDMEGChLsX:
		A9Z3Ci2PQhFUwBXvI('link','تحديث هذه القائمة',Zg9FeADE84jSRIvPCrzYulw3sL,764,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_CREATENEW_',Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU = AhBFVbK7LzNinwrg65JjpRP[:]
	import OAJRx3Djkr
	if fpegTIEPJKtW:
		if not OAJRx3Djkr.sudMiALnIV6pOlvta78QmJCUK(fpegTIEPJKtW,True): return
		ws4BcIv1HWPEkolOUaYDpeM = LipZmGc2ox7Ij(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX)
		Xg0VS4uIxmvy2bNGpTrY = sorted(ws4BcIv1HWPEkolOUaYDpeM,reverse=False,key=lambda key: key[1].lower())
	else:
		if not OAJRx3Djkr.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
		if k2x5IYN9dH1FfSytmDMEGChLsX and '_CREATENEW_' not in zIaSNiZbOTGWrcQE79gX:
			Xg0VS4uIxmvy2bNGpTrY = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			sORjFbEJu2vpQmr3LPka8WwB,Xg0VS4uIxmvy2bNGpTrY,ws4BcIv1HWPEkolOUaYDpeM = [],[],[]
			for ROm7YUNyvIkfELw89dAsP4uKl2GBz in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
				Xg0VS4uIxmvy2bNGpTrY += LipZmGc2ox7Ij(str(ROm7YUNyvIkfELw89dAsP4uKl2GBz),zIaSNiZbOTGWrcQE79gX)
			for type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in Xg0VS4uIxmvy2bNGpTrY:
				if Tbwq7kJ4vRSNVyUFcdMzirG not in sORjFbEJu2vpQmr3LPka8WwB:
					sORjFbEJu2vpQmr3LPka8WwB.append(Tbwq7kJ4vRSNVyUFcdMzirG)
					JJme1nbqytYWG9 = type,VaOH2318eP5yQWXrkcx,Tbwq7kJ4vRSNVyUFcdMzirG,165,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,zIaSNiZbOTGWrcQE79gX,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
					ws4BcIv1HWPEkolOUaYDpeM.append(JJme1nbqytYWG9)
			Xg0VS4uIxmvy2bNGpTrY = sorted(ws4BcIv1HWPEkolOUaYDpeM,reverse=False,key=lambda key: key[1].lower())
			if k2x5IYN9dH1FfSytmDMEGChLsX: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',Xg0VS4uIxmvy2bNGpTrY,B4GWT7zonF5yipbIwJmNUf6Vavg)
	AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+Xg0VS4uIxmvy2bNGpTrY
	i5xGCIRvcQlMemuO4jaYkWSwtD(False)
	return
def qq1AV3GDJjZoBEOmWSFX0fC9z(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX):
	k2x5IYN9dH1FfSytmDMEGChLsX = False
	if k2x5IYN9dH1FfSytmDMEGChLsX:
		A9Z3Ci2PQhFUwBXvI('link','تحديث هذه القائمة',Zg9FeADE84jSRIvPCrzYulw3sL,765,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_CREATENEW_',Zg9FeADE84jSRIvPCrzYulw3sL,{'folder':fpegTIEPJKtW})
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU = AhBFVbK7LzNinwrg65JjpRP[:]
	import Lb65UCfP20
	if fpegTIEPJKtW:
		if not Lb65UCfP20.sudMiALnIV6pOlvta78QmJCUK(fpegTIEPJKtW,True): return
		ws4BcIv1HWPEkolOUaYDpeM = EeqPGOS6ivn(fpegTIEPJKtW,zIaSNiZbOTGWrcQE79gX)
		Xg0VS4uIxmvy2bNGpTrY = sorted(ws4BcIv1HWPEkolOUaYDpeM,reverse=False,key=lambda key: key[1].lower())
	else:
		if not Lb65UCfP20.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
		if k2x5IYN9dH1FfSytmDMEGChLsX and '_CREATENEW_' not in zIaSNiZbOTGWrcQE79gX:
			Xg0VS4uIxmvy2bNGpTrY = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			sORjFbEJu2vpQmr3LPka8WwB,Xg0VS4uIxmvy2bNGpTrY,ws4BcIv1HWPEkolOUaYDpeM = [],[],[]
			for ROm7YUNyvIkfELw89dAsP4uKl2GBz in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
				Xg0VS4uIxmvy2bNGpTrY += EeqPGOS6ivn(str(ROm7YUNyvIkfELw89dAsP4uKl2GBz),zIaSNiZbOTGWrcQE79gX)
			for type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in Xg0VS4uIxmvy2bNGpTrY:
				if Tbwq7kJ4vRSNVyUFcdMzirG not in sORjFbEJu2vpQmr3LPka8WwB:
					sORjFbEJu2vpQmr3LPka8WwB.append(Tbwq7kJ4vRSNVyUFcdMzirG)
					JJme1nbqytYWG9 = type,VaOH2318eP5yQWXrkcx,Tbwq7kJ4vRSNVyUFcdMzirG,165,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,zIaSNiZbOTGWrcQE79gX,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
					ws4BcIv1HWPEkolOUaYDpeM.append(JJme1nbqytYWG9)
			Xg0VS4uIxmvy2bNGpTrY = sorted(ws4BcIv1HWPEkolOUaYDpeM,reverse=False,key=lambda key: key[1].lower())
			if k2x5IYN9dH1FfSytmDMEGChLsX: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS_M3U','SECTIONS_M3U_ALL',Xg0VS4uIxmvy2bNGpTrY,B4GWT7zonF5yipbIwJmNUf6Vavg)
	AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+Xg0VS4uIxmvy2bNGpTrY
	i5xGCIRvcQlMemuO4jaYkWSwtD(False)
	return
def H1pCLql39Yu87Q(group,zIaSNiZbOTGWrcQE79gX):
	k2x5IYN9dH1FfSytmDMEGChLsX = False
	CsaNhTtGm8 = []
	x5UCOb3KdpDrJsEcY1mo = '_IPTV_' if 'IPTV' in zIaSNiZbOTGWrcQE79gX else '_M3U_'
	if k2x5IYN9dH1FfSytmDMEGChLsX: CsaNhTtGm8 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS'+x5UCOb3KdpDrJsEcY1mo[:-1],group)
	if not CsaNhTtGm8:
		for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
			if k2x5IYN9dH1FfSytmDMEGChLsX: CsaNhTtGm8 += zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SECTIONS'+x5UCOb3KdpDrJsEcY1mo[:-1],'SECTIONS'+x5UCOb3KdpDrJsEcY1mo+str(fpegTIEPJKtW))
			elif x5UCOb3KdpDrJsEcY1mo=='_IPTV_': CsaNhTtGm8 += LipZmGc2ox7Ij(str(fpegTIEPJKtW),'_CREATENEW_')
			elif x5UCOb3KdpDrJsEcY1mo=='_M3U_': CsaNhTtGm8 += EeqPGOS6ivn(str(fpegTIEPJKtW),'_CREATENEW_')
		for type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in CsaNhTtGm8:
			if Tbwq7kJ4vRSNVyUFcdMzirG==group: v50uoKxSgEjaATet7DwzLZJyXk2CmR(type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
		items,QaVoNlxzSUORpb = [],[]
		for type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in AhBFVbK7LzNinwrg65JjpRP:
			l21p6EPJTbjNarG9Z = type,VaOH2318eP5yQWXrkcx[4:],url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,Zg9FeADE84jSRIvPCrzYulw3sL
			if l21p6EPJTbjNarG9Z not in QaVoNlxzSUORpb:
				QaVoNlxzSUORpb.append(l21p6EPJTbjNarG9Z)
				r1OMYvp0ViTG = type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
				items.append(r1OMYvp0ViTG)
		CsaNhTtGm8 = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if k2x5IYN9dH1FfSytmDMEGChLsX: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SECTIONS'+x5UCOb3KdpDrJsEcY1mo[:-1],group,CsaNhTtGm8,B4GWT7zonF5yipbIwJmNUf6Vavg)
	if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX and len(CsaNhTtGm8)>mq7rgp6FRO:
		AhBFVbK7LzNinwrg65JjpRP[:] = []
		A9Z3Ci2PQhFUwBXvI('folder','['+PPQORjT2lc7SVkKwFI4D+group+u4IRSmrYMKkaHUBnDiLWh+' :القسم]',group,165,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x5UCOb3KdpDrJsEcY1mo+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		A9Z3Ci2PQhFUwBXvI('folder','إعادة الطلب العشوائي من نفس القسم',group,165,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x5UCOb3KdpDrJsEcY1mo+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		CsaNhTtGm8 = AhBFVbK7LzNinwrg65JjpRP+pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(CsaNhTtGm8,mq7rgp6FRO)
	AhBFVbK7LzNinwrg65JjpRP[:] = CsaNhTtGm8
	i5xGCIRvcQlMemuO4jaYkWSwtD(False)
	return
def ssFCMcQlIdmxzw(zIaSNiZbOTGWrcQE79gX):
	A9Z3Ci2PQhFUwBXvI('folder','إعادة طلب قنوات عشوائية',Zg9FeADE84jSRIvPCrzYulw3sL,161,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	Syu6a0UseE8FGfWzLpt = AhBFVbK7LzNinwrg65JjpRP[:]
	AhBFVbK7LzNinwrg65JjpRP[:] = []
	import vvxHJkcCeG
	vvxHJkcCeG.yfWYTB58bDO('0',False)
	vvxHJkcCeG.yfWYTB58bDO('1',False)
	vvxHJkcCeG.yfWYTB58bDO('2',False)
	if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX:
		AhBFVbK7LzNinwrg65JjpRP[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
		if len(AhBFVbK7LzNinwrg65JjpRP)>mq7rgp6FRO: AhBFVbK7LzNinwrg65JjpRP[:] = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(AhBFVbK7LzNinwrg65JjpRP,mq7rgp6FRO)
	AhBFVbK7LzNinwrg65JjpRP[:] = Syu6a0UseE8FGfWzLpt+AhBFVbK7LzNinwrg65JjpRP
	return
def OVTFsgclRG4DKdAWCS(zIaSNiZbOTGWrcQE79gX):
	zIaSNiZbOTGWrcQE79gX = zIaSNiZbOTGWrcQE79gX.replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = nWw3GirR9qxCFBOa5Dt1gdXmJMpy(data)
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,'GET',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="content"(.*?)class="clearfix"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	pmQqNR56iPBVbOxHw,bOh4xRfDMoYeU = list(zip(*items))
	Hj0mAM4hb1aQtBi2P9W = []
	EIDi84Uj79LmaGBt6NypknV = [wjs26GpVfNiCUERHJ,'"','`',',','.',':',';',"'",'-']
	Dmhs6Y2BNAwx7Zt1Fk = bOh4xRfDMoYeU+pmQqNR56iPBVbOxHw
	for ZZH0OuidEG79JWPKw in Dmhs6Y2BNAwx7Zt1Fk:
		if ZZH0OuidEG79JWPKw in bOh4xRfDMoYeU: Z710CiEgwLNp2zqBnT8ymFjtcU = 2
		if ZZH0OuidEG79JWPKw in pmQqNR56iPBVbOxHw: Z710CiEgwLNp2zqBnT8ymFjtcU = 4
		T7VyXqpUoDPLMza = [YjZN3ADmertFahUQIECW in ZZH0OuidEG79JWPKw for YjZN3ADmertFahUQIECW in EIDi84Uj79LmaGBt6NypknV]
		if any(T7VyXqpUoDPLMza):
			I5ycituE8YxBLn = T7VyXqpUoDPLMza.index(True)
			lXEaStcK3mQDeIC54LuHgUsYzjnqvW = EIDi84Uj79LmaGBt6NypknV[I5ycituE8YxBLn]
			y8M6ohf1cjBnvKtTeREW = Zg9FeADE84jSRIvPCrzYulw3sL
			if ZZH0OuidEG79JWPKw.count(lXEaStcK3mQDeIC54LuHgUsYzjnqvW)>1: lzeInXfkNP4MrO52wqdZU8gR7oy1VG,EmXu7VR0ZPKq98r6Nhj,y8M6ohf1cjBnvKtTeREW = ZZH0OuidEG79JWPKw.split(lXEaStcK3mQDeIC54LuHgUsYzjnqvW,2)
			else: lzeInXfkNP4MrO52wqdZU8gR7oy1VG,EmXu7VR0ZPKq98r6Nhj = ZZH0OuidEG79JWPKw.split(lXEaStcK3mQDeIC54LuHgUsYzjnqvW,1)
			if len(lzeInXfkNP4MrO52wqdZU8gR7oy1VG)>Z710CiEgwLNp2zqBnT8ymFjtcU: Hj0mAM4hb1aQtBi2P9W.append(lzeInXfkNP4MrO52wqdZU8gR7oy1VG.lower())
			if len(EmXu7VR0ZPKq98r6Nhj)>Z710CiEgwLNp2zqBnT8ymFjtcU: Hj0mAM4hb1aQtBi2P9W.append(EmXu7VR0ZPKq98r6Nhj.lower())
			if len(y8M6ohf1cjBnvKtTeREW)>Z710CiEgwLNp2zqBnT8ymFjtcU: Hj0mAM4hb1aQtBi2P9W.append(y8M6ohf1cjBnvKtTeREW.lower())
		elif len(ZZH0OuidEG79JWPKw)>Z710CiEgwLNp2zqBnT8ymFjtcU: Hj0mAM4hb1aQtBi2P9W.append(ZZH0OuidEG79JWPKw.lower())
	for YjZN3ADmertFahUQIECW in range(9): pJ5tI2GD1jSPgdzO7qBuFk60Rni93.shuffle(Hj0mAM4hb1aQtBi2P9W)
	if '_SITES_' in zIaSNiZbOTGWrcQE79gX:
		zL72ThKkju6xV31D = LRS4BMJz10XF2s7ghtmvwVofr
	elif '_IPTV_' in zIaSNiZbOTGWrcQE79gX:
		zL72ThKkju6xV31D = ['IPTV']
		import OAJRx3Djkr
		if not OAJRx3Djkr.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
	elif '_M3U_' in zIaSNiZbOTGWrcQE79gX:
		zL72ThKkju6xV31D = ['M3U']
		import Lb65UCfP20
		if not Lb65UCfP20.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
	count,VyJuFPGYHzlUT57rokIfw = 0,0
	A9Z3Ci2PQhFUwBXvI('folder','[  ] :البحث عن',Zg9FeADE84jSRIvPCrzYulw3sL,164,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
	A9Z3Ci2PQhFUwBXvI('folder','إعادة البحث العشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,164,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	RR6UlHXj30fQIxvcZ = AhBFVbK7LzNinwrg65JjpRP[:]
	AhBFVbK7LzNinwrg65JjpRP[:] = []
	MQ5eYV8Nk9EW0muOdcbCypLoKH = []
	for ZZH0OuidEG79JWPKw in Hj0mAM4hb1aQtBi2P9W:
		EmXu7VR0ZPKq98r6Nhj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',ZZH0OuidEG79JWPKw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if EmXu7VR0ZPKq98r6Nhj: ZZH0OuidEG79JWPKw = ZZH0OuidEG79JWPKw.split(EmXu7VR0ZPKq98r6Nhj[0],1)[0]
		kEwiUJpBWhP653cDMlxAmyz = ZZH0OuidEG79JWPKw.replace('ّ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('َ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ً',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ُ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٌ',Zg9FeADE84jSRIvPCrzYulw3sL)
		kEwiUJpBWhP653cDMlxAmyz = kEwiUJpBWhP653cDMlxAmyz.replace('ِ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ٍ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ْ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('،',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ـ',Zg9FeADE84jSRIvPCrzYulw3sL)
		if kEwiUJpBWhP653cDMlxAmyz: MQ5eYV8Nk9EW0muOdcbCypLoKH.append(kEwiUJpBWhP653cDMlxAmyz)
	Rkbd9gFOSMos = []
	for OEJ3PT81KtbZ in range(0,20):
		search = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(MQ5eYV8Nk9EW0muOdcbCypLoKH,1)[0]
		if search in Rkbd9gFOSMos: continue
		Rkbd9gFOSMos.append(search)
		FLqQoZwdAngNkz49RMGUHJXW3bDC = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(zL72ThKkju6xV31D,1)[0]
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Random Video Search   site:'+str(FLqQoZwdAngNkz49RMGUHJXW3bDC)+'  search:'+search)
		AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		BZNYcxOXAElzS2IPf0aji(search+'_NODIALOGS_')
		if len(AhBFVbK7LzNinwrg65JjpRP)>0: break
	search = search.replace('_MOD_',Zg9FeADE84jSRIvPCrzYulw3sL)
	RR6UlHXj30fQIxvcZ[0][1] = '['+PPQORjT2lc7SVkKwFI4D+search+u4IRSmrYMKkaHUBnDiLWh+' :بحث عن]'
	AhBFVbK7LzNinwrg65JjpRP[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
	if len(AhBFVbK7LzNinwrg65JjpRP)>mq7rgp6FRO: AhBFVbK7LzNinwrg65JjpRP[:] = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(AhBFVbK7LzNinwrg65JjpRP,mq7rgp6FRO)
	AhBFVbK7LzNinwrg65JjpRP[:] = RR6UlHXj30fQIxvcZ+AhBFVbK7LzNinwrg65JjpRP
	return
def DDnkS9vmzO7G5hCLY3AebJixplgM4(ZXPWugUdx7fVt5ATwMv,zIaSNiZbOTGWrcQE79gX):
	ZXPWugUdx7fVt5ATwMv = ZXPWugUdx7fVt5ATwMv.replace('_MOD_',Zg9FeADE84jSRIvPCrzYulw3sL)
	zIaSNiZbOTGWrcQE79gX = zIaSNiZbOTGWrcQE79gX.replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	PY7y3Iwatle2mJFWROkGzVAbqMUTEh(False)
	if Als2YrFfpG6=={}: return
	if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX:
		A9Z3Ci2PQhFUwBXvI('folder','['+PPQORjT2lc7SVkKwFI4D+ZXPWugUdx7fVt5ATwMv+u4IRSmrYMKkaHUBnDiLWh+' :القسم]',ZXPWugUdx7fVt5ATwMv,166,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
		A9Z3Ci2PQhFUwBXvI('folder','إعادة الطلب العشوائي من نفس القسم',ZXPWugUdx7fVt5ATwMv,166,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	for website in sorted(list(Als2YrFfpG6[ZXPWugUdx7fVt5ATwMv].keys())):
		type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = Als2YrFfpG6[ZXPWugUdx7fVt5ATwMv][website]
		if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX or len(Als2YrFfpG6[ZXPWugUdx7fVt5ATwMv])==1:
			v50uoKxSgEjaATet7DwzLZJyXk2CmR(type,Zg9FeADE84jSRIvPCrzYulw3sL,url,OukWzCose6y,Zg9FeADE84jSRIvPCrzYulw3sL,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
			AhBFVbK7LzNinwrg65JjpRP[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
			WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU,Xg0VS4uIxmvy2bNGpTrY = AhBFVbK7LzNinwrg65JjpRP[:3],AhBFVbK7LzNinwrg65JjpRP[3:]
			for YjZN3ADmertFahUQIECW in range(9): pJ5tI2GD1jSPgdzO7qBuFk60Rni93.shuffle(Xg0VS4uIxmvy2bNGpTrY)
			if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX: AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+Xg0VS4uIxmvy2bNGpTrY[:mq7rgp6FRO]
			else: AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+Xg0VS4uIxmvy2bNGpTrY
		elif '_SITES_' in zIaSNiZbOTGWrcQE79gX: A9Z3Ci2PQhFUwBXvI('folder',website,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	return
def VK9dy20XhC1e368uiROGgzsQ(zIaSNiZbOTGWrcQE79gX,LfnWDFgRdJH4lZvt7yo28N):
	zIaSNiZbOTGWrcQE79gX = zIaSNiZbOTGWrcQE79gX.replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	VaOH2318eP5yQWXrkcx,kWOjxU5qnRF = Zg9FeADE84jSRIvPCrzYulw3sL,[]
	A9Z3Ci2PQhFUwBXvI('folder','['+PPQORjT2lc7SVkKwFI4D+VaOH2318eP5yQWXrkcx+u4IRSmrYMKkaHUBnDiLWh+' :القسم]',Zg9FeADE84jSRIvPCrzYulw3sL,LfnWDFgRdJH4lZvt7yo28N,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
	A9Z3Ci2PQhFUwBXvI('folder','إعادة طلب قسم عشوائي',Zg9FeADE84jSRIvPCrzYulw3sL,LfnWDFgRdJH4lZvt7yo28N,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+zIaSNiZbOTGWrcQE79gX)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU = AhBFVbK7LzNinwrg65JjpRP[:]
	AhBFVbK7LzNinwrg65JjpRP[:] = []
	CsaNhTtGm8 = []
	if '_SITES_' in zIaSNiZbOTGWrcQE79gX:
		PY7y3Iwatle2mJFWROkGzVAbqMUTEh(False)
		if Als2YrFfpG6=={}: return
		E9EGNWlTumKQeHz = list(Als2YrFfpG6.keys())
		ZXPWugUdx7fVt5ATwMv = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(E9EGNWlTumKQeHz,1)[0]
		Hj0mAM4hb1aQtBi2P9W = list(Als2YrFfpG6[ZXPWugUdx7fVt5ATwMv].keys())
		website = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(Hj0mAM4hb1aQtBi2P9W,1)[0]
		type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = Als2YrFfpG6[ZXPWugUdx7fVt5ATwMv][website]
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Random Category   website: '+website+'   name: '+VaOH2318eP5yQWXrkcx+'   url: '+url+'   mode: '+str(OukWzCose6y))
	elif '_IPTV_' in zIaSNiZbOTGWrcQE79gX:
		import OAJRx3Djkr
		if not OAJRx3Djkr.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
		for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
			CsaNhTtGm8 += LipZmGc2ox7Ij(str(fpegTIEPJKtW),zIaSNiZbOTGWrcQE79gX)
		if not CsaNhTtGm8: return
		type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(CsaNhTtGm8,1)[0]
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Random Category   name: '+VaOH2318eP5yQWXrkcx+'   url: '+url+'   mode: '+str(OukWzCose6y))
	elif '_M3U_' in zIaSNiZbOTGWrcQE79gX:
		import Lb65UCfP20
		if not Lb65UCfP20.sudMiALnIV6pOlvta78QmJCUK(Zg9FeADE84jSRIvPCrzYulw3sL,True): return
		for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
			CsaNhTtGm8 += EeqPGOS6ivn(str(fpegTIEPJKtW),zIaSNiZbOTGWrcQE79gX)
		if not CsaNhTtGm8: return
		type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(CsaNhTtGm8,1)[0]
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Random Category   name: '+VaOH2318eP5yQWXrkcx+'   url: '+url+'   mode: '+str(OukWzCose6y))
	xjKqcMkFYU5ovO1 = VaOH2318eP5yQWXrkcx
	DRFeXJ0Y24hsNZWEBzwCxdQf1 = []
	for YjZN3ADmertFahUQIECW in range(0,10):
		if YjZN3ADmertFahUQIECW>0: zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Random Category   name: '+VaOH2318eP5yQWXrkcx+'   url: '+url+'   mode: '+str(OukWzCose6y))
		AhBFVbK7LzNinwrg65JjpRP[:] = []
		if OukWzCose6y==234 and '__IPTVSeries__' in Tbwq7kJ4vRSNVyUFcdMzirG: OukWzCose6y = 233
		if OukWzCose6y==714 and '__M3USeries__' in Tbwq7kJ4vRSNVyUFcdMzirG: OukWzCose6y = 713
		if OukWzCose6y==144: OukWzCose6y = 291
		DMKySWniQ0HqtCsrg65dmb2Tha = v50uoKxSgEjaATet7DwzLZJyXk2CmR(type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
		if '_IPTV_' in zIaSNiZbOTGWrcQE79gX and OukWzCose6y==167: del AhBFVbK7LzNinwrg65JjpRP[:3]
		if '_M3U_' in zIaSNiZbOTGWrcQE79gX and OukWzCose6y==168: del AhBFVbK7LzNinwrg65JjpRP[:3]
		kWOjxU5qnRF[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
		if DRFeXJ0Y24hsNZWEBzwCxdQf1 and nWsGkOX74PMJ(u'حلقة') in str(kWOjxU5qnRF) or nWsGkOX74PMJ(u'حلقه') in str(kWOjxU5qnRF):
			VaOH2318eP5yQWXrkcx = xjKqcMkFYU5ovO1
			kWOjxU5qnRF[:] = DRFeXJ0Y24hsNZWEBzwCxdQf1
			break
		xjKqcMkFYU5ovO1 = VaOH2318eP5yQWXrkcx
		DRFeXJ0Y24hsNZWEBzwCxdQf1 = kWOjxU5qnRF
		if str(kWOjxU5qnRF).count('video')>0: break
		if str(kWOjxU5qnRF).count('live')>0: break
		if OukWzCose6y==233: break
		if OukWzCose6y==713: break
		if OukWzCose6y==291: break
		if kWOjxU5qnRF: type,VaOH2318eP5yQWXrkcx,url,OukWzCose6y,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(kWOjxU5qnRF,1)[0]
	if not VaOH2318eP5yQWXrkcx: VaOH2318eP5yQWXrkcx = '....'
	elif VaOH2318eP5yQWXrkcx.count('_')>1: VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.split('_',2)[2]
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('UNKNOWN: ',Zg9FeADE84jSRIvPCrzYulw3sL)
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('_MOD_',Zg9FeADE84jSRIvPCrzYulw3sL)
	WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU[0][1] = '['+PPQORjT2lc7SVkKwFI4D+VaOH2318eP5yQWXrkcx+u4IRSmrYMKkaHUBnDiLWh+' :القسم]'
	for YjZN3ADmertFahUQIECW in range(9): pJ5tI2GD1jSPgdzO7qBuFk60Rni93.shuffle(kWOjxU5qnRF)
	if '_RANDOM_' in zIaSNiZbOTGWrcQE79gX: AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+kWOjxU5qnRF[:mq7rgp6FRO]
	else: AhBFVbK7LzNinwrg65JjpRP[:] = WFwoCRP7hMfHOpD1aYS5Qdmsb2yuNU+kWOjxU5qnRF
	return
def RRhUq7cOMmu65kaIzDpPbov(DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD):
	v0Xd7pk9UbAPom51GD = v0Xd7pk9UbAPom51GD.replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	QievdNR3o5sftHALcMVnIzu2 = v0Xd7pk9UbAPom51GD
	if '__IPTVSeries__' in v0Xd7pk9UbAPom51GD:
		QievdNR3o5sftHALcMVnIzu2 = v0Xd7pk9UbAPom51GD.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in DDuIb5FnJo2UtBzq4LNAXsfdpkRga3: type = ',VIDEOS: '
	elif 'LIVE' in DDuIb5FnJo2UtBzq4LNAXsfdpkRga3: type = ',LIVE: '
	A9Z3Ci2PQhFUwBXvI('folder','['+PPQORjT2lc7SVkKwFI4D+type+QievdNR3o5sftHALcMVnIzu2+u4IRSmrYMKkaHUBnDiLWh+' :القسم]',DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,167,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+v0Xd7pk9UbAPom51GD)
	A9Z3Ci2PQhFUwBXvI('folder','إعادة الطلب العشوائي من نفس القسم',DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,167,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+v0Xd7pk9UbAPom51GD)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	import OAJRx3Djkr
	for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
		if '__IPTVSeries__' in v0Xd7pk9UbAPom51GD: OAJRx3Djkr.UUzCA532dhqKblQoYgJs(str(fpegTIEPJKtW),DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD,Zg9FeADE84jSRIvPCrzYulw3sL,False)
		else: OAJRx3Djkr.yfWYTB58bDO(str(fpegTIEPJKtW),DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD,Zg9FeADE84jSRIvPCrzYulw3sL,False)
	AhBFVbK7LzNinwrg65JjpRP[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
	if len(AhBFVbK7LzNinwrg65JjpRP)>(mq7rgp6FRO+3): AhBFVbK7LzNinwrg65JjpRP[:] = AhBFVbK7LzNinwrg65JjpRP[:3]+pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(AhBFVbK7LzNinwrg65JjpRP[3:],mq7rgp6FRO)
	return
def iU1jhMzVbxItsyAlCL8nrvDd(DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD):
	v0Xd7pk9UbAPom51GD = v0Xd7pk9UbAPom51GD.replace('_FORGETRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL).replace('_REMEMBERRESULTS_',Zg9FeADE84jSRIvPCrzYulw3sL)
	QievdNR3o5sftHALcMVnIzu2 = v0Xd7pk9UbAPom51GD
	if '__M3USeries__' in v0Xd7pk9UbAPom51GD:
		QievdNR3o5sftHALcMVnIzu2 = v0Xd7pk9UbAPom51GD.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in DDuIb5FnJo2UtBzq4LNAXsfdpkRga3: type = ',VIDEOS: '
	elif 'LIVE' in DDuIb5FnJo2UtBzq4LNAXsfdpkRga3: type = ',LIVE: '
	A9Z3Ci2PQhFUwBXvI('folder','['+PPQORjT2lc7SVkKwFI4D+type+QievdNR3o5sftHALcMVnIzu2+u4IRSmrYMKkaHUBnDiLWh+' :القسم]',DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,168,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+v0Xd7pk9UbAPom51GD)
	A9Z3Ci2PQhFUwBXvI('folder','إعادة الطلب العشوائي من نفس القسم',DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,168,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_FORGETRESULTS__REMEMBERRESULTS_'+v0Xd7pk9UbAPom51GD)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	import Lb65UCfP20
	for fpegTIEPJKtW in range(1,JjS5I28PwBEaqWMFhYLUdR+1):
		if '__M3USeries__' in v0Xd7pk9UbAPom51GD: Lb65UCfP20.UUzCA532dhqKblQoYgJs(str(fpegTIEPJKtW),DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD,Zg9FeADE84jSRIvPCrzYulw3sL,False)
		else: Lb65UCfP20.yfWYTB58bDO(str(fpegTIEPJKtW),DDuIb5FnJo2UtBzq4LNAXsfdpkRga3,v0Xd7pk9UbAPom51GD,Zg9FeADE84jSRIvPCrzYulw3sL,False)
	AhBFVbK7LzNinwrg65JjpRP[:] = cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP)
	if len(AhBFVbK7LzNinwrg65JjpRP)>(mq7rgp6FRO+3): AhBFVbK7LzNinwrg65JjpRP[:] = AhBFVbK7LzNinwrg65JjpRP[:3]+pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(AhBFVbK7LzNinwrg65JjpRP[3:],mq7rgp6FRO)
	return
def cvl35O0wryYPIbhRfzx6dZ(AhBFVbK7LzNinwrg65JjpRP):
	kWOjxU5qnRF = []
	for type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia in AhBFVbK7LzNinwrg65JjpRP:
		if 'صفحة' in VaOH2318eP5yQWXrkcx or 'صفحه' in VaOH2318eP5yQWXrkcx or 'page' in VaOH2318eP5yQWXrkcx.lower(): continue
		kWOjxU5qnRF.append([type,VaOH2318eP5yQWXrkcx,url,LfnWDFgRdJH4lZvt7yo28N,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Tbwq7kJ4vRSNVyUFcdMzirG,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia])
	return kWOjxU5qnRF
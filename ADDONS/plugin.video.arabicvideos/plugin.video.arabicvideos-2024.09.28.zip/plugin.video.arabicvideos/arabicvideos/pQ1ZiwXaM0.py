# -*- coding: utf-8 -*-
from V1VREBsj92 import *
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
bIPsOxjEpoH = 'AKOAM'
j0jSEdTPJuG4XNvfpO = '_AKO_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
g5MkB9vLJsSmYQhwUGA = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==70: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==71: CsaNhTtGm8 = hj3nmoDds5i679V2qKRN1vBMpAS8(url)
	elif mode==72: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==73: CsaNhTtGm8 = Dk2Ry6GWjdm8gi0175(url)
	elif mode==74: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==79: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,79,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'سلسلة افلام',Zg9FeADE84jSRIvPCrzYulw3sL,79,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'سلسلة افلام')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'سلاسل منوعة',Zg9FeADE84jSRIvPCrzYulw3sL,79,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'سلسلة')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	Uhe07PlWNakHDZc1t = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAM-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="partions"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t:
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,71)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def hj3nmoDds5i679V2qKRN1vBMpAS8(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAM-CATEGORIES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sect_parts(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = title.strip(wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,72)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'جميع الفروع',url,72)
	else: mbzIyKNqMVt0FQeOsPWc(url,Zg9FeADE84jSRIvPCrzYulw3sL)
	return
def mbzIyKNqMVt0FQeOsPWc(url,type):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('section_title featured_title(.*?)subjects-crousel',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif type=='search':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('akoam_result(.*?)<script',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif type=='more':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('section_title more_title(.*?)footer_bottom_services',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('navigation(.*?)<script',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items and HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
		title = BtKvPnEQJx32Z(title)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in g5MkB9vLJsSmYQhwUGA): A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,73,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,73,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pagination"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("</li><li >.*?href='(.*?)'>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,72,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,type)
	return
def gF8jmYVB9KzPtAaGZ3(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAM-SECTIONS-2nd')
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"href","(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[1]
	return hc5ePKxl4LJvEjDgTm
def Dk2Ry6GWjdm8gi0175(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAM-SECTIONS-1st')
	itVF1Q5eo4Z96RscghUk8wyM = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(https*://akwam.net/\w+.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	oo59vgcl7hCxeL2P = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(https*://underurl.com/\w+.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if itVF1Q5eo4Z96RscghUk8wyM or oo59vgcl7hCxeL2P:
		if itVF1Q5eo4Z96RscghUk8wyM: JaqiYfEglZDvmwQNS8zR = itVF1Q5eo4Z96RscghUk8wyM[0]
		elif oo59vgcl7hCxeL2P: JaqiYfEglZDvmwQNS8zR = gF8jmYVB9KzPtAaGZ3(oo59vgcl7hCxeL2P[0])
		JaqiYfEglZDvmwQNS8zR = UAjMPLdITqWChbrcB(JaqiYfEglZDvmwQNS8zR)
		import IyYirQzZGv
		if '/series/' in JaqiYfEglZDvmwQNS8zR or '/shows/' in JaqiYfEglZDvmwQNS8zR: IyYirQzZGv.dHjny9tTucrO(JaqiYfEglZDvmwQNS8zR)
		else: IyYirQzZGv.npRzZYjSm35wucxNPFlsTibVJeqI(JaqiYfEglZDvmwQNS8zR)
		return
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		title = BtKvPnEQJx32Z(title)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,73)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f:
		ZXWeI01flR('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,W8KBRzkdhlCxvF5sY2T,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	name = name.strip(wjs26GpVfNiCUERHJ)
	if 'sub_epsiode_title' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else:
		CVWuseq2wY47UF = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sub_file_title\'>(.*?) - <i>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		items = []
		for filename in CVWuseq2wY47UF:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',Zg9FeADE84jSRIvPCrzYulw3sL) ]
	count = 0
	nnhWEIa6Tm,KveOyf53gL = [],[]
	size = len(items)
	for title,filename in items:
		QAHN1PzTaF = Zg9FeADE84jSRIvPCrzYulw3sL
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: QAHN1PzTaF = filename.split('.')[-1]
		title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
		nnhWEIa6Tm.append(title)
		KveOyf53gL.append(count)
		count += 1
	if size>0:
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in name for B251BPiLbvG9UxszKtlI7YQHmoWw in g5MkB9vLJsSmYQhwUGA):
			if size==1:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = 0
			else:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الفيديو المناسب:', nnhWEIa6Tm)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1: return
			npRzZYjSm35wucxNPFlsTibVJeqI(url+'?section='+str(1+KveOyf53gL[size-lqQvOUWodZnhXLS2Vcuj6EtairFN-1]))
		else:
			for YjZN3ADmertFahUQIECW in reversed(range(size)):
				title = name + ' - ' + nnhWEIa6Tm[YjZN3ADmertFahUQIECW]
				title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
				yDTPzhEBKVJl7CX81 = url + '?section='+str(size-YjZN3ADmertFahUQIECW)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,74,W8KBRzkdhlCxvF5sY2T)
	else:
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+'الرابط ليس فيديو',Zg9FeADE84jSRIvPCrzYulw3sL,9999,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	hc5ePKxl4LJvEjDgTm,jjYXOr8QJsNUZv0PGL27ARSDceiq4 = url.split('?section=')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAM-PLAY_AKOAM-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	Vh7Cjs4KteF1GYLHr3bTZw = HNRenB3EZX62qgSKMd4f[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	Vh7Cjs4KteF1GYLHr3bTZw = Vh7Cjs4KteF1GYLHr3bTZw + 'direct_link_box'
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('epsoide_box(.*?)direct_link_box',Vh7Cjs4KteF1GYLHr3bTZw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	jjYXOr8QJsNUZv0PGL27ARSDceiq4 = len(qLx93JtrVCHlKaZW2hXc7dpiNmDR)-int(jjYXOr8QJsNUZv0PGL27ARSDceiq4)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = qLx93JtrVCHlKaZW2hXc7dpiNmDR[jjYXOr8QJsNUZv0PGL27ARSDceiq4]
	ZZH6czYDb0 = []
	eLIn05kZRWp7E43AXvcGDamhsK = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("class='download_btn.*?href='(.*?)'",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81 in items:
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named=________akoam')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for fZ9glveN2DCKdm5P,yDTPzhEBKVJl7CX81 in items:
		fZ9glveN2DCKdm5P = fZ9glveN2DCKdm5P.split('/')[-1]
		fZ9glveN2DCKdm5P = fZ9glveN2DCKdm5P.split('.')[0]
		if fZ9glveN2DCKdm5P in eLIn05kZRWp7E43AXvcGDamhsK:
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+eLIn05kZRWp7E43AXvcGDamhsK[fZ9glveN2DCKdm5P]+'________akoam')
		else: ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+fZ9glveN2DCKdm5P+'________akoam')
	if not ZZH6czYDb0:
		message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sub-no-file.*?\n(.*?)\n',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if message: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من الموقع الاصلي',message[0])
	else:
		import XabeJODuZn
		XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'%20')
	url = qfzHe2Yr49 + '/search/'+IGh3FSLfnog2BjN8s
	CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
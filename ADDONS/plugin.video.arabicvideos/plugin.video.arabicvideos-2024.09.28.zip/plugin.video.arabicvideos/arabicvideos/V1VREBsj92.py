# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from Kea9OSx7dZ import *
import base64 as JDMo92nlwsAZydBPkpNzFvU
bIPsOxjEpoH = yNBjYsgc23xoW(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ୸")
Als2YrFfpG6 = {}
AhBFVbK7LzNinwrg65JjpRP = []
DTYFukmj6ZVqygxARW1l0dXOpU2nv,xR1dtBMSbZ,HHUlnoL5redz7fE6QKq9jSTv42sMFy = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
llZXU07bFzpoI9nrK = {}
o3YKZFPvy9ag,k3weSoAxVMRl8qEPB7LWpiFfv = [UwCT5Oz6Wo0BP],[UwCT5Oz6Wo0BP]
B6ICRbTVXOQ1l4JsGxaFZy8AUvg2 = vvglE69OFKBm817Nkc
if GGfPQnrJKEqMv2ZVxdD:
	QI90vnGbT1LoPUNsxgecSZyV = PVqhLze0sFTyf.translatePath(ttC4VURALPYKh(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ୹"))
	C8ik4xAOE2Y53qZRJy6nbUVm = PVqhLze0sFTyf.translatePath(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭୺"))
	AvEeVqt3nSw2LHXQl8uFOKI5 = PVqhLze0sFTyf.translatePath(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ୻"))
	HHgE1pqyiM4W5 = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,DKmLTA2yGtj(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ୼"),ReLGYUQjz7C9iEd(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ୽"),YXm2qAbu8Qsx(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ୾"))
	w7wy9hIDTUo1WNius = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,eCpDE6wJtYUHn0GqK5(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ୿"),Vi1oNCM5kI7yJ0(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭஀"),vhZ5qjay1z94JmcMOgXe(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ஁"))
	LcUmF0zYN5j9uQB = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,YXm2qAbu8Qsx(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஂ"),vhZ5qjay1z94JmcMOgXe(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩஃ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ஄"))
	n7eguYlER0J5 = vGg1hAkzqi8exVbN(u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪஅ")
	from urllib.parse import quote as _IH9mXv75fCdFikBghQEbcxOV80sa
else:
	QI90vnGbT1LoPUNsxgecSZyV = Zz9SeICTbPksXy6nuOtLGWhN2V.translatePath(wFYiVd4r12x7CAQBL5SPof(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫஆ"))
	C8ik4xAOE2Y53qZRJy6nbUVm = Zz9SeICTbPksXy6nuOtLGWhN2V.translatePath(lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬஇ"))
	AvEeVqt3nSw2LHXQl8uFOKI5 = Zz9SeICTbPksXy6nuOtLGWhN2V.translatePath(JP65RzKaScIf(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩஈ"))
	HHgE1pqyiM4W5 = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஉ"),UixkloZbzGw28ujW56X(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩஊ"),JP65RzKaScIf(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭஋"))
	w7wy9hIDTUo1WNius = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,DKmLTA2yGtj(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ஌"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ஍"),NIBsHMvSXb(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫஎ"))
	LcUmF0zYN5j9uQB = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧஏ"),ZYTyoA483N(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨஐ"),vhZ5qjay1z94JmcMOgXe(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ஑"))
	n7eguYlER0J5 = UQS9lVew50DIyXrinWsMxTzA(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩஒ").encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	from urllib import quote as _IH9mXv75fCdFikBghQEbcxOV80sa
jKNw370SdFlQ = brAUlZfdFmt3TRJW2xX4.path.join(AvEeVqt3nSw2LHXQl8uFOKI5,UQS9lVew50DIyXrinWsMxTzA(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫஓ"))
FbSejdADVtON1rKaI = brAUlZfdFmt3TRJW2xX4.path.join(AvEeVqt3nSw2LHXQl8uFOKI5,yNBjYsgc23xoW(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩஔ"))
X40SOwL2ACtF1ZxgUhcv = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,E3i1eCBtN2w(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭க"))
K3cy6Wx8TGfJoREwnu59hj = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ykE045Tatx(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ஖"))
dVgLfY13X2 = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,vGg1hAkzqi8exVbN(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭஗"))
tJuIjTFl9cwGz2dishvoUm4SPK3ArB = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,vGg1hAkzqi8exVbN(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨ஘"))
FAYbRks1unjB9X0ITevptc4Z3 = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪங"))
w1wAdy5GghQiZKpzI = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪச"))
bhliCPq5mvAg19sIF = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,NIBsHMvSXb(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪ஛"))
xxARPUsiq6QGWKgZb3 = brAUlZfdFmt3TRJW2xX4.path.join(bhliCPq5mvAg19sIF,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬஜ"))
GZ9SnzDsABJW = brAUlZfdFmt3TRJW2xX4.path.join(bhliCPq5mvAg19sIF,ReLGYUQjz7C9iEd(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬ஝"))
S2apZTleKb6FXqd = brAUlZfdFmt3TRJW2xX4.path.join(xxARPUsiq6QGWKgZb3,vGg1hAkzqi8exVbN(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩஞ"))
SSWrcswxYdB9p = exMAFyUdlHcYb4RSk8I.Addon().getAddonInfo(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡱࡣࡷ࡬ࠬட"))
mG8Hh0MOdtnaxp5ZV7T1sLEfuI = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,yNBjYsgc23xoW(u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ஠"))
hq7O0pGjM9mI3kn21w6FxZ5BbHR = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,NIBsHMvSXb(u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬ஡"))
Bc2Y6ma40gobriNGXM5Vz1 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,JP65RzKaScIf(u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧ஢"))
shvIjdkx7EqaguJt2T = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨண"))
MnoqPIZtpaUNXueSL98YR = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,ee3tnwl7avk(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬத"))
B69ON2zrKsjmqcbUpv5 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,DKmLTA2yGtj(u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ஥"))
mtBEDO3U8uPl9YGVovyLJNH5s = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧ஦"))
Q0VcoPaDq4m8Jusrg5NFX = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,Vi1oNCM5kI7yJ0(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧ஧"))
MKA6jlwszI2LeWgqEQ = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,vGg1hAkzqi8exVbN(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩந"))
k5nIjDREtdlesKGUy = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,dn9ouNryjHiBFQOhASvX(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪன"))
VlhreQLGKx3zN = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,NIBsHMvSXb(u"ࠫࡦࡪࡤࡰࡰࡶࠫப"))
jtQuVIH1qNd6W7Mg0BYfULe5Zln = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ஫"),DKmLTA2yGtj(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ஬"),Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,eCpDE6wJtYUHn0GqK5(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭஭"))
E5ESVm9Qa6ruPLRDntWMz0sOXKfAd = brAUlZfdFmt3TRJW2xX4.path.join(QI90vnGbT1LoPUNsxgecSZyV,yNBjYsgc23xoW(u"ࠨ࡯ࡨࡨ࡮ࡧࠧம"),vGg1hAkzqi8exVbN(u"ࠩࡉࡳࡳࡺࡳࠨய"),dn9ouNryjHiBFQOhASvX(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭ர"))
JjS5I28PwBEaqWMFhYLUdR = vGg1hAkzqi8exVbN(u"࠺ፓ")
YOjp8EZx4D = [yNBjYsgc23xoW(u"ฺࠫ็ัࠨற"),ykE045Tatx(u"ࠬษ่ๅࠩல"),NIBsHMvSXb(u"࠭หศ่ํࠫள"),YXm2qAbu8Qsx(u"ࠧฬษ็ฯࠬழ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨำสฬ฾࠭வ"),IYC4iPxkTRUE85namF6(u"ࠩัหู๊ࠧஶ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪืฬีำࠨஷ"),eCpDE6wJtYUHn0GqK5(u"ุࠫอศฺࠩஸ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬัวๆ่ࠪஹ"),A2MHFvoqpZ64gNbB(u"࠭สศี฼ࠫ஺"),vhZ5qjay1z94JmcMOgXe(u"ฺࠧษืีࠬ஻")]
pRv3ziqwt6yI2CoY5c = ReLGYUQjz7C9iEd(u"ࠨ⸽ࠣ⼡ࠥ⸰ࠠ⸼ࠩ஼")
jeC3BTO5N4wSG = [ttC4VURALPYKh(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ஽")]
EEhfvO2rBnpjFA7KL4IqgiN = [vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡍࡋࡏࡌࡎࠩா"),yNBjYsgc23xoW(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪி"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬீ")]
EEhfvO2rBnpjFA7KL4IqgiN += [E3i1eCBtN2w(u"࠭ࡁࡌ࡙ࡄࡑࠬு"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩூ"),eCpDE6wJtYUHn0GqK5(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ௃"),vGg1hAkzqi8exVbN(u"ࠩࡄࡏࡔࡇࡍࠨ௄"),yNBjYsgc23xoW(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ௅")]
EEhfvO2rBnpjFA7KL4IqgiN += [okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧெ"),eCpDE6wJtYUHn0GqK5(u"ࠬࡈࡏࡌࡔࡄࠫே"),ReLGYUQjz7C9iEd(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫை"),x9PULjztJOpu7b(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ௉"),yyZPkLCRX1xcBDN(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪொ")]
Y4Os9hHdSzt078iG = [UixkloZbzGw28ujW56X(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬோ"),E3i1eCBtN2w(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫௌ"),yNBjYsgc23xoW(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ்ࠬ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ௎"),ee3tnwl7avk(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ௏"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩௐ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪ௑")]
Y4Os9hHdSzt078iG += [qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ௒"),ykE045Tatx(u"ࠪࡘ࡛ࡌࡕࡏࠩ௓"),UixkloZbzGw28ujW56X(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬ௔"),wFYiVd4r12x7CAQBL5SPof(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭௕"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ௖"),dn9ouNryjHiBFQOhASvX(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧௗ")]
ssIx2qYv3MTGinwt8kLhyF1Z7fD0oz = [UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ௘"),x9PULjztJOpu7b(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ௙"),YXm2qAbu8Qsx(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௚"),ykE045Tatx(u"ࠫࡋࡕࡓࡕࡃࠪ௛"),ZYTyoA483N(u"ࠬࡇࡈࡘࡃࡎࠫ௜"),E3i1eCBtN2w(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ௝"),eCpDE6wJtYUHn0GqK5(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ௞"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ௟"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࡙ࠩࡅࡗࡈࡏࡏࠩ௠"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧ௡")]
ssIx2qYv3MTGinwt8kLhyF1Z7fD0oz += [NIBsHMvSXb(u"ࠫࡘࡎࡏࡇࡊࡄࠫ௢"),eCpDE6wJtYUHn0GqK5(u"ࠬࡈࡒࡔࡖࡈࡎࠬ௣"),dn9ouNryjHiBFQOhASvX(u"࡙࠭ࡂࡓࡒࡘࠬ௤"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ௥"),ReLGYUQjz7C9iEd(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ௦"),NIBsHMvSXb(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ௧"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ௨"),vGg1hAkzqi8exVbN(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧ௩"),ZYTyoA483N(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭௪"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭௫"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨ௬")]
ssIx2qYv3MTGinwt8kLhyF1Z7fD0oz += [NIBsHMvSXb(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭௭"),ZYTyoA483N(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ௮"),JP65RzKaScIf(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫ௯"),E3i1eCBtN2w(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧ௰"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡚ࠬࡉࡌࡃࡄࡘࠬ௱"),ee3tnwl7avk(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩ௲"),x9PULjztJOpu7b(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩ௳"),E3i1eCBtN2w(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪ௴")]
ssIx2qYv3MTGinwt8kLhyF1Z7fD0oz += [ee3tnwl7avk(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭௵"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫ௶"),Vi1oNCM5kI7yJ0(u"ࠫࡆ࡟ࡌࡐࡎࠪ௷"),NIBsHMvSXb(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ௸"),YXm2qAbu8Qsx(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩ௹")]
xDTX5QSh9qm = [ttC4VURALPYKh(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ௺"),eCpDE6wJtYUHn0GqK5(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ௻"),YXm2qAbu8Qsx(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭௼"),ReLGYUQjz7C9iEd(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭௽")]
xDTX5QSh9qm += [NIBsHMvSXb(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ௾"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ௿"),lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧఀ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧఁ"),dn9ouNryjHiBFQOhASvX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬం"),ttC4VURALPYKh(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩః")]
xDTX5QSh9qm += [dn9ouNryjHiBFQOhASvX(u"ࠪࡍࡕ࡚ࡖࠨఄ"),ee3tnwl7avk(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧఅ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪఆ"),A2MHFvoqpZ64gNbB(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫఇ")]
xDTX5QSh9qm += [vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡎ࠵ࡘࠫఈ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪఉ"),ykE045Tatx(u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭ఊ"),yyZPkLCRX1xcBDN(u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧఋ")]
QTKNAkMztaih0o  = [vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡆࡑࡗࡂࡏࠪఌ"),x9PULjztJOpu7b(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ఍"),vhZ5qjay1z94JmcMOgXe(u"࠭ࡂࡐࡍࡕࡅࠬఎ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡂࡍࡒࡅࡒ࠭ఏ"),NIBsHMvSXb(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪఐ"),YXm2qAbu8Qsx(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ఑"),vGg1hAkzqi8exVbN(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬఒ"),wFYiVd4r12x7CAQBL5SPof(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ఓ"),ZYTyoA483N(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬఔ")]
QTKNAkMztaih0o += [vhZ5qjay1z94JmcMOgXe(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨక"),yNBjYsgc23xoW(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪఖ"),ReLGYUQjz7C9iEd(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩగ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪఘ"),ee3tnwl7avk(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫఙ"),ZYTyoA483N(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨచ"),JP65RzKaScIf(u"ࠬࡌࡏࡔࡖࡄࠫఛ"),qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡁࡉ࡙ࡄࡏࠬజ"),DKmLTA2yGtj(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩఝ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬఞ")]
QTKNAkMztaih0o += [yyZPkLCRX1xcBDN(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬట"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ఠ"),wFYiVd4r12x7CAQBL5SPof(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭డ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧఢ"),dn9ouNryjHiBFQOhASvX(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨణ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩత"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫథ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪద")]
QTKNAkMztaih0o += [NIBsHMvSXb(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫధ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭న"),Vi1oNCM5kI7yJ0(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ఩"),Vi1oNCM5kI7yJ0(u"࠭ࡔࡗࡈࡘࡒࠬప"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩఫ"),JP65RzKaScIf(u"ࠨࡕࡋࡓࡋࡎࡁࠨబ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"࡙ࠩࡅࡗࡈࡏࡏࠩభ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫమ")]
QTKNAkMztaih0o += [okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡇࡘࡓࡕࡇࡍࠫయ"),ttC4VURALPYKh(u"ࠬ࡟ࡁࡒࡑࡗࠫర"),IYC4iPxkTRUE85namF6(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧఱ"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨల"),ttC4VURALPYKh(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ళ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫఴ"),YXm2qAbu8Qsx(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬవ"),E3i1eCBtN2w(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫశ")]
QTKNAkMztaih0o += [vhZ5qjay1z94JmcMOgXe(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪష"),ttC4VURALPYKh(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨస"),DKmLTA2yGtj(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨహ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ఺"),eCpDE6wJtYUHn0GqK5(u"ࠩࡗࡍࡐࡇࡁࡕࠩ఻"),ee3tnwl7avk(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞఼࠭"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ఽ"),Vi1oNCM5kI7yJ0(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧా")]
JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr  = [eCpDE6wJtYUHn0GqK5(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫి"),DKmLTA2yGtj(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨీ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨు"),lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭ూ"),eCpDE6wJtYUHn0GqK5(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡊࡄࡗࡍ࡚ࡁࡈࡕࠪృ")]
JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr += [qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪౄ"),yyZPkLCRX1xcBDN(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ౅")]
JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr += [dn9ouNryjHiBFQOhASvX(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧె"),yNBjYsgc23xoW(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫే"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫై")]
JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr += [YXm2qAbu8Qsx(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ౉"),NIBsHMvSXb(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨొ"),JP65RzKaScIf(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩో")]
JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr += [zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧౌ"),JP65RzKaScIf(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕ్ࠪ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ౎")]
wDyJQ2Osov1G07Em3XqBMtICT = [OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡏ࠶࡙ࠬ౏"),A2MHFvoqpZ64gNbB(u"ࠩࡌࡔ࡙࡜ࠧ౐"),ttC4VURALPYKh(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ౑"),YXm2qAbu8Qsx(u"ࠫࡎࡌࡉࡍࡏࠪ౒"),yNBjYsgc23xoW(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭౓")]
o9tYLx4qFuPG = QTKNAkMztaih0o+JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr
LRS4BMJz10XF2s7ghtmvwVofr = QTKNAkMztaih0o+wDyJQ2Osov1G07Em3XqBMtICT
h97Pjsutv1rcV4zekJX = QTKNAkMztaih0o+JbqwgHvd5YoSnVi9yFZAMG8fU3xRzr+jeC3BTO5N4wSG
FtIMQicPuz4ZHJAW = [yNBjYsgc23xoW(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧ౔")]+EEhfvO2rBnpjFA7KL4IqgiN+[qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡎࡋ࡛ࡉࡉౕ࠭")]+Y4Os9hHdSzt078iG+[lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡒࡘࡆࡑࡏࡃࠨౖ")]+ssIx2qYv3MTGinwt8kLhyF1Z7fD0oz+[UixkloZbzGw28ujW56X(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪ౗")]+xDTX5QSh9qm
KfBl67yc98 = [yNBjYsgc23xoW(u"ࠪࡅࡐࡕࡁࡎࠩౘ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡆࡑࡗࡂࡏࠪౙ"),x9PULjztJOpu7b(u"ࠬࡏࡆࡊࡎࡐࠫౚ"),ykE045Tatx(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ౛"),IYC4iPxkTRUE85namF6(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ౜"),yNBjYsgc23xoW(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪౝ"),ReLGYUQjz7C9iEd(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ౞"),YXm2qAbu8Qsx(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ౟"),ee3tnwl7avk(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩౠ"),ZYTyoA483N(u"ࠬࡓ࠳ࡖࠩౡ"),yNBjYsgc23xoW(u"࠭ࡉࡑࡖ࡙ࠫౢ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡃࡑࡎࡖࡆ࠭ౣ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ౤"),ZYTyoA483N(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ౥")]
NOT_TO_TEST_ALL_SERVERS = [okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡣࡆࡑࡏࡠࠩ౦"),UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡤࡇࡋࡘࡡࠪ౧"),x9PULjztJOpu7b(u"ࠬࡥࡉࡇࡎࡢࠫ౨"),wFYiVd4r12x7CAQBL5SPof(u"࠭࡟ࡌࡔࡅࡣࠬ౩"),vGg1hAkzqi8exVbN(u"ࠧࡠࡏࡕࡊࡤ࠭౪"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡡࡖࡌࡒࡥࠧ౫"),vGg1hAkzqi8exVbN(u"ࠩࡢࡗࡍ࡜࡟ࠨ౬"),YXm2qAbu8Qsx(u"ࠪࡣ࡞࡛ࡔࡠࠩ౭"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡤࡊࡌࡎࡡࠪ౮"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡥࡍࡖࠩ౯"),YXm2qAbu8Qsx(u"࠭࡟ࡊࡒࠪ౰"),UixkloZbzGw28ujW56X(u"ࠧࡠࡄࡎࡖࡤ࠭౱"),NIBsHMvSXb(u"ࠨࡡࡈࡐࡈࡥࠧ౲"),ttC4VURALPYKh(u"ࠩࡢࡅࡗ࡚࡟ࠨ౳")]
bGgOREuAIUNyd5 = [
						Vi1oNCM5kI7yJ0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ౴")
						,UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭౵")
						,vGg1hAkzqi8exVbN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭౶")
						]
JqgcndNGI5W493ZRh = [
						IYC4iPxkTRUE85namF6(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚ࡓ࠮࠳ࡶࡸࠬ౷")
						,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ౸")
						,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ౹")
						,vhZ5qjay1z94JmcMOgXe(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ౺")
						,x9PULjztJOpu7b(u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ౻")
						,ZYTyoA483N(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ౼")
						,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ౽")
						,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ౾")
						,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ౿")
						,lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬಀ")
						,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩಁ")
						,dn9ouNryjHiBFQOhASvX(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪಂ")
						,JP65RzKaScIf(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪಃ")
						,yNBjYsgc23xoW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ಄")
						,DKmLTA2yGtj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨಅ")
						]
NvZXA76fYQWekDjhVFr0O2UiIdHxL = JqgcndNGI5W493ZRh+[
				 UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩಆ")
				,JP65RzKaScIf(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಇ")
				,vGg1hAkzqi8exVbN(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಈ")
				,E3i1eCBtN2w(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭ಉ")
				,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧಊ")
				,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨಋ")
				,dn9ouNryjHiBFQOhASvX(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨಌ")
				,DKmLTA2yGtj(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩ಍")
				,wFYiVd4r12x7CAQBL5SPof(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪಎ")
				,yNBjYsgc23xoW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಏ")
				,ykE045Tatx(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ಐ")
				,Vi1oNCM5kI7yJ0(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧ಑")
				,qdEKO42r3GhwmCDcHtxzJUR(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨಒ")
				,eCpDE6wJtYUHn0GqK5(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫಓ")
				,ttC4VURALPYKh(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨಔ")
				,UixkloZbzGw28ujW56X(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪಕ")
				]
JYCuTUrNh3 = [Vi1oNCM5kI7yJ0(u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪಖ"),DKmLTA2yGtj(u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫಗ"),x9PULjztJOpu7b(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬಘ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ಙ"),DKmLTA2yGtj(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧಚ"),YXm2qAbu8Qsx(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨಛ")]
PhpFa6EdVS = {
			 JP65RzKaScIf(u"ࠨࡃࡋ࡛ࡆࡑࠧಜ")		:[JP65RzKaScIf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫಝ")]
			,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡅࡐࡕࡁࡎࠩಞ")		:[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨಟ")]
			,yNBjYsgc23xoW(u"ࠬࡇࡋࡘࡃࡐࠫಠ")		:[jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭ಡ")]
			,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪಢ")	:[YXm2qAbu8Qsx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨಣ")]
			,DKmLTA2yGtj(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫತ")		:[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩಥ")]
			,IYC4iPxkTRUE85namF6(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬದ")		:[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡳࡳࡵࡤࡤ࠲ࡹࡼࠧಧ")]
			,DKmLTA2yGtj(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨನ")		:[DKmLTA2yGtj(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱ࡭ࡲ࡫ࡺࡪࡦ࠱ࡷ࡭ࡵࡷࠨ಩")]
			,UixkloZbzGw28ujW56X(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ಪ")	:[E3i1eCBtN2w(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩಫ")]
			,qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬಬ")		:[DKmLTA2yGtj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫಭ")]
			,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡇ࡙ࡍࡑࡏࠫಮ")		:[vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧ࠱ࡥࡾࡲ࡯࡭࠰ࡱࡩࡹ࠭ಯ")]
			,yNBjYsgc23xoW(u"ࠧࡃࡑࡎࡖࡆ࠭ರ")		:[eCpDE6wJtYUHn0GqK5(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧಱ")]
			,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩಲ")		:[IYC4iPxkTRUE85namF6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨಳ")]
			,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ಴")		:[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫವ")]
			,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ಶ")		:[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧಷ")]
			,vhZ5qjay1z94JmcMOgXe(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨಸ")		:[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨಹ")]
			,ReLGYUQjz7C9iEd(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ಺")		:[ttC4VURALPYKh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ಻")]
			,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ಼ࠧ")		:[ZYTyoA483N(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡥࡹࡩࡨࠨಽ")]
			,yNBjYsgc23xoW(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ಾ")	:[JP65RzKaScIf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭ಿ")]
			,dn9ouNryjHiBFQOhASvX(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫೀ")		:[ZYTyoA483N(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧು")]
			,UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ೂ")		:[UixkloZbzGw28ujW56X(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡪࡷ࡫ࡥ࠯ࡸ࡬ࡴࠬೃ")]
			,YXm2qAbu8Qsx(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩೄ")	:[E3i1eCBtN2w(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠻࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶ࠲ࡱࡾࡩ࠱ࠨ೅")]
			,ttC4VURALPYKh(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩೆ")		:[ttC4VURALPYKh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧೇ")]
			,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬೈ")		:[lU1fSmncFWjizwqZugyYBANML0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡺࡦࡦࡹ࠮࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪ೉")]
			,Vi1oNCM5kI7yJ0(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪೊ")	:[ZYTyoA483N(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ೋ"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨೌ")]
			,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈ್ࠫ")	:[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠻࠮ࡥࡴࡤࡱࡦࡩࡡࡧࡧ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ೎")]
			,E3i1eCBtN2w(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ೏")		:[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡣ࠯ࡦࡵࡥࡲࡧࡳ࠸࠰ࡦࡳࡲ࠭೐")]
			,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ೑")		:[ReLGYUQjz7C9iEd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡨࡸࡲࠬ೒")]
			,ZYTyoA483N(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ೓")		:[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡻࡪࡨࡣࡢ࡯ࠪ೔")]
			,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫೕ")		:[yyZPkLCRX1xcBDN(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪೖ")]
			,NIBsHMvSXb(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭೗")		:[ZYTyoA483N(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ೘")]
			,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ೙")		:[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ೚")]
			,UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ೛")		:[IYC4iPxkTRUE85namF6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ೜")]
			,UixkloZbzGw28ujW56X(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ೝ")	:[yNBjYsgc23xoW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠳࡫࡬ࡪࡨ࠱ࡲࡪࡽࡳࠨೞ")]
			,vGg1hAkzqi8exVbN(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭೟")		:[NIBsHMvSXb(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫೠ")]
			,yNBjYsgc23xoW(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪೡ")	:[KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭ೢ")]
			,ZYTyoA483N(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪೣ")		:[IYC4iPxkTRUE85namF6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡰ࠯ࡨࡤࡶࡪࡹ࡫ࡰ࠰ࡱࡩࡹ࠭೤")]
			,ZYTyoA483N(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭೥")		:[dn9ouNryjHiBFQOhASvX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫ೦")]
			,ZYTyoA483N(u"࠭ࡆࡐࡕࡗࡅࠬ೧")		:[yNBjYsgc23xoW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫ೨")]
			,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩ೩")		:[E3i1eCBtN2w(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࠳ࡧ࡬࡮ࡧࡶ࡬ࡰࡧࡨ࠯ࡰࡨࡸࠬ೪")]
			,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬ೫")		:[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨ࠮ࡧࡷࡶ࡬ࡦࡸ࠭ࡵࡸ࠱ࡧࡴࡳࠧ೬")]
			,vhZ5qjay1z94JmcMOgXe(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ೭")	:[IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡩࡹࡸ࡮ࡡࡳ࠰ࡹ࡭ࡩ࡫࡯ࠨ೮")]
			,IYC4iPxkTRUE85namF6(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ೯")		:[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪ೰")]
			,vhZ5qjay1z94JmcMOgXe(u"ࠩࡌࡊࡎࡒࡍࠨೱ")		:[E3i1eCBtN2w(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫೲ"),ReLGYUQjz7C9iEd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬೳ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭೴"),ykE045Tatx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ೵"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧ೶")]
			,eCpDE6wJtYUHn0GqK5(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ೷")	:[ykE045Tatx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪ೸")]
			,yyZPkLCRX1xcBDN(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ೹")		:[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࡯ࡰ࠰࡮࡭ࡹࡱ࡯ࡵ࠰ࡷࡺࠬ೺")]
			,ee3tnwl7avk(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭೻")		:[ttC4VURALPYKh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡷ࠱࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡨࡵ࡭ࠨ೼")]
			,eCpDE6wJtYUHn0GqK5(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭೽")	:[Vi1oNCM5kI7yJ0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ೾"),E3i1eCBtN2w(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ೿")]
			,DKmLTA2yGtj(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪഀ")		:[ZYTyoA483N(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮ࡧࡱࠪഁ")]
			,eCpDE6wJtYUHn0GqK5(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ം")		:[DKmLTA2yGtj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭ഃ")]
			,ttC4VURALPYKh(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪഄ")	:[ee3tnwl7avk(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡢࡵࡤࡺ࡮ࡪࡥࡰ࠰ࡱࡩࡼࡹࠧഅ")]
			,NIBsHMvSXb(u"ࠩࡓࡅࡓࡋࡔࠨആ")		:[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬഇ")]
			,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ഈ")		:[ZYTyoA483N(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡕࡌࡅ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ഉ")]
			,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪഊ")	:[DKmLTA2yGtj(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬഋ")]
			,JP65RzKaScIf(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫഌ")	:[qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥ࠳࡙ࡈࡂࡄࡄࡏࡆ࡚࡙࠯ࡸ࡬ࡴࠬ഍")]
			,ykE045Tatx(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬഎ")		:[UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡦࡦ࠷ࡹ࠷࠴ࡣࡰ࡯ࠪഏ")]
			,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩഐ")	:[JP65RzKaScIf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ഑")]
			,wFYiVd4r12x7CAQBL5SPof(u"ࠧࡔࡊࡒࡊࡍࡇࠧഒ")		:[ykE045Tatx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡳࡩࡱࡩ࡬ࡦ࠴ࡴࡷࠩഓ")]
			,vGg1hAkzqi8exVbN(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫഔ")		:[YXm2qAbu8Qsx(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪക"),yyZPkLCRX1xcBDN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫഖ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨഗ")]
			,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨഘ")		:[vGg1hAkzqi8exVbN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨങ")]
			,x9PULjztJOpu7b(u"ࠨࡖࡌࡏࡆࡇࡔࠨച")		:[YXm2qAbu8Qsx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡵ࡫࡮ࡥࡦࡺ࠮࡯ࡧࡷࠫഛ")]
			,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡘ࡛ࡌࡕࡏࠩജ")		:[IYC4iPxkTRUE85namF6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩഝ")]
			,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬഞ")		:[x9PULjztJOpu7b(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ട")]
			,ykE045Tatx(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫഠ")	:[E3i1eCBtN2w(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫഡ")]
			,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪഢ")		:[ZYTyoA483N(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡸ࡮࡯ࡸࠩണ")]
			,x9PULjztJOpu7b(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬത")		:[Vi1oNCM5kI7yJ0(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡣ࡭࡫ࡦ࡯ࠬഥ")]
			,IYC4iPxkTRUE85namF6(u"࡙࠭ࡂࡓࡒࡘࠬദ")		:[JP65RzKaScIf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬധ")]
			,DKmLTA2yGtj(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩന")		:[IYC4iPxkTRUE85namF6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬഩ")]
			,yNBjYsgc23xoW(u"ࠪࡖࡊࡖࡏࡔࠩപ")		:[ee3tnwl7avk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫഫ"),vhZ5qjay1z94JmcMOgXe(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩബ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪഭ")]
			,NIBsHMvSXb(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪമ")	:[yNBjYsgc23xoW(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭യ"),IYC4iPxkTRUE85namF6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫര"),dn9ouNryjHiBFQOhASvX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬറ")]
			,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬല")		:[E3i1eCBtN2w(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬള"),YXm2qAbu8Qsx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫ࠫഴ"),eCpDE6wJtYUHn0GqK5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪവ")]
			}
if Mn5NGAdz6xc42s0:
	PhpFa6EdVS[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨശ")] = [jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫഷ"),ee3tnwl7avk(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨസ"),YXm2qAbu8Qsx(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧഹ"),ReLGYUQjz7C9iEd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪഺ"),dn9ouNryjHiBFQOhASvX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥ഻ࠪ"),yyZPkLCRX1xcBDN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ഼࠭"),yyZPkLCRX1xcBDN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩഽ"),E3i1eCBtN2w(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡦࡥࡵࡺࡣࡩࡣࠪാ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡸࡪࡹࡴࡪࡰࡪࠫി"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩീ")]
	PhpFa6EdVS[IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩു")] = [vhZ5qjay1z94JmcMOgXe(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩൂ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ൃ"),ykE045Tatx(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬൄ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ൅"),IYC4iPxkTRUE85namF6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨെ"),ttC4VURALPYKh(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫേ"),wFYiVd4r12x7CAQBL5SPof(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧൈ"),wFYiVd4r12x7CAQBL5SPof(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ൉"),lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩൊ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧോ")]
else:
	PhpFa6EdVS[IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩൌ")] = [qdEKO42r3GhwmCDcHtxzJUR(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ്࠭"),ee3tnwl7avk(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪൎ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൏"),vhZ5qjay1z94JmcMOgXe(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ൐"),x9PULjztJOpu7b(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ൑"),UixkloZbzGw28ujW56X(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ൒"),ttC4VURALPYKh(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ൓"),IYC4iPxkTRUE85namF6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬൔ"),ReLGYUQjz7C9iEd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ൕ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫൖ")]
	PhpFa6EdVS[dn9ouNryjHiBFQOhASvX(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪൗ")] = [IYC4iPxkTRUE85namF6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ൘"),A2MHFvoqpZ64gNbB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ൙"),yNBjYsgc23xoW(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭൚"),JP65RzKaScIf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ൛"),dn9ouNryjHiBFQOhASvX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ൜"),ReLGYUQjz7C9iEd(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ൝"),UixkloZbzGw28ujW56X(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ൞"),A2MHFvoqpZ64gNbB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩൟ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪൠ"),ttC4VURALPYKh(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨൡ")]
Wbng8KmUpcXyOYNSGA = [x9PULjztJOpu7b(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬൢ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬൣ"),ReLGYUQjz7C9iEd(u"ࠬࡋࡍࡂࡋࡏࡗࠬ൤"),ZYTyoA483N(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ൥"),JP65RzKaScIf(u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩ൦"),dn9ouNryjHiBFQOhASvX(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ൧"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧ൨"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫ൩"),lU1fSmncFWjizwqZugyYBANML0(u"࡙ࠫࡋࡓࡕࡋࡑࡋࠬ൪"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧ൫")]
a6lEryZVzDACc1JixeFqnT35 = [YXm2qAbu8Qsx(u"࠭ࡁࡅࡆࡒࡒࡘ࠭൬"),ZYTyoA483N(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩ൭"),UixkloZbzGw28ujW56X(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪ൮")]
class depOPtkK89z6f1VL(j9ldCL3Ibp):
	def __init__(aFldbEymq0z6HUQcXK7Cr51,*aargs,**kkwargs):
		aFldbEymq0z6HUQcXK7Cr51.choiceID = -Mn5NGAdz6xc42s0
	def onClick(aFldbEymq0z6HUQcXK7Cr51,nTWiuejGKAbV7sxXIDZyNqmUE):
		if nTWiuejGKAbV7sxXIDZyNqmUE>=E3i1eCBtN2w(u"࠿࠰࠲࠲ፔ"): aFldbEymq0z6HUQcXK7Cr51.choiceID = nTWiuejGKAbV7sxXIDZyNqmUE-E3i1eCBtN2w(u"࠿࠰࠲࠲ፔ")
		aFldbEymq0z6HUQcXK7Cr51.WNzxEJUAd9abSh64iR1OTGQc7vY()
	def SH9WIXJluRvjQ7(aFldbEymq0z6HUQcXK7Cr51,*aargs):
		aFldbEymq0z6HUQcXK7Cr51.button0,aFldbEymq0z6HUQcXK7Cr51.button1,aFldbEymq0z6HUQcXK7Cr51.button2 = aargs[UwCT5Oz6Wo0BP],aargs[Mn5NGAdz6xc42s0],aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		aFldbEymq0z6HUQcXK7Cr51.header,aFldbEymq0z6HUQcXK7Cr51.text = aargs[O4dklMvZ8ULcS],aargs[NEc173Pr0jAwLF5OS]
		aFldbEymq0z6HUQcXK7Cr51.profile,aFldbEymq0z6HUQcXK7Cr51.direction = aargs[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠵ፕ")],aargs[KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠷ፖ")]
		aFldbEymq0z6HUQcXK7Cr51.buttonstimeout,aFldbEymq0z6HUQcXK7Cr51.closetimeout = aargs[lU1fSmncFWjizwqZugyYBANML0(u"࠺ፘ")],aargs[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠺ፗ")]
		if aFldbEymq0z6HUQcXK7Cr51.buttonstimeout>UwCT5Oz6Wo0BP or aFldbEymq0z6HUQcXK7Cr51.closetimeout>qdEKO42r3GhwmCDcHtxzJUR(u"࠴ፙ"): aFldbEymq0z6HUQcXK7Cr51.enable_progressbar = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		else: aFldbEymq0z6HUQcXK7Cr51.enable_progressbar = vvglE69OFKBm817Nkc
		aFldbEymq0z6HUQcXK7Cr51.image_filename = S2apZTleKb6FXqd.replace(UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ൯"),vGg1hAkzqi8exVbN(u"ࠪࡣࠬ൰")+str(LNma2eq3vEguwVtHjn.time())+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡤ࠭൱"))
		aFldbEymq0z6HUQcXK7Cr51.image_filename = aFldbEymq0z6HUQcXK7Cr51.image_filename.replace(Vi1oNCM5kI7yJ0(u"ࠬࡢ࡜ࠨ൲"),E3i1eCBtN2w(u"࠭࡜࡝࡞࡟ࠫ൳")).replace(DKmLTA2yGtj(u"ࠧ࠰࠱ࠪ൴"),dn9ouNryjHiBFQOhASvX(u"ࠨ࠱࠲࠳࠴࠭൵"))
		aFldbEymq0z6HUQcXK7Cr51.image_height = BEf8XIaMFVmj(aFldbEymq0z6HUQcXK7Cr51.button0,aFldbEymq0z6HUQcXK7Cr51.button1,aFldbEymq0z6HUQcXK7Cr51.button2,aFldbEymq0z6HUQcXK7Cr51.header,aFldbEymq0z6HUQcXK7Cr51.text,aFldbEymq0z6HUQcXK7Cr51.profile,aFldbEymq0z6HUQcXK7Cr51.direction,aFldbEymq0z6HUQcXK7Cr51.enable_progressbar,aFldbEymq0z6HUQcXK7Cr51.image_filename)
		aFldbEymq0z6HUQcXK7Cr51.show()
		aFldbEymq0z6HUQcXK7Cr51.getControl(IYC4iPxkTRUE85namF6(u"࠾࠶࠵࠱ፚ")).setImage(aFldbEymq0z6HUQcXK7Cr51.image_filename)
		aFldbEymq0z6HUQcXK7Cr51.getControl(x9PULjztJOpu7b(u"࠿࠰࠶࠲፛")).setHeight(aFldbEymq0z6HUQcXK7Cr51.image_height)
		if not aFldbEymq0z6HUQcXK7Cr51.button1 and aFldbEymq0z6HUQcXK7Cr51.button0 and aFldbEymq0z6HUQcXK7Cr51.button2: aFldbEymq0z6HUQcXK7Cr51.getControl(UQS9lVew50DIyXrinWsMxTzA(u"࠺࠲࠴࠶፝")).setPosition(-dn9ouNryjHiBFQOhASvX(u"࠴࠵࠴፞"),ee3tnwl7avk(u"࠰፜"))
		return aFldbEymq0z6HUQcXK7Cr51.image_filename,aFldbEymq0z6HUQcXK7Cr51.image_height
	def U6luJCR92Z(aFldbEymq0z6HUQcXK7Cr51):
		if aFldbEymq0z6HUQcXK7Cr51.buttonstimeout:
			aFldbEymq0z6HUQcXK7Cr51.th1 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=aFldbEymq0z6HUQcXK7Cr51.slQPr3JXkjIxRhNecUWLTZ,args=())
			aFldbEymq0z6HUQcXK7Cr51.th1.start()
		else: aFldbEymq0z6HUQcXK7Cr51.aVrCHowxFqzMSm()
	def slQPr3JXkjIxRhNecUWLTZ(aFldbEymq0z6HUQcXK7Cr51):
		aFldbEymq0z6HUQcXK7Cr51.getControl(UixkloZbzGw28ujW56X(u"࠼࠴࠷࠶፟")).setEnabled(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		for OEJ3PT81KtbZ in range(Mn5NGAdz6xc42s0,aFldbEymq0z6HUQcXK7Cr51.buttonstimeout+Mn5NGAdz6xc42s0):
			LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
			ctS6TQCuqen9Iixo = int(IYC4iPxkTRUE85namF6(u"࠵࠵࠶፠")*OEJ3PT81KtbZ/aFldbEymq0z6HUQcXK7Cr51.buttonstimeout)
			aFldbEymq0z6HUQcXK7Cr51.IOXHdz7qRx49uViysjSwaovmtYh0(ctS6TQCuqen9Iixo)
			if aFldbEymq0z6HUQcXK7Cr51.choiceID>ykE045Tatx(u"࠵፡"): break
		aFldbEymq0z6HUQcXK7Cr51.aVrCHowxFqzMSm()
	def ggZMBER2JG(aFldbEymq0z6HUQcXK7Cr51):
		if aFldbEymq0z6HUQcXK7Cr51.closetimeout:
			aFldbEymq0z6HUQcXK7Cr51.th2 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=aFldbEymq0z6HUQcXK7Cr51.XHL5AIjcTSGPDKpqkYgQW189VROywx,args=())
			aFldbEymq0z6HUQcXK7Cr51.th2.start()
		else: aFldbEymq0z6HUQcXK7Cr51.aVrCHowxFqzMSm()
	def XHL5AIjcTSGPDKpqkYgQW189VROywx(aFldbEymq0z6HUQcXK7Cr51):
		aFldbEymq0z6HUQcXK7Cr51.getControl(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠿࠰࠳࠲።")).setEnabled(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		LNma2eq3vEguwVtHjn.sleep(aFldbEymq0z6HUQcXK7Cr51.buttonstimeout)
		for OEJ3PT81KtbZ in range(aFldbEymq0z6HUQcXK7Cr51.closetimeout-Mn5NGAdz6xc42s0,-Mn5NGAdz6xc42s0,-Mn5NGAdz6xc42s0):
			LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
			ctS6TQCuqen9Iixo = int(UixkloZbzGw28ujW56X(u"࠱࠱࠲፣")*OEJ3PT81KtbZ/aFldbEymq0z6HUQcXK7Cr51.closetimeout)
			aFldbEymq0z6HUQcXK7Cr51.IOXHdz7qRx49uViysjSwaovmtYh0(ctS6TQCuqen9Iixo)
			if aFldbEymq0z6HUQcXK7Cr51.choiceID>UwCT5Oz6Wo0BP: break
		if aFldbEymq0z6HUQcXK7Cr51.closetimeout>UwCT5Oz6Wo0BP: aFldbEymq0z6HUQcXK7Cr51.choiceID = YXm2qAbu8Qsx(u"࠲࠲፤")
		aFldbEymq0z6HUQcXK7Cr51.WNzxEJUAd9abSh64iR1OTGQc7vY()
	def IOXHdz7qRx49uViysjSwaovmtYh0(aFldbEymq0z6HUQcXK7Cr51,ctS6TQCuqen9Iixo):
		aFldbEymq0z6HUQcXK7Cr51.precent = ctS6TQCuqen9Iixo
		aFldbEymq0z6HUQcXK7Cr51.getControl(dn9ouNryjHiBFQOhASvX(u"࠻࠳࠶࠵፥")).setPercent(aFldbEymq0z6HUQcXK7Cr51.precent)
	def aVrCHowxFqzMSm(aFldbEymq0z6HUQcXK7Cr51):
		if aFldbEymq0z6HUQcXK7Cr51.button0: aFldbEymq0z6HUQcXK7Cr51.getControl(A2MHFvoqpZ64gNbB(u"࠼࠴࠶࠶፦")).setEnabled(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		if aFldbEymq0z6HUQcXK7Cr51.button1: aFldbEymq0z6HUQcXK7Cr51.getControl(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠽࠵࠷࠱፧")).setEnabled(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		if aFldbEymq0z6HUQcXK7Cr51.button2: aFldbEymq0z6HUQcXK7Cr51.getControl(ReLGYUQjz7C9iEd(u"࠾࠶࠱࠳፨")).setEnabled(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	def WNzxEJUAd9abSh64iR1OTGQc7vY(aFldbEymq0z6HUQcXK7Cr51):
		aFldbEymq0z6HUQcXK7Cr51.close()
		try: brAUlZfdFmt3TRJW2xX4.remove(aFldbEymq0z6HUQcXK7Cr51.image_filename)
		except: pass
class fZLqV6xaCWsTItK2ngd():
	def __init__(aFldbEymq0z6HUQcXK7Cr51,showDialogs=vvglE69OFKBm817Nkc,logErrors=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
		aFldbEymq0z6HUQcXK7Cr51.showDialogs = showDialogs
		aFldbEymq0z6HUQcXK7Cr51.logErrors = logErrors
		aFldbEymq0z6HUQcXK7Cr51.finishedLIST,aFldbEymq0z6HUQcXK7Cr51.failedLIST = [],[]
		aFldbEymq0z6HUQcXK7Cr51.statusDICT,aFldbEymq0z6HUQcXK7Cr51.resultsDICT = {},{}
		aFldbEymq0z6HUQcXK7Cr51.processesLIST = []
		aFldbEymq0z6HUQcXK7Cr51.starttimeDICT,aFldbEymq0z6HUQcXK7Cr51.finishtimeDICT,aFldbEymq0z6HUQcXK7Cr51.elpasedtimeDICT = {},{},{}
	def lePMc1NbnJFjD4Rpt0Ew2fS3Zv9X(aFldbEymq0z6HUQcXK7Cr51,CsPNhF9RD27K8GlcMOVZHq,HhuDp632En59S,*aargs):
		CsPNhF9RD27K8GlcMOVZHq = str(CsPNhF9RD27K8GlcMOVZHq)
		aFldbEymq0z6HUQcXK7Cr51.statusDICT[CsPNhF9RD27K8GlcMOVZHq] = qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ൶")
		if aFldbEymq0z6HUQcXK7Cr51.showDialogs: ZXWeI01flR(Zg9FeADE84jSRIvPCrzYulw3sL,CsPNhF9RD27K8GlcMOVZHq)
		CeD3lAx2yJsohLZSVTBpWq = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=aFldbEymq0z6HUQcXK7Cr51.QxfelTtES8G9MNzcLIXR4ubBA,args=(CsPNhF9RD27K8GlcMOVZHq,HhuDp632En59S,aargs))
		aFldbEymq0z6HUQcXK7Cr51.processesLIST.append(CeD3lAx2yJsohLZSVTBpWq)
		return CeD3lAx2yJsohLZSVTBpWq
	def FHEp9T3OzwUf6BSq(aFldbEymq0z6HUQcXK7Cr51,CsPNhF9RD27K8GlcMOVZHq,HhuDp632En59S,*aargs):
		CeD3lAx2yJsohLZSVTBpWq = aFldbEymq0z6HUQcXK7Cr51.lePMc1NbnJFjD4Rpt0Ew2fS3Zv9X(CsPNhF9RD27K8GlcMOVZHq,HhuDp632En59S,*aargs)
		CeD3lAx2yJsohLZSVTBpWq.start()
	def QxfelTtES8G9MNzcLIXR4ubBA(aFldbEymq0z6HUQcXK7Cr51,CsPNhF9RD27K8GlcMOVZHq,HhuDp632En59S,aargs):
		CsPNhF9RD27K8GlcMOVZHq = str(CsPNhF9RD27K8GlcMOVZHq)
		aFldbEymq0z6HUQcXK7Cr51.starttimeDICT[CsPNhF9RD27K8GlcMOVZHq] = LNma2eq3vEguwVtHjn.time()
		try:
			aFldbEymq0z6HUQcXK7Cr51.resultsDICT[CsPNhF9RD27K8GlcMOVZHq] = HhuDp632En59S(*aargs)
			if ee3tnwl7avk(u"ࠪࡓࡕࡋࡎࡖࡔࡏࠫ൷") in str(HhuDp632En59S) and not aFldbEymq0z6HUQcXK7Cr51.resultsDICT[CsPNhF9RD27K8GlcMOVZHq].succeeded: KVirvJ58C1PjHyxel6FdwX()
			aFldbEymq0z6HUQcXK7Cr51.finishedLIST.append(CsPNhF9RD27K8GlcMOVZHq)
			aFldbEymq0z6HUQcXK7Cr51.statusDICT[CsPNhF9RD27K8GlcMOVZHq] = ZYTyoA483N(u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩ࠭൸")
		except Exception as JJyYREVW7k:
			if aFldbEymq0z6HUQcXK7Cr51.logErrors:
				o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
				if o4be19ApMtCrdf5!=vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ൹"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
			aFldbEymq0z6HUQcXK7Cr51.failedLIST.append(CsPNhF9RD27K8GlcMOVZHq)
			aFldbEymq0z6HUQcXK7Cr51.statusDICT[CsPNhF9RD27K8GlcMOVZHq] = lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ൺ")
		aFldbEymq0z6HUQcXK7Cr51.finishtimeDICT[CsPNhF9RD27K8GlcMOVZHq] = LNma2eq3vEguwVtHjn.time()
		aFldbEymq0z6HUQcXK7Cr51.elpasedtimeDICT[CsPNhF9RD27K8GlcMOVZHq] = aFldbEymq0z6HUQcXK7Cr51.finishtimeDICT[CsPNhF9RD27K8GlcMOVZHq] - aFldbEymq0z6HUQcXK7Cr51.starttimeDICT[CsPNhF9RD27K8GlcMOVZHq]
	def UwDZ90FbNYM8lQ3Cxh7(aFldbEymq0z6HUQcXK7Cr51):
		for t0tnfbmTohLaFP7JMDVZEX2 in aFldbEymq0z6HUQcXK7Cr51.processesLIST:
			t0tnfbmTohLaFP7JMDVZEX2.start()
	def TTOUZjShNc(aFldbEymq0z6HUQcXK7Cr51):
		while JP65RzKaScIf(u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨൻ") in list(aFldbEymq0z6HUQcXK7Cr51.statusDICT.values()): LNma2eq3vEguwVtHjn.sleep(UixkloZbzGw28ujW56X(u"࠷፩"))
def wwAHCjJm2GFhBNpbyZcefr3dDO():
	if not c7cZwUErDWgMbzvl51CVfsXYReA: return yyZPkLCRX1xcBDN(u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫർ")
	try: brAUlZfdFmt3TRJW2xX4.makedirs(cc6p0YbTjFzgyG3aRw)
	except: pass
	PIzFDc8MU9js = lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧൽ")
	oodKZezFLIjsc3WBvSu06OlqGQN1 = [ee3tnwl7avk(u"ࠪ࠼࠳࠻࠮࠱ࠩൾ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࠷࠶࠲࠲࠰࠴࠴࠳࠷࠹ࠨൿ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠸࠰࠳࠳࠱࠵࠶࠴࠲࠵ࡣࠪ඀"),vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠲࠱࠴࠴࠲࠶࠸࠮࠴࠲ࠪඁ"),DKmLTA2yGtj(u"ࠧ࠳࠲࠵࠶࠳࠶࠲࠯࠲࠵ࠫං"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨ࠴࠳࠶࠷࠴࠱࠱࠰࠵࠶ࠬඃ"),vGg1hAkzqi8exVbN(u"ࠩ࠵࠴࠷࠹࠮࠱࠵࠱࠴࠻࠭඄"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪ࠶࠵࠸࠳࠯࠲࠸࠲࠶࠼ࠧඅ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫ࠷࠶࠲࠴࠰࠳࠺࠳࠶࠶ࠨආ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠬ࠸࠰࠳࠵࠱࠵࠵࠴࠲࠹ࠩඇ"),ZYTyoA483N(u"࠭࠲࠱࠴࠷࠲࠵࠷࠮࠲࠶ࠪඈ"),IYC4iPxkTRUE85namF6(u"ࠧ࠳࠲࠵࠸࠳࠶࠷࠯࠴࠳ࠫඉ")]
	RZDtIyCHv5w6MVkUjuO7nc = oodKZezFLIjsc3WBvSu06OlqGQN1[-Mn5NGAdz6xc42s0]
	rkUD7chBaW61oNxnest0KFq = xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(RZDtIyCHv5w6MVkUjuO7nc)
	Y394XTAufZKnkFViod = xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(kI8qwbo6yER)
	if Y394XTAufZKnkFViod>rkUD7chBaW61oNxnest0KFq:
		PIzFDc8MU9js = vGg1hAkzqi8exVbN(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨඊ")
	return PIzFDc8MU9js
def n24ICdioEj7vsUJmhWgzwp53ZfRO():
	for ZKo6S7xzXC,Cv2QRZxhb7L,g9ic1KdEAJqulxUWCo in brAUlZfdFmt3TRJW2xX4.walk(bhliCPq5mvAg19sIF,topdown=vvglE69OFKBm817Nkc):
		if len(g9ic1KdEAJqulxUWCo)>wFYiVd4r12x7CAQBL5SPof(u"࠵࠱࠲፪"): eeiLrhbIvwnTuMo89ZOgEkJ(ZKo6S7xzXC,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	return
def efxhtp5Bqz4(k2x5IYN9dH1FfSytmDMEGChLsX):
	if eCpDE6wJtYUHn0GqK5(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈࠫඋ") in str(TSbmULh6HJNxjRYV): return
	global PhpFa6EdVS,o3YKZFPvy9ag
	VrbBLXk1O2P5Ro87 = Zg9FeADE84jSRIvPCrzYulw3sL
	if k2x5IYN9dH1FfSytmDMEGChLsX: VrbBLXk1O2P5Ro87 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡷࡹࡸࠧඌ"),ykE045Tatx(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧඍ"),dn9ouNryjHiBFQOhASvX(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧඎ"))
	if not VrbBLXk1O2P5Ro87:
		ZTG4ruxXUsc9N = PhpFa6EdVS[vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ඏ")][IYC4iPxkTRUE85namF6(u"࠺፫")]
		VVYFjoZJNU7kCtnwDrPxfSGb = {KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡶࡵࡨࡶࠬඐ"):fs60XkagtWFJ,JP65RzKaScIf(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩඑ"):kI8qwbo6yER}
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,ee3tnwl7avk(u"ࠩࡓࡓࡘ࡚ࠧඒ"),ZTG4ruxXUsc9N,VVYFjoZJNU7kCtnwDrPxfSGb,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡢࡔ࡞࡚ࡈࡐࡐࡢࡇࡔࡊࡅ࠮࠳ࡶࡸࠬඓ"))
		if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
			VrbBLXk1O2P5Ro87 = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
			cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧඔ"),wFYiVd4r12x7CAQBL5SPof(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧඕ"),VrbBLXk1O2P5Ro87,B4GWT7zonF5yipbIwJmNUf6Vavg)
	if VrbBLXk1O2P5Ro87:
		global NEW_SITESURLS,k3weSoAxVMRl8qEPB7LWpiFfv
		exec(VrbBLXk1O2P5Ro87,globals(),locals())
		PhpFa6EdVS.update(NEW_SITESURLS)
		o3YKZFPvy9ag = k3weSoAxVMRl8qEPB7LWpiFfv
	return
def AUwtF98c4Efjmx7lCguqN5():
	PyCLJVibnYcvluD6qU4pz5 = wwAHCjJm2GFhBNpbyZcefr3dDO()
	if PyCLJVibnYcvluD6qU4pz5==A2MHFvoqpZ64gNbB(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭ඖ"): zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࠯࡞ࡷࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭඗")+ijrVgHOUMs5Bo0ehTA8FtvcyXJDa+IYC4iPxkTRUE85namF6(u"ࠨࠢࡠࠫ඘"))
	else: zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭඙")+ijrVgHOUMs5Bo0ehTA8FtvcyXJDa+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࠤࡢ࠭ක"))
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧඛ"),ykE045Tatx(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬග")+kI8qwbo6yER)
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩඝ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪඞ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫඟ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬච"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,yyZPkLCRX1xcBDN(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ඡ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬජ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,eCpDE6wJtYUHn0GqK5(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨඣ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨඤ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,dn9ouNryjHiBFQOhASvX(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪඥ"),IYC4iPxkTRUE85namF6(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭ඦ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,ttC4VURALPYKh(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬට"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨඨ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,yNBjYsgc23xoW(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧඩ"),IK4zTnSMyGQpxEaesJAPVDY(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫඪ"))
	yUTYoAgth5iC43uLrdBH.setSetting(qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭ණ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(JP65RzKaScIf(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩඬ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫත"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬථ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ද"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(ttC4VURALPYKh(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧධ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(ReLGYUQjz7C9iEd(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧන"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(NIBsHMvSXb(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ඲"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧඳ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(ykE045Tatx(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬප"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(ZYTyoA483N(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪඵ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	yUTYoAgth5iC43uLrdBH.setSetting(NIBsHMvSXb(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬබ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬභ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,dn9ouNryjHiBFQOhASvX(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬම"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,E3i1eCBtN2w(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬඹ"))
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,vhZ5qjay1z94JmcMOgXe(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩය"))
	O1o4Qh6m2gWpdP0qwUaFTDMvnEi9yG(vvglE69OFKBm817Nkc)
	HsN3gRJ1Z9ahWqTPwj(FFP5vTqk3nDlEuGdIy)
	import XUbpWe5mRd
	XUbpWe5mRd.vqmnhb5oQRglk0w4u(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	if PyCLJVibnYcvluD6qU4pz5==ykE045Tatx(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨර"):
		x1NAX6MdmQg2BOJ(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,[zfdqH9nKtc3Sy6lbeWDm])
	else:
		x1NAX6MdmQg2BOJ(vvglE69OFKBm817Nkc,[])
		XUbpWe5mRd.g4OiGUFeMzlQLR0ju()
		XUbpWe5mRd.M9ZaLYTqERCo2(NIBsHMvSXb(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ඼"),vvglE69OFKBm817Nkc)
		XUbpWe5mRd.M9ZaLYTqERCo2(DKmLTA2yGtj(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ල"),vvglE69OFKBm817Nkc)
		try:
			feDIlutTk4O7U5 = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,ttC4VURALPYKh(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭඾"),A2MHFvoqpZ64gNbB(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ඿"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪව"),JP65RzKaScIf(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ශ"))
			SEuwHNUdTzjM4Z2D9CemVO = exMAFyUdlHcYb4RSk8I.Addon(id=ykE045Tatx(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬෂ"))
			SEuwHNUdTzjM4Z2D9CemVO.setSetting(x9PULjztJOpu7b(u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨස"),NIBsHMvSXb(u"ࠪࡊࡦࡲࡳࡦࠩහ"))
		except: pass
		try:
			feDIlutTk4O7U5 = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ළ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩෆ"),UixkloZbzGw28ujW56X(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭෇"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭෈"))
			SEuwHNUdTzjM4Z2D9CemVO = exMAFyUdlHcYb4RSk8I.Addon(id=eCpDE6wJtYUHn0GqK5(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨ෉"))
			SEuwHNUdTzjM4Z2D9CemVO.setSetting(lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽ්ࠬ"),dn9ouNryjHiBFQOhASvX(u"ࠪ࠷ࠬ෋"))
		except: pass
		try:
			feDIlutTk4O7U5 = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭෌"),E3i1eCBtN2w(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ෍"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭෎"),E3i1eCBtN2w(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ා"))
			SEuwHNUdTzjM4Z2D9CemVO = exMAFyUdlHcYb4RSk8I.Addon(id=okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨැ"))
			SEuwHNUdTzjM4Z2D9CemVO.setSetting(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧෑ"),dn9ouNryjHiBFQOhASvX(u"ࠪ࠶ࠬි"))
		except: pass
	WR7gIlwo5ik9zJv3CK4sS = wRZbDkg3X6Qhc(UbCmKIdEjMa5lr0)
	WR7gIlwo5ik9zJv3CK4sS = wRZbDkg3X6Qhc(tJuIjTFl9cwGz2dishvoUm4SPK3ArB)
	XUbpWe5mRd.tSkIvmyY4P(vvglE69OFKBm817Nkc)
	yUTYoAgth5iC43uLrdBH.setSetting(wFYiVd4r12x7CAQBL5SPof(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨී"),kI8qwbo6yER)
	i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def znWqw1S65FNyYoQmAv():
	ggaiZlEFNM0hBv48kszxPuU = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(yNBjYsgc23xoW(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪු")))
	ggaiZlEFNM0hBv48kszxPuU = UwCT5Oz6Wo0BP if not ggaiZlEFNM0hBv48kszxPuU else int(ggaiZlEFNM0hBv48kszxPuU)
	if not ggaiZlEFNM0hBv48kszxPuU or not UwCT5Oz6Wo0BP<=PPc8zbiVZnFkfXLBRv-ggaiZlEFNM0hBv48kszxPuU<=fA1u9wd7EkGBObjDhvWa:
		yUTYoAgth5iC43uLrdBH.setSetting(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ෕"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
		HsN3gRJ1Z9ahWqTPwj(FFP5vTqk3nDlEuGdIy)
		mlp8GACvzRxJ = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(YXm2qAbu8Qsx(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧූ")))
		mlp8GACvzRxJ = UwCT5Oz6Wo0BP if not mlp8GACvzRxJ else int(mlp8GACvzRxJ)
		if not mlp8GACvzRxJ or not UwCT5Oz6Wo0BP<=PPc8zbiVZnFkfXLBRv-mlp8GACvzRxJ<=E8RabFm1Kp5O0s:
			yUTYoAgth5iC43uLrdBH.setSetting(E3i1eCBtN2w(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ෗"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
			efxhtp5Bqz4(vvglE69OFKBm817Nkc)
		ookmIy8JCegXqhz1pY = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(A2MHFvoqpZ64gNbB(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ෘ")))
		ookmIy8JCegXqhz1pY = UwCT5Oz6Wo0BP if not ookmIy8JCegXqhz1pY else int(ookmIy8JCegXqhz1pY)
		if not ookmIy8JCegXqhz1pY or not UwCT5Oz6Wo0BP<=PPc8zbiVZnFkfXLBRv-ookmIy8JCegXqhz1pY<=ggWsYrlq8fy2v:
			yUTYoAgth5iC43uLrdBH.setSetting(IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧෙ"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
			CeD3lAx2yJsohLZSVTBpWq = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=n24ICdioEj7vsUJmhWgzwp53ZfRO)
			CeD3lAx2yJsohLZSVTBpWq.start()
	NNpvbUH2h8Q4yR5Kcq = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(vhZ5qjay1z94JmcMOgXe(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ේ")))
	NNpvbUH2h8Q4yR5Kcq = UwCT5Oz6Wo0BP if not NNpvbUH2h8Q4yR5Kcq else int(NNpvbUH2h8Q4yR5Kcq)
	ubZfthTi3qHz4BEpr = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧෛ")))
	ubZfthTi3qHz4BEpr = UwCT5Oz6Wo0BP if not ubZfthTi3qHz4BEpr else int(ubZfthTi3qHz4BEpr)
	if not NNpvbUH2h8Q4yR5Kcq or not ubZfthTi3qHz4BEpr or not UwCT5Oz6Wo0BP<=PPc8zbiVZnFkfXLBRv-ubZfthTi3qHz4BEpr<=NNpvbUH2h8Q4yR5Kcq: GG16O0dcAg()
	return
def GG16O0dcAg():
	uJTzpxaB2itbQnR = Mn5NGAdz6xc42s0
	KKBQfgTtPGysAv4Yr3J6qca = vvglE69OFKBm817Nkc if XcPLKthYTV.opJSrWfgHQ7 else CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if KKBQfgTtPGysAv4Yr3J6qca:
		z4GsL3bn2eCqB = s7XecJ90gPuFWK5Q8Z(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		if len(z4GsL3bn2eCqB)>Mn5NGAdz6xc42s0:
			zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,eCpDE6wJtYUHn0GqK5(u"࠭࠮࡝ࡶࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩො")+ijrVgHOUMs5Bo0ehTA8FtvcyXJDa+wFYiVd4r12x7CAQBL5SPof(u"ࠧࠡ࡟ࠪෝ"))
			CsPNhF9RD27K8GlcMOVZHq,QrXISV6wyYA,fOQUkxT2FMILJPC,GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe,BBkxwFGyasvQphqZ4H = z4GsL3bn2eCqB[UwCT5Oz6Wo0BP]
			kYwphje1QvisNGy3KatEACUo6VB,BBCt692peIHTGrAwd4cWUSDlih5z = GvIoOFAXCU63fVTHK452NEexq.split(IYC4iPxkTRUE85namF6(u"ࠨ࡞ࡱ࠿ࡀ࠭ෞ"))
			del z4GsL3bn2eCqB[UwCT5Oz6Wo0BP]
			lXhwatKiko15bARQ0TOuy3nLxqJ = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(z4GsL3bn2eCqB,Mn5NGAdz6xc42s0)
			CsPNhF9RD27K8GlcMOVZHq,QrXISV6wyYA,fOQUkxT2FMILJPC,GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe,BBkxwFGyasvQphqZ4H = lXhwatKiko15bARQ0TOuy3nLxqJ[UwCT5Oz6Wo0BP]
			fOQUkxT2FMILJPC = dn9ouNryjHiBFQOhASvX(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨෟ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࠤ࠿ࠦࠧ෠")+CsPNhF9RD27K8GlcMOVZHq+u4IRSmrYMKkaHUBnDiLWh+fOQUkxT2FMILJPC
			XXsladx6CjBzv359u1GSyYpHOe = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ෡")
			pRv3ziqwt6yI2CoY5c = qdEKO42r3GhwmCDcHtxzJUR(u"ࠬอไหสิ฽ฬะࠧ෢")
			button0,button1 = GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe
			DtQKml7HMgNaGFCXbVszIBu62P = [button0,button1,pRv3ziqwt6yI2CoY5c]
			wFv1kor5J3DtjU9y7gs6 = Mn5NGAdz6xc42s0 if XcPLKthYTV.dMeaPykZB3Ln8DGuS else DKmLTA2yGtj(u"࠳࠳፬")
			mQOFUVBbfyv39kzto0Nw4 = -ZYTyoA483N(u"࠼፭")
			while mQOFUVBbfyv39kzto0Nw4<UwCT5Oz6Wo0BP:
				vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(DtQKml7HMgNaGFCXbVszIBu62P,O4dklMvZ8ULcS)
				mQOFUVBbfyv39kzto0Nw4 = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN[UwCT5Oz6Wo0BP],vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN[Mn5NGAdz6xc42s0],vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],kYwphje1QvisNGy3KatEACUo6VB,fOQUkxT2FMILJPC,ykE045Tatx(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ෣"),wFv1kor5J3DtjU9y7gs6,YXm2qAbu8Qsx(u"࠺࠵፮"))
				if mQOFUVBbfyv39kzto0Nw4==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠶࠶፯"): break
				import XUbpWe5mRd
				if mQOFUVBbfyv39kzto0Nw4>=UwCT5Oz6Wo0BP and vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN[mQOFUVBbfyv39kzto0Nw4]==DtQKml7HMgNaGFCXbVszIBu62P[Mn5NGAdz6xc42s0]:
					XUbpWe5mRd.Y0YZLJcFOnCMbu5KX3fyIazElsDTN()
					if mQOFUVBbfyv39kzto0Nw4>=UwCT5Oz6Wo0BP: mQOFUVBbfyv39kzto0Nw4 = -IK4zTnSMyGQpxEaesJAPVDY(u"࠿፰")
				elif mQOFUVBbfyv39kzto0Nw4>=UwCT5Oz6Wo0BP and vvOBnbl4mkLhZW8MA9UwiHQ6JX1SCN[mQOFUVBbfyv39kzto0Nw4]==DtQKml7HMgNaGFCXbVszIBu62P[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]:
					XUbpWe5mRd.fGp682jlZSOVvHwMEnmY(vvglE69OFKBm817Nkc)
				if mQOFUVBbfyv39kzto0Nw4==-Mn5NGAdz6xc42s0: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ෤"),U2bWzwG8VdJsBqtR74ErDi3cg1v+UixkloZbzGw28ujW56X(u"ࠨะิ์ัࠦฮุลࠪ෥")+u4IRSmrYMKkaHUBnDiLWh+x9PULjztJOpu7b(u"ࠩ࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ෦"))
			uJTzpxaB2itbQnR = Mn5NGAdz6xc42s0
		else: uJTzpxaB2itbQnR = UwCT5Oz6Wo0BP
	yUTYoAgth5iC43uLrdBH.setSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෧"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,yNBjYsgc23xoW(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ෨"),ReLGYUQjz7C9iEd(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ෩"),uJTzpxaB2itbQnR,B4GWT7zonF5yipbIwJmNUf6Vavg)
	return
def VAGNDoMpOKBghejfL7vX8(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,cwMyvBgJuRXLWH48kpndbG7q2a,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8):
	pZl6CXD5JFVHauxUrS4ntjGI3h = int(B1uLcTqVplZMydrfJb6RY9EaGUPv8%wFYiVd4r12x7CAQBL5SPof(u"࠱࠱፱"))
	OukWzCose6y = int(B1uLcTqVplZMydrfJb6RY9EaGUPv8/jozVWcERh91GOF2NHXQiSwKqe8x(u"࠲࠲፲"))
	BHO7cog6ACPiMjWNSTlJ4hU = TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
	qS4sWeQTcG3Ujl5d7CXY9xtMyR = yUTYoAgth5iC43uLrdBH.getSetting(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭෪"))
	if not qS4sWeQTcG3Ujl5d7CXY9xtMyR: yUTYoAgth5iC43uLrdBH.setSetting(dn9ouNryjHiBFQOhASvX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ෫"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡃࡘࡘࡔ࠭෬"))
	eemiN1oSxUJ = yUTYoAgth5iC43uLrdBH.getSetting(yNBjYsgc23xoW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭෭"))
	AA0Wd3yScYv2H9hBD7a4oPpi = rBzf3emckoV5bh7wl4nuastES(cwMyvBgJuRXLWH48kpndbG7q2a)
	ofkHI4XSPtj9N = [UwCT5Oz6Wo0BP,IYC4iPxkTRUE85namF6(u"࠴࠹፴"),dn9ouNryjHiBFQOhASvX(u"࠵࠼፵"),qdEKO42r3GhwmCDcHtxzJUR(u"࠶࠿፶"),NIBsHMvSXb(u"࠴࠹፳"),ykE045Tatx(u"࠴࠶፹"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠻࠰፷"),NIBsHMvSXb(u"࠵࠴፸")]
	syrdT1n8qm4jfaz9PGV = OukWzCose6y not in ofkHI4XSPtj9N
	GGqawKneXEFoAuLhfT91NHQ7j = OukWzCose6y in [zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠷࠹፽"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠴࠻፺"),ReLGYUQjz7C9iEd(u"࠻࠶፼"),qdEKO42r3GhwmCDcHtxzJUR(u"࠺࠶፻")]
	ALTShgOMVZBRUd60bJ1 = B1uLcTqVplZMydrfJb6RY9EaGUPv8 in [ttC4VURALPYKh(u"࠲࠷࠷፿"),IK4zTnSMyGQpxEaesJAPVDY(u"࠸࠷࠱፾")]
	MSq83Ibv0yAugUJNjtzlc = (syrdT1n8qm4jfaz9PGV or GGqawKneXEFoAuLhfT91NHQ7j) and not ALTShgOMVZBRUd60bJ1
	GyHlgsrtoTbO8Fd7WKVI3 = (eemiN1oSxUJ or not Zxb5IVorSH9j0avgd3UfR6KeC) and eemiN1oSxUJ not in [ZYTyoA483N(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ෮"),NIBsHMvSXb(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࠫ෯"),ttC4VURALPYKh(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊࠧ෰"),ZYTyoA483N(u"࠭ࡍࡆࡐࡘࡣࡆ࡙ࡃࡆࡐࡇࡉࡉ࠭෱"),DKmLTA2yGtj(u"ࠧࡎࡇࡑ࡙ࡤࡊࡅࡔࡅࡈࡒࡉࡋࡄࠨෲ")]
	L2TM5QoVZAhFpPkWryzIi316 = yNBjYsgc23xoW(u"ࠨࡶࡼࡴࡪࡃࠧෳ") in eemiN1oSxUJ
	V7V3tlemuQ = B1uLcTqVplZMydrfJb6RY9EaGUPv8 in [eCpDE6wJtYUHn0GqK5(u"࠵࠻࠷ᎊ"),ZYTyoA483N(u"࠶࠼࠲ᎋ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠷࠶࠴ᎌ"),lU1fSmncFWjizwqZugyYBANML0(u"࠱࠷࠶ᎆ"),vGg1hAkzqi8exVbN(u"࠲࠸࠸ᎇ"),vGg1hAkzqi8exVbN(u"࠳࠹࠺ᎈ"),IK4zTnSMyGQpxEaesJAPVDY(u"࠴࠺࠼ᎉ"),IK4zTnSMyGQpxEaesJAPVDY(u"࠷࠶࠹ᎅ"),dn9ouNryjHiBFQOhASvX(u"࠺࠺࠶ᎂ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠸࠸࠵ᎀ"),IYC4iPxkTRUE85namF6(u"࠹࠹࠷ᎁ"),ttC4VURALPYKh(u"࠻࠻࠺ᎃ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠼࠼࠵ᎄ")]
	KkZtb4lhPd = pZl6CXD5JFVHauxUrS4ntjGI3h==lU1fSmncFWjizwqZugyYBANML0(u"࠹ᎍ") or B1uLcTqVplZMydrfJb6RY9EaGUPv8 in [NIBsHMvSXb(u"࠳࠷࠹ᎏ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"࠹࠶࠼᎑"),IYC4iPxkTRUE85namF6(u"࠸࠶࠸᎐"),UQS9lVew50DIyXrinWsMxTzA(u"࠵࠷ᎎ")]
	v3f1YS7lRFIJ9 = not V7V3tlemuQ
	Ld7cOYjNhQJi = not KkZtb4lhPd
	telyu6gbmW = AA0Wd3yScYv2H9hBD7a4oPpi in [Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"ࠩ࠱࠲ࠬ෴")]
	lUaM8HpeG7JV = telyu6gbmW or v3f1YS7lRFIJ9
	Dugbp27OwjtJIazEeTPs1 = telyu6gbmW or Ld7cOYjNhQJi or L2TM5QoVZAhFpPkWryzIi316
	ofqwTNsCQMe3B0azj6uLt9AhSmvG = B1uLcTqVplZMydrfJb6RY9EaGUPv8 not in [NIBsHMvSXb(u"࠴࠹࠴᎖"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠷࠼࠱᎒"),ReLGYUQjz7C9iEd(u"࠵࠺࠺᎗"),IYC4iPxkTRUE85namF6(u"࠲࠸࠲᎔"),ttC4VURALPYKh(u"࠹࠳࠱᎓"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠶࠶࠳᎕"),E3i1eCBtN2w(u"࠵࠵࠷࠰᎘")]
	if qS4sWeQTcG3Ujl5d7CXY9xtMyR==UixkloZbzGw28ujW56X(u"ࠪࡗ࡙ࡕࡐࠨ෵"): LLQlWuiJnNFqoCUxH1 = KkZtb4lhPd or V7V3tlemuQ
	else: LLQlWuiJnNFqoCUxH1 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	J25vMgRxN4Pnba386AjYfSmBuwL = OukWzCose6y in [ReLGYUQjz7C9iEd(u"࠷࠵᎛"),E3i1eCBtN2w(u"࠽࠵᎚"),A2MHFvoqpZ64gNbB(u"࠺࠺᎙"),YXm2qAbu8Qsx(u"࠲࠲࠴᎜")]
	flzwUXFyqYghxRVGeKboA = B1uLcTqVplZMydrfJb6RY9EaGUPv8 in [YXm2qAbu8Qsx(u"࠴࠻࠴᎝"),vv3sNE8XCU2RAiyVaueTbD950pz(u"࠺࠶࠵᎞")]
	XoJfuH9VAqZh5413sT0r2LBYcMg = not J25vMgRxN4Pnba386AjYfSmBuwL and not flzwUXFyqYghxRVGeKboA
	OpQiYEue83U = lUaM8HpeG7JV and Dugbp27OwjtJIazEeTPs1 and ofqwTNsCQMe3B0azj6uLt9AhSmvG and LLQlWuiJnNFqoCUxH1 and XoJfuH9VAqZh5413sT0r2LBYcMg
	VEnw6cuNXJQZ9BIbfSHAim4TC = ofqwTNsCQMe3B0azj6uLt9AhSmvG and LLQlWuiJnNFqoCUxH1 and XoJfuH9VAqZh5413sT0r2LBYcMg
	Qq9EZ3PphK0GDCiSX = VEnw6cuNXJQZ9BIbfSHAim4TC
	vPoXtDHWMlE = yUTYoAgth5iC43uLrdBH.getSetting(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡳࡶࡴࡼࡩࡥࡧࡵࠫ෶"))
	J5TR0CZFlIENofAecwqr = yUTYoAgth5iC43uLrdBH.getSetting(IYC4iPxkTRUE85namF6(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ෷"))
	iikEDqBN9mWpj840xHJurXZGh = vvglE69OFKBm817Nkc
	if GyHlgsrtoTbO8Fd7WKVI3 and OpQiYEue83U:
		XgjRqOewGHpm0fQ6hL3l72 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"࠭࡬ࡪࡵࡷࠫ෸"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭෹")+vPoXtDHWMlE+E3i1eCBtN2w(u"ࠨࡡࠪ෺")+J5TR0CZFlIENofAecwqr,BHO7cog6ACPiMjWNSTlJ4hU)
		if XgjRqOewGHpm0fQ6hL3l72:
			zOgQjNGH9yk1bXVRnofPvs(Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠩ࠱ࡠࡹࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ෻")+vPoXtDHWMlE+A2MHFvoqpZ64gNbB(u"ࠪࡣࠬ෼")+J5TR0CZFlIENofAecwqr+ReLGYUQjz7C9iEd(u"ࠫࠥࠦࠠࡍࡱࡤࡨ࡮ࡴࡧࠡ࡯ࡨࡲࡺࠦࡦࡳࡱࡰࠤࡨࡧࡣࡩࡧࠪ෽"))
			if L2TM5QoVZAhFpPkWryzIi316:
				JLajUBeA1TEH4n8SfiDxsd = []
				from V4GSlWcDCR import gpDbwjBnN2rfiqX7FyGIcWoHzJ6d
				from DxXprMnf5t import xFrhTvB4g5WHDIO0L7Q81n,d7d8GsiMUPnuN
				oWSflenbGJu3pDjCzKwREHqTIaN = gpDbwjBnN2rfiqX7FyGIcWoHzJ6d
				H0FSRxiQAj = xFrhTvB4g5WHDIO0L7Q81n()
				cZfM9GtlBR = eemiN1oSxUJ
				vz4eYSoH8lNAysa7mfjW,aaijAmU0gB2fxGDCsl,vrfgL7daGsPJS4hBneV1bDE,E0NYPSCc5oImvXdyTAn6w2L7hHMi,Qo1CD8sKUl0BymEvHr3NGfdgR,DDnGWUXQ9cCNpgOdK,n4OcxdgIU7VbtTJSoj3saDKiq5z0,fy4H7dilE5YZK8MGon,JJbdAL8NnSTBl = d2ickGMz45euLXJwAIxs7N(cZfM9GtlBR)
				XR2EPhZrisAC6N = vz4eYSoH8lNAysa7mfjW,aaijAmU0gB2fxGDCsl,vrfgL7daGsPJS4hBneV1bDE,E0NYPSCc5oImvXdyTAn6w2L7hHMi,Qo1CD8sKUl0BymEvHr3NGfdgR,DDnGWUXQ9cCNpgOdK,n4OcxdgIU7VbtTJSoj3saDKiq5z0,Zg9FeADE84jSRIvPCrzYulw3sL,JJbdAL8NnSTBl
				for N1a4EIFLiTB7Gsg in XgjRqOewGHpm0fQ6hL3l72:
					SAXQ4Ko9O7tvbzaRTB8Vn2xuwL = N1a4EIFLiTB7Gsg[JP65RzKaScIf(u"ࠬࡳࡥ࡯ࡷࡌࡸࡪࡳࠧ෾")]
					if SAXQ4Ko9O7tvbzaRTB8Vn2xuwL==XR2EPhZrisAC6N or N1a4EIFLiTB7Gsg[ReLGYUQjz7C9iEd(u"࠭࡭ࡰࡦࡨࠫ෿")] in [yNBjYsgc23xoW(u"࠷࠼࠵Ꭰ"),E3i1eCBtN2w(u"࠶࠼࠶᎟")]:
						N1a4EIFLiTB7Gsg = WWvFT8MZ1QthpRrXz(SAXQ4Ko9O7tvbzaRTB8Vn2xuwL,oWSflenbGJu3pDjCzKwREHqTIaN,H0FSRxiQAj)
						if N1a4EIFLiTB7Gsg[ReLGYUQjz7C9iEd(u"ࠧࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࠪ฀")]:
							bYMvE6AH9W3c8BiIfnrN0T7qC = d7d8GsiMUPnuN(H0FSRxiQAj,SAXQ4Ko9O7tvbzaRTB8Vn2xuwL,N1a4EIFLiTB7Gsg[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡰࡨࡻࡵࡧࡴࡩࠩก")])
							N1a4EIFLiTB7Gsg[ReLGYUQjz7C9iEd(u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨข")] = bYMvE6AH9W3c8BiIfnrN0T7qC+N1a4EIFLiTB7Gsg[ReLGYUQjz7C9iEd(u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩฃ")]
					JLajUBeA1TEH4n8SfiDxsd.append(N1a4EIFLiTB7Gsg)
				yUTYoAgth5iC43uLrdBH.setSetting(ReLGYUQjz7C9iEd(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨค"),Zg9FeADE84jSRIvPCrzYulw3sL)
				if TeDLBxpO03aonZFfQbNuK9S==ReLGYUQjz7C9iEd(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฅ"): cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬฆ")+vPoXtDHWMlE+JP65RzKaScIf(u"ࠧࡠࠩง")+J5TR0CZFlIENofAecwqr,BHO7cog6ACPiMjWNSTlJ4hU,JLajUBeA1TEH4n8SfiDxsd,E8RabFm1Kp5O0s)
			else: JLajUBeA1TEH4n8SfiDxsd = XgjRqOewGHpm0fQ6hL3l72
			if TeDLBxpO03aonZFfQbNuK9S==x9PULjztJOpu7b(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨจ") and AA0Wd3yScYv2H9hBD7a4oPpi!=IK4zTnSMyGQpxEaesJAPVDY(u"ࠩ࠱࠲ࠬฉ") and MSq83Ibv0yAugUJNjtzlc: rsfHM53TBgcQAjN7ZJtKzPGnSxeu()
			iikEDqBN9mWpj840xHJurXZGh = kQphjx9Ob4sVB1fCSTrGiYLyXHR20(BHO7cog6ACPiMjWNSTlJ4hU,JLajUBeA1TEH4n8SfiDxsd,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8)
	elif TeDLBxpO03aonZFfQbNuK9S==NIBsHMvSXb(u"ࠪࡪࡴࡲࡤࡦࡴࠪช") and eemiN1oSxUJ not in [vhZ5qjay1z94JmcMOgXe(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫซ"),Vi1oNCM5kI7yJ0(u"ࠬࡓࡅࡏࡗࡢࡖࡊ࡜ࡅࡓࡕࡈࡈࠬฌ"),UixkloZbzGw28ujW56X(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࠨญ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊࠧฎ"),ttC4VURALPYKh(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࠩฏ")] and VEnw6cuNXJQZ9BIbfSHAim4TC:
		nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨฐ")+vPoXtDHWMlE+wFYiVd4r12x7CAQBL5SPof(u"ࠪࡣࠬฑ")+J5TR0CZFlIENofAecwqr,BHO7cog6ACPiMjWNSTlJ4hU)
	return iikEDqBN9mWpj840xHJurXZGh,eemiN1oSxUJ,BHO7cog6ACPiMjWNSTlJ4hU,AA0Wd3yScYv2H9hBD7a4oPpi,MSq83Ibv0yAugUJNjtzlc,Qq9EZ3PphK0GDCiSX,vPoXtDHWMlE,J5TR0CZFlIENofAecwqr
def vr5Ica4owBMKe3GkZ8tiX(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv):
	if F4FxmRe6UlfGHXP in [IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࠶࠭ฒ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬ࠸ࠧณ"),dn9ouNryjHiBFQOhASvX(u"࠭࠳ࠨด"),DKmLTA2yGtj(u"ࠧ࠵ࠩต"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࠷ࠪถ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠴࠵ࠬท"),YXm2qAbu8Qsx(u"ࠪ࠵࠷࠭ธ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࠶࠹ࠧน")] and x7KDX8GywSYH6d0seM9F25ubhTLv:
		import DxXprMnf5t
		DxXprMnf5t.ofJQjaukKYsph58G9(Zxb5IVorSH9j0avgd3UfR6KeC,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv)
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc,ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	elif F4FxmRe6UlfGHXP==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠼ࠧบ"):
		import V1VREBsj92
		if x7KDX8GywSYH6d0seM9F25ubhTLv==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨป"): V1VREBsj92.ZXWeI01flR(KpNYeI2Pd4nHJG3cOTvWjbSa(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧผ"),wFYiVd4r12x7CAQBL5SPof(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨฝ"),LNma2eq3vEguwVtHjn=jozVWcERh91GOF2NHXQiSwKqe8x(u"࠸࠰࠱࠲Ꭱ"))
		elif x7KDX8GywSYH6d0seM9F25ubhTLv==yNBjYsgc23xoW(u"ࠩࡇࡉࡑࡋࡔࡆࠩพ"): B1uLcTqVplZMydrfJb6RY9EaGUPv8 = Vi1oNCM5kI7yJ0(u"࠳࠴࠶Ꭲ")
		CsaNhTtGm8 = V1VREBsj92.v50uoKxSgEjaATet7DwzLZJyXk2CmR(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,B1uLcTqVplZMydrfJb6RY9EaGUPv8,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
		if x7KDX8GywSYH6d0seM9F25ubhTLv==KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬฟ"): KVirvJ58C1PjHyxel6FdwX()
	elif Zxb5IVorSH9j0avgd3UfR6KeC==KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫ࠼࠭ภ"):
		import bmdRh0UM1W
		bmdRh0UM1W.N4knYsmEdB9i(x9PULjztJOpu7b(u"ࠬࡥࡁࡍࡎࠪม"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	elif Zxb5IVorSH9j0avgd3UfR6KeC==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠸ࠨย"): Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(ykE045Tatx(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ร")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+IYC4iPxkTRUE85namF6(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨฤ")+str(My3un1OVBNfSQm)+qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩล"))
	elif Zxb5IVorSH9j0avgd3UfR6KeC==YXm2qAbu8Qsx(u"ࠪ࠽ࠬฦ"):
		i5xGCIRvcQlMemuO4jaYkWSwtD(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif Zxb5IVorSH9j0avgd3UfR6KeC==wFYiVd4r12x7CAQBL5SPof(u"ࠫ࠶࠶ࠧว"):
		import bmdRh0UM1W
		bmdRh0UM1W.N4knYsmEdB9i(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭ศ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	elif Zxb5IVorSH9j0avgd3UfR6KeC==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭࠱࠵ࠩษ"): i5xGCIRvcQlMemuO4jaYkWSwtD(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊࠧส"))
	elif Zxb5IVorSH9j0avgd3UfR6KeC==qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࠳࠸ࠫห"): i5xGCIRvcQlMemuO4jaYkWSwtD(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Vi1oNCM5kI7yJ0(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࠩฬ"))
	elif Zxb5IVorSH9j0avgd3UfR6KeC==eCpDE6wJtYUHn0GqK5(u"ࠪ࠵࠻࠭อ"): i5xGCIRvcQlMemuO4jaYkWSwtD(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,ReLGYUQjz7C9iEd(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࠬฮ"))
	elif Zxb5IVorSH9j0avgd3UfR6KeC==x9PULjztJOpu7b(u"ࠬ࠷࠷ࠨฯ"): i5xGCIRvcQlMemuO4jaYkWSwtD(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,DKmLTA2yGtj(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࠨะ"))
	if Zxb5IVorSH9j0avgd3UfR6KeC in [NIBsHMvSXb(u"ࠧ࠺ࠩั"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨ࠳࠷ࠫา"),eCpDE6wJtYUHn0GqK5(u"ࠩ࠴࠹ࠬำ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪ࠵࠻࠭ิ"),ttC4VURALPYKh(u"ࠫ࠶࠽ࠧี")]: KVirvJ58C1PjHyxel6FdwX()
	return
def NNCIgMS8jRE0WUuksBmOAehqy(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv,cwMyvBgJuRXLWH48kpndbG7q2a):
	if c7cZwUErDWgMbzvl51CVfsXYReA: AUwtF98c4Efjmx7lCguqN5()
	if Zxb5IVorSH9j0avgd3UfR6KeC: vr5Ica4owBMKe3GkZ8tiX(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv)
	znWqw1S65FNyYoQmAv()
	efxhtp5Bqz4(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc
	sKAgLhE31O0dZQVUyrX9 = VAGNDoMpOKBghejfL7vX8(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,cwMyvBgJuRXLWH48kpndbG7q2a,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8)
	iikEDqBN9mWpj840xHJurXZGh,eemiN1oSxUJ,BHO7cog6ACPiMjWNSTlJ4hU,AA0Wd3yScYv2H9hBD7a4oPpi,MSq83Ibv0yAugUJNjtzlc,Qq9EZ3PphK0GDCiSX,vPoXtDHWMlE,J5TR0CZFlIENofAecwqr = sKAgLhE31O0dZQVUyrX9
	if iikEDqBN9mWpj840xHJurXZGh: return
	if eemiN1oSxUJ==vhZ5qjay1z94JmcMOgXe(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬึ"): HsN3gRJ1Z9ahWqTPwj(FFP5vTqk3nDlEuGdIy)
	LpTv52e4Icnwms0OXRW6oACix(x9PULjztJOpu7b(u"࠭ࡳࡵࡣࡵࡸࠬื"))
	if yUTYoAgth5iC43uLrdBH.getSetting(dn9ouNryjHiBFQOhASvX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪุ࠭")) not in [IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡃࡘࡘࡔู࠭"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡖࡘࡔࡖฺࠧ"),IYC4iPxkTRUE85namF6(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ฻")]:
		yUTYoAgth5iC43uLrdBH.setSetting(ttC4VURALPYKh(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ฼"),ykE045Tatx(u"ࠬࡇࡕࡕࡑࠪ฽"))
	if not yUTYoAgth5iC43uLrdBH.getSetting(yyZPkLCRX1xcBDN(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭฾")): yUTYoAgth5iC43uLrdBH.setSetting(wFYiVd4r12x7CAQBL5SPof(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧ฿"),JYCuTUrNh3[UwCT5Oz6Wo0BP])
	CsaNhTtGm8 = v50uoKxSgEjaATet7DwzLZJyXk2CmR(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	if DKmLTA2yGtj(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪเ") in xQXoDIqn4Ucsthb2G7YpzwPTymi: kRMLY8ETzoZBOvnSmw = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if TeDLBxpO03aonZFfQbNuK9S==Vi1oNCM5kI7yJ0(u"ࠩࡩࡳࡱࡪࡥࡳࠩแ"):
		if AA0Wd3yScYv2H9hBD7a4oPpi!=yNBjYsgc23xoW(u"ࠪ࠲࠳࠭โ") and MSq83Ibv0yAugUJNjtzlc: rsfHM53TBgcQAjN7ZJtKzPGnSxeu()
		if xTMIUH9jL2w4mspJkyrR>-Mn5NGAdz6xc42s0:
			IlmURTHGj5XdOeCw1bnDE3AP = [UwCT5Oz6Wo0BP,yyZPkLCRX1xcBDN(u"࠳࠸Ꭴ"),IYC4iPxkTRUE85namF6(u"࠴࠻Ꭵ"),lU1fSmncFWjizwqZugyYBANML0(u"࠵࠾Ꭶ"),ReLGYUQjz7C9iEd(u"࠳࠸Ꭳ"),E3i1eCBtN2w(u"࠳࠵Ꭹ"),IYC4iPxkTRUE85namF6(u"࠺࠶Ꭷ"),ReLGYUQjz7C9iEd(u"࠻࠳Ꭸ")]
			if (zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫ࡮ࡴࡴࠨใ"),YXm2qAbu8Qsx(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨไ"),ee3tnwl7avk(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫๅ")) or B1uLcTqVplZMydrfJb6RY9EaGUPv8 not in IlmURTHGj5XdOeCw1bnDE3AP) and not XcPLKthYTV.zyKW1Eow48ek0:
				from V4GSlWcDCR import gpDbwjBnN2rfiqX7FyGIcWoHzJ6d
				XgjRqOewGHpm0fQ6hL3l72 = RgzVFQlnIC0wxfShKmE8WLoUG4bji(gpDbwjBnN2rfiqX7FyGIcWoHzJ6d)
				iikEDqBN9mWpj840xHJurXZGh = kQphjx9Ob4sVB1fCSTrGiYLyXHR20(BHO7cog6ACPiMjWNSTlJ4hU,XgjRqOewGHpm0fQ6hL3l72,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8)
				if XgjRqOewGHpm0fQ6hL3l72 and Qq9EZ3PphK0GDCiSX:
					cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ๆ")+vPoXtDHWMlE+ykE045Tatx(u"ࠨࡡࠪ็")+J5TR0CZFlIENofAecwqr,BHO7cog6ACPiMjWNSTlJ4hU,XgjRqOewGHpm0fQ6hL3l72,E8RabFm1Kp5O0s)
			else:
				j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.addDirectoryItem(xTMIUH9jL2w4mspJkyrR,ee3tnwl7avk(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳่ࠬ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+vhZ5qjay1z94JmcMOgXe(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲้ࠪ"),HqjWaYEzp0D8eyQRud.ListItem(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅ๊ࠪ")))
				j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.addDirectoryItem(xTMIUH9jL2w4mspJkyrR,IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ๋")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭์"),HqjWaYEzp0D8eyQRud.ListItem(vGg1hAkzqi8exVbN(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭ํ")))
			j9wel7aIxL2EJn1rTKOXYNCqfMzRhg.endOfDirectory(xTMIUH9jL2w4mspJkyrR,oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,kRMLY8ETzoZBOvnSmw,b1BCrzIqxw9cpZa8)
	return
def HsN3gRJ1Z9ahWqTPwj(zzDVvlTRwLBQESNtI):
	if A2MHFvoqpZ64gNbB(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ๎") in TSbmULh6HJNxjRYV or ee3tnwl7avk(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧ๏") in TSbmULh6HJNxjRYV: return
	myKwJrxBAhUL6TVF = vvglE69OFKBm817Nkc if zzDVvlTRwLBQESNtI else CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if not myKwJrxBAhUL6TVF:
		SsQfzqobW80Ch63XtdE = hFlLfTs4oYBE(yUTYoAgth5iC43uLrdBH.getSetting(Vi1oNCM5kI7yJ0(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ๐")))
		SsQfzqobW80Ch63XtdE = UwCT5Oz6Wo0BP if not SsQfzqobW80Ch63XtdE else int(SsQfzqobW80Ch63XtdE)
		if not SsQfzqobW80Ch63XtdE or not UwCT5Oz6Wo0BP<=PPc8zbiVZnFkfXLBRv-SsQfzqobW80Ch63XtdE<=zzDVvlTRwLBQESNtI: myKwJrxBAhUL6TVF = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if not myKwJrxBAhUL6TVF:
		WWrUShDQdklIzXsmRKo1Bw = yUTYoAgth5iC43uLrdBH.getSetting(ReLGYUQjz7C9iEd(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ๑"))
		if WWrUShDQdklIzXsmRKo1Bw in [Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ๒"),UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ๓")]: myKwJrxBAhUL6TVF = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if not myKwJrxBAhUL6TVF:
		FzBcWeThtY4v = yUTYoAgth5iC43uLrdBH.getSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪ๔"))
		d9QSW7z3JIPrGHcjMty4NpRvT = yUTYoAgth5iC43uLrdBH.getSetting(ZYTyoA483N(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠵ࠫ๕"))
		Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(NIBsHMvSXb(u"࠶Ꭺ")*FzBcWeThtY4v.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
		Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(YXm2qAbu8Qsx(u"࠳࠷Ꭻ")*Nic9H6r7M3.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
		Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(IYC4iPxkTRUE85namF6(u"࠴࠽Ꭼ")*Nic9H6r7M3.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
		if Nic9H6r7M3!=d9QSW7z3JIPrGHcjMty4NpRvT: myKwJrxBAhUL6TVF = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if myKwJrxBAhUL6TVF: oYKDVlk6dFXTMf5zgG4jW38sp(vvglE69OFKBm817Nkc)
	return
def v50uoKxSgEjaATet7DwzLZJyXk2CmR(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia):
	B1uLcTqVplZMydrfJb6RY9EaGUPv8 = int(My3un1OVBNfSQm)
	OukWzCose6y = int(B1uLcTqVplZMydrfJb6RY9EaGUPv8//ReLGYUQjz7C9iEd(u"࠵࠵Ꭽ"))
	if   OukWzCose6y==UwCT5Oz6Wo0BP:  from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==Mn5NGAdz6xc42s0:  from y9svExgqST 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:  from IETgz37Lqy 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==O4dklMvZ8ULcS:  from iCRQa4Oc8X 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==NEc173Pr0jAwLF5OS:  from LwCQGXVja7 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif OukWzCose6y==vGg1hAkzqi8exVbN(u"࠺Ꭾ"):  from LhE3QqKS2J 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==eCpDE6wJtYUHn0GqK5(u"࠼Ꭿ"):  from FFR2UawxiY 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==NIBsHMvSXb(u"࠷Ꮀ"):  from pQ1ZiwXaM0 			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠹Ꮁ"):  from QQHduikc5f 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==qdEKO42r3GhwmCDcHtxzJUR(u"࠻Ꮂ"):  from x4UtLnquX5		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠴࠴Ꮃ"): from vvxHJkcCeG 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N)
	elif OukWzCose6y==DKmLTA2yGtj(u"࠵࠶Ꮄ"): from yeiIX36zJo 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠶࠸Ꮅ"): from jaOvDTcmbZ 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ZYTyoA483N(u"࠷࠳Ꮆ"): from GMldKzIVD7		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==E3i1eCBtN2w(u"࠱࠵Ꮇ"): from eRwxN7KrW0 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,EELGungxe6wKPar9hyRv5FUMpIB)
	elif OukWzCose6y==qdEKO42r3GhwmCDcHtxzJUR(u"࠲࠷Ꮈ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UixkloZbzGw28ujW56X(u"࠳࠹Ꮉ"): from V7V3tlemuQ		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠴࠻Ꮊ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vhZ5qjay1z94JmcMOgXe(u"࠵࠽Ꮋ"): from Jycpjse8v0		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠶࠿Ꮌ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yNBjYsgc23xoW(u"࠸࠰Ꮍ"): from R9Rm6XscNg		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==NIBsHMvSXb(u"࠲࠲Ꮎ"): from B8RiNLrIVh	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==E3i1eCBtN2w(u"࠳࠴Ꮏ"): from rk4QMqW6Z8		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==wFYiVd4r12x7CAQBL5SPof(u"࠴࠶Ꮐ"): from OAJRx3Djkr			import ut1mDygn8U6fzQhaMrBYK9l; CsaNhTtGm8 = ut1mDygn8U6fzQhaMrBYK9l(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==yNBjYsgc23xoW(u"࠵࠸Ꮑ"): from IyYirQzZGv 			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==NIBsHMvSXb(u"࠶࠺Ꮒ"): from yJTdSCOX7x 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==Vi1oNCM5kI7yJ0(u"࠷࠼Ꮓ"): from V4GSlWcDCR 			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==DKmLTA2yGtj(u"࠸࠷Ꮔ"): from DxXprMnf5t		import ut1mDygn8U6fzQhaMrBYK9l; CsaNhTtGm8 = ut1mDygn8U6fzQhaMrBYK9l(B1uLcTqVplZMydrfJb6RY9EaGUPv8,Zxb5IVorSH9j0avgd3UfR6KeC)
	elif OukWzCose6y==YXm2qAbu8Qsx(u"࠲࠹Ꮕ"): from OAJRx3Djkr			import ut1mDygn8U6fzQhaMrBYK9l; CsaNhTtGm8 = ut1mDygn8U6fzQhaMrBYK9l(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠳࠻Ꮖ"): from rEbLJu0WX6	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==x9PULjztJOpu7b(u"࠵࠳Ꮗ"): from fAYMmzEO20		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yNBjYsgc23xoW(u"࠶࠵Ꮘ"): from J6SZDv8IaX		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UixkloZbzGw28ujW56X(u"࠷࠷Ꮙ"): from sHC7O1VgMi		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yyZPkLCRX1xcBDN(u"࠸࠹Ꮚ"): from NOm3axJBXc		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N)
	elif OukWzCose6y==ttC4VURALPYKh(u"࠹࠴Ꮛ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠳࠶Ꮜ"): from Szw076nNGR		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==DKmLTA2yGtj(u"࠴࠸Ꮝ"): from wwKvyLS7uU			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==dn9ouNryjHiBFQOhASvX(u"࠵࠺Ꮞ"): from Y9cjIvMwV2			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠶࠼Ꮟ"): from EE6g4ZBibI 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠷࠾Ꮠ"): from P4zITBLrK0		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==Vi1oNCM5kI7yJ0(u"࠹࠶Ꮡ"): from tAvpx4RZWu	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif OukWzCose6y==ee3tnwl7avk(u"࠺࠱Ꮢ"): from tAvpx4RZWu	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif OukWzCose6y==E3i1eCBtN2w(u"࠴࠳Ꮣ"): from FVRYiGMdJh			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==qdEKO42r3GhwmCDcHtxzJUR(u"࠵࠵Ꮤ"): from urBoEOnx02			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==E3i1eCBtN2w(u"࠶࠷Ꮥ"): from TlGyYrZ0EN		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠷࠹Ꮦ"): from nBcTwsL9kY		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ReLGYUQjz7C9iEd(u"࠸࠻Ꮧ"): from L1PV8IBk34			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠹࠽Ꮨ"): from gNX7Y4t0Sb		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠺࠸Ꮩ"): from fHmezsZOGV		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ttC4VURALPYKh(u"࠴࠺Ꮪ"): from fForZ4LwTl		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vGg1hAkzqi8exVbN(u"࠶࠲Ꮫ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠷࠴Ꮬ"): from NOExhUsqZF 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==DKmLTA2yGtj(u"࠸࠶Ꮭ"): from NOExhUsqZF 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ReLGYUQjz7C9iEd(u"࠹࠸Ꮮ"): from V4GSlWcDCR 			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠺࠺Ꮯ"): from bmdRh0UM1W	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,wlxviMOuNeQVct4ULsCEHXZm6yR2p)
	elif OukWzCose6y==yNBjYsgc23xoW(u"࠻࠵Ꮰ"): from F91TH3ni7m 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ttC4VURALPYKh(u"࠵࠷Ꮱ"): from x6reJKUPRb		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠶࠹Ꮲ"): from xVvmRMp79W		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠷࠻Ꮳ"): from DD8x9nGTjO		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==A2MHFvoqpZ64gNbB(u"࠸࠽Ꮴ"): from KKnTgpavVf		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠺࠵Ꮵ"): from jmrw5AQV9g			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yNBjYsgc23xoW(u"࠻࠷Ꮶ"): from YBhVmwNfDK			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠼࠲Ꮷ"): from IvCTXhSxEe		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==YXm2qAbu8Qsx(u"࠶࠴Ꮸ"): from CZwfHSTMnR	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==Vi1oNCM5kI7yJ0(u"࠷࠶Ꮹ"): from SkxuGj30n4			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vhZ5qjay1z94JmcMOgXe(u"࠸࠸Ꮺ"): from uuL0bjGAER			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vGg1hAkzqi8exVbN(u"࠹࠺Ꮻ"): from nMduPwQNBv			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠺࠼Ꮼ"): from k560CXdIMv		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yyZPkLCRX1xcBDN(u"࠻࠾Ꮽ"): from uxCB1EvZIL		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==Vi1oNCM5kI7yJ0(u"࠼࠹Ꮾ"): from HV95jRad3o		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==qdEKO42r3GhwmCDcHtxzJUR(u"࠷࠱Ꮿ"): from SdHpbQKWze			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ykE045Tatx(u"࠸࠳Ᏸ"): from Lb65UCfP20			import ut1mDygn8U6fzQhaMrBYK9l; CsaNhTtGm8 = ut1mDygn8U6fzQhaMrBYK9l(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==ReLGYUQjz7C9iEd(u"࠹࠵Ᏹ"): from Lb65UCfP20			import ut1mDygn8U6fzQhaMrBYK9l; CsaNhTtGm8 = ut1mDygn8U6fzQhaMrBYK9l(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,TeDLBxpO03aonZFfQbNuK9S,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==dn9ouNryjHiBFQOhASvX(u"࠺࠷Ᏺ"): from zzOfaw1ZSn	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==lU1fSmncFWjizwqZugyYBANML0(u"࠻࠹Ᏻ"): from ZUvX5Te1Ly		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8)
	elif OukWzCose6y==JP65RzKaScIf(u"࠼࠻Ᏼ"): from ZUvX5Te1Ly		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8)
	elif OukWzCose6y==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠽࠶Ᏽ"): from V7V3tlemuQ		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi,wlxviMOuNeQVct4ULsCEHXZm6yR2p,QsWU0ew5xMjBozVtqHAGDTNyL4Ia)
	elif OukWzCose6y==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠷࠸᏶"): from AUPfVWo8Bn 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==A2MHFvoqpZ64gNbB(u"࠸࠺᏷"): from XN15zTsRbO 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠹࠼ᏸ"): from nI3TcUWd10 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ykE045Tatx(u"࠻࠴ᏹ"): from r1IcxTB74l 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ZYTyoA483N(u"࠼࠶ᏺ"): from DsYE3bQMhP 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vhZ5qjay1z94JmcMOgXe(u"࠽࠸ᏻ"): from Ym4jT1kfeg		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==YXm2qAbu8Qsx(u"࠾࠳ᏼ"): from p01WPVqYlg		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==eCpDE6wJtYUHn0GqK5(u"࠸࠵ᏽ"): from Z5KTxaBCsb		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==A2MHFvoqpZ64gNbB(u"࠹࠷᏾"): from ciYKf9J6S1		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==x9PULjztJOpu7b(u"࠺࠹᏿"): from TUXrq2Wucb		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ttC4VURALPYKh(u"࠻࠻᐀"): from m5GCozxNf9			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IK4zTnSMyGQpxEaesJAPVDY(u"࠼࠽ᐁ"): from Lwb5ZvxjPS			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==eCpDE6wJtYUHn0GqK5(u"࠽࠿ᐂ"): from ux0yD8HI7h		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IK4zTnSMyGQpxEaesJAPVDY(u"࠿࠰ᐃ"): from lDN1vpXqbR	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==DKmLTA2yGtj(u"࠹࠲ᐄ"): from u93ocWIFpr		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==dn9ouNryjHiBFQOhASvX(u"࠺࠴ᐅ"): from CmIRW3dsz6		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vhZ5qjay1z94JmcMOgXe(u"࠻࠶ᐆ"): from rpVHW0BUAq		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠼࠸ᐇ"): from WWDTkiomsl			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠽࠺ᐈ"): from gwLkxirdMG			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==yyZPkLCRX1xcBDN(u"࠾࠼ᐉ"): from SSibqHsJV3		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠿࠷ᐊ"): from GeFPYWAKRj		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==vhZ5qjay1z94JmcMOgXe(u"࠹࠹ᐋ"): from WWQh20gXyq		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠺࠻ᐌ"): from LovIOcuEeK		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ReLGYUQjz7C9iEd(u"࠳࠳࠴ᐍ"): from g9dJL8N73E		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==UQS9lVew50DIyXrinWsMxTzA(u"࠴࠴࠶ᐎ"): from FXDcd3soka	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠵࠵࠸ᐏ"): from XUbpWe5mRd 		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==IYC4iPxkTRUE85namF6(u"࠶࠶࠳ᐐ"): from MrKVAfbEcy	import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==NIBsHMvSXb(u"࠷࠰࠵ᐑ"): from PetBNZE18i		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ee3tnwl7avk(u"࠱࠱࠷ᐒ"): from A56FmERZHb			import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠲࠲࠹ᐓ"): from ktcdbBlICJ		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	elif OukWzCose6y==ReLGYUQjz7C9iEd(u"࠳࠳࠻ᐔ"): from axMUBXdfLb		import mp9gnhjBIoA8Rz3SylG	; CsaNhTtGm8 = mp9gnhjBIoA8Rz3SylG(B1uLcTqVplZMydrfJb6RY9EaGUPv8,ZTG4ruxXUsc9N,xQXoDIqn4Ucsthb2G7YpzwPTymi)
	else: CsaNhTtGm8 = None
	return CsaNhTtGm8
def hw2V6XZSmcrDK(POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H,iojW2gVFfT,showDialogs):
	FLqQoZwdAngNkz49RMGUHJXW3bDC = iojW2gVFfT.split(lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠰ࠫ๖"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP] if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࠱ࠬ๗") in iojW2gVFfT else iojW2gVFfT
	if not showDialogs or iojW2gVFfT in JqgcndNGI5W493ZRh: return vvglE69OFKBm817Nkc
	e5tpxWUIR07haVwbJSY2cFz4NmMfXA = yUTYoAgth5iC43uLrdBH.getSetting(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ๘"))
	yUTYoAgth5iC43uLrdBH.setSetting(DKmLTA2yGtj(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭๙"),Zg9FeADE84jSRIvPCrzYulw3sL)
	ttMSf4HzTVbmvuL9RAls8WagDq5eih = POocngw2KWudQXsL4rpRvf1eAz0qVl in [vhZ5qjay1z94JmcMOgXe(u"࠽ᐘ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠵࠶࠶࠰࠲ᐖ"),vGg1hAkzqi8exVbN(u"࠴࠵࠵࠶࠲ᐕ"),A2MHFvoqpZ64gNbB(u"࠶࠶࠰࠶࠶ᐗ")]
	iKsEZQ2Cx75XpgInRYHz9LGd1 = BBkxwFGyasvQphqZ4H.lower()
	Cq51sjgVmp8oFHRbu6te4LG = POocngw2KWudQXsL4rpRvf1eAz0qVl in [UwCT5Oz6Wo0BP,IK4zTnSMyGQpxEaesJAPVDY(u"࠳࠳࠸ᐛ"),yyZPkLCRX1xcBDN(u"࠱࠱࠲࠹࠵ᐙ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠲࠳࠴ᐚ")]
	k1kz3oOCcWIShAulR654 = ZYTyoA483N(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ๚") in iKsEZQ2Cx75XpgInRYHz9LGd1
	wOArEiCSKVYBD5fZRI3PtFUH = DKmLTA2yGtj(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ๛") in iKsEZQ2Cx75XpgInRYHz9LGd1
	wx15ZOth8ReW3djo = UixkloZbzGw28ujW56X(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ๜") in iKsEZQ2Cx75XpgInRYHz9LGd1
	ydBNL7v3RnXel = dn9ouNryjHiBFQOhASvX(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ๝") in iKsEZQ2Cx75XpgInRYHz9LGd1
	QXvyZSfmepFR7GHNh = yUTYoAgth5iC43uLrdBH.getSetting(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ๞"))
	udFWOplyCqMVZILn1sk7 = yUTYoAgth5iC43uLrdBH.getSetting(vGg1hAkzqi8exVbN(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ๟"))
	oFu7BCiHSrO1ZmyX3fnQExDRGs = E3i1eCBtN2w(u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ๠")
	t4tcsuCmSvPzTxY8GM3 = IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡅࡳࡴࡲࡶࠥ࠭๡")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+x9PULjztJOpu7b(u"ࠧ࠻ࠢࠪ๢")+BBkxwFGyasvQphqZ4H
	t4tcsuCmSvPzTxY8GM3 = UAjMPLdITqWChbrcB(t4tcsuCmSvPzTxY8GM3)
	if Cq51sjgVmp8oFHRbu6te4LG or k1kz3oOCcWIShAulR654 or wOArEiCSKVYBD5fZRI3PtFUH or wx15ZOth8ReW3djo or ydBNL7v3RnXel: oFu7BCiHSrO1ZmyX3fnQExDRGs += KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ๣")
	if ttMSf4HzTVbmvuL9RAls8WagDq5eih: oFu7BCiHSrO1ZmyX3fnQExDRGs += tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ๤")
	t4tcsuCmSvPzTxY8GM3 = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+t4tcsuCmSvPzTxY8GM3+u4IRSmrYMKkaHUBnDiLWh
	if QXvyZSfmepFR7GHNh==UixkloZbzGw28ujW56X(u"ࠪࡅࡘࡑࠧ๥") or udFWOplyCqMVZILn1sk7==ZYTyoA483N(u"ࠫࡆ࡙ࡋࠨ๦"):
		oFu7BCiHSrO1ZmyX3fnQExDRGs += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+UixkloZbzGw28ujW56X(u"ࠬํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦࠧࠧ๧")+u4IRSmrYMKkaHUBnDiLWh
	FjUBMw9OGSx = vvglE69OFKBm817Nkc
	if QXvyZSfmepFR7GHNh==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡁࡔࡍࠪ๨") or udFWOplyCqMVZILn1sk7==yNBjYsgc23xoW(u"ࠧࡂࡕࡎࠫ๩"):
		mQOFUVBbfyv39kzto0Nw4 = wCuDBb85Gjl36RAQnUEZd(ee3tnwl7avk(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ๪"),yNBjYsgc23xoW(u"ࠩัีําࠧ๫"),wFYiVd4r12x7CAQBL5SPof(u"ࠪษึูวๅࠢ็่๊ฮัๆฮࠪ๬"),ReLGYUQjz7C9iEd(u"ࠫฯ฻ไ๋ฯࠣห้๋ิไๆฬࠫ๭"),FLqQoZwdAngNkz49RMGUHJXW3bDC+Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J+ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC),oFu7BCiHSrO1ZmyX3fnQExDRGs+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+t4tcsuCmSvPzTxY8GM3)
		if mQOFUVBbfyv39kzto0Nw4==Mn5NGAdz6xc42s0:
			from XUbpWe5mRd import Y0YZLJcFOnCMbu5KX3fyIazElsDTN
			Y0YZLJcFOnCMbu5KX3fyIazElsDTN()
		elif mQOFUVBbfyv39kzto0Nw4==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: FjUBMw9OGSx = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,FLqQoZwdAngNkz49RMGUHJXW3bDC+Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J+ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC),oFu7BCiHSrO1ZmyX3fnQExDRGs,t4tcsuCmSvPzTxY8GM3)
	yUTYoAgth5iC43uLrdBH.setSetting(yyZPkLCRX1xcBDN(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭๮"),e5tpxWUIR07haVwbJSY2cFz4NmMfXA)
	return FjUBMw9OGSx
def x1NAX6MdmQg2BOJ(AfIobtyLaKlq3XrvVWn6N1dwec8=vvglE69OFKBm817Nkc,kh0MBOH4ly5Dm36xPRGpvwb=[]):
	IHKXeCqiLNb27nw1aA8VlkP = [UbCmKIdEjMa5lr0,tJuIjTFl9cwGz2dishvoUm4SPK3ArB]+kh0MBOH4ly5Dm36xPRGpvwb
	for ZMwJRKp4kcIvPrd7ih6e3njX in brAUlZfdFmt3TRJW2xX4.listdir(cc6p0YbTjFzgyG3aRw):
		if AfIobtyLaKlq3XrvVWn6N1dwec8 and (ZMwJRKp4kcIvPrd7ih6e3njX.startswith(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡩࡱࡶࡹࠫ๯")) or ZMwJRKp4kcIvPrd7ih6e3njX.startswith(YXm2qAbu8Qsx(u"ࠧ࡮࠵ࡸࠫ๰"))): continue
		if ZMwJRKp4kcIvPrd7ih6e3njX.startswith(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡨ࡬ࡰࡪࡥࠧ๱")): continue
		pfZtSg5czy = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ZMwJRKp4kcIvPrd7ih6e3njX)
		if pfZtSg5czy in IHKXeCqiLNb27nw1aA8VlkP: continue
		try: brAUlZfdFmt3TRJW2xX4.remove(pfZtSg5czy)
		except: pass
	if bhliCPq5mvAg19sIF not in IHKXeCqiLNb27nw1aA8VlkP: eeiLrhbIvwnTuMo89ZOgEkJ(bhliCPq5mvAg19sIF,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
	LNma2eq3vEguwVtHjn.sleep(yyZPkLCRX1xcBDN(u"࠴ᐜ"))
	return
def oszqtvpmB5XuaAPOwNMC6J(kX3qQnBINGg,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Bd4TxwQJ87HXUl3G6f=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	ZTG4ruxXUsc9N = ZTG4ruxXUsc9N+E3i1eCBtN2w(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ๲")+kX3qQnBINGg
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh,Bd4TxwQJ87HXUl3G6f)
	if ZTG4ruxXUsc9N in Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content: Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded = vvglE69OFKBm817Nkc
	if not Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		KVirvJ58C1PjHyxel6FdwX()
	return Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO
def LT41C2uHsQk8K5tbDS(ZTG4ruxXUsc9N):
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,ee3tnwl7avk(u"ࠪࡋࡊ࡚ࠧ๳"),ZTG4ruxXUsc9N,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ๴"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
	IA59uKFOmdpaUcrSbxEHyhwP = []
	if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
		DFgh28lLUomR3QIrdwN51ejxz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(x9PULjztJOpu7b(u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨ๵"),qHn7Qbi61UB)
		if DFgh28lLUomR3QIrdwN51ejxz: qHn7Qbi61UB = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO.join(DFgh28lLUomR3QIrdwN51ejxz)
		J0xnQCbuRl3tkLSw = qHn7Qbi61UB.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).strip(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO).split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
		IA59uKFOmdpaUcrSbxEHyhwP = []
		for kX3qQnBINGg in J0xnQCbuRl3tkLSw:
			if kX3qQnBINGg.count(Vi1oNCM5kI7yJ0(u"࠭࠮ࠨ๶"))==O4dklMvZ8ULcS: IA59uKFOmdpaUcrSbxEHyhwP.append(kX3qQnBINGg)
	return IA59uKFOmdpaUcrSbxEHyhwP
def znBO5KfMm0a9cZvdpbIu6UwP(*aargs):
	lZEWq2A6So3sCrvNOM = ykE045Tatx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ๷")
	J4xBiGXZ7FNILYg1 = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬ๸")
	s7wHbtNevdSGF = LT41C2uHsQk8K5tbDS(J4xBiGXZ7FNILYg1)
	IA59uKFOmdpaUcrSbxEHyhwP = LT41C2uHsQk8K5tbDS(lZEWq2A6So3sCrvNOM)
	p9hbFt3skWQ7Cve0lzf = s7wHbtNevdSGF+IA59uKFOmdpaUcrSbxEHyhwP
	zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+dn9ouNryjHiBFQOhASvX(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡳࡶࡴࡾࡩࡦࡵࠣࡰ࡮ࡹࡴࠡࠢࠣ࠵ࡸࡺࠫ࠳ࡰࡧ࠾ࠥࡡࠠࠨ๹")+str(len(s7wHbtNevdSGF))+ReLGYUQjz7C9iEd(u"ࠪ࠯ࠬ๺")+str(len(IA59uKFOmdpaUcrSbxEHyhwP))+IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࠥࡣࠧ๻"))
	kX3qQnBINGg = yUTYoAgth5iC43uLrdBH.getSetting(IYC4iPxkTRUE85namF6(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ๼"))
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = dA2JDHpu6O0kGt7M1fY4aVQbBKn()
	yUTYoAgth5iC43uLrdBH.setSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭๽"),Zg9FeADE84jSRIvPCrzYulw3sL)
	if kX3qQnBINGg or p9hbFt3skWQ7Cve0lzf:
		CsPNhF9RD27K8GlcMOVZHq,HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = UwCT5Oz6Wo0BP,wFYiVd4r12x7CAQBL5SPof(u"࠵࠵ᐝ")
		BWyiwLdn1ep48CrGk92RuTDYOxISgK = len(p9hbFt3skWQ7Cve0lzf)
		FcPTBwdMosE9r = HTPdhx6IsYmGjeZ5nbtkUy47ACvruK
		if BWyiwLdn1ep48CrGk92RuTDYOxISgK>FcPTBwdMosE9r: NbiPG1SmA4pucTaDvV = FcPTBwdMosE9r
		else: NbiPG1SmA4pucTaDvV = BWyiwLdn1ep48CrGk92RuTDYOxISgK
		CCSKzv3tpOnGd8D = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(p9hbFt3skWQ7Cve0lzf,NbiPG1SmA4pucTaDvV)
		if kX3qQnBINGg: CCSKzv3tpOnGd8D = [kX3qQnBINGg]+CCSKzv3tpOnGd8D
		klVhRojEu9H = fZLqV6xaCWsTItK2ngd(vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
		nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
		while LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx<=HTPdhx6IsYmGjeZ5nbtkUy47ACvruK and not klVhRojEu9H.finishedLIST:
			if CsPNhF9RD27K8GlcMOVZHq<NbiPG1SmA4pucTaDvV:
				kX3qQnBINGg = CCSKzv3tpOnGd8D[CsPNhF9RD27K8GlcMOVZHq]
				klVhRojEu9H.FHEp9T3OzwUf6BSq(CsPNhF9RD27K8GlcMOVZHq,oszqtvpmB5XuaAPOwNMC6J,kX3qQnBINGg,*aargs)
			LNma2eq3vEguwVtHjn.sleep(Vi1oNCM5kI7yJ0(u"࠵࠴࠷࠶ᐞ"))
			CsPNhF9RD27K8GlcMOVZHq += Mn5NGAdz6xc42s0
			zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ๾")+kX3qQnBINGg+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠢࡠࠫ๿"))
		finishedLIST = klVhRojEu9H.finishedLIST
		if finishedLIST:
			resultsDICT = klVhRojEu9H.resultsDICT
			Fh2iPdkEUjCns5ITJqRvZc7fArbN6Q = finishedLIST[UwCT5Oz6Wo0BP]
			Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = resultsDICT[Fh2iPdkEUjCns5ITJqRvZc7fArbN6Q]
			kX3qQnBINGg = CCSKzv3tpOnGd8D[int(Fh2iPdkEUjCns5ITJqRvZc7fArbN6Q)]
			yUTYoAgth5iC43uLrdBH.setSetting(vGg1hAkzqi8exVbN(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ຀"),kX3qQnBINGg)
			if Fh2iPdkEUjCns5ITJqRvZc7fArbN6Q!=UwCT5Oz6Wo0BP: zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+E3i1eCBtN2w(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭ກ")+kX3qQnBINGg+IYC4iPxkTRUE85namF6(u"ࠫࠥࡣࠧຂ"))
			else: zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+x9PULjztJOpu7b(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ຃")+kX3qQnBINGg+eCpDE6wJtYUHn0GqK5(u"࠭ࠠ࡞ࠩຄ"))
	return Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO
def VIEvKBFz5SpRcCJN(HjtULpPZbT61odXq3iysh,OMq4tcorHv1Cu8Dk9GPmK7VwJe):
	Pwu7gckiqnhBKWJT4Me1GFQS9HbZ = HjtULpPZbT61odXq3iysh.create_connection
	def eer9msufN2CSqXk(wpkD2H7gQVXMJRvObP1UNWA3,*aargs,**kkwargs):
		ZDWVv9t3sPk,tDux5SleJq3AVIRwizXnWTLjNg = wpkD2H7gQVXMJRvObP1UNWA3
		ip = MWojhtvAgL8ikb0U7OrI(ZDWVv9t3sPk,OMq4tcorHv1Cu8Dk9GPmK7VwJe)
		if ip: ZDWVv9t3sPk = ip[UwCT5Oz6Wo0BP]
		else:
			if OMq4tcorHv1Cu8Dk9GPmK7VwJe in JYCuTUrNh3: JYCuTUrNh3.remove(OMq4tcorHv1Cu8Dk9GPmK7VwJe)
			if JYCuTUrNh3:
				HknMA1Z3Vxw = JYCuTUrNh3[UwCT5Oz6Wo0BP]
				ip = MWojhtvAgL8ikb0U7OrI(ZDWVv9t3sPk,HknMA1Z3Vxw)
				if ip: ZDWVv9t3sPk = ip[UwCT5Oz6Wo0BP]
		wpkD2H7gQVXMJRvObP1UNWA3 = (ZDWVv9t3sPk,tDux5SleJq3AVIRwizXnWTLjNg)
		return Pwu7gckiqnhBKWJT4Me1GFQS9HbZ(wpkD2H7gQVXMJRvObP1UNWA3,*aargs,**kkwargs)
	HjtULpPZbT61odXq3iysh.create_connection = eer9msufN2CSqXk
	return Pwu7gckiqnhBKWJT4Me1GFQS9HbZ
def NTtZKnOqaQUlxIpw0H1vy2f9(ZTG4ruxXUsc9N):
	VUx3GgT1eyu9B0YQJfDNjhK,IqCholi3SkN4 = ZTG4ruxXUsc9N.split(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧ࠰ࠩ຅"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],IK4zTnSMyGQpxEaesJAPVDY(u"࠾࠰ᐟ")
	if YXm2qAbu8Qsx(u"ࠨ࠼ࠪຆ") in VUx3GgT1eyu9B0YQJfDNjhK: VUx3GgT1eyu9B0YQJfDNjhK,IqCholi3SkN4 = VUx3GgT1eyu9B0YQJfDNjhK.split(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩ࠽ࠫງ"))
	i4WHRp26rk03h = ttC4VURALPYKh(u"ࠪ࠳ࠬຈ")+Vi1oNCM5kI7yJ0(u"ࠫ࠴࠭ຉ").join(ZTG4ruxXUsc9N.split(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࠵ࠧຊ"))[E3i1eCBtN2w(u"࠳ᐠ"):])
	YYAz8aPFGR2n = qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡇࡆࡖࠣࠫ຋")+i4WHRp26rk03h+ee3tnwl7avk(u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧຌ")
	YYAz8aPFGR2n += YXm2qAbu8Qsx(u"ࠨࡊࡲࡷࡹࡀࠠࠨຍ")+VUx3GgT1eyu9B0YQJfDNjhK+ykE045Tatx(u"ࠩ࡟ࡶࡡࡴࠧຎ")
	YYAz8aPFGR2n += jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡠࡷࡢ࡮ࠨຏ")
	from socket import socket as M8hdlBv4XYT,AF_INET as VF5hbdCzyiXtuJl,SOCK_STREAM as fLCvJouZB5d
	try:
		e9wUrAWq2V3ThOvCu1IkDioXzg = M8hdlBv4XYT(VF5hbdCzyiXtuJl,fLCvJouZB5d)
		e9wUrAWq2V3ThOvCu1IkDioXzg.connect((VUx3GgT1eyu9B0YQJfDNjhK,IqCholi3SkN4))
		e9wUrAWq2V3ThOvCu1IkDioXzg.send(YYAz8aPFGR2n.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
		AQKgLe9VrI5j = e9wUrAWq2V3ThOvCu1IkDioXzg.recv(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠶࠳࠽࠻ᐢ")*OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠲࠲࠵࠸ᐡ"))
		qHn7Qbi61UB = repr(AQKgLe9VrI5j)
	except: qHn7Qbi61UB = Zg9FeADE84jSRIvPCrzYulw3sL
	return qHn7Qbi61UB
def G9GCDqXJFAc(Rdzu9GfpV34XKq,TeDLBxpO03aonZFfQbNuK9S):
	if IYC4iPxkTRUE85namF6(u"ࠫ࠳࠭ຐ") not in Rdzu9GfpV34XKq: return Rdzu9GfpV34XKq
	Rdzu9GfpV34XKq = Rdzu9GfpV34XKq+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠵ࠧຑ")
	dECqH6MwKb3Dg5fhG8U2,ha2mj1qgD5R3J = Rdzu9GfpV34XKq.split(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭࠮ࠨຒ"),ttC4VURALPYKh(u"࠴ᐣ"))
	wa4Jnojc89,ej7JpA9PCfDWdoB2 = ha2mj1qgD5R3J.split(UixkloZbzGw28ujW56X(u"ࠧ࠰ࠩຓ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠵ᐤ"))
	hMOegX4Pb8EjJCUw96TiHZIp1k3t = dECqH6MwKb3Dg5fhG8U2+x9PULjztJOpu7b(u"ࠨ࠰ࠪດ")+wa4Jnojc89
	if TeDLBxpO03aonZFfQbNuK9S in [A2MHFvoqpZ64gNbB(u"ࠩ࡫ࡳࡸࡺࠧຕ"),IYC4iPxkTRUE85namF6(u"ࠪࡲࡦࡳࡥࠨຖ")] and okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫ࠴࠭ທ") in hMOegX4Pb8EjJCUw96TiHZIp1k3t: hMOegX4Pb8EjJCUw96TiHZIp1k3t = hMOegX4Pb8EjJCUw96TiHZIp1k3t.rsplit(ee3tnwl7avk(u"ࠬ࠵ࠧຘ"),IK4zTnSMyGQpxEaesJAPVDY(u"࠶ᐥ"))[Mn5NGAdz6xc42s0]
	if TeDLBxpO03aonZFfQbNuK9S==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭࡮ࡢ࡯ࡨࠫນ") and lU1fSmncFWjizwqZugyYBANML0(u"ࠧ࠯ࠩບ") in hMOegX4Pb8EjJCUw96TiHZIp1k3t:
		r1VaoACtyqwFPS9d8 = hMOegX4Pb8EjJCUw96TiHZIp1k3t.split(NIBsHMvSXb(u"ࠨ࠰ࠪປ"))
		b6pDh28nQRtHylFIf5C = len(r1VaoACtyqwFPS9d8)
		if zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧຜ") in hMOegX4Pb8EjJCUw96TiHZIp1k3t: r1VaoACtyqwFPS9d8 = IYC4iPxkTRUE85namF6(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨຝ")
		elif b6pDh28nQRtHylFIf5C<=DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: r1VaoACtyqwFPS9d8 = r1VaoACtyqwFPS9d8[UwCT5Oz6Wo0BP]
		elif b6pDh28nQRtHylFIf5C>=O4dklMvZ8ULcS: r1VaoACtyqwFPS9d8 = r1VaoACtyqwFPS9d8[Mn5NGAdz6xc42s0]
		if len(r1VaoACtyqwFPS9d8)>Mn5NGAdz6xc42s0: hMOegX4Pb8EjJCUw96TiHZIp1k3t = r1VaoACtyqwFPS9d8
	return hMOegX4Pb8EjJCUw96TiHZIp1k3t
def nWsGkOX74PMJ(Cz2nTVw9EUJ):
	KdOvHuRoT6yVFSgBqQ7i54Ex1se = repr(Cz2nTVw9EUJ.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).replace(x9PULjztJOpu7b(u"ࠦࠬࠨພ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	return KdOvHuRoT6yVFSgBqQ7i54Ex1se
def VikRx6TtEdzKFbBoeOHpSvg7PLlq(Eko54UI6sgMu):
	wEMHkmJuxgK = Zg9FeADE84jSRIvPCrzYulw3sL
	if HByjTem6EJP5sZb: Eko54UI6sgMu = Eko54UI6sgMu.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	from unicodedata import decomposition as SlNEv8bZReYo5yA2nrJX6Ux3g
	for Dk8WaRNHygK2mEXMO30sIL in Eko54UI6sgMu:
		if   Dk8WaRNHygK2mEXMO30sIL==DKmLTA2yGtj(u"ࡺ࠭ยࠨຟ"): R9Rfpic6dbhVCjMWkzUBoK = UixkloZbzGw28ujW56X(u"࠭࡜࡝ࡷ࠳࠺࠷࠸ࠧຠ")
		elif Dk8WaRNHygK2mEXMO30sIL==E3i1eCBtN2w(u"ࡵࠨลࠪມ"): R9Rfpic6dbhVCjMWkzUBoK = IK4zTnSMyGQpxEaesJAPVDY(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠴ࠩຢ")
		elif Dk8WaRNHygK2mEXMO30sIL==dn9ouNryjHiBFQOhASvX(u"ࡷࠪศࠬຣ"): R9Rfpic6dbhVCjMWkzUBoK = YXm2qAbu8Qsx(u"ࠪࡠࡡࡻ࠰࠷࠴࠷ࠫ຤")
		elif Dk8WaRNHygK2mEXMO30sIL==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࡹࠬหࠧລ"): R9Rfpic6dbhVCjMWkzUBoK = E3i1eCBtN2w(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠺࠭຦")
		elif Dk8WaRNHygK2mEXMO30sIL==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࡻࠧวࠩວ"): R9Rfpic6dbhVCjMWkzUBoK = vGg1hAkzqi8exVbN(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠶ࠨຨ")
		else:
			v5gwek2FDLzZNnUycEBTY39t = SlNEv8bZReYo5yA2nrJX6Ux3g(Dk8WaRNHygK2mEXMO30sIL)
			if wjs26GpVfNiCUERHJ in v5gwek2FDLzZNnUycEBTY39t: R9Rfpic6dbhVCjMWkzUBoK = vGg1hAkzqi8exVbN(u"ࠨ࡞࡟ࡹࠬຩ")+v5gwek2FDLzZNnUycEBTY39t.split(wjs26GpVfNiCUERHJ,Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
			else:
				R9Rfpic6dbhVCjMWkzUBoK = Vi1oNCM5kI7yJ0(u"ࠩ࠳࠴࠵࠶ࠧສ")+hex(ord(Dk8WaRNHygK2mEXMO30sIL)).replace(yNBjYsgc23xoW(u"ࠪ࠴ࡽ࠭ຫ"),Zg9FeADE84jSRIvPCrzYulw3sL)
				R9Rfpic6dbhVCjMWkzUBoK = Vi1oNCM5kI7yJ0(u"ࠫࡡࡢࡵࠨຬ")+R9Rfpic6dbhVCjMWkzUBoK[-NEc173Pr0jAwLF5OS:]
		wEMHkmJuxgK += R9Rfpic6dbhVCjMWkzUBoK
	wEMHkmJuxgK = wEMHkmJuxgK.replace(NIBsHMvSXb(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ອ"),ttC4VURALPYKh(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧຮ"))
	if HByjTem6EJP5sZb: wEMHkmJuxgK = wEMHkmJuxgK.decode(wFYiVd4r12x7CAQBL5SPof(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨຯ")).encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	else: wEMHkmJuxgK = wEMHkmJuxgK.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).decode(yNBjYsgc23xoW(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩະ"))
	return wEMHkmJuxgK
def EnxNsqevtM28mpkZ5RG0(header=jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩັ"),YYPIsEk1LfiFBZ38JlXVm=Zg9FeADE84jSRIvPCrzYulw3sL,Gzc6lbqhe8H=vvglE69OFKBm817Nkc,source=Zg9FeADE84jSRIvPCrzYulw3sL):
	xQXoDIqn4Ucsthb2G7YpzwPTymi = LlitnVydk9Q(header,YYPIsEk1LfiFBZ38JlXVm,type=HqjWaYEzp0D8eyQRud.INPUT_ALPHANUM)
	xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	if not xQXoDIqn4Ucsthb2G7YpzwPTymi and not Gzc6lbqhe8H:
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,x9PULjztJOpu7b(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠼ࠣࠤࠥࠨࠧາ")+xQXoDIqn4Ucsthb2G7YpzwPTymi+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࠧ࠭ຳ"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨິ"),dn9ouNryjHiBFQOhASvX(u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩີ"))
		return Zg9FeADE84jSRIvPCrzYulw3sL
	if xQXoDIqn4Ucsthb2G7YpzwPTymi not in [Zg9FeADE84jSRIvPCrzYulw3sL,wjs26GpVfNiCUERHJ]:
		xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.strip(wjs26GpVfNiCUERHJ)
		xQXoDIqn4Ucsthb2G7YpzwPTymi = VikRx6TtEdzKFbBoeOHpSvg7PLlq(xQXoDIqn4Ucsthb2G7YpzwPTymi)
	if source!=IYC4iPxkTRUE85namF6(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩຶ") and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪື"),Zg9FeADE84jSRIvPCrzYulw3sL,[xQXoDIqn4Ucsthb2G7YpzwPTymi],vvglE69OFKBm817Nkc):
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,yNBjYsgc23xoW(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ຸࠡࠢࠣࠦࠬ")+xQXoDIqn4Ucsthb2G7YpzwPTymi+yNBjYsgc23xoW(u"ູࠪࠦࠬ"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า຺ࠧ"),YXm2qAbu8Qsx(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧົ"))
		return Zg9FeADE84jSRIvPCrzYulw3sL
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,dn9ouNryjHiBFQOhASvX(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩຼ")+xQXoDIqn4Ucsthb2G7YpzwPTymi+IYC4iPxkTRUE85namF6(u"ࠧࠣࠩຽ"))
	return xQXoDIqn4Ucsthb2G7YpzwPTymi
def zKaqs0n5ZdrvWSTJYhy7(hc5ePKxl4LJvEjDgTm,Y3OmVPp2ARgBCjn={}):
	ZTG4ruxXUsc9N,GFY2RTKWrfpJ48dNLPAxhXCqaVyv,Ne4k6g70sUroCTiSVQ,wi1aA0gGCJ9fWeOQPy52RjI = hc5ePKxl4LJvEjDgTm,{},{},Zg9FeADE84jSRIvPCrzYulw3sL
	if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡾࠪ຾") in hc5ePKxl4LJvEjDgTm: ZTG4ruxXUsc9N,GFY2RTKWrfpJ48dNLPAxhXCqaVyv = I28IrfmVwu4JkOXhGB(hc5ePKxl4LJvEjDgTm,UixkloZbzGw28ujW56X(u"ࠩࡿࠫ຿"))
	ksNdD5LMYTOZhQpzEc = list(set(list(Y3OmVPp2ARgBCjn.keys())+list(GFY2RTKWrfpJ48dNLPAxhXCqaVyv.keys())))
	for aOf4PbHpSiUm6eGDA1u0ky5wMvdln in ksNdD5LMYTOZhQpzEc:
		if aOf4PbHpSiUm6eGDA1u0ky5wMvdln in list(GFY2RTKWrfpJ48dNLPAxhXCqaVyv.keys()): Ne4k6g70sUroCTiSVQ[aOf4PbHpSiUm6eGDA1u0ky5wMvdln] = GFY2RTKWrfpJ48dNLPAxhXCqaVyv[aOf4PbHpSiUm6eGDA1u0ky5wMvdln]
		else: Ne4k6g70sUroCTiSVQ[aOf4PbHpSiUm6eGDA1u0ky5wMvdln] = Y3OmVPp2ARgBCjn[aOf4PbHpSiUm6eGDA1u0ky5wMvdln]
	if vGg1hAkzqi8exVbN(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧເ") not in ksNdD5LMYTOZhQpzEc: Ne4k6g70sUroCTiSVQ[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨແ")] = lAfzvsbYy7oQ3r28EMe()
	if eCpDE6wJtYUHn0GqK5(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ໂ") not in ksNdD5LMYTOZhQpzEc: Ne4k6g70sUroCTiSVQ[Vi1oNCM5kI7yJ0(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧໃ")] = G9GCDqXJFAc(ZTG4ruxXUsc9N,yNBjYsgc23xoW(u"ࠧࡶࡴ࡯ࠫໄ"))
	if x9PULjztJOpu7b(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ໅") not in ksNdD5LMYTOZhQpzEc: Ne4k6g70sUroCTiSVQ[ttC4VURALPYKh(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫໆ")] = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫ໇")
	for aOf4PbHpSiUm6eGDA1u0ky5wMvdln in list(Ne4k6g70sUroCTiSVQ.keys()): wi1aA0gGCJ9fWeOQPy52RjI += NIBsHMvSXb(u"່ࠫࠫ࠭")+aOf4PbHpSiUm6eGDA1u0ky5wMvdln+IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡃ້ࠧ")+Ne4k6g70sUroCTiSVQ[aOf4PbHpSiUm6eGDA1u0ky5wMvdln]
	if wi1aA0gGCJ9fWeOQPy52RjI: wi1aA0gGCJ9fWeOQPy52RjI = eCpDE6wJtYUHn0GqK5(u"࠭ࡼࠨ໊")+wi1aA0gGCJ9fWeOQPy52RjI[Mn5NGAdz6xc42s0:]
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,JP65RzKaScIf(u"ࠧࡈࡇࡗ໋ࠫ"),ZTG4ruxXUsc9N,Zg9FeADE84jSRIvPCrzYulw3sL,Ne4k6g70sUroCTiSVQ,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ໌"),vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
	if ee3tnwl7avk(u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭ໍ") not in qHn7Qbi61UB: return [OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪ࠱࠶࠭໎")],[ZTG4ruxXUsc9N+wi1aA0gGCJ9fWeOQPy52RjI]
	if UQS9lVew50DIyXrinWsMxTzA(u"࡙ࠫ࡟ࡐࡆ࠿ࡄ࡙ࡉࡏࡏࠨ໏") in qHn7Qbi61UB: return [A2MHFvoqpZ64gNbB(u"ࠬ࠳࠱ࠨ໐")],[ZTG4ruxXUsc9N+wi1aA0gGCJ9fWeOQPy52RjI]
	if A2MHFvoqpZ64gNbB(u"࠭ࡔ࡚ࡒࡈࡁ࡛ࡏࡄࡆࡑࠪ໑") in qHn7Qbi61UB: return [wFYiVd4r12x7CAQBL5SPof(u"ࠧ࠮࠳ࠪ໒")],[ZTG4ruxXUsc9N+wi1aA0gGCJ9fWeOQPy52RjI]
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,FFgcjplT5JvhNntUHSR3uLQxaAY,jUYgQTPeWih0rVwqIlpKGx2Rv5 = [],[],[],[]
	nRTS1iIwBy0MrzcuXDqH8kOC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠩ໓"),qHn7Qbi61UB+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not nRTS1iIwBy0MrzcuXDqH8kOC: return [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ࠰࠵ࠬ໔")],[ZTG4ruxXUsc9N+wi1aA0gGCJ9fWeOQPy52RjI]
	for zXbvQ6ajdGw1kYI,Rdzu9GfpV34XKq in nRTS1iIwBy0MrzcuXDqH8kOC:
		N3pROjkJKXQ6ro1,W8M9s7e13Gf2LkyDmPdjlxQAaC,YUCPADxT3NrgM = {},-eCpDE6wJtYUHn0GqK5(u"࠷ᐦ"),-eCpDE6wJtYUHn0GqK5(u"࠷ᐦ")
		ACzNhmQyIe0jU = Zg9FeADE84jSRIvPCrzYulw3sL
		l4wQZn2ebMpNr9H7cvhiGgXWLURj = zXbvQ6ajdGw1kYI.split(E3i1eCBtN2w(u"ࠪ࠰ࠬ໕"))
		for dczJa6f5mpR in l4wQZn2ebMpNr9H7cvhiGgXWLURj:
			if jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡂ࠭໖") in dczJa6f5mpR:
				aOf4PbHpSiUm6eGDA1u0ky5wMvdln,qYpW1vyJKaeTI3P7tF0oLXR2r = dczJa6f5mpR.split(DKmLTA2yGtj(u"ࠬࡃࠧ໗"),yNBjYsgc23xoW(u"࠱ᐧ"))
				N3pROjkJKXQ6ro1[aOf4PbHpSiUm6eGDA1u0ky5wMvdln.lower()] = qYpW1vyJKaeTI3P7tF0oLXR2r
		if qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ໘") in zXbvQ6ajdGw1kYI.lower():
			W8M9s7e13Gf2LkyDmPdjlxQAaC = int(N3pROjkJKXQ6ro1[dn9ouNryjHiBFQOhASvX(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ໙")])//zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠲࠲࠵࠸ᐨ")
			ACzNhmQyIe0jU += str(W8M9s7e13Gf2LkyDmPdjlxQAaC)+qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ໚")
		elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ໛") in zXbvQ6ajdGw1kYI.lower():
			W8M9s7e13Gf2LkyDmPdjlxQAaC = int(N3pROjkJKXQ6ro1[YXm2qAbu8Qsx(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ໜ")])//E3i1eCBtN2w(u"࠳࠳࠶࠹ᐩ")
			ACzNhmQyIe0jU += str(W8M9s7e13Gf2LkyDmPdjlxQAaC)+ykE045Tatx(u"ࠫࡰࡨࡰࡴࠢࠣࠫໝ")
		if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩໞ") in zXbvQ6ajdGw1kYI.lower():
			YUCPADxT3NrgM = int(N3pROjkJKXQ6ro1[ZYTyoA483N(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪໟ")].split(lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡹࠩ໠"))[Mn5NGAdz6xc42s0])
			ACzNhmQyIe0jU += str(YUCPADxT3NrgM)+F4skx1A3wOEh9lmPuZMnpCzR
		ACzNhmQyIe0jU = ACzNhmQyIe0jU.strip(F4skx1A3wOEh9lmPuZMnpCzR)
		if not ACzNhmQyIe0jU: ACzNhmQyIe0jU = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ໡")
		if not Rdzu9GfpV34XKq.startswith(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩ࡫ࡸࡹࡶࠧ໢")):
			if Rdzu9GfpV34XKq.startswith(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪ࠳࠴࠭໣")): Rdzu9GfpV34XKq = ZTG4ruxXUsc9N.split(ReLGYUQjz7C9iEd(u"ࠫ࠿࠭໤"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]+IYC4iPxkTRUE85namF6(u"ࠬࡀࠧ໥")+Rdzu9GfpV34XKq
			elif Rdzu9GfpV34XKq.startswith(E3i1eCBtN2w(u"࠭࠯ࠨ໦")): Rdzu9GfpV34XKq = G9GCDqXJFAc(ZTG4ruxXUsc9N,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡶࡴ࡯ࠫ໧"))+Rdzu9GfpV34XKq
			else: Rdzu9GfpV34XKq = ZTG4ruxXUsc9N.rsplit(ReLGYUQjz7C9iEd(u"ࠨ࠱ࠪ໨"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]+x9PULjztJOpu7b(u"ࠩ࠲ࠫ໩")+Rdzu9GfpV34XKq
		if ZYTyoA483N(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ໪") in list(N3pROjkJKXQ6ro1.keys()):
			WOry7DZPocFhH8p4 = N3pROjkJKXQ6ro1[lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭໫")]
			WOry7DZPocFhH8p4 = WOry7DZPocFhH8p4.replace(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࠨࠧ໬"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(UQS9lVew50DIyXrinWsMxTzA(u"ࠨࠧࠣ໭"),Zg9FeADE84jSRIvPCrzYulw3sL).split(UixkloZbzGw28ujW56X(u"ࠧࠤࠩ໮"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
			uVqMYescRCnSJyDlF7Hb = wzX1klOfLVhb2B4ita(WOry7DZPocFhH8p4)
			if uVqMYescRCnSJyDlF7Hb: wUpHn5IfzaQ8g4j = ACzNhmQyIe0jU+F4skx1A3wOEh9lmPuZMnpCzR+uVqMYescRCnSJyDlF7Hb
			else: wUpHn5IfzaQ8g4j = ACzNhmQyIe0jU
			wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j+Vi1oNCM5kI7yJ0(u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ໯")
			wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j+F4skx1A3wOEh9lmPuZMnpCzR+G9GCDqXJFAc(WOry7DZPocFhH8p4,Vi1oNCM5kI7yJ0(u"ࠩࡱࡥࡲ࡫ࠧ໰"))
			nnhWEIa6Tm.append(wUpHn5IfzaQ8g4j)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(WOry7DZPocFhH8p4)
			FFgcjplT5JvhNntUHSR3uLQxaAY.append(YUCPADxT3NrgM)
			jUYgQTPeWih0rVwqIlpKGx2Rv5.append(W8M9s7e13Gf2LkyDmPdjlxQAaC)
		Rdzu9GfpV34XKq = Rdzu9GfpV34XKq.split(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࠧࠬ໱"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
		uVqMYescRCnSJyDlF7Hb = wzX1klOfLVhb2B4ita(Rdzu9GfpV34XKq)
		if uVqMYescRCnSJyDlF7Hb: ACzNhmQyIe0jU = ACzNhmQyIe0jU+F4skx1A3wOEh9lmPuZMnpCzR+uVqMYescRCnSJyDlF7Hb
		ACzNhmQyIe0jU = ACzNhmQyIe0jU+F4skx1A3wOEh9lmPuZMnpCzR+G9GCDqXJFAc(Rdzu9GfpV34XKq,eCpDE6wJtYUHn0GqK5(u"ࠫࡳࡧ࡭ࡦࠩ໲"))
		nnhWEIa6Tm.append(ACzNhmQyIe0jU)
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(Rdzu9GfpV34XKq)
		FFgcjplT5JvhNntUHSR3uLQxaAY.append(YUCPADxT3NrgM)
		jUYgQTPeWih0rVwqIlpKGx2Rv5.append(W8M9s7e13Gf2LkyDmPdjlxQAaC)
	F5nZmIVxBz3 = list(zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,FFgcjplT5JvhNntUHSR3uLQxaAY,jUYgQTPeWih0rVwqIlpKGx2Rv5))
	F5nZmIVxBz3 = sorted(F5nZmIVxBz3, reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy, key=lambda key: key[O4dklMvZ8ULcS])
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,FFgcjplT5JvhNntUHSR3uLQxaAY,jUYgQTPeWih0rVwqIlpKGx2Rv5 = list(zip(*F5nZmIVxBz3))
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = list(nnhWEIa6Tm),list(fo6s53yEnbklLpaJOzgR4Q01wxB)
	A7TBFRkU8Q3 = []
	for Rdzu9GfpV34XKq in fo6s53yEnbklLpaJOzgR4Q01wxB: A7TBFRkU8Q3.append(Rdzu9GfpV34XKq+wi1aA0gGCJ9fWeOQPy52RjI)
	return nnhWEIa6Tm,A7TBFRkU8Q3
def MWojhtvAgL8ikb0U7OrI(ZDWVv9t3sPk,OMq4tcorHv1Cu8Dk9GPmK7VwJe=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not OMq4tcorHv1Cu8Dk9GPmK7VwJe: OMq4tcorHv1Cu8Dk9GPmK7VwJe = JYCuTUrNh3[UwCT5Oz6Wo0BP]
	if ZDWVv9t3sPk.replace(ReLGYUQjz7C9iEd(u"ࠬ࠴ࠧ໳"),Zg9FeADE84jSRIvPCrzYulw3sL).isdigit(): return [ZDWVv9t3sPk]
	from struct import pack as O317uaw0Zm4nJAqK6NWP,unpack_from as Aq7wIjNZR3QT4eJriKc
	from socket import socket as M8hdlBv4XYT,AF_INET as VF5hbdCzyiXtuJl,SOCK_DGRAM as p6U1wFSKiGxnZt9d02Co4THzE7I
	try:
		WWyETLZihpXxrom3sl9 = O317uaw0Zm4nJAqK6NWP(E3i1eCBtN2w(u"ࠨ࠾ࡉࠤ໴"), JP65RzKaScIf(u"࠴࠶࠵࠺࠹ᐪ"))
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(IK4zTnSMyGQpxEaesJAPVDY(u"ࠢ࠿ࡊࠥ໵"), zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠶࠺࠼ᐫ"))
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(vhZ5qjay1z94JmcMOgXe(u"ࠣࡀࡋࠦ໶"), Mn5NGAdz6xc42s0)
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(JP65RzKaScIf(u"ࠤࡁࡌࠧ໷"), UwCT5Oz6Wo0BP)
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(vhZ5qjay1z94JmcMOgXe(u"ࠥࡂࡍࠨ໸"), UwCT5Oz6Wo0BP)
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(UixkloZbzGw28ujW56X(u"ࠦࡃࡎࠢ໹"), UwCT5Oz6Wo0BP)
		if GGfPQnrJKEqMv2ZVxdD: rIqcdlf7xBjOzDgte4S9u = ZDWVv9t3sPk.split(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬ࠴ࠧ໺"))
		else: rIqcdlf7xBjOzDgte4S9u = ZDWVv9t3sPk.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).split(x9PULjztJOpu7b(u"࠭࠮ࠨ໻"))
		for nnZdjbXLQalIDAe9yhpwt1GuYRPB in rIqcdlf7xBjOzDgte4S9u:
			CCXmO8KQyFpSVaNeI1qlf5sj = nnZdjbXLQalIDAe9yhpwt1GuYRPB.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(eCpDE6wJtYUHn0GqK5(u"ࠢࡃࠤ໼"), len(nnZdjbXLQalIDAe9yhpwt1GuYRPB))
			for ooxM0h61Vv in nnZdjbXLQalIDAe9yhpwt1GuYRPB:
				WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠣࡥࠥ໽"), ooxM0h61Vv.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(Vi1oNCM5kI7yJ0(u"ࠤࡅࠦ໾"), UwCT5Oz6Wo0BP)
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(ZYTyoA483N(u"ࠥࡂࡍࠨ໿"), Mn5NGAdz6xc42s0)
		WWyETLZihpXxrom3sl9 += O317uaw0Zm4nJAqK6NWP(DKmLTA2yGtj(u"ࠦࡃࡎࠢༀ"), Mn5NGAdz6xc42s0)
		LseNYDPrtFkWEo5I7bjcxwG = M8hdlBv4XYT(VF5hbdCzyiXtuJl,p6U1wFSKiGxnZt9d02Co4THzE7I)
		LseNYDPrtFkWEo5I7bjcxwG.sendto(bytes(WWyETLZihpXxrom3sl9), (OMq4tcorHv1Cu8Dk9GPmK7VwJe, ykE045Tatx(u"࠺࠹ᐬ")))
		LseNYDPrtFkWEo5I7bjcxwG.settimeout(YXm2qAbu8Qsx(u"࠼ᐭ"))
		WR7gIlwo5ik9zJv3CK4sS, g2bTOFqhaxHMvNj3ERW6KXk8n5edI = LseNYDPrtFkWEo5I7bjcxwG.recvfrom(ttC4VURALPYKh(u"࠱࠱࠴࠷ᐮ"))
		LseNYDPrtFkWEo5I7bjcxwG.close()
		U37OxJuvLAgBdzH = Aq7wIjNZR3QT4eJriKc(ttC4VURALPYKh(u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ༁"), WR7gIlwo5ik9zJv3CK4sS, UwCT5Oz6Wo0BP)
		o3gLUlmHZxP2pWYF = U37OxJuvLAgBdzH[O4dklMvZ8ULcS]
		y3uHZvinPtB = len(ZDWVv9t3sPk)+IK4zTnSMyGQpxEaesJAPVDY(u"࠲࠺ᐯ")
		GvIoOFAXCU63fVTHK452NEexq = []
		for _1fwSkNYOv6sQFluPWetM32DI9 in range(o3gLUlmHZxP2pWYF):
			SPRgWseDXyZuQLTVoCJFd = y3uHZvinPtB
			uiT2jI0QZdmPK = Mn5NGAdz6xc42s0
			rULHKSYyD0w4sFc6bV7NMpke = vvglE69OFKBm817Nkc
			while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
				ooxM0h61Vv = Aq7wIjNZR3QT4eJriKc(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨ࠾ࡃࠤ༂"), WR7gIlwo5ik9zJv3CK4sS, SPRgWseDXyZuQLTVoCJFd)[UwCT5Oz6Wo0BP]
				if ooxM0h61Vv == UwCT5Oz6Wo0BP:
					SPRgWseDXyZuQLTVoCJFd += Mn5NGAdz6xc42s0
					break
				if ooxM0h61Vv >= ee3tnwl7avk(u"࠳࠼࠶ᐰ"):
					j9KvHyQGtu = Aq7wIjNZR3QT4eJriKc(vhZ5qjay1z94JmcMOgXe(u"ࠢ࠿ࡄࠥ༃"), WR7gIlwo5ik9zJv3CK4sS, SPRgWseDXyZuQLTVoCJFd + Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
					SPRgWseDXyZuQLTVoCJFd = ((ooxM0h61Vv << IYC4iPxkTRUE85namF6(u"࠻ᐱ")) + j9KvHyQGtu - 0xc000) - Mn5NGAdz6xc42s0
					rULHKSYyD0w4sFc6bV7NMpke = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				SPRgWseDXyZuQLTVoCJFd += Mn5NGAdz6xc42s0
				if rULHKSYyD0w4sFc6bV7NMpke == vvglE69OFKBm817Nkc: uiT2jI0QZdmPK += Mn5NGAdz6xc42s0
			if rULHKSYyD0w4sFc6bV7NMpke == CR6in9cZKo2SqGFmrHOLdhYEVTjsBy: uiT2jI0QZdmPK += Mn5NGAdz6xc42s0
			y3uHZvinPtB = y3uHZvinPtB + uiT2jI0QZdmPK
			q8P96fTXicYzHK = Aq7wIjNZR3QT4eJriKc(lU1fSmncFWjizwqZugyYBANML0(u"ࠣࡀࡋࡌࡎࡎࠢ༄"), WR7gIlwo5ik9zJv3CK4sS, y3uHZvinPtB)
			y3uHZvinPtB = y3uHZvinPtB + IYC4iPxkTRUE85namF6(u"࠵࠵ᐲ")
			imQ9VpRysAoBqWTa0UX = q8P96fTXicYzHK[UwCT5Oz6Wo0BP]
			L2415XQo6Fm80hkTfHYpcn9JrUuxdw = q8P96fTXicYzHK[O4dklMvZ8ULcS]
			if imQ9VpRysAoBqWTa0UX == Mn5NGAdz6xc42s0:
				Vf7WolGwjaCNp6hR1rt2QP = Aq7wIjNZR3QT4eJriKc(yyZPkLCRX1xcBDN(u"ࠤࡁࠦ༅")+yyZPkLCRX1xcBDN(u"ࠥࡆࠧ༆")*L2415XQo6Fm80hkTfHYpcn9JrUuxdw, WR7gIlwo5ik9zJv3CK4sS, y3uHZvinPtB)
				ip = Zg9FeADE84jSRIvPCrzYulw3sL
				for ooxM0h61Vv in Vf7WolGwjaCNp6hR1rt2QP: ip += str(ooxM0h61Vv) + tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࠳࠭༇")
				ip = ip[UwCT5Oz6Wo0BP:-Mn5NGAdz6xc42s0]
				GvIoOFAXCU63fVTHK452NEexq.append(ip)
			if imQ9VpRysAoBqWTa0UX in [Mn5NGAdz6xc42s0,DpahB8cwl4ZeKVsg71RuibSAfx0Ejr,E3i1eCBtN2w(u"࠵ᐵ"),DKmLTA2yGtj(u"࠷ᐶ"),yyZPkLCRX1xcBDN(u"࠷࠵ᐴ"),ttC4VURALPYKh(u"࠷࠾ᐳ")]: y3uHZvinPtB = y3uHZvinPtB + L2415XQo6Fm80hkTfHYpcn9JrUuxdw
	except: GvIoOFAXCU63fVTHK452NEexq = []
	if not GvIoOFAXCU63fVTHK452NEexq: zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+DKmLTA2yGtj(u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ༈")+ZDWVv9t3sPk+yyZPkLCRX1xcBDN(u"࠭ࠠ࡞ࠩ༉"))
	return GvIoOFAXCU63fVTHK452NEexq
def aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,ZTG4ruxXUsc9N,XgmQ1lh8HcUNPEiajL50,showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	if XgmQ1lh8HcUNPEiajL50:
		O0Os5C3JEFruxN21Aalnc = [wFYiVd4r12x7CAQBL5SPof(u"ࠧไสสีࠬ༊"),JP65RzKaScIf(u"ࠨสส่฿࠭་"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡤࡨࡺࡲࡴࠨ༌"),ykE045Tatx(u"ࠪࡼࡽ࠭།"),vGg1hAkzqi8exVbN(u"ࠫࡸ࡫ࡸࠨ༎")]
		if bIPsOxjEpoH!=NIBsHMvSXb(u"ࠬࡈࡏࡌࡔࡄࠫ༏"):
			O0Os5C3JEFruxN21Aalnc += [x9PULjztJOpu7b(u"࠭ࡲ࠻ࠩ༐"),A2MHFvoqpZ64gNbB(u"ࠧࡳ࠯ࠪ༑"),Vi1oNCM5kI7yJ0(u"ࠨ࠯ࡰࡥࠬ༒")]
			O0Os5C3JEFruxN21Aalnc += [dn9ouNryjHiBFQOhASvX(u"ࠩ࠽ࡶࠬ༓"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠪ࠱ࡷ࠭༔"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡲࡧ࠭ࠨ༕")]
		for KeSlIpkUvPOfbaQVsu89EJB0gy in XgmQ1lh8HcUNPEiajL50:
			if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ༖") in KeSlIpkUvPOfbaQVsu89EJB0gy: continue
			if jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭อๅไฬࠫ༗") in KeSlIpkUvPOfbaQVsu89EJB0gy: continue
			KeSlIpkUvPOfbaQVsu89EJB0gy = KeSlIpkUvPOfbaQVsu89EJB0gy.lower()
			if HByjTem6EJP5sZb: KeSlIpkUvPOfbaQVsu89EJB0gy = KeSlIpkUvPOfbaQVsu89EJB0gy.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			KeSlIpkUvPOfbaQVsu89EJB0gy = KeSlIpkUvPOfbaQVsu89EJB0gy.replace(ZYTyoA483N(u"ࠧ࠻༘ࠩ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			uumHnTGckFy3UZLKV9hA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮༙࠭ࠬ"),KeSlIpkUvPOfbaQVsu89EJB0gy,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			eOqCMtSrhTKNz93bw75VunPyH2 = vvglE69OFKBm817Nkc
			for B6hTQmANc03k7rHWwoIsiJ in uumHnTGckFy3UZLKV9hA:
				if len(B6hTQmANc03k7rHWwoIsiJ)==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
					eOqCMtSrhTKNz93bw75VunPyH2 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					break
			if E3i1eCBtN2w(u"ࠩࡱࡳࡹࠦࡲࡢࡶࡨࡨࠬ༚") in KeSlIpkUvPOfbaQVsu89EJB0gy: continue
			elif OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡹࡳࡸࡡࡵࡧࡧࠫ༛") in KeSlIpkUvPOfbaQVsu89EJB0gy: continue
			elif ZYTyoA483N(u"ࠫ฿๐ัࠡ็ุ๊ๆ࠭༜") in KeSlIpkUvPOfbaQVsu89EJB0gy: continue
			elif ZE3oYw0NMipGVt1zJ8yAULgq7nbdx([jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡲࡖࡅࡘࡈ࡚ࡊ࡞ࠧ༝")])[UwCT5Oz6Wo0BP]: continue
			elif KeSlIpkUvPOfbaQVsu89EJB0gy in [IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡲࠨ༞")] or eOqCMtSrhTKNz93bw75VunPyH2 or any(B251BPiLbvG9UxszKtlI7YQHmoWw in KeSlIpkUvPOfbaQVsu89EJB0gy for B251BPiLbvG9UxszKtlI7YQHmoWw in O0Os5C3JEFruxN21Aalnc):
				zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+UixkloZbzGw28ujW56X(u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭༟")+ZTG4ruxXUsc9N+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࠢࡠࠫ༠"))
				if showDialogs: ZXWeI01flR(eCpDE6wJtYUHn0GqK5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ༡"),YXm2qAbu8Qsx(u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ༢"))
				return CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return vvglE69OFKBm817Nkc
def I3kpd28CgLtrVEcuAXiZ(*aargs,**kkwargs):
	if aargs:
		direction = aargs[UwCT5Oz6Wo0BP]
		kJpxMN8ctml0RnvywseTufj = aargs[Mn5NGAdz6xc42s0]
		if not direction: direction = vhZ5qjay1z94JmcMOgXe(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ༣")
		if not kJpxMN8ctml0RnvywseTufj: kJpxMN8ctml0RnvywseTufj = A2MHFvoqpZ64gNbB(u"ࠬอำห็ิหึ࠭༤")
		RRK9d6LeC5nglHWwEYcZyFTXUzf = aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		xQXoDIqn4Ucsthb2G7YpzwPTymi = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO.join(aargs[vGg1hAkzqi8exVbN(u"࠵ᐷ"):])
	else: direction,kJpxMN8ctml0RnvywseTufj,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi = Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"࠭ࡏࡌࠩ༥"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	wCuDBb85Gjl36RAQnUEZd(direction,Zg9FeADE84jSRIvPCrzYulw3sL,kJpxMN8ctml0RnvywseTufj,Zg9FeADE84jSRIvPCrzYulw3sL,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,**kkwargs)
	return
def EiOpncsbPr8qQzGodeW(*aargs,**kkwargs):
	direction = aargs[UwCT5Oz6Wo0BP]
	Kgrv385CWw = aargs[Mn5NGAdz6xc42s0]
	ddH9KyrA7XNzJs6wlcSa0imRkBbvq = aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
	if ddH9KyrA7XNzJs6wlcSa0imRkBbvq or Kgrv385CWw: hrPiGl4jyMYmuwZCE6Q = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else: hrPiGl4jyMYmuwZCE6Q = vvglE69OFKBm817Nkc
	RRK9d6LeC5nglHWwEYcZyFTXUzf = aargs[O4dklMvZ8ULcS]
	xQXoDIqn4Ucsthb2G7YpzwPTymi = aargs[NEc173Pr0jAwLF5OS]
	if not direction: direction = ZYTyoA483N(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༦")
	if not Kgrv385CWw: Kgrv385CWw = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨๅ็หࠥࠦࡎࡰࠩ༧")
	if not ddH9KyrA7XNzJs6wlcSa0imRkBbvq: ddH9KyrA7XNzJs6wlcSa0imRkBbvq = yyZPkLCRX1xcBDN(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫ༨")
	if len(aargs)>=eCpDE6wJtYUHn0GqK5(u"࠺ᐹ"): xQXoDIqn4Ucsthb2G7YpzwPTymi += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+aargs[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠸ᐸ")]
	if len(aargs)>=UQS9lVew50DIyXrinWsMxTzA(u"࠼ᐺ"): xQXoDIqn4Ucsthb2G7YpzwPTymi += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+aargs[E3i1eCBtN2w(u"࠼ᐻ")]
	mQOFUVBbfyv39kzto0Nw4 = wCuDBb85Gjl36RAQnUEZd(direction,Kgrv385CWw,Zg9FeADE84jSRIvPCrzYulw3sL,ddH9KyrA7XNzJs6wlcSa0imRkBbvq,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,**kkwargs)
	if mQOFUVBbfyv39kzto0Nw4==-tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱ᐼ") and hrPiGl4jyMYmuwZCE6Q: mQOFUVBbfyv39kzto0Nw4 = -Mn5NGAdz6xc42s0
	elif mQOFUVBbfyv39kzto0Nw4==-Mn5NGAdz6xc42s0 and not hrPiGl4jyMYmuwZCE6Q: mQOFUVBbfyv39kzto0Nw4 = vvglE69OFKBm817Nkc
	elif mQOFUVBbfyv39kzto0Nw4==UwCT5Oz6Wo0BP: mQOFUVBbfyv39kzto0Nw4 = vvglE69OFKBm817Nkc
	elif mQOFUVBbfyv39kzto0Nw4==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: mQOFUVBbfyv39kzto0Nw4 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return mQOFUVBbfyv39kzto0Nw4
def WXZLgSfpV2jzRFTNiyroc(*aargs,**kkwargs):
	return HqjWaYEzp0D8eyQRud.Dialog().select(*aargs,**kkwargs)
def ZXWeI01flR(*aargs,**kkwargs):
	RRK9d6LeC5nglHWwEYcZyFTXUzf = aargs[UwCT5Oz6Wo0BP]
	xQXoDIqn4Ucsthb2G7YpzwPTymi = aargs[Mn5NGAdz6xc42s0]
	qumsGVnaObw = kkwargs[UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡸ࡮ࡳࡥࠨ༩")] if vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡹ࡯࡭ࡦࠩ༪") in list(kkwargs.keys()) else vGg1hAkzqi8exVbN(u"࠲࠲࠳࠴ᐽ")
	WWy3F9gxjuQiaAhkRTJ = aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr] if len(aargs)>DpahB8cwl4ZeKVsg71RuibSAfx0Ejr and KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡺࡩ࡮ࡧࠪ༫") not in aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr] else ttC4VURALPYKh(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭༬")
	CeD3lAx2yJsohLZSVTBpWq = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=nnXpJRDyFVx6K9utoU,args=(RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,WWy3F9gxjuQiaAhkRTJ,qumsGVnaObw))
	CeD3lAx2yJsohLZSVTBpWq.start()
	return
def nnXpJRDyFVx6K9utoU(RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,WWy3F9gxjuQiaAhkRTJ,qumsGVnaObw):
	qGEnAHvwpVD = WWy3F9gxjuQiaAhkRTJ.replace(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࠧ༭"),Zg9FeADE84jSRIvPCrzYulw3sL)
	name = pVZOH6lyXU(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,qGEnAHvwpVD+Vi1oNCM5kI7yJ0(u"ࠨࠢ࠰ࠤࠬ༮")+RRK9d6LeC5nglHWwEYcZyFTXUzf+eCpDE6wJtYUHn0GqK5(u"ࠩࠣ࠱ࠥ࠭༯")+xQXoDIqn4Ucsthb2G7YpzwPTymi)
	name = MwKxpYbB1gfk6RWQhl5F0sOAH4(name)
	image_filename = brAUlZfdFmt3TRJW2xX4.path.join(GZ9SnzDsABJW,name+dn9ouNryjHiBFQOhASvX(u"ࠪ࠲ࡵࡴࡧࠨ༰"))
	if brAUlZfdFmt3TRJW2xX4.path.exists(image_filename):
		if WWy3F9gxjuQiaAhkRTJ==UixkloZbzGw28ujW56X(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡶࡪ࡭ࡵ࡭ࡣࡵࠫ༱"): image_height = NIBsHMvSXb(u"࠳࠴࠻ᐾ")
		elif WWy3F9gxjuQiaAhkRTJ==NIBsHMvSXb(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡦࡻࡴࡰࠩ༲"): image_height = JP65RzKaScIf(u"࠵࠵࠵ᐿ")
	else: image_height = BEf8XIaMFVmj(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,WWy3F9gxjuQiaAhkRTJ,ReLGYUQjz7C9iEd(u"࠭࡬ࡦࡨࡷࠫ༳"),vvglE69OFKBm817Nkc,image_filename)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM = j9ldCL3Ibp(ZYTyoA483N(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧ༴"),SSWrcswxYdB9p,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵ༵ࠩ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩ࠺࠶࠵ࡶࠧ༶"))
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.show()
	if WWy3F9gxjuQiaAhkRTJ==Vi1oNCM5kI7yJ0(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵ༷ࠧ"):
		qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠾࠶࠴࠱ᑁ")).setHeight(yyZPkLCRX1xcBDN(u"࠶࠶࠻ᑀ"))
		qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(YXm2qAbu8Qsx(u"࠺࠲࠷࠴ᑄ")).setPosition(YXm2qAbu8Qsx(u"࠻࠵ᑂ"),-IK4zTnSMyGQpxEaesJAPVDY(u"࠸࠱ᑃ"))
		qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠻࠳࠹࠵ᑅ")).setPosition(DKmLTA2yGtj(u"࠴࠶࠵ᑆ"),-DKmLTA2yGtj(u"࠺࠵ᑇ"))
		qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(yyZPkLCRX1xcBDN(u"࠴࠱࠲ᑊ")).setPosition(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠾࠶ᑈ"),-OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠹࠵ᑉ"))
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵࠲࠴ᑋ")).setVisible(vvglE69OFKBm817Nkc)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠶࠳࠶ᑌ")).setVisible(vvglE69OFKBm817Nkc)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(yNBjYsgc23xoW(u"࠼࠴࠺࠶ᑍ")).setImage(image_filename)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(Vi1oNCM5kI7yJ0(u"࠽࠵࠻࠰ᑎ")).setHeight(image_height)
	LNma2eq3vEguwVtHjn.sleep(qumsGVnaObw//JP65RzKaScIf(u"࠶࠶࠰࠱࠰࠳ᑏ"))
	return
def eelI82pRmObUdPNsj6tcT3Wx9F(*aargs,**kkwargs):
	RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,profile,direction = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ༸"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡲࡥࡧࡶ༹ࠪ")
	if len(aargs)>=Mn5NGAdz6xc42s0: RRK9d6LeC5nglHWwEYcZyFTXUzf = aargs[UwCT5Oz6Wo0BP]
	if len(aargs)>=DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: xQXoDIqn4Ucsthb2G7YpzwPTymi = aargs[Mn5NGAdz6xc42s0]
	if len(aargs)>=O4dklMvZ8ULcS: profile = aargs[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
	if len(aargs)>=NEc173Pr0jAwLF5OS: direction = aargs[O4dklMvZ8ULcS]
	return ywuEego16R3ODiKVJr4Yf8qksH0vb(direction,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,profile)
def cch7AIZa3zlrSLvBiRCHqpd(*aargs,**kkwargs):
	return HqjWaYEzp0D8eyQRud.Dialog().contextmenu(*aargs,**kkwargs)
def eeBnxzu5y1ogSQaRO(*aargs,**kkwargs):
	return HqjWaYEzp0D8eyQRud.Dialog().browseSingle(*aargs,**kkwargs)
def LlitnVydk9Q(*aargs,**kkwargs):
	return HqjWaYEzp0D8eyQRud.Dialog().input(*aargs,**kkwargs)
def Rr8woplmSQWXIZcGFfA(*aargs,**kkwargs):
	return HqjWaYEzp0D8eyQRud.DialogProgress(*aargs,**kkwargs)
def wCuDBb85Gjl36RAQnUEZd(direction,button0=Zg9FeADE84jSRIvPCrzYulw3sL,button1=Zg9FeADE84jSRIvPCrzYulw3sL,button2=Zg9FeADE84jSRIvPCrzYulw3sL,RRK9d6LeC5nglHWwEYcZyFTXUzf=Zg9FeADE84jSRIvPCrzYulw3sL,xQXoDIqn4Ucsthb2G7YpzwPTymi=Zg9FeADE84jSRIvPCrzYulw3sL,profile=x9PULjztJOpu7b(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ༺"),jq4HN0VBFvnUZRs7GAz2wa6yi=UwCT5Oz6Wo0BP,Z2hCctBT9oM3xKkWU=UwCT5Oz6Wo0BP):
	if not direction: direction = vhZ5qjay1z94JmcMOgXe(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༻")
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM = depOPtkK89z6f1VL(yNBjYsgc23xoW(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ༼"),SSWrcswxYdB9p,E3i1eCBtN2w(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ༽"),NIBsHMvSXb(u"ࠪ࠻࠷࠶ࡰࠨ༾"))
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.SH9WIXJluRvjQ7(button0,button1,button2,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,profile,direction,jq4HN0VBFvnUZRs7GAz2wa6yi,Z2hCctBT9oM3xKkWU)
	if jq4HN0VBFvnUZRs7GAz2wa6yi>UwCT5Oz6Wo0BP: qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.U6luJCR92Z()
	if Z2hCctBT9oM3xKkWU>UwCT5Oz6Wo0BP: qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.ggZMBER2JG()
	if jq4HN0VBFvnUZRs7GAz2wa6yi==UwCT5Oz6Wo0BP and Z2hCctBT9oM3xKkWU==UwCT5Oz6Wo0BP: qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.aVrCHowxFqzMSm()
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.doModal()
	mQOFUVBbfyv39kzto0Nw4 = qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.choiceID
	return mQOFUVBbfyv39kzto0Nw4
def ywuEego16R3ODiKVJr4Yf8qksH0vb(direction,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,profile=YXm2qAbu8Qsx(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ༿")):
	if not direction: direction = vhZ5qjay1z94JmcMOgXe(u"ࠬࡲࡥࡧࡶࠪཀ")
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM = j9ldCL3Ibp(IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡄࡪࡣ࡯ࡳ࡬࡚ࡥࡹࡶ࡙࡭ࡪࡽࡥࡳࡈࡸࡰࡱ࡙ࡣࡳࡧࡨࡲ࠳ࡾ࡭࡭ࠩཁ"),SSWrcswxYdB9p,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨག"),Vi1oNCM5kI7yJ0(u"ࠨ࠹࠵࠴ࡵ࠭གྷ"))
	image_filename = S2apZTleKb6FXqd.replace(yNBjYsgc23xoW(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩང"),ZYTyoA483N(u"ࠪࡣࠬཅ")+str(LNma2eq3vEguwVtHjn.time())+vhZ5qjay1z94JmcMOgXe(u"ࠫࡤ࠭ཆ"))
	image_filename = image_filename.replace(IYC4iPxkTRUE85namF6(u"ࠬࡢ࡜ࠨཇ"),ee3tnwl7avk(u"࠭࡜࡝࡞࡟ࠫ཈")).replace(vhZ5qjay1z94JmcMOgXe(u"ࠧ࠰࠱ࠪཉ"),E3i1eCBtN2w(u"ࠨ࠱࠲࠳࠴࠭ཊ"))
	image_height = BEf8XIaMFVmj(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,RRK9d6LeC5nglHWwEYcZyFTXUzf,xQXoDIqn4Ucsthb2G7YpzwPTymi,profile,direction,vvglE69OFKBm817Nkc,image_filename)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.show()
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠿࠰࠶࠲ᑐ")).setHeight(image_height)
	qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.getControl(vhZ5qjay1z94JmcMOgXe(u"࠹࠱࠷࠳ᑑ")).setImage(image_filename)
	uLvzsQGnaJqk = qDXwtBkWJ1aA72Q8vlhG9VHCNLmYM.doModal()
	try: brAUlZfdFmt3TRJW2xX4.remove(image_filename)
	except: pass
	return uLvzsQGnaJqk
def lAfzvsbYy7oQ3r28EMe(pYdyJ7wtci=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	if pYdyJ7wtci:
		qoCMENGx4WgKp = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,vhZ5qjay1z94JmcMOgXe(u"ࠩࡶࡸࡷ࠭ཋ"),ykE045Tatx(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ཌ"),JP65RzKaScIf(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧཌྷ"))
		if qoCMENGx4WgKp: return qoCMENGx4WgKp
	xQXoDIqn4Ucsthb2G7YpzwPTymi = Zg9FeADE84jSRIvPCrzYulw3sL
	if UwCT5Oz6Wo0BP and Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
		Ahcb3XWMIz0JYT6g7jEpmsq = qHn7Qbi61UB.count(vGg1hAkzqi8exVbN(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭ཎ"))
		if Ahcb3XWMIz0JYT6g7jEpmsq>IYC4iPxkTRUE85namF6(u"࠹࠲ᑒ"):
			xQXoDIqn4Ucsthb2G7YpzwPTymi = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(wFYiVd4r12x7CAQBL5SPof(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨཏ"),qHn7Qbi61UB,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi[UwCT5Oz6Wo0BP]
	if not xQXoDIqn4Ucsthb2G7YpzwPTymi:
		ppSkmjHKXqJ3VdQvZeT = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,eCpDE6wJtYUHn0GqK5(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ཐ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩད"))
		xQXoDIqn4Ucsthb2G7YpzwPTymi = open(ppSkmjHKXqJ3VdQvZeT,dn9ouNryjHiBFQOhASvX(u"ࠩࡵࡦࠬདྷ")).read()
		if GGfPQnrJKEqMv2ZVxdD: xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
	qXF3uOMNykKmVpi98bwUxJ0BjGLI6H = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫན"),xQXoDIqn4Ucsthb2G7YpzwPTymi,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	DqIeJA076zMKoUNk2 = []
	for zXbvQ6ajdGw1kYI in qXF3uOMNykKmVpi98bwUxJ0BjGLI6H:
		ztBjAXe3Ccwp = zXbvQ6ajdGw1kYI.lower()
		if UixkloZbzGw28ujW56X(u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬཔ") in ztBjAXe3Ccwp: continue
		if IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡻࡢࡶࡰࡷࡹࠬཕ") in ztBjAXe3Ccwp: continue
		if ee3tnwl7avk(u"࠭ࡩࡱࡪࡲࡲࡪ࠭བ") in ztBjAXe3Ccwp: continue
		if ee3tnwl7avk(u"ࠧࡤࡴࡲࡷࠬབྷ") in ztBjAXe3Ccwp: continue
		DqIeJA076zMKoUNk2.append(zXbvQ6ajdGw1kYI)
	qoCMENGx4WgKp = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(DqIeJA076zMKoUNk2,Mn5NGAdz6xc42s0)
	qoCMENGx4WgKp = qoCMENGx4WgKp[UwCT5Oz6Wo0BP]
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,eCpDE6wJtYUHn0GqK5(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫམ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬཙ"),qoCMENGx4WgKp,E8RabFm1Kp5O0s)
	return qoCMENGx4WgKp
def TS2jM0Dl7syHeh3o8tPvxN5i9Lb(o4be19ApMtCrdf5=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not o4be19ApMtCrdf5: o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
	if Vi1oNCM5kI7yJ0(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧཚ") in o4be19ApMtCrdf5 or lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧཛ") in o4be19ApMtCrdf5: return
	if o4be19ApMtCrdf5!=jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨཛྷ"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
	nRTS1iIwBy0MrzcuXDqH8kOC = o4be19ApMtCrdf5.splitlines()
	TOJwE16IZS7Af = nRTS1iIwBy0MrzcuXDqH8kOC[-dn9ouNryjHiBFQOhASvX(u"࠳ᑓ")]
	EQwgUWAeyh6 = open(jKNw370SdFlQ,eCpDE6wJtYUHn0GqK5(u"࠭ࡲࡣࠩཝ")).read()
	if GGfPQnrJKEqMv2ZVxdD: EQwgUWAeyh6 = EQwgUWAeyh6.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	EQwgUWAeyh6 = EQwgUWAeyh6[-jozVWcERh91GOF2NHXQiSwKqe8x(u"࠻࠴࠵࠶ᑔ"):]
	BMRhxlqKtgFC6AUZWe5Tpd0b2rSn = ReLGYUQjz7C9iEd(u"ࠧ࠾ࠩཞ")*YXm2qAbu8Qsx(u"࠵࠵࠶ᑕ")
	if BMRhxlqKtgFC6AUZWe5Tpd0b2rSn in EQwgUWAeyh6: EQwgUWAeyh6 = EQwgUWAeyh6.rsplit(BMRhxlqKtgFC6AUZWe5Tpd0b2rSn,Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
	if TOJwE16IZS7Af in EQwgUWAeyh6: EQwgUWAeyh6 = EQwgUWAeyh6.rsplit(TOJwE16IZS7Af,Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
	OOm4vpntLQ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(lU1fSmncFWjizwqZugyYBANML0(u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧཟ"),EQwgUWAeyh6,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for v685Y9GAFXoCOfK2LRuTpP,iojW2gVFfT in reversed(OOm4vpntLQ):
		if iojW2gVFfT: break
	else: iojW2gVFfT = dn9ouNryjHiBFQOhASvX(u"ࠩࡑࡓ࡙ࠦࡓࡑࡇࡆࡍࡋࡏࡅࡅࠩའ")
	H047EqbDXrPzSx,zXbvQ6ajdGw1kYI,HhuDp632En59S = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	vFQ1OsgMw4cXJ7HYGe = vGg1hAkzqi8exVbN(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩཡ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫฬ๊ฮุล࠽ࠤࠥ࠭ར")+u4IRSmrYMKkaHUBnDiLWh+TOJwE16IZS7Af
	YlxJjQSZsg = A2MHFvoqpZ64gNbB(u"ࠬࡡࡒࡕࡎࡠࠫལ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+vGg1hAkzqi8exVbN(u"࠭วๅ็ุำึࡀࠠࠡࠩཤ")+u4IRSmrYMKkaHUBnDiLWh+iojW2gVFfT
	for XUOMNZ7WYxRe1DhPQB8Tt0pbv in reversed(nRTS1iIwBy0MrzcuXDqH8kOC):
		if A2MHFvoqpZ64gNbB(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧཥ") in XUOMNZ7WYxRe1DhPQB8Tt0pbv and ZYTyoA483N(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧས") in XUOMNZ7WYxRe1DhPQB8Tt0pbv: break
	XUOMNZ7WYxRe1DhPQB8Tt0pbv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(NIBsHMvSXb(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬཧ"),XUOMNZ7WYxRe1DhPQB8Tt0pbv,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XUOMNZ7WYxRe1DhPQB8Tt0pbv:
		H047EqbDXrPzSx,zXbvQ6ajdGw1kYI,HhuDp632En59S = XUOMNZ7WYxRe1DhPQB8Tt0pbv[UwCT5Oz6Wo0BP]
		if vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪ࠳ࠬཨ") in H047EqbDXrPzSx: H047EqbDXrPzSx = H047EqbDXrPzSx.rsplit(yyZPkLCRX1xcBDN(u"ࠫ࠴࠭ཀྵ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
		else: H047EqbDXrPzSx = H047EqbDXrPzSx.rsplit(NIBsHMvSXb(u"ࠬࡢ࡜ࠨཪ"),Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
		DY9eB2Ul4gfCQw1E3prGn8XhTaLAqt = NIBsHMvSXb(u"࡛࠭ࡓࡖࡏࡡࠬཫ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+ykE045Tatx(u"ࠧศๆ่่ๆࡀࠠࠡࠩཬ")+u4IRSmrYMKkaHUBnDiLWh+H047EqbDXrPzSx
		si51r4fazNKWn8vd0ZgIyTEDuYpeMH = lU1fSmncFWjizwqZugyYBANML0(u"ࠨ࡝ࡕࡘࡑࡣࠧ཭")+U2bWzwG8VdJsBqtR74ErDi3cg1v+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩสุ่฽ั࠻ࠢࠣࠫ཮")+u4IRSmrYMKkaHUBnDiLWh+zXbvQ6ajdGw1kYI
		ADeKhIVS73EJyFG = dn9ouNryjHiBFQOhASvX(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ཯")+U2bWzwG8VdJsBqtR74ErDi3cg1v+yyZPkLCRX1xcBDN(u"ࠫฬ๊ๅไษ้࠾ࠥࠦࠧ཰")+u4IRSmrYMKkaHUBnDiLWh+HhuDp632En59S
		KQxhLjzc34uyNRTIHJOigt5UV = DY9eB2Ul4gfCQw1E3prGn8XhTaLAqt+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+si51r4fazNKWn8vd0ZgIyTEDuYpeMH+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ADeKhIVS73EJyFG+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+YlxJjQSZsg+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+vFQ1OsgMw4cXJ7HYGe
		OlIjBH5SQfZosVq2Xzu = si51r4fazNKWn8vd0ZgIyTEDuYpeMH+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+YlxJjQSZsg+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+vFQ1OsgMw4cXJ7HYGe+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+DY9eB2Ul4gfCQw1E3prGn8XhTaLAqt+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ADeKhIVS73EJyFG
		kpaOPl7egtx0qfiwQKBdTZXmL1S = si51r4fazNKWn8vd0ZgIyTEDuYpeMH+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+vFQ1OsgMw4cXJ7HYGe+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+DY9eB2Ul4gfCQw1E3prGn8XhTaLAqt+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ADeKhIVS73EJyFG
	else:
		DY9eB2Ul4gfCQw1E3prGn8XhTaLAqt,si51r4fazNKWn8vd0ZgIyTEDuYpeMH,ADeKhIVS73EJyFG = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
		KQxhLjzc34uyNRTIHJOigt5UV = YlxJjQSZsg+lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡢ࡮࡝ࡰཱࠪ")+vFQ1OsgMw4cXJ7HYGe
		OlIjBH5SQfZosVq2Xzu = YlxJjQSZsg+jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭࡜࡯࡞ࡱིࠫ")+vFQ1OsgMw4cXJ7HYGe
		kpaOPl7egtx0qfiwQKBdTZXmL1S = vFQ1OsgMw4cXJ7HYGe
	RMqTceru2tF5QjZ4dBDvlCmkz6H = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าཱིࠫ")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	pQXF5hnNm10I8rPyvEdDl = dar0XmRojJwDW6Vef4OA9MH8()
	bB01SEwuzTXhZH = []
	CsaNhTtGm8 = pQXF5hnNm10I8rPyvEdDl[YXm2qAbu8Qsx(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸུ࠭")]
	Y394XTAufZKnkFViod = xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(kI8qwbo6yER)
	if lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹཱུࠧ") in list(pQXF5hnNm10I8rPyvEdDl.keys()):
		for fZNGDWOFM9ksEr3jnXT4bPhJdp,n4jdxZUyq6vNCsEMbBQkF8Io0,yM8h3YU0qkFeRgEm7cIp in CsaNhTtGm8:
			bB01SEwuzTXhZH = max(bB01SEwuzTXhZH,n4jdxZUyq6vNCsEMbBQkF8Io0)
		if Y394XTAufZKnkFViod<bB01SEwuzTXhZH:
			RRK9d6LeC5nglHWwEYcZyFTXUzf = dn9ouNryjHiBFQOhASvX(u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ั࠭ྲྀ")
			mQOFUVBbfyv39kzto0Nw4 = wCuDBb85Gjl36RAQnUEZd(ttC4VURALPYKh(u"ࠫࡷ࡯ࡧࡩࡶࠪཷ"),wFYiVd4r12x7CAQBL5SPof(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩླྀ"),A2MHFvoqpZ64gNbB(u"࠭สฮัํฯࠬཹ"),YXm2qAbu8Qsx(u"ࠧฯำ๋ะེࠬ"),RMqTceru2tF5QjZ4dBDvlCmkz6H+RRK9d6LeC5nglHWwEYcZyFTXUzf,KQxhLjzc34uyNRTIHJOigt5UV)
			if mQOFUVBbfyv39kzto0Nw4==Mn5NGAdz6xc42s0:
				import XUbpWe5mRd
				XUbpWe5mRd.vqmnhb5oQRglk0w4u(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
				KVirvJ58C1PjHyxel6FdwX()
			elif mQOFUVBbfyv39kzto0Nw4==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: KVirvJ58C1PjHyxel6FdwX()
	B2tjAdIKuY9EUb = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,eCpDE6wJtYUHn0GqK5(u"ࠨ࡮࡬ࡷࡹཻ࠭"),dn9ouNryjHiBFQOhASvX(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑོࠬ"),vhZ5qjay1z94JmcMOgXe(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗཽࠬ"))
	if not B2tjAdIKuY9EUb: B2tjAdIKuY9EUb = []
	OlIjBH5SQfZosVq2Xzu = OlIjBH5SQfZosVq2Xzu.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,vGg1hAkzqi8exVbN(u"ࠫࡡࡢ࡮ࠨཾ")).replace(IYC4iPxkTRUE85namF6(u"ࠬࡡࡒࡕࡎࡠࠫཿ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,Zg9FeADE84jSRIvPCrzYulw3sL).replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)
	kpaOPl7egtx0qfiwQKBdTZXmL1S = kpaOPl7egtx0qfiwQKBdTZXmL1S.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,vhZ5qjay1z94JmcMOgXe(u"࠭࡜࡝ࡰྀࠪ")).replace(eCpDE6wJtYUHn0GqK5(u"ࠧ࡜ࡔࡗࡐࡢཱྀ࠭"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,Zg9FeADE84jSRIvPCrzYulw3sL).replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL)
	qheCntHp6uFVoTArKNZkWi = kI8qwbo6yER+x9PULjztJOpu7b(u"ࠨ࠼࠽ࠫྂ")+kpaOPl7egtx0qfiwQKBdTZXmL1S
	if qheCntHp6uFVoTArKNZkWi in B2tjAdIKuY9EUb:
		RRK9d6LeC5nglHWwEYcZyFTXUzf = YXm2qAbu8Qsx(u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧྃ")
		I3kpd28CgLtrVEcuAXiZ(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡶ࡮࡭ࡨࡵ྄ࠩ"),Zg9FeADE84jSRIvPCrzYulw3sL,RMqTceru2tF5QjZ4dBDvlCmkz6H+RRK9d6LeC5nglHWwEYcZyFTXUzf,KQxhLjzc34uyNRTIHJOigt5UV)
		return
	X1zqxsSGk2emZba6r43NADhiM5pC = str(NGiBmYp8vX9T426lHn7ue).split(vGg1hAkzqi8exVbN(u"ࠫ࠳࠭྅"))[UwCT5Oz6Wo0BP]
	ZTG4ruxXUsc9N = PhpFa6EdVS[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ྆")][UQS9lVew50DIyXrinWsMxTzA(u"࠻ᑖ")]
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,E3i1eCBtN2w(u"࠭ࡐࡐࡕࡗࠫ྇"),ZTG4ruxXUsc9N,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨྈ"),vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
	sy6HfVi83aXrxRB4COSQEd = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yyZPkLCRX1xcBDN(u"ࠨࡕࡗࡅࡗ࡚࠺࠻ࡕࡗࡅࡗ࡚࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࡅࡏࡆ࠽࠾ࡊࡔࡄࠨྉ"),qHn7Qbi61UB,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for Ip7cGjJUmbL9,RRXvJuKUwS,ffxiV5p8lG9uLaRqXvEn0WmwzTcHy,gJWrmyNkI016Z7OXKu in sy6HfVi83aXrxRB4COSQEd:
		Ip7cGjJUmbL9 = Ip7cGjJUmbL9.split(qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠮ࠫྊ"))
		ffxiV5p8lG9uLaRqXvEn0WmwzTcHy = ffxiV5p8lG9uLaRqXvEn0WmwzTcHy.split(qdEKO42r3GhwmCDcHtxzJUR(u"ࠪ࠯ࠬྋ"))
		gJWrmyNkI016Z7OXKu = gJWrmyNkI016Z7OXKu.split(NIBsHMvSXb(u"ࠫ࠰࠭ྌ"))
		if zXbvQ6ajdGw1kYI in Ip7cGjJUmbL9 and TOJwE16IZS7Af==RRXvJuKUwS and kI8qwbo6yER in ffxiV5p8lG9uLaRqXvEn0WmwzTcHy and X1zqxsSGk2emZba6r43NADhiM5pC in gJWrmyNkI016Z7OXKu:
			RRK9d6LeC5nglHWwEYcZyFTXUzf = wFYiVd4r12x7CAQBL5SPof(u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪྍ")
			jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡲࡪࡩ࡫ࡸࠬྎ"),ttC4VURALPYKh(u"ࠧฯำ๋ะࠬྏ"),vhZ5qjay1z94JmcMOgXe(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬྐ"),RMqTceru2tF5QjZ4dBDvlCmkz6H+RRK9d6LeC5nglHWwEYcZyFTXUzf,KQxhLjzc34uyNRTIHJOigt5UV)
			if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0: I3kpd28CgLtrVEcuAXiZ(qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡦࡩࡳࡺࡥࡳࠩྑ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,RRK9d6LeC5nglHWwEYcZyFTXUzf)
			return
	RRK9d6LeC5nglHWwEYcZyFTXUzf = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪྒ")
	fY0ZxTRdyQpIUbV6HzX = wCuDBb85Gjl36RAQnUEZd(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡷ࡯ࡧࡩࡶࠪྒྷ"),NIBsHMvSXb(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩྔ"),ttC4VURALPYKh(u"࠭สฮัํฯࠥาาว์ࠪྕ"),vGg1hAkzqi8exVbN(u"ࠧหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠨྖ"),RMqTceru2tF5QjZ4dBDvlCmkz6H+RRK9d6LeC5nglHWwEYcZyFTXUzf,KQxhLjzc34uyNRTIHJOigt5UV)
	if fY0ZxTRdyQpIUbV6HzX==Mn5NGAdz6xc42s0:
		efxhtp5Bqz4(vvglE69OFKBm817Nkc)
		ZXWeI01flR(ZYTyoA483N(u"ࠨ่ฯัฯูࠦๆๆํอࠥอไหฯา๎ะࠦวๅฮีส๏࠭ྗ"),ZYTyoA483N(u"ࠩ๐ࡗࡺࡩࡣࡦࡵࡶࠫ྘"),LNma2eq3vEguwVtHjn=dn9ouNryjHiBFQOhASvX(u"࠽࠵࠱ᑗ"))
		KVirvJ58C1PjHyxel6FdwX()
	elif fY0ZxTRdyQpIUbV6HzX==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
		import XUbpWe5mRd
		XUbpWe5mRd.vqmnhb5oQRglk0w4u(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		KVirvJ58C1PjHyxel6FdwX()
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(E3i1eCBtN2w(u"ࠪࡧࡪࡴࡴࡦࡴࠪྙ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྚ"),YXm2qAbu8Qsx(u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭ྛ"))
	if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0: MvgQ64LDmVySGqotedf = ykE045Tatx(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩྜ")
	else:
		I3kpd28CgLtrVEcuAXiZ(ttC4VURALPYKh(u"ࠧࡤࡧࡱࡸࡪࡸࠧྜྷ"),Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྞ"),U2bWzwG8VdJsBqtR74ErDi3cg1v+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩอ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤࠩྟ")+u4IRSmrYMKkaHUBnDiLWh+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭ྠ"))
		return
	vvOzwTgFtar = OlIjBH5SQfZosVq2Xzu
	import XUbpWe5mRd
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = XUbpWe5mRd.XO1DeBA3qJgjH0syEZua(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡊࡸࡲࡰࡴࡶࠫྡ"),vvOzwTgFtar,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡖࡌࡔ࡝࡟ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗࠬྡྷ"),MvgQ64LDmVySGqotedf)
	if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD and MvgQ64LDmVySGqotedf:
		B2tjAdIKuY9EUb.append(qheCntHp6uFVoTArKNZkWi)
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩྣ"),x9PULjztJOpu7b(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩྤ"),B2tjAdIKuY9EUb,B4GWT7zonF5yipbIwJmNUf6Vavg)
	return
def hhoYXide0IUnEzW4gxtsGqrcFT3(WR7gIlwo5ik9zJv3CK4sS,filename=None):
	if GGfPQnrJKEqMv2ZVxdD: WR7gIlwo5ik9zJv3CK4sS = WR7gIlwo5ik9zJv3CK4sS.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	if not filename: ZMwJRKp4kcIvPrd7ih6e3njX = vGg1hAkzqi8exVbN(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨྥ")+str(LNma2eq3vEguwVtHjn.time())+Vi1oNCM5kI7yJ0(u"ࠩ࠱ࡨࡦࡺࠧྦ")
	else: ZMwJRKp4kcIvPrd7ih6e3njX = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪྦྷ")+filename+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫ࠳ࡪࡡࡵࠩྨ")
	open(ZMwJRKp4kcIvPrd7ih6e3njX,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡽࡢࠨྩ")).write(WR7gIlwo5ik9zJv3CK4sS)
	return
def s7XecJ90gPuFWK5Q8Z(k2x5IYN9dH1FfSytmDMEGChLsX):
	if k2x5IYN9dH1FfSytmDMEGChLsX:
		z4GsL3bn2eCqB = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,E3i1eCBtN2w(u"࠭࡬ࡪࡵࡷࠫྪ"),Vi1oNCM5kI7yJ0(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪྫ"),ttC4VURALPYKh(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫྫྷ"))
		if z4GsL3bn2eCqB: return z4GsL3bn2eCqB
	ZTG4ruxXUsc9N = PhpFa6EdVS[UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩྭ")][lU1fSmncFWjizwqZugyYBANML0(u"࠵ᑘ")]
	QrXISV6wyYA = EELfq0dKnyhZPxpA2jJrFsvXU(vvglE69OFKBm817Nkc) if not k2x5IYN9dH1FfSytmDMEGChLsX else fs60XkagtWFJ
	HHg6LBxyifWDl2Oucpn = gOd5YrkR6jsFX()
	yZ8XuBSf1M0NvqILAnYQGd36 = HHg6LBxyifWDl2Oucpn.split(yyZPkLCRX1xcBDN(u"ࠪ࠰ࠬྮ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
	S9k5pCrhxX3yH7 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪྯ"))
	ICNxS4XfEnmvWdbeGprk = f3mSgGZVx4l0qOtsWCQvkTu9Ky()
	VVYFjoZJNU7kCtnwDrPxfSGb = {NIBsHMvSXb(u"ࠬࡻࡳࡦࡴࠪྰ"):QrXISV6wyYA,vGg1hAkzqi8exVbN(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧྱ"):kI8qwbo6yER,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨྲ"):yZ8XuBSf1M0NvqILAnYQGd36,JP65RzKaScIf(u"ࠨ࡫ࡧࡷࠬླ"):opwNMkO7yVeCJXqPI(ICNxS4XfEnmvWdbeGprk)}
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,yNBjYsgc23xoW(u"ࠩࡓࡓࡘ࡚ࠧྴ"),ZTG4ruxXUsc9N,VVYFjoZJNU7kCtnwDrPxfSGb,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨྵ"))
	z4GsL3bn2eCqB = []
	if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
		z4GsL3bn2eCqB = qHn7Qbi61UB.replace(YXm2qAbu8Qsx(u"ࠫࡡࡢࡲࠨྶ"),SmFfh9kPpeoNBdcV7WnJ1LHMuXZO).replace(vhZ5qjay1z94JmcMOgXe(u"ࠬࡢ࡜࡯ࠩྷ"),SmFfh9kPpeoNBdcV7WnJ1LHMuXZO).replace(ttC4VURALPYKh(u"࠭࡜ࡳ࡞ࡱࠫྸ"),SmFfh9kPpeoNBdcV7WnJ1LHMuXZO).replace(mqBPGuVIYZbStQejFowJh2,SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
		z4GsL3bn2eCqB = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡀ࠺ࠩ࡞ࡧ࠯࠮ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯ࡇࡑࡈ࠿ࡀࡅࡏࡆࠪྐྵ"),z4GsL3bn2eCqB,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if z4GsL3bn2eCqB:
			z4GsL3bn2eCqB = sorted(z4GsL3bn2eCqB,reverse=vvglE69OFKBm817Nkc,key=lambda key: int(key[UwCT5Oz6Wo0BP]))
			CsPNhF9RD27K8GlcMOVZHq,QrXISV6wyYA,fOQUkxT2FMILJPC,GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe,BBkxwFGyasvQphqZ4H = z4GsL3bn2eCqB[UwCT5Oz6Wo0BP]
			bxrVTf4jP8kOQ = BBkxwFGyasvQphqZ4H if ZE3oYw0NMipGVt1zJ8yAULgq7nbdx([vhZ5qjay1z94JmcMOgXe(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧྺ")])[UwCT5Oz6Wo0BP] else fOQUkxT2FMILJPC
			yUTYoAgth5iC43uLrdBH.setSetting(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫྻ"),bxrVTf4jP8kOQ)
			cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,NIBsHMvSXb(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ྼ"),ReLGYUQjz7C9iEd(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ྽"),z4GsL3bn2eCqB,E8RabFm1Kp5O0s)
			yUTYoAgth5iC43uLrdBH.setSetting(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ྾"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
	return z4GsL3bn2eCqB
def AAMdFjOkSDyec648zgBUpfiwQbm(l4wQZn2ebMpNr9H7cvhiGgXWLURj,ll7nVBLjZp9DCbotYUkQgiO1=UwCT5Oz6Wo0BP,ds15wBGfEStMcAauZvoCU=UwCT5Oz6Wo0BP):
	if ll7nVBLjZp9DCbotYUkQgiO1 and not ds15wBGfEStMcAauZvoCU: ds15wBGfEStMcAauZvoCU = len(l4wQZn2ebMpNr9H7cvhiGgXWLURj)//ll7nVBLjZp9DCbotYUkQgiO1
	qbVM4zIZur,OEJ3PT81KtbZ,V8lpkbt69RLE1Nd5jAYizJOge = [],-Mn5NGAdz6xc42s0,UwCT5Oz6Wo0BP
	for dczJa6f5mpR in l4wQZn2ebMpNr9H7cvhiGgXWLURj:
		if V8lpkbt69RLE1Nd5jAYizJOge%ds15wBGfEStMcAauZvoCU==UwCT5Oz6Wo0BP:
			OEJ3PT81KtbZ += Mn5NGAdz6xc42s0
			qbVM4zIZur.append([])
		qbVM4zIZur[OEJ3PT81KtbZ].append(dczJa6f5mpR)
		V8lpkbt69RLE1Nd5jAYizJOge += Mn5NGAdz6xc42s0
	return qbVM4zIZur
def XHtP1Ezl7ieDqU(ZMwJRKp4kcIvPrd7ih6e3njX,WR7gIlwo5ik9zJv3CK4sS):
	RaCsQSZX0x3pkDoNtEzGy68 = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ZMwJRKp4kcIvPrd7ih6e3njX)
	if Mn5NGAdz6xc42s0 or lU1fSmncFWjizwqZugyYBANML0(u"࠭ࡉࡑࡖ࡙ࡣࠬ྿") not in ZMwJRKp4kcIvPrd7ih6e3njX or vGg1hAkzqi8exVbN(u"ࠧࡎ࠵ࡘࡣࠬ࿀") not in ZMwJRKp4kcIvPrd7ih6e3njX: xQXoDIqn4Ucsthb2G7YpzwPTymi = str(WR7gIlwo5ik9zJv3CK4sS)
	else:
		qbVM4zIZur = AAMdFjOkSDyec648zgBUpfiwQbm(WR7gIlwo5ik9zJv3CK4sS,wFYiVd4r12x7CAQBL5SPof(u"࠹ᑙ"))
		xQXoDIqn4Ucsthb2G7YpzwPTymi = Zg9FeADE84jSRIvPCrzYulw3sL
		for xjQbsq0nGUCB3E in qbVM4zIZur:
			xQXoDIqn4Ucsthb2G7YpzwPTymi += str(xjQbsq0nGUCB3E)+ttC4VURALPYKh(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ࿁")
		xQXoDIqn4Ucsthb2G7YpzwPTymi = xQXoDIqn4Ucsthb2G7YpzwPTymi.strip(E3i1eCBtN2w(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ࿂"))
	PJU0dt4TlqbI = aGHUATkRiwgYe0Dzu9d7jWh.compress(xQXoDIqn4Ucsthb2G7YpzwPTymi)
	open(RaCsQSZX0x3pkDoNtEzGy68,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡻࡧ࠭࿃")).write(PJU0dt4TlqbI)
	return
def XXhug1OlPCR4vWjqADrJxi85Nd(LwhdPNZ37p9clMKn,ZMwJRKp4kcIvPrd7ih6e3njX):
	if LwhdPNZ37p9clMKn==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡩ࡯ࡣࡵࠩ࿄"): WR7gIlwo5ik9zJv3CK4sS = {}
	elif LwhdPNZ37p9clMKn==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡲࡩࡴࡶࠪ࿅"): WR7gIlwo5ik9zJv3CK4sS = []
	elif LwhdPNZ37p9clMKn==vhZ5qjay1z94JmcMOgXe(u"࠭ࡳࡵࡴ࿆ࠪ"): WR7gIlwo5ik9zJv3CK4sS = Zg9FeADE84jSRIvPCrzYulw3sL
	elif LwhdPNZ37p9clMKn==E3i1eCBtN2w(u"ࠧࡪࡰࡷࠫ࿇"): WR7gIlwo5ik9zJv3CK4sS = UwCT5Oz6Wo0BP
	else: WR7gIlwo5ik9zJv3CK4sS = None
	RaCsQSZX0x3pkDoNtEzGy68 = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ZMwJRKp4kcIvPrd7ih6e3njX)
	PJU0dt4TlqbI = open(RaCsQSZX0x3pkDoNtEzGy68,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡴࡥࠫ࿈")).read()
	xQXoDIqn4Ucsthb2G7YpzwPTymi = aGHUATkRiwgYe0Dzu9d7jWh.decompress(PJU0dt4TlqbI)
	if wFYiVd4r12x7CAQBL5SPof(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ࿉") not in xQXoDIqn4Ucsthb2G7YpzwPTymi: WR7gIlwo5ik9zJv3CK4sS = eval(xQXoDIqn4Ucsthb2G7YpzwPTymi)
	else:
		qbVM4zIZur = xQXoDIqn4Ucsthb2G7YpzwPTymi.split(yyZPkLCRX1xcBDN(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ࿊"))
		del xQXoDIqn4Ucsthb2G7YpzwPTymi
		WR7gIlwo5ik9zJv3CK4sS = []
		QlnGISZ03Yg = fZLqV6xaCWsTItK2ngd()
		CsPNhF9RD27K8GlcMOVZHq = UwCT5Oz6Wo0BP
		for xjQbsq0nGUCB3E in qbVM4zIZur:
			QlnGISZ03Yg.lePMc1NbnJFjD4Rpt0Ew2fS3Zv9X(str(CsPNhF9RD27K8GlcMOVZHq),eval,xjQbsq0nGUCB3E)
			CsPNhF9RD27K8GlcMOVZHq += Mn5NGAdz6xc42s0
		del qbVM4zIZur
		QlnGISZ03Yg.UwDZ90FbNYM8lQ3Cxh7()
		QlnGISZ03Yg.TTOUZjShNc()
		l6lgHLvBr4F9b7 = list(QlnGISZ03Yg.resultsDICT.keys())
		MZNSjdLio1Pq79UOf8XaR = sorted(l6lgHLvBr4F9b7,reverse=vvglE69OFKBm817Nkc,key=lambda key: int(key))
		for CsPNhF9RD27K8GlcMOVZHq in MZNSjdLio1Pq79UOf8XaR:
			WR7gIlwo5ik9zJv3CK4sS += QlnGISZ03Yg.resultsDICT[CsPNhF9RD27K8GlcMOVZHq]
	return WR7gIlwo5ik9zJv3CK4sS
def qjmC6netduQSHZUw(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs):
	ggPaSenwrGT8zvk = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,ee3tnwl7avk(u"ࠫࡦࡪࡤࡰࡰࡶࠫ࿋"),Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,YXm2qAbu8Qsx(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ࿌"))
	try: X3KFbwUGL9YB5faz2W1slCjOox = open(ggPaSenwrGT8zvk,vhZ5qjay1z94JmcMOgXe(u"࠭ࡲࡣࠩ࿍")).read()
	except:
		TUmIEera4VM2Sdcn8X = brAUlZfdFmt3TRJW2xX4.path.join(QI90vnGbT1LoPUNsxgecSZyV,ZYTyoA483N(u"ࠧࡢࡦࡧࡳࡳࡹࠧ࿎"),Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ࿏"))
		try: X3KFbwUGL9YB5faz2W1slCjOox = open(TUmIEera4VM2Sdcn8X,lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡵࡦࠬ࿐")).read()
		except: return Zg9FeADE84jSRIvPCrzYulw3sL,[]
	if GGfPQnrJKEqMv2ZVxdD: X3KFbwUGL9YB5faz2W1slCjOox = X3KFbwUGL9YB5faz2W1slCjOox.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	VvITF3YNsoZfR6wMaLAEngiHPqJ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ee3tnwl7avk(u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧ࿑"),X3KFbwUGL9YB5faz2W1slCjOox,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if not VvITF3YNsoZfR6wMaLAEngiHPqJ: return Zg9FeADE84jSRIvPCrzYulw3sL,[]
	xjCRI45OZlUkY,iBUTkAWV9FMjIDN = VvITF3YNsoZfR6wMaLAEngiHPqJ[UwCT5Oz6Wo0BP],xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(VvITF3YNsoZfR6wMaLAEngiHPqJ[UwCT5Oz6Wo0BP])
	return xjCRI45OZlUkY,iBUTkAWV9FMjIDN
def dar0XmRojJwDW6Vef4OA9MH8():
	sZ315FyH4wSBQkvI = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡩ࡯ࡣࡵࠩ࿒"),yyZPkLCRX1xcBDN(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ࿓"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ࿔"))
	if sZ315FyH4wSBQkvI: return sZ315FyH4wSBQkvI
	pQXF5hnNm10I8rPyvEdDl,sZ315FyH4wSBQkvI = {},{}
	OOm4vpntLQ = [PhpFa6EdVS[ttC4VURALPYKh(u"ࠧࡓࡇࡓࡓࡘ࠭࿕")][UwCT5Oz6Wo0BP]]
	if NGiBmYp8vX9T426lHn7ue>OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠳࠺࠲࠾࠿ᑚ"): OOm4vpntLQ.append(PhpFa6EdVS[yyZPkLCRX1xcBDN(u"ࠨࡔࡈࡔࡔ࡙ࠧ࿖")][Mn5NGAdz6xc42s0])
	if GGfPQnrJKEqMv2ZVxdD: OOm4vpntLQ.append(PhpFa6EdVS[qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡕࡉࡕࡕࡓࠨ࿗")][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr])
	for rImAVFW1wE in OOm4vpntLQ:
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,NIBsHMvSXb(u"ࠪࡋࡊ࡚ࠧ࿘"),rImAVFW1wE,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ࿙"))
		if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
			qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
			qWJ8emg0wPNux1YM = rImAVFW1wE.rsplit(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࠵ࠧ࿚"),Vi1oNCM5kI7yJ0(u"࠴ᑛ"))[UwCT5Oz6Wo0BP]
			w0DtoBI1eyS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࿛"),qHn7Qbi61UB,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
			for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,djqT7peCMbwFHi in w0DtoBI1eyS9:
				YE7RkwepJzH0LQrB6NPjtUA = qWJ8emg0wPNux1YM+vhZ5qjay1z94JmcMOgXe(u"ࠧ࠰ࠩ࿜")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+Vi1oNCM5kI7yJ0(u"ࠨ࠱ࠪ࿝")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+YXm2qAbu8Qsx(u"ࠩ࠰ࠫ࿞")+djqT7peCMbwFHi+ZYTyoA483N(u"ࠪ࠲ࡿ࡯ࡰࠨ࿟")
				if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs not in list(pQXF5hnNm10I8rPyvEdDl.keys()):
					pQXF5hnNm10I8rPyvEdDl[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = []
					sZ315FyH4wSBQkvI[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = []
				yV0UkomHQeD24L6znqsGEjB9Y = xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(djqT7peCMbwFHi)
				pQXF5hnNm10I8rPyvEdDl[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs].append((djqT7peCMbwFHi,yV0UkomHQeD24L6znqsGEjB9Y,YE7RkwepJzH0LQrB6NPjtUA))
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in list(pQXF5hnNm10I8rPyvEdDl.keys()):
		sZ315FyH4wSBQkvI[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = sorted(pQXF5hnNm10I8rPyvEdDl[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs],reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: key[Mn5NGAdz6xc42s0])
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,UixkloZbzGw28ujW56X(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ࿠"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭࿡"),sZ315FyH4wSBQkvI,E8RabFm1Kp5O0s)
	return sZ315FyH4wSBQkvI
def xQWpCVmq3XYFdbJlHTfia4kS5gRtrv(djqT7peCMbwFHi):
	yV0UkomHQeD24L6znqsGEjB9Y = []
	TKAiXGUvHq7xrdf5MuOcI = djqT7peCMbwFHi.split(YXm2qAbu8Qsx(u"࠭࠮ࠨ࿢"))
	for B0pPeTEc4MFan2y5buH in TKAiXGUvHq7xrdf5MuOcI:
		CCXmO8KQyFpSVaNeI1qlf5sj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ykE045Tatx(u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ࿣"),B0pPeTEc4MFan2y5buH,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		fZRyFowAQ270d3k6icH = []
		for nnZdjbXLQalIDAe9yhpwt1GuYRPB in CCXmO8KQyFpSVaNeI1qlf5sj:
			if nnZdjbXLQalIDAe9yhpwt1GuYRPB.isdigit(): nnZdjbXLQalIDAe9yhpwt1GuYRPB = int(nnZdjbXLQalIDAe9yhpwt1GuYRPB)
			fZRyFowAQ270d3k6icH.append(nnZdjbXLQalIDAe9yhpwt1GuYRPB)
		yV0UkomHQeD24L6znqsGEjB9Y.append(fZRyFowAQ270d3k6icH)
	return yV0UkomHQeD24L6znqsGEjB9Y
def Nb6XKy4fcLGYJUTW0vu9ZCtmgQHnBM(yV0UkomHQeD24L6znqsGEjB9Y):
	djqT7peCMbwFHi = Zg9FeADE84jSRIvPCrzYulw3sL
	for B0pPeTEc4MFan2y5buH in yV0UkomHQeD24L6znqsGEjB9Y:
		for nnZdjbXLQalIDAe9yhpwt1GuYRPB in B0pPeTEc4MFan2y5buH: djqT7peCMbwFHi += str(nnZdjbXLQalIDAe9yhpwt1GuYRPB)
		djqT7peCMbwFHi += dn9ouNryjHiBFQOhASvX(u"ࠨ࠰ࠪ࿤")
	djqT7peCMbwFHi = djqT7peCMbwFHi.strip(NIBsHMvSXb(u"ࠩ࠱ࠫ࿥"))
	return djqT7peCMbwFHi
def DUlT4qMG5tQd(wdBbhtlZ6WuY5):
	BchiTO0Hae9m6l4E1F = {}
	pQXF5hnNm10I8rPyvEdDl = dar0XmRojJwDW6Vef4OA9MH8()
	caubiXgjl26koSURGFMs = yi4d8PrTLhG0HAsu2fXvwqbjpmRQxz(wdBbhtlZ6WuY5)
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in wdBbhtlZ6WuY5:
		if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs not in list(pQXF5hnNm10I8rPyvEdDl.keys()): continue
		sZ315FyH4wSBQkvI = pQXF5hnNm10I8rPyvEdDl[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs]
		X8wB92I4iKW0xOtVJTySrG,WRqLkgAySs,rVbiXKMU23PLBz6CAvsNcjtY7HD = sZ315FyH4wSBQkvI[UwCT5Oz6Wo0BP]
		wwmXRxF9gzLPqHNAisY68GB2KaVIb,GGSVcEmnpj = qjmC6netduQSHZUw(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
		y0rPdaD4EGAMtfu1xVkQie8R7,A5N1J7SlWxFwHCgy = caubiXgjl26koSURGFMs[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs]
		YbyISEtFej = WRqLkgAySs>GGSVcEmnpj and y0rPdaD4EGAMtfu1xVkQie8R7
		mHLBF2Mogbt7rWsCQ = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if not y0rPdaD4EGAMtfu1xVkQie8R7: FtXelEbKVwg = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ࿦")
		elif not A5N1J7SlWxFwHCgy: FtXelEbKVwg = Vi1oNCM5kI7yJ0(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭࿧")
		elif YbyISEtFej: FtXelEbKVwg = Vi1oNCM5kI7yJ0(u"ࠬࡵ࡬ࡥࠩ࿨")
		else:
			FtXelEbKVwg = E3i1eCBtN2w(u"࠭ࡧࡰࡱࡧࠫ࿩")
			mHLBF2Mogbt7rWsCQ = vvglE69OFKBm817Nkc
		BchiTO0Hae9m6l4E1F[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = mHLBF2Mogbt7rWsCQ,wwmXRxF9gzLPqHNAisY68GB2KaVIb,GGSVcEmnpj,X8wB92I4iKW0xOtVJTySrG,WRqLkgAySs,FtXelEbKVwg,rVbiXKMU23PLBz6CAvsNcjtY7HD
	return BchiTO0Hae9m6l4E1F
def OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,jj8fFw4aKnE52zUBT6cAQS0,MmjBWCl1wQLIJ7eyzTDt49XqSshuPA=Zg9FeADE84jSRIvPCrzYulw3sL,si51r4fazNKWn8vd0ZgIyTEDuYpeMH=Zg9FeADE84jSRIvPCrzYulw3sL,Ip7cGjJUmbL9=Zg9FeADE84jSRIvPCrzYulw3sL):
	if HByjTem6EJP5sZb: zkK23NOgQFhY75mjwDuxfbsc1EUiqS.update(jj8fFw4aKnE52zUBT6cAQS0,MmjBWCl1wQLIJ7eyzTDt49XqSshuPA,si51r4fazNKWn8vd0ZgIyTEDuYpeMH,Ip7cGjJUmbL9)
	else: zkK23NOgQFhY75mjwDuxfbsc1EUiqS.update(jj8fFw4aKnE52zUBT6cAQS0,MmjBWCl1wQLIJ7eyzTDt49XqSshuPA+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+si51r4fazNKWn8vd0ZgIyTEDuYpeMH+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+Ip7cGjJUmbL9)
	return
def Uu6MqoJxLtkimFsdYhc2Nvef(nmytzfOdMhHY6Ao1KSx5NL):
	def msSLKU0ZGPRiJj5n(KAMEWYTSBr,htOrekVmZ92,wfqmlpiRG9rkn=NIBsHMvSXb(u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠢ࿪")):
		return ((KAMEWYTSBr == UwCT5Oz6Wo0BP) and wfqmlpiRG9rkn[UwCT5Oz6Wo0BP]) or (msSLKU0ZGPRiJj5n(KAMEWYTSBr // htOrekVmZ92, htOrekVmZ92, wfqmlpiRG9rkn).lstrip(wfqmlpiRG9rkn[UwCT5Oz6Wo0BP]) + wfqmlpiRG9rkn[KAMEWYTSBr % htOrekVmZ92])
	def jgYFD9aXlJdhxPoQkVc63NHCBSuAy(KlU1zwMLmOCa, ex0nfistDmp36Q, f4hGlHiK3uMxwUg62o9J, b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc, IvcV8CbAZPpmdT4woEHk0zX3sSN6RW=None, SQkWUPdDbyaYs532uX=None, Vq4FBZTJ5lxDNPehW2Angdujzvc=None):
		while (f4hGlHiK3uMxwUg62o9J):
			f4hGlHiK3uMxwUg62o9J-=IK4zTnSMyGQpxEaesJAPVDY(u"࠵ᑜ")
			if (b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc[f4hGlHiK3uMxwUg62o9J]): KlU1zwMLmOCa = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠣ࡞࡟ࡦࠧ࿫") + msSLKU0ZGPRiJj5n(f4hGlHiK3uMxwUg62o9J, ex0nfistDmp36Q) + KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠤ࡟ࡠࡧࠨ࿬"),  b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc[f4hGlHiK3uMxwUg62o9J], KlU1zwMLmOCa)
		return KlU1zwMLmOCa
	nmytzfOdMhHY6Ao1KSx5NL = nmytzfOdMhHY6Ao1KSx5NL.split(x9PULjztJOpu7b(u"ࠪࢁ࠭࠭࿭"))[Mn5NGAdz6xc42s0]
	nmytzfOdMhHY6Ao1KSx5NL = nmytzfOdMhHY6Ao1KSx5NL.rsplit(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡸࡶ࡬ࡪࡶࠪ࿮"))[UwCT5Oz6Wo0BP]+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡹࡰ࡭࡫ࡷࠬࠬࢂࠧࠪࠫࠥ࿯")
	LE9gRTxzt856dh3K1F = eval(UixkloZbzGw28ujW56X(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧ࿰")+nmytzfOdMhHY6Ao1KSx5NL,{UixkloZbzGw28ujW56X(u"ࠧࡣࡣࡶࡩࡓ࠭࿱"):msSLKU0ZGPRiJj5n,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡷࡱࡴࡦࡩ࡫ࠨ࿲"):jgYFD9aXlJdhxPoQkVc63NHCBSuAy})
	return LE9gRTxzt856dh3K1F
def YE6NfDK7nZtwTs(code):
	_DMKCtlEkFq4=yyZPkLCRX1xcBDN(u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛࠭࠲ࠦ࿳")
	def A4QBkxcC13XPOTHtKsnNUwm(SQkWUPdDbyaYs532uX,IvcV8CbAZPpmdT4woEHk0zX3sSN6RW,VPG7JDdChkZsUgL4wbFrSWleXQu):
		sBqmayAZXS6T = list(_DMKCtlEkFq4)
		Q1xD5wjBig3cOsI = sBqmayAZXS6T[ykE045Tatx(u"࠵ᑝ"):IvcV8CbAZPpmdT4woEHk0zX3sSN6RW]
		YjZN3ADmertFahUQIECW = sBqmayAZXS6T[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠶ᑞ"):VPG7JDdChkZsUgL4wbFrSWleXQu]
		SQkWUPdDbyaYs532uX = list(SQkWUPdDbyaYs532uX)[::-OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠱ᑟ")]
		ppRxt5ilkfHrGQFZ3 = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠱ᑠ")
		for f4hGlHiK3uMxwUg62o9J,htOrekVmZ92 in enumerate(SQkWUPdDbyaYs532uX):
			if htOrekVmZ92 in Q1xD5wjBig3cOsI: ppRxt5ilkfHrGQFZ3 = ppRxt5ilkfHrGQFZ3 + Q1xD5wjBig3cOsI.index(htOrekVmZ92)*IvcV8CbAZPpmdT4woEHk0zX3sSN6RW**f4hGlHiK3uMxwUg62o9J
		b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc = IK4zTnSMyGQpxEaesJAPVDY(u"ࠥࠦ࿴")
		while ppRxt5ilkfHrGQFZ3 > UixkloZbzGw28ujW56X(u"࠲ᑡ"):
			b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc = YjZN3ADmertFahUQIECW[ppRxt5ilkfHrGQFZ3%VPG7JDdChkZsUgL4wbFrSWleXQu] + b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc
			ppRxt5ilkfHrGQFZ3 = (ppRxt5ilkfHrGQFZ3 - (ppRxt5ilkfHrGQFZ3%VPG7JDdChkZsUgL4wbFrSWleXQu))//VPG7JDdChkZsUgL4wbFrSWleXQu
		return int(b9IgyOtDpG71YxmuBFT2qzKZ4CNkHc) or JP65RzKaScIf(u"࠳ᑢ")
	def ZREx1XoQGN(Q1xD5wjBig3cOsI,u,U6osjRDOqInL,TlHpxhbRFfcmPsuOz,IvcV8CbAZPpmdT4woEHk0zX3sSN6RW,Vq4FBZTJ5lxDNPehW2Angdujzvc):
		Vq4FBZTJ5lxDNPehW2Angdujzvc = ttC4VURALPYKh(u"ࠦࠧ࿵");
		YjZN3ADmertFahUQIECW = YXm2qAbu8Qsx(u"࠴ᑣ")
		while YjZN3ADmertFahUQIECW < len(Q1xD5wjBig3cOsI):
			ppRxt5ilkfHrGQFZ3 = vGg1hAkzqi8exVbN(u"࠵ᑤ")
			VEsh8BwK5ey4J19MUSOLkNalZC = vGg1hAkzqi8exVbN(u"ࠧࠨ࿶")
			while Q1xD5wjBig3cOsI[YjZN3ADmertFahUQIECW] is not U6osjRDOqInL[IvcV8CbAZPpmdT4woEHk0zX3sSN6RW]:
				VEsh8BwK5ey4J19MUSOLkNalZC = KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࠧ࿷").join([VEsh8BwK5ey4J19MUSOLkNalZC,Q1xD5wjBig3cOsI[YjZN3ADmertFahUQIECW]])
				YjZN3ADmertFahUQIECW = YjZN3ADmertFahUQIECW + okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠷ᑥ")
			while ppRxt5ilkfHrGQFZ3 < len(U6osjRDOqInL):
				VEsh8BwK5ey4J19MUSOLkNalZC = VEsh8BwK5ey4J19MUSOLkNalZC.replace(U6osjRDOqInL[ppRxt5ilkfHrGQFZ3],str(ppRxt5ilkfHrGQFZ3))
				ppRxt5ilkfHrGQFZ3 = ppRxt5ilkfHrGQFZ3 + okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠱ᑦ")
			Vq4FBZTJ5lxDNPehW2Angdujzvc = DKmLTA2yGtj(u"ࠧࠨ࿸").join([Vq4FBZTJ5lxDNPehW2Angdujzvc,dn9ouNryjHiBFQOhASvX(u"ࠨࠩ࿹").join(map(chr, [A4QBkxcC13XPOTHtKsnNUwm(VEsh8BwK5ey4J19MUSOLkNalZC,IvcV8CbAZPpmdT4woEHk0zX3sSN6RW,E3i1eCBtN2w(u"࠲࠲ᑧ")) - TlHpxhbRFfcmPsuOz]))])
			YjZN3ADmertFahUQIECW = YjZN3ADmertFahUQIECW + vGg1hAkzqi8exVbN(u"࠳ᑨ")
		return Vq4FBZTJ5lxDNPehW2Angdujzvc
	code = code.replace(Vi1oNCM5kI7yJ0(u"ࠩ࡟ࡲࠬ࿺"),E3i1eCBtN2w(u"ࠪࠫ࿻")).replace(lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡡࡸࠧ࿼"),vhZ5qjay1z94JmcMOgXe(u"ࠬ࠭࿽"))
	Ps6a7MqQG2Vki = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(NIBsHMvSXb(u"࠭࡜ࡾ࡞ࠫࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࡝ࠫ࡟࠭ࠬ࿾"),code,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if Ps6a7MqQG2Vki:
		Ps6a7MqQG2Vki = list(Ps6a7MqQG2Vki[vhZ5qjay1z94JmcMOgXe(u"࠳ᑩ")])
		for KT4xDqLXVC5vEcjHfzOlM,code in enumerate(Ps6a7MqQG2Vki):
			if code.isdigit(): Ps6a7MqQG2Vki[KT4xDqLXVC5vEcjHfzOlM] = int(code)
			else: Ps6a7MqQG2Vki[KT4xDqLXVC5vEcjHfzOlM] = code.replace(JP65RzKaScIf(u"ࠧ࡝ࠤࠪ࿿"),x9PULjztJOpu7b(u"ࠨࠩက"))
		gaJIqHOxXdVWY = ZREx1XoQGN(*Ps6a7MqQG2Vki)
		return gaJIqHOxXdVWY
	return vhZ5qjay1z94JmcMOgXe(u"ࠩࠪခ")
def MbYyNHpKAW(ZTG4ruxXUsc9N,Wj3fNyeH2nibpAtwkY08KaSmvG=Zg9FeADE84jSRIvPCrzYulw3sL):
	if Wj3fNyeH2nibpAtwkY08KaSmvG==ee3tnwl7avk(u"ࠪࡰࡴࡽࡥࡳࠩဂ"): ZTG4ruxXUsc9N = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(Vi1oNCM5kI7yJ0(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫဃ"),lambda XYIa2Qm4rqWAz7iHBZT3VkEv5x89: XYIa2Qm4rqWAz7iHBZT3VkEv5x89.group(UwCT5Oz6Wo0BP).lower(),ZTG4ruxXUsc9N)
	elif Wj3fNyeH2nibpAtwkY08KaSmvG==DKmLTA2yGtj(u"ࠬࡻࡰࡱࡧࡵࠫင"): ZTG4ruxXUsc9N = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(NIBsHMvSXb(u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭စ"),lambda XYIa2Qm4rqWAz7iHBZT3VkEv5x89: XYIa2Qm4rqWAz7iHBZT3VkEv5x89.group(UwCT5Oz6Wo0BP).upper(),ZTG4ruxXUsc9N)
	return ZTG4ruxXUsc9N
def yi4d8PrTLhG0HAsu2fXvwqbjpmRQxz(wdBbhtlZ6WuY5):
	vvIuYGod4iU12,JJ5z0Fier2SQyRONG1 = vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc
	KAyrTaiwVmYnCS2NbPp = rNIFwicQYy7ZKf4XlzoP9Rj.connect(HHgE1pqyiM4W5)
	KAyrTaiwVmYnCS2NbPp.text_factory = str
	wxljEVBYCes0uWnzdZKDbhyI = KAyrTaiwVmYnCS2NbPp.cursor()
	if len(wdBbhtlZ6WuY5)==Mn5NGAdz6xc42s0: ndLWO4zPbIJrDsXTKpcqN = yNBjYsgc23xoW(u"ࠧࠩࠤࠪဆ")+wdBbhtlZ6WuY5[UwCT5Oz6Wo0BP]+qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࠤࠬࠫဇ")
	else: ndLWO4zPbIJrDsXTKpcqN = str(tuple(wdBbhtlZ6WuY5))
	wxljEVBYCes0uWnzdZKDbhyI.execute(IYC4iPxkTRUE85namF6(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩဈ")+ndLWO4zPbIJrDsXTKpcqN+IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࠤࡀ࠭ဉ"))
	eyGQZ6IzfoLwHdJajxUgC4ROW2pP = wxljEVBYCes0uWnzdZKDbhyI.fetchall()
	caubiXgjl26koSURGFMs = {}
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in wdBbhtlZ6WuY5: caubiXgjl26koSURGFMs[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = (vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,JJ5z0Fier2SQyRONG1 in eyGQZ6IzfoLwHdJajxUgC4ROW2pP:
		vvIuYGod4iU12 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		JJ5z0Fier2SQyRONG1 = JJ5z0Fier2SQyRONG1==Mn5NGAdz6xc42s0
		caubiXgjl26koSURGFMs[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs] = (vvIuYGod4iU12,JJ5z0Fier2SQyRONG1)
	KAyrTaiwVmYnCS2NbPp.close()
	return caubiXgjl26koSURGFMs
def wRZbDkg3X6Qhc(H047EqbDXrPzSx):
	CsaNhTtGm8 = Zg9FeADE84jSRIvPCrzYulw3sL
	if brAUlZfdFmt3TRJW2xX4.path.exists(H047EqbDXrPzSx):
		EXmDZJu7BtVLwj4 = open(H047EqbDXrPzSx,DKmLTA2yGtj(u"ࠫࡷࡨࠧည")).read()
		if GGfPQnrJKEqMv2ZVxdD: EXmDZJu7BtVLwj4 = EXmDZJu7BtVLwj4.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		NYyXGh8fLlE95Cr = JGmfjhoyKZUl(vGg1hAkzqi8exVbN(u"ࠬࡪࡩࡤࡶࠪဋ"),EXmDZJu7BtVLwj4)
		if NYyXGh8fLlE95Cr:
			CsaNhTtGm8 = {}
			for aOf4PbHpSiUm6eGDA1u0ky5wMvdln in NYyXGh8fLlE95Cr.keys():
				CsaNhTtGm8[aOf4PbHpSiUm6eGDA1u0ky5wMvdln] = []
				for nDlq7HK1JUjXpiRS9NyamsALB4wv in NYyXGh8fLlE95Cr[aOf4PbHpSiUm6eGDA1u0ky5wMvdln]:
					TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
					TeDLBxpO03aonZFfQbNuK9S = nDlq7HK1JUjXpiRS9NyamsALB4wv[UwCT5Oz6Wo0BP]
					Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = nDlq7HK1JUjXpiRS9NyamsALB4wv[Mn5NGAdz6xc42s0]
					Wo5ZqMiTYmSgUCvalXhRer4OjpP7 = rBzf3emckoV5bh7wl4nuastES(Wo5ZqMiTYmSgUCvalXhRer4OjpP7)
					ZTG4ruxXUsc9N = nDlq7HK1JUjXpiRS9NyamsALB4wv[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
					My3un1OVBNfSQm = nDlq7HK1JUjXpiRS9NyamsALB4wv[O4dklMvZ8ULcS]
					EELGungxe6wKPar9hyRv5FUMpIB = nDlq7HK1JUjXpiRS9NyamsALB4wv[NEc173Pr0jAwLF5OS]
					wlxviMOuNeQVct4ULsCEHXZm6yR2p = nDlq7HK1JUjXpiRS9NyamsALB4wv[vhZ5qjay1z94JmcMOgXe(u"࠹ᑪ")]
					if len(nDlq7HK1JUjXpiRS9NyamsALB4wv)>eCpDE6wJtYUHn0GqK5(u"࠻ᑫ"): xQXoDIqn4Ucsthb2G7YpzwPTymi = nDlq7HK1JUjXpiRS9NyamsALB4wv[eCpDE6wJtYUHn0GqK5(u"࠻ᑫ")]
					if len(nDlq7HK1JUjXpiRS9NyamsALB4wv)>A2MHFvoqpZ64gNbB(u"࠽ᑬ"): Zxb5IVorSH9j0avgd3UfR6KeC = nDlq7HK1JUjXpiRS9NyamsALB4wv[A2MHFvoqpZ64gNbB(u"࠽ᑬ")]
					if len(nDlq7HK1JUjXpiRS9NyamsALB4wv)>A2MHFvoqpZ64gNbB(u"࠸ᑭ"): QsWU0ew5xMjBozVtqHAGDTNyL4Ia = nDlq7HK1JUjXpiRS9NyamsALB4wv[A2MHFvoqpZ64gNbB(u"࠸ᑭ")]
					if H047EqbDXrPzSx==tJuIjTFl9cwGz2dishvoUm4SPK3ArB: Kli06PbBztwIvFSg1HeYGpnjd3 = TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zg9FeADE84jSRIvPCrzYulw3sL,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
					else: Kli06PbBztwIvFSg1HeYGpnjd3 = TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia
					CsaNhTtGm8[aOf4PbHpSiUm6eGDA1u0ky5wMvdln].append(Kli06PbBztwIvFSg1HeYGpnjd3)
		jd3r4eqQKWnYAGEJtDoy = str(CsaNhTtGm8)
		if GGfPQnrJKEqMv2ZVxdD: jd3r4eqQKWnYAGEJtDoy = jd3r4eqQKWnYAGEJtDoy.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		open(H047EqbDXrPzSx,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡷࡣࠩဌ")).write(jd3r4eqQKWnYAGEJtDoy)
	return CsaNhTtGm8
def aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC):
	CCTmngZSNhUfO5zBcRGrIeWMlVD = FLqQoZwdAngNkz49RMGUHJXW3bDC.split(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠮ࠩဍ"),Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
	AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if   CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠨࡃࡋ࡛ࡆࡑࠧဎ")		:	from YBhVmwNfDK			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==eCpDE6wJtYUHn0GqK5(u"ࠩࡄࡏࡔࡇࡍࠨဏ")		:	from pQ1ZiwXaM0			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==A2MHFvoqpZ64gNbB(u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬတ")	:	from Szw076nNGR		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡆࡑࡗࡂࡏࠪထ")		:	from IyYirQzZGv			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠬࡇࡋࡘࡃࡐࡘ࡚ࡈࡅࠨဒ")	:	from ciYKf9J6S1		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==yNBjYsgc23xoW(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ဓ")	:	from y9svExgqST			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ReLGYUQjz7C9iEd(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩန")	:	from FFR2UawxiY		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==UixkloZbzGw28ujW56X(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫပ")	: 	from GMldKzIVD7		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫဖ")	:	from LwCQGXVja7		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==E3i1eCBtN2w(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫဗ")	:	from TUXrq2Wucb		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vhZ5qjay1z94JmcMOgXe(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ဘ")	:	from GeFPYWAKRj		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪမ"):	from zzOfaw1ZSn	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨယ")	:	from yJTdSCOX7x		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠧࡂ࡛ࡏࡓࡑ࠭ရ")		:	from A56FmERZHb			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡄࡒࡏࡗࡇࠧလ")		:	from Y9cjIvMwV2			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩဝ")	:	from uuL0bjGAER			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==NIBsHMvSXb(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫသ")	:	from HV95jRad3o		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫဟ")	:	from Lwb5ZvxjPS			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬဠ")	:	from FVRYiGMdJh			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ReLGYUQjz7C9iEd(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨအ")	:	from F91TH3ni7m		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==NIBsHMvSXb(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩဢ")	:	from Ym4jT1kfeg		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ReLGYUQjz7C9iEd(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧဣ"):	from CZwfHSTMnR	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫဤ")	:	from fForZ4LwTl		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==E3i1eCBtN2w(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬဥ")	:	from x4UtLnquX5		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ဦ")	:	from p01WPVqYlg		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vGg1hAkzqi8exVbN(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨဧ")	:	from gNX7Y4t0Sb		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧဨ")	:	from fAYMmzEO20		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IYC4iPxkTRUE85namF6(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩဩ")	:	from WWQh20gXyq		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==eCpDE6wJtYUHn0GqK5(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ဪ"):	from tAvpx4RZWu	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬါ")	:	from rpVHW0BUAq		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==eCpDE6wJtYUHn0GqK5(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫာ")	:	from uxCB1EvZIL		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬိ")	:	from jaOvDTcmbZ		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==UixkloZbzGw28ujW56X(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧီ")	:	from AUPfVWo8Bn		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨု")	:	from XN15zTsRbO		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩူ")	:	from nI3TcUWd10		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪေ")	:	from r1IcxTB74l		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪဲ")	:	from TlGyYrZ0EN		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==vGg1hAkzqi8exVbN(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪဳ")	:	from urBoEOnx02			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ဴ")	:	from NOExhUsqZF		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨဵ")	:	from ktcdbBlICJ		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧံ")	:	from IvCTXhSxEe		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==JP65RzKaScIf(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ့࡙ࠪ")	:	from P4zITBLrK0		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩး")	:	from LovIOcuEeK		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴္ࠫ")	:	from xVvmRMp79W		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ttC4VURALPYKh(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶်ࠬ")	:	from KKnTgpavVf		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"ࠫࡋࡕࡓࡕࡃࠪျ")		:	from jmrw5AQV9g			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭ြ")	:	from axMUBXdfLb		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==E3i1eCBtN2w(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨွ")	:	from u93ocWIFpr		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬှ"):	from lDN1vpXqbR	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==eCpDE6wJtYUHn0GqK5(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧဿ"):	from FXDcd3soka	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ttC4VURALPYKh(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ၀")	:	from QQHduikc5f		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡍࡋࡏࡌࡎࠩ၁")		:	from IETgz37Lqy			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==yNBjYsgc23xoW(u"ࠫࡎࡖࡔࡗࠩ၂")		:	from OAJRx3Djkr			import bbR3FyrsBGSoft as AxIs6lqNDCuzmEwoKg475J,kkjBRKDdmEAuncTUShs1M2GrC6g3 as BZNYcxOXAElzS2IPf0aji,XZCQDjv9WNEA2SPdB3cTObaMI7qxl0 as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==yNBjYsgc23xoW(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ၃")	:	from sHC7O1VgMi		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ၄")	:	from DsYE3bQMhP		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==yNBjYsgc23xoW(u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ၅")	:	from k560CXdIMv		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==YXm2qAbu8Qsx(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩ၆")	:	from CmIRW3dsz6		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ၇")	:	from SdHpbQKWze			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ၈")	:	from nBcTwsL9kY		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡒ࠹ࡕࠨ၉")		:	from Lb65UCfP20			import bbR3FyrsBGSoft as AxIs6lqNDCuzmEwoKg475J,kkjBRKDdmEAuncTUShs1M2GrC6g3 as BZNYcxOXAElzS2IPf0aji,XZCQDjv9WNEA2SPdB3cTObaMI7qxl0 as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==x9PULjztJOpu7b(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨ၊")	:	from PetBNZE18i		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==A2MHFvoqpZ64gNbB(u"࠭ࡍࡐࡘࡖ࠸࡚࠭။")	:	from EE6g4ZBibI			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==NIBsHMvSXb(u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ၌")	:	from wwKvyLS7uU			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"ࠨࡒࡄࡒࡊ࡚ࠧ၍")		:	from iCRQa4Oc8X			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"ࠩࡔࡊࡎࡒࡍࠨ၎")		:	from gwLkxirdMG			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==DKmLTA2yGtj(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧ၏"):	from ux0yD8HI7h		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==ykE045Tatx(u"ࠫࡘࡎࡁࡃࡃࡎࡅ࡙࡟ࠧၐ")	:	from SSibqHsJV3		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧၑ")	:	from yeiIX36zJo		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪၒ"):	from DD8x9nGTjO		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==yNBjYsgc23xoW(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪၓ")	:	from J6SZDv8IaX		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡕࡋࡓࡋࡎࡁࠨၔ")	:	from SkxuGj30n4			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IYC4iPxkTRUE85namF6(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫၕ")	:	from LhE3QqKS2J		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==A2MHFvoqpZ64gNbB(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬၖ")	:	from Z5KTxaBCsb		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==wFYiVd4r12x7CAQBL5SPof(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ၗ")	:	from fHmezsZOGV		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==dn9ouNryjHiBFQOhASvX(u"࡚ࠬࡉࡌࡃࡄࡘࠬၘ")	:	from WWDTkiomsl			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IYC4iPxkTRUE85namF6(u"࠭ࡔࡗࡈࡘࡒࠬၙ")		:	from L1PV8IBk34			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡕࡘࡉ࡙ࡓ࠭ၚ")		:	from L1PV8IBk34			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==JP65RzKaScIf(u"ࠨࡘࡄࡖࡇࡕࡎࠨၛ")	:	from m5GCozxNf9			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭ၜ"):	from MrKVAfbEcy		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==Vi1oNCM5kI7yJ0(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫၝ")	:	from x6reJKUPRb		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==E3i1eCBtN2w(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬၞ")	:	from g9dJL8N73E		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==IYC4iPxkTRUE85namF6(u"ࠬ࡟ࡁࡒࡑࡗࠫၟ")		:	from nMduPwQNBv			import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==A2MHFvoqpZ64gNbB(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧၠ")	:	from eRwxN7KrW0		import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,KkZtb4lhPd as BZNYcxOXAElzS2IPf0aji,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	elif CCTmngZSNhUfO5zBcRGrIeWMlVD==eCpDE6wJtYUHn0GqK5(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ၡ"):	from rEbLJu0WX6	import bELNFKS6fCB as AxIs6lqNDCuzmEwoKg475J,j0jSEdTPJuG4XNvfpO as j8mQOhzZPXTwfLVM63riBa
	return AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa
def seYEjxGn1qkDZbXQtifpJLP3R(U6Lfok2vKIGRJejl5qzxMtC4iYOA,Ay2hPpbZC7XmtQlwnfBT8,showDialogs):
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,yyZPkLCRX1xcBDN(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨ࠼ࠣ࡟ࠥ࠭ၢ")+U6Lfok2vKIGRJejl5qzxMtC4iYOA+vhZ5qjay1z94JmcMOgXe(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬၣ")+str(Ay2hPpbZC7XmtQlwnfBT8)+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࠤࡢ࠭ၤ"))
	zkK23NOgQFhY75mjwDuxfbsc1EUiqS = Rr8woplmSQWXIZcGFfA()
	zkK23NOgQFhY75mjwDuxfbsc1EUiqS.create(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၥ"),NIBsHMvSXb(u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧၦ"))
	HSBPMf3ZT4L7 = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠲࠲࠵࠸ᑮ")*OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠲࠲࠵࠸ᑮ")
	jc1hxgZQB3yTXAKD6 = E3i1eCBtN2w(u"࠳ᑯ")*HSBPMf3ZT4L7
	import requests as CzrjWh4Xgi3cqPZ2K
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = CzrjWh4Xgi3cqPZ2K.get(U6Lfok2vKIGRJejl5qzxMtC4iYOA,stream=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,headers=Ay2hPpbZC7XmtQlwnfBT8)
	E3EhtVHTk6 = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.headers
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.close()
	V4VdjXGEzoT6wyxmv1siRheQqCA = bytes()
	if not E3EhtVHTk6:
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၧ"),dn9ouNryjHiBFQOhASvX(u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪၨ"))
		zkK23NOgQFhY75mjwDuxfbsc1EUiqS.close()
	else:
		if OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩၩ") not in list(E3EhtVHTk6.keys()): KlIzJpnqFPZCHixVkmgQ240LUXjvc9 = UwCT5Oz6Wo0BP
		else: KlIzJpnqFPZCHixVkmgQ240LUXjvc9 = int(E3EhtVHTk6[DKmLTA2yGtj(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪၪ")])
		JQUrnN8qcX2La3Hf0M4lxPCTA = str(int(wFYiVd4r12x7CAQBL5SPof(u"࠵࠵࠶࠰ᑱ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9/HSBPMf3ZT4L7)/tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠴࠴࠵࠶࠮࠱ᑰ"))
		prKeIXDMZShi1YcB2qsxPoA8NOlG = int(KlIzJpnqFPZCHixVkmgQ240LUXjvc9/jc1hxgZQB3yTXAKD6)+Mn5NGAdz6xc42s0
		if ttC4VURALPYKh(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪၫ") in list(E3EhtVHTk6.keys()) and KlIzJpnqFPZCHixVkmgQ240LUXjvc9>HSBPMf3ZT4L7:
			QSqXOF7UhcVYm42yntGMRCNb9Wdl = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			fIWwciB6XE = []
			DK6RznVyGZHLXs = lU1fSmncFWjizwqZugyYBANML0(u"࠶࠶ᑲ")
			fIWwciB6XE.append(str(UwCT5Oz6Wo0BP*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+A2MHFvoqpZ64gNbB(u"ࠫ࠲࠭ၬ")+str(Mn5NGAdz6xc42s0*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(Mn5NGAdz6xc42s0*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+ZYTyoA483N(u"ࠬ࠳ࠧၭ")+str(DpahB8cwl4ZeKVsg71RuibSAfx0Ejr*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(DpahB8cwl4ZeKVsg71RuibSAfx0Ejr*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭࠭ࠨၮ")+str(O4dklMvZ8ULcS*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(O4dklMvZ8ULcS*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࠮ࠩၯ")+str(NEc173Pr0jAwLF5OS*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(NEc173Pr0jAwLF5OS*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+ReLGYUQjz7C9iEd(u"ࠨ࠯ࠪၰ")+str(vGg1hAkzqi8exVbN(u"࠻ᑳ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(ttC4VURALPYKh(u"࠵ᑴ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+JP65RzKaScIf(u"ࠩ࠰ࠫၱ")+str(jozVWcERh91GOF2NHXQiSwKqe8x(u"࠷ᑵ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠹ᑷ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+UixkloZbzGw28ujW56X(u"ࠪ࠱ࠬၲ")+str(YXm2qAbu8Qsx(u"࠹ᑶ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(IYC4iPxkTRUE85namF6(u"࠼ᑹ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+yNBjYsgc23xoW(u"ࠫ࠲࠭ၳ")+str(vhZ5qjay1z94JmcMOgXe(u"࠼ᑸ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(ee3tnwl7avk(u"࠸ᑻ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+x9PULjztJOpu7b(u"ࠬ࠳ࠧၴ")+str(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠿ᑺ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs-Mn5NGAdz6xc42s0))
			fIWwciB6XE.append(str(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠺ᑼ")*KlIzJpnqFPZCHixVkmgQ240LUXjvc9//DK6RznVyGZHLXs)+ee3tnwl7avk(u"࠭࠭ࠨၵ"))
			NrDBUh3vgk = float(prKeIXDMZShi1YcB2qsxPoA8NOlG)/DK6RznVyGZHLXs
			Dcpz6SC0tTN = NrDBUh3vgk/int(Mn5NGAdz6xc42s0+NrDBUh3vgk)
		else:
			QSqXOF7UhcVYm42yntGMRCNb9Wdl = vvglE69OFKBm817Nkc
			DK6RznVyGZHLXs = Mn5NGAdz6xc42s0
			Dcpz6SC0tTN = Mn5NGAdz6xc42s0
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,ZYTyoA483N(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨၶ")+str(QSqXOF7UhcVYm42yntGMRCNb9Wdl)+JP65RzKaScIf(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪၷ")+str(KlIzJpnqFPZCHixVkmgQ240LUXjvc9)+ee3tnwl7avk(u"ࠩࠣࡡࠬၸ"))
		OEJ3PT81KtbZ,qtENYb2IhCniz0ckaRQJGe3FwTHZOf = UwCT5Oz6Wo0BP,UwCT5Oz6Wo0BP
		for V8lpkbt69RLE1Nd5jAYizJOge in range(DK6RznVyGZHLXs):
			Y3OmVPp2ARgBCjn = Ay2hPpbZC7XmtQlwnfBT8.copy()
			if QSqXOF7UhcVYm42yntGMRCNb9Wdl: Y3OmVPp2ARgBCjn[wFYiVd4r12x7CAQBL5SPof(u"ࠪࡖࡦࡴࡧࡦࠩၹ")] = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡧࡿࡴࡦࡵࡀࠫၺ")+fIWwciB6XE[V8lpkbt69RLE1Nd5jAYizJOge]
			Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = CzrjWh4Xgi3cqPZ2K.get(U6Lfok2vKIGRJejl5qzxMtC4iYOA,stream=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,headers=Y3OmVPp2ARgBCjn,timeout=JP65RzKaScIf(u"࠵࠳࠴ᑽ"))
			for XLjvKT637FoBIVlgi in Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.iter_content(chunk_size=jc1hxgZQB3yTXAKD6):
				if zkK23NOgQFhY75mjwDuxfbsc1EUiqS.iscanceled():
					zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬၻ"))
					break
				OEJ3PT81KtbZ += Dcpz6SC0tTN
				V4VdjXGEzoT6wyxmv1siRheQqCA += XLjvKT637FoBIVlgi
				if not qtENYb2IhCniz0ckaRQJGe3FwTHZOf: qtENYb2IhCniz0ckaRQJGe3FwTHZOf = len(XLjvKT637FoBIVlgi)
				if KlIzJpnqFPZCHixVkmgQ240LUXjvc9: OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠴࠴࠵ᑾ")*OEJ3PT81KtbZ//prKeIXDMZShi1YcB2qsxPoA8NOlG,ykE045Tatx(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧၼ"),str(UQS9lVew50DIyXrinWsMxTzA(u"࠵࠵࠶࠮࠱ᑿ")*qtENYb2IhCniz0ckaRQJGe3FwTHZOf*OEJ3PT81KtbZ//jc1hxgZQB3yTXAKD6//UQS9lVew50DIyXrinWsMxTzA(u"࠵࠵࠶࠮࠱ᑿ"))+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࠡ࠱ࠣࠫၽ")+JQUrnN8qcX2La3Hf0M4lxPCTA+DKmLTA2yGtj(u"ࠨࠢࡐࡆࠬၾ"))
				else: OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,qtENYb2IhCniz0ckaRQJGe3FwTHZOf*OEJ3PT81KtbZ//jc1hxgZQB3yTXAKD6,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧၿ"),str(eCpDE6wJtYUHn0GqK5(u"࠶࠶࠰࠯࠲ᒀ")*qtENYb2IhCniz0ckaRQJGe3FwTHZOf*OEJ3PT81KtbZ//jc1hxgZQB3yTXAKD6//eCpDE6wJtYUHn0GqK5(u"࠶࠶࠰࠯࠲ᒀ"))+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࠤࡒࡈࠧႀ"))
			Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.close()
		zkK23NOgQFhY75mjwDuxfbsc1EUiqS.close()
		if len(V4VdjXGEzoT6wyxmv1siRheQqCA)<KlIzJpnqFPZCHixVkmgQ240LUXjvc9 and KlIzJpnqFPZCHixVkmgQ240LUXjvc9>UwCT5Oz6Wo0BP:
			zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,Vi1oNCM5kI7yJ0(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧႁ")+str(len(V4VdjXGEzoT6wyxmv1siRheQqCA)//HSBPMf3ZT4L7)+vhZ5qjay1z94JmcMOgXe(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪႂ")+JQUrnN8qcX2La3Hf0M4lxPCTA+vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࠠࡎࡄࠣࡡࠬႃ"))
			mQOFUVBbfyv39kzto0Nw4 = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬႄ"),eCpDE6wJtYUHn0GqK5(u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨႅ"),A2MHFvoqpZ64gNbB(u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫႆ"),ZYTyoA483N(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႇ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨႈ")+str(len(V4VdjXGEzoT6wyxmv1siRheQqCA)//HSBPMf3ZT4L7)+E3i1eCBtN2w(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫႉ")+JQUrnN8qcX2La3Hf0M4lxPCTA+eCpDE6wJtYUHn0GqK5(u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨႊ"))
			if mQOFUVBbfyv39kzto0Nw4==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: V4VdjXGEzoT6wyxmv1siRheQqCA = seYEjxGn1qkDZbXQtifpJLP3R(U6Lfok2vKIGRJejl5qzxMtC4iYOA,Ay2hPpbZC7XmtQlwnfBT8,showDialogs)
			elif mQOFUVBbfyv39kzto0Nw4==Mn5NGAdz6xc42s0: zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,yyZPkLCRX1xcBDN(u"ࠧ࠯࡞ࡷࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭ႋ"))
			else: return Zg9FeADE84jSRIvPCrzYulw3sL
			if not V4VdjXGEzoT6wyxmv1siRheQqCA: return Zg9FeADE84jSRIvPCrzYulw3sL
		else: zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,dn9ouNryjHiBFQOhASvX(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬႌ")+JQUrnN8qcX2La3Hf0M4lxPCTA+ykE045Tatx(u"ࠩࠣࡑࡇࠦ࡝ࠨႍ"))
	return V4VdjXGEzoT6wyxmv1siRheQqCA
def DDgEMsaOcFGd(bIPsOxjEpoH):
	return Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO
def gOd5YrkR6jsFX(ip=Zg9FeADE84jSRIvPCrzYulw3sL):
	global ySqfAUYh0x8BPDio1MQsOLedzWN
	if ySqfAUYh0x8BPDio1MQsOLedzWN: return ySqfAUYh0x8BPDio1MQsOLedzWN
	GGLBJrdwkxjCil0hs,yZ8XuBSf1M0NvqILAnYQGd36,qnCJtOGSw0F3rWPVe8Do5K,sdxOXbcqh4,oNuVcjt20SG3EnXdA,BWpnLmYSQxrOM0uXI5elVqJ62FGTC = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	ZTG4ruxXUsc9N = yyZPkLCRX1xcBDN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭ႎ")+ip+JP65RzKaScIf(u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩႏ")
	Ay2hPpbZC7XmtQlwnfBT8 = {dn9ouNryjHiBFQOhASvX(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ႐"):Zg9FeADE84jSRIvPCrzYulw3sL}
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,NIBsHMvSXb(u"࠭ࡇࡆࡖࠪ႑"),ZTG4ruxXUsc9N,Zg9FeADE84jSRIvPCrzYulw3sL,Ay2hPpbZC7XmtQlwnfBT8,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ႒"))
	if not Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		ZTG4ruxXUsc9N = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳ࠱ࡦࡶࡩ࠯ࡥࡲࡱ࠴ࡰࡳࡰࡰ࠲ࠫ႓")+ip+E3i1eCBtN2w(u"ࠩࡂࡪ࡮࡫࡬ࡥࡵࡀࡵࡺ࡫ࡲࡺ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥ࠭ࡥ࡬ࡸࡾ࠲࡯ࡧࡨࡶࡩࡹ࠭႔")
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,eCpDE6wJtYUHn0GqK5(u"ࠪࡋࡊ࡚ࠧ႕"),ZTG4ruxXUsc9N,Zg9FeADE84jSRIvPCrzYulw3sL,Ay2hPpbZC7XmtQlwnfBT8,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠶ࡳࡪࠧ႖"))
	if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
		IxQ2cS4jAK3ZtHpiPJs1y = lSD9w50N6VBOHbfT2WRiPsM.loads(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		llroBzYKF9WTe1UG = list(IxQ2cS4jAK3ZtHpiPJs1y.keys())
		if vhZ5qjay1z94JmcMOgXe(u"ࠬ࡯ࡰࠨ႗") in llroBzYKF9WTe1UG: ip = IxQ2cS4jAK3ZtHpiPJs1y[qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࡩࡱࠩ႘")]
		if zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ႙") in llroBzYKF9WTe1UG: GGLBJrdwkxjCil0hs = IxQ2cS4jAK3ZtHpiPJs1y[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫႚ")]
		if ykE045Tatx(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪႛ") in llroBzYKF9WTe1UG: yZ8XuBSf1M0NvqILAnYQGd36 = IxQ2cS4jAK3ZtHpiPJs1y[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫႜ")]
		if A2MHFvoqpZ64gNbB(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪႝ") in llroBzYKF9WTe1UG: qnCJtOGSw0F3rWPVe8Do5K = IxQ2cS4jAK3ZtHpiPJs1y[ReLGYUQjz7C9iEd(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ႞")]
		if UixkloZbzGw28ujW56X(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭႟") in llroBzYKF9WTe1UG: sdxOXbcqh4 = IxQ2cS4jAK3ZtHpiPJs1y[IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧႠ")]
		if okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡥ࡬ࡸࡾ࠭Ⴁ") in llroBzYKF9WTe1UG: oNuVcjt20SG3EnXdA = IxQ2cS4jAK3ZtHpiPJs1y[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡦ࡭ࡹࡿࠧႢ")]
		if A2MHFvoqpZ64gNbB(u"ࠪࡵࡺ࡫ࡲࡺࠩႣ") in llroBzYKF9WTe1UG: ip = IxQ2cS4jAK3ZtHpiPJs1y[ykE045Tatx(u"ࠫࡶࡻࡥࡳࡻࠪႤ")]
		if UixkloZbzGw28ujW56X(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧࠪႥ") in llroBzYKF9WTe1UG: qnCJtOGSw0F3rWPVe8Do5K = IxQ2cS4jAK3ZtHpiPJs1y[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨࠫႦ")]
		if A2MHFvoqpZ64gNbB(u"ࠧࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨࠫႧ") in llroBzYKF9WTe1UG: sdxOXbcqh4 = IxQ2cS4jAK3ZtHpiPJs1y[dn9ouNryjHiBFQOhASvX(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡏࡣࡰࡩࠬႨ")]
		if wFYiVd4r12x7CAQBL5SPof(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫႩ") in llroBzYKF9WTe1UG:
			BWpnLmYSQxrOM0uXI5elVqJ62FGTC = IxQ2cS4jAK3ZtHpiPJs1y[UixkloZbzGw28ujW56X(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬႪ")][UixkloZbzGw28ujW56X(u"ࠫࡺࡺࡣࠨႫ")]
			if BWpnLmYSQxrOM0uXI5elVqJ62FGTC[UwCT5Oz6Wo0BP] not in [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬ࠳ࠧႬ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࠫࠨႭ")]: BWpnLmYSQxrOM0uXI5elVqJ62FGTC = ykE045Tatx(u"ࠧࠬࠩႮ")+BWpnLmYSQxrOM0uXI5elVqJ62FGTC
		if IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡱࡩࡪࡸ࡫ࡴࠨႯ") in llroBzYKF9WTe1UG:
			BWpnLmYSQxrOM0uXI5elVqJ62FGTC = IxQ2cS4jAK3ZtHpiPJs1y[ReLGYUQjz7C9iEd(u"ࠩࡲࡪ࡫ࡹࡥࡵࠩႰ")]
			if BWpnLmYSQxrOM0uXI5elVqJ62FGTC>=x9PULjztJOpu7b(u"࠶ᒁ"): BWpnLmYSQxrOM0uXI5elVqJ62FGTC = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪ࠯ࠬႱ")+LNma2eq3vEguwVtHjn.strftime(ttC4VURALPYKh(u"ࠦࠪࡎ࠺ࠦࡏࠥႲ"),LNma2eq3vEguwVtHjn.gmtime(BWpnLmYSQxrOM0uXI5elVqJ62FGTC))
			else: BWpnLmYSQxrOM0uXI5elVqJ62FGTC = yNBjYsgc23xoW(u"ࠬ࠳ࠧႳ")+LNma2eq3vEguwVtHjn.strftime(JP65RzKaScIf(u"ࠨࠥࡉ࠼ࠨࡑࠧႴ"),LNma2eq3vEguwVtHjn.gmtime(-BWpnLmYSQxrOM0uXI5elVqJ62FGTC))
	ySqfAUYh0x8BPDio1MQsOLedzWN = ip+qdEKO42r3GhwmCDcHtxzJUR(u"ࠧ࠭ࠩႵ")+GGLBJrdwkxjCil0hs+YXm2qAbu8Qsx(u"ࠨ࠮ࠪႶ")+yZ8XuBSf1M0NvqILAnYQGd36+UixkloZbzGw28ujW56X(u"ࠩ࠯ࠫႷ")+sdxOXbcqh4+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࠰ࠬႸ")+oNuVcjt20SG3EnXdA+IYC4iPxkTRUE85namF6(u"ࠫ࠱࠭Ⴙ")+BWpnLmYSQxrOM0uXI5elVqJ62FGTC
	ySqfAUYh0x8BPDio1MQsOLedzWN = ySqfAUYh0x8BPDio1MQsOLedzWN.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	if GGfPQnrJKEqMv2ZVxdD: ySqfAUYh0x8BPDio1MQsOLedzWN = ySqfAUYh0x8BPDio1MQsOLedzWN.decode(ee3tnwl7avk(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭Ⴚ"))
	ySqfAUYh0x8BPDio1MQsOLedzWN = uumhMi6O4pk7Gjd5aTQqy2Z(ySqfAUYh0x8BPDio1MQsOLedzWN)
	return ySqfAUYh0x8BPDio1MQsOLedzWN
def xXQLatdZbuT1H6(x934U2LmVgfZnXuzj8hOFMK6):
	v43xwTiXeU,showDialogs = Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if x934U2LmVgfZnXuzj8hOFMK6.count(NIBsHMvSXb(u"࠭࡟ࠨႻ"))>=DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
		x934U2LmVgfZnXuzj8hOFMK6,v43xwTiXeU = x934U2LmVgfZnXuzj8hOFMK6.split(A2MHFvoqpZ64gNbB(u"ࠧࡠࠩႼ"),Mn5NGAdz6xc42s0)
		v43xwTiXeU = DKmLTA2yGtj(u"ࠨࡡࠪႽ")+v43xwTiXeU
		if ReLGYUQjz7C9iEd(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧႾ") in v43xwTiXeU: showDialogs = vvglE69OFKBm817Nkc
		else: showDialogs = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return x934U2LmVgfZnXuzj8hOFMK6,v43xwTiXeU,showDialogs
def f3mSgGZVx4l0qOtsWCQvkTu9Ky():
	S9k5pCrhxX3yH7 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,dn9ouNryjHiBFQOhASvX(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩႿ"))
	ICNxS4XfEnmvWdbeGprk = UwCT5Oz6Wo0BP
	if brAUlZfdFmt3TRJW2xX4.path.exists(S9k5pCrhxX3yH7):
		for ZMwJRKp4kcIvPrd7ih6e3njX in brAUlZfdFmt3TRJW2xX4.listdir(S9k5pCrhxX3yH7):
			if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫ࠳ࡶࡹࡰࠩჀ") in ZMwJRKp4kcIvPrd7ih6e3njX: continue
			if ReLGYUQjz7C9iEd(u"ࠬࡥ࡟ࡱࡻࡦࡥࡨ࡮ࡥࡠࡡࠪჁ") in ZMwJRKp4kcIvPrd7ih6e3njX: continue
			aLCfkjG24NFqbPYv7s1y8xK = brAUlZfdFmt3TRJW2xX4.path.join(S9k5pCrhxX3yH7,ZMwJRKp4kcIvPrd7ih6e3njX)
			U2OTiqjluMHLVhcg4Ako,Ahcb3XWMIz0JYT6g7jEpmsq = M0VZ1cU2uDToibE6yj37RzCxkX5L(aLCfkjG24NFqbPYv7s1y8xK)
			ICNxS4XfEnmvWdbeGprk += U2OTiqjluMHLVhcg4Ako
	return ICNxS4XfEnmvWdbeGprk
def oYKDVlk6dFXTMf5zgG4jW38sp(showDialogs):
	F07xTam1PlSJvgocX3CIQB2fuZpq = yUTYoAgth5iC43uLrdBH.getSetting(x9PULjztJOpu7b(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫჂ"))
	jgC71X9o6t5P = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,YXm2qAbu8Qsx(u"ࠧࡴࡶࡵࠫჃ"),YXm2qAbu8Qsx(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫჄ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫჅ"))
	Th0DbSOd2HNCU9,N5D20BPt1WkELsrvmM = F07xTam1PlSJvgocX3CIQB2fuZpq,jgC71X9o6t5P
	Pbd4RfxHuBI5Z3Aq7Ke6Uwg0Y8,TTKgIZWHL0Aw72 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if Mn5NGAdz6xc42s0:
		ZTG4ruxXUsc9N = PhpFa6EdVS[UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ჆")][O4dklMvZ8ULcS]
		HHg6LBxyifWDl2Oucpn = gOd5YrkR6jsFX()
		yZ8XuBSf1M0NvqILAnYQGd36 = HHg6LBxyifWDl2Oucpn.split(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫ࠱࠭Ⴧ"))[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		ICNxS4XfEnmvWdbeGprk = f3mSgGZVx4l0qOtsWCQvkTu9Ky()
		VVYFjoZJNU7kCtnwDrPxfSGb = {jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࡻࡳࡦࡴࠪ჈"):fs60XkagtWFJ,UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ჉"):kI8qwbo6yER,IYC4iPxkTRUE85namF6(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ჊"):yZ8XuBSf1M0NvqILAnYQGd36,yyZPkLCRX1xcBDN(u"ࠨ࡫ࡧࡷࠬ჋"):opwNMkO7yVeCJXqPI(ICNxS4XfEnmvWdbeGprk)}
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,E3i1eCBtN2w(u"ࠩࡓࡓࡘ࡚ࠧ჌"),ZTG4ruxXUsc9N,VVYFjoZJNU7kCtnwDrPxfSGb,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧჍ"))
		if not Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
			if F07xTam1PlSJvgocX3CIQB2fuZpq in [Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"ࠫࡓࡋࡗࠨ჎")]: Th0DbSOd2HNCU9 = ttC4VURALPYKh(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ჏")
			elif F07xTam1PlSJvgocX3CIQB2fuZpq==DKmLTA2yGtj(u"࠭ࡏࡍࡆࠪა"): Th0DbSOd2HNCU9 = vhZ5qjay1z94JmcMOgXe(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ბ")
		else:
			f7n4eZYsUPl5uOEQNtmyv8xCJ0M = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
			f7n4eZYsUPl5uOEQNtmyv8xCJ0M = JGmfjhoyKZUl(E3i1eCBtN2w(u"ࠨ࡮࡬ࡷࡹ࠭გ"),f7n4eZYsUPl5uOEQNtmyv8xCJ0M)
			f7n4eZYsUPl5uOEQNtmyv8xCJ0M = sorted(f7n4eZYsUPl5uOEQNtmyv8xCJ0M,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: int(key[UwCT5Oz6Wo0BP]))
			TTKgIZWHL0Aw72,N5D20BPt1WkELsrvmM = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
			for v5tZV04CYPsf6jX,x8NYj9ZKAMkOthdQEB,vvOzwTgFtar in f7n4eZYsUPl5uOEQNtmyv8xCJ0M:
				if v5tZV04CYPsf6jX==vGg1hAkzqi8exVbN(u"ࠩ࠳ࠫდ"):
					TTKgIZWHL0Aw72 += vvOzwTgFtar+vhZ5qjay1z94JmcMOgXe(u"ࠪ࠾࠿࠭ე")
					continue
				if N5D20BPt1WkELsrvmM: N5D20BPt1WkELsrvmM += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+NIBsHMvSXb(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪვ")+u4IRSmrYMKkaHUBnDiLWh+JP65RzKaScIf(u"ࠬࡢ࡮࡝ࡰࠪზ")
				ozutpg7NDSyqbF9BcejwJlx0Ak = vvOzwTgFtar.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)[UwCT5Oz6Wo0BP]
				feKw2ynYhdXcFt = ReLGYUQjz7C9iEd(u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪთ") if x8NYj9ZKAMkOthdQEB else Zg9FeADE84jSRIvPCrzYulw3sL
				N5D20BPt1WkELsrvmM += vvOzwTgFtar.replace(ozutpg7NDSyqbF9BcejwJlx0Ak,U2bWzwG8VdJsBqtR74ErDi3cg1v+ozutpg7NDSyqbF9BcejwJlx0Ak+feKw2ynYhdXcFt+u4IRSmrYMKkaHUBnDiLWh)+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
			N5D20BPt1WkELsrvmM = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+N5D20BPt1WkELsrvmM+Vi1oNCM5kI7yJ0(u"ࠧ࡝ࡰ࡟ࡲࠬი")
			TTKgIZWHL0Aw72 = TTKgIZWHL0Aw72.strip(ReLGYUQjz7C9iEd(u"ࠨ࠼࠽ࠫკ"))
			Pbd4RfxHuBI5Z3Aq7Ke6Uwg0Y8 = yUTYoAgth5iC43uLrdBH.getSetting(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬლ"))
			if N5D20BPt1WkELsrvmM==jgC71X9o6t5P and F07xTam1PlSJvgocX3CIQB2fuZpq in [Vi1oNCM5kI7yJ0(u"ࠪࡓࡑࡊࠧმ"),ReLGYUQjz7C9iEd(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪნ")]: Th0DbSOd2HNCU9 = yyZPkLCRX1xcBDN(u"ࠬࡕࡌࡅࠩო")
			else: Th0DbSOd2HNCU9 = IYC4iPxkTRUE85namF6(u"࠭ࡎࡆ࡙ࠪპ")
			cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,x9PULjztJOpu7b(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪჟ"),yyZPkLCRX1xcBDN(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪრ"),N5D20BPt1WkELsrvmM,B4GWT7zonF5yipbIwJmNUf6Vavg)
			yUTYoAgth5iC43uLrdBH.setSetting(ttC4VURALPYKh(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪს"),opwNMkO7yVeCJXqPI(PPc8zbiVZnFkfXLBRv))
			yUTYoAgth5iC43uLrdBH.setSetting(dn9ouNryjHiBFQOhASvX(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ტ"),TTKgIZWHL0Aw72)
			Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(IK4zTnSMyGQpxEaesJAPVDY(u"࠵ᒂ")*TTKgIZWHL0Aw72.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
			Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(IYC4iPxkTRUE85namF6(u"࠲࠶ᒃ")*Nic9H6r7M3.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
			Nic9H6r7M3 = GIWbQnAEXrDLaKHwZcgNhfkFj1.md5(ttC4VURALPYKh(u"࠳࠼ᒄ")*Nic9H6r7M3.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)).hexdigest()
			yUTYoAgth5iC43uLrdBH.setSetting(eCpDE6wJtYUHn0GqK5(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧუ"),Nic9H6r7M3)
	if showDialogs:
		if Th0DbSOd2HNCU9 in [UixkloZbzGw28ujW56X(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫფ"),NIBsHMvSXb(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬქ")]:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪღ"),wFYiVd4r12x7CAQBL5SPof(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨყ"))
		else:
			ywuEego16R3ODiKVJr4Yf8qksH0vb(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡵ࡭࡬࡮ࡴࠨშ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭ჩ"),N5D20BPt1WkELsrvmM,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬც"))
			Th0DbSOd2HNCU9 = E3i1eCBtN2w(u"ࠬࡕࡌࡅࠩძ")
	if Th0DbSOd2HNCU9!=F07xTam1PlSJvgocX3CIQB2fuZpq:
		yUTYoAgth5iC43uLrdBH.setSetting(x9PULjztJOpu7b(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫწ"),Th0DbSOd2HNCU9)
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	BBNq3e4rVZU2QvsdYn1xchi = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if TTKgIZWHL0Aw72!=Pbd4RfxHuBI5Z3Aq7Ke6Uwg0Y8 else vvglE69OFKBm817Nkc
	if BBNq3e4rVZU2QvsdYn1xchi:
		XcPLKthYTV.zyKW1Eow48ek0,XcPLKthYTV.dMeaPykZB3Ln8DGuS,XcPLKthYTV.BdihkDomH03OAKgcaCM,XcPLKthYTV.opJSrWfgHQ7 = ZE3oYw0NMipGVt1zJ8yAULgq7nbdx([A2MHFvoqpZ64gNbB(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨჭ"),eCpDE6wJtYUHn0GqK5(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩხ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧჯ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫჰ")])
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def YYF54nVR1W9XAmL2hg0scCtNO(ZDWVv9t3sPk,tDux5SleJq3AVIRwizXnWTLjNg):
	from socket import socket as M8hdlBv4XYT,AF_INET as VF5hbdCzyiXtuJl,SOCK_STREAM as fLCvJouZB5d
	LseNYDPrtFkWEo5I7bjcxwG = M8hdlBv4XYT(VF5hbdCzyiXtuJl,fLCvJouZB5d)
	LseNYDPrtFkWEo5I7bjcxwG.settimeout(Mn5NGAdz6xc42s0)
	ScVZNf7CoTk6PD4A,Hn8sD9g0w4NycmJI7XrBt3Uq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,UwCT5Oz6Wo0BP
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	try: LseNYDPrtFkWEo5I7bjcxwG.connect((ZDWVv9t3sPk,tDux5SleJq3AVIRwizXnWTLjNg))
	except: ScVZNf7CoTk6PD4A = vvglE69OFKBm817Nkc
	HHTqNk9s6AGbKV = LNma2eq3vEguwVtHjn.time()
	if ScVZNf7CoTk6PD4A: Hn8sD9g0w4NycmJI7XrBt3Uq = HHTqNk9s6AGbKV-nnm3Asbhj8z4IDdSXMC1Vx
	return Hn8sD9g0w4NycmJI7XrBt3Uq
def O1o4Qh6m2gWpdP0qwUaFTDMvnEi9yG(showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჱ"),E3i1eCBtN2w(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫჲ"))
	else: jzydmKVUWrCv9D34F = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0:
		for ZMwJRKp4kcIvPrd7ih6e3njX in brAUlZfdFmt3TRJW2xX4.listdir(cc6p0YbTjFzgyG3aRw):
			if ZMwJRKp4kcIvPrd7ih6e3njX.endswith(UQS9lVew50DIyXrinWsMxTzA(u"࠭࠮ࡥࡤࠪჳ")) and tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡥࡣࡷࡥࠬჴ") in ZMwJRKp4kcIvPrd7ih6e3njX:
				w32cbMhWTreVNRq84K = brAUlZfdFmt3TRJW2xX4.path.join(cc6p0YbTjFzgyG3aRw,ZMwJRKp4kcIvPrd7ih6e3njX)
				KAyrTaiwVmYnCS2NbPp,wxljEVBYCes0uWnzdZKDbhyI = KKN3FYextA(w32cbMhWTreVNRq84K)
				wxljEVBYCes0uWnzdZKDbhyI.execute(ee3tnwl7avk(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫჵ"))
				wxljEVBYCes0uWnzdZKDbhyI.execute(NIBsHMvSXb(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧჶ"))
				wxljEVBYCes0uWnzdZKDbhyI.execute(vhZ5qjay1z94JmcMOgXe(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭ჷ"))
				wxljEVBYCes0uWnzdZKDbhyI.execute(ykE045Tatx(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧჸ"))
				wxljEVBYCes0uWnzdZKDbhyI.execute(ReLGYUQjz7C9iEd(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ჹ"))
				KAyrTaiwVmYnCS2NbPp.commit()
				KAyrTaiwVmYnCS2NbPp.close()
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩჺ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ჻"))
	return
def Tk5CeWKZwqrnxjO40(UK14Jf5gkys7dbAcm8D9eloz,EobviSzBLJgICVH,showDialogs):
	if UK14Jf5gkys7dbAcm8D9eloz!=None:
		global DTYFukmj6ZVqygxARW1l0dXOpU2nv
		DTYFukmj6ZVqygxARW1l0dXOpU2nv = UK14Jf5gkys7dbAcm8D9eloz
	if EobviSzBLJgICVH!=None:
		global xR1dtBMSbZ
		xR1dtBMSbZ = EobviSzBLJgICVH
	if showDialogs!=None:
		global HHUlnoL5redz7fE6QKq9jSTv42sMFy
		HHUlnoL5redz7fE6QKq9jSTv42sMFy = showDialogs
	return
def kkUFQPBLE2yHqM0vhW(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,data,headers,allow_redirects,showDialogs,iojW2gVFfT,eejR6xrJkTldh,Bd4TxwQJ87HXUl3G6f):
	if showDialogs==Zg9FeADE84jSRIvPCrzYulw3sL: UsyxcJB6RN2 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if HHUlnoL5redz7fE6QKq9jSTv42sMFy==Zg9FeADE84jSRIvPCrzYulw3sL else HHUlnoL5redz7fE6QKq9jSTv42sMFy
	else: UsyxcJB6RN2 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if showDialogs else vvglE69OFKBm817Nkc
	if Bd4TxwQJ87HXUl3G6f==Zg9FeADE84jSRIvPCrzYulw3sL: rzWNxv2Tjq0FlEUf9D7np = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if xR1dtBMSbZ==Zg9FeADE84jSRIvPCrzYulw3sL else xR1dtBMSbZ
	else: rzWNxv2Tjq0FlEUf9D7np = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if Bd4TxwQJ87HXUl3G6f else vvglE69OFKBm817Nkc
	if eejR6xrJkTldh==Zg9FeADE84jSRIvPCrzYulw3sL: LloZMyTKCedwsV9HY8aWxqbc6BNUi = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if DTYFukmj6ZVqygxARW1l0dXOpU2nv==Zg9FeADE84jSRIvPCrzYulw3sL else DTYFukmj6ZVqygxARW1l0dXOpU2nv
	else: LloZMyTKCedwsV9HY8aWxqbc6BNUi = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if eejR6xrJkTldh else vvglE69OFKBm817Nkc
	if allow_redirects==Zg9FeADE84jSRIvPCrzYulw3sL: U4cbiW1z6T72NVr = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else: U4cbiW1z6T72NVr = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if allow_redirects else vvglE69OFKBm817Nkc
	Y3OmVPp2ARgBCjn = {} if headers==Zg9FeADE84jSRIvPCrzYulw3sL else headers
	mrn4jdBuXKIw7N2lvh = {} if data==Zg9FeADE84jSRIvPCrzYulw3sL else data
	if iojW2gVFfT==DKmLTA2yGtj(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭ჼ"): Y3OmVPp2ARgBCjn = {}
	else:
		orWvKuaFmY6DIxfEJMtc2 = list(Y3OmVPp2ARgBCjn.keys())
		if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪჽ") not in orWvKuaFmY6DIxfEJMtc2: Y3OmVPp2ARgBCjn[x9PULjztJOpu7b(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫჾ")] = ttC4VURALPYKh(u"ࠫ࡭ࡺࡴࡱࠩჿ")
		if YXm2qAbu8Qsx(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᄀ") not in orWvKuaFmY6DIxfEJMtc2: Y3OmVPp2ARgBCjn[NIBsHMvSXb(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᄁ")] = lAfzvsbYy7oQ3r28EMe(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,LloZMyTKCedwsV9HY8aWxqbc6BNUi,rzWNxv2Tjq0FlEUf9D7np
def f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh=Zg9FeADE84jSRIvPCrzYulw3sL,Bd4TxwQJ87HXUl3G6f=Zg9FeADE84jSRIvPCrzYulw3sL):
	uUOrTzxoL3lhmftZnwRpHPaj = kkUFQPBLE2yHqM0vhW(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh,Bd4TxwQJ87HXUl3G6f)
	TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,LloZMyTKCedwsV9HY8aWxqbc6BNUi,rzWNxv2Tjq0FlEUf9D7np = uUOrTzxoL3lhmftZnwRpHPaj
	hc5ePKxl4LJvEjDgTm,QhUZisYJOeAnr9LRCp35,a2E4KwJsuBAtP39zRc7g8L1Gjq,fWaIoG2QB4xXAi9reFz3VtlCd = gVZqoUpmC3NkPnAi(ZTG4ruxXUsc9N)
	OMq4tcorHv1Cu8Dk9GPmK7VwJe = yUTYoAgth5iC43uLrdBH.getSetting(lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧᄂ"))
	udFWOplyCqMVZILn1sk7 = yUTYoAgth5iC43uLrdBH.getSetting(IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᄃ"))
	QXvyZSfmepFR7GHNh = yUTYoAgth5iC43uLrdBH.getSetting(DKmLTA2yGtj(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᄄ"))
	WIb8Eto0hunpf3yxKcX9FG6gO = [E3i1eCBtN2w(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠭ᄅ"),wFYiVd4r12x7CAQBL5SPof(u"ࠫࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩࠨᄆ"),ykE045Tatx(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠪᄇ"),ee3tnwl7avk(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠭ᄈ"),UixkloZbzGw28ujW56X(u"ࠧࡴࡥࡵࡥࡵ࡫ࡵࡱࠩᄉ"),YXm2qAbu8Qsx(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲࠫᄊ")]
	oogTaG1V6ed0lzY8kK5yfuZLcD9hM = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if any(B251BPiLbvG9UxszKtlI7YQHmoWw in ZTG4ruxXUsc9N for B251BPiLbvG9UxszKtlI7YQHmoWw in WIb8Eto0hunpf3yxKcX9FG6gO) else vvglE69OFKBm817Nkc
	if dn9ouNryjHiBFQOhASvX(u"ࠩࠩࡹࡷࡲ࠽ࠨᄋ") in hc5ePKxl4LJvEjDgTm and oogTaG1V6ed0lzY8kK5yfuZLcD9hM: qFiNYZLjIk8E5Kt2 = hc5ePKxl4LJvEjDgTm.rsplit(vGg1hAkzqi8exVbN(u"ࠪࠪࡺࡸ࡬࠾ࠩᄌ"),ZYTyoA483N(u"࠴ᒅ"))[Mn5NGAdz6xc42s0]
	else: qFiNYZLjIk8E5Kt2 = Zg9FeADE84jSRIvPCrzYulw3sL
	OBbUelr82CI6od0Pmkpw = PhpFa6EdVS[JP65RzKaScIf(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᄍ")]
	t4rMpkTG7u2ly3aHsEzv = hc5ePKxl4LJvEjDgTm in OBbUelr82CI6od0Pmkpw or qFiNYZLjIk8E5Kt2 in OBbUelr82CI6od0Pmkpw
	llPdFXbYGI9 = PhpFa6EdVS[dn9ouNryjHiBFQOhASvX(u"ࠬࡘࡅࡑࡑࡖࠫᄎ")]
	EEVoLOdvR3X6HJ1BCnNc82UFfar = hc5ePKxl4LJvEjDgTm in llPdFXbYGI9 or qFiNYZLjIk8E5Kt2 in llPdFXbYGI9
	ayjMXbzZ9K42Yr = t4rMpkTG7u2ly3aHsEzv or EEVoLOdvR3X6HJ1BCnNc82UFfar
	jxJdwRpkTDXWaScH = vvglE69OFKBm817Nkc
	bN5tO3Sv9f = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	cEnqAoDF6V0R = QhUZisYJOeAnr9LRCp35==None and a2E4KwJsuBAtP39zRc7g8L1Gjq==None and not oogTaG1V6ed0lzY8kK5yfuZLcD9hM
	if cEnqAoDF6V0R and ayjMXbzZ9K42Yr:
		if t4rMpkTG7u2ly3aHsEzv:
			LCQFyRNGmDtx1sIK80la5dXigP = OBbUelr82CI6od0Pmkpw.index(hc5ePKxl4LJvEjDgTm)
			ZjBhReFoXzlb = PhpFa6EdVS[yyZPkLCRX1xcBDN(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪᄏ")][LCQFyRNGmDtx1sIK80la5dXigP]
			zMsqA2SVtdHLJDx8gpFGw = Wbng8KmUpcXyOYNSGA[LCQFyRNGmDtx1sIK80la5dXigP]
			if zMsqA2SVtdHLJDx8gpFGw==qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩᄐ"): LloZMyTKCedwsV9HY8aWxqbc6BNUi,rzWNxv2Tjq0FlEUf9D7np,bN5tO3Sv9f = vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc
			elif zMsqA2SVtdHLJDx8gpFGw==wFYiVd4r12x7CAQBL5SPof(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᄑ"): jxJdwRpkTDXWaScH = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		elif EEVoLOdvR3X6HJ1BCnNc82UFfar:
			LCQFyRNGmDtx1sIK80la5dXigP = llPdFXbYGI9.index(hc5ePKxl4LJvEjDgTm)
			ZjBhReFoXzlb = PhpFa6EdVS[IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬᄒ")][LCQFyRNGmDtx1sIK80la5dXigP]
			zMsqA2SVtdHLJDx8gpFGw = a6lEryZVzDACc1JixeFqnT35[LCQFyRNGmDtx1sIK80la5dXigP]
	if a2E4KwJsuBAtP39zRc7g8L1Gjq==Zg9FeADE84jSRIvPCrzYulw3sL: a2E4KwJsuBAtP39zRc7g8L1Gjq = OMq4tcorHv1Cu8Dk9GPmK7VwJe
	elif a2E4KwJsuBAtP39zRc7g8L1Gjq==None and udFWOplyCqMVZILn1sk7 in [ykE045Tatx(u"ࠪࡅ࡚࡚ࡏࠨᄓ"),IYC4iPxkTRUE85namF6(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᄔ")] and LloZMyTKCedwsV9HY8aWxqbc6BNUi: a2E4KwJsuBAtP39zRc7g8L1Gjq = OMq4tcorHv1Cu8Dk9GPmK7VwJe
	if t4rMpkTG7u2ly3aHsEzv or EEVoLOdvR3X6HJ1BCnNc82UFfar: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = Vi1oNCM5kI7yJ0(u"࠵࠺ᒆ")
	elif oogTaG1V6ed0lzY8kK5yfuZLcD9hM: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = vv3sNE8XCU2RAiyVaueTbD950pz(u"࠻࠶ᒇ")
	elif iojW2gVFfT in JqgcndNGI5W493ZRh: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = wFYiVd4r12x7CAQBL5SPof(u"࠷࠰ᒈ")
	elif iojW2gVFfT==UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧᄕ"): HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠲࠱ᒉ")
	elif iojW2gVFfT==wFYiVd4r12x7CAQBL5SPof(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧᄖ"): HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = Vi1oNCM5kI7yJ0(u"࠳࠲ᒊ")
	elif NIBsHMvSXb(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎࠩᄗ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = ttC4VURALPYKh(u"࠹࠳ᒋ")
	elif dn9ouNryjHiBFQOhASvX(u"ࠨࡕࡋࡓࡋࡎࡁࠨᄘ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = yNBjYsgc23xoW(u"࠺࠹ᒌ")
	elif IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩᄙ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = eCpDE6wJtYUHn0GqK5(u"࠶࠺ᒍ")
	elif ykE045Tatx(u"ࠪࡅࡍ࡝ࡁࡌࠩᄚ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = NIBsHMvSXb(u"࠷࠶ᒎ")
	elif ZYTyoA483N(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᄛ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = UixkloZbzGw28ujW56X(u"࠸࠰ᒏ")
	elif E3i1eCBtN2w(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫᄜ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = x9PULjztJOpu7b(u"࠳࠱ᒐ")
	elif yNBjYsgc23xoW(u"࠭ࡁࡌࡑࡄࡑࠬᄝ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = ReLGYUQjz7C9iEd(u"࠳࠷ᒑ")
	elif E3i1eCBtN2w(u"ࠧࡂࡍ࡚ࡅࡒ࠭ᄞ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵࠳ᒒ")
	elif ee3tnwl7avk(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪᄟ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = ee3tnwl7avk(u"࠵࠴ᒓ")
	elif JP65RzKaScIf(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫᄠ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠺࠵ᒔ")
	elif NIBsHMvSXb(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬᄡ") in iojW2gVFfT: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = yyZPkLCRX1xcBDN(u"࠹࠶ᒕ")
	else: HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = ykE045Tatx(u"࠷࠵ᒖ")
	FekG0WMOadLYCZ9H5IE8r = (QhUZisYJOeAnr9LRCp35!=None)
	sshvGb3SgBlajFHP = (a2E4KwJsuBAtP39zRc7g8L1Gjq!=None and udFWOplyCqMVZILn1sk7!=ReLGYUQjz7C9iEd(u"ࠫࡘ࡚ࡏࡑࠩᄢ"))
	if FekG0WMOadLYCZ9H5IE8r and not oogTaG1V6ed0lzY8kK5yfuZLcD9hM: ZXWeI01flR(ZYTyoA483N(u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨᄣ"),QhUZisYJOeAnr9LRCp35)
	elif sshvGb3SgBlajFHP: ZXWeI01flR(E3i1eCBtN2w(u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭ᄤ"),a2E4KwJsuBAtP39zRc7g8L1Gjq)
	if FekG0WMOadLYCZ9H5IE8r:
		J0xnQCbuRl3tkLSw = {E3i1eCBtN2w(u"ࠢࡩࡶࡷࡴࠧᄥ"):QhUZisYJOeAnr9LRCp35,lU1fSmncFWjizwqZugyYBANML0(u"ࠣࡪࡷࡸࡵࡹࠢᄦ"):QhUZisYJOeAnr9LRCp35}
		Q2ftPnFK0UgaiZbRym9GCeWA = QhUZisYJOeAnr9LRCp35
	else: J0xnQCbuRl3tkLSw,Q2ftPnFK0UgaiZbRym9GCeWA = {},Zg9FeADE84jSRIvPCrzYulw3sL
	if sshvGb3SgBlajFHP:
		import urllib3.util.connection as HjtULpPZbT61odXq3iysh
		Pwu7gckiqnhBKWJT4Me1GFQS9HbZ = VIEvKBFz5SpRcCJN(HjtULpPZbT61odXq3iysh,OMq4tcorHv1Cu8Dk9GPmK7VwJe)
	i3SdQH58oFmP97pXLw61gfCYhJK,YlxJjQSZsg,QrwXYlzDfcW5vG2NTZdPAxhI,qw3SJPzGhO8exm7tYopM6VIrv,XipNjzJAT7GaVBeCWxd8KfDt,verify = U4cbiW1z6T72NVr,iojW2gVFfT,TgrlAZFKOMEcHt5d,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,fWaIoG2QB4xXAi9reFz3VtlCd
	if jxJdwRpkTDXWaScH: XipNjzJAT7GaVBeCWxd8KfDt = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if ayjMXbzZ9K42Yr or U4cbiW1z6T72NVr: i3SdQH58oFmP97pXLw61gfCYhJK = vvglE69OFKBm817Nkc
	if t4rMpkTG7u2ly3aHsEzv: QrwXYlzDfcW5vG2NTZdPAxhI = ttC4VURALPYKh(u"ࠩࡓࡓࡘ࡚ࠧᄧ")
	POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H = -Mn5NGAdz6xc42s0,ReLGYUQjz7C9iEd(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪᄨ")
	JhViKIvxTYcNH1Qbl2FWZS36Uy = vvglE69OFKBm817Nkc
	global llZXU07bFzpoI9nrK
	if not llZXU07bFzpoI9nrK: llZXU07bFzpoI9nrK = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,ttC4VURALPYKh(u"ࠫࡩ࡯ࡣࡵࠩᄩ"),ykE045Tatx(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᄪ"),ykE045Tatx(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᄫ"))
	H1p7Wj5h9OQnbtPZI24zo8sCU = []
	while hc5ePKxl4LJvEjDgTm not in H1p7Wj5h9OQnbtPZI24zo8sCU and hc5ePKxl4LJvEjDgTm in list(llZXU07bFzpoI9nrK.keys()):
		H1p7Wj5h9OQnbtPZI24zo8sCU.append(hc5ePKxl4LJvEjDgTm)
		hc5ePKxl4LJvEjDgTm = llZXU07bFzpoI9nrK[hc5ePKxl4LJvEjDgTm]
	import requests as CzrjWh4Xgi3cqPZ2K
	for OEJ3PT81KtbZ in range(dn9ouNryjHiBFQOhASvX(u"࠹ᒗ")):
		xc9irGf4YUKWI8kAZ5NgbCqHTtnvzP = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
		try:
			if OEJ3PT81KtbZ: YlxJjQSZsg = qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠶ࡹࡴࠨᄬ")
			if oogTaG1V6ed0lzY8kK5yfuZLcD9hM or not FekG0WMOadLYCZ9H5IE8r: BTKlfsON6tEUDkyLVvRQHezhcC4(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕ࡟ࡸࡔࡖࡅࡏࡡࡘࡖࡑ࠭ᄭ"),hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,YlxJjQSZsg,QrwXYlzDfcW5vG2NTZdPAxhI)
			try: Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.close()
			except: pass
			JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm
			Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = CzrjWh4Xgi3cqPZ2K.request(QrwXYlzDfcW5vG2NTZdPAxhI,hc5ePKxl4LJvEjDgTm,data=mrn4jdBuXKIw7N2lvh,headers=Y3OmVPp2ARgBCjn,verify=verify,allow_redirects=i3SdQH58oFmP97pXLw61gfCYhJK,timeout=HTPdhx6IsYmGjeZ5nbtkUy47ACvruK,proxies=J0xnQCbuRl3tkLSw)
			if eCpDE6wJtYUHn0GqK5(u"࠴࠲࠳ᒘ")<=Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.status_code<=OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠵࠼࠽ᒙ"):
				if not qw3SJPzGhO8exm7tYopM6VIrv:
					fId25GMECU91aVFrl4WHxLAncut = list(Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.headers.keys())
					if ykE045Tatx(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᄮ") in fId25GMECU91aVFrl4WHxLAncut: hc5ePKxl4LJvEjDgTm = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.headers[OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᄯ")]
					elif yyZPkLCRX1xcBDN(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᄰ") in fId25GMECU91aVFrl4WHxLAncut: hc5ePKxl4LJvEjDgTm = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.headers[ttC4VURALPYKh(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧᄱ")]
					else: qw3SJPzGhO8exm7tYopM6VIrv = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					if not qw3SJPzGhO8exm7tYopM6VIrv: hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.encode(x9PULjztJOpu7b(u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧᄲ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᄳ")).decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,ZYTyoA483N(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᄴ"))
					if ayjMXbzZ9K42Yr and Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.status_code==YXm2qAbu8Qsx(u"࠶࠴࠼ᒚ"):
						i3SdQH58oFmP97pXLw61gfCYhJK = U4cbiW1z6T72NVr
						QrwXYlzDfcW5vG2NTZdPAxhI = TgrlAZFKOMEcHt5d
						qw3SJPzGhO8exm7tYopM6VIrv = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
						zpBTYUA3Ievrtb6FK4OxCJ
				if not qw3SJPzGhO8exm7tYopM6VIrv or U4cbiW1z6T72NVr:
					if okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩ࡫ࡸࡹࡶࠧᄵ") not in hc5ePKxl4LJvEjDgTm:
						hMOegX4Pb8EjJCUw96TiHZIp1k3t = G9GCDqXJFAc(JaqiYfEglZDvmwQNS8zR,A2MHFvoqpZ64gNbB(u"ࠪࡹࡷࡲࠧᄶ"))
						hc5ePKxl4LJvEjDgTm = hMOegX4Pb8EjJCUw96TiHZIp1k3t+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫ࠴࠭ᄷ")+hc5ePKxl4LJvEjDgTm.lstrip(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬ࠵ࠧᄸ"))
				if hc5ePKxl4LJvEjDgTm!=JaqiYfEglZDvmwQNS8zR:
					llZXU07bFzpoI9nrK[JaqiYfEglZDvmwQNS8zR] = hc5ePKxl4LJvEjDgTm
					JhViKIvxTYcNH1Qbl2FWZS36Uy = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				if not qw3SJPzGhO8exm7tYopM6VIrv and U4cbiW1z6T72NVr and not wzX1klOfLVhb2B4ita(hc5ePKxl4LJvEjDgTm): zpBTYUA3Ievrtb6FK4OxCJ
			elif A2MHFvoqpZ64gNbB(u"࠺࠻࠰ᒜ")<=Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.status_code<=ee3tnwl7avk(u"࠹࠾࠿ᒛ"):
				Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.reason = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
				XipNjzJAT7GaVBeCWxd8KfDt = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			JaqiYfEglZDvmwQNS8zR = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.url
			POocngw2KWudQXsL4rpRvf1eAz0qVl = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.status_code
			BBkxwFGyasvQphqZ4H = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.reason
			Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.raise_for_status()
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		except CzrjWh4Xgi3cqPZ2K.exceptions.HTTPError as JJyYREVW7k:
			pass
		except CzrjWh4Xgi3cqPZ2K.exceptions.Timeout as JJyYREVW7k:
			if HByjTem6EJP5sZb: BBkxwFGyasvQphqZ4H = str(JJyYREVW7k.message).split(vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭࠺ࠡࠩᄹ"))[Mn5NGAdz6xc42s0]
			else: BBkxwFGyasvQphqZ4H = str(JJyYREVW7k).split(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࠻ࠢࠪᄺ"))[Mn5NGAdz6xc42s0]
		except CzrjWh4Xgi3cqPZ2K.exceptions.ConnectionError as JJyYREVW7k:
			try: TOJwE16IZS7Af = JJyYREVW7k.message[UwCT5Oz6Wo0BP]
			except: TOJwE16IZS7Af = str(JJyYREVW7k)
			IId3BAQsL6p9cej = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vhZ5qjay1z94JmcMOgXe(u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᄻ"),TOJwE16IZS7Af)
			if not IId3BAQsL6p9cej: IId3BAQsL6p9cej = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧᄼ"),TOJwE16IZS7Af)
			if not IId3BAQsL6p9cej:
				wwUBIaiCsVJdmyOMHKbEY1LRXD = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮ࡀࠢᄽ"),TOJwE16IZS7Af)
				if wwUBIaiCsVJdmyOMHKbEY1LRXD: IId3BAQsL6p9cej = [wwUBIaiCsVJdmyOMHKbEY1LRXD[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0],wwUBIaiCsVJdmyOMHKbEY1LRXD[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]]
			if not IId3BAQsL6p9cej: IId3BAQsL6p9cej = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠦ࠿࠮࡜ࡥ࠭ࠬ࠾ࠥ࠮࠮ࠫࡁࠬࠫࠧᄾ"),TOJwE16IZS7Af)
			if not IId3BAQsL6p9cej: IId3BAQsL6p9cej = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(ZYTyoA483N(u"ࠧࠦࠨ࡝ࡦ࠮࠭ࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᄿ"),TOJwE16IZS7Af)
			try: POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H = IId3BAQsL6p9cej[UwCT5Oz6Wo0BP]
			except: POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H = -vv3sNE8XCU2RAiyVaueTbD950pz(u"࠸ᒝ"),TOJwE16IZS7Af
		except CzrjWh4Xgi3cqPZ2K.exceptions.RequestException as JJyYREVW7k:
			if HByjTem6EJP5sZb: BBkxwFGyasvQphqZ4H = JJyYREVW7k.message
			else: BBkxwFGyasvQphqZ4H = str(JJyYREVW7k)
		except:
			xc9irGf4YUKWI8kAZ5NgbCqHTtnvzP = vvglE69OFKBm817Nkc
			try: POocngw2KWudQXsL4rpRvf1eAz0qVl = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.status_code
			except: pass
			try: BBkxwFGyasvQphqZ4H = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.reason
			except: pass
		BBkxwFGyasvQphqZ4H = str(BBkxwFGyasvQphqZ4H)
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,YXm2qAbu8Qsx(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᅀ")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+YXm2qAbu8Qsx(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᅁ")+BBkxwFGyasvQphqZ4H+UixkloZbzGw28ujW56X(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᅂ")+iojW2gVFfT+UQS9lVew50DIyXrinWsMxTzA(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᅃ")+ZTG4ruxXUsc9N+yNBjYsgc23xoW(u"ࠪࠤࡢ࠭ᅄ"))
		if cEnqAoDF6V0R and ayjMXbzZ9K42Yr and xc9irGf4YUKWI8kAZ5NgbCqHTtnvzP and not XipNjzJAT7GaVBeCWxd8KfDt and POocngw2KWudQXsL4rpRvf1eAz0qVl!=lU1fSmncFWjizwqZugyYBANML0(u"࠲࠱࠲ᒞ"):
			hc5ePKxl4LJvEjDgTm = ZjBhReFoXzlb
			XipNjzJAT7GaVBeCWxd8KfDt = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			continue
		if xc9irGf4YUKWI8kAZ5NgbCqHTtnvzP: break
	if not oQE7jJVFnvtzbYAhSOc14qRXdKy9pD and H1p7Wj5h9OQnbtPZI24zo8sCU:
		for url in H1p7Wj5h9OQnbtPZI24zo8sCU: del llZXU07bFzpoI9nrK[url]
		JhViKIvxTYcNH1Qbl2FWZS36Uy = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if JhViKIvxTYcNH1Qbl2FWZS36Uy:
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᅅ"),ReLGYUQjz7C9iEd(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧᅆ"),llZXU07bFzpoI9nrK,ggWsYrlq8fy2v)
		llZXU07bFzpoI9nrK = {}
	if a2E4KwJsuBAtP39zRc7g8L1Gjq!=None and udFWOplyCqMVZILn1sk7!=IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡓࡕࡑࡓࠫᅇ"): HjtULpPZbT61odXq3iysh.create_connection = Pwu7gckiqnhBKWJT4Me1GFQS9HbZ
	if udFWOplyCqMVZILn1sk7==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧᅈ") and LloZMyTKCedwsV9HY8aWxqbc6BNUi: a2E4KwJsuBAtP39zRc7g8L1Gjq = None
	if not oQE7jJVFnvtzbYAhSOc14qRXdKy9pD and QhUZisYJOeAnr9LRCp35==None and iojW2gVFfT not in JqgcndNGI5W493ZRh:
		o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
		if o4be19ApMtCrdf5!=A2MHFvoqpZ64gNbB(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫᅉ"): cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
	zCDbxZtwOE6 = dA2JDHpu6O0kGt7M1fY4aVQbBKn()
	if oogTaG1V6ed0lzY8kK5yfuZLcD9hM: JaqiYfEglZDvmwQNS8zR = qFiNYZLjIk8E5Kt2
	if not JaqiYfEglZDvmwQNS8zR: JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm
	zCDbxZtwOE6.url = JaqiYfEglZDvmwQNS8zR
	zCDbxZtwOE6.scrape = oogTaG1V6ed0lzY8kK5yfuZLcD9hM
	try: DHgYSBM2Tcfkp4sw5mhI = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
	except: DHgYSBM2Tcfkp4sw5mhI = Zg9FeADE84jSRIvPCrzYulw3sL
	try: Ne4k6g70sUroCTiSVQ = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.headers
	except: Ne4k6g70sUroCTiSVQ = {}
	try: Kay49M7PphBmewEW3gz = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.cookies.get_dict()
	except: Kay49M7PphBmewEW3gz = {}
	try: Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.close()
	except: pass
	if GGfPQnrJKEqMv2ZVxdD:
		try: DHgYSBM2Tcfkp4sw5mhI = DHgYSBM2Tcfkp4sw5mhI.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		except: pass
	POocngw2KWudQXsL4rpRvf1eAz0qVl = int(POocngw2KWudQXsL4rpRvf1eAz0qVl)
	zCDbxZtwOE6.code = POocngw2KWudQXsL4rpRvf1eAz0qVl
	zCDbxZtwOE6.reason = BBkxwFGyasvQphqZ4H
	zCDbxZtwOE6.content = DHgYSBM2Tcfkp4sw5mhI
	zCDbxZtwOE6.headers = Ne4k6g70sUroCTiSVQ
	zCDbxZtwOE6.cookies = Kay49M7PphBmewEW3gz
	zCDbxZtwOE6.succeeded = oQE7jJVFnvtzbYAhSOc14qRXdKy9pD
	zCDbxZtwOE6.scrapernumber = Zg9FeADE84jSRIvPCrzYulw3sL
	zCDbxZtwOE6.scraperserver = Zg9FeADE84jSRIvPCrzYulw3sL
	zCDbxZtwOE6.scraperurl = Zg9FeADE84jSRIvPCrzYulw3sL
	if HByjTem6EJP5sZb or isinstance(zCDbxZtwOE6.content,str): FrjHbx26kquOW4Coc5iQ3 = zCDbxZtwOE6.content.lower()
	else: FrjHbx26kquOW4Coc5iQ3 = Zg9FeADE84jSRIvPCrzYulw3sL
	qL8lfNzH5aXv1FmI907nGYtsKUp3 = (eCpDE6wJtYUHn0GqK5(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᅊ") in FrjHbx26kquOW4Coc5iQ3 or vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᅋ") in FrjHbx26kquOW4Coc5iQ3) and FrjHbx26kquOW4Coc5iQ3.count(JP65RzKaScIf(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧᅌ"))>wFYiVd4r12x7CAQBL5SPof(u"࠳ᒟ") and OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᅍ") not in iojW2gVFfT and vhZ5qjay1z94JmcMOgXe(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨᅎ") not in FrjHbx26kquOW4Coc5iQ3 and not oogTaG1V6ed0lzY8kK5yfuZLcD9hM
	if POocngw2KWudQXsL4rpRvf1eAz0qVl==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠴࠳࠴ᒠ") and qL8lfNzH5aXv1FmI907nGYtsKUp3: zCDbxZtwOE6.succeeded = vvglE69OFKBm817Nkc
	if zCDbxZtwOE6.succeeded and cEnqAoDF6V0R and ayjMXbzZ9K42Yr:
		yjOBkgfH84 = IYC4iPxkTRUE85namF6(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨᅏ")+mrn4jdBuXKIw7N2lvh[qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡬ࡲࡦࠬᅐ")].upper().replace(eCpDE6wJtYUHn0GqK5(u"ࠩࡊࡉ࡙࠭ᅑ"),Zg9FeADE84jSRIvPCrzYulw3sL) if jxJdwRpkTDXWaScH else zMsqA2SVtdHLJDx8gpFGw
		FajoeBMP8wQp3RyVUXbvrDtT6nc0z(yjOBkgfH84)
	if not zCDbxZtwOE6.succeeded and cEnqAoDF6V0R:
		LmlWYocwRBTh7KZUjkV1dnO = (qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᅒ") in FrjHbx26kquOW4Coc5iQ3 and jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡷࡧࡹࠡ࡫ࡧ࠾ࠥ࠭ᅓ") in FrjHbx26kquOW4Coc5iQ3)
		dNxwpzAnu0CMEUJQ63o2WRqgtI = (IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࠻ࠠࡴࡧࡦࠫᅔ") in FrjHbx26kquOW4Coc5iQ3 and ttC4VURALPYKh(u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧᅕ") in FrjHbx26kquOW4Coc5iQ3)
		pWwLz3cIN48M0hHYKlt7j1fkVm6 = (POocngw2KWudQXsL4rpRvf1eAz0qVl in [KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠷࠴࠸ᒡ")] and OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠾ࠥ࠷࠰࠳࠲ࠪᅖ") in FrjHbx26kquOW4Coc5iQ3)
		LDN8aIMi12XwVQ4j = (DKmLTA2yGtj(u"ࠨࡡࡦࡪࡤࡩࡨ࡭ࡡࠪᅗ") in FrjHbx26kquOW4Coc5iQ3 and IYC4iPxkTRUE85namF6(u"ࠩࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࠭ᅘ") in FrjHbx26kquOW4Coc5iQ3)
		if   qL8lfNzH5aXv1FmI907nGYtsKUp3: BBkxwFGyasvQphqZ4H = UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪᅙ")
		elif LmlWYocwRBTh7KZUjkV1dnO: BBkxwFGyasvQphqZ4H = dn9ouNryjHiBFQOhASvX(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᅚ")
		elif dNxwpzAnu0CMEUJQ63o2WRqgtI: BBkxwFGyasvQphqZ4H = IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬᅛ")
		elif pWwLz3cIN48M0hHYKlt7j1fkVm6: BBkxwFGyasvQphqZ4H = x9PULjztJOpu7b(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡢࡥࡦࡩࡸࡹࠠࡥࡧࡱ࡭ࡪࡪࠧᅜ")
		elif LDN8aIMi12XwVQ4j: BBkxwFGyasvQphqZ4H = lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩᅝ")
		else: BBkxwFGyasvQphqZ4H = str(BBkxwFGyasvQphqZ4H)
		if iojW2gVFfT in bGgOREuAIUNyd5: pass
		elif iojW2gVFfT in JqgcndNGI5W493ZRh:
			zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+NIBsHMvSXb(u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᅞ")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᅟ")+BBkxwFGyasvQphqZ4H+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᅠ")+iojW2gVFfT+lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᅡ")+hc5ePKxl4LJvEjDgTm+ee3tnwl7avk(u"ࠬࠦ࡝ࠨᅢ"))
		else: zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᅣ")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+ZYTyoA483N(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᅤ")+BBkxwFGyasvQphqZ4H+ttC4VURALPYKh(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᅥ")+iojW2gVFfT+IYC4iPxkTRUE85namF6(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᅦ")+hc5ePKxl4LJvEjDgTm+UixkloZbzGw28ujW56X(u"ࠪࠤࡢ࠭ᅧ"))
		SSQnwLPKtoe3aHAchxuBOMYg61v4 = qFiNYZLjIk8E5Kt2 if oogTaG1V6ed0lzY8kK5yfuZLcD9hM else UAjMPLdITqWChbrcB(hc5ePKxl4LJvEjDgTm)
		if HByjTem6EJP5sZb and isinstance(SSQnwLPKtoe3aHAchxuBOMYg61v4,unicode): SSQnwLPKtoe3aHAchxuBOMYg61v4 = SSQnwLPKtoe3aHAchxuBOMYg61v4.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		if ayjMXbzZ9K42Yr: SSQnwLPKtoe3aHAchxuBOMYg61v4 = SSQnwLPKtoe3aHAchxuBOMYg61v4.split(lU1fSmncFWjizwqZugyYBANML0(u"ࠫ࠴࠭ᅨ"))[-Mn5NGAdz6xc42s0]
		wjSk72HtchGgUOspnEQTRXZqWK = str(BBkxwFGyasvQphqZ4H)+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡢ࡮ࠩࠢࠪᅩ")+SSQnwLPKtoe3aHAchxuBOMYg61v4+Vi1oNCM5kI7yJ0(u"࠭ࠠࠪࠩᅪ")
		if POocngw2KWudQXsL4rpRvf1eAz0qVl in [-Mn5NGAdz6xc42s0,-DpahB8cwl4ZeKVsg71RuibSAfx0Ejr] or qL8lfNzH5aXv1FmI907nGYtsKUp3 or LmlWYocwRBTh7KZUjkV1dnO or dNxwpzAnu0CMEUJQ63o2WRqgtI or pWwLz3cIN48M0hHYKlt7j1fkVm6 or LDN8aIMi12XwVQ4j:
			zCDbxZtwOE6.code = -O4dklMvZ8ULcS
			zCDbxZtwOE6.reason = BBkxwFGyasvQphqZ4H
			if rzWNxv2Tjq0FlEUf9D7np:
				WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = P3wCWFA5Nt(TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H)
				if WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.succeeded: return WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3
		jzydmKVUWrCv9D34F = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if (udFWOplyCqMVZILn1sk7==lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡂࡕࡎࠫᅫ") or QXvyZSfmepFR7GHNh==JP65RzKaScIf(u"ࠨࡃࡖࡏࠬᅬ")) and (LloZMyTKCedwsV9HY8aWxqbc6BNUi or rzWNxv2Tjq0FlEUf9D7np):
			jzydmKVUWrCv9D34F = hw2V6XZSmcrDK(POocngw2KWudQXsL4rpRvf1eAz0qVl,wjSk72HtchGgUOspnEQTRXZqWK,iojW2gVFfT,UsyxcJB6RN2)
			if jzydmKVUWrCv9D34F and udFWOplyCqMVZILn1sk7==dn9ouNryjHiBFQOhASvX(u"ࠩࡄࡗࡐ࠭ᅭ"): udFWOplyCqMVZILn1sk7 = vhZ5qjay1z94JmcMOgXe(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᅮ")
			else: udFWOplyCqMVZILn1sk7 = IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ᅯ")
			if jzydmKVUWrCv9D34F and QXvyZSfmepFR7GHNh==vGg1hAkzqi8exVbN(u"ࠬࡇࡓࡌࠩᅰ"): QXvyZSfmepFR7GHNh = UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᅱ")
			else: QXvyZSfmepFR7GHNh = vGg1hAkzqi8exVbN(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᅲ")
			yUTYoAgth5iC43uLrdBH.setSetting(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᅳ"),udFWOplyCqMVZILn1sk7)
			yUTYoAgth5iC43uLrdBH.setSetting(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᅴ"),QXvyZSfmepFR7GHNh)
		if jzydmKVUWrCv9D34F:
			if POocngw2KWudQXsL4rpRvf1eAz0qVl==qdEKO42r3GhwmCDcHtxzJUR(u"࠼ᒢ") and yyZPkLCRX1xcBDN(u"ࠪ࡬ࡹࡺࡰࡴࠩᅵ") in hc5ePKxl4LJvEjDgTm and bN5tO3Sv9f:
				if UsyxcJB6RN2: ZXWeI01flR(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫᅶ"),Vi1oNCM5kI7yJ0(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᅷ"),LNma2eq3vEguwVtHjn=lU1fSmncFWjizwqZugyYBANML0(u"࠷࠶࠰࠱ᒣ"))
				JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+E3i1eCBtN2w(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᅸ")
				PPnXgJjB8cedw9YG5a2txu = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,JaqiYfEglZDvmwQNS8zR,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,UsyxcJB6RN2,yyZPkLCRX1xcBDN(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠷ࡴࡤࠨᅹ"))
				if PPnXgJjB8cedw9YG5a2txu.succeeded:
					zCDbxZtwOE6 = PPnXgJjB8cedw9YG5a2txu
					zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+yyZPkLCRX1xcBDN(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᅺ")+iojW2gVFfT+E3i1eCBtN2w(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᅻ")+ZTG4ruxXUsc9N+dn9ouNryjHiBFQOhASvX(u"ࠪࠤࡢ࠭ᅼ"))
					if UsyxcJB6RN2: ZXWeI01flR(ReLGYUQjz7C9iEd(u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨᅽ"),lU1fSmncFWjizwqZugyYBANML0(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᅾ"),LNma2eq3vEguwVtHjn=UQS9lVew50DIyXrinWsMxTzA(u"࠸࠰࠱࠲ᒤ"))
				else:
					zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+Vi1oNCM5kI7yJ0(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᅿ")+iojW2gVFfT+E3i1eCBtN2w(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᆀ")+ZTG4ruxXUsc9N+DKmLTA2yGtj(u"ࠨࠢࡠࠫᆁ"))
					if UsyxcJB6RN2: ZXWeI01flR(E3i1eCBtN2w(u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬᆂ"),x9PULjztJOpu7b(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆃ"),LNma2eq3vEguwVtHjn=E3i1eCBtN2w(u"࠲࠱࠲࠳ᒥ"))
			if not zCDbxZtwOE6.succeeded and QXvyZSfmepFR7GHNh in [lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡆ࡛ࡔࡐࠩᆄ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᆅ")] and rzWNxv2Tjq0FlEUf9D7np:
				if UsyxcJB6RN2: ZXWeI01flR(A2MHFvoqpZ64gNbB(u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᆆ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆇ"),LNma2eq3vEguwVtHjn=ttC4VURALPYKh(u"࠳࠲࠳࠴ᒦ"))
				PPnXgJjB8cedw9YG5a2txu = znBO5KfMm0a9cZvdpbIu6UwP(TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,UsyxcJB6RN2,iojW2gVFfT)
				if PPnXgJjB8cedw9YG5a2txu.succeeded:
					zCDbxZtwOE6 = PPnXgJjB8cedw9YG5a2txu
					zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᆈ")+iojW2gVFfT+vhZ5qjay1z94JmcMOgXe(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᆉ")+ZTG4ruxXUsc9N+JP65RzKaScIf(u"ࠪࠤࡢ࠭ᆊ"))
					if UsyxcJB6RN2: ZXWeI01flR(qdEKO42r3GhwmCDcHtxzJUR(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪᆋ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᆌ"),LNma2eq3vEguwVtHjn=yNBjYsgc23xoW(u"࠴࠳࠴࠵ᒧ"))
				else:
					zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᆍ")+iojW2gVFfT+ykE045Tatx(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᆎ")+ZTG4ruxXUsc9N+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠢࡠࠫᆏ"))
					if UsyxcJB6RN2: ZXWeI01flR(vhZ5qjay1z94JmcMOgXe(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᆐ"),E3i1eCBtN2w(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆑ"),LNma2eq3vEguwVtHjn=vv3sNE8XCU2RAiyVaueTbD950pz(u"࠵࠴࠵࠶ᒨ"))
			if not zCDbxZtwOE6.succeeded and udFWOplyCqMVZILn1sk7 in [okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡆ࡛ࡔࡐࠩᆒ"),ttC4VURALPYKh(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᆓ")] and LloZMyTKCedwsV9HY8aWxqbc6BNUi:
				if UsyxcJB6RN2: ZXWeI01flR(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨᆔ"),NIBsHMvSXb(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆕ"),LNma2eq3vEguwVtHjn=IYC4iPxkTRUE85namF6(u"࠶࠵࠶࠰ᒩ"))
				JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm+E3i1eCBtN2w(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᆖ")
				PPnXgJjB8cedw9YG5a2txu = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,JaqiYfEglZDvmwQNS8zR,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,UsyxcJB6RN2,vhZ5qjay1z94JmcMOgXe(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠴ࡵࡪࠪᆗ"))
				if PPnXgJjB8cedw9YG5a2txu.succeeded:
					zCDbxZtwOE6 = PPnXgJjB8cedw9YG5a2txu
					zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+NIBsHMvSXb(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪᆘ")+OMq4tcorHv1Cu8Dk9GPmK7VwJe+ykE045Tatx(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆙ")+iojW2gVFfT+eCpDE6wJtYUHn0GqK5(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆚ")+ZTG4ruxXUsc9N+JP65RzKaScIf(u"࠭ࠠ࡞ࠩᆛ"))
					if UsyxcJB6RN2: ZXWeI01flR(JP65RzKaScIf(u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨᆜ"),NIBsHMvSXb(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆝ"),LNma2eq3vEguwVtHjn=vGg1hAkzqi8exVbN(u"࠷࠶࠰࠱ᒪ"))
				else:
					zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+dn9ouNryjHiBFQOhASvX(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ᆞ")+OMq4tcorHv1Cu8Dk9GPmK7VwJe+yNBjYsgc23xoW(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆟ")+iojW2gVFfT+Vi1oNCM5kI7yJ0(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᆠ")+ZTG4ruxXUsc9N+wFYiVd4r12x7CAQBL5SPof(u"ࠬࠦ࡝ࠨᆡ"))
					if UsyxcJB6RN2: ZXWeI01flR(ZYTyoA483N(u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᆢ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆣ"),LNma2eq3vEguwVtHjn=JP65RzKaScIf(u"࠸࠰࠱࠲ᒫ"))
		if QXvyZSfmepFR7GHNh==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᆤ") or udFWOplyCqMVZILn1sk7==dn9ouNryjHiBFQOhASvX(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᆥ"): UsyxcJB6RN2 = vvglE69OFKBm817Nkc
		if not zCDbxZtwOE6.succeeded:
			if UsyxcJB6RN2: FjUBMw9OGSx = hw2V6XZSmcrDK(POocngw2KWudQXsL4rpRvf1eAz0qVl,wjSk72HtchGgUOspnEQTRXZqWK,iojW2gVFfT,UsyxcJB6RN2)
			if POocngw2KWudQXsL4rpRvf1eAz0qVl!=NIBsHMvSXb(u"࠲࠱࠲ᒬ") and iojW2gVFfT not in NvZXA76fYQWekDjhVFr0O2UiIdHxL and IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧᆦ") not in iojW2gVFfT: Sma2pEt5wTK()
	if yUTYoAgth5iC43uLrdBH.getSetting(YXm2qAbu8Qsx(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᆧ")) not in [ee3tnwl7avk(u"ࠬࡇࡕࡕࡑࠪᆨ"),x9PULjztJOpu7b(u"࠭ࡓࡕࡑࡓࠫᆩ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡂࡕࡎࠫᆪ")]: yUTYoAgth5iC43uLrdBH.setSetting(E3i1eCBtN2w(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᆫ"),vhZ5qjay1z94JmcMOgXe(u"ࠩࡄࡗࡐ࠭ᆬ"))
	if yUTYoAgth5iC43uLrdBH.getSetting(vhZ5qjay1z94JmcMOgXe(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᆭ")) not in [IYC4iPxkTRUE85namF6(u"ࠫࡆ࡛ࡔࡐࠩᆮ"),lU1fSmncFWjizwqZugyYBANML0(u"࡙ࠬࡔࡐࡒࠪᆯ"),A2MHFvoqpZ64gNbB(u"࠭ࡁࡔࡍࠪᆰ")]: yUTYoAgth5iC43uLrdBH.setSetting(x9PULjztJOpu7b(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᆱ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠨࡃࡖࡏࠬᆲ"))
	return zCDbxZtwOE6
def Fx7AY84Qu0bO1ymo(website,k90GreIRFVwiTSb5qh6ELA1toQ,Pd1eWRqOxlKcHNCFG=None):
	zHKvLlO8t4irkesq6U1pYbS5NVIM = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠲࠲ᒭ")
	W54DzJViO9bYlNMfE0FCskK7 = [IYC4iPxkTRUE85namF6(u"࠳ᒮ"),IYC4iPxkTRUE85namF6(u"࠳ᒮ"),IYC4iPxkTRUE85namF6(u"࠳ᒮ"),ykE045Tatx(u"࠴࠴ᒯ"),ReLGYUQjz7C9iEd(u"࠹ᒰ"),ykE045Tatx(u"࠴࠴ᒯ"),IYC4iPxkTRUE85namF6(u"࠳ᒮ"),IYC4iPxkTRUE85namF6(u"࠳ᒮ"),IYC4iPxkTRUE85namF6(u"࠳ᒮ"),ReLGYUQjz7C9iEd(u"࠹ᒰ")]
	y95VAOEztx0WQChlcDI7U = o3YKZFPvy9ag
	s67fuogDYEwM = []
	nnjhXIac8EqZp5e2Vbdv = [JP65RzKaScIf(u"࠵ᒱ")]*zHKvLlO8t4irkesq6U1pYbS5NVIM
	ENrCVPoMO2Jg8Bl41iD = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡧ࡭ࡨࡺࠧᆳ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬᆴ"))
	for W9kuYMXsjDQUIdflHLJFn8 in list(ENrCVPoMO2Jg8Bl41iD.keys()):
		if website not in W9kuYMXsjDQUIdflHLJFn8: continue
		FLqQoZwdAngNkz49RMGUHJXW3bDC,KxautrkVE4n = W9kuYMXsjDQUIdflHLJFn8.split(Vi1oNCM5kI7yJ0(u"ࠫࡤࡥࠧᆵ"))
		nnjhXIac8EqZp5e2Vbdv[int(KxautrkVE4n)] = ENrCVPoMO2Jg8Bl41iD[W9kuYMXsjDQUIdflHLJFn8]
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(zHKvLlO8t4irkesq6U1pYbS5NVIM):
		if ZZxHfvyXBmYVjQ9rdAT8RaSKG in y95VAOEztx0WQChlcDI7U+k90GreIRFVwiTSb5qh6ELA1toQ: continue
		if ZZxHfvyXBmYVjQ9rdAT8RaSKG==Pd1eWRqOxlKcHNCFG: nnjhXIac8EqZp5e2Vbdv[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = nnjhXIac8EqZp5e2Vbdv[ZZxHfvyXBmYVjQ9rdAT8RaSKG]+qdEKO42r3GhwmCDcHtxzJUR(u"࠷ᒲ")
		if nnjhXIac8EqZp5e2Vbdv[ZZxHfvyXBmYVjQ9rdAT8RaSKG]<Vi1oNCM5kI7yJ0(u"࠳ᒳ"): s67fuogDYEwM += [ZZxHfvyXBmYVjQ9rdAT8RaSKG]*W54DzJViO9bYlNMfE0FCskK7[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
	if not s67fuogDYEwM:
		for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(zHKvLlO8t4irkesq6U1pYbS5NVIM):
			nnjhXIac8EqZp5e2Vbdv[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = yNBjYsgc23xoW(u"࠱ᒴ")
			if ZZxHfvyXBmYVjQ9rdAT8RaSKG in y95VAOEztx0WQChlcDI7U+k90GreIRFVwiTSb5qh6ELA1toQ: continue
			s67fuogDYEwM += [ZZxHfvyXBmYVjQ9rdAT8RaSKG]*W54DzJViO9bYlNMfE0FCskK7[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in y95VAOEztx0WQChlcDI7U: nnjhXIac8EqZp5e2Vbdv[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠻࠼࠽࠾ᒵ")
	EoLaYzHWOk0vebg1Z4stNwh = []
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(zHKvLlO8t4irkesq6U1pYbS5NVIM): EoLaYzHWOk0vebg1Z4stNwh.append(website+IYC4iPxkTRUE85namF6(u"ࠬࡥ࡟ࠨᆶ")+str(ZZxHfvyXBmYVjQ9rdAT8RaSKG))
	cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨᆷ"),EoLaYzHWOk0vebg1Z4stNwh,nnjhXIac8EqZp5e2Vbdv,ufANkpln7j9r*yNBjYsgc23xoW(u"࠸ᒶ"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return s67fuogDYEwM
def P3wCWFA5Nt(TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H,k90GreIRFVwiTSb5qh6ELA1toQ=[]):
	ZXWeI01flR(Vi1oNCM5kI7yJ0(u"ࠧษัฦฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᆸ"),Zg9FeADE84jSRIvPCrzYulw3sL,LNma2eq3vEguwVtHjn=IK4zTnSMyGQpxEaesJAPVDY(u"࠻࠺࠶ᒷ"))
	zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+x9PULjztJOpu7b(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᆹ")+str(POocngw2KWudQXsL4rpRvf1eAz0qVl)+yNBjYsgc23xoW(u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᆺ")+BBkxwFGyasvQphqZ4H+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆻ")+iojW2gVFfT+vGg1hAkzqi8exVbN(u"ࠫࠥࡣࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆼ")+hc5ePKxl4LJvEjDgTm+wFYiVd4r12x7CAQBL5SPof(u"ࠬࠦ࡝ࠨᆽ"))
	website = iojW2gVFfT.split(A2MHFvoqpZ64gNbB(u"࠭࠭ࠨᆾ"))[UwCT5Oz6Wo0BP]
	WIb8Eto0hunpf3yxKcX9FG6gO = Fx7AY84Qu0bO1ymo(website,k90GreIRFVwiTSb5qh6ELA1toQ)
	xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = []
	if website==wFYiVd4r12x7CAQBL5SPof(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᆿ"):
		if UwCT5Oz6Wo0BP in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [UwCT5Oz6Wo0BP]
		if Mn5NGAdz6xc42s0 in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [Mn5NGAdz6xc42s0]
		if DpahB8cwl4ZeKVsg71RuibSAfx0Ejr in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		if O4dklMvZ8ULcS in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [O4dklMvZ8ULcS]*zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠶࠶ᒸ")
		if NEc173Pr0jAwLF5OS in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [NEc173Pr0jAwLF5OS]*NIBsHMvSXb(u"࠻ᒹ")
		if yNBjYsgc23xoW(u"࠶ᒻ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [yNBjYsgc23xoW(u"࠶ᒻ")]*vhZ5qjay1z94JmcMOgXe(u"࠱࠱ᒺ")
		if DKmLTA2yGtj(u"࠸ᒼ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [DKmLTA2yGtj(u"࠸ᒼ")]
		if x9PULjztJOpu7b(u"࠺ᒽ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [x9PULjztJOpu7b(u"࠺ᒽ")]
	elif website==KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᇀ"):
		if O4dklMvZ8ULcS in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [O4dklMvZ8ULcS]*JP65RzKaScIf(u"࠵࠵ᒾ")
	elif website==yyZPkLCRX1xcBDN(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫᇁ"):
		if Mn5NGAdz6xc42s0 in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [Mn5NGAdz6xc42s0]
		if NEc173Pr0jAwLF5OS in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [NEc173Pr0jAwLF5OS]*E3i1eCBtN2w(u"࠺ᒿ")
		if tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠵ᓁ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠵ᓁ")]*E3i1eCBtN2w(u"࠷࠰ᓀ")
		if vv3sNE8XCU2RAiyVaueTbD950pz(u"࠷ᓂ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [vv3sNE8XCU2RAiyVaueTbD950pz(u"࠷ᓂ")]
		if dn9ouNryjHiBFQOhASvX(u"࠹ᓃ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [dn9ouNryjHiBFQOhASvX(u"࠹ᓃ")]
	elif website==wFYiVd4r12x7CAQBL5SPof(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᇂ"):
		if NEc173Pr0jAwLF5OS in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [NEc173Pr0jAwLF5OS]*okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠸ᓄ")
		if E3i1eCBtN2w(u"࠺ᓆ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [E3i1eCBtN2w(u"࠺ᓆ")]*JP65RzKaScIf(u"࠵࠵ᓅ")
	elif website==DKmLTA2yGtj(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬᇃ"):
		if x9PULjztJOpu7b(u"࠿ᓇ") in WIb8Eto0hunpf3yxKcX9FG6gO: xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL += [x9PULjztJOpu7b(u"࠿ᓇ")]*jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵ᓈ")
	if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: WIb8Eto0hunpf3yxKcX9FG6gO = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL
	if WIb8Eto0hunpf3yxKcX9FG6gO:
		xQ0p7IGBC6w5z4WUPVHTkYlr = pJ5tI2GD1jSPgdzO7qBuFk60Rni93.sample(WIb8Eto0hunpf3yxKcX9FG6gO,Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
	else: xQ0p7IGBC6w5z4WUPVHTkYlr = -Mn5NGAdz6xc42s0
	update = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if xQ0p7IGBC6w5z4WUPVHTkYlr==UwCT5Oz6Wo0BP:
		scraperserver = ReLGYUQjz7C9iEd(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠲ࠩᇄ")
		Kk38V6vgW1xteF5XJHEworl = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠵࠺࠶ࡤ࠳࠴ࡩ࠵࠲ࡩ࠵࠹ࡣ࠰࠸࠵࠸࠱࠮ࡣࡤ࠼࠹࠳ࡥ࠺࠴࠶ࡧࡦ࡬࠸࠶࠺࠶࠸ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᇅ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+NIBsHMvSXb(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇆ")+Kk38V6vgW1xteF5XJHEworl+qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇇ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==Mn5NGAdz6xc42s0:
		scraperserver = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠷࠭ᇈ")
		Kk38V6vgW1xteF5XJHEworl = IK4zTnSMyGQpxEaesJAPVDY(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠱ࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲ࠺࠴࠻࠼࠵ࡪ࠿ࡣ࠶࠯࠺ࡩࡪ࠹࠭࠵ࡧࡨ࠶࠲࠾࠴ࡤ࠲࠰ࡪࡩ࠽࠹࠳ࡤࡤࡨࡩ࠹ࡤ࠶ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠺࠶࠵࠸࠷ࠬᇉ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+ReLGYUQjz7C9iEd(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇊ")+Kk38V6vgW1xteF5XJHEworl+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇋ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
		scraperserver = vGg1hAkzqi8exVbN(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪᇌ")
		Kk38V6vgW1xteF5XJHEworl = ttC4VURALPYKh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭ᇍ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+yNBjYsgc23xoW(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇎ")+Kk38V6vgW1xteF5XJHEworl+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇏ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==O4dklMvZ8ULcS:
		scraperserver = DKmLTA2yGtj(u"ࠪࡷࡨࡸࡡࡱࡧࡸࡴࠬᇐ")
		JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm.replace(ykE045Tatx(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ᇑ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᇒ"))
		N2dklZ3LF7DEe = A2MHFvoqpZ64gNbB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡨࡸࡡࡱࡧࡸࡴ࠳ࡩ࡯࡮࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁ࠶࡜ࡎࡴࡏࡷࡐ࠶ࡵࡂࡓ࡚࡮ࡗࡓࡉࡢࡄࡏࡍ࠵ࡐ࡞࡙ࡋ࡬࡭࠴ࡩࡰ࡚ࡸࠨ࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡈࡤࡰࡸ࡫ࠦࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᇓ")+OJYiDeyvSPTNI9(JaqiYfEglZDvmwQNS8zR)
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡈࡇࡗࠫᇔ"),N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==NEc173Pr0jAwLF5OS:
		scraperserver = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴࠨᇕ")
		N2dklZ3LF7DEe = ee3tnwl7avk(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠴ࡣࡰ࡯࠲ࡃࡹࡵ࡫ࡦࡰࡀࡥ࠹࡬࠷ࡧࡤ࠴࠸࠲࠸ࡤࡦࡨ࠰࠸࠵࠽࠱࠮࠺࠹࠸ࡧ࠳࠲࠳ࡧ࠶࠶࠻࠺ࡤ࠵ࡦࡧࡧࠫࡶࡲࡰࡺࡼࡇࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡶࡴ࡯ࡁࠬᇖ")+OJYiDeyvSPTNI9(hc5ePKxl4LJvEjDgTm)
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(NIBsHMvSXb(u"ࠪࡋࡊ࡚ࠧᇗ"),N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
		try:
			WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.content = JGmfjhoyKZUl(x9PULjztJOpu7b(u"ࠫࡩ࡯ࡣࡵࠩᇘ"),WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.content)
			WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.content = WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.content[vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᇙ")]
		except: pass
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠶ᓉ"):
		scraperserver = dn9ouNryjHiBFQOhASvX(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠵ࠬᇚ")
		Kk38V6vgW1xteF5XJHEworl = UixkloZbzGw28ujW56X(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡤࡵࡳࡼࡹࡥࡳ࠿ࡉࡥࡱࡹࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬᇛ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+ykE045Tatx(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇜ")+Kk38V6vgW1xteF5XJHEworl+IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇝ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==dn9ouNryjHiBFQOhASvX(u"࠸ᓊ"):
		scraperserver = qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠷ࠧᇞ")
		Kk38V6vgW1xteF5XJHEworl = yNBjYsgc23xoW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᇟ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+DKmLTA2yGtj(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇠ")+Kk38V6vgW1xteF5XJHEworl+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇡ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==E3i1eCBtN2w(u"࠺ᓋ"):
		scraperserver = qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠵ࠫᇢ")
		Kk38V6vgW1xteF5XJHEworl = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳ࡦ࠷ࡩ࠹ࡡࡦ࠳࠻࠹ࡩ࡬࠴ࡣࡨ࠹ࡥ࡫࠻࠳࠴ࡥ࠺࠴࠹࠶ࡢ࠴࠶࠺ࡧ࠾࡫࠹࠺ࡤࡨ࠸࠻࠼ࡡࡦ࠻࠽ࡧࡺࡹࡴࡰ࡯ࡋࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥࠧࡩࡨࡳࡈࡵࡤࡦ࠿࡬ࡰࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠺࠹࠲࠻࠴ࠬᇣ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+E3i1eCBtN2w(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇤ")+Kk38V6vgW1xteF5XJHEworl+JP65RzKaScIf(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇥ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==dn9ouNryjHiBFQOhASvX(u"࠼ᓌ"):
		scraperserver = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠳ࠨᇦ")
		N2dklZ3LF7DEe = ReLGYUQjz7C9iEd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠳ࡻ࠷࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠶࠽࠾࠷ࡥ࠺ࡥ࠸࠱࠼࡫ࡥ࠴࠯࠷ࡩࡪ࠸࠭࠹࠶ࡦ࠴࠲࡬ࡤ࠸࠻࠵ࡦࡦࡪࡤ࠴ࡦ࠸ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬ࠧࡷࡵࡰࡂ࠭ᇧ")+OJYiDeyvSPTNI9(hc5ePKxl4LJvEjDgTm)
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(DKmLTA2yGtj(u"࠭ࡇࡆࡖࠪᇨ"),N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	elif xQ0p7IGBC6w5z4WUPVHTkYlr==NIBsHMvSXb(u"࠾ᓍ"):
		scraperserver = JP65RzKaScIf(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠷࠭ᇩ")
		Kk38V6vgW1xteF5XJHEworl = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡁࡆࠨࡵࡩࡹࡻࡲ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡱࡸࡶࡨ࡫࠽ࡵࡴࡸࡩࠫ࡬࡯ࡳࡹࡤࡶࡩࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡵࡴࡸࡩ࠿࠸ࡢ࠴࠶࠳ࡥ࠻࠾࠹࠱ࡣ࠸࠸࠵࠷ࡤࡣࡥ࠶࠻࠷ࡩ࠱࠲࠶࠸ࡨ࠾࠼࠲ࡦ࠺ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠮ࡤࡱࡰ࠾࠽࠶࠸࠱ࠩᇪ")
		N2dklZ3LF7DEe = hc5ePKxl4LJvEjDgTm+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇫ")+Kk38V6vgW1xteF5XJHEworl+vhZ5qjay1z94JmcMOgXe(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇬ")
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,N2dklZ3LF7DEe,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	else:
		scraperserver,N2dklZ3LF7DEe = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
		WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = dA2JDHpu6O0kGt7M1fY4aVQbBKn()
		update = vvglE69OFKBm817Nkc
	if update and not WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.succeeded:
		Fx7AY84Qu0bO1ymo(website,[],xQ0p7IGBC6w5z4WUPVHTkYlr)
		if len(list(set(WIb8Eto0hunpf3yxKcX9FG6gO)))>Mn5NGAdz6xc42s0:
			jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇭ"),vhZ5qjay1z94JmcMOgXe(u"๊ࠬไฤีไࠤุ๐ัโำ้ࠣ฾อไอหࠣห้ำฬษࠢิๆ๊ࠦࠧᇮ")+str(xQ0p7IGBC6w5z4WUPVHTkYlr)+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࠠโึ็ࠤๆ๐ฺࠠ็็๎ฮࠦสอษ๋ึࠥอไฮฮหࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ะหํ๊ษࠡฬฯหํุࠠศๆะะอࠦๅาหࠣวำื้ࠡสสืฯิฯศ็ࠣื๏ืแา่ࠢาฯ๊แࠡมࠤࠫᇯ"))
			if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0:
				k90GreIRFVwiTSb5qh6ELA1toQ.append(xQ0p7IGBC6w5z4WUPVHTkYlr)
				WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3 = P3wCWFA5Nt(TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,U4cbiW1z6T72NVr,UsyxcJB6RN2,iojW2gVFfT,POocngw2KWudQXsL4rpRvf1eAz0qVl,BBkxwFGyasvQphqZ4H,k90GreIRFVwiTSb5qh6ELA1toQ)
				return WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3
	WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.scrapernumber = str(xQ0p7IGBC6w5z4WUPVHTkYlr)
	WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.scraperserver = scraperserver
	WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.scraperurl = N2dklZ3LF7DEe
	rF7LYIGDTxMzApsQt = JP65RzKaScIf(u"ࠧิ์ิๅึࠦัใ็ࠣࠫᇰ")+WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.scrapernumber
	if WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.succeeded:
		zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+eCpDE6wJtYUHn0GqK5(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨᇱ")+scraperserver+yNBjYsgc23xoW(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇲ")+iojW2gVFfT+ReLGYUQjz7C9iEd(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇳ")+hc5ePKxl4LJvEjDgTm+ttC4VURALPYKh(u"ࠫࠥࡣࠧᇴ"))
		ZXWeI01flR(DKmLTA2yGtj(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇵ"),rF7LYIGDTxMzApsQt,LNma2eq3vEguwVtHjn=vhZ5qjay1z94JmcMOgXe(u"࠽࠵࠱ᓎ"))
	else:
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+Vi1oNCM5kI7yJ0(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᇶ")+scraperserver+NIBsHMvSXb(u"ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᇷ")+str(WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.code)+wFYiVd4r12x7CAQBL5SPof(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᇸ")+WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3.reason+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇹ")+iojW2gVFfT+eCpDE6wJtYUHn0GqK5(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇺ")+hc5ePKxl4LJvEjDgTm+qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࠥࡣࠧᇻ"))
		ZXWeI01flR(YXm2qAbu8Qsx(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇼ"),rF7LYIGDTxMzApsQt,LNma2eq3vEguwVtHjn=IK4zTnSMyGQpxEaesJAPVDY(u"࠷࠶࠲ᓏ"))
	return WWpYQCMd0NaXtoBrcyOGHvu8ZA9mK3
def SmfLTBMNHF4QI1CtJpD9gn(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh=Zg9FeADE84jSRIvPCrzYulw3sL,Bd4TxwQJ87HXUl3G6f=Zg9FeADE84jSRIvPCrzYulw3sL):
	hc5ePKxl4LJvEjDgTm,QhUZisYJOeAnr9LRCp35,a2E4KwJsuBAtP39zRc7g8L1Gjq,fWaIoG2QB4xXAi9reFz3VtlCd = gVZqoUpmC3NkPnAi(ZTG4ruxXUsc9N)
	try: EdKOeSrAB4IxZa7X = Ay2hPpbZC7XmtQlwnfBT8.copy()
	except: EdKOeSrAB4IxZa7X = Ay2hPpbZC7XmtQlwnfBT8
	dczJa6f5mpR = TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,WR7gIlwo5ik9zJv3CK4sS,EdKOeSrAB4IxZa7X,Aixa65089K1
	if csmodNjArLZfC1v8PuKxU2Tg36JpI<tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱ᓐ"):
		nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,E3i1eCBtN2w(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩᇽ"),dczJa6f5mpR)
		csmodNjArLZfC1v8PuKxU2Tg36JpI = -csmodNjArLZfC1v8PuKxU2Tg36JpI
	if csmodNjArLZfC1v8PuKxU2Tg36JpI>vv3sNE8XCU2RAiyVaueTbD950pz(u"࠲ᓑ"):
		Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,YXm2qAbu8Qsx(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩᇾ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫᇿ"),dczJa6f5mpR)
		if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
			BTKlfsON6tEUDkyLVvRQHezhcC4(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩሀ"),hc5ePKxl4LJvEjDgTm,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT,TgrlAZFKOMEcHt5d)
			return Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = f9z23hDRKaHvgGoSCpX5u4i(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,Aixa65089K1,showDialogs,iojW2gVFfT,eejR6xrJkTldh,Bd4TxwQJ87HXUl3G6f)
	if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.succeeded:
		if zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫሁ") in iojW2gVFfT: Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content = NkJiXgtIB5ECy(Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content)
		if Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.scrape: csmodNjArLZfC1v8PuKxU2Tg36JpI = ggWsYrlq8fy2v
		if csmodNjArLZfC1v8PuKxU2Tg36JpI and Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧሂ"),dczJa6f5mpR,Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO,csmodNjArLZfC1v8PuKxU2Tg36JpI)
	return Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO
def chPtxDrfKE42FWZMd8VlowpAb1mIUN(csmodNjArLZfC1v8PuKxU2Tg36JpI,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,showDialogs,iojW2gVFfT):
	if not WR7gIlwo5ik9zJv3CK4sS or isinstance(WR7gIlwo5ik9zJv3CK4sS,dict): TgrlAZFKOMEcHt5d = UixkloZbzGw28ujW56X(u"ࠬࡍࡅࡕࠩሃ")
	else:
		TgrlAZFKOMEcHt5d = yyZPkLCRX1xcBDN(u"࠭ࡐࡐࡕࡗࠫሄ")
		WR7gIlwo5ik9zJv3CK4sS = UAjMPLdITqWChbrcB(WR7gIlwo5ik9zJv3CK4sS)
		rC3S0IsLOHwAXE68cNd7zGb,WR7gIlwo5ik9zJv3CK4sS = I28IrfmVwu4JkOXhGB(WR7gIlwo5ik9zJv3CK4sS)
	Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO = SmfLTBMNHF4QI1CtJpD9gn(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,showDialogs,iojW2gVFfT)
	qHn7Qbi61UB = Sx3rmh8lUDRoMbk4Xa2nG9VKj5WTsO.content
	qHn7Qbi61UB = str(qHn7Qbi61UB)
	return qHn7Qbi61UB
def gVZqoUpmC3NkPnAi(ZTG4ruxXUsc9N):
	ZZpfXGoN0mnksbeJ = ZTG4ruxXUsc9N.split(ZYTyoA483N(u"ࠧࡽࡾࠪህ"))
	hc5ePKxl4LJvEjDgTm,QhUZisYJOeAnr9LRCp35,a2E4KwJsuBAtP39zRc7g8L1Gjq,fWaIoG2QB4xXAi9reFz3VtlCd = ZZpfXGoN0mnksbeJ[UwCT5Oz6Wo0BP],None,None,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	for dczJa6f5mpR in ZZpfXGoN0mnksbeJ:
		if UixkloZbzGw28ujW56X(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ሆ") in dczJa6f5mpR: QhUZisYJOeAnr9LRCp35 = dczJa6f5mpR[qdEKO42r3GhwmCDcHtxzJUR(u"࠴࠵ᓒ"):]
		elif JP65RzKaScIf(u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬሇ") in dczJa6f5mpR: a2E4KwJsuBAtP39zRc7g8L1Gjq = dczJa6f5mpR[JP65RzKaScIf(u"࠽ᓓ"):]
		elif zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨለ") in dczJa6f5mpR: fWaIoG2QB4xXAi9reFz3VtlCd = vvglE69OFKBm817Nkc
	return hc5ePKxl4LJvEjDgTm,QhUZisYJOeAnr9LRCp35,a2E4KwJsuBAtP39zRc7g8L1Gjq,fWaIoG2QB4xXAi9reFz3VtlCd
def EFwy0JBRC5g1Ujq2ko6x(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,tirpPcl53GQ81ND,vZ1dq9xF4jwSbtUQz5ehTia,j7zCDeoV5Qqy6TuAi,Ay2hPpbZC7XmtQlwnfBT8=Zg9FeADE84jSRIvPCrzYulw3sL):
	UUqkQBJDYh8Kaf = G9GCDqXJFAc(ZTG4ruxXUsc9N,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡺࡸ࡬ࠨሉ"))
	DEYMzbJiWO6ehqZupNP9dS7AjLmHf = yUTYoAgth5iC43uLrdBH.getSetting(A2MHFvoqpZ64gNbB(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧሊ")+tirpPcl53GQ81ND)
	if UUqkQBJDYh8Kaf==DEYMzbJiWO6ehqZupNP9dS7AjLmHf: yUTYoAgth5iC43uLrdBH.setSetting(ttC4VURALPYKh(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨላ")+tirpPcl53GQ81ND,Zg9FeADE84jSRIvPCrzYulw3sL)
	if DEYMzbJiWO6ehqZupNP9dS7AjLmHf: JaqiYfEglZDvmwQNS8zR = ZTG4ruxXUsc9N.replace(UUqkQBJDYh8Kaf,DEYMzbJiWO6ehqZupNP9dS7AjLmHf)
	else:
		JaqiYfEglZDvmwQNS8zR = ZTG4ruxXUsc9N
		DEYMzbJiWO6ehqZupNP9dS7AjLmHf = UUqkQBJDYh8Kaf
	PPnXgJjB8cedw9YG5a2txu = SmfLTBMNHF4QI1CtJpD9gn(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,Ay2hPpbZC7XmtQlwnfBT8,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫሌ"))
	qHn7Qbi61UB = PPnXgJjB8cedw9YG5a2txu.content
	if GGfPQnrJKEqMv2ZVxdD:
		try: qHn7Qbi61UB = qHn7Qbi61UB.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,ReLGYUQjz7C9iEd(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨል"))
		except: pass
	if not PPnXgJjB8cedw9YG5a2txu.succeeded or j7zCDeoV5Qqy6TuAi not in qHn7Qbi61UB:
		vZ1dq9xF4jwSbtUQz5ehTia = vZ1dq9xF4jwSbtUQz5ehTia.replace(wjs26GpVfNiCUERHJ,dn9ouNryjHiBFQOhASvX(u"ࠩ࠮ࠫሎ"))
		hc5ePKxl4LJvEjDgTm = wFYiVd4r12x7CAQBL5SPof(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨሏ")+vZ1dq9xF4jwSbtUQz5ehTia
		Y3OmVPp2ARgBCjn = {UixkloZbzGw28ujW56X(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨሐ"):Zg9FeADE84jSRIvPCrzYulw3sL}
		zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩሑ"))
		if zCDbxZtwOE6.succeeded:
			qHn7Qbi61UB = zCDbxZtwOE6.content
			if GGfPQnrJKEqMv2ZVxdD:
				try: qHn7Qbi61UB = qHn7Qbi61UB.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ሒ"))
				except: pass
			CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(vhZ5qjay1z94JmcMOgXe(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡠࡼ࠰࡜ࡀ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨሓ"),qHn7Qbi61UB,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			aLsAU3PemivlhNTYHbJ6 = [DEYMzbJiWO6ehqZupNP9dS7AjLmHf]
			EElH2yGcnXk = [KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡣࡳ࡯ࠬሔ"),wFYiVd4r12x7CAQBL5SPof(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩሕ"),dn9ouNryjHiBFQOhASvX(u"ࠪࡸࡼ࡯ࡴࡵࡧࡵࠫሖ"),IYC4iPxkTRUE85namF6(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬሗ"),UixkloZbzGw28ujW56X(u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧመ"),yyZPkLCRX1xcBDN(u"࠭ࡰࡩࡲࠪሙ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡢࡶ࡯ࡥࡶ࠭ሚ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡵ࡬ࡸࡪ࡯࡮ࡥ࡫ࡦࡩࡸ࠭ማ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡶࡹࡷ࠴࡬ࡺࠩሜ"),YXm2qAbu8Qsx(u"ࠪࡦࡱࡵࡧࡴࡲࡲࡸࠬም"),UQS9lVew50DIyXrinWsMxTzA(u"ࠫ࡮ࡴࡦࡰࡴࡰࡩࡷ࠭ሞ"),ttC4VURALPYKh(u"ࠬࡹࡩࡵࡧ࡯࡭ࡰ࡫ࠧሟ"),ttC4VURALPYKh(u"࠭ࡩ࡯ࡵࡷࡥ࡬ࡸࡡ࡮ࠩሠ"),eCpDE6wJtYUHn0GqK5(u"ࠧࡴࡰࡤࡴࡨ࡮ࡡࡵࠩሡ"),UixkloZbzGw28ujW56X(u"ࠨࡪࡷࡸࡵ࠳ࡥࡲࡷ࡬ࡺࠬሢ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡩࡥࡸ࡫࡬ࡱ࡮ࡸࡷࠬሣ")]
			for Rdzu9GfpV34XKq in CPv45ibdnBc:
				if any(B251BPiLbvG9UxszKtlI7YQHmoWw in Rdzu9GfpV34XKq for B251BPiLbvG9UxszKtlI7YQHmoWw in EElH2yGcnXk): continue
				DEYMzbJiWO6ehqZupNP9dS7AjLmHf = G9GCDqXJFAc(Rdzu9GfpV34XKq,NIBsHMvSXb(u"ࠪࡹࡷࡲࠧሤ"))
				if DEYMzbJiWO6ehqZupNP9dS7AjLmHf in aLsAU3PemivlhNTYHbJ6: continue
				if len(aLsAU3PemivlhNTYHbJ6)==IK4zTnSMyGQpxEaesJAPVDY(u"࠾ᓔ"):
					zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+vGg1hAkzqi8exVbN(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫሥ")+tirpPcl53GQ81ND+qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪሦ")+UUqkQBJDYh8Kaf+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࠠ࡞ࠩሧ"))
					yUTYoAgth5iC43uLrdBH.setSetting(UixkloZbzGw28ujW56X(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩረ")+tirpPcl53GQ81ND,Zg9FeADE84jSRIvPCrzYulw3sL)
					break
				aLsAU3PemivlhNTYHbJ6.append(DEYMzbJiWO6ehqZupNP9dS7AjLmHf)
				JaqiYfEglZDvmwQNS8zR = ZTG4ruxXUsc9N.replace(UUqkQBJDYh8Kaf,DEYMzbJiWO6ehqZupNP9dS7AjLmHf)
				PPnXgJjB8cedw9YG5a2txu = SmfLTBMNHF4QI1CtJpD9gn(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,Ay2hPpbZC7XmtQlwnfBT8,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬሩ"))
				qHn7Qbi61UB = PPnXgJjB8cedw9YG5a2txu.content
				if PPnXgJjB8cedw9YG5a2txu.succeeded and j7zCDeoV5Qqy6TuAi in qHn7Qbi61UB:
					zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+ZYTyoA483N(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩሪ")+tirpPcl53GQ81ND+lU1fSmncFWjizwqZugyYBANML0(u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩራ")+DEYMzbJiWO6ehqZupNP9dS7AjLmHf+yyZPkLCRX1xcBDN(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩሬ")+UUqkQBJDYh8Kaf+vGg1hAkzqi8exVbN(u"ࠬࠦ࡝ࠨር"))
					yUTYoAgth5iC43uLrdBH.setSetting(DKmLTA2yGtj(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨሮ")+tirpPcl53GQ81ND,DEYMzbJiWO6ehqZupNP9dS7AjLmHf)
					break
	return DEYMzbJiWO6ehqZupNP9dS7AjLmHf,JaqiYfEglZDvmwQNS8zR,PPnXgJjB8cedw9YG5a2txu
def ulj9JfWhc0EgZbsm(xQXoDIqn4Ucsthb2G7YpzwPTymi):
	smAPnDkcZjIhtSipQH = {
	 ee3tnwl7avk(u"ࠧࡢࡪࡺࡥࡰ࠭ሯ")				:lU1fSmncFWjizwqZugyYBANML0(u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪሰ")
	,DKmLTA2yGtj(u"ࠩࡤ࡯ࡴࡧ࡭ࠨሱ")				:KpNYeI2Pd4nHJG3cOTvWjbSa(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧሲ")
	,YXm2qAbu8Qsx(u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭ሳ")				:A2MHFvoqpZ64gNbB(u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭ሴ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡡ࡬ࡹࡤࡱࠬስ")				:eCpDE6wJtYUHn0GqK5(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫሶ")
	,ZYTyoA483N(u"ࠨࡣ࡮ࡻࡦࡳࡴࡶࡤࡨࠫሷ")			:vv3sNE8XCU2RAiyVaueTbD950pz(u"่ࠩ์็฿ࠠศๅ๋ห๊ࠦส๋๊หࠫሸ")
	,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡥࡱࡧࡲࡢࡤࠪሹ")				:Vi1oNCM5kI7yJ0(u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫሺ")
	,ttC4VURALPYKh(u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧሻ")				:UixkloZbzGw28ujW56X(u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬሼ")
	,UixkloZbzGw28ujW56X(u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪሽ")			:tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫሾ")
	,ee3tnwl7avk(u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫሿ")				:yyZPkLCRX1xcBDN(u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧቀ")
	,vGg1hAkzqi8exVbN(u"ࠫࡦࡲ࡭ࡴࡶࡥࡥࠬቁ")				:E3i1eCBtN2w(u"๋่ࠬใ฻ࠣห้๋ีุสฬࠫቂ")
	,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡡ࡯࡫ࡰࡩࡿ࡯ࡤࠨቃ")				:DKmLTA2yGtj(u"ࠧๆ๊ๅ฽ࠥอๆๆ์ࠣึิ࠭ቄ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭ቅ")			:vGg1hAkzqi8exVbN(u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫቆ")
	,vGg1hAkzqi8exVbN(u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬቇ")				:OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"๊ࠫ๎โฺࠢ฼ีอࠦำ๋์าࠫቈ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ቉")				:UixkloZbzGw28ujW56X(u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧቊ")
	,yNBjYsgc23xoW(u"ࠧࡢࡻ࡯ࡳࡱ࠭ቋ")				:E3i1eCBtN2w(u"ࠨ็๋ๆ฾ࠦร๋ๆ๋่ࠬቌ")
	,UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡥࡳࡰࡸࡡࠨቍ")				:ee3tnwl7avk(u"้ࠪํู่ࠡสๆีฬ࠭቎")
	,yyZPkLCRX1xcBDN(u"ࠫࡧࡸࡳࡵࡧ࡭ࠫ቏")				:A2MHFvoqpZ64gNbB(u"๋่ࠬใ฻ࠣฬึูส๋ฮࠪቐ")
	,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡣࡪ࡯ࡤ࠸࠵࠶ࠧቑ")				:JP65RzKaScIf(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧቒ")
	,JP65RzKaScIf(u"ࠨࡥ࡬ࡱࡦ࠺ࡰࠨቓ")				:UQS9lVew50DIyXrinWsMxTzA(u"่ࠩ์็฿ࠠิ์่หࠥ็่าࠢห๎ࠬቔ")
	,lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪቕ")				:okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭ቖ")
	,ttC4VURALPYKh(u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ቗")				:yyZPkLCRX1xcBDN(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧቘ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡣࠩ቙")				:Vi1oNCM5kI7yJ0(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩቚ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࡻࡴࡸ࡫ࠨቛ")			:wFYiVd4r12x7CAQBL5SPof(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨቜ")
	,yyZPkLCRX1xcBDN(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡵ࠭ቝ")				:OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭቞")
	,UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨ቟")				:ykE045Tatx(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨበ")
	,UixkloZbzGw28ujW56X(u"ࠨࡥ࡬ࡱࡦ࡬ࡲࡦࡧࠪቡ")				:UQS9lVew50DIyXrinWsMxTzA(u"่ࠩ์็฿ࠠิ์่หࠥ็ั๋ࠩቢ")
	,vhZ5qjay1z94JmcMOgXe(u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭ባ")			:E3i1eCBtN2w(u"๊ࠫ๎โฺࠢึ๎๊อࠠๅษํฮࠬቤ")
	,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ብ")				:A2MHFvoqpZ64gNbB(u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭ቦ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡤ࡫ࡰࡥࡼࡨࡡࡴࠩቧ")				:UQS9lVew50DIyXrinWsMxTzA(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤํฮำࠨቨ")
	,ykE045Tatx(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧቩ")			:E3i1eCBtN2w(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠬቪ")
	,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫቫ")	:E3i1eCBtN2w(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆีอาิ๋๊็ࠩቬ")
	,ee3tnwl7avk(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱࡭ࡧࡳࡩࡶࡤ࡫ࡸ࠭ቭ")	:wFYiVd4r12x7CAQBL5SPof(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็๊ࠢหูะวไࠩቮ")
	,x9PULjztJOpu7b(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳࡬ࡪࡸࡨࡷࠬቯ")	:vhZ5qjay1z94JmcMOgXe(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊ฮวีำࠪተ")
	,vhZ5qjay1z94JmcMOgXe(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫቱ"):IK4zTnSMyGQpxEaesJAPVDY(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬቲ")
	,ttC4VURALPYKh(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡸࡴࡶࡩࡤࡵࠪታ")	:qdEKO42r3GhwmCDcHtxzJUR(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨቴ")
	,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬት")	:okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬቶ")
	,ykE045Tatx(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫቷ")				:OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"้ࠪฯ๎โโࠩቸ")
	,yNBjYsgc23xoW(u"ࠫࡩࡸࡡ࡮ࡣࡦࡥ࡫࡫ࠧቹ")			:ReLGYUQjz7C9iEd(u"๋่ࠬใ฻ࠣำึอๅศࠢๆหๆ๐็ࠨቺ")
	,ykE045Tatx(u"࠭ࡤࡳࡣࡰࡥࡸ࠽ࠧቻ")				:lU1fSmncFWjizwqZugyYBANML0(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧቼ")
	,yNBjYsgc23xoW(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩች")				:ttC4VURALPYKh(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠪቾ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬቿ")				:ttC4VURALPYKh(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠷ࠧኀ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠸ࠧኁ")				:yyZPkLCRX1xcBDN(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠳ࠩኂ")
	,UixkloZbzGw28ujW56X(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠴ࠩኃ")				:yNBjYsgc23xoW(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫኄ")
	,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠷ࠫኅ")				:lU1fSmncFWjizwqZugyYBANML0(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠹࠭ኆ")
	,eCpDE6wJtYUHn0GqK5(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨኇ")			:YXm2qAbu8Qsx(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦࡶࡪࡲࠪኈ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧ኉")				:dn9ouNryjHiBFQOhASvX(u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧኊ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡧࡪࡽࡳࡵࡷࠨኋ")				:YXm2qAbu8Qsx(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩኌ")
	,IYC4iPxkTRUE85namF6(u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬኍ")				:lU1fSmncFWjizwqZugyYBANML0(u"๊ࠫ๎โฺ่ࠢ์ุ๎ูสࠢสุ่๐ๆๆษࠪ኎")
	,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬ࡫࡬ࡪࡨࡹ࡭ࡩ࡫࡯ࠨ኏")			:qdEKO42r3GhwmCDcHtxzJUR(u"࠭ๅ้ไ฼ࠤศ๊๊โࠢไ๎ิ๐่ࠨነ")
	,eCpDE6wJtYUHn0GqK5(u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨኑ")				:ZYTyoA483N(u"ࠨ็๋ๆ฾ࠦแษำๆอࠬኒ")
	,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩና")				:qdEKO42r3GhwmCDcHtxzJUR(u"ࠪๅู๊ࠧኔ")
	,vhZ5qjay1z94JmcMOgXe(u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧን")			:eCpDE6wJtYUHn0GqK5(u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪኖ")
	,ReLGYUQjz7C9iEd(u"࠭ࡦࡢࡴࡨࡷࡰࡵࠧኗ")				:KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧๆ๊ๅ฽ࠥ็วา์ึ็ํ࠭ኘ")
	,YXm2qAbu8Qsx(u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠳ࠪኙ")				:okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"่ࠩ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫኚ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠶ࠬኛ")				:ZYTyoA483N(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧኜ")
	,UQS9lVew50DIyXrinWsMxTzA(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኝ")				:eCpDE6wJtYUHn0GqK5(u"࠭ๅอๆาࠫኞ")
	,IYC4iPxkTRUE85namF6(u"ࠧࡧࡱࡶࡸࡦ࠭ኟ")				:JP65RzKaScIf(u"ࠨ็๋ๆ฾ࠦแ้ีอหࠬአ")
	,E3i1eCBtN2w(u"ࠩࡩࡹࡳࡵ࡮ࡵࡸࠪኡ")				:YXm2qAbu8Qsx(u"้ࠪํู่ࠡใ้์๋ࠦส๋ใํࠫኢ")
	,yNBjYsgc23xoW(u"ࠫ࡫ࡻࡳࡩࡣࡵࡸࡻ࠭ኣ")				:vGg1hAkzqi8exVbN(u"๋่ࠬใ฻ࠣๅํฺวาࠢอ๎ๆ๐ࠧኤ")
	,A2MHFvoqpZ64gNbB(u"࠭ࡦࡶࡵ࡫ࡥࡷࡼࡩࡥࡧࡲࠫእ")			:yNBjYsgc23xoW(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤๆ๐ฯ๋๊ࠪኦ")
	,ZYTyoA483N(u"ࠨࡩࡲࡳࡩ࠭ኧ")					:Vi1oNCM5kI7yJ0(u"ࠩฯ๎ิ࠭ከ")
	,DKmLTA2yGtj(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬኩ")				:ykE045Tatx(u"๊ࠫ๎โฺ๊่ࠢฬࠦำ๋็สࠫኪ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫካ")				:A2MHFvoqpZ64gNbB(u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩኬ")
	,qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡪࡨ࡬ࡰࡲ࠭ክ")				:JP65RzKaScIf(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬኮ")
	,yyZPkLCRX1xcBDN(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨኯ")			:ZYTyoA483N(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬኰ")
	,yyZPkLCRX1xcBDN(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫ኱")		:IYC4iPxkTRUE85namF6(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪኲ")
	,dn9ouNryjHiBFQOhASvX(u"࠭ࡩࡱࡶࡹࠫኳ")					:jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡊࡒࡗ࡚ࠬኴ")
	,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨ࡫ࡳࡸࡻ࠳࡬ࡪࡸࡨࠫኵ")			:x9PULjztJOpu7b(u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭኶")
	,UQS9lVew50DIyXrinWsMxTzA(u"ࠪ࡭ࡵࡺࡶ࠮࡯ࡲࡺ࡮࡫ࡳࠨ኷")			:wFYiVd4r12x7CAQBL5SPof(u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨኸ")
	,NIBsHMvSXb(u"ࠬ࡯ࡰࡵࡸ࠰ࡷࡪࡸࡩࡦࡵࠪኹ")			:Vi1oNCM5kI7yJ0(u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬኺ")
	,ttC4VURALPYKh(u"ࠧ࡬ࡣࡵࡦࡦࡲࡡࡵࡸࠪኻ")			:zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫኼ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࡮ࡥࡹࡱ࡯ࡵࡶࡹࠫኽ")				:dn9ouNryjHiBFQOhASvX(u"้ࠪํู่ࠡๅอ็ํะࠠห์ไ๎ࠬኾ")
	,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭኿")				:zaOkgPnGLs6biVDuTjdCFrwefcqN(u"๋่ࠬใ฻ࠣ็ฯ้่หࠩዀ")
	,ZYTyoA483N(u"࠭࡫ࡪࡴࡰࡥࡱࡱࠧ዁")				:zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧๆ๊ๅ฽้ࠥัๆษ็็ࠬዂ")
	,qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡮ࡤࡶࡴࢀࡡࠨዃ")				:NIBsHMvSXb(u"่ࠩ์็฿ࠠๅษิ์ือࠧዄ")
	,lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡰ࡮ࡨࡲࡢࡴࡼࠫዅ")				:ee3tnwl7avk(u"๊๊ࠫแࠨ዆")
	,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡲࡩࡷࡧࠪ዇")					:tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭โ็ษฬࠫወ")
	,qdEKO42r3GhwmCDcHtxzJUR(u"ࠧ࡭࡫ࡹࡩࡹࡼࠧዉ")				:okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨ็็ๅࠬዊ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪዋ")				:DKmLTA2yGtj(u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩዌ")
	,YXm2qAbu8Qsx(u"ࠫࡲ࠹ࡵࠨው")					:vhZ5qjay1z94JmcMOgXe(u"ࠬࡓ࠳ࡖࠩዎ")
	,qdEKO42r3GhwmCDcHtxzJUR(u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨዏ")				:vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪዐ")
	,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬዑ")			:E3i1eCBtN2w(u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬዒ")
	,ee3tnwl7avk(u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧዓ")			:dn9ouNryjHiBFQOhASvX(u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩዔ")
	,A2MHFvoqpZ64gNbB(u"ࠬࡳࡡࡴࡣࡹ࡭ࡩ࡫࡯ࠨዕ")			:qdEKO42r3GhwmCDcHtxzJUR(u"࠭ๅ้ไ฼ࠤ๊อำศࠢไ๎ิ๐่ࠨዖ")
	,JP65RzKaScIf(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ዗")				:KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ็ไๆํีࠧዘ")
	,ttC4VURALPYKh(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩዙ")				:JP65RzKaScIf(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬዚ")
	,DKmLTA2yGtj(u"ࠫࡲࡿࡣࡪ࡯ࡤࠫዛ")				:DKmLTA2yGtj(u"๋่ࠬใ฻้ࠣฬ๐ࠠิ์่หࠬዜ")
	,x9PULjztJOpu7b(u"࠭࡯࡭ࡦࠪዝ")					:ykE045Tatx(u"ࠧใัํ้ࠬዞ")
	,UixkloZbzGw28ujW56X(u"ࠨࡲࡤࡲࡪࡺࠧዟ")				:yNBjYsgc23xoW(u"่ࠩ์็฿ࠠษษ้๎ฯ࠭ዠ")
	,UixkloZbzGw28ujW56X(u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩዡ")			:DKmLTA2yGtj(u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧዢ")
	,yyZPkLCRX1xcBDN(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫዣ")			:IYC4iPxkTRUE85namF6(u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫዤ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡲࡨ࡬ࡰࡲ࠭ዥ")				:JP65RzKaScIf(u"ࠨ็๋ๆ฾ࠦใ๋๊ࠣๅ๏๊ๅࠨዦ")
	,DKmLTA2yGtj(u"ࠩࡶࡩࡷ࡯ࡥࡴࡶ࡬ࡱࡪ࠭ዧ")			:A2MHFvoqpZ64gNbB(u"้ࠪํู่ࠡีํี๏ูࠠหษํ้ࠬየ")
	,IYC4iPxkTRUE85namF6(u"ࠫࡸ࡮ࡡࡣࡣ࡮ࡥࡹࡿࠧዩ")			:UixkloZbzGw28ujW56X(u"๋่ࠬใ฻ุࠣอ้ส๋ࠩዪ")
	,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨያ")				:qdEKO42r3GhwmCDcHtxzJUR(u"ࠧๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩዬ")
	,UixkloZbzGw28ujW56X(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬይ")			:Vi1oNCM5kI7yJ0(u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪዮ")
	,Vi1oNCM5kI7yJ0(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠭ዯ")			:dn9ouNryjHiBFQOhASvX(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭ደ")
	,x9PULjztJOpu7b(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣ࡯ࡦࡺࡳࡳࠨዱ")		:vhZ5qjay1z94JmcMOgXe(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧዲ")
	,yyZPkLCRX1xcBDN(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡺࡪࡩࡰࡵࠪዳ")		:vGg1hAkzqi8exVbN(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪዴ")
	,E3i1eCBtN2w(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡶࡥࡳࡵࡲࡲࡸ࠭ድ")	:KpNYeI2Pd4nHJG3cOTvWjbSa(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪዶ")
	,yyZPkLCRX1xcBDN(u"ࠫࡸ࡮࡯ࡧࡪࡤࠫዷ")				:vhZ5qjay1z94JmcMOgXe(u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧዸ")
	,IYC4iPxkTRUE85namF6(u"࠭ࡳࡩࡱࡲࡪࡲࡧࡸࠨዹ")				:yNBjYsgc23xoW(u"ࠧๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧዺ")
	,ttC4VURALPYKh(u"ࠨࡵ࡫ࡳࡴ࡬࡮ࡦࡶࠪዻ")				:okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"่ࠩ์็฿ࠠี๊ไࠤ๋ะࠧዼ")
	,A2MHFvoqpZ64gNbB(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬዽ")				:wFYiVd4r12x7CAQBL5SPof(u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪዾ")
	,dn9ouNryjHiBFQOhASvX(u"ࠬࡺࡩ࡬ࡣࡤࡸࠬዿ")				:ttC4VURALPYKh(u"࠭ๅ้ไ฼ࠤฯ้วหࠩጀ")
	,yNBjYsgc23xoW(u"ࠧࡵࡸࡩࡹࡳ࠭ጁ")				:yNBjYsgc23xoW(u"ࠨ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨጂ")
	,ReLGYUQjz7C9iEd(u"ࠩࡹࡥࡷࡨ࡯࡯ࠩጃ")				:qdEKO42r3GhwmCDcHtxzJUR(u"้ࠪํู่ࠡใสีอ๎ๆࠨጄ")
	,UixkloZbzGw28ujW56X(u"ࠫࡻ࡯ࡤࡦࡱࠪጅ")				:ttC4VURALPYKh(u"ࠬ็๊ะ์๋ࠫጆ")
	,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡶࡪࡦࡨࡳࡳࡹࡡࡦ࡯ࠪጇ")			:ykE045Tatx(u"ࠧๆ๊ๅ฽ࠥ็๊ะ์๋ࠤู๋วว็ࠪገ")
	,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠲ࠩጉ")				:qdEKO42r3GhwmCDcHtxzJUR(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠳ࠪጊ")
	,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡻࡪࡩࡩ࡮ࡣ࠵ࠫጋ")				:yNBjYsgc23xoW(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠣ࠶ࠬጌ")
	,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡿࡡࡲࡱࡷࠫግ")				:jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ๅ้ไ฼ࠤ๏อโ้ฬࠪጎ")
	,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨጏ")				:vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭ጐ")
	,eCpDE6wJtYUHn0GqK5(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ጑")		:yyZPkLCRX1xcBDN(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧጒ")
	,qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨጓ")	:DKmLTA2yGtj(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩጔ")
	,wFYiVd4r12x7CAQBL5SPof(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠧጕ")		:ee3tnwl7avk(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ็๊ะ์๋๋ฬะࠧ጖")
	,ttC4VURALPYKh(u"ࠨࡻࡷࡦࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ጗")			:tt8KsSi26LmWYVPxkMBl10dfRjXT(u"่ࠩ์ฬู่ࠡ็้ࠤ๏๎ส๋๊หࠫጘ")
	}
	K9aDRCk7tnZAezd = xQXoDIqn4Ucsthb2G7YpzwPTymi.lower()
	for key in list(smAPnDkcZjIhtSipQH.keys()):
		CNG3TIB24tKFeqoLkyrwEOWc = key.lower()
		if K9aDRCk7tnZAezd==CNG3TIB24tKFeqoLkyrwEOWc:
			xQXoDIqn4Ucsthb2G7YpzwPTymi = smAPnDkcZjIhtSipQH[key]
			break
	return xQXoDIqn4Ucsthb2G7YpzwPTymi
def KVirvJ58C1PjHyxel6FdwX():
	LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(A2MHFvoqpZ64gNbB(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡈࡲࡥࡢࡴࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱ࡾࡿࠪጙ"))
	raise ValueError(ttC4VURALPYKh(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧጚ"))
def i5xGCIRvcQlMemuO4jaYkWSwtD(cGblV1HRdC,RYiP30CVnLSFWyHjr4UNgZfk58z=Zg9FeADE84jSRIvPCrzYulw3sL):
	global B6ICRbTVXOQ1l4JsGxaFZy8AUvg2
	B6ICRbTVXOQ1l4JsGxaFZy8AUvg2 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if not RYiP30CVnLSFWyHjr4UNgZfk58z and cGblV1HRdC: RYiP30CVnLSFWyHjr4UNgZfk58z = DKmLTA2yGtj(u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡥࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ጛ")
	yUTYoAgth5iC43uLrdBH.setSetting(vGg1hAkzqi8exVbN(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪጜ"),RYiP30CVnLSFWyHjr4UNgZfk58z)
	return
def OJYiDeyvSPTNI9(ZTG4ruxXUsc9N,UVABNfQln6Sq=ee3tnwl7avk(u"ࠧ࠻࠱ࠪጝ")):
	return _IH9mXv75fCdFikBghQEbcxOV80sa(ZTG4ruxXUsc9N,UVABNfQln6Sq)
def Q0cIGopNygmEW329J(kT6I0rNCb9EjLz):
	if kT6I0rNCb9EjLz in [Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠨ࠲ࠪጞ"),UwCT5Oz6Wo0BP]: return Zg9FeADE84jSRIvPCrzYulw3sL
	kT6I0rNCb9EjLz = int(kT6I0rNCb9EjLz)
	ooZ4qpQ1JRwOK0vYWjxyrd = kT6I0rNCb9EjLz^ggWsYrlq8fy2v
	XYkQ29PeLWusHgzfqJyt63Bl = kT6I0rNCb9EjLz^E8RabFm1Kp5O0s
	yezPDU4sAZLKcfCEY5bm69 = kT6I0rNCb9EjLz^fA1u9wd7EkGBObjDhvWa
	uLvzsQGnaJqk = str(ooZ4qpQ1JRwOK0vYWjxyrd)+str(XYkQ29PeLWusHgzfqJyt63Bl)+str(yezPDU4sAZLKcfCEY5bm69)
	return uLvzsQGnaJqk
def PZGFzYuN1nlbvKRmaI8(kT6I0rNCb9EjLz):
	if kT6I0rNCb9EjLz in [Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠩ࠳ࠫጟ"),UwCT5Oz6Wo0BP]: return Zg9FeADE84jSRIvPCrzYulw3sL
	kT6I0rNCb9EjLz = str(kT6I0rNCb9EjLz)
	uLvzsQGnaJqk = Zg9FeADE84jSRIvPCrzYulw3sL
	if len(kT6I0rNCb9EjLz)==IK4zTnSMyGQpxEaesJAPVDY(u"࠷࠵ᓕ"):
		ooZ4qpQ1JRwOK0vYWjxyrd,XYkQ29PeLWusHgzfqJyt63Bl,yezPDU4sAZLKcfCEY5bm69 = kT6I0rNCb9EjLz[UwCT5Oz6Wo0BP:NEc173Pr0jAwLF5OS],kT6I0rNCb9EjLz[NEc173Pr0jAwLF5OS:IYC4iPxkTRUE85namF6(u"࠹ᓖ")],kT6I0rNCb9EjLz[IYC4iPxkTRUE85namF6(u"࠹ᓖ"):]
		ooZ4qpQ1JRwOK0vYWjxyrd = int(ooZ4qpQ1JRwOK0vYWjxyrd)^fA1u9wd7EkGBObjDhvWa
		XYkQ29PeLWusHgzfqJyt63Bl = int(XYkQ29PeLWusHgzfqJyt63Bl)^E8RabFm1Kp5O0s
		yezPDU4sAZLKcfCEY5bm69 = int(yezPDU4sAZLKcfCEY5bm69)^ggWsYrlq8fy2v
		if ooZ4qpQ1JRwOK0vYWjxyrd==XYkQ29PeLWusHgzfqJyt63Bl==yezPDU4sAZLKcfCEY5bm69: uLvzsQGnaJqk = str(ooZ4qpQ1JRwOK0vYWjxyrd*DKmLTA2yGtj(u"࠷࠲ᓗ"))
	return uLvzsQGnaJqk
def opwNMkO7yVeCJXqPI(kT6I0rNCb9EjLz,INHyK8dSPlu6j0kOqcUaTehx52gm=okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬጠ")):
	if kT6I0rNCb9EjLz==Zg9FeADE84jSRIvPCrzYulw3sL: return Zg9FeADE84jSRIvPCrzYulw3sL
	kT6I0rNCb9EjLz = int(kT6I0rNCb9EjLz)+int(INHyK8dSPlu6j0kOqcUaTehx52gm)
	ooZ4qpQ1JRwOK0vYWjxyrd = kT6I0rNCb9EjLz^ggWsYrlq8fy2v
	XYkQ29PeLWusHgzfqJyt63Bl = kT6I0rNCb9EjLz^E8RabFm1Kp5O0s
	yezPDU4sAZLKcfCEY5bm69 = kT6I0rNCb9EjLz^fA1u9wd7EkGBObjDhvWa
	uLvzsQGnaJqk = str(ooZ4qpQ1JRwOK0vYWjxyrd)+str(XYkQ29PeLWusHgzfqJyt63Bl)+str(yezPDU4sAZLKcfCEY5bm69)
	return uLvzsQGnaJqk
def hFlLfTs4oYBE(kT6I0rNCb9EjLz,INHyK8dSPlu6j0kOqcUaTehx52gm=yyZPkLCRX1xcBDN(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ጡ")):
	if kT6I0rNCb9EjLz==Zg9FeADE84jSRIvPCrzYulw3sL: return Zg9FeADE84jSRIvPCrzYulw3sL
	kT6I0rNCb9EjLz = str(kT6I0rNCb9EjLz)
	b6pDh28nQRtHylFIf5C = int(len(kT6I0rNCb9EjLz)/O4dklMvZ8ULcS)
	ooZ4qpQ1JRwOK0vYWjxyrd = int(kT6I0rNCb9EjLz[UwCT5Oz6Wo0BP:b6pDh28nQRtHylFIf5C])^ggWsYrlq8fy2v
	XYkQ29PeLWusHgzfqJyt63Bl = int(kT6I0rNCb9EjLz[b6pDh28nQRtHylFIf5C:DpahB8cwl4ZeKVsg71RuibSAfx0Ejr*b6pDh28nQRtHylFIf5C])^E8RabFm1Kp5O0s
	yezPDU4sAZLKcfCEY5bm69 = int(kT6I0rNCb9EjLz[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr*b6pDh28nQRtHylFIf5C:O4dklMvZ8ULcS*b6pDh28nQRtHylFIf5C])^fA1u9wd7EkGBObjDhvWa
	uLvzsQGnaJqk = Zg9FeADE84jSRIvPCrzYulw3sL
	if ooZ4qpQ1JRwOK0vYWjxyrd==XYkQ29PeLWusHgzfqJyt63Bl==yezPDU4sAZLKcfCEY5bm69: uLvzsQGnaJqk = str(int(ooZ4qpQ1JRwOK0vYWjxyrd)-int(INHyK8dSPlu6j0kOqcUaTehx52gm))
	return uLvzsQGnaJqk
def L8YzQPxF9OjJ6G(UlT5rR4SO0LNYvyu2eCk3cZM96s):
	sywnxdSVAN4iHUcu = PhpFa6EdVS[yNBjYsgc23xoW(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬጢ")][KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠺ᓘ")]
	iAjeXm5Ny9 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p,ttC4VURALPYKh(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩጣ"),ykE045Tatx(u"ࠧࡴ࡭࡬ࡲࡸ࠭ጤ"),E3i1eCBtN2w(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩጥ"),ee3tnwl7avk(u"ࠩ࠺࠶࠵ࡶࠧጦ"),ReLGYUQjz7C9iEd(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬጧ"))
	t6tVI4rREPUj9Dv7c5afskqBGWOiKx,fUnKBCe82L = M0VZ1cU2uDToibE6yj37RzCxkX5L(iAjeXm5Ny9)
	t6tVI4rREPUj9Dv7c5afskqBGWOiKx = opwNMkO7yVeCJXqPI(t6tVI4rREPUj9Dv7c5afskqBGWOiKx,ee3tnwl7avk(u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧጨ"))
	aTEbCl725nZcX9A = {vhZ5qjay1z94JmcMOgXe(u"ࠬ࡯ࡤࡴࠩጩ"):okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡄࡊࡃࡏࡓࡌ࠭ጪ"),DKmLTA2yGtj(u"ࠧࡶࡵࡵࠫጫ"):fs60XkagtWFJ,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡸࡨࡶࠬጬ"):kI8qwbo6yER,vGg1hAkzqi8exVbN(u"ࠩࡶࡧࡷ࠭ጭ"):UlT5rR4SO0LNYvyu2eCk3cZM96s,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡷ࡮ࢀࠧጮ"):t6tVI4rREPUj9Dv7c5afskqBGWOiKx}
	tIZGlVo2r63AnWLRC = {yNBjYsgc23xoW(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪጯ"):wFYiVd4r12x7CAQBL5SPof(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫጰ")}
	ccWRyTqp4d7KkHfBAz5 = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,wFYiVd4r12x7CAQBL5SPof(u"࠭ࡐࡐࡕࡗࠫጱ"),sywnxdSVAN4iHUcu,aTEbCl725nZcX9A,tIZGlVo2r63AnWLRC,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨጲ"))
	FlXDzyKoEJVWmx = ccWRyTqp4d7KkHfBAz5.content
	try:
		if not FlXDzyKoEJVWmx: mhd4PIU2f80K9
		ogxL5D1TPcVZKRp2 = JGmfjhoyKZUl(JP65RzKaScIf(u"ࠨࡦ࡬ࡧࡹ࠭ጳ"),FlXDzyKoEJVWmx)
		bbOX4ITWFdRhqjxDt8nAaMlyz6u5 = ogxL5D1TPcVZKRp2[IYC4iPxkTRUE85namF6(u"ࠩࡰࡷ࡬࠭ጴ")]
		TnjXCD1MiUvHQ3czkEmwSRogqrOdI = ogxL5D1TPcVZKRp2[yyZPkLCRX1xcBDN(u"ࠪࡷࡪࡩࠧጵ")]
		jXkFhtzwiCyxaTOMJKm4SqB6UdL3v = ogxL5D1TPcVZKRp2[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡸࡺࡰࠨጶ")]
		TnjXCD1MiUvHQ3czkEmwSRogqrOdI = int(hFlLfTs4oYBE(TnjXCD1MiUvHQ3czkEmwSRogqrOdI,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨጷ")))
		jXkFhtzwiCyxaTOMJKm4SqB6UdL3v = int(hFlLfTs4oYBE(jXkFhtzwiCyxaTOMJKm4SqB6UdL3v,lU1fSmncFWjizwqZugyYBANML0(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩጸ")))
		for R6WXFc4wKOj0J3Aat9BePhsQLdZloz in range(TnjXCD1MiUvHQ3czkEmwSRogqrOdI,UwCT5Oz6Wo0BP,-jXkFhtzwiCyxaTOMJKm4SqB6UdL3v):
			if not eval(wFYiVd4r12x7CAQBL5SPof(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬጹ"),{UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡺࡥࡱࡨ࠭ጺ"):Zz9SeICTbPksXy6nuOtLGWhN2V}): mhd4PIU2f80K9
			ZXWeI01flR(lU1fSmncFWjizwqZugyYBANML0(u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨጻ"),str(R6WXFc4wKOj0J3Aat9BePhsQLdZloz)+yyZPkLCRX1xcBDN(u"ࠪࠤࠥัว็์ฬࠫጼ"),LNma2eq3vEguwVtHjn=yNBjYsgc23xoW(u"࠶࠴࠵ᓙ")*jXkFhtzwiCyxaTOMJKm4SqB6UdL3v)
			Zz9SeICTbPksXy6nuOtLGWhN2V.sleep(IYC4iPxkTRUE85namF6(u"࠵࠵࠶࠰ᓚ")*jXkFhtzwiCyxaTOMJKm4SqB6UdL3v)
		if eval(NIBsHMvSXb(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩጽ"),{OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡾࡢ࡮ࡥࠪጾ"):Zz9SeICTbPksXy6nuOtLGWhN2V}):
			bbOX4ITWFdRhqjxDt8nAaMlyz6u5 = bbOX4ITWFdRhqjxDt8nAaMlyz6u5.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,vhZ5qjay1z94JmcMOgXe(u"࠭࡜࡝ࡰࠪጿ")).replace(mqBPGuVIYZbStQejFowJh2,qdEKO42r3GhwmCDcHtxzJUR(u"ࠧ࡝࡞ࡵࠫፀ"))
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠨะิ์ั࠭ፁ"),ttC4VURALPYKh(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬፂ"),bbOX4ITWFdRhqjxDt8nAaMlyz6u5)
		mhd4PIU2f80K9
	except: exec(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪፃ"),{eCpDE6wJtYUHn0GqK5(u"ࠫࡽࡨ࡭ࡤࠩፄ"):Zz9SeICTbPksXy6nuOtLGWhN2V})
	return
def Vhwb3zUBZ18qNM7Evp4sIyRAf():
	exec(yNBjYsgc23xoW(u"ࠬ࠭ࠧࠎࠌࡷࡶࡾࡀࠍࠋࠋࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷ࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࡻ࡭࡯࡬ࡦࠢࡗࡶࡺ࡫࠺ࠎࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡶࡰࡪ࡫ࡰࠩ࠳࠳࠴࠵࠯ࠍࠋࠋࠌࡸࡷࡿ࠺ࠡࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶࠲࡬࡫ࡴࡇࡱࡦࡹࡸ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡦࡷ࡫ࡡ࡬ࠏࠍࠍࡿࡩࡲࡦࡣࡷࡩࡤ࡫ࡲࡰࡴࡵࠑࠏ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮ࠓࠊࠨࠩࠪፅ"),{yNBjYsgc23xoW(u"࠭ࡸࡣ࡯ࡦ࡫ࡺ࡯ࠧፆ"):HqjWaYEzp0D8eyQRud,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡹࡤࡰࡧࠬፇ"):Zz9SeICTbPksXy6nuOtLGWhN2V})
	return
def M0VZ1cU2uDToibE6yj37RzCxkX5L(H047EqbDXrPzSx):
	U2OTiqjluMHLVhcg4Ako,Ahcb3XWMIz0JYT6g7jEpmsq = UwCT5Oz6Wo0BP,UwCT5Oz6Wo0BP
	if brAUlZfdFmt3TRJW2xX4.path.exists(H047EqbDXrPzSx):
		try: U2OTiqjluMHLVhcg4Ako = brAUlZfdFmt3TRJW2xX4.path.getsize(H047EqbDXrPzSx)
		except: pass
		if not U2OTiqjluMHLVhcg4Ako:
			try: U2OTiqjluMHLVhcg4Ako = brAUlZfdFmt3TRJW2xX4.stat(H047EqbDXrPzSx).st_size
			except: pass
		if not U2OTiqjluMHLVhcg4Ako:
			try:
				from pathlib import Path as ShfZKvwCnGe
				U2OTiqjluMHLVhcg4Ako = ShfZKvwCnGe(H047EqbDXrPzSx).stat().st_size
			except: pass
		if U2OTiqjluMHLVhcg4Ako: Ahcb3XWMIz0JYT6g7jEpmsq = Mn5NGAdz6xc42s0
	return U2OTiqjluMHLVhcg4Ako,Ahcb3XWMIz0JYT6g7jEpmsq
def eeiLrhbIvwnTuMo89ZOgEkJ(dtVFclTIzga7S,gZ6HWXMkuNVDhLKEvasrtROxBb,showDialogs):
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫፈ"),dtVFclTIzga7S+ykE045Tatx(u"ࠩ࡟ࡲࡡࡴࠧፉ")+PPQORjT2lc7SVkKwFI4D+vv3sNE8XCU2RAiyVaueTbD950pz(u"๋้ࠪࠦสา์าࠤู๊อ้ࠡำหࠥอไๆฮ็ำࠥลࠡࠨፊ")+u4IRSmrYMKkaHUBnDiLWh)
		if jzydmKVUWrCv9D34F!=Mn5NGAdz6xc42s0: return
	TOJwE16IZS7Af = vvglE69OFKBm817Nkc
	if brAUlZfdFmt3TRJW2xX4.path.exists(dtVFclTIzga7S):
		for ZKo6S7xzXC,Cv2QRZxhb7L,g9ic1KdEAJqulxUWCo in brAUlZfdFmt3TRJW2xX4.walk(dtVFclTIzga7S,topdown=vvglE69OFKBm817Nkc):
			for H047EqbDXrPzSx in g9ic1KdEAJqulxUWCo:
				RaCsQSZX0x3pkDoNtEzGy68 = brAUlZfdFmt3TRJW2xX4.path.join(ZKo6S7xzXC,H047EqbDXrPzSx)
				try: brAUlZfdFmt3TRJW2xX4.remove(RaCsQSZX0x3pkDoNtEzGy68)
				except Exception as JJyYREVW7k:
					if showDialogs and not TOJwE16IZS7Af: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፋ"),str(JJyYREVW7k))
					TOJwE16IZS7Af = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			if gZ6HWXMkuNVDhLKEvasrtROxBb:
				for dir in Cv2QRZxhb7L:
					VVkY50U1WtyMmLsCr = brAUlZfdFmt3TRJW2xX4.path.join(ZKo6S7xzXC,dir)
					try: brAUlZfdFmt3TRJW2xX4.rmdir(VVkY50U1WtyMmLsCr)
					except: pass
		if gZ6HWXMkuNVDhLKEvasrtROxBb:
			try: brAUlZfdFmt3TRJW2xX4.rmdir(ZKo6S7xzXC)
			except: pass
	if showDialogs and not TOJwE16IZS7Af:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፌ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧፍ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def OaItQeifu5jP3cF7(csmodNjArLZfC1v8PuKxU2Tg36JpI,TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT):
	hc5ePKxl4LJvEjDgTm,QhUZisYJOeAnr9LRCp35,a2E4KwJsuBAtP39zRc7g8L1Gjq,fWaIoG2QB4xXAi9reFz3VtlCd = gVZqoUpmC3NkPnAi(ZTG4ruxXUsc9N)
	dczJa6f5mpR = TgrlAZFKOMEcHt5d,hc5ePKxl4LJvEjDgTm,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8
	if csmodNjArLZfC1v8PuKxU2Tg36JpI<YXm2qAbu8Qsx(u"࠵ᓛ"):
		nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,NIBsHMvSXb(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨፎ"),dczJa6f5mpR)
		csmodNjArLZfC1v8PuKxU2Tg36JpI = -csmodNjArLZfC1v8PuKxU2Tg36JpI
	if csmodNjArLZfC1v8PuKxU2Tg36JpI>UixkloZbzGw28ujW56X(u"࠶ᓜ"):
		qHn7Qbi61UB = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡵࡷࡶࠬፏ"),Vi1oNCM5kI7yJ0(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪፐ"),dczJa6f5mpR)
		if qHn7Qbi61UB:
			BTKlfsON6tEUDkyLVvRQHezhcC4(yyZPkLCRX1xcBDN(u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨፑ"),ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT,TgrlAZFKOMEcHt5d)
			return qHn7Qbi61UB
	qHn7Qbi61UB = aOouqVcDHpnlR2Cz(TgrlAZFKOMEcHt5d,ZTG4ruxXUsc9N,WR7gIlwo5ik9zJv3CK4sS,Ay2hPpbZC7XmtQlwnfBT8,iojW2gVFfT)
	if qHn7Qbi61UB and csmodNjArLZfC1v8PuKxU2Tg36JpI: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,DKmLTA2yGtj(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬፒ"),dczJa6f5mpR,qHn7Qbi61UB,csmodNjArLZfC1v8PuKxU2Tg36JpI)
	return qHn7Qbi61UB
from fB2IPi6zhk import *
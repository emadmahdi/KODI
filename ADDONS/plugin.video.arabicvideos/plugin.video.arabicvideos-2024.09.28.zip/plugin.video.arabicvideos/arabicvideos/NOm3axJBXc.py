# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from V1VREBsj92 import *
bIPsOxjEpoH = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢨ")
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,tUHrEcLYK30N):
	if   LfnWDFgRdJH4lZvt7yo28N==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠹࠳࠱ऽ"): CsaNhTtGm8 = cOKhLS9ViqumsfTw84l5pe0GjZkCQ1()
	elif LfnWDFgRdJH4lZvt7yo28N==vGg1hAkzqi8exVbN(u"࠳࠴࠳ा"): CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(tUHrEcLYK30N)
	elif LfnWDFgRdJH4lZvt7yo28N==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠴࠵࠵ि"): CsaNhTtGm8 = I215BA9fbWtinqJVpaD7sPOEhzF()
	elif LfnWDFgRdJH4lZvt7yo28N==wFYiVd4r12x7CAQBL5SPof(u"࠵࠶࠷ी"): CsaNhTtGm8 = bbs1UC5q4rfD86xuRtOXQo9JTB()
	elif LfnWDFgRdJH4lZvt7yo28N==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠶࠷࠹ु"): CsaNhTtGm8 = szcl4TmkUMZgP(tUHrEcLYK30N)
	else: CsaNhTtGm8 = vvglE69OFKBm817Nkc
	return CsaNhTtGm8
def szcl4TmkUMZgP(LNXrA0mJhpuPTwk6):
	try: brAUlZfdFmt3TRJW2xX4.remove(LNXrA0mJhpuPTwk6.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
	except: brAUlZfdFmt3TRJW2xX4.remove(LNXrA0mJhpuPTwk6)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(tUHrEcLYK30N):
	nTdpZOCUe7l(tUHrEcLYK30N,bIPsOxjEpoH,ZYTyoA483N(u"ࠬࡼࡩࡥࡧࡲࠫࢩ"))
	return
def bbs1UC5q4rfD86xuRtOXQo9JTB():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = ykE045Tatx(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢪ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢫ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def cOKhLS9ViqumsfTw84l5pe0GjZkCQ1():
	A9Z3Ci2PQhFUwBXvI(ReLGYUQjz7C9iEd(u"ࠨ࡮࡬ࡲࡰ࠭ࢬ"),PPQORjT2lc7SVkKwFI4D+lU1fSmncFWjizwqZugyYBANML0(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢭ")+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"࠷࠸࠹ू"))
	A9Z3Ci2PQhFUwBXvI(yyZPkLCRX1xcBDN(u"ࠪࡰ࡮ࡴ࡫ࠨࢮ"),PPQORjT2lc7SVkKwFI4D+A2MHFvoqpZ64gNbB(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢯ")+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"࠸࠹࠲ृ"))
	A9Z3Ci2PQhFUwBXvI(lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡲࡩ࡯࡭ࠪࢰ"),PPQORjT2lc7SVkKwFI4D+x9PULjztJOpu7b(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢱ")+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"࠿࠹࠺࠻ॄ"))
	AAZJ8RTjlDWs5QhNeFzGSxbI = BRrtmWAJs9dgMXSI6Tc4q2LGjhi5()
	QRjg4fz9isbdNouhlaZc = brAUlZfdFmt3TRJW2xX4.stat(AAZJ8RTjlDWs5QhNeFzGSxbI).st_mtime
	g9ic1KdEAJqulxUWCo = []
	if GGfPQnrJKEqMv2ZVxdD: oIrx6KZFgNt73DAplCaOwyJq4fzS = brAUlZfdFmt3TRJW2xX4.listdir(AAZJ8RTjlDWs5QhNeFzGSxbI.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
	else: oIrx6KZFgNt73DAplCaOwyJq4fzS = brAUlZfdFmt3TRJW2xX4.listdir(AAZJ8RTjlDWs5QhNeFzGSxbI.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
	for GWOwzaVUyAH5JIC in oIrx6KZFgNt73DAplCaOwyJq4fzS:
		if GGfPQnrJKEqMv2ZVxdD: GWOwzaVUyAH5JIC = GWOwzaVUyAH5JIC.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		if not GWOwzaVUyAH5JIC.startswith(JP65RzKaScIf(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢲ")): continue
		ambSs1JNIuPMHBy3vAWX = brAUlZfdFmt3TRJW2xX4.path.join(AAZJ8RTjlDWs5QhNeFzGSxbI,GWOwzaVUyAH5JIC)
		QRjg4fz9isbdNouhlaZc = brAUlZfdFmt3TRJW2xX4.path.getmtime(ambSs1JNIuPMHBy3vAWX)
		g9ic1KdEAJqulxUWCo.append([GWOwzaVUyAH5JIC,QRjg4fz9isbdNouhlaZc])
	g9ic1KdEAJqulxUWCo = sorted(g9ic1KdEAJqulxUWCo,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: key[Mn5NGAdz6xc42s0])
	for GWOwzaVUyAH5JIC,QRjg4fz9isbdNouhlaZc in g9ic1KdEAJqulxUWCo:
		if HByjTem6EJP5sZb:
			try: GWOwzaVUyAH5JIC = GWOwzaVUyAH5JIC.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			except: pass
			GWOwzaVUyAH5JIC = GWOwzaVUyAH5JIC.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		ambSs1JNIuPMHBy3vAWX = brAUlZfdFmt3TRJW2xX4.path.join(AAZJ8RTjlDWs5QhNeFzGSxbI,GWOwzaVUyAH5JIC)
		A9Z3Ci2PQhFUwBXvI(ee3tnwl7avk(u"ࠨࡸ࡬ࡨࡪࡵࠧࢳ"),GWOwzaVUyAH5JIC,ambSs1JNIuPMHBy3vAWX,vhZ5qjay1z94JmcMOgXe(u"࠳࠴࠳ॅ"))
	return
def BRrtmWAJs9dgMXSI6Tc4q2LGjhi5():
	AAZJ8RTjlDWs5QhNeFzGSxbI = yUTYoAgth5iC43uLrdBH.getSetting(ZYTyoA483N(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢴ"))
	if AAZJ8RTjlDWs5QhNeFzGSxbI: return AAZJ8RTjlDWs5QhNeFzGSxbI
	yUTYoAgth5iC43uLrdBH.setSetting(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢵ"),cc6p0YbTjFzgyG3aRw)
	return cc6p0YbTjFzgyG3aRw
def I215BA9fbWtinqJVpaD7sPOEhzF():
	AAZJ8RTjlDWs5QhNeFzGSxbI = BRrtmWAJs9dgMXSI6Tc4q2LGjhi5()
	OmWI0UNRdtV = EiOpncsbPr8qQzGodeW(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢶ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢷ"),U2bWzwG8VdJsBqtR74ErDi3cg1v+AAZJ8RTjlDWs5QhNeFzGSxbI+u4IRSmrYMKkaHUBnDiLWh+lU1fSmncFWjizwqZugyYBANML0(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢸ"))
	if OmWI0UNRdtV==DKmLTA2yGtj(u"࠲ॆ"):
		d9Gq1Bawz72oIOylHhfbZ4kmFDrW = eeBnxzu5y1ogSQaRO(Vi1oNCM5kI7yJ0(u"࠵े"),NIBsHMvSXb(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢹ"),YXm2qAbu8Qsx(u"ࠨ࡮ࡲࡧࡦࡲࠧࢺ"),Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,AAZJ8RTjlDWs5QhNeFzGSxbI)
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(E3i1eCBtN2w(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢻ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢼ"),U2bWzwG8VdJsBqtR74ErDi3cg1v+AAZJ8RTjlDWs5QhNeFzGSxbI+u4IRSmrYMKkaHUBnDiLWh+IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢽ"))
		if jzydmKVUWrCv9D34F==ZYTyoA483N(u"࠴ै"):
			yUTYoAgth5iC43uLrdBH.setSetting(yNBjYsgc23xoW(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢾ"),d9Gq1Bawz72oIOylHhfbZ4kmFDrW)
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢿ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࣀ"))
	return
def fIPxNkKvy64OsA9(tUHrEcLYK30N,uVqMYescRCnSJyDlF7Hb=Zg9FeADE84jSRIvPCrzYulw3sL,website=Zg9FeADE84jSRIvPCrzYulw3sL):
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+eCpDE6wJtYUHn0GqK5(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࣁ")+tUHrEcLYK30N+x9PULjztJOpu7b(u"ࠩࠣࡡࠬࣂ"))
	if not uVqMYescRCnSJyDlF7Hb: uVqMYescRCnSJyDlF7Hb = wzX1klOfLVhb2B4ita(tUHrEcLYK30N)
	AAZJ8RTjlDWs5QhNeFzGSxbI = BRrtmWAJs9dgMXSI6Tc4q2LGjhi5()
	AA0Wd3yScYv2H9hBD7a4oPpi = pVZOH6lyXU(vvglE69OFKBm817Nkc)
	GWOwzaVUyAH5JIC = AA0Wd3yScYv2H9hBD7a4oPpi.replace(wjs26GpVfNiCUERHJ,qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡣࠬࣃ"))
	GWOwzaVUyAH5JIC = MwKxpYbB1gfk6RWQhl5F0sOAH4(GWOwzaVUyAH5JIC)
	GWOwzaVUyAH5JIC = IK4zTnSMyGQpxEaesJAPVDY(u"ࠫ࡫࡯࡬ࡦࡡࠪࣄ")+str(int(PPc8zbiVZnFkfXLBRv))[-JP65RzKaScIf(u"࠸ॉ"):]+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࡥࠧࣅ")+GWOwzaVUyAH5JIC+uVqMYescRCnSJyDlF7Hb
	VClEGd3kxDfN = brAUlZfdFmt3TRJW2xX4.path.join(AAZJ8RTjlDWs5QhNeFzGSxbI,GWOwzaVUyAH5JIC)
	z1MkhcyLvUeR0jKGg3t = {}
	z1MkhcyLvUeR0jKGg3t[Vi1oNCM5kI7yJ0(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࣆ")] = Zg9FeADE84jSRIvPCrzYulw3sL
	z1MkhcyLvUeR0jKGg3t[DKmLTA2yGtj(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣇ")] = E3i1eCBtN2w(u"ࠨࠬ࠲࠮ࠬࣈ")
	tUHrEcLYK30N = tUHrEcLYK30N.replace(JP65RzKaScIf(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣉ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	if okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ࣊") in tUHrEcLYK30N:
		hc5ePKxl4LJvEjDgTm,qoCMENGx4WgKp = tUHrEcLYK30N.rsplit(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ࣋"),qdEKO42r3GhwmCDcHtxzJUR(u"࠶ॊ"))
		qoCMENGx4WgKp = qoCMENGx4WgKp.replace(Vi1oNCM5kI7yJ0(u"ࠬࢂࠧ࣌"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(IYC4iPxkTRUE85namF6(u"࠭ࠦࠨ࣍"),Zg9FeADE84jSRIvPCrzYulw3sL)
	else: hc5ePKxl4LJvEjDgTm,qoCMENGx4WgKp = tUHrEcLYK30N,None
	if not qoCMENGx4WgKp: qoCMENGx4WgKp = lAfzvsbYy7oQ3r28EMe()
	if qoCMENGx4WgKp: z1MkhcyLvUeR0jKGg3t[x9PULjztJOpu7b(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࣎")] = qoCMENGx4WgKp
	if E3i1eCBtN2w(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࣏ࠪ") in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm,NNIKbSVi6Om372dg = hc5ePKxl4LJvEjDgTm.rsplit(lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀ࣐ࠫ"),IYC4iPxkTRUE85namF6(u"࠷ो"))
	else: hc5ePKxl4LJvEjDgTm,NNIKbSVi6Om372dg = hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.strip(ykE045Tatx(u"ࠪࢀ࣑ࠬ")).strip(dn9ouNryjHiBFQOhASvX(u"࣒ࠫࠫ࠭")).strip(UQS9lVew50DIyXrinWsMxTzA(u"ࠬࢂ࣓ࠧ")).strip(yNBjYsgc23xoW(u"࠭ࠦࠨࣔ"))
	NNIKbSVi6Om372dg = NNIKbSVi6Om372dg.replace(qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡽࠩࣕ"),Zg9FeADE84jSRIvPCrzYulw3sL).replace(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࠨࠪࣖ"),Zg9FeADE84jSRIvPCrzYulw3sL)
	if NNIKbSVi6Om372dg:	z1MkhcyLvUeR0jKGg3t[JP65RzKaScIf(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣗ")] = NNIKbSVi6Om372dg
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+UixkloZbzGw28ujW56X(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫࣘ")+hc5ePKxl4LJvEjDgTm+lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧࣙ")+str(z1MkhcyLvUeR0jKGg3t)+x9PULjztJOpu7b(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬࣚ")+VClEGd3kxDfN+vhZ5qjay1z94JmcMOgXe(u"࠭ࠠ࡞ࠩࣛ"))
	HSBPMf3ZT4L7 = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱࠱࠴࠷ौ")*tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱࠱࠴࠷ौ")
	oAO0ZyjInGDTct23Q = vhZ5qjay1z94JmcMOgXe(u"࠱्")
	try:
		BMrUz4aknjVKCwu9LYTQeJP =	Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(ee3tnwl7avk(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣜ"))
		BMrUz4aknjVKCwu9LYTQeJP = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨ࡞ࡧ࠯ࠬࣝ"),BMrUz4aknjVKCwu9LYTQeJP)
		oAO0ZyjInGDTct23Q = int(BMrUz4aknjVKCwu9LYTQeJP[UwCT5Oz6Wo0BP])
	except: pass
	if not oAO0ZyjInGDTct23Q:
		try:
			OkG4zrXxRwnTpDEP8 = brAUlZfdFmt3TRJW2xX4.statvfs(AAZJ8RTjlDWs5QhNeFzGSxbI)
			oAO0ZyjInGDTct23Q = OkG4zrXxRwnTpDEP8.f_frsize*OkG4zrXxRwnTpDEP8.f_bavail//HSBPMf3ZT4L7
		except: pass
	if not oAO0ZyjInGDTct23Q:
		try:
			OkG4zrXxRwnTpDEP8 = brAUlZfdFmt3TRJW2xX4.fstatvfs(AAZJ8RTjlDWs5QhNeFzGSxbI)
			oAO0ZyjInGDTct23Q = OkG4zrXxRwnTpDEP8.f_frsize*OkG4zrXxRwnTpDEP8.f_bavail//HSBPMf3ZT4L7
		except: pass
	if not oAO0ZyjInGDTct23Q:
		try:
			import shutil as X9egFOrVdajfbJoBY1T4PKh
			CSq3HMRKbsLnUZA1zV5e4cGQrDp,UUVBnLyNFkw,G5GpIXtWiTFJxOfb = X9egFOrVdajfbJoBY1T4PKh.disk_usage(AAZJ8RTjlDWs5QhNeFzGSxbI)
			oAO0ZyjInGDTct23Q = G5GpIXtWiTFJxOfb//HSBPMf3ZT4L7
		except: pass
	if not oAO0ZyjInGDTct23Q:
		ywuEego16R3ODiKVJr4Yf8qksH0vb(ttC4VURALPYKh(u"ࠩࡵ࡭࡬࡮ࡴࠨࣞ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣟ"),x9PULjztJOpu7b(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨ࣠"),yNBjYsgc23xoW(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣡"))
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧ࣢"))
		return vvglE69OFKBm817Nkc
	if uVqMYescRCnSJyDlF7Hb==eCpDE6wJtYUHn0GqK5(u"ࠧ࠯࡯࠶ࡹ࠽ࣣ࠭"):
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zKaqs0n5ZdrvWSTJYhy7(hc5ePKxl4LJvEjDgTm,z1MkhcyLvUeR0jKGg3t)
		if len(nnhWEIa6Tm)==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠲ॎ"):
			ZXWeI01flR(wFYiVd4r12x7CAQBL5SPof(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣤ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			return vvglE69OFKBm817Nkc
		elif len(nnhWEIa6Tm)==ttC4VURALPYKh(u"࠴ॏ"): lqQvOUWodZnhXLS2Vcuj6EtairFN = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠴ॐ")
		elif len(nnhWEIa6Tm)>NIBsHMvSXb(u"࠶॑"):
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(vhZ5qjay1z94JmcMOgXe(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣥ"), nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN == -ReLGYUQjz7C9iEd(u"࠷॒") :
				ZXWeI01flR(vGg1hAkzqi8exVbN(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้ࣦ࠭"),Zg9FeADE84jSRIvPCrzYulw3sL)
				return vvglE69OFKBm817Nkc
		hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	Uitn5fXukgj9OmRJSAd7 = eCpDE6wJtYUHn0GqK5(u"࠰॓")
	import requests as CzrjWh4Xgi3cqPZ2K
	if uVqMYescRCnSJyDlF7Hb==yNBjYsgc23xoW(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࣧ"):
		VClEGd3kxDfN = VClEGd3kxDfN.rsplit(vhZ5qjay1z94JmcMOgXe(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࣨ"))[UwCT5Oz6Wo0BP]+dn9ouNryjHiBFQOhASvX(u"࠭࠮࡮ࡲ࠷ࣩࠫ")
		t2P8jbfzoXhmWAe = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࡈࡇࡗࠫ࣪"),hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,z1MkhcyLvUeR0jKGg3t,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ࣫"))
		oYxLIbDgtOK2rhBc = t2P8jbfzoXhmWAe.content
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ࣬"),oYxLIbDgtOK2rhBc+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࡠࡳࡢࡲࠨ࣭"),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not CPv45ibdnBc:
			zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+YXm2qAbu8Qsx(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠ࣮ࠦࠧ")+hc5ePKxl4LJvEjDgTm+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࠦ࡝ࠨ࣯"))
			return vvglE69OFKBm817Nkc
		yDTPzhEBKVJl7CX81 = CPv45ibdnBc[UwCT5Oz6Wo0BP]
		if not yDTPzhEBKVJl7CX81.startswith(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡨࡵࡶࡳࣰࠫ")):
			if yDTPzhEBKVJl7CX81.startswith(A2MHFvoqpZ64gNbB(u"ࠧ࠰࠱ࣱࠪ")): yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm.split(DKmLTA2yGtj(u"ࠨ࠼ࣲࠪ"),vGg1hAkzqi8exVbN(u"࠲॔"))[UwCT5Oz6Wo0BP]+qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࠽ࠫࣳ")+yDTPzhEBKVJl7CX81
			elif yDTPzhEBKVJl7CX81.startswith(JP65RzKaScIf(u"ࠪ࠳ࠬࣴ")): yDTPzhEBKVJl7CX81 = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,dn9ouNryjHiBFQOhASvX(u"ࠫࡺࡸ࡬ࠨࣵ"))+yDTPzhEBKVJl7CX81
			else: yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm.rsplit(lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࠵ࣶࠧ"),vhZ5qjay1z94JmcMOgXe(u"࠳ॕ"))[UwCT5Oz6Wo0BP]+qdEKO42r3GhwmCDcHtxzJUR(u"࠭࠯ࠨࣷ")+yDTPzhEBKVJl7CX81
		t2P8jbfzoXhmWAe = CzrjWh4Xgi3cqPZ2K.request(dn9ouNryjHiBFQOhASvX(u"ࠧࡈࡇࡗࠫࣸ"),yDTPzhEBKVJl7CX81,headers=z1MkhcyLvUeR0jKGg3t,verify=vvglE69OFKBm817Nkc)
		yyuSQXA17U6CEGFMv2lpzhRB = t2P8jbfzoXhmWAe.content
		ZbYdXGnsxy1 = len(yyuSQXA17U6CEGFMv2lpzhRB)
		prKeIXDMZShi1YcB2qsxPoA8NOlG = len(CPv45ibdnBc)
		Uitn5fXukgj9OmRJSAd7 = ZbYdXGnsxy1*prKeIXDMZShi1YcB2qsxPoA8NOlG
	else:
		ZbYdXGnsxy1 = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠴ॖ")*HSBPMf3ZT4L7
		t2P8jbfzoXhmWAe = CzrjWh4Xgi3cqPZ2K.request(qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡉࡈࡘࣹࠬ"),hc5ePKxl4LJvEjDgTm,headers=z1MkhcyLvUeR0jKGg3t,verify=vvglE69OFKBm817Nkc,stream=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࣺࠪ") in t2P8jbfzoXhmWAe.headers: Uitn5fXukgj9OmRJSAd7 = int(t2P8jbfzoXhmWAe.headers[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣻ")])
		prKeIXDMZShi1YcB2qsxPoA8NOlG = int(Uitn5fXukgj9OmRJSAd7//ZbYdXGnsxy1)
	JQUrnN8qcX2La3Hf0M4lxPCTA = int(Uitn5fXukgj9OmRJSAd7//HSBPMf3ZT4L7)+A2MHFvoqpZ64gNbB(u"࠵ॗ")
	if Uitn5fXukgj9OmRJSAd7<yNBjYsgc23xoW(u"࠷࠷࠰࠱࠲क़"):
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣼ")+hc5ePKxl4LJvEjDgTm+ykE045Tatx(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+x9PULjztJOpu7b(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(oAO0ZyjInGDTct23Q)+NIBsHMvSXb(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣿ")+VClEGd3kxDfN+IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࠢࡠࠫऀ"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬँ"),E3i1eCBtN2w(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬं"))
		return vvglE69OFKBm817Nkc
	NjUuPlWdptC4vyZoQD8rVkabwHAc26 = dn9ouNryjHiBFQOhASvX(u"࠺࠰࠱ख़")
	H0WJtbPTjdVx8uNO7C = oAO0ZyjInGDTct23Q-JQUrnN8qcX2La3Hf0M4lxPCTA
	if H0WJtbPTjdVx8uNO7C<NjUuPlWdptC4vyZoQD8rVkabwHAc26:
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+YXm2qAbu8Qsx(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪः")+hc5ePKxl4LJvEjDgTm+Vi1oNCM5kI7yJ0(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩऄ")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+YXm2qAbu8Qsx(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬअ")+str(oAO0ZyjInGDTct23Q)+Vi1oNCM5kI7yJ0(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧआ")+str(NjUuPlWdptC4vyZoQD8rVkabwHAc26)+ykE045Tatx(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫइ")+VClEGd3kxDfN+x9PULjztJOpu7b(u"ࠩࠣࡡࠬई"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪउ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪऊ")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+ykE045Tatx(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऋ")+str(oAO0ZyjInGDTct23Q)+ZYTyoA483N(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ऌ")+str(NjUuPlWdptC4vyZoQD8rVkabwHAc26)+lU1fSmncFWjizwqZugyYBANML0(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩऍ"))
		return vvglE69OFKBm817Nkc
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(eCpDE6wJtYUHn0GqK5(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऎ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪए"),wFYiVd4r12x7CAQBL5SPof(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩऐ")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+UQS9lVew50DIyXrinWsMxTzA(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऑ")+str(oAO0ZyjInGDTct23Q)+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऒ"))
	if jzydmKVUWrCv9D34F!=tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱ग़"):
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,eCpDE6wJtYUHn0GqK5(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫओ"))
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+vv3sNE8XCU2RAiyVaueTbD950pz(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऔ")+hc5ePKxl4LJvEjDgTm+x9PULjztJOpu7b(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨक")+VClEGd3kxDfN+yyZPkLCRX1xcBDN(u"ࠩࠣࡡࠬख"))
		return vvglE69OFKBm817Nkc
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨग"))
	zkK23NOgQFhY75mjwDuxfbsc1EUiqS = Rr8woplmSQWXIZcGFfA()
	zkK23NOgQFhY75mjwDuxfbsc1EUiqS.create(VClEGd3kxDfN,IK4zTnSMyGQpxEaesJAPVDY(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬघ"))
	YR6J8iS7aEg290AKUyIsH1jr = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	if not XcPLKthYTV.dMeaPykZB3Ln8DGuS:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨङ"),IYC4iPxkTRUE85namF6(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧच"))
		return vvglE69OFKBm817Nkc
	if GGfPQnrJKEqMv2ZVxdD: UMPufVb9KJFELp1rtQigl6BoxzqCY = open(VClEGd3kxDfN,qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡸࡤࠪछ"))
	else: UMPufVb9KJFELp1rtQigl6BoxzqCY = open(VClEGd3kxDfN.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc),vGg1hAkzqi8exVbN(u"ࠨࡹࡥࠫज"))
	if uVqMYescRCnSJyDlF7Hb==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨझ"):
		for OEJ3PT81KtbZ in range(NIBsHMvSXb(u"࠲ज़"),prKeIXDMZShi1YcB2qsxPoA8NOlG+NIBsHMvSXb(u"࠲ज़")):
			yDTPzhEBKVJl7CX81 = CPv45ibdnBc[OEJ3PT81KtbZ-eCpDE6wJtYUHn0GqK5(u"࠳ड़")]
			if not yDTPzhEBKVJl7CX81.startswith(qdEKO42r3GhwmCDcHtxzJUR(u"ࠪ࡬ࡹࡺࡰࠨञ")):
				if yDTPzhEBKVJl7CX81.startswith(A2MHFvoqpZ64gNbB(u"ࠫ࠴࠵ࠧट")): yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm.split(UixkloZbzGw28ujW56X(u"ࠬࡀࠧठ"),yyZPkLCRX1xcBDN(u"࠴ढ़"))[UwCT5Oz6Wo0BP]+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭࠺ࠨड")+yDTPzhEBKVJl7CX81
				elif yDTPzhEBKVJl7CX81.startswith(UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࠰ࠩढ")): yDTPzhEBKVJl7CX81 = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,ykE045Tatx(u"ࠨࡷࡵࡰࠬण"))+yDTPzhEBKVJl7CX81
				else: yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm.rsplit(vGg1hAkzqi8exVbN(u"ࠩ࠲ࠫत"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠵फ़"))[UwCT5Oz6Wo0BP]+qdEKO42r3GhwmCDcHtxzJUR(u"ࠪ࠳ࠬथ")+yDTPzhEBKVJl7CX81
			t2P8jbfzoXhmWAe = CzrjWh4Xgi3cqPZ2K.request(vhZ5qjay1z94JmcMOgXe(u"ࠫࡌࡋࡔࠨद"),yDTPzhEBKVJl7CX81,headers=z1MkhcyLvUeR0jKGg3t,verify=vvglE69OFKBm817Nkc)
			yyuSQXA17U6CEGFMv2lpzhRB = t2P8jbfzoXhmWAe.content
			t2P8jbfzoXhmWAe.close()
			UMPufVb9KJFELp1rtQigl6BoxzqCY.write(yyuSQXA17U6CEGFMv2lpzhRB)
			HHTqNk9s6AGbKV = LNma2eq3vEguwVtHjn.time()
			leDU1YCyngJAWk = HHTqNk9s6AGbKV-nnm3Asbhj8z4IDdSXMC1Vx
			E6ta2p1VgyJMmen = leDU1YCyngJAWk//OEJ3PT81KtbZ
			mm6EblndyYHcfOr5eIMDUa8F7RAoCi = E6ta2p1VgyJMmen*(prKeIXDMZShi1YcB2qsxPoA8NOlG+NIBsHMvSXb(u"࠶य़"))
			Lm5stISOhr9NKol = mm6EblndyYHcfOr5eIMDUa8F7RAoCi-leDU1YCyngJAWk
			OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,int(x9PULjztJOpu7b(u"࠱࠱࠲ॡ")*OEJ3PT81KtbZ//(prKeIXDMZShi1YcB2qsxPoA8NOlG+lU1fSmncFWjizwqZugyYBANML0(u"࠷ॠ"))),NIBsHMvSXb(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ध"),vhZ5qjay1z94JmcMOgXe(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭न"),str(OEJ3PT81KtbZ*ZbYdXGnsxy1//HSBPMf3ZT4L7)+UixkloZbzGw28ujW56X(u"ࠧ࠰ࠩऩ")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+UixkloZbzGw28ujW56X(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭प")+LNma2eq3vEguwVtHjn.strftime(ttC4VURALPYKh(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦफ"),LNma2eq3vEguwVtHjn.gmtime(Lm5stISOhr9NKol))+ZYTyoA483N(u"ࠪࠤๅ࠭ब"))
			if zkK23NOgQFhY75mjwDuxfbsc1EUiqS.iscanceled():
				YR6J8iS7aEg290AKUyIsH1jr = vvglE69OFKBm817Nkc
				break
	else:
		OEJ3PT81KtbZ = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠱ॢ")
		for yyuSQXA17U6CEGFMv2lpzhRB in t2P8jbfzoXhmWAe.iter_content(chunk_size=ZbYdXGnsxy1):
			UMPufVb9KJFELp1rtQigl6BoxzqCY.write(yyuSQXA17U6CEGFMv2lpzhRB)
			OEJ3PT81KtbZ = OEJ3PT81KtbZ+x9PULjztJOpu7b(u"࠳ॣ")
			HHTqNk9s6AGbKV = LNma2eq3vEguwVtHjn.time()
			leDU1YCyngJAWk = HHTqNk9s6AGbKV-nnm3Asbhj8z4IDdSXMC1Vx
			E6ta2p1VgyJMmen = leDU1YCyngJAWk/OEJ3PT81KtbZ
			mm6EblndyYHcfOr5eIMDUa8F7RAoCi = E6ta2p1VgyJMmen*(prKeIXDMZShi1YcB2qsxPoA8NOlG+UixkloZbzGw28ujW56X(u"࠴।"))
			Lm5stISOhr9NKol = mm6EblndyYHcfOr5eIMDUa8F7RAoCi-leDU1YCyngJAWk
			OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,int(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠶࠶࠰०")*OEJ3PT81KtbZ/(prKeIXDMZShi1YcB2qsxPoA8NOlG+vGg1hAkzqi8exVbN(u"࠵॥"))),eCpDE6wJtYUHn0GqK5(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬभ"),eCpDE6wJtYUHn0GqK5(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬम"),str(OEJ3PT81KtbZ*ZbYdXGnsxy1//HSBPMf3ZT4L7)+DKmLTA2yGtj(u"࠭࠯ࠨय")+str(JQUrnN8qcX2La3Hf0M4lxPCTA)+IYC4iPxkTRUE85namF6(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬर")+LNma2eq3vEguwVtHjn.strftime(UixkloZbzGw28ujW56X(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥऱ"),LNma2eq3vEguwVtHjn.gmtime(Lm5stISOhr9NKol))+lU1fSmncFWjizwqZugyYBANML0(u"ࠩࠣไࠬल"))
			if zkK23NOgQFhY75mjwDuxfbsc1EUiqS.iscanceled():
				YR6J8iS7aEg290AKUyIsH1jr = vvglE69OFKBm817Nkc
				break
		t2P8jbfzoXhmWAe.close()
	UMPufVb9KJFELp1rtQigl6BoxzqCY.close()
	zkK23NOgQFhY75mjwDuxfbsc1EUiqS.close()
	if not YR6J8iS7aEg290AKUyIsH1jr:
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+ZYTyoA483N(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧळ")+hc5ePKxl4LJvEjDgTm+yNBjYsgc23xoW(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऴ")+VClEGd3kxDfN+UixkloZbzGw28ujW56X(u"ࠬࠦ࡝ࠨव"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩश"),lU1fSmncFWjizwqZugyYBANML0(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨष"))
		return CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,VsYiARtQ2WToMq(bIPsOxjEpoH)+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧस")+hc5ePKxl4LJvEjDgTm+dn9ouNryjHiBFQOhASvX(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩह")+VClEGd3kxDfN+JP65RzKaScIf(u"ࠪࠤࡢ࠭ऺ"))
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऻ"),ttC4VURALPYKh(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะ़ࠫ"))
	return CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'SHAHID4U'
j0jSEdTPJuG4XNvfpO = '_SH4_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
headers = {'User-Agent':lAfzvsbYy7oQ3r28EMe(True)}
Uhe07PlWNakHDZc1t = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==110: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==111: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==112: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==113: CsaNhTtGm8 = dHjny9tTucrO(url,True)
	elif mode==114: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'FULL_FILTER___'+text)
	elif mode==115: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'DEFINED_FILTER___'+text)
	elif mode==116: CsaNhTtGm8 = dHjny9tTucrO(url,False)
	elif mode==119: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(Pa6Q2LRkbtY0Id7nUNsZ.url,'url')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,119,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر محدد',Wtu1ZQ5yrA2KVlPs76EgbRvz,115)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر كامل',Wtu1ZQ5yrA2KVlPs76EgbRvz,114)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'المميزة',Wtu1ZQ5yrA2KVlPs76EgbRvz,111,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('simple-filter(.*?)adv-filter',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for filter,W8KBRzkdhlCxvF5sY2T,title in items:
			url = Wtu1ZQ5yrA2KVlPs76EgbRvz+filter
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,url,111,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,filter)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="dropdown"(.*?)<script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			if title in Uhe07PlWNakHDZc1t: continue
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+yDTPzhEBKVJl7CX81
			if 'netflix' in yDTPzhEBKVJl7CX81: title = 'نيتفلكس'
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,111)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url,AxYL8hm1sni5ej=Zg9FeADE84jSRIvPCrzYulw3sL,Pa6Q2LRkbtY0Id7nUNsZ=Zg9FeADE84jSRIvPCrzYulw3sL):
	if not Pa6Q2LRkbtY0Id7nUNsZ: Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f,items,cfUCuhJwZijTLxQX3gHayn89RqGrP = [],[],[]
	if AxYL8hm1sni5ej=='featured': HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('glide__slides(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('shows-container(.*?)pagination',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f: return
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		if 'WWE' in title: continue
		if 'javascript' in yDTPzhEBKVJl7CX81: continue
		yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81).strip('/')
		title = BtKvPnEQJx32Z(title)
		title = title.strip(wjs26GpVfNiCUERHJ)
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) الحلقة \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if '/film/' in yDTPzhEBKVJl7CX81 or 'فيلم' in yDTPzhEBKVJl7CX81 or any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,112,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,113,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/actor/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,111,W8KBRzkdhlCxvF5sY2T)
		elif '/series/' in yDTPzhEBKVJl7CX81 and '/list' not in url:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'/list'
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,111,W8KBRzkdhlCxvF5sY2T)
		elif '/list' in url and 'حلقة' in title:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,112,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,113,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		if AxYL8hm1sni5ej!='search': items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(updateQuery).*?>(.+?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		else: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<li>.*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for yDTPzhEBKVJl7CX81,title in items:
			title = title.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
			title = title.strip(wjs26GpVfNiCUERHJ)
			if AxYL8hm1sni5ej!='search':
				if '?' in url: yDTPzhEBKVJl7CX81 = url+'&page='+title
				else: yDTPzhEBKVJl7CX81 = url+'?page='+title
			title = BtKvPnEQJx32Z(title)
			if title: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,111,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,AxYL8hm1sni5ej)
	return
def dHjny9tTucrO(url,nh9yPVLxIpMKkRAaiJUmQT):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('items d-flex(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if len(HNRenB3EZX62qgSKMd4f)>1:
		if '/season/' in HNRenB3EZX62qgSKMd4f[0]: TdawvCqlKOoMIJygBtsQWGSbz,bbl9kf1oL2 = HNRenB3EZX62qgSKMd4f[0],HNRenB3EZX62qgSKMd4f[1]
		else: TdawvCqlKOoMIJygBtsQWGSbz,bbl9kf1oL2 = HNRenB3EZX62qgSKMd4f[1],HNRenB3EZX62qgSKMd4f[0]
	else: TdawvCqlKOoMIJygBtsQWGSbz,bbl9kf1oL2 = HNRenB3EZX62qgSKMd4f[0],HNRenB3EZX62qgSKMd4f[0]
	for OEJ3PT81KtbZ in range(2):
		if nh9yPVLxIpMKkRAaiJUmQT: mode,type,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = 116,'folder',TdawvCqlKOoMIJygBtsQWGSbz
		else: mode,type,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = 112,'video',bbl9kf1oL2
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nh9yPVLxIpMKkRAaiJUmQT and len(items)<2:
			nh9yPVLxIpMKkRAaiJUmQT = False
			continue
		for yDTPzhEBKVJl7CX81,kHDNMKGBw6pdeJ0WZi4,wUpHn5IfzaQ8g4j in items:
			title = kHDNMKGBw6pdeJ0WZi4+wjs26GpVfNiCUERHJ+wUpHn5IfzaQ8g4j
			A9Z3Ci2PQhFUwBXvI(type,j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,mode)
		break
	if not items and '/episodes' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		pB694VZaim183untF2dcM = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="breadcrumb"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if pB694VZaim183untF2dcM:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = pB694VZaim183untF2dcM[0]
			CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if len(CPv45ibdnBc)>2:
				yDTPzhEBKVJl7CX81 = CPv45ibdnBc[2]+'list'
				mbzIyKNqMVt0FQeOsPWc(yDTPzhEBKVJl7CX81)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="actions(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not HNRenB3EZX62qgSKMd4f: return
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	xx4RXlo1qr592GNiEtUjsSmwJ = '/watch/' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA
	download = '/download/' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA
	if   xx4RXlo1qr592GNiEtUjsSmwJ and not download: B34dAmGW8y1L0pEOitgVFIqjC,S7sw0l93EBeqzDQcAHhXUPMf5Jv4 = CPv45ibdnBc[0],Zg9FeADE84jSRIvPCrzYulw3sL
	elif not xx4RXlo1qr592GNiEtUjsSmwJ and download: B34dAmGW8y1L0pEOitgVFIqjC,S7sw0l93EBeqzDQcAHhXUPMf5Jv4 = Zg9FeADE84jSRIvPCrzYulw3sL,CPv45ibdnBc[0]
	elif xx4RXlo1qr592GNiEtUjsSmwJ and download: B34dAmGW8y1L0pEOitgVFIqjC,S7sw0l93EBeqzDQcAHhXUPMf5Jv4 = CPv45ibdnBc[0],CPv45ibdnBc[1]
	else: B34dAmGW8y1L0pEOitgVFIqjC,S7sw0l93EBeqzDQcAHhXUPMf5Jv4 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	if xx4RXlo1qr592GNiEtUjsSmwJ:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',B34dAmGW8y1L0pEOitgVFIqjC,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-PLAY-2nd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('let servers(.*?)player',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if sQPyfIOFgKLTU4u23XB6dmS9:
			idOhoxawsrWQVgTMfGC6lBmDN7XEK = sQPyfIOFgKLTU4u23XB6dmS9[0]
			QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"name":"(.*?)".*?"url":"(.*?)"',idOhoxawsrWQVgTMfGC6lBmDN7XEK,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for title,yDTPzhEBKVJl7CX81 in QaVoNlxzSUORpb:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\/','/')
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if download:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',S7sw0l93EBeqzDQcAHhXUPMf5Jv4,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-PLAY-3rd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"servers"(.*?)info-container',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if sQPyfIOFgKLTU4u23XB6dmS9:
			idOhoxawsrWQVgTMfGC6lBmDN7XEK = sQPyfIOFgKLTU4u23XB6dmS9[0]
			QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',idOhoxawsrWQVgTMfGC6lBmDN7XEK,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title,YUCPADxT3NrgM in QaVoNlxzSUORpb:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'+'____'+YUCPADxT3NrgM
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/search?s='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
def N3feaqwRugp50CJUtScZ781QBT(url):
	url = url.split('/smartemadfilter?')[0]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	wAsQoW6l1DitrY7MC = []
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('adv-filter(.*?)shows-container',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		wAsQoW6l1DitrY7MC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		qfL9zImCSg8r,S2hbYR5w0m7k68OHDyBgCnjA4izlJ,qLx93JtrVCHlKaZW2hXc7dpiNmDR = zip(*wAsQoW6l1DitrY7MC)
		wAsQoW6l1DitrY7MC = zip(S2hbYR5w0m7k68OHDyBgCnjA4izlJ,qfL9zImCSg8r,qLx93JtrVCHlKaZW2hXc7dpiNmDR)
	return wAsQoW6l1DitrY7MC
def b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA):
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('value="(.*?)".*?>\s*(.*?)\s*<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	return items
def pS83GuJDxZId9gbzmjnh1NrLO4a(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	oWd0XOQnlD1PHbYmR = url.split('/smartemadfilter?')[0]
	G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(url,'url')
	url = url.replace(oWd0XOQnlD1PHbYmR,G7lNnPYTc3Am8jLxp)
	url = url.replace('/smartemadfilter?','/?')
	return url
Czur3fR1EoGVAJLkYMnplBsvcabX = ['quality','year','genre','category']
SRbXctrBg8o2zLe95Q = ['category','genre','year']
def sF8AGonNID9x0J3TSUL2hd1Qjv(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Zg9FeADE84jSRIvPCrzYulw3sL: oorcIqYuTf6,LeoFXqubIsNmlZ0 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	else: oorcIqYuTf6,LeoFXqubIsNmlZ0 = filter.split('___')
	if type=='DEFINED_FILTER':
		if SRbXctrBg8o2zLe95Q[0]+'=' not in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = SRbXctrBg8o2zLe95Q[0]
		for YjZN3ADmertFahUQIECW in range(len(SRbXctrBg8o2zLe95Q[0:-1])):
			if SRbXctrBg8o2zLe95Q[YjZN3ADmertFahUQIECW]+'=' in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = SRbXctrBg8o2zLe95Q[YjZN3ADmertFahUQIECW+1]
		PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL.strip('&')+'___'+OOYBCTKMVyFR3lpLNP.strip('&')
		YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
	elif type=='FULL_FILTER':
		KK2pncrBCsGVagozjlQIb5dAD7k = kt4gOnZ7y6A0ifpW1L8VJFDaR(oorcIqYuTf6,'modified_values')
		KK2pncrBCsGVagozjlQIb5dAD7k = UAjMPLdITqWChbrcB(KK2pncrBCsGVagozjlQIb5dAD7k)
		if LeoFXqubIsNmlZ0!=Zg9FeADE84jSRIvPCrzYulw3sL: LeoFXqubIsNmlZ0 = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'modified_filters')
		if LeoFXqubIsNmlZ0==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+LeoFXqubIsNmlZ0
		JaqiYfEglZDvmwQNS8zR = pS83GuJDxZId9gbzmjnh1NrLO4a(hc5ePKxl4LJvEjDgTm)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أظهار قائمة الفيديو التي تم اختيارها ',JaqiYfEglZDvmwQNS8zR,111)
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' [[   '+KK2pncrBCsGVagozjlQIb5dAD7k+'   ]]',JaqiYfEglZDvmwQNS8zR,111)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	wAsQoW6l1DitrY7MC = N3feaqwRugp50CJUtScZ781QBT(url)
	dict = {}
	for name,ddFeJa6wxq2zNMPsjth9bZAmVO,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in wAsQoW6l1DitrY7MC:
		name = name.replace('كل ',Zg9FeADE84jSRIvPCrzYulw3sL)
		items = b4boXIp3gnuPmMLa9d5tW2R6BUTvDi(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
		if '=' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = url
		if type=='DEFINED_FILTER':
			if WWdHIOCPeKmgRstXk4c!=ddFeJa6wxq2zNMPsjth9bZAmVO: continue
			elif len(items)<2:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==SRbXctrBg8o2zLe95Q[-1]:
					JaqiYfEglZDvmwQNS8zR = pS83GuJDxZId9gbzmjnh1NrLO4a(hc5ePKxl4LJvEjDgTm)
					mbzIyKNqMVt0FQeOsPWc(JaqiYfEglZDvmwQNS8zR)
				else: sF8AGonNID9x0J3TSUL2hd1Qjv(hc5ePKxl4LJvEjDgTm,'DEFINED_FILTER___'+JDm4zR9r37vHg)
				return
			else:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==SRbXctrBg8o2zLe95Q[-1]:
					JaqiYfEglZDvmwQNS8zR = pS83GuJDxZId9gbzmjnh1NrLO4a(hc5ePKxl4LJvEjDgTm)
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',JaqiYfEglZDvmwQNS8zR,111)
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,115,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		elif type=='FULL_FILTER':
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع :'+name,hc5ePKxl4LJvEjDgTm,114,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		dict[ddFeJa6wxq2zNMPsjth9bZAmVO] = {}
		for B251BPiLbvG9UxszKtlI7YQHmoWw,xWfrLDQiMOA358ghbsZk6PtSK in items:
			if B251BPiLbvG9UxszKtlI7YQHmoWw=='196533': xWfrLDQiMOA358ghbsZk6PtSK = 'أفلام نيتفلكس'
			elif B251BPiLbvG9UxszKtlI7YQHmoWw=='196531': xWfrLDQiMOA358ghbsZk6PtSK = 'مسلسلات نيتفلكس'
			if xWfrLDQiMOA358ghbsZk6PtSK in Uhe07PlWNakHDZc1t: continue
			dict[ddFeJa6wxq2zNMPsjth9bZAmVO][B251BPiLbvG9UxszKtlI7YQHmoWw] = xWfrLDQiMOA358ghbsZk6PtSK
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+xWfrLDQiMOA358ghbsZk6PtSK
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
			OOiZSE1AIGsxBp0PqUo4bHgQ8u7 = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			title = xWfrLDQiMOA358ghbsZk6PtSK+' :'#+dict[ddFeJa6wxq2zNMPsjth9bZAmVO]['0']
			title = xWfrLDQiMOA358ghbsZk6PtSK+' :'+name
			if type=='FULL_FILTER': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,114,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
			elif type=='DEFINED_FILTER' and SRbXctrBg8o2zLe95Q[-2]+'=' in oorcIqYuTf6:
				YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(OOYBCTKMVyFR3lpLNP,'modified_filters')
				hc5ePKxl4LJvEjDgTm = url+'/smartemadfilter?'+YYwyLpO9f2Do7rztliJ3qFnscT
				JaqiYfEglZDvmwQNS8zR = pS83GuJDxZId9gbzmjnh1NrLO4a(hc5ePKxl4LJvEjDgTm)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,JaqiYfEglZDvmwQNS8zR,111)
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,115,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
	return
def kt4gOnZ7y6A0ifpW1L8VJFDaR(fn9dgJ0v1KVrZ,mode):
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.replace('=&','=0&')
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.strip('&')
	vJfWILDinBuPZjcUamEHlq = {}
	if '=' in fn9dgJ0v1KVrZ:
		items = fn9dgJ0v1KVrZ.split('&')
		for r1OMYvp0ViTG in items:
			MnwlGZ9Ef3S7kv5sxtzRiFaoCIb,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=')
			vJfWILDinBuPZjcUamEHlq[MnwlGZ9Ef3S7kv5sxtzRiFaoCIb] = B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = Zg9FeADE84jSRIvPCrzYulw3sL
	for key in Czur3fR1EoGVAJLkYMnplBsvcabX:
		if key in list(vJfWILDinBuPZjcUamEHlq.keys()): B251BPiLbvG9UxszKtlI7YQHmoWw = vJfWILDinBuPZjcUamEHlq[key]
		else: B251BPiLbvG9UxszKtlI7YQHmoWw = '0'
		if '%' not in B251BPiLbvG9UxszKtlI7YQHmoWw: B251BPiLbvG9UxszKtlI7YQHmoWw = OJYiDeyvSPTNI9(B251BPiLbvG9UxszKtlI7YQHmoWw)
		if mode=='modified_values' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+' + '+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='modified_filters' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='all': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip(' + ')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip('&')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.replace('=0','=')
	return PJlIOHanFyNWTgfswRdYXvei4x0Vh
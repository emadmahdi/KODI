# -*- coding: utf-8 -*-
from V1VREBsj92 import *
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
bIPsOxjEpoH = 'AKOAMCAM'
j0jSEdTPJuG4XNvfpO = '_AKC_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['مصارعة']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==350: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==351: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==352: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==353: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==354: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'FILTERS___'+text)
	elif mode==355: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'CATEGORIES___'+text)
	elif mode==356: CsaNhTtGm8 = wM8Tf2sueEvmJPGLF65nWZY39KoBy1(url)
	elif mode==357: CsaNhTtGm8 = vPdWhb3FQmwcjr0xk(url)
	elif mode==359: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+U2bWzwG8VdJsBqtR74ErDi3cg1v+'هذا الموقع مغلق'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,8)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,359,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر محدد',qfzHe2Yr49,356)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر كامل',qfzHe2Yr49,357)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-MENU-1st')
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('recently-container.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[0]
	else: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'اضيف حديثا',hc5ePKxl4LJvEjDgTm,351)
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('@id":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[0]
	else: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',hc5ePKxl4LJvEjDgTm,351,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('main-categories-list(.*?)main-categories-list',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?class="font.*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,351)
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="categories-box(.*?)<footer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = BtKvPnEQJx32Z(yDTPzhEBKVJl7CX81)
			if title not in Uhe07PlWNakHDZc1t: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,351)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def wM8Tf2sueEvmJPGLF65nWZY39KoBy1(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="menu(.*?)<nav',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?text">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t:
				title = title+' مصنفة'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,355)
		if website==Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def vPdWhb3FQmwcjr0xk(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="menu(.*?)<nav',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?text">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t:
				title = title+' مفلترة'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,354)
		if website==Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(FFP5vTqk3nDlEuGdIy,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('swiper-container(.*?)swiper-button-prev',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="container"(.*?)main-footer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		cfUCuhJwZijTLxQX3gHayn89RqGrP = []
		for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|الحلقه) \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if jjYXOr8QJsNUZv0PGL27ARSDceiq4:
					title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
					if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
						A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,352,W8KBRzkdhlCxvF5sY2T)
						cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
			elif 'مسلسل' in title:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,352,W8KBRzkdhlCxvF5sY2T)
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,353,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href=["\'](.*?)["\'].*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = BtKvPnEQJx32Z(yDTPzhEBKVJl7CX81)
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,351)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49 + '/?s='+IGh3FSLfnog2BjN8s
	CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	return
def dHjny9tTucrO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAMCAM-EPISODES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('text-white">الحلقات(.*?)<header',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		bbl9kf1oL2 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in bbl9kf1oL2:
			if 'الحلقة' in title or 'الحلقه' in title: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,353,W8KBRzkdhlCxvF5sY2T)
	else:
		W8KBRzkdhlCxvF5sY2T = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Icon')
		if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.count('<title>')>1: title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<title>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[1]
		else: title = 'رابط التشغيل'
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,url,353,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	fo6s53yEnbklLpaJOzgR4Q01wxB,nnhWEIa6Tm = [],[]
	d0QkNBpUyioDC6SGrmR5wOfJ2L = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = d0QkNBpUyioDC6SGrmR5wOfJ2L.content
	BmVyhAve6X2PYuI = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('post_id=(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if BmVyhAve6X2PYuI:
		BmVyhAve6X2PYuI = BmVyhAve6X2PYuI[0]
		headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':BmVyhAve6X2PYuI}
		hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		ufBWA3ZgliacIVk = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'POST',hc5ePKxl4LJvEjDgTm,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-PLAY-1st')
		CNhQcnS0dI6UFjbvLoyx = ufBWA3ZgliacIVk.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-server="(.*?)".*?class="text">(.*?)<',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for B6xEjq29ihy4rDnfGLFC,name in items:
			yDTPzhEBKVJl7CX81 = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?postid='+BmVyhAve6X2PYuI+'&serverid='+B6xEjq29ihy4rDnfGLFC+'?named='+name+'__watch'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(name)
		hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		ufBWA3ZgliacIVk = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'POST',hc5ePKxl4LJvEjDgTm,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'AKOAMCAM-PLAY-1st')
		CNhQcnS0dI6UFjbvLoyx = ufBWA3ZgliacIVk.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?class="text">(.*?)<',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__download'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(title)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def sF8AGonNID9x0J3TSUL2hd1Qjv(url,filter):
	yycVIo28p69ZU3XRaCbYdP = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==Zg9FeADE84jSRIvPCrzYulw3sL: oorcIqYuTf6,LeoFXqubIsNmlZ0 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	else: oorcIqYuTf6,LeoFXqubIsNmlZ0 = filter.split('___')
	if type=='CATEGORIES':
		if yycVIo28p69ZU3XRaCbYdP[0]+'=' not in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[0]
		for YjZN3ADmertFahUQIECW in range(len(yycVIo28p69ZU3XRaCbYdP[0:-1])):
			if yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW]+'=' in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW+1]
		PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL.strip('&')+'___'+OOYBCTKMVyFR3lpLNP.strip('&')
		YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'all')
		hc5ePKxl4LJvEjDgTm = url+'?'+YYwyLpO9f2Do7rztliJ3qFnscT
	elif type=='FILTERS':
		KK2pncrBCsGVagozjlQIb5dAD7k = kt4gOnZ7y6A0ifpW1L8VJFDaR(oorcIqYuTf6,'modified_values')
		KK2pncrBCsGVagozjlQIb5dAD7k = UAjMPLdITqWChbrcB(KK2pncrBCsGVagozjlQIb5dAD7k)
		if LeoFXqubIsNmlZ0!=Zg9FeADE84jSRIvPCrzYulw3sL: LeoFXqubIsNmlZ0 = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'all')
		if LeoFXqubIsNmlZ0==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = url+'?'+LeoFXqubIsNmlZ0
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أظهار قائمة الفيديو التي تم اختيارها',hc5ePKxl4LJvEjDgTm,351,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' [[   '+KK2pncrBCsGVagozjlQIb5dAD7k+'   ]]',hc5ePKxl4LJvEjDgTm,351,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<form id(.*?)</form>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	wAsQoW6l1DitrY7MC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	dict = {}
	for ddFeJa6wxq2zNMPsjth9bZAmVO,name,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in wAsQoW6l1DitrY7MC:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<option(.*?)>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if '=' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = url
		if type=='CATEGORIES':
			if WWdHIOCPeKmgRstXk4c!=ddFeJa6wxq2zNMPsjth9bZAmVO: continue
			elif len(items)<=1:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: mbzIyKNqMVt0FQeOsPWc(hc5ePKxl4LJvEjDgTm)
				else: sF8AGonNID9x0J3TSUL2hd1Qjv(hc5ePKxl4LJvEjDgTm,'CATEGORIES___'+JDm4zR9r37vHg)
				return
			else:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,351,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,355,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		elif type=='FILTERS':
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع : '+name,hc5ePKxl4LJvEjDgTm,354,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		dict[ddFeJa6wxq2zNMPsjth9bZAmVO] = {}
		for B251BPiLbvG9UxszKtlI7YQHmoWw,xWfrLDQiMOA358ghbsZk6PtSK in items:
			if xWfrLDQiMOA358ghbsZk6PtSK in Uhe07PlWNakHDZc1t: continue
			if 'value' not in B251BPiLbvG9UxszKtlI7YQHmoWw: B251BPiLbvG9UxszKtlI7YQHmoWw = xWfrLDQiMOA358ghbsZk6PtSK
			else: B251BPiLbvG9UxszKtlI7YQHmoWw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(.*?)"',B251BPiLbvG9UxszKtlI7YQHmoWw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
			dict[ddFeJa6wxq2zNMPsjth9bZAmVO][B251BPiLbvG9UxszKtlI7YQHmoWw] = xWfrLDQiMOA358ghbsZk6PtSK
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+xWfrLDQiMOA358ghbsZk6PtSK
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
			OOiZSE1AIGsxBp0PqUo4bHgQ8u7 = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			title = xWfrLDQiMOA358ghbsZk6PtSK+' : '#+dict[ddFeJa6wxq2zNMPsjth9bZAmVO]['0']
			title = xWfrLDQiMOA358ghbsZk6PtSK+' : '+name
			if type=='FILTERS': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,354,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
			elif type=='CATEGORIES' and yycVIo28p69ZU3XRaCbYdP[-2]+'=' in oorcIqYuTf6:
				YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(OOYBCTKMVyFR3lpLNP,'all')
				JaqiYfEglZDvmwQNS8zR = url+'?'+YYwyLpO9f2Do7rztliJ3qFnscT
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,JaqiYfEglZDvmwQNS8zR,351,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,355,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
	return
def kt4gOnZ7y6A0ifpW1L8VJFDaR(fn9dgJ0v1KVrZ,mode):
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.strip('&')
	vJfWILDinBuPZjcUamEHlq = {}
	if '=' in fn9dgJ0v1KVrZ:
		items = fn9dgJ0v1KVrZ.split('&')
		for r1OMYvp0ViTG in items:
			MnwlGZ9Ef3S7kv5sxtzRiFaoCIb,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=')
			vJfWILDinBuPZjcUamEHlq[MnwlGZ9Ef3S7kv5sxtzRiFaoCIb] = B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = Zg9FeADE84jSRIvPCrzYulw3sL
	A7qnSMrihGeFTKZL8zmODNv1U = ['cat','genre','release-year','quality','orderby']
	for key in A7qnSMrihGeFTKZL8zmODNv1U:
		if key in list(vJfWILDinBuPZjcUamEHlq.keys()): B251BPiLbvG9UxszKtlI7YQHmoWw = vJfWILDinBuPZjcUamEHlq[key]
		else: B251BPiLbvG9UxszKtlI7YQHmoWw = '0'
		if mode=='modified_values' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+' + '+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='modified_filters' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='all': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip(' + ')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip('&')
	return PJlIOHanFyNWTgfswRdYXvei4x0Vh
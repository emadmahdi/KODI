# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from V1VREBsj92 import *
bIPsOxjEpoH = JP65RzKaScIf(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨ৞")
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,Tbwq7kJ4vRSNVyUFcdMzirG=Zg9FeADE84jSRIvPCrzYulw3sL):
	if   LfnWDFgRdJH4lZvt7yo28N==yNBjYsgc23xoW(u"࠳೤"): n4Bc25Io1hYFaPeLyiu87dWmtqkz(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠵೥"): pass
	elif LfnWDFgRdJH4lZvt7yo28N==IK4zTnSMyGQpxEaesJAPVDY(u"࠷೦"): Y0YZLJcFOnCMbu5KX3fyIazElsDTN(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==yyZPkLCRX1xcBDN(u"࠹೧"): MKWqT8DBXx9hloRu4OArgmV()
	elif LfnWDFgRdJH4lZvt7yo28N==YXm2qAbu8Qsx(u"࠴೨"): zu4R2bVnZy9PxWkYw(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==yNBjYsgc23xoW(u"࠶೩"): qkK4bcLaDdX()
	elif LfnWDFgRdJH4lZvt7yo28N==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠸೪"): MqDEblLnkBsIeTOoC1YdKhVpW0()
	elif LfnWDFgRdJH4lZvt7yo28N==JP65RzKaScIf(u"࠺೫"): XXmGsWEunBUg63HhLa1VbKr2DfAoy()
	elif LfnWDFgRdJH4lZvt7yo28N==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠼೬"): z8fG9rhaZObFDvVP6Wde7QiTE1LXS()
	elif LfnWDFgRdJH4lZvt7yo28N==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠾೭"): uvVI1sZ5fd8rUKqj3GYxHgF()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠷࠵࠱೮"): hiOuYXzrRlms0jWKvgnqf8SZ1AJoU()
	elif LfnWDFgRdJH4lZvt7yo28N==lU1fSmncFWjizwqZugyYBANML0(u"࠱࠶࠳೯"): x7Reozbsg4Wh09mHINf5Pu2XDCU()
	elif LfnWDFgRdJH4lZvt7yo28N==vGg1hAkzqi8exVbN(u"࠲࠷࠵೰"): AANMVmockjQp1GKwgeJChPr8Tnt()
	elif LfnWDFgRdJH4lZvt7yo28N==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠳࠸࠷ೱ"): XXnW2D7l5OeaIb()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠴࠹࠹ೲ"): qqj6LhEvko4QTO0()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠵࠺࠻ೳ"): ttRY5hjknxy()
	elif LfnWDFgRdJH4lZvt7yo28N==YXm2qAbu8Qsx(u"࠶࠻࠶೴"): leIAjQ0EH8Ykf7uD4sKcZ()
	elif LfnWDFgRdJH4lZvt7yo28N==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠷࠵࠸೵"): Ahp4nrRSlyNeFEPJiL180VfboIzG()
	elif LfnWDFgRdJH4lZvt7yo28N==A2MHFvoqpZ64gNbB(u"࠱࠶࠺೶"): gy07nsfHjoZSQXPce23CDxkwrpB()
	elif LfnWDFgRdJH4lZvt7yo28N==eCpDE6wJtYUHn0GqK5(u"࠲࠷࠼೷"): bbBVcKFz2wAE(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==IK4zTnSMyGQpxEaesJAPVDY(u"࠳࠺࠴೸"): aDlQBLfgIT3mXNG()
	elif LfnWDFgRdJH4lZvt7yo28N==NIBsHMvSXb(u"࠴࠻࠶೹"): XULYcNVBqhPaiEFCpJ4v7KHWG()
	elif LfnWDFgRdJH4lZvt7yo28N==A2MHFvoqpZ64gNbB(u"࠵࠼࠸೺"): JJpOAGQruMNTVz9m([Tbwq7kJ4vRSNVyUFcdMzirG],CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
	elif LfnWDFgRdJH4lZvt7yo28N==UQS9lVew50DIyXrinWsMxTzA(u"࠶࠽࠳೻"): M9ZaLYTqERCo2(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧয়"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==ReLGYUQjz7C9iEd(u"࠷࠷࠵೼"): M9ZaLYTqERCo2(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫৠ"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠱࠸࠷೽"): F6zQ5Vt3MwbadyegPjX8fUBKu()
	elif LfnWDFgRdJH4lZvt7yo28N==vGg1hAkzqi8exVbN(u"࠲࠹࠹೾"): b5VxwQhXNjcTBFu1fzsK()
	elif LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠳࠺࠻೿"): N731NjrhcUKynLJuDAv(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ৡ"))
	elif LfnWDFgRdJH4lZvt7yo28N==E3i1eCBtN2w(u"࠴࠻࠽ഀ"): N731NjrhcUKynLJuDAv(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪৢ"))
	elif LfnWDFgRdJH4lZvt7yo28N==ZYTyoA483N(u"࠵࠼࠿ഁ"): N731NjrhcUKynLJuDAv(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫৣ"))
	elif LfnWDFgRdJH4lZvt7yo28N==ZYTyoA483N(u"࠶࠿࠰ം"): tQzfGpol49XkunWcgqRv7S()
	elif LfnWDFgRdJH4lZvt7yo28N==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠷࠹࠲ഃ"): mVq9Gvb3Iwx5MLUuihXNdfE()
	elif LfnWDFgRdJH4lZvt7yo28N==IYC4iPxkTRUE85namF6(u"࠱࠺࠴ഄ"): gCnvlQV7GH5TcBML0yDjiA46S()
	elif LfnWDFgRdJH4lZvt7yo28N==IYC4iPxkTRUE85namF6(u"࠲࠻࠶അ"): bWCuMBpP6Dm2z()
	elif LfnWDFgRdJH4lZvt7yo28N==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠳࠼࠸ആ"): WfjUdSVIa8z3iBJ6wxy7qZTlr()
	elif LfnWDFgRdJH4lZvt7yo28N==IK4zTnSMyGQpxEaesJAPVDY(u"࠴࠽࠺ഇ"): Otb8RvdK1gP7YrLuaicqwyS()
	elif LfnWDFgRdJH4lZvt7yo28N==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠵࠾࠼ഈ"): J2JRzSVfA6x75rvlW4c()
	elif LfnWDFgRdJH4lZvt7yo28N==yyZPkLCRX1xcBDN(u"࠶࠿࠷ഉ"): AAoLge0P9axSQniGj412()
	elif LfnWDFgRdJH4lZvt7yo28N==IYC4iPxkTRUE85namF6(u"࠷࠹࠹ഊ"): VpuQ7WkxR8HgLrKJdv()
	elif LfnWDFgRdJH4lZvt7yo28N==jozVWcERh91GOF2NHXQiSwKqe8x(u"࠱࠺࠻ഋ"): ZgmE45hw7zc8rGJHvDxa3()
	elif LfnWDFgRdJH4lZvt7yo28N==DKmLTA2yGtj(u"࠴࠶࠳ഌ"): DsHnhlWwx253ANjC97Z(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==jozVWcERh91GOF2NHXQiSwKqe8x(u"࠵࠷࠵഍"): g4OiGUFeMzlQLR0ju()
	elif LfnWDFgRdJH4lZvt7yo28N==x9PULjztJOpu7b(u"࠶࠸࠷എ"): hzOFU4I3iMKbWDCJ5G7xPp()
	elif LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠷࠹࠹ഏ"): nINlvB1O2oexgCTj()
	elif LfnWDFgRdJH4lZvt7yo28N==ZYTyoA483N(u"࠸࠺࠴ഐ"): B5gyMEXhiD9eNw1xjpcv3PAld(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==IYC4iPxkTRUE85namF6(u"࠹࠴࠶഑"): p3pVGvwtKXONrefoBF()
	elif LfnWDFgRdJH4lZvt7yo28N==UQS9lVew50DIyXrinWsMxTzA(u"࠳࠵࠸ഒ"): fGp682jlZSOVvHwMEnmY(vvglE69OFKBm817Nkc)
	elif LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠴࠶࠺ഓ"): vqmnhb5oQRglk0w4u(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠵࠷࠼ഔ"): tIbEcuaA41F95QeCV()
	elif LfnWDFgRdJH4lZvt7yo28N==lU1fSmncFWjizwqZugyYBANML0(u"࠶࠸࠾ക"): yGp3qEvI5PKOJxBCc(x9PULjztJOpu7b(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ৤"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==dn9ouNryjHiBFQOhASvX(u"࠹࠵࠶ഖ"): v4hOxkVRiMNKa3os7pIdwjqteyU()
	elif LfnWDFgRdJH4lZvt7yo28N==ykE045Tatx(u"࠺࠶࠱ഗ"): iiTHtgxACWSkXurJD46nIfLF3Vbj()
	elif LfnWDFgRdJH4lZvt7yo28N==yyZPkLCRX1xcBDN(u"࠻࠰࠳ഘ"): kfouPlW6qH()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠵࠱࠵ങ"): FLgwePHCYufpmN3rOUMEdhnBK7i21G(UbCmKIdEjMa5lr0)
	elif LfnWDFgRdJH4lZvt7yo28N==YXm2qAbu8Qsx(u"࠶࠲࠷ച"): FLgwePHCYufpmN3rOUMEdhnBK7i21G(tJuIjTFl9cwGz2dishvoUm4SPK3ArB)
	elif LfnWDFgRdJH4lZvt7yo28N==A2MHFvoqpZ64gNbB(u"࠷࠳࠹ഛ"): l1jxLHmUN8QSArFtqRZ()
	elif LfnWDFgRdJH4lZvt7yo28N==UixkloZbzGw28ujW56X(u"࠸࠴࠻ജ"): O1o4Qh6m2gWpdP0qwUaFTDMvnEi9yG(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	elif LfnWDFgRdJH4lZvt7yo28N==qdEKO42r3GhwmCDcHtxzJUR(u"࠹࠵࠽ഝ"): Ws2akn0NqhGo8xdZrQLS()
	elif LfnWDFgRdJH4lZvt7yo28N==ee3tnwl7avk(u"࠺࠶࠸ഞ"): qk0AdDtfBeM6rxuVFbzGEyU7Ph()
	elif LfnWDFgRdJH4lZvt7yo28N==JP65RzKaScIf(u"࠻࠰࠺ട"): yEoz2fNehMKgv5jciaRDmw8ptGx7W()
	elif LfnWDFgRdJH4lZvt7yo28N==Vi1oNCM5kI7yJ0(u"࠱࠱࠴࠳ഠ"): vSs4nd3u1PizjktAcMx0DmCoKy()
	elif LfnWDFgRdJH4lZvt7yo28N==x9PULjztJOpu7b(u"࠲࠲࠵࠵ഡ"): oEeCuGA63antqzKX2kp()
	return
def oEeCuGA63antqzKX2kp(MTYBFjy1qmIDuX=vvglE69OFKBm817Nkc):
	JJ5z0Fier2SQyRONG1 = yC2N01GBUPZAD()
	qUCo27rYnFbLGuRmXcIkw = jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭วๅฬื฾๏๊ࠠศๆ็หา่๋ࠠ฻่่ࠬ৥") if JJ5z0Fier2SQyRONG1 else ttC4VURALPYKh(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ็อ์็็ࠧ০")
	KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ১"),JP65RzKaScIf(u"ࠩัีําࠧ২"),E3i1eCBtN2w(u"ࠪษ๏่วโࠩ৩"),UixkloZbzGw28ujW56X(u"ࠫฯฺฺ๋ๆࠪ৪"),dn9ouNryjHiBFQOhASvX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৫"),PPQORjT2lc7SVkKwFI4D+qUCo27rYnFbLGuRmXcIkw+u4IRSmrYMKkaHUBnDiLWh+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+x9PULjztJOpu7b(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭৬"))
	if KPAgkny9rSD0Xdx6CUse1a2LG==Mn5NGAdz6xc42s0: LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(vhZ5qjay1z94JmcMOgXe(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬ৭"))
	elif KPAgkny9rSD0Xdx6CUse1a2LG==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr: LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧ৮"))
	if KPAgkny9rSD0Xdx6CUse1a2LG in [Mn5NGAdz6xc42s0,DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]:
		if NIBsHMvSXb(u"ࠩࡷࡶࡺ࡫ࠧ৯") in str(LUuIzEwBV9Kti6ZXF782): I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ৰ"),UixkloZbzGw28ujW56X(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨৱ"))
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৲"),DKmLTA2yGtj(u"࠭ไๅลึๅࠥอไฺ็็๎ฮࠦแีๆอࠫ৳"))
	return
def vSs4nd3u1PizjktAcMx0DmCoKy():
	url = PhpFa6EdVS[NIBsHMvSXb(u"ࠧࡓࡇࡏࡉࡆ࡙ࡅࡔࠩ৴")][x9PULjztJOpu7b(u"࠲ഢ")]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,JP65RzKaScIf(u"ࠨࡉࡈࡘࠬ৵"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡎࡔࡓࡕࡃࡏࡐࡤࡕࡌࡅࡡࡕࡉࡑࡋࡁࡔࡇ࠰࠵ࡸࡺࠧ৶"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	g9ic1KdEAJqulxUWCo = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠯ࠬࡂ࠭ࠧ࠭৷"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	g9ic1KdEAJqulxUWCo = sorted(g9ic1KdEAJqulxUWCo,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(DKmLTA2yGtj(u"ࠫศิสาࠢส่ส฻ฯศำࠣห้๋ๆศีหࠫ৸"),g9ic1KdEAJqulxUWCo)
	if lqQvOUWodZnhXLS2Vcuj6EtairFN>=E3i1eCBtN2w(u"࠳ണ"):
		IR2UgHdDYn7BlCKFwcm8GZhAk1 = url.rsplit(IK4zTnSMyGQpxEaesJAPVDY(u"ࠬ࠵ࠧ৹"),vGg1hAkzqi8exVbN(u"࠵ത"))[ykE045Tatx(u"࠵ഥ")]+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭࠯ࠨ৺")+g9ic1KdEAJqulxUWCo[lqQvOUWodZnhXLS2Vcuj6EtairFN]
		succeeded = ccvXlqfQCTgbshKmGw64jd2V5(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ৻"),IR2UgHdDYn7BlCKFwcm8GZhAk1,yNBjYsgc23xoW(u"ࡗࡶࡺ࡫൷"))
		if succeeded:
			yUTYoAgth5iC43uLrdBH.setSetting(ee3tnwl7avk(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬৼ"),Zg9FeADE84jSRIvPCrzYulw3sL)
			jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৽"),dn9ouNryjHiBFQOhASvX(u"ࠪฮ๊ࠦสฬสํฮࠥหีะษิࠤ็ี๊ๆࠢ็่อืๆศ็ฯࠤ࠳࠴ࠠๅๅ้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠฤ๊อ์๊อส๋ๅํหࠥฮสฮัํฯࠥาๅ๋฻ࠣห้ฮัศ็ฯࠤออำหะาห๊ࠦยฯำࠣษฺีวา่ࠢฮํ็ัࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣษ๏่วโࠢส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็๋ีอࠠศๆหี๋อๅอࠢยࠥࠦ࠭৾"))
			if jzydmKVUWrCv9D34F: yGp3qEvI5PKOJxBCc(UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ৿"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return
def Ws2akn0NqhGo8xdZrQLS():
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ਀"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳ࠦ็ัษࠣห้๋ำฮࠢึ์ๆ๊ࠦิสหࠤฯำฯ๋อࠣๅํื๊ࠡๆฯ้๏฿ฺ้ࠠสสๆࠦวๅสิ๊ฬ๋ฬࠡษ็ฮ๏ࠦสฺฬ่ำࠥ฿ไ๊่ࠢีํื้ࠠไอࠤ๊฿๊็ࠩਁ"))
	if jzydmKVUWrCv9D34F:
		yUTYoAgth5iC43uLrdBH.setSetting(NIBsHMvSXb(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬਂ"),Zg9FeADE84jSRIvPCrzYulw3sL)
		yUTYoAgth5iC43uLrdBH.setSetting(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨਃ"),Zg9FeADE84jSRIvPCrzYulw3sL)
		yUTYoAgth5iC43uLrdBH.setSetting(IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭਄"),Zg9FeADE84jSRIvPCrzYulw3sL)
		yUTYoAgth5iC43uLrdBH.setSetting(ee3tnwl7avk(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫਅ"),Zg9FeADE84jSRIvPCrzYulw3sL)
		yUTYoAgth5iC43uLrdBH.setSetting(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ਆ"),Zg9FeADE84jSRIvPCrzYulw3sL)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨਇ"),vGg1hAkzqi8exVbN(u"࠭สๆ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰ࠣ์ุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศหฯา๎ะࠦ็ั้ࠣห้หูะษาหฯࠦ࠮࠯๋ࠢว๏฼วࠡฬะำ๏ัฺ้ࠠสสๆࠦวๅสิ๊ฬ๋ฬࠡษ็ฮ๏ࠦสฺฬ่ำࠥ฿ไ๊ࠢส่ํ่สࠨਈ"))
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def yEoz2fNehMKgv5jciaRDmw8ptGx7W():
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,lU1fSmncFWjizwqZugyYBANML0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਉ"),ttC4VURALPYKh(u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥ࠴࠮๊่ࠡืาࠦฬๆ์฼ࠤ๊๊แศฬࠣห้ฮั็ษ่ะࠥอไใัํ้ฮࠦ࠮࠯ࠢ็็๏ฺ๊๊ࠦาࠤฬ๊ศา่ส้ัࠦลๅ๋ࠣัฬ๊ษࠡษ็ูๆืࠠ࠯࠰ࠣ๎฾์๊ࠡฬฯำ๏ีࠠศๆหี๋อๅอ๋ࠢฮฺ็๊า้ࠣ์ํ฼ู่ࠢหัฬ๊ษࠡษ็ฺ้์ูࠡษ็ฮ๏่ࠦื฻๊หࠥอไๆสิ้ัࠦฟࠢࠣࠪਊ"))
	if jzydmKVUWrCv9D34F:
		B5gyMEXhiD9eNw1xjpcv3PAld(vvglE69OFKBm817Nkc)
		eeiLrhbIvwnTuMo89ZOgEkJ(cc6p0YbTjFzgyG3aRw,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ਋"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬ਌"))
	return
def l1jxLHmUN8QSArFtqRZ():
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,YXm2qAbu8Qsx(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ਍"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ਎"))
	z4GsL3bn2eCqB = s7XecJ90gPuFWK5Q8Z(vvglE69OFKBm817Nkc)
	aWsMkVZ5KFSdHmf4GU8 = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	ydBORpZva5tS6skw = U2bWzwG8VdJsBqtR74ErDi3cg1v+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢࠪਏ")+u4IRSmrYMKkaHUBnDiLWh
	DLdmuz32cXYANVCosiOky580 = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫਐ")+u4IRSmrYMKkaHUBnDiLWh+IYC4iPxkTRUE85namF6(u"ࠨ࡞ࡱࡠࡳ࠭਑")
	for id,QrXISV6wyYA,fOQUkxT2FMILJPC,GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe,reason in reversed(z4GsL3bn2eCqB):
		if id==Vi1oNCM5kI7yJ0(u"ࠩ࠳ࠫ਒"):
			kYwphje1QvisNGy3KatEACUo6VB,BBCt692peIHTGrAwd4cWUSDlih5z = GvIoOFAXCU63fVTHK452NEexq.split(qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡠࡳࡁ࠻ࠨਓ"))
			continue
		if aWsMkVZ5KFSdHmf4GU8!=SmFfh9kPpeoNBdcV7WnJ1LHMuXZO: aWsMkVZ5KFSdHmf4GU8 += DLdmuz32cXYANVCosiOky580
		qS5lWUzuCiJjxwyAo1EdtD6nprV = ykE045Tatx(u"ࠫࡠࡘࡔࡍ࡟ࠪਔ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+id+DKmLTA2yGtj(u"ࠬࠦ࠺ࠡࠩਕ")+lU1fSmncFWjizwqZugyYBANML0(u"࠭วๅีวห้ࠦ࠺ࠡࠩਖ")+u4IRSmrYMKkaHUBnDiLWh+fOQUkxT2FMILJPC
		VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨਗ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+ttC4VURALPYKh(u"ࠨษ็ะํอศࠡ࠼ࠣࠫਘ")+u4IRSmrYMKkaHUBnDiLWh+GvIoOFAXCU63fVTHK452NEexq
		i68iLkExJaX = KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨਙ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+E3i1eCBtN2w(u"ࠪห้ิืฤࠢ࠽ࠤࠬਚ")+u4IRSmrYMKkaHUBnDiLWh+XXsladx6CjBzv359u1GSyYpHOe
		JXhn2P97BCK4yN1eWbLv = YXm2qAbu8Qsx(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬਛ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+yyZPkLCRX1xcBDN(u"ࠬอไิสหࠤ࠿ࠦࠧਜ")+u4IRSmrYMKkaHUBnDiLWh+reason
		aWsMkVZ5KFSdHmf4GU8 += qS5lWUzuCiJjxwyAo1EdtD6nprV+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ydBORpZva5tS6skw+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+i68iLkExJaX+JXhn2P97BCK4yN1eWbLv+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	ywuEego16R3ODiKVJr4Yf8qksH0vb(ykE045Tatx(u"࠭ࡲࡪࡩ࡫ࡸࠬਝ"),BBCt692peIHTGrAwd4cWUSDlih5z,aWsMkVZ5KFSdHmf4GU8,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਞ"))
	return
def FLgwePHCYufpmN3rOUMEdhnBK7i21G(file):
	if file==tJuIjTFl9cwGz2dishvoUm4SPK3ArB: zNwjW0b9tneHJCVEBTy = ZYTyoA483N(u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨਟ")
	elif file==UbCmKIdEjMa5lr0: zNwjW0b9tneHJCVEBTy = IYC4iPxkTRUE85namF6(u"ࠩๅ์ฬฬๅࠡฤัีࠥอไโ์า๎ํํวหࠩਠ")
	KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(YXm2qAbu8Qsx(u"ࠪࡧࡪࡴࡴࡦࡴࠪਡ"),E3i1eCBtN2w(u"ู๊ࠫอࠨਢ"),YXm2qAbu8Qsx(u"ࠬหีๅษะࠫਣ"),NIBsHMvSXb(u"࠭ฮา๊ฯࠫਤ"),A2MHFvoqpZ64gNbB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਥ"),NIBsHMvSXb(u"ࠨ้็ࠤฯื๊ะࠢศู้ออࠡ็็ๅࠥ࠭ਦ")+zNwjW0b9tneHJCVEBTy+IYC4iPxkTRUE85namF6(u"ࠩࠣว๊ࠦสา์าࠤู๊อࠡษ็้้็ࠠภࠩਧ"))
	if KPAgkny9rSD0Xdx6CUse1a2LG==qdEKO42r3GhwmCDcHtxzJUR(u"࠶ദ"):
		if brAUlZfdFmt3TRJW2xX4.path.exists(file):
			try: brAUlZfdFmt3TRJW2xX4.remove(file)
			except: pass
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ਨ"),E3i1eCBtN2w(u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩ਩")+zNwjW0b9tneHJCVEBTy)
	elif KPAgkny9rSD0Xdx6CUse1a2LG==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠱ധ"):
		data = wRZbDkg3X6Qhc(file)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨਪ"),ZYTyoA483N(u"࠭สๆࠢศู้ออࠡ็็ๅࠥ࠭ਫ")+zNwjW0b9tneHJCVEBTy)
	return
def iiTHtgxACWSkXurJD46nIfLF3Vbj():
	if NGiBmYp8vX9T426lHn7ue<IK4zTnSMyGQpxEaesJAPVDY(u"࠲࠺ന"):
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧๅๆฦืๆࠦร็ฬࠣฮุะฮะ็ࠣษฺีวาࠢๆ์ิ๐ࠠใัํ้ࠥืโๆࠢࠪਬ")+str(NGiBmYp8vX9T426lHn7ue)+ReLGYUQjz7C9iEd(u"ࠨ๋่ࠢ์ึวࠡษ็ๆํอฦๆࠢส่๊฻่าห่ࠣฬࠦสฺ็็ࠤ฾์ฯไࠢ࠱ࠤ์ึ็ࠡษ็้๏ุษࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠢ࠱ࠤ้หีๅษะࠤฬ๊ๅีๅ็อ่ࠥๅࠡสอัิ๐หࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦลๅ๋ࠣษ๏ࠦลึัสีࠥืโๆ้ࠣว฾๊้ࠡ็้ࠤ࠶࠾࠮࠱ࠩਭ")
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬਮ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
		return
	thz5sHXldkV3L = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(ttC4VURALPYKh(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ਯ"))
	BchiTO0Hae9m6l4E1F = DUlT4qMG5tQd([OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪਰ")])
	mHLBF2Mogbt7rWsCQ,DZG305BTcPXN6iA1Jy4wRhg,mW4sqXwxMZd1Q5o2RBDayiLpT,WZzO9cDrxsneRdG1uvlwYALf,Y9w5gi1rdGhb8kJRAclszDqj,SGEH3fth7ogXC9MVswdarPq,XrRcZnIBiU1D3 = BchiTO0Hae9m6l4E1F[ee3tnwl7avk(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ਱")]
	if mHLBF2Mogbt7rWsCQ or UixkloZbzGw28ujW56X(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬਲ") not in str(thz5sHXldkV3L):
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਲ਼"),Vi1oNCM5kI7yJ0(u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭਴"))
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = kfouPlW6qH()
		if not oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: return
	tSkIvmyY4P(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return
def tSkIvmyY4P(showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	thz5sHXldkV3L = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(x9PULjztJOpu7b(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬਵ"))
	if yyZPkLCRX1xcBDN(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩਸ਼") not in str(thz5sHXldkV3L):
		if showDialogs:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ਷"),DKmLTA2yGtj(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪਸ"))
		return
	BBOmAv8IVMNyDz1kxaXRULejtl2Z = brAUlZfdFmt3TRJW2xX4.path.join(C8ik4xAOE2Y53qZRJy6nbUVm,A2MHFvoqpZ64gNbB(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ਹ"),JP65RzKaScIf(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭਺"),x9PULjztJOpu7b(u"ࠨ࠹࠵࠴ࡵ࠭਻"),lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮਼ࠪ"))
	if not brAUlZfdFmt3TRJW2xX4.path.exists(BBOmAv8IVMNyDz1kxaXRULejtl2Z): return
	EXmDZJu7BtVLwj4 = open(BBOmAv8IVMNyDz1kxaXRULejtl2Z,E3i1eCBtN2w(u"ࠪࡶࡧ࠭਽")).read()
	if GGfPQnrJKEqMv2ZVxdD: EXmDZJu7BtVLwj4 = EXmDZJu7BtVLwj4.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	LKBirAUTzh8f5sgecVOXa9vPjt = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫਾ"),EXmDZJu7BtVLwj4,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	yVadACeYbioWnhUfOE8DFH,ddb0mR1pvIa2eg5DFPEMynf = LKBirAUTzh8f5sgecVOXa9vPjt[UwCT5Oz6Wo0BP]
	LDP0TFzSb5Q82M31vhYdt9H = eCpDE6wJtYUHn0GqK5(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭ਿ")+yVadACeYbioWnhUfOE8DFH+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࠬࠨੀ")+ddb0mR1pvIa2eg5DFPEMynf+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩੁ")
	if showDialogs:
		fftCBdeULy6vZzN = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(x9PULjztJOpu7b(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭ੂ"))
		if fftCBdeULy6vZzN==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ੃"): AihfLS072gGKwl = A2MHFvoqpZ64gNbB(u"ࠪๆํอฦๆࠢส่่ะวษหࠪ੄")
		elif fftCBdeULy6vZzN==UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ੅"): AihfLS072gGKwl = qdEKO42r3GhwmCDcHtxzJUR(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ੆")
		else: AihfLS072gGKwl = vGg1hAkzqi8exVbN(u"࠭โ้ษษ้ࠥษฮา๋ࠪੇ")
		KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(E3i1eCBtN2w(u"ࠧࡤࡧࡱࡸࡪࡸࠧੈ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠨไ๋หห๋ࠠฤะิํࠬ੉"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ੊"),UQS9lVew50DIyXrinWsMxTzA(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨੋ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨੌ")+AihfLS072gGKwl,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨ੍")+U2bWzwG8VdJsBqtR74ErDi3cg1v+YXm2qAbu8Qsx(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪ੎")+u4IRSmrYMKkaHUBnDiLWh)
		if KPAgkny9rSD0Xdx6CUse1a2LG==E3i1eCBtN2w(u"࠳ഩ"): kk1TItZQmYBMU = vGg1hAkzqi8exVbN(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ੏")
		elif KPAgkny9rSD0Xdx6CUse1a2LG==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠵പ"): kk1TItZQmYBMU = x9PULjztJOpu7b(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ੐")
		else: kk1TItZQmYBMU = Zg9FeADE84jSRIvPCrzYulw3sL
	else:
		fftCBdeULy6vZzN = yUTYoAgth5iC43uLrdBH.getSetting(NIBsHMvSXb(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧੑ"))
		if   fftCBdeULy6vZzN==Zg9FeADE84jSRIvPCrzYulw3sL: KPAgkny9rSD0Xdx6CUse1a2LG = yNBjYsgc23xoW(u"࠴ഫ")
		elif fftCBdeULy6vZzN==yNBjYsgc23xoW(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭੒"): KPAgkny9rSD0Xdx6CUse1a2LG = wFYiVd4r12x7CAQBL5SPof(u"࠶ബ")
		elif fftCBdeULy6vZzN==IYC4iPxkTRUE85namF6(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ੓"): KPAgkny9rSD0Xdx6CUse1a2LG = IYC4iPxkTRUE85namF6(u"࠸ഭ")
		kk1TItZQmYBMU = fftCBdeULy6vZzN
	if   KPAgkny9rSD0Xdx6CUse1a2LG==okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠰മ"): pumlvUKLRgV7sdMSqabjG = wFYiVd4r12x7CAQBL5SPof(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩ੔")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==vv3sNE8XCU2RAiyVaueTbD950pz(u"࠲യ"): pumlvUKLRgV7sdMSqabjG = yyZPkLCRX1xcBDN(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪ੕")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==vhZ5qjay1z94JmcMOgXe(u"࠴ര"): pumlvUKLRgV7sdMSqabjG = x9PULjztJOpu7b(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫ੖")
	else: return
	yUTYoAgth5iC43uLrdBH.setSetting(A2MHFvoqpZ64gNbB(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭੗"),kk1TItZQmYBMU)
	lbK5EP46TAwSQ = ttC4VURALPYKh(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ੘")+pumlvUKLRgV7sdMSqabjG+vGg1hAkzqi8exVbN(u"ࠪ࠰ࠬਖ਼")+ddb0mR1pvIa2eg5DFPEMynf+vhZ5qjay1z94JmcMOgXe(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ਗ਼")
	jd3r4eqQKWnYAGEJtDoy = EXmDZJu7BtVLwj4.replace(LDP0TFzSb5Q82M31vhYdt9H,lbK5EP46TAwSQ)
	if GGfPQnrJKEqMv2ZVxdD: jd3r4eqQKWnYAGEJtDoy = jd3r4eqQKWnYAGEJtDoy.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	open(BBOmAv8IVMNyDz1kxaXRULejtl2Z,E3i1eCBtN2w(u"ࠬࡽࡢࠨਜ਼")).write(jd3r4eqQKWnYAGEJtDoy)
	zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫੜ")+pumlvUKLRgV7sdMSqabjG+lU1fSmncFWjizwqZugyYBANML0(u"ࠧࠡ࡟ࠪ੝"))
	if showDialogs: Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧਫ਼"))
	return
def v4hOxkVRiMNKa3os7pIdwjqteyU():
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ੟"),ttC4VURALPYKh(u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨ੠"))
	if jzydmKVUWrCv9D34F==Vi1oNCM5kI7yJ0(u"࠴റ"): XXmGsWEunBUg63HhLa1VbKr2DfAoy()
	return
def z8fG9rhaZObFDvVP6Wde7QiTE1LXS():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ੡"),IYC4iPxkTRUE85namF6(u"ࠬํะศࠢส่๊๎โฺ่ࠢ฾้่ࠠๆ่ࠣห้๋ีะำࠣ์฿๐ัࠡ็฼ีํ็ࠠๆฬํࠤ๏ืฬฺࠢ็่฾๋ไࠨ੢"))
	return
def tIbEcuaA41F95QeCV():
	qS5lWUzuCiJjxwyAo1EdtD6nprV = U2bWzwG8VdJsBqtR74ErDi3cg1v+x9PULjztJOpu7b(u"࠭สฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢࠪ੣")+u4IRSmrYMKkaHUBnDiLWh
	qS5lWUzuCiJjxwyAo1EdtD6nprV += NIBsHMvSXb(u"ࠧศๆ่์็฿ࠠฤั้ห์ࠦแ๋้ࠣษา฻วว์ฬࠤ้฿ฯะࠢสู่๐ูสࠢไ๎ࠥอไฺษ็้ࠥะๅࠡฮ่฽์อࠠๆ่ࠣะ๊๐ูࠡษ็ฺ้อฯาࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่็ี๊ๆหࠣ์ฬ๊ฬะ์าอࠥอไฮๅ๋้๏ฯ้ࠠษ็฾๏ืࠠฮๅ๋้๏ฯ้ࠠ็้ࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊ࠦหๆࠢอ้ࠥะ่ฮ์า๋ฬ่ࠦฮีสฬࠥอไๆ฻า่ࠥำำษࠢึ็ฬ์ࠠะ๊็ࠤฬู๊ศๆ่ࠤู้ๆสࠢ࠵࠴࠷࠷้้ࠠํࠤฬ๊ลฮืสส๏ฯࠠศๆฦัิั้ࠠษ็วู๋ไࠡษ็ฮ๏ࠦสๆࠢ฼้้ํวࠡใํࠤฬ๊ำ็๊สฮࠥอไฺึิอࠥอไๆษู๎ฮ࠭੤")
	qS5lWUzuCiJjxwyAo1EdtD6nprV += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡷ࡭࡯ࡡࡤࡱࡸࡲࡹ࠭੥")+u4IRSmrYMKkaHUBnDiLWh
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = U2bWzwG8VdJsBqtR74ErDi3cg1v+ReLGYUQjz7C9iEd(u"ࠩหี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢࠪ੦")+u4IRSmrYMKkaHUBnDiLWh
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += NIBsHMvSXb(u"๋ࠪํูࠦษษิอࠥ฿ๆࠡสิ๊ฬ๋ฬࠡ์๋ๅึࠦๅฺๆ๋้ฬะࠠฮีสฬ๏ฯࠠไอํีฮࠦส่็ࠣะ๊๐ูࠡษ็ุ้๊ๅ๋่้ࠣะ๊ࠠฤ๊ๅหฯࠦวๅื็หฮ่ࠦฤ๊ๅหฯࠦวๅๅึ์ๆ่ࠦศๆัืํ็้ࠠึๆ่ࠥอไใ็ิࠤํษ่ใษอࠤฬ๊โๆำࠣ์ศ๐ึศࠢํ์ๆืࠠาฦํอࠥอไ่ๆส่ࠥ็๊ࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣ์ศ๐ึศࠢไ๎์ࠦสใ๊ํ้๋๊ࠥๅษา๎ࠥ๎็อำํࠤํ็๊่ࠢฦ๎฻อࠠษฯฮࠤํ่ัศรฬࠤฬ๊โาฤ้ࠤํษ๊ืษࠣๅ๏ํࠠศีอาฬืษ๊ࠡอๅฬสไ๊ࠡไ๎์ࠦรใ๊ส่๋ࠥๆิ๊หอ๊ࠥไฤ็ส้ࠥ฿ไ๋๋ࠢว๊๎ัࠡลัี๎ࠦส่็ࠣ็้ࠦๅิๆ่ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ็ๆฮํฮࠠษๆ฽อࠥาวโษࠣื่ืศห๋ࠢ๎ุะฮะ็๊ࠣ฽อๅ๊ࠡํ๊ิ๎าࠡฬะฮࠥฮ๊วหࠣ์๏์ฯ้ิࠣ็ฬา๊ห๋้ࠢำ฻ีࠡใๅ฻๊ࠥรอ้ีอࠥอไ้์้ำํุࠠ࠯ࠢส่๊๎โฺࠢส่ึูๅ๋ࠢ็่อืๆศ็ฯࠤ์๎ࠧ੧")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+A2MHFvoqpZ64gNbB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡭ࡶࡵ࡯࡭ࡲࡸࡵ࡭ࡧࡵࠫ੨")+u4IRSmrYMKkaHUBnDiLWh
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = UQS9lVew50DIyXrinWsMxTzA(u"ࠬࡡࡒࡕࡎࡠࠫ੩")+qS5lWUzuCiJjxwyAo1EdtD6nprV+vhZ5qjay1z94JmcMOgXe(u"࠭࡜࡯࡞ࡱࡠࡳࡡࡒࡕࡎࡠࠫ੪")+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6
	ywuEego16R3ODiKVJr4Yf8qksH0vb(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭੫"),Zg9FeADE84jSRIvPCrzYulw3sL,oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def fGp682jlZSOVvHwMEnmY(k2x5IYN9dH1FfSytmDMEGChLsX):
	HsN3gRJ1Z9ahWqTPwj(FFP5vTqk3nDlEuGdIy)
	z4GsL3bn2eCqB = s7XecJ90gPuFWK5Q8Z(k2x5IYN9dH1FfSytmDMEGChLsX)
	FajoeBMP8wQp3RyVUXbvrDtT6nc0z(ee3tnwl7avk(u"ࠨࡆࡒࡒࡆ࡚ࡉࡐࡐࡖࠫ੬"))
	id,QrXISV6wyYA,fOQUkxT2FMILJPC,GvIoOFAXCU63fVTHK452NEexq,XXsladx6CjBzv359u1GSyYpHOe,reason = z4GsL3bn2eCqB[UwCT5Oz6Wo0BP]
	kYwphje1QvisNGy3KatEACUo6VB,BBCt692peIHTGrAwd4cWUSDlih5z = GvIoOFAXCU63fVTHK452NEexq.split(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ࡟ࡲࡀࡁࠧ੭"))
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6,i68iLkExJaX,JXhn2P97BCK4yN1eWbLv = XXsladx6CjBzv359u1GSyYpHOe.split(ReLGYUQjz7C9iEd(u"ࠪࡠࡳࡁ࠻ࠨ੮"))
	sqLt82pWwfNROx5lm = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	while sqLt82pWwfNROx5lm:
		el5yuk30qs2JNfV1GAMF = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠫำื่อࠩ੯"),DKmLTA2yGtj(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫੰ"),UQS9lVew50DIyXrinWsMxTzA(u"࠭โศศ่อࠥอไหสิ฽ฬะࠧੱ"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧੲ"),VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6)
		if el5yuk30qs2JNfV1GAMF==x9PULjztJOpu7b(u"࠶ല"): JVoF294dXte70BTsb3A = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨ฻๋ำฮ࠭ੳ"),Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"่ࠩฬิษࠠศๆอฬึ฿ࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩੴ"),i68iLkExJaX,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧੵ"))
		elif el5yuk30qs2JNfV1GAMF==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠶ള"): Y0YZLJcFOnCMbu5KX3fyIazElsDTN()
		else: sqLt82pWwfNROx5lm = vvglE69OFKBm817Nkc
	if k2x5IYN9dH1FfSytmDMEGChLsX: i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def B5gyMEXhiD9eNw1xjpcv3PAld(showDialogs):
	jzydmKVUWrCv9D34F = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if showDialogs: jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ੶"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ูࠬฤศๆࠪ੷"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧ੸"))
	if jzydmKVUWrCv9D34F:
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if brAUlZfdFmt3TRJW2xX4.path.exists(jtQuVIH1qNd6W7Mg0BYfULe5Zln):
			try: brAUlZfdFmt3TRJW2xX4.remove(jtQuVIH1qNd6W7Mg0BYfULe5Zln)
			except: oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
		if showDialogs:
			if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,E3i1eCBtN2w(u"ࠧห็ࠣฬ๋าวฮ่ࠢืา่ࠦหืไ๎ึࠦๅๅใࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ੹"))
			else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨ੺"))
	return
def p3pVGvwtKXONrefoBF():
	tQzfGpol49XkunWcgqRv7S()
	cfDGqNno0tsldhreR7ibCgI = yUTYoAgth5iC43uLrdBH.getSetting(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ੻"))
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = {}
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡅ࡚࡚ࡏࠨ੼")] = JP65RzKaScIf(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪ੽")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[UQS9lVew50DIyXrinWsMxTzA(u"࡙ࠬࡔࡐࡒࠪ੾")] = ee3tnwl7avk(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ੿")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ઀")] = yyZPkLCRX1xcBDN(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩઁ")+str(KeJnzmh3VI4jRfC6Bgy0L/ReLGYUQjz7C9iEd(u"࠼࠰ഴ"))+ee3tnwl7avk(u"ࠩࠣำ็๐โสࠢไๆ฼࠭ં")
	CMo1yiSNldsAr9 = oHkimLnwDKNxlheUuGAMQIg9jY7dz[cfDGqNno0tsldhreR7ibCgI]
	KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠪ็ฬฺࠠࠨઃ")+str(KeJnzmh3VI4jRfC6Bgy0L/jozVWcERh91GOF2NHXQiSwKqe8x(u"࠶࠱വ"))+IK4zTnSMyGQpxEaesJAPVDY(u"ࠫࠥีโ๋ไฬࠫ઄"),UixkloZbzGw28ujW56X(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫઅ"),IK4zTnSMyGQpxEaesJAPVDY(u"࠭ล๋ไสๅ้ࠥวๆๆࠪઆ"),CMo1yiSNldsAr9,NIBsHMvSXb(u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪઇ"))
	if KPAgkny9rSD0Xdx6CUse1a2LG==wFYiVd4r12x7CAQBL5SPof(u"࠱ശ"): PazEutSe205xFLXk6OhJfWdscworBK = dn9ouNryjHiBFQOhASvX(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩઈ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==UQS9lVew50DIyXrinWsMxTzA(u"࠳ഷ"): PazEutSe205xFLXk6OhJfWdscworBK = YXm2qAbu8Qsx(u"ࠩࡄ࡙࡙ࡕࠧઉ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==qdEKO42r3GhwmCDcHtxzJUR(u"࠵സ"): PazEutSe205xFLXk6OhJfWdscworBK = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡗ࡙ࡕࡐࠨઊ")
	else: PazEutSe205xFLXk6OhJfWdscworBK = Zg9FeADE84jSRIvPCrzYulw3sL
	if PazEutSe205xFLXk6OhJfWdscworBK:
		yUTYoAgth5iC43uLrdBH.setSetting(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪઋ"),PazEutSe205xFLXk6OhJfWdscworBK)
		XXCwsFQvOYE9oGdUt = oHkimLnwDKNxlheUuGAMQIg9jY7dz[PazEutSe205xFLXk6OhJfWdscworBK]
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,XXCwsFQvOYE9oGdUt)
	return
def nINlvB1O2oexgCTj():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = {}
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬࡇࡕࡕࡑࠪઌ")] = UixkloZbzGw28ujW56X(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢส่ฯ๊โศศํࠤ๏฿ๅๅ࠼ࠣࠫઍ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[vhZ5qjay1z94JmcMOgXe(u"ࠧࡂࡕࡎࠫ઎")] = IYC4iPxkTRUE85namF6(u"ࠨีํีๆืࠠࡅࡐࡖࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้࠽ࠤࠬએ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[YXm2qAbu8Qsx(u"ࠩࡖࡘࡔࡖࠧઐ")] = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪื๏ืแาࠢࡇࡒࡘࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭ઑ")
	nn2q6Mmb4VPeEjocdwA10OZ5LgIu = yUTYoAgth5iC43uLrdBH.getSetting(YXm2qAbu8Qsx(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫ઒"))
	cfDGqNno0tsldhreR7ibCgI = yUTYoAgth5iC43uLrdBH.getSetting(ykE045Tatx(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨઓ"))
	CMo1yiSNldsAr9 = oHkimLnwDKNxlheUuGAMQIg9jY7dz[cfDGqNno0tsldhreR7ibCgI]+nn2q6Mmb4VPeEjocdwA10OZ5LgIu
	KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫઔ"),ykE045Tatx(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ક"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨวํๆฬ็ࠠไษ่่ࠬખ"),CMo1yiSNldsAr9,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭ગ"))
	if KPAgkny9rSD0Xdx6CUse1a2LG==ReLGYUQjz7C9iEd(u"࠴ഹ"): PazEutSe205xFLXk6OhJfWdscworBK = ttC4VURALPYKh(u"ࠪࡅࡘࡑࠧઘ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==yyZPkLCRX1xcBDN(u"࠶ഺ"): PazEutSe205xFLXk6OhJfWdscworBK = YXm2qAbu8Qsx(u"ࠫࡆ࡛ࡔࡐࠩઙ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==ReLGYUQjz7C9iEd(u"࠸഻"): PazEutSe205xFLXk6OhJfWdscworBK = vv3sNE8XCU2RAiyVaueTbD950pz(u"࡙ࠬࡔࡐࡒࠪચ")
	if KPAgkny9rSD0Xdx6CUse1a2LG in [vGg1hAkzqi8exVbN(u"࠱ഽ"),ReLGYUQjz7C9iEd(u"࠱഼")]:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(vGg1hAkzqi8exVbN(u"࠭ࡣࡦࡰࡷࡩࡷ࠭છ"),x9PULjztJOpu7b(u"ࠧิ์ิๅึࡀࠠࠨજ")+JYCuTUrNh3[Mn5NGAdz6xc42s0],dn9ouNryjHiBFQOhASvX(u"ࠨีํีๆื࠺ࠡࠩઝ")+JYCuTUrNh3[UwCT5Oz6Wo0BP],Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨઞ"))
		if jzydmKVUWrCv9D34F==vhZ5qjay1z94JmcMOgXe(u"࠳ാ"): DEYMzbJiWO6ehqZupNP9dS7AjLmHf = JYCuTUrNh3[UwCT5Oz6Wo0BP]
		else: DEYMzbJiWO6ehqZupNP9dS7AjLmHf = JYCuTUrNh3[Mn5NGAdz6xc42s0]
	elif KPAgkny9rSD0Xdx6CUse1a2LG==UQS9lVew50DIyXrinWsMxTzA(u"࠵ി"): DEYMzbJiWO6ehqZupNP9dS7AjLmHf = Zg9FeADE84jSRIvPCrzYulw3sL
	else: PazEutSe205xFLXk6OhJfWdscworBK = Zg9FeADE84jSRIvPCrzYulw3sL
	if PazEutSe205xFLXk6OhJfWdscworBK:
		yUTYoAgth5iC43uLrdBH.setSetting(vGg1hAkzqi8exVbN(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ટ"),PazEutSe205xFLXk6OhJfWdscworBK)
		yUTYoAgth5iC43uLrdBH.setSetting(IYC4iPxkTRUE85namF6(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫઠ"),DEYMzbJiWO6ehqZupNP9dS7AjLmHf)
		XXCwsFQvOYE9oGdUt = oHkimLnwDKNxlheUuGAMQIg9jY7dz[PazEutSe205xFLXk6OhJfWdscworBK]+DEYMzbJiWO6ehqZupNP9dS7AjLmHf
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,XXCwsFQvOYE9oGdUt)
	return
def hzOFU4I3iMKbWDCJ5G7xPp():
	cfDGqNno0tsldhreR7ibCgI = yUTYoAgth5iC43uLrdBH.getSetting(ee3tnwl7avk(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪડ"))
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = {}
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[vhZ5qjay1z94JmcMOgXe(u"࠭ࡁࡖࡖࡒࠫઢ")] = UixkloZbzGw28ujW56X(u"ࠧศๆหีํ้ำ๋ࠢส่ฯ๊โศศํࠤัอ็ำࠢ็่฾๋ไࠨણ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡃࡖࡏࠬત")] = vGg1hAkzqi8exVbN(u"ࠩส่อื่ไีํࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้ࠪથ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz[ZYTyoA483N(u"ࠪࡗ࡙ࡕࡐࠨદ")] = vGg1hAkzqi8exVbN(u"ࠫฬ๊ศา๊ๆื๏ࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭ધ")
	CMo1yiSNldsAr9 = oHkimLnwDKNxlheUuGAMQIg9jY7dz[cfDGqNno0tsldhreR7ibCgI]
	KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪન"),qdEKO42r3GhwmCDcHtxzJUR(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ઩"),vGg1hAkzqi8exVbN(u"ࠧฦ์ๅหๆࠦใศ็็ࠫપ"),CMo1yiSNldsAr9,ee3tnwl7avk(u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫફ"))
	if KPAgkny9rSD0Xdx6CUse1a2LG==IK4zTnSMyGQpxEaesJAPVDY(u"࠴ീ"): PazEutSe205xFLXk6OhJfWdscworBK = NIBsHMvSXb(u"ࠩࡄࡗࡐ࠭બ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==IK4zTnSMyGQpxEaesJAPVDY(u"࠶ു"): PazEutSe205xFLXk6OhJfWdscworBK = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡅ࡚࡚ࡏࠨભ")
	elif KPAgkny9rSD0Xdx6CUse1a2LG==zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠸ൂ"): PazEutSe205xFLXk6OhJfWdscworBK = YXm2qAbu8Qsx(u"ࠫࡘ࡚ࡏࡑࠩમ")
	else: PazEutSe205xFLXk6OhJfWdscworBK = Zg9FeADE84jSRIvPCrzYulw3sL
	if PazEutSe205xFLXk6OhJfWdscworBK:
		yUTYoAgth5iC43uLrdBH.setSetting(lU1fSmncFWjizwqZugyYBANML0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪય"),PazEutSe205xFLXk6OhJfWdscworBK)
		XXCwsFQvOYE9oGdUt = oHkimLnwDKNxlheUuGAMQIg9jY7dz[PazEutSe205xFLXk6OhJfWdscworBK]
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,XXCwsFQvOYE9oGdUt)
	return
def qk0AdDtfBeM6rxuVFbzGEyU7Ph():
	qS4sWeQTcG3Ujl5d7CXY9xtMyR = yUTYoAgth5iC43uLrdBH.getSetting(yyZPkLCRX1xcBDN(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ર"))
	if qS4sWeQTcG3Ujl5d7CXY9xtMyR==eCpDE6wJtYUHn0GqK5(u"ࠧࡔࡖࡒࡔࠬ઱"): header = Vi1oNCM5kI7yJ0(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧલ")
	else: header = ttC4VURALPYKh(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧળ")
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠪษ๏่วโࠩ઴"),ReLGYUQjz7C9iEd(u"ࠫฯ็ู๋ๆࠪવ"),header,ZYTyoA483N(u"่่ࠬศศ่ࠤฬ๊ศา่ส้ั๊ࠦห็ࠣฮาี๊ฬ้สࠤศ๎ส้็สฮ๏้๊ศࠢห฽ิࠦ࠱࠷ࠢึห฾ฯࠠๆ่ࠣวํ๊ࠠฤีอาิอๅࠡ࠰࠱ࠤํห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠤ๏สฯ๋ࠢศ่๎ࠦสฮัํฯ์อࠠโ์ࠣ็้ࠦๅาหࠣ๎ฯ๋ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎็ัษࠣ๎ุฮศࠡสฺสࠥ็๊ࠡใอั่่ࠥศศ่ࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩશ"))
	if jzydmKVUWrCv9D34F==-DKmLTA2yGtj(u"࠱ൃ"): return
	elif jzydmKVUWrCv9D34F:
		yUTYoAgth5iC43uLrdBH.setSetting(Vi1oNCM5kI7yJ0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ષ"),UixkloZbzGw28ujW56X(u"ࠧࡂࡗࡗࡓࠬસ"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫહ"),dn9ouNryjHiBFQOhASvX(u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫ઺"))
	else:
		yUTYoAgth5iC43uLrdBH.setSetting(ttC4VURALPYKh(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ઻"),lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡘ࡚ࡏࡑ઼ࠩ"))
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨઽ"),vhZ5qjay1z94JmcMOgXe(u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨા"))
	return
def n4Bc25Io1hYFaPeLyiu87dWmtqkz(Tbwq7kJ4vRSNVyUFcdMzirG):
	if Tbwq7kJ4vRSNVyUFcdMzirG!=Zg9FeADE84jSRIvPCrzYulw3sL:
		Tbwq7kJ4vRSNVyUFcdMzirG = VikRx6TtEdzKFbBoeOHpSvg7PLlq(Tbwq7kJ4vRSNVyUFcdMzirG)
		Tbwq7kJ4vRSNVyUFcdMzirG = Tbwq7kJ4vRSNVyUFcdMzirG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc).encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		F9beXQjL6grmcWOdfJkN8S17PwE5 = ee3tnwl7avk(u"࠲࠲࠴࠴࠸ൄ")
		LLR7anYON6lK8mcuyv = HqjWaYEzp0D8eyQRud.Window(F9beXQjL6grmcWOdfJkN8S17PwE5)
		LLR7anYON6lK8mcuyv.getControl(wFYiVd4r12x7CAQBL5SPof(u"࠵࠴࠵൅")).setLabel(Tbwq7kJ4vRSNVyUFcdMzirG)
	return
HH03KfSzbVRAOZ2hn9Xx5MoPr = [
			 A2MHFvoqpZ64gNbB(u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵ࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧિ")
			,UixkloZbzGw28ujW56X(u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫી")
			,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫુ")
			,vv3sNE8XCU2RAiyVaueTbD950pz(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬૂ")
			,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬૃ")
			,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧૄ")
			,UQS9lVew50DIyXrinWsMxTzA(u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠬૅ")+UixkloZbzGw28ujW56X(u"ࠧࠤࠩ૆")+yNBjYsgc23xoW(u"ࠨࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧે")
			,A2MHFvoqpZ64gNbB(u"ࠩࡌࡲࡸ࡫ࡣࡶࡴࡨࡖࡪࡷࡵࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪ࠰ࠬૈ")
			,YXm2qAbu8Qsx(u"ࠪࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࠳ࡄࡳ࡯ࡥࡧࡨࡁ࠵ࠬࡴࡦࡺࡷࡸࡂ࠭ૉ")
			,ZYTyoA483N(u"ࠫࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠴ࡷࡢࡴࡱࠬࠬ૊")
			,ReLGYUQjz7C9iEd(u"ࠬࡤ࡞࡟ࡠࡡࠫો")
			,ttC4VURALPYKh(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫૌ")
			]
def xx0asIfKtiA71zw(Eh9DwNXB3LFnz1P):
	if NIBsHMvSXb(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾્ࠬ") in Eh9DwNXB3LFnz1P and eCpDE6wJtYUHn0GqK5(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭૎") in Eh9DwNXB3LFnz1P: return CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	for Tbwq7kJ4vRSNVyUFcdMzirG in HH03KfSzbVRAOZ2hn9Xx5MoPr:
		if Tbwq7kJ4vRSNVyUFcdMzirG in Eh9DwNXB3LFnz1P: return CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	return vvglE69OFKBm817Nkc
def doiuzLQNmIKMtljBEnscYP8pe25xg(data):
	xMpYs7ySVfUCd45F1 = ee3tnwl7avk(u"࠻േ") if GGfPQnrJKEqMv2ZVxdD else x9PULjztJOpu7b(u"࠴࠹െ")
	data = data.replace(JP65RzKaScIf(u"࠸࠶ൈ")*wjs26GpVfNiCUERHJ,xMpYs7ySVfUCd45F1*wjs26GpVfNiCUERHJ)
	data = data.replace(KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠩࠣࡀ࡬࡫࡮ࡦࡴࡤࡰࡃࡀࠠࠨ૏"),eCpDE6wJtYUHn0GqK5(u"ࠪ࠾ࠥ࠭ૐ"))
	mrn4jdBuXKIw7N2lvh = Zg9FeADE84jSRIvPCrzYulw3sL
	for Eh9DwNXB3LFnz1P in data.splitlines():
		WNzxEJUAd9abSh64iR1OTGQc7vY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ૑"),Eh9DwNXB3LFnz1P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if WNzxEJUAd9abSh64iR1OTGQc7vY: Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(WNzxEJUAd9abSh64iR1OTGQc7vY[UwCT5Oz6Wo0BP],Zg9FeADE84jSRIvPCrzYulw3sL)
		mrn4jdBuXKIw7N2lvh += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+Eh9DwNXB3LFnz1P
	return mrn4jdBuXKIw7N2lvh
def DsHnhlWwx253ANjC97Z(qBmO284szSf6GW):
	if E3i1eCBtN2w(u"ࠬࡕࡌࡅࠩ૒") in qBmO284szSf6GW:
		Pnu5ZERDvijT = FbSejdADVtON1rKaI
		header = Vi1oNCM5kI7yJ0(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭૓")
	else:
		Pnu5ZERDvijT = jKNw370SdFlQ
		header = yNBjYsgc23xoW(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧ૔")
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,header,yNBjYsgc23xoW(u"ࠨีฯ่ࠥอไฤะฺหฦ๊ࠦฮฬ๋๎ࠥษ๊ืษࠣ฽้๏ࠠิฮ็ࠤฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢห้อห็์้ࠤ฻ื่า์ฬࠤู้๋าใฬࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯ้ࠠ็สࠤ์๎ࠠศๆ่็ฬ์ࠠศๆำ๎ูࠥศษࠢะำํัࠠศๆุ่่๊ษࠡ࠰ࠣ็ํี๊ࠡ์ะฮๆ฾ࠠษีฯ่๏์ࠠ࠯ࠢส่ศ๎ไ้๋ࠡࠤฬ๊ำอๆࠣห้ำวๅ์ࠣ์ๆ๐็ࠡ็฼่ํ๋วหࠢอฬิษࠠๆ่ำࠤอีว๋หࠣห้ะิ฻์็ࠤฬ๊อศๆํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์ฬ๊้ࠡษ็ฦ๋ࠦ࠮ࠡล่หࠥอไิฮ็ࠤฬ๊โะ์่ࠤๆํ่ࠡษ็ืั๊ࠠศๆึหอ่ࠠศๆำ๎ࠥะๅࠡฮ่฽์ࠦๅ็ࠢหี๋อๅอࠢๆ์ิ๐ࠠใส็ࠤวิัࠡวฺๅฬวࠠๅ้ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠫ૕"))
	if jzydmKVUWrCv9D34F!=ttC4VURALPYKh(u"࠷൉"): return
	GOWk750EPypAfloNXZBHD,dQT46gLOHsewaMC7iAxp3KBIb1N0 = [],vGg1hAkzqi8exVbN(u"࠰ൊ")
	size,count = M0VZ1cU2uDToibE6yj37RzCxkX5L(Pnu5ZERDvijT)
	file = open(Pnu5ZERDvijT,ZYTyoA483N(u"ࠩࡵࡦࠬ૖"))
	if size>ttC4VURALPYKh(u"࠳࠳࠴࠷࠶࠰ൌ"): file.seek(-UQS9lVew50DIyXrinWsMxTzA(u"࠲࠲࠳࠵࠵࠶ോ"),brAUlZfdFmt3TRJW2xX4.SEEK_END)
	data = file.read()
	file.close()
	if GGfPQnrJKEqMv2ZVxdD: data = data.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	data = doiuzLQNmIKMtljBEnscYP8pe25xg(data)
	nRTS1iIwBy0MrzcuXDqH8kOC = data.split(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO)
	for Eh9DwNXB3LFnz1P in reversed(nRTS1iIwBy0MrzcuXDqH8kOC):
		blk2qfmgOzxasjG56Q97BL31NwvyF = xx0asIfKtiA71zw(Eh9DwNXB3LFnz1P)
		if blk2qfmgOzxasjG56Q97BL31NwvyF: continue
		Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬ૗"),U2bWzwG8VdJsBqtR74ErDi3cg1v+vhZ5qjay1z94JmcMOgXe(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ૘")+u4IRSmrYMKkaHUBnDiLWh)
		Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(YXm2qAbu8Qsx(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬ૙"),yNBjYsgc23xoW(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࠩ૚")+ttC4VURALPYKh(u"ࠧࡆࡔࡕࡓࡗࡀࠧ૛")+u4IRSmrYMKkaHUBnDiLWh)
		Hj04r1fQcOkiebuD3ZqvJKnYxtBywp = Zg9FeADE84jSRIvPCrzYulw3sL
		dXj968JVgZMHY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(NIBsHMvSXb(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ૜"),Eh9DwNXB3LFnz1P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if dXj968JVgZMHY:
			Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP],dXj968JVgZMHY[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]).replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],Zg9FeADE84jSRIvPCrzYulw3sL)
			Hj04r1fQcOkiebuD3ZqvJKnYxtBywp = dXj968JVgZMHY[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]
		else:
			dXj968JVgZMHY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(eCpDE6wJtYUHn0GqK5(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ૝"),Eh9DwNXB3LFnz1P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if dXj968JVgZMHY:
				Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0],Zg9FeADE84jSRIvPCrzYulw3sL)
				Hj04r1fQcOkiebuD3ZqvJKnYxtBywp = dXj968JVgZMHY[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]
		if Hj04r1fQcOkiebuD3ZqvJKnYxtBywp: Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(Hj04r1fQcOkiebuD3ZqvJKnYxtBywp,PPQORjT2lc7SVkKwFI4D+Hj04r1fQcOkiebuD3ZqvJKnYxtBywp+u4IRSmrYMKkaHUBnDiLWh)
		GOWk750EPypAfloNXZBHD.append(Eh9DwNXB3LFnz1P)
		if len(str(GOWk750EPypAfloNXZBHD))>dn9ouNryjHiBFQOhASvX(u"࠸࠴࠶࠶࠰്"): break
	GOWk750EPypAfloNXZBHD = reversed(GOWk750EPypAfloNXZBHD)
	gYJEOB4Z8MIk5pxlafV9W = SmFfh9kPpeoNBdcV7WnJ1LHMuXZO.join(GOWk750EPypAfloNXZBHD)
	ywuEego16R3ODiKVJr4Yf8qksH0vb(ttC4VURALPYKh(u"ࠪࡰࡪ࡬ࡴࠨ૞"),E3i1eCBtN2w(u"ࠫวิัࠡลึ฻ึࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠨ૟"),gYJEOB4Z8MIk5pxlafV9W,eCpDE6wJtYUHn0GqK5(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨૠ"))
	return
def ZgmE45hw7zc8rGJHvDxa3():
	TOpNw8XBAn = open(k5nIjDREtdlesKGUy,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡲࡣࠩૡ")).read()
	if GGfPQnrJKEqMv2ZVxdD: TOpNw8XBAn = TOpNw8XBAn.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	TOpNw8XBAn = TOpNw8XBAn.replace(eCpDE6wJtYUHn0GqK5(u"ࠧ࡝ࡶࠪૢ"),A2MHFvoqpZ64gNbB(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪૣ"))
	BchiTO0Hae9m6l4E1F = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(yNBjYsgc23xoW(u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ૤"),TOpNw8XBAn,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for Eh9DwNXB3LFnz1P in BchiTO0Hae9m6l4E1F:
		TOpNw8XBAn = TOpNw8XBAn.replace(Eh9DwNXB3LFnz1P,U2bWzwG8VdJsBqtR74ErDi3cg1v+Eh9DwNXB3LFnz1P+u4IRSmrYMKkaHUBnDiLWh)
	eelI82pRmObUdPNsj6tcT3Wx9F(dn9ouNryjHiBFQOhASvX(u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫ૥"),TOpNw8XBAn)
	return
def VpuQ7WkxR8HgLrKJdv():
	qS5lWUzuCiJjxwyAo1EdtD6nprV = yyZPkLCRX1xcBDN(u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭૦")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = KpNYeI2Pd4nHJG3cOTvWjbSa(u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩ૧")
	i68iLkExJaX = ttC4VURALPYKh(u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩ૨")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = qS5lWUzuCiJjxwyAo1EdtD6nprV+UixkloZbzGw28ujW56X(u"ࠧ࠻ࠢࠪ૩")+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6+eCpDE6wJtYUHn0GqK5(u"ࠨࠢ࠱ࠤࠬ૪")+i68iLkExJaX
	ywuEego16R3ODiKVJr4Yf8qksH0vb(E3i1eCBtN2w(u"ࠩࡦࡩࡳࡺࡥࡳࠩ૫"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭૬"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ૭"))
	return
def XO1DeBA3qJgjH0syEZua(type,oHkimLnwDKNxlheUuGAMQIg9jY7dz,showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,url=Zg9FeADE84jSRIvPCrzYulw3sL,iojW2gVFfT=Zg9FeADE84jSRIvPCrzYulw3sL,Tbwq7kJ4vRSNVyUFcdMzirG=Zg9FeADE84jSRIvPCrzYulw3sL,QMDFxHB98NcLjbfdsvIJhRog0=Zg9FeADE84jSRIvPCrzYulw3sL):
	XvfYjmAHSJFo4p = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if not XcPLKthYTV.zyKW1Eow48ek0:
		if showDialogs:
			q0bUPSX5d1JAOcIRLh7 = (vhZ5qjay1z94JmcMOgXe(u"ࠬอไิูิ࠾ࠬ૮") in oHkimLnwDKNxlheUuGAMQIg9jY7dz and KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭วๅ็ๆห๋ࡀࠧ૯") in oHkimLnwDKNxlheUuGAMQIg9jY7dz and OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧศๆ่่ๆࡀࠧ૰") in oHkimLnwDKNxlheUuGAMQIg9jY7dz and IK4zTnSMyGQpxEaesJAPVDY(u"ࠨษ็า฼ษࠧ૱") in oHkimLnwDKNxlheUuGAMQIg9jY7dz and okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩส่๊฻ฯา࠼ࠪ૲") in oHkimLnwDKNxlheUuGAMQIg9jY7dz)
			if not q0bUPSX5d1JAOcIRLh7: XvfYjmAHSJFo4p = EiOpncsbPr8qQzGodeW(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪࡧࡪࡴࡴࡦࡴࠪ૳"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ૴"),oHkimLnwDKNxlheUuGAMQIg9jY7dz.replace(yyZPkLCRX1xcBDN(u"ࠬࡢ࡜࡯ࠩ૵"),SmFfh9kPpeoNBdcV7WnJ1LHMuXZO))
	elif showDialogs:
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = eCpDE6wJtYUHn0GqK5(u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭૶")
		dMleCSIoAYHEVO3 = EiOpncsbPr8qQzGodeW(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧࡤࡧࡱࡸࡪࡸࠧ૷"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UixkloZbzGw28ujW56X(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ૸")+x9PULjztJOpu7b(u"ࠩࠣࠤ࠶࠵࠵ࠨૹ"),yNBjYsgc23xoW(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨૺ"))
		vvJq8PAcFxIZ9OuMEVkf = EiOpncsbPr8qQzGodeW(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫૻ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬૼ")+ykE045Tatx(u"࠭ࠠࠡ࠴࠲࠹ࠬ૽"),NIBsHMvSXb(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ૾"))
		Mmc6HTvLEKxaVo = EiOpncsbPr8qQzGodeW(eCpDE6wJtYUHn0GqK5(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ૿"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ଀")+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࠤࠥ࠹࠯࠶ࠩଁ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩଂ"))
		L7FXQZ5awYHuSirD9InchPK = EiOpncsbPr8qQzGodeW(IYC4iPxkTRUE85namF6(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଃ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭଄")+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠧࠡࠢ࠷࠳࠺࠭ଅ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ଆ"))
		XvfYjmAHSJFo4p = EiOpncsbPr8qQzGodeW(NIBsHMvSXb(u"ࠩࡦࡩࡳࡺࡥࡳࠩଇ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪଈ")+ReLGYUQjz7C9iEd(u"ࠫࠥࠦ࠵࠰࠷ࠪଉ"),eCpDE6wJtYUHn0GqK5(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪଊ"))
	QrXISV6wyYA = EELfq0dKnyhZPxpA2jJrFsvXU(vvglE69OFKBm817Nkc)
	P6Pf3jYw0tkqycTShisDLK2a7 = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡁࡗ࠼ࠣࠫଋ")+QrXISV6wyYA+vhZ5qjay1z94JmcMOgXe(u"ࠧ࠮ࠩଌ")+type
	MvgQ64LDmVySGqotedf = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if wFYiVd4r12x7CAQBL5SPof(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ଍") in Tbwq7kJ4vRSNVyUFcdMzirG else vvglE69OFKBm817Nkc
	if not XvfYjmAHSJFo4p:
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ଎"),eCpDE6wJtYUHn0GqK5(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭ଏ"))
		return vvglE69OFKBm817Nkc
	swvrR4IWQm = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(NIBsHMvSXb(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪଐ"))
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += vhZ5qjay1z94JmcMOgXe(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ଑")+kI8qwbo6yER+NIBsHMvSXb(u"࠭ࠠ࠻࡞࡟ࡲࠬ଒")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += A2MHFvoqpZ64gNbB(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨଓ")+QrXISV6wyYA+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧଔ")+UP58QEGLitwdp4qBDJozTu6V+vGg1hAkzqi8exVbN(u"ࠩࠣ࠾ࡡࡢ࡮ࠨକ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨଖ")+swvrR4IWQm
	HHg6LBxyifWDl2Oucpn = gOd5YrkR6jsFX()
	HHg6LBxyifWDl2Oucpn = OJYiDeyvSPTNI9(HHg6LBxyifWDl2Oucpn)
	if HHg6LBxyifWDl2Oucpn: oHkimLnwDKNxlheUuGAMQIg9jY7dz += qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ଗ")+HHg6LBxyifWDl2Oucpn
	if url: oHkimLnwDKNxlheUuGAMQIg9jY7dz += UixkloZbzGw28ujW56X(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩଘ")+url
	if iojW2gVFfT: oHkimLnwDKNxlheUuGAMQIg9jY7dz += jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭ଙ")+iojW2gVFfT
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += NIBsHMvSXb(u"ࠧࠡ࠼࡟ࡠࡳ࠭ଚ")
	if showDialogs: ZXWeI01flR(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧଛ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫଜ"))
	if QMDFxHB98NcLjbfdsvIJhRog0:
		gYJEOB4Z8MIk5pxlafV9W = QMDFxHB98NcLjbfdsvIJhRog0
		if GGfPQnrJKEqMv2ZVxdD: gYJEOB4Z8MIk5pxlafV9W = gYJEOB4Z8MIk5pxlafV9W.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		gYJEOB4Z8MIk5pxlafV9W = JDMo92nlwsAZydBPkpNzFvU.b64encode(gYJEOB4Z8MIk5pxlafV9W)
	elif MvgQ64LDmVySGqotedf:
		if ZYTyoA483N(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪଝ") in Tbwq7kJ4vRSNVyUFcdMzirG: DKfNJOm6tXys3AIoFnwpWEzeY8UQ4 = FbSejdADVtON1rKaI
		else: DKfNJOm6tXys3AIoFnwpWEzeY8UQ4 = jKNw370SdFlQ
		if not brAUlZfdFmt3TRJW2xX4.path.exists(DKfNJOm6tXys3AIoFnwpWEzeY8UQ4):
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧଞ"),JP65RzKaScIf(u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪଟ"))
			return vvglE69OFKBm817Nkc
		zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭࠮࡝ࡶࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡴࡩࡧࠣࡰࡴ࡭ࡦࡪ࡮ࡨࠫଠ"))
		GOWk750EPypAfloNXZBHD,dQT46gLOHsewaMC7iAxp3KBIb1N0 = [],E3i1eCBtN2w(u"࠴ൎ")
		file = open(DKfNJOm6tXys3AIoFnwpWEzeY8UQ4,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧࡳࡤࠪଡ"))
		size,count = M0VZ1cU2uDToibE6yj37RzCxkX5L(DKfNJOm6tXys3AIoFnwpWEzeY8UQ4)
		if size>okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠸࠶࠱࠱࠲࠳൏"): file.seek(-okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠸࠶࠱࠱࠲࠳൏"),brAUlZfdFmt3TRJW2xX4.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		data = doiuzLQNmIKMtljBEnscYP8pe25xg(data)
		nRTS1iIwBy0MrzcuXDqH8kOC = data.splitlines()
		for Eh9DwNXB3LFnz1P in reversed(nRTS1iIwBy0MrzcuXDqH8kOC):
			blk2qfmgOzxasjG56Q97BL31NwvyF = xx0asIfKtiA71zw(Eh9DwNXB3LFnz1P)
			if blk2qfmgOzxasjG56Q97BL31NwvyF: continue
			dXj968JVgZMHY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨଢ"),Eh9DwNXB3LFnz1P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if dXj968JVgZMHY:
				Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP],dXj968JVgZMHY[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]).replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],Zg9FeADE84jSRIvPCrzYulw3sL)
			else:
				dXj968JVgZMHY = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩଣ"),Eh9DwNXB3LFnz1P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if dXj968JVgZMHY: Eh9DwNXB3LFnz1P = Eh9DwNXB3LFnz1P.replace(dXj968JVgZMHY[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0],Zg9FeADE84jSRIvPCrzYulw3sL)
			GOWk750EPypAfloNXZBHD.append(Eh9DwNXB3LFnz1P)
			if len(str(GOWk750EPypAfloNXZBHD))>JP65RzKaScIf(u"࠸࠵࠲࠲࠳࠴൐"): break
		GOWk750EPypAfloNXZBHD = reversed(GOWk750EPypAfloNXZBHD)
		gYJEOB4Z8MIk5pxlafV9W = ReLGYUQjz7C9iEd(u"ࠪࡠࡷࡢ࡮ࠨତ").join(GOWk750EPypAfloNXZBHD)
		gYJEOB4Z8MIk5pxlafV9W = gYJEOB4Z8MIk5pxlafV9W.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		gYJEOB4Z8MIk5pxlafV9W = JDMo92nlwsAZydBPkpNzFvU.b64encode(gYJEOB4Z8MIk5pxlafV9W)
	else: gYJEOB4Z8MIk5pxlafV9W = Zg9FeADE84jSRIvPCrzYulw3sL
	url = PhpFa6EdVS[UQS9lVew50DIyXrinWsMxTzA(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫଥ")][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
	EEFf6enQDxk = {dn9ouNryjHiBFQOhASvX(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭ଦ"):P6Pf3jYw0tkqycTShisDLK2a7,JP65RzKaScIf(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧଧ"):oHkimLnwDKNxlheUuGAMQIg9jY7dz,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨନ"):gYJEOB4Z8MIk5pxlafV9W}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨࡒࡒࡗ࡙࠭଩"),url,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌ࠮࠳ࡶࡸࠬପ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if vhZ5qjay1z94JmcMOgXe(u"ࠪࠦࡸࡻࡣࡤࡧࡨࡨࡪࡪࠢ࠻ࠢ࠴࠰ࠬଫ") in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else: oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
	if showDialogs:
		if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD:
			ZXWeI01flR(yNBjYsgc23xoW(u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧବ"),E3i1eCBtN2w(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ଭ"))
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠬମ"),yNBjYsgc23xoW(u"ࠧห็ࠣษึูวๅࠢส่ึูวๅหࠣฬ๋าวฮࠩଯ"))
		else:
			ZXWeI01flR(JP65RzKaScIf(u"ࠨๆ็วุ็ࠠโึ็ࠤฬ๊ลาีส่ࠬର"),YXm2qAbu8Qsx(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪ଱"))
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଲ"),A2MHFvoqpZ64gNbB(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩଳ"))
	return oQE7jJVFnvtzbYAhSOc14qRXdKy9pD
def x7Reozbsg4Wh09mHINf5Pu2XDCU():
	qS5lWUzuCiJjxwyAo1EdtD6nprV = lU1fSmncFWjizwqZugyYBANML0(u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ଴")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = E3i1eCBtN2w(u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨଵ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡑࡴࡲࡦࡱ࡫࡭ࠨଶ"),qS5lWUzuCiJjxwyAo1EdtD6nprV+Vi1oNCM5kI7yJ0(u"ࠨ࡞ࡱࡠࡳ࠭ଷ")+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6)
	qS5lWUzuCiJjxwyAo1EdtD6nprV = E3i1eCBtN2w(u"ࠩ࠵࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡦࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠨସ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = vGg1hAkzqi8exVbN(u"ࠪ࠶࠳ࠦࠠࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆ่ๅࠡสอ฾๏๐ัࠡษ็ะ้ีࠠฬ็ࠣๆ๊ࠦศห฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪହ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡋࡵ࡮ࡵࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪ଺"),qS5lWUzuCiJjxwyAo1EdtD6nprV+IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡢ࡮࡝ࡰࠪ଻")+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6)
	qS5lWUzuCiJjxwyAo1EdtD6nprV = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭࠳࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡩࡵ࡮࡝ࠩࡷࠤ࡭ࡧࡶࡦࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ଼ࠫ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧ࠴࠰ࠣࠤࠥหะศࠢ็้ࠥ๐ใ็ࠢ็ำ๏้ࠠๅ๊ะอ๋ࠥแศฬํัࠥ฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็้฻็ฯࠠศๆฯ฾ึอแ๋หࠪଽ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧା"),qS5lWUzuCiJjxwyAo1EdtD6nprV+qdEKO42r3GhwmCDcHtxzJUR(u"ࠩ࡟ࡲࡡࡴࠧି")+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6)
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡧࡪࡴࡴࡦࡴࠪୀ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫୁ"),vhZ5qjay1z94JmcMOgXe(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩୂ")+jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭࡜࡯࡞ࡱࠫୃ")+eCpDE6wJtYUHn0GqK5(u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧୄ"))
	if jzydmKVUWrCv9D34F==wFYiVd4r12x7CAQBL5SPof(u"࠱൑"): MqDEblLnkBsIeTOoC1YdKhVpW0()
	return
def XXnW2D7l5OeaIb():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,NIBsHMvSXb(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୅"),eCpDE6wJtYUHn0GqK5(u"ࠩ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬ๊ࠡ็่ฯษใะࠢๅ้ࠥฮสี฼ํ่ࠥอไาษห฻ࠥอไั์่ࠣฬฺ๊ࠦ็็ࠤะ๋ࠠใ็ࠣฬสืำศๆู้้ࠣไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣห้่วว็ฬࠤฬ๊ัว์ึ๎ฮࠦไๅสิ๊ฬ๋ฬࠨ୆"))
	return
def qqj6LhEvko4QTO0():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"๋ࠪีอࠠศๆหี๋อๅอ่ࠢาฺ฻ࠠโไฺࠤฺ้๊สࠢส่฾ืศ๋หࠣ์้้ๆ้ࠡำห๊ࠥวࠡ์่๊฾่ࠦอ๊าࠤ๊๎วใ฻ࠣๅ๏ํวࠡลไ่ฬ๋้ࠠ็ึุ่๊วห่ࠢฮึาๅสࠢฦ์๋ࠥฯษๆฯอࠥหไ๊ࠢส่้เษࠡษ็฽ึฮ๊ส๋ࠢห้๏ࠠๅ฼สฮࠥอฮา๋ࠣ์้อ๋๊ࠠฯำูࠥศษࠢ็่ฯ้ัศำࠪେ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧୈ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def ttRY5hjknxy():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = eCpDE6wJtYUHn0GqK5(u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ୉")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ୊"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def leIAjQ0EH8Ykf7uD4sKcZ():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = vhZ5qjay1z94JmcMOgXe(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫୋ")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ykE045Tatx(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫୌ"),E3i1eCBtN2w(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬ୍ࠫ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def Ahp4nrRSlyNeFEPJiL180VfboIzG():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = Vi1oNCM5kI7yJ0(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨ୎")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(DKmLTA2yGtj(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ୏"),wFYiVd4r12x7CAQBL5SPof(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ୐"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,vv3sNE8XCU2RAiyVaueTbD950pz(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ୑"))
	return
def gy07nsfHjoZSQXPce23CDxkwrpB():
	qS5lWUzuCiJjxwyAo1EdtD6nprV = ee3tnwl7avk(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨ୒")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = wFYiVd4r12x7CAQBL5SPof(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪ୓")
	i68iLkExJaX = UixkloZbzGw28ujW56X(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ୔")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭୕"),qS5lWUzuCiJjxwyAo1EdtD6nprV,VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6,i68iLkExJaX)
	return
def tQzfGpol49XkunWcgqRv7S():
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬୖ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡢ࡮࡝ࡰࠪୗ") + A2MHFvoqpZ64gNbB(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬ୘") + str(B4GWT7zonF5yipbIwJmNUf6Vavg/okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠷࠲൒")/okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠷࠲൒")/YXm2qAbu8Qsx(u"࠴࠷൓")/IYC4iPxkTRUE85namF6(u"࠶࠴ൔ")) + IK4zTnSMyGQpxEaesJAPVDY(u"ࠧࠡึ๊ีࠬ୙")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + ReLGYUQjz7C9iEd(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ୚") + str(uWf6FZMyi2NxL7bYlDCX80RO9pkTB/eCpDE6wJtYUHn0GqK5(u"࠺࠵ൕ")/eCpDE6wJtYUHn0GqK5(u"࠺࠵ൕ")/DKmLTA2yGtj(u"࠷࠺ൖ")) + IK4zTnSMyGQpxEaesJAPVDY(u"ࠩࠣ๎ํ๋ࠧ୛")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + x9PULjztJOpu7b(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧଡ଼") + str(ggWsYrlq8fy2v/yNBjYsgc23xoW(u"࠼࠰ൗ")/yNBjYsgc23xoW(u"࠼࠰ൗ")/vGg1hAkzqi8exVbN(u"࠲࠵൘")) + lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠥ๐่ๆࠩଢ଼")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + ZYTyoA483N(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ୞") + str(E8RabFm1Kp5O0s/YXm2qAbu8Qsx(u"࠷࠲൙")/YXm2qAbu8Qsx(u"࠷࠲൙")) + eCpDE6wJtYUHn0GqK5(u"࠭ࠠิษ฼อࠬୟ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫୠ") + str(fA1u9wd7EkGBObjDhvWa/IYC4iPxkTRUE85namF6(u"࠸࠳൚")/IYC4iPxkTRUE85namF6(u"࠸࠳൚")) + OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࠢึห฾ฯࠧୡ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + lU1fSmncFWjizwqZugyYBANML0(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪୢ") + str(Xo8KxLn4tlPM7GWbjwmF/Vi1oNCM5kI7yJ0(u"࠹࠴൛")) + zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࠤิ่๊ใหࠪୣ")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO + eCpDE6wJtYUHn0GqK5(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭୤") + str(FFP5vTqk3nDlEuGdIy) + JP65RzKaScIf(u"ࠬࠦฯใ์ๅอࠬ୥")
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += dn9ouNryjHiBFQOhASvX(u"࠭࡜࡯࡞ࡱࠫ୦") + OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษࠣࠫ୧") + str(E8RabFm1Kp5O0s/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")) + YXm2qAbu8Qsx(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩ୨") + str(ggWsYrlq8fy2v/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")/OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠷࠺൝")) + eCpDE6wJtYUHn0GqK5(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨ୩") + str(fA1u9wd7EkGBObjDhvWa/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")) + KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์ࠦࠧ୪") + str(Xo8KxLn4tlPM7GWbjwmF/UQS9lVew50DIyXrinWsMxTzA(u"࠺࠵൜")) + ReLGYUQjz7C9iEd(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭୫") + str(FFP5vTqk3nDlEuGdIy) + qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࠦฯใ์ๅอࠬ୬")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡲࡪࡩ࡫ࡸࠬ୭"),vhZ5qjay1z94JmcMOgXe(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬ୮"),VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6,ZYTyoA483N(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ୯"))
	return
def mVq9Gvb3Iwx5MLUuihXNdfE():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = wFYiVd4r12x7CAQBL5SPof(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬ୰")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ୱ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def gCnvlQV7GH5TcBML0yDjiA46S():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = dn9ouNryjHiBFQOhASvX(u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ୲")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JP65RzKaScIf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ୳"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def bWCuMBpP6Dm2z():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = lU1fSmncFWjizwqZugyYBANML0(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ୴")
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ୵"),oHkimLnwDKNxlheUuGAMQIg9jY7dz)
	return
def WfjUdSVIa8z3iBJ6wxy7qZTlr():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୶"),DKmLTA2yGtj(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ୷"))
	M9ZaLYTqERCo2(yNBjYsgc23xoW(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ୸"),CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return
def Otb8RvdK1gP7YrLuaicqwyS():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz  = tt8KsSi26LmWYVPxkMBl10dfRjXT(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭୹")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += qdEKO42r3GhwmCDcHtxzJUR(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬ୺")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭เ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำࠪ୻")+u4IRSmrYMKkaHUBnDiLWh+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += YXm2qAbu8Qsx(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧ୼")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(x9PULjztJOpu7b(u"ࠨࡴ࡬࡫࡭ࡺࠧ୽"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ୾"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,IYC4iPxkTRUE85namF6(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭୿"))
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = UQS9lVew50DIyXrinWsMxTzA(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ஀")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+JP65RzKaScIf(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ஁")+u4IRSmrYMKkaHUBnDiLWh
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭࡜࡯࡞ࡱࠫஂ")+eCpDE6wJtYUHn0GqK5(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨஃ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+ttC4VURALPYKh(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪ஄")+u4IRSmrYMKkaHUBnDiLWh
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += E3i1eCBtN2w(u"ࠩ࡟ࡲࡡࡴࠧஅ")+okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫஆ")
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += PPQORjT2lc7SVkKwFI4D+lU1fSmncFWjizwqZugyYBANML0(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭இ")+u4IRSmrYMKkaHUBnDiLWh
	ywuEego16R3ODiKVJr4Yf8qksH0vb(E3i1eCBtN2w(u"ࠬࡸࡩࡨࡪࡷࠫஈ"),vhZ5qjay1z94JmcMOgXe(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩஉ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,DKmLTA2yGtj(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪஊ"))
	return
def J2JRzSVfA6x75rvlW4c():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨ஋"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࠬ஌")+PPQORjT2lc7SVkKwFI4D+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࠬ஍")+u4IRSmrYMKkaHUBnDiLWh+UixkloZbzGw28ujW56X(u"ࠫࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣࠫஎ")+PPQORjT2lc7SVkKwFI4D+dn9ouNryjHiBFQOhASvX(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫஏ")+u4IRSmrYMKkaHUBnDiLWh)
	return
def uvVI1sZ5fd8rUKqj3GYxHgF():
	tQzfGpol49XkunWcgqRv7S()
	jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ஐ"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣห้้วีࠢยࠫ஑"),UixkloZbzGw28ujW56X(u"ࠨษ็็ฬฺ๋ࠠีิ฽ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤํ๋ำฮ้ࠣ๎฾๐ฯࠡีะฬࠥอไึใะหฯࠦๅ็ࠢส่ส์สา่อࠤ฾์ฯࠡษ็ัฬาษࠡว็๎์อ้ࠠษ็ุ้ำ๋ࠠฬ่ࠤฯ๊โศศํหࠥ฿ๆะࠢส๊ฯํวยࠢ฼้ึࠦวๅืไัฬะ้ࠠษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨஒ"))
	if jzydmKVUWrCv9D34F==eCpDE6wJtYUHn0GqK5(u"࠷൞"):
		x1NAX6MdmQg2BOJ(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡสส่่อๅๅࠩஓ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪษีอࠠไษ้ฮࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥออะࠢส่๊๎วใ฻ࠣๅัืศࠡษ็้ํู่ࠡษ็ฦ๋ࠦ࠮࠯࠰ࠣ์ศึวࠡษ็ู้้ไส่ࠢืฯ๋ัสࠢไษี์ࠠศำึ่ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫஔ"))
	return jzydmKVUWrCv9D34F
def zu4R2bVnZy9PxWkYw(showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	if not showDialogs: showDialogs = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡌࡋࡔࠨக"),yyZPkLCRX1xcBDN(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫ஖"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ஗"))
	if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
		JJv1AdQ6fLetHlR0 = vvglE69OFKBm817Nkc
		AA0Wd3yScYv2H9hBD7a4oPpi = pVZOH6lyXU(vvglE69OFKBm817Nkc)
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+eCpDE6wJtYUHn0GqK5(u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬ஘")+AA0Wd3yScYv2H9hBD7a4oPpi+ReLGYUQjz7C9iEd(u"ࠨ࡟ࠪங"))
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬச"),ttC4VURALPYKh(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧ஛"))
	else:
		JJv1AdQ6fLetHlR0 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧஜ"),IYC4iPxkTRUE85namF6(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ஝"))
	if not JJv1AdQ6fLetHlR0 and showDialogs: AANMVmockjQp1GKwgeJChPr8Tnt()
	return JJv1AdQ6fLetHlR0
def AANMVmockjQp1GKwgeJChPr8Tnt():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,DKmLTA2yGtj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩஞ"),A2MHFvoqpZ64gNbB(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭ட"))
	eeVRf8BzbDr2yHLwAkU9px()
	return
def Y0YZLJcFOnCMbu5KX3fyIazElsDTN(Tbwq7kJ4vRSNVyUFcdMzirG=Zg9FeADE84jSRIvPCrzYulw3sL):
	MvgQ64LDmVySGqotedf = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	if Vi1oNCM5kI7yJ0(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ஠") not in Tbwq7kJ4vRSNVyUFcdMzirG:
		MvgQ64LDmVySGqotedf = vvglE69OFKBm817Nkc
		KPAgkny9rSD0Xdx6CUse1a2LG = wCuDBb85Gjl36RAQnUEZd(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡦࡩࡳࡺࡥࡳࠩ஡"),vhZ5qjay1z94JmcMOgXe(u"ࠪาึ๎ฬࠨ஢"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫสืำศๆู้้ࠣไสࠩண"),ee3tnwl7avk(u"ࠬหัิษ็ࠤึูวๅหࠪத"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ஥"),vhZ5qjay1z94JmcMOgXe(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯืำๅࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ัࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣว๋ࠦสาี็ࠤฺ๊ใๅห้ࠣํา่ะหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠪ஦"))
		if KPAgkny9rSD0Xdx6CUse1a2LG in [-YXm2qAbu8Qsx(u"࠱ൟ"),vv3sNE8XCU2RAiyVaueTbD950pz(u"࠱ൠ")]: return
		elif KPAgkny9rSD0Xdx6CUse1a2LG==vGg1hAkzqi8exVbN(u"࠳ൡ"):
			MvgQ64LDmVySGqotedf = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			Tbwq7kJ4vRSNVyUFcdMzirG = Vi1oNCM5kI7yJ0(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ஧")
	if MvgQ64LDmVySGqotedf:
		if ZYTyoA483N(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩந") not in Tbwq7kJ4vRSNVyUFcdMzirG:
			jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡧࡪࡴࡴࡦࡴࠪன"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠫํ฼ูࠡษ็ู้้ไสࠢไ๎ࠥอไิฮ็ࠫப"),yNBjYsgc23xoW(u"่ࠬศๅࠢศีุอไࠡษ็ืัฺ๊ࠠๆํ็ࠥษๆࠡฬๆีึࠦࠠ็ใึࠤฬ๊แฺๆࠣห้ึ๊ࠡล฼฻ฬ้ࠠศๆุ่่๊ษࠡ࠰่่ࠣ๐๋ࠠฬ่ࠤฯูฬ๋ๆ๋ࠣีํࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦ࠮๊ࠡหำํ์่ࠠาสࠤฬ๊สิฮํู่่ࠥโࠢอีุ๊ࠠๆๆไࠤ้อࠠโษษำฮࠦๅ็้่ࠣส์็ࠡๆสࠤ๏ำส้์ࠣ฽้๏ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦสา์าࠤฬ์สࠡษ็ษอ๊ว฻ࠢ฼๊์อࠠ࠯๊่่ࠢࠥๅหࠢหฮ่ืวาࠢสฺ่๊ใๅหࠣรࠬ஫"))
			if jzydmKVUWrCv9D34F!=Vi1oNCM5kI7yJ0(u"࠴ൢ"):
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠩ஬"),DKmLTA2yGtj(u"ࠧๅๆฦืๆࠦศะ๊้ࠤฯูฬ๋ๆࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢไห๋ࠦวๅ็หี๊าࠠๅษࠣ๎ุะื๋฻้ࠣ฾ืแสࠢสฺ่๊ใๅหࠣ์้อࠠฮๆ๊ห๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ஭"))
				return
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫம"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ய"))
	search = EnxNsqevtM28mpkZ5RG0(header=A2MHFvoqpZ64gNbB(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬர"),source=bIPsOxjEpoH)
	if not search: return
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = search
	if MvgQ64LDmVySGqotedf: type = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬற")
	else: type = yyZPkLCRX1xcBDN(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ல")
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = XO1DeBA3qJgjH0syEZua(type,oHkimLnwDKNxlheUuGAMQIg9jY7dz,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,YXm2qAbu8Qsx(u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩள"),Tbwq7kJ4vRSNVyUFcdMzirG)
	return
def MKWqT8DBXx9hloRu4OArgmV():
	Tbwq7kJ4vRSNVyUFcdMzirG = ReLGYUQjz7C9iEd(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫழ")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(qdEKO42r3GhwmCDcHtxzJUR(u"ࠨࡴ࡬࡫࡭ࡺࠧவ"),A2MHFvoqpZ64gNbB(u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩஶ"),Tbwq7kJ4vRSNVyUFcdMzirG,UQS9lVew50DIyXrinWsMxTzA(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ஷ"))
	Tbwq7kJ4vRSNVyUFcdMzirG = YXm2qAbu8Qsx(u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧஸ")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(ykE045Tatx(u"ࠬࡲࡥࡧࡶࠪஹ"),vGg1hAkzqi8exVbN(u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫ஺"),Tbwq7kJ4vRSNVyUFcdMzirG,IYC4iPxkTRUE85namF6(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ஻"))
	return
def XULYcNVBqhPaiEFCpJ4v7KHWG():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ஼"),YXm2qAbu8Qsx(u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧ஽"))
	bWCuMBpP6Dm2z()
	return
def b5VxwQhXNjcTBFu1fzsK():
	qS5lWUzuCiJjxwyAo1EdtD6nprV,VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6,i68iLkExJaX,JXhn2P97BCK4yN1eWbLv,HHRsabZpuyCEOJ0X3zFLGovqTx1g,eHVJzsyxtKO,QNovjxUialZ2 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	EEFf6enQDxk,PKb2F0Ip4dTCwx5G8B1WEcN,JRvIeFaXtGVHyE,SSoXwkOUyCWAaNtHi = {UixkloZbzGw28ujW56X(u"ࠪࡥࠬா"):lU1fSmncFWjizwqZugyYBANML0(u"ࠫࡦ࠭ி")},{},[],{}
	url = PhpFa6EdVS[ee3tnwl7avk(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬீ")][Mn5NGAdz6xc42s0]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,jozVWcERh91GOF2NHXQiSwKqe8x(u"࠭ࡐࡐࡕࡗࠫு"),url,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬூ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(JP65RzKaScIf(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨ௃"),ee3tnwl7avk(u"ࠩࡘࡗࡆ࠭௄"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(dn9ouNryjHiBFQOhASvX(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ௅"),NIBsHMvSXb(u"࡚ࠫࡑࠧெ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(UixkloZbzGw28ujW56X(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬே"),ee3tnwl7avk(u"࠭ࡕࡂࡇࠪை"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(UixkloZbzGw28ujW56X(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭௉"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠨࡍࡖࡅࠬொ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(UQS9lVew50DIyXrinWsMxTzA(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫோ"),ReLGYUQjz7C9iEd(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨௌ"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(ZYTyoA483N(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥ்ࠬ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ௎"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace(E3i1eCBtN2w(u"࠭࡟ࡠࡡࠪ௏"),F4skx1A3wOEh9lmPuZMnpCzR)
	try: Gr0CXTUFJMLBp1xlqPoZ96aDHAsWt = JGmfjhoyKZUl(yyZPkLCRX1xcBDN(u"ࠧ࡭࡫ࡶࡸࠬௐ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	except:
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IK4zTnSMyGQpxEaesJAPVDY(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ௑"),wFYiVd4r12x7CAQBL5SPof(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ௒"))
		return
	KifduwEm6BGjAQYqoy,TcsWACuh5d8MVfivlmnLGB40H,vwSxoWQ9tmkl8jZ1VcYzy = Gr0CXTUFJMLBp1xlqPoZ96aDHAsWt
	SSoXwkOUyCWAaNtHi = {}
	OSCq7T9sgpFcDZjlYrw2 = [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭௓"),UixkloZbzGw28ujW56X(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪ௔")]
	bkfAchH39D = [YXm2qAbu8Qsx(u"ࠬࡇࡌࡍࠩ௕"),UixkloZbzGw28ujW56X(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭௖"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨௗ"),dn9ouNryjHiBFQOhASvX(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ௘"),x9PULjztJOpu7b(u"ࠩࡕࡉࡕࡕࡓࠨ௙")]+OSCq7T9sgpFcDZjlYrw2+Wbng8KmUpcXyOYNSGA+a6lEryZVzDACc1JixeFqnT35
	for FLqQoZwdAngNkz49RMGUHJXW3bDC,skYvqUBmbh7Lf3Va0wXEQp5,Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5 in TcsWACuh5d8MVfivlmnLGB40H:
		Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5 = uumhMi6O4pk7Gjd5aTQqy2Z(Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5)
		Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5 = Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5.strip(wjs26GpVfNiCUERHJ).strip(A2MHFvoqpZ64gNbB(u"ࠪࠤ࠳࠭௚"))
		JXhn2P97BCK4yN1eWbLv += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+FLqQoZwdAngNkz49RMGUHJXW3bDC+x9PULjztJOpu7b(u"ࠫ࠿ࠦࠧ௛")+u4IRSmrYMKkaHUBnDiLWh+Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
		if skYvqUBmbh7Lf3Va0wXEQp5.isdigit():
			SSoXwkOUyCWAaNtHi[FLqQoZwdAngNkz49RMGUHJXW3bDC] = int(skYvqUBmbh7Lf3Va0wXEQp5)
			if int(skYvqUBmbh7Lf3Va0wXEQp5)>eCpDE6wJtYUHn0GqK5(u"࠵࠵࠶ൣ"): skYvqUBmbh7Lf3Va0wXEQp5 = E3i1eCBtN2w(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ௜")
			else: skYvqUBmbh7Lf3Va0wXEQp5 = lU1fSmncFWjizwqZugyYBANML0(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ௝")
		if FLqQoZwdAngNkz49RMGUHJXW3bDC not in bkfAchH39D:
			if   skYvqUBmbh7Lf3Va0wXEQp5==ZYTyoA483N(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ௞"): qS5lWUzuCiJjxwyAo1EdtD6nprV += F4skx1A3wOEh9lmPuZMnpCzR+FLqQoZwdAngNkz49RMGUHJXW3bDC
			elif skYvqUBmbh7Lf3Va0wXEQp5==qdEKO42r3GhwmCDcHtxzJUR(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ௟"): VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 += F4skx1A3wOEh9lmPuZMnpCzR+FLqQoZwdAngNkz49RMGUHJXW3bDC
	Rgpbhx7moJ6AXwP9zNaQcYSM,lOQqcfejCUKJ8wrE0k,jIiwo45dKVlvPJfnpLGAxNb = list(zip(*TcsWACuh5d8MVfivlmnLGB40H))
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in sorted(LRS4BMJz10XF2s7ghtmvwVofr):
		if FLqQoZwdAngNkz49RMGUHJXW3bDC not in Rgpbhx7moJ6AXwP9zNaQcYSM:
			JXhn2P97BCK4yN1eWbLv += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+FLqQoZwdAngNkz49RMGUHJXW3bDC+yyZPkLCRX1xcBDN(u"ࠩ࠽ࠤࠬ௠")+u4IRSmrYMKkaHUBnDiLWh+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"่ࠪฬ๊้ࠦฮาࠫ௡")+JP65RzKaScIf(u"ࠫࡡࡴ࡜࡯ࠩ௢")
			if FLqQoZwdAngNkz49RMGUHJXW3bDC not in bkfAchH39D: i68iLkExJaX += F4skx1A3wOEh9lmPuZMnpCzR+FLqQoZwdAngNkz49RMGUHJXW3bDC
	for Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5,dQT46gLOHsewaMC7iAxp3KBIb1N0 in KifduwEm6BGjAQYqoy:
		Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5 = uumhMi6O4pk7Gjd5aTQqy2Z(Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5)
		HHRsabZpuyCEOJ0X3zFLGovqTx1g += Vp3GAYZRxXJb6nPkNaTdWiFQEKCS5+ZYTyoA483N(u"ࠬࡀࠠࠨ௣")+PPQORjT2lc7SVkKwFI4D+str(dQT46gLOHsewaMC7iAxp3KBIb1N0)+u4IRSmrYMKkaHUBnDiLWh+KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࠠࠡࠢࠪ௤")
	qS5lWUzuCiJjxwyAo1EdtD6nprV = qS5lWUzuCiJjxwyAo1EdtD6nprV.strip(wjs26GpVfNiCUERHJ)
	VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6.strip(wjs26GpVfNiCUERHJ)
	i68iLkExJaX = i68iLkExJaX.strip(wjs26GpVfNiCUERHJ)
	t0xhejPsHTO5WQfSlDJ3oFia6ZU7L = qS5lWUzuCiJjxwyAo1EdtD6nprV+F4skx1A3wOEh9lmPuZMnpCzR+VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6
	L9Ha8UpTPxvZSj0l  = ttC4VURALPYKh(u"ࠧๆ๊สๆ฾ࠦๆอฯࠣห้ฮั็ษ่ะࠥฮสี฼ํ่ࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫ௥")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+YXm2qAbu8Qsx(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ่์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั࠭௦")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	L9Ha8UpTPxvZSj0l += PPQORjT2lc7SVkKwFI4D+t0xhejPsHTO5WQfSlDJ3oFia6ZU7L+u4IRSmrYMKkaHUBnDiLWh+vGg1hAkzqi8exVbN(u"ࠩ࡟ࡲࡡࡴࠧ௧")
	L9Ha8UpTPxvZSj0l += yyZPkLCRX1xcBDN(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩ௨")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+ZYTyoA483N(u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไࠡๅห๎ึ่ࠦอ๊าࠤฺ๊ใๅหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ௩")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO
	L9Ha8UpTPxvZSj0l += PPQORjT2lc7SVkKwFI4D+i68iLkExJaX+u4IRSmrYMKkaHUBnDiLWh
	EbrfXYZsJmWl,s6sviWU8HxTpJe,NPMRxYioBJpCby,LqIGQg0hZbT2t = KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠵൤"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠵൤"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠵൤"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠵൤")
	all = SSoXwkOUyCWAaNtHi[ttC4VURALPYKh(u"ࠬࡇࡌࡍࠩ௪")]
	if ZYTyoA483N(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭௫") in list(SSoXwkOUyCWAaNtHi.keys()): EbrfXYZsJmWl = SSoXwkOUyCWAaNtHi[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ௬")]
	if KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ௭") in list(SSoXwkOUyCWAaNtHi.keys()): s6sviWU8HxTpJe = SSoXwkOUyCWAaNtHi[vGg1hAkzqi8exVbN(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ௮")]
	if JP65RzKaScIf(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ௯") in list(SSoXwkOUyCWAaNtHi.keys()): NPMRxYioBJpCby = SSoXwkOUyCWAaNtHi[qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ௰")]
	if UixkloZbzGw28ujW56X(u"ࠬࡘࡅࡑࡑࡖࠫ௱") in list(SSoXwkOUyCWAaNtHi.keys()): LqIGQg0hZbT2t = SSoXwkOUyCWAaNtHi[NIBsHMvSXb(u"࠭ࡒࡆࡒࡒࡗࠬ௲")]
	WSghA9bJoFMQzGReqjwtu = all-EbrfXYZsJmWl-s6sviWU8HxTpJe-NPMRxYioBJpCby-LqIGQg0hZbT2t
	DMKySWniQ0HqtCsrg65dmb2Tha,d2opxAVG8XYMc1BrsRgIhN = vwSxoWQ9tmkl8jZ1VcYzy[UwCT5Oz6Wo0BP]
	DMKySWniQ0HqtCsrg65dmb2Tha,tkp65h43AJaoH = vwSxoWQ9tmkl8jZ1VcYzy[Mn5NGAdz6xc42s0]
	R8DieokfTrUEGN65b = d2opxAVG8XYMc1BrsRgIhN-tkp65h43AJaoH
	QNovjxUialZ2 += U2bWzwG8VdJsBqtR74ErDi3cg1v+str(tkp65h43AJaoH)+u4IRSmrYMKkaHUBnDiLWh+yNBjYsgc23xoW(u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫ௳")
	QNovjxUialZ2 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(R8DieokfTrUEGN65b)+u4IRSmrYMKkaHUBnDiLWh+yyZPkLCRX1xcBDN(u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬ௴")
	QNovjxUialZ2 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(d2opxAVG8XYMc1BrsRgIhN)+u4IRSmrYMKkaHUBnDiLWh+Vi1oNCM5kI7yJ0(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪ௵")
	QNovjxUialZ2 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(len(vwSxoWQ9tmkl8jZ1VcYzy[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠸൥"):]))+u4IRSmrYMKkaHUBnDiLWh+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨ௶")
	for yZ8XuBSf1M0NvqILAnYQGd36,QrXISV6wyYA in vwSxoWQ9tmkl8jZ1VcYzy[zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠲൦"):]:
		yZ8XuBSf1M0NvqILAnYQGd36 = uumhMi6O4pk7Gjd5aTQqy2Z(yZ8XuBSf1M0NvqILAnYQGd36)
		yZ8XuBSf1M0NvqILAnYQGd36 = yZ8XuBSf1M0NvqILAnYQGd36.strip(wjs26GpVfNiCUERHJ).strip(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࠥ࠴ࠧ௷"))
		QNovjxUialZ2 += yZ8XuBSf1M0NvqILAnYQGd36+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠬࡀࠠࠨ௸")+PPQORjT2lc7SVkKwFI4D+str(QrXISV6wyYA)+u4IRSmrYMKkaHUBnDiLWh+wFYiVd4r12x7CAQBL5SPof(u"࠭ࠠࠡࠢࠪ௹")
	eHVJzsyxtKO += U2bWzwG8VdJsBqtR74ErDi3cg1v+str(WSghA9bJoFMQzGReqjwtu)+u4IRSmrYMKkaHUBnDiLWh+tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬ௺")
	eHVJzsyxtKO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(EbrfXYZsJmWl)+u4IRSmrYMKkaHUBnDiLWh+ReLGYUQjz7C9iEd(u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩ௻")
	eHVJzsyxtKO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(LqIGQg0hZbT2t)+u4IRSmrYMKkaHUBnDiLWh+ReLGYUQjz7C9iEd(u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่ืฯ๎ฯฺࠢ࠽ࠤࠬ௼")
	eHVJzsyxtKO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(s6sviWU8HxTpJe)+u4IRSmrYMKkaHUBnDiLWh+ZYTyoA483N(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧ௽")
	eHVJzsyxtKO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(NPMRxYioBJpCby)+u4IRSmrYMKkaHUBnDiLWh+OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠫฯัศ๋ฬࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠻ࠢࠪ௾")
	eHVJzsyxtKO += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+U2bWzwG8VdJsBqtR74ErDi3cg1v+str(len(KifduwEm6BGjAQYqoy))+u4IRSmrYMKkaHUBnDiLWh+E3i1eCBtN2w(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬ௿")
	eHVJzsyxtKO += yyZPkLCRX1xcBDN(u"࠭࡜࡯࡞ࡱࠫఀ")+HHRsabZpuyCEOJ0X3zFLGovqTx1g
	ywuEego16R3ODiKVJr4Yf8qksH0vb(qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡤࡧࡱࡸࡪࡸࠧఁ"),JP65RzKaScIf(u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨం"),QNovjxUialZ2,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬః"))
	ywuEego16R3ODiKVJr4Yf8qksH0vb(ykE045Tatx(u"ࠪࡧࡪࡴࡴࡦࡴࠪఄ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬఅ"),eHVJzsyxtKO,Vi1oNCM5kI7yJ0(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨఆ"))
	ywuEego16R3ODiKVJr4Yf8qksH0vb(yyZPkLCRX1xcBDN(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ఇ"),yNBjYsgc23xoW(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪఈ"),L9Ha8UpTPxvZSj0l,ZYTyoA483N(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫఉ"))
	ywuEego16R3ODiKVJr4Yf8qksH0vb(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠩ࡯ࡩ࡫ࡺࠧఊ"),yNBjYsgc23xoW(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬఋ"),JXhn2P97BCK4yN1eWbLv,DKmLTA2yGtj(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬఌ"))
	return
def AAoLge0P9axSQniGj412():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = lU1fSmncFWjizwqZugyYBANML0(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴࠧ఍")+U2bWzwG8VdJsBqtR74ErDi3cg1v+E3i1eCBtN2w(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬఎ")+u4IRSmrYMKkaHUBnDiLWh+dn9ouNryjHiBFQOhASvX(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯ࠩఏ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+A2MHFvoqpZ64gNbB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰࠩఐ")+u4IRSmrYMKkaHUBnDiLWh+NIBsHMvSXb(u"ࠩ࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡลฯ์อฯࠠศๆหี๋อๅอࠩ఑")
	ywuEego16R3ODiKVJr4Yf8qksH0vb(wFYiVd4r12x7CAQBL5SPof(u"ࠪࡧࡪࡴࡴࡦࡴࠪఒ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧఓ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,wFYiVd4r12x7CAQBL5SPof(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨఔ"))
	return
def g4OiGUFeMzlQLR0ju():
	oHkimLnwDKNxlheUuGAMQIg9jY7dz = vGg1hAkzqi8exVbN(u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫక")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+PhpFa6EdVS[A2MHFvoqpZ64gNbB(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ఖ")][UwCT5Oz6Wo0BP]+u4IRSmrYMKkaHUBnDiLWh+ZYTyoA483N(u"ࠨࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡࠩగ")+PPQORjT2lc7SVkKwFI4D+PhpFa6EdVS[YXm2qAbu8Qsx(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨఘ")][Mn5NGAdz6xc42s0]+u4IRSmrYMKkaHUBnDiLWh
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += eCpDE6wJtYUHn0GqK5(u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰࠪఙ")+PPQORjT2lc7SVkKwFI4D+PhpFa6EdVS[yNBjYsgc23xoW(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬచ")][Mn5NGAdz6xc42s0]+u4IRSmrYMKkaHUBnDiLWh
	oHkimLnwDKNxlheUuGAMQIg9jY7dz += NIBsHMvSXb(u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨఛ")+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+PPQORjT2lc7SVkKwFI4D+PhpFa6EdVS[A2MHFvoqpZ64gNbB(u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧజ")][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]+u4IRSmrYMKkaHUBnDiLWh
	ywuEego16R3ODiKVJr4Yf8qksH0vb(YXm2qAbu8Qsx(u"ࠧࡤࡧࡱࡸࡪࡸࠧఝ"),NIBsHMvSXb(u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧఞ"),oHkimLnwDKNxlheUuGAMQIg9jY7dz,lU1fSmncFWjizwqZugyYBANML0(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬట"))
	return
def N731NjrhcUKynLJuDAv(HL3hJsMnrlCcaQgVEziR):
	Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(ykE045Tatx(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩఠ")+HL3hJsMnrlCcaQgVEziR+UixkloZbzGw28ujW56X(u"ࠫ࠮࠭డ"), CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return
def MqDEblLnkBsIeTOoC1YdKhVpW0():
	LpTv52e4Icnwms0OXRW6oACix(JP65RzKaScIf(u"ࠬࡹࡴࡰࡲࠪఢ"))
	Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(IYC4iPxkTRUE85namF6(u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧణ"))
	return
def qkK4bcLaDdX():
	Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭త"), CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
	return
def aDlQBLfgIT3mXNG():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫథ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦร้ࠢสืฯิฯๆࠢࠥห้้๊ษ๊ิำ่ࠧࠦศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣห฻เืࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠩద"))
	return
def hiOuYXzrRlms0jWKvgnqf8SZ1AJoU():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Vi1oNCM5kI7yJ0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ధ"),lU1fSmncFWjizwqZugyYBANML0(u"้๊ࠫสฺษู่่๋ࠥࠡษ็้ๆ฼ไสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅำสฬ฼ࠦวๅาํࠤฯื๊ะࠢศฺฬ็ส่ࠢฦ์๋ࠥำฮ้้๋ࠣࠦࠠใษษ้ฮࠦวๅ็ไฺ้ฯ้ࠠๆๆ๊๊ࠥวࠡฬ้ๆึูࠦๅ์๊ࠤํ๊วࠡฬื฾้ํࠠ࠯๋ࠢฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎รๆษࠣฬฬูสฯัส้ࠥࠨวๅๅํฬํืฯࠣࠢไห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎ๆโีࠣห้้ไศ็ࠣ์ฬ๊ืา์ๅอࠥ฿ๆะࠢส่ฯ฿วๆๆ้ࠣ฾ࠦๅฮฬ๋๎ฬะࠠใ๊สส๊ࠦวๅ็ไฺ้ฯࠧన"))
	return
def kfouPlW6qH(gqPpUakQBJOyDFSTlMZ2V8K1HEbL=ttC4VURALPYKh(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ఩"),showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	thz5sHXldkV3L = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(NIBsHMvSXb(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩప"))
	data = lSD9w50N6VBOHbfT2WRiPsM.loads(thz5sHXldkV3L)
	yahP04WSCvqZmuIMcHQ6Vp = data[A2MHFvoqpZ64gNbB(u"ࠧࡳࡧࡶࡹࡱࡺࠧఫ")][ZYTyoA483N(u"ࠨࡸࡤࡰࡺ࡫ࠧబ")]
	if HByjTem6EJP5sZb: yahP04WSCvqZmuIMcHQ6Vp = yahP04WSCvqZmuIMcHQ6Vp.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬభ"),UQS9lVew50DIyXrinWsMxTzA(u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨమ")+yahP04WSCvqZmuIMcHQ6Vp+UQS9lVew50DIyXrinWsMxTzA(u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭య")+gqPpUakQBJOyDFSTlMZ2V8K1HEbL+ee3tnwl7avk(u"ࠬࠦฟࠢࠩర"))
		if jzydmKVUWrCv9D34F!=ZYTyoA483N(u"࠲൧"): return vvglE69OFKBm817Nkc
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD,w84aMg7jUcrZ5OGRbnEVBs9QIdvex,alCi7f6WdFy = aaEnC4rAS3uLHqx9owBhb1MzJjU(gqPpUakQBJOyDFSTlMZ2V8K1HEbL,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD:
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩఱ"),IK4zTnSMyGQpxEaesJAPVDY(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩల"))
		Tbl0qZIrG9p = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬళ")+gqPpUakQBJOyDFSTlMZ2V8K1HEbL+UixkloZbzGw28ujW56X(u"ࠩࠥࢁࢂ࠭ఴ"))
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if vGg1hAkzqi8exVbN(u"ࠪࡓࡐ࠭వ") in Tbl0qZIrG9p else vvglE69OFKBm817Nkc
		LNma2eq3vEguwVtHjn.sleep(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠳൨"))
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(eCpDE6wJtYUHn0GqK5(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫశ"))
	elif showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨష"),OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨస"))
	return oQE7jJVFnvtzbYAhSOc14qRXdKy9pD
def eeVRf8BzbDr2yHLwAkU9px():
	url = yNBjYsgc23xoW(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬహ")
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡉࡈࡘࠬ఺"),url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬ఻"))
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	a0F2eWrgoIP4MmbOVjGhH = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(Vi1oNCM5kI7yJ0(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮఼ࠩ"),yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	a0F2eWrgoIP4MmbOVjGhH = a0F2eWrgoIP4MmbOVjGhH[UwCT5Oz6Wo0BP].split(tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫ࠲࠭ఽ"))[UwCT5Oz6Wo0BP]
	E1kU4Hca0hDr3gxfNPSmQLodIZK = str(NGiBmYp8vX9T426lHn7ue)
	JXhn2P97BCK4yN1eWbLv = Vi1oNCM5kI7yJ0(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧా")+U2bWzwG8VdJsBqtR74ErDi3cg1v+a0F2eWrgoIP4MmbOVjGhH+u4IRSmrYMKkaHUBnDiLWh
	JXhn2P97BCK4yN1eWbLv += zaOkgPnGLs6biVDuTjdCFrwefcqN(u"࠭࡜࡯࡞ࡱࠫి")+IK4zTnSMyGQpxEaesJAPVDY(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ీ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+E1kU4Hca0hDr3gxfNPSmQLodIZK+u4IRSmrYMKkaHUBnDiLWh
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫు"),JXhn2P97BCK4yN1eWbLv)
	return
def fMTNBcXtPoO5mFn0UIweZda1QS():
	PQynxCOHWs6z29ejLI,n8segRSX30jNwlC,nFwolzUcBgh1jI6eCvtL3rNYJa = vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	Bh8rPyR6UVjlQvY,XXhjqTU752kRGfZC1xcS,IO93VvnfLhlCaNirBRuQXDzyH = vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	wdBbhtlZ6WuY5 = [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧూ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬృ"),ykE045Tatx(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪౄ")]
	BchiTO0Hae9m6l4E1F = DUlT4qMG5tQd(wdBbhtlZ6WuY5)
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in wdBbhtlZ6WuY5:
		if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs not in list(BchiTO0Hae9m6l4E1F.keys()): continue
		mHLBF2Mogbt7rWsCQ,wwmXRxF9gzLPqHNAisY68GB2KaVIb,GGSVcEmnpj,X8wB92I4iKW0xOtVJTySrG,WRqLkgAySs,dvZ0NWbkVhogcJI7qP2T,rVbiXKMU23PLBz6CAvsNcjtY7HD = BchiTO0Hae9m6l4E1F[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs]
		if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs==wFYiVd4r12x7CAQBL5SPof(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ౅"):
			Bh8rPyR6UVjlQvY = mHLBF2Mogbt7rWsCQ
			XXhjqTU752kRGfZC1xcS = wwmXRxF9gzLPqHNAisY68GB2KaVIb+UixkloZbzGw28ujW56X(u"࠭ࠠࠡࠢࠣࠬࠥ࠭ె")+ulj9JfWhc0EgZbsm(dvZ0NWbkVhogcJI7qP2T)+ykE045Tatx(u"ࠧࠡࠫࠪే")
			IO93VvnfLhlCaNirBRuQXDzyH = X8wB92I4iKW0xOtVJTySrG
		elif Knc8GLhkpePT7xzH3gZtv1jbiEIRAs==ykE045Tatx(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪై"):
			PQynxCOHWs6z29ejLI = PQynxCOHWs6z29ejLI or mHLBF2Mogbt7rWsCQ
			n8segRSX30jNwlC += Vi1oNCM5kI7yJ0(u"ࠩࠣࠤ࠱ࠦࠠࠨ౉")+wwmXRxF9gzLPqHNAisY68GB2KaVIb+zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠪࠤࠥࠦࠠࠩࠢࠪొ")+ulj9JfWhc0EgZbsm(dvZ0NWbkVhogcJI7qP2T)+lU1fSmncFWjizwqZugyYBANML0(u"ࠫࠥ࠯ࠧో")
			nFwolzUcBgh1jI6eCvtL3rNYJa += YXm2qAbu8Qsx(u"ࠬࠦࠠ࠭ࠢࠣࠫౌ")+X8wB92I4iKW0xOtVJTySrG
		elif Knc8GLhkpePT7xzH3gZtv1jbiEIRAs==ReLGYUQjz7C9iEd(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ్ࠬ"):
			g47FOfZJv2q = mHLBF2Mogbt7rWsCQ
			YQScZdn0aom3gGsKlz = wwmXRxF9gzLPqHNAisY68GB2KaVIb+lU1fSmncFWjizwqZugyYBANML0(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧ౎")+ulj9JfWhc0EgZbsm(dvZ0NWbkVhogcJI7qP2T)+Vi1oNCM5kI7yJ0(u"ࠨࠢࠬࠫ౏")
			WuMgZstkfGoQviAmDr1RzwIKbx6n7 = X8wB92I4iKW0xOtVJTySrG
	n8segRSX30jNwlC = n8segRSX30jNwlC.strip(yNBjYsgc23xoW(u"ࠩࠣࠤ࠱ࠦࠠࠨ౐"))
	nFwolzUcBgh1jI6eCvtL3rNYJa = nFwolzUcBgh1jI6eCvtL3rNYJa.strip(IYC4iPxkTRUE85namF6(u"ࠪࠤࠥ࠲ࠠࠡࠩ౑"))
	JJtaBWqkQOiCMsGofLxHurbNA4  = E3i1eCBtN2w(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ౒")+U2bWzwG8VdJsBqtR74ErDi3cg1v+IO93VvnfLhlCaNirBRuQXDzyH+u4IRSmrYMKkaHUBnDiLWh
	JJtaBWqkQOiCMsGofLxHurbNA4 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧ౓")+U2bWzwG8VdJsBqtR74ErDi3cg1v+XXhjqTU752kRGfZC1xcS+u4IRSmrYMKkaHUBnDiLWh
	JJtaBWqkQOiCMsGofLxHurbNA4 += DKmLTA2yGtj(u"࠭࡜࡯࡞ࡱࠫ౔")+Vi1oNCM5kI7yJ0(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤౕࠬ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+nFwolzUcBgh1jI6eCvtL3rNYJa+u4IRSmrYMKkaHUBnDiLWh
	JJtaBWqkQOiCMsGofLxHurbNA4 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+wFYiVd4r12x7CAQBL5SPof(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀౖࠠࠡࠢࠪ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+n8segRSX30jNwlC+u4IRSmrYMKkaHUBnDiLWh
	JJtaBWqkQOiCMsGofLxHurbNA4 += ee3tnwl7avk(u"ࠩ࡟ࡲࡡࡴࠧ౗")+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧౘ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+WuMgZstkfGoQviAmDr1RzwIKbx6n7+u4IRSmrYMKkaHUBnDiLWh
	JJtaBWqkQOiCMsGofLxHurbNA4 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+NIBsHMvSXb(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬౙ")+U2bWzwG8VdJsBqtR74ErDi3cg1v+YQScZdn0aom3gGsKlz+u4IRSmrYMKkaHUBnDiLWh
	mHLBF2Mogbt7rWsCQ = Bh8rPyR6UVjlQvY or PQynxCOHWs6z29ejLI
	if mHLBF2Mogbt7rWsCQ:
		header = ykE045Tatx(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧౚ")
		tKDGiWXJhlvcV14wr3E = dn9ouNryjHiBFQOhASvX(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧ౛")
	else:
		header = wFYiVd4r12x7CAQBL5SPof(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨ౜")
		tKDGiWXJhlvcV14wr3E = ttC4VURALPYKh(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪౝ")
	SoVXgAKrvukHyD98szGm = IYC4iPxkTRUE85namF6(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ౞")
	pWDA1s7LXiP5SCm = JJtaBWqkQOiCMsGofLxHurbNA4+yNBjYsgc23xoW(u"ࠪࡠࡳࡢ࡮ࠨ౟")+tKDGiWXJhlvcV14wr3E+qdEKO42r3GhwmCDcHtxzJUR(u"ࠫࡡࡴ࡜࡯ࠩౠ")+SoVXgAKrvukHyD98szGm
	ywuEego16R3ODiKVJr4Yf8qksH0vb(IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࡸࡩࡨࡪࡷࠫౡ"),header,pWDA1s7LXiP5SCm,IK4zTnSMyGQpxEaesJAPVDY(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩౢ"))
	return mHLBF2Mogbt7rWsCQ
def ccvXlqfQCTgbshKmGw64jd2V5(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,rVbiXKMU23PLBz6CAvsNcjtY7HD,showDialogs):
	oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
	if showDialogs:
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪౣ"),ZYTyoA483N(u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫ౤"))
		if jzydmKVUWrCv9D34F!=ttC4VURALPYKh(u"࠴൩"): return vvglE69OFKBm817Nkc
	VMnfE9mZhrd3bRAlYFak2wi6X5LQ = seYEjxGn1qkDZbXQtifpJLP3R(rVbiXKMU23PLBz6CAvsNcjtY7HD,{},showDialogs)
	if VMnfE9mZhrd3bRAlYFak2wi6X5LQ:
		VVkY50U1WtyMmLsCr = brAUlZfdFmt3TRJW2xX4.path.join(VlhreQLGKx3zN,Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
		eeiLrhbIvwnTuMo89ZOgEkJ(VVkY50U1WtyMmLsCr,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc)
		import zipfile as AXSUVcjRhKz7y831D,io as IKBwTCdaD7uWyG1HsSLoNe6
		HbA7iZsSf3285pgWBRuIE = IKBwTCdaD7uWyG1HsSLoNe6.BytesIO(VMnfE9mZhrd3bRAlYFak2wi6X5LQ)
		try:
			Om60dE7x2v1qiukCR9nf8sGMYpgQlt = AXSUVcjRhKz7y831D.ZipFile(HbA7iZsSf3285pgWBRuIE)
			Om60dE7x2v1qiukCR9nf8sGMYpgQlt.extractall(VlhreQLGKx3zN)
			LNma2eq3vEguwVtHjn.sleep(eCpDE6wJtYUHn0GqK5(u"࠵൪"))
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(x9PULjztJOpu7b(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭౥"))
			LNma2eq3vEguwVtHjn.sleep(IYC4iPxkTRUE85namF6(u"࠶൫"))
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = tfjuCKY824VkTibhaEcM(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
		except: oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
	if showDialogs:
		if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭౦"),ykE045Tatx(u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ౧"))
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౨"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ౩"))
	return oQE7jJVFnvtzbYAhSOc14qRXdKy9pD
def M9ZaLYTqERCo2(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,showDialogs=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy):
	if showDialogs==Zg9FeADE84jSRIvPCrzYulw3sL: showDialogs = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	caubiXgjl26koSURGFMs = yi4d8PrTLhG0HAsu2fXvwqbjpmRQxz([Knc8GLhkpePT7xzH3gZtv1jbiEIRAs])
	y0rPdaD4EGAMtfu1xVkQie8R7,A5N1J7SlWxFwHCgy = caubiXgjl26koSURGFMs[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs]
	if A5N1J7SlWxFwHCgy:
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vhZ5qjay1z94JmcMOgXe(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ౪"),ReLGYUQjz7C9iEd(u"ࠨใะูࠥอไฦุสๅฮࠦ࡜࡯ࠢࠪ౫")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+UixkloZbzGw28ujW56X(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬ౬"))
	else:
		oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = vvglE69OFKBm817Nkc
		jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠪࡧࡪࡴࡴࡦࡴࠪ౭"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ౮"),Zg9FeADE84jSRIvPCrzYulw3sL+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+ZYTyoA483N(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪ౯"))
		if jzydmKVUWrCv9D34F==vGg1hAkzqi8exVbN(u"࠷൬"):
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(ykE045Tatx(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭౰")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+qdEKO42r3GhwmCDcHtxzJUR(u"ࠧࠪࠩ౱"))
			LNma2eq3vEguwVtHjn.sleep(Vi1oNCM5kI7yJ0(u"࠱൭"))
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(ee3tnwl7avk(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ౲"))
			LNma2eq3vEguwVtHjn.sleep(wFYiVd4r12x7CAQBL5SPof(u"࠲൮"))
			while Zz9SeICTbPksXy6nuOtLGWhN2V.getCondVisibility(ttC4VURALPYKh(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭౳")): LNma2eq3vEguwVtHjn.sleep(UixkloZbzGw28ujW56X(u"࠳൯"))
			oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = tfjuCKY824VkTibhaEcM(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
			if showDialogs and oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭౴"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠫฯ๋ࠠโฯุࠤศ๎ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ౵"))
			elif showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yNBjYsgc23xoW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౶"),yNBjYsgc23xoW(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨ౷"))
	return oQE7jJVFnvtzbYAhSOc14qRXdKy9pD
def bbBVcKFz2wAE(showDialogs):
	if not showDialogs: jzydmKVUWrCv9D34F = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else: jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡤࡧࡱࡸࡪࡸࠧ౸"),Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,dn9ouNryjHiBFQOhASvX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ౹"),wFYiVd4r12x7CAQBL5SPof(u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩ౺"))
	if jzydmKVUWrCv9D34F==KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠴൰"):
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭౻"))
		if showDialogs:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ౼"),A2MHFvoqpZ64gNbB(u"ࠬะๅࠡวิืฬุ๊ࠠๆหࠤส๊้ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦวๅาํࠤๆ๐ࠠอ้สึ่ࠦไไ์ࠣ๎็๎ๅࠡสอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤ࠳ࠦศๆษࠣๅ๏ํวࠡฬะำ๏ั่ࠠาสࠤฬ๊ศา่ส้ั่ࠦหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬ౽"))
	return
def XXmGsWEunBUg63HhLa1VbKr2DfAoy():
	nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,ttC4VURALPYKh(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ౾"),DKmLTA2yGtj(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ౿"))
	eeVRf8BzbDr2yHLwAkU9px()
	mHLBF2Mogbt7rWsCQ = fMTNBcXtPoO5mFn0UIweZda1QS()
	if mHLBF2Mogbt7rWsCQ:
		vqmnhb5oQRglk0w4u(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		bbBVcKFz2wAE(CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		i5xGCIRvcQlMemuO4jaYkWSwtD(vvglE69OFKBm817Nkc)
	return
def tfjuCKY824VkTibhaEcM(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs):
	CsaNhTtGm8 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫಀ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+lU1fSmncFWjizwqZugyYBANML0(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧಁ"))
	succeeded = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if qdEKO42r3GhwmCDcHtxzJUR(u"ࠪࡓࡐ࠭ಂ") in CsaNhTtGm8 else vvglE69OFKBm817Nkc
	return succeeded
def cTSrsfa3uAD0Mdq5otULnh2YwCZzX(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs):
	CsaNhTtGm8 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC(ttC4VURALPYKh(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧಃ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡪࡦࡲࡳࡦࡿࢀࠫ಄"))
	succeeded = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if wFYiVd4r12x7CAQBL5SPof(u"࠭ࡏࡌࠩಅ") in CsaNhTtGm8 else vvglE69OFKBm817Nkc
	return succeeded
def aaEnC4rAS3uLHqx9owBhb1MzJjU(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,showDialogs,kyC0YLpfMWXJK,BchiTO0Hae9m6l4E1F=None):
	jzydmKVUWrCv9D34F,succeeded,w84aMg7jUcrZ5OGRbnEVBs9QIdvex,wwmXRxF9gzLPqHNAisY68GB2KaVIb = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc,lU1fSmncFWjizwqZugyYBANML0(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧಆ"),Zg9FeADE84jSRIvPCrzYulw3sL
	if not BchiTO0Hae9m6l4E1F: BchiTO0Hae9m6l4E1F = DUlT4qMG5tQd([Knc8GLhkpePT7xzH3gZtv1jbiEIRAs])
	if Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in list(BchiTO0Hae9m6l4E1F.keys()):
		mHLBF2Mogbt7rWsCQ,wwmXRxF9gzLPqHNAisY68GB2KaVIb,GGSVcEmnpj,X8wB92I4iKW0xOtVJTySrG,WRqLkgAySs,dvZ0NWbkVhogcJI7qP2T,rVbiXKMU23PLBz6CAvsNcjtY7HD = BchiTO0Hae9m6l4E1F[Knc8GLhkpePT7xzH3gZtv1jbiEIRAs]
		if dvZ0NWbkVhogcJI7qP2T==IYC4iPxkTRUE85namF6(u"ࠨࡩࡲࡳࡩ࠭ಇ"):
			succeeded,w84aMg7jUcrZ5OGRbnEVBs9QIdvex = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,yyZPkLCRX1xcBDN(u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪಈ")
			if kyC0YLpfMWXJK and showDialogs:
				jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ಉ"),vGg1hAkzqi8exVbN(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡๅ๋ำ๏๊ࠦิฬัำ๊ࠦรฯำࠣษฺีวา่ࠢฮํ็ัࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡๆ๊ิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫಊ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+ee3tnwl7avk(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัࠣษ฾อฯสࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦๅาหࠣวำื้ࠨಋ"))
				if jzydmKVUWrCv9D34F:
					succeeded = ccvXlqfQCTgbshKmGw64jd2V5(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,rVbiXKMU23PLBz6CAvsNcjtY7HD,vvglE69OFKBm817Nkc)
					if succeeded:
						w84aMg7jUcrZ5OGRbnEVBs9QIdvex = A2MHFvoqpZ64gNbB(u"࠭ࡲࡦ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫಌ")
						if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vGg1hAkzqi8exVbN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ಍"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊๎ฬ้ัฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษว฼หิฯࠠหอห๎ฯํว࡝ࡰ࡟ࡲࠬಎ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
					else:
						w84aMg7jUcrZ5OGRbnEVBs9QIdvex = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩಏ")
						I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ಐ"),okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫ಑")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
		else:
			if showDialogs:
				if dvZ0NWbkVhogcJI7qP2T==Vi1oNCM5kI7yJ0(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧಒ"): oHkimLnwDKNxlheUuGAMQIg9jY7dz = yyZPkLCRX1xcBDN(u"࠭ๅห๊ๅๅฮ࠭ಓ")
				elif dvZ0NWbkVhogcJI7qP2T==vhZ5qjay1z94JmcMOgXe(u"ࠧࡰ࡮ࡧࠫಔ"): oHkimLnwDKNxlheUuGAMQIg9jY7dz = ZYTyoA483N(u"ࠨไา๎๊ฯࠧಕ")
				elif dvZ0NWbkVhogcJI7qP2T==wFYiVd4r12x7CAQBL5SPof(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪಖ"): oHkimLnwDKNxlheUuGAMQIg9jY7dz = UQS9lVew50DIyXrinWsMxTzA(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ಗ")
				jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ttC4VURALPYKh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧಘ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠬํะ่ࠢส่ส฼วโหࠣࠫಙ")+oHkimLnwDKNxlheUuGAMQIg9jY7dz+qdEKO42r3GhwmCDcHtxzJUR(u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨಚ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
			if not jzydmKVUWrCv9D34F: w84aMg7jUcrZ5OGRbnEVBs9QIdvex = UQS9lVew50DIyXrinWsMxTzA(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩಛ")
			else:
				if dvZ0NWbkVhogcJI7qP2T==OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪಜ"):
					succeeded = tfjuCKY824VkTibhaEcM(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
					if succeeded:
						w84aMg7jUcrZ5OGRbnEVBs9QIdvex = ttC4VURALPYKh(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪಝ")
						if showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ee3tnwl7avk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ಞ"),Vi1oNCM5kI7yJ0(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩಟ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
					elif showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨಠ"),dn9ouNryjHiBFQOhASvX(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ษ฻อแส่ࠢฮํ่แสࠢ࠱࠲ࠥ๎ไๆࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩಡ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
				elif dvZ0NWbkVhogcJI7qP2T in [eCpDE6wJtYUHn0GqK5(u"ࠧࡰ࡮ࡧࠫಢ"),ZYTyoA483N(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩಣ")]:
					succeeded = ccvXlqfQCTgbshKmGw64jd2V5(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,rVbiXKMU23PLBz6CAvsNcjtY7HD,vvglE69OFKBm817Nkc)
					if succeeded:
						if dvZ0NWbkVhogcJI7qP2T==vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠩࡲࡰࡩ࠭ತ"): w84aMg7jUcrZ5OGRbnEVBs9QIdvex = ZYTyoA483N(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫಥ")
						elif dvZ0NWbkVhogcJI7qP2T==NIBsHMvSXb(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬದ"): w84aMg7jUcrZ5OGRbnEVBs9QIdvex = ReLGYUQjz7C9iEd(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨಧ")
						wwmXRxF9gzLPqHNAisY68GB2KaVIb = X8wB92I4iKW0xOtVJTySrG
						if showDialogs:
							if w84aMg7jUcrZ5OGRbnEVBs9QIdvex==tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧನ"): I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ಩"),lU1fSmncFWjizwqZugyYBANML0(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ็ี๊ๆหࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหฯา๎ะํว࡝ࡰ࡟ࡲࠬಪ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
							elif w84aMg7jUcrZ5OGRbnEVBs9QIdvex==IK4zTnSMyGQpxEaesJAPVDY(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬಫ"): I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,wFYiVd4r12x7CAQBL5SPof(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ಬ"),qdEKO42r3GhwmCDcHtxzJUR(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢ็้ࠥะใ็่ࠢ์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหอห๎ฯํว࡝ࡰ࡟ࡲࠬಭ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
					elif showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,qdEKO42r3GhwmCDcHtxzJUR(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨಮ"),A2MHFvoqpZ64gNbB(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩಯ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
	elif showDialogs: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZYTyoA483N(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪರ"),lU1fSmncFWjizwqZugyYBANML0(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ಱ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
	return succeeded,w84aMg7jUcrZ5OGRbnEVBs9QIdvex,wwmXRxF9gzLPqHNAisY68GB2KaVIb
def yGp3qEvI5PKOJxBCc(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,showDialogs,HoBOw7EeN2ZKyG3usX96jJ5,nnorqF3XlANRifQtxWm1jv=None,wxljEVBYCes0uWnzdZKDbhyI=None):
	ej6yQVk37gUOFIXtSNs08arE = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if nnorqF3XlANRifQtxWm1jv else vvglE69OFKBm817Nkc
	if not ej6yQVk37gUOFIXtSNs08arE:
		nnorqF3XlANRifQtxWm1jv = rNIFwicQYy7ZKf4XlzoP9Rj.connect(HHgE1pqyiM4W5)
		nnorqF3XlANRifQtxWm1jv.text_factory = str
		wxljEVBYCes0uWnzdZKDbhyI = nnorqF3XlANRifQtxWm1jv.cursor()
	succeeded,zGqXOMDsauPE = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,vvglE69OFKBm817Nkc
	try:
		yvzYuPaH7A5CnVkNSibxZW8IR6 = DKmLTA2yGtj(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫಲ")
		wxljEVBYCes0uWnzdZKDbhyI.execute(yNBjYsgc23xoW(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨಳ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+yyZPkLCRX1xcBDN(u"ࠫࠧࠦ࠻ࠨ಴"))
		eyGQZ6IzfoLwHdJajxUgC4ROW2pP = wxljEVBYCes0uWnzdZKDbhyI.fetchall()
		if eyGQZ6IzfoLwHdJajxUgC4ROW2pP and yvzYuPaH7A5CnVkNSibxZW8IR6 not in str(eyGQZ6IzfoLwHdJajxUgC4ROW2pP): wxljEVBYCes0uWnzdZKDbhyI.execute(yyZPkLCRX1xcBDN(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩವ")+yvzYuPaH7A5CnVkNSibxZW8IR6+UixkloZbzGw28ujW56X(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬಶ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧࠣࠢ࠾ࠫಷ"))
		mSTPOrbuZqyivXC9d6M3tGI5aH01hA = KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫಸ") if HByjTem6EJP5sZb else wFYiVd4r12x7CAQBL5SPof(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨಹ")
		wxljEVBYCes0uWnzdZKDbhyI.execute(lU1fSmncFWjizwqZugyYBANML0(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫ಺")+mSTPOrbuZqyivXC9d6M3tGI5aH01hA+x9PULjztJOpu7b(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ಻")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+IK4zTnSMyGQpxEaesJAPVDY(u"ࠬࠨࠠ࠼಼ࠩ"))
		eyGQZ6IzfoLwHdJajxUgC4ROW2pP = wxljEVBYCes0uWnzdZKDbhyI.fetchall()
		if eyGQZ6IzfoLwHdJajxUgC4ROW2pP:
			if showDialogs: jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,yyZPkLCRX1xcBDN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩಽ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫಾ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+lU1fSmncFWjizwqZugyYBANML0(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨಿ")+PPQORjT2lc7SVkKwFI4D+yyZPkLCRX1xcBDN(u"้ࠩࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫೀ")+u4IRSmrYMKkaHUBnDiLWh+IYC4iPxkTRUE85namF6(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨು"))
			else: jzydmKVUWrCv9D34F = Mn5NGAdz6xc42s0
			if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0:
				zGqXOMDsauPE = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				wxljEVBYCes0uWnzdZKDbhyI.execute(ReLGYUQjz7C9iEd(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪೂ")+mSTPOrbuZqyivXC9d6M3tGI5aH01hA+yyZPkLCRX1xcBDN(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪೃ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+lU1fSmncFWjizwqZugyYBANML0(u"࠭ࠢࠡ࠽ࠪೄ"))
		elif HoBOw7EeN2ZKyG3usX96jJ5:
			if showDialogs: jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ೅"),UQS9lVew50DIyXrinWsMxTzA(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬೆ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+dn9ouNryjHiBFQOhASvX(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩೇ")+PPQORjT2lc7SVkKwFI4D+UixkloZbzGw28ujW56X(u"ࠪࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠࠨೈ")+u4IRSmrYMKkaHUBnDiLWh+dn9ouNryjHiBFQOhASvX(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ೉"))
			else: jzydmKVUWrCv9D34F = Mn5NGAdz6xc42s0
			if jzydmKVUWrCv9D34F==Mn5NGAdz6xc42s0:
				zGqXOMDsauPE = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				if HByjTem6EJP5sZb: wxljEVBYCes0uWnzdZKDbhyI.execute(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫೊ")+mSTPOrbuZqyivXC9d6M3tGI5aH01hA+yyZPkLCRX1xcBDN(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ೋ")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࠣࠫࠣ࠿ࠬೌ"))
				else: wxljEVBYCes0uWnzdZKDbhyI.execute(YXm2qAbu8Qsx(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔ್ࠦࠧ")+mSTPOrbuZqyivXC9d6M3tGI5aH01hA+ReLGYUQjz7C9iEd(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭೎")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs+A2MHFvoqpZ64gNbB(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪ೏"))
	except: succeeded = vvglE69OFKBm817Nkc
	if showDialogs and zGqXOMDsauPE:
		if succeeded: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,x9PULjztJOpu7b(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ೐"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭೑")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,IYC4iPxkTRUE85namF6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ೒"),vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣฮาี๊ฬࠢส่ส฼วโหࠣࡠࡳࡢ࡮ࠨ೓")+Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
	if not ej6yQVk37gUOFIXtSNs08arE:
		nnorqF3XlANRifQtxWm1jv.commit()
		nnorqF3XlANRifQtxWm1jv.close()
		if zGqXOMDsauPE:
			LNma2eq3vEguwVtHjn.sleep(okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠵൱"))
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(yyZPkLCRX1xcBDN(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ೔"))
			LNma2eq3vEguwVtHjn.sleep(YXm2qAbu8Qsx(u"࠶൲"))
	return zGqXOMDsauPE
def JJpOAGQruMNTVz9m(wdBbhtlZ6WuY5,showDialogs,kyC0YLpfMWXJK,HoBOw7EeN2ZKyG3usX96jJ5):
	nnorqF3XlANRifQtxWm1jv = rNIFwicQYy7ZKf4XlzoP9Rj.connect(HHgE1pqyiM4W5)
	nnorqF3XlANRifQtxWm1jv.text_factory = str
	wxljEVBYCes0uWnzdZKDbhyI = nnorqF3XlANRifQtxWm1jv.cursor()
	BchiTO0Hae9m6l4E1F = DUlT4qMG5tQd(wdBbhtlZ6WuY5)
	qI1tVHpOFGA9KvaC5Tbg3jDxfWdMc = vvglE69OFKBm817Nkc
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in wdBbhtlZ6WuY5:
		succeeded,w84aMg7jUcrZ5OGRbnEVBs9QIdvex,wwmXRxF9gzLPqHNAisY68GB2KaVIb = aaEnC4rAS3uLHqx9owBhb1MzJjU(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,showDialogs,kyC0YLpfMWXJK,BchiTO0Hae9m6l4E1F)
		zGqXOMDsauPE = yGp3qEvI5PKOJxBCc(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs,showDialogs,HoBOw7EeN2ZKyG3usX96jJ5,nnorqF3XlANRifQtxWm1jv,wxljEVBYCes0uWnzdZKDbhyI)
		if zGqXOMDsauPE: qI1tVHpOFGA9KvaC5Tbg3jDxfWdMc = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	nnorqF3XlANRifQtxWm1jv.commit()
	nnorqF3XlANRifQtxWm1jv.close()
	if qI1tVHpOFGA9KvaC5Tbg3jDxfWdMc:
		LNma2eq3vEguwVtHjn.sleep(vGg1hAkzqi8exVbN(u"࠷൳"))
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin(vGg1hAkzqi8exVbN(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ೕ"))
		LNma2eq3vEguwVtHjn.sleep(Vi1oNCM5kI7yJ0(u"࠱൴"))
	if showDialogs:
		if len(wdBbhtlZ6WuY5)>ReLGYUQjz7C9iEd(u"࠲൵"): I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ೖ"),eCpDE6wJtYUHn0GqK5(u"ࠫฯ๋ࠠษ่ฯหาࠦแฮืࠣะ๊๐ูࠡษ็ษ฻อแศฬࠪ೗"))
		else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ೘"),lU1fSmncFWjizwqZugyYBANML0(u"࠭สๆࠢห๊ัออࠡใะูࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ೙")+wdBbhtlZ6WuY5[okWFdbYgPyj17Li3Bq5fpD6Q8nO0(u"࠲൶")])
	return
def vqmnhb5oQRglk0w4u(showDialogs):
	avTWSJfYs5XKk468eBAqG = [vGg1hAkzqi8exVbN(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ೚"),UixkloZbzGw28ujW56X(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ೛"),vGg1hAkzqi8exVbN(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭೜"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪೝ")]
	qJdOpKkiQBDNVtY8l25csM6w9m0 = [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴࡯ࡵࡪࡨࡶࡸ࠭ೞ"),A2MHFvoqpZ64gNbB(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡪ࠭೟"),ttC4VURALPYKh(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦࠩೠ"),wFYiVd4r12x7CAQBL5SPof(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩೡ"),jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩೢ"),vGg1hAkzqi8exVbN(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡨࡵࡤࡦࡤࡨࡶ࡬࠭ೣ")]
	for Knc8GLhkpePT7xzH3gZtv1jbiEIRAs in qJdOpKkiQBDNVtY8l25csM6w9m0: cTSrsfa3uAD0Mdq5otULnh2YwCZzX(Knc8GLhkpePT7xzH3gZtv1jbiEIRAs)
	JJpOAGQruMNTVz9m(avTWSJfYs5XKk468eBAqG,showDialogs,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	return
# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'KATKOUTE'
j0jSEdTPJuG4XNvfpO = '_KTK_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['الصفحة الرئيسية','Sign in','الأقسام']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==670: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==671: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==672: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==673: CsaNhTtGm8 = DhjI5w2TgXo(url,text)
	elif mode==674: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==679: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,679,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"navslide-divider"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,mode)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	items = hj3nmoDds5i679V2qKRN1vBMpAS8(qfzHe2Yr49+'/watch/browse.html')
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,674,W8KBRzkdhlCxvF5sY2T)
	return
def hj3nmoDds5i679V2qKRN1vBMpAS8(url):
	i3EyRQuIhemBb = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','KATKOUTE','CATEGORIES')
	if i3EyRQuIhemBb: return i3EyRQuIhemBb
	i3EyRQuIhemBb = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-CATEGORIES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"category-header"(.*?)<footer>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		i3EyRQuIhemBb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if i3EyRQuIhemBb: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'KATKOUTE','CATEGORIES',i3EyRQuIhemBb,ggWsYrlq8fy2v)
	return i3EyRQuIhemBb
def hkO9B6NystZxC1VDvWe(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"caret"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('"presentation"','</ul>')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = [(Zg9FeADE84jSRIvPCrzYulw3sL,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)]
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' فرز أو فلتر أو ترتيب '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		for K8L06TpijdQJUhz5co,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if K8L06TpijdQJUhz5co: K8L06TpijdQJUhz5co = K8L06TpijdQJUhz5co+': '
			for yDTPzhEBKVJl7CX81,title in items:
				title = K8L06TpijdQJUhz5co+title
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,671)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-category-subcats"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(items)<30:
			A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			for yDTPzhEBKVJl7CX81,title in items:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,671)
	if not vXCcUPg6OoWFdYSr and not sQPyfIOFgKLTU4u23XB6dmS9: mbzIyKNqMVt0FQeOsPWc(url)
	return
def mbzIyKNqMVt0FQeOsPWc(url,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	if YYAz8aPFGR2n=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-TITLES-1st')
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-TITLES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,items = Zg9FeADE84jSRIvPCrzYulw3sL,[]
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	if YYAz8aPFGR2n=='ajax-search':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((Zg9FeADE84jSRIvPCrzYulw3sL,yDTPzhEBKVJl7CX81,title))
	elif YYAz8aPFGR2n=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-video-watch-featured"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_episodes':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_movies':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(HNRenB3EZX62qgSKMd4f)>1: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[1]
	elif YYAz8aPFGR2n=='featured_series':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((Zg9FeADE84jSRIvPCrzYulw3sL,yDTPzhEBKVJl7CX81,title))
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(data-echo=".*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA and not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items: return
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,672,W8KBRzkdhlCxvF5sY2T)
		elif YYAz8aPFGR2n=='new_episodes':
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,672,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,673,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif '/movseries/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,671,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,673,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if yDTPzhEBKVJl7CX81=='#': continue
			if 'http' not in yDTPzhEBKVJl7CX81:
				hc5ePKxl4LJvEjDgTm = url.rsplit('/',1)[0]
				yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm+'/'+yDTPzhEBKVJl7CX81.strip('/')
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,671,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,YYAz8aPFGR2n)
	return
def DhjI5w2TgXo(url,fAzmnhNw7ToKEV6u4e5HUj):
	A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+'تشغيل الفيديو',url,672)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	i3EyRQuIhemBb = hj3nmoDds5i679V2qKRN1vBMpAS8(qfzHe2Yr49+'/watch/browse.html')
	OdCjx1zHLNy9YtUloiIVDPMghQq4,dWjh5KStXlP,i19abZkInQYFoqKf = zip(*i3EyRQuIhemBb)
	r9ZzDUniE8sI0Bt7Q6ax = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-EPISODES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-video-heading"(.*?)id="player"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in CPv45ibdnBc:
			if yDTPzhEBKVJl7CX81 not in OdCjx1zHLNy9YtUloiIVDPMghQq4:
				r1OMYvp0ViTG = (yDTPzhEBKVJl7CX81,title)
				r9ZzDUniE8sI0Bt7Q6ax.append(r1OMYvp0ViTG)
		if len(r9ZzDUniE8sI0Bt7Q6ax)==1:
			yDTPzhEBKVJl7CX81,title = r9ZzDUniE8sI0Bt7Q6ax[0]
			mbzIyKNqMVt0FQeOsPWc(yDTPzhEBKVJl7CX81,'new_episodes')
			return
		else:
			for yDTPzhEBKVJl7CX81,title in r9ZzDUniE8sI0Bt7Q6ax:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,671,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'new_episodes')
	if not r9ZzDUniE8sI0Bt7Q6ax: mbzIyKNqMVt0FQeOsPWc(url,'new_episodes')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0 = []
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'KATKOUTE-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sources:(.*?)flashplayer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('file: "(.*?)".*?label: "(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in CPv45ibdnBc:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named=__watch__'+YUCPADxT3NrgM
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"embedded-video".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not CPv45ibdnBc: CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("file: '(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if CPv45ibdnBc:
		yDTPzhEBKVJl7CX81 = CPv45ibdnBc[0]
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named=__embed')
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/watch/search.php?keywords='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
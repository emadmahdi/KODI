# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'DRAMACAFE'
j0jSEdTPJuG4XNvfpO = '_DCF_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['الصفحة الرئيسية','Sign in','تسجيل']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==930: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==931: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==932: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==933: CsaNhTtGm8 = DhjI5w2TgXo(url,text)
	elif mode==934: CsaNhTtGm8 = hkO9B6NystZxC1VDvWe(url)
	elif mode==939: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,939,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"navslide-wrap"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?</i>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,934)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('/category.php">(.*?)"navslide-divider"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''['"]dropdown-menu['"](.*?)</ul>''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for idOhoxawsrWQVgTMfGC6lBmDN7XEK in HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace(idOhoxawsrWQVgTMfGC6lBmDN7XEK,Zg9FeADE84jSRIvPCrzYulw3sL)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		if title in Uhe07PlWNakHDZc1t: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		title = BtKvPnEQJx32Z(title)
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,934)
	return
def hkO9B6NystZxC1VDvWe(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-SUBMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"caret"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if vXCcUPg6OoWFdYSr:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('"presentation"','</ul>')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = [(Zg9FeADE84jSRIvPCrzYulw3sL,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)]
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' فرز أو فلتر أو ترتيب '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
		for K8L06TpijdQJUhz5co,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if K8L06TpijdQJUhz5co: K8L06TpijdQJUhz5co = K8L06TpijdQJUhz5co+': '
			for yDTPzhEBKVJl7CX81,title in items:
				title = K8L06TpijdQJUhz5co+title
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,931)
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-category-subcats"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(items)<30:
			A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			for yDTPzhEBKVJl7CX81,title in items:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,931)
	if not vXCcUPg6OoWFdYSr and not sQPyfIOFgKLTU4u23XB6dmS9: mbzIyKNqMVt0FQeOsPWc(url)
	return
def mbzIyKNqMVt0FQeOsPWc(url,YYAz8aPFGR2n=Zg9FeADE84jSRIvPCrzYulw3sL):
	if YYAz8aPFGR2n=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-TITLES-1st')
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-TITLES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,items = Zg9FeADE84jSRIvPCrzYulw3sL,[]
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	if YYAz8aPFGR2n=='ajax-search':
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((Zg9FeADE84jSRIvPCrzYulw3sL,yDTPzhEBKVJl7CX81,title))
	elif YYAz8aPFGR2n=='featured':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-carousel_featured"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_episodes':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	elif YYAz8aPFGR2n=='new_movies':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"row pm-ul-browse-videos(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if len(HNRenB3EZX62qgSKMd4f)>1: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[1]
	elif YYAz8aPFGR2n=='featured_series':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(data-echo=".*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	if nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA and not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not items: return
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	uN2iWj1h3qsJOKlL5fQPprX = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in uN2iWj1h3qsJOKlL5fQPprX):
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,932,W8KBRzkdhlCxvF5sY2T)
		elif YYAz8aPFGR2n=='new_episodes':
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,932,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4:
			title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,933,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,933,W8KBRzkdhlCxvF5sY2T)
	if 1:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pagination(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81=='#': continue
				yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
				title = BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,931)
	return
def DhjI5w2TgXo(url,fAzmnhNw7ToKEV6u4e5HUj):
	Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-EPISODES-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	vXCcUPg6OoWFdYSr = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	EELGungxe6wKPar9hyRv5FUMpIB = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"pm-poster-img".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if EELGungxe6wKPar9hyRv5FUMpIB: W8KBRzkdhlCxvF5sY2T = EELGungxe6wKPar9hyRv5FUMpIB[0]
	else: W8KBRzkdhlCxvF5sY2T = Zg9FeADE84jSRIvPCrzYulw3sL
	items = []
	OPcSiDbsW3tNvCGTJehM = False
	if vXCcUPg6OoWFdYSr and not fAzmnhNw7ToKEV6u4e5HUj:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = vXCcUPg6OoWFdYSr[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for fAzmnhNw7ToKEV6u4e5HUj,title in items:
			fAzmnhNw7ToKEV6u4e5HUj = fAzmnhNw7ToKEV6u4e5HUj.strip('#')
			if len(items)>1: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,933,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,fAzmnhNw7ToKEV6u4e5HUj)
			else: OPcSiDbsW3tNvCGTJehM = True
	else: OPcSiDbsW3tNvCGTJehM = True
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="'+fAzmnhNw7ToKEV6u4e5HUj+'"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if sQPyfIOFgKLTU4u23XB6dmS9 and OPcSiDbsW3tNvCGTJehM:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		QaVoNlxzSUORpb = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		items = []
		for yDTPzhEBKVJl7CX81,title in QaVoNlxzSUORpb: items.append((yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T))
		if not items: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
			yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+'/'+yDTPzhEBKVJl7CX81.strip('/')
			title = title.replace('</em><span>',wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,932,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0,EaK7fXz6F9AbMJptQ12HlweoBd = [],[]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if 0 and 'post=' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="player".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
		L1LtcvTxI4q = yDTPzhEBKVJl7CX81.split('post=')[1]
		L1LtcvTxI4q = JDMo92nlwsAZydBPkpNzFvU.b64decode(L1LtcvTxI4q)
		if GGfPQnrJKEqMv2ZVxdD: L1LtcvTxI4q = L1LtcvTxI4q.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		L1LtcvTxI4q = JGmfjhoyKZUl('dict',L1LtcvTxI4q)
		CPv45ibdnBc = L1LtcvTxI4q['servers']
		WWuctLSlqizGgrK = list(CPv45ibdnBc.keys())
		CPv45ibdnBc = list(CPv45ibdnBc.values())
		F5nZmIVxBz3 = zip(WWuctLSlqizGgrK,CPv45ibdnBc)
		for title,yDTPzhEBKVJl7CX81 in F5nZmIVxBz3:
			if yDTPzhEBKVJl7CX81 not in EaK7fXz6F9AbMJptQ12HlweoBd:
				EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+title+'__watch'
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	if 1:
		hc5ePKxl4LJvEjDgTm = url.replace('watch.php','play.php')
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'DRAMACAFE-PLAY2-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[0]
			if yDTPzhEBKVJl7CX81 not in EaK7fXz6F9AbMJptQ12HlweoBd:
				EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
				m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__embed'
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"WatchList"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81 not in EaK7fXz6F9AbMJptQ12HlweoBd:
					EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
					yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__watch'
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
		if 'pm-download' not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			hc5ePKxl4LJvEjDgTm = url.replace('watch.php','downloads.php')
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,False,'DRAMACAFE-PLAY-2nd')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pm-download(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('download-url="(.*?)".*?<span>(.*?)</span>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81 not in EaK7fXz6F9AbMJptQ12HlweoBd:
					EaK7fXz6F9AbMJptQ12HlweoBd.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
					yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named='+m0t48jnKhrQFJViguoMl9NBPp+'__download'
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/search.php?keywords='+search
	mbzIyKNqMVt0FQeOsPWc(url,'search')
	return
# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from Kea9OSx7dZ import *
bIPsOxjEpoH = vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠪࡍࡓࡏࡔࠨൾ")
otaHZysOQ8JPXuUFV91l = NIBsHMvSXb(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠫൿ")
TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia = d2ickGMz45euLXJwAIxs7N(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
B1uLcTqVplZMydrfJb6RY9EaGUPv8 = int(My3un1OVBNfSQm)
cwMyvBgJuRXLWH48kpndbG7q2a = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel(qdEKO42r3GhwmCDcHtxzJUR(u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭඀"))
cwMyvBgJuRXLWH48kpndbG7q2a = cwMyvBgJuRXLWH48kpndbG7q2a.replace(MVtOGEXYcJLSjm4,Zg9FeADE84jSRIvPCrzYulw3sL).replace(FEftnphOJQY9dWI5iCoMj43zKbA,Zg9FeADE84jSRIvPCrzYulw3sL)
if B1uLcTqVplZMydrfJb6RY9EaGUPv8==A2MHFvoqpZ64gNbB(u"࠳࠸࠳ඦ"): ClzFsRVxfvW9dqXZpm = ee3tnwl7avk(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧඁ")+kI8qwbo6yER+JP65RzKaScIf(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧං")+UP58QEGLitwdp4qBDJozTu6V+E3i1eCBtN2w(u"ࠨࠢࡠࠫඃ")
else:
	YF8iAwIVnxdrKgkUQZpTMCByeHlX0u = UAjMPLdITqWChbrcB(ijrVgHOUMs5Bo0ehTA8FtvcyXJDa).replace(PPQORjT2lc7SVkKwFI4D,Zg9FeADE84jSRIvPCrzYulw3sL).replace(U2bWzwG8VdJsBqtR74ErDi3cg1v,Zg9FeADE84jSRIvPCrzYulw3sL)
	YF8iAwIVnxdrKgkUQZpTMCByeHlX0u = YF8iAwIVnxdrKgkUQZpTMCByeHlX0u.replace(u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
	YF8iAwIVnxdrKgkUQZpTMCByeHlX0u = YF8iAwIVnxdrKgkUQZpTMCByeHlX0u.replace(z1LI6x7aofZnmb,wjs26GpVfNiCUERHJ).replace(Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	ClzFsRVxfvW9dqXZpm = JP65RzKaScIf(u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨ඄")+cwMyvBgJuRXLWH48kpndbG7q2a+DKmLTA2yGtj(u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪඅ")+My3un1OVBNfSQm+vGg1hAkzqi8exVbN(u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫආ")+YF8iAwIVnxdrKgkUQZpTMCByeHlX0u+jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠬࠦ࡝ࠨඇ")
zOgQjNGH9yk1bXVRnofPvs(JfQX7SAvVrxZyRDgT,otaHZysOQ8JPXuUFV91l+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+VsYiARtQ2WToMq(bIPsOxjEpoH)+ClzFsRVxfvW9dqXZpm)
if vGg1hAkzqi8exVbN(u"࠭࡟ࠨඈ") in Zxb5IVorSH9j0avgd3UfR6KeC: F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv = Zxb5IVorSH9j0avgd3UfR6KeC.split(ttC4VURALPYKh(u"ࠧࡠࠩඉ"),E3i1eCBtN2w(u"࠳ට"))
else: F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv = Zxb5IVorSH9j0avgd3UfR6KeC,Zg9FeADE84jSRIvPCrzYulw3sL
B6ICRbTVXOQ1l4JsGxaFZy8AUvg2,o4be19ApMtCrdf5 = vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL
if F4FxmRe6UlfGHXP in [IK4zTnSMyGQpxEaesJAPVDY(u"ࠨ࠳ࠪඊ"),UQS9lVew50DIyXrinWsMxTzA(u"ࠩ࠵ࠫඋ"),UixkloZbzGw28ujW56X(u"ࠪ࠷ࠬඌ"),zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠫ࠹࠭ඍ"),IYC4iPxkTRUE85namF6(u"ࠬ࠻ࠧඎ"),JP65RzKaScIf(u"࠭࠱࠲ࠩඏ"),NIBsHMvSXb(u"ࠧ࠲࠴ࠪඐ"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"ࠨ࠳࠶ࠫඑ")] and (IYC4iPxkTRUE85namF6(u"ࠩࡄࡈࡉ࠭ඒ") in x7KDX8GywSYH6d0seM9F25ubhTLv or OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"ࠪࡖࡊࡓࡏࡗࡇࠪඓ") in x7KDX8GywSYH6d0seM9F25ubhTLv or NIBsHMvSXb(u"࡚ࠫࡖࠧඔ") in x7KDX8GywSYH6d0seM9F25ubhTLv or ttC4VURALPYKh(u"ࠬࡊࡏࡘࡐࠪඕ") in x7KDX8GywSYH6d0seM9F25ubhTLv):
	from DxXprMnf5t import ofJQjaukKYsph58G9
	ofJQjaukKYsph58G9(Zxb5IVorSH9j0avgd3UfR6KeC,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv)
	yUTYoAgth5iC43uLrdBH.setSetting(KpNYeI2Pd4nHJG3cOTvWjbSa(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪඖ"),ijrVgHOUMs5Bo0ehTA8FtvcyXJDa)
	B6ICRbTVXOQ1l4JsGxaFZy8AUvg2 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
elif not c7cZwUErDWgMbzvl51CVfsXYReA and B1uLcTqVplZMydrfJb6RY9EaGUPv8 in [tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠵࠷࠺ඨ"),tt8KsSi26LmWYVPxkMBl10dfRjXT(u"࠻࠶࠻ඩ")]:
	fpegTIEPJKtW = str(QsWU0ew5xMjBozVtqHAGDTNyL4Ia[Vi1oNCM5kI7yJ0(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ඗")])
	bIPsOxjEpoH = E3i1eCBtN2w(u"ࠨࡋࡓࡘ࡛࠭඘") if B1uLcTqVplZMydrfJb6RY9EaGUPv8==UixkloZbzGw28ujW56X(u"࠷࠹࠵ඪ") else jozVWcERh91GOF2NHXQiSwKqe8x(u"ࠩࡐ࠷࡚࠭඙")
	SB0e4TN3HZ6xJlv9W = bIPsOxjEpoH.lower()
	qoCMENGx4WgKp = yUTYoAgth5iC43uLrdBH.getSetting(x9PULjztJOpu7b(u"ࠪࡥࡻ࠴ࠧක")+SB0e4TN3HZ6xJlv9W+dn9ouNryjHiBFQOhASvX(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩඛ")+fpegTIEPJKtW)
	NNIKbSVi6Om372dg = yUTYoAgth5iC43uLrdBH.getSetting(dn9ouNryjHiBFQOhASvX(u"ࠬࡧࡶ࠯ࠩග")+SB0e4TN3HZ6xJlv9W+ee3tnwl7avk(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩඝ")+fpegTIEPJKtW)
	if qoCMENGx4WgKp or NNIKbSVi6Om372dg:
		ZTG4ruxXUsc9N += vv3sNE8XCU2RAiyVaueTbD950pz(u"ࠧࡽࠩඞ")
		if qoCMENGx4WgKp: ZTG4ruxXUsc9N += vhZ5qjay1z94JmcMOgXe(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧඟ")+qoCMENGx4WgKp
		if NNIKbSVi6Om372dg: ZTG4ruxXUsc9N += UixkloZbzGw28ujW56X(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬච")+NNIKbSVi6Om372dg
		ZTG4ruxXUsc9N = ZTG4ruxXUsc9N.replace(dn9ouNryjHiBFQOhASvX(u"ࠪࢀࠫ࠭ඡ"),IYC4iPxkTRUE85namF6(u"ࠫࢁ࠭ජ"))
	Ca2IhqLSj98Rxuert7Acb = yUTYoAgth5iC43uLrdBH.getSetting(Vi1oNCM5kI7yJ0(u"ࠬࡧࡶ࠯ࠩඣ")+SB0e4TN3HZ6xJlv9W+yyZPkLCRX1xcBDN(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨඤ")+fpegTIEPJKtW)
	if Ca2IhqLSj98Rxuert7Acb:
		EUg52dGoIqVBOsFR1Na = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(UQS9lVew50DIyXrinWsMxTzA(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪඥ"),ZTG4ruxXUsc9N,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		ZTG4ruxXUsc9N = ZTG4ruxXUsc9N.replace(EUg52dGoIqVBOsFR1Na[UwCT5Oz6Wo0BP],Ca2IhqLSj98Rxuert7Acb)
	nTdpZOCUe7l(ZTG4ruxXUsc9N,bIPsOxjEpoH,TeDLBxpO03aonZFfQbNuK9S)
else:
	import V1VREBsj92
	try: V1VREBsj92.NNCIgMS8jRE0WUuksBmOAehqy(TeDLBxpO03aonZFfQbNuK9S,Wo5ZqMiTYmSgUCvalXhRer4OjpP7,ZTG4ruxXUsc9N,My3un1OVBNfSQm,EELGungxe6wKPar9hyRv5FUMpIB,wlxviMOuNeQVct4ULsCEHXZm6yR2p,xQXoDIqn4Ucsthb2G7YpzwPTymi,Zxb5IVorSH9j0avgd3UfR6KeC,QsWU0ew5xMjBozVtqHAGDTNyL4Ia,B1uLcTqVplZMydrfJb6RY9EaGUPv8,F4FxmRe6UlfGHXP,x7KDX8GywSYH6d0seM9F25ubhTLv,cwMyvBgJuRXLWH48kpndbG7q2a)
	except Exception as TOJwE16IZS7Af: o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
	B6ICRbTVXOQ1l4JsGxaFZy8AUvg2 = V1VREBsj92.B6ICRbTVXOQ1l4JsGxaFZy8AUvg2
zUax4FJqAIfO5iWd(B6ICRbTVXOQ1l4JsGxaFZy8AUvg2,o4be19ApMtCrdf5)
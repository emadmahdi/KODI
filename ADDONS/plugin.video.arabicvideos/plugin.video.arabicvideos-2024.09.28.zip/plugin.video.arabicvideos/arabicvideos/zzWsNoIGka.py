# -*- coding: utf-8 -*-
import sys as cbzwJ3rLm0XhR52W7xoqE8Qljk
LLOux39NjCpeQwK1rcYbkHSAfVEs = cbzwJ3rLm0XhR52W7xoqE8Qljk.version_info [0] == 2
MAXaxzcY1HPR0puFeTmrVSqs = 2048
A7UOVohx8wZIET = 7
def FFc5qHYBCp72miwJojUxg8Aev (rP9RLYHdWVsU1acOhpzbw6yTlQI):
	global eek7Ldr0AWvTtQ
	KHzwtcrBljmZCfd = ord (rP9RLYHdWVsU1acOhpzbw6yTlQI [-1])
	kkeflaOhRZVgAHUCirucxSGTzX = rP9RLYHdWVsU1acOhpzbw6yTlQI [:-1]
	Kzj7HNQD2L = KHzwtcrBljmZCfd % len (kkeflaOhRZVgAHUCirucxSGTzX)
	MMbvmrBRK50h = kkeflaOhRZVgAHUCirucxSGTzX [:Kzj7HNQD2L] + kkeflaOhRZVgAHUCirucxSGTzX [Kzj7HNQD2L:]
	if LLOux39NjCpeQwK1rcYbkHSAfVEs:
		FkJWYD5yOhefnwoit7qmU03GAzs = unicode () .join ([unichr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	else:
		FkJWYD5yOhefnwoit7qmU03GAzs = str () .join ([chr (ord (Do5EP6JVQUHxLBbhp) - MAXaxzcY1HPR0puFeTmrVSqs - (QQtloOjC3quLgYyWRXFV + KHzwtcrBljmZCfd) % A7UOVohx8wZIET) for QQtloOjC3quLgYyWRXFV, Do5EP6JVQUHxLBbhp in enumerate (MMbvmrBRK50h)])
	return eval (FkJWYD5yOhefnwoit7qmU03GAzs)
KpNYeI2Pd4nHJG3cOTvWjbSa,vhZ5qjay1z94JmcMOgXe,tt8KsSi26LmWYVPxkMBl10dfRjXT=FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev,FFc5qHYBCp72miwJojUxg8Aev
NIBsHMvSXb,ZYTyoA483N,ttC4VURALPYKh=tt8KsSi26LmWYVPxkMBl10dfRjXT,vhZ5qjay1z94JmcMOgXe,KpNYeI2Pd4nHJG3cOTvWjbSa
E3i1eCBtN2w,vv3sNE8XCU2RAiyVaueTbD950pz,lU1fSmncFWjizwqZugyYBANML0=ttC4VURALPYKh,ZYTyoA483N,NIBsHMvSXb
YXm2qAbu8Qsx,ykE045Tatx,yyZPkLCRX1xcBDN=lU1fSmncFWjizwqZugyYBANML0,vv3sNE8XCU2RAiyVaueTbD950pz,E3i1eCBtN2w
ee3tnwl7avk,wFYiVd4r12x7CAQBL5SPof,A2MHFvoqpZ64gNbB=yyZPkLCRX1xcBDN,ykE045Tatx,YXm2qAbu8Qsx
IK4zTnSMyGQpxEaesJAPVDY,UQS9lVew50DIyXrinWsMxTzA,jozVWcERh91GOF2NHXQiSwKqe8x=A2MHFvoqpZ64gNbB,wFYiVd4r12x7CAQBL5SPof,ee3tnwl7avk
x9PULjztJOpu7b,Vi1oNCM5kI7yJ0,UixkloZbzGw28ujW56X=jozVWcERh91GOF2NHXQiSwKqe8x,UQS9lVew50DIyXrinWsMxTzA,IK4zTnSMyGQpxEaesJAPVDY
DKmLTA2yGtj,IYC4iPxkTRUE85namF6,dn9ouNryjHiBFQOhASvX=UixkloZbzGw28ujW56X,Vi1oNCM5kI7yJ0,x9PULjztJOpu7b
ReLGYUQjz7C9iEd,qdEKO42r3GhwmCDcHtxzJUR,okWFdbYgPyj17Li3Bq5fpD6Q8nO0=dn9ouNryjHiBFQOhASvX,IYC4iPxkTRUE85namF6,DKmLTA2yGtj
eCpDE6wJtYUHn0GqK5,zaOkgPnGLs6biVDuTjdCFrwefcqN,vGg1hAkzqi8exVbN=okWFdbYgPyj17Li3Bq5fpD6Q8nO0,qdEKO42r3GhwmCDcHtxzJUR,ReLGYUQjz7C9iEd
JP65RzKaScIf,yNBjYsgc23xoW,OOQeLIFBCbkV8fnq3m4Tl50UhDj=vGg1hAkzqi8exVbN,zaOkgPnGLs6biVDuTjdCFrwefcqN,eCpDE6wJtYUHn0GqK5
from V1VREBsj92 import *
ZXWeI01flR(vv3sNE8XCU2RAiyVaueTbD950pz(u"࡙ࠫࡋࡓࡕࠩ൸"),KpNYeI2Pd4nHJG3cOTvWjbSa(u"࡚ࠬࡅࡔࡖࠪ൹"))
U6Lfok2vKIGRJejl5qzxMtC4iYOA = OOQeLIFBCbkV8fnq3m4Tl50UhDj(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡸ࠷࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡩ࡫ࡱ࡯ࡧࡸ࡯ࡢࡦࡥࡥࡳࡪ࠮ࡤࡱࡰ࠳࠶࠶ࡍࡃ࠰ࡽ࡭ࡵ࠭ൺ")
U6Lfok2vKIGRJejl5qzxMtC4iYOA = ReLGYUQjz7C9iEd(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡨࡩࡩࡺࡥࡴࡶ࠱ࡪࡹࡶ࠮ࡰࡶࡨࡲࡪࡺ࠮ࡨࡴ࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡩࡸࡺ࠱࠱࠲࡮࠲ࡩࡨࠧൻ")
seYEjxGn1qkDZbXQtifpJLP3R(U6Lfok2vKIGRJejl5qzxMtC4iYOA,{},CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
tUHrEcLYK30N = UixkloZbzGw28ujW56X(u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ๅา฻࠮࡮ࡲ࠶ࠫർ")
tUHrEcLYK30N = zaOkgPnGLs6biVDuTjdCFrwefcqN(u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠ࡫࡯࡬ࡦࡡ࠷࠼࠸࠺࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧൽ")
# -*- coding: utf-8 -*-
from V1VREBsj92 import *
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
bIPsOxjEpoH = 'AKWAM'
j0jSEdTPJuG4XNvfpO = '_AKW_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
fhzIDTylX3vNnmUwaJBuEGFA826pL = Zg9FeADE84jSRIvPCrzYulw3sL
Uhe07PlWNakHDZc1t = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==240: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==241: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==242: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==243: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==244: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'FILTERS___'+text)
	elif mode==245: CsaNhTtGm8 = sF8AGonNID9x0J3TSUL2hd1Qjv(url,'CATEGORIES___'+text)
	elif mode==246: CsaNhTtGm8 = wM8Tf2sueEvmJPGLF65nWZY39KoBy1(url)
	elif mode==247: CsaNhTtGm8 = vPdWhb3FQmwcjr0xk(url)
	elif mode==248: CsaNhTtGm8 = rKTWHmDuA3PMOlInkUz()
	elif mode==249: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def rKTWHmDuA3PMOlInkUz():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'AKWAM-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Grq0xVpBTJ5D6RLc1 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('home-site-btn-container.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if Grq0xVpBTJ5D6RLc1: Grq0xVpBTJ5D6RLc1 = Grq0xVpBTJ5D6RLc1[0]
	else: Grq0xVpBTJ5D6RLc1 = qfzHe2Yr49
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',Grq0xVpBTJ5D6RLc1,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'AKWAM-MENU-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,249,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر محدد',qfzHe2Yr49,246)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'فلتر كامل',qfzHe2Yr49,247)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',Grq0xVpBTJ5D6RLc1,241,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured')
	recent = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('recently-container.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	yDTPzhEBKVJl7CX81 = recent[0]
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'أضيف حديثا',yDTPzhEBKVJl7CX81,241)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,name,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
		if name in Uhe07PlWNakHDZc1t: continue
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+name,yDTPzhEBKVJl7CX81,241)
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title in Uhe07PlWNakHDZc1t: continue
			title = name+wjs26GpVfNiCUERHJ+title
			A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,241)
	return
def wM8Tf2sueEvmJPGLF65nWZY39KoBy1(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKWAM-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="menu(.*?)<nav',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?text">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t:
				title = title+' مصنفة'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,245)
		if website==Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def vPdWhb3FQmwcjr0xk(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'AKWAM-MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="menu(.*?)<nav',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?text">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title not in Uhe07PlWNakHDZc1t:
				title = title+' مفلترة'
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,244)
		if website==Zg9FeADE84jSRIvPCrzYulw3sL: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('swiper-container(.*?)swiper-button-prev',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="widget"(.*?)main-footer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not items:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,title in items:
			if '/series/' in yDTPzhEBKVJl7CX81 or '/shows/' in yDTPzhEBKVJl7CX81:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,242,W8KBRzkdhlCxvF5sY2T)
			elif '/movies/' in yDTPzhEBKVJl7CX81:
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,243,W8KBRzkdhlCxvF5sY2T)
			elif '/games/' not in yDTPzhEBKVJl7CX81:
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,243,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			yDTPzhEBKVJl7CX81 = BtKvPnEQJx32Z(yDTPzhEBKVJl7CX81)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,241)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'%20')
	url = qfzHe2Yr49 + '/search?q='+IGh3FSLfnog2BjN8s
	CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url)
	return
def dHjny9tTucrO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		W8KBRzkdhlCxvF5sY2T = Zz9SeICTbPksXy6nuOtLGWhN2V.getInfoLabel('ListItem.Icon')
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+'رابط التشغيل',url,243,W8KBRzkdhlCxvF5sY2T)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('-episodes">(.*?)<div class="widget-4',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		bbl9kf1oL2 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in bbl9kf1oL2:
			title = title.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in yDTPzhEBKVJl7CX81: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,242,W8KBRzkdhlCxvF5sY2T)
			else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,243,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKWAM-PLAY-1st')
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('badge-danger.*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	DtQKml7HMgNaGFCXbVszIBu62P = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('li><a href="#(.*?)".*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	fo6s53yEnbklLpaJOzgR4Q01wxB,nnhWEIa6Tm,qLx93JtrVCHlKaZW2hXc7dpiNmDR,vZrGBS8uyMNa = [],[],[],[]
	if DtQKml7HMgNaGFCXbVszIBu62P:
		QAHN1PzTaF = 'mp4'
		for kJpxMN8ctml0RnvywseTufj,YUCPADxT3NrgM in DtQKml7HMgNaGFCXbVszIBu62P:
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('tab-content quality" id="'+kJpxMN8ctml0RnvywseTufj+'".*?</div>.\s*</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			qLx93JtrVCHlKaZW2hXc7dpiNmDR.append(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
			vZrGBS8uyMNa.append(YUCPADxT3NrgM)
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="qualities(.*?)<h3.*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f:
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,filename = HNRenB3EZX62qgSKMd4f[0]
			HnfIu8gMJF2mOWzv03hPAKs5TZ7G = ['zip','rar','txt','pdf','htm','tar','iso','html']
			QAHN1PzTaF = filename.rsplit('.',1)[1].strip(wjs26GpVfNiCUERHJ)
			if QAHN1PzTaF in HnfIu8gMJF2mOWzv03hPAKs5TZ7G:
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		qLx93JtrVCHlKaZW2hXc7dpiNmDR.append(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
		vZrGBS8uyMNa.append(Zg9FeADE84jSRIvPCrzYulw3sL)
	for YjZN3ADmertFahUQIECW in range(len(qLx93JtrVCHlKaZW2hXc7dpiNmDR)):
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?icon-(.*?)"',qLx93JtrVCHlKaZW2hXc7dpiNmDR[YjZN3ADmertFahUQIECW],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,t4dKabzjNnYP5wEAk37Bmv in CPv45ibdnBc:
			if 'torrent' in t4dKabzjNnYP5wEAk37Bmv: continue
			elif 'download' in t4dKabzjNnYP5wEAk37Bmv: type = 'download'
			elif 'play' in t4dKabzjNnYP5wEAk37Bmv: type = 'watch'
			else: type = 'unknown'
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'?named=__'+type+'____'+vZrGBS8uyMNa[YjZN3ADmertFahUQIECW]+'__akwam'
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def sF8AGonNID9x0J3TSUL2hd1Qjv(url,filter):
	yycVIo28p69ZU3XRaCbYdP = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==Zg9FeADE84jSRIvPCrzYulw3sL: oorcIqYuTf6,LeoFXqubIsNmlZ0 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	else: oorcIqYuTf6,LeoFXqubIsNmlZ0 = filter.split('___')
	if type=='CATEGORIES':
		if yycVIo28p69ZU3XRaCbYdP[0]+'=' not in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[0]
		for YjZN3ADmertFahUQIECW in range(len(yycVIo28p69ZU3XRaCbYdP[0:-1])):
			if yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW]+'=' in oorcIqYuTf6: WWdHIOCPeKmgRstXk4c = yycVIo28p69ZU3XRaCbYdP[YjZN3ADmertFahUQIECW+1]
		PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+WWdHIOCPeKmgRstXk4c+'=0'
		JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL.strip('&')+'___'+OOYBCTKMVyFR3lpLNP.strip('&')
		YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'all')
		hc5ePKxl4LJvEjDgTm = url+'?'+YYwyLpO9f2Do7rztliJ3qFnscT
	elif type=='FILTERS':
		KK2pncrBCsGVagozjlQIb5dAD7k = kt4gOnZ7y6A0ifpW1L8VJFDaR(oorcIqYuTf6,'modified_values')
		KK2pncrBCsGVagozjlQIb5dAD7k = UAjMPLdITqWChbrcB(KK2pncrBCsGVagozjlQIb5dAD7k)
		if LeoFXqubIsNmlZ0!=Zg9FeADE84jSRIvPCrzYulw3sL: LeoFXqubIsNmlZ0 = kt4gOnZ7y6A0ifpW1L8VJFDaR(LeoFXqubIsNmlZ0,'all')
		if LeoFXqubIsNmlZ0==Zg9FeADE84jSRIvPCrzYulw3sL: hc5ePKxl4LJvEjDgTm = url
		else: hc5ePKxl4LJvEjDgTm = url+'?'+LeoFXqubIsNmlZ0
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'أظهار قائمة الفيديو التي تم اختيارها',hc5ePKxl4LJvEjDgTm,241,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+' [[   '+KK2pncrBCsGVagozjlQIb5dAD7k+'   ]]',hc5ePKxl4LJvEjDgTm,241,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
		A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,True,'AKWAM-FILTERS_MENU-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<form id(.*?)</form>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	wAsQoW6l1DitrY7MC = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	dict = {}
	for ddFeJa6wxq2zNMPsjth9bZAmVO,name,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in wAsQoW6l1DitrY7MC:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<option(.*?)>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if '=' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = url
		if type=='CATEGORIES':
			if WWdHIOCPeKmgRstXk4c!=ddFeJa6wxq2zNMPsjth9bZAmVO: continue
			elif len(items)<=1:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: mbzIyKNqMVt0FQeOsPWc(hc5ePKxl4LJvEjDgTm)
				else: sF8AGonNID9x0J3TSUL2hd1Qjv(hc5ePKxl4LJvEjDgTm,'CATEGORIES___'+JDm4zR9r37vHg)
				return
			else:
				if ddFeJa6wxq2zNMPsjth9bZAmVO==yycVIo28p69ZU3XRaCbYdP[-1]: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,241,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
				else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',hc5ePKxl4LJvEjDgTm,245,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		elif type=='FILTERS':
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'=0'
			JDm4zR9r37vHg = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع : '+name,hc5ePKxl4LJvEjDgTm,244,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,JDm4zR9r37vHg)
		dict[ddFeJa6wxq2zNMPsjth9bZAmVO] = {}
		for B251BPiLbvG9UxszKtlI7YQHmoWw,xWfrLDQiMOA358ghbsZk6PtSK in items:
			if xWfrLDQiMOA358ghbsZk6PtSK in Uhe07PlWNakHDZc1t: continue
			if 'value' not in B251BPiLbvG9UxszKtlI7YQHmoWw: B251BPiLbvG9UxszKtlI7YQHmoWw = xWfrLDQiMOA358ghbsZk6PtSK
			else: B251BPiLbvG9UxszKtlI7YQHmoWw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(.*?)"',B251BPiLbvG9UxszKtlI7YQHmoWw,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
			dict[ddFeJa6wxq2zNMPsjth9bZAmVO][B251BPiLbvG9UxszKtlI7YQHmoWw] = xWfrLDQiMOA358ghbsZk6PtSK
			PmfFyer7RA4Bod9Jx8GaH6DL = oorcIqYuTf6+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+xWfrLDQiMOA358ghbsZk6PtSK
			OOYBCTKMVyFR3lpLNP = LeoFXqubIsNmlZ0+'&'+ddFeJa6wxq2zNMPsjth9bZAmVO+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
			OOiZSE1AIGsxBp0PqUo4bHgQ8u7 = PmfFyer7RA4Bod9Jx8GaH6DL+'___'+OOYBCTKMVyFR3lpLNP
			title = xWfrLDQiMOA358ghbsZk6PtSK+' : '#+dict[ddFeJa6wxq2zNMPsjth9bZAmVO]['0']
			title = xWfrLDQiMOA358ghbsZk6PtSK+' : '+name
			if type=='FILTERS': A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,244,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
			elif type=='CATEGORIES' and yycVIo28p69ZU3XRaCbYdP[-2]+'=' in oorcIqYuTf6:
				YYwyLpO9f2Do7rztliJ3qFnscT = kt4gOnZ7y6A0ifpW1L8VJFDaR(OOYBCTKMVyFR3lpLNP,'all')
				JaqiYfEglZDvmwQNS8zR = url+'?'+YYwyLpO9f2Do7rztliJ3qFnscT
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,JaqiYfEglZDvmwQNS8zR,241,Zg9FeADE84jSRIvPCrzYulw3sL,'1')
			else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,245,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,OOiZSE1AIGsxBp0PqUo4bHgQ8u7)
	return
def kt4gOnZ7y6A0ifpW1L8VJFDaR(fn9dgJ0v1KVrZ,mode):
	fn9dgJ0v1KVrZ = fn9dgJ0v1KVrZ.strip('&')
	vJfWILDinBuPZjcUamEHlq = {}
	if '=' in fn9dgJ0v1KVrZ:
		items = fn9dgJ0v1KVrZ.split('&')
		for r1OMYvp0ViTG in items:
			MnwlGZ9Ef3S7kv5sxtzRiFaoCIb,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=')
			vJfWILDinBuPZjcUamEHlq[MnwlGZ9Ef3S7kv5sxtzRiFaoCIb] = B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = Zg9FeADE84jSRIvPCrzYulw3sL
	A7qnSMrihGeFTKZL8zmODNv1U = ['section','category','rating','year','language','formats','quality']
	for key in A7qnSMrihGeFTKZL8zmODNv1U:
		if key in list(vJfWILDinBuPZjcUamEHlq.keys()): B251BPiLbvG9UxszKtlI7YQHmoWw = vJfWILDinBuPZjcUamEHlq[key]
		else: B251BPiLbvG9UxszKtlI7YQHmoWw = '0'
		if mode=='modified_values' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+' + '+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='modified_filters' and B251BPiLbvG9UxszKtlI7YQHmoWw!='0': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
		elif mode=='all': PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh+'&'+key+'='+B251BPiLbvG9UxszKtlI7YQHmoWw
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip(' + ')
	PJlIOHanFyNWTgfswRdYXvei4x0Vh = PJlIOHanFyNWTgfswRdYXvei4x0Vh.strip('&')
	return PJlIOHanFyNWTgfswRdYXvei4x0Vh
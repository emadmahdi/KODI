# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'RESOLVERS'
KSvGVmHDLlIuUZfJ = []
headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
def PayeNkwilE7tGdLcQOngopvqu(ZZH6czYDb0,source,type,url):
	if not ZZH6czYDb0:
		zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		SMTDPAE4eWq6g8ZiCdft = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'dict','MISC_PERM','SITES_ERRORS')
		II79SczUa2VOMP8DXBtmgA4Yq6KxZo = LNma2eq3vEguwVtHjn.strftime('%Y.%m.%d %H:%M',LNma2eq3vEguwVtHjn.gmtime(PPc8zbiVZnFkfXLBRv))
		Eh9DwNXB3LFnz1P = II79SczUa2VOMP8DXBtmgA4Yq6KxZo,url
		key = source+z1LI6x7aofZnmb+kI8qwbo6yER+z1LI6x7aofZnmb+str(NGiBmYp8vX9T426lHn7ue)
		oHkimLnwDKNxlheUuGAMQIg9jY7dz = Zg9FeADE84jSRIvPCrzYulw3sL
		if key not in list(SMTDPAE4eWq6g8ZiCdft.keys()): SMTDPAE4eWq6g8ZiCdft[key] = [Eh9DwNXB3LFnz1P]
		else:
			if url not in str(SMTDPAE4eWq6g8ZiCdft[key]): SMTDPAE4eWq6g8ZiCdft[key].append(Eh9DwNXB3LFnz1P)
			else: oHkimLnwDKNxlheUuGAMQIg9jY7dz = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		CSq3HMRKbsLnUZA1zV5e4cGQrDp = UwCT5Oz6Wo0BP
		for key in list(SMTDPAE4eWq6g8ZiCdft.keys()):
			SMTDPAE4eWq6g8ZiCdft[key] = list(set(SMTDPAE4eWq6g8ZiCdft[key]))
			CSq3HMRKbsLnUZA1zV5e4cGQrDp += len(SMTDPAE4eWq6g8ZiCdft[key])
		I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+oHkimLnwDKNxlheUuGAMQIg9jY7dz+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(CSq3HMRKbsLnUZA1zV5e4cGQrDp))
		if CSq3HMRKbsLnUZA1zV5e4cGQrDp>=5:
			jzydmKVUWrCv9D34F = EiOpncsbPr8qQzGodeW(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if jzydmKVUWrCv9D34F==1:
				QMDFxHB98NcLjbfdsvIJhRog0 = Zg9FeADE84jSRIvPCrzYulw3sL
				for key in list(SMTDPAE4eWq6g8ZiCdft.keys()):
					QMDFxHB98NcLjbfdsvIJhRog0 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+key
					ukmadLUcENb47iIhpzV1J = sorted(SMTDPAE4eWq6g8ZiCdft[key],reverse=vvglE69OFKBm817Nkc,key=lambda YHcj1fekJSbi908n6WZL4AyhT: YHcj1fekJSbi908n6WZL4AyhT[UwCT5Oz6Wo0BP])
					for II79SczUa2VOMP8DXBtmgA4Yq6KxZo,url in ukmadLUcENb47iIhpzV1J:
						QMDFxHB98NcLjbfdsvIJhRog0 += SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+II79SczUa2VOMP8DXBtmgA4Yq6KxZo+z1LI6x7aofZnmb+UAjMPLdITqWChbrcB(url)
					QMDFxHB98NcLjbfdsvIJhRog0 += '\n\n'
				import XUbpWe5mRd
				oQE7jJVFnvtzbYAhSOc14qRXdKy9pD = XUbpWe5mRd.XO1DeBA3qJgjH0syEZua('Videos',Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-PLAY_RESOLVERS',Zg9FeADE84jSRIvPCrzYulw3sL,QMDFxHB98NcLjbfdsvIJhRog0)
				if oQE7jJVFnvtzbYAhSOc14qRXdKy9pD: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','تم الإرسال بنجاح')
				else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','فشلت عملية الإرسال')
			if jzydmKVUWrCv9D34F!=-Mn5NGAdz6xc42s0:
				SMTDPAE4eWq6g8ZiCdft = {}
				nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'MISC_PERM','SITES_ERRORS')
		if SMTDPAE4eWq6g8ZiCdft: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'MISC_PERM','SITES_ERRORS',SMTDPAE4eWq6g8ZiCdft,B4GWT7zonF5yipbIwJmNUf6Vavg)
		return
	ZZH6czYDb0 = list(set(ZZH6czYDb0))
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = VVPSsRdu7YDg84qJLK(ZZH6czYDb0,source)
	zzej8q36QhUyEAROVvwBkplrWIu9 = str(fo6s53yEnbklLpaJOzgR4Q01wxB).count('__watch')
	knXbNZvyDe = str(fo6s53yEnbklLpaJOzgR4Q01wxB).count('__download')
	gsKn7qAoy0O = len(fo6s53yEnbklLpaJOzgR4Q01wxB)-zzej8q36QhUyEAROVvwBkplrWIu9-knXbNZvyDe
	gCdVXMcJEARlIkUr6KOBjZumvsYfyx = 'مشاهدة:'+str(zzej8q36QhUyEAROVvwBkplrWIu9)+'    تحميل:'+str(knXbNZvyDe)+'    أخرى:'+str(gsKn7qAoy0O)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: Tbl0qZIrG9p,VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'unresolved',Zg9FeADE84jSRIvPCrzYulw3sL
	else:
		add = UwCT5Oz6Wo0BP
		if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in source for B251BPiLbvG9UxszKtlI7YQHmoWw in KfBl67yc98):
			add = Mn5NGAdz6xc42s0
			fo6s53yEnbklLpaJOzgR4Q01wxB = ['RESOLVE_ALL_LINKS']+list(fo6s53yEnbklLpaJOzgR4Q01wxB)
			nnhWEIa6Tm = [PPQORjT2lc7SVkKwFI4D+'فحص جميع السيرفرات'+u4IRSmrYMKkaHUBnDiLWh]+list(nnhWEIa6Tm)
		while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			VLa3Uijkb0vXeJSWcrPf8KOlz4uA,Tbl0qZIrG9p = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
			if XcPLKthYTV.resolveonly: add,lqQvOUWodZnhXLS2Vcuj6EtairFN = Mn5NGAdz6xc42s0,UwCT5Oz6Wo0BP
			elif add and len(fo6s53yEnbklLpaJOzgR4Q01wxB)==DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = Mn5NGAdz6xc42s0
			else: lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(gCdVXMcJEARlIkUr6KOBjZumvsYfyx,nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: Tbl0qZIrG9p = 'canceled_1st_menu'
			elif add and lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP:
				Tbl0qZIrG9p = 'canceled_2nd_menu'
				CsaNhTtGm8 = oMgiPWkxtO(nnhWEIa6Tm[add:],fo6s53yEnbklLpaJOzgR4Q01wxB[add:],source)
				if XcPLKthYTV.resolveonly: return
				if CsaNhTtGm8:
					I8quXCKm40 = []
					for TMWIQ9soPr,Lx0JNzMogifQkWXa5KvGmcITEt,ChB6D2xfQRbr4YZtI0E7ocHz1saqX,a0Dr8FhlHk6TUMIzvgRABi5237C9e,HQym2lRFU0dWTjvY9Z1SsK in CsaNhTtGm8:
						if HQym2lRFU0dWTjvY9Z1SsK: I8quXCKm40.append((TMWIQ9soPr,Lx0JNzMogifQkWXa5KvGmcITEt,ChB6D2xfQRbr4YZtI0E7ocHz1saqX,a0Dr8FhlHk6TUMIzvgRABi5237C9e,HQym2lRFU0dWTjvY9Z1SsK))
					if I8quXCKm40: nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errors,WWuctLSlqizGgrK,CPv45ibdnBc = zip(*I8quXCKm40)
					else:
						I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						Tbl0qZIrG9p = 'failed'
						break
					gCdVXMcJEARlIkUr6KOBjZumvsYfyx = 'السيرفرات الجيدة ( '+str(len(fo6s53yEnbklLpaJOzgR4Q01wxB))+' )'
					add = UwCT5Oz6Wo0BP
					continue
			else:
				CsaNhTtGm8 = oMgiPWkxtO([nnhWEIa6Tm[lqQvOUWodZnhXLS2Vcuj6EtairFN]],[fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]],source)
				if CsaNhTtGm8:
					title,yDTPzhEBKVJl7CX81,errors,WWuctLSlqizGgrK,CPv45ibdnBc = CsaNhTtGm8[UwCT5Oz6Wo0BP]
					if 'سيرفر' in title and '2مجهول2' in title:
						zOgQjNGH9yk1bXVRnofPvs(ETdv5ONS01nK4Lw6ZC9AXjpiH723P,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Unknown selected server   Server: [ '+title+' ]   Original: [ '+yDTPzhEBKVJl7CX81+' ]')
						import XUbpWe5mRd
						XUbpWe5mRd.leIAjQ0EH8Ykf7uD4sKcZ()
						Tbl0qZIrG9p = 'unresolved'
					else:
						Tbl0qZIrG9p,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,A7TBFRkU8Q3 = a9ur1teAScibOZBKzgvFmyCUpo(title,yDTPzhEBKVJl7CX81,errors,WWuctLSlqizGgrK,CPv45ibdnBc,source,type)
			if Tbl0qZIrG9p in ['EXIT_ALL_RESOLVERS','canceled_1st_menu']:
				LUuIzEwBV9Kti6ZXF782 = Zz9SeICTbPksXy6nuOtLGWhN2V.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Playlist.Clear","params":{"playlistid":1}}')
			if Tbl0qZIrG9p in ['EXIT_ALL_RESOLVERS','download','playing','testing','canceled_1st_menu'] or len(fo6s53yEnbklLpaJOzgR4Q01wxB)==1+add: break
			elif Tbl0qZIrG9p in ['failed','timeout','tried']: break
			elif Tbl0qZIrG9p not in ['canceled_2nd_menu','https']:
				if SmFfh9kPpeoNBdcV7WnJ1LHMuXZO in VLa3Uijkb0vXeJSWcrPf8KOlz4uA: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = '[LEFT]  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,'\n[LEFT]  ')
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,profile='confirm_mediumfont')
	if Tbl0qZIrG9p=='unresolved' and len(nnhWEIa6Tm)>0: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+SmFfh9kPpeoNBdcV7WnJ1LHMuXZO+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,profile='confirm_mediumfont')
	elif Tbl0qZIrG9p in ['failed','timeout'] and VLa3Uijkb0vXeJSWcrPf8KOlz4uA!=Zg9FeADE84jSRIvPCrzYulw3sL: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج',VLa3Uijkb0vXeJSWcrPf8KOlz4uA,profile='confirm_mediumfont')
	return Tbl0qZIrG9p
HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2,AAf5ycPR0xYZml1GNeDKBqM = [],[],[],[],[],[]
def oMgiPWkxtO(joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0,source):
	global HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2,AAf5ycPR0xYZml1GNeDKBqM
	CsaNhTtGm8,W8WxayiRHKzd,new = [],[],[]
	Tk5CeWKZwqrnxjO40(vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc,vvglE69OFKBm817Nkc)
	count = len(ZZH6czYDb0)
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(count):
		HcoMfIznqXR3CaVuJKdTk.append(None)
		zbp604dB9TAc.append(None)
		LSv6gYwMc1uynOEWiNtrJeCA.append(None)
		ccoXKVLtw9egnRisNaz.append(None)
		T5C3sw1yW64okRAu9gG7HcE2.append(None)
		AAf5ycPR0xYZml1GNeDKBqM.append(UwCT5Oz6Wo0BP)
		title = joaMtxEpGfDXFPRHQgLKizyOT2b93[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[ZZxHfvyXBmYVjQ9rdAT8RaSKG].strip(wjs26GpVfNiCUERHJ).strip('&').strip('?').strip('/')
		if count>Mn5NGAdz6xc42s0 and XcPLKthYTV.showDialogs: ZXWeI01flR('فحص سيرفر رقم  '+str(ZZxHfvyXBmYVjQ9rdAT8RaSKG+1),title)
		nnCDcq4rubN9PgVxRY = ['YOUTUBE','DAILYMOTION','AKWAM']
		if source in nnCDcq4rubN9PgVxRY: ExrB3z6q0LMHan(title,yDTPzhEBKVJl7CX81,source,ZZxHfvyXBmYVjQ9rdAT8RaSKG)
		else:
			lJCeZswAUfTWL = yDTPzhEBKVJl7CX81.split('?named=',Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]
			d4UZpRiPMHAC2g6kL97 = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','RESOLVED',lJCeZswAUfTWL)
			if d4UZpRiPMHAC2g6kL97 and (d4UZpRiPMHAC2g6kL97[UwCT5Oz6Wo0BP] or d4UZpRiPMHAC2g6kL97[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG] = d4UZpRiPMHAC2g6kL97
			else:
				awpK2Fx4zPMRu9l3 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=ExrB3z6q0LMHan,args=(title,yDTPzhEBKVJl7CX81,source,ZZxHfvyXBmYVjQ9rdAT8RaSKG))
				awpK2Fx4zPMRu9l3.start()
				W8WxayiRHKzd.append(awpK2Fx4zPMRu9l3)
				new.append(ZZxHfvyXBmYVjQ9rdAT8RaSKG)
				LNma2eq3vEguwVtHjn.sleep(0.75)
	timeout = 60 if source=='AKWAM' else 30
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	for awpK2Fx4zPMRu9l3 in W8WxayiRHKzd: awpK2Fx4zPMRu9l3.join(timeout)
	for ZZxHfvyXBmYVjQ9rdAT8RaSKG in range(count):
		title = joaMtxEpGfDXFPRHQgLKizyOT2b93[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[ZZxHfvyXBmYVjQ9rdAT8RaSKG].strip(wjs26GpVfNiCUERHJ).strip('&').strip('?').strip('/')
		lQoWVn5cyIsJFgY = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy if AAf5ycPR0xYZml1GNeDKBqM[ZZxHfvyXBmYVjQ9rdAT8RaSKG]+Mn5NGAdz6xc42s0>timeout else vvglE69OFKBm817Nkc
		if HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG] and (HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG][UwCT5Oz6Wo0BP] or HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = HcoMfIznqXR3CaVuJKdTk[ZZxHfvyXBmYVjQ9rdAT8RaSKG]
		elif lQoWVn5cyIsJFgY: EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = '\nFailed:  Timed Out ('+str(timeout)+' seconds)',[],[]
		else: EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4 = '\nFailed:  Could not find the video file',[],[]
		CsaNhTtGm8.append([title,yDTPzhEBKVJl7CX81,EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4])
		if ZZxHfvyXBmYVjQ9rdAT8RaSKG in new:
			lJCeZswAUfTWL = yDTPzhEBKVJl7CX81.split('?named=',1)[UwCT5Oz6Wo0BP]
			cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'RESOLVED',lJCeZswAUfTWL,[EEVI25dSbDOyjv1xsXW,wUpHn5IfzaQ8g4j,WOry7DZPocFhH8p4],E8RabFm1Kp5O0s)
	Tk5CeWKZwqrnxjO40(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL)
	return CsaNhTtGm8
def ExrB3z6q0LMHan(m0t48jnKhrQFJViguoMl9NBPp,url,source,D0wIcOgK6BJtoEys2U):
	global HcoMfIznqXR3CaVuJKdTk,AAf5ycPR0xYZml1GNeDKBqM
	AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = UwCT5Oz6Wo0BP
	nnm3Asbhj8z4IDdSXMC1Vx = LNma2eq3vEguwVtHjn.time()
	zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Resolving started   Selected: [ '+m0t48jnKhrQFJViguoMl9NBPp+' ]   Original: [ '+url+' ]')
	yDTPzhEBKVJl7CX81,N9X3WLOct6aUVs0MEYAvxr = url,Zg9FeADE84jSRIvPCrzYulw3sL
	IIMvGtR0hwmYXVWA7HNP3eEJQS2 = 'INTERNAL_RESOLVER'
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gzbrLIBSXAF2oVU4aJcK3iftWd75P(url,source)
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS':
		HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = 'EXIT_ALL_RESOLVERS',[],[]
		AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
		return HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U]
	elif 'NEED_EXTERNAL_RESOLVERS' in VLa3Uijkb0vXeJSWcrPf8KOlz4uA:
		N9X3WLOct6aUVs0MEYAvxr = '\nResolver 1:  Need External Resolver'
		yDTPzhEBKVJl7CX81 = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)[UwCT5Oz6Wo0BP]
		IIMvGtR0hwmYXVWA7HNP3eEJQS2,N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = OO0nZSWq5H4rJw(N9X3WLOct6aUVs0MEYAvxr,yDTPzhEBKVJl7CX81,source,D0wIcOgK6BJtoEys2U)
		if N9X3WLOct6aUVs0MEYAvxr=='EXIT_ALL_RESOLVERS':
			AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
			return N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	elif VLa3Uijkb0vXeJSWcrPf8KOlz4uA: N9X3WLOct6aUVs0MEYAvxr = 'Resolver 1:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:80]
	if fo6s53yEnbklLpaJOzgR4Q01wxB:
		fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
		zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Resolving succeeded   Selected: [ '+m0t48jnKhrQFJViguoMl9NBPp+' ]   Resolver: [ '+IIMvGtR0hwmYXVWA7HNP3eEJQS2+' ]   Original: [ '+url+' ]   Link: [ '+yDTPzhEBKVJl7CX81+' ]   Videos: [ '+str(fo6s53yEnbklLpaJOzgR4Q01wxB)+' ]')
	else: zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Resolving failed   Selected: [ '+m0t48jnKhrQFJViguoMl9NBPp+' ]   Original: [ '+url+' ]   Link: [ '+yDTPzhEBKVJl7CX81+' ]   Errors: [ '+N9X3WLOct6aUVs0MEYAvxr+' ]')
	N9X3WLOct6aUVs0MEYAvxr = UAjMPLdITqWChbrcB(N9X3WLOct6aUVs0MEYAvxr)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	AAf5ycPR0xYZml1GNeDKBqM[D0wIcOgK6BJtoEys2U] = LNma2eq3vEguwVtHjn.time()-nnm3Asbhj8z4IDdSXMC1Vx
	return N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def a9ur1teAScibOZBKzgvFmyCUpo(title,yDTPzhEBKVJl7CX81,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,source,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS': return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	elif fo6s53yEnbklLpaJOzgR4Q01wxB:
		while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			else: lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الملف المناسب:', nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: Tbl0qZIrG9p = 'tried'
			else:
				mQ1H5zbKPevwuRZUVAYDp42N = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				zOgQjNGH9yk1bXVRnofPvs(ZJnQfwkWG2MXUV1SiLl8Ixp46mHc9,VsYiARtQ2WToMq(bIPsOxjEpoH)+'   Playing started   Selected: [ '+title+' ]   Original: [ '+yDTPzhEBKVJl7CX81+' ]   Video: [ '+str(mQ1H5zbKPevwuRZUVAYDp42N)+' ]')
				if 'moshahda.' in mQ1H5zbKPevwuRZUVAYDp42N and 'download_orig' in mQ1H5zbKPevwuRZUVAYDp42N:
					EEVI25dSbDOyjv1xsXW,F9mNlIL0VX5uOT18sf,A7TBFRkU8Q3 = SpaWQdMNH9XqLt0z(mQ1H5zbKPevwuRZUVAYDp42N)
					if A7TBFRkU8Q3: mQ1H5zbKPevwuRZUVAYDp42N = A7TBFRkU8Q3[UwCT5Oz6Wo0BP]
					else: mQ1H5zbKPevwuRZUVAYDp42N = Zg9FeADE84jSRIvPCrzYulw3sL
				if not mQ1H5zbKPevwuRZUVAYDp42N: Tbl0qZIrG9p = 'unresolved'
				else: Tbl0qZIrG9p = nTdpZOCUe7l(mQ1H5zbKPevwuRZUVAYDp42N,source,type)
			if Tbl0qZIrG9p in ['playing','testing','canceled_2nd_menu'] or len(fo6s53yEnbklLpaJOzgR4Q01wxB)==1: break
			elif Tbl0qZIrG9p in ['failed','timeout','tried']: break
			else: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		Tbl0qZIrG9p = 'unresolved'
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81): Tbl0qZIrG9p = nTdpZOCUe7l(yDTPzhEBKVJl7CX81,source,type)
	return Tbl0qZIrG9p,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,fo6s53yEnbklLpaJOzgR4Q01wxB
def R7XmiIPODa6k8VxMFQlZtS(url,source):
	hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	if '?named=' in url:
		hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5 = url.split('?named=',Mn5NGAdz6xc42s0)
		bbY0rUvML9u7TkPS8eofB5 = bbY0rUvML9u7TkPS8eofB5+'__'+'__'+'__'+'__'+'__'
		VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg,YlxJjQSZsg, = bbY0rUvML9u7TkPS8eofB5.split('__')[:6]
	if not YUCPADxT3NrgM: YUCPADxT3NrgM = '0'
	else: YUCPADxT3NrgM = YUCPADxT3NrgM.replace('p',Zg9FeADE84jSRIvPCrzYulw3sL).replace(wjs26GpVfNiCUERHJ,Zg9FeADE84jSRIvPCrzYulw3sL)
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.strip('?').strip('/').strip('&')
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,'host')
	if VaOH2318eP5yQWXrkcx: S41FAgod7yKYwPjLx0NIt9knMQ = VaOH2318eP5yQWXrkcx
	else: S41FAgod7yKYwPjLx0NIt9knMQ = m0t48jnKhrQFJViguoMl9NBPp
	S41FAgod7yKYwPjLx0NIt9knMQ = G9GCDqXJFAc(S41FAgod7yKYwPjLx0NIt9knMQ,'name')
	VaOH2318eP5yQWXrkcx = VaOH2318eP5yQWXrkcx.replace('مباشر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('سيرفر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ال ',wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	bbY0rUvML9u7TkPS8eofB5 = bbY0rUvML9u7TkPS8eofB5.replace('مباشر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('سيرفر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ال ',wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	S41FAgod7yKYwPjLx0NIt9knMQ = S41FAgod7yKYwPjLx0NIt9knMQ.replace('مباشر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('سيرفر',Zg9FeADE84jSRIvPCrzYulw3sL).replace('ال ',wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
	return hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg
def AKBoT7vNy1sGCSq98HWL2Rlc(url,source):
	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,feKw2ynYhdXcFt,VigSj1dHsDzNfLtkhvECeXy4c,fVMmZsFWPO4ljeEdSw,EtfLVkdeJgcUWASqCK8F1yTIzu9l,IIMvGtR0hwmYXVWA7HNP3eEJQS2 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,None,None,None,None,None
	hc5ePKxl4LJvEjDgTm,bbY0rUvML9u7TkPS8eofB5,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = R7XmiIPODa6k8VxMFQlZtS(url,source)
	if '?named=' in url:
		if   type=='embed': type = wjs26GpVfNiCUERHJ+'مفضل'
		elif type=='watch': type = wjs26GpVfNiCUERHJ+'%مشاهدة'
		elif type=='both': type = wjs26GpVfNiCUERHJ+'%%مشاهدة وتحميل'
		elif type=='download': type = wjs26GpVfNiCUERHJ+'%%%تحميل'
		elif type==Zg9FeADE84jSRIvPCrzYulw3sL: type = wjs26GpVfNiCUERHJ+'%%%%'
		if QAHN1PzTaF!=Zg9FeADE84jSRIvPCrzYulw3sL:
			if 'mp4' not in QAHN1PzTaF: QAHN1PzTaF = '%'+QAHN1PzTaF
			QAHN1PzTaF = wjs26GpVfNiCUERHJ+QAHN1PzTaF
		if YUCPADxT3NrgM!=Zg9FeADE84jSRIvPCrzYulw3sL:
			YUCPADxT3NrgM = '%%%%%%%%%'+YUCPADxT3NrgM
			YUCPADxT3NrgM = wjs26GpVfNiCUERHJ+YUCPADxT3NrgM[-9:]
	if   'AKOAM'		in source: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'AKWAM'		in source: feKw2ynYhdXcFt	= 'akwam'
	elif 'katkoute'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'photos.app.g'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'arabseed'		in source: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'alarab'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'fasel'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 't7meel'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'movs4u'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'myegyvip'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'fajer'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'فجر'			in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= 'fajer'
	elif 'فلسطين'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= 'palestine'
	elif 'gdrive'		in hc5ePKxl4LJvEjDgTm:   feKw2ynYhdXcFt	= 'google'
	elif 'mycima'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'wecima'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'cimanow'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'newcima'		in VaOH2318eP5yQWXrkcx:   feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'dailymotion'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'bokra'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'tvfun'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'tvksa'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'anavidz'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'shoofpro'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'shahid4u'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'shahed4u'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'cima4u'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'egynow'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'halacima'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'cimaabdo'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'redmodx'	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'redmodx'
	elif 'youtu'	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'youtube'
	elif 'y2u.be'	 	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'youtube'
	elif 'egy-best.net'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'd.egybest.d'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'egybestvip'
	elif 'egy.best'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'egybest1'
	elif 'egybest'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'egybest3'
	elif 'moshahda'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'moshahda'
	elif 'facultybooks'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'facultybooks'
	elif 'inflam.cc'	in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'inflam'
	elif 'buzzvrl'		in m0t48jnKhrQFJViguoMl9NBPp: feKw2ynYhdXcFt	= 'buzzvrl'
	elif 'arabloads'	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'arabloads'
	elif 'archive'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'archive'
	elif 'catch.is'	 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'catch'
	elif 'filerio'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'filerio'
	elif 'vidbm'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'vidbm'
	elif 'vidhd'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'myvid'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'myviid'		in m0t48jnKhrQFJViguoMl9NBPp: EtfLVkdeJgcUWASqCK8F1yTIzu9l	= S41FAgod7yKYwPjLx0NIt9knMQ
	elif 'videobin'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'videobin'
	elif 'govid'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'govid'
	elif 'liivideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'liivideo'
	elif 'mp4upload'	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'mp4upload'
	elif 'publicvideo'	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'publicvideo'
	elif 'rapidvideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'rapidvideo'
	elif 'top4top'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'top4top'
	elif 'upp' 			in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'upbom'
	elif 'upb' 			in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'upbom'
	elif 'uqload' 		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'uqload'
	elif 'vcstream' 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'vcstream'
	elif 'vidbob'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'vidbob'
	elif 'vidoza' 		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'vidoza'
	elif 'watchvideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'watchvideo'
	elif 'wintv.live'	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'wintv.live'
	elif 'zippyshare'	in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'zippyshare'
	elif 'hd-cdn'		in m0t48jnKhrQFJViguoMl9NBPp: VigSj1dHsDzNfLtkhvECeXy4c	= 'hd-cdn'
	if   feKw2ynYhdXcFt:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = 'خاص',feKw2ynYhdXcFt
	elif EtfLVkdeJgcUWASqCK8F1yTIzu9l:		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = '%محدد',EtfLVkdeJgcUWASqCK8F1yTIzu9l
	elif VigSj1dHsDzNfLtkhvECeXy4c:		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = '%%عام معروف',VigSj1dHsDzNfLtkhvECeXy4c
	elif fVMmZsFWPO4ljeEdSw:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = '%%%عام خارجي',fVMmZsFWPO4ljeEdSw
	elif IIMvGtR0hwmYXVWA7HNP3eEJQS2:	rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = '%%%%عام خارجي',S41FAgod7yKYwPjLx0NIt9knMQ
	else:			rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx = '%%%%%عام مجهول',S41FAgod7yKYwPjLx0NIt9knMQ
	return rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM
def gzbrLIBSXAF2oVU4aJcK3iftWd75P(url,source):
	hc5ePKxl4LJvEjDgTm,EtfLVkdeJgcUWASqCK8F1yTIzu9l,m0t48jnKhrQFJViguoMl9NBPp,S41FAgod7yKYwPjLx0NIt9knMQ,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,NNIKbSVi6Om372dg = R7XmiIPODa6k8VxMFQlZtS(url,source)
	if   'AKOAM'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = pQ1ZiwXaM0(hc5ePKxl4LJvEjDgTm,VaOH2318eP5yQWXrkcx)
	elif 'AKWAM'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = IyYirQzZGv(hc5ePKxl4LJvEjDgTm,type,YUCPADxT3NrgM)
	elif 'FASELHD1'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = xVvmRMp79W(hc5ePKxl4LJvEjDgTm)
	elif 'YOUTUBE'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(hc5ePKxl4LJvEjDgTm)
	elif 'youtu'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(hc5ePKxl4LJvEjDgTm)
	elif 'y2u.be'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(hc5ePKxl4LJvEjDgTm)
	elif 'CIMA4U'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FVRYiGMdJh(hc5ePKxl4LJvEjDgTm)
	elif 'CIMACLUB'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Ym4jT1kfeg(hc5ePKxl4LJvEjDgTm)
	elif 'ARABSEED'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yJTdSCOX7x(hc5ePKxl4LJvEjDgTm)
	elif 'CIMAABDO'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = F91TH3ni7m(hc5ePKxl4LJvEjDgTm)
	elif 'SHOFHA'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SkxuGj30n4(hc5ePKxl4LJvEjDgTm)
	elif 'EGYBEST1'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = AUPfVWo8Bn(hc5ePKxl4LJvEjDgTm,NNIKbSVi6Om372dg)
	elif 'ALMSTBA'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = TUXrq2Wucb(hc5ePKxl4LJvEjDgTm)
	elif 'LAROZA'		in source: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SdHpbQKWze(hc5ePKxl4LJvEjDgTm)
	elif 'katkoute'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = k560CXdIMv(hc5ePKxl4LJvEjDgTm)
	elif 'akoam.cam'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Szw076nNGR(hc5ePKxl4LJvEjDgTm)
	elif 'alarab'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = nFh5kfeVbduoPp9lz(hc5ePKxl4LJvEjDgTm)
	elif 'shahid4u'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yeiIX36zJo(hc5ePKxl4LJvEjDgTm)
	elif 'shahed4u'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = yeiIX36zJo(hc5ePKxl4LJvEjDgTm)
	elif 'egynow'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = urBoEOnx02(hc5ePKxl4LJvEjDgTm)
	elif 'tvfun'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif 'tvksa'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif 'tv-f.com'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = L1PV8IBk34(hc5ePKxl4LJvEjDgTm)
	elif 'halacima'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = QQHduikc5f(hc5ePKxl4LJvEjDgTm)
	elif 'shoofpro'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fHmezsZOGV(hc5ePKxl4LJvEjDgTm)
	elif 'myegyvip'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = hhALjcYd2fWB(hc5ePKxl4LJvEjDgTm)
	elif 'vs4u'			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = EE6g4ZBibI(hc5ePKxl4LJvEjDgTm)
	elif 'fajer'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = P4zITBLrK0(hc5ePKxl4LJvEjDgTm)
	elif 'cimanow'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fAYMmzEO20(hc5ePKxl4LJvEjDgTm)
	elif 'newcima'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = fAYMmzEO20(hc5ePKxl4LJvEjDgTm)
	elif 'cima-light'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gNX7Y4t0Sb(hc5ePKxl4LJvEjDgTm)
	elif 'cimalight'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = gNX7Y4t0Sb(hc5ePKxl4LJvEjDgTm)
	elif 'mycima'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = wwKvyLS7uU(hc5ePKxl4LJvEjDgTm)
	elif 'wecima'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = CmrYlk2Py3bgvZu106neDaWzpcEs(hc5ePKxl4LJvEjDgTm)
	elif 'bokra'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Y9cjIvMwV2(hc5ePKxl4LJvEjDgTm)
	elif 'dailymotion'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = tAvpx4RZWu(hc5ePKxl4LJvEjDgTm)
	elif 'arblionz'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = R9Rm6XscNg(hc5ePKxl4LJvEjDgTm)
	elif 'egy-best.net'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = r1IcxTB74l(hc5ePKxl4LJvEjDgTm)
	elif 'd.egybest.d'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif 'egybest'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = nI3TcUWd10(hc5ePKxl4LJvEjDgTm)
	elif 'series4watch'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = B8RiNLrIVh(hc5ePKxl4LJvEjDgTm)
	elif 'upbam' 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA and VLa3Uijkb0vXeJSWcrPf8KOlz4uA!='EXIT_ALL_RESOLVERS': VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'Failed:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def PQdFebAH57halw1M(VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB):
	WWuctLSlqizGgrK,CPv45ibdnBc = [],[]
	for title,yDTPzhEBKVJl7CX81 in zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB):
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81):
			WWuctLSlqizGgrK.append(title)
			CPv45ibdnBc.append(yDTPzhEBKVJl7CX81)
	if not CPv45ibdnBc and not VLa3Uijkb0vXeJSWcrPf8KOlz4uA: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'Failed'
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,WWuctLSlqizGgrK,CPv45ibdnBc
def OO0nZSWq5H4rJw(N9X3WLOct6aUVs0MEYAvxr,url,source,D0wIcOgK6BJtoEys2U):
	global HcoMfIznqXR3CaVuJKdTk,zbp604dB9TAc,LSv6gYwMc1uynOEWiNtrJeCA,ccoXKVLtw9egnRisNaz,T5C3sw1yW64okRAu9gG7HcE2
	ulNBWMPEiF = []
	TAE1KYHWmGzoR = ('Timeout',[],[])
	zbp604dB9TAc[D0wIcOgK6BJtoEys2U],LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U],ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U],T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U] = TAE1KYHWmGzoR,TAE1KYHWmGzoR,TAE1KYHWmGzoR,TAE1KYHWmGzoR
	II1HJTbh6XFp = [j7HldantU8TLXsSQ,Xy7tcwx3hAQYoGm,PPEHU7VyJ5wBqWzKCMm4hSslxk9,jVOnHTRa4EAmzsy7h]
	if 'frdl' in url: II1HJTbh6XFp = [j7HldantU8TLXsSQ,Xy7tcwx3hAQYoGm,jVOnHTRa4EAmzsy7h]
	for Nc3WHfDVqvnQtbomekKLi9jC in II1HJTbh6XFp:
		XfZIObwvneJGjkdRyrU = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=Nc3WHfDVqvnQtbomekKLi9jC,args=(url,source,D0wIcOgK6BJtoEys2U))
		ulNBWMPEiF.append(XfZIObwvneJGjkdRyrU)
		XfZIObwvneJGjkdRyrU.start()
		LNma2eq3vEguwVtHjn.sleep(1)
	timeout,step = 30,DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
	for TAE1KYHWmGzoR in range(timeout//step):
		if zbp604dB9TAc[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]=='EXIT_ALL_RESOLVERS' or (not zbp604dB9TAc[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and zbp604dB9TAc[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): break
		if LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]=='EXIT_ALL_RESOLVERS' or (not LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): break
		if ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]=='EXIT_ALL_RESOLVERS' or (not ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): break
		if T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP]=='EXIT_ALL_RESOLVERS' or (not T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][UwCT5Oz6Wo0BP] and T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]): break
		LNma2eq3vEguwVtHjn.sleep(step)
	for XfZIObwvneJGjkdRyrU in ulNBWMPEiF: XfZIObwvneJGjkdRyrU.join(1)
	jY1R9tQPzXcnoTBsJLHe = 'EXTERNAL_RESOLVER_2'
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zbp604dB9TAc[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS' or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += '\nResolver 2:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:80]
	jY1R9tQPzXcnoTBsJLHe = 'EXTERNAL_RESOLVER_3'
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS' or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += '\nResolver 3:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:80]
	jY1R9tQPzXcnoTBsJLHe = 'EXTERNAL_RESOLVER_4'
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS' or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += '\nResolver 4:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:80]
	jY1R9tQPzXcnoTBsJLHe = 'EXTERNAL_RESOLVER_5'
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U]
	fo6s53yEnbklLpaJOzgR4Q01wxB = fAqtZCBGpF5rRl741IVSk2NuWY(fo6s53yEnbklLpaJOzgR4Q01wxB)
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS' or fo6s53yEnbklLpaJOzgR4Q01wxB: return jY1R9tQPzXcnoTBsJLHe,VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	N9X3WLOct6aUVs0MEYAvxr += '\nResolver 5:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)[:80]
	HcoMfIznqXR3CaVuJKdTk[D0wIcOgK6BJtoEys2U] = N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return jY1R9tQPzXcnoTBsJLHe,N9X3WLOct6aUVs0MEYAvxr,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def j7HldantU8TLXsSQ(url,source,D0wIcOgK6BJtoEys2U):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'name')
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	if 'dailymotion'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = tAvpx4RZWu(url)
	elif 'googleuserco' in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = oU2fiWIkqgMjzrO(url)
	elif 'youtu'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(url)
	elif 'y2u.be'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = eRwxN7KrW0(url)
	elif 'photos.app.g'	in url   : VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = End4XYrWitLP(url)
	elif 'moshahda'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SpaWQdMNH9XqLt0z(url)
	elif 'faselhd'		in url   : VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = xVvmRMp79W(url)
	elif 'arabloads'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ETZDzC3rpIfuhALVRkSUlxXW21QNoH(url)
	elif 'archive'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = rxR7qJpG2lFV6i(url)
	elif 'buzzvrl'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = J1J6LlmAnuXeOVBka(url)
	elif 'e5tsar'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = XnusLo18E03YSp9dctTNZ7FxP(url)
	elif 'facultybooks'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SU6JCeR1nYVaAqj3hgi(url)
	elif 'inflam.cc'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SU6JCeR1nYVaAqj3hgi(url)
	elif 'upbam' 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	elif 'liivideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = grAa8UdWkpub(url)
	elif 'mp4upload'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = qL7uoRwbpI2QFjHP51S(url)
	elif 'rapidvideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = x1yIRrBg8Sf(url)
	elif 'top4top'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ptDGgdlni7a5fVoxEjKYON6XC(url)
	elif 'upb' 			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url)
	elif 'upp' 			in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url)
	elif 'uqload' 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = pdvXniJubODEGh1fRVA2SHIM8c(url)
	elif 'vcstream' 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FFxdlpqBmr8V(url)
	elif 'vidbob'		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = FF5NbecBfM1ED36lQ(url)
	elif 'vidoza' 		in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Z89zqsFYGhdOw3ADCl5VtoSiQNXg(url)
	elif 'watchvideo' 	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = RT28FCeLrhH01x(url)
	elif 'wintv.live'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = NF9nrM2hfP3WIw(url)
	elif 'zippyshare'	in m0t48jnKhrQFJViguoMl9NBPp: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = B17B4reZUshzTbcxEG8RCAop(url)
	else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	global zbp604dB9TAc
	if VLa3Uijkb0vXeJSWcrPf8KOlz4uA and VLa3Uijkb0vXeJSWcrPf8KOlz4uA!='EXIT_ALL_RESOLVERS': VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'Failed:  '
	zbp604dB9TAc[D0wIcOgK6BJtoEys2U] = VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def Xy7tcwx3hAQYoGm(url,source,D0wIcOgK6BJtoEys2U):
	global LSv6gYwMc1uynOEWiNtrJeCA
	if 'youtube' in url:
		LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = 'Failed:  Skipped',[],[]
		return
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	if wzX1klOfLVhb2B4ita(url): VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = hHGKjWOTmg8FVLqyCJQMtUeA7BaEI(url)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = T5T0LfYeA6(url)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB:
		if VLa3Uijkb0vXeJSWcrPf8KOlz4uA=='EXIT_ALL_RESOLVERS': VLa3Uijkb0vXeJSWcrPf8KOlz4uA = Zg9FeADE84jSRIvPCrzYulw3sL
		LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = 'Failed:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
		return
	LSv6gYwMc1uynOEWiNtrJeCA[D0wIcOgK6BJtoEys2U] = VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def PPEHU7VyJ5wBqWzKCMm4hSslxk9(url,source,D0wIcOgK6BJtoEys2U):
	o4be19ApMtCrdf5 = Zg9FeADE84jSRIvPCrzYulw3sL
	CsaNhTtGm8 = vvglE69OFKBm817Nkc
	try:
		import resolveurl as KKUsV0CbeNfgyP7h6
		CsaNhTtGm8 = KKUsV0CbeNfgyP7h6.resolve(url)
	except Exception as dSBk0vXsUeruCTV9y2IQlJhKRx: o4be19ApMtCrdf5 = str(dSBk0vXsUeruCTV9y2IQlJhKRx)
	global ccoXKVLtw9egnRisNaz
	if not CsaNhTtGm8:
		if o4be19ApMtCrdf5==Zg9FeADE84jSRIvPCrzYulw3sL:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!='NoneType: None\n': cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA = o4be19ApMtCrdf5.splitlines()[-Mn5NGAdz6xc42s0]
		ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U] = 'Failed:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
		return
	ccoXKVLtw9egnRisNaz[D0wIcOgK6BJtoEys2U] = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[CsaNhTtGm8]
	return
def jVOnHTRa4EAmzsy7h(url,source,D0wIcOgK6BJtoEys2U):
	o4be19ApMtCrdf5 = Zg9FeADE84jSRIvPCrzYulw3sL
	CsaNhTtGm8 = vvglE69OFKBm817Nkc
	try:
		import yt_dlp as wNK2e1XjbvRq0TxACEMdQt7knp
		DHGTZgtxV6JLWSkb = wNK2e1XjbvRq0TxACEMdQt7knp.YoutubeDL({'no_color': CR6in9cZKo2SqGFmrHOLdhYEVTjsBy})
		CsaNhTtGm8 = DHGTZgtxV6JLWSkb.extract_info(url,download=vvglE69OFKBm817Nkc)
	except Exception as dSBk0vXsUeruCTV9y2IQlJhKRx: o4be19ApMtCrdf5 = str(dSBk0vXsUeruCTV9y2IQlJhKRx)
	global T5C3sw1yW64okRAu9gG7HcE2
	if not CsaNhTtGm8 or 'formats' not in list(CsaNhTtGm8.keys()):
		if o4be19ApMtCrdf5==Zg9FeADE84jSRIvPCrzYulw3sL:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!='NoneType: None\n': cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA = o4be19ApMtCrdf5.splitlines()[-Mn5NGAdz6xc42s0]
		T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U] = 'Failed:  '+VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
	else:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for yDTPzhEBKVJl7CX81 in CsaNhTtGm8['formats']:
			nnhWEIa6Tm.append(yDTPzhEBKVJl7CX81['format'])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81['url'])
		T5C3sw1yW64okRAu9gG7HcE2[D0wIcOgK6BJtoEys2U] = Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	return
def hHGKjWOTmg8FVLqyCJQMtUeA7BaEI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,'RESOLVERS-REDIRECT_URL-1st')
	headers = Pa6Q2LRkbtY0Id7nUNsZ.headers
	if 'Location' in list(headers.keys()):
		yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		if wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81): return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'Failed:  ',[],[]
def fAqtZCBGpF5rRl741IVSk2NuWY(XrEQ2VJFc6KxMwvdqGH5oUhICOu1):
	if 'list' in str(type(XrEQ2VJFc6KxMwvdqGH5oUhICOu1)):
		CPv45ibdnBc = []
		for yDTPzhEBKVJl7CX81 in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
			if 'str' in str(type(yDTPzhEBKVJl7CX81)): yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			CPv45ibdnBc.append(yDTPzhEBKVJl7CX81)
	else: CPv45ibdnBc = XrEQ2VJFc6KxMwvdqGH5oUhICOu1.replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL).replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
	return CPv45ibdnBc
def VVPSsRdu7YDg84qJLK(A7TBFRkU8Q3,source):
	PPQvsXBcDj = ggWsYrlq8fy2v
	data = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','SERVERS',A7TBFRkU8Q3)
	if data:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = list(zip(*data))
		return nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,CzJQSxB3rIlUY9sOH1X = [],[],[]
	for yDTPzhEBKVJl7CX81 in A7TBFRkU8Q3:
		if '//' not in yDTPzhEBKVJl7CX81: continue
		rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM = AKBoT7vNy1sGCSq98HWL2Rlc(yDTPzhEBKVJl7CX81,source)
		YUCPADxT3NrgM = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\d+',YUCPADxT3NrgM,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if YUCPADxT3NrgM: YUCPADxT3NrgM = int(YUCPADxT3NrgM[UwCT5Oz6Wo0BP])
		else: YUCPADxT3NrgM = UwCT5Oz6Wo0BP
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
		CzJQSxB3rIlUY9sOH1X.append([rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp])
	if CzJQSxB3rIlUY9sOH1X:
		uLm9NQjaOevl1YWZ7RK5bghTSoE6tA = sorted(CzJQSxB3rIlUY9sOH1X,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: (key[NEc173Pr0jAwLF5OS],key[UwCT5Oz6Wo0BP],key[O4dklMvZ8ULcS],key[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr],key[Mn5NGAdz6xc42s0],key[5],key[6]))
		EaK7fXz6F9AbMJptQ12HlweoBd,qfXLp7dntsOZUhyIPW = [],[]
		for Eh9DwNXB3LFnz1P in uLm9NQjaOevl1YWZ7RK5bghTSoE6tA:
			rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp = Eh9DwNXB3LFnz1P
			if 'مفضل' in type:
				qfXLp7dntsOZUhyIPW.append(Eh9DwNXB3LFnz1P)
				continue
			if Eh9DwNXB3LFnz1P not in EaK7fXz6F9AbMJptQ12HlweoBd: EaK7fXz6F9AbMJptQ12HlweoBd.append(Eh9DwNXB3LFnz1P)
		EaK7fXz6F9AbMJptQ12HlweoBd = qfXLp7dntsOZUhyIPW+EaK7fXz6F9AbMJptQ12HlweoBd
		pfQhOaqwdBS2k8ZiRA5MeXYUK = UwCT5Oz6Wo0BP
		for rroVc9aI2diKHO1kbEe3s4tGWwX5q,VaOH2318eP5yQWXrkcx,type,QAHN1PzTaF,YUCPADxT3NrgM,yDTPzhEBKVJl7CX81,m0t48jnKhrQFJViguoMl9NBPp in EaK7fXz6F9AbMJptQ12HlweoBd:
			YUCPADxT3NrgM = str(YUCPADxT3NrgM) if YUCPADxT3NrgM else Zg9FeADE84jSRIvPCrzYulw3sL
			title = 'سيرفر'+wjs26GpVfNiCUERHJ+type+wjs26GpVfNiCUERHJ+rroVc9aI2diKHO1kbEe3s4tGWwX5q+wjs26GpVfNiCUERHJ+YUCPADxT3NrgM+wjs26GpVfNiCUERHJ+QAHN1PzTaF+wjs26GpVfNiCUERHJ+VaOH2318eP5yQWXrkcx
			if m0t48jnKhrQFJViguoMl9NBPp not in title: title = title+wjs26GpVfNiCUERHJ+m0t48jnKhrQFJViguoMl9NBPp
			title = title.replace('%',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
			pfQhOaqwdBS2k8ZiRA5MeXYUK += Mn5NGAdz6xc42s0
			title = str(pfQhOaqwdBS2k8ZiRA5MeXYUK)+'. '+title
			if yDTPzhEBKVJl7CX81 not in fo6s53yEnbklLpaJOzgR4Q01wxB:
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if fo6s53yEnbklLpaJOzgR4Q01wxB:
			data = list(zip(nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB))
			if data: cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'SERVERS',A7TBFRkU8Q3,data,PPQvsXBcDj)
	return nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def nFh5kfeVbduoPp9lz(url):
	if '.m3u8' in url:
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = zKaqs0n5ZdrvWSTJYhy7(url)
		if fo6s53yEnbklLpaJOzgR4Q01wxB: return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def k560CXdIMv(url):
	ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93 = [],[]
	if '/videos.mp4?vid=' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-KATKOUTE-1st')
		if 'Location' in Pa6Q2LRkbtY0Id7nUNsZ.headers:
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
			m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
			joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
	elif 'katkoute.com' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-KATKOUTE-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			nmytzfOdMhHY6Ao1KSx5NL = nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP]
			LE9gRTxzt856dh3K1F = Uu6MqoJxLtkimFsdYhc2Nvef(nmytzfOdMhHY6Ao1KSx5NL)
			OOm4vpntLQ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sources:(\[.*?\]),',LE9gRTxzt856dh3K1F,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if OOm4vpntLQ:
				OOm4vpntLQ = OOm4vpntLQ[UwCT5Oz6Wo0BP]
				OOm4vpntLQ = JGmfjhoyKZUl('list',OOm4vpntLQ)
				for dict in OOm4vpntLQ:
					yDTPzhEBKVJl7CX81 = dict['file']
					YUCPADxT3NrgM = dict['label']
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(YUCPADxT3NrgM+wjs26GpVfNiCUERHJ+m0t48jnKhrQFJViguoMl9NBPp)
		elif 'Location' in Pa6Q2LRkbtY0Id7nUNsZ.headers:
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
			m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
			joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
		if '?url=https://photos.app.goo' in url:
			yDTPzhEBKVJl7CX81 = url.split('?url=')[Mn5NGAdz6xc42s0]
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&')[UwCT5Oz6Wo0BP]
			if yDTPzhEBKVJl7CX81:
				ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
				joaMtxEpGfDXFPRHQgLKizyOT2b93.append('photos google')
	else:
		ZZH6czYDb0.append(url)
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'name')
		joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp)
	if not ZZH6czYDb0: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(ZZH6czYDb0)==Mn5NGAdz6xc42s0: yDTPzhEBKVJl7CX81 = ZZH6czYDb0[UwCT5Oz6Wo0BP]
	else:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('أختر الملف المناسب',joaMtxEpGfDXFPRHQgLKizyOT2b93)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
		yDTPzhEBKVJl7CX81 = ZZH6czYDb0[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def oU2fiWIkqgMjzrO(url):
	headers = {'User-Agent':'Kodi/'+str(NGiBmYp8vX9T426lHn7ue)}
	for OEJ3PT81KtbZ in range(50):
		LNma2eq3vEguwVtHjn.sleep(0.100)
		Pa6Q2LRkbtY0Id7nUNsZ = f9z23hDRKaHvgGoSCpX5u4i('GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()):
			yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'|User-Agent='+headers['User-Agent']
			return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		if Pa6Q2LRkbtY0Id7nUNsZ.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def End4XYrWitLP(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-PHOTOSGOOGLE-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81,YUCPADxT3NrgM = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		return Zg9FeADE84jSRIvPCrzYulw3sL,[YUCPADxT3NrgM],[yDTPzhEBKVJl7CX81]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def g9dJL8N73E(url):
	if '/weepis/' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-WECIMA2-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?<quality>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		else: return 'Error: Resolver Failed WECIMA2',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def TUXrq2Wucb(url):
	if 'serv=' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ALMSTBA-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		else:
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("AlbaPlayerControl\('(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
				url = JDMo92nlwsAZydBPkpNzFvU.b64decode(url)
				if GGfPQnrJKEqMv2ZVxdD: url = url.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			else: return 'Error: Resolver Failed ALMSTBA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def xVvmRMp79W(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FASELHD1-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = NkJiXgtIB5ECy(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"file":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def SdHpbQKWze(url):
	if len(url)>200:
		url = url.strip('/')+'/'
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-LAROZA-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		if UwCT5Oz6Wo0BP and 'function(h,u,n,t,e,r)' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"loader"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if HNRenB3EZX62qgSKMd4f:
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
				HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<script>var(.*?)</script',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if HNRenB3EZX62qgSKMd4f:
					nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = YE6NfDK7nZtwTs(HNRenB3EZX62qgSKMd4f[0])
		elif len(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)<400: yDTPzhEBKVJl7CX81 = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		else: return 'Error: Resolver Failed LAROZA',[],[]
		return '',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def SkxuGj30n4(url):
	if '/down.php' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-SHOFHA-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('video-wrapper.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def FVRYiGMdJh(url):
	if 'server.php' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMA4U-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		if 'http' in yDTPzhEBKVJl7CX81: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def urBoEOnx02(url):
	hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
	Y3OmVPp2ARgBCjn = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYNOW-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: return 'Error: Resolver Failed EGYNOW',[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def fHmezsZOGV(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-SHOOFPRO-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if not yDTPzhEBKVJl7CX81: return 'Error: Resolver Failed SHOOFPRO',[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def QQHduikc5f(url):
	hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
	Y3OmVPp2ARgBCjn = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-HALACIMA-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''<iframe src=["'](.*?)["']''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if not yDTPzhEBKVJl7CX81: return 'Error: Resolver Failed HALACIMA',[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def F91TH3ni7m(url):
	WOry7DZPocFhH8p4,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = url,[],[]
	if '/ajax/' in url:
		hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
		Y3OmVPp2ARgBCjn = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMAABDO-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''<iframe.*?src=["'](.*?)["']''',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL: WOry7DZPocFhH8p4 = xQwlTBNtYRbpOMrS1hq6Wdc7ZGXmfL[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[WOry7DZPocFhH8p4]
def L1PV8IBk34(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-TVFUN-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	Y65YT7juUnzFIJwGcyZMpO = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("var fserv =.*?'(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	if Y65YT7juUnzFIJwGcyZMpO:
		Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO[UwCT5Oz6Wo0BP][2:]
		Y65YT7juUnzFIJwGcyZMpO = JDMo92nlwsAZydBPkpNzFvU.b64decode(Y65YT7juUnzFIJwGcyZMpO)
		if GGfPQnrJKEqMv2ZVxdD: Y65YT7juUnzFIJwGcyZMpO = Y65YT7juUnzFIJwGcyZMpO.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',Y65YT7juUnzFIJwGcyZMpO,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL
	if not yDTPzhEBKVJl7CX81: return 'Error: Resolver Failed TVFUN',[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def hhALjcYd2fWB(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MYEGYVIP-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="col-sm-12".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: return 'Error: Resolver Failed MYEGYVIP',[],[]
	yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def tAvpx4RZWu(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed',Zg9FeADE84jSRIvPCrzYulw3sL)
	url = url.replace('.com/','.com/player/metadata/')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-DAILYMOTION-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'Error: Resolver Failed DAILYMOTION'
	dSBk0vXsUeruCTV9y2IQlJhKRx = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"error".*?"messagee":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if dSBk0vXsUeruCTV9y2IQlJhKRx: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = dSBk0vXsUeruCTV9y2IQlJhKRx[UwCT5Oz6Wo0BP]
	url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('x-mpegURL","url":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not url and VLa3Uijkb0vXeJSWcrPf8KOlz4uA:
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,[],[]
	yDTPzhEBKVJl7CX81 = url[UwCT5Oz6Wo0BP].replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
	F9mNlIL0VX5uOT18sf,A7TBFRkU8Q3 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
	Mles4QpWJtb0vzDZCj = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"owner":\{"id":"(.*?)".*?"screenname":"(.*?)","url":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if Mles4QpWJtb0vzDZCj: YriOlGaJ7fHPov9b,Cvz4PanE5N,T8trGu27K3ohHA = Mles4QpWJtb0vzDZCj[UwCT5Oz6Wo0BP]
	else: YriOlGaJ7fHPov9b,Cvz4PanE5N,T8trGu27K3ohHA = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	T8trGu27K3ohHA = T8trGu27K3ohHA.replace('\/','/')
	Cvz4PanE5N = uumhMi6O4pk7Gjd5aTQqy2Z(Cvz4PanE5N)
	nnhWEIa6Tm = [PPQORjT2lc7SVkKwFI4D+'OWNER:  '+Cvz4PanE5N+u4IRSmrYMKkaHUBnDiLWh]+F9mNlIL0VX5uOT18sf
	fo6s53yEnbklLpaJOzgR4Q01wxB = [T8trGu27K3ohHA]+A7TBFRkU8Q3
	lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الملف المناسب: ('+str(len(fo6s53yEnbklLpaJOzgR4Q01wxB)-1)+' ملف)',nnhWEIa6Tm)
	if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
	elif lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP:
		EEHGwO3V8XjP651npWNz4gmlMABS = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[UwCT5Oz6Wo0BP]+'?type=folder&mode=402&url='+T8trGu27K3ohHA+'&textt='+Cvz4PanE5N
		Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin("Container.Update("+EEHGwO3V8XjP651npWNz4gmlMABS+")")
		return 'EXIT_ALL_RESOLVERS',[],[]
	yDTPzhEBKVJl7CX81 =  fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def Y9cjIvMwV2(yDTPzhEBKVJl7CX81):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BOKRA-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if '.json' in yDTPzhEBKVJl7CX81: url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"src":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: url = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[UwCT5Oz6Wo0BP]
	if 'http' not in url: url = 'http:'+url
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def SpaWQdMNH9XqLt0z(url):
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	if 'op=download_orig' in url:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOSHAHDA-1st')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('direct link.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[items[UwCT5Oz6Wo0BP]]
		else:
			oHkimLnwDKNxlheUuGAMQIg9jY7dz = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="err">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if oHkimLnwDKNxlheUuGAMQIg9jY7dz:
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من الموقع الاصلي',oHkimLnwDKNxlheUuGAMQIg9jY7dz[UwCT5Oz6Wo0BP])
				return 'Error: '+oHkimLnwDKNxlheUuGAMQIg9jY7dz[UwCT5Oz6Wo0BP],[],[]
	else:
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = 'movizland'
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOSHAHDA-2nd')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Form method="POST" action=\'(.*?)\'(.*?)div',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: return 'Error: Resolver Failed MOSHAHDA',[],[]
		WOry7DZPocFhH8p4 = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]
		if '.rar' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA or '.zip' in nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA: return 'Error: MOSHAHDA Not a video file',[],[]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('name="(.*?)".*?value="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		EEFf6enQDxk = {}
		for VaOH2318eP5yQWXrkcx,B251BPiLbvG9UxszKtlI7YQHmoWw in items:
			EEFf6enQDxk[VaOH2318eP5yQWXrkcx] = B251BPiLbvG9UxszKtlI7YQHmoWw
		data = nWw3GirR9qxCFBOa5Dt1gdXmJMpy(EEFf6enQDxk)
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,WOry7DZPocFhH8p4,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOSHAHDA-3rd')
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP]
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('file:"(.*?)"(,label:".*?"|)',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		ORuP1Qjt7DETJvNHKr,nnhWEIa6Tm,VRzd5ahswMGUtuCKpLjroP9T6kx47,fo6s53yEnbklLpaJOzgR4Q01wxB,xDHj9fZiWoTanbkBcG8FPwSm = [],[],[],[],[]
		for yDTPzhEBKVJl7CX81,title in items:
			if '.m3u8' in yDTPzhEBKVJl7CX81:
				ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
				fo6s53yEnbklLpaJOzgR4Q01wxB = fo6s53yEnbklLpaJOzgR4Q01wxB + VRzd5ahswMGUtuCKpLjroP9T6kx47
				if ORuP1Qjt7DETJvNHKr[UwCT5Oz6Wo0BP]=='-1': nnhWEIa6Tm.append(' سيرفر خاص '+'m3u8 '+W4KwrJtUfaNF2Q3Coqsl869V1dbm)
				else:
					for title in ORuP1Qjt7DETJvNHKr:
						nnhWEIa6Tm.append(' سيرفر خاص '+'m3u8 '+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+title)
			else:
				title = title.replace(',label:"',Zg9FeADE84jSRIvPCrzYulw3sL)
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+title
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		yDTPzhEBKVJl7CX81 = 'http://moshahda.online' + download
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOSHAHDA-5th')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for id,LfnWDFgRdJH4lZvt7yo28N,hash,uo2MTB486ONdtnQIfHl in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+W4KwrJtUfaNF2Q3Coqsl869V1dbm+wjs26GpVfNiCUERHJ+uo2MTB486ONdtnQIfHl.split('x')[Mn5NGAdz6xc42s0]
			yDTPzhEBKVJl7CX81 = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+LfnWDFgRdJH4lZvt7yo28N+'&hash='+hash
			xDHj9fZiWoTanbkBcG8FPwSm.append(uo2MTB486ONdtnQIfHl)
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		xDHj9fZiWoTanbkBcG8FPwSm = set(xDHj9fZiWoTanbkBcG8FPwSm)
		B0TvEN4Dubzkt8K2la,xhnJiBWP4jftFcaTrdm = [],[]
		for title in nnhWEIa6Tm:
			W8q6caR1ouAm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(" (\d*x|\d*)&&",title+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for uo2MTB486ONdtnQIfHl in xDHj9fZiWoTanbkBcG8FPwSm:
				if W8q6caR1ouAm[UwCT5Oz6Wo0BP] in uo2MTB486ONdtnQIfHl:
					title = title.replace(W8q6caR1ouAm[UwCT5Oz6Wo0BP],uo2MTB486ONdtnQIfHl.split('x')[Mn5NGAdz6xc42s0])
			B0TvEN4Dubzkt8K2la.append(title)
		for YjZN3ADmertFahUQIECW in range(len(fo6s53yEnbklLpaJOzgR4Q01wxB)):
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("&&(.*?)(\d*)&&",'&&'+B0TvEN4Dubzkt8K2la[YjZN3ADmertFahUQIECW]+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			xhnJiBWP4jftFcaTrdm.append( [B0TvEN4Dubzkt8K2la[YjZN3ADmertFahUQIECW],fo6s53yEnbklLpaJOzgR4Q01wxB[YjZN3ADmertFahUQIECW],items[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP],items[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0]] )
		xhnJiBWP4jftFcaTrdm = sorted(xhnJiBWP4jftFcaTrdm, key=lambda zambDVfyYtWTNnu8jdsoIA1G: zambDVfyYtWTNnu8jdsoIA1G[O4dklMvZ8ULcS], reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy)
		xhnJiBWP4jftFcaTrdm = sorted(xhnJiBWP4jftFcaTrdm, key=lambda zambDVfyYtWTNnu8jdsoIA1G: zambDVfyYtWTNnu8jdsoIA1G[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr], reverse=vvglE69OFKBm817Nkc)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for YjZN3ADmertFahUQIECW in range(len(xhnJiBWP4jftFcaTrdm)):
			nnhWEIa6Tm.append(xhnJiBWP4jftFcaTrdm[YjZN3ADmertFahUQIECW][UwCT5Oz6Wo0BP])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(xhnJiBWP4jftFcaTrdm[YjZN3ADmertFahUQIECW][Mn5NGAdz6xc42s0])
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def XnusLo18E03YSp9dctTNZ7FxP(url):
	Gi82lgtIxVsjSyqZU5EmBLkKw = url.split('?')
	hc5ePKxl4LJvEjDgTm = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-E5TSAR-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('Please wait.*?href=\'(.*?)\'',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url = items[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def J1J6LlmAnuXeOVBka(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FACULTYBOOKS-1st')
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('redirect_url.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def SU6JCeR1nYVaAqj3hgi(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FACULTYBOOKS-1st')
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href","(htt.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def P4zITBLrK0(url):
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if '/wp-admin/' in url:
		hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh = I28IrfmVwu4JkOXhGB(url)
		Y3OmVPp2ARgBCjn = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',hc5ePKxl4LJvEjDgTm,mrn4jdBuXKIw7N2lvh,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FAJERSHOW-2nd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		if CNhQcnS0dI6UFjbvLoyx.startswith('http'): hc5ePKxl4LJvEjDgTm = CNhQcnS0dI6UFjbvLoyx
		else:
			JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('''src=['"](.*?)['"]''',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if JaqiYfEglZDvmwQNS8zR:
				hc5ePKxl4LJvEjDgTm = JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP]
				JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source=(.*?)[&$]',hc5ePKxl4LJvEjDgTm,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if JaqiYfEglZDvmwQNS8zR:
					hc5ePKxl4LJvEjDgTm = UAjMPLdITqWChbrcB(JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP])
					return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif '/links/' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FAJERSHOW-1st')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): hc5ePKxl4LJvEjDgTm = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		else: hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="link".*?href="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	if '/v/' in hc5ePKxl4LJvEjDgTm or '/f/' in hc5ePKxl4LJvEjDgTm:
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace('/f/','/api/source/')
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace('/v/','/api/source/')
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-FAJERSHOW-3rd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"file":"(.*?)","label":"(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,title in items:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
				nnhWEIa6Tm.append(title)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		else:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"file":"(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if items:
				yDTPzhEBKVJl7CX81 = items[UwCT5Oz6Wo0BP]
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
				nnhWEIa6Tm.append(Zg9FeADE84jSRIvPCrzYulw3sL)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	else: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def EE6g4ZBibI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOVS4U-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
		else: hc5ePKxl4LJvEjDgTm = url
		if 'movs4u' not in hc5ePKxl4LJvEjDgTm: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOVS4U-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="player"(.*?)videojs',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<source src="(.*?)".*?label="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items:
			for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a in items:
				nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	elif 'main_player.php' in url:
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('url=(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MOVS4U-3rd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"file": "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR[UwCT5Oz6Wo0BP]
		nnhWEIa6Tm.append(Zg9FeADE84jSRIvPCrzYulw3sL)
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(JaqiYfEglZDvmwQNS8zR)
	elif 'download_link' in url:
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<center><a href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed MOVS4U',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def Ym4jT1kfeg(url):
	if '?get=' in url:
		yDTPzhEBKVJl7CX81 = url.split('?get=',Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
		yDTPzhEBKVJl7CX81 = JDMo92nlwsAZydBPkpNzFvU.b64decode(yDTPzhEBKVJl7CX81)
		if GGfPQnrJKEqMv2ZVxdD: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,'ignore')
		return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	website = PhpFa6EdVS['CIMACLUB'][UwCT5Oz6Wo0BP]
	headers = {'Referer':website}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMACLUB-2nd')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'url')
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('download=.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("sources: \['(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("file:'(.*?)'",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]+'|Referer='+website
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	if 'name="Xtoken"' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		lR0EwfcTGVZjuhqFk5eJoQ = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('name="Xtoken" content="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if lR0EwfcTGVZjuhqFk5eJoQ:
			yDTPzhEBKVJl7CX81 = lR0EwfcTGVZjuhqFk5eJoQ[UwCT5Oz6Wo0BP]
			yDTPzhEBKVJl7CX81 = JDMo92nlwsAZydBPkpNzFvU.b64decode(yDTPzhEBKVJl7CX81)
			if GGfPQnrJKEqMv2ZVxdD: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,'ignore')
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('http.*?(http.*?),',yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]+'|Referer='+website
				return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def AUPfVWo8Bn(url,NNIKbSVi6Om372dg):
	joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = [],[]
	if '/1/' in url:
		yDTPzhEBKVJl7CX81 = url.replace('/1/','/4/')
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-1st')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<video(.*?)</video>',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?size="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in items:
				if yDTPzhEBKVJl7CX81 not in ZZH6czYDb0:
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(m0t48jnKhrQFJViguoMl9NBPp+F4skx1A3wOEh9lmPuZMnpCzR+YUCPADxT3NrgM)
			return Zg9FeADE84jSRIvPCrzYulw3sL,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
	elif '/d/' in url:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-2nd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe.*?src="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace('/1/','/4/')
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-3rd')
			CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class.*?href="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	elif '/role/' in url:
		headers = {'Referer':NNIKbSVi6Om372dg}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-4th')
		yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-5th')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = ymNcGjZfWdUuv2sSpelH(yDTPzhEBKVJl7CX81,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
	elif '/download/' in url:
		hc5ePKxl4LJvEjDgTm = url.replace('/download/','/script/')
		Y3OmVPp2ARgBCjn = {'Referer':NNIKbSVi6Om372dg}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-6th')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-7th')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()):
				yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST1-8th')
				yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
				VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = ymNcGjZfWdUuv2sSpelH(yDTPzhEBKVJl7CX81,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
				if ZZH6czYDb0: return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
			elif '/embed.php?id=' in yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('/embed.php?id=','/jwplayer.php?id=')
				return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def nI3TcUWd10(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST3-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	data = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if data:
		cB10urUPnl,id,uODM6CAnSGgIxastoEph = data[UwCT5Oz6Wo0BP]
		data = 'op='+cB10urUPnl+'&id='+id+'&fname='+uODM6CAnSGgIxastoEph
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST3-2nd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"referer" value="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def r1IcxTB74l(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST4-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL)
		return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def jaOvDTcmbZ(url):
	hc5ePKxl4LJvEjDgTm = url.split('?named=',Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP].strip('?').strip('/').strip('&')
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,items,JaqiYfEglZDvmwQNS8zR = [],[],[],Zg9FeADE84jSRIvPCrzYulw3sL
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-EGYBEST-1st')
	if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): JaqiYfEglZDvmwQNS8zR = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
	if 'http' in JaqiYfEglZDvmwQNS8zR:
		if '__watch' in url: JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR.replace('/f/','/v/')
		cIeOo9suKM7g21TiQwqFtbUyW = hc5ePKxl4LJvEjDgTm.split('?PHPSID=')[Mn5NGAdz6xc42s0]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+cIeOo9suKM7g21TiQwqFtbUyW }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'EGYBEST-PLAY-3rd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		if '/f/' in JaqiYfEglZDvmwQNS8zR: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h2>.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		elif '/v/' in JaqiYfEglZDvmwQNS8zR: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="video".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if items: return [],[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
		elif '<h1>404</h1>' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def B8RiNLrIVh(yDTPzhEBKVJl7CX81):
	Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('postid=(.*?)&serverid=(.*?)&&',yDTPzhEBKVJl7CX81+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
	BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+BmVyhAve6X2PYuI+'&serverid='+B6xEjq29ihy4rDnfGLFC
	headers = { 'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL , 'X-Requested-With':'XMLHttpRequest' }
	hc5ePKxl4LJvEjDgTm = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def wwKvyLS7uU(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'url')
	Y3OmVPp2ARgBCjn = {'Referer':m0t48jnKhrQFJViguoMl9NBPp,'Accept-Encoding':'gzip, deflate'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MYCIMA-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('player.qualityselector(.*?)formats:',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = Zg9FeADE84jSRIvPCrzYulw3sL
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('format: \'(\d.*?)\', src: "(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for title,yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[UwCT5Oz6Wo0BP]
		elif len(fo6s53yEnbklLpaJOzgR4Q01wxB)>Mn5NGAdz6xc42s0:
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('أختر الملف المناسب', nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
			hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	else:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: hc5ePKxl4LJvEjDgTm = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
	if not hc5ePKxl4LJvEjDgTm: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def CmrYlk2Py3bgvZu106neDaWzpcEs(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'url')
	Y3OmVPp2ARgBCjn = {'Referer':m0t48jnKhrQFJViguoMl9NBPp,'Accept-Encoding':'gzip, deflate'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-WECIMA-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('player.qualityselector(.*?)formats:',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = Zg9FeADE84jSRIvPCrzYulw3sL
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('format: \'(\d.*?)\', src: "(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
		for title,yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(title)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
		if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==Mn5NGAdz6xc42s0: hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[UwCT5Oz6Wo0BP]
		elif len(fo6s53yEnbklLpaJOzgR4Q01wxB)>Mn5NGAdz6xc42s0:
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('أختر الملف المناسب', nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
			hc5ePKxl4LJvEjDgTm = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	if not hc5ePKxl4LJvEjDgTm:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f: hc5ePKxl4LJvEjDgTm = HNRenB3EZX62qgSKMd4f[UwCT5Oz6Wo0BP]
	if not hc5ePKxl4LJvEjDgTm: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def Szw076nNGR(yDTPzhEBKVJl7CX81):
	Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',yDTPzhEBKVJl7CX81+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url,BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
	data = {'post_id':BmVyhAve6X2PYuI,'server':B6xEjq29ihy4rDnfGLFC}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-AKOAMCAM-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('iframe src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def gNX7Y4t0Sb(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMALIGHT-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		if yDTPzhEBKVJl7CX81: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def fForZ4LwTl(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMACLUP-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<IFRAME SRC="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
	return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def fAYMmzEO20(url):
	oWd0XOQnlD1PHbYmR = G9GCDqXJFAc(url,'url')
	if 'index=' in url:
		headers = {'Referer':oWd0XOQnlD1PHbYmR}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMANOW-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			if 'http' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = 'http:'+hc5ePKxl4LJvEjDgTm
			if 'cimanow' in hc5ePKxl4LJvEjDgTm:
				hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace('https://','http://')
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMANOW-2nd')
				CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)".*?size="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
				G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,'url')
				for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in reversed(items):
					yDTPzhEBKVJl7CX81 = G7lNnPYTc3Am8jLxp+yDTPzhEBKVJl7CX81+'|Referer='+G7lNnPYTc3Am8jLxp
					nnhWEIa6Tm.append(YUCPADxT3NrgM)
					fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
				return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
			else: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	hc5ePKxl4LJvEjDgTm = url+'|Referer='+oWd0XOQnlD1PHbYmR
	if 'http' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = 'http:'+hc5ePKxl4LJvEjDgTm
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
def bGV3Ay8d9nCW2mUHuf6vD1eE(yDTPzhEBKVJl7CX81):
	oWd0XOQnlD1PHbYmR = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'url')
	if 'postid' in yDTPzhEBKVJl7CX81:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',yDTPzhEBKVJl7CX81+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		url,BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		data = {'id':BmVyhAve6X2PYuI,'server':B6xEjq29ihy4rDnfGLFC}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMANOW-1st')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('iframe src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[UwCT5Oz6Wo0BP]
		if 'cimanow' in hc5ePKxl4LJvEjDgTm:
			headers = {'Referer':oWd0XOQnlD1PHbYmR,'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-CIMANOW-2nd')
			CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)".*?size="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
			G7lNnPYTc3Am8jLxp = G9GCDqXJFAc(hc5ePKxl4LJvEjDgTm,'url')
			for yDTPzhEBKVJl7CX81,YUCPADxT3NrgM in reversed(items):
				yDTPzhEBKVJl7CX81 = G7lNnPYTc3Am8jLxp+yDTPzhEBKVJl7CX81+'|Referer='+G7lNnPYTc3Am8jLxp
				nnhWEIa6Tm.append(YUCPADxT3NrgM)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
		else: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'|Referer='+oWd0XOQnlD1PHbYmR
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
def R9Rm6XscNg(yDTPzhEBKVJl7CX81):
	if 'postid' in yDTPzhEBKVJl7CX81:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('postid=(.*?)&serverid=(.*?)&&',yDTPzhEBKVJl7CX81+'&&',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		G6qYBaPENlLtckHTvhCR4d7A = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'url')
		url = G6qYBaPENlLtckHTvhCR4d7A+'/ajaxCenter?_action=getserver&_post_id='+BmVyhAve6X2PYuI+'&serverid='+B6xEjq29ihy4rDnfGLFC
		headers = { 'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL , 'X-Requested-With':'XMLHttpRequest' }
		hc5ePKxl4LJvEjDgTm = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARBLIONZ-1st')
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).replace(mqBPGuVIYZbStQejFowJh2,Zg9FeADE84jSRIvPCrzYulw3sL)
		return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	elif '/redirect/' in yDTPzhEBKVJl7CX81:
		dQT46gLOHsewaMC7iAxp3KBIb1N0 = UwCT5Oz6Wo0BP
		while '/redirect/' in yDTPzhEBKVJl7CX81 and dQT46gLOHsewaMC7iAxp3KBIb1N0<5:
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
			dQT46gLOHsewaMC7iAxp3KBIb1N0 += Mn5NGAdz6xc42s0
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def yJTdSCOX7x(url):
	m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'url')
	headers = {'Referer':m0t48jnKhrQFJViguoMl9NBPp,'User-Agent':lAfzvsbYy7oQ3r28EMe()}
	if '/embed-' in url:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARABSEED-2nd')
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP].replace('https','http')
			return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else:
		w1TQtjmOINLSfBcUWvoa7q3RV26X0A = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARABSEED-3rd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = w1TQtjmOINLSfBcUWvoa7q3RV26X0A.content
		Y3OmVPp2ARgBCjn = headers.copy()
		if '_lnk_' in str(w1TQtjmOINLSfBcUWvoa7q3RV26X0A.cookies):
			cookies = w1TQtjmOINLSfBcUWvoa7q3RV26X0A.cookies
			Y3OmVPp2ARgBCjn['Cookie'] = UAjMPLdITqWChbrcB(nWw3GirR9qxCFBOa5Dt1gdXmJMpy(cookies))
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('link.href = "(http.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not yDTPzhEBKVJl7CX81: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
		else:
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP])+'&d=1'
			zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARABSEED-4th')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = zCDbxZtwOE6.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="btn".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81:
				yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP])
				if 'mp4' in yDTPzhEBKVJl7CX81 and '/d/' in yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
				else: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'Error: Resolver Failed ARABSEED',[],[]
def yeiIX36zJo(yDTPzhEBKVJl7CX81):
	if '_action=getserver' in yDTPzhEBKVJl7CX81:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-SHAHID4U-1st')
		url = Pa6Q2LRkbtY0Id7nUNsZ.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else:
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('postid=(.*?)&serverid=(.*?)$',yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if not Gi82lgtIxVsjSyqZU5EmBLkKw: Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('_post_id=(.*?)&serverid=(.*?)$',yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		BmVyhAve6X2PYuI,B6xEjq29ihy4rDnfGLFC = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'url')
		url = m0t48jnKhrQFJViguoMl9NBPp+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':BmVyhAve6X2PYuI,'i':B6xEjq29ihy4rDnfGLFC}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':yDTPzhEBKVJl7CX81}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'POST',url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-SHAHID4U-2nd')
		CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
		hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if hc5ePKxl4LJvEjDgTm:
			hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP]
			return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def wwiCDIvs9P(GwcehBCRflA2MgH):
	osGpLivVOZ9mgSkAD4uyhec3U0P = yUTYoAgth5iC43uLrdBH.getSetting('av.akwam.verification')
	headers = {'Cookie':osGpLivVOZ9mgSkAD4uyhec3U0P} if osGpLivVOZ9mgSkAD4uyhec3U0P else Zg9FeADE84jSRIvPCrzYulw3sL
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',GwcehBCRflA2MgH,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
	Vs9M1kaPJlZowdfWDt = str(Pa6Q2LRkbtY0Id7nUNsZ.headers)
	ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR = Vs9M1kaPJlZowdfWDt+wxIqRGu1yTCf
	if '.mp4' in ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR: L9GkAl40jOgC6nf7ixqhU3YQcJK1 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	else:
		Xl69gbpxUTS4RCImzN8,dkKX8zLCs6yqBlD7Y5geZEpAicua20,ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64,L9GkAl40jOgC6nf7ixqhU3YQcJK1 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc
		captcha = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if captcha: ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64 = captcha[UwCT5Oz6Wo0BP]
		vq6X1PusA0CdEwtZf = PhpFa6EdVS['PYTHON'][7]
		if UwCT5Oz6Wo0BP:
			data = {'user':fs60XkagtWFJ,'version':kI8qwbo6yER,'url':GwcehBCRflA2MgH,'key':c8yHSJkT64,'id':Zg9FeADE84jSRIvPCrzYulw3sL,'job':'geturls'}
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Zg9FeADE84jSRIvPCrzYulw3sL
		if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith('URLS='):
			XrEQ2VJFc6KxMwvdqGH5oUhICOu1 = JGmfjhoyKZUl('list',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.split('URLS=',Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0])
			for YYAz8aPFGR2n in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
				url = YYAz8aPFGR2n['url']
				G1hbAR8Yxkp0zeCoMdaB4Dqw = YYAz8aPFGR2n['method']
				data = YYAz8aPFGR2n['data']
				headers = YYAz8aPFGR2n['headers']
				Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,G1hbAR8Yxkp0zeCoMdaB4Dqw,url,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
				if '.mp4' in wxIqRGu1yTCf:
					L9GkAl40jOgC6nf7ixqhU3YQcJK1 = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					break
				Vs9M1kaPJlZowdfWDt = str(Pa6Q2LRkbtY0Id7nUNsZ.headers)
				ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR = Vs9M1kaPJlZowdfWDt+wxIqRGu1yTCf
				Xl69gbpxUTS4RCImzN8 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(akwamVerification\w+).*?"(eyJ.*?)"',ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('recaptcha-token.*?"(03A.*?)"',ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if dkKX8zLCs6yqBlD7Y5geZEpAicua20: dkKX8zLCs6yqBlD7Y5geZEpAicua20 = dkKX8zLCs6yqBlD7Y5geZEpAicua20[UwCT5Oz6Wo0BP]
				if Xl69gbpxUTS4RCImzN8 or dkKX8zLCs6yqBlD7Y5geZEpAicua20: break
		if not L9GkAl40jOgC6nf7ixqhU3YQcJK1:
			if not Xl69gbpxUTS4RCImzN8:
				if captcha and not dkKX8zLCs6yqBlD7Y5geZEpAicua20:
					if Mn5NGAdz6xc42s0: dkKX8zLCs6yqBlD7Y5geZEpAicua20 = e4XT9Vp5sNIP8M0lyFd7orGUhJ2Ou(c8yHSJkT64,'ar',GwcehBCRflA2MgH)
					else:
						if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith('ID='):
							data = {'user':fs60XkagtWFJ,'version':kI8qwbo6yER,'url':GwcehBCRflA2MgH,'key':c8yHSJkT64,'id':Zg9FeADE84jSRIvPCrzYulw3sL,'job':'getid'}
							Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
						else: yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = 'ID=1234::::TIMEOUT=45'
						if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith('ID='):
							XQsiFUaSgDCLro = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('ID=(.*?)::::TIMEOUT=(.*?)$',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
							ItDYZ781iSzo,HTPdhx6IsYmGjeZ5nbtkUy47ACvruK = XQsiFUaSgDCLro[UwCT5Oz6Wo0BP]
							oHkimLnwDKNxlheUuGAMQIg9jY7dz = 'هذه العملية تحتاج وقت من 10 إلى '+HTPdhx6IsYmGjeZ5nbtkUy47ACvruK+' ثانية'
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS = Rr8woplmSQWXIZcGFfA()
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',oHkimLnwDKNxlheUuGAMQIg9jY7dz)
							uuAgLD1dr7s = LNma2eq3vEguwVtHjn.time()
							i8OdhkMvDrt1Fzx0fJXKgVyEl4p,ePJSwbWn1QRuilDZg8a = UwCT5Oz6Wo0BP,UwCT5Oz6Wo0BP
							while i8OdhkMvDrt1Fzx0fJXKgVyEl4p<int(HTPdhx6IsYmGjeZ5nbtkUy47ACvruK):
								OpsLGCQJ9nbVthERxuAY1e(zkK23NOgQFhY75mjwDuxfbsc1EUiqS,int(i8OdhkMvDrt1Fzx0fJXKgVyEl4p/int(HTPdhx6IsYmGjeZ5nbtkUy47ACvruK)*100),oHkimLnwDKNxlheUuGAMQIg9jY7dz,Zg9FeADE84jSRIvPCrzYulw3sL,HTPdhx6IsYmGjeZ5nbtkUy47ACvruK+' / '+str(int(i8OdhkMvDrt1Fzx0fJXKgVyEl4p))+'  ثانية')
								if i8OdhkMvDrt1Fzx0fJXKgVyEl4p>ePJSwbWn1QRuilDZg8a+10:
									data = {'user':fs60XkagtWFJ,'version':kI8qwbo6yER,'url':GwcehBCRflA2MgH,'key':c8yHSJkT64,'id':ItDYZ781iSzo,'job':'gettoken'}
									Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',vq6X1PusA0CdEwtZf,data,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
									if yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.startswith('TOKEN='):
										dkKX8zLCs6yqBlD7Y5geZEpAicua20 = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.split('TOKEN=',1)[Mn5NGAdz6xc42s0]
										break
									ePJSwbWn1QRuilDZg8a = i8OdhkMvDrt1Fzx0fJXKgVyEl4p
								else: LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
								i8OdhkMvDrt1Fzx0fJXKgVyEl4p = LNma2eq3vEguwVtHjn.time()-uuAgLD1dr7s
							zkK23NOgQFhY75mjwDuxfbsc1EUiqS.close()
				if dkKX8zLCs6yqBlD7Y5geZEpAicua20:
					cwOlXoA1krih5LKjQ = Pa6Q2LRkbtY0Id7nUNsZ.cookies
					ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('akwam_session=(.*?);',ujhIqDJMk0EHKe3gW4GS1tcYNlXmTR,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if 'akwam_session' in list(cwOlXoA1krih5LKjQ.keys()): ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = cwOlXoA1krih5LKjQ['akwam_session']
					elif ZZqwLUcVuJkAIl8SjNHOsEd5ipM6: ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 = ZZqwLUcVuJkAIl8SjNHOsEd5ipM6[UwCT5Oz6Wo0BP]
					captcha = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if captcha: ykHvcOoTYS8hQsVPqGZ0mAKLN,c8yHSJkT64 = captcha[UwCT5Oz6Wo0BP]
					if ZZqwLUcVuJkAIl8SjNHOsEd5ipM6 and captcha:
						headers = {'Cookie':'akwam_session='+ZZqwLUcVuJkAIl8SjNHOsEd5ipM6,'Referer':GwcehBCRflA2MgH,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+dkKX8zLCs6yqBlD7Y5geZEpAicua20
						Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'POST',ykHvcOoTYS8hQsVPqGZ0mAKLN,data,headers,vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
						try: cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
						except: cookies = {}
						Xl69gbpxUTS4RCImzN8 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if Xl69gbpxUTS4RCImzN8:
				VaOH2318eP5yQWXrkcx,Xl69gbpxUTS4RCImzN8 = Xl69gbpxUTS4RCImzN8[UwCT5Oz6Wo0BP]
				osGpLivVOZ9mgSkAD4uyhec3U0P = VaOH2318eP5yQWXrkcx+'='+Xl69gbpxUTS4RCImzN8
				yUTYoAgth5iC43uLrdBH.setSetting('av.akwam.verification',osGpLivVOZ9mgSkAD4uyhec3U0P)
				I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in wxIqRGu1yTCf:
					headers = {'Cookie':osGpLivVOZ9mgSkAD4uyhec3U0P}
					Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',GwcehBCRflA2MgH,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					wxIqRGu1yTCf = Pa6Q2LRkbtY0Id7nUNsZ.content
	if not L9GkAl40jOgC6nf7ixqhU3YQcJK1 and not osGpLivVOZ9mgSkAD4uyhec3U0P: I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return wxIqRGu1yTCf
def IyYirQzZGv(url,type,YUCPADxT3NrgM):
	ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93 = [],[]
	GwcehBCRflA2MgH = url
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-AKWAM-1st')
	CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
	KqSR7WPb0FXlsD6UNpfg = []
	if '/watch/' in CNhQcnS0dI6UFjbvLoyx or '/download/' in CNhQcnS0dI6UFjbvLoyx:
		qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<a href="http.*?</a>',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if qLx93JtrVCHlKaZW2hXc7dpiNmDR:
			for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
				CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				for yDTPzhEBKVJl7CX81,title in CPv45ibdnBc:
					if yDTPzhEBKVJl7CX81 in ZZH6czYDb0: continue
					if '/watch/' not in yDTPzhEBKVJl7CX81 and '/download/' not in yDTPzhEBKVJl7CX81: continue
					if 'ا' not in title:
						KqSR7WPb0FXlsD6UNpfg.append((title,yDTPzhEBKVJl7CX81))
						continue
					title = title.replace('</span>',Zg9FeADE84jSRIvPCrzYulw3sL).replace(' - ',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
					if 'span' in title: continue
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
			for title,yDTPzhEBKVJl7CX81 in KqSR7WPb0FXlsD6UNpfg:
				if yDTPzhEBKVJl7CX81 not in ZZH6czYDb0:
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
			lqQvOUWodZnhXLS2Vcuj6EtairFN = UwCT5Oz6Wo0BP
			if len(ZZH6czYDb0)>Mn5NGAdz6xc42s0:
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('بعضها يحتاج 60 ثانية',joaMtxEpGfDXFPRHQgLKizyOT2b93)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
			if ZZH6czYDb0 and lqQvOUWodZnhXLS2Vcuj6EtairFN>=UwCT5Oz6Wo0BP: GwcehBCRflA2MgH = ZZH6czYDb0[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	wxIqRGu1yTCf = wwiCDIvs9P(GwcehBCRflA2MgH)
	fo6s53yEnbklLpaJOzgR4Q01wxB,nnhWEIa6Tm = [],[]
	if type=='download':
		hjLBiG9rbkvJ45pHUZRyKf38Qn = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('btn-loader.*?href="(.*?)"',wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if hjLBiG9rbkvJ45pHUZRyKf38Qn:
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(hjLBiG9rbkvJ45pHUZRyKf38Qn[UwCT5Oz6Wo0BP])
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(YUCPADxT3NrgM)
	elif type=='watch':
		CPv45ibdnBc = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<source.*?src="(.*?)".*?size="(.*?)"',wxIqRGu1yTCf,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,size in CPv45ibdnBc:
			if not yDTPzhEBKVJl7CX81: continue
			if YUCPADxT3NrgM in size:
				nnhWEIa6Tm.append(size)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
				break
		if not fo6s53yEnbklLpaJOzgR4Q01wxB:
			for yDTPzhEBKVJl7CX81,size in CPv45ibdnBc:
				if not yDTPzhEBKVJl7CX81: continue
				nnhWEIa6Tm.append(size)
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if not fo6s53yEnbklLpaJOzgR4Q01wxB: return 'Error: Resolver Failed AKWAM',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def pQ1ZiwXaM0(url,VaOH2318eP5yQWXrkcx):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-AKOAM-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	cookies = Pa6Q2LRkbtY0Id7nUNsZ.cookies
	if 'golink' in list(cookies.keys()):
		osGpLivVOZ9mgSkAD4uyhec3U0P = cookies['golink']
		osGpLivVOZ9mgSkAD4uyhec3U0P = UAjMPLdITqWChbrcB(uumhMi6O4pk7Gjd5aTQqy2Z(osGpLivVOZ9mgSkAD4uyhec3U0P))
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('route":"(.*?)"',osGpLivVOZ9mgSkAD4uyhec3U0P,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		hc5ePKxl4LJvEjDgTm = items[UwCT5Oz6Wo0BP].replace('\/','/')
		hc5ePKxl4LJvEjDgTm = uumhMi6O4pk7Gjd5aTQqy2Z(hc5ePKxl4LJvEjDgTm)
	else: hc5ePKxl4LJvEjDgTm = url
	if 'catch.is' in hc5ePKxl4LJvEjDgTm:
		bUct2lM4esE8mVBILAXJOZ = hc5ePKxl4LJvEjDgTm.split('%2F')[-Mn5NGAdz6xc42s0]
		hc5ePKxl4LJvEjDgTm = 'http://catch.is/'+bUct2lM4esE8mVBILAXJOZ
		return 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[hc5ePKxl4LJvEjDgTm]
	else:
		website = PhpFa6EdVS['AKOAM'][UwCT5Oz6Wo0BP]
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',website,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-AKOAM-2nd')
		rHCZ02fmNhGS = Pa6Q2LRkbtY0Id7nUNsZ.url
		YAQCdqosX2z5lOGc3 = hc5ePKxl4LJvEjDgTm.split('/')[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		kTVy5DAjqHmM8Q = rHCZ02fmNhGS.split('/')[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]
		JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm.replace(YAQCdqosX2z5lOGc3,kTVy5DAjqHmM8Q)
		headers = { 'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL , 'X-Requested-With':'XMLHttpRequest' , 'Referer':JaqiYfEglZDvmwQNS8zR }
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST', JaqiYfEglZDvmwQNS8zR, Zg9FeADE84jSRIvPCrzYulw3sL, headers, vvglE69OFKBm817Nkc,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-AKOAM-3rd')
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('direct_link":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if not items:
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<iframe.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
			if not items:
				items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<embed.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL|aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.IGNORECASE)
		if items:
			yDTPzhEBKVJl7CX81 = items[UwCT5Oz6Wo0BP].replace('\/','/')
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.rstrip('/')
			if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:' + yDTPzhEBKVJl7CX81
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('http://','https://')
			if VaOH2318eP5yQWXrkcx==Zg9FeADE84jSRIvPCrzYulw3sL: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
			else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = 'NEED_EXTERNAL_RESOLVERS',[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
		else: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = 'Error: Resolver Failed AKOAM',[],[]
		return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def x1yIRrBg8Sf(url):
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-RAPIDVIDEO-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<source src="(.*?)".*?label="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB,errno = [],[],Zg9FeADE84jSRIvPCrzYulw3sL
	if items:
		for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a in items:
			nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def pdvXniJubODEGh1fRVA2SHIM8c(url):
	headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-UQLOAD-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sources: \["(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		url = items[UwCT5Oz6Wo0BP]+'|Referer='+url
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def FFxdlpqBmr8V(url):
	url = url.strip('/')
	if '/embed/' in url: bUct2lM4esE8mVBILAXJOZ = url.split('/')[NEc173Pr0jAwLF5OS]
	else: bUct2lM4esE8mVBILAXJOZ = url.split('/')[-Mn5NGAdz6xc42s0]
	url = 'https://vcstream.to/player?fid=' + bUct2lM4esE8mVBILAXJOZ
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-VCSTREAM-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('\\',Zg9FeADE84jSRIvPCrzYulw3sL)
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('file":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def Z89zqsFYGhdOw3ADCl5VtoSiQNXg(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-VIDOZA-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	for yDTPzhEBKVJl7CX81,cwMyvBgJuRXLWH48kpndbG7q2a,W8q6caR1ouAm in items:
		nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a+wjs26GpVfNiCUERHJ+W8q6caR1ouAm)
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed VIDOZA',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def RT28FCeLrhH01x(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-WATCHVIDEO-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = set(items)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	for bUct2lM4esE8mVBILAXJOZ,LfnWDFgRdJH4lZvt7yo28N,Jjr796Gdo12WzI0BwTuC84asPhv,cwMyvBgJuRXLWH48kpndbG7q2a,W8q6caR1ouAm in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+bUct2lM4esE8mVBILAXJOZ+'&mode='+LfnWDFgRdJH4lZvt7yo28N+'&hash='+Jjr796Gdo12WzI0BwTuC84asPhv
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-WATCHVIDEO-2nd')
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('direct link.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			nnhWEIa6Tm.append(cwMyvBgJuRXLWH48kpndbG7q2a+wjs26GpVfNiCUERHJ+W8q6caR1ouAm)
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	if len(fo6s53yEnbklLpaJOzgR4Q01wxB)==UwCT5Oz6Wo0BP: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def UpG3wvu0RmLtDqgkB94KzhZcIP8dX(url):
	yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL
	if Mn5NGAdz6xc42s0 or 'Key=' not in url:
		hc5ePKxl4LJvEjDgTm = url.replace('upbom.live','uppom.live')
		hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.split('/')
		bUct2lM4esE8mVBILAXJOZ = hc5ePKxl4LJvEjDgTm[O4dklMvZ8ULcS]
		hc5ePKxl4LJvEjDgTm = '/'.join(hc5ePKxl4LJvEjDgTm[UwCT5Oz6Wo0BP:NEc173Pr0jAwLF5OS])
		EEFf6enQDxk = {'id':bUct2lM4esE8mVBILAXJOZ,'op':'download2','method_free':'Free+Download+%3E%3E'}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',hc5ePKxl4LJvEjDgTm,EEFf6enQDxk,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-UPBOM-1st')
		if 'Location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['Location']
		if not yDTPzhEBKVJl7CX81 and Pa6Q2LRkbtY0Id7nUNsZ.succeeded:
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('id="direct_link".*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
	else:
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-UPBOM-2nd')
		if 'location' in list(Pa6Q2LRkbtY0Id7nUNsZ.headers.keys()): yDTPzhEBKVJl7CX81 = Pa6Q2LRkbtY0Id7nUNsZ.headers['location']
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	return 'Error: Resolver Failed UPBOM',[],[]
def grAa8UdWkpub(url):
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-LIIVIDEO-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sources:.*?"(.*?)","(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[]
	if items:
		nnhWEIa6Tm.append('mp4')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(items[UwCT5Oz6Wo0BP][Mn5NGAdz6xc42s0])
		nnhWEIa6Tm.append('m3u8')
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(items[UwCT5Oz6Wo0BP][UwCT5Oz6Wo0BP])
		return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
ZnC5xweA7Qa2X8vYp = vvglE69OFKBm817Nkc
def eRwxN7KrW0(url):
	global ZnC5xweA7Qa2X8vYp
	if ZnC5xweA7Qa2X8vYp: return 'Error    : Resolver YOUTUBE Failed',[],[]
	ZnC5xweA7Qa2X8vYp = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
	bUct2lM4esE8mVBILAXJOZ = url.split('/')[-Mn5NGAdz6xc42s0]
	bUct2lM4esE8mVBILAXJOZ = bUct2lM4esE8mVBILAXJOZ.split('&')[UwCT5Oz6Wo0BP]
	bUct2lM4esE8mVBILAXJOZ = bUct2lM4esE8mVBILAXJOZ.replace('watch?v=',Zg9FeADE84jSRIvPCrzYulw3sL)
	hc5ePKxl4LJvEjDgTm = PhpFa6EdVS['YOUTUBE'][UwCT5Oz6Wo0BP]+'/watch?v='+bUct2lM4esE8mVBILAXJOZ
	joIuF3TtfVUdby7K2N = 'http://youtu.be/'+bUct2lM4esE8mVBILAXJOZ
	aXT8hF9ylD6pMHj7BZsYQnA,DpgrWvF3wOCI5MEn4dXaGx,zUOoIHnWacwMtFr3yGkN2xu4gi,MhpvcyiPkbw0atNDXBURgl = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
	if UwCT5Oz6Wo0BP:
		for OEJ3PT81KtbZ in range(5):
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-YOUTUBE-1st')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
			if 'itag' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: break
			LNma2eq3vEguwVtHjn.sleep(DpahB8cwl4ZeKVsg71RuibSAfx0Ejr)
		LWBtsX3i8TfPJxF = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var ytInitialPlayerResponse = (.*?);</script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if LWBtsX3i8TfPJxF: LWBtsX3i8TfPJxF = LWBtsX3i8TfPJxF[UwCT5Oz6Wo0BP]
		else: LWBtsX3i8TfPJxF = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	else:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Zg9FeADE84jSRIvPCrzYulw3sL
		headers['Content-Type'] = 'application/json'
		JaqiYfEglZDvmwQNS8zR = PhpFa6EdVS['YOUTUBE'][UwCT5Oz6Wo0BP]+'/youtubei/v1/player'
		a8ayG4wjQhRPdF3Os = '{"videoId": "'+bUct2lM4esE8mVBILAXJOZ+'", "context": {"client": {"clientVersion": "1.9", "clientName": "ANDROID_TESTSUITE"}}}'
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'POST',JaqiYfEglZDvmwQNS8zR,a8ayG4wjQhRPdF3Os,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-YOUTUBE-2nd')
		LWBtsX3i8TfPJxF = Pa6Q2LRkbtY0Id7nUNsZ.content
	LWBtsX3i8TfPJxF = LWBtsX3i8TfPJxF.replace('\\u0026','&')
	SiMblPt0wfKdhvx = JGmfjhoyKZUl('dict',LWBtsX3i8TfPJxF)
	nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = ['بدون ترجمة يوتيوب'],[Zg9FeADE84jSRIvPCrzYulw3sL]
	try:
		UOQSuNkawVxYW0j = SiMblPt0wfKdhvx['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for zEMeLmF5g1tHIGKThqnZv43r in UOQSuNkawVxYW0j:
			yDTPzhEBKVJl7CX81 = zEMeLmF5g1tHIGKThqnZv43r['baseUrl']
			try: title = zEMeLmF5g1tHIGKThqnZv43r['name']['simpleText']
			except: title = zEMeLmF5g1tHIGKThqnZv43r['name']['runs'][UwCT5Oz6Wo0BP]['textt']
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(title)
	except: pass
	if len(nnhWEIa6Tm)>Mn5NGAdz6xc42s0:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الترجمة ('+str(len(nnhWEIa6Tm))+' ملف)', nnhWEIa6Tm)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN!=UwCT5Oz6Wo0BP:
			yDTPzhEBKVJl7CX81 = fo6s53yEnbklLpaJOzgR4Q01wxB[lqQvOUWodZnhXLS2Vcuj6EtairFN]+'&'
			tmvza0UiZy = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('&(fmt=.*?)&',yDTPzhEBKVJl7CX81)
			if tmvza0UiZy: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace(tmvza0UiZy[UwCT5Oz6Wo0BP],'fmt=vtt')
			else: yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'fmt=vtt'
			aXT8hF9ylD6pMHj7BZsYQnA = yDTPzhEBKVJl7CX81.strip('&')
	vvy6dnOMNsB3ZCWU09YQu,qtJ7YwyzuUsml4x0jM,an5GQFpEJxW9,TNPEAmKFYZJjsktnx5eIoSM,aTZNB9SyUCpHrPgK8lDE0xhA = [],[],[],[],[]
	try: DpgrWvF3wOCI5MEn4dXaGx = SiMblPt0wfKdhvx['streamingData']['dashManifestUrl']
	except: pass
	try: zUOoIHnWacwMtFr3yGkN2xu4gi = SiMblPt0wfKdhvx['streamingData']['hlsManifestUrl']
	except: pass
	try: vvy6dnOMNsB3ZCWU09YQu = SiMblPt0wfKdhvx['streamingData']['formats']
	except: pass
	try: qtJ7YwyzuUsml4x0jM = SiMblPt0wfKdhvx['streamingData']['adaptiveFormats']
	except: pass
	dnD40ZjBAsiGLEp8Qy = vvy6dnOMNsB3ZCWU09YQu+qtJ7YwyzuUsml4x0jM
	for dict in dnD40ZjBAsiGLEp8Qy:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			SS5sovXA2zyC3GQUWu0m = dict['signatureCipher'].split('&')
			for r1OMYvp0ViTG in SS5sovXA2zyC3GQUWu0m:
				key,B251BPiLbvG9UxszKtlI7YQHmoWw = r1OMYvp0ViTG.split('=',1)
				dict[key] = UAjMPLdITqWChbrcB(B251BPiLbvG9UxszKtlI7YQHmoWw)
		if 'url' in list(dict.keys()): dict['url'] = UAjMPLdITqWChbrcB(dict['url'])
		an5GQFpEJxW9.append(dict)
	GmX8rCfsEjogehqyFR = Zg9FeADE84jSRIvPCrzYulw3sL
	if 'sp=sig' in LWBtsX3i8TfPJxF:
		if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-YOUTUBE-3rd')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		Ok0lZfciATo6V = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if Ok0lZfciATo6V:
			Ok0lZfciATo6V = PhpFa6EdVS['YOUTUBE'][UwCT5Oz6Wo0BP]+Ok0lZfciATo6V[UwCT5Oz6Wo0BP]
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',Ok0lZfciATo6V,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-YOUTUBE-4th')
			GmX8rCfsEjogehqyFR = Pa6Q2LRkbtY0Id7nUNsZ.content
			import youtube_signature.cipher as q8nULG1RsHEYmOxCzlVJ7v,youtube_signature.json_script_engine as JdQHChX2Arzi6eBNDEk8gaVo4s
			SS5sovXA2zyC3GQUWu0m = KmFLAGNDghfX5eliOHxq8.SS5sovXA2zyC3GQUWu0m.Cipher()
			SS5sovXA2zyC3GQUWu0m._object_cache = {}
			BiFoDOTxMpgPN2JRH1wYLe0sCm3Qr = SS5sovXA2zyC3GQUWu0m._load_javascript(GmX8rCfsEjogehqyFR)
			aqsVK05Omyz14doteSpg76xG8rMUX = JGmfjhoyKZUl('str',str(BiFoDOTxMpgPN2JRH1wYLe0sCm3Qr))
			ZS3dYTk2B7grwie = KmFLAGNDghfX5eliOHxq8.GGPS7bixueVYWJtN5F9wkfo13L.JsonScriptEngine(aqsVK05Omyz14doteSpg76xG8rMUX)
	for dict in an5GQFpEJxW9:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>Mn5NGAdz6xc42s0:
			TNPEAmKFYZJjsktnx5eIoSM.append(dict)
		elif GmX8rCfsEjogehqyFR and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			y2fatnIZjMK6FNwvLhBXGb4gzC = ZS3dYTk2B7grwie.execute(dict['s'])
			if y2fatnIZjMK6FNwvLhBXGb4gzC!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+y2fatnIZjMK6FNwvLhBXGb4gzC
				TNPEAmKFYZJjsktnx5eIoSM.append(dict)
	for dict in TNPEAmKFYZJjsktnx5eIoSM:
		QAHN1PzTaF,S4IGfrgeiNY1,chflIRAL6C0k7Tpd5VsM83E2X4,dycYjuzoBkZxN96TmG173VRqLs,Zl1ERx3MtqoBb0gypuIF,W8M9s7e13Gf2LkyDmPdjlxQAaC = 'unknown','unknown','unknown','Unknown',Zg9FeADE84jSRIvPCrzYulw3sL,'0'
		try:
			VFbwiHyWrCkom8SBGxv = dict['type']
			VFbwiHyWrCkom8SBGxv = VFbwiHyWrCkom8SBGxv.replace('+',Zg9FeADE84jSRIvPCrzYulw3sL)
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?)/(.*?);.*?"(.*?)"',VFbwiHyWrCkom8SBGxv,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			dycYjuzoBkZxN96TmG173VRqLs,QAHN1PzTaF,Zl1ERx3MtqoBb0gypuIF = items[UwCT5Oz6Wo0BP]
			EEO4ehLyWXkYs9Vv = Zl1ERx3MtqoBb0gypuIF.split(',')
			S4IGfrgeiNY1 = Zg9FeADE84jSRIvPCrzYulw3sL
			for r1OMYvp0ViTG in EEO4ehLyWXkYs9Vv: S4IGfrgeiNY1 += r1OMYvp0ViTG.split('.')[UwCT5Oz6Wo0BP]+','
			S4IGfrgeiNY1 = S4IGfrgeiNY1.strip(',')
			if 'bitrate' in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = Zg9FeADE84jSRIvPCrzYulw3sL
			if dycYjuzoBkZxN96TmG173VRqLs=='textt': continue
			elif ',' in VFbwiHyWrCkom8SBGxv:
				dycYjuzoBkZxN96TmG173VRqLs = 'A+V'
				chflIRAL6C0k7Tpd5VsM83E2X4 = QAHN1PzTaF+F4skx1A3wOEh9lmPuZMnpCzR+W8M9s7e13Gf2LkyDmPdjlxQAaC+dict['size'].split('x')[Mn5NGAdz6xc42s0]
			elif dycYjuzoBkZxN96TmG173VRqLs=='video':
				dycYjuzoBkZxN96TmG173VRqLs = 'Video'
				chflIRAL6C0k7Tpd5VsM83E2X4 = W8M9s7e13Gf2LkyDmPdjlxQAaC+dict['size'].split('x')[Mn5NGAdz6xc42s0]+F4skx1A3wOEh9lmPuZMnpCzR+dict['fps']+'fps'+F4skx1A3wOEh9lmPuZMnpCzR+QAHN1PzTaF
			elif dycYjuzoBkZxN96TmG173VRqLs=='audio':
				dycYjuzoBkZxN96TmG173VRqLs = 'Audio'
				chflIRAL6C0k7Tpd5VsM83E2X4 = W8M9s7e13Gf2LkyDmPdjlxQAaC+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+F4skx1A3wOEh9lmPuZMnpCzR+QAHN1PzTaF
		except:
			o4be19ApMtCrdf5 = CFzcuYA4GMkOi1qXSoLQ2x3Ry.format_exc()
			if o4be19ApMtCrdf5!='NoneType: None\n': cbzwJ3rLm0XhR52W7xoqE8Qljk.stderr.write(o4be19ApMtCrdf5)
		if 'dur=' in dict['url']: NAdtOanYBmF0IWbMvXxz7lERiTjo = round(0.5+float(dict['url'].split('dur=',1)[Mn5NGAdz6xc42s0].split('&',Mn5NGAdz6xc42s0)[UwCT5Oz6Wo0BP]))
		elif 'approxDurationMs' in list(dict.keys()): NAdtOanYBmF0IWbMvXxz7lERiTjo = round(0.5+float(dict['approxDurationMs'])/1000)
		else: NAdtOanYBmF0IWbMvXxz7lERiTjo = '0'
		if 'bitrate' not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = dict['size'].split('x')[Mn5NGAdz6xc42s0]
		else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = dycYjuzoBkZxN96TmG173VRqLs+':  '+chflIRAL6C0k7Tpd5VsM83E2X4+'  ('+S4IGfrgeiNY1+','+dict['itag']+')'
		dict['quality'] = chflIRAL6C0k7Tpd5VsM83E2X4.split(F4skx1A3wOEh9lmPuZMnpCzR)[UwCT5Oz6Wo0BP].split('kbps')[UwCT5Oz6Wo0BP]
		dict['type2'] = dycYjuzoBkZxN96TmG173VRqLs
		dict['filetype'] = QAHN1PzTaF
		dict['codecs'] = Zl1ERx3MtqoBb0gypuIF
		dict['duration'] = NAdtOanYBmF0IWbMvXxz7lERiTjo
		dict['bitrate'] = W8M9s7e13Gf2LkyDmPdjlxQAaC
		aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	xHDsCzmVNBSuU7aAbyFXrwe9d4c,DONT46Rds9tg5cjybnH2r0hmBkzF,JJXr91fnmitVRBAxMh4SpuToN6g,EQw4Jx6FMmSpaHyizo,XXMbhDNk8tH9OodvE4uxjcK = [],[],[],[],[]
	BUnmlTkZRarM48dEL,ZFjH5017tIOn93W,ZZOfoDtXWbm6y4zFGMJqUVue,UVJLGFuSn3m76IcoAfNCqRkXPxzD,MVshf93imc7N8qRJeQwG4P2aSxpB = [],[],[],[],[]
	if DpgrWvF3wOCI5MEn4dXaGx:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+F4skx1A3wOEh9lmPuZMnpCzR+'جودة ذكية'
		dict['url'] = DpgrWvF3wOCI5MEn4dXaGx
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	if zUOoIHnWacwMtFr3yGkN2xu4gi:
		ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(zUOoIHnWacwMtFr3yGkN2xu4gi)
		jhtuNW60MDJegGloFPUXa5CB3T = list(zip(ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47))
		for title,yDTPzhEBKVJl7CX81 in jhtuNW60MDJegGloFPUXa5CB3T:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = yDTPzhEBKVJl7CX81
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[UwCT5Oz6Wo0BP].rsplit(F4skx1A3wOEh9lmPuZMnpCzR)[-Mn5NGAdz6xc42s0]
			else: dict['bitrate'] = '10'
			if title.count(F4skx1A3wOEh9lmPuZMnpCzR)>Mn5NGAdz6xc42s0:
				YUCPADxT3NrgM = title.rsplit(F4skx1A3wOEh9lmPuZMnpCzR)[-O4dklMvZ8ULcS]
				if YUCPADxT3NrgM.isdigit(): dict['quality'] = YUCPADxT3NrgM
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+F4skx1A3wOEh9lmPuZMnpCzR+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+F4skx1A3wOEh9lmPuZMnpCzR+dict['bitrate']+'kbps  '+dict['quality']
			aTZNB9SyUCpHrPgK8lDE0xhA.append(dict)
	aTZNB9SyUCpHrPgK8lDE0xhA = sorted(aTZNB9SyUCpHrPgK8lDE0xhA,reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy,key=lambda key: float(key['bitrate']))
	if not aTZNB9SyUCpHrPgK8lDE0xhA:
		if not yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
			Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(FFP5vTqk3nDlEuGdIy,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-YOUTUBE-5th')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		qS5lWUzuCiJjxwyAo1EdtD6nprV = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="messagee">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		i68iLkExJaX = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		JXhn2P97BCK4yN1eWbLv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		try: L9Ha8UpTPxvZSj0l = SiMblPt0wfKdhvx['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][UwCT5Oz6Wo0BP]['textt']
		except: L9Ha8UpTPxvZSj0l = Zg9FeADE84jSRIvPCrzYulw3sL
		try: t0xhejPsHTO5WQfSlDJ3oFia6ZU7L = SiMblPt0wfKdhvx['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][UwCT5Oz6Wo0BP]['runs'][UwCT5Oz6Wo0BP]['textt']
		except: t0xhejPsHTO5WQfSlDJ3oFia6ZU7L = Zg9FeADE84jSRIvPCrzYulw3sL
		try: lt6Naxkn0dE2jp = SiMblPt0wfKdhvx['playabilityStatus']['reason']
		except: lt6Naxkn0dE2jp = Zg9FeADE84jSRIvPCrzYulw3sL
		if qS5lWUzuCiJjxwyAo1EdtD6nprV or VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6 or i68iLkExJaX or JXhn2P97BCK4yN1eWbLv or L9Ha8UpTPxvZSj0l or t0xhejPsHTO5WQfSlDJ3oFia6ZU7L or lt6Naxkn0dE2jp:
			if   qS5lWUzuCiJjxwyAo1EdtD6nprV: oHkimLnwDKNxlheUuGAMQIg9jY7dz = qS5lWUzuCiJjxwyAo1EdtD6nprV[UwCT5Oz6Wo0BP]
			elif VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6: oHkimLnwDKNxlheUuGAMQIg9jY7dz = VKcPJpZkm8XMbwaN1Hey5lA9S2TLU6[UwCT5Oz6Wo0BP]
			elif i68iLkExJaX: oHkimLnwDKNxlheUuGAMQIg9jY7dz = i68iLkExJaX[UwCT5Oz6Wo0BP]
			elif JXhn2P97BCK4yN1eWbLv: oHkimLnwDKNxlheUuGAMQIg9jY7dz = JXhn2P97BCK4yN1eWbLv[UwCT5Oz6Wo0BP]
			elif L9Ha8UpTPxvZSj0l: oHkimLnwDKNxlheUuGAMQIg9jY7dz = L9Ha8UpTPxvZSj0l
			elif t0xhejPsHTO5WQfSlDJ3oFia6ZU7L: oHkimLnwDKNxlheUuGAMQIg9jY7dz = t0xhejPsHTO5WQfSlDJ3oFia6ZU7L
			elif lt6Naxkn0dE2jp: oHkimLnwDKNxlheUuGAMQIg9jY7dz = lt6Naxkn0dE2jp
			SMcIzDwl6ZYH5apGqtJWs = oHkimLnwDKNxlheUuGAMQIg9jY7dz.replace(SmFfh9kPpeoNBdcV7WnJ1LHMuXZO,Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
			R4sklnAbdw6CvMu = PPQORjT2lc7SVkKwFI4D+'هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن'+u4IRSmrYMKkaHUBnDiLWh
			I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من الموقع والمبرمج',R4sklnAbdw6CvMu+'\n\n'+SMcIzDwl6ZYH5apGqtJWs)
			return 'Error    : Resolver YOUTUBE Failed: '+SMcIzDwl6ZYH5apGqtJWs,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	ccrMYZf56WKNl7kyeRu,cc9G7EPUaOZN,sQJ4oGWx9LvO6jUdFVzwit3EqTgK = [],[],[]
	for dict in aTZNB9SyUCpHrPgK8lDE0xhA:
		if dict['type2']=='Video':
			xHDsCzmVNBSuU7aAbyFXrwe9d4c.append(dict['title'])
			BUnmlTkZRarM48dEL.append(dict)
		elif dict['type2']=='Audio':
			DONT46Rds9tg5cjybnH2r0hmBkzF.append(dict['title'])
			ZFjH5017tIOn93W.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if 'bitrate' not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = '0'
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict['bitrate']
			ccrMYZf56WKNl7kyeRu.append([dict,{},title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
		else:
			title = dict['title'].replace('A+V:  ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if 'bitrate' not in list(dict.keys()): W8M9s7e13Gf2LkyDmPdjlxQAaC = '0'
			else: W8M9s7e13Gf2LkyDmPdjlxQAaC = dict['bitrate']
			ccrMYZf56WKNl7kyeRu.append([dict,{},title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
			JJXr91fnmitVRBAxMh4SpuToN6g.append(title)
			ZZOfoDtXWbm6y4zFGMJqUVue.append(dict)
		MiLAY1z26vj5UTK = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: MiLAY1z26vj5UTK = vvglE69OFKBm817Nkc
			elif NGiBmYp8vX9T426lHn7ue<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: MiLAY1z26vj5UTK = vvglE69OFKBm817Nkc
		if dict['type2']=='Video' and dict['init']!='0-0' and MiLAY1z26vj5UTK==CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			XXMbhDNk8tH9OodvE4uxjcK.append(dict['title'])
			MVshf93imc7N8qRJeQwG4P2aSxpB.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and MiLAY1z26vj5UTK==CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
			EQw4Jx6FMmSpaHyizo.append(dict['title'])
			UVJLGFuSn3m76IcoAfNCqRkXPxzD.append(dict)
	for giEV3vqyDHPaCklUreh in UVJLGFuSn3m76IcoAfNCqRkXPxzD:
		KAXSetWLral6y2 = giEV3vqyDHPaCklUreh['bitrate']
		for qIMNa2nOfgdkPxKETc0WJLZY in MVshf93imc7N8qRJeQwG4P2aSxpB:
			hX3J4Scy8FionrlDG1A = qIMNa2nOfgdkPxKETc0WJLZY['bitrate']
			W8M9s7e13Gf2LkyDmPdjlxQAaC = hX3J4Scy8FionrlDG1A+KAXSetWLral6y2
			title = qIMNa2nOfgdkPxKETc0WJLZY['title'].replace('Video:  ','mpd  ')
			title = title.replace(qIMNa2nOfgdkPxKETc0WJLZY['filetype']+F4skx1A3wOEh9lmPuZMnpCzR,Zg9FeADE84jSRIvPCrzYulw3sL)
			title = title.replace(str((float(hX3J4Scy8FionrlDG1A*10)//1024/10))+'kbps',str((float(W8M9s7e13Gf2LkyDmPdjlxQAaC*10)//1024/10))+'kbps')
			title = title+'('+giEV3vqyDHPaCklUreh['title'].split('(',Mn5NGAdz6xc42s0)[Mn5NGAdz6xc42s0]
			ccrMYZf56WKNl7kyeRu.append([qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
	ccrMYZf56WKNl7kyeRu = sorted(ccrMYZf56WKNl7kyeRu, reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy, key=lambda key: float(key[O4dklMvZ8ULcS]))
	for qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC in ccrMYZf56WKNl7kyeRu:
		AMv3D891O07rwVsYgb5tkziNxd2 = qIMNa2nOfgdkPxKETc0WJLZY['filetype']
		if 'filetype' in list(giEV3vqyDHPaCklUreh.keys()):
			AMv3D891O07rwVsYgb5tkziNxd2 = 'mpd'
		if AMv3D891O07rwVsYgb5tkziNxd2 not in sQJ4oGWx9LvO6jUdFVzwit3EqTgK:
			sQJ4oGWx9LvO6jUdFVzwit3EqTgK.append(AMv3D891O07rwVsYgb5tkziNxd2)
			cc9G7EPUaOZN.append([qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC])
	SHVNdQ2ypFUZAMCtE7gOow9K,PTB6i0GMySIgqQlvd2UFZ3,BdAifjEWrcQ = [],[],UwCT5Oz6Wo0BP
	Cvz4PanE5N,cQOHCwI3nBsf24tRZ5hizLDSo = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
	try: Cvz4PanE5N = SiMblPt0wfKdhvx['videoDetails']['author']
	except: Cvz4PanE5N = Zg9FeADE84jSRIvPCrzYulw3sL
	try: d1lvAHTkc0RqX69s8zrO = SiMblPt0wfKdhvx['videoDetails']['channelId']
	except: d1lvAHTkc0RqX69s8zrO = Zg9FeADE84jSRIvPCrzYulw3sL
	if Cvz4PanE5N and d1lvAHTkc0RqX69s8zrO:
		BdAifjEWrcQ += Mn5NGAdz6xc42s0
		title = PPQORjT2lc7SVkKwFI4D+'OWNER:  '+Cvz4PanE5N+u4IRSmrYMKkaHUBnDiLWh
		yDTPzhEBKVJl7CX81 = PhpFa6EdVS['YOUTUBE'][UwCT5Oz6Wo0BP]+'/channel/'+d1lvAHTkc0RqX69s8zrO
		SHVNdQ2ypFUZAMCtE7gOow9K.append(title)
		PTB6i0GMySIgqQlvd2UFZ3.append(yDTPzhEBKVJl7CX81)
		try: cQOHCwI3nBsf24tRZ5hizLDSo = SiMblPt0wfKdhvx['videoDetails']['thumbnail']['thumbnails'][-Mn5NGAdz6xc42s0]['url']
		except: pass
	for qIMNa2nOfgdkPxKETc0WJLZY,giEV3vqyDHPaCklUreh,title,W8M9s7e13Gf2LkyDmPdjlxQAaC in cc9G7EPUaOZN:
		SHVNdQ2ypFUZAMCtE7gOow9K.append(title) ; PTB6i0GMySIgqQlvd2UFZ3.append('highest')
	if JJXr91fnmitVRBAxMh4SpuToN6g: SHVNdQ2ypFUZAMCtE7gOow9K.append('صورة وصوت محددة') ; PTB6i0GMySIgqQlvd2UFZ3.append('muxed')
	if ccrMYZf56WKNl7kyeRu: SHVNdQ2ypFUZAMCtE7gOow9K.append('صورة وصوت المتوفر') ; PTB6i0GMySIgqQlvd2UFZ3.append('all')
	if XXMbhDNk8tH9OodvE4uxjcK: SHVNdQ2ypFUZAMCtE7gOow9K.append('mpd اختر الصورة والصوت') ; PTB6i0GMySIgqQlvd2UFZ3.append('mpd')
	if xHDsCzmVNBSuU7aAbyFXrwe9d4c: SHVNdQ2ypFUZAMCtE7gOow9K.append('صورة بدون صوت') ; PTB6i0GMySIgqQlvd2UFZ3.append('video')
	if DONT46Rds9tg5cjybnH2r0hmBkzF: SHVNdQ2ypFUZAMCtE7gOow9K.append('صوت بدون صورة') ; PTB6i0GMySIgqQlvd2UFZ3.append('audio')
	ktgDwbcXMKnVUBure5y3i6ToZFq = vvglE69OFKBm817Nkc
	while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc(joIuF3TtfVUdby7K2N, SHVNdQ2ypFUZAMCtE7gOow9K)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN==-Mn5NGAdz6xc42s0: return 'EXIT_ALL_RESOLVERS',[],[]
		elif lqQvOUWodZnhXLS2Vcuj6EtairFN==UwCT5Oz6Wo0BP and Cvz4PanE5N:
			yDTPzhEBKVJl7CX81 = PTB6i0GMySIgqQlvd2UFZ3[lqQvOUWodZnhXLS2Vcuj6EtairFN]
			EEHGwO3V8XjP651npWNz4gmlMABS = cbzwJ3rLm0XhR52W7xoqE8Qljk.argv[UwCT5Oz6Wo0BP]+'?type=folder&mode=141&name='+OJYiDeyvSPTNI9(Cvz4PanE5N)+'&url='+yDTPzhEBKVJl7CX81
			if cQOHCwI3nBsf24tRZ5hizLDSo: EEHGwO3V8XjP651npWNz4gmlMABS = EEHGwO3V8XjP651npWNz4gmlMABS+'&image='+OJYiDeyvSPTNI9(cQOHCwI3nBsf24tRZ5hizLDSo)
			Zz9SeICTbPksXy6nuOtLGWhN2V.executebuiltin("Container.Update("+EEHGwO3V8XjP651npWNz4gmlMABS+")")
			return 'EXIT_ALL_RESOLVERS',[],[]
		KPAgkny9rSD0Xdx6CUse1a2LG = PTB6i0GMySIgqQlvd2UFZ3[lqQvOUWodZnhXLS2Vcuj6EtairFN]
		wq16EVmW5ezHgZj4MPxNsGA9Yn = SHVNdQ2ypFUZAMCtE7gOow9K[lqQvOUWodZnhXLS2Vcuj6EtairFN]
		if KPAgkny9rSD0Xdx6CUse1a2LG=='dash':
			MhpvcyiPkbw0atNDXBURgl = DpgrWvF3wOCI5MEn4dXaGx
			break
		elif KPAgkny9rSD0Xdx6CUse1a2LG in ['audio','video','muxed']:
			if KPAgkny9rSD0Xdx6CUse1a2LG=='muxed': nnhWEIa6Tm,lYurfDCiEO8 = JJXr91fnmitVRBAxMh4SpuToN6g,ZZOfoDtXWbm6y4zFGMJqUVue
			elif KPAgkny9rSD0Xdx6CUse1a2LG=='video': nnhWEIa6Tm,lYurfDCiEO8 = xHDsCzmVNBSuU7aAbyFXrwe9d4c,BUnmlTkZRarM48dEL
			elif KPAgkny9rSD0Xdx6CUse1a2LG=='audio': nnhWEIa6Tm,lYurfDCiEO8 = DONT46Rds9tg5cjybnH2r0hmBkzF,ZFjH5017tIOn93W
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الملف ('+str(len(nnhWEIa6Tm))+' ملف)', nnhWEIa6Tm)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				MhpvcyiPkbw0atNDXBURgl = lYurfDCiEO8[lqQvOUWodZnhXLS2Vcuj6EtairFN]['url']
				wq16EVmW5ezHgZj4MPxNsGA9Yn = nnhWEIa6Tm[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				break
		elif KPAgkny9rSD0Xdx6CUse1a2LG=='mpd':
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر جودة الصورة ('+str(len(XXMbhDNk8tH9OodvE4uxjcK))+' ملف)', XXMbhDNk8tH9OodvE4uxjcK)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				wq16EVmW5ezHgZj4MPxNsGA9Yn = XXMbhDNk8tH9OodvE4uxjcK[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				STY4hGQDjBcJqiz60RM8x2vFdWLlw = MVshf93imc7N8qRJeQwG4P2aSxpB[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر جودة الصوت ('+str(len(EQw4Jx6FMmSpaHyizo))+' ملف)', EQw4Jx6FMmSpaHyizo)
				if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
					wq16EVmW5ezHgZj4MPxNsGA9Yn += ' + '+EQw4Jx6FMmSpaHyizo[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					Z9dKgxe7Nb1fsQrSjO5lanp = UVJLGFuSn3m76IcoAfNCqRkXPxzD[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
					break
		elif KPAgkny9rSD0Xdx6CUse1a2LG=='all':
			YyEr2JT4sik9K0N,mmGJreUkZgyC5MWdpulA,QYUCZbet7qns,EEViDU6MofmWjqcXw = list(zip(*ccrMYZf56WKNl7kyeRu))
			lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الملف ('+str(len(QYUCZbet7qns))+' ملف)', QYUCZbet7qns)
			if lqQvOUWodZnhXLS2Vcuj6EtairFN!=-Mn5NGAdz6xc42s0:
				wq16EVmW5ezHgZj4MPxNsGA9Yn = QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				STY4hGQDjBcJqiz60RM8x2vFdWLlw = YyEr2JT4sik9K0N[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				if 'mpd' in QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN] and STY4hGQDjBcJqiz60RM8x2vFdWLlw['url']!=DpgrWvF3wOCI5MEn4dXaGx:
					Z9dKgxe7Nb1fsQrSjO5lanp = mmGJreUkZgyC5MWdpulA[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				else: MhpvcyiPkbw0atNDXBURgl = STY4hGQDjBcJqiz60RM8x2vFdWLlw['url']
				break
		elif KPAgkny9rSD0Xdx6CUse1a2LG=='highest':
			YyEr2JT4sik9K0N,mmGJreUkZgyC5MWdpulA,QYUCZbet7qns,EEViDU6MofmWjqcXw = list(zip(*cc9G7EPUaOZN))
			STY4hGQDjBcJqiz60RM8x2vFdWLlw = YyEr2JT4sik9K0N[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
			if 'mpd' in QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ] and STY4hGQDjBcJqiz60RM8x2vFdWLlw['url']!=DpgrWvF3wOCI5MEn4dXaGx:
				Z9dKgxe7Nb1fsQrSjO5lanp = mmGJreUkZgyC5MWdpulA[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
				ktgDwbcXMKnVUBure5y3i6ToZFq = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			else: MhpvcyiPkbw0atNDXBURgl = STY4hGQDjBcJqiz60RM8x2vFdWLlw['url']
			wq16EVmW5ezHgZj4MPxNsGA9Yn = QYUCZbet7qns[lqQvOUWodZnhXLS2Vcuj6EtairFN-BdAifjEWrcQ]
			break
	if not ktgDwbcXMKnVUBure5y3i6ToZFq: c9RjgrzQxZ4YHJ5iT = MhpvcyiPkbw0atNDXBURgl
	else: c9RjgrzQxZ4YHJ5iT = 'Video: '+STY4hGQDjBcJqiz60RM8x2vFdWLlw['url']+' + Audio: '+Z9dKgxe7Nb1fsQrSjO5lanp['url']
	if ktgDwbcXMKnVUBure5y3i6ToZFq:
		jp5HefdQzXwxV81myK6oGDEg = int(STY4hGQDjBcJqiz60RM8x2vFdWLlw['duration'])
		vTG7bx2PuBWEKYpXflOjs = int(Z9dKgxe7Nb1fsQrSjO5lanp['duration'])
		NAdtOanYBmF0IWbMvXxz7lERiTjo = str(max(jp5HefdQzXwxV81myK6oGDEg,vTG7bx2PuBWEKYpXflOjs))
		ZhjVrDwMlL2BdNU5skzHyC0cPpaFX1 = STY4hGQDjBcJqiz60RM8x2vFdWLlw['url'].replace('&','&amp;')
		DqUbITsrEQ = Z9dKgxe7Nb1fsQrSjO5lanp['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+NAdtOanYBmF0IWbMvXxz7lERiTjo+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['filetype']+'" subsegmentAlignment="True">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['itag']+'" codecs="'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['codecs']+'" startWithSAP="1" bandwidth="'+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw['bitrate'])+'" width="'+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw['width'])+'" height="'+str(STY4hGQDjBcJqiz60RM8x2vFdWLlw['height'])+'" frameRate="'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['fps']+'">\n'
		mpd += '<BaseURL>'+ZhjVrDwMlL2BdNU5skzHyC0cPpaFX1+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['index']+'">\n'
		mpd += '<Initialization range="'+STY4hGQDjBcJqiz60RM8x2vFdWLlw['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+Z9dKgxe7Nb1fsQrSjO5lanp['filetype']+'" subsegmentAlignment="True">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+Z9dKgxe7Nb1fsQrSjO5lanp['itag']+'" codecs="'+Z9dKgxe7Nb1fsQrSjO5lanp['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+Z9dKgxe7Nb1fsQrSjO5lanp['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+DqUbITsrEQ+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+Z9dKgxe7Nb1fsQrSjO5lanp['index']+'">\n'
		mpd += '<Initialization range="'+Z9dKgxe7Nb1fsQrSjO5lanp['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if GGfPQnrJKEqMv2ZVxdD:
			import http.server as ddg7f8JuRIBPzQkhFOXsECKjTGnp3o
			import http.client as ss0f1CFxiL
		else:
			import BaseHTTPServer as ddg7f8JuRIBPzQkhFOXsECKjTGnp3o
			import httplib as ss0f1CFxiL
		class y4yNqHekmVoFOr7TdYn(ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.HTTPServer):
			def __init__(rX4tN2IJPD0yYa1jw8WlSmCL,ip='localhost',port=55055,mpd='<>'):
				rX4tN2IJPD0yYa1jw8WlSmCL.ip = ip
				rX4tN2IJPD0yYa1jw8WlSmCL.port = port
				rX4tN2IJPD0yYa1jw8WlSmCL.mpd = mpd
				ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.HTTPServer.__init__(rX4tN2IJPD0yYa1jw8WlSmCL,(rX4tN2IJPD0yYa1jw8WlSmCL.ip,rX4tN2IJPD0yYa1jw8WlSmCL.port),BXNDfIuhWrctnSo1v4)
				rX4tN2IJPD0yYa1jw8WlSmCL.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.threads = fZLqV6xaCWsTItK2ngd(vvglE69OFKBm817Nkc)
				rX4tN2IJPD0yYa1jw8WlSmCL.threads.FHEp9T3OzwUf6BSq(Mn5NGAdz6xc42s0,rX4tN2IJPD0yYa1jw8WlSmCL.FFDyejL7S46)
			def FFDyejL7S46(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
				while rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning:
					rX4tN2IJPD0yYa1jw8WlSmCL.handle_request()
			def stop(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.keeprunning = vvglE69OFKBm817Nkc
				rX4tN2IJPD0yYa1jw8WlSmCL.Ig1jWXvabcN7P()
			def ETwjFlzhWc(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.stop()
				rX4tN2IJPD0yYa1jw8WlSmCL.M8hdlBv4XYT.close()
				rX4tN2IJPD0yYa1jw8WlSmCL.server_close()
			def fzaC0BNKvxpdwbmgn5l6Eo78Rqs2jV(rX4tN2IJPD0yYa1jw8WlSmCL,mpd):
				rX4tN2IJPD0yYa1jw8WlSmCL.mpd = mpd
			def Ig1jWXvabcN7P(rX4tN2IJPD0yYa1jw8WlSmCL):
				KAyrTaiwVmYnCS2NbPp = ss0f1CFxiL.HTTPConnection(rX4tN2IJPD0yYa1jw8WlSmCL.ip+':'+str(rX4tN2IJPD0yYa1jw8WlSmCL.port))
				KAyrTaiwVmYnCS2NbPp.request("HEAD", "/")
		class BXNDfIuhWrctnSo1v4(ddg7f8JuRIBPzQkhFOXsECKjTGnp3o.BaseHTTPRequestHandler):
			def LqfeBsNQymvY5hK1lEpju9(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.send_response(200)
				rX4tN2IJPD0yYa1jw8WlSmCL.send_header('Content-type','textt/plain')
				rX4tN2IJPD0yYa1jw8WlSmCL.end_headers()
				rX4tN2IJPD0yYa1jw8WlSmCL.wfile.write(rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.mpd.encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc))
				LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
				if rX4tN2IJPD0yYa1jw8WlSmCL.path=='/youtube.mpd': rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.ETwjFlzhWc()
				if rX4tN2IJPD0yYa1jw8WlSmCL.path=='/shutdown': rX4tN2IJPD0yYa1jw8WlSmCL.m0t48jnKhrQFJViguoMl9NBPp.ETwjFlzhWc()
			def IYxNW2RDMBnFrTc7JV(rX4tN2IJPD0yYa1jw8WlSmCL):
				rX4tN2IJPD0yYa1jw8WlSmCL.send_response(200)
				rX4tN2IJPD0yYa1jw8WlSmCL.end_headers()
		U3DI1pSatT9GbyXeP6Rd = y4yNqHekmVoFOr7TdYn('127.0.0.1',55055,mpd)
		MhpvcyiPkbw0atNDXBURgl = U3DI1pSatT9GbyXeP6Rd.mpdurl
		U3DI1pSatT9GbyXeP6Rd.start()
	else: U3DI1pSatT9GbyXeP6Rd = Zg9FeADE84jSRIvPCrzYulw3sL
	if not MhpvcyiPkbw0atNDXBURgl: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[[MhpvcyiPkbw0atNDXBURgl,aXT8hF9ylD6pMHj7BZsYQnA,U3DI1pSatT9GbyXeP6Rd]]
def FF5NbecBfM1ED36lQ(url):
	headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-VIDBOB-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('file:"(.*?)"(,label:"(.*?)"|)\}',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	items = set(items)
	items = sorted(items, reverse=CR6in9cZKo2SqGFmrHOLdhYEVTjsBy, key=lambda key: key[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr])
	ORuP1Qjt7DETJvNHKr,nnhWEIa6Tm,VRzd5ahswMGUtuCKpLjroP9T6kx47,fo6s53yEnbklLpaJOzgR4Q01wxB = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for yDTPzhEBKVJl7CX81,DMKySWniQ0HqtCsrg65dmb2Tha,cwMyvBgJuRXLWH48kpndbG7q2a in items:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('https:','http:')
		if '.m3u8' in yDTPzhEBKVJl7CX81:
			ORuP1Qjt7DETJvNHKr,VRzd5ahswMGUtuCKpLjroP9T6kx47 = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81)
			fo6s53yEnbklLpaJOzgR4Q01wxB = fo6s53yEnbklLpaJOzgR4Q01wxB + VRzd5ahswMGUtuCKpLjroP9T6kx47
			if ORuP1Qjt7DETJvNHKr[UwCT5Oz6Wo0BP]=='-1': nnhWEIa6Tm.append('سيرفر خاص'+'   m3u8')
			else:
				for title in ORuP1Qjt7DETJvNHKr:
					nnhWEIa6Tm.append('سيرفر خاص'+Qmr9KYe4lX3G1fcnSg0h8zkOMWPR6J+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+cwMyvBgJuRXLWH48kpndbG7q2a
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
			nnhWEIa6Tm.append(title)
	return Zg9FeADE84jSRIvPCrzYulw3sL,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
def ymNcGjZfWdUuv2sSpelH(url,yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG):
	joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0,R6R2SncUg57LCAFd0,ffCVRQTFby24aYhA3szw8W,CPv45ibdnBc = [],[],[],[],[]
	if 'str' not in str(type(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)): yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,'ignore')
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<video preload.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if not yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('direct_link.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if yDTPzhEBKVJl7CX81 and not wzX1klOfLVhb2B4ita(yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]): yDTPzhEBKVJl7CX81 = []
	if yDTPzhEBKVJl7CX81:
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81[UwCT5Oz6Wo0BP]
		title = yDTPzhEBKVJl7CX81.rsplit('.',1)[Mn5NGAdz6xc42s0]
		joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title)
		ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	else:
		qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('sources: *(\[.*?\])',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var sources = (\{.*?\})',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var jw = (\{.*?\})',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not qLx93JtrVCHlKaZW2hXc7dpiNmDR: qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var player = .*?\((\{.*?\})\)',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if qLx93JtrVCHlKaZW2hXc7dpiNmDR:
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = qLx93JtrVCHlKaZW2hXc7dpiNmDR[UwCT5Oz6Wo0BP]
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub(r'([\{\,][\t\s\n\r]*)(\w+[\t\s]*):',r'\1"\2":',qLx93JtrVCHlKaZW2hXc7dpiNmDR)
			qLx93JtrVCHlKaZW2hXc7dpiNmDR = JGmfjhoyKZUl('dict',qLx93JtrVCHlKaZW2hXc7dpiNmDR)
			if isinstance(qLx93JtrVCHlKaZW2hXc7dpiNmDR,dict): qLx93JtrVCHlKaZW2hXc7dpiNmDR = [qLx93JtrVCHlKaZW2hXc7dpiNmDR]
			for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
				zF90fUaVNHqwh5CK,yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL
				if isinstance(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,dict):
					keys = list(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.keys())
					if   'type' in keys: zF90fUaVNHqwh5CK = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['type'])
					if   'file' in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['file']
					elif 'hls' in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['hls']
					elif 'src' in keys: yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['src']
					if   'label' in keys: title = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['label'])
					elif 'video_height' in keys: title = str(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA['video_height'])
					elif '.' in yDTPzhEBKVJl7CX81: title = yDTPzhEBKVJl7CX81.rsplit('.',1)[Mn5NGAdz6xc42s0]
					else: title = yDTPzhEBKVJl7CX81
				elif isinstance(nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,str):
					yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA
					title = yDTPzhEBKVJl7CX81.rsplit('.',1)[Mn5NGAdz6xc42s0]
				if Mn5NGAdz6xc42s0:
					joaMtxEpGfDXFPRHQgLKizyOT2b93.append(title+F4skx1A3wOEh9lmPuZMnpCzR+zF90fUaVNHqwh5CK)
					ZZH6czYDb0.append(yDTPzhEBKVJl7CX81)
	for yDTPzhEBKVJl7CX81,title in zip(ZZH6czYDb0,joaMtxEpGfDXFPRHQgLKizyOT2b93):
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('\\/','/')
		m0t48jnKhrQFJViguoMl9NBPp = G9GCDqXJFAc(url,'url')
		qoCMENGx4WgKp = lAfzvsbYy7oQ3r28EMe()
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = m0t48jnKhrQFJViguoMl9NBPp+yDTPzhEBKVJl7CX81
		if '.m3u8' in yDTPzhEBKVJl7CX81:
			headers = {'User-Agent':qoCMENGx4WgKp,'Referer':m0t48jnKhrQFJViguoMl9NBPp}
			ipStRL9IF7O31elgsNdhKxu,il7RMnzUYqN3XPw = zKaqs0n5ZdrvWSTJYhy7(yDTPzhEBKVJl7CX81,headers)
			ffCVRQTFby24aYhA3szw8W += il7RMnzUYqN3XPw
			R6R2SncUg57LCAFd0 += ipStRL9IF7O31elgsNdhKxu
		else:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81+'|User-Agent='+qoCMENGx4WgKp+'&Referer='+m0t48jnKhrQFJViguoMl9NBPp
			ffCVRQTFby24aYhA3szw8W.append(yDTPzhEBKVJl7CX81)
			R6R2SncUg57LCAFd0.append(title)
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	if ffCVRQTFby24aYhA3szw8W: VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0 = Zg9FeADE84jSRIvPCrzYulw3sL,R6R2SncUg57LCAFd0,ffCVRQTFby24aYhA3szw8W
	else:
		if '<' not in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG and len(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)<100 and yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
		else:
			msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<div style=".*?">(File.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not msg: msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<div class="vp_video_stub_txt">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not msg: msg = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h2>(Sorry.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if msg: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = msg[UwCT5Oz6Wo0BP]
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,joaMtxEpGfDXFPRHQgLKizyOT2b93,ZZH6czYDb0
def vv9RFhuai06TJOHnoYBd7wVI1(OYJSXhfiyznTILqxurj2cwZU,url):
	global xxvdQOw03tRrG6
	url = url.strip('/')
	LE9gRTxzt856dh3K1F,EEFf6enQDxk = Zg9FeADE84jSRIvPCrzYulw3sL,{}
	headers = {'User-Agent':lAfzvsbYy7oQ3r28EMe()}
	headers['Referer'] = G9GCDqXJFAc(url,'url')
	headers['Accept-Language'] = 'en-US,en;q=0.9'
	headers['Sec-Fetch-Dest'] = 'iframe'
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,'RESOLVERS-XSHARING-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	OxJ3WCimXvjuMZ6Fk = Pa6Q2LRkbtY0Id7nUNsZ.code
	if not isinstance(yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,str): yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.decode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc,'ignore')
	if 'function(p,a,c,k,e,' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			try: LE9gRTxzt856dh3K1F = Uu6MqoJxLtkimFsdYhc2Nvef(nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP])
			except: LE9gRTxzt856dh3K1F = Zg9FeADE84jSRIvPCrzYulw3sL
	if 'function(h,u,n,t,e,r)' in yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG:
		nmytzfOdMhHY6Ao1KSx5NL = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(eval\(function\(h,u,n,t,e,r.*?)</script>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if nmytzfOdMhHY6Ao1KSx5NL:
			try: LE9gRTxzt856dh3K1F = YE6NfDK7nZtwTs(nmytzfOdMhHY6Ao1KSx5NL[UwCT5Oz6Wo0BP])
			except: LE9gRTxzt856dh3K1F = Zg9FeADE84jSRIvPCrzYulw3sL
	CNhQcnS0dI6UFjbvLoyx = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG+LE9gRTxzt856dh3K1F
	if '"id2"' in CNhQcnS0dI6UFjbvLoyx or '"id"' in CNhQcnS0dI6UFjbvLoyx:
		wjEFWihDBaM = url.split('/')[O4dklMvZ8ULcS].replace('embed-',Zg9FeADE84jSRIvPCrzYulw3sL).replace('.html',Zg9FeADE84jSRIvPCrzYulw3sL)
		if '"id2"' in CNhQcnS0dI6UFjbvLoyx: EEFf6enQDxk = {'id2':wjEFWihDBaM,'op':'download2'}
		elif '"id"' in CNhQcnS0dI6UFjbvLoyx: EEFf6enQDxk = {'id':wjEFWihDBaM,'op':'download2'}
		Y3OmVPp2ARgBCjn = headers.copy()
		Y3OmVPp2ARgBCjn['Content-Type'] = 'application/x-www-form-urlencoded'
		zCDbxZtwOE6 = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST',url,EEFf6enQDxk,Y3OmVPp2ARgBCjn,Zg9FeADE84jSRIvPCrzYulw3sL,vvglE69OFKBm817Nkc,'RESOLVERS-XSHARING-2nd')
		CNhQcnS0dI6UFjbvLoyx = zCDbxZtwOE6.content
	CUcuT2nrbsJwY9GQdI37K,nnhRcEpIPOr7k4L1UHldzuBfg8KMj,l8ochfSOAkKMRPCUaW7 = ymNcGjZfWdUuv2sSpelH(url,CNhQcnS0dI6UFjbvLoyx)
	xxvdQOw03tRrG6[OYJSXhfiyznTILqxurj2cwZU] = CUcuT2nrbsJwY9GQdI37K,nnhRcEpIPOr7k4L1UHldzuBfg8KMj,l8ochfSOAkKMRPCUaW7,OxJ3WCimXvjuMZ6Fk
	return
xxvdQOw03tRrG6,VzeEkWnN6Rl = {},UwCT5Oz6Wo0BP
def T5T0LfYeA6(url):
	global xxvdQOw03tRrG6,VzeEkWnN6Rl
	CPv45ibdnBc,threads = [],[]
	VzeEkWnN6Rl += 100
	bbEU3QqZpXGfs = VzeEkWnN6Rl
	CPv45ibdnBc.append([Mn5NGAdz6xc42s0,url])
	xxvdQOw03tRrG6[bbEU3QqZpXGfs+Mn5NGAdz6xc42s0] = [None,None,None,None]
	bB5kF8zAXr6nUmL = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=vv9RFhuai06TJOHnoYBd7wVI1,args=(bbEU3QqZpXGfs+Mn5NGAdz6xc42s0,url))
	bB5kF8zAXr6nUmL.start()
	bB5kF8zAXr6nUmL.join(10)
	if not xxvdQOw03tRrG6[bbEU3QqZpXGfs+1][DpahB8cwl4ZeKVsg71RuibSAfx0Ejr]:
		hc5ePKxl4LJvEjDgTm = url.replace('/embed-','/')
		Gi82lgtIxVsjSyqZU5EmBLkKw = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('^(.*?://.*?)/(.*?)/(.*?)$',hc5ePKxl4LJvEjDgTm+'/',aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		start,FE6Ugdau8WbYP,end = Gi82lgtIxVsjSyqZU5EmBLkKw[UwCT5Oz6Wo0BP]
		end = end.strip('/')
		YafkZxvGitNEVuKBlWwohIp = len(FE6Ugdau8WbYP)<NEc173Pr0jAwLF5OS or FE6Ugdau8WbYP in ['file','video','videoembed','ajax','iframe','mirror']
		if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([DpahB8cwl4ZeKVsg71RuibSAfx0Ejr,start+'/embed-'+FE6Ugdau8WbYP+'/'+end])
		if end: CPv45ibdnBc.append([O4dklMvZ8ULcS,start+'/'+FE6Ugdau8WbYP+'/embed-'+end])
		if '.html' in FE6Ugdau8WbYP:
			wYkMpSyTjdorCxvWXJZqentfsLU0 = FE6Ugdau8WbYP.replace('.html',Zg9FeADE84jSRIvPCrzYulw3sL)
			CPv45ibdnBc.append([NEc173Pr0jAwLF5OS,start+'/'+wYkMpSyTjdorCxvWXJZqentfsLU0+'/'+end])
			CPv45ibdnBc.append([5,start+'/embed-'+wYkMpSyTjdorCxvWXJZqentfsLU0+'/'+end])
			if end: CPv45ibdnBc.append([6,start+'/'+wYkMpSyTjdorCxvWXJZqentfsLU0+'/embed-'+end])
		elif '.html' in end:
			EyfIJ2FB4orR1iXV8h0 = end.replace('.html',Zg9FeADE84jSRIvPCrzYulw3sL)
			CPv45ibdnBc.append([7,start+'/'+FE6Ugdau8WbYP+'/'+EyfIJ2FB4orR1iXV8h0])
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([8,start+'/embed-'+FE6Ugdau8WbYP+'/'+EyfIJ2FB4orR1iXV8h0])
			CPv45ibdnBc.append([9,start+'/'+FE6Ugdau8WbYP+'/embed-'+EyfIJ2FB4orR1iXV8h0])
		else:
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([10,start+'/'+FE6Ugdau8WbYP+'.html'])
			if not YafkZxvGitNEVuKBlWwohIp: CPv45ibdnBc.append([11,start+'/embed-'+FE6Ugdau8WbYP+'.html'])
			if end: CPv45ibdnBc.append([12,start+'/'+FE6Ugdau8WbYP+'/'+end+'.html'])
			if end: CPv45ibdnBc.append([13,start+'/'+FE6Ugdau8WbYP+'/embed-'+end+'.html'])
		if YafkZxvGitNEVuKBlWwohIp and end:
			end = end.replace('/embed-','/')
			CPv45ibdnBc.append([14,start+'/'+end])
			CPv45ibdnBc.append([15,start+'/embed-'+end])
			if '.html' in end:
				EyfIJ2FB4orR1iXV8h0 = end.replace('.html',Zg9FeADE84jSRIvPCrzYulw3sL)
				CPv45ibdnBc.append([16,start+'/'+EyfIJ2FB4orR1iXV8h0])
				CPv45ibdnBc.append([17,start+'/embed-'+EyfIJ2FB4orR1iXV8h0])
			else:
				CPv45ibdnBc.append([18,start+'/'+end+'.html'])
				CPv45ibdnBc.append([19,start+'/embed-'+end+'.html'])
		f9ZLzC56UOFywvm2Q70gDRK3uoIYN = []
		for qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81 in CPv45ibdnBc[Mn5NGAdz6xc42s0:]:
			xxvdQOw03tRrG6[bbEU3QqZpXGfs+qS1RW5ZtAkYb] = [None,None,None,None]
			IXU6zAnudWi7FDYweOtvqysaCcE9 = I9IjKTbgiCVvuWJLAB2wP3rXOQ.Thread(target=vv9RFhuai06TJOHnoYBd7wVI1,args=(bbEU3QqZpXGfs+qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81))
			IXU6zAnudWi7FDYweOtvqysaCcE9.start()
			f9ZLzC56UOFywvm2Q70gDRK3uoIYN.append(IXU6zAnudWi7FDYweOtvqysaCcE9)
			LNma2eq3vEguwVtHjn.sleep(0.75)
		for IXU6zAnudWi7FDYweOtvqysaCcE9 in f9ZLzC56UOFywvm2Q70gDRK3uoIYN: IXU6zAnudWi7FDYweOtvqysaCcE9.join(10)
	VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = Zg9FeADE84jSRIvPCrzYulw3sL,[],[]
	EEPAJVu7U2vBMlDS4 = []
	for qS1RW5ZtAkYb,yDTPzhEBKVJl7CX81 in CPv45ibdnBc:
		xxgAEcKoNC5T0kwuV,SPBdzpmsOvKf,EJik7MPjH5apctxF94bVgLqf,nnAkHiSJN7CxWD4QuZL8fYUpgr = xxvdQOw03tRrG6[bbEU3QqZpXGfs+qS1RW5ZtAkYb]
		if not fo6s53yEnbklLpaJOzgR4Q01wxB and EJik7MPjH5apctxF94bVgLqf: nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB = SPBdzpmsOvKf,EJik7MPjH5apctxF94bVgLqf
		if not VLa3Uijkb0vXeJSWcrPf8KOlz4uA and xxgAEcKoNC5T0kwuV: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = xxgAEcKoNC5T0kwuV
		if nnAkHiSJN7CxWD4QuZL8fYUpgr: EEPAJVu7U2vBMlDS4.append(nnAkHiSJN7CxWD4QuZL8fYUpgr)
	EEPAJVu7U2vBMlDS4 = list(set(EEPAJVu7U2vBMlDS4))
	if not VLa3Uijkb0vXeJSWcrPf8KOlz4uA and len(EEPAJVu7U2vBMlDS4)==1:
		OxJ3WCimXvjuMZ6Fk = EEPAJVu7U2vBMlDS4[UwCT5Oz6Wo0BP]
		if OxJ3WCimXvjuMZ6Fk!=200:
			if OxJ3WCimXvjuMZ6Fk<UwCT5Oz6Wo0BP: VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'Video page/server is not accessible'
			else:
				VLa3Uijkb0vXeJSWcrPf8KOlz4uA = 'HTTP Error: '+str(OxJ3WCimXvjuMZ6Fk)
				if GGfPQnrJKEqMv2ZVxdD: import http.client as ss0f1CFxiL
				else: import httplib as ss0f1CFxiL
				try: VLa3Uijkb0vXeJSWcrPf8KOlz4uA += ' ( '+ss0f1CFxiL.responses[OxJ3WCimXvjuMZ6Fk]+' )'
				except: pass
	LNma2eq3vEguwVtHjn.sleep(Mn5NGAdz6xc42s0)
	return VLa3Uijkb0vXeJSWcrPf8KOlz4uA,nnhWEIa6Tm,fo6s53yEnbklLpaJOzgR4Q01wxB
class sz7cmkAhjaL8NlMg6EWKdV(HqjWaYEzp0D8eyQRud.WindowDialog):
	def __init__(rX4tN2IJPD0yYa1jw8WlSmCL, *args, **gyrQSCWPzi5D6dTIOZEv9AF8t):
		H4hmknQqlf39Z = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, 'resources', 'recaptcha2', 'dialogbg.png')
		KKc5By6rYFDdhMWziPj20eHA1O = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, 'resources', 'recaptcha2', 'selected.png')
		HFuAgNr6dJ = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, 'resources', 'recaptcha2', 'buttonfo.png')
		cX96nDARZfCuN2bsWrvqME8 = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, 'resources', 'recaptcha2', 'buttonnf.png')
		pqQUDotCaY76eObznwWj4XFS = brAUlZfdFmt3TRJW2xX4.path.join(SSWrcswxYdB9p, 'resources', 'recaptcha2', 'buttonbg.png')
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = vvglE69OFKBm817Nkc
		rX4tN2IJPD0yYa1jw8WlSmCL.chk = [UwCT5Oz6Wo0BP] * 9
		rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton = [UwCT5Oz6Wo0BP] * 9
		rX4tN2IJPD0yYa1jw8WlSmCL.chkstate = [vvglE69OFKBm817Nkc] * 9
		C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf = 250, UwCT5Oz6Wo0BP, 700, 760
		jtOrUwX4csM7vKyk0CpqN2ITlbD = C8LKAyqbQB9DMWvrxS16VXJktzo+Gd6hSozXglT0Z//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel = 355, 120, 500, 500
		UdoKWkiCRy5F0TaXDqpGfVurSZOE2 = DxdsFza9bqrlZLIOpNgCS3oy+HGkU4hJrTpf8ND7Z2Ycsvy//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		ImHC54ei6l3bsSxTVor, Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK, Js829nHb6FWucwOP0m, UPwfKWh54kZNvoB = 100, 655, 150, 50
		WLr0TljBFDvXyIaVcR = jtOrUwX4csM7vKyk0CpqN2ITlbD-Js829nHb6FWucwOP0m-ImHC54ei6l3bsSxTVor//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		yYv4JScLOkw3Xah876nlRobHpjQ = jtOrUwX4csM7vKyk0CpqN2ITlbD+ImHC54ei6l3bsSxTVor//DpahB8cwl4ZeKVsg71RuibSAfx0Ejr
		TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv = 355, 30, 500, 50
		pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby = 355, 70, 500, 50
		EEe7lM4CPfypz9G1JHXRgaY = 0.9
		C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf = int(C8LKAyqbQB9DMWvrxS16VXJktzo*EEe7lM4CPfypz9G1JHXRgaY), int(QBhnMgDdPiFacI3p*EEe7lM4CPfypz9G1JHXRgaY), int(Gd6hSozXglT0Z*EEe7lM4CPfypz9G1JHXRgaY), int(NawPUTA7lQYLx3FWunf*EEe7lM4CPfypz9G1JHXRgaY)
		DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel = int(DxdsFza9bqrlZLIOpNgCS3oy*EEe7lM4CPfypz9G1JHXRgaY), int(NVsFQHu4bEhy7xjYUvZeG39Rrp0J*EEe7lM4CPfypz9G1JHXRgaY), int(HGkU4hJrTpf8ND7Z2Ycsvy*EEe7lM4CPfypz9G1JHXRgaY), int(OOzuYXkwIMN5Lo2fKh4dZSianbel*EEe7lM4CPfypz9G1JHXRgaY)
		WLr0TljBFDvXyIaVcR, EEVFjaqIOGygobDXZ, lB1q2At0zbVdX8GcQPOse, V6ZYaEHwkT8hWjev = int(WLr0TljBFDvXyIaVcR*EEe7lM4CPfypz9G1JHXRgaY), int(Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK*EEe7lM4CPfypz9G1JHXRgaY), int(Js829nHb6FWucwOP0m*EEe7lM4CPfypz9G1JHXRgaY), int(UPwfKWh54kZNvoB*EEe7lM4CPfypz9G1JHXRgaY)
		yYv4JScLOkw3Xah876nlRobHpjQ, GUWC1Opf9sq3Mv0e8nugALxXb, PP37ZuzYgkwUrnbTMx5, ssX9lvENKiSm7QRodPUM = int(yYv4JScLOkw3Xah876nlRobHpjQ*EEe7lM4CPfypz9G1JHXRgaY), int(Ngu0oAp1Rj3ceD7dTmbqzWwZQhXVYK*EEe7lM4CPfypz9G1JHXRgaY), int(Js829nHb6FWucwOP0m*EEe7lM4CPfypz9G1JHXRgaY), int(UPwfKWh54kZNvoB*EEe7lM4CPfypz9G1JHXRgaY)
		TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv = int(TumopOkWSlB3tIvZnVXMsdK*EEe7lM4CPfypz9G1JHXRgaY), int(xAzbmYgDyvjpW*EEe7lM4CPfypz9G1JHXRgaY), int(KCta3OfYpS1F*EEe7lM4CPfypz9G1JHXRgaY), int(H4WmA0OMqCQyijuxv*EEe7lM4CPfypz9G1JHXRgaY)
		pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby = int(pgcW1Y0udyzTDSC*EEe7lM4CPfypz9G1JHXRgaY), int(BAi2OW7pchDx1t*EEe7lM4CPfypz9G1JHXRgaY), int(bjc08326tGUSiA4RXC*EEe7lM4CPfypz9G1JHXRgaY), int(Sau0gLfeWxqp9cCAmby*EEe7lM4CPfypz9G1JHXRgaY)
		xxB32TXgSfC7y = HqjWaYEzp0D8eyQRud.ControlImage(C8LKAyqbQB9DMWvrxS16VXJktzo, QBhnMgDdPiFacI3p, Gd6hSozXglT0Z, NawPUTA7lQYLx3FWunf, H4hmknQqlf39Z)
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(xxB32TXgSfC7y)
		rX4tN2IJPD0yYa1jw8WlSmCL.iteration = gyrQSCWPzi5D6dTIOZEv9AF8t.get('iteration')
		VVHQWDNc9BUpOT38o2i0x = U2bWzwG8VdJsBqtR74ErDi3cg1v+'فحص أنا إنسان ولست روبوت         '+'المحاولة رقم  '+str(rX4tN2IJPD0yYa1jw8WlSmCL.iteration)+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo = HqjWaYEzp0D8eyQRud.ControlLabel(TumopOkWSlB3tIvZnVXMsdK, xAzbmYgDyvjpW, KCta3OfYpS1F, H4WmA0OMqCQyijuxv, VVHQWDNc9BUpOT38o2i0x, 'font13')
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo)
		W8KBRzkdhlCxvF5sY2T = HqjWaYEzp0D8eyQRud.ControlImage(DxdsFza9bqrlZLIOpNgCS3oy, NVsFQHu4bEhy7xjYUvZeG39Rrp0J, HGkU4hJrTpf8ND7Z2Ycsvy, OOzuYXkwIMN5Lo2fKh4dZSianbel, gyrQSCWPzi5D6dTIOZEv9AF8t.get('captcha'))
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(W8KBRzkdhlCxvF5sY2T)
		JK5lBaj9fR1ztCnoIUXG8xQ2Ow = U2bWzwG8VdJsBqtR74ErDi3cg1v+gyrQSCWPzi5D6dTIOZEv9AF8t.get('msg')+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo = HqjWaYEzp0D8eyQRud.ControlLabel(pgcW1Y0udyzTDSC, BAi2OW7pchDx1t, bjc08326tGUSiA4RXC, Sau0gLfeWxqp9cCAmby, JK5lBaj9fR1ztCnoIUXG8xQ2Ow, 'font13')
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.strActionInfo)
		text = U2bWzwG8VdJsBqtR74ErDi3cg1v+'خروج'+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton = HqjWaYEzp0D8eyQRud.ControlButton(WLr0TljBFDvXyIaVcR, EEVFjaqIOGygobDXZ, lB1q2At0zbVdX8GcQPOse, V6ZYaEHwkT8hWjev, text, focusTexture=pqQUDotCaY76eObznwWj4XFS, noFocusTexture=HFuAgNr6dJ, alignment=2)
		text = U2bWzwG8VdJsBqtR74ErDi3cg1v+'استمرار'+u4IRSmrYMKkaHUBnDiLWh
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton = HqjWaYEzp0D8eyQRud.ControlButton(yYv4JScLOkw3Xah876nlRobHpjQ, GUWC1Opf9sq3Mv0e8nugALxXb, PP37ZuzYgkwUrnbTMx5, ssX9lvENKiSm7QRodPUM, text, focusTexture=pqQUDotCaY76eObznwWj4XFS, noFocusTexture=HFuAgNr6dJ, alignment=2)
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		m0ENcaf43WGqz6P, ZZp9X1nkucf5ljChPxsIb = OOzuYXkwIMN5Lo2fKh4dZSianbel//O4dklMvZ8ULcS, HGkU4hJrTpf8ND7Z2Ycsvy//O4dklMvZ8ULcS
		for YjZN3ADmertFahUQIECW in range(9):
			sunLqYwZXvKVbh5ANzCo = YjZN3ADmertFahUQIECW // O4dklMvZ8ULcS
			P08KTbhMB9qmwoND3IzFfUxX = YjZN3ADmertFahUQIECW % O4dklMvZ8ULcS
			zcpgViqlHuQkPSsWGY74xdjOAf3BF = DxdsFza9bqrlZLIOpNgCS3oy + (ZZp9X1nkucf5ljChPxsIb * P08KTbhMB9qmwoND3IzFfUxX)
			bK2FwMazi8kpgn3rls79mSoJQVeR = NVsFQHu4bEhy7xjYUvZeG39Rrp0J + (m0ENcaf43WGqz6P * sunLqYwZXvKVbh5ANzCo)
			rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW] = HqjWaYEzp0D8eyQRud.ControlImage(zcpgViqlHuQkPSsWGY74xdjOAf3BF, bK2FwMazi8kpgn3rls79mSoJQVeR, ZZp9X1nkucf5ljChPxsIb, m0ENcaf43WGqz6P, KKc5By6rYFDdhMWziPj20eHA1O)
			rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW])
			rX4tN2IJPD0yYa1jw8WlSmCL.chk[YjZN3ADmertFahUQIECW].setVisible(vvglE69OFKBm817Nkc)
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW] = HqjWaYEzp0D8eyQRud.ControlButton(zcpgViqlHuQkPSsWGY74xdjOAf3BF, bK2FwMazi8kpgn3rls79mSoJQVeR, ZZp9X1nkucf5ljChPxsIb, m0ENcaf43WGqz6P, str(YjZN3ADmertFahUQIECW + Mn5NGAdz6xc42s0), font='font13', focusTexture=HFuAgNr6dJ, noFocusTexture=cX96nDARZfCuN2bsWrvqME8)
			rX4tN2IJPD0yYa1jw8WlSmCL.addControl(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW])
		for YjZN3ADmertFahUQIECW in range(9):
			MLVJYNgw6Bs = (YjZN3ADmertFahUQIECW // O4dklMvZ8ULcS) * O4dklMvZ8ULcS
			NlEwy1coZ8iPAVMze745rmSGnF = MLVJYNgw6Bs + (YjZN3ADmertFahUQIECW + Mn5NGAdz6xc42s0) % O4dklMvZ8ULcS
			Q3MHvd4hr7 = MLVJYNgw6Bs + (YjZN3ADmertFahUQIECW - Mn5NGAdz6xc42s0) % O4dklMvZ8ULcS
			BCM7bhIvsfTJ3anQXFYge5zOt6wl = (YjZN3ADmertFahUQIECW - O4dklMvZ8ULcS) % 9
			LflpkH4xgSZToKcuzIyMJ69Y1DhB = (YjZN3ADmertFahUQIECW + O4dklMvZ8ULcS) % 9
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[NlEwy1coZ8iPAVMze745rmSGnF])
			rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[Q3MHvd4hr7])
			if YjZN3ADmertFahUQIECW <= DpahB8cwl4ZeKVsg71RuibSAfx0Ejr:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
			else:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[BCM7bhIvsfTJ3anQXFYge5zOt6wl])
			if YjZN3ADmertFahUQIECW >= 6:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
			else:
				rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[YjZN3ADmertFahUQIECW].controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[LflpkH4xgSZToKcuzIyMJ69Y1DhB])
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlLeft(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlRight(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[DpahB8cwl4ZeKVsg71RuibSAfx0Ejr])
		rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[8])
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlDown(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[UwCT5Oz6Wo0BP])
		rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.controlUp(rX4tN2IJPD0yYa1jw8WlSmCL.chkbutton[6])
		rX4tN2IJPD0yYa1jw8WlSmCL.setFocus(rX4tN2IJPD0yYa1jw8WlSmCL.okbutton)
	def get(rX4tN2IJPD0yYa1jw8WlSmCL):
		rX4tN2IJPD0yYa1jw8WlSmCL.doModal()
		rX4tN2IJPD0yYa1jw8WlSmCL.close()
		if not rX4tN2IJPD0yYa1jw8WlSmCL.cancelled:
			return [YjZN3ADmertFahUQIECW for YjZN3ADmertFahUQIECW in range(9) if rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[YjZN3ADmertFahUQIECW]]
	def onControl(rX4tN2IJPD0yYa1jw8WlSmCL, M6BhQE5fSnOUZk7NPA2Dm83cuWL1):
		if M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getId() == rX4tN2IJPD0yYa1jw8WlSmCL.okbutton.getId() and any(rX4tN2IJPD0yYa1jw8WlSmCL.chkstate):
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
		elif M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getId() == rX4tN2IJPD0yYa1jw8WlSmCL.cancelbutton.getId():
			rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
		else:
			cwMyvBgJuRXLWH48kpndbG7q2a = M6BhQE5fSnOUZk7NPA2Dm83cuWL1.getLabel()
			if cwMyvBgJuRXLWH48kpndbG7q2a.isnumeric():
				index = int(cwMyvBgJuRXLWH48kpndbG7q2a) - Mn5NGAdz6xc42s0
				rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index] = not rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index]
				rX4tN2IJPD0yYa1jw8WlSmCL.chk[index].setVisible(rX4tN2IJPD0yYa1jw8WlSmCL.chkstate[index])
	def onAction(rX4tN2IJPD0yYa1jw8WlSmCL, zMsqA2SVtdHLJDx8gpFGw):
		if zMsqA2SVtdHLJDx8gpFGw == 10:
			rX4tN2IJPD0yYa1jw8WlSmCL.cancelled = CR6in9cZKo2SqGFmrHOLdhYEVTjsBy
			rX4tN2IJPD0yYa1jw8WlSmCL.close()
def e4XT9Vp5sNIP8M0lyFd7orGUhJ2Ou(key,Zxh5l1rNem,url):
	headers = {'Referer':url,'Accept-Language':Zxh5l1rNem}
	J2zpHd3wU9s = 'http://www.google.com/recaptcha/api/fallback?k='+key
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',J2zpHd3wU9s,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	dkKX8zLCs6yqBlD7Y5geZEpAicua20,iteration = Zg9FeADE84jSRIvPCrzYulw3sL,UwCT5Oz6Wo0BP
	while CR6in9cZKo2SqGFmrHOLdhYEVTjsBy:
		yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
		EEFf6enQDxk = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"(/recaptcha/api2/payload[^"]+)', yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		iteration += Mn5NGAdz6xc42s0
		message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		if not message: message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)
		if not message:
			dkKX8zLCs6yqBlD7Y5geZEpAicua20 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('readonly>(.*?)<', yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)[UwCT5Oz6Wo0BP]
			break
		else:
			message = message[UwCT5Oz6Wo0BP]
			EEFf6enQDxk = EEFf6enQDxk[UwCT5Oz6Wo0BP]
		iAUKN2hp8XojexOZVGu4fa0TLS = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(r'name="c"\s+value="([^"]+)', yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG)[UwCT5Oz6Wo0BP]
		ssmj6TJAIYlo8n = 'https://www.google.com%s' % (EEFf6enQDxk.replace('&amp;', '&'))
		message = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.sub('</?(div|strong)[^>]*>', Zg9FeADE84jSRIvPCrzYulw3sL, message)
		A1UqLd35XVtkHu7 = sz7cmkAhjaL8NlMg6EWKdV(captcha=ssmj6TJAIYlo8n, msg=message, iteration=iteration)
		EcOPrVSsGvT = A1UqLd35XVtkHu7.get()
		if not EcOPrVSsGvT: break
		data = {'c': iAUKN2hp8XojexOZVGu4fa0TLS, 'response': EcOPrVSsGvT}
		Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'POST',J2zpHd3wU9s,data,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return dkKX8zLCs6yqBlD7Y5geZEpAicua20
def ETZDzC3rpIfuhALVRkSUlxXW21QNoH(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARABLOADS-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('color="red">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def ptDGgdlni7a5fVoxEjKYON6XC(url):
	return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
def B17B4reZUshzTbcxEG8RCAop(url):
	m0t48jnKhrQFJViguoMl9NBPp = url.split('/')
	yy1Zn4ovHpRqmKzjIfa = '/'.join(m0t48jnKhrQFJViguoMl9NBPp[UwCT5Oz6Wo0BP:O4dklMvZ8ULcS])
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ZIPPYSHARE-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,Bmxi32K6Taz90GXCreMD48wb,EsVf1Kpd2UQojJ3nG8B5IAxL9vSq,hlbwqNiv4xUA2EWOHZ5ejY,E5OVouZa6tIKv4fSzWnY3bBQMj = items[UwCT5Oz6Wo0BP]
		MnwlGZ9Ef3S7kv5sxtzRiFaoCIb = int(YswlgoudyzkW8hARTP09tDG16a) % int(Bmxi32K6Taz90GXCreMD48wb) + int(EsVf1Kpd2UQojJ3nG8B5IAxL9vSq) % int(hlbwqNiv4xUA2EWOHZ5ejY)
		url = yy1Zn4ovHpRqmKzjIfa + uNy4ZJUMEiTj5aS0Rxf619YPzrk + str(MnwlGZ9Ef3S7kv5sxtzRiFaoCIb) + E5OVouZa6tIKv4fSzWnY3bBQMj
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def qL7uoRwbpI2QFjHP51S(url):
	id = url.split('/')[-Mn5NGAdz6xc42s0]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	EEFf6enQDxk = { "id":id , "op":"download2" }
	YYAz8aPFGR2n = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'POST', url, EEFf6enQDxk, headers, Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(YYAz8aPFGR2n.headers.keys()): yDTPzhEBKVJl7CX81 = YYAz8aPFGR2n.headers['Location']
	else: yDTPzhEBKVJl7CX81 = url
	if yDTPzhEBKVJl7CX81: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[yDTPzhEBKVJl7CX81]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def NF9nrM2hfP3WIw(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-WINTVLIVE-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('mp4: \[\'(.*?)\'',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def rxR7qJpG2lFV6i(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ARCHIVE-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('source src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[UwCT5Oz6Wo0BP]
		return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def ryWH7UVAMO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'RESOLVERS-ESTREAM-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('video preload.*?src=.*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items: return Zg9FeADE84jSRIvPCrzYulw3sL,[Zg9FeADE84jSRIvPCrzYulw3sL],[ items[UwCT5Oz6Wo0BP] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
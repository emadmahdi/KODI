# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'FASELHD1'
headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
j0jSEdTPJuG4XNvfpO = '_FH1_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
Uhe07PlWNakHDZc1t = ['جوائز الأوسكار','المراجعات','wwe']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==570: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==571: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==572: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==573: CsaNhTtGm8 = Te0y7HtBjMXxJc3uh(url,text)
	elif mode==576: CsaNhTtGm8 = q3y5axVoPJU1()
	elif mode==579: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('link',j0jSEdTPJuG4XNvfpO+'لماذا الموقع بطيء',Zg9FeADE84jSRIvPCrzYulw3sL,576)
	Wtu1ZQ5yrA2KVlPs76EgbRvz,url = qfzHe2Yr49,qfzHe2Yr49
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FASELHD1-MENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Wtu1ZQ5yrA2KVlPs76EgbRvz,579,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'المميزة',Wtu1ZQ5yrA2KVlPs76EgbRvz,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured1')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="h3">(.*?)<.*?href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for title,yDTPzhEBKVJl7CX81 in items:
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'details1')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"menu-primary"(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		ZZdnQYiLFU6RGsOPkaTVp = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<li (.*?)</li>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		TKAiXGUvHq7xrdf5MuOcI = [Zg9FeADE84jSRIvPCrzYulw3sL,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		OEJ3PT81KtbZ = 0
		for trgU5GIRQc in ZZdnQYiLFU6RGsOPkaTVp:
			if OEJ3PT81KtbZ>0: A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',trgU5GIRQc,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				if yDTPzhEBKVJl7CX81=='#': continue
				if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+yDTPzhEBKVJl7CX81
				if title==Zg9FeADE84jSRIvPCrzYulw3sL: continue
				if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title.lower() for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t): continue
				title = TKAiXGUvHq7xrdf5MuOcI[OEJ3PT81KtbZ]+title
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'details2')
			OEJ3PT81KtbZ += 1
	return
def q3y5axVoPJU1():
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FASELHD1-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	sQPyfIOFgKLTU4u23XB6dmS9 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="h4">(.*?)</div>(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if not sQPyfIOFgKLTU4u23XB6dmS9: return
	if type=='filters':
		HNRenB3EZX62qgSKMd4f = [yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"homeSlide"(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		ZUyhgmew6MfJLD3b,CPv45ibdnBc,WWuctLSlqizGgrK = zip(*items)
		items = zip(CPv45ibdnBc,ZUyhgmew6MfJLD3b,WWuctLSlqizGgrK)
	elif type=='featured2':
		title,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	elif type=='details2' and len(sQPyfIOFgKLTU4u23XB6dmS9)>1:
		title = sQPyfIOFgKLTU4u23XB6dmS9[0][0]
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'featured2')
		title = sQPyfIOFgKLTU4u23XB6dmS9[1][0]
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,url,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'details3')
		return
	else:
		title,nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = sQPyfIOFgKLTU4u23XB6dmS9[-1]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
		if any(B251BPiLbvG9UxszKtlI7YQHmoWw in title.lower() for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t): continue
		W8KBRzkdhlCxvF5sY2T = uumhMi6O4pk7Gjd5aTQqy2Z(W8KBRzkdhlCxvF5sY2T)
		W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.split('?resize=')[0]
		title = BtKvPnEQJx32Z(title)
		jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة).\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if '/collections/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,571,W8KBRzkdhlCxvF5sY2T)
		elif jjYXOr8QJsNUZv0PGL27ARSDceiq4 and type==Zg9FeADE84jSRIvPCrzYulw3sL:
			title = '_MOD_'+jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
			title = title.strip(' –')
			if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,573,W8KBRzkdhlCxvF5sY2T)
				cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif 'episodes/' in yDTPzhEBKVJl7CX81 or 'movies/' in yDTPzhEBKVJl7CX81 or 'hindi/' in yDTPzhEBKVJl7CX81:
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,572,W8KBRzkdhlCxvF5sY2T)
		else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,573,W8KBRzkdhlCxvF5sY2T)
	if type=='filters':
		aGhnZkfYXLqx2i5FJrBbDU = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"more_button_page":(.*?),',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if aGhnZkfYXLqx2i5FJrBbDU:
			count = aGhnZkfYXLqx2i5FJrBbDU[0]
			yDTPzhEBKVJl7CX81 = url+'/offset/'+count
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة أخرى',yDTPzhEBKVJl7CX81,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'filters')
	elif 'details' in type:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("class='pagination(.*?)</div>",yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href='(.*?)'.*?>(.*?)<",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				title = 'صفحة '+BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,571,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'details4')
	return
def Te0y7HtBjMXxJc3uh(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FASELHD1-SEASONS_EPISODES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	TdawvCqlKOoMIJygBtsQWGSbz = False
	if not type:
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"seasonList"(.*?)"container"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if len(items)>1:
				Wtu1ZQ5yrA2KVlPs76EgbRvz = G9GCDqXJFAc(url,'url')
				TdawvCqlKOoMIJygBtsQWGSbz = True
				for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,name,title in items:
					name = BtKvPnEQJx32Z(name)
					if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = Wtu1ZQ5yrA2KVlPs76EgbRvz+yDTPzhEBKVJl7CX81
					title = name+' - '+title
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,573,W8KBRzkdhlCxvF5sY2T,Zg9FeADE84jSRIvPCrzYulw3sL,'episodes')
	if type=='episodes' or not TdawvCqlKOoMIJygBtsQWGSbz:
		EELGungxe6wKPar9hyRv5FUMpIB = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"posterImg".*?src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if EELGungxe6wKPar9hyRv5FUMpIB: W8KBRzkdhlCxvF5sY2T = EELGungxe6wKPar9hyRv5FUMpIB[0]
		else: W8KBRzkdhlCxvF5sY2T = Zg9FeADE84jSRIvPCrzYulw3sL
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"epAll"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				title = title.strip(wjs26GpVfNiCUERHJ)
				title = BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,572,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	ZZH6czYDb0,i2Dfb69VzR5O73QBoScX8GAkl,ffCVRQTFby24aYhA3szw8W = [],[],[]
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'FASELHD1-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	ZZofL4OdMp0 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('مستوى المشاهدة.*?">(.*?)</span>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if ZZofL4OdMp0:
		XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"tag">(.*?)</a>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"videoRow"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&img=')[0]
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named=__embed')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="streamHeader(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall("href = '(.*?)'.*?</i>(.*?)</a>",nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,name in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&img=')[0]
			name = name.strip(wjs26GpVfNiCUERHJ)
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+name+'__watch')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="downloadLinks(.*?)blackwindow',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?</span>(.*?)</a>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,name in items:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.split('&img=')[0]
			ZZH6czYDb0.append(yDTPzhEBKVJl7CX81+'?named='+name+'__download')
	for Lvxt1QeJ8OGm4njZolAyw7DYN in ZZH6czYDb0:
		yDTPzhEBKVJl7CX81,name = Lvxt1QeJ8OGm4njZolAyw7DYN.split('?named')
		if yDTPzhEBKVJl7CX81 not in i2Dfb69VzR5O73QBoScX8GAkl:
			i2Dfb69VzR5O73QBoScX8GAkl.append(yDTPzhEBKVJl7CX81)
			ffCVRQTFby24aYhA3szw8W.append(Lvxt1QeJ8OGm4njZolAyw7DYN)
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(ffCVRQTFby24aYhA3szw8W,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/?s='+search
	mbzIyKNqMVt0FQeOsPWc(hc5ePKxl4LJvEjDgTm,'details5')
	return
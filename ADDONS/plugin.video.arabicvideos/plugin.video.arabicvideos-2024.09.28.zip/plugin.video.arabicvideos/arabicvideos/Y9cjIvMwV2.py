# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'BOKRA'
j0jSEdTPJuG4XNvfpO = '_BKR_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
headers = {'User-Agent':Zg9FeADE84jSRIvPCrzYulw3sL}
Uhe07PlWNakHDZc1t = ['افلام للكبار','بكرا TV']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==370: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==371: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==372: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==374: CsaNhTtGm8 = ooYNk1L8IzEiA2Khm7Pyd(url)
	elif mode==375: CsaNhTtGm8 = k4ux8SUIXlwpAHznoWPf3JFLOGmd2(url)
	elif mode==376: CsaNhTtGm8 = kGwYCRnXm3t2ZEOyDiz(0,url)
	elif mode==377: CsaNhTtGm8 = kGwYCRnXm3t2ZEOyDiz(1,url)
	elif mode==379: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-MENU-1st')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,379,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'قنوات تلفزيونية',qfzHe2Yr49+'/al_1103560_1',371)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('right-side(.*?)</ul>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'المميزة',qfzHe2Yr49,375)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الأحدث',qfzHe2Yr49,376)
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'قائمة الممثلين',qfzHe2Yr49,374)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+' ===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="container"(.*?)top-menu',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items[7:]:
			title = title.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371)
		for yDTPzhEBKVJl7CX81,title in items[0:7]:
			title = title.strip(wjs26GpVfNiCUERHJ)
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371)
	return
def ooYNk1L8IzEiA2Khm7Pyd(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(ggWsYrlq8fy2v,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-ACTORSMENU-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="row cat Tags"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			if 'http' in yDTPzhEBKVJl7CX81: continue
			else: yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371)
	return
def k4ux8SUIXlwpAHznoWPf3JFLOGmd2(website=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-FEATURED-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('"MainContent"(.*?)main-title2',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('://',':///').replace('//','/').replace(wjs26GpVfNiCUERHJ,'%20')
				A9Z3Ci2PQhFUwBXvI('video',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,372,W8KBRzkdhlCxvF5sY2T)
	return
def kGwYCRnXm3t2ZEOyDiz(id,website=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-WATCHINGNOW-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('main-title2(.*?)class="row',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[id]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
			if not any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in Uhe07PlWNakHDZc1t):
				W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('://',':///').replace('//','/').replace(wjs26GpVfNiCUERHJ,'%20')
				A9Z3Ci2PQhFUwBXvI('video',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,372,W8KBRzkdhlCxvF5sY2T)
	return
def mbzIyKNqMVt0FQeOsPWc(url,wAmCd4R5vU=Zg9FeADE84jSRIvPCrzYulw3sL):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(E8RabFm1Kp5O0s,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-TITLES-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	if 'vidpage_' in url:
		yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(/Album-.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if yDTPzhEBKVJl7CX81:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81[0]
			mbzIyKNqMVt0FQeOsPWc(yDTPzhEBKVJl7CX81)
			return
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class=" subcats"(.*?)class="col-md-3',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if wAmCd4R5vU==Zg9FeADE84jSRIvPCrzYulw3sL and HNRenB3EZX62qgSKMd4f and HNRenB3EZX62qgSKMd4f[0].count('href')>1:
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'الجميع',url,371,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'titles')
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)" title="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			yDTPzhEBKVJl7CX81 = qfzHe2Yr49+'/'+yDTPzhEBKVJl7CX81
			title = title.strip(wjs26GpVfNiCUERHJ)
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371)
	else:
		cfUCuhJwZijTLxQX3gHayn89RqGrP = []
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="col-md-3(.*?)col-xs-12',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if not HNRenB3EZX62qgSKMd4f: HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="col-sm-8"(.*?)col-xs-12',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,W8KBRzkdhlCxvF5sY2T,title in items:
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
				title = title.strip(wjs26GpVfNiCUERHJ)
				W8KBRzkdhlCxvF5sY2T = W8KBRzkdhlCxvF5sY2T.replace('://',':///').replace('//','/').replace(wjs26GpVfNiCUERHJ,'%20')
				if '/al_' in yDTPzhEBKVJl7CX81:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371,W8KBRzkdhlCxvF5sY2T)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) - +الحلقة +\d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					if jjYXOr8QJsNUZv0PGL27ARSDceiq4: title = '_MOD_مسلسل '+jjYXOr8QJsNUZv0PGL27ARSDceiq4[0]
					if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
						cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
						A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371,W8KBRzkdhlCxvF5sY2T)
				else: A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,372,W8KBRzkdhlCxvF5sY2T)
		HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		if HNRenB3EZX62qgSKMd4f:
			nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
			items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="".*?href="(.*?)">(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			for yDTPzhEBKVJl7CX81,title in items:
				yDTPzhEBKVJl7CX81 = qfzHe2Yr49+yDTPzhEBKVJl7CX81
				title = 'صفحة '+BtKvPnEQJx32Z(title)
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,371,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'titles')
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(fA1u9wd7EkGBObjDhvWa,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-PLAY-1st')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	XgmQ1lh8HcUNPEiajL50 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('label-success mrg-btm-5 ">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if XgmQ1lh8HcUNPEiajL50 and aHztrdbWNx7yo8RZEmAOgTl5BX3Cs4(bIPsOxjEpoH,url,XgmQ1lh8HcUNPEiajL50): return
	JaqiYfEglZDvmwQNS8zR = Zg9FeADE84jSRIvPCrzYulw3sL
	hc5ePKxl4LJvEjDgTm = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('var url = "(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm[0]
	else: hc5ePKxl4LJvEjDgTm = url.replace('/vidpage_','/Play/')
	if 'http' not in hc5ePKxl4LJvEjDgTm: hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+hc5ePKxl4LJvEjDgTm
	hc5ePKxl4LJvEjDgTm = hc5ePKxl4LJvEjDgTm.strip('-')
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(Xo8KxLn4tlPM7GWbjwmF,'GET',hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'BOKRA-PLAY-2nd')
	CNhQcnS0dI6UFjbvLoyx = Pa6Q2LRkbtY0Id7nUNsZ.content
	JaqiYfEglZDvmwQNS8zR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if JaqiYfEglZDvmwQNS8zR:
		JaqiYfEglZDvmwQNS8zR = JaqiYfEglZDvmwQNS8zR[-1]
		if 'http' not in JaqiYfEglZDvmwQNS8zR: JaqiYfEglZDvmwQNS8zR = 'http:'+JaqiYfEglZDvmwQNS8zR
		if '/PLAY/' not in hc5ePKxl4LJvEjDgTm:
			if 'embed.min.js' in JaqiYfEglZDvmwQNS8zR:
				ZI27xz6yocas4bWlLgmtpAq3R = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',CNhQcnS0dI6UFjbvLoyx,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				if ZI27xz6yocas4bWlLgmtpAq3R:
					YjgoFIZUEwBPyCn, SpcLCATsBa8QqEmd4 = ZI27xz6yocas4bWlLgmtpAq3R[0]
					JaqiYfEglZDvmwQNS8zR = G9GCDqXJFAc(JaqiYfEglZDvmwQNS8zR,'url')+'/v2/'+YjgoFIZUEwBPyCn+'/config/'+SpcLCATsBa8QqEmd4+'.json'
		import XabeJODuZn
		XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu([JaqiYfEglZDvmwQNS8zR],bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49+'/Search/'+search
	mbzIyKNqMVt0FQeOsPWc(url)
	return
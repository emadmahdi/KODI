# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'ALFATIMI'
j0jSEdTPJuG4XNvfpO = '_FTM_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
GFj02wcbnlsK = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
A3pVEBYJtOuW1kS8DNH5 = ['3030','628']
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==60: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==61: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==62: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==63: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==64: CsaNhTtGm8 = IeJVc0T4xfmPj(text)
	elif mode==69: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,69,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'ما يتم مشاهدته الان',qfzHe2Yr49,64,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'recent_viewed_vids')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الاكثر مشاهدة',qfzHe2Yr49,64,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'most_viewed_vids')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'اضيفت مؤخرا',qfzHe2Yr49,64,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'recently_added_vids')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'فيديو عشوائي',qfzHe2Yr49,64,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'random_vids')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'افلام ومسلسلات',qfzHe2Yr49,61,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'-1')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'البرامج الدينية',qfzHe2Yr49,61,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'-2')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'English Videos',qfzHe2Yr49,61,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'-3')
	return Zg9FeADE84jSRIvPCrzYulw3sL
def mbzIyKNqMVt0FQeOsPWc(url,WWdHIOCPeKmgRstXk4c):
	zosuEtyPVpXKqO2H7xa = Zg9FeADE84jSRIvPCrzYulw3sL
	if WWdHIOCPeKmgRstXk4c not in ['-1','-2','-3']: zosuEtyPVpXKqO2H7xa = '?cat='+WWdHIOCPeKmgRstXk4c
	hc5ePKxl4LJvEjDgTm = qfzHe2Yr49+'/menu_level.php'+zosuEtyPVpXKqO2H7xa
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'ALFATIMI-TITLES-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	d5abDpJczu0OxK4nUq,L9GkAl40jOgC6nf7ixqhU3YQcJK1 = False,False
	for yDTPzhEBKVJl7CX81,title,count in items:
		title = BtKvPnEQJx32Z(title)
		title = title.strip(wjs26GpVfNiCUERHJ)
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
		zosuEtyPVpXKqO2H7xa = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('cat=(.*?)&',yDTPzhEBKVJl7CX81,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
		if WWdHIOCPeKmgRstXk4c==zosuEtyPVpXKqO2H7xa: d5abDpJczu0OxK4nUq = True
		elif d5abDpJczu0OxK4nUq 	or (WWdHIOCPeKmgRstXk4c=='-1' and zosuEtyPVpXKqO2H7xa in GFj02wcbnlsK)  						or (WWdHIOCPeKmgRstXk4c=='-2' and zosuEtyPVpXKqO2H7xa not in A3pVEBYJtOuW1kS8DNH5 and zosuEtyPVpXKqO2H7xa not in GFj02wcbnlsK)  						or (WWdHIOCPeKmgRstXk4c=='-3' and zosuEtyPVpXKqO2H7xa in A3pVEBYJtOuW1kS8DNH5):
							if count=='1': A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,63)
							else: A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,61,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,zosuEtyPVpXKqO2H7xa)
							L9GkAl40jOgC6nf7ixqhU3YQcJK1 = True
	if not L9GkAl40jOgC6nf7ixqhU3YQcJK1: dHjny9tTucrO(url)
	return
def dHjny9tTucrO(url):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALFATIMI-EPISODES-1st')
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)id="footer',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	yDTPzhEBKVJl7CX81 = Zg9FeADE84jSRIvPCrzYulw3sL
	for W8KBRzkdhlCxvF5sY2T,title,yDTPzhEBKVJl7CX81 in items:
		title = title.replace('Add',Zg9FeADE84jSRIvPCrzYulw3sL).replace('to Quicklist',Zg9FeADE84jSRIvPCrzYulw3sL).strip(wjs26GpVfNiCUERHJ)
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,63,W8KBRzkdhlCxvF5sY2T)
	HNRenB3EZX62qgSKMd4f=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?)div',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA=HNRenB3EZX62qgSKMd4f[0]
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('pagination(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	items=aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	hc5ePKxl4LJvEjDgTm = url.split('?')[0]
	for yDTPzhEBKVJl7CX81,W2yRvbsquF5XAMzd3jIPom in items:
		yDTPzhEBKVJl7CX81 = hc5ePKxl4LJvEjDgTm + yDTPzhEBKVJl7CX81
		title = BtKvPnEQJx32Z(W2yRvbsquF5XAMzd3jIPom)
		title = 'صفحة ' + title
		A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,62)
	return yDTPzhEBKVJl7CX81
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	if 'videos.php' in url: url = dHjny9tTucrO(url)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,url,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,True,'ALFATIMI-PLAY-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('playlistfile:"(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	nTdpZOCUe7l(url,bIPsOxjEpoH,'video')
	return
def IeJVc0T4xfmPj(WWdHIOCPeKmgRstXk4c):
	EEFf6enQDxk = { 'mode' : WWdHIOCPeKmgRstXk4c }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = nWw3GirR9qxCFBOa5Dt1gdXmJMpy(EEFf6enQDxk)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(fA1u9wd7EkGBObjDhvWa,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title,W8KBRzkdhlCxvF5sY2T in items:
		title = title.strip(wjs26GpVfNiCUERHJ)
		if 'http' not in yDTPzhEBKVJl7CX81: yDTPzhEBKVJl7CX81 = 'http:'+yDTPzhEBKVJl7CX81
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,63,W8KBRzkdhlCxvF5sY2T)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	IGh3FSLfnog2BjN8s = search.replace(wjs26GpVfNiCUERHJ,'+')
	url = qfzHe2Yr49 + '/search_result.php?query=' + IGh3FSLfnog2BjN8s
	dHjny9tTucrO(url)
	return
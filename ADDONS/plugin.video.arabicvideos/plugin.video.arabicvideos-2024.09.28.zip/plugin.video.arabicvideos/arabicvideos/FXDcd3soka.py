# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'GOOGLESEARCH'
j0jSEdTPJuG4XNvfpO = '_GOS_'
def mp9gnhjBIoA8Rz3SylG(LfnWDFgRdJH4lZvt7yo28N,tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG):
	if   LfnWDFgRdJH4lZvt7yo28N==1010: CsaNhTtGm8 = bELNFKS6fCB()
	elif LfnWDFgRdJH4lZvt7yo28N==1011: CsaNhTtGm8 = ATp5eRFzhs(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==1012: CsaNhTtGm8 = gsjZmY70i8l(tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==1013: CsaNhTtGm8 = l3fBmndMXVvGurShH()
	elif LfnWDFgRdJH4lZvt7yo28N==1014: CsaNhTtGm8 = Jp45zXlBLmGUeZg63uSAEf0c(tUHrEcLYK30N,Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==1015: CsaNhTtGm8 = kPerGdhbX8WUINZuJjR7M92Q(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==1016: CsaNhTtGm8 = hG5zELmjcWrPRaFgS6YNU8bAv9(Tbwq7kJ4vRSNVyUFcdMzirG)
	elif LfnWDFgRdJH4lZvt7yo28N==1018: CsaNhTtGm8 = KkZtb4lhPd(Tbwq7kJ4vRSNVyUFcdMzirG,-uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
	elif LfnWDFgRdJH4lZvt7yo28N==1019: CsaNhTtGm8 = KkZtb4lhPd(Tbwq7kJ4vRSNVyUFcdMzirG)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder','بحث جوجل جديد',Zg9FeADE84jSRIvPCrzYulw3sL,1019)
	A9Z3Ci2PQhFUwBXvI('link','كيف يعمل بحث جوجل','',1013)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'==== كلمات البحث المخزنة ===='+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	pJK32uYjB69RdQqr45b7Oxci8PM = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if pJK32uYjB69RdQqr45b7Oxci8PM:
		pJK32uYjB69RdQqr45b7Oxci8PM = pJK32uYjB69RdQqr45b7Oxci8PM['__SEQUENCED_COLUMNS__']
		for He8xrotiaD0spXjL in reversed(pJK32uYjB69RdQqr45b7Oxci8PM):
			A9Z3Ci2PQhFUwBXvI('folder',He8xrotiaD0spXjL,Zg9FeADE84jSRIvPCrzYulw3sL,1019,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,He8xrotiaD0spXjL)
	return
def KkZtb4lhPd(search,LHeJtTqAMg51lSo07fY8wNj3GU64k=uWf6FZMyi2NxL7bYlDCX80RO9pkTB):
	if not search:
		search = EnxNsqevtM28mpkZ5RG0()
		if not search: return
		search = search.lower()
	ZDUovIyE74YS2x = search.replace(j0jSEdTPJuG4XNvfpO,Zg9FeADE84jSRIvPCrzYulw3sL)
	mf6SbtOVs1Dnr = []
	if LHeJtTqAMg51lSo07fY8wNj3GU64k>0: mf6SbtOVs1Dnr = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GOOGLESEARCH_RESULTS',ZDUovIyE74YS2x)
	if not mf6SbtOVs1Dnr or LHeJtTqAMg51lSo07fY8wNj3GU64k<0:
		BBO5A28KsXcqWHCDFiteYGh = ZZtLJIAlQFqmb(search,LHeJtTqAMg51lSo07fY8wNj3GU64k)
		HQkdKuFbJpl,wBpCdnuXFb6E7ToWAMIsytVQ5NOG = [],[]
		for r1OMYvp0ViTG in BBO5A28KsXcqWHCDFiteYGh:
			name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC = r1OMYvp0ViTG
			if name==FLqQoZwdAngNkz49RMGUHJXW3bDC: wBpCdnuXFb6E7ToWAMIsytVQ5NOG.append(r1OMYvp0ViTG)
			else: HQkdKuFbJpl.append(r1OMYvp0ViTG)
		import bmdRh0UM1W
		if LHeJtTqAMg51lSo07fY8wNj3GU64k>=0: bmdRh0UM1W.tg4swfAUF2QmuOlDe68n9(ZDUovIyE74YS2x,'_GOOGLE',True)
		cb76opH5VXk2fjWqzExS0yTBGsen(zfdqH9nKtc3Sy6lbeWDm,'GOOGLESEARCH_RESULTS',ZDUovIyE74YS2x,[HQkdKuFbJpl,wBpCdnuXFb6E7ToWAMIsytVQ5NOG],uWf6FZMyi2NxL7bYlDCX80RO9pkTB)
		if LHeJtTqAMg51lSo07fY8wNj3GU64k<0:
			nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DETAILED_GOOGLE',ZDUovIyE74YS2x)
			bmdRh0UM1W.tg4swfAUF2QmuOlDe68n9(ZDUovIyE74YS2x,'_GOOGLE',False)
			nnWvBsbfxdHYJNLPAct(zfdqH9nKtc3Sy6lbeWDm,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+ZDUovIyE74YS2x+"')")
			I3kpd28CgLtrVEcuAXiZ('','','رسالة من المبرمج','تم عمل بحث جوجل جديد')
	A9Z3Ci2PQhFUwBXvI('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('folder','بحث منفرد لمواقع جوجل',Zg9FeADE84jSRIvPCrzYulw3sL,1011,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','نتائج البحث مفصلة - '+ZDUovIyE74YS2x,'opened_sites_google',1012,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('folder','نتائج البحث مقسمة - '+ZDUovIyE74YS2x,'listed_sites_google',1012,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('folder','مواقع جوجل - '+ZDUovIyE74YS2x,'',1016,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	A9Z3Ci2PQhFUwBXvI('link','إعادة بحث جوجل - '+ZDUovIyE74YS2x,'',1018,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,ZDUovIyE74YS2x)
	return
def hG5zELmjcWrPRaFgS6YNU8bAv9(ZDUovIyE74YS2x):
	HQkdKuFbJpl,wBpCdnuXFb6E7ToWAMIsytVQ5NOG = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GOOGLESEARCH_RESULTS',ZDUovIyE74YS2x)
	HQkdKuFbJpl = sorted(HQkdKuFbJpl,reverse=vvglE69OFKBm817Nkc,key=lambda key: key[UwCT5Oz6Wo0BP])
	mf6SbtOVs1Dnr = {}
	for name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC in HQkdKuFbJpl: mf6SbtOVs1Dnr[FLqQoZwdAngNkz49RMGUHJXW3bDC] = name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC
	YY1P4CAqJlQDc6fbg = list(mf6SbtOVs1Dnr.keys())
	import bmdRh0UM1W
	jH7iXopROeWL = bmdRh0UM1W.Eh0QVwABIdie(YY1P4CAqJlQDc6fbg)
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in jH7iXopROeWL:
		if 'tuple' in str(type(FLqQoZwdAngNkz49RMGUHJXW3bDC)):
			AhBFVbK7LzNinwrg65JjpRP.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			continue
		name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC = mf6SbtOVs1Dnr[FLqQoZwdAngNkz49RMGUHJXW3bDC]
		AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		A9Z3Ci2PQhFUwBXvI('folder',j8mQOhzZPXTwfLVM63riBa+name,yDTPzhEBKVJl7CX81,1014,VVE9FqW5n7yD6H,'',FLqQoZwdAngNkz49RMGUHJXW3bDC)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'===== ===== ===== '+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,9999)
	A9Z3Ci2PQhFUwBXvI('link',PPQORjT2lc7SVkKwFI4D+'مواقع بجوجل غير موجودة بالبرنامج'+u4IRSmrYMKkaHUBnDiLWh,Zg9FeADE84jSRIvPCrzYulw3sL,1015)
	wBpCdnuXFb6E7ToWAMIsytVQ5NOG = sorted(wBpCdnuXFb6E7ToWAMIsytVQ5NOG,reverse=vvglE69OFKBm817Nkc,key=lambda key: key[UwCT5Oz6Wo0BP])
	for name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC in wBpCdnuXFb6E7ToWAMIsytVQ5NOG:
		A9Z3Ci2PQhFUwBXvI('link','_GOS_'+PPQORjT2lc7SVkKwFI4D+name+wjs26GpVfNiCUERHJ+u4IRSmrYMKkaHUBnDiLWh,yDTPzhEBKVJl7CX81,1015,VVE9FqW5n7yD6H,'',FLqQoZwdAngNkz49RMGUHJXW3bDC)
	return
def gsjZmY70i8l(ynVak3xzErGlC,ZDUovIyE74YS2x):
	mf6SbtOVs1Dnr = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GOOGLESEARCH_RESULTS',ZDUovIyE74YS2x)
	if not mf6SbtOVs1Dnr: return
	HQkdKuFbJpl,wBpCdnuXFb6E7ToWAMIsytVQ5NOG = mf6SbtOVs1Dnr
	oDhMnqOW21bJH3zYvX4,rr9PpoKq3Wg = [],{}
	for name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC in HQkdKuFbJpl:
		oDhMnqOW21bJH3zYvX4.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		rr9PpoKq3Wg[FLqQoZwdAngNkz49RMGUHJXW3bDC] = efRWKaYs4q(title)
	import bmdRh0UM1W
	bmdRh0UM1W.K2oYJvSEPQiz(ZDUovIyE74YS2x,ynVak3xzErGlC,Zg9FeADE84jSRIvPCrzYulw3sL,oDhMnqOW21bJH3zYvX4,rr9PpoKq3Wg)
	return
def ATp5eRFzhs(search):
	mf6SbtOVs1Dnr = zZlsxj57ThCH(zfdqH9nKtc3Sy6lbeWDm,'list','GOOGLESEARCH_RESULTS',search)
	if not mf6SbtOVs1Dnr: return
	HQkdKuFbJpl,wBpCdnuXFb6E7ToWAMIsytVQ5NOG = mf6SbtOVs1Dnr
	HQkdKuFbJpl = sorted(HQkdKuFbJpl,reverse=vvglE69OFKBm817Nkc,key=lambda key: key[UwCT5Oz6Wo0BP])
	mf6SbtOVs1Dnr = {}
	for name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC in HQkdKuFbJpl:
		mf6SbtOVs1Dnr[FLqQoZwdAngNkz49RMGUHJXW3bDC] = name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC
	YY1P4CAqJlQDc6fbg = list(mf6SbtOVs1Dnr.keys())
	import bmdRh0UM1W
	jH7iXopROeWL = bmdRh0UM1W.Eh0QVwABIdie(YY1P4CAqJlQDc6fbg)
	for FLqQoZwdAngNkz49RMGUHJXW3bDC in jH7iXopROeWL:
		if 'tuple' in str(type(FLqQoZwdAngNkz49RMGUHJXW3bDC)):
			AhBFVbK7LzNinwrg65JjpRP.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			continue
		name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC = mf6SbtOVs1Dnr[FLqQoZwdAngNkz49RMGUHJXW3bDC]
		AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
		title = efRWKaYs4q(title)
		name = name+' - '+search
		A9Z3Ci2PQhFUwBXvI('folder',j8mQOhzZPXTwfLVM63riBa+name,FLqQoZwdAngNkz49RMGUHJXW3bDC,548,VVE9FqW5n7yD6H,'',title)
	return
def efRWKaYs4q(title):
	jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|حلقة)',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	wUpHn5IfzaQ8g4j = jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0] if jjYXOr8QJsNUZv0PGL27ARSDceiq4 else title
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	wUpHn5IfzaQ8g4j = wUpHn5IfzaQ8g4j.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return wUpHn5IfzaQ8g4j
def ZZtLJIAlQFqmb(search,LHeJtTqAMg51lSo07fY8wNj3GU64k):
	search = search.replace(wjs26GpVfNiCUERHJ,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	Pa6Q2LRkbtY0Id7nUNsZ = SmfLTBMNHF4QI1CtJpD9gn(LHeJtTqAMg51lSo07fY8wNj3GU64k,'GET',url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'GOOGLESEARCH-SEARCH-1st')
	O3Qs4RLrGcbMYazCITdogNwU,PcaEX452oRikq0F = [],[]
	if not Pa6Q2LRkbtY0Id7nUNsZ.succeeded: return O3Qs4RLrGcbMYazCITdogNwU
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = Pa6Q2LRkbtY0Id7nUNsZ.content
	YfOyLApok0dPx5Su2Z8b4qrcl7v1E = brAUlZfdFmt3TRJW2xX4.path.join(bhliCPq5mvAg19sIF,'googlesearch')
	if not brAUlZfdFmt3TRJW2xX4.path.exists(YfOyLApok0dPx5Su2Z8b4qrcl7v1E):
		try: brAUlZfdFmt3TRJW2xX4.makedirs(YfOyLApok0dPx5Su2Z8b4qrcl7v1E)
		except: pass
	qLx93JtrVCHlKaZW2hXc7dpiNmDR = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in qLx93JtrVCHlKaZW2hXc7dpiNmDR:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = JGmfjhoyKZUl('list',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA)
		yDTPzhEBKVJl7CX81 = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[17]
		title,text,name,EELGungxe6wKPar9hyRv5FUMpIB = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[31][0:4]
		name = name.strip(' ')
		if not name: name = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
		name = MwKxpYbB1gfk6RWQhl5F0sOAH4(name)
		if 'http://' in EELGungxe6wKPar9hyRv5FUMpIB or 'https://' in EELGungxe6wKPar9hyRv5FUMpIB: VVE9FqW5n7yD6H = EELGungxe6wKPar9hyRv5FUMpIB
		elif 'data:image/' in EELGungxe6wKPar9hyRv5FUMpIB and ';base64,' in EELGungxe6wKPar9hyRv5FUMpIB:
			W6xr5Re378nqPFsuJAIztkmhGgpVv = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('data:image/(\w+);base64,',EELGungxe6wKPar9hyRv5FUMpIB)
			W6xr5Re378nqPFsuJAIztkmhGgpVv = W6xr5Re378nqPFsuJAIztkmhGgpVv[0]
			VVE9FqW5n7yD6H = brAUlZfdFmt3TRJW2xX4.path.join(YfOyLApok0dPx5Su2Z8b4qrcl7v1E,name+'.'+W6xr5Re378nqPFsuJAIztkmhGgpVv)
			if not brAUlZfdFmt3TRJW2xX4.path.exists(VVE9FqW5n7yD6H):
				EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.replace('\\u003d','=')
				EELGungxe6wKPar9hyRv5FUMpIB = EELGungxe6wKPar9hyRv5FUMpIB.replace('data:image/'+W6xr5Re378nqPFsuJAIztkmhGgpVv+';base64,','')
				nhTwvGEluSxVd8s6oQrpUmc2 = JDMo92nlwsAZydBPkpNzFvU.b64decode(EELGungxe6wKPar9hyRv5FUMpIB)
				open(VVE9FqW5n7yD6H,'wb').write(nhTwvGEluSxVd8s6oQrpUmc2)
		else: VVE9FqW5n7yD6H = ''
		FLqQoZwdAngNkz49RMGUHJXW3bDC = Ttk2dsfXR1QzJxycKBnN0a9mALVoS(name,yDTPzhEBKVJl7CX81)
		if FLqQoZwdAngNkz49RMGUHJXW3bDC not in PcaEX452oRikq0F:
			PcaEX452oRikq0F.append(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			name = ulj9JfWhc0EgZbsm(FLqQoZwdAngNkz49RMGUHJXW3bDC)
			O3Qs4RLrGcbMYazCITdogNwU.append([name,yDTPzhEBKVJl7CX81,title,text,VVE9FqW5n7yD6H,FLqQoZwdAngNkz49RMGUHJXW3bDC])
	return O3Qs4RLrGcbMYazCITdogNwU
def Jp45zXlBLmGUeZg63uSAEf0c(yDTPzhEBKVJl7CX81,FLqQoZwdAngNkz49RMGUHJXW3bDC):
	AxIs6lqNDCuzmEwoKg475J,BZNYcxOXAElzS2IPf0aji,j8mQOhzZPXTwfLVM63riBa = aZiCA5ThU2k6osm4Nl1ugzDF(FLqQoZwdAngNkz49RMGUHJXW3bDC)
	if j8mQOhzZPXTwfLVM63riBa: AxIs6lqNDCuzmEwoKg475J()
	else: kPerGdhbX8WUINZuJjR7M92Q()
	return
def l3fBmndMXVvGurShH():
	I3kpd28CgLtrVEcuAXiZ('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def kPerGdhbX8WUINZuJjR7M92Q(FLqQoZwdAngNkz49RMGUHJXW3bDC=''):
	I3kpd28CgLtrVEcuAXiZ('','',FLqQoZwdAngNkz49RMGUHJXW3bDC,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def Ttk2dsfXR1QzJxycKBnN0a9mALVoS(name,yDTPzhEBKVJl7CX81):
	qctaNTZYpz0 = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	W4KwrJtUfaNF2Q3Coqsl869V1dbm = name.lower()
	Tbl0qZIrG9p = ''
	for key in list(qctaNTZYpz0.keys()):
		if key.lower() in W4KwrJtUfaNF2Q3Coqsl869V1dbm: Tbl0qZIrG9p = qctaNTZYpz0[key]
	if not Tbl0qZIrG9p:
		WOry7DZPocFhH8p4 = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'url')
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in list(PhpFa6EdVS.keys()):
			Lx0JNzMogifQkWXa5KvGmcITEt = G9GCDqXJFAc(PhpFa6EdVS[FLqQoZwdAngNkz49RMGUHJXW3bDC][0],'url')
			if WOry7DZPocFhH8p4==Lx0JNzMogifQkWXa5KvGmcITEt: Tbl0qZIrG9p = FLqQoZwdAngNkz49RMGUHJXW3bDC
	if not Tbl0qZIrG9p:
		W4KwrJtUfaNF2Q3Coqsl869V1dbm = G9GCDqXJFAc(yDTPzhEBKVJl7CX81,'name')
		for FLqQoZwdAngNkz49RMGUHJXW3bDC in list(PhpFa6EdVS.keys()):
			uGgbzHI7ro = G9GCDqXJFAc(PhpFa6EdVS[FLqQoZwdAngNkz49RMGUHJXW3bDC][0],'name')
			if W4KwrJtUfaNF2Q3Coqsl869V1dbm==uGgbzHI7ro: Tbl0qZIrG9p = FLqQoZwdAngNkz49RMGUHJXW3bDC
	if not Tbl0qZIrG9p: Tbl0qZIrG9p = name
	Tbl0qZIrG9p = Tbl0qZIrG9p.upper()
	return Tbl0qZIrG9p
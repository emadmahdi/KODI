# -*- coding: utf-8 -*-
from V1VREBsj92 import *
bIPsOxjEpoH = 'MOVIZLAND'
headers = { 'User-Agent' : Zg9FeADE84jSRIvPCrzYulw3sL }
j0jSEdTPJuG4XNvfpO = '_MVZ_'
qfzHe2Yr49 = PhpFa6EdVS[bIPsOxjEpoH][0]
p2tHwDRfg16WJ0IYF5xLXGa9S7us = PhpFa6EdVS[bIPsOxjEpoH][1]
def mp9gnhjBIoA8Rz3SylG(mode,url,text):
	if   mode==180: CsaNhTtGm8 = bELNFKS6fCB()
	elif mode==181: CsaNhTtGm8 = mbzIyKNqMVt0FQeOsPWc(url,text)
	elif mode==182: CsaNhTtGm8 = npRzZYjSm35wucxNPFlsTibVJeqI(url)
	elif mode==183: CsaNhTtGm8 = dHjny9tTucrO(url)
	elif mode==188: CsaNhTtGm8 = XzHvmJrO3PeBWN7oqu1pwE6jZK()
	elif mode==189: CsaNhTtGm8 = KkZtb4lhPd(text)
	else: CsaNhTtGm8 = False
	return CsaNhTtGm8
def XzHvmJrO3PeBWN7oqu1pwE6jZK():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	I3kpd28CgLtrVEcuAXiZ(Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'رسالة من المبرمج',message)
	return
def bELNFKS6fCB():
	A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'بحث في الموقع',Zg9FeADE84jSRIvPCrzYulw3sL,189,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'_REMEMBERRESULTS_')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'بوكس اوفيس موفيز لاند',qfzHe2Yr49,181,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'box-office')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'أحدث الافلام',qfzHe2Yr49,181,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'latest-movies')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'تليفزيون موفيز لاند',qfzHe2Yr49,181,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'tv')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'الاكثر مشاهدة',qfzHe2Yr49,181,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'top-views')
	A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+'أقوى الافلام الحالية',qfzHe2Yr49,181,Zg9FeADE84jSRIvPCrzYulw3sL,Zg9FeADE84jSRIvPCrzYulw3sL,'top-movies')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-MENU-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<h2><a href="(.*?)".*?">(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	for yDTPzhEBKVJl7CX81,title in items:
		A9Z3Ci2PQhFUwBXvI('folder',bIPsOxjEpoH+'_SCRIPT_'+j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,181)
	return yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
def mbzIyKNqMVt0FQeOsPWc(url,type=Zg9FeADE84jSRIvPCrzYulw3sL):
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,url,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	elif type=='box-office': nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	elif type=='top-movies': nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('btn-2-overlay(.*?)<style>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	elif type=='top-views': nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	elif type=='tv': nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	else: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
	if type in ['top-views','top-movies']:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	else: items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	cfUCuhJwZijTLxQX3gHayn89RqGrP = []
	odEpDjOFTcz39bsiAwVUKXMkQ8u51 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for W8KBRzkdhlCxvF5sY2T,uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,Bmxi32K6Taz90GXCreMD48wb in items:
		if type in ['top-views','top-movies']:
			W8KBRzkdhlCxvF5sY2T,yDTPzhEBKVJl7CX81,WOry7DZPocFhH8p4,title = W8KBRzkdhlCxvF5sY2T,uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,Bmxi32K6Taz90GXCreMD48wb
		else: W8KBRzkdhlCxvF5sY2T,title,yDTPzhEBKVJl7CX81,WOry7DZPocFhH8p4 = W8KBRzkdhlCxvF5sY2T,uNy4ZJUMEiTj5aS0Rxf619YPzrk,YswlgoudyzkW8hARTP09tDG16a,Bmxi32K6Taz90GXCreMD48wb
		yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81)
		yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81.replace('?view=true',Zg9FeADE84jSRIvPCrzYulw3sL)
		title = BtKvPnEQJx32Z(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('بجوده ',Zg9FeADE84jSRIvPCrzYulw3sL)
		title = title.strip(wjs26GpVfNiCUERHJ)
		if 'الحلقة' in title or 'الحلقه' in title:
			jjYXOr8QJsNUZv0PGL27ARSDceiq4 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|الحلقه) \d+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if jjYXOr8QJsNUZv0PGL27ARSDceiq4:
				title = '_MOD_' + jjYXOr8QJsNUZv0PGL27ARSDceiq4[0][0]
				if title not in cfUCuhJwZijTLxQX3gHayn89RqGrP:
					A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,183,W8KBRzkdhlCxvF5sY2T)
					cfUCuhJwZijTLxQX3gHayn89RqGrP.append(title)
		elif any(B251BPiLbvG9UxszKtlI7YQHmoWw in title for B251BPiLbvG9UxszKtlI7YQHmoWw in odEpDjOFTcz39bsiAwVUKXMkQ8u51):
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81 + '?servers=' + WOry7DZPocFhH8p4
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,182,W8KBRzkdhlCxvF5sY2T)
		else:
			yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81 + '?servers=' + WOry7DZPocFhH8p4
			A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,183,W8KBRzkdhlCxvF5sY2T)
	if type==Zg9FeADE84jSRIvPCrzYulw3sL:
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('\n<li><a href="(.*?)".*?>(.*?)<',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81,title in items:
			title = BtKvPnEQJx32Z(title)
			title = title.replace('الصفحة ',Zg9FeADE84jSRIvPCrzYulw3sL)
			if title!=Zg9FeADE84jSRIvPCrzYulw3sL:
				A9Z3Ci2PQhFUwBXvI('folder',j0jSEdTPJuG4XNvfpO+'صفحة '+title,yDTPzhEBKVJl7CX81,181)
	return
def dHjny9tTucrO(url):
	hc5ePKxl4LJvEjDgTm = url.split('?servers=')[0]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-EPISODES-1st')
	nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	title,DMKySWniQ0HqtCsrg65dmb2Tha,W8KBRzkdhlCxvF5sY2T = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA[0]
	name = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('class="episodesNumbers"(.*?)</div>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if HNRenB3EZX62qgSKMd4f:
		nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[0]
		items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(.*?)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
		for yDTPzhEBKVJl7CX81 in items:
			yDTPzhEBKVJl7CX81 = UAjMPLdITqWChbrcB(yDTPzhEBKVJl7CX81)
			title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(الحلقة|الحلقه)-([0-9]+)',yDTPzhEBKVJl7CX81.split('/')[-2],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if not title: title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('()-([0-9]+)',yDTPzhEBKVJl7CX81.split('/')[-2],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if title: title = wjs26GpVfNiCUERHJ + title[0][1]
			else: title = Zg9FeADE84jSRIvPCrzYulw3sL
			title = name + ' - ' + 'الحلقة' + title
			title = BtKvPnEQJx32Z(title)
			A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,yDTPzhEBKVJl7CX81,182,W8KBRzkdhlCxvF5sY2T)
	if not items:
		title = BtKvPnEQJx32Z(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',Zg9FeADE84jSRIvPCrzYulw3sL).replace('بجوده ',Zg9FeADE84jSRIvPCrzYulw3sL)
		A9Z3Ci2PQhFUwBXvI('video',j0jSEdTPJuG4XNvfpO+title,url,182,W8KBRzkdhlCxvF5sY2T)
	return
def npRzZYjSm35wucxNPFlsTibVJeqI(url):
	XrEQ2VJFc6KxMwvdqGH5oUhICOu1 = url.split('?servers=')
	hc5ePKxl4LJvEjDgTm = XrEQ2VJFc6KxMwvdqGH5oUhICOu1[0]
	del XrEQ2VJFc6KxMwvdqGH5oUhICOu1[0]
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,hc5ePKxl4LJvEjDgTm,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-PLAY-1st')
	yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('font-size: 25px;" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)[0]
	if yDTPzhEBKVJl7CX81 not in XrEQ2VJFc6KxMwvdqGH5oUhICOu1: XrEQ2VJFc6KxMwvdqGH5oUhICOu1.append(yDTPzhEBKVJl7CX81)
	fo6s53yEnbklLpaJOzgR4Q01wxB = []
	for yDTPzhEBKVJl7CX81 in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
		if '://moshahda.' in yDTPzhEBKVJl7CX81:
			mmX2Ja6PMpyGYi = yDTPzhEBKVJl7CX81
			fo6s53yEnbklLpaJOzgR4Q01wxB.append(mmX2Ja6PMpyGYi+'?named=Main')
	for yDTPzhEBKVJl7CX81 in XrEQ2VJFc6KxMwvdqGH5oUhICOu1:
		if '://vb.movizland.' in yDTPzhEBKVJl7CX81:
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,yDTPzhEBKVJl7CX81,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-PLAY-2nd')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.decode('windows-1256').encode(nJ5QfkKIG9C3e7Ozq61MU8Dmhc)
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			HNRenB3EZX62qgSKMd4f = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
			if HNRenB3EZX62qgSKMd4f:
				F9mNlIL0VX5uOT18sf,A7TBFRkU8Q3 = [],[]
				if len(HNRenB3EZX62qgSKMd4f)==1:
					title = Zg9FeADE84jSRIvPCrzYulw3sL
					nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG
				else:
					for nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA in HNRenB3EZX62qgSKMd4f:
						idOhoxawsrWQVgTMfGC6lBmDN7XEK = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
						if idOhoxawsrWQVgTMfGC6lBmDN7XEK: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = 'src="/uploads/13721411411.png"  \n  ' + idOhoxawsrWQVgTMfGC6lBmDN7XEK[0][1]
						idOhoxawsrWQVgTMfGC6lBmDN7XEK = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
						if idOhoxawsrWQVgTMfGC6lBmDN7XEK: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = 'src="/uploads/13721411411.png"  \n  ' + idOhoxawsrWQVgTMfGC6lBmDN7XEK[0]
						idOhoxawsrWQVgTMfGC6lBmDN7XEK = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
						if idOhoxawsrWQVgTMfGC6lBmDN7XEK: nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = idOhoxawsrWQVgTMfGC6lBmDN7XEK[0] + '  \n  src="/uploads/13721411411.png"'
						BQwyjcvgY4qmnOpSLbsdfNCh = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<(.*?)http://up.movizland.(online|com)/uploads/',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
						title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('> *([^<>]+) *<',BQwyjcvgY4qmnOpSLbsdfNCh[0][0],aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
						title = wjs26GpVfNiCUERHJ.join(title)
						title = title.strip(wjs26GpVfNiCUERHJ)
						title = title.replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ).replace(F4skx1A3wOEh9lmPuZMnpCzR,wjs26GpVfNiCUERHJ)
						F9mNlIL0VX5uOT18sf.append(title)
					lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('أختر الفيديو المطلوب:', F9mNlIL0VX5uOT18sf)
					if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1 : return
					title = F9mNlIL0VX5uOT18sf[lqQvOUWodZnhXLS2Vcuj6EtairFN]
					nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = HNRenB3EZX62qgSKMd4f[lqQvOUWodZnhXLS2Vcuj6EtairFN]
				yDTPzhEBKVJl7CX81 = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('href="(http://moshahda\..*?/\w+.html)"',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				aES0lq7Jmi = yDTPzhEBKVJl7CX81[0]
				fo6s53yEnbklLpaJOzgR4Q01wxB.append(aES0lq7Jmi+'?named=Forum')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('ـ',Zg9FeADE84jSRIvPCrzYulw3sL)
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA = nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				mxkyz9tWqFfsgnU = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',nCc1OGt26FQ3Ey9La4SIpNjKXv5bqA,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
				for dSLtcIN4qK9WhbzVv7Jxe1M08 in mxkyz9tWqFfsgnU:
					type = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall(' typetype="(.*?)" ',dSLtcIN4qK9WhbzVv7Jxe1M08)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = Zg9FeADE84jSRIvPCrzYulw3sL
					items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',dSLtcIN4qK9WhbzVv7Jxe1M08,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
					for VVsA4S1GuREb,yDTPzhEBKVJl7CX81 in items:
						title = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('(\w+[ \w]*)<',VVsA4S1GuREb)
						title = title[-1]
						yDTPzhEBKVJl7CX81 = yDTPzhEBKVJl7CX81 + '?named=' + title + type
						fo6s53yEnbklLpaJOzgR4Q01wxB.append(yDTPzhEBKVJl7CX81)
	JaqiYfEglZDvmwQNS8zR = hc5ePKxl4LJvEjDgTm.replace(qfzHe2Yr49,p2tHwDRfg16WJ0IYF5xLXGa9S7us)
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(ggWsYrlq8fy2v,JaqiYfEglZDvmwQNS8zR,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-PLAY-3rd')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('" href="(.*?)"',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	if items:
		rDEjaqTcoMu4OFV6b02kIAwZLPiXG = items[-1]
		fo6s53yEnbklLpaJOzgR4Q01wxB.append(rDEjaqTcoMu4OFV6b02kIAwZLPiXG+'?named=Mobile')
	import XabeJODuZn
	XabeJODuZn.PayeNkwilE7tGdLcQOngopvqu(fo6s53yEnbklLpaJOzgR4Q01wxB,bIPsOxjEpoH,'video',url)
	return
def KkZtb4lhPd(search):
	search,NNYRDot8vC,showDialogs = xXQLatdZbuT1H6(search)
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: search = EnxNsqevtM28mpkZ5RG0()
	if search==Zg9FeADE84jSRIvPCrzYulw3sL: return
	search = search.replace(wjs26GpVfNiCUERHJ,'+')
	yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG = chPtxDrfKE42FWZMd8VlowpAb1mIUN(E8RabFm1Kp5O0s,qfzHe2Yr49,Zg9FeADE84jSRIvPCrzYulw3sL,headers,Zg9FeADE84jSRIvPCrzYulw3sL,'MOVIZLAND-SEARCH-1st')
	items = aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.findall('<option value="(.*?)">(.*?)</option>',yJvWd6ZtOrxY8gnRE2IlcmH1fPauUG,aqr0hwGeVSk1Zz4FoAygn3OxuftMLJ.DOTALL)
	ImDCBeZOpgTsl08KL9 = [ Zg9FeADE84jSRIvPCrzYulw3sL ]
	ahOzQTt23CfVy9xKoB0DUgPFrjmsp = [ 'الكل وبدون فلتر' ]
	for WWdHIOCPeKmgRstXk4c,title in items:
		ImDCBeZOpgTsl08KL9.append(WWdHIOCPeKmgRstXk4c)
		ahOzQTt23CfVy9xKoB0DUgPFrjmsp.append(title)
	if WWdHIOCPeKmgRstXk4c:
		lqQvOUWodZnhXLS2Vcuj6EtairFN = WXZLgSfpV2jzRFTNiyroc('اختر الفلتر المناسب:', ahOzQTt23CfVy9xKoB0DUgPFrjmsp)
		if lqQvOUWodZnhXLS2Vcuj6EtairFN == -1 : return
		WWdHIOCPeKmgRstXk4c = ImDCBeZOpgTsl08KL9[lqQvOUWodZnhXLS2Vcuj6EtairFN]
	else: WWdHIOCPeKmgRstXk4c = Zg9FeADE84jSRIvPCrzYulw3sL
	url = qfzHe2Yr49 + '/?s='+search+'&mcat='+WWdHIOCPeKmgRstXk4c
	mbzIyKNqMVt0FQeOsPWc(url)
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_ = l1111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪᒻ")
menu_name = l1111_l1_ (u"ࠩࡢࡇࡒࡉ࡟ࠨᒼ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"้ࠪํู่่ࠡอๅ้๐ใิࠩᒽ")]
def l1111ll_l1_(mode,url,text):
	if   mode==490: l11l_l1_ = l11l111_l1_()
	elif mode==491: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==492: l11l_l1_ = l1lllll_l1_(url)
	elif mode==493: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==494: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==499: l11l_l1_ = l1lll1_l1_(text,url)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᒾ"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭ᒿ"),l1111_l1_ (u"࠭ࠧᓀ"),l1111_l1_ (u"ࠧࠨᓁ"),l1111_l1_ (u"ࠨࠩᓂ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᓃ"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᓄ"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"ࠫ࠴࠭ᓅ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩᓆ"))
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓇ"),menu_name+l1111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᓈ"),l1llll1lll_l1_,499,l1111_l1_ (u"ࠨࠩᓉ"),l1111_l1_ (u"ࠩࠪᓊ"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᓋ"))
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓌ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᓍ")+menu_name+l1111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬᓎ"),l1llll1lll_l1_,491,l1111_l1_ (u"ࠧࠨᓏ"),l1111_l1_ (u"ࠨࠩᓐ"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᓑ"))
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᓒ"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᓓ"),l1111_l1_ (u"ࠬ࠭ᓔ"),9999)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠠࡂ࡬ࡤࡼ࡮࡬ࡹࡇ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᓕ"),html,re.DOTALL)
	if l1l11lll1_l1_:
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡬ࡩ࡭ࡶࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᓖ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title in l11ll11_l1_: continue
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵࡯࡭ࡦ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫᓗ")+l1l111l_l1_+l1111_l1_ (u"ࠩ࠱ࡴ࡭ࡶࠧᓘ")
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓙ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨᓚ")+menu_name+title,l1l111l_l1_,491)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᓛ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᓜ"),l1111_l1_ (u"ࠧࠨᓝ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓞ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᓟ")+menu_name+l1111_l1_ (u"ࠪวๆ๊วๆࠩᓠ"),l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศใ็ห๊࠳࡭ࡰࡸ࡬ࡩࡸ࠳ࡦࡪ࡮ࡰࡩ࠴࡬࡯ࡳࡧ࡬࡫ࡳ࠳ࡨࡥ࠯สๅ้อๅ࠮ษฯ๊อ๏࠭࠳ࠩᓡ"),494,l1111_l1_ (u"ࠬ࠭ᓢ"),l1111_l1_ (u"࠭ࠧᓣ"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᓤ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓥ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᓦ")+menu_name+l1111_l1_ (u"ุ้๊ࠪำๅษอࠫᓧ"),l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ๆี็ื้อส࠰็ึุ่๊วห࠯สะ๋ฮ้ࠨᓨ"),494,l1111_l1_ (u"ࠬ࠭ᓩ"),l1111_l1_ (u"࠭ࠧᓪ"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᓫ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᓬ"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᓭ"),l1111_l1_ (u"ࠪࠫᓮ"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᓯ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᓰ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if l1l111l_l1_==l1111_l1_ (u"࠭࠯ࠨᓱ"): continue
		if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬᓲ") not in l1l111l_l1_: l1l111l_l1_ = l1llll1lll_l1_+l1l111l_l1_
		if title in l11ll11_l1_: continue
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓳ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᓴ")+menu_name+title,l1l111l_l1_,491)
	return html
def l11lll1l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᓵ"),l1111_l1_ (u"ࠫࠬᓶ"),url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩᓷ"),url,l1111_l1_ (u"࠭ࠧᓸ"),l1111_l1_ (u"ࠧࠨᓹ"),l1111_l1_ (u"ࠨࠩᓺ"),l1111_l1_ (u"ࠩࠪᓻ"),l1111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᓼ"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᓽ"),html,re.DOTALL)
	if l1lll1l1ll_l1_:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᓾ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title in l11ll11_l1_: continue
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓿ"),menu_name+title,l1l111l_l1_,491)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠧࠨᔀ")):
	items = []
	#l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠨࡷࡵࡰࠬᔁ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭ᔂ"),url,l1111_l1_ (u"ࠪࠫᔃ"),l1111_l1_ (u"ࠫࠬᔄ"),l1111_l1_ (u"ࠬ࠭ᔅ"),l1111_l1_ (u"࠭ࠧᔆ"),l1111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᔇ"))
	html = response.content
	block = l1111_l1_ (u"ࠨࠩᔈ")
	if l1111_l1_ (u"ࠩ࠱ࡴ࡭ࡶࠧᔉ") in url: block = html
	elif l1111_l1_ (u"ࠪࡃࡸࡃࠧᔊ") in url:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡨ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࠥࡱࡦࡴࡩࡧࡧࡶࡸࠧ࠭ᔋ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔌ"),block,re.DOTALL)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࠧࡳࡡ࡯࡫ࡩࡩࡸࡺࠢࠨᔍ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
	if not block: return
	#if not items: items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࡜࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡦࡴࡾࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᔎ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ࠨ็ืห์ีษࠨᔏ"),l1111_l1_ (u"ࠩไ๎้๋ࠧᔐ"),l1111_l1_ (u"ࠪห฿์๊สࠩᔑ"),l1111_l1_ (u"ࠫศเๆ๋หࠪᔒ"),l1111_l1_ (u"้ࠬไ๋สࠪᔓ"),l1111_l1_ (u"࠭วฺๆส๊ࠬᔔ"),l1111_l1_ (u"่ࠧัสๅࠬᔕ"),l1111_l1_ (u"ࠨ็หหึอษࠨᔖ"),l1111_l1_ (u"ࠩ฼ี฻࠭ᔗ"),l1111_l1_ (u"้ࠪ์ืฬศ่ࠪᔘ"),l1111_l1_ (u"ࠫฬ๊ศ้็ࠪᔙ"),l1111_l1_ (u"๋ࠬำาฯํอࠬᔚ")]
	for l1l111l_l1_,img,title in items:
		title = l1l1111_l1_(title)
		l11l11l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧᔛ"),title,re.DOTALL)
		if not l11l11l_l1_: l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᔜ"),title,re.DOTALL)
		if not l11l11l_l1_ or any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᔝ"),menu_name+title,l1l111l_l1_,492,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠩะ่็ฯࠧᔞ") in title:
			title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᔟ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔠ"),menu_name+title,l1l111l_l1_,493,img)
				l1lllll1_l1_.append(title)
		else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔡ"),menu_name+title,l1l111l_l1_,493,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔢ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᔣ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠨษ็ูๆำษࠡࠩᔤ"),l1111_l1_ (u"ࠩࠪᔥ"))
			if title!=l1111_l1_ (u"ࠪࠫᔦ"): l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔧ"),menu_name+l1111_l1_ (u"ࠬ฻แฮหࠣࠫᔨ")+title,l1l111l_l1_,491)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪᔩ"),url,l1111_l1_ (u"ࠧࠨᔪ"),l1111_l1_ (u"ࠨࠩᔫ"),l1111_l1_ (u"ࠩࠪᔬ"),l1111_l1_ (u"ࠪࠫᔭ"),l1111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᔮ"))
	html = response.content
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡂࡶࡶࡷࡳࡳࡹࡂࡢࡴࡆࡳࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᔯ"),html,re.DOTALL)
	if l1l1lll_l1_:
		l1l1lll_l1_ = l1l1lll_l1_[0]
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪᔰ"),l1l1lll_l1_,l1111_l1_ (u"ࠧࠨᔱ"),l1111_l1_ (u"ࠨࠩᔲ"),l1111_l1_ (u"ࠩࠪᔳ"),l1111_l1_ (u"ࠪࠫᔴ"),l1111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᔵ"))
		html = response.content
	img = re.findall(l1111_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᔶ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᔷ"))
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᔸ"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫᔹ"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᔺ") not in url:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᔻ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔼ"),menu_name+title,l1l111l_l1_,493,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩࡡࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡤࡲࡼࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᔽ"),block,re.DOTALL)
		if items:
			for l1l111l_l1_,img,title in items:
				title = title.strip(l1111_l1_ (u"࠭ࠠࠨᔾ"))
				l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᔿ"),menu_name+title,l1l111l_l1_,492,img)
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᕀ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᕁ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				title = l1l1111_l1_(title)
				title = title.replace(l1111_l1_ (u"ࠪห้฻แฮหࠣࠫᕂ"),l1111_l1_ (u"ࠫࠬᕃ"))
				if title!=l1111_l1_ (u"ࠬ࠭ᕄ"): l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕅ"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭ᕆ")+title,l1l111l_l1_,491)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url.strip(l1111_l1_ (u"ࠨ࠱ࠪᕇ"))+l1111_l1_ (u"ࠩ࠲ࡃࡻ࡯ࡥࡸ࠿࠴ࠫᕈ")
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᕉ"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬᕊ"),l1111_l1_ (u"ࠬ࠭ᕋ"),l1111_l1_ (u"࠭ࠧᕌ"),l1111_l1_ (u"ࠧࠨᕍ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᕎ"))
	html = response.content
	l11lll1l_l1_ = []
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠩࡸࡶࡱ࠭ᕏ"))
	l1lll111l1_l1_ = re.findall(l1111_l1_ (u"ࠥࡨࡦࡺࡡ࠻ࠢࠪࡵࡂ࠮࠮ࠫࡁࠬࠪࠧᕐ"),html,re.DOTALL)
	#if not l1lll111l1_l1_: l1lll111l1_l1_ = re.findall(l1111_l1_ (u"ࠫࡡ࠮ࡴࡩ࡫ࡶࡠ࠳࡯ࡤ࡝࠮࠳ࡠ࠱࠮࠮ࠫࡁࠬࡠ࠮࠭ᕑ"),html,re.DOTALL)
	l1lll111l1_l1_ = l1lll111l1_l1_[0]
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕒ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩᕓ"),block,re.DOTALL)
		for l1lll1l111_l1_,title in items:
			title = title.strip(l1111_l1_ (u"ࠧࠡࠩᕔ"))
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵࡯࡭ࡦ࠲ࡷࡪࡸࡶࡦࡴࡶ࠳ࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡳࡀࠫᕕ")+l1lll111l1_l1_+l1111_l1_ (u"ࠩࠩ࡭ࡂ࠭ᕖ")+l1lll1l111_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᕗ")+title+l1111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᕘ")
			l11lll1l_l1_.append(l1l111l_l1_)
	# l11l1l11l_l1_ l11ll1l1l_l1_ l1l111l_l1_
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡘ࡫ࡲࡷࡧࡵࠦ࠳࠰࠿ࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕙ"),html,re.DOTALL)
	if l1l111l_l1_:
		title = l1111_l1_ (u"࠭ๅโุ็ࠫᕚ")
		l1l111l_l1_ = l1l111l_l1_[0]+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࠪᕛ")+title
		l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	#l1l1lll_l1_ = url.strip(l1111_l1_ (u"ࠨ࠱ࠪᕜ"))+l1111_l1_ (u"ࠩ࠲ࡃࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠱ࠨᕝ")
	#response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᕞ"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬᕟ"),l1111_l1_ (u"ࠬ࠭ᕠ"),l1111_l1_ (u"࠭ࠧᕡ"),l1111_l1_ (u"ࠧࠨᕢ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᕣ"))
	#html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᕤ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕥ"),block,re.DOTALL)
		for title,l1l111l_l1_ in items:
			title = title.strip(l1111_l1_ (u"ࠫࠥ࠭ᕦ"))
			if l1111_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭ᕧ") in l1l111l_l1_: title2 = l1111_l1_ (u"࠭࡟ࡠะสูࠬᕨ")
			else: title2 = l1111_l1_ (u"ࠧࠨᕩ")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᕪ")+title+l1111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᕫ")+title2
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᕬ"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᕭ"),url)
	return
def l1lll1_l1_(search,l1llll1lll_l1_=l1111_l1_ (u"ࠬ࠭ᕮ")):
	if not l1llll1lll_l1_: l1llll1lll_l1_ = l1ll11l_l1_
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search:
		search = l11ll_l1_()
		if not search: return
	search = search.replace(l1111_l1_ (u"࠭ࠠࠨᕯ"),l1111_l1_ (u"ࠧࠬࠩᕰ"))
	url = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠯ࡲ࡫ࡴࡄࡹ࠽ࠨᕱ")+search
	l1l11l1_l1_(url)
	return
#   search is l1lll11ll1_l1_ l1lll11lll_l1_ in l1l11l1_l1_()
#   l1ll11ll_l1_://l1lll111ll_l1_.l1lll11l11_l1_-l1lll11l1l_l1_.l1lll11l1l_l1_/?s=the+l1lll11111_l1_
#   l1ll11ll_l1_://l1lll111ll_l1_.l1lll11l11_l1_-l1lll11l1l_l1_.l1lll11l1l_l1_/search/the+l1lll11111_l1_/
#   l1ll11ll_l1_://l1lll111ll_l1_.l1lll11l11_l1_-l1lll11l1l_l1_.l1lll11l1l_l1_/index.l1lll1111l_l1_?s=the+l1lll11111_l1_
#	l1ll11ll_l1_://l1lll11l11_l1_-l1lll11l1l_l1_.io/index.l1lll1111l_l1_?s=the+l1lll11111_l1_
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
headers = { l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫੈ") : l1111_l1_ (u"ࠨࠩ੉") }
l111_l1_=l1111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ੊")
menu_name=l1111_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩੋ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
#l11l1_l1_ = [l1111_l1_ (u"ࠫๆ๐ไๆࠩੌ"),l1111_l1_ (u"้ࠬไ๋ส੍ࠪ"),l1111_l1_ (u"࠭วๅ฻ิฺࠥอไศีห์฾๐ࠧ੎"),l1111_l1_ (u"ࠧๆีิั๏ฯࠧ੏"),l1111_l1_ (u"ࠨ็ึีา๐็ࠨ੐"),l1111_l1_ (u"ࠩส฾๋๐ษࠨੑ"),l1111_l1_ (u"ࠪห฾๊ว็ࠩ੒"),l1111_l1_ (u"้่ࠫวยࠩ੓")]
#proxy = l1111_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷࠵࠺࠰࠵࠴࠸࠴࠸࠸࠰࠴࠷࠵ࡀ࠳࠲࠴࠻ࠫ੔")
#proxy = l1111_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭੕")+l11ll11l_l1_[6][1]
proxy = l1111_l1_ (u"ࠧࠨ੖")
l11ll11_l1_ = [l1111_l1_ (u"ࠨล็฽ฬฮࠧ੗"),l1111_l1_ (u"ࠩส่๊฻วา฻ฬࠤฬ๊อาหࠪ੘"),l1111_l1_ (u"ࠪห้่ัศ่ࠣห้้ั๋็ࠪਖ਼"),l1111_l1_ (u"ࠫฬ๊ใหสࠣ์ࠥอไศสะหะ࠭ਗ਼"),l1111_l1_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨਜ਼"),l1111_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬึวฺ์ฬࠫੜ")]
def l1111ll_l1_(mode,url,text):
	if   mode==240: l11l_l1_ = l11l111_l1_()
	elif mode==241: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==242: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==243: l11l_l1_ = l1lllll_l1_(url)
	elif mode==244: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ੝")+text)
	elif mode==245: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨਫ਼")+text)
	elif mode==246: l11l_l1_ = l1ll1l1l_l1_(url)
	elif mode==247: l11l_l1_ = l11ll111_l1_(url)
	elif mode==248: l11l_l1_ = l11l11l1_l1_()
	elif mode==249: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l11l1_l1_():
	l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ੟"),l1111_l1_ (u"ࠪࠫ੠"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ੡"),l1111_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢࠥว่๎วๆࠢส่ัี๊ะࠤࠣๅ๏ࠦศฺุࠣห้ษอ๋ษ้ࠤๆ๐็่๋ࠡ฽๋ࠥๆࠡษ็ััฮࠠืัࠣห้ฮัศ็ฯࠤ࠳่่ࠦาสࠤ๏ูศษุ่่๊ࠢษࠡใํࠤฯฺฺ๋ๆࠣห้็๊ะ์๋๋ฬะࠠ࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠิสห๋ฬࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋๋๋ࠢ๏ࠦสู้ิࠤํะฮหใํࠤอ฻่าหࠣ฽ู๎วว์ฬࠫ੢"))
	return
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ੣"),l1ll11l_l1_,l1111_l1_ (u"ࠧࠨ੤"),headers,l1111_l1_ (u"ࠨࠩ੥"),l1111_l1_ (u"ࠩࠪ੦"),l1111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ੧"))
	html = response.content
	l11l1l11_l1_ = re.findall(l1111_l1_ (u"ࠫ࡭ࡵ࡭ࡦ࠯ࡶ࡭ࡹ࡫࠭ࡣࡶࡱ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੨"),html,re.DOTALL)
	if l11l1l11_l1_: l11l1l11_l1_ = l11l1l11_l1_[0]
	else: l11l1l11_l1_ = l1ll11l_l1_
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ੩"),l11l1l11_l1_,l1111_l1_ (u"࠭ࠧ੪"),headers,l1111_l1_ (u"ࠧࠨ੫"),l1111_l1_ (u"ࠨࠩ੬"),l1111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ੭"))
	html = response.content
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ੮"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ੯"),l1111_l1_ (u"ࠬ࠭ੰ"),249,l1111_l1_ (u"࠭ࠧੱ"),l1111_l1_ (u"ࠧࠨੲ"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬੳ"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩੴ"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ੵ"),l1ll11l_l1_,246)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ੶"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ੷"),l1ll11l_l1_,247)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ੸"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ੹"),l1111_l1_ (u"ࠨࠩ੺"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੻"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ੼")+menu_name+l1111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ੽"),l11l1l11_l1_,241,l1111_l1_ (u"ࠬ࠭੾"),l1111_l1_ (u"࠭ࠧ੿"),l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ઀"))
	l111llll_l1_ = re.findall(l1111_l1_ (u"ࠨࡴࡨࡧࡪࡴࡴ࡭ࡻ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧઁ"),html,re.DOTALL)
	l1l111l_l1_ = l111llll_l1_[0]
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩં"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧઃ")+menu_name+l1111_l1_ (u"ࠫศ฼๊โࠢะำ๏ัวࠨ઄"),l1l111l_l1_,241)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪઅ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭આ"),l1111_l1_ (u"ࠧࠨઇ"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡯ࡥ࠱࠹ࠦࡤ࠮ࡨ࡯ࡩࡽࠦࡡ࡭࡫ࡪࡲ࠲࡯ࡴࡦ࡯ࡶ࠱ࡨ࡫࡮ࡵࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨࡪࡸ࠭࡭࡫ࡱ࡯ࠥࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨઈ"),html,re.DOTALL)
	for l1l111l_l1_,name,block in l111l1l_l1_:
		if name in l11ll11_l1_: continue
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩઉ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧઊ")+menu_name+name,l1l111l_l1_,241)
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪઋ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title in l11ll11_l1_: continue
			title = name+l1111_l1_ (u"ࠬࠦࠧઌ")+title
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઍ"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ઎")+menu_name+title,l1l111l_l1_,241)
	return
def l1ll1l1l_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠨࠩએ")):
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠩࠪઐ"),headers,l1111_l1_ (u"ࠪࠫઑ"),l1111_l1_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ઒"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽ࡰࡤࡺࠬઓ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ઔ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title not in l11ll11_l1_:
				title = title+l1111_l1_ (u"ࠧࠡ็ุ๊ๆฯࠧક")
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨખ"),menu_name+title,l1l111l_l1_,245)
		if l1l1lll1_l1_==l1111_l1_ (u"ࠩࠪગ"): l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨઘ"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫઙ"),l1111_l1_ (u"ࠬ࠭ચ"),9999)
	return html
def l11ll111_l1_(l1l1lll1_l1_=l1111_l1_ (u"࠭ࠧછ")):
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠧࠨજ"),headers,l1111_l1_ (u"ࠨࠩઝ"),l1111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪઞ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪટ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫઠ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title not in l11ll11_l1_:
				title = title+l1111_l1_ (u"ࠬࠦๅโๆอีฮ࠭ડ")
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઢ"),menu_name+title,l1l111l_l1_,244)
		if l1l1lll1_l1_==l1111_l1_ (u"ࠧࠨણ"): l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ત"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩથ"),l1111_l1_ (u"ࠪࠫદ"),9999)
	return html
def l1l11l1_l1_(url,type=l1111_l1_ (u"ࠫࠬધ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭ન"),l1111_l1_ (u"࠭ࠧ઩"),url,type)
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠧࠨપ"),headers,True,l1111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫફ"))
	if type==l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫબ"): l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡼ࡯ࡰࡦࡴ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡷࡼ࡯ࡰࡦࡴ࠰ࡦࡺࡺࡴࡰࡰ࠰ࡴࡷ࡫ࡶࠨભ"),html,re.DOTALL)
	else: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡧࡱࡲࡸࡪࡸࠧમ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩય"),block,re.DOTALL)
		if not items:
			items = re.findall(l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬર"),block,re.DOTALL)
		for img,l1l111l_l1_,title in items:
			#if l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ઱") in img: img = img.split(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦࠬલ"))[1]
			if l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫળ") in l1l111l_l1_ or l1111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫ઴") in l1l111l_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫવ"),menu_name+title,l1l111l_l1_,242,img)
			elif l1111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧશ") in l1l111l_l1_:
				l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬષ"),menu_name+title,l1l111l_l1_,243,img)
			elif l1111_l1_ (u"ࠧ࠰ࡩࡤࡱࡪࡹ࠯ࠨસ") not in l1l111l_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧહ"),menu_name+title,l1l111l_l1_,243,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ઺"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ઻"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title==l1111_l1_ (u"ࠫࠫࡲࡳࡢࡳࡸࡳࡀ઼࠭"): title = l1111_l1_ (u"ูࠬวษไฬࠫઽ")
			if title==l1111_l1_ (u"࠭ࠦࡳࡵࡤࡵࡺࡵ࠻ࠨા"): title = l1111_l1_ (u"ࠧๅษะๆฮ࠭િ")
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨી"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨુ")+title,l1l111l_l1_,241)
	return
def l1lll1_l1_(search):
	# l1ll11ll_l1_://l11ll1l1_l1_.l1ll1111_l1_/search?q=%l11ll1ll_l1_%l1ll111l_l1_%l11ll1ll_l1_%l1lll111_l1_%l11ll1ll_l1_%l1l1ll11_l1_
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫૂ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬૃ"): return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"ࠬࠦࠧૄ"),l1111_l1_ (u"࠭ࠥ࠳࠲ࠪૅ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ૆")+l1lll1l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩે"),l1111_l1_ (u"ࠩࠪૈ"),url,l1111_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࡢࡅࡐࡕࡁࡎࠩૉ"))
	l11l_l1_ = l1l11l1_l1_(url)
	return
def l1l11ll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ૊"),l1111_l1_ (u"ࠬ࠭ો"),url,l1111_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࡠࡃࡎ࡛ࡆࡓࠧૌ"))
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠧࠨ્"),headers,True,l1111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭૎"))
	if l1111_l1_ (u"ࠩ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡄࠧ૏") not in html:
		img = xbmc.getInfoLabel(l1111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡏࡣࡰࡰࠪૐ"))
		l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ૑"),menu_name+l1111_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫ૒"),url,243,img)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠳࠴ࠨ૓"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		l1llll11_l1_ = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૔"),block,re.DOTALL)
		for l1l111l_l1_,title,img in l1llll11_l1_:
			#if l1111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ૕") in l1l111l_l1_: continue
			if l1111_l1_ (u"ࠩส่า๊โศฬࠪ૖") in title or l1111_l1_ (u"้ࠪํอำๆࠢสาึ๏ࠧ૗") in title: continue
			if l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭૘") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૙"),menu_name+title,l1l111l_l1_,242,img)
			else: l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ૚"),menu_name+title,l1l111l_l1_,243,img)
	return
def l1lllll_l1_(url):
	#l11l11l1_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l1111_l1_ (u"ࠧࡔ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ૛"), l1111_l1_ (u"ࠨࡹࠪ૜")).write(html)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠩࠪ૝"),headers,True,l1111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ૞"))
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠫࡧࡧࡤࡨࡧ࠰ࡨࡦࡴࡧࡦࡴ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૟"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	l11l11ll_l1_ = re.findall(l1111_l1_ (u"ࠬࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧૠ"),html,re.DOTALL)
	#l11l11ll_l1_ = ([l1111_l1_ (u"࠭ࠧૡ"),l1111_l1_ (u"ࠧࠨૢ")],[l1111_l1_ (u"ࠨࠩૣ"),l1111_l1_ (u"ࠩࠪ૤")])
	l11lll1l_l1_,l11111l_l1_,l1lll11_l1_,l11l1lll_l1_ = [],[],[],[]
	if l11l11ll_l1_:
		l1ll_l1_ = l1111_l1_ (u"ࠪࡱࡵ࠺ࠧ૥")
		for l11l1l1l_l1_,l11l1111_l1_ in l11l11ll_l1_:
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡴࡹࡦࡲࡩࡵࡻࠥࠤ࡮ࡪ࠽ࠣࠩ૦")+l11l1l1l_l1_+l1111_l1_ (u"ࠬࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿࠰࡟ࡷ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ૧"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			l1lll11_l1_.append(block)
			l11l1lll_l1_.append(l11l1111_l1_)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡱࡶࡣ࡯࡭ࡹ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૨"),html,re.DOTALL)
		if not l111l1l_l1_:
			l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ૩"),l1111_l1_ (u"ࠨࠩ૪"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૫"),l1111_l1_ (u"่ࠪฬ๊้ࠦฮาࠤ๊๊แࠡใํำ๏๎ࠠโ์๋ࠣีอࠠศๆิหอ฽ࠧ૬"))
			return
		else:
			block,filename = l111l1l_l1_[0]
			l111l1_l1_ = [l1111_l1_ (u"ࠫࡿ࡯ࡰࠨ૭"),l1111_l1_ (u"ࠬࡸࡡࡳࠩ૮"),l1111_l1_ (u"࠭ࡴࡹࡶࠪ૯"),l1111_l1_ (u"ࠧࡱࡦࡩࠫ૰"),l1111_l1_ (u"ࠨࡪࡷࡱࠬ૱"),l1111_l1_ (u"ࠩࡷࡥࡷ࠭૲"),l1111_l1_ (u"ࠪ࡭ࡸࡵࠧ૳"),l1111_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩ૴")]
			l1ll_l1_ = filename.rsplit(l1111_l1_ (u"ࠬ࠴ࠧ૵"),1)[1].strip(l1111_l1_ (u"࠭ࠠࠨ૶"))
			if l1ll_l1_ in l111l1_l1_:
				l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ૷"),l1111_l1_ (u"ࠨࠩ૸"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬૹ"),l1111_l1_ (u"ࠪห้๋ไโࠢ็๎ุࠦแ๋ัํ์ࠥ๎ไศุࠢ์ฯ࠭ૺ"))
				return
		l1lll11_l1_.append(block)
		l11l1lll_l1_.append(l1111_l1_ (u"ࠫࠬૻ"))
	for i in range(len(l1lll11_l1_)):
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩࡤࡱࡱ࠱࠭࠴ࠪࡀࠫࠥࠫૼ"),l1lll11_l1_[i],re.DOTALL)
		for l1l111l_l1_,l11l111l_l1_ in l11l1ll1_l1_:
			if l1111_l1_ (u"࠭ࡴࡰࡴࡵࡩࡳࡺࠧ૽") in l11l111l_l1_: continue
			#elif l1111_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ૾") in l11l111l_l1_: continue
			elif l1111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ૿") in l11l111l_l1_: type = l1111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ଀")
			elif l1111_l1_ (u"ࠪࡴࡱࡧࡹࠨଁ") in l11l111l_l1_: type = l1111_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪଂ")
			else: type = l1111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ଃ")
			#title = l11l1lll_l1_[i]+l1111_l1_ (u"࠭ࠠๆๆไࠤࠬ଄")+type
			#l11111l_l1_.append(title)
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࠪଅ")+type+l1111_l1_ (u"ࠨࡡࡢࡣࡤ࠭ଆ")+l11l1lll_l1_[i]+l1111_l1_ (u"ࠩࡢࡣࡦࡱࡷࡢ࡯ࠪଇ")
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪࡘࡊ࡙ࡔࠨଈ"),l11111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࡙ࠫࡋࡓࡕࠩଉ"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫଊ"),url)
	return
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨଋ"),l1111_l1_ (u"ࠧࠨଌ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ଍"),l1111_l1_ (u"ࠩࠪ଎"),filter,url)
	l1l1l11l_l1_ = [l1111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࠫଏ"),l1111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ଐ"),l1111_l1_ (u"ࠬࡿࡥࡢࡴࠪ଑"),l1111_l1_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭଒")]
	if l1111_l1_ (u"ࠧࡀࠩଓ") in url: url = url.split(l1111_l1_ (u"ࠨࡁࠪଔ"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠩࡢࡣࡤ࠭କ"),1)
	if filter==l1111_l1_ (u"ࠪࠫଖ"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠫࠬଗ"),l1111_l1_ (u"ࠬ࠭ଘ")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪଙ"))
	if type==l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫଚ"):
		if l1l1l11l_l1_[0]+l1111_l1_ (u"ࠨ࠿ࠪଛ") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠩࡀࠫଜ") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬଝ")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧଞ")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧଟ")+category+l1111_l1_ (u"࠭࠽࠱ࠩଠ")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩଡ"))+l1111_l1_ (u"ࠨࡡࡢࡣࠬଢ")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠩࠩࠫଣ"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠪࡥࡱࡲࠧତ"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠫࡄ࠭ଥ")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ଦ"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨଧ"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠧࠨନ"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨࡣ࡯ࡰࠬ଩"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠩࠪପ"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠪࡃࠬଫ")+l1l11ll1_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫବ"),menu_name+l1111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠧଭ"),l1l1lll_l1_,241,l1111_l1_ (u"࠭ࠧମ"),l1111_l1_ (u"ࠧ࠲ࠩଯ"))
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨର"),menu_name+l1111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ଱")+l11lll11_l1_+l1111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩଲ"),l1l1lll_l1_,241,l1111_l1_ (u"ࠫࠬଳ"),l1111_l1_ (u"ࠬ࠷ࠧ଴"))
		l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫଵ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଶ"),l1111_l1_ (u"ࠨࠩଷ"),9999)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠩࠪସ"),headers,True,l1111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬହ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡁ࡬࡯ࡳ࡯ࠣ࡭ࡩ࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ଺"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠴ࠪࡀࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࡁࠫ଻"),block,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"଼࠭ࠧ"),l1111_l1_ (u"ࠧࠨଽ"),l1111_l1_ (u"ࠨࠩା"),str(l111111_l1_))
	dict = {}
	for l1lll1ll_l1_,name,block in l111111_l1_:
		#name = name.replace(l1111_l1_ (u"ࠩ࠰࠱ࠬି"),l1111_l1_ (u"ࠪࠫୀ"))
		items = re.findall(l1111_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡁࠬ࠳࠰࠿ࠪ࠾ࠪୁ"),block,re.DOTALL)
		if l1111_l1_ (u"ࠬࡃࠧୂ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪୃ"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧୄ")+l1l1l1ll_l1_)
				return
			else:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୅"),menu_name+l1111_l1_ (u"ࠩส่ัฺ๋๊ࠩ୆"),l1l1lll_l1_,241,l1111_l1_ (u"ࠪࠫେ"),l1111_l1_ (u"ࠫ࠶࠭ୈ"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୉"),menu_name+l1111_l1_ (u"࠭วๅฮ่๎฾࠭୊"),l1l1lll_l1_,245,l1111_l1_ (u"ࠧࠨୋ"),l1111_l1_ (u"ࠨࠩୌ"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕ୍ࠪ"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬ୎")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠶ࠧ୏")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧ୐")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠱ࠩ୑")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ୒")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୓"),menu_name+l1111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠤࠬ୔")+name,l1l1lll_l1_,244,l1111_l1_ (u"ࠪࠫ୕"),l1111_l1_ (u"ࠫࠬୖ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧୗ"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if option in l11ll11_l1_: continue
			if l1111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ୘") not in value: value = option
			else: value = re.findall(l1111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୙"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠪ୚")+l1lll1ll_l1_+l1111_l1_ (u"ࠩࡀࠫ୛")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠬଡ଼")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠭ଢ଼")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ୞")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"࠭ࠠ࠻ࠢࠪୟ")#+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠧ࠱ࠩୠ")]
			title = option+l1111_l1_ (u"ࠨࠢ࠽ࠤࠬୡ")+name
			if type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪୢ"): l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪୣ"),menu_name+title,url,244,l1111_l1_ (u"ࠫࠬ୤"),l1111_l1_ (u"ࠬ࠭୥"),l1lll1l1_l1_)		# +l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ୦"))
			elif type==l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ୧") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠨ࠿ࠪ୨") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠩࡤࡰࡱ࠭୩"))
				l11l11_l1_ = url+l1111_l1_ (u"ࠪࡃࠬ୪")+l1l111l1_l1_
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ୫"),menu_name+title,l11l11_l1_,241,l1111_l1_ (u"ࠬ࠭୬"),l1111_l1_ (u"࠭࠱ࠨ୭"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ୮"),menu_name+title,url,245,l1111_l1_ (u"ࠨࠩ୯"),l1111_l1_ (u"ࠩࠪ୰"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫୱ"),l1111_l1_ (u"ࠫࠬ୲"),filters,l1111_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭୳"))
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ୴")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ୵")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࠬ୶")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	#filters = filters.replace(l1111_l1_ (u"ࠩࡀࠪࠬ୷"),l1111_l1_ (u"ࠪࡁ࠵ࠬࠧ୸"))
	filters = filters.strip(l1111_l1_ (u"ࠫࠫ࠭୹"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠬࡃࠧ୺") in filters:
		items = filters.split(l1111_l1_ (u"࠭ࠦࠨ୻"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠧ࠾ࠩ୼"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠨࠩ୽")
	l1ll1lll_l1_ = [l1111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ୾"),l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ୿"),l1111_l1_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ஀"),l1111_l1_ (u"ࠬࡿࡥࡢࡴࠪ஁"),l1111_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨஂ"),l1111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨஃ"),l1111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ஄")]
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠩ࠳ࠫஅ")
		#if l1111_l1_ (u"ࠪࠩࠬஆ") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭இ") and value!=l1111_l1_ (u"ࠬ࠶ࠧஈ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠠࠬࠢࠪஉ")+value
		elif mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪஊ") and value!=l1111_l1_ (u"ࠨ࠲ࠪ஋"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠩࠩࠫ஌")+key+l1111_l1_ (u"ࠪࡁࠬ஍")+value
		elif mode==l1111_l1_ (u"ࠫࡦࡲ࡬ࠨஎ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠬࠧஏ")+key+l1111_l1_ (u"࠭࠽ࠨஐ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠡ࠭ࠣࠫ஑"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠨࠨࠪஒ"))
	#l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠩࡀ࠴ࠬஓ"),l1111_l1_ (u"ࠪࡁࠬஔ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬக"),l1111_l1_ (u"ࠬ࠭஖"),filters,l1111_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ஗"))
	return l1lll11l_l1_
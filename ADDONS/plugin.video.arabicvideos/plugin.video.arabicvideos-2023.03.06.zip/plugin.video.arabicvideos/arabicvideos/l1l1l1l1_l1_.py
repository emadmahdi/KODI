# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࣦࠧ") : l1111_l1_ (u"ࠫࠬࣧ") }
l111_l1_=l1111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧࣨ")
menu_name=l1111_l1_ (u"࠭࡟ࡂࡍࡆࡣࣩࠬ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
#l11l1_l1_ = [l1111_l1_ (u"ࠧโ์็้ࠬ࣪"),l1111_l1_ (u"ࠨๅ็๎อ࠭࣫"),l1111_l1_ (u"ࠩส่฾ืึࠡษ็หุฮฺ่์ࠪ࣬"),l1111_l1_ (u"ุ้ࠪือ๋ห࣭ࠪ"),l1111_l1_ (u"ู๊ࠫัฮ์๊࣮ࠫ"),l1111_l1_ (u"ࠬอฺ็์ฬ࣯ࠫ"),l1111_l1_ (u"࠭วฺๆสࣰ๊ࠬ"),l1111_l1_ (u"ࠧๅไสลࣱࠬ")]
#proxy = l1111_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰࠳࠸࠽࠳࠸࠰࠴࠰࠻࠻࠳࠷࠳࠱࠼࠶࠵࠷࠾ࣲࠧ")
#proxy = l1111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩࣳ")+l11ll11l_l1_[6][1]
#l11ll11_l1_ = [l1111_l1_ (u"ࠪฬึอๅอࠩࣴ"),l1111_l1_ (u"ࠫศู๊ศสࠪࣵ"),l1111_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮࣶ࠭"),l1111_l1_ (u"࠭วๅลฯ๋ืฯࠠศๆ็์า๐ษࠨࣷ"),l1111_l1_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬࣸ"),l1111_l1_ (u"ࠨสิห๊าࠠศๆอู๊๐ๅࠨࣹ"),l1111_l1_ (u"ࠩส่฾อศࠡไอห้ࣺ࠭"),l1111_l1_ (u"ࠪห้฿วษࠢส่่๋ศ๋๊อีࠥࡖࡃࠨࣻ"),l1111_l1_ (u"ࠫฬ๊ศาษ่ะࠬࣼ")]
l11ll11_l1_ = [l1111_l1_ (u"๋ࠬีศำ฼อࠬࣽ")]
def l1111ll_l1_(mode,url,text):
	if   mode==350: l11l_l1_ = l11l111_l1_(url)
	elif mode==351: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==352: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==353: l11l_l1_ = l1lllll_l1_(url)
	elif mode==354: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪࣾ")+text)
	elif mode==355: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧࣿ")+text)
	elif mode==356: l11l_l1_ = l1ll1l1l_l1_(url)
	elif mode==357: l11l_l1_ = l11ll111_l1_(url)
	elif mode==359: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠨࠩऀ")):
	if l1l1lll1_l1_==l1111_l1_ (u"ࠩࠪँ"):
		l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨं"),menu_name+l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩः"),l1111_l1_ (u"ࠬ࠭ऄ"),8)
		l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫअ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧआ"),l1111_l1_ (u"ࠨࠩइ"),9999)
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩई"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪउ"),l1111_l1_ (u"ࠫࠬऊ"),359,l1111_l1_ (u"ࠬ࠭ऋ"),l1111_l1_ (u"࠭ࠧऌ"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫऍ"))
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨऎ"),l1l1lll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ए")+menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ऐ"),l1ll11l_l1_,356)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫऑ"),l1l1lll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩऒ")+menu_name+l1111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩओ"),l1ll11l_l1_,357)
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬऔ"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨक"),l1111_l1_ (u"ࠩࠪख"),9999)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪग"),l1l1lll1_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨघ")+menu_name+l1111_l1_ (u"ࠬอไๆิํำࠬङ"),l1ll11l_l1_,352,l1111_l1_ (u"࠭ࠧच"),l1111_l1_ (u"ࠧࠨछ"),l1111_l1_ (u"ࠨ࡯ࡲࡶࡪ࠭ज"))
	#l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩझ"),l1l1lll1_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧञ")+menu_name+l1111_l1_ (u"ࠫฬ๊วฯสสีࠬट"),l1ll11l_l1_,352,l1111_l1_ (u"ࠬ࠭ठ"),l1111_l1_ (u"࠭ࠧड"),l1111_l1_ (u"ࠧ࡯ࡧࡺࡷࠬढ"))
	html = l111l11_l1_(l1111l1_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠨࠩण"),headers,l1111_l1_ (u"ࠩࠪत"),l1111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧथ"))
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡰࡾ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪद"),html,re.DOTALL)
	if l1l1lll_l1_: l1l1lll_l1_ = l1l1lll_l1_[0]
	else: l1l1lll_l1_ = l1ll11l_l1_
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬध"),l1l1lll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪन")+menu_name+l1111_l1_ (u"ࠧศุํๅࠥำฯ๋อสࠫऩ"),l1l1lll_l1_,351)
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠨࡂ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧप"),html,re.DOTALL)
	if l1l1lll_l1_: l1l1lll_l1_ = l1l1lll_l1_[0]
	else: l1l1lll_l1_ = l1ll11l_l1_
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩफ"),l1l1lll1_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧब")+menu_name+l1111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬभ"),l1l1lll_l1_,351,l1111_l1_ (u"ࠬ࠭म"),l1111_l1_ (u"࠭ࠧय"),l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩर"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠬऱ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡴࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫल"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title not in l11ll11_l1_: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪळ"),menu_name+title,l1l111l_l1_,351)
		if l1l1lll1_l1_==l1111_l1_ (u"ࠫࠬऴ"): l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪव"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭श"),l1111_l1_ (u"ࠧࠨष"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡨ࡯ࡹࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸࠧस"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬह"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			if title not in l11ll11_l1_: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪऺ"),menu_name+title,l1l111l_l1_,351)
	return html
def l1ll1l1l_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠫࠬऻ")):
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"़ࠬ࠭"),headers,l1111_l1_ (u"࠭ࠧऽ"),l1111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫा"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀࡳࡧࡶࠨि"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪी"),l1111_l1_ (u"ࠪࠫु"),l1l111l_l1_,l111l1l_l1_][0])
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫू"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭ृ"),l1111_l1_ (u"࠭ࠧॄ"),l1l111l_l1_,title)
			if title not in l11ll11_l1_:
				title = title+l1111_l1_ (u"ࠧࠡ็ุ๊ๆฯࠧॅ")
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨॆ"),menu_name+title,l1l111l_l1_,355)
		if l1l1lll1_l1_==l1111_l1_ (u"ࠩࠪे"): l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨै"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫॉ"),l1111_l1_ (u"ࠬ࠭ॊ"),9999)
	return html
def l11ll111_l1_(l1l1lll1_l1_=l1111_l1_ (u"࠭ࠧो")):
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠧࠨौ"),headers,l1111_l1_ (u"ࠨ्ࠩ"),l1111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ॎ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪॏ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫॐ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title not in l11ll11_l1_:
				title = title+l1111_l1_ (u"ࠬࠦๅโๆอีฮ࠭॑")
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ॒࠭"),menu_name+title,l1l111l_l1_,354)
		if l1l1lll1_l1_==l1111_l1_ (u"ࠧࠨ॓"): l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭॔"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॕ"),l1111_l1_ (u"ࠪࠫॖ"),9999)
	return html
def l1l11l1_l1_(url,type=l1111_l1_ (u"ࠫࠬॗ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭क़"),l1111_l1_ (u"࠭ࠧख़"),url,type)
	html = l111l11_l1_(l1l111ll_l1_,url,l1111_l1_ (u"ࠧࠨग़"),headers,True,l1111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧज़"))
	if type==l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫड़"): l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡼ࡯ࡰࡦࡴ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡷࡼ࡯ࡰࡦࡴ࠰ࡦࡺࡺࡴࡰࡰ࠰ࡴࡷ࡫ࡶࠨढ़"),html,re.DOTALL)
	else: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡪࡴࡵࡴࡦࡴࠪफ़"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬࡾ࡬ࡪࡰ࡮࠾࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫय़"),block,re.DOTALL)
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧॠ"),l1111_l1_ (u"ࠧࠨॡ"),str(len(block)),url)
		l1lllll1_l1_ = []
		for img,l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			if l1111_l1_ (u"ࠨษ็ั้่ษࠨॢ") in title or l1111_l1_ (u"ࠩส่า๊โ่ࠩॣ") in title:
				l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡡࡪࠫࠨ।"),title,re.DOTALL)
				if l11l11l_l1_:
					title = l1111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ॥") + l11l11l_l1_[0][0]
					if title not in l1lllll1_l1_:
						l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ०"),menu_name+title,l1l111l_l1_,352,img)
						l1lllll1_l1_.append(title)
			elif l1111_l1_ (u"࠭ๅิๆึ่ࠬ१") in title:
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ२"),menu_name+title,l1l111l_l1_,352,img)
			else: l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ३"),menu_name+title,l1l111l_l1_,353,img)
			#if l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ४") in l1l111l_l1_ or l1111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫ५") in l1l111l_l1_:
			#	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ६"),menu_name+title,l1l111l_l1_,352,img)
			#elif l1111_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩ७") not in l1l111l_l1_ and l1111_l1_ (u"࠭࠯ࡨࡣࡰࡩࡸ࠵ࠧ८") not in l1l111l_l1_:
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ९"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ॰"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#if l1111_l1_ (u"ࠩࠩࡰࡸࡧࡱࡶࡱ࠾ࠫॱ") in title: title = l1111_l1_ (u"ูࠪๆำษࠡีสฬ็ฯࠧॲ")
			#if l1111_l1_ (u"ࠫࠫࡸࡳࡢࡳࡸࡳࡀ࠭ॳ") in title: title = l1111_l1_ (u"ࠬ฻แฮห่ࠣฬำโสࠩॴ")
			#if l1111_l1_ (u"࠭ࠦ࡭ࡣࡴࡹࡴ࠭ॵ") in title: title = l1111_l1_ (u"ࠧศๆุๅาฯࠠศๆอห้๐ษࠨॶ")
			#if l1111_l1_ (u"ࠨืไัฮ࠭ॷ") not in title: title = l1111_l1_ (u"ุࠩๅาฯࠠࠨॸ")+title
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			title = l1l1111_l1_(title)
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪॹ"),menu_name+l1111_l1_ (u"ฺࠫ็อสࠢࠪॺ")+title,l1l111l_l1_,351)
	return
def l1lll1_l1_(search):
	# l1ll11ll_l1_://l11ll1l1_l1_.l1ll1111_l1_/search?q=%l11ll1ll_l1_%l1ll111l_l1_%l11ll1ll_l1_%l1lll111_l1_%l11ll1ll_l1_%l1l1ll11_l1_
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠬ࠭ॻ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"࠭ࠧॼ"): return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"ࠧࠡࠩॽ"),l1111_l1_ (u"ࠨ࠭ࠪॾ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧॿ")+l1lll1l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫঀ"),l1111_l1_ (u"ࠫࠬঁ"),url,l1111_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࡤࡇࡋࡐࡃࡐࠫং"))
	l11l_l1_ = l1l11l1_l1_(url)
	return
def l1l11ll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧঃ"),l1111_l1_ (u"ࠧࠨ঄"),url,l1111_l1_ (u"ࠨࡇࡓࡍࡘࡕࡄࡆࡕࡢࡅࡐ࡝ࡁࡎࠩঅ"))
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠩࠪআ"),headers,True,l1111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫই"))
	#if l1111_l1_ (u"ࠫ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠧঈ") not in html:
	#	img = xbmc.getInfoLabel(l1111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬউ"))
	#	l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬঊ"),menu_name+l1111_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭ঋ"),url,353,img)
	#else:
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡶࡨࡼࡹ࠳ࡷࡩ࡫ࡷࡩࠧࡄวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭ࡁ࡮ࡥࡢࡦࡨࡶࠬঌ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l1llll11_l1_ = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ঍"),block,re.DOTALL)
		for l1l111l_l1_,img,title in l1llll11_l1_:
			if l1111_l1_ (u"ࠪห้ำไใหࠪ঎") in title or l1111_l1_ (u"ࠫฬ๊อๅไ๊ࠫএ") in title: l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫঐ"),menu_name+title,l1l111l_l1_,353,img)
			#else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭঑"),menu_name+title,l1l111l_l1_,352,img)
	else:
		img = xbmc.getInfoLabel(l1111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ঒"))
		if html.count(l1111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠩও"))>1: title = re.findall(l1111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩঔ"),html,re.DOTALL)[1]
		else: title = l1111_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩক")
		l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪখ"),menu_name+title,url,353,img)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_,l11111l_l1_ = [],[]
	l1llll1l_l1_ = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩগ"),url,l1111_l1_ (u"࠭ࠧঘ"),l1111_l1_ (u"ࠧࠨঙ"),l1111_l1_ (u"ࠨࠩচ"),l1111_l1_ (u"ࠩࠪছ"),l1111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧজ"))
	html = l1llll1l_l1_.content
	l11lllll_l1_ = re.findall(l1111_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬঝ"),html,re.DOTALL)
	if l11lllll_l1_:
		l11lllll_l1_ = l11lllll_l1_[0]
		headers = {l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩঞ"):l1111_l1_ (u"࠭ࠧট"),l1111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ঠ"):l1111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧড")}
		data = {l1111_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪঢ"):l11lllll_l1_}
		l1l1lll_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡣࡩࡰࡦࡳ࠸࡬࡭࡮࠳ࡎࡴࡣ࠰ࡃ࡭ࡥࡽ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡗࡢࡶࡦ࡬࠳ࡶࡨࡱࠩণ")
		l1l11l1l_l1_ = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩত"),l1l1lll_l1_,data,headers,l1111_l1_ (u"ࠬ࠭থ"),l1111_l1_ (u"࠭ࠧদ"),l1111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫধ"))
		l11llll1_l1_ = l1l11l1l_l1_.content
		items = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨন"),l11llll1_l1_,re.DOTALL)
		for l1l1111l_l1_,name in items:
			#data = {l1111_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ঩"):l11lllll_l1_,l1111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪপ"):l1l1111l_l1_}
			l1l111l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩফ")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅࡰࡰࡵࡷ࡭ࡩࡃࠧব")+l11lllll_l1_+l1111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪভ")+l1l1111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨম")+name+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩয")
			l11lll1l_l1_.append(l1l111l_l1_)
			l11111l_l1_.append(name)
		l1l1lll_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴ࡊ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡪࡳࠫর")
		l1l11l1l_l1_ = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ঱"),l1l1lll_l1_,data,headers,l1111_l1_ (u"ࠫࠬল"),l1111_l1_ (u"ࠬ࠭঳"),l1111_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ঴"))
		l11llll1_l1_ = l1l11l1l_l1_.content
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ঵"),l11llll1_l1_,re.DOTALL)
		for l1l111l_l1_,title in items:
			#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩশ"),l1111_l1_ (u"ࠩࠪষ"),l1l111l_l1_,title)
			l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠪࠤࠬস"))
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬহ")+title+l1111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ঺")
			l11lll1l_l1_.append(l1l111l_l1_)
			l11111l_l1_.append(title)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ঻"),url)
	return
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠ়ࠩ"),l1111_l1_ (u"ࠨࠩঽ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪা"),l1111_l1_ (u"ࠪࠫি"),filter,url)
	l1l1l11l_l1_ = [l1111_l1_ (u"ࠫࡨࡧࡴࠨী"),l1111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫু"),l1111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬূ"),l1111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨৃ"),l1111_l1_ (u"ࠨࡱࡵࡨࡪࡸࡢࡺࠩৄ")]
	if l1111_l1_ (u"ࠩࡂࠫ৅") in url: url = url.split(l1111_l1_ (u"ࠪࡃࠬ৆"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠫࡤࡥ࡟ࠨে"),1)
	if filter==l1111_l1_ (u"ࠬ࠭ৈ"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"࠭ࠧ৉"),l1111_l1_ (u"ࠧࠨ৊")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠨࡡࡢࡣࠬো"))
	if type==l1111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ৌ"):
		if l1l1l11l_l1_[0]+l1111_l1_ (u"ࠪࡁ্ࠬ") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠫࡂ࠭ৎ") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠬࠬࠧ৏")+category+l1111_l1_ (u"࠭࠽࠱ࠩ৐")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠧࠧࠩ৑")+category+l1111_l1_ (u"ࠨ࠿࠳ࠫ৒")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠩࠩࠫ৓"))+l1111_l1_ (u"ࠪࡣࡤࡥࠧ৔")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠫࠫ࠭৕"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠬࡧ࡬࡭ࠩ৖"))
		l1l1lll_l1_ = url+l1111_l1_ (u"࠭࠿ࠨৗ")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ৘"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ৙"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠩࠪ৚"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠪࡥࡱࡲࠧ৛"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠫࠬড়"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠬࡅࠧঢ়")+l1l11ll1_l1_
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭৞"),menu_name+l1111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠩয়"),l1l1lll_l1_,351,l1111_l1_ (u"ࠨࠩৠ"),l1111_l1_ (u"ࠩ࠴ࠫৡ"))
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪৢ"),menu_name+l1111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫৣ")+l11lll11_l1_+l1111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ৤"),l1l1lll_l1_,351,l1111_l1_ (u"࠭ࠧ৥"),l1111_l1_ (u"ࠧ࠲ࠩ০"))
		l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭১"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ২"),l1111_l1_ (u"ࠪࠫ৩"),9999)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠫࠬ৪"),headers,True,l1111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ৫"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࠼ࡧࡱࡵࡱࠥ࡯ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭৬"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴ࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭৭"),block,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ৮"),l1111_l1_ (u"ࠩࠪ৯"),l1111_l1_ (u"ࠪࠫৰ"),str(l111111_l1_))
	dict = {}
	for l1lll1ll_l1_,name,block in l111111_l1_:
		#name = name.replace(l1111_l1_ (u"ࠫ࠲࠳ࠧৱ"),l1111_l1_ (u"ࠬ࠭৲"))
		items = re.findall(l1111_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡃ࠮࠮ࠫࡁࠬࡀࠬ৳"),block,re.DOTALL)
		if l1111_l1_ (u"ࠧ࠾ࠩ৴") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ৵"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ৶")+l1l1l1ll_l1_)
				return
			else:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ৷"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ৸"),l1l1lll_l1_,351,l1111_l1_ (u"ࠬ࠭৹"),l1111_l1_ (u"࠭࠱ࠨ৺"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ৻"),menu_name+l1111_l1_ (u"ࠨษ็ะ๊๐ูࠨৼ"),l1l1lll_l1_,355,l1111_l1_ (u"ࠩࠪ৽"),l1111_l1_ (u"ࠪࠫ৾"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ৿"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠬࠬࠧ਀")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠱ࠩਁ")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠧࠧࠩਂ")+l1lll1ll_l1_+l1111_l1_ (u"ࠨ࠿࠳ࠫਃ")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭਄")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪਅ"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿ࠦࠧਆ")+name,l1l1lll_l1_,354,l1111_l1_ (u"ࠬ࠭ਇ"),l1111_l1_ (u"࠭ࠧਈ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩਉ"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if option in l11ll11_l1_: continue
			if l1111_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧਊ") not in value: value = option
			else: value = re.findall(l1111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ਋"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬ਌")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠭਍")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧ਎")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽ࠨਏ")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫਐ")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"ࠨࠢ࠽ࠤࠬ਑")#+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠩ࠳ࠫ਒")]
			title = option+l1111_l1_ (u"ࠪࠤ࠿ࠦࠧਓ")+name
			if type==l1111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬਔ"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਕ"),menu_name+title,url,354,l1111_l1_ (u"࠭ࠧਖ"),l1111_l1_ (u"ࠧࠨਗ"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪਘ"))
			elif type==l1111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ਙ") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠪࡁࠬਚ") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠫࡦࡲ࡬ࠨਛ"))
				l11l11_l1_ = url+l1111_l1_ (u"ࠬࡅࠧਜ")+l1l111l1_l1_
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਝ"),menu_name+title,l11l11_l1_,351,l1111_l1_ (u"ࠧࠨਞ"),l1111_l1_ (u"ࠨ࠳ࠪਟ"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਠ"),menu_name+title,url,355,l1111_l1_ (u"ࠪࠫਡ"),l1111_l1_ (u"ࠫࠬਢ"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭ਣ"),l1111_l1_ (u"࠭ࠧਤ"),filters,l1111_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠷࠱ࠨਥ"))
	# mode==l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪਦ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬਧ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠪࡥࡱࡲࠧਨ")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	#filters = filters.replace(l1111_l1_ (u"ࠫࡂࠬࠧ਩"),l1111_l1_ (u"ࠬࡃ࠰ࠧࠩਪ"))
	filters = filters.strip(l1111_l1_ (u"࠭ࠦࠨਫ"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠧ࠾ࠩਬ") in filters:
		items = filters.split(l1111_l1_ (u"ࠨࠨࠪਭ"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠩࡀࠫਮ"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠪࠫਯ")
	l1ll1lll_l1_ = [l1111_l1_ (u"ࠫࡨࡧࡴࠨਰ"),l1111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ਱"),l1111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬਲ"),l1111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨਲ਼"),l1111_l1_ (u"ࠨࡱࡵࡨࡪࡸࡢࡺࠩ਴")]
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠩ࠳ࠫਵ")
		#if l1111_l1_ (u"ࠪࠩࠬਸ਼") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭਷") and value!=l1111_l1_ (u"ࠬ࠶ࠧਸ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠠࠬࠢࠪਹ")+value
		elif mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ਺") and value!=l1111_l1_ (u"ࠨ࠲ࠪ਻"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"਼ࠩࠩࠫ")+key+l1111_l1_ (u"ࠪࡁࠬ਽")+value
		elif mode==l1111_l1_ (u"ࠫࡦࡲ࡬ࠨਾ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠬࠧਿ")+key+l1111_l1_ (u"࠭࠽ࠨੀ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠡ࠭ࠣࠫੁ"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠨࠨࠪੂ"))
	#l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠩࡀ࠴ࠬ੃"),l1111_l1_ (u"ࠪࡁࠬ੄"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ੅"),l1111_l1_ (u"ࠬ࠭੆"),filters,l1111_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧੇ"))
	return l1lll11l_l1_
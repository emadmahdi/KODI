# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ䱈")
headers = { l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䱉") : l1111_l1_ (u"ࠧࠨ䱊") }
menu_name=l1111_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧ䱋")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ䱌"),l1111_l1_ (u"ࠪห้้ไࠨ䱍"),l1111_l1_ (u"ࠫฬ็ไศ็ࠪ䱎"),l1111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ䱏")]
def l1111ll_l1_(mode,url,text):
	if   mode==110: l11l_l1_ = l11l111_l1_()
	elif mode==111: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==112: l11l_l1_ = l1lllll_l1_(url)
	elif mode==113: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==114: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ䱐")+text)
	elif mode==115: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ䱑")+text)
	elif mode==119: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䱒"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪ䱓"),headers,l1111_l1_ (u"ࠪࠫ䱔"),l1111_l1_ (u"ࠫࠬ䱕"),l1111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䱖"))
	#if not response.succeeded:
	#	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䱗"),menu_name+l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䱘"),l1111_l1_ (u"ࠨࠩ䱙"),8)
	#	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䱚"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䱛"),l1111_l1_ (u"ࠫࠬ䱜"),9999)
	#	return
	html = response.content
	l11l1l11_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡࡲࡤ࡫ࡪ࠳ࡣࡰࡰࡷࡩࡳࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱝"),html,re.DOTALL)
	if not l11l1l11_l1_: l11l1l11_l1_ = re.findall(l1111_l1_ (u"࠭ࡨࡰ࡯ࡨ࠱ࡸ࡯ࡴࡦ࠯ࡥࡸࡳ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱞"),html,re.DOTALL)
	if not l11l1l11_l1_: l11l1l11_l1_ = re.findall(l1111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲࡮ࡥࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱟"),html,re.DOTALL)
	l11l1l11_l1_ = l11l1l11_l1_[0].strip(l1111_l1_ (u"ࠨ࠱ࠪ䱠"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l11l1l11_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭䱡"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䱢"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䱣"),l1111_l1_ (u"ࠬ࠭䱤"),119,l1111_l1_ (u"࠭ࠧ䱥"),l1111_l1_ (u"ࠧࠨ䱦"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䱧"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䱨"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭䱩"),l11l1l11_l1_,115)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䱪"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ䱫"),l11l1l11_l1_,114)
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱬"),menu_name+l1111_l1_ (u"ࠧโๆอีࠬ䱭"),l1111_l1_ (u"ࠨࠩ䱮"),114,l1llll1lll_l1_)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䱯"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䱰"),l1111_l1_ (u"ࠫࠬ䱱"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䱲"),l11l1l11_l1_,l1111_l1_ (u"࠭ࠧ䱳"),headers,l1111_l1_ (u"ࠧࠨ䱴"),l1111_l1_ (u"ࠨࠩ䱵"),l1111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䱶"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭ࡵࡣࡥࡷ࠭࠴ࠪࡀࠫࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ䱷"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡪࡩࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䱸"),block,re.DOTALL)
	for filter,title in items:
		url = l1llll1lll_l1_+l1111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡗ࡭ࡧࡨࡪࡦ࠷ࡹ࠴ࡇࡪࡢࡺࡤࡸ࠴ࡎ࡯࡮ࡧ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬ࡎ࡯࡮ࡧ࠱ࡴ࡭ࡶࠧ䱹")
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱺"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ䱻")+menu_name+title,url,111,l1111_l1_ (u"ࠨࠩ䱼"),l1111_l1_ (u"ࠩࠪ䱽"),filter)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䱾"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䱿"),l1111_l1_ (u"ࠬ࠭䲀"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䲁"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䲂"),block,re.DOTALL)
	#l111l1ll1_l1_ = [l1111_l1_ (u"ࠨ็ึุ่๊วหࠢࠪ䲃"),l1111_l1_ (u"ࠩสๅ้อๅࠡࠩ䲄"),l1111_l1_ (u"ࠪฬึอๅอࠩ䲅"),l1111_l1_ (u"ࠫ฾ื่ืࠩ䲆"),l1111_l1_ (u"้ࠬไ๋สสฮࠬ䲇"),l1111_l1_ (u"࠭ว฻ษ้ํࠬ䲈")]
	#if l1111_l1_ (u"ࠧศใ็หู๊ࠦาสํࠫ䲉") not in str(items):
	#	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䲊"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭䲋")+menu_name+l1111_l1_ (u"ࠪหๆ๊วๆࠢ฼ีอ๐ࠧ䲌"),l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศใ็ห๊࠳ูาสํ࠱࠶࠭䲍"),111)
	for l1l111l_l1_,title in items:
		if title in l11ll11_l1_: continue
		if l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䲎") not in l1l111l_l1_: l1l111l_l1_ = l1llll1lll_l1_+l1l111l_l1_
		l1111_l1_ (u"ࠨࠢࠣࠌࠌࠍ࡮࡬ࠠࠨࠧࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬํࠧ࠭ࠩฬࠫ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ์ࠫ࠱๊࠭ࠨࠫࠍࠍࠎࠨࠢࠣ䲏")
		title = title.strip(l1111_l1_ (u"ࠧࠡࠩ䲐"))
		#if not any(value in title for value in l11ll11_l1_):
		#	if any(value in title for value in l111l1ll1_l1_):
		if l1111_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ䲑") in l1l111l_l1_: title = l1111_l1_ (u"้ࠩ๎ฯ็ไไีࠪ䲒")
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲓"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ䲔")+menu_name+title,l1l111l_l1_,111)
	return html
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠬ࠭䲕")):
	if l1111_l1_ (u"࠭࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡖ࡬ࡴࡽࡳ࠯ࡲ࡫ࡴࡄ࠭䲖") in url:
		url,data = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䲗"):l1111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䲘"),l1111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䲙"):l1111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䲚")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䲛"),url,data,l1l1lll11_l1_,l1111_l1_ (u"ࠬ࠭䲜"),l1111_l1_ (u"࠭ࠧ䲝"),l1111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䲞"))
		html = response.content
		block = html
	elif l1111_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ䲟") in url:
		data = {l1111_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ䲠"):l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡧࡲ࡯ࡤ࡭ࠪ䲡"),l1111_l1_ (u"ࠫࡰ࡫ࡹࠨ䲢"):l11111l1l_l1_}
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䲣"):l1111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䲤")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䲥"),url,data,l1l1lll11_l1_,l1111_l1_ (u"ࠨࠩ䲦"),l1111_l1_ (u"ࠩࠪ䲧"),l1111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ䲨"))
		html = response.content
		block = html
	else:
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䲩"):l1111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䲪")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ䲫"),url,l1111_l1_ (u"ࠧࠨ䲬"),l1l1lll11_l1_,l1111_l1_ (u"ࠨࠩ䲭"),l1111_l1_ (u"ࠩࠪ䲮"),l1111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ䲯"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡵࡣࡪࡷ࠲ࡩ࡬ࡰࡷࡧࠫ䲰"),html,re.DOTALL)
		if not l111l1l_l1_: return
		block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䲱"),block,re.DOTALL)
	#if not items: items = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲲"),block,re.DOTALL)
	#if l1111_l1_ (u"ࠧࡱࡣࡪࡩࠬ䲳") not in url: items = re.findall(l1111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䲴"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ุ่ࠩฬํฯสࠩ䲵"),l1111_l1_ (u"ࠪๅ๏๊ๅࠨ䲶"),l1111_l1_ (u"ࠫฬเๆ๋หࠪ䲷"),l1111_l1_ (u"้ࠬไ๋สࠪ䲸"),l1111_l1_ (u"࠭วฺๆส๊ࠬ䲹"),l1111_l1_ (u"่ࠧัสๅࠬ䲺"),l1111_l1_ (u"ࠨ็หหึอษࠨ䲻"),l1111_l1_ (u"ࠩ฼ี฻࠭䲼"),l1111_l1_ (u"้ࠪ์ืฬศ่ࠪ䲽"),l1111_l1_ (u"ࠫฬ๊ศ้็ࠪ䲾")]
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ䲿") in l1l111l_l1_: continue
		#if l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䳀") in l1l111l_l1_: continue
		#l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠧࠧࠥ࠳࠷࠽ࡁࠧ䳁"),l1111_l1_ (u"ࠨࠨࠪ䳂"))
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠩ࠲ࠫ䳃"))
		title = l1l1111_l1_(title)
		title = title.strip(l1111_l1_ (u"ࠪࠤࠬ䳄"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ䳅"),title,re.DOTALL)
		if l1111_l1_ (u"ࠬ็๊ๅ็ࠪ䳆") in l1l111l_l1_ or any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䳇"),menu_name+title,l1l111l_l1_,112,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠧศๆะ่็ฯࠧ䳈") in title and l1111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ䳉") not in url:
			title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䳊") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳋"),menu_name+title,l1l111l_l1_,113,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵ࠳ࠬ䳌") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳍"),menu_name+title,l1l111l_l1_,111,img)
		elif l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䳎") in l1l111l_l1_ and l1111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭䳏") not in url:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ䳐")
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳑"),menu_name+title,l1l111l_l1_,111,img)
		elif l1111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䳒") in url and l1111_l1_ (u"ࠫา๊โสࠩ䳓") in title:
			l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䳔"),menu_name+title,l1l111l_l1_,112,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳕"),menu_name+title,l1l111l_l1_,113,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭䳖"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䳗"),block,re.DOTALL)
		if not items: items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䳘"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠪห้฻แฮหࠣࠫ䳙"),l1111_l1_ (u"ࠫࠬ䳚"))
			if title!=l1111_l1_ (u"ࠬ࠭䳛"): l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳜"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭䳝")+title,l1l111l_l1_,111)
	l1111111l_l1_ = re.findall(l1111_l1_ (u"ࠨࡵ࡫ࡳࡼࡳ࡯ࡳࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䳞"),html,re.DOTALL)
	if l1111111l_l1_:
		l1l111l_l1_ = l1111111l_l1_[0]
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳟"),menu_name+l1111_l1_ (u"ู้ࠪอ็ะหࠣห้๋า๋ัࠪ䳠"),l1l111l_l1_,111)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䳡"),url,l1111_l1_ (u"ࠬ࠭䳢"),headers,l1111_l1_ (u"࠭ࠧ䳣"),l1111_l1_ (u"ࠧࠨ䳤"),l1111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䳥"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࠤ࡮ࡪ࠽ࠣࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩࡵࡣࡪࡷ࠲ࡩ࡬ࡰࡷࡧࠫ䳦"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭䳧"),html,re.DOTALL)
	items = []
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䳨") not in url:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䳩"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			title = title.strip(l1111_l1_ (u"࠭ࠠࠨ䳪"))
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䳫"),menu_name+title,l1l111l_l1_,113,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭࡜ࡣ࠰ࡾࡢ࠱࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳬"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			title = title.strip(l1111_l1_ (u"ࠩࠣࠫ䳭"))
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䳮"),menu_name+title,l1l111l_l1_,112,img)
	# l1llll11_l1_ l11l1l1l_l1_
	if not items and l1111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ䳯") in html:
		l1l11ll1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡲࡦࡣࡧࡧࡷࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䳰"),html,re.DOTALL)
		if l1l11ll1l_l1_:
			block = l1l11ll1l_l1_[0]
			l11l1ll1_l1_ = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䳱"),block,re.DOTALL)
			if len(l11l1ll1_l1_)>2:
				l1l111l_l1_ = l11l1ll1_l1_[2]+l1111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䳲")
				l1l11l1_l1_(l1l111l_l1_)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	l1llllll1_l1_ = url.strip(l1111_l1_ (u"ࠨ࠱ࠪ䳳"))
	hostname = l1l1lll1l_l1_(l1llllll1_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭䳴"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䳵"),l1llllll1_l1_,l1111_l1_ (u"ࠫࠬ䳶"),headers,l1111_l1_ (u"ࠬ࠭䳷"),l1111_l1_ (u"࠭ࠧ䳸"),l1111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䳹"))
	html = response.content#.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䳺"))
	id = re.findall(l1111_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䳻"),html,re.DOTALL)
	if not id: id = re.findall(l1111_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫ䳼"),html,re.DOTALL)
	if not id: id = re.findall(l1111_l1_ (u"ࠫࡵࡵࡳࡵ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䳽"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l1111_l1_ (u"ࠬ࠭䳾")
	#else: l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䳿"),l1111_l1_ (u"ࠧࠨ䴀"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䴁"),l1111_l1_ (u"ࠩํีั๏ࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ้๋ࠢࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭䴂"))
	if True or l1111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ䴃") in html:
		#parts = url.split(l1111_l1_ (u"ࠫ࠴࠭䴄"))
		#l1l1lll_l1_ = url.replace(parts[3],l1111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䴅"))
		l1l1lll_l1_ = l1llllll1_l1_+l1111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠭䴆")
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ䴇"),l1l1lll_l1_,l1111_l1_ (u"ࠨࠩ䴈"),headers,l1111_l1_ (u"ࠩࠪ䴉"),l1111_l1_ (u"ࠪࠫ䴊"),l1111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ䴋"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䴌"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䴍"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		if l111l1l_l1_: l111ll1l_l1_ = l111l1l_l1_[0]
		else: l111ll1l_l1_ = l11llll1_l1_
		if not id:
			id = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࠽ࠣ࠲ࠥࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䴎"),l111ll1l_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l1111_l1_ (u"ࠨࠩ䴏")
		l111l111l_l1_ = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴐"),l11llll1_l1_,re.DOTALL)
		l11l1ll11_l1_ = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ䴑"),l11llll1_l1_,re.DOTALL)
		l111l11l1_l1_ = re.findall(l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䴒"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡡࡴࠪ࠯ࠬࡂࡷࡪࡸࡶࡦࡴࡢ࡭ࡲࡧࡧࡦࠤࡁࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭䴓"),l11llll1_l1_)
		l1111lll1_l1_ = re.findall(l1111_l1_ (u"࠭ࡳࡳࡥࡀࠪࡶࡻ࡯ࡵ࠽ࠫ࠲࠯ࡅࠩࠧࡳࡸࡳࡹࡁ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䴔"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		l111l1111_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴕"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		l111l1111111_l1_ = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䴖"),l111ll1l_l1_,re.DOTALL|re.IGNORECASE)
		l111l11111ll_l1_ = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭䴗"),l111ll1l_l1_,re.DOTALL|re.IGNORECASE)
		items = l111l111l_l1_+l11l1ll11_l1_+l111l11l1_l1_+l1111llll_l1_+l1111lll1_l1_+l111l1111_l1_+l111l1111111_l1_+l111l11111ll_l1_
		if not items:
			items = re.findall(l1111_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴘"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.strip(l1111_l1_ (u"ࠫࡡࡴࠧ䴙")).strip(l1111_l1_ (u"ࠬࠦࠧ䴚"))
			if l1111_l1_ (u"࠭࠮ࡱࡰࡪࠫ䴛") in server: continue
			if l1111_l1_ (u"ࠧ࠯࡬ࡳ࡫ࠬ䴜") in server: continue
			if l1111_l1_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨ䴝") in server: continue
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ䴞"),title,re.DOTALL)
			if l11l1111_l1_:
				l11l1111_l1_ = l11l1111_l1_[0]
				if l11l1111_l1_ in title: title = title.replace(l11l1111_l1_+l1111_l1_ (u"ࠪࡴࠬ䴟"),l1111_l1_ (u"ࠫࠬ䴠")).replace(l11l1111_l1_,l1111_l1_ (u"ࠬ࠭䴡")).strip(l1111_l1_ (u"࠭ࠠࠨ䴢"))
				l11l1111_l1_ = l1111_l1_ (u"ࠧࡠࡡࡢࡣࠬ䴣")+l11l1111_l1_
			else: l11l1111_l1_ = l1111_l1_ (u"ࠨࠩ䴤")
			if server.isdigit(): l1l111l_l1_ = hostname+l1111_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ䴥")+id+l1111_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ䴦")+server+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䴧")+title+l1111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䴨")+l11l1111_l1_
			else:
				if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䴩") not in server: server = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䴪")+server
				l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䴫"),title,re.DOTALL)
				if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"ࠩࡢࡣࡤࡥࠧ䴬")+l11l1111_l1_[0]
				else: l11l1111_l1_ = l1111_l1_ (u"ࠪࠫ䴭")
				l1l111l_l1_ = server+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬ䴮")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䴯"),l11lll1l_l1_)
	#l11lll1l_l1_ = []
	if l1111_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡅ࡫ࡹࠫ䴰") in html:
		l1l1lll_l1_ = l1llllll1_l1_+l1111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䴱")
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䴲"),l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ䴳"),headers,l1111_l1_ (u"ࠪࠫ䴴"),l1111_l1_ (u"ࠫࠬ䴵"),l1111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ䴶"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䴷"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ䴸"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		if l111l1l_l1_: l111ll1l_l1_ = l111l1l_l1_[0]
		else: l111ll1l_l1_ = l11llll1_l1_
		l1lll11_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾࡫࠷࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䴹"),l111ll1l_l1_,re.DOTALL)
		for title,block in l1lll11_l1_:
			title = title.strip(l1111_l1_ (u"ࠩࠣࠫ䴺"))
			items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴻"),block,re.DOTALL)
			for l1l111l_l1_,name,l11l1111_l1_ in items:
				l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠫࡡࡪࠫࠨ䴼"),l11l1111_l1_,re.DOTALL)
				if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䴽")+l11l1111_l1_[0]
				else:
					l11l1111_l1_ = re.findall(l1111_l1_ (u"࠭࡜ࡥ࠭ࠪ䴾"),title,re.DOTALL)
					if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"ࠧࡠࡡࡢࡣࠬ䴿")+l11l1111_l1_[0]
					else: l11l1111_l1_ = l1111_l1_ (u"ࠨࠩ䵀")
				l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䵁")+name+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䵂")+l11l1111_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
		if not l1lll11_l1_:
			l1l1lll_l1_ = hostname +l1111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡖ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪ䵃")
			l1l1lll11_l1_ = {l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䵄"):l1111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䵅")}
			l11lll1ll_l1_ = {l1111_l1_ (u"ࠧࡪࡦࠪ䵆"):id}
			response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䵇"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠩࠪ䵈"),l1111_l1_ (u"ࠪࠫ䵉"),l1111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䵊"))
			l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䵋"))
			items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䵌"),l11llll1_l1_,re.DOTALL)
			for l1l111l_l1_,name,l11l1111_l1_ in items:
				l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䵍")+name+l1111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䵎")+l1111_l1_ (u"ࠩࡢࡣࡤࡥࠧ䵏")+l11l1111_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䵐"),l11lll1l_l1_)
	elif l1111_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࡔ࡯ࡸࠩ䵑") in html:
		l1l1lll11_l1_ = { l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䵒"):l1111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䵓") }
		l1l1lll_l1_ = l1llllll1_l1_.replace(parts[3],l1111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䵔"))
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䵕"),l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ䵖"),l1l1lll11_l1_,l1111_l1_ (u"ࠪࠫ䵗"),l1111_l1_ (u"ࠫࠬ䵘"),l1111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ䵙"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䵚"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠳ࡩࡵࡧࡰࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䵛"),l11llll1_l1_,re.DOTALL)
		for block in l111l1l_l1_:
			items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䵜"),block,re.DOTALL)
			for l1l111l_l1_,name,l11l1111_l1_ in items:
				l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䵝")+name+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䵞")+l1111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ䵟")+l11l1111_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
	elif l1111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ䵠") in html:
		l1l1lll11_l1_ = { l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䵡"):l1111_l1_ (u"ࠧࠨ䵢") , l1111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䵣"):l1111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䵤") }
		l1l1lll_l1_ = hostname + l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭䵥")+id
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䵦"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭䵧"),l1l1lll11_l1_,l1111_l1_ (u"࠭ࠧ䵨"),l1111_l1_ (u"ࠧࠨ䵩"),l1111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬ䵪"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䵫"))
		if l1111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲ࡨࡴ࡯ࡵࠪ䵬") in l11llll1_l1_:
			l111l11l1_l1_ = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䵭"),l11llll1_l1_,re.DOTALL)
			for l11l11_l1_ in l111l11l1_l1_:
				if l1111_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ䵮") not in l11l11_l1_ and l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䵯") in l11l11_l1_:
					l11l11_l1_ = l11l11_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䵰")
					l11lll1l_l1_.append(l11l11_l1_)
				elif l1111_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䵱") in l11l11_l1_:
					l11l1111_l1_ = l1111_l1_ (u"ࠩࠪ䵲")
					response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䵳"),l11l11_l1_,l1111_l1_ (u"ࠫࠬ䵴"),headers,l1111_l1_ (u"ࠬ࠭䵵"),l1111_l1_ (u"࠭ࠧ䵶"),l1111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ䵷"))
					l111l1lll_l1_ = response.content#.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䵸"))
					l1lll11_l1_ = re.findall(l1111_l1_ (u"ࠩࠫࡀࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࠪ࠯࠰࠱࠲࠳ࠧ䵹"),l111l1lll_l1_,re.DOTALL)
					for l11l11ll1_l1_ in l1lll11_l1_:
						l111ll11l_l1_ = l1111_l1_ (u"ࠪࠫ䵺")
						l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭䵻"),l11l11ll1_l1_,re.DOTALL)
						for l111lllll_l1_ in l1111llll_l1_:
							item = re.findall(l1111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䵼"),l111lllll_l1_,re.DOTALL)
							if item:
								l11l1111_l1_ = l1111_l1_ (u"࠭࡟ࡠࡡࡢࠫ䵽")+item[0]
								break
						for l111lllll_l1_ in reversed(l1111llll_l1_):
							item = re.findall(l1111_l1_ (u"ࠧ࡝ࡹ࡟ࡻ࠰࠭䵾"),l111lllll_l1_,re.DOTALL)
							if item:
								l111ll11l_l1_ = item[0]
								break
						l1111lll1_l1_ = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䵿"),l11l11ll1_l1_,re.DOTALL)
						for l111lll11_l1_ in l1111lll1_l1_:
							l111lll11_l1_ = l111lll11_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䶀")+l111ll11l_l1_+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䶁")+l11l1111_l1_
							l11lll1l_l1_.append(l111lll11_l1_)
		elif l1111_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠩ䶂") in l11llll1_l1_:
			l11llll1_l1_ = l11llll1_l1_.replace(l1111_l1_ (u"ࠬࡂࡨ࠷ࠢࠪ䶃"),l1111_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠠ࠾࠿ࡖࡘࡆࡘࡔ࠾࠿ࠪ䶄"))+l1111_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠨ䶅")
			l11llll1_l1_ = l11llll1_l1_.replace(l1111_l1_ (u"ࠨ࠾࡫࠷ࠥ࠭䶆"),l1111_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠣࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠭䶇"))+l1111_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠫ䶈")
			l111lll1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡂࡃࡓࡕࡃࡕࡘࡂࡃࠨ࠯ࠬࡂ࠭ࡂࡃࡅࡏࡆࡀࡁࠬ䶉"),l11llll1_l1_,re.DOTALL)
			if l111lll1l_l1_:
				for l11l11ll1_l1_ in l111lll1l_l1_:
					if l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫ䶊") not in l11l11ll1_l1_: continue
					l11l11111_l1_ = l1111_l1_ (u"࠭ࠧ䶋")
					l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠧࡴ࡮ࡲࡻ࠲ࡳ࡯ࡵ࡫ࡲࡲࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䶌"),l11l11ll1_l1_,re.DOTALL)
					for l111lllll_l1_ in l1111llll_l1_:
						item = re.findall(l1111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䶍"),l111lllll_l1_,re.DOTALL)
						if item:
							l11l11111_l1_ = l1111_l1_ (u"ࠩࡢࡣࡤࡥࠧ䶎")+item[0]
							break
					l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ䶏"),l11l11ll1_l1_,re.DOTALL)
					if l1111llll_l1_:
						for l111ll11l_l1_,l111ll1ll_l1_ in l1111llll_l1_:
							l111ll1ll_l1_ = l111ll1ll_l1_+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䶐")+l111ll11l_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䶑")+l11l11111_l1_
							l11lll1l_l1_.append(l111ll1ll_l1_)
					else:
						l1111llll_l1_ = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䶒"),l11l11ll1_l1_,re.DOTALL)
						for l111ll1ll_l1_,l111ll11l_l1_ in l1111llll_l1_:
							l111ll1ll_l1_ = l111ll1ll_l1_.strip(l1111_l1_ (u"ࠧࠡࠩ䶓"))+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䶔")+l111ll11l_l1_+l1111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䶕")+l11l11111_l1_
							l11lll1l_l1_.append(l111ll1ll_l1_)
			else:
				l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࡜ࡸ࠭ࠬࡀࠬ䶖"),l11llll1_l1_,re.DOTALL)
				for l111ll1ll_l1_,l111ll11l_l1_ in l1111llll_l1_:
					l111ll1ll_l1_ = l111ll1ll_l1_.strip(l1111_l1_ (u"ࠫࠥ࠭䶗"))+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䶘")+l111ll11l_l1_+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䶙")
					l11lll1l_l1_.append(l111ll1ll_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䶚"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䶛"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search:
		search = l11ll_l1_()
		if not search: return
	search = search.replace(l1111_l1_ (u"ࠩࠣࠫ䶜"),l1111_l1_ (u"ࠪ࠯ࠬ䶝"))
	if l1ll11_l1_:
		l111ll111_l1_ = [l1111_l1_ (u"ࠫฬ็ไศ็ࠪ䶞"),l1111_l1_ (u"๋ࠬำๅี็หฯ࠭䶟"),l1111_l1_ (u"࠭ๅๆอ็๎๋࠭䶠"),l1111_l1_ (u"ࠧศๆๆ่ࠬ䶡")]
		l1l1lllll_l1_ = [l1111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ䶢"),l1111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䶣"),l1111_l1_ (u"ࠪࡥࡨࡺ࡯ࡳࠩ䶤"),l1111_l1_ (u"ࠫࠬ䶥")]
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศࠨ䶦"), l111ll111_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lllll_l1_[l1l_l1_]
	else: type = l1111_l1_ (u"࠭ࠧ䶧")
	l1111_l1_ (u"ࠢࠣࠤࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠮ࠫ࠴࡮࡯࡮ࡧࠪ࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡴࡡ࡮ࡧࡀࠦࡹࡿࡰࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡷࡹࡸࠨࡴࡪࡲࡻࡩ࡯ࡡ࡭ࡱࡪࡷ࠮࠲ࡳࡵࡴࠫࡰࡪࡴࠨࡩࡶࡰࡰ࠮࠯ࠩࠋࠋ࡬ࡪࠥࡹࡨࡰࡹࡧ࡭ࡦࡲ࡯ࡨࡵࠣࡥࡳࡪࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠮ࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࠋࡩࡳࡷࠦࡣࡢࡶࡨ࡫ࡴࡸࡹ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡠู࠭าู๊ࠤ๊฻วา฻ฬࠫࡢࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡨࡧࡴࡦࡩࡲࡶࡾ࠯ࠊࠊࠋࠌࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ࠮ࠣࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚ࠩࠋࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࡁࠥ࠳࠱ࠡ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢࠪࠫࠏࠏࠣࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ࠮ࡷࡪࡧࡲࡤࡪ࠮ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ࠭ࡦࡥࡹ࡫ࡧࡰࡴࡼࠎࠎࠨࠢࠣ䶨")
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭䶩")+search+l1111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࠩ䶪")+type
	l1l11l1_l1_(url)
	return
# ===========================================
#     l11111l11_l1_ l1llll1l1l_l1_ l1llll11ll_l1_
# ===========================================
def l111111ll_l1_(url):
	url = url.split(l1111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ䶫"))[0]
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䶬"),url,l1111_l1_ (u"ࠬ࠭䶭"),headers,l1111_l1_ (u"࠭ࠧ䶮"),l1111_l1_ (u"ࠧࠨ䶯"),l1111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ䶰"))
	html = response.content
	# all l1lll11_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡹࡥࡢࡴࡦ࡬ࠧ࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ䶱"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	# name + category + options block
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡴࡵ࠯ࠬࡂࡶࡴࡻ࡮ࡥࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡪࡰࡳࡹࡹࠦ࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䶲"),block,re.DOTALL)
	return l111111_l1_
def l1lllll111_l1_(block):
	# id + title
	items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡦࡥࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦ࡬ࡪࡩ࡫࡮ࡣࡵ࡯࠲ࡨ࡯࡭ࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶳"),block,re.DOTALL)
	return items
def l111l111111l_l1_(url):
	url = url.replace(l1111_l1_ (u"ࠬࡩࡡࡵ࠿ࠪ䶴"),l1111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ䶵"))
	if l1111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ䶶") not in url: url = url+l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ䶷")
	l1lllll1l1_l1_ = url.split(l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭䶸"))[0]
	l1lllll11l_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧ䶹"))
	url = url.replace(l1lllll1l1_l1_,l1lllll11l_l1_)
	url = url.replace(l1111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ䶺"),l1111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡗ࡭ࡧࡨࡪࡦ࠷ࡹ࠴ࡇࡪࡢࡺࡤࡸ࠴ࡎ࡯࡮ࡧ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࡙ࡨࡰࡹࡶ࠲ࡵ࡮ࡰࡀࠩ䶻"))
	return url
l1111lllllll_l1_ = [l1111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䶼"),l1111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭䶽"),l1111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ䶾"),l1111_l1_ (u"ࠩࡦࡥࡹ࠭䶿")]
l111l11111l1_l1_ = [l1111_l1_ (u"ࠪࡧࡦࡺࠧ䷀"),l1111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䷁"),l1111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䷂")]
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䷃"),l1111_l1_ (u"ࠧࠨ䷄"))
	url = url.split(l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ䷅"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠩࡢࡣࡤ࠭䷆"),1)
	if filter==l1111_l1_ (u"ࠪࠫ䷇"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠫࠬ䷈"),l1111_l1_ (u"ࠬ࠭䷉")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪ䷊"))
	if type==l1111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ䷋"):
		if l111l11111l1_l1_[0]+l1111_l1_ (u"ࠨ࠿ࠪ䷌") not in l1l11lll_l1_: category = l111l11111l1_l1_[0]
		for i in range(len(l111l11111l1_l1_[0:-1])):
			if l111l11111l1_l1_[i]+l1111_l1_ (u"ࠩࡀࠫ䷍") in l1l11lll_l1_: category = l111l11111l1_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬ䷎")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧ䷏")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧ䷐")+category+l1111_l1_ (u"࠭࠽࠱ࠩ䷑")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩ䷒"))+l1111_l1_ (u"ࠨࡡࡢࡣࠬ䷓")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠩࠩࠫ䷔"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䷕"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ䷖")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ䷗"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䷘"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠧࠨ䷙"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䷚"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠩࠪ䷛"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ䷜")+l1l11ll1_l1_
		l11l11_l1_ = l111l111111l_l1_(l1l1lll_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷝"),menu_name+l1111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ䷞"),l11l11_l1_,111)
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷟"),menu_name+l1111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ䷠")+l11lll11_l1_+l1111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ䷡"),l11l11_l1_,111)
		l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䷢"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䷣"),l1111_l1_ (u"ࠫࠬ䷤"),9999)
	l111111_l1_ = l111111ll_l1_(url)
	dict = {}
	for name,l1lll1ll_l1_,block in l111111_l1_:
		name = name.replace(l1111_l1_ (u"ࠬ࠳࠭ࠨ䷥"),l1111_l1_ (u"࠭ࠧ䷦"))
		items = l1lllll111_l1_(block)
		if l1111_l1_ (u"ࠧ࠾ࠩ䷧") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ䷨"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<2:
				if l1lll1ll_l1_==l111l11111l1_l1_[-1]:
					l11l11_l1_ = l111l111111l_l1_(l1l1lll_l1_)
					l1l11l1_l1_(l11l11_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭䷩")+l1l1l1ll_l1_)
				return
			else:
				if l1lll1ll_l1_==l111l11111l1_l1_[-1]:
					l11l11_l1_ = l111l111111l_l1_(l1l1lll_l1_)
					l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷪"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ䷫"),l11l11_l1_,111)
				else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷬"),menu_name+l1111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ䷭"),l1l1lll_l1_,115,l1111_l1_ (u"ࠧࠨ䷮"),l1111_l1_ (u"ࠨࠩ䷯"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ䷰"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬ䷱")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠶ࠧ䷲")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧ䷳")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠱ࠩ䷴")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ䷵")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷶"),menu_name+l1111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ䷷")+name,l1l1lll_l1_,114,l1111_l1_ (u"ࠪࠫ䷸"),l1111_l1_ (u"ࠫࠬ䷹"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䷺"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if value==l1111_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭䷻"): option = l1111_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧ䷼")
			elif value==l1111_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨ䷽"): option = l1111_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫ䷾")
			if option in l11ll11_l1_: continue
			#if l1111_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ䷿") not in value: value = option
			#else: value = re.findall(l1111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬ一"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠬࠬࠧ丁")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽ࠨ丂")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠧࠧࠩ七")+l1lll1ll_l1_+l1111_l1_ (u"ࠨ࠿ࠪ丄")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭丅")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"ࠪࠤ࠿࠭丆")#+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠫ࠵࠭万")]
			title = option+l1111_l1_ (u"ࠬࠦ࠺ࠨ丈")+name
			if type==l1111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ三"): l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ上"),menu_name+title,url,114,l1111_l1_ (u"ࠨࠩ下"),l1111_l1_ (u"ࠩࠪ丌"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ不"))
			elif type==l1111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ与") and l111l11111l1_l1_[-2]+l1111_l1_ (u"ࠬࡃࠧ丏") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ丐"))
				l1l1lll_l1_ = url+l1111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ丑")+l1l111l1_l1_
				l11l11_l1_ = l111l111111l_l1_(l1l1lll_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丒"),menu_name+title,l11l11_l1_,111)
			else: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ专"),menu_name+title,url,115,l1111_l1_ (u"ࠪࠫ且"),l1111_l1_ (u"ࠫࠬ丕"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	# mode==l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ世")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ丗")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠧࡢ࡮࡯ࠫ丘")					all l1l1llll_l1_ & l111111l1_l1_ filters
	filters = filters.replace(l1111_l1_ (u"ࠨ࠿ࠩࠫ丙"),l1111_l1_ (u"ࠩࡀ࠴ࠫ࠭业"))
	filters = filters.strip(l1111_l1_ (u"ࠪࠪࠬ丛"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠫࡂ࠭东") in filters:
		items = filters.split(l1111_l1_ (u"ࠬࠬࠧ丝"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"࠭࠽ࠨ丞"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠧࠨ丟")
	for key in l1111lllllll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠨ࠲ࠪ丠")
		if l1111_l1_ (u"ࠩࠨࠫ両") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ丢") and value!=l1111_l1_ (u"ࠫ࠵࠭丣"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠦࠫࠡࠩ两")+value
		elif mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ严") and value!=l1111_l1_ (u"ࠧ࠱ࠩ並"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠨࠨࠪ丧")+key+l1111_l1_ (u"ࠩࡀࠫ丨")+value
		elif mode==l1111_l1_ (u"ࠪࡥࡱࡲࠧ丩"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠫࠫ࠭个")+key+l1111_l1_ (u"ࠬࡃࠧ丫")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"࠭ࠠࠬࠢࠪ丬"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠧࠩ中"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠨ࠿࠳ࠫ丮"),l1111_l1_ (u"ࠩࡀࠫ丯"))
	return l1lll11l_l1_
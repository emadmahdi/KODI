# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ⧈")
menu_name = l1111_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧ⧉")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
headers = {l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⧊"):l1111_l1_ (u"ࠪࠫ⧋")}
def l1111ll_l1_(mode,url,text):
	if   mode==320: l11l_l1_ = l11l111_l1_()
	elif mode==321: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==322: l11l_l1_ = l1lllll_l1_(url)
	elif mode==329: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⧌"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⧍"),l1111_l1_ (u"࠭ࠧ⧎"),329,l1111_l1_ (u"ࠧࠨ⧏"),l1111_l1_ (u"ࠨࠩ⧐"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⧑"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⧒"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⧓"),l1111_l1_ (u"ࠬ࠭⧔"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ⧕"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⧖"),l1111_l1_ (u"ࠨࠩ⧗"),headers,l1111_l1_ (u"ࠩࠪ⧘"),l1111_l1_ (u"ࠪࠫ⧙"),l1111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⧚"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰࡲ࠱ࡵࡲࡵࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⧛"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⧜"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if title==l1111_l1_ (u"ࠧศๆ่็ฯฮษࠡษ็้ึฬ๊สࠩ⧝"): continue
		l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⧞"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭⧟")+menu_name+title,l1l111l_l1_,321)
	return html
def l1l11l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⧠"),l1111_l1_ (u"ࠫࠬ⧡"),url,html)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ⧢"),url,l1111_l1_ (u"࠭ࠧ⧣"),headers,l1111_l1_ (u"ࠧࠨ⧤"),l1111_l1_ (u"ࠨࠩ⧥"),l1111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⧦"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⧧"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡰࡥ࠷ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⧨"),block,re.DOTALL)
	if not items: items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⧩"),block,re.DOTALL)
	for l1l111l_l1_,img,count,title in items:
		count = count.replace(l1111_l1_ (u"ู࠭ะัࠣࠫ⧪"),l1111_l1_ (u"ࠧࠨ⧫")).replace(l1111_l1_ (u"ࠨࠢࠪ⧬"),l1111_l1_ (u"ࠩࠪ⧭"))
		l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠪ࠳ࠬ⧮"),l1111_l1_ (u"ࠫࠬ⧯"))
		img = img.replace(l1111_l1_ (u"ࠧ࠭ࠢ⧰"),l1111_l1_ (u"࠭ࠧ⧱"))
		if l1111_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬ⧲") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⧳")+l1l111l_l1_
		l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࠫ⧴")+l1l111l_l1_
		img = l1ll11l_l1_+img
		title = title.strip(l1111_l1_ (u"ࠪࠤࠬ⧵"))
		title = title+l1111_l1_ (u"ࠫࠥ࠮ࠧ⧶")+count+l1111_l1_ (u"ࠬ࠯ࠧ⧷")
		if l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⧸") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧹"),menu_name+title,l1l111l_l1_,321,img)
		elif l1111_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ⧺") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⧻"),menu_name+title,l1l111l_l1_,322,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⧼"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⧽"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⧾")+l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧿"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭⨀")+title,l1l111l_l1_,321)
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ⨁"),url,l1111_l1_ (u"ࠩࠪ⨂"),headers,l1111_l1_ (u"ࠪࠫ⨃"),l1111_l1_ (u"ࠫࠬ⨄"),l1111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⨅"))
	html = response.content
	#l1l111l_l1_ = re.findall(l1111_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⨆"),html,re.DOTALL)
	#if not l1l111l_l1_:
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⨇"),html,re.DOTALL)
	l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_[0]#+l1111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ⨈")+l1l111l1l_l1_()+l1111_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡵࡴࡸࡩࠬ⨉")
	l1ll11ll1_l1_(l1l111l_l1_,l111_l1_,l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⨊"))
	return
def l1lll1_l1_(search):
	#search = l1111_l1_ (u"๊ࠫิสศำࠪ⨋")
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠬ࠭⨌"): search = l11ll_l1_()
	if search==l1111_l1_ (u"࠭ࠧ⨍"): return
	search = search.replace(l1111_l1_ (u"ࠧࠡࠩ⨎"),l1111_l1_ (u"ࠨ࠭ࠪ⨏"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ⨐")+search
	l1l11l1_l1_(url)
	return
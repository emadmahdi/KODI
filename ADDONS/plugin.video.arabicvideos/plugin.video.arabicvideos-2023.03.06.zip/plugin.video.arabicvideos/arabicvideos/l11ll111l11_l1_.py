# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_ = l1111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ仞")
menu_name=l1111_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ仟")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l1ll1111l1_l1_ = l111lll_l1_[l111_l1_][1]
l1ll111l111_l1_ = l111lll_l1_[l111_l1_][2]
def l1111ll_l1_(mode,url,text):
	if   mode==50: l11l_l1_ = l11l111_l1_()
	elif mode==51: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==52: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==53: l11l_l1_ = l1lllll_l1_(url)
	elif mode==55: l11l_l1_ = l1111llll1ll_l1_()
	elif mode==56: l11l_l1_ = l1111lll1lll_l1_()
	elif mode==57: l11l_l1_ = l1111llll111_l1_(url,1)
	elif mode==58: l11l_l1_ = l1111llll111_l1_(url,2)
	elif mode==59: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ仠"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ仡"),l1111_l1_ (u"࠭ࠧ仢"),59,l1111_l1_ (u"ࠧࠨ代"),l1111_l1_ (u"ࠨࠩ令"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭以"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ仦"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ仧"),l1111_l1_ (u"ࠬ࠭仨"),9999)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭仩"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ仪")+menu_name+l1111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ仫"),l1111_l1_ (u"ࠩࠪ们"),56)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ仭"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ仮")+menu_name+l1111_l1_ (u"ࠬอไศใ็ห๊࠭仯"),l1111_l1_ (u"࠭ࠧ仰"),55)
	return l1111_l1_ (u"ࠧࠨ仱")
def l1111llll1ll_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ仲"),menu_name+l1111_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ仳"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ仴"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ仵"),menu_name+l1111_l1_ (u"ࠬอแๅษ่ࠤึอฦอหࠪ件"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ价"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ仸"),menu_name+l1111_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไศใ็ห๊࠭仹"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ仺"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ任"),menu_name+l1111_l1_ (u"ࠫฬ็ไศ็ࠣ็้อำ๋ๅํอࠬ仼"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ份"),51)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ仾"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ仿"),l1111_l1_ (u"ࠨࠩ伀"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ企"),menu_name+l1111_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสึ๊ฮࠦวๅษ้ฮฬาࠧ伂"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡹࡰࡲࠪ伃"),57)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伄"),menu_name+l1111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศใู่ࠥะโ๋์่ࠫ伅"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ伆"),57)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ伇"),menu_name+l1111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็ห่ััࠡ็ืห์ีษࠨ伈"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ伉"),57)
	return
def l1111lll1lll_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伊"),menu_name+l1111_l1_ (u"ࠬออะอࠣห้๋ำๅี็หฯ࠭伋"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ伌"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ伍"),menu_name+l1111_l1_ (u"ࠨ็ึุ่๊วหࠢิหหาษࠨ伎"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭伏"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ伐"),menu_name+l1111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็ุ้๊ำๅษอࠫ休"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ伒"),51)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭伓"),menu_name+l1111_l1_ (u"ࠧๆี็ื้อสࠡๅ็หุ๐ใ๋หࠪ伔"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ伕"),51)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ伖"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ众"),l1111_l1_ (u"ࠫࠬ优"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伙"),menu_name+l1111_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ会"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡽࡴࡶࠧ伛"),57)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ伜"),menu_name+l1111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ伝"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭伞"),57)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伟"),menu_name+l1111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭传"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ伡"),57)
	return
def l1l11l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ伢"),l1111_l1_ (u"ࠨࠩ伣"),url,url)
	if l1111_l1_ (u"ࠩࡂࠫ伤") in url:
		parts = url.split(l1111_l1_ (u"ࠪࡃࠬ伥"))
		url = parts[0]
		filter = l1111_l1_ (u"ࠫࡄ࠭伦") + QUOTE(parts[1],l1111_l1_ (u"ࠬࡃࠦ࠻࠱ࠨࠫ伧"))
	else: filter = l1111_l1_ (u"࠭ࠧ伨")
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ伩"),l1111_l1_ (u"ࠨࠩ伪"),filter,l1111_l1_ (u"ࠩࠪ伫"))
	parts = url.split(l1111_l1_ (u"ࠪ࠳ࠬ伬"))
	sort,page,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1111_l1_ (u"ࠫࡾࡵࡰࠨ伭"),l1111_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࠬ伮"),l1111_l1_ (u"࠭ࡶࡪࡧࡺࡷࠬ伯")]:
		if type==l1111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭估"): type1=l1111_l1_ (u"ࠨใํ่๊࠭伱")
		elif type==l1111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ伲"): type1=l1111_l1_ (u"ุ้๊ࠪำๅࠩ伳")
		#url = l1ll11l_l1_ + l1111_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠲ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨ伴") + QUOTE(type1) + l1111_l1_ (u"ࠬ࠵ࠧ伵") + page + l1111_l1_ (u"࠭࠯ࠨ伶") + sort + filter
		url = l1ll11l_l1_ + l1111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ伷") + QUOTE(type1) + l1111_l1_ (u"ࠨ࠱ࠪ伸") + page + l1111_l1_ (u"ࠩ࠲ࠫ伹") + sort + filter
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ伺"),l1111_l1_ (u"ࠫࠬ伻"),l1111_l1_ (u"ࠬ࠭似"),url)
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"࠭ࠧ伽"),l1111_l1_ (u"ࠧࠨ伾"),l1111_l1_ (u"ࠨࠩ伿"),l1111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ佀"))
		#items = re.findall(l1111_l1_ (u"ࠪࠦࡷ࡫ࡦࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࠤࡱࡹࡲ࡫ࡰࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡵࡩࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ佁"),html,re.DOTALL)
		items = re.findall(l1111_l1_ (u"ࠫࠧࡶࡩࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡰࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࠦࡵ࡫ࡰࡪࡵࡲࡨࡪࡹࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡲࡵࡩࡸࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ佂"),html,re.DOTALL)
		l1l1lllll1l_l1_=0
		for id,title,l1111lll11ll_l1_,img in items:
			l1l1lllll1l_l1_ += 1
			#img = l1ll1111l1_l1_ + l1111_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ佃") + img + l1111_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭佄")
			img = l1ll111l111_l1_ + l1111_l1_ (u"ࠧ࠰ࡸ࠵࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࡰࡥ࡮ࡴ࠯ࠨ佅") + img + l1111_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ但")
			l1l111l_l1_ = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ佇") + id
			if type==l1111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ佈"): l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ佉"),menu_name+title,l1l111l_l1_,53,img)
			if type==l1111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ佊"): l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭佋"),menu_name+l1111_l1_ (u"ࠧๆี็ื้ࠦࠧ佌")+title,l1l111l_l1_+l1111_l1_ (u"ࠨࡁࡨࡴࡂ࠭位")+l1111lll11ll_l1_+l1111_l1_ (u"ࠩࡀࠫ低")+title+l1111_l1_ (u"ࠪࡁࠬ住")+img,52,img)
	else:
		if type==l1111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ佐"): type1=l1111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ佑")
		elif type==l1111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭佒"): type1=l1111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ体")
		url = l1ll1111l1_l1_ + l1111_l1_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ佔") + sort + l1111_l1_ (u"ࠩ࠰ࠫ何") + type1 + l1111_l1_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ佖")
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬ佗"),l1111_l1_ (u"ࠬ࠭佘"),l1111_l1_ (u"࠭ࠧ余"),l1111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭佚"))
		items = re.findall(l1111_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭佛"),html,re.DOTALL)
		l1l1lllll1l_l1_=0
		for id,l1111lll11ll_l1_,img,title in items:
			l1l1lllll1l_l1_ += 1
			img = l1ll1111l1_l1_ + l1111_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ作") + img + l1111_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ佝")
			l1l111l_l1_ = l1ll11l_l1_ + l1111_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ佞") + id
			if type==l1111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ佟"): l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ你"),menu_name+title,l1l111l_l1_,53,img)
			elif type==l1111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ佡"): l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ佢"),menu_name+l1111_l1_ (u"่ࠩืู้ไࠡࠩ佣")+title,l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ佤")+l1111lll11ll_l1_+l1111_l1_ (u"ࠫࡂ࠭佥")+title+l1111_l1_ (u"ࠬࡃࠧ佦")+img,52,img)
	title=l1111_l1_ (u"࠭ีโฯฬࠤࠬ佧")
	if l1l1lllll1l_l1_==16:
		for l1ll111l11l_l1_ in range(1,13) :
			if not page==str(l1ll111l11l_l1_):
				#url = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ佨")+type+l1111_l1_ (u"ࠨ࠱ࠪ佩")+str(l1ll111l11l_l1_)+l1111_l1_ (u"ࠩ࠲ࠫ佪")+sort + filter
				url = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ佫")+type+l1111_l1_ (u"ࠫ࠴࠭佬")+str(l1ll111l11l_l1_)+l1111_l1_ (u"ࠬ࠵ࠧ佭")+sort + filter
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭佮"),menu_name+title+str(l1ll111l11l_l1_),url,51)
	return
def l1l11ll_l1_(url):
	parts = url.split(l1111_l1_ (u"ࠧ࠾ࠩ佯"))
	l1111lll11ll_l1_ = int(parts[1])
	name = UNQUOTE(parts[2])
	name = name.replace(l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭佰"),l1111_l1_ (u"ࠩࠪ佱"))
	img = parts[3]
	url = url.split(l1111_l1_ (u"ࠪࡃࠬ佲"))[0]
	if l1111lll11ll_l1_==0:
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬ佳"),l1111_l1_ (u"ࠬ࠭佴"),l1111_l1_ (u"࠭ࠧ併"),l1111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ佶"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴ࠿ࠩ佷"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ佸"),block,re.DOTALL)
		l1111lll11ll_l1_ = int(items[-1])
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ佹"),l1111_l1_ (u"ࠫࠬ佺"),l1111lll11ll_l1_,l1111_l1_ (u"ࠬ࠭佻"))
	#name = xbmc.getInfoLabel( l1111_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡬ࡸࡱ࡫ࠢ佼") )
	#img = xbmc.getInfoLabel( l1111_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠣ佽") )
	for l11l11l_l1_ in range(l1111lll11ll_l1_,0,-1):
		l1l111l_l1_ = url + l1111_l1_ (u"ࠨࡁࡨࡴࡂ࠭佾") + str(l11l11l_l1_)
		title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ使")+name+l1111_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦࠧ侀")+str(l11l11l_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ侁"),menu_name+title,l1l111l_l1_,53,img)
	return
def l1lllll_l1_(url):
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠬ࠭侂"),l1111_l1_ (u"࠭ࠧ侃"),l1111_l1_ (u"ࠧࠨ侄"),l1111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ侅"))
	l1111lll1ll1_l1_ = re.findall(l1111_l1_ (u"่ࠩฮํ็ัࠡ฻็ํฺ่ࠥโ่ࠢหู่ࠠษ฻า࠲࠯ࡅ࡭ࡰ࡯ࡨࡲࡹࡢࠨࠣࠪ࠱࠮ࡄ࠯ࠢࠨ來"),html,re.DOTALL)
	if l1111lll1ll1_l1_:
		time = l1111lll1ll1_l1_[1].replace(l1111_l1_ (u"ࠪࡘࠬ侇"),l1111_l1_ (u"ࠫࠥࠦࠠࠡࠩ侈"))
		l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭侉"),l1111_l1_ (u"࠭ࠧ侊"),l1111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩ例"),l1111_l1_ (u"ࠨ้ำหࠥอไโ์า๎ํࠦำ๋ๅ๋๊๋ࠥส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี่ࠠาสࠤฬ๊่ใฬࠪ侌")+l1111_l1_ (u"ࠩ࡟ࡲࠬ侍")+time)
		return
	#if l1111_l1_ (u"๊ࠪ฾ะะาࠢ฼่๎่ࠦใ๊฼ࠤำ฽รࠨ侎") in html:
	#	l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ侏"),l1111_l1_ (u"ࠬ࠭侐"),l1111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ侑"),l1111_l1_ (u"ࠧ็฻อิึูࠦๅ๋ࠣ์็๎ูࠡะฺวࠬ侒"))
	#	return
	l1111lll111l_l1_,l1111llll11l_l1_ = [],[]
	l1111llll1l1_l1_ = re.findall(l1111_l1_ (u"ࠨࡸࡤࡶࠥࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭侓"),html,re.DOTALL)[0]
	l1111lll1l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡹࡥࡷࠦࡢࡢࡥ࡮ࡹࡵࡥ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ侔"),html,re.DOTALL)[0]
	# l1llll111_l1_ l11l1ll1_l1_
	l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡱࡹ࠺ࠡࠪ࠱࠮ࡄ࠯࡟࡭࡫ࡱ࡯ࡡ࠱ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ侕"),html,re.DOTALL)
	for server,l1l111l_l1_ in l11l1ll1_l1_:
		if l1111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ侖") in server:
			server = l1111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ侗")
			url = l1111lll1l1l_l1_ + l1l111l_l1_
		else:
			server = l1111_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ侘")
			url = l1111llll1l1_l1_ + l1l111l_l1_
		if l1111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭侙") in url:
			l1111lll111l_l1_.append(url)
			l1111llll11l_l1_.append(l1111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠠࠨ侚")+server)
		l1111_l1_ (u"ࠤࠥࠦࠏࠏࠉࡪࡨࠣࠫ࠳ࡳ࠳ࡶ࠺ࠪࠤ࡮ࡴࠠࡶࡴ࡯࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨࡶࡴ࡯࠭ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛࠱࡟ࡀࡁࠬ࠳࠱ࠨ࠼ࠍࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥࡵࡳ࡮࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲࠩࠋࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡳࡧ࡭ࡦ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪࡱ࠸ࡻ࠸ࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࠪࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠮࠯࠺ࠋࠋࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࡟࡮ࡣࠩࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡾࡶࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡࡩ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࠣࠫ࠮ࡡ࠰࡞ࠌࠌࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࡟࡮ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࡨ࡬ࡰࡪࡺࡹࡱࡧ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠢࠪ࠰ࠬࠦࠠࠨࠫࠍࠍࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟࡯ࡣࡰࡩ࠳ࡧࡰࡱࡧࡱࡨ࠭࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠫࠨࠢࠣࠫ࠰ࡹࡥࡳࡸࡨࡶ࠰࠭ࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠨࠢࠣ供")
	# l1111l1l_l1_ l11l1ll1_l1_
	l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡣࡱ࡯࡮࡬࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ侜"),html,re.DOTALL)
	l11l1ll1_l1_ += re.findall(l1111_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ依"),html,re.DOTALL)
	for server,l1l111l_l1_ in l11l1ll1_l1_:
		filename = l1l111l_l1_.split(l1111_l1_ (u"ࠬ࠵ࠧ侞"))[-1]
		filename = filename.replace(l1111_l1_ (u"࠭ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠨ侟"),l1111_l1_ (u"ࠧࠨ侠"))
		filename = filename.replace(l1111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭価"),l1111_l1_ (u"ࠩࠪ侢"))
		filename = filename.replace(l1111_l1_ (u"ࠪ࠱ࠬ侣"),l1111_l1_ (u"ࠫࠬ侤"))
		if l1111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ侥") in server:
			server = l1111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭侦")
			url = l1111lll1l1l_l1_ + l1l111l_l1_
		else:
			server = l1111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ侧")
			url = l1111llll1l1_l1_ + l1l111l_l1_
		l1111lll111l_l1_.append(url)
		l1111llll11l_l1_.append(l1111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࠦࠧ侨")+server+l1111_l1_ (u"ࠩࠣࠤࠬ侩")+filename)
	l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡚ࠣ࡮ࡪࡥࡰࠢࡔࡹࡦࡲࡩࡵࡻ࠽ࠫ侪"), l1111llll11l_l1_)
	if l1l_l1_ == -1 : return
	url = l1111lll111l_l1_[l1l_l1_]
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ侫"))
	return
def l1111llll111_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭侬"),l1111_l1_ (u"࠭ࠧ侭"),url,url)
	if l1111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ侮") in url: l1l1lll_l1_ = l1ll11l_l1_ + l1111_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰็ึุ่๊ࠧ侯")
	else: l1l1lll_l1_ = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ไ๎้๋ࠧ侰")
	l1l1lll_l1_ = QUOTE(l1l1lll_l1_)
	html = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ侱"),l1111_l1_ (u"ࠫࠬ侲"),l1111_l1_ (u"ࠬ࠭侳"),l1111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡈࡌࡐ࡙ࡋࡒࡔ࠯࠴ࡷࡹ࠭侴"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ侵"),l1111_l1_ (u"ࠨࠩ侶"),url,html)
	if type==1: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡹࡧ࡭ࡥ࡯ࡴࡨࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ侷"),html,re.DOTALL)
	elif type==2: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ侸"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࠫ侹"),block,re.DOTALL)
	if type==1:
		for l1111lll11l1_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侺"),menu_name+title,url+l1111_l1_ (u"࠭࠿ࡴࡷࡥ࡫ࡪࡴࡲࡦ࠿ࠪ侻")+l1111lll11l1_l1_,58)
	elif type==2:
		url,l1111lll11l1_l1_ = url.split(l1111_l1_ (u"ࠧࡀࠩ侼"))
		for country,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侽"),menu_name+title,url+l1111_l1_ (u"ࠩࡂࡧࡴࡻ࡮ࡵࡴࡼࡁࠬ侾")+country+l1111_l1_ (u"ࠪࠪࠬ便")+l1111lll11l1_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search: search = l11ll_l1_()
	if not search: return
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ俀"),l1111_l1_ (u"ࠬ࠭俁"),search,search)
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"࠭ࠠࠨ係"),l1111_l1_ (u"ࠧࠦ࠴࠳ࠫ促"))
	#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ俄"), l1ll11l_l1_, l1111_l1_ (u"ࠩࠪ俅"), l1111_l1_ (u"ࠪࠫ俆"), True,l1111_l1_ (u"ࠫࠬ俇"),l1111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ俈"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11ll11l1_l1_ = cookies[l1111_l1_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧ俉")]
	#l1111lll1l11_l1_ = re.findall(l1111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡤࡵࡵࡪࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧ俊"),html,re.DOTALL)
	#l1111lll1l11_l1_ = l1111lll1l11_l1_[0]
	#payload = l1111_l1_ (u"ࠨࡡࡦࡷࡷ࡬࠽ࠨ俋") + l1111lll1l11_l1_ + l1111_l1_ (u"ࠩࠩࡵࡂ࠭俌") + QUOTE(l1lll1l_l1_)
	#headers = { l1111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ俍"):l1111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ俎") , l1111_l1_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬ俏"):l1111_l1_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠨ俐")+l11ll11l1_l1_ }
	#url = l1ll11l_l1_ + l1111_l1_ (u"ࠢ࠰ࡵࡨࡥࡷࡩࡨࠣ俑")
	#response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭俒"), url, payload, headers, True,l1111_l1_ (u"ࠩࠪ俓"),l1111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ俔"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ俕")+l1lll1l_l1_
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ俖"),url,l1111_l1_ (u"࠭ࠧ俗"),l1111_l1_ (u"ࠧࠨ俘"),True,l1111_l1_ (u"ࠨࠩ俙"),l1111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ俚"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪ࡫ࡪࡴࡥࡳࡣ࡯࠱ࡧࡵࡤࡺࠪ࠱࠮ࡄ࠯ࡳࡦࡣࡵࡧ࡭࠳ࡢࡰࡶࡷࡳࡲ࠳ࡰࡢࡦࡧ࡭ࡳ࡭ࠧ俛"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ俜"),block,re.DOTALL)
	if items:
		for l1l111l_l1_,img,title in items:
			#title = title.decode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ保")).encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ俞"))
			url = l1ll11l_l1_ + l1l111l_l1_
			if l1111_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ俟") in url:
				if l1111_l1_ (u"ࠨࡁࡨࡴࡂ࠭俠") in url:
					title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ信")+title
					url = url.replace(l1111_l1_ (u"ࠪࡃࡪࡶ࠽࠲ࠩ俢"),l1111_l1_ (u"ࠫࡄ࡫ࡰ࠾࠲ࠪ俣"))
					url = url+l1111_l1_ (u"ࠬࡃࠧ俤")+QUOTE(title)+l1111_l1_ (u"࠭࠽ࠨ俥")+img
					l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ俦"),menu_name+title,url,52,img)
				else:
					title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥแ๋ๆ่ࠤࠬ俧")+title
					l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ俨"),menu_name+title,url,53,img)
	#else: l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ俩"),l1111_l1_ (u"ࠫࠬ俪"),l1111_l1_ (u"ࠬࡴ࡯ࠡࡴࡨࡷࡺࡲࡴࡴࠩ俫"),l1111_l1_ (u"࠭ไศࠢอ์ัีࠠ็ฬสสัࠦไๅสะฯࠬ俬"))
	return
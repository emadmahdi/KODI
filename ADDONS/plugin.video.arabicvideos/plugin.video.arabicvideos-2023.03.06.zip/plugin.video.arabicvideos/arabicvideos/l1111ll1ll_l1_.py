# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬᴏ")
menu_name=l1111_l1_ (u"࠭࡟ࡆࡉࡑࡣࠬᴐ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬᴑ"),l1111_l1_ (u"ࠨษ็็้࠭ᴒ"),l1111_l1_ (u"ࠩࡱ࠳ࡆ࠭ᴓ"),l1111_l1_ (u"ࠪห้๋า๋ัࠪᴔ"),l1111_l1_ (u"ࠫ็฻ษࠡ฻ืๆࠬᴕ")]
def l1111ll_l1_(mode,url,text):
	if   mode==430: l11l_l1_ = l11l111_l1_()
	elif mode==431: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==432: l11l_l1_ = l1lllll_l1_(url)
	elif mode==433: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==434: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᴖ")+text)
	elif mode==435: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬᴗ")+text)
	elif mode==436: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==437: l11l_l1_ = l1llllllll_l1_(url)
	elif mode==439: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᴘ"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᴙ"),l1111_l1_ (u"ࠩࠪᴚ"),l1111_l1_ (u"ࠪࠫᴛ"),l1111_l1_ (u"ࠫࠬᴜ"),l1111_l1_ (u"ࠬ࠭ᴝ"),l1111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᴞ"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡥࡤࡲࡴࡴࡩࡤࡣ࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴟ"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"ࠨ࠱ࠪᴠ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭ᴡ"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᴢ"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᴣ"),l1111_l1_ (u"ࠬ࠭ᴤ"),439,l1111_l1_ (u"࠭ࠧᴥ"),l1111_l1_ (u"ࠧࠨᴦ"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴧ"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᴨ"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᴩ"),l1llll1lll_l1_,435)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴪ"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᴫ"),l1llll1lll_l1_,434)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᴬ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᴭ"),l1111_l1_ (u"ࠨࠩᴮ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᴯ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧᴰ")+menu_name+l1111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪᴱ"),l1llll1lll_l1_,431)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴲ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᴳ")+menu_name+l1111_l1_ (u"ࠧศใ็ห๊ࠦว้่่ࠣฬ๐ๆࠨᴴ"),l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠲ࠩᴵ"),436)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᴶ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧᴷ")+menu_name+l1111_l1_ (u"ู๊ࠫไิๆสฮࠥอ่็ࠢ็ห๏์ࠧᴸ"),l1llll1lll_l1_+l1111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠳ࡡ࡭࡮࠴ࠫᴹ"),436)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴺ"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫᴻ")+menu_name+l1111_l1_ (u"ࠨไสส๊ฯࠠหใุ๎้๐ษࠨᴼ"),l1llll1lll_l1_,437)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᴽ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᴾ"),l1111_l1_ (u"ࠫࠬᴿ"),9999)
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵀ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᵁ")+menu_name+l1111_l1_ (u"ࠧศๆ่้๏ุษࠨᵂ"),l1llll1lll_l1_,431,l1111_l1_ (u"ࠨࠩᵃ"),l1111_l1_ (u"ࠩࠪᵄ"),l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᵅ"))
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵆ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᵇ")+menu_name+l1111_l1_ (u"࠭รโๆส้ࠬᵈ"),l1llll1lll_l1_+l1111_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹ࠯ࠨᵉ"),436)
	#l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵊ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᵋ")+menu_name+l1111_l1_ (u"ุ้๊ࠪำๅษอࠫᵌ"),l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲࠷࠯ࠨᵍ"),436)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡓࡪࡶࡨࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡵࡧ࡭ࠨࠧᵎ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᵏ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		#if title==l1111_l1_ (u"ࠧศๆิส๏ู๊สࠩᵐ"): title = l1111_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧᵑ")
		if title in l11ll11_l1_: continue
		if title==l1111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᵒ"): continue
		if l1111_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠬᵓ") in title: continue
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵔ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᵕ")+menu_name+title,l1l111l_l1_,431)
	return
def l1llllllll_l1_(l1l1lll1_l1_=l1111_l1_ (u"࠭ࠧᵖ")):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᵗ"),l1l1lll1_l1_+l1111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᵘ"),l1111_l1_ (u"ࠩࠪᵙ"),l1111_l1_ (u"ࠪࠫᵚ"),l1111_l1_ (u"ࠫࠬᵛ"),l1111_l1_ (u"ࠬ࠭ᵜ"),l1111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᵝ"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡥࡤࡲࡴࡴࡩࡤࡣ࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᵞ"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"ࠨ࠱ࠪᵟ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭ᵠ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡑ࡯ࡳࡵࡆࡵࡳࡵ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡶࡨ࡮ࡩ࡯ࡩࡐࡥࡸࡺࡥࡳࠤࠪᵡ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᵢ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11ll11_l1_: continue
		l1l111l_l1_ = l1l1lll1_l1_+l1111_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩᵣ")+category+l1111_l1_ (u"࠭࠽ࠨᵤ")+value
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᵥ"),l1l1lll1_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬᵦ")+menu_name+title,l1l111l_l1_,431)
	return
def	l11lll1l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪᵧ"),l1111_l1_ (u"ࠪࠫᵨ"),l1111_l1_ (u"ࠫࡘ࡛ࡂࡎࡇࡑ࡙ࠬᵩ"),url)
	#LOG_THIS(l1111_l1_ (u"ࠬ࠭ᵪ"),l1l111l_l1_)
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪᵫ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᵬ"),url,l1111_l1_ (u"ࠨࠩᵭ"),l1111_l1_ (u"ࠩࠪᵮ"),l1111_l1_ (u"ࠪࠫᵯ"),l1111_l1_ (u"ࠫࠬᵰ"),l1111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᵱ"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵲ"),menu_name+l1111_l1_ (u"ࠧศๆฯ้๏฿ࠧᵳ"),url,431)
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨᵴ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨᵵ"),block,re.DOTALL)
	for l11111l1l_l1_,title in items:
		if title in l11ll11_l1_: continue
		l1l1lll_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡑࡴࡼࡩࡦࡵ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࡄࡱࡥࡺ࠿ࠪᵶ")+l11111l1l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵷ"),menu_name+title,l1l1lll_l1_,431)
	#l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᵸ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᵹ"),l1111_l1_ (u"ࠧࠨᵺ"),9999)
	#l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡌࡲࡳ࡫ࡲࡑࡣࡪࡩࡋ࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠨᵻ"),html,re.DOTALL)
	#block = l111l1l_l1_[0]
	#items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩᵼ"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l11ll11_l1_: continue
	#	if l1111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵ࠲ࠫᵽ") in url: l1l1lll_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡒࡵࡶࡪࡧࡶ࠳࡙࡫ࡲ࡮ࡵ࠱ࡴ࡭ࡶ࠿ࠨᵾ")+category+l1111_l1_ (u"ࠬࡃࠧᵿ")+value
	#	elif l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠭ࠨᶀ") in url: l1l1lll_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡔࡧࡵ࡭ࡪࡹ࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࡀࠩᶁ")+category+l1111_l1_ (u"ࠨ࠿ࠪᶂ")+value
	#	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᶃ"),menu_name+title,l1l1lll_l1_,431)
	return
def l1l11l1_l1_(url,request=l1111_l1_ (u"ࠪࠫᶄ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬᶅ"),l1111_l1_ (u"ࠬ࠭ᶆ"),request,url)
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪᶇ"))
	items = []
	if l1111_l1_ (u"ࠧ࠰ࡖࡨࡶࡲࡹ࠮ࡱࡪࡳࠫᶈ") in url or l1111_l1_ (u"ࠨ࠱ࡊࡩࡹ࠴ࡰࡩࡲࠪᶉ") in url or l1111_l1_ (u"ࠩ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࠬᶊ") in url:
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ᶋ"):l1111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬᶌ"),l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᶍ"):l1111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᶎ")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡑࡑࡖࡘࠬᶏ"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠨࠩᶐ"),l1111_l1_ (u"ࠩࠪᶑ"),l1111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᶒ"))
		html = response.content
		block = html
	elif request==l1111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᶓ"):
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩᶔ"),url,l1111_l1_ (u"࠭ࠧᶕ"),l1111_l1_ (u"ࠧࠨᶖ"),l1111_l1_ (u"ࠨࠩᶗ"),l1111_l1_ (u"ࠩࠪᶘ"),l1111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᶙ"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡓࡡࡪࡰࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡏࡤࡸࡨ࡮ࡥࡴࡖࡤࡦࡱ࡫ࠢࠨᶚ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᶛ"),block,re.DOTALL)
	else:
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪᶜ"),url,l1111_l1_ (u"ࠧࠨᶝ"),l1111_l1_ (u"ࠨࠩᶞ"),l1111_l1_ (u"ࠩࠪᶟ"),l1111_l1_ (u"ࠪࠫᶠ"),l1111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᶡ"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡓࡥ࡬࡯࡮ࡢࡶࡨࠦࠬᶢ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭ᶣ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	if not items: items = re.findall(l1111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡬ࡱࡦ࡭ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᶤ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ࠨ็ืห์ีษࠨᶥ"),l1111_l1_ (u"ࠩไ๎้๋ࠧᶦ"),l1111_l1_ (u"ࠪห฿์๊สࠩᶧ"),l1111_l1_ (u"่๊๊ࠫษࠩᶨ"),l1111_l1_ (u"ࠬอูๅษ้ࠫᶩ"),l1111_l1_ (u"࠭็ะษไࠫᶪ"),l1111_l1_ (u"ࠧๆสสีฬฯࠧᶫ"),l1111_l1_ (u"ࠨ฻ิฺࠬᶬ"),l1111_l1_ (u"่๋ࠩึาว็ࠩᶭ"),l1111_l1_ (u"ࠪห้ฮ่ๆࠩᶮ")]
	for l1l111l_l1_,title,img in items:
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠫ࠴࠭ᶯ"))
		#l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
		title = l1l1111_l1_(title)
		#title = title.strip(l1111_l1_ (u"ࠬࠦࠧᶰ"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩᶱ"),title,re.DOTALL)
		if any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᶲ"),menu_name+title,l1l111l_l1_,432,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠨษ็ั้่ษࠨᶳ") in title:
			title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᶴ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶵ"),menu_name+title,l1l111l_l1_,433,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩᶶ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶷ"),menu_name+title,l1l111l_l1_,431,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶸ"),menu_name+title,l1l111l_l1_,433,img)
	if request!=l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᶹ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡓࡥ࡬࡯࡮ࡢࡶࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᶺ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᶻ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᶼ") not in l1l111l_l1_: l1l111l_l1_ = l1llll1lll_l1_+l1l111l_l1_
				l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
				title = l1l1111_l1_(title)
				if title!=l1111_l1_ (u"ࠫࠬᶽ"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶾ"),menu_name+l1111_l1_ (u"࠭ีโฯฬࠤࠬᶿ")+title,l1l111l_l1_,431)
		l1111111l_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᷀"),html,re.DOTALL)
		if l1111111l_l1_:
			l1l111l_l1_ = l1111111l_l1_[0]
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷁"),menu_name+l1111_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะ᷂ࠩ"),l1l111l_l1_,431)
	return
def l1l11ll_l1_(url):
	#LOG_THIS(l1111_l1_ (u"ࠪࠫ᷃"),l1111_l1_ (u"ࠫ࠶࠷࠱࠲ࠢࠣࠫ᷄")+url)
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ᷅"))
	l1lll1l1ll_l1_,l1l11lll1_l1_ = [],[]
	if l1111_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠯ࡲ࡫ࡴࠬ᷆") in url:
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ᷇"):l1111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ᷈"),l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ᷉"):l1111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺᷊ࠪ")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ᷋"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠬ࠭᷌"),l1111_l1_ (u"࠭ࠧ᷍"),l1111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ᷎࠭"))
		html = response.content
		l1l11lll1_l1_ = [html]
	else:
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘ᷏ࠬ"),url,l1111_l1_ (u"᷐ࠩࠪ"),l1111_l1_ (u"ࠪࠫ᷑"),l1111_l1_ (u"ࠫࠬ᷒"),l1111_l1_ (u"ࠬ࠭ᷓ"),l1111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᷔ"))
		html = response.content
		l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᷕ"),html,re.DOTALL)
		l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᷖ"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_:
		img = re.findall(l1111_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᷗ"),html,re.DOTALL)
		img = img[0]
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᷘ"),block,re.DOTALL)
		for l1111ll11l_l1_,l1111ll111_l1_,title in items:
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࡂࠫᷙ")+l1111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡂ࠭ᷚ")+l1111ll111_l1_+l1111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩᷛ")+l1111ll11l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᷜ"),menu_name+title,l1l111l_l1_,433,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		img = xbmc.getInfoLabel(l1111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩᷝ"))
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭ᷞ"),block,re.DOTALL)
		for l1l111l_l1_,title,l11l11l_l1_ in items:
			title = title+l1111_l1_ (u"ࠪࠤࠬᷟ")+l11l11l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᷠ"),menu_name+title,l1l111l_l1_,432,img)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url+l1111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ᷡ")
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪᷢ"),l1l1lll_l1_,l1111_l1_ (u"ࠧࠨᷣ"),l1111_l1_ (u"ࠨࠩᷤ"),l1111_l1_ (u"ࠩࠪᷥ"),l1111_l1_ (u"ࠪࠫᷦ"),l1111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᷧ"))
	html = response.content
	l11lll1l_l1_ = []
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩᷨ"))
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᷩ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l1lll111l1_l1_ = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᷪ"),block,re.DOTALL)
		if l1lll111l1_l1_:
			l1lll111l1_l1_ = l1lll111l1_l1_[0]
			#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩᷫ"),l1111_l1_ (u"ࠩࠪᷬ"),l1111_l1_ (u"ࠪࠫᷭ"),l1lll111l1_l1_)
			items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪᷮ"),block,re.DOTALL)
			for server,title in items:
				l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁࡶࡩࡷࡼࡥࡳ࠿ࠪᷯ")+server+l1111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩᷰ")+l1lll111l1_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᷱ")+title+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᷲ")
				l11lll1l_l1_.append(l1l111l_l1_)
	# l11l1l11l_l1_ l1l111l_l1_
	l11l1l11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡩࡧࡴࡤࡱࡪࠨ࠾࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᷳ"),html,re.DOTALL)
	if l11l1l11l_l1_:
		l11l1l11l_l1_ = l11l1l11l_l1_[0].replace(l1111_l1_ (u"ࠪࡠࡳ࠭ᷴ"),l1111_l1_ (u"ࠫࠬ᷵"))
		title = l1l1lll1l_l1_(l11l1l11l_l1_,l1111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ᷶"))
		l1l111l_l1_ = l11l1l11l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ᷷ࠧ")+title+l1111_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ᷸")
		l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁ᷹ࠫ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ᷺࠭"),block,re.DOTALL)
		for l1l111l_l1_,title,l11l1111_l1_ in items:
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠪࡠࡳ࠭᷻"),l1111_l1_ (u"ࠫࠬ᷼"))
			if l11l1111_l1_!=l1111_l1_ (u"᷽ࠬ࠭"): l11l1111_l1_ = l1111_l1_ (u"࠭࡟ࡠࡡࡢࠫ᷾")+l11l1111_l1_
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᷿")+title+l1111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬḀ")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧḁ"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩḂ"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠫࠬḃ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠬ࠭Ḅ"): return
	search = search.replace(l1111_l1_ (u"࠭ࠠࠨḅ"),l1111_l1_ (u"ࠧࠦ࠴࠳ࠫḆ"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭ḇ")+search
	l1l11l1_l1_(url)
	return
# ===========================================
#     l11111l11_l1_ l1llll1l1l_l1_ l1llll11ll_l1_
# ===========================================
def l111111ll_l1_(url):
	url = url.split(l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ḉ"))[0]
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧḉ"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨḊ"),l1llll1lll_l1_,l1111_l1_ (u"ࠬ࠭ḋ"),l1111_l1_ (u"࠭ࠧḌ"),l1111_l1_ (u"ࠧࠨḍ"),l1111_l1_ (u"ࠨࠩḎ"),l1111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫḏ"))
	html = response.content
	# all l1lll11_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨḐ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	# name + options block + category
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠮࠭ḑ"),block,re.DOTALL)
	return l111111_l1_
def l1lllll111_l1_(block):
	# value + name
	items = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫࡠࡩ࠱ࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ḓ"),block,re.DOTALL)
	return items
def l11111111_l1_(url):
	#url = url.replace(l1111_l1_ (u"࠭ࡣࡢࡶࡀࠫḓ"),l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪḔ"))
	l1lllll1l1_l1_ = url.split(l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬḕ"))[0]
	l1lllll11l_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠩࡸࡶࡱ࠭Ḗ"))
	url = url.replace(l1lllll1l1_l1_,l1lllll11l_l1_)
	url = url.replace(l1111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧḗ"),l1111_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨḘ"))
	return url
def l1111ll1l1_l1_(l1ll11l1_l1_,url):
	l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨḙ")) # l111llll11_l1_ be l11l1111l1_l1_
	l11l11_l1_ = url+l1111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪḚ")+l1l111l1_l1_
	l11l11_l1_ = l11111111_l1_(l11l11_l1_)
	return l11l11_l1_
l1l1l11l_l1_ = [l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩḛ"),l1111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩḜ"),l1111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨḝ"),l1111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩḞ")]
l1ll1lll_l1_ = [l1111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬḟ"),l1111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫḠ"),l1111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬḡ"),l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩḢ"),l1111_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪḣ"),l1111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪḤ")]
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḥ"),l1111_l1_ (u"ࠫࠬḦ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭ḧ"),l1111_l1_ (u"࠭ࠧḨ"),filter,url)
	if l1111_l1_ (u"ࠧࡀࠩḩ") in url: url = url.split(l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬḪ"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠩࡢࡣࡤ࠭ḫ"),1)
	if filter==l1111_l1_ (u"ࠪࠫḬ"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠫࠬḭ"),l1111_l1_ (u"ࠬ࠭Ḯ")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪḯ"))
	if type==l1111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪḰ"):
		if l1l1l11l_l1_[0]+l1111_l1_ (u"ࠨ࠿ࠪḱ") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠩࡀࠫḲ") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬḳ")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧḴ")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧḵ")+category+l1111_l1_ (u"࠭࠽࠱ࠩḶ")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩḷ"))+l1111_l1_ (u"ࠨࡡࡢࡣࠬḸ")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠩࠩࠫḹ"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭Ḻ")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨḻ")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨḼ"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨḽ")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠧࠨḾ"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫḿ")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		if l1l11ll1_l1_==l1111_l1_ (u"ࠩࠪṀ"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧṁ")+l1l11ll1_l1_
		l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṂ"),menu_name+l1111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨṃ"),l1l1lll_l1_,431)
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṅ"),menu_name+l1111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧṅ")+l11lll11_l1_+l1111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧṆ"),l1l1lll_l1_,431)
		l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṇ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪṈ"),l1111_l1_ (u"ࠫࠬṉ"),9999)
	l111111_l1_ = l111111ll_l1_(url)
	dict = {}
	for name,block,l1lll1ll_l1_ in l111111_l1_:
		name = name.replace(l1111_l1_ (u"ࠬ࠳࠭ࠨṊ"),l1111_l1_ (u"࠭ࠧṋ"))
		items = l1lllll111_l1_(block)
		if l1111_l1_ (u"ࠧ࠾ࠩṌ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫṍ"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<2:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]:
					url = l11111111_l1_(url)
					l1l11l1_l1_(url)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨṎ")+l1l1l1ll_l1_)
				return
			else:
				l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪṏ"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬṐ"),l1l1lll_l1_,431)
				else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṑ"),menu_name+l1111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧṒ"),l1l1lll_l1_,435,l1111_l1_ (u"ࠧࠨṓ"),l1111_l1_ (u"ࠨࠩṔ"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬṕ"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬṖ")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠶ࠧṗ")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧṘ")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠱ࠩṙ")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫṚ")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṛ"),menu_name+l1111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫṜ")+name,l1l1lll_l1_,434,l1111_l1_ (u"ࠪࠫṝ"),l1111_l1_ (u"ࠫࠬṞ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧṟ"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if value==l1111_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭Ṡ"): option = l1111_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧṡ")
			elif value==l1111_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨṢ"): option = l1111_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫṣ")
			if option in l11ll11_l1_: continue
			#if l1111_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩṤ") not in value: value = option
			#else: value = re.findall(l1111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬṥ"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠬࠬࠧṦ")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽ࠨṧ")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠧࠧࠩṨ")+l1lll1ll_l1_+l1111_l1_ (u"ࠨ࠿ࠪṩ")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭Ṫ")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"ࠪࠤ࠿࠭ṫ")#+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠫ࠵࠭Ṭ")]
			title = option+l1111_l1_ (u"ࠬࠦ࠺ࠨṭ")+name
			if type==l1111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩṮ"): l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṯ"),menu_name+title,url,434,l1111_l1_ (u"ࠨࠩṰ"),l1111_l1_ (u"ࠩࠪṱ"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṲ"))
			elif type==l1111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧṳ") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠬࡃࠧṴ") in l1l11lll_l1_:
				l11l11_l1_ = l1111ll1l1_l1_(l1ll11l1_l1_,url)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ṵ"),menu_name+title,l11l11_l1_,431)
			else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṶ"),menu_name+title,url,435,l1111_l1_ (u"ࠨࠩṷ"),l1111_l1_ (u"ࠩࠪṸ"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫṹ"),l1111_l1_ (u"ࠫࠬṺ"),filters,l1111_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭ṻ"))
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨṼ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪṽ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭Ṿ")			all l1l1llll_l1_ & l111111l1_l1_ filters
	filters = filters.replace(l1111_l1_ (u"ࠩࡀࠪࠬṿ"),l1111_l1_ (u"ࠪࡁ࠵ࠬࠧẀ"))
	filters = filters.strip(l1111_l1_ (u"ࠫࠫ࠭ẁ"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠬࡃࠧẂ") in filters:
		items = filters.split(l1111_l1_ (u"࠭ࠦࠨẃ"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠧ࠾ࠩẄ"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠨࠩẅ")
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠩ࠳ࠫẆ")
		if l1111_l1_ (u"ࠪࠩࠬẇ") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭Ẉ") and value!=l1111_l1_ (u"ࠬ࠶ࠧẉ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠠࠬࠢࠪẊ")+value
		elif mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪẋ") and value!=l1111_l1_ (u"ࠨ࠲ࠪẌ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠩࠩࠫẍ")+key+l1111_l1_ (u"ࠪࡁࠬẎ")+value
		elif mode==l1111_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩẏ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠬࠧẐ")+key+l1111_l1_ (u"࠭࠽ࠨẑ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠡ࠭ࠣࠫẒ"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠨࠨࠪẓ"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠩࡀ࠴ࠬẔ"),l1111_l1_ (u"ࠪࡁࠬẕ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬẖ"),l1111_l1_ (u"ࠬ࠭ẗ"),filters,l1111_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧẘ"))
	return l1lll11l_l1_
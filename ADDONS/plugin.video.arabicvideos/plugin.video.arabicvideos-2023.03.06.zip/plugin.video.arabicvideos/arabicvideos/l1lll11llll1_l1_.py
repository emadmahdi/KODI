# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㨚")
headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㨛"):l1111_l1_ (u"ࠨࠩ㨜")}
menu_name=l1111_l1_ (u"ࠩࡢࡑࡈࡓ࡟ࠨ㨝")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ㨞"),l1111_l1_ (u"ࠫࡼࡽࡥࠨ㨟")]
def l1111ll_l1_(mode,url,text):
	if   mode==360: l11l_l1_ = l11l111_l1_()
	elif mode==361: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==362: l11l_l1_ = l1lllll_l1_(url)
	elif mode==363: l11l_l1_ = l1l11ll_l1_(url,text)
	elif mode==364: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ㨠")+text)
	elif mode==365: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ㨡")+text)
	elif mode==366: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==369: l11l_l1_ = l1lll1_l1_(text,url)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ㨢"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩ㨣"),l1111_l1_ (u"ࠩࠪ㨤"),False,l1111_l1_ (u"ࠪࠫ㨥"),l1111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㨦"))
	#hostname = response.headers[l1111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㨧")]
	#hostname = hostname.strip(l1111_l1_ (u"࠭࠯ࠨ㨨"))
	#l1llll1lll_l1_ = l1ll11l_l1_
	#url = l1llll1lll_l1_+l1111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ㨩")
	#url = l1llll1lll_l1_
	#response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㨪"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪ㨫"),l1111_l1_ (u"ࠪࠫ㨬"),l1111_l1_ (u"ࠫࠬ㨭"),l1111_l1_ (u"ࠬ࠭㨮"),l1111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㨯"))
	#l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㨰"),menu_name+l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋ีอࠠศๆ่์็฿ࠠๆ฼็ๆࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㨱"),l1111_l1_ (u"ࠩࠪ㨲"),8)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㨳"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㨴"),l1111_l1_ (u"ࠬ࠭㨵"),9999)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㨶"),menu_name+l1111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㨷"),l1ll11l_l1_,369,l1111_l1_ (u"ࠨࠩ㨸"),l1111_l1_ (u"ࠩࠪ㨹"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㨺"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㨻"),menu_name+l1111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ㨼"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭㨽"),364)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㨾"),menu_name+l1111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ㨿"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ㩀"),365)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㩁"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㩂"),l1111_l1_ (u"ࠬ࠭㩃"),9999)
	#l1l1lll11_l1_ = {l1111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㩄"):hostname,l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㩅"):l1111_l1_ (u"ࠨࠩ㩆")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1111_l1_ (u"ࠩ࡟࠳ࠬ㩇"),l1111_l1_ (u"ࠪ࠳ࠬ㩈"))
	#l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࡥࡥࡷ࠮࠮ࠫࡁࠬࡪ࡮ࡲࡴࡦࡴࠪ㩉"),html,re.DOTALL)
	#if l111l1l_l1_:
	#	block = l111l1l_l1_[0]
	#	items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㩊"),block,re.DOTALL)
	#	for l1l111l_l1_,title in items:
	#		if l1111_l1_ (u"࠭ࠥࡥ࠻ࠨ࠼࠺ࠫࡤ࠹ࠧࡥ࠹ࠪࡪ࠸ࠦࡣ࠺ࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡢ࠺ࠧࡧ࠼ࠪࡧ࠹࠮ࠧࡧ࠼ࠪࡧࡤࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡥ࠾࠭㩋") in l1l111l_l1_: continue
	#		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩌"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ㩍")+menu_name+title,l1l111l_l1_,366)
	#	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㩎"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㩏"),l1111_l1_ (u"ࠫࠬ㩐"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ㩑"),l1ll11l_l1_,l1111_l1_ (u"࠭ࠧ㩒"),l1111_l1_ (u"ࠧࠨ㩓"),l1111_l1_ (u"ࠨࠩ㩔"),l1111_l1_ (u"ࠩࠪ㩕"),l1111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ㩖"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡳࡍ࡫ࡶࡸࡇࡻࡴࡵࡱࡱࠦࠬ㩗"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㩘"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㩙") not in l1l111l_l1_:
			#	server = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ㩚"))
			#	l1l111l_l1_ = l1l111l_l1_.replace(server,l1llll1lll_l1_)
			if title==l1111_l1_ (u"ࠨࠩ㩛"): continue
			if any(value in title.lower() for value in l11ll11_l1_): continue
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㩜"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㩝")+menu_name+title,l1l111l_l1_,366)
		l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㩞"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㩟"),l1111_l1_ (u"࠭ࠧ㩠"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠮࠮ࠫࡁࠬ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠩ㩡"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㩢"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㩣"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㩤")+menu_name+title,l1l111l_l1_,366,img)
	return html
def l11lll1l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㩥"),l1111_l1_ (u"ࠬ࠭㩦"),url,l1111_l1_ (u"࠭ࠧ㩧"))
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㩨"):url,l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㩩"):l1111_l1_ (u"ࠩࠪ㩪")}
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ㩫"),url,l1111_l1_ (u"ࠫࠬ㩬"),l1111_l1_ (u"ࠬ࠭㩭"),l1111_l1_ (u"࠭ࠧ㩮"),l1111_l1_ (u"ࠧࠨ㩯"),l1111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㩰"))
	html = response.content
	#l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㩱"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭㩲"),url,364)
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩳"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ㩴"),url,365)
	if l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠭㩵") in html:
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩶"),menu_name+l1111_l1_ (u"ࠨษ็้๊๐าสࠩ㩷"),url,361,l1111_l1_ (u"ࠩࠪ㩸"),l1111_l1_ (u"ࠪࠫ㩹"),l1111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㩺"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭㩻"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㩼"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩽"),menu_name+title,l1l111l_l1_,361)
	return
def l1l11l1_l1_(l1l1l1llll11_l1_,type=l1111_l1_ (u"ࠨࠩ㩾")):
	if l1111_l1_ (u"ࠩ࠽࠾ࠬ㩿") in l1l1l1llll11_l1_:
		l11l11_l1_,url = l1l1l1llll11_l1_.split(l1111_l1_ (u"ࠪ࠾࠿࠭㪀"))
		server = l1l1lll1l_l1_(l11l11_l1_,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ㪁"))
		url = server+url
	else: url,l11l11_l1_ = l1l1l1llll11_l1_,l1l1l1llll11_l1_
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㪂"):l11l11_l1_,l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㪃"):l1111_l1_ (u"ࠧࠨ㪄")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㪅"),url,l1111_l1_ (u"ࠩࠪ㪆"),l1111_l1_ (u"ࠪࠫ㪇"),l1111_l1_ (u"ࠫࠬ㪈"),l1111_l1_ (u"ࠬ࠭㪉"),l1111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ㪊"))
	html = response.content
	if type==l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㪋"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ㪌"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ㪍"):
		l111l1l_l1_ = [html.replace(l1111_l1_ (u"ࠪࡠࡡ࠵ࠧ㪎"),l1111_l1_ (u"ࠫ࠴࠭㪏")).replace(l1111_l1_ (u"ࠬࡢ࡜ࠣࠩ㪐"),l1111_l1_ (u"࠭ࠢࠨ㪑"))]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡈࡴ࡬ࡨ࠲࠳ࡍࡺࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ㪒"),html,re.DOTALL)
	l1lllll1_l1_ = []
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ㪓"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			if any(value in title.lower() for value in l11ll11_l1_): continue
			img = escapeUNICODE(img)
			title = l1l1111_l1_(title)
			title = escapeUNICODE(title)
			title = title.replace(l1111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ㪔"),l1111_l1_ (u"ࠪࠫ㪕"))
			if l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭㪖") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㪗"),menu_name+title,l1l111l_l1_,363,img)
			elif l1111_l1_ (u"࠭อๅไฬࠫ㪘") in title:
				l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ㪙"),title,re.DOTALL)
				if l11l11l_l1_: title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㪚") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1lllll1_l1_.append(title)
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㪛"),menu_name+title,l1l111l_l1_,363,img)
			else:
				l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㪜"),menu_name+title,l1l111l_l1_,362,img)
		if type==l1111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ㪝"):
			l1l1l1lll1ll_l1_ = re.findall(l1111_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ㪞"),block,re.DOTALL)
			if l1l1l1lll1ll_l1_:
				count = l1l1l1lll1ll_l1_[0]
				l1l111l_l1_ = url+l1111_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ㪟")+count
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪠"),menu_name+l1111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ㪡"),l1l111l_l1_,361,l1111_l1_ (u"ࠩࠪ㪢"),l1111_l1_ (u"ࠪࠫ㪣"),l1111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ㪤"))
		elif type==l1111_l1_ (u"ࠬ࠭㪥"):
			l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㪦"),html,re.DOTALL)
			if l111l1l_l1_:
				block = l111l1l_l1_[0]
				items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㪧"),block,re.DOTALL)
				for l1l111l_l1_,title in items:
					title = l1111_l1_ (u"ࠨืไัฮࠦࠧ㪨")+l1l1111_l1_(title)
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㪩"),menu_name+title,l1l111l_l1_,361)
	return
def l1l11ll_l1_(url,type=l1111_l1_ (u"ࠪࠫ㪪")):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ㪫"),url,l1111_l1_ (u"ࠬ࠭㪬"),l1111_l1_ (u"࠭ࠧ㪭"),l1111_l1_ (u"ࠧࠨ㪮"),l1111_l1_ (u"ࠨࠩ㪯"),l1111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㪰"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡩࡵࡧࡰࠦࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠪ࠱࠮ࡄ࠯ࠢࠨ㪱"),html,re.DOTALL)
	if name: name = name[-1].replace(l1111_l1_ (u"ࠫ࠲࠭㪲"),l1111_l1_ (u"ࠬࠦࠧ㪳")).strip(l1111_l1_ (u"࠭࠯ࠨ㪴"))
	if l1111_l1_ (u"ࠧๆ๊ึ้ࠬ㪵") in name and type==l1111_l1_ (u"ࠨࠩ㪶"):
		name = name.split(l1111_l1_ (u"่ࠩ์ุ๋ࠧ㪷"))[0]
		name = name.replace(l1111_l1_ (u"ู้ࠪอ็ะหࠪ㪸"),l1111_l1_ (u"ࠫࠬ㪹")).strip(l1111_l1_ (u"ࠬࠦࠧ㪺"))
	elif l1111_l1_ (u"࠭อๅไฬࠫ㪻") in name:
		name = name.split(l1111_l1_ (u"ࠧฮๆๅอࠬ㪼"))[0]
		name = name.replace(l1111_l1_ (u"ࠨ็ืห์ีษࠨ㪽"),l1111_l1_ (u"ࠩࠪ㪾")).strip(l1111_l1_ (u"ࠪࠤࠬ㪿"))
	else: name = name
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵ࡬ࡲ࡬ࡲࡥࡴࡧࡦࡸ࡮ࡵ࡮ࠨ㫀"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		if type==l1111_l1_ (u"ࠬ࠭㫁"):
			items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㫂"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭㫃") in title: continue
				if l1111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩ㫄") in title: continue
				title = name+l1111_l1_ (u"ࠩࠣ࠱ࠥ࠭㫅")+title
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㫆"),menu_name+title,l1l111l_l1_,363,l1111_l1_ (u"ࠫࠬ㫇"),l1111_l1_ (u"ࠬ࠭㫈"),l1111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㫉"))
		if len(menuItemsLIST)==0:
			l111ll1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠬࠦࠨ㫊"),block+l1111_l1_ (u"ࠨࠨࠩࠫ㫋"),re.DOTALL)
			if l111ll1l_l1_: block = l111ll1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㫌"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				title = title.strip(l1111_l1_ (u"ࠪࠤࠬ㫍"))
				title = name+l1111_l1_ (u"ࠫࠥ࠳ࠠࠨ㫎")+title
				l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㫏"),menu_name+title,l1l111l_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㫐"),html,re.DOTALL)
		if title: title = title[0].replace(l1111_l1_ (u"ࠧࠡ࠯้ࠣฬ๐ࠠิ์่หࠬ㫑"),l1111_l1_ (u"ࠨࠩ㫒")).replace(l1111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ㫓"),l1111_l1_ (u"ࠪࠫ㫔"))
		else: title = l1111_l1_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ㫕")
		l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㫖"),menu_name+title,url,362)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ㫗"),url,l1111_l1_ (u"ࠧࠨ㫘"),l1111_l1_ (u"ࠨࠩ㫙"),l1111_l1_ (u"ࠩࠪ㫚"),l1111_l1_ (u"ࠪࠫ㫛"),l1111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㫜"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂฬ๊สึ่ํๅࡁ࠴ࠪࡀ࠾ࡤ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㫝"),html,re.DOTALL)
	if l1llll_l1_:
		l1llll_l1_ = [l1llll_l1_[0][0],l1llll_l1_[0][1]]
		if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡋ࡭ࡣࡧࡧࠦࠬ㫞"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ㫟"),block,re.DOTALL)
		for l1l111l_l1_,name in items:
			if l1111_l1_ (u"ࠨࡪࡷࡸࡵ࠭㫠") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if name==l1111_l1_ (u"ࠩึ๎ึ็ัࠡ็ส๎ู๊ࠥๆษࠪ㫡"): name = l1111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ㫢")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㫣")+name+l1111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㫤")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㫥"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ㫦"),block,re.DOTALL)
		for l1l111l_l1_,l11l1111_l1_ in items:
			if l1111_l1_ (u"ࠨࡪࡷࡸࡵ࠭㫧") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ㫨"),l11l1111_l1_,re.DOTALL)
			if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ㫩")+l11l1111_l1_[0]
			else: l11l1111_l1_ = l1111_l1_ (u"ࠫࠬ㫪")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡳࡹࡤ࡫ࡰࡥࠬ㫫")+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㫬")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ㫭"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㫮"),url)
	return
def l1lll1_l1_(search,hostname=l1111_l1_ (u"ࠩࠪ㫯")):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫ㫰"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬ㫱"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧ㫲"),l1111_l1_ (u"࠭ࠫࠨ㫳"))
	l11lll1l_l1_ = [l1111_l1_ (u"ࠧ࠰ࠩ㫴"),l1111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ㫵"),l1111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ㫶"),l1111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ㫷"),l1111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ㫸")]
	l1ll11l1l1l_l1_ = [l1111_l1_ (u"ࠬอไฤใ็ห๊࠭㫹"),l1111_l1_ (u"࠭วๅ็ึุ่๊วหࠩ㫺"),l1111_l1_ (u"ࠧศๆส๊๏๋๊๊ࠡࠣห้้ัห๊้ࠫ㫻"),l1111_l1_ (u"ࠨษ็ฬึอๅอࠢอ่๏็า๋๊้๎ฮ࠭㫼"),l1111_l1_ (u"ࠩ฽๎ึࠦๅฮัาࠫ㫽")]
	if l1ll11_l1_:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪหำะัࠡษ็๊ํ฿ࠠศๆ่฻้๎ศ࠻ࠩ㫾"), l1ll11l1l1l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 4
	if hostname==l1111_l1_ (u"ࠫࠬ㫿"):
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ㬀"),l1ll11l_l1_,l1111_l1_ (u"࠭ࠧ㬁"),l1111_l1_ (u"ࠧࠨ㬂"),False,l1111_l1_ (u"ࠨࠩ㬃"),l1111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㬄"))
		hostname = response.headers[l1111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㬅")]
		hostname = hostname.strip(l1111_l1_ (u"ࠫ࠴࠭㬆"))
	l1l1lll_l1_ = hostname+l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ㬇")+search+l11lll1l_l1_[l1l_l1_]
	l1l11l1_l1_(l1l1lll_l1_)
	return
def l1llllll_l1_(l1l1l1llll11_l1_,filter):
	if l1111_l1_ (u"࠭࠿ࡀࠩ㬈") in l1l1l1llll11_l1_: url = l1l1l1llll11_l1_.split(l1111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭㬉"))[0]
	else: url = l1l1l1llll11_l1_
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㬊"):l1l1l1llll11_l1_,l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㬋"):l1111_l1_ (u"ࠪࠫ㬌")}
	filter = filter.replace(l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㬍"),l1111_l1_ (u"ࠬ࠭㬎"))
	type,filter = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪ㬏"),1)
	if filter==l1111_l1_ (u"ࠧࠨ㬐"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠨࠩ㬑"),l1111_l1_ (u"ࠩࠪ㬒")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠪࡣࡤࡥࠧ㬓"))
	if type==l1111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ㬔"):
		if l1l11l11l_l1_[0]+l1111_l1_ (u"ࠬࡃ࠽ࠨ㬕") not in l1l11lll_l1_: category = l1l11l11l_l1_[0]
		for i in range(len(l1l11l11l_l1_[0:-1])):
			if l1l11l11l_l1_[i]+l1111_l1_ (u"࠭࠽࠾ࠩ㬖") in l1l11lll_l1_: category = l1l11l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠧࠧࠨࠪ㬗")+category+l1111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ㬘")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ㬙")+category+l1111_l1_ (u"ࠪࡁࡂ࠶ࠧ㬚")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠫࠫࠬࠧ㬛"))+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ㬜")+l1ll11l1_l1_.strip(l1111_l1_ (u"࠭ࠦࠧࠩ㬝"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ㬞"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ㬟")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ㬠"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ㬡"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠫࠬ㬢"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ㬣"))
		if l1l11ll1_l1_==l1111_l1_ (u"࠭ࠧ㬤"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭㬥")+l1l11ll1_l1_
		l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_,l1l1l1llll11_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㬦"),menu_name+l1111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ㬧"),l1llllll1_l1_,361,l1111_l1_ (u"ࠪࠫ㬨"),l1111_l1_ (u"ࠫࠬ㬩"),l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭㬪"))
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㬫"),menu_name+l1111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ㬬")+l11lll11_l1_+l1111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ㬭"),l1llllll1_l1_,361,l1111_l1_ (u"ࠩࠪ㬮"),l1111_l1_ (u"ࠪࠫ㬯"),l1111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ㬰"))
		l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㬱"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㬲"),l1111_l1_ (u"ࠧࠨ㬳"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㬴"),url,l1111_l1_ (u"ࠩࠪ㬵"),l1111_l1_ (u"ࠪࠫ㬶"),l1111_l1_ (u"ࠫࠬ㬷"),l1111_l1_ (u"ࠬ࠭㬸"),l1111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㬹"))
	html = response.content
	html = html.replace(l1111_l1_ (u"ࠧ࡝࡞ࠥࠫ㬺"),l1111_l1_ (u"ࠨࠤࠪ㬻")).replace(l1111_l1_ (u"ࠩ࡟ࡠ࠴࠭㬼"),l1111_l1_ (u"ࠪ࠳ࠬ㬽"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡁࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ㬾"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ㬿"),block+l1111_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ㭀"),re.DOTALL)
	dict = {}
	for l1lll1ll_l1_,name,block in l111111_l1_:
		name = escapeUNICODE(name)
		if l1111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ㭁") in l1lll1ll_l1_: continue
		items = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ㭂"),block,re.DOTALL)
		if l1111_l1_ (u"ࠩࡀࡁࠬ㭃") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ㭄"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ㭅")+l1l1l1ll_l1_)
				return
			else:
				l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_,l1l1l1llll11_l1_)
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]:
					l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㭆"),menu_name+l1111_l1_ (u"࠭วๅฮ่๎฾࠭㭇"),l1llllll1_l1_,361,l1111_l1_ (u"ࠧࠨ㭈"),l1111_l1_ (u"ࠨࠩ㭉"),l1111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ㭊"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㭋"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ㭌"),l1l1lll_l1_,364,l1111_l1_ (u"ࠬ࠭㭍"),l1111_l1_ (u"࠭ࠧ㭎"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ㭏"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠩࠫ㭐")+l1lll1ll_l1_+l1111_l1_ (u"ࠩࡀࡁ࠵࠭㭑")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠫ࠭㭒")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂࡃ࠰ࠨ㭓")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ㭔")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㭕"),menu_name+name+l1111_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ㭖"),l1l1lll_l1_,365,l1111_l1_ (u"ࠨࠩ㭗"),l1111_l1_ (u"ࠩࠪ㭘"),l1l1l1ll_l1_+l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㭙"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1111_l1_ (u"ࠫࡷ࠭㭚") or value==l1111_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ㭛"): continue
			if any(value in option.lower() for value in l11ll11_l1_): continue
			if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㭜") in option: continue
			if l1111_l1_ (u"ࠧศๆๆ่ࠬ㭝") in option: continue
			if l1111_l1_ (u"ࠨࡰ࠰ࡥࠬ㭞") in value: continue
			#if value in [l1111_l1_ (u"ࠩࡵࠫ㭟"),l1111_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ㭠"),l1111_l1_ (u"ࠫࡹࡼ࠭࡮ࡣࠪ㭡")]: continue
			#if l1lll1ll_l1_==l1111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ㭢"): option = value
			if option==l1111_l1_ (u"࠭ࠧ㭣"): option = value
			l11ll11ll_l1_ = option
			l1ll1111111_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ㭤"),option,re.DOTALL)
			if l1ll1111111_l1_: l11ll11ll_l1_ = l1ll1111111_l1_[0]
			title2 = name+l1111_l1_ (u"ࠨ࠼ࠣࠫ㭥")+l11ll11ll_l1_
			dict[l1lll1ll_l1_][value] = title2
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ㭦")+l1lll1ll_l1_+l1111_l1_ (u"ࠪࡁࡂ࠭㭧")+l11ll11ll_l1_
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠫࠫࠬࠧ㭨")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃ࠽ࠨ㭩")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ㭪")+l1ll11l1_l1_
			if type==l1111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ㭫"):
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㭬"),menu_name+title2,url,365,l1111_l1_ (u"ࠩࠪ㭭"),l1111_l1_ (u"ࠪࠫ㭮"),l1lll1l1_l1_+l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㭯"))
			elif type==l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ㭰") and l1l11l11l_l1_[-2]+l1111_l1_ (u"࠭࠽࠾ࠩ㭱") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ㭲"))
				#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ㭳"),l1111_l1_ (u"ࠩࠪ㭴"),l1l111l1_l1_,l1ll11l1_l1_)
				l11l11_l1_ = url+l1111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ㭵")+l1l111l1_l1_
				l1llllll1_l1_ = l11lllll1_l1_(l11l11_l1_,l1l1l1llll11_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㭶"),menu_name+title2,l1llllll1_l1_,361,l1111_l1_ (u"ࠬ࠭㭷"),l1111_l1_ (u"࠭ࠧ㭸"),l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ㭹"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㭺"),menu_name+title2,url,364,l1111_l1_ (u"ࠩࠪ㭻"),l1111_l1_ (u"ࠪࠫ㭼"),l1lll1l1_l1_)
	return
l1l11l11l_l1_ = [l1111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ㭽"),l1111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ㭾"),l1111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭㭿")]
l1l111ll1_l1_ = [l1111_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ㮀"),l1111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ㮁"),l1111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ㮂"),l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ㮃"),l1111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ㮄"),l1111_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ㮅"),l1111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭㮆"),l1111_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ㮇")]
def l11lllll1_l1_(l1l1lll_l1_,l11l11_l1_):
	if l1111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ㮈") in l1l1lll_l1_: l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ㮉"),l1111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ㮊"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ㮋"),l1111_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ㮌"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"࠭࠽࠾ࠩ㮍"),l1111_l1_ (u"ࠧ࠰ࠩ㮎"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠨࠨࠩࠫ㮏"),l1111_l1_ (u"ࠩ࠲ࠫ㮐"))
	return l1l1lll_l1_
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㮑"),l1111_l1_ (u"ࠫࠬ㮒"),filters,l1111_l1_ (u"ࠬࡏࡎࠡࠢࠣࠤࠬ㮓")+mode)
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ㮔")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ㮕")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࠬ㮖")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	filters = filters.strip(l1111_l1_ (u"ࠩࠩࠪࠬ㮗"))
	l1l1l111_l1_,l1lll11l_l1_ = {},l1111_l1_ (u"ࠪࠫ㮘")
	if l1111_l1_ (u"ࠫࡂࡃࠧ㮙") in filters:
		items = filters.split(l1111_l1_ (u"ࠬࠬࠦࠨ㮚"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"࠭࠽࠾ࠩ㮛"))
			l1l1l111_l1_[var] = value
	for key in l1l111ll1_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠧ࠱ࠩ㮜")
		if l1111_l1_ (u"ࠨࠧࠪ㮝") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ㮞") and value!=l1111_l1_ (u"ࠪ࠴ࠬ㮟"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠫࠥ࠱ࠠࠨ㮠")+value
		elif mode==l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ㮡") and value!=l1111_l1_ (u"࠭࠰ࠨ㮢"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠧࠧࠨࠪ㮣")+key+l1111_l1_ (u"ࠨ࠿ࡀࠫ㮤")+value
		elif mode==l1111_l1_ (u"ࠩࡤࡰࡱ࠭㮥"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠪࠪࠫ࠭㮦")+key+l1111_l1_ (u"ࠫࡂࡃࠧ㮧")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠬࠦࠫࠡࠩ㮨"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"࠭ࠦࠧࠩ㮩"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㮪"),l1111_l1_ (u"ࠨࠩ㮫"),l1lll11l_l1_,l1111_l1_ (u"ࠩࡒ࡙࡙࠭㮬"))
	return l1lll11l_l1_
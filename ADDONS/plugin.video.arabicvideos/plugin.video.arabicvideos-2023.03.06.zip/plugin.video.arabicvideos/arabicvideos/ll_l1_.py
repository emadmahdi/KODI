# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
#
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㹡")
#l1l11ll1ll1l_l1_ = [ l1111_l1_ (u"ࠪࡱࡾࡹࡴࡳࡧࡤࡱࠬ㹢"),l1111_l1_ (u"ࠫࡻ࡯࡭ࡱ࡮ࡨࠫ㹣"),l1111_l1_ (u"ࠬࡼࡩࡥࡤࡲࡱࠬ㹤"),l1111_l1_ (u"࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫ㹥") ]
l1l11ll1ll1l_l1_ = []
headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㹦"):l1111_l1_ (u"ࠨࠩ㹧")}
def l11_l1_(l11ll1l_l1_,l111_l1_=l1111_l1_ (u"ࠩࠪ㹨"),type=l1111_l1_ (u"ࠪࠫ㹩"),url=l1111_l1_ (u"ࠫࠬ㹪")):
	#l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ืวษูࠣห้๋ๆศีหࠫ㹫"),l11ll1l_l1_)
	if not l11ll1l_l1_:
		LOG_THIS(l1111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㹬"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ㹭")+l111_l1_+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ㹮")+type+l1111_l1_ (u"ࠩࠣࡡࠬ㹯"))
		l11l1ll1ll11_l1_ = READ_FROM_SQL3(cache_dbfile,l1111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㹰"),l1111_l1_ (u"ࠫࡒࡏࡓࡄࠩ㹱"),l1111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ㹲"))
		datetime = time.strftime(l1111_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ㹳"),time.gmtime(now))
		line = datetime,url
		key = l111_l1_+l1111_l1_ (u"ࠧࠡࠢࠣࠤࠬ㹴")+l111lll11ll_l1_+l1111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㹵")+str(kodi_version)
		if key not in list(l11l1ll1ll11_l1_.keys()): l11l1ll1ll11_l1_[key] = [line]
		else: l11l1ll1ll11_l1_[key].append(line)
		total = 0
		for key in list(l11l1ll1ll11_l1_.keys()):
			l11l1ll1ll11_l1_[key] = list(set(l11l1ll1ll11_l1_[key]))
			total += len(l11l1ll1ll11_l1_[key])
		l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㹶"),l1111_l1_ (u"ࠪࠫ㹷"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㹸"),l1111_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํࠦ࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠹ࠣๅ๏ี๊้้สฮࠬ㹹")+l1111_l1_ (u"࠭࡜࡯࡞ࡱࠫ㹺")+l1111_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪ㹻")+str(total))
		if total>=7:
			l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠨࠩ㹼"),l1111_l1_ (u"ࠩࠪ㹽"),l1111_l1_ (u"ࠪࠫ㹾"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㹿"),l1111_l1_ (u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠹ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭㺀"))
			if l1l1l1l111_l1_==1:
				l11l1lll111l_l1_ = l1111_l1_ (u"࠭ࠧ㺁")
				for key in list(l11l1ll1ll11_l1_.keys()):
					l11l1lll111l_l1_ += l1111_l1_ (u"ࠧ࡝ࡰࠪ㺂")+key
					l1l11llll1l1_l1_ = sorted(l11l1ll1ll11_l1_[key],reverse=False,key=lambda l11l1l1l1l1l_l1_: l11l1l1l1l1l_l1_[0])
					for datetime,url in l1l11llll1l1_l1_:
						l11l1lll111l_l1_ += l1111_l1_ (u"ࠨ࡞ࡱࠫ㺃")+datetime+l1111_l1_ (u"ࠩࠣࠤࠥࠦࠧ㺄")+UNQUOTE(url)
					l11l1lll111l_l1_ += l1111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㺅")
				import l1l1l1l1l11_l1_
				l1lll1ll1lll_l1_ = l1111_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ㺆")+l11ll1lll11_l1_(32)+l1111_l1_ (u"ࠬ࠳ࡖࡪࡦࡨࡳࡸ࠭㺇")
				succeeded = l1l1l1l1l11_l1_.l111llll1l1_l1_(l1lll1ll1lll_l1_,l1111_l1_ (u"࠭ࠧ㺈"),False,l1111_l1_ (u"ࠧࠨ㺉"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㺊"),l1111_l1_ (u"ࠩࠪ㺋"),l11l1lll111l_l1_)
				if succeeded: l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㺌"),l1111_l1_ (u"ࠫࠬ㺍"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㺎"),l1111_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ㺏"))
				else: l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㺐"),l1111_l1_ (u"ࠨࠩ㺑"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㺒"),l1111_l1_ (u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨ㺓"))
			if l1l1l1l111_l1_!=-1:
				l11l1ll1ll11_l1_ = {}
				l1ll1lll11l_l1_(cache_dbfile,l1111_l1_ (u"ࠫࡒࡏࡓࡄࠩ㺔"),l1111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ㺕"))
		if l11l1ll1ll11_l1_: l1ll11lllll_l1_(cache_dbfile,l1111_l1_ (u"࠭ࡍࡊࡕࡆࠫ㺖"),l1111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭㺗"),l11l1ll1ll11_l1_,l1l1llll11l_l1_)
		return
	l11ll1l_l1_ = list(set(l11ll1l_l1_))
	l11111l_l1_,l11lll1l_l1_ = l11l1l11l111_l1_(l11ll1l_l1_)
	l1l111l11l1l_l1_ = str(l11lll1l_l1_).count(l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㺘"))
	l11ll111l111_l1_ = str(l11lll1l_l1_).count(l1111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㺙"))
	l1l111l11lll_l1_ = len(l11lll1l_l1_)-l1l111l11l1l_l1_-l11ll111l111_l1_
	l11l1lll1l1l_l1_ = l1111_l1_ (u"ู้ࠪอ็ะห࠽ࠫ㺚")+str(l1l111l11l1l_l1_)+l1111_l1_ (u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨ㺛")+str(l11ll111l111_l1_)+l1111_l1_ (u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨ㺜")+str(l1l111l11lll_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㺝"),l1111_l1_ (u"ࠧࠨ㺞"),str(l1l111l11l1l_l1_),str(l11ll111l111_l1_))
	#l1l_l1_ = l11llll_l1_(l11l1lll1l1l_l1_, l11lll1l_l1_)
	if not l11lll1l_l1_:
		result = l1111_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㺟")
		l1l11l111111_l1_ = l1111_l1_ (u"ࠩࠪ㺠")
	else:
		while True:
			l1l11l111111_l1_ = l1111_l1_ (u"ࠪࠫ㺡")
			if len(l11lll1l_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = l11llll_l1_(l11l1lll1l1l_l1_,l11111l_l1_)
			if l1l_l1_==-1: result = l1111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ㺢")
			else:
				title = l11111l_l1_[l1l_l1_]
				l1l111l_l1_ = l11lll1l_l1_[l1l_l1_]
				#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㺣"),l1111_l1_ (u"࠭ࠧ㺤"),title,l1l111l_l1_)
				if l1111_l1_ (u"ࠧิ์ิๅึ࠭㺥") in title and l1111_l1_ (u"ࠨ࠴่ะ์๎ไ࠳ࠩ㺦") in title:
					LOG_THIS(l1111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㺧"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠪࠤࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ㺨")+title+l1111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ㺩")+l1l111l_l1_+l1111_l1_ (u"ࠬࠦ࡝ࠨ㺪"))
					import l1l1l1l1l11_l1_
					l1l1l1l1l11_l1_.l1111ll_l1_(156)
					result = l1111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㺫")
				else:
					LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㺬"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭㺭")+title+l1111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ㺮")+l1l111l_l1_+l1111_l1_ (u"ࠪࠤࡢ࠭㺯"))
					result,l1l11l111111_l1_,l1l1ll111l1l_l1_ = l11ll1lll1ll_l1_(l1l111l_l1_,l111_l1_,type)
					#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㺰"),l1111_l1_ (u"ࠬ࠭㺱"),result,l1l11l111111_l1_)
			if l1111_l1_ (u"࠭࡜࡯ࠩ㺲") not in l1l11l111111_l1_: l11ll1ll1lll_l1_,l11l11lll11_l1_ = l1l11l111111_l1_,l1111_l1_ (u"ࠧࠨ㺳")
			else: l11ll1ll1lll_l1_,l11l11lll11_l1_ = l1l11l111111_l1_.split(l1111_l1_ (u"ࠨ࡞ࡱࠫ㺴"),1)
			if result in [l1111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ㺵"),l1111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㺶"),l1111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㺷"),l1111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ㺸")] or len(l11lll1l_l1_)==1: break
			elif result in [l1111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㺹"),l1111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ㺺"),l1111_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㺻")]: break
			elif result not in [l1111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭㺼"),l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㺽")]: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㺾"),l1111_l1_ (u"ࠬ࠭㺿"),l1111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㻀"),l1111_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ㻁")+l1111_l1_ (u"ࠨ࡞ࡱࠫ㻂")+l11ll1ll1lll_l1_+l1111_l1_ (u"ࠩ࡟ࡲࠬ㻃")+l11l11lll11_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㻄"),l1111_l1_ (u"ࠫࠬ㻅"),l1111_l1_ (u"ࠬ࠭㻆"),str(l1l1ll111l1l_l1_))
	if result==l1111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㻇") and len(l11111l_l1_)>0: l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㻈"),l1111_l1_ (u"ࠨࠩ㻉"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㻊"),l1111_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ㻋")+l1111_l1_ (u"ࠫࡡࡴࠧ㻌")+l1l11l111111_l1_)
	elif result in [l1111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㻍"),l1111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㻎")] and l1l11l111111_l1_!=l1111_l1_ (u"ࠧࠨ㻏"): l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ㻐"),l1111_l1_ (u"ࠩࠪ㻑"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㻒"),l1l11l111111_l1_)
	#elif l1l11l111111_l1_==l1111_l1_ (u"ࠫࡗࡋࡔࡖࡔࡑࡣ࡙ࡕ࡟࡚ࡑࡘࡘ࡚ࡈࡅࠨ㻓"): result = l1l1ll111l1l_l1_
	l1111_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࡳࡧࡶࡹࡱࡺࠠࡪࡰࠣ࡟ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ࠯ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ࡟࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡖࡨࡷࡹࡀࠠࠡࠢࠪ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠰࡞࠭ࡶࡽࡸ࠴ࡡࡳࡩࡹ࡟࠷ࡣࠩࠋࠋࠌࡼࡧࡳࡣࡱ࡮ࡸ࡫࡮ࡴ࠮ࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࡣࡧࡨࡴࡴ࡟ࡩࡣࡱࡨࡱ࡫ࠬࠡࡈࡤࡰࡸ࡫ࠬࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬ࠮࠯ࠊࠊࠋࡳࡰࡦࡿ࡟ࡪࡶࡨࡱࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫࡴࡦࡺࡨ࠾ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠱ࡂࡱࡴࡪࡥ࠾࠳࠷࠷ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࠩ࠸ࡌࡶࠦ࠵ࡇ࡫ࡼࡨ࠱ࡱࡺ࡙ࡸࡼ࠿ࡑࠨࠫࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡶ࡬ࡢࡻࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࡬ࡷ࠳࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳ࠯ࡪࡲ࡫ࡳࡳ࡫࠯࠲࠴࠶࠸࠹࠽࠮࡮ࡲ࠷ࠫ࠱ࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠪࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨฬ่ࠤฬ๊วๅ฼สลࠬ࠲ࠧࠨࠫࠍࠍࠧࠨࠢ㻔")
	return result
	#if l111_l1_==l1111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㻕"): menu_name=l1111_l1_ (u"ࠧࡉࡎࡄࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㻖")
	#elif l111_l1_==l1111_l1_ (u"ࠨ࠶ࡋࡉࡑࡇࡌࠨ㻗"): menu_name=l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡍࡋࡌࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㻘")
	#elif l111_l1_==l1111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㻙"): menu_name=l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡁࡌࡏࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㻚")
	#elif l111_l1_==l1111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㻛"): menu_name=l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡕࡋ࠸ࠥ࠭㻜")
	#size = len(l1ll1lll1l_l1_)
	#for i in range(0,size):
	#	title = l1l111ll1l1l_l1_[i]
	#	l1l111l_l1_ = l1ll1lll1l_l1_[i]
	#	l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㻝"),menu_name+title,l1l111l_l1_,160,l1111_l1_ (u"ࠨࠩ㻞"),l1111_l1_ (u"ࠩࠪ㻟"),l111_l1_)
def l11ll1lll1ll_l1_(url,l111_l1_,type=l1111_l1_ (u"ࠪࠫ㻠")):
	url = url.strip(l1111_l1_ (u"ࠫࠥ࠭㻡")).strip(l1111_l1_ (u"ࠬࠬࠧ㻢")).strip(l1111_l1_ (u"࠭࠿ࠨ㻣")).strip(l1111_l1_ (u"ࠧ࠰ࠩ㻤"))
	l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111l11l11_l1_(url)
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ㻥"),l1111_l1_ (u"ࠩࠪ㻦"),url,l1l11l111111_l1_)
	if l1l11l111111_l1_==l1111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ㻧"): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	elif l11lll1l_l1_:
		while True:
			if len(l11lll1l_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㻨"), l11111l_l1_)
			if l1l_l1_==-1: result = l1111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ㻩")
			else:
				l1l11ll1lll1_l1_ = l11lll1l_l1_[l1l_l1_]
				title = l11111l_l1_[l1l_l1_]
				LOG_THIS(l1111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㻪"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭㻫")+title+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㻬")+str(l1l11ll1lll1_l1_)+l1111_l1_ (u"ࠩࠣࡡࠬ㻭"))
				if l1111_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭㻮") in l1l11ll1lll1_l1_ and l1111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ㻯") in l1l11ll1lll1_l1_:
					l1l11lll1lll_l1_,l1l1l1llllll_l1_,l1l1ll111l1l_l1_ = l11ll11l1111_l1_(l1l11ll1lll1_l1_)
					if l1l1ll111l1l_l1_: l1l11ll1lll1_l1_ = l1l1ll111l1l_l1_[0]
					else: l1l11ll1lll1_l1_ = l1111_l1_ (u"ࠬ࠭㻰")
				if not l1l11ll1lll1_l1_: result = l1111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㻱")
				else: result = l1ll11ll1_l1_(l1l11ll1lll1_l1_,l111_l1_,type)
			if result in [l1111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㻲"),l1111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ㻳")] or len(l11lll1l_l1_)==1: break
			elif result in [l1111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㻴"),l1111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㻵"),l1111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㻶")]: break
			else: l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㻷"),l1111_l1_ (u"࠭ࠧ㻸"),l1111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㻹"),l1111_l1_ (u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ㻺"))
	else:
		result = l1111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭㻻")
		l1l1111l1l_l1_ = l1l1l11lll_l1_(url)
		if l1l1111l1l_l1_: result = l1ll11ll1_l1_(url,l111_l1_,type)
	return result,l1l11l111111_l1_,l11lll1l_l1_
	#title = xbmc.getInfoLabel( l1111_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ㻼") )
	#if l1111_l1_ (u"ุࠫ๐ัโำࠣ฽ฬ๋ࠠๆฮ๊์้࠭㻽") in title:
	#	import l1l1l1l1l11_l1_
	#	l1l1l1l1l11_l1_.l1111ll_l1_(156)
	#	return l1111_l1_ (u"ࠬ࠭㻾")
def l11ll1l1lll1_l1_(url):
	# url = url+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㻿")+name+l1111_l1_ (u"ࠧࡠࡡࠪ㼀")+type+l1111_l1_ (u"ࠨࡡࡢࠫ㼁")+l1ll_l1_+l1111_l1_ (u"ࠩࡢࡣࠬ㼂")+l11l1111_l1_
	# url = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹࡅ࡮ࡢ࡯ࡨࡨࡂࡧ࡫ࡸࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢ࠻࠷࠶ࠧ㼃")
	l1l1lll_l1_,l11lllll1111_l1_,server,l11l1l1l1ll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,source = url,l1111_l1_ (u"ࠫࠬ㼄"),l1111_l1_ (u"ࠬ࠭㼅"),l1111_l1_ (u"࠭ࠧ㼆"),l1111_l1_ (u"ࠧࠨ㼇"),l1111_l1_ (u"ࠨࠩ㼈"),l1111_l1_ (u"ࠩࠪ㼉"),l1111_l1_ (u"ࠪࠫ㼊"),l1111_l1_ (u"ࠫࠬ㼋")
	if l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㼌") in url:
		l1l1lll_l1_,l11lllll1111_l1_ = url.split(l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㼍"),1)
		l11lllll1111_l1_ = l11lllll1111_l1_+l1111_l1_ (u"ࠧࡠࡡࠪ㼎")+l1111_l1_ (u"ࠨࡡࡢࠫ㼏")+l1111_l1_ (u"ࠩࡢࡣࠬ㼐")+l1111_l1_ (u"ࠪࡣࡤ࠭㼑")
		l11lllll1111_l1_ = l11lllll1111_l1_.lower()
		name,type,l1ll_l1_,l11l1111_l1_,source = l11lllll1111_l1_.split(l1111_l1_ (u"ࠫࡤࡥࠧ㼒"))[:5]
	if l11l1111_l1_==l1111_l1_ (u"ࠬ࠭㼓"): l11l1111_l1_ = l1111_l1_ (u"࠭࠰ࠨ㼔")
	else: l11l1111_l1_ = l11l1111_l1_.replace(l1111_l1_ (u"ࠧࡱࠩ㼕"),l1111_l1_ (u"ࠨࠩ㼖")).replace(l1111_l1_ (u"ࠩࠣࠫ㼗"),l1111_l1_ (u"ࠪࠫ㼘"))
	l1l1lll_l1_ = l1l1lll_l1_.strip(l1111_l1_ (u"ࠫࡄ࠭㼙")).strip(l1111_l1_ (u"ࠬ࠵ࠧ㼚")).strip(l1111_l1_ (u"࠭ࠦࠨ㼛"))
	server = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠧࡩࡱࡶࡸࠬ㼜"))
	if name: l11l1l1l1ll1_l1_ = name
	elif source: l11l1l1l1ll1_l1_ = source
	else: l11l1l1l1ll1_l1_ = server
	l11l1l1l1ll1_l1_ = l1l1lll1l_l1_(l11l1l1l1ll1_l1_,l1111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㼝"))
	name = name.replace(l1111_l1_ (u"่ࠩฬฬฺัࠨ㼞"),l1111_l1_ (u"ࠪࠫ㼟")).replace(l1111_l1_ (u"ุࠫ๐ัโำࠪ㼠"),l1111_l1_ (u"ࠬ࠭㼡")).replace(l1111_l1_ (u"࠭วๅࠢࠪ㼢"),l1111_l1_ (u"ࠧࠡࠩ㼣")).replace(l1111_l1_ (u"ࠨࠢࠣࠫ㼤"),l1111_l1_ (u"ࠩࠣࠫ㼥"))
	l11lllll1111_l1_ = l11lllll1111_l1_.replace(l1111_l1_ (u"้ࠪออิาࠩ㼦"),l1111_l1_ (u"ࠫࠬ㼧")).replace(l1111_l1_ (u"ู๊ࠬาใิࠫ㼨"),l1111_l1_ (u"࠭ࠧ㼩")).replace(l1111_l1_ (u"ࠧศๆࠣࠫ㼪"),l1111_l1_ (u"ࠨࠢࠪ㼫")).replace(l1111_l1_ (u"ࠩࠣࠤࠬ㼬"),l1111_l1_ (u"ࠪࠤࠬ㼭"))
	l11l1l1l1ll1_l1_ = l11l1l1l1ll1_l1_.replace(l1111_l1_ (u"๊ࠫฮวีำࠪ㼮"),l1111_l1_ (u"ࠬ࠭㼯")).replace(l1111_l1_ (u"࠭ำ๋ำไีࠬ㼰"),l1111_l1_ (u"ࠧࠨ㼱")).replace(l1111_l1_ (u"ࠨษ็ࠤࠬ㼲"),l1111_l1_ (u"ࠩࠣࠫ㼳")).replace(l1111_l1_ (u"ࠪࠤࠥ࠭㼴"),l1111_l1_ (u"ࠫࠥ࠭㼵"))
	return l1l1lll_l1_,l11lllll1111_l1_,server,l11l1l1l1ll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,source
def l1l111l11ll1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㼶"),l1111_l1_ (u"࠭ࠧ㼷"),url,l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ㼸"))
	# l1lll1l1l_l1_	: سيرفر خاص
	# l11lll1llll1_l1_		: سيرفر محدد
	# l11ll1l1llll_l1_		: سيرفر عام معروف
	# l1ll1l1ll_l1_	: سيرفر عام خارجي
	# l1ll1l1llll1_l1_	: سيرفر عام خارجي
	l11ll1lllll1_l1_,name,l1lll1l1l_l1_,l11ll1l1llll_l1_,l1ll1l1ll_l1_,l11lll1llll1_l1_,l1ll1l1llll1_l1_ = l1111_l1_ (u"ࠨࠩ㼹"),l1111_l1_ (u"ࠩࠪ㼺"),None,None,None,None,None
	l1l1lll_l1_,l11lllll1111_l1_,server,l11l1l1l1ll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,source = l11ll1l1lll1_l1_(url)
	if l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㼻") in url:
		if   type==l1111_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ㼼"): type = l1111_l1_ (u"ࠬࠦࠧ㼽")+l1111_l1_ (u"࠭ๅโุ็ࠫ㼾")
		elif type==l1111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭㼿"): type = l1111_l1_ (u"ࠨࠢࠪ㽀")+l1111_l1_ (u"ࠩࠨู้อ็ะหࠪ㽁")
		elif type==l1111_l1_ (u"ࠪࡦࡴࡺࡨࠨ㽂"): type = l1111_l1_ (u"ࠫࠥ࠭㽃")+l1111_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ㽄")
		elif type==l1111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㽅"): type = l1111_l1_ (u"ࠧࠡࠩ㽆")+l1111_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ㽇")
		elif type==l1111_l1_ (u"ࠩࠪ㽈"): type = l1111_l1_ (u"ࠪࠤࠬ㽉")+l1111_l1_ (u"ࠫࠪࠫࠥࠦࠩ㽊")
		if l1ll_l1_!=l1111_l1_ (u"ࠬ࠭㽋"):
			if l1111_l1_ (u"࠭࡭ࡱ࠶ࠪ㽌") not in l1ll_l1_: l1ll_l1_ = l1111_l1_ (u"ࠧࠦࠩ㽍")+l1ll_l1_
			l1ll_l1_ = l1111_l1_ (u"ࠨࠢࠪ㽎")+l1ll_l1_
		if l11l1111_l1_!=l1111_l1_ (u"ࠩࠪ㽏"):
			l11l1111_l1_ = l1111_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭㽐")+l11l1111_l1_
			l11l1111_l1_ = l1111_l1_ (u"ࠫࠥ࠭㽑")+l11l1111_l1_[-9:]
	#if any(value in server for value in l1l11ll1ll1l_l1_): return l1111_l1_ (u"ࠬ࠭㽒")
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㽓"),l1111_l1_ (u"ࠧࠨ㽔"),name,l11l1l1l1ll1_l1_)
	if   l1111_l1_ (u"ࠨࡣ࡮ࡳࡦࡳࠧ㽕")		in source: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㽖")		in source: l1lll1l1l_l1_	= l1111_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ㽗")
	elif l1111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭㽘")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ㽙")		in server: l1lll1l1l_l1_	= l1111_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㽚")
	elif l1111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡳࡵࡣࡷ࡭ࡴࡴࠧ㽛") in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ㽜")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ㽝")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ㽞")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ㽟")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ㽠")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ㽡")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠲ࡩ࡬ࡶࡤࠪ㽢")	in name:   l1lll1l1l_l1_	= l1111_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪ㽣")
	elif l1111_l1_ (u"ࠩไะึ࠭㽤")			in name:   l1lll1l1l_l1_	= l1111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ㽥")
	elif l1111_l1_ (u"ࠫๆ๊ำุ์้ࠫ㽦")		in name:   l1lll1l1l_l1_	= l1111_l1_ (u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨ㽧")
	elif l1111_l1_ (u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭㽨")		in l1l1lll_l1_:   l1lll1l1l_l1_	= l1111_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ㽩")
	elif l1111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㽪")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ㽫")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ㽬")		in name:   l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㽭")	in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ㽮")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ㽯")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭㽰")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ㽱")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ㽲")		in server: l1lll1l1l_l1_	= l11l1l1l1ll1_l1_
	#elif l1111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡳ࡫ࡴࠨ㽳")	in l1l1lll_l1_:   l1lll1l1l_l1_	= l1111_l1_ (u"ࠫࠥ࠭㽴")
	elif l1111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㽵")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨ㽶")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ㽷")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ㽸")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ㽹")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ㽺")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ㽻")	 	in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭㽼")
	elif l1111_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭㽽")	 	in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ㽾")
	elif l1111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭㽿")	in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭㾀")
	elif l1111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ㾁")		in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ㾂")
	elif l1111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ㾃")		in server: l1lll1l1l_l1_	= l1111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ㾄")
	elif l1111_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭㾅")	in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ㾆")
	elif l1111_l1_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬ㾇")	in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯ࠪ㾈")
	elif l1111_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ㾉")		in server: l1lll1l1l_l1_	= l1111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭㾊")
	elif l1111_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ㾋")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ㾌")
	elif l1111_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ㾍")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ㾎")
	elif l1111_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ㾏")	 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠫࡨࡧࡴࡤࡪࠪ㾐")
	elif l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭㾑")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ㾒")
	elif l1111_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭㾓")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ㾔")
	elif l1111_l1_ (u"ࠩࡹ࡭ࡩ࡮ࡤࠨ㾕")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠪࡱࡾࡼࡩࡥࠩ㾖")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠫࡲࡿࡶࡪ࡫ࡧࠫ㾗")		in server: l11lll1llll1_l1_	= l11l1l1l1ll1_l1_
	elif l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ㾘")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ㾙")
	elif l1111_l1_ (u"ࠧࡨࡱࡹ࡭ࡩ࠭㾚")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ㾛")
	elif l1111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ㾜") 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ㾝")
	elif l1111_l1_ (u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ㾞")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ㾟")
	elif l1111_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫ㾠")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ㾡")
	elif l1111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ㾢") 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭㾣")
	elif l1111_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ㾤")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ㾥")
	elif l1111_l1_ (u"ࠬࡻࡰࡱࠩ㾦") 			in server: l11ll1l1llll_l1_	= l1111_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ㾧")
	elif l1111_l1_ (u"ࠧࡶࡲࡥࠫ㾨") 			in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ㾩")
	elif l1111_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ㾪") 		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ㾫")
	elif l1111_l1_ (u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭㾬") 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ㾭")
	elif l1111_l1_ (u"࠭ࡶࡪࡦࡥࡳࡧ࠭㾮")		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ㾯")
	elif l1111_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ㾰") 		in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ㾱")
	elif l1111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ㾲") 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ㾳")
	elif l1111_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ㾴")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ㾵")
	elif l1111_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ㾶")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ㾷")
	#elif l1111_l1_ (u"ࠩࡸࡴࡹࡵࡢࡰࡺࠪ㾸") 	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ㾹")
	#elif l1111_l1_ (u"ࠫࡺࡶࡴࡰࡵࡷࡶࡪࡧ࡭ࠨ㾺")	in server: l11ll1l1llll_l1_	= l1111_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ㾻")
	l1111_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࡸࡶࡱ࠱ࠧ࠾࠿ࡀࠫ࠰ࡻࡲ࡭࠴ࠬࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡪ࡯ࡳࡳࡷࡺࠠࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠎࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬࠯ࡊࡲࡷࡹ࡫ࡤࡎࡧࡧ࡭ࡦࡌࡩ࡭ࡧࠫࡹࡷࡲ࠲ࠪ࠰ࡹࡥࡱ࡯ࡤࡠࡷࡵࡰ࠭࠯ࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠋࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡶࡪࡹ࡯࡭ࡸࡨࡶ࠿ࠐࠉࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠳࠴࠵࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ࠯ࠊࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡇࡣ࡯ࡷࡪࠐࠉࠊࠋࠦࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡤ࡭࠰ࡲࡶ࡬ࠐࠉࠊࠋ࡯࡭ࡸࡺ࡟ࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻࡷࡨࡱ࠳࡯ࡳࡩ࠱࡫࡮ࡺࡨࡶࡤ࠱࡭ࡴ࠵ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥ࡮࠲ࡷࡺࡶࡰࡰࡴࡷࡩࡩࡹࡩࡵࡧࡶ࠲࡭ࡺ࡭࡭ࠩࠍࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࡱ࡯ࡳࡵࡡࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡅࡔࡑࡏ࡚ࡆࡈࡌࡆ࠯࠴ࡷࡹ࠭ࠩࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࡮ࡴ࡮࡮࠽ࠎࠎࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱࡡ࠰࡞࠰࡯ࡳࡼ࡫ࡲࠩࠫࠍࠍࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽࡮࡬ࡂࠬ࠲ࠧࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂࡢ࠿ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁ࠵࡬ࡪࡀࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀ࠴ࡨ࠾ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠵࠶࠷࠸ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠩࠋࠋࠌࠍࠎࡶࡡࡳࡶࡶࠤࡂࠦࡳࡦࡴࡹࡩࡷ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠮ࠨࠫࠍࠍࠎࠏࠉࡧࡱࡵࠤࡵࡧࡲࡵࠢ࡬ࡲࠥࡶࡡࡳࡶࡶ࠾ࠏࠏࠉࠊࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡴࡦࡸࡴࠪ࠾࠷࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࠎ࡫࡬ࡪࡨࠣࡴࡦࡸࡴࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠍࠍࠎࠏࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡔࡳࡷࡨࠎࠎࠏࠉࠊࠋࠌࡦࡷ࡫ࡡ࡬ࠌࠌࠦࠧࠨ㾼")
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㾽"),l1111_l1_ (u"ࠨࠩ㾾"),url,l1l1lll_l1_)
	if   l1lll1l1l_l1_:	l11ll1lllll1_l1_,name = l1111_l1_ (u"ࠩัหฺ࠭㾿"),l1lll1l1l_l1_
	elif l11lll1llll1_l1_:		l11ll1lllll1_l1_,name = l1111_l1_ (u"๊ࠪࠩำฯะࠩ㿀"),l11lll1llll1_l1_
	elif l11ll1l1llll_l1_:		l11ll1lllll1_l1_,name = l1111_l1_ (u"ูࠫࠪࠫศ็้ࠣ฾ื่โࠩ㿁"),l11ll1l1llll_l1_
	elif l1ll1l1ll_l1_:	l11ll1lllll1_l1_,name = l1111_l1_ (u"ࠬࠫࠥࠦ฻ส้ࠥิวาฮํࠫ㿂"),l1ll1l1ll_l1_
	elif l1ll1l1llll1_l1_:	l11ll1lllll1_l1_,name = l1111_l1_ (u"࠭ࠥࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭㿃"),l11l1l1l1ll1_l1_
	else:			l11ll1lllll1_l1_,name = l1111_l1_ (u"ࠧࠦࠧࠨࠩࠪ฿วๆ่ࠢะ์๎ไࠨ㿄"),l11l1l1l1ll1_l1_
	return l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_
	l1111_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࠫࡵࡲࡡࡺࡴ࠱࠸࡭࡫࡬ࡢ࡮ࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋࡳࡶ࡮ࡼࡡࡵࡧࠣࡁࠥ࠭ࡨࡦ࡮ࡤࡰࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡩࡸࡺࡲࡦࡣࡰࠫࠏࠏࡥ࡭࡫ࡩࠤࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩࠍࠍࡪࡲࡩࡧࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡹ࡮ࡥࡷ࡫ࡧࡩࡴ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷࡧࡹ࠲࡮ࡵࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡺࡪࡼࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡺ࡮ࡪࡢࡰ࡯ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡩࡦࠪࠤࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡶ࡬ࡦࡸࡥࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡺ࡮ࡪࡳࡩࡣࡵࡩࠬࠐࠉࠣࠤࠥ㿅")
def l1l11l11l11l_l1_(url):
	l1l1lll_l1_,l11lllll1111_l1_,server,l11l1l1l1ll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,source = l11ll1l1lll1_l1_(url)
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㿆"),l1111_l1_ (u"ࠪࠫ㿇"),l11lll1llll1_l1_,server)
	#if l1111_l1_ (u"ࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩ㿈")	in server: l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ㿉"),l1111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ㿊"))
	#if any(value in server for value in l1l11ll1ll1l_l1_): l11111l_l1_,l11lll1l_l1_ = [l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡇࡖࡓࡑ࡜ࡅࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡶࡪࡹ࡯࡭ࡸࡨࠤࡹ࡮ࡩࡴࠢࡶࡩࡷࡼࡥࡳࠩ㿋")],[]
	if   l1111_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫ㿌")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l1l1l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࠨ㿍")		in source: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11lll_l1_(l1l1lll_l1_,name)
	elif l1111_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ㿎")		in source: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l1ll1_l1_(l1l1lll_l1_,type,l11l1111_l1_)
	elif l1111_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ㿏")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111111111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㿐")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1l1l111l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨ㿑")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1l1l111l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ㿒")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11111ll1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ㿓")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1lll1l11l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ㿔")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111ll1ll_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ㿕")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l111111l1l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ㿖")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l111111l1l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ㿗")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll11l1ll1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ㿘")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1lll1l1l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ㿙")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll11l1lll1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ㿚")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111lllll1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ㿛")			in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l111llll111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ㿜")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1llll1ll1l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ㿝")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1l1lll_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡰ࡮࡭ࡨࡵࠩ㿞")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1ll111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ㿟")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1ll111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ㿠")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1lll11llll1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ㿡")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1ll1l1l1lll_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ㿢")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111ll1l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㿣")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l1llll1l_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭㿤")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ㿥")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡺࡥࡤࡪࠪ㿦")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1111_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㿧")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l111l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭㿨")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠩࠪ㿩"),[l1111_l1_ (u"ࠪࠫ㿪")],[l1l1lll_l1_]
	elif l1111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ㿫")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l111l_l1_(url)
	elif l1111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ㿬")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l111l1ll1l1_l1_(l1l1lll_l1_)
	elif l1111_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ㿭") 		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠧࠨ㿮"),[l1111_l1_ (u"ࠨࠩ㿯")],[l1l1lll_l1_]
	else: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㿰"),[l1111_l1_ (u"ࠪࠫ㿱")],[l1l1lll_l1_]
	return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
def l11ll1l11ll1_l1_(url):
	server = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㿲"))
	#if l1111_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ㿳")	in server: l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㿴"),l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㿵"))
	#if any(value in server for value in l1l11ll1ll1l_l1_): l11111l_l1_,l11lll1l_l1_ = [l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ㿶")],[]
	l1l1111ll11l_l1_ = False
	if   l1111_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ㿷")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1ll1l1l_l1_(url)
	elif l1111_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ㿸")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1ll1l1l_l1_(url)
	elif l1111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭㿹")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1111_l1_(url)
	elif l1111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㿺")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l1llll1l_l1_(url)
	elif l1111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ㿻")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll11l1111_l1_(url)
	elif l1111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ㿼")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1lll1lllll_l1_(url)
	elif l1111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ㿽")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1111ll1_l1_(url)
	elif l1111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ㿾")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111lll1ll_l1_(url)
	elif l1111_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ㿿")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11111111l_l1_(url)
	elif l1111_l1_ (u"ࠫࡪ࠻ࡴࡴࡣࡵࠫ䀀")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l11ll1l_l1_(url)
	elif l1111_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䀁")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l1l11ll_l1_(url)
	elif l1111_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ䀂")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l1l11ll_l1_(url)
	elif l1111_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ䀃")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ䀄")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䀅")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ䀆")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䀇")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"ࠬࡲࡩࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䀈")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	elif l1111_l1_ (u"࠭ࡶࡪࡦࡲࡦࡦ࠭䀉")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1l111l1_l1_(url)
	elif l1111_l1_ (u"ࠧࡷ࡫ࡧࡷࡵ࡫ࡥࡥࠩ䀊")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1l111l1_l1_(url)
	elif l1111_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ䀋") 		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠩࠪ䀌"),[l1111_l1_ (u"ࠪࠫ䀍")],[url]
	#elif l1111_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ䀎")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1ll1l11l_l1_(url)
	elif l1111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䀏") 	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111lll1l1_l1_(url)
	elif l1111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䀐")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11llll1llll_l1_(url)
	elif l1111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳ࡭ࡵࠧ䀑")in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11llll1ll_l1_(url)
	elif l1111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䀒") 	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1llll111_l1_(url)
	elif l1111_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䀓")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11lllll11ll_l1_(url)
	elif l1111_l1_ (u"ࠪࡹࡵࡨࠧ䀔") 			in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l1l111l_l1_(url)
	elif l1111_l1_ (u"ࠫࡺࡶࡰࠨ䀕") 			in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l1l111l_l1_(url)
	#elif l1111_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭䀖") 	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111llllll_l1_(url)
	#elif l1111_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ䀗")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111llllll_l1_(url)
	elif l1111_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䀘") 		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11lll11l111_l1_(url)
	elif l1111_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ䀙") 	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11lll11111l_l1_(url)
	elif l1111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䀚")		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11lllll11l1_l1_(url)
	elif l1111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䀛") 		in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1lll11l_l1_(url)
	elif l1111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䀜") 	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11llll1ll1l_l1_(url)
	elif l1111_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ䀝")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1l11ll11_l1_(url)
	elif l1111_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䀞")	in server: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l111ll1lll_l1_(url)
	else: l1l1111ll11l_l1_ = True
	if l1l1111ll11l_l1_ or l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠩ䀟") in l1l11l111111_l1_:
		l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠠࡇࡣ࡬ࡰࡪࡪࠧ䀠"),[],[]
	return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	l1111_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇࡖࡘࡗࡋࡁࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡍࡏࡖࡐࡏࡍࡒࡏࡔࡆࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡉࡏࡖࡒ࡙ࡕࡒࡏࡂࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡙ࡎࡅࡗࡋࡇࡉࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡫ࡶ࠯࡫ࡲࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡆࡘࡌࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡴࡱࡧࡹࡳ࠰࠷࡬ࡪࡲࡡ࡭ࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡋࡉࡑࡇࡌࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡆࡔࡓࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡋࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡳࡩࡣࡵࡩࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡖࡌࡆࡘࡅࠩࡷࡵࡰ࠮ࠐࠉࠣࠤࠥ䀡")
def	l11ll11lll1l_l1_(l1l1ll11ll11_l1_):
	if l1111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䀢") in str(type(l1l1ll11ll11_l1_)):
		l11l1ll1_l1_ = []
		for l1l111l_l1_ in l1l1ll11ll11_l1_:
			if l1111_l1_ (u"ࠫࡸࡺࡲࠨ䀣") in str(type(l1l111l_l1_)):
				l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠬࡢࡲࠨ䀤"),l1111_l1_ (u"࠭ࠧ䀥")).replace(l1111_l1_ (u"ࠧ࡝ࡰࠪ䀦"),l1111_l1_ (u"ࠨࠩ䀧")).strip(l1111_l1_ (u"ࠩࠣࠫ䀨"))
			l11l1ll1_l1_.append(l1l111l_l1_)
	else: l11l1ll1_l1_ = l1l1ll11ll11_l1_.replace(l1111_l1_ (u"ࠪࡠࡷ࠭䀩"),l1111_l1_ (u"ࠫࠬ䀪")).replace(l1111_l1_ (u"ࠬࡢ࡮ࠨ䀫"),l1111_l1_ (u"࠭ࠧ䀬")).strip(l1111_l1_ (u"ࠧࠡࠩ䀭"))
	return l11l1ll1_l1_
def l1l111l11l11_l1_(url):
	LOG_THIS(l1111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䀮"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ䀯")+url+l1111_l1_ (u"ࠪࠤࡢ࠭䀰"))
	l1ll1l1llll1_l1_,l1l111l_l1_,l11ll11llll1_l1_ = l1111_l1_ (u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨ䀱"),l1111_l1_ (u"ࠬ࠭䀲"),l1111_l1_ (u"࠭ࠧ䀳")
	l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11l11l11l_l1_(url)
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䀴"),l1111_l1_ (u"ࠨࠩ䀵"),l1111_l1_ (u"ࠩࠪ䀶"),l1l11l111111_l1_)
	l11lll1l_l1_ = l11ll11lll1l_l1_(l11lll1l_l1_)
	if l1l11l111111_l1_==l1111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䀷"): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	elif l11lll1l_l1_: l1l111l_l1_ = l11lll1l_l1_[0]
	if l1l11l111111_l1_==l1111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䀸"):
		#l1l11l111111_l1_ = l1l11l111111_l1_.replace(l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䀹"),l1111_l1_ (u"࠭ࠧ䀺"))
		l1ll1l1llll1_l1_ = l1111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶࠭䀻")
		l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1l11ll1_l1_(l1l111l_l1_)
		l11lll1l_l1_ = l11ll11lll1l_l1_(l11lll1l_l1_)
		if l1l11l111111_l1_==l1111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䀼"): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
		elif l1111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ䀽") in l1l11l111111_l1_:
			l11ll11llll1_l1_ += l1111_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠫ䀾")+l1l11l111111_l1_
			l1ll1l1llll1_l1_ = l1111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䀿")
			l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1l11l1l_l1_(l1l111l_l1_)
			l11lll1l_l1_ = l11ll11lll1l_l1_(l11lll1l_l1_)
			if l1l11l111111_l1_==l1111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䁀"): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
			elif l1111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ䁁") in l1l11l111111_l1_:
				l11ll11llll1_l1_ += l1111_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠨ䁂")+l1l11l111111_l1_
				l1ll1l1llll1_l1_ = l1111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ䁃")
				l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11ll1l11l11_l1_(l1l111l_l1_)
				l11lll1l_l1_ = l11ll11lll1l_l1_(l11lll1l_l1_)
				if l1l11l111111_l1_==l1111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䁄"): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
				elif l1111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䁅") in l1l11l111111_l1_:
					l11ll11llll1_l1_ += l1111_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠤࠬ䁆")+l1l11l111111_l1_
					#LOG_THIS(l1111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䁇"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"࠭ࠠࠡࠢࡄࡰࡱࠦࡅࡹࡶࡨࡶࡳࡧ࡬ࠡࡔࡨࡷࡴࡲࡶࡦࡴࡶࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡍࡦࡵࡶࡥ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬ䁈")+l11ll11llll1_l1_+l1111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䁉")+url+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䁊")+l1l111l_l1_+l1111_l1_ (u"ࠩࠣࡡࠬ䁋"))
	elif l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠬ䁌") in l1l11l111111_l1_: l11ll11llll1_l1_ = l1111_l1_ (u"ࠫࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠰࠻ࠢࠪ䁍")+l1l11l111111_l1_
	l11ll11llll1_l1_ = l11ll11llll1_l1_.strip(l1111_l1_ (u"ࠬࡢ࡮ࠨ䁎"))
	if l11lll1l_l1_: LOG_THIS(l1111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䁏"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ䁐")+l1ll1l1llll1_l1_+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䁑")+l1l111l_l1_+l1111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡶࡹࡱࡺ࠺ࠡ࡝ࠣࠫ䁒")+str(l11lll1l_l1_)+l1111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䁓")+url+l1111_l1_ (u"ࠫࠥࡣࠧ䁔"))
	else: LOG_THIS(l1111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䁕"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䁖")+l1l111l_l1_+l1111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡴࡵࡤ࡫ࡪࡹ࠺ࠡ࡝ࠣࠫ䁗")+l11ll11llll1_l1_+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䁘")+url+l1111_l1_ (u"ࠩࠣࡡࠬ䁙"))
	#l11ll11llll1_l1_ = l11ll11llll1_l1_.replace(l1111_l1_ (u"ࠪࡠࡳ࠭䁚"),l1111_l1_ (u"ࠫࠥ࠴࠮࠯ࠢࠪ䁛"))
	#if l1111_l1_ (u"ࠬ࡫ࡲࡳࡱࡵ࠾ࠥ࠭䁜") not in l1l11l111111_l1_.lower(): return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	l11ll11llll1_l1_ = UNQUOTE(l11ll11llll1_l1_)
	return l11ll11llll1_l1_,l11111l_l1_,l11lll1l_l1_
def l11l1l11l111_l1_(l1l1ll111l1l_l1_):
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䁝"),l1l1ll111l1l_l1_)
	l1ll11l1l1l1_l1_ = l111ll_l1_
	data = READ_FROM_SQL3(cache_dbfile,l1111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䁞"),l1111_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䁟"),l1l1ll111l1l_l1_)
	if data:
		l11111l_l1_,l11lll1l_l1_ = list(zip(*data))
		return l11111l_l1_,l11lll1l_l1_
	l11111l_l1_,l11lll1l_l1_,l1l111ll1l1l_l1_ = [],[],[]
	for l1l111l_l1_ in l1l1ll111l1l_l1_:
		if l1111_l1_ (u"ࠩ࠲࠳ࠬ䁠") not in l1l111l_l1_: continue
		l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_ = l1l111l11ll1_l1_(l1l111l_l1_)
		l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠪࡠࡩ࠱ࠧ䁡"),l11l1111_l1_,re.DOTALL)
		if l11l1111_l1_: l11l1111_l1_ = int(l11l1111_l1_[0])
		else: l11l1111_l1_ = 0
		#if l11l1111_l1_:
		#	l11ll111ll11_l1_ = sorted(l11l1111_l1_,reverse=True,key=lambda key: int(key))
		#	l11l1111_l1_ = int(l11ll111ll11_l1_[0])
		#else: l11l1111_l1_ = 0
		server = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䁢"))
		l1l111ll1l1l_l1_.append([l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,l1l111l_l1_,server])
	if l1l111ll1l1l_l1_:
		#l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,l1l111l_l1_ = zip(*l1l111ll1l1l_l1_)
		#name = reversed(name)
		#l1l111ll1l1l_l1_ = zip(l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,l1l111l_l1_)
		l111111lll1_l1_ = sorted(l1l111ll1l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll1l1ll1l_l1_ = []
		for line in l111111lll1_l1_:
			if line not in l11ll1l1ll1l_l1_:
				l11ll1l1ll1l_l1_.append(line)
				#LOG_THIS(l1111_l1_ (u"ࠬ࠭䁣"),str(line))
		for l11ll1lllll1_l1_,name,type,l1ll_l1_,l11l1111_l1_,l1l111l_l1_,server in l11ll1l1ll1l_l1_:
			if l11l1111_l1_: l11l1111_l1_ = str(l11l1111_l1_)
			else: l11l1111_l1_ = l1111_l1_ (u"࠭ࠧ䁤")
			#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䁥"),l1111_l1_ (u"ࠨࠩ䁦"),name,l1l111l_l1_)
			title = l1111_l1_ (u"ࠩึ๎ึ็ัࠨ䁧")+l1111_l1_ (u"ࠪࠤࠬ䁨")+type+l1111_l1_ (u"ࠫࠥ࠭䁩")+l11ll1lllll1_l1_+l1111_l1_ (u"ࠬࠦࠧ䁪")+l11l1111_l1_+l1111_l1_ (u"࠭ࠠࠨ䁫")+l1ll_l1_+l1111_l1_ (u"ࠧࠡࠩ䁬")+name
			if server not in title: title = title+l1111_l1_ (u"ࠨࠢࠪ䁭")+server
			title = title.replace(l1111_l1_ (u"ࠩࠨࠫ䁮"),l1111_l1_ (u"ࠪࠫ䁯")).strip(l1111_l1_ (u"ࠫࠥ࠭䁰")).replace(l1111_l1_ (u"ࠬࠦࠠࠨ䁱"),l1111_l1_ (u"࠭ࠠࠨ䁲")).replace(l1111_l1_ (u"ࠧࠡࠢࠪ䁳"),l1111_l1_ (u"ࠨࠢࠪ䁴")).replace(l1111_l1_ (u"ࠩࠣࠤࠬ䁵"),l1111_l1_ (u"ࠪࠤࠬ䁶"))
			if l1l111l_l1_ not in l11lll1l_l1_:
				l11111l_l1_.append(title)
				l11lll1l_l1_.append(l1l111l_l1_)
		if l11lll1l_l1_:
			#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ䁷"),l11lll1l_l1_)
			data = list(zip(l11111l_l1_,l11lll1l_l1_))
			if data: l1ll11lllll_l1_(cache_dbfile,l1111_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䁸"),l1l1ll111l1l_l1_,data,l1ll11l1l1l1_l1_)
	#LOG_THIS(l1111_l1_ (u"࠭ࠧ䁹"),l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠿࠸࠺ࠡࠢࠣࠫ䁺")+str(data))
	return l11111l_l1_,l11lll1l_l1_
l1111_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡕࡈࡖ࡛ࡋࡒࡔࡡࡆࡅࡈࡎࡅࡅࡡࡒࡐࡉ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪࡃࠧࠨࠫ࠽ࠎࠎࠩࡴ࠲ࠢࡀࠤࡹ࡯࡭ࡦ࠰ࡷ࡭ࡲ࡫ࠨࠪࠌࠌࡧࡦࡩࡨࡦࡲࡨࡶ࡮ࡵࡤࠡ࠿ࠣࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠊࠊࡥࡲࡲࡳࠦ࠽ࠡࡵࡴࡰ࡮ࡺࡥ࠴࠰ࡦࡳࡳࡴࡥࡤࡶࠫࡧࡦࡩࡨࡦࡡࡧࡦ࡫࡯࡬ࡦࠫࠍࠍࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡗࡊࡒࡅࡄࡖࠣࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠭ࡷࡵࡰࡑࡏࡓࡕࠢࡉࡖࡔࡓࠠࡴࡧࡵࡺࡪࡸࡳࡤࡣࡦ࡬ࡪࠦࡗࡉࡇࡕࡉࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࠽ࠣࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫ࠮ࠫࠧ࠭ࠩࠋࠋࡵࡳࡼࡹࠠ࠾ࠢࡦ࠲࡫࡫ࡴࡤࡪࡤࡰࡱ࠮ࠩࠋࠋ࡬ࡪࠥࡸ࡯ࡸࡵ࠽ࠎࠎࠏࠣ࡮ࡧࡶࡷࡦ࡭ࡥࠡ࠿ࠣࠫ࡫ࡵࡵ࡯ࡦࠣ࡭ࡳࠦࡣࡢࡥ࡫ࡩࠬࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࡴࡎࡌࡗ࡙࠲ࡵࡳ࡮ࡏࡍࡘ࡚ࠠ࠾ࠢࡈ࡚ࡆࡒࠨࠨࡵࡷࡶࠬ࠲ࡲࡰࡹࡶ࡟࠵ࡣ࡛࠱࡟ࠬ࠰ࡊ࡜ࡁࡍࠪࠪࡷࡹࡸࠧ࠭ࡴࡲࡻࡸࡡ࠰࡞࡝࠴ࡡ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠥࡰࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡩࡡࡤࡪࡨࠫࠏࠏࠉࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠱ࡻࡲ࡭ࡎࡌࡗ࡙ࠦ࠽ࠡࡕࡈࡖ࡛ࡋࡒࡔࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭ࠏࠏࠉࡵࠢࡀࠤ࠭ࡴ࡯ࡸ࠭ࡦࡥࡨ࡮ࡥࡱࡧࡵ࡭ࡴࡪࠬࡴࡶࡵࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠬࡴࡶࡵࠬࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕࠫ࠯ࡷࡹࡸࠨࡶࡴ࡯ࡐࡎ࡙ࡔࠪࠫࠍࠍࠎࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠤࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡴࡧࡵࡺࡪࡸࡳࡤࡣࡦ࡬ࡪࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠲࠿ࠪࠤ࠯ࡸ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣࡰ࡯ࡰ࡭ࡹ࠮ࠩࠋࠋࡦࡳࡳࡴ࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࠦࡸ࠷ࠦ࠽ࠡࡶ࡬ࡱࡪ࠴ࡴࡪ࡯ࡨࠬ࠮ࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡐࡒࡘࡎࡌࡉࡄࡃࡗࡍࡔࡔࠨ࡮ࡧࡶࡷࡦ࡭ࡥ࠭ࡵࡷࡶ࠭࡯࡮ࡵࠪࡷ࠶࠲ࡺ࠱ࠪࠫ࠮ࠫࠥࡳࡳࠨࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠮ࡸࡶࡱࡒࡉࡔࡖࠍࠎࡩ࡫ࡦࠡࡕࡈࡖ࡛ࡋࡒࡔࡡࡒࡐࡉ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪࡃࠧࠨࠫ࠽ࠎࠎࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗ࠰ࡺࡴ࡫࡯ࡱࡺࡲࡑࡏࡓࡕ࠮ࡶࡩࡷࡼࡥࡳࡵࡇࡍࡈ࡚ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠊࠊࠥ࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦ࡬ࡪࡵࡷࠬࡸ࡫ࡴࠩ࡮࡬ࡲࡰࡒࡉࡔࡖࠬ࠭ࠏࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭ࠬࠡ࡮࡬ࡲࡰࡒࡉࡔࡖࠬࠎࠎࠩࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯ࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࠽ࠎࠎࠏࡩࡧࠢ࡯࡭ࡳࡱ࠽࠾ࠩࠪ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࡶࡩࡷࡼࡥࡳࡐࡄࡑࡊࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡂࡄࡏࡉ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࡳࡦࡴࡹࡩࡷࡹࡄࡊࡅࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࠥࡡࡳࡦࡴࡹࡩࡷࡔࡁࡎࡇ࠯ࡰ࡮ࡴ࡫࡞ࠢࠬࠎࠎࡹ࡯ࡳࡶࡨࡨࡉࡏࡃࡕࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬࡸ࡫ࡲࡷࡧࡵࡷࡉࡏࡃࡕ࠮ࠣࡶࡪࡼࡥࡳࡵࡨࡁ࡙ࡸࡵࡦ࠮ࠣ࡯ࡪࡿ࠽࡭ࡣࡰࡦࡩࡧࠠ࡬ࡧࡼ࠾ࠥࡱࡥࡺ࡝࠳ࡡ࠮ࠐࠉࡧࡱࡵࠤࡸ࡫ࡲࡷࡧࡵ࠰ࡱ࡯࡮࡬ࠢ࡬ࡲࠥࡹ࡯ࡳࡶࡨࡨࡉࡏࡃࡕ࠼ࠍࠍࠎࡹࡥࡳࡸࡨࡶࠥࡃࠠࡴࡧࡵࡺࡪࡸ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠨࠫ࠱࠭ࠧࠪࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡶࡩࡷࡼࡥࡳࠫࠍࠍࠎࡻࡲ࡭ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠣ࡭࡫ࡱࡩࡸࠦ࠽ࠡ࡮ࡨࡲ࠭ࡻ࡮࡬ࡰࡲࡻࡳࡒࡉࡔࡖࠬࠎࠎࠩࡩࡧࠢ࡯࡭ࡳ࡫ࡳ࠿࠲࠽ࠎࠎࠩࠉ࡮ࡧࡶࡷࡦ࡭ࡥࠡ࠿ࠣࠫࡡࡢ࡮ࠨࠌࠌࠧࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠠࡪࡰࠣࡹࡳࡱ࡮ࡰࡹࡱࡐࡎ࡙ࡔ࠻ࠌࠌࠧࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࠠࠬ࠿ࠣࡰ࡮ࡴ࡫ࠡ࠭ࠣࠫࡡࡢ࡮ࠨࠌࠌࠧࠎࡹࡵࡣ࡬ࡨࡧࡹࠦ࠽ࠡࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࡸࠦ࠽ࠡࠩࠣ࠯ࠥࡹࡴࡳࠪ࡯࡭ࡳ࡫ࡳࠪࠌࠌࠧࠎࡸࡥࡴࡷ࡯ࡸࠥࡃࠠࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏࠬࡸࡻࡢ࡫ࡧࡦࡸ࠱ࡳࡥࡴࡵࡤ࡫ࡪ࠲ࡆࡢ࡮ࡶࡩ࠱࠭ࠧ࠭ࠩࡉࡖࡔࡓ࠭ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࠫ࠰ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗࠎࠧࠨࠢ䁻")
def	l11ll1l11l1l_l1_(url):
	#url = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡈࡡࡘࡡ࡭ࡩࡳࡵࡺࡌࡥࠪ䁼")
	l1111l11l1l_l1_ = l1111_l1_ (u"ࠪࠫ䁽")
	l11l_l1_ = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11llll1111l_l1_():
		#l11l_l1_ = resolveurl.HostedMediaFile(url).resolve()
		l11l_l1_ = resolveurl.resolve(url)
	except Exception as error: l1111l11l1l_l1_ = str(error)
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䁾"),l1111_l1_ (u"ࠬ࠭䁿"),l1111_l1_ (u"࠭ࠧ䂀"),str(l11l_l1_))
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䂁"),l1111_l1_ (u"ࠨࠩ䂂"),l1111_l1_ (u"ࠩࠪ䂃"),str(l1111l11l1l_l1_))
	# resolveurl l11l1llll1_l1_ fail l11l1ll1l1ll_l1_ with l11ll11111ll_l1_ error or l11lll111111_l1_ value False
	if not l11l_l1_:
		if l1111l11l1l_l1_==l1111_l1_ (u"ࠪࠫ䂄"):
			l1111l11l1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l11l1l_l1_)
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䂅"),l1111_l1_ (u"ࠬ࠭䂆"),l1111_l1_ (u"࠭ࠧ䂇"),str(l1111l11l1l_l1_))
		l1l11l111111_l1_ = l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷ࠦࡆࡢ࡫࡯ࡩࡩ࠭䂈")
		l1l11l111111_l1_ += l1111_l1_ (u"ࠨࠢࠪ䂉")+l1111l11l1l_l1_.splitlines()[-1]
		return l1l11l111111_l1_,[],[]
	return l1111_l1_ (u"ࠩࠪ䂊"),[l1111_l1_ (u"ࠪࠫ䂋")],[l11l_l1_]
def	l11ll1l11l11_l1_(url):
	#url = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡃࡣ࡚ࡣ࡯࡫࡮ࡰࡼࡎࡧࠬ䂌")
	#url = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱ࠴ࡼࡩࡥࡧࡲ࠳ࡽ࠽ࡹࡺ࠶࠴ࡷࠬ䂍")
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䂎"),l1111_l1_ (u"ࠧࠨ䂏"),url,l1111_l1_ (u"ࠨࠩ䂐"))
	#return l1111_l1_ (u"ࠩࠪ䂑"),[],[]
	l1111l11l1l_l1_ = l1111_l1_ (u"ࠪࠫ䂒")
	l11l_l1_ = False
	try:
		import youtube_dl
		l1l111111l11_l1_ = youtube_dl.YoutubeDL({l1111_l1_ (u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭䂓"): True})
		l11l_l1_ = l1l111111l11_l1_.extract_info(url,download=False)
	except Exception as error: l1111l11l1l_l1_ = str(error)
	# youtube_dl l11l1llll1_l1_ fail l11l1ll1l1ll_l1_ with l11ll11111ll_l1_ error or l11lll111111_l1_ value False
	if not l11l_l1_ or l1111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭䂔") not in list(l11l_l1_.keys()):
		if l1111l11l1l_l1_==l1111_l1_ (u"࠭ࠧ䂕"):
			l1111l11l1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l11l1l_l1_)
		#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䂖"),l1111_l1_ (u"ࠨࠩ䂗"),l1111_l1_ (u"ࠩࠪ䂘"),l1111l11l1l_l1_)
		l1l11l111111_l1_ = l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠢࡉࡥ࡮ࡲࡥࡥࠩ䂙")
		l1l11l111111_l1_ += l1111_l1_ (u"ࠫࠥ࠭䂚")+l1111l11l1l_l1_.splitlines()[-1]
		return l1l11l111111_l1_,[],[]
	else:
		l11111l_l1_,l11lll1l_l1_ = [],[]
		for l1l111l_l1_ in l11l_l1_[l1111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭䂛")]:
			l11111l_l1_.append(l1l111l_l1_[l1111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹ࠭䂜")])
			l11lll1l_l1_.append(l1l111l_l1_[l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䂝")])
		return l1111_l1_ (u"ࠨࠩ䂞"),l11111l_l1_,l11lll1l_l1_
def l1l111111111_l1_(url):
	if l1111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䂟") in url:
		l11111l_l1_,l11lll1l_l1_ = l1l1ll111l_l1_(url)
		if l11lll1l_l1_: return l1111_l1_ (u"ࠪࠫ䂠"),l11111l_l1_,l11lll1l_l1_
		return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡍࡃࡕࡅࡇ࠭䂡"),[],[]
	return l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䂢"),[l1111_l1_ (u"࠭ࠧ䂣")],[url]
#=================================================================================
# l11lll111l_l1_ of the l11l11l11l_l1_ l1llll11lll_l1_ l1llll111ll_l1_ added from:
# l1ll11ll_l1_://l11l111ll1_l1_.com/l111lll1ll_l1_/l11l11llll_l1_-addons/l11l1ll1ll_l1_/l11ll11l11_l1_/plugin.video.l11ll1llll_l1_/l11l1lll11_l1_/l1llll1ll11_l1_/l111l111l1_l1_.py
#=================================================================================
def l1l111llll1l_l1_(l11ll11lll_l1_):
	data,page,l1llll1l1l1_l1_ = l11ll11lll_l1_,l1111_l1_ (u"ࠧࠨ䂤"),l1111_l1_ (u"ࠨࠩ䂥")
	l1llll1l111_l1_ = re.findall(l1111_l1_ (u"ࠩ࠿ࡷࡨࡸࡩࡱࡶ࠱࠮ࡄࡁ࠮ࠫࡁ࡟ࠫ࠭࠴ࠪࡀࠫ࠾ࠫ䂦"), data, re.S)
	l1llll1111l_l1_ = re.findall(l1111_l1_ (u"ࠪ࠳࡬࠴࠮࠯࠰࠱ࠬ࠳࠰࠿ࠪ࡞ࠬࠫ䂧"), data, re.S)
	if l1llll1l111_l1_ and l1llll1111l_l1_:
		l11ll11lll_l1_ = l1llll1l111_l1_[0].replace(l1111_l1_ (u"ࠦࠬࠨ䂨"),l1111_l1_ (u"ࠬ࠭䂩"))
		l11ll11lll_l1_ = l11ll11lll_l1_.replace(l1111_l1_ (u"ࠨࠫࠣ䂪"),l1111_l1_ (u"ࠧࠨ䂫"))
		l11ll11lll_l1_ = l11ll11lll_l1_.replace(l1111_l1_ (u"ࠣ࡞ࡱࠦ䂬"),l1111_l1_ (u"ࠩࠪ䂭"))
		l1llll111l1_l1_ = l11ll11lll_l1_.split(l1111_l1_ (u"ࠪ࠲ࠬ䂮"))
		page = l1111_l1_ (u"ࠫࠬ䂯")
		for l11l1l1l1l_l1_ in l1llll111l1_l1_:
				try:
					l1llll11l11_l1_ = base64.b64decode(l11l1l1l1l_l1_+l1111_l1_ (u"ࠬࡃ࠽ࠨ䂰"))
					l1llll11l1l_l1_ = re.findall(l1111_l1_ (u"࠭࡜ࡥ࠭ࠪ䂱"), l1llll11l11_l1_, re.S)
					if l1llll11l1l_l1_:
						l1llll11ll1_l1_ = int(l1llll11l1l_l1_[0])+int(l1llll1111l_l1_[0])
						page = page + chr(l1llll11ll1_l1_)
				except: return l1111_l1_ (u"ࠧࠨ䂲"),l1111_l1_ (u"ࠨࠩ䂳")
		l1llll1l1l1_l1_ = re.findall(l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䂴"), page, re.S)
	return page,l1llll1l1l1_l1_
def l1lll1lllll_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䂵"),url,l1111_l1_ (u"ࠫࠬ䂶"),l1111_l1_ (u"ࠬ࠭䂷"),l1111_l1_ (u"࠭ࠧ䂸"),l1111_l1_ (u"ࠧࠨ䂹"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠲࠷ࡳࡵࠩ䂺"))
	html = response.content
	page,url = l1l111llll1l_l1_(html)
	if not url: return l1111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈࠬ䂻"),[],[]
	return l1111_l1_ (u"ࠪࠫ䂼"),[l1111_l1_ (u"ࠫࠬ䂽")],[url]
def l11111ll1_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䂾"),url,l1111_l1_ (u"࠭ࠧ䂿"),l1111_l1_ (u"ࠧࠨ䃀"),l1111_l1_ (u"ࠨࠩ䃁"),l1111_l1_ (u"ࠩࠪ䃂"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪ䃃"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䃄"),html,re.DOTALL)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅ࠹࡛ࠧ䃅"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䃆"),[l1111_l1_ (u"ࠧࠨ䃇")],[l1l111l_l1_]
def l1111ll1ll_l1_(url):
	l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
	l1l1lll11_l1_ = {l1111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䃈"):l1111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䃉"),l1111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䃊"):l1111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䃋")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䃌"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"࠭ࠧ䃍"),l1111_l1_ (u"ࠧࠨ䃎"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡏࡑ࡚࠱࠶ࡹࡴࠨ䃏"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䃐"),html,re.DOTALL)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡐࡒ࡛ࠬ䃑"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	return l1111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䃒"),[l1111_l1_ (u"ࠬ࠭䃓")],[l1l111l_l1_]
def l1ll11l1lll1_l1_(url):
	headers = {l1111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䃔"):l1111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䃕")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䃖"),url,l1111_l1_ (u"ࠩࠪ䃗"),headers,l1111_l1_ (u"ࠪࠫ䃘"),l1111_l1_ (u"ࠫࠬ䃙"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡓࡔࡌࡐࡓࡑ࠰࠵ࡸࡺࠧ䃚"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䃛"),html,re.DOTALL|re.IGNORECASE)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡔࡕࡆࡑࡔࡒࠫ䃜"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䃝"),[l1111_l1_ (u"ࠩࠪ䃞")],[l1l111l_l1_]
def l1ll11l1ll1_l1_(url):
	l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
	l1l1lll11_l1_ = {l1111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䃟"):l1111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䃠")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䃡"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"࠭ࠧ䃢"),l1111_l1_ (u"ࠧࠨ䃣"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡍࡇࡌࡂࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䃤"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ䃥"),html,re.DOTALL|re.IGNORECASE)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡎࡁࡍࡃࡆࡍࡒࡇࠧ䃦"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	if l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䃧") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ䃨")+l1l111l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䃩"),l1111_l1_ (u"ࠧࠨ䃪"),l1111_l1_ (u"ࠨࠩ䃫"),l1l111l_l1_)
	return l1111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䃬"),[l1111_l1_ (u"ࠪࠫ䃭")],[l1l111l_l1_]
def l1lll1l1l1_l1_(url):
	l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
	l1l1lll11_l1_ = {l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䃮"):l1111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䃯")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䃰"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠧࠨ䃱"),l1111_l1_ (u"ࠨࠩ䃲"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫ䃳"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ䃴"),html,re.DOTALL|re.IGNORECASE)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡅࡇࡊࡏࠨ䃵"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	return l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䃶"),[l1111_l1_ (u"࠭ࠧ䃷")],[l1l111l_l1_]
def l111111l1l1_l1_(url):
	#LOG_THIS(l1111_l1_ (u"ࠧࠨ䃸"),url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䃹"),url,l1111_l1_ (u"ࠩࠪ䃺"),l1111_l1_ (u"ࠪࠫ䃻"),l1111_l1_ (u"ࠫࠬ䃼"),l1111_l1_ (u"ࠬ࠭䃽"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬ䃾"))
	html = response.content
	l11ll1ll111l_l1_ = re.findall(l1111_l1_ (u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䃿"),html,re.DOTALL|re.IGNORECASE)
	if l11ll1ll111l_l1_:
		l11ll1ll111l_l1_ = l11ll1ll111l_l1_[0][2:]
		#l11ll1ll111l_l1_ = l11ll1ll111l_l1_.decode(l1111_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ䄀"))
		l11ll1ll111l_l1_ = base64.b64decode(l11ll1ll111l_l1_)
		if kodi_version>18.99: l11ll1ll111l_l1_ = l11ll1ll111l_l1_.decode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䄁"))
		l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䄂"),l11ll1ll111l_l1_,re.DOTALL)
	else: l1l111l_l1_ = l1111_l1_ (u"ࠫࠬ䄃")
	if not l1l111l_l1_: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭䄄"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䄅") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䄆")+l1l111l_l1_
	return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䄇"),[l1111_l1_ (u"ࠩࠪ䄈")],[l1l111l_l1_]
def l1l111lllll1_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䄉"),url,l1111_l1_ (u"ࠫࠬ䄊"),l1111_l1_ (u"ࠬ࠭䄋"),l1111_l1_ (u"࠭ࠧ䄌"),l1111_l1_ (u"ࠧࠨ䄍"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪ䄎"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䄏"),html,re.DOTALL)
	if not l1l111l_l1_: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧ䄐"),[],[]
	l1l111l_l1_ = l1l111l_l1_[0]
	return l1111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䄑"),[l1111_l1_ (u"ࠬ࠭䄒")],[l1l111l_l1_]
def l1l1llll1l_l1_(url):
	id = url.split(l1111_l1_ (u"࠭࠯ࠨ䄓"))[-1]
	if l1111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ䄔") in url: url = url.replace(l1111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ䄕"),l1111_l1_ (u"ࠩࠪ䄖"))
	url = url.replace(l1111_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࠩ䄗"),l1111_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬ䄘"))
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䄙"),url,l1111_l1_ (u"࠭ࠧ䄚"),l1111_l1_ (u"ࠧࠨ䄛"),l1111_l1_ (u"ࠨࠩ䄜"),l1111_l1_ (u"ࠩࠪ䄝"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ䄞"))
	html = response.content
	#l111ll1l1_l1_(html)
	#LOG_THIS(l1111_l1_ (u"ࠫࠬ䄟"),url)
	l1l11l111111_l1_ = l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ䄠")
	error = re.findall(l1111_l1_ (u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䄡"),html,re.DOTALL)
	if error: l1l11l111111_l1_ = error[0]
	url = re.findall(l1111_l1_ (u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䄢"),html,re.DOTALL)
	if not url and l1l11l111111_l1_:
		#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䄣"),l1111_l1_ (u"ࠩࠪ䄤"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠬ䄥"),l1l11l111111_l1_)
		return l1l11l111111_l1_,[],[]
	l1l111l_l1_ = url[0].replace(l1111_l1_ (u"ࠫࡡࡢࠧ䄦"),l1111_l1_ (u"ࠬ࠭䄧"))
	l1l1l1llllll_l1_,l1l1ll111l1l_l1_ = l1l1ll111l_l1_(l1l111l_l1_)
	owner = re.findall(l1111_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䄨"),html,re.DOTALL)
	if owner: l11ll1ll1l11_l1_,l1l1111111ll_l1_,l1l11ll11111_l1_ = owner[0]
	else: l11ll1ll1l11_l1_,l1l1111111ll_l1_,l1l11ll11111_l1_ = l1111_l1_ (u"ࠧࠨ䄩"),l1111_l1_ (u"ࠨࠩ䄪"),l1111_l1_ (u"ࠩࠪ䄫")
	l1l11ll11111_l1_ = l1l11ll11111_l1_.replace(l1111_l1_ (u"ࠪࡠ࠴࠭䄬"),l1111_l1_ (u"ࠫ࠴࠭䄭"))
	l1l1111111ll_l1_ = escapeUNICODE(l1l1111111ll_l1_)
	l11111l_l1_ = [l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ䄮")+l1l1111111ll_l1_+l1111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䄯")]+l1l1l1llllll_l1_
	l11lll1l_l1_ = [l1l11ll11111_l1_]+l1l1ll111l1l_l1_
	l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ䄰")+str(len(l11lll1l_l1_)-1)+l1111_l1_ (u"ࠨ่่ࠢๆ࠯ࠧ䄱"),l11111l_l1_)
	if l1l_l1_==-1: return l1111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䄲"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l1111_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ䄳")+l1l11ll11111_l1_+l1111_l1_ (u"ࠫࠫࡺࡥࡹࡶࡀࠫ䄴")+l1l1111111ll_l1_
		xbmc.executebuiltin(l1111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ䄵")+new_path+l1111_l1_ (u"ࠨࠩࠣ䄶"))
		return l1111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䄷"),[],[]
	l1l111l_l1_ =  l11lll1l_l1_[l1l_l1_]
	return l1111_l1_ (u"ࠨࠩ䄸"),[l1111_l1_ (u"ࠩࠪ䄹")],[l1l111l_l1_]
def l1111ll1l_l1_(l1l111l_l1_):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䄺"),l1l111l_l1_,l1111_l1_ (u"ࠫࠬ䄻"),l1111_l1_ (u"ࠬ࠭䄼"),l1111_l1_ (u"࠭ࠧ䄽"),l1111_l1_ (u"ࠧࠨ䄾"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧ䄿"))
	html = response.content
	if l1111_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨ䅀") in l1l111l_l1_: url = re.findall(l1111_l1_ (u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䅁"),html,re.DOTALL)
	else: url = re.findall(l1111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䅂"),html,re.DOTALL)
	if not url: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭䅃"),[],[]
	url = url[0]
	if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䅄") not in url: url = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䅅")+url
	return l1111_l1_ (u"ࠨࠩ䅆"),[l1111_l1_ (u"ࠩࠪ䅇")],[url]
def l11ll11l1111_l1_(url):
	# http://l1l11l1ll111_l1_.l11l1lll1111_l1_/l1l111l111ll_l1_.html?l11lll1llll1_l1_=l11ll11111l1_l1_
	# http://l1l11l1ll111_l1_.l11l1lll1111_l1_/l11ll111lll1_l1_?op=l1l1111111l1_l1_&id=l1l111l111ll_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䅈") : l1111_l1_ (u"ࠫࠬ䅉") }
	if l1111_l1_ (u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ䅊") in url:
		html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"࠭ࠧ䅋"),headers,l1111_l1_ (u"ࠧࠨ䅌"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪ䅍"))
		#xbmc.log(html)
		#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ䅎"),l1111_l1_ (u"ࠪࠫ䅏"),url,html)
		items = re.findall(l1111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䅐"),html,re.DOTALL)
		if items: return l1111_l1_ (u"ࠬ࠭䅑"),[l1111_l1_ (u"࠭ࠧ䅒")],[items[0]]
		else:
			message = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䅓"),html,re.DOTALL)
			if message:
				l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䅔"),l1111_l1_ (u"ࠩࠪ䅕"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไศื็๎ࠬ䅖"),message[0])
				return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࠬ䅗")+message[0],[],[]
	else:
		#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭䅘"),l1111_l1_ (u"࠭ࠧ䅙"),l1l111l_l1_,l1111_l1_ (u"ࠧࠨ䅚"))
		#url,name2 = url.split(l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䅛"))
		#name2 = name2.lower()
		name2 = l1111_l1_ (u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬ䅜")
		# l11ll1l1l_l1_ l11l1ll1_l1_
		html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠪࠫ䅝"),headers,l1111_l1_ (u"ࠫࠬ䅞"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧ䅟"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䅠"),html,re.DOTALL)
		if not l111l1l_l1_: return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䅡"),[],[]
		l1lllll1ll_l1_ = l111l1l_l1_[0][0]
		block = l111l1l_l1_[0][1]
		if l1111_l1_ (u"ࠨ࠰ࡵࡥࡷ࠭䅢") in block or l1111_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ䅣") in block: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨ䅤"),[],[]
		items = re.findall(l1111_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䅥"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l1l1_l1_(payload)
		html = l111l11_l1_(l1ll1llll_l1_,l1lllll1ll_l1_,data,headers,l1111_l1_ (u"ࠬ࠭䅦"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠸ࡸࡤࠨ䅧"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥ࡙ࠢ࡭ࡩ࡫࡯࠯ࠬࡂ࡫ࡪࡺ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡯࡭ࡢࡩࡨ࠾ࠬ䅨"),html,re.DOTALL)
		if not l111l1l_l1_: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䅩"),[],[]
		download = l111l1l_l1_[0][0]
		block = l111l1l_l1_[0][1]
		items = re.findall(l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤ࠱࠮ࡄࠨࡼࠪࠩ䅪"),block,re.DOTALL)
		l1l111lll11l_l1_,l11111l_l1_,l11ll1lll111_l1_,l11lll1l_l1_,l11ll1ll1111_l1_ = [],[],[],[],[]
		for l1l111l_l1_,title in items:
			if l1111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䅫") in l1l111l_l1_:
				l1l111lll11l_l1_,l11ll1lll111_l1_ = l1l1ll111l_l1_(l1l111l_l1_)
				l11lll1l_l1_ = l11lll1l_l1_ + l11ll1lll111_l1_
				if l1l111lll11l_l1_[0]==l1111_l1_ (u"ࠫ࠲࠷ࠧ䅬"): l11111l_l1_.append(l1111_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ䅭")+l1111_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ䅮")+name2)
				else:
					for title in l1l111lll11l_l1_:
						l11111l_l1_.append(l1111_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䅯")+l1111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䅰")+name2+l1111_l1_ (u"ࠩࠣࠫ䅱")+title)
			else:
				title = title.replace(l1111_l1_ (u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬ䅲"),l1111_l1_ (u"ࠫࠬ䅳"))
				title = title.strip(l1111_l1_ (u"ࠬࠨࠧ䅴"))
				#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䅵"),l1111_l1_ (u"ࠧࠨ䅶"),title,str(l11ll1ll1111_l1_))
				title = l1111_l1_ (u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧ䅷")+l1111_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ䅸")+name2+l1111_l1_ (u"ࠪࠤࠬ䅹")+title
				l11111l_l1_.append(title)
				l11lll1l_l1_.append(l1l111l_l1_)
		# download l11l1ll1_l1_
		l1l111l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭䅺") + download
		html = l111l11_l1_(l1ll1llll_l1_,l1l111l_l1_,l1111_l1_ (u"ࠬ࠭䅻"),headers,l1111_l1_ (u"࠭ࠧ䅼"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠻ࡴࡩࠩ䅽"))
		items = re.findall(l1111_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰ࠧ䅾"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1111_l1_ (u"ࠩࠣื๏ืแาࠢอั๊๐ไࠡะสูࠥ࠭䅿")+l1111_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ䆀")+name2+l1111_l1_ (u"ࠫࠥ࠭䆁")+resolution.split(l1111_l1_ (u"ࠬࡾࠧ䆂"))[1]
			l1l111l_l1_ = l1111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ䆃")+id+l1111_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ䆄")+mode+l1111_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ䆅")+hash
			l11ll1ll1111_l1_.append(resolution)
			l11111l_l1_.append(title)
			l11lll1l_l1_.append(l1l111l_l1_)
		l11ll1ll1111_l1_ = set(l11ll1ll1111_l1_)
		l11llll111l1_l1_,l1l11ll1l111_l1_ = [],[]
		for title in l11111l_l1_:
			#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ䆆"),l1111_l1_ (u"ࠪࠫ䆇"),title,l1111_l1_ (u"ࠫࠬ䆈"))
			res = re.findall(l1111_l1_ (u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧ䆉"),title+l1111_l1_ (u"࠭ࠦࠧࠩ䆊"),re.DOTALL)
			for resolution in l11ll1ll1111_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1111_l1_ (u"ࠧࡹࠩ䆋"))[1])
			l11llll111l1_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l11lll1l_l1_)):
			items = re.findall(l1111_l1_ (u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤ䆌"),l1111_l1_ (u"ࠩࠩࠪࠬ䆍")+l11llll111l1_l1_[i]+l1111_l1_ (u"ࠪࠪࠫ࠭䆎"),re.DOTALL)
			l1l11ll1l111_l1_.append( [l11llll111l1_l1_[i],l11lll1l_l1_[i],items[0][0],items[0][1]] )
		l1l11ll1l111_l1_ = sorted(l1l11ll1l111_l1_, key=lambda x: x[3], reverse=True)
		l1l11ll1l111_l1_ = sorted(l1l11ll1l111_l1_, key=lambda x: x[2], reverse=False)
		l11111l_l1_,l11lll1l_l1_ = [],[]
		for i in range(len(l1l11ll1l111_l1_)):
			l11111l_l1_.append(l1l11ll1l111_l1_[i][0])
			l11lll1l_l1_.append(l1l11ll1l111_l1_[i][1])
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ䆏"),[],[]
	return l1111_l1_ (u"ࠬ࠭䆐"),l11111l_l1_,l11lll1l_l1_
def l11l1l11ll1l_l1_(url):
	# http://l11ll11l11ll_l1_.com/717254
	parts = url.split(l1111_l1_ (u"࠭࠿ࠨ䆑"))
	l1l1lll_l1_ = parts[0]
	headers = { l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䆒") : l1111_l1_ (u"ࠨࠩ䆓") }
	html = l111l11_l1_(l1ll1llll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ䆔"),headers,l1111_l1_ (u"ࠪࠫ䆕"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫ䆖"))
	items = re.findall(l1111_l1_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭䆗"),html,re.DOTALL)
	url = items[0]
	#l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11111ll1l_l1_(url)
	#return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䆘"),[l1111_l1_ (u"ࠧࠨ䆙")],[url]
def l1l11111111l_l1_(url):
	# l1ll11ll_l1_://l111ll1111_l1_.l111l111ll_l1_/l111ll11ll_l1_
	# l1ll11ll_l1_://l111l11l11_l1_.cc/l111ll11ll_l1_
	l11111l_l1_,l11lll1l_l1_ = [],[]
	headers = { l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䆚") : l1111_l1_ (u"ࠩࠪ䆛") }
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠪࠫ䆜"),headers,l1111_l1_ (u"ࠫࠬ䆝"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ䆞"))
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䆟"),html,re.DOTALL)
	if l1l1lll_l1_: return l1111_l1_ (u"ࠧࠨ䆠"),[l1111_l1_ (u"ࠨࠩ䆡")],[l1l1lll_l1_[0]]
	else: return l1111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇ࡛࡚࡛ࡘࡕࡐࠬ䆢"),[],[]
def l11l1l1l11ll_l1_(url):
	# l1ll11ll_l1_://l111ll1111_l1_.l111l111ll_l1_/l111ll11ll_l1_
	# l1ll11ll_l1_://l111l11l11_l1_.cc/l111ll11ll_l1_
	l11111l_l1_,l11lll1l_l1_ = [],[]
	headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䆣") : l1111_l1_ (u"ࠫࠬ䆤") }
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠬ࠭䆥"),headers,l1111_l1_ (u"࠭ࠧ䆦"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䆧"))
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫ䆨"),html,re.DOTALL)
	if l1l1lll_l1_: return l1111_l1_ (u"ࠩࠪ䆩"),[l1111_l1_ (u"ࠪࠫ䆪")],[l1l1lll_l1_[0]]
	else: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬ䆫"),[],[]
def l1llll1ll1l_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭䆬"),l1111_l1_ (u"࠭ࠧ䆭"),url,str(0000))
	# l11ll1l1l_l1_    l1ll11ll_l1_://show.l11lll1l1111_l1_.com/l11lllll1lll_l1_-l11llll1l1ll_l1_/l11llll1l1ll_l1_-l11llllll1l1_l1_.l1lll1111l_l1_?action=l11ll1ll11l1_l1_&l1111ll11l_l1_=32513&l1llll1lll1_l1_=1&type=l111ll111l_l1_
	# download l1ll11ll_l1_://show.l11lll1l1111_l1_.com/l11l1ll1_l1_/l1l11l111l11_l1_
	l11111l_l1_,l11lll1l_l1_,errno = [],[],l1111_l1_ (u"ࠧࠨ䆮")
	# l11ll1l1l_l1_
	if l1111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬ䆯") in url:
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䆰"):l1111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䆱")}
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䆲"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠬ࠭䆳"),l1111_l1_ (u"࠭ࠧ䆴"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪ䆵"))
		l11llll1_l1_ = response.content
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩ䆶"),l11llll1_l1_,re.DOTALL)
		l1l1lll_l1_ = l1l1lll_l1_[0]
		#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ䆷"),l1111_l1_ (u"ࠪࠫ䆸"),l1l1lll_l1_,str(1111))
	# download
	elif l1111_l1_ (u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬ䆹") in url:
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䆺"),url,l1111_l1_ (u"࠭ࠧ䆻"),l1111_l1_ (u"ࠧࠨ䆼"),True,l1111_l1_ (u"ࠨࠩ䆽"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬ䆾"))
		l11llll1_l1_ = response.content
		if l1111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䆿") in list(response.headers.keys()): l1l1lll_l1_ = response.headers[l1111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䇀")]
		else: l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䇁"),l11llll1_l1_,re.DOTALL)[0]
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䇂"),l1111_l1_ (u"ࠧࠨ䇃"),l1l1lll_l1_,str(2222))
	if l1111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䇄") in l1l1lll_l1_ or l1111_l1_ (u"ࠩ࠲ࡪ࠴࠭䇅") in l1l1lll_l1_:
		l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠪ࠳࡫࠵ࠧ䇆"),l1111_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䇇"))
		l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䇈"),l1111_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䇉"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䇊"),l1111_l1_ (u"ࠨࠩ䇋"),l1l1lll_l1_,str(3333))
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䇌"),l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ䇍"),l1111_l1_ (u"ࠫࠬ䇎"),l1111_l1_ (u"ࠬ࠭䇏"),l1111_l1_ (u"࠭ࠧ䇐"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪ䇑"))
		l11llll1_l1_ = response.content
		items = re.findall(l1111_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䇒"),l11llll1_l1_,re.DOTALL)
		if items:
			for l1l111l_l1_,title in items:
				l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠩ࡟ࡠࠬ䇓"),l1111_l1_ (u"ࠪࠫ䇔"))
				l11111l_l1_.append(title)
				l11lll1l_l1_.append(l1l111l_l1_)
		else:
			items = re.findall(l1111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䇕"),l11llll1_l1_,re.DOTALL)
			if items:
				l1l111l_l1_ = items[0]
				l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠬࡢ࡜ࠨ䇖"),l1111_l1_ (u"࠭ࠧ䇗"))
				l11111l_l1_.append(l1111_l1_ (u"ࠧࠨ䇘"))
				l11lll1l_l1_.append(l1l111l_l1_)
	else: return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䇙"),[l1111_l1_ (u"ࠩࠪ䇚")],[l1l1lll_l1_]
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ䇛"),l1111_l1_ (u"ࠫࠬ䇜"),str(l11lll1ll_l1_),l1l1lll_l1_)
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ䇝"),[],[]
	return l1111_l1_ (u"࠭ࠧ䇞"),l11111l_l1_,l11lll1l_l1_
def l111llll111_l1_(url):
	# l11ll1l1l_l1_ l1111l1l_l1_  l1ll11ll_l1_://l1l1111l1l1l_l1_.l11ll1ll11ll_l1_.l111l111ll_l1_/l1ll1llll111_l1_/l11l1l1l11l1_l1_.l1lll1111l_l1_?s=07&id=l11l1l1ll1l1_l1_,&img=2wh9shmvcTypozADtS8EpvgrwWS.jpg&l11ll1111l11_l1_=l1ll1111l1ll_l1_&l1l111l1llll_l1_=l11l1lll11l1_l1_
	# l11ll1l1l_l1_ l1llll111_l1_ l1ll11ll_l1_://l11ll1llll1l_l1_.l11ll1ll11ll_l1_.l111l111ll_l1_/l1ll1llll111_l1_/l11lll11ll1l_l1_.l1lll1111l_l1_?l11l1ll1lll1_l1_=l11ll1ll1ll1_l1_&l11ll1l1l1ll_l1_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.jpg&l11ll1111l11_l1_=l1ll1111l1ll_l1_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.jpg&l11ll1111l11_l1_=l1ll1111l1ll_l1_&l1l111l1llll_l1_=l11lll1lll1l_l1_
	# download l1ll11ll_l1_://l1ll11llll11_l1_.l11ll111ll1l_l1_.l11llllll111_l1_/l1l11ll111ll_l1_?server=l11lll1111l1_l1_&id=l11l1l1llll1_l1_,,
	# l11l1l11l_l1_ l1ll11ll_l1_://l11ll111ll1l_l1_.l1lll11l1l_l1_/l11l1l11l_l1_/l1l11l111ll1_l1_
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ䇟"),url,l1111_l1_ (u"ࠨࠩ䇠"),l1111_l1_ (u"ࠩࠪ䇡"),l1111_l1_ (u"ࠪࠫ䇢"),l1111_l1_ (u"ࠫࠬ䇣"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬ䇤"))
	html = response.content
	l11111l_l1_,l11lll1l_l1_,errno = [],[],l1111_l1_ (u"࠭ࠧ䇥")
	if l1111_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ䇦") in url or l1111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ䇧") in url:
		if l1111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ䇨") in url:
			l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䇩"),html,re.DOTALL)
			l1l1lll_l1_ = l1l1lll_l1_[0]
		else: l1l1lll_l1_ = url
		if l1111_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ䇪") not in l1l1lll_l1_: return l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䇫"),[l1111_l1_ (u"࠭ࠧ䇬")],[l1l1lll_l1_]
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ䇭"),l1l1lll_l1_,l1111_l1_ (u"ࠨࠩ䇮"),l1111_l1_ (u"ࠩࠪ䇯"),l1111_l1_ (u"ࠪࠫ䇰"),l1111_l1_ (u"ࠫࠬ䇱"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ䇲"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ䇳"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䇴"),block,re.DOTALL)
		if items:
			for l1l111l_l1_,l1lll1ll1l1l_l1_ in items:
				l11111l_l1_.append(l1lll1ll1l1l_l1_)
				l11lll1l_l1_.append(l1l111l_l1_)
	elif l1111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ䇵") in url:
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭䇶"),html,re.DOTALL)
		l1l1lll_l1_ = l1l1lll_l1_[0]
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䇷"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬ䇸"),l1111_l1_ (u"ࠬ࠭䇹"),l1111_l1_ (u"࠭ࠧ䇺"),l1111_l1_ (u"ࠧࠨ䇻"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨ䇼"))
		html = response.content
		l11l11_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䇽"),html,re.DOTALL)
		l11l11_l1_ = l11l11_l1_[0]
		l11111l_l1_.append(l1111_l1_ (u"ࠪࠫ䇾"))
		l11lll1l_l1_.append(l11l11_l1_)
	elif l1111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ䇿") in url:
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䈀"),html,re.DOTALL)
		if l1l1lll_l1_:
			l1l1lll_l1_ = l1l1lll_l1_[0]
			return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䈁"),[l1111_l1_ (u"ࠧࠨ䈂")],[l1l1lll_l1_]
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪ䈃"),[],[]
	return l1111_l1_ (u"ࠩࠪ䈄"),l11111l_l1_,l11lll1l_l1_
def l11l1l111l_l1_(url):
	# l1ll11ll_l1_://l11l1l1ll111_l1_.l1l1111lll11_l1_/l11lll1l1l11_l1_?call=l1l11l11l1ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11lll1llll1_l1_=l11l1ll1l1l1_l1_
	# l1ll11ll_l1_://l11l1l1ll111_l1_.l1l1111lll11_l1_/l11lll1l1l11_l1_?call=l1l11l11l1ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11lll1llll1_l1_=l11lllll1ll1_l1_
	l1l1lll_l1_ = url.split(l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䈅"),1)[0].strip(l1111_l1_ (u"ࠫࡄ࠭䈆")).strip(l1111_l1_ (u"ࠬ࠵ࠧ䈇")).strip(l1111_l1_ (u"࠭ࠦࠨ䈈"))
	l11111l_l1_,l11lll1l_l1_,items,l11l11_l1_ = [],[],[],l1111_l1_ (u"ࠧࠨ䈉")
	headers = { l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䈊"):l1111_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩ䈋") }
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䈌"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬ䈍"),headers,True,l1111_l1_ (u"ࠬ࠭䈎"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠵ࡸࡺࠧ䈏"))
	if l1111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䈐") in list(response.headers.keys()): l11l11_l1_ = response.headers[l1111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䈑")]
	#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭䈒"),l11l11_l1_,l1111_l1_ (u"ࠪࠫ䈓"),headers,False,l1111_l1_ (u"ࠫࠬ䈔"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠵ࡲࡩ࠭䈕"))
	#if l1111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䈖") in response.headers: l11l11_l1_ = response.headers[l1111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䈗")]
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䈘"),l1111_l1_ (u"ࠩࠪ䈙"),l11l11_l1_,response.content)
	if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䈚") in l11l11_l1_:
		# l1ll11ll_l1_://l11l1ll111_l1_.top/f/l1l11111lll1_l1_/?l11lllll11_l1_=l1l11ll111l1_l1_
		# l1ll11ll_l1_://l11l1ll111_l1_.top/v/l1l11111lll1_l1_/?l11lllll11_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l1111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䈛") in url: l11l11_l1_ = l11l11_l1_.replace(l1111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䈜"),l1111_l1_ (u"࠭࠯ࡷ࠱ࠪ䈝"))
		l11llll1l1l1_l1_ = l1l1lll_l1_.split(l1111_l1_ (u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ䈞"))[1]
		headers = { l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䈟"):headers[l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䈠")] , l1111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䈡"):l1111_l1_ (u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ䈢")+l11llll1l1l1_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䈣"),l11l11_l1_,l1111_l1_ (u"࠭ࠧ䈤"),headers,False,l1111_l1_ (u"ࠧࠨ䈥"),l1111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䈦"))
		html = response.content
		#xbmc.log(html)
		#html = l111l11_l1_(l1ll1llll_l1_,l11l11_l1_,l1111_l1_ (u"ࠩࠪ䈧"),headers,l1111_l1_ (u"ࠪࠫ䈨"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠵ࡵࡨࠬ䈩"))
		if l1111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䈪") in l11l11_l1_: items = re.findall(l1111_l1_ (u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䈫"),html,re.DOTALL)
		elif l1111_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䈬") in l11l11_l1_: items = re.findall(l1111_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䈭"),html,re.DOTALL)
		if items: return [],[l1111_l1_ (u"ࠩࠪ䈮")],[ items[0] ]
		elif l1111_l1_ (u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩ䈯") in html:
			return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧ䈰"),[],[]
	else: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨ䈱"),[],[]
	#xbmc.log(html)
def l111l1ll1l1_l1_(l1l111l_l1_):
	# l1ll11ll_l1_://l1l11ll1llll_l1_.l1ll1111_l1_/?l11lllll_l1_=147043&l1l1111l_l1_=5
	parts = re.findall(l1111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䈲"),l1l111l_l1_+l1111_l1_ (u"ࠧࠧࠨࠪ䈳"),re.DOTALL|re.IGNORECASE)
	l11lllll_l1_,l1l1111l_l1_ = parts[0]
	url = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䈴")+l11lllll_l1_+l1111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭䈵")+l1l1111l_l1_
	headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䈶"):l1111_l1_ (u"ࠫࠬ䈷") , l1111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䈸"):l1111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䈹") }
	l1l1lll_l1_ = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠧࠨ䈺"),headers,l1111_l1_ (u"ࠨࠩ䈻"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ䈼"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ䈽"),l1111_l1_ (u"ࠫࠬ䈾"),url,l1l1lll_l1_)
	#l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11111ll1l_l1_(l1l1lll_l1_)
	#return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	return l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䈿"),[l1111_l1_ (u"࠭ࠧ䉀")],[l1l1lll_l1_]
def l1lll11llll1_l1_(url):
	# l1ll11ll_l1_://l1l1111l1lll_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1l11111l1ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l1lll1lll_l1_=1608181746
	server = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䉁"))
	l1l1lll11_l1_ = {l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䉂"):server,l1111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ䉃"):l1111_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ䉄")}
	response = l1l11l_l1_(l1lll11ll1l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䉅"),url,l1111_l1_ (u"ࠬ࠭䉆"),l1l1lll11_l1_,l1111_l1_ (u"࠭ࠧ䉇"),l1111_l1_ (u"ࠧࠨ䉈"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ䉉"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ䉊"),html,re.DOTALL)
	l1l1lll_l1_ = l1111_l1_ (u"ࠪࠫ䉋")
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䉌"),block,re.DOTALL)
		l11111l_l1_,l11lll1l_l1_ = [],[]
		for title,l1l111l_l1_ in items:
			l11111l_l1_.append(title)
			l11lll1l_l1_.append(l1l111l_l1_)
		if len(l11lll1l_l1_)==1: l1l1lll_l1_ = l11lll1l_l1_[0]
		elif len(l11lll1l_l1_)>1:
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䉍"), l11111l_l1_)
			if l1l_l1_==-1: return l1111_l1_ (u"࠭ࠧ䉎"),[],[]
			l1l1lll_l1_ = l11lll1l_l1_[l1l_l1_]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䉏"),html,re.DOTALL)
		if l111l1l_l1_: l1l1lll_l1_ = l111l1l_l1_[0]
	if not l1l1lll_l1_: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ䉐"),[],[]
	return l1111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䉑"),[l1111_l1_ (u"ࠪࠫ䉒")],[l1l1lll_l1_]
def l1ll1l1l1lll_l1_(url):
	# l1ll11ll_l1_://l1l11lll111l_l1_.l1l11l1111l1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1l11111l1ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l1lll1lll_l1_=1608181746
	server = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䉓"))
	l1l1lll11_l1_ = {l1111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䉔"):server,l1111_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䉕"):l1111_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䉖")}
	response = l1l11l_l1_(l1lll11ll1l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䉗"),url,l1111_l1_ (u"ࠩࠪ䉘"),l1l1lll11_l1_,l1111_l1_ (u"ࠪࠫ䉙"),l1111_l1_ (u"ࠫࠬ䉚"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䉛"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䉜"),html,re.DOTALL)
	l1l1lll_l1_ = l1111_l1_ (u"ࠧࠨ䉝")
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䉞"),block,re.DOTALL)
		l11111l_l1_,l11lll1l_l1_ = [],[]
		for title,l1l111l_l1_ in items:
			l11111l_l1_.append(title)
			l11lll1l_l1_.append(l1l111l_l1_)
		if len(l11lll1l_l1_)==1: l1l1lll_l1_ = l11lll1l_l1_[0]
		elif len(l11lll1l_l1_)>1:
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䉟"), l11111l_l1_)
			if l1l_l1_==-1: return l1111_l1_ (u"ࠪࠫ䉠"),[],[]
			l1l1lll_l1_ = l11lll1l_l1_[l1l_l1_]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䉡"),html,re.DOTALL)
		if l111l1l_l1_: l1l1lll_l1_ = l111l1l_l1_[0]
	if not l1l1lll_l1_: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ䉢"),[],[]
	return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䉣"),[l1111_l1_ (u"ࠧࠨ䉤")],[l1l1lll_l1_]
def l1l1l1l1_l1_(l1l111l_l1_):
	# l1ll11ll_l1_://w.l11lll11l1l1_l1_.l11ll11ll1l1_l1_/l11lllll1lll_l1_-content/l1l11l111l1l_l1_/l11lll111lll_l1_/l11ll11ll111_l1_/l1l111l1ll11_l1_/l11l1lll1ll1_l1_/l11lllllll11_l1_.l1lll1111l_l1_?l11lllll_l1_=42869&l1l1111l_l1_=4
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䉥"),l1111_l1_ (u"ࠩࠪ䉦"),l1l111l_l1_,html)
	parts = re.findall(l1111_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䉧"),l1l111l_l1_+l1111_l1_ (u"ࠫࠫࠬࠧ䉨"),re.DOTALL)
	url,l11lllll_l1_,l1l1111l_l1_ = parts[0]
	data = {l1111_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭䉩"):l11lllll_l1_,l1111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭䉪"):l1l1111l_l1_}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䉫"),url,data,l1111_l1_ (u"ࠨࠩ䉬"),l1111_l1_ (u"ࠩࠪ䉭"),l1111_l1_ (u"ࠪࠫ䉮"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭䉯"))
	html = response.content
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䉰"),html,re.DOTALL)[0]
	return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䉱"),[l1111_l1_ (u"ࠧࠨ䉲")],[l1l1lll_l1_]
def l1ll1ll111_l1_(url):
	# l1ll11ll_l1_://l11llll1l11l_l1_.l1lll11l11_l1_-l11l1l1l1l11_l1_.com/l11l1l11l_l1_.l1lll1111l_l1_?l11lll1lll11_l1_=l1l111ll11ll_l1_
	# l1ll11ll_l1_://l.l11llllllll1_l1_.l11llllll111_l1_/l11l1l11l_l1_.l1lll1111l_l1_?l11lll1lll11_l1_=40e2032d1
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䉳"),url,l1111_l1_ (u"ࠩࠪ䉴"),l1111_l1_ (u"ࠪࠫ䉵"),l1111_l1_ (u"ࠫࠬ䉶"),l1111_l1_ (u"ࠬ࠭䉷"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࠷ࡳࡵࠩ䉸"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䉹"),html,re.DOTALL)
	if l1l111l_l1_:
		l1l111l_l1_ = l1l111l_l1_[0]
		return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䉺"),[l1111_l1_ (u"ࠩࠪ䉻")],[l1l111l_l1_]
	return l1111_l1_ (u"ࠪࠫ䉼"),[],[]
def l1lll1l11l_l1_(url):
	# l1ll11ll_l1_://l1lll111ll_l1_.l1lll11l11_l1_-l1lll11l1l_l1_.l1lll11l1l_l1_/l11lllll1lll_l1_-content/l1l11l111l1l_l1_/old/l11lll1l1lll_l1_/server.l1lll1111l_l1_?q=140276&i=3
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䉽"),url,l1111_l1_ (u"ࠬ࠭䉾"),l1111_l1_ (u"࠭ࠧ䉿"),l1111_l1_ (u"ࠧࠨ䊀"),l1111_l1_ (u"ࠨࠩ䊁"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ䊂"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䊃"),html,re.DOTALL)[0]
	return l1111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䊄"),[l1111_l1_ (u"ࠬ࠭䊅")],[l1l111l_l1_]
def l1ll1l1lll_l1_(url):
	# l1ll11ll_l1_://l1l111l1lll1_l1_.l1ll1111lll1_l1_.cc/l11lllll1lll_l1_-content/l1l11l111l1l_l1_/l11llll11l11_l1_%20Now%20New/l1l111l1l1l1_l1_.l1lll1111l_l1_?action=l11l1l11lll1_l1_&index=00&id=58504
	# l1ll11ll_l1_://l11l1ll11l11_l1_.l1ll1111lll1_l1_.l1ll1111_l1_/l1l11l1l1111_l1_/2021/04/05/_1l111ll1ll1_l1_-l1l11l1lllll_l1_.l11l1l1l1lll_l1_ 200.l11l1ll1llll_l1_.2020.l11l1ll111ll_l1_/[l11llll11l11_l1_-l1l11l1lllll_l1_.l11l1l11l1ll_l1_] 200.l11l1ll1llll_l1_.2020.l11l1ll111ll_l1_-360p.l1111l1l_l1_
	l1lllll1l1_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ䊆"))
	if l1111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ䊇") in url:
		headers = {l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䊈"):l1lllll1l1_l1_}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭䊉"),url,l1111_l1_ (u"ࠪࠫ䊊"),headers,l1111_l1_ (u"ࠫࠬ䊋"),l1111_l1_ (u"ࠬ࠭䊌"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ䊍"))
		html = response.content
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䊎"),html,re.DOTALL)
		if l1l1lll_l1_:
			l1l1lll_l1_ = l1l1lll_l1_[0]
			if l1111_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䊏") in l1l1lll_l1_:
				l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ䊐"),l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ䊑"))
				response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ䊒"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭䊓"),headers,l1111_l1_ (u"࠭ࠧ䊔"),l1111_l1_ (u"ࠧࠨ䊕"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ䊖"))
				l11llll1_l1_ = response.content
				items = re.findall(l1111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䊗"),l11llll1_l1_,re.DOTALL)
				l11111l_l1_,l11lll1l_l1_ = [],[]
				l1lllll11l_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧ䊘"))
				for l1l111l_l1_,l11l1111_l1_ in reversed(items):
					l1l111l_l1_ = l1lllll11l_l1_+l1l111l_l1_+l1111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䊙")+l1lllll11l_l1_
					l11111l_l1_.append(l11l1111_l1_)
					l11lll1l_l1_.append(l1l111l_l1_)
				return l1111_l1_ (u"ࠬ࠭䊚"),l11111l_l1_,l11lll1l_l1_
			else: return l1111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䊛"),[l1111_l1_ (u"ࠧࠨ䊜")],[l1l1lll_l1_]
	l1l1lll_l1_ = url+l1111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䊝")+l1lllll1l1_l1_
	return l1111_l1_ (u"ࠩࠪ䊞"),[l1111_l1_ (u"ࠪࠫ䊟")],[l1l1lll_l1_]
def l11ll11lll11_l1_(l1l111l_l1_):
	# l1ll11ll_l1_://l1ll1111lll1_l1_.l11ll11ll1l1_l1_/l11lllll1lll_l1_-content/l1l11l111l1l_l1_/l1l1l1111111_l1_/l1l11111l11l_l1_/server.l1lll1111l_l1_?l11lllll_l1_=42869&l1l1111l_l1_=4
	# l1ll11ll_l1_://l11ll1l1ll11_l1_.l1ll1111lll1_l1_.l1ll1111_l1_/l1l11l1l1111_l1_/2020/08/14/_1l111ll1ll1_l1_-l1l11l1lllll_l1_.l11l1l1l1lll_l1_ l11l1l1ll11l_l1_.l11l1llll1ll_l1_.2020.l11ll11l111l_l1_-l11ll11l1ll1_l1_/[l11llll11l11_l1_-l1l11l1lllll_l1_.l11l1l11l1ll_l1_] l11l1l1ll11l_l1_.l11l1llll1ll_l1_.2020.l11ll11l111l_l1_-l11ll11l1ll1_l1_-1080p.l1111l1l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䊠"),l1111_l1_ (u"ࠬ࠭䊡"),url,html)
	l1lllll1l1_l1_ = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ䊢"))
	if l1111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䊣") in l1l111l_l1_:
		parts = re.findall(l1111_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䊤"),l1l111l_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ䊥"),re.DOTALL)
		url,l11lllll_l1_,l1l1111l_l1_ = parts[0]
		data = {l1111_l1_ (u"ࠪ࡭ࡩ࠭䊦"):l11lllll_l1_,l1111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䊧"):l1l1111l_l1_}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䊨"),url,data,l1111_l1_ (u"࠭ࠧ䊩"),l1111_l1_ (u"ࠧࠨ䊪"),l1111_l1_ (u"ࠨࠩ䊫"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ䊬"))
		html = response.content
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䊭"),html,re.DOTALL)[0]
		if l1111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䊮") in l1l1lll_l1_:
			headers = {l1111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䊯"):l1lllll1l1_l1_,l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䊰"):l1111_l1_ (u"ࠧࠨ䊱")}
			response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䊲"),l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ䊳"),headers,l1111_l1_ (u"ࠪࠫ䊴"),l1111_l1_ (u"ࠫࠬ䊵"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䊶"))
			l11llll1_l1_ = response.content
			items = re.findall(l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䊷"),l11llll1_l1_,re.DOTALL)
			l11111l_l1_,l11lll1l_l1_ = [],[]
			l1lllll11l_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䊸"))
			for l1l111l_l1_,l11l1111_l1_ in reversed(items):
				l1l111l_l1_ = l1lllll11l_l1_+l1l111l_l1_+l1111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䊹")+l1lllll11l_l1_
				l11111l_l1_.append(l11l1111_l1_)
				l11lll1l_l1_.append(l1l111l_l1_)
			return l1111_l1_ (u"ࠩࠪ䊺"),l11111l_l1_,l11lll1l_l1_
		else: return l1111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䊻"),[l1111_l1_ (u"ࠫࠬ䊼")],[l1l1lll_l1_]
	else:
		l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䊽")+l1lllll1l1_l1_
		return l1111_l1_ (u"࠭ࠧ䊾"),[l1111_l1_ (u"ࠧࠨ䊿")],[l1l111l_l1_]
def l11l111l1_l1_(l1l111l_l1_):
	# http://l1l111l1111l_l1_.tv/?l11lllll_l1_=159485&l1l1111l_l1_=0
	if l1111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ䋀") in l1l111l_l1_:
		parts = re.findall(l1111_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䋁"),l1l111l_l1_+l1111_l1_ (u"ࠪࠪࠫ࠭䋂"),re.DOTALL|re.IGNORECASE)
		l11lllll_l1_,l1l1111l_l1_ = parts[0]
		host = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䋃"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭䋄"),l1111_l1_ (u"࠭ࠧ䋅"),l1l111l_l1_,host)
		url = host+l1111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ䋆")+l11lllll_l1_+l1111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ䋇")+l1l1111l_l1_
		headers = { l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䋈"):l1111_l1_ (u"ࠪࠫ䋉") , l1111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䋊"):l1111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䋋") }
		l1l1lll_l1_ = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"࠭ࠧ䋌"),headers,l1111_l1_ (u"ࠧࠨ䋍"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ䋎"))
		l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬ䋏"),l1111_l1_ (u"ࠪࠫ䋐")).replace(l1111_l1_ (u"ࠫࡡࡸࠧ䋑"),l1111_l1_ (u"ࠬ࠭䋒"))
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䋓"),l1111_l1_ (u"ࠧࠨ䋔"),url,l1l1lll_l1_)
		#l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1l11111ll1l_l1_(l1l1lll_l1_)
		#return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
		return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䋕"),[l1111_l1_ (u"ࠩࠪ䋖")],[l1l1lll_l1_]
	elif l1111_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ䋗") in l1l111l_l1_:
		counts = 0
		while l1111_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ䋘") in l1l111l_l1_ and counts<5:
			response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ䋙"),l1l111l_l1_,l1111_l1_ (u"࠭ࠧ䋚"),l1111_l1_ (u"ࠧࠨ䋛"),l1111_l1_ (u"ࠨࠩ䋜"),l1111_l1_ (u"ࠩࠪ䋝"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬ䋞"))
			if l1111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䋟") in list(response.headers.keys()): l1l111l_l1_ = response.headers[l1111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䋠")]
			counts += 1
		return l1111_l1_ (u"࠭ࠧ䋡"),[l1111_l1_ (u"ࠧࠨ䋢")],[l1l111l_l1_]
	else: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ䋣"),[],[]
def l11ll1111_l1_(url):
	# l1ll11ll_l1_://l1l111l11111_l1_.l11ll1111lll_l1_.me/l/l1l111ll11l1_l1_=
	server = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠩࡸࡶࡱ࠭䋤"))
	headers = {l1111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䋥"):server,l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䋦"):l1l111l1l_l1_()}
	if l1111_l1_ (u"ࠬ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䋧") in url:
		l1l1lll11_l1_ = {l1111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䋨"):l1111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䋩")}
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䋪"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,True,l1111_l1_ (u"ࠩࠪ䋫"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠳ࡶࡸࠬ䋬"))
		html = response.content
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠫࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䋭"),html,re.DOTALL|re.IGNORECASE)
		if l11l1ll1_l1_: return l1111_l1_ (u"ࠬ࠭䋮"),[l1111_l1_ (u"࠭ࠧ䋯")],[l11l1ll1_l1_[0]]
	elif l1111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ䋰") in url:
		html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠨࠩ䋱"),headers,l1111_l1_ (u"ࠩࠪ䋲"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ䋳"))
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䋴"),html,re.DOTALL)
		if l11l1ll1_l1_: return l1111_l1_ (u"ࠬ࠭䋵"),[l1111_l1_ (u"࠭ࠧ䋶")],[l11l1ll1_l1_[0]]
	else:
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ䋷"),url,l1111_l1_ (u"ࠨࠩ䋸"),headers,l1111_l1_ (u"ࠩࠪ䋹"),l1111_l1_ (u"ࠪࠫ䋺"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠶ࡶࡩ࠭䋻"))
		if l1111_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ䋼") in list(response.headers.keys()):
			cookies = response.headers[l1111_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ䋽")]
			l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠴ࠪࡀ࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ䋾"),cookies,re.DOTALL)
			if l11l1ll1_l1_:
				l1l111l_l1_ = UNQUOTE(l11l1ll1_l1_[0])
				return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䋿"),[l1111_l1_ (u"ࠩࠪ䌀")],[l1l111l_l1_]
	return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧ䌁"),[],[]
	l1111_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࠤࡳࡵࡴࠡࡹࡲࡶࡰ࡯࡮ࡨࠌࠌࠍࠨࠦࡩࡵࠢࡱࡩࡪࡪࡳࠡࡥࡲࡳࡰ࡯ࡥࠡࡨࡵࡳࡲࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠍࠍࠎࠩࠠࡄࡱࡲ࡯࡮࡫࠺ࠡࡥࡩࡣࡨࡲࡥࡢࡴࡤࡲࡨ࡫࠽ࡄࡏࡨ࠲ࡍࡑࡇࡒ࡭ࡰࡻࡳ࡙ࡖࡶࡰࡽ࡚ࡎࡶࡱࡰࡹࡴࡗࡆࡠࡣࡱࡰࡉ࠻࡯ࡈࡐࡖࡑࡔࡦ࡞ࡈࡆ࠱࠯࠴࠺࠻࠹࠱࠲࠴࠳࠴࠻࠳࠰࠮࠴࠸࠴ࠏࠏࠉࡴࡧࡵࡺࡪࡸࠠ࠾ࠢࡖࡉࡗ࡜ࡅࡓࠪࡸࡶࡱ࠲ࠧࡶࡴ࡯ࠫ࠮ࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠨࠪ࠮ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿ࡹࡥࡳࡸࡨࡶࢂࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧࠪࠌࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࡾࡵࡩ࠳ࡏࡇࡏࡑࡕࡉࡈࡇࡓࡆࠫࠍࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡥ࡮ࡤࡨࡨ࠲࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮࡞ࠫࠬࡣࠬ࡜࡮࡬ࡲࡰࡣࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡸࡶࡱࠦ࠽ࠡ࡮࡬ࡲࡰࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩ࠭ࡪࡷࡱࡱ࠯ࠊࠊࠋࠦࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࠏࠣࡪࡨࠣࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠥࠌࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠤࠋࡵࡩࡹࡻࡲ࡯ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡺࡸ࡬ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠋࠋࠥࠦࠧ䌂")
	#if l1111_l1_ (u"ࠬ࠴࡭ࡱ࠶࠱࡬ࡹࡳ࡬ࠨ䌃") in url:
	#	l1lll1111lll_l1_ = url.split(l1111_l1_ (u"࠭࠯ࠨ䌄"))
	#	url = l1111_l1_ (u"ࠧ࠰ࠩ䌅").join(l1lll1111lll_l1_[:4])
	#	tmp = re.findall(l1111_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࠲࠳࠳࠰࠿࠰ࠫࠫ࠲࠯ࡅࠩࠥࠩ䌆"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l1111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䌇")+tmp[0][1]+l1111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ䌈")
	#	#return l1111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䌉"),[l1111_l1_ (u"ࠬ࠭䌊")],[url]
	#	#l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l11l1lllll11_l1_(url)
	#	#return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
	# l11l1l11l_l1_ l1l111l_l1_
	#return l1111_l1_ (u"࠭ࠧ䌋"),[l1111_l1_ (u"ࠧࠨ䌌")],[l1l111l_l1_]
def l1ll1l1l111l_l1_(l1l111l_l1_):
	# l1ll11ll_l1_://l1ll11ll1ll1_l1_.l1ll1111_l1_/?l11lllll_l1_=142302&l1l1111l_l1_=4
	parts = re.findall(l1111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䌍"),l1l111l_l1_,re.DOTALL|re.IGNORECASE)
	l11lllll_l1_,l1l1111l_l1_ = parts[0]
	server = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭䌎"))
	url = server+l1111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䌏")
	#url = server+l1111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䌐")+l11lllll_l1_+l1111_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ䌑")+l1l1111l_l1_
	#data = {l1111_l1_ (u"࠭ࡩࡥࠩ䌒"):l11lllll_l1_,l1111_l1_ (u"ࠧࡪࠩ䌓"):l1l1111l_l1_,l1111_l1_ (u"ࠨ࡯ࡨࡸࡦ࠭䌔"):l1111_l1_ (u"ࠩࡲࡰࡩࡥࡳࡦࡴࡹࡩࡷࡹࠧ䌕"),l1111_l1_ (u"ࠪࡸࡾࡶࡥࠨ䌖"):l1111_l1_ (u"ࠫࡴࡲࡤࠨ䌗")}
	data = {l1111_l1_ (u"ࠬ࡯ࡤࠨ䌘"):l11lllll_l1_,l1111_l1_ (u"࠭ࡩࠨ䌙"):l1l1111l_l1_}
	headers = {l1111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䌚"):l1111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䌛"),l1111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䌜"):l1l111l_l1_}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䌝"),url,data,headers,l1111_l1_ (u"ࠫࠬ䌞"),l1111_l1_ (u"ࠬ࠭䌟"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠶ࡹࡴࠨ䌠"))
	l11llll1_l1_ = response.content
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䌡"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
	if l1l1lll_l1_:
		l1l1lll_l1_ = l1l1lll_l1_[0]
		return l1111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䌢"),[l1111_l1_ (u"ࠩࠪ䌣")],[l1l1lll_l1_]
	return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡂࡊࡌࡈ࠹࡛ࠧ䌤"),[],[]
def l1l1ll1_l1_(l1l1lll_l1_,type,l11l1111_l1_):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䌥"),l1111_l1_ (u"ࠬ࠭䌦"),l1l1lll_l1_,type)
	# l1ll11ll_l1_://l1l1111ll1l1_l1_-2o.com/l11ll1l1l_l1_/12899		?l11lll1llll1_l1_=		__1l11llllll1_l1_
	# l1ll11ll_l1_://l1l1111ll1l1_l1_-2o.com/l1l111l_l1_/12899			?l11lll1llll1_l1_=		__11ll11l1lll_l1_
	# http://l1l11111l1l1_l1_.l11llll11ll1_l1_.io/l11ll1l1l_l1_/85288
	# http://l1l11111l1l1_l1_.l11llll11ll1_l1_.io/l1l111l_l1_/12899
	l11llll1_l1_ = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"࠭ࠧ䌧"),l1111_l1_ (u"ࠧࠨ䌨"),True,l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ䌩"))
	l11l11_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䌪"),l11llll1_l1_,re.DOTALL)
	if l11l11_l1_: l11l11_l1_ = UNQUOTE(l11l11_l1_[0])
	else: l11l11_l1_ = l1l1lll_l1_
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ䌫"),l1111_l1_ (u"ࠫࠬ䌬"),l1111_l1_ (u"ࠬ࠭䌭"),l11l11_l1_)
	l11lll1l_l1_,l11111l_l1_ = [],[]
	if type==l1111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䌮"):
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ䌯"),l11l11_l1_,l1111_l1_ (u"ࠨࠩ䌰"),l1111_l1_ (u"ࠩࠪ䌱"),l1111_l1_ (u"ࠪࠫ䌲"),True,l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠲࡯ࡦࠪ䌳"))
		l1l1ll1l1_l1_ = response.content
		l1llllll1_l1_ = re.findall(l1111_l1_ (u"ࠬࡨࡴ࡯࠯࡯ࡳࡦࡪࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䌴"),l1l1ll1l1_l1_,re.DOTALL)
		if l1llllll1_l1_:
			l1l111l_l1_ = UNQUOTE(l1llllll1_l1_[0])
			l11lll1l_l1_.append(l1l111l_l1_)
			l11111l_l1_.append(l11l1111_l1_)
			#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䌵"),l1111_l1_ (u"ࠧࠨ䌶"),l1111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䌷"),l1l111l_l1_)
	elif type==l1111_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ䌸"):
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ䌹"),l11l11_l1_,l1111_l1_ (u"ࠫࠬ䌺"),l1111_l1_ (u"ࠬ࠭䌻"),l1111_l1_ (u"࠭ࠧ䌼"),True,l1111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䌽"))
		l1l1ll1l1_l1_ = response.content
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䌾"),l1l1ll1l1_l1_,re.DOTALL)
		for l1l111l_l1_,size in l11l1ll1_l1_:
			if l11l1111_l1_ in size:
				l11111l_l1_.append(size)
				l11lll1l_l1_.append(l1l111l_l1_)
				#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ䌿"),l1111_l1_ (u"ࠪࠫ䍀"),l1111_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䍁"),l1l111l_l1_)
				break
		if not l11lll1l_l1_:
			for l1l111l_l1_,size in l11l1ll1_l1_:
				l11111l_l1_.append(size)
				l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࡚ࠬࡅࡔࡖࠪ䍂"),l11lll1l_l1_)
	if not l11lll1l_l1_: return l1111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ䍃"),[],[]
	return l1111_l1_ (u"ࠧࠨ䍄"),l11111l_l1_,l11lll1l_l1_
def l11lll_l1_(url,name):
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䍅"),l1111_l1_ (u"ࠩࠪ䍆"),url,l11lll1llll1_l1_)
	# http://l11ll1l1l1l_l1_.l11lll11l1l1_l1_.l1ll1111_l1_/5cf68c23e6e79			?l11lll1llll1_l1_=			__1l11l1l1lll_l1_
	# http://w.l11ll1l1_l1_.l111l111ll_l1_/5e14fd0a2806e			?l11lll1llll1_l1_=			ok.l11ll11l1l11_l1_
	#l11lll1llll1_l1_ = l11lll1llll1_l1_.replace(l1111_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࡡࡢࠫ䍇"),l1111_l1_ (u"ࠫࠬ䍈")).split(l1111_l1_ (u"ࠬࡥ࡟ࠨ䍉"))[1]
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ䍊"),url,l1111_l1_ (u"ࠧࠨ䍋"),l1111_l1_ (u"ࠨࠩ䍌"),True,l1111_l1_ (u"ࠩࠪ䍍"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩ䍎"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l1111_l1_ (u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ䍏") in list(cookies.keys()):
		l11ll11l1_l1_ = cookies[l1111_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䍐")]
		l11ll11l1_l1_ = UNQUOTE(escapeUNICODE(l11ll11l1_l1_))
		items = re.findall(l1111_l1_ (u"࠭ࡲࡰࡷࡷࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䍑"),l11ll11l1_l1_,re.DOTALL)
		l1l1lll_l1_ = items[0].replace(l1111_l1_ (u"ࠧ࡝࠱ࠪ䍒"),l1111_l1_ (u"ࠨ࠱ࠪ䍓"))
		l1l1lll_l1_ = escapeUNICODE(l1l1lll_l1_)
	else: l1l1lll_l1_ = url
	if l1111_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ䍔") in l1l1lll_l1_:
		id = l1l1lll_l1_.split(l1111_l1_ (u"ࠪࠩ࠷ࡌࠧ䍕"))[-1]
		l1l1lll_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡧࡴࡤࡪ࠱࡭ࡸ࠵ࠧ䍖")+id
		return l1111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䍗"),[l1111_l1_ (u"࠭ࠧ䍘")],[l1l1lll_l1_]
	else:
		l1l1lll1_l1_ = l111lll_l1_[l1111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭䍙")][0]
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ䍚"),l1l1lll1_l1_,l1111_l1_ (u"ࠩࠪ䍛"),l1111_l1_ (u"ࠪࠫ䍜"),True,l1111_l1_ (u"ࠫࠬ䍝"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫ䍞"))
		l11lll1ll1ll_l1_ = response.url
		#l11lll1ll1ll_l1_ = response.headers[l1111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䍟")]
		#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䍠"),l1111_l1_ (u"ࠨࠩ䍡"),response.url,l1l1lll1_l1_)
		l1l11l1llll1_l1_ = l1l1lll_l1_.split(l1111_l1_ (u"ࠩ࠲ࠫ䍢"))[2]#.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䍣"))
		l1l11llll111_l1_ = l11lll1ll1ll_l1_.split(l1111_l1_ (u"ࠫ࠴࠭䍤"))[2]#.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䍥"))
		l11l11_l1_ = l1l1lll_l1_.replace(l1l11l1llll1_l1_,l1l11llll111_l1_)
		headers = { l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䍦"):l1111_l1_ (u"ࠧࠨ䍧") , l1111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䍨"):l1111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䍩") , l1111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䍪"):l11l11_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䍫"), l11l11_l1_, l1111_l1_ (u"ࠬ࠭䍬"), headers, False,l1111_l1_ (u"࠭ࠧ䍭"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭䍮"))
		html = response.content
		#xbmc.log(str(l11l11_l1_), level=xbmc.LOGERROR)
		items = re.findall(l1111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䍯"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䍰"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1111_l1_ (u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䍱"),html,re.DOTALL|re.IGNORECASE)
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䍲"),l1111_l1_ (u"ࠬ࠭䍳"),str(items),html)
		if items:
			l1l111l_l1_ = items[0].replace(l1111_l1_ (u"࠭࡜࠰ࠩ䍴"),l1111_l1_ (u"ࠧ࠰ࠩ䍵"))
			l1l111l_l1_ = l1l111l_l1_.rstrip(l1111_l1_ (u"ࠨ࠱ࠪ䍶"))
			if l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䍷") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䍸") + l1l111l_l1_
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ䍹"),l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ䍺"))
			if name==l1111_l1_ (u"࠭ࠧ䍻"): l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠧࠨ䍼"),[l1111_l1_ (u"ࠨࠩ䍽")],[l1l111l_l1_]
			else: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䍾"),[l1111_l1_ (u"ࠪࠫ䍿")],[l1l111l_l1_]
		else: l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_ = l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬ䎀"),[],[]
		return l1l11l111111_l1_,l11111l_l1_,l11lll1l_l1_
def l11l1llll111_l1_(url):
	# l1ll11ll_l1_://l1ll11llll11_l1_.l11ll1l111ll_l1_.com/e/l1l11l11l1l1_l1_
	headers = { l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䎁") : l1111_l1_ (u"࠭ࠧ䎂") }
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠧࠨ䎃"),headers,l1111_l1_ (u"ࠨࠩ䎄"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭䎅"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ䎆"),l1111_l1_ (u"ࠫࠬ䎇"),url,html)
	items = re.findall(l1111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䎈"),html,re.DOTALL)
	l11111l_l1_,l11lll1l_l1_,errno = [],[],l1111_l1_ (u"࠭ࠧ䎉")
	if items:
		for l1l111l_l1_,l1lll1ll1l1l_l1_ in items:
			l11111l_l1_.append(l1lll1ll1l1l_l1_)
			l11lll1l_l1_.append(l1l111l_l1_)
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭䎊"),[],[]
	return l1111_l1_ (u"ࠨࠩ䎋"),l11111l_l1_,l11lll1l_l1_
def l11lll11l111_l1_(url):
	# l1ll11ll_l1_://l11llll11111_l1_.com/l11l1l11l_l1_-l1l111ll111l_l1_.html
	url = url.replace(l1111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䎌"),l1111_l1_ (u"ࠪࠫ䎍"))
	headers = { l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䎎") : l1111_l1_ (u"ࠬ࠭䎏") }
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"࠭ࠧ䎐"),headers,l1111_l1_ (u"ࠧࠨ䎑"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ䎒"))
	items = re.findall(l1111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䎓"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ䎔"),l1111_l1_ (u"ࠫࠬ䎕"),url,items[0])
	if items:
		url = items[0]+l1111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䎖")+url
		return l1111_l1_ (u"࠭ࠧ䎗"),[l1111_l1_ (u"ࠧࠨ䎘")],[url]
	else: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪ䎙"),[],[]
def l11lll11111l_l1_(url):
	# l1ll11ll_l1_://l1l11l1l111l_l1_.to/l11l1l11l_l1_/5c83f14297d62
	url = url.strip(l1111_l1_ (u"ࠩ࠲ࠫ䎚"))
	if l1111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ䎛") in url: id = url.split(l1111_l1_ (u"ࠫ࠴࠭䎜"))[4]
	else: id = url.split(l1111_l1_ (u"ࠬ࠵ࠧ䎝"))[-1]
	url = l1111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪ䎞") + id
	headers = { l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䎟") : l1111_l1_ (u"ࠨࠩ䎠") }
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠩࠪ䎡"),headers,l1111_l1_ (u"ࠪࠫ䎢"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡅࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭䎣"))
	html = html.replace(l1111_l1_ (u"ࠬࡢ࡜ࠨ䎤"),l1111_l1_ (u"࠭ࠧ䎥"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䎦"),l1111_l1_ (u"ࠨࠩ䎧"),url,html)
	items = re.findall(l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䎨"),html,re.DOTALL)
	if items: return l1111_l1_ (u"ࠪࠫ䎩"),[l1111_l1_ (u"ࠫࠬ䎪")],[ items[0] ]
	else: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡅࡖࡘࡗࡋࡁࡎࠩ䎫"),[],[]
def l11ll1lll11l_l1_(url):
	# l1ll11ll_l1_://l1l1111l1l11_l1_.l1ll1111_l1_/l11l1l11l_l1_-l1l11lllll1l_l1_.html
	url = url.replace(l1111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭䎬"),l1111_l1_ (u"ࠧࠨ䎭"))
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠨࠩ䎮"),l1111_l1_ (u"ࠩࠪ䎯"),l1111_l1_ (u"ࠪࠫ䎰"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫ䎱"))
	items = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䎲"),html,re.DOTALL)
	l11111l_l1_,l11lll1l_l1_ = [],[]
	for l1l111l_l1_,l1lll1ll1l1l_l1_,res in items:
		l11111l_l1_.append(l1lll1ll1l1l_l1_+l1111_l1_ (u"࠭ࠠࠨ䎳")+res)
		l11lll1l_l1_.append(l1l111l_l1_)
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡕ࡚ࡂࠩ䎴"),[],[]
	return l1111_l1_ (u"ࠨࠩ䎵"),l11111l_l1_,l11lll1l_l1_
def l11llll1ll1l_l1_(url):
	# l1ll11ll_l1_://l1l11l11111l_l1_.l1111llll1_l1_/l11l1l11l_l1_-l11lll111l1l_l1_.html
	url = url.replace(l1111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䎶"),l1111_l1_ (u"ࠪࠫ䎷"))
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠫࠬ䎸"),l1111_l1_ (u"ࠬ࠭䎹"),l1111_l1_ (u"࠭ࠧ䎺"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ䎻"))
	items = re.findall(l1111_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ䎼"),html,re.DOTALL)
	items = set(items)
	l11111l_l1_,l11lll1l_l1_ = [],[]
	for id,mode,hash,l1lll1ll1l1l_l1_,res in items:
		url = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭䎽")+id+l1111_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ䎾")+mode+l1111_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ䎿")+hash
		html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠬ࠭䏀"),l1111_l1_ (u"࠭ࠧ䏁"),l1111_l1_ (u"ࠧࠨ䏂"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠴ࡱࡨࠬ䏃"))
		items = re.findall(l1111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䏄"),html,re.DOTALL)
		for l1l111l_l1_ in items:
			l11111l_l1_.append(l1lll1ll1l1l_l1_+l1111_l1_ (u"ࠪࠤࠬ䏅")+res)
			l11lll1l_l1_.append(l1l111l_l1_)
	if len(l11lll1l_l1_)==0: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑࠪ䏆"),[],[]
	return l1111_l1_ (u"ࠬ࠭䏇"),l11111l_l1_,l11lll1l_l1_
def l11l1l1l111l_l1_(url):
	# l1ll11ll_l1_://l11ll11ll11l_l1_.com:2053/l11ll1l1111l_l1_/l11ll1llllll_l1_.l1l11l11l111_l1_.l1l11ll1ll11_l1_.1080p.l1l11l1l1l11_l1_.l1l11lllllll_l1_.l11l1ll111l1_l1_.l1111l1l_l1_.html?l1l11111l1ll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l1lll1lll_l1_=1624070560
	# http://l11lllllll1l_l1_.l11l111ll11_l1_/l11lll1l11ll_l1_/l11l1ll1ll1l_l1_.l11l1l1ll1ll_l1_.l11l1lll11ll_l1_.2018.1080p.l11ll11l111l_l1_-l11ll11l1ll1_l1_.l11llll11lll_l1_.l1111l1l_l1_.html
	l1l111l_l1_ = l1111_l1_ (u"࠭ࠧ䏈")
	if l1111_l1_ (u"ࠧࡌࡧࡼࡁࠬ䏉") not in url:
		l1l1lll_l1_ = url.replace(l1111_l1_ (u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ䏊"),l1111_l1_ (u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭䏋"))
		l1l1lll_l1_ = l1l1lll_l1_.split(l1111_l1_ (u"ࠪ࠳ࠬ䏌"))
		id = l1l1lll_l1_[3]
		l1l1lll_l1_ = l1111_l1_ (u"ࠫ࠴࠭䏍").join(l1l1lll_l1_[0:4])
		#headers = {l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䏎"):l1l111l1l_l1_(),l1111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䏏"):l1111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䏐")}
		payload = {l1111_l1_ (u"ࠨ࡫ࡧࠫ䏑"):id,l1111_l1_ (u"ࠩࡲࡴࠬ䏒"):l1111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭䏓"),l1111_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ䏔"):l1111_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ䏕")}
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䏖"),l1l1lll_l1_,payload,l1111_l1_ (u"ࠧࠨ䏗"),l1111_l1_ (u"ࠨࠩ䏘"),l1111_l1_ (u"ࠩࠪ䏙"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ䏚"))
		if l1111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䏛") in list(response.headers.keys()): l1l111l_l1_ = response.headers[l1111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䏜")]
	else:
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ䏝"),url,l1111_l1_ (u"ࠧࠨ䏞"),l1111_l1_ (u"ࠨࠩ䏟"),l1111_l1_ (u"ࠩࠪ䏠"),l1111_l1_ (u"ࠪࠫ䏡"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠲࡯ࡦࠪ䏢"))
		if l1111_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䏣") in list(response.headers.keys()): l1l111l_l1_ = response.headers[l1111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䏤")]
	if l1l111l_l1_: return l1111_l1_ (u"ࠧࠨ䏥"),[l1111_l1_ (u"ࠨࠩ䏦")],[l1l111l_l1_]
	return l1111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡖࡂࡐࡏࠪ䏧"),[],[]
def l1l111lll1l1_l1_(url):
	# l1ll11ll_l1_://l1ll11llll11_l1_.l1l11lll1l1l_l1_.com/012ocyw9li6g.html
	headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䏨") : l1111_l1_ (u"ࠫࠬ䏩") }
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠬ࠭䏪"),headers,l1111_l1_ (u"࠭ࠧ䏫"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ䏬"))
	items = re.findall(l1111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䏭"),html,re.DOTALL)
	l11111l_l1_,l11lll1l_l1_ = [],[]
	if items:
		l11111l_l1_.append(l1111_l1_ (u"ࠩࡰࡴ࠹࠭䏮"))
		l11lll1l_l1_.append(items[0][1])
		l11111l_l1_.append(l1111_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ䏯"))
		l11lll1l_l1_.append(items[0][0])
		return l1111_l1_ (u"ࠫࠬ䏰"),l11111l_l1_,l11lll1l_l1_
	else: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡋࡌ࡚ࡎࡊࡅࡐࠩ䏱"),[],[]
def l11l1ll1l1l_l1_(url):
	# l1l11l111lll_l1_ l111lll1lll_l1_			url = l1111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ䏲")
	# l11ll1lll1l1_l1_ .l1l11l1ll11l_l1_ l111lll1lll_l1_		url = l1111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡝ࡼ࡭ࡔࡐࡄࡽࡪࡿࡆࡊࠩ䏳")
	# l1l111l1l11l_l1_ l1l1l1111l_l1_ .l1llll111_l1_ l111lll1lll_l1_		url = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡍࡦ࠳࠯ࡑࡗࡹ࡙ࡳࡏࡹࠪ䏴")
	# l11llll111ll_l1_ l111lll1lll_l1_			url = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡥࡠࡕ࠼࡚ࡻࡐࡍ࠲ࡒࡌࠫ䏵")
	# l11lll111l_l1_ files have l11lll111ll1_l1_ l1ll111111ll_l1_		url = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࠲ࡹࡇࡖ࡚࡜ࡣࡔࡻࡢࡕࠬ䏶")
	# url = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ䏷")
	# url = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࠲ࡶ࠰ࡥࡩ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ䏸")
	# url = l1111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡨࡱࡧ࡫ࡤ࠰ࡧࡇࡰ࡟࠻ࡶࡂࡐࡔ࡙࡬࠭䏹")
	# url = l1111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩ䏺")
	# l1ll1lll1_l1_ l1l11l11ll1l_l1_ l11ll1l11111_l1_   l1ll11ll_l1_://l11lll111l11_l1_.me/l11ll1l1l1l1_l1_/l11l1ll11ll1_l1_-l11ll111l1l1_l1_-l1l11ll1l1l1_l1_
	id = url.split(l1111_l1_ (u"ࠨ࠱ࠪ䏻"))[-1]
	id = id.replace(l1111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ䏼"),l1111_l1_ (u"ࠪࠫ䏽"))
	#url = l1111_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ䏾")+id
	#return l1111_l1_ (u"ࠬ࠭䏿"),[l1111_l1_ (u"࠭ࠧ䐀")],[url]
	url = l111lll_l1_[l1111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䐁")][0]+l1111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ䐂")+id
	l11l1ll11lll_l1_,l11ll11lllll_l1_,l11lllll1l1l_l1_,l11lll1ll11l_l1_ = l1111_l1_ (u"ࠩࠪ䐃"),l1111_l1_ (u"ࠪࠫ䐄"),l1111_l1_ (u"ࠫࠬ䐅"),l1111_l1_ (u"ࠬ࠭䐆")
	l1111_l1_ (u"ࠨࠢࠣࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠦࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡜ࠨ࠮ࠪࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠪ࠱࠮ࡄ࠯ࡤࡦࡨࡤࡹࡱࡺࡁࡶࡦ࡬ࡳ࡙ࡸࡡࡤ࡭ࡌࡲࡩ࡫ࡸࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡵ࠱࠲࠵࠺ࠬ࠲ࠧࠧࠨࠪ࠭ࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡻࠣ࡮ࡤࡲ࡬ࡻࡡࡨࡧࡆࡳࡩ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧ࡞࠮࡞ࠫࠬࡣࠊࠊࠋࠌࡪࡴࡸࠠ࡭ࡣࡱ࡫࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡢࡰࡪ࠭ࠏࠏࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไหำฯ้ฮࠦวๅ็้หุฮษ࠻ࠩ࠯ࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠩࠋࠋࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡲࡴࡺࠠࡪࡰࠣ࡟࠵࠲࠭࠲࡟࠽ࠎࠎࠏࠉࠊࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡢࡢࡵࡨ࡙ࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࠌࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌ࡜࠲ࡠ࠯ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠦࡵࡻࡳࡩࡂࡺࡲࡢࡥ࡮ࠪࡹࡲࡡ࡯ࡩࡀࠫ࠰ࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡡ࡝࠭࡝ࡠࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊ࡫ࡩࠤࠬ࠵ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠱ࠪࠤ࡮ࡴࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠻ࠢࡧࡥࡸ࡮ࡕࡓࡎࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࡧ࡯ࡷࡪࡀࠠࡥࡣࡶ࡬࡚ࡘࡌࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡴ࠱ࠪ࠰ࠬ࠵ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠱ࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡪ࡯ࡷ࡚ࡘࡌࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࠣࡩࡶࡰࡰ࠷ࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࡩ࡮ࡶ࡙ࡗࡒࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫ࠮ࠐࠉࠊࠥ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡚࠰ࡑࡊࡊࡉࡂ࠼ࡘࡖࡎࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠬࡕ࡛ࡓࡉࡂ࡙ࡕࡃࡖࡌࡘࡑࡋࡓ࠭ࡉࡕࡓ࡚ࡖ࠭ࡊࡆࡀࠦࡻࡺࡴࠨ࠮࡫ࡸࡲࡲ࠲࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠤ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠤࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢࠩࠫࠨࠨࡩࡱࡹࡃࡶࡵࡶࠩࡸࡾࡶࡥ࠾ࡶࡵࡥࡨࡱࠦࡵ࡮ࡤࡲ࡬ࡃࠧࠋࠋࡥࡰࡴࡩ࡫ࡴ࠮ࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠮ࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵࠢࡀࠤࡠࡣࠬ࡜࡟࠯ࡿࢂࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡻࡲ࡭ࡡࡨࡲࡨࡵࡤࡦࡦࡢࡪࡲࡺ࡟ࡴࡶࡵࡩࡦࡳ࡟࡮ࡣࡳࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡠࡨࡰࡸࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠪࠌࠌ࡭࡫ࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡯ࡷࡣࡱ࡯ࡳࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡥࡳࡪࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠦࡃ࡛ࠨࠩࡠ࠾ࠏࠏࠉࠊࡨࡰࡸࡤࡲࡩࡴࡶࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋࡩࡱࡹࡥࡩࡵࡣࡪࡷࠥࡃࠠࡧ࡯ࡷࡣࡱ࡯ࡳࡵ࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠯ࠫ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡧ࡯ࡷࡣ࡮ࡺࡡࡨࡵ࠽ࠎࠎࠏࠉࠊ࡫ࡷࡥ࡬࠲ࡳࡪࡼࡨࠤࡂࠦࡩࡵࡧࡰ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠴࠭ࠩࠋࠋࠌࠍࠎ࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࡠ࡯ࡴࡢࡩࡠࠤࡂࠦࡳࡪࡼࡨࠎࠎ࡬࡯ࡳࠢࡥࡰࡴࡩ࡫ࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡣ࡮ࡲࡧࡰࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࡱ࡯࡮ࡦࡵࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠱࠭ࠩࠋࠋࠌࡪࡴࡸࠠ࡭࡫ࡱࡩࠥ࡯࡮ࠡ࡮࡬ࡲࡪࡹ࠺ࠋࠋࠌࠍࠨࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨࠨ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠰ࡱ࡫ࡶࡦ࡮ࡀࡼࡧࡳࡣ࠯ࡎࡒࡋࡓࡕࡔࡊࡅࡈ࠭ࠏࠏࠉࠊࠥࡻࡦࡲࡩ࠮࡭ࡱࡪࠬࡱ࡯࡮ࡦ࠮࡯ࡩࡻ࡫࡬࠾ࡺࡥࡱࡨ࠴ࡌࡐࡉࡑࡓ࡙ࡏࡃࡆࠫࠍࠍࠎࠏ࡬ࡪࡰࡨࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱࡩ࠮ࠐࠉࠊࠋࡧ࡭ࡨࡺࠠ࠾ࠢࡾࢁࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢ࡯࡭ࡳ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠧࠨࠪ࠭ࠏࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡯ࡪࡿࠬࡷࡣ࡯ࡹࡪࠦ࠽ࠡ࡫ࡷࡩࡲ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠽ࠨ࠮࠴࠭ࠏࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛࡬ࡧࡼࡡࠥࡃࠠࡷࡣ࡯ࡹࡪࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡳࡪࡼࡨࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪࠢࡤࡲࡩࠦࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠋࠋࠌࠍࠎࡪࡩࡤࡶ࡞ࠫࡸ࡯ࡺࡦࠩࡠࠤࡂࠦࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࡡࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡࡢࠐࠉࠊࠋࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺࠩࠋࠋࡥࡰࡴࡩ࡫ࡴ࠮ࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳ࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡪࡴࡸ࡭ࡢࡶࡶࠦ࠿ࡢ࡛ࠩ࠰࠭ࡃ࠮ࡢ࡝ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠦ࠿ࡢ࡛ࠩ࠰࠭ࡃ࠮ࡢ࡝ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠪࠌࠌࡪࡴࡸࠠࡣ࡮ࡲࡧࡰࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠧࠨࠪ࠰ࠬࠬࠧࠪࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠽ࠣࠩ࠯ࠫࡂ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࠦࠧ࠭ࠬࠨࠤࠪ࠭ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠽ࡸࡷࡻࡥࠨ࠮ࠪ࠾࡙ࡸࡵࡦࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠺ࡧࡣ࡯ࡷࡪ࠭ࠬࠨ࠼ࡉࡥࡱࡹࡥࠨࠫࠍࠍࠎ࡯ࡦࠡࠩ࡞ࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮࠾ࠥࡨ࡬ࡰࡥ࡮ࠤࡂࠦࠧ࡜ࠩ࠮ࡦࡱࡵࡣ࡬࠭ࠪࡡࠬࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡈ࡚ࡆࡒࠨࠨ࡮࡬ࡷࡹ࠭ࠬࡣ࡮ࡲࡧࡰ࠯ࠊࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡀࠊࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣࠩࠋࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪࡸࡾࡶࡥࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡁࠬ࠲ࠧ࠾ࠤࠪ࠭࠰࠭ࠢࠨࠌࠌࠍࠎ࡯ࡦࠡࠩࡩࡴࡸ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡧࡲࡶࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫ࡫ࡶࡳࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡸ࡫ࡧࡸ࡭࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡽࡩࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡽࡩࡥࡶ࡫ࠫࡢ࠯ࠫࠨࡺࠪ࠯ࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡩࡧ࡬࡫࡭ࡺࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡴࡶࡤࡶࡹ࠭࡝ࠬࠩ࠰ࠫ࠰ࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡩࡳࡪࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡶࡸࡦࡸࡴࠨ࡟࠮ࠫ࠲࠭ࠫࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡥ࡯ࡦࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡣ࡫ࡷࡶࡦࡺࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪࠢࡤࡲࡩࠦࡤࡪࡥࡷ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝࠿࠳࠴࠵࠷࠸࠲࠴࠵࠶࠾ࠥࡪࡥ࡭ࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠋࠋࠌࠍࠎࡩࡩࡱࡪࡨࡶࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ࡟࠱ࡷࡵࡲࡩࡵࠪࠪࠪࠬ࠯ࠊࠊࠋࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢࡦ࡭ࡵ࡮ࡥࡳ࠼ࠍࠍࠎࠏࠉࠊ࡭ࡨࡽ࠱ࡼࡡ࡭ࡷࡨࠤࡂࠦࡩࡵࡧࡰ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡂ࠭ࠬ࠲ࠫࠍࠍࠎࠏࠉࠊࡦ࡬ࡧࡹࡡ࡫ࡦࡻࡠࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡷࡣ࡯ࡹࡪ࠯ࠊࠊࠋࠌࠧ࡮࡬ࠠࠨࡷࡵࡰࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡵࡳ࡮ࠪࡡࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡦ࡬ࡧࡹࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠊࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴࠪࠌࠌࡹࡷࡲ࡟࡭࡫ࡶࡸ࠱ࡹࡴࡳࡧࡤࡱࡸ࠶ࠬࡴࡶࡵࡩࡦࡳࡳ࠲࠮ࡶࡸࡷ࡫ࡡ࡮ࡵ࠵ࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࡡ࡝࠭࡝ࡠࠎࠎ࡯ࡦࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱ࠡࡣࡱࡨࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶࠿ࠐࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶ࠴ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷࠺ࠋࠋࠌࠍࡺࡸ࡬࠲ࠢࡀࠤࡩ࡯ࡣࡵ࠳࡞ࠫࡺࡸ࡬ࠨ࡟࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎࠩࡵࡳ࡮࠴ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡦ࡬ࡧࡹ࠷࡛ࠨࡷࡵࡰࠬࡣࠩࠪ࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍ࡫ࡵࡲࠡࡦ࡬ࡧࡹ࠸ࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴࠽ࠎࠎࠏࠉࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡦ࡬ࡧࡹ࠸࡛ࠨࡷࡵࡰࠬࡣ࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࠌࠧࡺࡸ࡬࠳ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࡛࠭ࡎࡒࡗࡒࡘࡊ࠮ࡤࡪࡥࡷ࠶ࡠ࠭ࡵࡳ࡮ࠪࡡ࠮࠯࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࠌ࡭࡫ࠦࡵࡳ࡮࠴ࡁࡂࡻࡲ࡭࠴ࠣࡥࡳࡪࠠࡶࡴ࡯࠵ࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡻࡲ࡭ࡡ࡯࡭ࡸࡺ࠺ࠋࠋࠌࠍࠎࠏࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠯ࡣࡳࡴࡪࡴࡤࠩࡷࡵࡰ࠶࠯ࠊࠊࠋࠌࠍࠎࡪࡩࡤࡶ࠴࠲ࡺࡶࡤࡢࡶࡨࠬࡩ࡯ࡣࡵ࠴ࠬࠎࠎࠏࠉࠊࠋࡶࡸࡷ࡫ࡡ࡮ࡵ࠳࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵ࠳ࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡸࡺࡲࡦࡣࡰࡷ࠵ࠦ࠽ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱ࠬࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲ࠋࠋࠥࠦࠧ䐇")
	# l11llll1ll11_l1_ json data
	l1l1lll_l1_ = l111lll_l1_[l1111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䐈")][0]+l1111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡱ࡮ࡤࡽࡪࡸࠧ䐉")
	l11lll1ll_l1_ = {l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪ䐊"):id,l1111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ䐋"):{l1111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ䐌"):{l1111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ䐍"):l1111_l1_ (u"ࠨࡁࡏࡆࡕࡓࡎࡊࠢ䐎"),l1111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ䐏"):l1111_l1_ (u"ࠣ࠳࠹࠲࠵࠻ࠢ䐐")}}}
	l11lll1ll_l1_ = str(l11lll1ll_l1_)
	response = l1l11l_l1_(l1lll11ll1l1_l1_,l1111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䐑"),l1l1lll_l1_,l11lll1ll_l1_,l1111_l1_ (u"ࠪࠫ䐒"),l1111_l1_ (u"ࠫࠬ䐓"),l1111_l1_ (u"ࠬ࠭䐔"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ䐕"))
	html = response.content
	#l111ll1l1_l1_(l1111_l1_ (u"ࠧࠨ䐖"),html)
	l11l1ll11111_l1_ = l1lll11ll11_l1_(l1111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䐗"),html)
	# l11llll1ll11_l1_ l1l11lll1l11_l1_ & l1l11l1l11l1_l1_
	l11111l_l1_,l11lll1l_l1_ = [l1111_l1_ (u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭䐘")],[l1111_l1_ (u"ࠪࠫ䐙")]
	try:
		l1l11lll1l11_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭䐚")][l1111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ䐛")][l1111_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭䐜")]
		for l11l1llll1l1_l1_ in l1l11lll1l11_l1_:
			l1l111l_l1_ = l11l1llll1l1_l1_[l1111_l1_ (u"ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠨ䐝")]
			title = l11l1llll1l1_l1_[l1111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䐞")][l1111_l1_ (u"ࠩࡵࡹࡳࡹࠧ䐟")][0][l1111_l1_ (u"ࠪࡸࡪࡾࡴࠨ䐠")]
			l11lll1l_l1_.append(l1l111l_l1_)
			l11111l_l1_.append(title)
	except: pass
	if len(l11111l_l1_)>1:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭䐡"), l11111l_l1_)
		if l1l_l1_==-1: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ䐢"),[],[]
		elif l1l_l1_!=0:
			l1l111l_l1_ = l11lll1l_l1_[l1l_l1_]+l1111_l1_ (u"࠭ࠦࠨ䐣")
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠧࠧࡨࡰࡸࡂࡹࡲࡷ࠴ࠩࠫ䐤"),l1111_l1_ (u"ࠨࠨࡩࡱࡹࡃࡶࡵࡶࠩࠫ䐥"))
			l11l1ll11lll_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠩࠩࠫ䐦"))
	formats,l1l11l11ll11_l1_,l11l1llllll1_l1_,l11l1lllllll_l1_,l11l1lllll1l_l1_ = [],[],[],[],[]
	# l11llll1ll11_l1_ l11ll111l1ll_l1_ streams
	try: l11ll11lllll_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ䐧")][l1111_l1_ (u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭䐨")]
	except: pass
	# l11llll1ll11_l1_ l1l111l1l11l_l1_ stream
	try: l11lllll1l1l_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ䐩")][l1111_l1_ (u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ䐪")]
	except: pass
	# l11llll1ll11_l1_ l1ll1l1l1l_l1_ l1111l1l_l1_ streams
	try: formats = l11l1ll11111_l1_[l1111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ䐫")][l1111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ䐬")]
	except: pass
	# l11llll1ll11_l1_ l1ll1l1l1l_l1_ l1l11l1ll11l_l1_ streams
	try: l1l11l11ll11_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ䐭")][l1111_l1_ (u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ䐮")]
	except: pass
	l1l1111ll1ll_l1_ = formats+l1l11l11ll11_l1_
	for dict in l1l1111ll1ll_l1_:
		if l1111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䐯") in list(dict.keys()): dict[l1111_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䐰")] = str(dict[l1111_l1_ (u"࠭ࡩࡵࡣࡪࠫ䐱")])
		if l1111_l1_ (u"ࠧࡧࡲࡶࠫ䐲") in list(dict.keys()): dict[l1111_l1_ (u"ࠨࡨࡳࡷࠬ䐳")] = str(dict[l1111_l1_ (u"ࠩࡩࡴࡸ࠭䐴")])
		if l1111_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ䐵") in list(dict.keys()): dict[l1111_l1_ (u"ࠫࡹࡿࡰࡦࠩ䐶")] = dict[l1111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ䐷")]		#.replace(l1111_l1_ (u"࠭࠽ࠨ䐸"),l1111_l1_ (u"ࠧ࠾ࠩ䐹"))+l1111_l1_ (u"ࠨࠤࠪ䐺")
		if l1111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ䐻") in list(dict.keys()): dict[l1111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ䐼")] = str(dict[l1111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭䐽")])
		if l1111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䐾") in list(dict.keys()): dict[l1111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ䐿")] = str(dict[l1111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ䑀")])
		if l1111_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ䑁") in list(dict.keys()): dict[l1111_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ䑂")] = str(dict[l1111_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ䑃")])+l1111_l1_ (u"ࠫࡽ࠭䑄")+str(dict[l1111_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ䑅")])
		if l1111_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ䑆") in list(dict.keys()): dict[l1111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ䑇")] = dict[l1111_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ䑈")][l1111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ䑉")]+l1111_l1_ (u"ࠪ࠱ࠬ䑊")+dict[l1111_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ䑋")][l1111_l1_ (u"ࠬ࡫࡮ࡥࠩ䑌")]
		if l1111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ䑍") in list(dict.keys()): dict[l1111_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭䑎")] = dict[l1111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ䑏")][l1111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ䑐")]+l1111_l1_ (u"ࠪ࠱ࠬ䑑")+dict[l1111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ䑒")][l1111_l1_ (u"ࠬ࡫࡮ࡥࠩ䑓")]
		if l1111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ䑔") in list(dict.keys()): dict[l1111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䑕")] = dict[l1111_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ䑖")]
		if l1111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䑗") in list(dict.keys()) and int(dict[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䑘")])>111222333: del dict[l1111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䑙")]
		if l1111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ䑚") in list(dict.keys()):
			cipher = dict[l1111_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ䑛")].split(l1111_l1_ (u"ࠧࠧࠩ䑜"))
			for item in cipher:
				key,value = item.split(l1111_l1_ (u"ࠨ࠿ࠪ䑝"),1)
				dict[key] = UNQUOTE(value)
		if l1111_l1_ (u"ࠩࡸࡶࡱ࠭䑞") in list(dict.keys()): dict[l1111_l1_ (u"ࠪࡹࡷࡲࠧ䑟")] = UNQUOTE(dict[l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䑠")])
		#if l1111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࡂ࠭䑡") in dict[l1111_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ䑢")]: dict[l1111_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ䑣")] = dict[l1111_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ䑤")].split(l1111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴ࠿࡟ࠦࠬ䑥"))[1].strip(l1111_l1_ (u"ࠪࡠࠧ࠭䑦"))
		#LOG_THIS(l1111_l1_ (u"ࠫࠬ䑧"),dict[l1111_l1_ (u"ࠬࡺࡹࡱࡧࠪ䑨")]+l1111_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦࠧ䑩")+dict[l1111_l1_ (u"ࠧࡵࡻࡳࡩࠬ䑪")])
		l11l1llllll1_l1_.append(dict)
	l11ll1111l1l_l1_ = l1111_l1_ (u"ࠨࠩ䑫")
	if l1111_l1_ (u"ࠩࡶࡴࡂࡹࡩࡨࠩ䑬") in html:
		#l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡽࡹࡹ࠯࡫ࡵࡥ࡭ࡳ࠵ࡰ࡭ࡣࡼࡩࡷࡥ࠮ࠫࡁࠬࠦࠬ䑭"),html,re.DOTALL)
		# /s/l1ll1llll111_l1_/6dde7fb4/l11llll1l111_l1_.l1l11l1111ll_l1_/l1l111l111l1_l1_/base.l1l1111l1111_l1_
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ䑮"),html,re.DOTALL)
		if l111l1l_l1_:
			l11lll1l11l1_l1_ = l111lll_l1_[l1111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䑯")][0]+l111l1l_l1_[0]
			l11ll1111l1l_l1_ = l111l11_l1_(l1ll1llll_l1_,l11lll1l11l1_l1_,l1111_l1_ (u"࠭ࠧ䑰"),l1111_l1_ (u"ࠧࠨ䑱"),l1111_l1_ (u"ࠨࠩ䑲"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ䑳"))
			import youtube_signature.cipher
			import youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1l1111lllll_l1_ = cipher._load_javascript(l11ll1111l1l_l1_)
			l11lll11l1ll_l1_ = str(l1l1111lllll_l1_)
	for dict in l11l1llllll1_l1_:
		url = dict[l1111_l1_ (u"ࠪࡹࡷࡲࠧ䑴")]
		if l1111_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨ䑵") in url or url.count(l1111_l1_ (u"ࠬࡹࡩࡨ࠿ࠪ䑶"))>1: l11l1lllllll_l1_.append(dict)
		elif not l11ll1111l1l_l1_ and l1111_l1_ (u"࠭ࡳࠨ䑷") in list(dict.keys()) and l1111_l1_ (u"ࠧࡴࡲࠪ䑸") in list(dict.keys()):
			l1l1111lllll_l1_ = l1lll11ll11_l1_(l1111_l1_ (u"ࠨࡵࡷࡶࠬ䑹"),l11lll11l1ll_l1_)
			json_script_engine = youtube_signature.json_script_engine.JsonScriptEngine(l1l1111lllll_l1_)
			l11llll111ll_l1_ = json_script_engine.execute(dict[l1111_l1_ (u"ࠩࡶࠫ䑺")])
			if l11llll111ll_l1_!=dict[l1111_l1_ (u"ࠪࡷࠬ䑻")]:
				dict[l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䑼")] = url+l1111_l1_ (u"ࠬࠬࠧ䑽")+dict[l1111_l1_ (u"࠭ࡳࡱࠩ䑾")]+l1111_l1_ (u"ࠧ࠾ࠩ䑿")+l11llll111ll_l1_
				l11l1lllllll_l1_.append(dict)
	for dict in l11l1lllllll_l1_:
		l1ll_l1_,l11l1l1lll1l_l1_,l1l111ll1111_l1_,l11ll1111111_l1_,codecs,l11l11lllll_l1_ = l1111_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ䒀"),l1111_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ䒁"),l1111_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ䒂"),l1111_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ䒃"),l1111_l1_ (u"ࠬ࠭䒄"),l1111_l1_ (u"࠭࠰ࠨ䒅")
		try:
			l11ll111111l_l1_ = dict[l1111_l1_ (u"ࠧࡵࡻࡳࡩࠬ䒆")]
			l11ll111111l_l1_ = l11ll111111l_l1_.replace(l1111_l1_ (u"ࠨ࠭ࠪ䒇"),l1111_l1_ (u"ࠩࠪ䒈"))
			items = re.findall(l1111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ䒉"),l11ll111111l_l1_,re.DOTALL)
			l11ll1111111_l1_,l1ll_l1_,codecs = items[0]
			l1l111l1l1ll_l1_ = codecs.split(l1111_l1_ (u"ࠫ࠱࠭䒊"))
			l11l1l1lll1l_l1_ = l1111_l1_ (u"ࠬ࠭䒋")
			for item in l1l111l1l1ll_l1_: l11l1l1lll1l_l1_ += item.split(l1111_l1_ (u"࠭࠮ࠨ䒌"))[0]+l1111_l1_ (u"ࠧ࠭ࠩ䒍")
			l11l1l1lll1l_l1_ = l11l1l1lll1l_l1_.strip(l1111_l1_ (u"ࠨ࠮ࠪ䒎"))
			if l1111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䒏") in list(dict.keys()): l11l11lllll_l1_ = str(float(dict[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䒐")]*10)//1024/10)+l1111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ䒑")
			else: l11l11lllll_l1_ = l1111_l1_ (u"ࠬ࠭䒒")
			if l11ll1111111_l1_==l1111_l1_ (u"࠭ࡴࡦࡺࡷࠫ䒓"): continue
			elif l1111_l1_ (u"ࠧ࠭ࠩ䒔") in l11ll111111l_l1_:
				l11ll1111111_l1_ = l1111_l1_ (u"ࠨࡃ࠮࡚ࠬ䒕")
				l1l111ll1111_l1_ = l1ll_l1_+l1111_l1_ (u"ࠩࠣࠤࠬ䒖")+l11l11lllll_l1_+dict[l1111_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ䒗")].split(l1111_l1_ (u"ࠫࡽ࠭䒘"))[1]
			elif l11ll1111111_l1_==l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒙"):
				l11ll1111111_l1_ = l1111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ䒚")
				l1l111ll1111_l1_ = l11l11lllll_l1_+dict[l1111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ䒛")].split(l1111_l1_ (u"ࠨࡺࠪ䒜"))[1]+l1111_l1_ (u"ࠩࠣࠤࠬ䒝")+dict[l1111_l1_ (u"ࠪࡪࡵࡹࠧ䒞")]+l1111_l1_ (u"ࠫ࡫ࡶࡳࠨ䒟")+l1111_l1_ (u"ࠬࠦࠠࠨ䒠")+l1ll_l1_
			elif l11ll1111111_l1_==l1111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ䒡"):
				l11ll1111111_l1_ = l1111_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭䒢")
				l1l111ll1111_l1_ = l11l11lllll_l1_+str(int(dict[l1111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬ䒣")])/1000)+l1111_l1_ (u"ࠩ࡮࡬ࡿࠦࠠࠨ䒤")+dict[l1111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ䒥")]+l1111_l1_ (u"ࠫࡨ࡮ࠧ䒦")+l1111_l1_ (u"ࠬࠦࠠࠨ䒧")+l1ll_l1_
		except:
			l1111l11l1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l11l1l_l1_)
		if l1111_l1_ (u"࠭ࡤࡶࡴࡀࠫ䒨") in dict[l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䒩")]: duration = round(0.5+float(dict[l1111_l1_ (u"ࠨࡷࡵࡰࠬ䒪")].split(l1111_l1_ (u"ࠩࡧࡹࡷࡃࠧ䒫"),1)[1].split(l1111_l1_ (u"ࠪࠪࠬ䒬"),1)[0]))
		elif l1111_l1_ (u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧ䒭") in list(dict.keys()): duration = round(0.5+float(dict[l1111_l1_ (u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ䒮")])/1000)
		else: duration = l1111_l1_ (u"࠭࠰ࠨ䒯")
		if l1111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䒰") not in list(dict.keys()): l11l11lllll_l1_ = dict[l1111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭䒱")].split(l1111_l1_ (u"ࠩࡻࠫ䒲"))[1]
		else: l11l11lllll_l1_ = dict[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䒳")]
		if l1111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䒴") not in list(dict.keys()): dict[l1111_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ䒵")] = l1111_l1_ (u"࠭࠰࠮࠲ࠪ䒶")
		dict[l1111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䒷")] = l11ll1111111_l1_+l1111_l1_ (u"ࠨ࠼ࠣࠤࠬ䒸")+l1l111ll1111_l1_+l1111_l1_ (u"ࠩࠣࠤ࠭࠭䒹")+l11l1l1lll1l_l1_+l1111_l1_ (u"ࠪ࠰ࠬ䒺")+dict[l1111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䒻")]+l1111_l1_ (u"ࠬ࠯ࠧ䒼")
		dict[l1111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䒽")] = l1l111ll1111_l1_.split(l1111_l1_ (u"ࠧࠡࠢࠪ䒾"))[0].split(l1111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭䒿"))[0]
		dict[l1111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䓀")] = l11ll1111111_l1_
		dict[l1111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䓁")] = l1ll_l1_
		dict[l1111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䓂")] = codecs
		dict[l1111_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ䓃")] = duration
		dict[l1111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䓄")] = l11l11lllll_l1_
		l11l1lllll1l_l1_.append(dict)
	l1l1111l1ll1_l1_,l11lll1l1l1l_l1_,l1l11l1lll11_l1_,l1l11ll11l11_l1_,l11l1l11llll_l1_ = [],[],[],[],[]
	l11lll1l111l_l1_,l11ll11l1l1l_l1_,l11ll11ll1ll_l1_,l1l111l1l111_l1_,l1l11l1l11ll_l1_ = [],[],[],[],[]
	if l11ll11lllll_l1_:
		dict = {}
		dict[l1111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭䓅")] = l1111_l1_ (u"ࠨࡃ࠮࡚ࠬ䓆")
		dict[l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䓇")] = l1111_l1_ (u"ࠪࡱࡵࡪࠧ䓈")
		dict[l1111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䓉")] = dict[l1111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䓊")]+l1111_l1_ (u"࠭࠺ࠡࠢࠪ䓋")+dict[l1111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䓌")]+l1111_l1_ (u"ࠨࠢࠣࠫ䓍")+l1111_l1_ (u"ࠩฯ์ิฯࠠัๅํอࠬ䓎")
		dict[l1111_l1_ (u"ࠪࡹࡷࡲࠧ䓏")] = l11ll11lllll_l1_
		dict[l1111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ䓐")] = l1111_l1_ (u"ࠬ࠶ࠧ䓑") # for l1l1l11111_l1_ l11ll11lllll_l1_ any l111l11l111_l1_ will l1l11llll11l_l1_ l1ll1llllll_l1_ sort l1l1lllll11_l1_
		dict[l1111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䓒")] = l1111_l1_ (u"ࠧ࠺࠺࠺࠺࠺࠺࠳࠳࠳࠳ࠫ䓓") # 20
		l11l1lllll1l_l1_.append(dict)
	if l11lllll1l1l_l1_:
		l1l111lll11l_l1_,l11ll1lll111_l1_ = l1l1ll111l_l1_(l11lllll1l1l_l1_)
		l11lllll111l_l1_ = list(zip(l1l111lll11l_l1_,l11ll1lll111_l1_))
		for title,l1l111l_l1_ in l11lllll111l_l1_:
			dict = {}
			dict[l1111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䓔")] = l1111_l1_ (u"ࠩࡄ࠯࡛࠭䓕")
			dict[l1111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䓖")] = l1111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ䓗")
			dict[l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ䓘")] = l1l111l_l1_
			#if l1111_l1_ (u"࠭ࡂࡘ࠼ࠣࠫ䓙") in title: dict[l1111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䓚")] = title.split(l1111_l1_ (u"ࠨࠢࠣࠫ䓛"))[1].split(l1111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ䓜"))[0]
			#if l1111_l1_ (u"ࠪࡖࡪࡹ࠺ࠡࠩ䓝") in title: dict[l1111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ䓞")] = title.split(l1111_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ䓟"))[1]
			# title = l1111_l1_ (u"ࠨ࠴࠳࠸࠺࡯ࡧࡶࡳࠡࠢ࠺࠶࠵ࠦࠠ࠯࡯࠶ࡹ࠽ࠨ䓠")
			if l1111_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ䓡") in title: dict[l1111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䓢")] = title.split(l1111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ䓣"))[0].rsplit(l1111_l1_ (u"ࠪࠤࠥ࠭䓤"))[-1]
			else: dict[l1111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䓥")] = l1111_l1_ (u"ࠬ࠷࠰ࠨ䓦")
			l11l1111_l1_ = title.rsplit(l1111_l1_ (u"࠭ࠠࠡࠩ䓧"))[-3]
			if l11l1111_l1_.isdigit(): dict[l1111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ䓨")] = l11l1111_l1_
			else: dict[l1111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䓩")] = l1111_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ䓪")
			#dict[l1111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ䓫")] = title
			if title==l1111_l1_ (u"ࠫ࠲࠷ࠧ䓬"): dict[l1111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䓭")] = dict[l1111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ䓮")]+l1111_l1_ (u"ࠧ࠻ࠢࠣࠫ䓯")+dict[l1111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ䓰")]+l1111_l1_ (u"ࠩࠣࠤࠬ䓱")+l1111_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭䓲")
			else: dict[l1111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䓳")] = dict[l1111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䓴")]+l1111_l1_ (u"࠭࠺ࠡࠢࠪ䓵")+dict[l1111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䓶")]+l1111_l1_ (u"ࠨࠢࠣࠫ䓷")+dict[l1111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䓸")]+l1111_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ䓹")+dict[l1111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ䓺")]
			l11l1lllll1l_l1_.append(dict)
	l11l1lllll1l_l1_ = sorted(l11l1lllll1l_l1_,reverse=True,key=lambda key: float(key[l1111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䓻")]))
	if not l11l1lllll1l_l1_:
		l1ll1ll1lll_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䓼"),html,re.DOTALL)
		l1ll1lll111_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻࡞ࡾࠦࡷࡻ࡮ࡴࠤ࠽ࡠࡠࡢࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䓽"),html,re.DOTALL)
		l1l1111l111l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䓾"),html,re.DOTALL)
		l1l1111l11l1_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䓿"),html,re.DOTALL)
		try: l1l1111l11ll_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ䔀")][l1111_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ䔁")][l1111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䔂")][l1111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䔃")][l1111_l1_ (u"ࠧࡳࡷࡱࡷࠬ䔄")][0][l1111_l1_ (u"ࠨࡶࡨࡼࡹ࠭䔅")]
		except:
			try: l1l1111l11ll_l1_ = l11l1ll11111_l1_[l1111_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭䔆")][l1111_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ䔇")][l1111_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ䔈")][l1111_l1_ (u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭䔉")][0][l1111_l1_ (u"࠭ࡲࡶࡰࡶࠫ䔊")][0][l1111_l1_ (u"ࠧࡵࡧࡻࡸࠬ䔋")]
			except: l1l1111l11ll_l1_ = l1111_l1_ (u"ࠨࠩ䔌")
		if l1ll1ll1lll_l1_ or l1ll1lll111_l1_ or l1l1111l111l_l1_ or l1l1111l11l1_l1_ or l1l1111l11ll_l1_:
			if l1ll1ll1lll_l1_: message = l1ll1ll1lll_l1_[0]
			elif l1ll1lll111_l1_: message = l1ll1lll111_l1_[0]
			elif l1l1111l111l_l1_: message = l1l1111l111l_l1_[0]
			elif l1l1111l11l1_l1_: message = l1l1111l11l1_l1_[0]
			elif l1l1111l11ll_l1_: message = l1l1111l11ll_l1_
			l1l11ll11lll_l1_ = message.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬ䔍"),l1111_l1_ (u"ࠪࠫ䔎")).strip(l1111_l1_ (u"ࠫࠥ࠭䔏"))
			l1l11ll11l1l_l1_ = l1111_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠪ䔐")
			l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䔑"),l1111_l1_ (u"ࠧࠨ䔒"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ䔓"),l1l11ll11lll_l1_+l1111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䔔")+l1l11ll11l1l_l1_)
			return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ䔕")+l1l11ll11lll_l1_,[],[]
		else: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ䔖"),[],[]
	l1l11ll1l11l_l1_,l11l1lll1l11_l1_,l1l11ll1l1ll_l1_ = [],[],[]
	for dict in l11l1lllll1l_l1_:
		if dict[l1111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䔗")]==l1111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ䔘"):
			l1l1111l1ll1_l1_.append(dict[l1111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䔙")])
			l11lll1l111l_l1_.append(dict)
		elif dict[l1111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䔚")]==l1111_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ䔛"):
			l11lll1l1l1l_l1_.append(dict[l1111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䔜")])
			l11ll11l1l1l_l1_.append(dict)
		elif dict[l1111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䔝")]==l1111_l1_ (u"ࠬࡳࡰࡥࠩ䔞"):
			title = dict[l1111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䔟")].replace(l1111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ䔠"),l1111_l1_ (u"ࠨࠩ䔡"))
			if l1111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䔢") not in list(dict.keys()): l11l11lllll_l1_ = l1111_l1_ (u"ࠪ࠴ࠬ䔣")
			else: l11l11lllll_l1_ = dict[l1111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䔤")]
			l1l11ll1l11l_l1_.append([dict,{},title,l11l11lllll_l1_])
		else:
			title = dict[l1111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䔥")].replace(l1111_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭䔦"),l1111_l1_ (u"ࠧࠨ䔧"))
			if l1111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䔨") not in list(dict.keys()): l11l11lllll_l1_ = l1111_l1_ (u"ࠩ࠳ࠫ䔩")
			else: l11l11lllll_l1_ = dict[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䔪")]
			l1l11ll1l11l_l1_.append([dict,{},title,l11l11lllll_l1_])
			l1l11l1lll11_l1_.append(title)
			l11ll11ll1ll_l1_.append(dict)
		l11lllllllll_l1_ = True
		if l1111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䔫") in list(dict.keys()):
			if l1111_l1_ (u"ࠬࡧࡶ࠱ࠩ䔬") in dict[l1111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䔭")]: l11lllllllll_l1_ = False
			elif kodi_version<18:
				if l1111_l1_ (u"ࠧࡢࡸࡦࠫ䔮") not in dict[l1111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䔯")] and l1111_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ䔰") not in dict[l1111_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䔱")]: l11lllllllll_l1_ = False
		if dict[l1111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䔲")]==l1111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ䔳") and dict[l1111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䔴")]!=l1111_l1_ (u"ࠧ࠱࠯࠳ࠫ䔵") and l11lllllllll_l1_==True:
			l11l1l11llll_l1_.append(dict[l1111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䔶")])
			l1l11l1l11ll_l1_.append(dict)
		elif dict[l1111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䔷")]==l1111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ䔸") and dict[l1111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䔹")]!=l1111_l1_ (u"ࠬ࠶࠭࠱ࠩ䔺") and l11lllllllll_l1_==True:
			l1l11ll11l11_l1_.append(dict[l1111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䔻")])
			l1l111l1l111_l1_.append(dict)
		#LOG_THIS(l1111_l1_ (u"ࠧࠨ䔼"),l1111_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ䔽")+dict[l1111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ䔾")])
	for l11llll11l1l_l1_ in l1l111l1l111_l1_:
		l1l11lll1111_l1_ = l11llll11l1l_l1_[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䔿")]
		for l1l11111llll_l1_ in l1l11l1l11ll_l1_:
			l1l11lllll11_l1_ = l1l11111llll_l1_[l1111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䕀")]
			l11l11lllll_l1_ = l1l11lllll11_l1_+l1l11lll1111_l1_
			title = l1l11111llll_l1_[l1111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䕁")].replace(l1111_l1_ (u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ䕂"),l1111_l1_ (u"ࠧ࡮ࡲࡧࠤࠥ࠭䕃"))
			title = title.replace(l1l11111llll_l1_[l1111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ䕄")]+l1111_l1_ (u"ࠩࠣࠤࠬ䕅"),l1111_l1_ (u"ࠪࠫ䕆"))
			title = title.replace(str((float(l1l11lllll11_l1_*10)//1024/10))+l1111_l1_ (u"ࠫࡰࡨࡰࡴࠩ䕇"),str((float(l11l11lllll_l1_*10)//1024/10))+l1111_l1_ (u"ࠬࡱࡢࡱࡵࠪ䕈"))
			title = title+l1111_l1_ (u"࠭ࠨࠨ䕉")+l11llll11l1l_l1_[l1111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䕊")].split(l1111_l1_ (u"ࠨࠪࠪ䕋"),1)[1]
			l1l11ll1l11l_l1_.append([l1l11111llll_l1_,l11llll11l1l_l1_,title,l11l11lllll_l1_])
	l1l11ll1l11l_l1_ = sorted(l1l11ll1l11l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l11111llll_l1_,l11llll11l1l_l1_,title,l11l11lllll_l1_ in l1l11ll1l11l_l1_:
		l1l1111lll1l_l1_ = l1l11111llll_l1_[l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䕌")]
		if l1111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䕍") in list(l11llll11l1l_l1_.keys()):
			l1l1111lll1l_l1_ = l1111_l1_ (u"ࠫࡲࡶࡤࠨ䕎")
			#l1l1111lll1l_l1_ = l1l1111lll1l_l1_+l11llll11l1l_l1_[l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䕏")]
		if l1l1111lll1l_l1_ not in l1l11ll1l1ll_l1_:
			l1l11ll1l1ll_l1_.append(l1l1111lll1l_l1_)
			l11l1lll1l11_l1_.append([l1l11111llll_l1_,l11llll11l1l_l1_,title,l11l11lllll_l1_])
			#LOG_THIS(l1111_l1_ (u"࠭ࠧ䕐"),str(l11l11lllll_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࠫ䕑")+title)
	#l11l1lll1l11_l1_ = sorted(l11l1lll1l11_l1_, reverse=True, key=lambda key: int(key[3]))
	l11l1ll1111l_l1_,l1l111llll11_l1_,shift = [],[],0
	l1111_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࡳࡩ࡫ࡩࡸࠥ࠱࠽ࠡ࠳ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ࠰ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠶ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ䕒")
	l11lll11llll_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䕓"),html,re.DOTALL)
	l11ll111llll_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡦࡻࡴࡩࡱࡵࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䕔"),html,re.DOTALL)
	if l11ll111llll_l1_:
		owner = l11ll111llll_l1_[0]
		shift += 1
		title = l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䕕")+owner+l1111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䕖")
		l1l111l_l1_ = l111lll_l1_[l1111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䕗")][0]+l1111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ䕘")+l11lll11llll_l1_[0]
		l11l1ll1111l_l1_.append(title)
		l1l111llll11_l1_.append(l1l111l_l1_)
	#if l11ll11lllll_l1_:
	#	shift += 1
	#	l11l1ll1111l_l1_.append(l1111_l1_ (u"ࠨ࡯ࡳࡨࠥา่ะหࠣิ่๐ษࠨ䕙")) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠩࡧࡥࡸ࡮ࠧ䕚"))
	for l1l11111llll_l1_,l11llll11l1l_l1_,title,l11l11lllll_l1_ in l11l1lll1l11_l1_:
		l11l1ll1111l_l1_.append(title) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ䕛"))
	if l1l11l1lll11_l1_: l11l1ll1111l_l1_.append(l1111_l1_ (u"ฺࠫ๎ัสู๋ࠢํะࠠๆฯา์ิฯࠠศๆฯ์ิฯࠧ䕜")) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ䕝"))
	if l1l11ll1l11l_l1_: l11l1ll1111l_l1_.append(l1111_l1_ (u"࠭ี้ำฬࠤํ฻่หࠢฯ้๏฿ࠠศๆ่ฮํ็ัࠨ䕞")) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠧࡢ࡮࡯ࠫ䕟"))
	if l11l1l11llll_l1_: l11l1ll1111l_l1_.append(l1111_l1_ (u"ࠨ࡯ࡳࡨࠥอๆหࠢอาฯอัࠡฮ๋ำฮࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭䕠")) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠩࡰࡴࡩ࠭䕡"))
	if l1l1111l1ll1_l1_: l11l1ll1111l_l1_.append(l1111_l1_ (u"ูࠪํืษࠡใๅ฻ࠥฮฯู้่ࠣํะࠧ䕢")) ; l1l111llll11_l1_.append(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䕣"))
	if l11lll1l1l1l_l1_: l11l1ll1111l_l1_.append(l1111_l1_ (u"ࠬ฻่หࠢไๆ฼ࠦศะ๊้ࠤฺ๎ัสࠩ䕤")) ; l1l111llll11_l1_.append(l1111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ䕥"))
	l1l11ll1111l_l1_ = False
	while True:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅ็ษึฬ࠿࠭䕦"), l11l1ll1111l_l1_)
		if l1l_l1_==-1: return l1111_l1_ (u"ࠨࠩ䕧"),[],[]
		if l1l_l1_==0:
			l1l111l_l1_ = l1l111llll11_l1_[l1l_l1_]
			owner = QUOTE(l1111_l1_ (u"ࠩ࠯ࠫ䕨"))+l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡟ࡕࡕࠢࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ䕩")+owner+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䕪")
			new_path = sys.argv[0]+l1111_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠹ࠬ࡮ࡢ࡯ࡨࡁࠬ䕫")+owner+l1111_l1_ (u"࠭ࠦࡶࡴ࡯ࡁࠬ䕬")+l1l111l_l1_
			xbmc.executebuiltin(l1111_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ䕭")+new_path+l1111_l1_ (u"ࠣࠫࠥ䕮"))
			return l1111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䕯"),[],[]
		choice = l1l111llll11_l1_[l1l_l1_]
		l1l1111ll111_l1_ = l11l1ll1111l_l1_[l1l_l1_]
		if choice==l1111_l1_ (u"ࠪࡨࡦࡹࡨࠨ䕰"):
			l11lll1ll11l_l1_ = l11ll11lllll_l1_
			break
		elif choice in [l1111_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ䕱"),l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䕲"),l1111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ䕳")]:
			if choice==l1111_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭䕴"): l11111l_l1_,l11llllll1ll_l1_ = l1l11l1lll11_l1_,l11ll11ll1ll_l1_
			elif choice==l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䕵"): l11111l_l1_,l11llllll1ll_l1_ = l1l1111l1ll1_l1_,l11lll1l111l_l1_
			elif choice==l1111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ䕶"): l11111l_l1_,l11llllll1ll_l1_ = l11lll1l1l1l_l1_,l11ll11l1l1l_l1_
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ䕷"), l11111l_l1_)
			if l1l_l1_!=-1:
				l11lll1ll11l_l1_ = l11llllll1ll_l1_[l1l_l1_][l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䕸")]
				l1l1111ll111_l1_ = l11111l_l1_[l1l_l1_]
				break
		elif choice==l1111_l1_ (u"ࠬࡳࡰࡥࠩ䕹"):
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ัส࠼ࠪ䕺"), l11l1l11llll_l1_)
			if l1l_l1_!=-1:
				l1l1111ll111_l1_ = l11l1l11llll_l1_[l1l_l1_]
				l11l1ll11l1l_l1_ = l1l11l1l11ll_l1_[l1l_l1_]
				l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่ห࠼ࠪ䕻"), l1l11ll11l11_l1_)
				if l1l_l1_!=-1:
					l1l1111ll111_l1_ += l1111_l1_ (u"ࠨࠢ࠮ࠤࠬ䕼")+l1l11ll11l11_l1_[l1l_l1_]
					l11llllll11l_l1_ = l1l111l1l111_l1_[l1l_l1_]
					l1l11ll1111l_l1_ = True
					break
		elif choice==l1111_l1_ (u"ࠩࡤࡰࡱ࠭䕽"):
			l11ll1l1l11l_l1_,l11l1l11l1l1_l1_,l11l1l1l1111_l1_,l1l11l1lll1l_l1_ = list(zip(*l1l11ll1l11l_l1_))
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ䕾"), l11l1l1l1111_l1_)
			if l1l_l1_!=-1:
				l1l1111ll111_l1_ = l11l1l1l1111_l1_[l1l_l1_]
				l11l1ll11l1l_l1_ = l11ll1l1l11l_l1_[l1l_l1_]
				if l1111_l1_ (u"ࠫࡲࡶࡤࠨ䕿") in l11l1l1l1111_l1_[l1l_l1_] and l11l1ll11l1l_l1_[l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ䖀")]!=l11ll11lllll_l1_:
					l11llllll11l_l1_ = l11l1l11l1l1_l1_[l1l_l1_]
					l1l11ll1111l_l1_ = True
				else: l11lll1ll11l_l1_ = l11l1ll11l1l_l1_[l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ䖁")]
				break
		elif choice==l1111_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ䖂"):
			#shift += 1
			l11ll1l1l11l_l1_,l11l1l11l1l1_l1_,l11l1l1l1111_l1_,l1l11l1lll1l_l1_ = list(zip(*l11l1lll1l11_l1_))
			l11l1ll11l1l_l1_ = l11ll1l1l11l_l1_[l1l_l1_-shift]
			if l1111_l1_ (u"ࠨ࡯ࡳࡨࠬ䖃") in l11l1l1l1111_l1_[l1l_l1_-shift] and l11l1ll11l1l_l1_[l1111_l1_ (u"ࠩࡸࡶࡱ࠭䖄")]!=l11ll11lllll_l1_:
				l11llllll11l_l1_ = l11l1l11l1l1_l1_[l1l_l1_-shift]
				l1l11ll1111l_l1_ = True
			else: l11lll1ll11l_l1_ = l11l1ll11l1l_l1_[l1111_l1_ (u"ࠪࡹࡷࡲࠧ䖅")]
			l1l1111ll111_l1_ = l11l1l1l1111_l1_[l1l_l1_-shift]
			break
	if not l1l11ll1111l_l1_: l11ll1llll11_l1_ = l11lll1ll11l_l1_
	else: l11ll1llll11_l1_ = l1111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠬ䖆")+l11l1ll11l1l_l1_[l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ䖇")]+l1111_l1_ (u"࠭ࠠࠬࠢࡄࡹࡩ࡯࡯࠻ࠢࠪ䖈")+l11llllll11l_l1_[l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䖉")]
	if l1l11ll1111l_l1_:
		#LOG_THIS(l1111_l1_ (u"ࠨࠩ䖊"),l1111_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭䖋")+str(l11l1ll11l1l_l1_))
		#LOG_THIS(l1111_l1_ (u"ࠪࠫ䖌"),l1111_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮࠯ࠥࠦࠠࠨ䖍")+str(l11llllll11l_l1_))
		#if l1l11l11llll_l1_>l11lll11ll11_l1_: duration = str(l1l11l11llll_l1_)
		#else: duration = str(l11lll11ll11_l1_)
		#duration = str(l1l11l11llll_l1_) if l1l11l11llll_l1_>l11lll11ll11_l1_ else str(l11lll11ll11_l1_)
		l1l11l11llll_l1_ = int(l11l1ll11l1l_l1_[l1111_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ䖎")])
		l11lll11ll11_l1_ = int(l11llllll11l_l1_[l1111_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ䖏")])
		duration = str(max(l1l11l11llll_l1_,l11lll11ll11_l1_))
		l11ll11l11l1_l1_ = l11l1ll11l1l_l1_[l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ䖐")].replace(l1111_l1_ (u"ࠨࠨࠪ䖑"),l1111_l1_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ䖒"))		# +l1111_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠰࠱࠲࠳࠴࠵࠶ࠧ䖓")
		l11lll1l1ll1_l1_ = l11llllll11l_l1_[l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ䖔")].replace(l1111_l1_ (u"ࠬࠬࠧ䖕"),l1111_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ䖖"))		# +l1111_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ䖗")
		l1l11l1ll11l_l1_ = l1111_l1_ (u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ䖘")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪ䖙")+duration+l1111_l1_ (u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩ䖚")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ䖛")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩ䖜")+l11l1ll11l1l_l1_[l1111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䖝")]+l1111_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ䖞")		# l11lll1lllll_l1_=l1111_l1_ (u"ࠣ࠳ࠥ䖟") l1l11l1l1ll1_l1_=l1111_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ䖠") default=l1111_l1_ (u"ࠥࡸࡷࡻࡥࠣ䖡")>\n
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ䖢")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ䖣")+l11l1ll11l1l_l1_[l1111_l1_ (u"࠭ࡩࡵࡣࡪࠫ䖤")]+l1111_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ䖥")+l11l1ll11l1l_l1_[l1111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䖦")]+l1111_l1_ (u"ࠩࠥࠤࡸࡺࡡࡳࡶ࡚࡭ࡹ࡮ࡓࡂࡒࡀࠦ࠶ࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦࠬ䖧")+str(l11l1ll11l1l_l1_[l1111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䖨")])+l1111_l1_ (u"ࠫࠧࠦࡷࡪࡦࡷ࡬ࡂࠨࠧ䖩")+str(l11l1ll11l1l_l1_[l1111_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ䖪")])+l1111_l1_ (u"࠭ࠢࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠪ䖫")+str(l11l1ll11l1l_l1_[l1111_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ䖬")])+l1111_l1_ (u"ࠨࠤࠣࡪࡷࡧ࡭ࡦࡔࡤࡸࡪࡃࠢࠨ䖭")+l11l1ll11l1l_l1_[l1111_l1_ (u"ࠩࡩࡴࡸ࠭䖮")]+l1111_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ䖯")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ䖰")+l11ll11l11l1_l1_+l1111_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ䖱")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ䖲")+l11l1ll11l1l_l1_[l1111_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭䖳")]+l1111_l1_ (u"ࠨࠤࡁࡠࡳ࠭䖴")	# l1l11lll1ll1_l1_=l1111_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ䖵")>\n
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭䖶")+l11l1ll11l1l_l1_[l1111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䖷")]+l1111_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ䖸")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ䖹")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭䖺")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭䖻")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠲ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡡࡶࡦ࡬ࡳ࠴࠭䖼")+l11llllll11l_l1_[l1111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䖽")]+l1111_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ䖾")		# l11lll1lllll_l1_=l1111_l1_ (u"ࠧ࠷ࠢ䖿") l1l11l1l1ll1_l1_=l1111_l1_ (u"ࠨࡴࡳࡷࡨࠦ䗀") default=l1111_l1_ (u"ࠢࡵࡴࡸࡩࠧ䗁")>\n
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭䗂")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ䗃")+l11llllll11l_l1_[l1111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ䗄")]+l1111_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ䗅")+l11llllll11l_l1_[l1111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ䗆")]+l1111_l1_ (u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩ䗇")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭䗈")+l11llllll11l_l1_[l1111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䗉")]+l1111_l1_ (u"ࠩࠥ࠳ࡃࡢ࡮ࠨ䗊")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭䗋")+l11lll1l1ll1_l1_+l1111_l1_ (u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ䗌")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ䗍")+l11llllll11l_l1_[l1111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ䗎")]+l1111_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ䗏")	# l1l11lll1ll1_l1_=l1111_l1_ (u"ࠣࡶࡵࡹࡪࠨ䗐")>\n
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ䗑")+l11llllll11l_l1_[l1111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ䗒")]+l1111_l1_ (u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ䗓")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ䗔")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ䗕")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ䗖")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭䗗")
		l1l11l1ll11l_l1_ += l1111_l1_ (u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ䗘")
		#open(l1111_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ䗙"),l1111_l1_ (u"ࠫࡼࡨࠧ䗚")).write(l1l11l1ll11l_l1_)
		#LOG_THIS(l1111_l1_ (u"ࠬ࠭䗛"),l1l11l1ll11l_l1_)
		#l1l11l1ll11l_l1_ = l111l11_l1_(l1l111ll_l1_,l11ll11lllll_l1_,l1111_l1_ (u"࠭ࠧ䗜"),l1111_l1_ (u"ࠧࠨ䗝"),l1111_l1_ (u"ࠨࠩ䗞"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠹ࡵࡪࠪ䗟"))
		if kodi_version>18.99:
			import http.server as l1l111111ll1_l1_
			import http.client as l11l1l1lll11_l1_
		else:
			import BaseHTTPServer as l1l111111ll1_l1_
			import httplib as l11l1l1lll11_l1_
		class l1l11111ll11_l1_(l1l111111ll1_l1_.HTTPServer):
			#l1l11l1ll11l_l1_ = l1111_l1_ (u"ࠪࡀࡃ࠭䗠")
			def __init__(self,l1ll1llll1ll_l1_=l1111_l1_ (u"ࠫࡱࡵࡣࡢ࡮࡫ࡳࡸࡺࠧ䗡"),port=55055,l1l11l1ll11l_l1_=l1111_l1_ (u"ࠬࡂ࠾ࠨ䗢")):
				self.l1ll1llll1ll_l1_ = l1ll1llll1ll_l1_
				self.port = port
				self.l1l11l1ll11l_l1_ = l1l11l1ll11l_l1_
				l1l111111ll1_l1_.HTTPServer.__init__(self,(self.l1ll1llll1ll_l1_,self.port),l11l1l11l11l_l1_)
				self.l11lllll1l11_l1_ = l1111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ䗣")+l1ll1llll1ll_l1_+l1111_l1_ (u"ࠧ࠻ࠩ䗤")+str(port)+l1111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ䗥")
				#print(l1111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡻࡰࠡࡰࡲࡻࠥࡲࡩࡴࡶࡨࡲ࡮ࡴࡧࠡࡱࡱࠤࡵࡵࡲࡵ࠼ࠣࠫ䗦")+str(port))
			def start(self):
				self.threads = l111ll1ll1l_l1_(False)
				self.threads.start_new_thread(1,self.l11ll1ll1l1l_l1_)
			def l11ll1ll1l1l_l1_(self):
				#print(l1111_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡣࡵࡸࡪࡪࠧ䗧"))
				self.l11l1ll1l111_l1_ = True
				#l1l1llllll1_l1_ = 0
				while self.l11l1ll1l111_l1_:
					#l1l1llllll1_l1_ += 1
					#print(l1111_l1_ (u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠥࡧࠠࡴ࡫ࡱ࡫ࡱ࡫ࠠࡩࡣࡱࡨࡱ࡫࡟ࡳࡧࡴࡹࡪࡹࡴࠩࠫࠣࡲࡴࡽ࠺ࠡࠩ䗨")+str(l1l1llllll1_l1_)+l1111_l1_ (u"ࠬ࠭䗩"))
					#settimeout l11ll11l1l_l1_ not work l11lll1111ll_l1_ to error message if it l1l11l1l1l1l_l1_ l11ll11111ll_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l11ll1ll1l1l_l1_ l1111l11111_l1_ request l11lll1ll1l1_l1_ 60 seconds)
					self.handle_request()
				#print(l1111_l1_ (u"࠭ࡳࡦࡴࡹ࡭ࡳ࡭ࠠࡳࡧࡴࡹࡪࡹࡴࡴࠢࡶࡸࡴࡶࡰࡦࡦ࡟ࡲࠬ䗪"))
			def stop(self):
				self.l11l1ll1l111_l1_ = False
				self.l1l111111lll_l1_()	# needed to l1l111l1ll1l_l1_ self.handle_request() to l11ll1ll1l1l_l1_ l111l11llll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l1111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡨࡴࡽ࡮ࠡࡰࡲࡻࡡࡴࠧ䗫"))
			def load(self,l1l11l1ll11l_l1_):
				self.l1l11l1ll11l_l1_ = l1l11l1ll11l_l1_
			def l1l111111lll_l1_(self):
				conn = l11l1l1lll11_l1_.HTTPConnection(self.l1ll1llll1ll_l1_+l1111_l1_ (u"ࠨ࠼ࠪ䗬")+str(self.port))
				conn.request(l1111_l1_ (u"ࠤࡋࡉࡆࡊࠢ䗭"), l1111_l1_ (u"ࠥ࠳ࠧ䗮"))
		class l11l1l11l11l_l1_(l1l111111ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l1111_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡋࡊ࡚ࠠࠡࠩ䗯")+self.path)
				self.send_response(200)
				self.send_header(l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ䗰"),l1111_l1_ (u"࠭ࡴࡦࡺࡷ࠳ࡵࡲࡡࡪࡰࠪ䗱"))
				self.end_headers()
				#self.wfile.write(self.path+l1111_l1_ (u"ࠧ࡝ࡰࠪ䗲"))
				self.wfile.write(self.server.l1l11l1ll11l_l1_.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䗳")))
				time.sleep(1)
				if self.path==l1111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ䗴"): self.server.shutdown()
				if self.path==l1111_l1_ (u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭䗵"): self.server.shutdown()
			def do_HEAD(self):
				#print(l1111_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡌࡊࡇࡄࠡࠢࠪ䗶")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1l11111ll11_l1_(l1111_l1_ (u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ䗷"),55055,l1l11l1ll11l_l1_)
		#httpd.load(l1l11l1ll11l_l1_)
		l11lll1ll11l_l1_ = httpd.l11lllll1l11_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l11lll1ll11l_l1_ = l1111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭࡫ࡹࡩࡸ࡯࡭࠯ࡦࡤࡷ࡭࡯ࡦ࠯ࡱࡵ࡫࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠵ࡣࡩࡷࡱ࡯ࡩࡻࡲࡠ࠳࠲ࡥࡹࡵ࡟࠸࠱ࡷࡩࡸࡺࡰࡪࡥ࠷ࡣ࠽ࡹ࠯ࡎࡣࡱ࡭࡫࡫ࡳࡵ࠰ࡰࡴࡩ࠭䗸")
		#l11lll1ll11l_l1_ = l1111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡤࡷ࡭࠴ࡡ࡬ࡣࡰࡥ࡮ࢀࡥࡥ࠰ࡱࡩࡹ࠵ࡤࡢࡵ࡫࠶࠻࠺࠯ࡕࡧࡶࡸࡈࡧࡳࡦࡵ࠲࠶ࡨ࠵ࡱࡶࡣ࡯ࡧࡴࡳ࡭࠰࠳࠲ࡑࡺࡲࡴࡪࡔࡨࡷࡒࡖࡅࡈ࠴࠱ࡱࡵࡪࠧ䗹")
		#l11lll1ll11l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸࡸ࡯࠮ࡵࡧ࡯ࡩࡨࡵ࡭࠮ࡲࡤࡶ࡮ࡹࡴࡦࡥ࡫࠲࡫ࡸ࠯ࡨࡲࡤࡧ࠴ࡊࡁࡔࡊࡢࡇࡔࡔࡆࡐࡔࡐࡅࡓࡉࡅ࠰ࡖࡨࡰࡪࡩ࡯࡮ࡒࡤࡶ࡮ࡹࡔࡦࡥ࡫࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠵࡭ࡱ࠶࠰ࡰ࡮ࡼࡥ࠮࡯ࡳࡨ࠲ࡇࡖ࠮ࡄࡖ࠲ࡲࡶࡤࠨ䗺")
		#l11lll1ll11l_l1_ = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡨࡲ࡫ࡤࡪࡣ࠱ࡦࡧࡩ࠮ࡤࡱ࠱ࡹࡰ࠵ࡤࡢࡵ࡫࠳ࡴࡴࡤࡦ࡯ࡤࡲࡩ࠵ࡴࡦࡵࡷࡧࡦࡸࡤ࠰࠳࠲ࡧࡱ࡯ࡥ࡯ࡶࡢࡱࡦࡴࡩࡧࡧࡶࡸ࠲࡫ࡶࡦࡰࡷࡷ࠲ࡳࡵ࡭ࡶ࡬ࡰࡦࡴࡧ࠯࡯ࡳࡨࠬ䗻")
		#l11lll1ll11l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ䗼")
	else: httpd = l1111_l1_ (u"ࠫࠬ䗽")
	if not l11lll1ll11l_l1_: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ䗾"),[],[]
	return l1111_l1_ (u"࠭ࠧ䗿"),[l1111_l1_ (u"ࠧࠨ䘀")],[[l11lll1ll11l_l1_,l11l1ll11lll_l1_,httpd]]
def l11lllll11l1_l1_(url):
	# l1ll11ll_l1_://l1l1111llll1_l1_.com/l11lll11l11l_l1_
	headers = { l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䘁") : l1111_l1_ (u"ࠩࠪ䘂") }
	#url = url.replace(l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䘃"),l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ䘄"))
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠬ࠭䘅"),headers,l1111_l1_ (u"࠭ࠧ䘆"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ䘇"))
	items = re.findall(l1111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ䘈"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l111lll11l_l1_,l11111l_l1_,l11ll1lll111_l1_,l11lll1l_l1_ = [],[],[],[]
	if items:
		for l1l111l_l1_,dummy,l1lll1ll1l1l_l1_ in items:
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ䘉"),l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䘊"))
			if l1111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䘋") in l1l111l_l1_:
				l1l111lll11l_l1_,l11ll1lll111_l1_ = l1l1ll111l_l1_(l1l111l_l1_)
				#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭䘌"),l1111_l1_ (u"࠭ࠧ䘍"),str(l11lll1l_l1_),str(l11ll1lll111_l1_))
				l11lll1l_l1_ = l11lll1l_l1_ + l11ll1lll111_l1_
				if l1l111lll11l_l1_[0]==l1111_l1_ (u"ࠧ࠮࠳ࠪ䘎"): l11111l_l1_.append(l1111_l1_ (u"ࠨีํีๆืࠠฯษุࠫ䘏")+l1111_l1_ (u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ䘐"))
				else:
					for title in l1l111lll11l_l1_:
						l11111l_l1_.append(l1111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭䘑")+l1111_l1_ (u"ࠫࠥࠦࠠࠨ䘒")+title)
			else:
				title = l1111_l1_ (u"ู๊ࠬาใิࠤำอีࠨ䘓")+l1111_l1_ (u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩ䘔")+l1lll1ll1l1l_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
				l11111l_l1_.append(title)
		return l1111_l1_ (u"ࠧࠨ䘕"),l11111l_l1_,l11lll1l_l1_
	else: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ䘖"),[],[]
def	l11ll1l111l1_l1_(url):
	# l1ll11ll_l1_://l1l111lll111_l1_.cc/l11l1l11l_l1_-1qrpoobdg7bu.html
	# l1ll11ll_l1_://l1l11111l111_l1_.cc//l11l1l11l_l1_-l11ll1l1l111_l1_.html
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭䘗"),url,l1111_l1_ (u"ࠪࠫ䘘"),l1111_l1_ (u"ࠫࠬ䘙"),l1111_l1_ (u"ࠬ࠭䘚"),l1111_l1_ (u"࠭ࠧ䘛"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜࡛ࡏࡄࡆࡑࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ䘜"))
	html = response.content
	l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䘝"),html,re.DOTALL)
	if l11l1ll1_l1_:
		l1l111l_l1_ = l11l1ll1_l1_[0]
		return l1111_l1_ (u"ࠩࠪ䘞"),[l1111_l1_ (u"ࠪࠫ䘟")],[l1l111l_l1_]
	return l1111_l1_ (u"ࠫࠬ䘠"),[],[]
def	l11l1lllll11_l1_(url):
	# l1ll11ll_l1_://l11l1l1lllll_l1_.in/l1l11ll11ll1_l1_
	# l1ll11ll_l1_://l11l1l1lllll_l1_.in/l11l1l11l_l1_-l1l11ll11ll1_l1_.html
	# l1ll11ll_l1_://l1l11l11lll1_l1_.l1lll11111l1_l1_/l11lll1ll111_l1_
	# l1ll11ll_l1_://l1l11l11lll1_l1_.l1lll11111l1_l1_/l11l1l11l_l1_-l11lll1ll111_l1_.html
	# l1ll11ll_l1_://l1ll11llll11_l1_.l1l111111l1l_l1_.com/l11l1l11l_l1_-l1l11lll11l1_l1_.html
	url = url.replace(l1111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䘡"),l1111_l1_ (u"࠭ࠧ䘢")).replace(l1111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭䘣"),l1111_l1_ (u"ࠨࠩ䘤"))
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭䘥"),url,l1111_l1_ (u"ࠪࠫ䘦"),l1111_l1_ (u"ࠫࠬ䘧"),l1111_l1_ (u"ࠬ࠭䘨"),l1111_l1_ (u"࠭ࠧ䘩"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭䘪"))
	html = response.content
	l1lllllll1ll_l1_ = re.findall(l1111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ䘫"),html,re.DOTALL)
	if l1lllllll1ll_l1_:
		l1lllllll1ll_l1_ = l1lllllll1ll_l1_[0]
		l1ll1ll111l1_l1_ = l1lll111111l_l1_(l1lllllll1ll_l1_)
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䘬"),l1ll1ll111l1_l1_,re.DOTALL)
		if not l11l1ll1_l1_: l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪࠬࢁࠬ䘭"),l1ll1ll111l1_l1_,re.DOTALL)
		l11111l_l1_,l11lll1l_l1_ = [],[]
		for l1l111l_l1_,title in l11l1ll1_l1_:
			if not title: title = l1l111l_l1_.rsplit(l1111_l1_ (u"ࠫ࠳࠭䘮"),1)[1]
			l11111l_l1_.append(title)
			l11lll1l_l1_.append(l1l111l_l1_)
		return l1111_l1_ (u"ࠬ࠭䘯"),l11111l_l1_,l11lll1l_l1_
	id = url.split(l1111_l1_ (u"࠭࠯ࠨ䘰"))[3]
	headers = { l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䘱"):l1111_l1_ (u"ࠨࠩ䘲") , l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䘳"):l1111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䘴") }
	payload = { l1111_l1_ (u"ࠫ࡮ࡪࠧ䘵"):id , l1111_l1_ (u"ࠬࡵࡰࠨ䘶"):l1111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ䘷") }
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䘸"),url,payload,headers,l1111_l1_ (u"ࠨࠩ䘹"),l1111_l1_ (u"ࠩࠪ䘺"),l1111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ䘻"))
	html = response.content
	items = re.findall(l1111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䘼"),html,re.DOTALL)
	if items: return l1111_l1_ (u"ࠬ࠭䘽"),[l1111_l1_ (u"࠭ࠧ䘾")],[ items[0] ]
	return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡛ࠢࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇࠨ䘿"),[],[]
l1111_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡉࡒ࡚ࡎࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡼࡩࡥࡧࡲ࠳ࡵࡲࡡࡺ࠱ࡄࡅ࡛ࡋࡎࡥࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠡࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࠠ࠻ࠢࠪࠫࠥࢃࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔ࡜ࡉࡅ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࡟࠵ࡣ࠽࠾ࠩ࠰࠵ࠬࡀࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠽ࠎࠎࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰࡴ࠹࠭ࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓ࡛ࡏࡄࠨ࠮࡞ࡡ࠱ࡡ࡝ࠋࠋࠦࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠱࡮࠰ࡪࡳࡻ࡯ࡤ࠯ࡥࡲ࠳ࡸࡺࡲࡦࡣࡰ࠳࠷࠸࠹࠯࡯࠶ࡹ࠽ࠐࠢࠣࠤ䙀")
#####################################################
#    l11lll11lll1_l1_ l1l111ll1l11_l1_ l11ll1l11lll_l1_
#    16-06-2019
#####################################################
def l11ll1111ll1_l1_(url):
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠩࠪ䙁"),l1111_l1_ (u"ࠪࠫ䙂"),l1111_l1_ (u"ࠫࠬ䙃"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ䙄"))
	items = re.findall(l1111_l1_ (u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䙅"),html,re.DOTALL)
	if items: return l1111_l1_ (u"ࠧࠨ䙆"),[l1111_l1_ (u"ࠨࠩ䙇")],[ items[0] ]
	else: return l1111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧ䙈"),[],[]
def l11lllll11ll_l1_(url):
	return l1111_l1_ (u"ࠪࠫ䙉"),[l1111_l1_ (u"ࠫࠬ䙊")],[ url ]
def l1l111ll1lll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭䙋"),l1111_l1_ (u"࠭ࠧ䙌"),url,l1111_l1_ (u"ࠧࠨ䙍"))
	server = url.split(l1111_l1_ (u"ࠨ࠱ࠪ䙎"))
	basename = l1111_l1_ (u"ࠩ࠲ࠫ䙏").join(server[0:3])
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠪࠫ䙐"),l1111_l1_ (u"ࠫࠬ䙑"),l1111_l1_ (u"ࠬ࠭䙒"),l1111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪ䙓"))
	items = re.findall(l1111_l1_ (u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䙔"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䙕"),l1111_l1_ (u"ࠩࠪ䙖"),url,str(var))
	if items:
		l1l1ll111111_l1_,l1l1ll11l1l1_l1_,l1l1ll11l1ll_l1_,l1l11l1ll1l1_l1_,l1l11l1ll1ll_l1_,l1l11lll11ll_l1_ = items[0]
		var = int(l1l1ll11l1l1_l1_) % int(l1l1ll11l1ll_l1_) + int(l1l11l1ll1l1_l1_) % int(l1l11l1ll1ll_l1_)
		url = basename + l1l1ll111111_l1_ + str(var) + l1l11lll11ll_l1_
		return l1111_l1_ (u"ࠪࠫ䙗"),[l1111_l1_ (u"ࠫࠬ䙘")],[url]
	else: return l1111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫ䙙"),[],[]
def l11llll1llll_l1_(url):
	url = url.replace(l1111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭䙚"),l1111_l1_ (u"ࠧࠨ䙛"))
	url = url.replace(l1111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䙜"),l1111_l1_ (u"ࠩࠪ䙝"))
	id = url.split(l1111_l1_ (u"ࠪ࠳ࠬ䙞"))[-1]
	headers = { l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䙟") : l1111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䙠") }
	payload = { l1111_l1_ (u"ࠨࡩࡥࠤ䙡"):id , l1111_l1_ (u"ࠢࡰࡲࠥ䙢"):l1111_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦ䙣") }
	request = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䙤"), url, payload, headers, l1111_l1_ (u"ࠪࠫ䙥"),l1111_l1_ (u"ࠫࠬ䙦"),l1111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡓ࠸࡚ࡖࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ䙧"))
	if l1111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䙨") in list(request.headers.keys()): l1l111l_l1_ = request.headers[l1111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䙩")]
	else: l1l111l_l1_ = url
	if l1l111l_l1_: return l1111_l1_ (u"ࠨࠩ䙪"),[l1111_l1_ (u"ࠩࠪ䙫")],[l1l111l_l1_]
	else: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡐ࠵ࡗࡓࡐࡔࡇࡄࠨ䙬"),[],[]
def l11l1l11ll11_l1_(url):
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠫࠬ䙭"),l1111_l1_ (u"ࠬ࠭䙮"),l1111_l1_ (u"࠭ࠧ䙯"),l1111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡎࡔࡔࡗࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ䙰"))
	items = re.findall(l1111_l1_ (u"ࠨ࡯ࡳ࠸࠿ࠦ࡜࡜࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ䙱"),html,re.DOTALL)
	if items: return l1111_l1_ (u"ࠩࠪ䙲"),[l1111_l1_ (u"ࠪࠫ䙳")],[ items[0] ]
	else: return l1111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡊࡐࡗ࡚ࡑࡏࡖࡆࠩ䙴"),[],[]
def l1l111lll1ll_l1_(url):
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠬ࠭䙵"),l1111_l1_ (u"࠭ࠧ䙶"),l1111_l1_ (u"ࠧࠨ䙷"),l1111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡃࡉࡋ࡙ࡉ࠲࠷ࡳࡵࠩ䙸"))
	items = re.findall(l1111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䙹"),html,re.DOTALL)
	#l11llll1lll1_l1_.l11ll111l11l_l1_(l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠳ࡵࡲࡨࠩ䙺") + items[0])
	if items:
		url = url = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ䙻") + items[0]
		return l1111_l1_ (u"ࠬ࠭䙼"),[l1111_l1_ (u"࠭ࠧ䙽")],[ url ]
	else: return l1111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ䙾"),[],[]
def l1l11llll1ll_l1_(url):
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"ࠨࠩ䙿"),l1111_l1_ (u"ࠩࠪ䚀"),l1111_l1_ (u"ࠪࠫ䚁"),l1111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡗࡅࡐࡎࡉࡖࡊࡆࡈࡓࡍࡕࡓࡕ࠯࠴ࡷࡹ࠭䚂"))
	items = re.findall(l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䚃"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ䚄"),l1111_l1_ (u"ࠧࠨ䚅"),str(items),html)
	if items: return l1111_l1_ (u"ࠨࠩ䚆"),[l1111_l1_ (u"ࠩࠪ䚇")],[ items[0] ]
	else: return l1111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚ࠧ䚈"),[],[]
def l11l1llll11l_l1_(url):
	#url = url.replace(l1111_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ䚉"),l1111_l1_ (u"ࠬ࠭䚊"))
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"࠭ࠧ䚋"),l1111_l1_ (u"ࠧࠨ䚌"),l1111_l1_ (u"ࠨࠩ䚍"),l1111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ䚎"))
	items = re.findall(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䚏"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ䚐"),l1111_l1_ (u"ࠬ࠭䚑"),items[0],items[0])
	if items: return l1111_l1_ (u"࠭ࠧ䚒"),[l1111_l1_ (u"ࠧࠨ䚓")],[ items[0] ]
	else: return l1111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫ䚔"),[],[]
l1111_l1_ (u"ࠤࠥࠦࠏࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠍࠧࠥࠦࠠࠡࡐࡒࡘࠥ࡝ࡏࡓࡍࡌࡒࡌࠦࡁࡏ࡛ࡐࡓࡗࡋࠊࠤࠢࠣࠤࠥ࠶࠲࠮ࡈࡈࡆ࠲࠸࠰࠳࠳ࠍࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠋࠌࠍࠎࠏࠨࠢࠣ䚕")
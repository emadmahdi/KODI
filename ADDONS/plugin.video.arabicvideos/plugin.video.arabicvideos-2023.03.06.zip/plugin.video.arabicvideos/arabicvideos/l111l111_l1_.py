# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
#l1ll11l_l1_ = l1111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮࠱ࡹ࡭ࡪࡽ࠭࠲࠱สๅ้อๅ࠮฻ิฬ๏ฯࠧ஘")
#l1ll11l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭ࠨங")
#l1ll11l_l1_ = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡺ࠶࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪச")
#l1ll11l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰ࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶࠧ஛")
l111_l1_ = l1111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫஜ")
headers = {l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ஝"):l1111_l1_ (u"࠭ࠧஞ")}
menu_name=l1111_l1_ (u"ࠧࡠࡍࡏࡅࡤ࠭ட")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,text):
	if   mode==10: l11l_l1_ = l11l111_l1_()
	elif mode==11: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==12: l11l_l1_ = l1lllll_l1_(url)
	elif mode==13: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==14: l11l_l1_ = l1llll1ll_l1_()
	elif mode==15: l11l_l1_ = l1lllllll_l1_()
	elif mode==16: l11l_l1_ = l1111ll1_l1_()
	elif mode==19: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஠"),menu_name+l1111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ஡"),l1111_l1_ (u"ࠪࠫ஢"),19,l1111_l1_ (u"ࠫࠬண"),l1111_l1_ (u"ࠬ࠭த"),l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ஥"))
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ஦"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ஧"),l1111_l1_ (u"ࠩࠪந"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪன"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨப")+menu_name+l1111_l1_ (u"ࠬศฮาࠢส่ส฼วโษอࠫ஫"),l1111_l1_ (u"࠭ࠧ஬"),14)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஭"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬம")+menu_name+l1111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠩய"),l1111_l1_ (u"ࠪࠫர"),15)
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠫࠬற"),headers,l1111_l1_ (u"ࠬ࠭ல"),l1111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨள"))
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠧࡪࡦࡀࠦࡳࡧࡶ࠮ࡵ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ழ"),html,re.DOTALL)
	l111ll11_l1_ = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪவ"),l111ll11_l1_,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"ࠩࠣࠫஶ"))
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஷ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨஸ")+menu_name+title,l1l111l_l1_,11)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪஹ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭஺"),l1111_l1_ (u"ࠧࠨ஻"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡫ࡧࡁࠧࡴࡡࡷࡤࡤࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ஼"),html,re.DOTALL)
	l111ll1l_l1_ = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஽"),l111ll1l_l1_,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪா"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨி")+menu_name+title,l1l111l_l1_,11)
	return html
def l1lllllll_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬீ"),menu_name+l1111_l1_ (u"࠭ฬๆ์฼ࠤฬ๊ๅิๆึ่ฬะࠠศๆ฼ีอ๐ษࠨு"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠳࠸࠰็ึุ่๊วห࠯฼ีอ๐ษࠨூ"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௃"),menu_name+l1111_l1_ (u"่ࠩืู้ไศฬࠣหู้ๆสࠢส่ศิ๊าหࠪ௄"),l1111_l1_ (u"ࠪࠫ௅"),16)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫெ"),menu_name+l1111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥอไฤะํีฮ࠭ே"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠲࠾࠯ๆี็ื้อส࠮ำฺ่ฬ์࠭࠳࠲࠵࠶ࠬை"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ௉"),menu_name+l1111_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠶࠷࠭ொ"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠸࠲࠰็ุี๏ฯࠧோ"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪௌ"),menu_name+l1111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠲࠲்ࠩ"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠴࠴࠳๊฻ั๋หࠪ௎"),11)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭௏"),menu_name+l1111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠵࠴ࠬௐ"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠷࠶࠯ๆืิ๎ฮ࠭௑"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ௒"),menu_name+l1111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠷࠹ࠨ௓"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠲࠻࠲ฺ้ื๊สࠩ௔"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ௕"),menu_name+l1111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠳࠻ࠫ௖"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠵࠽࠵ๅึำํอࠬௗ"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௘"),menu_name+l1111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠶࠽ࠧ௙"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠱࠸࠱ู่ึ๐ษࠨ௚"),11)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ௛"),menu_name+l1111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠲࠸ࠪ௜"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠴࠺࠴๋ีา์ฬࠫ௝"),11)
	return
def l1llll1ll_l1_():
	html = l111l11_l1_(l1111l1_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠧࠨ௞"),headers,True,l1111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ௟"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ௠"),l1111_l1_ (u"ࠪࠫ௡"),l1111_l1_ (u"ࠫࠬ௢"),html)
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠬ࡮ࡥࡢࡦ࡬ࡲ࡬࠳ࡴࡰࡲࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠫ௣"),html,re.DOTALL)
	block = l111l1l_l1_[0]+l111l1l_l1_[1]
	items=re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ௤"),block,re.DOTALL)
	for l1l111l_l1_,img,title in items:
		url = l1ll11l_l1_ + l1l111l_l1_
		if l1111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ௥") in url: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௦"),menu_name+title,url,11,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ௧"),menu_name+title,url,12,img)
	return
def l1l11l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ௨"),l1111_l1_ (u"ࠫࠬ௩"),l1111_l1_ (u"࡚ࠬࡉࡕࡎࡈࡗࠬ௪"),url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ௫"),url,l1111_l1_ (u"ࠧࠨ௬"),headers,True,True,l1111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ௭"))
	html = response.content
	#open(l1111_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ௮"),l1111_l1_ (u"ࠪࡻࠬ௯")).write(str(html))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠭࠴ࠪࡀࠫࡵ࡭࡬࡮ࡴࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ௰"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	l1ll1ll11_l1_ = False
	#items = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬ࡠ࠻࠲࡞࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ௱"),block,re.DOTALL)
	items = re.findall(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠲ࡨ࡯ࡹ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௲"),block,re.DOTALL)
	l1lllll1_l1_,l1111lll_l1_ = [],[]
	for l1l111l_l1_,img,title in items:
		if title==l1111_l1_ (u"ࠧࠨ௳"): title = l1l111l_l1_.split(l1111_l1_ (u"ࠨ࠱ࠪ௴"))[-1].replace(l1111_l1_ (u"ࠩ࠰ࠫ௵"),l1111_l1_ (u"ࠪࠤࠬ௶"))
		l111l1ll_l1_ = re.findall(l1111_l1_ (u"ࠫ࠭ࡢࡤࠬࠫࠪ௷"),title,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		l1111lll_l1_.append([img,l1l111l_l1_,title,l111l1ll_l1_])
	l1111lll_l1_ = sorted(l1111lll_l1_, reverse=True, key=lambda key: key[3])
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭௸"),l1111_l1_ (u"࠭ࠧ௹"),l1111_l1_ (u"ࠧ࠳࠴࠵ࠫ௺"),url)
	for img,l1l111l_l1_,title,l111l1ll_l1_ in l1111lll_l1_:
		l1l111l_l1_ = l1ll11l_l1_ + l1l111l_l1_
		#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ௻"),l1111_l1_ (u"ࠩࠪ௼"),url,title)
		title = title.replace(l1111_l1_ (u"ู้ࠪอ็ะหุ้๊ࠣำๅࠩ௽"),l1111_l1_ (u"ู๊ࠫไิๆࠪ௾"))
		title = title.replace(l1111_l1_ (u"๋ࠬิศ้าอࠥอไๆี็ื้࠭௿"),l1111_l1_ (u"࠭วๅ็ึุ่๊ࠧఀ"))
		title = title.replace(l1111_l1_ (u"ࠧๆึส๋ิฯࠠโ์็้ࠬఁ"),l1111_l1_ (u"ࠨใํ่๊࠭ం"))
		title = title.replace(l1111_l1_ (u"ุ่ࠩฬํฯสࠢส่ๆ๐ไๆࠩః"),l1111_l1_ (u"ࠪห้็๊ๅ็ࠪఄ"))
		title = title.replace(l1111_l1_ (u"๊ࠫฮวีำฬࠤ่๎วๅ์อ๎ࠬఅ"),l1111_l1_ (u"ࠬ࠭ఆ"))
		title = title.replace(l1111_l1_ (u"ู࠭ศๆํอࠥ฿ไ๊ࠢส่฾ืศࠨఇ"),l1111_l1_ (u"ࠧࠨఈ"))
		title = title.replace(l1111_l1_ (u"ࠨ็ืห์ีษࠡ็หหูืษࠨఉ"),l1111_l1_ (u"ࠩࠪఊ"))
		title = title.replace(l1111_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠬఋ"),l1111_l1_ (u"ࠫࠬఌ"))
		title = title.replace(l1111_l1_ (u"ࠬอ่็ๆส๎๋࠭఍"),l1111_l1_ (u"࠭ࠧఎ"))
		title = title.replace(l1111_l1_ (u"ࠧษฮ๋ำฮูࠦศๆํอࠬఏ"),l1111_l1_ (u"ࠨࠩఐ"))
		title = title.replace(l1111_l1_ (u"ࠩฯ์ิฯฺࠠษ็๎ฮ࠭఑"),l1111_l1_ (u"ࠪࠫఒ"))
		title = title.replace(l1111_l1_ (u"ࠫอี่็ࠢอั๊๐ไࠨఓ"),l1111_l1_ (u"ࠬ࠭ఔ"))
		title = title.replace(l1111_l1_ (u"ู࠭ๅ๋ࠣห้฿ัษࠩక"),l1111_l1_ (u"ࠧࠨఖ"))
		title = title.replace(l1111_l1_ (u"ࠨ็หหูืษࠨగ"),l1111_l1_ (u"ࠩࠪఘ"))
		title = title.strip(l1111_l1_ (u"ࠪࠤࠬఙ")).replace(l1111_l1_ (u"ࠫࠥࠦࠧచ"),l1111_l1_ (u"ࠬࠦࠧఛ")).replace(l1111_l1_ (u"࠭ࠠࠡࠩజ"),l1111_l1_ (u"ࠧࠡࠩఝ"))
		title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧఞ")+title
		title2 = title
		if l1111_l1_ (u"ࠩ࠲ࡵ࠴࠭ట") in url and (l1111_l1_ (u"ࠪห้ำไใหࠪఠ") in title or l1111_l1_ (u"ࠫฬ๊อๅไ๊ࠫడ") in title):
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨఢ"),title,re.DOTALL)
			if l11l11l_l1_: title2 = l11l11l_l1_[0]
			#if l1111_l1_ (u"࠭ๅิๆึ่ࠬణ") not in title2: title2 = l1111_l1_ (u"ࠧๆี็ื้ࠦࠧత")+title2
		if title2 not in l1lllll1_l1_:
			l1lllll1_l1_.append(title2)
			#xbmc.log(title2, level=xbmc.LOGNOTICE)
			if l1111_l1_ (u"ࠨ࠱ࡴ࠳ࠬథ") in url and (l1111_l1_ (u"ࠩส่า๊โสࠩద") in title or l1111_l1_ (u"ࠪห้ำไใ้ࠪధ") in title):
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫన"),menu_name+title2,l1l111l_l1_,13,img)
				l1ll1ll11_l1_ = True
			elif l1111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ఩") in l1l111l_l1_:
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ప"),menu_name+title,l1l111l_l1_,11,img)
				l1ll1ll11_l1_ = True
			else:
				#if l1111_l1_ (u"ࠧๆี็ื้࠭ఫ") not in title and l1111_l1_ (u"ࠨษ็ั้่ษࠨబ") in title: title = l1111_l1_ (u"่ࠩืู้ไࠡࠩభ")+title
				l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩమ"),menu_name+title,l1l111l_l1_,12,img)
				l1ll1ll11_l1_ = True
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬయ"),l1111_l1_ (u"ࠬ࠭ర"),l1111_l1_ (u"࠭࠳࠴࠵ࠪఱ"),url)
	if l1ll1ll11_l1_:
		items = re.findall(l1111_l1_ (u"ࠧࡵࡵࡦࡣ࠸ࡪ࡟ࡣࡷࡷࡸࡴࡴࠠࡳࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬల"),block,re.DOTALL)
		for l1l111l_l1_,page in items:
			url = l1ll11l_l1_ + l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨళ"),menu_name+page,url,11)
	return
def l1l11ll_l1_(url):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠩࠪఴ"),headers,True,l1111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩవ"))
	l111l1l1_l1_ = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡹࡥࡳ࡫ࡨࡷ࠳࠰࠿ࠪࠤࠪశ"),html,re.DOTALL)
	l1l1lll_l1_ = l1ll11l_l1_+l111l1l1_l1_[0]
	l11l_l1_ = l1l11l1_l1_(l1l1lll_l1_)
	return
l1111_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡋࡐࡊࡕࡒࡈࡊ࡙࡟ࡐࡎࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࡔࡳࡷࡨ࠰ࠬࡇࡌࡂࡔࡄࡆ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࡟ࡐࡎࡇ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡥࡥࡳࡴࡥࡳ࠯ࡵ࡭࡬࡮ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶ࡭ࡨ࠳ࡣࡩࡣࡱࡲࡪࡲࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡹࡴࡦࡲࠣ࠶ࠬ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡵࡳ࡮࠯ࠫࡸࡺࡥࡱࠢ࠶ࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡵࡲࡶࡹ࡫ࡤࠩ࡫ࡷࡩࡲࡹࠬࠡࡴࡨࡺࡪࡸࡳࡦ࠿ࡗࡶࡺ࡫ࠬࠡ࡭ࡨࡽࡂࡲࡡ࡮ࡤࡧࡥࠥࡱࡥࡺ࠼ࠣ࡯ࡪࡿ࡛࠲࡟ࠬࠎࠎࠩ࡮ࡢ࡯ࡨࠤࡂࠦࡸࡣ࡯ࡦ࠲࡬࡫ࡴࡊࡰࡩࡳࡑࡧࡢࡦ࡮ࠫࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠭ࠩࡶࡸࡪࡶࠠ࠵ࠩࠬࠎࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡧࡱࡵࠤ࡮ࡳࡧ࠭࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌ࡭࡫ࠦࡴࡪࡶ࡯ࡩࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࡗࡑࡕ࡚ࡕࡔࡆࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆี็ื้ࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠷࠲࠭࡫ࡰ࡫࠮ࠐࠉࠊࠋࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠻ࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨష")
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	html = l111l11_l1_(l1ll1llll_l1_,url,l1111_l1_ (u"࠭ࠧస"),headers,True,l1111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩహ"))
	# l1llll111_l1_ l1lll1l1l_l1_ server
	# l1ll11ll_l1_://l111lll1_l1_.l1lll1ll1_l1_.com/l1lll11ll_l1_-_حلقة_1ll1ll1l_l1_حكايتي_1111111_l1_رمضان_11111ll_l1_
	# l1ll11ll_l1_://l111l11l_l1_.l1lll1ll1_l1_.com/numeric/110272.l1111l1l_l1_/l11111l1_l1_.l1llll111_l1_
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡷࡵ࠳ࡩࡧࡴࡤࡱࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ఺"),html,re.DOTALL)
	if l1l1lll_l1_:
		l1l1lll_l1_ = l1l1lll_l1_[0]
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠩࡡࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠥࠩ఻"),l1l1lll_l1_,re.DOTALL)
		if l11l1ll1_l1_:
			first = l11l1ll1_l1_[0][0]
			second,l1lll1111_l1_ = l11l1ll1_l1_[0][1].rsplit(l1111_l1_ (u"ࠪ࠳఼ࠬ"),1)
			l11l11_l1_ = second+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬఽ")
			l11lll1l_l1_.append(l11l11_l1_)
			l1llllll1_l1_ = first+l1lll1111_l1_
		else:
			l11llll1_l1_ = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭ా"),headers,False,l1111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨి"))
			l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡵࡵࡧࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨీ"),l11llll1_l1_,re.DOTALL)
			if l1l1lll_l1_:
				l1l1lll_l1_ = l1l1lll_l1_[0]+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱ࠸ࡻ࠸ࠨు")
				l11lll1l_l1_.append(l1l1lll_l1_)
	# l1ll1l1ll_l1_ server - l111111l_l1_ - l1ll11ll_l1_://l111lll1_l1_.l1lll1ll1_l1_.com/l1lll1l11_l1_-_الذئب_حلقة_1lll11l1_l1_
	# l1ll1l1ll_l1_ server - l1ll1lll1_l1_ - l1ll11ll_l1_://l111lll1_l1_.l1lll1ll1_l1_.com/l1111l11_l1_-_1lll111l_l1_فيلم_اكشن_1lllll11_l1_
	# l1ll1l1ll_l1_ server - l1llll1l1_l1_ - l1ll11ll_l1_://l111lll1_l1_.l1lll1ll1_l1_.com/l1llll11l_l1_-_لحلقة_1lllll1l_l1_السجين_مترجمة_1lll1lll_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡄࡲࡼ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪూ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩృ"),block,re.DOTALL)
		if l1l1lll_l1_:
			l1l1lll_l1_ = l1l1lll_l1_[0]+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬౄ")
			l11lll1l_l1_.append(l1l1lll_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ౅"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬె"),url)
	return
def l1111ll1_l1_():
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠧࠨే"),headers,True,l1111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡔࡄࡑࡆࡊࡁࡏ࠯࠴ࡷࡹ࠭ై"))
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠩ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳࡺ࡟ࡴࡧࡦࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨ࡬ࡦࡨࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭౉"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items=re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬొ"),block,re.DOTALL)
	year = re.findall(l1111_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠮࡛࠱࠯࠼ࡡ࠰࠯࠯ࠨో"),str(items),re.DOTALL)
	year = year[0]
	for l1l111l_l1_,title in items:
		url = l1ll11l_l1_+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"ࠬࠦࠧౌ"))+l1111_l1_ (u"࠭ࠠࠨ్")+year
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౎"),menu_name+title,url,11)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠨࠩ౏"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠩࠪ౐"): return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"ࠪࠤࠬ౑"),l1111_l1_ (u"ࠫࠪ࠸࠰ࠨ౒"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠧ࠵ࡱ࠰ࠤ౓") + l1lll1l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ౔"),l1111_l1_ (u"ࠧࠨౕ"),l1111_l1_ (u"ࠨ࠵࠶࠷ౖࠬ"),url)
	l11l_l1_ = l1l11l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㢛")
headers = { l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㢜") : l1111_l1_ (u"ࠪࠫ㢝") }
menu_name=l1111_l1_ (u"ࠫࡤࡓࡖ࡛ࡡࠪ㢞")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l1ll1111l1_l1_ = l111lll_l1_[l111_l1_][1]
def l1111ll_l1_(mode,url,text):
	if   mode==180: l11l_l1_ = l11l111_l1_()
	elif mode==181: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==182: l11l_l1_ = l1lllll_l1_(url)
	elif mode==183: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==188: l11l_l1_ = l1l1ll11l11l_l1_()
	elif mode==189: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l1l1ll11l11l_l1_():
	message = l1111_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠡ࠰࠱࠲ࠥ๎ศฮษฯอࠥอไ๊ࠢส฽ฬีษࠡสิ้ัฯࠠๆ่ࠣห้฻แาࠢ࠱࠲࠳่ࠦศๆ่ฬึ๋ฬࠡฯส่๏อࠠๆึ฽์้่๋ࠦ฻ส๊๏ࠦๅ็๋ࠢ฽่ฯࠠึฯํอࠥ࠴࠮࠯๋่ࠢ์ึวࠡี๋ๅࠥ๐ศใ๋ࠣห้๋่ใ฻้ࠣ฿๊โࠡษ็ํ๋ࠥวࠡึสลࠥอไๅ้ࠪ㢟")
	l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㢠"),l1111_l1_ (u"ࠧࠨ㢡"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㢢"),message)
	return
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㢣"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ㢤"),l1111_l1_ (u"ࠫࠬ㢥"),189,l1111_l1_ (u"ࠬ࠭㢦"),l1111_l1_ (u"࠭ࠧ㢧"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㢨"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㢩"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭㢪")+menu_name+l1111_l1_ (u"ࠪฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࠫ㢫"),l1ll11l_l1_,181,l1111_l1_ (u"ࠫࠬ㢬"),l1111_l1_ (u"ࠬ࠭㢭"),l1111_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ㢮"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㢯"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ㢰")+menu_name+l1111_l1_ (u"ࠩฦัิัࠠศๆสๅ้อๅࠨ㢱"),l1ll11l_l1_,181,l1111_l1_ (u"ࠪࠫ㢲"),l1111_l1_ (u"ࠫࠬ㢳"),l1111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㢴"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㢵"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ㢶")+menu_name+l1111_l1_ (u"ࠨฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ีࠧ㢷"),l1ll11l_l1_,181,l1111_l1_ (u"ࠩࠪ㢸"),l1111_l1_ (u"ࠪࠫ㢹"),l1111_l1_ (u"ࠫࡹࡼࠧ㢺"))
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㢻"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ㢼")+menu_name+l1111_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧ㢽"),l1ll11l_l1_,181,l1111_l1_ (u"ࠨࠩ㢾"),l1111_l1_ (u"ࠩࠪ㢿"),l1111_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭㣀"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㣁"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ㣂")+menu_name+l1111_l1_ (u"࠭รใ๊์ࠤฬ๊วโๆส้ࠥอไฮษ็๎ฮ࠭㣃"),l1ll11l_l1_,181,l1111_l1_ (u"ࠧࠨ㣄"),l1111_l1_ (u"ࠨࠩ㣅"),l1111_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭㣆"))
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠪࠫ㣇"),headers,l1111_l1_ (u"ࠫࠬ㣈"),l1111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㣉"))
	items = re.findall(l1111_l1_ (u"࠭࠼ࡩ࠴ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㣊"),html,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㣋"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ㣌")+menu_name+title,l1l111l_l1_,181)
	return html
def l1l11l1_l1_(url,type=l1111_l1_ (u"ࠩࠪ㣍")):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠪࠫ㣎"),headers,l1111_l1_ (u"ࠫࠬ㣏"),l1111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ㣐"))
	if type==l1111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭㣑"): block = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ฤฯาฯࠥอไฤใ็ห๊ࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ㣒"),html,re.DOTALL)[0]
	elif type==l1111_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬ㣓"): block = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀห์ู่ࠠศ๊ไ๎ุࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ㣔"),html,re.DOTALL)[0]
	elif type==l1111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㣕"): block = re.findall(l1111_l1_ (u"ࠫࡧࡺ࡮࠮࠴࠰ࡳࡻ࡫ࡲ࡭ࡣࡼࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩ㣖"),html,re.DOTALL)[0]
	elif type==l1111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ㣗"): block = re.findall(l1111_l1_ (u"࠭ࡢࡵࡰ࠰࠵ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠪ࠱࠮ࡄ࠯ࡢࡵࡰ࠰࠶ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠩ㣘"),html,re.DOTALL)[0]
	elif type==l1111_l1_ (u"ࠧࡵࡸࠪ㣙"): block = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡨࠤࠪ㣚"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ㣛"),l1111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㣜")]:
		items = re.findall(l1111_l1_ (u"ࠫࡸࡺࡹ࡭ࡧࡀࠦࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㣝"),block,re.DOTALL)
	else: items = re.findall(l1111_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࡂࠨ࠳࡜࠲࠰࠽ࡢ࠱ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㣞"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l11l111ll_l1_ = [l1111_l1_ (u"࠭แ๋ๆ่ࠫ㣟"),l1111_l1_ (u"ࠧศๆะ่็ฯࠧ㣠"),l1111_l1_ (u"ࠨษ็ั้่็ࠨ㣡"),l1111_l1_ (u"ࠩ฼ี฻࠭㣢"),l1111_l1_ (u"ࠪࡖࡦࡽࠧ㣣"),l1111_l1_ (u"ࠫࡘࡳࡡࡤ࡭ࡇࡳࡼࡴࠧ㣤"),l1111_l1_ (u"ࠬอูๅษ้ࠫ㣥"),l1111_l1_ (u"࠭วอิสลࠬ㣦")]
	for img,l1l1ll111111_l1_,l1l1ll11l1l1_l1_,l1l1ll11l1ll_l1_ in items:
		if type in [l1111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ㣧"),l1111_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㣨")]:
			img,l1l111l_l1_,l1lllll1ll_l1_,title = img,l1l1ll111111_l1_,l1l1ll11l1l1_l1_,l1l1ll11l1ll_l1_
		else: img,title,l1l111l_l1_,l1lllll1ll_l1_ = img,l1l1ll111111_l1_,l1l1ll11l1l1_l1_,l1l1ll11l1ll_l1_
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_)
		l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠩࡂࡺ࡮࡫ࡷ࠾ࡶࡵࡹࡪ࠭㣩"),l1111_l1_ (u"ࠪࠫ㣪"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㣫"),l1111_l1_ (u"ࠬ࠭㣬"),l1l111l_l1_,l1lllll1ll_l1_)
		title = l1l1111_l1_(title)
		#title2 = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭࠭ฮฬ้ัฬࢀอา่ะ้ࠬࠫ㣭"),title,re.DOTALL)
		#if title2: title = title2[0][0]
		if l1111_l1_ (u"ࠧษฮ๋ำฮࠦࠧ㣮") in title or l1111_l1_ (u"ࠨสฯ์ิํࠠࠨ㣯") in title:
			title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㣰") + title.replace(l1111_l1_ (u"ࠪฬั๎ฯสࠢࠪ㣱"),l1111_l1_ (u"ࠫࠬ㣲")).replace(l1111_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ㣳"),l1111_l1_ (u"࠭ࠧ㣴"))
		title = title.strip(l1111_l1_ (u"ࠧࠡࠩ㣵"))
		if l1111_l1_ (u"ࠨษ็ั้่ษࠨ㣶") in title or l1111_l1_ (u"ࠩส่า๊โ่ࠩ㣷") in title:
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡡࡪࠫࠨ㣸"),title,re.DOTALL)
			if l11l11l_l1_:
				title = l1111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㣹") + l11l11l_l1_[0][0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㣺"),menu_name+title,l1l111l_l1_,183,img)
					l1lllll1_l1_.append(title)
		elif any(value in title for value in l11l111ll_l1_):
			l1l111l_l1_ = l1l111l_l1_ + l1111_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ㣻") + l1lllll1ll_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㣼"),menu_name+title,l1l111l_l1_,182,img)
		else:
			l1l111l_l1_ = l1l111l_l1_ + l1111_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ㣽") + l1lllll1ll_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㣾"),menu_name+title,l1l111l_l1_,183,img)
	if type==l1111_l1_ (u"ࠪࠫ㣿"):
		items = re.findall(l1111_l1_ (u"ࠫࡡࡴ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㤀"),html,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠬอไึใะอࠥ࠭㤁"),l1111_l1_ (u"࠭ࠧ㤂"))
			if title!=l1111_l1_ (u"ࠧࠨ㤃"):
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㤄"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨ㤅")+title,l1l111l_l1_,181)
	return
def l1l11ll_l1_(url):
	l1l1lll_l1_ = url.split(l1111_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭㤆"))[0]
	html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠫࠬ㤇"),headers,l1111_l1_ (u"ࠬ࠭㤈"),l1111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㤉"))
	block = re.findall(l1111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵ࡫ࡷࡰࡪࡄ࠮ࠫࡁ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠬࡠ࠶࠭࠺࡟࠮࠭ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㤊"),html,re.DOTALL)
	title,dummy,img = block[0]
	name = re.findall(l1111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡞࠴࠲࠿࡝ࠬࠩ㤋"),title,re.DOTALL)
	if name: name = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㤌") + name[0][0]
	else: name = title
	items = []
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷࡓࡻ࡭ࡣࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㤍"),html,re.DOTALL)
	if l111l1l_l1_:
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㤎"),l1111_l1_ (u"ࠬ࠭㤏"),l1l1lll_l1_,str(l111l1l_l1_))
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㤐"),block,re.DOTALL)
		for l1l111l_l1_ in items:
			l1l111l_l1_ = UNQUOTE(l1l111l_l1_)
			title = re.findall(l1111_l1_ (u"ࠧࠩษ็ั้่ษࡽษ็ั้่็ࠪ࠯ࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ㤑"),l1l111l_l1_.split(l1111_l1_ (u"ࠨ࠱ࠪ㤒"))[-2],re.DOTALL)
			if not title: title = re.findall(l1111_l1_ (u"ࠩࠫ࠭࠲࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ㤓"),l1l111l_l1_.split(l1111_l1_ (u"ࠪ࠳ࠬ㤔"))[-2],re.DOTALL)
			if title: title = l1111_l1_ (u"ࠫࠥ࠭㤕") + title[0][1]
			else: title = l1111_l1_ (u"ࠬ࠭㤖")
			title = name + l1111_l1_ (u"࠭ࠠ࠮ࠢࠪ㤗") + l1111_l1_ (u"ࠧศๆะ่็ฯࠧ㤘") + title
			title = l1l1111_l1_(title)
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㤙"),menu_name+title,l1l111l_l1_,182,img)
	if not items:
		title = l1l1111_l1_(title)
		if l1111_l1_ (u"ࠩหะํีษࠡࠩ㤚") in title or l1111_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ㤛") in title:
			title = l1111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㤜") + title.replace(l1111_l1_ (u"ࠬฮฬ้ัฬࠤࠬ㤝"),l1111_l1_ (u"࠭ࠧ㤞")).replace(l1111_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ㤟"),l1111_l1_ (u"ࠨࠩ㤠"))
		l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㤡"),menu_name+title,url,182,img)
	return
def l1lllll_l1_(url):
	l1l1ll11ll11_l1_ = url.split(l1111_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭㤢"))
	l1l1lll_l1_ = l1l1ll11ll11_l1_[0]
	del l1l1ll11ll11_l1_[0]
	html = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠫࠬ㤣"),headers,l1111_l1_ (u"ࠬ࠭㤤"),l1111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㤥"))
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠧࡧࡱࡱࡸ࠲ࡹࡩࡻࡧ࠽ࠤ࠷࠻ࡰࡹ࠽ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㤦"),html,re.DOTALL)[0]
	if l1l111l_l1_ not in l1l1ll11ll11_l1_: l1l1ll11ll11_l1_.append(l1l111l_l1_)
	l11lll1l_l1_ = []
	# l1l1ll111lll_l1_
	for l1l111l_l1_ in l1l1ll11ll11_l1_:
		if l1111_l1_ (u"ࠨ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ㤧") in l1l111l_l1_:
			l1l1ll111lll_l1_ = l1l111l_l1_
			l11lll1l_l1_.append(l1l1ll111lll_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡐࡥ࡮ࡴࠧ㤨"))
	# l1l1ll111ll1_l1_
	for l1l111l_l1_ in l1l1ll11ll11_l1_:
		if l1111_l1_ (u"ࠪ࠾࠴࠵ࡶࡣ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠭㤩") in l1l111l_l1_:
			html = l111l11_l1_(l111ll_l1_,l1l111l_l1_,l1111_l1_ (u"ࠫࠬ㤪"),headers,l1111_l1_ (u"ࠬ࠭㤫"),l1111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ㤬"))
			html = html.decode(l1111_l1_ (u"ࠧࡸ࡫ࡱࡨࡴࡽࡳ࠮࠳࠵࠹࠻࠭㤭")).encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㤮"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l1l1l1lllll1_l1_><l1l1ll1111ll_l1_ /><l1l1l1lllll1_l1_ align=l1111_l1_ (u"ࠤࡦࡩࡳࡺࡥࡳࠤ㤯")>(\*\*\*\*\*\*\*\*|13721411411.png|)
			html = html.replace(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㤰"),l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㤱"))
			html = html.replace(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㤲"),l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ㤳"))
			html = html.replace(l1111_l1_ (u"ࠧ࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࡀࡧࡸࠠ࠰ࡀ࠿ࡨ࡮ࡼࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢ࠿ࠩ㤴"),l1111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㤵"))
			html = html.replace(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡦࡴࡸࡤࡦࡴࠥࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠬ㤶"),l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㤷"))
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ㤸"),html,re.DOTALL)
			if l111l1l_l1_:
				#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㤹"),l1111_l1_ (u"࠭ࠧ㤺"),url,str(len(l111l1l_l1_)))
				l1l1l1llllll_l1_,l1l1ll111l1l_l1_ = [],[]
				if len(l111l1l_l1_)==1:
					title = l1111_l1_ (u"ࠧࠨ㤻")
					block = html
				else:
					for block in l111l1l_l1_:
						l111ll1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠴ࠪࡀ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࠭ࠫ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ㤼"),block,re.DOTALL)
						if l111ll1l_l1_: block = l1111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ㤽") + l111ll1l_l1_[0][1]
						l111ll1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀ࠾࡫ࡶࠥࡹࡩࡻࡧࡀࠦ࠶ࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࠨࠠ࠰ࡀࠫ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ㤾"),block,re.DOTALL)
						if l111ll1l_l1_: block = l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭㤿") + l111ll1l_l1_[0]
						l111ll1l_l1_ = re.findall(l1111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࠫ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹ࠢࠡ࠱ࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㥀"),block,re.DOTALL)
						if l111ll1l_l1_: block = l111ll1l_l1_[0] + l1111_l1_ (u"࠭ࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㥁")
						l1l1ll11l111_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࠪ࠱࠮ࡄ࠯ࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠭㥂"),block,re.DOTALL)
						title = re.findall(l1111_l1_ (u"ࠨࡀࠣ࠮࠭ࡡ࡞࠽ࡀࡠ࠯࠮ࠦࠪ࠽ࠩ㥃"),l1l1ll11l111_l1_[0][0],re.DOTALL)
						title = l1111_l1_ (u"ࠩࠣࠫ㥄").join(title)
						title = title.strip(l1111_l1_ (u"ࠪࠤࠬ㥅"))
						title = title.replace(l1111_l1_ (u"ࠫࠥࠦࠧ㥆"),l1111_l1_ (u"ࠬࠦࠧ㥇")).replace(l1111_l1_ (u"࠭ࠠࠡࠩ㥈"),l1111_l1_ (u"ࠧࠡࠩ㥉")).replace(l1111_l1_ (u"ࠨࠢࠣࠫ㥊"),l1111_l1_ (u"ࠩࠣࠫ㥋")).replace(l1111_l1_ (u"ࠪࠤࠥ࠭㥌"),l1111_l1_ (u"ࠫࠥ࠭㥍")).replace(l1111_l1_ (u"ࠬࠦࠠࠨ㥎"),l1111_l1_ (u"࠭ࠠࠨ㥏"))
						l1l1l1llllll_l1_.append(title)
					l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧฤะอีࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮ࠺ࠨ㥐"), l1l1l1llllll_l1_)
					if l1l_l1_ == -1 : return
					title = l1l1l1llllll_l1_[l1l_l1_]
					block = l111l1l_l1_[l1l_l1_]
				l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠬࠦࠬ㥑"),block,re.DOTALL)
				l1l1l1llll1l_l1_ = l1l111l_l1_[0]
				l11lll1l_l1_.append(l1l1l1llll1l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡉࡳࡷࡻ࡭ࠨ㥒"))
				block = block.replace(l1111_l1_ (u"ࠪไࠬ㥓"),l1111_l1_ (u"ࠫࠬ㥔"))
				block = block.replace(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ㥕"),l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ㥖"))
				block = block.replace(l1111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡨࡵ࡭࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠹࠶࠽࠴࠲࠴࠴࠻࠺࠸࠹࠷࠰ࡳࡲ࡬ࠨࠧ㥗"),l1111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ㥘"))
				block = block.replace(l1111_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้ะอๆ์็ࠫ㥙"),l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ㥚"))
				block = block.replace(l1111_l1_ (u"ࠫึ๎วษูࠣห้ะอๆ์็ࠫ㥛"),l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ㥜"))
				block = block.replace(l1111_l1_ (u"࠭ำ๋ำไีฬะࠠศๆุ่ฬํฯࠨ㥝"),l1111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ㥞"))
				block = block.replace(l1111_l1_ (u"ࠨำ๋หอ฽ࠠศๆุ่ฬํฯࠨ㥟"),l1111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭㥠"))
				l1l1ll11111l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴ࡢࡤࠬࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ㥡"),block,re.DOTALL)
				for l1l1ll111l11_l1_ in l1l1ll11111l_l1_:
					#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㥢"),l1111_l1_ (u"ࠬ࠭㥣"),l1111_l1_ (u"࠭ࠧ㥤"),str(l1l1ll111l11_l1_))
					type = re.findall(l1111_l1_ (u"ࠧࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࠬ㥥"),l1l1ll111l11_l1_)
					if type:
						if type[0]!=l1111_l1_ (u"ࠨࡤࡲࡸ࡭࠭㥦"): type = l1111_l1_ (u"ࠩࡢࡣࠬ㥧")+type[0]
						else: type = l1111_l1_ (u"ࠪࠫ㥨")
					items = re.findall(l1111_l1_ (u"ࠫ࠭ࡅ࠼ࠢࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴࠯ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿࠳࡫ࡵ࡮ࡵࡀ࠱࠮ࡄࢂ࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾ࡥࡶࠥ࠵࠾࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࠰࠭ࡃ࠮ࠨࠧ㥩"),l1l1ll111l11_l1_,re.DOTALL)
					for l1l1ll1111l1_l1_,l1l111l_l1_ in items:
						title = re.findall(l1111_l1_ (u"ࠬ࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫࠫ࠿ࠫ㥪"),l1l1ll1111l1_l1_)
						title = title[-1]
						l1l111l_l1_ = l1l111l_l1_ + l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㥫") + title + type
						l11lll1l_l1_.append(l1l111l_l1_)
	# l1l1ll11ll1l_l1_
	l11l11_l1_ = l1l1lll_l1_.replace(l1ll11l_l1_,l1ll1111l1_l1_)
	html = l111l11_l1_(l111ll_l1_,l11l11_l1_,l1111_l1_ (u"ࠧࠨ㥬"),headers,l1111_l1_ (u"ࠨࠩ㥭"),l1111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㥮"))
	items = re.findall(l1111_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㥯"),html,re.DOTALL)
	#l1l1llll11_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵ࡥ࡮ࡤࡨࡨࡒ࠳ࠨ࡝ࡹ࠮࠭࠲࠴ࠪࡀ࠰࡫ࡸࡲࡲࠩࠨ㥰"),html,re.DOTALL)
	#if l1l1llll11_l1_:
	if items:
		#l1l1ll11ll1l_l1_ = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ㥱") + l1l1llll11_l1_[-1] + l1111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ㥲")
		l1l1ll11ll1l_l1_ = items[-1]
		l11lll1l_l1_.append(l1l1ll11ll1l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡱࡥ࡭ࡱ࡫ࠧ㥳"))
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㥴"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠩࠪ㥵"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠪࠫ㥶"): return
	search = search.replace(l1111_l1_ (u"ࠫࠥ࠭㥷"),l1111_l1_ (u"ࠬ࠱ࠧ㥸"))
	html = l111l11_l1_(l1111l1_l1_,l1ll11l_l1_,l1111_l1_ (u"࠭ࠧ㥹"),headers,l1111_l1_ (u"ࠧࠨ㥺"),l1111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ㥻"))
	items = re.findall(l1111_l1_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࡁࠫ㥼"),html,re.DOTALL)
	l11l1111l_l1_ = [ l1111_l1_ (u"ࠪࠫ㥽") ]
	l111ll111_l1_ = [ l1111_l1_ (u"ࠫฬ๊ใๅ๋ࠢฬิ๎ๆࠡใ็ฮึ࠭㥾") ]
	for category,title in items:
		l11l1111l_l1_.append(category)
		l111ll111_l1_.append(title)
	if category:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ㥿"), l111ll111_l1_)
		if l1l_l1_ == -1 : return
		category = l11l1111l_l1_[l1l_l1_]
	else: category = l1111_l1_ (u"࠭ࠧ㦀")
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ㦁")+search+l1111_l1_ (u"ࠨࠨࡰࡧࡦࡺ࠽ࠨ㦂")+category
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㦃"),l1111_l1_ (u"ࠪࠫ㦄"),url,url)
	l1l11l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㕄")
menu_name=l1111_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧ㕅")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ㕆"),l1111_l1_ (u"ࠪหุะแิษิฮ่๋้ࠠࠢส่฼๊ศศฬࠪ㕇")]
def l1111ll_l1_(mode,url,text):
	if   mode==450: l11l_l1_ = l11l111_l1_()
	elif mode==451: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==452: l11l_l1_ = l1lllll_l1_(url)
	elif mode==453: l11l_l1_ = l1llll1111_l1_(url)
	elif mode==454: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==459: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ㕈"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭㕉"),l1111_l1_ (u"࠭ࠧ㕊"),l1111_l1_ (u"ࠧࠨ㕋"),l1111_l1_ (u"ࠨࠩ㕌"),l1111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㕍"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1ll11l_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧ㕎"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕏"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㕐"),l1111_l1_ (u"࠭ࠧ㕑"),459,l1111_l1_ (u"ࠧࠨ㕒"),l1111_l1_ (u"ࠨࠩ㕓"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㕔"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕕"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ㕖")+menu_name+l1111_l1_ (u"๋ࠬหษฬสฮ๊่ࠥะ์๊ࠣฯ࠭㕗"),l1llll1lll_l1_,451,l1111_l1_ (u"࠭ࠧ㕘"),l1111_l1_ (u"ࠧࠨ㕙"),l1111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㕚"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕛"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㕜")+menu_name+l1111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ㕝"),l1llll1lll_l1_,451,l1111_l1_ (u"ࠬ࠭㕞"),l1111_l1_ (u"࠭ࠧ㕟"),l1111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ㕠"))
	#l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕡"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭㕢")+menu_name+l1111_l1_ (u"้๊ࠪัไ๋่ࠪ㕣"),l1llll1lll_l1_,451,l1111_l1_ (u"ࠫࠬ㕤"),l1111_l1_ (u"ࠬ࠭㕥"),l1111_l1_ (u"࠭ࡡࡤࡶࡲࡶࡸ࠭㕦"))
	#l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕧"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ㕨")+menu_name+l1111_l1_ (u"่ࠩืู้ไศฬ๋๋ࠣี๊สࠩ㕩"),l1llll1lll_l1_,451,l1111_l1_ (u"ࠪࠫ㕪"),l1111_l1_ (u"ࠫࠬ㕫"),l1111_l1_ (u"ࠬ࠶ࠧ㕬"))
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕭"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ㕮")+menu_name+l1111_l1_ (u"ࠨ็ึุ่๊วห๊๊ࠢิ๐ษࠡ็าฬ้าษࠨ㕯"),l1llll1lll_l1_,451,l1111_l1_ (u"ࠩࠪ㕰"),l1111_l1_ (u"ࠪࠫ㕱"),l1111_l1_ (u"ࠫ࠶࠭㕲"))
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕳"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ㕴")+menu_name+l1111_l1_ (u"ࠧศใ็ห๊ࠦ็็ัํอࠬ㕵"),l1llll1lll_l1_,451,l1111_l1_ (u"ࠨࠩ㕶"),l1111_l1_ (u"ࠩࠪ㕷"),l1111_l1_ (u"ࠪ࠶ࠬ㕸"))
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㕹"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㕺"),l1111_l1_ (u"࠭ࠧ㕻"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡏࡤ࡭ࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࠤࡖ࡭ࡹ࡫ࡓ࡭࡫ࡧࡩࡷࠨࠧ㕼"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㕽"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if l1l111l_l1_==l1111_l1_ (u"ࠩࠦࠫ㕾"): continue
			if title in l11ll11_l1_: continue
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕿"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ㖀")+menu_name+title,l1l111l_l1_,451)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠬ࠭㖁")):
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㖂"),l1111_l1_ (u"ࠧࠨ㖃"),url)
	items = []
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㖄"),url,l1111_l1_ (u"ࠩࠪ㖅"),l1111_l1_ (u"ࠪࠫ㖆"),l1111_l1_ (u"ࠫࠬ㖇"),l1111_l1_ (u"ࠬ࠭㖈"),l1111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ㖉"))
	html = response.content
	if l11111l1l_l1_==l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㖊"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡖ࡭ࡹ࡫ࡓ࡭࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡽࡡࡷࡧࡶࠦࠬ㖋"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	elif l11111l1l_l1_==l1111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㖌"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡗ࡫ࡣࡦࡰࡷࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭㖍"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	elif l1111_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠪ㖎") in html:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷࡩࡽࡺ࠯࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠦࠬ㖏"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࠥࡅࡨࡺ࡯ࡳࡐࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㖐"),block,re.DOTALL)
	elif l11111l1l_l1_ in [l1111_l1_ (u"ࠧ࠱ࠩ㖑"),l1111_l1_ (u"ࠨ࠳ࠪ㖒"),l1111_l1_ (u"ࠩ࠵ࠫ㖓")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡘ࡫ࡣࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄࠧ㖔"),html,re.DOTALL)
		block = l111l1l_l1_[int(l11111l1l_l1_)]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㖕"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	if not items: items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ㖖"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"࠭ๅีษ๊ำฮ࠭㖗"),l1111_l1_ (u"ࠧโ์็้ࠬ㖘"),l1111_l1_ (u"ࠨษ฽๊๏ฯࠧ㖙"),l1111_l1_ (u"ࠩฦ฾๋๐ษࠨ㖚"),l1111_l1_ (u"ࠪ็้๐ศࠨ㖛"),l1111_l1_ (u"ࠫฬ฿ไศ่ࠪ㖜"),l1111_l1_ (u"ࠬํฯศใࠪ㖝"),l1111_l1_ (u"࠭ๅษษิหฮ࠭㖞"),l1111_l1_ (u"ฺࠧำูࠫ㖟"),l1111_l1_ (u"ࠨ็๊ีัอๆࠨ㖠"),l1111_l1_ (u"ࠩส่อ๎ๅࠨ㖡")]
	for l1l111l_l1_,img,title in items:
		if l1111_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ㖢") in html and l1111_l1_ (u"ࠫࡸࡸࡣ࠾ࠩ㖣") in img:
			img = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㖤"),img,re.DOTALL)
			img = img[0]
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"࠭࠯ࠨ㖥"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ㖦"),title,re.DOTALL)
		if not l11l11l_l1_: l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ㖧"),title,re.DOTALL)
		#if any(value in title for value in l1lll1lll1_l1_):
		if set(title.split()) & set(l1lll1lll1_l1_) and l1111_l1_ (u"่ࠩืู้ไࠨ㖨") not in title:
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㖩"),menu_name+title,l1l111l_l1_,452,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠫา๊โสࠩ㖪") in title:
			title = l1111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㖫") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㖬"),menu_name+title,l1l111l_l1_,453,img)
				l1lllll1_l1_.append(title)
		else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖭"),menu_name+title,l1l111l_l1_,453,img)
	if l11111l1l_l1_ in [l1111_l1_ (u"ࠨࠩ㖮"),l1111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㖯")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㖰"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㖱"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				#if l1l111l_l1_==l1111_l1_ (u"ࠧࠨ㖲"): continue
				title = l1l1111_l1_(title)
				#if title!=l1111_l1_ (u"࠭ࠧ㖳"):
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖴"),menu_name+l1111_l1_ (u"ࠨืไัฮࠦࠧ㖵")+title,l1l111l_l1_,451)
	return
def l1llll1111_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭㖶"),url,l1111_l1_ (u"ࠪࠫ㖷"),l1111_l1_ (u"ࠫࠬ㖸"),l1111_l1_ (u"ࠬ࠭㖹"),l1111_l1_ (u"࠭ࠧ㖺"),l1111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㖻"))
	html = response.content
	# l1llll1ll1_l1_
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡗࡺࡨࡌࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㖼"),html,re.DOTALL)
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠨ㖽") in str(l1lll1l1ll_l1_):
		title = re.findall(l1111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠯ࠪ㖾"),html,re.DOTALL)
		title = title[0].strip(l1111_l1_ (u"ࠫࠥ࠭㖿"))
		l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㗀"),menu_name+title,url,454)
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㗁"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗂"),menu_name+title,l1l111l_l1_,454)
	else: l1l11ll_l1_(url)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㗃"),url,l1111_l1_ (u"ࠩࠪ㗄"),l1111_l1_ (u"ࠪࠫ㗅"),l1111_l1_ (u"ࠫࠬ㗆"),l1111_l1_ (u"ࠬ࠭㗇"),l1111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㗈"))
	html = response.content
	# l1llll11_l1_
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㗉"),html,re.DOTALL)
	if l1l11lll1_l1_:
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㗊"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㗋"),menu_name+title,l1l111l_l1_,452,img)
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㗌"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㗍"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				#if l1l111l_l1_==l1111_l1_ (u"ࠧࠨ㗎"): continue
				title = l1l1111_l1_(title)
				#if title!=l1111_l1_ (u"࠭ࠧ㗏"):
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗐"),menu_name+l1111_l1_ (u"ࠨืไัฮࠦࠧ㗑")+title,l1l111l_l1_,454)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url.replace(l1111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ㗒"),l1111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫ㗓"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㗔"),l1111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㗕"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ㗖"),l1l1lll_l1_,l1111_l1_ (u"ࠧࠨ㗗"),l1111_l1_ (u"ࠨࠩ㗘"),l1111_l1_ (u"ࠩࠪ㗙"),l1111_l1_ (u"ࠪࠫ㗚"),l1111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㗛"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ㗜"))
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡚ࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡹࡩࡥࡧࡁࠫ㗝"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ㗞"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㗟")+title+l1111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ㗠")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫࠥࡷࡪࡲࡡࡳࡻࠥࠫ㗡"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㗢"),block,re.DOTALL)
		for l1l111l_l1_,name in items:
			name = l1l1111_l1_(name)
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭㗣"),name,re.DOTALL)
			if l11l1111_l1_:
				l11l1111_l1_ = l1111_l1_ (u"࠭࡟ࡠࡡࡢࠫ㗤")+l11l1111_l1_[0]
				name = l1111_l1_ (u"ࠧࠨ㗥")
			else: l11l1111_l1_ = l1111_l1_ (u"ࠨࠩ㗦")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㗧")+name+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㗨")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ㗩"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㗪"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"࠭ࠧ㗫"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠧࠨ㗬"): return
	search = search.replace(l1111_l1_ (u"ࠨࠢࠪ㗭"),l1111_l1_ (u"ࠩ࠮ࠫ㗮"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ㗯")+search
	l1l11l1_l1_(url)
	return
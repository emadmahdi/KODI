# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
import bs4
l111_l1_=l1111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩẙ")
menu_name=l1111_l1_ (u"ࠨࡡࡈࡐࡈࡥࠧẚ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = []
def l1111ll_l1_(mode,url,text):
	if   mode==510: l11l_l1_ = l11l111_l1_(url)
	elif mode==511: l11l_l1_ = l1lllll11ll_l1_(url)
	elif mode==512: l11l_l1_ = l1111l1ll1_l1_(url)
	elif mode==513: l11l_l1_ = l1111l1l1l_l1_(url)
	elif mode==514: l11l_l1_ = l1lllll1l11_l1_(url,l1111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨẛ")+text)
	elif mode==515: l11l_l1_ = l1lllll1l11_l1_(url,l1111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩẜ")+text)
	elif mode==516: l11l_l1_ = l111111l1l_l1_(text)
	elif mode==517: l11l_l1_ = l11111lll1_l1_(url)
	elif mode==518: l11l_l1_ = l11111llll_l1_(url)
	elif mode==519: l11l_l1_ = l1lll1_l1_(text)
	elif mode==520: l11l_l1_ = l11111l111_l1_(url)
	elif mode==521: l11l_l1_ = l1lllll11l1_l1_(url)
	elif mode==522: l11l_l1_ = l1lllll_l1_(url)
	elif mode==523: l11l_l1_ = l1llllll111_l1_(text)
	elif mode==524: l11l_l1_ = l1llllll1l1_l1_()
	elif mode==525: l11l_l1_ = l1111l1l11_l1_()
	elif mode==526: l11l_l1_ = l111111lll_l1_()
	elif mode==527: l11l_l1_ = l1llllll1ll_l1_()
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠫࠬẝ")):
	if not l1l1lll1_l1_:
		l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẞ"),menu_name+l1111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ẟ"),l1111_l1_ (u"ࠧࠨẠ"),519)
		l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ạ"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫẢ"),l1111_l1_ (u"ࠪࠫả"),9999)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẤ"),menu_name+l1111_l1_ (u"๋่ࠬิ๊฼อࠥอไฤ฻่ห้࠭ấ"),l1111_l1_ (u"࠭ࠧẦ"),525)
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧầ"),menu_name+l1111_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็วูิวึࠩẨ"),l1111_l1_ (u"ࠩࠪẩ"),526)
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẪ"),menu_name+l1111_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊ๅึ่ไหฯ࠭ẫ"),l1111_l1_ (u"ࠬ࠭Ậ"),527)
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ậ"),menu_name+l1111_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆ่๊ํ฿วหࠩẮ"),l1111_l1_ (u"ࠨࠩắ"),524)
	return
def l1llllll1l1_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩẰ"),menu_name+l1111_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦ࠭ࠡะสูฮ࠭ằ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࠫẲ"),520)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẳ"),menu_name+l1111_l1_ (u"࠭แ๋ัํ์์อสࠡ࠯ࠣวาีหࠨẴ"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯࡭ࡣࡷࡩࡸࡺࠧẵ"),521)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẶ"),menu_name+l1111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรใั่ࠫặ"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡳࡱࡪࡥࡴࡶࠪẸ"),521)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẹ"),menu_name+l1111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦ็ะืࠠๆึส๋ิฯࠧẺ"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࡶࡪࡧࡺࡷࠬẻ"),521)
	return
def l1111l1l11_l1_():
	l1111_l1_ (u"ࠢࠣࠤࠐࠎࠎࡺࡹࡱࡧࠣࡁࠥ࠷ࠠࠤࠢࡤࡧࡹࡵࡲࡴࠏࠍࠍࡹࡿࡰࡦࠢࡀࠤ࠷ࠦࠣࠡࡸ࡬ࡨࡪࡵࡳࠎࠌࠌࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠ࠲ࠢࠦࠤࡲࡵࡶࡪࡧࡶࠑࠏࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࠷ࠥࠩࠠࡴࡧࡵ࡭ࡪࡹࠍࠋࠋࡩࡳࡷ࡫ࡩࡨࡰࠣࡁࠥ࡬ࡡ࡭ࡵࡨࠤࠨࠦࡡࡳࡣࡥ࡭ࡨࠓࠊࠊࡨࡲࡶࡪ࡯ࡧ࡯ࠢࡀࠤࡹࡸࡵࡦࠢࠦࠤࡪࡴࡧ࡭࡫ࡶ࡬ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊ࠥษแๅษ่ࠤ฾ืศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠳࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡ฻ิฬ๏࠭ࠬ࡭࡫ࡱ࡯࠸࠲࠵࠲࠳ࠬࠑࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮๊๋ࠫหๅ์้ࠤศ็ไศ็ࠣหั์ศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠵࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡษฯ๊อ๐ࠧ࠭࡮࡬ࡲࡰ࠻ࠬ࠶࠳࠴࠭ࠒࠐࠉ࡭࡫ࡱ࡯࠶ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠸ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠹ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠺ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠺ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏࠢࠣࠤẼ")
	l1lllll1l1l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪẽ")
	l11111111l_l1_ = l1lllll1l1l_l1_+l1111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬẾ")
	l1111l11ll_l1_ = l1lllll1l1l_l1_+l1111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭ế")
	l1lllllll11_l1_ = l1lllll1l1l_l1_+l1111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭Ề")
	l1lllllll1l_l1_ = l1lllll1l1l_l1_+l1111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧề")
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ể"),menu_name+l1111_l1_ (u"ࠧๆื้ๅฬะࠠฤใ็หู๊ࠦาสํࠫể"),l11111111l_l1_,511)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨỄ"),menu_name+l1111_l1_ (u"ู่๋ࠩ็วห่ࠢืู้ไศฬࠣ฽ึฮ๊ࠨễ"),l1111l11ll_l1_,511)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỆ"),menu_name+l1111_l1_ (u"๊ࠫ฻ๆโษอࠤศ็ไศ็ࠣหั์ศ๋ࠩệ"),l1lllllll11_l1_,511)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỈ"),menu_name+l1111_l1_ (u"࠭ๅึ่ไหฯࠦๅิๆึ่ฬะࠠศฮ้ฬ๏࠭ỉ"),l1lllllll1l_l1_,511)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬỊ"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪị"),l1111_l1_ (u"ࠩࠪỌ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪọ"),menu_name+l1111_l1_ (u"ࠫๆํัิࠢฦ฽๊อไࠡลหะิ๐ࠧỎ"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬỏ"),517)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ố"),menu_name+l1111_l1_ (u"ࠧโ้ิืࠥࠦศๅัࠣห้หๆหษฯࠫố"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡣࡰࡷࡱࡸࡷࡿࠧỒ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩồ"),menu_name+l1111_l1_ (u"ࠪๅ์ืำࠡษ็่฿ฯࠧỔ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫổ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỖ"),menu_name+l1111_l1_ (u"࠭แ่ำึࠤ๊฻ๆโษอࠤฬู๊ๆๆࠪỗ"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴࡭ࡥ࡯ࡴࡨࠫỘ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨộ"),menu_name+l1111_l1_ (u"ࠩไ๋ึูࠠิ่ฬࠤฬ๊ลึัสีࠬỚ"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡴࡨࡰࡪࡧࡳࡦࡡࡼࡩࡦࡸࠧớ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩỜ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧờ"),l1111_l1_ (u"࠭ࠧỞ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧở"),menu_name+l1111_l1_ (u"ࠨ็๋หุ๋ࠠ࠮ࠢไ่ฯืࠠๆฯาำࠬỠ"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭ỡ"),515)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỢ"),menu_name+l1111_l1_ (u"๊ࠫ๎วิ็ࠣ࠱ࠥ็ไหำࠣ็ฬ๋ไࠨợ"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡧ࡬ࡴࠩỤ"),514)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫụ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠶ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠳࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỦ"),l1111_l1_ (u"ࠨࠩủ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩỨ"),menu_name+l1111_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨứ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬỪ"),515)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬừ"),menu_name+l1111_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫỬ"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨử"),514)
	return
def l1llllll1ll_l1_():
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬỮ"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪữ"),l1111_l1_ (u"ࠪࠫỰ"),l1111_l1_ (u"ࠫࠬự"),l1111_l1_ (u"ࠬ࠭Ỳ"),l1111_l1_ (u"࠭ࠧỳ"),l1111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫỴ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭ỵ"),multi_valued_attributes=None)
	block = l1lllll111l_l1_.find(l1111_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵࠩỶ"),attrs={l1111_l1_ (u"ࠪࡲࡦࡳࡥࠨỷ"):l1111_l1_ (u"ࠫࡹࡧࡧࠨỸ")})	# <select name=l1111_l1_ (u"ࠬࡺࡡࡨࠩỹ")>
	options = block.find_all(l1111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳ࠭Ỻ"))
	for option in options:
		value = option.get(l1111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭ỻ"))		# or option[l1111_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧỼ")] l11l1l11ll_l1_ it will fail if not l1l11llll_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧỽ"))
			value = value.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨỾ"))
		l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸ࠬࡴࡺࡲࡨࡁࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨỿ")+value
		title = title.replace(l1111_l1_ (u"่ࠬวว็ฬࠤࠬἀ"),l1111_l1_ (u"࠭ࠧἁ"))
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἂ"),menu_name+title,l1l111l_l1_,511)
	return
def l111111lll_l1_():
	l1lllll1l1l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪἃ")
	l111111111_l1_ = l1lllll1l1l_l1_+l1111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭ἄ")
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἅ"),menu_name+l1111_l1_ (u"๊ࠫ฻ๆโษอࠤศฺฮศืࠪἆ"),l111111111_l1_,511)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪἇ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨἈ"),l1111_l1_ (u"ࠧࠨἉ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨἊ"),menu_name+l1111_l1_ (u"ࠩไ๋ึูࠠฤึัหฺࠦรษฮา๎ࠬἋ"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬἌ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἍ"),menu_name+l1111_l1_ (u"ࠬ็็าี้ࠣํ฽ๆࠨἎ"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵࡮ࡢࡶ࡬ࡳࡳࡧ࡬ࡪࡶࡼࠫἏ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἐ"),menu_name+l1111_l1_ (u"ࠨใ๊ีุࠦࠠหษิ๎ำࠦวๅ็ํ่ฬีࠧἑ"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡥ࡭ࡷࡺࡨࡠࡻࡨࡥࡷ࠭ἒ"),517)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἓ"),menu_name+l1111_l1_ (u"ࠫๆํัิࠢࠣฮฬื๊ฯࠢส่ํ็วสࠩἔ"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡪࡥࡢࡶ࡫ࡣࡾ࡫ࡡࡳࠩἕ"),517)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ἖"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠲࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ἗"),l1111_l1_ (u"ࠨࠩἘ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩἙ"),menu_name+l1111_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨἚ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬἛ"),515)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἜ"),menu_name+l1111_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫἝ"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ἞"),514)
	return
def l1lllll11ll_l1_(url):
	if l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ἟") in url: index = 0
	elif l1111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪἠ") in url: index = 1
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧἡ"),url,l1111_l1_ (u"ࠫࠬἢ"),l1111_l1_ (u"ࠬ࠭ἣ"),l1111_l1_ (u"࠭ࠧἤ"),l1111_l1_ (u"ࠧࠨἥ"),l1111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭ἦ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧἧ"),multi_valued_attributes=None)
	l1lll11_l1_ = l1lllll111l_l1_.find_all(class_=l1111_l1_ (u"ࠪ࡮ࡺࡳࡢࡰ࠯ࡷ࡬ࡪࡧࡴࡦࡴࠣࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠬἨ"))
	for block in l1lll11_l1_:
		title = block.find_all(l1111_l1_ (u"ࠫࡦ࠭Ἡ"))[index].text
		l1l111l_l1_ = l1ll11l_l1_+block.find_all(l1111_l1_ (u"ࠬࡧࠧἪ"))[index].get(l1111_l1_ (u"࠭ࡨࡳࡧࡩࠫἫ"))
		if kodi_version<19:
			title = title.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬἬ"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ἥ"))
		if not l1lll11_l1_:
			l1111l1ll1_l1_(l1l111l_l1_)
			return
		else:
			title = title.replace(l1111_l1_ (u"ࠩๅหห๋ษࠡࠩἮ"),l1111_l1_ (u"ࠪࠫἯ"))
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἰ"),menu_name+title,l1l111l_l1_,512)
	l1lllll1lll_l1_(l1lllll111l_l1_,511)
	return
def l1lllll1lll_l1_(l1lllll111l_l1_,mode):
	block = l1lllll111l_l1_.find(class_=l1111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩἱ"))
	if block:
		l1l1l1ll1_l1_ = block.find_all(l1111_l1_ (u"࠭ࡡࠨἲ"))
		l1lllll1111_l1_ = block.find_all(l1111_l1_ (u"ࠧ࡭࡫ࠪἳ"))
		l111111ll1_l1_ = list(zip(l1l1l1ll1_l1_,l1lllll1111_l1_))
		ii = -1
		length = len(l111111ll1_l1_)
		for l1ll111ll_l1_,l1lllll1ll1_l1_ in l111111ll1_l1_:
			ii += 1
			l1lllll1ll1_l1_ = l1lllll1ll1_l1_[l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧἴ")]
			if l1111_l1_ (u"ࠩࡸࡲࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠧἵ") in l1lllll1ll1_l1_ or l1111_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࠫἶ") in l1lllll1ll1_l1_: continue
			name2 = l1ll111ll_l1_.text
			l1lllll1ll_l1_ = l1ll11l_l1_+l1ll111ll_l1_.get(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩἷ"))
			if kodi_version<19:
				name2 = name2.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪἸ"))
				l1lllll1ll_l1_ = l1lllll1ll_l1_.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫἹ"))
			if   ii==0: name2 = l1111_l1_ (u"ࠧฤ๊็ํࠬἺ")
			elif ii==1: name2 = l1111_l1_ (u"ࠨีสฬ็ฯࠧἻ")
			elif ii==length-2: name2 = l1111_l1_ (u"ࠩ็หา่ษࠨἼ")
			elif ii==length-1: name2 = l1111_l1_ (u"ࠪวำ๐ัสࠩἽ")
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἾ"),menu_name+l1111_l1_ (u"ࠬ฻แฮหࠣࠫἿ")+name2,l1lllll1ll_l1_,mode)
	return
def l1111l1ll1_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪὀ"),url,l1111_l1_ (u"ࠧࠨὁ"),l1111_l1_ (u"ࠨࠩὂ"),l1111_l1_ (u"ࠩࠪὃ"),l1111_l1_ (u"ࠪࠫὄ"),l1111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠷࠭࠲ࡵࡷࠫὅ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ὆"),multi_valued_attributes=None)
	l1lll11_l1_ = l1lllll111l_l1_.find_all(class_=l1111_l1_ (u"࠭ࡲࡰࡹࠪ὇"))
	items,first = [],True
	for block in l1lll11_l1_:
		if not block.find(class_=l1111_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫὈ")): continue
		if first: first = False ; continue
		l11111ll1l_l1_ = []
		l1llll1llll_l1_ = block.find_all(class_=[l1111_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡸࡥࡥࠩὉ"),l1111_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡰࡶࡴࡳࡰࡪ࠭Ὂ")])
		for l1llllll11l_l1_ in l1llll1llll_l1_:
			l1ll1ll1l1_l1_ = l1llllll11l_l1_.find_all(l1111_l1_ (u"ࠪࡰ࡮࠭Ὃ"))[1].text
			if kodi_version<19:
				l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩὌ"))
			l11111ll1l_l1_.append(l1ll1ll1l1_l1_)
		if not l1l1ll_l1_(l111_l1_,l1111_l1_ (u"ࠬ࠭Ὅ"),l11111ll1l_l1_,False):
			image = block.find(l1111_l1_ (u"࠭ࡩ࡮ࡩࠪ὎")).get(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ὏"))
			title = block.find(l1111_l1_ (u"ࠨࡪ࠶ࠫὐ"))
			name = title.find(l1111_l1_ (u"ࠩࡤࠫὑ")).text
			l1l111l_l1_ = l1ll11l_l1_+title.find(l1111_l1_ (u"ࠪࡥࠬὒ")).get(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩὓ"))
			l1llllllll1_l1_ = block.find(class_=l1111_l1_ (u"ࠬࡴ࡯࠮࡯ࡤࡶ࡬࡯࡮ࠨὔ"))
			l1lllllllll_l1_ = block.find(class_=l1111_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭ὕ"))
			if l1llllllll1_l1_: l1llllllll1_l1_ = l1llllllll1_l1_.text
			if l1lllllllll_l1_: l1lllllllll_l1_ = l1lllllllll_l1_.text
			if kodi_version<19:
				image = image.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬὖ"))
				name = name.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ὗ"))
				l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ὘"))
				if l1llllllll1_l1_: l1llllllll1_l1_ = l1llllllll1_l1_.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨὙ"))
			infodict = {}
			if l1lllllllll_l1_: infodict[l1111_l1_ (u"ࠫࡸࡺࡡࡳࡵࠪ὚")] = l1lllllllll_l1_
			if l1llllllll1_l1_:
				l1llllllll1_l1_ = l1llllllll1_l1_.replace(l1111_l1_ (u"ࠬࡢ࡮ࠨὛ"),l1111_l1_ (u"࠭ࠠ࠯࠰ࠣࠫ὜"))
				infodict[l1111_l1_ (u"ࠧࡱ࡮ࡲࡸࠬὝ")] = l1llllllll1_l1_.replace(l1111_l1_ (u"ࠨ࠰࠱࠲ฬ่ัฤࠢสุ่๊๊ะࠩ὞"),l1111_l1_ (u"ࠩࠪὟ"))
			if l1111_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪὠ") in l1l111l_l1_:
				#name = l1111_l1_ (u"ࠫอำหࠡ฻้ࠤࠬὡ")+name
				l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὢ"),menu_name+name,l1l111l_l1_,516,image,l1111_l1_ (u"࠭ࠧὣ"),name,l1111_l1_ (u"ࠧࠨὤ"),infodict)
			elif l1111_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪὥ") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩὦ"),menu_name+name,l1l111l_l1_,513,image,l1111_l1_ (u"ࠪࠫὧ"),name,l1111_l1_ (u"ࠫࠬὨ"),infodict)
	l1lllll1lll_l1_(l1lllll111l_l1_,512)
	return
def l1111l1l1l_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩὩ"),url,l1111_l1_ (u"࠭ࠧὪ"),l1111_l1_ (u"ࠧࠨὫ"),l1111_l1_ (u"ࠨࠩὬ"),l1111_l1_ (u"ࠩࠪὭ"),l1111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠷࠳࠱ࡴࡶࠪὮ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩὯ"),multi_valued_attributes=None)
	l1lll11_l1_ = l1lllll111l_l1_.find_all(l1111_l1_ (u"ࠬࡲࡩࠨὰ"))
	names,items = [],[]
	for block in l1lll11_l1_:
		if not block.find(class_=l1111_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪά")): continue
		if not block.find(class_=[l1111_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠩὲ"),l1111_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠣࡸࡪࡾࡴ࠮ࡥࡨࡲࡹ࡫ࡲࠨέ")]): continue
		if block.find(class_=l1111_l1_ (u"ࠩ࡫࡭ࡩ࡫ࠧὴ")): continue
		title = block.find(class_=[l1111_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠬή"),l1111_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩࠦࡴࡦࡺࡷ࠱ࡨ࡫࡮ࡵࡧࡵࠫὶ")])
		name = title.find(l1111_l1_ (u"ࠬࡧࠧί")).text
		if name in names: continue
		names.append(name)
		l1l111l_l1_ = l1ll11l_l1_+title.find(l1111_l1_ (u"࠭ࡡࠨὸ")).get(l1111_l1_ (u"ࠧࡩࡴࡨࡪࠬό"))
		if l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨὺ") in url: image = block.find(l1111_l1_ (u"ࠩ࡬ࡱ࡬࠭ύ")).get(l1111_l1_ (u"ࠪࡷࡷࡩࠧὼ"))
		elif l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭ώ") in url: image = block.find(l1111_l1_ (u"ࠬ࡯࡭ࡨࠩ὾")).get(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ὿"))
		elif l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨᾀ") in url: image = block.find(l1111_l1_ (u"ࠨ࡫ࡰ࡫ࠬᾁ")).get(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫᾂ"))
		else: image = block.find(l1111_l1_ (u"ࠪ࡭ࡲ࡭ࠧᾃ")).get(l1111_l1_ (u"ࠫࡸࡸࡣࠨᾄ"))
		if kodi_version<19:
			name = name.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᾅ"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᾆ"))
			image = image.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᾇ"))
		name = name.strip(l1111_l1_ (u"ࠨࠢࠪᾈ"))
		items.append((name,l1l111l_l1_,image))
	if l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫᾉ") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1l111l_l1_,image in items:
		if l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡻ࡯ࡤࡦࡱ࠲ࠫᾊ") in url: l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᾋ"),menu_name+name,l1l111l_l1_,522,image)
		elif l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧᾌ") in url: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾍ"),menu_name+name,l1l111l_l1_,513,image,l1111_l1_ (u"ࠧࠨᾎ"),name)
		else: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᾏ"),menu_name+name,l1l111l_l1_,516,image,l1111_l1_ (u"ࠩࠪᾐ"),name)
	return
def l111111l1l_l1_(text):
	text = text.replace(l1111_l1_ (u"ࠪห้หูๅษ้ࠫᾑ"),l1111_l1_ (u"ࠫࠬᾒ")).replace(l1111_l1_ (u"๊ࠬแ๋ๆ่ࠫᾓ"),l1111_l1_ (u"࠭ࠧᾔ")).replace(l1111_l1_ (u"ࠧศๆิื๊๐ࠧᾕ"),l1111_l1_ (u"ࠨࠩᾖ"))
	text = text.replace(l1111_l1_ (u"ࠩศ฽้อๆࠨᾗ"),l1111_l1_ (u"ࠪࠫᾘ")).replace(l1111_l1_ (u"ࠫๆ๐ไๆࠩᾙ"),l1111_l1_ (u"ࠬ࠭ᾚ")).replace(l1111_l1_ (u"࠭วๅสิ์๊๎ࠧᾛ"),l1111_l1_ (u"ࠧࠨᾜ"))
	text = text.replace(l1111_l1_ (u"ࠨษ็ฮู๎๊ใ์ࠪᾝ"),l1111_l1_ (u"ࠩࠪᾞ")).replace(l1111_l1_ (u"ู่๊ࠪไิๆࠪᾟ"),l1111_l1_ (u"ࠫࠬᾠ")).replace(l1111_l1_ (u"๋ࠬำๅี็ࠫᾡ"),l1111_l1_ (u"࠭ࠧᾢ"))
	text = text.replace(l1111_l1_ (u"ࠧ࠻ࠩᾣ"),l1111_l1_ (u"ࠨࠩᾤ")).replace(l1111_l1_ (u"ࠩࠬࠫᾥ"),l1111_l1_ (u"ࠪࠫᾦ")).replace(l1111_l1_ (u"ࠫ࠭࠭ᾧ"),l1111_l1_ (u"ࠬ࠭ᾨ")).replace(l1111_l1_ (u"࠭ࠬࠨᾩ"),l1111_l1_ (u"ࠧࠨᾪ"))
	text = text.replace(l1111_l1_ (u"ࠨࡡࠪᾫ"),l1111_l1_ (u"ࠩࠪᾬ")).replace(l1111_l1_ (u"ࠪ࠿ࠬᾭ"),l1111_l1_ (u"ࠫࠬᾮ")).replace(l1111_l1_ (u"ࠬ࠳ࠧᾯ"),l1111_l1_ (u"࠭ࠧᾰ")).replace(l1111_l1_ (u"ࠧ࠯ࠩᾱ"),l1111_l1_ (u"ࠨࠩᾲ"))
	text = text.replace(l1111_l1_ (u"ࠩ࡟ࠫࠬᾳ"),l1111_l1_ (u"ࠪࠫᾴ")).replace(l1111_l1_ (u"ࠫࡡࠨࠧ᾵"),l1111_l1_ (u"ࠬ࠭ᾶ"))
	text = text.replace(l1111_l1_ (u"࠭ࠠࠡࠢࠣࠫᾷ"),l1111_l1_ (u"ࠧࠡࠩᾸ")).replace(l1111_l1_ (u"ࠨࠢࠣࠤࠬᾹ"),l1111_l1_ (u"ࠩࠣࠫᾺ")).replace(l1111_l1_ (u"ࠪࠤࠥ࠭Ά"),l1111_l1_ (u"ࠫࠥ࠭ᾼ"))
	text = text.strip(l1111_l1_ (u"ࠬࠦࠧ᾽"))
	l1111l1111_l1_ = text.count(l1111_l1_ (u"࠭ࠠࠨι"))+1
	if l1111l1111_l1_==1:
		l1llllll111_l1_(text)
		return
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᾿"),menu_name+l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๅๆหัะࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ῀"),l1111_l1_ (u"ࠩࠪ῁"),9999)
	l1111111ll_l1_ = text.split(l1111_l1_ (u"ࠪࠤࠬῂ"))
	l1111l11l1_l1_ = pow(2,l1111l1111_l1_)
	l11111l1l1_l1_ = []
	def l1111111l1_l1_(a,b):
		if a==l1111_l1_ (u"ࠫ࠶࠭ῃ"): return b
		return l1111_l1_ (u"ࠬ࠭ῄ")
	for ii in range(l1111l11l1_l1_,0,-1):
		l11111l11l_l1_ = list(l1111l1111_l1_*l1111_l1_ (u"࠭࠰ࠨ῅")+bin(ii)[2:])[-l1111l1111_l1_:]
		l11111l11l_l1_ = reversed(l11111l11l_l1_)
		result = map(l1111111l1_l1_,l11111l11l_l1_,l1111111ll_l1_)
		title = l1111_l1_ (u"ࠧࠡࠩῆ").join(filter(None,result))
		if kodi_version<19: title2 = title.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ῇ"))
		else: title2 = title
		if len(title2)>2 and title not in l11111l1l1_l1_:
			l11111l1l1_l1_.append(title)
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩῈ"),menu_name+title,l1111_l1_ (u"ࠪࠫΈ"),523,l1111_l1_ (u"ࠫࠬῊ"),l1111_l1_ (u"ࠬ࠭Ή"),title)
	return
def l1llllll111_l1_(l1111l111l_l1_):
	import l11111ll11_l1_
	l1111l111l_l1_ = l11ll_l1_(default=l1111l111l_l1_)
	l11111ll11_l1_.l1lll1_l1_(l1111l111l_l1_)
	return
def l11111lll1_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪῌ"),url,l1111_l1_ (u"ࠧࠨ῍"),l1111_l1_ (u"ࠨࠩ῎"),l1111_l1_ (u"ࠩࠪ῏"),l1111_l1_ (u"ࠪࠫῐ"),l1111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪῑ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪῒ"),multi_valued_attributes=None)
	block = l1lllll111l_l1_.find(class_=l1111_l1_ (u"࠭࡬ࡪࡵࡷ࠱ࡸ࡫ࡰࡢࡴࡤࡸࡴࡸࠠ࡭࡫ࡶࡸ࠲ࡺࡩࡵ࡮ࡨࠫΐ"))
	l11l11l11_l1_ = block.find_all(l1111_l1_ (u"ࠧࡢࠩ῔"))
	items = []
	for title in l11l11l11_l1_:
		name = title.text
		l1l111l_l1_ = l1ll11l_l1_+title.get(l1111_l1_ (u"ࠨࡪࡵࡩ࡫࠭῕"))
		if kodi_version<19:
			name = name.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧῖ"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨῗ"))
		if l1111_l1_ (u"ࠫࠨ࠭Ῐ") not in l1l111l_l1_: items.append((name,l1l111l_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1l111l_l1_ = item
		l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬῙ"),menu_name+name,l1l111l_l1_,518)
	return
def l11111llll_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪῚ"),url,l1111_l1_ (u"ࠧࠨΊ"),l1111_l1_ (u"ࠨࠩ῜"),l1111_l1_ (u"ࠩࠪ῝"),l1111_l1_ (u"ࠪࠫ῞"),l1111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ῟"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪῠ"),multi_valued_attributes=None)
	l1lll11_l1_ = l1lllll111l_l1_.find(class_=l1111_l1_ (u"࠭ࡥࡹࡲࡤࡲࡩ࠭ῡ")).find_all(l1111_l1_ (u"ࠧࡵࡴࠪῢ"))
	for block in l1lll11_l1_:
		l111111l11_l1_ = block.find_all(l1111_l1_ (u"ࠨࡣࠪΰ"))
		if not l111111l11_l1_: continue
		image = block.find(l1111_l1_ (u"ࠩ࡬ࡱ࡬࠭ῤ")).get(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬῥ"))
		name = l111111l11_l1_[1].text
		l1l111l_l1_ = l1ll11l_l1_+l111111l11_l1_[1].get(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩῦ"))
		l1lllllllll_l1_ = block.find(class_=l1111_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬῧ"))
		if l1lllllllll_l1_: l1lllllllll_l1_ = l1lllllllll_l1_.text
		if kodi_version<19:
			name = name.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫῨ"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬῩ"))
			image = image.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ὺ"))
		infodict = {}
		if l1lllllllll_l1_: infodict[l1111_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨΎ")] = l1lllllllll_l1_
		if l1111_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪῬ") in l1l111l_l1_:
			#name = l1111_l1_ (u"ࠫอำหࠡ฻้ࠤࠬ῭")+name
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ΅"),menu_name+name,l1l111l_l1_,516,image,l1111_l1_ (u"࠭ࠧ`"),name,l1111_l1_ (u"ࠧࠨ῰"),infodict)
		elif l1111_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ῱") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩῲ"),menu_name+name,l1l111l_l1_,513,image,l1111_l1_ (u"ࠪࠫῳ"),name,l1111_l1_ (u"ࠫࠬῴ"),infodict)
	l1lllll1lll_l1_(l1lllll111l_l1_,518)
	return
def l11111l111_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ῵"),url,l1111_l1_ (u"࠭ࠧῶ"),l1111_l1_ (u"ࠧࠨῷ"),l1111_l1_ (u"ࠨࠩῸ"),l1111_l1_ (u"ࠩࠪΌ"),l1111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡜ࡉࡅࡇࡒࡗࡤࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨῺ"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩΏ"),multi_valued_attributes=None)
	l11l11l11_l1_ = l1lllll111l_l1_.find_all(class_=l1111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡴࡪࡶ࡯ࡩࠥ࡯࡮࡭࡫ࡱࡩࠬῼ"))
	l11l1ll1_l1_ = l1lllll111l_l1_.find_all(class_=l1111_l1_ (u"࠭ࡢࡶࡶࡷࡳࡳࠦࡧࡳࡧࡨࡲࠥࡹ࡭ࡢ࡮࡯ࠤࡷ࡯ࡧࡩࡶࠪ´"))
	items = zip(l11l11l11_l1_,l11l1ll1_l1_)
	for title,l1l111l_l1_ in items:
		title = title.text
		l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_.get(l1111_l1_ (u"ࠧࡩࡴࡨࡪࠬ῾"))
		if kodi_version<19:
			title = title.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭῿"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ "))
		title = title.replace(l1111_l1_ (u"ࠪࠤࠥࠦࠠࠨ "),l1111_l1_ (u"ࠫࠥ࠭ ")).replace(l1111_l1_ (u"ࠬࠦࠠࠡࠩ "),l1111_l1_ (u"࠭ࠠࠨ ")).replace(l1111_l1_ (u"ࠧࠡࠢࠪ "),l1111_l1_ (u"ࠨࠢࠪ "))
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ "),menu_name+title,l1l111l_l1_,521)
	return
def l1lllll11l1_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ "),url,l1111_l1_ (u"ࠫࠬ "),l1111_l1_ (u"ࠬ࠭ "),l1111_l1_ (u"࠭ࠧ​"),l1111_l1_ (u"ࠧࠨ‌"),l1111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ‍"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ‎"),multi_valued_attributes=None)
	l1111l1lll_l1_ = l1lllll111l_l1_.find(class_=l1111_l1_ (u"ࠪࡰࡦࡸࡧࡦ࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡ࡯ࡨࡨ࡮ࡻ࡭࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠺ࠠࡴ࡯ࡤࡰࡱ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠶ࠬ‏"))
	l1lll11_l1_ = l1111l1lll_l1_.find_all(l1111_l1_ (u"ࠫࡱ࡯ࠧ‐"))
	for block in l1lll11_l1_:
		title = block.find(class_=l1111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ‑")).text
		l1l111l_l1_ = l1ll11l_l1_+block.find(l1111_l1_ (u"࠭ࡡࠨ‒")).get(l1111_l1_ (u"ࠧࡩࡴࡨࡪࠬ–"))
		image = block.find(l1111_l1_ (u"ࠨ࡫ࡰ࡫ࠬ—")).get(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ―"))
		duration = block.find(class_=l1111_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ‖")).text
		if kodi_version<19:
			title = title.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ‗"))
			l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ‘"))
			image = image.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ’"))
			duration = duration.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ‚"))
		duration = duration.replace(l1111_l1_ (u"ࠨ࡞ࡱࠫ‛"),l1111_l1_ (u"ࠩࠪ“")).strip(l1111_l1_ (u"ࠪࠤࠬ”"))
		l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ„"),menu_name+title,l1l111l_l1_,522,image,duration)
	l1lllll1lll_l1_(l1lllll111l_l1_,521)
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ‟"),url,l1111_l1_ (u"࠭ࠧ†"),l1111_l1_ (u"ࠧࠨ‡"),l1111_l1_ (u"ࠨࠩ•"),l1111_l1_ (u"ࠩࠪ‣"),l1111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ․"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ‥"),multi_valued_attributes=None)
	l1l111l_l1_ = l1lllll111l_l1_.find(class_=l1111_l1_ (u"ࠬ࡬࡬ࡦࡺ࠰ࡺ࡮ࡪࡥࡰࠩ…")).find(l1111_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪ࠭‧")).get(l1111_l1_ (u"ࠧࡴࡴࡦࠫ "))
	if kodi_version<19: l1l111l_l1_ = l1l111l_l1_.encode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ "))
	l1ll11ll1_l1_(l1l111l_l1_,l111_l1_,l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ‪"))
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫ‫"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬ‬"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧ‭"),l1111_l1_ (u"࠭ࠥ࠳࠲ࠪ‮"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡁࡴࡁࠬ ")+search
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ‰"),url,l1111_l1_ (u"ࠩࠪ‱"),l1111_l1_ (u"ࠪࠫ′"),l1111_l1_ (u"ࠫࠬ″"),l1111_l1_ (u"ࠬ࠭‴"),l1111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ‵"))
	html = response.content
	l1lllll111l_l1_ = bs4.BeautifulSoup(html,l1111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ‶"),multi_valued_attributes=None)
	l1lll11_l1_ = l1lllll111l_l1_.find_all(class_=l1111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡮ࡨࡪࡹ࠭‷"))
	for block in l1lll11_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ‸"))
		title = title.split(l1111_l1_ (u"ࠪࠬࠬ‹"),1)[0].strip(l1111_l1_ (u"ࠫࠥ࠭›"))
		if   l1111_l1_ (u"ࠬษูๆษ็ࠫ※") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ‼"),l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ‽"))
		elif l1111_l1_ (u"ࠨลืาฬ฻ࠧ‾") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ‿"),l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⁀"))
		#elif l1111_l1_ (u"ࠫศำฯศอࠪ⁁") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⁂"),l1111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡦࡸࡨࡲࡹ࠵ࠧ⁃"))
		#elif l1111_l1_ (u"ࠧๆ้ิะฬ์วหࠩ⁄") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⁅"),l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡪࡪࡹࡴࡪࡸࡤࡰ࠴࠭⁆"))
		elif l1111_l1_ (u"ࠪๅ๏ี๊้้สฮࠬ⁇") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⁈"),l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⁉"))
		#elif l1111_l1_ (u"࠭รฯสสีࠬ⁊") in title: l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⁋"),l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡷࡳࡵ࡯ࡣ࠰ࠩ⁌"))
		else: continue
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⁍"),menu_name+title,l1l111l_l1_,513)
	return
# ===========================================
#     l11111l11_l1_ l1llll1l1l_l1_ l1llll11ll_l1_
# ===========================================
def l1lllll1l11_l1_(url,text):
	global l1l1l11l_l1_,l1ll1lll_l1_
	if l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ⁎") in url:
		l1l1l11l_l1_ = [l1111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⁏"),l1111_l1_ (u"ࠬࡿࡥࡢࡴࠪ⁐"),l1111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⁑")]
		l1ll1lll_l1_ = [l1111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ⁒"),l1111_l1_ (u"ࠨࡻࡨࡥࡷ࠭⁓"),l1111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⁔")]
	elif l1111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ⁕") in url:
		l1l1l11l_l1_ = [l1111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⁖"),l1111_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭⁗"),l1111_l1_ (u"࠭ࡴࡺࡲࡨࠫ⁘")]
		l1ll1lll_l1_ = [l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⁙"),l1111_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⁚"),l1111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⁛")]
	l1llllll_l1_(url,text)
	return
def l111111ll_l1_(url):
	url = url.split(l1111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⁜"))[0]
	#l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨ⁝"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ⁞"),url,l1111_l1_ (u"࠭ࠧ "),l1111_l1_ (u"ࠧࠨ⁠"),l1111_l1_ (u"ࠨࠩ⁡"),l1111_l1_ (u"ࠩࠪ⁢"),l1111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ⁣"))
	html = response.content
	# all l1lll11_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࠢࡤࡧࡹ࡯࡯࡯࠿ࠥ࠳࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ⁤"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	# name + category + options block
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹࠦ࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⁥"),block,re.DOTALL)
	return l111111_l1_
def l1lllll111_l1_(block):
	# value + name
	items = re.findall(l1111_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⁦"),block,re.DOTALL)
	return items
def l11111111_l1_(url):
	#url = url.replace(l1111_l1_ (u"ࠧࡤࡣࡷࡁࠬ⁧"),l1111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⁨"))
	l1lllll1l1_l1_ = url.split(l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⁩"))[0]
	l1lllll11l_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧ⁪"))
	#url = url.replace(l1lllll1l1_l1_,l1lllll11l_l1_)
	url = url.replace(l1111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⁫"),l1111_l1_ (u"ࠬ࠵࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࠩ⁬"))
	return url
def l11l1l1l11_l1_(l1ll11l1_l1_,url):
	l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⁭")) # l111llll11_l1_ be l11l1111l1_l1_
	l11l11_l1_ = url+l1111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⁮")+l1l111l1_l1_
	l11l11_l1_ = l11111111_l1_(l11l11_l1_)
	return l11l11_l1_
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⁯"),l1111_l1_ (u"ࠩࠪ⁰"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫⁱ"),l1111_l1_ (u"ࠫࠬ⁲"),filter,url)
	if l1111_l1_ (u"ࠬࡅࠧ⁳") in url: url = url.split(l1111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⁴"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠧࡠࡡࡢࠫ⁵"),1)
	if filter==l1111_l1_ (u"ࠨࠩ⁶"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠩࠪ⁷"),l1111_l1_ (u"ࠪࠫ⁸")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ⁹"))
	if type==l1111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⁺"):
		if l1l1l11l_l1_[0]+l1111_l1_ (u"࠭࠽ࠨ⁻") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠧ࠾ࠩ⁼") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠪ⁽")+category+l1111_l1_ (u"ࠩࡀ࠴ࠬ⁾")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠬⁿ")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧ₀")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠬࠬࠧ₁"))+l1111_l1_ (u"࠭࡟ࡠࡡࠪ₂")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩ₃"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ₄")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭₅")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭₆"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭₇")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠬ࠭₈"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ₉")) # l111lll11l_l1_ l11l1ll1l1_l1_ not change
		if l1l11ll1_l1_==l1111_l1_ (u"ࠧࠨ₊"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ₋")+l1l11ll1_l1_
		l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₌"),menu_name+l1111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭₍"),l1l1lll_l1_,511)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ₎"),menu_name+l1111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ₏")+l11lll11_l1_+l1111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬₐ"),l1l1lll_l1_,511)
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬₑ"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨₒ"),l1111_l1_ (u"ࠩࠪₓ"),9999)
	l111111_l1_ = l111111ll_l1_(url)
	dict = {}
	for name,l1lll1ll_l1_,block in l111111_l1_:
		name = name.replace(l1111_l1_ (u"ࠪ࠱࠲࠭ₔ"),l1111_l1_ (u"ࠫࠬₕ"))
		items = l1lllll111_l1_(block)
		if l1111_l1_ (u"ࠬࡃࠧₖ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩₗ"):
			if l1lll1ll_l1_ not in l1l1l11l_l1_: continue
			if category!=l1lll1ll_l1_: continue
			elif len(items)<2:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]:
					url = l11111111_l1_(url)
					l1111l1ll1_l1_(url)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ₘ")+l1l1l1ll_l1_)
				return
			else:
				l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨₙ"),menu_name+l1111_l1_ (u"ࠩส่ัฺ๋๊ࠩₚ"),l1l1lll_l1_,511)
				else: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪₛ"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫₜ"),l1l1lll_l1_,515,l1111_l1_ (u"ࠬ࠭₝"),l1111_l1_ (u"࠭ࠧ₞"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ₟"):
			if l1lll1ll_l1_ not in l1ll1lll_l1_: continue
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠪ₠")+l1lll1ll_l1_+l1111_l1_ (u"ࠩࡀ࠴ࠬ₡")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠬ₢")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠶ࠧ₣")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ₤")+l1ll11l1_l1_
			if   name==l1111_l1_ (u"࠭ࡴࡺࡲࡨࠫ₥"): name = l1111_l1_ (u"ࠧศๆ้์฾࠭₦")
			elif name==l1111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ₧"): name = l1111_l1_ (u"ࠩส่฾๋ไࠨ₨")
			elif name==l1111_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ₩"): name = l1111_l1_ (u"ࠫฬ๊ไ฻หࠪ₪")
			elif name==l1111_l1_ (u"ࠬࡿࡥࡢࡴࠪ₫"): name = l1111_l1_ (u"࠭วๅี้อࠬ€")
			elif name==l1111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ₭"): name = l1111_l1_ (u"ࠨษ็้ํูๅࠨ₮")
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₯"),menu_name+l1111_l1_ (u"ࠪห้าๅ๋฻࠽ࠤࠬ₰")+name,l1l1lll_l1_,514,l1111_l1_ (u"ࠫࠬ₱"),l1111_l1_ (u"ࠬ࠭₲"),l1l1l1ll_l1_)		# +l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ₳"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if option in l11ll11_l1_: continue
			if l1111_l1_ (u"ࠧๆื้ๅฬะࠠฤะิํࠬ₴") in option: continue
			if l1111_l1_ (u"ࠨษ็็้࠭₵") in option: continue
			if l1111_l1_ (u"ࠩส่้เษࠨ₶") in option: continue
			option = option.replace(l1111_l1_ (u"ࠪๆฬฬๅสࠢࠪ₷"),l1111_l1_ (u"ࠫࠬ₸"))
			if   name==l1111_l1_ (u"ࠬࡺࡹࡱࡧࠪ₹"): name = l1111_l1_ (u"࠭วๅ่๋฽ࠬ₺")
			elif name==l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ₻"): name = l1111_l1_ (u"ࠨษ็฽๊๊ࠧ₼")
			elif name==l1111_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ₽"): name = l1111_l1_ (u"ࠪหฺ้๊สࠩ₾")
			elif name==l1111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ₿"): name = l1111_l1_ (u"ࠬอไิ่ฬࠫ⃀")
			elif name==l1111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⃁"): name = l1111_l1_ (u"ࠧศๆ่์ุ๋ࠧ⃂")
			#if l1111_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ⃃") not in value: value = option
			#else: value = re.findall(l1111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ⃄"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠬ⃅")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂ࠭⃆")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠧ⃇")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽ࠨ⃈")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ⃉")+l1ll11l1_l1_
			if name: title = option+l1111_l1_ (u"ࠨࠢ࠽ࠫ⃊")+name
			else: title = option   #+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠩ࠳ࠫ⃋")]
			if type==l1111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⃌"): l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃍"),menu_name+title,url,514,l1111_l1_ (u"ࠬ࠭⃎"),l1111_l1_ (u"࠭ࠧ⃏"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⃐"))
			elif type==l1111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⃑") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠩࡀ⃒ࠫ") in l1l11lll_l1_:
				l11l11_l1_ = l11l1l1l11_l1_(l1ll11l1_l1_,url)
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ⃓ࠪ"),menu_name+title,l11l11_l1_,511)
			else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃔"),menu_name+title,url,515,l1111_l1_ (u"ࠬ࠭⃕"),l1111_l1_ (u"࠭ࠧ⃖"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⃗"),l1111_l1_ (u"ࠨ⃘ࠩ"),filters,l1111_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳⃙ࠪ"))
	# mode==l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷ⃚ࠬ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⃛")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⃜")			all l1l1llll_l1_ & l111111l1_l1_ filters
	filters = filters.replace(l1111_l1_ (u"࠭࠽ࠧࠩ⃝"),l1111_l1_ (u"ࠧ࠾࠲ࠩࠫ⃞"))
	filters = filters.strip(l1111_l1_ (u"ࠨࠨࠪ⃟"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠩࡀࠫ⃠") in filters:
		items = filters.split(l1111_l1_ (u"ࠪࠪࠬ⃡"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠫࡂ࠭⃢"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠬ࠭⃣")
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"࠭࠰ࠨ⃤")
		if l1111_l1_ (u"⃥ࠧࠦࠩ") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵ⃦ࠪ") and value!=l1111_l1_ (u"ࠩ࠳ࠫ⃧"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠪࠤ࠰⃨ࠦࠧ")+value
		elif mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⃩") and value!=l1111_l1_ (u"ࠬ࠶⃪ࠧ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠦࠨ⃫")+key+l1111_l1_ (u"ࠧ࠾⃬ࠩ")+value
		elif mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ⃭࠭"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"⃮ࠩࠩࠫ")+key+l1111_l1_ (u"ࠪࡁ⃯ࠬ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠫࠥ࠱ࠠࠨ⃰"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠬࠬࠧ⃱"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"࠭࠽࠱ࠩ⃲"),l1111_l1_ (u"ࠧ࠾ࠩ⃳"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⃴"),l1111_l1_ (u"ࠩࠪ⃵"),filters,l1111_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫ⃶"))
	return l1lll11l_l1_
l1l1l11l_l1_ = []
l1ll1lll_l1_ = []
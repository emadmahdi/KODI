# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
#
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕࠪ㱩")
menu_name=l1111_l1_ (u"ࠪࡣࡑ࡙ࡔࡠࠩ㱪")
l1l1l1l1ll1l_l1_ = 5
l1l1l1l111ll_l1_ = 10
def l1111ll_l1_(mode,url,text,page):
	if   mode==160: l11l_l1_ = l11l111_l1_()
	elif mode==161: l11l_l1_ = l1l1l1lll1l1_l1_(text)
	elif mode==162: l11l_l1_ = l1l1l11l1lll_l1_(text,162)
	elif mode==163: l11l_l1_ = l1l1l11l1lll_l1_(text,163)
	elif mode==164: l11l_l1_ = l1l1l1ll11l1_l1_(text)
	elif mode==165: l11l_l1_ = l1l1l1l1ll11_l1_(text,page)
	elif mode==166: l11l_l1_ = l1l1l111ll11_l1_(url,text)
	elif mode==167: l11l_l1_ = l1l1l111lll1_l1_(url,text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㱫"),l1111_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭㱬"),l1111_l1_ (u"࠭ࠧ㱭"),161,l1111_l1_ (u"ࠧࠨ㱮"),l1111_l1_ (u"ࠨࠩ㱯"),l1111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㱰"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㱱"),l1111_l1_ (u"ࠫ็ูๅࠡ฻ื์ฬฬ๊ࠨ㱲"),l1111_l1_ (u"ࠬ࠭㱳"),162,l1111_l1_ (u"࠭ࠧ㱴"),l1111_l1_ (u"ࠧࠨ㱵"),l1111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㱶"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㱷"),l1111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭㱸"),l1111_l1_ (u"ࠫࠬ㱹"),163,l1111_l1_ (u"ࠬ࠭㱺"),l1111_l1_ (u"࠭ࠧ㱻"),l1111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㱼"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱽"),l1111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ㱾"),l1111_l1_ (u"ࠪࠫ㱿"),164,l1111_l1_ (u"ࠫࠬ㲀"),l1111_l1_ (u"ࠬ࠭㲁"),l1111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㲂"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲃"),l1111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ㲄"),l1111_l1_ (u"ࠩࠪ㲅"),165,l1111_l1_ (u"ࠪࠫ㲆"),l1111_l1_ (u"ࠫࠬ㲇"),l1111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ㲈"))
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㲉"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㲊"),l1111_l1_ (u"ࠨࠩ㲋"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲌"),l1111_l1_ (u"ࠪๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ㲍"),l1111_l1_ (u"ࠫࠬ㲎"),163,l1111_l1_ (u"ࠬ࠭㲏"),l1111_l1_ (u"࠭ࠧ㲐"),l1111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㲑"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲒"),l1111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ㲓"),l1111_l1_ (u"ࠪࠫ㲔"),163,l1111_l1_ (u"ࠫࠬ㲕"),l1111_l1_ (u"ࠬ࠭㲖"),l1111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㲗"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲘"),l1111_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ㲙"),l1111_l1_ (u"ࠩࠪ㲚"),162,l1111_l1_ (u"ࠪࠫ㲛"),l1111_l1_ (u"ࠫࠬ㲜"),l1111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㲝"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲞"),l1111_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ㲟"),l1111_l1_ (u"ࠨࠩ㲠"),162,l1111_l1_ (u"ࠩࠪ㲡"),l1111_l1_ (u"ࠪࠫ㲢"),l1111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㲣"))
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲤"),l1111_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘ࡛ࠦศฮอࠣ฽ู๎วว์ࠪ㲥"),l1111_l1_ (u"ࠧࠨ㲦"),164,l1111_l1_ (u"ࠨࠩ㲧"),l1111_l1_ (u"ࠩࠪ㲨"),l1111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㲩"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲪"),l1111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭㲫"),l1111_l1_ (u"࠭ࠧ㲬"),165,l1111_l1_ (u"ࠧࠨ㲭"),l1111_l1_ (u"ࠨࠩ㲮"),l1111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㲯"))
	return
def l1l1l1lll1l1_l1_(options):
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲰"),l1111_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ㲱"),l1111_l1_ (u"ࠬ࠭㲲"),161,l1111_l1_ (u"࠭ࠧ㲳"),l1111_l1_ (u"ࠧࠨ㲴"),l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ㲵"))
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲶"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㲷"),l1111_l1_ (u"ࠫࠬ㲸"),9999)
	l1ll1l1ll111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲹"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢ࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㲺")+l1111_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㲻"),l1111_l1_ (u"ࠨࠩ㲼"),147)
	#l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲽"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㲾")+l1111_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㲿"),l1111_l1_ (u"ࠬ࠭㳀"),148)
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳁"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㳂")+l1111_l1_ (u"ࠨไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠪ㳃"),l1111_l1_ (u"ࠩࠪ㳄"),28)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㳅"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㳆")+l1111_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ㳇"),l1111_l1_ (u"࠭ࠧ㳈"),41)
	#l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㳉"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㳊")+l1111_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ㳋"),l1111_l1_ (u"ࠪࠫ㳌"),135)
	import l1lllll11111_l1_
	l1lllll11111_l1_.l1ll1lll11_l1_(l1111_l1_ (u"ࠫ࠵࠭㳍"),False)
	l1lllll11111_l1_.l1ll1lll11_l1_(l1111_l1_ (u"ࠬ࠷ࠧ㳎"),False)
	l1lllll11111_l1_.l1ll1lll11_l1_(l1111_l1_ (u"࠭࠲ࠨ㳏"),False)
	#l1lllll11111_l1_.l1ll1lll11_l1_(l1111_l1_ (u"ࠧ࠴ࠩ㳐"),False)
	if l1111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ㳑") in options:
		menuItemsLIST[:] = l1l1l11ll1l1_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l1l1ll1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l1l1ll1l_l1_)
	menuItemsLIST[:] = l1ll1l1ll111_l1_+menuItemsLIST
	return
def l1l1l1ll11l1_l1_(options):
	options = options.replace(l1111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㳒"),l1111_l1_ (u"ࠪࠫ㳓")).replace(l1111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㳔"),l1111_l1_ (u"ࠬ࠭㳕"))
	headers = { l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㳖") : l1111_l1_ (u"ࠧࠨ㳗") }
	url = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ㳘")
	payload = { l1111_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ㳙") : l1111_l1_ (u"ࠪ࠹࠵࠭㳚") }
	data = l1ll1l1l1_l1_(payload)
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㳛"),l1111_l1_ (u"ࠬ࠭㳜"),l1111_l1_ (u"࠭ࠧ㳝"),str(data))
	response = l1l11l_l1_(l1lll11ll1l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ㳞"),url,data,headers,l1111_l1_ (u"ࠨࠩ㳟"),l1111_l1_ (u"ࠩࠪ㳠"),l1111_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖ࠱ࡘࡋࡁࡓࡅࡋࡣࡗࡇࡎࡅࡑࡐࡣ࡛ࡏࡄࡆࡑࡖ࠱࠶ࡹࡴࠨ㳡"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭㳢"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㳣"),block,re.DOTALL)
	l1l1l11111l1_l1_,l1l1l111ll1l_l1_ = list(zip(*items))
	l1l1l1ll1l11_l1_ = []
	l1l1l1lll111_l1_ = [l1111_l1_ (u"࠭ࠠࠨ㳤"),l1111_l1_ (u"ࠧࠣࠩ㳥"),l1111_l1_ (u"ࠨࡢࠪ㳦"),l1111_l1_ (u"ࠩ࠯ࠫ㳧"),l1111_l1_ (u"ࠪ࠲ࠬ㳨"),l1111_l1_ (u"ࠫ࠿࠭㳩"),l1111_l1_ (u"ࠬࡁࠧ㳪"),l1111_l1_ (u"ࠨࠧࠣ㳫"),l1111_l1_ (u"ࠧ࠮ࠩ㳬")]
	l1l1l1l1l1l1_l1_ = l1l1l111ll1l_l1_+l1l1l11111l1_l1_
	for word in l1l1l1l1l1l1_l1_:
		if word in l1l1l111ll1l_l1_: l1l1l1l11l1l_l1_ = 2
		if word in l1l1l11111l1_l1_: l1l1l1l11l1l_l1_ = 4
		l1l1l1ll1l1l_l1_ = [i in word for i in l1l1l1lll111_l1_]
		if any(l1l1l1ll1l1l_l1_):
			index = l1l1l1ll1l1l_l1_.index(True)
			l1l1l11l1111_l1_ = l1l1l1lll111_l1_[index]
			l1l1l1l1llll_l1_ = l1111_l1_ (u"ࠨࠩ㳭")
			if word.count(l1l1l11l1111_l1_)>1: l1l1l1ll1111_l1_,l1l1l1l1lll1_l1_,l1l1l1l1llll_l1_ = word.split(l1l1l11l1111_l1_,2)
			else: l1l1l1ll1111_l1_,l1l1l1l1lll1_l1_ = word.split(l1l1l11l1111_l1_,1)
			if len(l1l1l1ll1111_l1_)>l1l1l1l11l1l_l1_: l1l1l1ll1l11_l1_.append(l1l1l1ll1111_l1_.lower())
			if len(l1l1l1l1lll1_l1_)>l1l1l1l11l1l_l1_: l1l1l1ll1l11_l1_.append(l1l1l1l1lll1_l1_.lower())
			if len(l1l1l1l1llll_l1_)>l1l1l1l11l1l_l1_: l1l1l1ll1l11_l1_.append(l1l1l1l1llll_l1_.lower())
		elif len(word)>l1l1l1l11l1l_l1_: l1l1l1ll1l11_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1l1ll1l11_l1_)
	#l1l_l1_ = l11llll_l1_(str(len(l1l1l1ll1l11_l1_)),l1l1l1ll1l11_l1_)
	l1111_l1_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ㳮")
	if l1111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ㳯") in options:
		l1l1l11llll1_l1_ = l1ll1ll1ll11_l1_
	elif l1111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ㳰") in options:
		l1l1l11llll1_l1_ = [l1111_l1_ (u"ࠬࡏࡐࡕࡘࠪ㳱")]
		import l1l1l1111l1_l1_
		if not l1l1l1111l1_l1_.isIPTVFiles(True): return
	count,l1l1l11111ll_l1_ = 0,0
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳲"),l1111_l1_ (u"ࠧศๆหัะูࠦ็ࠢ࠽ࠤࡠࠦࠠ࡞ࠩ㳳"),l1111_l1_ (u"ࠨࠩ㳴"),164,l1111_l1_ (u"ࠩࠪ㳵"),l1111_l1_ (u"ࠪࠫ㳶"),l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㳷")+options)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳸"),l1111_l1_ (u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭㳹"),l1111_l1_ (u"ࠧࠨ㳺"),164,l1111_l1_ (u"ࠨࠩ㳻"),l1111_l1_ (u"ࠩࠪ㳼"),l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㳽")+options)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㳾"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㳿"),l1111_l1_ (u"࠭ࠧ㴀"),9999)
	l1l1l111111l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l1ll1lll_l1_ = []
	for word in l1l1l1ll1l11_l1_:
		l1l1l1l1lll1_l1_ = re.findall(l1111_l1_ (u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆ࡜ࠤ࡞ࠧࡠࠪࡢ࡞࡝ࠨ࡟࠮ࡡࡥ࡜࠽࡞ࡁࡡࠬ㴁"),word,re.DOTALL)
		if l1l1l1l1lll1_l1_: word = word.split(l1l1l1l1lll1_l1_[0],1)[0]
		l1l1l1l1l11l_l1_ = word.replace(l1111_l1_ (u"ࠨ๓ࠪ㴂"),l1111_l1_ (u"ࠩࠪ㴃")).replace(l1111_l1_ (u"ࠪ๒ࠬ㴄"),l1111_l1_ (u"ࠫࠬ㴅")).replace(l1111_l1_ (u"ࠬ๑ࠧ㴆"),l1111_l1_ (u"࠭ࠧ㴇")).replace(l1111_l1_ (u"ࠧ๐ࠩ㴈"),l1111_l1_ (u"ࠨࠩ㴉")).replace(l1111_l1_ (u"ࠩ๏ࠫ㴊"),l1111_l1_ (u"ࠪࠫ㴋"))
		l1l1l1l1l11l_l1_ = l1l1l1l1l11l_l1_.replace(l1111_l1_ (u"ࠫ๕࠭㴌"),l1111_l1_ (u"ࠬ࠭㴍")).replace(l1111_l1_ (u"࠭ํࠨ㴎"),l1111_l1_ (u"ࠧࠨ㴏")).replace(l1111_l1_ (u"ࠨ๔ࠪ㴐"),l1111_l1_ (u"ࠩࠪ㴑")).replace(l1111_l1_ (u"ࠪฐࠬ㴒"),l1111_l1_ (u"ࠫࠬ㴓")).replace(l1111_l1_ (u"ࠬๆࠧ㴔"),l1111_l1_ (u"࠭ࠧ㴕"))
		l1l1l1ll1lll_l1_.append(l1l1l1l1l11l_l1_)
	for i in range(0,20):
		text = random.sample(l1l1l1ll1lll_l1_,1)[0]
		site = random.sample(l1l1l11llll1_l1_,1)[0]
		LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㴖"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡧࡲࡤࡪࠣࠤࠥࡹࡩࡵࡧ࠽ࠫ㴗")+str(site)+l1111_l1_ (u"ࠩࠣࠤࡹ࡫ࡸࡵ࠼ࠪ㴘")+text)
		#l11l_l1_ = l1ll1l1ll1ll_l1_(l1111_l1_ (u"ࠪࠫ㴙"),l1111_l1_ (u"ࠫࠬ㴚"),l1111_l1_ (u"ࠬ࠭㴛"),site,l1111_l1_ (u"࠭ࠧ㴜"),l1111_l1_ (u"ࠧࠨ㴝"),text+l1111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㴞"),l1111_l1_ (u"ࠩࠪ㴟"),l1111_l1_ (u"ࠪࠫ㴠"))
		l1ll1l11111_l1_,l1ll1l1l11l_l1_,l1lll111l11_l1_ = l1ll11ll1ll_l1_(site)
		l1ll1l1l11l_l1_(text+l1111_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ㴡"))
		if len(menuItemsLIST)>0: break
	#text = text.replace(l1111_l1_ (u"ࠬࡥࠧ㴢"),l1111_l1_ (u"࠭ࠧ㴣"))
	l1l1l111111l_l1_[0][1] = l1111_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㴤")+text[:-2]+l1111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้ฮอฬࠢ฼๊ࠥࡀࠠ࡜ࠢࠪ㴥")
	menuItemsLIST[:] = l1l1l11ll1l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l1l1ll1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l1l1ll1l_l1_)
	menuItemsLIST[:] = l1l1l111111l_l1_+menuItemsLIST
	#import l11111ll11_l1_
	#l11111ll11_l1_.l1lll1_l1_(search)
	return
def l1l1l1ll1ll1_l1_(site):
	l1ll1l11111_l1_,l1ll1l1l11l_l1_,l1lll111l11_l1_ = l1ll11ll1ll_l1_(site)
	try:
		if l1111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㴦") in site: l1ll1l11111_l1_(site)
		else: l1ll1l11111_l1_()
		l1l1l1l111l1_l1_ = False
	except: l1l1l1l111l1_l1_ = True
	if l1l1l1l111l1_l1_: l1ll111_l1_(site,l1111_l1_ (u"ࠪๅู๊ࠠษ้ำหࠥอไๆ๊ๅ฽ࠬ㴧"),time=2000)
	else: l1ll111_l1_(site,l1111_l1_ (u"ࠫฯ๋ࠠอๆหࠤฬ๊รใีส้ࠬ㴨"),time=2000)
	return l1l1l1l111l1_l1_
def l1l1l1111lll_l1_(l1l1l1l11l11_l1_=True):
	if not l1l1l1l11l11_l1_:
		global l1ll11l11l11_l1_
		l11l_l1_ = READ_FROM_SQL3(cache_dbfile,l1111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㴩"),l1111_l1_ (u"࠭ࡍࡊࡕࡆࠫ㴪"),l1111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ㴫"))
		if l11l_l1_:
			l1ll11l11l11_l1_ = l11l_l1_
			return
	l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㴬"),l1111_l1_ (u"ࠩࠪ㴭"),l1111_l1_ (u"ࠪࠫ㴮"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㴯"),l1111_l1_ (u"๊ࠬใ๋ࠢอ้้ฬ่ࠠา๊ࠤฬ๊โศศ่อࠥ࠴ࠠศๆหี๋อๅอࠢํัฯอฬࠡล้ࠤ๏็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎ࠠศๆอ๎ࠥ็๊ࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠีอาึาࠠๆ่๊หࠥ็โุࠢส่ศ่ำศ็ࠣห้ืฦ๋ีํอࠥ࠴ࠠฬ็ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬำุๆ้ࠡำ๋ࠥอไฤไึห๊ࠦอห๋่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่่หํวࠡ็ิอࠥษฮา๋ࠣ࠲ࠥ฿ๅๅ์ฬࠤ๊๊ฦࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠหฯอหัูࠦศัฬࠤศ่ไࠡ็้ࠤ࠸ࠦฯใษษๆࠥ࠴่ࠠๆࠣฮึ๐ฯࠡล้ࠤฯาๅฺࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩ㴰"))
	if l1l1l1l111_l1_!=1: return
	l1l1l111l11l_l1_ = menuItemsLIST[:]
	l1l1l11lll1l_l1_,l1l1l11ll1ll_l1_ = 0,l1111_l1_ (u"࠭ࠧ㴱")
	for site in l11ll1ll11l_l1_:
		l1l1l1l111l1_l1_ = l1l1l1ll1ll1_l1_(site)
		if l1l1l1l111l1_l1_:
			l1l1l11lll1l_l1_ += 1
			l1l1l11ll1ll_l1_ += l1111_l1_ (u"ࠧࠡࠩ㴲")+site
			if l1l1l11lll1l_l1_>=l1l1l1l111ll_l1_: break
	menuItemsLIST[:] = l1l1l111l11l_l1_
	if l1l1l11lll1l_l1_>=l1l1l1l111ll_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ㴳"),l1111_l1_ (u"ࠩࠪ㴴"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㴵"),l1111_l1_ (u"้ࠫี๊ไุ่่๊ࠢษࠡใํࠤࠬ㴶")+str(l1l1l11lll1l_l1_)+l1111_l1_ (u"ࠬࠦๅ้ษๅ฽๋ࠥๆࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢ࠱࠲࠳่ࠦิสห๋ฬࠦโะࠢํ็ํ์ฺࠠั่ࠤํา่ะࠢศ๊ฯืๆ๋ฬࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋࠼ࠪ㴷")+l1l1l11ll1ll_l1_)
	else:
		l1ll11lllll_l1_(cache_dbfile,l1111_l1_ (u"࠭ࡍࡊࡕࡆࠫ㴸"),l1111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ㴹"),l1ll11l11l11_l1_,l1l1llll11l_l1_)
		l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ㴺"),l1111_l1_ (u"ࠩࠪ㴻"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㴼"),l1111_l1_ (u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪ㴽"))
	return
def l1l1l11l1l1l_l1_(options):
	if l1111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ㴾") not in options:
		l11l_l1_ = READ_FROM_SQL3(cache_dbfile,l1111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㴿"),l1111_l1_ (u"ࠧࡎࡋࡖࡇࠬ㵀"),l1111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ㵁"))
		if l11l_l1_: menuItemsLIST[:] = l11l_l1_ ; return
	message = l1111_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ㵂")
	import l1l1l1111l1_l1_
	if l1l1l1111l1_l1_.isIPTVFiles(True):
		if l1111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㵃") in options and l1111_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ㵄") not in options:
			try: l1l1l1111l1_l1_.l1l111l11ll_l1_(l1111_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㵅"),l1111_l1_ (u"࠭ࠧ㵆"),l1111_l1_ (u"ࠧࠨ㵇"),options+l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㵈"))
			except: l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㵉"),l1111_l1_ (u"ࠪࠫ㵊"),l1111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ㵋"),message)
			try: l1l1l1111l1_l1_.l1l111l11ll_l1_(l1111_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㵌"),l1111_l1_ (u"࠭ࠧ㵍"),l1111_l1_ (u"ࠧࠨ㵎"),options+l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㵏"))
			except: l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㵐"),l1111_l1_ (u"ࠪࠫ㵑"),l1111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ㵒"),message)
			try: l1l1l1111l1_l1_.l1l111l11ll_l1_(l1111_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㵓"),l1111_l1_ (u"࠭ࠧ㵔"),l1111_l1_ (u"ࠧࠨ㵕"),options+l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㵖"))
			except: l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ㵗"),l1111_l1_ (u"ࠪࠫ㵘"),l1111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ㵙"),message)
		if l1111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㵚") in options and l1111_l1_ (u"࠭࡟ࡗࡑࡇࡣࠬ㵛") not in options:
			try: l1l1l1111l1_l1_.l1l111l11ll_l1_(l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㵜"),l1111_l1_ (u"ࠨࠩ㵝"),l1111_l1_ (u"ࠩࠪ㵞"),options+l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㵟"))
			except: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㵠"),l1111_l1_ (u"ࠬ࠭㵡"),l1111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫ㵢"),message)
			try: l1l1l1111l1_l1_.l1l111l11ll_l1_(l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㵣"),l1111_l1_ (u"ࠨࠩ㵤"),l1111_l1_ (u"ࠩࠪ㵥"),options+l1111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㵦"))
			except: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㵧"),l1111_l1_ (u"ࠬ࠭㵨"),l1111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫ㵩"),message)
	l1ll11lllll_l1_(cache_dbfile,l1111_l1_ (u"ࠧࡎࡋࡖࡇࠬ㵪"),l1111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ㵫"),menuItemsLIST,l1l1llll11l_l1_)
	return
def l1l1l1l1ll11_l1_(options,l1l1l11lllll_l1_):
	if l1111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ㵬") in options:
		if l1111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ㵭") in options and l1l1l11lllll_l1_==l1111_l1_ (u"ࠫࠬ㵮"): l1l1l1111lll_l1_(True)
		elif l1l1l11lllll_l1_: l1l1l1111lll_l1_(False)
		#if l1ll11l11l11_l1_=={}: return
	l1l1l1l1111l_l1_ = options.replace(l1111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ㵯"),l1111_l1_ (u"࠭ࠧ㵰")).replace(l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㵱"),l1111_l1_ (u"ࠨࠩ㵲")).replace(l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㵳"),l1111_l1_ (u"ࠪࠫ㵴"))
	if not l1l1l11lllll_l1_:
		l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㵵"),l1111_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ㵶"),l1111_l1_ (u"࠭ࠧ㵷"),165,l1111_l1_ (u"ࠧࠨ㵸"),l1111_l1_ (u"ࠨࠩ㵹"),l1111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ㵺")+l1l1l1l1111l_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㵻"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㵼"),l1111_l1_ (u"ࠬ࠭㵽"),9999)
	if l1111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ㵾") in options:
		l1ll1l11ll_l1_ = [l1111_l1_ (u"ࠧฤใ็ห๊࠭㵿"),l1111_l1_ (u"ࠨ็ึุ่๊วหࠩ㶀"),l1111_l1_ (u"่ࠩืึำ๊ศฬࠪ㶁"),l1111_l1_ (u"ࠪฬึอๅอࠩ㶂"),l1111_l1_ (u"ࠫศ฽แศๆࠣ์่ืส้่ࠪ㶃"),l1111_l1_ (u"ࠬืๅืษ้ࠫ㶄"),l1111_l1_ (u"࠭รฮัฮ࠱ศิัࠨ㶅"),l1111_l1_ (u"ࠧิๆสื้࠭㶆"),l1111_l1_ (u"ࠨ็๋ื๏่้ࠨ㶇"),l1111_l1_ (u"ࠩฦุ์ื࠭ฤๅฮีࠬ㶈"),l1111_l1_ (u"ࠪห้ศๆࠨ㶉"),l1111_l1_ (u"ࠫ฻ำใࠨ㶊"),l1111_l1_ (u"ࠬื๊ศุฬࠫ㶋"),l1111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ㶌"),l1111_l1_ (u"ࠧๆ็ฮ่๏์ࠧ㶍"),l1111_l1_ (u"ࠨสฮࠤา๐ࠧ㶎"),l1111_l1_ (u"ࠩา๎๋๐ษࠨ㶏"),l1111_l1_ (u"ࠪื๋๎วหࠩ㶐"),l1111_l1_ (u"ࠫศิั๊ࠩ㶑")]
		l1l1l111l1l1_l1_ = [l1111_l1_ (u"ࠬอแๅษ่ࠫ㶒"),l1111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㶓"),l1111_l1_ (u"ࠧโ์็้ࠬ㶔"),l1111_l1_ (u"ࠨใ็้ࠬ㶕")]
		l1l1l11l11l1_l1_ = [l1111_l1_ (u"่ࠩืู้ไࠨ㶖"),l1111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ㶗")]
		l1l1l1lll11l_l1_ = [l1111_l1_ (u"ู๊ࠫวาฯࠪ㶘"),l1111_l1_ (u"๋ࠬำาฯํหฯ࠭㶙")]
		l1l1l11l111l_l1_ = [l1111_l1_ (u"࠭ศาษ่ะࠬ㶚"),l1111_l1_ (u"ࠧࡴࡪࡲࡻࠬ㶛"),l1111_l1_ (u"ࠨฬ็ๅื๐่็ࠩ㶜"),l1111_l1_ (u"ࠩอ่๏็า๋๊้ࠫ㶝")]
		l1l1l1l1l111_l1_ = [l1111_l1_ (u"ࠪห๋๋๊ࠨ㶞"),l1111_l1_ (u"่ࠫืส้่ࠪ㶟"),l1111_l1_ (u"้ࠬวาฬ๋๊ࠬ㶠"),l1111_l1_ (u"࠭࡫ࡪࡦࡶࠫ㶡"),l1111_l1_ (u"ุࠧใ็ࠫ㶢"),l1111_l1_ (u"ࠨษฺๅฬ๊ࠧ㶣")]
		l1111ll1_l1_ = [l1111_l1_ (u"ࠩิ้฻อๆࠨ㶤")]
		l1llll1ll_l1_ = [l1111_l1_ (u"ࠪหาีหࠨ㶥"),l1111_l1_ (u"ࠫฬิัࠨ㶦"),l1111_l1_ (u"๋่ࠬฯำࠪ㶧"),l1111_l1_ (u"࠭ฬะ์าࠫ㶨"),l1111_l1_ (u"ࠧๆุสๅࠬ㶩"),l1111_l1_ (u"ࠨฯา๎ะ࠭㶪")]
		l1l1l11l1ll1_l1_ = [l1111_l1_ (u"ࠩึ่ฬูไࠨ㶫"),l1111_l1_ (u"ࠪืู้ไ่ࠩ㶬")]
		l1l1l1111l11_l1_ = [l1111_l1_ (u"ࠫฬเว็์ࠪ㶭"),l1111_l1_ (u"๋่ࠬิ์ๅํࠬ㶮"),l1111_l1_ (u"࠭ใๅ์หࠫ㶯"),l1111_l1_ (u"ࠧฮใ็ࠫ㶰"),l1111_l1_ (u"ࠨ࡯ࡸࡷ࡮ࡩࠧ㶱")]
		l1l1l1ll111l_l1_ = [l1111_l1_ (u"ࠩส็ะืࠧ㶲"),l1111_l1_ (u"ࠪหูํัࠨ㶳"),l1111_l1_ (u"๊๋๊ࠫำ้ࠪ㶴"),l1111_l1_ (u"ࠬอูๅ๋ࠪ㶵"),l1111_l1_ (u"࠭ๅฯฬสี์࠭㶶"),l1111_l1_ (u"ࠧๆะอหึอสࠨ㶷"),l1111_l1_ (u"ࠨษๅ์๎࠭㶸")]
		l1l1l111llll_l1_ = [l1111_l1_ (u"ࠩส่ฬ์ࠧ㶹"),l1111_l1_ (u"ࠪัฬ๊๊ࠨ㶺"),l1111_l1_ (u"๊ࠫัศหࠩ㶻"),l1111_l1_ (u"ࠬืววฮࠪ㶼")]
		l1l1l1111ll1_l1_ = [l1111_l1_ (u"࠭ึฮๅࠪ㶽"),l1111_l1_ (u"ࠧไ๊่๎ิ๐ࠧ㶾")]
		l1l1l111l1ll_l1_ = [l1111_l1_ (u"ࠨำํห฻ํࠧ㶿"),l1111_l1_ (u"ࠩๆ์ึํࠧ㷀"),l1111_l1_ (u"ฺ้ࠪอัฺ้ࠪ㷁"),l1111_l1_ (u"ูࠫ๎สࠨ㷂"),l1111_l1_ (u"ࠬื๊ศุฬࠫ㷃")]
		l1l1l1l11ll1_l1_ = [l1111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ㷄"),l1111_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ㷅"),l1111_l1_ (u"ࠨ่ํฮๆ๊๊ไีࠪ㷆")]
		l1l1l111l111_l1_ = [l1111_l1_ (u"่้ࠩะ๊๊็ࠩ㷇"),l1111_l1_ (u"ࠪหูิวึࠩ㷈"),l1111_l1_ (u"๋ࠫา่ๆࠩ㷉")]
		l1l1ll1ll_l1_ = [l1111_l1_ (u"ࠬฮหࠡฯํࠫ㷊"),l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㷋"),l1111_l1_ (u"ࠧใ่ส๋ࠬ㷌"),l1111_l1_ (u"ࠨไ้์ฬะࠧ㷍")]
		l1l1l1l11lll_l1_ = [l1111_l1_ (u"ࠩา๎๋࠭㷎"),l1111_l1_ (u"ࠪหิ฿๊่ࠩ㷏"),l1111_l1_ (u"ࠫื๐วาษอࠫ㷐"),l1111_l1_ (u"๊ࠬืๆ์สฮࠬ㷑"),l1111_l1_ (u"࠭ฯฺษฤࠫ㷒"),l1111_l1_ (u"ࠧใำส๊ࠬ㷓"),l1111_l1_ (u"ࠨไุหหีࠧ㷔"),l1111_l1_ (u"ࠩิฯฬวࠧ㷕"),l1111_l1_ (u"้ࠪึาู๋้ࠪ㷖"),l1111_l1_ (u"ࠫฬึว็ࠩ㷗"),l1111_l1_ (u"ࠬอำๅษ่ࠫ㷘"),l1111_l1_ (u"࠭ส้ษื๎า࠭㷙"),l1111_l1_ (u"ࠧฯูหࠫ㷚"),l1111_l1_ (u"ࠨฯ๋ึํ๐ࠧ㷛"),l1111_l1_ (u"ࠩ฼ฮออสࠨ㷜"),l1111_l1_ (u"้ࠪํอไ๋ัࠪ㷝"),l1111_l1_ (u"๋ࠫ๎วฺ์ࠪ㷞"),l1111_l1_ (u"ࠬ฿โศศาࠫ㷟"),l1111_l1_ (u"࠭ว็ษื๎ิ࠭㷠")]
		l1l1l1l1l1ll_l1_ = [l1111_l1_ (u"ࠧ࠲࠻ࠪ㷡"),l1111_l1_ (u"ࠨ࠴࠳ࠫ㷢")]
		if not l1l1l11lllll_l1_:
			l1l1l11lllll_l1_ = 0
			for l1l1l1l11111_l1_ in l1ll1l11ll_l1_:
				l1l1l11lllll_l1_ += 1
				l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㷣"),menu_name+l1l1l1l11111_l1_,l1111_l1_ (u"ࠪࠫ㷤"),165,l1111_l1_ (u"ࠫࠬ㷥"),str(l1l1l11lllll_l1_),l1l1l1l1111l_l1_)
		else:
			for name in sorted(list(l1ll11l11l11_l1_.keys())):
				name2 = name.lower()
				category = []
				if any(value in name2 for value in l1l1l111l1l1_l1_): category.append(1)
				if any(value in name2 for value in l1l1l11l11l1_l1_): category.append(2)
				if any(value in name2 for value in l1l1l1lll11l_l1_): category.append(3)
				if any(value in name2 for value in l1l1l11l111l_l1_): category.append(4)
				if any(value in name2 for value in l1l1l1l1l111_l1_): category.append(5)
				if any(value in name2 for value in l1111ll1_l1_): category.append(6)
				if any(value in name2 for value in l1llll1ll_l1_) and name2 not in [l1111_l1_ (u"ࠬอฮา๋ࠪ㷦")]: category.append(7)
				if any(value in name2 for value in l1l1l11l1ll1_l1_): category.append(8)
				if any(value in name2 for value in l1l1l1111l11_l1_): category.append(9)
				if any(value in name2 for value in l1l1l1ll111l_l1_): category.append(10)
				if any(value in name2 for value in l1l1l111llll_l1_): category.append(11)
				if any(value in name2 for value in l1l1l1111ll1_l1_): category.append(12)
				if any(value in name2 for value in l1l1l111l1ll_l1_): category.append(13)
				if any(value in name2 for value in l1l1l1l11ll1_l1_): category.append(14)
				if any(value in name2 for value in l1l1l111l111_l1_): category.append(15)
				if any(value in name2 for value in l1l1ll1ll_l1_): category.append(16)
				if any(value in name2 for value in l1l1l1l11lll_l1_): category.append(17)
				if any(value in name2 for value in l1l1l1l1l1ll_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l1l1l11lllll_l1_:
						l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㷧"),menu_name+name,name,166,l1111_l1_ (u"ࠧࠨ㷨"),l1111_l1_ (u"ࠨࠩ㷩"),l1l1l1l1111l_l1_+l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㷪"))
	elif l1111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㷫") in options:
		if l1111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ㷬") in options:
			import l1l1l1111l1_l1_
			if not l1l1l1111l1_l1_.isIPTVFiles(False): l1l1l1111l1_l1_.l1l111llll1_l1_()
		l1l1l11l1l1l_l1_(options)
	return
def l1l1l111ll11_l1_(l1llll1l11l1_l1_,options):
	options = options.replace(l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㷭"),l1111_l1_ (u"࠭ࠧ㷮")).replace(l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㷯"),l1111_l1_ (u"ࠨࠩ㷰"))
	l1l1l1111lll_l1_(False)
	if l1ll11l11l11_l1_=={}: return
	if l1111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ㷱") in options:
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㷲"),l1111_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㷳")+l1llll1l11l1_l1_+l1111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ㷴"),l1llll1l11l1_l1_,166,l1111_l1_ (u"࠭ࠧ㷵"),l1111_l1_ (u"ࠧࠨ㷶"),l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㷷")+options)
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㷸"),l1111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ㷹"),l1llll1l11l1_l1_,166,l1111_l1_ (u"ࠫࠬ㷺"),l1111_l1_ (u"ࠬ࠭㷻"),l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㷼")+options)
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㷽"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㷾"),l1111_l1_ (u"ࠩࠪ㷿"),9999)
	for l1l1lll1_l1_ in sorted(list(l1ll11l11l11_l1_[l1llll1l11l1_l1_].keys())):
		type,name,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict = l1ll11l11l11_l1_[l1llll1l11l1_l1_][l1l1lll1_l1_]
		if l1111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ㸀") in options or len(l1ll11l11l11_l1_[l1llll1l11l1_l1_])==1:
			l1ll1l1ll1ll_l1_(type,l1111_l1_ (u"ࠫࠬ㸁"),url,l1ll1lll111l_l1_,l1111_l1_ (u"ࠬ࠭㸂"),page,text,l1111_l1_ (u"࠭ࠧ㸃"),l1111_l1_ (u"ࠧࠨ㸄"))
			menuItemsLIST[:] = l1l1l11ll1l1_l1_(menuItemsLIST)
			l1l1l1111l1l_l1_,l111l11ll1_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l11ll1_l1_)
			if l1111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ㸅") in options: menuItemsLIST[:] = l1l1l1111l1l_l1_+l111l11ll1_l1_[:l1l1l1l1ll1l_l1_]
			else: menuItemsLIST[:] = l1l1l1111l1l_l1_+l111l11ll1_l1_
		elif l1111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ㸆") in options: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㸇"),l1l1lll1_l1_,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict)
	return
def l1l1l11l1lll_l1_(options,mode):
	options = options.replace(l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㸈"),l1111_l1_ (u"ࠬ࠭㸉")).replace(l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㸊"),l1111_l1_ (u"ࠧࠨ㸋"))
	name,l1l1l11l1l11_l1_ = l1111_l1_ (u"ࠨࠩ㸌"),[]
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㸍"),l1111_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㸎")+name+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅไึ้ࠥࡀࠠ࡜ࠢࠪ㸏"),l1111_l1_ (u"ࠬ࠭㸐"),mode,l1111_l1_ (u"࠭ࠧ㸑"),l1111_l1_ (u"ࠧࠨ㸒"),l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㸓")+options)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㸔"),l1111_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪ㸕"),l1111_l1_ (u"ࠫࠬ㸖"),mode,l1111_l1_ (u"ࠬ࠭㸗"),l1111_l1_ (u"࠭ࠧ㸘"),l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㸙")+options)
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㸚"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㸛"),l1111_l1_ (u"ࠪࠫ㸜"),9999)
	l1l1l1111l1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l1111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ㸝") in options:
		l1l1l1111lll_l1_(False)
		if l1ll11l11l11_l1_=={}: return
		l1l1l11ll11l_l1_ = list(l1ll11l11l11_l1_.keys())
		l1llll1l11l1_l1_ = random.sample(l1l1l11ll11l_l1_,1)[0]
		l1l1l1ll1l11_l1_ = list(l1ll11l11l11_l1_[l1llll1l11l1_l1_].keys())
		l1l1lll1_l1_ = random.sample(l1l1l1ll1l11_l1_,1)[0]
		type,name,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict = l1ll11l11l11_l1_[l1llll1l11l1_l1_][l1l1lll1_l1_]
		LOG_THIS(l1111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㸞"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩ㸟")+l1l1lll1_l1_+l1111_l1_ (u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ㸠")+name+l1111_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ㸡")+url+l1111_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ㸢")+str(l1ll1lll111l_l1_))
	elif l1111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㸣") in options:
		l1l1l11l1l1l_l1_(options)
		if not menuItemsLIST: return
		type,name,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㸤"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ㸥")+name+l1111_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ㸦")+url+l1111_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ㸧")+str(l1ll1lll111l_l1_))
	l1l1l11l11ll_l1_ = name
	l1l1l11lll11_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l1111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㸨"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ㸩")+name+l1111_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ㸪")+url+l1111_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ㸫")+str(l1ll1lll111l_l1_))
		menuItemsLIST[:] = []
		if l1ll1lll111l_l1_==234 and l1111_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭㸬") in text: l1ll1lll111l_l1_ = 233
		if l1ll1lll111l_l1_==144: l1ll1lll111l_l1_ = 291
		html = l1ll1l1ll1ll_l1_(type,name,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict)
		#if l1111_l1_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ㸭") in html: l1l1l11l1lll_l1_(options,mode)
		if l1111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ㸮") in options and l1ll1lll111l_l1_==167: del menuItemsLIST[:3]
		l1l1l11l1l11_l1_[:] = l1l1l11ll1l1_l1_(menuItemsLIST)
		if l1l1l11lll11_l1_ and l1ll11111111_l1_(l1111_l1_ (u"ࡶࠩะ่็ฯࠧ㸯")) in str(l1l1l11l1l11_l1_) or l1ll11111111_l1_(l1111_l1_ (u"ࡷࠪั้่็ࠨ㸰")) in str(l1l1l11l1l11_l1_):
			name = l1l1l11l11ll_l1_
			l1l1l11l1l11_l1_[:] = l1l1l11lll11_l1_
			break
		l1l1l11l11ll_l1_ = name
		l1l1l11lll11_l1_ = l1l1l11l1l11_l1_[:]
		if str(l1l1l11l1l11_l1_).count(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㸱"))>0: break
		if str(l1l1l11l1l11_l1_).count(l1111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㸲"))>0: break
		if l1ll1lll111l_l1_==233: break	# l11l1l11l1_l1_ l111l1l1_l1_ names l111ll1ll11_l1_ of l1llll11_l1_ name
		if l1ll1lll111l_l1_==291: break	# l1ll1lll1_l1_ l1l1l1ll11ll_l1_ names l111ll1ll11_l1_ of l1ll1lll1_l1_ l1l1l1ll11ll_l1_ contents
		if l1l1l11l1l11_l1_: type,name,url,l1ll1lll111l_l1_,image,page,text,l1lll1l111l_l1_,infodict = random.sample(l1l1l11l1l11_l1_,1)[0]
	if name==l1111_l1_ (u"ࠬ࠭㸳"): name = l1111_l1_ (u"࠭࠮࠯࠰࠱ࠫ㸴")
	elif name.count(l1111_l1_ (u"ࠧࡠࠩ㸵"))>1: name = name.split(l1111_l1_ (u"ࠨࡡࠪ㸶"),2)[2]
	name = name.replace(l1111_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐ࠽ࠤࠬ㸷"),l1111_l1_ (u"ࠪࠫ㸸"))#.replace(l1111_l1_ (u"ࠫ࠱ࡓࡏࡗࡋࡈࡗ࠿ࠦࠧ㸹"),l1111_l1_ (u"ࠬ࠭㸺")).replace(l1111_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ㸻"),l1111_l1_ (u"ࠧࠨ㸼")).replace(l1111_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ㸽"),l1111_l1_ (u"ࠩࠪ㸾"))
	l1l1l1111l1l_l1_[0][1] = l1111_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㸿")+name+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅไึ้ࠥࡀࠠ࡜ࠢࠪ㹀")
	for i in range(9): random.shuffle(l1l1l11l1l11_l1_)
	if l1111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ㹁") in options: menuItemsLIST[:] = l1l1l1111l1l_l1_+l1l1l11l1l11_l1_[:l1l1l1l1ll1l_l1_]
	else: menuItemsLIST[:] = l1l1l1111l1l_l1_+l1l1l11l1l11_l1_
	return
def l1l1l111lll1_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㹂"),l1111_l1_ (u"ࠧࠨ㹃")).replace(l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㹄"),l1111_l1_ (u"ࠩࠪ㹅"))
	l1l1l11ll111_l1_ = GROUP
	if l1111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ㹆") in GROUP:
		l1l1l11ll111_l1_ = GROUP.split(l1111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ㹇"))[0]
		type = l1111_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ㹈")
	elif l1111_l1_ (u"࠭ࡖࡐࡆࠪ㹉") in TYPE: type = l1111_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ㹊")
	elif l1111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㹋") in TYPE: type = l1111_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ㹌")
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㹍"),l1111_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㹎")+type+l1l1l11ll111_l1_+l1111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ㹏"),TYPE,167,l1111_l1_ (u"࠭ࠧ㹐"),l1111_l1_ (u"ࠧࠨ㹑"),l1111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㹒")+GROUP)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㹓"),l1111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ㹔"),TYPE,167,l1111_l1_ (u"ࠫࠬ㹕"),l1111_l1_ (u"ࠬ࠭㹖"),l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㹗")+GROUP)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㹘"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㹙"),l1111_l1_ (u"ࠩࠪ㹚"),9999)
	import l1l1l1111l1_l1_
	if l1111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ㹛") in GROUP: l1l1l1111l1_l1_.l1l111l11ll_l1_(TYPE,GROUP,l1111_l1_ (u"ࠫࠬ㹜"))
	else: l1l1l1111l1_l1_.l1ll1lll11_l1_(TYPE,GROUP,l1111_l1_ (u"ࠬ࠭㹝"))
	menuItemsLIST[:] = l1l1l11ll1l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l1l1ll1l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l1l1ll1l_l1_)
	return
def l1l1l11ll1l1_l1_(menuItemsLIST):
	l1l1l11l1l11_l1_ = []
	for type,name,url,mode,image,page,text,l1lll1l111l_l1_,infodict in menuItemsLIST:
		if l1111_l1_ (u"࠭ีโฯฬࠫ㹞") in name or l1111_l1_ (u"ࠧึใะ๋ࠬ㹟") in name or l1111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭㹠") in name.lower(): continue
		l1l1l11l1l11_l1_.append([type,name,url,mode,image,page,text,l1lll1l111l_l1_,infodict])
	return l1l1l11l1l11_l1_
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㦅")
menu_name=l1111_l1_ (u"ࠬࡥࡍ࠵ࡗࡢࠫ㦆")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"࠭ว็๊ส฽ࠥอแๅษ่ࠫ㦇"),l1111_l1_ (u"ࠧอ๊าหฯࠦวโๆส้ࠬ㦈")]
def l1111ll_l1_(mode,url,text):
	if   mode==380: l11l_l1_ = l11l111_l1_()
	elif mode==381: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==382: l11l_l1_ = l1lllll_l1_(url)
	elif mode==383: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==389: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㦉"),menu_name+l1111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ㦊"),l1111_l1_ (u"ࠪࠫ㦋"),389,l1111_l1_ (u"ࠫࠬ㦌"),l1111_l1_ (u"ࠬ࠭㦍"),l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㦎"))
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㦏"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㦐"),l1111_l1_ (u"ࠩࠪ㦑"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㦒"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ㦓")+menu_name+l1111_l1_ (u"ࠬอไๆ็ํึฮ࠭㦔"),l1ll11l_l1_,381,l1111_l1_ (u"࠭ࠧ㦕"),l1111_l1_ (u"ࠧࠨ㦖"),l1111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㦗"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㦘"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㦙")+menu_name+l1111_l1_ (u"ࠫฬ๊ฬศ่ห๎ฮ࠭㦚"),l1ll11l_l1_,381,l1111_l1_ (u"ࠬ࠭㦛"),l1111_l1_ (u"࠭ࠧ㦜"),l1111_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭㦝"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ㦞"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪ㦟"),l1111_l1_ (u"ࠪࠫ㦠"),l1111_l1_ (u"ࠫࠬ㦡"),l1111_l1_ (u"ࠬ࠭㦢"),l1111_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㦣"))
	html = response.content
	items = re.findall(l1111_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㦤"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㦥"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭㦦")+menu_name+title,l1ll11l_l1_,381,l1111_l1_ (u"ࠪࠫ㦧"),l1111_l1_ (u"ࠫࠬ㦨"),l1111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㦩")+str(seq))
	block = l1111_l1_ (u"࠭ࠧ㦪")
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡥࡥࡱࡵࠦࠬ㦫"),html,re.DOTALL)
	if l111l1l_l1_: block += l111l1l_l1_[0]
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡡࡴ࡫ࡧࡩࠬ㦬"),html,re.DOTALL)
	if l111l1l_l1_: block += l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㦭"),block,re.DOTALL)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㦮"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㦯"),l1111_l1_ (u"ࠬ࠭㦰"),9999)
	first = True
	for l1l111l_l1_,title in items:
		title = l1l1111_l1_(title)
		if title==l1111_l1_ (u"࠭วๅล฼่๎ࠦๅีษ๊ำฮ࠭㦱"):
			if first:
				title = l1111_l1_ (u"ࠧศๆสๅ้อๅࠡࠩ㦲")+title
				first = False
			else: title = l1111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤࠬ㦳")+title
		if title not in l11ll11_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㦴"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㦵")+menu_name+title,l1l111l_l1_,381)
	return html
def l1l11l1_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㦶"),l1111_l1_ (u"ࠬ࠭㦷"),url,type)
	#l111ll1l1_l1_(html)
	block,items = [],[]
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ㦸"),url,l1111_l1_ (u"ࠧࠨ㦹"),l1111_l1_ (u"ࠨࠩ㦺"),l1111_l1_ (u"ࠩࠪ㦻"),l1111_l1_ (u"ࠪࠫ㦼"),l1111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ㦽"))
	html = response.content
	if type==l1111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ㦾"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ㦿"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㧀"),block,re.DOTALL)
	elif type==l1111_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ㧁"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭㧂"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		z = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ㧃"),block,re.DOTALL)
		l11lll1l_l1_,l1l111lll_l1_,l11111l_l1_ = zip(*z)
		items = zip(l1l111lll_l1_,l11lll1l_l1_,l11111l_l1_)
	elif type==l1111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㧄"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ㧅"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㧆"),block,re.DOTALL)
	elif l1111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ㧇") in type:
		seq = int(type[-1:])
		html = html.replace(l1111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ㧈"),l1111_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ㧉"))
		html = html.replace(l1111_l1_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ㧊"),l1111_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ㧋"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ㧌"),html,re.DOTALL)
		block = l111l1l_l1_[seq]
		if seq==2: items = re.findall(l1111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㧍"),block,re.DOTALL)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭㧎"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0][0]
			if l1111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ㧏") in url:
				items = re.findall(l1111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㧐"),block,re.DOTALL)
			elif l1111_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭㧑") in url:
				items = re.findall(l1111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㧒"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㧓"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࠬ㧔") in title:
			title = re.findall(l1111_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡪࡸࡩࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㧕"),title,re.DOTALL)
			title = title[0][1]#+l1111_l1_ (u"ࠨࠢ࠰ࠤࠬ㧖")+title[0][0]
			if title in l1lllll1_l1_: continue
			l1lllll1_l1_.append(title)
			title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㧗")+title
		title2 = re.findall(l1111_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿ࠫ㧘"),title,re.DOTALL)
		if title2: title = title2[0]
		title = l1l1111_l1_(title)
		if l1111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ㧙") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㧚"),menu_name+title,l1l111l_l1_,383,img)
		elif l1111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ㧛") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㧜"),menu_name+title,l1l111l_l1_,383,img)
		elif l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ㧝") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㧞"),menu_name+title,l1l111l_l1_,383,img)
		elif l1111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ㧟") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㧠"),menu_name+title,l1l111l_l1_,381,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㧡"),menu_name+title,l1l111l_l1_,382,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࡐࡢࡩࡨࠤ࠭࠴ࠪࡀࠫࠣࡳ࡫ࠦࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㧢"),html,re.DOTALL)
	if l111l1l_l1_:
		current = l111l1l_l1_[0][0]
		last = l111l1l_l1_[0][1]
		block = l111l1l_l1_[0][2]
		items = re.findall(l1111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ㧣"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title==l1111_l1_ (u"ࠨࠩ㧤") or title==last: continue
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㧥"),menu_name+l1111_l1_ (u"ูࠪๆำษࠡࠩ㧦")+title,l1l111l_l1_,381,l1111_l1_ (u"ࠫࠬ㧧"),l1111_l1_ (u"ࠬ࠭㧨"),type)
		#if title==last:
		l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭㧩")+title+l1111_l1_ (u"ࠧ࠰ࠩ㧪"),l1111_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ㧫")+last+l1111_l1_ (u"ࠩ࠲ࠫ㧬"))
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㧭"),menu_name+l1111_l1_ (u"ࠫฬิัࠡืไัฮࠦࠧ㧮")+last,l1l111l_l1_,381,l1111_l1_ (u"ࠬ࠭㧯"),l1111_l1_ (u"࠭ࠧ㧰"),type)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ㧱"),url,l1111_l1_ (u"ࠨࠩ㧲"),l1111_l1_ (u"ࠩࠪ㧳"),l1111_l1_ (u"ࠪࠫ㧴"),l1111_l1_ (u"ࠫࠬ㧵"),l1111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㧶"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㧷"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_,False):
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㧸"),menu_name+l1111_l1_ (u"ࠨษ็ุ้๊ำๅࠢ็่่ฮวา๋ࠢห้๋ศา็ฯࠤ๊์ู่ࠩ㧹"),l1111_l1_ (u"ࠩࠪ㧺"),9999)
		return
	if l1111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㧻") in url or l1111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ㧼") in url:
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡪࡶࡨࡱࠬࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ㧽"),html,re.DOTALL)
		if l1l1lll_l1_:
			l1l1lll_l1_ = l1l1lll_l1_[1]
			l1l11ll_l1_(l1l1lll_l1_)
			return
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨࡧࡳ࡭ࡸࡵࡤࡪࡱࡶࠫ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡢࡵࡷࠦࠬ࠭ࠧ㧾"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡱࡹࡲ࡫ࡲࡢࡰࡧࡳࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ㧿"),block,re.DOTALL)
		for img,l11l11l_l1_,l1l111l_l1_,name in items:
			title = l11l11l_l1_+l1111_l1_ (u"ࠨࠢ࠽ࠤࠬ㨀")+name+l1111_l1_ (u"ࠩࠣห้ำไใหࠪ㨁")
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㨂"),menu_name+title,l1l111l_l1_,382)
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ㨃"),url,l1111_l1_ (u"ࠬ࠭㨄"),l1111_l1_ (u"࠭ࠧ㨅"),l1111_l1_ (u"ࠧࠨ㨆"),l1111_l1_ (u"ࠨࠩ㨇"),l1111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㨈"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㨉"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠦࠧࠨࡩࡥ࠿ࠪࡴࡱࡧࡹࡦࡴ࠰ࡳࡵࡺࡩࡰࡰ࠰࠵ࠬ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠫࠦࡸ࡮ࡥࡢࡦࡨࡶࠧࢂࠧࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ࠩࠣࠤࠥ㨊"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0][0]
		items = re.findall(l1111_l1_ (u"ࠧࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡷࡪࡸࡶࡦࡴࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ㨋"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㨌")+title+l1111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ㨍")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬࠮ࡥ࡯ࡳࡸ࡫ࠢࠨ㨎"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡢࡣࡤࡪ࡬ࡠࡩࡧࡶ࡮ࡼࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㨏"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㨐")+title+l1111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㨑")
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ㨒"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㨓"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠧࠨ㨔"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠨࠩ㨕"): return
	search = search.replace(l1111_l1_ (u"ࠩࠣࠫ㨖"),l1111_l1_ (u"ࠪ࠯ࠬ㨗"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ㨘")+search
	l1l11l1_l1_(url,l1111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ㨙"))
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ์")
headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫํ"):l1111_l1_ (u"ࠨࠩ๎")}
menu_name=l1111_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨ๏")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ๐"),l1111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษ๎ࠫ๑"),l1111_l1_ (u"๋ࠬีศำ฼๋ࠬ๒"),l1111_l1_ (u"࠭วฺๆ้ࠤ๊฿ๆศࠢ⠖ࠤࡋࡵࡲࠡࡣࡧࡷࠬ๓"),l1111_l1_ (u"ࠧๆ๊หห๏๊วหࠩ๔"),l1111_l1_ (u"ࠨสิห๊าࠠไ็ห๎ํะัࠨ๕"),l1111_l1_ (u"ࠩส่฾อศࠡๅ่ฬ๏๎สาࠩ๖"),l1111_l1_ (u"ࠪหุ๊วๆ์สฮࠬ๗"),l1111_l1_ (u"ࠫฬิั๊ࠩ๘"),l1111_l1_ (u"ࠬอโิษ่ࠤฬิั๋ࠩ๙"),l1111_l1_ (u"࠭วีฬิห่อสࠨ๚")]
def l1111ll_l1_(mode,url,text):
	if   mode==250: l11l_l1_ = l11l111_l1_()
	elif mode==251: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==252: l11l_l1_ = l1lllll_l1_(url)
	elif mode==253: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==254: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ๛")+text)
	elif mode==255: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ๜")+text)
	elif mode==256: l11l_l1_ = l11lll1l1_l1_(url,text)
	elif mode==259: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
headers = {l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭๝"):l1l111l1l_l1_()}
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๞"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ๟"),l1111_l1_ (u"ࠬ࠭๠"),259,l1111_l1_ (u"࠭ࠧ๡"),l1111_l1_ (u"ࠧࠨ๢"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ๣"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๤"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭๥"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬ๦"),254)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๧"),menu_name+l1111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ๨"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ๩"),255)
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭๪"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ๫"),l1111_l1_ (u"ࠪࠫ๬"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ๭"),menu_name+l1111_l1_ (u"ࠬอไๆ็ํึฮ࠭๮"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ๯"),251,l1111_l1_ (u"ࠧࠨ๰"),l1111_l1_ (u"ࠨࠩ๱"),l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩ๲"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๳"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ๴")+menu_name+l1111_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ๵"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ๶"),251,l1111_l1_ (u"ࠧࠨ๷"),l1111_l1_ (u"ࠨࠩ๸"),l1111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭๹"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๺"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ๻")+menu_name+l1111_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ๼"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ๽"),251,l1111_l1_ (u"ࠧࠨ๾"),l1111_l1_ (u"ࠨࠩ๿"),l1111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ຀"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪກ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨຂ")+menu_name+l1111_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬ຃"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡭ࡣࡶࡸࡪࡹࡴࠨຄ"),251,l1111_l1_ (u"ࠧࠨ຅"),l1111_l1_ (u"ࠨࠩຆ"),l1111_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪງ"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧຈ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪຉ"),l1111_l1_ (u"ࠬ࠭ຊ"),headers,l1111_l1_ (u"࠭ࠧ຋"),l1111_l1_ (u"ࠧࠨຌ"),l1111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬຍ"))
	html = response.content
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡩࡳࡻࡈࡦࡣࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫຎ"),html,re.DOTALL)
	l111ll1l_l1_ = l1l11lll1_l1_[0]
	l11l1ll11_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬຏ"),l111ll1l_l1_,re.DOTALL)
	for l1l111l_l1_,title in l11l1ll11_l1_:
		title = l1l1111_l1_(title)
		if title not in l11ll11_l1_ and title!=l1111_l1_ (u"ࠫࠬຐ"):
			if l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪຑ") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			#l1l111l_l1_ = l1l111l_l1_.rstrip(l1111_l1_ (u"࠭࠯ࠨຒ")).replace(l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫຓ")),l1ll11l_l1_)
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨດ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ຕ")+menu_name+title,l1l111l_l1_,256)
	return html
def l11lll1l1_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫຖ"),l1111_l1_ (u"ࠫࠬທ"),l1111_l1_ (u"࡙ࠬࡕࡃࡏࡈࡒ࡚ࠦࠠࠡࠢࠣࠫຘ")+type,url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪນ"),url,l1111_l1_ (u"ࠧࠨບ"),headers,l1111_l1_ (u"ࠨࠩປ"),l1111_l1_ (u"ࠩࠪຜ"),l1111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪຝ"))
	html = response.content
	if l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵࡍࡳ࡙ࡥࡤࡶ࡬ࡳࡳ࠭ພ") in html: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬຟ"),menu_name+l1111_l1_ (u"࠭วๅลๆฯึࠦๅีษ๊ำฮ࠭ຠ"),url,251,l1111_l1_ (u"ࠧࠨມ"),l1111_l1_ (u"ࠨࠩຢ"),l1111_l1_ (u"ࠩࡰࡳࡸࡺࠧຣ"))
	if l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡹࠧ຤") in html: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫລ"),menu_name+l1111_l1_ (u"ࠬอไๆ็ํึฮ࠭຦"),url,251,l1111_l1_ (u"࠭ࠧວ"),l1111_l1_ (u"ࠧࠨຨ"),l1111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪຩ"))
	if l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡳࡱࡳࡍ࡫ࡶࡸࠬສ") in html:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩຫ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			if len(l111l1l_l1_)>1 and type==l1111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪຬ"): block = l111l1l_l1_[1]
			items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ອ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				title2 = re.findall(l1111_l1_ (u"࠭࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧຮ"),title,re.DOTALL)
				try: l11ll1ll1_l1_ = title2[0][0]
				except: l11ll1ll1_l1_ = l1111_l1_ (u"ࠧࠨຯ")
				try: l11ll1lll_l1_ = title2[0][1]
				except: l11ll1lll_l1_ = l1111_l1_ (u"ࠨࠩະ")
				title2 = l11ll1ll1_l1_+l11ll1lll_l1_
				title2 = title2.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬັ"),l1111_l1_ (u"ࠪࠫາ"))
				#LOG_THIS(l1111_l1_ (u"ࠫࠬຳ"),str(title2))
				if l1111_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠧິ") in title:
					title2 = re.findall(l1111_l1_ (u"࠭࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪີ"),title,re.DOTALL)
					title2 = title2[0]
				if not title2:
					title2 = re.findall(l1111_l1_ (u"ࠧࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬຶ"),title,re.DOTALL)
					title2 = title2[0]
				else:
					if l1111_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭ື") in l1l111l_l1_: type = l1l111l_l1_.split(l1111_l1_ (u"ࠩ࡮ࡩࡾࡃຸࠧ"))[1]
					else: type = l1111_l1_ (u"ࠪࡲࡪࡽࡥࡴࡶູࠪ")
					#l1l111l_l1_ = l1l111l_l1_.rstrip(l1111_l1_ (u"ࠫ࠴຺࠭")).replace(l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩົ")),l1ll11l_l1_)
					l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ຼ"),menu_name+title2,l1l111l_l1_,251,l1111_l1_ (u"ࠧࠨຽ"),l1111_l1_ (u"ࠨࠩ຾"),type)
	return
def l1l11l1_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ຿"),l1111_l1_ (u"ࠪࠫເ"),l1111_l1_ (u"࡙ࠫࡏࡔࡍࡇࡖࠤࠥࠦࠠࠡࠩແ")+type,url)
	method,data,items = l1111_l1_ (u"ࠬࡍࡅࡕࠩໂ"),l1111_l1_ (u"࠭ࠧໃ"),[]
	if type==l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨໄ"):
		if l1111_l1_ (u"ࠨࡁࠪ໅") in url:
			l11lll111_l1_,l11lll1ll_l1_ = l1111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧໆ"),{}
			l1l1lll_l1_,l11llll11_l1_ = url.split(l1111_l1_ (u"ࠪࡃࠬ໇"))
			lines = l11llll11_l1_.split(l1111_l1_ (u"່ࠫࠫ࠭"))
			for line in lines:
				key,value = line.split(l1111_l1_ (u"ࠬࡃ້ࠧ"))
				l11lll1ll_l1_[key] = value
			if lines: method,url,data = l11lll111_l1_,l1l1lll_l1_,l11lll1ll_l1_
	response = l1l11l_l1_(l1111l1_l1_,method,url,data,headers,l1111_l1_ (u"໊࠭ࠧ"),l1111_l1_ (u"ࠧࠨ໋"),l1111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ໌"))
	html = response.content
	if type==l1111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪໍ"): l111l1l_l1_ = [html]
	elif l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ໎") in type: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡒࡩ࡯࡭ࡶࡐ࡮ࡹࡴࠨ໏"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ໐"): l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ฬะ์าࠤฬ๊วโๆส้࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭໑"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭໒"): l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ໓"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠩࡰࡳࡸࡺࠧ໔"): l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴࡌࡲࡘ࡫ࡣࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡳࡱࡳࡍ࡫ࡶࡸࠬ໕"),html,re.DOTALL)
	else: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡇࡲ࡯ࡤ࡭ࡶ࠱࡚ࡒࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡇࡢࡰࡇ࡯ࡗࡪ࡫ࡤࠣࠩ໖"),html,re.DOTALL)
	if l1111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ໗") in type:
		block = l111l1l_l1_[0]
		zz = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠩࡵࡵࡧࢁࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໘"),block,re.DOTALL)
		if zz:
			l11lll1l_l1_,l11111l_l1_,l1l111111_l1_,l1l111lll_l1_ = zip(*zz)
			items = zip(l11lll1l_l1_,l1l111lll_l1_,l11111l_l1_)
	else:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ໙"),block,re.DOTALL)
		#if not items: items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ໚"),block,re.DOTALL)
		#if not items: items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ໛"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for l1l111l_l1_,img,title in items:
		#l1l111l_l1_ = l1l111l_l1_.rstrip(l1111_l1_ (u"ࠪ࠳ࠬໜ")).replace(l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨໝ")),l1ll11l_l1_)
		#img = img.rstrip(l1111_l1_ (u"ࠬ࠵ࠧໞ")).replace(l1l1lll1l_l1_(img,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪໟ")),l1ll11l_l1_)
		title = l1l1111_l1_(title)
		if l1111_l1_ (u"ࠧศๆะ่็ฯࠧ໠") in title:
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ໡"),title,re.DOTALL)
			if l11l11l_l1_:
				title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ໢") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1lllll1_l1_.append(title)
					l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ໣"),menu_name+title,l1l111l_l1_,253,img)
			else: l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ໤"),menu_name+title,l1l111l_l1_,252,img)
		elif l1111_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ໥") in l1l111l_l1_ or l1111_l1_ (u"࠭ๅิๆึ่ࠬ໦") in title:
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໧"),menu_name+title,l1l111l_l1_,253,img)
		else:
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ໨"),menu_name+title,l1l111l_l1_,252,img)
	if type in [l1111_l1_ (u"ࠩࡱࡩࡼ࡫ࡳࡵࠩ໩"),l1111_l1_ (u"ࠪࡦࡪࡹࡴࠨ໪"),l1111_l1_ (u"ࠫࡲࡵࡳࡵࠩ໫")]:
		items = re.findall(l1111_l1_ (u"ࠬࡶࡡࡨࡧ࠰ࡲࡺࡳࡢࡦࡴࡶࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ໬"),html,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			title = l1l1111_l1_(title)
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭໭"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭໮")+title,l1l111l_l1_,251,l1111_l1_ (u"ࠨࠩ໯"),l1111_l1_ (u"ࠩࠪ໰"),type)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ໱"),url,l1111_l1_ (u"ࠫࠬ໲"),headers,l1111_l1_ (u"ࠬ࠭໳"),l1111_l1_ (u"࠭ࠧ໴"),l1111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ໵"))
	html = response.content
	items = re.findall(l1111_l1_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡔࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭໶"),html,re.DOTALL)
	if not items: return
	img,name = items[0]
	if l1111_l1_ (u"ࠩส่า๊โสࠩ໷") in name: name = name.split(l1111_l1_ (u"ࠪห้ำไใหࠪ໸"))[0].strip(l1111_l1_ (u"ࠫࠥ࠭໹"))
	elif l1111_l1_ (u"ࠬำไใหࠪ໺") in name: name = name.split(l1111_l1_ (u"࠭อๅไฬࠫ໻"))[0].strip(l1111_l1_ (u"ࠧࠡࠩ໼"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵࡄࡶࡪࡧࠢࠩ࠰࠭ࡃ࠮ࡹࡴࡺ࡮ࡨࡁࠧࡩ࡬ࡦࡣࡵ࠾ࠥࡨ࡯ࡵࡪ࠾ࠦࠬ໽"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ໾"),block,re.DOTALL)
		for l1l111l_l1_,l11l11l_l1_ in reversed(items):
			title = name+l1111_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦัใ็ࠣࠫ໿")+l11l11l_l1_
			#l1l111l_l1_ = l1l111l_l1_.rstrip(l1111_l1_ (u"ࠫ࠴࠭ༀ")).replace(l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ༁")),l1ll11l_l1_)
			#img = img.rstrip(l1111_l1_ (u"࠭࠯ࠨ༂")).replace(l1l1lll1l_l1_(img,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ༃")),l1ll11l_l1_)
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ༄"),menu_name+title,l1l111l_l1_,252,img)
	else: l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ༅"),menu_name+l1111_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ༆"),url,252,img)
	return
def l11l1llll_l1_(title,l1l111l_l1_):
	title2 = re.findall(l1111_l1_ (u"ࠫࡠࡧ࠭ࡻࡃ࠰࡞࠲ࡣࠫࠨ༇"),title,re.DOTALL)
	if title2: title = title2[0]
	else: title = title+l1111_l1_ (u"ࠬࠦࠧ༈")+l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ༉"))
	title = title.replace(l1111_l1_ (u"ฺࠧำหࠤุ๐ฯࠨ༊"),l1111_l1_ (u"ࠨࠩ་")).replace(l1111_l1_ (u"่ࠩฬฬฺัࠨ༌"),l1111_l1_ (u"ࠪࠫ།")).replace(l1111_l1_ (u"ฺ๊ࠫว่ัฬࠫ༎"),l1111_l1_ (u"ࠬ࠭༏"))
	title = title.replace(l1111_l1_ (u"࠭ํࠨ༐"),l1111_l1_ (u"ࠧࠨ༑"))
	title = title.replace(l1111_l1_ (u"ࠨࠢࠣࠫ༒"),l1111_l1_ (u"ࠩࠣࠫ༓")).replace(l1111_l1_ (u"ࠪࠤࠥ࠭༔"),l1111_l1_ (u"ࠫࠥ࠭༕"))
	return title
def l1lllll_l1_(url):
	# l1ll11ll_l1_://l1l11111l_l1_.l11lll11l_l1_/فيلم-l11ll1l11_l1_-for-l11l1lll1_l1_-l11l1l1l1_l1_-2022-مترجم/
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ༖"),url,l1111_l1_ (u"࠭ࠧ༗"),headers,l1111_l1_ (u"ࠧࠨ༘"),l1111_l1_ (u"ࠨ༙ࠩ"),l1111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭༚"))
	html = response.content
	l11lll1l_l1_ = []
	# l11l1l11l_l1_ l11ll1l1l_l1_ l1l111l_l1_
	l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡏࡦࡳࡣࡰࡩࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༛"),html,re.DOTALL)
	if l11l1ll1_l1_:
		l1l111l_l1_,l11l1111_l1_ = l11l1ll1_l1_[0]
		name = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ༜"))
		l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭༝")+name+l1111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࡡࡢࠫ༞")+l11l1111_l1_
		l11lll1l_l1_.append(l1l111l_l1_)
	# l11ll1l1l_l1_ & download l11l1ll1_l1_
	l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༟"),html,re.DOTALL)
	if l11l1ll1_l1_:
		server = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠨࡷࡵࡰࠬ༠"))
		#headers = {l1111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ༡"):server,l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ༢"):l1l111l1l_l1_()}
		headers[l1111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ༣")] = server
		# l11ll1l1l_l1_ l11l1ll1_l1_
		l11l1ll1l_l1_ = l11l1ll1_l1_[0][0]
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ༤"),l11l1ll1l_l1_,l1111_l1_ (u"࠭ࠧ༥"),headers,l1111_l1_ (u"ࠧࠨ༦"),l1111_l1_ (u"ࠨࠩ༧"),l1111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭༨"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡧࡵࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄࡂ࠯ࡶ࡮ࡁ࠭ࠬ༩"),html,re.DOTALL)
		if l111l1l_l1_:
			l11l1l111_l1_ = l111l1l_l1_[0]
			l11l1l111_l1_ = l11l1l111_l1_.replace(l1111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ༪"),l1111_l1_ (u"ࠬࡂࡨ࠴ࡀࠪ༫"))
			l11l1l111_l1_ = l11l1l111_l1_.replace(l1111_l1_ (u"࠭࠼ࡩ࠵ࡁࠫ༬"),l1111_l1_ (u"ࠧ࠽ࡪ࠶ࡂࡁ࡮࠳࠿ࠩ༭"))
			l1lll11_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾࡫࠷ࡃ࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠨ࠯ࠬࡂ࠭ࡁ࡮࠳࠿ࠩ༮"),l11l1l111_l1_,re.DOTALL)
			for l11l1111_l1_,block in l1lll11_l1_:
				items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭༯"),block,re.DOTALL)
				for l1l111l_l1_,name in items:
					name = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ༰"))
					l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ༱")+name+l1111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟ࡠࡡࠪ༲")+l11l1111_l1_
					l11lll1l_l1_.append(l1l111l_l1_)
		# download l11l1ll1_l1_
		l11llllll_l1_ = l11l1ll1_l1_[0][1]
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ༳"),l11llllll_l1_,l1111_l1_ (u"ࠧࠨ༴"),headers,l1111_l1_ (u"ࠨ༵ࠩ"),l1111_l1_ (u"ࠩࠪ༶"),l1111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪ༷ࠧ"))
		html = response.content
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡇࡲࡦࡣࠥࠬ࠳࠰࠿ࠪࡨࡸࡲࡨࡺࡩࡰࡰࠪ༸"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾༹ࠪ"),block,re.DOTALL)
			for l1l111l_l1_,title,l11l1111_l1_ in items:
				if not l1l111l_l1_: continue
				# it l1l1111l1_l1_ a l11ll11l1_l1_ from l11llll1l_l1_
				# l1l11l111_l1_
				if l1111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡹࡴࡢࡶ࡬ࡳࡳ࠭༺") in l1l111l_l1_: continue
				l1l111l_l1_ = UNQUOTE(l1l111l_l1_)
				title = l11l1llll_l1_(title,l1l111l_l1_)
				l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ༻")+title+l1111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ༼")+l11l1111_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ༽"), l11lll1l_l1_)
	l11ll111l_l1_ = str(l11lll1l_l1_)
	l111l1_l1_ = [l1111_l1_ (u"ࠪ࠲ࡿ࡯ࡰࡀࠩ༾"),l1111_l1_ (u"ࠫ࠳ࡸࡡࡳࡁࠪ༿"),l1111_l1_ (u"ࠬ࠴ࡴࡹࡶࡂࠫཀ"),l1111_l1_ (u"࠭࠮ࡱࡦࡩࡃࠬཁ"),l1111_l1_ (u"ࠧ࠯ࡶࡤࡶࡄ࠭ག"),l1111_l1_ (u"ࠨ࠰࡬ࡷࡴࡅࠧགྷ"),l1111_l1_ (u"ࠩ࠱ࡾ࡮ࡶ࠮ࠨང"),l1111_l1_ (u"ࠪ࠲ࡷࡧࡲ࠯ࠩཅ"),l1111_l1_ (u"ࠫ࠳ࡺࡸࡵ࠰ࠪཆ"),l1111_l1_ (u"ࠬ࠴ࡰࡥࡨ࠱ࠫཇ"),l1111_l1_ (u"࠭࠮ࡵࡣࡵ࠲ࠬ཈"),l1111_l1_ (u"ࠧ࠯࡫ࡶࡳ࠳࠭ཉ")]
	if any(value in l11ll111l_l1_ for value in l111l1_l1_):
		l1ll1l_l1_(l1111_l1_ (u"ࠨࠩཊ"),l1111_l1_ (u"ࠩࠪཋ"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ཌ"),l1111_l1_ (u"ࠫัืศࠡำสฬ฼ࠦๅฯฬ็ๅ๊ࠥร็๊ࠢิฬࠦวๅำสฬ฼ࠦไ๋ี้๋ࠣࠦๆ้฻ࠣห้ื่ศสฺࠤฬ๊ส๋ࠢไ๎์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡๆฦ๊ࠥํะศࠢส่๊๎โฺࠢไ๎์ࠦฮะ็สฮࠥษฮา๋ࠣ฾๏ืࠠๆๆไหฯࠦวๅใํำ๏๎ࠧཌྷ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫཎ"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search: search = l11ll_l1_()
	if not search: return
	search = search.replace(l1111_l1_ (u"࠭ࠠࠨཏ"),l1111_l1_ (u"ࠧࠬࠩཐ"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡩ࡭ࡳࡪ࠯ࡀࡨ࡬ࡲࡩࡃࠧད")+search
	l1l11l1_l1_(url,l1111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩདྷ"))
	return
def l1llllll_l1_(url,filter):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫན"),l1111_l1_ (u"ࠫࠬཔ"),filter,url)
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ཕ"):url,l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪབ"):l1111_l1_ (u"ࠧࠨབྷ")}
	#l1l1lll11_l1_ = l1111_l1_ (u"ࠨࠩམ")
	#filter = filter.replace(l1111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫཙ"),l1111_l1_ (u"ࠪࠫཚ"))
	if l1111_l1_ (u"ࠫࡄࡅࠧཛ") in url: url = url.split(l1111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫཛྷ"))[0]
	type,filter = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪཝ"),1)
	if filter==l1111_l1_ (u"ࠧࠨཞ"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠨࠩཟ"),l1111_l1_ (u"ࠩࠪའ")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠪࡣࡤࡥࠧཡ"))
	if type==l1111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨར"):
		if l1l11l11l_l1_[0]+l1111_l1_ (u"ࠬࡃ࠽ࠨལ") not in l1l11lll_l1_: category = l1l11l11l_l1_[0]
		for i in range(len(l1l11l11l_l1_[0:-1])):
			if l1l11l11l_l1_[i]+l1111_l1_ (u"࠭࠽࠾ࠩཤ") in l1l11lll_l1_: category = l1l11l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠧࠧࠨࠪཥ")+category+l1111_l1_ (u"ࠨ࠿ࡀ࠴ࠬས")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠩࠩࠪࠬཧ")+category+l1111_l1_ (u"ࠪࡁࡂ࠶ࠧཨ")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠫࠫࠬࠧཀྵ"))+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩཪ")+l1ll11l1_l1_.strip(l1111_l1_ (u"࠭ࠦࠧࠩཫ"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪཬ"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ཭")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ཮"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ཯"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠫࠬ཰"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨཱ"))
		if l1l11ll1_l1_==l1111_l1_ (u"ི࠭ࠧ"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄཱི࠭")+l1l11ll1_l1_
		l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨུ"),menu_name+l1111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤཱུࠬ"),l1llllll1_l1_,251,l1111_l1_ (u"ࠪࠫྲྀ"),l1111_l1_ (u"ࠫࠬཷ"),l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ླྀ"))
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ཹ"),menu_name+l1111_l1_ (u"ࠧࠡ࡝࡞ࠤེࠥࠦࠧ")+l11lll11_l1_+l1111_l1_ (u"ࠨࠢࠣࠤࡢࡣཻࠧ"),l1llllll1_l1_,251,l1111_l1_ (u"ོࠩࠪ"),l1111_l1_ (u"ཽࠪࠫ"),l1111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬཾ"))
		l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪཿ"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢྀ࠭"),l1111_l1_ (u"ࠧࠨཱྀ"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ྂ"),url,l1111_l1_ (u"ࠩࠪྃ"),headers,l1111_l1_ (u"྄ࠪࠫ"),l1111_l1_ (u"ࠫࠬ྅"),l1111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ྆"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡔࡢࡺࡓࡥ࡬࡫ࡆࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡙ࠦ࡫ࡲ࡮ࡄࡗࡒࡸࠨࠧ྇"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	l1l111l11_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡕࡣࡻࡔࡦ࡭ࡥࡇ࡫࡯ࡸࡪࡸࡉࡵࡧࡰࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩྈ"),block,re.DOTALL)
	l1l1111ll_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡔࡤࡸ࡮ࡴࡧࡇ࡫࡯ࡸࡪࡸࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁ࠲࠯ࡅࠨ࠽ࡷ࡯ࡂ࠮࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩྉ"),block,re.DOTALL)
	l111111_l1_ = l1l111l11_l1_+l1l1111ll_l1_
	dict = {}
	for name,l1lll1ll_l1_,block in l111111_l1_:
		#if l1111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫྊ") in l1lll1ll_l1_: continue
		items = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫྋ"),block,re.DOTALL)
		if name==l1111_l1_ (u"ࠫฬิั๊ࠩྌ"): name = l1111_l1_ (u"ࠬอไศไึห๊࠭ྍ")
		if not items:
			l11l1ll11_l1_ = re.findall(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡷࡧࡴࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭ྎ"),block,re.DOTALL)
			items = []
			for option,value in l11l1ll11_l1_: items.append([option,l1111_l1_ (u"ࠧࠨྏ"),value])
			l1lll1ll_l1_ = l1111_l1_ (u"ࠨࡴࡤࡸࡪ࠭ྐ")
			name = l1111_l1_ (u"ࠩส่ฯ่๊๋็ࠪྑ")
		else: l1lll1ll_l1_ = items[0][1]
		if l1111_l1_ (u"ࠪࡁࡂ࠭ྒ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨྒྷ"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬྔ")+l1l1l1ll_l1_)
				return
			else:
				l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_)
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ྕ"),menu_name+l1111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨྖ"),l1llllll1_l1_,251,l1111_l1_ (u"ࠨࠩྗ"),l1111_l1_ (u"ࠩࠪ྘"),l1111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫྙ"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྚ"),menu_name+l1111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ྛ"),l1l1lll_l1_,254,l1111_l1_ (u"࠭ࠧྜ"),l1111_l1_ (u"ࠧࠨྜྷ"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩྞ"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠩࠩࠪࠬྟ")+l1lll1ll_l1_+l1111_l1_ (u"ࠪࡁࡂ࠶ࠧྠ")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠫࠫࠬࠧྡ")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃ࠽࠱ࠩྡྷ")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪྣ")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧྤ"),menu_name+l1111_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪྥ")+name,l1l1lll_l1_,255,l1111_l1_ (u"ࠩࠪྦ"),l1111_l1_ (u"ࠪࠫྦྷ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ྨ"))
		dict[l1lll1ll_l1_] = {}
		for option,dummy,value in items:
			if option in l11ll11_l1_: continue
			if l1111_l1_ (u"ࠬอไไๆࠪྩ") in option: continue
			option = l1l1111_l1_(option)
			#if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫྪ") in option: continue
			#if l1111_l1_ (u"ࠧ࡯࠯ࡤࠫྫ") in value: continue
			l11ll11ll_l1_,title2 = option,option
			title2 = name+l1111_l1_ (u"ࠨ࠼ࠣࠫྫྷ")+l11ll11ll_l1_
			dict[l1lll1ll_l1_][value] = title2
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠩࠩࠪࠬྭ")+l1lll1ll_l1_+l1111_l1_ (u"ࠪࡁࡂ࠭ྮ")+l11ll11ll_l1_
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠫࠫࠬࠧྯ")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃ࠽ࠨྰ")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪྱ")+l1ll11l1_l1_
			if type==l1111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨྲ"):
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨླ"),menu_name+title2,url,255,l1111_l1_ (u"ࠩࠪྴ"),l1111_l1_ (u"ࠪࠫྵ"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ྶ"))
			elif type==l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩྷ") and l1l11l11l_l1_[-2]+l1111_l1_ (u"࠭࠽࠾ࠩྸ") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪྐྵ"))
				#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩྺ"),l1111_l1_ (u"ࠩࠪྻ"),l1l111l1_l1_,l1ll11l1_l1_)
				l11l11_l1_ = url+l1111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩྼ")+l1l111l1_l1_
				l1llllll1_l1_ = l11lllll1_l1_(l11l11_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ྽"),menu_name+title2,l1llllll1_l1_,251,l1111_l1_ (u"ࠬ࠭྾"),l1111_l1_ (u"࠭ࠧ྿"),l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ࿀"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿁"),menu_name+title2,url,254,l1111_l1_ (u"ࠩࠪ࿂"),l1111_l1_ (u"ࠪࠫ࿃"),l1lll1l1_l1_)
	return
l1l11l11l_l1_ = [l1111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭࿄"),l1111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭࿅"),l1111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶ࿆ࠬ")]
l1l111ll1_l1_ = [l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ࿇"),l1111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ࿈"),l1111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ࿉"),l1111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ࿊"),l1111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭࿋"),l1111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭࿌"),l1111_l1_ (u"࠭ࡲࡢࡶࡨࠫ࿍")]
def l11lllll1_l1_(url):
	l11l1l1ll_l1_ = l1111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠲࠱࠴࠴࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡍࡵ࡭ࡦ࠰ࡳ࡬ࡵ࠭࿎")
	url = url.replace(l1111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࠬ࿏"),l11l1l1ll_l1_)
	url = url.replace(l1111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪ࿐"),l1111_l1_ (u"ࠪࠫ࿑"))
	if l11l1l1ll_l1_ not in url: url = url+l11l1l1ll_l1_
	url = url.replace(l1111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ࿒"),l1111_l1_ (u"ࠬࡿࡥࡢࡴࠪ࿓"))
	url = url.replace(l1111_l1_ (u"࠭࠿ࡀࠩ࿔"),l1111_l1_ (u"ࠧࡀࠩ࿕"))
	url = url.replace(l1111_l1_ (u"ࠨࠨࠩࠫ࿖"),l1111_l1_ (u"ࠩࠩࠫ࿗"))
	url = url.replace(l1111_l1_ (u"ࠪࡁࡂ࠭࿘"),l1111_l1_ (u"ࠫࡂ࠭࿙"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭࿚"),l1111_l1_ (u"࠭ࠧ࿛"),l1111_l1_ (u"ࠧࠨ࿜"),l1111_l1_ (u"ࠨࡒࡕࡉࡕࡇࡒࡆࡡࡉࡍࡑ࡚ࡅࡓࡡࡉࡍࡓࡇࡌࡠࡗࡕࡐࠬ࿝"))
	return url
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ࿞"),l1111_l1_ (u"ࠪࠫ࿟"),filters,l1111_l1_ (u"ࠫࡎࡔࠠࠡࠢࠣࠫ࿠")+mode)
	# mode==l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ࿡")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ࿢")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠧࡢ࡮࡯ࠫ࿣")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	filters = filters.strip(l1111_l1_ (u"ࠨࠨࠩࠫ࿤"))
	l1l1l111_l1_,l1lll11l_l1_ = {},l1111_l1_ (u"ࠩࠪ࿥")
	if l1111_l1_ (u"ࠪࡁࡂ࠭࿦") in filters:
		items = filters.split(l1111_l1_ (u"ࠫࠫࠬࠧ࿧"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠬࡃ࠽ࠨ࿨"))
			l1l1l111_l1_[var] = value
	for key in l1l111ll1_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"࠭࠰ࠨ࿩")
		if l1111_l1_ (u"ࠧࠦࠩ࿪") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ࿫") and value!=l1111_l1_ (u"ࠩ࠳ࠫ࿬"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠪࠤ࠰ࠦࠧ࿭")+value
		elif mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ࿮") and value!=l1111_l1_ (u"ࠬ࠶ࠧ࿯"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠦࠧࠩ࿰")+key+l1111_l1_ (u"ࠧ࠾࠿ࠪ࿱")+value
		elif mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࠬ࿲"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ࿳")+key+l1111_l1_ (u"ࠪࡁࡂ࠭࿴")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠫࠥ࠱ࠠࠨ࿵"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠬࠬࠦࠨ࿶"))
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ࿷"),l1111_l1_ (u"ࠧࠨ࿸"),l1lll11l_l1_,l1111_l1_ (u"ࠨࡑࡘࡘࠬ࿹"))
	return l1lll11l_l1_
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l1ll111_l1_(l1111_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ傉"),l1111_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ傊"))
#url = l1111_l1_ (u"ࠫࡈࡀ࡜࡝ࡒࡲࡶࡹࡧࡢ࡭ࡧࠣࡔࡷࡵࡧࡳࡣࡰࡷࡡࡢࡋࡐࡆࡌࡣࡻ࠷࠸ࡠ࠸࠷ࡦ࡮ࡺ࡜࡝ࡍࡲࡨ࡮ࡢ࡜ࡱࡱࡵࡸࡦࡨ࡬ࡦࡡࡧࡥࡹࡧ࡜࡝ࡥࡤࡧ࡭࡫࡜࡝ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸࡢ࡜ࡧ࡫࡯ࡩࡤ࠶࠸࠺࠸ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪ傋")
#url = l1111_l1_ (u"ࠬࡩ࠺࡝࡞ࡤࡷࡩ࡬࠮࡮ࡲ࠶ࠫ傌")
#url = l1111_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡶࡨ࡫࠴࡭ࡱ࠵ࠪ傍")
#url = l1111_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡤࡷࡩ࡬࠮࡮ࡲ࠶ࠫ傎")
url = l1111_l1_ (u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ๅา฻࠮࡮ࡲ࠶ࠫ傏")
url = l1111_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠ࡫࡯࡬ࡦࡡ࠷࠼࠸࠺࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧ傐")
#url = url.decode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ傑"))
xbmc.Player().play(url)
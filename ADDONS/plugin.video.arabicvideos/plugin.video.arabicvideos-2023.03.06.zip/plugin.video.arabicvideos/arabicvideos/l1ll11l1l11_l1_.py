# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_ = l1111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭┍")
menu_name=l1111_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ┎")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l1ll1111l1_l1_ = l111lll_l1_[l111_l1_][1]
l1ll111l111_l1_ = l111lll_l1_[l111_l1_][2]
l1ll111l1l1_l1_ = l111lll_l1_[l111_l1_][3]
#l1ll11l1111_l1_  = l111lll_l1_[l111_l1_][4]
#l1ll11l1111_l1_  = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,page,text):
	if   mode==20: l11l_l1_ = l1ll111l1ll_l1_()
	elif mode==21: l11l_l1_ = l11l111_l1_(url)
	elif mode==22: l11l_l1_ = l1l11l1_l1_(url,page)
	elif mode==23: l11l_l1_ = l1l11ll_l1_(url,page)
	elif mode==24: l11l_l1_ = l1lllll_l1_(url,text)
	elif mode==25: l11l_l1_ = l1l1lllllll_l1_(url)
	elif mode==27: l11l_l1_ = l1l1ll1ll_l1_(url)
	elif mode==28: l11l_l1_ = l1ll111lll1_l1_()
	elif mode==29: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l1ll111l1ll_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┏"),menu_name+l1111_l1_ (u"ࠪ฽ึฮ๊ࠨ┐"),l1ll11l_l1_,21,l1111_l1_ (u"ࠫࠬ┑"),l1111_l1_ (u"ࠬ࠷࠰࠲ࠩ┒"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),menu_name+l1111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ└"),l1ll1111l1_l1_,21,l1111_l1_ (u"ࠨࠩ┕"),l1111_l1_ (u"ࠩ࠴࠴࠶࠭┖"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┗"),menu_name+l1111_l1_ (u"ࠫๆอัิ๋ࠪ┘"),l1ll111l111_l1_,21,l1111_l1_ (u"ࠬ࠭┙"),l1111_l1_ (u"࠭࠱࠱࠳ࠪ┚"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┛"),menu_name+l1111_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ├"),l1ll111l1l1_l1_,21,l1111_l1_ (u"ࠩࠪ┝"),l1111_l1_ (u"ࠪ࠵࠵࠷ࠧ┞"))
	return
def l1ll111lll1_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ┟"),menu_name+l1111_l1_ (u"ࠬ฿ัษ์ࠪ┠"),l1ll11l_l1_,27)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫ┡"),menu_name+l1111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ┢"),l1ll1111l1_l1_,27)
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭┣"),menu_name+l1111_l1_ (u"ࠩไหึู้ࠨ┤"),l1ll111l111_l1_,27)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ┥"),menu_name+l1111_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ┦"),l1ll111l1l1_l1_,27)
	return
def l11l111_l1_(l1ll111llll_l1_):
	l111_l1_ = l1ll111llll_l1_
	if l1ll111llll_l1_==l1111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ┧"): l1ll111llll_l1_ = l1ll11l_l1_
	elif l1ll111llll_l1_==l1111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭┨"): l1ll111llll_l1_ = l1ll1111l1_l1_
	else: l111_l1_ = l1111_l1_ (u"ࠧࠨ┩")
	lang = l1ll11l111l_l1_(l1ll111llll_l1_)
	if lang==l1111_l1_ (u"ࠨࡣࡵࠫ┪") or l111_l1_==l1111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ┫"):
		l1ll111111l_l1_ = l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ┬")
		l1ll1111111_l1_ = l1111_l1_ (u"ู๊ࠫไิๆสฮࠥ࠳ࠠฮษ็๎ฮ࠭┭")
		name2 = l1111_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡละำะ࠭┮")
		l1ll11111l1_l1_ = l1111_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢฦฬัี๊ࠨ┯")
		l1ll1111l11_l1_ = l1111_l1_ (u"ࠧษอࠣั๏ࠦย๋ࠢไ๎้๋ࠧ┰")
		l1ll11111ll_l1_ = l1111_l1_ (u"ࠨลไ่ฬ๋ࠧ┱")
		l1ll1111ll1_l1_ = l1111_l1_ (u"่ࠩ์ุ๐โ๊ࠩ┲")
		l1ll1111l1l_l1_ = l1111_l1_ (u"ࠪฬึอๅอࠩ┳")
	elif lang==l1111_l1_ (u"ࠫࡪࡴࠧ┴") or l111_l1_==l1111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ┵"):
		l1ll111111l_l1_ = l1111_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡩ࡯ࠢࡶ࡭ࡹ࡫ࠧ┶")
		l1ll1111111_l1_ = l1111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠮ࠢࡆࡹࡷࡸࡥ࡯ࡶࠪ┷")
		name2 = l1111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡐࡦࡺࡥࡴࡶࠪ┸")
		l1ll11111l1_l1_ = l1111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡆࡲࡰࡩࡣࡥࡩࡹ࠭┹")
		l1ll1111l11_l1_ = l1111_l1_ (u"ࠪࡐ࡮ࡼࡥࠡ࡫ࡉ࡭ࡱࡳࠠࡤࡪࡤࡲࡳ࡫࡬ࠨ┺")
		l1ll11111ll_l1_ = l1111_l1_ (u"ࠫࡒࡵࡶࡪࡧࡶࠫ┻")
		l1ll1111ll1_l1_ = l1111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ┼")
		l1ll1111l1l_l1_ = l1111_l1_ (u"࠭ࡓࡩࡱࡺࡷࠬ┽")
	elif lang in [l1111_l1_ (u"ࠧࡧࡣࠪ┾"),l1111_l1_ (u"ࠨࡨࡤ࠶ࠬ┿")]:
		l1ll111111l_l1_ = l1111_l1_ (u"ࠩฯืฯา่ࠡัิࠤุอ໌หࠩ╀")
		l1ll1111111_l1_ = l1111_l1_ (u"ࠪืึ๐วๅࠢ࠰ࠤัอัໍࠩ╁")
		name2 = l1111_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥศฮา໎้ࠫ╂")
		l1ll11111l1_l1_ = l1111_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦวๅใหหࠬ╃")
		l1ll1111l11_l1_ = l1111_l1_ (u"࠭๾ฯึࠣึ๋ี็ࠡษํࠤๆ๐ไๆࠩ╄")
		l1ll11111ll_l1_ = l1111_l1_ (u"ࠧโ์็้ࠬ╅")
		l1ll1111ll1_l1_ = l1111_l1_ (u"ࠨ็๋ื๏่้ࠨ╆")
		l1ll1111l1l_l1_ = l1111_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠬ╇")
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╈"),menu_name+l1ll111111l_l1_,l1ll111llll_l1_,29,l1111_l1_ (u"ࠫࠬ╉"),l1111_l1_ (u"ࠬ࠭╊"),l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ╋"))
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ╌"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ╍")+menu_name+l1ll1111l11_l1_,l1ll111llll_l1_,27)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ╎"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ╏"),l1111_l1_ (u"ࠫࠬ═"),9999)
	l1ll1llll1_l1_ = [l1111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ║"),l1111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ╒"),l1111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭╓")]
	html = l111l11_l1_(l111ll_l1_,l1ll111llll_l1_+l1111_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧ╔"),l1111_l1_ (u"ࠩࠪ╕"),l1111_l1_ (u"ࠪࠫ╖"),l1111_l1_ (u"ࠫࠬ╗"),l1111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭╘"))
	l111l1l_l1_=re.findall(l1111_l1_ (u"࠭ࡢࡶࡶࡷࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠱ࡆࡳࡳࡺࡡࡤࡶࠪ╙"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭╚"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if any(value in l1l111l_l1_ for value in l1ll1llll1_l1_):
				url = l1ll111llll_l1_+l1l111l_l1_
				if l1111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ╛") in l1l111l_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╜"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ╝")+menu_name+l1ll1111111_l1_,url,22,l1111_l1_ (u"ࠫࠬ╞"),l1111_l1_ (u"ࠬ࠷࠰࠱ࠩ╟"))
					l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╠"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ╡")+menu_name+name2,url,22,l1111_l1_ (u"ࠨࠩ╢"),l1111_l1_ (u"ࠩ࠴࠴࠶࠭╣"))
					l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╤"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ╥")+menu_name+l1ll11111l1_l1_,url,22,l1111_l1_ (u"ࠬ࠭╦"),l1111_l1_ (u"࠭࠲࠱࠳ࠪ╧"))
				elif l1111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ╨") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╩"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭╪")+menu_name+l1ll11111ll_l1_,url,22,l1111_l1_ (u"ࠪࠫ╫"),l1111_l1_ (u"ࠫ࠶࠶࠰ࠨ╬"))
				elif l1111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ╭") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╮"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ╯")+menu_name+l1ll1111ll1_l1_,url,25,l1111_l1_ (u"ࠨࠩ╰"),l1111_l1_ (u"ࠩ࠴࠴࠶࠭╱"))
				elif l1111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ╲") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╳"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ╴")+menu_name+l1ll1111l1l_l1_,url,22,l1111_l1_ (u"࠭ࠧ╵"),l1111_l1_ (u"ࠧ࠲࠲࠴ࠫ╶"))
	return html
def l1l1lllllll_l1_(url):
	l1ll111llll_l1_ = l1ll1111lll_l1_(url)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠨࠩ╷"),l1111_l1_ (u"ࠩࠪ╸"),l1111_l1_ (u"ࠪࠫ╹"),l1111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡑ࡚࡙ࡉࡄࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ╺"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦ࠱ࡹࡵ࡯࡭ࡵ࠰࡬ࡪࡧࡤࡦࡴࠫ࠲࠯ࡅࠩࡎࡷࡶ࡭ࡨ࠳ࡢࡰࡦࡼࠫ╻"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	title = re.findall(l1111_l1_ (u"࠭࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ╼"),block,re.DOTALL)[0]
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╽"),menu_name+title,url,22,l1111_l1_ (u"ࠨࠩ╾"),l1111_l1_ (u"ࠩ࠴࠴࠶࠭╿"))
	items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ▀"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll111llll_l1_ + l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▁"),menu_name+title,l1l111l_l1_,23,l1111_l1_ (u"ࠬ࠭▂"),l1111_l1_ (u"࠭࠱࠱࠳ࠪ▃"))
	return
def l1l11l1_l1_(url,page):
	l1ll111llll_l1_ = l1ll1111lll_l1_(url)
	lang = l1ll11l111l_l1_(url)
	type = url.split(l1111_l1_ (u"ࠧ࠰ࠩ▄"))[-1]
	l1l1lllll11_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ▅"),l1111_l1_ (u"ࠩࠪ▆"),url, type)
	if type==l1111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ▇") and page==l1111_l1_ (u"ࠫ࠵࠭█"):
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠬ࠭▉"),l1111_l1_ (u"࠭ࠧ▊"),l1111_l1_ (u"ࠧࠨ▋"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ▌"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨ▍"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠪ࠱࠮ࡄ࠯࠾࠯ࠬࡂ࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭▎"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			title = escapeUNICODE(title)
			title = l1l1111_l1_(title)
			l1l111l_l1_ = l1ll111llll_l1_ + l1l111l_l1_
			img = l1ll111llll_l1_ + QUOTE(img)
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▏"),menu_name+title,l1l111l_l1_,23,img,l1l1lllll11_l1_+l1111_l1_ (u"ࠬ࠶࠱ࠨ▐"))
	l1l1lllll1l_l1_=0
	if type==l1111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭░"): category=l1111_l1_ (u"ࠧ࠴ࠩ▒")
	if type==l1111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭▓"): category=l1111_l1_ (u"ࠩ࠸ࠫ▔")
	if type==l1111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ▕"): category=l1111_l1_ (u"ࠫ࠼࠭▖")
	if type in [l1111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ▗"),l1111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ▘"),l1111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ▙")] and page!=l1111_l1_ (u"ࠨ࠲ࠪ▚"):
		l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡒࡤ࡫ࡪ࡯࡮ࡨࡋࡷࡩࡲࡅࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ▛")+category+l1111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ▜")+page+l1111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬ࡯ࡳࡦࡨࡶࡧࡿ࠽ࠨ▝")+l1l1lllll11_l1_
		html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭▞"),l1111_l1_ (u"࠭ࠧ▟"),l1111_l1_ (u"ࠧࠨ■"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ□"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ▢"),l1111_l1_ (u"ࠪࠫ▣"),l1l1lll_l1_, html)
		items = re.findall(l1111_l1_ (u"ࠫࠧࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠮ࡃࠧࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ▤"),html,re.DOTALL)
		for id,title,img in items:
			title = escapeUNICODE(title)
			title = title.replace(l1111_l1_ (u"ࠬࡢ࡜ࠨ▥"),l1111_l1_ (u"࠭ࠧ▦"))
			title = title.replace(l1111_l1_ (u"ࠧࠣࠩ▧"),l1111_l1_ (u"ࠨࠩ▨"))
			l1l1lllll1l_l1_ += 1
			l1l111l_l1_ = l1ll111llll_l1_ + l1111_l1_ (u"ࠩ࠲ࠫ▩") + type + l1111_l1_ (u"ࠪ࠳ࡈࡵ࡮ࡵࡧࡱࡸ࠴࠭▪") + id
			img = l1ll111llll_l1_ + QUOTE(img)
			if type==l1111_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ▫"): l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ▬"),menu_name+title,l1l111l_l1_,24,img,l1l1lllll11_l1_+l1111_l1_ (u"࠭࠰࠲ࠩ▭"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▮"),menu_name+title,l1l111l_l1_,23,img,l1l1lllll11_l1_+l1111_l1_ (u"ࠨ࠲࠴ࠫ▯"))
	if type==l1111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ▰"):
		html = l111l11_l1_(l1111l1_l1_,l1ll111llll_l1_+l1111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡍࡳࡪࡥࡹࡁࡳࡥ࡬࡫࠽ࠨ▱")+page,l1111_l1_ (u"ࠫࠬ▲"),l1111_l1_ (u"ࠬ࠭△"),l1111_l1_ (u"࠭ࠧ▴"),l1111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠳ࡳࡦࠪ▵"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠲ࡪࡥ࡮ࡱࠫ࠲࠯ࡅࠩࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ࠱ࡩ࡫࡭ࡰࠩ▶"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ▷"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			l1l1lllll1l_l1_ += 1
			img = l1ll111llll_l1_ + img
			l1l111l_l1_ = l1ll111llll_l1_ + l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▸"),menu_name+title,l1l111l_l1_,23,img,l1111_l1_ (u"ࠫ࠶࠶࠱ࠨ▹"))
	if l1l1lllll1l_l1_>20:
		title=l1111_l1_ (u"ࠬ฻แฮหࠣࠫ►")
		if lang==l1111_l1_ (u"࠭ࡥ࡯ࠩ▻"): title = l1111_l1_ (u"ࠧࡑࡣࡪࡩࠥ࠭▼")
		if lang==l1111_l1_ (u"ࠨࡨࡤࠫ▽"): title = l1111_l1_ (u"ุࠩๅาํࠠࠨ▾")
		if lang==l1111_l1_ (u"ࠪࡪࡦ࠸ࠧ▿"): title = l1111_l1_ (u"ฺࠫ็อ่ࠢࠪ◀")
		for l1ll111l11l_l1_ in range(1,11) :
			if not page==str(l1ll111l11l_l1_):
				l1l1llllll1_l1_ = l1111_l1_ (u"ࠬ࠶ࠧ◁")+str(l1ll111l11l_l1_)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◂"),menu_name+title+str(l1ll111l11l_l1_),url,22,l1111_l1_ (u"ࠧࠨ◃"),l1l1lllll11_l1_+l1l1llllll1_l1_[-2:])
	return
def l1l11ll_l1_(url,page):
	l1ll111llll_l1_ = l1ll1111lll_l1_(url)
	l1ll11l1111_l1_ = l1ll1111lll_l1_(url)
	lang = l1ll11l111l_l1_(url)
	parts = url.split(l1111_l1_ (u"ࠨ࠱ࠪ◄"))
	id,type = parts[-1],parts[3]
	l1l1lllll11_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	l1l1lllll1l_l1_ = 0
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ◅"),l1111_l1_ (u"ࠪࠫ◆"),url, type)
	if type==l1111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ◇"):
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠬ࠭◈"),l1111_l1_ (u"࠭ࠧ◉"),l1111_l1_ (u"ࠧࠨ◊"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭○"))
		items = re.findall(l1111_l1_ (u"ࠩࡆࡳࡲࡳࡥ࡯ࡶࡢࡴࡦࡴࡥ࡭ࡡࡌࡸࡪࡳ࠮ࠫࡁࡳࡂ࠭࠴ࠪࡀࠫ࠿࡭࠳࠱࠿ࡷࡣࡵࠤ࡮ࡴࡴࡦࡴࡢࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࡠࠬ࠭◌"),html,re.DOTALL)
		title = l1111_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦࠧ◍")
		if lang==l1111_l1_ (u"ࠫࡪࡴࠧ◎"): title = l1111_l1_ (u"ࠬࠦ࠭ࠡࡇࡳ࡭ࡸࡵࡤࡦࠢࠪ●")
		if lang==l1111_l1_ (u"࠭ࡦࡢࠩ◐"): title = l1111_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ◑")
		if lang==l1111_l1_ (u"ࠨࡨࡤ࠶ࠬ◒"): title = l1111_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ◓")
		if lang==l1111_l1_ (u"ࠪࡪࡦ࠭◔"): l1ll111ll11_l1_ = l1111_l1_ (u"ࠫࠬ◕")
		else: l1ll111ll11_l1_ = lang
		l1ll11l11l1_l1_ = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࡢ࠭࠭࠴ࠪࡀࠫࠥࡂࠬ◖"),html,re.DOTALL)
		for name,count,img,l1l111l_l1_ in items:
			for l11l11l_l1_ in range(int(count),0,-1):
				l1l11l1ll_l1_ = img + l1ll111ll11_l1_ + id + l1111_l1_ (u"࠭࠯ࠨ◗") + str(l11l11l_l1_) + l1111_l1_ (u"ࠧ࠯ࡲࡱ࡫ࠬ◘")
				#l111111111_l1_ = l1ll11l11l1_l1_[0][0]+lang+id+l1111_l1_ (u"ࠨ࠱࠯ࠫ◙")+str(l11l11l_l1_)+l1111_l1_ (u"ࠩ࠯ࠫ◚")+str(l11l11l_l1_)+l1111_l1_ (u"ࠪࡣࠬ◛")+l1ll11l11l1_l1_[0][2]
				l1ll1111111_l1_ = name + title + str(l11l11l_l1_)
				l1ll1111111_l1_ = l1l1111_l1_(l1ll1111111_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ◜"),menu_name+l1ll1111111_l1_,url,24,l1l11l1ll_l1_,l1111_l1_ (u"ࠬ࠭◝"),str(l11l11l_l1_))
	elif type==l1111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ◞"):
		l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"ࠧ࠰ࡊࡲࡱࡪ࠵ࡐࡢࡩࡨ࡭ࡳ࡭ࡁࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡌࡸࡪࡳ࠿ࡪࡦࡀࠫ◟")+str(id)+l1111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ◠")+page+l1111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡴࡸࡤࡦࡴࡥࡽࡂ࠷ࠧ◡")
		html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ◢"),l1111_l1_ (u"ࠫࠬ◣"),l1111_l1_ (u"ࠬ࠭◤"),l1111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ◥"))
		items = re.findall(l1111_l1_ (u"ࠧࡆࡲ࡬ࡷࡴࡪࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡊࡩࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ◦"),html,re.DOTALL)
		title = l1111_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ◧")
		if lang==l1111_l1_ (u"ࠩࡨࡲࠬ◨"): title = l1111_l1_ (u"ࠪࠤ࠲ࠦࡅࡱ࡫ࡶࡳࡩ࡫ࠠࠨ◩")
		if lang==l1111_l1_ (u"ࠫ࡫ࡧࠧ◪"): title = l1111_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ◫")
		if lang==l1111_l1_ (u"࠭ࡦࡢ࠴ࠪ◬"): title = l1111_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ◭")
		for l11l11l_l1_,img,l1l111l_l1_,desc,name in items:
			l1l1lllll1l_l1_ += 1
			l1l11l1ll_l1_ = l1ll11l1111_l1_ + QUOTE(img)
			#l111111111_l1_ = l1ll11l1111_l1_ + QUOTE(l1l111l_l1_)
			name = escapeUNICODE(name)
			l1ll1111111_l1_ = name + title + str(l11l11l_l1_)
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ◮"),menu_name+l1ll1111111_l1_,l1l1lll_l1_,24,l1l11l1ll_l1_,l1111_l1_ (u"ࠩࠪ◯"),str(l1l1lllll1l_l1_))
	elif type==l1111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ◰"):
		if l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸࠬ◱") in url and l1111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ◲") not in url:
			l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽ࠨ◳")+str(id)+l1111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ◴")+page+l1111_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠲ࠪ◵")
			html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ◶"),l1111_l1_ (u"ࠪࠫ◷"),l1111_l1_ (u"ࠫࠬ◸"),l1111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠳ࡳࡦࠪ◹"))
			items = re.findall(l1111_l1_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛ࡵࡩࡤࡧࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ◺"),html,re.DOTALL)
			for img,l1l111l_l1_,name,title in items:
				l1l1lllll1l_l1_ += 1
				l1l11l1ll_l1_ = l1ll11l1111_l1_ + QUOTE(img)
				#l111111111_l1_ = l1ll11l1111_l1_ + QUOTE(l1l111l_l1_)
				l1ll1111111_l1_ = name + l1111_l1_ (u"ࠧࠡ࠯ࠣࠫ◻") + title
				l1ll1111111_l1_ = l1ll1111111_l1_.strip(l1111_l1_ (u"ࠨࠢࠪ◼"))
				l1ll1111111_l1_ = escapeUNICODE(l1ll1111111_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ◽"),menu_name+l1ll1111111_l1_,l1l1lll_l1_,24,l1l11l1ll_l1_,l1111_l1_ (u"ࠪࠫ◾"),str(l1l1lllll1l_l1_))
		elif l1111_l1_ (u"ࠫࡈࡲࡩࡱࡵࠪ◿") in url:
			l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ☀")+page+l1111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠱࠶ࠩ☁")
			html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠧࠨ☂"),l1111_l1_ (u"ࠨࠩ☃"),l1111_l1_ (u"ࠩࠪ☄"),l1111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠹ࡺࡨࠨ★"))
			items = re.findall(l1111_l1_ (u"ࠫࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗ࡫ࡧࡩࡴࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ☆"),html,re.DOTALL)
			for img,title,l1l111l_l1_ in items:
				l1l1lllll1l_l1_ += 1
				l1l11l1ll_l1_ = l1ll11l1111_l1_ + QUOTE(img)
				#l111111111_l1_ = l1ll11l1111_l1_ + QUOTE(l1l111l_l1_)
				l1ll1111111_l1_ = title.strip(l1111_l1_ (u"ࠬࠦࠧ☇"))
				l1ll1111111_l1_ = escapeUNICODE(l1ll1111111_l1_)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ☈"),menu_name+l1ll1111111_l1_,l1l1lll_l1_,24,l1l11l1ll_l1_,l1111_l1_ (u"ࠧࠨ☉"),str(l1l1lllll1l_l1_))
		elif l1111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ☊") in url:
			if l1111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠻࠭☋") in url:
				l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁ࠵ࠬࡰࡢࡩࡨࡁࠬ☌")+page+l1111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠻࠭☍")
				html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭☎"),l1111_l1_ (u"࠭ࠧ☏"),l1111_l1_ (u"ࠧࠨ☐"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠸ࡸ࡭࠭☑"))
			elif l1111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠹࠭☒") in url:
				l1l1lll_l1_ = l1ll111llll_l1_+l1111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁ࠵ࠬࡰࡢࡩࡨࡁࠬ☓")+page+l1111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠹࠭☔")
				html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭☕"),l1111_l1_ (u"࠭ࠧ☖"),l1111_l1_ (u"ࠧࠨ☗"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠹ࡸ࡭࠭☘"))
			items = re.findall(l1111_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ☙"),html,re.DOTALL)
			for img,l1l111l_l1_,name,title in items:
				l1l1lllll1l_l1_ += 1
				l1l11l1ll_l1_ = l1ll11l1111_l1_ + QUOTE(img)
				#l111111111_l1_ = l1ll11l1111_l1_ + QUOTE(l1l111l_l1_)
				l1ll1111111_l1_ = name + l1111_l1_ (u"ࠪࠤ࠲ࠦࠧ☚") + title
				l1ll1111111_l1_ = l1ll1111111_l1_.strip(l1111_l1_ (u"ࠫࠥ࠭☛"))
				l1ll1111111_l1_ = escapeUNICODE(l1ll1111111_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ☜"),menu_name+l1ll1111111_l1_,l1l1lll_l1_,24,l1l11l1ll_l1_,l1111_l1_ (u"࠭ࠧ☝"),str(l1l1lllll1l_l1_))
	if type==l1111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭☞") or type==l1111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ☟"):
		if l1l1lllll1l_l1_>25:
			title=l1111_l1_ (u"ุࠩๅาฯࠠࠨ☠")
			if lang==l1111_l1_ (u"ࠪࡩࡳ࠭☡"): title = l1111_l1_ (u"ࠫࠥࡖࡡࡨࡧࠣࠫ☢")
			if lang==l1111_l1_ (u"ࠬ࡬ࡡࠨ☣"): title = l1111_l1_ (u"࠭ࠠึใะ๋ࠥ࠭☤")
			if lang==l1111_l1_ (u"ࠧࡧࡣ࠵ࠫ☥"): title = l1111_l1_ (u"ࠨุࠢๅาํࠠࠨ☦")
			for l1ll111l11l_l1_ in range(1,11):
				if not page==str(l1ll111l11l_l1_):
					l1l1llllll1_l1_ = l1111_l1_ (u"ࠩ࠳ࠫ☧")+str(l1ll111l11l_l1_)
					l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☨"),menu_name+title+str(l1ll111l11l_l1_),url,23,l1111_l1_ (u"ࠫࠬ☩"),l1l1lllll11_l1_+l1l1llllll1_l1_[-2:])
	return
def l1lllll_l1_(url,l11l11l_l1_):
	l1ll11l1111_l1_ = l1ll1111lll_l1_(url)
	l11111l_l1_,l11lll1l_l1_ = [],[]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠬ࠭☪"),l1111_l1_ (u"࠭ࠧ☫"),l1111_l1_ (u"ࠧࠨ☬"),l1111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ☭"))
	# l1llll11_l1_ l1llll111_l1_ l11l1ll1_l1_
	items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡷ࡫ࡧࡩࡴࡃࠢࠩ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭࡟ࠪࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ☮"),html,re.DOTALL)
	if items:
		lang = l1ll11l111l_l1_(url)
		parts = url.split(l1111_l1_ (u"ࠪ࠳ࠬ☯"))
		id,type = parts[-1],parts[3]
		l1l111l_l1_ = items[0][0]+lang+id+l1111_l1_ (u"ࠫ࠴࠲ࠧ☰")+l11l11l_l1_+l1111_l1_ (u"ࠬ࠲ࠧ☱")+l11l11l_l1_+l1111_l1_ (u"࠭࡟ࠨ☲")+items[0][2]
		l11111l_l1_.append(l1111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ☳"))
		l11lll1l_l1_.append(l1l111l_l1_)
	# l1llll11_l1_ l1111l1l_l1_ url
	items = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࠪࠪ࡟࠲࠳࠰࠿ࠪࠤࠪ☴"),html,re.DOTALL)
	if items:
		lang = l1ll11l111l_l1_(url)
		parts = url.split(l1111_l1_ (u"ࠩ࠲ࠫ☵"))
		id,type = parts[-1],parts[3]
		l1l111l_l1_ = items[0][0]+lang+id+l1111_l1_ (u"ࠪ࠳ࠬ☶")+l11l11l_l1_+items[0][2]
		l11111l_l1_.append(l1111_l1_ (u"ࠫࡲࡶ࠴ࠡࡷࡵࡰࠬ☷"))
		l11lll1l_l1_.append(l1l111l_l1_)
	# l1llll11_l1_ l1111l1l_l1_ src
	items = re.findall(l1111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ☸"),html,re.DOTALL)
	for l1l111l_l1_ in items:
		l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"࠭࠯࠰ࠩ☹"),l1111_l1_ (u"ࠧ࠰ࠩ☺"))
		l11111l_l1_.append(l1111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࡹࡲࡤࠩ☻"))
		l11lll1l_l1_.append(l1l111l_l1_)
	# l1ll111ll1l_l1_ l1111l1l_l1_ l11l1ll1_l1_
	items = re.findall(l1111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ☼"),html,re.DOTALL)
	if items:
		l1l111l_l1_ = items[int(l11l11l_l1_)-1]
		l1l111l_l1_ = l1ll11l1111_l1_+QUOTE(l1l111l_l1_)
		l11111l_l1_.append(l1111_l1_ (u"ࠪࡱࡵ࠺ࠠࡢࡦࡧࡶࡪࡹࡳࠨ☽"))
		l11lll1l_l1_.append(l1l111l_l1_)
	# l1ll111ll1l_l1_ l1ll11l11ll_l1_ l11l1ll1_l1_
	items = re.findall(l1111_l1_ (u"࡛ࠫࡵࡩࡤࡧࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ☾"),html,re.DOTALL)
	if items:
		l1l111l_l1_ = items[int(l11l11l_l1_)-1]
		l1l111l_l1_ = l1ll11l1111_l1_+QUOTE(l1l111l_l1_)
		l11111l_l1_.append(l1111_l1_ (u"ࠬࡳࡰ࠴ࠢࡤࡨࡩࡸࡥࡴࡵࠪ☿"))
		l11lll1l_l1_.append(l1l111l_l1_)
	# l1l_l1_
	if len(l11lll1l_l1_)==1: l1l111l_l1_ = l11lll1l_l1_[0]
	else:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ♀"), l11111l_l1_)
		if l1l_l1_ == -1 : return
		l1l111l_l1_ = l11lll1l_l1_[l1l_l1_]
	l1ll11ll1_l1_(l1l111l_l1_,l111_l1_,l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭♁"))
	return
def l1ll1111lll_l1_(url):
	if l1ll11l_l1_ in url: site = l1ll11l_l1_
	elif l1ll1111l1_l1_ in url: site = l1ll1111l1_l1_
	elif l1ll111l111_l1_ in url: site = l1ll111l111_l1_
	elif l1ll111l1l1_l1_ in url: site = l1ll111l1l1_l1_
	else: site = l1111_l1_ (u"ࠨࠩ♂")
	return site
def l1ll11l111l_l1_(url):
	if   l1ll11l_l1_ in url: lang = l1111_l1_ (u"ࠩࡤࡶࠬ♃")
	elif l1ll1111l1_l1_ in url: lang = l1111_l1_ (u"ࠪࡩࡳ࠭♄")
	elif l1ll111l111_l1_ in url: lang = l1111_l1_ (u"ࠫ࡫ࡧࠧ♅")
	elif l1ll111l1l1_l1_ in url: lang = l1111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ♆")
	else: lang = l1111_l1_ (u"࠭ࠧ♇")
	return lang
def l1l1ll1ll_l1_(url):
	lang = l1ll11l111l_l1_(url)
	l1l1lll_l1_ = url + l1111_l1_ (u"ࠧ࠰ࡊࡲࡱࡪ࠵ࡌࡪࡸࡨࠫ♈")
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ♉"),l1l1lll_l1_,l1111_l1_ (u"ࠩࠪ♊"),l1111_l1_ (u"ࠪࠫ♋"),l1111_l1_ (u"ࠫࠬ♌"),l1111_l1_ (u"ࠬ࠭♍"),l1111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ♎"))
	html = response.content
	items = re.findall(l1111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ♏"),html,re.DOTALL)
	l11l11_l1_ = items[0]
	l1ll11ll1_l1_(l11l11_l1_,l111_l1_,l1111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭♐"))
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search:
		search = l11ll_l1_()
		if not search: return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"ࠩࠣࠫ♑"),l1111_l1_ (u"ࠪ࠯ࠬ♒"))
	if l1ll11_l1_:
		l1ll1lll1l_l1_ = [ l1ll11l_l1_ , l1ll1111l1_l1_ , l1ll111l111_l1_ , l1ll111l1l1_l1_ ]
		l1ll11l1l1l_l1_ = [ l1111_l1_ (u"ࠫ฾ืศ๋ࠩ♓") , l1111_l1_ (u"ࠬࡋ࡮ࡨ࡮࡬ࡷ࡭࠭♔") , l1111_l1_ (u"࠭แศำึํࠬ♕") , l1111_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ♖") ]
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠨษัฮึࠦวๅๆ฽อࠥอไๆ่สือฯ࠺ࠨ♗"), l1ll11l1l1l_l1_)
		if l1l_l1_ == -1 : return
		l1l1lll1_l1_ = l1ll1lll1l_l1_[l1l_l1_]
	else:
		if l1111_l1_ (u"ࠩࡢࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࡡࠪ♘") in options: l1l1lll1_l1_ = l1ll11l_l1_
		elif l1111_l1_ (u"ࠪࡣࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࡣࠬ♙") in options: l1l1lll1_l1_ = l1ll1111l1_l1_
		else: l1l1lll1_l1_ = l1111_l1_ (u"ࠫࠬ♚")
	if not l1l1lll1_l1_: return
	lang = l1ll11l111l_l1_(l1l1lll1_l1_)
	l1l1lll_l1_ = l1l1lll1_l1_ + l1111_l1_ (u"ࠧ࠵ࡈࡰ࡯ࡨ࠳ࡘ࡫ࡡࡳࡥ࡫ࡃࡸ࡫ࡡࡳࡥ࡫ࡷࡹࡸࡩ࡯ࡩࡀࠦ♛") + l1lll1l_l1_
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ♜"),l1111_l1_ (u"ࠧࠨ♝"),lang,l1l1lll_l1_)
	html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠨࠩ♞"),l1111_l1_ (u"ࠩࠪ♟"),l1111_l1_ (u"ࠪࠫ♠"),l1111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ♡"))
	items = re.findall(l1111_l1_ (u"ࠬࠨࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡉࡡࡵࡧࡪࡳࡷࡿࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠩ♢"),html,re.DOTALL)
	if items:
		for img,category,id,title in items:
			#if category in [l1111_l1_ (u"࠭࠳ࠨ♣"),l1111_l1_ (u"ࠧ࠶ࠩ♤"),l1111_l1_ (u"ࠨ࠹ࠪ♥")]:
			if category in [l1111_l1_ (u"ࠩ࠶ࠫ♦"),l1111_l1_ (u"ࠪ࠻ࠬ♧")]:
				title = title.replace(l1111_l1_ (u"ࠫࡡࡢࠧ♨"),l1111_l1_ (u"ࠬ࠭♩"))
				title = title.replace(l1111_l1_ (u"࠭ࠢࠨ♪"),l1111_l1_ (u"ࠧࠨ♫"))
				if category==l1111_l1_ (u"ࠨ࠵ࠪ♬"):
					type = l1111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ♭")
					if lang==l1111_l1_ (u"ࠪࡥࡷ࠭♮"): name = l1111_l1_ (u"ู๊ࠫไิๆࠣ࠾ࠥ࠭♯")
					elif lang==l1111_l1_ (u"ࠬ࡫࡮ࠨ♰"): name = l1111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠺ࠡࠩ♱")
					elif lang==l1111_l1_ (u"ࠧࡧࡣࠪ♲"): name = l1111_l1_ (u"ࠨีิ๎ฬ๊่ࠠษࠣ࠾ࠥ࠭♳")
					elif lang==l1111_l1_ (u"ࠩࡩࡥ࠷࠭♴"): name = l1111_l1_ (u"ࠪืึ๐วๅ๊ࠢหࠥࡀࠠࠨ♵")
				elif category==l1111_l1_ (u"ࠫ࠺࠭♶"):
					type = l1111_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ♷")
					if lang==l1111_l1_ (u"࠭ࡡࡳࠩ♸"): name = l1111_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ♹")
					elif lang==l1111_l1_ (u"ࠨࡧࡱࠫ♺"): name = l1111_l1_ (u"ࠩࡐࡳࡻ࡯ࡥࠡ࠼ࠣࠫ♻")
					elif lang==l1111_l1_ (u"ࠪࡪࡦ࠭♼"): name = l1111_l1_ (u"ࠫๆ๐ไๆࠢ࠽ࠤࠬ♽")
					elif lang==l1111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ♾"): name = l1111_l1_ (u"࠭แๅ็๋ࠣฬࠦ࠺ࠡࠩ♿")
				elif category==l1111_l1_ (u"ࠧ࠸ࠩ⚀"):
					type = l1111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⚁")
					if lang==l1111_l1_ (u"ࠩࡤࡶࠬ⚂"): name = l1111_l1_ (u"ࠪฬึ์วๆฮࠣ࠾ࠥ࠭⚃")
					elif lang==l1111_l1_ (u"ࠫࡪࡴࠧ⚄"): name = l1111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲࠦ࠺ࠡࠩ⚅")
					elif lang==l1111_l1_ (u"࠭ࡦࡢࠩ⚆"): name = l1111_l1_ (u"ࠧษำ้ห๊ํ่ࠠษࠣ࠾ࠥ࠭⚇")
					elif lang==l1111_l1_ (u"ࠨࡨࡤ࠶ࠬ⚈"): name = l1111_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠥࡀࠠࠨ⚉")
				title = name + title
				l1l111l_l1_ = l1l1lll1_l1_ + l1111_l1_ (u"ࠪ࠳ࠬ⚊") + type + l1111_l1_ (u"ࠫ࠴ࡉ࡯࡯ࡶࡨࡲࡹ࠵ࠧ⚋") + id
				img = QUOTE(img)
				img = l1l1lll1_l1_+img
				#LOG_THIS(l1111_l1_ (u"ࠬ࠭⚌"),img)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⚍"),menu_name+title,l1l111l_l1_,23,img,l1111_l1_ (u"ࠧ࠲࠲࠴ࠫ⚎"))
	#else: l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⚏"),l1111_l1_ (u"ࠩࠪ⚐"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⚑"),,لا توجد نتائج للبحث')
	return
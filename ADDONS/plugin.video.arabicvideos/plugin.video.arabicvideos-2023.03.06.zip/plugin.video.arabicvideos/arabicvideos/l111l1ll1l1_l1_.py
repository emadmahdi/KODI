# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ䚖")
headers = { l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䚗") : l1111_l1_ (u"ࠬ࠭䚘") }
menu_name=l1111_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ䚙")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,text):
	if   mode==210: l11l_l1_ = l11l111_l1_()
	elif mode==211: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==212: l11l_l1_ = l1lllll_l1_(url)
	elif mode==213: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==214: l11l_l1_ = l11l1l111l1l_l1_(url)
	elif mode==215: l11l_l1_ = l11l1l111ll1_l1_(url)
	elif mode==218: l11l_l1_ = l1l1ll11l11l_l1_()
	elif mode==219: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l1l1ll11l11l_l1_():
	message = l1111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ䚚")
	l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ䚛"),l1111_l1_ (u"ࠩࠪ䚜"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䚝"),l1111_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ䚞"),message)
	return
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䚟"),menu_name+l1111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䚠"),l1111_l1_ (u"ࠧࠨ䚡"),219,l1111_l1_ (u"ࠨࠩ䚢"),l1111_l1_ (u"ࠩࠪ䚣"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚤"))
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䚥"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠪ䚦"),l1111_l1_ (u"࠭ࠧ䚧"),114,l1ll11l_l1_)
	url = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡓ࡭ࡳࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࡰࡪࡰࠩࡰ࡮ࡳࡩࡵ࠿࠵࠹ࠬ䚨")
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䚩"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭䚪")+menu_name+l1111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ䚫"),url,211)
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠫࠬ䚬"),headers,l1111_l1_ (u"ࠬ࠭䚭"),l1111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䚮"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡇ࡫࡯ࡸࡪࡸࡳࡃࡷࡷࡸࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䚯"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䚰"),block,re.DOTALL)
	for l1l111l_l1_,title in items:#[1:-1]:
		url = l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂ࠭䚱")+l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䚲"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ䚳")+menu_name+title,url,211)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䚴"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䚵"),block,re.DOTALL)
	l11ll11_l1_ = [l1111_l1_ (u"ࠧๆี็ื้อสࠡษ้้๏࠭䚶"),l1111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ䚷")]
	#l111l1ll1_l1_ = [l1111_l1_ (u"่ࠩืู้ไศฬࠣࠫ䚸"),l1111_l1_ (u"ࠪหๆ๊วๆࠢࠪ䚹"),l1111_l1_ (u"ࠫอืวๆฮࠪ䚺"),l1111_l1_ (u"ࠬ฿ัุ้ࠪ䚻"),l1111_l1_ (u"࠭ใๅ์หหฯ࠭䚼"),l1111_l1_ (u"ࠧศ฼ส๊๎࠭䚽")]
	for l1l111l_l1_,title in items:
		title = title.strip(l1111_l1_ (u"ࠨࠢࠪ䚾"))
		if not any(value in title for value in l11ll11_l1_):
		#	if any(value in title for value in l111l1ll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䚿"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ䛀")+menu_name+title,l1l111l_l1_,211)
	return html
def l1l11l1_l1_(url):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬ䛁"),headers,l1111_l1_ (u"ࠬ࠭䛂"),l1111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䛃"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ䛄"),l1111_l1_ (u"ࠨࠩ䛅"),url,html)
	if l1111_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫ䛆") in url or l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ䛇") in url: block = html
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡒ࡫ࡤࡪࡣࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ䛈"),html,re.DOTALL)
		if l111l1l_l1_: block = l111l1l_l1_[0]
		else: return
	items = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䛉"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l11l111ll_l1_ = [l1111_l1_ (u"࠭ๅีษ๊ำฮ࠭䛊"),l1111_l1_ (u"ࠧโ์็้ࠬ䛋"),l1111_l1_ (u"ࠨษ฽๊๏ฯࠧ䛌"),l1111_l1_ (u"ࠩๆ่๏ฮࠧ䛍"),l1111_l1_ (u"ࠪห฾๊ว็ࠩ䛎"),l1111_l1_ (u"ࠫ์ีวโࠩ䛏"),l1111_l1_ (u"๋ࠬศศำสอࠬ䛐"),l1111_l1_ (u"ู࠭าุࠪ䛑"),l1111_l1_ (u"ࠧๆ้ิะฬ์ࠧ䛒"),l1111_l1_ (u"ࠨษ็ฬํ๋ࠧ䛓")]
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䛔") in l1l111l_l1_: continue
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠪ࠳ࠬ䛕"))
		title = l1l1111_l1_(title)
		title = title.strip(l1111_l1_ (u"ࠫࠥ࠭䛖"))
		if l1111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬ䛗") in l1l111l_l1_ or any(value in title for value in l11l111ll_l1_):
			l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䛘"),menu_name+title,l1l111l_l1_,212,img)
		elif l1111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ䛙") in l1l111l_l1_ and l1111_l1_ (u"ࠨษ็ั้่ษࠨ䛚") in title:
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ䛛"),title,re.DOTALL)
			if l11l11l_l1_:
				title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䛜") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䛝"),menu_name+title,l1l111l_l1_,213,img)
					l1lllll1_l1_.append(title)
		else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䛞"),menu_name+title,l1l111l_l1_,213,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䛟"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䛠"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠨษ็ูๆำษࠡࠩ䛡"),l1111_l1_ (u"ࠩࠪ䛢"))
			if title!=l1111_l1_ (u"ࠪࠫ䛣"): l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䛤"),menu_name+l1111_l1_ (u"ࠬ฻แฮหࠣࠫ䛥")+title,l1l111l_l1_,211)
	return
def l1l11ll_l1_(url):
	l11l11lll_l1_,items,l1111lll_l1_ = -1,[],[]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"࠭ࠧ䛦"),headers,l1111_l1_ (u"ࠧࠨ䛧"),l1111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䛨"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡷ࡭࠲ࡲࡩࡴࡶ࠰ࡲࡺࡳࡢࡦࡴࡨࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䛩"),html,re.DOTALL)
	if l111l1l_l1_:
		l1lll11_l1_ = l1111_l1_ (u"ࠪࠫ䛪").join(l111l1l_l1_)
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䛫"),l1lll11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭䛬"))
	for l1l111l_l1_ in items:
		l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"࠭࠯ࠨ䛭"))
		title = l1111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䛮") + l1l111l_l1_.split(l1111_l1_ (u"ࠨ࠱ࠪ䛯"))[-1].replace(l1111_l1_ (u"ࠩ࠰ࠫ䛰"),l1111_l1_ (u"ࠪࠤࠬ䛱"))
		l111l1ll_l1_ = re.findall(l1111_l1_ (u"ࠫฬ๊อๅไฬ࠱࠭ࡢࡤࠬࠫࠪ䛲"),l1l111l_l1_.split(l1111_l1_ (u"ࠬ࠵ࠧ䛳"))[-1],re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = l111l1ll_l1_[0]
		else: l111l1ll_l1_ = l1111_l1_ (u"࠭࠰ࠨ䛴")
		l1111lll_l1_.append([l1l111l_l1_,title,l111l1ll_l1_])
	items = sorted(l1111lll_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11l1l_l1_ = str(items).count(l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ䛵"))
	l11l11lll_l1_ = str(items).count(l1111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ䛶"))
	if l11l11l1l_l1_>1 and l11l11lll_l1_>0 and l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ䛷") not in url:
		for l1l111l_l1_,title,l111l1ll_l1_ in items:
			if l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ䛸") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䛹"),menu_name+title,l1l111l_l1_,213)
	else:
		for l1l111l_l1_,title,l111l1ll_l1_ in items:
			if l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ䛺") not in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䛻"),menu_name+title,l1l111l_l1_,212)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	parts = url.split(l1111_l1_ (u"ࠧ࠰ࠩ䛼"))
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠨࠩ䛽"),headers,l1111_l1_ (u"ࠩࠪ䛾"),l1111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䛿"))
	# l11ll1l1l_l1_ l11l1ll1_l1_
	if l1111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ䜀") in html:
		l1l1lll_l1_ = url.replace(parts[3],l1111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䜁"))
		l11llll1_l1_ = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"࠭ࠧ䜂"),headers,l1111_l1_ (u"ࠧࠨ䜃"),l1111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䜄"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䜅"),l11llll1_l1_,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡳࡡࡨࡧࠥࡂࡡࡴࠨ࠯ࠬࡂ࠭ࡡࡴࠧ䜆"),block,re.DOTALL)
			if items:
				id = re.findall(l1111_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬ䜇"),l11llll1_l1_,re.DOTALL)
				if id:
					l1l1llll11_l1_ = id[0]
					for l1l111l_l1_,title in items:
						l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ䜈")+l1l1llll11_l1_+l1111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䜉")+l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䜊")+title+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䜋")
						l11lll1l_l1_.append(l1l111l_l1_)
			else:
				# l1ll11ll_l1_://l11l1l111lll_l1_.tv/l11ll1l1l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ䜌"),block,re.DOTALL)
				for l1l111l_l1_,dummy in items:
					l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	if l1111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ䜍") in html:
		l1l1lll_l1_ = url.replace(parts[3],l1111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䜎"))
		l11llll1_l1_ = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭䜏"),headers,l1111_l1_ (u"࠭ࠧ䜐"),l1111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䜑"))
		id = re.findall(l1111_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䜒"),l11llll1_l1_,re.DOTALL)
		if id:
			l1l1llll11_l1_ = id[0]
			l1l1lll11_l1_ = { l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䜓"):l1111_l1_ (u"ࠪࠫ䜔") , l1111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䜕"):l1111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䜖") }
			l1l1lll_l1_ = l1ll11l_l1_ + l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩ䜗")+l1l1llll11_l1_
			l11llll1_l1_ = l111l11_l1_(l111ll_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠧࠨ䜘"),l1l1lll11_l1_,l1111_l1_ (u"ࠨࠩ䜙"),l1111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ䜚"))
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀ࡭࠹࠮ࠫࡁࠫࡠࡩ࠱ࠩࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䜛"),l11llll1_l1_,re.DOTALL)
			if l111l1l_l1_:
				for resolution,block in l111l1l_l1_:
					items = re.findall(l1111_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䜜"),block,re.DOTALL)
					for name,l1l111l_l1_ in items:
						l11lll1l_l1_.append(l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䜝")+name+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䜞")+l1111_l1_ (u"ࠧࡠࡡࡢࡣࠬ䜟")+resolution)
			else:
				l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾࡫࠺࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ䜠"),l11llll1_l1_,re.DOTALL)
				if not l111l1l_l1_: l111l1l_l1_ = [l11llll1_l1_]
				for block in l111l1l_l1_:
					l1111_l1_ (u"ࠤࠥࠦࠏࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡨࡶࡻ࡫ࡲࡴࡖ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࡰࡤࡱࡪࡀࠊࠊࠋࠌࠍࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࡟࠲࠷࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪห้ีโสࠢࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠋࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨࠥࡂ࠭ࠧ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫ࠠࠬࠢࠪࠤๅࠦࠧࠋࠋࠌࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥ࠭ࠧࠋࠋࠌࠍࠎࠏࠢࠣࠤ䜡")
					name = l1111_l1_ (u"ࠪࠫ䜢")
					items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ䜣"),block,re.DOTALL)
					for l1l111l_l1_ in items:
						server = l1111_l1_ (u"ࠬࠬࠦࠨ䜤") + l1l111l_l1_.split(l1111_l1_ (u"࠭࠯ࠨ䜥"))[2].lower() + l1111_l1_ (u"ࠧࠧࠨࠪ䜦")
						server = server.replace(l1111_l1_ (u"ࠨ࠰ࡦࡳࡲࠬࠦࠨ䜧"),l1111_l1_ (u"ࠩࠪ䜨")).replace(l1111_l1_ (u"ࠪ࠲ࡨࡵࠦࠧࠩ䜩"),l1111_l1_ (u"ࠫࠬ䜪"))
						server = server.replace(l1111_l1_ (u"ࠬ࠴࡮ࡦࡶࠩࠪࠬ䜫"),l1111_l1_ (u"࠭ࠧ䜬")).replace(l1111_l1_ (u"ࠧ࠯ࡱࡵ࡫ࠫࠬࠧ䜭"),l1111_l1_ (u"ࠨࠩ䜮"))
						server = server.replace(l1111_l1_ (u"ࠩ࠱ࡰ࡮ࡼࡥࠧࠨࠪ䜯"),l1111_l1_ (u"ࠪࠫ䜰")).replace(l1111_l1_ (u"ࠫ࠳ࡵ࡮࡭࡫ࡱࡩࠫࠬࠧ䜱"),l1111_l1_ (u"ࠬ࠭䜲"))
						server = server.replace(l1111_l1_ (u"࠭ࠦࠧࡪࡧ࠲ࠬ䜳"),l1111_l1_ (u"ࠧࠨ䜴")).replace(l1111_l1_ (u"ࠨࠨࠩࡻࡼࡽ࠮ࠨ䜵"),l1111_l1_ (u"ࠩࠪ䜶"))
						server = server.replace(l1111_l1_ (u"ࠪࠪࠫ࠭䜷"),l1111_l1_ (u"ࠫࠬ䜸"))
						l1l111l_l1_ = l1l111l_l1_ + l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䜹") + name + server + l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䜺")
						l11lll1l_l1_.append(l1l111l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䜻"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠨࠩ䜼"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠩࠪ䜽"): return
	search = search.replace(l1111_l1_ (u"ࠪࠤࠬ䜾"),l1111_l1_ (u"ࠫ࠰࠭䜿"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ䝀")+search
	l1l11l1_l1_(url)
	return
	l1111_l1_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡴࡧࡤࡶࡨ࡮ࠠࡴࡧࡦࡳࡳࡪࡡࡳࡻࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯ࡦࡥࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦ࡬ࡪࡩ࡫࡮ࡣࡵ࡯࠲ࡨ࡯࡭ࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠭ࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࠊࡨࡲࡶࠥࡩࡡࡵࡧࡪࡳࡷࡿࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡨࡧࡴࡦࡩࡲࡶࡾ࠯ࠊࠊࠋࠌࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ࠮ࠣࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚ࠩࠋࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࡁࠥ࠳࠱ࠡ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠉࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ࠮ࡷࡪࡧࡲࡤࡪ࠮ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ࠭ࡦࡥࡹ࡫ࡧࡰࡴࡼࠎࠎࠏࡔࡊࡖࡏࡉࡘ࠮ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤ䝁")
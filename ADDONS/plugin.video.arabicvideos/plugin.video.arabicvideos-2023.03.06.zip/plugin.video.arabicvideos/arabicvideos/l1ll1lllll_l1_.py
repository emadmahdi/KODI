# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
#l1ll11l_l1_ = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡩ࠴࠴ࡩࡧ࡯ࡥࡱ࠴ࡴࡷࠩᕲ")
#l1ll11l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠹࡮ࡥ࡭ࡣ࡯࠲ࡹࡼࠧᕳ")
#l1ll11l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰࠷࡬ࡪࡲࡡ࡭࠰ࡷࡺࠬᕴ")
l111_l1_=l1111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧᕵ")
headers = { l1111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᕶ") : l1111_l1_ (u"ࠧࠨᕷ") }
menu_name=l1111_l1_ (u"ࠨࡡࡆࡑࡋࡥࠧᕸ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,text):
	if   mode==90: l11l_l1_ = l11l111_l1_()
	elif mode==91: l11l_l1_ = l1ll1lll11_l1_(url)
	elif mode==92: l11l_l1_ = l1lllll_l1_(url)
	elif mode==94: l11l_l1_ = l1llll1ll_l1_()
	elif mode==95: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==99: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕹ"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᕺ"),l1111_l1_ (u"ࠫࠬᕻ"),99,l1111_l1_ (u"ࠬ࠭ᕼ"),l1111_l1_ (u"࠭ࠧᕽ"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᕾ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᕿ"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᖀ"),l1111_l1_ (u"ࠪࠫᖁ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖂ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᖃ")+menu_name+l1111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬᖄ"),l1111_l1_ (u"ࠧࠨᖅ"),94)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖆ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᖇ")+menu_name+l1111_l1_ (u"ࠪห้ษอะอࠪᖈ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱࡧࡴࡦࡵࡷࠫᖉ"),91)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖊ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᖋ")+menu_name+l1111_l1_ (u"ࠧศๆฦ฽้๏ࠠหไํ้ฬ๑ࠧᖌ"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡫ࡰࡨࡧ࠭ᖍ"),91)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖎ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧᖏ")+menu_name+l1111_l1_ (u"ࠫฬ๊รไอิࠤฺ๊ว่ัฬࠫᖐ"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡼࡩࡦࡹࠪᖑ"),91)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖒ"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫᖓ")+menu_name+l1111_l1_ (u"ࠨษ็้ะฮสࠨᖔ"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡳ࡭ࡳ࠭ᖕ"),91)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖖ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨᖗ")+menu_name+l1111_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫᖘ"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡮ࡦࡹࡐࡳࡻ࡯ࡥࡴࠩᖙ"),91)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᖚ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬᖛ")+menu_name+l1111_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨᖜ"),l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡲࡪࡽࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨᖝ"),91)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᖞ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᖟ"),l1111_l1_ (u"࠭ࠧᖠ"),9999)
	#l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᖡ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬᖢ")+menu_name+l1111_l1_ (u"ࠩฯำ๏ีࠠศๆ่์็฿ࠧᖣ"),l1ll11l_l1_,91)
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠪࠫᖤ"),headers,l1111_l1_ (u"ࠫࠬᖥ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᖦ"))
	#upper l1ll1llll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡢ࡫ࡱࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡴࡡࡷࠩᖧ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᖨ"),block,re.DOTALL)
	l11ll11_l1_ = [l1111_l1_ (u"ࠨษไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠫᖩ")]
	for l1l111l_l1_,title in items:
		title = title.strip(l1111_l1_ (u"ࠩࠣࠫᖪ"))
		if not any(value in title for value in l11ll11_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖫ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨᖬ")+menu_name+title,l1l111l_l1_,91)
	return html
def l1ll1lll11_l1_(url):
	if l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࠪᖭ") in url:
		url,search = url.split(l1111_l1_ (u"࠭࠿ࡵ࠿ࠪᖮ"))
		headers = { l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᖯ") : l1111_l1_ (u"ࠨࠩᖰ") , l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᖱ") : l1111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᖲ") }
		data = { l1111_l1_ (u"ࠫࡹ࠭ᖳ") : search }
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪᖴ"),url,data,headers,l1111_l1_ (u"࠭ࠧᖵ"),l1111_l1_ (u"ࠧࠨᖶ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭ᖷ"))
		html = response.content
	else:
		headers = { l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᖸ") : l1111_l1_ (u"ࠪࠫᖹ") }
		html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬᖺ"),headers,l1111_l1_ (u"ࠬ࠭ᖻ"),l1111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠳ࡰࡧࠫᖼ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࡫ࡵ࡯ࡵࠤࠪᖽ"),html,re.DOTALL)
	if l111l1l_l1_: block = l111l1l_l1_[0]
	else: block = l1111_l1_ (u"ࠨࠩᖾ")
	items = re.findall(l1111_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡮ࡱࡹ࡭ࡪ࠳ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᖿ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"ࠪห้ำไใหࠪᗀ") in title and l1111_l1_ (u"ࠫ࠴ࡩ࠯ࠨᗁ") not in url and l1111_l1_ (u"ࠬ࠵ࡣࡢࡶ࠲ࠫᗂ") not in url:
			l11l11l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡡ࠰࠮࠻ࡠ࠯ࠬᗃ"),title,re.DOTALL)
			if l11l11l_l1_:
				title = l1111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᗄ")+l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗅ"),menu_name+title,l1l111l_l1_,95,img)
					l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪᗆ") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᗇ"),menu_name+title,l1l111l_l1_,92,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗈ"),menu_name+title,l1l111l_l1_,91,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪᗉ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᗊ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠧศๆุๅาฯࠠࠨᗋ"),l1111_l1_ (u"ࠨࠩᗌ"))
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗍ"),menu_name+l1111_l1_ (u"ูࠪๆำษࠡࠩᗎ")+title,l1l111l_l1_,91)
	return
def l1l11ll_l1_(url):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬᗏ"),headers,l1111_l1_ (u"ࠬ࠭ᗐ"),l1111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᗑ"))
	img = re.findall(l1111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗒ"),html,re.DOTALL)
	img = img[0]
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡫ࡧࡁࠧ࡫ࡰࡪࡵࡲࡨࡪࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᗓ"),html,re.DOTALL)
	if l111l1l_l1_:
		name = re.findall(l1111_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᗔ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫᗕ"))
			if l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᗖ") in name: name = name.split(l1111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗗ"),1)[1]
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᗘ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᗙ"),menu_name+name+l1111_l1_ (u"ࠨࠢ࠰ࠤࠬᗚ")+title,l1l111l_l1_,92,img)
	else:
		tmp = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡳࡻ࡯ࡥࡵ࡫ࡷࡰࡪࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᗛ"),html,re.DOTALL)
		if tmp: l1l111l_l1_,title = tmp[0]
		else: l1l111l_l1_,title = url,name
		l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᗜ"),menu_name+title,l1l111l_l1_,92,img)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_,l1ll1lll1l_l1_ = [],[]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬᗝ"),headers,l1111_l1_ (u"ࠬ࠭ᗞ"),l1111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᗟ"))
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠧࡵࡧࡻࡸ࠲ࡹࡨࡢࡦࡲࡻ࠿ࠦ࡮ࡰࡰࡨ࠿ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᗠ"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫᗡ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗢ"),block,re.DOTALL)
		for l1l111l_l1_ in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᗣ")
			l11lll1l_l1_.append(l1l111l_l1_)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡳࡧࡶ࠮ࡶࡤࡦࡸࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࠰ࡴࡦࡴࡥ࡭࠯ࡰࡳࡷ࡫ࠧᗤ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		# l11ll1l1l_l1_ l11l1ll1_l1_
		items = re.findall(l1111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡪࡳࡢࡦࡦࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗥ"),block,re.DOTALL)
		for id,l1l111l_l1_ in items:
			title = l1111_l1_ (u"࠭ำ๋ำไีࠥ࠭ᗦ")+id
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᗧ")+title+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᗨ")
			l11lll1l_l1_.append(l1l111l_l1_)
		# other l11l1ll1_l1_
		items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᗩ"),block,re.DOTALL)
		for l1l111l_l1_ in items:
			if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᗪ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᗫ")+l1l111l_l1_
			l1l111l_l1_ = UNQUOTE(l1l111l_l1_)
			l11lll1l_l1_.append(l1l111l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᗬ"),url)
	return
def l1llll1ll_l1_():
	html = l111l11_l1_(l1111l1_l1_,l1ll11l_l1_,l1111_l1_ (u"࠭ࠧᗭ"),headers,l1111_l1_ (u"ࠧࠨᗮ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧᗯ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩ࡬ࡨࡂࠨࡩ࡯ࡦࡨࡼ࠲ࡲࡡࡴࡶ࠰ࡱࡴࡼࡩࡦࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥ࡭ࡳࡪࡥࡹ࠯ࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࠨᗰ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗱ"),block,re.DOTALL)
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬᗲ") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᗳ"),menu_name+title,l1l111l_l1_,92,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗴ"),menu_name+title,l1l111l_l1_,91,img)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠧࠨᗵ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠨࠩᗶ"): return
	search = search.replace(l1111_l1_ (u"ࠩࠣࠫᗷ"),l1111_l1_ (u"ࠪ࠯ࠬᗸ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡷࡁࠬᗹ")+search
	l1ll1lll11_l1_(url)
	return
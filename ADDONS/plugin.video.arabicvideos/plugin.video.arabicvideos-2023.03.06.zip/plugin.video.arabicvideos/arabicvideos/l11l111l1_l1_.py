# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ࿺")
headers = { l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࿻") : l1111_l1_ (u"ࠫࠬ࿼") }
menu_name=l1111_l1_ (u"ࠬࡥࡁࡓࡎࡢࠫ࿽")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ู࠭าู๊ࠤฬ๊ๅึษิ฽ฮ࠭࿾"),l1111_l1_ (u"ࠧศๆๆ่ࠬ࿿"),l1111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪက"),l1111_l1_ (u"ࠩส่฾อศࠨခ"),l1111_l1_ (u"ࠪฬึอๅอࠢๆ้อ๐่หำࠪဂ"),l1111_l1_ (u"๊ࠫ๎ศศ์็ࠤํࠦฬ้ษ็ࠫဃ"),l1111_l1_ (u"ࠬอไใี่ࠤฬ๊วิๆส้๏࠭င")]
def l1111ll_l1_(mode,url,text):
	if   mode==200: l11l_l1_ = l11l111_l1_()
	elif mode==201: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==202: l11l_l1_ = l1lllll_l1_(url)
	elif mode==203: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==204: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪစ")+text)
	elif mode==205: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧဆ")+text)
	elif mode==209: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဇ"),menu_name+l1111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩဈ"),l1111_l1_ (u"ࠪࠫဉ"),209,l1111_l1_ (u"ࠫࠬည"),l1111_l1_ (u"ࠬ࠭ဋ"),l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪဌ"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧဍ"),menu_name+l1111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫဎ"),l1ll11l_l1_,205)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩဏ"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭တ"),l1ll11l_l1_,204)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩထ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬဒ"),l1111_l1_ (u"࠭ࠧဓ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧန"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬပ")+menu_name+l1111_l1_ (u"่้ࠩ๏ุษࠨဖ"),l1ll11l_l1_+l1111_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧဗ"),201)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫဘ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩမ")+menu_name+l1111_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫယ"),l1ll11l_l1_+l1111_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡲࡵࡶࡪࡧࡶࠫရ"),201)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨလ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ဝ")+menu_name+l1111_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪသ"),l1ll11l_l1_+l1111_l1_ (u"ࠫࡄࡅࡴࡳࡧࡱࡨ࡮ࡴࡧࡠࡵࡨࡶ࡮࡫ࡳࠨဟ"),201)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဠ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪအ")+menu_name+l1111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩဢ"),l1ll11l_l1_+l1111_l1_ (u"ࠨࡁࡂࡱࡦ࡯࡮ࡱࡣࡪࡩࠬဣ"),201)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭ဤ"),l1ll11l_l1_,l1111_l1_ (u"ࠪࠫဥ"),headers,True,l1111_l1_ (u"ࠫࠬဦ"),l1111_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩဧ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡓࡡࡪࡰࡕࡳࡼ࠭ဨ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩဩ"),block,re.DOTALL)
		for filter,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡩࡱࡰࡩ࠴ࡳ࡯ࡳࡧࡂࡪ࡮ࡲࡴࡦࡴࡀࠫဪ")+filter
			l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩါ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧာ")+menu_name+title,l1l111l_l1_,201)
		l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩိ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬီ"),l1111_l1_ (u"࠭ࠧု"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ူ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪေ"),block,re.DOTALL)
	#l111l1ll1_l1_ = [l1111_l1_ (u"่ࠩืู้ไศฬࠣࠫဲ"),l1111_l1_ (u"ࠪหๆ๊วๆࠢࠪဳ"),l1111_l1_ (u"ࠫอืวๆฮࠪဴ"),l1111_l1_ (u"ࠬ฿ัุ้ࠪဵ"),l1111_l1_ (u"࠭ใๅ์หหฯ࠭ံ"),l1111_l1_ (u"ࠧศ฼ส๊๎့࠭")]
	for l1l111l_l1_,title in items:
		if l1111_l1_ (u"ࠨࡪࡷࡸࡵ࠭း") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"္ࠩࠣࠫ"))
		if not any(value in title for value in l11ll11_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ်ࠪ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨျ")+menu_name+title,l1l111l_l1_,201)
	return html
def l1l11l1_l1_(url):
	l1111_l1_ (u"ࠧࠨࠢࠋࠋࠦࠤ࡫ࡵࡲࠡࡒࡒࡗ࡙ࠦࡦࡪ࡮ࡷࡩࡷࡀࠊࠊ࡫ࡩࠤࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࡵࡳ࡮࠵࠰࡫࡯࡬ࡵࡧࡵࡷ࠷ࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡅࠧࠪࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧ࠭ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥࠫࡥࡣࡰࡷࡱࡸࡂ࠻࠰ࠨࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡷࡵࡰ࠷࠲ࡦࡪ࡮ࡷࡩࡷࡹ࠲ࠪࠌࠌࠍࡩࡧࡴࡢ࠴ࠣࡁࠥࢁࠧࡧࡱࡵࡱࠬࡀࡦࡪ࡮ࡷࡩࡷࡹ࠲࠭ࠩࡉ࡭ࡱࡺࡥࡳ࡙ࡲࡶࡩࡃࠧ࠻ࠩࠪࢁࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳ࠢࡀࠤ࡭࡫ࡡࡥࡧࡵࡷࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩࡠࠤࡂࠦࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩࡠࠤࡂ࡙ࠦࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷ࠷ࡡ࡙ࠧ࠯ࡆࡗࡗࡌ࠭ࡕࡑࡎࡉࡓ࠭࡝ࠡ࠿ࠣࠫࡌࡠ࠴ࡐࡦ࠳ࡲ࡯࡚ࡃࡢࡉࡺࡧࡌࡷ࠴ࡊࡼࡊࡵࡍࡋࡲ࡚࠲ࡸ࡞ࡴࡧࡕ࡙࡜ࡆ࠺ࡍ࡫ࡘࡹࡺࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜ࠩࡆࡳࡴࡱࡩࡦࠩࡠࠤࡂࠦࠧࡸࡣࡵࡦࡱ࡯࡯࡯ࡼࡷࡺࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࡥࡺࡌࡳࡨ࡮ࡏ࠶ࡊ࡯ࡕ࠴ࡒ࡞ࡎࡋ࡛࡯ࡖࡑࡗࡪࡥࡣࡑࡈࡰࡾࡖ࡯ࡦࡊ࡞࠶ࡈ࠲࡚࡮ࡈ࠽ࡕ࡙ࡉࡴࡋࡱ࡞࡭ࡨࡈࡗ࡮ࡌ࡮ࡴ࡯ࡑࡕࡔࡕ࡚࡝ࡓ࠱ࡖ࡬࡯ࡋࡧࡌࡆࡳࡣࡘࡊࡰࡕࡅࡹࡇࡒ࡙࡛ࡗ࡙ࡖ࠶࠴ࡨ࠶ࡔࡗࡦࡊࡦࡻࡪࡴࡍࡺࡘ࡚ࡖࡋࡗ࡭࡭࠴ࡘ࡜ࡎ࠶ࡤ࡬ࡺ࡯࡞࠶ࡈ࡮ࡢ࠵ࡳ࡜ࡘ࠷ࡂࡘࡤࡗࡅ࠸࡙࡭ࡏ࡬ࡧࡊࡩ࠹ࡗࡄࡋࡶࡍࡲ࠷ࡨ࡚ࡻࡌ࠺ࡎࡰࡕࡹ࡜ࡗ࡫ࡾࡔ࡭ࡎࡻࡒࡋࡊࡿࡍ࡫ࡋ࠳ࡒࡉࡔ࡬࡛࡬࡫ࡰࡓ࠸ࡎ࡬࡜ࡗࡆࡲࡔࡪࡥ࡯࡜ࡾࡆ࠶ࡎ࡫ࡃࡺࡑ࡙ࡐ࡫ࡎࡼ࡝࡮ࡔࡊࡉࡻࡐࡗ࡝ࡾࡓࡺ࡬࠲ࡑࡈࡨ࠻ࡍࡕࡄ࡭ࡒ࡜ࡏࡹࡐࡖ࡯࡮ࡓࡰࡧࡪࡨࡔࡁࡂ࠭ࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡔࡔ࡙ࡔࠨ࠮ࡸࡶࡱ࠸ࠬࡥࡣࡷࡥ࠷࠲ࡨࡦࡣࡧࡩࡷࡹ࠲࠭ࡖࡵࡹࡪ࠲ࠧࠨ࠮ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩࠬࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠥ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠨࠢࠣြ")
	if l1111_l1_ (u"࠭࠿ࡀࠩွ") in url: url,type = url.split(l1111_l1_ (u"ࠧࡀࡁࠪှ"))
	else: type = l1111_l1_ (u"ࠨࠩဿ")
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ၀"),l1111_l1_ (u"ࠪࠫ၁"),url,type)
	#if url==l1ll11l_l1_: url = url+l1111_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩ၂")
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭၃"),l1111_l1_ (u"࠭ࠧ၄"),url,l1111_l1_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠧ၅"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ၆"),url,l1111_l1_ (u"ࠩࠪ၇"),headers,True,l1111_l1_ (u"ࠪࠫ၈"),l1111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ၉"))
	html = response.content#.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ၊"))
	#l111ll1l1_l1_(html)
	if l1111_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ။") in url: l111l1l_l1_ = [html]
	elif type==l1111_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ၌"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡏࡤࡷࡹ࡫ࡲࡔ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡠࡳࠦࠪ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀࠪ၍"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࡣࡲࡵࡶࡪࡧࡶࠫ၎"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡗࡱ࡯ࡤࡦࡴࡢ࠵࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ၏"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠫࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥࡳࡦࡴ࡬ࡩࡸ࠭ၐ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡤ࠸ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫၑ"),html,re.DOTALL)
	elif type==l1111_l1_ (u"࠭࠱࠲࠳ࡰࡥ࡮ࡴࡰࡢࡩࡨࠫၒ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣࡴࡦ࡭ࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥࡷࠧ࠭ၓ"),html,re.DOTALL)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩၔ"),html,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪၕ"),l1111_l1_ (u"ࠪࠫၖ"),l1111_l1_ (u"ࠫࠬၗ"),str(l111l1l_l1_))
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	#items = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨ࡯ࡹ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩၘ"),block,re.DOTALL)
	l11l111ll_l1_ = [l1111_l1_ (u"࠭ๅีษ๊ำฮ࠭ၙ"),l1111_l1_ (u"ࠧโ์็้ࠬၚ"),l1111_l1_ (u"ࠨษ฽๊๏ฯࠧၛ"),l1111_l1_ (u"ࠩๆ่๏ฮࠧၜ"),l1111_l1_ (u"ࠪห฾๊ว็ࠩၝ"),l1111_l1_ (u"ࠫ์ีวโࠩၞ"),l1111_l1_ (u"๋ࠬศศำสอࠬၟ"),l1111_l1_ (u"ู࠭าุࠪၠ"),l1111_l1_ (u"ࠧๆ้ิะฬ์ࠧၡ"),l1111_l1_ (u"ࠨษ็ฬํ๋ࠧၢ")]
	#l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧၣ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪၤ"),l1111_l1_ (u"ࠫࠬၥ"),9999)
	items = re.findall(l1111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫၦ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1111_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡏࡴࡦ࡯ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀࠬၧ"),block,re.DOTALL)
		l11l1ll1_l1_,l111l1l1l_l1_,l11l11l11_l1_ = zip(*items)
		items = zip(l111l1l1l_l1_,l11l1ll1_l1_,l11l11l11_l1_)
	l1lllll1_l1_ = []
	for img,l1l111l_l1_,title in items:
		#l1l111l_l1_ = escapeUNICODE(l1l111l_l1_)
		#l1l111l_l1_ = QUOTE(l1l111l_l1_)
		if l1111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩၨ") in l1l111l_l1_: continue
		l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠨ࠱ࠪၩ"))
		title = l1l1111_l1_(title)
		title = title.strip(l1111_l1_ (u"ࠩࠣࠫၪ"))
		if l1111_l1_ (u"ࠪ࠳࡫࡯࡬࡮࠱ࠪၫ") in l1l111l_l1_ or any(value in title for value in l11l111ll_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪၬ"),menu_name+title,l1l111l_l1_,202,img)
		elif l1111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨၭ") in l1l111l_l1_ and l1111_l1_ (u"࠭วๅฯ็ๆฮ࠭ၮ") in title:
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪၯ"),title,re.DOTALL)
			if l11l11l_l1_:
				title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧၰ") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩၱ"),menu_name+title,l1l111l_l1_,203,img)
					l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠪ࠳ࡵࡧࡣ࡬࠱ࠪၲ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫၳ"),menu_name+title,l1l111l_l1_+l1111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬၴ"),201,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ၵ"),menu_name+title,l1l111l_l1_,203,img)
	if type in [l1111_l1_ (u"ࠧࠨၶ"),l1111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡶࡡࡨࡧࠪၷ")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪၸ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪၹ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
				title = l1l1111_l1_(title)
				title = title.replace(l1111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬၺ"),l1111_l1_ (u"ࠬ࠭ၻ"))
				if l1111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩၼ") in url:
					l111l11ll_l1_ = l1l111l_l1_.split(l1111_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭ၽ"))[1]
					l111llll1_l1_ = url.split(l1111_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧၾ"))[1]
					l1l111l_l1_ = url.replace(l1111_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨၿ")+l111llll1_l1_,l1111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩႀ")+l111l11ll_l1_)
				if title!=l1111_l1_ (u"ࠫࠬႁ"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬႂ"),menu_name+l1111_l1_ (u"࠭ีโฯฬࠤࠬႃ")+title,l1l111l_l1_,201)
	return
def l1l11ll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨႄ"),l1111_l1_ (u"ࠨࠩႅ"),url,l1111_l1_ (u"ࠩࠪႆ"))
	l11l11lll_l1_,items,l1111lll_l1_ = -1,[],[]
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧႇ"),url,l1111_l1_ (u"ࠫࠬႈ"),headers,True,l1111_l1_ (u"ࠬ࠭ႉ"),l1111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧႊ"))
	html = response.content#.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬႋ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡶ࡬࠱ࡱ࡯ࡳࡵ࠯ࡱࡹࡲࡨࡥࡳࡧࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨႌ"),html,re.DOTALL)
	if l111l1l_l1_:
		l1111lll_l1_ = []
		l1lll11_l1_ = l1111_l1_ (u"ႍࠩࠪ").join(l111l1l_l1_)
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႎ"),l1lll11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1111_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬႏ"))
	for l1l111l_l1_ in items:
		l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠬ࠵ࠧ႐"))
		title = l1111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ႑") + l1l111l_l1_.split(l1111_l1_ (u"ࠧ࠰ࠩ႒"))[-1].replace(l1111_l1_ (u"ࠨ࠯ࠪ႓"),l1111_l1_ (u"ࠩࠣࠫ႔"))
		l111l1ll_l1_ = re.findall(l1111_l1_ (u"ࠪห้ำไให࠰ࠬࡡࡪࠫࠪࠩ႕"),l1l111l_l1_.split(l1111_l1_ (u"ࠫ࠴࠭႖"))[-1],re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = l111l1ll_l1_[0]
		else: l111l1ll_l1_ = l1111_l1_ (u"ࠬ࠶ࠧ႗")
		l1111lll_l1_.append([l1l111l_l1_,title,l111l1ll_l1_])
	items = sorted(l1111lll_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11l1l_l1_ = str(items).count(l1111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ႘"))
	l11l11lll_l1_ = str(items).count(l1111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ႙"))
	if l11l11l1l_l1_>1 and l11l11lll_l1_>0 and l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪႚ") not in url:
		for l1l111l_l1_,title,l111l1ll_l1_ in items:
			if l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫႛ") in l1l111l_l1_:
				#l1l111l_l1_ = QUOTE(l1l111l_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪႜ"),menu_name+title,l1l111l_l1_,203)
	else:
		for l1l111l_l1_,title,l111l1ll_l1_ in items:
			if l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ႝ") not in l1l111l_l1_:
				#if l1111_l1_ (u"ࠬࠫࠧ႞") not in l1l111l_l1_: l1l111l_l1_ = QUOTE(l1l111l_l1_)
				#else: l1l111l_l1_ = QUOTE(UNQUOTE(l1l111l_l1_))
				#l1l111l_l1_ = UNQUOTE(l1l111l_l1_)
				title = UNQUOTE(title)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ႟"),menu_name+title,l1l111l_l1_,202)
	return
def l1lllll_l1_(url):
	#LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧႠ"),l1111_l1_ (u"ࠨࡇࡐࡅࡉࠦ࠱࠲࠳ࠪႡ"))
	l11lll1l_l1_ = []
	parts = url.split(l1111_l1_ (u"ࠩ࠲ࠫႢ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫႣ"),l1111_l1_ (u"ࠫࠬႤ"),url,l1111_l1_ (u"ࠬࡖࡌࡂ࡛࠰࠵ࡸࡺࠧႥ"))
	#url = UNQUOTE(QUOTE(url))
	hostname = l1ll11l_l1_
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪႦ"),url,l1111_l1_ (u"ࠧࠨႧ"),headers,True,True,l1111_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬႨ"))
	html = response.content#.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧႩ"))
	id = re.findall(l1111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫႪ"),html,re.DOTALL)
	if not id: id = re.findall(l1111_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬႫ"),html,re.DOTALL)
	if not id: id = re.findall(l1111_l1_ (u"ࠬࡶ࡯ࡴࡶ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧႬ"),html,re.DOTALL)
	if id: id = id[0]
	#else: l1ll1l_l1_(l1111_l1_ (u"࠭ࠧႭ"),l1111_l1_ (u"ࠧࠨႮ"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႯ"),l1111_l1_ (u"ࠩํีั๏ࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ้๋ࠢࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭Ⴐ"))
	#LOG_THIS(l1111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪႱ"),l1111_l1_ (u"ࠫࡊࡓࡁࡅࠢࡖࡘࡆࡘࡔࠡࡖࡌࡑࡎࡔࡇࠡ࠳࠴࠵ࠬႲ"))
	if l1111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭Ⴓ") in html:
		#parts = url.split(l1111_l1_ (u"࠭࠯ࠨႴ"))
		l1l1lll_l1_ = url.replace(parts[3],l1111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭Ⴕ"))
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬႶ"),l1l1lll_l1_,l1111_l1_ (u"ࠩࠪႷ"),headers,True,True,l1111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧႸ"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩႹ"))
		l111l111l_l1_ = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫႺ"),l11llll1_l1_,re.DOTALL)
		l11l1ll11_l1_ = re.findall(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧႻ"),l11llll1_l1_,re.DOTALL)
		l111l11l1_l1_ = re.findall(l1111_l1_ (u"ࠧࡴࡴࡦࡁࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫႼ"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࡝ࡰ࠭࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩႽ"),l11llll1_l1_)
		l1111lll1_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႾ"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		l111l1111_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬႿ"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l111l111l_l1_+l11l1ll11_l1_+l111l11l1_l1_+l1111llll_l1_+l1111lll1_l1_+l111l1111_l1_
		#LOG_THIS(l1111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫჀ"),l1111_l1_ (u"ࠬࡋࡍࡂࡆࠣࡗ࡙ࡇࡒࡕࠢࡗࡍࡒࡏࡎࡈࠢ࠷࠸࠹࠭Ⴡ"))
		if not items:
			items = re.findall(l1111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫჂ"),l11llll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1111_l1_ (u"ࠧ࠯ࡲࡱ࡫ࠬჃ") in server: continue
			if l1111_l1_ (u"ࠨ࠰࡭ࡴ࡬࠭Ⴤ") in server: continue
			if l1111_l1_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩჅ") in server: continue
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ჆"),title,re.DOTALL)
			if l11l1111_l1_:
				l11l1111_l1_ = l11l1111_l1_[0]
				if l11l1111_l1_ in title: title = title.replace(l11l1111_l1_+l1111_l1_ (u"ࠫࡵ࠭Ⴧ"),l1111_l1_ (u"ࠬ࠭჈")).replace(l11l1111_l1_,l1111_l1_ (u"࠭ࠧ჉")).strip(l1111_l1_ (u"ࠧࠡࠩ჊"))
				l11l1111_l1_ = l1111_l1_ (u"ࠨࡡࡢࡣࡤ࠭჋")+l11l1111_l1_
			else: l11l1111_l1_ = l1111_l1_ (u"ࠩࠪ჌")
			#LOG_THIS(l1111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪჍ"),l1111_l1_ (u"ࠫࡠ࠭჎")+str(id)+l1111_l1_ (u"ࠬࡣࠠࠡ࡝ࠪ჏")+str(hostname)+l1111_l1_ (u"࠭࡝ࠡࠢ࡞ࠫა")+str(title)+l1111_l1_ (u"ࠧ࡞ࠢࠣ࡟ࠬბ")+str(l11l1111_l1_)+l1111_l1_ (u"ࠨ࡟ࠪგ"))
			if server.isdigit():
				l1l111l_l1_ = hostname+l1111_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬდ")+id+l1111_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧე")+server+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬვ")+title+l1111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ზ")+l11l1111_l1_
			else:
				if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫთ") not in server: server = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ი")+server
				l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩკ"),title,re.DOTALL)
				if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"ࠩࡢࡣࡤࡥࠧლ")+l11l1111_l1_[0]
				else: l11l1111_l1_ = l1111_l1_ (u"ࠪࠫმ")
				l1l111l_l1_ = server+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬნ")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#LOG_THIS(l1111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬო"),l1111_l1_ (u"࡛࠭ࠨპ")+l11l1111_l1_+l1111_l1_ (u"ࠧ࡞ࠢࠣࠤࠥࡡࠧჟ")+title+l1111_l1_ (u"ࠨ࡟ࠪრ"))
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧს"), l11lll1l_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫტ"),l1111_l1_ (u"ࠫࠬუ"),l1111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠤ࠶࠭ფ"),	str(len(items)))
	if l1111_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡏࡱࡺࠫქ") in html:
		l1l1lll11_l1_ = { l1111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ღ"):l1111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨყ") }
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬშ")
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧჩ"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬც"),l1l1lll11_l1_,True,l1111_l1_ (u"ࠬ࠭ძ"),l1111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪწ"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬჭ"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩხ"),l1111_l1_ (u"ࠩࠪჯ"),l1l1lll_l1_,l11llll1_l1_)
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫჰ"),l11llll1_l1_,re.DOTALL)
		for block in l111l1l_l1_:
			items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ჱ"),block,re.DOTALL)
			for l1l111l_l1_,name,l11l1111_l1_ in items:
				l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ჲ")+name+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪჳ")+l1111_l1_ (u"ࠧࡠࡡࡢࡣࠬჴ")+l11l1111_l1_
				l11lll1l_l1_.append(l1l111l_l1_)
	elif l1111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬჵ") in html:
		l1l1lll11_l1_ = { l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ჶ"):l1111_l1_ (u"ࠪࠫჷ") , l1111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧჸ"):l1111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ჹ") }
		l1l1lll_l1_ = hostname + l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩჺ")+id
		response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ჻"),l1l1lll_l1_,l1111_l1_ (u"ࠨࠩჼ"),l1l1lll11_l1_,True,True,l1111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭ჽ"))
		l11llll1_l1_ = response.content#.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨჾ"))
		if l1111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠳ࡢࡵࡰࡶࠫჿ") in l11llll1_l1_:
			l111l11l1_l1_ = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᄀ"),l11llll1_l1_,re.DOTALL)
			for l11l11_l1_ in l111l11l1_l1_:
				if l1111_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭ᄁ") not in l11l11_l1_ and l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬᄂ") in l11l11_l1_:
					l11l11_l1_ = l11l11_l1_+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᄃ")
					l11lll1l_l1_.append(l11l11_l1_)
				elif l1111_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩᄄ") in l11l11_l1_:
					l11l1111_l1_ = l1111_l1_ (u"ࠪࠫᄅ")
					response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᄆ"),l11l11_l1_,l1111_l1_ (u"ࠬ࠭ᄇ"),headers,True,True,l1111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪᄈ"))
					l111l1lll_l1_ = response.content#.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᄉ"))
					l1lll11_l1_ = re.findall(l1111_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭ᄊ"),l111l1lll_l1_,re.DOTALL)
					for l11l11ll1_l1_ in l1lll11_l1_:
						l111ll11l_l1_ = l1111_l1_ (u"ࠩࠪᄋ")
						l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬᄌ"),l11l11ll1_l1_,re.DOTALL)
						for l111lllll_l1_ in l1111llll_l1_:
							item = re.findall(l1111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬᄍ"),l111lllll_l1_,re.DOTALL)
							if item:
								l11l1111_l1_ = l1111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪᄎ")+item[0]
								break
						for l111lllll_l1_ in reversed(l1111llll_l1_):
							item = re.findall(l1111_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬᄏ"),l111lllll_l1_,re.DOTALL)
							if item:
								l111ll11l_l1_ = item[0]
								break
						l1111lll1_l1_ = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᄐ"),l11l11ll1_l1_,re.DOTALL)
						for l111lll11_l1_ in l1111lll1_l1_:
							l111lll11_l1_ = l111lll11_l1_+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᄑ")+l111ll11l_l1_+l1111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᄒ")+l11l1111_l1_
							l11lll1l_l1_.append(l111lll11_l1_)
			#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᄓ"),l1111_l1_ (u"ࠫࠬᄔ"),l1111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࠲ࠩᄕ"),	str(len(l11lll1l_l1_))	)
		elif l1111_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠫᄖ") in l11llll1_l1_:
			l11llll1_l1_ = l11llll1_l1_.replace(l1111_l1_ (u"ࠧ࠽ࡪ࠹ࠤࠬᄗ"),l1111_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬᄘ"))+l1111_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪᄙ")
			l11llll1_l1_ = l11llll1_l1_.replace(l1111_l1_ (u"ࠪࡀ࡭࠹ࠠࠨᄚ"),l1111_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨᄛ"))+l1111_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ᄜ")
			#LOG_THIS(l1111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᄝ"),l11llll1_l1_)
			#open(l1111_l1_ (u"ࠧࡴ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧᄞ"),l1111_l1_ (u"ࠨࡹࠪᄟ")).write(l11llll1_l1_)
			l111lll1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡀࡁࡘ࡚ࡁࡓࡖࡀࡁ࠭࠴ࠪࡀࠫࡀࡁࡊࡔࡄ࠾࠿ࠪᄠ"),l11llll1_l1_,re.DOTALL)
			if l111lll1l_l1_:
				for l11l11ll1_l1_ in l111lll1l_l1_:
					if l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩᄡ") not in l11l11ll1_l1_: continue
					#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬᄢ"),l1111_l1_ (u"ࠬ࠭ᄣ"),l1111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠡ࠳࠴࠵ࠬᄤ"),	l11l11ll1_l1_	)
					l11l11111_l1_ = l1111_l1_ (u"ࠧࠨᄥ")
					l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠨࡵ࡯ࡳࡼ࠳࡭ࡰࡶ࡬ࡳࡳࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᄦ"),l11l11ll1_l1_,re.DOTALL)
					for l111lllll_l1_ in l1111llll_l1_:
						item = re.findall(l1111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪᄧ"),l111lllll_l1_,re.DOTALL)
						if item:
							l11l11111_l1_ = l1111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨᄨ")+item[0]
							break
					l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᄩ"),l11l11ll1_l1_,re.DOTALL)
					if l1111llll_l1_:
						for l111ll11l_l1_,l111ll1ll_l1_ in l1111llll_l1_:
							l111ll1ll_l1_ = l111ll1ll_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᄪ")+l111ll11l_l1_+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᄫ")+l11l11111_l1_
							l11lll1l_l1_.append(l111ll1ll_l1_)
					else:
						l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᄬ"),l11l11ll1_l1_,re.DOTALL)
						for l111ll1ll_l1_,l111ll11l_l1_ in l1111llll_l1_:
							l111ll1ll_l1_ = l111ll1ll_l1_.strip(l1111_l1_ (u"ࠨࠢࠪᄭ"))+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᄮ")+l111ll11l_l1_+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᄯ")+l11l11111_l1_
							l11lll1l_l1_.append(l111ll1ll_l1_)
			else:
				l1111llll_l1_ = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࡝ࡹ࠮࠭ࡁ࠭ᄰ"),l11llll1_l1_,re.DOTALL)
				for l111ll1ll_l1_,l111ll11l_l1_ in l1111llll_l1_:
					l111ll1ll_l1_ = l111ll1ll_l1_.strip(l1111_l1_ (u"ࠬࠦࠧᄱ"))+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᄲ")+l111ll11l_l1_+l1111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᄳ")
					l11lll1l_l1_.append(l111ll1ll_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᄴ"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᄵ"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫᄶ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬᄷ"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧᄸ"),l1111_l1_ (u"࠭ࠫࠨᄹ"))
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᄺ"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡤࡰࡿ࠭ᄻ"),l1111_l1_ (u"ࠩࠪᄼ"),headers,True,l1111_l1_ (u"ࠪࠫᄽ"),l1111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪᄾ"))
	html = response.content#.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᄿ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣࡩࡧࡹࡶࡴࡴ࠭ࡴࡧ࡯ࡩࡨࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᅀ"),html,re.DOTALL)
	if l1ll11_l1_ and l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᅁ"),block,re.DOTALL)
		l11l1111l_l1_,l111ll111_l1_ = [],[]
		for category,title in items:
			#if title in [l1111_l1_ (u"ࠨำํห฻ฯู้่ࠠࠢฬืู่ࠩᅂ")]: continue
			l11l1111l_l1_.append(category)
			l111ll111_l1_.append(title)
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩᅃ"), l111ll111_l1_)
		if l1l_l1_ == -1 : return
		category = l11l1111l_l1_[l1l_l1_]
	else: category = l1111_l1_ (u"ࠪࠫᅄ")
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨᅅ")+search+l1111_l1_ (u"ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩᅆ")+category+l1111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠷ࠧᅇ")
	l1l11l1_l1_(url)
	return
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᅈ"),l1111_l1_ (u"ࠨࠩᅉ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪᅊ"),l1111_l1_ (u"ࠪࠫᅋ"),filter,url)
	# for l111l1l11_l1_ filter:		l1l1l11l_l1_ = [l1111_l1_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶࡾࡉࡨࡦࡥ࡮ࡆࡴࡾࠧᅌ"),l1111_l1_ (u"ࠬ࡟ࡥࡢࡴࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫᅍ"),l1111_l1_ (u"࠭ࡇࡦࡰࡵࡩࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᅎ"),l1111_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩᅏ")]
	l1l1l11l_l1_ = [l1111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᅐ"),l1111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᅑ"),l1111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᅒ"),l1111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬᅓ")]
	if l1111_l1_ (u"ࠬࡅࠧᅔ") in url: url = url.split(l1111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᅕ"))[0]
	type,filter = filter.split(l1111_l1_ (u"ࠧࡠࡡࡢࠫᅖ"),1)
	if filter==l1111_l1_ (u"ࠨࠩᅗ"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠩࠪᅘ"),l1111_l1_ (u"ࠪࠫᅙ")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠫࡤࡥ࡟ࠨᅚ"))
	if type==l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩᅛ"):
		if l1l1l11l_l1_[0]+l1111_l1_ (u"࠭࠽ࠨᅜ") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠧ࠾ࠩᅝ") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠪᅞ")+category+l1111_l1_ (u"ࠩࡀ࠴ࠬᅟ")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠬᅠ")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧᅡ")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠬࠬࠧᅢ"))+l1111_l1_ (u"࠭࡟ࡠࡡࠪᅣ")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩᅤ"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᅥ"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᅦ")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᅧ"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᅨ"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠬ࠭ᅩ"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᅪ"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠧࠨᅫ"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬᅬ")+l1l11ll1_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅭ"),menu_name+l1111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ᅮ"),l1l1lll_l1_,201)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅯ"),menu_name+l1111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬᅰ")+l11lll11_l1_+l1111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬᅱ"),l1l1lll_l1_,201)
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᅲ"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᅳ"),l1111_l1_ (u"ࠩࠪᅴ"),9999)
	html = l111l11_l1_(l111ll_l1_,url+l1111_l1_ (u"ࠪ࠳ࡦࡲࡺࠨᅵ"),l1111_l1_ (u"ࠫࠬᅶ"),headers,l1111_l1_ (u"ࠬ࠭ᅷ"),l1111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᅸ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡂ࡬ࡤࡼࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡄࡢࡶࡤࠬ࠳࠰࠿ࠪࡈ࡬ࡰࡹ࡫ࡲࡘࡱࡵࡨࠬᅹ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	# for l111l1l11_l1_ filter:		l111111_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࡭࠸ࠧᅺ"),block,re.DOTALL)
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠩ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡦࡰࡴࡗࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࡮࠲ࠨᅻ"),block,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᅼ"),l1111_l1_ (u"ࠫࠬᅽ"),l1111_l1_ (u"ࠬ࠭ᅾ"),str(l111111_l1_))
	dict = {}
	for name,l1lll1ll_l1_,block in l111111_l1_:
		#name = name.replace(l1111_l1_ (u"࠭࠭࠮ࠩᅿ"),l1111_l1_ (u"ࠧࠨᆀ"))
		name = name.replace(l1111_l1_ (u"ࠨษัฮ๏อัࠡࠩᆁ"),l1111_l1_ (u"ࠩࠪᆂ"))
		name = name.replace(l1111_l1_ (u"ࠪื๋ฯࠠศๆศ๊ฯอฬࠨᆃ"),l1111_l1_ (u"ࠫฬ๊ำ็หࠪᆄ"))
		items = re.findall(l1111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᆅ"),block,re.DOTALL)
		if l1111_l1_ (u"࠭࠽ࠨᆆ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫᆇ"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨᆈ")+l1l1l1ll_l1_)
				return
			else:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᆉ"),menu_name+l1111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫᆊ"),l1l1lll_l1_,201)
				else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆋ"),menu_name+l1111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ᆌ"),l1l1lll_l1_,205,l1111_l1_ (u"࠭ࠧᆍ"),l1111_l1_ (u"ࠧࠨᆎ"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩᆏ"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠩࠩࠫᆐ")+l1lll1ll_l1_+l1111_l1_ (u"ࠪࡁ࠵࠭ᆑ")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠫࠫ࠭ᆒ")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃ࠰ࠨᆓ")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᆔ")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆕ"),menu_name+l1111_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪᆖ")+name,l1l1lll_l1_,204,l1111_l1_ (u"ࠩࠪᆗ"),l1111_l1_ (u"ࠪࠫᆘ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᆙ"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			option = option.replace(l1111_l1_ (u"ࠬࡢ࡮ࠨᆚ"),l1111_l1_ (u"࠭ࠧᆛ"))
			if option in l11ll11_l1_: continue
			#if option==l1111_l1_ (u"ࠧศๆๆ่ࠬᆜ"): continue
			#option = l1111_l1_ (u"ࠨ࡝ࠪᆝ")+option+l1111_l1_ (u"ࠩࡠࠫᆞ")
			#if l1111_l1_ (u"ࠪห้้ไࠨᆟ") in option: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬᆠ"),l1111_l1_ (u"ࠬ࠭ᆡ"),l1111_l1_ (u"࠭ࠧᆢ"),l1111_l1_ (u"ࠧ࡜ࠩᆣ")+str(option)+l1111_l1_ (u"ࠨ࡟ࠪᆤ"))
			#if l1111_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨᆥ") not in value: value = option
			#else: value = re.findall(l1111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫᆦ"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠫࠫ࠭ᆧ")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃࠧᆨ")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"࠭ࠦࠨᆩ")+l1lll1ll_l1_+l1111_l1_ (u"ࠧ࠾ࠩᆪ")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬᆫ")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"ࠩࠣ࠾ࠬᆬ")#+dict[l1lll1ll_l1_][l1111_l1_ (u"ࠪ࠴ࠬᆭ")]
			title = option+l1111_l1_ (u"ࠫࠥࡀࠧᆮ")+name
			if type==l1111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ᆯ"): l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆰ"),menu_name+title,url,204,l1111_l1_ (u"ࠧࠨᆱ"),l1111_l1_ (u"ࠨࠩᆲ"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᆳ"))
			elif type==l1111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧᆴ") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠫࡂ࠭ᆵ") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᆶ"))
				l11l11_l1_ = url+l1111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᆷ")+l1l111l1_l1_
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆸ"),menu_name+title,l11l11_l1_,201)
			else: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆹ"),menu_name+title,url,205,l1111_l1_ (u"ࠩࠪᆺ"),l1111_l1_ (u"ࠪࠫᆻ"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬᆼ"),l1111_l1_ (u"ࠬ࠭ᆽ"),filters,l1111_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧᆾ"))
	# mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᆿ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᇀ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠩࡤࡰࡱ࠭ᇁ")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	filters = filters.replace(l1111_l1_ (u"ࠪࡁࠫ࠭ᇂ"),l1111_l1_ (u"ࠫࡂ࠶ࠦࠨᇃ"))
	filters = filters.strip(l1111_l1_ (u"ࠬࠬࠧᇄ"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"࠭࠽ࠨᇅ") in filters:
		items = filters.split(l1111_l1_ (u"ࠧࠧࠩᇆ"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠨ࠿ࠪᇇ"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠩࠪᇈ")
	# for l111l1l11_l1_ filter:		l1ll1lll_l1_ = [l1111_l1_ (u"ࠪࡇࡦࡺࡥࡨࡱࡵࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᇉ"),l1111_l1_ (u"ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪᇊ"),l1111_l1_ (u"ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬᇋ"),l1111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨᇌ")]
	l1ll1lll_l1_ = [l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᇍ"),l1111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᇎ"),l1111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᇏ"),l1111_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᇐ")]
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠫ࠵࠭ᇑ")
		if l1111_l1_ (u"ࠬࠫࠧᇒ") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᇓ") and value!=l1111_l1_ (u"ࠧ࠱ࠩᇔ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠨࠢ࠮ࠤࠬᇕ")+value
		elif mode==l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᇖ") and value!=l1111_l1_ (u"ࠪ࠴ࠬᇗ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠫࠫ࠭ᇘ")+key+l1111_l1_ (u"ࠬࡃࠧᇙ")+value
		elif mode==l1111_l1_ (u"࠭ࡡ࡭࡮ࠪᇚ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠧࠧࠩᇛ")+key+l1111_l1_ (u"ࠨ࠿ࠪᇜ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠩࠣ࠯ࠥ࠭ᇝ"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠪࠪࠬᇞ"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠫࡂ࠶ࠧᇟ"),l1111_l1_ (u"ࠬࡃࠧᇠ"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧᇡ"),l1111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᇢ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩᇣ"),l1111_l1_ (u"ࠩࠪᇤ"),filters,l1111_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫᇥ"))
	return l1lll11l_l1_
l1111_l1_ (u"ࠦࠧࠨࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠴ࡷࡹࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡷࡶࡩࡩࠦ࡮ࡰࡹࠣ࡭ࡳࠦࡷࡦࡤࡶ࡭ࡹ࡫ࠩࠋࡣࡧࡨ࡮ࡴࡧࠡࡨ࡬ࡰࡹ࡫ࡲࠡࡶࡲࠤࡸ࡫ࡡࡳࡥ࡫ࠎࡕࡕࡓࡕ࠼ࠌ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴ࡡࡳࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥࠫࡥࡣࡰࡷࡱࡸࡂ࠻࠰ࠋࠋࡧࡥࡹࡧ࠺ࠊ࡝ࠪࡇࡦࡺࡥࡨࡱࡵࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ࠬࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧ࠭ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫࡖࡻࡡ࡭࡫ࡷࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭࡝ࠋࠋ࡫ࡩࡦࡪࡥࡳࡵ࠽ࠍࡈࡵ࡯࡬࡫ࡨࠤ࠰ࠦࡘࡓࡇࡉ࠱࡙ࡕࡋࡆࡐࠍࠎࠏ࡬ࡩ࡭ࡶࡨࡶࡸࡀࠉ࠳ࡰࡧࠤࡲ࡫ࡴࡩࡱࡧࠍࠎ࠮࡯࡭ࡦࠣࡱࡪࡺࡨࡰࡦࠣࡦࡺࡺࠠࡴࡶ࡬ࡰࡱࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠩࠊࠋࠫࡹࡸ࡫ࡤࠡ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡶࡻࡡ࡭࡫ࡷࡽࡂ࡝ࡅࡃ࠯ࡇࡐࠫࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࡁ࠷࠶࠲࠱ࠌࠍࠎࠏ࡬ࡩ࡭ࡶࡨࡶࡸࡀࠉ࠴ࡴࡧࠤࡲ࡫ࡴࡩࡱࡧࠍࠎ࠮࡯࡭ࡦࠣࡱࡪࡺࡨࡰࡦࠣࡦࡺࡺࠠࡴࡶ࡬ࡰࡱࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠩࠋࡉࡈࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶ࠴࠸࠰࠲࠻ࠍࡋࡊ࡚࠺ࠊࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡦࡸࡴ࠰ࡳࡸࡥࡱ࡯ࡴࡺ࠱࠷ࡏࠪ࠸࠰ࡃ࡮ࡸࡖࡦࡿࠊࠣࠤࠥᇦ")
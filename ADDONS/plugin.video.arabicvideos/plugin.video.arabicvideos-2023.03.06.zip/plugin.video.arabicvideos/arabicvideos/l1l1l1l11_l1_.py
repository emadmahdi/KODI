﻿# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_ = l1111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬෙ")
headers = { l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨේ") : l1111_l1_ (u"ࠬ࠭ෛ") }
menu_name=l1111_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬො")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,text):
	if   mode==40: l11l_l1_ = l11l111_l1_()
	elif mode==41: l11l_l1_ = l1l1ll1ll_l1_()
	elif mode==42: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==43: l11l_l1_ = l1lllll_l1_(url)
	elif mode==44: l11l_l1_ = CATEGORIES(url,text)
	elif mode==45: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==46: l11l_l1_ = l1l1l11ll_l1_()
	elif mode==47: l11l_l1_ = l1l11l1l1_l1_(url)
	elif mode==49: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬෝ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬෞ")+menu_name+l1111_l1_ (u"ࠩส่อัࠠศๆะ๎๊ࠥโ็ษฬࠤฬ๊ๅฺษิๅࠬෟ"),l1111_l1_ (u"ࠪࠫ෠"),41)
	return
	l1111_l1_ (u"ࠦࠧࠨࠊࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ࠲ࠧࠨ࠮࠷࠽࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠱ࠧࡠࡡࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่อืวๆฮࠣห้ำวๅ์ฬࠫ࠱࠭ࠧ࠭࠶࠹࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ࠯ࠊࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲࡬࠷ࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠮ࠫࡤࡥ࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡴࡡ࡮ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠸࠰ࠬ࠭ࠬࠨࠩ࠯ࠫ࠸࠭ࠩࠋࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡳࡧࡦࡩࡳࡺ࠭ࡥࡧࡩࡥࡺࡲࡴ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡳࡧ࡭ࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠯ࠬࡥ࡟ࡠࠩ࠮ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡮ࡢ࡯ࡨ࡟࠵ࡣࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯࠸࠺࠲ࠧࠨ࠮ࠪࠫ࠱࠭࠲ࠨࠫࠍࠍࡳࡧ࡭ࡦࠢࡀࠤࡠ࠭วาึํๅࠥอไษำส้ั࠭࡝ࠋࠋࠦࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠧࡄ࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷ࠱ࡹࡵࡰࠣࡀ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡲࡦࡳࡥ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠮ࠫࡤࡥ࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡴࡡ࡮ࡧ࡞࠴ࡢ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮࠷࠸࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠶ࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠣ࡬ࡹࡳ࡬ࠋࠋࠥࠦࠧ෡")
def l1l11l1_l1_(url,select):
	l111l1_l1_ = [l1111_l1_ (u"ࠬะืษ์ๅหฯࠦวๅษฯ๋ืฯࠠศๆำ็๏ฯࠧ෢"),l1111_l1_ (u"࠭ฬะ๊็ࠤฬ๊ศาษ่ะࠬ෣"),l1111_l1_ (u"ࠧศ๊ๅหฯࠦศาษ่ะ๋อࠧ෤")]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠨࠩ෥"),headers,l1111_l1_ (u"ࠩࠪ෦"),l1111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ෧"))
	if select==l1111_l1_ (u"ࠫ࠷࠭෨"):
		l1l11lll1_l1_=re.findall(l1111_l1_ (u"ࠬࡸࡥࡤࡧࡱࡸ࠲ࡪࡥࡧࡣࡸࡰࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡱ࡫ࡡࡳࠤࠪ෩"),html,re.DOTALL)
		if l1l11lll1_l1_:
			block = l1l11lll1_l1_[0]
			items=re.findall(l1111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡸࡥ࡭࠿ࠥࡦࡴࡵ࡫࡮ࡣࡵ࡯ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭෪"),block,re.DOTALL)
			for img,url,title in items:
				if not any(value in title for value in l111l1_l1_):
					title = l1l1111_l1_(title)
					l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ෫"),menu_name+title,url,42,img)
	elif select==l1111_l1_ (u"ࠨ࠵ࠪ෬"):
		l1l11ll1l_l1_=re.findall(l1111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡦࡴࡾࠨ࠯ࠬࡂ࠭ࡸࡩࡲࡪࡲࡷࠫ෭"),html,re.DOTALL)
		if l1l11ll1l_l1_:
			block = l1l11ll1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠪ࡬࠷࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෮"),block,re.DOTALL)
			for url,title,img in items:
				if not any(value in title for value in l111l1_l1_):
					title = l1l1111_l1_(title)
					l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෯"),menu_name+title,url,42,img)
	l1l1l111l_l1_=re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡪࠪ෰"),html,re.DOTALL)
	if l1l1l111l_l1_:
		block = l1l1l111l_l1_[0]
		items=re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෱"),block,re.DOTALL)
		for url,title in items:
			title = l1l1111_l1_(title)
			title = l1111_l1_ (u"ࠧึใะอࠥ࠭ෲ") + title
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨෳ"),menu_name+title,url,45,l1111_l1_ (u"ࠩࠪ෴"),l1111_l1_ (u"ࠪࠫ෵"),select)
	return
def l1l11ll_l1_(url):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬ෶"),headers,l1111_l1_ (u"ࠬ࠭෷"),l1111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ෸"))
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠧࡦࡰࡷࡶࡾ࠳ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡴࡲࡤࡲࠥ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ෹"),html,re.DOTALL)
	if l111l1l_l1_:
		name = l111l1l_l1_[0]
		name = l1l1111_l1_(name)
		l111l1l_l1_=re.findall(l1111_l1_ (u"ࠨࡹࡳ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹ࠳ࡳࡤࡴ࡬ࡴࡹ࠮࠮ࠫࡁࠬ࠲ࡪࡴࡴࡳࡻࠪ෺"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡭ࡦࡶࡤࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࠨ࠺ࡼࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡭ࡻ࡭ࡣࠤ࠽ࡿࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ෻"),block,re.DOTALL)
			for l1l111l_l1_,title,l1l1l1111_l1_,l1l11l1ll_l1_,l1l11ll11_l1_ in items:
				l1l11l1ll_l1_ = l1l11l1ll_l1_.replace(l1111_l1_ (u"ࠪࡠ࠴࠭෼"),l1111_l1_ (u"ࠫ࠴࠭෽"))
				l1l11ll11_l1_ = l1l11ll11_l1_.replace(l1111_l1_ (u"ࠬࡢ࠯ࠨ෾"),l1111_l1_ (u"࠭࠯ࠨ෿"))
				l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠧ࡝࠱ࠪ฀"),l1111_l1_ (u"ࠨ࠱ࠪก"))
				title = escapeUNICODE(title)
				l1l111l_l1_ = escapeUNICODE(l1l111l_l1_)
				title = title.split(l1111_l1_ (u"ࠩࠣࠫข"))[-1]
				title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩฃ") + name + l1111_l1_ (u"ࠫࠥ࠳ࠠࠨค") + title
				duration = re.findall(l1111_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬ࡤ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪฅ"),l1l1l1111_l1_,re.DOTALL)
				if duration: duration = duration[0]
				else:  duration = l1111_l1_ (u"࠭ࠧฆ")
				l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ง"),menu_name+title,l1l111l_l1_,43,l1l11ll11_l1_,duration)
		else:
			items=re.findall(l1111_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡲ࡭ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪ࠴ࠪࡀࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧจ"),html,re.DOTALL)
			for title,l1l111l_l1_,img in items:
				img = img.replace(l1111_l1_ (u"ࠩ࡟࠳ࠬฉ"),l1111_l1_ (u"ࠪ࠳ࠬช"))
				title = escapeUNICODE(title)
				l1l111l_l1_ = escapeUNICODE(l1l111l_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪซ"),menu_name+title,l1l111l_l1_,43,img)
			#l1l1l11l1_l1_(url)
	else:
		l111l1l_l1_=re.findall(l1111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ฌ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧญ"),l1111_l1_ (u"ࠧࠨฎ"),url, block)
			items=re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧฏ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				title = l1l1111_l1_(title)
				l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨฐ"),menu_name+title,l1l111l_l1_,47)
	return
def l1lllll_l1_(url):
	url = url.replace(l1111_l1_ (u"ࠪࠤࠬฑ"),l1111_l1_ (u"ࠫࠪ࠸࠰ࠨฒ"))
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫณ"))
	return
def l1l11l1l1_l1_(url):
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"࠭ࠧด"),headers,l1111_l1_ (u"ࠧࠨต"),l1111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡔࡑࡇ࡙ࡠࡐࡈ࡛࡜ࡋࡂࡔࡋࡗࡉ࠲࠷ࡳࡵࠩถ"))
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡒࡍࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬท"),html,re.DOTALL)
	l1lllll_l1_(l1l111l_l1_[0])
	return
def CATEGORIES(url,category):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫธ"),l1111_l1_ (u"ࠫࠬน"),type, url)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠬ࠭บ"),headers,l1111_l1_ (u"࠭ࠧป"),l1111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪผ"))
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠨࡥࡤࡸ࠶࠴ࡡ࡝ࠪ࠳࠰࠭࠴ࠪࡀࠫࡧࡳࡨࡻ࡭ࡦࡰࡷ࠲ࡼࡸࡩࡵࡧࠪฝ"),html,re.DOTALL)
	block= l111l1l_l1_[0]
	items=re.findall(l1111_l1_ (u"ࠩࡦࡥࡹ࠷࠮ࡢ࡞ࠫࠬ࠳࠰࠿ࠪ࠮ࠫ࠲࠯ࡅࠩ࠭࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠰ࡡ࠭࡜ࠨ࠮࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬพ"),block,re.DOTALL)
	l1l11llll_l1_=False
	l111l1_l1_ = [l1111_l1_ (u"ࠪ࠱࠸࠿࠹ࠨฟ"),l1111_l1_ (u"ࠫ࠺࠼࠴࠴ࠩภ"),l1111_l1_ (u"ࠬ࠸࠳࠱࠸ࠪม"),l1111_l1_ (u"࠭࠵࠷࠷࠷ࠫย"),l1111_l1_ (u"ࠧ࠲࠲࠺࠵࠻࠭ร"),l1111_l1_ (u"ࠨ࠳࠳࠶࠼࠽ࠧฤ"),l1111_l1_ (u"ࠩ࠺࠽࠹࠼ࠧล")]
	for cat,parent,title,l1l111l_l1_ in items:
		if parent == category and cat not in l111l1_l1_:
			title = l1l1111_l1_(title)
			if l1111_l1_ (u"ࠪ์็อสࠡสิห๊าࠧฦ") in title: continue
			if l1111_l1_ (u"ࠫ࠭࠭ว") in title:
				title = l1111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫศ") + title.replace(re.findall(l1111_l1_ (u"࠭ࠠ࡝ࠪ࠱࠮ࡄࡢࠩࠨษ"),title)[0],l1111_l1_ (u"ࠧࠨส"))
			url = l1ll11l_l1_ + l1111_l1_ (u"ࠨ࠱ࠪห") + l1l111l_l1_
			if cat == l1111_l1_ (u"ࠩ࠰࠵࠻࠻ࠧฬ"): title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩอ") + l1111_l1_ (u"ࠫฬ๊ำ๋ัูࠣอออࠡึหีࠥ࠮࠶࠱ࠫࠪฮ")
			if l1111_l1_ (u"ࠬ࠳ࠧฯ") in cat: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ะ"),menu_name+title,url,44,l1111_l1_ (u"ࠧࠨั"),l1111_l1_ (u"ࠨࠩา"),cat)
			else: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩำ"),menu_name+title,url,42)
			l1l11llll_l1_=True
	if not l1l11llll_l1_: l1l11l1_l1_(url,l1111_l1_ (u"ࠪ࠷ࠬิ"))
	return
def l1l1l11ll_l1_():
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬี"),l1111_l1_ (u"ࠬ࠭ึ"),type, url)
	html = l111l11_l1_(l1111l1_l1_,l1ll11l_l1_,l1111_l1_ (u"࠭ࠧื"),headers,l1111_l1_ (u"ࠧࠨุ"),l1111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡔࡗࡕࡇࡓࡃࡐࡗ࠲࠷ࡳࡵูࠩ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡰࡩ࡬ࡧ࠭࡮ࡧࡱࡹ࠲ࡨ࡬ࡰࡥ࡮ࠬ࠳࠰࠿ࠪ࡯ࡨ࡫ࡦ࠳࡭ࡦࡰࡸฺࠫ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ฻"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ฼"),menu_name+title,l1l111l_l1_,44)
	return
def l1l1ll1ll_l1_():
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵࡬ࡪࡸࡨࠫ฽"),l1111_l1_ (u"࠭ࠧ฾"),l1111_l1_ (u"ࠧࠨ฿"),l1111_l1_ (u"ࠨࠩเ"),l1111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭แ"))
	items = re.findall(l1111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨโ"),html,re.DOTALL)
	url = UNQUOTE(items[0])
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬใ"),l1111_l1_ (u"ࠬ࠭ไ"),url,str(html))
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫๅ"))
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠧࠨๆ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠨࠩ็"): return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"่ࠩࠣࠫ"),l1111_l1_ (u"ࠪࠩ࠷࠶้ࠧ"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡅࡳ࠾๊ࠩ") +l1lll1l_l1_
	l1l11l1_l1_(url,l1111_l1_ (u"ࠬ࠹๋ࠧ"))
	return
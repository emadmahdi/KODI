# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
#
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭᤬")
def l1111ll_l1_(mode,url):
	if   mode==330: l11l_l1_ = l1l1l1llll_l1_()
	elif mode==331: l11l_l1_ = l1lllll_l1_(url)
	elif mode==332: l11l_l1_ = l1l11lll11_l1_()
	elif mode==333: l11l_l1_ = l1l111l111_l1_()
	elif mode==334: l11l_l1_ = l1l11ll11l_l1_(url)
	else: l11l_l1_ = False
	return l11l_l1_
def l1l11ll11l_l1_(l1l111llll_l1_):
	try: os.remove(l1l111llll_l1_.decode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ᤭")))
	except: os.remove(l1l111llll_l1_)
	return
def l1lllll_l1_(url):
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᤮"))
	return
def l1l111l111_l1_():
	message = l1111_l1_ (u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭᤯")
	l1ll1l_l1_(l1111_l1_ (u"ࠨࠩᤰ"),l1111_l1_ (u"ࠩࠪᤱ"),l1111_l1_ (u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡษ็้้็วหࠩᤲ"),message)
	return
def l1l1l1llll_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᤳ"),l1111_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪᤴ"),l1111_l1_ (u"࠭ࠧᤵ"),333)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᤶ"),l1111_l1_ (u"ࠨฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨᤷ"),l1111_l1_ (u"ࠩࠪᤸ"),332)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᤹"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᤺"),l1111_l1_ (u"᤻ࠬ࠭"),9999)
	l1l1l11l11_l1_ = l1l11ll111_l1_()
	mtime = os.stat(l1l1l11l11_l1_).st_mtime
	files = []
	if kodi_version>18.99: l1l1l111ll_l1_ = os.listdir(l1l1l11l11_l1_.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ᤼")))
	else: l1l1l111ll_l1_ = os.listdir(l1l1l11l11_l1_.decode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ᤽")))
	for filename in l1l1l111ll_l1_:
		if kodi_version>18.99: filename = filename.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭᤾"))
		if not filename.startswith(l1111_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ᤿")): continue
		filepath = os.path.join(l1l1l11l11_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l1l1l1ll11_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ᥀"))
			except: pass
			filename = filename.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ᥁"))
		filepath = os.path.join(l1l1l11l11_l1_,filename)
		l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᥂"),filename,filepath,331)
	return
def l1l11ll111_l1_():
	l1l1l11l11_l1_ = settings.getSetting(l1111_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩ᥃"))
	if l1l1l11l11_l1_: return l1l1l11l11_l1_
	settings.setSetting(l1111_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ᥄"),addoncachefolder)
	return addoncachefolder
def l1l11lll11_l1_():
	l1l1l11l11_l1_ = l1l11ll111_l1_()
	change = l1l11l1l11_l1_(l1111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ᥅"),l1111_l1_ (u"ࠩࠪ᥆"),l1111_l1_ (u"ࠪࠫ᥇"),l1l1l11l11_l1_,l1111_l1_ (u"ࠫ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨ᥈"))
	if change==1:
		newpath = l1l11llll1_l1_(3,l1111_l1_ (u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ᥉"),l1111_l1_ (u"࠭࡬ࡰࡥࡤࡰࠬ᥊"),l1111_l1_ (u"ࠧࠨ᥋"),False,True,l1l1l11l11_l1_)
		l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ᥌"),l1111_l1_ (u"ࠩࠪ᥍"),l1111_l1_ (u"ࠪࠫ᥎"),newpath,l1111_l1_ (u"ࠫ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨ᥏"))
		if l1l1l1l111_l1_==1:
			settings.setSetting(l1111_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨᥐ"),newpath)
			l1ll1l_l1_(l1111_l1_ (u"࠭ࠧᥑ"),l1111_l1_ (u"ࠧࠨᥒ"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᥓ"),l1111_l1_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪᥔ"))
	#if not change or not l1l1l1l111_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᥕ"),l1111_l1_ (u"ࠫࠬᥖ"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᥗ"),l1111_l1_ (u"࠭สๆࠢส่฿อมࠡษ็฽๊๊๊สࠩᥘ"))
	return
def l1l11lll1l_l1_(filename):
	l1l1l1lll1_l1_ = l1111_l1_ (u"ࠧࠨᥙ").join(ii for ii in filename if ii not in l1111_l1_ (u"ࠨ࡞࠲ࠦ࠿࠰࠿࠽ࡀࡿࠫᥚ")+escapeUNICODE(l1111_l1_ (u"ࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩᥛ")))
	return l1l1l1lll1_l1_
def l1l11l1lll_l1_(url,l1l1111l1l_l1_=l1111_l1_ (u"ࠪࠫᥜ"),l1l1lll1_l1_=l1111_l1_ (u"ࠫࠬᥝ")):
	#l1ll111_l1_(l1111_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬᥞ"),l1111_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭ᥟ"))
	LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᥠ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᥡ")+url+l1111_l1_ (u"ࠩࠣࡡࠬᥢ"))
	if not l1l1111l1l_l1_: l1l1111l1l_l1_ = l1l1l11lll_l1_(url,l1l1lll1_l1_)
	#if not l1l1111l1l_l1_:
	#	l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᥣ"),l1111_l1_ (u"ࠫࠬᥤ"),l1111_l1_ (u"ࠬะๆำ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᥥ"),l1111_l1_ (u"࠭วๅ็็ๅ๋ࠥๆ่๋ࠡ฽ࠥ࠭ᥦ")+l1l1111l1l_l1_+l1111_l1_ (u"๊ࠧࠡส่อืๆศ็ฯࠤาอไ๋ษࠣ฾๏ืࠠอษ๊ึ๊ࠥสฮ็ํ่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊ๅๅใสฮࠬᥧ"))
	#	LOG_THIS(l1111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᥨ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡹࡿࡰࡦ࠱ࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᥩ")+url+l1111_l1_ (u"ࠪࠤࡢ࠭ᥪ"))
	#	return False
	l1l1l11l11_l1_ = l1l11ll111_l1_()
	l1l1l1l11l_l1_ = l1l1l111l1_l1_()
	filename = l1l1l1l11l_l1_.replace(l1111_l1_ (u"ࠫࠥ࠭ᥫ"),l1111_l1_ (u"ࠬࡥࠧᥬ"))
	filename = l1l11lll1l_l1_(filename)
	#l1l1111l1l_l1_ = l1l1111l1l_l1_.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᥭ"))
	filename = l1111_l1_ (u"ࠧࡧ࡫࡯ࡩࡤ࠭᥮")+str(int(now))[-4:]+l1111_l1_ (u"ࠨࡡࠪ᥯")+filename+l1l1111l1l_l1_
	l1l111l11l_l1_ = os.path.join(l1l1l11l11_l1_,filename)
	headers = {}
	headers[l1111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫᥰ")] = l1111_l1_ (u"ࠪࠫᥱ")
	headers[l1111_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷࠫᥲ")] = l1111_l1_ (u"ࠬ࠰࠯ࠫࠩᥳ")
	url = url.replace(l1111_l1_ (u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩᥴ"),l1111_l1_ (u"ࠧࠨ᥵"))
	if l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭᥶") in url:
		l1l1lll_l1_,l1l1111ll1_l1_ = url.rsplit(l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ᥷"),1)
		l1l1111ll1_l1_ = l1l1111ll1_l1_.replace(l1111_l1_ (u"ࠪࢀࠬ᥸"),l1111_l1_ (u"ࠫࠬ᥹")).replace(l1111_l1_ (u"ࠬࠬࠧ᥺"),l1111_l1_ (u"࠭ࠧ᥻"))
	else: l1l1lll_l1_,l1l1111ll1_l1_ = url,None
	if not l1l1111ll1_l1_: l1l1111ll1_l1_ = l1l111l1l_l1_()
	if l1l1111ll1_l1_: headers[l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᥼")] = l1l1111ll1_l1_
	if l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ᥽") in l1l1lll_l1_: l1l1lll_l1_,l1l11l11l1_l1_ = l1l1lll_l1_.rsplit(l1111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ᥾"),1)
	else: l1l1lll_l1_,l1l11l11l1_l1_ = l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ᥿")
	l1l1lll_l1_ = l1l1lll_l1_.strip(l1111_l1_ (u"ࠫࢁ࠭ᦀ")).strip(l1111_l1_ (u"ࠬࠬࠧᦁ")).strip(l1111_l1_ (u"࠭ࡼࠨᦂ")).strip(l1111_l1_ (u"ࠧࠧࠩᦃ"))
	l1l11l11l1_l1_ = l1l11l11l1_l1_.replace(l1111_l1_ (u"ࠨࡾࠪᦄ"),l1111_l1_ (u"ࠩࠪᦅ")).replace(l1111_l1_ (u"ࠪࠪࠬᦆ"),l1111_l1_ (u"ࠫࠬᦇ"))
	if l1l11l11l1_l1_:	headers[l1111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᦈ")] = l1l11l11l1_l1_
	LOG_THIS(l1111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᦉ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᦊ")+l1l1lll_l1_+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫᦋ")+str(headers)+l1111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᦌ")+l1l111l11l_l1_+l1111_l1_ (u"ࠪࠤࡢ࠭ᦍ"))
	l1l1ll1111_l1_ = 1024*1024
	l1l1l11ll1_l1_ = 0
	try:
		l1l1l11l1l_l1_ =	xbmc.getInfoLabel(l1111_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡥࡦࡕࡳࡥࡨ࡫ࠧᦎ"))
		l1l1l11l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡢࡤࠬࠩᦏ"),l1l1l11l1l_l1_)
		l1l1l11ll1_l1_ = int(l1l1l11l1l_l1_[0])
	except: pass
	if l1l1l11ll1_l1_==0:
		try:
			st = os.l1l1111l11_l1_(l1l1l11l11_l1_)
			l1l1l11ll1_l1_ = st.f_frsize*st.f_bavail//l1l1ll1111_l1_
		except: pass
	if l1l1l11ll1_l1_==0:
		try:
			st = os.l1l1l1ll1l_l1_(l1l1l11l11_l1_)
			l1l1l11ll1_l1_ = st.f_frsize*st.f_bavail//l1l1ll1111_l1_
		except: pass
	if l1l1l11ll1_l1_==0:
		try:
			import shutil
			total,l1l11ll1ll_l1_,l1l11l1ll1_l1_ = shutil.l1l1ll11ll_l1_(l1l1l11l11_l1_)
			l1l1l11ll1_l1_ = l1l11l1ll1_l1_//l1l1ll1111_l1_
		except: pass
	if l1l1l11ll1_l1_==0:
		l1l1ll1l11_l1_(l1111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬᦐ"),l1111_l1_ (u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠๆฮ๊์้ฯࠧᦑ"),l1111_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ฽๎ึࠦโศัิࠤศ์๋ࠠฯาำ๋ࠥโะษิࠤู๊วฮหࠣห้ะฮำ์้ࠤฬ๊แศำ฽อࠥ็๊ࠡฮ๊หื้้ࠠ฻็๎์ࠦแศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦไ็ࠢํ฽ฺ๊๊่ࠠา็ࠥหไ๊ࠢฦ๊ࠥ๐โ้็้ࠣอืๅอ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡสะ่ࠥํะ่ࠢสฺ่๊ใๅห่ࠣฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠣๆิ๊ࠦิสหࠤฬ๋สๅษฤࠤัํวำๅࠣฬฬ๊ๅๅใสฮࠥ๎็ัษࠣๅ๏ํࠠฯู๋ีฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๊็ัษࠣหู้ศษࠢๅห๊ࠦวๅ็หี๊าࠠๆฦๅฮฬࠦศๆ่฼ࠤฬ๊ศา่ส้ัࠦๅ็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬᦒ"),l1111_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᦓ"))
		LOG_THIS(l1111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨᦔ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬᦕ"))
		return False
	import requests
	if l1l1111l1l_l1_==l1111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫᦖ"):
		l11111l_l1_,l11lll1l_l1_ = l1l1ll111l_l1_(l1l1lll_l1_,headers)
		#l11llll_l1_(l1111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᦗ"), l11111l_l1_)
		#l11llll_l1_(l1111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬᦘ"), l11lll1l_l1_)
		if len(l11111l_l1_)==0:
			l1ll111_l1_(l1111_l1_ (u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬᦙ"),l1111_l1_ (u"ࠩࠪᦚ"))
			return False
		elif len(l11111l_l1_)==1: l1l_l1_ = 0
		elif len(l11111l_l1_)>1:
			l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨᦛ"), l11111l_l1_)
			if l1l_l1_ == -1 :
				l1ll111_l1_(l1111_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬะ้๏๊ࠧᦜ"),l1111_l1_ (u"ࠬ࠭ᦝ"))
				return False
		l1l1lll_l1_ = l11lll1l_l1_[l1l_l1_]
	filesize = 0
	if l1l1111l1l_l1_==l1111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬᦞ"):
		l1l111l11l_l1_ = l1l111l11l_l1_.rsplit(l1111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᦟ"))[0]+l1111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭ᦠ")
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭ᦡ"),l1l1lll_l1_,l1111_l1_ (u"ࠪࠫᦢ"),headers,l1111_l1_ (u"ࠫࠬᦣ"),l1111_l1_ (u"ࠬ࠭ᦤ"),l1111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭ᦥ"))
		l1llll111_l1_ = response.content
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠧ࡝ࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩᦦ"),l1llll111_l1_+l1111_l1_ (u"ࠨ࡞ࡱࡠࡷ࠭ᦧ"),re.DOTALL)
		if not l11l1ll1_l1_:
			LOG_THIS(l1111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᦨ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᦩ")+l1l1lll_l1_+l1111_l1_ (u"ࠫࠥࡣࠧᦪ"))
			return False
		l1l111l_l1_ = l11l1ll1_l1_[0]
		if not l1l111l_l1_.startswith(l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᦫ")):
			if l1l111l_l1_.startswith(l1111_l1_ (u"࠭࠯࠰ࠩ᦬")): l1l111l_l1_ = l1l1lll_l1_.split(l1111_l1_ (u"ࠧ࠻ࠩ᦭"),1)[0]+l1111_l1_ (u"ࠨ࠼ࠪ᦮")+l1l111l_l1_
			elif l1l111l_l1_.startswith(l1111_l1_ (u"ࠩ࠲ࠫ᦯")): l1l111l_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧᦰ"))+l1l111l_l1_
			else: l1l111l_l1_ = l1l1lll_l1_.rsplit(l1111_l1_ (u"ࠫ࠴࠭ᦱ"),1)[0]+l1111_l1_ (u"ࠬ࠵ࠧᦲ")+l1l111l_l1_
		response = requests.request(l1111_l1_ (u"࠭ࡇࡆࡖࠪᦳ"),l1l111l_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l1l11l1l1l_l1_ = len(l11l1ll1_l1_)
		filesize = chunksize*l1l11l1l1l_l1_
	else:
		chunksize = 1*l1l1ll1111_l1_
		response = requests.request(l1111_l1_ (u"ࠧࡈࡇࡗࠫᦴ"),l1l1lll_l1_,headers=headers,verify=False,stream=True)
		if l1111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᦵ") in response.headers: filesize = int(response.headers[l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᦶ")])
		l1l11l1l1l_l1_ = int(filesize//chunksize)
	#l1l1l1l1l1_l1_ = l1l11l1l1l_l1_+1
	l1l1l1l1l1_l1_ = int(filesize//l1l1ll1111_l1_)+1
	if filesize<21000:
		LOG_THIS(l1111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨᦷ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᦸ")+l1l1lll_l1_+l1111_l1_ (u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᦹ")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᦺ")+str(l1l1l11ll1_l1_)+l1111_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᦻ")+l1l111l11l_l1_+l1111_l1_ (u"ࠨࠢࡠࠫᦼ"))
		l1ll1l_l1_(l1111_l1_ (u"ࠩࠪᦽ"),l1111_l1_ (u"ࠪࠫᦾ"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᦿ"),l1111_l1_ (u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧᧀ"))
		return False
	l1l11l111l_l1_ = 400
	l1l111ll11_l1_ = l1l1l11ll1_l1_-l1l1l1l1l1_l1_
	if l1l111ll11_l1_<l1l11l111l_l1_:
		LOG_THIS(l1111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫᧁ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠧࠡࠢࠣࡒࡴࡺࠠࡦࡰࡲࡹ࡬࡮ࠠࡥ࡫ࡶ࡯ࠥࡹࡰࡢࡥࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᧂ")+l1l1lll_l1_+l1111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᧃ")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᧄ")+str(l1l1l11ll1_l1_)+l1111_l1_ (u"ࠪࠤࡒࡈࠠ࠮ࠢࠪᧅ")+str(l1l11l111l_l1_)+l1111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᧆ")+l1l111l11l_l1_+l1111_l1_ (u"ࠬࠦ࡝ࠨᧇ"))
		l1ll1l_l1_(l1111_l1_ (u"࠭ࠧᧈ"),l1111_l1_ (u"ࠧࠨᧉ"),l1111_l1_ (u"ࠨๆสࠤ๏๎ฬะ่ࠢืฬำษࠡๅสๅ๏ฯࠠๅๆอั๊๐ไࠨ᧊"),l1111_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่ࠢะะ๊ํࠠࠨ᧋")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡࠩ᧌")+str(l1l1l11ll1_l1_)+l1111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠๆ็้าอแูหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬิ๎ๆࠡ็ืห่๊๋ࠠฮหࠤสฮโศรࠣࠫ᧍")+str(l1l11l111l_l1_)+l1111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡใสี฿ฯࠠะษษ้ฬ่่ࠦาสࠤ๊฿ๆศ้ࠣว๋ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧ᧎"))
		return False
	l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭᧏"),l1111_l1_ (u"ࠧࠨ᧐"),l1111_l1_ (u"ࠨࠩ᧑"),l1111_l1_ (u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪ᧒"),l1111_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩ᧓")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪ᧔")+str(l1l1l11ll1_l1_)+l1111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆฦ๊ฯืๆ๋ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩ᧕"))
	if l1l1l1l111_l1_!=1:
		l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ᧖"),l1111_l1_ (u"ࠧࠨ᧗"),l1111_l1_ (u"ࠨࠩ᧘"),l1111_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ᧙"))
		LOG_THIS(l1111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ᧚"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡸࡥࡧࡷࡶࡩࡩࠦࡴࡰࠢࡶࡸࡦࡸࡴࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ᧛")+l1l1lll_l1_+l1111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ᧜")+l1l111l11l_l1_+l1111_l1_ (u"࠭ࠠ࡞ࠩ᧝"))
		return False
	LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ᧞"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭᧟"))
	pDialog = l1l1l1l1ll_l1_()
	pDialog.create(l1l111l11l_l1_,l1111_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ᧠"))
	l1l11l11ll_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l1l111l11l_l1_,l1111_l1_ (u"ࠪࡻࡧ࠭᧡"))
	else: file = open(l1l111l11l_l1_.decode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ᧢")),l1111_l1_ (u"ࠬࡽࡢࠨ᧣"))
	if l1l1111l1l_l1_==l1111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ᧤"): # l1l11ll1ll_l1_ for l1llll111_l1_ and l1l111ll1l_l1_ chunks video files such as .l1l1l1111l_l1_
		for ii in range(1,l1l11l1l1l_l1_+1):
			l1l111l_l1_ = l11l1ll1_l1_[ii-1]
			if not l1l111l_l1_.startswith(l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬ᧥")):
				if l1l111l_l1_.startswith(l1111_l1_ (u"ࠨ࠱࠲ࠫ᧦")): l1l111l_l1_ = l1l1lll_l1_.split(l1111_l1_ (u"ࠩ࠽ࠫ᧧"),1)[0]+l1111_l1_ (u"ࠪ࠾ࠬ᧨")+l1l111l_l1_
				elif l1l111l_l1_.startswith(l1111_l1_ (u"ࠫ࠴࠭᧩")): l1l111l_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ᧪"))+l1l111l_l1_
				else: l1l111l_l1_ = l1l1lll_l1_.rsplit(l1111_l1_ (u"࠭࠯ࠨ᧫"),1)[0]+l1111_l1_ (u"ࠧ࠰ࠩ᧬")+l1l111l_l1_
			response = requests.request(l1111_l1_ (u"ࠨࡉࡈࡘࠬ᧭"),l1l111l_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l1l111l1ll_l1_ = time.time()
			l1l1111lll_l1_ = l1l111l1ll_l1_-t1
			l1l111l1l1_l1_ = l1l1111lll_l1_//ii
			l1l11lllll_l1_ = l1l111l1l1_l1_*(l1l11l1l1l_l1_+1)
			l1l111lll1_l1_ = l1l11lllll_l1_-l1l1111lll_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii//(l1l11l1l1l_l1_+1)),l1111_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ᧮"),l1111_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ᧯"),str(ii*chunksize//l1l1ll1111_l1_)+l1111_l1_ (u"ࠫ࠴࠭᧰")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪ᧱")+time.strftime(l1111_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣ᧲"),time.gmtime(l1l111lll1_l1_))+l1111_l1_ (u"ࠧࠡโࠪ᧳"))
			if pDialog.iscanceled():
				l1l11l11ll_l1_ = False
				break
	else: # l1111l1l_l1_ and other l1l1l11111_l1_ file l1l1ll11l1_l1_
		ii = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			ii = ii+1
			l1l111l1ll_l1_ = time.time()
			l1l1111lll_l1_ = l1l111l1ll_l1_-t1
			l1l111l1l1_l1_ = l1l1111lll_l1_/ii
			l1l11lllll_l1_ = l1l111l1l1_l1_*(l1l11l1l1l_l1_+1)
			l1l111lll1_l1_ = l1l11lllll_l1_-l1l1111lll_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii/(l1l11l1l1l_l1_+1)),l1111_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ᧴"),l1111_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ᧵"),str(ii*chunksize//l1l1ll1111_l1_)+l1111_l1_ (u"ࠪ࠳ࠬ᧶")+str(l1l1l1l1l1_l1_)+l1111_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ᧷")+time.strftime(l1111_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ᧸"),time.gmtime(l1l111lll1_l1_))+l1111_l1_ (u"࠭ࠠแࠩ᧹"))
			if pDialog.iscanceled():
				l1l11l11ll_l1_ = False
				break
		response.close()
	file.close()
	pDialog.close()
	if not l1l11l11ll_l1_:
		LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ᧺"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ᧻")+l1l1lll_l1_+l1111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ᧼")+l1l111l11l_l1_+l1111_l1_ (u"ࠪࠤࡢ࠭᧽"))
		l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ᧾"),l1111_l1_ (u"ࠬ࠭᧿"),l1111_l1_ (u"࠭ࠧᨀ"),l1111_l1_ (u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᨁ"))
		return True
	LOG_THIS(l1111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᨂ"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᨃ")+l1l1lll_l1_+l1111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᨄ")+l1l111l11l_l1_+l1111_l1_ (u"ࠫࠥࡣࠧᨅ"))
	l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭ᨆ"),l1111_l1_ (u"࠭ࠧᨇ"),l1111_l1_ (u"ࠧࠨᨈ"),l1111_l1_ (u"ࠨฬ่ࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡส้ะฬำࠧᨉ"))
	return True
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
headers = { l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࠀ") : l1111_l1_ (u"ࠬ࠭ࠁ") }
l111_l1_=l1111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬࠂ")
menu_name=l1111_l1_ (u"ࠧࡠࡃࡎࡓࡤ࠭ࠃ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11l1_l1_ = [l1111_l1_ (u"ࠨใํ่๊࠭ࠄ"),l1111_l1_ (u"ࠩๆ่๏ฮࠧࠅ"),l1111_l1_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫࠆ"),l1111_l1_ (u"ู๊ࠫัฮ์ฬࠫࠇ"),l1111_l1_ (u"๋ࠬำาฯํ๋ࠬࠈ"),l1111_l1_ (u"࠭ว฻่ํอࠬࠉ"),l1111_l1_ (u"ࠧศ฻็ห๋࠭ࠊ"),l1111_l1_ (u"ࠨๆๅหฦ࠭ࠋ")]
def l1111ll_l1_(mode,url,text):
	if   mode==70: l11l_l1_ = l11l111_l1_()
	elif mode==71: l11l_l1_ = CATEGORIES(url)
	elif mode==72: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==73: l11l_l1_ = l11111_l1_(url)
	elif mode==74: l11l_l1_ = l1lllll_l1_(url)
	elif mode==79: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠌ"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪࠍ"),l1111_l1_ (u"ࠫࠬࠎ"),79,l1111_l1_ (u"ࠬ࠭ࠏ"),l1111_l1_ (u"࠭ࠧࠐ"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫࠑ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࠒ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ࠓ")+menu_name+l1111_l1_ (u"ࠪืู้ไสࠢสๅ้อๅࠨࠔ"),l1111_l1_ (u"ࠫࠬࠕ"),79,l1111_l1_ (u"ࠬ࠭ࠖ"),l1111_l1_ (u"࠭ࠧࠗ"),l1111_l1_ (u"ࠧิๆึ่ฮࠦวโๆส้ࠬ࠘"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࠙"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ࠚ")+menu_name+l1111_l1_ (u"ࠪื้อำๅ่๊ࠢํ฿ษࠨࠛ"),l1111_l1_ (u"ࠫࠬࠜ"),79,l1111_l1_ (u"ࠬ࠭ࠝ"),l1111_l1_ (u"࠭ࠧࠞ"),l1111_l1_ (u"ࠧิๆึ่ฮ࠭ࠟ"))
	#l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࠠ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ࠡ")+menu_name+l1111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫࠢ"),l1ll11l_l1_,72,l1111_l1_ (u"ࠫࠬࠣ"),l1111_l1_ (u"ࠬ࠭ࠤ"),l1111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨࠥ"))
	#l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠦ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬࠧ")+menu_name+l1111_l1_ (u"ࠩสุ่๊๊ะࠩࠨ"),l1ll11l_l1_,72,l1111_l1_ (u"ࠪࠫࠩ"),l1111_l1_ (u"ࠫࠬࠪ"),l1111_l1_ (u"ࠬࡳ࡯ࡳࡧࠪࠫ"))
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ࠭")+menu_name+l1111_l1_ (u"ࠨษ็วำฮวาࠩ࠮"),l1ll11l_l1_,72,l1111_l1_ (u"ࠩࠪ࠯"),l1111_l1_ (u"ࠪࠫ࠰"),l1111_l1_ (u"ࠫࡳ࡫ࡷࡴࠩ࠱"))
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ࠳")+menu_name+l1111_l1_ (u"ࠧศๆฦาออัࠨ࠴"),l1ll11l_l1_,72,l1111_l1_ (u"ࠨࠩ࠵"),l1111_l1_ (u"ࠩࠪ࠶"),l1111_l1_ (u"ࠪࡲࡪࡽࡳࠨ࠷"))
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ࠸"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠹"),l1111_l1_ (u"࠭ࠧ࠺"),9999)
	l11ll11_l1_ = [l1111_l1_ (u"ࠧศๆๆฮอ่ࠦࠡษ็หอำวฬࠩ࠻"),l1111_l1_ (u"ࠨษ็็ํืำศฬࠣห้ะูๅ์่๎ฮ࠭࠼"),l1111_l1_ (u"ࠩส่ศู๊ศสࠪ࠽"),l1111_l1_ (u"ࠪห้ฮัศ็ฯࠫ࠾"),l1111_l1_ (u"ࠫฬ๊วอ้ีอࠥอไๅ๊ะ๎ฮ࠭࠿"),l1111_l1_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨࡀ"),l1111_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧࡁ")]
	html = l111l11_l1_(l111ll_l1_,l1ll11l_l1_,l1111_l1_ (u"ࠧࠨࡂ"),headers,l1111_l1_ (u"ࠨࠩࡃ"),l1111_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪࡄ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡦ࡮࡭࡟ࡱࡣࡵࡸࡸࡥ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࡡࡶࡩࡦࡸࡣࡩࠩࡅ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪࡆ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if title not in l11ll11_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࡇ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪࡈ")+menu_name+title,l1l111l_l1_,71)
	return html
def CATEGORIES(url):
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠧࠨࡉ"),headers,l1111_l1_ (u"ࠨࠩࡊ"),l1111_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩࡋ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡷࡪࡩࡴࡠࡲࡤࡶࡹࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫࡌ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࡍ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = title.strip(l1111_l1_ (u"ࠬࠦࠧࡎ"))
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࡏ"),menu_name+title,l1l111l_l1_,72)
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࡐ"),menu_name+l1111_l1_ (u"ࠨฮ่๎฾ࠦวๅใิ์฾࠭ࡑ"),url,72)
	else: l1l11l1_l1_(url,l1111_l1_ (u"ࠩࠪࡒ"))
	return
def l1l11l1_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫࡓ"),l1111_l1_ (u"ࠫࠬࡔ"),url,type)
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠬ࠭ࡕ"),headers,True,l1111_l1_ (u"࠭ࡁࡌࡑࡄࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩࡖ"))
	items = []
	if type==l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩࡗ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡡࡷ࡭ࡹࡲࡥࠡࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡳࡶࡤ࡭ࡩࡨࡺࡳ࠮ࡥࡵࡳࡺࡹࡥ࡭ࠩࡘ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤ࡭ࡩࡨࡺ࡟ࡣࡱࡻ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀ࡙ࠪ"),block,re.DOTALL)
	elif type==l1111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪ࡚ࠪ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡢࡶࡪࡹࡵ࡭ࡶࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨ࡛"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠴ࡂࠬ࡜"),block,re.DOTALL)
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ࡝"),l1111_l1_ (u"ࠧࠨ࡞"),str(len(items)),block)
	elif type==l1111_l1_ (u"ࠨ࡯ࡲࡶࡪ࠭࡟"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡢࡸ࡮ࡺ࡬ࡦࠢࡰࡳࡷ࡫࡟ࡵ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴࡢࡦࡴࡺࡴࡰ࡯ࡢࡷࡪࡸࡶࡪࡥࡨࡷࠬࡠ"),html,re.DOTALL)
	#elif type==l1111_l1_ (u"ࠪࡲࡪࡽࡳࠨࡡ"):
	#	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡤࡺࡩࡵ࡮ࡨࠤࡳ࡫ࡷࡴࡡࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡴࡥࡸࡵࡢࡱࡴࡸࡥࡠࡥ࡫ࡳ࡮ࡩࡥࡴࠩࡢ"),html,re.DOTALL)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧࡣ"),html,re.DOTALL)
	if not items and l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨࡪࡦࡥࡷࡣࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨࡤ"),block,re.DOTALL)
	for l1l111l_l1_,img,title in items:
		if l1111_l1_ (u"ࠧหู๊๎าࠦ็ศ็ࠪࡥ") in title: continue
		title = title.replace(l1111_l1_ (u"ࠨ࡞ࡱࠫࡦ"),l1111_l1_ (u"ࠩࠪࡧ")).strip(l1111_l1_ (u"ࠪࠤࠬࡨ"))
		title = l1l1111_l1_(title)
		if any(value in title for value in l11l1_l1_): l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪࡩ"),menu_name+title,l1l111l_l1_,73,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࡪ"),menu_name+title,l1l111l_l1_,73,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࡫"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠢ࠽࠱࡯࡭ࡃࡂ࡬ࡪࠢࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ࡬"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࡭"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨ࡮")+title,l1l111l_l1_,72,l1111_l1_ (u"ࠪࠫ࡯"),l1111_l1_ (u"ࠫࠬࡰ"),type)
	return
def l1llll1_l1_(url):
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠬ࠭ࡱ"),headers,True,l1111_l1_ (u"࠭ࡁࡌࡑࡄࡑ࠲࡙ࡅࡄࡖࡌࡓࡓ࡙࠭࠳ࡰࡧࠫࡲ"))
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡪࡵࡩ࡫ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨࡳ"),html,re.DOTALL)
	l1l1lll_l1_ = l1l1lll_l1_[1]
	return l1l1lll_l1_
def l11111_l1_(url):
	#l111l1_l1_ = [l1111_l1_ (u"ࠨࡼ࡬ࡴࠬࡴ"),l1111_l1_ (u"ࠩࡵࡥࡷ࠭ࡵ"),l1111_l1_ (u"ࠪࡸࡽࡺࠧࡶ"),l1111_l1_ (u"ࠫࡵࡪࡦࠨࡷ"),l1111_l1_ (u"ࠬ࡮ࡴ࡮ࠩࡸ"),l1111_l1_ (u"࠭ࡴࡢࡴࠪࡹ"),l1111_l1_ (u"ࠧࡪࡵࡲࠫࡺ"),l1111_l1_ (u"ࠨࡪࡷࡱࡱ࠭ࡻ")]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠩࠪࡼ"),headers,True,l1111_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡖࡉࡈ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨࡽ"))
	l1ll1l1_l1_ = re.findall(l1111_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠯ࡀ࠯࠰ࡣ࡮ࡻࡦࡳ࠮࡯ࡧࡷ࠳ࡡࡽࠫ࠯ࠬࡂ࠭ࠧ࠭ࡾ"),html,re.DOTALL)
	l11l1ll_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸ࠰࠺࠰࠱ࡸࡲࡩ࡫ࡲࡶࡴ࡯࠲ࡨࡵ࡭࠰࡞ࡺ࠯࠳࠰࠿ࠪࠤࠪࡿ"),html,re.DOTALL)
	if l1ll1l1_l1_ or l11l1ll_l1_:
		if l1ll1l1_l1_: l11l11_l1_ = l1ll1l1_l1_[0]
		elif l11l1ll_l1_: l11l11_l1_ = l1llll1_l1_(l11l1ll_l1_[0])
		l11l11_l1_ = UNQUOTE(l11l11_l1_)
		import l1l1ll1_l1_
		if l1111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨࢀ") in l11l11_l1_ or l1111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡼࡹ࠯ࠨࢁ") in l11l11_l1_: l1l1ll1_l1_.l1l11ll_l1_(l11l11_l1_)
		else: l1l1ll1_l1_.l1lllll_l1_(l11l11_l1_)
		return
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠨ็ะฮํ๏ࠠศๆไ๎้๋࠮ࠫࡁࡁ࠲࠯ࡅࠨ࡝ࡹ࠭ࡃ࠮ࡢࡗࠫࡁ࠿ࠫࢂ"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	items = re.findall(l1111_l1_ (u"ࠩ࠿ࡦࡷࠦ࠯࠿࡞ࡱࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩࢃ"),html,re.DOTALL)
	for l1l111l_l1_,title in items:
		title = l1l1111_l1_(title)
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࢄ"),menu_name+title,l1l111l_l1_,73)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸࡻࡢࡠࡶ࡬ࡸࡱ࡫ࠢ࠯ࠬࡂࡀ࡭࠷࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠶ࡄ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡰࡥ࡮ࡴ࡟ࡪ࡯ࡪࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢࡦ࠰࠷࠵࠶࠭࠳࠷࠳ࠬ࠳࠰࠿ࠪࡣ࡮ࡳ࠲࡬ࡥࡦࡦࡥࡥࡨࡱࠧࢅ"),html,re.DOTALL)
	if not l111l1l_l1_:
		l1ll111_l1_(l1111_l1_ (u"ࠬิืฤࠢัหึา๊ࠨࢆ"),l1111_l1_ (u"࠭ไศࠢํ์ัีࠠๆๆไࠤๆ๐ฯ๋๊ࠪࢇ"))
		return
	name,img,block = l111l1l_l1_[0]
	name = name.strip(l1111_l1_ (u"ࠧࠡࠩ࢈"))
	if l1111_l1_ (u"ࠨࡵࡸࡦࡤ࡫ࡰࡴ࡫ࡲࡨࡪࡥࡴࡪࡶ࡯ࡩࠬࢉ") in block:
		items = re.findall(l1111_l1_ (u"ࠩࡶࡹࡧࡥࡥࡱࡵ࡬ࡳࡩ࡫࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁ࠲࠯ࡅࡳࡶࡤࡢࡪ࡮ࡲࡥࡠࡶ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪࢊ"),block,re.DOTALL)
	else:
		filenames = re.findall(l1111_l1_ (u"ࠪࡷࡺࡨ࡟ࡧ࡫࡯ࡩࡤࡺࡩࡵ࡮ࡨࡠࠬࡄࠨ࠯ࠬࡂ࠭ࠥ࠳ࠠ࠽࡫ࡁࠫࢋ"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l1111_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪࢌ"),filename) )
	if not items: items = [ (l1111_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫࢍ"),l1111_l1_ (u"࠭ࠧࢎ")) ]
	count = 0
	l11111l_l1_,l111ll1_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l1ll_l1_ = l1111_l1_ (u"ࠧࠨ࢏")
		if l1111_l1_ (u"ࠨࠢ࠰ࠤࠬ࢐") in filename: filename = filename.split(l1111_l1_ (u"ࠩࠣ࠱ࠥ࠭࢑"))[0]
		else: filename = l1111_l1_ (u"ࠪࡨࡺࡳ࡭ࡺ࠰ࡽ࡭ࡵ࠭࢒")
		if l1111_l1_ (u"ࠫ࠳࠭࢓") in filename: l1ll_l1_ = filename.split(l1111_l1_ (u"ࠬ࠴ࠧ࢔"))[-1]
		#if any(value in l1ll_l1_ for value in l111l1_l1_):
		#	if l1111_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬ࢕") not in title: title = title + l1111_l1_ (u"ࠧ࠻ࠩ࢖")
		title = title.replace(l1111_l1_ (u"ࠨ࡞ࡱࠫࢗ"),l1111_l1_ (u"ࠩࠪ࢘")).strip(l1111_l1_ (u"ࠪࠤ࢙ࠬ"))
		l11111l_l1_.append(title)
		l111ll1_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l11l1_l1_):
			if size==1:
				l1l_l1_ = 0
			else:
				#l11llll_l1_(l1111_l1_ (u"࢚ࠫࠬ"),l11111l_l1_)
				l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࢛࠭"), l11111l_l1_)
				if l1l_l1_ == -1: return
			l1lllll_l1_(url+l1111_l1_ (u"࠭࠿ࡴࡧࡦࡸ࡮ࡵ࡮࠾ࠩ࢜")+str(1+l111ll1_l1_[size-l1l_l1_-1]))
		else:
			for i in reversed(range(size)):
				#if l1111_l1_ (u"ࠧ࠻ࠩ࢝") in l11111l_l1_[i]: title = l11111l_l1_[i].strip(l1111_l1_ (u"ࠨ࠼ࠪ࢞")) + l1111_l1_ (u"ࠩࠣ࠱๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭࢟")
				#else: title = name + l1111_l1_ (u"ࠪࠤ࠲ࠦࠧࢠ") + l11111l_l1_[i]
				title = name + l1111_l1_ (u"ࠫࠥ࠳ࠠࠨࢡ") + l11111l_l1_[i]
				title = title.replace(l1111_l1_ (u"ࠬࡢ࡮ࠨࢢ"),l1111_l1_ (u"࠭ࠧࢣ")).strip(l1111_l1_ (u"ࠧࠡࠩࢤ"))
				l1l111l_l1_ = url + l1111_l1_ (u"ࠨࡁࡶࡩࡨࡺࡩࡰࡰࡀࠫࢥ")+str(size-i)
				l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨࢦ"),menu_name+title,l1l111l_l1_,74,img)
	else:
		l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩࢧ"),menu_name+l1111_l1_ (u"ࠫฬ๊ัศสฺࠤ้๐ำࠡใํำ๏๎ࠧࢨ"),l1111_l1_ (u"ࠬ࠭ࢩ"),9999,img)
		#l1ll111_l1_(l1111_l1_ (u"࠭ฮุลࠣาฬืฬ๋ࠩࢪ"),l1111_l1_ (u"ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐ฯ๋๊ࠪࢫ"))
	return
def l1lllll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩࢬ"),l1111_l1_ (u"ࠩࠪࢭ"),url,l1111_l1_ (u"ࠪࠫࢮ"))
	l1l1lll_l1_,l11l11l_l1_ = url.split(l1111_l1_ (u"ࠫࡄࡹࡥࡤࡶ࡬ࡳࡳࡃࠧࢯ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩࢰ"),l1l1lll_l1_,l1111_l1_ (u"࠭ࠧࢱ"),headers,True,l1111_l1_ (u"ࠧࠨࢲ"),l1111_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡑࡎࡄ࡝ࡤࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨࢳ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠴ࠪࡀࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠭࠴ࠪࡀࠫࡤ࡯ࡴ࠳ࡦࡦࡧࡧࡦࡦࡩ࡫ࠨࢴ"),html,re.DOTALL)
	l11ll1_l1_ = l111l1l_l1_[0].replace(l1111_l1_ (u"ࠥࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࡡࡥࡳࡽࠨࢵ"),l1111_l1_ (u"ࠫࠧࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠠࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼࠬࢶ"))
	l11ll1_l1_ = l11ll1_l1_ + l1111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠧࢷ")
	l1lll11_l1_ = re.findall(l1111_l1_ (u"࠭ࡥࡱࡵࡲ࡭ࡩ࡫࡟ࡣࡱࡻࠬ࠳࠰࠿ࠪࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࡥࡢࡰࡺࠪࢸ"),l11ll1_l1_,re.DOTALL)
	l11l11l_l1_ = len(l1lll11_l1_)-int(l11l11l_l1_)
	block = l1lll11_l1_[l11l11l_l1_]
	l11ll1l_l1_ = []
	l11l1l1_l1_ = {l1111_l1_ (u"ࠧ࠲࠶࠵࠷࠵࠽࠵࠹࠸࠵ࠫࢹ"):l1111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ࢺ"),l1111_l1_ (u"ࠩ࠴࠸࠼࠽࠴࠹࠹࠹࠴࠶࠭ࢻ"):l1111_l1_ (u"ࠪࡩࡸࡺࡲࡦࡣࡰࠫࢼ"),l1111_l1_ (u"ࠫ࠶࠻࠰࠶࠵࠵࠼࠹࠶࠴ࠨࢽ"):l1111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱࡦࡴࡧࡰࠩࢾ"),
		l1111_l1_ (u"࠭࠱࠵࠴࠶࠴࠽࠶࠰࠲࠷ࠪࢿ"):l1111_l1_ (u"ࠧࡧ࡮ࡤࡷ࡭ࡾࠧࣀ"),l1111_l1_ (u"ࠨ࠳࠷࠹࠽࠷࠱࠸࠴࠼࠹ࠬࣁ"):l1111_l1_ (u"ࠩࡲࡴࡪࡴ࡬ࡰࡣࡧࠫࣂ"),l1111_l1_ (u"ࠪ࠵࠹࠸࠳࠱࠹࠼࠷࠵࠼ࠧࣃ"):l1111_l1_ (u"ࠫࡻ࡯࡭ࡱ࡮ࡨࠫࣄ"),l1111_l1_ (u"ࠬ࠷࠴࠴࠲࠳࠹࠷࠹࠷࠲ࠩࣅ"):l1111_l1_ (u"࠭࡯࡬࠰ࡵࡹࠬࣆ"),
		l1111_l1_ (u"ࠧ࠲࠶࠺࠻࠹࠾࠸࠳࠳࠶ࠫࣇ"):l1111_l1_ (u"ࠨࡶ࡫ࡩࡻ࡯ࡤࠨࣈ"),l1111_l1_ (u"ࠩ࠴࠹࠺࠾࠲࠸࠺࠳࠴࠻࠭ࣉ"):l1111_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ࣊"),l1111_l1_ (u"ࠫ࠶࠺࠷࠸࠶࠻࠻࠾࠿࠰ࠨ࣋"):l1111_l1_ (u"ࠬࡼࡩࡥࡶࡲࡨࡴ࠭࣌")}
	items = re.findall(l1111_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡤࡷࡲ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ࣍"),block,re.DOTALL)
	for l1l111l_l1_ in items:
		l11ll1l_l1_.append(l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡢࡣࡤࡥ࡟ࡠࡣ࡮ࡳࡦࡳࠧ࣎"))
	items = re.findall(l1111_l1_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࣏࠭ࠧ"),block,re.DOTALL)
	for l1111l_l1_,l1l111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.split(l1111_l1_ (u"ࠩ࠲࣐ࠫ"))[-1]
		l1111l_l1_ = l1111l_l1_.split(l1111_l1_ (u"ࠪ࠲࣑ࠬ"))[0]
		if l1111l_l1_ in l11l1l1_l1_:
			l11ll1l_l1_.append(l1l111l_l1_+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁ࣒ࠬ")+l11l1l1_l1_[l1111l_l1_]+l1111_l1_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥࡡ࡬ࡱࡤࡱ࣓ࠬ"))
		else: l11ll1l_l1_.append(l1l111l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧࣔ")+l1111l_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡣ࡮ࡳࡦࡳࠧࣕ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩࣖ"),l1111_l1_ (u"ࠩࠪࣗ"),url,str(l11ll1l_l1_))
	if not l11ll1l_l1_:
		message = re.findall(l1111_l1_ (u"ࠪࡷࡺࡨ࠭࡯ࡱ࠰ࡪ࡮ࡲࡥ࠯ࠬࡂࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭ࣘ"),block,re.DOTALL)
		if message: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬࣙ"),l1111_l1_ (u"ࠬ࠭ࣚ"),l1111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨࣛ"),message[0])
	else:
		import ll_l1_
		ll_l1_.l11_l1_(l11ll1l_l1_,l111_l1_,l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ࣜ"),url)
	return
def l1lll1_l1_(search):
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩࣝ"),l1111_l1_ (u"ࠩࠪࣞ"),search,l1111_l1_ (u"ࠪࠫࣟ"))
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠫࠬ࣠"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠬ࠭࣡"): return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"࠭ࠠࠨ࣢"),l1111_l1_ (u"ࠧࠦ࠴࠳ࣣࠫ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪࣤ")+l1lll1l_l1_
	l11l_l1_ = l1l11l1_l1_(url,l1111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩࣥ"))
	return
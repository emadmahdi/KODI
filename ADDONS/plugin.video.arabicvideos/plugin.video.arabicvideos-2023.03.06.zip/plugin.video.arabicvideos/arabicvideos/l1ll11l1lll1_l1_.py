# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ俭")
#headers = {l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ修"):l1111_l1_ (u"ࠩࠪ俯")}
menu_name = l1111_l1_ (u"ࠪࡣࡘࡎࡐࡠࠩ俰")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"๊ࠫ฻วา฻ฬࠫ俱"),l1111_l1_ (u"ࠬฮหࠡ็หหูืࠧ俲")]
def l1111ll_l1_(mode,url,text):
	if   mode==480: l11l_l1_ = l11l111_l1_()
	elif mode==481: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==482: l11l_l1_ = l1lllll_l1_(url)
	elif mode==483: l11l_l1_ = l1l11ll_l1_(url,text)
	elif mode==489: l11l_l1_ = l1lll1_l1_(text,url)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ俳"),l1ll11l_l1_,l1111_l1_ (u"ࠧࠨ俴"),l1111_l1_ (u"ࠨࠩ俵"),l1111_l1_ (u"ࠩࠪ俶"),l1111_l1_ (u"ࠪࠫ俷"),l1111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ俸"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ俹"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"࠭࠯ࠨ俺"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ俻"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俼"),menu_name+l1111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ俽"),l1llll1lll_l1_,489,l1111_l1_ (u"ࠪࠫ俾"),l1111_l1_ (u"ࠫࠬ俿"),l1111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ倀"))
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ倁"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ倂"),l1111_l1_ (u"ࠨࠩ倃"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ倄"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ倅")+menu_name+l1111_l1_ (u"ࠫศำฯฬࠢส่๊๎วื์฼ࠫ倆"),l1llll1lll_l1_,481)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡰࡽࡆࡩࡣࡰࡷࡱࡸࠧ࠭倇"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ倈"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if l1l111l_l1_==l1111_l1_ (u"ࠧࠤࠩ倉"): continue
		if title in l11ll11_l1_: continue
		title = l1l1111_l1_(title)
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倊"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭個")+menu_name+title,l1l111l_l1_,481)
	return html
def l1l11l1_l1_(url,l1111ll1lll1_l1_):
	items = []
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ倌"),url,l1111_l1_ (u"ࠫࠬ倍"),l1111_l1_ (u"ࠬ࠭倎"),l1111_l1_ (u"࠭ࠧ倏"),l1111_l1_ (u"ࠧࠨ倐"),l1111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ們"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡴࡴࡹࡴࠩ࠰࠭ࡃ࠮ࠨࡦࡰࡱࡷࡩࡷࠨࠧ倒"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ倓"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ฺ๊ࠫว่ัฬࠫ倔"),l1111_l1_ (u"ࠬ็๊ๅ็ࠪ倕"),l1111_l1_ (u"࠭ว฻่ํอࠬ倖"),l1111_l1_ (u"ࠧฤ฼้๎ฮ࠭倗"),l1111_l1_ (u"ࠨๅ็๎อ࠭倘"),l1111_l1_ (u"ࠩส฽้อๆࠨ候"),l1111_l1_ (u"๋ࠪิอแࠨ倚"),l1111_l1_ (u"๊ࠫฮวาษฬࠫ倛"),l1111_l1_ (u"ࠬ฿ัืࠩ倜"),l1111_l1_ (u"࠭ๅ่ำฯห๋࠭倝"),l1111_l1_ (u"ࠧศๆห์๊࠭倞"),l1111_l1_ (u"ࠨ็ึีา๐ษࠨ借")]
	l1111ll1llll_l1_ = l1111_l1_ (u"ࠩ࠲ࠫ倠").join(l1111ll1lll1_l1_.strip(l1111_l1_ (u"ࠪ࠳ࠬ倡")).split(l1111_l1_ (u"ࠫ࠴࠭倢"))[4:]).split(l1111_l1_ (u"ࠬ࠳ࠧ倣"))
	for l1l111l_l1_,title,img in items:
		title = l1l1111_l1_(title)
		l11l11l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ値"),title,re.DOTALL)
		if l1111ll1lll1_l1_:
			l1lllll1ll_l1_ = l1111_l1_ (u"ࠧ࠰ࠩ倥").join(l1l111l_l1_.strip(l1111_l1_ (u"ࠨ࠱ࠪ倦")).split(l1111_l1_ (u"ࠩ࠲ࠫ倧"))[4:]).split(l1111_l1_ (u"ࠪ࠱ࠬ倨"))
			l1111lll1111_l1_ = len([x for x in l1111ll1llll_l1_ if x in l1lllll1ll_l1_])
			if l1111lll1111_l1_>2 and l1111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ倩") in l1l111l_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ倪"),menu_name+title,l1l111l_l1_,482,img)
		else:
			if not l11l11l_l1_: l11l11l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ倫"),title,re.DOTALL)
			#if any(value in title for value in l1lll1lll1_l1_):
			if set(title.split()) & set(l1lll1lll1_l1_) and l1111_l1_ (u"ࠧๆี็ื้࠭倬") not in title:
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ倭"),menu_name+title,l1l111l_l1_,482,img)
			elif l11l11l_l1_ and l1111_l1_ (u"ࠩะ่็ฯࠧ倮") in title:
				title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ倯") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ倰"),menu_name+title,l1l111l_l1_,483,img,l1111_l1_ (u"ࠬ࠭倱"),url)
					l1lllll1_l1_.append(title)
			else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭倲"),menu_name+title,l1l111l_l1_,483,img,l1111_l1_ (u"ࠧࠨ倳"),url)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠣࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠦ倴"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ倵"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠪห้฻แฮหࠣࠫ倶"),l1111_l1_ (u"ࠫࠬ倷"))
			if title!=l1111_l1_ (u"ࠬ࠭倸"): l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭倹"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭债")+title,l1l111l_l1_,481,l1111_l1_ (u"ࠨࠩ倻"),l1111_l1_ (u"ࠩࠪ值"),l1111ll1lll1_l1_)
	return
def l1l11ll_l1_(url,l1l1lll_l1_):
	headers = {l1111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭倽"):l1111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ倾")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ倿"),url,l1111_l1_ (u"࠭ࠧ偀"),headers,l1111_l1_ (u"ࠧࠨ偁"),l1111_l1_ (u"ࠨࠩ偂"),l1111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ偃"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧ偄"))
	img = re.findall(l1111_l1_ (u"ࠫࠧ࡯࡭ࡨ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ偅"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭偆"))
	l1111ll1ll1l_l1_ = True
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"࠭ࠢ࡭࡫ࡶࡸࡘ࡫ࡡࡴࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ假"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ偈") not in url:
		block = l1lll1l1ll_l1_[0]
		count = block.count(l1111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠬ偉"))
		if count==0: count = block.count(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠨ偊"))
		if count>1:
			l1111ll1ll1l_l1_ = False
			if l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠨ偋") in block:
				items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ偌"),block,re.DOTALL)
				for id,title in items:
					l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠲࠯ࡲ࡫ࡴࡄࡹ࡬ࡶࡩࡀࠫ偍")+id
					l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭偎"),menu_name+title,l1l111l_l1_,483,img)
			else:
				items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ偏"),block,re.DOTALL)
				for id,title in items:
					l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵ࡭ࡪࡹࡉࡅ࠿ࠪ偐")+id
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偑"),menu_name+title,l1l111l_l1_,483,img)
	# l1llll11_l1_
	if l1111ll1ll1l_l1_:
		block = l1111_l1_ (u"ࠪࠫ偒")
		if l1111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ偓") in url: block = html
		else:
			l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡥࡱ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ偔"),html,re.DOTALL)
			if l1l11lll1_l1_: block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ偕"),block,re.DOTALL)
		if items:
			for l1l111l_l1_,title in items:
				title = title.strip(l1111_l1_ (u"ࠧࠡࠩ偖"))
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ偗"),menu_name+title,l1l111l_l1_,482,img)
	if not menuItemsLIST: l1l11l1_l1_(l1l1lll_l1_,url)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url.strip(l1111_l1_ (u"ࠩ࠲ࠫ偘"))+l1111_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡹࡤࡸࡨ࡮ࠧ偙")
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ做"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭偛"),l1111_l1_ (u"࠭ࠧ停"),l1111_l1_ (u"ࠧࠨ偝"),l1111_l1_ (u"ࠨࠩ偞"),l1111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭偟"))
	html = response.content
	l11lll1l_l1_ = []
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧ偠"))
	l1lll111l1_l1_ = re.findall(l1111_l1_ (u"ࠫࡻࡵ࡟ࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ偡"),html,re.DOTALL)
	if not l1lll111l1_l1_: l1lll111l1_l1_ = re.findall(l1111_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ偢"),html,re.DOTALL)
	l1lll111l1_l1_ = l1lll111l1_l1_[0]
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ偣"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ偤"),block,re.DOTALL)
		for l1lll1l111_l1_,title in items:
			title = title.strip(l1111_l1_ (u"ࠨࠢࠪ健"))
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲࡭࡫ࡸࡡ࡮ࡧ࠵࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ偦")+l1lll111l1_l1_+l1111_l1_ (u"ࠪࠪࡻ࡯ࡤࡦࡱࡀࠫ偧")+l1lll1l111_l1_[2:]+l1111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ偨")+title+l1111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭偩")
			l11lll1l_l1_.append(l1l111l_l1_)
	# l11l1l11l_l1_ l11ll1l1l_l1_ l1l111l_l1_
	l1l111l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡨࡧࡷࡉࡲࡨࡥࡥࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ偪"),html,re.DOTALL)
	if l1l111l_l1_:
		title = l1l1lll1l_l1_(l1l111l_l1_[0],l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ偫"))
		l1l111l_l1_ = l1l111l_l1_[0]+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ偬")+title+l1111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ偭")
		l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l1l1lll_l1_ = url.strip(l1111_l1_ (u"ࠪ࠳ࠬ偮"))+l1111_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ偯")
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ偰"),l1l1lll_l1_,l1111_l1_ (u"࠭ࠧ偱"),l1111_l1_ (u"ࠧࠨ偲"),l1111_l1_ (u"ࠨࠩ偳"),l1111_l1_ (u"ࠩࠪ側"),l1111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ偵"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡺࡡࡣ࡮ࡨ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ偶"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ偷"),block,re.DOTALL)
		for title,l1l111l_l1_ in items:
			title = title.strip(l1111_l1_ (u"࠭ࠠࠨ偸"))
			if l1111_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ偹") in l1l111l_l1_: title2 = l1111_l1_ (u"ࠨࡡࡢาฬ฻ࠧ偺")
			else: title2 = l1111_l1_ (u"ࠩࠪ偻")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ偼")+title+l1111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ偽")+title2
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ偾"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ偿"),url)
	return
def l1lll1_l1_(search,l1llll1lll_l1_=l1111_l1_ (u"ࠧࠨ傀")):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠨࠩ傁"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠩࠪ傂"): return
	search = search.replace(l1111_l1_ (u"ࠪࠤࠬ傃"),l1111_l1_ (u"ࠫ࠰࠭傄"))
	if l1llll1lll_l1_==l1111_l1_ (u"ࠬ࠭傅"): l1llll1lll_l1_ = l1ll11l_l1_
	url = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ傆")+search+l1111_l1_ (u"ࠧ࠰ࠩ傇")
	l1l11l1_l1_(url,l1111_l1_ (u"ࠨࠩ傈"))
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᗺ")
menu_name=l1111_l1_ (u"࠭࡟ࡄࡏࡏࡣࠬᗻ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠧใ่๋หฯࠦแืษษ๎ฮ࠭ᗼ")]
def l1111ll_l1_(mode,url,text):
	if   mode==470: l11l_l1_ = l11l111_l1_()
	elif mode==471: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==472: l11l_l1_ = l1lllll_l1_(url)
	elif mode==473: l11l_l1_ = l1l11ll_l1_(url,text)
	elif mode==474: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==479: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬᗽ"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪᗾ"),l1111_l1_ (u"ࠪࠫᗿ"),l1111_l1_ (u"ࠫࠬᘀ"),l1111_l1_ (u"ࠬ࠭ᘁ"),l1111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᘂ"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡷࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᘃ"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"ࠨ࠱ࠪᘄ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭ᘅ"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘆ"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᘇ"),l1111_l1_ (u"ࠬ࠭ᘈ"),479,l1111_l1_ (u"࠭ࠧᘉ"),l1111_l1_ (u"ࠧࠨᘊ"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᘋ"))
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᘌ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᘍ"),l1111_l1_ (u"ࠫࠬᘎ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘏ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᘐ")+menu_name+l1111_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬᘑ"),l1llll1lll_l1_,471,l1111_l1_ (u"ࠨࠩᘒ"),l1111_l1_ (u"ࠩࠪᘓ"),l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬᘔ"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘕ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᘖ")+menu_name+l1111_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᘗ"),l1llll1lll_l1_,471,l1111_l1_ (u"ࠧࠨᘘ"),l1111_l1_ (u"ࠨࠩᘙ"),l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᘚ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᘛ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᘜ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		title = title.strip(l1111_l1_ (u"ࠬࠦࠧᘝ"))
		#if title in l11ll11_l1_: continue
		l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"࠭ࡣࡢࡶࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡱࡴࡼࡩࡦࡵ࠴ࠫᘞ"),l1111_l1_ (u"ࠧࡤࡣࡷࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶࠫᘟ"))
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘠ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᘡ")+menu_name+title,l1l111l_l1_,474)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘢ"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘣ"),l1111_l1_ (u"ࠬ࠭ᘤ"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᘥ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᘦ"),html,re.DOTALL)
	for l111ll1l_l1_ in l111l1l_l1_:
		block = block.replace(l111ll1l_l1_,l1111_l1_ (u"ࠨࠩᘧ"))
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᘨ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if title in l11ll11_l1_: continue
		#l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧᘩ")+category+l1111_l1_ (u"ࠫࡂ࠭ᘪ")+value
		l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘫ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᘬ")+menu_name+title,l1l111l_l1_,474)
	return
def l11lll1l1_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᘭ"),url,l1111_l1_ (u"ࠨࠩᘮ"),l1111_l1_ (u"ࠩࠪᘯ"),l1111_l1_ (u"ࠪࠫᘰ"),l1111_l1_ (u"ࠫࠬᘱ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᘲ"))
	html = response.content
	if l1111_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵ࠭ᘳ") in url: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡱ࠲࡭ࡲࡪࡦࠥࠫᘴ"),html,re.DOTALL)
	else: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᘵ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᘶ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if l1111_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪᘷ") in l1l111l_l1_:
				if l1111_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃࡥ࡯ࡩ࡯࡭ࡸ࡮࠭࡮ࡱࡹ࡭ࡪࡹࠧᘸ") in l1l111l_l1_: continue
				if l1111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹ࠱ࠨᘹ") in l1l111l_l1_: continue
				if l1111_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾࡯࡬ࡷࡨ࠭ᘺ") in l1l111l_l1_: continue
				if l1111_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡷࡺ࠲ࡩࡨࡢࡰࡱࡩࡱ࠭ᘻ") in l1l111l_l1_: continue
				if l1111_l1_ (u"ࠨ็้ิࠥอไษัส๎ฮ࠭ᘼ") in title and l1111_l1_ (u"ࠩࡧࡳࡂࡸࡡࡵ࡫ࡱ࡫ࠬᘽ") not in l1l111l_l1_: continue
			else: title = l1111_l1_ (u"ࠪฮึะ๊ษࠢหหุะฮะษ่࠾ࠥࠦࠧᘾ")+title
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘿ"),menu_name+title,l1l111l_l1_,471)
	else: l1l11l1_l1_(url)
	return
def l1l11l1_l1_(url,request=l1111_l1_ (u"ࠬ࠭ᙀ")):
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪᙁ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᙂ"),url,l1111_l1_ (u"ࠨࠩᙃ"),l1111_l1_ (u"ࠩࠪᙄ"),l1111_l1_ (u"ࠪࠫᙅ"),l1111_l1_ (u"ࠫࠬᙆ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᙇ"))
	html = response.content
	items = []
	if request==l1111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨᙈ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡫ࡲࡵࡪࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᙉ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠬᙊ"),block,re.DOTALL)
		l11l1ll1_l1_,l11l11l11_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,l11l1ll1_l1_,l11l11l11_l1_)
	elif request==l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᙋ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬᙌ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠩᙍ"),block,re.DOTALL)
		l11l1ll1_l1_,l11l11l11_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,l11l1ll1_l1_,l11l11l11_l1_)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙎ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭ᙏ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᙐ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙑ"),html,re.DOTALL)
		if not l111l1l_l1_: return
		block = l111l1l_l1_[0]
	if not items: items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙒ"),block,re.DOTALL)
	if not items: items = re.findall(l1111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᙓ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ฺ๊ࠫว่ัฬࠫᙔ"),l1111_l1_ (u"ࠬ็๊ๅ็ࠪᙕ"),l1111_l1_ (u"࠭ว฻่ํอࠬᙖ"),l1111_l1_ (u"ࠧไๆํฬࠬᙗ"),l1111_l1_ (u"ࠨษ฼่ฬ์ࠧᙘ"),l1111_l1_ (u"๊ࠩำฬ็ࠧᙙ"),l1111_l1_ (u"้ࠪออัศหࠪᙚ"),l1111_l1_ (u"ࠫ฾ืึࠨᙛ"),l1111_l1_ (u"๋ࠬ็าฮส๊ࠬᙜ"),l1111_l1_ (u"࠭วๅส๋้ࠬᙝ"),l1111_l1_ (u"ࠧๆีิั๏ฯࠧᙞ")]
	for img,l1l111l_l1_,title in items:
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠨ࠱ࠪᙟ"))
		if l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᙠ") not in l1l111l_l1_: l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࠬᙡ")+l1l111l_l1_.strip(l1111_l1_ (u"ࠫ࠴࠭ᙢ"))
		if l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᙣ") not in img: img = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࠨᙤ")+img.strip(l1111_l1_ (u"ࠧ࠰ࠩᙥ"))
		#l1l111l_l1_ = l1l1111_l1_(l1l111l_l1_)
		#title = l1l1111_l1_(title)
		#title = title.strip(l1111_l1_ (u"ࠨࠢࠪᙦ"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᙧ"),title,re.DOTALL)
		if any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᙨ"),menu_name+title,l1l111l_l1_,472,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠫฬ๊อๅไฬࠫᙩ") in title:
			title = l1111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᙪ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙫ"),menu_name+title,l1l111l_l1_,473,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᙬ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᙭"),menu_name+title,l1l111l_l1_,471,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᙮"),menu_name+title,l1l111l_l1_,473,img)
	if request not in [l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬᙯ"),l1111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᙰ")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙱ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᙲ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1l111l_l1_==l1111_l1_ (u"ࠧࠤࠩᙳ"): continue
				l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࠪᙴ")+l1l111l_l1_.strip(l1111_l1_ (u"ࠩ࠲ࠫᙵ"))
				title = l1l1111_l1_(title)
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙶ"),menu_name+l1111_l1_ (u"ฺࠫ็อสࠢࠪᙷ")+title,l1l111l_l1_,471)
		l1111111l_l1_ = re.findall(l1111_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᙸ"),html,re.DOTALL)
		if l1111111l_l1_:
			l1l111l_l1_ = l1111111l_l1_[0]
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙹ"),menu_name+l1111_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧᙺ"),l1l111l_l1_,471)
	return
def l1l11ll_l1_(url,l1ll1ll1ll_l1_):
	#LOG_THIS(l1111_l1_ (u"ࠨࠩᙻ"),l1111_l1_ (u"ࠩ࠴࠵࠶࠷ࠠࠡࠩᙼ")+url)
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠪࡹࡷࡲࠧᙽ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᙾ"),url,l1111_l1_ (u"ࠬ࠭ᙿ"),l1111_l1_ (u"࠭ࠧ "),l1111_l1_ (u"ࠧࠨᚁ"),l1111_l1_ (u"ࠨࠩᚂ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫᚃ"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᚄ"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩᚅ")+l1ll1ll1ll_l1_+l1111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᚆ"),html,re.DOTALL)
	items = []
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and not l1ll1ll1ll_l1_:
		img = re.findall(l1111_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᚇ"),html,re.DOTALL)
		img = img[0]
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࡞࠯ࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫᚈ"),block,re.DOTALL)
		for l1ll1ll1ll_l1_,title in items: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᚉ"),menu_name+title,url,473,img,l1111_l1_ (u"ࠩࠪᚊ"),l1ll1ll1ll_l1_)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		#img = xbmc.getInfoLabel(l1111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫᚋ"))
		img = re.findall(l1111_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᚌ"),html,re.DOTALL)
		img = img[0]
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡺࡩࡵ࡮ࡨࡁࠬ࠮࠮ࠫࡁࠬࠫࠥ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࠦᚍ"),block,re.DOTALL)
		if items:
			for title,l1l111l_l1_ in items:
				l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࠨᚎ")+l1l111l_l1_.strip(l1111_l1_ (u"ࠧ࠰ࠩᚏ"))
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᚐ"),menu_name+title,l1l111l_l1_,472,img)
		else:
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᚑ"),block,re.DOTALL)
			for l1l111l_l1_,title,img in items:
				if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᚒ") not in l1l111l_l1_: l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠫ࠴࠭ᚓ")+l1l111l_l1_.strip(l1111_l1_ (u"ࠬ࠵ࠧᚔ"))
				l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚕ"),menu_name+title,l1l111l_l1_,472,img)
	if l1111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩᚖ") in html:
		if items: l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᚗ"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᚘ"),l1111_l1_ (u"ࠪࠫᚙ"),9999)
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᚚ"),menu_name+l1111_l1_ (u"๋่ࠬศุํ฽ࠥึวหุ่ࠢฮ࠭᚛"),url,471)
	#else: l1l11l1_l1_(url)
	return
def l1lllll_l1_(url):
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ᚜"))
	l11lll1l_l1_ = []
	# l1ll1ll1l1_l1_ check
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ᚝"),url,l1111_l1_ (u"ࠨࠩ᚞"),l1111_l1_ (u"ࠩࠪ᚟"),l1111_l1_ (u"ࠪࠫᚠ"),l1111_l1_ (u"ࠫࠬᚡ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᚢ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡮ࡁࠫᚣ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l1llll_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᚤ"),block,re.DOTALL)
		if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_,True): return
	# default l11ll1l1l_l1_ l1l111l_l1_
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚥ"),html,re.DOTALL)
	if l1l111l_l1_:
		l1l111l_l1_ = l1l111l_l1_[0]+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪᚦ")
		if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᚧ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᚨ")+l1l111l_l1_
		l11lll1l_l1_.append(l1l111l_l1_)
	# l11l1l11l_l1_ l11ll1l1l_l1_ l1l111l_l1_
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨ࡚ࡘࡌࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᚩ"),html,re.DOTALL)
	if l1l111l_l1_:
		l1l111l_l1_ = l1l111l_l1_[0]+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧᚪ")
		if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬᚫ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᚬ")+l1l111l_l1_
		l11lll1l_l1_.append(l1l111l_l1_)
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l1l1lll_l1_ = url.replace(l1111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ᚭ"),l1111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭ᚮ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᚯ"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭ᚰ"),l1111_l1_ (u"࠭ࠧᚱ"),l1111_l1_ (u"ࠧࠨᚲ"),l1111_l1_ (u"ࠨࠩᚳ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧᚴ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᚵ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪᚶ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᚷ")+title+l1111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᚸ")
			if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬᚹ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᚺ")+l1l111l_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l1l1lll_l1_ = url.replace(l1111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ᚻ"),l1111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪᚼ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᚽ"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭ᚾ"),l1111_l1_ (u"࠭ࠧᚿ"),l1111_l1_ (u"ࠧࠨᛀ"),l1111_l1_ (u"ࠨࠩᛁ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧᛂ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᛃ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ᛄ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᛅ")+title+l1111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᛆ")
			if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬᛇ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᛈ")+l1l111l_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᛉ"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᛊ"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠫࠬᛋ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠬ࠭ᛌ"): return
	search = search.replace(l1111_l1_ (u"࠭ࠠࠨᛍ"),l1111_l1_ (u"ࠧࠬࠩᛎ"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩᛏ")+search
	l1l11l1_l1_(url)
	return
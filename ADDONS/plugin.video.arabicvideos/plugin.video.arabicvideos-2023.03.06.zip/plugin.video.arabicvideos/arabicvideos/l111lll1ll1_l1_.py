# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭丰")
menu_name = l1111_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ丱")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
headers = {l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ串"):None}
def l1111ll_l1_(mode,url,text):
	if   mode==310: l11l_l1_ = l11l111_l1_()
	elif mode==311: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==312: l11l_l1_ = l1lllll_l1_(url)
	elif mode==313: l11l_l1_ = l1111lllll1l_l1_(url)
	elif mode==314: l11l_l1_ = l1llll1ll_l1_(text)
	elif mode==319: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭丳"),menu_name+l1111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ临"),l1111_l1_ (u"ࠨࠩ丵"),319,l1111_l1_ (u"ࠩࠪ丶"),l1111_l1_ (u"ࠪࠫ丷"),l1111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ丸"))
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丹"),menu_name+l1111_l1_ (u"࠭แๅฬิࠫ为"),l1111_l1_ (u"ࠧࠨ主"),114,l1ll11l_l1_)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ丼"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪ丽"),l1111_l1_ (u"ࠪࠫ举"),l1111_l1_ (u"ࠫࠬ丿"),l1111_l1_ (u"ࠬ࠭乀"),l1111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ乁"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶ࡮࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ乂"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭乃"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ乄"),l1111_l1_ (u"ࠪࠫ久"),9999)
	items = re.findall(l1111_l1_ (u"ࠫࡁ࡮࠵࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠸ࡂࠬ乆"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1111_l1_ (u"ࠬࠦࠧ乇"))
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭么"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ义")+menu_name+title,l1ll11l_l1_,314,l1111_l1_ (u"ࠨࠩ乊"),l1111_l1_ (u"ࠩࠪ之"),str(seq+1))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乌"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ乍")+menu_name+l1111_l1_ (u"๋ࠬโศู฼ࠤูํัࠨ乎"),l1ll11l_l1_,314,l1111_l1_ (u"࠭ࠧ乏"),l1111_l1_ (u"ࠧࠨ乐"),l1111_l1_ (u"ࠨ࠲ࠪ乑"))
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ乒"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ乓"),l1111_l1_ (u"ࠫࠬ乔"),9999)
	items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡃࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡅࡂࠬ乕"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࠨ乖")+l1l111l_l1_
		#title = title.strip(l1111_l1_ (u"ࠧࠡࠩ乗"))
		#url = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡃࡪ࡯ࡤࡒࡴࡽ࠯ࡊࡰࡷࡩࡷ࡬ࡡࡤࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠱ࡴ࡭ࡶࠧ乘")
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乙"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ乚")+menu_name+title,l1l111l_l1_,311)
	return html
def l1llll1ll_l1_(seq):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ乛"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭乜"),l1111_l1_ (u"࠭ࠧ九"),l1111_l1_ (u"ࠧࠨ乞"),l1111_l1_ (u"ࠨࠩ也"),l1111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ习"))
	html = response.content
	if seq==l1111_l1_ (u"ࠪ࠴ࠬ乡"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ乢"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ乣"),block,re.DOTALL)
		for l1l111l_l1_,name,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࠨ乤")+l1l111l_l1_
			title = title.strip(l1111_l1_ (u"ࠧࠡࠩ乥"))
			name = name.strip(l1111_l1_ (u"ࠨࠢࠪ书"))
			title = title+l1111_l1_ (u"ࠩࠣࠬࠬ乧")+name+l1111_l1_ (u"ࠪ࠭ࠬ乨")
			l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ乩"),menu_name+title,l1l111l_l1_,312)
	elif seq in [l1111_l1_ (u"ࠬ࠷ࠧ乪"),l1111_l1_ (u"࠭࠲ࠨ乫"),l1111_l1_ (u"ࠧ࠴ࠩ乬")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠪ࠿࡬࠺ࡄ࠮ࠫࡁࠬࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡲࡧࠨ乭"),html,re.DOTALL)
		l1111lllll11_l1_ = int(seq)-1
		block = l111l1l_l1_[l1111lllll11_l1_]
		if seq==l1111_l1_ (u"ࠩ࠴ࠫ乮"): items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ乯"),block,re.DOTALL)
		else: items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ买"),block,re.DOTALL)
		for l1l111l_l1_,img,title,name in items:
			img = l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࠧ乱")+img
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࠨ乲")+l1l111l_l1_
			title = title.strip(l1111_l1_ (u"ࠧࠡࠩ乳"))
			name = name.strip(l1111_l1_ (u"ࠨࠢࠪ乴"))
			title = title+l1111_l1_ (u"ࠩࠣࠬࠬ乵")+name+l1111_l1_ (u"ࠪ࠭ࠬ乶")
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乷"),menu_name+title,l1l111l_l1_,311,img)
	elif seq in [l1111_l1_ (u"ࠬ࠺ࠧ乸"),l1111_l1_ (u"࠭࠵ࠨ乹"),l1111_l1_ (u"ࠧ࠷ࠩ乺")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠪ࠿࡬࠺ࡄ࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ乻"),html,re.DOTALL)
		seq = int(seq)-4
		block = l111l1l_l1_[seq]
		items = re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࠳ࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ乼"),block,re.DOTALL)
		for img,l1l111l_l1_,l1ll1111111_l1_,title,name2 in items:
			img = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࠬ乽")+img
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴࠭乾")+l1l111l_l1_
			title = title.strip(l1111_l1_ (u"ࠬࠦࠧ乿"))
			l1ll1111111_l1_ = l1ll1111111_l1_.strip(l1111_l1_ (u"࠭ࠠࠨ亀"))
			name2 = name2.strip(l1111_l1_ (u"ࠧࠡࠩ亁"))
			if l1ll1111111_l1_: name = l1ll1111111_l1_
			else: name = name2
			title = title+l1111_l1_ (u"ࠨࠢࠫࠫ亂")+name+l1111_l1_ (u"ࠩࠬࠫ亃")
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ亄"),menu_name+title,l1l111l_l1_,312,img)
	return
def l1l11l1_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ亅"),url,l1111_l1_ (u"ࠬ࠭了"),l1111_l1_ (u"࠭ࠧ亇"),l1111_l1_ (u"ࠧࠨ予"),l1111_l1_ (u"ࠨࠩ争"),l1111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ亊"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪ࡭ࡧࡵࡸ࠮ࡪࡨࡥࡩ࡯࡮ࡨࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧ࡮ࡲࡥࡹ࠳ࡲࡪࡩ࡫ࡸࠬ事"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	if l1111_l1_ (u"ࠫࡨࡧࡴࡴࡷࡰ࠱ࡲࡵࡢࡪ࡮ࡨࠫ二") in block:
		items = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂࡧࡦࡺࡳࡶ࡯࠰ࡱࡴࡨࡩ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ亍"),block,re.DOTALL)
		if items:
			for img,l1l111l_l1_,title,count in items:
				img = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࠨ于")+img
				l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࠩ亏")+l1l111l_l1_
				count = count.replace(l1111_l1_ (u"ࠨࠢสฺ่๎ส๋ห࠽ࠤࠬ亐"),l1111_l1_ (u"ࠩ࠽ࠫ云"))
				title = title.strip(l1111_l1_ (u"ࠪࠤࠬ互"))
				title = title+l1111_l1_ (u"ࠫࠥ࠮ࠧ亓")+count+l1111_l1_ (u"ࠬ࠯ࠧ五")
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭井"),menu_name+title,l1l111l_l1_,311,img)
	else:
		items = re.findall(l1111_l1_ (u"ࠧࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ亖"),block,re.DOTALL)
		for l1l111l_l1_,title,l1111llllll1_l1_,duration in items:
			if title==l1111_l1_ (u"ࠨࠩ亗") or l1111llllll1_l1_==l1111_l1_ (u"ࠩࠪ亘"): continue
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࠬ亙")+l1l111l_l1_
			title = title+l1111_l1_ (u"ࠫࠥ࠮ࠧ亚")+duration+l1111_l1_ (u"ࠬ࠯ࠧ些")
			l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ亜"),menu_name+title,l1l111l_l1_,312)
	if not items: l1l11ll_l1_(html)
	return
def l1l11ll_l1_(html):
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ亝"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭亞"),block,re.DOTALL)
	for l1l111l_l1_,title,name,count,duration in items:
		l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࠫ亟")+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"ࠪࠤࠬ亠"))
		name = name.strip(l1111_l1_ (u"ࠫࠥ࠭亡"))
		title = title+l1111_l1_ (u"ࠬࠦࠨࠨ亢")+name+l1111_l1_ (u"࠭ࠩࠨ亣")
		l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭交"),menu_name+title,l1l111l_l1_,312,l1111_l1_ (u"ࠨࠩ亥"),duration)
	return
def l1111lllll1l_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭亦"),url,l1111_l1_ (u"ࠪࠫ产"),l1111_l1_ (u"ࠫࠬ亨"),l1111_l1_ (u"ࠬ࠭亩"),l1111_l1_ (u"࠭ࠧ亪"),l1111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡗࡊࡇࡒࡄࡊࡢࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭享"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠠࡱ࠯࠴ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ京"),html,re.DOTALL)
	if not l111l1l_l1_:
		l1l11l1_l1_(url)
		return
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ亭"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࠬ亮")+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"ࠫࠥ࠭亯"))
		if l1111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠱ࠬ亰") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ亱"),menu_name+title,l1l111l_l1_,312)
		else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亲"),menu_name+title,l1l111l_l1_,311)
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ亳"),url,l1111_l1_ (u"ࠩࠪ亴"),l1111_l1_ (u"ࠪࠫ亵"),l1111_l1_ (u"ࠫࠬ亶"),l1111_l1_ (u"ࠬ࠭亷"),l1111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ亸"))
	html = response.content
	l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠧ࠽ࡣࡸࡨ࡮ࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ亹"),html,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ人"),html,re.DOTALL)
	l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_[0]
	l1ll11ll1_l1_(l1l111l_l1_,l111_l1_,l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ亻"))
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫ亼"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬ亽"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧ亾"),l1111_l1_ (u"࠭ࠫࠨ亿"))
	l1l1l1l1ll1_l1_ = [l1111_l1_ (u"ࠧࠧࡶࡀࡥࠬ什"),l1111_l1_ (u"ࠨࠨࡷࡁࡨ࠭仁"),l1111_l1_ (u"ࠩࠩࡸࡂࡹࠧ仂")]
	if l1ll11_l1_:
		l1l1l111lll_l1_ = [l1111_l1_ (u"ࠪๆฬืฦࠨ仃"),l1111_l1_ (u"ࠫส฻ฯศำࠣ࠳๋ࠥฬๅัࠪ仄"),l1111_l1_ (u"๋ࠬโุ฻ࠣห้฻่ห์ࠪ仅")]
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡ࠯ࠣวำะัࠡษ็ฬาัࠧ仆"), l1l1l111lll_l1_)
		if l1l_l1_ == -1: return
	elif l1111_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࡤ࠭仇") in options: l1l_l1_ = 0
	elif l1111_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࡤ࠭仈") in options: l1l_l1_ = 1
	elif l1111_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘࡥࠧ仉") in options: l1l_l1_ = 2
	else: return
	type = l1l1l1l1ll1_l1_[l1l_l1_]
	url = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫ今")+search+type
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ介"),url,l1111_l1_ (u"ࠬ࠭仌"),l1111_l1_ (u"࠭ࠧ仍"),l1111_l1_ (u"ࠧࠨ从"),l1111_l1_ (u"ࠨࠩ仏"),l1111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ仐"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ仑"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭仒"),block,re.DOTALL)
			for l1l111l_l1_,img,title,name in items:
				title = title.strip(l1111_l1_ (u"ࠬࠦࠧ仓"))
				name = name.strip(l1111_l1_ (u"࠭ࠠࠨ仔"))
				title = title+l1111_l1_ (u"ࠧࠡࠪࠪ仕")+name+l1111_l1_ (u"ࠨࠫࠪ他")
				l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ仗"),menu_name+title,l1l111l_l1_,313,img)
		elif l1l_l1_==2:
			items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽ࠩ付"),block,re.DOTALL)
			for l1l111l_l1_,title,name in items:
				title = title.strip(l1111_l1_ (u"ࠫࠥ࠭仙"))
				name = name.strip(l1111_l1_ (u"ࠬࠦࠧ仚"))
				title = title+l1111_l1_ (u"࠭ࠠࠩࠩ仛")+name+l1111_l1_ (u"ࠧࠪࠩ仜")
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ仝"),menu_name+title,l1l111l_l1_,312)
	return
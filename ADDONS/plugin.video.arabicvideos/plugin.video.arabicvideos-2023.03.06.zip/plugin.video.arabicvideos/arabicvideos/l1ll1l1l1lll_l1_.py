# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ儕")
headers = {l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ儖"):l1111_l1_ (u"ࠫࠬ儗")}
menu_name=l1111_l1_ (u"ࠬࡥࡗࡄࡏࡢࠫ儘")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ儙"),l1111_l1_ (u"ࠧࡸࡹࡨࠫ儚")]
def l1111ll_l1_(mode,url,text):
	if   mode==570: l11l_l1_ = l11l111_l1_()
	elif mode==571: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==572: l11l_l1_ = l1lllll_l1_(url)
	elif mode==573: l11l_l1_ = l1l11ll_l1_(url,text)
	elif mode==574: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ儛")+text)
	elif mode==575: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭儜")+text)
	elif mode==576: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==579: l11l_l1_ = l1lll1_l1_(text,url)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ儝"),l1ll11l_l1_,l1111_l1_ (u"ࠫࠬ儞"),l1111_l1_ (u"ࠬ࠭償"),False,l1111_l1_ (u"࠭ࠧ儠"),l1111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ儡"))
	#hostname = response.headers[l1111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ儢")]
	#hostname = hostname.strip(l1111_l1_ (u"ࠩ࠲ࠫ儣"))
	#l1llll1lll_l1_ = l1ll11l_l1_
	#url = l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ儤")
	#url = l1llll1lll_l1_
	#response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ儥"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭儦"),l1111_l1_ (u"࠭ࠧ儧"),l1111_l1_ (u"ࠧࠨ儨"),l1111_l1_ (u"ࠨࠩ儩"),l1111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ優"))
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ儫"),menu_name+l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儬"),l1111_l1_ (u"ࠬ࠭儭"),8)
	#l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ儮"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ儯"),l1111_l1_ (u"ࠨࠩ儰"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ儱"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ儲"),l1ll11l_l1_,579,l1111_l1_ (u"ࠫࠬ儳"),l1111_l1_ (u"ࠬ࠭儴"),l1111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ儵"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儶"),menu_name+l1111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ儷"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ儸"),574)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ儹"),menu_name+l1111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ儺"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ儻"),575)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ儼"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ儽"),l1111_l1_ (u"ࠨࠩ儾"),9999)
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ儿"):hostname,l1111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ兀"):l1111_l1_ (u"ࠫࠬ允")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1111_l1_ (u"ࠬࡢ࠯ࠨ兂"),l1111_l1_ (u"࠭࠯ࠨ元"))
	#l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡦࡪ࡮ࡷࡩࡷ࠭兄"),html,re.DOTALL)
	#if l111l1l_l1_:
	#	block = l111l1l_l1_[0]
	#	items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ充"),block,re.DOTALL)
	#	for l1l111l_l1_,title in items:
	#		if l1111_l1_ (u"ࠩࠨࡨ࠾ࠫ࠸࠶ࠧࡧ࠼ࠪࡨ࠵ࠦࡦ࠻ࠩࡦ࠽ࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡥ࠽ࠪࡪ࠸ࠦࡣ࠼࠱ࠪࡪ࠸ࠦࡣࡧࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡡ࠺ࠩ兆") in l1l111l_l1_: continue
	#		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ兇"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ先")+menu_name+title,l1l111l_l1_,576)
	#	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ光"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭兊"),l1111_l1_ (u"ࠧࠨ克"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ兌"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪ免"),l1111_l1_ (u"ࠪࠫ兎"),l1111_l1_ (u"ࠫࠬ兏"),l1111_l1_ (u"ࠬ࠭児"),l1111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ兑"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ兒"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ兓"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#if l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ兔") not in l1l111l_l1_:
			#	server = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧ兕"))
			#	l1l111l_l1_ = l1l111l_l1_.replace(server,l1llll1lll_l1_)
			if title==l1111_l1_ (u"ࠫࠬ兖"): continue
			if any(value in title.lower() for value in l11ll11_l1_): continue
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ兗"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ兘")+menu_name+title,l1l111l_l1_,576)
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ兙"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ党"),l1111_l1_ (u"ࠩࠪ兛"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩࠬ兜"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ兝"),block,re.DOTALL)
		for l1l111l_l1_,img,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ兞"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ兟")+menu_name+title,l1l111l_l1_,576,img)
	return html
def l11lll1l1_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ兠"),l1111_l1_ (u"ࠨࠩ兡"),url,l1111_l1_ (u"ࠩࠪ兢"))
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ兣"):url,l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ兤"):l1111_l1_ (u"ࠬ࠭入")}
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ兦"),url,l1111_l1_ (u"ࠧࠨ內"),l1111_l1_ (u"ࠨࠩ全"),l1111_l1_ (u"ࠩࠪ兩"),l1111_l1_ (u"ࠪࠫ兪"),l1111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ八"))
	html = response.content
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ公"),menu_name+l1111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ六"),url,574)
	#l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ兮"),menu_name+l1111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ兯"),url,575)
	if l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ兰") in html:
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ共"),menu_name+l1111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ兲"),url,571,l1111_l1_ (u"ࠬ࠭关"),l1111_l1_ (u"࠭ࠧ兴"),l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ兵"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ其"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ具"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ典"),menu_name+title,l1l111l_l1_,571)
	return
def l1l11l1_l1_(l1l1l1llll11_l1_,type=l1111_l1_ (u"ࠫࠬ兹")):
	if l1111_l1_ (u"ࠬࡀ࠺ࠨ兺") in l1l1l1llll11_l1_:
		l11l11_l1_,url = l1l1l1llll11_l1_.split(l1111_l1_ (u"࠭࠺࠻ࠩ养"))
		server = l1l1lll1l_l1_(l11l11_l1_,l1111_l1_ (u"ࠧࡶࡴ࡯ࠫ兼"))
		url = server+url
	else: url,l11l11_l1_ = l1l1l1llll11_l1_,l1l1l1llll11_l1_
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ兽"):l11l11_l1_,l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭兾"):l1111_l1_ (u"ࠪࠫ兿")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ冀"),url,l1111_l1_ (u"ࠬ࠭冁"),l1111_l1_ (u"࠭ࠧ冂"),l1111_l1_ (u"ࠧࠨ冃"),l1111_l1_ (u"ࠨࠩ冄"),l1111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭内"))
	html = response.content
	if type==l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ円"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠨ冇"),html,re.DOTALL)
	elif type==l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭冈"):
		l111l1l_l1_ = [html.replace(l1111_l1_ (u"࠭࡜࡝࠱ࠪ冉"),l1111_l1_ (u"ࠧ࠰ࠩ冊")).replace(l1111_l1_ (u"ࠨ࡞࡟ࠦࠬ冋"),l1111_l1_ (u"ࠩࠥࠫ册"))]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡋࡷ࡯ࡤ࠮࠯࡚ࡩࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ再"),html,re.DOTALL)
	l1lllll1_l1_ = []
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ冎"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			if any(value in title.lower() for value in l11ll11_l1_): continue
			img = escapeUNICODE(img)
			title = l1l1111_l1_(title)
			title = escapeUNICODE(title)
			title = title.replace(l1111_l1_ (u"๋ࠬิศ้าอࠥ࠭冏"),l1111_l1_ (u"࠭ࠧ冐"))
			if l1111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ冑") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ冒"),menu_name+title,l1l111l_l1_,573,img)
			elif l1111_l1_ (u"ࠩะ่็ฯࠧ冓") in title:
				l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭冔"),title,re.DOTALL)
				if l11l11l_l1_: title = l1111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ冕") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1lllll1_l1_.append(title)
					l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冖"),menu_name+title,l1l111l_l1_,573,img)
			else:
				l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ冗"),menu_name+title,l1l111l_l1_,572,img)
		if type==l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ冘"):
			l1l1l1lll1ll_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭写"),block,re.DOTALL)
			if l1l1l1lll1ll_l1_:
				count = l1l1l1lll1ll_l1_[0]
				l1l111l_l1_ = url+l1111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ冚")+count
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ军"),menu_name+l1111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ农"),l1l111l_l1_,571,l1111_l1_ (u"ࠬ࠭冝"),l1111_l1_ (u"࠭ࠧ冞"),l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ冟"))
		elif type==l1111_l1_ (u"ࠨࠩ冠"):
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ冡"),html,re.DOTALL)
			if l111l1l_l1_:
				block = l111l1l_l1_[0]
				items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ冢"),block,re.DOTALL)
				for l1l111l_l1_,title in items:
					title = l1111_l1_ (u"ฺࠫ็อสࠢࠪ冣")+l1l1111_l1_(title)
					l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冤"),menu_name+title,l1l111l_l1_,571)
	return
def l1l11ll_l1_(url,type=l1111_l1_ (u"࠭ࠧ冥")):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ冦"),url,l1111_l1_ (u"ࠨࠩ冧"),l1111_l1_ (u"ࠩࠪ冨"),l1111_l1_ (u"ࠪࠫ冩"),l1111_l1_ (u"ࠫࠬ冪"),l1111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ冫"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1111_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤ࡬ࡸࡪࡳࠢࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠭࠴ࠪࡀࠫࠥࠫ冬"),html,re.DOTALL)
	if name: name = name[-1].replace(l1111_l1_ (u"ࠧ࠮ࠩ冭"),l1111_l1_ (u"ࠨࠢࠪ冮")).strip(l1111_l1_ (u"ࠩ࠲ࠫ冯"))
	if l1111_l1_ (u"้ࠪํูๅࠨ冰") in name and type==l1111_l1_ (u"ࠫࠬ冱"):
		name = name.split(l1111_l1_ (u"๋่ࠬิ็ࠪ冲"))[0]
		name = name.replace(l1111_l1_ (u"࠭ๅีษ๊ำฮ࠭决"),l1111_l1_ (u"ࠧࠨ冴")).strip(l1111_l1_ (u"ࠨࠢࠪ况"))
	elif l1111_l1_ (u"ࠩะ่็ฯࠧ冶") in name:
		name = name.split(l1111_l1_ (u"ࠪั้่ษࠨ冷"))[0]
		name = name.replace(l1111_l1_ (u"ฺ๊ࠫว่ัฬࠫ冸"),l1111_l1_ (u"ࠬ࠭冹")).strip(l1111_l1_ (u"࠭ࠠࠨ冺"))
	else: name = name
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࠫ冻"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		if type==l1111_l1_ (u"ࠨࠩ冼"):
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ冽"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ冾") in title: continue
				if l1111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ冿") in title: continue
				title = name+l1111_l1_ (u"ࠬࠦ࠭ࠡࠩ净")+title
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭凁"),menu_name+title,l1l111l_l1_,573,l1111_l1_ (u"ࠧࠨ凂"),l1111_l1_ (u"ࠨࠩ凃"),l1111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ凄"))
		if len(menuItemsLIST)==0:
			l111ll1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠨࠩࠫ凅"),block+l1111_l1_ (u"ࠫࠫࠬࠧ准"),re.DOTALL)
			if l111ll1l_l1_: block = l111ll1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭凇"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				title = title.strip(l1111_l1_ (u"࠭ࠠࠨ凈"))
				title = name+l1111_l1_ (u"ࠧࠡ࠯ࠣࠫ凉")+title
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ凊"),menu_name+title,l1l111l_l1_,572)
	if len(menuItemsLIST)==0:
		title = re.findall(l1111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ凋"),html,re.DOTALL)
		if title: title = title[0].replace(l1111_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ凌"),l1111_l1_ (u"ࠫࠬ凍")).replace(l1111_l1_ (u"๋ࠬิศ้าอࠥ࠭凎"),l1111_l1_ (u"࠭ࠧ减"))
		else: title = l1111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ凐")
		l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ凑"),menu_name+title,url,572)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭凒"),url,l1111_l1_ (u"ࠪࠫ凓"),l1111_l1_ (u"ࠫࠬ凔"),l1111_l1_ (u"ࠬ࠭凕"),l1111_l1_ (u"࠭ࠧ凖"),l1111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ凗"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ凘"),html,re.DOTALL)
	if l1llll_l1_:
		l1llll_l1_ = [l1llll_l1_[0][0],l1llll_l1_[0][1]]
		if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ凙"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ凚"),block,re.DOTALL)
		for l1l111l_l1_,name in items:
			if l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ凛") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if name==l1111_l1_ (u"ู๊ࠬาใิࠤํ๐ࠠิ์่หࠬ凜"): name = l1111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭凝")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ凞")+name+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ凟")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ几"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ凡"),block,re.DOTALL)
		for l1l111l_l1_,l11l1111_l1_ in items:
			if l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ凢") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭凣"),l11l1111_l1_,re.DOTALL)
			if l11l1111_l1_: l11l1111_l1_ = l1111_l1_ (u"࠭࡟ࡠࡡࡢࠫ凤")+l11l1111_l1_[0]
			else: l11l1111_l1_ = l1111_l1_ (u"ࠧࠨ凥")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡹࡨࡧ࡮ࡳࡡࠨ処")+l1111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭凧")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ凨"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ凩"),url)
	return
def l1lll1_l1_(search,hostname=l1111_l1_ (u"ࠬ࠭凪")):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"࠭ࠧ凫"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠧࠨ凬"): return
	search = search.replace(l1111_l1_ (u"ࠨࠢࠪ凭"),l1111_l1_ (u"ࠩ࠮ࠫ凮"))
	l11lll1l_l1_ = [l1111_l1_ (u"ࠪ࠳ࠬ凯"),l1111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡷࡪࡸࡩࡦࡵࠪ凰"),l1111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡦࡴࡩ࡮ࡧࠪ凱"),l1111_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡺࡶࠨ凲"),l1111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭凳")]
	l1ll11l1l1l_l1_ = [l1111_l1_ (u"ࠨษ็วๆ๊วๆࠩ凴"),l1111_l1_ (u"ࠩสู่๊ไิๆสฮࠬ凵"),l1111_l1_ (u"ࠪห้อๆ๋็ํࠤํࠦวๅๅิฮํ์ࠧ凶"),l1111_l1_ (u"ࠫฬ๊ศาษ่ะࠥะไ๋ใี๎ํ์๊สࠩ凷"),l1111_l1_ (u"ࠬเ๊า่ࠢัิีࠧ凸")]
	if l1ll11_l1_:
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ凹"), l1ll11l1l1l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 4
	if not hostname:
		hostname = l1ll11l_l1_
		#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ出"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩ击"),l1111_l1_ (u"ࠩࠪ凼"),False,l1111_l1_ (u"ࠪࠫ函"),l1111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ凾"))
		#hostname = response.headers[l1111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ凿")]
		#hostname = response.url
		#hostname = hostname.strip(l1111_l1_ (u"࠭࠯ࠨ刀"))
	l1l1lll_l1_ = hostname+l1111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ刁")+search+l11lll1l_l1_[l1l_l1_]
	l1l11l1_l1_(l1l1lll_l1_)
	return
def l1llllll_l1_(l1l1l1llll11_l1_,filter):
	if l1111_l1_ (u"ࠨࡁࡂࠫ刂") in l1l1l1llll11_l1_: url = l1l1l1llll11_l1_.split(l1111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ刃"))[0]
	else: url = l1l1l1llll11_l1_
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ刄"):l1l1l1llll11_l1_,l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ刅"):l1111_l1_ (u"ࠬ࠭分")}
	filter = filter.replace(l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ切"),l1111_l1_ (u"ࠧࠨ刈"))
	type,filter = filter.split(l1111_l1_ (u"ࠨࡡࡢࡣࠬ刉"),1)
	if filter==l1111_l1_ (u"ࠩࠪ刊"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠪࠫ刋"),l1111_l1_ (u"ࠫࠬ刌")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ刍"))
	if type==l1111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ刎"):
		if l1l11l11l_l1_[0]+l1111_l1_ (u"ࠧ࠾࠿ࠪ刏") not in l1l11lll_l1_: category = l1l11l11l_l1_[0]
		for i in range(len(l1l11l11l_l1_[0:-1])):
			if l1l11l11l_l1_[i]+l1111_l1_ (u"ࠨ࠿ࡀࠫ刐") in l1l11lll_l1_: category = l1l11l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ刑")+category+l1111_l1_ (u"ࠪࡁࡂ࠶ࠧ划")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠫࠫࠬࠧ刓")+category+l1111_l1_ (u"ࠬࡃ࠽࠱ࠩ刔")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"࠭ࠦࠧࠩ刕"))+l1111_l1_ (u"ࠧࡠࡡࡢࠫ刖")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠨࠨࠩࠫ列"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ刘"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ则")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ刚"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ创"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"࠭ࠧ刜"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ初"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠨࠩ刞"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ刟")+l1l11ll1_l1_
		l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_,l1l1l1llll11_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ删"),menu_name+l1111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ刡"),l1llllll1_l1_,571,l1111_l1_ (u"ࠬ࠭刢"),l1111_l1_ (u"࠭ࠧ刣"),l1111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ判"))
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ別"),menu_name+l1111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ刦")+l11lll11_l1_+l1111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ刧"),l1llllll1_l1_,571,l1111_l1_ (u"ࠫࠬ刨"),l1111_l1_ (u"ࠬ࠭利"),l1111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ刪"))
		l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ别"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ刬"),l1111_l1_ (u"ࠩࠪ刭"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ刮"),url,l1111_l1_ (u"ࠫࠬ刯"),l1111_l1_ (u"ࠬ࠭到"),l1111_l1_ (u"࠭ࠧ刱"),l1111_l1_ (u"ࠧࠨ刲"),l1111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ刳"))
	html = response.content
	html = html.replace(l1111_l1_ (u"ࠩ࡟ࡠࠧ࠭刴"),l1111_l1_ (u"ࠪࠦࠬ刵")).replace(l1111_l1_ (u"ࠫࡡࡢ࠯ࠨ制"),l1111_l1_ (u"ࠬ࠵ࠧ刷"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࠼ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ券"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ刹"),block+l1111_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ刺"),re.DOTALL)
	dict = {}
	for l1lll1ll_l1_,name,block in l111111_l1_:
		name = escapeUNICODE(name)
		if l1111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ刻") in l1lll1ll_l1_: continue
		items = re.findall(l1111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ刼"),block,re.DOTALL)
		if l1111_l1_ (u"ࠫࡂࡃࠧ刽") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ刾"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<=1:
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]: l1l11l1_l1_(l1l1lll_l1_)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭刿")+l1l1l1ll_l1_)
				return
			else:
				l1llllll1_l1_ = l11lllll1_l1_(l1l1lll_l1_,l1l1l1llll11_l1_)
				if l1lll1ll_l1_==l1l11l11l_l1_[-1]:
					l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ剀"),menu_name+l1111_l1_ (u"ࠨษ็ะ๊๐ูࠨ剁"),l1llllll1_l1_,571,l1111_l1_ (u"ࠩࠪ剂"),l1111_l1_ (u"ࠪࠫ剃"),l1111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ剄"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ剅"),menu_name+l1111_l1_ (u"࠭วๅฮ่๎฾࠭剆"),l1l1lll_l1_,574,l1111_l1_ (u"ࠧࠨ則"),l1111_l1_ (u"ࠨࠩ剈"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ剉"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠪࠪࠫ࠭削")+l1lll1ll_l1_+l1111_l1_ (u"ࠫࡂࡃ࠰ࠨ剋")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠬࠬࠦࠨ剌")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠾࠲ࠪ前")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ剎")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ剏"),menu_name+name+l1111_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ剐"),l1l1lll_l1_,575,l1111_l1_ (u"ࠪࠫ剑"),l1111_l1_ (u"ࠫࠬ剒"),l1l1l1ll_l1_+l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ剓"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1111_l1_ (u"࠭ࡲࠨ剔") or value==l1111_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭剕"): continue
			if any(value in option.lower() for value in l11ll11_l1_): continue
			if l1111_l1_ (u"ࠨࡪࡷࡸࡵ࠭剖") in option: continue
			if l1111_l1_ (u"ࠩส่่๊ࠧ剗") in option: continue
			if l1111_l1_ (u"ࠪࡲ࠲ࡧࠧ剘") in value: continue
			#if value in [l1111_l1_ (u"ࠫࡷ࠭剙"),l1111_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ剚"),l1111_l1_ (u"࠭ࡴࡷ࠯ࡰࡥࠬ剛")]: continue
			#if l1lll1ll_l1_==l1111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭剜"): option = value
			if option==l1111_l1_ (u"ࠨࠩ剝"): option = value
			l11ll11ll_l1_ = option
			l1ll1111111_l1_ = re.findall(l1111_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ剞"),option,re.DOTALL)
			if l1ll1111111_l1_: l11ll11ll_l1_ = l1ll1111111_l1_[0]
			title2 = name+l1111_l1_ (u"ࠪ࠾ࠥ࠭剟")+l11ll11ll_l1_
			dict[l1lll1ll_l1_][value] = title2
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠫࠫࠬࠧ剠")+l1lll1ll_l1_+l1111_l1_ (u"ࠬࡃ࠽ࠨ剡")+l11ll11ll_l1_
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"࠭ࠦࠧࠩ剢")+l1lll1ll_l1_+l1111_l1_ (u"ࠧ࠾࠿ࠪ剣")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ剤")+l1ll11l1_l1_
			if type==l1111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ剥"):
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ剦"),menu_name+title2,url,575,l1111_l1_ (u"ࠫࠬ剧"),l1111_l1_ (u"ࠬ࠭剨"),l1lll1l1_l1_+l1111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ剩"))
			elif type==l1111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ剪") and l1l11l11l_l1_[-2]+l1111_l1_ (u"ࠨ࠿ࡀࠫ剫") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ剬"))
				#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ剭"),l1111_l1_ (u"ࠫࠬ剮"),l1l111l1_l1_,l1ll11l1_l1_)
				l11l11_l1_ = url+l1111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ副")+l1l111l1_l1_
				l1llllll1_l1_ = l11lllll1_l1_(l11l11_l1_,l1l1l1llll11_l1_)
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭剰"),menu_name+title2,l1llllll1_l1_,571,l1111_l1_ (u"ࠧࠨ剱"),l1111_l1_ (u"ࠨࠩ割"),l1111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ剳"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ剴"),menu_name+title2,url,574,l1111_l1_ (u"ࠫࠬ創"),l1111_l1_ (u"ࠬ࠭剶"),l1lll1l1_l1_)
	return
l1l11l11l_l1_ = [l1111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ剷"),l1111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭剸"),l1111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ剹")]
l1l111ll1_l1_ = [l1111_l1_ (u"ࠩࡰࡴࡦࡧࠧ剺"),l1111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ剻"),l1111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ剼"),l1111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ剽"),l1111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ剾"),l1111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ剿"),l1111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ劀"),l1111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ劁")]
def l11lllll1_l1_(l1l1lll_l1_,l11l11_l1_):
	if l1111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ劂") in l1l1lll_l1_: l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ劃"),l1111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭劄"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ劅"),l1111_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫ劆"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠨ࠿ࡀࠫ劇"),l1111_l1_ (u"ࠩ࠲ࠫ劈"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠪࠪࠫ࠭劉"),l1111_l1_ (u"ࠫ࠴࠭劊"))
	return l1l1lll_l1_
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭劋"),l1111_l1_ (u"࠭ࠧ劌"),filters,l1111_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧ劍")+mode)
	# mode==l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ劎")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ劏")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠪࡥࡱࡲࠧ劐")					all filters (l1l11111_l1_ l1l1llll_l1_ filter)
	filters = filters.strip(l1111_l1_ (u"ࠫࠫࠬࠧ劑"))
	l1l1l111_l1_,l1lll11l_l1_ = {},l1111_l1_ (u"ࠬ࠭劒")
	if l1111_l1_ (u"࠭࠽࠾ࠩ劓") in filters:
		items = filters.split(l1111_l1_ (u"ࠧࠧࠨࠪ劔"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠨ࠿ࡀࠫ劕"))
			l1l1l111_l1_[var] = value
	for key in l1l111ll1_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠩ࠳ࠫ劖")
		if l1111_l1_ (u"ࠪࠩࠬ劗") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭劘") and value!=l1111_l1_ (u"ࠬ࠶ࠧ劙"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠠࠬࠢࠪ劚")+value
		elif mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ力") and value!=l1111_l1_ (u"ࠨ࠲ࠪ劜"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠩࠩࠪࠬ劝")+key+l1111_l1_ (u"ࠪࡁࡂ࠭办")+value
		elif mode==l1111_l1_ (u"ࠫࡦࡲ࡬ࠨ功"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠬࠦࠨ加")+key+l1111_l1_ (u"࠭࠽࠾ࠩ务")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠡ࠭ࠣࠫ劢"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠨࠨࠩࠫ劣"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ劤"),l1111_l1_ (u"ࠪࠫ劥"),l1lll11l_l1_,l1111_l1_ (u"ࠫࡔ࡛ࡔࠨ劦"))
	return l1lll11l_l1_
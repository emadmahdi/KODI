# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ㐴")
l1ll11l_l1_ = l111lll_l1_[l1111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㐵")][0]
def l1111ll_l1_(mode,url):
	if   mode==100: l11l_l1_ = l11l111_l1_()
	elif mode==101: l11l_l1_ = l1ll1lll11_l1_(l1111_l1_ (u"ࠪ࠴ࠬ㐶"),True)
	elif mode==102: l11l_l1_ = l1ll1lll11_l1_(l1111_l1_ (u"ࠫ࠶࠭㐷"),True)
	elif mode==103: l11l_l1_ = l1ll1lll11_l1_(l1111_l1_ (u"ࠬ࠸ࠧ㐸"),True)
	elif mode==104: l11l_l1_ = l1ll1lll11_l1_(l1111_l1_ (u"࠭࠳ࠨ㐹"),True)
	elif mode==105: l11l_l1_ = l1lllll_l1_(url)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐺"),l1111_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧ㐻")+l1111_l1_ (u"ࠩ็ฺ่๊สาๅํ๊ࠥฮฮะ็ฬࠤࡎࡖࡔࡗࠩ㐼"),l1111_l1_ (u"ࠪࠫ㐽"),230)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㐾"),l1111_l1_ (u"ࠬࡥࡔࡗ࠲ࡢࠫ㐿")+l1111_l1_ (u"࠭โ็๊สฮ๋ࠥๆࠡ็๋ห็฿็ศࠢส่ศ฻ไ๋หࠪ㑀"),l1111_l1_ (u"ࠧࠨ㑁"),101)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㑂"),l1111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ㑃")+l1111_l1_ (u"ࠪๆ๋๎วหࠢ฼ีอ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㑄"),l1111_l1_ (u"ࠫࠬ㑅"),147)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㑆"),l1111_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ㑇")+l1111_l1_ (u"ࠧใ่๋หฯࠦรอ่ห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㑈"),l1111_l1_ (u"ࠨࠩ㑉"),148)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑊"),l1111_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ㑋")+l1111_l1_ (u"ࠫࠥࠦโ็ษฬࠤว๐ࠠโ์็้๋ࠥๆࠡ็๋ๆ฾ํๅࠡࠢࠪ㑌"),l1111_l1_ (u"ࠬ࠭㑍"),28)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㑎"),l1111_l1_ (u"ࠧࡠࡏࡕࡊࡤ࠭㑏")+l1111_l1_ (u"ࠨไ้หฮࠦวๅ็฼หึ็ࠠๆ่้ࠣํู่่็ࠪ㑐"),l1111_l1_ (u"ࠩࠪ㑑"),41)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㑒"),l1111_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ㑓")+l1111_l1_ (u"่ࠬๆศหࠣห้้่ฬำ้๋ࠣࠦๅ้ไ฼๋๊࠭㑔"),l1111_l1_ (u"࠭ࠧ㑕"),135)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㑖"),l1111_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ㑗")+l1111_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ㑘"),l1111_l1_ (u"ࠪࠫ㑙"),38)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㑚"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㑛"),l1111_l1_ (u"࠭ࠧ㑜"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㑝"),l1111_l1_ (u"ࠨࡡࡗ࡚࠶ࡥࠧ㑞")+l1111_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ฾อๅสࠩ㑟"),l1111_l1_ (u"ࠪࠫ㑠"),102)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑡"),l1111_l1_ (u"ࠬࡥࡔࡗ࠴ࡢࠫ㑢")+l1111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡะสูฮ࠭㑣"),l1111_l1_ (u"ࠧࠨ㑤"),103)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㑥"),l1111_l1_ (u"ࠩࡢࡘ࡛࠹࡟ࠨ㑦")+l1111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอ๊ࠥไโฯุࠫ㑧"),l1111_l1_ (u"ࠫࠬ㑨"),104)
	return
def l1ll1lll11_l1_(l1ll1llll1_l1_,show=True):
	menu_name=l1111_l1_ (u"ࠬࡥࡔࡗࠩ㑩")+l1ll1llll1_l1_+l1111_l1_ (u"࠭࡟ࠨ㑪")
	client = l11ll1lll11_l1_(32)
	payload = { l1111_l1_ (u"ࠧࡪࡦࠪ㑫") : l1111_l1_ (u"ࠨࠩ㑬") , l1111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㑭") : client , l1111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㑮") : l1111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㑯") , l1111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㑰") : l1ll1llll1_l1_ }
	#data = l1ll1l1l1_l1_(payload)
	#LOG_THIS(l1111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㑱"),str(payload))
	#LOG_THIS(l1111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㑲"),str(data))
	#response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㑳"), l1ll11l_l1_, payload, l1111_l1_ (u"ࠩࠪ㑴"), True,l1111_l1_ (u"ࠪࠫ㑵"),l1111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㑶"))
	#html = response.content
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㑷"),l1ll11l_l1_,payload,l1111_l1_ (u"࠭ࠧ㑸"),l1111_l1_ (u"ࠧࠨ㑹"),l1111_l1_ (u"ࠨࠩ㑺"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㑻"))
	html = response.content
	#html = html.replace(l1111_l1_ (u"ࠪࡠࡷ࠭㑼"),l1111_l1_ (u"ࠫࠬ㑽"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㑾"),l1111_l1_ (u"࠭ࠧ㑿"),html,html)
	#file = open(l1111_l1_ (u"ࠧࡴ࠼࠲ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭㒀"), l1111_l1_ (u"ࠨࡹࠪ㒁"))
	#file.write(html)
	#file.close()
	items = re.findall(l1111_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ㒂"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1111_l1_ (u"ࠪࡥࡱ࠭㒃"),l1111_l1_ (u"ࠫࡆࡲࠧ㒄"))
			start = start.replace(l1111_l1_ (u"ࠬࡋ࡬ࠨ㒅"),l1111_l1_ (u"࠭ࡁ࡭ࠩ㒆"))
			start = start.replace(l1111_l1_ (u"ࠧࡂࡎࠪ㒇"),l1111_l1_ (u"ࠨࡃ࡯ࠫ㒈"))
			start = start.replace(l1111_l1_ (u"ࠩࡈࡐࠬ㒉"),l1111_l1_ (u"ࠪࡅࡱ࠭㒊"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1111_l1_ (u"ࠫࡆࡲ࠭ࠨ㒋"),l1111_l1_ (u"ࠬࡇ࡬ࠨ㒌"))
			start = start.replace(l1111_l1_ (u"࠭ࡁ࡭ࠢࠪ㒍"),l1111_l1_ (u"ࠧࡂ࡮ࠪ㒎"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1llll11_l1_,name,img in items:
			if l1111_l1_ (u"ࠨࠥࠪ㒏") in source: continue
			#if source in [l1111_l1_ (u"ࠩࡑࡘࠬ㒐"),l1111_l1_ (u"ࠪ࡝࡚࠭㒑"),l1111_l1_ (u"ࠫ࡜࡙࠰ࠨ㒒"),l1111_l1_ (u"ࠬࡘࡌ࠲ࠩ㒓"),l1111_l1_ (u"࠭ࡒࡍ࠴ࠪ㒔")]: continue
			if source!=l1111_l1_ (u"ࠧࡖࡔࡏࠫ㒕"): name = name+l1111_l1_ (u"ࠨࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㒖")+source+l1111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㒗")
			url = source+l1111_l1_ (u"ࠪ࠿ࡀ࠭㒘")+server+l1111_l1_ (u"ࠫࡀࡁࠧ㒙")+l1l1llll11_l1_+l1111_l1_ (u"ࠬࡁ࠻ࠨ㒚")+l1ll1llll1_l1_
			l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㒛"),menu_name+l1111_l1_ (u"ࠧࠨ㒜")+name,url,105,img)
	else:
		if show: l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㒝"),menu_name+l1111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㒞"),l1111_l1_ (u"ࠪࠫ㒟"),9999)
		#if show: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㒠"),l1111_l1_ (u"ࠬ࠭㒡"),l1111_l1_ (u"࠭ࠧ㒢"),l1111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㒣"))
		#l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㒤"),menu_name+l1111_l1_ (u"ࠩ็่ศูแࠡๆสࠤฯ๎ฬะࠢๅ๊ํอสࠡฬ็ๅื๎ๆ๋ห่่ࠣ࠭㒥"),l1111_l1_ (u"ࠪࠫ㒦"),9999)
		#l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㒧"),menu_name+l1111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็ห็ืศศรࠣ์ฬ๊วึัๅหฦࠦแใูࠪ㒨"),l1111_l1_ (u"࠭ࠧ㒩"),9999)
		#l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㒪"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㒫"),l1111_l1_ (u"ࠩࠪ㒬"),9999)
		#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㒭"),menu_name+l1111_l1_ (u"࡚ࠫࡴࡦࡰࡴࡷࡹࡳࡧࡴࡦ࡮ࡼ࠰ࠥࡴ࡯ࠡࡖ࡙ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠦࡦࡰࡴࠣࡽࡴࡻࠧ㒮"),l1111_l1_ (u"ࠬ࠭㒯"),9999)
		#l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㒰"),menu_name+l1111_l1_ (u"ࠧࡊࡶࠣ࡭ࡸࠦࡦࡰࡴࠣࡶࡪࡲࡡࡵ࡫ࡹࡩࡸࠦࠦࠡࡨࡵ࡭ࡪࡴࡤࡴࠢࡲࡲࡱࡿࠧ㒱"),l1111_l1_ (u"ࠨࠩ㒲"),9999)
	return
def l1lllll_l1_(id):
	source,server,l1l1llll11_l1_,l1ll1llll1_l1_ = id.split(l1111_l1_ (u"ࠩ࠾࠿ࠬ㒳"))
	url = l1111_l1_ (u"ࠪࠫ㒴")
	if source==l1111_l1_ (u"࡚ࠫࡘࡌࠨ㒵"): url = l1l1llll11_l1_
	elif source==l1111_l1_ (u"ࠬࡍࡁࠨ㒶"):
		payload = { l1111_l1_ (u"࠭ࡩࡥࠩ㒷") : l1111_l1_ (u"ࠧࠨ㒸"), l1111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㒹") : l11ll1lll11_l1_(32) , l1111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㒺") : l1111_l1_ (u"ࠪࡴࡱࡧࡹࡈࡃ࠴ࠫ㒻") , l1111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㒼") : l1111_l1_ (u"ࠬ࠭㒽") }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ㒾"),l1ll11l_l1_,payload,l1111_l1_ (u"ࠧࠨ㒿"),False,l1111_l1_ (u"ࠨࠩ㓀"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㓁"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㓂"),l1111_l1_ (u"ࠫࠬ㓃"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㓄"),l1111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㓅"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l1lll111l1_l1_ = cookies[l1111_l1_ (u"ࠧࡂࡕࡓ࠲ࡓࡋࡔࡠࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࠫ㓆")]
		url = response.headers[l1111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㓇")]
		payload = { l1111_l1_ (u"ࠩ࡬ࡨࠬ㓈") : l1l1llll11_l1_ , l1111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㓉") : l11ll1lll11_l1_(32) , l1111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㓊") : l1111_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠷࠭㓋") , l1111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㓌") : l1111_l1_ (u"ࠧࠨ㓍") }
		headers = { l1111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ㓎") : l1111_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠧ㓏")+l1l1lll111l1_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ㓐"),l1ll11l_l1_,payload,headers,l1111_l1_ (u"ࠫࠬ㓑"),l1111_l1_ (u"ࠬ࠭㓒"),l1111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ㓓"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㓔"),l1111_l1_ (u"ࠨࠩ㓕"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㓖"),l1111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㓗"))
			return
		html = response.content
		url = re.findall(l1111_l1_ (u"ࠫࡷ࡫ࡳࡱࠤ࠽ࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄࡳ࠳ࡶ࠺ࠬࠬ࠳࠰࠿ࠪࠤࠪ㓘"),html,re.DOTALL)
		l1l111l_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l1111_l1_ (u"ࠬ࠭㓙"),l1111_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰ࠦࠧ㓚")+l1l111l_l1_)
		#LOG_THIS(l1111_l1_ (u"ࠧࠨ㓛"),l1111_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠡࠩ㓜")+params)
		l1l1lll1111l_l1_ = l1111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠼࠳࠭㓝")+server+l1111_l1_ (u"ࠪ࠻࠼࠽࠯ࠨ㓞")+l1l1llll11_l1_+l1111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㓟")+params
		l1l1lll11111_l1_ = l1l1lll1111l_l1_.replace(l1111_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㓠"),l1111_l1_ (u"࠭࠴࠱࠼࠺ࠫ㓡")).replace(l1111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㓢"),l1111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㓣"))
		l1l1lll111ll_l1_ = l1l1lll1111l_l1_.replace(l1111_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㓤"),l1111_l1_ (u"ࠪ࠸࠷ࡀ࠷ࠨ㓥")).replace(l1111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㓦"),l1111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㓧"))
		l11111l_l1_ = [l1111_l1_ (u"࠭ࡈࡅࠩ㓨"),l1111_l1_ (u"ࠧࡔࡆ࠴ࠫ㓩"),l1111_l1_ (u"ࠨࡕࡇ࠶ࠬ㓪")]
		l11lll1l_l1_ = [l1l1lll1111l_l1_,l1l1lll11111_l1_,l1l1lll111ll_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ㓫"), l11111l_l1_)
		if l1l_l1_ == -1: return
		else: url = l11lll1l_l1_[l1l_l1_]
	elif source==l1111_l1_ (u"ࠪࡒ࡙࠭㓬"):
		headers = { l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㓭") : l1111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㓮") }
		payload = { l1111_l1_ (u"࠭ࡩࡥࠩ㓯") : l1l1llll11_l1_ , l1111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㓰") : l11ll1lll11_l1_(32) , l1111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㓱") : l1111_l1_ (u"ࠩࡳࡰࡦࡿࡎࡕࠩ㓲") , l1111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㓳") : l1ll1llll1_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㓴"), l1ll11l_l1_, payload, headers, False,l1111_l1_ (u"ࠬ࠭㓵"),l1111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ㓶"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ㓷"),l1111_l1_ (u"ࠨࠩ㓸"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㓹"),l1111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㓺"))
			return
		html = response.content
		url = response.headers[l1111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㓻")]
		url = url.replace(l1111_l1_ (u"ࠬࠫ࠲࠱ࠩ㓼"),l1111_l1_ (u"࠭ࠠࠨ㓽"))
		url = url.replace(l1111_l1_ (u"ࠧࠦ࠵ࡇࠫ㓾"),l1111_l1_ (u"ࠨ࠿ࠪ㓿"))
		if l1111_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࠨ㔀") in l1l1llll11_l1_:
			url = url.replace(l1111_l1_ (u"ࠪࡒ࡙ࡔࡎࡪ࡮ࡨࠫ㔁"),l1111_l1_ (u"ࠫࠬ㔂"))
			url = url.replace(l1111_l1_ (u"ࠬࡲࡥࡢࡴࡱ࡭ࡳ࡭࠱ࠨ㔃"),l1111_l1_ (u"࠭ࡌࡦࡣࡵࡲ࡮ࡴࡧࠨ㔄"))
	elif source==l1111_l1_ (u"ࠧࡑࡎࠪ㔅"):
		#headers = { l1111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㔆") : l1111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㔇") }
		payload = { l1111_l1_ (u"ࠪ࡭ࡩ࠭㔈") : l1l1llll11_l1_ , l1111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㔉") : l11ll1lll11_l1_(32) , l1111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㔊") : l1111_l1_ (u"࠭ࡰ࡭ࡣࡼࡔࡑ࠭㔋") , l1111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㔌") : l1ll1llll1_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㔍"), l1ll11l_l1_, payload, l1111_l1_ (u"ࠩࠪ㔎"),False,l1111_l1_ (u"ࠪࠫ㔏"),l1111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭㔐"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭㔑"),l1111_l1_ (u"࠭ࠧ㔒"),l1111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㔓"),l1111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㔔"))
			return
		html = response.content
		url = response.headers[l1111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㔕")]
		headers = {l1111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㔖"):response.headers[l1111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㔗")]}
		response = l1l11l_l1_(l1l111ll_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㔘"),url, l1111_l1_ (u"࠭ࠧ㔙"),headers , l1111_l1_ (u"ࠧࠨ㔚"),l1111_l1_ (u"ࠨࠩ㔛"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ㔜"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㔝"),l1111_l1_ (u"ࠫࠬ㔞"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㔟"),l1111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㔠"))
			return
		html = response.content
		items = re.findall(l1111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㔡"),html,re.DOTALL)
		url = items[0]
	elif source in [l1111_l1_ (u"ࠨࡖࡄࠫ㔢"),l1111_l1_ (u"ࠩࡉࡑࠬ㔣"),l1111_l1_ (u"ࠪ࡝࡚࠭㔤"),l1111_l1_ (u"ࠫ࡜࡙࠱ࠨ㔥"),l1111_l1_ (u"ࠬ࡝ࡓ࠳ࠩ㔦"),l1111_l1_ (u"࠭ࡒࡍ࠳ࠪ㔧"),l1111_l1_ (u"ࠧࡓࡎ࠵ࠫ㔨")]:
		if source==l1111_l1_ (u"ࠨࡖࡄࠫ㔩"): l1l1llll11_l1_ = id
		headers = { l1111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㔪") : l1111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㔫") }
		payload = { l1111_l1_ (u"ࠫ࡮ࡪࠧ㔬") : l1l1llll11_l1_ , l1111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㔭") : l11ll1lll11_l1_(32) , l1111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㔮") : l1111_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ㔯")+source , l1111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㔰") : l1ll1llll1_l1_ }
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㔱"),l1ll11l_l1_,payload,headers,l1111_l1_ (u"ࠪࠫ㔲"),l1111_l1_ (u"ࠫࠬ㔳"),l1111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ㔴"))
		if not response.succeeded:
			l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㔵"),l1111_l1_ (u"ࠧࠨ㔶"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㔷"),l1111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㔸"))
			return
		html = response.content
		url = response.headers[l1111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㔹")]
		if source==l1111_l1_ (u"ࠫࡋࡓࠧ㔺"):
			response = l1l11l_l1_(l1l111ll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ㔻"), url, l1111_l1_ (u"࠭ࠧ㔼"), l1111_l1_ (u"ࠧࠨ㔽"), False,l1111_l1_ (u"ࠨࠩ㔾"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠸ࡶ࡫ࠫ㔿"))
			url = response.headers[l1111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㕀")]
			url = url.replace(l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㕁"),l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㕂"))
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㕃"))
	return
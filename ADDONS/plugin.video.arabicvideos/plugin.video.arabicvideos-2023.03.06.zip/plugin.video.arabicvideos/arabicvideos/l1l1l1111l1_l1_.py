# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡎࡖࡔࡗࠩ⚒")
menu_name=l1111_l1_ (u"ࠬࡥࡉࡑࡖࡢࠫ⚓")
ALL_TYPES = [
		 l1111_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭⚔"),l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ⚕")
		,l1111_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ⚖"),l1111_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ⚗")
		,l1111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ⚘"),l1111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ⚙"),l1111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ⚚")
		,l1111_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ⚛"),l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭⚜")
		,l1111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⚝"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ⚞"),l1111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ⚟")
		,l1111_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⚠"),l1111_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ⚡")
		,l1111_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ⚢"),l1111_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ⚣")
		,l1111_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ⚤"),l1111_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ⚥"),l1111_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ⚦")
		]
def l1111ll_l1_(mode,url,text,type,page):
	if   mode==230: l11l_l1_ = l11l111_l1_()
	elif mode==231: l11l_l1_ = l11lllll11l_l1_()
	elif mode==232: l11l_l1_ = l1l111llll1_l1_()
	elif mode==233: l11l_l1_ = l1l111l11ll_l1_(url,text,page)
	elif mode==234: l11l_l1_ = l1ll1lll11_l1_(url,text,page)
	elif mode==235: l11l_l1_ = l1lllll_l1_(url,type)
	elif mode==236: l11l_l1_ = l1l11111ll1_l1_(True)
	elif mode==237: l11l_l1_ = l1l11l1l111_l1_(True)
	elif mode==238: l11l_l1_ = l1l11lll1l1_l1_(url,text)
	elif mode==239: l11l_l1_ = l1lll1_l1_(text,url,page)
	elif mode==280: l11l_l1_ = l1l111l1lll_l1_()
	elif mode==281: l11l_l1_ = l11lllll1l1_l1_()
	elif mode==282: l11l_l1_ = l1l1111l1ll_l1_()
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚧"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎๋ࠥไโษอࠤࡎࡖࡔࡗࠩ⚨"),l1111_l1_ (u"࠭ࠧ⚩"),239,l1111_l1_ (u"ࠧࠨ⚪"),l1111_l1_ (u"ࠨࠩ⚫"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⚬"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚭"),menu_name+l1111_l1_ (u"ࠫ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧ⚮"),l1111_l1_ (u"ࠬ࠭⚯"),165,l1111_l1_ (u"࠭ࠧ⚰"),l1111_l1_ (u"ࠧࠨ⚱"),l1111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ⚲"))
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⚳"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⚴"),l1111_l1_ (u"ࠫࠬ⚵"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚶"),menu_name+l1111_l1_ (u"࠭โ็๊สฮ๋ࠥี็ใฬࠫ⚷"),l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭⚸"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚹"),menu_name+l1111_l1_ (u"ࠩฦๅ้อๅࠡ็ุ๊ๆฯࠧ⚺"),l1111_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ⚻"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚼"),menu_name+l1111_l1_ (u"๋ࠬำๅี็หฯࠦๅึ่ไอࠬ⚽"),l1111_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ⚾"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚿"),menu_name+l1111_l1_ (u"ࠨใํำ๏๎็ศฬ้ࠣัํ่ๅหࠪ⛀"),l1111_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ⛁"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛂"),menu_name+l1111_l1_ (u"ࠫ็์่ศฬ้ࠣัํ่ๅหࠪ⛃"),l1111_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ⛄"),233)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⛅"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⛆"),l1111_l1_ (u"ࠨࠩ⛇"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛈"),menu_name+l1111_l1_ (u"ࠪๆ๋๎วหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ⛉"),l1111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ⛊"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛋"),menu_name+l1111_l1_ (u"࠭รโๆส้๋ࠥี็ใฬࠤํ๋ัหสฬࠫ⛌"),l1111_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ⛍"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛎"),menu_name+l1111_l1_ (u"่ࠩืู้ไศฬฺ้ࠣ์แส๋้ࠢึะศสࠩ⛏"),l1111_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ⛐"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛑"),menu_name+l1111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯ้ࠠ็ิฮอฯࠧ⛒"),l1111_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ⛓"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⛔"),menu_name+l1111_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯ้ࠠ็ิฮอฯࠧ⛕"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ⛖"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⛗"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⛘"),l1111_l1_ (u"ࠬ࠭⛙"),9999)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛚"),menu_name+l1111_l1_ (u"ࠧศๆๅ๊ํอสࠡษ็วฺ๊๊สࠢหำํ์ࠠห฼ํ๎ึ࠭⛛"),l1111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⛜"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛝"),menu_name+l1111_l1_ (u"ࠪห้็๊ะ์๋๋ฬะࠠศๆฦู้๐ษࠡสา์๋ࠦส฻์ํีࠬ⛞"),l1111_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ⛟"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⛠"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⛡"),l1111_l1_ (u"ࠧࠨ⛢"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛣"),menu_name+l1111_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠠๆ่ࠣวุ๋วว้สࠤํ๋ัหสฬࠫ⛤"),l1111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ⛥"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛦"),menu_name+l1111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢฦื๊อฦ่ษࠣ์๊ืสษหࠪ⛧"),l1111_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭⛨"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⛩"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⛪"),l1111_l1_ (u"ࠩࠪ⛫"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛬"),menu_name+l1111_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แส่๊ࠢࠥษโิษ่๋ฬ่ࠦๆำอฬฮ࠭⛭"),l1111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ⛮"),233)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛯"),menu_name+l1111_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠡ็้ࠤศ่ำศ็๊หࠥ๎ๅาฬหอࠬ⛰"),l1111_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࠩ⛱"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⛲"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⛳"),l1111_l1_ (u"ࠫࠬ⛴"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛵"),menu_name+l1111_l1_ (u"࠭ศาษ่ะࠥอไใ่๋หฯࠦࠨอั๋่ࠥ็โุࠫࠪ⛶"),l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ⛷"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛸"),menu_name+l1111_l1_ (u"ࠩฦีู๐แࠡษ็ๆ๋๎วหࠢ็่ศ๐วๆࠢส่๊อึ๋หࠪ⛹"),l1111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ⛺"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛻"),menu_name+l1111_l1_ (u"ࠬษัี์ไࠤอืวๆฮࠣห้่ๆ้ษอࠤ้๊ร๋ษ่ࠤฬ๊ๅศุํอࠬ⛼"),l1111_l1_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ⛽"),233)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⛾"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⛿"),l1111_l1_ (u"ࠩࠪ✀"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ✁"),menu_name+l1111_l1_ (u"ࠫส฼วโหࠣวํࠦส฻์ํีࠥอิหำส็ࠥࡏࡐࡕࡘࠪ✂"),l1111_l1_ (u"ࠬ࠭✃"),231)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ✄"),menu_name+l1111_l1_ (u"ฺࠧัาࠤๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠫ✅"),l1111_l1_ (u"ࠨࠩ✆"),281)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ✇"),menu_name+l1111_l1_ (u"ࠪๅา฻ࠠศึอีฬ้ࠠࡊࡒࡗ࡚ࠬ✈"),l1111_l1_ (u"ࠫࠬ✉"),236)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ✊"),menu_name+l1111_l1_ (u"࠭ฬๅส้้ࠣ็วหࠢࡌࡔ࡙࡜ࠧ✋"),l1111_l1_ (u"ࠧࠨ✌"),232)
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭✍"),menu_name+l1111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡏࡐࡕࡘࠪ✎"),l1111_l1_ (u"ࠪࠫ✏"),237)
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ✐"),menu_name+l1111_l1_ (u"ࠬอำหะาห๊ࠦวๅีํีๆืࠠศๆฦืึ฿ࠧ✑"),l1111_l1_ (u"࠭ࠧ✒"),282)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ✓"),menu_name+l1111_l1_ (u"ࠨฬ฽๎๏ืࠠࡊࡒࡗ࡚࡛ࠥࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ✔"),l1111_l1_ (u"ࠩࠪ✕"),280)
	return
def l1l11111ll1_l1_(l1l11l1l1ll_l1_=True):
	#if not isIPTVFiles(True): return
	ok,status = False,l1111_l1_ (u"ࠪࠫ✖")
	l1l111ll111_l1_,l1l1ll111ll_l1_ = l1111_l1_ (u"ࠫࠬ✗"),l1111_l1_ (u"ࠬ࠭✘")
	l1l11l1ll1l_l1_,l1l1lll11ll_l1_,server,username,password = l1l11ll11ll_l1_()
	if username==l1111_l1_ (u"࠭ࠧ✙"): return
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࠫ✚"))
	headers = {l1111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ✛"):l1l1111ll1_l1_}
	if l1l11l1ll1l_l1_:
		response = l1l11l_l1_(l1l111ll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭✜"),l1l11l1ll1l_l1_,l1111_l1_ (u"ࠪࠫ✝"),headers,False,False,l1111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭✞"))
		html = response.content
		if response.succeeded:
			timestamp,l1l111l11l1_l1_,l1l1111l1l1_l1_,l11llll1l1l_l1_,l1l11ll1ll1_l1_ = 0,0,l1111_l1_ (u"ࠬ࠭✟"),l1111_l1_ (u"࠭ࠧ✠"),l1111_l1_ (u"ࠧࠨ✡")
			try:
				dict = l1lll11ll11_l1_(l1111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭✢"),html)
				status = dict[l1111_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ✣")][l1111_l1_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ✤")]
				ok = True
				l1l1111l1l1_l1_ = dict[l1111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡴࡦࡰࠩ✥")][l1111_l1_ (u"ࠬࡺࡩ࡮ࡧࡢࡲࡴࡽࠧ✦")]
			except: pass
			if l1l1111l1l1_l1_:
				try:
					struct = time.strptime(l1l1111l1l1_l1_,l1111_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ✧"))
					timestamp = int(time.mktime(struct))
					l1l111l11l1_l1_ = int(now-timestamp)
					# l1l1l1l1111_l1_ to the l1l111111l1_l1_ l1l1ll11l1l_l1_ hour with 15 minutes error range
					l1l111l11l1_l1_ = int((l1l111l11l1_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l1111_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ✨")][l1111_l1_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬ✩")]))
					l11llll1l1l_l1_ = time.strftime(l1111_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭✪"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l1111_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭✫")][l1111_l1_ (u"ࠫࡪࡾࡰࡠࡦࡤࡸࡪ࠭✬")]))
					l1l11ll1ll1_l1_ = time.strftime(l1111_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ✭"),struct)
				except: pass
			settings.setSetting(l1111_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ✮"),str(now))
			settings.setSetting(l1111_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࠪ✯"),str(l1l111l11l1_l1_))
			l1l11llll1l_l1_ = l1111_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡡ࡬ࡲ࡫ࡵࠢ࠻ࠩ✰")+html.split(l1111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡢ࡭ࡳ࡬࡯ࠣ࠼ࠪ✱"))[1]
			l1l11llll1l_l1_ = l1l11llll1l_l1_.replace(l1111_l1_ (u"ࠪ࠾ࠬ✲"),l1111_l1_ (u"ࠫ࠿ࠦࠧ✳")).replace(l1111_l1_ (u"ࠬ࠲ࠧ✴"),l1111_l1_ (u"࠭ࠬࠡࠩ✵")).replace(l1111_l1_ (u"ࠧࡾࡿࠪ✶"),l1111_l1_ (u"ࠨࡿࠪ✷"))
			new = re.findall(l1111_l1_ (u"ࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࠧࡶ࡯ࡳࡶࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭✸"),l1l11llll1l_l1_,re.DOTALL)
			l1l111ll111_l1_,l1l1ll111ll_l1_ = new[0]
			if ok and l1l11l1l1ll_l1_:
				max = dict[l1111_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭✹")][l1111_l1_ (u"ࠫࡲࡧࡸࡠࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࡸ࠭✺")]
				l1l1l111111_l1_ = dict[l1111_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ✻")][l1111_l1_ (u"࠭ࡡࡤࡶ࡬ࡺࡪࡥࡣࡰࡰࡶࠫ✼")]
				l1l1l11l1ll_l1_ = dict[l1111_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ✽")][l1111_l1_ (u"ࠨ࡫ࡶࡣࡹࡸࡩࡢ࡮ࠪ✾")]
				parts = l1l11l1ll1l_l1_.split(l1111_l1_ (u"ࠩࡂࠫ✿"),1)
				message = l1111_l1_ (u"࡙ࠪࡗࡒ࠺ࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ❀")+l1l11l1ll1l_l1_+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭❁")
				message += l1111_l1_ (u"ࠬࡢ࡮࡝ࡰࡖࡸࡦࡺࡵࡴ࠼ࠣࠤࠬ❂")+l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ❃")+status+l1111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ❄")
				message += l1111_l1_ (u"ࠨ࡞ࡱࡘࡷ࡯ࡡ࡭࠼ࠣࠤࠥࠦࠧ❅")+l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ❆")+str(l1l1l11l1ll_l1_==l1111_l1_ (u"ࠪ࠵ࠬ❇"))+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭❈")
				message += l1111_l1_ (u"ࠬࡢ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠡࠢࡄࡸ࠿ࠦࠠࠨ❉")+l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ❊")+l11llll1l1l_l1_+l1111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ❋")
				message += l1111_l1_ (u"ࠨ࡞ࡱࡉࡽࡶࡩࡳࡻࠣࡈࡦࡺࡥ࠻ࠢࠣࠫ❌")+l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ❍")+l1l11ll1ll1_l1_+l1111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ❎")
				message += l1111_l1_ (u"ࠫࡡࡴࡃࡰࡰࡱࡩࡨࡺࡩࡰࡰࡶࠤࠥࠦࠨࠡࡃࡦࡸ࡮ࡼࡥࠡ࠱ࠣࡑࡦࡾࡩ࡮ࡷࡰࠤ࠮ࠦ࠺ࠡࠢࠪ❏")+l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ❐")+l1l1l111111_l1_+l1111_l1_ (u"࠭ࠠ࠰ࠢࠪ❑")+max+l1111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ❒")
				message += l1111_l1_ (u"ࠨ࡞ࡱࡅࡱࡲ࡯ࡸࡧࡧࠤࡔࡻࡴࡱࡷࡷࡷ࠿ࠦࠠࠡࠩ❓")+l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ❔")+l1111_l1_ (u"ࠥࠤ࠱ࠦࠢ❕").join(dict[l1111_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ❖")][l1111_l1_ (u"ࠬࡧ࡬࡭ࡱࡺࡩࡩࡥ࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡹࠧ❗")])+l1111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ❘")
				message += l1111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ❙")+l1l11llll1l_l1_
				if status==l1111_l1_ (u"ࠨࡃࡦࡸ࡮ࡼࡥࠨ❚"): l1l111ll1l1_l1_(l1111_l1_ (u"ࠩส่ฬฺสาษๆࠤ๏฿ๅๅࠢหำํ์ࠠๆึส็้࠭❛"),message)
				else: l1l111ll1l1_l1_(l1111_l1_ (u"ࠪ๎อี่ࠡล้ࠤ์์วไุ่่๊ࠢษࠡใํࠤฬ๊วีฬิห่࠭❜"),message)
	if l1l11l1ll1l_l1_ and ok and status==l1111_l1_ (u"ࠫࡆࡩࡴࡪࡸࡨࠫ❝"):
		LOG_THIS(l1111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ❞"),l1111_l1_ (u"࠭࠮ࠡࠢࠣࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥࡏࡐࡕࡘ࡙ࠣࡗࡒࠠࠡࠢ࡞ࠤࡎࡖࡔࡗࠢࡤࡧࡨࡵࡵ࡯ࡶࠣ࡭ࡸࠦࡏࡌࠢࡠࠤ࡛ࠥࠦࠡࠩ❟")+l1l11l1ll1l_l1_+l1111_l1_ (u"ࠧࠡ࡟ࠪ❠"))
		succeeded = True
	else:
		LOG_THIS(l1111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭❡"),l1111_l1_ (u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤࡎࡖࡔࡗࠢࡘࡖࡑࠦࠠࠡ࡝ࠣࡈࡴ࡫ࡳࠡࡰࡲࡸࠥࡽ࡯ࡳ࡭ࠣࡡࠥࠦࠠ࡜ࠢࠪ❢")+l1l11l1ll1l_l1_+l1111_l1_ (u"ࠪࠤࡢ࠭❣"))
		if l1l11l1l1ll_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ❤"),l1111_l1_ (u"ࠬ࠭❥"),l1111_l1_ (u"࠭แฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠩ❦"),l1111_l1_ (u"ࠧาษห฻ࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤฬ๊ะ๋ࠢๅ้ฯࠦว็ฬࠣฬส฼วโฬ๊ࠤส๊้ࠡษ็ฬึ์วๆฮ่ࠣฬฺ๊ࠦ็็ࠤศ๎ࠠศๆิหอ฽ࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣวีํศࠡว็ํ่ࠥวว็ฬࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠣ์็๋ࠠษวูหๆฯࠠาษห฻ࠥๆࡉࡑࡖ࡙ࠤัี๊ะࠢฦ์่ࠥๅࠡสศู้ออࠡษ็ีฬฮืࠡษ็ๆิ๐ๅࠨ❧"))
		succeeded = False
	return succeeded,l1l111ll111_l1_,l1l1ll111ll_l1_
def l1ll1lll11_l1_(TYPE,GROUP,PAGE):
	if PAGE==l1111_l1_ (u"ࠨࠩ❨"): PAGE = l1111_l1_ (u"ࠩ࠴ࠫ❩")
	import EXCLUDES
	total = EXCLUDES.IPTV_ITEMS(TYPE,GROUP,PAGE,READ_FROM_SQL3,isIPTVFiles,menuItemsLIST,GET_DBFILE_NAME)
	l1l1ll11l11_l1_(PAGE,TYPE,234,total,GROUP)
	return
def l1l1l11l11l_l1_(l11llll1111_l1_):
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ❪"),l11llll1111_l1_+l1111_l1_ (u"ࠫ์ึ็ࠡษ็ๆฬฬๅสࠢศ้ฬࠦแศำ฽อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠬ❫"),l1111_l1_ (u"ࠬ࠭❬"),9999)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ❭"),l11llll1111_l1_+l1111_l1_ (u"ࠧฤ๊ࠣห้ิฯๆหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣหูะัศๅๆࠫ❮"),l1111_l1_ (u"ࠨࠩ❯"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ❰"),l11llll1111_l1_+l1111_l1_ (u"ࠪวํࠦัศสฺࠤࡎࡖࡔࡗโࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ฿๐ัࠡืะ๎า࠭❱"),l1111_l1_ (u"ࠫࠬ❲"),9999)
	return
def l1l111l11ll_l1_(TYPE,GROUP,PAGE,l1l1lll1_l1_=l1111_l1_ (u"ࠬ࠭❳")):
	if PAGE==l1111_l1_ (u"࠭ࠧ❴"): PAGE = l1111_l1_ (u"ࠧ࠲ࠩ❵")
	#import EXCLUDES
	#EXCLUDES.l1l1l1lll1l_l1_(TYPE,GROUP,l1l1lll1_l1_)
	l11llll1111_l1_ = menu_name
	if l1l1lll1_l1_==l1111_l1_ (u"ࠨࠩ❶"): l1l11lll111_l1_ = True
	else: l1l11lll111_l1_ = False
	if not isIPTVFiles(l1l11lll111_l1_):
		l1l1l11l11l_l1_(l11llll1111_l1_)
		return
	#l1l11l11l1l_l1_ = menuItemsLIST[:] ; menuItemsLIST[:] = []
	#l11l_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ❷"),l1111_l1_ (u"ࠪࡍࡕ࡚ࡖࡠࡉࡕࡓ࡚ࡖࡓࠨ❸"),[TYPE,GROUP,l1l1lll1_l1_])
	#if l11l_l1_: menuItemsLIST[:] = menuItemsLIST+l11l_l1_ ; return
	if l1111_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ❹") in GROUP: l1l1l111l1l_l1_,l1l111111ll_l1_ = GROUP.split(l1111_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ❺"))
	else: l1l1l111l1l_l1_,l1l111111ll_l1_ = GROUP,l1111_l1_ (u"࠭ࠧ❻")
	iptv_dbfile = GET_DBFILE_NAME(TYPE)
	l1l1l11111l_l1_ = READ_FROM_SQL3(iptv_dbfile,l1111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ❼"),l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࠧ❽")+TYPE,l1111_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭❾"))
	if l1l1l11111l_l1_:
		l1l1lll11l1_l1_ = []
		for group,img in l1l1l11111l_l1_:
			if l1l1lll1_l1_:
				if l1111_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ❿") in group: l11llll1111_l1_ = l1111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ➀")
				elif l1111_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ➁") in group: l11llll1111_l1_ = l1111_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧ➂")
				elif l1111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ➃") in TYPE: l11llll1111_l1_ = l1111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭➄")
				else: l11llll1111_l1_ = l1111_l1_ (u"࡙ࠩࡍࡉࡋࡏࡔࠩ➅")
				l11llll1111_l1_ = l1111_l1_ (u"ࠪ࠰ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ➆")+l11llll1111_l1_+l1111_l1_ (u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➇")
			if l1111_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ➈") in group: l1l1l1l11l1_l1_,l11lll1ll11_l1_ = group.split(l1111_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ➉"))
			else: l1l1l1l11l1_l1_,l11lll1ll11_l1_ = group,l1111_l1_ (u"ࠧࠨ➊")
			if not GROUP:
				if l1l1l1l11l1_l1_ in l1l1lll11l1_l1_: continue
				l1l1lll11l1_l1_.append(l1l1l1l11l1_l1_)
				if l1111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࠨ➋") in l1l1lll1_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➌"),l11llll1111_l1_+l1l1l1l11l1_l1_,TYPE,167,l1111_l1_ (u"ࠪࠫ➍"),l1111_l1_ (u"ࠫ࠶࠭➎"),group)
				# l111l1l1_l1_ groups
				elif l1111_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ➏") in group: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➐"),l11llll1111_l1_+l1l1l1l11l1_l1_,TYPE,233,l1111_l1_ (u"ࠧࠨ➑"),l1111_l1_ (u"ࠨ࠳ࠪ➒"),group)
				else: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➓"),l11llll1111_l1_+l1l1l1l11l1_l1_,TYPE,234,l1111_l1_ (u"ࠪࠫ➔"),l1111_l1_ (u"ࠫ࠶࠭➕"),group)
			elif l1111_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ➖") in group and l1l1l1l11l1_l1_==l1l1l111l1l_l1_:
				if l11lll1ll11_l1_ in l1l1lll11l1_l1_: continue
				l1l1lll11l1_l1_.append(l11lll1ll11_l1_)
				if l1111_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࠭➗") in l1l1lll1_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➘"),l11llll1111_l1_+l11lll1ll11_l1_,TYPE,167,l1111_l1_ (u"ࠨࠩ➙"),l1111_l1_ (u"ࠩ࠴ࠫ➚"),group)
				# l111l1l1_l1_ names
				else: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➛"),l11llll1111_l1_+l11lll1ll11_l1_,TYPE,234,img,l1111_l1_ (u"ࠫ࠶࠭➜"),group)
		if not l1l1lll1_l1_:
			end = int(PAGE)*100
			start = end-100
			total = len(menuItemsLIST)
			menuItemsLIST[:] = menuItemsLIST[start:end]
			l1l1ll11l11_l1_(PAGE,TYPE,233,total,GROUP)
	else: l1l1l11l11l_l1_(l11llll1111_l1_)
	#l1ll11lllll_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢࡋࡗࡕࡕࡑࡕࠪ➝"),[TYPE,GROUP,l1l1lll1_l1_],menuItemsLIST,l1l1llll11l_l1_)
	#menuItemsLIST[:] = l1l11l11l1l_l1_+menuItemsLIST
	return
def l1l11lll1l1_l1_(url,function):
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࠪ➞"))
	headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ➟"):l1l1111ll1_l1_}
	if not isIPTVFiles(True): return
	timestamp = settings.getSetting(l1111_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ➠"))
	if timestamp==l1111_l1_ (u"ࠩࠪ➡") or now-int(timestamp)>24*HOUR:
		ok,l1l111ll111_l1_,l1l1ll111ll_l1_ = l1l11111ll1_l1_(False)
		if not ok: return
	l1l111l11l1_l1_ = int(settings.getSetting(l1111_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫࠭➢")))
	server = settings.getSetting(l1111_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡹࡥࡳࡸࡨࡶࠬ➣"))
	username = settings.getSetting(l1111_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡲࡦࡳࡥࠨ➤"))
	password = settings.getSetting(l1111_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡱࡣࡶࡷࡼࡵࡲࡥࠩ➥"))
	l1l111l1l1l_l1_ = url.split(l1111_l1_ (u"ࠧ࠰ࠩ➦"))
	l11llll11l1_l1_ = l1l111l1l1l_l1_[-1].replace(l1111_l1_ (u"ࠨ࠰ࡷࡷࠬ➧"),l1111_l1_ (u"ࠩࠪ➨")).replace(l1111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ➩"),l1111_l1_ (u"ࠫࠬ➪"))
	if function==l1111_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ➫"): l1l1ll1l1ll_l1_ = l1111_l1_ (u"࠭ࡧࡦࡶࡢࡷ࡭ࡵࡲࡵࡡࡨࡴ࡬࠭➬")
	else: l1l1ll1l1ll_l1_ = l1111_l1_ (u"ࠧࡨࡧࡷࡣࡸ࡯࡭ࡱ࡮ࡨࡣࡩࡧࡴࡢࡡࡷࡥࡧࡲࡥࠨ➭")
	l1l11l1ll1l_l1_,l1l1lll11ll_l1_,server,username,password = l1l11ll11ll_l1_()
	if username==l1111_l1_ (u"ࠨࠩ➮"): return
	l1l11l1111l_l1_ = l1l11l1ll1l_l1_+l1111_l1_ (u"ࠩࠩࡥࡨࡺࡩࡰࡰࡀࠫ➯")+l1l1ll1l1ll_l1_+l1111_l1_ (u"ࠪࠪࡸࡺࡲࡦࡣࡰࡣ࡮ࡪ࠽ࠨ➰")+l11llll11l1_l1_
	html = l111l11_l1_(l1l111ll_l1_,l1l11l1111l_l1_,l1111_l1_ (u"ࠫࠬ➱"),headers,l1111_l1_ (u"ࠬ࠭➲"),l1111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡊࡖࡇࡠࡋࡗࡉࡒ࡙࠭࠳ࡰࡧࠫ➳"))
	l1l11lll1ll_l1_ = l1lll11ll11_l1_(l1111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ➴"),html)
	l1l1111111l_l1_ = l1l11lll1ll_l1_[l1111_l1_ (u"ࠨࡧࡳ࡫ࡤࡲࡩࡴࡶ࡬ࡲ࡬ࡹࠧ➵")]
	l1l11l1l1l1_l1_ = []
	if function in [l1111_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ➶"),l1111_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭➷")]:
		for dict in l1l1111111l_l1_:
			if dict[l1111_l1_ (u"ࠫ࡭ࡧࡳࡠࡣࡵࡧ࡭࡯ࡶࡦࠩ➸")]==1:
				l1l11l1l1l1_l1_.append(dict)
				if function in [l1111_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ➹")]: break
		if not l1l11l1l1l1_l1_: return
		l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➺"),menu_name+l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ส่๊๊แศฬࠣห้ษ่ๅ์ࠣฬ์ึ็ࠡษ็ๆฬฬๅสࠢๅำ๊ࠥวࠡฬ฼้้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➻"),l1111_l1_ (u"ࠨࠩ➼"),9999)
		if function in [l1111_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ➽")]:
			l1l1ll1lll1_l1_ = 2
			l1l11111l11_l1_ = l1l1ll1lll1_l1_*HOUR
			l1l11l1l1l1_l1_ = []
			l1l1lll1lll_l1_ = int(int(dict[l1111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ➾")])/l1l11111l11_l1_)*l1l11111l11_l1_
			l1l1l11lll1_l1_ = now+l1l11111l11_l1_
			l11llll1ll1_l1_ = int((l1l1l11lll1_l1_-l1l1lll1lll_l1_)/HOUR)
			for count in range(l11llll1ll1_l1_):
				if count>=6:
					if count%l1l1ll1lll1_l1_!=0: continue
					duration = l1l11111l11_l1_
				else: duration = l1l11111l11_l1_//2
				l1l11l11lll_l1_ = l1l1lll1lll_l1_+count*HOUR
				dict = {}
				dict[l1111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ➿")] = l1111_l1_ (u"ࠬ࠭⟀")
				struct = time.localtime(l1l11l11lll_l1_-l1l111l11l1_l1_-HOUR)
				dict[l1111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ⟁")] = time.strftime(l1111_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ⟂"),struct)
				dict[l1111_l1_ (u"ࠨࡵࡷࡥࡷࡺ࡟ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ⟃")] = str(l1l11l11lll_l1_)
				dict[l1111_l1_ (u"ࠩࡶࡸࡴࡶ࡟ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ⟄")] = str(l1l11l11lll_l1_+duration)
				l1l11l1l1l1_l1_.append(dict)
	elif function in [l1111_l1_ (u"ࠪࡗࡍࡕࡒࡕࡡࡈࡔࡌ࠭⟅"),l1111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭⟆")]: l1l11l1l1l1_l1_ = l1l1111111l_l1_
	if function==l1111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡉࡕࡍࠧ⟇") and len(l1l11l1l1l1_l1_)>0:
		l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⟈"),menu_name+l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊ิ์ࠦโศศ่อࠥฮัศ็ฯࠤฬ๊โ็๊สฮࠥ࠮ฬะ๊็ࠤๆ่ืࠪโ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⟉"),l1111_l1_ (u"ࠨࠩ⟊"),9999)
	#l11lll1llll_l1_ = [l1111_l1_ (u"ࠩࡖࡥࡹ࠭⟋"), l1111_l1_ (u"ࠪࡗࡺࡴࠧ⟌"), l1111_l1_ (u"ࠫࡒࡵ࡮ࠨ⟍"), l1111_l1_ (u"࡚ࠬࡵࡦࠩ⟎"), l1111_l1_ (u"࠭ࡗࡦࡦࠪ⟏") , l1111_l1_ (u"ࠧࡕࡪࡸࠫ⟐"), l1111_l1_ (u"ࠨࡈࡵ࡭ࠬ⟑")]
	#arabic = [l1111_l1_ (u"ࠩึฬฯ࠭⟒"), l1111_l1_ (u"ࠪวาีࠧ⟓"), l1111_l1_ (u"ࠫศัๆ๋่ࠪ⟔"), l1111_l1_ (u"ࠬัไศอสลࠬ⟕"), l1111_l1_ (u"࠭ราส฼หฦ࠭⟖"), l1111_l1_ (u"ࠧฯ็ํืࠬ⟗"), l1111_l1_ (u"ࠨฮ่฽ฮ࠭⟘")]
	l1l11l11ll1_l1_ = []
	img = xbmc.getInfoLabel(l1111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ⟙"))
	for dict in l1l11l1l1l1_l1_:
		title = base64.b64decode(dict[l1111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ⟚")])
		if kodi_version>18.99: title = title.decode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⟛"))
		l1l11l11lll_l1_ = int(dict[l1111_l1_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ⟜")])
		l1l1l1ll111_l1_ = int(dict[l1111_l1_ (u"࠭ࡳࡵࡱࡳࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ⟝")])
		l1l1l1l11ll_l1_ = str(int((l1l1l1ll111_l1_-l1l11l11lll_l1_+59)/60))
		l1l1llll1ll_l1_ = dict[l1111_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭⟞")].replace(l1111_l1_ (u"ࠨࠢࠪ⟟"),l1111_l1_ (u"ࠩ࠽ࠫ⟠"))
		#struct = time.gmtime(l1l11l11lll_l1_-l1l111l11l1_l1_+time.altzone-3600)
		#l1l1llll1ll_l1_ = time.strftime(l1111_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ⟡"),struct)
		struct = time.localtime(l1l11l11lll_l1_-HOUR)
		l1l1l11l111_l1_ = time.strftime(l1111_l1_ (u"ࠫࠪࡎ࠺ࠦࡏࠪ⟢"),struct)
		l1l1l1l1l1l_l1_ = time.strftime(l1111_l1_ (u"ࠬࠫࡡࠨ⟣"),struct)
		#l1l11l1llll_l1_ = l11lll1llll_l1_.index(l1l1l1l1l1l_l1_)
		#l1l1ll1l11l_l1_ = arabic[l1l11l1llll_l1_]
		#title = l1111_l1_ (u"࠭เࠡࠩ⟤")+title+l1111_l1_ (u"ࠧࠡࠢࠫࠫ⟥")+l1l1l1l11ll_l1_+l1111_l1_ (u"ࠨัๅ࠭ࠥ࠭⟦")+l1l1l11l111_l1_+l1111_l1_ (u"ࠩࠣࠫ⟧")+l1l1ll1l11l_l1_
		if function==l1111_l1_ (u"ࠪࡗࡍࡕࡒࡕࡡࡈࡔࡌ࠭⟨"): title = l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ⟩")+l1l1l11l111_l1_+l1111_l1_ (u"ࠬࠦเࠡࠩ⟪")+title+l1111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ⟫")
		elif function==l1111_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ⟬"): title = l1l1l1l1l1l_l1_+l1111_l1_ (u"ࠨࠢࠪ⟭")+l1l1l11l111_l1_+l1111_l1_ (u"ࠩࠣࠬࠬ⟮")+l1l1l1l11ll_l1_+l1111_l1_ (u"ࠪࡱ࡮ࡴࠩࠨ⟯")
		else: title = l1l1l1l1l1l_l1_+l1111_l1_ (u"ࠫࠥ࠭⟰")+l1l1l11l111_l1_+l1111_l1_ (u"ࠬࠦࠨࠨ⟱")+l1l1l1l11ll_l1_+l1111_l1_ (u"࠭࡭ࡪࡰࠬࠤࠥࠦࠧ⟲")+title+l1111_l1_ (u"ࠧࠡโࠪ⟳")
		if function in [l1111_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ⟴"),l1111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ⟵"),l1111_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭⟶")]:
			l11llllll1l_l1_ = server+l1111_l1_ (u"ࠫ࠴ࡺࡩ࡮ࡧࡶ࡬࡮࡬ࡴ࠰ࠩ⟷")+username+l1111_l1_ (u"ࠬ࠵ࠧ⟸")+password+l1111_l1_ (u"࠭࠯ࠨ⟹")+l1l1l1l11ll_l1_+l1111_l1_ (u"ࠧ࠰ࠩ⟺")+l1l1llll1ll_l1_+l1111_l1_ (u"ࠨ࠱ࠪ⟻")+l11llll11l1_l1_+l1111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ⟼")
			if function==l1111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ⟽"): l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⟾"),menu_name+title,l11llllll1l_l1_,9999,img)
			else: l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⟿"),menu_name+title,l11llllll1l_l1_,235,img)
		l1l11l11ll1_l1_.append(title)
	if function==l1111_l1_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩ⠀") and l1l11l11ll1_l1_: l1l_l1_ = l1l111ll11l_l1_(l1l11l11ll1_l1_)
	return l1l11l11ll1_l1_
def l1l1111l1ll_l1_():
	if not isIPTVFiles(True): return
	server,l1l111l1ll1_l1_,l1l1111ll11_l1_ = l1111_l1_ (u"ࠧࠨ⠁"),0,0
	succeeded,l1l111ll111_l1_,l1l1ll111ll_l1_ = l1l11111ll1_l1_(False)
	if succeeded:
		l1l1ll1l1l1_l1_ = l11llll111l_l1_(l1l111ll111_l1_)
		l1l111l1ll1_l1_ = l11llll1l11_l1_(l1l1ll1l1l1_l1_[0],int(l1l1ll111ll_l1_))
		iptv_dbfile = GET_DBFILE_NAME(l1111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ⠂"))
		groups = READ_FROM_SQL3(iptv_dbfile,l1111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⠃"),l1111_l1_ (u"ࠪࡍࡕ࡚ࡖࡠࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ⠄"))
		streams = READ_FROM_SQL3(iptv_dbfile,l1111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⠅"),l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⠆"),groups[1])
		url = streams[0][2]
		l1l1l11l1l1_l1_ = re.findall(l1111_l1_ (u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩ⠇"),url,re.DOTALL)
		l1l1l11l1l1_l1_ = l1l1l11l1l1_l1_[0]
		if l1111_l1_ (u"ࠧ࠻ࠩ⠈") in l1l1l11l1l1_l1_: l1l11lllll1_l1_,l1l11111l1l_l1_ = l1l1l11l1l1_l1_.split(l1111_l1_ (u"ࠨ࠼ࠪ⠉"))
		else: l1l11lllll1_l1_,l1l11111l1l_l1_ = l1l1l11l1l1_l1_,l1111_l1_ (u"ࠩ࠻࠴ࠬ⠊")
		l11llll1lll_l1_ = l11llll111l_l1_(l1l11lllll1_l1_)
		l1l1111ll11_l1_ = l11llll1l11_l1_(l11llll1lll_l1_[0],int(l1l11111l1l_l1_))
	if l1l111l1ll1_l1_ and l1l1111ll11_l1_:
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⠋"),l1111_l1_ (u"ࠫࠬ⠌"),l1l11lllll1_l1_,l1l111ll111_l1_)
		#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭⠍"),l1111_l1_ (u"࠭ࠧ⠎"),str(l1l111l1ll1_l1_),str(l1l1111ll11_l1_))
		message = l1111_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢสุ่๐ัโำࠣห้ษีๅ์ࠣว๊ࠦวๅีํีๆืࠠศๆฦืึ฿ࠠภࠣࠤࠫ⠏")
		message += l1111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭⠐")+l1111_l1_ (u"๋ࠩๆฯࠦึศศ฼ࠤๆ๐ࠠศๆึ๎ึ็ัࠡษ็วฺ๊๊ࠨ⠑")+l1111_l1_ (u"ࠪࡠࡳ࠭⠒")+str(int(l1l1111ll11_l1_*1000))+l1111_l1_ (u"๋ࠫࠥไ๋ࠢฮห๋๐ษࠨ⠓")
		message += l1111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ⠔")+l1111_l1_ (u"่࠭ใฬฺࠣฬฬูࠡใํࠤฬ๊ำ๋ำไีࠥอไษัํ่ࠬ⠕")+l1111_l1_ (u"ࠧ࡝ࡰࠪ⠖")+str(int(l1l111l1ll1_l1_*1000))+l1111_l1_ (u"ࠨ่่ࠢ๏ࠦหศ่ํอࠬ⠗")
		l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ⠘"),l1111_l1_ (u"ࠪหู้๊าใิࠤฬ๊รึๆํࠫ⠙"),l1111_l1_ (u"ࠫฬ๊ำ๋ำไีࠥอไฤีิ฽ࠬ⠚"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⠛"),message)
		if l1l1l1l111_l1_==1 and l1l111l1ll1_l1_<l1l1111ll11_l1_: server = l1l111ll111_l1_+l1111_l1_ (u"࠭࠺ࠨ⠜")+l1l1ll111ll_l1_
	else: l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⠝"),l1111_l1_ (u"ࠨࠩ⠞"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⠟"),l1111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำࠥอไิ์ิๅึࠦวๅสา๎้࠭⠠"))
	settings.setSetting(l1111_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡹࡥࡳࡸࡨࡶࠬ⠡"),server)
	return
def l1lllll_l1_(url,type):
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࠩ⠢"))
	if l1l1111ll1_l1_!=l1111_l1_ (u"࠭ࠧ⠣"): url = url+l1111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭⠤")+l1l1111ll1_l1_
	l11l1lll1l_l1_ = settings.getSetting(l1111_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡶࡩࡷࡼࡥࡳࠩ⠥"))
	if l11l1lll1l_l1_:
		l1l1l111l11_l1_ = re.findall(l1111_l1_ (u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬ⠦"),url,re.DOTALL)
		l1l1lll_l1_ = url.replace(l1l1l111l11_l1_[0],l11l1lll1l_l1_)
		l11l_l1_ = l1ll11ll1_l1_(l1l1lll_l1_,l111_l1_,type)
		#if l11l_l1_!=l1111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ⠧"):
		#	choice = l1l111lll11_l1_(l1111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ⠨"),l1111_l1_ (u"ࠬิั้ฮࠪ⠩"),l1111_l1_ (u"࠭ล๋ไสๅ๋ࠥฤใฬࠪ⠪"),l1111_l1_ (u"ࠧฦ์ๅหๆࠦฯศศ่๎ࠬ⠫"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⠬"),l1111_l1_ (u"ࠩ็่ศูแࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆࠦวๅีํีๆืࠠศๆฦืึ฿้ࠠษึฮำีวๆࠢสุ่๐ัโำࠣห้ษีๅ์ࠣฯ๊ࠦลฺษาอ๋ࠥอศ๊็อࠥ็สฮࠢส่ๆ๐ฯ๋๊้ࠣึฯࠠฤะิํࠥลࠡࠢࠩ⠭"))
		#	if choice in [1,2]:
		#		if choice==2: settings.setSetting(l1111_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡸ࡫ࡲࡷࡧࡵࠫ⠮"),l1111_l1_ (u"ࠫࠬ⠯"))
		#		l1ll11ll1_l1_(url,l111_l1_,type)
	else: l1ll11ll1_l1_(url,l111_l1_,type)
	return
def l1l111l1lll_l1_():
	l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭⠰"),l1111_l1_ (u"࠭ࠧ⠱"),l1111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⠲"),l1111_l1_ (u"ࠨฬะิ๏ืࠠๆ้่ࠤํํวๆࠢฯำฬࠦ࠮ࠡ์ิะ๎ูࠦะ็ࠣฮ฿๐๊า้ࠣษีอࠠไ่อࠤ้อࠠห฻ิๅ๋ࠥว้๋ࠡࠤ࠳้ࠦࠠ฻า้ࠥะฺ๋์ิ๋ࠥหไศࠢ฼๊ิࠦวๅุิ์ึฯࠠศๆๅูํ๏ࠠ࠯ࠢส่าอฬสࠢ็๋ีอࠠศๆอ฾๏๐ั้ࠡํࠤๆ่ืࠡวำหࠥ฽ไษฬ้๋้ࠣࠠีำๆอࠥๆࡉࡑࡖ࡙ࠤศ์ࠠห฻่่ࠥํะศࠢส่ฯเ๊๋ำࠣ࠲ࠥ๎แใูࠣ฽๋ีๅศࠢอืฯิฯๆࠢัำ๊ฯࠠแࡋࡓࡘ࡛ࠦสฮฬสะࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣาฬ฻ࠧ⠳"))
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹ࠭⠴"))
	l1l11111lll_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ⠵"),l1111_l1_ (u"ࠫฬูสฯัส้ࠥอไฤื็๎ࠬ⠶"),l1111_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ⠷"),l1l1111ll1_l1_,l1111_l1_ (u"࠭็ัษ๋ࠣํࠦเࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤฬ๊ๅิฬัำ๊ࠦอศๆํหู๋ࠥࠡโࡌࡔ࡙࡜ࠠศๆำ๎ࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣฮ฾ี๊ๅ้ࠣว๊ࠦสา์าࠤส฿วะฬ๊ࠤสู๊้๊ࠡ฽๏ฯࠠศๆอฯอ๐สࠡษ็วฺ๊๊๊ࠡส่ฯ๐ࠠหไิ๎ออࠠห่สือࠦฬๆ์฼ࠤูืใศฬࠣไࡎࡖࡔࡗࠢยࠥࠬ⠸"))
	if l1l11111lll_l1_==1: l1l1111ll1_l1_ = l11ll_l1_(l1111_l1_ (u"ࠧฤๅอฬࠥๆࡉࡑࡖ࡙ࠤ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠡฮา๎ิ࠭⠹"),l1l1111ll1_l1_,True)
	else: l1l1111ll1_l1_ = l1111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ⠺")
	if l1l1111ll1_l1_==l1111_l1_ (u"ࠩࠣࠫ⠻"):
		l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⠼"),l1111_l1_ (u"ࠫࠬ⠽"),l1111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⠾"),l1111_l1_ (u"ฺ๋࠭ำุ้๋่ࠣฮࠢฦืฯิฯศ็ࠣๅึอฺࠡๆ๋ัิํࠠฤ๊ࠣ฽ิฯࠠโำส฾ฬะࠠๅ๊ะำ์อࠠ࠯࠰࠱ࠤ๏าศࠡว่หࠥะัไ้ࠣๅฬืฺࠡฬ่ห๊อࠠฤ๊ࠣษ฻อแสࠢะีๆࠦร้ࠢฦ๎ฺ๊ࠥࠡฤัีู๋่ࠥษࠪ⠿"))
		return
	l1l11111lll_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ⡀"),l1111_l1_ (u"ࠨࠩ⡁"),l1111_l1_ (u"ࠩࠪ⡂"),l1l1111ll1_l1_,l1111_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥํะศࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠษั็ห๋ࠥๆࠡࠢส่็ี๊ๆࠢยࠫ⡃"))
	if l1l11111lll_l1_!=1:
		l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ⡄"),l1111_l1_ (u"ࠬ࠭⡅"),l1111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⡆"),l1111_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ⡇"))
		return
	settings.setSetting(l1111_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࠬ⡈"),l1l1111ll1_l1_)
	l1l111llll1_l1_()
	return
def l1l11ll11ll_l1_(l1l1111lll1_l1_=l1111_l1_ (u"ࠩࠪ⡉")):
	if l1l1111lll1_l1_==l1111_l1_ (u"ࠪࠫ⡊"): l1l1111lll1_l1_ = settings.getSetting(l1111_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡻࡲ࡭ࠩ⡋"))
	server = l1l1lll1l_l1_(l1l1111lll1_l1_,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩ⡌"))
	username = re.findall(l1111_l1_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨ⡍"),l1l1111lll1_l1_+l1111_l1_ (u"ࠧࠧࠩ⡎"),re.DOTALL)
	password = re.findall(l1111_l1_ (u"ࠨࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠬ࠳࠰࠿ࠪࠨࠪ⡏"),l1l1111lll1_l1_+l1111_l1_ (u"ࠩࠩࠫ⡐"),re.DOTALL)
	if not username or not password:
		l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⡑"),l1111_l1_ (u"ࠫࠬ⡒"),l1111_l1_ (u"ࠬ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠨ⡓"),l1111_l1_ (u"࠭ัศสฺࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠣห้ึ๊ࠡไ่ฮࠥอๆหࠢหษ฻อแห้ࠣษ้๏ࠠศๆหี๋อๅอࠢ็หࠥ๐ูๆๆࠣวํࠦวๅำสฬ฼ฺ๋ࠦำ้ࠣํา่ะࠢไ๎ࠥอไษำ้ห๊าࠠ࠯ࠢฦิ์ฮࠠฦๆ์ࠤ็อฦๆหࠣหูะัศๅࠣไࡎࡖࡔࡗ๋ࠢๆ๊ࠦศฦุสๅฮࠦัศสฺࠤๅࡏࡐࡕࡘࠣะิ๐ฯࠡล๋ࠤ็๋ࠠษวุ่ฬำࠠศๆิหอ฽ࠠศๆๅำ๏๋ࠧ⡔"))
		return l1111_l1_ (u"ࠧࠨ⡕"),l1111_l1_ (u"ࠨࠩ⡖"),l1111_l1_ (u"ࠩࠪ⡗"),l1111_l1_ (u"ࠪࠫ⡘"),l1111_l1_ (u"ࠫࠬ⡙")
	username = username[0]
	password = password[0]
	l1l11l1ll1l_l1_ = server+l1111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡡࡱ࡫࠱ࡴ࡭ࡶ࠿ࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ࠪ⡚")+username+l1111_l1_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪ⡛")+password
	l1l1lll11ll_l1_ = server+l1111_l1_ (u"ࠧ࠰ࡩࡨࡸ࠳ࡶࡨࡱࡁࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬ⡜")+username+l1111_l1_ (u"ࠨࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁࠬ⡝")+password+l1111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࡯࠶ࡹࡤࡶ࡬ࡶࡵࠪ⡞")
	return l1l11l1ll1l_l1_,l1l1lll11ll_l1_,server,username,password
def l11lllll11l_l1_():
	l1l11111lll_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ⡟"),l1111_l1_ (u"ࠫࠬ⡠"),l1111_l1_ (u"ࠬ࠭⡡"),l1111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⡢"),l1111_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ั๊ࠦฮฬสะࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤ๊์ࠠฤ์ุࠣึ้ษࠡโࡌࡔ࡙࡜้่๋ࠠ฽ࠥืวษูࠣห้ะอๆ์็ࠤฬ๊ๅุๆ๋ฬࠥํ่ࠡ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡳ࠳ࡶ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࠥࠦ࡜࡯๊่ࠢࠥะั๋ัࠣฮ฿๐๊าࠢส่ึอศุࠢส่ว์ࠠภࠩ⡣"))
	if l1l11111lll_l1_!=1: return
	l1l11l111ll_l1_ = settings.getSetting(l1111_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡶࡱ࠭⡤"))
	if l1l11l111ll_l1_!=l1111_l1_ (u"ࠩࠪ⡥"):
		l1l11111lll_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ⡦"),l1111_l1_ (u"่ࠫะวษหࠣะิ๐ฯࠨ⡧"),l1111_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ⡨"),l1111_l1_ (u"࠭วๅำสฬ฼ࠦวๅฯส่๏ࠦ็้࠼ࠪ⡩"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ⡪")+l1l11l111ll_l1_+l1111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⡫")+l1111_l1_ (u"ࠩ࡟ࡲࡡࡴ่ࠠาสࠤ์๎ࠠาษห฻ࠥๆࡉࡑࡖ࡙ࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠห฻า๎้ํࠠฤ็ࠣฮึ๐ฯࠡๅอหอฯࠠาษห฻ࠥาฯ๋ัࠣรࠦ࠭⡬"))
		if l1l11111lll_l1_!=1: l1l11l111ll_l1_ = l1111_l1_ (u"ࠪࠫ⡭")
	l11lll1ll1l_l1_ = l11ll_l1_(l1111_l1_ (u"ࠫฬ้สษࠢิหอ฽ࠠแࡋࡓࡘ࡛ࠦใศ็็หࠬ⡮"),l1l11l111ll_l1_)
	if l11lll1ll1l_l1_==l1111_l1_ (u"ࠬ࠭⡯"): return
	else:
		l1l11l1ll1l_l1_,l1l1lll11ll_l1_,server,username,password = l1l11ll11ll_l1_(l11lll1ll1l_l1_)
		if username==l1111_l1_ (u"࠭ࠧ⡰"): return
		message = l1111_l1_ (u"่ࠧา๊ࠤฬ๊ๅฺๆ๋้ฬะࠠห็ࠣวำึ็ศ่๊ࠢࠥืวษูࠣไࡎࡖࡔࡗࠢส่ี๐ࠠศ่อࠤ่ะศห้ࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ศࠢยࠥࡡࡴࠧ⡱")
		message += l1111_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭⡲")+server+l1111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠ฽๋๎ว็ࠢสุ่๐ัโำ࠽ࠤࠬ⡳")
		message += l1111_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ⡴")+username+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢอำๆࠢสู่๊สฯั่࠾ࠥ࠭⡵")
		message += l1111_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ⡶")+password+l1111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ไๆ่อࠥอไิำ࠽ࠤࠬ⡷")
		l1l11111lll_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭⡸"),l1111_l1_ (u"ࠨࠩ⡹"),l1111_l1_ (u"ࠩࠪ⡺"),l1111_l1_ (u"ࠪห้ืวษูࠣห้าฯ๋ั๋ࠣํࡀࠧ⡻"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ⡼")+l11lll1ll1l_l1_+l1111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⡽")+l1111_l1_ (u"࠭࡜࡯ࠩ⡾")+message)
		if l1l11111lll_l1_!=1:
			l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⡿"),l1111_l1_ (u"ࠨࠩ⢀"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⢁"),l1111_l1_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧ⢂"))
			return
	settings.setSetting(l1111_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡻࡲ࡭ࠩ⢃"),l11lll1ll1l_l1_)
	settings.setSetting(l1111_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ⢄"),l1111_l1_ (u"࠭ࠧ⢅"))
	settings.setSetting(l1111_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࠪ⢆"),l1111_l1_ (u"ࠨࠩ⢇"))
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹ࠭⢈"))
	if l1l1111ll1_l1_==l1111_l1_ (u"ࠪࠫ⢉"): settings.setSetting(l1111_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࠨ⢊"),l1111_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭⢋"))
	l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭⢌"),l1111_l1_ (u"ࠧࠨ⢍"),l1111_l1_ (u"ࠨࠩ⢎"),l11lll1ll1l_l1_,l1111_l1_ (u"ࠩอ้ࠥะฺ๋ำࠣีฬฮืࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠฦๆ์ࠤ์ึวࠡษ็ีฬฮืࠡษ็ะิ๐ฯࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦแฮื๋ࠣีอࠠศๆิหอ฽ࠠศๆล๊ࠥลࠧ⢏"))
	if l1l1l1l111_l1_==1: ok,l1l111ll111_l1_,l1l1ll111ll_l1_ = l1l11111ll1_l1_(True)
	l1l111llll1_l1_()
	return
def CLEAN_NAME(title):
	title = title.replace(l1111_l1_ (u"ࠪࠤࠥ࠭⢐"),l1111_l1_ (u"ࠫࠥ࠭⢑")).replace(l1111_l1_ (u"ࠬࠦࠠࠨ⢒"),l1111_l1_ (u"࠭ࠠࠨ⢓")).replace(l1111_l1_ (u"ࠧࠡࠢࠪ⢔"),l1111_l1_ (u"ࠨࠢࠪ⢕"))
	title = title.replace(l1111_l1_ (u"ࠩࡿࢀࠬ⢖"),l1111_l1_ (u"ࠪࢀࠬ⢗")).replace(l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ⢘"),l1111_l1_ (u"ࠬࡀࠧ⢙")).replace(l1111_l1_ (u"࠭࠭࠮ࠩ⢚"),l1111_l1_ (u"ࠧ࠮ࠩ⢛"))
	title = title.replace(l1111_l1_ (u"ࠨ࡝࡞ࠫ⢜"),l1111_l1_ (u"ࠩ࡞ࠫ⢝")).replace(l1111_l1_ (u"ࠪࡡࡢ࠭⢞"),l1111_l1_ (u"ࠫࡢ࠭⢟"))
	title = title.replace(l1111_l1_ (u"ࠬ࠮ࠨࠨ⢠"),l1111_l1_ (u"࠭ࠨࠨ⢡")).replace(l1111_l1_ (u"ࠧࠪࠫࠪ⢢"),l1111_l1_ (u"ࠨࠫࠪ⢣"))
	title = title.replace(l1111_l1_ (u"ࠩ࠿ࡀࠬ⢤"),l1111_l1_ (u"ࠪࡀࠬ⢥")).replace(l1111_l1_ (u"ࠫࡃࡄࠧ⢦"),l1111_l1_ (u"ࠬࡄࠧ⢧"))
	#title = title.strip(l1111_l1_ (u"࠭ࠠࠨ⢨")).strip(l1111_l1_ (u"ࠧࡽࠩ⢩")).strip(l1111_l1_ (u"ࠨ࠯ࠪ⢪")).strip(l1111_l1_ (u"ࠩ࠽ࠫ⢫")).strip(l1111_l1_ (u"ࠪࠬࠬ⢬")).strip(l1111_l1_ (u"ࠫࡠ࠭⢭"))
	return title
l1111_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪ࡙ࠥࡐࡍࡋࡗࡣࡓࡇࡍࡆࠪࡷ࡭ࡹࡲࡥࠪ࠼ࠍࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡃ࠽ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪ࠾ࠥࡸࡥࡵࡷࡵࡲࠥࡺࡩࡵ࡮ࡨࠎࠎࡲ࡯ࡸࡧࡶࡸ࠱ࡲࡡ࡯ࡩࠣࡁࠥ࠿࠹࠺࠻࠯ࠫࠬࠐࠉࡧ࡫ࡵࡷࡹࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࡛࠱࠼࠵ࡡࠏࠏࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࡵࠣࡁࠥࡡࠧࠡࠩ࠯ࠫ࠿࠭ࠬࠨ࠯ࠪ࠰ࠬࢂࠧ࠭ࠩࡠࠫ࠱࠭ࠩࠨ࠮ࠪࠧࠬ࠲ࠧ࠯ࠩ࠯ࠫ࠱࠭ࠬࠨࠦࠪ࠰ࠧ࠭ࠢ࠭ࠩࠤࠫ࠱࠭ࡀࠨ࠮ࠪࠩࠬ࠲ࠧࠧࠩ࠯ࠫ࠯࠭ࠬࠨࡠࠪࡡࠏࠏࡩࡧࠢࠣࠤ࡫࡯ࡲࡴࡶ࡞࠴ࡢࡃ࠽ࠨࠪࠪ࠾ࠥࡹࡥࡱࡣࡵࡥࡹࡵࡲࡴࠢࡀࠤࡠ࠭ࠩࠨ࡟ࠍࠍࡪࡲࡩࡧࠢࡩ࡭ࡷࡹࡴ࡜࠲ࡠࡁࡂ࡛࠭ࠨ࠼ࠣࡷࡪࡶࡡࡳࡣࡷࡳࡷࡹࠠ࠾ࠢ࡞ࠫࡢ࠭࡝ࠋࠋࡨࡰ࡮࡬ࠠࡧ࡫ࡵࡷࡹࡡ࠰࡞࠿ࡀࠫࡁ࠭࠺ࠡࡵࡨࡴࡦࡸࡡࡵࡱࡵࡷࠥࡃࠠ࡜ࠩࡁࠫࡢࠐࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡶࡩࡵࡧࡲࡢࡶࡲࡶࡸࡀࠊࠊࠋࡳࡳࡸ࡯ࡴࡪࡱࡱࠤࡂࠦࡴࡪࡶ࡯ࡩࡠ࠸࠺࡞࠰ࡩ࡭ࡳࡪࠨࡪࠫࠍࠍࠎࠩࡰࡰࡵ࡬ࡸ࡮ࡵ࡮ࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࡝࠴࠾ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠢࠪ࠰ࠬ࠭ࠩ࠯ࡨ࡬ࡲࡩ࠮ࡩࠪࠌࠌࠍ࡮࡬ࠠࡱࡱࡶ࡭ࡹ࡯࡯࡯ࡀࡀ࠴ࠥࡧ࡮ࡥࠢࡳࡳࡸ࡯ࡴࡪࡱࡱࡀࡂࡲ࡯ࡸࡧࡶࡸ࠿ࠐࠉࠊࠋ࡯ࡳࡼ࡫ࡳࡵࠢࡀࠤࡵࡵࡳࡪࡶ࡬ࡳࡳࠐࠉࠊࠋࡶࡩࡵࠦ࠽ࠡ࡫ࠍࠍ࡮࡬ࠠ࡭ࡱࡺࡩࡸࡺ࠽࠾࠻࠼࠽࠾ࡀࠠ࡭ࡣࡱ࡫ࠥࡃࠠࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪࠎࠎ࡯ࡦࠡ࡮ࡤࡲ࡬ࡃ࠽ࠨࠩ࠽ࠎࠎࠏ࡮ࡢ࡯ࡨ࠵࠱ࡴࡡ࡮ࡧ࠵ࠤࡂࠦࡴࡪࡶ࡯ࡩࡠ࠸࠺࡞࠰ࡶࡴࡱ࡯ࡴࠩࡵࡨࡴ࠱࠷ࠩࠋࠋࠌࡰࡦࡴࡧࠡ࠿ࠣࡪ࡮ࡸࡳࡵ࠭ࡱࡥࡲ࡫࠱ࠬࡵࡨࡴ࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠨࡺࡩࡵ࡮ࡨࠤࡂࠦࡦࡪࡴࡶࡸ࠰࠭ࠠࠨ࠭ࡶࡩࡵ࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫ࠮ࠫࠥ࠭ࠫ࡯ࡣࡰࡩ࠷ࠐࠉࠊࠥࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠥࠦࠧ࠭ࠩࠣࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠢࠣࠫ࠱࠭ࠠࠨࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡱࡧ࡮ࡨ࠮ࡷ࡭ࡹࡲࡥࠋࠤࠥࠦ⢮")
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	lang,sep = l1111_l1_ (u"࠭ࠧ⢯"),l1111_l1_ (u"ࠧࠨ⢰")
	title2 = title
	first = title[:1]
	rest = title[1:]
	if   first==l1111_l1_ (u"ࠨࠪࠪ⢱"): sep = l1111_l1_ (u"ࠩࠬࠫ⢲")
	elif first==l1111_l1_ (u"ࠪ࡟ࠬ⢳"): sep = l1111_l1_ (u"ࠫࡢ࠭⢴")
	elif first==l1111_l1_ (u"ࠬࡂࠧ⢵"): sep = l1111_l1_ (u"࠭࠾ࠨ⢶")
	elif first==l1111_l1_ (u"ࠧࡽࠩ⢷"): sep = l1111_l1_ (u"ࠨࡾࠪ⢸")
	if sep and (sep in rest):
		part1,part2 = rest.split(sep,1)
		lang = part1
		title2 = first+part1+sep+l1111_l1_ (u"ࠩࠣࠫ⢹")+part2
	elif title.count(l1111_l1_ (u"ࠪࢀࠬ⢺"))>=2:
		part1,part2 = title.split(l1111_l1_ (u"ࠫࢁ࠭⢻"),1)
		lang = part1
		title2 = part1+l1111_l1_ (u"ࠬࠦࡼࠨ⢼")+part2
	else:
		sep = re.findall(l1111_l1_ (u"࠭࡞࡝ࡹࡾ࠶ࢂ࠮ࠠࡽ࡞࠽ࢀࡡ࠳ࡼ࡝ࡾࡿࡠࡢࢂ࡜ࠪࡾ࡟ࠧࢁࡢ࠮ࡽ࡞࠯ࢀࡡࠪࡼ࡝ࠩࡿࡠࠦࢂ࡜ࡁࡾ࡟ࠩࢁࡢࠦࡽ࡞࠭ࢀࡡࡤࠩࠨ⢽"),title,re.DOTALL)
		if not sep: sep = re.findall(l1111_l1_ (u"ࠧ࡟࡞ࡺࡿ࠸ࢃࠨࠡࡾ࡟࠾ࢁࡢ࠭ࡽ࡞ࡿࢀࡡࡣࡼ࡝ࠫࡿࡠࠨࢂ࡜࠯ࡾ࡟࠰ࢁࡢࠤࡽ࡞ࠪࢀࡡࠧࡼ࡝ࡂࡿࡠࠪࢂ࡜ࠧࡾ࡟࠮ࢁࡢ࡞ࠪࠩ⢾"),title,re.DOTALL)
		if not sep: sep = re.findall(l1111_l1_ (u"ࠨࡠ࡟ࡻࢀ࠺ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ⢿"),title,re.DOTALL)
		if sep:
			part1,part2 = title.split(sep[0],1)
			lang = part1
			title2 = part1+l1111_l1_ (u"ࠩࠣࠫ⣀")+sep[0]+l1111_l1_ (u"ࠪࠤࠬ⣁")+part2
	title2 = title2.replace(l1111_l1_ (u"ࠫࠥࠦࠠࠨ⣂"),l1111_l1_ (u"ࠬࠦࠧ⣃")).replace(l1111_l1_ (u"࠭ࠠࠡࠩ⣄"),l1111_l1_ (u"ࠧࠡࠩ⣅"))
	lang = lang.replace(l1111_l1_ (u"ࠨࠢࠣࠫ⣆"),l1111_l1_ (u"ࠩࠣࠫ⣇"))
	if lang==l1111_l1_ (u"ࠪࠫ⣈"): lang = l1111_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡢࠥࠦ࠭⣉")
	return lang,title2
def l1l111llll1_l1_():
	global pDialog,l1l1ll11111_l1_,l1l1lll111l_l1_,l1l1ll1ll1l_l1_,l1l11ll1lll_l1_,l1l1111llll_l1_
	l1l11l1ll1l_l1_,l1l1lll11ll_l1_,server,username,password = l1l11ll11ll_l1_()
	if username==l1111_l1_ (u"ࠬ࠭⣊"): return
	l1l1111ll1_l1_ = settings.getSetting(l1111_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࠪ⣋"))
	headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⣌"):l1l1111ll1_l1_}
	l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ⣍"),l1111_l1_ (u"ࠩࠪ⣎"),l1111_l1_ (u"ࠪࠫ⣏"),l1111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⣐"),l1111_l1_ (u"ࠬ฿ๅๅ์ฬࠤั๊ศࠡ็็ๅฬะࠠแࡋࡓࡘ࡛ࠦฬะ์าอ่ࠥฯࠡฬะฮฬาฺࠠัฬࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ้ฮࠠศๆ่่ๆอสࠡษ็ฦ๋ࠦฟࠨ⣑"))
	if l1l1l1l111_l1_!=1: return
	if 1:
		ok,l1l111ll111_l1_,l1l1ll111ll_l1_ = l1l11111ll1_l1_(False)
		if not ok:
			l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⣒"),l1111_l1_ (u"ࠧࠨ⣓"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⣔"),l1111_l1_ (u"ࠩไุ้ࠦศิฯหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢ࠱ࠤศำสๆษ็ࠤึอศุࠢใࡍࡕ࡚ࡖࠡ฼ํีࠥ฻อ๋ฯࠣวํࠦว็ฬ่๊ࠣࠦสิฬัำ๊ࠦำศสๅหࠥิฯๆหࠣไࡎࡖࡔࡗࠢส่๊๎ฬ้ัฬࠤออไษำ้ห๊าࠠ࠯࠰ࠣ฽้๋วࠡล้ࠤ์ึ็ࠡษ็าิ๋ษࠡฬะฮฬาࠠศึอีฬ้ࠠๆัไ์฾่ࠦึฯํัࠥ๎๊อสࠣว๋ࠦสื์ไࠤึอศุࠢส่ฬฺสาษๆࠤอ์แิๅ่้ࠣฮั็ษ่ะࠥฮวิฬัำฬ๋ࠠใษษ้ฮࠦเࡊࡒࡗ࡚ࠥอไๆ๊ฯ์ิฯࠠษ้ำหࠥอไษำ้ห๊าࠧ⣕"))
			if not l1l1lll11ll_l1_: LOG_THIS(l1111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ⣖"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"ࠫࠥࠦࠠࡏࡱࠣࡍࡕ࡚ࡖࠡࡗࡕࡐࠥ࡬࡯ࡶࡰࡧࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡌࡔ࡙࡜ࠠࡧ࡫࡯ࡩࡸ࠭⣗"))
			else: LOG_THIS(l1111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ⣘"),l1l11ll1l1_l1_(l111_l1_)+l1111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡊࡒࡗ࡚ࠥ࡬ࡩ࡭ࡧࡶࠫ⣙"))
			return
		import l1l1l1l1l11_l1_
		l1l1llll1l1_l1_ = l1l1l1l1l11_l1_.l1l1l1ll11l_l1_(l1l1lll11ll_l1_,headers)
		if not l1l1llll1l1_l1_: return
		open(l1l11ll1l1l_l1_,l1111_l1_ (u"ࠧࡸࡤࠪ⣚")).write(l1l1llll1l1_l1_)
	else: l1l1llll1l1_l1_ = open(l1l11ll1l1l_l1_,l1111_l1_ (u"ࠨࡴࡥࠫ⣛")).read()
	if kodi_version>18.99: l1l1llll1l1_l1_ = l1l1llll1l1_l1_.decode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⣜"))
	pDialog = l1l1l1l1ll_l1_()
	pDialog.create(l1111_l1_ (u"ࠪะ้ฮࠠๆๆไหฯࠦเࡊࡒࡗ࡚ࠥาฯ๋ัฬࠫ⣝"),l1111_l1_ (u"ࠫࠬ⣞"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠬࠨࡴࡷࡩ࠰ࠫ⣟"),l1111_l1_ (u"࠭ࠢࠡࡶࡹ࡫࠲࠭⣠"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠧ๏ࠩ⣡"),l1111_l1_ (u"ࠨࠩ⣢")).replace(l1111_l1_ (u"ࠩ๎ࠫ⣣"),l1111_l1_ (u"ࠪࠫ⣤")).replace(l1111_l1_ (u"ࠫ๔࠭⣥"),l1111_l1_ (u"ࠬ࠭⣦")).replace(l1111_l1_ (u"࠭์ࠨ⣧"),l1111_l1_ (u"ࠧࠨ⣨"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠨ๓ࠪ⣩"),l1111_l1_ (u"ࠩࠪ⣪")).replace(l1111_l1_ (u"ࠪ๔ࠬ⣫"),l1111_l1_ (u"ࠫࠬ⣬")).replace(l1111_l1_ (u"ࠬ๓ࠧ⣭"),l1111_l1_ (u"࠭ࠧ⣮")).replace(l1111_l1_ (u"ࠧ๓ࠩ⣯"),l1111_l1_ (u"ࠨࠩ⣰"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠩࡪࡶࡴࡻࡰ࠮ࡶ࡬ࡸࡱ࡫࠽ࠨ⣱"),l1111_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠿ࠪ⣲"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠫࡹࡼࡧ࠮ࠩ⣳"),l1111_l1_ (u"ࠬ࠭⣴")).replace(l1111_l1_ (u"࠭࡜ࡳࠩ⣵"),l1111_l1_ (u"ࠧࠨ⣶")).replace(l1111_l1_ (u"ࠨ࡞ࡱࠫ⣷"),l1111_l1_ (u"ࠩࠪ⣸"))
	live_archived_channels,live_epg_channels = [],[]
	PROGRESS_UPDATE(pDialog,20,l1111_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆอสࠡษ็ฯฬ์่๋หࠪ⣹"),l1111_l1_ (u"ࠫฬ๊ๅๅใࠣี็๋࠺࠮ࠩ⣺"),l1111_l1_ (u"ࠬ࠷ࠠ࠰ࠢ࠶ࠫ⣻"))
	if pDialog.iscanceled(): return
	url = l1l11l1ll1l_l1_+l1111_l1_ (u"࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡸ࡫ࡲࡪࡧࡶࡣࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨ⣼")
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠧࠨ⣽"),headers,l1111_l1_ (u"ࠨࠩ⣾"),l1111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡄࡔࡈࡅ࡙ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓ࠮࠳ࡶࡸࠬ⣿"))
	html = escapeUNICODE(html)
	l1l1l1ll1ll_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡤࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⤀"),html,re.DOTALL)
	del html
	for group in l1l1l1ll1ll_l1_:
		group = group.replace(l1111_l1_ (u"ࠫࡡ࠵ࠧ⤁"),l1111_l1_ (u"ࠬ࠵ࠧ⤂"))
		if kodi_version<19: group = group.decode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⤃")).encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⤄"))
		l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ⤅")+group+l1111_l1_ (u"ࠩࠥࠫ⤆"),l1111_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠿ࠥࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ⤇")+group+l1111_l1_ (u"ࠫࠧ࠭⤈"))
	del l1l1l1ll1ll_l1_
	PROGRESS_UPDATE(pDialog,25,l1111_l1_ (u"ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ⤉"),l1111_l1_ (u"࠭วๅ็็ๅࠥืโๆ࠼࠰ࠫ⤊"),l1111_l1_ (u"ࠧ࠳ࠢ࠲ࠤ࠸࠭⤋"))
	if pDialog.iscanceled(): return
	url = l1l11l1ll1l_l1_+l1111_l1_ (u"ࠨࠨࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡥࡶࡰࡦࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧ⤌")
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠩࠪ⤍"),headers,l1111_l1_ (u"ࠪࠫ⤎"),l1111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡆࡖࡊࡇࡔࡆࡡࡖࡘࡗࡋࡁࡎࡕ࠰࠶ࡳࡪࠧ⤏"))
	html = escapeUNICODE(html)
	l1l11111111_l1_ = re.findall(l1111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࡟࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⤐"),html,re.DOTALL)
	del html
	for group in l1l11111111_l1_:
		group = group.replace(l1111_l1_ (u"࠭࡜࠰ࠩ⤑"),l1111_l1_ (u"ࠧ࠰ࠩ⤒"))
		if kodi_version<19: group = group.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⤓")).encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⤔"))
		l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l1111_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠿ࠥࠫ⤕")+group+l1111_l1_ (u"ࠫࠧ࠭⤖"),l1111_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡁࠧࡥ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡠࠩ⤗")+group+l1111_l1_ (u"࠭ࠢࠨ⤘"))
	del l1l11111111_l1_
	PROGRESS_UPDATE(pDialog,30,l1111_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯࠧ⤙"),l1111_l1_ (u"ࠨษ็้้็ࠠาไ่࠾࠲࠭⤚"),l1111_l1_ (u"ࠩ࠶ࠤ࠴ࠦ࠳ࠨ⤛"))
	if pDialog.iscanceled(): return
	url = l1l11l1ll1l_l1_+l1111_l1_ (u"ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠ࡮࡬ࡺࡪࡥࡳࡵࡴࡨࡥࡲࡹࠧ⤜")
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠫࠬ⤝"),headers,l1111_l1_ (u"ࠬ࠭⤞"),l1111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠹ࡲࡥࠩ⤟"))
	html = escapeUNICODE(html)
	l1l11l11111_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹࡼ࡟ࡢࡴࡦ࡬࡮ࡼࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ⤠"),html,re.DOTALL)
	for name,l1l11ll11l1_l1_ in l1l11l11111_l1_:
		if l1l11ll11l1_l1_==l1111_l1_ (u"ࠨ࠳ࠪ⤡"): live_archived_channels.append(name)
	del l1l11l11111_l1_
	l1l1l1ll1l1_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡥࡱࡩࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ⤢"),html,re.DOTALL)
	del html
	for name,l11llllll11_l1_ in l1l1l1ll1l1_l1_:
		if l11llllll11_l1_!=l1111_l1_ (u"ࠪࡲࡺࡲ࡬ࠨ⤣"): live_epg_channels.append(name)
	del l1l1l1ll1l1_l1_
	lines = re.findall(l1111_l1_ (u"ࠫࡎࡔࡆࠩ࠰࠭ࡃ࠮ࠩࡅ࡙ࡖࠪ⤤"),l1l1llll1l1_l1_+l1111_l1_ (u"ࠬࡢ࡮ࠤࡇ࡛ࡘࠬ⤥"),re.DOTALL)
	l1l1ll1111_l1_ = 1024*1024
	l1l11l11l11_l1_ = 1+len(l1l1llll1l1_l1_)//l1l1ll1111_l1_//10
	del l1l1llll1l1_l1_
	l11llll11ll_l1_ = len(lines)
	l11lllllll1_l1_ = l1l111l1l11_l1_(lines,l1l11l11l11_l1_)
	del lines
	for ii in range(l1l11l11l11_l1_):
		PROGRESS_UPDATE(pDialog,35+int(5*ii/l1l11l11l11_l1_),l1111_l1_ (u"࠭สใูํ฽ࠥอไๆๆไࠤฬ๊ัว์ึ๎ࠬ⤦"),l1111_l1_ (u"ࠧศๆฯึฦࠦัใ็࠽࠱ࠬ⤧"),str(ii+1)+l1111_l1_ (u"ࠨࠢ࠲ࠤࠬ⤨")+str(l1l11l11l11_l1_))
		if pDialog.iscanceled(): return
		l1l11lll11l_l1_ = str(l11lllllll1_l1_[ii])
		if kodi_version>18.99: l1l11lll11l_l1_ = l1l11lll11l_l1_.encode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⤩"))
		open(l1l11ll1l1l_l1_+l1111_l1_ (u"ࠪ࠲࠵࠶ࠧ⤪")+str(ii),l1111_l1_ (u"ࠫࡼࡨࠧ⤫")).write(l1l11lll11l_l1_)
	del l11lllllll1_l1_,l1l11lll11l_l1_
	import EXCLUDES
	l11lllll111_l1_,streams_not_sorted,jj = [],[],0
	for ii in range(l1l11l11l11_l1_):
		if pDialog.iscanceled(): return
		l1l11lll11l_l1_ = open(l1l11ll1l1l_l1_+l1111_l1_ (u"ࠬ࠴࠰࠱ࠩ⤬")+str(ii),l1111_l1_ (u"࠭ࡲࡣࠩ⤭")).read()
		if kodi_version>18.99: l1l11lll11l_l1_ = l1l11lll11l_l1_.decode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⤮"))
		lines = l1lll11ll11_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⤯"),l1l11lll11l_l1_)
		del l1l11lll11l_l1_
		streams,jj,ignored_streams = EXCLUDES.READ_ALL_IPTV_LINES(lines,live_epg_channels,live_archived_channels,pDialog,l11llll11ll_l1_,jj)
		if pDialog.iscanceled(): return
		if not streams: return
		streams_not_sorted += streams
		os.remove(l1l11ll1l1l_l1_+l1111_l1_ (u"ࠩ࠱࠴࠵࠭⤰")+str(ii))
		l11lllll111_l1_ += ignored_streams
	del lines,streams
	grouped_streams,ignored_streams = EXCLUDES.CREATE_IPTV_GROUPED_STREAMS(streams_not_sorted,pDialog,ALL_TYPES)
	if pDialog.iscanceled(): return
	l11lllll111_l1_ += ignored_streams
	del streams_not_sorted,ignored_streams
	l1l1ll1ll11_l1_ = len(ALL_TYPES)
	l1l1lll111l_l1_,l1l11ll1lll_l1_,l1l1ll1ll1l_l1_,l1l1111llll_l1_,ii = {},{},{},0,0
	for TYPE in list(grouped_streams.keys()):
		l1l1ll111l1_l1_,l1l11l1ll11_l1_,l1l11ll111l_l1_ = [],{},[]
		l1l111l1111_l1_ = grouped_streams[TYPE]
		del grouped_streams[TYPE]
		l11lllll1ll_l1_ = len(l1l111l1111_l1_)
		l1l11l1ll11_l1_[l1111_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭⤱")] = [l11lllll1ll_l1_]
		if l11lllll1ll_l1_>0:
			l1l1l1l1lll_l1_,l1l1llll111_l1_,l11lll1l1ll_l1_,l1l1lll1ll1_l1_,l1l1l111ll1_l1_ = zip(*l1l111l1111_l1_)
			l1l11ll111l_l1_ = zip(l1l1l1l1lll_l1_,l1l1l111ll1_l1_)
			del l1l1l1l1lll_l1_,l1l1llll111_l1_,l11lll1l1ll_l1_,l1l1lll1ll1_l1_,l1l1l111ll1_l1_
			l1l11ll111l_l1_ = set(l1l11ll111l_l1_)		# to get l1l1lll11l1_l1_ set
			l1l11ll111l_l1_ = list(l1l11ll111l_l1_)		# to convert set to list
			l1l1ll1l111_l1_ = len(l1l11ll111l_l1_)
			for jj in range(l1l1ll1l111_l1_):
				if jj%173==0:
					PROGRESS_UPDATE(pDialog,60+int(15*ii//l1l1ll1ll11_l1_),l1111_l1_ (u"ࠫฯ฻ๆ๋฻ࠣห้๋ไโษอ࠾࠲ࠦวๅ็็ๅࠥืโๆࠩ⤲"),str(ii)+l1111_l1_ (u"ࠬࠦ࠯ࠡࠩ⤳")+str(l1l1ll1ll11_l1_),str(jj+1)+l1111_l1_ (u"࠭ࠠ࠰ࠢࠪ⤴")+str(l1l1ll1l111_l1_))
					if pDialog.iscanceled(): return
				l1l1ll111l1_l1_.append(l1l11ll111l_l1_[jj])
				group,img = l1l11ll111l_l1_[jj]
				l1l11l1ll11_l1_[group] = []
			del l1l11ll111l_l1_
			l1l1ll111l1_l1_ = sorted(l1l1ll111l1_l1_)
		l1l11l1ll11_l1_[l1111_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ⤵")] = l1l1ll111l1_l1_
		del l1l1ll111l1_l1_
		for group,context,title,url,img in l1l111l1111_l1_:
			l1l11l1ll11_l1_[group].append((context,title,url,img))
		del l1l111l1111_l1_
		l1l1lll111l_l1_[TYPE] = l1l11l1ll11_l1_
		del l1l11l1ll11_l1_
		l1l11ll1lll_l1_[TYPE] = list(l1l1lll111l_l1_[TYPE].keys())
		l1l1ll1ll1l_l1_[TYPE] = len(l1l11ll1lll_l1_[TYPE])
		l1l1111llll_l1_ += l1l1ll1ll1l_l1_[TYPE]
		ii += 1
	l1l1ll11111_l1_ = 0
	l1l11l1l111_l1_(False)
	#import threading
	for TYPE in list(l1l1lll111l_l1_.keys()):
		#l1l1ll1llll_l1_ = threading.Thread(target=l1l1lll1111_l1_,args=(TYPE,))
		#l1l1ll1llll_l1_.start()
		#l1l1ll1llll_l1_.join()
		l1l1lll1111_l1_(TYPE)
		if pDialog.iscanceled(): return
	l1l1lll1l11_l1_ = len(l11lllll111_l1_)
	ii = 0
	for stream in l11lllll111_l1_:
		PROGRESS_UPDATE(pDialog,95+int(5*ii//l1l1lll1l11_l1_),l1111_l1_ (u"ࠨฬัึ๏์ࠠศๆ่๋๊๊ษࠨ⤶"),l1111_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ⤷"),str(ii)+l1111_l1_ (u"ࠪࠤ࠴ࠦࠧ⤸")+str(l1l1lll1l11_l1_))
		if pDialog.iscanceled(): return
		l1ll11lllll_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠫࡎࡖࡔࡗࡡࡌࡋࡓࡕࡒࡆࡆࠪ⤹"),[str(stream)],[l1111_l1_ (u"ࠬ࠭⤺")],l1l1llll11l_l1_,True)
		ii += 1
	l1ll11lllll_l1_(l11llllllll_l1_,l1111_l1_ (u"࠭ࡉࡑࡖ࡙ࡣࡎࡍࡎࡐࡔࡈࡈࠬ⤻"),[l1111_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ⤼")],[str(l1l1lll1l11_l1_)],l1l1llll11l_l1_,True)
	l1ll11lllll_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࡄࡖࡏࡐ࡝ࠬ⤽"),[l1111_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ⤾")],[l1111_l1_ (u"ࠪ࠴ࠬ⤿")],l1l1llll11l_l1_,True)
	open(l1l111lll1l_l1_,l1111_l1_ (u"ࠫࡼ࠭⥀")).write(l1111_l1_ (u"ࠬ࠭⥁"))
	pDialog.close()
	time.sleep(1)
	l1l111ll1ll_l1_ = l11lllll1l1_l1_(False)
	l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⥂"),l1111_l1_ (u"ࠧࠨ⥃"),l1111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⥄"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ⥅")+l1111_l1_ (u"ࠪฮ๊ࠦฬๅส้้ࠣ็วหࠢใࡍࡕ࡚ࡖࠡฮา๎ิฯࠧ⥆")+l1111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⥇")+l1111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ⥈")+l1l111ll1ll_l1_)
	return
def l1l1lll1111_l1_(TYPE):
	global pDialog,l1l1ll11111_l1_,l1l1lll111l_l1_,l1l1ll1ll1l_l1_,l1l11ll1lll_l1_,l1l1111llll_l1_
	for jj in range(1+l1l1ll1ll1l_l1_[TYPE]//173):
		#l1l1l11ll1l_l1_ = l1l11ll1lll_l1_[TYPE][jj*43:(1+jj)*43]
		l1l1l11ll1l_l1_ = l1l11ll1lll_l1_[TYPE][0:173]
		del l1l11ll1lll_l1_[TYPE][0:173]
		l1l1111l11l_l1_,l1l1111l111_l1_ = [],[]
		for group in l1l1l11ll1l_l1_:
			l1l1111l11l_l1_.append(group)
			l1l1111l111_l1_.append(l1l1lll111l_l1_[TYPE][group])
		l1l1ll11111_l1_ += len(l1l1111l111_l1_)
		PROGRESS_UPDATE(pDialog,75+int(20*l1l1ll11111_l1_//l1l1111llll_l1_),l1111_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊࠭⥉"),l1111_l1_ (u"ࠧศๆๅหห๋ษࠡำๅ้࠿࠳ࠧ⥊"),str(l1l1ll11111_l1_)+l1111_l1_ (u"ࠨࠢ࠲ࠤࠬ⥋")+str(l1l1111llll_l1_))
		if pDialog.iscanceled(): return
		iptv_dbfile = GET_DBFILE_NAME(TYPE)
		l1ll11lllll_l1_(iptv_dbfile,l1111_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࠨ⥌")+TYPE,l1l1111l11l_l1_,l1l1111l111_l1_,l1l1llll11l_l1_,True)
	del l1l1lll111l_l1_[TYPE],l1l11ll1lll_l1_[TYPE],l1l1ll1ll1l_l1_[TYPE]
	return
def l11lllll1l1_l1_(l1l11lll111_l1_=True):
	if not isIPTVFiles(l1l11lll111_l1_): return l1111_l1_ (u"ࠪࠫ⥍")
	l1l1lll1l11_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⥎"),l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢࡍࡌࡔࡏࡓࡇࡇࠫ⥏"),l1111_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ⥐"))[0]
	l1l111l111l_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⥑"),l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࡌࡊࡘࡈࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ⥒"),l1111_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ⥓"))[0]
	l1l1lll1l1l_l1_ = READ_FROM_SQL3(l1l1ll11ll1_l1_,l1111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⥔"),l1111_l1_ (u"ࠫࡎࡖࡔࡗࡡ࡙ࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⥕"),l1111_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ⥖"))[0]
	l1l1l1111ll_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"࠭࡬ࡪࡵࡷࠫ⥗"),l1111_l1_ (u"ࠧࡊࡒࡗ࡚ࡤࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ⥘"),l1111_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ⥙"))[0]
	l1l1111ll1l_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⥚"),l1111_l1_ (u"ࠪࡍࡕ࡚ࡖࡠࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ⥛"),l1111_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ⥜"))[0]
	l1l11l111l1_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠬࡲࡩࡴࡶࠪ⥝"),l1111_l1_ (u"࠭ࡉࡑࡖ࡙ࡣ࡛ࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⥞"),l1111_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ⥟"))[0]
	l11l11lll_l1_ = READ_FROM_SQL3(l1l1ll11ll1_l1_,l1111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⥠"),l1111_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ⥡"),l1111_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭⥢"))[0]
	l1l11llll11_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⥣"),l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢ࡚ࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ⥤"),l1111_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ⥥"))[0]
	groups = READ_FROM_SQL3(l1l1ll11ll1_l1_,l1111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⥦"),l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ⥧"),l1111_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭⥨"))
	l1l11llllll_l1_ = []
	for group,img in groups:
		l1l11l1lll1_l1_ = group.split(l1111_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ⥩"))[1]
		l1l11llllll_l1_.append(l1l11l1lll1_l1_)
	l1l1l11llll_l1_ = len(l1l11llllll_l1_)
	total = l1l11l111l1_l1_+l11l11lll_l1_+l1l11llll11_l1_+l1l1111ll1l_l1_+l1l1l1111ll_l1_
	l1l111ll1ll_l1_ = l1111_l1_ (u"ࠫ็์่ศฬ࠽ࠤࠬ⥪")+str(l1l1l1111ll_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥษแๅษ่࠾ࠥ࠭⥫")+str(l1l11l111l1_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"࠭࡜࡯็ึุ่๊วห࠼ࠣࠫ⥬")+str(l1l1l11llll_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠฮๆๅหฯࡀࠠࠨ⥭")+str(l11l11lll_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠨ࡞ࡱๆ๋๎วห่ࠢะ์๎ไส࠼ࠣࠫ⥮")+str(l1l1111ll1l_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢไ๎ิ๎็ศฬ้ࠣัํ่ๅห࠽ࠤࠬ⥯")+str(l1l11llll11_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠪࡠࡳ๋ฬๆ๊฼ࠤฬ๊โ็๊สฮ࠿ࠦࠧ⥰")+str(l1l111l111l_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤ๊าๅ้฻ࠣห้็๊ะ์๋๋ฬะ࠺ࠡࠩ⥱")+str(l1l1lll1l1l_l1_)
	l1l111ll1ll_l1_ += l1111_l1_ (u"ࠬࡢ࡮࡝ࡰ่ะ๊๎ูࠡษ็้฻อแส࠼ࠣࠫ⥲")+str(total)
	l1l111ll1ll_l1_ += l1111_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦๅอ็๋฽ࠥอไๆ้่่ฮࡀࠠࠨ⥳")+str(l1l1lll1l11_l1_)
	if l1l11lll111_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ⥴"),l1111_l1_ (u"ࠨࠩ⥵"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⥶"),l1l111ll1ll_l1_)
	l1l1l1lll11_l1_ = l1l111ll1ll_l1_.replace(l1111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ⥷"),l1111_l1_ (u"ࠫࡡࡴࠧ⥸"))
	LOG_THIS(l1111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⥹"),l1111_l1_ (u"࠭࠮ࠡࠢࠣࡇࡴࡻ࡮ࡵࡵࠣࡳ࡫ࠦࡉࡑࡖ࡙ࠤࡻ࡯ࡤࡦࡱࡶ࠾࠲ࡢ࡮ࠨ⥺")+l1l1l1lll11_l1_)
	return l1l111ll1ll_l1_
def l1l11l1l111_l1_(l1l11lll111_l1_=True):
	if l1l11lll111_l1_:
		l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ⥻"),l1111_l1_ (u"ࠨࠩ⥼"),l1111_l1_ (u"ࠩࠪ⥽"),l1111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦเࡊࡒࡗ࡚ࠬ⥾"),l1111_l1_ (u"ࠫฯูสุ์฼ࠤๆ๐ࠠฤ์ࠣ์็ะࠠศๆาาํ๊ࠠฦๆ์ࠤ็อฦๆหࠣไࡎࡖࡔࡗ๋ࠢะ้ฮࠠๆๆไหฯࠦเࡊࡒࡗ࡚ࠥาฯ๋ัฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯࠣห้๋ไโษอࠤฬ๊โะ์่อࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ⥿"))
		if l1l1l1l111_l1_!=1: return
		try: os.remove(l1l11ll1l1l_l1_)
		except: pass
	try: os.remove(l1l111lll1l_l1_)
	except: pass
	l1ll1lll11l_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢࡈ࡚ࡓࡍ࡚ࠩ⦀"))
	l1ll1lll11l_l1_(l11llllllll_l1_,l1111_l1_ (u"࠭ࡉࡑࡖ࡙ࡣࡎࡍࡎࡐࡔࡈࡈࠬ⦁"))
	l1ll1lll11l_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠧࡊࡒࡗ࡚ࡤࡍࡒࡐࡗࡓࡗࠬ⦂"))
	l1ll1lll11l_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࡉࡕࡇࡐࡗࠬ⦃"))
	l1ll1lll11l_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࡔࡇࡄࡖࡈࡎࠧ⦄"))
	l1ll1lll11l_l1_(cache_dbfile,l1111_l1_ (u"ࠪࡑࡎ࡙ࡃࠨ⦅"),l1111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ⦆"))
	for TYPE in ALL_TYPES:
		iptv_dbfile = GET_DBFILE_NAME(TYPE)
		l1ll1lll11l_l1_(iptv_dbfile,l1111_l1_ (u"ࠬࡏࡐࡕࡘࡢࠫ⦇")+TYPE)
	import l1l1l1l1l11_l1_
	l1l1l1l1l11_l1_.l1l1l11ll11_l1_(False)
	#l1l11l1l11l_l1_(False)
	#l1ll1lll11l_l1_(cache_dbfile,l1111_l1_ (u"࠭ࡍࡊࡕࡆࠫ⦈"),l1111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡏࡍ࡛ࡋࠧ⦉"))
	#l1l11ll1l11_l1_()
	if l1l11lll111_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⦊"),l1111_l1_ (u"ࠩࠪ⦋"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⦌"),l1111_l1_ (u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊่่ࠢๆอสࠡโࡌࡔ࡙࡜ࠧ⦍"))
	return
def isIPTVFiles(l1l11lll111_l1_=True):
	l1l1l1lllll_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠬࡲࡩࡴࡶࠪ⦎"),l1111_l1_ (u"࠭ࡉࡑࡖ࡙ࡣࡉ࡛ࡍࡎ࡛ࠪ⦏"),l1111_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ⦐"))
	if l1l1l1lllll_l1_: return True
	if l1l11lll111_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⦑"),l1111_l1_ (u"ࠩࠪ⦒"),l1111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⦓"),l1111_l1_ (u"ࠫฬ์สࠡสะหัฯࠠฦๆ์ࠤฬ๊ะ่ษหࠤส๊้ࠡไสส๊ฯࠠแࡋࡓࡘ࡛ࠦหๆࠢอฺ฿฽ฺࠠๆ์ࠤࠧหึศใฬࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠥࠤ࠭๎็ัษࠣ๎๊้ๆࠡึิหฦํࠠๆ่ࠣว๏ࠦิาๅฬࠤๅࡏࡐࡕࡘࠬࠤ࠳࠴ࠠฤ๊ࠣว๋ะࠠษฯสะฮࠦไอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢฯำ๏ีษ๊ࠡำ่่ࠦศศๆำ๋ฬฮࠠฦๆ์ࠤ็อฦๆหࠣไࡎࡖࡔࡗࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠩ⦔"))
	return False
def l1lll1_l1_(l1ll1l11l1l_l1_,TYPE=l1111_l1_ (u"ࠬ࠭⦕"),PAGE=l1111_l1_ (u"࠭ࠧ⦖")):
	if not PAGE: PAGE = l1111_l1_ (u"ࠧ࠲ࠩ⦗")
	search,options,l1ll11_l1_ = l1ll1ll_l1_(l1ll1l11l1l_l1_)
	if not isIPTVFiles(l1ll11_l1_): return
	l1l1l1l1ll1_l1_ = [l1111_l1_ (u"ࠨࠩ⦘"),l1111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ⦙"),l1111_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ⦚"),l1111_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ⦛"),l1111_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ⦜"),l1111_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭⦝")]
	if not l1ll11_l1_:
		if   l1111_l1_ (u"ࠧࡠࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࡣࠬ⦞") in options: TYPE = l1l1l1l1ll1_l1_[1]
		elif l1111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⦟") in options: TYPE = l1l1l1l1ll1_l1_[2]
		elif l1111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⦠") in options: TYPE = l1l1l1l1ll1_l1_[3]
	else:
		if not search:
			search = l11ll_l1_()
			if not search: return
		l1l1l111lll_l1_ = [l1111_l1_ (u"ࠪห้้ไࠨ⦡"),l1111_l1_ (u"ࠫ็์่ศฬࠪ⦢"),l1111_l1_ (u"ࠬษแๅษ่ࠫ⦣"),l1111_l1_ (u"࠭ๅิๆึ่ฬะࠧ⦤"),l1111_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ⦥"),l1111_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯࠧ⦦")]
		choice = l11llll_l1_(l1111_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⦧"), l1l1l111lll_l1_)
		if choice == -1: return
		TYPE = l1l1l1l1ll1_l1_[choice]
	l11lll1lll1_l1_ = search.lower()
	l11l_l1_ = READ_FROM_SQL3(l11llllllll_l1_,l1111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⦨"),l1111_l1_ (u"ࠫࡎࡖࡔࡗࡡࡖࡉࡆࡘࡃࡉࠩ⦩"),[TYPE,l11lll1lll1_l1_])
	if not l11l_l1_:
		l1l1ll11lll_l1_,l1l11ll1111_l1_ = [],[]
		if not TYPE: l1l111lllll_l1_ = [1,2,3,4,5]
		else: l1l111lllll_l1_ = [l1l1l1l1ll1_l1_.index(TYPE)]
		for ii in l1l111lllll_l1_:
			iptv_dbfile = GET_DBFILE_NAME(l1l1l1l1ll1_l1_[ii])
			if ii!=3:
				streams = READ_FROM_SQL3(iptv_dbfile,l1111_l1_ (u"ࠬࡪࡩࡤࡶࠪ⦪"),l1111_l1_ (u"࠭ࡉࡑࡖ࡙ࡣࠬ⦫")+l1l1l1l1ll1_l1_[ii])
				del streams[l1111_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ⦬")]
				del streams[l1111_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ⦭")]
				del streams[l1111_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⦮")]
				groups = list(streams.keys())
				for group in groups:
					for context,title,url,img in streams[group]:
						if l11lll1lll1_l1_ in title.lower(): l1l11ll1111_l1_.append((title,url,img))
					del streams[group]
				del streams
			else: groups = READ_FROM_SQL3(iptv_dbfile,l1111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⦯"),l1111_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ⦰")+l1l1l1l1ll1_l1_[ii],l1111_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ⦱"))
			for group in groups:
				try: group,img = group
				except: img = l1111_l1_ (u"࠭ࠧ⦲")
				if l11lll1lll1_l1_ in group.lower():
					if ii!=3: l1l1l1l111l_l1_ = group
					else:
						l1l1l1l11l1_l1_,l11lll1ll11_l1_ = group.split(l1111_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ⦳"))
						if l11lll1lll1_l1_ in l1l1l1l11l1_l1_.lower(): l1l1l1l111l_l1_ = l1l1l1l11l1_l1_
						else: l1l1l1l111l_l1_ = l11lll1ll11_l1_
					l1l1ll11lll_l1_.append((group,l1l1l1l111l_l1_,l1l1l1l1ll1_l1_[ii],img))
			del groups
		l1l1ll11lll_l1_ = set(l1l1ll11lll_l1_)
		l1l11ll1111_l1_ = set(l1l11ll1111_l1_)
		l1l1ll11lll_l1_ = sorted(l1l1ll11lll_l1_,reverse=False,key=lambda key: key[1])
		l1l11ll1111_l1_ = sorted(l1l11ll1111_l1_,reverse=False,key=lambda key: key[0])
		l1ll11lllll_l1_(l11llllllll_l1_,l1111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࡓࡆࡃࡕࡇࡍ࠭⦴"),[TYPE,l11lll1lll1_l1_],[l1l1ll11lll_l1_,l1l11ll1111_l1_],l1l1llll11l_l1_)
	else: l1l1ll11lll_l1_,l1l11ll1111_l1_ = l11l_l1_
	groups = len(l1l1ll11lll_l1_)
	l11l11l11_l1_ = len(l1l11ll1111_l1_)
	page = int(PAGE)
	s1 = max(0,(page-1)*100)
	e1 = max(0,page*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l1l1l111l_l1_,l1l1ll1111l_l1_,img in l1l1ll11lll_l1_[s1:e1]:
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⦵"),menu_name+l1l1l1l111l_l1_,l1l1ll1111l_l1_,234,img,l1111_l1_ (u"ࠪ࠵ࠬ⦶"),group)
	del l1l1ll11lll_l1_
	for title,url,img in l1l11ll1111_l1_[s2:e2]:
		#l1l1111l1l_l1_ = l1l1l11lll_l1_(url)
		l1l1l1llll1_l1_ = url.split(l1111_l1_ (u"ࠫ࠴࠭⦷"))[-1]
		if l1111_l1_ (u"ࠬ࠴ࠧ⦸") in l1l1l1llll1_l1_ and l1111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ⦹") not in l1l1l1llll1_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⦺"),menu_name+title,url,235,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⦻"),menu_name+title,url,235,img)
	del l1l11ll1111_l1_
	l1l1ll11l11_l1_(PAGE,TYPE,239,groups+l11l11l11_l1_,search+l1111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⦼"))
	return
def l1l1ll11l11_l1_(PAGE,TYPE,mode,total,text):
	if PAGE!=l1111_l1_ (u"ࠪ࠵ࠬ⦽"): l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦾"),menu_name+l1111_l1_ (u"ࠬ฻แฮหࠣࠫ⦿")+str(1),TYPE,mode,l1111_l1_ (u"࠭ࠧ⧀"),str(1),text)
	if not total: total = 0
	l1l1l1ll1_l1_ = int(total/100)+1
	for page in range(2,l1l1l1ll1_l1_):
		cond1 = (page%10==0 or int(PAGE)-4<page<int(PAGE)+4)
		cond2 = (cond1 and int(PAGE)-40<page<int(PAGE)+40)
		if str(page)!=PAGE and (page%100==0 or cond2):
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧁"),menu_name+l1111_l1_ (u"ࠨืไัฮࠦࠧ⧂")+str(page),TYPE,mode,l1111_l1_ (u"ࠩࠪ⧃"),str(page),text)
	if str(l1l1l1ll1_l1_)!=PAGE: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧄"),menu_name+l1111_l1_ (u"ࠫศิัࠡืไัฮࠦࠧ⧅")+str(l1l1l1ll1_l1_),TYPE,mode,l1111_l1_ (u"ࠬ࠭⧆"),str(l1l1l1ll1_l1_),text)
	return
l1111_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡓࡂࡘࡈࡣࡘ࡚ࡒࡆࡃࡐࡗࡤ࡚ࡏࡠࡆࡌࡗࡐ࠮ࡧࡳࡱࡸࡴࡪࡪ࡟ࡴࡶࡵࡩࡦࡳࡳ࠭ࡃࡏࡐࡤ࡚࡙ࡑࡇࡖ࠭࠿ࠐࠉࡨ࡮ࡲࡦࡦࡲࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠌࠌࡪ࡮ࡲࡥࡴࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠࠎࠎ࡬ࡩ࡭ࡧࡶࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩ࡬ࡴࡹࡼ࡟ࠨ࠭ࡶࡸࡷ࠮ࡩ࡯ࡶࠫࡲࡴࡽࠩࠪ࠭ࠪࡣ࠳ࡳ࠳ࡶࠩࠬࠎࠎ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠠ࠾ࠢࠪ࡭ࡵࡺࡶࡠࠩ࠮ࡷࡹࡸࠨࡪࡰࡷࠬࡳࡵࡷࠪࠫ࠮ࠫࡤࡥࡔ࡚ࡒࡈࡣࡤ࠴ࡳࡵࡴࡨࡥࡲࡹࠧࠋࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡪ࡮ࡲࡥࠨ࠮ࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠏࠏࡦࡰࡴࠣࡘ࡞ࡖࡅࠡ࡫ࡱࠤࡆࡒࡌࡠࡖ࡜ࡔࡊ࡙࠺ࠋࠋࠌࡲࡪࡽ࡟ࡴࡶࡵࡩࡦࡳࡳࠡ࠿ࠣࡷࡹࡸࠨࡨࡴࡲࡹࡵ࡫ࡤࡠࡵࡷࡶࡪࡧ࡭ࡴ࡝ࡗ࡝ࡕࡋ࡝ࠪࠌࠌࠍࡳ࡫ࡷࡠࡵࡷࡶࡪࡧ࡭ࡴࠢࡀࠤࡳ࡫ࡷࡠࡵࡷࡶࡪࡧ࡭ࡴ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࢂ࠲ࠧ࠭ࠩࢀ࠰ࡡࡴࠧࠪࠌࠌࠍࡳ࡫ࡷࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣࡁࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡢࡣ࡙࡟ࡐࡆࡡࡢࠫ࠱࠭࡟ࠨ࠭ࡗ࡝ࡕࡋࠫࠨࡡࠪ࠭ࠏࠏࠉࡪࡲࡷࡺࡋ࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡥࡩࡪ࡯࡯ࡥࡤࡧ࡭࡫ࡦࡰ࡮ࡧࡩࡷ࠲࡮ࡦࡹࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠐࠉࠊࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡳࡩࡳ࠮ࡩࡱࡶࡹࡊ࡮ࡲࡥ࠭ࠢࠪࡻࡧ࠭ࠩࠋࠋࠌࡪ࡮ࡲࡥ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡯ࡧࡺࡣࡸࡺࡲࡦࡣࡰࡷ࠮ࠐࠉࠊࡨ࡬ࡰࡪ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࡩ࡭ࡱ࡫ࡳࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡥࡸࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠏࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩࡌࡔ࡙࡜ࠧ࠭ࠩอ้ࠥาไษ่่ࠢๆอสࠡโࡌࡔ࡙࡜ࠠอัํำฮ࠭ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠍࡨࡪ࡬ࠠࡈࡇࡗࡣࡘ࡚ࡒࡆࡃࡐࡗࡤࡌࡒࡐࡏࡢࡈࡎ࡙ࡋࠩࡖ࡜ࡔࡊ࠯࠺ࠋࠋࡪࡰࡴࡨࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠎࠎ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡪ࡮ࡲࡥࠨࠫࠍࠍ࡫࡯࡬ࡦࡰࡤࡱࡪࠦ࠽ࠡࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡥ࡟ࡕ࡛ࡓࡉࡤࡥࠧ࠭ࠩࡢࠫ࠰࡚࡙ࡑࡇ࠮ࠫࡤ࠭ࠩࠋࠋ࡬ࡴࡹࡼࡆࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠬࠎࠎ࡬ࠠ࠾ࠢࡲࡴࡪࡴࠨࡪࡲࡷࡺࡋ࡯࡬ࡦ࠮ࠪࡶࡧ࠭ࠩࠋࠋࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡪࡾࡴࠡ࠿ࠣࡪ࠳ࡸࡥࡢࡦࠫ࠭ࠏࠏࡳࡵࡴࡨࡥࡲࡹࠠ࠾ࠢࡈ࡚ࡆࡒࠨࠨ࡮࡬ࡷࡹ࠭ࠬࡴࡶࡵࡩࡦࡳࡳࡠࡶࡨࡼࡹ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࠌࠥࠦࠧ⧇")
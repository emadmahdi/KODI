# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪᛐ")
menu_name=l1111_l1_ (u"ࠪࡣࡈࡓࡎࡠࠩᛑ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠫ็อฦๆฬํࠫᛒ")]
def l1111ll_l1_(mode,url,text):
	if   mode==300: l11l_l1_ = l11l111_l1_()
	elif mode==301: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==302: l11l_l1_ = l1l11l1_l1_(url)
	elif mode==303: l11l_l1_ = l1llll1111_l1_(url)
	elif mode==304: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==305: l11l_l1_ = l1lllll_l1_(url)
	elif mode==309: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᛓ"),menu_name+l1111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᛔ"),l1111_l1_ (u"ࠧࠨᛕ"),309,l1111_l1_ (u"ࠨࠩᛖ"),l1111_l1_ (u"ࠩࠪᛗ"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᛘ"))
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᛙ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᛚ"),l1111_l1_ (u"࠭ࠧᛛ"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᛜ"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩᛝ"),l1111_l1_ (u"ࠩࠪᛞ"),l1111_l1_ (u"ࠪࠫᛟ"),l1111_l1_ (u"ࠫࠬᛠ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᛡ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࠼ࡶ࡮ࡁࠬ࠳࠰࠿ࠪ࠾ࡶࡴࡦࡴ࠾ࠨᛢ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬᛣ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
		title = title.strip(l1111_l1_ (u"ࠨࠢࠪᛤ"))
		if title==l1111_l1_ (u"ࠩิ้฻อๆࠨᛥ"): l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ัๆุส๊࠴࠭ᛦ")
		if not any(value in title for value in l11ll11_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛧ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᛨ")+menu_name+title,l1l111l_l1_,301)
	l11lll1l1_l1_(l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬᛩ"))
	return html
def l11lll1l1_l1_(url):
	seq = 0
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᛪ"),url,l1111_l1_ (u"ࠨࠩ᛫"),l1111_l1_ (u"ࠩࠪ᛬"),l1111_l1_ (u"ࠪࠫ᛭"),l1111_l1_ (u"ࠫࠬᛮ"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᛯ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱࠮ࡄࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠫࠪᛰ"),html,re.DOTALL)
	if l111l1l_l1_:
		for block in l111l1l_l1_:
			seq += 1
			items = re.findall(l1111_l1_ (u"ࠧ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱ࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᛱ"),block,re.DOTALL)
			for title,test,l1l111l_l1_ in items:
				title = title.strip(l1111_l1_ (u"ࠨࠢࠪᛲ"))
				if title==l1111_l1_ (u"ࠩࠪᛳ"): title = l1111_l1_ (u"ࠪฬํ๎่้๊ࠪᛴ")
				if l1111_l1_ (u"ࠫࡪࡳ࠾࠽ࡣࠪᛵ") not in test:
					if block.count(l1111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᛶ"))>0:
						l1ll1l11ll_l1_ = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᛷ"),block,re.DOTALL)
						for l1l111l_l1_ in l1ll1l11ll_l1_:
							title = l1l111l_l1_.split(l1111_l1_ (u"ࠧ࠰ࠩᛸ"))[-2]
							l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᛹"),menu_name+title,l1l111l_l1_,301)
						continue
					else: l1l111l_l1_ = url+l1111_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭᛺")+str(seq)
				#l111l1ll1_l1_ = [l1111_l1_ (u"ุ้๊ࠪำๅษอࠤࠬ᛻"),l1111_l1_ (u"ࠫฬ็ไศ็ࠣࠫ᛼"),l1111_l1_ (u"ࠬฮัศ็ฯࠫ᛽"),l1111_l1_ (u"ู࠭าู๊ࠫ᛾"),l1111_l1_ (u"ࠧไๆํฬฬะࠧ᛿"),l1111_l1_ (u"ࠨษ฽ห๋๏ࠧᜀ")]
				#if any(value in title for value in l111l1ll1_l1_):
				if not any(value in title for value in l11ll11_l1_):
					l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜁ"),menu_name+title,l1l111l_l1_,302)
	else: l1l11l1_l1_(url,html)
	return
def l1l11l1_l1_(url,html=l1111_l1_ (u"ࠪࠫᜂ")):
	if html==l1111_l1_ (u"ࠫࠬᜃ"):
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩᜄ"),url,l1111_l1_ (u"࠭ࠧᜅ"),l1111_l1_ (u"ࠧࠨᜆ"),l1111_l1_ (u"ࠨࠩᜇ"),l1111_l1_ (u"ࠩࠪᜈ"),l1111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᜉ"))
		html = response.content
	if l1111_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᜊ") in url:
		url,seq = url.split(l1111_l1_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩᜋ"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱࠮ࡄࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠫࠪᜌ"),html,re.DOTALL)
		block = l111l1l_l1_[int(seq)-1]
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡲࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡱࡧࡽࡃ࠭ᜍ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠨ࠾ࡤ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᜎ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for l1l111l_l1_,data,img in items:
		title = re.findall(l1111_l1_ (u"ࠩ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠴ࠪࡀ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡭࠿ࠩᜏ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1111_l1_ (u"ࠪࡠࡳ࠭ᜐ"),l1111_l1_ (u"ࠫࠬᜑ")).strip(l1111_l1_ (u"ࠬࠦࠧᜒ"))
		if not title or title==l1111_l1_ (u"࠭ࠧᜓ"):
			title = re.findall(l1111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠾࠯ࠬࡂࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᜔"),data,re.DOTALL)
			if title: title = title[0].replace(l1111_l1_ (u"ࠨ࡞ࡱ᜕ࠫ"),l1111_l1_ (u"ࠩࠪ᜖")).strip(l1111_l1_ (u"ࠪࠤࠬ᜗"))
			if not title or title==l1111_l1_ (u"ࠫࠬ᜘"):
				title = re.findall(l1111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᜙"),data,re.DOTALL)
				title = title[0].replace(l1111_l1_ (u"࠭࡜࡯ࠩ᜚"),l1111_l1_ (u"ࠧࠨ᜛")).strip(l1111_l1_ (u"ࠨࠢࠪ᜜"))
		title = l1l1111_l1_(title)
		#if title==l1111_l1_ (u"ࠩࠪ᜝"): continue
		if title not in l1lllll1_l1_:
			l1lllll1_l1_.append(title)
			l111ll1l_l1_ = l1l111l_l1_+data+img
			if l1111_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ᜞") in l111ll1l_l1_ or l1111_l1_ (u"ู๊ࠫไิๆࠪᜟ") in l111ll1l_l1_ or l1111_l1_ (u"ࠬࠨࡥࡱ࡫ࡶࡳࡩ࡫ࠢࠨᜠ") in l111ll1l_l1_:
				if l1111_l1_ (u"࠭ศาษ่ะࠬᜡ") in data: title = l1111_l1_ (u"ࠧษำ้ห๊าࠠࠨᜢ")+title
				elif l1111_l1_ (u"ࠨ็ึุ่๊ࠧᜣ") in data or l1111_l1_ (u"่ࠩ์ุ๋ࠧᜤ") in data: title = l1111_l1_ (u"ุ้๊ࠪำๅࠢࠪᜥ")+title
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᜦ"),menu_name+title,l1l111l_l1_,303,img)
			else: l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᜧ"),menu_name+title,l1l111l_l1_,305,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᜨ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᜩ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜪ"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨᜫ")+title,l1l111l_l1_,302)
	return
def l1llll1111_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᜬ"),url,l1111_l1_ (u"ࠫࠬᜭ"),l1111_l1_ (u"ࠬ࠭ᜮ"),l1111_l1_ (u"࠭ࠧᜯ"),l1111_l1_ (u"ࠧࠨᜰ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧᜱ"))
	html = response.content
	name = re.findall(l1111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿ࠩᜲ"),html,re.DOTALL)
	name = name[0].replace(l1111_l1_ (u"ࠪࢀู๊ࠥๆษ๊ࠣฬ๎ࠧᜳ"),l1111_l1_ (u"᜴ࠫࠬ")).replace(l1111_l1_ (u"ࠬࡉࡩ࡮ࡣࠣࡒࡴࡽࠧ᜵"),l1111_l1_ (u"࠭ࠧ᜶")).strip(l1111_l1_ (u"ࠧࠡࠩ᜷")).replace(l1111_l1_ (u"ࠨࠢࠣࠫ᜸"),l1111_l1_ (u"ࠩࠣࠫ᜹"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡸ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ᜺"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᜻"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#title = name+l1111_l1_ (u"ࠬࠦࠧ᜼")+title.replace(l1111_l1_ (u"࠭࡜࡯ࠩ᜽"),l1111_l1_ (u"ࠧࠨ᜾")).strip(l1111_l1_ (u"ࠨࠢࠪ᜿"))
			title = title.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬᝀ"),l1111_l1_ (u"ࠪࠫᝁ")).strip(l1111_l1_ (u"ࠫࠥ࠭ᝂ"))
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᝃ"),menu_name+title,l1l111l_l1_,304)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪᝄ"),url,l1111_l1_ (u"ࠧࠨᝅ"),l1111_l1_ (u"ࠨࠩᝆ"),l1111_l1_ (u"ࠩࠪᝇ"),l1111_l1_ (u"ࠪࠫᝈ"),l1111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᝉ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡤࡦࡶࡤ࡭ࡱࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡲࡦ࡮ࡤࡸࡪࡪࠢࠨᝊ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᝋ"),block,re.DOTALL)
	for l1l111l_l1_,img,title in items:
		title = title.replace(l1111_l1_ (u"ࠧ࡝ࡰࠪᝌ"),l1111_l1_ (u"ࠨࠩᝍ")).strip(l1111_l1_ (u"ࠩࠣࠫᝎ"))
		l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᝏ"),menu_name+title,l1l111l_l1_,305,img)
	return
def l1lllll_l1_(url):
	l1111_l1_ (u"ࠦࠧࠨࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡮ࡩ࡯ࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ࠯ࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡤࡱࡲ࡯࡮࡫ࡳࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸ࠴ࡧࡦࡶࡢࡨ࡮ࡩࡴࠩࠫࠍࠍࡕࡎࡐࡔࡇࡖࡗࡎࡊࠠ࠾ࠢࡦࡳࡴࡱࡩࡦࡵ࡞ࠫࡕࡎࡐࡔࡇࡖࡗࡎࡊࠧ࡞ࠌࠌࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠣࡪࡵࡩ࡫ࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ࠯ࡶࡪࡪࡩࡳࡧࡦࡸࡤ࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠯ࠫࡈࡵ࡯࡬࡫ࡨࠫ࠿࠭ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅ࠿ࠪ࠯ࡕࡎࡐࡔࡇࡖࡗࡎࡊࡽࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡶࡦࡴ࡬ࡪࡾࡥ࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ࠮ࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡥࡩࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡡࡥࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡤࡨࡤࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࠤࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡧࡤࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨࠫࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡨࡴ࡯ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡨ࡮ࡹࡰ࡭ࡣࡼ࠾ࠥࡴ࡯࡯ࡧ࠾ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷ࡡ࠰࡞࠭ࠪ࠳ࠬࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠬࡘࡥࡧࡧࡵࡩࡷ࠭࠺ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡧ࠴ࡣࡪ࡯ࡤࡺ࡮ࡪࡳ࠯࡮࡬ࡺࡪ࠵ࠧࡾࠌࠌࠦࠧࠨᝐ")
	l1l1lll_l1_ = url+l1111_l1_ (u"ࠬࡽࡡࡵࡥ࡫࡭ࡳ࡭࠯ࠨᝑ")
	#server = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪᝒ"))
	#l1l1lll11_l1_ = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᝓ"):None,l1111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ᝔"):server}
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭᝕"),l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ᝖"),l1111_l1_ (u"ࠫࠬ᝗"),l1111_l1_ (u"ࠬ࠭᝘"),l1111_l1_ (u"࠭ࠧ᝙"),l1111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ᝚"))
	l11llll1_l1_ = response.content
	#l1l1lll_l1_ = l1ll1l1ll1_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧ᝛"))
	#l11llll1_l1_ = l1ll1l1l11_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭᝜"),l1l1lll_l1_,l1111_l1_ (u"ࠪࠫ᝝"),l1111_l1_ (u"ࠫࠬ᝞"),l1111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠻ࡺࡨࠨ᝟"))
	#if l11llll1_l1_ and kodi_version>18.99: l11llll1_l1_ = l11llll1_l1_.decode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᝠ"))
	l11lll1l_l1_ = []
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᝡ"),l11llll1_l1_,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᝢ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = title.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬᝣ"),l1111_l1_ (u"ࠪࠫᝤ")).strip(l1111_l1_ (u"ࠫࠥ࠭ᝥ"))
			l11l1111_l1_ = re.findall(l1111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ᝦ"),title,re.DOTALL)
			if l11l1111_l1_:
				l11l1111_l1_ = l1111_l1_ (u"࠭࡟ࡠࡡࡢࠫᝧ")+l11l1111_l1_[0]
				#title = l1111_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᝨ")
				title = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠨࡰࡤࡱࡪ࠭ᝩ"))
			else: l11l1111_l1_ = l1111_l1_ (u"ࠩࠪᝪ")
			l1lllll1ll_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᝫ")+title+l1111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᝬ")+l11l1111_l1_
			l11lll1l_l1_.append(l1lllll1ll_l1_)
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᝭"),l11llll1_l1_,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		# l11l1l11l_l1_ l11ll1l1l_l1_ l11l1ll1_l1_
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"࠭ࠨ࠰࠱࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬᝮ"),block,re.DOTALL)
		for l1l111l_l1_ in l11l1ll1_l1_:
			l1l111l_l1_ = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᝯ")+l1l111l_l1_
			title = l1l1lll1l_l1_(l1l111l_l1_,l1111_l1_ (u"ࠨࡰࡤࡱࡪ࠭ᝰ"))
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᝱")+title+l1111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫᝲ")
			l11lll1l_l1_.append(l1l111l_l1_)
		# l1ll1l1l1l_l1_ l11ll1l1l_l1_ l11l1ll1_l1_
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠫࡦࡰࡡࡹ࡞ࠫࡿࡺࡸ࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᝳ"),l11llll1_l1_,re.DOTALL)
		if l11l1ll1_l1_:
			items = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡳࡪࡥࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ᝴"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1111_l1_ (u"࠭࡜࡯ࠩ᝵"),l1111_l1_ (u"ࠧࠨ᝶")).strip(l1111_l1_ (u"ࠨࠢࠪ᝷"))
				title = title.replace(l1111_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫ᝸"),l1111_l1_ (u"ࠪࡇ࡮ࡳࡡࡏࡱࡺࠫ᝹"))
				l1l111l_l1_ = l11l1ll1_l1_[0]+l1111_l1_ (u"ࠫࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡷࡪࡶࡦ࡬ࠫ࡯࡮ࡥࡧࡻࡁࠬ᝺")+index+l1111_l1_ (u"ࠬࠬࡩࡥ࠿ࠪ᝻")+id+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ᝼")+title+l1111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ᝽")
				l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭᝾"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᝿"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫក"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬខ"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧគ"),l1111_l1_ (u"࠭ࠫࠨឃ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬង")+search
	l1l11l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨᲯ")
menu_name=l1111_l1_ (u"ࠨࡡࡈࡋࡉࡥࠧᲰ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ู่ࠩฬืูสࠩᲱ"),l1111_l1_ (u"ࠪหาีหࠡษ็ฬึอๅอࠩᲲ"),l1111_l1_ (u"ࠫฬำฯฬࠢส่ฬู๊ศสࠪᲳ"),l1111_l1_ (u"ࠬอไาศํื๏ฯࠧᲴ"),l1111_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬᲵ")]
def l1111ll_l1_(mode,url,text):
	if   mode==440: l11l_l1_ = l11l111_l1_()
	elif mode==441: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==442: l11l_l1_ = l1lllll_l1_(url)
	elif mode==443: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==449: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫᲶ"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩᲷ"),l1111_l1_ (u"ࠩࠪᲸ"),l1111_l1_ (u"ࠪࠫᲹ"),l1111_l1_ (u"ࠫࠬᲺ"),l1111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ᲻"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1ll11l_l1_,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ᲼"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲽ"),menu_name+l1111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᲾ"),l1111_l1_ (u"ࠩࠪᲿ"),449,l1111_l1_ (u"ࠪࠫ᳀"),l1111_l1_ (u"ࠫࠬ᳁"),l1111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᳂"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳃"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ᳄")+menu_name+l1111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ᳅"),l1ll11l_l1_,441)
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᳆"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᳇"),l1111_l1_ (u"ࠫࠬ᳈"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡣࡲ࡫࡮ࡶࡡࡵ࡭࡬࡮ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᳉"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᳊"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if title in l11ll11_l1_: continue
		if l1l111l_l1_==l1111_l1_ (u"ࠧࠤࠩ᳋"): continue
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳌"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭᳍")+menu_name+title,l1l111l_l1_,441)
	return
def l1l11l1_l1_(url,l111l1ll_l1_=l1111_l1_ (u"ࠪࠫ᳎")):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ᳏"),url,l1111_l1_ (u"ࠬ࠭᳐"),l1111_l1_ (u"࠭ࠧ᳑"),l1111_l1_ (u"ࠧࠨ᳒"),l1111_l1_ (u"ࠨࠩ᳓"),l1111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪ᳔ࠧ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ᳕ࠦࠬ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ᳖࠭ࠧ࠭"),block,re.DOTALL)
	for l1l111l_l1_,title,img in items:
		if l1111_l1_ (u"ࠬ࠵ࡵࡳ࡮࠲᳗ࠫ") in l1l111l_l1_: continue
		elif l1111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ᳘") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ᳙ࠧ"),menu_name+title,l1l111l_l1_,443,img)
		elif l1111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ᳚") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳛"),menu_name+title,l1l111l_l1_,443,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ᳜ࠩ"),menu_name+title,l1l111l_l1_,442,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ᳝࠭"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿᳞ࠫ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᳟࠭"),menu_name+l1111_l1_ (u"ࠧึใะอࠥ࠭᳠")+title,l1l111l_l1_,441)
	return
l1111_l1_ (u"ࠣࠤࠥࠎࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡷ࡫ࡧࡩࡴࡒࡉࡔࡖࠣࡁࠥࡡࠧๆึส๋ิฯࠧ࠭ࠩไ๎้๋ࠧ࠭ࠩส฾๋๐ษࠨ࠮ࠪ็้๐ศࠨ࠮ࠪห฾๊ว็ࠩ࠯ࠫ์ีวโࠩ࠯๊ࠫฮวาษฬࠫ࠱ู࠭าุࠪ࠰๋ࠬ็าฮส๊ࠬ࠲ࠧศๆห์๊࠭࡝ࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧ࠯࡭ࡲ࡭ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡵ࡯ࡧࡶࡧࡦࡶࡥࡉࡖࡐࡐ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡰ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧ࠰ࠩࠬࠎࠎࠏࡥࡱ࡫ࡶࡳࡩ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥࡧ࡮ࡺࠪࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࠣࡪࡴࡸࠠࡷࡣ࡯ࡹࡪࠦࡩ࡯ࠢࡹ࡭ࡩ࡫࡯ࡍࡋࡖࡘ࠮ࡀࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠷࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࡪࡶࡩࡴࡱࡧࡩࠥࡧ࡮ࡥࠢࠪห้ำไใหࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡥࡍࡐࡆࡢࠫࠥ࠱ࠠࡦࡲ࡬ࡷࡴࡪࡥ࡜࠲ࡠࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࠢࡱࡳࡹࠦࡩ࡯ࠢࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠿ࠐࠉࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠊࠋࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡢࡵࡶࡩࡲࡨ࡬ࡺ࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠷ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠷࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠳࠭࡫ࡰ࡫࠮ࠐࠉࡪࡨࠣࡷࡪࡷࡵࡦࡰࡦࡩࡂࡃࠧࠨ࠼ࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ᳡")
def l1l11ll_l1_(url):
	data = {l1111_l1_ (u"࡙ࠩ࡭ࡪࡽ᳢ࠧ"):1}
	headers = {l1111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦ᳣ࠩ"):l1111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ᳤ࠪ")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡖࡏࡔࡖ᳥ࠪ"),url,data,headers,l1111_l1_ (u"᳦࠭ࠧ"),l1111_l1_ (u"ࠧࠨ᳧"),l1111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ᳨"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᳩ"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᳪ"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᳫ"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳬ"),menu_name+title,l1l111l_l1_,443,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		img = re.findall(l1111_l1_ (u"࠭ࠢࡰࡩ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁ᳭ࠬࠦࠬ"),html,re.DOTALL)
		img = img[0]
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᳮ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = title.replace(l1111_l1_ (u"ࠨ࡞ࡱࠫᳯ"),l1111_l1_ (u"ࠩࠪᳰ")).strip(l1111_l1_ (u"ࠪࠤࠬᳱ"))
			l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᳲ"),menu_name+title,l1l111l_l1_,442,img)
	return
def l1lllll_l1_(url):
	data = {l1111_l1_ (u"ࠬ࡜ࡩࡦࡹࠪᳳ"):1}
	headers = {l1111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ᳴"):l1111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ᳵ")}
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᳶ"),url,data,headers,l1111_l1_ (u"ࠩࠪ᳷"),l1111_l1_ (u"ࠪࠫ᳸"),l1111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ᳹"))
	html = response.content
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᳺ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ᳻"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = title.replace(l1111_l1_ (u"ࠧ࡝ࡰࠪ᳼"),l1111_l1_ (u"ࠨࠩ᳽")).strip(l1111_l1_ (u"ࠩࠣࠫ᳾"))
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᳿")+title+l1111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᴀ")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᴁ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴂ"),block,re.DOTALL)
		for title,l11l1111_l1_,l1l111l_l1_ in items:
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠧ࡝ࡰࠪᴃ"),l1111_l1_ (u"ࠨࠩᴄ"))
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᴅ")+title+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᴆ")+l1111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩᴇ")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᴈ"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᴉ"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠧࠨᴊ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠨࠩᴋ"): return
	search = search.replace(l1111_l1_ (u"ࠩࠣࠫᴌ"),l1111_l1_ (u"ࠪ࠯ࠬᴍ"))
	#search = l1l1111_l1_(search)
	url = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩᴎ")+search
	l1l11l1_l1_(url)
	return
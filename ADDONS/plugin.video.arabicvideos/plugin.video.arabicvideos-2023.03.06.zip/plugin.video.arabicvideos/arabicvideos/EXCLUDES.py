# -*- coding: utf-8 -*-

import xbmc,re,os,sys,time,xbmcvfs
import arabic_reshaper,bidi.algorithm
from PIL import Image,ImageFont,ImageDraw

kodi_release = xbmc.getInfoLabel("System.BuildVersion")
kodi_version = re.findall('^(.*?)[ -]',kodi_release+' ',re.DOTALL)
kodi_version = float(kodi_version[0])

if kodi_version>18.99:
	xbmcfolder = xbmcvfs.translatePath('special://xbmc')
	cachefolder = xbmcvfs.translatePath('special://temp')
else:
	xbmcfolder = xbmc.translatePath('special://xbmc')
	cachefolder = xbmc.translatePath('special://temp')

addon_id = sys.argv[0].split('/')[2]	# plugin.video.arabicvideos
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
fontfile = os.path.join(xbmcfolder,'media','Fonts','arial.ttf')
addoncachefolder = os.path.join(cachefolder,addon_id)
dialogimagefile = os.path.join(addoncachefolder,'dialog_0000_.png')

kodi_release = xbmc.getInfoLabel("System.BuildVersion")
kodi_version = re.findall('^(.*?)[ -]',kodi_release+' ',re.DOTALL)
kodi_version = float(kodi_version[0])

if kodi_version>18.99:
	from urllib.parse import quote as _quote
	from urllib.parse import unquote as _unquote
else:
	from urllib import quote as _quote
	from urllib import unquote as _unquote

def QUOTE(url,exceptions=':/'):
	return _quote(url,exceptions)
	#return urllib2.quote(url,exceptions)

def UNQUOTE(url):
	return _unquote(url)
	#return urllib2.unquote(url)

def PROGRESS_UPDATE(pDialog,percentage,line1='',line2='',line3=''):
	if kodi_version<19: pDialog.update(percentage,line1,line2,line3)
	else: pDialog.update(percentage,line1+'\n'+line2+'\n'+line3)
	return

def READ_ALL_IPTV_LINES(lines,live_epg_channels,live_archived_channels,pDialog,length,jj):
	streams,ignored_streams = [],[]
	vod_types = ['.avi','.mp4','.mkv','.flv','.mp3','.webm']
	for line in lines:
		if jj%473==0:
			PROGRESS_UPDATE(pDialog,40+int(10*jj/length),'قراءة الفيديوهات','الفيديو رقم:-',str(jj)+' / '+str(length))
			if pDialog.iscanceled(): return None,None,None
		if 'http:' in line:
			line,url = line.rsplit('http:',1)
			url = 'http:'+url
		elif 'https:' in line:
			line,url = line.rsplit('https:',1)
			url = 'https:'+url
		elif 'rtmp:' in line:
			line,url = line.rsplit('rtmp:',1)
			url = 'rtmp:'+url
		else:
			ignored_streams.append({'line':line})
			continue
		dict1,context,group,title,type,is_vod_url = {},'','','','',False
		try:
			line,title = line.rsplit('",',1)
			line = line+'"'
		except:
			try: line,title = line.rsplit('1,',1)
			except: title = ''
		dict1['url'] = url
		params = re.findall(' (.*?)="(.*?)"',line,re.DOTALL)
		for key,value in params:
			key = key.replace('"','').strip(' ')
			dict1[key] = value.strip(' ')
		if not title:
			if 'name' in list(dict1.keys()) and dict1['name']: title = dict1['name']
		dict1['title'] = title.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in list(dict1.keys()):
			dict1['img'] = dict1['logo']
			del dict1['logo']
		else: dict1['img'] = ''
		if 'group' in list(dict1.keys()) and dict1['group']: group = dict1['group']
		if any(value in url.lower() for value in vod_types): is_vod_url = True
		if is_vod_url or '__SERIES__' in group or '__MOVIES__' in group:
			type = 'VOD'
			if '__SERIES__' in group: type = type+'_SERIES'
			elif '__MOVIES__' in group: type = type+'_MOVIES'
			else: type = type+'_UNKNOWN'
			group = group.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			type = 'LIVE'
			if title in live_epg_channels: context = context+'_EPG'
			if title in live_archived_channels: context = context+'_ARCHIVED'
			if not group: type = type+'_UNKNOWN'
			else: type = type+context
		group = group.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in type: group = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in type: group = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in type:
			series_title = re.findall('(.*?) [Ss]\d+ +[Ee]\d+',dict1['title'],re.DOTALL)
			if series_title: series_title = series_title[0]
			else: series_title = '!!__UNKNOWN_SERIES__!!'
			group = group+'__SERIES__'+series_title
		if 'id' in list(dict1.keys()): del dict1['id']
		if 'ID' in list(dict1.keys()): del dict1['ID']
		if 'name' in list(dict1.keys()): del dict1['name']
		title = dict1['title']
		#if '\\u' in title.lower(): title = title.decode('unicode_escape')
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		country,title = SPLIT_NAME(title)
		dict1['type'] = type
		dict1['context'] = context
		dict1['group'] = group.upper()
		dict1['title'] = title.upper()
		dict1['country'] = country.upper()
		dict1['language'] = language.upper()
		streams.append(dict1)
		jj += 1
	return streams,jj,ignored_streams

def SPLIT_NAME(title):
	if len(title)<3: return title,title
	lang,sep = '',''
	title2 = title
	first = title[:1]
	rest = title[1:]
	if   first=='(': sep = ')'
	elif first=='[': sep = ']'
	elif first=='<': sep = '>'
	elif first=='|': sep = '|'
	if sep and (sep in rest):
		part1,part2 = rest.split(sep,1)
		lang = part1
		title2 = first+part1+sep+' '+part2
	elif title.count('|')>=2:
		part1,part2 = title.split('|',1)
		lang = part1
		title2 = part1+' |'+part2
	else:
		sep = re.findall('^\w{2}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if not sep: sep = re.findall('^\w{3}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if not sep: sep = re.findall('^\w{4}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if sep:
			part1,part2 = title.split(sep[0],1)
			lang = part1
			title2 = part1+' '+sep[0]+' '+part2
	title2 = title2.replace('   ',' ').replace('  ',' ')
	lang = lang.replace('  ',' ')
	if lang=='': lang = '!!__UNKNOWN__!!'
	lang = lang.strip(' ')
	title2 = title2.strip(' ')
	return lang,title2

def CLEAN_NAME(title):
	title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	title = title.replace('||','|').replace('___',':').replace('--','-')
	title = title.replace('[[','[').replace(']]',']')
	title = title.replace('((','(').replace('))',')')
	title = title.replace('<<','<').replace('>>','>')
	#title = title.strip(' ').strip('|').strip('-').strip(':').strip('(').strip('[')
	title = title.strip(' ')
	return title

def CREATE_IPTV_GROUPED_STREAMS(streams_not_sorted,pDialog,ALL_TYPES):
	grouped_streams = {}
	for type1 in ALL_TYPES: grouped_streams[type1] = []
	length = len(streams_not_sorted)
	text3 = str(length)
	jj = 0
	ignored_streams = []
	for dict1 in streams_not_sorted:
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,50+int(5*jj/length),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(jj)+' / '+text3)
			if pDialog.iscanceled(): return None,None
		group,context,title,url,img = dict1['group'],dict1['context'],dict1['title'],dict1['url'],dict1['img']
		country,language,type1 = dict1['country'],dict1['language'],dict1['type']
		tuple2 = (group,context,title,url,img)
		fail = False
		if 'LIVE' in type1:
			if 'UNKNOWN' in type1: grouped_streams['LIVE_UNKNOWN_GROUPED'].append(tuple2)
			elif 'LIVE' in type1: grouped_streams['LIVE_GROUPED'].append(tuple2)
			else: fail = True
			grouped_streams['LIVE_ORIGINAL_GROUPED'].append(tuple2)
		elif 'VOD' in type1:
			if 'UNKNOWN' in type1: grouped_streams['VOD_UNKNOWN_GROUPED'].append(tuple2)
			elif 'MOVIES' in type1: grouped_streams['VOD_MOVIES_GROUPED'].append(tuple2)
			elif 'SERIES' in type1: grouped_streams['VOD_SERIES_GROUPED'].append(tuple2)
			else: fail = True
			grouped_streams['VOD_ORIGINAL_GROUPED'].append(tuple2)
		else: fail = True
		if fail: ignored_streams.append(dict1)
		jj += 1
	streams_sorted = sorted(streams_not_sorted,reverse=False,key=lambda key: key['title'].lower())
	del streams_not_sorted
	text3 = str(length)
	jj = 0
	for dict1 in streams_sorted:
		jj += 1
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,55+int(5*jj/length),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(jj)+' / '+text3)
			if pDialog.iscanceled(): return None,None
		type1 = dict1['type']
		group,context,title,url,img = dict1['group'],dict1['context'],dict1['title'],dict1['url'],dict1['img']
		country,language = dict1['country'],dict1['language']
		tuple1 = (group,context+'_TIMESHIFT',title,url,img)
		tuple2 = (group,context,title,url,img)
		tuple3 = (country,context,title,url,img)
		tuple4 = (language,context,title,url,img)
		if 'LIVE' in type1:
			if 'UNKNOWN' in type1: grouped_streams['LIVE_UNKNOWN_GROUPED_SORTED'].append(tuple2)
			else: grouped_streams['LIVE_GROUPED_SORTED'].append(tuple2)
			if 'EPG'		in type1: grouped_streams['LIVE_EPG_GROUPED_SORTED'].append(tuple2)
			if 'ARCHIVED'	in type1: grouped_streams['LIVE_ARCHIVED_GROUPED_SORTED'].append(tuple2)
			if 'ARCHIVED'	in type1: grouped_streams['LIVE_TIMESHIFT_GROUPED_SORTED'].append(tuple1)
			grouped_streams['LIVE_FROM_NAME_SORTED'].append(tuple3)
			grouped_streams['LIVE_FROM_GROUP_SORTED'].append(tuple4)
		elif 'VOD' in type1:
			if   'UNKNOWN'	in type1: grouped_streams['VOD_UNKNOWN_GROUPED_SORTED'].append(tuple2)
			elif 'MOVIES'	in type1: grouped_streams['VOD_MOVIES_GROUPED_SORTED'].append(tuple2)
			elif 'SERIES'	in type1: grouped_streams['VOD_SERIES_GROUPED_SORTED'].append(tuple2)
			grouped_streams['VOD_FROM_NAME_SORTED'].append(tuple3)
			grouped_streams['VOD_FROM_GROUP_SORTED'].append(tuple4)
	return grouped_streams,ignored_streams

def IPTV_ITEMS(TYPE,GROUP,PAGE,READ_FROM_SQL3,isIPTVFiles,menuItemsLIST,GET_DBFILE_NAME):
	if PAGE=='': PAGE = '1'
	menu_name = '_IPT_'
	if not isIPTVFiles(True): return None
	iptv_dbfile = GET_DBFILE_NAME(TYPE)
	streams = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_'+TYPE,GROUP)
	end = int(PAGE)*100
	start = end-100
	for context,title,url,img in streams[start:end]:
		cond1 = ('GROUPED' in TYPE or TYPE=='ALL')
		cond2 = ('GROUPED' not in TYPE and TYPE!='ALL')
		if cond1 or cond2:
			if   'ARCHIVED'  in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','ARCHIVED','',''])
			elif 'EPG' 		 in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','FULL_EPG','',''])
			elif 'TIMESHIFT' in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','TIMESHIFT','',''])
			elif 'LIVE' 	 in TYPE: menuItemsLIST.append(['live',menu_name+title,url,235,img,'','',context,''])
			else: menuItemsLIST.append(['video',menu_name+title,url,235,img,'','','',''])
	return len(streams)

def GET_ALL_KODI_MENU_ITEMS(menuItemsLIST,half_triangular_colon,FAVOURITES_FILE_DICT,MENUS__LAST_VIDEOS_MENU,xbmcgui,xbmcplugin,addon_id,addon_handle,defaulticon,defaultthumb,defaultfanart,TRANSLATE,HOUR,READ_FROM_SQL3,cache_dbfile,ltr,rtl):
	KodiMenuList = []
	for menuItem in menuItemsLIST:
		type_,name,url,mode,image,text1,text2,context,infodict = menuItem
		mode = int(mode)
		datetime = re.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',name,re.DOTALL)
		if datetime:
			datetime,date,time = datetime[0]
			name = name.replace(datetime,'')
			#name2 = RESTORE_PATH_NAME(ltr,rtl,name)
		# name & name2 needed for integration of last_videos & favorites & watched_status
		name2 = name
		site = re.findall('^_(\w\w\w)_(.*?)$',name,re.DOTALL)
		if site:
			site,name = site[0]
			modified = '_MOD_' in name
			folder = type_=='folder'
			if modified and folder: start = ';'
			elif modified and not folder: start = half_triangular_colon
			elif not modified and folder: start = ','
			elif not modified and not folder: start = ' '
			name = name.replace('_MOD_','')
			site = start+'[COLOR FFC89008]'+site+' [/COLOR]'
		else: site = ''
		if datetime:
			if kodi_version<19:
				datetime = '[COLOR FFFFFF00]'+date+' '+time+'[/COLOR]'
				if site: name = datetime+' '+site+ltr+name
				else: name = datetime+rtl+name+' '
			elif kodi_version>18.99:
				if site:
					datetime = '[COLOR FFFFFF00]'+date+' '+time+'[/COLOR]'
					name = datetime+' '+site+name
				else:
					datetime = '[COLOR FFFFFF00]'+time+' '+date+'[/COLOR]'
					name = name+' '+rtl+datetime
		elif site:
			"""
			site = site[0][0]
			name = name[5:]
			if name.startswith('_MOD_'):
				start = start1
				name = name[5:]
			else: start = start2
			words = name.split(' ')
			name,added = '',False
			for word in words:
				if word: arb = re.findall('[ء-ي]',word[0],re.DOTALL)
				else: arb = []
				if arb and not added:
					name += rtl+word+' '
					added = True
				else:
					name += word+' '
					added = False
			name = name[:-1]
			#if kodi_version<19: name = rtl+name
			name01 = 'test this - new hello'
			name02 = 'new hello - مرحبا بكم'
			name03 = 'فحص جديد - play here'
			name04 = 'برمجة صعبة - مزعجة ايضا'
			"""
			#english_to_arabic = re.findall('[^\xc1-\xed ] +[\xc1-\xed]',name,re.DOTALL)
			#english_to_arabic = re.findall('[^ء-ي] +[ء-ي]',name,re.DOTALL)
			#special_last_letter = re.findall('[ -~]$',name,re.DOTALL)
			#english_last_letter = re.findall('[a-zA-Z0-9]$',name,re.DOTALL)
			#if special_last_letter: special_last_letter = re.findall('\W',special_last_letter[0],re.DOTALL)
			#special_last_letter = re.findall('[\!\&\^\(\)\_\-\+\=\@\#\$\%\?\.\,\;\:]$',name,re.DOTALL)
			#name = 'A '+name
			#for change in set(changes):
			#	name = name.replace(change,change[:-1]+rtl+change[-1])
			#name = name[2:]
			name = name.replace('بحث IPTV ',rtl+'بحث IPTV '+rtl)
			special_first_letter = re.findall('^[ -~]',name,re.DOTALL)
			if kodi_version<19:
				if special_first_letter: name = site+ltr+name
				else: name = site+name
			elif kodi_version>18.99:
				if special_first_letter: name = site+name
				else: name = site+rtl+name
		listitem = xbmcgui.ListItem(name)
		menuItem = (type_,name2,url,str(mode),image,'',text2,context,'')
		newpath_dict = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
		newpath_dict['name'] = QUOTE(name2)
		newpath_dict['type'] = type_.strip(' ')
		newpath_dict['mode'] = str(mode).strip(' ')
		if type_=='folder' and text1: newpath_dict['page'] = QUOTE(text1.strip(' '))
		if context: newpath_dict['context'] = context.strip(' ')
		if text2: newpath_dict['text'] = QUOTE(text2.strip(' '))
		if infodict:
			infodict = str(infodict)
			newpath_dict['infodict'] = QUOTE(infodict.strip(' '))
			infodict = eval(infodict)
		else: infodict = {}
		if 'plot' in list(infodict.keys()): listitem.setInfo('video',{'PlotOutline':infodict['plot'],'Plot':infodict['plot']})
		if 'stars' in list(infodict.keys()): listitem.setInfo('video',{'Rating':infodict['stars']})
		if image:
			#listitem.setArt({'thumb':image,'poster':image,'banner':image,'fanart':image,'clearart':image,'clearlogo':image,'landscape':image,'icon':image})
			listitem.setArt({'icon':image,'thumb':image,'fanart':image})
			newpath_dict['image'] = QUOTE(image.strip(' '))
		else:
			#size = 10
			#intro,site,title = '','',name
			#if kodi_version<19: title = title.decode('utf8')
			#tmp = re.findall('^(.*?\[COLOR FFC89008\]).*?([A-Z0-9]{3}).*?\[/COLOR\](.*?)$',title,re.DOTALL)
			#if tmp: intro,site,title = tmp[0]
			#if ' ' not in title: title += ' '
			#if title.index(' ')>=3*size: title = title[:size]+' '+title[size:2*size]+' '+title[2*size:3*size]+' '+title[3*size:]
			#elif title.index(' ')>=2*size: title = title[:size]+' '+title[size:2*size]+' '+title[2*size:]
			#elif title.index(' ')>=size: title = title[:size]+' '+title[size:]
			#if site: title = intro+site+'[/COLOR]\n'+title
			listitem.setInfo('video',{'Title':name})
			listitem.setArt({'icon':defaulticon,'thumb':defaultthumb,'fanart':defaultfanart})
		#listitem.setInfo(type='video',infoLabels={'Title':name})
		if url: newpath_dict['url'] = QUOTE(url.strip(' '))
		context_menu = []
		newpath = 'plugin://'+addon_id+'/?type='+newpath_dict['type']+'&mode='+newpath_dict['mode']
		if newpath_dict['page']: newpath += '&page='+newpath_dict['page']
		if newpath_dict['name']: newpath += '&name='+newpath_dict['name']
		if newpath_dict['text']: newpath += '&text='+newpath_dict['text']
		if newpath_dict['infodict']: newpath += '&infodict='+newpath_dict['infodict']
		if newpath_dict['image']: newpath += '&image='+newpath_dict['image']
		if newpath_dict['url']: newpath += '&url='+newpath_dict['url']
		if mode!=265: context_menu += GET_FAVOURITES_CONTEXT_MENU(FAVOURITES_FILE_DICT,menuItem,newpath,ltr,rtl)
		if newpath_dict['context']: newpath += '&context='+newpath_dict['context']
		if mode in [235,238] and type_=='live' and 'EPG' in context:
			run_path = 'plugin://'+addon_id+'?mode=238&text=SHORT_EPG&url='+url
			run_text = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if mode==265:
			length = MENUS__LAST_VIDEOS_MENU(text2,True)
			if length>0:
				run_path = 'plugin://'+addon_id+'?mode=266&text='+text2
				run_text = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+TRANSLATE(text2)+'[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		if type_=='video' and mode!=331:
			run_path = newpath+'&context=6_DOWNLOAD'
			run_text = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if mode==331:
			run_path = newpath+'&context=6_DELETE'
			run_text = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if type_=='folder' and mode==540:
			all_words = READ_FROM_SQL3(cache_dbfile,'list','GLOBALSEARCH_SITES')
			if all_words:
				run_path = 'plugin://'+addon_id+'?context=7'
				run_text = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		MAIN_MENU_MODES = [9990,7,100,151,159,165,176,196,199,230,261,263,264,265,267,268,270,290,330,341,346,348,501,505,510,540]
		if mode not in MAIN_MENU_MODES:
			run_path = 'plugin://'+addon_id+'?context=8&mode=260'
			run_text = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		NON_SITES_MENUS = [0,150,160,170,190,260,280,330,340,410,500,520,530,560]
		if mode%10 and mode!=9990:
			site_mode = mode-mode%10
			if site_mode==280: site_mode = 230  # IPTV
			if site_mode==410: site_mode = 400  # DAILYMOTION
			if site_mode==520: site_mode = 510  # ELCINEMA
			if site_mode not in NON_SITES_MENUS:
				run_path = 'plugin://'+addon_id+'?context=8&mode='+str(site_mode)
				run_text = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		#if type_=='folder' and site_mode not in NON_SITES_MENUS and (mode%10)!=9:
		#if site_mode not in NON_SITES_MENUS:
		run_path = newpath+'&context=9'
		run_text = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
		run_item = (run_text,'RunPlugin('+run_path+')')
		context_menu.append(run_item)
		listitem.addContextMenuItems(context_menu)
		if type_ in ['link','video','live']: isFolder = False
		elif type_=='folder': isFolder = True
		if type_=='video':
			listitem.setInfo('video',{'mediatype':'movie'})
			if text1:
				duration = re.findall('[\d:]+',text1,re.DOTALL)
				if duration:
					duration = '0:0:0:0:0:'+duration[0]
					dummy,days,hours,minutes,seconds = duration.rsplit(':',4)
					duration2 = int(days)*24*HOUR+int(hours)*HOUR+int(minutes)*60+int(seconds)
					listitem.setInfo('video',{'duration':duration2})
			listitem.setProperty('IsPlayable','true')
			xbmcplugin.setContent(addon_handle,'movies')
		#listitem.setInfo(type='video',infoLabels={'Title':name})
		#xbmcplugin.addDirectoryItem(handle=addon_handle,url=newpath,listitem=listitem,isFolder=isFolder)
		KodiMenuList.append((newpath,listitem,isFolder))
	return KodiMenuList

"""
def RESTORE_PATH_NAME(ltr,rtl,name):
	start,site,modified = '','',''
	name = name.replace(ltr,'').replace(rtl,'')
	tmp = re.findall('(.)\[COLOR FFC89008\](\w\w\w) +\[\/COLOR\](.*?)$',name,re.DOTALL)
	if tmp: start,site,name = tmp[0]
	if start not in [' ',',','']: modified = '_MOD_'
	if site: site = '_'+site+'_'
	#datetime = re.findall('(_\d\d\.\d\d_\d\d\:\d\d_)',name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],'')
	name = site+modified+name
	return name
"""

def GET_FAVOURITES_CONTEXT_MENU(FAVOURITES_FILE_DICT,menuItem,kodipath,ltr,rtl):
	type,name,url,mode,image,page,text,context,infodict = menuItem
	if not mode: type,mode = 'folder','260'
	contextMenu,favouriteID = [],''
	favouritesDICT = FAVOURITES_FILE_DICT
	if 'context=' in addon_path:
		tmp = re.findall('context=(\d+)',addon_path,re.DOTALL)
		if tmp: favouriteID = str(tmp[0])
	if mode=='270':
		favouriteID = context
		if favouriteID in list(favouritesDICT.keys()): # and len(favouritesDICT[context])>0:
			contextMenu.append(('مسح قائمة مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_DELETELIST'+')'))
	else:
		if favouriteID in list(favouritesDICT.keys()):
			count = len(favouritesDICT[favouriteID])
			if count>1: contextMenu.append(('تحريك 1 للأعلى','RunPlugin('+kodipath+'&context='+favouriteID+'_UP1)'))
			if count>4: contextMenu.append(('تحريك 4 للأعلى','RunPlugin('+kodipath+'&context='+favouriteID+'_UP4)'))
			if count>1: contextMenu.append(('تحريك 1 للأسفل','RunPlugin('+kodipath+'&context='+favouriteID+'_DOWN1)'))
			if count>4: contextMenu.append(('تحريك 4 للأسفل','RunPlugin('+kodipath+'&context='+favouriteID+'_DOWN4)'))
		for favouriteID in ['1','2','3','4','5']:
			if favouriteID in list(favouritesDICT.keys()) and menuItem in favouritesDICT[favouriteID]:
				contextMenu.append(('مسح من مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_REMOVE1)'))
			else: contextMenu.append(('إضافة إلى مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_ADD1)'))
	contextMenuNEW = []
	for i1,i2 in contextMenu:
		i1 = '[COLOR FFFFFF00]'+i1+'[/COLOR]'
		contextMenuNEW.append((i1,i2,))
	return contextMenuNEW

def REMOVE_TAGS(word):
	if '[' in word and ']' in word:
		tags = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		colors1 = re.findall('\[COLOR .*?\]',word,re.DOTALL)
		colors2 = re.findall('\[COLOR###.*?\]',word,re.DOTALL)
		all_tags = tags+colors1+colors2
		for tag in all_tags: word = word.replace(tag,'')
	return word

def WRAP_THIS_TEXT(oldtext,fontfile,fontsize,max_dialog_width,line_height):
	newtext,total_height,max_height = '',0,15000
	oldtext = oldtext.replace('[COLOR ','[COLOR###')
	textfont = ImageFont.truetype(fontfile,size=fontsize)
	txt = Image.new('RGBA',(max_dialog_width,99),(255,255,255,0))
	writing = ImageDraw.Draw(txt)
	# needed to decrease width by approximately two letters
	max_dialog_width -= fontsize
	for oldline in oldtext.splitlines():
		total_height += line_height
		newline_width,newline = 0,''
		for word in oldline.split(' '):
			word_notags = REMOVE_TAGS(' '+word)
			word_width,word_height = writing.textsize(word_notags,font=textfont)
			if newline_width+word_width<max_dialog_width:
				if not newline: newline += word
				else: newline += ' '+word
				newline_width += word_width
			else:
				if word_width<max_dialog_width:
					newline += '\n '+word
					total_height += line_height
					newline_width = word_width
				else:
					while word_width>=max_dialog_width:
						for ii in range(1,len(' '+word),1):
							before = ' '+word[:ii]
							after = word[ii:]
							before_notags = REMOVE_TAGS(before)
							before_width,before_height = writing.textsize(before_notags,font=textfont)
							if newline_width+before_width>=max_dialog_width:
								after_width = word_width-before_width
								newline += before+'\n'
								total_height += line_height
								word_width = after_width
								if after_width>=max_dialog_width:
									newline_width = 0
									word = after
								else:
									newline_width = after_width
									newline += after
								break
				if total_height>max_height: break
		newtext += '\n'+newline
		if total_height>max_height: break
	newtext = newtext[1:]
	newtext = newtext.replace('[COLOR###','[COLOR ')
	return newtext

def FORMAT_IMAGE_TEXT(text):
	text = text.replace('\n','_sss__newline_')
	text = text.replace('[RTL]','_sss__linertl_')
	text = text.replace('[LEFT]','_sss__lineleft_')
	text = text.replace('[RIGHT]','_sss__lineright_')
	text = text.replace('[CENTER]','_sss__linecenter_')
	text = text.replace('[/COLOR]','_sss__endcolor_')
	colors = re.findall('\[COLOR (.*?)\]',text,re.DOTALL)
	for color in colors: text = text.replace('[COLOR '+color+']','_sss__newcolor'+color+'_')
	#LOG_THIS('',text.encode('utf8'))
	#LOG_THIS('',newtext_notags.encode('utf8'))
	#LOG_THIS('',newtext_tags.encode('utf8'))
	return text

def CREATE_IMAGE(button0,button1,button2,header,text,profile,text_direction,image_width,enable_progressbar):
	#text_direction = 'right'
	#text = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ  الصِّيَامَ إِلَى اللَّيْلِ لا تلمني لله الحمد محمد رسول الله صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ"
	#header = "السلام عليكم هذه الأسطر للتجربة"
	#header = 'عربي'
	#text = 'عربي'
	#button0,button1,button2 = 'عربي 0','عربي 1','عربي 2'
	#text = "السلام عليكم Alsalam Alekum الله اكبر ولله الحمد هذه الأسطر للتجربة"
	#header = 'This is a test text test text in English 12345 123456'
	#text = 'This is a test text test text in English 12345 123456'
	#header = header.strip('\n')
	#text = '[RTL]white1[COLOR FFC89008]orange new line\nnew line[/COLOR]white2 new line\nnew line white3[COLOR FFFFFF00]yellow[/COLOR]white4\n[COLOR FFC89008]\n===================[/COLOR]\nwhite5'
	#text = '[RTL]ابيض [COLOR FFC89008]برتقالي سطر جديد\n[RTL] سطر جديد[/COLOR]ابيض سطر جديد\n[RTL]سطر جديد ابيض[COLOR FFFFFF00]اصفر[/COLOR]ابيض\n[RTL][COLOR FFC89008]\n===================[/COLOR]\n[RTL]ابيض'
	#text = '[RTL][COLOR FFFFFF00]السؤال : [/COLOR]'+'ابيض اهلا وسهلا ومرحبا والسلام عليكم هذه لفحص البرنامج وتقطيع الكتابة احتاج تجربة سطر طويل أو طويل جدا\n'+'هذه مختلفة عن البقية'
	#text = '[RTL]this[COLOR FFFFFF00] line is rtl\nthis line is[/COLOR] regular'
	#text = 'ابيض  برتقالي سطر جديد \n سطر جديد ابيض سطر جديد\nسطر جديد ابيض[COLOR FFFFFF00]اصفر[/COLOR]ابيض\n[COLOR FFC89008]\n===================[/COLOR]\nابيض'
	#text_direction = 'right'
	#text = 'AA default AA\nBB default BB\n[LEFT]CC left CC\n[RIGHT]DD right DD\n[CENTER]FF center FF\nGGGG'
	#text = '[COLOR FFFFFF00]\n'+'line1'+'[/COLOR]\n'+'line2\n============'
	#text = '--------\n[COLOR FFC89008]\n=================\n+++++++++'
	#text = 'Hello World this is to test text wrapping It might be Wrong'
	#text = 'Hello World this is to test text wrapping It might be Wrong'
	#text = '     Hello     World     this     \n     test     text     wrapping     now     '
	#text = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z '
	#text = text+text+text+'\n'+text
	#text = text+' '+text
	#text = 'ImportError: No module named urllib3.util.connection\ntesting'
	"""
	text = text+'\n1====1'
	text = text+'\n2====2'
	text = text+'\n3====3'
	text = text+'\n4====4'
	text = text+'\n5====5'
	text = text+'\n6====6'
	text = text+'\n7====7'
	text = text+'\n8====8'
	text = text+'\n9====9'
	text = text+'\n0====0'
	text = text+'\n1====1'
	text = text+'\n2====2'
	"""
	#text = "السلام عليكم هذه لفحص البرنامج وتقطيع الكتابة احتاج تجربة سطر طويل أو طويل"
	#text = text+text+text+text+text+text+text+text+text+text
	#button1 = 'hello\r\n'
	#header = 'السلام عليكم هذه لفحص'
	#text = 'السلام عليكم هذه لفحص'
	#header = header+'\n'+header
	#button0 = button1 = button2 = '12345678901234'
	#button0 = button1 = button2 = ''
	#image_height = 435
	#button1 = ''
	#  jpg => "RGB"		png => "RGBA"
	#  "white"	  (33,55,77)	'#808080'
	#img = Image.open(emptyimagefile).convert("RGBA")
	#img = img.resize((image_width,image_height))
	#profile = 'confirm_smallfont'
	#LOG_THIS('',text)
	if kodi_version<19:
		# kodi 18 should use decode
		# kodi 19 should not use any decode or encode
		# otherwise all the arabic drawing addons will not work
		text = text.decode('utf8')
		header = header.decode('utf8')
		button0 = button0.decode('utf8')
		button1 = button1.decode('utf8')
		button2 = button2.decode('utf8')
	header_posx = 5
	header_upper_margin = 20
	header_sides_margin = 20
	header_lines_spacing = 0
	header_direction = 'center'
	text_posx = 0
	text_upper_margin = 19
	text_sides_margin = 30
	text_lines_spacing = 8
	text_wrap = True
	progressbar_posy = 375
	buttons_posy = 410
	buttons_height = 50
	buttons_width = 280
	buttons_text_posx = 28
	buttons_spacing = 5
	bottom_upper_margin = 0
	bottom_lower_margin = 31
	font_size = [36,32,28]
	if profile in ['notification','notification_twohalfs']:
		if profile=='notification_twohalfs':
			dialog_height = 'UPPER'
			header_direction = 'right'
			text_wrap = True
			header_lines_spacing = 10
		else:
			dialog_height = 97+20
			header_direction = 'left'
			text_wrap = False
		font_size = [33,33,33]
		header_sides_margin = 20
		header_upper_margin = 0
		text_sides_margin = 20
		text_upper_margin = 25+10
	elif profile=='confirm_bigfont': dialog_height = 500
	elif profile=='confirm_smallfont': font_size = [28,23,18] ; dialog_height = 500
	elif profile=='textview_bigfont': dialog_height = 740
	elif profile=='textview_bigfont_long': dialog_height = 'UPPER'
	elif profile=='textview_smallfont': font_size = [28,23,18] ; dialog_height = 740
	elif profile=='textview_smallfont_long': font_size = [28,23,18] ; dialog_height = 'UPPER'
	header_fontsize = font_size[0]
	text_fontsize = font_size[1]
	buttons_fontsize = font_size[2]
	header_font = ImageFont.truetype(fontfile,size=header_fontsize)
	text_font = ImageFont.truetype(fontfile,size=text_fontsize)
	buttons_font = ImageFont.truetype(fontfile,size=buttons_fontsize)
	txt = Image.new('RGBA',(100,100),(255,255,255,0))
	writing = ImageDraw.Draw(txt)
	text_line_width,text_line_height = writing.textsize('HHH BBB 888 000',font=text_font)
	header_line_width,header_line_height = writing.textsize('HHH BBB 888 000',font=header_font)
	header_lines_count = header.count('\n')+1
	header_total_height = header_upper_margin+header_lines_count*(header_line_height+header_lines_spacing)-header_lines_spacing
	arabic_config = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	reshaper = arabic_reshaper.ArabicReshaper(configuration=arabic_config)
	if text:
		text_max_width = image_width-text_sides_margin*2
		text_line_height_with_spacing = text_line_height+text_lines_spacing
		textreshaped = reshaper.reshape(text)
		if text_wrap:
			text_with_tags = WRAP_THIS_TEXT(textreshaped,fontfile,text_fontsize,text_max_width,text_line_height_with_spacing)
			text_with_notags = REMOVE_TAGS(text_with_tags)
			text_lines_count = text_with_notags.count('\n')+1
			if text_lines_count<6:
				if text_lines_count<4: new_text_max_width = int(0.8*text_max_width)
				else: new_text_max_width = int(0.9*text_max_width)
				text_with_tags = WRAP_THIS_TEXT(textreshaped,fontfile,text_fontsize,new_text_max_width,text_line_height_with_spacing)
				text_with_notags = REMOVE_TAGS(text_with_tags)
				text_lines_count = text_with_notags.count('\n')+1
			text_total_height = text_upper_margin+text_lines_count*text_line_height_with_spacing-text_lines_spacing
		else:
			text_total_height = text_upper_margin+text_line_height
			text_with_notags = textreshaped.split('\n')[0]
			text_with_tags = textreshaped.split('\n')[0]
	else: text_total_height = text_upper_margin
	bottom_total_height = bottom_upper_margin+bottom_lower_margin
	if enable_progressbar:
		progressbar_with_spacing_height = buttons_posy-progressbar_posy
		bottom_total_height += progressbar_with_spacing_height
	else: progressbar_with_spacing_height = 0
	if button0 or button1 or button2: bottom_total_height += buttons_height
	if dialog_height!='UPPER': image_height = dialog_height
	else: image_height = header_total_height+text_total_height+bottom_total_height
	text_available_height = image_height-header_total_height-bottom_total_height-text_upper_margin
	txt = Image.new('RGBA',(image_width,image_height),(255,255,255,0))
	writing = ImageDraw.Draw(txt)
	if not button1 and button0 and button2:
		buttons_text_posx += 105
		buttons_spacing -= 110
	if header:
		header_posy = header_upper_margin
		header = bidi.algorithm.get_display(reshaper.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,height = writing.textsize(line,font=header_font)
				if header_direction=='center': header_posx2 = header_posx+(image_width-width)/2
				elif header_direction=='right': header_posx2 = header_posx+image_width-width-header_sides_margin
				elif header_direction=='left': header_posx2 = header_posx+header_sides_margin
				writing.text((header_posx2,header_posy),line,font=header_font,fill='yellow')#, spacing=5, align="right")
			header_posy += header_fontsize+header_lines_spacing
	if button0 or button1 or button2:
		#buttons_text_posy = (buttons_height-buttons_fontsize)/2
		buttons_text_posy = header_total_height+text_available_height+text_upper_margin+progressbar_with_spacing_height+bottom_upper_margin
		if button0:
			button0 = bidi.algorithm.get_display(reshaper.reshape(button0))
			button0_width,button0_height = writing.textsize(button0,font=buttons_font)
			button0_text_posx = buttons_text_posx+0*(buttons_spacing+buttons_width)+(buttons_width-button0_width)/2
			writing.text((button0_text_posx,buttons_text_posy),button0,font=buttons_font,fill='yellow')#, spacing=5, align="right")
		if button1:
			button1 = bidi.algorithm.get_display(reshaper.reshape(button1))
			button1_width,button1_height = writing.textsize(button1,font=buttons_font)
			button1_text_posx = buttons_text_posx+1*(buttons_spacing+buttons_width)+(buttons_width-button1_width)/2
			writing.text((button1_text_posx,buttons_text_posy),button1,font=buttons_font,fill='yellow')#, spacing=5, align="right")
		if button2:
			button2 = bidi.algorithm.get_display(reshaper.reshape(button2))
			button2_width,button2_height = writing.textsize(button2,font=buttons_font)
			button2_text_posx = buttons_text_posx+2*(buttons_spacing+buttons_width)+(buttons_width-button2_width)/2
			writing.text((button2_text_posx,buttons_text_posy),button2,font=buttons_font,fill='yellow')#, spacing=5, align="right")
	if text:
		lines_posx,lines_width = [],[]
		text_with_tags = FORMAT_IMAGE_TEXT(text_with_tags)
		splitted_lines = text_with_tags.split('_sss__newline_')
		for line_and_styles in splitted_lines:
			line_direction = text_direction
			if   '_sss__lineleft_' in line_and_styles: line_direction = 'left'
			elif '_sss__lineright_' in line_and_styles: line_direction = 'right'
			elif '_sss__linecenter_' in line_and_styles: line_direction = 'center'
			line_no_styles = line_and_styles
			tags = re.findall('_sss__.*?_',line_and_styles,re.DOTALL)
			for tag in tags: line_no_styles = line_no_styles.replace(tag,'')
			if line_no_styles=='': width,height = 0,text_line_height_with_spacing
			else: width,height = writing.textsize(line_no_styles,font=text_font)
			if   line_direction=='left': text_posx2 = text_posx+text_sides_margin
			elif line_direction=='right': text_posx2 = text_posx+text_sides_margin+text_max_width-width
			elif line_direction=='center': text_posx2 = text_posx+text_sides_margin+(text_max_width-width)/2
			if text_posx2<text_sides_margin: text_posx2 = text_posx+text_sides_margin
			lines_posx.append(text_posx2)
			lines_width.append(width)
		text_posx2 = lines_posx[0]
		splitted_text = text_with_tags.split('_sss_')
		default_color = (255,255,255,255)
		color3 = default_color
		add_to_posx1,add_to_posy = 0,0
		text_rtl = False
		line_seq = 0
		text_posy = header_total_height+text_upper_margin/2
		if text_total_height<(text_available_height+text_upper_margin):
			text_half_height = (text_available_height+text_upper_margin-text_total_height)/2
			text_posy = header_total_height+text_upper_margin+text_half_height-text_line_height/2
		"""
		LOG_THIS('','image_height: '+str(image_height))
		LOG_THIS('','header_upper_margin: '+str(header_upper_margin))
		LOG_THIS('','header_total_height: '+str(header_total_height))
		LOG_THIS('','text_upper_margin: '+str(text_upper_margin))
		LOG_THIS('','text_total_height: '+str(text_total_height))
		LOG_THIS('','text_posy: '+str(text_posy))
		LOG_THIS('','text_available_height: '+str(text_available_height))
		LOG_THIS('','bottom_upper_margin: '+str(bottom_upper_margin))
		LOG_THIS('','progressbar_with_spacing_height: '+str(progressbar_with_spacing_height))
		LOG_THIS('','buttons_text_posy: '+str(buttons_text_posy))
		LOG_THIS('','bottom_lower_margin: '+str(bottom_lower_margin))
		LOG_THIS('','bottom_total_height: '+str(bottom_total_height))
		"""
		for line in splitted_text:
			if not line or (line and ord(line[0])==65279): continue
			style1 = line.split('_newline_',1)
			style2 = line.split('_newcolor',1)
			style3 = line.split('_endcolor_',1)
			style4 = line.split('_linertl_',1)
			style5 = line.split('_lineleft_',1)
			style6 = line.split('_lineright_',1)
			style7 = line.split('_linecenter_',1)
			if len(style1)>1:
				line_seq += 1
				line = style1[1]
				add_to_posx1 = 0
				text_posx2 = lines_posx[line_seq]
				add_to_posy += text_line_height_with_spacing
				text_rtl = False
			elif len(style2)>1:
				line = style2[1]
				color3 = line[0:8]
				color3 = '#'+color3[2:]#+color3[:2]
				line = line[9:]
			elif len(style3)>1:
				line = style3[1]
				color3 = default_color
			elif len(style4)>1:
				line = style4[1]
				text_rtl = True
				add_to_posx1 = lines_width[line_seq]
			elif len(style5)>1:
				line = style5[1]
			elif len(style6)>1:
				line = style6[1]
			elif len(style7)>1:
				line = style7[1]
			if line:
				text_posy2 = text_posy+add_to_posy
				line = bidi.algorithm.get_display(line)
				width,height = writing.textsize(line,font=text_font)
				if text_rtl: add_to_posx1 -= width
				text_posx3 = text_posx2+add_to_posx1
				writing.text((text_posx3,text_posy2),line,font=text_font,fill=color3)
				if not text_rtl: add_to_posx1 += width
				if text_posy2>text_available_height+text_line_height_with_spacing: break
	#combined = Image.alpha_composite(img,txt)
	#combined.save(readyimagefile)
	#txt = txt.resize((image_width,image_height),Image.ANTIALIAS)
	#txt.show()
	image_filename = dialogimagefile.replace('_0000_','_'+str(time.time())+'_')
	image_filename = image_filename.replace('\\','\\\\').replace('//','////')
	txt.save(image_filename)
	#time.sleep(0.100)
	return image_filename,image_height

def escapeUNICODE(string2):
	if kodi_version<19 and '\\u' in string2:
		string2 = string2.decode('unicode_escape')
		string2 = string2.encode('utf8')
	return string2




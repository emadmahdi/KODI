# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫᇧ")
menu_name=l1111_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬᇨ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
headers = {l1111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᇩ"):l1111_l1_ (u"ࠨࠩᇪ")}
l11ll11_l1_ = [l1111_l1_ (u"ࠩสๅ้อๅࠡๆ็็ออัࠨᇫ"),l1111_l1_ (u"ࠪฬ่ืวࠡࡖ࡙ࠫᇬ")]
def l1111ll_l1_(mode,url,text):
	if   mode==370: l11l_l1_ = l11l111_l1_()
	elif mode==371: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==372: l11l_l1_ = l1lllll_l1_(url)
	elif mode==373: l11l_l1_ = l11lll1l1_l1_(url)
	elif mode==374: l11l_l1_ = l1111ll11_l1_(url)
	elif mode==375: l11l_l1_ = l1111l111_l1_(url)
	elif mode==376: l11l_l1_ = l1111l11l_l1_(url)
	elif mode==379: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᇭ"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭ᇮ"),l1111_l1_ (u"࠭ࠧᇯ"),l1111_l1_ (u"ࠧࠨᇰ"),l1111_l1_ (u"ࠨࠩᇱ"),l1111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᇲ"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᇳ"),menu_name+l1111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᇴ"),l1111_l1_ (u"ࠬ࠭ᇵ"),379,l1111_l1_ (u"࠭ࠧᇶ"),l1111_l1_ (u"ࠧࠨᇷ"),l1111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᇸ"))
	l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᇹ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᇺ"),l1111_l1_ (u"ࠫࠬᇻ"),9999)
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡸࡩࡨࡪࡷ࠱ࡸ࡯ࡤࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᇼ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᇽ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇾ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬᇿ")+menu_name+title,l1l111l_l1_,371)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩሀ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧሁ")+menu_name+l1111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅฯฬสีฮ࠭ሂ"),l1ll11l_l1_,375)
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬሃ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪሄ")+menu_name+l1111_l1_ (u"๋ࠧึส๋ิࠦวๅษ้ࠫህ"),l1ll11l_l1_,376)
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨሆ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ሇ")+menu_name+l1111_l1_ (u"ࠪๆฬฬๅสࠢส่๊๎โฺࠩለ"),l1ll11l_l1_,373)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሉ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩሊ")+menu_name+l1111_l1_ (u"࠭โศศ่อࠥอไๆ็ฮ่๏์ࠧላ"),l1ll11l_l1_,374)
	return
def l11lll1l1_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠧࠨሌ")):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬል"),l1ll11l_l1_,l1111_l1_ (u"ࠩࠪሎ"),l1111_l1_ (u"ࠪࠫሏ"),l1111_l1_ (u"ࠫࠬሐ"),l1111_l1_ (u"ࠬ࠭ሑ"),l1111_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪሒ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪࡶࡲࡴ࠲ࡳࡥ࡯ࡷࠪሓ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧሔ"),block,re.DOTALL)
		for l1l111l_l1_,title in items[7:]:
			title = title.strip(l1111_l1_ (u"ࠩࠣࠫሕ"))
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪሖ"),l1l1lll1_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨሗ")+menu_name+title,l1l111l_l1_,371)
		for l1l111l_l1_,title in items[0:7]:
			title = title.strip(l1111_l1_ (u"ࠬࠦࠧመ"))
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ሙ"),l1l1lll1_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫሚ")+menu_name+title,l1l111l_l1_,371)
	return html
def l1111ll11_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠨࠩማ")):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭ሜ"),l1ll11l_l1_,l1111_l1_ (u"ࠪࠫም"),l1111_l1_ (u"ࠫࠬሞ"),l1111_l1_ (u"ࠬ࠭ሟ"),l1111_l1_ (u"࠭ࠧሠ"),l1111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡁࡄࡖࡒࡖࡘࡓࡅࡏࡗ࠰࠵ࡸࡺࠧሡ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡲࡻࠥࡩࡡࡵࠢࡗࡥ࡬ࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬሢ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨሣ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨሤ") in l1l111l_l1_: continue
			else: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሥ"),l1l1lll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩሦ")+menu_name+title,l1l111l_l1_,371)
	return
def l1111l111_l1_(l1l1lll1_l1_=l1111_l1_ (u"࠭ࠧሧ")):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫረ"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩሩ"),l1111_l1_ (u"ࠩࠪሪ"),l1111_l1_ (u"ࠪࠫራ"),l1111_l1_ (u"ࠫࠬሬ"),l1111_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡕࡓࡕࡘࡌࡉ࡜࡙࠭࠲ࡵࡷࠫር"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡴࡢࡤ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡲࡻࠬሮ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሯ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧሰ"),l1l1lll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ሱ")+menu_name+title,l1l111l_l1_,372)
	return
def l1111l11l_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠪࠫሲ")):
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨሳ"),l1ll11l_l1_,l1111_l1_ (u"ࠬ࠭ሴ"),l1111_l1_ (u"࠭ࠧስ"),l1111_l1_ (u"ࠧࠨሶ"),l1111_l1_ (u"ࠨࠩሷ"),l1111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮࡙ࡄࡘࡈࡎࡉࡏࡉࡑࡓ࡜࠳࠱ࡴࡶࠪሸ"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡶ࡬ࡸࡱ࡫࠲ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸ࡯ࡸࠩሹ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬሺ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if not any(value in title for value in l11ll11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫሻ"),l1l1lll1_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪሼ")+menu_name+title,l1l111l_l1_,372)
	return
def l1l11l1_l1_(url,type1=l1111_l1_ (u"ࠧࠨሽ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩሾ"),l1111_l1_ (u"ࠩࠪሿ"),l1111_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪቀ"),url)
	#LOG_THIS(l1111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫቁ"),html)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩቂ"),url,l1111_l1_ (u"࠭ࠧቃ"),l1111_l1_ (u"ࠧࠨቄ"),l1111_l1_ (u"ࠨࠩቅ"),l1111_l1_ (u"ࠩࠪቆ"),l1111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ቇ"))
	html = response.content
	if l1111_l1_ (u"ࠫࡻ࡯ࡤࡱࡣࡪࡩࡤ࠭ቈ") in url:
		l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡁ࡭ࡤࡸࡱ࠲࠴ࠪࡀࠫࠥࠫ቉"),html,re.DOTALL)
		if l1l111l_l1_:
			l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_[0]
			l1l11l1_l1_(l1l111l_l1_)
			return
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࠠࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡱࡩ࠳࠳ࠨቊ"),html,re.DOTALL)
	if type1==l1111_l1_ (u"ࠧࠨቋ") and l111l1l_l1_ and l111l1l_l1_[0].count(l1111_l1_ (u"ࠨࡪࡵࡩ࡫࠭ቌ"))>1:
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩቍ"),menu_name+l1111_l1_ (u"ࠪห้าๅ๋฻ࠪ቎"),url,371,l1111_l1_ (u"ࠫࠬ቏"),l1111_l1_ (u"ࠬ࠭ቐ"),l1111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡸ࠭ቑ"))
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ቒ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࠪቓ")+l1l111l_l1_
			title = title.strip(l1111_l1_ (u"ࠩࠣࠫቔ"))
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪቕ"),menu_name+title,l1l111l_l1_,371)
	else:
		l1lllll1_l1_ = []
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭ቖ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠾ࠢࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡻࡷ࠲࠷࠲ࠨ቗"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽ࠩቘ"),block,re.DOTALL)
			l1111_l1_ (u"ࠢࠣࠤࠍࠍࠎࠏࡩࡵࡧࡰࡷ࠷ࠦ࠽ࠡ࡝ࡠࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮࡬ࡱ࡬࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡺࡲࡺ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࡮ࡴࡴࠩࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭วๅฯ็ๆฮࠦࠫࠩ࡞ࡧ࠯࠮࠭ࠬࡵ࡫ࡷࡰࡪ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࡞࠴ࡢ࠯ࠊࠊࠋࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡩ࡯ࡶࡰࡷࠤࡂࠦ࠭࠲ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷ࠷࠴ࡡࡱࡲࡨࡲࡩ࠮ࠨ࡭࡫ࡱ࡯࠱࡯࡭ࡨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡥࡲࡹࡳࡺࠩࠪࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡩࡵࡧࡰࡷ࠷࠲ࠠࡳࡧࡹࡩࡷࡹࡥ࠾ࡈࡤࡰࡸ࡫ࠬࠡ࡭ࡨࡽࡂࡲࡡ࡮ࡤࡧࡥࠥࡱࡥࡺ࠼ࠣ࡯ࡪࡿ࡛࠴࡟ࠬࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮࡬ࡱ࡬࠲ࡴࡪࡶ࡯ࡩ࠱ࡩ࡯ࡶࡰࡷࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠦࠧࠨ቙")
			for l1l111l_l1_,img,title in items:
				#img = l1ll11l_l1_+img
				l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
				title = title.strip(l1111_l1_ (u"ࠨࠢࠪቚ"))
				if l1111_l1_ (u"ࠩ࠲ࡥࡱࡥࠧቛ") in l1l111l_l1_:
					l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪቜ"),menu_name+title,l1l111l_l1_,371,img)
				elif l1111_l1_ (u"ࠫฬ๊อๅไฬࠫቝ") in title and (l1111_l1_ (u"ࠬ࠵ࡃࡢࡶ࠰ࠫ቞") in url or l1111_l1_ (u"࠭࠯ࡔࡧࡤࡶࡨ࡮࠯ࠨ቟") in url):
					l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦ࠭ࠡ࠭ส่า๊โสࠢ࠮ࡠࡩ࠱ࠧበ"),title,re.DOTALL)
					if l11l11l_l1_: title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭ቡ")+l11l11l_l1_[0]
					if title not in l1lllll1_l1_:
						l1lllll1_l1_.append(title)
						l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩቢ"),menu_name+title,l1l111l_l1_,371,img)
				else: l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩባ"),menu_name+title,l1l111l_l1_,372,img)
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬቤ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨብ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
				title = l1111_l1_ (u"࠭ีโฯฬࠤࠬቦ")+l1l1111_l1_(title)
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧቧ"),menu_name+title,l1l111l_l1_,371,l1111_l1_ (u"ࠨࠩቨ"),l1111_l1_ (u"ࠩࠪቩ"),l1111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡵࠪቪ"))
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨቫ"),url,l1111_l1_ (u"ࠬ࠭ቬ"),l1111_l1_ (u"࠭ࠧቭ"),l1111_l1_ (u"ࠧࠨቮ"),l1111_l1_ (u"ࠨࠩቯ"),l1111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪተ"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠪࡰࡦࡨࡥ࡭࠯ࡶࡹࡨࡩࡥࡴࡵࠣࡱࡷ࡭࠭ࡣࡶࡰ࠱࠺ࠦࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨቱ"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	l11l11_l1_ = l1111_l1_ (u"ࠫࠬቲ")
	l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬࡼࡡࡳࠢࡸࡶࡱࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩታ"),html,re.DOTALL)
	if l1l1lll_l1_: l1l1lll_l1_ = l1l1lll_l1_[0]
	else: l1l1lll_l1_ = url.replace(l1111_l1_ (u"࠭࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠࠩቴ"),l1111_l1_ (u"ࠧ࠰ࡒ࡯ࡥࡾ࠵ࠧት"))
	if l1111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ቶ") not in l1l1lll_l1_: l1l1lll_l1_ = l1ll11l_l1_+l1l1lll_l1_
	l1l1lll_l1_ = l1l1lll_l1_.strip(l1111_l1_ (u"ࠩ࠰ࠫቷ"))
	response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧቸ"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬቹ"),l1111_l1_ (u"ࠬ࠭ቺ"),l1111_l1_ (u"࠭ࠧቻ"),l1111_l1_ (u"ࠧࠨቼ"),l1111_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩች"))
	l11llll1_l1_ = response.content
	l11l11_l1_ = re.findall(l1111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧቾ"),l11llll1_l1_,re.DOTALL)
	if l11l11_l1_:
		l11l11_l1_ = l11l11_l1_[-1]
		if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨቿ") not in l11l11_l1_: l11l11_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪኀ")+l11l11_l1_
		if l1111_l1_ (u"ࠬ࠵ࡐࡍࡃ࡜࠳ࠬኁ") not in l1l1lll_l1_:
			if l1111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠳ࡳࡩ࡯࠰࡭ࡷࠬኂ") in l11l11_l1_:
				l1111l1l1_l1_ = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡲ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ኃ"),l11llll1_l1_,re.DOTALL)
				if l1111l1l1_l1_:
					l11111lll_l1_, l1111l1ll_l1_ = l1111l1l1_l1_[0]
					l11l11_l1_ = l1l1lll1l_l1_(l11l11_l1_,l1111_l1_ (u"ࠨࡷࡵࡰࠬኄ"))+l1111_l1_ (u"ࠩ࠲ࡺ࠷࠵ࠧኅ")+l11111lll_l1_+l1111_l1_ (u"ࠪ࠳ࡨࡵ࡮ࡧ࡫ࡪ࠳ࠬኆ")+l1111l1ll_l1_+l1111_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪኇ")
		import ll_l1_
		ll_l1_.l11_l1_([l11l11_l1_],l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫኈ"))
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"࠭ࠧ኉"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠧࠨኊ"): return
	search = search.replace(l1111_l1_ (u"ࠨࠢࠪኋ"),l1111_l1_ (u"ࠩ࠮ࠫኌ"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡘ࡫ࡡࡳࡥ࡫࠳ࠬኍ")+search
	l1l11l1_l1_(url)
	return
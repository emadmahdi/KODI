# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_ = l1111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ౗")
menu_name=l1111_l1_ (u"ࠪࡣࡋ࡚ࡍࡠࠩౘ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l1ll1l111_l1_ = [l1111_l1_ (u"ࠫ࠶࠸࠳࠺ࠩౙ"),l1111_l1_ (u"ࠬ࠷࠲࠶࠲ࠪౚ"),l1111_l1_ (u"࠭࠱࠳࠶࠸ࠫ౛"),l1111_l1_ (u"ࠧ࠳࠲ࠪ౜"),l1111_l1_ (u"ࠨ࠳࠵࠹࠾࠭ౝ"),l1111_l1_ (u"ࠩ࠵࠵࠽࠭౞"),l1111_l1_ (u"ࠪ࠸࠽࠻ࠧ౟"),l1111_l1_ (u"ࠫ࠶࠸࠳࠹ࠩౠ"),l1111_l1_ (u"ࠬ࠷࠲࠶࠺ࠪౡ"),l1111_l1_ (u"࠭࠲࠺࠴ࠪౢ")]
l1ll11lll_l1_ = [l1111_l1_ (u"ࠧ࠴࠲࠶࠴ࠬౣ"),l1111_l1_ (u"ࠨ࠸࠵࠼ࠬ౤")]
def l1111ll_l1_(mode,url,text):
	if   mode==60: l11l_l1_ = l11l111_l1_()
	elif mode==61: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==62: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==63: l11l_l1_ = l1lllll_l1_(url)
	elif mode==64: l11l_l1_ = l1ll1l11l_l1_(text)
	elif mode==69: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౥"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ౦"),l1111_l1_ (u"ࠫࠬ౧"),69,l1111_l1_ (u"ࠬ࠭౨"),l1111_l1_ (u"࠭ࠧ౩"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ౪"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ౫"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭౬")+menu_name+l1111_l1_ (u"้ࠪฬ๊ࠦห็ู้ࠣอ็ะฬ๊ࠤฬ๊ว็ࠩ౭"),l1ll11l_l1_,64,l1111_l1_ (u"ࠫࠬ౮"),l1111_l1_ (u"ࠬ࠭౯"),l1111_l1_ (u"࠭ࡲࡦࡥࡨࡲࡹࡥࡶࡪࡧࡺࡩࡩࡥࡶࡪࡦࡶࠫ౰"))
	l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౱"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ౲")+menu_name+l1111_l1_ (u"ࠩส่ฬ้หาุ่ࠢฬํฯสࠩ౳"),l1ll11l_l1_,64,l1111_l1_ (u"ࠪࠫ౴"),l1111_l1_ (u"ࠫࠬ౵"),l1111_l1_ (u"ࠬࡳ࡯ࡴࡶࡢࡺ࡮࡫ࡷࡦࡦࡢࡺ࡮ࡪࡳࠨ౶"))
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౷"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ౸")+menu_name+l1111_l1_ (u"ࠨษู๎ๆะࠠๆฦัีฬ࠭౹"),l1ll11l_l1_,64,l1111_l1_ (u"ࠩࠪ౺"),l1111_l1_ (u"ࠪࠫ౻"),l1111_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡰࡾࡥࡡࡥࡦࡨࡨࡤࡼࡩࡥࡵࠪ౼"))
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ౽"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ౾")+menu_name+l1111_l1_ (u"ࠧโ์า๎ํูࠦี๊สส๏࠭౿"),l1ll11l_l1_,64,l1111_l1_ (u"ࠨࠩಀ"),l1111_l1_ (u"ࠩࠪಁ"),l1111_l1_ (u"ࠪࡶࡦࡴࡤࡰ࡯ࡢࡺ࡮ࡪࡳࠨಂ"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫಃ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ಄")+menu_name+l1111_l1_ (u"࠭วโๆส้ࠥ๎ๅิๆึ่ฬะࠧಅ"),l1ll11l_l1_,61,l1111_l1_ (u"ࠧࠨಆ"),l1111_l1_ (u"ࠨࠩಇ"),l1111_l1_ (u"ࠩ࠰࠵ࠬಈ"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಉ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨಊ")+menu_name+l1111_l1_ (u"ࠬอไษำส้ัࠦวๅัํ๊๏ฯࠧಋ"),l1ll11l_l1_,61,l1111_l1_ (u"࠭ࠧಌ"),l1111_l1_ (u"ࠧࠨ಍"),l1111_l1_ (u"ࠨ࠯࠵ࠫಎ"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಏ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧಐ")+menu_name+l1111_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠥ࡜ࡩࡥࡧࡲࡷࠬ಑"),l1ll11l_l1_,61,l1111_l1_ (u"ࠬ࠭ಒ"),l1111_l1_ (u"࠭ࠧಓ"),l1111_l1_ (u"ࠧ࠮࠵ࠪಔ"))
	return l1111_l1_ (u"ࠨࠩಕ")
def l1l11l1_l1_(url,category):
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪಖ"),l1111_l1_ (u"ࠪࠫಗ"),l1111_l1_ (u"ࠫࠬಘ"), category)
	cat = l1111_l1_ (u"ࠬ࠭ಙ")
	if category not in [l1111_l1_ (u"࠭࠭࠲ࠩಚ"),l1111_l1_ (u"ࠧ࠮࠴ࠪಛ"),l1111_l1_ (u"ࠨ࠯࠶ࠫಜ")]: cat = l1111_l1_ (u"ࠩࡂࡧࡦࡺ࠽ࠨಝ")+category
	l1l1lll_l1_ = l1ll11l_l1_+l1111_l1_ (u"ࠪ࠳ࡲ࡫࡮ࡶࡡ࡯ࡩࡻ࡫࡬࠯ࡲ࡫ࡴࠬಞ")+cat
	html = l111l11_l1_(l1111l1_l1_,l1l1lll_l1_,l1111_l1_ (u"ࠫࠬಟ"),l1111_l1_ (u"ࠬ࠭ಠ"),l1111_l1_ (u"࠭ࠧಡ"),l1111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ಢ"))
	items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧಣ"),html,re.DOTALL)
	l1ll11l1l_l1_,l1ll1ll11_l1_ = False,False
	for l1l111l_l1_,title,count in items:
		title = l1l1111_l1_(title)
		title = title.strip(l1111_l1_ (u"ࠩࠣࠫತ"))
		if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨಥ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪದ")+l1l111l_l1_
		cat = re.findall(l1111_l1_ (u"ࠬࡩࡡࡵ࠿ࠫ࠲࠯ࡅࠩࠧࠩಧ"),l1l111l_l1_,re.DOTALL)[0]
		if category==cat: l1ll11l1l_l1_ = True
		elif l1ll11l1l_l1_ 	or (category==l1111_l1_ (u"࠭࠭࠲ࠩನ") and cat in l1ll1l111_l1_) \
						or (category==l1111_l1_ (u"ࠧ࠮࠴ࠪ಩") and cat not in l1ll11lll_l1_ and cat not in l1ll1l111_l1_) \
						or (category==l1111_l1_ (u"ࠨ࠯࠶ࠫಪ") and cat in l1ll11lll_l1_):
							if count==l1111_l1_ (u"ࠩ࠴ࠫಫ"): l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩಬ"),menu_name+title,l1l111l_l1_,63)
							else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫಭ"),menu_name+title,l1l111l_l1_,61,l1111_l1_ (u"ࠬ࠭ಮ"),l1111_l1_ (u"࠭ࠧಯ"),cat)
							l1ll1ll11_l1_ = True
	if not l1ll1ll11_l1_: l1l11ll_l1_(url)
	return
def l1l11ll_l1_(url):
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠧࠨರ"),l1111_l1_ (u"ࠨࠩಱ"),True,l1111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪಲ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫಳ"),l1111_l1_ (u"ࠫࠬ಴"),url , html)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠪವ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡧࡳ࡫ࡧࡣࡻ࡯ࡥࡸ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫಶ"),block,re.DOTALL)
	l1l111l_l1_ = l1111_l1_ (u"ࠧࠨಷ")
	for img,title,l1l111l_l1_ in items:
		title = title.replace(l1111_l1_ (u"ࠨࡃࡧࡨࠬಸ"),l1111_l1_ (u"ࠩࠪಹ")).replace(l1111_l1_ (u"ࠪࡸࡴࠦࡑࡶ࡫ࡦ࡯ࡱ࡯ࡳࡵࠩ಺"),l1111_l1_ (u"ࠫࠬ಻")).strip(l1111_l1_ (u"಼ࠬࠦࠧ"))
		if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫಽ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ಾ")+l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧಿ"),menu_name+title,l1l111l_l1_,63,img)
	l111l1l_l1_=re.findall(l1111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫೀ"),block,re.DOTALL)
	block=l111l1l_l1_[0]
	block=re.findall(l1111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫು"),html,re.DOTALL)[0]
	items=re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ೂ"),block,re.DOTALL)
	l1l1lll_l1_ = url.split(l1111_l1_ (u"ࠬࡅࠧೃ"))[0]
	for l1l111l_l1_,l1ll111ll_l1_ in items:
		l1l111l_l1_ = l1l1lll_l1_ + l1l111l_l1_
		title = l1l1111_l1_(l1ll111ll_l1_)
		title = l1111_l1_ (u"࠭ีโฯฬࠤࠬೄ") + title
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ೅"),menu_name+title,l1l111l_l1_,62)
	return l1l111l_l1_
def l1lllll_l1_(url):
	if l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬೆ") in url: url = l1l11ll_l1_(url)
	html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠩࠪೇ"),l1111_l1_ (u"ࠪࠫೈ"),True,l1111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ೉"))
	items = re.findall(l1111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬೊ"),html,re.DOTALL)
	url = items[0]
	if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫೋ") not in url: url = l1111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ೌ")+url
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ್ࠧ"))
	return
def l1ll1l11l_l1_(category):
	payload = { l1111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ೎") : category }
	url = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶ࠰ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࠪ೏")
	headers = { l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ೐") : l1111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ೑") }
	data = l1ll1l1l1_l1_(payload)
	html = l111l11_l1_(l1ll1llll_l1_,url,data,headers,True,l1111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡏࡒࡗ࡙࡙࠭࠲ࡵࡷࠫ೒"))
	items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦࠨ೓"),html,re.DOTALL)
	for l1l111l_l1_,title,img in items:
		title = title.strip(l1111_l1_ (u"ࠨࠢࠪ೔"))
		if l1111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧೕ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩೖ")+l1l111l_l1_
		l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ೗"),menu_name+title,l1l111l_l1_,63,img)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠬ࠭೘"): search = l11ll_l1_()
	if search==l1111_l1_ (u"࠭ࠧ೙"): return
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ೚"),l1111_l1_ (u"ࠨࠩ೛"),search, l1ll11l_l1_)
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"ࠩࠣࠫ೜"),l1111_l1_ (u"ࠪ࠯ࠬೝ"))
	url = l1ll11l_l1_ + l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡤࡸࡥࡴࡷ࡯ࡸ࠳ࡶࡨࡱࡁࡴࡹࡪࡸࡹ࠾ࠩೞ") + l1lll1l_l1_ # + l1111_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁ࠶࠭೟")
	l1l11ll_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ኎")
headers = {l1111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ኏"):l1111_l1_ (u"࠭ࠧነ")}
menu_name = l1111_l1_ (u"ࠧࡠࡅ࠷࡙ࡤ࠭ኑ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬኒ"),l1111_l1_ (u"ࠩสาึ๐ࠧና"),l1111_l1_ (u"ࠪหำื้ࠨኔ"),l1111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ን"),l1111_l1_ (u"ࠬฮฯ้่ࠣษำะ๊ศำࠪኖ"),l1111_l1_ (u"࠭วโๆส้ࠬኗ"),l1111_l1_ (u"ࠧๆี็ื้อสࠨኘ")]
def l1111ll_l1_(mode,url,text):
	if   mode==420: l11l_l1_ = l11l111_l1_()
	elif mode==421: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==422: l11l_l1_ = l1llll1111_l1_(url)
	elif mode==423: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==424: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧኙ")+text)
	elif mode==425: l11l_l1_ = l1llllll_l1_(url,l1111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨኚ")+text)
	elif mode==426: l11l_l1_ = l1lllll_l1_(url)
	elif mode==427: l11l_l1_ = l1llllllll_l1_(url)
	elif mode==429: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧኛ"),l1ll11l_l1_,l1111_l1_ (u"ࠫࠬኜ"),l1111_l1_ (u"ࠬ࠭ኝ"),l1111_l1_ (u"࠭ࠧኞ"),l1111_l1_ (u"ࠧࠨኟ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪአ"))
	html = response.content
	l1llll1lll_l1_ = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨኡ"),html,re.DOTALL)
	l1llll1lll_l1_ = l1llll1lll_l1_[0].strip(l1111_l1_ (u"ࠪ࠳ࠬኢ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1llll1lll_l1_,l1111_l1_ (u"ࠫࡺࡸ࡬ࠨኣ"))
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኤ"),menu_name+l1111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭እ"),l1111_l1_ (u"ࠧࠨኦ"),429,l1111_l1_ (u"ࠨࠩኧ"),l1111_l1_ (u"ࠩࠪከ"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧኩ"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫኪ"),menu_name+l1111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨካ"),l1llll1lll_l1_,425)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ኬ"),menu_name+l1111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪክ"),l1llll1lll_l1_,424)
	l1l1l_l1_(l1111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ኮ"),l1111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩኯ"),l1111_l1_ (u"ࠪࠫኰ"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ኱"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩኲ")+menu_name+l1111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨኳ"),l1llll1lll_l1_,421)
	#l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧኴ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬኵ")+menu_name+l1111_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨ኶"),l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶ࠳ࠬ኷"),421)
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫኸ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩኹ")+menu_name+l1111_l1_ (u"࠭ๆ๋ฬไู่่ࠧኺ"),l1llll1lll_l1_+l1111_l1_ (u"ࠧ࠰ࡰࡨࡸ࡫ࡲࡩࡹ࠱ࠪኻ"),421)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ኼ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬࡁࠬ࠳࠰࠿ࠪ࠾ࠪኽ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if title in l11ll11_l1_: continue
		if l1111_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫኾ") in l1l111l_l1_: title = l1111_l1_ (u"ࠫศ็ไศ็ࠣห้์ฬ้็ࠪ኿")
		elif l1111_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾࠧዀ") in l1l111l_l1_: title = l1111_l1_ (u"࠭รโๆส้ࠥ๎ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨ዁")
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዂ"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬዃ")+menu_name+title,l1l111l_l1_,421)
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዄ"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧዅ")+menu_name+l1111_l1_ (u"ࠫ็อฦๆหࠣฮๆ฻๊ๅ์ฬࠫ዆"),l1llll1lll_l1_,427)
	return
def l1llllllll_l1_(l1l1lll1_l1_=l1111_l1_ (u"ࠬ࠭዇")):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪወ"),l1ll11l_l1_,l1111_l1_ (u"ࠧࠨዉ"),l1111_l1_ (u"ࠨࠩዊ"),l1111_l1_ (u"ࠩࠪዋ"),l1111_l1_ (u"ࠪࠫዌ"),l1111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ው"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡕ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ዎ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪࠤ࠭ࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿ࠫዏ"),block,re.DOTALL)
	for category,id,l1l111l_l1_,title in items:
		if title in l11ll11_l1_: continue
		if l1111_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸ࠮࡯ࡲࡺ࡮࡫ࡳࠨዐ") in l1l111l_l1_: title = l1111_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨዑ")
		elif l1111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴ࠯ࡱࡩࡹ࡬࡬ࡪࡺࠪዒ") in l1l111l_l1_: title = l1111_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬዓ")
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዔ"),l1l1lll1_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩዕ")+menu_name+title,l1l111l_l1_,421,l1111_l1_ (u"࠭ࠧዖ"),l1111_l1_ (u"ࠧࠨ዗"),category+l1111_l1_ (u"ࠨࡾࠪዘ")+id)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠩࠪዙ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫዚ"),l1111_l1_ (u"ࠫࠬዛ"),l11111l1l_l1_,url)
	if l1111_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨዜ") in url: url = url.strip(l1111_l1_ (u"࠭࠯ࠨዝ"))+l1111_l1_ (u"ࠧ࠰࡯ࡳࡥࡦ࠵ࡦࡢ࡯࡬ࡰࡾ࠵ࠧዞ")
	items = []
	l1llll1lll_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠨࡷࡵࡰࠬዟ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭ዠ"),url,l1111_l1_ (u"ࠪࠫዡ"),headers,l1111_l1_ (u"ࠫࠬዢ"),l1111_l1_ (u"ࠬ࠭ዣ"),l1111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪዤ"))
	html = response.content
	if not l11111l1l_l1_ or l1111_l1_ (u"ࠧࡽࠩዥ") in l11111l1l_l1_:
		#if l1111_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠭ዦ") in html:
		#	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዧ"),menu_name+l1111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭የ"),url,425)
		#	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዩ"),menu_name+l1111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨዪ"),url,424)
		#	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫያ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧዬ"),l1111_l1_ (u"ࠨࠩይ"),9999)
		if l1111_l1_ (u"ࠩࡿࠫዮ") not in l11111l1l_l1_: l1lllllll1_l1_ = l1111_l1_ (u"ࠪࠫዯ")
		else: l1lllllll1_l1_ = l1111_l1_ (u"ࠫ࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠵ࠧደ")+l11111l1l_l1_
		l1llll111l_l1_ = False
		if l1111_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠨዱ") in html:
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዲ"),menu_name+l1111_l1_ (u"ࠧศๆ่้๏ุษࠨዳ"),url,421,l1111_l1_ (u"ࠨࠩዴ"),l1111_l1_ (u"ࠩࠪድ"),l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬዶ"))
			l1llll111l_l1_ = True
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩዷ"),html,re.DOTALL)
		if l111l1l_l1_:
			l111ll1l_l1_ = l111l1l_l1_[0]
			l11l1ll11_l1_ = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡨ࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫዸ"),l111ll1l_l1_,re.DOTALL)
			for l1llllll11_l1_,title2 in l11l1ll11_l1_:
				l1lllll1ll_l1_ = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡨ࡫࡮ࡵࡧࡵ࠳ࡦࡩࡴࡪࡱࡱ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴ࡺࡡࡣ࠱ࠪዹ")+l1llllll11_l1_+l1lllllll1_l1_+l1111_l1_ (u"ࠧ࠰ࠩዺ")
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨዻ"),menu_name+title2,l1lllll1ll_l1_,421)
				l1llll111l_l1_ = True
		if l1llll111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧዼ"),l1111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪዽ"),l1111_l1_ (u"ࠫࠬዾ"),9999)
	if l11111l1l_l1_==l1111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧዿ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶ࡮ࡷ࡭ࡋ࡯࡬ࡵࡧࡵࠫጀ"),html,re.DOTALL)
		if not l111l1l_l1_: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪጁ"),html,re.DOTALL)
		if l111l1l_l1_: block = l111l1l_l1_[0]
		else: block = l1111_l1_ (u"ࠨࠩጂ")
	elif l1111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬጃ") in url or l1111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡧࡪࡴࡴࡦࡴ࠲ࠫጄ") in url:
		block = html
	elif l1111_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ጅ") in url:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡖࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠫࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠰ࠧጆ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
	elif l1111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷࡹࠧጇ") in url:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࠭ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠫࠩገ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫጉ"),block,re.DOTALL)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡆ࡭ࡲࡧ࠴ࡶࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩጊ"),html,re.DOTALL)
		if l111l1l_l1_: block = l111l1l_l1_[0]
		else: block = l1111_l1_ (u"ࠪࠫጋ")
	if not items: items = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࠯ࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠭࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠲࠯ࡅࡂࡰࡺࡗ࡭ࡹࡲࡥࡊࡰࡩࡳ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬጌ"),block,re.DOTALL)
	if not items: items = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫግ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for l1l111l_l1_,img,title in items:
		if not title: continue
		if l1111_l1_ (u"࠭࠿࡯ࡧࡺࡷࡂ࠭ጎ") in l1l111l_l1_: continue
		title = title.replace(l1111_l1_ (u"ࠧๆึส๋ิฯࠠࠨጏ"),l1111_l1_ (u"ࠨࠩጐ"))
		title = l1l1111_l1_(title)
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ጑"),title,re.DOTALL)
		if l11l11l_l1_ and l1111_l1_ (u"ࠪั้่ษࠨጒ") in title:
			title = l1111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪጓ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬጔ"),menu_name+title,l1l111l_l1_,422,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧጕ") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ጖"),menu_name+title,l1l111l_l1_,421,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ጗"),menu_name+title,l1l111l_l1_,422,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩጘ"),html,re.DOTALL)
	if l111l1l_l1_ and l11111l1l_l1_!=l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬጙ"):
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࡠࠬࡢࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩ࡟ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ጚ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = l1l1111_l1_(title)
			title = title.replace(l1111_l1_ (u"ࠬอไึใะอࠥ࠭ጛ"),l1111_l1_ (u"࠭ࠧጜ"))
			if title!=l1111_l1_ (u"ࠧࠨጝ"): l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጞ"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨጟ")+title,l1l111l_l1_,421)
	l1111111l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀ࠴ࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ጠ"),html,re.DOTALL)
	if l1111111l_l1_:
		l1l111l_l1_,title = l1111111l_l1_[0]
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጡ"),menu_name+title,l1l111l_l1_,421)
	return
def l1llll1111_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩጢ"),url,l1111_l1_ (u"࠭ࠧጣ"),l1111_l1_ (u"ࠧࠨጤ"),l1111_l1_ (u"ࠨࠩጥ"),l1111_l1_ (u"ࠩࠪጦ"),l1111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨጧ"))
	html = response.content
	# l11ll1l1l_l1_/download main l11l1l1l_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡑࡳࡼࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨጨ"),html,re.DOTALL)
	if l111l1l_l1_:
		url = l111l1l_l1_[0]
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩጩ"),url,l1111_l1_ (u"࠭ࠧጪ"),l1111_l1_ (u"ࠧࠨጫ"),l1111_l1_ (u"ࠨࠩጬ"),l1111_l1_ (u"ࠩࠪጭ"),l1111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠷ࡴࡤࠨጮ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩጯ"),l1111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬጰ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡓࡦࡣࡶࡳࡳࡹࡓࡦࡥࡷ࡭ࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪጱ"),html,re.DOTALL)
	# l1llll11l1_l1_ l1llllll1l_l1_
	if l1111_l1_ (u"ࠧ࠰ࡶࡤ࡫࠴࠭ጲ") in url or l1111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࠨጳ") in url:
		l1l11l1_l1_(url)
	# l1llll1ll1_l1_
	elif l111l1l_l1_:
		img = xbmc.getInfoLabel(l1111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪጴ"))
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤጵ"),block,re.DOTALL)
		l1llll1l11_l1_ = [l1111_l1_ (u"ู๊ࠫไิๆࠪጶ"),l1111_l1_ (u"๋่ࠬิ็ࠪጷ"),l1111_l1_ (u"࠭ศา่ส้ั࠭ጸ"),l1111_l1_ (u"ࠧฮๆๅอࠬጹ")]
		for l1l111l_l1_,title in items:
			if any(value in title for value in l1llll1l11_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጺ"),menu_name+title,l1l111l_l1_,423,img)
			else: l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨጻ"),menu_name+title,l1l111l_l1_,426,img)
	else: l1l11ll_l1_(url)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧጼ"),url,l1111_l1_ (u"ࠫࠬጽ"),l1111_l1_ (u"ࠬ࠭ጾ"),l1111_l1_ (u"࠭ࠧጿ"),l1111_l1_ (u"ࠧࠨፀ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧፁ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧፂ"),l1111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪፃ"))
	img = re.findall(l1111_l1_ (u"ࠫࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧፄ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = l1111_l1_ (u"ࠬ࠭ፅ")
	# l1llll11_l1_
	l1l11ll1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡔࡧࡦࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫፆ"),html,re.DOTALL)
	if l1l11ll1l_l1_:
		block = l1l11ll1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫፇ"),block,re.DOTALL)
		for l1l111l_l1_,title,l11l11l_l1_ in items:
			title = title+l1111_l1_ (u"ࠨࠢࠪፈ")+l11l11l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨፉ"),menu_name+title,l1l111l_l1_,426,img)
	else: l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩፊ"),menu_name+l1111_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪፋ"),url,426,img)
	return
def l1lllll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩፌ"),url,l1111_l1_ (u"࠭ࠧፍ"),headers,l1111_l1_ (u"ࠧࠨፎ"),l1111_l1_ (u"ࠨࠩፏ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫፐ"))
	html = response.content
	#newurl = re.findall(l1111_l1_ (u"ࠪࠦࡸࡺࡹ࡭ࡧࡶ࡬ࡪ࡫ࡴࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪፑ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩፒ"))
	l1llll1lll_l1_ = l1l1lll1l_l1_(newurl,l1111_l1_ (u"ࠬࡻࡲ࡭ࠩፓ"))
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	#if kodi_version>18.99: html = html.decode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫፔ"),l1111_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧፕ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨ࡙ࡤࡸࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪፖ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠢࠡ࠱ࡁࠬ࠳࠰࠿ࠪ࠾ࠪፗ"),block,re.DOTALL)
		for l1l1111l_l1_,title in items:
			title = title.strip(l1111_l1_ (u"ࠪࠤࠬፘ"))
			if l1111_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪፙ") in title.lower(): title = l1111_l1_ (u"ࠬิวึࠢࠪፚ")+title
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࡴࡶࡵࡹࡨࡺࡵࡳࡧ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ፛")+l1l1111l_l1_+l1111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ፜")+title+l1111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ፝")
			#l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡢ࠶ࡸ࠲࡮ࡩࡵࠨ፞"),l1111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷ࠱ࡱࡽ࠭፟"))
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ፠"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦࠧࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ፡"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			title = title.strip(l1111_l1_ (u"࠭ࠠࠨ።"))
			if l1111_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭፣") in title.lower(): title2 = l1111_l1_ (u"ࠨࡡࡢาฬ฻ࠧ፤")
			else: title2 = l1111_l1_ (u"ࠩࠪ፥")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ፦")+title+l1111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ፧")+title2
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ፨"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ፩"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠧࠨ፪"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠨࠩ፫"): return
	search = search.replace(l1111_l1_ (u"ࠩࠣࠫ፬"),l1111_l1_ (u"ࠪ࠯ࠬ፭"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭፮")+search+l1111_l1_ (u"ࠬ࠵ࠧ፯")
	l1l11l1_l1_(url,l1111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭፰"))
	return
# ===========================================
#     l11111l11_l1_ l1llll1l1l_l1_ l1llll11ll_l1_
# ===========================================
def l111111ll_l1_(url):
	if l1111_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩ፱") not in url: url = l1l1lll1l_l1_(url,l1111_l1_ (u"ࠨࡷࡵࡰࠬ፲"))
	else: url = url.split(l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭፳"))[0]
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ፴"),url,l1111_l1_ (u"ࠫࠬ፵"),l1111_l1_ (u"ࠬ࠭፶"),l1111_l1_ (u"࠭ࠧ፷"),l1111_l1_ (u"ࠧࠨ፸"),l1111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ፹"))
	html = response.content
	# all l1lll11_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧ፺"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	# name + options block + category
	l111111_l1_ = re.findall(l1111_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ፻"),block,re.DOTALL)
	return l111111_l1_
def l1lllll111_l1_(block):
	# id + title
	items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ፼"),block,re.DOTALL)
	return items
def l11111111_l1_(url):
	l1lllll1l1_l1_ = url.split(l1111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ፽"))[0]
	l1lllll11l_l1_ = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ፾"))
	url = url.replace(l1lllll1l1_l1_,l1lllll11l_l1_)
	url = url.replace(l1111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ፿"),l1111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᎀ"))
	url = url.replace(l1111_l1_ (u"ࠩࡀࠫᎁ"),l1111_l1_ (u"ࠪ࠳ࠬᎂ")).replace(l1111_l1_ (u"ࠫࠫ࠭ᎃ"),l1111_l1_ (u"ࠬ࠵ࠧᎄ"))
	url = url+l1111_l1_ (u"࠭࠯ࠨᎅ")
	return url
l1l1l11l_l1_ = [l1111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᎆ"),l1111_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧᎇ"),l1111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᎈ")]
l1ll1lll_l1_ = [l1111_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᎉ"),l1111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᎊ"),l1111_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᎋ"),l1111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᎌ")]
def l1llllll_l1_(url,filter):
	#filter = filter.replace(l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᎍ"),l1111_l1_ (u"ࠨࠩᎎ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪᎏ"),l1111_l1_ (u"ࠪࠫ᎐"),filter,url)
	if l1111_l1_ (u"ࠫࡄ࠭᎑") in url: url = url.split(l1111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ᎒"))[0]
	type,filter = filter.split(l1111_l1_ (u"࠭࡟ࡠࡡࠪ᎓"),1)
	if filter==l1111_l1_ (u"ࠧࠨ᎔"): l1l11lll_l1_,l1l11ll1_l1_ = l1111_l1_ (u"ࠨࠩ᎕"),l1111_l1_ (u"ࠩࠪ᎖")
	else: l1l11lll_l1_,l1l11ll1_l1_ = filter.split(l1111_l1_ (u"ࠪࡣࡤࡥࠧ᎗"))
	if type==l1111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ᎘"):
		if l1111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ᎙") in url:
			global l1l1l11l_l1_
			l1l1l11l_l1_ = l1l1l11l_l1_[1:]
		if l1l1l11l_l1_[0]+l1111_l1_ (u"࠭࠽ࠨ᎚") not in l1l11lll_l1_: category = l1l1l11l_l1_[0]
		for i in range(len(l1l1l11l_l1_[0:-1])):
			if l1l1l11l_l1_[i]+l1111_l1_ (u"ࠧ࠾ࠩ᎛") in l1l11lll_l1_: category = l1l1l11l_l1_[i+1]
		l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠨࠨࠪ᎜")+category+l1111_l1_ (u"ࠩࡀ࠴ࠬ᎝")
		l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠪࠪࠬ᎞")+category+l1111_l1_ (u"ࠫࡂ࠶ࠧ᎟")
		l1l1l1ll_l1_ = l1ll1ll1_l1_.strip(l1111_l1_ (u"ࠬࠬࠧᎠ"))+l1111_l1_ (u"࠭࡟ࡠࡡࠪᎡ")+l1ll11l1_l1_.strip(l1111_l1_ (u"ࠧࠧࠩᎢ"))
		l1l111l1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᎣ"))
		l1l1lll_l1_ = url+l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ꭴ")+l1l111l1_l1_
	elif type==l1111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭Ꭵ"):
		l11lll11_l1_ = l1l11l11_l1_(l1l11lll_l1_,l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭Ꭶ"))
		l11lll11_l1_ = UNQUOTE(l11lll11_l1_)
		if l1l11ll1_l1_!=l1111_l1_ (u"ࠬ࠭Ꭷ"): l1l11ll1_l1_ = l1l11l11_l1_(l1l11ll1_l1_,l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᎨ"))
		if l1l11ll1_l1_==l1111_l1_ (u"ࠧࠨᎩ"): l1l1lll_l1_ = url
		else: l1l1lll_l1_ = url+l1111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᎪ")+l1l11ll1_l1_
		l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎫ"),menu_name+l1111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭Ꭼ"),l1l1lll_l1_,421,l1111_l1_ (u"ࠫࠬᎭ"),l1111_l1_ (u"ࠬ࠭Ꭾ"),l1111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭Ꭿ"))
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᎰ"),menu_name+l1111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᎱ")+l11lll11_l1_+l1111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᎲ"),l1l1lll_l1_,421,l1111_l1_ (u"ࠪࠫᎳ"),l1111_l1_ (u"ࠫࠬᎴ"),l1111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᎵ"))
		l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᎶ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᎷ"),l1111_l1_ (u"ࠨࠩᎸ"),9999)
	l111111_l1_ = l111111ll_l1_(url)
	dict = {}
	for name,block,l1lll1ll_l1_ in l111111_l1_:
		if l1111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭Ꮉ") in url and l1lll1ll_l1_==l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᎺ"): continue
		name = name.replace(l1111_l1_ (u"ࠫ࠲࠳ࠧᎻ"),l1111_l1_ (u"ࠬ࠭Ꮌ"))
		items = l1lllll111_l1_(block)
		if l1111_l1_ (u"࠭࠽ࠨᎽ") not in l1l1lll_l1_: l1l1lll_l1_ = url
		if type==l1111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᎾ"):
			if category!=l1lll1ll_l1_: continue
			elif len(items)<2:
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]:
					url = l11111111_l1_(url)
					l1l11l1_l1_(url)
				else: l1llllll_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᎿ")+l1l1l1ll_l1_)
				return
			else:
				l1l1lll_l1_ = l11111111_l1_(l1l1lll_l1_)
				if l1lll1ll_l1_==l1l1l11l_l1_[-1]: l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏀ"),menu_name+l1111_l1_ (u"ࠪห้าๅ๋฻ࠪᏁ"),l1l1lll_l1_,421,l1111_l1_ (u"ࠫࠬᏂ"),l1111_l1_ (u"ࠬ࠭Ꮓ"),l1111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭Ꮔ"))
				else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏅ"),menu_name+l1111_l1_ (u"ࠨษ็ะ๊๐ูࠨᏆ"),l1l1lll_l1_,425,l1111_l1_ (u"ࠩࠪᏇ"),l1111_l1_ (u"ࠪࠫᏈ"),l1l1l1ll_l1_)
		elif type==l1111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᏉ"):
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠬࠬࠧᏊ")+l1lll1ll_l1_+l1111_l1_ (u"࠭࠽࠱ࠩᏋ")
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠧࠧࠩᏌ")+l1lll1ll_l1_+l1111_l1_ (u"ࠨ࠿࠳ࠫᏍ")
			l1l1l1ll_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭Ꮞ")+l1ll11l1_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏏ"),menu_name+l1111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭Ꮠ")+name,l1l1lll_l1_,424,l1111_l1_ (u"ࠬ࠭Ꮡ"),l1111_l1_ (u"࠭ࠧᏒ"),l1l1l1ll_l1_)		# +l1111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᏓ"))
		dict[l1lll1ll_l1_] = {}
		for value,option in items:
			if value==l1111_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨᏔ"): option = l1111_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩᏕ")
			elif value==l1111_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪᏖ"): option = l1111_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭Ꮧ")
			if option in l11ll11_l1_: continue
			#if l1111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᏘ") not in value: value = option
			#else: value = re.findall(l1111_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧᏙ"),value,re.DOTALL)[0]
			dict[l1lll1ll_l1_][value] = option
			l1ll1ll1_l1_ = l1l11lll_l1_+l1111_l1_ (u"ࠧࠧࠩᏚ")+l1lll1ll_l1_+l1111_l1_ (u"ࠨ࠿ࠪᏛ")+option
			l1ll11l1_l1_ = l1l11ll1_l1_+l1111_l1_ (u"ࠩࠩࠫᏜ")+l1lll1ll_l1_+l1111_l1_ (u"ࠪࡁࠬᏝ")+value
			l1lll1l1_l1_ = l1ll1ll1_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨᏞ")+l1ll11l1_l1_
			title = option+l1111_l1_ (u"ࠬࠦ࠺ࠨᏟ")#+dict[l1lll1ll_l1_][l1111_l1_ (u"࠭࠰ࠨᏠ")]
			title = option+l1111_l1_ (u"ࠧࠡ࠼ࠪᏡ")+name
			if type==l1111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᏢ"): l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏣ"),menu_name+title,url,424,l1111_l1_ (u"ࠪࠫᏤ"),l1111_l1_ (u"ࠫࠬᏥ"),l1lll1l1_l1_)		# +l1111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᏦ"))
			elif type==l1111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᏧ") and l1l1l11l_l1_[-2]+l1111_l1_ (u"ࠧ࠾ࠩᏨ") in l1l11lll_l1_:
				l1l111l1_l1_ = l1l11l11_l1_(l1ll11l1_l1_,l1111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᏩ"))
				l11l11_l1_ = url+l1111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ꮺ")+l1l111l1_l1_
				l11l11_l1_ = l11111111_l1_(l11l11_l1_)
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏫ"),menu_name+title,l11l11_l1_,421,l1111_l1_ (u"ࠫࠬᏬ"),l1111_l1_ (u"ࠬ࠭Ꮽ"),l1111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭Ꮾ"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏯ"),menu_name+title,url,425,l1111_l1_ (u"ࠨࠩᏰ"),l1111_l1_ (u"ࠩࠪᏱ"),l1lll1l1_l1_)
	return
def l1l11l11_l1_(filters,mode):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫᏲ"),l1111_l1_ (u"ࠫࠬᏳ"),filters,l1111_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭Ᏼ"))
	# mode==l1111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᏵ")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ values
	# mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ᏶")		l1ll1l11_l1_ l1l1ll1l_l1_ l1l1llll_l1_ filters
	# mode==l1111_l1_ (u"ࠨࡣ࡯ࡰࠬ᏷")					all l1l1llll_l1_ & l111111l1_l1_ filters
	filters = filters.replace(l1111_l1_ (u"ࠩࡀࠪࠬᏸ"),l1111_l1_ (u"ࠪࡁ࠵ࠬࠧᏹ"))
	filters = filters.strip(l1111_l1_ (u"ࠫࠫ࠭ᏺ"))
	l1l1l111_l1_ = {}
	if l1111_l1_ (u"ࠬࡃࠧᏻ") in filters:
		items = filters.split(l1111_l1_ (u"࠭ࠦࠨᏼ"))
		for item in items:
			var,value = item.split(l1111_l1_ (u"ࠧ࠾ࠩᏽ"))
			l1l1l111_l1_[var] = value
	l1lll11l_l1_ = l1111_l1_ (u"ࠨࠩ᏾")
	for key in l1ll1lll_l1_:
		if key in list(l1l1l111_l1_.keys()): value = l1l1l111_l1_[key]
		else: value = l1111_l1_ (u"ࠩ࠳ࠫ᏿")
		if l1111_l1_ (u"ࠪࠩࠬ᐀") not in value: value = QUOTE(value)
		if mode==l1111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᐁ") and value!=l1111_l1_ (u"ࠬ࠶ࠧᐂ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"࠭ࠠࠬࠢࠪᐃ")+value
		elif mode==l1111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᐄ") and value!=l1111_l1_ (u"ࠨ࠲ࠪᐅ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠩࠩࠫᐆ")+key+l1111_l1_ (u"ࠪࡁࠬᐇ")+value
		elif mode==l1111_l1_ (u"ࠫࡦࡲ࡬ࠨᐈ"): l1lll11l_l1_ = l1lll11l_l1_+l1111_l1_ (u"ࠬࠬࠧᐉ")+key+l1111_l1_ (u"࠭࠽ࠨᐊ")+value
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠧࠡ࠭ࠣࠫᐋ"))
	l1lll11l_l1_ = l1lll11l_l1_.strip(l1111_l1_ (u"ࠨࠨࠪᐌ"))
	l1lll11l_l1_ = l1lll11l_l1_.replace(l1111_l1_ (u"ࠩࡀ࠴ࠬᐍ"),l1111_l1_ (u"ࠪࡁࠬᐎ"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬᐏ"),l1111_l1_ (u"ࠬ࠭ᐐ"),filters,l1111_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᐑ"))
	return l1lll11l_l1_
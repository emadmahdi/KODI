# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
#l1ll11l_l1_ = l1111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ㮭")
headers = {l1111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㮮"):l1111_l1_ (u"ࠬ࠭㮯")}
l111_l1_ = l1111_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ㮰")
menu_name=l1111_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭㮱")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
def l1111ll_l1_(mode,url,page,text):
	if   mode==30: l11l_l1_ = l11l111_l1_()
	elif mode==31: l11l_l1_ = CATEGORIES(url,l1111_l1_ (u"ࠨ࠵ࠪ㮲"))
	elif mode==32: l11l_l1_ = l1ll1lll11_l1_(url)
	elif mode==33: l11l_l1_ = l1lllll_l1_(url)
	elif mode==35: l11l_l1_ = CATEGORIES(url,l1111_l1_ (u"ࠩ࠴ࠫ㮳"))
	elif mode==36: l11l_l1_ = CATEGORIES(url,l1111_l1_ (u"ࠪ࠶ࠬ㮴"))
	elif mode==37: l11l_l1_ = CATEGORIES(url,l1111_l1_ (u"ࠫ࠹࠭㮵"))
	elif mode==38: l11l_l1_ = l1l1ll1ll_l1_()
	elif mode==39: l11l_l1_ = l1lll1_l1_(text,page)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮶"),menu_name+l1111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㮷"),l1111_l1_ (u"ࠧࠨ㮸"),39,l1111_l1_ (u"ࠨࠩ㮹"),l1111_l1_ (u"ࠩࠪ㮺"),l1111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㮻"))
	#l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㮼"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㮽"),l1111_l1_ (u"࠭ࠧ㮾"),9999)
	l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㮿"),l111_l1_+l1111_l1_ (u"ࠨࡡࡢࡣࠬ㯀")+menu_name+l1111_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ㯁"),l1111_l1_ (u"ࠪࠫ㯂"),38)
	#l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯃"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ㯄")+menu_name+l1111_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠสิห๊าࠧ㯅"),l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ㯆"),31)
	#l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯇"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭㯈")+menu_name+l1111_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅษๆฯึࠦๅีษ๊ำฮ࠭㯉"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ㯊"),37)
	#l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯋"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ㯌")+menu_name+l1111_l1_ (u"ࠧศใ็ห๊ࠦอิสࠣห้์ฺ่ࠩ㯍"),l1ll11l_l1_+l1111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ㯎"),35)
	#l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㯏"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ㯐")+menu_name+l1111_l1_ (u"ࠫฬ็ไศ็ࠣัุฮࠠศๆ่้ะ๊ࠧ㯑"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭㯒"),36)
	#l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㯓"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ㯔")+menu_name+l1111_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ㯕"),l1ll11l_l1_+l1111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ㯖"),32)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㯗"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ㯘")+menu_name+l1111_l1_ (u"๋ࠬำาฯํหฯ࠭㯙"),l1ll11l_l1_+l1111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࡨࡧࡱࡶࡪ࠵࠴࠰࠳ࠪ㯚"),32)
	return l1111_l1_ (u"ࠧࠨ㯛")
def CATEGORIES(url,select=l1111_l1_ (u"ࠨࠩ㯜")):
	type = url.split(l1111_l1_ (u"ࠩ࠲ࠫ㯝"))[3]
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ㯞"),l1111_l1_ (u"ࠫࠬ㯟"),type, url)
	if type==l1111_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ㯠"):
		html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"࠭ࠧ㯡"),headers,l1111_l1_ (u"ࠧࠨ㯢"),l1111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨ㯣"))
		if select==l1111_l1_ (u"ࠩ࠶ࠫ㯤"):
			l111l1l_l1_=re.findall(l1111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࡍࡦࡰࡸࠬ࠳࠰࠿ࠪࡵࡨࡶ࡮࡫ࡳࡇࡱࡵࡱࠬ㯥"),html,re.DOTALL)
			block= l111l1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㯦"),block,re.DOTALL)
			for l1l111l_l1_,name in items:
				if l1111_l1_ (u"้ࠬไ๋สสฮ๋ࠥึฮๅฬࠫ㯧") in name: continue
				url = l1ll11l_l1_ + l1l111l_l1_
				name = name.strip(l1111_l1_ (u"࠭ࠠࠨ㯨"))
				l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯩"),menu_name+name,url,32)
		if select==l1111_l1_ (u"ࠨ࠶ࠪ㯪"):
			l111l1l_l1_=re.findall(l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡦࡨࡸࡦ࡯࡬ࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡼ࠾࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࠫ㯫"),html,re.DOTALL)
			block= l111l1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㯬"),block,re.DOTALL)
			for l1l111l_l1_,img,title in items:
				url = l1ll11l_l1_ + l1l111l_l1_
				title = title.strip(l1111_l1_ (u"ࠫࠥ࠭㯭"))
				l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯮"),menu_name+title,url,32,img)
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ㯯"),l1111_l1_ (u"ࠧࠨ㯰"),url,l1111_l1_ (u"ࠨࠩ㯱"))
	if type==l1111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ㯲"):
		html = l111l11_l1_(l111ll_l1_,url,l1111_l1_ (u"ࠪࠫ㯳"),headers,l1111_l1_ (u"ࠫࠬ㯴"),l1111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠴ࡱࡨࠬ㯵"))
		if select==l1111_l1_ (u"࠭࠱ࠨ㯶"):
			l111l1l_l1_=re.findall(l1111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡇࡦࡰࡧࡩࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ㯷"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㯸"),block,re.DOTALL)
			for value,name in items:
				url = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱ࠪ㯹") + value
				name = name.strip(l1111_l1_ (u"ࠪࠤࠬ㯺"))
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯻"),menu_name+name,url,32)
		elif select==l1111_l1_ (u"ࠬ࠸ࠧ㯼"):
			l111l1l_l1_=re.findall(l1111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡇࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ㯽"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			items=re.findall(l1111_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㯾"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1111_l1_ (u"ࠨࠢࠪ㯿"))
				url = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ㰀") + value
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰁"),menu_name+name,url,32)
	return
def l1ll1lll11_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㰂"),l1111_l1_ (u"ࠬ࠭㰃"),url,l1111_l1_ (u"࠭ࠧ㰄"))
	type = url.split(l1111_l1_ (u"ࠧ࠰ࠩ㰅"))[3]
	html = l111l11_l1_(l1111l1_l1_,url,l1111_l1_ (u"ࠨࠩ㰆"),headers,l1111_l1_ (u"ࠩࠪ㰇"),l1111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㰈"))
	if l1111_l1_ (u"ࠫ࡭ࡵ࡭ࡦࠩ㰉") in url: type=l1111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ㰊")
	if type==l1111_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ㰋"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠫ࠲࠯ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ㰌"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㰍"),block,re.DOTALL)
			for l1l111l_l1_,img,name in items:
				url = l1ll11l_l1_ + l1l111l_l1_
				name = name.strip(l1111_l1_ (u"ࠩࠣࠫ㰎"))
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰏"),menu_name+name,url,32,img)
	if type==l1111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ㰐"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ㰑"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠱࠿ࠪࠤࠪ㰒"),block,re.DOTALL)
		for l1l111l_l1_,img,name in items:
			name = name.strip(l1111_l1_ (u"ࠧࠡࠩ㰓"))
			url = l1ll11l_l1_ + l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㰔"),menu_name+name,url,33,img)
	if type==l1111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㰕"):
		page = url.split(l1111_l1_ (u"ࠪ࠳ࠬ㰖"))[-1]
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ㰗"),l1111_l1_ (u"ࠬ࠭㰘"),url,l1111_l1_ (u"࠭ࠧ㰙"))
		if page==l1111_l1_ (u"ࠧ࠲ࠩ㰚"):
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠭࠴ࠫࡀࠫࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠭㰛"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࠪ㰜"),block,re.DOTALL)
			count = 0
			for l1l111l_l1_,img,l11l11l_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1111_l1_ (u"ࠪࠤ࠲ࠦࠧ㰝") + l11l11l_l1_
				url = l1ll11l_l1_ + l1l111l_l1_
				l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㰞"),menu_name+name,url,33,img)
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴ࠰࠭ࡃࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ㰟"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸ࠧ㰠"),block,re.DOTALL)
		for l1l111l_l1_,img,title,l11l11l_l1_ in items:
			l11l11l_l1_ = l11l11l_l1_.strip(l1111_l1_ (u"ࠧࠡࠩ㰡"))
			title = title.strip(l1111_l1_ (u"ࠨࠢࠪ㰢"))
			name = title + l1111_l1_ (u"ࠩࠣ࠱ࠥ࠭㰣") + l11l11l_l1_
			url = l1ll11l_l1_ + l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㰤"),menu_name+name,url,33,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫ࡬ࡲࡹࡱࡪ࡬ࡧࡴࡴ࠭ࡤࡪࡨࡺࡷࡵ࡮࠮ࡴ࡬࡫࡭ࡺࠨ࠯࠭ࡂ࠭ࡩࡧࡴࡢ࠯ࡵࡩࡻ࡯ࡶࡦ࠯ࡽࡳࡳ࡫ࡩࡥ࠿ࠥ࠸ࠧ࠭㰥"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㰦"),block,re.DOTALL)
	for l1l111l_l1_,page in items:
		url = l1ll11l_l1_ + l1l111l_l1_
		name = l1111_l1_ (u"࠭ีโฯฬࠤࠬ㰧") + page
		l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㰨"),menu_name+name,url,32)
	return
def l1lllll_l1_(url):
	if l1111_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ㰩") in url:
		url = l1ll11l_l1_ + l1111_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࡷ࠳࠲ࡷࡪࡸࡩࡦࡵࡏ࡭ࡳࡱ࠯ࠨ㰪") + url.split(l1111_l1_ (u"ࠪ࠳ࠬ㰫"))[-1]
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ㰬"),url,l1111_l1_ (u"ࠬ࠭㰭"),headers,l1111_l1_ (u"࠭ࠧ㰮"),l1111_l1_ (u"ࠧࠨ㰯"),l1111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㰰"))
		html = response.content
		items = re.findall(l1111_l1_ (u"ࠩࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㰱"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1111_l1_ (u"ࠪࡠ࠴࠭㰲"),l1111_l1_ (u"ࠫ࠴࠭㰳"))
	else:
		response = l1l11l_l1_(l1ll1llll_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ㰴"),url,l1111_l1_ (u"࠭ࠧ㰵"),headers,l1111_l1_ (u"ࠧࠨ㰶"),l1111_l1_ (u"ࠨࠩ㰷"),l1111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㰸"))
		html = response.content
		items = re.findall(l1111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࡙ࡗࡒࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㰹"),html,re.DOTALL)
		url = items[0]
	l1ll11ll1_l1_(url,l111_l1_,l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㰺"))
	return
def l1lll1_l1_(search,page=l1111_l1_ (u"ࠬ࠭㰻")):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search:
		search = l11ll_l1_()
		if not search: return
	l1lll1l_l1_ = search.replace(l1111_l1_ (u"࠭ࠠࠨ㰼"),l1111_l1_ (u"ࠧࠦ࠴࠳ࠫ㰽"))
	l1l1lllll_l1_ = [l1111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ㰾"),l1111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ㰿")]
	if not page: page = l1111_l1_ (u"ࠪ࠵ࠬ㱀")
	else: page,type = page.split(l1111_l1_ (u"ࠫ࠴࠭㱁"))
	if l1ll11_l1_:
		l1ll11l1l1l_l1_ = [ l1111_l1_ (u"ࠬฮอฬࠢ฼๊ࠥอแๅษ่ࠫ㱂") , l1111_l1_ (u"࠭ศฮอࠣ฽๋ࠦๅิๆึ่ฬะࠧ㱃")]
		l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤ࠲ࠦวฯฬิࠤฬ๊ศฮอࠪ㱄"), l1ll11l1l1l_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lllll_l1_[l1l_l1_]
	else:
		if l1111_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࡠࠩ㱅") in options: type = l1111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ㱆")
		elif l1111_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࡢࠫ㱇") in options: type = l1111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ㱈")
		else: return
	headers[l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㱉")] = l1111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭㱊")
	data = {l1111_l1_ (u"ࠧࡲࡷࡨࡶࡾ࠭㱋"):l1lll1l_l1_ , l1111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡅࡱࡰࡥ࡮ࡴࠧ㱌"):type}
	if page!=l1111_l1_ (u"ࠩ࠴ࠫ㱍"): data[l1111_l1_ (u"ࠪࡪࡷࡵ࡭ࠨ㱎")] = page
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㱏"),l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭㱐"),data,headers,l1111_l1_ (u"࠭ࠧ㱑"),l1111_l1_ (u"ࠧࠨ㱒"),l1111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ㱓"))
	html = response.content
	items=re.findall(l1111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㱔"),html,re.DOTALL)
	if items:
		for title,l1l111l_l1_ in items:
			url = l1ll11l_l1_ + l1l111l_l1_.replace(l1111_l1_ (u"ࠪࡠ࠴࠭㱕"),l1111_l1_ (u"ࠫ࠴࠭㱖"))
			if l1111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ㱗") in url: l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㱘"),menu_name+l1111_l1_ (u"ࠧโ์็้ࠥ࠭㱙")+title,url,33)
			elif l1111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ㱚") in url:
				url = url.replace(l1111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ㱛"),l1111_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࠩ㱜"))
				l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㱝"),menu_name+l1111_l1_ (u"๋ࠬำๅี็ࠤࠬ㱞")+title,url+l1111_l1_ (u"࠭࠯࠲ࠩ㱟"),32)
	count=re.findall(l1111_l1_ (u"ࠧࠣࡶࡲࡸࡦࡲࠢ࠻ࠪ࠱࠮ࡄ࠯ࡽࠨ㱠"),html,re.DOTALL)
	if count:
		l1l1l1ll1_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll111ll_l1_ in range(1,l1l1l1ll1_l1_):
			l1ll111ll_l1_ = str(l1ll111ll_l1_)
			if l1ll111ll_l1_!=page:
				l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱡"),l1111_l1_ (u"ุࠩๅาฯࠠࠨ㱢")+l1ll111ll_l1_,l1111_l1_ (u"ࠪࠫ㱣"),39,l1111_l1_ (u"ࠫࠬ㱤"),l1ll111ll_l1_+l1111_l1_ (u"ࠬ࠵ࠧ㱥")+type,search)
	return
def l1l1ll1ll_l1_():
	l1l111l_l1_ = l1111_l1_ (u"࠭ࡡࡉࡔ࠳ࡧࡉࡵࡶࡍ࠴ࡧࡾࡩࡎࡊ࡭࡛࡚࠴࠵ࡒ࡮ࡃࡪࡥࡱ࡛࠶ࡌ࡮ࡐࡹࡐࡲࡲࡳࡍ࠴࡙࡯࡟࠸ࡖࡧ࡛࡚ࡎࡾࡒ࠲ࡩࡪࡥࡋࡋ࡛ࡖࡪ࠻ࡺࡦࡌࡌ࠵ࡣࡉ࡯ࡾࡩࡉ࠵ࡵࡏ࠶࡙࠹࠭㱦")
	l1l111l_l1_ = base64.b64decode(l1l111l_l1_)
	l1l111l_l1_ = l1l111l_l1_.decode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㱧"))
	l1ll11ll1_l1_(l1l111l_l1_,l111_l1_,l1111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㱨"))
	return
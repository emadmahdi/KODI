﻿# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
#import unicodedata,simplejson
def l1111ll_l1_(mode,l11lll1111l_l1_):
	if l11lll1111l_l1_==l1111_l1_ (u"ࠪࠫ⨑"): return
	if mode==1:
		l11lll11lll_l1_ = xbmcgui.l11lll11ll1_l1_()
		l11lll11l1l_l1_ = xbmcgui.l11ll1lll1l_l1_(l11lll11lll_l1_)
		l11lll1111l_l1_ = l11lll1l111_l1_(l11lll1111l_l1_)
		l11lll11l1l_l1_.getControl(311).l11lll1l11l_l1_(l11lll1111l_l1_)
	if mode==0:
		#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ⨒"))
		#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ⨓"))
		#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⨔"))
		l11ll1lllll_l1_=l1111_l1_ (u"࡙ࠧࠩ⨕")
		if kodi_version>18.99: check = isinstance(l11lll1111l_l1_,str)
		else: check = isinstance(l11lll1111l_l1_,unicode)
		if check==True: l11ll1lllll_l1_=l1111_l1_ (u"ࠨࡗࠪ⨖")
		l11ll1llll1_l1_=str(type(l11lll1111l_l1_))+l1111_l1_ (u"ࠩࠣࠫ⨗")+l11lll1111l_l1_+l1111_l1_ (u"ࠪࠤࠬ⨘")+l11ll1lllll_l1_+l1111_l1_ (u"ࠫࠥ࠭⨙")
		for i in range(0,len(l11lll1111l_l1_),1):
			l11ll1llll1_l1_ += hex(ord(l11lll1111l_l1_[i])).replace(l1111_l1_ (u"ࠬ࠶ࡸࠨ⨚"),l1111_l1_ (u"࠭ࠧ⨛"))+l1111_l1_ (u"ࠧࠡࠩ⨜")
		l11lll1111l_l1_ = l11lll1l111_l1_(l11lll1111l_l1_)
		#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⨝"))
		l11ll1lllll_l1_=l1111_l1_ (u"࡛ࠩࠫ⨞")
		if kodi_version>18.99: check = isinstance(l11lll1111l_l1_, str)
		else: check = isinstance(l11lll1111l_l1_, unicode)
		if check==True: l11ll1lllll_l1_=l1111_l1_ (u"࡙ࠪࠬ⨟")
		l11lll11111_l1_=str(type(l11lll1111l_l1_))+l1111_l1_ (u"ࠫࠥ࠭⨠")+l11lll1111l_l1_+l1111_l1_ (u"ࠬࠦࠧ⨡")+l11ll1lllll_l1_+l1111_l1_ (u"࠭ࠠࠨ⨢")
		for i in range(0,len(l11lll1111l_l1_),1):
			l11lll11111_l1_ += hex(ord(l11lll1111l_l1_[i])).replace(l1111_l1_ (u"ࠧ࠱ࡺࠪ⨣"),l1111_l1_ (u"ࠨࠩ⨤"))+l1111_l1_ (u"ࠩࠣࠫ⨥")
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⨦"),l1111_l1_ (u"ࠫࠬ⨧"),l11ll1llll1_l1_,l11lll11111_l1_)
	return
	#for i in range(0,len(l11lll1111l_l1_)-2,3):
	#	string=hex(ord(l11lll1111l_l1_[i+0]))+l1111_l1_ (u"ࠬࠦࠠࠨ⨨")+hex(ord(l11lll1111l_l1_[i+1]))+l1111_l1_ (u"࠭ࠠࠡࠩ⨩")+hex(ord(l11lll1111l_l1_[i+2]))
	#	l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⨪"),l1111_l1_ (u"ࠨࠩ⨫"),l1111_l1_ (u"ࠩࠪ⨬"),string)
	#return
	#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⨭"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ⨮"),l1111_l1_ (u"ࠬ࠭⨯"),l1111_l1_ (u"࠭ࠧ⨰"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1l111_l1_(l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⨱"))
	#l11lll1111l_l1_ = unicodedata.normalize(l1111_l1_ (u"ࠨࡐࡉࡏࡉ࠭⨲"),l11lll1111l_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ⨳"),l1111_l1_ (u"ࠪࠫ⨴"),l1111_l1_ (u"ࠫࠬ⨵"),   hex(  unicodedata.combining(l11lll1111l_l1_[0])  )   )
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭⨶"),l1111_l1_ (u"࠭ࠧ⨷"),l11lll1111l_l1_,   hex(ord(  l11lll1111l_l1_[0]  ))   )
	#new = l1111_l1_ (u"ࠧࠨ⨸")
	#for l11lll111l1_l1_ in l11lll1111l_l1_:
	#	l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⨹"),l1111_l1_ (u"ࠩࠪ⨺"),l1111_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ⨻"),unicodedata.decomposition(l11lll111l1_l1_) )
	#	new += l1111_l1_ (u"ࠫࡡࡻ࠰ࠨ⨼") + hex(ord(l11lll111l1_l1_)).replace(l1111_l1_ (u"ࠬ࠶ࡸࠨ⨽"),l1111_l1_ (u"࠭ࠧ⨾"))
	#l11lll1111l_l1_ = new
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⨿"),l1111_l1_ (u"ࠨࠩ⩀"),l1111_l1_ (u"ࠩࠪ⩁"),l11lll1111l_l1_)
	#new = l1111_l1_ (u"ࠪࠫ⩂")
	#for i in range(len(l11lll1111l_l1_)-6,-5,-6):
	#	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ⩃"),l1111_l1_ (u"ࠬ࠭⩄"),l1111_l1_ (u"࠭ࠧ⩅"),str(i))
	#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1] + l11lll1111l_l1_[i+2] + l11lll1111l_l1_[i+3] + l11lll1111l_l1_[i+4] + l11lll1111l_l1_[i+5]
	#l11lll1111l_l1_ = new
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⩆"),l1111_l1_ (u"ࠨࠩ⩇"),l1111_l1_ (u"ࠩࠪ⩈"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ⩉"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ⩊"),l1111_l1_ (u"ࠬ࠭⩋"),l1111_l1_ (u"࠭ࠧ⩌"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1111l_l1_.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⩍"))
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩ⩎"),l1111_l1_ (u"ࠩࠪ⩏"),l1111_l1_ (u"ࠪࠫ⩐"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l1111_l1_ (u"ࠫࡪࡳࡡࡥࠩ⩑")
	#l11lll111ll_l1_ = xbmc.executeJSONRPC(l1111_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡎࡴࡰࡶࡶ࠱ࡗࡪࡴࡤࡕࡧࡻࡸࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠫ⩒")+l11lll1111l_l1_+l1111_l1_ (u"࠭ࠢ࠭ࠤࡧࡳࡳ࡫ࠢ࠻ࡨࡤࡰࡸ࡫ࡽ࠭ࠤ࡬ࡨࠧࡀ࠱ࡾࠩ⩓"))
	#simplejson.loads(l11lll111ll_l1_)
	#l11lll1111l_l1_ = l11lll1111l_l1_.encode(l1111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⩔"))
	#new = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ⩕"))
	#l11lll1111l_l1_ = new
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ⩖"),l1111_l1_ (u"ࠪࠫ⩗"),l1111_l1_ (u"ࠫࠬ⩘"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1l111_l1_(l11lll1111l_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭⩙"),l1111_l1_ (u"࠭ࠧ⩚"),l1111_l1_ (u"ࠧࠨ⩛"),l11lll1111l_l1_)
	#new = l1111_l1_ (u"ࠨࠩ⩜")
	#for i in range(len(l11lll1111l_l1_)-2,-1,-2):
	#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1]
	#l11lll1111l_l1_ = new
	#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪ⩝"),l1111_l1_ (u"ࠪࠫ⩞"),l1111_l1_ (u"ࠫࠬ⩟"),l11lll1111l_l1_)
	#l11lll1111l_l1_ = l11lll1111l_l1_.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⩠"))
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⩡"),l1111_l1_ (u"ࠧࠨ⩢"),l1111_l1_ (u"ࠨࠩ⩣"),l11lll1111l_l1_)
	#new = l1111_l1_ (u"ࠩࠪ⩤")
	#for i in range(len(l11lll1111l_l1_)-2,-1,-2):
	#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1]
	#l11lll1111l_l1_ = new
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⩥"),l1111_l1_ (u"ࠫࠬ⩦"),l1111_l1_ (u"ࠬ࠭⩧"),l11lll1111l_l1_)
		#l11lll1111l_l1_ = l11lll1111l_l1_.replace(l1111_l1_ (u"࠭ࠠࠨ⩨"),l1111_l1_ (u"ࠧࠨ⩩"))
		#new = l1111_l1_ (u"ࠨࠩ⩪")
		#for i in range(len(l11lll1111l_l1_)-3,-2,-3):
		#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1] + l11lll1111l_l1_[i+2]
		#l11lll1111l_l1_ = new
		#new = l1111_l1_ (u"ࠩࠪ⩫")
		#for i in range(len(l11lll1111l_l1_)-2,-1,-2):
		#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1]
		#l11lll1111l_l1_ = new
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⩬"),l1111_l1_ (u"ࠫࠬ⩭"),l1111_l1_ (u"ࠬ࠭⩮"),l11lll1111l_l1_)
		#l11lll1111l_l1_ = l11lll1111l_l1_.l11lll11l11_l1_(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⩯"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⩰"),l1111_l1_ (u"ࠨࠩ⩱"),str(ord(l11lll1111l_l1_[0]))+l1111_l1_ (u"ࠩࠣࠫ⩲")+str(ord(l11lll1111l_l1_[1]))+l1111_l1_ (u"ࠪࠤࠬ⩳")+str(ord(l11lll1111l_l1_[2])),str(len(l11lll1111l_l1_)))
		#l1ll1l_l1_(l1111_l1_ (u"ࠫࠬ⩴"),l1111_l1_ (u"ࠬ࠭⩵"),l1111_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵ࠦࡌࡦࡶࡷࡩࡷࡹࠧ⩶"),l11lll1111l_l1_)
		#new = l1111_l1_ (u"ࠧࠨ⩷")
		#for i in range(len(l11lll1111l_l1_)-2,-1,-2):
		#	new += l11lll1111l_l1_[i] + l11lll1111l_l1_[i+1]
		#l11lll1111l_l1_ = new
		#new = l11lll1111l_l1_.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⩸"))
		#new = new.decode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⩹"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⩺"),l1111_l1_ (u"ࠫࠬ⩻"),l1111_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ⩼"),new )
		#l11ll1llll1_l1_ = l1111_l1_ (u"࠭ࠧ⩽")
		#for l11lll111l1_l1_ in new:
		#	l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⩾"),l1111_l1_ (u"ࠨࠩ⩿"),l1111_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ⪀"),unicodedata.decomposition(l11lll111l1_l1_) )
		#	l11ll1llll1_l1_ += l1111_l1_ (u"ࠪࡠࡺ࠭⪁") + hex(ord(l11lll111l1_l1_)).replace(l1111_l1_ (u"ࠫࡽ࠭⪂"),l1111_l1_ (u"ࠬ࠭⪃"))
		#l11ll1llll1_l1_ = l11ll1llll1_l1_.decode(l1111_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ⪄"))
		#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⪅"),l1111_l1_ (u"ࠨࠩ⪆"),l1111_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ⪇"),l11ll1llll1_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l11lll1l111_l1_(new)
		#l11lll1111l_l1_ = new.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⪈"))
		#new = new.decode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⪉")) #.decode(l1111_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭⪊"))
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⪋"),l1111_l1_ (u"ࠧࠨ⪌"),l1111_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨ⪍"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l1111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⪎")))   )
		#l11lll1111l_l1_ = l11lll1l111_l1_(new)
		#l11lll1111l_l1_ = l11lll1l111_l1_(l11lll1111l_l1_)
		#method=l1111_l1_ (u"ࠥࡍࡳࡶࡵࡵ࠰ࡖࡩࡳࡪࡔࡦࡺࡷࠦ⪏")
		#params=l1111_l1_ (u"ࠫࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠥࡴࠤ࠯ࠤࠧࡪ࡯࡯ࡧࠥ࠾࡫ࡧ࡬ࡴࡧࢀࠫ⪐") % l11lll1111l_l1_
		#l11lll111ll_l1_ = xbmc.executeJSONRPC(l1111_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠣࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠦࠢࠦࡵࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࠡࠧࡶ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ⪑") % (method, params))
# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ傒")
menu_name=l1111_l1_ (u"ࠬࡥࡔࡗࡈࡢࠫ傓")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ傔")]
def l1111ll_l1_(mode,url,text):
	if   mode==460: l11l_l1_ = l11l111_l1_()
	elif mode==461: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==462: l11l_l1_ = l1lllll_l1_(url)
	elif mode==463: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==469: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡈࡇࡗࠫ傕"),l1ll11l_l1_,l1111_l1_ (u"ࠨࠩ傖"),l1111_l1_ (u"ࠩࠪ傗"),l1111_l1_ (u"ࠪࠫ傘"),l1111_l1_ (u"ࠫࠬ備"),l1111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭傚"))
	html = response.content
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭傛"),menu_name+l1111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ傜"),l1111_l1_ (u"ࠨࠩ傝"),469,l1111_l1_ (u"ࠩࠪ傞"),l1111_l1_ (u"ࠪࠫ傟"),l1111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傠"))
	l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傡"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ傢")+menu_name+l1111_l1_ (u"ࠧฤะิࠤฬ๊อๅไสฮࠬ傣"),l1ll11l_l1_,461,l1111_l1_ (u"ࠨࠩ傤"),l1111_l1_ (u"ࠩࠪ傥"),l1111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ傦"))
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ傧"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ储"),l1111_l1_ (u"࠭ࠧ傩"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣ࡯ࡨࡲࡺ࠳ࡢࡵࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ傪"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ傫"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#if l1l111l_l1_==l1111_l1_ (u"ࠩࠦࠫ催"): continue
			if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ傭") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			if title==l1111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭傮"): title = l1111_l1_ (u"ࠬาฯ๋ัࠣั้่วหࠢอ๎ๆ๐ࠠโษ้ࠫ傯")
			if title in l11ll11_l1_: continue
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭傰"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫ傱")+menu_name+title,l1l111l_l1_,461)
	#l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡉࡳࡴࡺࡥࡳࡅࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ傲"),html,re.DOTALL)
	#if l111l1l_l1_:
	#	block = l111l1l_l1_[0]
	#	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ傳"),block,re.DOTALL)
	#	for l1l111l_l1_,title in items:
	#		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ傴"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ債")+menu_name+title,l1l111l_l1_,461)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠬ࠭傶")):
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ傷"),l1111_l1_ (u"ࠧࠨ傸"),l11111l1l_l1_,url)
	items = []
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ傹"),url,l1111_l1_ (u"ࠩࠪ傺"),l1111_l1_ (u"ࠪࠫ傻"),l1111_l1_ (u"ࠫࠬ傼"),l1111_l1_ (u"ࠬ࠭傽"),l1111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ傾"))
	html = response.content
	if l11111l1l_l1_!=l1111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ傿"): l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠪࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡥࡢࡦ࠰ࡸ࡮ࡺ࡬ࡦࠤࠪ僀"),html,re.DOTALL)
	else: l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩฦาึࠦวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ僁"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡭ࡻ࡭ࡣࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ僂"),block,re.DOTALL)
		l1lllll1_l1_ = []
		l1lll1lll1_l1_ = [l1111_l1_ (u"ฺ๊ࠫว่ัฬࠫ僃"),l1111_l1_ (u"ࠬ็๊ๅ็ࠪ僄"),l1111_l1_ (u"࠭ว฻่ํอࠬ僅"),l1111_l1_ (u"ࠧไๆํฬࠬ僆"),l1111_l1_ (u"ࠨษ฼่ฬ์ࠧ僇"),l1111_l1_ (u"๊ࠩำฬ็ࠧ僈"),l1111_l1_ (u"้ࠪออัศหࠪ僉"),l1111_l1_ (u"ࠫ฾ืึࠨ僊"),l1111_l1_ (u"๋ࠬ็าฮส๊ࠬ僋"),l1111_l1_ (u"࠭วๅส๋้ࠬ僌")]
		for l1l111l_l1_,title,img in items:
			if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬ働") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l1l111l_l1_ = UNQUOTE(l1l111l_l1_)	#.strip(l1111_l1_ (u"ࠨ࠱ࠪ僎"))
			l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ像"),title,re.DOTALL)
			if any(value in title for value in l1lll1lll1_l1_):
				l1l1l_l1_(l1111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ僐"),menu_name+title,l1l111l_l1_,462,img)
			elif l11l11l_l1_ and l1111_l1_ (u"ࠫฬ๊อๅไฬࠫ僑") in title:
				title = l1111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ僒") + l11l11l_l1_[0]
				if title not in l1lllll1_l1_:
					l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僓"),menu_name+title,l1l111l_l1_,463,img)
					l1lllll1_l1_.append(title)
			else: l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僔"),menu_name+title,l1l111l_l1_,463,img)
	if l11111l1l_l1_!=l1111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ僕"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ僖"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ僗"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠫࠥ࠭僘"))
				if l1l111l_l1_==l1111_l1_ (u"ࠧࠨ僙"): continue
				if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ僚") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
				#title = l1l1111_l1_(title)
				if title!=l1111_l1_ (u"ࠧࠨ僛"): l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僜"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨ僝")+title,l1l111l_l1_,461)
	return
def l1l11ll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ僞"),l1111_l1_ (u"ࠫࠬ僟"),l1111_l1_ (u"ࠬࡋࡐࡊࡕࡒࡈࡊ࡙ࠧ僠"),url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪ僡"),url,l1111_l1_ (u"ࠧࠨ僢"),l1111_l1_ (u"ࠨࠩ僣"),l1111_l1_ (u"ࠩࠪ僤"),l1111_l1_ (u"ࠪࠫ僥"),l1111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ僦"))
	html = response.content
	# l1llll11_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬ࠮ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡫ࡩࡦࡪ࠭ࡵ࡫ࡷࡰࡪࠨࠧ僧"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ僨"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			if l1111_l1_ (u"ࠧࡩࡶࡷࡴࠬ僩") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l1l1l_l1_(l1111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ僪"),menu_name+title,l1l111l_l1_,462,img)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ僫"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ僬"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			l1l111l_l1_ = l1l111l_l1_.strip(l1111_l1_ (u"ࠫࠥ࠭僭"))
			if l1l111l_l1_==l1111_l1_ (u"ࠧࠨ僮"): continue
			if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ僯") not in l1l111l_l1_: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			#title = l1l1111_l1_(title)
			if title!=l1111_l1_ (u"ࠧࠨ僰"): l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僱"),menu_name+l1111_l1_ (u"ุࠩๅาฯࠠࠨ僲")+title,l1l111l_l1_,463)
	return
def l1lllll_l1_(url):
	l11lll1l_l1_ = []
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ僳"),url,l1111_l1_ (u"ࠫࠬ僴"),l1111_l1_ (u"ࠬ࠭僵"),l1111_l1_ (u"࠭ࠧ僶"),l1111_l1_ (u"ࠧࠨ僷"),l1111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ僸"))
	html = response.content
	# l11l1l11l_l1_ l1l111l_l1_
	l11l1ll11l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡗࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ價"),html,re.DOTALL)
	if l11l1ll11l_l1_:
		l11l1ll11l_l1_ = l11l1ll11l_l1_[0]
		if l1111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ僺") not in l11l1ll11l_l1_:
			if l1111_l1_ (u"ࠫ࠴࠵ࠧ僻") in l11l1ll11l_l1_: l11l1ll11l_l1_ = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ僼")+l11l1ll11l_l1_
			else: l11l1ll11l_l1_ = l1ll11l_l1_+l11l1ll11l_l1_
		l11l1ll11l_l1_ = l11l1ll11l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ僽")
		l11lll1l_l1_.append(l11l1ll11l_l1_)
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡣ࠳࠸࠾ࡧ࡫ࡦࡰࡴࡨࠬ࠳࠰࠿ࠪࡵࡰࡥࡱࡲ࠮ࠫࡁ࡚ࠥ࡮ࡪࡥࡰࡕࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩࠣࡒ࡯ࡥࡾࠨࠧ僾"),html,re.DOTALL)
	if l111l1l_l1_:
		l1111ll1l1l1_l1_,l1111ll1l1ll_l1_ = l111l1l_l1_[0]
		names = re.findall(l1111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ僿"),l1111ll1l1l1_l1_,re.DOTALL)
		l11l1ll1_l1_ = re.findall(l1111_l1_ (u"ࠤࡶࡩࡹ࡜ࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣ儀"),l1111ll1l1ll_l1_,re.DOTALL)
		l1111ll1l11l_l1_ = zip(names,l11l1ll1_l1_)
		for name,l11ll1ll111l_l1_ in l1111ll1l11l_l1_:
			l11ll1ll111l_l1_ = l11ll1ll111l_l1_[2:]
			if kodi_version<19: l11ll1ll111l_l1_ = l11ll1ll111l_l1_.decode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ儁"))
			l11ll1ll111l_l1_ = base64.b64decode(l11ll1ll111l_l1_)
			if kodi_version>18.99: l11ll1ll111l_l1_ = l11ll1ll111l_l1_.decode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ儂"))
			l1l111l_l1_ = re.findall(l1111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ儃"),l11ll1ll111l_l1_,re.DOTALL)
			l1l111l_l1_ = l1l111l_l1_[0]
		if l1111_l1_ (u"࠭ࡨࡵࡶࡳࠫ億") not in l1l111l_l1_:
			if l1111_l1_ (u"ࠧ࠰࠱ࠪ儅") in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ儆")+l1l111l_l1_
			else: l1l111l_l1_ = l1ll11l_l1_+l1l111l_l1_
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ儇")+name+l1111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ儈")
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ儉"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ儊"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if not search:
		search = l11ll_l1_()
		if not search: return
	if l1111_l1_ (u"࠭ࠠࠨ儋") in search:
		if l1ll11_l1_: l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ儌"),l1111_l1_ (u"ࠨࠩ儍"),l1111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ儎"),l1111_l1_ (u"่้ࠪษำโࠢส่อำหࠡใํࠤ์ึวࠡษ็้ํู่ࠡๆสࠤ๏฿ๅๅࠢ฼๊ิࠦืๅสࠣว่ััࠡ็้ࠤ่๊ๅส๋ࠢหาีษࠡ࠰࠱࠲ࠥ๐ัอ๋ࠣห้ฮอฬࠢ฼๊้ࠥไๆหࠣ์ฬำฯสࠢไๆ฼࠭儏"))
		return
	#search = search.replace(l1111_l1_ (u"ࠫࠥ࠭儐"),l1111_l1_ (u"ࠬ࠳ࠧ儑"))
	#url = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ儒")+search
	url = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡳ࠲ࠫ儓")+search+l1111_l1_ (u"ࠨ࠱ࠪ儔")
	l1l11l1_l1_(url)
	return
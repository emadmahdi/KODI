# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ⃷")
menu_name=l1111_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫ⃸")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"࠭วๅฬุ๊๏็วหࠩ⃹"),l1111_l1_ (u"ࠧศ่ืหฦࠦอิษหࠫ⃺"),l1111_l1_ (u"ࠨู็ฬฬะࠠศๆี์๖อัࠨ⃻")]
#headers = {l1111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⃼"):l1111_l1_ (u"ࠪࠫ⃽")}
def l1111ll_l1_(mode,url,text):
	if   mode==390: l11l_l1_ = l11l111_l1_()
	elif mode==391: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==392: l11l_l1_ = l1lllll_l1_(url)
	elif mode==393: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==399: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃾"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⃿"),l1111_l1_ (u"࠭ࠧ℀"),399,l1111_l1_ (u"ࠧࠨ℁"),l1111_l1_ (u"ࠨࠩℂ"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭℃"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ℄"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ℅"),l1111_l1_ (u"ࠬ࠭℆"),9999)
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"࠭ࡇࡆࡖࠪℇ"),l1ll11l_l1_,l1111_l1_ (u"ࠧࠨ℈"),l1111_l1_ (u"ࠨࠩ℉"),l1111_l1_ (u"ࠩࠪℊ"),l1111_l1_ (u"ࠪࠫℋ"),l1111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩℌ"))
	html = response.content
	items = re.findall(l1111_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ℍ"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℎ"),l111_l1_+l1111_l1_ (u"ࠧࡠࡡࡢࠫℏ")+menu_name+title,l1ll11l_l1_,391,l1111_l1_ (u"ࠨࠩℐ"),l1111_l1_ (u"ࠩࠪℑ"),l1111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪℒ")+str(seq))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫℓ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ℔")+menu_name+l1111_l1_ (u"࠭ๅฯฬสีฬะฺࠠึ๋หห๐ษࠨℕ"),l1ll11l_l1_,391,l1111_l1_ (u"ࠧࠨ№"),l1111_l1_ (u"ࠨࠩ℗"),l1111_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ℘"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪℙ"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨℚ")+menu_name+l1111_l1_ (u"ࠬษูๅ๋ࠣห้ษแๅษ่ࠤฯ่๊๋็ส๏ࠬℛ"),l1ll11l_l1_,391,l1111_l1_ (u"࠭ࠧℜ"),l1111_l1_ (u"ࠧࠨℝ"),l1111_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡱࡴࡼࡩࡦࡵࠪ℞"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ℟"),l111_l1_+l1111_l1_ (u"ࠪࡣࡤࡥࠧ℠")+menu_name+l1111_l1_ (u"ࠫศ฿ไ๊ࠢสู่๊ไิๆสฮࠥะโ๋์่ห๐࠭℡"),l1ll11l_l1_,391,l1111_l1_ (u"ࠬ࠭™"),l1111_l1_ (u"࠭ࠧ℣"),l1111_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩℤ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ℥"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭Ω")+menu_name+l1111_l1_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨ℧"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬℨ"),391,l1111_l1_ (u"ࠬ࠭℩"),l1111_l1_ (u"࠭ࠧK"),l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩÅ"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨℬ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ℭ")+menu_name+l1111_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪ℮"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭ℯ"),391,l1111_l1_ (u"ࠬ࠭ℰ"),l1111_l1_ (u"࠭ࠧℱ"),l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷࡺࡸ࡮࡯ࡸࡵࠪℲ"))
	block = l1111_l1_ (u"ࠨࠩℳ")
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧℴ"),html,re.DOTALL)
	if l111l1l_l1_: block += l111l1l_l1_[0]
	response = l1l11l_l1_(l111ll_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧℵ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬℶ"),l1111_l1_ (u"ࠬ࠭ℷ"),l1111_l1_ (u"࠭ࠧℸ"),l1111_l1_ (u"ࠧࠨℹ"),l1111_l1_ (u"ࠨࠩ℺"),l1111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ℻"))
	html = response.content
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡲࡥࡢࡵࡨࡷࠧ࠮࠮ࠫࡁࠬࡥࡸ࡯ࡤࡦࠩℼ"),html,re.DOTALL)
	if l111l1l_l1_: block += l111l1l_l1_[0]
	l1l1l_l1_(l1111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩℽ"),l1111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬℾ"),l1111_l1_ (u"࠭ࠧℿ"),9999)
	items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⅀"),block,re.DOTALL)
	first = True
	for l1l111l_l1_,title in items:
		title = l1l1111_l1_(title)
		if title==l1111_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ⅁"):
			if first:
				title = l1111_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ⅂")+title
				first = False
			else: title = l1111_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ⅃")+title
		if title not in l11ll11_l1_:
			if title==l1111_l1_ (u"ࠫศ็ไศ็ࠪ⅄"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⅅ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪⅆ")+menu_name+title,l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨⅇ"),391,l1111_l1_ (u"ࠨࠩⅈ"),l1111_l1_ (u"ࠩࠪⅉ"),l1111_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⅊"))
			elif title==l1111_l1_ (u"ู๊ࠫไิๆสฮࠬ⅋"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅌"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪ⅍")+menu_name+title,l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩⅎ"),391,l1111_l1_ (u"ࠨࠩ⅏"),l1111_l1_ (u"ࠩࠪ⅐"),l1111_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⅑"))
			else: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⅒"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ⅓")+menu_name+title,l1l111l_l1_,391)
	return html
def l1l11l1_l1_(url,type):
	#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⅔"),l1111_l1_ (u"ࠧࠨ⅕"),url,type)
	#l111ll1l1_l1_(html)
	block,items = [],[]
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠨࡉࡈࡘࠬ⅖"),url,l1111_l1_ (u"ࠩࠪ⅗"),l1111_l1_ (u"ࠪࠫ⅘"),l1111_l1_ (u"ࠫࠬ⅙"),l1111_l1_ (u"ࠬ࠭⅚"),l1111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⅛"))
	html = response.content
	if type in [l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⅜"),l1111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⅝")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ⅞"),html,re.DOTALL)
		if l111l1l_l1_: block = l111l1l_l1_[0]
		#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ⅟"),l1111_l1_ (u"ࠫࠬⅠ"),url,block)
	elif type==l1111_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪⅡ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࡩࡥ࠿ࠥࡥࡷࡩࡨࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨⅢ"),html,re.DOTALL)
		if l111l1l_l1_: block = l111l1l_l1_[0]
	elif type==l1111_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡰࡳࡻ࡯ࡥࡴࠩⅣ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶ࡯ࡩ࡫ࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠫࡹࡵࡰ࠮࡫ࡰࡨࡧ࠳࡬ࡪࡵࡷࠤࡹࡸࡩࡨࡪࡷࠦⅤ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			#l1ll1l_l1_(l1111_l1_ (u"ࠩࠪⅥ"),l1111_l1_ (u"ࠪࠫⅦ"),str(len(block)),type)
			items = re.findall(l1111_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢⅧ"),block,re.DOTALL)
	elif type==l1111_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟ࡴࡧࡵ࡭ࡪࡹࠧⅨ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴࡳ࡫ࡪ࡬ࡹ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴࠥⅩ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨⅪ"),l1111_l1_ (u"ࠨࠩⅫ"),str(len(block)),type)
			items = re.findall(l1111_l1_ (u"ࠤ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧⅬ"),block,re.DOTALL)
	elif type==l1111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪⅭ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨⅮ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨⅯ"),block,re.DOTALL)
	elif type==l1111_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬⅰ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫⅱ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		z = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪⅲ"),block,re.DOTALL)
		l11lll1l_l1_,l1l111lll_l1_,l11111l_l1_ = zip(*z)
		items = zip(l1l111lll_l1_,l11lll1l_l1_,l11111l_l1_)
	elif type==l1111_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪⅳ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨⅴ"),html,re.DOTALL)
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⅵ"),block,re.DOTALL)
	elif l1111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬⅶ") in type:
		seq = int(type[-1:])
		html = html.replace(l1111_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨⅷ"),l1111_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭ⅸ"))
		html = html.replace(l1111_l1_ (u"ࠨ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ⅹ"),l1111_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡦࡰࡧࡂࠬⅺ"))
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧⅻ"),html,re.DOTALL)
		block = l111l1l_l1_[seq]
		if seq==6:
			z = re.findall(l1111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⅼ"),block,re.DOTALL)
			l1l111lll_l1_,l11111l_l1_,l11lll1l_l1_ = zip(*z)
			items = zip(l1l111lll_l1_,l11lll1l_l1_,l11111l_l1_)
	else:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫⅽ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0][0]
			if l1111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬⅾ") in url:
				items = re.findall(l1111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⅿ"),block,re.DOTALL)
			elif l1111_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫↀ") in url:
				items = re.findall(l1111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨↁ"),block,re.DOTALL)
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫↂ"),l1111_l1_ (u"ࠫࠬↃ"),str(len(items)),type)
	if not items and block:
		items = re.findall(l1111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧↄ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	for img,l1l111l_l1_,title in items:
		if l1111_l1_ (u"࠭ࡳࡳࡥࡀࠫↅ") in title: continue
		if l1111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭ↆ") in title:
			title = re.findall(l1111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫↇ"),title,re.DOTALL)
			title = title[0][1]#+l1111_l1_ (u"ࠩࠣ࠱ࠥ࠭ↈ")+title[0][0]
			if title in l1lllll1_l1_: continue
			l1lllll1_l1_.append(title)
			title = l1111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ↉")+title
		title2 = re.findall(l1111_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ↊"),title,re.DOTALL)
		if title2: title = title2[0]
		title = l1l1111_l1_(title)
		if l1111_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ↋") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↌"),menu_name+title,l1l111l_l1_,393,img)
		elif l1111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ↍") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↎"),menu_name+title,l1l111l_l1_,393,img)
		elif l1111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ↏") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ←"),menu_name+title,l1l111l_l1_,393,img)
		elif l1111_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ↑") in l1l111l_l1_: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ→"),menu_name+title,l1l111l_l1_,391,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ↓"),menu_name+title,l1l111l_l1_,392,img)
	if type not in [l1111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ↔"),l1111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ↕")]:
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁุๅาฯࠠࠩ࠰࠭ࡃ࠮ࠦๅ็ࠢࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭↖"),html,re.DOTALL)
		if l111l1l_l1_:
			current = l111l1l_l1_[0][0]
			last = l111l1l_l1_[0][1]
			block = l111l1l_l1_[0][2]
			items = re.findall(l1111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ↗"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if title==l1111_l1_ (u"ࠫࠬ↘") or title==last: continue
				l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ↙"),menu_name+l1111_l1_ (u"࠭ีโฯฬࠤࠬ↚")+title,l1l111l_l1_,391,l1111_l1_ (u"ࠧࠨ↛"),l1111_l1_ (u"ࠨࠩ↜"),type)
			#if title==last:
			l1l111l_l1_ = l1l111l_l1_.replace(l1111_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ↝")+title+l1111_l1_ (u"ࠪ࠳ࠬ↞"),l1111_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ↟")+last+l1111_l1_ (u"ࠬ࠵ࠧ↠"))
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↡"),menu_name+l1111_l1_ (u"ࠧศะิࠤฺ็อสࠢࠪ↢")+last,l1l111l_l1_,391,l1111_l1_ (u"ࠨࠩ↣"),l1111_l1_ (u"ࠩࠪ↤"),type)
	return
def l1l11ll_l1_(url):
	#l1ll1l_l1_(l1111_l1_ (u"ࠪࠫ↥"),l1111_l1_ (u"ࠫࠬ↦"),l1111_l1_ (u"ࠬ࠭↧"),url)
	server = l1l1lll1l_l1_(url,l1111_l1_ (u"࠭ࡵࡳ࡮ࠪ↨"))
	url = url.replace(server,l1ll11l_l1_)
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ↩"),l1111_l1_ (u"ࠨࠩ↪"),server,url)
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭↫"),url,l1111_l1_ (u"ࠪࠫ↬"),l1111_l1_ (u"ࠫࠬ↭"),l1111_l1_ (u"ࠬ࠭↮"),l1111_l1_ (u"࠭ࠧ↯"),l1111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ↰"))
	html = response.content
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭↱"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	if l1111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭↲") in url or l1111_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭↳") in url:# or l1111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ↴") in url:
		l1l1lll_l1_ = re.findall(l1111_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡪࡶࡨࡱࠬࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ↵"),html,re.DOTALL)
		if l1l1lll_l1_:
			l1l1lll_l1_ = l1l1lll_l1_[1]
			l1l11ll_l1_(l1l1lll_l1_)
			return
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽࡜ࠩࠥࡡࡪࡶࡩࡴࡱࡧ࡭ࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩࠪࠫ↶"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡱࡹࡲ࡫ࡲࡢࡰࡧࡳࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ↷"),block,re.DOTALL)
		for img,l11l11l_l1_,l1l111l_l1_,name in items:
			title = l11l11l_l1_+l1111_l1_ (u"ࠨࠢ࠽ࠤࠬ↸")+name
			if l1111_l1_ (u"ࠩส่า๊โสࠩ↹") not in title: title = title+l1111_l1_ (u"ࠪࠤฬ๊อๅไฬࠫ↺")
			l1l1l_l1_(l1111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ↻"),menu_name+title,l1l111l_l1_,392)
	return
def l1lllll_l1_(url):
	html = l1ll1l1l11_l1_(l1111l1_l1_,l1111_l1_ (u"ࠬࡍࡅࡕࠩ↼"),url,l1111_l1_ (u"࠭ࠧ↽"),l1111_l1_ (u"ࠧࠨ↾"),l1111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭↿"))
	#response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭⇀"),url,l1111_l1_ (u"ࠪࠫ⇁"),l1111_l1_ (u"ࠫࠬ⇂"),l1111_l1_ (u"ࠬ࠭⇃"),l1111_l1_ (u"࠭ࠧ⇄"),l1111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⇅"))
	#html = response.content
	if kodi_version>18.99: html = html.decode(l1111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⇆"))
	l1llll_l1_ = re.findall(l1111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⇇"),html,re.DOTALL)
	if l1llll_l1_ and l1l1ll_l1_(l111_l1_,url,l1llll_l1_): return
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸ࠭ࡰࡲࡷ࡭ࡴࡴ࠭࠲ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃ࡛ࠣࡾ࡟ࠫࡢ࠮ࡳࡩࡧࡤࡨࡪࡸࡼࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠯࡛ࠣࡾ࡟ࠫࡢ࠭⇈"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0][0]
		items = re.findall(l1111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡽࡵ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡰࡰࡵࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡲࡺࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡠࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⇉"),block,re.DOTALL)
		for type,l1111ll11l_l1_,l1llll1lll1_l1_,title in items:
			#l1l111l_l1_ = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡺ࠲ࡦࡲࡦࡢ࡬ࡨࡶࡹࡼ࠮ࡤࡱࡰ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶࠧ⇊")
			l1l111l_l1_ = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࡤࡨࡲ࡯࡮࠮ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡨࡴࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࡟ࡢ࡬ࡤࡼࠫࡶ࡯ࡴࡶࡀࠫ⇋")+l1111ll11l_l1_+l1111_l1_ (u"ࠧࠧࡰࡸࡱࡪࡃࠧ⇌")+l1llll1lll1_l1_+l1111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࠨ⇍")+type
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⇎")+title+l1111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⇏")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	#l111ll1l1_l1_(html)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠦ࡮ࡪ࠽ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪࠤࡨࡲࡡࡴࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃ࡛࡝ࠤࡿࠫࡢࡹࡢࡰࡺ࡞ࡠࠧࢂࠧ࡞ࠤ⇐"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࡯࡭ࡨࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࠫࡶࡻࡡ࡭࡫ࡷࡽࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠧ⇑"),block,re.DOTALL)
		#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧ⇒"),l1111_l1_ (u"ࠧࠨ⇓"),str(items),str(block))
		for img,l1l111l_l1_,l11l1111_l1_,lang in items:
			if l1111_l1_ (u"ࠨ࠿ࠪ⇔") in img:
				host = img.split(l1111_l1_ (u"ࠩࡀࠫ⇕"))[1]
				title = l1l1lll1l_l1_(host,l1111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ⇖"))
			else: title = l1111_l1_ (u"ࠫࠬ⇗")
			title = lang+l1111_l1_ (u"ࠬࠦࠧ⇘")+title
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⇙")+title+l1111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ⇚")+l11l1111_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⇛"), l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⇜"),url)
	return
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠪࠫ⇝"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠫࠬ⇞"): return
	search = search.replace(l1111_l1_ (u"ࠬࠦࠧ⇟"),l1111_l1_ (u"࠭ࠫࠨ⇠"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⇡")+search
	l1l11l1_l1_(url,l1111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⇢"))
	return
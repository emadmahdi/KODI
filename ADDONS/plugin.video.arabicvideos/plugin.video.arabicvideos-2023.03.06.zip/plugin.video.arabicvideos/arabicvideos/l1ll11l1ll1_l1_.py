# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ⑯")
menu_name=l1111_l1_ (u"ࠫࡤࡎࡌࡄࡡࠪ⑰")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"๋ࠬีศำ฼อࠬ⑱"),l1111_l1_ (u"࠭วฮัฮࠤฬ๊ศาษ่ะࠬ⑲"),l1111_l1_ (u"ࠧศฯาฯࠥอไศๆ฼หอ࠭⑳"),l1111_l1_ (u"ࠨษะำะࠦวๅษ฽ห๋๏ࠧ⑴")]
def l1111ll_l1_(mode,url,text):
	if   mode==80: l11l_l1_ = l11l111_l1_()
	elif mode==81: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==82: l11l_l1_ = l1lllll_l1_(url)
	elif mode==83: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==89: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠩࡊࡉ࡙࠭⑵"),l1ll11l_l1_,l1111_l1_ (u"ࠪࠫ⑶"),l1111_l1_ (u"ࠫࠬ⑷"),l1111_l1_ (u"ࠬ࠭⑸"),l1111_l1_ (u"࠭ࠧ⑹"),l1111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⑺"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1ll11l_l1_,l1111_l1_ (u"ࠨࡷࡵࡰࠬ⑻"))
	l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⑼"),menu_name+l1111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⑽"),l1111_l1_ (u"ࠫࠬ⑾"),89,l1111_l1_ (u"ࠬ࠭⑿"),l1111_l1_ (u"࠭ࠧ⒀"),l1111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⒁"))
	l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒂"),menu_name+l1111_l1_ (u"ࠩสาฯืๆศࠢ็็ࠬ⒃"),l1llll1lll_l1_,81,l1111_l1_ (u"ࠪࠫ⒄"),l1111_l1_ (u"ࠫࠬ⒅"),l1111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⒆"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⒇"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⒈"),block,re.DOTALL)
	for l11111l1l_l1_,title in items:
		l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࡀ࡫ࡷࡩࡲࡃࠧ⒉")+l11111l1l_l1_+l1111_l1_ (u"ࠩࠩࡅ࡯ࡧࡸ࠾࠳ࠪ⒊")
		l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒋"),l111_l1_+l1111_l1_ (u"ࠫࡤࡥ࡟ࠨ⒌")+menu_name+title,l1l111l_l1_,81)
	l1l1l_l1_(l1111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒍"),l1111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⒎"),l1111_l1_ (u"ࠧࠨ⒏"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡱࡥࡻ࠳࡭ࡢ࡫ࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧࡶ࠿ࠩ⒐"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⒑"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if l1l111l_l1_==l1111_l1_ (u"ࠪࠧࠬ⒒"): continue
		if title in l11ll11_l1_: continue
		l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⒓"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩ⒔")+menu_name+title,l1l111l_l1_,81)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"࠭ࠧ⒕")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ⒖"),l1111_l1_ (u"ࠨࠩ⒗"),url)
	items = []
	# l1lll1ll11_l1_ l1lll1ll1l_l1_
	if l1111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩ⒘") in url or l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫ⒙") in url:
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⒚"):l1111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ⒛")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"࠭ࡐࡐࡕࡗࠫ⒜"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠧࠨ⒝"),l1111_l1_ (u"ࠨࠩ⒞"),l1111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⒟"))
		html = response.content
		l111l1l_l1_ = [html]
	else:
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧ⒠"),url,l1111_l1_ (u"ࠫࠬ⒡"),l1111_l1_ (u"ࠬ࠭⒢"),l1111_l1_ (u"࠭ࠧ⒣"),l1111_l1_ (u"ࠧࠨ⒤"),l1111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⒥"))
		html = response.content
		# l11111l1l_l1_ items
		if l11111l1l_l1_==l1111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ⒦"):
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⒧"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⒨"),block,re.DOTALL)
			#l1ll1l_l1_(l1111_l1_ (u"ࠬ࠭⒩"),l1111_l1_ (u"࠭ࠧ⒪"),l1111_l1_ (u"ࠧࠨ⒫"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l1111_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠨ⒬") in html:
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⒭"),html,re.DOTALL)
		else:
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࡀࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ⒮"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	if not items:
		items = re.findall(l1111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡳࡷ࡯ࡧࡪࡰࡤࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⒯"),block,re.DOTALL)
		if not items: items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⒰"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"࠭ๅีษ๊ำฮ࠭⒱"),l1111_l1_ (u"ࠧโ์็้ࠬ⒲"),l1111_l1_ (u"ࠨษ฽๊๏ฯࠧ⒳"),l1111_l1_ (u"ࠩๆ่๏ฮࠧ⒴"),l1111_l1_ (u"ࠪห฾๊ว็ࠩ⒵"),l1111_l1_ (u"ࠫ์ีวโࠩⒶ"),l1111_l1_ (u"๋ࠬศศำสอࠬⒷ"),l1111_l1_ (u"ู࠭าุࠪⒸ"),l1111_l1_ (u"ࠧๆ้ิะฬ์ࠧⒹ"),l1111_l1_ (u"ࠨษ็ฬํ๋ࠧⒺ")]
	for l1l111l_l1_,title,img in items:
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠩ࠲ࠫⒻ"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭Ⓖ"),title,re.DOTALL)
		if l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭Ⓗ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⒾ"),menu_name+title,l1l111l_l1_,83,img)
		elif l1111_l1_ (u"࠭ำๅษึ่ࠬⒿ") not in url and any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ⓚ"),menu_name+title,l1l111l_l1_,82,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠨษ็ั้่ษࠨⓁ") in title:
			title = l1111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨⓂ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓃ"),menu_name+title,l1l111l_l1_,83,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭Ⓞ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓅ"),menu_name+title,l1l111l_l1_,81,img)
		else: l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓠ"),menu_name+title,l1l111l_l1_,83,img)
	if l11111l1l_l1_==l1111_l1_ (u"ࠧࠨⓇ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬⓈ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫⓉ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1l111l_l1_==l1111_l1_ (u"ࠥࠦⓊ"): continue
				#title = l1l1111_l1_(title)
				if title!=l1111_l1_ (u"ࠫࠬⓋ"): l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓌ"),menu_name+l1111_l1_ (u"࠭ีโฯฬࠤࠬⓍ")+title,l1l111l_l1_,81)
	if l1111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧⓎ") in url or l1111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩⓏ") in url:
		if l1111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩⓐ") in url:
			url = url.replace(l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪⓑ"),l1111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬⓒ"))+l1111_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃ࠲࠱ࠩⓓ")
		elif l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧⓔ") in url:
			url,offset = url.split(l1111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩⓕ"))
			offset = int(offset)+20
			url = url+l1111_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪⓖ")+str(offset)
		l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓗ"),menu_name+l1111_l1_ (u"๋๋ࠪอใࠡษ็้ื๐ฯࠨⓘ"),url,81)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨⓙ"),url,l1111_l1_ (u"ࠬ࠭ⓚ"),l1111_l1_ (u"࠭ࠧⓛ"),l1111_l1_ (u"ࠧࠨⓜ"),l1111_l1_ (u"ࠨࠩⓝ"),l1111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪⓞ"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠪࠦ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࡃࡻࡖࡩࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫⓟ"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡲࡩࡴࡶ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨⓠ"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧⓡ") not in url:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⓢ"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			l1l1l_l1_(l1111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⓣ"),menu_name+title,l1l111l_l1_,83,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		img = re.findall(l1111_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⓤ"),html,re.DOTALL)
		img = img[0]
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⓥ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#title = title.replace(l1111_l1_ (u"ࠪࡠࡳ࠭ⓦ"),l1111_l1_ (u"ࠫࠬⓧ")).strip(l1111_l1_ (u"ࠬࠦࠧⓨ"))
			l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⓩ"),menu_name+title,l1l111l_l1_,82,img)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url.replace(l1111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⓪"),l1111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⓫"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⓬"),l1111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⓭"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨ⓮"),l1l1lll_l1_,l1111_l1_ (u"ࠬ࠭⓯"),l1111_l1_ (u"࠭ࠧ⓰"),l1111_l1_ (u"ࠧࠨ⓱"),l1111_l1_ (u"ࠨࠩ⓲"),l1111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⓳"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧ⓴"))
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⓵"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l11lllll_l1_ = re.findall(l1111_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⓶"),html,re.DOTALL)
		l11lllll_l1_ = l11lllll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ⓷"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1111_l1_ (u"ࠧ࡝ࡰࠪ⓸"),l1111_l1_ (u"ࠨࠩ⓹")).strip(l1111_l1_ (u"ࠩࠣࠫ⓺"))
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭⓻")+server+l1111_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭⓼")+l11lllll_l1_+l1111_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭⓽")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⓾")+title+l1111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⓿")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠨࠤࡧࡳࡼࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ─"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ━"),block,re.DOTALL)
		for l1l111l_l1_,name in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ│")+name+l1111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ┃")
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ┄"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ┅"),url)
	return
l1111_l1_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡑࡎࡄ࡝ࡤࡕࡌࡅࠪࡸࡶࡱ࠯࠺ࠋࠋࡧࡥࡹࡧࠠ࠾ࠢࡾ࡛ࠫ࡯ࡥࡸࠩ࠽࠵ࢂࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ࠿࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬࢃࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡓࡓࡘ࡚ࠧ࠭ࡷࡵࡰ࠱ࡪࡡࡵࡣ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡡ࡝ࠋࠋࠦࠤࡼࡧࡴࡤࡪࠣࡰ࡮ࡴ࡫ࡴࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡺࡥࡹࡩࡨࡂࡴࡨࡥࡒࡧࡳࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧࠋࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠣࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡰ࡮ࡴ࡫ࡴࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡧࡳࡳࡽ࡬ࡰࡣࡧ࠱ࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡹࡥࡳ࠯ࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠࡵ࡫ࡷࡰࡪ࠲ࡱࡶࡣ࡯࡭ࡹࡿࠬ࡭࡫ࡱ࡯ࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ࠫࠨࡡࡢࡣࡤ࠭ࠫࡲࡷࡤࡰ࡮ࡺࡹࠋࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠋࠋ࡬ࡪࠥࡲࡥ࡯ࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭ࡂࡃ࠰࠻ࠢࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠮ࠪห้ืวษู่ࠣ๏ูࠠโ์๊ࠤๆ๐ฯ๋๊ࠪ࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࡪ࡯ࡳࡳࡷࡺࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠍࠍࠎࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ┆")
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠨࠩ┇"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠩࠪ┈"): return
	search = search.replace(l1111_l1_ (u"ࠪࠤࠬ┉"),l1111_l1_ (u"ࠫ࠲࠭┊"))
	url = l1ll11l_l1_+l1111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ┋")+search+l1111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ┌")
	l1l11l1_l1_(url)
	return
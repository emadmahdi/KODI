# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠫࡋࡇࡖࡐࡗࡕࡍ࡙ࡋࡓࠨ⇳")
def l1111ll_l1_(mode,l1lll1l111l_l1_):
	if   mode==270: l11l_l1_ = l11l111_l1_(l1lll1l111l_l1_)
	#elif mode==271: l11l_l1_ = l1lll111lll_l1_(l1lll1l111l_l1_)
	else: l11l_l1_ = False
	return l11l_l1_
def l1lll1lll1l_l1_(context):
	if not context: return
	if l1111_l1_ (u"ࠬࡥࠧ⇴") in context: favouriteID,l1lll111l1l_l1_ = context.split(l1111_l1_ (u"࠭࡟ࠨ⇵"),1)
	else: favouriteID,l1lll111l1l_l1_ = context,l1111_l1_ (u"ࠧࠨ⇶")
	if   l1lll111l1l_l1_==l1111_l1_ (u"ࠨࡗࡓ࠵ࠬ⇷")	: l1lll11l1l1_l1_(favouriteID,True,1)
	elif l1lll111l1l_l1_==l1111_l1_ (u"ࠩࡇࡓ࡜ࡔ࠱ࠨ⇸")	: l1lll11l1l1_l1_(favouriteID,False,1)
	elif l1lll111l1l_l1_==l1111_l1_ (u"࡙ࠪࡕ࠺ࠧ⇹")	: l1lll11l1l1_l1_(favouriteID,True,4)
	elif l1lll111l1l_l1_==l1111_l1_ (u"ࠫࡉࡕࡗࡏ࠶ࠪ⇺")	: l1lll11l1l1_l1_(favouriteID,False,4)
	elif l1lll111l1l_l1_==l1111_l1_ (u"ࠬࡇࡄࡅ࠳ࠪ⇻")	: l1lll1l1ll1_l1_(favouriteID)
	elif l1lll111l1l_l1_==l1111_l1_ (u"࠭ࡒࡆࡏࡒ࡚ࡊ࠷ࠧ⇼"): l1lll11l111_l1_(favouriteID)
	elif l1lll111l1l_l1_==l1111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࡌࡊࡕࡗࠫ⇽"): l1lll111lll_l1_(favouriteID)
	return
def l11l111_l1_(favouriteID):
	favouritesDICT = l1lll11llll_l1_()
	if favouriteID in list(favouritesDICT.keys()):
		#l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⇾"),l1111_l1_ (u"่ࠩืาࠦ็ั้ࠣห้่วว็ฬࠫ⇿"),l1111_l1_ (u"ࠪࠫ∀"),271,l1111_l1_ (u"ࠫࠬ∁"),l1111_l1_ (u"ࠬ࠭∂"),l1111_l1_ (u"࠭ࠧ∃"),favouriteID)
		#l1l1l_l1_(l1111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ∄"),l1111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ∅"),l1111_l1_ (u"ࠩࠪ∆"),9999)
		try:
			l1lll1lll11_l1_ = favouritesDICT[favouriteID]
			for type,name,url,mode,image,page,text,context,infodict in l1lll1lll11_l1_:
				l1l1l_l1_(type,name,url,mode,image,page,text,context,infodict)
		except:
			favouritesDICT = l1lll1ll11l_l1_(l1lll1l1111_l1_,False)
			l1lll1lll11_l1_ = favouritesDICT[favouriteID]
			for type,name,url,mode,image,page,text,context,infodict in l1lll1lll11_l1_:
				l1l1l_l1_(type,name,url,mode,image,page,text,context,infodict)
	return
def l1lll1l1ll1_l1_(favouriteID):
	type,name,url,mode,image,page,text,context,infodict = l1lll11ll1l_l1_(addon_path)
	#name = RESTORE_PATH_NAME(ltr,rtl,name)
	menuItem = (type,name,url,mode,image,page,text,l1111_l1_ (u"ࠪࠫ∇"),l1111_l1_ (u"ࠫࠬ∈"))
	favouritesDICT = l1lll11llll_l1_()
	l1lll1ll111_l1_ = {}
	for l1lll11l1ll_l1_ in list(favouritesDICT.keys()):
		if l1lll11l1ll_l1_!=favouriteID: l1lll1ll111_l1_[l1lll11l1ll_l1_] = favouritesDICT[l1lll11l1ll_l1_]
		else:
			if name and name!=l1111_l1_ (u"ࠬ࠴࠮ࠨ∉"):
				l1lll1l1lll_l1_ = favouritesDICT[l1lll11l1ll_l1_]
				if menuItem in l1lll1l1lll_l1_:
					index = l1lll1l1lll_l1_.index(menuItem)
					del l1lll1l1lll_l1_[index]
				l111l11ll1_l1_ = l1lll1l1lll_l1_+[menuItem]
				l1lll1ll111_l1_[l1lll11l1ll_l1_] = l111l11ll1_l1_
			else: l1lll1ll111_l1_[l1lll11l1ll_l1_] = favouritesDICT[l1lll11l1ll_l1_]
	if favouriteID not in list(l1lll1ll111_l1_.keys()): l1lll1ll111_l1_[favouriteID] = [menuItem]
	l1lll1ll1l1_l1_ = str(l1lll1ll111_l1_)
	if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.encode(l1111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ∊"))
	open(l1lll1l1111_l1_,l1111_l1_ (u"ࠧࡸࡤࠪ∋")).write(l1lll1ll1l1_l1_)
	return
def l1lll11l111_l1_(favouriteID):
	type,name,url,mode,image,page,text,context,infodict = l1lll11ll1l_l1_(addon_path)
	#name = RESTORE_PATH_NAME(ltr,rtl,name)
	menuItem = (type,name,url,mode,image,page,text,l1111_l1_ (u"ࠨࠩ∌"),l1111_l1_ (u"ࠩࠪ∍"))
	favouritesDICT = l1lll11llll_l1_()
	if favouriteID in list(favouritesDICT.keys()) and menuItem in favouritesDICT[favouriteID]:
		favouritesDICT[favouriteID].remove(menuItem)
		if len(favouritesDICT[favouriteID])==0: del favouritesDICT[favouriteID]
		l1lll1ll1l1_l1_ = str(favouritesDICT)
		if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.encode(l1111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ∎"))
		open(l1lll1l1111_l1_,l1111_l1_ (u"ࠫࡼࡨࠧ∏")).write(l1lll1ll1l1_l1_)
	return
def l1lll11l1l1_l1_(favouriteID,l1lll1ll1ll_l1_,l1lll1l11l1_l1_):
	type,name,url,mode,image,page,text,context,infodict = l1lll11ll1l_l1_(addon_path)
	#name = RESTORE_PATH_NAME(ltr,rtl,name)
	menuItem = (type,name,url,mode,image,page,text,l1111_l1_ (u"ࠬ࠭∐"),l1111_l1_ (u"࠭ࠧ∑"))
	favouritesDICT = l1lll11llll_l1_()
	if favouriteID in list(favouritesDICT.keys()):
		l1lll1l1lll_l1_ = favouritesDICT[favouriteID]
		#l111ll1l1_l1_(name+l1111_l1_ (u"ࠧࠡ࠭࠮࠯࠰࠱ࠫࠬ࠭࠮࠯࠰ࠦࠧ−")+str(name)+l1111_l1_ (u"ࠨࠢ࠮࠯࠰࠱ࠫࠬ࠭࠮࠯࠰࠱ࠠࠨ∓")+str(l1111_l1_ (u"ࠩࠪ∔"))+l1111_l1_ (u"ࠪࠤ࠰࠱ࠫࠬ࠭࠮࠯࠰࠱ࠫࠬ࠭࠮࠯࠰ࠦࠧ∕")+str(l1lll1l1lll_l1_[0]))
		if menuItem not in l1lll1l1lll_l1_: return
		size = len(l1lll1l1lll_l1_)
		for i in range(0,l1lll1l11l1_l1_):
			l1lll11lll1_l1_ = l1lll1l1lll_l1_.index(menuItem)
			if l1lll1ll1ll_l1_: l1lll11l11l_l1_ = l1lll11lll1_l1_-1
			else: l1lll11l11l_l1_ = l1lll11lll1_l1_+1
			if l1lll11l11l_l1_>=size: l1lll11l11l_l1_ = l1lll11l11l_l1_-size
			if l1lll11l11l_l1_<0: l1lll11l11l_l1_ = l1lll11l11l_l1_+size
			l1lll1l1lll_l1_.insert(l1lll11l11l_l1_, l1lll1l1lll_l1_.pop(l1lll11lll1_l1_))
		favouritesDICT[favouriteID] = l1lll1l1lll_l1_
		l1lll1ll1l1_l1_ = str(favouritesDICT)
		if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.encode(l1111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ∖"))
		open(l1lll1l1111_l1_,l1111_l1_ (u"ࠬࡽࡢࠨ∗")).write(l1lll1ll1l1_l1_)
	return
def l1lll111lll_l1_(favouriteID):
	l1l1l1l111_l1_ = l1l11l1l11_l1_(l1111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭∘"),l1111_l1_ (u"ࠧࠨ∙"),l1111_l1_ (u"ࠨࠩ√"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ∛"),l1111_l1_ (u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤ๊ำส้์สฮ่ࠥวว็ฬࠤฬ๊ๅโุ็อࠥ࠭∜")+favouriteID+l1111_l1_ (u"ࠫࠥลࠡࠨ∝"))
	if l1l1l1l111_l1_!=1: return
	favouritesDICT = l1lll11llll_l1_()
	if favouriteID in list(favouritesDICT.keys()):
		del favouritesDICT[favouriteID]
		l1lll1ll1l1_l1_ = str(favouritesDICT)
		if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.encode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ∞"))
		open(l1lll1l1111_l1_,l1111_l1_ (u"࠭ࡷࡣࠩ∟")).write(l1lll1ll1l1_l1_)
		l1ll1l_l1_(l1111_l1_ (u"ࠧࠨ∠"),l1111_l1_ (u"ࠨࠩ∡"),l1111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ∢"),l1111_l1_ (u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡ็ะฮํ๐วหࠢๅหห๋ษࠡษ็้ๆ฼ไสࠢࠪ∣")+favouriteID)
	return
def l1lll11llll_l1_(l1lll111ll1_l1_=False):
	if os.path.exists(l1lll1l1111_l1_):
		l1lll1llll1_l1_ = open(l1lll1l1111_l1_,l1111_l1_ (u"ࠫࡷࡨࠧ∤")).read()
		if kodi_version>18.99: l1lll1llll1_l1_ = l1lll1llll1_l1_.decode(l1111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ∥"))
		favouritesDICT = l1lll11ll11_l1_(l1111_l1_ (u"࠭ࡤࡪࡥࡷࠫ∦"),l1lll1llll1_l1_,l1lll1l1111_l1_)
		if favouritesDICT and l1lll111ll1_l1_:
			l1lll1l1l11_l1_ = {}
			for favouriteID in favouritesDICT.keys():
				l1lll1l1l11_l1_[favouriteID] = []
				for menuItem in favouritesDICT[favouriteID]:
					type,name,url,mode,image,page,text,context,infodict = menuItem
					l1lll1l1l1l_l1_ = type,name,url,mode,image,l1111_l1_ (u"ࠧࠨ∧"),text,context,l1111_l1_ (u"ࠨࠩ∨")
					l1lll1l1l11_l1_[favouriteID].append(l1lll1l1l1l_l1_)
			favouritesDICT = l1lll1l1l11_l1_
	else: favouritesDICT = {}
	return favouritesDICT
l1111_l1_ (u"ࠤࠥࠦࠒࠐࡤࡦࡨࠣࡊࡎ࡞࡟ࡐࡎࡇࡣࡋࡇࡖࡐࡗࡕࡍ࡙ࡋ࡟ࡊࡖࡈࡑࡘ࠮ࠩ࠻ࠏࠍࠍࡳ࡫ࡷࡅࡋࡆࡘࠥࡃࠠࡼࡿࠐࠎࠎ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴࡆࡌࡇ࡙ࠦ࠽ࠡࡉࡈࡘࡤࡇࡌࡍࡡࡉࡅ࡛ࡕࡕࡓࡋࡗࡉࡘ࠮ࠩࠎࠌࠌࡪࡴࡸࠠࡧࡣࡹࡳࡺࡸࡩࡵࡧࡌࡈࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵࡇࡍࡈ࡚࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠏࠍࠍࠎࡴࡥࡸࡆࡌࡇ࡙ࡡࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡋࡇࡡࠥࡃࠠ࡜࡟ࠐࠎࠎࠏ࡭ࡦࡰࡸࡐࡎ࡙ࡔࠡ࠿ࠣࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹࡄࡊࡅࡗ࡟࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡉࡅ࡟ࠐࠎࠎࠏࡦࡰࡴࠣࡸࡾࡶࡥ࠭ࡰࡤࡱࡪ࠲ࡵࡳ࡮࠯ࡱࡴࡪࡥ࠭࡫ࡰࡥ࡬࡫ࠬࡱࡣࡪࡩ࠱ࡺࡥࡹࡶ࠯ࡧࡴࡴࡴࡦࡺࡷ࠰࡮ࡴࡦࡰࡦ࡬ࡧࡹࠦࡩ࡯ࠢࡰࡩࡳࡻࡌࡊࡕࡗ࠾ࠒࠐࠉࠊࠋࠦࡲࡦࡳࡥࠡ࠿ࠣࡖࡊ࡙ࡔࡐࡔࡈࡣࡕࡇࡔࡉࡡࡑࡅࡒࡋࠨ࡭ࡶࡵ࠰ࡷࡺ࡬࠭ࡰࡤࡱࡪ࠯ࠍࠋࠋࠌࠍࡲ࡫࡮ࡶࡋࡷࡩࡲࠦ࠽ࠡࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩ࠱ࡻࡲ࡭࠮ࡰࡳࡩ࡫ࠬࡪ࡯ࡤ࡫ࡪ࠲ࡰࡢࡩࡨ࠰ࡹ࡫ࡸࡵ࠮ࠪࠫ࠱࠭ࠧࠪࠏࠍࠍࠎࠏ࡮ࡦࡹࡇࡍࡈ࡚࡛ࡧࡣࡹࡳࡺࡸࡩࡵࡧࡌࡈࡢ࠴ࡡࡱࡲࡨࡲࡩ࠮࡭ࡦࡰࡸࡍࡹ࡫࡭ࠪࠏࠍࠍࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠࡴࡶࡵࠬࡳ࡫ࡷࡅࡋࡆࡘ࠮ࠓࠊࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡲࡪࡽࡆࡊࡎࡈࠤࡂࠦ࡮ࡦࡹࡉࡍࡑࡋ࠮ࡦࡰࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠎࠌࠌࡳࡵ࡫࡮ࠩࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷ࡫࡯࡬ࡦ࠮ࠪࡻࡧ࠭ࠩ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡯ࡧࡺࡊࡎࡒࡅࠪࠏࠍࠍࡷ࡫ࡴࡶࡴࡱࠑࠏࠨࠢࠣ∩")
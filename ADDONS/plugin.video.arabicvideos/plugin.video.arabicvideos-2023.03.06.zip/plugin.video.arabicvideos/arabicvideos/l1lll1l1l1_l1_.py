# -*- coding: utf-8 -*-
import sys
l11lll1_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1l11_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11l1l_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11l1l_l1_)
    l1ll1_l1_ = l11l1l_l1_ [:l1lll_l1_] + l11l1l_l1_ [l1lll_l1_:]
    if l11lll1_l1_:
        l1l1l1l_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1l1l_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l111l_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1l1l_l1_)
from l1l1l1_l1_ import *
l111_l1_=l1111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᐒ")
menu_name=l1111_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧᐓ")
l1ll11l_l1_ = l111lll_l1_[l111_l1_][0]
l11ll11_l1_ = [l1111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᐔ")]
def l1111ll_l1_(mode,url,text):
	if   mode==550: l11l_l1_ = l11l111_l1_()
	elif mode==551: l11l_l1_ = l1l11l1_l1_(url,text)
	elif mode==552: l11l_l1_ = l1lllll_l1_(url)
	elif mode==553: l11l_l1_ = l1l11ll_l1_(url)
	elif mode==559: l11l_l1_ = l1lll1_l1_(text)
	else: l11l_l1_ = False
	return l11l_l1_
def l11l111_l1_():
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᐕ"),l1ll11l_l1_+l1111_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᐖ"),l1111_l1_ (u"ࠬ࠭ᐗ"),l1111_l1_ (u"࠭ࠧᐘ"),l1111_l1_ (u"ࠧࠨᐙ"),l1111_l1_ (u"ࠨࠩᐚ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᐛ"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1ll11l_l1_,l1111_l1_ (u"ࠪࡹࡷࡲࠧᐜ"))
	l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐝ"),menu_name+l1111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᐞ"),l1111_l1_ (u"࠭ࠧᐟ"),559,l1111_l1_ (u"ࠧࠨᐠ"),l1111_l1_ (u"ࠨࠩᐡ"),l1111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᐢ"))
	l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐣ"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐤ"),l1111_l1_ (u"ࠬ࠭ᐥ"),9999)
	l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐦ"),menu_name+l1111_l1_ (u"ࠧศะอี๋อࠠๅๅࠪᐧ"),l1llll1lll_l1_,551,l1111_l1_ (u"ࠨࠩᐨ"),l1111_l1_ (u"ࠩࠪᐩ"),l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᐪ"))
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᐫ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᐬ"),block,re.DOTALL)
	for l11111l1l_l1_,title in items:
		l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲࡅࡩࡵࡧࡰࡁࠬᐭ")+l11111l1l_l1_+l1111_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨᐮ")
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐯ"),l111_l1_+l1111_l1_ (u"ࠩࡢࡣࡤ࠭ᐰ")+menu_name+title,l1l111l_l1_,551)
	#l1l1l_l1_(l1111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐱ"),l1111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐲ"),l1111_l1_ (u"ࠬ࠭ᐳ"),9999)
	l111l1l_l1_ = re.findall(l1111_l1_ (u"࠭ࠢ࡯ࡣࡹ࠱ࡲࡧࡩ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡻࡄࠧᐴ"),html,re.DOTALL)
	block = l111l1l_l1_[0]
	items = re.findall(l1111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᐵ"),block,re.DOTALL)
	for l1l111l_l1_,title in items:
		if l1l111l_l1_==l1111_l1_ (u"ࠨࠥࠪᐶ"): continue
		if title in l11ll11_l1_: continue
		if l1111_l1_ (u"่ࠩืู้ไࠡࠩᐷ") in title: continue
		if l1111_l1_ (u"ࠪวาีหࠨᐸ") in title: l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐹ"),l111_l1_+l1111_l1_ (u"ࠬࡥ࡟ࡠࠩᐺ")+menu_name+title,l1l111l_l1_,551)
	l1l1l_l1_(l1111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᐻ"),l1111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᐼ"),l1111_l1_ (u"ࠨࠩᐽ"),9999)
	for l1l111l_l1_,title in items:
		if l1l111l_l1_==l1111_l1_ (u"ࠩࠦࠫᐾ"): continue
		if title in l11ll11_l1_: continue
		if l1111_l1_ (u"ุ้๊ࠪำๅࠢࠪᐿ") in title: continue
		if l1111_l1_ (u"ࠫศำฯฬࠩᑀ") not in title: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᑁ"),l111_l1_+l1111_l1_ (u"࠭࡟ࡠࡡࠪᑂ")+menu_name+title,l1l111l_l1_,551)
	return
def l1l11l1_l1_(url,l11111l1l_l1_=l1111_l1_ (u"ࠧࠨᑃ")):
	#l1ll1l_l1_(l1111_l1_ (u"ࠨࠩᑄ"),l1111_l1_ (u"ࠩࠪᑅ"),url)
	items = []
	# l1lll1ll11_l1_ l1lll1ll1l_l1_
	if l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᑆ") in url or l1111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᑇ") in url:
		l1l1lll_l1_,l11lll1ll_l1_ = l1lll1llll_l1_(url)
		l1l1lll11_l1_ = {l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᑈ"):l1111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᑉ")}
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠧࡑࡑࡖࡘࠬᑊ"),l1l1lll_l1_,l11lll1ll_l1_,l1l1lll11_l1_,l1111_l1_ (u"ࠨࠩᑋ"),l1111_l1_ (u"ࠩࠪᑌ"),l1111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᑍ"))
		html = response.content
		l111l1l_l1_ = [html]
	else:
		response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠫࡌࡋࡔࠨᑎ"),url,l1111_l1_ (u"ࠬ࠭ᑏ"),l1111_l1_ (u"࠭ࠧᑐ"),l1111_l1_ (u"ࠧࠨᑑ"),l1111_l1_ (u"ࠨࠩᑒ"),l1111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᑓ"))
		html = response.content
		# l11111l1l_l1_ items
		if l11111l1l_l1_==l1111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᑔ"):
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᑕ"),html,re.DOTALL)
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᑖ"),block,re.DOTALL)
			#l1ll1l_l1_(l1111_l1_ (u"࠭ࠧᑗ"),l1111_l1_ (u"ࠧࠨᑘ"),l1111_l1_ (u"ࠨࠩᑙ"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l1111_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠩᑚ") in html:
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬᑛ"),html,re.DOTALL)
		else:
			l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠫࡁࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩᑜ"),html,re.DOTALL)
	if not l111l1l_l1_: return
	block = l111l1l_l1_[0]
	if not items:
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡴࡸࡩࡨ࡫ࡱࡥࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᑝ"),block,re.DOTALL)
		if not items: items = re.findall(l1111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᑞ"),block,re.DOTALL)
	l1lllll1_l1_ = []
	l1lll1lll1_l1_ = [l1111_l1_ (u"ࠧๆึส๋ิฯࠧᑟ"),l1111_l1_ (u"ࠨใํ่๊࠭ᑠ"),l1111_l1_ (u"ࠩส฾๋๐ษࠨᑡ"),l1111_l1_ (u"ࠪ็้๐ศࠨᑢ"),l1111_l1_ (u"ࠫฬ฿ไศ่ࠪᑣ"),l1111_l1_ (u"ࠬํฯศใࠪᑤ"),l1111_l1_ (u"࠭ๅษษิหฮ࠭ᑥ"),l1111_l1_ (u"ฺࠧำูࠫᑦ"),l1111_l1_ (u"ࠨ็๊ีัอๆࠨᑧ"),l1111_l1_ (u"ࠩส่อ๎ๅࠨᑨ")]
	for l1l111l_l1_,title,img in items:
		l1l111l_l1_ = UNQUOTE(l1l111l_l1_).strip(l1111_l1_ (u"ࠪ࠳ࠬᑩ"))
		l11l11l_l1_ = re.findall(l1111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧᑪ"),title,re.DOTALL)
		if l1111_l1_ (u"ูࠬไศี็ࠫᑫ") not in url and any(value in title for value in l1lll1lll1_l1_):
			l1l1l_l1_(l1111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᑬ"),menu_name+title,l1l111l_l1_,552,img)
		elif l11l11l_l1_ and l1111_l1_ (u"ࠧศๆะ่็ฯࠧᑭ") in title:
			title = l1111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᑮ") + l11l11l_l1_[0]
			if title not in l1lllll1_l1_:
				l1l1l_l1_(l1111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑯ"),menu_name+title,l1l111l_l1_,553,img)
				l1lllll1_l1_.append(title)
		elif l1111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬᑰ") in l1l111l_l1_:
			l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᑱ"),menu_name+title,l1l111l_l1_,551,img)
		else: l1l1l_l1_(l1111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᑲ"),menu_name+title,l1l111l_l1_,553,img)
	if l11111l1l_l1_==l1111_l1_ (u"࠭ࠧᑳ"):
		l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫᑴ"),html,re.DOTALL)
		if l111l1l_l1_:
			block = l111l1l_l1_[0]
			items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᑵ"),block,re.DOTALL)
			for l1l111l_l1_,title in items:
				if l1l111l_l1_==l1111_l1_ (u"ࠤࠥᑶ"): continue
				#title = l1l1111_l1_(title)
				if title!=l1111_l1_ (u"ࠪࠫᑷ"): l1l1l_l1_(l1111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᑸ"),menu_name+l1111_l1_ (u"ࠬ฻แฮหࠣࠫᑹ")+title,l1l111l_l1_,551)
	if l1111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ᑺ") in url or l1111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨᑻ") in url:
		if l1111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨᑼ") in url:
			url = url.replace(l1111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᑽ"),l1111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫᑾ"))+l1111_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨᑿ")
		elif l1111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ᒀ") in url:
			url,offset = url.split(l1111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨᒁ"))
			offset = int(offset)+20
			url = url+l1111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩᒂ")+str(offset)
		l1l1l_l1_(l1111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒃ"),menu_name+l1111_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧᒄ"),url,551)
	return
def l1l11ll_l1_(url):
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᒅ"),url,l1111_l1_ (u"ࠫࠬᒆ"),l1111_l1_ (u"ࠬ࠭ᒇ"),l1111_l1_ (u"࠭ࠧᒈ"),l1111_l1_ (u"ࠧࠨᒉ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᒊ"))
	html = response.content
	l1lll1l1ll_l1_ = re.findall(l1111_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪᒋ"),html,re.DOTALL)
	l1l11lll1_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧᒌ"),html,re.DOTALL)
	# l1llll1ll1_l1_
	if l1lll1l1ll_l1_ and l1111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭ᒍ") not in url:
		block = l1lll1l1ll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᒎ"),block,re.DOTALL)
		for l1l111l_l1_,title,img in items:
			l1l1l_l1_(l1111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒏ"),menu_name+title,l1l111l_l1_,553,img)
	# l1llll11_l1_
	elif l1l11lll1_l1_:
		img = re.findall(l1111_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᒐ"),html,re.DOTALL)
		img = img[0]
		block = l1l11lll1_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒑ"),block,re.DOTALL)
		for l1l111l_l1_,title in items:
			#title = title.replace(l1111_l1_ (u"ࠩ࡟ࡲࠬᒒ"),l1111_l1_ (u"ࠪࠫᒓ")).strip(l1111_l1_ (u"ࠫࠥ࠭ᒔ"))
			l1l1l_l1_(l1111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᒕ"),menu_name+title,l1l111l_l1_,552,img)
	return
def l1lllll_l1_(url):
	l1l1lll_l1_ = url.replace(l1111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨᒖ"),l1111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨᒗ"))
	l1l1lll_l1_ = l1l1lll_l1_.replace(l1111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬᒘ"),l1111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬᒙ"))
	response = l1l11l_l1_(l1111l1_l1_,l1111_l1_ (u"ࠪࡋࡊ࡚ࠧᒚ"),l1l1lll_l1_,l1111_l1_ (u"ࠫࠬᒛ"),l1111_l1_ (u"ࠬ࠭ᒜ"),l1111_l1_ (u"࠭ࠧᒝ"),l1111_l1_ (u"ࠧࠨᒞ"),l1111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᒟ"))
	html = response.content
	l1llll1lll_l1_ = l1l1lll1l_l1_(l1l1lll_l1_,l1111_l1_ (u"ࠩࡸࡶࡱ࠭ᒠ"))
	l11lll1l_l1_ = []
	# l11ll1l1l_l1_ l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᒡ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		l11lllll_l1_ = re.findall(l1111_l1_ (u"ࠫࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒢ"),html,re.DOTALL)
		l11lllll_l1_ = l11lllll_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧᒣ"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1111_l1_ (u"࠭࡜࡯ࠩᒤ"),l1111_l1_ (u"ࠧࠨᒥ")).strip(l1111_l1_ (u"ࠨࠢࠪᒦ"))
			l1l111l_l1_ = l1llll1lll_l1_+l1111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡃࡸ࡫ࡲࡷࡧࡵࡁࠬᒧ")+server+l1111_l1_ (u"ࠪࠪࡵࡵࡳࡵࡋࡇࡁࠬᒨ")+l11lllll_l1_+l1111_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬᒩ")
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᒪ")+title+l1111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᒫ")
			l11lll1l_l1_.append(l1l111l_l1_)
	# download l11l1ll1_l1_
	l111l1l_l1_ = re.findall(l1111_l1_ (u"ࠧࠣࡦࡲࡻࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᒬ"),html,re.DOTALL)
	if l111l1l_l1_:
		block = l111l1l_l1_[0]
		items = re.findall(l1111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒭ"),block,re.DOTALL)
		for l1l111l_l1_,name in items:
			l1l111l_l1_ = l1l111l_l1_+l1111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᒮ")+name+l1111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᒯ")
			if l1111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᒰ") not in l1l111l_l1_: l1l111l_l1_ = l1111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᒱ")+l1l111l_l1_
			l11lll1l_l1_.append(l1l111l_l1_)
	#l1l_l1_ = l11llll_l1_(l1111_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᒲ"),l11lll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l11lll1l_l1_,l111_l1_,l1111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᒳ"),url)
	return
l1111_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡒࡏࡅ࡞ࡥࡏࡍࡆࠫࡹࡷࡲࠩ࠻ࠌࠌࡨࡦࡺࡡࠡ࠿ࠣࡿࠬ࡜ࡩࡦࡹࠪ࠾࠶ࢃࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡀࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ࡽࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡔࡔ࡙ࡔࠨ࠮ࡸࡶࡱ࠲ࡤࡢࡶࡤ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡄࡆࡉࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞ࠌࠌࠧࠥࡽࡡࡵࡥ࡫ࠤࡱ࡯࡮࡬ࡵࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡻࡦࡺࡣࡩࡃࡵࡩࡦࡓࡡࡴࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡺࡥࡹࡩࡨࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠤࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡱ࡯࡮࡬ࡵࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡨࡴࡴࡷ࡭ࡱࡤࡨ࠲ࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡳࡦࡴ࠰ࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠬࡲࡷࡤࡰ࡮ࡺࡹ࠭࡮࡬ࡲࡰࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧࠬࠩࡢࡣࡤࡥࠧࠬࡳࡸࡥࡱ࡯ࡴࡺࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪࠌࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࡃ࠽࠱࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠯ࠫฬ๊ัศสฺࠤ้๐ำࠡใํ๋ࠥ็๊ะ์๋ࠫ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖࠎࠎࠏࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡺࡸ࡬ࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨᒴ")
def l1lll1_l1_(search):
	search,options,l1ll11_l1_ = l1ll1ll_l1_(search)
	if search==l1111_l1_ (u"ࠩࠪᒵ"): search = l11ll_l1_()
	if search==l1111_l1_ (u"ࠪࠫᒶ"): return
	search = search.replace(l1111_l1_ (u"ࠫࠥ࠭ᒷ"),l1111_l1_ (u"ࠬ࠳ࠧᒸ"))
	url = l1ll11l_l1_+l1111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨᒹ")+search+l1111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭ᒺ")
	l1l11l1_l1_(url)
	return
# -*- coding: utf-8 -*-


#import logging,xbmc,re
#kodi_release = xbmc.getInfoLabel("System.BuildVersion")
#kodi_major_version = re.findall('^(\d\d)\.',kodi_release,re.DOTALL)[0]
#if int(kodi_major_version)<19: python_version = '27'
#elif kodi_major_version=='19': python_version = '38'
#elif kodi_major_version=='20': python_version = '311'
#elif kodi_major_version=='21': python_version = '313'
#logging.warning('\n\n'+python_version+'\n\n')


import sys,os,xbmcaddon

addonfolder = xbmcaddon.Addon().getAddonInfo('path')

packagesfolder = os.path.join(addonfolder,'packages')
sys.path.append(packagesfolder)

#python_version_major = sys.version_info[0]
#python_version_minor = sys.version_info[1]
#if python_version_major==2: python_version = '27'
#else: python_version = str(python_version_major)+str(python_version_minor)
#arabicvideosfolder = os.path.join(addonfolder,'python'+python_version)

arabicvideosfolder = os.path.join(addonfolder,'arabicvideos')
sys.path.append(arabicvideosfolder)

#from LIBRARY import *
#DIALOG_OK()

import arabicvideos



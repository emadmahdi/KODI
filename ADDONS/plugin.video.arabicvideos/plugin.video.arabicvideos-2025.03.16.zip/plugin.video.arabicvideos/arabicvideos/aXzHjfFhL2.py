# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'YOUTUBE'
xzA9sM3rG6IHd7jl8T = '_YUT_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
VW5jFZ1eAh = 0
def X42LMUrFfIY3oWeazj(mode,url,text,type,H4TFmtAe5rM8oY1lfPviVC,name,ylKTDSkdQmUChwbX45ALeiu):
	if	 mode==140: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==141: w8YsNWfQ5gFluRvOmSd4Cb96H = CEG2bY61K9QZHUWLDgARymhifzN7up(url,name,ylKTDSkdQmUChwbX45ALeiu)
	elif mode==143: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url,type)
	elif mode==144: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC,text)
	elif mode==145: w8YsNWfQ5gFluRvOmSd4Cb96H = TgNphWEiHqe5v8S1uPDm0I2f7(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==147: w8YsNWfQ5gFluRvOmSd4Cb96H = BUZ3rni78SDlmseaGPAuL()
	elif mode==148: w8YsNWfQ5gFluRvOmSd4Cb96H = CukFrVa3geSstG()
	elif mode==149: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	if 0:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'قائمة 1',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'قائمة 2',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'شخص',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/user/TCNofficial',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'موقع',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'حساب',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/@TheSocialCTV',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'العاب',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/gaming',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'افلام',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/feed/storefront',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مختارات',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/feed/guide_builder',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'قصيرة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/shorts',144,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'تصفح',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/youtubei/v1/guide?key=',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'رئيسية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+Vk54F7GcROfCy6HunEI,144)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'رائج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/feed/trending?bp=',144)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,149,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الرائجة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/feed/trending',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'التصفح',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/youtubei/v1/guide?key=',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'القصيرة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/shorts',144,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مختارات يوتيوب',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/feed/guide_builder',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مختارات البرنامج',Vk54F7GcROfCy6HunEI,290)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: قنوات عربية',Vk54F7GcROfCy6HunEI,147)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: قنوات أجنبية',Vk54F7GcROfCy6HunEI,148)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: افلام عربية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=فيلم',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: افلام اجنبية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=movie',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: مسرحيات عربية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=مسرحية',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: مسلسلات عربية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: مسلسلات اجنبية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=series&sp=EgIQAw==',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: مسلسلات كارتون',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=كارتون&sp=EgIQAw==',144)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث: خطبة المرجعية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def CEG2bY61K9QZHUWLDgARymhifzN7up(url,name,ylKTDSkdQmUChwbX45ALeiu):
	name = oqfzZIP1Qxu(name)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'CHNL:  '+name,url,144,ylKTDSkdQmUChwbX45ALeiu)
	return
def BUZ3rni78SDlmseaGPAuL():
	txsXO7gSMnrwAh6NmJ9D(FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def CukFrVa3geSstG():
	txsXO7gSMnrwAh6NmJ9D(FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query=tv&sp=EgJAAQ==')
	return
def h5hmzOAeWEPip(url,type):
	url = url.split('&',1)[0]
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3([url],TVPm7Bz1XOwJ2,type,url)
	return
def nBaDxUCFHMf7I(Kf95GukXdh3MJBwC,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS):
	level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = p1pTyjFEIDr3lgUHhdJsm5t9MBwS.split('::')
	AnPxHui5wLBWTzo1jDv8SOI43G9,E02cb1dzxltrDy = [],[]
	if '/youtubei/v1/browse' in url: AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['onResponseReceivedCommands']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['entries']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['items'][3]['guideSectionRenderer']['items']")
	XXITNA4G2vCOeoQ,Wb65FgAc0oG8dUqy,hjoBdvO71xMGVS = jMXBfWoCGl5EcA(Kf95GukXdh3MJBwC,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
	if level=='1' and XXITNA4G2vCOeoQ:
		if len(Wb65FgAc0oG8dUqy)>1 and 'search_query' not in url:
			for b3txToPMSn9vs in range(len(Wb65FgAc0oG8dUqy)):
				EDFHS9oUzktr8aw0QAf5OxL = str(b3txToPMSn9vs)
				AnPxHui5wLBWTzo1jDv8SOI43G9 = []
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['reloadContinuationItemsCommand']['continuationItems']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['command']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]")
				kNQM9jAU6TVlhezn14cKtBb,anbjzfuiDdgYP6vSXqwRex,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(Wb65FgAc0oG8dUqy,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
				if kNQM9jAU6TVlhezn14cKtBb: E02cb1dzxltrDy.append([anbjzfuiDdgYP6vSXqwRex,url,'2::'+EDFHS9oUzktr8aw0QAf5OxL+'::0::0'])
			AnPxHui5wLBWTzo1jDv8SOI43G9.append("yccc['continuationEndpoint']")
			kNQM9jAU6TVlhezn14cKtBb,anbjzfuiDdgYP6vSXqwRex,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(Kf95GukXdh3MJBwC,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
			if kNQM9jAU6TVlhezn14cKtBb and E02cb1dzxltrDy and 'continuationCommand' in list(anbjzfuiDdgYP6vSXqwRex.keys()):
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/my_main_page_shorts_link'
				E02cb1dzxltrDy.append([anbjzfuiDdgYP6vSXqwRex,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'1::0::0::0'])
	return Wb65FgAc0oG8dUqy,XXITNA4G2vCOeoQ,E02cb1dzxltrDy,hjoBdvO71xMGVS
def YHZs1W05uxSgD2IPBfqCbzvRcpn(Kf95GukXdh3MJBwC,Wb65FgAc0oG8dUqy,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS):
	level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = p1pTyjFEIDr3lgUHhdJsm5t9MBwS.split('::')
	AnPxHui5wLBWTzo1jDv8SOI43G9,BvIwOYdtN5UsAEGeh6qfu1P37 = [],[]
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[0]['itemSectionRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['reloadContinuationItemsCommand']['continuationItems']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd["+EDFHS9oUzktr8aw0QAf5OxL+"]")
	OGQq7FP0yKkgAjzw94B2MEu,zQE29a4kG3uI5OjRYNipb,vqTeVJf8gp0O7MNCRs4tzkFhy = jMXBfWoCGl5EcA(Wb65FgAc0oG8dUqy,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
	if level=='2' and OGQq7FP0yKkgAjzw94B2MEu:
		if len(zQE29a4kG3uI5OjRYNipb)>1:
			for b3txToPMSn9vs in range(len(zQE29a4kG3uI5OjRYNipb)):
				d5eRrEQCWDNcPAtyF4 = str(b3txToPMSn9vs)
				AnPxHui5wLBWTzo1jDv8SOI43G9 = []
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['richSectionRenderer']['content']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['richItemRenderer']['content']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]")
				kNQM9jAU6TVlhezn14cKtBb,anbjzfuiDdgYP6vSXqwRex,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(zQE29a4kG3uI5OjRYNipb,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
				if kNQM9jAU6TVlhezn14cKtBb: BvIwOYdtN5UsAEGeh6qfu1P37.append([anbjzfuiDdgYP6vSXqwRex,url,'3::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::0'])
			AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			AnPxHui5wLBWTzo1jDv8SOI43G9.append("yddd[1]")
			kNQM9jAU6TVlhezn14cKtBb,anbjzfuiDdgYP6vSXqwRex,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(Wb65FgAc0oG8dUqy,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
			if kNQM9jAU6TVlhezn14cKtBb and BvIwOYdtN5UsAEGeh6qfu1P37 and 'continuationItemRenderer' in list(anbjzfuiDdgYP6vSXqwRex.keys()):
				BvIwOYdtN5UsAEGeh6qfu1P37.append([anbjzfuiDdgYP6vSXqwRex,url,'3::0::0::0'])
	return zQE29a4kG3uI5OjRYNipb,OGQq7FP0yKkgAjzw94B2MEu,BvIwOYdtN5UsAEGeh6qfu1P37,vqTeVJf8gp0O7MNCRs4tzkFhy
def VDwhAJ20sGXZHiLvWk(Kf95GukXdh3MJBwC,zQE29a4kG3uI5OjRYNipb,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS):
	level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = p1pTyjFEIDr3lgUHhdJsm5t9MBwS.split('::')
	AnPxHui5wLBWTzo1jDv8SOI43G9,ss9TaGEJuN1mwzoqkK34bVp6j7R8 = [],[]
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['reelShelfRenderer']['items']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee["+d5eRrEQCWDNcPAtyF4+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yeee")
	Gkc53P6pRafYyXZi9wqDUC,sTBbMDP3vxn,ZFCLBR2xUu9Tm0i1JKX = jMXBfWoCGl5EcA(zQE29a4kG3uI5OjRYNipb,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
	if level=='3' and Gkc53P6pRafYyXZi9wqDUC:
		if len(sTBbMDP3vxn)>0:
			for b3txToPMSn9vs in range(len(sTBbMDP3vxn)):
				n3JHYmWtq9kVIBZyDMv = str(b3txToPMSn9vs)
				AnPxHui5wLBWTzo1jDv8SOI43G9 = []
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yfff["+n3JHYmWtq9kVIBZyDMv+"]['richItemRenderer']['content']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yfff["+n3JHYmWtq9kVIBZyDMv+"]['gameCardRenderer']['game']")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yfff["+n3JHYmWtq9kVIBZyDMv+"]['itemSectionRenderer']['contents'][0]")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yfff["+n3JHYmWtq9kVIBZyDMv+"]")
				AnPxHui5wLBWTzo1jDv8SOI43G9.append("yfff")
				kNQM9jAU6TVlhezn14cKtBb,anbjzfuiDdgYP6vSXqwRex,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(sTBbMDP3vxn,Vk54F7GcROfCy6HunEI,AnPxHui5wLBWTzo1jDv8SOI43G9)
				if kNQM9jAU6TVlhezn14cKtBb: ss9TaGEJuN1mwzoqkK34bVp6j7R8.append([anbjzfuiDdgYP6vSXqwRex,url,'4::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv])
	return sTBbMDP3vxn,Gkc53P6pRafYyXZi9wqDUC,ss9TaGEJuN1mwzoqkK34bVp6j7R8,ZFCLBR2xUu9Tm0i1JKX
def jMXBfWoCGl5EcA(ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU,BectAOFVxS9aKMswLvhY):
	Kf95GukXdh3MJBwC,IID2SFskQaGtRgu0p4xqyLnvOU = ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU
	Wb65FgAc0oG8dUqy,IID2SFskQaGtRgu0p4xqyLnvOU = ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU
	zQE29a4kG3uI5OjRYNipb,IID2SFskQaGtRgu0p4xqyLnvOU = ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU
	sTBbMDP3vxn,IID2SFskQaGtRgu0p4xqyLnvOU = ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU
	anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU = ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU
	count = len(BectAOFVxS9aKMswLvhY)
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(count):
		try:
			ttJ2oYkXshBc9yIwWinEd1VU4fLPaM = eval(BectAOFVxS9aKMswLvhY[sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz])
			return True,ttJ2oYkXshBc9yIwWinEd1VU4fLPaM,sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz+1
		except: pass
	return False,Vk54F7GcROfCy6HunEI,0
def txsXO7gSMnrwAh6NmJ9D(url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS=Vk54F7GcROfCy6HunEI,data=Vk54F7GcROfCy6HunEI):
	E02cb1dzxltrDy,BvIwOYdtN5UsAEGeh6qfu1P37,ss9TaGEJuN1mwzoqkK34bVp6j7R8 = [],[],[]
	if '::' not in p1pTyjFEIDr3lgUHhdJsm5t9MBwS: p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '1::0::0::0'
	level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = p1pTyjFEIDr3lgUHhdJsm5t9MBwS.split('::')
	if level=='4': level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = '1',EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv
	data = data.replace('_REMEMBERRESULTS_',Vk54F7GcROfCy6HunEI)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP,Kf95GukXdh3MJBwC,zWochUpvu80mn5 = IFpC8GE4rukfWcVDeohzUm(url,data)
	p1pTyjFEIDr3lgUHhdJsm5t9MBwS = level+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
	if level in ['1','2','3']:
		Wb65FgAc0oG8dUqy,XXITNA4G2vCOeoQ,E02cb1dzxltrDy,hjoBdvO71xMGVS = nBaDxUCFHMf7I(Kf95GukXdh3MJBwC,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
		if not XXITNA4G2vCOeoQ: return
		W4QKNJrloXExp3ha9bUms = len(E02cb1dzxltrDy)
		if W4QKNJrloXExp3ha9bUms<2:
			if level=='1': level = '2'
			E02cb1dzxltrDy = []
	p1pTyjFEIDr3lgUHhdJsm5t9MBwS = level+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
	if level in ['2','3']:
		zQE29a4kG3uI5OjRYNipb,OGQq7FP0yKkgAjzw94B2MEu,BvIwOYdtN5UsAEGeh6qfu1P37,vqTeVJf8gp0O7MNCRs4tzkFhy = YHZs1W05uxSgD2IPBfqCbzvRcpn(Kf95GukXdh3MJBwC,Wb65FgAc0oG8dUqy,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
		if not OGQq7FP0yKkgAjzw94B2MEu: return
		eXK2uMqE3lAP1kW5B = len(BvIwOYdtN5UsAEGeh6qfu1P37)
		if eXK2uMqE3lAP1kW5B<2:
			if level=='2': level = '3'
			BvIwOYdtN5UsAEGeh6qfu1P37 = []
	p1pTyjFEIDr3lgUHhdJsm5t9MBwS = level+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
	if level in ['3']:
		sTBbMDP3vxn,Gkc53P6pRafYyXZi9wqDUC,ss9TaGEJuN1mwzoqkK34bVp6j7R8,ZFCLBR2xUu9Tm0i1JKX = VDwhAJ20sGXZHiLvWk(Kf95GukXdh3MJBwC,zQE29a4kG3uI5OjRYNipb,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
		if not Gkc53P6pRafYyXZi9wqDUC: return
		UP6qbrX5Gviag = len(ss9TaGEJuN1mwzoqkK34bVp6j7R8)
	for anbjzfuiDdgYP6vSXqwRex,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS in E02cb1dzxltrDy+BvIwOYdtN5UsAEGeh6qfu1P37+ss9TaGEJuN1mwzoqkK34bVp6j7R8:
		oecU0R2PC4WmyTdHFk13xAph = ccml7DhKrGvV9qjn8bC52u(anbjzfuiDdgYP6vSXqwRex,url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	return
def ccml7DhKrGvV9qjn8bC52u(anbjzfuiDdgYP6vSXqwRex,url=Vk54F7GcROfCy6HunEI,p1pTyjFEIDr3lgUHhdJsm5t9MBwS=Vk54F7GcROfCy6HunEI):
	if '::' in p1pTyjFEIDr3lgUHhdJsm5t9MBwS: level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = p1pTyjFEIDr3lgUHhdJsm5t9MBwS.split('::')
	else: level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = '1','0','0','0'
	kNQM9jAU6TVlhezn14cKtBb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,count,GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL,AkdSmrZRnOlXz,vvMSGb2z6cAyUWRefQt4hP7i = aL7MmGu2wKNs(anbjzfuiDdgYP6vSXqwRex)
	e5OWwcYkVblSPxKC0atH73 = '/videos?' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/streams?' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/playlists?' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	R2lt6pbLiha1jqUTxd = '/channels?' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/shorts?' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	if e5OWwcYkVblSPxKC0atH73 or R2lt6pbLiha1jqUTxd: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
	e5OWwcYkVblSPxKC0atH73 = 'watch?v=' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and '/playlist?list=' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	R2lt6pbLiha1jqUTxd = '/gaming' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp  and '/feed/storefront' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	if p1pTyjFEIDr3lgUHhdJsm5t9MBwS[0:5]=='3::0::' and e5OWwcYkVblSPxKC0atH73 and R2lt6pbLiha1jqUTxd: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		level,EDFHS9oUzktr8aw0QAf5OxL,d5eRrEQCWDNcPAtyF4,n3JHYmWtq9kVIBZyDMv = '1','0','0','0'
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = Vk54F7GcROfCy6HunEI
	zWochUpvu80mn5 = Vk54F7GcROfCy6HunEI
	if '/youtubei/v1/browse' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/youtubei/v1/search' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/my_main_page_shorts_link' in url:
		data = cad8TeSyMUYmfsEO0.getSetting('av.youtube.data')
		if data.count(':::')==4:
			FJSUmtAXh9L,key,pcqdGuymjhxZrkz1ROt4bLMY0C8XF5,C6jIWbGtMOk7polT9P1Ymfy,cVbGQZ5wHCNO6pU8nKt2Ji = data.split(':::')
			zWochUpvu80mn5 = FJSUmtAXh9L+':::'+key+':::'+pcqdGuymjhxZrkz1ROt4bLMY0C8XF5+':::'+C6jIWbGtMOk7polT9P1Ymfy+':::'+vvMSGb2z6cAyUWRefQt4hP7i
			if '/my_main_page_shorts_link' in url and not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
			else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?key='+key
	if not title:
		global VW5jFZ1eAh
		VW5jFZ1eAh += 1
		title = 'فيديوهات '+str(VW5jFZ1eAh)
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '3'+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
	if not kNQM9jAU6TVlhezn14cKtBb: return False
	elif 'searchPyvRenderer' in str(anbjzfuiDdgYP6vSXqwRex): return False
	elif '/about' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return False
	elif '/community' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return False
	elif 'continuationItemRenderer' in list(anbjzfuiDdgYP6vSXqwRex.keys()) or 'continuationCommand' in list(anbjzfuiDdgYP6vSXqwRex.keys()):
		if int(level)>1: level = str(int(level)-1)
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = level+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: '+'صفحة أخرى',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS,zWochUpvu80mn5)
	elif '/search' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		title = ':: '+title
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '3'+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
		url = url.replace('/search',Vk54F7GcROfCy6HunEI)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,145,Vk54F7GcROfCy6HunEI,p1pTyjFEIDr3lgUHhdJsm5t9MBwS,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '3'+'::'+EDFHS9oUzktr8aw0QAf5OxL+'::'+d5eRrEQCWDNcPAtyF4+'::'+n3JHYmWtq9kVIBZyDMv
		title = ':: '+title
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS,zWochUpvu80mn5)
	elif '/browse' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and url==FFLhlYUAsfJBXeQmRpzD7c14ZP6:
		title = ':: '+title
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '2::0::0::0'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS,zWochUpvu80mn5)
	elif not ssfLBvkuNiXear2gPdxcyT4AQMhYSp and 'horizontalMovieListRenderer' in str(anbjzfuiDdgYP6vSXqwRex):
		title = ':: '+title
		p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '3::0::0::0'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	elif 'messageRenderer' in str(anbjzfuiDdgYP6vSXqwRex):
		v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,9999)
	elif hh13E4fXSkgY2dNFrAqL:
		v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+hh13E4fXSkgY2dNFrAqL+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,143,afR4xElWyzgcNAUnKXBempC)
	elif '/playlist?list=' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('&playnext=1',Vk54F7GcROfCy6HunEI)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'LIST'+count+':  '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	elif '/shorts/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&list=',1)[0]
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,143,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
	elif '/watch?v=' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		if '&list=' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and count:
			oFlMx64JZEqVpi2ty = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&list=',1)[1]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/playlist?list='+oFlMx64JZEqVpi2ty
			p1pTyjFEIDr3lgUHhdJsm5t9MBwS = '1::0::0::0'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'LIST'+count+':  '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
		else:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&list=',1)[0]
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,143,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
	elif '/channel/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/c/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or ('/@' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and ssfLBvkuNiXear2gPdxcyT4AQMhYSp.count('/')==3):
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.decode(AoCWwJHgUPKXI7u2lEzym).encode('raw_unicode_escape')
			title = ww25jXuxtpK1TOJEbGUgrm8(title)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'CHNL'+count+':  '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	elif '/user/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'USER'+count+':  '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	else:
		if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
		title = ':: '+title
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,144,afR4xElWyzgcNAUnKXBempC,p1pTyjFEIDr3lgUHhdJsm5t9MBwS,zWochUpvu80mn5)
	return True
def aL7MmGu2wKNs(anbjzfuiDdgYP6vSXqwRex):
	kNQM9jAU6TVlhezn14cKtBb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,count,GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL,AkdSmrZRnOlXz,cVbGQZ5wHCNO6pU8nKt2Ji = False,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	if not isinstance(anbjzfuiDdgYP6vSXqwRex,dict): return kNQM9jAU6TVlhezn14cKtBb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,count,GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL,AkdSmrZRnOlXz,cVbGQZ5wHCNO6pU8nKt2Ji
	for RplPxCrE4v7bGUwge5JN in list(anbjzfuiDdgYP6vSXqwRex.keys()):
		WHm1xEw5eTpU = anbjzfuiDdgYP6vSXqwRex[RplPxCrE4v7bGUwge5JN]
		if isinstance(WHm1xEw5eTpU,dict): break
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['header']['richListHeaderRenderer']['title']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['headline']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['unplayableText']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['formattedTitle']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['title']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['title']['runs'][0]['text']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['text']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['text']['runs'][0]['text']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['title']['content']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['title']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("item['title']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("item['reelWatchEndpoint']['videoId']")
	kNQM9jAU6TVlhezn14cKtBb,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("item['commandMetadata']['webCommandMetadata']['url']")
	kNQM9jAU6TVlhezn14cKtBb,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnail']['thumbnails'][0]['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	kNQM9jAU6TVlhezn14cKtBb,afR4xElWyzgcNAUnKXBempC,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['videoCountShortText']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['videoCountText']['runs'][0]['text']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['videoCount']")
	kNQM9jAU6TVlhezn14cKtBb,count,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['lengthText']['simpleText']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	kNQM9jAU6TVlhezn14cKtBb,GbwM6iseo0ZVlh4ydB,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	AnPxHui5wLBWTzo1jDv8SOI43G9 = []
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	AnPxHui5wLBWTzo1jDv8SOI43G9.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	kNQM9jAU6TVlhezn14cKtBb,cVbGQZ5wHCNO6pU8nKt2Ji,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = jMXBfWoCGl5EcA(anbjzfuiDdgYP6vSXqwRex,WHm1xEw5eTpU,AnPxHui5wLBWTzo1jDv8SOI43G9)
	if 'LIVE' in GbwM6iseo0ZVlh4ydB: GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL = Vk54F7GcROfCy6HunEI,'LIVE:  '
	if 'مباشر' in GbwM6iseo0ZVlh4ydB: GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL = Vk54F7GcROfCy6HunEI,'LIVE:  '
	if 'badges' in list(WHm1xEw5eTpU.keys()):
		LOxcfDr0A2J9GY14Tt7uMaSFzb8yi = str(WHm1xEw5eTpU['badges'])
		if 'Free with Ads' in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: AkdSmrZRnOlXz = '$:  '
		if 'LIVE' in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: hh13E4fXSkgY2dNFrAqL = 'LIVE:  '
		if 'Buy' in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi or 'Rent' in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: AkdSmrZRnOlXz = '$$:  '
		if IZHqo3tkufgnFv0sAGTRMQwbjda(u'مباشر') in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: hh13E4fXSkgY2dNFrAqL = 'LIVE:  '
		if IZHqo3tkufgnFv0sAGTRMQwbjda(u'شراء') in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: AkdSmrZRnOlXz = '$$:  '
		if IZHqo3tkufgnFv0sAGTRMQwbjda(u'استئجار') in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: AkdSmrZRnOlXz = '$$:  '
		if IZHqo3tkufgnFv0sAGTRMQwbjda(u'إعلانات') in LOxcfDr0A2J9GY14Tt7uMaSFzb8yi: AkdSmrZRnOlXz = '$:  '
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ww25jXuxtpK1TOJEbGUgrm8(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.split('?')[0]
	if  afR4xElWyzgcNAUnKXBempC and 'http' not in afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = 'https:'+afR4xElWyzgcNAUnKXBempC
	title = ww25jXuxtpK1TOJEbGUgrm8(title)
	if AkdSmrZRnOlXz: title = AkdSmrZRnOlXz+title
	GbwM6iseo0ZVlh4ydB = GbwM6iseo0ZVlh4ydB.replace(',',Vk54F7GcROfCy6HunEI)
	count = count.replace(',',Vk54F7GcROfCy6HunEI)
	count = RSuYINdeamsK0t.findall('\d+',count)
	if count: count = count[0]
	else: count = Vk54F7GcROfCy6HunEI
	return True,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,count,GbwM6iseo0ZVlh4ydB,hh13E4fXSkgY2dNFrAqL,AkdSmrZRnOlXz,cVbGQZ5wHCNO6pU8nKt2Ji
def IFpC8GE4rukfWcVDeohzUm(url,data=Vk54F7GcROfCy6HunEI,MmpRngPUCzrJ0HlGfB=Vk54F7GcROfCy6HunEI):
	if MmpRngPUCzrJ0HlGfB==Vk54F7GcROfCy6HunEI: MmpRngPUCzrJ0HlGfB = 'ytInitialData'
	rZigEYv8tbVk = p3QOAkrEuys81JqHobh()
	eDbTIrV6KLfz80 = {'User-Agent':rZigEYv8tbVk,'Cookie':'PREF=hl=ar'}
	global cad8TeSyMUYmfsEO0
	if not data: data = cad8TeSyMUYmfsEO0.getSetting('av.youtube.data')
	if data.count(':::')==4: FJSUmtAXh9L,key,pcqdGuymjhxZrkz1ROt4bLMY0C8XF5,C6jIWbGtMOk7polT9P1Ymfy,cVbGQZ5wHCNO6pU8nKt2Ji = data.split(':::')
	else: FJSUmtAXh9L,key,pcqdGuymjhxZrkz1ROt4bLMY0C8XF5,C6jIWbGtMOk7polT9P1Ymfy,cVbGQZ5wHCNO6pU8nKt2Ji = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	zWochUpvu80mn5 = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":pcqdGuymjhxZrkz1ROt4bLMY0C8XF5}}}
	if url==FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/shorts' or '/my_main_page_shorts_link' in url:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		zWochUpvu80mn5['sequenceParams'] = FJSUmtAXh9L
		zWochUpvu80mn5 = str(zWochUpvu80mn5)
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',url,zWochUpvu80mn5,eDbTIrV6KLfz80,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/youtubei/v1/guide?key='+key
		zWochUpvu80mn5 = str(zWochUpvu80mn5)
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',url,zWochUpvu80mn5,eDbTIrV6KLfz80,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and FJSUmtAXh9L:
		zWochUpvu80mn5['continuation'] = cVbGQZ5wHCNO6pU8nKt2Ji
		zWochUpvu80mn5['context']['client']['visitorData'] = FJSUmtAXh9L
		zWochUpvu80mn5 = str(zWochUpvu80mn5)
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',url,zWochUpvu80mn5,eDbTIrV6KLfz80,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and C6jIWbGtMOk7polT9P1Ymfy:
		eDbTIrV6KLfz80.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':pcqdGuymjhxZrkz1ROt4bLMY0C8XF5})
		eDbTIrV6KLfz80.update({'Cookie':'VISITOR_INFO1_LIVE='+C6jIWbGtMOk7polT9P1Ymfy})
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'YOUTUBE-GET_PAGE_DATA-6th')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('"innertubeApiKey".*?"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.I)
	if OFskSRKaxrlLWPGz9: key = OFskSRKaxrlLWPGz9[0]
	OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('"cver".*?"value".*?"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.I)
	if OFskSRKaxrlLWPGz9: pcqdGuymjhxZrkz1ROt4bLMY0C8XF5 = OFskSRKaxrlLWPGz9[0]
	OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('"visitorData".*?"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.I)
	if OFskSRKaxrlLWPGz9: FJSUmtAXh9L = OFskSRKaxrlLWPGz9[0]
	cookies = Iy3PA1SVXNfjOchtgHC5kuJBG.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): C6jIWbGtMOk7polT9P1Ymfy = cookies['VISITOR_INFO1_LIVE']
	FQAU5IsVfYLyoc7Da0J9veNidHGTw = FJSUmtAXh9L+':::'+key+':::'+pcqdGuymjhxZrkz1ROt4bLMY0C8XF5+':::'+C6jIWbGtMOk7polT9P1Ymfy+':::'+cVbGQZ5wHCNO6pU8nKt2Ji
	if MmpRngPUCzrJ0HlGfB=='ytInitialData' and 'ytInitialData' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp = RSuYINdeamsK0t.findall('window\["ytInitialData"\] = ({.*?});',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp: fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp = RSuYINdeamsK0t.findall('var ytInitialData = ({.*?});',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		v7l9NfLSZ0jma = Bw6jaUcFxlqdDT8bC('str',fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp[0])
	elif MmpRngPUCzrJ0HlGfB=='ytInitialGuideData' and 'ytInitialGuideData' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp = RSuYINdeamsK0t.findall('var ytInitialGuideData = ({.*?});',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		v7l9NfLSZ0jma = Bw6jaUcFxlqdDT8bC('str',fOy9YXtqIc7G4ZDiHhVLSj5PBnxwmp[0])
	elif '</script>' not in FjwObZSWkg8ahBdiQf9IeY135DpXoP: v7l9NfLSZ0jma = Bw6jaUcFxlqdDT8bC('str',FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	else: v7l9NfLSZ0jma = Vk54F7GcROfCy6HunEI
	if 0:
		Kf95GukXdh3MJBwC = str(v7l9NfLSZ0jma)
		if PvwFsJK23NbU8XWAx: Kf95GukXdh3MJBwC = Kf95GukXdh3MJBwC.encode(AoCWwJHgUPKXI7u2lEzym)
		open('S:\\0000emad.dat','wb').write(Kf95GukXdh3MJBwC)
	cad8TeSyMUYmfsEO0.setSetting('av.youtube.data',FQAU5IsVfYLyoc7Da0J9veNidHGTw)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP,v7l9NfLSZ0jma,FQAU5IsVfYLyoc7Da0J9veNidHGTw
def TgNphWEiHqe5v8S1uPDm0I2f7(url,p1pTyjFEIDr3lgUHhdJsm5t9MBwS):
	search = p3bB2auMmSjXC0dE8FUfZ()
	if not search: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	hj50MJnoOp6ZWaS1IQ8Elr = url+'/search?query='+search
	txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr,p1pTyjFEIDr3lgUHhdJsm5t9MBwS)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in iwX378tMyTW9KUB: mPY63wWuDMLCeNq1vE = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in iwX378tMyTW9KUB: mPY63wWuDMLCeNq1vE = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in iwX378tMyTW9KUB: mPY63wWuDMLCeNq1vE = '&sp=EgIQAg%253D%253D'
		else: mPY63wWuDMLCeNq1vE = Vk54F7GcROfCy6HunEI
		ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr+mPY63wWuDMLCeNq1vE
	else:
		TZNWFD3LMG1i5XnCs0fJy8SIoHBkK,VukWAEnUviJ657Qp4,esUNcDaPg3QoX = [],[],Vk54F7GcROfCy6HunEI
		uFTqBXvNVRSCZmWizAytkQP5fK = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		D2Dob4lZ5cjyp = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		zLaNVp4oDR7kwGYATOsi = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر البحث المناسب',uFTqBXvNVRSCZmWizAytkQP5fK)
		if zLaNVp4oDR7kwGYATOsi == -1: return
		m08DbunM7YUV = D2Dob4lZ5cjyp[zLaNVp4oDR7kwGYATOsi]
		FjwObZSWkg8ahBdiQf9IeY135DpXoP,LbJiNWUPRoH90sVpk4m,data = IFpC8GE4rukfWcVDeohzUm(hj50MJnoOp6ZWaS1IQ8Elr+m08DbunM7YUV)
		if LbJiNWUPRoH90sVpk4m:
			try:
				MNUoVvL4Re = LbJiNWUPRoH90sVpk4m['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for A53NxInZRLXbhm in range(len(MNUoVvL4Re)):
					group = MNUoVvL4Re[A53NxInZRLXbhm]['searchFilterGroupRenderer']['filters']
					for WuUgRlVTnLkIA6D5voSeY in range(len(group)):
						WHm1xEw5eTpU = group[WuUgRlVTnLkIA6D5voSeY]['searchFilterRenderer']
						if 'navigationEndpoint' in list(WHm1xEw5eTpU.keys()):
							ssfLBvkuNiXear2gPdxcyT4AQMhYSp = WHm1xEw5eTpU['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('\u0026','&')
							title = WHm1xEw5eTpU['tooltip']
							title = title.replace('البحث عن ',Vk54F7GcROfCy6HunEI)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								esUNcDaPg3QoX = title
								YBDKFZOGfyCHLPA1EaUz9MJ = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',Vk54F7GcROfCy6HunEI)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								esUNcDaPg3QoX = title
								YBDKFZOGfyCHLPA1EaUz9MJ = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
							if 'Sort by' in title: continue
							TZNWFD3LMG1i5XnCs0fJy8SIoHBkK.append(ww25jXuxtpK1TOJEbGUgrm8(title))
							VukWAEnUviJ657Qp4.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			except: pass
		if not esUNcDaPg3QoX: dG4fg0WCZYEXmBvnJcaurhtQF = Vk54F7GcROfCy6HunEI
		else:
			TZNWFD3LMG1i5XnCs0fJy8SIoHBkK = ['بدون فلتر',esUNcDaPg3QoX]+TZNWFD3LMG1i5XnCs0fJy8SIoHBkK
			VukWAEnUviJ657Qp4 = [Vk54F7GcROfCy6HunEI,YBDKFZOGfyCHLPA1EaUz9MJ]+VukWAEnUviJ657Qp4
			ydeOzuPprh3LfF8iMD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('موقع يوتيوب - اختر الفلتر',TZNWFD3LMG1i5XnCs0fJy8SIoHBkK)
			if ydeOzuPprh3LfF8iMD == -1: return
			dG4fg0WCZYEXmBvnJcaurhtQF = VukWAEnUviJ657Qp4[ydeOzuPprh3LfF8iMD]
		if dG4fg0WCZYEXmBvnJcaurhtQF: ynmiDuav5ICTeRsqj6Vb18Q = FFLhlYUAsfJBXeQmRpzD7c14ZP6+dG4fg0WCZYEXmBvnJcaurhtQF
		elif m08DbunM7YUV: ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr+m08DbunM7YUV
		else: ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr
	txsXO7gSMnrwAh6NmJ9D(ynmiDuav5ICTeRsqj6Vb18Q)
	return
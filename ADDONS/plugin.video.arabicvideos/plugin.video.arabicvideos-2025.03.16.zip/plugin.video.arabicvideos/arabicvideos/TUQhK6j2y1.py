# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'EGYBESTVIP'
xzA9sM3rG6IHd7jl8T = '_EGV_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
def X42LMUrFfIY3oWeazj(mode,url,H4TFmtAe5rM8oY1lfPviVC,text):
	if   mode==220: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==221: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==222: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==223: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==224: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url)
	elif mode==229: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,229,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="i i-home"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)"(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,222)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="ba(.*?)<script',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,221)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'html' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
			if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp.endswith('/'): v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,221)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="rs_scroll"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,224)
	return
def dm9YWrf845oej12ICpRnTgtSiQxV(url):
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',url,221)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-FILTERS_MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="sub_nav(.*?)id="movies',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".+?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,221)
	else: txsXO7gSMnrwAh6NmJ9D(url)
	return
def txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC='1'):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	if '/search' in url or '?' in url: hj50MJnoOp6ZWaS1IQ8Elr = url + '&'
	else: hj50MJnoOp6ZWaS1IQ8Elr = url + '?'
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr + 'page=' + H4TFmtAe5rM8oY1lfPviVC
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		Ry3L7fdNGh=RSuYINdeamsK0t.findall('class="pda"(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[-1]
	elif '/series/' in url:
		Ry3L7fdNGh=RSuYINdeamsK0t.findall('class="owl-carousel owl-carousel(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	else:
		Ry3L7fdNGh=RSuYINdeamsK0t.findall('id="movies(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[-1]
	items = RSuYINdeamsK0t.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		title = Uo7Tbc29Eu(title)
		if '/movie/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/episode' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp.rstrip('/'),223,afR4xElWyzgcNAUnKXBempC)
		else:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,221,afR4xElWyzgcNAUnKXBempC)
	if len(items)>=16:
		YogGb1DwesStqWiCXMLF3lyd = ['/movies','/tv','/search','/trending']
		H4TFmtAe5rM8oY1lfPviVC = int(H4TFmtAe5rM8oY1lfPviVC)
		if any(value in url for value in YogGb1DwesStqWiCXMLF3lyd):
			for ZQd1VT5ywx in range(0,1000,100):
				if int(H4TFmtAe5rM8oY1lfPviVC/100)*100==ZQd1VT5ywx:
					for zHq7nBWJTNyY1I3aLco4AR in range(ZQd1VT5ywx,ZQd1VT5ywx+100,10):
						if int(H4TFmtAe5rM8oY1lfPviVC/10)*10==zHq7nBWJTNyY1I3aLco4AR:
							for izP6de3EkWvy5rDxQAN in range(zHq7nBWJTNyY1I3aLco4AR,zHq7nBWJTNyY1I3aLco4AR+10,1):
								if not H4TFmtAe5rM8oY1lfPviVC==izP6de3EkWvy5rDxQAN and izP6de3EkWvy5rDxQAN!=0:
									v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+str(izP6de3EkWvy5rDxQAN),url,221,Vk54F7GcROfCy6HunEI,str(izP6de3EkWvy5rDxQAN))
						elif zHq7nBWJTNyY1I3aLco4AR!=0: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+str(zHq7nBWJTNyY1I3aLco4AR),url,221,Vk54F7GcROfCy6HunEI,str(zHq7nBWJTNyY1I3aLco4AR))
						else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+str(1),url,221,Vk54F7GcROfCy6HunEI,str(1))
				elif ZQd1VT5ywx!=0: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+str(ZQd1VT5ywx),url,221,Vk54F7GcROfCy6HunEI,str(ZQd1VT5ywx))
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+str(1),url,221)
	return
def h5hmzOAeWEPip(url):
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-PLAY-1st')
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('<td>التصنيف</td>.*?">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	wYO9tk5xDT34dnl2MpyaEg,cJaHITKBuyFpoCgfAPXteVLvYS = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	K84KFtxXbueInOlG0D,I3fJxYivohwAtgFp5Vj = FjwObZSWkg8ahBdiQf9IeY135DpXoP,FjwObZSWkg8ahBdiQf9IeY135DpXoP
	iL2a5mzGeMI9yrupTCnRfElQ = RSuYINdeamsK0t.findall('show_dl api" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if iL2a5mzGeMI9yrupTCnRfElQ:
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in iL2a5mzGeMI9yrupTCnRfElQ:
			if '/watch/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: wYO9tk5xDT34dnl2MpyaEg = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			elif '/download/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: cJaHITKBuyFpoCgfAPXteVLvYS = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if wYO9tk5xDT34dnl2MpyaEg!=Vk54F7GcROfCy6HunEI: K84KFtxXbueInOlG0D = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,wYO9tk5xDT34dnl2MpyaEg,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-PLAY-2nd')
		if cJaHITKBuyFpoCgfAPXteVLvYS!=Vk54F7GcROfCy6HunEI: I3fJxYivohwAtgFp5Vj = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,cJaHITKBuyFpoCgfAPXteVLvYS,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-PLAY-3rd')
	skK0UihYA5BcZuSfzTHjrPV = RSuYINdeamsK0t.findall('id="video".*?data-src="(.*?)"',K84KFtxXbueInOlG0D,RSuYINdeamsK0t.DOTALL)
	if skK0UihYA5BcZuSfzTHjrPV:
		hj50MJnoOp6ZWaS1IQ8Elr = skK0UihYA5BcZuSfzTHjrPV[0]
		if hj50MJnoOp6ZWaS1IQ8Elr!=Vk54F7GcROfCy6HunEI and 'uploaded.egybest.download' in hj50MJnoOp6ZWaS1IQ8Elr and '/?id=_' not in hj50MJnoOp6ZWaS1IQ8Elr:
			nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-PLAY-4th')
			b8W9YKdmrfosaM7GJB = RSuYINdeamsK0t.findall('source src="(.*?)" title="(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if b8W9YKdmrfosaM7GJB:
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns in b8W9YKdmrfosaM7GJB:
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=ed.egybest.do__watch__mp4__'+jMiru3pGns)
			else:
				oOv4sVqEAmyM = hj50MJnoOp6ZWaS1IQ8Elr.split('/')[2]
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(hj50MJnoOp6ZWaS1IQ8Elr+'?named='+oOv4sVqEAmyM+'__watch')
		elif hj50MJnoOp6ZWaS1IQ8Elr!=Vk54F7GcROfCy6HunEI:
			oOv4sVqEAmyM = hj50MJnoOp6ZWaS1IQ8Elr.split('/')[2]
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(hj50MJnoOp6ZWaS1IQ8Elr+'?named='+oOv4sVqEAmyM+'__watch')
	SIhUQO2JlgtL = RSuYINdeamsK0t.findall('<table class="dls_table(.*?)</table>',I3fJxYivohwAtgFp5Vj,RSuYINdeamsK0t.DOTALL)
	if SIhUQO2JlgtL:
		SIhUQO2JlgtL = SIhUQO2JlgtL[0]
		MAsPm3vfVih0QDwO6 = RSuYINdeamsK0t.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',SIhUQO2JlgtL,RSuYINdeamsK0t.DOTALL)
		if MAsPm3vfVih0QDwO6:
			for jMiru3pGns,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in MAsPm3vfVih0QDwO6:
				if 'myegyvip' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp.count('/')>=2:
					oOv4sVqEAmyM = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[2]
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+oOv4sVqEAmyM+'__download__mp4__'+jMiru3pGns)
	yU4x75f6iS2TgJzcFnev = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		yU4x75f6iS2TgJzcFnev.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yU4x75f6iS2TgJzcFnev,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBESTVIP-SEARCH-1st')
	cVbGQZ5wHCNO6pU8nKt2Ji = RSuYINdeamsK0t.findall('name="_token" value="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if cVbGQZ5wHCNO6pU8nKt2Ji:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search?_token='+cVbGQZ5wHCNO6pU8nKt2Ji[0]+'&q='+HJVMp5sLkG7EnixWo3QOg
		txsXO7gSMnrwAh6NmJ9D(url)
	return
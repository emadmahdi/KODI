# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SHAHID4U'
xzA9sM3rG6IHd7jl8T = '_SH4_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
headers = {'User-Agent':p3QOAkrEuys81JqHobh(True)}
wXPtB6I0QKLTyD932sl5d = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==110: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==111: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==112: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==113: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,True)
	elif mode==114: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'FULL_FILTER___'+text)
	elif mode==115: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'DEFINED_FILTER___'+text)
	elif mode==116: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,False)
	elif mode==119: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RRav1Sf7Px(Iy3PA1SVXNfjOchtgHC5kuJBG.url,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,119,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',lseWcUVP5qY,115)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',lseWcUVP5qY,114)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',lseWcUVP5qY,111,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('simple-filter(.*?)adv-filter',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for filter,afR4xElWyzgcNAUnKXBempC,title in items:
			url = lseWcUVP5qY+filter
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,url,111,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,filter)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="dropdown"(.*?)<script>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if title in wXPtB6I0QKLTyD932sl5d: continue
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if 'netflix' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = 'نيتفلكس'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,111)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,U8tZVnuiQqYjG5KdEWNbXF=Vk54F7GcROfCy6HunEI,Iy3PA1SVXNfjOchtgHC5kuJBG=Vk54F7GcROfCy6HunEI):
	if not Iy3PA1SVXNfjOchtgHC5kuJBG: Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh,items,GEzxBN8rAh1d = [],[],[]
	if U8tZVnuiQqYjG5KdEWNbXF=='featured': Ry3L7fdNGh = RSuYINdeamsK0t.findall('glide__slides(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else: Ry3L7fdNGh = RSuYINdeamsK0t.findall('shows-container(.*?)pagination',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not items: items = RSuYINdeamsK0t.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if 'WWE' in title: continue
		if 'javascript' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		title = Uo7Tbc29Eu(title)
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if '/film/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or 'فيلم' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,112,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,113,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/actor/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,111,afR4xElWyzgcNAUnKXBempC)
		elif '/series/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and '/list' not in url:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'/list'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,111,afR4xElWyzgcNAUnKXBempC)
		elif '/list' in url and 'حلقة' in title:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,112,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,113,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		if U8tZVnuiQqYjG5KdEWNbXF!='search': items = RSuYINdeamsK0t.findall('(updateQuery).*?>(.+?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		else: items = RSuYINdeamsK0t.findall('<li>.*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if U8tZVnuiQqYjG5KdEWNbXF!='search':
				if '?' in url: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'&page='+title
				else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'?page='+title
			title = Uo7Tbc29Eu(title)
			if title: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,111,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,U8tZVnuiQqYjG5KdEWNbXF)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,XCkFpYZyKfm):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('items d-flex(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if len(Ry3L7fdNGh)>1:
		if '/season/' in Ry3L7fdNGh[0]: Yo3AtpSIM5ax6dUTwLk1qCgjeym7P,NTaCesPm04 = Ry3L7fdNGh[0],Ry3L7fdNGh[1]
		else: Yo3AtpSIM5ax6dUTwLk1qCgjeym7P,NTaCesPm04 = Ry3L7fdNGh[1],Ry3L7fdNGh[0]
	else: Yo3AtpSIM5ax6dUTwLk1qCgjeym7P,NTaCesPm04 = Ry3L7fdNGh[0],Ry3L7fdNGh[0]
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(2):
		if XCkFpYZyKfm: mode,type,UwcYSVZbdK3rI = 116,'folder',Yo3AtpSIM5ax6dUTwLk1qCgjeym7P
		else: mode,type,UwcYSVZbdK3rI = 112,'video',NTaCesPm04
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if XCkFpYZyKfm and len(items)<2:
			XCkFpYZyKfm = False
			continue
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,xxM1Ua3FDdE2Xl8TOzsVuqBWg,esUNcDaPg3QoX in items:
			title = xxM1Ua3FDdE2Xl8TOzsVuqBWg+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+esUNcDaPg3QoX
			v0TjHlLZqkRxUCpmNwSy8AndO(type,xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,mode)
		break
	if not items and '/episodes' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		aaDZiuBb5zsPgT1cWtnk3oQU0v4 = RSuYINdeamsK0t.findall('class="breadcrumb"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if aaDZiuBb5zsPgT1cWtnk3oQU0v4:
			UwcYSVZbdK3rI = aaDZiuBb5zsPgT1cWtnk3oQU0v4[0]
			HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if len(HXhRgxEZ4d2Dek)>2:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = HXhRgxEZ4d2Dek[2]+'list'
				txsXO7gSMnrwAh6NmJ9D(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="actions(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	xxkzfovCYN3USgd1 = '/watch/' in UwcYSVZbdK3rI
	download = '/download/' in UwcYSVZbdK3rI
	if   xxkzfovCYN3USgd1 and not download: ugNHnV4WvrYkchKJ,FkAdRi9Xp0MnrmZ86 = HXhRgxEZ4d2Dek[0],Vk54F7GcROfCy6HunEI
	elif not xxkzfovCYN3USgd1 and download: ugNHnV4WvrYkchKJ,FkAdRi9Xp0MnrmZ86 = Vk54F7GcROfCy6HunEI,HXhRgxEZ4d2Dek[0]
	elif xxkzfovCYN3USgd1 and download: ugNHnV4WvrYkchKJ,FkAdRi9Xp0MnrmZ86 = HXhRgxEZ4d2Dek[0],HXhRgxEZ4d2Dek[1]
	else: ugNHnV4WvrYkchKJ,FkAdRi9Xp0MnrmZ86 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	if xxkzfovCYN3USgd1:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',ugNHnV4WvrYkchKJ,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-PLAY-2nd')
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('let servers(.*?)player',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if QQHXiFSA0jUsklmxbpaMztu:
			v8e07ENZbVzIjaMSQPAxLUyuKcWho = QQHXiFSA0jUsklmxbpaMztu[0]
			C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('"name":"(.*?)".*?"url":"(.*?)"',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
			for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in C7SvpZQLjOwh9m0goVbzXadR5:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('\\/','/')
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if download:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FkAdRi9Xp0MnrmZ86,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-PLAY-3rd')
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"servers"(.*?)info-container',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if QQHXiFSA0jUsklmxbpaMztu:
			v8e07ENZbVzIjaMSQPAxLUyuKcWho = QQHXiFSA0jUsklmxbpaMztu[0]
			C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,jMiru3pGns in C7SvpZQLjOwh9m0goVbzXadR5:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+'____'+jMiru3pGns
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search?s='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
def xkK0Y7fnciMQvjyq(url):
	url = url.split('/smartemadfilter?')[0]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ugep4NW1YS = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('adv-filter(.*?)shows-container',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		Ugep4NW1YS = RSuYINdeamsK0t.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		OOJi6xHhMq05oDe,eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK,DatFuedGb45zR1KqIWNk = zip(*Ugep4NW1YS)
		Ugep4NW1YS = zip(eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK,OOJi6xHhMq05oDe,DatFuedGb45zR1KqIWNk)
	return Ugep4NW1YS
def uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI):
	items = RSuYINdeamsK0t.findall('value="(.*?)".*?>\s*(.*?)\s*<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return items
def R0kPAsQ9prh8dNY4DIbvf21zClyL(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	zxAP2BC6ekOXpHnwF = url.split('/smartemadfilter?')[0]
	iFJVwrXDlfRUKN20 = RRav1Sf7Px(url,'url')
	url = url.replace(zxAP2BC6ekOXpHnwF,iFJVwrXDlfRUKN20)
	url = url.replace('/smartemadfilter?','/?')
	return url
DZ9EWKPJut5hf4vnM = ['quality','year','genre','category']
gW3HMvICPYqjaxQ2iU4rFKo8LASZ1 = ['category','genre','year']
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='DEFINED_FILTER':
		if gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0:-1])):
			if gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='FULL_FILTER':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+KMbV6CGYIuH
		ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',ynmiDuav5ICTeRsqj6Vb18Q,111)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',ynmiDuav5ICTeRsqj6Vb18Q,111)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ugep4NW1YS = xkK0Y7fnciMQvjyq(url)
	dict = {}
	for name,kuKGA8HpgN7PyjvxeLZ,UwcYSVZbdK3rI in Ugep4NW1YS:
		name = name.replace('كل ',Vk54F7GcROfCy6HunEI)
		items = uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='DEFINED_FILTER':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<2:
				if kuKGA8HpgN7PyjvxeLZ==gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-1]:
					ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
					txsXO7gSMnrwAh6NmJ9D(ynmiDuav5ICTeRsqj6Vb18Q)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'DEFINED_FILTER___'+Ng1Jod47fp0S)
				return
			else:
				if kuKGA8HpgN7PyjvxeLZ==gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-1]:
					ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',ynmiDuav5ICTeRsqj6Vb18Q,111)
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,115,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='FULL_FILTER':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع :'+name,hj50MJnoOp6ZWaS1IQ8Elr,114,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if value=='196533': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'أفلام نيتفلكس'
			elif value=='196531': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'مسلسلات نيتفلكس'
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'#+dict[kuKGA8HpgN7PyjvxeLZ]['0']
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'+name
			if type=='FULL_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,114,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='DEFINED_FILTER' and gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-2]+'=' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
				hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,111)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,115,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.replace('=&','=0&')
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	for key in DZ9EWKPJut5hf4vnM:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.replace('=0','=')
	return PpjxGzO7yqD0AXSJL1Mw
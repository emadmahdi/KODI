# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ALFATIMI'
xzA9sM3rG6IHd7jl8T = '_FTM_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
WWdNR89SUFsbVkzBvIrHJ5XQfio = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
YzNg8Uqkm316vWbASstTDR = ['3030','628']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==60: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==61: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==62: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==63: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==64: w8YsNWfQ5gFluRvOmSd4Cb96H = lyzGnuUYQqLTHPVSjk5p(text)
	elif mode==69: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,69,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'ما يتم مشاهدته الان',FFLhlYUAsfJBXeQmRpzD7c14ZP6,64,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'recent_viewed_vids')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الاكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6,64,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'most_viewed_vids')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'اضيفت مؤخرا',FFLhlYUAsfJBXeQmRpzD7c14ZP6,64,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'recently_added_vids')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'فيديو عشوائي',FFLhlYUAsfJBXeQmRpzD7c14ZP6,64,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'random_vids')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'افلام ومسلسلات',FFLhlYUAsfJBXeQmRpzD7c14ZP6,61,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'-1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'البرامج الدينية',FFLhlYUAsfJBXeQmRpzD7c14ZP6,61,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'-2')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'English Videos',FFLhlYUAsfJBXeQmRpzD7c14ZP6,61,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'-3')
	return Vk54F7GcROfCy6HunEI
def txsXO7gSMnrwAh6NmJ9D(url,MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb):
	zfO7acv9exNPl5SgnJLk63HoqA = Vk54F7GcROfCy6HunEI
	if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb not in ['-1','-2','-3']: zfO7acv9exNPl5SgnJLk63HoqA = '?cat='+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb
	hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/menu_level.php'+zfO7acv9exNPl5SgnJLk63HoqA
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALFATIMI-TITLES-1st')
	items = RSuYINdeamsK0t.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	o1XUrs6SCzQgqOVWydIjYR8al73pu,ydWEcgbFm0lNr42a8 = False,False
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,count in items:
		title = Uo7Tbc29Eu(title)
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		zfO7acv9exNPl5SgnJLk63HoqA = RSuYINdeamsK0t.findall('cat=(.*?)&',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,RSuYINdeamsK0t.DOTALL)[0]
		if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb==zfO7acv9exNPl5SgnJLk63HoqA: o1XUrs6SCzQgqOVWydIjYR8al73pu = True
		elif o1XUrs6SCzQgqOVWydIjYR8al73pu 	or (MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='-1' and zfO7acv9exNPl5SgnJLk63HoqA in WWdNR89SUFsbVkzBvIrHJ5XQfio)  						or (MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='-2' and zfO7acv9exNPl5SgnJLk63HoqA not in YzNg8Uqkm316vWbASstTDR and zfO7acv9exNPl5SgnJLk63HoqA not in WWdNR89SUFsbVkzBvIrHJ5XQfio)  						or (MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='-3' and zfO7acv9exNPl5SgnJLk63HoqA in YzNg8Uqkm316vWbASstTDR):
							if count=='1': v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,63)
							else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,61,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,zfO7acv9exNPl5SgnJLk63HoqA)
							ydWEcgbFm0lNr42a8 = True
	if not ydWEcgbFm0lNr42a8: SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALFATIMI-EPISODES-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('pagination(.*?)id="footer',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Vk54F7GcROfCy6HunEI
	for afR4xElWyzgcNAUnKXBempC,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		title = title.replace('Add',Vk54F7GcROfCy6HunEI).replace('to Quicklist',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,63,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh=RSuYINdeamsK0t.findall('(.*?)div',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI=Ry3L7fdNGh[0]
	UwcYSVZbdK3rI=RSuYINdeamsK0t.findall('pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	items=RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = url.split('?')[0]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,M87xAQqm352BynDjzF6pLJl9N in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = hj50MJnoOp6ZWaS1IQ8Elr + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = Uo7Tbc29Eu(M87xAQqm352BynDjzF6pLJl9N)
		title = 'صفحة ' + title
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,62)
	return ssfLBvkuNiXear2gPdxcyT4AQMhYSp
def h5hmzOAeWEPip(url):
	if 'videos.php' in url: url = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALFATIMI-PLAY-1st')
	items = RSuYINdeamsK0t.findall('playlistfile:"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	qnUlyF2JXuGYdSA6Iac1(url,TVPm7Bz1XOwJ2,'video')
	return
def lyzGnuUYQqLTHPVSjk5p(MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb):
	k8NxAwnQI2FzZCyJYthpaVubLscq = { 'mode' : MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = weWxHqLyORY4NfBbGQmgc53F1E8UVz(k8NxAwnQI2FzZCyJYthpaVubLscq)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,63,afR4xElWyzgcNAUnKXBempC)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/search_result.php?query=' + HJVMp5sLkG7EnixWo3QOg
	SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	return
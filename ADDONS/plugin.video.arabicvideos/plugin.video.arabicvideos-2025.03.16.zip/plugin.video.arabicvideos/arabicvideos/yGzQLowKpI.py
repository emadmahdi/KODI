# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'MOVIZLAND'
headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
xzA9sM3rG6IHd7jl8T = '_MVZ_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
PqQp5bd4ZAeVu6DM1Kjrt = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][1]
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==180: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==181: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==182: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==183: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==188: w8YsNWfQ5gFluRvOmSd4Cb96H = Vjwok1a5vMDZbdGuOSXEt8L7Tc()
	elif mode==189: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def Vjwok1a5vMDZbdGuOSXEt8L7Tc():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج',message)
	return
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,189,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'بوكس اوفيس موفيز لاند',FFLhlYUAsfJBXeQmRpzD7c14ZP6,181,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'box-office')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أحدث الافلام',FFLhlYUAsfJBXeQmRpzD7c14ZP6,181,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'latest-movies')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'تليفزيون موفيز لاند',FFLhlYUAsfJBXeQmRpzD7c14ZP6,181,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'tv')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الاكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6,181,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'top-views')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أقوى الافلام الحالية',FFLhlYUAsfJBXeQmRpzD7c14ZP6,181,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'top-movies')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-MENU-1st')
	items = RSuYINdeamsK0t.findall('<h2><a href="(.*?)".*?">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,181)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	elif type=='box-office': UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	elif type=='top-movies': UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('btn-2-overlay(.*?)<style>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	elif type=='top-views': UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	elif type=='tv': UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	else: UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
	if type in ['top-views','top-movies']:
		items = RSuYINdeamsK0t.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else: items = RSuYINdeamsK0t.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	tFflmNDy4p78jeLWnk9xCcVZsYEz01 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for afR4xElWyzgcNAUnKXBempC,ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU,cBfzEmAetGSDF64blZoXKwY57nN in items:
		if type in ['top-views','top-movies']:
			afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,YBDKFZOGfyCHLPA1EaUz9MJ,title = afR4xElWyzgcNAUnKXBempC,ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU,cBfzEmAetGSDF64blZoXKwY57nN
		else: afR4xElWyzgcNAUnKXBempC,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,YBDKFZOGfyCHLPA1EaUz9MJ = afR4xElWyzgcNAUnKXBempC,ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU,cBfzEmAetGSDF64blZoXKwY57nN
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('?view=true',Vk54F7GcROfCy6HunEI)
		title = Uo7Tbc29Eu(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',Vk54F7GcROfCy6HunEI).replace('بجوده ',Vk54F7GcROfCy6HunEI)
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'الحلقة' in title or 'الحلقه' in title:
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|الحلقه) \d+',title,RSuYINdeamsK0t.DOTALL)
			if AWjJSatwokZ:
				title = '_MOD_' + AWjJSatwokZ[0][0]
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,183,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
		elif any(value in title for value in tFflmNDy4p78jeLWnk9xCcVZsYEz01):
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp + '?servers=' + YBDKFZOGfyCHLPA1EaUz9MJ
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,182,afR4xElWyzgcNAUnKXBempC)
		else:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp + '?servers=' + YBDKFZOGfyCHLPA1EaUz9MJ
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,183,afR4xElWyzgcNAUnKXBempC)
	if type==Vk54F7GcROfCy6HunEI:
		items = RSuYINdeamsK0t.findall('\n<li><a href="(.*?)".*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			if title!=Vk54F7GcROfCy6HunEI:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,181)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	hj50MJnoOp6ZWaS1IQ8Elr = url.split('?servers=')[0]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-EPISODES-1st')
	UwcYSVZbdK3rI = RSuYINdeamsK0t.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	title,x7ohwWJScUpRi1K50qs,afR4xElWyzgcNAUnKXBempC = UwcYSVZbdK3rI[0]
	name = RSuYINdeamsK0t.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,RSuYINdeamsK0t.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="episodesNumbers"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			title = RSuYINdeamsK0t.findall('(الحلقة|الحلقه)-([0-9]+)',ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-2],RSuYINdeamsK0t.DOTALL)
			if not title: title = RSuYINdeamsK0t.findall('()-([0-9]+)',ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-2],RSuYINdeamsK0t.DOTALL)
			if title: title = otBWsSAfu7dihVkP9e1JFKrvmYy2Q + title[0][1]
			else: title = Vk54F7GcROfCy6HunEI
			title = name + ' - ' + 'الحلقة' + title
			title = Uo7Tbc29Eu(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,182,afR4xElWyzgcNAUnKXBempC)
	if not items:
		title = Uo7Tbc29Eu(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',Vk54F7GcROfCy6HunEI).replace('بجوده ',Vk54F7GcROfCy6HunEI)
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,182,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	q3U5kprDyzQMwIu2ONZsxBc41aEtKT = url.split('?servers=')
	hj50MJnoOp6ZWaS1IQ8Elr = q3U5kprDyzQMwIu2ONZsxBc41aEtKT[0]
	del q3U5kprDyzQMwIu2ONZsxBc41aEtKT[0]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-PLAY-1st')
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('font-size: 25px;" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in q3U5kprDyzQMwIu2ONZsxBc41aEtKT: q3U5kprDyzQMwIu2ONZsxBc41aEtKT.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in q3U5kprDyzQMwIu2ONZsxBc41aEtKT:
		if '://moshahda.' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			rHmtBjQeaJyxR19MbUq0pG736 = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(rHmtBjQeaJyxR19MbUq0pG736+'?named=Main')
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in q3U5kprDyzQMwIu2ONZsxBc41aEtKT:
		if '://vb.movizland.' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-PLAY-2nd')
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.decode('windows-1256').encode(AoCWwJHgUPKXI7u2lEzym)
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if Ry3L7fdNGh:
				TQjudoNYcPJr5,v6eOQW0xrkL = [],[]
				if len(Ry3L7fdNGh)==1:
					title = Vk54F7GcROfCy6HunEI
					UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
				else:
					for UwcYSVZbdK3rI in Ry3L7fdNGh:
						v8e07ENZbVzIjaMSQPAxLUyuKcWho = RSuYINdeamsK0t.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
						if v8e07ENZbVzIjaMSQPAxLUyuKcWho: UwcYSVZbdK3rI = 'src="/uploads/13721411411.png"  \n  ' + v8e07ENZbVzIjaMSQPAxLUyuKcWho[0][1]
						v8e07ENZbVzIjaMSQPAxLUyuKcWho = RSuYINdeamsK0t.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
						if v8e07ENZbVzIjaMSQPAxLUyuKcWho: UwcYSVZbdK3rI = 'src="/uploads/13721411411.png"  \n  ' + v8e07ENZbVzIjaMSQPAxLUyuKcWho[0]
						v8e07ENZbVzIjaMSQPAxLUyuKcWho = RSuYINdeamsK0t.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
						if v8e07ENZbVzIjaMSQPAxLUyuKcWho: UwcYSVZbdK3rI = v8e07ENZbVzIjaMSQPAxLUyuKcWho[0] + '  \n  src="/uploads/13721411411.png"'
						uZKUgz8EeqLHsXMr7oVm6lpCOh053t = RSuYINdeamsK0t.findall('<(.*?)http://up.movizland.(online|com)/uploads/',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
						title = RSuYINdeamsK0t.findall('> *([^<>]+) *<',uZKUgz8EeqLHsXMr7oVm6lpCOh053t[0][0],RSuYINdeamsK0t.DOTALL)
						title = otBWsSAfu7dihVkP9e1JFKrvmYy2Q.join(title)
						title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
						title = title.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
						TQjudoNYcPJr5.append(title)
					qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('أختر الفيديو المطلوب:', TQjudoNYcPJr5)
					if qreJEpY8nZguD == -1 : return
					title = TQjudoNYcPJr5[qreJEpY8nZguD]
					UwcYSVZbdK3rI = Ry3L7fdNGh[qreJEpY8nZguD]
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('href="(http://moshahda\..*?/\w+.html)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				ggj1KSxOC546tMzLDcB = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ggj1KSxOC546tMzLDcB+'?named=Forum')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('ـ',Vk54F7GcROfCy6HunEI)
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				eAoZTaOBQq3MExkKSDC = RSuYINdeamsK0t.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for oJlTIFyUNrCZnVhfLwk in eAoZTaOBQq3MExkKSDC:
					type = RSuYINdeamsK0t.findall(' typetype="(.*?)" ',oJlTIFyUNrCZnVhfLwk)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = Vk54F7GcROfCy6HunEI
					items = RSuYINdeamsK0t.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',oJlTIFyUNrCZnVhfLwk,RSuYINdeamsK0t.DOTALL)
					for rAY4G1fphg8mPL32s,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
						title = RSuYINdeamsK0t.findall('(\w+[ \w]*)<',rAY4G1fphg8mPL32s)
						title = title[-1]
						ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp + '?named=' + title + type
						yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr.replace(FFLhlYUAsfJBXeQmRpzD7c14ZP6,PqQp5bd4ZAeVu6DM1Kjrt)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-PLAY-3rd')
	items = RSuYINdeamsK0t.findall('" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		WcQ8jOFYNLnoGApdDC2wuTzmS = items[-1]
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(WcQ8jOFYNLnoGApdDC2wuTzmS+'?named=Mobile')
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'MOVIZLAND-SEARCH-1st')
	items = RSuYINdeamsK0t.findall('<option value="(.*?)">(.*?)</option>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	V80Y4qCyNQ2Sl = [ Vk54F7GcROfCy6HunEI ]
	fN2oXxtE0J1sq = [ 'الكل وبدون فلتر' ]
	for MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,title in items:
		V80Y4qCyNQ2Sl.append(MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb)
		fN2oXxtE0J1sq.append(title)
	if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb:
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر الفلتر المناسب:', fN2oXxtE0J1sq)
		if qreJEpY8nZguD == -1 : return
		MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = V80Y4qCyNQ2Sl[qreJEpY8nZguD]
	else: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = Vk54F7GcROfCy6HunEI
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/?s='+search+'&mcat='+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb
	txsXO7gSMnrwAh6NmJ9D(url)
	return
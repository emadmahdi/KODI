# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
ILyVox7aiXM148nz = 'IPTV'
klWfTZXjDY4qbPhvOKxd = '_IPT_'
RnlvXActfLaqGDzB6VH = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def GKIyworcUq4AbupslPTFvx(Yz6schq9wSmiu3IOdke0DXPj5W,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO,hArRgv5l10sU2yVSCO9JBHbE,NBnKOkHsvLd,GeDUpHhCROtPrx):
	global klWfTZXjDY4qbPhvOKxd
	try:
		j6W37Jtc8ryXDT95Phx = str(GeDUpHhCROtPrx['folder'])
		klWfTZXjDY4qbPhvOKxd = '_IP'+j6W37Jtc8ryXDT95Phx+'_'
	except: j6W37Jtc8ryXDT95Phx = Vk54F7GcROfCy6HunEI
	if   Yz6schq9wSmiu3IOdke0DXPj5W==230: P8JgauLzVmeTiRMy39nADHj = JKh7zNpgtOmTMI5r()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==231: P8JgauLzVmeTiRMy39nADHj = muVeMOGUgnkyd9wsNA4(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==232: P8JgauLzVmeTiRMy39nADHj = D08HRNYzBfCe2mPhnkGLpXaKVWi(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==233: P8JgauLzVmeTiRMy39nADHj = dh1OAs2VijQreD8kJXFupZ(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO,NBnKOkHsvLd)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==234: P8JgauLzVmeTiRMy39nADHj = XZA9vYcOi4(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO,NBnKOkHsvLd)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==235: P8JgauLzVmeTiRMy39nADHj = h5hmzOAeWEPip(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,hArRgv5l10sU2yVSCO9JBHbE)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==236: P8JgauLzVmeTiRMy39nADHj = qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,True)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==237: P8JgauLzVmeTiRMy39nADHj = mIlV9YhHrkCGeMytbO8TBEA(j6W37Jtc8ryXDT95Phx,True)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==238: P8JgauLzVmeTiRMy39nADHj = DK1oiaX2leIWFZ9TuCmwPHzpQRAL(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==239: P8JgauLzVmeTiRMy39nADHj = FXrJ2CcKxVys6aM(YWCso5NMKO,j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,NBnKOkHsvLd)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==280: P8JgauLzVmeTiRMy39nADHj = JwqdmWj19PZr(j6W37Jtc8ryXDT95Phx,True)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==281: P8JgauLzVmeTiRMy39nADHj = bb5Hn2mBvFZrlUywkOapK06hc(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==282: P8JgauLzVmeTiRMy39nADHj = NHRMs1X5gPT7dA29n(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==283: P8JgauLzVmeTiRMy39nADHj = K9n0oVpzxZOLG4b3wHf2vWjmuXEIr(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==285: P8JgauLzVmeTiRMy39nADHj = Wk24A81X0bOevyBMQEUNjq(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==286: P8JgauLzVmeTiRMy39nADHj = QjiCnYpR3MNJbBkDTOGu1Emgvr5Z(j6W37Jtc8ryXDT95Phx)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==289: P8JgauLzVmeTiRMy39nADHj = PxUzbQsISy7wg1cGd4l5Ma9YqHhi(YWCso5NMKO,j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,NBnKOkHsvLd)
	else: P8JgauLzVmeTiRMy39nADHj = False
	return P8JgauLzVmeTiRMy39nADHj
def JKh7zNpgtOmTMI5r():
	for j6W37Jtc8ryXDT95Phx in range(1,YWQb3r2CoU+1):
		klWfTZXjDY4qbPhvOKxd = '_IP'+str(j6W37Jtc8ryXDT95Phx)+'_'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قائمة مجلد '+DVO3m2tJ4Hdh[j6W37Jtc8ryXDT95Phx],Vk54F7GcROfCy6HunEI,280,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	return
def JwqdmWj19PZr(j6W37Jtc8ryXDT95Phx=Vk54F7GcROfCy6HunEI,zM4WqLKfU03HChTsad=Vk54F7GcROfCy6HunEI):
	if j6W37Jtc8ryXDT95Phx:
		Rb8jUiKTa2cz9NDn = {'folder':j6W37Jtc8ryXDT95Phx}
		CU0GKZWMYgiFlV6Q1oH8wquc = Vk54F7GcROfCy6HunEI
	else:
		Rb8jUiKTa2cz9NDn = Vk54F7GcROfCy6HunEI
		CU0GKZWMYgiFlV6Q1oH8wquc = Vk54F7GcROfCy6HunEI
	L4kj0iRQ35PYdreJFm9NV = LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad)
	if not L4kj0iRQ35PYdreJFm9NV:
		v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+d761ZWXHEvliYN45RzLP2+' إضافة أو تغيير اشتراك'+CU0GKZWMYgiFlV6Q1oH8wquc+' '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,231,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+d761ZWXHEvliYN45RzLP2+' جلب ملفات'+CU0GKZWMYgiFlV6Q1oH8wquc+' '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,232,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	else:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'بحث في الملفات'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,289,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_',Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مصنفة مرتبة'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مصنفة من القسم'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_FROM_GROUP_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مصنفة من الاسم'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_FROM_NAME_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مصنفة بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_ORIGINAL_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مجهولة مرتبة'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_UNKNOWN_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'قنوات مجهولة بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_UNKNOWN_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أفلام مصنفة بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_MOVIES_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أفلام مصنفة مرتبة'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_MOVIES_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'مسلسلات مصنفة بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_SERIES_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'مسلسلات مصنفة مرتبة'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_SERIES_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'فيديوهات بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_ORIGINAL_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'فيديوهات مصنفة من القسم'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_FROM_GROUP_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'فيديوهات مصنفة من الاسم'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_FROM_NAME_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'فيديوهات مجهولة بلا ترتيب'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_UNKNOWN_GROUPED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'فيديوهات مجهولة مرتبة'+CU0GKZWMYgiFlV6Q1oH8wquc,'VOD_UNKNOWN_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'برامج القنوات (جدول فقط)'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_EPG_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أرشيف القنوات للأيام الماضية'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_TIMESHIFT_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أرشيف برامج القنوات للأيام الماضية'+CU0GKZWMYgiFlV6Q1oH8wquc,'LIVE_ARCHIVED_GROUPED_SORTED',233,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'إضافة أو تغيير اشتراك'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,231,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'جلب ملفات'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,232,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'مسح ملفات'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,237,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'فحص اشتراك'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,236,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'عدد فيديوهات'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,281,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'Referer تغيير'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,286,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'User-Agent تغيير'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,283,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+'استخدم السيرفر الأسرع'+CU0GKZWMYgiFlV6Q1oH8wquc,Vk54F7GcROfCy6HunEI,282,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Rb8jUiKTa2cz9NDn)
	return
def qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad=True):
	z3zSNULCoHJxfhk5eMiGWEpTXYBF,oFGg2XBeH7PhTQRc4l = False,Vk54F7GcROfCy6HunEI
	sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k = OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx)
	if RrJQvd9mBH46bclqoI0iCYK2Zj3==Vk54F7GcROfCy6HunEI: return False,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	KT67DQI1xk9XG34ezN0hH = a2LEDnNXSZTqVdoUM1GB5tvukHpQ(j6W37Jtc8ryXDT95Phx)
	if SvBypP6sNKoYbiAeZUVF:
		aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET',SvBypP6sNKoYbiAeZUVF,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,False,Vk54F7GcROfCy6HunEI,'IPTV-CHECK_ACCOUNT-1st')
		ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
		if aaspUWRrCE4nLAlGf.succeeded:
			ofNzXSTxHaqg3ebB1,xySEbwG7Zhi0c9HMNldFDkU6vJ,JT3DOogGUh7Nx,PCAHU7rQavF,c0f2LrnO5z = 0,0,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
			try:
				gb3Wy6fShH2JLT0z78jXQ1qkU = Bw6jaUcFxlqdDT8bC('dict',ov9nVhCfMkz37xPgQOS)
				oFGg2XBeH7PhTQRc4l = gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['status']
				z3zSNULCoHJxfhk5eMiGWEpTXYBF = True
				JT3DOogGUh7Nx = gb3Wy6fShH2JLT0z78jXQ1qkU['server_info']['time_now']
			except: pass
			if JT3DOogGUh7Nx:
				try:
					xuE9nIjqQ1Y2704h5k = Gb6kwVlSQ4MU.strptime(JT3DOogGUh7Nx,'%Y.%m.%d %H:%M:%S')
					ofNzXSTxHaqg3ebB1 = int(Gb6kwVlSQ4MU.mktime(xuE9nIjqQ1Y2704h5k))
					xySEbwG7Zhi0c9HMNldFDkU6vJ = int(npbh5qZo1PBiNkj-ofNzXSTxHaqg3ebB1)
					xySEbwG7Zhi0c9HMNldFDkU6vJ = int((xySEbwG7Zhi0c9HMNldFDkU6vJ+900)/1800)*1800
				except: pass
				try:
					xuE9nIjqQ1Y2704h5k = Gb6kwVlSQ4MU.localtime(int(gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['created_at']))
					PCAHU7rQavF = Gb6kwVlSQ4MU.strftime('%Y.%m.%d %H:%M:%S',xuE9nIjqQ1Y2704h5k)
				except: pass
				try:
					xuE9nIjqQ1Y2704h5k = Gb6kwVlSQ4MU.localtime(int(gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['exp_date']))
					c0f2LrnO5z = Gb6kwVlSQ4MU.strftime('%Y.%m.%d %H:%M:%S',xuE9nIjqQ1Y2704h5k)
				except: pass
			cad8TeSyMUYmfsEO0.setSetting('av.iptv.timestamp_'+j6W37Jtc8ryXDT95Phx,str(npbh5qZo1PBiNkj))
			cad8TeSyMUYmfsEO0.setSetting('av.iptv.timediff_'+j6W37Jtc8ryXDT95Phx,str(xySEbwG7Zhi0c9HMNldFDkU6vJ))
			try:
				bOIUfrATj9EW2YsQBV1XzcFg = '"server_info":'+ov9nVhCfMkz37xPgQOS.split('"server_info":')[1]
				bOIUfrATj9EW2YsQBV1XzcFg = bOIUfrATj9EW2YsQBV1XzcFg.replace(':',': ').replace(',',', ').replace('}}','}')
				DecEhLGPBK = RSuYINdeamsK0t.findall('"url": "(.*?)", "port": "(.*?)"',bOIUfrATj9EW2YsQBV1XzcFg,RSuYINdeamsK0t.DOTALL)
				sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = DecEhLGPBK[0]
			except: z3zSNULCoHJxfhk5eMiGWEpTXYBF = False
			if z3zSNULCoHJxfhk5eMiGWEpTXYBF and zM4WqLKfU03HChTsad:
				max = gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['max_connections']
				RKJ8kY2HhAGVQfp5cboTvg = gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['active_cons']
				YtHU3sREjklpnF7TMQG = gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['is_trial']
				gGd60Z1QoiyFSpqEW89R = SvBypP6sNKoYbiAeZUVF.split('?',1)
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW = 'URL:  '+nMt0iueCy6K+SvBypP6sNKoYbiAeZUVF+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\n\nStatus:  '+nMt0iueCy6K+oFGg2XBeH7PhTQRc4l+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\nTrial:    '+nMt0iueCy6K+str(YtHU3sREjklpnF7TMQG=='1')+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\nCreated  At:  '+nMt0iueCy6K+PCAHU7rQavF+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\nExpiry Date:  '+nMt0iueCy6K+c0f2LrnO5z+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\nConnections   ( Active / Maximum ) :  '+nMt0iueCy6K+RKJ8kY2HhAGVQfp5cboTvg+' / '+max+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\nAllowed Outputs:   '+nMt0iueCy6K+" , ".join(gb3Wy6fShH2JLT0z78jXQ1qkU['user_info']['allowed_output_formats'])+ZZoLlKyInXc08j2pTGJ
				BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\n\n'+bOIUfrATj9EW2YsQBV1XzcFg
				if oFGg2XBeH7PhTQRc4l=='Active': JJWH15tngbuPBpId('الاشتراك يعمل بدون مشاكل',BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
				else: JJWH15tngbuPBpId('يبدو أن هناك مشكلة في الاشتراك',BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	if SvBypP6sNKoYbiAeZUVF and z3zSNULCoHJxfhk5eMiGWEpTXYBF and oFGg2XBeH7PhTQRc4l=='Active':
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+SvBypP6sNKoYbiAeZUVF+' ]')
		E7Oap3UPWiS1eom2yM84nlkJGzwgXT = True
	else:
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,'Checking IPTV URL   [ Does not work ]   [ '+SvBypP6sNKoYbiAeZUVF+' ]')
		if zM4WqLKfU03HChTsad: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		E7Oap3UPWiS1eom2yM84nlkJGzwgXT = False
	return E7Oap3UPWiS1eom2yM84nlkJGzwgXT,sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM
def XZA9vYcOi4(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs,KKu9gxU3oSnMwldvkR,jRD6Yh2SiNut,zM4WqLKfU03HChTsad=True):
	if not jRD6Yh2SiNut: jRD6Yh2SiNut = '1'
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad): return
	alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs)
	QoNlOVqsvGLC = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list',ttCN9cTKWFIlmMDVpzs,KKu9gxU3oSnMwldvkR)
	U6EFlBDHxNSr = int(jRD6Yh2SiNut)*100
	GtHz43sOcmoYbVlW2D9MJNEZXAxh = U6EFlBDHxNSr-100
	for m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 in QoNlOVqsvGLC[GtHz43sOcmoYbVlW2D9MJNEZXAxh:U6EFlBDHxNSr]:
		Q1Qb6AMaEuDgjHkl = ('GROUPED' in ttCN9cTKWFIlmMDVpzs or ttCN9cTKWFIlmMDVpzs=='ALL')
		AXWL0SuCrg7NvhH4le9KT2sO5D = ('GROUPED' not in ttCN9cTKWFIlmMDVpzs and ttCN9cTKWFIlmMDVpzs!='ALL')
		if Q1Qb6AMaEuDgjHkl or AXWL0SuCrg7NvhH4le9KT2sO5D:
			if   'ARCHIVED'  in ttCN9cTKWFIlmMDVpzs: h9zFQKnsNL.menuItemsLIST.append(['folder',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,238,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,'ARCHIVED',Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx}])
			elif 'EPG' 		 in ttCN9cTKWFIlmMDVpzs: h9zFQKnsNL.menuItemsLIST.append(['folder',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,238,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,'FULL_EPG',Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx}])
			elif 'TIMESHIFT' in ttCN9cTKWFIlmMDVpzs: h9zFQKnsNL.menuItemsLIST.append(['folder',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,238,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,'TIMESHIFT',Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx}])
			elif 'LIVE' 	 in ttCN9cTKWFIlmMDVpzs: h9zFQKnsNL.menuItemsLIST.append(['live',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,235,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,m6cEejX1UO0HwpuvqL7xGA2VWJ,{'folder':j6W37Jtc8ryXDT95Phx}])
			else: h9zFQKnsNL.menuItemsLIST.append(['video',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,235,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx}])
	tRO48VjuUF = len(QoNlOVqsvGLC)
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(j6W37Jtc8ryXDT95Phx,jRD6Yh2SiNut,ttCN9cTKWFIlmMDVpzs,234,tRO48VjuUF,KKu9gxU3oSnMwldvkR)
	return
def cf0LvUBKDTCAlWi2ba3(KiCrQT7vlonu4D1XxHs):
	v0TjHlLZqkRxUCpmNwSy8AndO('link',KiCrQT7vlonu4D1XxHs+'هذه القائمة إما فارغة أو غير موجودة',Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',KiCrQT7vlonu4D1XxHs+'أو الخدمة غير موجودة في اشتراكك',Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',KiCrQT7vlonu4D1XxHs+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',Vk54F7GcROfCy6HunEI,9999)
	return
def dh1OAs2VijQreD8kJXFupZ(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs,KKu9gxU3oSnMwldvkR,jRD6Yh2SiNut,zeqwH7lKdJbaiVB39xmIu2jYrMWnst=Vk54F7GcROfCy6HunEI,zM4WqLKfU03HChTsad=True):
	if not jRD6Yh2SiNut: jRD6Yh2SiNut = '1'
	KiCrQT7vlonu4D1XxHs = klWfTZXjDY4qbPhvOKxd
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad): return False
	if '__SERIES__' in KKu9gxU3oSnMwldvkR: EE9y0b5qkCBgFXQHAGNi2xrpwh6,kYUTy3cFfgSi = KKu9gxU3oSnMwldvkR.split('__SERIES__')
	else: EE9y0b5qkCBgFXQHAGNi2xrpwh6,kYUTy3cFfgSi = KKu9gxU3oSnMwldvkR,Vk54F7GcROfCy6HunEI
	alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs)
	UUa2vGf03DpBMKAVtlXjxuzS9P1ZEF = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list',ttCN9cTKWFIlmMDVpzs,'__GROUPS__')
	if not UUa2vGf03DpBMKAVtlXjxuzS9P1ZEF: return False
	PylbqwSm49j = []
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Nx0lZXuS65tYU9QJpCTqw4cR2 in UUa2vGf03DpBMKAVtlXjxuzS9P1ZEF:
		if zeqwH7lKdJbaiVB39xmIu2jYrMWnst:
			if '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: KiCrQT7vlonu4D1XxHs = 'SERIES'
			elif '!!__UNKNOWN__!!' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: KiCrQT7vlonu4D1XxHs = 'UNKNOWN'
			elif 'LIVE' in ttCN9cTKWFIlmMDVpzs: KiCrQT7vlonu4D1XxHs = 'LIVE'
			else: KiCrQT7vlonu4D1XxHs = 'VIDEOS'
			KiCrQT7vlonu4D1XxHs = ','+nMt0iueCy6K+KiCrQT7vlonu4D1XxHs+': '+ZZoLlKyInXc08j2pTGJ
		if '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: pl0wQaXx4rDncWejVGNFSiY6zfb,FLAtsE10HMuhV5Kg9R76abvGydUpx = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.split('__SERIES__')
		else: pl0wQaXx4rDncWejVGNFSiY6zfb,FLAtsE10HMuhV5Kg9R76abvGydUpx = yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI
		if not KKu9gxU3oSnMwldvkR:
			if pl0wQaXx4rDncWejVGNFSiY6zfb in PylbqwSm49j: continue
			PylbqwSm49j.append(pl0wQaXx4rDncWejVGNFSiY6zfb)
			if 'RANDOM' in zeqwH7lKdJbaiVB39xmIu2jYrMWnst: v0TjHlLZqkRxUCpmNwSy8AndO('folder',KiCrQT7vlonu4D1XxHs+pl0wQaXx4rDncWejVGNFSiY6zfb,ttCN9cTKWFIlmMDVpzs,167,Vk54F7GcROfCy6HunEI,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
			elif '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: v0TjHlLZqkRxUCpmNwSy8AndO('folder',KiCrQT7vlonu4D1XxHs+pl0wQaXx4rDncWejVGNFSiY6zfb,ttCN9cTKWFIlmMDVpzs,233,Vk54F7GcROfCy6HunEI,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',KiCrQT7vlonu4D1XxHs+pl0wQaXx4rDncWejVGNFSiY6zfb,ttCN9cTKWFIlmMDVpzs,234,Vk54F7GcROfCy6HunEI,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
		elif '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w and pl0wQaXx4rDncWejVGNFSiY6zfb==EE9y0b5qkCBgFXQHAGNi2xrpwh6:
			if FLAtsE10HMuhV5Kg9R76abvGydUpx in PylbqwSm49j: continue
			PylbqwSm49j.append(FLAtsE10HMuhV5Kg9R76abvGydUpx)
			if 'RANDOM' in zeqwH7lKdJbaiVB39xmIu2jYrMWnst: v0TjHlLZqkRxUCpmNwSy8AndO('folder',KiCrQT7vlonu4D1XxHs+FLAtsE10HMuhV5Kg9R76abvGydUpx,ttCN9cTKWFIlmMDVpzs,167,Vk54F7GcROfCy6HunEI,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',KiCrQT7vlonu4D1XxHs+FLAtsE10HMuhV5Kg9R76abvGydUpx,ttCN9cTKWFIlmMDVpzs,234,Nx0lZXuS65tYU9QJpCTqw4cR2,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	h9zFQKnsNL.menuItemsLIST[:] = sorted(h9zFQKnsNL.menuItemsLIST,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT[1].lower())
	if not zeqwH7lKdJbaiVB39xmIu2jYrMWnst:
		U6EFlBDHxNSr = int(jRD6Yh2SiNut)*100
		GtHz43sOcmoYbVlW2D9MJNEZXAxh = U6EFlBDHxNSr-100
		tRO48VjuUF = len(h9zFQKnsNL.menuItemsLIST)
		h9zFQKnsNL.menuItemsLIST[:] = h9zFQKnsNL.menuItemsLIST[GtHz43sOcmoYbVlW2D9MJNEZXAxh:U6EFlBDHxNSr]
		zHSF4cMRhPp9ibC6ou1Yxna2lBq0(j6W37Jtc8ryXDT95Phx,jRD6Yh2SiNut,ttCN9cTKWFIlmMDVpzs,233,tRO48VjuUF,KKu9gxU3oSnMwldvkR)
	return True
def DK1oiaX2leIWFZ9TuCmwPHzpQRAL(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,w27xBlmt4DsQnSuGjhiNk61aX):
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,True): return
	KT67DQI1xk9XG34ezN0hH = a2LEDnNXSZTqVdoUM1GB5tvukHpQ(j6W37Jtc8ryXDT95Phx)
	ofNzXSTxHaqg3ebB1 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.timestamp_'+j6W37Jtc8ryXDT95Phx)
	if not ofNzXSTxHaqg3ebB1 or npbh5qZo1PBiNkj-int(ofNzXSTxHaqg3ebB1)>24*uuXTYKmMekIRQfcDd0:
		E7Oap3UPWiS1eom2yM84nlkJGzwgXT,sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,False)
		if not E7Oap3UPWiS1eom2yM84nlkJGzwgXT: return
	xySEbwG7Zhi0c9HMNldFDkU6vJ = int(cad8TeSyMUYmfsEO0.getSetting('av.iptv.timediff_'+j6W37Jtc8ryXDT95Phx))
	AHfRNJaOSdgIUE3CMeK = cad8TeSyMUYmfsEO0.getSetting('av.iptv.server_'+j6W37Jtc8ryXDT95Phx)
	RrJQvd9mBH46bclqoI0iCYK2Zj3 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.username_'+j6W37Jtc8ryXDT95Phx)
	NNCyFG5MO3ewBI9k = cad8TeSyMUYmfsEO0.getSetting('av.iptv.password_'+j6W37Jtc8ryXDT95Phx)
	ZavOVkcrf0LJ2pYhbl = lI5ck2gjRCiw9bMTF0xHsG.split('/')
	YHay2PUb10lQzhvg9tkn5oLSBI8q = ZavOVkcrf0LJ2pYhbl[-1].replace('.ts',Vk54F7GcROfCy6HunEI).replace('.m3u8',Vk54F7GcROfCy6HunEI)
	if w27xBlmt4DsQnSuGjhiNk61aX=='SHORT_EPG': hEVaw1Pn8rp = 'get_short_epg'
	else: hEVaw1Pn8rp = 'get_simple_data_table'
	SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k = OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx)
	if not RrJQvd9mBH46bclqoI0iCYK2Zj3: return
	MIFdcLJ7hfYtVxAHDNlpnuXjem4zbG = SvBypP6sNKoYbiAeZUVF+'&action='+hEVaw1Pn8rp+'&stream_id='+YHay2PUb10lQzhvg9tkn5oLSBI8q
	ov9nVhCfMkz37xPgQOS = WdAsPN7Ovr2TGkXySczhLKxZ5fw0(AOhmwtSyYBn4ZF7RuvQNU,MIFdcLJ7hfYtVxAHDNlpnuXjem4zbG,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,'IPTV-EPG_ITEMS-2nd')
	fIA8tO6asgRQxvM0SPnb3kN = Bw6jaUcFxlqdDT8bC('dict',ov9nVhCfMkz37xPgQOS)
	EptQ0dno4xGfh8WSXZy = fIA8tO6asgRQxvM0SPnb3kN['epg_listings']
	j140jJaQVXKgzm8IGNbcw6hOEZyp = []
	if w27xBlmt4DsQnSuGjhiNk61aX in ['ARCHIVED','TIMESHIFT']:
		for gb3Wy6fShH2JLT0z78jXQ1qkU in EptQ0dno4xGfh8WSXZy:
			if gb3Wy6fShH2JLT0z78jXQ1qkU['has_archive']==1:
				j140jJaQVXKgzm8IGNbcw6hOEZyp.append(gb3Wy6fShH2JLT0z78jXQ1qkU)
				if w27xBlmt4DsQnSuGjhiNk61aX in ['TIMESHIFT']: break
		if not j140jJaQVXKgzm8IGNbcw6hOEZyp: return
		v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+nMt0iueCy6K+'الملفات الأولي بهذه القائمة قد لا تعمل'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		if w27xBlmt4DsQnSuGjhiNk61aX in ['TIMESHIFT']:
			QjVBFLcbS5t = 2
			eEucjdwHAhGJs4 = QjVBFLcbS5t*uuXTYKmMekIRQfcDd0
			j140jJaQVXKgzm8IGNbcw6hOEZyp = []
			XCjfVGsLvAuaQYeHNi6 = int(int(gb3Wy6fShH2JLT0z78jXQ1qkU['start_timestamp'])/eEucjdwHAhGJs4)*eEucjdwHAhGJs4
			fJEB5S9yoFu = npbh5qZo1PBiNkj+eEucjdwHAhGJs4
			wyI4MKO7vG923WUu8opmkjDJdlafr = int((fJEB5S9yoFu-XCjfVGsLvAuaQYeHNi6)/uuXTYKmMekIRQfcDd0)
			for qqyTLbPBFOKAI70wt3U in range(wyI4MKO7vG923WUu8opmkjDJdlafr):
				if qqyTLbPBFOKAI70wt3U>=6:
					if qqyTLbPBFOKAI70wt3U%QjVBFLcbS5t!=0: continue
					jJ4g2lcwIi6eVOoFQf = eEucjdwHAhGJs4
				else: jJ4g2lcwIi6eVOoFQf = eEucjdwHAhGJs4//2
				z7zRuT3W4AsygJwFhLpU1lH = XCjfVGsLvAuaQYeHNi6+qqyTLbPBFOKAI70wt3U*uuXTYKmMekIRQfcDd0
				gb3Wy6fShH2JLT0z78jXQ1qkU = {}
				gb3Wy6fShH2JLT0z78jXQ1qkU['title'] = Vk54F7GcROfCy6HunEI
				xuE9nIjqQ1Y2704h5k = Gb6kwVlSQ4MU.localtime(z7zRuT3W4AsygJwFhLpU1lH-xySEbwG7Zhi0c9HMNldFDkU6vJ-uuXTYKmMekIRQfcDd0)
				gb3Wy6fShH2JLT0z78jXQ1qkU['start'] = Gb6kwVlSQ4MU.strftime('%Y.%m.%d %H:%M:%S',xuE9nIjqQ1Y2704h5k)
				gb3Wy6fShH2JLT0z78jXQ1qkU['start_timestamp'] = str(z7zRuT3W4AsygJwFhLpU1lH)
				gb3Wy6fShH2JLT0z78jXQ1qkU['stop_timestamp'] = str(z7zRuT3W4AsygJwFhLpU1lH+jJ4g2lcwIi6eVOoFQf)
				j140jJaQVXKgzm8IGNbcw6hOEZyp.append(gb3Wy6fShH2JLT0z78jXQ1qkU)
	elif w27xBlmt4DsQnSuGjhiNk61aX in ['SHORT_EPG','FULL_EPG']: j140jJaQVXKgzm8IGNbcw6hOEZyp = EptQ0dno4xGfh8WSXZy
	if w27xBlmt4DsQnSuGjhiNk61aX=='FULL_EPG' and len(j140jJaQVXKgzm8IGNbcw6hOEZyp)>0:
		v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+nMt0iueCy6K+'هذه قائمة برامج القنوات (جدول فقط)ـ'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	ZJjeMlwR62AWPbQp8FVT3La1kKSX = []
	Nx0lZXuS65tYU9QJpCTqw4cR2 = J2L6to3R1Z.getInfoLabel('ListItem.Icon')
	for gb3Wy6fShH2JLT0z78jXQ1qkU in j140jJaQVXKgzm8IGNbcw6hOEZyp:
		qXzxUjlRydGDhOQ9fM3a8tp4ZKe = PnRA5dpzE18JU.b64decode(gb3Wy6fShH2JLT0z78jXQ1qkU['title'])
		if PvwFsJK23NbU8XWAx: qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.decode(AoCWwJHgUPKXI7u2lEzym)
		z7zRuT3W4AsygJwFhLpU1lH = int(gb3Wy6fShH2JLT0z78jXQ1qkU['start_timestamp'])
		BbFdTIzLkR0jsSgtEH5VXJ8Zmv = int(gb3Wy6fShH2JLT0z78jXQ1qkU['stop_timestamp'])
		MrlpBfAF2J = str(int((BbFdTIzLkR0jsSgtEH5VXJ8Zmv-z7zRuT3W4AsygJwFhLpU1lH+59)/60))
		deF2RXx0l6KQBaigV3tHjGmkyIf = gb3Wy6fShH2JLT0z78jXQ1qkU['start'].replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,':')
		xuE9nIjqQ1Y2704h5k = Gb6kwVlSQ4MU.localtime(z7zRuT3W4AsygJwFhLpU1lH-uuXTYKmMekIRQfcDd0)
		oSLW1Blm6IMPzX4 = Gb6kwVlSQ4MU.strftime('%H:%M',xuE9nIjqQ1Y2704h5k)
		DPph1wcaTHMCQeOL4 = Gb6kwVlSQ4MU.strftime('%a',xuE9nIjqQ1Y2704h5k)
		if w27xBlmt4DsQnSuGjhiNk61aX=='SHORT_EPG': qXzxUjlRydGDhOQ9fM3a8tp4ZKe = d761ZWXHEvliYN45RzLP2+oSLW1Blm6IMPzX4+' ـ '+qXzxUjlRydGDhOQ9fM3a8tp4ZKe+ZZoLlKyInXc08j2pTGJ
		elif w27xBlmt4DsQnSuGjhiNk61aX=='TIMESHIFT': qXzxUjlRydGDhOQ9fM3a8tp4ZKe = DPph1wcaTHMCQeOL4+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+oSLW1Blm6IMPzX4+' ('+MrlpBfAF2J+'min)'
		else: qXzxUjlRydGDhOQ9fM3a8tp4ZKe = DPph1wcaTHMCQeOL4+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+oSLW1Blm6IMPzX4+' ('+MrlpBfAF2J+'min)   '+qXzxUjlRydGDhOQ9fM3a8tp4ZKe+' ـ'
		if w27xBlmt4DsQnSuGjhiNk61aX in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			vcE2OR8Yhyl6K9oVNGb1W5 = AHfRNJaOSdgIUE3CMeK+'/timeshift/'+RrJQvd9mBH46bclqoI0iCYK2Zj3+'/'+NNCyFG5MO3ewBI9k+'/'+MrlpBfAF2J+'/'+deF2RXx0l6KQBaigV3tHjGmkyIf+'/'+YHay2PUb10lQzhvg9tkn5oLSBI8q+'.m3u8'
			if w27xBlmt4DsQnSuGjhiNk61aX=='FULL_EPG': v0TjHlLZqkRxUCpmNwSy8AndO('link',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,vcE2OR8Yhyl6K9oVNGb1W5,9999,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,vcE2OR8Yhyl6K9oVNGb1W5,235,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
		ZJjeMlwR62AWPbQp8FVT3La1kKSX.append(qXzxUjlRydGDhOQ9fM3a8tp4ZKe)
	if w27xBlmt4DsQnSuGjhiNk61aX=='SHORT_EPG' and ZJjeMlwR62AWPbQp8FVT3La1kKSX: vFHiI5uK0DgzPCBmfa = Rx1mwkch5ZKu(ZJjeMlwR62AWPbQp8FVT3La1kKSX)
	return ZJjeMlwR62AWPbQp8FVT3La1kKSX
def NHRMs1X5gPT7dA29n(j6W37Jtc8ryXDT95Phx):
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,True): return
	AHfRNJaOSdgIUE3CMeK,rGYMJtBEvmFQWLIu2l6fT,J01MEQhjPxGFnNfZL2eqdrvUszmOS = Vk54F7GcROfCy6HunEI,0,0
	E7Oap3UPWiS1eom2yM84nlkJGzwgXT,sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,False)
	if E7Oap3UPWiS1eom2yM84nlkJGzwgXT:
		llQyYaqAVdcMfbwWDL4FG = LUYAScDEWagR9o(sb2wFzSlq7J8mNyHrCDLTXnZGe6)
		rGYMJtBEvmFQWLIu2l6fT = JSmOA1XwhMN4IrcqeYPgEB652xl(llQyYaqAVdcMfbwWDL4FG[0],int(JAqX9QVlhetaWpnL6RZM))
		alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,'LIVE_GROUPED')
		rxvoadmqAXiW6SRE0zn7hVtuwyCkfF = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list','LIVE_GROUPED')
		QoNlOVqsvGLC = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list','LIVE_GROUPED',rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[1])
		lI5ck2gjRCiw9bMTF0xHsG = QoNlOVqsvGLC[0][2]
		XFHTCI92r3cdEY04Jqfw = RSuYINdeamsK0t.findall('://(.*?)/',lI5ck2gjRCiw9bMTF0xHsG,RSuYINdeamsK0t.DOTALL)
		XFHTCI92r3cdEY04Jqfw = XFHTCI92r3cdEY04Jqfw[0]
		if ':' in XFHTCI92r3cdEY04Jqfw: EMnBC3beGvPXg,QQa2wPpn1TSz8j3CZtEdAxM4yRhic = XFHTCI92r3cdEY04Jqfw.split(':')
		else: EMnBC3beGvPXg,QQa2wPpn1TSz8j3CZtEdAxM4yRhic = XFHTCI92r3cdEY04Jqfw,'80'
		z9IGL7gWKuav = LUYAScDEWagR9o(EMnBC3beGvPXg)
		J01MEQhjPxGFnNfZL2eqdrvUszmOS = JSmOA1XwhMN4IrcqeYPgEB652xl(z9IGL7gWKuav[0],int(QQa2wPpn1TSz8j3CZtEdAxM4yRhic))
	if rGYMJtBEvmFQWLIu2l6fT and J01MEQhjPxGFnNfZL2eqdrvUszmOS:
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\n\n'+'وقت ضائع في السيرفر الأصلي'+ixrPWKeFMnqJyVodX6D9AaO2+str(int(J01MEQhjPxGFnNfZL2eqdrvUszmOS*1000))+' ملي ثانية'
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW += '\n\n'+'وقت ضائع في السيرفر البديل'+ixrPWKeFMnqJyVodX6D9AaO2+str(int(rGYMJtBEvmFQWLIu2l6fT*1000))+' ملي ثانية'
		wP56xXV9CSE8 = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		if wP56xXV9CSE8==1 and rGYMJtBEvmFQWLIu2l6fT<J01MEQhjPxGFnNfZL2eqdrvUszmOS: AHfRNJaOSdgIUE3CMeK = sb2wFzSlq7J8mNyHrCDLTXnZGe6+':'+JAqX9QVlhetaWpnL6RZM
	else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.server_'+j6W37Jtc8ryXDT95Phx,AHfRNJaOSdgIUE3CMeK)
	return
def h5hmzOAeWEPip(j6W37Jtc8ryXDT95Phx,lI5ck2gjRCiw9bMTF0xHsG,hArRgv5l10sU2yVSCO9JBHbE):
	tkB9WV43hJHYajEydLDzIi6 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx)
	ywzJ068n3TOm7jrxRlEaPA = cad8TeSyMUYmfsEO0.getSetting('av.iptv.referer_'+j6W37Jtc8ryXDT95Phx)
	if tkB9WV43hJHYajEydLDzIi6 or ywzJ068n3TOm7jrxRlEaPA:
		lI5ck2gjRCiw9bMTF0xHsG += '|'
		if tkB9WV43hJHYajEydLDzIi6: lI5ck2gjRCiw9bMTF0xHsG += '&User-Agent='+tkB9WV43hJHYajEydLDzIi6
		if ywzJ068n3TOm7jrxRlEaPA: lI5ck2gjRCiw9bMTF0xHsG += '&Referer='+ywzJ068n3TOm7jrxRlEaPA
		lI5ck2gjRCiw9bMTF0xHsG = lI5ck2gjRCiw9bMTF0xHsG.replace('|&','|')
	hYC4PrHumSvqJbs9KxW = cad8TeSyMUYmfsEO0.getSetting('av.iptv.server_'+j6W37Jtc8ryXDT95Phx)
	if hYC4PrHumSvqJbs9KxW:
		q6GYWJFIrP5onDS0zldUxw = RSuYINdeamsK0t.findall('://(.*?)/',lI5ck2gjRCiw9bMTF0xHsG,RSuYINdeamsK0t.DOTALL)
		lI5ck2gjRCiw9bMTF0xHsG = lI5ck2gjRCiw9bMTF0xHsG.replace(q6GYWJFIrP5onDS0zldUxw[0],hYC4PrHumSvqJbs9KxW)
	qnUlyF2JXuGYdSA6Iac1(lI5ck2gjRCiw9bMTF0xHsG,ILyVox7aiXM148nz,hArRgv5l10sU2yVSCO9JBHbE)
	return
def K9n0oVpzxZOLG4b3wHf2vWjmuXEIr(j6W37Jtc8ryXDT95Phx):
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	tkB9WV43hJHYajEydLDzIi6 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx)
	PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center','استخدام الأصلي','تعديل القديم',tkB9WV43hJHYajEydLDzIi6,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if PgYTqUkOXsftbQSKEciZxwp9uaB==1: tkB9WV43hJHYajEydLDzIi6 = p3bB2auMmSjXC0dE8FUfZ('أكتب ـIPTV User-Agent جديد',tkB9WV43hJHYajEydLDzIi6,True)
	else: tkB9WV43hJHYajEydLDzIi6 = 'Unknown'
	if tkB9WV43hJHYajEydLDzIi6==otBWsSAfu7dihVkP9e1JFKrvmYy2Q:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tkB9WV43hJHYajEydLDzIi6,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if PgYTqUkOXsftbQSKEciZxwp9uaB!=1:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم الإلغاء')
		return
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx,tkB9WV43hJHYajEydLDzIi6)
	BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx)
	return
def QjiCnYpR3MNJbBkDTOGu1Emgvr5Z(j6W37Jtc8ryXDT95Phx):
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	ywzJ068n3TOm7jrxRlEaPA = cad8TeSyMUYmfsEO0.getSetting('av.iptv.referer_'+j6W37Jtc8ryXDT95Phx)
	PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center','استخدام الأصلي','تعديل القديم',ywzJ068n3TOm7jrxRlEaPA,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if PgYTqUkOXsftbQSKEciZxwp9uaB==1: ywzJ068n3TOm7jrxRlEaPA = p3bB2auMmSjXC0dE8FUfZ('أكتب ـIPTV Referer جديد',ywzJ068n3TOm7jrxRlEaPA,True)
	else: ywzJ068n3TOm7jrxRlEaPA = Vk54F7GcROfCy6HunEI
	if ywzJ068n3TOm7jrxRlEaPA==otBWsSAfu7dihVkP9e1JFKrvmYy2Q:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ywzJ068n3TOm7jrxRlEaPA,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if PgYTqUkOXsftbQSKEciZxwp9uaB!=1:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم الإلغاء')
		return
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.referer_'+j6W37Jtc8ryXDT95Phx,ywzJ068n3TOm7jrxRlEaPA)
	BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx)
	return
def OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx,yvjN7L154ePDsV26HzRrY8nTc=Vk54F7GcROfCy6HunEI):
	if not yvjN7L154ePDsV26HzRrY8nTc: yvjN7L154ePDsV26HzRrY8nTc = cad8TeSyMUYmfsEO0.getSetting('av.iptv.url_'+j6W37Jtc8ryXDT95Phx)
	AHfRNJaOSdgIUE3CMeK = RRav1Sf7Px(yvjN7L154ePDsV26HzRrY8nTc,'url')
	RrJQvd9mBH46bclqoI0iCYK2Zj3 = RSuYINdeamsK0t.findall('username=(.*?)&',yvjN7L154ePDsV26HzRrY8nTc+'&',RSuYINdeamsK0t.DOTALL)
	NNCyFG5MO3ewBI9k = RSuYINdeamsK0t.findall('password=(.*?)&',yvjN7L154ePDsV26HzRrY8nTc+'&',RSuYINdeamsK0t.DOTALL)
	if not RrJQvd9mBH46bclqoI0iCYK2Zj3 or not NNCyFG5MO3ewBI9k:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	RrJQvd9mBH46bclqoI0iCYK2Zj3 = RrJQvd9mBH46bclqoI0iCYK2Zj3[0]
	NNCyFG5MO3ewBI9k = NNCyFG5MO3ewBI9k[0]
	SvBypP6sNKoYbiAeZUVF = AHfRNJaOSdgIUE3CMeK+'/player_api.php?username='+RrJQvd9mBH46bclqoI0iCYK2Zj3+'&password='+NNCyFG5MO3ewBI9k
	Po42eiOLy73c = AHfRNJaOSdgIUE3CMeK+'/get.php?username='+RrJQvd9mBH46bclqoI0iCYK2Zj3+'&password='+NNCyFG5MO3ewBI9k+'&type=m3u_plus'
	return SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k
def lvwFBh25Lb40pYMeEIKz3Ha6C(j6W37Jtc8ryXDT95Phx,ssIwfcHRomN4=Vk54F7GcROfCy6HunEI):
	FhjDnISCYHVv7ymgQxpfREXat2J = ssIwfcHRomN4.replace('/','_').replace(':','_').replace('.','_')
	FhjDnISCYHVv7ymgQxpfREXat2J = FhjDnISCYHVv7ymgQxpfREXat2J.replace('?','_').replace('=','_').replace('&','_')
	FhjDnISCYHVv7ymgQxpfREXat2J = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,FhjDnISCYHVv7ymgQxpfREXat2J).strip('.m3u')+'.m3u'
	return FhjDnISCYHVv7ymgQxpfREXat2J
def muVeMOGUgnkyd9wsNA4(j6W37Jtc8ryXDT95Phx):
	pVofxIH8UCgWmJwBNDuzkht = cad8TeSyMUYmfsEO0.getSetting('av.iptv.url_'+j6W37Jtc8ryXDT95Phx)
	ePXbGhrzt6yg5ucdvwK8x72FVAlWm = True
	if pVofxIH8UCgWmJwBNDuzkht:
		PgYTqUkOXsftbQSKEciZxwp9uaB = rAdiM2DVzBuxjPvYFTQs('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',nMt0iueCy6K+pVofxIH8UCgWmJwBNDuzkht+ZZoLlKyInXc08j2pTGJ+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if PgYTqUkOXsftbQSKEciZxwp9uaB==-1: return
		elif PgYTqUkOXsftbQSKEciZxwp9uaB==0: pVofxIH8UCgWmJwBNDuzkht = Vk54F7GcROfCy6HunEI
		elif PgYTqUkOXsftbQSKEciZxwp9uaB==2:
			PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if PgYTqUkOXsftbQSKEciZxwp9uaB in [-1,0]: return
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم مسح الرابط')
			ePXbGhrzt6yg5ucdvwK8x72FVAlWm = False
			xlV9npTe6ytahmUJbd7zcsEfAv = Vk54F7GcROfCy6HunEI
	if ePXbGhrzt6yg5ucdvwK8x72FVAlWm:
		xlV9npTe6ytahmUJbd7zcsEfAv = p3bB2auMmSjXC0dE8FUfZ('اكتب رابط ـIPTV كاملا',pVofxIH8UCgWmJwBNDuzkht)
		xlV9npTe6ytahmUJbd7zcsEfAv = xlV9npTe6ytahmUJbd7zcsEfAv.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not xlV9npTe6ytahmUJbd7zcsEfAv:
			PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if PgYTqUkOXsftbQSKEciZxwp9uaB in [-1,0]: return
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم مسح الرابط')
	else:
		SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k = OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx,xlV9npTe6ytahmUJbd7zcsEfAv)
		if not RrJQvd9mBH46bclqoI0iCYK2Zj3: return
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+AHfRNJaOSdgIUE3CMeK+ZZoLlKyInXc08j2pTGJ+'عنوان السيرفر: '
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+RrJQvd9mBH46bclqoI0iCYK2Zj3+ZZoLlKyInXc08j2pTGJ+'اسم المستخدم: '
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+DDRlM68ye4nc10bJWkaFAosirG++'كلمة السر: '
		PgYTqUkOXsftbQSKEciZxwp9uaB = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('right',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'الرابط الجديد هو:',nMt0iueCy6K+xlV9npTe6ytahmUJbd7zcsEfAv+ZZoLlKyInXc08j2pTGJ+'\n\n'+BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		if PgYTqUkOXsftbQSKEciZxwp9uaB!=1:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم الإلغاء')
			return
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.url_'+j6W37Jtc8ryXDT95Phx,xlV9npTe6ytahmUJbd7zcsEfAv)
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.timestamp_'+j6W37Jtc8ryXDT95Phx,Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting('av.iptv.timediff_'+j6W37Jtc8ryXDT95Phx,Vk54F7GcROfCy6HunEI)
	tkB9WV43hJHYajEydLDzIi6 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx)
	if not tkB9WV43hJHYajEydLDzIi6: cad8TeSyMUYmfsEO0.setSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx,'Unknown')
	k38YUrZAxhagtEM0yDbKq = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,xlV9npTe6ytahmUJbd7zcsEfAv+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if k38YUrZAxhagtEM0yDbKq==1: E7Oap3UPWiS1eom2yM84nlkJGzwgXT,sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,True)
	BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx)
	return
def oohidwAg2ypVztckI(p74HvfYKXiexEOAPR9BUNkq0u,ppBMuojq7ZEAtesD,NfZq8QdxRcXLTvjSPYHDk,fgiuLwj4vykqNxXKQVnh,X5XWZFgTmNGfxsOcrqKjLaQwE,AyCmXWaeTFD9O8GwucvM03qi1,Po42eiOLy73c):
	QoNlOVqsvGLC,AMhE4K9Q2I7WN6 = [],[]
	xbGwKO4i6jeu = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		if AyCmXWaeTFD9O8GwucvM03qi1%473==0:
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,40+int(10*AyCmXWaeTFD9O8GwucvM03qi1/X5XWZFgTmNGfxsOcrqKjLaQwE),'قراءة الفيديوهات','الفيديو رقم:-',str(AyCmXWaeTFD9O8GwucvM03qi1)+' / '+str(X5XWZFgTmNGfxsOcrqKjLaQwE))
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return None,None,None
		lI5ck2gjRCiw9bMTF0xHsG = RSuYINdeamsK0t.findall('^(.*?)\n+((http|https|rtmp).*?)$',uDJxNtKl2gLkR6zC7OZWEf1cjvF059,RSuYINdeamsK0t.DOTALL)
		if lI5ck2gjRCiw9bMTF0xHsG:
			uDJxNtKl2gLkR6zC7OZWEf1cjvF059,lI5ck2gjRCiw9bMTF0xHsG,avxZKMEsw9BTjVDuikc = lI5ck2gjRCiw9bMTF0xHsG[0]
			lI5ck2gjRCiw9bMTF0xHsG = lI5ck2gjRCiw9bMTF0xHsG.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI)
			uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI)
		else:
			AMhE4K9Q2I7WN6.append({'line':uDJxNtKl2gLkR6zC7OZWEf1cjvF059})
			continue
		Q0IDpm9BgJG,m6cEejX1UO0HwpuvqL7xGA2VWJ,yIiE1cO8rWlRZPNLJ9jMb5tToex6w,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,hArRgv5l10sU2yVSCO9JBHbE,x38i1GrBkWIch2gAEm6MV = {},Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,False
		try:
			uDJxNtKl2gLkR6zC7OZWEf1cjvF059,qXzxUjlRydGDhOQ9fM3a8tp4ZKe = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.rsplit('",',1)
			uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = uDJxNtKl2gLkR6zC7OZWEf1cjvF059+'"'
		except:
			try: uDJxNtKl2gLkR6zC7OZWEf1cjvF059,qXzxUjlRydGDhOQ9fM3a8tp4ZKe = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.rsplit('1,',1)
			except: qXzxUjlRydGDhOQ9fM3a8tp4ZKe = Vk54F7GcROfCy6HunEI
		Q0IDpm9BgJG['url'] = lI5ck2gjRCiw9bMTF0xHsG
		q3B2PAazM4oc = RSuYINdeamsK0t.findall(' (.*?)="(.*?)"',uDJxNtKl2gLkR6zC7OZWEf1cjvF059,RSuYINdeamsK0t.DOTALL)
		for ddUWzEgl3bhS0oi5MkuT,GIA5xasoXQJ6MelpHD in q3B2PAazM4oc:
			ddUWzEgl3bhS0oi5MkuT = ddUWzEgl3bhS0oi5MkuT.replace('"',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			Q0IDpm9BgJG[ddUWzEgl3bhS0oi5MkuT] = GIA5xasoXQJ6MelpHD.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		MzxcahekYtLvU54pPgBdjfTQnSGRm = list(Q0IDpm9BgJG.keys())
		if not qXzxUjlRydGDhOQ9fM3a8tp4ZKe:
			if 'name' in MzxcahekYtLvU54pPgBdjfTQnSGRm and Q0IDpm9BgJG['name']: qXzxUjlRydGDhOQ9fM3a8tp4ZKe = Q0IDpm9BgJG['name']
		Q0IDpm9BgJG['title'] = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'logo' in MzxcahekYtLvU54pPgBdjfTQnSGRm:
			Q0IDpm9BgJG['img'] = Q0IDpm9BgJG['logo']
			del Q0IDpm9BgJG['logo']
		else: Q0IDpm9BgJG['img'] = Vk54F7GcROfCy6HunEI
		if 'group' in MzxcahekYtLvU54pPgBdjfTQnSGRm and Q0IDpm9BgJG['group']: yIiE1cO8rWlRZPNLJ9jMb5tToex6w = Q0IDpm9BgJG['group']
		if any(value in lI5ck2gjRCiw9bMTF0xHsG.lower() for value in xbGwKO4i6jeu):
			x38i1GrBkWIch2gAEm6MV = True if 'm3u' not in lI5ck2gjRCiw9bMTF0xHsG else False
		if x38i1GrBkWIch2gAEm6MV or '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w or '__MOVIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w:
			hArRgv5l10sU2yVSCO9JBHbE = 'VOD'
			if '__SERIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: hArRgv5l10sU2yVSCO9JBHbE = hArRgv5l10sU2yVSCO9JBHbE+'_SERIES'
			elif '__MOVIES__' in yIiE1cO8rWlRZPNLJ9jMb5tToex6w: hArRgv5l10sU2yVSCO9JBHbE = hArRgv5l10sU2yVSCO9JBHbE+'_MOVIES'
			else: hArRgv5l10sU2yVSCO9JBHbE = hArRgv5l10sU2yVSCO9JBHbE+'_UNKNOWN'
			yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.replace('__SERIES__',Vk54F7GcROfCy6HunEI).replace('__MOVIES__',Vk54F7GcROfCy6HunEI)
		else:
			hArRgv5l10sU2yVSCO9JBHbE = 'LIVE'
			if qXzxUjlRydGDhOQ9fM3a8tp4ZKe in ppBMuojq7ZEAtesD: m6cEejX1UO0HwpuvqL7xGA2VWJ = m6cEejX1UO0HwpuvqL7xGA2VWJ+'_EPG'
			if qXzxUjlRydGDhOQ9fM3a8tp4ZKe in NfZq8QdxRcXLTvjSPYHDk: m6cEejX1UO0HwpuvqL7xGA2VWJ = m6cEejX1UO0HwpuvqL7xGA2VWJ+'_ARCHIVED'
			if not yIiE1cO8rWlRZPNLJ9jMb5tToex6w: hArRgv5l10sU2yVSCO9JBHbE = hArRgv5l10sU2yVSCO9JBHbE+'_UNKNOWN'
			else: hArRgv5l10sU2yVSCO9JBHbE = hArRgv5l10sU2yVSCO9JBHbE+m6cEejX1UO0HwpuvqL7xGA2VWJ
		yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'LIVE_UNKNOWN' in hArRgv5l10sU2yVSCO9JBHbE: yIiE1cO8rWlRZPNLJ9jMb5tToex6w = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in hArRgv5l10sU2yVSCO9JBHbE: yIiE1cO8rWlRZPNLJ9jMb5tToex6w = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in hArRgv5l10sU2yVSCO9JBHbE:
			umjxBa8ApCg6eWNrnlyYT7EFDo1k = RSuYINdeamsK0t.findall('(.*?) [Ss]\d+ +[Ee]\d+',Q0IDpm9BgJG['title'],RSuYINdeamsK0t.DOTALL)
			if umjxBa8ApCg6eWNrnlyYT7EFDo1k: umjxBa8ApCg6eWNrnlyYT7EFDo1k = umjxBa8ApCg6eWNrnlyYT7EFDo1k[0]
			else: umjxBa8ApCg6eWNrnlyYT7EFDo1k = '!!__UNKNOWN_SERIES__!!'
			yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w+'__SERIES__'+umjxBa8ApCg6eWNrnlyYT7EFDo1k
		if 'id' in MzxcahekYtLvU54pPgBdjfTQnSGRm: del Q0IDpm9BgJG['id']
		if 'ID' in MzxcahekYtLvU54pPgBdjfTQnSGRm: del Q0IDpm9BgJG['ID']
		if 'name' in MzxcahekYtLvU54pPgBdjfTQnSGRm: del Q0IDpm9BgJG['name']
		qXzxUjlRydGDhOQ9fM3a8tp4ZKe = Q0IDpm9BgJG['title']
		qXzxUjlRydGDhOQ9fM3a8tp4ZKe = ww25jXuxtpK1TOJEbGUgrm8(qXzxUjlRydGDhOQ9fM3a8tp4ZKe)
		qXzxUjlRydGDhOQ9fM3a8tp4ZKe = IOLrXisTBet7JMy2ou5hkz1KPUjGdS(qXzxUjlRydGDhOQ9fM3a8tp4ZKe)
		TK9iFC0yPG,yIiE1cO8rWlRZPNLJ9jMb5tToex6w = dglAEmoWjGVNK(yIiE1cO8rWlRZPNLJ9jMb5tToex6w)
		Ql5pX3S2Lu,qXzxUjlRydGDhOQ9fM3a8tp4ZKe = dglAEmoWjGVNK(qXzxUjlRydGDhOQ9fM3a8tp4ZKe)
		Q0IDpm9BgJG['type'] = hArRgv5l10sU2yVSCO9JBHbE
		Q0IDpm9BgJG['context'] = m6cEejX1UO0HwpuvqL7xGA2VWJ
		Q0IDpm9BgJG['group'] = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.upper()
		Q0IDpm9BgJG['title'] = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.upper()
		Q0IDpm9BgJG['country'] = Ql5pX3S2Lu.upper()
		Q0IDpm9BgJG['language'] = TK9iFC0yPG.upper()
		QoNlOVqsvGLC.append(Q0IDpm9BgJG)
		AyCmXWaeTFD9O8GwucvM03qi1 += 1
	return QoNlOVqsvGLC,AyCmXWaeTFD9O8GwucvM03qi1,AMhE4K9Q2I7WN6
def IOLrXisTBet7JMy2ou5hkz1KPUjGdS(qXzxUjlRydGDhOQ9fM3a8tp4ZKe):
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.replace('||','|').replace('___',':').replace('--','-')
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.replace('[[','[').replace(']]',']')
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.replace('((','(').replace('))',')')
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.replace('<<','<').replace('>>','>')
	qXzxUjlRydGDhOQ9fM3a8tp4ZKe = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	return qXzxUjlRydGDhOQ9fM3a8tp4ZKe
def jjrBzpf74NnVMgGWkT3H5bJImlR1t(utBebMzoFwEmOrD0GaKT,fgiuLwj4vykqNxXKQVnh):
	kvNQyGf6g7UZT2lrmHL3cb = {}
	for qiCPWMLTsNk9QyAObtDBH7m in RnlvXActfLaqGDzB6VH: kvNQyGf6g7UZT2lrmHL3cb[qiCPWMLTsNk9QyAObtDBH7m] = []
	X5XWZFgTmNGfxsOcrqKjLaQwE = len(utBebMzoFwEmOrD0GaKT)
	kkz5EOduci39 = str(X5XWZFgTmNGfxsOcrqKjLaQwE)
	AyCmXWaeTFD9O8GwucvM03qi1 = 0
	AMhE4K9Q2I7WN6 = []
	for Q0IDpm9BgJG in utBebMzoFwEmOrD0GaKT:
		if AyCmXWaeTFD9O8GwucvM03qi1%873==0:
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,50+int(5*AyCmXWaeTFD9O8GwucvM03qi1/X5XWZFgTmNGfxsOcrqKjLaQwE),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(AyCmXWaeTFD9O8GwucvM03qi1)+' / '+kkz5EOduci39)
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return None,None
		yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 = Q0IDpm9BgJG['group'],Q0IDpm9BgJG['context'],Q0IDpm9BgJG['title'],Q0IDpm9BgJG['url'],Q0IDpm9BgJG['img']
		Ql5pX3S2Lu,TK9iFC0yPG,qiCPWMLTsNk9QyAObtDBH7m = Q0IDpm9BgJG['country'],Q0IDpm9BgJG['language'],Q0IDpm9BgJG['type']
		kTyJhvpuYgKEZzwGsS2a4 = (yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2)
		cdNCx41S8a = False
		if 'LIVE' in qiCPWMLTsNk9QyAObtDBH7m:
			if 'UNKNOWN' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_UNKNOWN_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
			elif 'LIVE' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
			else: cdNCx41S8a = True
			kvNQyGf6g7UZT2lrmHL3cb['LIVE_ORIGINAL_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
		elif 'VOD' in qiCPWMLTsNk9QyAObtDBH7m:
			if 'UNKNOWN' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_UNKNOWN_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
			elif 'MOVIES' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_MOVIES_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
			elif 'SERIES' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_SERIES_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
			else: cdNCx41S8a = True
			kvNQyGf6g7UZT2lrmHL3cb['VOD_ORIGINAL_GROUPED'].append(kTyJhvpuYgKEZzwGsS2a4)
		else: cdNCx41S8a = True
		if cdNCx41S8a: AMhE4K9Q2I7WN6.append(Q0IDpm9BgJG)
		AyCmXWaeTFD9O8GwucvM03qi1 += 1
	Acn7zxedEsC12Hm9vOUgQwTNV56l = sorted(utBebMzoFwEmOrD0GaKT,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT['title'].lower())
	del utBebMzoFwEmOrD0GaKT
	kkz5EOduci39 = str(X5XWZFgTmNGfxsOcrqKjLaQwE)
	AyCmXWaeTFD9O8GwucvM03qi1 = 0
	for Q0IDpm9BgJG in Acn7zxedEsC12Hm9vOUgQwTNV56l:
		AyCmXWaeTFD9O8GwucvM03qi1 += 1
		if AyCmXWaeTFD9O8GwucvM03qi1%873==0:
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,55+int(5*AyCmXWaeTFD9O8GwucvM03qi1/X5XWZFgTmNGfxsOcrqKjLaQwE),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(AyCmXWaeTFD9O8GwucvM03qi1)+' / '+kkz5EOduci39)
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return None,None
		qiCPWMLTsNk9QyAObtDBH7m = Q0IDpm9BgJG['type']
		yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 = Q0IDpm9BgJG['group'],Q0IDpm9BgJG['context'],Q0IDpm9BgJG['title'],Q0IDpm9BgJG['url'],Q0IDpm9BgJG['img']
		Ql5pX3S2Lu,TK9iFC0yPG = Q0IDpm9BgJG['country'],Q0IDpm9BgJG['language']
		nAiMyWwQ09m = (yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ+'_TIMESHIFT',qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2)
		kTyJhvpuYgKEZzwGsS2a4 = (yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2)
		UUz8HoqAPCgy19c = (Ql5pX3S2Lu,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2)
		VV6bRsfExWCXpFTN = (TK9iFC0yPG,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2)
		if 'LIVE' in qiCPWMLTsNk9QyAObtDBH7m:
			if 'UNKNOWN' in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_UNKNOWN_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			else: kvNQyGf6g7UZT2lrmHL3cb['LIVE_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			if 'EPG'		in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_EPG_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			if 'ARCHIVED'	in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_ARCHIVED_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			if 'ARCHIVED'	in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['LIVE_TIMESHIFT_GROUPED_SORTED'].append(nAiMyWwQ09m)
			kvNQyGf6g7UZT2lrmHL3cb['LIVE_FROM_NAME_SORTED'].append(UUz8HoqAPCgy19c)
			kvNQyGf6g7UZT2lrmHL3cb['LIVE_FROM_GROUP_SORTED'].append(VV6bRsfExWCXpFTN)
		elif 'VOD' in qiCPWMLTsNk9QyAObtDBH7m:
			if   'UNKNOWN'	in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_UNKNOWN_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			elif 'MOVIES'	in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_MOVIES_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			elif 'SERIES'	in qiCPWMLTsNk9QyAObtDBH7m: kvNQyGf6g7UZT2lrmHL3cb['VOD_SERIES_GROUPED_SORTED'].append(kTyJhvpuYgKEZzwGsS2a4)
			kvNQyGf6g7UZT2lrmHL3cb['VOD_FROM_NAME_SORTED'].append(UUz8HoqAPCgy19c)
			kvNQyGf6g7UZT2lrmHL3cb['VOD_FROM_GROUP_SORTED'].append(VV6bRsfExWCXpFTN)
	return kvNQyGf6g7UZT2lrmHL3cb,AMhE4K9Q2I7WN6
def dglAEmoWjGVNK(qXzxUjlRydGDhOQ9fM3a8tp4ZKe):
	if len(qXzxUjlRydGDhOQ9fM3a8tp4ZKe)<3: return qXzxUjlRydGDhOQ9fM3a8tp4ZKe,qXzxUjlRydGDhOQ9fM3a8tp4ZKe
	jp92E1Yfsk6vL7exTH5cmAM8RzVq,JBd07ks1EDri = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	q9i8HCZAdsacWw3z46 = qXzxUjlRydGDhOQ9fM3a8tp4ZKe
	O0nMhUspVkRDFSGbvH = qXzxUjlRydGDhOQ9fM3a8tp4ZKe[:1]
	dqLuCgHznE4wXUD0ax28Zmt = qXzxUjlRydGDhOQ9fM3a8tp4ZKe[1:]
	if   O0nMhUspVkRDFSGbvH=='(': JBd07ks1EDri = ')'
	elif O0nMhUspVkRDFSGbvH=='[': JBd07ks1EDri = ']'
	elif O0nMhUspVkRDFSGbvH=='<': JBd07ks1EDri = '>'
	elif O0nMhUspVkRDFSGbvH=='|': JBd07ks1EDri = '|'
	if JBd07ks1EDri and (JBd07ks1EDri in dqLuCgHznE4wXUD0ax28Zmt):
		jRmAuViy9CdPnONcWrJgL4M3Txt,Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9 = dqLuCgHznE4wXUD0ax28Zmt.split(JBd07ks1EDri,1)
		jp92E1Yfsk6vL7exTH5cmAM8RzVq = jRmAuViy9CdPnONcWrJgL4M3Txt
		q9i8HCZAdsacWw3z46 = O0nMhUspVkRDFSGbvH+jRmAuViy9CdPnONcWrJgL4M3Txt+JBd07ks1EDri+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9
	elif qXzxUjlRydGDhOQ9fM3a8tp4ZKe.count('|')>=2:
		jRmAuViy9CdPnONcWrJgL4M3Txt,Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9 = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.split('|',1)
		jp92E1Yfsk6vL7exTH5cmAM8RzVq = jRmAuViy9CdPnONcWrJgL4M3Txt
		q9i8HCZAdsacWw3z46 = jRmAuViy9CdPnONcWrJgL4M3Txt+' |'+Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9
	else:
		JBd07ks1EDri = RSuYINdeamsK0t.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',qXzxUjlRydGDhOQ9fM3a8tp4ZKe,RSuYINdeamsK0t.DOTALL)
		if not JBd07ks1EDri: JBd07ks1EDri = RSuYINdeamsK0t.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',qXzxUjlRydGDhOQ9fM3a8tp4ZKe,RSuYINdeamsK0t.DOTALL)
		if not JBd07ks1EDri: JBd07ks1EDri = RSuYINdeamsK0t.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',qXzxUjlRydGDhOQ9fM3a8tp4ZKe,RSuYINdeamsK0t.DOTALL)
		if JBd07ks1EDri:
			jRmAuViy9CdPnONcWrJgL4M3Txt,Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9 = qXzxUjlRydGDhOQ9fM3a8tp4ZKe.split(JBd07ks1EDri[0],1)
			jp92E1Yfsk6vL7exTH5cmAM8RzVq = jRmAuViy9CdPnONcWrJgL4M3Txt
			q9i8HCZAdsacWw3z46 = jRmAuViy9CdPnONcWrJgL4M3Txt+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+JBd07ks1EDri[0]+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Bf7JrOWl1qFV8Ebt4nmvTK5Dgi9
	q9i8HCZAdsacWw3z46 = q9i8HCZAdsacWw3z46.replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	jp92E1Yfsk6vL7exTH5cmAM8RzVq = jp92E1Yfsk6vL7exTH5cmAM8RzVq.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if not jp92E1Yfsk6vL7exTH5cmAM8RzVq: jp92E1Yfsk6vL7exTH5cmAM8RzVq = '!!__UNKNOWN__!!'
	jp92E1Yfsk6vL7exTH5cmAM8RzVq = jp92E1Yfsk6vL7exTH5cmAM8RzVq.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	q9i8HCZAdsacWw3z46 = q9i8HCZAdsacWw3z46.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	return jp92E1Yfsk6vL7exTH5cmAM8RzVq,q9i8HCZAdsacWw3z46
def a2LEDnNXSZTqVdoUM1GB5tvukHpQ(j6W37Jtc8ryXDT95Phx):
	KT67DQI1xk9XG34ezN0hH = {}
	tkB9WV43hJHYajEydLDzIi6 = cad8TeSyMUYmfsEO0.getSetting('av.iptv.useragent_'+j6W37Jtc8ryXDT95Phx)
	if tkB9WV43hJHYajEydLDzIi6: KT67DQI1xk9XG34ezN0hH['User-Agent'] = tkB9WV43hJHYajEydLDzIi6
	ywzJ068n3TOm7jrxRlEaPA = cad8TeSyMUYmfsEO0.getSetting('av.iptv.referer_'+j6W37Jtc8ryXDT95Phx)
	if ywzJ068n3TOm7jrxRlEaPA: KT67DQI1xk9XG34ezN0hH['Referer'] = ywzJ068n3TOm7jrxRlEaPA
	return KT67DQI1xk9XG34ezN0hH
def D08HRNYzBfCe2mPhnkGLpXaKVWi(j6W37Jtc8ryXDT95Phx):
	global fgiuLwj4vykqNxXKQVnh,kvNQyGf6g7UZT2lrmHL3cb,XXPe9O1yzufU,mmboPWl0OM5VEZCFiaU9S,NP86IfGJV0iXZFYKSkAsrH,rxvoadmqAXiW6SRE0zn7hVtuwyCkfF,W3LoZPBk1pzV8nUu6e,SIbFGm3ivL17B,O2VixSCBPFU
	SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k = OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx)
	if not RrJQvd9mBH46bclqoI0iCYK2Zj3: return
	KT67DQI1xk9XG34ezN0hH = a2LEDnNXSZTqVdoUM1GB5tvukHpQ(j6W37Jtc8ryXDT95Phx)
	wP56xXV9CSE8 = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if wP56xXV9CSE8!=1: return
	FhjDnISCYHVv7ymgQxpfREXat2J = K1zl4dy3IfeHs506mhJLX.replace('___','_'+j6W37Jtc8ryXDT95Phx)
	if 1:
		E7Oap3UPWiS1eom2yM84nlkJGzwgXT,sb2wFzSlq7J8mNyHrCDLTXnZGe6,JAqX9QVlhetaWpnL6RZM = qmHgOtCNX5YQd(j6W37Jtc8ryXDT95Phx,False)
		if not E7Oap3UPWiS1eom2yM84nlkJGzwgXT:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not Po42eiOLy73c: iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(ILyVox7aiXM148nz)+'   No IPTV URL found to download IPTV files')
			else: iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(ILyVox7aiXM148nz)+'   Failed to download IPTV files')
			return
		JH7k1smqPb9c8zDfIrvelS40My2VR = jRf87LJug6qp4ZzTyhm(Po42eiOLy73c,KT67DQI1xk9XG34ezN0hH,True)
		if not JH7k1smqPb9c8zDfIrvelS40My2VR: return
		open(FhjDnISCYHVv7ymgQxpfREXat2J,'wb').write(JH7k1smqPb9c8zDfIrvelS40My2VR)
	else: JH7k1smqPb9c8zDfIrvelS40My2VR = open(FhjDnISCYHVv7ymgQxpfREXat2J,'rb').read()
	if PvwFsJK23NbU8XWAx and JH7k1smqPb9c8zDfIrvelS40My2VR: JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.decode(AoCWwJHgUPKXI7u2lEzym)
	fgiuLwj4vykqNxXKQVnh = LfgAx0QSMK59hF()
	fgiuLwj4vykqNxXKQVnh.create('جلب ملفات ـIPTV جديدة',Vk54F7GcROfCy6HunEI)
	yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,15,'تنظيف الملف الرئيسي',Vk54F7GcROfCy6HunEI)
	JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('"tvg-','" tvg-')
	JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('َ',Vk54F7GcROfCy6HunEI).replace('ً',Vk54F7GcROfCy6HunEI).replace('ُ',Vk54F7GcROfCy6HunEI).replace('ٌ',Vk54F7GcROfCy6HunEI)
	JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('ّ',Vk54F7GcROfCy6HunEI).replace('ِ',Vk54F7GcROfCy6HunEI).replace('ٍ',Vk54F7GcROfCy6HunEI).replace('ْ',Vk54F7GcROfCy6HunEI)
	JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('group-title=','group=').replace('tvg-',Vk54F7GcROfCy6HunEI)
	NfZq8QdxRcXLTvjSPYHDk,ppBMuojq7ZEAtesD = [],[]
	yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if fgiuLwj4vykqNxXKQVnh.iscanceled():
		fgiuLwj4vykqNxXKQVnh.close()
		return
	lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_series_categories'
	aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',lI5ck2gjRCiw9bMTF0xHsG,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IPTV-CREATE_STREAMS-1st')
	ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
	ov9nVhCfMkz37xPgQOS = ww25jXuxtpK1TOJEbGUgrm8(ov9nVhCfMkz37xPgQOS)
	XXTyVuN9wxGQ1OvUh02kceRAjn = RSuYINdeamsK0t.findall('category_name":"(.*?)"',ov9nVhCfMkz37xPgQOS,RSuYINdeamsK0t.DOTALL)
	del ov9nVhCfMkz37xPgQOS
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in XXTyVuN9wxGQ1OvUh02kceRAjn:
		yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.replace('\/','/')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.decode(AoCWwJHgUPKXI7u2lEzym).encode(AoCWwJHgUPKXI7u2lEzym)
		JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('group="'+yIiE1cO8rWlRZPNLJ9jMb5tToex6w+'"','group="__SERIES__'+yIiE1cO8rWlRZPNLJ9jMb5tToex6w+'"')
	del XXTyVuN9wxGQ1OvUh02kceRAjn
	yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if fgiuLwj4vykqNxXKQVnh.iscanceled():
		fgiuLwj4vykqNxXKQVnh.close()
		return
	lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_vod_categories'
	aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',lI5ck2gjRCiw9bMTF0xHsG,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IPTV-CREATE_STREAMS-2nd')
	ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
	ov9nVhCfMkz37xPgQOS = ww25jXuxtpK1TOJEbGUgrm8(ov9nVhCfMkz37xPgQOS)
	L01OCrFI6zmqNM = RSuYINdeamsK0t.findall('category_name":"(.*?)"',ov9nVhCfMkz37xPgQOS,RSuYINdeamsK0t.DOTALL)
	del ov9nVhCfMkz37xPgQOS
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in L01OCrFI6zmqNM:
		yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.replace('\/','/')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: yIiE1cO8rWlRZPNLJ9jMb5tToex6w = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.decode(AoCWwJHgUPKXI7u2lEzym).encode(AoCWwJHgUPKXI7u2lEzym)
		JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace('group="'+yIiE1cO8rWlRZPNLJ9jMb5tToex6w+'"','group="__MOVIES__'+yIiE1cO8rWlRZPNLJ9jMb5tToex6w+'"')
	del L01OCrFI6zmqNM
	yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if fgiuLwj4vykqNxXKQVnh.iscanceled():
		fgiuLwj4vykqNxXKQVnh.close()
		return
	lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_live_streams'
	aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',lI5ck2gjRCiw9bMTF0xHsG,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IPTV-CREATE_STREAMS-3rd')
	ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
	ov9nVhCfMkz37xPgQOS = ww25jXuxtpK1TOJEbGUgrm8(ov9nVhCfMkz37xPgQOS)
	CDjamrOK2ob = RSuYINdeamsK0t.findall('"name":"(.*?)".*?"tv_archive":(.*?),',ov9nVhCfMkz37xPgQOS,RSuYINdeamsK0t.DOTALL)
	for EDy0Rs9liwjZvJY,p57p4dY03gUAJtPhrSo in CDjamrOK2ob:
		if p57p4dY03gUAJtPhrSo=='1': NfZq8QdxRcXLTvjSPYHDk.append(EDy0Rs9liwjZvJY)
	del CDjamrOK2ob
	R1MDHi28xq0nYc3J7wF = RSuYINdeamsK0t.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',ov9nVhCfMkz37xPgQOS,RSuYINdeamsK0t.DOTALL)
	del ov9nVhCfMkz37xPgQOS
	for EDy0Rs9liwjZvJY,ggHOuyAP7IKQj09TcswJzMox1iESnv in R1MDHi28xq0nYc3J7wF:
		if ggHOuyAP7IKQj09TcswJzMox1iESnv!='null': ppBMuojq7ZEAtesD.append(EDy0Rs9liwjZvJY)
	del R1MDHi28xq0nYc3J7wF
	JH7k1smqPb9c8zDfIrvelS40My2VR = JH7k1smqPb9c8zDfIrvelS40My2VR.replace(gSiK7EQVNXClOUDZGs,ixrPWKeFMnqJyVodX6D9AaO2)
	p74HvfYKXiexEOAPR9BUNkq0u = RSuYINdeamsK0t.findall('NF:(.+?)'+'#'+'EXTI',JH7k1smqPb9c8zDfIrvelS40My2VR+'\n+'+'#'+'EXTINF:',RSuYINdeamsK0t.DOTALL)
	if not p74HvfYKXiexEOAPR9BUNkq0u:
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(ILyVox7aiXM148nz)+'   Folder:'+j6W37Jtc8ryXDT95Phx+'   No video links found in IPTV file')
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+'مجلد رقم '+j6W37Jtc8ryXDT95Phx)
		fgiuLwj4vykqNxXKQVnh.close()
		return
	tUqYwFH9iMSBlKu2hrsN8GfgdA3jEQ = []
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		iUBmuWkqIo3Yg0A5vjZPn6OaV2bRd = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.lower()
		if 'adult' in iUBmuWkqIo3Yg0A5vjZPn6OaV2bRd: continue
		if 'xxx' in iUBmuWkqIo3Yg0A5vjZPn6OaV2bRd: continue
		tUqYwFH9iMSBlKu2hrsN8GfgdA3jEQ.append(uDJxNtKl2gLkR6zC7OZWEf1cjvF059)
	p74HvfYKXiexEOAPR9BUNkq0u = tUqYwFH9iMSBlKu2hrsN8GfgdA3jEQ
	del tUqYwFH9iMSBlKu2hrsN8GfgdA3jEQ
	ddcXY97j2xJTI = 1024*1024
	K3705qIw9EutnMbWgdNGHc8xl = 1+len(JH7k1smqPb9c8zDfIrvelS40My2VR)//ddcXY97j2xJTI//10
	del JH7k1smqPb9c8zDfIrvelS40My2VR
	Qh4Gf7HdkxOsEVT5jnYguLJ = len(p74HvfYKXiexEOAPR9BUNkq0u)
	SSzLojufKQJkqAp = Gtl57mNQ9UOCBf2SyYv(p74HvfYKXiexEOAPR9BUNkq0u,K3705qIw9EutnMbWgdNGHc8xl)
	del p74HvfYKXiexEOAPR9BUNkq0u
	for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(K3705qIw9EutnMbWgdNGHc8xl):
		yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,35+int(5*qf4yXuWZFYbxTEdkcQBUsAIgKH/K3705qIw9EutnMbWgdNGHc8xl),'تقطيع الملف الرئيسي','الجزء رقم:-',str(qf4yXuWZFYbxTEdkcQBUsAIgKH+1)+' / '+str(K3705qIw9EutnMbWgdNGHc8xl))
		if fgiuLwj4vykqNxXKQVnh.iscanceled():
			fgiuLwj4vykqNxXKQVnh.close()
			return
		Xy5BQEtIlGr94sKNab7TSCVx0PDU = str(SSzLojufKQJkqAp[qf4yXuWZFYbxTEdkcQBUsAIgKH])
		if PvwFsJK23NbU8XWAx: Xy5BQEtIlGr94sKNab7TSCVx0PDU = Xy5BQEtIlGr94sKNab7TSCVx0PDU.encode(AoCWwJHgUPKXI7u2lEzym)
		open(FhjDnISCYHVv7ymgQxpfREXat2J+'.00'+str(qf4yXuWZFYbxTEdkcQBUsAIgKH),'wb').write(Xy5BQEtIlGr94sKNab7TSCVx0PDU)
	del SSzLojufKQJkqAp,Xy5BQEtIlGr94sKNab7TSCVx0PDU
	NfdoCkxLREimcPtO,utBebMzoFwEmOrD0GaKT,AyCmXWaeTFD9O8GwucvM03qi1 = [],[],0
	for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(K3705qIw9EutnMbWgdNGHc8xl):
		if fgiuLwj4vykqNxXKQVnh.iscanceled():
			fgiuLwj4vykqNxXKQVnh.close()
			return
		Xy5BQEtIlGr94sKNab7TSCVx0PDU = open(FhjDnISCYHVv7ymgQxpfREXat2J+'.00'+str(qf4yXuWZFYbxTEdkcQBUsAIgKH),'rb').read()
		Gb6kwVlSQ4MU.sleep(1)
		try: CR3aLOVKSIme5XFoYi6M.remove(FhjDnISCYHVv7ymgQxpfREXat2J+'.00'+str(qf4yXuWZFYbxTEdkcQBUsAIgKH))
		except: pass
		if PvwFsJK23NbU8XWAx: Xy5BQEtIlGr94sKNab7TSCVx0PDU = Xy5BQEtIlGr94sKNab7TSCVx0PDU.decode(AoCWwJHgUPKXI7u2lEzym)
		rSYkN95QMKmctfa4ViwjPgDZO8HGE7 = Bw6jaUcFxlqdDT8bC('list',Xy5BQEtIlGr94sKNab7TSCVx0PDU)
		del Xy5BQEtIlGr94sKNab7TSCVx0PDU
		QoNlOVqsvGLC,AyCmXWaeTFD9O8GwucvM03qi1,AMhE4K9Q2I7WN6 = oohidwAg2ypVztckI(rSYkN95QMKmctfa4ViwjPgDZO8HGE7,ppBMuojq7ZEAtesD,NfZq8QdxRcXLTvjSPYHDk,fgiuLwj4vykqNxXKQVnh,Qh4Gf7HdkxOsEVT5jnYguLJ,AyCmXWaeTFD9O8GwucvM03qi1,Po42eiOLy73c)
		if fgiuLwj4vykqNxXKQVnh.iscanceled():
			fgiuLwj4vykqNxXKQVnh.close()
			return
		if not QoNlOVqsvGLC:
			fgiuLwj4vykqNxXKQVnh.close()
			return
		utBebMzoFwEmOrD0GaKT += QoNlOVqsvGLC
		NfdoCkxLREimcPtO += AMhE4K9Q2I7WN6
	del rSYkN95QMKmctfa4ViwjPgDZO8HGE7,QoNlOVqsvGLC
	kvNQyGf6g7UZT2lrmHL3cb,AMhE4K9Q2I7WN6 = jjrBzpf74NnVMgGWkT3H5bJImlR1t(utBebMzoFwEmOrD0GaKT,fgiuLwj4vykqNxXKQVnh)
	if fgiuLwj4vykqNxXKQVnh.iscanceled():
		fgiuLwj4vykqNxXKQVnh.close()
		return
	NfdoCkxLREimcPtO += AMhE4K9Q2I7WN6
	del utBebMzoFwEmOrD0GaKT,AMhE4K9Q2I7WN6
	mmboPWl0OM5VEZCFiaU9S,NP86IfGJV0iXZFYKSkAsrH,rxvoadmqAXiW6SRE0zn7hVtuwyCkfF,W3LoZPBk1pzV8nUu6e,SIbFGm3ivL17B = {},{},{},0,0
	SFGs0vQT45YyC2XtkqUaZr = list(kvNQyGf6g7UZT2lrmHL3cb.keys())
	O2VixSCBPFU = len(SFGs0vQT45YyC2XtkqUaZr)*3
	if 1:
		Mo9lQ7Iux1bKmPtFa8W = {}
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs] = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=qkC0hvYDgc6BVozTOjE1,args=(ttCN9cTKWFIlmMDVpzs,))
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs].start()
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs].join()
		if fgiuLwj4vykqNxXKQVnh.iscanceled():
			fgiuLwj4vykqNxXKQVnh.close()
			return
	else:
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			qkC0hvYDgc6BVozTOjE1(ttCN9cTKWFIlmMDVpzs)
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return
	mIlV9YhHrkCGeMytbO8TBEA(j6W37Jtc8ryXDT95Phx,False)
	SFGs0vQT45YyC2XtkqUaZr = list(mmboPWl0OM5VEZCFiaU9S.keys())
	XXPe9O1yzufU = 0
	if 1:
		Mo9lQ7Iux1bKmPtFa8W = {}
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs] = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=kFXLUqijC3yxd2r,args=(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs))
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs].start()
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			Mo9lQ7Iux1bKmPtFa8W[ttCN9cTKWFIlmMDVpzs].join()
		if fgiuLwj4vykqNxXKQVnh.iscanceled():
			fgiuLwj4vykqNxXKQVnh.close()
			return
	else:
		for ttCN9cTKWFIlmMDVpzs in SFGs0vQT45YyC2XtkqUaZr:
			kFXLUqijC3yxd2r(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs)
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return
	qf4yXuWZFYbxTEdkcQBUsAIgKH = 0
	M2wEbtmSRfa8JqojkWXsrAP = len(NfdoCkxLREimcPtO)
	alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,'IGNORED')
	for TGQCNgYzpOPZmKlVicwyRt2rIo9u in NfdoCkxLREimcPtO:
		if qf4yXuWZFYbxTEdkcQBUsAIgKH%27==0:
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,95+int(5*qf4yXuWZFYbxTEdkcQBUsAIgKH//M2wEbtmSRfa8JqojkWXsrAP),'تخزين المهملة','الفيديو رقم:-',str(qf4yXuWZFYbxTEdkcQBUsAIgKH)+' / '+str(M2wEbtmSRfa8JqojkWXsrAP))
			if fgiuLwj4vykqNxXKQVnh.iscanceled():
				fgiuLwj4vykqNxXKQVnh.close()
				return
		FgY4iT81AjHC6239Q(alTgYKybwfIhi,'IGNORED',str(TGQCNgYzpOPZmKlVicwyRt2rIo9u),Vk54F7GcROfCy6HunEI,piwNWcJEe9m)
		qf4yXuWZFYbxTEdkcQBUsAIgKH += 1
	FgY4iT81AjHC6239Q(alTgYKybwfIhi,'IGNORED','__COUNT__',str(M2wEbtmSRfa8JqojkWXsrAP),piwNWcJEe9m)
	FgY4iT81AjHC6239Q(alTgYKybwfIhi,'DUMMY','__DUMMY__','1',piwNWcJEe9m)
	fgiuLwj4vykqNxXKQVnh.close()
	Gb6kwVlSQ4MU.sleep(1)
	i96zBLQpSRWK = bb5Hn2mBvFZrlUywkOapK06hc(j6W37Jtc8ryXDT95Phx,False)
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج',d761ZWXHEvliYN45RzLP2+'تم جلب ملفات ـIPTV جديدة'+ZZoLlKyInXc08j2pTGJ+'\n\n'+i96zBLQpSRWK)
	BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx)
	Rl9iZEjgtdhHAocuU1fk7wLPB6r(False)
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(False)
	return
def qkC0hvYDgc6BVozTOjE1(ttCN9cTKWFIlmMDVpzs):
	global fgiuLwj4vykqNxXKQVnh,kvNQyGf6g7UZT2lrmHL3cb,XXPe9O1yzufU,mmboPWl0OM5VEZCFiaU9S,NP86IfGJV0iXZFYKSkAsrH,rxvoadmqAXiW6SRE0zn7hVtuwyCkfF,W3LoZPBk1pzV8nUu6e,SIbFGm3ivL17B,O2VixSCBPFU
	mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs] = {}
	bXJFhm4VnOYaI0PEtoy,Vc9JFfBXzyaWSpZu5Q = {},[]
	AnDOTXdKq2Q1 = len(kvNQyGf6g7UZT2lrmHL3cb[ttCN9cTKWFIlmMDVpzs])
	mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs]['__COUNT__'] = AnDOTXdKq2Q1
	if AnDOTXdKq2Q1>0:
		ENbq6BwF9Py4pAi,XnsGyMhVpuItiSeQcZj1mHL,oo7ULZbv9K5sJyPT64tdfDqpF,brJptqW83ojf2G1McUdPQuZAVYOKS,w8ycTYK3h9velS = zip(*kvNQyGf6g7UZT2lrmHL3cb[ttCN9cTKWFIlmMDVpzs])
		del XnsGyMhVpuItiSeQcZj1mHL,oo7ULZbv9K5sJyPT64tdfDqpF,brJptqW83ojf2G1McUdPQuZAVYOKS
		NBsx3ZUkioRQGg1v6jD7F5SuWMV = list(set(ENbq6BwF9Py4pAi))
		for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in NBsx3ZUkioRQGg1v6jD7F5SuWMV:
			bXJFhm4VnOYaI0PEtoy[yIiE1cO8rWlRZPNLJ9jMb5tToex6w] = Vk54F7GcROfCy6HunEI
			mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs][yIiE1cO8rWlRZPNLJ9jMb5tToex6w] = []
		yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,60+int(15*SIbFGm3ivL17B//O2VixSCBPFU),'تصنيع القوائم','الجزء رقم:-',str(SIbFGm3ivL17B)+' / '+str(O2VixSCBPFU))
		if fgiuLwj4vykqNxXKQVnh.iscanceled(): return
		SIbFGm3ivL17B += 1
		iSRW7QPIhxamsAB2cjq1FJOZeHXo = len(NBsx3ZUkioRQGg1v6jD7F5SuWMV)
		del NBsx3ZUkioRQGg1v6jD7F5SuWMV
		Vc9JFfBXzyaWSpZu5Q = list(set(zip(ENbq6BwF9Py4pAi,w8ycTYK3h9velS)))
		del ENbq6BwF9Py4pAi,w8ycTYK3h9velS
		for yIiE1cO8rWlRZPNLJ9jMb5tToex6w,c7E603KRhbToig9V4yx in Vc9JFfBXzyaWSpZu5Q:
			if not bXJFhm4VnOYaI0PEtoy[yIiE1cO8rWlRZPNLJ9jMb5tToex6w] and c7E603KRhbToig9V4yx: bXJFhm4VnOYaI0PEtoy[yIiE1cO8rWlRZPNLJ9jMb5tToex6w] = c7E603KRhbToig9V4yx
		yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,60+int(15*SIbFGm3ivL17B//O2VixSCBPFU),'تصنيع القوائم','الجزء رقم:-',str(SIbFGm3ivL17B)+' / '+str(O2VixSCBPFU))
		if fgiuLwj4vykqNxXKQVnh.iscanceled(): return
		SIbFGm3ivL17B += 1
		nBRLaCWpEztHNvlqiy = list(bXJFhm4VnOYaI0PEtoy.keys())
		UlYiTG08qgQL6vEwuy9kaK4zn = list(bXJFhm4VnOYaI0PEtoy.values())
		del bXJFhm4VnOYaI0PEtoy
		Vc9JFfBXzyaWSpZu5Q = list(zip(nBRLaCWpEztHNvlqiy,UlYiTG08qgQL6vEwuy9kaK4zn))
		del nBRLaCWpEztHNvlqiy,UlYiTG08qgQL6vEwuy9kaK4zn
		Vc9JFfBXzyaWSpZu5Q = sorted(Vc9JFfBXzyaWSpZu5Q)
	else: SIbFGm3ivL17B += 2
	mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs]['__GROUPS__'] = Vc9JFfBXzyaWSpZu5Q
	del Vc9JFfBXzyaWSpZu5Q
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w,m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 in kvNQyGf6g7UZT2lrmHL3cb[ttCN9cTKWFIlmMDVpzs]:
		mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs][yIiE1cO8rWlRZPNLJ9jMb5tToex6w].append((m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2))
	yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,60+int(15*SIbFGm3ivL17B//O2VixSCBPFU),'تصنيع القوائم','الجزء رقم:-',str(SIbFGm3ivL17B)+' / '+str(O2VixSCBPFU))
	if fgiuLwj4vykqNxXKQVnh.iscanceled(): return
	SIbFGm3ivL17B += 1
	del kvNQyGf6g7UZT2lrmHL3cb[ttCN9cTKWFIlmMDVpzs]
	rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[ttCN9cTKWFIlmMDVpzs] = list(mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs].keys())
	NP86IfGJV0iXZFYKSkAsrH[ttCN9cTKWFIlmMDVpzs] = len(rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[ttCN9cTKWFIlmMDVpzs])
	W3LoZPBk1pzV8nUu6e += NP86IfGJV0iXZFYKSkAsrH[ttCN9cTKWFIlmMDVpzs]
	return
def kFXLUqijC3yxd2r(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs):
	global fgiuLwj4vykqNxXKQVnh,kvNQyGf6g7UZT2lrmHL3cb,XXPe9O1yzufU,mmboPWl0OM5VEZCFiaU9S,NP86IfGJV0iXZFYKSkAsrH,rxvoadmqAXiW6SRE0zn7hVtuwyCkfF,W3LoZPBk1pzV8nUu6e,SIbFGm3ivL17B,O2VixSCBPFU
	alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs)
	for AyCmXWaeTFD9O8GwucvM03qi1 in range(1+NP86IfGJV0iXZFYKSkAsrH[ttCN9cTKWFIlmMDVpzs]//273):
		u8NcjRF9P2IX = []
		BBgwARosGPM7ZFz3qlr6 = rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[ttCN9cTKWFIlmMDVpzs][0:273]
		for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in BBgwARosGPM7ZFz3qlr6:
			u8NcjRF9P2IX.append(mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs][yIiE1cO8rWlRZPNLJ9jMb5tToex6w])
		FgY4iT81AjHC6239Q(alTgYKybwfIhi,ttCN9cTKWFIlmMDVpzs,BBgwARosGPM7ZFz3qlr6,u8NcjRF9P2IX,piwNWcJEe9m,True)
		XXPe9O1yzufU += len(BBgwARosGPM7ZFz3qlr6)
		yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(fgiuLwj4vykqNxXKQVnh,75+int(20*XXPe9O1yzufU//W3LoZPBk1pzV8nUu6e),'تخزين القوائم','القائمة رقم:-',str(XXPe9O1yzufU)+' / '+str(W3LoZPBk1pzV8nUu6e))
		if fgiuLwj4vykqNxXKQVnh.iscanceled(): return
		del rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[ttCN9cTKWFIlmMDVpzs][0:273]
	del mmboPWl0OM5VEZCFiaU9S[ttCN9cTKWFIlmMDVpzs],rxvoadmqAXiW6SRE0zn7hVtuwyCkfF[ttCN9cTKWFIlmMDVpzs],NP86IfGJV0iXZFYKSkAsrH[ttCN9cTKWFIlmMDVpzs]
	return
def bb5Hn2mBvFZrlUywkOapK06hc(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad=True):
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad): return
	DGnauLYqJV1Xd4yNHhkcm2CwB = 'رسالة من المبرمج'
	NP39ptrcJlida5fIxSBFHmK = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,'LIVE_ORIGINAL_GROUPED')
	Hfl4aRuGVby9IhLqr6k5nmtvs0 = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,'VOD_ORIGINAL_GROUPED')
	M2wEbtmSRfa8JqojkWXsrAP = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','IGNORED','__COUNT__')
	x1gwjkNmdWAT29M06yzOqeBfl = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	kk9ecGrzVx8TMwEijAhPtYp3g0Ks = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(Hfl4aRuGVby9IhLqr6k5nmtvs0,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	u8yNqY7CPGJlFdIfHsxwW59iZ1 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','LIVE_GROUPED','__COUNT__')
	G95f8EspFuMZH6y = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	NfozV8c4d6kluUp = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','VOD_MOVIES_GROUPED','__COUNT__')
	VL4MAHbsxBdR = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(Hfl4aRuGVby9IhLqr6k5nmtvs0,'int','VOD_SERIES_GROUPED','__COUNT__')
	y0yDnZX24OQhSxrWtAgIl3Y = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(NP39ptrcJlida5fIxSBFHmK,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	rxvoadmqAXiW6SRE0zn7hVtuwyCkfF = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(Hfl4aRuGVby9IhLqr6k5nmtvs0,'list','VOD_SERIES_GROUPED','__GROUPS__')
	G1O4t8DjRMakP = []
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Nx0lZXuS65tYU9QJpCTqw4cR2 in rxvoadmqAXiW6SRE0zn7hVtuwyCkfF:
		rHZu9DMI2xUvhljoLtC = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.split('__SERIES__')[1]
		G1O4t8DjRMakP.append(rHZu9DMI2xUvhljoLtC)
	yTodpl9CL1HAI2iDhfbe = len(G1O4t8DjRMakP)
	tRO48VjuUF = int(NfozV8c4d6kluUp)+int(VL4MAHbsxBdR)+int(y0yDnZX24OQhSxrWtAgIl3Y)+int(G95f8EspFuMZH6y)+int(u8yNqY7CPGJlFdIfHsxwW59iZ1)
	i96zBLQpSRWK = Vk54F7GcROfCy6HunEI
	i96zBLQpSRWK += 'قنوات: '+str(u8yNqY7CPGJlFdIfHsxwW59iZ1)
	i96zBLQpSRWK += '   .   أفلام: '+str(NfozV8c4d6kluUp)
	i96zBLQpSRWK += '\nمسلسلات: '+str(yTodpl9CL1HAI2iDhfbe)
	i96zBLQpSRWK += '   .   حلقات: '+str(VL4MAHbsxBdR)
	i96zBLQpSRWK += '\nقنوات مجهولة: '+str(G95f8EspFuMZH6y)
	i96zBLQpSRWK += '   .   فيدوهات مجهولة: '+str(y0yDnZX24OQhSxrWtAgIl3Y)
	i96zBLQpSRWK += '\nمجموع القنوات: '+str(x1gwjkNmdWAT29M06yzOqeBfl)
	i96zBLQpSRWK += '   .   مجموع الفيديوهات: '+str(kk9ecGrzVx8TMwEijAhPtYp3g0Ks)
	i96zBLQpSRWK += '\n\nمجموع المضافة: '+str(tRO48VjuUF)
	i96zBLQpSRWK += '   .   مجموع المهملة: '+str(M2wEbtmSRfa8JqojkWXsrAP)
	if zM4WqLKfU03HChTsad: GHdYDixegkm9PJMN('center',Vk54F7GcROfCy6HunEI,DGnauLYqJV1Xd4yNHhkcm2CwB,i96zBLQpSRWK)
	uAPWFHq81Ne6vslGdIwTVBKzarO4 = i96zBLQpSRWK.replace('\n\n',ixrPWKeFMnqJyVodX6D9AaO2)
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,'.\tCounts of IPTV videos   Folder: '+j6W37Jtc8ryXDT95Phx+ixrPWKeFMnqJyVodX6D9AaO2+uAPWFHq81Ne6vslGdIwTVBKzarO4)
	return i96zBLQpSRWK
def mIlV9YhHrkCGeMytbO8TBEA(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad=True):
	if zM4WqLKfU03HChTsad:
		wP56xXV9CSE8 = WfM3l9n0GTFrVaeUxcsktQyJvYIC8('center',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if wP56xXV9CSE8!=1: return
		ShW5HPetFK67wU = K1zl4dy3IfeHs506mhJLX.replace('___','_'+j6W37Jtc8ryXDT95Phx)
		try: CR3aLOVKSIme5XFoYi6M.remove(ShW5HPetFK67wU)
		except: pass
	ShW5HPetFK67wU = yH76LQ2Yigdkfp.replace('___','_'+j6W37Jtc8ryXDT95Phx)
	try: CR3aLOVKSIme5XFoYi6M.remove(ShW5HPetFK67wU)
	except: pass
	ShW5HPetFK67wU = TI7QuAnOoX2.replace('___','_'+j6W37Jtc8ryXDT95Phx)
	try: CR3aLOVKSIme5XFoYi6M.remove(ShW5HPetFK67wU)
	except: pass
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'SECTIONS_IPTV','SECTIONS_IPTV_'+j6W37Jtc8ryXDT95Phx)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	Rl9iZEjgtdhHAocuU1fk7wLPB6r(False)
	BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx)
	if zM4WqLKfU03HChTsad:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(False)
	return
def LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx=Vk54F7GcROfCy6HunEI,zM4WqLKfU03HChTsad=True):
	if j6W37Jtc8ryXDT95Phx:
		alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(str(j6W37Jtc8ryXDT95Phx),'DUMMY')
		avxZKMEsw9BTjVDuikc = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'str','DUMMY','__DUMMY__')
		if avxZKMEsw9BTjVDuikc: return True
	else:
		j6W37Jtc8ryXDT95Phx = '1'
		for CU0GKZWMYgiFlV6Q1oH8wquc in range(1,YWQb3r2CoU+1):
			alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(str(CU0GKZWMYgiFlV6Q1oH8wquc),'DUMMY')
			avxZKMEsw9BTjVDuikc = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'str','DUMMY','__DUMMY__')
			if avxZKMEsw9BTjVDuikc: return True
	if zM4WqLKfU03HChTsad:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+nMt0iueCy6K+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+ZZoLlKyInXc08j2pTGJ)
		DGnauLYqJV1Xd4yNHhkcm2CwB = 'إضافة وتغيير رابط '+DVO3m2tJ4Hdh[1]+' (مجلد '+DVO3m2tJ4Hdh[int(j6W37Jtc8ryXDT95Phx)]+')'
		wP56xXV9CSE8 = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,DGnauLYqJV1Xd4yNHhkcm2CwB,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if wP56xXV9CSE8==1: muVeMOGUgnkyd9wsNA4(j6W37Jtc8ryXDT95Phx)
	return False
def FXrJ2CcKxVys6aM(h5Lq7Idk6TcWzKHpAVo8MnNgF2Uut,j6W37Jtc8ryXDT95Phx=Vk54F7GcROfCy6HunEI,ttCN9cTKWFIlmMDVpzs=Vk54F7GcROfCy6HunEI,jRD6Yh2SiNut=Vk54F7GcROfCy6HunEI):
	if not jRD6Yh2SiNut: jRD6Yh2SiNut = '1'
	rXEdWpTOxkiLqY8vfjUBn,tFleBaQ2fUrNiPdu3k8cpjWCxS7,zM4WqLKfU03HChTsad = HD6MGAiC4TrtXdc9ge7I(h5Lq7Idk6TcWzKHpAVo8MnNgF2Uut)
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad): return
	if not rXEdWpTOxkiLqY8vfjUBn:
		rXEdWpTOxkiLqY8vfjUBn = p3bB2auMmSjXC0dE8FUfZ()
		if not rXEdWpTOxkiLqY8vfjUBn: return
	PiQjSZ13IHEW = [Vk54F7GcROfCy6HunEI,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ttCN9cTKWFIlmMDVpzs:
		if not zM4WqLKfU03HChTsad:
			if   '_IPTV-LIVE_' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[1]
			elif '_IPTV-MOVIES' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[2]
			elif '_IPTV-SERIES' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[3]
			else: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[0]
		else:
			WkJEXDeIGSibvOsyUwB = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			OFEaiVuGrdSf20oxQl57Wp9A = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('أختر البحث المناسب', WkJEXDeIGSibvOsyUwB)
			if OFEaiVuGrdSf20oxQl57Wp9A==-1: return
			ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[OFEaiVuGrdSf20oxQl57Wp9A]
	rXEdWpTOxkiLqY8vfjUBn = rXEdWpTOxkiLqY8vfjUBn+'_NODIALOGS_'
	if j6W37Jtc8ryXDT95Phx: PxUzbQsISy7wg1cGd4l5Ma9YqHhi(rXEdWpTOxkiLqY8vfjUBn,j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs,jRD6Yh2SiNut)
	else:
		for j6W37Jtc8ryXDT95Phx in range(1,YWQb3r2CoU+1):
			PxUzbQsISy7wg1cGd4l5Ma9YqHhi(rXEdWpTOxkiLqY8vfjUBn,str(j6W37Jtc8ryXDT95Phx),ttCN9cTKWFIlmMDVpzs,jRD6Yh2SiNut)
		h9zFQKnsNL.menuItemsLIST[:] = sorted(h9zFQKnsNL.menuItemsLIST,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT[1].lower())
	return
def PxUzbQsISy7wg1cGd4l5Ma9YqHhi(h5Lq7Idk6TcWzKHpAVo8MnNgF2Uut,j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs=Vk54F7GcROfCy6HunEI,jRD6Yh2SiNut=Vk54F7GcROfCy6HunEI):
	if not jRD6Yh2SiNut: jRD6Yh2SiNut = '1'
	rXEdWpTOxkiLqY8vfjUBn,tFleBaQ2fUrNiPdu3k8cpjWCxS7,zM4WqLKfU03HChTsad = HD6MGAiC4TrtXdc9ge7I(h5Lq7Idk6TcWzKHpAVo8MnNgF2Uut)
	if not j6W37Jtc8ryXDT95Phx: return
	if not LBGi7uYZ6XTo5ct3f2FH8j(j6W37Jtc8ryXDT95Phx,zM4WqLKfU03HChTsad): return
	if not rXEdWpTOxkiLqY8vfjUBn:
		rXEdWpTOxkiLqY8vfjUBn = p3bB2auMmSjXC0dE8FUfZ()
		if not rXEdWpTOxkiLqY8vfjUBn: return
	PiQjSZ13IHEW = [Vk54F7GcROfCy6HunEI,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ttCN9cTKWFIlmMDVpzs:
		if not zM4WqLKfU03HChTsad:
			if   '_IPTV-LIVE_' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[1]
			elif '_IPTV-MOVIES' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[2]
			elif '_IPTV-SERIES' in tFleBaQ2fUrNiPdu3k8cpjWCxS7: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[3]
			else: ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[0]
		else:
			WkJEXDeIGSibvOsyUwB = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			OFEaiVuGrdSf20oxQl57Wp9A = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('أختر البحث المناسب', WkJEXDeIGSibvOsyUwB)
			if OFEaiVuGrdSf20oxQl57Wp9A==-1: return
			ttCN9cTKWFIlmMDVpzs = PiQjSZ13IHEW[OFEaiVuGrdSf20oxQl57Wp9A]
	GOq3Y5wIArcuWhQ = rXEdWpTOxkiLqY8vfjUBn.lower()
	alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,'SEARCH')
	P8JgauLzVmeTiRMy39nADHj = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list','SEARCH',(ttCN9cTKWFIlmMDVpzs,GOq3Y5wIArcuWhQ))
	if not P8JgauLzVmeTiRMy39nADHj:
		X1LP5GEbt2vF3VyH,Da70JT6Ify = [],[]
		if not ttCN9cTKWFIlmMDVpzs: sBTrLufa94UxcFywhDGPKdA5ZHi7m3 = [1,2,3,4,5]
		else: sBTrLufa94UxcFywhDGPKdA5ZHi7m3 = [PiQjSZ13IHEW.index(ttCN9cTKWFIlmMDVpzs)]
		for qf4yXuWZFYbxTEdkcQBUsAIgKH in sBTrLufa94UxcFywhDGPKdA5ZHi7m3:
			alTgYKybwfIhi = zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,PiQjSZ13IHEW[qf4yXuWZFYbxTEdkcQBUsAIgKH])
			if qf4yXuWZFYbxTEdkcQBUsAIgKH!=3:
				QoNlOVqsvGLC = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'dict',PiQjSZ13IHEW[qf4yXuWZFYbxTEdkcQBUsAIgKH])
				del QoNlOVqsvGLC['__COUNT__']
				del QoNlOVqsvGLC['__GROUPS__']
				del QoNlOVqsvGLC['__SEQUENCED_COLUMNS__']
				rxvoadmqAXiW6SRE0zn7hVtuwyCkfF = list(QoNlOVqsvGLC.keys())
				for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in rxvoadmqAXiW6SRE0zn7hVtuwyCkfF:
					for m6cEejX1UO0HwpuvqL7xGA2VWJ,qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 in QoNlOVqsvGLC[yIiE1cO8rWlRZPNLJ9jMb5tToex6w]:
						if GOq3Y5wIArcuWhQ in qXzxUjlRydGDhOQ9fM3a8tp4ZKe.lower(): Da70JT6Ify.append((qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2))
					del QoNlOVqsvGLC[yIiE1cO8rWlRZPNLJ9jMb5tToex6w]
				del QoNlOVqsvGLC
			else: rxvoadmqAXiW6SRE0zn7hVtuwyCkfF = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(alTgYKybwfIhi,'list',PiQjSZ13IHEW[qf4yXuWZFYbxTEdkcQBUsAIgKH],'__GROUPS__')
			for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in rxvoadmqAXiW6SRE0zn7hVtuwyCkfF:
				try: yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Nx0lZXuS65tYU9QJpCTqw4cR2 = yIiE1cO8rWlRZPNLJ9jMb5tToex6w
				except: Nx0lZXuS65tYU9QJpCTqw4cR2 = Vk54F7GcROfCy6HunEI
				if GOq3Y5wIArcuWhQ in yIiE1cO8rWlRZPNLJ9jMb5tToex6w.lower():
					if qf4yXuWZFYbxTEdkcQBUsAIgKH!=3: DDvlyxZImoaL = yIiE1cO8rWlRZPNLJ9jMb5tToex6w
					else:
						pl0wQaXx4rDncWejVGNFSiY6zfb,FLAtsE10HMuhV5Kg9R76abvGydUpx = yIiE1cO8rWlRZPNLJ9jMb5tToex6w.split('__SERIES__')
						if GOq3Y5wIArcuWhQ in pl0wQaXx4rDncWejVGNFSiY6zfb.lower(): DDvlyxZImoaL = pl0wQaXx4rDncWejVGNFSiY6zfb
						else: DDvlyxZImoaL = FLAtsE10HMuhV5Kg9R76abvGydUpx
					X1LP5GEbt2vF3VyH.append((yIiE1cO8rWlRZPNLJ9jMb5tToex6w,DDvlyxZImoaL,PiQjSZ13IHEW[qf4yXuWZFYbxTEdkcQBUsAIgKH],Nx0lZXuS65tYU9QJpCTqw4cR2))
			del rxvoadmqAXiW6SRE0zn7hVtuwyCkfF
		X1LP5GEbt2vF3VyH = set(X1LP5GEbt2vF3VyH)
		Da70JT6Ify = set(Da70JT6Ify)
		X1LP5GEbt2vF3VyH = sorted(X1LP5GEbt2vF3VyH,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT[1])
		Da70JT6Ify = sorted(Da70JT6Ify,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT[0])
		FgY4iT81AjHC6239Q(alTgYKybwfIhi,'SEARCH',(ttCN9cTKWFIlmMDVpzs,GOq3Y5wIArcuWhQ),(X1LP5GEbt2vF3VyH,Da70JT6Ify),piwNWcJEe9m)
	else: X1LP5GEbt2vF3VyH,Da70JT6Ify = P8JgauLzVmeTiRMy39nADHj
	rxvoadmqAXiW6SRE0zn7hVtuwyCkfF = len(X1LP5GEbt2vF3VyH)
	Tduyhw9mH1SW = len(Da70JT6Ify)
	NBnKOkHsvLd = int(jRD6Yh2SiNut)
	jjPWCL1OvJNnlxITZtomE8G7 = max(0,(NBnKOkHsvLd-1)*100)
	HQJuw1poCz2MRyiET = max(0,NBnKOkHsvLd*100)
	PxlUdCp83ykNW2siuKAv7mVMRZe = max(0,jjPWCL1OvJNnlxITZtomE8G7-rxvoadmqAXiW6SRE0zn7hVtuwyCkfF)
	hDbHniNtj2JCeOT = max(0,HQJuw1poCz2MRyiET-rxvoadmqAXiW6SRE0zn7hVtuwyCkfF)
	for yIiE1cO8rWlRZPNLJ9jMb5tToex6w,DDvlyxZImoaL,MdEe5xAKX32QPOugUB9TabItYz7op,Nx0lZXuS65tYU9QJpCTqw4cR2 in X1LP5GEbt2vF3VyH[jjPWCL1OvJNnlxITZtomE8G7:HQJuw1poCz2MRyiET]:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+DDvlyxZImoaL,MdEe5xAKX32QPOugUB9TabItYz7op,234,Nx0lZXuS65tYU9QJpCTqw4cR2,'1',yIiE1cO8rWlRZPNLJ9jMb5tToex6w,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	del X1LP5GEbt2vF3VyH
	for qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,Nx0lZXuS65tYU9QJpCTqw4cR2 in Da70JT6Ify[PxlUdCp83ykNW2siuKAv7mVMRZe:hDbHniNtj2JCeOT]:
		oBQORUT4MS3sFj2hdemNWunXk = fLvc6uEJiq3(lI5ck2gjRCiw9bMTF0xHsG)
		hArRgv5l10sU2yVSCO9JBHbE = 'live'
		if '.mkv' in oBQORUT4MS3sFj2hdemNWunXk or 'VOD' in ttCN9cTKWFIlmMDVpzs: hArRgv5l10sU2yVSCO9JBHbE = 'video'
		v0TjHlLZqkRxUCpmNwSy8AndO(hArRgv5l10sU2yVSCO9JBHbE,klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,235,Nx0lZXuS65tYU9QJpCTqw4cR2,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	del Da70JT6Ify
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(j6W37Jtc8ryXDT95Phx,jRD6Yh2SiNut,ttCN9cTKWFIlmMDVpzs,239,rxvoadmqAXiW6SRE0zn7hVtuwyCkfF+Tduyhw9mH1SW,rXEdWpTOxkiLqY8vfjUBn+'_NODIALOGS_')
	return
def zHSF4cMRhPp9ibC6ou1Yxna2lBq0(j6W37Jtc8ryXDT95Phx,jRD6Yh2SiNut,ttCN9cTKWFIlmMDVpzs,Yz6schq9wSmiu3IOdke0DXPj5W,tRO48VjuUF,YWCso5NMKO):
	if jRD6Yh2SiNut!='1': v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'صفحة '+str(1),ttCN9cTKWFIlmMDVpzs,Yz6schq9wSmiu3IOdke0DXPj5W,Vk54F7GcROfCy6HunEI,str(1),YWCso5NMKO,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	if not tRO48VjuUF: tRO48VjuUF = 0
	HX3Vc7mIS4 = int(tRO48VjuUF/100)+1
	for NBnKOkHsvLd in range(2,HX3Vc7mIS4):
		Q1Qb6AMaEuDgjHkl = (NBnKOkHsvLd%10==0 or int(jRD6Yh2SiNut)-4<NBnKOkHsvLd<int(jRD6Yh2SiNut)+4)
		AXWL0SuCrg7NvhH4le9KT2sO5D = (Q1Qb6AMaEuDgjHkl and int(jRD6Yh2SiNut)-40<NBnKOkHsvLd<int(jRD6Yh2SiNut)+40)
		if str(NBnKOkHsvLd)!=jRD6Yh2SiNut and (NBnKOkHsvLd%100==0 or AXWL0SuCrg7NvhH4le9KT2sO5D):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'صفحة '+str(NBnKOkHsvLd),ttCN9cTKWFIlmMDVpzs,Yz6schq9wSmiu3IOdke0DXPj5W,Vk54F7GcROfCy6HunEI,str(NBnKOkHsvLd),YWCso5NMKO,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	if str(HX3Vc7mIS4)!=jRD6Yh2SiNut: v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+'أخر صفحة '+str(HX3Vc7mIS4),ttCN9cTKWFIlmMDVpzs,Yz6schq9wSmiu3IOdke0DXPj5W,Vk54F7GcROfCy6HunEI,str(HX3Vc7mIS4),YWCso5NMKO,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	return
def zHqmAUfJvIXiraTE1xnGMjygR9L(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs):
	if 'SERIES' in ttCN9cTKWFIlmMDVpzs or 'VOD_ORIGINAL' in ttCN9cTKWFIlmMDVpzs: alTgYKybwfIhi = TI7QuAnOoX2
	else: alTgYKybwfIhi = yH76LQ2Yigdkfp
	alTgYKybwfIhi = alTgYKybwfIhi.replace('___','_'+j6W37Jtc8ryXDT95Phx)
	return alTgYKybwfIhi
def Wk24A81X0bOevyBMQEUNjq(j6W37Jtc8ryXDT95Phx,ttCN9cTKWFIlmMDVpzs,KKu9gxU3oSnMwldvkR):
	SvBypP6sNKoYbiAeZUVF,Po42eiOLy73c,AHfRNJaOSdgIUE3CMeK,RrJQvd9mBH46bclqoI0iCYK2Zj3,NNCyFG5MO3ewBI9k = OILXfklstCrncJVowgWEaZeRY5F(j6W37Jtc8ryXDT95Phx)
	if not RrJQvd9mBH46bclqoI0iCYK2Zj3: return
	KT67DQI1xk9XG34ezN0hH = a2LEDnNXSZTqVdoUM1GB5tvukHpQ(j6W37Jtc8ryXDT95Phx)
	if   ttCN9cTKWFIlmMDVpzs=='XTREAM_LIVE_GROUPS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_live_categories'
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_VOD_GROUPS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_vod_categories'
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_SERIES_GROUPS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_series_categories'
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_LIVE_ITEMS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_live_streams&category_id='+KKu9gxU3oSnMwldvkR
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_VOD_ITEMS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_vod_streams&category_id='+KKu9gxU3oSnMwldvkR
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_SERIES_ITEMS': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_series&category_id='+KKu9gxU3oSnMwldvkR
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_EPISODES': lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF+'&action=get_series_info&series_id='+KKu9gxU3oSnMwldvkR
	else: return
	aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',lI5ck2gjRCiw9bMTF0xHsG,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IPTV-XTREAM_MENUS-1st')
	ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: ov9nVhCfMkz37xPgQOS = ov9nVhCfMkz37xPgQOS.decode(AoCWwJHgUPKXI7u2lEzym).encode(AoCWwJHgUPKXI7u2lEzym)
	iQ5KlTsXInk2yo1WBVeZx64jpb = Bw6jaUcFxlqdDT8bC('list',ov9nVhCfMkz37xPgQOS)
	if 'GROUPS' in ttCN9cTKWFIlmMDVpzs:
		ttCN9cTKWFIlmMDVpzs = ttCN9cTKWFIlmMDVpzs.replace('_GROUPS','_ITEMS')
		iQ5KlTsXInk2yo1WBVeZx64jpb = sorted(iQ5KlTsXInk2yo1WBVeZx64jpb,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT['category_name'].lower())
		for yIiE1cO8rWlRZPNLJ9jMb5tToex6w in iQ5KlTsXInk2yo1WBVeZx64jpb:
			hbQR8K2TxmVruswlDGNcCEkv = yIiE1cO8rWlRZPNLJ9jMb5tToex6w['category_id']
			qXzxUjlRydGDhOQ9fM3a8tp4ZKe = yIiE1cO8rWlRZPNLJ9jMb5tToex6w['category_name']
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,ttCN9cTKWFIlmMDVpzs,285,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,str(hbQR8K2TxmVruswlDGNcCEkv),Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_SERIES_ITEMS':
		iQ5KlTsXInk2yo1WBVeZx64jpb = sorted(iQ5KlTsXInk2yo1WBVeZx64jpb,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT['name'].lower())
		for OFitNcsekqyCHoZVnXWxfvr8 in iQ5KlTsXInk2yo1WBVeZx64jpb:
			qXzxUjlRydGDhOQ9fM3a8tp4ZKe = OFitNcsekqyCHoZVnXWxfvr8['name']
			c7E603KRhbToig9V4yx = OFitNcsekqyCHoZVnXWxfvr8['cover']
			hbQR8K2TxmVruswlDGNcCEkv = OFitNcsekqyCHoZVnXWxfvr8['series_id']
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,'XTREAM_EPISODES',285,c7E603KRhbToig9V4yx,Vk54F7GcROfCy6HunEI,str(hbQR8K2TxmVruswlDGNcCEkv),Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	elif ttCN9cTKWFIlmMDVpzs=='XTREAM_EPISODES':
		c7E603KRhbToig9V4yx = iQ5KlTsXInk2yo1WBVeZx64jpb['info']['cover']
		EDy0Rs9liwjZvJY = iQ5KlTsXInk2yo1WBVeZx64jpb['info']['name']
		qPt6mxeJiA1gDlf3w4cKW = iQ5KlTsXInk2yo1WBVeZx64jpb['episodes']
		for doDz7nQeKFCH4g9MSO5WybvG1cUV0 in qPt6mxeJiA1gDlf3w4cKW:
			DlbRwZz1Sjaq09 = qPt6mxeJiA1gDlf3w4cKW[doDz7nQeKFCH4g9MSO5WybvG1cUV0]
			for ZG2eyVKMrNWCgfqowXYIx7nsJlU in DlbRwZz1Sjaq09:
				qXzxUjlRydGDhOQ9fM3a8tp4ZKe = ZG2eyVKMrNWCgfqowXYIx7nsJlU['title']
				YJyxBPcjCf4NeUd07agOqho = RSuYINdeamsK0t.findall('\d+.(S\d+E\d+)',qXzxUjlRydGDhOQ9fM3a8tp4ZKe,RSuYINdeamsK0t.DOTALL)
				if YJyxBPcjCf4NeUd07agOqho: qXzxUjlRydGDhOQ9fM3a8tp4ZKe = EDy0Rs9liwjZvJY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+YJyxBPcjCf4NeUd07agOqho[0]
				hbQR8K2TxmVruswlDGNcCEkv = ZG2eyVKMrNWCgfqowXYIx7nsJlU['id']
				IqWJRO0gH9bSu = ZG2eyVKMrNWCgfqowXYIx7nsJlU['container_extension']
				lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF.split('/player_api.php')[0]+'/series/'+RrJQvd9mBH46bclqoI0iCYK2Zj3+'/'+NNCyFG5MO3ewBI9k+'/'+str(hbQR8K2TxmVruswlDGNcCEkv)+'.'+IqWJRO0gH9bSu
				v0TjHlLZqkRxUCpmNwSy8AndO('video',klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,235,c7E603KRhbToig9V4yx,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	elif 'ITEMS' in ttCN9cTKWFIlmMDVpzs:
		hArRgv5l10sU2yVSCO9JBHbE = 'live' if 'LIVE' in ttCN9cTKWFIlmMDVpzs else 'video'
		iQ5KlTsXInk2yo1WBVeZx64jpb = sorted(iQ5KlTsXInk2yo1WBVeZx64jpb,reverse=False,key=lambda ddUWzEgl3bhS0oi5MkuT: ddUWzEgl3bhS0oi5MkuT['name'].lower())
		for fPUIoxJ2SKF8kh1a in iQ5KlTsXInk2yo1WBVeZx64jpb:
			qXzxUjlRydGDhOQ9fM3a8tp4ZKe = fPUIoxJ2SKF8kh1a['name']
			c7E603KRhbToig9V4yx = fPUIoxJ2SKF8kh1a['stream_icon']
			hbQR8K2TxmVruswlDGNcCEkv = fPUIoxJ2SKF8kh1a['stream_id']
			try:
				IqWJRO0gH9bSu = fPUIoxJ2SKF8kh1a['container_extension']
				if IqWJRO0gH9bSu: IqWJRO0gH9bSu = '.'+IqWJRO0gH9bSu
			except: IqWJRO0gH9bSu = Vk54F7GcROfCy6HunEI
			if fPUIoxJ2SKF8kh1a['stream_type']=='live': qiCPWMLTsNk9QyAObtDBH7m,y2ikY43PwmAIMNF8Ze9rx = Vk54F7GcROfCy6HunEI,'live'
			elif fPUIoxJ2SKF8kh1a['stream_type']=='movie': qiCPWMLTsNk9QyAObtDBH7m,y2ikY43PwmAIMNF8Ze9rx = 'movie/','video'
			lI5ck2gjRCiw9bMTF0xHsG = SvBypP6sNKoYbiAeZUVF.split('/player_api.php')[0]+'/'+qiCPWMLTsNk9QyAObtDBH7m+RrJQvd9mBH46bclqoI0iCYK2Zj3+'/'+NNCyFG5MO3ewBI9k+'/'+str(hbQR8K2TxmVruswlDGNcCEkv)+IqWJRO0gH9bSu
			v0TjHlLZqkRxUCpmNwSy8AndO(hArRgv5l10sU2yVSCO9JBHbE,klWfTZXjDY4qbPhvOKxd+qXzxUjlRydGDhOQ9fM3a8tp4ZKe,lI5ck2gjRCiw9bMTF0xHsG,235,c7E603KRhbToig9V4yx,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{'folder':j6W37Jtc8ryXDT95Phx})
	return
def BDfj7rF5sidg9SkpKTM(j6W37Jtc8ryXDT95Phx):
	Z70mXAdBUKWxtNFvJ6R1jQcs = cad8TeSyMUYmfsEO0.getSetting('av.language.provider')
	GqR6n3LFY9B2bkoAgWSJKhMiP = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'MENUS_CACHE_'+Z70mXAdBUKWxtNFvJ6R1jQcs+'_'+GqR6n3LFY9B2bkoAgWSJKhMiP,'%_IP'+j6W37Jtc8ryXDT95Phx+'_%')
	return
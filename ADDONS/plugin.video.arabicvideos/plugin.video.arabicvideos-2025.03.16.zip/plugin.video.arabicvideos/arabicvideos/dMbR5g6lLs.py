# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'VARBON'
xzA9sM3rG6IHd7jl8T = '_VRB_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['الرئيسية','يلا شوت']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==870: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==871: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==872: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==873: w8YsNWfQ5gFluRvOmSd4Cb96H = avVhkSxXDBifGPcCWzYJsnm5Q(url)
	elif mode==879: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VARBON-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,879,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"primary-links"(.*?)</u',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,871)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"list-categories"(.*?)</div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.lstrip('/')
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,871)
	return
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VARBON-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"home-content"(.*?)"footer"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('"overlay"','"duration"><')
		items = RSuYINdeamsK0t.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		GEzxBN8rAh1d = []
		for afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(' ')
			title = Uo7Tbc29Eu(title)
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة).\d+',title,RSuYINdeamsK0t.DOTALL)
			if 'episodes' not in type and AWjJSatwokZ:
				title = '_MOD_' + AWjJSatwokZ[0][0]
				title = title.replace('اون لاين',Vk54F7GcROfCy6HunEI)
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,873,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,872,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''["']pagination["'](.*?)["']footer["']''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,871,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
	return
def avVhkSxXDBifGPcCWzYJsnm5Q(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VARBON-SERIES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="eplist"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		NTaCesPm04 = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in NTaCesPm04:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,872)
	else:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"category".*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0])
			txsXO7gSMnrwAh6NmJ9D(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'episodes')
	return
def h5hmzOAeWEPip(url):
	MMJL8QqY6T7dv1onu = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'hash=' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		CZmKqDRcn2tA8SUphFQTs = RSuYINdeamsK0t.findall('hash=(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		CZmKqDRcn2tA8SUphFQTs = list(set(CZmKqDRcn2tA8SUphFQTs))
		for bGnTdg51V6vK in CZmKqDRcn2tA8SUphFQTs:
			zAYwk8ud73tK6nF0HPfDjhe = []
			itb54hH6eAY = bGnTdg51V6vK.split('__')
			for EgUlDW3NpXL0F in itb54hH6eAY:
				try:
					EgUlDW3NpXL0F = PnRA5dpzE18JU.b64decode(EgUlDW3NpXL0F+'=')
					if PvwFsJK23NbU8XWAx: EgUlDW3NpXL0F = EgUlDW3NpXL0F.decode(AoCWwJHgUPKXI7u2lEzym)
					zAYwk8ud73tK6nF0HPfDjhe.append(EgUlDW3NpXL0F)
				except: pass
			HXhRgxEZ4d2Dek = '>'.join(zAYwk8ud73tK6nF0HPfDjhe)
			HXhRgxEZ4d2Dek = HXhRgxEZ4d2Dek.splitlines()
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
				if ' => ' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
					title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(' => ')
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	elif 'post_id' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		aPlrVesU3WkF79DXxAT8jHSECq6Q = RSuYINdeamsK0t.findall("post_id = '(.*?)'",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if aPlrVesU3WkF79DXxAT8jHSECq6Q:
			aPlrVesU3WkF79DXxAT8jHSECq6Q = aPlrVesU3WkF79DXxAT8jHSECq6Q[0]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/wp-admin/admin-ajax.php?action=video_info&post_id='+aPlrVesU3WkF79DXxAT8jHSECq6Q
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-PLAY-2nd')
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('"name":"(.*?)","src":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if not HXhRgxEZ4d2Dek: HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('"(src)":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('\\/','/')
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				if name=='src': name = ''
				MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch')
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
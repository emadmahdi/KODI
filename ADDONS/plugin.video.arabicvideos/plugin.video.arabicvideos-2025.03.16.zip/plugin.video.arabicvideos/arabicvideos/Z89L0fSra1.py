# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMALIGHT'
xzA9sM3rG6IHd7jl8T = '_CML_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['قنوات فضائية']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==470: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==471: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==472: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==473: w8YsNWfQ5gFluRvOmSd4Cb96H = QgxPohjR8trYI(url,text)
	elif mode==474: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==479: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('"url": "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,479,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"content"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.replace(YIPoWuLzfl93BTS,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('cat=online-movies1','cat=online-movies')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,474)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('/category.php">(.*?)"navslide-divider"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall("'dropdown-menu'(.*?)</ul>",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,474)
	return
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'topvideos.php' in url: Ry3L7fdNGh = RSuYINdeamsK0t.findall('"caret"(.*?)id="pm-grid"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else: Ry3L7fdNGh = RSuYINdeamsK0t.findall('"caret"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'topvideos.php' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				if 'topvideos.php?c=english-movies' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				if 'topvideos.php?c=online-movies1' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				if 'topvideos.php?c=misc' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				if 'topvideos.php?c=tv-channel' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				if 'منذ البداية' in title and 'do=rating' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,471)
	else: txsXO7gSMnrwAh6NmJ9D(url)
	return
def txsXO7gSMnrwAh6NmJ9D(url,MmpRngPUCzrJ0HlGfB=Vk54F7GcROfCy6HunEI):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = []
	if MmpRngPUCzrJ0HlGfB=='featured_movies':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"container-fluid"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		HXhRgxEZ4d2Dek,ss285HRGmwx,ZJNXiLH47OaB5sle90FUT = zip(*items)
		items = zip(ZJNXiLH47OaB5sle90FUT,HXhRgxEZ4d2Dek,ss285HRGmwx)
	elif MmpRngPUCzrJ0HlGfB=='featured_series':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('المسلسلات المميزة(.*?)<style>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		HXhRgxEZ4d2Dek,ss285HRGmwx,ZJNXiLH47OaB5sle90FUT = zip(*items)
		items = zip(ZJNXiLH47OaB5sle90FUT,HXhRgxEZ4d2Dek,ss285HRGmwx)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('(data-echo=".*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('"BlocksList"(.*?)"titleSectionCon"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="pm-grid"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="pm-related"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('pm-ul-browse-videos(.*?)clearfix',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: return
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not items: items = RSuYINdeamsK0t.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if not items: items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		title = title.replace('ماي سيما',Vk54F7GcROfCy6HunEI).replace('مشاهدة',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
		if 'http' not in afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = lseWcUVP5qY+'/'+afR4xElWyzgcNAUnKXBempC.strip('/')
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة) \d+',title,RSuYINdeamsK0t.DOTALL)
		if any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			title = '_MOD_'+title
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,472,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'حلقة' in title:
			title = '_MOD_'+AWjJSatwokZ[0][0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,473,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/movseries/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,471,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,473,afR4xElWyzgcNAUnKXBempC)
	if MmpRngPUCzrJ0HlGfB not in ['featured_movies','featured_series']:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				title = Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,471)
		Xhmn2Nrb5dLK4GOTIe3p = RSuYINdeamsK0t.findall('showmore" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Xhmn2Nrb5dLK4GOTIe3p:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Xhmn2Nrb5dLK4GOTIe3p[0]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مشاهدة المزيد',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,471)
	return
def QgxPohjR8trYI(url,KBe7D36amSnG9WZf5dCUPQhOz):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-EPISODES-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"SeasonsBox"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	items = []
	if WvDVRHAc37CGulIhPagimorZSy0x and not KBe7D36amSnG9WZf5dCUPQhOz:
		afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"series-header".*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0] if afR4xElWyzgcNAUnKXBempC else Vk54F7GcROfCy6HunEI
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if len(items)==1: KBe7D36amSnG9WZf5dCUPQhOz = items[0][0]
		elif len(items)>1:
			for KBe7D36amSnG9WZf5dCUPQhOz,title in items: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,473,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,KBe7D36amSnG9WZf5dCUPQhOz)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('id="'+KBe7D36amSnG9WZf5dCUPQhOz+'"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu and len(items)<2:
		afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"series-header".*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0] if afR4xElWyzgcNAUnKXBempC else Vk54F7GcROfCy6HunEI
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.replace('ماي سيما',Vk54F7GcROfCy6HunEI).replace('مسلسل',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,472,afR4xElWyzgcNAUnKXBempC)
		else:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,472,afR4xElWyzgcNAUnKXBempC)
	if 'id="pm-related"' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		if items: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مواضيع ذات صلة',url,471)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<div itemprop="description">(.*?)href=',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('<p>(.*?)</p>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco,True): return
	hj50MJnoOp6ZWaS1IQ8Elr = url.replace('/watch.php','/play.php')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-PLAY-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	eI0dT5nfo24YyAkca8UKEOGHsu7m = []
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"embedURL" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in eI0dT5nfo24YyAkca8UKEOGHsu7m:
			eI0dT5nfo24YyAkca8UKEOGHsu7m.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=__embed'
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	items = RSuYINdeamsK0t.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in eI0dT5nfo24YyAkca8UKEOGHsu7m:
			eI0dT5nfo24YyAkca8UKEOGHsu7m.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	hj50MJnoOp6ZWaS1IQ8Elr = url.replace('/watch.php','/downloads.php')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMALIGHT-PLAY-3rd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"downloadlist"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<strong>(.*?)</strong>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in eI0dT5nfo24YyAkca8UKEOGHsu7m:
				eI0dT5nfo24YyAkca8UKEOGHsu7m.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	oOv4sVqEAmyM = RRav1Sf7Px(FFLhlYUAsfJBXeQmRpzD7c14ZP6,'url')
	url = oOv4sVqEAmyM+'/search.php?keywords='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
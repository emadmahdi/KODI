# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from rRp4ulO0fm import *
SITESURLS = {
			 SSBkx0WbN1asnDCQV6tIj(u"ࠪࡅࡍ࡝ࡁࡌࠩଏ")		:[WCPwmyVsb62KRlo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ଐ")]
			,EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡇࡋࡐࡃࡐࠫ଑")		:[EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪ଒")]
			,cpHxZyU7vTtqmIw(u"ࠧࡂࡍ࡚ࡅࡒ࠭ଓ")		:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨଔ")]
			,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬକ")	:[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࠴ࡡ࡬ࡹࡤࡱ࠳ࡺࡵࡣࡧࠪଖ")]
			,MpJ8GOKoic(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ଗ")		:[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫଘ")]
			,YzowicIDTRusXZSU61(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧଙ")		:[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩଚ")]
			,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪଛ")		:[jXWzIZcDva4ikEUfN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪଜ")]
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨଝ")	:[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫଞ")]
			,Nlyfx1HnzOWCovke5(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧଟ")		:[HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭ଠ")]
			,ESXZrtnCfcDJGo01vFg(u"ࠧࡂ࡛ࡏࡓࡑ࠭ଡ")		:[WXuJd8nz2spo146t(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨଢ")]
			,WXuJd8nz2spo146t(u"ࠩࡅࡓࡐࡘࡁࠨଣ")		:[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩତ")]
			,eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡇࡘࡓࡕࡇࡍࠫଥ")		:[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪଦ")]
			,wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧଧ")		:[YzowicIDTRusXZSU61(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ନ")]
			,ynxXU3gaiQ9GPCftr1q(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨ଩")		:[QYSAUI5r46yil8cfaO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧପ")]
			,NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪଫ")		:[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪବ")]
			,WXuJd8nz2spo146t(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧଭ")		:[MpJ8GOKoic(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭ମ")]
			,wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩଯ")		:[MzgKWUQ4V5H(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡧࡴࡤࡪࠪର")]
			,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ଱")	:[FGLEMi21Bfn(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨଲ")]
			,WsklGNp2CYzVQUag(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ଳ")		:[ESXZrtnCfcDJGo01vFg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯ࠨ଴")]
			,FGLEMi21Bfn(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨଵ")		:[NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡬ࡲࡦࡧ࠱ࡺ࡮ࡶࠧଶ")]
			,eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫଷ")	:[jXWzIZcDva4ikEUfN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠸࠼࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸ࠴࠻ࡶࡴ࠻ࠪସ")]
			,jXWzIZcDva4ikEUfN(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫହ")		:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ଺")]
			,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ଻")		:[WCPwmyVsb62KRlo(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡼࡨࡡࡴࡵ࠱ࡱࡾࡩࡩ࡮ࡣ࠱ࡧࡨ଼࠭")]
			,ESXZrtnCfcDJGo01vFg(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬଽ")	:[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨା"),FGLEMi21Bfn(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪି")]
			,cpHxZyU7vTtqmIw(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ୀ")	:[WsklGNp2CYzVQUag(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠶࠰ࡧࡶࡦࡳࡡࡤࡣࡩࡩ࠲ࡺࡶ࠯ࡥࡲࡱࠬୁ")]
			,WCPwmyVsb62KRlo(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ୂ")		:[WsklGNp2CYzVQUag(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡥࡴࡤࡱࡦࡹ࠷࠯ࡰࡨࡸࠬୃ")]
			,jXWzIZcDva4ikEUfN(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩୄ")		:[V2RQwM8XjlrK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡪࡺࡴࠧ୅")]
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ୆")		:[ESXZrtnCfcDJGo01vFg(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡽࡥࡣࡥࡤࡱࠬେ")]
			,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ୈ")		:[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬ୉")]
			,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ୊")		:[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧୋ")]
			,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩୌ")		:[XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦ୍ࠩ")]
			,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ୎")		:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫ୏")]
			,g7yJo2LVuqx1trPe(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ୐")	:[ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠮ࡦ࡮࡬ࡪ࠳ࡴࡥࡸࡵࠪ୑")]
			,Nlyfx1HnzOWCovke5(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ୒")		:[YzowicIDTRusXZSU61(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭୓")]
			,jXWzIZcDva4ikEUfN(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ୔")	:[cpHxZyU7vTtqmIw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ୕")]
			,WCPwmyVsb62KRlo(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬୖ")		:[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡲ࠱ࡪࡦࡸࡥࡴ࡭ࡲ࠲ࡳ࡫ࡴࠨୗ")]
			,NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ୘")		:[eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭୙")]
			,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡈࡒࡗ࡙ࡇࠧ୚")		:[EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭୛")]
			,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫଡ଼")		:[YzowicIDTRusXZSU61(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࠮ࡢ࡮ࡰࡩࡸ࡮࡫ࡢࡪ࠱ࡲࡪࡺࠧଢ଼")]
			,EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧ୞")		:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࠰ࡩࡹࡸ࡮ࡡࡳ࠯ࡷࡺ࠳ࡩ࡯࡮ࠩୟ")]
			,WCPwmyVsb62KRlo(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬୠ")	:[ynxXU3gaiQ9GPCftr1q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲࡫ࡻࡳࡩࡣࡵ࠲ࡻ࡯ࡤࡦࡱࠪୡ")]
			,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫୢ")		:[NNjUsZzEcFOAoKry2CDMgb1(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬୣ")]
			,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡎࡌࡉࡍࡏࠪ୤")		:[FGLEMi21Bfn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭୥"),g7yJo2LVuqx1trPe(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ୦"),FGLEMi21Bfn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ୧"),MzgKWUQ4V5H(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ୨"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩ୩")]
			,MpJ8GOKoic(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭୪")	:[MpJ8GOKoic(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬ୫")]
			,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ୬")		:[HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬࡫ࡷ࡯ࡴࡺ࠮ࡤࡣࡰࠫ୭")]
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ୮")		:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡹ࠳ࡱࡩࡳ࡯ࡤࡰࡰ࠴ࡣࡰ࡯ࠪ୯")]
			,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ୰")		:[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡧࡲࡰࡼࡤ࠲࡮ࡴ࡫ࠨୱ")]
			,Nlyfx1HnzOWCovke5(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ୲")		:[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮࡭࡫ࡱ࡯ࠬ୳")]
			,WsklGNp2CYzVQUag(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩ୴")	:[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲ࡲࡧࡳࡢ࠰ࡱࡩࡼࡹࠧ୵")]
			,jXWzIZcDva4ikEUfN(u"ࠨࡒࡄࡒࡊ࡚ࠧ୶")		:[pnkrd2S84FJfN73KuiCYv(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ୷")]
			,wAU9jKvmTM0(u"ࠪࡖࡊࡒࡅࡂࡕࡈࡗࠬ୸")		:[wYTDlJC5vpOKynUEX3ge6W(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ୹")]
			,ogJClMiqPa4A0NUtTxpDVybEWG(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩ୺")	:[wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡣ࠱ࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫࠮ࡤࡣࡰࠫ୻")]
			,jXWzIZcDva4ikEUfN(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ୼")	:[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡨࡥ࠰ࡹ࡭ࡵ࠭୽")]
			,QYSAUI5r46yil8cfaO(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ୾")		:[cpHxZyU7vTtqmIw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠴࡮ࡰࡹࠪ୿")]
			,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ஀")	:[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ஁")]
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ஂ")		:[wAU9jKvmTM0(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳ࡫࡮ࡡ࠯ࡶࡹࠫஃ")]
			,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ஄")		:[XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩஅ"),YzowicIDTRusXZSU61(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪஆ"),WsklGNp2CYzVQUag(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧஇ")]
			,Nlyfx1HnzOWCovke5(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧஈ")		:[QYSAUI5r46yil8cfaO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥࡰࡽࡡ࡮࠰ࡷࡹࡧ࡫ࠧஉ")]
			,Nlyfx1HnzOWCovke5(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧஊ")		:[MpJ8GOKoic(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡰࡧࡡࡵ࠰ࡱࡩࡹ࠭஋")]
			,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ஌")		:[ynxXU3gaiQ9GPCftr1q(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨ஍")]
			,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡛ࠫࡇࡒࡃࡑࡑࠫஎ")		:[SSBkx0WbN1asnDCQV6tIj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭࠯ࡸࡤࡶࡧࡵ࡮࠯ࡥࡤࡱࠬஏ")]
			,eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪஐ")	:[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠮࡯ࡵࡤࡩࡲ࠴࡮ࡦࡶࠪ஑")]
			,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩஒ")		:[wAU9jKvmTM0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪࡩࡩ࡮ࡣ࠱ࡷ࡭ࡵࡷࠨஓ")]
			,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫஔ")		:[FGLEMi21Bfn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡩ࡬ࡪࡥ࡮ࠫக")]
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬ࡟ࡁࡒࡑࡗࠫ஖")		:[g7yJo2LVuqx1trPe(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺ࠰ࡼࡥࡶࡵࡴ࠯ࡶࡹࠫ஗")]
			,eAMGzHRQVs2KyCwPXljYhB(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ஘")		:[QYSAUI5r46yil8cfaO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫங")]
			,wAU9jKvmTM0(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨச")	:[pnkrd2S84FJfN73KuiCYv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭஛")]
			,V2RQwM8XjlrK(u"ࠫࡎࡖࡔࡗࠩஜ")			:[Vk54F7GcROfCy6HunEI]
			,wAU9jKvmTM0(u"ࠬࡓ࠳ࡖࠩ஝")			:[Vk54F7GcROfCy6HunEI]
			,WsklGNp2CYzVQUag(u"࠭ࡒࡆࡒࡒࡗࠬஞ")		:[V2RQwM8XjlrK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧட"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ஠"),MzgKWUQ4V5H(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭஡")]
			,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠷ࠧ஢")	:[ynxXU3gaiQ9GPCftr1q(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯ࡳࡧࡩࡷ࠴࡮ࡥࡢࡦࡶ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨண"),jXWzIZcDva4ikEUfN(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭த"),MzgKWUQ4V5H(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ஥")]
			,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠵ࠫ஦")	:[SSBkx0WbN1asnDCQV6tIj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭஧"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫந"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬன")]
			,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠳ࠨப")	:[pnkrd2S84FJfN73KuiCYv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭஫"),wAU9jKvmTM0(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ஬"),MpJ8GOKoic(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ஭")]
			,WXuJd8nz2spo146t(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧம")	:[eAMGzHRQVs2KyCwPXljYhB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡸࡻࡲࡨࡧ࠱ࡷ࡭࠵࡫ࡰࡦ࡬ࠫய"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡮ࡳࡩ࡯ࠧர"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡱ࡯ࡥ࡫ࠪற")]
			,YzowicIDTRusXZSU61(u"ࠬࡌࡉࡍࡇࡖࡣࡘࡕࡕࡓࡅࡈࡗࠬல"):[FGLEMi21Bfn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠭ள")]
			,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ழ")	:[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫவ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨஶ")]
			}
if pwxH3oREFm5v98BCZ1QVtzMJOc:
	SITESURLS[QYSAUI5r46yil8cfaO(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪஷ")] = [g7yJo2LVuqx1trPe(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ஸ"),QYSAUI5r46yil8cfaO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪஹ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ஺"),WCPwmyVsb62KRlo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ஻"),ESXZrtnCfcDJGo01vFg(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ஼"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ஽"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫா"),Nlyfx1HnzOWCovke5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬி"),WsklGNp2CYzVQUag(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ீ"),WCPwmyVsb62KRlo(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫு"),ynxXU3gaiQ9GPCftr1q(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪூ")]
	SITESURLS[FGLEMi21Bfn(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭௃")] = [WCPwmyVsb62KRlo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭௄"),ynxXU3gaiQ9GPCftr1q(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ௅"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩெ"),jXWzIZcDva4ikEUfN(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬே"),QYSAUI5r46yil8cfaO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬை"),ynxXU3gaiQ9GPCftr1q(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ௉"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫொ"),pnkrd2S84FJfN73KuiCYv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬோ"),XCYALgFs2O3hZdpHrlMmB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ௌ"),FGLEMi21Bfn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨ்ࠫ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ௎")]
	SITESURLS[wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠵ࠫ௏")] = [XCYALgFs2O3hZdpHrlMmB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪௐ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ௑"),wAU9jKvmTM0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭௒"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ௓"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ௔"),MpJ8GOKoic(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ௕"),Nlyfx1HnzOWCovke5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ௖"),ESXZrtnCfcDJGo01vFg(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩௗ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ௘"),wAU9jKvmTM0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ௙"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧ௚")]
	SITESURLS[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠴ࠩ௛")] = [kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ௜"),eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ௝"),Nlyfx1HnzOWCovke5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ௞"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ௟"),ESXZrtnCfcDJGo01vFg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ௠"),YzowicIDTRusXZSU61(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭௡"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ௢"),XCYALgFs2O3hZdpHrlMmB(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡦࡥࡵࡺࡣࡩࡣࠪ௣"),wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡸࡪࡹࡴࡪࡰࡪࠫ௤"),MpJ8GOKoic(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ௥"),SSBkx0WbN1asnDCQV6tIj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ௦")]
else:
	SITESURLS[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ௧")] = [QYSAUI5r46yil8cfaO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭௨"),wAU9jKvmTM0(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ௩"),WCPwmyVsb62KRlo(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ௪"),WsklGNp2CYzVQUag(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ௫"),cpHxZyU7vTtqmIw(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ௬"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ௭"),cpHxZyU7vTtqmIw(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ௮"),YzowicIDTRusXZSU61(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ௯"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭௰"),WCPwmyVsb62KRlo(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ௱"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ௲")]
	SITESURLS[wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬ௳")] = [SSBkx0WbN1asnDCQV6tIj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ௴"),ESXZrtnCfcDJGo01vFg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ௵"),MzgKWUQ4V5H(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ௶"),V2RQwM8XjlrK(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ௷"),ESXZrtnCfcDJGo01vFg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ௸"),NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭௹"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ௺"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ௻"),XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ௼"),ynxXU3gaiQ9GPCftr1q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ௽"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ௾")]
	SITESURLS[ynxXU3gaiQ9GPCftr1q(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪ௿")] = [ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩఀ"),SSBkx0WbN1asnDCQV6tIj(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ఁ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬం"),jXWzIZcDva4ikEUfN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨః"),YzowicIDTRusXZSU61(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨఄ"),jXWzIZcDva4ikEUfN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫఅ"),wAU9jKvmTM0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧఆ"),Nlyfx1HnzOWCovke5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨఇ"),cpHxZyU7vTtqmIw(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩఈ"),jXWzIZcDva4ikEUfN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧఉ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ఊ")]
	SITESURLS[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨఋ")] = [ESXZrtnCfcDJGo01vFg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧఌ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ఍"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪఎ"),wAU9jKvmTM0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ఏ"),QYSAUI5r46yil8cfaO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ఐ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ఑"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬఒ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ఓ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧఔ"),YzowicIDTRusXZSU61(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬక"),wAU9jKvmTM0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫఖ")]
api_python_actions = [pnkrd2S84FJfN73KuiCYv(u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪగ"),QYSAUI5r46yil8cfaO(u"ࠩࡕࡉࡕࡕࡒࡕࡕࠪఘ"),cpHxZyU7vTtqmIw(u"ࠪࡉࡒࡇࡉࡍࡕࠪఙ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭చ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡏࡓࡍࡃࡐࡍࡈ࡙ࠧఛ"),jXWzIZcDva4ikEUfN(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩజ"),XCYALgFs2O3hZdpHrlMmB(u"ࠧࡌࡐࡒ࡛ࡓࡋࡒࡓࡑࡕࡗࠬఝ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩఞ"),V2RQwM8XjlrK(u"ࠩࡗࡉࡘ࡚ࡉࡏࡉࠪట"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡉ࡝࡚ࡒࡂࡒ࡜ࡘࡍࡕࡎࡄࡑࡇࡉࠬఠ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡊ࡞ࡅࡄࡗࡗࡉࡏ࡙ࠧడ")]
api_repos_actions = [V2RQwM8XjlrK(u"ࠬࡇࡄࡅࡑࡑࡗࠬఢ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠸ࠨణ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠺ࠩత")]
C7tWRO0bJdz3TV49j8eIklM1fDSxB = eu1NswY9zkKC60I
qUhMJ0k8yAs = eu1NswY9zkKC60I
JizCr5lUSWf = eu1NswY9zkKC60I
fNB1eMh5ytzOIPow2icAC6Sv = YOHXqtbQTBfKerIZ
resolveonly = eu1NswY9zkKC60I
oMt0Iw2GKZ47PeLBj13JO = eu1NswY9zkKC60I
ALLOW_DNS_FIX = tayEeSpKRJIdC8g10
ALLOW_PROXY_FIX = tayEeSpKRJIdC8g10
ALLOW_SHOWDIALOGS_FIX = tayEeSpKRJIdC8g10
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪథ"),cpHxZyU7vTtqmIw(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬద"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫధ"),cpHxZyU7vTtqmIw(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭న"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ఩"),ynxXU3gaiQ9GPCftr1q(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨప"),XCYALgFs2O3hZdpHrlMmB(u"࡚ࠧࡃࡔࡓ࡙࠭ఫ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡘࡄࡖࡇࡕࡎࠨబ")]
BADCOMMONIDS = [BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࠼࠽࠾࠿࠭࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠲࠳࠴࠵࠭భ"),WsklGNp2CYzVQUag(u"ࠪ࠽࠾࠾࠸࠮࠹࠺࠺࠻࠳࠵࠶࠶࠷࠱࠸࠹࠲࠳࠯࠵࠴࠽࠼ࠧమ")]
GEOLOCATION_DATA = Vk54F7GcROfCy6HunEI
AV_CLIENT_IDS = Vk54F7GcROfCy6HunEI
DNS_SERVERS = [WXuJd8nz2spo146t(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬయ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭ర"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧఱ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨల"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩళ"),pnkrd2S84FJfN73KuiCYv(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪఴ")]
busydialog_active = eu1NswY9zkKC60I
dns_succeeded_urls = []
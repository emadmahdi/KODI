# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'TVFUN'
xzA9sM3rG6IHd7jl8T = '_TVF_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['بث مباشر']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==460: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==461: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==462: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==463: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==469: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'TVFUN-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,469,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"menu-btn"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)</span>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,461)
	return
def txsXO7gSMnrwAh6NmJ9D(url,U8tZVnuiQqYjG5KdEWNbXF=Vk54F7GcROfCy6HunEI):
	items = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'TVFUN-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="head-title"(.*?)id="footer"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		GEzxBN8rAh1d = []
		dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			title = '_MOD_'+title.replace('<br>',otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
			if any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,462,afR4xElWyzgcNAUnKXBempC)
			elif AWjJSatwokZ and 'الحلقة' in title:
				title = '_MOD_' + AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,463,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,463,afR4xElWyzgcNAUnKXBempC)
	if U8tZVnuiQqYjG5KdEWNbXF!='latest':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('<a href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=="": continue
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,461)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'TVFUN-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="head-title"(.*?)id="footer"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
				title = '_MOD_'+title.replace('<br>',otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,462,afR4xElWyzgcNAUnKXBempC)
		else:
			items = RSuYINdeamsK0t.findall('class="episode.*?href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,462)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=="": continue
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,463)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	hj50MJnoOp6ZWaS1IQ8Elr = url.replace('/video/','/watch/')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'TVFUN-PLAY-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('VideoServers"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for HFXwP5TlDqS0yjrYi1xdV3u9KG,name in HXhRgxEZ4d2Dek:
			HFXwP5TlDqS0yjrYi1xdV3u9KG = HFXwP5TlDqS0yjrYi1xdV3u9KG[2:]
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: HFXwP5TlDqS0yjrYi1xdV3u9KG = HFXwP5TlDqS0yjrYi1xdV3u9KG.decode(AoCWwJHgUPKXI7u2lEzym)
			HFXwP5TlDqS0yjrYi1xdV3u9KG = PnRA5dpzE18JU.b64decode(HFXwP5TlDqS0yjrYi1xdV3u9KG)
			if PvwFsJK23NbU8XWAx: HFXwP5TlDqS0yjrYi1xdV3u9KG = HFXwP5TlDqS0yjrYi1xdV3u9KG.decode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('src="(.*?)"',HFXwP5TlDqS0yjrYi1xdV3u9KG,RSuYINdeamsK0t.DOTALL)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				if '//' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch'
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	if otBWsSAfu7dihVkP9e1JFKrvmYy2Q in search:
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/q/'+search+'/'
	txsXO7gSMnrwAh6NmJ9D(url)
	return
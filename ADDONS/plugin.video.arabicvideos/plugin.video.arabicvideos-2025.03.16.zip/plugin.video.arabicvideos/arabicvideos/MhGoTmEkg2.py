# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'EGYNOW'
xzA9sM3rG6IHd7jl8T = '_EGN_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==430: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==431: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==432: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==433: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==434: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==437: w8YsNWfQ5gFluRvOmSd4Cb96H = cZrsdpG2zEf1oOiD8PVQBwYHRqvS(url)
	elif mode==439: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/films',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('"canonical" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,439,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',lseWcUVP5qY,435)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',lseWcUVP5qY,434)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المضاف حديثا',lseWcUVP5qY,431)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'افلام اون لاين',lseWcUVP5qY+'/films1',436)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'مسلسلات اون لاين',lseWcUVP5qY+'/series-all1',436)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'قائمة تفصيلية',lseWcUVP5qY,437)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"SiteNavigation"(.*?)"Search"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,431)
	return
def cZrsdpG2zEf1oOiD8PVQBwYHRqvS(website=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',website+'/films',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('"canonical" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"ListDroped"(.*?)"SearchingMaster"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,value,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = website+'/explore/?'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'='+value
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,431)
	return
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-SUBMENU-1st')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',url,431)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"titleSectionCon"(.*?)</div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('data-key="(.*?)".*?<em>(.*?)</em>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for U8tZVnuiQqYjG5KdEWNbXF,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		hj50MJnoOp6ZWaS1IQ8Elr = lseWcUVP5qY+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+U8tZVnuiQqYjG5KdEWNbXF
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,hj50MJnoOp6ZWaS1IQ8Elr,431)
	return
def txsXO7gSMnrwAh6NmJ9D(url,MmpRngPUCzrJ0HlGfB=Vk54F7GcROfCy6HunEI):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
		eDbTIrV6KLfz80 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-TITLES-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
	elif MmpRngPUCzrJ0HlGfB=='featured':
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-TITLES-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"MainSlider"(.*?)"MatchesTable"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-TITLES-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"BlocksList"(.*?)"Paginate"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('"BlocksList"(.*?)"titleSectionCon"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not items: items = RSuYINdeamsK0t.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,432,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'الحلقة' in title:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,433,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/movseries/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,431,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,433,afR4xElWyzgcNAUnKXBempC)
	if MmpRngPUCzrJ0HlGfB!='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"Paginate"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Uo7Tbc29Eu(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				title = Uo7Tbc29Eu(title)
				if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,431)
		Xhmn2Nrb5dLK4GOTIe3p = RSuYINdeamsK0t.findall('showmore" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Xhmn2Nrb5dLK4GOTIe3p:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Xhmn2Nrb5dLK4GOTIe3p[0]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مشاهدة المزيد',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,431)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	WvDVRHAc37CGulIhPagimorZSy0x,QQHXiFSA0jUsklmxbpaMztu = [],[]
	if 'Episodes.php' in url:
		hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
		eDbTIrV6KLfz80 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-EPISODES-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		QQHXiFSA0jUsklmxbpaMztu = [FjwObZSWkg8ahBdiQf9IeY135DpXoP]
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-EPISODES-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"SeasonsList"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"EpisodesList"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x:
		afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"og:image" content="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for bGnTdg51V6vK,huFADBJSor6tKZPbeW9HiXcV,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+huFADBJSor6tKZPbeW9HiXcV+'&post_id='+bGnTdg51V6vK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,433,afR4xElWyzgcNAUnKXBempC)
	elif QQHXiFSA0jUsklmxbpaMztu:
		afR4xElWyzgcNAUnKXBempC = J2L6to3R1Z.getInfoLabel('ListItem.Thumb')
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,AWjJSatwokZ in items:
			title = title+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+AWjJSatwokZ
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,432,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	hj50MJnoOp6ZWaS1IQ8Elr = url+'/watch/'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	lseWcUVP5qY = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,'url')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"container-servers"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		X9PVULyJeCSviHfhmj0Gku6tgZz2 = RSuYINdeamsK0t.findall('data-id="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if X9PVULyJeCSviHfhmj0Gku6tgZz2:
			X9PVULyJeCSviHfhmj0Gku6tgZz2 = X9PVULyJeCSviHfhmj0Gku6tgZz2[0]
			items = RSuYINdeamsK0t.findall('data-server="(.*?)".*?<span>(.*?)</span>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for oOv4sVqEAmyM,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+oOv4sVqEAmyM+'&post_id='+X9PVULyJeCSviHfhmj0Gku6tgZz2+'?named='+title+'__watch'
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Y6mwd2WJpiN7jgzXtElP4Vbh = RSuYINdeamsK0t.findall('"container-iframe"><iframe src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Y6mwd2WJpiN7jgzXtElP4Vbh:
		Y6mwd2WJpiN7jgzXtElP4Vbh = Y6mwd2WJpiN7jgzXtElP4Vbh[0].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI)
		title = RRav1Sf7Px(Y6mwd2WJpiN7jgzXtElP4Vbh,'name')
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Y6mwd2WJpiN7jgzXtElP4Vbh+'?named='+title+'__embed'
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"container-download"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,jMiru3pGns in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI)
			if jMiru3pGns!=Vk54F7GcROfCy6HunEI: jMiru3pGns = '____'+jMiru3pGns
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+jMiru3pGns
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
def xkK0Y7fnciMQvjyq(url):
	url = url.split('/smartemadfilter?')[0]
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',lseWcUVP5qY,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('("dropdown-button".*?)"SearchingMaster"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ugep4NW1YS = RSuYINdeamsK0t.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return Ugep4NW1YS
def uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI):
	items = RSuYINdeamsK0t.findall('data-term="(\d+)" data-name="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return items
def eW2Btjung49(url):
	zxAP2BC6ekOXpHnwF = url.split('/smartemadfilter?')[0]
	iFJVwrXDlfRUKN20 = RRav1Sf7Px(url,'url')
	url = url.replace(zxAP2BC6ekOXpHnwF,iFJVwrXDlfRUKN20)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def eDoWruaJt92k50dFRKOHl(ssCfIvyG3epxY4OtkHK,url):
	aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
	ynmiDuav5ICTeRsqj6Vb18Q = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	ynmiDuav5ICTeRsqj6Vb18Q = eW2Btjung49(ynmiDuav5ICTeRsqj6Vb18Q)
	return ynmiDuav5ICTeRsqj6Vb18Q
jVTGDSdXIEbQJ6ueqK19w = ['category','country','genre','release-year']
LJSlAbTd4vknNqtOUZDm = ['quality','release-year','genre','category','language','country']
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if jVTGDSdXIEbQJ6ueqK19w[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(jVTGDSdXIEbQJ6ueqK19w[0:-1])):
			if jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='ALL_ITEMS_FILTER':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+KMbV6CGYIuH
		hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',hj50MJnoOp6ZWaS1IQ8Elr,431)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',hj50MJnoOp6ZWaS1IQ8Elr,431)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ugep4NW1YS = xkK0Y7fnciMQvjyq(url)
	dict = {}
	for name,UwcYSVZbdK3rI,kuKGA8HpgN7PyjvxeLZ in Ugep4NW1YS:
		name = name.replace('--',Vk54F7GcROfCy6HunEI)
		items = uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='SPECIFIED_FILTER':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<2:
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]:
					url = eW2Btjung49(url)
					txsXO7gSMnrwAh6NmJ9D(url)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'SPECIFIED_FILTER___'+Ng1Jod47fp0S)
				return
			else:
				hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',hj50MJnoOp6ZWaS1IQ8Elr,431)
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',hj50MJnoOp6ZWaS1IQ8Elr,435,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='ALL_ITEMS_FILTER':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع :'+name,hj50MJnoOp6ZWaS1IQ8Elr,434,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if value=='196533': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'أفلام نيتفلكس'
			elif value=='196531': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'مسلسلات نيتفلكس'
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'#+dict[kuKGA8HpgN7PyjvxeLZ]['0']
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'+name
			if type=='ALL_ITEMS_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,434,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='SPECIFIED_FILTER' and jVTGDSdXIEbQJ6ueqK19w[-2]+'=' in UWFh8TfCJpRomD3:
				ynmiDuav5ICTeRsqj6Vb18Q = eDoWruaJt92k50dFRKOHl(ssCfIvyG3epxY4OtkHK,url)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,431)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,435,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.replace('=&','=0&')
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	for key in LJSlAbTd4vknNqtOUZDm:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all_filters': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.replace('=0','=')
	return PpjxGzO7yqD0AXSJL1Mw
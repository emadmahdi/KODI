# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
xzA9sM3rG6IHd7jl8T = WCPwmyVsb62KRlo(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
KHWjqGglbCtBvS = CR3aLOVKSIme5XFoYi6M.path.join(HTx0geQ7siEXV,MpJ8GOKoic(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
gWyBObvHL4V = CR3aLOVKSIme5XFoYi6M.path.join(HTx0geQ7siEXV,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
NehEdgfU5W = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,ESXZrtnCfcDJGo01vFg(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),WXuJd8nz2spo146t(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
vW9UgGwp1q78baQeDrf = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
FCecEw1DfM6ihJ = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
JCFnvZLtVSrk0P = V2RQwM8XjlrK(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
zzTvZLRtHWe4XOo = ynxXU3gaiQ9GPCftr1q(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
VWAkurxXEJRy5D9M = wAU9jKvmTM0(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
TTRwULfJbaQcDNs = wYTDlJC5vpOKynUEX3ge6W(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
NmRzhxGIJq = dQxGp0knIfj
PTLqKaUAV5wdyvMDfc4 = GK4x3b6Erdk
Pzb9OlDt4HWEwXgnJFV = ZZ0elhq5SkW1cpPUJz
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W):
	if   Yz6schq9wSmiu3IOdke0DXPj5W==ogJClMiqPa4A0NUtTxpDVybEWG(u"࠽࠴࠱࣢"): w8YsNWfQ5gFluRvOmSd4Cb96H = OIaDg139Yk2jJMeLixFps6rWvzwlAV()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==pnkrd2S84FJfN73KuiCYv(u"࠷࠵࠳ࣣ"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(KHWjqGglbCtBvS,YOHXqtbQTBfKerIZ,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MzgKWUQ4V5H(u"࠸࠶࠵ࣤ"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(gWyBObvHL4V,YOHXqtbQTBfKerIZ,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠹࠷࠷ࣥ"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(NehEdgfU5W,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠺࠸࠹ࣦ"): w8YsNWfQ5gFluRvOmSd4Cb96H = JvSlQGoR4F6im8jh5OxKeDsI1H2BX9(YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WsklGNp2CYzVQUag(u"࠻࠹࠻ࣧ"): w8YsNWfQ5gFluRvOmSd4Cb96H = sI9u6e2BAiDM(YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠼࠺࠶ࣨ"): w8YsNWfQ5gFluRvOmSd4Cb96H = SS5Tzfq7Xmp8hRnOY0(YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==NNjUsZzEcFOAoKry2CDMgb1(u"࠽࠵࠱ࣩ"): w8YsNWfQ5gFluRvOmSd4Cb96H = WtehuYQag2()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠷࠶࠳࣪"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(vW9UgGwp1q78baQeDrf,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ynxXU3gaiQ9GPCftr1q(u"࠸࠷࠵࣫"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(FCecEw1DfM6ihJ,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠹࠸࠷࣬"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(JCFnvZLtVSrk0P,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WsklGNp2CYzVQUag(u"࠺࠹࠹࣭"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(zzTvZLRtHWe4XOo,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==eAMGzHRQVs2KyCwPXljYhB(u"࠻࠺࠻࣮"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(VWAkurxXEJRy5D9M,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WCPwmyVsb62KRlo(u"࠼࠻࠶࣯"): w8YsNWfQ5gFluRvOmSd4Cb96H = Agz62xbajVk15PieF4utWsGmBC(TTRwULfJbaQcDNs,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠽࠵࠸ࣰ"): w8YsNWfQ5gFluRvOmSd4Cb96H = uo1DHY3xfcCqRB8h(YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==eAMGzHRQVs2KyCwPXljYhB(u"࠷࠶࠺ࣱ"): w8YsNWfQ5gFluRvOmSd4Cb96H = ttqZMHN1kYWDQ2();ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==EM6qpnCBYQGA9kbgDVLfrP(u"࠲࠲࠻࠴ࣲ"): w8YsNWfQ5gFluRvOmSd4Cb96H = urLAfkR34aGEj95pMJQO6tFiZm()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠳࠳࠼࠶ࣳ"): w8YsNWfQ5gFluRvOmSd4Cb96H = OjA0BF1uQJ3YxPZvbirIn(YOHXqtbQTBfKerIZ);ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MzgKWUQ4V5H(u"࠴࠴࠽࠸ࣴ"): w8YsNWfQ5gFluRvOmSd4Cb96H = RuHWDUqT1a98JkiVrnIB();ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠵࠵࠾࠳ࣵ"): w8YsNWfQ5gFluRvOmSd4Cb96H = YE38WkviTtuS0ph1();ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==FGLEMi21Bfn(u"࠶࠶࠸࠵ࣶ"): w8YsNWfQ5gFluRvOmSd4Cb96H = iTpRGU5PwYMjt3();ff6BjH1F5I4qo(w8YsNWfQ5gFluRvOmSd4Cb96H)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WCPwmyVsb62KRlo(u"࠷࠰࠹࠷ࣷ"): w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠱࠱࠺࠹ࣸ"): w8YsNWfQ5gFluRvOmSd4Cb96H = JKQBixOwMXl5F1yPNeb0uRsk3WGTgh()
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = eu1NswY9zkKC60I
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def JKQBixOwMXl5F1yPNeb0uRsk3WGTgh():
	bbYGkvuoSHB52R3TD84ZhmEI = V2RQwM8XjlrK(u"࠲࠲࠵࠸ࣹ")*V2RQwM8XjlrK(u"࠲࠲࠵࠸ࣹ")
	gHNrTGfQpklb2A1MBx8ueo9OJV6Kh = WWyMvQzapJOkdYeH0b()//bbYGkvuoSHB52R3TD84ZhmEI
	OfXL63VzS7gJn5GUltc2QxFEwypHRB = gHNrTGfQpklb2A1MBx8ueo9OJV6Kh<V2RQwM8XjlrK(u"࠷࠳ࣺ")
	size = nMt0iueCy6K+YzowicIDTRusXZSU61(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+Nlyfx1HnzOWCovke5(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+ZZoLlKyInXc08j2pTGJ
	if OfXL63VzS7gJn5GUltc2QxFEwypHRB:
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+wYTDlJC5vpOKynUEX3ge6W(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠐ"),YzowicIDTRusXZSU61(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฦูอำสࠡ็่ฮ้ฬษࠡ࠰࠱ࠤํํะศࠢํือฮࠠๆึส็้ࠦใฬ์ิอࠥ็๊ࠡฬื฾๏๊ࠠศๆฯ๋ฬุ้ࠠฬื฾๏๊ࠠไ๊า๎ࠥ๎สี฼ํ่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ࠲࠳ࠦว็ฬࠣฬาอฬสࠢศ่๎ࠦส็ฺํๅࠥา็ศิๆࠤํะๆุ์ไࠤ่๎ฯ๋๋ࠢฮ๋฾๊โ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲࠬࠑ")+size)
	else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠒ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"่ࠩืฬำษࠡษ็ฮำุ๊็ࠢไ๎ࠥา็ศิๆࠤั๐ฯส࡞ࡱࡠࡳ࠭ࠓ")+size)
	return OfXL63VzS7gJn5GUltc2QxFEwypHRB
def ff6BjH1F5I4qo(oecU0R2PC4WmyTdHFk13xAph):
	if oecU0R2PC4WmyTdHFk13xAph: YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ)
	return
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡰ࡮ࡴ࡫ࠨࠔ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫๆำีࠡ็ึหาฯࠠศๆอาื๐ๆࠨࠕ"),Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠴࠴࠽࠼ࣻ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),jXWzIZcDva4ikEUfN(u"࠭ส็ฺํๅࠥอไอ้สึࠬࠗ"),Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"࠻࠺࠶ࣼ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),ynxXU3gaiQ9GPCftr1q(u"ࠨฬ้฼๏็ࠠไ๊า๎ࠬ࠙"),Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"࠼࠺࠰ࣽ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠩࡩࡳࡱࡪࡥࡳࠩࠚ"),WCPwmyVsb62KRlo(u"ࠪฮ๋฾๊โࠢส่อืๆศ็ฯࠫࠛ"),Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"࠷࠰࠹࠲ࣾ"))
	return
def urLAfkR34aGEj95pMJQO6tFiZm():
	gCN1aspLSldwZWHBoV0,W4QKNJrloXExp3ha9bUms = ooFhg4P73OKBtD0a8GRWecv(NmRzhxGIJq)
	llVTJXsoa2exp86CtQFDy,eXK2uMqE3lAP1kW5B = ooFhg4P73OKBtD0a8GRWecv(PTLqKaUAV5wdyvMDfc4)
	krapxHRchdLTIjlbzP9U0SyOwKV,UP6qbrX5Gviag = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(Pzb9OlDt4HWEwXgnJFV)
	t8q3g2uNnp,hB45OHxeSFEAn7vgpq = gCN1aspLSldwZWHBoV0+llVTJXsoa2exp86CtQFDy+krapxHRchdLTIjlbzP9U0SyOwKV,W4QKNJrloXExp3ha9bUms+eXK2uMqE3lAP1kW5B+UP6qbrX5Gviag
	Nlvjm0siXK7dDP = Nlyfx1HnzOWCovke5(u"ࠫࠥ࠮ࠧࠜ")+TVPU926hld(gCN1aspLSldwZWHBoV0)+YzowicIDTRusXZSU61(u"ࠬࠦ࠭ࠡࠩࠝ")+str(W4QKNJrloXExp3ha9bUms)+QYSAUI5r46yil8cfaO(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠞ")
	z3r2yNQqDC9EBj6 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࠡࠪࠪࠟ")+TVPU926hld(llVTJXsoa2exp86CtQFDy)+XCYALgFs2O3hZdpHrlMmB(u"ࠨࠢ࠰ࠤࠬࠠ")+str(eXK2uMqE3lAP1kW5B)+g7yJo2LVuqx1trPe(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࠡ")
	mSO9iEG348ao = eAMGzHRQVs2KyCwPXljYhB(u"ࠪࠤ࠭࠭ࠢ")+TVPU926hld(krapxHRchdLTIjlbzP9U0SyOwKV)+YzowicIDTRusXZSU61(u"ࠫࠥ࠳ࠠࠨࠣ")+str(UP6qbrX5Gviag)+ynxXU3gaiQ9GPCftr1q(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࠤ")
	giuXKqNSk3js = XCYALgFs2O3hZdpHrlMmB(u"࠭ࠠࠩࠩࠥ")+TVPU926hld(t8q3g2uNnp)+WsklGNp2CYzVQUag(u"ࠧࠡ࠯ࠣࠫࠦ")+str(hB45OHxeSFEAn7vgpq)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࠧ")
	v0TjHlLZqkRxUCpmNwSy8AndO(eAMGzHRQVs2KyCwPXljYhB(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),xzA9sM3rG6IHd7jl8T+wYTDlJC5vpOKynUEX3ge6W(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠩ")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"࠱࠱࠺࠷ࣿ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),nMt0iueCy6K+QYSAUI5r46yil8cfaO(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠫ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"࠺࠻࠼࠽ऀ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),xzA9sM3rG6IHd7jl8T+Nlyfx1HnzOWCovke5(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩ࠭")+Nlvjm0siXK7dDP,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"࠳࠳࠼࠶ँ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),xzA9sM3rG6IHd7jl8T+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬ࠯")+z3r2yNQqDC9EBj6,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"࠴࠴࠽࠸ं"))
	v0TjHlLZqkRxUCpmNwSy8AndO(pnkrd2S84FJfN73KuiCYv(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),xzA9sM3rG6IHd7jl8T+ESXZrtnCfcDJGo01vFg(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫ࠱")+mSO9iEG348ao,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠵࠵࠾࠳ः"))
	v0TjHlLZqkRxUCpmNwSy8AndO(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡲࡩ࡯࡭ࠪ࠲"),xzA9sM3rG6IHd7jl8T+MpJ8GOKoic(u"࠭สึใํีࠥอไษำ้ห๊าࠧ࠳")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"࠶࠶࠸࠵ऄ"))
	return
def iTpRGU5PwYMjt3():
	oecU0R2PC4WmyTdHFk13xAph = eu1NswY9zkKC60I
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠴"),WCPwmyVsb62KRlo(u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥ࠴࠮๊่ࠡืาࠦฬๆ์฼ࠤ๊๊แศฬࠣห้ฮั็ษ่ะࠥอไใัํ้ฮࠦ࠮࠯ࠢะฮ๎ฺ๊๊ࠦาࠤฬ๊ศา่ส้ัࠦลๅ๋ࠣัฬ๊ษࠡษ็ูๆืࠠ࠯࠰ࠣ๎฾์๊ࠡฯส่ฮ่ࠦื฻ํอࠥ฼ศุࠢส่๊฻ๆฺࠢ࠱࠲ࠥ๐ู็์ࠣห้ำวๅหࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ั้ࠣห้฿ๅๅ์ฬࠤฯะๅࠡส่ืาࠦๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ์ู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠵"))
	if W8j2OheqsroDJIYzRupt6nG:
		LTW4UcDzVObdQY70MqwvgfBZ5Gia = YE38WkviTtuS0ph1()
		oY54qxOHMlQ = Agz62xbajVk15PieF4utWsGmBC(GK4x3b6Erdk,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
		oecU0R2PC4WmyTdHFk13xAph = LTW4UcDzVObdQY70MqwvgfBZ5Gia and OGQq7FP0yKkgAjzw94B2MEu
		if oecU0R2PC4WmyTdHFk13xAph: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࠶"),ESXZrtnCfcDJGo01vFg(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠๆีะࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ฿วะࠢส่อืๆศ็ฯࠤสู๊้๊ࠡ฽๏ฯࠠศๆุๅึࠦ࠮࠯ฺ๋ࠢ฾๐ษุࠡห฻ࠥอไๆื้฽ࠬ࠷"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣฮฺ็๊าࠢส่อืๆศ็ฯࠤํหูศัอ๋ࠥหไฺ๊๋ࠢ฾๐ษุࠡห฻ࠥอไๆื้฽ࠬ࠸"))
	return oecU0R2PC4WmyTdHFk13xAph
def RuHWDUqT1a98JkiVrnIB():
	import rrnsP3eh5Q
	rrnsP3eh5Q.ccUmXov1LtjWkps6D7l3gx2z()
	kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(ynxXU3gaiQ9GPCftr1q(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࠹"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪ࠺"),WCPwmyVsb62KRlo(u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬࠦ࠮࠯ࠢ฼่๊อࠠฤ่ࠣห้๋ำฮࠢํฮ๊ࠦสๅไสส๏อฺ่ࠠาࠤฬ์ส่ษฤࠤ฾๋ัࠡษ็ูๆำวหࠢ࠱࠲ࠥ๎รุ๋สࠤฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫ࠻"))
	if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
		kNQM9jAU6TVlhezn14cKtBb = Agz62xbajVk15PieF4utWsGmBC(GK4x3b6Erdk,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
		if kNQM9jAU6TVlhezn14cKtBb: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠼"),V2RQwM8XjlrK(u"ࠩะ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊าࠧ࠽"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠾"))
	return kNQM9jAU6TVlhezn14cKtBb
def YE38WkviTtuS0ph1():
	kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(SSBkx0WbN1asnDCQV6tIj(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࠿"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ูࠬฤศๆࠪࡀ"),YzowicIDTRusXZSU61(u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧࡁ"))
	if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
		try:
			CR3aLOVKSIme5XFoYi6M.remove(ZZ0elhq5SkW1cpPUJz)
			kNQM9jAU6TVlhezn14cKtBb = YOHXqtbQTBfKerIZ
		except: pass
		if kNQM9jAU6TVlhezn14cKtBb: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠧห็ࠣฬ๋าวฮ่ࠢืา่ࠦหืไ๎ึࠦๅๅใࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧࡂ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨࡃ"))
	return kNQM9jAU6TVlhezn14cKtBb
def urLAfkR34aGEj95pMJQO6tFiZm():
	gCN1aspLSldwZWHBoV0,W4QKNJrloXExp3ha9bUms = ooFhg4P73OKBtD0a8GRWecv(NmRzhxGIJq)
	llVTJXsoa2exp86CtQFDy,eXK2uMqE3lAP1kW5B = ooFhg4P73OKBtD0a8GRWecv(PTLqKaUAV5wdyvMDfc4)
	krapxHRchdLTIjlbzP9U0SyOwKV,UP6qbrX5Gviag = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(Pzb9OlDt4HWEwXgnJFV)
	t8q3g2uNnp,hB45OHxeSFEAn7vgpq = gCN1aspLSldwZWHBoV0+llVTJXsoa2exp86CtQFDy+krapxHRchdLTIjlbzP9U0SyOwKV,W4QKNJrloXExp3ha9bUms+eXK2uMqE3lAP1kW5B+UP6qbrX5Gviag
	Nlvjm0siXK7dDP = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࠣࠬࠬࡄ")+TVPU926hld(gCN1aspLSldwZWHBoV0)+WsklGNp2CYzVQUag(u"ࠪࠤ࠲ࠦࠧࡅ")+str(W4QKNJrloXExp3ha9bUms)+V2RQwM8XjlrK(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡆ")
	z3r2yNQqDC9EBj6 = MpJ8GOKoic(u"ࠬࠦࠨࠨࡇ")+TVPU926hld(llVTJXsoa2exp86CtQFDy)+ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࠠ࠮ࠢࠪࡈ")+str(eXK2uMqE3lAP1kW5B)+WCPwmyVsb62KRlo(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡉ")
	mSO9iEG348ao = QYSAUI5r46yil8cfaO(u"ࠨࠢࠫࠫࡊ")+TVPU926hld(krapxHRchdLTIjlbzP9U0SyOwKV)+cpHxZyU7vTtqmIw(u"ࠩࠣ࠱ࠥ࠭ࡋ")+str(UP6qbrX5Gviag)+MpJ8GOKoic(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡌ")
	giuXKqNSk3js = V2RQwM8XjlrK(u"ࠫࠥ࠮ࠧࡍ")+TVPU926hld(t8q3g2uNnp)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࠦ࠭ࠡࠩࡎ")+str(hB45OHxeSFEAn7vgpq)+wYTDlJC5vpOKynUEX3ge6W(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡏ")
	v0TjHlLZqkRxUCpmNwSy8AndO(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),xzA9sM3rG6IHd7jl8T+g7yJo2LVuqx1trPe(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡑ")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠷࠰࠹࠶अ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(YzowicIDTRusXZSU61(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),nMt0iueCy6K+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡓ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠹࠺࠻࠼आ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ynxXU3gaiQ9GPCftr1q(u"ࠫࡱ࡯࡮࡬ࠩࡔ"),xzA9sM3rG6IHd7jl8T+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࡕ")+Nlvjm0siXK7dDP,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"࠲࠲࠻࠵इ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(V2RQwM8XjlrK(u"࠭࡬ࡪࡰ࡮ࠫࡖ"),xzA9sM3rG6IHd7jl8T+jXWzIZcDva4ikEUfN(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪࡗ")+z3r2yNQqDC9EBj6,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠳࠳࠼࠷ई"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),xzA9sM3rG6IHd7jl8T+ITXLHQdeVC2icEOAU8hqG470afPB3(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอ࡙ࠩ")+mSO9iEG348ao,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"࠴࠴࠽࠹उ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠪࡰ࡮ࡴ࡫ࠨ࡚"),xzA9sM3rG6IHd7jl8T+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะ࡛ࠬ")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"࠵࠵࠾࠴ऊ"))
	return
def OIaDg139Yk2jJMeLixFps6rWvzwlAV():
	gCN1aspLSldwZWHBoV0,W4QKNJrloXExp3ha9bUms = ooFhg4P73OKBtD0a8GRWecv(KHWjqGglbCtBvS)
	llVTJXsoa2exp86CtQFDy,eXK2uMqE3lAP1kW5B = ooFhg4P73OKBtD0a8GRWecv(gWyBObvHL4V)
	krapxHRchdLTIjlbzP9U0SyOwKV,UP6qbrX5Gviag = ooFhg4P73OKBtD0a8GRWecv(NehEdgfU5W)
	t8q3g2uNnp,hB45OHxeSFEAn7vgpq = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(KKx9waqGFuyfT)
	t8q3g2uNnp -= ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠸࠼࠸࠷࠶ऋ")
	hB45OHxeSFEAn7vgpq -= pwxH3oREFm5v98BCZ1QVtzMJOc
	jDCuyJxcOvUi85NX3g = str(CR3aLOVKSIme5XFoYi6M.listdir(UrJ5GQheX9YF2uMzcykWZPNt))
	SSL7ncKFOTCYi8G = jDCuyJxcOvUi85NX3g.count(cpHxZyU7vTtqmIw(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧ࡜"))+jDCuyJxcOvUi85NX3g.count(WXuJd8nz2spo146t(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭࡝"))
	Nlvjm0siXK7dDP = ynxXU3gaiQ9GPCftr1q(u"ࠧࠡࠪࠪ࡞")+TVPU926hld(gCN1aspLSldwZWHBoV0)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࠢ࠰ࠤࠬ࡟")+str(W4QKNJrloXExp3ha9bUms)+YzowicIDTRusXZSU61(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡠ")
	z3r2yNQqDC9EBj6 = ESXZrtnCfcDJGo01vFg(u"ࠪࠤ࠭࠭ࡡ")+TVPU926hld(llVTJXsoa2exp86CtQFDy)+MpJ8GOKoic(u"ࠫࠥ࠳ࠠࠨࡢ")+str(eXK2uMqE3lAP1kW5B)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡣ")
	mSO9iEG348ao = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࠠࠩࠩࡤ")+TVPU926hld(krapxHRchdLTIjlbzP9U0SyOwKV)+XCYALgFs2O3hZdpHrlMmB(u"ࠧࠡ࠯ࠣࠫࡥ")+str(UP6qbrX5Gviag)+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡦ")
	giuXKqNSk3js = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࠣࠬࠬࡧ")+TVPU926hld(t8q3g2uNnp)+WCPwmyVsb62KRlo(u"ࠪ࠭ࠬࡨ")
	NNu0ebKfOsSD1CYV27xLzRZwFEoM = MzgKWUQ4V5H(u"ࠫࠥ࠮ࠧࡩ")+str(SSL7ncKFOTCYi8G)+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡪ")
	gGUbS0ZRTe6K = gCN1aspLSldwZWHBoV0+llVTJXsoa2exp86CtQFDy+krapxHRchdLTIjlbzP9U0SyOwKV+t8q3g2uNnp
	qqyTLbPBFOKAI70wt3U = W4QKNJrloXExp3ha9bUms+eXK2uMqE3lAP1kW5B+UP6qbrX5Gviag+hB45OHxeSFEAn7vgpq+SSL7ncKFOTCYi8G
	YWCso5NMKO = FGLEMi21Bfn(u"࠭ࠠࠩࠩ࡫")+TVPU926hld(gGUbS0ZRTe6K)+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࠡ࠯ࠣࠫ࡬")+str(qqyTLbPBFOKAI70wt3U)+WCPwmyVsb62KRlo(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࡭")
	v0TjHlLZqkRxUCpmNwSy8AndO(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡯࡭ࡳࡱࠧ࡮"),xzA9sM3rG6IHd7jl8T+ESXZrtnCfcDJGo01vFg(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࡯")+YWCso5NMKO,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"࠽࠴࠶ऌ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡱ࡯࡮࡬ࠩࡰ"),nMt0iueCy6K+ESXZrtnCfcDJGo01vFg(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡱ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠹࠺࠻࠼ऍ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(WsklGNp2CYzVQUag(u"࠭࡬ࡪࡰ࡮ࠫࡲ"),xzA9sM3rG6IHd7jl8T+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࡳ")+Nlvjm0siXK7dDP,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠸࠶࠴ऎ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(jXWzIZcDva4ikEUfN(u"ࠨ࡮࡬ࡲࡰ࠭ࡴ"),xzA9sM3rG6IHd7jl8T+wYTDlJC5vpOKynUEX3ge6W(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࡵ")+z3r2yNQqDC9EBj6,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠹࠷࠶ए"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡰ࡮ࡴ࡫ࠨࡶ"),xzA9sM3rG6IHd7jl8T+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࡷ")+mSO9iEG348ao,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"࠺࠸࠸ऐ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(WCPwmyVsb62KRlo(u"ࠬࡲࡩ࡯࡭ࠪࡸ"),xzA9sM3rG6IHd7jl8T+V2RQwM8XjlrK(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࡹ")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠻࠹࠺ऑ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧ࡭࡫ࡱ࡯ࠬࡺ"),xzA9sM3rG6IHd7jl8T+WCPwmyVsb62KRlo(u"ࠨ็ึั๋ࠥไโษอࠤฬ๊ใาษืࠤฬ๊ๅลไออࠬࡻ")+NNu0ebKfOsSD1CYV27xLzRZwFEoM,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"࠼࠺࠶ऒ"))
	return
def WtehuYQag2():
	kkcasqeQi87HjhC9noUIM2b1 = YOHXqtbQTBfKerIZ if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࠲ࠫࡼ") in Z7NtweOaCqhSgKuT1A5rip6sbP23 else eu1NswY9zkKC60I
	if not kkcasqeQi87HjhC9noUIM2b1:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡽ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮ࠡ็ฮ่ࠥษฬ่ิฬࠤศฮไ๊ࠡฦ๊ิื่๋ัࠣ์้๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์่ࠠาสࠤฬ๊ๆ้฻ࠪࡾ"))
		return
	s9sTYnbqIEHthVG3czOK1p8vxF = cad8TeSyMUYmfsEO0.getSetting(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩࡿ"))
	if not s9sTYnbqIEHthVG3czOK1p8vxF: ttqZMHN1kYWDQ2()
	gCN1aspLSldwZWHBoV0,W4QKNJrloXExp3ha9bUms = ooFhg4P73OKBtD0a8GRWecv(vW9UgGwp1q78baQeDrf)
	llVTJXsoa2exp86CtQFDy,eXK2uMqE3lAP1kW5B = ooFhg4P73OKBtD0a8GRWecv(FCecEw1DfM6ihJ)
	krapxHRchdLTIjlbzP9U0SyOwKV,UP6qbrX5Gviag = ooFhg4P73OKBtD0a8GRWecv(JCFnvZLtVSrk0P)
	t8q3g2uNnp,hB45OHxeSFEAn7vgpq = ooFhg4P73OKBtD0a8GRWecv(zzTvZLRtHWe4XOo)
	KZmhToW2qLf9sCAU5zHcb1rlBNpt,SSL7ncKFOTCYi8G = ooFhg4P73OKBtD0a8GRWecv(VWAkurxXEJRy5D9M)
	M5ywJeQzAVZBFuKsiRx3D4a0fXdYkL,sNy0EblPL5f = ooFhg4P73OKBtD0a8GRWecv(TTRwULfJbaQcDNs)
	Nlvjm0siXK7dDP = ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࠠࠩࠩࢀ")+TVPU926hld(gCN1aspLSldwZWHBoV0)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࠡ࠯ࠣࠫࢁ")+str(W4QKNJrloXExp3ha9bUms)+ynxXU3gaiQ9GPCftr1q(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	z3r2yNQqDC9EBj6 = FGLEMi21Bfn(u"ࠩࠣࠬࠬࢃ")+TVPU926hld(llVTJXsoa2exp86CtQFDy)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࠤ࠲ࠦࠧࢄ")+str(eXK2uMqE3lAP1kW5B)+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	mSO9iEG348ao = WCPwmyVsb62KRlo(u"ࠬࠦࠨࠨࢆ")+TVPU926hld(krapxHRchdLTIjlbzP9U0SyOwKV)+FGLEMi21Bfn(u"࠭ࠠ࠮ࠢࠪࢇ")+str(UP6qbrX5Gviag)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	giuXKqNSk3js = MpJ8GOKoic(u"ࠨࠢࠫࠫࢉ")+TVPU926hld(t8q3g2uNnp)+YzowicIDTRusXZSU61(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(hB45OHxeSFEAn7vgpq)+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	NNu0ebKfOsSD1CYV27xLzRZwFEoM = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࠥ࠮ࠧࢌ")+TVPU926hld(KZmhToW2qLf9sCAU5zHcb1rlBNpt)+pnkrd2S84FJfN73KuiCYv(u"ࠬࠦ࠭ࠡࠩࢍ")+str(SSL7ncKFOTCYi8G)+ESXZrtnCfcDJGo01vFg(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	pqOw3vPREUj1ifb492on5KBW = ynxXU3gaiQ9GPCftr1q(u"ࠧࠡࠪࠪ࢏")+TVPU926hld(M5ywJeQzAVZBFuKsiRx3D4a0fXdYkL)+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࠢ࠰ࠤࠬ࢐")+str(sNy0EblPL5f)+SSBkx0WbN1asnDCQV6tIj(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࢑")
	gGUbS0ZRTe6K = gCN1aspLSldwZWHBoV0+llVTJXsoa2exp86CtQFDy+krapxHRchdLTIjlbzP9U0SyOwKV+t8q3g2uNnp+KZmhToW2qLf9sCAU5zHcb1rlBNpt+M5ywJeQzAVZBFuKsiRx3D4a0fXdYkL
	qqyTLbPBFOKAI70wt3U = W4QKNJrloXExp3ha9bUms+eXK2uMqE3lAP1kW5B+UP6qbrX5Gviag+hB45OHxeSFEAn7vgpq+SSL7ncKFOTCYi8G+sNy0EblPL5f
	YWCso5NMKO = jXWzIZcDva4ikEUfN(u"ࠪࠤ࠭࠭࢒")+TVPU926hld(gGUbS0ZRTe6K)+g7yJo2LVuqx1trPe(u"ࠫࠥ࠳ࠠࠨ࢓")+str(qqyTLbPBFOKAI70wt3U)+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࢔")
	v0TjHlLZqkRxUCpmNwSy8AndO(BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),xzA9sM3rG6IHd7jl8T+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪ࢖"),Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠽࠵࠹ओ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),xzA9sM3rG6IHd7jl8T+FGLEMi21Bfn(u"่ࠩืาࠦวๅฮ่๎฾࠭࢘")+YWCso5NMKO,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠷࠶࠹औ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(XCYALgFs2O3hZdpHrlMmB(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),nMt0iueCy6K+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࢚ࠢࠪ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠺࠻࠼࠽क"))
	v0TjHlLZqkRxUCpmNwSy8AndO(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),xzA9sM3rG6IHd7jl8T+XCYALgFs2O3hZdpHrlMmB(u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭࢜")+Nlvjm0siXK7dDP,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"࠹࠸࠵ख"))
	v0TjHlLZqkRxUCpmNwSy8AndO(Nlyfx1HnzOWCovke5(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),xzA9sM3rG6IHd7jl8T+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬ࢞")+z3r2yNQqDC9EBj6,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠺࠹࠷ग"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),xzA9sM3rG6IHd7jl8T+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪࢠ")+mSO9iEG348ao,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠻࠺࠹घ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(jXWzIZcDva4ikEUfN(u"ࠫࡱ࡯࡮࡬ࠩࢡ"),xzA9sM3rG6IHd7jl8T+MpJ8GOKoic(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨࢢ")+giuXKqNSk3js,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"࠼࠻࠴ङ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(YzowicIDTRusXZSU61(u"࠭࡬ࡪࡰ࡮ࠫࢣ"),xzA9sM3rG6IHd7jl8T+WXuJd8nz2spo146t(u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧࢤ")+NNu0ebKfOsSD1CYV27xLzRZwFEoM,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"࠽࠵࠶च"))
	v0TjHlLZqkRxUCpmNwSy8AndO(V2RQwM8XjlrK(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),xzA9sM3rG6IHd7jl8T+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩࢦ")+pqOw3vPREUj1ifb492on5KBW,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠷࠶࠸छ"))
	return
def OjA0BF1uQJ3YxPZvbirIn(showDialogs):
	if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࢧ"),WXuJd8nz2spo146t(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢨ"))
	eAVb9j48rtIzkDJBCoM7dfNPqs,cDT5zduEyA2fFZ87empjYW6l4JPK0t = [],ufmXvxgoHGDwZtjsLkR05i
	for II47El3LywZWjh,vvqj1arwXtdLgTenQ379ZhybMzA4DO,i2jwG4Ex1VL0MPSW8h9A in CR3aLOVKSIme5XFoYi6M.walk(dQxGp0knIfj,topdown=eu1NswY9zkKC60I):
		oJQ85cHziLGf3uVD9q1whPTjKS = len(i2jwG4Ex1VL0MPSW8h9A)
		if oJQ85cHziLGf3uVD9q1whPTjKS>jXWzIZcDva4ikEUfN(u"࠶࠲࠳ज"): eAVb9j48rtIzkDJBCoM7dfNPqs.append(vvqj1arwXtdLgTenQ379ZhybMzA4DO)
		cDT5zduEyA2fFZ87empjYW6l4JPK0t += oJQ85cHziLGf3uVD9q1whPTjKS
	wzmfYZdRgBWDHKyja43nFrts2b81iG = cDT5zduEyA2fFZ87empjYW6l4JPK0t>ESXZrtnCfcDJGo01vFg(u"࠷࠳࠴࠵झ")
	if showDialogs:
		count = nMt0iueCy6K+ogJClMiqPa4A0NUtTxpDVybEWG(u"๊ࠬฯ๋ๅࠣࠤࠬࢩ")+str(cDT5zduEyA2fFZ87empjYW6l4JPK0t)+SSBkx0WbN1asnDCQV6tIj(u"࠭ࠠࠡื๋ีฮ࠭ࢪ")+ZZoLlKyInXc08j2pTGJ
		if not eAVb9j48rtIzkDJBCoM7dfNPqs and not wzmfYZdRgBWDHKyja43nFrts2b81iG: W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࢫ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠨๆสࠤ๏๎ฬะࠢ฼๊ิ้ࠠึ๊ิࠤ่ะวษหࠣ็ะ๐ัสࠢ࠱࠲ࠥ๎ไ่าสࠤ้อࠠหฯอหัࠦร็ࠢอุ้ำࠠึ๊ิࠤฬ๊ใหษหอࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢬ")+count)
		else: W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢭ"),ynxXU3gaiQ9GPCftr1q(u"่ࠪิ๐ใࠡื๋ี้ࠥสศสฬࠤ่ั๊าหࠣ࠲࠳่่ࠦาสࠤ็ี๋ࠠีหฬ๋ࠥิศๅ็ࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦศา่ส้ัูࠦๆษาࠤ࠳࠴ࠠฤ่อࠤอำวอหࠣษ้๏ࠠๆีะࠤ์ึ็ࠡษ็ูํืࠠ࠯࠰๋้ࠣࠦสา์าࠤู๊อࠡื๋ีࠥอไไฬสฬฮࠦวๅฤ้ࠤฤࠧࠠ࡝ࡰ࡟ࡲࠬࢮ")+count)
	else: W8j2OheqsroDJIYzRupt6nG = pwxH3oREFm5v98BCZ1QVtzMJOc
	if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
		if wzmfYZdRgBWDHKyja43nFrts2b81iG: Agz62xbajVk15PieF4utWsGmBC(II47El3LywZWjh,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
		elif eAVb9j48rtIzkDJBCoM7dfNPqs:
			for vvqj1arwXtdLgTenQ379ZhybMzA4DO in eAVb9j48rtIzkDJBCoM7dfNPqs: Agz62xbajVk15PieF4utWsGmBC(vvqj1arwXtdLgTenQ379ZhybMzA4DO,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	return
def ttqZMHN1kYWDQ2():
	oecU0R2PC4WmyTdHFk13xAph = eu1NswY9zkKC60I
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢯ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࢰ"))
	if W8j2OheqsroDJIYzRupt6nG==-jXWzIZcDva4ikEUfN(u"࠴ञ"): return
	if W8j2OheqsroDJIYzRupt6nG:
		import subprocess as cQyEz2gYlPhfT7xbXSK8M1rA
		try:
			cQyEz2gYlPhfT7xbXSK8M1rA.Popen(g7yJo2LVuqx1trPe(u"࠭ࡳࡶࠩࢱ"))
			oecU0R2PC4WmyTdHFk13xAph = YOHXqtbQTBfKerIZ
		except: pass
		if oecU0R2PC4WmyTdHFk13xAph:
			DD8ELWmzo3hB0su = vW9UgGwp1q78baQeDrf+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+FCecEw1DfM6ihJ+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+JCFnvZLtVSrk0P+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+zzTvZLRtHWe4XOo+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+VWAkurxXEJRy5D9M+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+TTRwULfJbaQcDNs
			ypNCs530xDBrnI1WaZd8vb9Vm = cQyEz2gYlPhfT7xbXSK8M1rA.Popen(ynxXU3gaiQ9GPCftr1q(u"ࠧࡴࡷࠣ࠱ࡨࠦࠢࡤࡪࡰࡳࡩࠦ࠭ࡓࠢ࠳࠻࠼࠽ࠠࠨࢲ")+DD8ELWmzo3hB0su+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࠤࠪࢳ"),shell=YOHXqtbQTBfKerIZ,stdin=cQyEz2gYlPhfT7xbXSK8M1rA.PIPE,stdout=cQyEz2gYlPhfT7xbXSK8M1rA.PIPE,stderr=cQyEz2gYlPhfT7xbXSK8M1rA.PIPE)
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢴ"),EM6qpnCBYQGA9kbgDVLfrP(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࢵ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢶ"),QYSAUI5r46yil8cfaO(u"ࠬ฿ๅๅ์ฬࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤฯำสศฮࠣฬึ์วๆฮࠣࠤࡷࡵ࡯ࡵࠢࠣวํࠦࠠࡴࡷࡳࡩࡷࡻࡳࡦࡴࠣࠤศ๎ࠠࠡࡵࡸࠤࠥ๎ฬ่ษี็๊ࠥวࠡ์๋ะิࠦแ๋้๋ࠣีอࠠศๆหี๋อๅอࠢ࠱࠲ࠥษ่ࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠬࢷ"))
	return oecU0R2PC4WmyTdHFk13xAph
def TVPU926hld(gGUbS0ZRTe6K):
	for M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa in [ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡂࠨࢸ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡌࡄࠪࢹ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡏࡅࠫࢺ"),ynxXU3gaiQ9GPCftr1q(u"ࠩࡊࡆࠬࢻ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡘࡇ࠭ࢼ")]:
		if gGUbS0ZRTe6K<wAU9jKvmTM0(u"࠵࠵࠸࠴ट"): break
		else: gGUbS0ZRTe6K /= ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠶࠶࠲࠵࠰࠳ठ")
	YWCso5NMKO = WXuJd8nz2spo146t(u"ࠦࠪ࠹࠮࠲ࡨࠣࠩࡸࠨࢽ")%(gGUbS0ZRTe6K,M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa)
	return YWCso5NMKO
def ooFhg4P73OKBtD0a8GRWecv(yxjzsdfUAQ4Y3I=YzowicIDTRusXZSU61(u"ࠬ࠴ࠧࢾ")):
	global Gr4vc5SknFjlZhoEuQy8bdfBXe,KxVR13dtIfrFGOJaHZm
	Gr4vc5SknFjlZhoEuQy8bdfBXe,KxVR13dtIfrFGOJaHZm = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
	def zPJQBVkvAECtZbaiuc3T(yxjzsdfUAQ4Y3I):
		global Gr4vc5SknFjlZhoEuQy8bdfBXe,KxVR13dtIfrFGOJaHZm
		if CR3aLOVKSIme5XFoYi6M.path.exists(yxjzsdfUAQ4Y3I):
			if ufmXvxgoHGDwZtjsLkR05i and WsklGNp2CYzVQUag(u"࠭ࡳࡤࡣࡱࡨ࡮ࡸࠧࢿ") in dir(CR3aLOVKSIme5XFoYi6M):
				for IcPTE5yNx1lXzU6SVCmgFHQ3p7soM in CR3aLOVKSIme5XFoYi6M.scandir(yxjzsdfUAQ4Y3I):
					if IcPTE5yNx1lXzU6SVCmgFHQ3p7soM.is_dir(follow_symlinks=eu1NswY9zkKC60I):
						zPJQBVkvAECtZbaiuc3T(IcPTE5yNx1lXzU6SVCmgFHQ3p7soM.path)
					elif IcPTE5yNx1lXzU6SVCmgFHQ3p7soM.is_file(follow_symlinks=eu1NswY9zkKC60I):
						Gr4vc5SknFjlZhoEuQy8bdfBXe += IcPTE5yNx1lXzU6SVCmgFHQ3p7soM.stat().st_size
						KxVR13dtIfrFGOJaHZm += pwxH3oREFm5v98BCZ1QVtzMJOc
			else:
				for IcPTE5yNx1lXzU6SVCmgFHQ3p7soM in CR3aLOVKSIme5XFoYi6M.listdir(yxjzsdfUAQ4Y3I):
					LLuDiZBH5QCGSRJ = CR3aLOVKSIme5XFoYi6M.path.abspath(CR3aLOVKSIme5XFoYi6M.path.join(yxjzsdfUAQ4Y3I,IcPTE5yNx1lXzU6SVCmgFHQ3p7soM))
					if CR3aLOVKSIme5XFoYi6M.path.isdir(LLuDiZBH5QCGSRJ):
						zPJQBVkvAECtZbaiuc3T(LLuDiZBH5QCGSRJ)
					elif CR3aLOVKSIme5XFoYi6M.path.isfile(LLuDiZBH5QCGSRJ):
						gGUbS0ZRTe6K,qqyTLbPBFOKAI70wt3U = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(LLuDiZBH5QCGSRJ)
						Gr4vc5SknFjlZhoEuQy8bdfBXe += gGUbS0ZRTe6K
						KxVR13dtIfrFGOJaHZm += qqyTLbPBFOKAI70wt3U
		return
	try: zPJQBVkvAECtZbaiuc3T(yxjzsdfUAQ4Y3I)
	except: pass
	return Gr4vc5SknFjlZhoEuQy8bdfBXe,KxVR13dtIfrFGOJaHZm
def sI9u6e2BAiDM(showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣀ"),nMt0iueCy6K+MzgKWUQ4V5H(u"ࠨ้็ࠤฯื๊ะ่ࠢืา࠭ࣁ")+ixrPWKeFMnqJyVodX6D9AaO2+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠡ࠰࠱ࠤํ๋ไโษอࠤฬ๊ใาษืࠫࣂ")+ixrPWKeFMnqJyVodX6D9AaO2+FGLEMi21Bfn(u"ࠪรࠦࠧࠧࣃ")+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return
	XXITNA4G2vCOeoQ = Agz62xbajVk15PieF4utWsGmBC(KHWjqGglbCtBvS,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
	OGQq7FP0yKkgAjzw94B2MEu = Agz62xbajVk15PieF4utWsGmBC(gWyBObvHL4V,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
	Gkc53P6pRafYyXZi9wqDUC = Agz62xbajVk15PieF4utWsGmBC(NehEdgfU5W,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	TpXtFOezxHidQqKj4gCcR = JvSlQGoR4F6im8jh5OxKeDsI1H2BX9(eu1NswY9zkKC60I)
	AD3JiK5OfWR4NUYH = SS5Tzfq7Xmp8hRnOY0(eu1NswY9zkKC60I)
	succeeded = all([XXITNA4G2vCOeoQ,OGQq7FP0yKkgAjzw94B2MEu,Gkc53P6pRafYyXZi9wqDUC,TpXtFOezxHidQqKj4gCcR,AD3JiK5OfWR4NUYH])
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),cpHxZyU7vTtqmIw(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࣆ"),WXuJd8nz2spo146t(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩࣇ"))
	return succeeded
def uo1DHY3xfcCqRB8h(showDialogs):
	if showDialogs:
		DD8ELWmzo3hB0su = vW9UgGwp1q78baQeDrf+ixrPWKeFMnqJyVodX6D9AaO2+FCecEw1DfM6ihJ+ixrPWKeFMnqJyVodX6D9AaO2+JCFnvZLtVSrk0P+ixrPWKeFMnqJyVodX6D9AaO2+zzTvZLRtHWe4XOo+ixrPWKeFMnqJyVodX6D9AaO2+VWAkurxXEJRy5D9M+ixrPWKeFMnqJyVodX6D9AaO2+TTRwULfJbaQcDNs
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࣈ"),nMt0iueCy6K+WCPwmyVsb62KRlo(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢส่ฯ๐ࠠโ์๋ࠣีํࠠศๆ่ะ้ีวห࡞ࡱࡠࡳ࠭ࣉ")+DD8ELWmzo3hB0su+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return
	XXITNA4G2vCOeoQ = Agz62xbajVk15PieF4utWsGmBC(vW9UgGwp1q78baQeDrf,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	OGQq7FP0yKkgAjzw94B2MEu = Agz62xbajVk15PieF4utWsGmBC(FCecEw1DfM6ihJ,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	Gkc53P6pRafYyXZi9wqDUC = Agz62xbajVk15PieF4utWsGmBC(JCFnvZLtVSrk0P,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	TpXtFOezxHidQqKj4gCcR = Agz62xbajVk15PieF4utWsGmBC(zzTvZLRtHWe4XOo,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	AD3JiK5OfWR4NUYH = Agz62xbajVk15PieF4utWsGmBC(VWAkurxXEJRy5D9M,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	gJUeCn4ZFO1y5kdG6qB9WYSMRu = Agz62xbajVk15PieF4utWsGmBC(TTRwULfJbaQcDNs,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	succeeded = all([XXITNA4G2vCOeoQ,OGQq7FP0yKkgAjzw94B2MEu,Gkc53P6pRafYyXZi9wqDUC,TpXtFOezxHidQqKj4gCcR,AD3JiK5OfWR4NUYH,gJUeCn4ZFO1y5kdG6qB9WYSMRu])
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࣊"),WsklGNp2CYzVQUag(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ࣋"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣌"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨ࣍"))
	return succeeded
def JvSlQGoR4F6im8jh5OxKeDsI1H2BX9(showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࣎"),nMt0iueCy6K+wAU9jKvmTM0(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤ࣏ࠫ")+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=WXuJd8nz2spo146t(u"࠷ड"): return MzgKWUQ4V5H(u"ࡆࡢ࡮ࡶࡩढ")
	try:
		succeeded = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࡕࡴࡸࡩण")
		bIsz45VatWSMRmkyph63Zg1lf = U4xLTJsWfkMbNpicjY9SVOwAthED.connect(KKx9waqGFuyfT)
		bIsz45VatWSMRmkyph63Zg1lf.text_factory = str
		C9frwiYhylNH2n14uDaG5 = bIsz45VatWSMRmkyph63Zg1lf.cursor()
		C9frwiYhylNH2n14uDaG5.execute(cpHxZyU7vTtqmIw(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࣐࠭"))
		C9frwiYhylNH2n14uDaG5.execute(NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨ࣑"))
		C9frwiYhylNH2n14uDaG5.execute(ynxXU3gaiQ9GPCftr1q(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾࣒ࠫ"))
		bIsz45VatWSMRmkyph63Zg1lf.commit()
		C9frwiYhylNH2n14uDaG5.execute(XCYALgFs2O3hZdpHrlMmB(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࣓࠭"))
		bIsz45VatWSMRmkyph63Zg1lf.close()
	except: succeeded = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࡈࡤࡰࡸ࡫त")
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࣔ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣕ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࣖ"),MpJ8GOKoic(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣗ"))
	return succeeded
def SS5Tzfq7Xmp8hRnOY0(showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࣘ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๊๊ࠫแศฬࠣห้้ัศึ๋ࠣ๏ࠦๅๅใสฮࠥ๐ี็฻๊ห้่ࠥะ์ࠣ฽๋ีๅศࠢํ฾้่ࠠ็ใึ๋ࠥฮี้ำฬࠤ๊็วอลฬࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅๅใสฮࠥ๐อหษฯ๋ฬࠦๅษำ่ะ๏ࠦใ้ัํࠤาะ้ࠡ์฼ีๆ๎ๆࠡ็้๋ฬࠦใ๋ใࠣัิัสࠡษ็ู้้ไสࠩࣙ")+ixrPWKeFMnqJyVodX6D9AaO2+ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+XCYALgFs2O3hZdpHrlMmB(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠢส่่ืวีࠢส่๊สโหหࠣรࠦࠧࠧࣚ")+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return ynxXU3gaiQ9GPCftr1q(u"ࡉࡥࡱࡹࡥथ")
	succeeded = wYTDlJC5vpOKynUEX3ge6W(u"ࡘࡷࡻࡥद")
	for file in CR3aLOVKSIme5XFoYi6M.listdir(UrJ5GQheX9YF2uMzcykWZPNt):
		if ynxXU3gaiQ9GPCftr1q(u"࠭࡫ࡰࡦ࡬ࡣࡸࡺࡡࡤ࡭ࡷࡶࡦࡩࡥࠨࣛ") not in file and MzgKWUQ4V5H(u"ࠧ࡬ࡱࡧ࡭ࡤࡩࡲࡢࡵ࡫ࡰࡴ࡭ࠧࣜ") not in file: continue
		NMGgy2Ojlwu1nVxK = CR3aLOVKSIme5XFoYi6M.path.join(UrJ5GQheX9YF2uMzcykWZPNt,file)
		try: CR3aLOVKSIme5XFoYi6M.remove(NMGgy2Ojlwu1nVxK)
		except Exception as MhfeRPFkU07j5ogmqbsYcCS:
			succeeded = Nlyfx1HnzOWCovke5(u"ࡋࡧ࡬ࡴࡧध")
			if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࣝ"),str(MhfeRPFkU07j5ogmqbsYcCS))
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࣞ"),YzowicIDTRusXZSU61(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫࣟ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࣠"),SSBkx0WbN1asnDCQV6tIj(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡษ็ุ้ำࠧ࣡"))
	return succeeded
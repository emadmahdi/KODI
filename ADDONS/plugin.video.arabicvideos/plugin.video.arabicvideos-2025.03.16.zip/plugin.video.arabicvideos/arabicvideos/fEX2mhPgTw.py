# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ALMSTBA'
xzA9sM3rG6IHd7jl8T = '_MST_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['الرئيسية','يلا شوت']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==860: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==861: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==862: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==863: w8YsNWfQ5gFluRvOmSd4Cb96H = QgxPohjR8trYI(url,text)
	elif mode==869: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,869,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"primary-links"(.*?)</u',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,861)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"list-categories"(.*?)<script',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.lstrip('/')
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,861)
	return
def txsXO7gSMnrwAh6NmJ9D(url,N5RUprZIYG6ekHh=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"home-content"(.*?)"footer"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('"overlay"','"duration"><')
		items = RSuYINdeamsK0t.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		GEzxBN8rAh1d = []
		for afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(' ')
			title = Uo7Tbc29Eu(title)
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة).\d+',title,RSuYINdeamsK0t.DOTALL)
			if 'episodes' not in N5RUprZIYG6ekHh and AWjJSatwokZ:
				title = '_MOD_' + AWjJSatwokZ[0][0]
				title = title.replace('اون لاين',Vk54F7GcROfCy6HunEI)
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,863,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,862,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''["']pagination["'](.*?)["']footer["']''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		N5RUprZIYG6ekHh = 'episodes_pages' if 'episodes' in N5RUprZIYG6ekHh else 'pages'
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,861,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,N5RUprZIYG6ekHh)
	else:
		xYvb8nulJPMe10jIrt6yVRfKWNLC = RSuYINdeamsK0t.findall('class="pagination__next.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if xYvb8nulJPMe10jIrt6yVRfKWNLC:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = xYvb8nulJPMe10jIrt6yVRfKWNLC[0]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة لاحقة',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,861,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,N5RUprZIYG6ekHh)
	return
def QgxPohjR8trYI(url,KBe7D36amSnG9WZf5dCUPQhOz):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-EPISODES_SEASONS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"episodes-container"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	ylKTDSkdQmUChwbX45ALeiu = RSuYINdeamsK0t.findall('"thumbnailUrl":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	afR4xElWyzgcNAUnKXBempC = ylKTDSkdQmUChwbX45ALeiu[0] if ylKTDSkdQmUChwbX45ALeiu else Vk54F7GcROfCy6HunEI
	afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
	afR4xElWyzgcNAUnKXBempC += '|Referer='+FFLhlYUAsfJBXeQmRpzD7c14ZP6
	items = []
	JSDICxLuO7GWz9fRlBMiAY8eZq3 = False
	if WvDVRHAc37CGulIhPagimorZSy0x and not KBe7D36amSnG9WZf5dCUPQhOz:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('data-tab="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for KBe7D36amSnG9WZf5dCUPQhOz,title in items:
			KBe7D36amSnG9WZf5dCUPQhOz = KBe7D36amSnG9WZf5dCUPQhOz.strip('#')
			if len(items)>1: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,863,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,KBe7D36amSnG9WZf5dCUPQhOz)
			else: JSDICxLuO7GWz9fRlBMiAY8eZq3 = True
	else: JSDICxLuO7GWz9fRlBMiAY8eZq3 = True
	if JSDICxLuO7GWz9fRlBMiAY8eZq3 or not KBe7D36amSnG9WZf5dCUPQhOz:
		if not KBe7D36amSnG9WZf5dCUPQhOz: QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"tab-content.*?id="(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		else: QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"tab-content.*?id="'+KBe7D36amSnG9WZf5dCUPQhOz+'"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if QQHXiFSA0jUsklmxbpaMztu:
			UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('./')
				title = title.replace('</em><span>',otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,862,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	MMJL8QqY6T7dv1onu,FMpUSlAmskvgKEZ = [],[]
	hj50MJnoOp6ZWaS1IQ8Elr = url.strip('/')+'/?do=watch'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('iframe src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		FMpUSlAmskvgKEZ.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-PLAY-2nd')
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		YBDKFZOGfyCHLPA1EaUz9MJ = RSuYINdeamsK0t.findall('iframe src="(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		YBDKFZOGfyCHLPA1EaUz9MJ = YBDKFZOGfyCHLPA1EaUz9MJ[0] if YBDKFZOGfyCHLPA1EaUz9MJ else ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		YBDKFZOGfyCHLPA1EaUz9MJ = Uo7Tbc29Eu(YBDKFZOGfyCHLPA1EaUz9MJ)
		if YBDKFZOGfyCHLPA1EaUz9MJ not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(YBDKFZOGfyCHLPA1EaUz9MJ)
			oOv4sVqEAmyM = RRav1Sf7Px(YBDKFZOGfyCHLPA1EaUz9MJ,'name')
			YBDKFZOGfyCHLPA1EaUz9MJ = YBDKFZOGfyCHLPA1EaUz9MJ+'?named='+oOv4sVqEAmyM+'__embed'
			MMJL8QqY6T7dv1onu.append(YBDKFZOGfyCHLPA1EaUz9MJ)
	headers = {'Referer':url}
	X9PVULyJeCSviHfhmj0Gku6tgZz2 = RSuYINdeamsK0t.findall('post_id:(\d+)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hhx2oaz4LgH5W = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/wp-admin/admin-ajax.php?action=video_info&post_id='+X9PVULyJeCSviHfhmj0Gku6tgZz2[0]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hhx2oaz4LgH5W,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMSTBA-PLAY-3rd')
	nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"src":"(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('\/','/')
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+oOv4sVqEAmyM+'__watch'
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"Download" target="_blank" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+oOv4sVqEAmyM+'__download'
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
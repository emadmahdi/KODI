# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ARABSEED'
headers = {'User-Agent':p3QOAkrEuys81JqHobh()}
xzA9sM3rG6IHd7jl8T = '_ARS_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==250: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==251: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==252: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==253: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==254: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'CATEGORIES___'+text)
	elif mode==255: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'FILTERS___'+text)
	elif mode==256: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url,text)
	elif mode==259: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/main',Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,259,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/اخرى',254)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/اخرى',255)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/main',251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured_main')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'جديد الأفلام',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/main',251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'new_movies')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'جديد الحلقات',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/main',251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'new_episodes')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المضاف حديثاً',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/latest',251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'lastest')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('class="MenuHeader"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	v8e07ENZbVzIjaMSQPAxLUyuKcWho = QQHXiFSA0jUsklmxbpaMztu[0]
	C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in C7SvpZQLjOwh9m0goVbzXadR5:
		title = Uo7Tbc29Eu(title)
		if title not in wXPtB6I0QKLTyD932sl5d and title!=Vk54F7GcROfCy6HunEI:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,256)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def kAuPp3tC2FhGEb8m6DjMZVi(url,type):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'class="SliderInSection' in FjwObZSWkg8ahBdiQf9IeY135DpXoP: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الأكثر مشاهدة',url,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'most')
	if 'class="MainSlides' in FjwObZSWkg8ahBdiQf9IeY135DpXoP: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',url,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	if 'class="LinksList' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="LinksList(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			if len(Ry3L7fdNGh)>1 and type=='new_episodes': UwcYSVZbdK3rI = Ry3L7fdNGh[1]
			items = RSuYINdeamsK0t.findall('href="(.*?)"(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				esUNcDaPg3QoX = RSuYINdeamsK0t.findall('</i>(.*?)<span>(.*?)<',title,RSuYINdeamsK0t.DOTALL)
				try: TT7ytNUaAEzleV2oMR9j3 = esUNcDaPg3QoX[0][0].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				except: TT7ytNUaAEzleV2oMR9j3 = Vk54F7GcROfCy6HunEI
				try: OBuSrz9n5ARhJXN = esUNcDaPg3QoX[0][1].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				except: OBuSrz9n5ARhJXN = Vk54F7GcROfCy6HunEI
				esUNcDaPg3QoX = TT7ytNUaAEzleV2oMR9j3+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+OBuSrz9n5ARhJXN
				if '<strong>' in title:
					mhOxHeVaSc1B2PX = RSuYINdeamsK0t.findall('</i>(.*?)<',title,RSuYINdeamsK0t.DOTALL)
					if mhOxHeVaSc1B2PX: esUNcDaPg3QoX = mhOxHeVaSc1B2PX[0]
				if not esUNcDaPg3QoX:
					mhOxHeVaSc1B2PX = RSuYINdeamsK0t.findall('alt="(.*?)"',title,RSuYINdeamsK0t.DOTALL)
					if mhOxHeVaSc1B2PX: esUNcDaPg3QoX = mhOxHeVaSc1B2PX[0]
				if esUNcDaPg3QoX:
					if 'key=' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: type = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('key=')[1]
					else: type = 'newest'
					esUNcDaPg3QoX = esUNcDaPg3QoX.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
	return
def txsXO7gSMnrwAh6NmJ9D(url,type):
	n36U48jsVv,data,items = 'GET',Vk54F7GcROfCy6HunEI,[]
	if type=='filters':
		if '?' in url:
			ufRbcL6KC5t,zWochUpvu80mn5 = 'POST',{}
			hj50MJnoOp6ZWaS1IQ8Elr,FQAU5IsVfYLyoc7Da0J9veNidHGTw = url.split('?')
			nsiJk9RY6DLarMI = FQAU5IsVfYLyoc7Da0J9veNidHGTw.split('&')
			for bBpKQ53S0agq6lRw1 in nsiJk9RY6DLarMI:
				key,value = bBpKQ53S0agq6lRw1.split('=')
				zWochUpvu80mn5[key] = value
			if nsiJk9RY6DLarMI: n36U48jsVv,url,data = ufRbcL6KC5t,hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,n36U48jsVv,url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if type=='filters': Ry3L7fdNGh = [FjwObZSWkg8ahBdiQf9IeY135DpXoP]
	elif 'featured' in type: Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="MainSlides(.*?)class="LinksList',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	elif type=='new_movies': Ry3L7fdNGh = RSuYINdeamsK0t.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	elif type=='new_episodes': Ry3L7fdNGh = RSuYINdeamsK0t.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	elif type=='most': Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="SliderInSection(.*?)class="LinksList',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else: Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="Blocks-UL"(.*?)class="AboElSeed"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if 'featured' in type:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		b3txToPMSn9vs = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if b3txToPMSn9vs:
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,nWcb8JC7zEVouFjx9fILGh1vSQ,QWTGp4HPhD9vmfoncj26Jqwb5,UmRYTiht1H8oqzwKr = zip(*b3txToPMSn9vs)
			items = zip(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,UmRYTiht1H8oqzwKr,nWcb8JC7zEVouFjx9fILGh1vSQ)
	else:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if 'WWE' in title: continue
		title = Uo7Tbc29Eu(title)
		if 'الحلقة' in title:
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
			if AWjJSatwokZ:
				title = '_MOD_' + AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					GEzxBN8rAh1d.append(title)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,253,afR4xElWyzgcNAUnKXBempC)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,252,afR4xElWyzgcNAUnKXBempC)
		elif '/selary/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or 'مسلسل' in title:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,253,afR4xElWyzgcNAUnKXBempC)
		else:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,252,afR4xElWyzgcNAUnKXBempC)
	if type in ['newest','best','most']:
		items = RSuYINdeamsK0t.findall('page-numbers" href="(.*?)">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Uo7Tbc29Eu(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			title = Uo7Tbc29Eu(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP[10000:]
	items = RSuYINdeamsK0t.findall('data-src="(.*?)".*?alt="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not items: return
	afR4xElWyzgcNAUnKXBempC,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="ContainerEpisodesList"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<em>(.*?)</em>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,AWjJSatwokZ in items:
			title = name+' - الحلقة رقم '+AWjJSatwokZ
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,252,afR4xElWyzgcNAUnKXBempC)
	else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+'ملف التشغيل',url,252,afR4xElWyzgcNAUnKXBempC)
	return
def oQtNgsnMXGlU9vBiDqwL6Rm(title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	esUNcDaPg3QoX = RSuYINdeamsK0t.findall('[a-zA-Z-]+',title,RSuYINdeamsK0t.DOTALL)
	if esUNcDaPg3QoX: title = esUNcDaPg3QoX[0]
	else: title = title+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
	title = title.replace('عرب سيد',Vk54F7GcROfCy6HunEI).replace('مباشر',Vk54F7GcROfCy6HunEI).replace('مشاهدة',Vk54F7GcROfCy6HunEI)
	title = title.replace('ٍ',Vk54F7GcROfCy6HunEI)
	title = title.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	return title
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	hj50MJnoOp6ZWaS1IQ8Elr = Iy3PA1SVXNfjOchtgHC5kuJBG.url
	oOv4sVqEAmyM = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,'url')
	headers['Referer'] = oOv4sVqEAmyM+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	wYO9tk5xDT34dnl2MpyaEg,z8p7S5XrEHbKxLjk2BoYgPmhMGc,yI4qeVsUZlWivnrN6d1PuGSTckR = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	cJaHITKBuyFpoCgfAPXteVLvYS,H5HGzhOnkS,bU4MXeGwSfTpAgL8k0lYi = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	cBurna96FICv2N5Td = RSuYINdeamsK0t.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for fJFrAMYPDz,name,value in cBurna96FICv2N5Td:
		if 'w' in name: wYO9tk5xDT34dnl2MpyaEg,z8p7S5XrEHbKxLjk2BoYgPmhMGc,yI4qeVsUZlWivnrN6d1PuGSTckR = fJFrAMYPDz,name,value
		elif 'd' in name: cJaHITKBuyFpoCgfAPXteVLvYS,H5HGzhOnkS,bU4MXeGwSfTpAgL8k0lYi = fJFrAMYPDz,name,value
	if wYO9tk5xDT34dnl2MpyaEg:
		data = z8p7S5XrEHbKxLjk2BoYgPmhMGc+'='+yI4qeVsUZlWivnrN6d1PuGSTckR
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'POST',wYO9tk5xDT34dnl2MpyaEg,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-PLAY-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="WatcherArea(.*?</ul>)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = Ry3L7fdNGh[0]
			TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = TSLhPFdNlpHWc6AwCbxe9nJkqiEO0.replace('</ul>','<h3>')
			TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = TSLhPFdNlpHWc6AwCbxe9nJkqiEO0.replace('<h3>','<h3><h3>')
			DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('<h3>.*?(\d+)(.*?)<h3>',TSLhPFdNlpHWc6AwCbxe9nJkqiEO0,RSuYINdeamsK0t.DOTALL)
			if not DatFuedGb45zR1KqIWNk: DatFuedGb45zR1KqIWNk = [(Vk54F7GcROfCy6HunEI,TSLhPFdNlpHWc6AwCbxe9nJkqiEO0)]
			for jMiru3pGns,UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
				if jMiru3pGns: jMiru3pGns = '____'+jMiru3pGns
				items = RSuYINdeamsK0t.findall('data-link="(.*?)".*?<span>(.*?)</span>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
					if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch'+jMiru3pGns
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if HXhRgxEZ4d2Dek:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns = HXhRgxEZ4d2Dek[0]
			name = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
			if '%' in jMiru3pGns: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__embed__'
			else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__embed____'+jMiru3pGns
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if cJaHITKBuyFpoCgfAPXteVLvYS:
		data = H5HGzhOnkS+'='+bU4MXeGwSfTpAgL8k0lYi
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'POST',cJaHITKBuyFpoCgfAPXteVLvYS,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-PLAY-3rd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="DownloadArea(.*?)<script src=',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = Ry3L7fdNGh[0]
			DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('class="DownloadServers(.*?)</ul>',TSLhPFdNlpHWc6AwCbxe9nJkqiEO0,RSuYINdeamsK0t.DOTALL)
			for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
				items = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,jMiru3pGns in items:
					if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
					if 'reviewstation' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download____'+jMiru3pGns
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	wJAQRlgZUa970j2IoPs = str(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	bBwKX6xvjLkq = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in wJAQRlgZUa970j2IoPs for value in bBwKX6xvjLkq):
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search: search = p3bB2auMmSjXC0dE8FUfZ()
	if not search: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/find/?find='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='CATEGORIES':
		if z3ejatAUuRhOc5mWDlvs8[0]+'==' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = z3ejatAUuRhOc5mWDlvs8[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(z3ejatAUuRhOc5mWDlvs8[0:-1])):
			if z3ejatAUuRhOc5mWDlvs8[zHq7nBWJTNyY1I3aLco4AR]+'==' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = z3ejatAUuRhOc5mWDlvs8[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'==0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'==0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'//getposts??'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='FILTERS':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'//getposts??'+KMbV6CGYIuH
		xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',xIZTXEQJ7qtmF,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',xIZTXEQJ7qtmF,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'POST',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ARABSEED-FILTERS_MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	G1qPedU9g8SmNw4YycDV0Xj6FEI = RSuYINdeamsK0t.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	wHPdTXVIFsoKx6arg = RSuYINdeamsK0t.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	Ugep4NW1YS = G1qPedU9g8SmNw4YycDV0Xj6FEI+wHPdTXVIFsoKx6arg
	dict = {}
	for name,kuKGA8HpgN7PyjvxeLZ,UwcYSVZbdK3rI in Ugep4NW1YS:
		items = RSuYINdeamsK0t.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('data-rate="(.*?)".*?<em>(.*?)</em>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			items = []
			for CCPw5ZS83fxa7AXzQ9VvUIrNDbo,value in C7SvpZQLjOwh9m0goVbzXadR5: items.append([CCPw5ZS83fxa7AXzQ9VvUIrNDbo,Vk54F7GcROfCy6HunEI,value])
			kuKGA8HpgN7PyjvxeLZ = 'rate'
			name = 'التقييم'
		else: kuKGA8HpgN7PyjvxeLZ = items[0][1]
		if '==' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='CATEGORIES':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<=1:
				if kuKGA8HpgN7PyjvxeLZ==z3ejatAUuRhOc5mWDlvs8[-1]: txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'CATEGORIES___'+Ng1Jod47fp0S)
				return
			else:
				xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(hj50MJnoOp6ZWaS1IQ8Elr)
				if kuKGA8HpgN7PyjvxeLZ==z3ejatAUuRhOc5mWDlvs8[-1]: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',xIZTXEQJ7qtmF,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',hj50MJnoOp6ZWaS1IQ8Elr,254,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='FILTERS':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+kuKGA8HpgN7PyjvxeLZ+'==0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+kuKGA8HpgN7PyjvxeLZ+'==0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع :'+name,hj50MJnoOp6ZWaS1IQ8Elr,255,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for CCPw5ZS83fxa7AXzQ9VvUIrNDbo,x7ohwWJScUpRi1K50qs,value in items:
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			if 'الكل' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			CCPw5ZS83fxa7AXzQ9VvUIrNDbo = Uo7Tbc29Eu(CCPw5ZS83fxa7AXzQ9VvUIrNDbo)
			xxM1Ua3FDdE2Xl8TOzsVuqBWg,esUNcDaPg3QoX = CCPw5ZS83fxa7AXzQ9VvUIrNDbo,CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			esUNcDaPg3QoX = name+': '+xxM1Ua3FDdE2Xl8TOzsVuqBWg
			dict[kuKGA8HpgN7PyjvxeLZ][value] = esUNcDaPg3QoX
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+kuKGA8HpgN7PyjvxeLZ+'=='+xxM1Ua3FDdE2Xl8TOzsVuqBWg
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+kuKGA8HpgN7PyjvxeLZ+'=='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			if type=='FILTERS':
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,url,255,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='CATEGORIES' and z3ejatAUuRhOc5mWDlvs8[-2]+'==' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
				ynmiDuav5ICTeRsqj6Vb18Q = url+'//getposts??'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(ynmiDuav5ICTeRsqj6Vb18Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,xIZTXEQJ7qtmF,251,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,url,254,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
z3ejatAUuRhOc5mWDlvs8 = ['category','country','release-year']
iiVg3Lp5KB0m1FUXM7GlEY6QRsk9 = ['category','country','genre','release-year','language','quality','rate']
def LbJju0HKpiaENIe3xYo8AMkXBFVh(url):
	ffA52K9MiPUv6DmpRQNSW = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',ffA52K9MiPUv6DmpRQNSW)
	url = url.replace('/category/اخرى',Vk54F7GcROfCy6HunEI)
	if ffA52K9MiPUv6DmpRQNSW not in url: url = url+ffA52K9MiPUv6DmpRQNSW
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&&')
	og8wRH5eO04T3uylM,PpjxGzO7yqD0AXSJL1Mw = {},Vk54F7GcROfCy6HunEI
	if '==' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('==')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	for key in iiVg3Lp5KB0m1FUXM7GlEY6QRsk9:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&&'+key+'=='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&&'+key+'=='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&&')
	return PpjxGzO7yqD0AXSJL1Mw
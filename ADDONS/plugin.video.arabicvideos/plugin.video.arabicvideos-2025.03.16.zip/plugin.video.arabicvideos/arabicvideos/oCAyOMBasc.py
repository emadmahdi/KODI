# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'MYCIMA'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_MCM_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['مصارعة حرة','wwe']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==360: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==361: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==362: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==363: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,text)
	elif mode==364: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'CATEGORIES___'+text)
	elif mode==365: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'FILTERS___'+text)
	elif mode==366: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==369: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,url)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',FFLhlYUAsfJBXeQmRpzD7c14ZP6,369,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/AjaxCenter/RightBar',364)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/AjaxCenter/RightBar',365)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-MENU-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('class="menu-item.*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title==Vk54F7GcROfCy6HunEI: continue
			if any(value in title.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,366)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('hoverable activable(.*?)hoverable activable',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,366,afR4xElWyzgcNAUnKXBempC)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'class="Slider--Grid"' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',url,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="list--Tabsui"(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,361)
	return
def txsXO7gSMnrwAh6NmJ9D(kkb3logrYqHWCzLDGKduPpfQIv,type=Vk54F7GcROfCy6HunEI):
	if '::' in kkb3logrYqHWCzLDGKduPpfQIv:
		ynmiDuav5ICTeRsqj6Vb18Q,url = kkb3logrYqHWCzLDGKduPpfQIv.split('::')
		oOv4sVqEAmyM = RRav1Sf7Px(ynmiDuav5ICTeRsqj6Vb18Q,'url')
		url = oOv4sVqEAmyM+url
	else: url,ynmiDuav5ICTeRsqj6Vb18Q = kkb3logrYqHWCzLDGKduPpfQIv,kkb3logrYqHWCzLDGKduPpfQIv
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if type=='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	elif type=='filters':
		Ry3L7fdNGh = [FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('\\/','/').replace('\\"','"')]
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
			if any(value in title.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
			afR4xElWyzgcNAUnKXBempC = ww25jXuxtpK1TOJEbGUgrm8(afR4xElWyzgcNAUnKXBempC)
			title = Uo7Tbc29Eu(title)
			title = ww25jXuxtpK1TOJEbGUgrm8(title)
			title = title.replace('مشاهدة ',Vk54F7GcROfCy6HunEI)
			if '/series/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,363,afR4xElWyzgcNAUnKXBempC)
			elif 'حلقة' in title:
				AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) +حلقة +\d+',title,RSuYINdeamsK0t.DOTALL)
				if AWjJSatwokZ: title = '_MOD_' + AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					GEzxBN8rAh1d.append(title)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,363,afR4xElWyzgcNAUnKXBempC)
			else:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,362,afR4xElWyzgcNAUnKXBempC)
		if type=='filters':
			lyNAzPtVKoUXJxYMb = RSuYINdeamsK0t.findall('"more_button_page":(.*?),',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if lyNAzPtVKoUXJxYMb:
				count = lyNAzPtVKoUXJxYMb[0]
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'/offset/'+count
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة أخرى',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
		elif type==Vk54F7GcROfCy6HunEI:
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if Ry3L7fdNGh:
				UwcYSVZbdK3rI = Ry3L7fdNGh[0]
				items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
					title = 'صفحة '+Uo7Tbc29Eu(title)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,361)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = ZlBMJUAWRm9buv(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	name = RSuYINdeamsK0t.findall('itemprop="item" href=".*?/series/(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if name: name = name[-1].replace('-',otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip('/')
	if 'موسم' in name and type==Vk54F7GcROfCy6HunEI:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	else: name = name
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="Seasons--Episodes"(.*?)</singlesection',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		if type==Vk54F7GcROfCy6HunEI:
			items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,363,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'episodes')
		if len(h9zFQKnsNL.menuItemsLIST)==0:
			v8e07ENZbVzIjaMSQPAxLUyuKcWho = RSuYINdeamsK0t.findall('class="Episodes--Seasons--Episodes"(.*?)&&',UwcYSVZbdK3rI+'&&',RSuYINdeamsK0t.DOTALL)
			if v8e07ENZbVzIjaMSQPAxLUyuKcWho: UwcYSVZbdK3rI = v8e07ENZbVzIjaMSQPAxLUyuKcWho[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?<episodeTitle>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = name+' - '+title
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,362)
	if len(h9zFQKnsNL.menuItemsLIST)==0:
		title = RSuYINdeamsK0t.findall('<title>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',Vk54F7GcROfCy6HunEI).replace('مشاهدة ',Vk54F7GcROfCy6HunEI)
		else: title = 'ملف التشغيل'
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,362)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco:
		TwIJRB04mjGDfpz7CQMdco = [TwIJRB04mjGDfpz7CQMdco[0][0],TwIJRB04mjGDfpz7CQMdco[0][1]]
		if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('data-url="(.*?)".*?strong>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if name=='سيرفر ماي سيما': name = 'mycima'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="List--Download(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			jMiru3pGns = RSuYINdeamsK0t.findall('\d\d\d+',jMiru3pGns,RSuYINdeamsK0t.DOTALL)
			if jMiru3pGns: jMiru3pGns = '____'+jMiru3pGns[0]
			else: jMiru3pGns = Vk54F7GcROfCy6HunEI
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=mycima'+'__download'+jMiru3pGns
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search,AejzU6LD3b7BoMyJF2GS=Vk54F7GcROfCy6HunEI):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ['/list','/','/list/series','/list/anime','/list/tv']
	ZlgD1VuYNwp5dxqCmFJnrcRXPLMG = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر النوع المطلوب:', ZlgD1VuYNwp5dxqCmFJnrcRXPLMG)
		if qreJEpY8nZguD==-1: return
	else: qreJEpY8nZguD = 0
	if AejzU6LD3b7BoMyJF2GS==Vk54F7GcROfCy6HunEI:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,False,Vk54F7GcROfCy6HunEI,'MYCIMA-SEARCH-1st')
		AejzU6LD3b7BoMyJF2GS = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
		AejzU6LD3b7BoMyJF2GS = AejzU6LD3b7BoMyJF2GS.strip('/')
	hj50MJnoOp6ZWaS1IQ8Elr = AejzU6LD3b7BoMyJF2GS+'/search/'+search+yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr)
	return
def dm9YWrf845oej12ICpRnTgtSiQxV(kkb3logrYqHWCzLDGKduPpfQIv,filter):
	if '??' in kkb3logrYqHWCzLDGKduPpfQIv: url = kkb3logrYqHWCzLDGKduPpfQIv.split('//getposts??')[0]
	else: url = kkb3logrYqHWCzLDGKduPpfQIv
	filter = filter.replace('_FORGETRESULTS_',Vk54F7GcROfCy6HunEI)
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='CATEGORIES':
		if z3ejatAUuRhOc5mWDlvs8[0]+'==' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = z3ejatAUuRhOc5mWDlvs8[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(z3ejatAUuRhOc5mWDlvs8[0:-1])):
			if z3ejatAUuRhOc5mWDlvs8[zHq7nBWJTNyY1I3aLco4AR]+'==' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = z3ejatAUuRhOc5mWDlvs8[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'==0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'==0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'//getposts??'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='FILTERS':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'//getposts??'+KMbV6CGYIuH
		xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(hj50MJnoOp6ZWaS1IQ8Elr,kkb3logrYqHWCzLDGKduPpfQIv)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',xIZTXEQJ7qtmF,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',xIZTXEQJ7qtmF,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MYCIMA-FILTERS_MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('\\"','"').replace('\\/','/')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<mycima--filter(.*?)</mycima--filter>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ugep4NW1YS = RSuYINdeamsK0t.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',UwcYSVZbdK3rI+'<filterbox',RSuYINdeamsK0t.DOTALL)
	dict = {}
	for kuKGA8HpgN7PyjvxeLZ,name,UwcYSVZbdK3rI in Ugep4NW1YS:
		name = ww25jXuxtpK1TOJEbGUgrm8(name)
		if 'interest' in kuKGA8HpgN7PyjvxeLZ: continue
		items = RSuYINdeamsK0t.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if '==' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='CATEGORIES':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<=1:
				if kuKGA8HpgN7PyjvxeLZ==z3ejatAUuRhOc5mWDlvs8[-1]: txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'CATEGORIES___'+Ng1Jod47fp0S)
				return
			else:
				xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(hj50MJnoOp6ZWaS1IQ8Elr,kkb3logrYqHWCzLDGKduPpfQIv)
				if kuKGA8HpgN7PyjvxeLZ==z3ejatAUuRhOc5mWDlvs8[-1]:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',xIZTXEQJ7qtmF,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,364,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='FILTERS':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+kuKGA8HpgN7PyjvxeLZ+'==0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+kuKGA8HpgN7PyjvxeLZ+'==0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name+': الجميع',hj50MJnoOp6ZWaS1IQ8Elr,365,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S+'_FORGETRESULTS_')
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			name = ww25jXuxtpK1TOJEbGUgrm8(name)
			CCPw5ZS83fxa7AXzQ9VvUIrNDbo = ww25jXuxtpK1TOJEbGUgrm8(CCPw5ZS83fxa7AXzQ9VvUIrNDbo)
			if value=='r' or value=='nc-17': continue
			if any(value in CCPw5ZS83fxa7AXzQ9VvUIrNDbo.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
			if 'http' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			if 'الكل' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			if 'n-a' in value: continue
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo==Vk54F7GcROfCy6HunEI: CCPw5ZS83fxa7AXzQ9VvUIrNDbo = value
			xxM1Ua3FDdE2Xl8TOzsVuqBWg = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			jjlvNYP47uXIK2 = RSuYINdeamsK0t.findall('<name>(.*?)</name>',CCPw5ZS83fxa7AXzQ9VvUIrNDbo,RSuYINdeamsK0t.DOTALL)
			if jjlvNYP47uXIK2: xxM1Ua3FDdE2Xl8TOzsVuqBWg = jjlvNYP47uXIK2[0]
			esUNcDaPg3QoX = name+': '+xxM1Ua3FDdE2Xl8TOzsVuqBWg
			dict[kuKGA8HpgN7PyjvxeLZ][value] = esUNcDaPg3QoX
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&&'+kuKGA8HpgN7PyjvxeLZ+'=='+xxM1Ua3FDdE2Xl8TOzsVuqBWg
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&&'+kuKGA8HpgN7PyjvxeLZ+'=='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			if type=='FILTERS':
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,url,365,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and z3ejatAUuRhOc5mWDlvs8[-2]+'==' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
				ynmiDuav5ICTeRsqj6Vb18Q = url+'//getposts??'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				xIZTXEQJ7qtmF = LbJju0HKpiaENIe3xYo8AMkXBFVh(ynmiDuav5ICTeRsqj6Vb18Q,kkb3logrYqHWCzLDGKduPpfQIv)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,xIZTXEQJ7qtmF,361,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,url,364,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
z3ejatAUuRhOc5mWDlvs8 = ['genre','release-year','nation']
iiVg3Lp5KB0m1FUXM7GlEY6QRsk9 = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def LbJju0HKpiaENIe3xYo8AMkXBFVh(hj50MJnoOp6ZWaS1IQ8Elr,ynmiDuav5ICTeRsqj6Vb18Q):
	if '/AjaxCenter/RightBar' in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace('//getposts??','::/AjaxCenter/Filtering/')
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace('==','/')
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace('&&','/')
	return hj50MJnoOp6ZWaS1IQ8Elr
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&&')
	og8wRH5eO04T3uylM,PpjxGzO7yqD0AXSJL1Mw = {},Vk54F7GcROfCy6HunEI
	if '==' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('==')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	for key in iiVg3Lp5KB0m1FUXM7GlEY6QRsk9:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&&'+key+'=='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&&'+key+'=='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&&')
	return PpjxGzO7yqD0AXSJL1Mw
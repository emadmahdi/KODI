# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
ILyVox7aiXM148nz = 'EXCLUDES'
def X1ou5t2aHf0xFLwA(EDy0Rs9liwjZvJY,IuWhtGZOPeozEUTC3KsiB):
	IuWhtGZOPeozEUTC3KsiB = IuWhtGZOPeozEUTC3KsiB.replace(nMt0iueCy6K,Vk54F7GcROfCy6HunEI).replace(' '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI)[pwxH3oREFm5v98BCZ1QVtzMJOc:]
	z8zFIwECN1i7GWZTQnpHVD3xlMh6mf = RSuYINdeamsK0t.findall('[a-zA-Z]',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
	if 'بحث IPTV - ' in EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace('بحث IPTV - ',kH6Bj7pebUaxIf+'بحث IPTV - '+kH6Bj7pebUaxIf)
	elif ' IPTV' in EDy0Rs9liwjZvJY and IuWhtGZOPeozEUTC3KsiB=='IPT': EDy0Rs9liwjZvJY = kH6Bj7pebUaxIf+EDy0Rs9liwjZvJY
	elif 'بحث M3U - ' in EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace('بحث M3U - ',kH6Bj7pebUaxIf+'بحث M3U - '+kH6Bj7pebUaxIf)
	elif ' M3U' in EDy0Rs9liwjZvJY and IuWhtGZOPeozEUTC3KsiB=='M3U': EDy0Rs9liwjZvJY = kH6Bj7pebUaxIf+EDy0Rs9liwjZvJY
	elif 'بحث ' in EDy0Rs9liwjZvJY and ' - ' in EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = kH6Bj7pebUaxIf+EDy0Rs9liwjZvJY
	elif not z8zFIwECN1i7GWZTQnpHVD3xlMh6mf:
		xxm7BFlAYub = RSuYINdeamsK0t.findall('^( *?)(.*?)( *?)$',EDy0Rs9liwjZvJY)
		Zpc2BAo3GvLRenfDz9qXYIQsKj,drphbEjwctDSy3,X6jNL0wT3d145hmQYio9uHz = xxm7BFlAYub[ufmXvxgoHGDwZtjsLkR05i]
		cehj0wxMXLVySOFHG67pTI = RSuYINdeamsK0t.findall('^([!-~])',drphbEjwctDSy3)
		if cehj0wxMXLVySOFHG67pTI: EDy0Rs9liwjZvJY = Zpc2BAo3GvLRenfDz9qXYIQsKj+ZdD4q6gA50I+drphbEjwctDSy3+X6jNL0wT3d145hmQYio9uHz
		else: EDy0Rs9liwjZvJY = X6jNL0wT3d145hmQYio9uHz+kH6Bj7pebUaxIf+drphbEjwctDSy3+Zpc2BAo3GvLRenfDz9qXYIQsKj
	else:
		import bidi.algorithm as XTO5h0Fqprge621
		if pwxH3oREFm5v98BCZ1QVtzMJOc:
			R2RdAbZYEL5 = EDy0Rs9liwjZvJY
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: R2RdAbZYEL5 = R2RdAbZYEL5.decode(AoCWwJHgUPKXI7u2lEzym,'ignore')
			nYsW3DtKLSAXPbQ9aUO7rd = XTO5h0Fqprge621.get_display(R2RdAbZYEL5,base_dir='L')
			hhwyJeYnBmb6Z = R2RdAbZYEL5.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			IiXKRqyvjCU4gYLDEMoeWfaS = nYsW3DtKLSAXPbQ9aUO7rd.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			q5cCiDvFpf2Rr9,tvk3mP8nlqYudjOiar45GWZ7Kbc6,Ws3RGZutchO8QnvEK,pN6neGtS0lvQ = [],[],Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
			IWo8quDyxaY0trKO6l = zip(hhwyJeYnBmb6Z,IiXKRqyvjCU4gYLDEMoeWfaS)
			for RhwDQkOIaE92yvipLbVgW3,CaLcEYSApsjJBgU6GX in IWo8quDyxaY0trKO6l:
				if RhwDQkOIaE92yvipLbVgW3==CaLcEYSApsjJBgU6GX==Vk54F7GcROfCy6HunEI and pN6neGtS0lvQ:
					Ws3RGZutchO8QnvEK += otBWsSAfu7dihVkP9e1JFKrvmYy2Q
					continue
				if RhwDQkOIaE92yvipLbVgW3==CaLcEYSApsjJBgU6GX:
					jp92E1Yfsk6vL7exTH5cmAM8RzVq = 'EN'
					if pN6neGtS0lvQ==jp92E1Yfsk6vL7exTH5cmAM8RzVq: Ws3RGZutchO8QnvEK += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+RhwDQkOIaE92yvipLbVgW3
					elif RhwDQkOIaE92yvipLbVgW3:
						if Ws3RGZutchO8QnvEK:
							tvk3mP8nlqYudjOiar45GWZ7Kbc6.append(Ws3RGZutchO8QnvEK)
							q5cCiDvFpf2Rr9.append(Vk54F7GcROfCy6HunEI)
						Ws3RGZutchO8QnvEK = RhwDQkOIaE92yvipLbVgW3
				else:
					jp92E1Yfsk6vL7exTH5cmAM8RzVq = 'AR'
					if pN6neGtS0lvQ==jp92E1Yfsk6vL7exTH5cmAM8RzVq: Ws3RGZutchO8QnvEK += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+RhwDQkOIaE92yvipLbVgW3
					elif RhwDQkOIaE92yvipLbVgW3:
						if Ws3RGZutchO8QnvEK:
							q5cCiDvFpf2Rr9.append(Ws3RGZutchO8QnvEK)
							tvk3mP8nlqYudjOiar45GWZ7Kbc6.append(Vk54F7GcROfCy6HunEI)
						Ws3RGZutchO8QnvEK = RhwDQkOIaE92yvipLbVgW3
				pN6neGtS0lvQ = jp92E1Yfsk6vL7exTH5cmAM8RzVq
			if jp92E1Yfsk6vL7exTH5cmAM8RzVq=='EN':
				q5cCiDvFpf2Rr9.append(Ws3RGZutchO8QnvEK)
				tvk3mP8nlqYudjOiar45GWZ7Kbc6.append(Vk54F7GcROfCy6HunEI)
			else:
				tvk3mP8nlqYudjOiar45GWZ7Kbc6.append(Ws3RGZutchO8QnvEK)
				q5cCiDvFpf2Rr9.append(Vk54F7GcROfCy6HunEI)
			xxJck13Q2BmERiVU8gLrOb4 = Vk54F7GcROfCy6HunEI
			IWo8quDyxaY0trKO6l = zip(q5cCiDvFpf2Rr9,tvk3mP8nlqYudjOiar45GWZ7Kbc6)
			import bidi.mirror as H0oBirMY7Ksl58t
			for fFQnElth6xMVKSusIrRCX,QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS in IWo8quDyxaY0trKO6l:
				if fFQnElth6xMVKSusIrRCX: xxJck13Q2BmERiVU8gLrOb4 += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+fFQnElth6xMVKSusIrRCX
				else:
					cehj0wxMXLVySOFHG67pTI = RSuYINdeamsK0t.findall('([!-~]) *$',QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS)
					if cehj0wxMXLVySOFHG67pTI:
						cehj0wxMXLVySOFHG67pTI = cehj0wxMXLVySOFHG67pTI[ufmXvxgoHGDwZtjsLkR05i]
						try:
							RytK6s89EzAbrh1kVeq7 = H0oBirMY7Ksl58t.MIRRORED[cehj0wxMXLVySOFHG67pTI]
							xxm7BFlAYub = RSuYINdeamsK0t.findall('^( *?)(.*?)( *?)$',QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS)
							if xxm7BFlAYub: Zpc2BAo3GvLRenfDz9qXYIQsKj,QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS,X6jNL0wT3d145hmQYio9uHz = xxm7BFlAYub[ufmXvxgoHGDwZtjsLkR05i]
							QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS = Zpc2BAo3GvLRenfDz9qXYIQsKj+RytK6s89EzAbrh1kVeq7+QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS[:-pwxH3oREFm5v98BCZ1QVtzMJOc]+X6jNL0wT3d145hmQYio9uHz
						except: pass
					xxJck13Q2BmERiVU8gLrOb4 += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+QQr9hoxXKgHtNyjJnaiqRG8LbAzUlS
			EDy0Rs9liwjZvJY = xxJck13Q2BmERiVU8gLrOb4[pwxH3oREFm5v98BCZ1QVtzMJOc:]
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.encode(AoCWwJHgUPKXI7u2lEzym)
		else:
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.decode(AoCWwJHgUPKXI7u2lEzym)
			EDy0Rs9liwjZvJY = XTO5h0Fqprge621.get_display(EDy0Rs9liwjZvJY)
			R2RdAbZYEL5,nYsW3DtKLSAXPbQ9aUO7rd = EDy0Rs9liwjZvJY,EDy0Rs9liwjZvJY
			if 1:
				pN6neGtS0lvQ,o0JApa32Y4QXfx7 = Vk54F7GcROfCy6HunEI,[]
				oW9F1KRvHhjNa7J03rOlCnVcS = EDy0Rs9liwjZvJY.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				for XoUycvGgzS8Bfk in oW9F1KRvHhjNa7J03rOlCnVcS:
					if not XoUycvGgzS8Bfk:
						if o0JApa32Y4QXfx7: o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc] += otBWsSAfu7dihVkP9e1JFKrvmYy2Q
						else: o0JApa32Y4QXfx7.append(Vk54F7GcROfCy6HunEI)
						continue
					DWNg5V8Xflmep = RSuYINdeamsK0t.findall('[!-~]',XoUycvGgzS8Bfk[ufmXvxgoHGDwZtjsLkR05i])
					if DWNg5V8Xflmep==pN6neGtS0lvQ and o0JApa32Y4QXfx7: o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc] += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+XoUycvGgzS8Bfk
					else:
						if o0JApa32Y4QXfx7:
							Co3KJQ0klsA6a8it7qYMgXbjVWxGyR = RSuYINdeamsK0t.findall('[^!-~]',o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc])
							if Co3KJQ0klsA6a8it7qYMgXbjVWxGyR:
								o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc] = XTO5h0Fqprge621.get_display(o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc])
								rovD9lM6WQxzU1i = RSuYINdeamsK0t.findall('^ +',o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc])
								if rovD9lM6WQxzU1i: o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc] = o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc].lstrip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)+rovD9lM6WQxzU1i[ufmXvxgoHGDwZtjsLkR05i]
						o0JApa32Y4QXfx7.append(XoUycvGgzS8Bfk)
					pN6neGtS0lvQ = DWNg5V8Xflmep
				if o0JApa32Y4QXfx7: o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc] = XTO5h0Fqprge621.get_display(o0JApa32Y4QXfx7[-pwxH3oREFm5v98BCZ1QVtzMJOc])
				EDy0Rs9liwjZvJY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q.join(o0JApa32Y4QXfx7)
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.encode(AoCWwJHgUPKXI7u2lEzym)
	return EDy0Rs9liwjZvJY
def ZZArK3Eo5wj8CvNDLaFXBQOceWx(whlLMpFrbVYQNHDACx8EgvuXeT,fNgLOhpS8alPKvoxqdT,sB0cmXYkHgGnC2PFy3):
	hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,mpRqdhJV6NyFO,al7FB0LpuXYA26CiZbfwGSIyeU,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx = whlLMpFrbVYQNHDACx8EgvuXeT
	Yz6schq9wSmiu3IOdke0DXPj5W = int(Yz6schq9wSmiu3IOdke0DXPj5W)
	AC9SerbxZRfM76 = RSuYINdeamsK0t.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
	if AC9SerbxZRfM76:
		AC9SerbxZRfM76,vjU9VK4q3LhQaHGYlF,Caxf5RzMcJZI4YQp863vNDXAOHS = AC9SerbxZRfM76[ufmXvxgoHGDwZtjsLkR05i]
		EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(AC9SerbxZRfM76,Vk54F7GcROfCy6HunEI)
	utV7wcB3SZ = EDy0Rs9liwjZvJY
	IuWhtGZOPeozEUTC3KsiB = RSuYINdeamsK0t.findall('^_(\w\w\w)_(.*?)$',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
	if IuWhtGZOPeozEUTC3KsiB:
		IuWhtGZOPeozEUTC3KsiB,EDy0Rs9liwjZvJY = IuWhtGZOPeozEUTC3KsiB[ufmXvxgoHGDwZtjsLkR05i]
		y4fmDzl8h6i0ZqXMu = '_MOD_' in EDy0Rs9liwjZvJY
		j6W37Jtc8ryXDT95Phx = hArRgv5l10sU2yVSCO9JBHbE=='folder'
		if y4fmDzl8h6i0ZqXMu and j6W37Jtc8ryXDT95Phx: GtHz43sOcmoYbVlW2D9MJNEZXAxh = ';'
		elif y4fmDzl8h6i0ZqXMu and not j6W37Jtc8ryXDT95Phx: GtHz43sOcmoYbVlW2D9MJNEZXAxh = WWXlgMJx4SP910N
		elif not y4fmDzl8h6i0ZqXMu and j6W37Jtc8ryXDT95Phx: GtHz43sOcmoYbVlW2D9MJNEZXAxh = ','
		elif not y4fmDzl8h6i0ZqXMu and not j6W37Jtc8ryXDT95Phx: GtHz43sOcmoYbVlW2D9MJNEZXAxh = otBWsSAfu7dihVkP9e1JFKrvmYy2Q
		EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace('_MOD_',Vk54F7GcROfCy6HunEI)
		IuWhtGZOPeozEUTC3KsiB = GtHz43sOcmoYbVlW2D9MJNEZXAxh+nMt0iueCy6K+IuWhtGZOPeozEUTC3KsiB+' '+ZZoLlKyInXc08j2pTGJ
	else: IuWhtGZOPeozEUTC3KsiB = Vk54F7GcROfCy6HunEI
	if AC9SerbxZRfM76:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			AC9SerbxZRfM76 = d761ZWXHEvliYN45RzLP2+vjU9VK4q3LhQaHGYlF+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Caxf5RzMcJZI4YQp863vNDXAOHS+ZZoLlKyInXc08j2pTGJ
			if IuWhtGZOPeozEUTC3KsiB: EDy0Rs9liwjZvJY = AC9SerbxZRfM76+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+kH6Bj7pebUaxIf+IuWhtGZOPeozEUTC3KsiB+EDy0Rs9liwjZvJY
			else: EDy0Rs9liwjZvJY = AC9SerbxZRfM76+kH6Bj7pebUaxIf+EDy0Rs9liwjZvJY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
		elif PvwFsJK23NbU8XWAx:
			if IuWhtGZOPeozEUTC3KsiB:
				AC9SerbxZRfM76 = d761ZWXHEvliYN45RzLP2+vjU9VK4q3LhQaHGYlF+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Caxf5RzMcJZI4YQp863vNDXAOHS+ZZoLlKyInXc08j2pTGJ
				EDy0Rs9liwjZvJY = AC9SerbxZRfM76+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+IuWhtGZOPeozEUTC3KsiB+EDy0Rs9liwjZvJY
			else:
				AC9SerbxZRfM76 = d761ZWXHEvliYN45RzLP2+Caxf5RzMcJZI4YQp863vNDXAOHS+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+vjU9VK4q3LhQaHGYlF+ZZoLlKyInXc08j2pTGJ
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+kH6Bj7pebUaxIf+AC9SerbxZRfM76
	elif IuWhtGZOPeozEUTC3KsiB:
		EDy0Rs9liwjZvJY = X1ou5t2aHf0xFLwA(EDy0Rs9liwjZvJY,IuWhtGZOPeozEUTC3KsiB)
		EDy0Rs9liwjZvJY = IuWhtGZOPeozEUTC3KsiB+EDy0Rs9liwjZvJY
	whlLMpFrbVYQNHDACx8EgvuXeT = hArRgv5l10sU2yVSCO9JBHbE,utV7wcB3SZ,lI5ck2gjRCiw9bMTF0xHsG,str(Yz6schq9wSmiu3IOdke0DXPj5W),c7E603KRhbToig9V4yx,mpRqdhJV6NyFO,al7FB0LpuXYA26CiZbfwGSIyeU,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx
	EXc0od7mCjG2YknyIASrMgK5TvpzH = {'type':Vk54F7GcROfCy6HunEI,'mode':Vk54F7GcROfCy6HunEI,'url':Vk54F7GcROfCy6HunEI,'text':Vk54F7GcROfCy6HunEI,'page':Vk54F7GcROfCy6HunEI,'name':Vk54F7GcROfCy6HunEI,'image':Vk54F7GcROfCy6HunEI,'context':Vk54F7GcROfCy6HunEI,'infodict':Vk54F7GcROfCy6HunEI}
	if PvwFsJK23NbU8XWAx: utV7wcB3SZ = utV7wcB3SZ.encode(AoCWwJHgUPKXI7u2lEzym,'ignore').decode(AoCWwJHgUPKXI7u2lEzym)
	EXc0od7mCjG2YknyIASrMgK5TvpzH['name'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(utV7wcB3SZ)
	EXc0od7mCjG2YknyIASrMgK5TvpzH['type'] = hArRgv5l10sU2yVSCO9JBHbE.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	EXc0od7mCjG2YknyIASrMgK5TvpzH['mode'] = str(Yz6schq9wSmiu3IOdke0DXPj5W).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if hArRgv5l10sU2yVSCO9JBHbE=='folder' and mpRqdhJV6NyFO: EXc0od7mCjG2YknyIASrMgK5TvpzH['page'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(mpRqdhJV6NyFO.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q))
	if m6cEejX1UO0HwpuvqL7xGA2VWJ: EXc0od7mCjG2YknyIASrMgK5TvpzH['context'] = m6cEejX1UO0HwpuvqL7xGA2VWJ.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if al7FB0LpuXYA26CiZbfwGSIyeU: EXc0od7mCjG2YknyIASrMgK5TvpzH['text'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(al7FB0LpuXYA26CiZbfwGSIyeU.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q))
	if c7E603KRhbToig9V4yx: EXc0od7mCjG2YknyIASrMgK5TvpzH['image'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(c7E603KRhbToig9V4yx.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q))
	if GeDUpHhCROtPrx:
		GeDUpHhCROtPrx = str(GeDUpHhCROtPrx)
		EXc0od7mCjG2YknyIASrMgK5TvpzH['infodict'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(GeDUpHhCROtPrx.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q))
		GeDUpHhCROtPrx = eval(GeDUpHhCROtPrx)
	else: GeDUpHhCROtPrx = {}
	if lI5ck2gjRCiw9bMTF0xHsG: EXc0od7mCjG2YknyIASrMgK5TvpzH['url'] = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(lI5ck2gjRCiw9bMTF0xHsG.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q))
	RIaBAlK2Yoz9Gp3jqxyiUVE = {'name':Vk54F7GcROfCy6HunEI,'context_menu':Vk54F7GcROfCy6HunEI,'plot':Vk54F7GcROfCy6HunEI,'stars':Vk54F7GcROfCy6HunEI,'image':Vk54F7GcROfCy6HunEI,'type':Vk54F7GcROfCy6HunEI,'isFolder':Vk54F7GcROfCy6HunEI,'newpath':Vk54F7GcROfCy6HunEI,'duration':Vk54F7GcROfCy6HunEI}
	QzDYRdwp9y7xcTsq = []
	QQeJR9rGbHgj = 'plugin://'+DDXHAicJtj6+'/?type='+EXc0od7mCjG2YknyIASrMgK5TvpzH['type']+'&mode='+EXc0od7mCjG2YknyIASrMgK5TvpzH['mode']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['page']: QQeJR9rGbHgj += '&page='+EXc0od7mCjG2YknyIASrMgK5TvpzH['page']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['name']: QQeJR9rGbHgj += '&name='+EXc0od7mCjG2YknyIASrMgK5TvpzH['name']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['text']: QQeJR9rGbHgj += '&text='+EXc0od7mCjG2YknyIASrMgK5TvpzH['text']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['infodict']: QQeJR9rGbHgj += '&infodict='+EXc0od7mCjG2YknyIASrMgK5TvpzH['infodict']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['image']: QQeJR9rGbHgj += '&image='+EXc0od7mCjG2YknyIASrMgK5TvpzH['image']
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['url']: QQeJR9rGbHgj += '&url='+EXc0od7mCjG2YknyIASrMgK5TvpzH['url']
	if Yz6schq9wSmiu3IOdke0DXPj5W not in [265,533]: RIaBAlK2Yoz9Gp3jqxyiUVE['favorites'] = YOHXqtbQTBfKerIZ
	else: RIaBAlK2Yoz9Gp3jqxyiUVE['favorites'] = eu1NswY9zkKC60I
	if EXc0od7mCjG2YknyIASrMgK5TvpzH['context']: QQeJR9rGbHgj += '&context='+EXc0od7mCjG2YknyIASrMgK5TvpzH['context']
	if Yz6schq9wSmiu3IOdke0DXPj5W in [235,238] and hArRgv5l10sU2yVSCO9JBHbE=='live' and 'EPG' in m6cEejX1UO0HwpuvqL7xGA2VWJ:
		NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?mode=238&text=SHORT_EPG&url='+lI5ck2gjRCiw9bMTF0xHsG
		QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'البرامج القادمة'+ZZoLlKyInXc08j2pTGJ
		ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
		QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if Yz6schq9wSmiu3IOdke0DXPj5W==265:
		X5XWZFgTmNGfxsOcrqKjLaQwE = fNgLOhpS8alPKvoxqdT(al7FB0LpuXYA26CiZbfwGSIyeU,YOHXqtbQTBfKerIZ)
		if X5XWZFgTmNGfxsOcrqKjLaQwE>ufmXvxgoHGDwZtjsLkR05i:
			NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?mode=266&text='+al7FB0LpuXYA26CiZbfwGSIyeU
			QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'مسح قائمة آخر 50 '+rLjksYNqhOBoHl3WREm8p(al7FB0LpuXYA26CiZbfwGSIyeU)+ZZoLlKyInXc08j2pTGJ
			ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
			QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if hArRgv5l10sU2yVSCO9JBHbE=='video' and Yz6schq9wSmiu3IOdke0DXPj5W!=331:
		NprvbGEsZkaYIzfXdRlc5LW3Q = QQeJR9rGbHgj+'&context=6_DOWNLOAD'
		QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'تحميل ملف الفيديو'+ZZoLlKyInXc08j2pTGJ
		ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
		QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if Yz6schq9wSmiu3IOdke0DXPj5W==331:
		NprvbGEsZkaYIzfXdRlc5LW3Q = QQeJR9rGbHgj+'&context=6_DELETE'
		QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'حذف ملف الفيديو'+ZZoLlKyInXc08j2pTGJ
		ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
		QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if hArRgv5l10sU2yVSCO9JBHbE=='folder' and Yz6schq9wSmiu3IOdke0DXPj5W==540:
		Tce7wVfK4l85rYgIzRPkWSvsQ9 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_SPLITTED_ALL')
		if Tce7wVfK4l85rYgIzRPkWSvsQ9:
			NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?context=7'
			QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'مسح كلمات بحث المواقع'+ZZoLlKyInXc08j2pTGJ
			ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
			QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if hArRgv5l10sU2yVSCO9JBHbE=='folder' and Yz6schq9wSmiu3IOdke0DXPj5W==1010:
		Tce7wVfK4l85rYgIzRPkWSvsQ9 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if Tce7wVfK4l85rYgIzRPkWSvsQ9:
			NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?context=10'
			QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'مسح كلمات بحث جوجل'+ZZoLlKyInXc08j2pTGJ
			ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
			QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	VV8dBTpzRJr = [9990,9999,RXnhpCUk4M1TvgJE,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if Yz6schq9wSmiu3IOdke0DXPj5W not in VV8dBTpzRJr:
		NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?context=8&mode=260'
		QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'القائمة الرئيسية'+ZZoLlKyInXc08j2pTGJ
		ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
		QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	hhgGAfOXvk7xowduHCnV3 = Yz6schq9wSmiu3IOdke0DXPj5W-Yz6schq9wSmiu3IOdke0DXPj5W%10
	if Yz6schq9wSmiu3IOdke0DXPj5W%10:
		if hhgGAfOXvk7xowduHCnV3==280: hhgGAfOXvk7xowduHCnV3 = 230
		if hhgGAfOXvk7xowduHCnV3==410: hhgGAfOXvk7xowduHCnV3 = 400
		if hhgGAfOXvk7xowduHCnV3==520: hhgGAfOXvk7xowduHCnV3 = 510
		if hhgGAfOXvk7xowduHCnV3 not in X34XVDTA8KQJs:
			NprvbGEsZkaYIzfXdRlc5LW3Q = 'plugin://'+DDXHAicJtj6+'?context=8&mode='+str(hhgGAfOXvk7xowduHCnV3)
			QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'قائمة الموقع'+ZZoLlKyInXc08j2pTGJ
			ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
			QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	NprvbGEsZkaYIzfXdRlc5LW3Q = QQeJR9rGbHgj+'&context=9'
	QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'تحديث القائمة'+ZZoLlKyInXc08j2pTGJ
	ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
	QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if hArRgv5l10sU2yVSCO9JBHbE in ['video','live']:
		NprvbGEsZkaYIzfXdRlc5LW3Q = QQeJR9rGbHgj+'&context=18'
		QsOcUIiGRP = d761ZWXHEvliYN45RzLP2+'إظهار قوائم الجودة'+ZZoLlKyInXc08j2pTGJ
		ozhdQYGRaf = (QsOcUIiGRP,'RunPlugin('+NprvbGEsZkaYIzfXdRlc5LW3Q+')')
		QzDYRdwp9y7xcTsq.append(ozhdQYGRaf)
	if hArRgv5l10sU2yVSCO9JBHbE in ['link','video','live']: PPoj1HKLOzlF2Jus94Vep5hDZXiG = eu1NswY9zkKC60I
	elif hArRgv5l10sU2yVSCO9JBHbE=='folder': PPoj1HKLOzlF2Jus94Vep5hDZXiG = YOHXqtbQTBfKerIZ
	RIaBAlK2Yoz9Gp3jqxyiUVE['name'] = EDy0Rs9liwjZvJY
	RIaBAlK2Yoz9Gp3jqxyiUVE['context_menu'] = QzDYRdwp9y7xcTsq
	if 'plot' in list(GeDUpHhCROtPrx.keys()): RIaBAlK2Yoz9Gp3jqxyiUVE['plot'] = GeDUpHhCROtPrx['plot']
	if 'stars' in list(GeDUpHhCROtPrx.keys()): RIaBAlK2Yoz9Gp3jqxyiUVE['stars'] = GeDUpHhCROtPrx['stars']
	if c7E603KRhbToig9V4yx: RIaBAlK2Yoz9Gp3jqxyiUVE['image'] = c7E603KRhbToig9V4yx
	if hArRgv5l10sU2yVSCO9JBHbE=='video' and mpRqdhJV6NyFO:
		jJ4g2lcwIi6eVOoFQf = RSuYINdeamsK0t.findall('[\d:]+',mpRqdhJV6NyFO,RSuYINdeamsK0t.DOTALL)
		if jJ4g2lcwIi6eVOoFQf:
			jJ4g2lcwIi6eVOoFQf = '0:0:0:0:0:'+jJ4g2lcwIi6eVOoFQf[ufmXvxgoHGDwZtjsLkR05i]
			avxZKMEsw9BTjVDuikc,XAwx8ekHPdCnfGmN45y3W,Pp2D6ugbMeBCO7cTt59RosViW03,ZZnreOQIiSRvfD3cVN5TE,aLcx6bo0PRjHQVCGmIA2TizXOYq = jJ4g2lcwIi6eVOoFQf.rsplit(':',BZm7TqLPJfAVblDKsya85zFWXNMY)
			VAfX5s6waym4DRMUeSnQ3Cq = int(XAwx8ekHPdCnfGmN45y3W)*24*uuXTYKmMekIRQfcDd0+int(Pp2D6ugbMeBCO7cTt59RosViW03)*uuXTYKmMekIRQfcDd0+int(ZZnreOQIiSRvfD3cVN5TE)*60+int(aLcx6bo0PRjHQVCGmIA2TizXOYq)
			RIaBAlK2Yoz9Gp3jqxyiUVE['duration'] = VAfX5s6waym4DRMUeSnQ3Cq
	RIaBAlK2Yoz9Gp3jqxyiUVE['type'] = hArRgv5l10sU2yVSCO9JBHbE
	RIaBAlK2Yoz9Gp3jqxyiUVE['isFolder'] = PPoj1HKLOzlF2Jus94Vep5hDZXiG
	RIaBAlK2Yoz9Gp3jqxyiUVE['newpath'] = QQeJR9rGbHgj
	RIaBAlK2Yoz9Gp3jqxyiUVE['menuItem'] = whlLMpFrbVYQNHDACx8EgvuXeT
	RIaBAlK2Yoz9Gp3jqxyiUVE['mode'] = Yz6schq9wSmiu3IOdke0DXPj5W
	return RIaBAlK2Yoz9Gp3jqxyiUVE
def EEKTSdtU0bn3CIHQw64glWamXupJj(fNgLOhpS8alPKvoxqdT):
	aWf04iQjCH5qKLzGMyupbd72Sgnr,jjlvNYP47uXIK2 = [],Vk54F7GcROfCy6HunEI
	from DVX8HOTEnm import aXwcANF5vO8oDb,aTZdon9vfYHe12XzCI
	sB0cmXYkHgGnC2PFy3 = aXwcANF5vO8oDb()
	s9sTYnbqIEHthVG3czOK1p8vxF = cad8TeSyMUYmfsEO0.getSetting('av.status.refresh')
	if zLxMfI0XGwHT8n and (not s9sTYnbqIEHthVG3czOK1p8vxF or s9sTYnbqIEHthVG3czOK1p8vxF=='REFRESH_CACHE'): s9sTYnbqIEHthVG3czOK1p8vxF = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'str','FOLDERS_SORT',zLxMfI0XGwHT8n)
	if s9sTYnbqIEHthVG3czOK1p8vxF:
		if   '_PERM' in s9sTYnbqIEHthVG3czOK1p8vxF: jjlvNYP47uXIK2 = 'دائمي'
		elif '_TEMP' in s9sTYnbqIEHthVG3czOK1p8vxF: jjlvNYP47uXIK2 = 'مؤقت'
		if   '_REVERSED_' in s9sTYnbqIEHthVG3czOK1p8vxF: KK4WEqy9u1mj = 'عكسي' ; h9zFQKnsNL.menuItemsLIST[:] = reversed(h9zFQKnsNL.menuItemsLIST)
		elif '_ASCENDED_' in s9sTYnbqIEHthVG3czOK1p8vxF: KK4WEqy9u1mj = 'تصاعدي' ; h9zFQKnsNL.menuItemsLIST[:] = sorted(h9zFQKnsNL.menuItemsLIST,reverse=eu1NswY9zkKC60I,key=lambda key:key[pwxH3oREFm5v98BCZ1QVtzMJOc])
		elif '_DESCENDED_' in s9sTYnbqIEHthVG3czOK1p8vxF: KK4WEqy9u1mj = 'تنازلي' ; h9zFQKnsNL.menuItemsLIST[:] = sorted(h9zFQKnsNL.menuItemsLIST,reverse=YOHXqtbQTBfKerIZ,key=lambda key:key[pwxH3oREFm5v98BCZ1QVtzMJOc])
		elif '_RANDOMIZED_' in s9sTYnbqIEHthVG3czOK1p8vxF: KK4WEqy9u1mj = 'عشوائي' ; budUNB9jgpI8Pm5.shuffle(h9zFQKnsNL.menuItemsLIST)
	name = 'ترتيب '+KK4WEqy9u1mj+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jjlvNYP47uXIK2 if jjlvNYP47uXIK2 else 'بدون ترتيب (أصلي)'
	name = d761ZWXHEvliYN45RzLP2+name+ZZoLlKyInXc08j2pTGJ
	if s9sTYnbqIEHthVG3czOK1p8vxF in PPFb4eNE52s: cad8TeSyMUYmfsEO0.setSetting('av.status.refresh',Vk54F7GcROfCy6HunEI)
	WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = cmeXCvAZnH86gJ(zLxMfI0XGwHT8n)
	Yz6schq9wSmiu3IOdke0DXPj5W = int(Fj9S5lYorenKWR2I30)
	hhgGAfOXvk7xowduHCnV3 = Yz6schq9wSmiu3IOdke0DXPj5W-Yz6schq9wSmiu3IOdke0DXPj5W%10
	if Yz6schq9wSmiu3IOdke0DXPj5W%10 and hhgGAfOXvk7xowduHCnV3 not in X34XVDTA8KQJs and len(h9zFQKnsNL.menuItemsLIST)>1:
		h9zFQKnsNL.menuItemsLIST[:] = [('link',name,'',533,'','',zLxMfI0XGwHT8n,'','')]+h9zFQKnsNL.menuItemsLIST
	for whlLMpFrbVYQNHDACx8EgvuXeT in h9zFQKnsNL.menuItemsLIST:
		RIaBAlK2Yoz9Gp3jqxyiUVE = ZZArK3Eo5wj8CvNDLaFXBQOceWx(whlLMpFrbVYQNHDACx8EgvuXeT,fNgLOhpS8alPKvoxqdT,sB0cmXYkHgGnC2PFy3)
		if RIaBAlK2Yoz9Gp3jqxyiUVE['favorites']:
			QJ0EA3bvwqroRVUBZkFiOhNxzs47C = aTZdon9vfYHe12XzCI(sB0cmXYkHgGnC2PFy3,RIaBAlK2Yoz9Gp3jqxyiUVE['menuItem'],RIaBAlK2Yoz9Gp3jqxyiUVE['newpath'])
			RIaBAlK2Yoz9Gp3jqxyiUVE['context_menu'] = QJ0EA3bvwqroRVUBZkFiOhNxzs47C+RIaBAlK2Yoz9Gp3jqxyiUVE['context_menu']
		aWf04iQjCH5qKLzGMyupbd72Sgnr.append(RIaBAlK2Yoz9Gp3jqxyiUVE)
	return aWf04iQjCH5qKLzGMyupbd72Sgnr
def TUMGi8Lgrt6SEnqJy7XZ50sVP(p74HvfYKXiexEOAPR9BUNkq0u):
	GtHz43sOcmoYbVlW2D9MJNEZXAxh,uRK5jnwABa6SF0zq4hc2b, = [],Vk54F7GcROfCy6HunEI
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		if not uDJxNtKl2gLkR6zC7OZWEf1cjvF059: GtHz43sOcmoYbVlW2D9MJNEZXAxh.append(Vk54F7GcROfCy6HunEI)
		else: break
	p74HvfYKXiexEOAPR9BUNkq0u = p74HvfYKXiexEOAPR9BUNkq0u[len(GtHz43sOcmoYbVlW2D9MJNEZXAxh):]
	YWCso5NMKO = '\n\n\n\n'.join(p74HvfYKXiexEOAPR9BUNkq0u)
	YWCso5NMKO = YWCso5NMKO.replace('===== ===== =====','000001')
	YWCso5NMKO = YWCso5NMKO.replace(nMt0iueCy6K,'000002')
	YWCso5NMKO = YWCso5NMKO.replace(d761ZWXHEvliYN45RzLP2,'000003')
	YWCso5NMKO = YWCso5NMKO.replace(ZZoLlKyInXc08j2pTGJ,'000004')
	YWCso5NMKO = YWCso5NMKO.replace('[RIGHT]','000005')
	J5rfz78qyAvt49aoVunbRE1hZG = 100000
	dcyVz5IrtjO4 = {}
	muR0icbEPngf7jyC9zoFdQ = RSuYINdeamsK0t.findall('http.*?[\r\n ]',YWCso5NMKO,RSuYINdeamsK0t.DOTALL)
	for KQ2wd7f31Y6b9tueUaAFhqzxM in muR0icbEPngf7jyC9zoFdQ:
		J5rfz78qyAvt49aoVunbRE1hZG += pwxH3oREFm5v98BCZ1QVtzMJOc
		YWCso5NMKO = YWCso5NMKO.replace(KQ2wd7f31Y6b9tueUaAFhqzxM,str(J5rfz78qyAvt49aoVunbRE1hZG))
		dcyVz5IrtjO4[str(J5rfz78qyAvt49aoVunbRE1hZG)] = KQ2wd7f31Y6b9tueUaAFhqzxM
	for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(ufmXvxgoHGDwZtjsLkR05i,len(YWCso5NMKO),4800):
		k7hV0lgE3YeCbidwyGsmZQ5 = YWCso5NMKO[qf4yXuWZFYbxTEdkcQBUsAIgKH:qf4yXuWZFYbxTEdkcQBUsAIgKH+4800]
		GqR6n3LFY9B2bkoAgWSJKhMiP = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
		lI5ck2gjRCiw9bMTF0xHsG = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+GqR6n3LFY9B2bkoAgWSJKhMiP
		KT67DQI1xk9XG34ezN0hH = {'Content-Type':'text/plain'}
		cUwPtxlmTLe5nFD = k7hV0lgE3YeCbidwyGsmZQ5.encode(AoCWwJHgUPKXI7u2lEzym)
		aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'POST',lI5ck2gjRCiw9bMTF0xHsG,cUwPtxlmTLe5nFD,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if aaspUWRrCE4nLAlGf.succeeded:
			ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
			eAnWIsB05tC8YvoDZ = Bw6jaUcFxlqdDT8bC('str',ov9nVhCfMkz37xPgQOS)
			if eAnWIsB05tC8YvoDZ:
				eAnWIsB05tC8YvoDZ = eAnWIsB05tC8YvoDZ['translation']
				eAnWIsB05tC8YvoDZ = ww25jXuxtpK1TOJEbGUgrm8(eAnWIsB05tC8YvoDZ)
				for AyCmXWaeTFD9O8GwucvM03qi1 in range(len(eAnWIsB05tC8YvoDZ)):
					uRK5jnwABa6SF0zq4hc2b += eAnWIsB05tC8YvoDZ[AyCmXWaeTFD9O8GwucvM03qi1][ufmXvxgoHGDwZtjsLkR05i]
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000001','===== ===== =====')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000002',nMt0iueCy6K)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000003',d761ZWXHEvliYN45RzLP2)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000004',ZZoLlKyInXc08j2pTGJ)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000005','[RIGHT]')
	for J5rfz78qyAvt49aoVunbRE1hZG in list(dcyVz5IrtjO4.keys()):
		KQ2wd7f31Y6b9tueUaAFhqzxM = dcyVz5IrtjO4[J5rfz78qyAvt49aoVunbRE1hZG]
		uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace(J5rfz78qyAvt49aoVunbRE1hZG,KQ2wd7f31Y6b9tueUaAFhqzxM)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.split('\n\n\n\n')
	return GtHz43sOcmoYbVlW2D9MJNEZXAxh+uRK5jnwABa6SF0zq4hc2b
def zF3MQTbakCoZrS6x815mnN(p74HvfYKXiexEOAPR9BUNkq0u):
	GtHz43sOcmoYbVlW2D9MJNEZXAxh,uRK5jnwABa6SF0zq4hc2b, = [],Vk54F7GcROfCy6HunEI
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		if not uDJxNtKl2gLkR6zC7OZWEf1cjvF059: GtHz43sOcmoYbVlW2D9MJNEZXAxh.append(Vk54F7GcROfCy6HunEI)
		else: break
	p74HvfYKXiexEOAPR9BUNkq0u = p74HvfYKXiexEOAPR9BUNkq0u[len(GtHz43sOcmoYbVlW2D9MJNEZXAxh):]
	YWCso5NMKO = '\\n\\n\\n\\n'.join(p74HvfYKXiexEOAPR9BUNkq0u)
	YWCso5NMKO = YWCso5NMKO.replace('كلا','no')
	YWCso5NMKO = YWCso5NMKO.replace('استمرار','continue')
	YWCso5NMKO = YWCso5NMKO.replace('===== ===== =====','000001')
	YWCso5NMKO = YWCso5NMKO.replace(nMt0iueCy6K,'000002')
	YWCso5NMKO = YWCso5NMKO.replace(d761ZWXHEvliYN45RzLP2,'000003')
	YWCso5NMKO = YWCso5NMKO.replace(ZZoLlKyInXc08j2pTGJ,'000004')
	YWCso5NMKO = YWCso5NMKO.replace('[RIGHT]','000005')
	YWCso5NMKO = YWCso5NMKO.replace('[CENTER]','000006')
	YWCso5NMKO = YWCso5NMKO.replace('[RTL]','000007')
	YWCso5NMKO = YWCso5NMKO.replace("'","\\\\\\'")
	YWCso5NMKO = YWCso5NMKO.replace('"','\\\\\\"')
	YWCso5NMKO = YWCso5NMKO.replace(ixrPWKeFMnqJyVodX6D9AaO2,'\\n')
	YWCso5NMKO = YWCso5NMKO.replace(gSiK7EQVNXClOUDZGs,'\\\\r')
	for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(ufmXvxgoHGDwZtjsLkR05i,len(YWCso5NMKO),4800):
		k7hV0lgE3YeCbidwyGsmZQ5 = YWCso5NMKO[qf4yXuWZFYbxTEdkcQBUsAIgKH:qf4yXuWZFYbxTEdkcQBUsAIgKH+4800]
		lI5ck2gjRCiw9bMTF0xHsG = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		KT67DQI1xk9XG34ezN0hH = {'Content-Type':'application/x-www-form-urlencoded'}
		GqR6n3LFY9B2bkoAgWSJKhMiP = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
		cUwPtxlmTLe5nFD = 'f.req='+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8('[[["MkEWBc","[[\\"'+k7hV0lgE3YeCbidwyGsmZQ5+'\\",\\"ar\\",\\"'+GqR6n3LFY9B2bkoAgWSJKhMiP+'\\",1],[]]",null,"generic"]]]',Vk54F7GcROfCy6HunEI)
		cUwPtxlmTLe5nFD = cUwPtxlmTLe5nFD.replace('%5Cn','%5C%5Cn')
		aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'POST',lI5ck2gjRCiw9bMTF0xHsG,cUwPtxlmTLe5nFD,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if aaspUWRrCE4nLAlGf.succeeded:
			ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
			ov9nVhCfMkz37xPgQOS = ov9nVhCfMkz37xPgQOS.split(ixrPWKeFMnqJyVodX6D9AaO2)[-pwxH3oREFm5v98BCZ1QVtzMJOc]
			eAnWIsB05tC8YvoDZ = Bw6jaUcFxlqdDT8bC('str',ov9nVhCfMkz37xPgQOS)[ufmXvxgoHGDwZtjsLkR05i][RXnhpCUk4M1TvgJE]
			if eAnWIsB05tC8YvoDZ:
				eAnWIsB05tC8YvoDZ = Bw6jaUcFxlqdDT8bC('str',eAnWIsB05tC8YvoDZ)[pwxH3oREFm5v98BCZ1QVtzMJOc][ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i][m5DECdgjU4KqpVhyJ9A2b]
				eAnWIsB05tC8YvoDZ = ww25jXuxtpK1TOJEbGUgrm8(eAnWIsB05tC8YvoDZ)
				for AyCmXWaeTFD9O8GwucvM03qi1 in range(len(eAnWIsB05tC8YvoDZ)):
					uRK5jnwABa6SF0zq4hc2b += eAnWIsB05tC8YvoDZ[AyCmXWaeTFD9O8GwucvM03qi1][ufmXvxgoHGDwZtjsLkR05i]
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('00000','0000').replace('0000','000')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0001','===== ===== =====')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0002',nMt0iueCy6K)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0003',d761ZWXHEvliYN45RzLP2)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0004',ZZoLlKyInXc08j2pTGJ)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0005','[RIGHT]')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0006','[CENTER]')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0007','[RTL]')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.split('\n\n\n\n')
	return GtHz43sOcmoYbVlW2D9MJNEZXAxh+uRK5jnwABa6SF0zq4hc2b
def r3HLucl7Ok(p74HvfYKXiexEOAPR9BUNkq0u):
	GtHz43sOcmoYbVlW2D9MJNEZXAxh,oWH3AzTOM9b8VN = [],[]
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		if not uDJxNtKl2gLkR6zC7OZWEf1cjvF059: GtHz43sOcmoYbVlW2D9MJNEZXAxh.append(Vk54F7GcROfCy6HunEI)
		else: break
	p74HvfYKXiexEOAPR9BUNkq0u = p74HvfYKXiexEOAPR9BUNkq0u[len(GtHz43sOcmoYbVlW2D9MJNEZXAxh):]
	YWCso5NMKO = '\n\n\n\n'.join(p74HvfYKXiexEOAPR9BUNkq0u)
	YWCso5NMKO = YWCso5NMKO.replace('كلا','no')
	YWCso5NMKO = YWCso5NMKO.replace('استمرار','continue')
	YWCso5NMKO = YWCso5NMKO.replace('أدناه','below')
	YWCso5NMKO = YWCso5NMKO.replace(nMt0iueCy6K,'00001')
	YWCso5NMKO = YWCso5NMKO.replace(d761ZWXHEvliYN45RzLP2,'00002')
	YWCso5NMKO = YWCso5NMKO.replace(ZZoLlKyInXc08j2pTGJ,'00003')
	YWCso5NMKO = YWCso5NMKO.replace('=====','00004')
	YWCso5NMKO = YWCso5NMKO.replace(',','00005')
	YWCso5NMKO = YWCso5NMKO.replace('[RTL]','00009')
	YWCso5NMKO = YWCso5NMKO.replace('[CENTER]','0000A')
	YWCso5NMKO = YWCso5NMKO.replace(gSiK7EQVNXClOUDZGs,'0000B')
	p74HvfYKXiexEOAPR9BUNkq0u = YWCso5NMKO.split(ixrPWKeFMnqJyVodX6D9AaO2)
	YWCso5NMKO,uRK5jnwABa6SF0zq4hc2b = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
		if len(YWCso5NMKO+uDJxNtKl2gLkR6zC7OZWEf1cjvF059)<1800: YWCso5NMKO += ixrPWKeFMnqJyVodX6D9AaO2+uDJxNtKl2gLkR6zC7OZWEf1cjvF059
		else:
			oWH3AzTOM9b8VN.append(YWCso5NMKO)
			YWCso5NMKO = uDJxNtKl2gLkR6zC7OZWEf1cjvF059
	oWH3AzTOM9b8VN.append(YWCso5NMKO)
	for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in oWH3AzTOM9b8VN:
		KT67DQI1xk9XG34ezN0hH = {'Content-Type':'application/json','User-Agent':Vk54F7GcROfCy6HunEI}
		lI5ck2gjRCiw9bMTF0xHsG = 'https://api.reverso.net/translate/v1/translation'
		GqR6n3LFY9B2bkoAgWSJKhMiP = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
		cUwPtxlmTLe5nFD = {"format":"text","from":"ara","to":GqR6n3LFY9B2bkoAgWSJKhMiP,"input":uDJxNtKl2gLkR6zC7OZWEf1cjvF059,"options":{"sentenceSplitter":YOHXqtbQTBfKerIZ,"origin":"translation.web","contextResults":eu1NswY9zkKC60I,"languageDetection":eu1NswY9zkKC60I}}
		cUwPtxlmTLe5nFD = MkuHT2blpeds34wXxDyvgitqWo.dumps(cUwPtxlmTLe5nFD)
		aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'POST',lI5ck2gjRCiw9bMTF0xHsG,cUwPtxlmTLe5nFD,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIBRARY-REVERSO_TRANSLATE-1st')
		if aaspUWRrCE4nLAlGf.succeeded:
			ov9nVhCfMkz37xPgQOS = aaspUWRrCE4nLAlGf.content
			ov9nVhCfMkz37xPgQOS = Bw6jaUcFxlqdDT8bC('dict',ov9nVhCfMkz37xPgQOS)
			uRK5jnwABa6SF0zq4hc2b += ixrPWKeFMnqJyVodX6D9AaO2+Vk54F7GcROfCy6HunEI.join(ov9nVhCfMkz37xPgQOS['translation'])
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b[RXnhpCUk4M1TvgJE:]
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000000','00000').replace('00000','0000').replace('0000','000')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0001',nMt0iueCy6K)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0002',d761ZWXHEvliYN45RzLP2)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0003',ZZoLlKyInXc08j2pTGJ)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0004','=====')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0005',',')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('0009','[RTL]')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000A','[CENTER]')
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.replace('000B',gSiK7EQVNXClOUDZGs)
	uRK5jnwABa6SF0zq4hc2b = uRK5jnwABa6SF0zq4hc2b.split('\n\n\n\n')
	return GtHz43sOcmoYbVlW2D9MJNEZXAxh+uRK5jnwABa6SF0zq4hc2b
def DV8Rb6KA4ijtQJu(p74HvfYKXiexEOAPR9BUNkq0u):
	c1HrMjdNBCh8Kb5kgx7SJni2 = cad8TeSyMUYmfsEO0.getSetting('av.language.translate')
	if not c1HrMjdNBCh8Kb5kgx7SJni2 or not p74HvfYKXiexEOAPR9BUNkq0u: return p74HvfYKXiexEOAPR9BUNkq0u
	Z70mXAdBUKWxtNFvJ6R1jQcs = cad8TeSyMUYmfsEO0.getSetting('av.language.provider')
	GqR6n3LFY9B2bkoAgWSJKhMiP = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
	ppsovXQ6zhdVR9fl3K8 = GqR6n3LFY9B2bkoAgWSJKhMiP+'__'+str(p74HvfYKXiexEOAPR9BUNkq0u)
	cad8TeSyMUYmfsEO0.setSetting('av.language.translate',Vk54F7GcROfCy6HunEI)
	uRK5jnwABa6SF0zq4hc2b = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','TRANSLATE_'+Z70mXAdBUKWxtNFvJ6R1jQcs,ppsovXQ6zhdVR9fl3K8)
	if not uRK5jnwABa6SF0zq4hc2b:
		if Z70mXAdBUKWxtNFvJ6R1jQcs=='GOOGLE': uRK5jnwABa6SF0zq4hc2b = zF3MQTbakCoZrS6x815mnN(p74HvfYKXiexEOAPR9BUNkq0u)
		elif Z70mXAdBUKWxtNFvJ6R1jQcs=='REVERSO': uRK5jnwABa6SF0zq4hc2b = r3HLucl7Ok(p74HvfYKXiexEOAPR9BUNkq0u)
		elif Z70mXAdBUKWxtNFvJ6R1jQcs=='GLOSBE': uRK5jnwABa6SF0zq4hc2b = TUMGi8Lgrt6SEnqJy7XZ50sVP(p74HvfYKXiexEOAPR9BUNkq0u)
		if len(p74HvfYKXiexEOAPR9BUNkq0u)==len(uRK5jnwABa6SF0zq4hc2b):
			FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'TRANSLATE_'+Z70mXAdBUKWxtNFvJ6R1jQcs,ppsovXQ6zhdVR9fl3K8,uRK5jnwABa6SF0zq4hc2b,mXdxepDh683FuUKlb0)
		else:
			uRK5jnwABa6SF0zq4hc2b = p74HvfYKXiexEOAPR9BUNkq0u
			qJAOp7HgfKeMQkDau('الترجمة فشلت','Translation Failed')
	cad8TeSyMUYmfsEO0.setSetting('av.language.translate','1')
	return uRK5jnwABa6SF0zq4hc2b
def TbFKCvLjE0OQISHfymke(whlLMpFrbVYQNHDACx8EgvuXeT,aWf04iQjCH5qKLzGMyupbd72Sgnr,E7Oap3UPWiS1eom2yM84nlkJGzwgXT,SGftUH5cmTR1siBNpC,o1ozf4PX9brOcW63any):
	hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,NBnKOkHsvLd,YWCso5NMKO,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx = whlLMpFrbVYQNHDACx8EgvuXeT
	WI67vSPgJC = []
	c1HrMjdNBCh8Kb5kgx7SJni2 = cad8TeSyMUYmfsEO0.getSetting('av.language.translate')
	if c1HrMjdNBCh8Kb5kgx7SJni2:
		HPkg0DJ42hqanKMfjzxrewG,sqftAjkHn3xmdcY540gKr6,P4xByNefcMEOIqkra1FHvUQL = [],[],[]
		if not WI67vSPgJC:
			for RIaBAlK2Yoz9Gp3jqxyiUVE in aWf04iQjCH5qKLzGMyupbd72Sgnr:
				EDy0Rs9liwjZvJY = RIaBAlK2Yoz9Gp3jqxyiUVE['name'].replace(kH6Bj7pebUaxIf,Vk54F7GcROfCy6HunEI).replace(ZdD4q6gA50I,Vk54F7GcROfCy6HunEI)
				AC9SerbxZRfM76 = RSuYINdeamsK0t.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
				if AC9SerbxZRfM76:
					GtHz43sOcmoYbVlW2D9MJNEZXAxh,vjU9VK4q3LhQaHGYlF,Caxf5RzMcJZI4YQp863vNDXAOHS,U6EFlBDHxNSr,EDy0Rs9liwjZvJY = AC9SerbxZRfM76[ufmXvxgoHGDwZtjsLkR05i]
					AC9SerbxZRfM76 = GtHz43sOcmoYbVlW2D9MJNEZXAxh+vjU9VK4q3LhQaHGYlF+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Caxf5RzMcJZI4YQp863vNDXAOHS+U6EFlBDHxNSr+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
				else:
					AC9SerbxZRfM76 = RSuYINdeamsK0t.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
					if AC9SerbxZRfM76:
						EDy0Rs9liwjZvJY,GtHz43sOcmoYbVlW2D9MJNEZXAxh,Caxf5RzMcJZI4YQp863vNDXAOHS,vjU9VK4q3LhQaHGYlF,U6EFlBDHxNSr = AC9SerbxZRfM76[ufmXvxgoHGDwZtjsLkR05i]
						AC9SerbxZRfM76 = GtHz43sOcmoYbVlW2D9MJNEZXAxh+vjU9VK4q3LhQaHGYlF+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+Caxf5RzMcJZI4YQp863vNDXAOHS+U6EFlBDHxNSr+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
					else: AC9SerbxZRfM76 = Vk54F7GcROfCy6HunEI
				IuWhtGZOPeozEUTC3KsiB = RSuYINdeamsK0t.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
				if IuWhtGZOPeozEUTC3KsiB: IuWhtGZOPeozEUTC3KsiB,EDy0Rs9liwjZvJY = IuWhtGZOPeozEUTC3KsiB[ufmXvxgoHGDwZtjsLkR05i]
				else: IuWhtGZOPeozEUTC3KsiB = Vk54F7GcROfCy6HunEI
				HPkg0DJ42hqanKMfjzxrewG.append(AC9SerbxZRfM76+IuWhtGZOPeozEUTC3KsiB)
				sqftAjkHn3xmdcY540gKr6.append(EDy0Rs9liwjZvJY)
			P4xByNefcMEOIqkra1FHvUQL = DV8Rb6KA4ijtQJu(sqftAjkHn3xmdcY540gKr6)
			if P4xByNefcMEOIqkra1FHvUQL:
				for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(len(aWf04iQjCH5qKLzGMyupbd72Sgnr)):
					RIaBAlK2Yoz9Gp3jqxyiUVE = aWf04iQjCH5qKLzGMyupbd72Sgnr[qf4yXuWZFYbxTEdkcQBUsAIgKH]
					RIaBAlK2Yoz9Gp3jqxyiUVE['name'] = HPkg0DJ42hqanKMfjzxrewG[qf4yXuWZFYbxTEdkcQBUsAIgKH]+P4xByNefcMEOIqkra1FHvUQL[qf4yXuWZFYbxTEdkcQBUsAIgKH]
					WI67vSPgJC.append(RIaBAlK2Yoz9Gp3jqxyiUVE)
	if WI67vSPgJC: aWf04iQjCH5qKLzGMyupbd72Sgnr = WI67vSPgJC
	KyOd1J9zai5s3,RNjpYtMsBuIVO2SG83QzyvaLE,I6GXqe8hmnsLcof = [],ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
	zuQWHGjdc79XEVwghp = cad8TeSyMUYmfsEO0.getSetting('av.status.menusimages')
	HoRQ3Xdr0wM = zuQWHGjdc79XEVwghp!='STOP'
	l2epPvf6s4g7CWXjJ = []
	if HoRQ3Xdr0wM:
		lG7Ni4JKFPL = CR3aLOVKSIme5XFoYi6M.path.join(dQxGp0knIfj,Yz6schq9wSmiu3IOdke0DXPj5W)
		try: l2epPvf6s4g7CWXjJ = CR3aLOVKSIme5XFoYi6M.listdir(lG7Ni4JKFPL)
		except:
			if not CR3aLOVKSIme5XFoYi6M.path.exists(lG7Ni4JKFPL):
				try: CR3aLOVKSIme5XFoYi6M.makedirs(lG7Ni4JKFPL)
				except: pass
	PHs5iO1gfw = kYHNaQpydAGB8J0TbIc32P('menu_item')
	Kl5O4RSMpXeVfhs26TmZz93iW7QYv = l2epPvf6s4g7CWXjJ
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog and yBxCpcVaPow1bztQm4X.platform=='win32':
		Kl5O4RSMpXeVfhs26TmZz93iW7QYv = []
		for s3ON1MCzgIKUF in l2epPvf6s4g7CWXjJ:
			s3ON1MCzgIKUF = s3ON1MCzgIKUF.decode('windows-1256').encode(AoCWwJHgUPKXI7u2lEzym)
			Kl5O4RSMpXeVfhs26TmZz93iW7QYv.append(s3ON1MCzgIKUF)
	for RIaBAlK2Yoz9Gp3jqxyiUVE in aWf04iQjCH5qKLzGMyupbd72Sgnr:
		EDy0Rs9liwjZvJY = RIaBAlK2Yoz9Gp3jqxyiUVE['name']
		if PvwFsJK23NbU8XWAx: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.encode(AoCWwJHgUPKXI7u2lEzym,'ignore').decode(AoCWwJHgUPKXI7u2lEzym)
		QzDYRdwp9y7xcTsq = RIaBAlK2Yoz9Gp3jqxyiUVE['context_menu']
		RMWxegr21v4cy0Sua = RIaBAlK2Yoz9Gp3jqxyiUVE['plot']
		XfetivpswWy = RIaBAlK2Yoz9Gp3jqxyiUVE['stars']
		c7E603KRhbToig9V4yx = RIaBAlK2Yoz9Gp3jqxyiUVE['image']
		hArRgv5l10sU2yVSCO9JBHbE = RIaBAlK2Yoz9Gp3jqxyiUVE['type']
		jJ4g2lcwIi6eVOoFQf = RIaBAlK2Yoz9Gp3jqxyiUVE['duration']
		PPoj1HKLOzlF2Jus94Vep5hDZXiG = RIaBAlK2Yoz9Gp3jqxyiUVE['isFolder']
		QQeJR9rGbHgj = RIaBAlK2Yoz9Gp3jqxyiUVE['newpath']
		Elfoau4LIrBt1PbgD = SZDFRGim3j8L.ListItem(EDy0Rs9liwjZvJY)
		Elfoau4LIrBt1PbgD.addContextMenuItems(QzDYRdwp9y7xcTsq)
		jjMc4TBbNAweGgaRKIzkE9 = eu1NswY9zkKC60I if HoRQ3Xdr0wM else YOHXqtbQTBfKerIZ
		if c7E603KRhbToig9V4yx:
			Elfoau4LIrBt1PbgD.setArt({'icon':c7E603KRhbToig9V4yx,'thumb':c7E603KRhbToig9V4yx,'fanart':c7E603KRhbToig9V4yx,'banner':c7E603KRhbToig9V4yx,'clearart':c7E603KRhbToig9V4yx,'poster':c7E603KRhbToig9V4yx,'clearlogo':c7E603KRhbToig9V4yx,'landscape':c7E603KRhbToig9V4yx})
			jjMc4TBbNAweGgaRKIzkE9 = eu1NswY9zkKC60I
		elif not jjMc4TBbNAweGgaRKIzkE9:
			jjMc4TBbNAweGgaRKIzkE9 = YOHXqtbQTBfKerIZ
			EDy0Rs9liwjZvJY = jrELQfAuqnWc9pBSPivOb5Ft(eu1NswY9zkKC60I,EDy0Rs9liwjZvJY)
			EDy0Rs9liwjZvJY = I1yWnMRpsx5(EDy0Rs9liwjZvJY)
			w6wJ8PugQftj = EDy0Rs9liwjZvJY+'.png'
			w5wMZjzqXFgRiNWxBS = CR3aLOVKSIme5XFoYi6M.path.join(lG7Ni4JKFPL,w6wJ8PugQftj)
			if w6wJ8PugQftj in Kl5O4RSMpXeVfhs26TmZz93iW7QYv:
				Elfoau4LIrBt1PbgD.setArt({'icon':w5wMZjzqXFgRiNWxBS,'thumb':w5wMZjzqXFgRiNWxBS,'fanart':w5wMZjzqXFgRiNWxBS,'banner':w5wMZjzqXFgRiNWxBS,'clearart':w5wMZjzqXFgRiNWxBS,'poster':w5wMZjzqXFgRiNWxBS,'clearlogo':w5wMZjzqXFgRiNWxBS,'landscape':w5wMZjzqXFgRiNWxBS})
				jjMc4TBbNAweGgaRKIzkE9 = eu1NswY9zkKC60I
			elif RNjpYtMsBuIVO2SG83QzyvaLE<40 and I6GXqe8hmnsLcof<=wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:
				try:
					DDiqvYfculICpzRhy = DD90GvrytmcnMxi7FP2K3C(PHs5iO1gfw,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EDy0Rs9liwjZvJY,'menu_item','center',eu1NswY9zkKC60I,w5wMZjzqXFgRiNWxBS)
					Elfoau4LIrBt1PbgD.setArt({'icon':w5wMZjzqXFgRiNWxBS,'thumb':w5wMZjzqXFgRiNWxBS,'fanart':w5wMZjzqXFgRiNWxBS,'banner':w5wMZjzqXFgRiNWxBS,'clearart':w5wMZjzqXFgRiNWxBS,'poster':w5wMZjzqXFgRiNWxBS,'clearlogo':w5wMZjzqXFgRiNWxBS,'landscape':w5wMZjzqXFgRiNWxBS})
					RNjpYtMsBuIVO2SG83QzyvaLE += pwxH3oREFm5v98BCZ1QVtzMJOc
					jjMc4TBbNAweGgaRKIzkE9 = eu1NswY9zkKC60I
					Kl5O4RSMpXeVfhs26TmZz93iW7QYv.append(w6wJ8PugQftj)
					if RNjpYtMsBuIVO2SG83QzyvaLE==m5DECdgjU4KqpVhyJ9A2b: qJAOp7HgfKeMQkDau('إضافة الكتابة لصور القائمة','انتظار',Gb6kwVlSQ4MU=500)
				except: I6GXqe8hmnsLcof += pwxH3oREFm5v98BCZ1QVtzMJOc
		if jjMc4TBbNAweGgaRKIzkE9:
			Elfoau4LIrBt1PbgD.setArt({'icon':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'thumb':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'fanart':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'banner':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'clearart':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'poster':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'clearlogo':KC4gIs8aTpjqBNhYkrdR9ZVJMz,'landscape':KC4gIs8aTpjqBNhYkrdR9ZVJMz})
		if gs15xoifvOt<20:
			if RMWxegr21v4cy0Sua: Elfoau4LIrBt1PbgD.setInfo('video',{'Plot':RMWxegr21v4cy0Sua,'PlotOutline':RMWxegr21v4cy0Sua})
			if XfetivpswWy: Elfoau4LIrBt1PbgD.setInfo('video',{'Rating':XfetivpswWy})
			if not c7E603KRhbToig9V4yx:
				Elfoau4LIrBt1PbgD.setInfo('video',{'Title':EDy0Rs9liwjZvJY})
			if hArRgv5l10sU2yVSCO9JBHbE=='video':
				Elfoau4LIrBt1PbgD.setInfo('video',{'mediatype':'tvshow'})
				if jJ4g2lcwIi6eVOoFQf: Elfoau4LIrBt1PbgD.setInfo('video',{'duration':jJ4g2lcwIi6eVOoFQf})
				Elfoau4LIrBt1PbgD.setProperty('IsPlayable','true')
		else:
			wwNQI7dTyoZgvrD6R9ckfCS1iJY = Elfoau4LIrBt1PbgD.getVideoInfoTag()
			if XfetivpswWy: wwNQI7dTyoZgvrD6R9ckfCS1iJY.setRating(float(XfetivpswWy))
			if not c7E603KRhbToig9V4yx:
				wwNQI7dTyoZgvrD6R9ckfCS1iJY.setTitle(EDy0Rs9liwjZvJY)
			if hArRgv5l10sU2yVSCO9JBHbE=='video':
				wwNQI7dTyoZgvrD6R9ckfCS1iJY.setMediaType('tvshow')
				if jJ4g2lcwIi6eVOoFQf: wwNQI7dTyoZgvrD6R9ckfCS1iJY.setDuration(jJ4g2lcwIi6eVOoFQf)
				Elfoau4LIrBt1PbgD.setProperty('IsPlayable','true')
		KyOd1J9zai5s3.append((QQeJR9rGbHgj,Elfoau4LIrBt1PbgD,PPoj1HKLOzlF2Jus94Vep5hDZXiG))
	n8NU7czo3KqG.setContent(YBCwDWyFAe4XpJNxQK2smG,'tvshows')
	EEreuD3mz2BG1yJFa6q = n8NU7czo3KqG.addDirectoryItems(YBCwDWyFAe4XpJNxQK2smG,KyOd1J9zai5s3)
	n8NU7czo3KqG.endOfDirectory(YBCwDWyFAe4XpJNxQK2smG,E7Oap3UPWiS1eom2yM84nlkJGzwgXT,SGftUH5cmTR1siBNpC,o1ozf4PX9brOcW63any)
	return EEreuD3mz2BG1yJFa6q
def v0TjHlLZqkRxUCpmNwSy8AndO(hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx=Vk54F7GcROfCy6HunEI,NBnKOkHsvLd=Vk54F7GcROfCy6HunEI,YWCso5NMKO=Vk54F7GcROfCy6HunEI,m6cEejX1UO0HwpuvqL7xGA2VWJ=Vk54F7GcROfCy6HunEI,GeDUpHhCROtPrx={}):
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace('\t',Vk54F7GcROfCy6HunEI)
	lI5ck2gjRCiw9bMTF0xHsG = lI5ck2gjRCiw9bMTF0xHsG.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace('\t',Vk54F7GcROfCy6HunEI)
	if '_SCRIPT_' in EDy0Rs9liwjZvJY:
		ILyVox7aiXM148nz,EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.split('_SCRIPT_',pwxH3oREFm5v98BCZ1QVtzMJOc)
		if ILyVox7aiXM148nz not in list(h9zFQKnsNL.menuItemsDICT.keys()): h9zFQKnsNL.menuItemsDICT[ILyVox7aiXM148nz] = []
		h9zFQKnsNL.menuItemsDICT[ILyVox7aiXM148nz].append([hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,NBnKOkHsvLd,YWCso5NMKO,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx])
	h9zFQKnsNL.menuItemsLIST.append([hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,NBnKOkHsvLd,YWCso5NMKO,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx])
	return
def Uo7Tbc29Eu(w23PUMk7qXWCjF8):
	if PvwFsJK23NbU8XWAx: from html import unescape as _h6orvNU9tCV13b
	else:
		from HTMLParser import HTMLParser as pSJ7HV0kcgmnFf3dL
		_h6orvNU9tCV13b = pSJ7HV0kcgmnFf3dL().unescape
	if '&' in w23PUMk7qXWCjF8 and ';' in w23PUMk7qXWCjF8:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: w23PUMk7qXWCjF8 = w23PUMk7qXWCjF8.decode(AoCWwJHgUPKXI7u2lEzym)
		w23PUMk7qXWCjF8 = _h6orvNU9tCV13b(w23PUMk7qXWCjF8)
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: w23PUMk7qXWCjF8 = w23PUMk7qXWCjF8.encode(AoCWwJHgUPKXI7u2lEzym)
	return w23PUMk7qXWCjF8
def ww25jXuxtpK1TOJEbGUgrm8(w23PUMk7qXWCjF8):
	if '\\u' in w23PUMk7qXWCjF8:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: w23PUMk7qXWCjF8 = w23PUMk7qXWCjF8.decode('unicode_escape','ignore').encode(AoCWwJHgUPKXI7u2lEzym)
		elif PvwFsJK23NbU8XWAx: w23PUMk7qXWCjF8 = w23PUMk7qXWCjF8.encode(AoCWwJHgUPKXI7u2lEzym).decode('unicode_escape','ignore')
	return w23PUMk7qXWCjF8
def HmN7xPhSEQLzrqU(jXd6r2n3GO14Ws9IATUapDYKE7Sy,tf8WoQVwc4yIxnrm,ltpWMgNKmRjwu1T,hw8ipZ3lcrYDXG6VWxPHsO,YWCso5NMKO,P2eFqf3CLhWk7I,PdH18iXBxefn,ood1tZKe9yrgqpSUODxFschnu4NBa,DhOVIJAdQ80smzBy6RjSPbLH):
	qU5pySBwjD60FsJgPcVhACNr = CR3aLOVKSIme5XFoYi6M.path.dirname(DhOVIJAdQ80smzBy6RjSPbLH)
	if not CR3aLOVKSIme5XFoYi6M.path.exists(qU5pySBwjD60FsJgPcVhACNr):
		try: CR3aLOVKSIme5XFoYi6M.makedirs(qU5pySBwjD60FsJgPcVhACNr)
		except: pass
	PPHfAMzEc9Tm12lv3NUwjYVpKS6Q = kYHNaQpydAGB8J0TbIc32P(P2eFqf3CLhWk7I)
	DDiqvYfculICpzRhy = DD90GvrytmcnMxi7FP2K3C(PPHfAMzEc9Tm12lv3NUwjYVpKS6Q,jXd6r2n3GO14Ws9IATUapDYKE7Sy,tf8WoQVwc4yIxnrm,ltpWMgNKmRjwu1T,hw8ipZ3lcrYDXG6VWxPHsO,YWCso5NMKO,P2eFqf3CLhWk7I,PdH18iXBxefn,ood1tZKe9yrgqpSUODxFschnu4NBa,DhOVIJAdQ80smzBy6RjSPbLH)
	return DDiqvYfculICpzRhy
def kYHNaQpydAGB8J0TbIc32P(P2eFqf3CLhWk7I):
	ifVuGQCY1jo2DP7wEkSMb = m5DECdgjU4KqpVhyJ9A2b
	MLytgvmaspUHQ27fT = 20
	REPxpAVZ1LwoGet8JN = 20
	FZ9248QeYjOcNqt1DEupIB = ufmXvxgoHGDwZtjsLkR05i
	bfmxVTBYw32uyAIKOJR7Z6C = 'center'
	pvAxcJq85PINS = ufmXvxgoHGDwZtjsLkR05i
	ehMVxJC5ug3rISOkRYnlaA = 19
	wpmnI1bEFl8fAMkXe = 30
	TcSGaJXfL9pWhKtl3jFMHQz265Oe = 8
	NUaTzn8HlrKCFZy = YOHXqtbQTBfKerIZ
	VhnNIcG8f96S0Er = 375
	XYK5t61rU7vG4mkcSF0baCRQqVOE = 410
	uugRVqSHNFeizajpYI09cLkAyUtd = 50
	F1AgMnOuWHJp562 = 280
	fUuk9CQBcJiANm6rS = 28
	LbiVWaxcqzXEdA1NCIwu7KY56 = m5DECdgjU4KqpVhyJ9A2b
	jZveq9U12L = ufmXvxgoHGDwZtjsLkR05i
	wUCqeFYldV4Zk = 31
	eKC98fmBqMvINH2jsnTGbduz = [36,32,28]
	from PIL import ImageDraw as znoB95HRCwUOrcKfY,ImageFont as PwU9AIMTYtLvbFeKjm,Image as IRWaJDtc8pPE4
	if 'notification' in P2eFqf3CLhWk7I:
		if P2eFqf3CLhWk7I=='notification_regular':
			DthKpx0NySn4Ai2O1s3dj = 117
			bfmxVTBYw32uyAIKOJR7Z6C = 'left'
			NUaTzn8HlrKCFZy = eu1NswY9zkKC60I
		elif P2eFqf3CLhWk7I=='notification_auto':
			DthKpx0NySn4Ai2O1s3dj = 'UPPER'
			bfmxVTBYw32uyAIKOJR7Z6C = 'right'
			FZ9248QeYjOcNqt1DEupIB = 10
		ztBp1i982dHm = 720
		eKC98fmBqMvINH2jsnTGbduz = [33,33,33]
		REPxpAVZ1LwoGet8JN = 20
		MLytgvmaspUHQ27fT = ufmXvxgoHGDwZtjsLkR05i
		wpmnI1bEFl8fAMkXe = 20
		ehMVxJC5ug3rISOkRYnlaA = 35
	elif P2eFqf3CLhWk7I=='menu_item':
		eKC98fmBqMvINH2jsnTGbduz,ztBp1i982dHm,DthKpx0NySn4Ai2O1s3dj = [28,28,28],200,250
		pvAxcJq85PINS,wpmnI1bEFl8fAMkXe,ehMVxJC5ug3rISOkRYnlaA, = ufmXvxgoHGDwZtjsLkR05i,-12,-30
		MLytgvmaspUHQ27fT = ufmXvxgoHGDwZtjsLkR05i
		BaJOmRNQ5vdSe3W8xpHDkyCc7UP = IRWaJDtc8pPE4.open(KC4gIs8aTpjqBNhYkrdR9ZVJMz)
		TTtpQnEySZ8RM = IRWaJDtc8pPE4.new('RGBA',(ztBp1i982dHm,DthKpx0NySn4Ai2O1s3dj),(255,ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i,255))
	elif P2eFqf3CLhWk7I=='confirm_smallfont': eKC98fmBqMvINH2jsnTGbduz,DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = [28,24,20],500,900
	elif P2eFqf3CLhWk7I=='confirm_mediumfont': eKC98fmBqMvINH2jsnTGbduz,DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = [32,28,24],500,900
	elif P2eFqf3CLhWk7I=='confirm_bigfont': eKC98fmBqMvINH2jsnTGbduz,DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = [36,32,28],500,900
	elif P2eFqf3CLhWk7I=='textview_bigfont': DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = 740,1270
	elif P2eFqf3CLhWk7I=='textview_bigfont_long': DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = 'UPPER',1270
	elif P2eFqf3CLhWk7I=='textview_smallfont': eKC98fmBqMvINH2jsnTGbduz,DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = [28,23,18],740,1270
	elif P2eFqf3CLhWk7I=='textview_smallfont_long': eKC98fmBqMvINH2jsnTGbduz,DthKpx0NySn4Ai2O1s3dj,ztBp1i982dHm = [28,23,18],'UPPER',1270
	BefcnGZSIuilTN42Fw,UxOmp6Vh4rL0DH,LYid8ywpZkn56brQmlH = eKC98fmBqMvINH2jsnTGbduz
	jNE4PSxMQRf5GgLXIz6pda0Cnyq = PwU9AIMTYtLvbFeKjm.truetype(BsdjXEqRlKmkePz8F,size=BefcnGZSIuilTN42Fw)
	krYZxcbAT9HSo5XPfIRnQOJwyG30 = PwU9AIMTYtLvbFeKjm.truetype(BsdjXEqRlKmkePz8F,size=UxOmp6Vh4rL0DH)
	eeWVgstkamuFQTw7K2yG9HJhMD = PwU9AIMTYtLvbFeKjm.truetype(BsdjXEqRlKmkePz8F,size=LYid8ywpZkn56brQmlH)
	WcQRiqtnFbH = ztBp1i982dHm-wpmnI1bEFl8fAMkXe*RXnhpCUk4M1TvgJE
	kOZlFcu9r1MvfqQDnPxg0swW8aj6X = IRWaJDtc8pPE4.new('RGBA',(WcQRiqtnFbH,100),(255,255,255,ufmXvxgoHGDwZtjsLkR05i))
	AIvbDBuUVjQ90SgyRz7YJZO = znoB95HRCwUOrcKfY.Draw(kOZlFcu9r1MvfqQDnPxg0swW8aj6X)
	l4AQu6HhEtixwz8v,TyPBQCJMb2w1vdSfiHrsEpYjaRO5 = AIvbDBuUVjQ90SgyRz7YJZO.textsize('HHH BBB 888 000',font=jNE4PSxMQRf5GgLXIz6pda0Cnyq)
	HRCX3il8YOF,ZWSX5F6jAyJouDmgdz19OHPM4q = AIvbDBuUVjQ90SgyRz7YJZO.textsize('HHH BBB 888 000',font=krYZxcbAT9HSo5XPfIRnQOJwyG30)
	Gih2LFa4dq = {'delete_harakat':eu1NswY9zkKC60I,'support_ligatures':YOHXqtbQTBfKerIZ,'ARABIC LIGATURE ALLAH':eu1NswY9zkKC60I}
	from arabic_reshaper import ArabicReshaper as jNcESWmx7iQRu
	VajUZsr7AEL2KYORif6e = jNcESWmx7iQRu(configuration=Gih2LFa4dq)
	PPHfAMzEc9Tm12lv3NUwjYVpKS6Q = {}
	QFYxHw64BqZKsi8ta = locals()
	for ddUWzEgl3bhS0oi5MkuT in QFYxHw64BqZKsi8ta: PPHfAMzEc9Tm12lv3NUwjYVpKS6Q[ddUWzEgl3bhS0oi5MkuT] = QFYxHw64BqZKsi8ta[ddUWzEgl3bhS0oi5MkuT]
	return PPHfAMzEc9Tm12lv3NUwjYVpKS6Q
def DD90GvrytmcnMxi7FP2K3C(PPHfAMzEc9Tm12lv3NUwjYVpKS6Q,jXd6r2n3GO14Ws9IATUapDYKE7Sy,tf8WoQVwc4yIxnrm,ltpWMgNKmRjwu1T,hw8ipZ3lcrYDXG6VWxPHsO,YWCso5NMKO,P2eFqf3CLhWk7I,PdH18iXBxefn,ood1tZKe9yrgqpSUODxFschnu4NBa,DhOVIJAdQ80smzBy6RjSPbLH):
	for ddUWzEgl3bhS0oi5MkuT in PPHfAMzEc9Tm12lv3NUwjYVpKS6Q: globals()[ddUWzEgl3bhS0oi5MkuT] = PPHfAMzEc9Tm12lv3NUwjYVpKS6Q[ddUWzEgl3bhS0oi5MkuT]
	global fUuk9CQBcJiANm6rS,LbiVWaxcqzXEdA1NCIwu7KY56
	if P2eFqf3CLhWk7I!='menu_item':
		c1HrMjdNBCh8Kb5kgx7SJni2 = cad8TeSyMUYmfsEO0.getSetting('av.language.translate')
		if c1HrMjdNBCh8Kb5kgx7SJni2:
			if jXd6r2n3GO14Ws9IATUapDYKE7Sy=='نعم  Yes': jXd6r2n3GO14Ws9IATUapDYKE7Sy = 'Yes'
			elif jXd6r2n3GO14Ws9IATUapDYKE7Sy=='كلا  No': jXd6r2n3GO14Ws9IATUapDYKE7Sy = 'No'
			if tf8WoQVwc4yIxnrm=='نعم  Yes': tf8WoQVwc4yIxnrm = 'Yes'
			elif tf8WoQVwc4yIxnrm=='كلا  No': tf8WoQVwc4yIxnrm = 'No'
			if ltpWMgNKmRjwu1T=='نعم  Yes': ltpWMgNKmRjwu1T = 'Yes'
			elif ltpWMgNKmRjwu1T=='كلا  No': ltpWMgNKmRjwu1T = 'No'
			P8JgauLzVmeTiRMy39nADHj = DV8Rb6KA4ijtQJu([jXd6r2n3GO14Ws9IATUapDYKE7Sy,tf8WoQVwc4yIxnrm,ltpWMgNKmRjwu1T,hw8ipZ3lcrYDXG6VWxPHsO,YWCso5NMKO])
			if P8JgauLzVmeTiRMy39nADHj: jXd6r2n3GO14Ws9IATUapDYKE7Sy,tf8WoQVwc4yIxnrm,ltpWMgNKmRjwu1T,hw8ipZ3lcrYDXG6VWxPHsO,YWCso5NMKO = P8JgauLzVmeTiRMy39nADHj
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
		YWCso5NMKO = YWCso5NMKO.decode(AoCWwJHgUPKXI7u2lEzym)
		hw8ipZ3lcrYDXG6VWxPHsO = hw8ipZ3lcrYDXG6VWxPHsO.decode(AoCWwJHgUPKXI7u2lEzym)
		jXd6r2n3GO14Ws9IATUapDYKE7Sy = jXd6r2n3GO14Ws9IATUapDYKE7Sy.decode(AoCWwJHgUPKXI7u2lEzym)
		tf8WoQVwc4yIxnrm = tf8WoQVwc4yIxnrm.decode(AoCWwJHgUPKXI7u2lEzym)
		ltpWMgNKmRjwu1T = ltpWMgNKmRjwu1T.decode(AoCWwJHgUPKXI7u2lEzym)
	Ip6L4aKQTXDB2 = hw8ipZ3lcrYDXG6VWxPHsO.count(ixrPWKeFMnqJyVodX6D9AaO2)+pwxH3oREFm5v98BCZ1QVtzMJOc
	n3xSs1P9wz8MkYrZm = MLytgvmaspUHQ27fT+Ip6L4aKQTXDB2*(TyPBQCJMb2w1vdSfiHrsEpYjaRO5+FZ9248QeYjOcNqt1DEupIB)-FZ9248QeYjOcNqt1DEupIB
	if YWCso5NMKO:
		VqKS3kPjtn2YBbDfTH = ZWSX5F6jAyJouDmgdz19OHPM4q+TcSGaJXfL9pWhKtl3jFMHQz265Oe
		P58aECSHzZ2 = VajUZsr7AEL2KYORif6e.reshape(YWCso5NMKO)
		if NUaTzn8HlrKCFZy:
			tbsFxeNzWYKTRgCjMcPGrH8LVB = L8kmH6PQDwrutONEVYc2jvG7iCUqI4(AIvbDBuUVjQ90SgyRz7YJZO,krYZxcbAT9HSo5XPfIRnQOJwyG30,P58aECSHzZ2,UxOmp6Vh4rL0DH,WcQRiqtnFbH,VqKS3kPjtn2YBbDfTH)
			gFsCATpQHltWZqGb5k9UuB0nyf1EX = NWUusyJwLQ31xMopgfSBb(tbsFxeNzWYKTRgCjMcPGrH8LVB)
			oRUmxynKQk = gFsCATpQHltWZqGb5k9UuB0nyf1EX.count(ixrPWKeFMnqJyVodX6D9AaO2)+pwxH3oREFm5v98BCZ1QVtzMJOc
			wwCBHYarzR = ehMVxJC5ug3rISOkRYnlaA+oRUmxynKQk*VqKS3kPjtn2YBbDfTH-TcSGaJXfL9pWhKtl3jFMHQz265Oe
		else:
			wwCBHYarzR = ehMVxJC5ug3rISOkRYnlaA+ZWSX5F6jAyJouDmgdz19OHPM4q
			gFsCATpQHltWZqGb5k9UuB0nyf1EX = P58aECSHzZ2.split(ixrPWKeFMnqJyVodX6D9AaO2)[ufmXvxgoHGDwZtjsLkR05i]
			tbsFxeNzWYKTRgCjMcPGrH8LVB = P58aECSHzZ2.split(ixrPWKeFMnqJyVodX6D9AaO2)[ufmXvxgoHGDwZtjsLkR05i]
	else: wwCBHYarzR = ehMVxJC5ug3rISOkRYnlaA
	ORiGWJq1EvcVzgM0Tt2UofNryLXl = jZveq9U12L+wUCqeFYldV4Zk
	if ood1tZKe9yrgqpSUODxFschnu4NBa:
		I1RxjXm2tJq = XYK5t61rU7vG4mkcSF0baCRQqVOE-VhnNIcG8f96S0Er
		ORiGWJq1EvcVzgM0Tt2UofNryLXl += I1RxjXm2tJq
	else: I1RxjXm2tJq = ufmXvxgoHGDwZtjsLkR05i
	if jXd6r2n3GO14Ws9IATUapDYKE7Sy or tf8WoQVwc4yIxnrm or ltpWMgNKmRjwu1T: ORiGWJq1EvcVzgM0Tt2UofNryLXl += uugRVqSHNFeizajpYI09cLkAyUtd
	DDiqvYfculICpzRhy = DthKpx0NySn4Ai2O1s3dj if DthKpx0NySn4Ai2O1s3dj!='UPPER' else n3xSs1P9wz8MkYrZm+wwCBHYarzR+ORiGWJq1EvcVzgM0Tt2UofNryLXl
	kOZlFcu9r1MvfqQDnPxg0swW8aj6X = IRWaJDtc8pPE4.new('RGBA',(ztBp1i982dHm,DDiqvYfculICpzRhy),(255,255,255,ufmXvxgoHGDwZtjsLkR05i))
	FEptu4DjWAhS7GUNYQnq5bgiRfcX19 = znoB95HRCwUOrcKfY.Draw(kOZlFcu9r1MvfqQDnPxg0swW8aj6X)
	ouh9IeEq2G8FaHgtjlzR = DDiqvYfculICpzRhy-n3xSs1P9wz8MkYrZm-ORiGWJq1EvcVzgM0Tt2UofNryLXl-ehMVxJC5ug3rISOkRYnlaA
	if not tf8WoQVwc4yIxnrm and jXd6r2n3GO14Ws9IATUapDYKE7Sy and ltpWMgNKmRjwu1T:
		fUuk9CQBcJiANm6rS += 105
		LbiVWaxcqzXEdA1NCIwu7KY56 -= 110
	import bidi.algorithm as XTO5h0Fqprge621
	if hw8ipZ3lcrYDXG6VWxPHsO:
		nfTkj3h1aVtYgxMAquR = MLytgvmaspUHQ27fT
		hw8ipZ3lcrYDXG6VWxPHsO = XTO5h0Fqprge621.get_display(VajUZsr7AEL2KYORif6e.reshape(hw8ipZ3lcrYDXG6VWxPHsO))
		p74HvfYKXiexEOAPR9BUNkq0u = hw8ipZ3lcrYDXG6VWxPHsO.splitlines()
		for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in p74HvfYKXiexEOAPR9BUNkq0u:
			if uDJxNtKl2gLkR6zC7OZWEf1cjvF059:
				ejOVHn028XJxaqEM1yt3U,aLmDYNGAwPHdTfgR8O19vkMthoxqie = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(uDJxNtKl2gLkR6zC7OZWEf1cjvF059,font=jNE4PSxMQRf5GgLXIz6pda0Cnyq)
				if bfmxVTBYw32uyAIKOJR7Z6C=='center': gcopUlbe3NSB = ifVuGQCY1jo2DP7wEkSMb+(ztBp1i982dHm-ejOVHn028XJxaqEM1yt3U)/RXnhpCUk4M1TvgJE
				elif bfmxVTBYw32uyAIKOJR7Z6C=='right': gcopUlbe3NSB = ifVuGQCY1jo2DP7wEkSMb+ztBp1i982dHm-ejOVHn028XJxaqEM1yt3U-REPxpAVZ1LwoGet8JN
				elif bfmxVTBYw32uyAIKOJR7Z6C=='left': gcopUlbe3NSB = ifVuGQCY1jo2DP7wEkSMb+REPxpAVZ1LwoGet8JN
				FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((gcopUlbe3NSB,nfTkj3h1aVtYgxMAquR),uDJxNtKl2gLkR6zC7OZWEf1cjvF059,font=jNE4PSxMQRf5GgLXIz6pda0Cnyq,fill='yellow')
			nfTkj3h1aVtYgxMAquR += BefcnGZSIuilTN42Fw+FZ9248QeYjOcNqt1DEupIB
	if jXd6r2n3GO14Ws9IATUapDYKE7Sy or tf8WoQVwc4yIxnrm or ltpWMgNKmRjwu1T:
		vASptxV783BwdegPK2 = n3xSs1P9wz8MkYrZm+ouh9IeEq2G8FaHgtjlzR+ehMVxJC5ug3rISOkRYnlaA+I1RxjXm2tJq+jZveq9U12L
		if jXd6r2n3GO14Ws9IATUapDYKE7Sy:
			jXd6r2n3GO14Ws9IATUapDYKE7Sy = XTO5h0Fqprge621.get_display(VajUZsr7AEL2KYORif6e.reshape(jXd6r2n3GO14Ws9IATUapDYKE7Sy))
			usLpaNMQBAU,bxvyX1eZKkR8VwdapjQE = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(jXd6r2n3GO14Ws9IATUapDYKE7Sy,font=eeWVgstkamuFQTw7K2yG9HJhMD)
			cxFSoWr1gD8Vfpn64CIdAiZM = fUuk9CQBcJiANm6rS+ufmXvxgoHGDwZtjsLkR05i*(LbiVWaxcqzXEdA1NCIwu7KY56+F1AgMnOuWHJp562)+(F1AgMnOuWHJp562-usLpaNMQBAU)/RXnhpCUk4M1TvgJE
			FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((cxFSoWr1gD8Vfpn64CIdAiZM,vASptxV783BwdegPK2),jXd6r2n3GO14Ws9IATUapDYKE7Sy,font=eeWVgstkamuFQTw7K2yG9HJhMD,fill='yellow')
		if tf8WoQVwc4yIxnrm:
			tf8WoQVwc4yIxnrm = XTO5h0Fqprge621.get_display(VajUZsr7AEL2KYORif6e.reshape(tf8WoQVwc4yIxnrm))
			nNHR19Ld5Vq6F7WBgclC,UjdemXF4pw5QMI = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(tf8WoQVwc4yIxnrm,font=eeWVgstkamuFQTw7K2yG9HJhMD)
			Ni3fqAePoFxO = fUuk9CQBcJiANm6rS+pwxH3oREFm5v98BCZ1QVtzMJOc*(LbiVWaxcqzXEdA1NCIwu7KY56+F1AgMnOuWHJp562)+(F1AgMnOuWHJp562-nNHR19Ld5Vq6F7WBgclC)/RXnhpCUk4M1TvgJE
			FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((Ni3fqAePoFxO,vASptxV783BwdegPK2),tf8WoQVwc4yIxnrm,font=eeWVgstkamuFQTw7K2yG9HJhMD,fill='yellow')
		if ltpWMgNKmRjwu1T:
			ltpWMgNKmRjwu1T = XTO5h0Fqprge621.get_display(VajUZsr7AEL2KYORif6e.reshape(ltpWMgNKmRjwu1T))
			iJMHTmoPtycgxR5lKLA,yxzLtCSKpVbRaDncTos0mfE2U3dg = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(ltpWMgNKmRjwu1T,font=eeWVgstkamuFQTw7K2yG9HJhMD)
			XsYtwKeabrinkqmORcMNUSC = fUuk9CQBcJiANm6rS+RXnhpCUk4M1TvgJE*(LbiVWaxcqzXEdA1NCIwu7KY56+F1AgMnOuWHJp562)+(F1AgMnOuWHJp562-iJMHTmoPtycgxR5lKLA)/RXnhpCUk4M1TvgJE
			FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((XsYtwKeabrinkqmORcMNUSC,vASptxV783BwdegPK2),ltpWMgNKmRjwu1T,font=eeWVgstkamuFQTw7K2yG9HJhMD,fill='yellow')
	if YWCso5NMKO:
		ss7THajkKY,c6B83aQjkOiMx4Vf = [],[]
		tbsFxeNzWYKTRgCjMcPGrH8LVB = qTDYyX6PHvFomVw(tbsFxeNzWYKTRgCjMcPGrH8LVB)
		DDIUfNocHuLxRT2ia9 = tbsFxeNzWYKTRgCjMcPGrH8LVB.split('_sss__newline_')
		for pqDvT1NicJ9Lh in DDIUfNocHuLxRT2ia9:
			x39xoZBAe7zfMk0sVIgjmH = PdH18iXBxefn
			if   '_sss__lineleft_' in pqDvT1NicJ9Lh: x39xoZBAe7zfMk0sVIgjmH = 'left'
			elif '_sss__lineright_' in pqDvT1NicJ9Lh: x39xoZBAe7zfMk0sVIgjmH = 'right'
			elif '_sss__linecenter_' in pqDvT1NicJ9Lh: x39xoZBAe7zfMk0sVIgjmH = 'center'
			Mj7xDLAyQYW04VnEwb12zZlucR = pqDvT1NicJ9Lh
			yw7T5oM2DIuiSAbKLJ = RSuYINdeamsK0t.findall('_sss__.*?_',pqDvT1NicJ9Lh,RSuYINdeamsK0t.DOTALL)
			for KhDQdV69OGk78wMP2yAb0 in yw7T5oM2DIuiSAbKLJ: Mj7xDLAyQYW04VnEwb12zZlucR = Mj7xDLAyQYW04VnEwb12zZlucR.replace(KhDQdV69OGk78wMP2yAb0,Vk54F7GcROfCy6HunEI)
			if Mj7xDLAyQYW04VnEwb12zZlucR==Vk54F7GcROfCy6HunEI: ejOVHn028XJxaqEM1yt3U,aLmDYNGAwPHdTfgR8O19vkMthoxqie = ufmXvxgoHGDwZtjsLkR05i,VqKS3kPjtn2YBbDfTH
			else: ejOVHn028XJxaqEM1yt3U,aLmDYNGAwPHdTfgR8O19vkMthoxqie = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(Mj7xDLAyQYW04VnEwb12zZlucR,font=krYZxcbAT9HSo5XPfIRnQOJwyG30)
			if   x39xoZBAe7zfMk0sVIgjmH=='left': LLkWszg5CotbP0frUYhET1ZGunI = pvAxcJq85PINS+wpmnI1bEFl8fAMkXe
			elif x39xoZBAe7zfMk0sVIgjmH=='right': LLkWszg5CotbP0frUYhET1ZGunI = pvAxcJq85PINS+wpmnI1bEFl8fAMkXe+WcQRiqtnFbH-ejOVHn028XJxaqEM1yt3U
			elif x39xoZBAe7zfMk0sVIgjmH=='center': LLkWszg5CotbP0frUYhET1ZGunI = pvAxcJq85PINS+wpmnI1bEFl8fAMkXe+(WcQRiqtnFbH-ejOVHn028XJxaqEM1yt3U)/RXnhpCUk4M1TvgJE
			if LLkWszg5CotbP0frUYhET1ZGunI<wpmnI1bEFl8fAMkXe: LLkWszg5CotbP0frUYhET1ZGunI = pvAxcJq85PINS+wpmnI1bEFl8fAMkXe
			ss7THajkKY.append(LLkWszg5CotbP0frUYhET1ZGunI)
			c6B83aQjkOiMx4Vf.append(ejOVHn028XJxaqEM1yt3U)
		LLkWszg5CotbP0frUYhET1ZGunI = ss7THajkKY[ufmXvxgoHGDwZtjsLkR05i]
		CdsxyZ3tuoRc6WG = tbsFxeNzWYKTRgCjMcPGrH8LVB.split('_sss_')
		W8rxQs50dC3LvNMIlTEYPcjRh4 = (255,255,255,255)
		RRXSujIhvcw = W8rxQs50dC3LvNMIlTEYPcjRh4
		Vby8wROjedpUl,rXDjZkRx2bGMoN3uVTBg7Id = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
		BB0viwqeHyUh = eu1NswY9zkKC60I
		CUzVIvNhZFJ = ufmXvxgoHGDwZtjsLkR05i
		qKHADIk5vUt2MSRTrfcbam30LC8 = n3xSs1P9wz8MkYrZm+ehMVxJC5ug3rISOkRYnlaA/RXnhpCUk4M1TvgJE
		if wwCBHYarzR<(ouh9IeEq2G8FaHgtjlzR+ehMVxJC5ug3rISOkRYnlaA):
			mh6Rd4oAFtQq5zEOH9nN = (ouh9IeEq2G8FaHgtjlzR+ehMVxJC5ug3rISOkRYnlaA-wwCBHYarzR)/RXnhpCUk4M1TvgJE
			qKHADIk5vUt2MSRTrfcbam30LC8 = n3xSs1P9wz8MkYrZm+ehMVxJC5ug3rISOkRYnlaA+mh6Rd4oAFtQq5zEOH9nN-ZWSX5F6jAyJouDmgdz19OHPM4q/RXnhpCUk4M1TvgJE
		for uDJxNtKl2gLkR6zC7OZWEf1cjvF059 in CdsxyZ3tuoRc6WG:
			if not uDJxNtKl2gLkR6zC7OZWEf1cjvF059 or (uDJxNtKl2gLkR6zC7OZWEf1cjvF059 and ord(uDJxNtKl2gLkR6zC7OZWEf1cjvF059[ufmXvxgoHGDwZtjsLkR05i])==65279): continue
			ZjzuW4lYLkgq0m = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_newline_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			lC8Z02AXpTGIcS = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_newcolor',pwxH3oREFm5v98BCZ1QVtzMJOc)
			UUkZBXdRIbywo = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_endcolor_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			QaT2ZBFzpDPIg = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_linertl_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			doxpU9AZ6wrXfNJkO7YTRsgGuPW = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_lineleft_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			hXB3EOCGc5Zv8P7Sempu1wWrD = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_lineright_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			dblzOgQcCe2LS6fnPJBXj38 = uDJxNtKl2gLkR6zC7OZWEf1cjvF059.split('_linecenter_',pwxH3oREFm5v98BCZ1QVtzMJOc)
			if len(ZjzuW4lYLkgq0m)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				CUzVIvNhZFJ += pwxH3oREFm5v98BCZ1QVtzMJOc
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = ZjzuW4lYLkgq0m[pwxH3oREFm5v98BCZ1QVtzMJOc]
				Vby8wROjedpUl = ufmXvxgoHGDwZtjsLkR05i
				LLkWszg5CotbP0frUYhET1ZGunI = ss7THajkKY[CUzVIvNhZFJ]
				rXDjZkRx2bGMoN3uVTBg7Id += VqKS3kPjtn2YBbDfTH
				BB0viwqeHyUh = eu1NswY9zkKC60I
			elif len(lC8Z02AXpTGIcS)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = lC8Z02AXpTGIcS[pwxH3oREFm5v98BCZ1QVtzMJOc]
				RRXSujIhvcw = uDJxNtKl2gLkR6zC7OZWEf1cjvF059[ufmXvxgoHGDwZtjsLkR05i:8]
				RRXSujIhvcw = '#'+RRXSujIhvcw[RXnhpCUk4M1TvgJE:]
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = uDJxNtKl2gLkR6zC7OZWEf1cjvF059[9:]
			elif len(UUkZBXdRIbywo)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = UUkZBXdRIbywo[pwxH3oREFm5v98BCZ1QVtzMJOc]
				RRXSujIhvcw = W8rxQs50dC3LvNMIlTEYPcjRh4
			elif len(QaT2ZBFzpDPIg)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = QaT2ZBFzpDPIg[pwxH3oREFm5v98BCZ1QVtzMJOc]
				BB0viwqeHyUh = YOHXqtbQTBfKerIZ
				Vby8wROjedpUl = c6B83aQjkOiMx4Vf[CUzVIvNhZFJ]
			elif len(doxpU9AZ6wrXfNJkO7YTRsgGuPW)>1: uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = doxpU9AZ6wrXfNJkO7YTRsgGuPW[pwxH3oREFm5v98BCZ1QVtzMJOc]
			elif len(hXB3EOCGc5Zv8P7Sempu1wWrD)>1: uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = hXB3EOCGc5Zv8P7Sempu1wWrD[pwxH3oREFm5v98BCZ1QVtzMJOc]
			elif len(dblzOgQcCe2LS6fnPJBXj38)>1: uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = dblzOgQcCe2LS6fnPJBXj38[pwxH3oREFm5v98BCZ1QVtzMJOc]
			if uDJxNtKl2gLkR6zC7OZWEf1cjvF059:
				VdkP4aDFTBM6mc = qKHADIk5vUt2MSRTrfcbam30LC8+rXDjZkRx2bGMoN3uVTBg7Id
				uDJxNtKl2gLkR6zC7OZWEf1cjvF059 = XTO5h0Fqprge621.get_display(uDJxNtKl2gLkR6zC7OZWEf1cjvF059)
				ejOVHn028XJxaqEM1yt3U,aLmDYNGAwPHdTfgR8O19vkMthoxqie = FEptu4DjWAhS7GUNYQnq5bgiRfcX19.textsize(uDJxNtKl2gLkR6zC7OZWEf1cjvF059,font=krYZxcbAT9HSo5XPfIRnQOJwyG30)
				if BB0viwqeHyUh: Vby8wROjedpUl -= ejOVHn028XJxaqEM1yt3U
				DHh7jWMK4YZuqNVpBl1QJmGOcoEakS = LLkWszg5CotbP0frUYhET1ZGunI+Vby8wROjedpUl
				FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((DHh7jWMK4YZuqNVpBl1QJmGOcoEakS,VdkP4aDFTBM6mc),uDJxNtKl2gLkR6zC7OZWEf1cjvF059,font=krYZxcbAT9HSo5XPfIRnQOJwyG30,fill=RRXSujIhvcw)
				if P2eFqf3CLhWk7I=='menu_item': FEptu4DjWAhS7GUNYQnq5bgiRfcX19.text((DHh7jWMK4YZuqNVpBl1QJmGOcoEakS+pwxH3oREFm5v98BCZ1QVtzMJOc,VdkP4aDFTBM6mc+pwxH3oREFm5v98BCZ1QVtzMJOc),uDJxNtKl2gLkR6zC7OZWEf1cjvF059,font=krYZxcbAT9HSo5XPfIRnQOJwyG30,fill=RRXSujIhvcw)
				if not BB0viwqeHyUh: Vby8wROjedpUl += ejOVHn028XJxaqEM1yt3U
				if VdkP4aDFTBM6mc>ouh9IeEq2G8FaHgtjlzR+VqKS3kPjtn2YBbDfTH: break
	if P2eFqf3CLhWk7I=='menu_item':
		d86MTyzFOUbCXn1NrIRW3QpiEhYutZ = BaJOmRNQ5vdSe3W8xpHDkyCc7UP.copy()
		Gb6kwVlSQ4MU.sleep(0.05)
		d86MTyzFOUbCXn1NrIRW3QpiEhYutZ.paste(TTtpQnEySZ8RM,(ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i),mask=kOZlFcu9r1MvfqQDnPxg0swW8aj6X)
	else: d86MTyzFOUbCXn1NrIRW3QpiEhYutZ = kOZlFcu9r1MvfqQDnPxg0swW8aj6X
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: DhOVIJAdQ80smzBy6RjSPbLH = DhOVIJAdQ80smzBy6RjSPbLH.decode(AoCWwJHgUPKXI7u2lEzym)
	try: d86MTyzFOUbCXn1NrIRW3QpiEhYutZ.save(DhOVIJAdQ80smzBy6RjSPbLH)
	except UnicodeError:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			DhOVIJAdQ80smzBy6RjSPbLH = DhOVIJAdQ80smzBy6RjSPbLH.encode(AoCWwJHgUPKXI7u2lEzym)
			d86MTyzFOUbCXn1NrIRW3QpiEhYutZ.save(DhOVIJAdQ80smzBy6RjSPbLH)
	return DDiqvYfculICpzRhy
def L8kmH6PQDwrutONEVYc2jvG7iCUqI4(AIvbDBuUVjQ90SgyRz7YJZO,krYZxcbAT9HSo5XPfIRnQOJwyG30,b2bqUHlyd1uImCe0jJ7DwP4Ok,Yp7awr35utLDMKPR,WcQRiqtnFbH,GDA1sYrzjmklcI8p2qTh):
	pDNfjSx4qA9uQZVI,QkDBRiqNrFG5nSuPWVad9Ibl,MXofK607GqE5wyRzW2OIY = Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i,15000
	b2bqUHlyd1uImCe0jJ7DwP4Ok = b2bqUHlyd1uImCe0jJ7DwP4Ok.replace('[COLOR ','[COLOR:::')
	LdP15rZqbwezHWGEOThf = WcQRiqtnFbH-Yp7awr35utLDMKPR*RXnhpCUk4M1TvgJE
	for pcKDbCFQvqVruBAS41Nnxzl5fX27a in b2bqUHlyd1uImCe0jJ7DwP4Ok.splitlines():
		QkDBRiqNrFG5nSuPWVad9Ibl += GDA1sYrzjmklcI8p2qTh
		lESiAUMg3KOIj0JuayPB,HtiTJ5QE6dk = ufmXvxgoHGDwZtjsLkR05i,Vk54F7GcROfCy6HunEI
		for XoUycvGgzS8Bfk in pcKDbCFQvqVruBAS41Nnxzl5fX27a.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q):
			TT92w0yosWQY16PDRVxSNqA = NWUusyJwLQ31xMopgfSBb(otBWsSAfu7dihVkP9e1JFKrvmYy2Q+XoUycvGgzS8Bfk)
			aDmMkvLt2Nhqe,w36JCeu5N1UQlbTjm80yH4g = AIvbDBuUVjQ90SgyRz7YJZO.textsize(TT92w0yosWQY16PDRVxSNqA,font=krYZxcbAT9HSo5XPfIRnQOJwyG30)
			if lESiAUMg3KOIj0JuayPB+aDmMkvLt2Nhqe<LdP15rZqbwezHWGEOThf:
				if not HtiTJ5QE6dk: HtiTJ5QE6dk += XoUycvGgzS8Bfk
				else: HtiTJ5QE6dk += otBWsSAfu7dihVkP9e1JFKrvmYy2Q+XoUycvGgzS8Bfk
				lESiAUMg3KOIj0JuayPB += aDmMkvLt2Nhqe
			else:
				if aDmMkvLt2Nhqe<LdP15rZqbwezHWGEOThf:
					HtiTJ5QE6dk += '\n '+XoUycvGgzS8Bfk
					QkDBRiqNrFG5nSuPWVad9Ibl += GDA1sYrzjmklcI8p2qTh
					lESiAUMg3KOIj0JuayPB = aDmMkvLt2Nhqe
				else:
					while aDmMkvLt2Nhqe>LdP15rZqbwezHWGEOThf:
						for qf4yXuWZFYbxTEdkcQBUsAIgKH in range(pwxH3oREFm5v98BCZ1QVtzMJOc,len(otBWsSAfu7dihVkP9e1JFKrvmYy2Q+XoUycvGgzS8Bfk),pwxH3oREFm5v98BCZ1QVtzMJOc):
							ggnMqYWjQzv234RtpB9Di5rGTCc = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+XoUycvGgzS8Bfk[:qf4yXuWZFYbxTEdkcQBUsAIgKH]
							m2ljFHZGIwECX7STrtVu3v9qcPf = XoUycvGgzS8Bfk[qf4yXuWZFYbxTEdkcQBUsAIgKH:]
							Fko3hj5ZVQNfGCHqe7LrUcn9DyI = NWUusyJwLQ31xMopgfSBb(ggnMqYWjQzv234RtpB9Di5rGTCc)
							J0TDZFGXEeoQ,Cw4J20I8BQyM = AIvbDBuUVjQ90SgyRz7YJZO.textsize(Fko3hj5ZVQNfGCHqe7LrUcn9DyI,font=krYZxcbAT9HSo5XPfIRnQOJwyG30)
							if lESiAUMg3KOIj0JuayPB+J0TDZFGXEeoQ>LdP15rZqbwezHWGEOThf:
								t0tk1HWRubCIPZj5SFcA7DrYmsUJ = aDmMkvLt2Nhqe-J0TDZFGXEeoQ
								HtiTJ5QE6dk += ggnMqYWjQzv234RtpB9Di5rGTCc+ixrPWKeFMnqJyVodX6D9AaO2
								QkDBRiqNrFG5nSuPWVad9Ibl += GDA1sYrzjmklcI8p2qTh
								aDmMkvLt2Nhqe = t0tk1HWRubCIPZj5SFcA7DrYmsUJ
								if t0tk1HWRubCIPZj5SFcA7DrYmsUJ>LdP15rZqbwezHWGEOThf:
									lESiAUMg3KOIj0JuayPB = ufmXvxgoHGDwZtjsLkR05i
									XoUycvGgzS8Bfk = m2ljFHZGIwECX7STrtVu3v9qcPf
								else:
									lESiAUMg3KOIj0JuayPB = t0tk1HWRubCIPZj5SFcA7DrYmsUJ
									HtiTJ5QE6dk += m2ljFHZGIwECX7STrtVu3v9qcPf
								break
				if QkDBRiqNrFG5nSuPWVad9Ibl>MXofK607GqE5wyRzW2OIY: break
		pDNfjSx4qA9uQZVI += ixrPWKeFMnqJyVodX6D9AaO2+HtiTJ5QE6dk
		if QkDBRiqNrFG5nSuPWVad9Ibl>MXofK607GqE5wyRzW2OIY: break
	pDNfjSx4qA9uQZVI = pDNfjSx4qA9uQZVI[pwxH3oREFm5v98BCZ1QVtzMJOc:]
	pDNfjSx4qA9uQZVI = pDNfjSx4qA9uQZVI.replace('[COLOR:::','[COLOR ')
	return pDNfjSx4qA9uQZVI
def NWUusyJwLQ31xMopgfSBb(XoUycvGgzS8Bfk):
	if '[' in XoUycvGgzS8Bfk and ']' in XoUycvGgzS8Bfk:
		yw7T5oM2DIuiSAbKLJ = [ZZoLlKyInXc08j2pTGJ,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		c23OWvdbE80aw1rgMzIAlDsVo74hCi = RSuYINdeamsK0t.findall('\[COLOR .*?\]',XoUycvGgzS8Bfk,RSuYINdeamsK0t.DOTALL)
		LugdombCR2Y1s683PhjZ = RSuYINdeamsK0t.findall('\[COLOR:::.*?\]',XoUycvGgzS8Bfk,RSuYINdeamsK0t.DOTALL)
		o9oJ7mw8hX3GsO = yw7T5oM2DIuiSAbKLJ+c23OWvdbE80aw1rgMzIAlDsVo74hCi+LugdombCR2Y1s683PhjZ
		for KhDQdV69OGk78wMP2yAb0 in o9oJ7mw8hX3GsO: XoUycvGgzS8Bfk = XoUycvGgzS8Bfk.replace(KhDQdV69OGk78wMP2yAb0,Vk54F7GcROfCy6HunEI)
	return XoUycvGgzS8Bfk
def qTDYyX6PHvFomVw(YWCso5NMKO):
	YWCso5NMKO = YWCso5NMKO.replace(ixrPWKeFMnqJyVodX6D9AaO2,'_sss__newline_')
	YWCso5NMKO = YWCso5NMKO.replace('[RTL]','_sss__linertl_')
	YWCso5NMKO = YWCso5NMKO.replace('[LEFT]','_sss__lineleft_')
	YWCso5NMKO = YWCso5NMKO.replace('[RIGHT]','_sss__lineright_')
	YWCso5NMKO = YWCso5NMKO.replace('[CENTER]','_sss__linecenter_')
	YWCso5NMKO = YWCso5NMKO.replace(ZZoLlKyInXc08j2pTGJ,'_sss__endcolor_')
	oXt9W1aPmK3Twg8Gl7I4JDh = RSuYINdeamsK0t.findall('\[COLOR (.*?)\]',YWCso5NMKO,RSuYINdeamsK0t.DOTALL)
	for diPagJA0GyTM964U8vtZ2HDk in oXt9W1aPmK3Twg8Gl7I4JDh: YWCso5NMKO = YWCso5NMKO.replace('[COLOR '+diPagJA0GyTM964U8vtZ2HDk+']','_sss__newcolor'+diPagJA0GyTM964U8vtZ2HDk+'_')
	return YWCso5NMKO
def jrELQfAuqnWc9pBSPivOb5Ft(LLBCE0TuewHp6,EDy0Rs9liwjZvJY=Vk54F7GcROfCy6HunEI):
	if not EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = J2L6to3R1Z.getInfoLabel('ListItem.Label')
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(qMmCGK8cln5bID4fkhAF,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if LLBCE0TuewHp6: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace('[COLOR ',Vk54F7GcROfCy6HunEI).replace(']',Vk54F7GcROfCy6HunEI)
	else: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(d761ZWXHEvliYN45RzLP2,Vk54F7GcROfCy6HunEI).replace(nMt0iueCy6K,Vk54F7GcROfCy6HunEI).replace(hh6BmGb5aUH,Vk54F7GcROfCy6HunEI).replace(X8sIqoceCwHlQ6bt5n9r1OVSFpA,Vk54F7GcROfCy6HunEI)
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).replace(ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI)
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(kH6Bj7pebUaxIf,Vk54F7GcROfCy6HunEI).replace(ZdD4q6gA50I,Vk54F7GcROfCy6HunEI)
	YJyxBPcjCf4NeUd07agOqho = RSuYINdeamsK0t.findall('\d\d:\d\d ',EDy0Rs9liwjZvJY,RSuYINdeamsK0t.DOTALL)
	if YJyxBPcjCf4NeUd07agOqho: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.split(YJyxBPcjCf4NeUd07agOqho[ufmXvxgoHGDwZtjsLkR05i],pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
	if not EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = 'Main Menu'
	return EDy0Rs9liwjZvJY
def I1yWnMRpsx5(z9zanu6eDOHMZjbfiyEkB):
	bmfU3ty6xdD1u = Vk54F7GcROfCy6HunEI.join(qf4yXuWZFYbxTEdkcQBUsAIgKH for qf4yXuWZFYbxTEdkcQBUsAIgKH in z9zanu6eDOHMZjbfiyEkB if qf4yXuWZFYbxTEdkcQBUsAIgKH not in '\/":*?<>|'+WWXlgMJx4SP910N)
	return bmfU3ty6xdD1u
def FB73gN9pmQMe1AVKjyslCL8I2X(NBnKOkHsvLd):
	cUwPtxlmTLe5nFD = RSuYINdeamsK0t.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",NBnKOkHsvLd,RSuYINdeamsK0t.S)
	if cUwPtxlmTLe5nFD:
		sx0nUG7R9yoPeO,py8Tg0xSaHd5nD3M9mzVhrIAOs = cUwPtxlmTLe5nFD[ufmXvxgoHGDwZtjsLkR05i]
		sx0nUG7R9yoPeO = RSuYINdeamsK0t.findall("=[\r\n\s\t]+'(.*?)';", sx0nUG7R9yoPeO, RSuYINdeamsK0t.S)[ufmXvxgoHGDwZtjsLkR05i]
		if sx0nUG7R9yoPeO and py8Tg0xSaHd5nD3M9mzVhrIAOs:
			OLHqgZXkcCKRdYi7JxtwWFSpElvV = sx0nUG7R9yoPeO.replace("'",Vk54F7GcROfCy6HunEI).replace("+",Vk54F7GcROfCy6HunEI).replace("\n",Vk54F7GcROfCy6HunEI).replace("\r",Vk54F7GcROfCy6HunEI)
			zK4h9Ylv02mPjBt8prU7GoTdu = OLHqgZXkcCKRdYi7JxtwWFSpElvV.split('.')
			NBnKOkHsvLd = Vk54F7GcROfCy6HunEI
			for RtorgQbL5MWa26T4379ldw in zK4h9Ylv02mPjBt8prU7GoTdu:
				qhzYVuO4wNLt = PnRA5dpzE18JU.b64decode(RtorgQbL5MWa26T4379ldw+'==').decode(AoCWwJHgUPKXI7u2lEzym)
				PgDwAco7xl2ZruYz = RSuYINdeamsK0t.findall('\d+', qhzYVuO4wNLt, RSuYINdeamsK0t.S)
				if PgDwAco7xl2ZruYz:
					bkwYJvpj6mt = int(PgDwAco7xl2ZruYz[ufmXvxgoHGDwZtjsLkR05i])
					bkwYJvpj6mt += int(py8Tg0xSaHd5nD3M9mzVhrIAOs)
					NBnKOkHsvLd = NBnKOkHsvLd + chr(bkwYJvpj6mt)
			if PvwFsJK23NbU8XWAx: NBnKOkHsvLd = NBnKOkHsvLd.encode('iso-8859-1').decode(AoCWwJHgUPKXI7u2lEzym)
	return NBnKOkHsvLd
def LOp5or14udNYRXFKDxwh(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7=Vk54F7GcROfCy6HunEI,kNnrH6938aeRlGjKySB2CcIT=Vk54F7GcROfCy6HunEI):
	if '::' in V3EjC5wJlI: V3EjC5wJlI,WypSQTO7504tHY = V3EjC5wJlI.split('::')
	else: V3EjC5wJlI,WypSQTO7504tHY = V3EjC5wJlI,''
	hj50MJnoOp6ZWaS1IQ8Elr,SsAcDJaR2NuE7p4ZkO,ii5oPt8ldEp,HabAZ8CldGFjyvh = ppD6ewtT4LyNSgXxIQqYaA9U(N39NCXDAaVnx)
	gGJca1tveBV297Dl = imAJgoKCHE3DrTVOnPlf.copy() if isinstance(imAJgoKCHE3DrTVOnPlf,dict) else imAJgoKCHE3DrTVOnPlf
	L39t14lv2dr7IYqxERZM = V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,MFWydLr2JXCuVlUgAw9ERH8Yoiep,gGJca1tveBV297Dl,hscbiOf5pLaXMzUnDk
	if zpkoYB8x4vLuScXFiKPqOtRAj<ufmXvxgoHGDwZtjsLkR05i:
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'OPENURL_REQUESTS',L39t14lv2dr7IYqxERZM)
		zpkoYB8x4vLuScXFiKPqOtRAj = -zpkoYB8x4vLuScXFiKPqOtRAj
	if zpkoYB8x4vLuScXFiKPqOtRAj>ufmXvxgoHGDwZtjsLkR05i:
		s63mcpoNbCT79FW0dOfauhYrRyLV = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'response','OPENURL_REQUESTS',L39t14lv2dr7IYqxERZM)
		if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
			R68OB3VtYS0WK('REQUESTS  READ_CACHE',hj50MJnoOp6ZWaS1IQ8Elr,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,JlT9OB143U,V3EjC5wJlI)
			return s63mcpoNbCT79FW0dOfauhYrRyLV
	if WypSQTO7504tHY=='SCRAPERS': s63mcpoNbCT79FW0dOfauhYrRyLV = rGOT0oqaguXHlC5SZJz(V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U)
	else: s63mcpoNbCT79FW0dOfauhYrRyLV = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7,kNnrH6938aeRlGjKySB2CcIT)
	if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		if 'CIMANOW' in JlT9OB143U: s63mcpoNbCT79FW0dOfauhYrRyLV.content = FB73gN9pmQMe1AVKjyslCL8I2X(s63mcpoNbCT79FW0dOfauhYrRyLV.content)
		if s63mcpoNbCT79FW0dOfauhYrRyLV.scrape: zpkoYB8x4vLuScXFiKPqOtRAj = sT9DURSXlOybaCQ
		if zpkoYB8x4vLuScXFiKPqOtRAj and s63mcpoNbCT79FW0dOfauhYrRyLV.content: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'OPENURL_REQUESTS',L39t14lv2dr7IYqxERZM,s63mcpoNbCT79FW0dOfauhYrRyLV,zpkoYB8x4vLuScXFiKPqOtRAj)
	return s63mcpoNbCT79FW0dOfauhYrRyLV
def zwntpBDFVLeOkCymhsP(V3EjC5wJlI,N39NCXDAaVnx,data,headers,allow_redirects,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7,kNnrH6938aeRlGjKySB2CcIT):
	if data==Vk54F7GcROfCy6HunEI: data = {}
	if headers==Vk54F7GcROfCy6HunEI: headers = {}
	QQxtB4R1grIyH5blGpT2LDdP6 = YOHXqtbQTBfKerIZ if allow_redirects in [Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ] else eu1NswY9zkKC60I
	QLR0TuBGvEincdzjlUKO48g3IWPpo = YOHXqtbQTBfKerIZ if showDialogs in [Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ] else eu1NswY9zkKC60I
	rGPR6hJ9i83snyvd = YOHXqtbQTBfKerIZ if KMl6HEmOUCYyLtbJDP2df7 in [Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ] else eu1NswY9zkKC60I
	YYyHmvqJXjhueGIxCd = YOHXqtbQTBfKerIZ if kNnrH6938aeRlGjKySB2CcIT in [Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ] else eu1NswY9zkKC60I
	zWochUpvu80mn5 = data
	eDbTIrV6KLfz80 = headers
	QLR0TuBGvEincdzjlUKO48g3IWPpo = QLR0TuBGvEincdzjlUKO48g3IWPpo if h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX==tayEeSpKRJIdC8g10 else h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX
	rGPR6hJ9i83snyvd = rGPR6hJ9i83snyvd if h9zFQKnsNL.ALLOW_DNS_FIX==tayEeSpKRJIdC8g10 else h9zFQKnsNL.ALLOW_DNS_FIX
	YYyHmvqJXjhueGIxCd = YYyHmvqJXjhueGIxCd if h9zFQKnsNL.ALLOW_PROXY_FIX==tayEeSpKRJIdC8g10 else h9zFQKnsNL.ALLOW_PROXY_FIX
	if JlT9OB143U=='SERVICES-INSTALL_OLD_RELEASE-1st': eDbTIrV6KLfz80 = {}
	else:
		ftyMuxlL8wkrFNq0sbPCiT2 = list(eDbTIrV6KLfz80.keys())
		if 'Referer' not in ftyMuxlL8wkrFNq0sbPCiT2: eDbTIrV6KLfz80['Referer'] = 'http'
		if 'User-Agent' not in ftyMuxlL8wkrFNq0sbPCiT2: eDbTIrV6KLfz80['User-Agent'] = p3QOAkrEuys81JqHobh(YOHXqtbQTBfKerIZ)
	return V3EjC5wJlI,N39NCXDAaVnx,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,rGPR6hJ9i83snyvd,YYyHmvqJXjhueGIxCd
def yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7=Vk54F7GcROfCy6HunEI,kNnrH6938aeRlGjKySB2CcIT=Vk54F7GcROfCy6HunEI):
	iUK5nxJut9YvoS2h = zwntpBDFVLeOkCymhsP(V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7,kNnrH6938aeRlGjKySB2CcIT)
	V3EjC5wJlI,N39NCXDAaVnx,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,rGPR6hJ9i83snyvd,YYyHmvqJXjhueGIxCd = iUK5nxJut9YvoS2h
	hj50MJnoOp6ZWaS1IQ8Elr,SsAcDJaR2NuE7p4ZkO,ii5oPt8ldEp,HabAZ8CldGFjyvh = ppD6ewtT4LyNSgXxIQqYaA9U(N39NCXDAaVnx)
	EFl75DTWxtVedjRskgnaZr = cad8TeSyMUYmfsEO0.getSetting('av.status.dns')
	bnjDWeOuzEP6kJYMAiIR4lpK1oU = cad8TeSyMUYmfsEO0.getSetting('av.status.usedns')
	uc7o2QzC9XSnpmBfIP65KaYkrFhs = cad8TeSyMUYmfsEO0.getSetting('av.status.useproxy')
	D0XI7ajmBPeo1 = ['scrapeops','scraperapi','scrapingant','scrapingrobot','scrapeup','scrape.do']
	RRtF4wl1sqKP69OEmdJfAGYI = YOHXqtbQTBfKerIZ if any(value in N39NCXDAaVnx for value in D0XI7ajmBPeo1) else eu1NswY9zkKC60I
	if '&url=' in hj50MJnoOp6ZWaS1IQ8Elr and RRtF4wl1sqKP69OEmdJfAGYI: ggslOPNHIR08hXQEj = hj50MJnoOp6ZWaS1IQ8Elr.rsplit('&url=',pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
	else: ggslOPNHIR08hXQEj = Vk54F7GcROfCy6HunEI
	vGiIwYlHcNQymdqnpWOsAhZ = h9zFQKnsNL.SITESURLS['PYTHON']
	KIkWCUNeuw7zOtnGyfZ = hj50MJnoOp6ZWaS1IQ8Elr in vGiIwYlHcNQymdqnpWOsAhZ or ggslOPNHIR08hXQEj in vGiIwYlHcNQymdqnpWOsAhZ
	qyWZiGHjCM29KBhf487N = h9zFQKnsNL.SITESURLS['REPOS']
	A93kRBs8T62OjuMgvrpZKPQhyi1Ie = hj50MJnoOp6ZWaS1IQ8Elr in qyWZiGHjCM29KBhf487N or ggslOPNHIR08hXQEj in qyWZiGHjCM29KBhf487N
	pRkZszMt47NbD692KJ = KIkWCUNeuw7zOtnGyfZ or A93kRBs8T62OjuMgvrpZKPQhyi1Ie
	EdD17cbhJnUzGF3PAai2vMKQY45B = eu1NswY9zkKC60I
	DnjxsaeQhLH9cTwBOfVdZGiFg7JrMI = YOHXqtbQTBfKerIZ
	ce7zXGN8tHMqlP0bg = SsAcDJaR2NuE7p4ZkO==None and ii5oPt8ldEp==None and not RRtF4wl1sqKP69OEmdJfAGYI
	if ce7zXGN8tHMqlP0bg and pRkZszMt47NbD692KJ:
		if KIkWCUNeuw7zOtnGyfZ:
			bDPh6Nd8RvoFHnBlEKx4MTpUJcS = vGiIwYlHcNQymdqnpWOsAhZ.index(hj50MJnoOp6ZWaS1IQ8Elr)
			G8G3k1zvVxdpaTDHlNhbmtQ5YrXge = h9zFQKnsNL.SITESURLS['PYTHON_BKP1'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			nnm39dVaR0 = h9zFQKnsNL.SITESURLS['PYTHON_BKP2'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			E30pcFYPWgJGTwC9kaABKd65 = h9zFQKnsNL.SITESURLS['PYTHON_BKP3'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			fJFrAMYPDz = h9zFQKnsNL.api_python_actions[bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			if fJFrAMYPDz=='LISTPLAY': rGPR6hJ9i83snyvd,YYyHmvqJXjhueGIxCd,DnjxsaeQhLH9cTwBOfVdZGiFg7JrMI = eu1NswY9zkKC60I,eu1NswY9zkKC60I,eu1NswY9zkKC60I
			elif fJFrAMYPDz=='CAPTCHA': EdD17cbhJnUzGF3PAai2vMKQY45B = YOHXqtbQTBfKerIZ
		elif A93kRBs8T62OjuMgvrpZKPQhyi1Ie:
			bDPh6Nd8RvoFHnBlEKx4MTpUJcS = qyWZiGHjCM29KBhf487N.index(hj50MJnoOp6ZWaS1IQ8Elr)
			G8G3k1zvVxdpaTDHlNhbmtQ5YrXge = h9zFQKnsNL.SITESURLS['REPOS_BKP1'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			nnm39dVaR0 = h9zFQKnsNL.SITESURLS['REPOS_BKP2'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			E30pcFYPWgJGTwC9kaABKd65 = h9zFQKnsNL.SITESURLS['REPOS_BKP3'][bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
			fJFrAMYPDz = h9zFQKnsNL.api_repos_actions[bDPh6Nd8RvoFHnBlEKx4MTpUJcS]
	if ii5oPt8ldEp==Vk54F7GcROfCy6HunEI: ii5oPt8ldEp = EFl75DTWxtVedjRskgnaZr
	elif ii5oPt8ldEp==None and bnjDWeOuzEP6kJYMAiIR4lpK1oU in ['AUTO','ACCEPTED'] and rGPR6hJ9i83snyvd: ii5oPt8ldEp = EFl75DTWxtVedjRskgnaZr
	if KIkWCUNeuw7zOtnGyfZ or A93kRBs8T62OjuMgvrpZKPQhyi1Ie: e98nIYDOZyX05Tf3io2dpV = 15
	elif RRtF4wl1sqKP69OEmdJfAGYI: e98nIYDOZyX05Tf3io2dpV = 60
	elif JlT9OB143U in hhmKJHnG2Yw: e98nIYDOZyX05Tf3io2dpV = 10
	elif JlT9OB143U=='LIBRARY-REVERSO_TRANSLATE-1st': e98nIYDOZyX05Tf3io2dpV = 20
	elif JlT9OB143U=='LIBRARY-GOOGLE_TRANSLATE-1st': e98nIYDOZyX05Tf3io2dpV = 20
	elif 'RESOLVERS-AKWAM' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 70
	elif 'SHOFHA' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 75
	elif 'CIMA4U' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 25
	elif 'AHWAK' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 20
	elif 'CIMALIGHT' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 20
	elif 'CIMACLUBWORK' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 30
	elif 'AKOAM' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 25
	elif 'AKWAM' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 30
	elif 'FASELHD1' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 20
	elif 'EGYBEST3' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 60
	elif 'HALACIMA' in JlT9OB143U: e98nIYDOZyX05Tf3io2dpV = 40
	else: e98nIYDOZyX05Tf3io2dpV = 15
	Aa41lXxLuidoBw9k = (SsAcDJaR2NuE7p4ZkO!=None)
	p76YJHwhf14UFRTQGbSVLZmEMOd = (ii5oPt8ldEp!=None and bnjDWeOuzEP6kJYMAiIR4lpK1oU!='STOP')
	if Aa41lXxLuidoBw9k and not RRtF4wl1sqKP69OEmdJfAGYI: qJAOp7HgfKeMQkDau('تفعيل بروكسي رقم',SsAcDJaR2NuE7p4ZkO)
	elif p76YJHwhf14UFRTQGbSVLZmEMOd: qJAOp7HgfKeMQkDau('تفعيل DNS رقم',ii5oPt8ldEp)
	if Aa41lXxLuidoBw9k:
		YzwjLlne7PBMcrVUWm3y0H = {"http":SsAcDJaR2NuE7p4ZkO,"https":SsAcDJaR2NuE7p4ZkO}
		SqQF2g9DGAYOHuRc = SsAcDJaR2NuE7p4ZkO
	else: YzwjLlne7PBMcrVUWm3y0H,SqQF2g9DGAYOHuRc = {},Vk54F7GcROfCy6HunEI
	if p76YJHwhf14UFRTQGbSVLZmEMOd:
		import urllib3.util.connection as EMenbGcfTy3OJLN5XIHtug9
		ZSkg1WTpqOjfFtLNyD5o6 = NuAKiZSnYzsp2BrTCRX73QFa0DHc(EMenbGcfTy3OJLN5XIHtug9,EFl75DTWxtVedjRskgnaZr,YOHXqtbQTBfKerIZ)
	zzL4jwpNiObuCv,tW8xaRsY0I25Sruv3wog4zJqO,ufRbcL6KC5t,po5zCgyERPjktbNa1SKVD,BKZ1hexWDTmur9og8QPVbLM0Sz,E7ibShAVLGqRmNn846XrcsYCTwfk,verify = QQxtB4R1grIyH5blGpT2LDdP6,JlT9OB143U,V3EjC5wJlI,eu1NswY9zkKC60I,eu1NswY9zkKC60I,eu1NswY9zkKC60I,HabAZ8CldGFjyvh
	if EdD17cbhJnUzGF3PAai2vMKQY45B: BKZ1hexWDTmur9og8QPVbLM0Sz = YOHXqtbQTBfKerIZ
	if pRkZszMt47NbD692KJ or QQxtB4R1grIyH5blGpT2LDdP6: zzL4jwpNiObuCv = eu1NswY9zkKC60I
	if KIkWCUNeuw7zOtnGyfZ: ufRbcL6KC5t = 'POST'
	PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1 = -pwxH3oREFm5v98BCZ1QVtzMJOc,'Unknown Error'
	GC5S1FUPHi7qA8j2KI = eu1NswY9zkKC60I
	if not h9zFQKnsNL.FORWARDS_HOSTNAMES: h9zFQKnsNL.FORWARDS_HOSTNAMES = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'dict','MISC_TEMP','FORWARDS')
	XH3Fufkti28RKIglyvSzeJaQYAP = []
	while hj50MJnoOp6ZWaS1IQ8Elr not in XH3Fufkti28RKIglyvSzeJaQYAP and hj50MJnoOp6ZWaS1IQ8Elr in list(h9zFQKnsNL.FORWARDS_HOSTNAMES.keys()):
		XH3Fufkti28RKIglyvSzeJaQYAP.append(hj50MJnoOp6ZWaS1IQ8Elr)
		hj50MJnoOp6ZWaS1IQ8Elr = h9zFQKnsNL.FORWARDS_HOSTNAMES[hj50MJnoOp6ZWaS1IQ8Elr]
	import requests as C56ifaczLBrtO7Vm
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(9):
		kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
		if sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz:
			tW8xaRsY0I25Sruv3wog4zJqO = 'LIBRARY-OPENURL_REQUESTS-1st'
			try: s63mcpoNbCT79FW0dOfauhYrRyLV.close()
			except: pass
		if RRtF4wl1sqKP69OEmdJfAGYI or not Aa41lXxLuidoBw9k: R68OB3VtYS0WK('REQUESTS\tOPEN_URL',hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,tW8xaRsY0I25Sruv3wog4zJqO,ufRbcL6KC5t)
		ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr
		try:
			s63mcpoNbCT79FW0dOfauhYrRyLV = C56ifaczLBrtO7Vm.request(ufRbcL6KC5t,hj50MJnoOp6ZWaS1IQ8Elr,data=zWochUpvu80mn5,headers=eDbTIrV6KLfz80,verify=verify,allow_redirects=zzL4jwpNiObuCv,timeout=e98nIYDOZyX05Tf3io2dpV,proxies=YzwjLlne7PBMcrVUWm3y0H)
			if 300<=s63mcpoNbCT79FW0dOfauhYrRyLV.status_code<=399:
				if not po5zCgyERPjktbNa1SKVD:
					jj4OQGNhuwo = list(s63mcpoNbCT79FW0dOfauhYrRyLV.headers.keys())
					if 'Location' in jj4OQGNhuwo: hj50MJnoOp6ZWaS1IQ8Elr = s63mcpoNbCT79FW0dOfauhYrRyLV.headers['Location']
					elif 'location' in jj4OQGNhuwo: hj50MJnoOp6ZWaS1IQ8Elr = s63mcpoNbCT79FW0dOfauhYrRyLV.headers['location']
					else: po5zCgyERPjktbNa1SKVD = YOHXqtbQTBfKerIZ
					if not po5zCgyERPjktbNa1SKVD: hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.encode('latin-1','ignore').decode(AoCWwJHgUPKXI7u2lEzym,'ignore')
					if pRkZszMt47NbD692KJ and s63mcpoNbCT79FW0dOfauhYrRyLV.status_code==307:
						zzL4jwpNiObuCv = QQxtB4R1grIyH5blGpT2LDdP6
						ufRbcL6KC5t = V3EjC5wJlI
						po5zCgyERPjktbNa1SKVD = YOHXqtbQTBfKerIZ
						mmEdjkGWrJPbphO
				if not po5zCgyERPjktbNa1SKVD or QQxtB4R1grIyH5blGpT2LDdP6:
					if 'http' not in hj50MJnoOp6ZWaS1IQ8Elr:
						m7wxoiP840qI = RRav1Sf7Px(ynmiDuav5ICTeRsqj6Vb18Q,'url')
						hj50MJnoOp6ZWaS1IQ8Elr = m7wxoiP840qI+'/'+hj50MJnoOp6ZWaS1IQ8Elr.lstrip('/')
				if hj50MJnoOp6ZWaS1IQ8Elr!=ynmiDuav5ICTeRsqj6Vb18Q:
					h9zFQKnsNL.FORWARDS_HOSTNAMES[ynmiDuav5ICTeRsqj6Vb18Q] = hj50MJnoOp6ZWaS1IQ8Elr
					GC5S1FUPHi7qA8j2KI = YOHXqtbQTBfKerIZ
				if not po5zCgyERPjktbNa1SKVD and QQxtB4R1grIyH5blGpT2LDdP6:
					if fLvc6uEJiq3(hj50MJnoOp6ZWaS1IQ8Elr): mmEdjkGWrJPbphO
					else: continue
			elif 550<=s63mcpoNbCT79FW0dOfauhYrRyLV.status_code<=599:
				s63mcpoNbCT79FW0dOfauhYrRyLV.reason = s63mcpoNbCT79FW0dOfauhYrRyLV.content
				BKZ1hexWDTmur9og8QPVbLM0Sz = YOHXqtbQTBfKerIZ
			ynmiDuav5ICTeRsqj6Vb18Q = s63mcpoNbCT79FW0dOfauhYrRyLV.url
			PvV97U5qtXD38GlIJBmsxFjrELn = s63mcpoNbCT79FW0dOfauhYrRyLV.status_code
			euQMlv6PXcjI3mybnKsgtwBpHJ1 = s63mcpoNbCT79FW0dOfauhYrRyLV.reason
			s63mcpoNbCT79FW0dOfauhYrRyLV.raise_for_status()
			kNQM9jAU6TVlhezn14cKtBb = YOHXqtbQTBfKerIZ
		except C56ifaczLBrtO7Vm.exceptions.HTTPError as MhfeRPFkU07j5ogmqbsYcCS:
			pass
		except C56ifaczLBrtO7Vm.exceptions.Timeout as MhfeRPFkU07j5ogmqbsYcCS:
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: euQMlv6PXcjI3mybnKsgtwBpHJ1 = str(MhfeRPFkU07j5ogmqbsYcCS.message).split(': ')[pwxH3oREFm5v98BCZ1QVtzMJOc]
			else: euQMlv6PXcjI3mybnKsgtwBpHJ1 = str(MhfeRPFkU07j5ogmqbsYcCS).split(': ')[pwxH3oREFm5v98BCZ1QVtzMJOc]
		except C56ifaczLBrtO7Vm.exceptions.ConnectionError as MhfeRPFkU07j5ogmqbsYcCS:
			try: UzQpsgO6iuy2WP70RCSvjMn3VIqN = MhfeRPFkU07j5ogmqbsYcCS.message[ufmXvxgoHGDwZtjsLkR05i]
			except: UzQpsgO6iuy2WP70RCSvjMn3VIqN = str(MhfeRPFkU07j5ogmqbsYcCS)
			wo2ive8zyWuPLVGpmJbaYQMnS531A = RSuYINdeamsK0t.findall("\[Errno (\d+)\] (.*?)'",UzQpsgO6iuy2WP70RCSvjMn3VIqN)
			if not wo2ive8zyWuPLVGpmJbaYQMnS531A: wo2ive8zyWuPLVGpmJbaYQMnS531A = RSuYINdeamsK0t.findall(", error\((\d+), '(.*?)'",UzQpsgO6iuy2WP70RCSvjMn3VIqN)
			if not wo2ive8zyWuPLVGpmJbaYQMnS531A:
				JJdV2ZvWxspQ = RSuYINdeamsK0t.findall(": (.*?):.*?(\d+):",UzQpsgO6iuy2WP70RCSvjMn3VIqN)
				if JJdV2ZvWxspQ: wo2ive8zyWuPLVGpmJbaYQMnS531A = [JJdV2ZvWxspQ[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc],JJdV2ZvWxspQ[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i]]
			if not wo2ive8zyWuPLVGpmJbaYQMnS531A: wo2ive8zyWuPLVGpmJbaYQMnS531A = RSuYINdeamsK0t.findall(":(\d+): (.*?)'",UzQpsgO6iuy2WP70RCSvjMn3VIqN)
			if not wo2ive8zyWuPLVGpmJbaYQMnS531A: wo2ive8zyWuPLVGpmJbaYQMnS531A = RSuYINdeamsK0t.findall(" (\d+)] (.*?)'",UzQpsgO6iuy2WP70RCSvjMn3VIqN)
			try: PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1 = wo2ive8zyWuPLVGpmJbaYQMnS531A[ufmXvxgoHGDwZtjsLkR05i]
			except: PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1 = -RXnhpCUk4M1TvgJE,UzQpsgO6iuy2WP70RCSvjMn3VIqN
		except C56ifaczLBrtO7Vm.exceptions.RequestException as MhfeRPFkU07j5ogmqbsYcCS:
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: euQMlv6PXcjI3mybnKsgtwBpHJ1 = MhfeRPFkU07j5ogmqbsYcCS.message
			else: euQMlv6PXcjI3mybnKsgtwBpHJ1 = str(MhfeRPFkU07j5ogmqbsYcCS)
		except:
			try: PvV97U5qtXD38GlIJBmsxFjrELn = s63mcpoNbCT79FW0dOfauhYrRyLV.status_code
			except: pass
			try: euQMlv6PXcjI3mybnKsgtwBpHJ1 = s63mcpoNbCT79FW0dOfauhYrRyLV.reason
			except: pass
		euQMlv6PXcjI3mybnKsgtwBpHJ1 = str(euQMlv6PXcjI3mybnKsgtwBpHJ1)
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,'OPENURL_REQUESTS\tRESPONSE  Code: [ '+str(PvV97U5qtXD38GlIJBmsxFjrELn)+' ]   Reason: [ '+euQMlv6PXcjI3mybnKsgtwBpHJ1+' ]   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
		if ce7zXGN8tHMqlP0bg and pRkZszMt47NbD692KJ and not BKZ1hexWDTmur9og8QPVbLM0Sz and PvV97U5qtXD38GlIJBmsxFjrELn!=200:
			if hj50MJnoOp6ZWaS1IQ8Elr not in [G8G3k1zvVxdpaTDHlNhbmtQ5YrXge,nnm39dVaR0,E30pcFYPWgJGTwC9kaABKd65]: hj50MJnoOp6ZWaS1IQ8Elr,BKZ1hexWDTmur9og8QPVbLM0Sz = G8G3k1zvVxdpaTDHlNhbmtQ5YrXge,eu1NswY9zkKC60I
			elif hj50MJnoOp6ZWaS1IQ8Elr==G8G3k1zvVxdpaTDHlNhbmtQ5YrXge: hj50MJnoOp6ZWaS1IQ8Elr,BKZ1hexWDTmur9og8QPVbLM0Sz = nnm39dVaR0,eu1NswY9zkKC60I
			elif hj50MJnoOp6ZWaS1IQ8Elr==nnm39dVaR0: hj50MJnoOp6ZWaS1IQ8Elr,BKZ1hexWDTmur9og8QPVbLM0Sz = E30pcFYPWgJGTwC9kaABKd65,YOHXqtbQTBfKerIZ
			continue
		break
	PvV97U5qtXD38GlIJBmsxFjrELn = int(PvV97U5qtXD38GlIJBmsxFjrELn)
	if not kNQM9jAU6TVlhezn14cKtBb:
		jtyaEDvzMYOLngm0 = JSmOA1XwhMN4IrcqeYPgEB652xl(h9zFQKnsNL.DNS_SERVERS[RXnhpCUk4M1TvgJE],53)
		if jtyaEDvzMYOLngm0==-pwxH3oREFm5v98BCZ1QVtzMJOc:
			iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,'OPENURL_REQUESTS   DISCONNECTED   The device is not connected to the internet !!')
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','للأسف جهازك غير مربوط بالإنترنت .. أو غير قادر أن يستخدم الإنترنت .. أو إعدادات جهازك غير صحيحة \n\n لحل المشكلة تأكد أن جهازك مربوط بطريقة صحيحة بالإنترنت وفيه الإنترنت تعمل بصورة جيدة')
			sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
			return s63mcpoNbCT79FW0dOfauhYrRyLV
	if not kNQM9jAU6TVlhezn14cKtBb and XH3Fufkti28RKIglyvSzeJaQYAP:
		for url in XH3Fufkti28RKIglyvSzeJaQYAP:
			if url in list(h9zFQKnsNL.FORWARDS_HOSTNAMES.keys()):
				del h9zFQKnsNL.FORWARDS_HOSTNAMES[url]
				GC5S1FUPHi7qA8j2KI = YOHXqtbQTBfKerIZ
	if GC5S1FUPHi7qA8j2KI:
		FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'MISC_TEMP','FORWARDS',h9zFQKnsNL.FORWARDS_HOSTNAMES,sT9DURSXlOybaCQ)
		h9zFQKnsNL.FORWARDS_HOSTNAMES = {}
	if ii5oPt8ldEp!=None and bnjDWeOuzEP6kJYMAiIR4lpK1oU!='STOP': EMenbGcfTy3OJLN5XIHtug9.create_connection = ZSkg1WTpqOjfFtLNyD5o6
	if bnjDWeOuzEP6kJYMAiIR4lpK1oU=='ALWAYS' and rGPR6hJ9i83snyvd: ii5oPt8ldEp = None
	if not kNQM9jAU6TVlhezn14cKtBb and SsAcDJaR2NuE7p4ZkO==None and JlT9OB143U not in hhmKJHnG2Yw:
		ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
		if ovLGZ5jUxNzmiQC!='NoneType: None\n': yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
	HHA0ZI3kaPXocl7CsGjr = O8O0UxfNrsRKdw9()
	if RRtF4wl1sqKP69OEmdJfAGYI: ynmiDuav5ICTeRsqj6Vb18Q = ggslOPNHIR08hXQEj
	if not ynmiDuav5ICTeRsqj6Vb18Q: ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr
	HHA0ZI3kaPXocl7CsGjr.url = ynmiDuav5ICTeRsqj6Vb18Q
	HHA0ZI3kaPXocl7CsGjr.scrape = RRtF4wl1sqKP69OEmdJfAGYI
	try: Un1QzlgwB4jSHkMOdfGI6pJA8 = s63mcpoNbCT79FW0dOfauhYrRyLV.content
	except: Un1QzlgwB4jSHkMOdfGI6pJA8 = Vk54F7GcROfCy6HunEI
	try: Mln9dk5vU0aRuFLhoXcgCB8HVy = s63mcpoNbCT79FW0dOfauhYrRyLV.headers
	except: Mln9dk5vU0aRuFLhoXcgCB8HVy = {}
	try: howNynIFjEmL0xS = s63mcpoNbCT79FW0dOfauhYrRyLV.cookies.get_dict()
	except: howNynIFjEmL0xS = {}
	try: s63mcpoNbCT79FW0dOfauhYrRyLV.close()
	except: pass
	if PvwFsJK23NbU8XWAx:
		try: Un1QzlgwB4jSHkMOdfGI6pJA8 = Un1QzlgwB4jSHkMOdfGI6pJA8.decode(AoCWwJHgUPKXI7u2lEzym)
		except: pass
	HHA0ZI3kaPXocl7CsGjr.code = PvV97U5qtXD38GlIJBmsxFjrELn
	HHA0ZI3kaPXocl7CsGjr.reason = euQMlv6PXcjI3mybnKsgtwBpHJ1
	HHA0ZI3kaPXocl7CsGjr.content = Un1QzlgwB4jSHkMOdfGI6pJA8
	HHA0ZI3kaPXocl7CsGjr.headers = Mln9dk5vU0aRuFLhoXcgCB8HVy
	HHA0ZI3kaPXocl7CsGjr.cookies = howNynIFjEmL0xS
	HHA0ZI3kaPXocl7CsGjr.succeeded = kNQM9jAU6TVlhezn14cKtBb
	HHA0ZI3kaPXocl7CsGjr.scrapernumber = Vk54F7GcROfCy6HunEI
	HHA0ZI3kaPXocl7CsGjr.scraperserver = Vk54F7GcROfCy6HunEI
	HHA0ZI3kaPXocl7CsGjr.scraperurl = Vk54F7GcROfCy6HunEI
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog or isinstance(HHA0ZI3kaPXocl7CsGjr.content,str): q4dTglW1Q8 = HHA0ZI3kaPXocl7CsGjr.content.lower()
	else: q4dTglW1Q8 = Vk54F7GcROfCy6HunEI
	e5OWwcYkVblSPxKC0atH73 = ('cloudflare' in q4dTglW1Q8 or 'google' in q4dTglW1Q8) and q4dTglW1Q8.count('recaptcha')>RXnhpCUk4M1TvgJE and 'FASELHD1' not in JlT9OB143U and 'recaptcha-token' not in q4dTglW1Q8 and not RRtF4wl1sqKP69OEmdJfAGYI
	if PvV97U5qtXD38GlIJBmsxFjrELn==200 and e5OWwcYkVblSPxKC0atH73: HHA0ZI3kaPXocl7CsGjr.succeeded = eu1NswY9zkKC60I
	if HHA0ZI3kaPXocl7CsGjr.succeeded and ce7zXGN8tHMqlP0bg and pRkZszMt47NbD692KJ:
		wa6JNfixUTIWdpe3ROE2Z4XgmQzCrF = 'CAPTCHA'+zWochUpvu80mn5['job'].upper().replace('GET',Vk54F7GcROfCy6HunEI) if EdD17cbhJnUzGF3PAai2vMKQY45B else fJFrAMYPDz
		uDgqdPIMJYjQpiG6VKhySfObaLz(wa6JNfixUTIWdpe3ROE2Z4XgmQzCrF)
	if not HHA0ZI3kaPXocl7CsGjr.succeeded and ce7zXGN8tHMqlP0bg:
		R2lt6pbLiha1jqUTxd = ('cloudflare' in q4dTglW1Q8 and 'ray id: ' in q4dTglW1Q8)
		Vhk1BaPsZpnd7 = ('5 sec' in q4dTglW1Q8 and 'browser' in q4dTglW1Q8)
		kfg8lCUErvi4FJpxZD9KQ5qY1eHsw = (PvV97U5qtXD38GlIJBmsxFjrELn in [403] and 'error code: 1020' in q4dTglW1Q8)
		Q82EcPfYdVN3qRM9SvwI5b = ('_cf_chl_' in q4dTglW1Q8 and 'challenge-' in q4dTglW1Q8)
		if   e5OWwcYkVblSPxKC0atH73: euQMlv6PXcjI3mybnKsgtwBpHJ1 = 'Blocked by recaptcha'
		elif R2lt6pbLiha1jqUTxd: euQMlv6PXcjI3mybnKsgtwBpHJ1 = 'Blocked by cloudflare'
		elif Vhk1BaPsZpnd7: euQMlv6PXcjI3mybnKsgtwBpHJ1 = 'Blocked by 5 seconds browser check'
		elif kfg8lCUErvi4FJpxZD9KQ5qY1eHsw: euQMlv6PXcjI3mybnKsgtwBpHJ1 = 'Blocked by cloudflare access denied'
		elif Q82EcPfYdVN3qRM9SvwI5b: euQMlv6PXcjI3mybnKsgtwBpHJ1 = 'Blocked by cloudflare security check'
		else: euQMlv6PXcjI3mybnKsgtwBpHJ1 = str(euQMlv6PXcjI3mybnKsgtwBpHJ1)
		if JlT9OB143U in aIOMVn2y65xAKSBXmJGbzPc4djeu: pass
		elif JlT9OB143U in hhmKJHnG2Yw:
			iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+'  Direct connection failed   Code: [ '+str(PvV97U5qtXD38GlIJBmsxFjrELn)+' ]   Reason: [ '+euQMlv6PXcjI3mybnKsgtwBpHJ1+' ]   Source: [ '+JlT9OB143U+' ]   URL: [ '+hj50MJnoOp6ZWaS1IQ8Elr+' ]')
		else: iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Direct connection failed   Code: [ '+str(PvV97U5qtXD38GlIJBmsxFjrELn)+' ]   Reason: [ '+euQMlv6PXcjI3mybnKsgtwBpHJ1+' ]   Source: [ '+JlT9OB143U+' ]   URL: [ '+hj50MJnoOp6ZWaS1IQ8Elr+' ]')
		qP14Kjfca6mR = ggslOPNHIR08hXQEj if RRtF4wl1sqKP69OEmdJfAGYI else ZlBMJUAWRm9buv(hj50MJnoOp6ZWaS1IQ8Elr)
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog and isinstance(qP14Kjfca6mR,unicode): qP14Kjfca6mR = qP14Kjfca6mR.encode(AoCWwJHgUPKXI7u2lEzym)
		if pRkZszMt47NbD692KJ: qP14Kjfca6mR = qP14Kjfca6mR.split('/')[-pwxH3oREFm5v98BCZ1QVtzMJOc]
		W1iaHlCfTUtx53mp0szX = str(euQMlv6PXcjI3mybnKsgtwBpHJ1)+'\n( '+qP14Kjfca6mR+' )'
		if any([e5OWwcYkVblSPxKC0atH73,R2lt6pbLiha1jqUTxd,Vhk1BaPsZpnd7,kfg8lCUErvi4FJpxZD9KQ5qY1eHsw,Q82EcPfYdVN3qRM9SvwI5b]):
			HHA0ZI3kaPXocl7CsGjr.code = -wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			HHA0ZI3kaPXocl7CsGjr.reason = euQMlv6PXcjI3mybnKsgtwBpHJ1
			if YYyHmvqJXjhueGIxCd:
				IeBwLgl8iZvptJhq1sHRzfWkQGu3 = rGOT0oqaguXHlC5SZJz(V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1)
				if IeBwLgl8iZvptJhq1sHRzfWkQGu3.succeeded: return IeBwLgl8iZvptJhq1sHRzfWkQGu3
		W8j2OheqsroDJIYzRupt6nG = YOHXqtbQTBfKerIZ
		if (bnjDWeOuzEP6kJYMAiIR4lpK1oU=='ASK' or uc7o2QzC9XSnpmBfIP65KaYkrFhs=='ASK') and (rGPR6hJ9i83snyvd or YYyHmvqJXjhueGIxCd):
			W8j2OheqsroDJIYzRupt6nG = KhWLUeoAF0CfZINwr4u(PvV97U5qtXD38GlIJBmsxFjrELn,W1iaHlCfTUtx53mp0szX,JlT9OB143U,QLR0TuBGvEincdzjlUKO48g3IWPpo)
			if W8j2OheqsroDJIYzRupt6nG and bnjDWeOuzEP6kJYMAiIR4lpK1oU=='ASK': bnjDWeOuzEP6kJYMAiIR4lpK1oU = 'ACCEPTED'
			else: bnjDWeOuzEP6kJYMAiIR4lpK1oU = 'REJECTED'
			if W8j2OheqsroDJIYzRupt6nG and uc7o2QzC9XSnpmBfIP65KaYkrFhs=='ASK': uc7o2QzC9XSnpmBfIP65KaYkrFhs = 'ACCEPTED'
			else: uc7o2QzC9XSnpmBfIP65KaYkrFhs = 'REJECTED'
			cad8TeSyMUYmfsEO0.setSetting('av.status.usedns',bnjDWeOuzEP6kJYMAiIR4lpK1oU)
			cad8TeSyMUYmfsEO0.setSetting('av.status.useproxy',uc7o2QzC9XSnpmBfIP65KaYkrFhs)
		if W8j2OheqsroDJIYzRupt6nG:
			if PvV97U5qtXD38GlIJBmsxFjrELn==8 and 'https' in hj50MJnoOp6ZWaS1IQ8Elr and DnjxsaeQhLH9cTwBOfVdZGiFg7JrMI:
				if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('تفعيل فحص شهادة التشفير SSL','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr+'||NoVerifySSL'
				dey3bshxM9ST6o = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,ynmiDuav5ICTeRsqj6Vb18Q,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,QLR0TuBGvEincdzjlUKO48g3IWPpo,'LIBRARY-OPENURL_REQUESTS-2nd')
				if dey3bshxM9ST6o.succeeded:
					HHA0ZI3kaPXocl7CsGjr = dey3bshxM9ST6o
					iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Succeeded using SSL:   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('نجاح باستخدام SSL','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				else:
					iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Failed using SSL:   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('فشل باستخدام SSL','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
			if not HHA0ZI3kaPXocl7CsGjr.succeeded and uc7o2QzC9XSnpmBfIP65KaYkrFhs in ['AUTO','ACCEPTED'] and YYyHmvqJXjhueGIxCd:
				if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('تفعيل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				dey3bshxM9ST6o = nn0pSXU9gvN(V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U)
				if dey3bshxM9ST6o.succeeded:
					HHA0ZI3kaPXocl7CsGjr = dey3bshxM9ST6o
					iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Proxies succeeded:   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('نجاح سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				else:
					iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Proxies failed:   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('فشل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
			if not HHA0ZI3kaPXocl7CsGjr.succeeded and bnjDWeOuzEP6kJYMAiIR4lpK1oU in ['AUTO','ACCEPTED'] and rGPR6hJ9i83snyvd:
				if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('تفعيل سيرفر DNS','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr+'||MyDNSUrl='
				dey3bshxM9ST6o = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,ynmiDuav5ICTeRsqj6Vb18Q,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,QLR0TuBGvEincdzjlUKO48g3IWPpo,'LIBRARY-OPENURL_REQUESTS-4th')
				if dey3bshxM9ST6o.succeeded:
					HHA0ZI3kaPXocl7CsGjr = dey3bshxM9ST6o
					iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+'   DNS succeeded:   DNS: [ '+EFl75DTWxtVedjRskgnaZr+' ]   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('نجاح سيرفر DNS','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
				else:
					iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+'   DNS failed:   DNS: [ '+EFl75DTWxtVedjRskgnaZr+' ]   Source: [ '+JlT9OB143U+' ]   URL: [ '+N39NCXDAaVnx+' ]')
					if QLR0TuBGvEincdzjlUKO48g3IWPpo: qJAOp7HgfKeMQkDau('فشل سيرفر DNS','لإصلاح مشكلة الإنترنيت',Gb6kwVlSQ4MU=2000)
		if uc7o2QzC9XSnpmBfIP65KaYkrFhs=='REJECTED' or bnjDWeOuzEP6kJYMAiIR4lpK1oU=='REJECTED': QLR0TuBGvEincdzjlUKO48g3IWPpo = eu1NswY9zkKC60I
		if not HHA0ZI3kaPXocl7CsGjr.succeeded:
			if QLR0TuBGvEincdzjlUKO48g3IWPpo: yArj1FaQ830dD = KhWLUeoAF0CfZINwr4u(PvV97U5qtXD38GlIJBmsxFjrELn,W1iaHlCfTUtx53mp0szX,JlT9OB143U,QLR0TuBGvEincdzjlUKO48g3IWPpo)
			if PvV97U5qtXD38GlIJBmsxFjrELn!=200 and JlT9OB143U not in F8DIvARTeocz1hymWkEr and 'RESOLVERS-' not in JlT9OB143U: Q3yIdfYxvkqGsU()
	if cad8TeSyMUYmfsEO0.getSetting('av.status.usedns') not in ['AUTO','STOP','ASK']: cad8TeSyMUYmfsEO0.setSetting('av.status.usedns','ASK')
	if cad8TeSyMUYmfsEO0.getSetting('av.status.useproxy') not in ['AUTO','STOP','ASK']: cad8TeSyMUYmfsEO0.setSetting('av.status.useproxy','ASK')
	return HHA0ZI3kaPXocl7CsGjr
def YlDdnyUO3S1gArpu(oX6deUmzM4yS0WfJg5pvxra):
	YBOb5W8g9r6t,W89zPFlbmaJwNRT = Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I
	if oX6deUmzM4yS0WfJg5pvxra: YBOb5W8g9r6t = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'str','MISC_TEMP','EXTRAPYTHONCODE')
	if not YBOb5W8g9r6t:
		N39NCXDAaVnx = h9zFQKnsNL.SITESURLS['PYTHON'][9]
		NQw0ays5GT = {'user':h9zFQKnsNL.AV_CLIENT_IDS,'version':ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk}
		YBOb5W8g9r6t = ttSVmd8ijOyIF5vEAJ('POST',N39NCXDAaVnx,NQw0ays5GT,Vk54F7GcROfCy6HunEI,'LIBRARY-EXTRA_PYTHON_CODE-1st')
		uDgqdPIMJYjQpiG6VKhySfObaLz(h9zFQKnsNL.api_python_actions[9])
		if YBOb5W8g9r6t: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'MISC_TEMP','EXTRAPYTHONCODE',YBOb5W8g9r6t,piwNWcJEe9m)
		W89zPFlbmaJwNRT = YOHXqtbQTBfKerIZ
	if YBOb5W8g9r6t:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		exec(YBOb5W8g9r6t,globals(),locals())
		h9zFQKnsNL.SITESURLS.update(NEW_SITESURLS)
		h9zFQKnsNL.BADSCRAPERS = list(set(h9zFQKnsNL.BADSCRAPERS+NEW_BADSCRAPERS))
		h9zFQKnsNL.BADCOMMONIDS = list(set(h9zFQKnsNL.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk in list(NEW_BADWEBSITES.keys()): h9zFQKnsNL.BADWEBSITES += NEW_BADWEBSITES[ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk]
	return W89zPFlbmaJwNRT
def qcjRWIiklN3tZ9YQMU8(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,fqNDhEb7ic5rH2K9Rx,kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr):
	iK69aWeGp0lkVbNwMQgSsf4T3 = int(M7IELOvt1eNWmjVrYnH2lBQ3kagq%10)
	jZaSeHp3I8tXwbW6fumGcEV9k0g = int(M7IELOvt1eNWmjVrYnH2lBQ3kagq/10)
	KJDPiS1HOjsvrg = WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH
	KOVjGL7w0Iydxo5abqZ2JYXC = cad8TeSyMUYmfsEO0.getSetting('av.status.menuscache')
	if not KOVjGL7w0Iydxo5abqZ2JYXC: cad8TeSyMUYmfsEO0.setSetting('av.status.menuscache','AUTO')
	s9sTYnbqIEHthVG3czOK1p8vxF = cad8TeSyMUYmfsEO0.getSetting('av.status.refresh')
	ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6 = oqfzZIP1Qxu(fqNDhEb7ic5rH2K9Rx)
	WWXLfIHYEpGmnzj8y5lgrN3ehKwMt = [ufmXvxgoHGDwZtjsLkR05i,15,17,19,26,34,50,53]
	b4btCBnFrT1xAJym8esjEkSaLgI0 = jZaSeHp3I8tXwbW6fumGcEV9k0g not in WWXLfIHYEpGmnzj8y5lgrN3ehKwMt
	tFQ8z3MGSJ5vjcohmsX = jZaSeHp3I8tXwbW6fumGcEV9k0g in [23,28,71,72]
	efkOuP8CtYmdKjTB1QFAqoa5DEiJ = M7IELOvt1eNWmjVrYnH2lBQ3kagq in [265,270]
	uuGLWSjis1geyqQbzOmNZt = (b4btCBnFrT1xAJym8esjEkSaLgI0 or tFQ8z3MGSJ5vjcohmsX) and not efkOuP8CtYmdKjTB1QFAqoa5DEiJ
	ZZdygA1KljvDnx = (s9sTYnbqIEHthVG3czOK1p8vxF or not rF0ghTZEyQ) and s9sTYnbqIEHthVG3czOK1p8vxF not in ['REFRESH_CACHE']+PPFb4eNE52s
	ss6KeWoXZEpgYuIbNMJkvLP = 'type=' in s9sTYnbqIEHthVG3czOK1p8vxF
	EhpH9kBONb = M7IELOvt1eNWmjVrYnH2lBQ3kagq in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	zDkgCMXBmx2A = iK69aWeGp0lkVbNwMQgSsf4T3==9 or M7IELOvt1eNWmjVrYnH2lBQ3kagq in [145,516,523,45]
	JywCftjarP9u = not EhpH9kBONb
	lYiPwzc1o4umRGksLMKIe3j = not zDkgCMXBmx2A
	QVfaxn8XCrBwlU = ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6 in [Vk54F7GcROfCy6HunEI,'..']
	jRNbaSrTfVMhtle = QVfaxn8XCrBwlU or JywCftjarP9u
	HyQOz0Ke8n37bqVaTfsMwvX = QVfaxn8XCrBwlU or lYiPwzc1o4umRGksLMKIe3j or ss6KeWoXZEpgYuIbNMJkvLP
	DuKZCxmMsgIq1R = M7IELOvt1eNWmjVrYnH2lBQ3kagq not in [260,261,265,270,330,540,1010]
	if KOVjGL7w0Iydxo5abqZ2JYXC=='STOP': FMu4itQzSnsUP0AaeV = zDkgCMXBmx2A or EhpH9kBONb
	else: FMu4itQzSnsUP0AaeV = YOHXqtbQTBfKerIZ
	oFQC9hn7PwMBKOJcUYT = jZaSeHp3I8tXwbW6fumGcEV9k0g in [74,75,108]
	LaVhHepy83UCGM6ji1Y0zPDdWwFtO = M7IELOvt1eNWmjVrYnH2lBQ3kagq in [280,720]
	sAr5pwmLJb2enYzB9g = not oFQC9hn7PwMBKOJcUYT and not LaVhHepy83UCGM6ji1Y0zPDdWwFtO
	DfALXw59KoZBS2TEUihqYtGMpH3u = jRNbaSrTfVMhtle and HyQOz0Ke8n37bqVaTfsMwvX and DuKZCxmMsgIq1R and FMu4itQzSnsUP0AaeV and sAr5pwmLJb2enYzB9g
	gjw3p81W9BdPFUqfz5Ti = DuKZCxmMsgIq1R and FMu4itQzSnsUP0AaeV and sAr5pwmLJb2enYzB9g
	eRvnScGtXfMl8OBY6Cgy = gjw3p81W9BdPFUqfz5Ti
	DpTqfLBkI8bmHGy9MiZ1htrx3 = cad8TeSyMUYmfsEO0.getSetting('av.language.provider')
	UEibe4W6wOgLG8h1RCABxzY = cad8TeSyMUYmfsEO0.getSetting('av.language.code')
	zXjVHxtcS4 = eu1NswY9zkKC60I
	if ZZdygA1KljvDnx and DfALXw59KoZBS2TEUihqYtGMpH3u:
		YMu8AkUvjgt5zK4FGTC2PasJdN69SQ = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','MENUS_CACHE_'+DpTqfLBkI8bmHGy9MiZ1htrx3+'_'+UEibe4W6wOgLG8h1RCABxzY,KJDPiS1HOjsvrg)
		if YMu8AkUvjgt5zK4FGTC2PasJdN69SQ:
			iQlMPpRZXWLd(Vk54F7GcROfCy6HunEI,'.\tMENUS_CACHE_'+DpTqfLBkI8bmHGy9MiZ1htrx3+'_'+UEibe4W6wOgLG8h1RCABxzY+'   Loading menu from cache')
			if ss6KeWoXZEpgYuIbNMJkvLP:
				lCV0USqKrHy1WM256sIoneZibXauj3 = []
				from GBPlghkIE8 import lkQJPwK9SIXMtY1U
				from DVX8HOTEnm import aXwcANF5vO8oDb,aTZdon9vfYHe12XzCI
				d8sjAn9MpFVtvJIC1Uhif3PcYxBOu = lkQJPwK9SIXMtY1U
				WLEgH4jGuaDyd = aXwcANF5vO8oDb()
				yiWjN5R8Xp = s9sTYnbqIEHthVG3czOK1p8vxF
				zJAvDflE7N0Lu4Hwa,bZRqmXy2KT3G5DVsBJUd0pIiHtO,kkb3logrYqHWCzLDGKduPpfQIv,XF9HdeJ5yPjLrltDZkYcCu2B,RR06QJSNHBOL4YK,l1uJYOP4FAgEbaSIZKec,SqWmjdJoz4cBsIOiNfe0ka3CVD,wRmuVtJjNSCk5ol9sXBy2i,JRNErl7WtM3h = cmeXCvAZnH86gJ(yiWjN5R8Xp)
				WAde9PaGgCtfNOUmBk = zJAvDflE7N0Lu4Hwa,bZRqmXy2KT3G5DVsBJUd0pIiHtO,kkb3logrYqHWCzLDGKduPpfQIv,XF9HdeJ5yPjLrltDZkYcCu2B,RR06QJSNHBOL4YK,l1uJYOP4FAgEbaSIZKec,SqWmjdJoz4cBsIOiNfe0ka3CVD,Vk54F7GcROfCy6HunEI,JRNErl7WtM3h
				for GzFOQuSsfmiw in YMu8AkUvjgt5zK4FGTC2PasJdN69SQ:
					sp1XmOHbSaB5y7QIYRE3z06T = GzFOQuSsfmiw['menuItem']
					if sp1XmOHbSaB5y7QIYRE3z06T==WAde9PaGgCtfNOUmBk or GzFOQuSsfmiw['mode'] in [265,270]:
						GzFOQuSsfmiw = ZZArK3Eo5wj8CvNDLaFXBQOceWx(sp1XmOHbSaB5y7QIYRE3z06T,d8sjAn9MpFVtvJIC1Uhif3PcYxBOu,WLEgH4jGuaDyd)
						if GzFOQuSsfmiw['favorites']:
							TtbLVKeg837oAINkDyv9uE = aTZdon9vfYHe12XzCI(WLEgH4jGuaDyd,sp1XmOHbSaB5y7QIYRE3z06T,GzFOQuSsfmiw['newpath'])
							GzFOQuSsfmiw['context_menu'] = TtbLVKeg837oAINkDyv9uE+GzFOQuSsfmiw['context_menu']
					lCV0USqKrHy1WM256sIoneZibXauj3.append(GzFOQuSsfmiw)
				cad8TeSyMUYmfsEO0.setSetting('av.status.refresh',Vk54F7GcROfCy6HunEI)
				if WypSQTO7504tHY=='folder': FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'MENUS_CACHE_'+DpTqfLBkI8bmHGy9MiZ1htrx3+'_'+UEibe4W6wOgLG8h1RCABxzY,KJDPiS1HOjsvrg,lCV0USqKrHy1WM256sIoneZibXauj3,ddQIv6q9hTce1iA0nWSX5UuLaNb)
			else: lCV0USqKrHy1WM256sIoneZibXauj3 = YMu8AkUvjgt5zK4FGTC2PasJdN69SQ
			if WypSQTO7504tHY=='folder' and ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6!='..' and uuGLWSjis1geyqQbzOmNZt: u3DFOqsSJBc079Xg()
			zXjVHxtcS4 = TbFKCvLjE0OQISHfymke(KJDPiS1HOjsvrg,lCV0USqKrHy1WM256sIoneZibXauj3,kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr)
	elif WypSQTO7504tHY=='folder' and s9sTYnbqIEHthVG3czOK1p8vxF not in ['REFRESH_CACHE']+PPFb4eNE52s and gjw3p81W9BdPFUqfz5Ti:
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'MENUS_CACHE_'+DpTqfLBkI8bmHGy9MiZ1htrx3+'_'+UEibe4W6wOgLG8h1RCABxzY,KJDPiS1HOjsvrg)
	return zXjVHxtcS4,s9sTYnbqIEHthVG3czOK1p8vxF,KJDPiS1HOjsvrg,ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6,uuGLWSjis1geyqQbzOmNZt,eRvnScGtXfMl8OBY6Cgy,DpTqfLBkI8bmHGy9MiZ1htrx3,UEibe4W6wOgLG8h1RCABxzY
def BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH):
	M7IELOvt1eNWmjVrYnH2lBQ3kagq = int(Fj9S5lYorenKWR2I30)
	jZaSeHp3I8tXwbW6fumGcEV9k0g = int(M7IELOvt1eNWmjVrYnH2lBQ3kagq//10)
	if   jZaSeHp3I8tXwbW6fumGcEV9k0g==ufmXvxgoHGDwZtjsLkR05i:  from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==pwxH3oREFm5v98BCZ1QVtzMJOc:  from PXIDHZvyGh 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==RXnhpCUk4M1TvgJE:  from Re91HMbF8l 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:  from k8qN7Fo1a0 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==BZm7TqLPJfAVblDKsya85zFWXNMY:  from kDcMnFYsiw 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,H4TFmtAe5rM8oY1lfPviVC)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==m5DECdgjU4KqpVhyJ9A2b:  from d4TFuBPg3f 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==6:  from BPa8QdH7Gk 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==7:  from cU2pfFhDjH 			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==8:  from ahFMwSmWVy 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==9:  from aKIkBgjWq0		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==10: from Lu2jhfESHF 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==11: from RTvsb4O16t 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==12: from agMbSs938w 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==13: from Zs5zYvgNJD		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==14: from aXzHjfFhL2 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC,HpzRx8a4nj,ylKTDSkdQmUChwbX45ALeiu)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==15: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==16: from EhpH9kBONb		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==17: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==18: from yGzQLowKpI		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==19: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==20: from UlyBdnX14x		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==21: from vvkMu57igz	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==22: from TUQhK6j2y1		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==23: from WWria3lCPQ			import GKIyworcUq4AbupslPTFvx; w8YsNWfQ5gFluRvOmSd4Cb96H = GKIyworcUq4AbupslPTFvx(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==24: from KIO4XePNEd 			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==25: from fsHGYLNI5R 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==26: from GBPlghkIE8 			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==27: from DVX8HOTEnm		import GKIyworcUq4AbupslPTFvx; w8YsNWfQ5gFluRvOmSd4Cb96H = GKIyworcUq4AbupslPTFvx(M7IELOvt1eNWmjVrYnH2lBQ3kagq,rF0ghTZEyQ)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==28: from WWria3lCPQ			import GKIyworcUq4AbupslPTFvx; w8YsNWfQ5gFluRvOmSd4Cb96H = GKIyworcUq4AbupslPTFvx(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==29: from qC3TvE6xV8	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==30: from rm87i5wn64		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==31: from McyGYCaWgo		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==32: from JJOYjwKUzn		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==33: from hE3qDaCYkF		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==34: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==35: from JfhGnxkT0C		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==36: from oCAyOMBasc			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==37: from eeJOLScAxm			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==38: from XXbVGhg7yo 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==39: from lUdgLk0izX		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==40: from sjqwv4CVyB	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==41: from sjqwv4CVyB	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==42: from KpTdiYPncX			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==43: from MhGoTmEkg2			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==44: from mGsN7zp3Tr		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==45: from cotY0HQLr8		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==46: from YNmJdaRLhM			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==47: from Z89L0fSra1		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==48: from S5SGI6cZW1		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==49: from xzMblkIAKs		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==50: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==51: from WplIVr5uBO 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==52: from WplIVr5uBO 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==53: from GBPlghkIE8 			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==54: from BHk9b8G5AL	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,H4TFmtAe5rM8oY1lfPviVC)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==55: from Mis0W8Q4a7 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==56: from qKo9G5Nwgz		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==57: from QBUiYm6CtO		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==58: from xWmilpNGzf		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==59: from lU4NMcfLDY		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==60: from pVZljYfmER			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==61: from INiR8Z5JHn			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==62: from IVxRjUAok8		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==63: from G9GbcAVkDB	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==64: from jZnLR47tB5			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==65: from oaTpRbNj8U			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==66: from tIX2QORNFS			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==67: from ddeNSF5fca		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==68: from IIwj6ap74b		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==69: from OOzshLHt2J		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==70: from llhCVaYrkN			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==71: from n4KTbzCNIs			import GKIyworcUq4AbupslPTFvx; w8YsNWfQ5gFluRvOmSd4Cb96H = GKIyworcUq4AbupslPTFvx(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==72: from n4KTbzCNIs			import GKIyworcUq4AbupslPTFvx; w8YsNWfQ5gFluRvOmSd4Cb96H = GKIyworcUq4AbupslPTFvx(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,WypSQTO7504tHY,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==73: from FC4DifMwRH	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==74: from UvMSts9Iai		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==75: from UvMSts9Iai		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==76: from EhpH9kBONb		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==77: from QQzUvhZY8P 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==78: from ggUmxYnW0l 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==79: from TICq46Es3M 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==80: from tSvc6xpWlE 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==81: from w4L2zA5FyH 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==82: from KVS3Zj7peQ		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==83: from QLDRgOfCVA		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==84: from kVU4aLQhe7		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==85: from XwWBQtcRYI		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==86: from fEX2mhPgTw		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==87: from dMbR5g6lLs			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==88: from yywYoiXMmG			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==89: from T9EvSY1rXI		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==90: from IK6G3k8fMo	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==91: from NOu4iJt5zj		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==92: from O7TiM6FkIC		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==93: from Clj93VJn8m		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==94: from fHls7bihum			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==95: from rxFoDKgp4n			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==96: from dIQC6Dc45p		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==97: from aVC8mI9T7q		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==98: from QLo9OEpqlB		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==99: from sJb8wcGRNI		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==100: from HVdu8AmN05		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==101: from wlYHRpVvh5	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==102: from rrnsP3eh5Q 		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==103: from vkK52PxTij	import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==104: from tkd2Dhn8HN		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==105: from coOaNQelht			import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==106: from dUryeT1CJH		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==107: from a2YrPhnIXl		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq,N39NCXDAaVnx,RRG6QsiOkKU0ChovTBY3qdf)
	elif jZaSeHp3I8tXwbW6fumGcEV9k0g==108: from UvMSts9Iai		import X42LMUrFfIY3oWeazj	; w8YsNWfQ5gFluRvOmSd4Cb96H = X42LMUrFfIY3oWeazj(M7IELOvt1eNWmjVrYnH2lBQ3kagq)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = None
	return w8YsNWfQ5gFluRvOmSd4Cb96H
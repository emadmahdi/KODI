# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'EGYBEST1'
xzA9sM3rG6IHd7jl8T = '_EB1_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['مكتبتي','ايجي بست']
def X42LMUrFfIY3oWeazj(mode,url,H4TFmtAe5rM8oY1lfPviVC,text):
	if   mode==770: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==771: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==772: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==773: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==774: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'FULL_FILTER___'+text)
	elif mode==775: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'DEFINED_FILTER___'+text)
	elif mode==776: w8YsNWfQ5gFluRvOmSd4Cb96H = d3dvo9txDeRB7uzFLQ(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==779: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,url)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,779,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST1-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('nav-list(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?<span>(.*?)</span>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if any(value in title for value in wXPtB6I0QKLTyD932sl5d): continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,771)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-article(.*?)social-box',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('main-title.*?">(.*?)<.*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,771,Vk54F7GcROfCy6HunEI,'mainmenu')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-menu(.*?)</div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,771)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def d3dvo9txDeRB7uzFLQ(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST1-SEASONS_EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-article".*?">(.*?)<(.*?)article',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		Yo3AtpSIM5ax6dUTwLk1qCgjeym7P,NTaCesPm04,items = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,[]
		for name,UwcYSVZbdK3rI in Ry3L7fdNGh:
			if 'حلقات' in name: NTaCesPm04 = UwcYSVZbdK3rI
			if 'مواسم' in name: Yo3AtpSIM5ax6dUTwLk1qCgjeym7P = UwcYSVZbdK3rI
		if Yo3AtpSIM5ax6dUTwLk1qCgjeym7P and not type:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',Yo3AtpSIM5ax6dUTwLk1qCgjeym7P,RSuYINdeamsK0t.DOTALL)
			if len(items)>1:
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,776,afR4xElWyzgcNAUnKXBempC,'season')
		if NTaCesPm04 and len(items)<2:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',NTaCesPm04,RSuYINdeamsK0t.DOTALL)
			if items:
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
					v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,773,afR4xElWyzgcNAUnKXBempC)
			else:
				items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',NTaCesPm04,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
					v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,773)
	return
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST1-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items,W1F9NnGI5Rybc7kOVEah3v,iiRIXOcxv1An6k30Z2ULMwYB = [],False,False
	if not type:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-content(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,771,Vk54F7GcROfCy6HunEI,'submenu')
				W1F9NnGI5Rybc7kOVEah3v = True
	if not type and 'p=' not in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('searchform(.*?)</form>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			if W1F9NnGI5Rybc7kOVEah3v: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',url,775,Vk54F7GcROfCy6HunEI,'filter')
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',url,774,Vk54F7GcROfCy6HunEI,'filter')
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث',url,779)
			v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
			iiRIXOcxv1An6k30Z2ULMwYB = True
	if not W1F9NnGI5Rybc7kOVEah3v:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('blocks(.*?)article',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
				afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.strip(ixrPWKeFMnqJyVodX6D9AaO2)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				if '/serie/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,776,afR4xElWyzgcNAUnKXBempC,'season')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,773,afR4xElWyzgcNAUnKXBempC)
			H4TFmtAe5rM8oY1lfPviVC = '1'
			if 'p=' in url: url,H4TFmtAe5rM8oY1lfPviVC = url.split('p=',1)
			bIsz45VatWSMRmkyph63Zg1lf = '&' if '?' in url else '?'
			url = url+bIsz45VatWSMRmkyph63Zg1lf
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الصفحة التالية',url,771)
			elif H4TFmtAe5rM8oY1lfPviVC!='1':
				url = url+'p='+str(int(H4TFmtAe5rM8oY1lfPviVC)-1)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الصفحة السابقة',url,771)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST1-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('<label>التصنيف</label>.*?">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu,LsCXUSqao6NIc1l9 = [],[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('download-section.*?action="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in LsCXUSqao6NIc1l9:
			LsCXUSqao6NIc1l9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=__embed______'+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(url))
	DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('WatchServers(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall("url='(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,oOv4sVqEAmyM in HXhRgxEZ4d2Dek:
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in LsCXUSqao6NIc1l9:
				LsCXUSqao6NIc1l9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+oOv4sVqEAmyM+'__both______'+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(url))
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search,url=Vk54F7GcROfCy6HunEI):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search: search = p3bB2auMmSjXC0dE8FUfZ()
	if not search: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	if not url: url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search?query='+HJVMp5sLkG7EnixWo3QOg
	else: url = url+'?title='+HJVMp5sLkG7EnixWo3QOg+'&genre=&year=&lang='
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
def xkK0Y7fnciMQvjyq(url):
	url = url.split('/smartemadfilter?')[0]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ugep4NW1YS = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('form-row(.*?)</form>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		Ugep4NW1YS = RSuYINdeamsK0t.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		OOJi6xHhMq05oDe,eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK,DatFuedGb45zR1KqIWNk = zip(*Ugep4NW1YS)
		Ugep4NW1YS = zip(eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK,OOJi6xHhMq05oDe,DatFuedGb45zR1KqIWNk)
	return Ugep4NW1YS
def uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI):
	items = RSuYINdeamsK0t.findall('value="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return items
def R0kPAsQ9prh8dNY4DIbvf21zClyL(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
DZ9EWKPJut5hf4vnM = ['year','lang','genre']
gW3HMvICPYqjaxQ2iU4rFKo8LASZ1 = ['year','lang','genre']
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='DEFINED_FILTER':
		if gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[0:-1])):
			if gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'all')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='FULL_FILTER':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'all')
		if not KMbV6CGYIuH: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+KMbV6CGYIuH
		ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',ynmiDuav5ICTeRsqj6Vb18Q,771,Vk54F7GcROfCy6HunEI,'filter')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',ynmiDuav5ICTeRsqj6Vb18Q,771,Vk54F7GcROfCy6HunEI,'filter')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ugep4NW1YS = xkK0Y7fnciMQvjyq(url)
	dict = {}
	for name,kuKGA8HpgN7PyjvxeLZ,UwcYSVZbdK3rI in Ugep4NW1YS:
		name = name.replace('كل ',Vk54F7GcROfCy6HunEI)
		items = uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='DEFINED_FILTER':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<2:
				if kuKGA8HpgN7PyjvxeLZ==gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-1]:
					ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
					txsXO7gSMnrwAh6NmJ9D(ynmiDuav5ICTeRsqj6Vb18Q)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'DEFINED_FILTER___'+Ng1Jod47fp0S)
				return
			else:
				if kuKGA8HpgN7PyjvxeLZ==gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-1]:
					ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',ynmiDuav5ICTeRsqj6Vb18Q,771,Vk54F7GcROfCy6HunEI,'filter')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع ',hj50MJnoOp6ZWaS1IQ8Elr,775,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='FULL_FILTER':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع :'+name,hj50MJnoOp6ZWaS1IQ8Elr,774,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if not value: continue
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'#+dict[kuKGA8HpgN7PyjvxeLZ]['0']
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'+name
			if type=='FULL_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,774,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='DEFINED_FILTER' and gW3HMvICPYqjaxQ2iU4rFKo8LASZ1[-2]+'=' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
				hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				ynmiDuav5ICTeRsqj6Vb18Q = R0kPAsQ9prh8dNY4DIbvf21zClyL(hj50MJnoOp6ZWaS1IQ8Elr)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,771,Vk54F7GcROfCy6HunEI,'filter')
			elif type=='DEFINED_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,775,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.replace('=&','=0&')
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	for key in DZ9EWKPJut5hf4vnM:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.replace('=0','=')
	return PpjxGzO7yqD0AXSJL1Mw
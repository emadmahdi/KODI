# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMACLUP'
xzA9sM3rG6IHd7jl8T = '_CMC_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['موقع نتفليكس']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==490: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==491: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==492: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==493: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==494: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==499: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,url)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"filter AjaxifyFilter"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu:
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('data-filter="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/old/filter/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'.php'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,491)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أفلام',lseWcUVP5qY+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'مسلسلات',lseWcUVP5qY+'/category/مسلسلات/مسلسلات-اجنبى',494,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="navigation-menu"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='/': continue
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if title in wXPtB6I0QKLTyD932sl5d: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,491)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"filter"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,491)
	return
def txsXO7gSMnrwAh6NmJ9D(url,U8tZVnuiQqYjG5KdEWNbXF=Vk54F7GcROfCy6HunEI):
	items = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
	if '.php' in url: UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
	elif '?s=' in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"blocks(.*?)"manifest"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"Blocks(.*?)"manifest"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not UwcYSVZbdK3rI: return
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) حلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if not AWjJSatwokZ: AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if not AWjJSatwokZ or any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,492,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'حلقة' in title:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,493,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,493,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<li><a href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,491)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('"ButtonsBarCo".*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hj50MJnoOp6ZWaS1IQ8Elr:
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-EPISODES-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"img-responsive" src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
	else: afR4xElWyzgcNAUnKXBempC = J2L6to3R1Z.getInfoLabel('ListItem.Thumb')
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"filter"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"Blocks(.*?)class="pagination"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x and '/series/' not in url:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,493,afR4xElWyzgcNAUnKXBempC)
	elif QQHXiFSA0jUsklmxbpaMztu:
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,492,afR4xElWyzgcNAUnKXBempC)
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = Uo7Tbc29Eu(title)
				title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
				if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,491)
	return
def h5hmzOAeWEPip(url):
	hj50MJnoOp6ZWaS1IQ8Elr = url.strip('/')+'/?view=1'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMACLUP-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	X9PVULyJeCSviHfhmj0Gku6tgZz2 = RSuYINdeamsK0t.findall("data: 'q=(.*?)&",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	X9PVULyJeCSviHfhmj0Gku6tgZz2 = X9PVULyJeCSviHfhmj0Gku6tgZz2[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"serversList"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('data-server="(.*?)">(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for Ljqg7JpF5Rmk12,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/old/servers/server.php?q='+X9PVULyJeCSviHfhmj0Gku6tgZz2+'&i='+Ljqg7JpF5Rmk12+'?named='+title+'__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"embedServer".*?SRC="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		title = 'مفضل'
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]+'?named=__embed__'+title
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"downloadsList"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<td>(.*?)</td>.*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'anavidz' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: esUNcDaPg3QoX = '__خاص'
			else: esUNcDaPg3QoX = Vk54F7GcROfCy6HunEI
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+esUNcDaPg3QoX
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search,lseWcUVP5qY=Vk54F7GcROfCy6HunEI):
	if not lseWcUVP5qY: lseWcUVP5qY = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = lseWcUVP5qY+'/index.php?s='+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
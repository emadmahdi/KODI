# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SERIES4WATCH'
headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
xzA9sM3rG6IHd7jl8T = '_SFW_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==210: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==211: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==212: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==213: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==214: w8YsNWfQ5gFluRvOmSd4Cb96H = CcVgGhAMiQFnZX5P04TweExSHjWt(url)
	elif mode==215: w8YsNWfQ5gFluRvOmSd4Cb96H = BqJdywMa6mYF9itTcQUkG5Wro1(url)
	elif mode==218: w8YsNWfQ5gFluRvOmSd4Cb96H = Vjwok1a5vMDZbdGuOSXEt8L7Tc()
	elif mode==219: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def Vjwok1a5vMDZbdGuOSXEt8L7Tc():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,219,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/getpostsPin?type=one&data=pin&limit=25'
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المميزة',url,211)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('FiltersButtons(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('data-get="(.*?)".*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/getposts?type=one&data='+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,url,211)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('navigation-menu(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(http.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	wXPtB6I0QKLTyD932sl5d = ['مسلسلات انمي','الرئيسية']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,211)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('MediaGrid"(.*?)class="pagination"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		else: return
	items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	tFflmNDy4p78jeLWnk9xCcVZsYEz01 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if '/series/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		title = Uo7Tbc29Eu(title)
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if '/film/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or any(value in title for value in tFflmNDy4p78jeLWnk9xCcVZsYEz01):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,212,afR4xElWyzgcNAUnKXBempC)
		elif '/episode/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and 'الحلقة' in title:
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
			if AWjJSatwokZ:
				title = '_MOD_' + AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,213,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,213,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Uo7Tbc29Eu(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,211)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	uGJIOhBKwH0Njgpyb5iz6Sqvc,items,neAK1NjwRgb2 = -1,[],[]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-EPISODES-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('ti-list-numbered(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		DatFuedGb45zR1KqIWNk = Vk54F7GcROfCy6HunEI.join(Ry3L7fdNGh)
		items = RSuYINdeamsK0t.findall('href="(.*?)"',DatFuedGb45zR1KqIWNk,RSuYINdeamsK0t.DOTALL)
	items.append(url)
	items = set(items)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
		title = '_MOD_' + ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-1].replace('-',otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = RSuYINdeamsK0t.findall('الحلقة-(\d+)',ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-1],RSuYINdeamsK0t.DOTALL)
		if A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl: A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl[0]
		else: A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = '0'
		neAK1NjwRgb2.append([ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl])
	items = sorted(neAK1NjwRgb2, reverse=False, key=lambda key: int(key[2]))
	sxM3rRv8YPClU1gjewLOiuZ = str(items).count('/season/')
	uGJIOhBKwH0Njgpyb5iz6Sqvc = str(items).count('/episode/')
	if sxM3rRv8YPClU1gjewLOiuZ>1 and uGJIOhBKwH0Njgpyb5iz6Sqvc>0 and '/season/' not in url:
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl in items:
			if '/season/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,213)
	else:
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl in items:
			if '/season/' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,212)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	itb54hH6eAY = url.split('/')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		hj50MJnoOp6ZWaS1IQ8Elr = url.replace(itb54hH6eAY[3],'watch')
		nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-PLAY-2nd')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="servers-list(.*?)</div>',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if items:
				id = RSuYINdeamsK0t.findall('post_id=(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
				if id:
					w9UG3QYd7oV51ryigjs6kMO = id[0]
					for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
						ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?postid='+w9UG3QYd7oV51ryigjs6kMO+'&serverid='+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
						yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			else:
				items = RSuYINdeamsK0t.findall('data-embedd=".*?(http.*?)("|&quot;)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,x7ohwWJScUpRi1K50qs in items:
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if '/download/' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		hj50MJnoOp6ZWaS1IQ8Elr = url.replace(itb54hH6eAY[3],'download')
		nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-PLAY-3rd')
		id = RSuYINdeamsK0t.findall('postId:"(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if id:
			w9UG3QYd7oV51ryigjs6kMO = id[0]
			eDbTIrV6KLfz80 = { 'User-Agent':Vk54F7GcROfCy6HunEI , 'X-Requested-With':'XMLHttpRequest' }
			hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/ajaxCenter?_action=getdownloadlinks&postId='+w9UG3QYd7oV51ryigjs6kMO
			nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,'SERIES4WATCH-PLAY-4th')
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('<h3.*?(\d+)(.*?)</div>',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if Ry3L7fdNGh:
				for CaAnGXpU4zIq,UwcYSVZbdK3rI in Ry3L7fdNGh:
					items = RSuYINdeamsK0t.findall('<td>(.*?)<.*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
					for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
						yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__download'+'____'+CaAnGXpU4zIq)
			else:
				Ry3L7fdNGh = RSuYINdeamsK0t.findall('<h6(.*?)</table>',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
				if not Ry3L7fdNGh: Ry3L7fdNGh = [nqzvfpjFuS42ywk8]
				for UwcYSVZbdK3rI in Ry3L7fdNGh:
					name = Vk54F7GcROfCy6HunEI
					items = RSuYINdeamsK0t.findall('href="(http.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
					for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
						oOv4sVqEAmyM = '&&' + ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[2].lower() + '&&'
						oOv4sVqEAmyM = oOv4sVqEAmyM.replace('.com&&',Vk54F7GcROfCy6HunEI).replace('.co&&',Vk54F7GcROfCy6HunEI)
						oOv4sVqEAmyM = oOv4sVqEAmyM.replace('.net&&',Vk54F7GcROfCy6HunEI).replace('.org&&',Vk54F7GcROfCy6HunEI)
						oOv4sVqEAmyM = oOv4sVqEAmyM.replace('.live&&',Vk54F7GcROfCy6HunEI).replace('.online&&',Vk54F7GcROfCy6HunEI)
						oOv4sVqEAmyM = oOv4sVqEAmyM.replace('&&hd.',Vk54F7GcROfCy6HunEI).replace('&&www.',Vk54F7GcROfCy6HunEI)
						oOv4sVqEAmyM = oOv4sVqEAmyM.replace('&&',Vk54F7GcROfCy6HunEI)
						ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp + '?named=' + name + oOv4sVqEAmyM + '__download'
						yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/search?s='+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
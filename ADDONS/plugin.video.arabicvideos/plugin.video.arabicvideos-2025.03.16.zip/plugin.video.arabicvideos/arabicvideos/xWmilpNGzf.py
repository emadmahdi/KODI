# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SHAHIDNEWS'
xzA9sM3rG6IHd7jl8T = '_SHN_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['قنوات فضائية','فارسكو','Show more']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==580: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==581: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==582: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==583: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,text)
	elif mode==584: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==589: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHIDNEWS-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,589,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('/category.php">(.*?)"navslide-divider"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall("'dropdown-menu'(.*?)</ul>",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for v8e07ENZbVzIjaMSQPAxLUyuKcWho in Ry3L7fdNGh: UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace(v8e07ENZbVzIjaMSQPAxLUyuKcWho,Vk54F7GcROfCy6HunEI)
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,584)
	return
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHIDNEWS-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"caret"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('"presentation"','</ul>')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = [(Vk54F7GcROfCy6HunEI,UwcYSVZbdK3rI)]
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' فرز أو فلتر أو ترتيب '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		for D3UH5PxKtrs9ichoj2YS6RLGqB,UwcYSVZbdK3rI in Ry3L7fdNGh:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if D3UH5PxKtrs9ichoj2YS6RLGqB: D3UH5PxKtrs9ichoj2YS6RLGqB = D3UH5PxKtrs9ichoj2YS6RLGqB+': '
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = D3UH5PxKtrs9ichoj2YS6RLGqB+title
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,581)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"pm-category-subcats"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu:
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if len(items)<30:
			v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,581)
	if not WvDVRHAc37CGulIhPagimorZSy0x and not QQHXiFSA0jUsklmxbpaMztu: txsXO7gSMnrwAh6NmJ9D(url)
	return
def txsXO7gSMnrwAh6NmJ9D(url,MmpRngPUCzrJ0HlGfB=Vk54F7GcROfCy6HunEI):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHIDNEWS-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('(data-echo=".*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('"BlocksList"(.*?)"titleSectionCon"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="pm-grid"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="pm-related"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not items: items = RSuYINdeamsK0t.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if not items: items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
		if 'http' not in afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = lseWcUVP5qY+'/'+afR4xElWyzgcNAUnKXBempC.strip('/')
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,582,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'الحلقة' in title:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,583,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/movseries/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,581,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,583,afR4xElWyzgcNAUnKXBempC)
	if MmpRngPUCzrJ0HlGfB not in ['featured_movies','featured_series']:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				title = Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,581)
		Xhmn2Nrb5dLK4GOTIe3p = RSuYINdeamsK0t.findall('showmore" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Xhmn2Nrb5dLK4GOTIe3p:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Xhmn2Nrb5dLK4GOTIe3p[0]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مشاهدة المزيد',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,581)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,KBe7D36amSnG9WZf5dCUPQhOz):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHIDNEWS-EPISODES-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('nav-seasons"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	items = []
	JSDICxLuO7GWz9fRlBMiAY8eZq3 = False
	if WvDVRHAc37CGulIhPagimorZSy0x and not KBe7D36amSnG9WZf5dCUPQhOz:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for KBe7D36amSnG9WZf5dCUPQhOz,title in items:
			KBe7D36amSnG9WZf5dCUPQhOz = KBe7D36amSnG9WZf5dCUPQhOz.strip('#')
			if len(items)>1: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,583,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,KBe7D36amSnG9WZf5dCUPQhOz)
			else: JSDICxLuO7GWz9fRlBMiAY8eZq3 = True
	else: JSDICxLuO7GWz9fRlBMiAY8eZq3 = True
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('id="'+KBe7D36amSnG9WZf5dCUPQhOz+'"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu and JSDICxLuO7GWz9fRlBMiAY8eZq3:
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,582)
		else:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,582)
	return
def h5hmzOAeWEPip(url):
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHAHIDNEWS-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"Playerholder".*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	Gig2pqudmsyhzNvacPQCe = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('hash=')[1]
	itb54hH6eAY = Gig2pqudmsyhzNvacPQCe.split('__')
	qRbT6JLErSdc,HXhRgxEZ4d2Dek,title = Vk54F7GcROfCy6HunEI,[],Vk54F7GcROfCy6HunEI
	for EgUlDW3NpXL0F in itb54hH6eAY:
		hByVUIdEl7LO2 = ((4-len(EgUlDW3NpXL0F)%4)%4)*'='
		try:
			EgUlDW3NpXL0F = PnRA5dpzE18JU.b64decode(EgUlDW3NpXL0F+hByVUIdEl7LO2)
			if PvwFsJK23NbU8XWAx: EgUlDW3NpXL0F = EgUlDW3NpXL0F.decode(AoCWwJHgUPKXI7u2lEzym,'ignore')
		except: pass
		qRbT6JLErSdc += EgUlDW3NpXL0F
	qRbT6JLErSdc = qRbT6JLErSdc.replace(' = ',' => ')
	az4IndtG3KOHuXv = qRbT6JLErSdc.splitlines()
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in az4IndtG3KOHuXv:
		if '://' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: HXhRgxEZ4d2Dek.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
		if ' => ' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(' => ')
		elif 'http' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('http')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		else: continue
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip(' ')
		if not title: title = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search.php?keywords='+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
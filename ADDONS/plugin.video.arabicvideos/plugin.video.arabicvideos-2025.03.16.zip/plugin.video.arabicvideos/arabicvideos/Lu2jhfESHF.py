# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'LIVETV'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS['PYTHON'][0]
def X42LMUrFfIY3oWeazj(mode,url):
	if   mode==100: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==101: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4('0',True)
	elif mode==102: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4('1',True)
	elif mode==103: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4('2',True)
	elif mode==104: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4('3',True)
	elif mode==105: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==106: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4('4',True)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_M3U_'+'قوائم فيديوهات M3U',Vk54F7GcROfCy6HunEI,762)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_IPT_'+'قوائم فيديوهات IPTV',Vk54F7GcROfCy6HunEI,761)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TV0_'+'قنوات من مواقعها الأصلية',Vk54F7GcROfCy6HunEI,101)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TV4_'+'قنوات مختارة من يوتيوب',Vk54F7GcROfCy6HunEI,106)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_YUT_'+'قنوات عربية من يوتيوب',Vk54F7GcROfCy6HunEI,147)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_YUT_'+'قنوات أجنبية من يوتيوب',Vk54F7GcROfCy6HunEI,148)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',Vk54F7GcROfCy6HunEI,28)
	v0TjHlLZqkRxUCpmNwSy8AndO('live','_MRF_'+'قناة المعارف من موقعهم',Vk54F7GcROfCy6HunEI,41)
	v0TjHlLZqkRxUCpmNwSy8AndO('live','_PNT_'+'قناة هلا من موقع بانيت',Vk54F7GcROfCy6HunEI,38)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TV1_'+'قنوات تلفزيونية عامة',Vk54F7GcROfCy6HunEI,102)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TV2_'+'قنوات تلفزيونية خاصة',Vk54F7GcROfCy6HunEI,103)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TV3_'+'قنوات تلفزيونية للفحص',Vk54F7GcROfCy6HunEI,104)
	return
def XZA9vYcOi4(Ak1pcoVisreCFTRyH6J7WgL,showDialogs=True):
	xzA9sM3rG6IHd7jl8T = '_TV'+Ak1pcoVisreCFTRyH6J7WgL+'_'
	k8NxAwnQI2FzZCyJYthpaVubLscq = {'id':Vk54F7GcROfCy6HunEI,'user':h9zFQKnsNL.AV_CLIENT_IDS,'function':'list','menu':Ak1pcoVisreCFTRyH6J7WgL}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',FFLhlYUAsfJBXeQmRpzD7c14ZP6,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIVETV-ITEMS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = RSuYINdeamsK0t.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		for zHq7nBWJTNyY1I3aLco4AR in range(len(items)):
			name = items[zHq7nBWJTNyY1I3aLco4AR][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[zHq7nBWJTNyY1I3aLco4AR] = items[zHq7nBWJTNyY1I3aLco4AR][0],items[zHq7nBWJTNyY1I3aLco4AR][1],items[zHq7nBWJTNyY1I3aLco4AR][2],name,items[zHq7nBWJTNyY1I3aLco4AR][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for JlT9OB143U,oOv4sVqEAmyM,w9UG3QYd7oV51ryigjs6kMO,name,afR4xElWyzgcNAUnKXBempC in items:
			if '#' in JlT9OB143U: continue
			if JlT9OB143U!='URL': name = name+nMt0iueCy6K+NaXBAuesz07inT4g6cDt+JlT9OB143U+ZZoLlKyInXc08j2pTGJ
			url = JlT9OB143U+';;'+oOv4sVqEAmyM+';;'+w9UG3QYd7oV51ryigjs6kMO+';;'+Ak1pcoVisreCFTRyH6J7WgL
			v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+Vk54F7GcROfCy6HunEI+name,url,105,afR4xElWyzgcNAUnKXBempC)
	else:
		if showDialogs: v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+'هذه الخدمة مخصصة للمبرمج فقط',Vk54F7GcROfCy6HunEI,9999)
	return
def h5hmzOAeWEPip(id):
	JlT9OB143U,oOv4sVqEAmyM,w9UG3QYd7oV51ryigjs6kMO,Ak1pcoVisreCFTRyH6J7WgL = id.split(';;')
	url = Vk54F7GcROfCy6HunEI
	if JlT9OB143U=='URL': url = w9UG3QYd7oV51ryigjs6kMO
	elif JlT9OB143U=='YOUTUBE':
		url = h9zFQKnsNL.SITESURLS['YOUTUBE'][0]+'/watch?v='+w9UG3QYd7oV51ryigjs6kMO
		import f37xHeSwPL
		f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3([url],TVPm7Bz1XOwJ2,'live',url)
		return
	elif JlT9OB143U=='GA':
		k8NxAwnQI2FzZCyJYthpaVubLscq = { 'id' : Vk54F7GcROfCy6HunEI, 'user' : h9zFQKnsNL.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : Vk54F7GcROfCy6HunEI }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,False,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-1st')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		cookies = Iy3PA1SVXNfjOchtgHC5kuJBG.cookies
		Culrvnk2GYSIFWLt5x4O3N8we7ZiBK = cookies['ASP.NET_SessionId']
		url = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
		k8NxAwnQI2FzZCyJYthpaVubLscq = { 'id' : w9UG3QYd7oV51ryigjs6kMO , 'user' : h9zFQKnsNL.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : Vk54F7GcROfCy6HunEI }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+Culrvnk2GYSIFWLt5x4O3N8we7ZiBK }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,k8NxAwnQI2FzZCyJYthpaVubLscq,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-2nd')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		url = RSuYINdeamsK0t.findall('resp":"(http.*?m3u8)(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url[0][0]
		iUK5nxJut9YvoS2h = url[0][1]
		a2aQ3sHuITehY1iRxPzAObodl7 = 'http://38.'+oOv4sVqEAmyM+'777/'+w9UG3QYd7oV51ryigjs6kMO+'_HD.m3u8'+iUK5nxJut9YvoS2h
		ySr51MdcTH4U2OegAuknBa = a2aQ3sHuITehY1iRxPzAObodl7.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		Qm2ub5SzJyECN = a2aQ3sHuITehY1iRxPzAObodl7.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		nWcb8JC7zEVouFjx9fILGh1vSQ = ['HD','SD1','SD2']
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [a2aQ3sHuITehY1iRxPzAObodl7,ySr51MdcTH4U2OegAuknBa,Qm2ub5SzJyECN]
		qreJEpY8nZguD = 0
		if qreJEpY8nZguD == -1: return
		else: url = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	elif JlT9OB143U=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		k8NxAwnQI2FzZCyJYthpaVubLscq = { 'id' : w9UG3QYd7oV51ryigjs6kMO , 'user' : h9zFQKnsNL.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : Ak1pcoVisreCFTRyH6J7WgL }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST', FFLhlYUAsfJBXeQmRpzD7c14ZP6, k8NxAwnQI2FzZCyJYthpaVubLscq, headers, False,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-3rd')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		url = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
		url = url.replace('%20',otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		url = url.replace('%3D','=')
		if 'Learn' in w9UG3QYd7oV51ryigjs6kMO:
			url = url.replace('NTNNile',Vk54F7GcROfCy6HunEI)
			url = url.replace('learning1','Learning')
	elif JlT9OB143U=='PL':
		k8NxAwnQI2FzZCyJYthpaVubLscq = { 'id' : w9UG3QYd7oV51ryigjs6kMO , 'user' : h9zFQKnsNL.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : Ak1pcoVisreCFTRyH6J7WgL }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST', FFLhlYUAsfJBXeQmRpzD7c14ZP6, k8NxAwnQI2FzZCyJYthpaVubLscq, Vk54F7GcROfCy6HunEI,False,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-4th')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		url = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
		headers = {'Referer':Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Referer']}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'POST',url, Vk54F7GcROfCy6HunEI,headers , Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-5th')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		items = RSuYINdeamsK0t.findall('source src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		url = items[0]
	elif JlT9OB143U in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if JlT9OB143U=='TA': w9UG3QYd7oV51ryigjs6kMO = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		k8NxAwnQI2FzZCyJYthpaVubLscq = { 'id' : w9UG3QYd7oV51ryigjs6kMO , 'user' : h9zFQKnsNL.AV_CLIENT_IDS , 'function' : 'play'+JlT9OB143U , 'menu' : Ak1pcoVisreCFTRyH6J7WgL }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',FFLhlYUAsfJBXeQmRpzD7c14ZP6,k8NxAwnQI2FzZCyJYthpaVubLscq,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-6th')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		url = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
		if JlT9OB143U=='FM':
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET', url, Vk54F7GcROfCy6HunEI, Vk54F7GcROfCy6HunEI, False,Vk54F7GcROfCy6HunEI,'LIVETV-PLAY-7th')
			url = Iy3PA1SVXNfjOchtgHC5kuJBG.headers['Location']
			url = url.replace('https','http')
	qnUlyF2JXuGYdSA6Iac1(url,TVPm7Bz1XOwJ2,'live')
	return
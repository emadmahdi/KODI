# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'GOOGLESEARCH'
xzA9sM3rG6IHd7jl8T = '_GOS_'
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO):
	if   Yz6schq9wSmiu3IOdke0DXPj5W==1010: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1011: w8YsNWfQ5gFluRvOmSd4Cb96H = xAtf9yTc1Sa(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1012: w8YsNWfQ5gFluRvOmSd4Cb96H = mEk08yAeDICHZYfotu(lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1013: w8YsNWfQ5gFluRvOmSd4Cb96H = ak6T4YuSbKgnP3eXL9cHAOC07BmWFQ()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1014: w8YsNWfQ5gFluRvOmSd4Cb96H = Vw4cGOeE3BUr2QP(lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1015: w8YsNWfQ5gFluRvOmSd4Cb96H = TVZjDLixQF3aSfcHt8E065(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1016: w8YsNWfQ5gFluRvOmSd4Cb96H = TtJHieg061pmuAENFdISQrcCobnY(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1018: w8YsNWfQ5gFluRvOmSd4Cb96H = GC90Wd5e4Pq(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==1019: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(YWCso5NMKO,False)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','بحث جوجل جديد',Vk54F7GcROfCy6HunEI,1019)
	v0TjHlLZqkRxUCpmNwSy8AndO('link','كيف يعمل بحث جوجل','',1013)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'==== كلمات البحث المخزنة ===='+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	lDthGpmQvkZEq4WBd27caV5oPn = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if lDthGpmQvkZEq4WBd27caV5oPn:
		lDthGpmQvkZEq4WBd27caV5oPn = lDthGpmQvkZEq4WBd27caV5oPn['__SEQUENCED_COLUMNS__']
		for rXEdWpTOxkiLqY8vfjUBn in reversed(lDthGpmQvkZEq4WBd27caV5oPn):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',rXEdWpTOxkiLqY8vfjUBn,Vk54F7GcROfCy6HunEI,1019,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,rXEdWpTOxkiLqY8vfjUBn)
	return
def GC90Wd5e4Pq(search):
	zDkgCMXBmx2A(search,True)
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def zDkgCMXBmx2A(search,XIF4i6SEufM1YR5HklwqLCNhsnjvmA=False):
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	QTu5DMfvn62aRLhKq07 = search.replace(xzA9sM3rG6IHd7jl8T,Vk54F7GcROfCy6HunEI).lower()
	wCrmV8AoKGWjQEUDa7ndY1T,sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = [],[],[]
	if not XIF4i6SEufM1YR5HklwqLCNhsnjvmA:
		wCrmV8AoKGWjQEUDa7ndY1T = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GOOGLESEARCH_RESULTS',QTu5DMfvn62aRLhKq07)
		if wCrmV8AoKGWjQEUDa7ndY1T: sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = wCrmV8AoKGWjQEUDa7ndY1T
	if XIF4i6SEufM1YR5HklwqLCNhsnjvmA or not wCrmV8AoKGWjQEUDa7ndY1T:
		import BHk9b8G5AL
		BHk9b8G5AL.gDkiOuodEZ(QTu5DMfvn62aRLhKq07,'_GOOGLE',True)
		emFdEfOI06HL1vNtKzA = G6hduFY3lq48ZMcNynwWQOPoRzCKaL(QTu5DMfvn62aRLhKq07)
		for anbjzfuiDdgYP6vSXqwRex in emFdEfOI06HL1vNtKzA:
			name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs = anbjzfuiDdgYP6vSXqwRex
			if PPmYnWkqTCfNH1u4yoRs in HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi: sePTVADzKm4jQxNqiF7Eptldc35Z.append(anbjzfuiDdgYP6vSXqwRex)
			else: ypsd2zUm16HOMSuecxkbVYaoWj.append(anbjzfuiDdgYP6vSXqwRex)
		sePTVADzKm4jQxNqiF7Eptldc35Z = sorted(sePTVADzKm4jQxNqiF7Eptldc35Z,reverse=eu1NswY9zkKC60I,key=lambda key: key[ufmXvxgoHGDwZtjsLkR05i])
		ypsd2zUm16HOMSuecxkbVYaoWj = sorted(ypsd2zUm16HOMSuecxkbVYaoWj,reverse=eu1NswY9zkKC60I,key=lambda key: key[ufmXvxgoHGDwZtjsLkR05i])
		FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'GOOGLESEARCH_RESULTS',QTu5DMfvn62aRLhKq07,[sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj],mXdxepDh683FuUKlb0)
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DETAILED_GOOGLE',QTu5DMfvn62aRLhKq07)
		BHk9b8G5AL.gDkiOuodEZ(QTu5DMfvn62aRLhKq07,'_GOOGLE',False)
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+QTu5DMfvn62aRLhKq07+"')")
		if sePTVADzKm4jQxNqiF7Eptldc35Z: GHdYDixegkm9PJMN('','','رسالة من المبرمج','تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(sePTVADzKm4jQxNqiF7Eptldc35Z))+'  مواقع')
		else: sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = oAYRapNtI6hu1XgGm4WqBs7v(QTu5DMfvn62aRLhKq07,eu1NswY9zkKC60I)
	v0TjHlLZqkRxUCpmNwSy8AndO('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','بحث منفرد لمواقع جوجل',Vk54F7GcROfCy6HunEI,1011,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','نتائج البحث مفصلة - '+QTu5DMfvn62aRLhKq07,'opened_sites_google',1012,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','نتائج البحث مقسمة - '+QTu5DMfvn62aRLhKq07,'listed_sites_google',1012,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','مواقع جوجل ('+str(len(sePTVADzKm4jQxNqiF7Eptldc35Z))+') - '+QTu5DMfvn62aRLhKq07,'',1016,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('link','إعادة بحث جوجل - '+QTu5DMfvn62aRLhKq07,'',1018,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,search)
	return
def TtJHieg061pmuAENFdISQrcCobnY(QTu5DMfvn62aRLhKq07):
	sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = oAYRapNtI6hu1XgGm4WqBs7v(QTu5DMfvn62aRLhKq07)
	if not sePTVADzKm4jQxNqiF7Eptldc35Z and not ypsd2zUm16HOMSuecxkbVYaoWj: return
	uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D = {}
	for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs in sePTVADzKm4jQxNqiF7Eptldc35Z: uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D[PPmYnWkqTCfNH1u4yoRs] = name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs
	YGX2vc8yQ71TFfHat = list(uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D.keys())
	import BHk9b8G5AL
	PwDslImZiv4xUgArG = BHk9b8G5AL.UUOlq467VQ3hpTcaJiuBKzxwY(YGX2vc8yQ71TFfHat)
	for PPmYnWkqTCfNH1u4yoRs in PwDslImZiv4xUgArG:
		if 'tuple' in str(type(PPmYnWkqTCfNH1u4yoRs)):
			h9zFQKnsNL.menuItemsLIST.append(PPmYnWkqTCfNH1u4yoRs)
			continue
		name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs = uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D[PPmYnWkqTCfNH1u4yoRs]
		tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',e6TULIp9Qk3XgJ1C84AoSfsWh7dOG+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1014,aNlmtZkzK7oxI8JUj5VX,'',PPmYnWkqTCfNH1u4yoRs)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'مواقع بجوجل غير موجودة بالبرنامج'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,1015)
	ypsd2zUm16HOMSuecxkbVYaoWj = sorted(ypsd2zUm16HOMSuecxkbVYaoWj,reverse=eu1NswY9zkKC60I,key=lambda key: key[ufmXvxgoHGDwZtjsLkR05i])
	for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs in ypsd2zUm16HOMSuecxkbVYaoWj:
		v0TjHlLZqkRxUCpmNwSy8AndO('link','_GOS_'+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1015,aNlmtZkzK7oxI8JUj5VX,'',PPmYnWkqTCfNH1u4yoRs)
	return
def oAYRapNtI6hu1XgGm4WqBs7v(QTu5DMfvn62aRLhKq07,Db1rWd3ICTAVKh8owc9QB7GLXug6ZH=YOHXqtbQTBfKerIZ):
	sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = [],[]
	if Db1rWd3ICTAVKh8owc9QB7GLXug6ZH:
		wCrmV8AoKGWjQEUDa7ndY1T = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GOOGLESEARCH_RESULTS',QTu5DMfvn62aRLhKq07)
		if wCrmV8AoKGWjQEUDa7ndY1T: sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = wCrmV8AoKGWjQEUDa7ndY1T
	if not sePTVADzKm4jQxNqiF7Eptldc35Z and not ypsd2zUm16HOMSuecxkbVYaoWj: GHdYDixegkm9PJMN('','','رسالة من المبرمج','للأسف جوجل لم يجد مواقع فيها طلبك')
	return sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj
def mEk08yAeDICHZYfotu(zodCYIev4gjbVTux7,QTu5DMfvn62aRLhKq07):
	sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = oAYRapNtI6hu1XgGm4WqBs7v(QTu5DMfvn62aRLhKq07)
	if not sePTVADzKm4jQxNqiF7Eptldc35Z and not ypsd2zUm16HOMSuecxkbVYaoWj: return
	xZusr3lETtgoR,TPLEredXGohjUvzHkBil84y = [],{}
	for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs in sePTVADzKm4jQxNqiF7Eptldc35Z:
		xZusr3lETtgoR.append(PPmYnWkqTCfNH1u4yoRs)
		TPLEredXGohjUvzHkBil84y[PPmYnWkqTCfNH1u4yoRs] = FF5AU3dBkYo(text)
	import BHk9b8G5AL
	BHk9b8G5AL.lAJcuH4gSIFM(QTu5DMfvn62aRLhKq07,zodCYIev4gjbVTux7,Vk54F7GcROfCy6HunEI,xZusr3lETtgoR,TPLEredXGohjUvzHkBil84y)
	return
def xAtf9yTc1Sa(QTu5DMfvn62aRLhKq07):
	sePTVADzKm4jQxNqiF7Eptldc35Z,ypsd2zUm16HOMSuecxkbVYaoWj = oAYRapNtI6hu1XgGm4WqBs7v(QTu5DMfvn62aRLhKq07)
	if not sePTVADzKm4jQxNqiF7Eptldc35Z and not ypsd2zUm16HOMSuecxkbVYaoWj: return
	uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D = {}
	for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs in sePTVADzKm4jQxNqiF7Eptldc35Z:
		uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D[PPmYnWkqTCfNH1u4yoRs] = name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs
	YGX2vc8yQ71TFfHat = list(uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D.keys())
	import BHk9b8G5AL
	PwDslImZiv4xUgArG = BHk9b8G5AL.UUOlq467VQ3hpTcaJiuBKzxwY(YGX2vc8yQ71TFfHat)
	for PPmYnWkqTCfNH1u4yoRs in PwDslImZiv4xUgArG:
		if 'tuple' in str(type(PPmYnWkqTCfNH1u4yoRs)):
			h9zFQKnsNL.menuItemsLIST.append(PPmYnWkqTCfNH1u4yoRs)
			continue
		name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs = uGbiXFO9ytcT6rzSHoqxaAsRdZEm5D[PPmYnWkqTCfNH1u4yoRs]
		tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
		text = FF5AU3dBkYo(text)
		name = name+' - '+QTu5DMfvn62aRLhKq07
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',e6TULIp9Qk3XgJ1C84AoSfsWh7dOG+name,PPmYnWkqTCfNH1u4yoRs,548,aNlmtZkzK7oxI8JUj5VX,'',text)
	return
def FF5AU3dBkYo(title):
	AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة)',title,RSuYINdeamsK0t.DOTALL)
	esUNcDaPg3QoX = AWjJSatwokZ[0][0] if AWjJSatwokZ else title
	esUNcDaPg3QoX = esUNcDaPg3QoX.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	esUNcDaPg3QoX = esUNcDaPg3QoX.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	esUNcDaPg3QoX = esUNcDaPg3QoX.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	esUNcDaPg3QoX = esUNcDaPg3QoX.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	esUNcDaPg3QoX = esUNcDaPg3QoX.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	esUNcDaPg3QoX = esUNcDaPg3QoX.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return esUNcDaPg3QoX
def G6hduFY3lq48ZMcNynwWQOPoRzCKaL(search):
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	hj50MJnoOp6ZWaS1IQ8Elr = url+'&start=0&num=100&tbm=vid&udm=7'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'GOOGLESEARCH-SEARCH-1st')
	if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded: return []
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	l803AUuJ6ojsNV4ObZtLTXMv = CR3aLOVKSIme5XFoYi6M.path.join(dQxGp0knIfj,'googlesearch')
	if not CR3aLOVKSIme5XFoYi6M.path.exists(l803AUuJ6ojsNV4ObZtLTXMv):
		try: CR3aLOVKSIme5XFoYi6M.makedirs(l803AUuJ6ojsNV4ObZtLTXMv)
		except: pass
	items = []
	DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if DatFuedGb45zR1KqIWNk:
		for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,ylKTDSkdQmUChwbX45ALeiu,name = UwcYSVZbdK3rI
			ylKTDSkdQmUChwbX45ALeiu = ''
			items.append([ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,name,ylKTDSkdQmUChwbX45ALeiu])
	else:
		hj50MJnoOp6ZWaS1IQ8Elr = url+'&start=0&num=200'
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET::SCRAPERS',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'GOOGLESEARCH-SEARCH-2nd')
		if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded: return []
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not DatFuedGb45zR1KqIWNk: DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
			UwcYSVZbdK3rI = Bw6jaUcFxlqdDT8bC('list',UwcYSVZbdK3rI)
			if len(UwcYSVZbdK3rI)>17:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = UwcYSVZbdK3rI[17]
				title,text,name,ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI[31][0:4]
				items.append([ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,name,ylKTDSkdQmUChwbX45ALeiu])
	WSgrwNy75k4,LNeuEv7lS0toxp5dsDjUV = [],[]
	for anbjzfuiDdgYP6vSXqwRex in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,name,ylKTDSkdQmUChwbX45ALeiu = anbjzfuiDdgYP6vSXqwRex
		name = name.strip(' ')
		if not name: name = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
		name = I1yWnMRpsx5(name)
		if 'http://' in ylKTDSkdQmUChwbX45ALeiu or 'https://' in ylKTDSkdQmUChwbX45ALeiu: aNlmtZkzK7oxI8JUj5VX = ylKTDSkdQmUChwbX45ALeiu
		elif 'data:image/' in ylKTDSkdQmUChwbX45ALeiu and ';base64,' in ylKTDSkdQmUChwbX45ALeiu:
			l95rOqdPzAjZpm2v = RSuYINdeamsK0t.findall('data:image/(\w+);base64,',ylKTDSkdQmUChwbX45ALeiu)
			l95rOqdPzAjZpm2v = l95rOqdPzAjZpm2v[0]
			aNlmtZkzK7oxI8JUj5VX = CR3aLOVKSIme5XFoYi6M.path.join(l803AUuJ6ojsNV4ObZtLTXMv,name+'.'+l95rOqdPzAjZpm2v)
			if not CR3aLOVKSIme5XFoYi6M.path.exists(aNlmtZkzK7oxI8JUj5VX):
				ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.replace('\\u003d','=')
				ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.replace('data:image/'+l95rOqdPzAjZpm2v+';base64,','')
				d5GBvHrcy73n08UtR1igzQ4Wb = PnRA5dpzE18JU.b64decode(ylKTDSkdQmUChwbX45ALeiu)
				open(aNlmtZkzK7oxI8JUj5VX,'wb').write(d5GBvHrcy73n08UtR1igzQ4Wb)
		else: aNlmtZkzK7oxI8JUj5VX = ''
		PPmYnWkqTCfNH1u4yoRs = Sh23xAvu5CJQm9n1WrGH(name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		if PPmYnWkqTCfNH1u4yoRs not in LNeuEv7lS0toxp5dsDjUV:
			LNeuEv7lS0toxp5dsDjUV.append(PPmYnWkqTCfNH1u4yoRs)
			name = rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs)
			WSgrwNy75k4.append([name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,text,aNlmtZkzK7oxI8JUj5VX,PPmYnWkqTCfNH1u4yoRs])
	return WSgrwNy75k4
def Vw4cGOeE3BUr2QP(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,PPmYnWkqTCfNH1u4yoRs):
	tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
	if e6TULIp9Qk3XgJ1C84AoSfsWh7dOG: tlZBeT1Y2RjIu()
	else: TVZjDLixQF3aSfcHt8E065()
	return
def ak6T4YuSbKgnP3eXL9cHAOC07BmWFQ():
	GHdYDixegkm9PJMN('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def TVZjDLixQF3aSfcHt8E065(PPmYnWkqTCfNH1u4yoRs=''):
	GHdYDixegkm9PJMN('','',PPmYnWkqTCfNH1u4yoRs,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def Sh23xAvu5CJQm9n1WrGH(name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	W7yLH5BMlXIcmiAVODef8QSNb4Zj = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	KK4WEqy9u1mj = name.lower()
	MmPd59qzTto3eGuvrJNL = ''
	for key in list(W7yLH5BMlXIcmiAVODef8QSNb4Zj.keys()):
		if key.lower() in KK4WEqy9u1mj: MmPd59qzTto3eGuvrJNL = W7yLH5BMlXIcmiAVODef8QSNb4Zj[key]
	if not MmPd59qzTto3eGuvrJNL:
		YBDKFZOGfyCHLPA1EaUz9MJ = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'url')
		for PPmYnWkqTCfNH1u4yoRs in list(h9zFQKnsNL.SITESURLS.keys()):
			J4GX5SPIvY1anesyTKWVZr8 = RRav1Sf7Px(h9zFQKnsNL.SITESURLS[PPmYnWkqTCfNH1u4yoRs][0],'url')
			if YBDKFZOGfyCHLPA1EaUz9MJ==J4GX5SPIvY1anesyTKWVZr8: MmPd59qzTto3eGuvrJNL = PPmYnWkqTCfNH1u4yoRs
	if not MmPd59qzTto3eGuvrJNL:
		KK4WEqy9u1mj = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
		for PPmYnWkqTCfNH1u4yoRs in list(h9zFQKnsNL.SITESURLS.keys()):
			zjB19pntWJaDObVhmYu4NLZk = RRav1Sf7Px(h9zFQKnsNL.SITESURLS[PPmYnWkqTCfNH1u4yoRs][0],'name')
			if KK4WEqy9u1mj==zjB19pntWJaDObVhmYu4NLZk: MmPd59qzTto3eGuvrJNL = PPmYnWkqTCfNH1u4yoRs
	if not MmPd59qzTto3eGuvrJNL: MmPd59qzTto3eGuvrJNL = name
	MmPd59qzTto3eGuvrJNL = MmPd59qzTto3eGuvrJNL.upper()
	return MmPd59qzTto3eGuvrJNL
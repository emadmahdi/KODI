# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'BOKRA'
xzA9sM3rG6IHd7jl8T = '_BKR_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
wXPtB6I0QKLTyD932sl5d = ['افلام للكبار','بكرا TV']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==370: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==371: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==372: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==374: w8YsNWfQ5gFluRvOmSd4Cb96H = tK0AgSaDdI7sy9clVCN(url)
	elif mode==375: w8YsNWfQ5gFluRvOmSd4Cb96H = TFy7CmcgxDhtPJZB5H23KborYUnk(url)
	elif mode==376: w8YsNWfQ5gFluRvOmSd4Cb96H = qImbFZ42QlREa(0,url)
	elif mode==377: w8YsNWfQ5gFluRvOmSd4Cb96H = qImbFZ42QlREa(1,url)
	elif mode==379: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-MENU-1st')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,379,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('right-side(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المميزة',FFLhlYUAsfJBXeQmRpzD7c14ZP6,375)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الأحدث',FFLhlYUAsfJBXeQmRpzD7c14ZP6,376)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'قائمة الممثلين',FFLhlYUAsfJBXeQmRpzD7c14ZP6,374)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="container"(.*?)top-menu',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items[7:]:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items[0:7]:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371)
	return
def tK0AgSaDdI7sy9clVCN(website=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-ACTORSMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="row cat Tags"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'http' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
			else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371)
	return
def TFy7CmcgxDhtPJZB5H23KborYUnk(website=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-FEATURED-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"MainContent"(.*?)main-title2',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('://',':///').replace('//','/').replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,372,afR4xElWyzgcNAUnKXBempC)
	return
def qImbFZ42QlREa(id,website=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-WATCHINGNOW-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-title2(.*?)class="row',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[id]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
				afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('://',':///').replace('//','/').replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
				v0TjHlLZqkRxUCpmNwSy8AndO('video',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,372,afR4xElWyzgcNAUnKXBempC)
	return
def txsXO7gSMnrwAh6NmJ9D(url,qOjIGBrnXhlx=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'vidpage_' in url:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('href="(/Album-.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
			txsXO7gSMnrwAh6NmJ9D(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class=" subcats"(.*?)class="col-md-3',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if qOjIGBrnXhlx==Vk54F7GcROfCy6HunEI and Ry3L7fdNGh and Ry3L7fdNGh[0].count('href')>1:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',url,371,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'titles')
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371)
	else:
		GEzxBN8rAh1d = []
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="col-md-3(.*?)col-xs-12',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="col-sm-8"(.*?)col-xs-12',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('://',':///').replace('//','/').replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
				if '/al_' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371,afR4xElWyzgcNAUnKXBempC)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) - +الحلقة +\d+',title,RSuYINdeamsK0t.DOTALL)
					if AWjJSatwokZ: title = '_MOD_مسلسل '+AWjJSatwokZ[0]
					if title not in GEzxBN8rAh1d:
						GEzxBN8rAh1d.append(title)
						v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371,afR4xElWyzgcNAUnKXBempC)
				else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,372,afR4xElWyzgcNAUnKXBempC)
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('class="".*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				title = 'صفحة '+Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,371,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'titles')
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('label-success mrg-btm-5 ">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	ynmiDuav5ICTeRsqj6Vb18Q = Vk54F7GcROfCy6HunEI
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('var url = "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]
	else: hj50MJnoOp6ZWaS1IQ8Elr = url.replace('/vidpage_','/Play/')
	if 'http' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6+hj50MJnoOp6ZWaS1IQ8Elr
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.strip('-')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'BOKRA-PLAY-2nd')
	nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ynmiDuav5ICTeRsqj6Vb18Q = RSuYINdeamsK0t.findall('src="(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
	if ynmiDuav5ICTeRsqj6Vb18Q:
		ynmiDuav5ICTeRsqj6Vb18Q = ynmiDuav5ICTeRsqj6Vb18Q[-1]
		if 'http' not in ynmiDuav5ICTeRsqj6Vb18Q: ynmiDuav5ICTeRsqj6Vb18Q = 'http:'+ynmiDuav5ICTeRsqj6Vb18Q
		if '/PLAY/' not in hj50MJnoOp6ZWaS1IQ8Elr:
			if 'embed.min.js' in ynmiDuav5ICTeRsqj6Vb18Q:
				FMX56ujmTslg8vOB7I13PbyV = RSuYINdeamsK0t.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
				if FMX56ujmTslg8vOB7I13PbyV:
					ZSWycnCgdUiDqbs5v6RM1LtuPw, deiMgnvPSY3ky = FMX56ujmTslg8vOB7I13PbyV[0]
					ynmiDuav5ICTeRsqj6Vb18Q = RRav1Sf7Px(ynmiDuav5ICTeRsqj6Vb18Q,'url')+'/v2/'+ZSWycnCgdUiDqbs5v6RM1LtuPw+'/config/'+deiMgnvPSY3ky+'.json'
		import f37xHeSwPL
		f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3([ynmiDuav5ICTeRsqj6Vb18Q],TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/Search/'+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
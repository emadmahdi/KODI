# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'FASELHD2'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_FH2_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['wwe']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==590: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==591: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==592: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==593: w8YsNWfQ5gFluRvOmSd4Cb96H = d3dvo9txDeRB7uzFLQ(url,text)
	elif mode==599: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	lseWcUVP5qY = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',lseWcUVP5qY,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD2-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',lseWcUVP5qY,599,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',lseWcUVP5qY,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured1')
	items = RSuYINdeamsK0t.findall('<strong>(.*?)</strong>.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details1')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-menu"(.*?)header-social',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		YbgxWEosLAIqy5CZD8 = RSuYINdeamsK0t.findall('<li (.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for Ak1pcoVisreCFTRyH6J7WgL in YbgxWEosLAIqy5CZD8:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',Ak1pcoVisreCFTRyH6J7WgL,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details2')
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD2-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ZRuNA9ydoHCXp = 0
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"archive-slider(.*?)<h4>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu: v8e07ENZbVzIjaMSQPAxLUyuKcWho = QQHXiFSA0jUsklmxbpaMztu[0]
	else: v8e07ENZbVzIjaMSQPAxLUyuKcWho = Vk54F7GcROfCy6HunEI
	if type=='featured1':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"slider-carousel"(.*?)</container>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		q0ZrEo62YLbBCfJ,ss285HRGmwx,HXhRgxEZ4d2Dek = zip(*items)
		items = zip(HXhRgxEZ4d2Dek,q0ZrEo62YLbBCfJ,ss285HRGmwx)
	elif type=='featured2':
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
	elif type=='filters':
		Ry3L7fdNGh = [FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in v8e07ENZbVzIjaMSQPAxLUyuKcWho:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<h4>(.*?)</h4>(.*?)</container>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مميزة',url,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured2')
		title = Ry3L7fdNGh[0][0]
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details3')
		return
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<h4>(.*?)</h4>(.*?)</container>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		title,UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	GEzxBN8rAh1d = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if any(value in title.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة).\d+',title,RSuYINdeamsK0t.DOTALL)
		if '/movseries/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,591,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and type==Vk54F7GcROfCy6HunEI:
			title = '_MOD_'+AWjJSatwokZ[0][0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,593,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,592,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,593,afR4xElWyzgcNAUnKXBempC)
	if type=='filters':
		lyNAzPtVKoUXJxYMb = RSuYINdeamsK0t.findall('"more_button_page":(.*?),',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if lyNAzPtVKoUXJxYMb:
			count = lyNAzPtVKoUXJxYMb[0]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'/offset/'+count
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة أخرى',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
	elif 'details' in type:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = 'صفحة '+Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,591,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details4')
	return
def d3dvo9txDeRB7uzFLQ(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD2-SEASONS_EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Yo3AtpSIM5ax6dUTwLk1qCgjeym7P = False
	if not type:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<seasons(.*?)</seasons>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if len(items)>1:
				lseWcUVP5qY = RRav1Sf7Px(url,'url')
				Yo3AtpSIM5ax6dUTwLk1qCgjeym7P = True
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
					title = Uo7Tbc29Eu(title)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,593,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,'episodes')
	if type=='episodes' or not Yo3AtpSIM5ax6dUTwLk1qCgjeym7P:
		ylKTDSkdQmUChwbX45ALeiu = RSuYINdeamsK0t.findall('<bkز*?image:url\((.*?)\)"></bk>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ylKTDSkdQmUChwbX45ALeiu: afR4xElWyzgcNAUnKXBempC = ylKTDSkdQmUChwbX45ALeiu[0]
		else: afR4xElWyzgcNAUnKXBempC = Vk54F7GcROfCy6HunEI
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<all-episodes(.*?)</all-episodes>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,592,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	MMJL8QqY6T7dv1onu,EKTx69zw3SMdmlPnkeb,VV2e6BuEOz9ta = [],[],[]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD2-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Od2iYMok9sHT6qXuSmvtKJ = RSuYINdeamsK0t.findall('العمر :.*?<strong">(.*?)</strong>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Od2iYMok9sHT6qXuSmvtKJ and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,Od2iYMok9sHT6qXuSmvtKJ): return
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('<iframe src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=__embed')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<slice-title(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('data-url="(.*?)".*?</i>(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<downloads(.*?)</downloads>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</div>(.*?)</div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__download')
	for JrvbaUIyLx9cWpY4HqZD32j in MMJL8QqY6T7dv1onu:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name = JrvbaUIyLx9cWpY4HqZD32j.split('?named')
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in EKTx69zw3SMdmlPnkeb:
			EKTx69zw3SMdmlPnkeb.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			VV2e6BuEOz9ta.append(JrvbaUIyLx9cWpY4HqZD32j)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(VV2e6BuEOz9ta,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	lseWcUVP5qY = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	url = lseWcUVP5qY+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url,'details5')
	return
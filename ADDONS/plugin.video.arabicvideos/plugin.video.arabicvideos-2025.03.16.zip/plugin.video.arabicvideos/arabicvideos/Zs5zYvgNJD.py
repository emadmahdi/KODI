# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ALKAWTHAR'
xzA9sM3rG6IHd7jl8T = '_KWT_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
def X42LMUrFfIY3oWeazj(mode,url,H4TFmtAe5rM8oY1lfPviVC,text):
	if   mode==130: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==131: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==132: w8YsNWfQ5gFluRvOmSd4Cb96H = GMXZ0AndlPkWcuBiy25ECLDghr(url)
	elif mode==133: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==134: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==135: w8YsNWfQ5gFluRvOmSd4Cb96H = xU0lJEy5CG3O1YRbic()
	elif mode==139: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,url)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,139,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-MENU-1st')
	Ry3L7fdNGh=RSuYINdeamsK0t.findall('dropdown-menu(.*?)dropdown-toggle',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[1]
	items=RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if '/conductor' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if '/category/' in url: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,132)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,131)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المسلسلات',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/543',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الأفلام',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/628',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'برامج الصغار والشباب',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/517',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'ابرز البرامج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/1763',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المحاضرات',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/943',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'عاشوراء',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/1353',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'البرامج الاجتماعية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/501',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'البرامج الدينية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/509',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'البرامج الوثائقية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/553',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'البرامج السياسية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/545',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'كتب',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/291',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'تعلم الفارسية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/88',132,Vk54F7GcROfCy6HunEI,'1')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أرشيف البرامج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/category/1279',132,Vk54F7GcROfCy6HunEI,'1')
	return
def txsXO7gSMnrwAh6NmJ9D(url):
	cIzabQoiNs = ['/religious','/social','/political','/films','/series']
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-TITLES-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('titlebar(.*?)titlebar',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if any(value in url for value in cIzabQoiNs):
		items = RSuYINdeamsK0t.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,133,afR4xElWyzgcNAUnKXBempC,'1')
	elif '/docs' in url:
		items = RSuYINdeamsK0t.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,133,afR4xElWyzgcNAUnKXBempC,'1')
	return
def GMXZ0AndlPkWcuBiy25ECLDghr(url):
	MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = url.split('/')[-1]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-CATEGORIES-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('parentcat(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh:
		SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,'1')
		return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall("href='(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,132,Vk54F7GcROfCy6HunEI,'1')
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,H4TFmtAe5rM8oY1lfPviVC):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-EPISODES-1st')
	items = RSuYINdeamsK0t.findall('totalpagecount=[\'"](.*?)[\'"]',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not items:
		url = RSuYINdeamsK0t.findall('class="news-detail-body".*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,134)
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	rj0RgeMpYOEZs6tSzoVcKHm87lU9q = int(items[0])
	name = RSuYINdeamsK0t.findall('main-title.*?</a> >(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if name: name = name[0].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	else: name = J2L6to3R1Z.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = url.split('/')[-1]
		if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/category/' + MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb + '/' + H4TFmtAe5rM8oY1lfPviVC
		nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-EPISODES-2nd')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('currentpagenumber(.*?)pagination',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,type,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',Vk54F7GcROfCy6HunEI)
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='628': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,133,afR4xElWyzgcNAUnKXBempC,'1')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,134,afR4xElWyzgcNAUnKXBempC)
	elif '/episode/' in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('playlist(.*?)col-md-12',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,134,afR4xElWyzgcNAUnKXBempC)
		elif '/category/628' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
				title = '_MOD_' + 'ملف التشغيل'
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,134)
		else:
			items = RSuYINdeamsK0t.findall('id="Categories.*?href=\'(.*?)\'',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = items[0].split('/')[-1]
			url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/category/' + MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb
			GMXZ0AndlPkWcuBiy25ECLDghr(url)
			return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		f6yKSzoPZRd3IkOn = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in f6yKSzoPZRd3IkOn:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('&amp;','&')
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,133)
	return
def h5hmzOAeWEPip(url):
	if '/news/' in url or '/episode/' in url:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-PLAY-1st')
		items = RSuYINdeamsK0t.findall("mobilevideopath.*?value='(.*?)'",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if items: url = items[0]
	qnUlyF2JXuGYdSA6Iac1(url,TVPm7Bz1XOwJ2,'video')
	return
def xU0lJEy5CG3O1YRbic():
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/live'
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-LIVE-1st')
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('live-container.*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]
	eDbTIrV6KLfz80 = {'Referer':FFLhlYUAsfJBXeQmRpzD7c14ZP6}
	HHA0ZI3kaPXocl7CsGjr = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,True,'ALKAWTHAR-LIVE-2nd')
	nqzvfpjFuS42ywk8 = HHA0ZI3kaPXocl7CsGjr.content
	cVbGQZ5wHCNO6pU8nKt2Ji = RSuYINdeamsK0t.findall('csrf-token" content="(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
	cVbGQZ5wHCNO6pU8nKt2Ji = cVbGQZ5wHCNO6pU8nKt2Ji[0]
	TTgshlfx72UH = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,'url')
	ynmiDuav5ICTeRsqj6Vb18Q = RSuYINdeamsK0t.findall("playUrl = '(.*?)'",nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
	ynmiDuav5ICTeRsqj6Vb18Q = TTgshlfx72UH+ynmiDuav5ICTeRsqj6Vb18Q[0]
	Mln9dk5vU0aRuFLhoXcgCB8HVy = {'X-CSRF-TOKEN':cVbGQZ5wHCNO6pU8nKt2Ji}
	dey3bshxM9ST6o = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,'POST',ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,Mln9dk5vU0aRuFLhoXcgCB8HVy,False,True,'ALKAWTHAR-LIVE-3rd')
	vOHS8JTkq04Uy21i7 = dey3bshxM9ST6o.content
	xIZTXEQJ7qtmF = RSuYINdeamsK0t.findall('"(.*?)"',vOHS8JTkq04Uy21i7,RSuYINdeamsK0t.DOTALL)
	xIZTXEQJ7qtmF = xIZTXEQJ7qtmF[0].replace('\/','/')
	qnUlyF2JXuGYdSA6Iac1(xIZTXEQJ7qtmF,TVPm7Bz1XOwJ2,'live')
	return
def zDkgCMXBmx2A(search,url=Vk54F7GcROfCy6HunEI):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if url==Vk54F7GcROfCy6HunEI:
		if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
		if search==Vk54F7GcROfCy6HunEI: return
		search = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(search)
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search?q='+search
		SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,Vk54F7GcROfCy6HunEI)
		return
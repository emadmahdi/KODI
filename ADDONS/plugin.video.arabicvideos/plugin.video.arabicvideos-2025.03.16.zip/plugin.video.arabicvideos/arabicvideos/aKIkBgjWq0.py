# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMAFANS'
headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
xzA9sM3rG6IHd7jl8T = '_CMF_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==90: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==91: w8YsNWfQ5gFluRvOmSd4Cb96H = XZA9vYcOi4(url)
	elif mode==92: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==94: w8YsNWfQ5gFluRvOmSd4Cb96H = DZjbwYA1GS7tsv()
	elif mode==95: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==99: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,99,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المضاف حديثا',Vk54F7GcROfCy6HunEI,94)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الأحدث',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=latest',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الأعلى تقيماً',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=imdb',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الأكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=view',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المثبت',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=pin',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'جديد الأفلام',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=newMovies',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'جديد الحلقات',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?type=newEpisodes',91)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'CIMAFANS-MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="mainmenu(.*?)nav',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('<li><a href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	wXPtB6I0QKLTyD932sl5d = ['افلام للكبار فقط']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,91)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="f-cats"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('<li><a href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,91)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def XZA9vYcOi4(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAFANS-ITEMS-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	else:
		headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'CIMAFANS-ITEMS-2nd')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="movies-items(.*?)class="listfoot"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	else: UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
	items = RSuYINdeamsK0t.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة [0-9]+',title,RSuYINdeamsK0t.DOTALL)
			if AWjJSatwokZ:
				title = '_MOD_'+AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,95,afR4xElWyzgcNAUnKXBempC)
					GEzxBN8rAh1d.append(title)
		elif '/video/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,92,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,91,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<a href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,91)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'CIMAFANS-EPISODES-1st')
	afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('img src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="episodes-panel(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		name = RSuYINdeamsK0t.findall('itemprop="title">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if name: name = name[1]
		else:
			name = J2L6to3R1Z.getInfoLabel('ListItem.Label')
			if ZZoLlKyInXc08j2pTGJ in name: name = name.split(ZZoLlKyInXc08j2pTGJ,1)[1]
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?name">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+name+' - '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,92,afR4xElWyzgcNAUnKXBempC)
	else:
		OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('class="movietitle"><a href="(.*?)">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if OFskSRKaxrlLWPGz9: ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title = OFskSRKaxrlLWPGz9[0]
		else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title = url,name
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,92,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,bbMoq8kVm9BzE6YRZdlr = [],[]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'CIMAFANS-PLAY-1st')
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('text-shadow: none;">(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="links-panel(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?__download'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('nav-tabs"(.*?)video-panel-more',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('id="(.*?)".*?embed src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			title = 'سيرفر '+id
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		items = RSuYINdeamsK0t.findall('data-server-src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def DZjbwYA1GS7tsv():
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'CIMAFANS-LATEST-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="index-last-movie(.*?)id="index-slider-movie',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if '/video/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,92,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,91,afR4xElWyzgcNAUnKXBempC)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/search.php?t='+search
	XZA9vYcOi4(url)
	return
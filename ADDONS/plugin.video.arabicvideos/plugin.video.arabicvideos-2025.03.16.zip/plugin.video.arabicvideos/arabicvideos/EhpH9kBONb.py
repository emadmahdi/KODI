# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫᬀ")
xzA9sM3rG6IHd7jl8T = Nlyfx1HnzOWCovke5(u"ࠫࡤࡒࡓࡕࡡࠪᬁ")
sshCBgJv0b2EDfKrjcUW = BZm7TqLPJfAVblDKsya85zFWXNMY
Qpumhn0cAkTLSE = V2RQwM8XjlrK(u"࠴࠴ᵯ")
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,url,YWCso5NMKO,H4TFmtAe5rM8oY1lfPviVC,Xb17xtEphFigA8dReBrGH):
	try: vEznYtihqcojIFrOkUTXdLR = str(Xb17xtEphFigA8dReBrGH[Nlyfx1HnzOWCovke5(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬂ")])
	except: vEznYtihqcojIFrOkUTXdLR = Vk54F7GcROfCy6HunEI
	if   Yz6schq9wSmiu3IOdke0DXPj5W==MpJ8GOKoic(u"࠵࠻࠶ᵰ"): w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ESXZrtnCfcDJGo01vFg(u"࠶࠼࠱ᵱ"): w8YsNWfQ5gFluRvOmSd4Cb96H = FCAzPVk0TRdufxtKHh(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==eAMGzHRQVs2KyCwPXljYhB(u"࠷࠶࠳ᵲ"): w8YsNWfQ5gFluRvOmSd4Cb96H = Uljxr5Jf87qnYZRNQb9SeX4KgTah(YWCso5NMKO,eAMGzHRQVs2KyCwPXljYhB(u"࠷࠶࠳ᵲ"))
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠱࠷࠵ᵳ"): w8YsNWfQ5gFluRvOmSd4Cb96H = Uljxr5Jf87qnYZRNQb9SeX4KgTah(YWCso5NMKO,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠱࠷࠵ᵳ"))
	elif Yz6schq9wSmiu3IOdke0DXPj5W==EM6qpnCBYQGA9kbgDVLfrP(u"࠲࠸࠷ᵴ"): w8YsNWfQ5gFluRvOmSd4Cb96H = H8isMcP3LoxCqXF0eOGSh(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ESXZrtnCfcDJGo01vFg(u"࠳࠹࠹ᵵ"): w8YsNWfQ5gFluRvOmSd4Cb96H = JqAjU4Ms16nw0f3FCr(url,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠴࠺࠻ᵶ"): w8YsNWfQ5gFluRvOmSd4Cb96H = fGMDbE7OnsHviFmK86UR40edLph(url,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==XCYALgFs2O3hZdpHrlMmB(u"࠵࠻࠽ᵷ"): w8YsNWfQ5gFluRvOmSd4Cb96H = oobFP4REhZiy5gtCWNDq(url,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠶࠼࠸ᵸ"): w8YsNWfQ5gFluRvOmSd4Cb96H = NfiVubJmFW4zPRgkUt59(url,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WXuJd8nz2spo146t(u"࠽࠶࠲ᵹ"): w8YsNWfQ5gFluRvOmSd4Cb96H = C1CaVLpgSNIHTZ5D3xB60()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠷࠷࠴ᵺ"): w8YsNWfQ5gFluRvOmSd4Cb96H = m1ZVd2iGfuJ()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MzgKWUQ4V5H(u"࠸࠸࠶ᵻ"): w8YsNWfQ5gFluRvOmSd4Cb96H = yownSVRNWUZ(vEznYtihqcojIFrOkUTXdLR,YWCso5NMKO,H4TFmtAe5rM8oY1lfPviVC)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==wAU9jKvmTM0(u"࠹࠹࠸ᵼ"): w8YsNWfQ5gFluRvOmSd4Cb96H = h48cGBzjfnrVvoZ5MElmx(vEznYtihqcojIFrOkUTXdLR,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==jXWzIZcDva4ikEUfN(u"࠺࠺࠺ᵽ"): w8YsNWfQ5gFluRvOmSd4Cb96H = giaB9sEXhAJIzWd(vEznYtihqcojIFrOkUTXdLR,YWCso5NMKO)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = eu1NswY9zkKC60I
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO(WsklGNp2CYzVQUag(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬃ"),g7yJo2LVuqx1trPe(u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨᬄ"),Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠵࠻࠷ᵾ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᬅ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬆ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪๆฺุ๋ࠠึ๋หห๐ࠧᬇ"),Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠶࠼࠲ᵿ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬈ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(wYTDlJC5vpOKynUEX3ge6W(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬉ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩᬊ"),Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"࠷࠶࠴ᶀ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬋ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ynxXU3gaiQ9GPCftr1q(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬌ"),QYSAUI5r46yil8cfaO(u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨᬍ"),Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"࠱࠷࠶ᶁ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬎ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(eAMGzHRQVs2KyCwPXljYhB(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬏ"),jXWzIZcDva4ikEUfN(u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᬐ"),Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠸࠸࠶ᶂ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᬑ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠧ࡭࡫ࡱ࡯ࠬᬒ"),nMt0iueCy6K+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᬓ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"࠻࠼࠽࠾ᶃ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬔ"),Nlyfx1HnzOWCovke5(u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧᬕ"),Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠴࠺࠸ᶄ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬖ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(EM6qpnCBYQGA9kbgDVLfrP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬗ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ࠭ᬘ"),Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"࠵࠻࠹ᶅ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬙ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(ESXZrtnCfcDJGo01vFg(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬚ"),WCPwmyVsb62KRlo(u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᬛ"),Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠶࠼࠲ᶆ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᬜ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(pnkrd2S84FJfN73KuiCYv(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬝ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬᬞ"),Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"࠷࠶࠳ᶇ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬟ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬠ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸࡛ࠠษฯฮࠤ฾ฺ่ศศํࠫᬡ"),Vk54F7GcROfCy6HunEI,jXWzIZcDva4ikEUfN(u"࠱࠷࠶ᶈ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬢ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(wAU9jKvmTM0(u"ࠪࡪࡴࡲࡤࡦࡴࠪᬣ"),g7yJo2LVuqx1trPe(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫᬤ"),Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"࠸࠸࠸ᶉ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬥ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡬ࡪࡰ࡮ࠫᬦ"),nMt0iueCy6K+cpHxZyU7vTtqmIw(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᬧ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"࠻࠼࠽࠾ᶊ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(WsklGNp2CYzVQUag(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬨ"),ynxXU3gaiQ9GPCftr1q(u"ࠩๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧᬩ"),Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠴࠺࠸ᶋ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬪ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(MpJ8GOKoic(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬫ"),cpHxZyU7vTtqmIw(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭ᬬ"),Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠵࠻࠹ᶌ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬭ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬮ"),WXuJd8nz2spo146t(u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩᬯ"),Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠶࠼࠲ᶍ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᬰ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(WXuJd8nz2spo146t(u"ࠪࡪࡴࡲࡤࡦࡴࠪᬱ"),XCYALgFs2O3hZdpHrlMmB(u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬᬲ"),Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"࠷࠶࠳ᶎ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬳ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡦࡰ࡮ࡧࡩࡷ᬴࠭"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠠษฯฮࠤ฾ฺ่ศศํࠫᬵ"),Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"࠱࠷࠶ᶏ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬶ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬷ"),pnkrd2S84FJfN73KuiCYv(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫᬸ"),Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠸࠸࠷ᶐ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬹ"))
	return
def C1CaVLpgSNIHTZ5D3xB60():
	v0TjHlLZqkRxUCpmNwSy8AndO(eAMGzHRQVs2KyCwPXljYhB(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬺ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭࡟ࡊࡒࡗࡣࠬᬻ")+EM6qpnCBYQGA9kbgDVLfrP(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡊࡒࡗ࡚ࠬᬼ"),Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠹࠹࠸ᶑ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(QYSAUI5r46yil8cfaO(u"ࠨ࡮࡬ࡲࡰ࠭ᬽ"),nMt0iueCy6K+WsklGNp2CYzVQUag(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᬾ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠼࠽࠾࠿ᶒ"))
	for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
		xzA9sM3rG6IHd7jl8T = YzowicIDTRusXZSU61(u"ࠪࡣࡎࡖࠧᬿ")+str(vEznYtihqcojIFrOkUTXdLR)+XCYALgFs2O3hZdpHrlMmB(u"ࠫࡤ࠭ᭀ")
		v0TjHlLZqkRxUCpmNwSy8AndO(MpJ8GOKoic(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᭁ"),xzA9sM3rG6IHd7jl8T+BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᭂ")+DVO3m2tJ4Hdh[vEznYtihqcojIFrOkUTXdLR],Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"࠻࠻࠺ᶓ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{ESXZrtnCfcDJGo01vFg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᭃ"):vEznYtihqcojIFrOkUTXdLR})
	return
def m1ZVd2iGfuJ():
	v0TjHlLZqkRxUCpmNwSy8AndO(wAU9jKvmTM0(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᭄"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡢࡑ࠸࡛࡟ࠨᭅ")+XCYALgFs2O3hZdpHrlMmB(u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡑ࠸࡛ࠧᭆ"),Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠼࠼࠵ᶔ"))
	v0TjHlLZqkRxUCpmNwSy8AndO(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡱ࡯࡮࡬ࠩᭇ"),nMt0iueCy6K+FGLEMi21Bfn(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᭈ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠿࠹࠺࠻ᶕ"))
	for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
		xzA9sM3rG6IHd7jl8T = ynxXU3gaiQ9GPCftr1q(u"࠭࡟ࡎࡗࠪᭉ")+str(vEznYtihqcojIFrOkUTXdLR)+pnkrd2S84FJfN73KuiCYv(u"ࠧࡠࠩᭊ")
		v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᭋ"),xzA9sM3rG6IHd7jl8T+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫᭌ")+DVO3m2tJ4Hdh[vEznYtihqcojIFrOkUTXdLR],Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠷࠷࠷ᶖ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,{l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭍"):vEznYtihqcojIFrOkUTXdLR})
	return
def Ha8hOZx3wRf(PPmYnWkqTCfNH1u4yoRs):
	global JF7pXwWrxt09,WDHNb37PSZIuLQCGzcJ21
	tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
	try:
		if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡎࡌࡉࡍࡏࠪ᭎") in PPmYnWkqTCfNH1u4yoRs: tlZBeT1Y2RjIu(PPmYnWkqTCfNH1u4yoRs)
		else: tlZBeT1Y2RjIu()
		nwg8eh5x4Go = eu1NswY9zkKC60I
	except:
		ha6J2Q31InwURpklLx94TS75()
		nwg8eh5x4Go = YOHXqtbQTBfKerIZ
	PPmYnWkqTCfNH1u4yoRs = rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs)
	if nwg8eh5x4Go:
		qJAOp7HgfKeMQkDau(PPmYnWkqTCfNH1u4yoRs,ynxXU3gaiQ9GPCftr1q(u"ࠬ็ิๅࠢ็่ศูแࠨ᭏"),Gb6kwVlSQ4MU=WsklGNp2CYzVQUag(u"࠳࠲࠳࠴ᶗ"))
		JF7pXwWrxt09 += pwxH3oREFm5v98BCZ1QVtzMJOc
		WDHNb37PSZIuLQCGzcJ21 += ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࠠ࠯ࠢࠪ᭐")+PPmYnWkqTCfNH1u4yoRs
	else: qJAOp7HgfKeMQkDau(PPmYnWkqTCfNH1u4yoRs,Vk54F7GcROfCy6HunEI,Gb6kwVlSQ4MU=ESXZrtnCfcDJGo01vFg(u"࠳࠳࠴࠵ᶘ"))
	return
WHl0X13zIVuGyP4eK = {}
def cL8tpP2Fa0k57XlIRbUQ(NGRhIVg7fa0q85TnljdDr62=YOHXqtbQTBfKerIZ):
	global JF7pXwWrxt09,WDHNb37PSZIuLQCGzcJ21,WHl0X13zIVuGyP4eK
	if not NGRhIVg7fa0q85TnljdDr62:
		WHl0X13zIVuGyP4eK = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,MpJ8GOKoic(u"ࠧࡥ࡫ࡦࡸࠬ᭑"),QYSAUI5r46yil8cfaO(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ᭒"),WsklGNp2CYzVQUag(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧ᭓"))
		if WHl0X13zIVuGyP4eK: return
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(MzgKWUQ4V5H(u"ࠪࡧࡪࡴࡴࡦࡴࠪ᭔"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᭕"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬำส๊ࠢอ้้ฬ่ࠠา๊ࠤฬ๊โศศ่อࠥ࠴࠮ࠡีํๅา฻ࠠศๆหี๋อๅอࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎ࠠศๆอ๎ࠥ็๊ࠡษ็ฬึ์วๆฮࠣัฯ๏๋ࠠีอาึาࠠๆ่๊หࠥ็โุࠢส่ศ่ำศ็ࠣห้ืฦ๋ีํอࠥ࠴࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳࠴่ࠠา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤ฾อฯสࠢฦๆ้ࠦๅ็ࠢ࠶ࠤิ่ววไࠣࡠࡳࡢ࡮ࠨ᭖")+nMt0iueCy6K+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ᭗")+ZZoLlKyInXc08j2pTGJ)
	if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return
	igFtOzLBeQu(b8f2icUnEswC9Ja,b8f2icUnEswC9Ja,b8f2icUnEswC9Ja)
	jfzVdXNLE7SOTplc4eFaCwxI3BPnm = h9zFQKnsNL.menuItemsLIST
	JF7pXwWrxt09,WDHNb37PSZIuLQCGzcJ21,threads = ufmXvxgoHGDwZtjsLkR05i,Vk54F7GcROfCy6HunEI,{}
	for PPmYnWkqTCfNH1u4yoRs in IIJTHtKar50hg3UzuLdl4yDxvNQA1:
		Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
		threads[PPmYnWkqTCfNH1u4yoRs] = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=Ha8hOZx3wRf,args=(PPmYnWkqTCfNH1u4yoRs,))
		threads[PPmYnWkqTCfNH1u4yoRs].start()
	else:
		for PPmYnWkqTCfNH1u4yoRs in list(threads.keys()): threads[PPmYnWkqTCfNH1u4yoRs].join()
	h9zFQKnsNL.menuItemsLIST[:] = jfzVdXNLE7SOTplc4eFaCwxI3BPnm
	WHl0X13zIVuGyP4eK = {}
	for PPmYnWkqTCfNH1u4yoRs in list(threads.keys()):
		try: eesqS1nV7XcUoO9Ff = h9zFQKnsNL.menuItemsDICT[PPmYnWkqTCfNH1u4yoRs]
		except: continue
		PPmYnWkqTCfNH1u4yoRs = eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡠࡎࡖࡘࡤ࠭᭘")+rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs)
		for hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,NBnKOkHsvLd,YWCso5NMKO,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx in eesqS1nV7XcUoO9Ff:
			if not EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ࠰࠱࠲࠳࠭᭙")
			else:
				if EDy0Rs9liwjZvJY.count(FGLEMi21Bfn(u"ࠩࡢࠫ᭚"))>pwxH3oREFm5v98BCZ1QVtzMJOc: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.split(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡣࠬ᭛"),RXnhpCUk4M1TvgJE)[RXnhpCUk4M1TvgJE]
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(MpJ8GOKoic(u"ࠫࢥ࠭᭜"),Vk54F7GcROfCy6HunEI).replace(jXWzIZcDva4ikEUfN(u"ࠬࠦࡈࡅࠩ᭝"),Vk54F7GcROfCy6HunEI).replace(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡈࡅࠢࠪ᭞"),Vk54F7GcROfCy6HunEI)
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧแࠩ᭟"),Vk54F7GcROfCy6HunEI).replace(ESXZrtnCfcDJGo01vFg(u"ࠨหࠪ᭠"),ynxXU3gaiQ9GPCftr1q(u"๊ࠩࠫ᭡")).replace(wAU9jKvmTM0(u"ࠪศࠬ᭢"),SSBkx0WbN1asnDCQV6tIj(u"ࠫํ࠭᭣"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(YzowicIDTRusXZSU61(u"ࠬษࠧ᭤"),wYTDlJC5vpOKynUEX3ge6W(u"࠭วࠨ᭥")).replace(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧฦࠩ᭦"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨษࠪ᭧")).replace(QYSAUI5r46yil8cfaO(u"ࠩลࠫ᭨"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪหࠬ᭩"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"้ࠫษࠧ᭪"),EM6qpnCBYQGA9kbgDVLfrP(u"๊ࠬวࠨ᭫")).replace(FGLEMi21Bfn(u"࠭ไฦ᭬ࠩ"),ynxXU3gaiQ9GPCftr1q(u"ࠧๅษࠪ᭭")).replace(YzowicIDTRusXZSU61(u"ࠨๆลࠫ᭮"),FGLEMi21Bfn(u"ࠩ็หࠬ᭯"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ๒ࠬ᭰"),Vk54F7GcROfCy6HunEI).replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠫ๐࠭᭱"),Vk54F7GcROfCy6HunEI).replace(wAU9jKvmTM0(u"ࠬ๕ࠧ᭲"),Vk54F7GcROfCy6HunEI).replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭์ࠨ᭳"),Vk54F7GcROfCy6HunEI)
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(WCPwmyVsb62KRlo(u"ࠧ๑ࠩ᭴"),Vk54F7GcROfCy6HunEI).replace(pnkrd2S84FJfN73KuiCYv(u"ࠨ๏ࠪ᭵"),Vk54F7GcROfCy6HunEI).replace(pnkrd2S84FJfN73KuiCYv(u"ࠩ๕ࠫ᭶"),Vk54F7GcROfCy6HunEI).replace(SSBkx0WbN1asnDCQV6tIj(u"ࠪ๕ࠬ᭷"),Vk54F7GcROfCy6HunEI)
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(FGLEMi21Bfn(u"ࠫࢁ࠭᭸"),Vk54F7GcROfCy6HunEI).replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࢄࠧ᭹"),Vk54F7GcROfCy6HunEI)
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(WXuJd8nz2spo146t(u"࠭ว้่่ࠣฬ๐ๆࠨ᭺"),Vk54F7GcROfCy6HunEI).replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧิ์่ห๊ࠥว๋ฬࠪ᭻"),Vk54F7GcROfCy6HunEI)
				LyRcpDsgZPTaJxCSXtumjbF = [wYTDlJC5vpOKynUEX3ge6W(u"ࠨษ็฽ฬฮࠧ᭼"),eAMGzHRQVs2KyCwPXljYhB(u"ࠩั๎ฬ๊ࠧ᭽"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪห้ฮ่ๆࠩ᭾"),SSBkx0WbN1asnDCQV6tIj(u"ࠫฬ๊ว็ࠩ᭿"),Nlyfx1HnzOWCovke5(u"ࠬอืโษ็ࠫᮀ"),pnkrd2S84FJfN73KuiCYv(u"࠭อศๆํ๋ࠬᮁ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧศๆ฽หื࠭ᮂ"),cpHxZyU7vTtqmIw(u"ࠨืส่า࠭ᮃ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩส่ิ๐ๆࠨᮄ"),eAMGzHRQVs2KyCwPXljYhB(u"้ࠪํอไ๋ัࠪᮅ"),pnkrd2S84FJfN73KuiCYv(u"ࠫฬู๊ศๆ่ࠫᮆ"),FGLEMi21Bfn(u"ࠬอูๆษ็ࠫᮇ")]
				if not any(GIA5xasoXQJ6MelpHD in EDy0Rs9liwjZvJY for GIA5xasoXQJ6MelpHD in LyRcpDsgZPTaJxCSXtumjbF): EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(SSBkx0WbN1asnDCQV6tIj(u"࠭วๅࠩᮈ"),Vk54F7GcROfCy6HunEI)
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧศะิ๎ࠬᮉ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨษัี๎࠭ᮊ")).replace(MzgKWUQ4V5H(u"ࠩสะ๋ฮ้ࠨᮋ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪหั์ศ๋ࠩᮌ")).replace(ESXZrtnCfcDJGo01vFg(u"ࠫ฾อฦๅ์๊ࠫᮍ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬ฿ววๆํࠫᮎ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(SSBkx0WbN1asnDCQV6tIj(u"࠭วอ่ห๎์࠭ᮏ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧศฮ้ฬ๏࠭ᮐ")).replace(XCYALgFs2O3hZdpHrlMmB(u"ࠨ฻ิฬ๏ํࠧᮑ"),QYSAUI5r46yil8cfaO(u"ࠩ฼ีอ๐ࠧᮒ")).replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠪีํ๋ว็ีํ๋ࠬᮓ"),ESXZrtnCfcDJGo01vFg(u"ࠫึ๎ๅศ่ึ๎ࠬᮔ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬเัษ์๊ࠫᮕ"),g7yJo2LVuqx1trPe(u"ฺ࠭าสํࠫᮖ")).replace(WXuJd8nz2spo146t(u"้่ࠧࠢืู้ไศฬࠪᮗ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠨ็ึุ่๊วหࠩᮘ")).replace(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩส฾ฬ์้ࠨᮙ"),WsklGNp2CYzVQUag(u"ࠪห฿อๆ๋ࠩᮚ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(eAMGzHRQVs2KyCwPXljYhB(u"ࠫฯอั๋ะํࠫᮛ"),Nlyfx1HnzOWCovke5(u"ࠬะวา์ัࠫᮜ")).replace(ynxXU3gaiQ9GPCftr1q(u"࠭ฮ๋ษ็ࠤ฾๊ๅ๋ࠩᮝ"),WCPwmyVsb62KRlo(u"ࠧฯ์ส่ࠬᮞ")).replace(SSBkx0WbN1asnDCQV6tIj(u"ࠨ็๋ื๏่๊่ࠩᮟ"),ynxXU3gaiQ9GPCftr1q(u"่ࠩ์ุ๐โ๊ࠩᮠ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"๋๋ࠪี้ࠨᮡ"),MzgKWUQ4V5H(u"ࠫ์์ฯ๋ࠩᮢ")).replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠬํๆะ์๊ࠫᮣ"),MpJ8GOKoic(u"࠭็็ัํࠫᮤ")).replace(SSBkx0WbN1asnDCQV6tIj(u"้ࠧอสส็๐็ࠨᮥ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ๊ฮหห่๊ࠨᮦ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩอ่๏็า๋๊้๎์࠭ᮧ"),WXuJd8nz2spo146t(u"ࠪฮ้็า๋๊้ࠫᮨ")).replace(ynxXU3gaiQ9GPCftr1q(u"ࠫฯ๊แำ์๋๊๏ํࠧᮩ"),XCYALgFs2O3hZdpHrlMmB(u"ࠬะไโิํ์᮪๋࠭")).replace(QYSAUI5r46yil8cfaO(u"่࠭ࠡๅิฮํ์᮫ࠧ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"้ࠧๅิฮํ์ࠧᮬ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨษ็ัฬ๊๊่ࠩᮭ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩะห้๐็ࠨᮮ")).replace(WCPwmyVsb62KRlo(u"้ࠪํู໌ใ์ࠪᮯ"),XCYALgFs2O3hZdpHrlMmB(u"๊ࠫ๎ำ๋ไ์ࠫ᮰")).replace(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬอไศ่่๎ࠬ᮱"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ว็็ํࠫ᮲"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(g7yJo2LVuqx1trPe(u"ࠧศๆ่ืู้ไศฬࠪ᮳"),wAU9jKvmTM0(u"ࠨ็ึุ่๊วหࠩ᮴")).replace(ynxXU3gaiQ9GPCftr1q(u"ࠩส่อืวๆฮࠪ᮵"),Nlyfx1HnzOWCovke5(u"ࠪฬึอๅอࠩ᮶")).replace(SSBkx0WbN1asnDCQV6tIj(u"่ࠫอัห๊้ࠫ᮷"),g7yJo2LVuqx1trPe(u"้ࠬัห๊้ࠫ᮸"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(jXWzIZcDva4ikEUfN(u"࠭อา๊หࠫ᮹"),V2RQwM8XjlrK(u"ࠧฮำหࠫᮺ")).replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠨษ็ห๋อิ๋ัࠪᮻ"),YzowicIDTRusXZSU61(u"ࠩส๊ฬฺ๊ะࠩᮼ")).replace(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪหุ๐่๋้ࠪᮽ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫฬู๊้์ࠪᮾ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(WCPwmyVsb62KRlo(u"ࠬ฿ัษ๋ࠪᮿ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ู࠭าสํࠫᯀ")).replace(MzgKWUQ4V5H(u"ࠧหำๆํࠬᯁ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠨฬิ็๏࠭ᯂ")).replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩอี่๐็ࠨᯃ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪฮึ้๊ࠨᯄ")).replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫฬ๊ๅืษไࠫᯅ"),MpJ8GOKoic(u"๋ࠬึศใࠪᯆ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ั๋ษู๎ࠬᯇ"),YzowicIDTRusXZSU61(u"ࠧา์สฺฮ࠭ᯈ")).replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨำํห฻ํࠧᯉ"),wAU9jKvmTM0(u"ࠩิ๎ฬ฼ษࠨᯊ")).replace(WXuJd8nz2spo146t(u"ࠪหุ๐่๋้ࠪᯋ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫฬู๊้์ࠪᯌ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"้่ࠬๆ์าํࠬᯍ"),FGLEMi21Bfn(u"࠭ใ้็ํำ๏࠭ᯎ")).replace(g7yJo2LVuqx1trPe(u"ࠧไ๊่๎ิ๐็ࠨᯏ"),ynxXU3gaiQ9GPCftr1q(u"ࠨๅ๋้๏ี๊ࠨᯐ")).replace(pnkrd2S84FJfN73KuiCYv(u"ࠩส๊๏๋๊ࠨᯑ"),jXWzIZcDva4ikEUfN(u"ࠪห๋๋๊ࠨᯒ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(Nlyfx1HnzOWCovke5(u"ࠫฬ์๊ๆ์ื๊ࠬᯓ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬอๆๆ์ื๊ࠬᯔ")).replace(YzowicIDTRusXZSU61(u"࠭ว็็์ࠫᯕ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧศ่่๎ู์ࠧᯖ")).replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠨษ้้๏࠭ᯗ"),pnkrd2S84FJfN73KuiCYv(u"ࠩส๊๊๐ิ็ࠩᯘ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(MzgKWUQ4V5H(u"ࠪห๋๋๊ี่ื๊ࠬᯙ"),g7yJo2LVuqx1trPe(u"ࠫฬ์ๅ๋ึ้ࠫᯚ")).replace(pnkrd2S84FJfN73KuiCYv(u"ࠬอไศ่่๎ู์ࠧᯛ"),XCYALgFs2O3hZdpHrlMmB(u"࠭ว็็ํุ๋࠭ᯜ")).replace(wAU9jKvmTM0(u"ࠧศใ็ห๊ࠦๅิๆึ่ฬะࠧᯝ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠨษไ่ฬ๋้ࠠ็ึุ่๊วหࠩᯞ"))
				EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࠰ࠫᯟ")).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if EDy0Rs9liwjZvJY not in list(WHl0X13zIVuGyP4eK.keys()): WHl0X13zIVuGyP4eK[EDy0Rs9liwjZvJY] = {}
			WHl0X13zIVuGyP4eK[EDy0Rs9liwjZvJY][PPmYnWkqTCfNH1u4yoRs] = [hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,c7E603KRhbToig9V4yx,NBnKOkHsvLd,YWCso5NMKO,m6cEejX1UO0HwpuvqL7xGA2VWJ,GeDUpHhCROtPrx]
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,WsklGNp2CYzVQUag(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫᯠ"),XCYALgFs2O3hZdpHrlMmB(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩᯡ"),WHl0X13zIVuGyP4eK,piwNWcJEe9m)
	if JF7pXwWrxt09>=Qpumhn0cAkTLSE: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᯢ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧᯣ")+str(JF7pXwWrxt09)+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࠡ็๋ๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้้ࠠๆิฬࠦๅีๅ็อูࠥศษ้สࠤ฾อฯส่๊ࠢࠥอไฦ่อี๋๐สࠡ฻้ำ่่ࠦศๆ่์ฬู่้ࠡํ࠾ࠬᯤ")+WDHNb37PSZIuLQCGzcJ21)
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᯥ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ᯦"))
	igFtOzLBeQu(I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB)
	sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	return
def zQZPhw6F3eXtqYEIdMVGvHpnamfNr(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
	F29ms0aOy3NkqxRP14wo = h9zFQKnsNL.menuItemsLIST
	h9zFQKnsNL.menuItemsLIST[:] = []
	if oX6deUmzM4yS0WfJg5pvxra and ynxXU3gaiQ9GPCftr1q(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᯧ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		w8YsNWfQ5gFluRvOmSd4Cb96H = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡱ࡯ࡳࡵࠩᯨ"),Nlyfx1HnzOWCovke5(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᯩ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᯪ")+vEznYtihqcojIFrOkUTXdLR)
	elif WXuJd8nz2spo146t(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᯫ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7 or WsklGNp2CYzVQUag(u"ࠨࡡ࡙ࡓࡉࡥࠧᯬ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		import WWria3lCPQ
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = YzowicIDTRusXZSU61(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧᯭ")
		if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡣࡑࡏࡖࡆࡡࠪᯮ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			try: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,WCPwmyVsb62KRlo(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᯯ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯰ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᯱ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈ᯲ࠬ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᯳࠭"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ᯴"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,WsklGNp2CYzVQUag(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᯵"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᯶"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭᯷"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		if wAU9jKvmTM0(u"࠭࡟ࡗࡑࡇࡣࠬ᯸") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			try: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,ESXZrtnCfcDJGo01vFg(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᯹"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᯺"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ᯻"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ᯼"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᯽"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ᯾"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		w8YsNWfQ5gFluRvOmSd4Cb96H = h9zFQKnsNL.menuItemsLIST
		if oX6deUmzM4yS0WfJg5pvxra: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,Nlyfx1HnzOWCovke5(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭᯿"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨᰀ")+vEznYtihqcojIFrOkUTXdLR,w8YsNWfQ5gFluRvOmSd4Cb96H,piwNWcJEe9m)
	h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def tt0PHpN1xwrL(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
	F29ms0aOy3NkqxRP14wo = h9zFQKnsNL.menuItemsLIST
	h9zFQKnsNL.menuItemsLIST[:] = []
	if oX6deUmzM4yS0WfJg5pvxra and jXWzIZcDva4ikEUfN(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᰁ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		w8YsNWfQ5gFluRvOmSd4Cb96H = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࡯࡭ࡸࡺࠧᰂ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᰃ"),SSBkx0WbN1asnDCQV6tIj(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫᰄ")+vEznYtihqcojIFrOkUTXdLR)
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠬࡥࡌࡊࡘࡈࡣࠬᰅ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7 or MzgKWUQ4V5H(u"࠭࡟ࡗࡑࡇࡣࠬᰆ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		import n4KTbzCNIs
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬᰇ")
		if FGLEMi21Bfn(u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨᰈ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			try: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,HOxJyt7l8osNeCjZFMQGi4Sr(u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᰉ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+FGLEMi21Bfn(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰊ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᰋ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,V2RQwM8XjlrK(u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᰌ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+V2RQwM8XjlrK(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰍ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᰎ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᰏ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰐ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᰑ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		if NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡤ࡜ࡏࡅࡡࠪᰒ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			try: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,FGLEMi21Bfn(u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᰓ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+MzgKWUQ4V5H(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰔ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᰕ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			try: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(vEznYtihqcojIFrOkUTXdLR,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᰖ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tFleBaQ2fUrNiPdu3k8cpjWCxS7+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰗ"),eu1NswY9zkKC60I)
			except: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅไ้์ฬะࠧᰘ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		w8YsNWfQ5gFluRvOmSd4Cb96H = h9zFQKnsNL.menuItemsLIST
		if oX6deUmzM4yS0WfJg5pvxra: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,WCPwmyVsb62KRlo(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᰙ"),NNjUsZzEcFOAoKry2CDMgb1(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬᰚ")+vEznYtihqcojIFrOkUTXdLR,w8YsNWfQ5gFluRvOmSd4Cb96H,piwNWcJEe9m)
	h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def yownSVRNWUZ(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7,OOcWBhI6azRmLQnrE):
	igFtOzLBeQu(XVgJmyC4wSjDON,XVgJmyC4wSjDON,b8f2icUnEswC9Ja)
	if OOcWBhI6azRmLQnrE: cL8tpP2Fa0k57XlIRbUQ(eu1NswY9zkKC60I)
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᰛ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 and not OOcWBhI6azRmLQnrE: cL8tpP2Fa0k57XlIRbUQ(YOHXqtbQTBfKerIZ)
	wbnzQ7FrZ3H = tFleBaQ2fUrNiPdu3k8cpjWCxS7.replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᰜ"),Vk54F7GcROfCy6HunEI).replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᰝ"),Vk54F7GcROfCy6HunEI).replace(QYSAUI5r46yil8cfaO(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᰞ"),Vk54F7GcROfCy6HunEI)
	if not OOcWBhI6azRmLQnrE:
		v0TjHlLZqkRxUCpmNwSy8AndO(ynxXU3gaiQ9GPCftr1q(u"ࠪࡰ࡮ࡴ࡫ࠨᰟ"),jXWzIZcDva4ikEUfN(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢส่ศ่ำศ็ࠪᰠ"),Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"࠺࠺࠸ᶙ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᰡ")+wbnzQ7FrZ3H,Vk54F7GcROfCy6HunEI,{WCPwmyVsb62KRlo(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰢ"):vEznYtihqcojIFrOkUTXdLR})
		v0TjHlLZqkRxUCpmNwSy8AndO(ynxXU3gaiQ9GPCftr1q(u"ࠧ࡭࡫ࡱ࡯ࠬᰣ"),nMt0iueCy6K+FGLEMi21Bfn(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᰤ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠽࠾࠿࠹ᶚ"))
		tt8LGEdJs5hcFC9krZ3BHWAjSoY = [ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩฦๅ้อๅࠨᰥ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ุ้๊ࠪำๅษอࠫᰦ"),QYSAUI5r46yil8cfaO(u"ู๊ࠫัฮ์สฮࠬᰧ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠬฮัศ็ฯࠫᰨ"),SSBkx0WbN1asnDCQV6tIj(u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬᰩ"),ESXZrtnCfcDJGo01vFg(u"ࠧา็ูห๋࠭ᰪ"),cpHxZyU7vTtqmIw(u"ࠨละำะ࠳รฯำࠪᰫ"),wAU9jKvmTM0(u"ࠩึ่ฬูไࠨᰬ"),EM6qpnCBYQGA9kbgDVLfrP(u"้ࠪํู๊ใ๋ࠪᰭ"),MpJ8GOKoic(u"ࠫศฺ็า࠯ฦ็ะืࠧᰮ"),V2RQwM8XjlrK(u"ࠬอไร่ࠪᰯ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ึฮๅࠪᰰ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧา์สฺฮ࠭ᰱ"),cpHxZyU7vTtqmIw(u"ࠨ่ํฮๆ๊ใิࠩᰲ"),pnkrd2S84FJfN73KuiCYv(u"่้ࠩะ๊๊็ࠩᰳ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪฬะࠦอ๋ࠩᰴ"),wAU9jKvmTM0(u"ࠫิ๐ๆ๋หࠪᰵ"),g7yJo2LVuqx1trPe(u"ูࠬๆ้ษอࠫᰶ"),ynxXU3gaiQ9GPCftr1q(u"࠭รฯำ์᰷ࠫ")]
		OOcWBhI6azRmLQnrE = ufmXvxgoHGDwZtjsLkR05i
		for fUcnRPHrwtEgXodJp95vyO7A4 in tt8LGEdJs5hcFC9krZ3BHWAjSoY:
			OOcWBhI6azRmLQnrE += pwxH3oREFm5v98BCZ1QVtzMJOc
			v0TjHlLZqkRxUCpmNwSy8AndO(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᰸"),xzA9sM3rG6IHd7jl8T+fUcnRPHrwtEgXodJp95vyO7A4,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"࠼࠼࠳ᶛ"),Vk54F7GcROfCy6HunEI,str(OOcWBhI6azRmLQnrE),wbnzQ7FrZ3H,Vk54F7GcROfCy6HunEI,{MpJ8GOKoic(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᰹"):vEznYtihqcojIFrOkUTXdLR})
	else:
		x0xd8Q9K4AHojsS567gIfWbOwv = [cpHxZyU7vTtqmIw(u"ࠩสๅ้อๅࠨ᰺"),FGLEMi21Bfn(u"ࠪࡱࡴࡼࡩࡦࠩ᰻"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫๆ๐ไๆࠩ᰼"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ็ไๆࠩ᰽")]
		avVhkSxXDBifGPcCWzYJsnm5Q = [EM6qpnCBYQGA9kbgDVLfrP(u"࠭ๅิๆึ่ࠬ᰾"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ᰿")]
		QR49GIikjgTSayBmPWv5uE = [SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ็ึหึำࠧ᱀"),wAU9jKvmTM0(u"่ࠩืึำ๊ศฬࠪ᱁")]
		q4oO9jKFzHfVIxkRWYn = [ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪฬึอๅอࠩ᱂"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡸ࡮࡯ࡸࠩ᱃"),WCPwmyVsb62KRlo(u"ࠬะไโิํ์๋࠭᱄"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭สๅ์ไึ๏๎ๆࠨ᱅")]
		idgQ8u5HFlCz2DnJjMpUsrG90 = [ESXZrtnCfcDJGo01vFg(u"ࠧศ่่๎ࠬ᱆"),eAMGzHRQVs2KyCwPXljYhB(u"ࠨๅิฮํ์ࠧ᱇"),ynxXU3gaiQ9GPCftr1q(u"ࠩๆหึะ่็ࠩ᱈"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡯࡮ࡪࡳࠨ᱉"),ESXZrtnCfcDJGo01vFg(u"ࠫ฼็ไࠨ᱊"),MzgKWUQ4V5H(u"ࠬอืโษ็ࠫ᱋")]
		nPtvlBeUcTW4ZaIC0s7bmVLj = [ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ัๆุส๊ࠬ᱌")]
		DZjbwYA1GS7tsv = [ynxXU3gaiQ9GPCftr1q(u"ࠧศฯาฯࠬᱍ"),WCPwmyVsb62KRlo(u"ࠨษัีࠬᱎ"),FGLEMi21Bfn(u"่ࠩ์ำืࠧᱏ"),pnkrd2S84FJfN73KuiCYv(u"ࠪะิ๐ฯࠨ᱐"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"๊ࠫ฼วโࠩ᱑"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬำฯ๋อࠪ᱒")]
		aTMQO2Lf1PRkBGYErlqVJ9HSxc = [jXWzIZcDva4ikEUfN(u"࠭ำๅษึ่ࠬ᱓"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧิๆึ่์࠭᱔")]
		qop9tzhdMIaR2iE1G = [BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨษ฽ห๋๐ࠧ᱕"),wYTDlJC5vpOKynUEX3ge6W(u"่ࠩ์ุ๐โ๊ࠩ᱖"),ESXZrtnCfcDJGo01vFg(u"ࠪ็้๐ศࠨ᱗"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫา็ไࠨ᱘"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡳࡵࡴ࡫ࡦࠫ᱙")]
		TFy7CmcgxDhtPJZB5H23KborYUnk = [ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭วไอิࠫᱚ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧศึ๊ีࠬᱛ"),FGLEMi21Bfn(u"ࠨ็่๎ืํࠧᱜ"),SSBkx0WbN1asnDCQV6tIj(u"ࠩส฽้๏ࠧᱝ"),ynxXU3gaiQ9GPCftr1q(u"้ࠪำะวา้ࠪᱞ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๊ࠫิสศำสฮࠬᱟ"),wAU9jKvmTM0(u"ࠬอโ้๋ࠪᱠ")]
		NO6t5oQ4V0 = [g7yJo2LVuqx1trPe(u"࠭วๅษ้ࠫᱡ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧฮษ็๎ࠬᱢ"),XCYALgFs2O3hZdpHrlMmB(u"ࠨ็ฮฬฯ࠭ᱣ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩิหหาࠧᱤ")]
		Xg8LYfpSW34jdubs1R = [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ฺࠪา้ࠧᱥ"),pnkrd2S84FJfN73KuiCYv(u"่ࠫ๎ๅ๋ัํࠫᱦ")]
		KKsb5cA9uoCLW = [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬื๊ศุ๊ࠫᱧ"),MpJ8GOKoic(u"࠭ใ้ำ๊ࠫᱨ"),SSBkx0WbN1asnDCQV6tIj(u"ࠧๆืสี฾ํࠧᱩ"),ynxXU3gaiQ9GPCftr1q(u"ࠨึ๋ฮࠬᱪ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩิ๎ฬ฼ษࠨᱫ")]
		YIuVOnJm7USbpoQyiFGW04DB5Nw = [HOxJyt7l8osNeCjZFMQGi4Sr(u"๊ࠪ๏ะแๅๅึࠫᱬ"),g7yJo2LVuqx1trPe(u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬᱭ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠬ์๊หใ็๎ู่ࠧᱮ")]
		FhUTLMZkj7ueyvVmKrAac = [kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ๅๆอ็๎๋࠭ᱯ"),cpHxZyU7vTtqmIw(u"ࠧศึัหฺ࠭ᱰ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠨ่ฯ์๊࠭ᱱ")]
		xU0lJEy5CG3O1YRbic = [jXWzIZcDva4ikEUfN(u"ࠩหฯࠥำ๊ࠨᱲ"),wAU9jKvmTM0(u"ࠪࡰ࡮ࡼࡥࠨᱳ"),SSBkx0WbN1asnDCQV6tIj(u"ࠫ็์ว่ࠩᱴ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"่ࠬๆ้ษอࠫᱵ")]
		mahPZB9SnqGO3 = [Nlyfx1HnzOWCovke5(u"࠭ฯ๋่ࠪᱶ"),XCYALgFs2O3hZdpHrlMmB(u"ࠧศั฼๎์࠭ᱷ"),FGLEMi21Bfn(u"ࠨิํหึอสࠨᱸ"),Nlyfx1HnzOWCovke5(u"ࠩ็฻๊๐วหࠩᱹ"),WXuJd8nz2spo146t(u"ࠪำ฾อมࠨᱺ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫ็ืว็ࠩᱻ"),wYTDlJC5vpOKynUEX3ge6W(u"่ࠬีศศาࠫᱼ"),cpHxZyU7vTtqmIw(u"࠭ัฬษฤࠫᱽ"),YzowicIDTRusXZSU61(u"ࠧๆำฯ฽๏ํࠧ᱾"),eAMGzHRQVs2KyCwPXljYhB(u"ࠨษำห๋࠭᱿"),SSBkx0WbN1asnDCQV6tIj(u"ࠩสื้อๅࠨᲀ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪฮํอิ๋ฯࠪᲁ"),ynxXU3gaiQ9GPCftr1q(u"ࠫำ฽ศࠨᲂ"),WsklGNp2CYzVQUag(u"ࠬำ่ำ๊ํࠫᲃ"),FGLEMi21Bfn(u"ู࠭หสสฮࠬᲄ"),QYSAUI5r46yil8cfaO(u"ࠧๆ๊ส่๏ีࠧᲅ"),ynxXU3gaiQ9GPCftr1q(u"ࠨ่๋ห฾๐ࠧᲆ"),WCPwmyVsb62KRlo(u"ࠩ฼ๆฬฬฯࠨᲇ"),YzowicIDTRusXZSU61(u"ࠪห๋อิ๋ัࠪᲈ")]
		nlzNXCePYph02SOJAfRHsV1i8Brx = [cpHxZyU7vTtqmIw(u"ࠫ࠷࠶࠱࠱ࠩᲉ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࠸࠰࠲࠳ࠪᲊ"),pnkrd2S84FJfN73KuiCYv(u"࠭࠲࠱࠳࠵ࠫ᲋"),pnkrd2S84FJfN73KuiCYv(u"ࠧ࠳࠲࠴࠷ࠬ᲌"),pnkrd2S84FJfN73KuiCYv(u"ࠨ࠴࠳࠵࠹࠭᲍"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩ࠵࠴࠶࠻ࠧ᲎"),MzgKWUQ4V5H(u"ࠪ࠶࠵࠷࠶ࠨ᲏"),YzowicIDTRusXZSU61(u"ࠫ࠷࠶࠱࠸ࠩᲐ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠬ࠸࠰࠲࠺ࠪᲑ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠲࠱࠳࠼ࠫᲒ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧ࠳࠲࠵࠴ࠬᲓ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࠴࠳࠶࠶࠭Ე"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࠵࠴࠷࠸ࠧᲕ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࠶࠵࠸࠳ࠨᲖ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࠷࠶࠲࠵ࠩᲗ"),jXWzIZcDva4ikEUfN(u"ࠬ࠸࠰࠳࠷ࠪᲘ"),WsklGNp2CYzVQUag(u"࠭࠲࠱࠴࠹ࠫᲙ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࠳࠲࠵࠻ࠬᲚ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ࠴࠳࠶࠽࠭Მ")]
		for EDy0Rs9liwjZvJY in sorted(list(WHl0X13zIVuGyP4eK.keys())):
			KK4WEqy9u1mj = EDy0Rs9liwjZvJY.lower()
			MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = []
			if any(value in KK4WEqy9u1mj for value in x0xd8Q9K4AHojsS567gIfWbOwv): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(pwxH3oREFm5v98BCZ1QVtzMJOc)
			if any(value in KK4WEqy9u1mj for value in avVhkSxXDBifGPcCWzYJsnm5Q): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(RXnhpCUk4M1TvgJE)
			if any(value in KK4WEqy9u1mj for value in QR49GIikjgTSayBmPWv5uE): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A)
			if any(value in KK4WEqy9u1mj for value in q4oO9jKFzHfVIxkRWYn): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(BZm7TqLPJfAVblDKsya85zFWXNMY)
			if any(value in KK4WEqy9u1mj for value in idgQ8u5HFlCz2DnJjMpUsrG90): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(m5DECdgjU4KqpVhyJ9A2b)
			if any(value in KK4WEqy9u1mj for value in nPtvlBeUcTW4ZaIC0s7bmVLj): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(wAU9jKvmTM0(u"࠼ᶜ"))
			if any(value in KK4WEqy9u1mj for value in DZjbwYA1GS7tsv) and KK4WEqy9u1mj not in [cpHxZyU7vTtqmIw(u"ࠩสาึ๏ࠧᲜ")]: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠷ᶝ"))
			if any(value in KK4WEqy9u1mj for value in aTMQO2Lf1PRkBGYErlqVJ9HSxc): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(QYSAUI5r46yil8cfaO(u"࠹ᶞ"))
			if any(value in KK4WEqy9u1mj for value in qop9tzhdMIaR2iE1G): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(WCPwmyVsb62KRlo(u"࠻ᶟ"))
			if any(value in KK4WEqy9u1mj for value in TFy7CmcgxDhtPJZB5H23KborYUnk): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(wYTDlJC5vpOKynUEX3ge6W(u"࠴࠴ᶠ"))
			if any(value in KK4WEqy9u1mj for value in NO6t5oQ4V0): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(NNjUsZzEcFOAoKry2CDMgb1(u"࠵࠶ᶡ"))
			if any(value in KK4WEqy9u1mj for value in Xg8LYfpSW34jdubs1R): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(jXWzIZcDva4ikEUfN(u"࠶࠸ᶢ"))
			if any(value in KK4WEqy9u1mj for value in KKsb5cA9uoCLW): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠷࠳ᶣ"))
			if any(value in KK4WEqy9u1mj for value in YIuVOnJm7USbpoQyiFGW04DB5Nw): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(V2RQwM8XjlrK(u"࠱࠵ᶤ"))
			if any(value in KK4WEqy9u1mj for value in FhUTLMZkj7ueyvVmKrAac): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠲࠷ᶥ"))
			if any(value in KK4WEqy9u1mj for value in xU0lJEy5CG3O1YRbic): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠳࠹ᶦ"))
			if any(value in KK4WEqy9u1mj for value in mahPZB9SnqGO3): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(HOxJyt7l8osNeCjZFMQGi4Sr(u"࠴࠻ᶧ"))
			if any(value in KK4WEqy9u1mj for value in nlzNXCePYph02SOJAfRHsV1i8Brx): MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb.append(wAU9jKvmTM0(u"࠵࠽ᶨ"))
			if not MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = [V2RQwM8XjlrK(u"࠶࠿ᶩ")]
			for zfO7acv9exNPl5SgnJLk63HoqA in MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb:
				if str(zfO7acv9exNPl5SgnJLk63HoqA)==OOcWBhI6azRmLQnrE:
					v0TjHlLZqkRxUCpmNwSy8AndO(pnkrd2S84FJfN73KuiCYv(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲝ"),xzA9sM3rG6IHd7jl8T+EDy0Rs9liwjZvJY,EDy0Rs9liwjZvJY,WXuJd8nz2spo146t(u"࠷࠶࠷ᶪ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wbnzQ7FrZ3H+WsklGNp2CYzVQUag(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲞ"))
	igFtOzLBeQu(XVgJmyC4wSjDON,XVgJmyC4wSjDON,I3IivNQUYMoVL5zbmnZWgaAudfB)
	return
def h48cGBzjfnrVvoZ5MElmx(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
	if oX6deUmzM4yS0WfJg5pvxra:
		v0TjHlLZqkRxUCpmNwSy8AndO(WXuJd8nz2spo146t(u"ࠬࡲࡩ࡯࡭ࠪᲟ"),V2RQwM8XjlrK(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡍࡕ࡚ࡖࠨᲠ"),Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠷࠷࠶ᶫ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᲡ"),Vk54F7GcROfCy6HunEI,{kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲢ"):vEznYtihqcojIFrOkUTXdLR})
		v0TjHlLZqkRxUCpmNwSy8AndO(g7yJo2LVuqx1trPe(u"ࠩ࡯࡭ࡳࡱࠧᲣ"),nMt0iueCy6K+EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᲤ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠺࠻࠼࠽ᶬ"))
	F29ms0aOy3NkqxRP14wo = h9zFQKnsNL.menuItemsLIST[:]
	import WWria3lCPQ
	if vEznYtihqcojIFrOkUTXdLR:
		if not WWria3lCPQ.LBGi7uYZ6XTo5ct3f2FH8j(vEznYtihqcojIFrOkUTXdLR,YOHXqtbQTBfKerIZ): return
		Q5Ta8skiClFL41xwdb = zQZPhw6F3eXtqYEIdMVGvHpnamfNr(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		yU4x75f6iS2TgJzcFnev = sorted(Q5Ta8skiClFL41xwdb,reverse=eu1NswY9zkKC60I,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc].lower())
	else:
		if not WWria3lCPQ.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
		if oX6deUmzM4yS0WfJg5pvxra and ESXZrtnCfcDJGo01vFg(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᲥ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			yU4x75f6iS2TgJzcFnev = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡲࡩࡴࡶࠪᲦ"),g7yJo2LVuqx1trPe(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭Ყ"),WXuJd8nz2spo146t(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫᲨ"))
		else:
			UsAWC1hoaknSe5KEuR2T,yU4x75f6iS2TgJzcFnev,Q5Ta8skiClFL41xwdb = [],[],[]
			for MPZoLHXScG in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
				yU4x75f6iS2TgJzcFnev += zQZPhw6F3eXtqYEIdMVGvHpnamfNr(str(MPZoLHXScG),tFleBaQ2fUrNiPdu3k8cpjWCxS7)
			for type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in yU4x75f6iS2TgJzcFnev:
				if YWCso5NMKO not in UsAWC1hoaknSe5KEuR2T:
					UsAWC1hoaknSe5KEuR2T.append(YWCso5NMKO)
					xg7yHGIqnUe = type,EDy0Rs9liwjZvJY,YWCso5NMKO,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠳࠹࠹ᶭ"),ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,tFleBaQ2fUrNiPdu3k8cpjWCxS7,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH
					Q5Ta8skiClFL41xwdb.append(xg7yHGIqnUe)
			yU4x75f6iS2TgJzcFnev = sorted(Q5Ta8skiClFL41xwdb,reverse=eu1NswY9zkKC60I,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc].lower())
			if oX6deUmzM4yS0WfJg5pvxra: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,jXWzIZcDva4ikEUfN(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᲩ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭Ც"),yU4x75f6iS2TgJzcFnev,piwNWcJEe9m)
	h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def giaB9sEXhAJIzWd(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
	if oX6deUmzM4yS0WfJg5pvxra:
		v0TjHlLZqkRxUCpmNwSy8AndO(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡰ࡮ࡴ࡫ࠨᲫ"),Nlyfx1HnzOWCovke5(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢฦๆุอๅࠡࡏ࠶࡙ࠬᲬ"),Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠺࠺࠺ᶮ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᲭ"),Vk54F7GcROfCy6HunEI,{NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ხ"):vEznYtihqcojIFrOkUTXdLR})
		v0TjHlLZqkRxUCpmNwSy8AndO(QYSAUI5r46yil8cfaO(u"ࠧ࡭࡫ࡱ࡯ࠬᲯ"),nMt0iueCy6K+jXWzIZcDva4ikEUfN(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ჰ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠽࠾࠿࠹ᶯ"))
	F29ms0aOy3NkqxRP14wo = h9zFQKnsNL.menuItemsLIST[:]
	import n4KTbzCNIs
	if vEznYtihqcojIFrOkUTXdLR:
		if not n4KTbzCNIs.LBGi7uYZ6XTo5ct3f2FH8j(vEznYtihqcojIFrOkUTXdLR,YOHXqtbQTBfKerIZ): return
		Q5Ta8skiClFL41xwdb = tt0PHpN1xwrL(vEznYtihqcojIFrOkUTXdLR,tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		yU4x75f6iS2TgJzcFnev = sorted(Q5Ta8skiClFL41xwdb,reverse=eu1NswY9zkKC60I,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc].lower())
	else:
		if not n4KTbzCNIs.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
		if oX6deUmzM4yS0WfJg5pvxra and NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᲱ") not in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
			yU4x75f6iS2TgJzcFnev = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡰ࡮ࡹࡴࠨᲲ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᲳ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨᲴ"))
		else:
			UsAWC1hoaknSe5KEuR2T,yU4x75f6iS2TgJzcFnev,Q5Ta8skiClFL41xwdb = [],[],[]
			for MPZoLHXScG in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
				yU4x75f6iS2TgJzcFnev += tt0PHpN1xwrL(str(MPZoLHXScG),tFleBaQ2fUrNiPdu3k8cpjWCxS7)
			for type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in yU4x75f6iS2TgJzcFnev:
				if YWCso5NMKO not in UsAWC1hoaknSe5KEuR2T:
					UsAWC1hoaknSe5KEuR2T.append(YWCso5NMKO)
					xg7yHGIqnUe = type,EDy0Rs9liwjZvJY,YWCso5NMKO,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠶࠼࠵ᶰ"),ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,tFleBaQ2fUrNiPdu3k8cpjWCxS7,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH
					Q5Ta8skiClFL41xwdb.append(xg7yHGIqnUe)
			yU4x75f6iS2TgJzcFnev = sorted(Q5Ta8skiClFL41xwdb,reverse=eu1NswY9zkKC60I,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc].lower())
			if oX6deUmzM4yS0WfJg5pvxra: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,FGLEMi21Bfn(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᲵ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᲶ"),yU4x75f6iS2TgJzcFnev,piwNWcJEe9m)
	h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def JqAjU4Ms16nw0f3FCr(group,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
	w8YsNWfQ5gFluRvOmSd4Cb96H = []
	llfQdFkUNJMRz = MpJ8GOKoic(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨᲷ") if cpHxZyU7vTtqmIw(u"ࠩࡌࡔ࡙࡜ࠧᲸ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 else Nlyfx1HnzOWCovke5(u"ࠪࡣࡒ࠹ࡕࡠࠩᲹ")
	if oX6deUmzM4yS0WfJg5pvxra: w8YsNWfQ5gFluRvOmSd4Cb96H = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡱ࡯ࡳࡵࠩᲺ"),WXuJd8nz2spo146t(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ᲻")+llfQdFkUNJMRz[:-pwxH3oREFm5v98BCZ1QVtzMJOc],group)
	if not w8YsNWfQ5gFluRvOmSd4Cb96H:
		for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
			if oX6deUmzM4yS0WfJg5pvxra: w8YsNWfQ5gFluRvOmSd4Cb96H += w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,ynxXU3gaiQ9GPCftr1q(u"࠭࡬ࡪࡵࡷࠫ᲼"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᲽ")+llfQdFkUNJMRz[:-pwxH3oREFm5v98BCZ1QVtzMJOc],XCYALgFs2O3hZdpHrlMmB(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪᲾ")+llfQdFkUNJMRz+str(vEznYtihqcojIFrOkUTXdLR))
			elif llfQdFkUNJMRz==FGLEMi21Bfn(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩᲿ"): w8YsNWfQ5gFluRvOmSd4Cb96H += zQZPhw6F3eXtqYEIdMVGvHpnamfNr(str(vEznYtihqcojIFrOkUTXdLR),MpJ8GOKoic(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ᳀"))
			elif llfQdFkUNJMRz==ESXZrtnCfcDJGo01vFg(u"ࠫࡤࡓ࠳ࡖࡡࠪ᳁"): w8YsNWfQ5gFluRvOmSd4Cb96H += tt0PHpN1xwrL(str(vEznYtihqcojIFrOkUTXdLR),WCPwmyVsb62KRlo(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᳂"))
		for type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in w8YsNWfQ5gFluRvOmSd4Cb96H:
			if YWCso5NMKO==group: BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
		items,C7SvpZQLjOwh9m0goVbzXadR5 = [],[]
		for type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in h9zFQKnsNL.menuItemsLIST:
			L5L1P3p8BnK0vkTRi2of = type,EDy0Rs9liwjZvJY[BZm7TqLPJfAVblDKsya85zFWXNMY:],url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Vk54F7GcROfCy6HunEI
			if L5L1P3p8BnK0vkTRi2of not in C7SvpZQLjOwh9m0goVbzXadR5:
				C7SvpZQLjOwh9m0goVbzXadR5.append(L5L1P3p8BnK0vkTRi2of)
				anbjzfuiDdgYP6vSXqwRex = type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH
				items.append(anbjzfuiDdgYP6vSXqwRex)
		w8YsNWfQ5gFluRvOmSd4Cb96H = sorted(items,reverse=eu1NswY9zkKC60I,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc].lower()[wAU9jKvmTM0(u"࠻ᶱ"):])
		if oX6deUmzM4yS0WfJg5pvxra: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ᳃")+llfQdFkUNJMRz[:-pwxH3oREFm5v98BCZ1QVtzMJOc],group,w8YsNWfQ5gFluRvOmSd4Cb96H,piwNWcJEe9m)
	if Nlyfx1HnzOWCovke5(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ᳄") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 and len(w8YsNWfQ5gFluRvOmSd4Cb96H)>sshCBgJv0b2EDfKrjcUW:
		h9zFQKnsNL.menuItemsLIST[:] = []
		v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳅"),XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡞ࠫ᳆")+nMt0iueCy6K+group+ZZoLlKyInXc08j2pTGJ+QYSAUI5r46yil8cfaO(u"ࠪࠤ࠿อไใี่ࡡࠬ᳇"),group,WXuJd8nz2spo146t(u"࠱࠷࠷ᶲ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,llfQdFkUNJMRz+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳈"))
		v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᳉"),YzowicIDTRusXZSU61(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ᳊"),group,SSBkx0WbN1asnDCQV6tIj(u"࠲࠸࠸ᶳ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,llfQdFkUNJMRz+g7yJo2LVuqx1trPe(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳋"))
		v0TjHlLZqkRxUCpmNwSy8AndO(V2RQwM8XjlrK(u"ࠨ࡮࡬ࡲࡰ࠭᳌"),nMt0iueCy6K+ESXZrtnCfcDJGo01vFg(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ᳍")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,jXWzIZcDva4ikEUfN(u"࠻࠼࠽࠾ᶴ"))
		w8YsNWfQ5gFluRvOmSd4Cb96H = h9zFQKnsNL.menuItemsLIST+budUNB9jgpI8Pm5.sample(w8YsNWfQ5gFluRvOmSd4Cb96H,sshCBgJv0b2EDfKrjcUW)
	h9zFQKnsNL.menuItemsLIST[:] = w8YsNWfQ5gFluRvOmSd4Cb96H
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def FCAzPVk0TRdufxtKHh(tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳎"),FGLEMi21Bfn(u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ᳏"),Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"࠴࠺࠶ᶵ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ᳐"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡬ࡪࡰ࡮ࠫ᳑"),nMt0iueCy6K+pnkrd2S84FJfN73KuiCYv(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᳒")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"࠽࠾࠿࠹ᶶ"))
	vXPTn6pqd81FDOW3hSJe = h9zFQKnsNL.menuItemsLIST[:]
	h9zFQKnsNL.menuItemsLIST[:] = []
	import Lu2jhfESHF
	Lu2jhfESHF.XZA9vYcOi4(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨ࠲ࠪ᳓"),eu1NswY9zkKC60I)
	Lu2jhfESHF.XZA9vYcOi4(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࠴᳔ࠫ"),eu1NswY9zkKC60I)
	Lu2jhfESHF.XZA9vYcOi4(V2RQwM8XjlrK(u"ࠪ࠶᳕ࠬ"),eu1NswY9zkKC60I)
	if cpHxZyU7vTtqmIw(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ᳖࠭") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		h9zFQKnsNL.menuItemsLIST[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
		if len(h9zFQKnsNL.menuItemsLIST)>sshCBgJv0b2EDfKrjcUW: h9zFQKnsNL.menuItemsLIST[:] = budUNB9jgpI8Pm5.sample(h9zFQKnsNL.menuItemsLIST,sshCBgJv0b2EDfKrjcUW)
	h9zFQKnsNL.menuItemsLIST[:] = vXPTn6pqd81FDOW3hSJe+h9zFQKnsNL.menuItemsLIST
	return
def H8isMcP3LoxCqXF0eOGSh(tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	tFleBaQ2fUrNiPdu3k8cpjWCxS7 = tFleBaQ2fUrNiPdu3k8cpjWCxS7.replace(MzgKWUQ4V5H(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ᳗ࠧ"),Vk54F7GcROfCy6HunEI).replace(QYSAUI5r46yil8cfaO(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳘ࠪ"),Vk54F7GcROfCy6HunEI)
	headers = { ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ᳙ࠫ") : Vk54F7GcROfCy6HunEI }
	url = WXuJd8nz2spo146t(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ᳚")
	data = {EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ᳛"):wAU9jKvmTM0(u"ࠪ࠹࠵᳜࠭")}
	data = weWxHqLyORY4NfBbGQmgc53F1E8UVz(data)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,QYSAUI5r46yil8cfaO(u"ࠫࡌࡋࡔࠨ᳝"),url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺ᳞ࠧ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨ᳟"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
	items = RSuYINdeamsK0t.findall(g7yJo2LVuqx1trPe(u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ᳠"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	OtP7dLNZYm8394nDgQA,OaEebH3QYhyS1CMP7slUjF = list(zip(*items))
	UKRbQComrBLiEWc90S3Ie4hHaFpf = []
	OrfXSsBxbAeT1CkvV9i7togNPKmZ = [otBWsSAfu7dihVkP9e1JFKrvmYy2Q,XCYALgFs2O3hZdpHrlMmB(u"ࠨࠤࠪ᳡"),ynxXU3gaiQ9GPCftr1q(u"ࠩࡣ᳢ࠫ"),QYSAUI5r46yil8cfaO(u"ࠪ࠰᳣ࠬ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠫ࠳᳤࠭"),FGLEMi21Bfn(u"ࠬࡀ᳥ࠧ"),Nlyfx1HnzOWCovke5(u"࠭࠻ࠨ᳦"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠢࠨࠤ᳧"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࠯᳨ࠪ")]
	D931vKtUhE5apLCA8lVgwcqjZOiY = OaEebH3QYhyS1CMP7slUjF+OtP7dLNZYm8394nDgQA
	for OgD6TeFCXv7bf in D931vKtUhE5apLCA8lVgwcqjZOiY:
		if OgD6TeFCXv7bf in OaEebH3QYhyS1CMP7slUjF: QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I = RXnhpCUk4M1TvgJE
		if OgD6TeFCXv7bf in OtP7dLNZYm8394nDgQA: QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I = BZm7TqLPJfAVblDKsya85zFWXNMY
		x3O6Poq24ilkv0dQ8 = [zHq7nBWJTNyY1I3aLco4AR in OgD6TeFCXv7bf for zHq7nBWJTNyY1I3aLco4AR in OrfXSsBxbAeT1CkvV9i7togNPKmZ]
		if any(x3O6Poq24ilkv0dQ8):
			p1pTyjFEIDr3lgUHhdJsm5t9MBwS = x3O6Poq24ilkv0dQ8.index(YOHXqtbQTBfKerIZ)
			dOns95Nj16Sviqc7uUCotz = OrfXSsBxbAeT1CkvV9i7togNPKmZ[p1pTyjFEIDr3lgUHhdJsm5t9MBwS]
			isjUvN4yWQxb0L6MoZ3O = Vk54F7GcROfCy6HunEI
			if OgD6TeFCXv7bf.count(dOns95Nj16Sviqc7uUCotz)>pwxH3oREFm5v98BCZ1QVtzMJOc: uutTaYOczxZqFySXhl7BPr4oHm2QL,Sy5EHX462NIDoCkgmudnaK,isjUvN4yWQxb0L6MoZ3O = OgD6TeFCXv7bf.split(dOns95Nj16Sviqc7uUCotz,RXnhpCUk4M1TvgJE)
			else: uutTaYOczxZqFySXhl7BPr4oHm2QL,Sy5EHX462NIDoCkgmudnaK = OgD6TeFCXv7bf.split(dOns95Nj16Sviqc7uUCotz,pwxH3oREFm5v98BCZ1QVtzMJOc)
			if len(uutTaYOczxZqFySXhl7BPr4oHm2QL)>QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I: UKRbQComrBLiEWc90S3Ie4hHaFpf.append(uutTaYOczxZqFySXhl7BPr4oHm2QL.lower())
			if len(Sy5EHX462NIDoCkgmudnaK)>QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I: UKRbQComrBLiEWc90S3Ie4hHaFpf.append(Sy5EHX462NIDoCkgmudnaK.lower())
			if len(isjUvN4yWQxb0L6MoZ3O)>QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I: UKRbQComrBLiEWc90S3Ie4hHaFpf.append(isjUvN4yWQxb0L6MoZ3O.lower())
		elif len(OgD6TeFCXv7bf)>QQ9r8GgSWbTE2UPvx3BsLNpK4Auk7I: UKRbQComrBLiEWc90S3Ie4hHaFpf.append(OgD6TeFCXv7bf.lower())
	for zHq7nBWJTNyY1I3aLco4AR in range(wYTDlJC5vpOKynUEX3ge6W(u"࠾ᶷ")): budUNB9jgpI8Pm5.shuffle(UKRbQComrBLiEWc90S3Ie4hHaFpf)
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪᳩ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		FcRIYtbVHT1BXuqS7Gz4Qfds = WjMzbLpa1rUo5Pq
	elif BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡣࡎࡖࡔࡗࡡࠪᳪ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		FcRIYtbVHT1BXuqS7Gz4Qfds = [eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡎࡖࡔࡗࠩᳫ")]
		import WWria3lCPQ
		if not WWria3lCPQ.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
	elif pnkrd2S84FJfN73KuiCYv(u"ࠬࡥࡍ࠴ࡗࡢࠫᳬ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		FcRIYtbVHT1BXuqS7Gz4Qfds = [NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡍ࠴ࡗ᳭ࠪ")]
		import n4KTbzCNIs
		if not n4KTbzCNIs.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
	count,ZZ2IReKi48G3ksqjOXSrEbdDPa651p = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
	v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),SSBkx0WbN1asnDCQV6tIj(u"ࠨ࡝ࠣࠤࡢࠦ࠺ศๆหัะูࠦ็ࠩᳯ"),Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠷࠶࠵ᶸ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᳰ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
	v0TjHlLZqkRxUCpmNwSy8AndO(cpHxZyU7vTtqmIw(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),pnkrd2S84FJfN73KuiCYv(u"ࠫส฿วะหࠣห้ฮอฬࠢส่฾ฺ่ศศํࠫᳲ"),Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"࠱࠷࠶ᶹ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᳳ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
	v0TjHlLZqkRxUCpmNwSy8AndO(XCYALgFs2O3hZdpHrlMmB(u"࠭࡬ࡪࡰ࡮ࠫ᳴"),nMt0iueCy6K+eAMGzHRQVs2KyCwPXljYhB(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᳵ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"࠺࠻࠼࠽ᶺ"))
	xxSqfWVp1Uw = h9zFQKnsNL.menuItemsLIST[:]
	h9zFQKnsNL.menuItemsLIST[:] = []
	o41M3aLDmg = []
	for OgD6TeFCXv7bf in UKRbQComrBLiEWc90S3Ie4hHaFpf:
		Sy5EHX462NIDoCkgmudnaK = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀࠨᳶ")+cpHxZyU7vTtqmIw(u"ࠩࠦࠫ᳷")+eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧ᳸"),OgD6TeFCXv7bf,RSuYINdeamsK0t.DOTALL)
		if Sy5EHX462NIDoCkgmudnaK: OgD6TeFCXv7bf = OgD6TeFCXv7bf.split(Sy5EHX462NIDoCkgmudnaK[ufmXvxgoHGDwZtjsLkR05i],pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		hlYvjqG1iomk8ACMwX = OgD6TeFCXv7bf.replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ๖࠭᳹"),Vk54F7GcROfCy6HunEI).replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ๔ࠧᳺ"),Vk54F7GcROfCy6HunEI).replace(jXWzIZcDva4ikEUfN(u"๋࠭ࠨ᳻"),Vk54F7GcROfCy6HunEI).replace(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧ๐ࠩ᳼"),Vk54F7GcROfCy6HunEI).replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ๎ࠪ᳽"),Vk54F7GcROfCy6HunEI)
		hlYvjqG1iomk8ACMwX = hlYvjqG1iomk8ACMwX.replace(YzowicIDTRusXZSU61(u"ࠩ๓ࠫ᳾"),Vk54F7GcROfCy6HunEI).replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ๑ࠬ᳿"),Vk54F7GcROfCy6HunEI).replace(jXWzIZcDva4ikEUfN(u"ࠫ๗࠭ᴀ"),Vk54F7GcROfCy6HunEI).replace(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬฒࠧᴁ"),Vk54F7GcROfCy6HunEI).replace(ynxXU3gaiQ9GPCftr1q(u"࠭เࠨᴂ"),Vk54F7GcROfCy6HunEI)
		if hlYvjqG1iomk8ACMwX: o41M3aLDmg.append(hlYvjqG1iomk8ACMwX)
	Ao2vieHUjzLCXpbdIGuMl18mS = []
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(ufmXvxgoHGDwZtjsLkR05i,wYTDlJC5vpOKynUEX3ge6W(u"࠴࠳ᶻ")):
		search = budUNB9jgpI8Pm5.sample(o41M3aLDmg,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		if search in Ao2vieHUjzLCXpbdIGuMl18mS: continue
		Ao2vieHUjzLCXpbdIGuMl18mS.append(search)
		PPmYnWkqTCfNH1u4yoRs = budUNB9jgpI8Pm5.sample(FcRIYtbVHT1BXuqS7Gz4Qfds,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+eAMGzHRQVs2KyCwPXljYhB(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪᴃ")+str(PPmYnWkqTCfNH1u4yoRs)+WsklGNp2CYzVQUag(u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫᴄ")+search)
		tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
		hjBWFnCMqr(search+wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧᴅ"))
		if len(h9zFQKnsNL.menuItemsLIST)>ufmXvxgoHGDwZtjsLkR05i: break
	search = search.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡣࡒࡕࡄࡠࠩᴆ"),Vk54F7GcROfCy6HunEI)
	xxSqfWVp1Uw[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc] = g7yJo2LVuqx1trPe(u"ࠫࡠ࠭ᴇ")+nMt0iueCy6K+search+ZZoLlKyInXc08j2pTGJ+YzowicIDTRusXZSU61(u"ࠬࠦ࠺ษฯฮࠤ฾์࡝ࠨᴈ")
	h9zFQKnsNL.menuItemsLIST[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
	if len(h9zFQKnsNL.menuItemsLIST)>sshCBgJv0b2EDfKrjcUW: h9zFQKnsNL.menuItemsLIST[:] = budUNB9jgpI8Pm5.sample(h9zFQKnsNL.menuItemsLIST,sshCBgJv0b2EDfKrjcUW)
	h9zFQKnsNL.menuItemsLIST[:] = xxSqfWVp1Uw+h9zFQKnsNL.menuItemsLIST
	return
def fGMDbE7OnsHviFmK86UR40edLph(SCbrO7yjlGH0W,tFleBaQ2fUrNiPdu3k8cpjWCxS7):
	SCbrO7yjlGH0W = SCbrO7yjlGH0W.replace(QYSAUI5r46yil8cfaO(u"࠭࡟ࡎࡑࡇࡣࠬᴉ"),Vk54F7GcROfCy6HunEI)
	tFleBaQ2fUrNiPdu3k8cpjWCxS7 = tFleBaQ2fUrNiPdu3k8cpjWCxS7.replace(SSBkx0WbN1asnDCQV6tIj(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᴊ"),Vk54F7GcROfCy6HunEI).replace(g7yJo2LVuqx1trPe(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴋ"),Vk54F7GcROfCy6HunEI)
	cL8tpP2Fa0k57XlIRbUQ(eu1NswY9zkKC60I)
	if not WHl0X13zIVuGyP4eK: return
	if MpJ8GOKoic(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᴌ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		v0TjHlLZqkRxUCpmNwSy8AndO(g7yJo2LVuqx1trPe(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴍ"),XCYALgFs2O3hZdpHrlMmB(u"ࠫࡠ࠭ᴎ")+nMt0iueCy6K+SCbrO7yjlGH0W+ZZoLlKyInXc08j2pTGJ+EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᴏ"),SCbrO7yjlGH0W,WXuJd8nz2spo146t(u"࠴࠺࠻ᶼ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴐ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		v0TjHlLZqkRxUCpmNwSy8AndO(YzowicIDTRusXZSU61(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴑ"),MpJ8GOKoic(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧᴒ"),SCbrO7yjlGH0W,cpHxZyU7vTtqmIw(u"࠵࠻࠼ᶽ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴓ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		v0TjHlLZqkRxUCpmNwSy8AndO(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡰ࡮ࡴ࡫ࠨᴔ"),nMt0iueCy6K+NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᴕ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"࠾࠿࠹࠺ᶾ"))
	for website in sorted(list(WHl0X13zIVuGyP4eK[SCbrO7yjlGH0W].keys())):
		type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = WHl0X13zIVuGyP4eK[SCbrO7yjlGH0W][website]
		if WsklGNp2CYzVQUag(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᴖ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 or len(WHl0X13zIVuGyP4eK[SCbrO7yjlGH0W])==pwxH3oREFm5v98BCZ1QVtzMJOc:
			BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(type,Vk54F7GcROfCy6HunEI,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)
			h9zFQKnsNL.menuItemsLIST[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
			F29ms0aOy3NkqxRP14wo,yU4x75f6iS2TgJzcFnev = h9zFQKnsNL.menuItemsLIST[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A],h9zFQKnsNL.menuItemsLIST[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:]
			if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᴗ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
				for zHq7nBWJTNyY1I3aLco4AR in range(ESXZrtnCfcDJGo01vFg(u"࠿ᶿ")): budUNB9jgpI8Pm5.shuffle(yU4x75f6iS2TgJzcFnev)
				h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev[:sshCBgJv0b2EDfKrjcUW]
			else: h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev
		elif wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨᴘ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7: v0TjHlLZqkRxUCpmNwSy8AndO(Nlyfx1HnzOWCovke5(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴙ"),website,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
	return
def Uljxr5Jf87qnYZRNQb9SeX4KgTah(tFleBaQ2fUrNiPdu3k8cpjWCxS7,Yz6schq9wSmiu3IOdke0DXPj5W):
	tFleBaQ2fUrNiPdu3k8cpjWCxS7 = tFleBaQ2fUrNiPdu3k8cpjWCxS7.replace(ynxXU3gaiQ9GPCftr1q(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴚ"),Vk54F7GcROfCy6HunEI).replace(QYSAUI5r46yil8cfaO(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴛ"),Vk54F7GcROfCy6HunEI)
	EDy0Rs9liwjZvJY,yU4x75f6iS2TgJzcFnev = Vk54F7GcROfCy6HunEI,[]
	v0TjHlLZqkRxUCpmNwSy8AndO(SSBkx0WbN1asnDCQV6tIj(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴜ"),ESXZrtnCfcDJGo01vFg(u"ࠬࡡࠧᴝ")+nMt0iueCy6K+EDy0Rs9liwjZvJY+ZZoLlKyInXc08j2pTGJ+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨᴞ"),Vk54F7GcROfCy6HunEI,Yz6schq9wSmiu3IOdke0DXPj5W,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴟ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
	v0TjHlLZqkRxUCpmNwSy8AndO(wAU9jKvmTM0(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴠ"),g7yJo2LVuqx1trPe(u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩᴡ"),Vk54F7GcROfCy6HunEI,Yz6schq9wSmiu3IOdke0DXPj5W,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴢ")+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
	v0TjHlLZqkRxUCpmNwSy8AndO(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡱ࡯࡮࡬ࠩᴣ"),nMt0iueCy6K+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᴤ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠹࠺࠻࠼᷀"))
	F29ms0aOy3NkqxRP14wo = h9zFQKnsNL.menuItemsLIST[:]
	h9zFQKnsNL.menuItemsLIST[:] = []
	w8YsNWfQ5gFluRvOmSd4Cb96H = []
	if ESXZrtnCfcDJGo01vFg(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧᴥ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		cL8tpP2Fa0k57XlIRbUQ(eu1NswY9zkKC60I)
		if not WHl0X13zIVuGyP4eK: return
		BkRNj8yqliWa67tzX1SoTLu3gZw20r = list(WHl0X13zIVuGyP4eK.keys())
		SCbrO7yjlGH0W = budUNB9jgpI8Pm5.sample(BkRNj8yqliWa67tzX1SoTLu3gZw20r,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		UKRbQComrBLiEWc90S3Ie4hHaFpf = list(WHl0X13zIVuGyP4eK[SCbrO7yjlGH0W].keys())
		website = budUNB9jgpI8Pm5.sample(UKRbQComrBLiEWc90S3Ie4hHaFpf,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = WHl0X13zIVuGyP4eK[SCbrO7yjlGH0W][website]
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+SSBkx0WbN1asnDCQV6tIj(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪᴦ")+website+V2RQwM8XjlrK(u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫᴧ")+EDy0Rs9liwjZvJY+eAMGzHRQVs2KyCwPXljYhB(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫᴨ")+url+FGLEMi21Bfn(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ᴩ")+str(jZaSeHp3I8tXwbW6fumGcEV9k0g))
	elif HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡤࡏࡐࡕࡘࡢࠫᴪ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		import WWria3lCPQ
		if not WWria3lCPQ.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
		for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
			w8YsNWfQ5gFluRvOmSd4Cb96H += zQZPhw6F3eXtqYEIdMVGvHpnamfNr(str(vEznYtihqcojIFrOkUTXdLR),tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		if not w8YsNWfQ5gFluRvOmSd4Cb96H: return
		type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = budUNB9jgpI8Pm5.sample(w8YsNWfQ5gFluRvOmSd4Cb96H,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+QYSAUI5r46yil8cfaO(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬᴫ")+EDy0Rs9liwjZvJY+ESXZrtnCfcDJGo01vFg(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨᴬ")+url+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪᴭ")+str(jZaSeHp3I8tXwbW6fumGcEV9k0g))
	elif MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡡࡐ࠷࡚ࡥࠧᴮ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		import n4KTbzCNIs
		if not n4KTbzCNIs.LBGi7uYZ6XTo5ct3f2FH8j(Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ): return
		for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
			w8YsNWfQ5gFluRvOmSd4Cb96H += tt0PHpN1xwrL(str(vEznYtihqcojIFrOkUTXdLR),tFleBaQ2fUrNiPdu3k8cpjWCxS7)
		if not w8YsNWfQ5gFluRvOmSd4Cb96H: return
		type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = budUNB9jgpI8Pm5.sample(w8YsNWfQ5gFluRvOmSd4Cb96H,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+Nlyfx1HnzOWCovke5(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩᴯ")+EDy0Rs9liwjZvJY+EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬᴰ")+url+SSBkx0WbN1asnDCQV6tIj(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧᴱ")+str(jZaSeHp3I8tXwbW6fumGcEV9k0g))
	J9JrFqZM31gRcySvlzN = EDy0Rs9liwjZvJY
	Sues6pBcT0ZQbmPU5vrfVJLWHon4 = []
	for zHq7nBWJTNyY1I3aLco4AR in range(ufmXvxgoHGDwZtjsLkR05i,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠲࠲᷁")):
		if zHq7nBWJTNyY1I3aLco4AR>ufmXvxgoHGDwZtjsLkR05i: iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬᴲ")+EDy0Rs9liwjZvJY+cpHxZyU7vTtqmIw(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨᴳ")+url+wAU9jKvmTM0(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪᴴ")+str(jZaSeHp3I8tXwbW6fumGcEV9k0g))
		h9zFQKnsNL.menuItemsLIST[:] = []
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==g7yJo2LVuqx1trPe(u"࠴࠶࠸᷂") and l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᴵ") in YWCso5NMKO: jZaSeHp3I8tXwbW6fumGcEV9k0g = ogJClMiqPa4A0NUtTxpDVybEWG(u"࠵࠷࠸᷃")
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠻࠶࠺᷄") and wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᴶ") in YWCso5NMKO: jZaSeHp3I8tXwbW6fumGcEV9k0g = MzgKWUQ4V5H(u"࠼࠷࠳᷅")
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==WCPwmyVsb62KRlo(u"࠷࠴࠵᷆"): jZaSeHp3I8tXwbW6fumGcEV9k0g = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲࠺࠳᷇")
		x7ohwWJScUpRi1K50qs = BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
		if Nlyfx1HnzOWCovke5(u"ࠪࡣࡎࡖࡔࡗࡡࠪᴷ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 and jZaSeHp3I8tXwbW6fumGcEV9k0g==ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠲࠸࠺᷈"): del h9zFQKnsNL.menuItemsLIST[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		if QYSAUI5r46yil8cfaO(u"ࠫࡤࡓ࠳ࡖࡡࠪᴸ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 and jZaSeHp3I8tXwbW6fumGcEV9k0g==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠳࠹࠼᷉"): del h9zFQKnsNL.menuItemsLIST[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		yU4x75f6iS2TgJzcFnev[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
		if Sues6pBcT0ZQbmPU5vrfVJLWHon4 and IZHqo3tkufgnFv0sAGTRMQwbjda(cpHxZyU7vTtqmIw(u"ࡺ࠭อๅไฬࠫᴹ")) in str(yU4x75f6iS2TgJzcFnev) or IZHqo3tkufgnFv0sAGTRMQwbjda(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࡻࠧฮๆๅ๋ࠬᴺ")) in str(yU4x75f6iS2TgJzcFnev):
			EDy0Rs9liwjZvJY = J9JrFqZM31gRcySvlzN
			yU4x75f6iS2TgJzcFnev[:] = Sues6pBcT0ZQbmPU5vrfVJLWHon4
			break
		J9JrFqZM31gRcySvlzN = EDy0Rs9liwjZvJY
		Sues6pBcT0ZQbmPU5vrfVJLWHon4 = yU4x75f6iS2TgJzcFnev
		if str(yU4x75f6iS2TgJzcFnev).count(wAU9jKvmTM0(u"ࠧࡷ࡫ࡧࡩࡴ࠭ᴻ"))>ufmXvxgoHGDwZtjsLkR05i: break
		if str(yU4x75f6iS2TgJzcFnev).count(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࡮࡬ࡺࡪ࠭ᴼ"))>ufmXvxgoHGDwZtjsLkR05i: break
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==MpJ8GOKoic(u"࠵࠷࠸᷊"): break
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==pnkrd2S84FJfN73KuiCYv(u"࠻࠶࠹᷋"): break
		if jZaSeHp3I8tXwbW6fumGcEV9k0g==wAU9jKvmTM0(u"࠷࠿࠱᷌"): break
		if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᴽ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7 and yU4x75f6iS2TgJzcFnev: type,EDy0Rs9liwjZvJY,url,jZaSeHp3I8tXwbW6fumGcEV9k0g,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = budUNB9jgpI8Pm5.sample(yU4x75f6iS2TgJzcFnev,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
	if not EDy0Rs9liwjZvJY: EDy0Rs9liwjZvJY = NNjUsZzEcFOAoKry2CDMgb1(u"ࠪ࠲࠳࠴࠮ࠨᴾ")
	elif EDy0Rs9liwjZvJY.count(wAU9jKvmTM0(u"ࠫࡤ࠭ᴿ"))>pwxH3oREFm5v98BCZ1QVtzMJOc: EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.split(QYSAUI5r46yil8cfaO(u"ࠬࡥࠧᵀ"),RXnhpCUk4M1TvgJE)[RXnhpCUk4M1TvgJE]
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡕࡏࡍࡑࡓ࡜ࡔ࠺ࠡࠩᵁ"),Vk54F7GcROfCy6HunEI)
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(Nlyfx1HnzOWCovke5(u"ࠧࡠࡏࡒࡈࡤ࠭ᵂ"),Vk54F7GcROfCy6HunEI)
	F29ms0aOy3NkqxRP14wo[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc] = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡝ࠪᵃ")+nMt0iueCy6K+EDy0Rs9liwjZvJY+ZZoLlKyInXc08j2pTGJ+MpJ8GOKoic(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫᵄ")
	if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬᵅ") in tFleBaQ2fUrNiPdu3k8cpjWCxS7:
		for zHq7nBWJTNyY1I3aLco4AR in range(FGLEMi21Bfn(u"࠿᷍")): budUNB9jgpI8Pm5.shuffle(yU4x75f6iS2TgJzcFnev)
		h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev[:sshCBgJv0b2EDfKrjcUW]
	else: h9zFQKnsNL.menuItemsLIST[:] = F29ms0aOy3NkqxRP14wo+yU4x75f6iS2TgJzcFnev
	return
def oobFP4REhZiy5gtCWNDq(EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP):
	ByGIgtCR8QE9DNux0q6zXWreJSYKP = ByGIgtCR8QE9DNux0q6zXWreJSYKP.replace(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵆ"),Vk54F7GcROfCy6HunEI).replace(jXWzIZcDva4ikEUfN(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵇ"),Vk54F7GcROfCy6HunEI)
	MI7WlE5PNfm0cHqZiyu9 = ByGIgtCR8QE9DNux0q6zXWreJSYKP
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧᵈ") in ByGIgtCR8QE9DNux0q6zXWreJSYKP:
		MI7WlE5PNfm0cHqZiyu9 = ByGIgtCR8QE9DNux0q6zXWreJSYKP.split(Nlyfx1HnzOWCovke5(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨᵉ"))[ufmXvxgoHGDwZtjsLkR05i]
		type = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫᵊ")
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡙ࠩࡓࡉ࠭ᵋ") in EZWiXSOQg0: type = NNjUsZzEcFOAoKry2CDMgb1(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭ᵌ")
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡑࡏࡖࡆࠩᵍ") in EZWiXSOQg0: type = Nlyfx1HnzOWCovke5(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭ᵎ")
	v0TjHlLZqkRxUCpmNwSy8AndO(QYSAUI5r46yil8cfaO(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵏ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࡜ࠩᵐ")+nMt0iueCy6K+type+MI7WlE5PNfm0cHqZiyu9+ZZoLlKyInXc08j2pTGJ+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪᵑ"),EZWiXSOQg0,wAU9jKvmTM0(u"࠱࠷࠹᷎"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵒ")+ByGIgtCR8QE9DNux0q6zXWreJSYKP)
	v0TjHlLZqkRxUCpmNwSy8AndO(MpJ8GOKoic(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵓ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪᵔ"),EZWiXSOQg0,wYTDlJC5vpOKynUEX3ge6W(u"࠲࠸࠺᷏"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵕ")+ByGIgtCR8QE9DNux0q6zXWreJSYKP)
	v0TjHlLZqkRxUCpmNwSy8AndO(cpHxZyU7vTtqmIw(u"࠭࡬ࡪࡰ࡮ࠫᵖ"),nMt0iueCy6K+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᵗ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"࠻࠼࠽࠾᷐"))
	import WWria3lCPQ
	for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
		if cpHxZyU7vTtqmIw(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᵘ") in ByGIgtCR8QE9DNux0q6zXWreJSYKP: WWria3lCPQ.dh1OAs2VijQreD8kJXFupZ(str(vEznYtihqcojIFrOkUTXdLR),EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I)
		else: WWria3lCPQ.XZA9vYcOi4(str(vEznYtihqcojIFrOkUTXdLR),EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I)
	h9zFQKnsNL.menuItemsLIST[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
	if len(h9zFQKnsNL.menuItemsLIST)>(sshCBgJv0b2EDfKrjcUW+wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A): h9zFQKnsNL.menuItemsLIST[:] = h9zFQKnsNL.menuItemsLIST[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]+budUNB9jgpI8Pm5.sample(h9zFQKnsNL.menuItemsLIST[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:],sshCBgJv0b2EDfKrjcUW)
	return
def NfiVubJmFW4zPRgkUt59(EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP):
	ByGIgtCR8QE9DNux0q6zXWreJSYKP = ByGIgtCR8QE9DNux0q6zXWreJSYKP.replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵙ"),Vk54F7GcROfCy6HunEI).replace(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵚ"),Vk54F7GcROfCy6HunEI)
	MI7WlE5PNfm0cHqZiyu9 = ByGIgtCR8QE9DNux0q6zXWreJSYKP
	if YzowicIDTRusXZSU61(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᵛ") in ByGIgtCR8QE9DNux0q6zXWreJSYKP:
		MI7WlE5PNfm0cHqZiyu9 = ByGIgtCR8QE9DNux0q6zXWreJSYKP.split(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬᵜ"))[ufmXvxgoHGDwZtjsLkR05i]
		type = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩᵝ")
	elif Nlyfx1HnzOWCovke5(u"ࠧࡗࡑࡇࠫᵞ") in EZWiXSOQg0: type = MpJ8GOKoic(u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫᵟ")
	elif WXuJd8nz2spo146t(u"ࠩࡏࡍ࡛ࡋࠧᵠ") in EZWiXSOQg0: type = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫᵡ")
	v0TjHlLZqkRxUCpmNwSy8AndO(WCPwmyVsb62KRlo(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵢ"),WsklGNp2CYzVQUag(u"ࠬࡡࠧᵣ")+nMt0iueCy6K+type+MI7WlE5PNfm0cHqZiyu9+ZZoLlKyInXc08j2pTGJ+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨᵤ"),EZWiXSOQg0,NNjUsZzEcFOAoKry2CDMgb1(u"࠴࠺࠽᷑"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵥ")+ByGIgtCR8QE9DNux0q6zXWreJSYKP)
	v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵦ"),MpJ8GOKoic(u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨᵧ"),EZWiXSOQg0,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠵࠻࠾᷒"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵨ")+ByGIgtCR8QE9DNux0q6zXWreJSYKP)
	v0TjHlLZqkRxUCpmNwSy8AndO(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡱ࡯࡮࡬ࠩᵩ"),nMt0iueCy6K+ESXZrtnCfcDJGo01vFg(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᵪ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠾࠿࠹࠺ᷓ"))
	import n4KTbzCNIs
	for vEznYtihqcojIFrOkUTXdLR in range(pwxH3oREFm5v98BCZ1QVtzMJOc,YWQb3r2CoU+pwxH3oREFm5v98BCZ1QVtzMJOc):
		if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᵫ") in ByGIgtCR8QE9DNux0q6zXWreJSYKP: n4KTbzCNIs.dh1OAs2VijQreD8kJXFupZ(str(vEznYtihqcojIFrOkUTXdLR),EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I)
		else: n4KTbzCNIs.XZA9vYcOi4(str(vEznYtihqcojIFrOkUTXdLR),EZWiXSOQg0,ByGIgtCR8QE9DNux0q6zXWreJSYKP,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I)
	h9zFQKnsNL.menuItemsLIST[:] = LEfICJTtqkKr5v(h9zFQKnsNL.menuItemsLIST)
	if len(h9zFQKnsNL.menuItemsLIST)>(sshCBgJv0b2EDfKrjcUW+wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A): h9zFQKnsNL.menuItemsLIST[:] = h9zFQKnsNL.menuItemsLIST[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]+budUNB9jgpI8Pm5.sample(h9zFQKnsNL.menuItemsLIST[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:],sshCBgJv0b2EDfKrjcUW)
	return
def LEfICJTtqkKr5v(JJ3xLX6AkIdqMKerzyiOV1R):
	sSHWNVAYcL = []
	for type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in JJ3xLX6AkIdqMKerzyiOV1R:
		if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧึใะอࠬᵬ") in EDy0Rs9liwjZvJY or kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨืไั์࠭ᵭ") in EDy0Rs9liwjZvJY or SSBkx0WbN1asnDCQV6tIj(u"ࠩࡳࡥ࡬࡫ࠧᵮ") in EDy0Rs9liwjZvJY.lower(): continue
		sSHWNVAYcL.append([type,EDy0Rs9liwjZvJY,url,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH])
	return sSHWNVAYcL
# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'VIDEONSAEM'
xzA9sM3rG6IHd7jl8T = '_VNS_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','Show more','قصة عشق','عروض المصارعة الحرة مترجم']
headers = {'Referer':FFLhlYUAsfJBXeQmRpzD7c14ZP6}
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==1030: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==1031: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==1032: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==1033: w8YsNWfQ5gFluRvOmSd4Cb96H = QgxPohjR8trYI(url,text)
	elif mode==1034: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==1039: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,1039,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''["']navslide-wrap["'](.*?)</ul>''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1034)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('/category.php">(.*?)"navslide-divider"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''["']dropdown-menu["'](.*?)</ul>''',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for v8e07ENZbVzIjaMSQPAxLUyuKcWho in Ry3L7fdNGh: UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace(v8e07ENZbVzIjaMSQPAxLUyuKcWho,Vk54F7GcROfCy6HunEI)
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if not title: continue
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1034)
	return
def kAuPp3tC2FhGEb8m6DjMZVi(url):
	G2RujvmTAgMzDpiw,C7SvpZQLjOwh9m0goVbzXadR5 = [],[]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-SUBMENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"caret"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x and '.php' in str(WvDVRHAc37CGulIhPagimorZSy0x):
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		UwcYSVZbdK3rI = UwcYSVZbdK3rI.replace('"presentation"','</ul>')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = [(Vk54F7GcROfCy6HunEI,UwcYSVZbdK3rI)]
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' فرز أو فلتر أو ترتيب '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
		for D3UH5PxKtrs9ichoj2YS6RLGqB,UwcYSVZbdK3rI in Ry3L7fdNGh:
			G2RujvmTAgMzDpiw = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if D3UH5PxKtrs9ichoj2YS6RLGqB: D3UH5PxKtrs9ichoj2YS6RLGqB = D3UH5PxKtrs9ichoj2YS6RLGqB+': '
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in G2RujvmTAgMzDpiw:
				title = D3UH5PxKtrs9ichoj2YS6RLGqB+title
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1031)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"pm-category-subcats"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if QQHXiFSA0jUsklmxbpaMztu:
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if 1 or len(C7SvpZQLjOwh9m0goVbzXadR5)<30:
			if G2RujvmTAgMzDpiw: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in C7SvpZQLjOwh9m0goVbzXadR5:
				if title in wXPtB6I0QKLTyD932sl5d: continue
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1031)
	if not WvDVRHAc37CGulIhPagimorZSy0x and not QQHXiFSA0jUsklmxbpaMztu: txsXO7gSMnrwAh6NmJ9D(url)
	return
def txsXO7gSMnrwAh6NmJ9D(url,MmpRngPUCzrJ0HlGfB=Vk54F7GcROfCy6HunEI):
	if MmpRngPUCzrJ0HlGfB=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		eDbTIrV6KLfz80 = headers.copy()
		eDbTIrV6KLfz80['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',url,data,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-TITLES-1st')
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-TITLES-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	UwcYSVZbdK3rI,items = Vk54F7GcROfCy6HunEI,[]
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	if MmpRngPUCzrJ0HlGfB=='ajax-search':
		UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
		C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in C7SvpZQLjOwh9m0goVbzXadR5: items.append((Vk54F7GcROfCy6HunEI,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title))
	elif MmpRngPUCzrJ0HlGfB=='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pm-carousel_featured"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	elif MmpRngPUCzrJ0HlGfB=='new_episodes':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"row pm-ul-browse-videos(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	elif MmpRngPUCzrJ0HlGfB=='new_movies':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"row pm-ul-browse-videos(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if len(Ry3L7fdNGh)>1: UwcYSVZbdK3rI = Ry3L7fdNGh[1]
	elif MmpRngPUCzrJ0HlGfB=='featured_series':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pm-grid"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if UwcYSVZbdK3rI and not items: items = RSuYINdeamsK0t.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if not items: return
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
		afR4xElWyzgcNAUnKXBempC += '|Referer='+FFLhlYUAsfJBXeQmRpzD7c14ZP6
		if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة).\d+',title,RSuYINdeamsK0t.DOTALL)
		if MmpRngPUCzrJ0HlGfB=='episodes' or any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1032,afR4xElWyzgcNAUnKXBempC)
		elif MmpRngPUCzrJ0HlGfB=='new_episodes':
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1032,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ:
			title = '_MOD_' + AWjJSatwokZ[0][0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1033,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1033,afR4xElWyzgcNAUnKXBempC)
	if 1:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/')
				title = Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,1031,'','',MmpRngPUCzrJ0HlGfB)
	return
def QgxPohjR8trYI(url,KBe7D36amSnG9WZf5dCUPQhOz):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-EPISODES_SEASONS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="eplist"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		NTaCesPm04 = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in NTaCesPm04:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,872)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<dt>(.*?)<dt>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				txsXO7gSMnrwAh6NmJ9D(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[-1],'episodes')
	return
def h5hmzOAeWEPip(url):
	MMJL8QqY6T7dv1onu,FMpUSlAmskvgKEZ = [],[]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'VIDEONSAEM-PLAY-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if 'hash=' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		CZmKqDRcn2tA8SUphFQTs = RSuYINdeamsK0t.findall('hash=(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		CZmKqDRcn2tA8SUphFQTs = list(set(CZmKqDRcn2tA8SUphFQTs))
		for bGnTdg51V6vK in CZmKqDRcn2tA8SUphFQTs:
			zAYwk8ud73tK6nF0HPfDjhe = []
			itb54hH6eAY = bGnTdg51V6vK.split('__')
			for EgUlDW3NpXL0F in itb54hH6eAY:
				try:
					EgUlDW3NpXL0F = PnRA5dpzE18JU.b64decode(EgUlDW3NpXL0F+'=')
					if PvwFsJK23NbU8XWAx: EgUlDW3NpXL0F = EgUlDW3NpXL0F.decode(AoCWwJHgUPKXI7u2lEzym)
					zAYwk8ud73tK6nF0HPfDjhe.append(EgUlDW3NpXL0F)
				except: pass
			HXhRgxEZ4d2Dek = '>'.join(zAYwk8ud73tK6nF0HPfDjhe)
			HXhRgxEZ4d2Dek = HXhRgxEZ4d2Dek.splitlines()
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
				if ' => ' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
					title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(' => ')
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search.php?keywords='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
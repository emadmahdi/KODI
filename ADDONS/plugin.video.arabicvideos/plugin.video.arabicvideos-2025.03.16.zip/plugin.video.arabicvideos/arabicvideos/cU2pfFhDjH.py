# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
TVPm7Bz1XOwJ2 = 'AKOAM'
xzA9sM3rG6IHd7jl8T = '_AKO_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
IuMOSFRLa8VKz12ZwTrfcg95Yl = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==70: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==71: w8YsNWfQ5gFluRvOmSd4Cb96H = GMXZ0AndlPkWcuBiy25ECLDghr(url)
	elif mode==72: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==73: w8YsNWfQ5gFluRvOmSd4Cb96H = bdiAgtcRT1zlVu(url)
	elif mode==74: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==79: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,79,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'سلسلة افلام',Vk54F7GcROfCy6HunEI,79,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'سلسلة افلام')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'سلاسل منوعة',Vk54F7GcROfCy6HunEI,79,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'سلسلة')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	wXPtB6I0QKLTyD932sl5d = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'AKOAM-MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="partions"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title not in wXPtB6I0QKLTyD932sl5d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,71)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def GMXZ0AndlPkWcuBiy25ECLDghr(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'AKOAM-CATEGORIES-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('sect_parts(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,72)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'جميع الفروع',url,72)
	else: txsXO7gSMnrwAh6NmJ9D(url,Vk54F7GcROfCy6HunEI)
	return
def txsXO7gSMnrwAh6NmJ9D(url,type):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('section_title featured_title(.*?)subjects-crousel',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	elif type=='search':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('akoam_result(.*?)<script',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	elif type=='more':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('section_title more_title(.*?)footer_bottom_services',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('navigation(.*?)<script',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not items and Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		title = Uo7Tbc29Eu(title)
		if any(value in title for value in IuMOSFRLa8VKz12ZwTrfcg95Yl): v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,73,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,73,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall("</li><li >.*?href='(.*?)'>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,72,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
	return
def KKaqjM3x0HTL4wzC6oNPv1g(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,True,'AKOAM-SECTIONS-2nd')
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('"href","(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[1]
	return hj50MJnoOp6ZWaS1IQ8Elr
def bdiAgtcRT1zlVu(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,True,'AKOAM-SECTIONS-1st')
	mL0bWdOavgsxM15 = RSuYINdeamsK0t.findall('"(https*://akwam.net/\w+.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	L1cVmorxp589wQRIWvNSis = RSuYINdeamsK0t.findall('"(https*://underurl.com/\w+.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if mL0bWdOavgsxM15 or L1cVmorxp589wQRIWvNSis:
		if mL0bWdOavgsxM15: ynmiDuav5ICTeRsqj6Vb18Q = mL0bWdOavgsxM15[0]
		elif L1cVmorxp589wQRIWvNSis: ynmiDuav5ICTeRsqj6Vb18Q = KKaqjM3x0HTL4wzC6oNPv1g(L1cVmorxp589wQRIWvNSis[0])
		ynmiDuav5ICTeRsqj6Vb18Q = ZlBMJUAWRm9buv(ynmiDuav5ICTeRsqj6Vb18Q)
		import KIO4XePNEd
		if '/series/' in ynmiDuav5ICTeRsqj6Vb18Q or '/shows/' in ynmiDuav5ICTeRsqj6Vb18Q: KIO4XePNEd.SQr4lDstIa0NdFyp7Pf23BG6jnLY(ynmiDuav5ICTeRsqj6Vb18Q)
		else: KIO4XePNEd.h5hmzOAeWEPip(ynmiDuav5ICTeRsqj6Vb18Q)
		return
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	items = RSuYINdeamsK0t.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = Uo7Tbc29Eu(title)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,73)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh:
		qJAOp7HgfKeMQkDau('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,afR4xElWyzgcNAUnKXBempC,UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if 'sub_epsiode_title' in UwcYSVZbdK3rI:
		items = RSuYINdeamsK0t.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else:
		eeJgvPE5c98zd = RSuYINdeamsK0t.findall('sub_file_title\'>(.*?) - <i>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		items = []
		for filename in eeJgvPE5c98zd:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',Vk54F7GcROfCy6HunEI) ]
	count = 0
	nWcb8JC7zEVouFjx9fILGh1vSQ,iSzTVyWEBD1aM3FhACkmjdR8G = [],[]
	size = len(items)
	for title,filename in items:
		k2kRdMUp0qmI9Hrv = Vk54F7GcROfCy6HunEI
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: k2kRdMUp0qmI9Hrv = filename.split('.')[-1]
		title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
		iSzTVyWEBD1aM3FhACkmjdR8G.append(count)
		count += 1
	if size>0:
		if any(value in name for value in IuMOSFRLa8VKz12ZwTrfcg95Yl):
			if size==1:
				qreJEpY8nZguD = 0
			else:
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر الفيديو المناسب:', nWcb8JC7zEVouFjx9fILGh1vSQ)
				if qreJEpY8nZguD == -1: return
			h5hmzOAeWEPip(url+'?section='+str(1+iSzTVyWEBD1aM3FhACkmjdR8G[size-qreJEpY8nZguD-1]))
		else:
			for zHq7nBWJTNyY1I3aLco4AR in reversed(range(size)):
				title = name + ' - ' + nWcb8JC7zEVouFjx9fILGh1vSQ[zHq7nBWJTNyY1I3aLco4AR]
				title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url + '?section='+str(size-zHq7nBWJTNyY1I3aLco4AR)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,74,afR4xElWyzgcNAUnKXBempC)
	else:
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+'الرابط ليس فيديو',Vk54F7GcROfCy6HunEI,9999,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	hj50MJnoOp6ZWaS1IQ8Elr,AWjJSatwokZ = url.split('?section=')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,True,Vk54F7GcROfCy6HunEI,'AKOAM-PLAY_AKOAM-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = Ry3L7fdNGh[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 = TSLhPFdNlpHWc6AwCbxe9nJkqiEO0 + 'direct_link_box'
	DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall('epsoide_box(.*?)direct_link_box',TSLhPFdNlpHWc6AwCbxe9nJkqiEO0,RSuYINdeamsK0t.DOTALL)
	AWjJSatwokZ = len(DatFuedGb45zR1KqIWNk)-int(AWjJSatwokZ)
	UwcYSVZbdK3rI = DatFuedGb45zR1KqIWNk[AWjJSatwokZ]
	MMJL8QqY6T7dv1onu = []
	sHOfyKgz2E = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = RSuYINdeamsK0t.findall("class='download_btn.*?href='(.*?)'",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=________akoam')
	items = RSuYINdeamsK0t.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for FnEjYH6rXWvTt,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		FnEjYH6rXWvTt = FnEjYH6rXWvTt.split('/')[-1]
		FnEjYH6rXWvTt = FnEjYH6rXWvTt.split('.')[0]
		if FnEjYH6rXWvTt in sHOfyKgz2E:
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+sHOfyKgz2E[FnEjYH6rXWvTt]+'________akoam')
		else: MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+FnEjYH6rXWvTt+'________akoam')
	if not MMJL8QqY6T7dv1onu:
		message = RSuYINdeamsK0t.findall('sub-no-file.*?\n(.*?)\n',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if message: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من الموقع الاصلي',message[0])
	else:
		import f37xHeSwPL
		f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/search/'+HJVMp5sLkG7EnixWo3QOg
	w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMA4U'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_C4U_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==420: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==421: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==422: w8YsNWfQ5gFluRvOmSd4Cb96H = LtxlDoQP8WUczV3w2(url)
	elif mode==423: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==424: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==427: w8YsNWfQ5gFluRvOmSd4Cb96H = cZrsdpG2zEf1oOiD8PVQBwYHRqvS(url)
	elif mode==429: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,429,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',lseWcUVP5qY,425)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',lseWcUVP5qY,424)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الرئيسية',lseWcUVP5qY,421)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('NavigationMenu(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="*(.*?)"*>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if '/actors' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = 'أفلام النجوم'
		elif '/netflix' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = 'أفلام ومسلسلات نيتفلكس'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,421)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'قائمة تفصيلية',lseWcUVP5qY,427)
	return
def cZrsdpG2zEf1oOiD8PVQBwYHRqvS(website=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('FilteringTitle(.*?)PageTitle',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,id,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if 'netflix-movies' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = 'مسلسلات نيتفلكس'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'|'+id)
	return
def txsXO7gSMnrwAh6NmJ9D(url,U8tZVnuiQqYjG5KdEWNbXF=Vk54F7GcROfCy6HunEI):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if not U8tZVnuiQqYjG5KdEWNbXF or '|' in U8tZVnuiQqYjG5KdEWNbXF:
		if '|' not in U8tZVnuiQqYjG5KdEWNbXF: iC7kTjzcuv89OIhbQRmaPMY1Lo = Vk54F7GcROfCy6HunEI
		else: iC7kTjzcuv89OIhbQRmaPMY1Lo = '/archive/'+U8tZVnuiQqYjG5KdEWNbXF
		wLMdNAUREnq0v = False
		if 'PinSlider' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',url,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
			wLMdNAUREnq0v = True
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('PageTitle(.*?)PageContent',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			v8e07ENZbVzIjaMSQPAxLUyuKcWho = Ry3L7fdNGh[0]
			C7SvpZQLjOwh9m0goVbzXadR5 = RSuYINdeamsK0t.findall('data-tab="(.*?)".*?<span>(.*?)<',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
			for fmeNrFQ02i5ZStvjT9P4HKaIl,esUNcDaPg3QoX in C7SvpZQLjOwh9m0goVbzXadR5:
				YBDKFZOGfyCHLPA1EaUz9MJ = lseWcUVP5qY+'/ajaxcenter/action/HomepageLoader/tab/'+fmeNrFQ02i5ZStvjT9P4HKaIl+iC7kTjzcuv89OIhbQRmaPMY1Lo+'/'
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ,421)
				wLMdNAUREnq0v = True
		if wLMdNAUREnq0v: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	if U8tZVnuiQqYjG5KdEWNbXF=='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('PinSlider(.*?)MultiFilter',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: Ry3L7fdNGh = RSuYINdeamsK0t.findall('PinSlider(.*?)PageTitle',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		else: UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
	elif '/filter/' in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('PageContent(.*?)class="*pagination"*',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	elif '/actors' in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('PageContent(.*?)class="*pagination"*',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('Cima4uBlocks(.*?)</li></ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		else: UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
	if not items: items = RSuYINdeamsK0t.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if not items: items = RSuYINdeamsK0t.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if not title: continue
		if '?news=' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
		title = title.replace('مشاهدة ',Vk54F7GcROfCy6HunEI)
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) حلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if AWjJSatwokZ and 'حلقة' in title:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,422,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/actor/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,421,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,422,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('pagination(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh and U8tZVnuiQqYjG5KdEWNbXF!='featured':
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,421)
	Xhmn2Nrb5dLK4GOTIe3p = RSuYINdeamsK0t.findall('</li><a href="(.*?)".*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Xhmn2Nrb5dLK4GOTIe3p:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title = Xhmn2Nrb5dLK4GOTIe3p[0]
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,421)
	return
def LtxlDoQP8WUczV3w2(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-SEASONS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="WatchNow".*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		url = Ry3L7fdNGh[0]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-SEASONS-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('SeasonsSections(.*?)</div></div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if '/tag/' in url or '/actor' in url:
		txsXO7gSMnrwAh6NmJ9D(url)
	elif Ry3L7fdNGh:
		afR4xElWyzgcNAUnKXBempC = J2L6to3R1Z.getInfoLabel('ListItem.Thumb')
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall("href='(.*?)'>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		XBo5SuJlDQLR9G6v0nbcd = ['مسلسل','موسم','برنامج','حلقة']
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if any(value in title for value in XBo5SuJlDQLR9G6v0nbcd):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,423,afR4xElWyzgcNAUnKXBempC)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,426,afR4xElWyzgcNAUnKXBempC)
	else: SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"background-image:url\((.*?)\)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
	else: afR4xElWyzgcNAUnKXBempC = Vk54F7GcROfCy6HunEI
	aaDZiuBb5zsPgT1cWtnk3oQU0v4 = RSuYINdeamsK0t.findall('EpisodesSection(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if aaDZiuBb5zsPgT1cWtnk3oQU0v4:
		UwcYSVZbdK3rI = aaDZiuBb5zsPgT1cWtnk3oQU0v4[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,AWjJSatwokZ in items:
			title = title+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+AWjJSatwokZ
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,426,afR4xElWyzgcNAUnKXBempC)
	else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+'رابط التشغيل',url,426,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	AvQkxtXDKfW0dON3RE79gaHPLro = Iy3PA1SVXNfjOchtgHC5kuJBG.url
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: AvQkxtXDKfW0dON3RE79gaHPLro = AvQkxtXDKfW0dON3RE79gaHPLro.encode(AoCWwJHgUPKXI7u2lEzym)
	lseWcUVP5qY = RRav1Sf7Px(AvQkxtXDKfW0dON3RE79gaHPLro,'url')
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('WatchSection(.*?)</div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('data-link="(.*?)".*? />(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for rqMLoZpDlPfi95u,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'myvid' in title.lower(): title = 'خاص '+title
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/structure/server.php?id='+rqMLoZpDlPfi95u+'?named='+title+'__watch'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('DownloadServers(.*?)</div></div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*? />(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'myvid' in title.lower(): esUNcDaPg3QoX = '__خاص'
			else: esUNcDaPg3QoX = Vk54F7GcROfCy6HunEI
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+esUNcDaPg3QoX
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/Search?q='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
def xkK0Y7fnciMQvjyq(url):
	if 'smartemadfilter' not in url: url = RRav1Sf7Px(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('MultiFilter(.*?)PageTitle',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ugep4NW1YS = RSuYINdeamsK0t.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return Ugep4NW1YS
def uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI):
	items = RSuYINdeamsK0t.findall('data-id="(.*?)".*?</div>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return items
def eW2Btjung49(url):
	zxAP2BC6ekOXpHnwF = url.split('/smartemadfilter?')[0]
	iFJVwrXDlfRUKN20 = RRav1Sf7Px(url,'url')
	url = url.replace(zxAP2BC6ekOXpHnwF,iFJVwrXDlfRUKN20)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
jVTGDSdXIEbQJ6ueqK19w = ['category','types','release-year']
LJSlAbTd4vknNqtOUZDm = ['Quality','release-year','types','category']
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global jVTGDSdXIEbQJ6ueqK19w
			jVTGDSdXIEbQJ6ueqK19w = jVTGDSdXIEbQJ6ueqK19w[1:]
		if jVTGDSdXIEbQJ6ueqK19w[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(jVTGDSdXIEbQJ6ueqK19w[0:-1])):
			if jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='ALL_ITEMS_FILTER':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+KMbV6CGYIuH
		hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',hj50MJnoOp6ZWaS1IQ8Elr,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filter')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',hj50MJnoOp6ZWaS1IQ8Elr,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filter')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ugep4NW1YS = xkK0Y7fnciMQvjyq(url)
	dict = {}
	for name,UwcYSVZbdK3rI,kuKGA8HpgN7PyjvxeLZ in Ugep4NW1YS:
		if '/category/' in url and kuKGA8HpgN7PyjvxeLZ=='category': continue
		name = name.replace('--',Vk54F7GcROfCy6HunEI)
		items = uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='SPECIFIED_FILTER':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<2:
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]:
					url = eW2Btjung49(url)
					txsXO7gSMnrwAh6NmJ9D(url)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'SPECIFIED_FILTER___'+Ng1Jod47fp0S)
				return
			else:
				hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filter')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,425,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='ALL_ITEMS_FILTER':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع :'+name,hj50MJnoOp6ZWaS1IQ8Elr,424,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if value=='196533': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'أفلام نيتفلكس'
			elif value=='196531': CCPw5ZS83fxa7AXzQ9VvUIrNDbo = 'مسلسلات نيتفلكس'
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'#+dict[kuKGA8HpgN7PyjvxeLZ]['0']
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'+name
			if type=='ALL_ITEMS_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,424,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='SPECIFIED_FILTER' and jVTGDSdXIEbQJ6ueqK19w[-2]+'=' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'modified_filters')
				ynmiDuav5ICTeRsqj6Vb18Q = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				ynmiDuav5ICTeRsqj6Vb18Q = eW2Btjung49(ynmiDuav5ICTeRsqj6Vb18Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,421,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filter')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,425,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.replace('=&','=0&')
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	for key in LJSlAbTd4vknNqtOUZDm:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.replace('=0','=')
	return PpjxGzO7yqD0AXSJL1Mw
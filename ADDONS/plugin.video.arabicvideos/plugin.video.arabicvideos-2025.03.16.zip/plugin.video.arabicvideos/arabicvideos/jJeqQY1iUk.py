﻿# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,muBTftRFQDvhsCZiEMV):
	if muBTftRFQDvhsCZiEMV==Vk54F7GcROfCy6HunEI: return
	if Yz6schq9wSmiu3IOdke0DXPj5W==1:
		hyq03oZSn19MGz5VLtr = SZDFRGim3j8L.getCurrentWindowDialogId()
		x8oRkwze61WhbGPLD5 = SZDFRGim3j8L.Window(hyq03oZSn19MGz5VLtr)
		muBTftRFQDvhsCZiEMV = YqgcrtzU8LVNymnp3Z(muBTftRFQDvhsCZiEMV)
		x8oRkwze61WhbGPLD5.getControl(311).setLabel(muBTftRFQDvhsCZiEMV)
	if Yz6schq9wSmiu3IOdke0DXPj5W==0:
		WypSQTO7504tHY='X'
		if PvwFsJK23NbU8XWAx: hXsrqMyaZb4Bj = isinstance(muBTftRFQDvhsCZiEMV,str)
		else: hXsrqMyaZb4Bj = isinstance(muBTftRFQDvhsCZiEMV,unicode)
		if hXsrqMyaZb4Bj==True: WypSQTO7504tHY='U'
		D0OjpwXJIPqNB=str(type(muBTftRFQDvhsCZiEMV))+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+muBTftRFQDvhsCZiEMV+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+WypSQTO7504tHY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
		for zHq7nBWJTNyY1I3aLco4AR in range(0,len(muBTftRFQDvhsCZiEMV),1):
			D0OjpwXJIPqNB += hex(ord(muBTftRFQDvhsCZiEMV[zHq7nBWJTNyY1I3aLco4AR])).replace('0x',Vk54F7GcROfCy6HunEI)+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
		muBTftRFQDvhsCZiEMV = YqgcrtzU8LVNymnp3Z(muBTftRFQDvhsCZiEMV)
		WypSQTO7504tHY='X'
		if PvwFsJK23NbU8XWAx: hXsrqMyaZb4Bj = isinstance(muBTftRFQDvhsCZiEMV, str)
		else: hXsrqMyaZb4Bj = isinstance(muBTftRFQDvhsCZiEMV, unicode)
		if hXsrqMyaZb4Bj==True: WypSQTO7504tHY='U'
		DjL1CoTyd2J3=str(type(muBTftRFQDvhsCZiEMV))+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+muBTftRFQDvhsCZiEMV+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+WypSQTO7504tHY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
		for zHq7nBWJTNyY1I3aLco4AR in range(0,len(muBTftRFQDvhsCZiEMV),1):
			DjL1CoTyd2J3 += hex(ord(muBTftRFQDvhsCZiEMV[zHq7nBWJTNyY1I3aLco4AR])).replace('0x',Vk54F7GcROfCy6HunEI)+otBWsSAfu7dihVkP9e1JFKrvmYy2Q
	return
# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMANOW'
xzA9sM3rG6IHd7jl8T = '_CMN_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['قائمتي']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==300: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==301: w8YsNWfQ5gFluRvOmSd4Cb96H = kAuPp3tC2FhGEb8m6DjMZVi(url)
	elif mode==302: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==303: w8YsNWfQ5gFluRvOmSd4Cb96H = LtxlDoQP8WUczV3w2(url)
	elif mode==304: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==305: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==306: w8YsNWfQ5gFluRvOmSd4Cb96H = ggMHQnVw0lPJImj()
	elif mode==309: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,309,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/home',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<header>(.*?)</header>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('<li><a href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,301)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	kAuPp3tC2FhGEb8m6DjMZVi(FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/home',FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def ggMHQnVw0lPJImj():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def kAuPp3tC2FhGEb8m6DjMZVi(url,FjwObZSWkg8ahBdiQf9IeY135DpXoP=Vk54F7GcROfCy6HunEI):
	if not FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-SUBMENU-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	W7SMIpbzhori2JE9mv = 0
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('(<section>.*?</section>)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		for UwcYSVZbdK3rI in Ry3L7fdNGh:
			W7SMIpbzhori2JE9mv += 1
			items = RSuYINdeamsK0t.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for title,Xnteb7NYoCxjAwBULGvc960y,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				if title==Vk54F7GcROfCy6HunEI: title = 'بووووو'
				if 'em><a' not in Xnteb7NYoCxjAwBULGvc960y:
					if UwcYSVZbdK3rI.count('/category/')>0:
						tt8LGEdJs5hcFC9krZ3BHWAjSoY = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
						for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in tt8LGEdJs5hcFC9krZ3BHWAjSoY:
							title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-2]
							v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,301)
						continue
					else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'?sequence='+str(W7SMIpbzhori2JE9mv)
				if not any(value in title for value in wXPtB6I0QKLTyD932sl5d):
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,302)
	else: txsXO7gSMnrwAh6NmJ9D(url,FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	return
def txsXO7gSMnrwAh6NmJ9D(url,FjwObZSWkg8ahBdiQf9IeY135DpXoP=Vk54F7GcROfCy6HunEI):
	if FjwObZSWkg8ahBdiQf9IeY135DpXoP==Vk54F7GcROfCy6HunEI:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-TITLES-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if '?sequence=' in url:
		url,W7SMIpbzhori2JE9mv = url.split('?sequence=')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('(<section>.*?</section>)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[int(W7SMIpbzhori2JE9mv)-1]
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"posts"(.*?)</body>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,data,afR4xElWyzgcNAUnKXBempC in items:
		title = RSuYINdeamsK0t.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,RSuYINdeamsK0t.DOTALL)
		if title: title = title[0][2].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if not title or title==Vk54F7GcROfCy6HunEI:
			title = RSuYINdeamsK0t.findall('title">.*?</em>(.*?)<',data,RSuYINdeamsK0t.DOTALL)
			if title: title = title[0].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if not title or title==Vk54F7GcROfCy6HunEI:
				title = RSuYINdeamsK0t.findall('title">(.*?)<',data,RSuYINdeamsK0t.DOTALL)
				title = title[0].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		title = Uo7Tbc29Eu(title)
		title = title.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if title not in GEzxBN8rAh1d:
			GEzxBN8rAh1d.append(title)
			v8e07ENZbVzIjaMSQPAxLUyuKcWho = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+data+afR4xElWyzgcNAUnKXBempC
			if '/selary/' in v8e07ENZbVzIjaMSQPAxLUyuKcWho or 'مسلسل' in v8e07ENZbVzIjaMSQPAxLUyuKcWho or '"episode"' in v8e07ENZbVzIjaMSQPAxLUyuKcWho:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,303,afR4xElWyzgcNAUnKXBempC)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,305,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<li><a href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,302)
	return
def LtxlDoQP8WUczV3w2(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-SEASONS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	name = RSuYINdeamsK0t.findall('<title>(.*?)</title>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',Vk54F7GcROfCy6HunEI).replace('Cima Now',Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		name = name.split('الحلقة')[0].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)+' - '
	else: name = Vk54F7GcROfCy6HunEI
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<section(.*?)</section>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if len(items)>1:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = name+title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,304)
		elif len(items)==1:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title = items[0]
			SQr4lDstIa0NdFyp7Pf23BG6jnLY(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		else: SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if '/selary/' not in url:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"episodes"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			title = 'الحلقة '+title
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,305)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"details"(.*?)"related"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,305,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	hqwmBgbJYo90CRMuPAdX3tiylNvz = RSuYINdeamsK0t.findall('class="shine" href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hqwmBgbJYo90CRMuPAdX3tiylNvz:
		oOv4sVqEAmyM = RRav1Sf7Px(hqwmBgbJYo90CRMuPAdX3tiylNvz[0],'url')
		headers = {'Referer':oOv4sVqEAmyM}
	else: headers = Vk54F7GcROfCy6HunEI
	hj50MJnoOp6ZWaS1IQ8Elr = url+'watching/'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMANOW-PLAY-5th')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"download"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</i>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			jMiru3pGns = RSuYINdeamsK0t.findall('\d\d\d+',title,RSuYINdeamsK0t.DOTALL)
			if jMiru3pGns:
				jMiru3pGns = '____'+jMiru3pGns[0]
				title = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
			else: jMiru3pGns = Vk54F7GcROfCy6HunEI
			YBDKFZOGfyCHLPA1EaUz9MJ = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+jMiru3pGns
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(YBDKFZOGfyCHLPA1EaUz9MJ)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"watch"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('"embed".*?src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'name')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__embed'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		HXhRgxEZ4d2Dek = [FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/wp-content/themes/Cima%20Now%20New/core.php']
		if HXhRgxEZ4d2Dek:
			items = RSuYINdeamsK0t.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for p1pTyjFEIDr3lgUHhdJsm5t9MBwS,id,title in items:
				title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = HXhRgxEZ4d2Dek[0]+'?action=switch&index='+p1pTyjFEIDr3lgUHhdJsm5t9MBwS+'&id='+id+'?named='+title+'__watch'
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url)
	return
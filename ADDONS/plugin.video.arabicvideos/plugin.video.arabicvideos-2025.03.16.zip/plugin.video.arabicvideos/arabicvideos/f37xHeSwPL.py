# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = V2RQwM8XjlrK(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᷔ")
e0grHtADF7sG = []
headers = {eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᷕ"):Vk54F7GcROfCy6HunEI}
def XaBikMpvOqAU9yIQV3Y4mGdtfKWu(url,VV6Z5b3pHm7ETlW,XLg5UfRh6nBubWC7eK):
	url = url.replace(NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ࠱ࡰ࡭ࡷࡸ࡯ࡳ࠱ࠪᷖ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࠲࡭࡫ࡸࡡ࡮ࡧ࠲ࠫᷗ")).replace(pnkrd2S84FJfN73KuiCYv(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧᷘ"),pnkrd2S84FJfN73KuiCYv(u"ࠫ࠴࡯ࡦࡳࡣࡰࡩ࠴࠭ᷙ"))
	url = url.replace(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࠵ࡷ࠯࡯ࡨ࡫ࡦࡳࡡࡹ࠰ࡰࡩ࠴࠭ᷚ"),NNjUsZzEcFOAoKry2CDMgb1(u"࠭࠯࡮ࡧࡪࡥࡲࡧࡸ࠯࡯ࡨ࠳ࠬᷛ"))
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,V2RQwM8XjlrK(u"ࠧࡈࡇࡗࠫᷜ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,ESXZrtnCfcDJGo01vFg(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓࡅࡈࡃࡐࡅ࡝࠳࠱ࡴࡶࠪᷝ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	vbeiLuMzJsNdjKHhSXZW0 = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠩࡵࡺࡵࡴ࠼࠼ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠭ᷞ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	headers = {WsklGNp2CYzVQUag(u"ࠪ࡜࠲ࡏ࡮ࡦࡴࡷ࡭ࡦ࠭ᷟ"):wAU9jKvmTM0(u"ࠫࡹࡸࡵࡦࠩᷠ"),pnkrd2S84FJfN73KuiCYv(u"ࠬ࡞࠭ࡊࡰࡨࡶࡹ࡯ࡡ࠮ࡒࡤࡶࡹ࡯ࡡ࡭࠯ࡇࡥࡹࡧࠧᷡ"):g7yJo2LVuqx1trPe(u"࠭ࡳࡵࡴࡨࡥࡲࡹࠧᷢ"),V2RQwM8XjlrK(u"࡙ࠧ࠯ࡌࡲࡪࡸࡴࡪࡣ࠰ࡔࡦࡸࡴࡪࡣ࡯࠱ࡈࡵ࡭ࡱࡱࡱࡩࡳࡺࠧᷣ"):BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡨ࡬ࡰࡪࡹ࠯࡮࡫ࡵࡶࡴࡸ࠯ࡷ࡫ࡧࡩࡴ࠭ᷤ")}
	headers[wAU9jKvmTM0(u"࡛ࠩ࠱ࡎࡴࡥࡳࡶ࡬ࡥ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᷥ")] = vbeiLuMzJsNdjKHhSXZW0[ufmXvxgoHGDwZtjsLkR05i]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,pnkrd2S84FJfN73KuiCYv(u"ࠪࡋࡊ࡚ࠧᷦ"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏࡈࡋࡆࡓࡁ࡙࠯࠵ࡲࡩ࠭ᷧ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	HxNybJ6pTOgf3AYea = MkuHT2blpeds34wXxDyvgitqWo.loads(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	BzM5GvfomTOyqRrC1l4WJd3 = HxNybJ6pTOgf3AYea[Nlyfx1HnzOWCovke5(u"ࠬࡶࡲࡰࡲࡶࠫᷨ")][NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡳࡵࡴࡨࡥࡲࡹࠧᷩ")][l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡥࡣࡷࡥࠬᷪ")]
	MMJL8QqY6T7dv1onu = []
	for l5jaqCcHr6PGJQSFgoKM0s in range(len(BzM5GvfomTOyqRrC1l4WJd3)):
		jMiru3pGns = BzM5GvfomTOyqRrC1l4WJd3[l5jaqCcHr6PGJQSFgoKM0s][ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࡮ࡤࡦࡪࡲࠧᷫ")]
		HXhRgxEZ4d2Dek = BzM5GvfomTOyqRrC1l4WJd3[l5jaqCcHr6PGJQSFgoKM0s][l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡰ࡭ࡷࡸ࡯ࡳࡵࠪᷬ")]
		for mBsE0NxfrlZ9 in range(len(HXhRgxEZ4d2Dek)):
			title = HXhRgxEZ4d2Dek[mBsE0NxfrlZ9][QYSAUI5r46yil8cfaO(u"ࠪࡨࡷ࡯ࡶࡦࡴࠪᷭ")]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = wAU9jKvmTM0(u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫᷮ")+HXhRgxEZ4d2Dek[mBsE0NxfrlZ9][g7yJo2LVuqx1trPe(u"ࠬࡲࡩ࡯࡭ࠪᷯ")]+SSBkx0WbN1asnDCQV6tIj(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᷰ")+title+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡠࡡࠪᷱ")+VV6Z5b3pHm7ETlW+XCYALgFs2O3hZdpHrlMmB(u"ࠨࡡࡢࠫᷲ")+jMiru3pGns
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	return MMJL8QqY6T7dv1onu
def BDHby2pEuQ4K8(url,VV6Z5b3pHm7ETlW,XLg5UfRh6nBubWC7eK):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,XCYALgFs2O3hZdpHrlMmB(u"ࠩࡊࡉ࡙࠭ᷳ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,MpJ8GOKoic(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡂࡎࡅࡅࡕࡒࡁ࡚ࡇࡕ࠱࠶ࡹࡴࠨᷴ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if isinstance(FjwObZSWkg8ahBdiQf9IeY135DpXoP,bytes): FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.decode(AoCWwJHgUPKXI7u2lEzym,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ᷵"))
	Ry3L7fdNGh = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࠨࡡࡱ࡮ࡵ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᷶"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
		items = RSuYINdeamsK0t.findall(MzgKWUQ4V5H(u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤࡤࡴࡱࡸ࠭࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾᷷ࠪ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		MMJL8QqY6T7dv1onu = []
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᷸")+title+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡡࡢ᷹ࠫ")+VV6Z5b3pHm7ETlW)
	return MMJL8QqY6T7dv1onu
def NbnC0kgmuayWOXhcev(url,VV6Z5b3pHm7ETlW,XLg5UfRh6nBubWC7eK):
	SBy5dFiWExn2jkMXDs89UKhuVt4mY3 = url.split(MpJ8GOKoic(u"ࠩ࠲᷺ࠫ"))[ynxXU3gaiQ9GPCftr1q(u"࠺൬")]
	J4GX5SPIvY1anesyTKWVZr8 = PnRA5dpzE18JU.b64decode(SBy5dFiWExn2jkMXDs89UKhuVt4mY3)
	if PvwFsJK23NbU8XWAx: J4GX5SPIvY1anesyTKWVZr8 = J4GX5SPIvY1anesyTKWVZr8.decode(AoCWwJHgUPKXI7u2lEzym)
	K51fQOtRTuLyx3qbUnV = ZlBMJUAWRm9buv(J4GX5SPIvY1anesyTKWVZr8)+eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᷻")+XLg5UfRh6nBubWC7eK
	return [K51fQOtRTuLyx3qbUnV]
def qe3NDMXfWrtScs0ulxVZdTi(url):
	Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = Vk54F7GcROfCy6HunEI,[],[]
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ᷼") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,wAU9jKvmTM0(u"ࠬࡍࡅࡕ᷽ࠩ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗ࠳࠱ࡴࡶࠪ᷾"))
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.url
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	elif WXuJd8nz2spo146t(u"ࠧࡴࡧࡵࡺࡂ᷿࠭") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,QYSAUI5r46yil8cfaO(u"ࠨࡉࡈࡘࠬḀ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡌࡃࡃࡓࡐࡆ࡟ࡅࡓ࠯࠵ࡲࡩ࠭ḁ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḂ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: url = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		else:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(WXuJd8nz2spo146t(u"ࠦࡆࡲࡢࡢࡒ࡯ࡥࡾ࡫ࡲࡄࡱࡱࡸࡷࡵ࡬࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩࠥḃ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				url = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
				url = PnRA5dpzE18JU.b64decode(url)
				if PvwFsJK23NbU8XWAx: url = url.decode(AoCWwJHgUPKXI7u2lEzym)
			else: return pnkrd2S84FJfN73KuiCYv(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡅࡅࡕࡒࡁ࡚ࡇࡕࠫḄ"),[],[]
		Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = MzgKWUQ4V5H(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḅ"),[Vk54F7GcROfCy6HunEI],[url]
	return Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu
def iV0X1OGQNrTPCgt(o8yg1bH2FU5PkYEpVzIdsX7,source):
	FMpUSlAmskvgKEZ,jqLVOGcz37JNtr = [],[]
	for ZhKvMoPs3BX12tN in o8yg1bH2FU5PkYEpVzIdsX7:
		qOjIGBrnXhlx = RSuYINdeamsK0t.findall(jXWzIZcDva4ikEUfN(u"ࠧ࡯ࡣࡰࡩࡩࡃ࠮ࠫࡁࡢࡣ࠭࠴ࠪࡀࠫࡢࡣࠬḆ"),ZhKvMoPs3BX12tN+MpJ8GOKoic(u"ࠨࡡࡢࠫḇ"),RSuYINdeamsK0t.DOTALL)
		wo9k5817amns2M = qOjIGBrnXhlx[ufmXvxgoHGDwZtjsLkR05i] if qOjIGBrnXhlx else Vk54F7GcROfCy6HunEI
		Q2Eux49rnpKFCwaMztDGoyiWYjhU8q,ipVAuqjDhWbY9vMe4,VV2e6BuEOz9ta = ZhKvMoPs3BX12tN,Vk54F7GcROfCy6HunEI,[]
		if V2RQwM8XjlrK(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪḈ") in ZhKvMoPs3BX12tN: Q2Eux49rnpKFCwaMztDGoyiWYjhU8q,ipVAuqjDhWbY9vMe4 = ZhKvMoPs3BX12tN.split(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫḉ"),pwxH3oREFm5v98BCZ1QVtzMJOc)
		try:
			if g7yJo2LVuqx1trPe(u"ࠫࡦࡲࡢࡢࡲ࡯ࡥࡾ࡫ࡲࠨḊ") in Q2Eux49rnpKFCwaMztDGoyiWYjhU8q: VV2e6BuEOz9ta = BDHby2pEuQ4K8(Q2Eux49rnpKFCwaMztDGoyiWYjhU8q,wo9k5817amns2M,ipVAuqjDhWbY9vMe4)
			elif cpHxZyU7vTtqmIw(u"ࠬࡳࡥࡨࡣࡰࡥࡽ࠭ḋ") in Q2Eux49rnpKFCwaMztDGoyiWYjhU8q: VV2e6BuEOz9ta = XaBikMpvOqAU9yIQV3Y4mGdtfKWu(Q2Eux49rnpKFCwaMztDGoyiWYjhU8q,wo9k5817amns2M,ipVAuqjDhWbY9vMe4)
			elif wAU9jKvmTM0(u"࠭࠯࡭࠱ࡤࡌࡗ࠶ࡣࡉࡏ࠹ࡐࡾ࠿ࠧḌ") in Q2Eux49rnpKFCwaMztDGoyiWYjhU8q: VV2e6BuEOz9ta = NbnC0kgmuayWOXhcev(Q2Eux49rnpKFCwaMztDGoyiWYjhU8q,wo9k5817amns2M,ipVAuqjDhWbY9vMe4)
		except: pass
		if VV2e6BuEOz9ta:
			for YBDKFZOGfyCHLPA1EaUz9MJ in VV2e6BuEOz9ta:
				tgQu3APewZdLvqFyT5bHC60Ej,oCISNjhp09Piqad65w8FBvMbWlu = YBDKFZOGfyCHLPA1EaUz9MJ,Vk54F7GcROfCy6HunEI
				if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨḍ") in YBDKFZOGfyCHLPA1EaUz9MJ: tgQu3APewZdLvqFyT5bHC60Ej,oCISNjhp09Piqad65w8FBvMbWlu = YBDKFZOGfyCHLPA1EaUz9MJ.split(WCPwmyVsb62KRlo(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩḎ"),pwxH3oREFm5v98BCZ1QVtzMJOc)
				if tgQu3APewZdLvqFyT5bHC60Ej not in FMpUSlAmskvgKEZ:
					FMpUSlAmskvgKEZ.append(tgQu3APewZdLvqFyT5bHC60Ej)
					jqLVOGcz37JNtr.append(YBDKFZOGfyCHLPA1EaUz9MJ)
		elif Q2Eux49rnpKFCwaMztDGoyiWYjhU8q not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(Q2Eux49rnpKFCwaMztDGoyiWYjhU8q)
			jqLVOGcz37JNtr.append(ZhKvMoPs3BX12tN)
	return jqLVOGcz37JNtr
def oogER58wOUZWcyFJb3Gs(source,WypSQTO7504tHY,url):
	iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+pnkrd2S84FJfN73KuiCYv(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩḏ")+source+NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫḐ")+WypSQTO7504tHY+jXWzIZcDva4ikEUfN(u"ࠫࠥࡣࠧḑ"))
	TzeD5skpU0QnaZtrBuGi3Y = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡪࡩࡤࡶࠪḒ"),wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩḓ"),YzowicIDTRusXZSU61(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭Ḕ"))
	k3CIfpuzbU = Gb6kwVlSQ4MU.strftime(wAU9jKvmTM0(u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩḕ"),Gb6kwVlSQ4MU.gmtime(npbh5qZo1PBiNkj))
	bBpKQ53S0agq6lRw1 = k3CIfpuzbU,url
	key = source+qMmCGK8cln5bID4fkhAF+ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk+qMmCGK8cln5bID4fkhAF+str(gs15xoifvOt)
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = Vk54F7GcROfCy6HunEI
	if key not in list(TzeD5skpU0QnaZtrBuGi3Y.keys()): TzeD5skpU0QnaZtrBuGi3Y[key] = [bBpKQ53S0agq6lRw1]
	else:
		if url not in str(TzeD5skpU0QnaZtrBuGi3Y[key]): TzeD5skpU0QnaZtrBuGi3Y[key].append(bBpKQ53S0agq6lRw1)
		else: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧḖ")
	qPQ9oCcxdzTbM4pysa5f = ufmXvxgoHGDwZtjsLkR05i
	for key in list(TzeD5skpU0QnaZtrBuGi3Y.keys()):
		TzeD5skpU0QnaZtrBuGi3Y[key] = list(set(TzeD5skpU0QnaZtrBuGi3Y[key]))
		qPQ9oCcxdzTbM4pysa5f += len(TzeD5skpU0QnaZtrBuGi3Y[key])
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jXWzIZcDva4ikEUfN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ḗ"),MzgKWUQ4V5H(u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬḘ")+BadMOTrh9Lnp0w6KZCQASE4uyk7fW+EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡢ࡮࡝ࡰ่้ࠣ฿ไๆࠢส่อืๆศ็ฯࠤ๏่่ๆࠢหะ๊฿ࠠใษษ้ฮࠦศศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥ๐ฬะࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤํู่โࠢํ฽ึ฼ฺࠠๆํ็ࠥอไษำ้ห๊าࠠฤ่ࠣฮึูไ้ࠡำ๋ࠥอไใษษ้ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾์ฯๆษࠣ๎ฺฮอࠡ฻าำ์อࠠ࠶ࠢไ๎ิ๐่่ษอࠫḙ")+eAMGzHRQVs2KyCwPXljYhB(u"࠭࡜࡯࡞ࡱࠫḚ")+FGLEMi21Bfn(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪḛ")+str(qPQ9oCcxdzTbM4pysa5f))
	if qPQ9oCcxdzTbM4pysa5f>=m5DECdgjU4KqpVhyJ9A2b:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḜ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩส่อืๆศ็ฯࠤัู๋ࠡไสส๊ฯࠠโ์๊หࠥ࠻ࠠโ์า๎ํํวหࠢ็้ࠥ๐ฬะࠢส่อืๆศ็ฯࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ๋ำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦลาีส่ࠥํะ่ࠢส่็อฦๆหࠣๆอ๊ࠠๆีะ๋ฬࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅ็หี๊าࠠษใะูࠥํะ่ࠢส่ๆ๐ฯ๋๊๊หฯࠦฟࠢࠣࠪḝ"))
		if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
			h1hCuxyBEI = Vk54F7GcROfCy6HunEI
			for key in list(TzeD5skpU0QnaZtrBuGi3Y.keys()):
				h1hCuxyBEI += ixrPWKeFMnqJyVodX6D9AaO2+key
				QQLUlTrDMvhkRudmjFzWGVxa = sorted(TzeD5skpU0QnaZtrBuGi3Y[key],reverse=eu1NswY9zkKC60I,key=lambda llfDRvHqwcxLJuB018GVp79OW: llfDRvHqwcxLJuB018GVp79OW[ufmXvxgoHGDwZtjsLkR05i])
				for k3CIfpuzbU,url in QQLUlTrDMvhkRudmjFzWGVxa:
					h1hCuxyBEI += ixrPWKeFMnqJyVodX6D9AaO2+k3CIfpuzbU+qMmCGK8cln5bID4fkhAF+ZlBMJUAWRm9buv(url)
				h1hCuxyBEI += ESXZrtnCfcDJGo01vFg(u"ࠪࡠࡳࡢ࡮ࠨḞ")
			import rrnsP3eh5Q
			kNQM9jAU6TVlhezn14cKtBb = rrnsP3eh5Q.G5GEld8on2FIazkY(jXWzIZcDva4ikEUfN(u"࡛ࠫ࡯ࡤࡦࡱࡶࠫḟ"),Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḠ"),Vk54F7GcROfCy6HunEI,h1hCuxyBEI)
			if kNQM9jAU6TVlhezn14cKtBb: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩḡ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪḢ"))
			else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḣ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩไุ้ะฺࠠ็็๎ฮࠦวๅวิืฬ๊ࠧḤ"))
		if W8j2OheqsroDJIYzRupt6nG!=-pwxH3oREFm5v98BCZ1QVtzMJOc:
			TzeD5skpU0QnaZtrBuGi3Y = {}
			kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ḥ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪḦ"))
	if TzeD5skpU0QnaZtrBuGi3Y: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨḧ"),WCPwmyVsb62KRlo(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬḨ"),TzeD5skpU0QnaZtrBuGi3Y,piwNWcJEe9m)
	return
def DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,source,WypSQTO7504tHY,url):
	if not MMJL8QqY6T7dv1onu:
		oogER58wOUZWcyFJb3Gs(source,WypSQTO7504tHY,url)
		return
	PSo6Hynm5cdOBMzL = cad8TeSyMUYmfsEO0.getSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫḩ"))
	tfWzFSja2yr = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࠯ࠪḪ") not in PSo6Hynm5cdOBMzL
	VV2e6BuEOz9ta = iV0X1OGQNrTPCgt(MMJL8QqY6T7dv1onu[:],source)
	if VV2e6BuEOz9ta!=MMJL8QqY6T7dv1onu and not tfWzFSja2yr:
		qAWIPHj6zYyhFsRulBm = []
		for ZhKvMoPs3BX12tN in MMJL8QqY6T7dv1onu:
			XGxCZsfQvckMJmKT6Ea15rSd,XLg5UfRh6nBubWC7eK = ZhKvMoPs3BX12tN,Vk54F7GcROfCy6HunEI
			if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪḫ") in ZhKvMoPs3BX12tN: XGxCZsfQvckMJmKT6Ea15rSd,XLg5UfRh6nBubWC7eK = ZhKvMoPs3BX12tN.split(MzgKWUQ4V5H(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫḬ"),pwxH3oREFm5v98BCZ1QVtzMJOc)
			XLg5UfRh6nBubWC7eK = XLg5UfRh6nBubWC7eK.replace(MpJ8GOKoic(u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬḭ"),V2RQwM8XjlrK(u"ࠬ࠭Ḯ")).replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪḯ"),YzowicIDTRusXZSU61(u"ࠧࠨḰ")).replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩḱ"),WXuJd8nz2spo146t(u"ࠩࠪḲ"))
			qAWIPHj6zYyhFsRulBm.append(XLg5UfRh6nBubWC7eK)
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪษ฽ํวาࠢๅ์ฬฬๅࠡษ็ะํีษࠨḳ"),qAWIPHj6zYyhFsRulBm)
	MMJL8QqY6T7dv1onu = list(set(VV2e6BuEOz9ta))
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = DDVufOyzMg7HhejNEpk90AoXKr2Gd(MMJL8QqY6T7dv1onu,source)
	if h9zFQKnsNL.resolveonly:
		h0yYrdxVB28394WIvCZ = iVdWLYs1AGFR0zPO6c3mZBwE(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,source,eu1NswY9zkKC60I)
		return
	sSucxbrN0KlUyEBPvTO712dmiC,Q0WnJxCYdAINZk2tBjs5,gJChoTzFUR2PYbGNnm18c6MvW,h0yYrdxVB28394WIvCZ,GYQSk8B51t64ZwUp7aRolC,anbjzfuiDdgYP6vSXqwRex = eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,[],Vk54F7GcROfCy6HunEI,[]
	y5BOK0FMSv = not any(value in source for value in kB9H0W4xSJEpXDTd)
	if y5BOK0FMSv:
		xTlSyQbXa2M4tJ1pA7VBCU = ufmXvxgoHGDwZtjsLkR05i
		vFA4GgsSMbkquJChtyp = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡱ࡯ࡳࡵࠩḴ"),V2RQwM8XjlrK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡗࡆࡇࡊࡋࡄࡆࡆࠪḵ"))
		ESJw2ztIWHnF4g9NhcuO = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,NNjUsZzEcFOAoKry2CDMgb1(u"࠭࡬ࡪࡵࡷࠫḶ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪḷ"))
		JJc0FiTzrC1RE76PA5wo2aN = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࡮࡬ࡷࡹ࠭Ḹ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡋࡇࡉࡍࡇࡇࠫḹ"))
		W7SMIpbzhori2JE9mv = ufmXvxgoHGDwZtjsLkR05i
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in list(zip(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)):
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(FGLEMi21Bfn(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫḺ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp in vFA4GgsSMbkquJChtyp:
				xTlSyQbXa2M4tJ1pA7VBCU += pwxH3oREFm5v98BCZ1QVtzMJOc
				nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = hh6BmGb5aUH+title+ZZoLlKyInXc08j2pTGJ
			elif ssfLBvkuNiXear2gPdxcyT4AQMhYSp in JJc0FiTzrC1RE76PA5wo2aN:
				xTlSyQbXa2M4tJ1pA7VBCU += pwxH3oREFm5v98BCZ1QVtzMJOc
				nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = nMt0iueCy6K+title+ZZoLlKyInXc08j2pTGJ
			elif ssfLBvkuNiXear2gPdxcyT4AQMhYSp in ESJw2ztIWHnF4g9NhcuO:
				xTlSyQbXa2M4tJ1pA7VBCU += pwxH3oREFm5v98BCZ1QVtzMJOc
				nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = title
			else:
				xTlSyQbXa2M4tJ1pA7VBCU += pwxH3oREFm5v98BCZ1QVtzMJOc
				nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = title
			W7SMIpbzhori2JE9mv += pwxH3oREFm5v98BCZ1QVtzMJOc
		anbjzfuiDdgYP6vSXqwRex = [d761ZWXHEvliYN45RzLP2+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩḻ")+ZZoLlKyInXc08j2pTGJ]
	else: GYQSk8B51t64ZwUp7aRolC = d761ZWXHEvliYN45RzLP2+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬษฮหำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠬḼ")+ZZoLlKyInXc08j2pTGJ
	while YOHXqtbQTBfKerIZ:
		Ly6dZ0zbaG2KugB9FQA = YOHXqtbQTBfKerIZ
		if y5BOK0FMSv:
			if tfWzFSja2yr and len(nWcb8JC7zEVouFjx9fILGh1vSQ)==pwxH3oREFm5v98BCZ1QVtzMJOc: qreJEpY8nZguD = pwxH3oREFm5v98BCZ1QVtzMJOc
			else:
				ooC7RDBmIqYHhLE2vsM9pJa = str(nWcb8JC7zEVouFjx9fILGh1vSQ).count(hh6BmGb5aUH)
				nLYqmBWzayXeS4Dpvfw3PUG = str(nWcb8JC7zEVouFjx9fILGh1vSQ).count(nMt0iueCy6K)
				ffAqXj5uRLNYFgkGWrez = len(nWcb8JC7zEVouFjx9fILGh1vSQ)-ooC7RDBmIqYHhLE2vsM9pJa-nLYqmBWzayXeS4Dpvfw3PUG
				if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: GYQSk8B51t64ZwUp7aRolC = nMt0iueCy6K+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨḽ")+str(nLYqmBWzayXeS4Dpvfw3PUG)+ZZoLlKyInXc08j2pTGJ+MpJ8GOKoic(u"้ࠧࠡࠢࠣัํ่ๅห࠽ࠫḾ")+str(ffAqXj5uRLNYFgkGWrez)+hh6BmGb5aUH+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨฮํำฮࡀࠧḿ")+str(ooC7RDBmIqYHhLE2vsM9pJa)+ZZoLlKyInXc08j2pTGJ
				else: GYQSk8B51t64ZwUp7aRolC = hh6BmGb5aUH+NNjUsZzEcFOAoKry2CDMgb1(u"ࠩฯ๎ิฯ࠺ࠨṀ")+str(ooC7RDBmIqYHhLE2vsM9pJa)+ZZoLlKyInXc08j2pTGJ+WCPwmyVsb62KRlo(u"ࠪࠤࠥࠦๅอ้๋่ฮࡀࠧṁ")+str(ffAqXj5uRLNYFgkGWrez)+nMt0iueCy6K+MpJ8GOKoic(u"ࠫࠥࠦࠠิ์ษอ࠿࠭Ṃ")+str(nLYqmBWzayXeS4Dpvfw3PUG)+ZZoLlKyInXc08j2pTGJ
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(GYQSk8B51t64ZwUp7aRolC,anbjzfuiDdgYP6vSXqwRex+nWcb8JC7zEVouFjx9fILGh1vSQ)
			if qreJEpY8nZguD==ufmXvxgoHGDwZtjsLkR05i:
				Ly6dZ0zbaG2KugB9FQA = eu1NswY9zkKC60I
				start,end = ufmXvxgoHGDwZtjsLkR05i,len(nWcb8JC7zEVouFjx9fILGh1vSQ)-pwxH3oREFm5v98BCZ1QVtzMJOc
				h0yYrdxVB28394WIvCZ = iVdWLYs1AGFR0zPO6c3mZBwE(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,source,YOHXqtbQTBfKerIZ)
				gJChoTzFUR2PYbGNnm18c6MvW = WXuJd8nz2spo146t(u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪ࡟ࡢ࡮࡯ࠫṃ") if h0yYrdxVB28394WIvCZ else WsklGNp2CYzVQUag(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧṄ")
			elif qreJEpY8nZguD>ufmXvxgoHGDwZtjsLkR05i: start,end = qreJEpY8nZguD-pwxH3oREFm5v98BCZ1QVtzMJOc,qreJEpY8nZguD-pwxH3oREFm5v98BCZ1QVtzMJOc
		else:
			if tfWzFSja2yr and len(nWcb8JC7zEVouFjx9fILGh1vSQ)==pwxH3oREFm5v98BCZ1QVtzMJOc: qreJEpY8nZguD = ufmXvxgoHGDwZtjsLkR05i
			else: qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(GYQSk8B51t64ZwUp7aRolC,nWcb8JC7zEVouFjx9fILGh1vSQ)
			start,end = qreJEpY8nZguD,qreJEpY8nZguD
		if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc:
			gJChoTzFUR2PYbGNnm18c6MvW = NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩṅ")
			break
		if Ly6dZ0zbaG2KugB9FQA:
			gJChoTzFUR2PYbGNnm18c6MvW = g7yJo2LVuqx1trPe(u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࡢࡳࡳ࡫ࠧṆ")
			h0yYrdxVB28394WIvCZ = iVdWLYs1AGFR0zPO6c3mZBwE([nWcb8JC7zEVouFjx9fILGh1vSQ[start]],[yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[start]],source,YOHXqtbQTBfKerIZ)
			title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Q0WnJxCYdAINZk2tBjs5,ss285HRGmwx,HXhRgxEZ4d2Dek,fJHXGS7YqL3kaR = h0yYrdxVB28394WIvCZ[ufmXvxgoHGDwZtjsLkR05i]
			E8Wnput30AyeSKq,rC6poVY8EkwilKeD7yZ0jg = e6xvkAHalPYZ(title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,ss285HRGmwx,HXhRgxEZ4d2Dek,source,WypSQTO7504tHY)
			if E8Wnput30AyeSKq in [V2RQwM8XjlrK(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧṇ"),WCPwmyVsb62KRlo(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫṈ"),QYSAUI5r46yil8cfaO(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬṉ")]:
				sSucxbrN0KlUyEBPvTO712dmiC = YOHXqtbQTBfKerIZ
				break
			else:
				if not Q0WnJxCYdAINZk2tBjs5: Q0WnJxCYdAINZk2tBjs5 = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡩࡥ࡮ࡲࡥࡥࠩṊ")
				title = nMt0iueCy6K+title+ZZoLlKyInXc08j2pTGJ
				h0yYrdxVB28394WIvCZ[ufmXvxgoHGDwZtjsLkR05i] = title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Q0WnJxCYdAINZk2tBjs5,ss285HRGmwx,HXhRgxEZ4d2Dek,fJHXGS7YqL3kaR
				q3p4Y6nNbAw8I = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(SSBkx0WbN1asnDCQV6tIj(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧṋ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
				kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬṌ"),q3p4Y6nNbAw8I)
				FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,YzowicIDTRusXZSU61(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪṍ"),q3p4Y6nNbAw8I,[Q0WnJxCYdAINZk2tBjs5,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp],ddQIv6q9hTce1iA0nWSX5UuLaNb)
			if Q0WnJxCYdAINZk2tBjs5==QYSAUI5r46yil8cfaO(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧṎ"): break
			JYMEUgC4zb = WCPwmyVsb62KRlo(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬṏ")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,g7yJo2LVuqx1trPe(u"ࠫࡡࡴ࡛ࡍࡇࡉࡘࡢࠦࠠࠨṐ")) if Q0WnJxCYdAINZk2tBjs5.count(ixrPWKeFMnqJyVodX6D9AaO2)>WCPwmyVsb62KRlo(u"࠳൭") else ixrPWKeFMnqJyVodX6D9AaO2+Q0WnJxCYdAINZk2tBjs5
			if WXuJd8nz2spo146t(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ṑ") not in source: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṒ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้࡟ࡲࠬṓ")+JYMEUgC4zb,profile=MzgKWUQ4V5H(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭Ṕ"))
			if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==pwxH3oREFm5v98BCZ1QVtzMJOc and Q0WnJxCYdAINZk2tBjs5: break
		for W7SMIpbzhori2JE9mv in range(start,end+pwxH3oREFm5v98BCZ1QVtzMJOc):
			Ip03a9MdXD1UkJqyREefiY = ufmXvxgoHGDwZtjsLkR05i if Ly6dZ0zbaG2KugB9FQA else W7SMIpbzhori2JE9mv
			title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Q0WnJxCYdAINZk2tBjs5,ss285HRGmwx,HXhRgxEZ4d2Dek,fJHXGS7YqL3kaR = h0yYrdxVB28394WIvCZ[Ip03a9MdXD1UkJqyREefiY]
			nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv].replace(nMt0iueCy6K,Vk54F7GcROfCy6HunEI).replace(hh6BmGb5aUH,Vk54F7GcROfCy6HunEI).replace(XYvSoxmf0QGpbngZ,Vk54F7GcROfCy6HunEI).replace(ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI)
			if fJHXGS7YqL3kaR==FGLEMi21Bfn(u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪṕ"): nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = hh6BmGb5aUH+nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv]+ZZoLlKyInXc08j2pTGJ
			elif fJHXGS7YqL3kaR==cpHxZyU7vTtqmIw(u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫṖ"): nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = nMt0iueCy6K+nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv]+ZZoLlKyInXc08j2pTGJ
			else: nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv] = nWcb8JC7zEVouFjx9fILGh1vSQ[W7SMIpbzhori2JE9mv]
	if gJChoTzFUR2PYbGNnm18c6MvW==WXuJd8nz2spo146t(u"ࠫࡳࡵࡴࡠࡴࡨࡷࡴࡲࡶࡢࡤ࡯ࡩࠬṗ"): GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṘ"),wAU9jKvmTM0(u"࠭ไๅลึๅ๊ࠥวࠡ์๋ะิࠦำ๋ำไีฬะࠠอ์าอࠥ็๊้ࠡำหࠥอไโ์า๎ํࠦ࠮࠯ࠢะหํ๊ࠠฤ่ࠣฮอำหࠡ฻้ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎๋่ࠥศไ฼ࠤศิั๊ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠫṙ"))
	if not sSucxbrN0KlUyEBPvTO712dmiC or gJChoTzFUR2PYbGNnm18c6MvW in [g7yJo2LVuqx1trPe(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩṚ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩṛ")] or Q0WnJxCYdAINZk2tBjs5:
		yjsIKYfTL4vHnte3oa2h9 = J2L6to3R1Z.executeJSONRPC(ynxXU3gaiQ9GPCftr1q(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩṜ"))
	return
def iVdWLYs1AGFR0zPO6c3mZBwE(t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu,source,showDialogs):
	global tteBNPTyGoZm30npkazUwXs4fW,rHTqjowlmFdsu62SzJGCX9MtyK,VXmGCLJsz1HF8TygMRlKjqpS3koYO0,y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO,YYzda4xBQ8qD3PXwEoJt,xng34597UEKdv1WCyocT0
	tteBNPTyGoZm30npkazUwXs4fW,rHTqjowlmFdsu62SzJGCX9MtyK,VXmGCLJsz1HF8TygMRlKjqpS3koYO0,y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO,YYzda4xBQ8qD3PXwEoJt,xng34597UEKdv1WCyocT0 = [],[],[],[],[],[]
	w8YsNWfQ5gFluRvOmSd4Cb96H,an6Oz04soGKv9CUtmAP5ufHJ2y,new = [],[],[]
	igFtOzLBeQu(b8f2icUnEswC9Ja,b8f2icUnEswC9Ja,b8f2icUnEswC9Ja)
	count = len(MMJL8QqY6T7dv1onu)
	for l5jaqCcHr6PGJQSFgoKM0s in range(count):
		tteBNPTyGoZm30npkazUwXs4fW.append(tayEeSpKRJIdC8g10)
		rHTqjowlmFdsu62SzJGCX9MtyK.append(tayEeSpKRJIdC8g10)
		VXmGCLJsz1HF8TygMRlKjqpS3koYO0.append(tayEeSpKRJIdC8g10)
		y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO.append(tayEeSpKRJIdC8g10)
		YYzda4xBQ8qD3PXwEoJt.append(tayEeSpKRJIdC8g10)
		xng34597UEKdv1WCyocT0.append(ufmXvxgoHGDwZtjsLkR05i)
		title = t8tfMv1VXZYQ5y3[l5jaqCcHr6PGJQSFgoKM0s]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = MMJL8QqY6T7dv1onu[l5jaqCcHr6PGJQSFgoKM0s].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࠪࠬṝ")).strip(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡄ࠭Ṟ")).strip(pnkrd2S84FJfN73KuiCYv(u"ࠬ࠵ࠧṟ"))
		if count>pwxH3oREFm5v98BCZ1QVtzMJOc and showDialogs: qJAOp7HgfKeMQkDau(SSBkx0WbN1asnDCQV6tIj(u"࠭แฮืࠣื๏ืแาࠢิๆ๊ࠦࠠࠨṠ")+str(l5jaqCcHr6PGJQSFgoKM0s+SSBkx0WbN1asnDCQV6tIj(u"࠲൮")),title)
		lghSX7O3CMGZ15oURawN = [SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨṡ"),cpHxZyU7vTtqmIw(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭Ṣ"),WsklGNp2CYzVQUag(u"ࠩࡄࡏ࡜ࡇࡍࠨṣ")]
		if source in lghSX7O3CMGZ15oURawN: tteBNPTyGoZm30npkazUwXs4fW[l5jaqCcHr6PGJQSFgoKM0s] = L1LTzg72wsQP(title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,source,l5jaqCcHr6PGJQSFgoKM0s,YOHXqtbQTBfKerIZ)
		else:
			if pwxH3oREFm5v98BCZ1QVtzMJOc:
				Q1Z3pmscViRhIMTSvbDe = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=L1LTzg72wsQP,args=(title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,source,l5jaqCcHr6PGJQSFgoKM0s,count==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠳൯")))
				an6Oz04soGKv9CUtmAP5ufHJ2y.append(Q1Z3pmscViRhIMTSvbDe)
				new.append(l5jaqCcHr6PGJQSFgoKM0s)
	def lFaESUguGO0eKrW9Xx():
		S8qFckmG72duCn9pgb = eu1NswY9zkKC60I
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in tteBNPTyGoZm30npkazUwXs4fW:
			if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: break
		else: S8qFckmG72duCn9pgb = YOHXqtbQTBfKerIZ
		fS1J2Hvtmwc78DUy = J2L6to3R1Z.Player().isPlaying() if h9zFQKnsNL.resolveonly else YOHXqtbQTBfKerIZ
		return S8qFckmG72duCn9pgb or not fS1J2Hvtmwc78DUy
	yQXxP1eirFRKJ5gHbun(an6Oz04soGKv9CUtmAP5ufHJ2y,DjFy4Lsm3dqlzSOtWN,pt7CIKiU8PVBw194dkQEznq,pwxH3oREFm5v98BCZ1QVtzMJOc,lFaESUguGO0eKrW9Xx)
	for l5jaqCcHr6PGJQSFgoKM0s in range(count):
		title = t8tfMv1VXZYQ5y3[l5jaqCcHr6PGJQSFgoKM0s]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = MMJL8QqY6T7dv1onu[l5jaqCcHr6PGJQSFgoKM0s].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(wYTDlJC5vpOKynUEX3ge6W(u"ࠪࠪࠬṤ")).strip(MzgKWUQ4V5H(u"ࠫࡄ࠭ṥ")).strip(ESXZrtnCfcDJGo01vFg(u"ࠬ࠵ࠧṦ"))
		q3p4Y6nNbAw8I = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧṧ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i] if l5jaqCcHr6PGJQSFgoKM0s in new else eu1NswY9zkKC60I
		stream = tteBNPTyGoZm30npkazUwXs4fW[l5jaqCcHr6PGJQSFgoKM0s]
		if stream and not stream[ufmXvxgoHGDwZtjsLkR05i] and stream[RXnhpCUk4M1TvgJE]:
			fJHXGS7YqL3kaR = FGLEMi21Bfn(u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨṨ")
			JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ = stream
			if q3p4Y6nNbAw8I: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ṩ"),q3p4Y6nNbAw8I,[JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ],ddQIv6q9hTce1iA0nWSX5UuLaNb)
		elif stream and stream[ufmXvxgoHGDwZtjsLkR05i] and not stream[pwxH3oREFm5v98BCZ1QVtzMJOc] and not stream[RXnhpCUk4M1TvgJE]:
			fJHXGS7YqL3kaR = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪṪ")
			JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ = WCPwmyVsb62KRlo(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤ࡝ࡰࠪṫ")+stream[ufmXvxgoHGDwZtjsLkR05i],[],[]
			if q3p4Y6nNbAw8I: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,V2RQwM8XjlrK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭Ṭ"),q3p4Y6nNbAw8I,[JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ],ddQIv6q9hTce1iA0nWSX5UuLaNb)
		elif xng34597UEKdv1WCyocT0[l5jaqCcHr6PGJQSFgoKM0s]+pwxH3oREFm5v98BCZ1QVtzMJOc>LLFKptWI7nsuHOCTiGhd:
			fJHXGS7YqL3kaR = WXuJd8nz2spo146t(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ṭ")
			JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ = V2RQwM8XjlrK(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡹ࡯࡭ࡦࡦࠣࡳࡺࡺࠠࠩࠩṮ")+str(xng34597UEKdv1WCyocT0[l5jaqCcHr6PGJQSFgoKM0s])+MpJ8GOKoic(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪṯ"),[],[]
			if q3p4Y6nNbAw8I: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫṰ"),q3p4Y6nNbAw8I,[JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ],ddQIv6q9hTce1iA0nWSX5UuLaNb)
		elif not stream:
			fJHXGS7YqL3kaR = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡦࡥࡳࡩࡥ࡭ࠩṱ")
			JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠪṲ"),[],[]
			if q3p4Y6nNbAw8I: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,FGLEMi21Bfn(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧṳ"),q3p4Y6nNbAw8I,[JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ],ddQIv6q9hTce1iA0nWSX5UuLaNb)
		else:
			fJHXGS7YqL3kaR = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭Ṵ")
			JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ = WsklGNp2CYzVQUag(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡵࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ṵ"),[],[]
			if q3p4Y6nNbAw8I: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪṶ"),q3p4Y6nNbAw8I,[JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ],ddQIv6q9hTce1iA0nWSX5UuLaNb)
		w8YsNWfQ5gFluRvOmSd4Cb96H.append([title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,JYMEUgC4zb,esUNcDaPg3QoX,YBDKFZOGfyCHLPA1EaUz9MJ,fJHXGS7YqL3kaR])
	igFtOzLBeQu(I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB)
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def L1LTzg72wsQP(oOv4sVqEAmyM,url,source,J5rfz78qyAvt49aoVunbRE1hZG,aecBUkinHGEVQ6YohZLFgfKpt):
	global tteBNPTyGoZm30npkazUwXs4fW,xng34597UEKdv1WCyocT0
	xng34597UEKdv1WCyocT0[J5rfz78qyAvt49aoVunbRE1hZG] = ufmXvxgoHGDwZtjsLkR05i
	TT7ytNUaAEzleV2oMR9j3 = Gb6kwVlSQ4MU.time()
	iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+MpJ8GOKoic(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩṷ")+oOv4sVqEAmyM+WsklGNp2CYzVQUag(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ṹ")+url+MzgKWUQ4V5H(u"ࠪࠤࡢ࠭ṹ"))
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp,aQMrk68ODs = url,Vk54F7GcROfCy6HunEI
	mObvJPH4QKjaSA58gy7VhkCr = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨṺ")
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Ui7YL0cIb9HpxmGQlgRES8ko(url,source)
	if Q0WnJxCYdAINZk2tBjs5==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪṻ"):
		tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = cpHxZyU7vTtqmIw(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫṼ"),[],[]
		xng34597UEKdv1WCyocT0[J5rfz78qyAvt49aoVunbRE1hZG] = Gb6kwVlSQ4MU.time()-TT7ytNUaAEzleV2oMR9j3
		return tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG]
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪṽ") in Q0WnJxCYdAINZk2tBjs5:
		aQMrk68ODs = wAU9jKvmTM0(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥ࠮࠲࠮࠷ࠬࠫṾ")
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)[ufmXvxgoHGDwZtjsLkR05i]
		mObvJPH4QKjaSA58gy7VhkCr,aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Gh0g3H6tpWjNrnZeP5AcV9QwyEK(aQMrk68ODs,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,source,J5rfz78qyAvt49aoVunbRE1hZG)
		if aQMrk68ODs==WsklGNp2CYzVQUag(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧṿ"):
			tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
			xng34597UEKdv1WCyocT0[J5rfz78qyAvt49aoVunbRE1hZG] = Gb6kwVlSQ4MU.time()-TT7ytNUaAEzleV2oMR9j3
			return aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	elif Q0WnJxCYdAINZk2tBjs5: aQMrk68ODs = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪẀ")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)[:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠻࠴൰")]
	if yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
		iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+QYSAUI5r46yil8cfaO(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧẁ")+oOv4sVqEAmyM+wAU9jKvmTM0(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩẂ")+mObvJPH4QKjaSA58gy7VhkCr+QYSAUI5r46yil8cfaO(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪẃ")+url+YzowicIDTRusXZSU61(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧẄ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+g7yJo2LVuqx1trPe(u"ࠨࠢࡠࠤ࡙ࠥࠦࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭ẅ")+str(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࠣࡡࠬẆ"))
	else:
		L40rnClKSBdEvZHDwkQ = ESXZrtnCfcDJGo01vFg(u"ࠪࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪẇ")+aQMrk68ODs+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࠥࡣࠧẈ") if aecBUkinHGEVQ6YohZLFgfKpt else Vk54F7GcROfCy6HunEI
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+MzgKWUQ4V5H(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬẉ")+oOv4sVqEAmyM+SSBkx0WbN1asnDCQV6tIj(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪẊ")+url+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧẋ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࠢࡠࠫẌ")+L40rnClKSBdEvZHDwkQ)
	aQMrk68ODs = ZlBMJUAWRm9buv(aQMrk68ODs)
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	xng34597UEKdv1WCyocT0[J5rfz78qyAvt49aoVunbRE1hZG] = Gb6kwVlSQ4MU.time()-TT7ytNUaAEzleV2oMR9j3
	return aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def e6xvkAHalPYZ(title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,source,WypSQTO7504tHY=Vk54F7GcROfCy6HunEI):
	if yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		if not nWcb8JC7zEVouFjx9fILGh1vSQ[ufmXvxgoHGDwZtjsLkR05i]: nWcb8JC7zEVouFjx9fILGh1vSQ = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
		PSo6Hynm5cdOBMzL = cad8TeSyMUYmfsEO0.getSetting(WCPwmyVsb62KRlo(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ẍ"))
		tfWzFSja2yr = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࠱ࠬẎ") not in PSo6Hynm5cdOBMzL
		while YOHXqtbQTBfKerIZ:
			if tfWzFSja2yr and len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==pwxH3oREFm5v98BCZ1QVtzMJOc: qreJEpY8nZguD = ufmXvxgoHGDwZtjsLkR05i
			else: qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(MzgKWUQ4V5H(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪẏ"),nWcb8JC7zEVouFjx9fILGh1vSQ)
			if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: MmPd59qzTto3eGuvrJNL = MzgKWUQ4V5H(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧẐ")
			else:
				ZZPgLz0iE93myTJCkSUYwDuQ4 = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
				iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+QYSAUI5r46yil8cfaO(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬẑ")+title+Nlyfx1HnzOWCovke5(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫẒ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+cpHxZyU7vTtqmIw(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩẓ")+str(ZZPgLz0iE93myTJCkSUYwDuQ4)+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࠣࡡࠬẔ"))
				if WCPwmyVsb62KRlo(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭ẕ") in ZZPgLz0iE93myTJCkSUYwDuQ4 and kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫẖ") in ZZPgLz0iE93myTJCkSUYwDuQ4:
					JYMEUgC4zb,TQjudoNYcPJr5,v6eOQW0xrkL = al82YzMuUrXhfHBLVojgRI(ZZPgLz0iE93myTJCkSUYwDuQ4)
					if v6eOQW0xrkL: ZZPgLz0iE93myTJCkSUYwDuQ4 = v6eOQW0xrkL[ufmXvxgoHGDwZtjsLkR05i]
					else: ZZPgLz0iE93myTJCkSUYwDuQ4 = Vk54F7GcROfCy6HunEI
				if not ZZPgLz0iE93myTJCkSUYwDuQ4: MmPd59qzTto3eGuvrJNL = g7yJo2LVuqx1trPe(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩẗ")
				else: MmPd59qzTto3eGuvrJNL = qnUlyF2JXuGYdSA6Iac1(ZZPgLz0iE93myTJCkSUYwDuQ4,source,WypSQTO7504tHY)
			if MmPd59qzTto3eGuvrJNL in [kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧẘ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨẙ"),YzowicIDTRusXZSU61(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ẚ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫẛ")] or len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==SSBkx0WbN1asnDCQV6tIj(u"࠵൱"): break
			elif MmPd59qzTto3eGuvrJNL in [ynxXU3gaiQ9GPCftr1q(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪẜ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬẝ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡺࡲࡪࡧࡧࠫẞ")]: break
			else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẟ"),jXWzIZcDva4ikEUfN(u"ࠧศๆ่่ๆࠦไๆࠢํ฽๊๊ࠠอำหࠤ๊๊แࠡ฼ํี์࠭Ạ"))
	else:
		MmPd59qzTto3eGuvrJNL = ESXZrtnCfcDJGo01vFg(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬạ")
		if fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp): MmPd59qzTto3eGuvrJNL = qnUlyF2JXuGYdSA6Iac1(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,source,WypSQTO7504tHY)
	return MmPd59qzTto3eGuvrJNL,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def aCjhDALkinFlTGX91uYdo0pRe(url,source):
	hj50MJnoOp6ZWaS1IQ8Elr,oCISNjhp09Piqad65w8FBvMbWlu,oOv4sVqEAmyM,NR6mKH5ijyQWV70Fnbvdlh9,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB = url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪẢ") in url:
		hj50MJnoOp6ZWaS1IQ8Elr,oCISNjhp09Piqad65w8FBvMbWlu = url.split(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫả"),pwxH3oREFm5v98BCZ1QVtzMJOc)
		oCISNjhp09Piqad65w8FBvMbWlu = oCISNjhp09Piqad65w8FBvMbWlu+pnkrd2S84FJfN73KuiCYv(u"ࠫࡤࡥࠧẤ")+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡥ࡟ࠨấ")+BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡟ࡠࠩẦ")+XCYALgFs2O3hZdpHrlMmB(u"ࠧࡠࡡࠪầ")+WsklGNp2CYzVQUag(u"ࠨࡡࡢࠫẨ")
		EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB,tW8xaRsY0I25Sruv3wog4zJqO, = oCISNjhp09Piqad65w8FBvMbWlu.split(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡢࡣࠬẩ"))[:WXuJd8nz2spo146t(u"࠻൲")]
	if not jMiru3pGns: jMiru3pGns = ESXZrtnCfcDJGo01vFg(u"ࠪ࠴ࠬẪ")
	else: jMiru3pGns = jMiru3pGns.replace(FGLEMi21Bfn(u"ࠫࡵ࠭ẫ"),Vk54F7GcROfCy6HunEI).replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,Vk54F7GcROfCy6HunEI)
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.strip(ESXZrtnCfcDJGo01vFg(u"ࠬࡅࠧẬ")).strip(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠯ࠨậ")).strip(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࠧࠩẮ"))
	oOv4sVqEAmyM = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡪࡲࡷࡹ࠭ắ"))
	if EDy0Rs9liwjZvJY: NR6mKH5ijyQWV70Fnbvdlh9 = EDy0Rs9liwjZvJY
	else: NR6mKH5ijyQWV70Fnbvdlh9 = oOv4sVqEAmyM
	NR6mKH5ijyQWV70Fnbvdlh9 = RRav1Sf7Px(NR6mKH5ijyQWV70Fnbvdlh9,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡱࡥࡲ࡫ࠧẰ"))
	EDy0Rs9liwjZvJY = EDy0Rs9liwjZvJY.replace(WsklGNp2CYzVQUag(u"้ࠪออิาࠩằ"),Vk54F7GcROfCy6HunEI).replace(WXuJd8nz2spo146t(u"ุࠫ๐ัโำࠪẲ"),Vk54F7GcROfCy6HunEI).replace(XCYALgFs2O3hZdpHrlMmB(u"ࠬอไࠡࠩẳ"),otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	oCISNjhp09Piqad65w8FBvMbWlu = oCISNjhp09Piqad65w8FBvMbWlu.replace(WXuJd8nz2spo146t(u"࠭ๅษษืีࠬẴ"),Vk54F7GcROfCy6HunEI).replace(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧิ์ิๅึ࠭ẵ"),Vk54F7GcROfCy6HunEI).replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨษ็ࠤࠬẶ"),otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	NR6mKH5ijyQWV70Fnbvdlh9 = NR6mKH5ijyQWV70Fnbvdlh9.replace(wYTDlJC5vpOKynUEX3ge6W(u"่ࠩฬฬฺัࠨặ"),Vk54F7GcROfCy6HunEI).replace(ESXZrtnCfcDJGo01vFg(u"ࠪื๏ืแาࠩẸ"),Vk54F7GcROfCy6HunEI).replace(FGLEMi21Bfn(u"ࠫฬ๊ࠠࠨẹ"),otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	return hj50MJnoOp6ZWaS1IQ8Elr,oCISNjhp09Piqad65w8FBvMbWlu,oOv4sVqEAmyM,NR6mKH5ijyQWV70Fnbvdlh9,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB
def gdDM3UcWBC8Rt45IEh26N9n0HkF7T(url,source):
	tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,ewGlmFf52ByKobU,MR0bs43yVJmq86Zg,H4eBdShuY31,XLg5UfRh6nBubWC7eK,mObvJPH4QKjaSA58gy7VhkCr = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10
	hj50MJnoOp6ZWaS1IQ8Elr,oCISNjhp09Piqad65w8FBvMbWlu,oOv4sVqEAmyM,NR6mKH5ijyQWV70Fnbvdlh9,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB = aCjhDALkinFlTGX91uYdo0pRe(url,source)
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ẻ") in url:
		if   WypSQTO7504tHY==XCYALgFs2O3hZdpHrlMmB(u"࠭ࡥ࡮ࡤࡨࡨࠬẻ"): WypSQTO7504tHY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧๆใู่ࠬẼ")
		elif WypSQTO7504tHY==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡹࡤࡸࡨ࡮ࠧẽ"): WypSQTO7504tHY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࠨู้อ็ะหࠪẾ")
		elif WypSQTO7504tHY==WsklGNp2CYzVQUag(u"ࠪࡦࡴࡺࡨࠨế"): WypSQTO7504tHY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+WXuJd8nz2spo146t(u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭Ề")
		elif WypSQTO7504tHY==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧề"): WypSQTO7504tHY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jXWzIZcDva4ikEUfN(u"࠭ࠥࠦࠧอั๊๐ไࠨỂ")
		elif WypSQTO7504tHY==Vk54F7GcROfCy6HunEI: WypSQTO7504tHY = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࠦࠧࠨࠩࠬể")
		if k2kRdMUp0qmI9Hrv!=Vk54F7GcROfCy6HunEI:
			if eAMGzHRQVs2KyCwPXljYhB(u"ࠨ࡯ࡳ࠸ࠬỄ") not in k2kRdMUp0qmI9Hrv: k2kRdMUp0qmI9Hrv = jXWzIZcDva4ikEUfN(u"ࠩࠨࠫễ")+k2kRdMUp0qmI9Hrv
			k2kRdMUp0qmI9Hrv = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+k2kRdMUp0qmI9Hrv
		if jMiru3pGns!=Vk54F7GcROfCy6HunEI:
			jMiru3pGns = V2RQwM8XjlrK(u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭Ệ")+jMiru3pGns
			jMiru3pGns = otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jMiru3pGns[-kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠿൳"):]
	if   QYSAUI5r46yil8cfaO(u"ࠫࡆࡑࡏࡂࡏࠪệ")		in source: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MzgKWUQ4V5H(u"ࠬࡇࡋࡘࡃࡐࠫỈ")		in source: ewGlmFf52ByKobU	= ESXZrtnCfcDJGo01vFg(u"࠭ࡡ࡬ࡹࡤࡱࠬỉ")
	elif WsklGNp2CYzVQUag(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩỊ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧị")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫỌ")		in source: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡥࡱࡧࡲࡢࡤࠪọ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif jXWzIZcDva4ikEUfN(u"ࠫ࡫ࡧࡳࡦ࡮ࠪỎ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡺ࠷࡮ࡧࡨࡰࠬỏ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif ESXZrtnCfcDJGo01vFg(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭Ố")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩố")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MpJ8GOKoic(u"ࠨࡨࡤ࡮ࡪࡸࠧỒ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩไะึ࠭ồ")			in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡪࡦࡰࡥࡳࠩỔ")
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫๆ๊ำุ์้ࠫổ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= ESXZrtnCfcDJGo01vFg(u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨỖ")
	elif EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭ỗ")		in hj50MJnoOp6ZWaS1IQ8Elr:   ewGlmFf52ByKobU	= wAU9jKvmTM0(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧỘ")
	elif YzowicIDTRusXZSU61(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨộ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MpJ8GOKoic(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩỚ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫớ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬỜ")		in EDy0Rs9liwjZvJY:   ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif ynxXU3gaiQ9GPCftr1q(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪờ")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡢࡰ࡭ࡵࡥࠬỞ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠧࡵࡸࡩࡹࡳ࠭ở")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠨࡶࡹ࡯ࡸࡧࠧỠ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif V2RQwM8XjlrK(u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪỡ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif jXWzIZcDva4ikEUfN(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬỢ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif jXWzIZcDva4ikEUfN(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ợ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif WsklGNp2CYzVQUag(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧỤ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭ụ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif WXuJd8nz2spo146t(u"ࠧࡦࡩࡼࡲࡴࡽࠧỦ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif WXuJd8nz2spo146t(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪủ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MzgKWUQ4V5H(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫỨ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡶࡪࡪ࡭ࡰࡦࡻࠫứ")	 	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= jXWzIZcDva4ikEUfN(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬỪ")
	elif MzgKWUQ4V5H(u"ࠬࡿ࡯ࡶࡶࡸࠫừ")	 	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧỬ")
	elif MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧử")	 	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= YzowicIDTRusXZSU61(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩỮ")
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨữ")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= NR6mKH5ijyQWV70Fnbvdlh9
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨỰ")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= WXuJd8nz2spo146t(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨự")
	elif SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧỲ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨỳ")
	elif WCPwmyVsb62KRlo(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨỴ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪỵ")
	elif g7yJo2LVuqx1trPe(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫỶ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= YzowicIDTRusXZSU61(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬỷ")
	elif ynxXU3gaiQ9GPCftr1q(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪỸ")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= cpHxZyU7vTtqmIw(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫỹ")
	elif ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩỺ")	in oOv4sVqEAmyM: ewGlmFf52ByKobU	= MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡪࡰࡩࡰࡦࡳࠧỻ")
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩỼ")		in oOv4sVqEAmyM: ewGlmFf52ByKobU	= QYSAUI5r46yil8cfaO(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪỽ")
	elif BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭Ỿ")	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧỿ")
	elif HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭ἀ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧἁ")
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩἂ")	 	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡥࡤࡸࡨ࡮ࠧἃ")
	elif ynxXU3gaiQ9GPCftr1q(u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪἄ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= g7yJo2LVuqx1trPe(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫἅ")
	elif MpJ8GOKoic(u"ࠫࡻ࡯ࡤࡣ࡯ࠪἆ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= SSBkx0WbN1asnDCQV6tIj(u"ࠬࡼࡩࡥࡤࡰࠫἇ")
	elif MzgKWUQ4V5H(u"࠭ࡶࡪࡦ࡫ࡨࠬἈ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧ࡮ࡻࡹ࡭ࡩ࠭Ἁ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif WsklGNp2CYzVQUag(u"ࠨ࡯ࡼࡺ࡮࡯ࡤࠨἊ")		in oOv4sVqEAmyM: XLg5UfRh6nBubWC7eK	= NR6mKH5ijyQWV70Fnbvdlh9
	elif WCPwmyVsb62KRlo(u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫἋ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬἌ")
	elif SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫ࡬ࡵࡶࡪࡦࠪἍ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬ࡭࡯ࡷ࡫ࡧࠫἎ")
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨἏ") 	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= pnkrd2S84FJfN73KuiCYv(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩἐ")
	elif ESXZrtnCfcDJGo01vFg(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫἑ")	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬἒ")
	elif EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨἓ")	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩἔ")
	elif SSBkx0WbN1asnDCQV6tIj(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩἕ") 	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ἖")
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ἗")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= QYSAUI5r46yil8cfaO(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩἘ")
	elif ESXZrtnCfcDJGo01vFg(u"ࠩࡸࡴࡵ࠭Ἑ") 			in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡹࡵࡨ࡯࡮ࠩἚ")
	elif WsklGNp2CYzVQUag(u"ࠫࡺࡶࡢࠨἛ") 			in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= YzowicIDTRusXZSU61(u"ࠬࡻࡰࡣࡱࡰࠫἜ")
	elif EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭Ἕ") 		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= ESXZrtnCfcDJGo01vFg(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ἞")
	elif wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡸ࡮ࠫ἟") 			in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡹ࡯ࠬἠ")
	elif WXuJd8nz2spo146t(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬἡ") 	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ἢ")
	elif XCYALgFs2O3hZdpHrlMmB(u"ࠬࡼࡩࡥࡤࡲࡦࠬἣ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= WsklGNp2CYzVQUag(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ἤ")
	elif ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧἥ") 		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= WsklGNp2CYzVQUag(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨἦ")
	elif g7yJo2LVuqx1trPe(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ἧ") 	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= pnkrd2S84FJfN73KuiCYv(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧἨ")
	elif WCPwmyVsb62KRlo(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨἩ")	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= Nlyfx1HnzOWCovke5(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩἪ")
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪἫ")	in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫἬ")
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨἭ")		in oOv4sVqEAmyM: MR0bs43yVJmq86Zg	= FGLEMi21Bfn(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩἮ")
	if   ewGlmFf52ByKobU:	tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = WsklGNp2CYzVQUag(u"ࠪาฬ฻ࠧἯ"),ewGlmFf52ByKobU
	elif XLg5UfRh6nBubWC7eK:		tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = QYSAUI5r46yil8cfaO(u"๋ࠫࠪอะัࠪἰ"),XLg5UfRh6nBubWC7eK
	elif MR0bs43yVJmq86Zg:		tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = YzowicIDTRusXZSU61(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪἱ"),MR0bs43yVJmq86Zg
	elif H4eBdShuY31:	tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬἲ"),H4eBdShuY31
	elif mObvJPH4QKjaSA58gy7VhkCr:	tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧἳ"),NR6mKH5ijyQWV70Fnbvdlh9
	else:			tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY = YzowicIDTRusXZSU61(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩἴ"),NR6mKH5ijyQWV70Fnbvdlh9
	return tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns
def XXDnoGaNpuWsK(Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9):
	ss285HRGmwx,HXhRgxEZ4d2Dek = [],[]
	for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in list(zip(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)):
		if fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
			ss285HRGmwx.append(title)
			HXhRgxEZ4d2Dek.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if not HXhRgxEZ4d2Dek and not Q0WnJxCYdAINZk2tBjs5: Q0WnJxCYdAINZk2tBjs5 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡉࡥ࡮ࡲࡥࡥࠩἵ")
	return Q0WnJxCYdAINZk2tBjs5,ss285HRGmwx,HXhRgxEZ4d2Dek
def Ui7YL0cIb9HpxmGQlgRES8ko(url,source):
	hj50MJnoOp6ZWaS1IQ8Elr,XLg5UfRh6nBubWC7eK,oOv4sVqEAmyM,NR6mKH5ijyQWV70Fnbvdlh9,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB = aCjhDALkinFlTGX91uYdo0pRe(url,source)
	if   ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡽࡴࡻࡴࡶࠩἶ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧἷ"),[Vk54F7GcROfCy6HunEI],[url]
	elif V2RQwM8XjlrK(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬἸ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἹ"),[Vk54F7GcROfCy6HunEI],[url]
	elif V2RQwM8XjlrK(u"ࠧࡢ࡮ࡥࡥࡵࡲࡡࡺࡧࡵࠫἺ")	in hj50MJnoOp6ZWaS1IQ8Elr  : Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = BDHby2pEuQ4K8(hj50MJnoOp6ZWaS1IQ8Elr)
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࡯ࡨ࡫ࡦࡳࡡࡹࠩἻ")		in hj50MJnoOp6ZWaS1IQ8Elr  : Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = XaBikMpvOqAU9yIQV3Y4mGdtfKWu(hj50MJnoOp6ZWaS1IQ8Elr)
	elif MpJ8GOKoic(u"ࠩࡄࡏࡔࡇࡍࠨἼ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = cU2pfFhDjH(hj50MJnoOp6ZWaS1IQ8Elr,EDy0Rs9liwjZvJY)
	elif WCPwmyVsb62KRlo(u"ࠪࡅࡐ࡝ࡁࡎࠩἽ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = KIO4XePNEd(hj50MJnoOp6ZWaS1IQ8Elr,WypSQTO7504tHY,jMiru3pGns)
	elif wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭Ἶ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = QBUiYm6CtO(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ESXZrtnCfcDJGo01vFg(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭Ἷ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = MpJ8GOKoic(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩὀ"),[Vk54F7GcROfCy6HunEI],[url]
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧὁ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = KpTdiYPncX(hj50MJnoOp6ZWaS1IQ8Elr)
	elif wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪὂ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = KVS3Zj7peQ(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫὃ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = fsHGYLNI5R(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WCPwmyVsb62KRlo(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬὄ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Mis0W8Q4a7(hj50MJnoOp6ZWaS1IQ8Elr)
	elif g7yJo2LVuqx1trPe(u"ࠫࡘࡎࡏࡇࡊࡄࠫὅ")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jZnLR47tB5(hj50MJnoOp6ZWaS1IQ8Elr)
	elif SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ὆")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = QQzUvhZY8P(hj50MJnoOp6ZWaS1IQ8Elr,yCJq05F7M4TB)
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭὇")		in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = llhCVaYrkN(hj50MJnoOp6ZWaS1IQ8Elr)
	elif MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫὈ")	in source: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = xWmilpNGzf(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WsklGNp2CYzVQUag(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪὉ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ddeNSF5fca(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WCPwmyVsb62KRlo(u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬὊ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = JfhGnxkT0C(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WsklGNp2CYzVQUag(u"ࠪࡥࡱࡧࡲࡢࡤࠪὋ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = wMvjk9tOmEbGc(hj50MJnoOp6ZWaS1IQ8Elr)
	elif g7yJo2LVuqx1trPe(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭Ὄ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = RTvsb4O16t(hj50MJnoOp6ZWaS1IQ8Elr)
	elif BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧὍ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = RTvsb4O16t(hj50MJnoOp6ZWaS1IQ8Elr)
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡥࡨࡻࡱࡳࡼ࠭὎")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = MhGoTmEkg2(hj50MJnoOp6ZWaS1IQ8Elr)
	elif pnkrd2S84FJfN73KuiCYv(u"ࠧࡵࡸࡩࡹࡳ࠭὏")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = YNmJdaRLhM(hj50MJnoOp6ZWaS1IQ8Elr)
	elif cpHxZyU7vTtqmIw(u"ࠨࡶࡹ࡯ࡸࡧࠧὐ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = YNmJdaRLhM(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫὑ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = YNmJdaRLhM(hj50MJnoOp6ZWaS1IQ8Elr)
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬὒ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ahFMwSmWVy(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WsklGNp2CYzVQUag(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ὓ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = S5SGI6cZW1(hj50MJnoOp6ZWaS1IQ8Elr)
	elif YzowicIDTRusXZSU61(u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧὔ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ZWvcm6Tos3d2GEiw1DqJnKNCYa(hj50MJnoOp6ZWaS1IQ8Elr)
	elif YzowicIDTRusXZSU61(u"࠭ࡶࡴ࠶ࡸࠫὕ")			in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = XXbVGhg7yo(hj50MJnoOp6ZWaS1IQ8Elr)
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡧࡣ࡭ࡩࡷ࠭ὖ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = lUdgLk0izX(hj50MJnoOp6ZWaS1IQ8Elr)
	elif HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩὗ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = rm87i5wn64(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WXuJd8nz2spo146t(u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪ὘")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = rm87i5wn64(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WCPwmyVsb62KRlo(u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧὙ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Z89L0fSra1(hj50MJnoOp6ZWaS1IQ8Elr)
	elif MzgKWUQ4V5H(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ὚")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Z89L0fSra1(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WsklGNp2CYzVQUag(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬὛ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = oCAyOMBasc(hj50MJnoOp6ZWaS1IQ8Elr)
	elif cpHxZyU7vTtqmIw(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭὜")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = kSiFC7Tna0mw(hj50MJnoOp6ZWaS1IQ8Elr)
	elif WsklGNp2CYzVQUag(u"ࠧࡣࡱ࡮ࡶࡦ࠭Ὕ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = eeJOLScAxm(hj50MJnoOp6ZWaS1IQ8Elr)
	elif wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭὞")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = sjqwv4CVyB(hj50MJnoOp6ZWaS1IQ8Elr)
	elif SSBkx0WbN1asnDCQV6tIj(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫὟ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = UlyBdnX14x(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩὠ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = tSvc6xpWlE(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ynxXU3gaiQ9GPCftr1q(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩὡ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	elif g7yJo2LVuqx1trPe(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ὢ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = TICq46Es3M(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬὣ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = vvkMu57igz(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡶࡲࡥࡥࡲ࠭ὤ") 		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	else: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = wAU9jKvmTM0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫὥ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	if not Q0WnJxCYdAINZk2tBjs5 and not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: Q0WnJxCYdAINZk2tBjs5 = WCPwmyVsb62KRlo(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲ࠢࡉࡥ࡮ࡲࡵࡳࡧࠪὦ")
	elif Q0WnJxCYdAINZk2tBjs5 not in [Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨὧ"),WCPwmyVsb62KRlo(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧὨ")]: Q0WnJxCYdAINZk2tBjs5 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨὩ")+Q0WnJxCYdAINZk2tBjs5
	return Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def Gh0g3H6tpWjNrnZeP5AcV9QwyEK(aQMrk68ODs,url,source,J5rfz78qyAvt49aoVunbRE1hZG):
	global tteBNPTyGoZm30npkazUwXs4fW,rHTqjowlmFdsu62SzJGCX9MtyK,VXmGCLJsz1HF8TygMRlKjqpS3koYO0,y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO,YYzda4xBQ8qD3PXwEoJt
	tYoTg4yBzC9DeG7Rivq = []
	for mObvJPH4QKjaSA58gy7VhkCr in [rHTqjowlmFdsu62SzJGCX9MtyK,VXmGCLJsz1HF8TygMRlKjqpS3koYO0,y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO,YYzda4xBQ8qD3PXwEoJt]: mObvJPH4QKjaSA58gy7VhkCr[J5rfz78qyAvt49aoVunbRE1hZG] = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧὪ"),[],[]
	qpzHxgSefDR,gNmvFEVAdMUX6Wbt3ic = [KK5yJcP4CIHuG,O0TG92kwtaR4s,tt8zGbsyp1ievNS53Y4lofRMKJ,HAGXu71gL0D],[]
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡧࡴࡧࡰࠬὫ") in url: qpzHxgSefDR,gNmvFEVAdMUX6Wbt3ic = [KK5yJcP4CIHuG,O0TG92kwtaR4s,HAGXu71gL0D],[y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO]
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩὬ") in url: qpzHxgSefDR,gNmvFEVAdMUX6Wbt3ic = [KK5yJcP4CIHuG],[VXmGCLJsz1HF8TygMRlKjqpS3koYO0,y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO,YYzda4xBQ8qD3PXwEoJt]
	for mObvJPH4QKjaSA58gy7VhkCr in gNmvFEVAdMUX6Wbt3ic: mObvJPH4QKjaSA58gy7VhkCr[J5rfz78qyAvt49aoVunbRE1hZG] = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡖ࡯࡮ࡶࡰࡦࡦࠪὭ"),[],[]
	for mObvJPH4QKjaSA58gy7VhkCr in qpzHxgSefDR:
		EHfJ9Y4jehi8ScrmU5 = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=mObvJPH4QKjaSA58gy7VhkCr,args=(url,source,J5rfz78qyAvt49aoVunbRE1hZG))
		tYoTg4yBzC9DeG7Rivq.append(EHfJ9Y4jehi8ScrmU5)
	def XT2GIzA87x30VyvinajBf1JCrlu():
		YNEjtVdezWXC,St8uyM6sOUHCWDG2B,Oj06Wm4cwoZEHRPku8Yq,WWybLYVnI5K327qU4m6 = eu1NswY9zkKC60I,eu1NswY9zkKC60I,eu1NswY9zkKC60I,eu1NswY9zkKC60I
		hGo3BNKeAjHOITFpErYc0PxusWb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = rHTqjowlmFdsu62SzJGCX9MtyK[J5rfz78qyAvt49aoVunbRE1hZG]
		if (ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not hGo3BNKeAjHOITFpErYc0PxusWb) or (hGo3BNKeAjHOITFpErYc0PxusWb and hGo3BNKeAjHOITFpErYc0PxusWb!=SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫὮ")): YNEjtVdezWXC = YOHXqtbQTBfKerIZ
		hGo3BNKeAjHOITFpErYc0PxusWb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = VXmGCLJsz1HF8TygMRlKjqpS3koYO0[J5rfz78qyAvt49aoVunbRE1hZG]
		if (ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not hGo3BNKeAjHOITFpErYc0PxusWb) or (hGo3BNKeAjHOITFpErYc0PxusWb and hGo3BNKeAjHOITFpErYc0PxusWb!=ynxXU3gaiQ9GPCftr1q(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬὯ")): St8uyM6sOUHCWDG2B = YOHXqtbQTBfKerIZ
		hGo3BNKeAjHOITFpErYc0PxusWb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO[J5rfz78qyAvt49aoVunbRE1hZG]
		if (ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not hGo3BNKeAjHOITFpErYc0PxusWb) or (hGo3BNKeAjHOITFpErYc0PxusWb and hGo3BNKeAjHOITFpErYc0PxusWb!=l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ὰ")): Oj06Wm4cwoZEHRPku8Yq = YOHXqtbQTBfKerIZ
		hGo3BNKeAjHOITFpErYc0PxusWb,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = YYzda4xBQ8qD3PXwEoJt[J5rfz78qyAvt49aoVunbRE1hZG]
		if (ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not hGo3BNKeAjHOITFpErYc0PxusWb) or (hGo3BNKeAjHOITFpErYc0PxusWb and hGo3BNKeAjHOITFpErYc0PxusWb!=WXuJd8nz2spo146t(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧά")): WWybLYVnI5K327qU4m6 = YOHXqtbQTBfKerIZ
		S8qFckmG72duCn9pgb = all([YNEjtVdezWXC,St8uyM6sOUHCWDG2B,Oj06Wm4cwoZEHRPku8Yq,WWybLYVnI5K327qU4m6])
		fS1J2Hvtmwc78DUy = J2L6to3R1Z.Player().isPlaying() if h9zFQKnsNL.resolveonly else YOHXqtbQTBfKerIZ
		return S8qFckmG72duCn9pgb or not fS1J2Hvtmwc78DUy
	yQXxP1eirFRKJ5gHbun(tYoTg4yBzC9DeG7Rivq,LLFKptWI7nsuHOCTiGhd,pt7CIKiU8PVBw194dkQEznq,pwxH3oREFm5v98BCZ1QVtzMJOc,XT2GIzA87x30VyvinajBf1JCrlu)
	succeeded = QYSAUI5r46yil8cfaO(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭ὲ")
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = rHTqjowlmFdsu62SzJGCX9MtyK[J5rfz78qyAvt49aoVunbRE1hZG]
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	if Q0WnJxCYdAINZk2tBjs5==WsklGNp2CYzVQUag(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭έ") or yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return succeeded,Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	aQMrk68ODs += Nlyfx1HnzOWCovke5(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠣࠫὴ")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)[:WCPwmyVsb62KRlo(u"࠸࠱൴")]
	succeeded = g7yJo2LVuqx1trPe(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩή")
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = VXmGCLJsz1HF8TygMRlKjqpS3koYO0[J5rfz78qyAvt49aoVunbRE1hZG]
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	if Q0WnJxCYdAINZk2tBjs5==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩὶ") or yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return succeeded,Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	aQMrk68ODs += HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧί")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)[:MzgKWUQ4V5H(u"࠹࠲൵")]
	succeeded = WCPwmyVsb62KRlo(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠬὸ")
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO[J5rfz78qyAvt49aoVunbRE1hZG]
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	if Q0WnJxCYdAINZk2tBjs5==wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬό") or yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return succeeded,Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	aQMrk68ODs += WCPwmyVsb62KRlo(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠺࠺ࠡࠢࠪὺ")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)[:EM6qpnCBYQGA9kbgDVLfrP(u"࠺࠳൶")]
	succeeded = WCPwmyVsb62KRlo(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨύ")
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = YYzda4xBQ8qD3PXwEoJt[J5rfz78qyAvt49aoVunbRE1hZG]
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = jJRLWq70UtVpfAwN8E(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	if Q0WnJxCYdAINZk2tBjs5==wAU9jKvmTM0(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨὼ") or yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return succeeded,Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	aQMrk68ODs += EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠷࠽ࠤࠥ࠭ώ")+Q0WnJxCYdAINZk2tBjs5.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)[:QYSAUI5r46yil8cfaO(u"࠻࠴൷")]
	tteBNPTyGoZm30npkazUwXs4fW[J5rfz78qyAvt49aoVunbRE1hZG] = aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	return succeeded,aQMrk68ODs,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def KK5yJcP4CIHuG(url,source,J5rfz78qyAvt49aoVunbRE1hZG):
	hj50MJnoOp6ZWaS1IQ8Elr,XLg5UfRh6nBubWC7eK,oOv4sVqEAmyM,NR6mKH5ijyQWV70Fnbvdlh9,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,yCJq05F7M4TB = aCjhDALkinFlTGX91uYdo0pRe(url,source)
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	if XCYALgFs2O3hZdpHrlMmB(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ὾")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = sjqwv4CVyB(url)
	elif wAU9jKvmTM0(u"࠭ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࠬ὿") in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = dDnCJ0pPsHGrI(url)
	elif SSBkx0WbN1asnDCQV6tIj(u"ࠧࡺࡱࡸࡸࡺ࠭ᾀ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = PEIoQ5fW1JN3S0OgnDhYlK8xqX(url)
	elif kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨᾁ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = PEIoQ5fW1JN3S0OgnDhYlK8xqX(url)
	elif V2RQwM8XjlrK(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨᾂ")	in url   : Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = NlU80V7efqA5hyQjbKHEv1d(url)
	elif QYSAUI5r46yil8cfaO(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬᾃ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = al82YzMuUrXhfHBLVojgRI(url)
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨࠬᾄ")		in url   : Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = QBUiYm6CtO(url)
	elif kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨᾅ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = qPwySnJRkGuX3hQdOLi(url)
	elif Nlyfx1HnzOWCovke5(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧᾆ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = IvurTMR8L94(url)
	elif YzowicIDTRusXZSU61(u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨᾇ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = KihbdWFrtBkew(url)
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡧ࠸ࡸࡸࡧࡲࠨᾈ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = sTiej2EJP1BMKYFU(url)
	elif SSBkx0WbN1asnDCQV6tIj(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨᾉ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = VnMz8lRjkKoe26s0HgqNWUC(url)
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭ᾊ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = VnMz8lRjkKoe26s0HgqNWUC(url)
	elif jXWzIZcDva4ikEUfN(u"ࠫࡺࡶࡢࡢ࡯ࠪᾋ") 		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	elif jXWzIZcDva4ikEUfN(u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧᾌ") 	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = foKW8R9wMHsLv0B74OhnZq(url)
	elif kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩᾍ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ClKL7mkBz8VIqnYxPp9wTUSWajg(url)
	elif MpJ8GOKoic(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫᾎ") 	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = p6m5OUzRc93ZTouexVbriQnFKY(url)
	elif EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩᾏ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ZeGsbz1JVjFioIU(url)
	elif FGLEMi21Bfn(u"ࠩࡸࡴࡧ࠭ᾐ") 			in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = LX3Kx2Spy157czwmdts9kRenoBa(url)
	elif NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡹࡵࡶࠧᾑ") 			in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = LX3Kx2Spy157czwmdts9kRenoBa(url)
	elif WCPwmyVsb62KRlo(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫᾒ") 		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ECDu5f3Fog(url)
	elif SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡼ࡫ࠨᾓ")	 		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = a0eFS9pzw42Ayob(hj50MJnoOp6ZWaS1IQ8Elr)
	elif ynxXU3gaiQ9GPCftr1q(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨᾔ") 	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = PV3kOwAI1Gm9WLBroa4Xv5sbK(url)
	elif ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᾕ")		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = y9dBp80LTvZjFPwmMReYGDI6r(url)
	elif ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᾖ") 		in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = TcE6ptAvNganoy5u02PR7zCiBkLU(url)
	elif EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ᾗ") 	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = vxgfYrUJKlz4WO0jXy(url)
	elif HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧᾘ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = rUKEGsRwtDF9VS5M(url)
	elif g7yJo2LVuqx1trPe(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨᾙ")	in oOv4sVqEAmyM: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = kx1ozQyOftL(url)
	else: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[],[]
	global rHTqjowlmFdsu62SzJGCX9MtyK
	if not Q0WnJxCYdAINZk2tBjs5 and not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: Q0WnJxCYdAINZk2tBjs5 = WXuJd8nz2spo146t(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶ࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭ᾚ")
	elif Q0WnJxCYdAINZk2tBjs5 not in [Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᾛ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᾜ")]: Q0WnJxCYdAINZk2tBjs5 = XCYALgFs2O3hZdpHrlMmB(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᾝ")+Q0WnJxCYdAINZk2tBjs5
	rHTqjowlmFdsu62SzJGCX9MtyK[J5rfz78qyAvt49aoVunbRE1hZG] = Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	return
def O0TG92kwtaR4s(url,source,J5rfz78qyAvt49aoVunbRE1hZG):
	global VXmGCLJsz1HF8TygMRlKjqpS3koYO0
	if jXWzIZcDva4ikEUfN(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪᾞ") in url:
		VXmGCLJsz1HF8TygMRlKjqpS3koYO0[J5rfz78qyAvt49aoVunbRE1hZG] = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡙ࠥ࡫ࡪࡲࡳࡩࡩ࠭ᾟ"),[],[]
		return
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[],[]
	if fLvc6uEJiq3(url):
		Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = J3JbhSvt8Wr21cXPC7(url)
	if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = ToDvrmzes1w(url)
	if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
		if Q0WnJxCYdAINZk2tBjs5==ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾠ"): Q0WnJxCYdAINZk2tBjs5 = Vk54F7GcROfCy6HunEI
		Q0WnJxCYdAINZk2tBjs5 = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᾡ")+Q0WnJxCYdAINZk2tBjs5 if Q0WnJxCYdAINZk2tBjs5 else jXWzIZcDva4ikEUfN(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧᾢ")
	VXmGCLJsz1HF8TygMRlKjqpS3koYO0[J5rfz78qyAvt49aoVunbRE1hZG] = Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	return
def tt8zGbsyp1ievNS53Y4lofRMKJ(url,source,J5rfz78qyAvt49aoVunbRE1hZG):
	ovLGZ5jUxNzmiQC = Vk54F7GcROfCy6HunEI
	w8YsNWfQ5gFluRvOmSd4Cb96H = eu1NswY9zkKC60I
	try:
		import resolveurl as HHFv14jG83f9
		w8YsNWfQ5gFluRvOmSd4Cb96H = HHFv14jG83f9.resolve(url)
	except Exception as hGo3BNKeAjHOITFpErYc0PxusWb: ovLGZ5jUxNzmiQC = str(hGo3BNKeAjHOITFpErYc0PxusWb)
	global y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO
	if not w8YsNWfQ5gFluRvOmSd4Cb96H:
		if ovLGZ5jUxNzmiQC==Vk54F7GcROfCy6HunEI:
			ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
			if ovLGZ5jUxNzmiQC!=ESXZrtnCfcDJGo01vFg(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪᾣ"): yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
		Q0WnJxCYdAINZk2tBjs5 = ovLGZ5jUxNzmiQC.splitlines()[-pwxH3oREFm5v98BCZ1QVtzMJOc]
		y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO[J5rfz78qyAvt49aoVunbRE1hZG] = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᾤ")+Q0WnJxCYdAINZk2tBjs5,[],[]
		return
	y8BCUQ0l6rwN5XdFSmktH2AKVgEDuO[J5rfz78qyAvt49aoVunbRE1hZG] = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[w8YsNWfQ5gFluRvOmSd4Cb96H]
	return
def HAGXu71gL0D(url,source,J5rfz78qyAvt49aoVunbRE1hZG):
	ovLGZ5jUxNzmiQC = Vk54F7GcROfCy6HunEI
	w8YsNWfQ5gFluRvOmSd4Cb96H = eu1NswY9zkKC60I
	try:
		import yt_dlp as wwyR8YnLIja
		e8QZdW1D0yo3 = wwyR8YnLIja.YoutubeDL({MpJ8GOKoic(u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫᾥ"): YOHXqtbQTBfKerIZ})
		w8YsNWfQ5gFluRvOmSd4Cb96H = e8QZdW1D0yo3.extract_info(url,download=eu1NswY9zkKC60I)
	except Exception as hGo3BNKeAjHOITFpErYc0PxusWb: ovLGZ5jUxNzmiQC = str(hGo3BNKeAjHOITFpErYc0PxusWb)
	global YYzda4xBQ8qD3PXwEoJt
	if not w8YsNWfQ5gFluRvOmSd4Cb96H or NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫᾦ") not in list(w8YsNWfQ5gFluRvOmSd4Cb96H.keys()):
		if ovLGZ5jUxNzmiQC==Vk54F7GcROfCy6HunEI:
			ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
			if ovLGZ5jUxNzmiQC!=eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧᾧ"): yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
		Q0WnJxCYdAINZk2tBjs5 = ovLGZ5jUxNzmiQC.splitlines()[-pwxH3oREFm5v98BCZ1QVtzMJOc]
		YYzda4xBQ8qD3PXwEoJt[J5rfz78qyAvt49aoVunbRE1hZG] = MzgKWUQ4V5H(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᾨ")+Q0WnJxCYdAINZk2tBjs5,[],[]
	else:
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in w8YsNWfQ5gFluRvOmSd4Cb96H[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧᾩ")]:
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[YzowicIDTRusXZSU61(u"ࠧࡧࡱࡵࡱࡦࡺࠧᾪ")])
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ynxXU3gaiQ9GPCftr1q(u"ࠨࡷࡵࡰࠬᾫ")])
		YYzda4xBQ8qD3PXwEoJt[J5rfz78qyAvt49aoVunbRE1hZG] = Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	return
def J3JbhSvt8Wr21cXPC7(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,MpJ8GOKoic(u"ࠩࡊࡉ࡙࠭ᾬ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,FGLEMi21Bfn(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡆࡌࡖࡊࡉࡔࡠࡗࡕࡐ࠲࠷ࡳࡵࠩᾭ"))
	headers = Iy3PA1SVXNfjOchtgHC5kuJBG.headers
	if MzgKWUQ4V5H(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᾮ") in list(headers.keys()):
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[WXuJd8nz2spo146t(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᾯ")]
		if fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp): return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return MzgKWUQ4V5H(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩᾰ"),[],[]
def jJRLWq70UtVpfAwN8E(q3U5kprDyzQMwIu2ONZsxBc41aEtKT):
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡭࡫ࡶࡸࠬᾱ") in str(type(q3U5kprDyzQMwIu2ONZsxBc41aEtKT)):
		HXhRgxEZ4d2Dek = []
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in q3U5kprDyzQMwIu2ONZsxBc41aEtKT:
			if MzgKWUQ4V5H(u"ࠨࡵࡷࡶࠬᾲ") in str(type(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			HXhRgxEZ4d2Dek.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	else: HXhRgxEZ4d2Dek = q3U5kprDyzQMwIu2ONZsxBc41aEtKT.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	return HXhRgxEZ4d2Dek
def DDVufOyzMg7HhejNEpk90AoXKr2Gd(v6eOQW0xrkL,source):
	data = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,ynxXU3gaiQ9GPCftr1q(u"ࠩ࡯࡭ࡸࡺࠧᾳ"),SSBkx0WbN1asnDCQV6tIj(u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫᾴ"),v6eOQW0xrkL)
	if data:
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = zip(*data)
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = list(nWcb8JC7zEVouFjx9fILGh1vSQ),list(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
		return nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,YZ7udgSc260AfmbBwHUkJs1jlV3Q9 = [],[],[]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in v6eOQW0xrkL:
		if WsklGNp2CYzVQUag(u"ࠫ࠴࠵ࠧ᾵") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
		tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns = gdDM3UcWBC8Rt45IEh26N9n0HkF7T(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,source)
		jMiru3pGns = RSuYINdeamsK0t.findall(WCPwmyVsb62KRlo(u"ࠬࡢࡤࠬࠩᾶ"),jMiru3pGns,RSuYINdeamsK0t.DOTALL)
		if jMiru3pGns: jMiru3pGns = int(jMiru3pGns[ufmXvxgoHGDwZtjsLkR05i])
		else: jMiru3pGns = ufmXvxgoHGDwZtjsLkR05i
		oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࡮ࡢ࡯ࡨࠫᾷ"))
		YZ7udgSc260AfmbBwHUkJs1jlV3Q9.append([tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,oOv4sVqEAmyM])
	if YZ7udgSc260AfmbBwHUkJs1jlV3Q9:
		UUb2PMLqHZxJe0coQm917 = sorted(YZ7udgSc260AfmbBwHUkJs1jlV3Q9,reverse=YOHXqtbQTBfKerIZ,key=lambda key: (key[BZm7TqLPJfAVblDKsya85zFWXNMY],key[ufmXvxgoHGDwZtjsLkR05i],key[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A],key[RXnhpCUk4M1TvgJE],key[pwxH3oREFm5v98BCZ1QVtzMJOc],key[ogJClMiqPa4A0NUtTxpDVybEWG(u"࠹൸")],key[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠻൹")]))
		FMpUSlAmskvgKEZ,Y6mwd2WJpiN7jgzXtElP4Vbh = [],[]
		for bBpKQ53S0agq6lRw1 in UUb2PMLqHZxJe0coQm917:
			tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,oOv4sVqEAmyM = bBpKQ53S0agq6lRw1
			if ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧๆใู่ࠬᾸ") in WypSQTO7504tHY:
				Y6mwd2WJpiN7jgzXtElP4Vbh.append(bBpKQ53S0agq6lRw1)
				continue
			if bBpKQ53S0agq6lRw1 not in FMpUSlAmskvgKEZ: FMpUSlAmskvgKEZ.append(bBpKQ53S0agq6lRw1)
		FMpUSlAmskvgKEZ = Y6mwd2WJpiN7jgzXtElP4Vbh+FMpUSlAmskvgKEZ
		W7SMIpbzhori2JE9mv = ufmXvxgoHGDwZtjsLkR05i
		for tycKzUdOrwaiLF5DINBP4uxHSTq6,EDy0Rs9liwjZvJY,WypSQTO7504tHY,k2kRdMUp0qmI9Hrv,jMiru3pGns,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,oOv4sVqEAmyM in FMpUSlAmskvgKEZ:
			jMiru3pGns = str(jMiru3pGns) if jMiru3pGns else Vk54F7GcROfCy6HunEI
			title = ynxXU3gaiQ9GPCftr1q(u"ࠨีํีๆืࠧᾹ")+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+WypSQTO7504tHY+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+tycKzUdOrwaiLF5DINBP4uxHSTq6+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jMiru3pGns+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+k2kRdMUp0qmI9Hrv+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+EDy0Rs9liwjZvJY
			if oOv4sVqEAmyM.lower() not in title.lower(): title = title+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+oOv4sVqEAmyM
			title = title.replace(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࠨࠫᾺ"),Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			W7SMIpbzhori2JE9mv += pwxH3oREFm5v98BCZ1QVtzMJOc
			title = str(W7SMIpbzhori2JE9mv)+pnkrd2S84FJfN73KuiCYv(u"ࠪ࠲ࠥ࠭Ά")+title
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		if yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
			data = list(zip(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9))
			if data: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,jXWzIZcDva4ikEUfN(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬᾼ"),v6eOQW0xrkL,data,sT9DURSXlOybaCQ)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = list(nWcb8JC7zEVouFjx9fILGh1vSQ),list(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	return nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def fEX2mhPgTw(url):
	if FGLEMi21Bfn(u"ࠬࡷࡶࡪࡦࠪ᾽") in url:
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = BDHby2pEuQ4K8(url)
		if yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
		return ESXZrtnCfcDJGo01vFg(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡑࡘ࡚ࡂࡂࠩι"),[],[]
	return eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᾿"),[Vk54F7GcROfCy6HunEI],[url]
def wMvjk9tOmEbGc(url):
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ῀") in url:
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,url)
		if yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
		return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࠹ࡕ࠹ࠩ῁"),[],[]
	return wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ῂ"),[Vk54F7GcROfCy6HunEI],[url]
def ddeNSF5fca(url):
	MMJL8QqY6T7dv1onu,t8tfMv1VXZYQ5y3 = [],[]
	if ESXZrtnCfcDJGo01vFg(u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧῃ") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,pnkrd2S84FJfN73KuiCYv(u"ࠬࡍࡅࡕࠩῄ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨ῅"))
		if WCPwmyVsb62KRlo(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩῆ") in Iy3PA1SVXNfjOchtgHC5kuJBG.headers:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪῇ")]
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡱࡥࡲ࡫ࠧῈ"))
			t8tfMv1VXZYQ5y3.append(oOv4sVqEAmyM)
	elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩΈ") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,cpHxZyU7vTtqmIw(u"ࠫࡌࡋࡔࠨῊ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧΉ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		tcymZ7D4BiLadxl58 = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭ῌ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if tcymZ7D4BiLadxl58:
			tcymZ7D4BiLadxl58 = tcymZ7D4BiLadxl58[ufmXvxgoHGDwZtjsLkR05i]
			xjofhAUmXqrE1 = xukS7TA9pKl(tcymZ7D4BiLadxl58)
			LzpvmNuXZQDYr = RSuYINdeamsK0t.findall(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬ῍"),xjofhAUmXqrE1,RSuYINdeamsK0t.DOTALL)
			if LzpvmNuXZQDYr:
				LzpvmNuXZQDYr = LzpvmNuXZQDYr[ufmXvxgoHGDwZtjsLkR05i]
				LzpvmNuXZQDYr = Bw6jaUcFxlqdDT8bC(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࡮࡬ࡷࡹ࠭῎"),LzpvmNuXZQDYr)
				for dict in LzpvmNuXZQDYr:
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = dict[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡩ࡭ࡱ࡫ࠧ῏")]
					jMiru3pGns = dict[pnkrd2S84FJfN73KuiCYv(u"ࠪࡰࡦࡨࡥ࡭ࠩῐ")]
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
					oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡳࡧ࡭ࡦࠩῑ"))
					t8tfMv1VXZYQ5y3.append(jMiru3pGns+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+oOv4sVqEAmyM)
		elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧῒ") in Iy3PA1SVXNfjOchtgHC5kuJBG.headers:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨΐ")]
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,WXuJd8nz2spo146t(u"ࠧ࡯ࡣࡰࡩࠬ῔"))
			t8tfMv1VXZYQ5y3.append(oOv4sVqEAmyM)
		if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨ῕") in url:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.split(ynxXU3gaiQ9GPCftr1q(u"ࠩࡂࡹࡷࡲ࠽ࠨῖ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split(SSBkx0WbN1asnDCQV6tIj(u"ࠪࠪࠬῗ"))[ufmXvxgoHGDwZtjsLkR05i]
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				t8tfMv1VXZYQ5y3.append(V2RQwM8XjlrK(u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫῘ"))
	else:
		MMJL8QqY6T7dv1onu.append(url)
		oOv4sVqEAmyM = RRav1Sf7Px(url,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡴࡡ࡮ࡧࠪῙ"))
		t8tfMv1VXZYQ5y3.append(oOv4sVqEAmyM)
	if not MMJL8QqY6T7dv1onu: return jXWzIZcDva4ikEUfN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪῚ"),[],[]
	elif len(MMJL8QqY6T7dv1onu)==pwxH3oREFm5v98BCZ1QVtzMJOc: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = MMJL8QqY6T7dv1onu[ufmXvxgoHGDwZtjsLkR05i]
	else:
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(XCYALgFs2O3hZdpHrlMmB(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬΊ"),t8tfMv1VXZYQ5y3)
		if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return Nlyfx1HnzOWCovke5(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭῜"),[],[]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = MMJL8QqY6T7dv1onu[qreJEpY8nZguD]
	return QYSAUI5r46yil8cfaO(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ῝"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def dDnCJ0pPsHGrI(url):
	headers = {wYTDlJC5vpOKynUEX3ge6W(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ῞"):WsklGNp2CYzVQUag(u"ࠫࡐࡵࡤࡪ࠱ࠪ῟")+str(gs15xoifvOt)}
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(EM6qpnCBYQGA9kbgDVLfrP(u"࠻࠰ൺ")):
		Gb6kwVlSQ4MU.sleep(pt7CIKiU8PVBw194dkQEznq)
		Iy3PA1SVXNfjOchtgHC5kuJBG = yPi9tYgLIMo2qW1f5Arp68c(ynxXU3gaiQ9GPCftr1q(u"ࠬࡍࡅࡕࠩῠ"),url,Vk54F7GcROfCy6HunEI,headers,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪῡ"))
		if WsklGNp2CYzVQUag(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩῢ") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()):
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[wAU9jKvmTM0(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪΰ")]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨῤ")+headers[ynxXU3gaiQ9GPCftr1q(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧῥ")]
			return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
		if Iy3PA1SVXNfjOchtgHC5kuJBG.code!=NNjUsZzEcFOAoKry2CDMgb1(u"࠴࠳࠻ൻ"): break
	return HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪῦ"),[],[]
def NlU80V7efqA5hyQjbKHEv1d(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡍࡅࡕࠩῧ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅ࠮࠳ࡶࡸࠬῨ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠧࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳࠰࠿ࠪࠤ࠯࠲࠯ࡅࠬ࠯ࠬࡂ࠰࠭࠴ࠪࡀࠫ࠯ࠫῩ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		return Vk54F7GcROfCy6HunEI,[jMiru3pGns],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩῪ"),[],[]
def HVdu8AmN05(url):
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࠲ࡻࡪ࡫ࡰࡪࡵ࠲ࠫΎ") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,g7yJo2LVuqx1trPe(u"ࠪࡋࡊ࡚ࠧῬ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡇࡆࡍࡒࡇ࠲࠮࠳ࡶࡸࠬ῭"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡲࡷࡤࡰ࡮ࡺࡹ࠿ࠩ΅"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: url = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		else: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁ࠳ࠩ`"),[],[]
	return WXuJd8nz2spo146t(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ῰"),[Vk54F7GcROfCy6HunEI],[url]
def QBUiYm6CtO(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,MpJ8GOKoic(u"ࠨࡉࡈࡘࠬ῱"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠷࠭࠲ࡵࡷࠫῲ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FB73gN9pmQMe1AVKjyslCL8I2X(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫῳ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]]
	return pnkrd2S84FJfN73KuiCYv(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠱ࠨῴ"),[],[]
def llhCVaYrkN(url):
	if len(url)>MzgKWUQ4V5H(u"࠳࠲࠳ർ"):
		url = url.strip(MpJ8GOKoic(u"ࠬ࠵ࠧ῵"))+SSBkx0WbN1asnDCQV6tIj(u"࠭࠯ࠨῶ")
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,wAU9jKvmTM0(u"ࠧࡈࡇࡗࠫῷ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡇࡒࡐ࡜ࡄ࠱࠶ࡹࡴࠨῸ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if ufmXvxgoHGDwZtjsLkR05i and MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳࠫࠪΌ") in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			Ry3L7fdNGh = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠪࠦࡱࡵࡡࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩῺ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if Ry3L7fdNGh:
				UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
				Ry3L7fdNGh = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡁࡹࡣࡳ࡫ࡳࡸࡃࡼࡡࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴࠨΏ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				if Ry3L7fdNGh:
					UwcYSVZbdK3rI = nnAikQJ3CUMWVhfatgT(Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i])
		elif len(FjwObZSWkg8ahBdiQf9IeY135DpXoP)<wYTDlJC5vpOKynUEX3ge6W(u"࠶࠳࠴ൽ"): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FjwObZSWkg8ahBdiQf9IeY135DpXoP
		else: return wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡃࡕࡓ࡟ࡇࠧῼ"),[],[]
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return QYSAUI5r46yil8cfaO(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ´"),[Vk54F7GcROfCy6HunEI],[url]
def jZnLR47tB5(url):
	if HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧ࠰ࡦࡲࡻࡳ࠴ࡰࡩࡲࠪ῾") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,MpJ8GOKoic(u"ࠨࡉࡈࡘࠬ῿"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡊࡍࡇ࠭࠲ࡵࡷࠫࠀ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(pnkrd2S84FJfN73KuiCYv(u"ࠬࡼࡩࡥࡧࡲ࠱ࡼࡸࡡࡱࡲࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠁ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		url = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	return ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠂ"),[Vk54F7GcROfCy6HunEI],[url]
def KpTdiYPncX(url):
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫࠃ") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡉࡈࡘࠬࠄ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩࠅ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠆ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		if g7yJo2LVuqx1trPe(u"ࠫ࡭ࡺࡴࡱࠩࠇ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࠈ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
		return WXuJd8nz2spo146t(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨࠉ"),[],[]
	return ynxXU3gaiQ9GPCftr1q(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠊ"),[Vk54F7GcROfCy6HunEI],[url]
def MhGoTmEkg2(url):
	hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
	eDbTIrV6KLfz80 = {kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫࠋ"):MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪࠌ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩࠍ"):wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫࠎ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,WsklGNp2CYzVQUag(u"ࠬࡖࡏࡔࡖࠪࠏ"),hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡔࡏࡘ࠯࠴ࡷࡹ࠭ࠐ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(jXWzIZcDva4ikEUfN(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࠑ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return MpJ8GOKoic(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡎࡐ࡙ࠪࠒ"),[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	return cpHxZyU7vTtqmIw(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠓ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def S5SGI6cZW1(url):
	headers = {kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ࠔ"):eAMGzHRQVs2KyCwPXljYhB(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬࠕ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MzgKWUQ4V5H(u"ࠬࡍࡅࡕࠩࠖ"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨࠗ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠘"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ࠙"),[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	return V2RQwM8XjlrK(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠚ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def ahFMwSmWVy(url):
	hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
	eDbTIrV6KLfz80 = {jXWzIZcDva4ikEUfN(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩࠛ"):FGLEMi21Bfn(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫࠜ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,WXuJd8nz2spo146t(u"ࠬࡖࡏࡔࡖࠪࠝ"),hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡋࡅࡑࡇࡃࡊࡏࡄ࠱࠶ࡹࡴࠨࠞ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩࠟ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡌࡆࡒࡁࡄࡋࡐࡅࠬࠠ"),[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࡫ࡸࡹࡶࠧࠡ") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = QYSAUI5r46yil8cfaO(u"ࠪ࡬ࡹࡺࡰ࠻ࠩࠢ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	return WsklGNp2CYzVQUag(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠣ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def Mis0W8Q4a7(url):
	YBDKFZOGfyCHLPA1EaUz9MJ,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = url,[],[]
	if wAU9jKvmTM0(u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࠬࠤ") in url:
		hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
		eDbTIrV6KLfz80 = {WXuJd8nz2spo146t(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࠥ"):WCPwmyVsb62KRlo(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧࠦ")}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MpJ8GOKoic(u"ࠨࡒࡒࡗ࡙࠭ࠧ"),hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫࠨ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		pZGDafn8c5w = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠪࠫࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧࠩ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if pZGDafn8c5w: YBDKFZOGfyCHLPA1EaUz9MJ = pZGDafn8c5w[ufmXvxgoHGDwZtjsLkR05i]
	return wAU9jKvmTM0(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠪ"),[Vk54F7GcROfCy6HunEI],[YBDKFZOGfyCHLPA1EaUz9MJ]
def YNmJdaRLhM(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡍࡅࡕࠩࠫ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬࠬ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	HFXwP5TlDqS0yjrYi1xdV3u9KG = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ࠭"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	if HFXwP5TlDqS0yjrYi1xdV3u9KG:
		HFXwP5TlDqS0yjrYi1xdV3u9KG = HFXwP5TlDqS0yjrYi1xdV3u9KG[ufmXvxgoHGDwZtjsLkR05i][BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠵ൾ"):]
		HFXwP5TlDqS0yjrYi1xdV3u9KG = PnRA5dpzE18JU.b64decode(HFXwP5TlDqS0yjrYi1xdV3u9KG)
		if PvwFsJK23NbU8XWAx: HFXwP5TlDqS0yjrYi1xdV3u9KG = HFXwP5TlDqS0yjrYi1xdV3u9KG.decode(AoCWwJHgUPKXI7u2lEzym)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࠮"),HFXwP5TlDqS0yjrYi1xdV3u9KG,RSuYINdeamsK0t.DOTALL)
	else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Vk54F7GcROfCy6HunEI
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return FGLEMi21Bfn(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪ࠯"),[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࡬ࡹࡺࡰࠨ࠰") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࡭ࡺࡴࡱ࠼ࠪ࠱")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
	return jXWzIZcDva4ikEUfN(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࠲"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def ZWvcm6Tos3d2GEiw1DqJnKNCYa(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡇࡆࡖࠪ࠳"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩ࠴"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࠵"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭࠶"),[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	return SSBkx0WbN1asnDCQV6tIj(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࠷"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def sjqwv4CVyB(url):
	id = url.split(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࠴࠭࠸"))[-cpHxZyU7vTtqmIw(u"࠵ൿ")]
	if ESXZrtnCfcDJGo01vFg(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ࠹") in url: url = url.replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭࠺"),Vk54F7GcROfCy6HunEI)
	url = url.replace(Nlyfx1HnzOWCovke5(u"ࠧ࠯ࡥࡲࡱ࠴࠭࠻"),pnkrd2S84FJfN73KuiCYv(u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩ࠼"))
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,cpHxZyU7vTtqmIw(u"ࠩࡊࡉ࡙࠭࠽"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ࠾"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Q0WnJxCYdAINZk2tBjs5 = MzgKWUQ4V5H(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ࠿")
	hGo3BNKeAjHOITFpErYc0PxusWb = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡀ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hGo3BNKeAjHOITFpErYc0PxusWb: Q0WnJxCYdAINZk2tBjs5 = hGo3BNKeAjHOITFpErYc0PxusWb[ufmXvxgoHGDwZtjsLkR05i]
	url = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪࡁ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not url and Q0WnJxCYdAINZk2tBjs5:
		return Q0WnJxCYdAINZk2tBjs5,[],[]
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url[ufmXvxgoHGDwZtjsLkR05i].replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡝࡞ࠪࡂ"),Vk54F7GcROfCy6HunEI)
	TQjudoNYcPJr5,v6eOQW0xrkL = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	PSo6Hynm5cdOBMzL = cad8TeSyMUYmfsEO0.getSetting(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬࡃ"))
	if PSo6Hynm5cdOBMzL and kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩ࠰ࠫࡄ") not in PSo6Hynm5cdOBMzL: title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = TQjudoNYcPJr5[ufmXvxgoHGDwZtjsLkR05i],v6eOQW0xrkL[ufmXvxgoHGDwZtjsLkR05i]
	else:
		AadlWS7x4gL5YMCt6921ZTiQ = RSuYINdeamsK0t.findall(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࡡࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡅ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if AadlWS7x4gL5YMCt6921ZTiQ: rrixQ15zyC9M0pPUN,pptdwqz7ZsJkmABaUbVfr9IWl,rc7pKwZGSkLqOWxMavYh3Dd = AadlWS7x4gL5YMCt6921ZTiQ[ufmXvxgoHGDwZtjsLkR05i]
		else: rrixQ15zyC9M0pPUN,pptdwqz7ZsJkmABaUbVfr9IWl,rc7pKwZGSkLqOWxMavYh3Dd = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
		rc7pKwZGSkLqOWxMavYh3Dd = rc7pKwZGSkLqOWxMavYh3Dd.replace(ynxXU3gaiQ9GPCftr1q(u"ࠫࡡ࠵ࠧࡆ"),V2RQwM8XjlrK(u"ࠬ࠵ࠧࡇ"))
		pptdwqz7ZsJkmABaUbVfr9IWl = ww25jXuxtpK1TOJEbGUgrm8(pptdwqz7ZsJkmABaUbVfr9IWl)
		nWcb8JC7zEVouFjx9fILGh1vSQ = [nMt0iueCy6K+MzgKWUQ4V5H(u"࠭ࡏࡘࡐࡈࡖ࠿ࠦࠠࠨࡈ")+pptdwqz7ZsJkmABaUbVfr9IWl+ZZoLlKyInXc08j2pTGJ]+TQjudoNYcPJr5
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [rc7pKwZGSkLqOWxMavYh3Dd]+v6eOQW0xrkL
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(ESXZrtnCfcDJGo01vFg(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨࡉ")+str(len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)-XCYALgFs2O3hZdpHrlMmB(u"࠶඀"))+g7yJo2LVuqx1trPe(u"ࠨ่่ࠢๆ࠯ࠧࡊ"),nWcb8JC7zEVouFjx9fILGh1vSQ)
		if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࡋ"),[],[]
		elif qreJEpY8nZguD==ufmXvxgoHGDwZtjsLkR05i:
			N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx = yBxCpcVaPow1bztQm4X.argv[ufmXvxgoHGDwZtjsLkR05i]+SSBkx0WbN1asnDCQV6tIj(u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩࡌ")+rc7pKwZGSkLqOWxMavYh3Dd+NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࠫࡺࡥࡹࡶࡷࡁࠬࡍ")+pptdwqz7ZsJkmABaUbVfr9IWl
			J2L6to3R1Z.executebuiltin(cpHxZyU7vTtqmIw(u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤࡎ")+N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx+WXuJd8nz2spo146t(u"ࠨࠩࠣࡏ"))
			return eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࡐ"),[],[]
		title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = nWcb8JC7zEVouFjx9fILGh1vSQ[qreJEpY8nZguD],yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	return Vk54F7GcROfCy6HunEI,[title],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def eeJOLScAxm(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡉࡈࡘࠬࡑ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨࡒ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪ࠲࡯ࡹ࡯࡯ࠩࡓ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: url = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫࡔ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else: url = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࡕ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not url: return Nlyfx1HnzOWCovke5(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧࡖ"),[],[]
	url = url[ufmXvxgoHGDwZtjsLkR05i]
	if WXuJd8nz2spo146t(u"ࠧࡩࡶࡷࡴࠬࡗ") not in url: url = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡪࡷࡸࡵࡀࠧࡘ")+url
	return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
def al82YzMuUrXhfHBLVojgRI(url):
	headers = { SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࡙࠭") : Vk54F7GcROfCy6HunEI }
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࡚࠭") in url:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࡛࠭"))
		items = RSuYINdeamsK0t.findall(NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࡜"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if items: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[items[ufmXvxgoHGDwZtjsLkR05i]]
		else:
			BadMOTrh9Lnp0w6KZCQASE4uyk7fW = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࡝"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if BadMOTrh9Lnp0w6KZCQASE4uyk7fW:
				GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩ࡞"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW[ufmXvxgoHGDwZtjsLkR05i])
				return wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩ࡟")+BadMOTrh9Lnp0w6KZCQASE4uyk7fW[ufmXvxgoHGDwZtjsLkR05i],[],[]
	else:
		KK4WEqy9u1mj = ESXZrtnCfcDJGo01vFg(u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬࡠ")
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬࡡ"))
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ࡢ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: return V2RQwM8XjlrK(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩࡣ"),[],[]
		YBDKFZOGfyCHLPA1EaUz9MJ = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i]
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]
		if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠮ࡳࡣࡵࠫࡤ") in UwcYSVZbdK3rI or MpJ8GOKoic(u"ࠧ࠯ࡼ࡬ࡴࠬࡥ") in UwcYSVZbdK3rI: return NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭ࡦ"),[],[]
		items = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࡧ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		k8NxAwnQI2FzZCyJYthpaVubLscq = {}
		for EDy0Rs9liwjZvJY,value in items:
			k8NxAwnQI2FzZCyJYthpaVubLscq[EDy0Rs9liwjZvJY] = value
		data = weWxHqLyORY4NfBbGQmgc53F1E8UVz(k8NxAwnQI2FzZCyJYthpaVubLscq)
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,YBDKFZOGfyCHLPA1EaUz9MJ,data,headers,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬࡨ"))
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩࡩ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh: return NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩࡪ"),[],[]
		download = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i]
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]
		items = RSuYINdeamsK0t.findall(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭࡫"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,nWcb8JC7zEVouFjx9fILGh1vSQ,vwYsD8UprydixO3n7L,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,N1kTrvAL5GnCesSxhbDzJEq = [],[],[],[],[]
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧ࠯࡯࠶ࡹ࠽࠭࡬") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,vwYsD8UprydixO3n7L = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 + vwYsD8UprydixO3n7L
				if QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz[ufmXvxgoHGDwZtjsLkR05i]==pnkrd2S84FJfN73KuiCYv(u"ࠨ࠯࠴ࠫ࡭"): nWcb8JC7zEVouFjx9fILGh1vSQ.append(MpJ8GOKoic(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ࡮")+SSBkx0WbN1asnDCQV6tIj(u"ࠪࡱ࠸ࡻ࠸ࠡࠩ࡯")+KK4WEqy9u1mj)
				else:
					for title in QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz:
						nWcb8JC7zEVouFjx9fILGh1vSQ.append(XCYALgFs2O3hZdpHrlMmB(u"ู๊ࠫࠥาใิࠤำอีࠡࠩࡰ")+WCPwmyVsb62KRlo(u"ࠬࡳ࠳ࡶ࠺ࠣࠫࡱ")+KK4WEqy9u1mj+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+title)
			else:
				title = title.replace(YzowicIDTRusXZSU61(u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨࡲ"),Vk54F7GcROfCy6HunEI)
				title = title.strip(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠣࠩࡳ"))
				title = cpHxZyU7vTtqmIw(u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧࡴ")+MzgKWUQ4V5H(u"ࠩࠣࡱࡵ࠺ࠠࠨࡵ")+KK4WEqy9u1mj+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+title
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬࡶ") + download
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠸ࡸ࡭࠭ࡷ"))
		items = RSuYINdeamsK0t.findall(QYSAUI5r46yil8cfaO(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭ࠤࡸ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for id,Yz6schq9wSmiu3IOdke0DXPj5W,hash,CaAnGXpU4zIq in items:
			title = jXWzIZcDva4ikEUfN(u"࠭ࠠิ์ิๅึࠦสฮ็ํ่ࠥิวึࠢࠪࡹ")+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࠡ࡯ࡳ࠸ࠥ࠭ࡺ")+KK4WEqy9u1mj+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+CaAnGXpU4zIq.split(Nlyfx1HnzOWCovke5(u"ࠨࡺࠪࡻ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = g7yJo2LVuqx1trPe(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧࡼ")+id+pnkrd2S84FJfN73KuiCYv(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪࡽ")+Yz6schq9wSmiu3IOdke0DXPj5W+MzgKWUQ4V5H(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫࡾ")+hash
			N1kTrvAL5GnCesSxhbDzJEq.append(CaAnGXpU4zIq)
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		N1kTrvAL5GnCesSxhbDzJEq = set(N1kTrvAL5GnCesSxhbDzJEq)
		HhMya3ktZVdTpozc5GRB,uq6kKpMD4SYgslfTAi1E5ecX7nx2 = [],[]
		for title in nWcb8JC7zEVouFjx9fILGh1vSQ:
			jeKWBpHiawn82Y4VQ = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧࡿ"),title+WCPwmyVsb62KRlo(u"࠭ࠦࠧࠩࢀ"),RSuYINdeamsK0t.DOTALL)
			for CaAnGXpU4zIq in N1kTrvAL5GnCesSxhbDzJEq:
				if jeKWBpHiawn82Y4VQ[ufmXvxgoHGDwZtjsLkR05i] in CaAnGXpU4zIq:
					title = title.replace(jeKWBpHiawn82Y4VQ[ufmXvxgoHGDwZtjsLkR05i],CaAnGXpU4zIq.split(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡹࠩࢁ"))[pwxH3oREFm5v98BCZ1QVtzMJOc])
			HhMya3ktZVdTpozc5GRB.append(title)
		for zHq7nBWJTNyY1I3aLco4AR in range(len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)):
			items = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤࢂ"),jXWzIZcDva4ikEUfN(u"ࠩࠩࠪࠬࢃ")+HhMya3ktZVdTpozc5GRB[zHq7nBWJTNyY1I3aLco4AR]+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࠪࠫ࠭ࢄ"),RSuYINdeamsK0t.DOTALL)
			uq6kKpMD4SYgslfTAi1E5ecX7nx2.append( [HhMya3ktZVdTpozc5GRB[zHq7nBWJTNyY1I3aLco4AR],yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[zHq7nBWJTNyY1I3aLco4AR],items[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i],items[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]] )
		uq6kKpMD4SYgslfTAi1E5ecX7nx2 = sorted(uq6kKpMD4SYgslfTAi1E5ecX7nx2, key=lambda M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa: M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A], reverse=YOHXqtbQTBfKerIZ)
		uq6kKpMD4SYgslfTAi1E5ecX7nx2 = sorted(uq6kKpMD4SYgslfTAi1E5ecX7nx2, key=lambda M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa: M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa[RXnhpCUk4M1TvgJE], reverse=eu1NswY9zkKC60I)
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(uq6kKpMD4SYgslfTAi1E5ecX7nx2)):
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(uq6kKpMD4SYgslfTAi1E5ecX7nx2[zHq7nBWJTNyY1I3aLco4AR][ufmXvxgoHGDwZtjsLkR05i])
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(uq6kKpMD4SYgslfTAi1E5ecX7nx2[zHq7nBWJTNyY1I3aLco4AR][pwxH3oREFm5v98BCZ1QVtzMJOc])
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨࢅ"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def sTiej2EJP1BMKYFU(url):
	itb54hH6eAY = url.split(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡅࠧࢆ"))
	hj50MJnoOp6ZWaS1IQ8Elr = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
	headers = { YzowicIDTRusXZSU61(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࢇ") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺࠧ࢈"))
	items = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩࢉ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	url = items[ufmXvxgoHGDwZtjsLkR05i]
	return BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢊ"),[Vk54F7GcROfCy6HunEI],[url]
def KihbdWFrtBkew(url):
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	headers = { EM6qpnCBYQGA9kbgDVLfrP(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࢋ") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪࢌ"))
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢍ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hj50MJnoOp6ZWaS1IQ8Elr: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]]
	else: return XCYALgFs2O3hZdpHrlMmB(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩࢎ"),[],[]
def VnMz8lRjkKoe26s0HgqNWUC(url):
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	headers = { XCYALgFs2O3hZdpHrlMmB(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࢏") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ࢐"))
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁࠬࠦࠬ࢑"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hj50MJnoOp6ZWaS1IQ8Elr: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]]
	else: return ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠫ࢒"),[],[]
def lUdgLk0izX(url):
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,errno = [],[],Vk54F7GcROfCy6HunEI
	if XCYALgFs2O3hZdpHrlMmB(u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ࢓") in url:
		hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
		eDbTIrV6KLfz80 = {ESXZrtnCfcDJGo01vFg(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ࢔"):QYSAUI5r46yil8cfaO(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭࢕")}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡑࡑࡖࡘࠬ࢖"),hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧࠫࢗ"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if nqzvfpjFuS42ywk8.startswith(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡫ࡸࡹࡶࠧ࢘")): hj50MJnoOp6ZWaS1IQ8Elr = nqzvfpjFuS42ywk8
		else:
			ynmiDuav5ICTeRsqj6Vb18Q = RSuYINdeamsK0t.findall(YzowicIDTRusXZSU61(u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞࢙ࠩࠪࠫ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if ynmiDuav5ICTeRsqj6Vb18Q:
				hj50MJnoOp6ZWaS1IQ8Elr = ynmiDuav5ICTeRsqj6Vb18Q[ufmXvxgoHGDwZtjsLkR05i]
				ynmiDuav5ICTeRsqj6Vb18Q = RSuYINdeamsK0t.findall(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫ࡞ࠪࠩࡣ࢚ࠧ"),hj50MJnoOp6ZWaS1IQ8Elr,RSuYINdeamsK0t.DOTALL)
				if ynmiDuav5ICTeRsqj6Vb18Q:
					hj50MJnoOp6ZWaS1IQ8Elr = ZlBMJUAWRm9buv(ynmiDuav5ICTeRsqj6Vb18Q[ufmXvxgoHGDwZtjsLkR05i])
					return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	elif eAMGzHRQVs2KyCwPXljYhB(u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࢛࠭") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,YzowicIDTRusXZSU61(u"࠭ࡇࡆࡖࠪ࢜"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠱ࡴࡶࠪ࢝"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if cpHxZyU7vTtqmIw(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ࢞") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()): hj50MJnoOp6ZWaS1IQ8Elr = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ࢟")]
		else:
			hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(jXWzIZcDva4ikEUfN(u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢠ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i] if hj50MJnoOp6ZWaS1IQ8Elr else url
	if MpJ8GOKoic(u"ࠫ࠴ࡼ࠯ࠨࢡ") in hj50MJnoOp6ZWaS1IQ8Elr or YzowicIDTRusXZSU61(u"ࠬ࠵ࡦ࠰ࠩࢢ") in hj50MJnoOp6ZWaS1IQ8Elr:
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace(Nlyfx1HnzOWCovke5(u"࠭࠯ࡧ࠱ࠪࢣ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭ࢤ"))
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace(pnkrd2S84FJfN73KuiCYv(u"ࠨ࠱ࡹ࠳ࠬࢥ"),YzowicIDTRusXZSU61(u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨࢦ"))
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,WXuJd8nz2spo146t(u"ࠪࡔࡔ࡙ࡔࠨࢧ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧࢨ"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		items = RSuYINdeamsK0t.findall(QYSAUI5r46yil8cfaO(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢩ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭࡜࡝ࠩࢪ"),Vk54F7GcROfCy6HunEI)
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		else:
			items = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢫ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if items:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[ufmXvxgoHGDwZtjsLkR05i]
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࡞࡟ࠫࢬ"),Vk54F7GcROfCy6HunEI)
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(Vk54F7GcROfCy6HunEI)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	else: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢭ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨࢮ"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def XXbVGhg7yo(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡌࡋࡔࠨࢯ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬࢰ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,errno = [],[],Vk54F7GcROfCy6HunEI
	if MpJ8GOKoic(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩࢱ") in url or FGLEMi21Bfn(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨࢲ") in url:
		if wAU9jKvmTM0(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫࢳ") in url:
			hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(WCPwmyVsb62KRlo(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢴ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]
		else: hj50MJnoOp6ZWaS1IQ8Elr = url
		if NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪࢵ") not in hj50MJnoOp6ZWaS1IQ8Elr: return MzgKWUQ4V5H(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࢶ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,jXWzIZcDva4ikEUfN(u"ࠬࡍࡅࡕࠩࢷ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭ࢸ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪࢹ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
		items = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢺ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,fqNDhEb7ic5rH2K9Rx in items:
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(fqNDhEb7ic5rH2K9Rx)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	elif jXWzIZcDva4ikEUfN(u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫࢻ") in url:
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧࢼ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,jXWzIZcDva4ikEUfN(u"ࠫࡌࡋࡔࠨࢽ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬࢾ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ynmiDuav5ICTeRsqj6Vb18Q = RSuYINdeamsK0t.findall(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢿ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		ynmiDuav5ICTeRsqj6Vb18Q = ynmiDuav5ICTeRsqj6Vb18Q[ufmXvxgoHGDwZtjsLkR05i]
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(Vk54F7GcROfCy6HunEI)
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ynmiDuav5ICTeRsqj6Vb18Q)
	elif wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧࣀ") in url:
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(g7yJo2LVuqx1trPe(u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࣁ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if hj50MJnoOp6ZWaS1IQ8Elr:
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]
			return ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣂ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return YzowicIDTRusXZSU61(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡗࡕ࠷࡙ࠬࣃ"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def KVS3Zj7peQ(url):
	if ESXZrtnCfcDJGo01vFg(u"ࠫࡄ࡭ࡥࡵ࠿ࠪࣄ") in url:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.split(XCYALgFs2O3hZdpHrlMmB(u"ࠬࡅࡧࡦࡶࡀࠫࣅ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = PnRA5dpzE18JU.b64decode(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		if PvwFsJK23NbU8XWAx: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.decode(AoCWwJHgUPKXI7u2lEzym,NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ࣆ"))
		return WsklGNp2CYzVQUag(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣇ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	website = h9zFQKnsNL.SITESURLS[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪࣈ")][ufmXvxgoHGDwZtjsLkR05i]
	headers = {FGLEMi21Bfn(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣉ"):website}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡋࡊ࡚ࠧ࣊"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡃ࠯࠵ࡲࡩ࠭࣋"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	oOv4sVqEAmyM = RRav1Sf7Px(url,WsklGNp2CYzVQUag(u"ࠬࡻࡲ࡭ࠩ࣌"))
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(QYSAUI5r46yil8cfaO(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࣍"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠢࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠬ࠮࠮ࠫࡁࠬࠫࠧ࣎"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠣࡨ࡬ࡰࡪࡀࠧࠩ࠰࠭ࡃ࠮࣏࠭ࠢ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁ࣐ࠬ")+website
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤ࣑ࠪ") in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		Krbq3I49t8 = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࣒࠭ࠧ࠭"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Krbq3I49t8:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Krbq3I49t8[ufmXvxgoHGDwZtjsLkR05i]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = PnRA5dpzE18JU.b64decode(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			if PvwFsJK23NbU8XWAx: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.decode(AoCWwJHgUPKXI7u2lEzym,cpHxZyU7vTtqmIw(u"ࠬ࡯ࡧ࡯ࡱࡵࡩ࣓ࠬ"))
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"࠭ࡨࡵࡶࡳ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࠮ࠪࣔ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣕ")+website
				return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return FGLEMi21Bfn(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣖ"),[Vk54F7GcROfCy6HunEI],[url]
def QQzUvhZY8P(url,yCJq05F7M4TB):
	t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = [],[]
	if MpJ8GOKoic(u"ࠩ࠲࠵࠴࠭ࣗ") in url:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.replace(wAU9jKvmTM0(u"ࠪ࠳࠶࠵ࠧࣘ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࠴࠺࠯ࠨࣙ"))
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡍࡅࡕࠩࣚ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨࣛ"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭ࣜ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
			items = RSuYINdeamsK0t.findall(jXWzIZcDva4ikEUfN(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣝ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in MMJL8QqY6T7dv1onu:
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
					oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,pnkrd2S84FJfN73KuiCYv(u"ࠩࡱࡥࡲ࡫ࠧࣞ"))
					t8tfMv1VXZYQ5y3.append(oOv4sVqEAmyM+YIPoWuLzfl93BTS+jMiru3pGns)
			return Vk54F7GcROfCy6HunEI,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu
	elif WXuJd8nz2spo146t(u"ࠪ࠳ࡩ࠵ࠧࣟ") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡌࡋࡔࠨ࣠"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠶ࡳࡪࠧ࣡"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࣢"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i].replace(MpJ8GOKoic(u"ࠧ࠰࠳࠲ࣣࠫ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࠱࠷࠳ࠬࣤ"))
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡊࡉ࡙࠭ࣥ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࣦࠬ"))
			nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࣧ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣨ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]]
	elif YzowicIDTRusXZSU61(u"࠭࠯ࡳࡱ࡯ࡩ࠴ࣩ࠭") in url:
		headers = {EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࣪"):yCJq05F7M4TB}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,jXWzIZcDva4ikEUfN(u"ࠨࡉࡈࡘࠬ࣫"),url,Vk54F7GcROfCy6HunEI,headers,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠵ࡶ࡫ࠫ࣬"))
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲ࣭ࠬ")]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,FGLEMi21Bfn(u"ࠫࡌࡋࡔࠨ࣮"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠹ࡹ࡮࣯ࠧ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = WZEdv9hYqQDcjtxGn2Ul6f4(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,FjwObZSWkg8ahBdiQf9IeY135DpXoP)
		return Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࣰࠪ") in url:
		hj50MJnoOp6ZWaS1IQ8Elr = url.replace(WXuJd8nz2spo146t(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࣱࠫ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ࠱ࡶࡧࡷ࡯ࡰࡵ࠱ࣲࠪ"))
		eDbTIrV6KLfz80 = {WsklGNp2CYzVQUag(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣳ"):yCJq05F7M4TB}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,V2RQwM8XjlrK(u"ࠪࡋࡊ࡚ࠧࣴ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠹ࡸ࡭࠭ࣵ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂࣶ࠭ࠧ࠭"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡇࡆࡖࠪࣷ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠽ࡴࡩࠩࣸ"))
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			if cpHxZyU7vTtqmIw(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࣹࠪ") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()):
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࣺࠫ")]
				Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,ynxXU3gaiQ9GPCftr1q(u"ࠪࡋࡊ࡚ࠧࣻ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠻ࡸ࡭࠭ࣼ"))
				FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
				Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = WZEdv9hYqQDcjtxGn2Ul6f4(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,FjwObZSWkg8ahBdiQf9IeY135DpXoP)
				if MMJL8QqY6T7dv1onu: return Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu
			elif cpHxZyU7vTtqmIw(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ࣽ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(cpHxZyU7vTtqmIw(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧࣾ"),MzgKWUQ4V5H(u"ࠧ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫࣿ"))
				return ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫऀ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	else: return HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬँ"),[Vk54F7GcROfCy6HunEI],[url]
	return WXuJd8nz2spo146t(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧं"),[],[]
def TICq46Es3M(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,jXWzIZcDva4ikEUfN(u"ࠫࡌࡋࡔࠨः"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠵ࡸࡺࠧऄ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	data = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"࠭ࠢࡢࡥࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧअ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if data:
		rvkLyGNFQVTROxpa,id,WzjRkV9JmcxdGP = data[ufmXvxgoHGDwZtjsLkR05i]
		data = WCPwmyVsb62KRlo(u"ࠧࡰࡲࡀࠫआ")+rvkLyGNFQVTROxpa+WCPwmyVsb62KRlo(u"ࠨࠨ࡬ࡨࡂ࠭इ")+id+g7yJo2LVuqx1trPe(u"ࠩࠩࡪࡳࡧ࡭ࡦ࠿ࠪई")+WzjRkV9JmcxdGP
		headers = {Nlyfx1HnzOWCovke5(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩउ"):wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪऊ")}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,jXWzIZcDva4ikEUfN(u"ࠬࡖࡏࡔࡖࠪऋ"),url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠷ࡴࡤࠨऌ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠧࠣࡴࡨࡪࡪࡸࡥࡳࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪऍ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫऎ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]]
	return kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ए"),[],[]
def tSvc6xpWlE(url):
	headers = {kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ऐ"):QYSAUI5r46yil8cfaO(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬऑ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡍࡅࡕࠩऒ"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱࠶ࡹࡴࠨओ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ESXZrtnCfcDJGo01vFg(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬऔ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i].replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI)
		return Nlyfx1HnzOWCovke5(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫक"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ख"),[],[]
def agMbSs938w(url):
	hj50MJnoOp6ZWaS1IQ8Elr = url.split(MpJ8GOKoic(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫग"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i].strip(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡄ࠭घ")).strip(pnkrd2S84FJfN73KuiCYv(u"ࠬ࠵ࠧङ")).strip(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࠦࠨच"))
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,items,ynmiDuav5ICTeRsqj6Vb18Q = [],[],[],Vk54F7GcROfCy6HunEI
	headers = { pnkrd2S84FJfN73KuiCYv(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫछ"):eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨज") }
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡊࡉ࡙࠭झ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫञ"))
	if eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ट") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()): ynmiDuav5ICTeRsqj6Vb18Q = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧठ")]
	if ynxXU3gaiQ9GPCftr1q(u"࠭ࡨࡵࡶࡳࠫड") in ynmiDuav5ICTeRsqj6Vb18Q:
		if g7yJo2LVuqx1trPe(u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨढ") in url: ynmiDuav5ICTeRsqj6Vb18Q = ynmiDuav5ICTeRsqj6Vb18Q.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨ࠱ࡩ࠳ࠬण"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࠲ࡺ࠴࠭त"))
		XwzAhkcV31W4RvCEaHNLiTUs0rj = hj50MJnoOp6ZWaS1IQ8Elr.split(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬथ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
		headers = { MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨद"):headers[ESXZrtnCfcDJGo01vFg(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩध")] , FGLEMi21Bfn(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭न"):kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨऩ")+XwzAhkcV31W4RvCEaHNLiTUs0rj }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,WXuJd8nz2spo146t(u"ࠨࡉࡈࡘࠬप"),ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,headers,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬफ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if g7yJo2LVuqx1trPe(u"ࠪ࠳࡫࠵ࠧब") in ynmiDuav5ICTeRsqj6Vb18Q: items = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪभ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		elif V2RQwM8XjlrK(u"ࠬ࠵ࡶ࠰ࠩम") in ynmiDuav5ICTeRsqj6Vb18Q: items = RSuYINdeamsK0t.findall(g7yJo2LVuqx1trPe(u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪय"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if items: return [],[Vk54F7GcROfCy6HunEI],[ items[ufmXvxgoHGDwZtjsLkR05i] ]
		elif WsklGNp2CYzVQUag(u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭र") in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			return ESXZrtnCfcDJGo01vFg(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫऱ"),[],[]
	else: return SSBkx0WbN1asnDCQV6tIj(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬल"),[],[]
def vvkMu57igz(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	itb54hH6eAY = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬळ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࠫࠬࠧऴ"),RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	aPlrVesU3WkF79DXxAT8jHSECq6Q,rqMLoZpDlPfi95u = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
	url = MpJ8GOKoic(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭व")+aPlrVesU3WkF79DXxAT8jHSECq6Q+WsklGNp2CYzVQUag(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪश")+rqMLoZpDlPfi95u
	headers = { SSBkx0WbN1asnDCQV6tIj(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫष"):Vk54F7GcROfCy6HunEI , MzgKWUQ4V5H(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫस"):l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪह") }
	hj50MJnoOp6ZWaS1IQ8Elr = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩऺ"))
	return wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧऻ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
def oCAyOMBasc(url):
	oOv4sVqEAmyM = RRav1Sf7Px(url,NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡻࡲ࡭़ࠩ"))
	eDbTIrV6KLfz80 = {Nlyfx1HnzOWCovke5(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧऽ"):oOv4sVqEAmyM,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩा"):wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨि")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡊࡉ࡙࠭ी"),url,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪु"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬू"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = Vk54F7GcROfCy6HunEI
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
		items = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫृ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==pwxH3oREFm5v98BCZ1QVtzMJOc: hj50MJnoOp6ZWaS1IQ8Elr = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[ufmXvxgoHGDwZtjsLkR05i]
		elif len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)>pwxH3oREFm5v98BCZ1QVtzMJOc:
			qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(V2RQwM8XjlrK(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫॄ"), nWcb8JC7zEVouFjx9fILGh1vSQ)
			if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॅ"),[],[]
			hj50MJnoOp6ZWaS1IQ8Elr = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॆ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: hj50MJnoOp6ZWaS1IQ8Elr = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
	if not hj50MJnoOp6ZWaS1IQ8Elr: return eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡃࡊࡏࡄࠫे"),[],[]
	return FGLEMi21Bfn(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ै"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
def kSiFC7Tna0mw(url):
	oOv4sVqEAmyM = RRav1Sf7Px(url,ynxXU3gaiQ9GPCftr1q(u"ࠫࡺࡸ࡬ࠨॉ"))
	eDbTIrV6KLfz80 = {ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ॊ"):oOv4sVqEAmyM,g7yJo2LVuqx1trPe(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨो"):ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧौ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,MpJ8GOKoic(u"ࠨࡉࡈࡘ्ࠬ"),url,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩॎ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫॏ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = Vk54F7GcROfCy6HunEI
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
		items = RSuYINdeamsK0t.findall(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪॐ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==pwxH3oREFm5v98BCZ1QVtzMJOc: hj50MJnoOp6ZWaS1IQ8Elr = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[ufmXvxgoHGDwZtjsLkR05i]
		elif len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)>pwxH3oREFm5v98BCZ1QVtzMJOc:
			qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(WCPwmyVsb62KRlo(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ॑"),nWcb8JC7zEVouFjx9fILGh1vSQ)
			if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖ॒ࠫ"),[],[]
			hj50MJnoOp6ZWaS1IQ8Elr = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	if not hj50MJnoOp6ZWaS1IQ8Elr:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ॓"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh: hj50MJnoOp6ZWaS1IQ8Elr = Ry3L7fdNGh[ufmXvxgoHGDwZtjsLkR05i]
	if not hj50MJnoOp6ZWaS1IQ8Elr: return MpJ8GOKoic(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪ॔"),[],[]
	return wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॕ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
def JfhGnxkT0C(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	itb54hH6eAY = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩॖ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp+WXuJd8nz2spo146t(u"ࠫࠫࠬࠧॗ"),RSuYINdeamsK0t.DOTALL)
	url,aPlrVesU3WkF79DXxAT8jHSECq6Q,rqMLoZpDlPfi95u = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
	data = {eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭क़"):aPlrVesU3WkF79DXxAT8jHSECq6Q,g7yJo2LVuqx1trPe(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ख़"):rqMLoZpDlPfi95u}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡑࡑࡖࡘࠬग़"),url,data,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪज़"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧड़"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[ufmXvxgoHGDwZtjsLkR05i]
	return SSBkx0WbN1asnDCQV6tIj(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ढ़"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
def xWmilpNGzf(url):
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡄࡹࡥࡳࡸࡀࠫफ़") in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,pnkrd2S84FJfN73KuiCYv(u"ࠬࡍࡅࡕࠩय़"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳࠱ࡴࡶࠪॠ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॡ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		else: return WXuJd8nz2spo146t(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧॢ"),[],[]
	return MpJ8GOKoic(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॣ"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def Z89L0fSra1(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,cpHxZyU7vTtqmIw(u"ࠪࡋࡊ࡚ࠧ।"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ॥"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭०"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return QYSAUI5r46yil8cfaO(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ१"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return MzgKWUQ4V5H(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ२"),[],[]
def xzMblkIAKs(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡉࡈࡘࠬ३"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ४"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(WXuJd8nz2spo146t(u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ५"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[ufmXvxgoHGDwZtjsLkR05i]
	return BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ६"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def rm87i5wn64(url):
	zxAP2BC6ekOXpHnwF = RRav1Sf7Px(url,QYSAUI5r46yil8cfaO(u"ࠬࡻࡲ࡭ࠩ७"))
	if YzowicIDTRusXZSU61(u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭८") in url:
		headers = {kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ९"):zxAP2BC6ekOXpHnwF}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,cpHxZyU7vTtqmIw(u"ࠨࡉࡈࡘࠬ॰"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪॱ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॲ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if hj50MJnoOp6ZWaS1IQ8Elr:
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]
			if FGLEMi21Bfn(u"ࠫ࡭ࡺࡴࡱࠩॳ") not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = SSBkx0WbN1asnDCQV6tIj(u"ࠬ࡮ࡴࡵࡲ࠽ࠫॴ")+hj50MJnoOp6ZWaS1IQ8Elr
			if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧॵ") in hj50MJnoOp6ZWaS1IQ8Elr:
				Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,wAU9jKvmTM0(u"ࠧࡈࡇࡗࠫॶ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩॷ"))
				nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
				items = RSuYINdeamsK0t.findall(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॸ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
				if not items:
					Ry3L7fdNGh = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣ࡜࠯ࠩॹ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
					if Ry3L7fdNGh:
						v8e07ENZbVzIjaMSQPAxLUyuKcWho = Ry3L7fdNGh[EM6qpnCBYQGA9kbgDVLfrP(u"࠶ඁ")]
						items = RSuYINdeamsK0t.findall(NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࠧࡢ࡛ࠩ࠰࠭ࡃ࠮ࡢ࡝ࠡࠪ࠱࠮ࡄ࠯ࠢࠨॺ"),v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
						if items:
							XKafoh0Dz9NnYuwA6tpCj1FdqZ4V,vvqUulpOEReVMx0rZ9h84Knz = zip(*items)
							items = list(zip(vvqUulpOEReVMx0rZ9h84Knz,XKafoh0Dz9NnYuwA6tpCj1FdqZ4V))
				nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
				iFJVwrXDlfRUKN20 = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,WXuJd8nz2spo146t(u"ࠬࡻࡲ࡭ࠩॻ"))
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns in reversed(items):
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = iFJVwrXDlfRUKN20+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+XCYALgFs2O3hZdpHrlMmB(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩॼ")+iFJVwrXDlfRUKN20
					nWcb8JC7zEVouFjx9fILGh1vSQ.append(jMiru3pGns)
					yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
			else: return MzgKWUQ4V5H(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪॽ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	hj50MJnoOp6ZWaS1IQ8Elr = url+MpJ8GOKoic(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫॾ")+zxAP2BC6ekOXpHnwF
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࡫ࡸࡹࡶࠧॿ") not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = FGLEMi21Bfn(u"ࠪ࡬ࡹࡺࡰ࠻ࠩঀ")+hj50MJnoOp6ZWaS1IQ8Elr
	return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
def b0mhCdWPYgraKxRHntjqAUE1(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	zxAP2BC6ekOXpHnwF = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,MzgKWUQ4V5H(u"ࠫࡺࡸ࡬ࠨঁ"))
	if EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬং") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		itb54hH6eAY = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬঃ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࠧࠨࠪ঄"),RSuYINdeamsK0t.DOTALL)
		url,aPlrVesU3WkF79DXxAT8jHSECq6Q,rqMLoZpDlPfi95u = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
		data = {eAMGzHRQVs2KyCwPXljYhB(u"ࠨ࡫ࡧࠫঅ"):aPlrVesU3WkF79DXxAT8jHSECq6Q,MzgKWUQ4V5H(u"ࠩࡶࡩࡷࡼࡥࡳࠩআ"):rqMLoZpDlPfi95u}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡔࡔ࡙ࡔࠨই"),url,data,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬঈ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(eAMGzHRQVs2KyCwPXljYhB(u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪউ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[ufmXvxgoHGDwZtjsLkR05i]
		if ESXZrtnCfcDJGo01vFg(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧঊ") in hj50MJnoOp6ZWaS1IQ8Elr:
			headers = {wAU9jKvmTM0(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨঋ"):zxAP2BC6ekOXpHnwF,cpHxZyU7vTtqmIw(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬঌ"):Vk54F7GcROfCy6HunEI}
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡊࡉ࡙࠭঍"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ঎"))
			nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			items = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪএ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
			iFJVwrXDlfRUKN20 = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,g7yJo2LVuqx1trPe(u"ࠬࡻࡲ࡭ࠩঐ"))
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jMiru3pGns in reversed(items):
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = iFJVwrXDlfRUKN20+ssfLBvkuNiXear2gPdxcyT4AQMhYSp+g7yJo2LVuqx1trPe(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ঑")+iFJVwrXDlfRUKN20
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(jMiru3pGns)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
		else: return QYSAUI5r46yil8cfaO(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ঒"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	else:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+cpHxZyU7vTtqmIw(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫও")+zxAP2BC6ekOXpHnwF
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
def UlyBdnX14x(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	if SSBkx0WbN1asnDCQV6tIj(u"ࠩࡳࡳࡸࡺࡩࡥࠩঔ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		itb54hH6eAY = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬক"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp+EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࠫࠬࠧখ"),RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		aPlrVesU3WkF79DXxAT8jHSECq6Q,rqMLoZpDlPfi95u = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
		J37JeAXWmvduKoc = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,ESXZrtnCfcDJGo01vFg(u"ࠬࡻࡲ࡭ࠩগ"))
		url = J37JeAXWmvduKoc+YzowicIDTRusXZSU61(u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫঘ")+aPlrVesU3WkF79DXxAT8jHSECq6Q+EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫঙ")+rqMLoZpDlPfi95u
		headers = { HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬচ"):Vk54F7GcROfCy6HunEI , kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬছ"):kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫজ") }
		hj50MJnoOp6ZWaS1IQ8Elr = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭ঝ"))
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)
		return WsklGNp2CYzVQUag(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨঞ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪট") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		RRQ2wKuh8BJfde0Zr = ufmXvxgoHGDwZtjsLkR05i
		while YzowicIDTRusXZSU61(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫঠ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and RRQ2wKuh8BJfde0Zr<XCYALgFs2O3hZdpHrlMmB(u"࠵ං"):
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡉࡈࡘࠬড"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫঢ"))
			if XCYALgFs2O3hZdpHrlMmB(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬণ") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[g7yJo2LVuqx1trPe(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ত")]
			RRQ2wKuh8BJfde0Zr += pwxH3oREFm5v98BCZ1QVtzMJOc
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	else: return kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩথ"),[],[]
def fsHGYLNI5R(url):
	oOv4sVqEAmyM = RRav1Sf7Px(url,pnkrd2S84FJfN73KuiCYv(u"࠭ࡵࡳ࡮ࠪদ"))
	headers = {ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨধ"):oOv4sVqEAmyM,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬন"):p3QOAkrEuys81JqHobh()}
	if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ঩") in url:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬপ"))
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪফ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i].replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠬ࡮ࡴࡵࡲࡶࠫব"),XCYALgFs2O3hZdpHrlMmB(u"࠭ࡨࡵࡶࡳࠫভ"))
			return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	else:
		UjngGi2LuTM1X53Ih6HdSAPlQ0ZCr = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,g7yJo2LVuqx1trPe(u"ࠧࡈࡇࡗࠫম"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪয"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = UjngGi2LuTM1X53Ih6HdSAPlQ0ZCr.content
		eDbTIrV6KLfz80 = headers.copy()
		if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡢࡰࡳࡱ࡟ࠨর") in str(UjngGi2LuTM1X53Ih6HdSAPlQ0ZCr.cookies):
			cookies = UjngGi2LuTM1X53Ih6HdSAPlQ0ZCr.cookies
			eDbTIrV6KLfz80[V2RQwM8XjlrK(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ঱")] = ZlBMJUAWRm9buv(weWxHqLyORY4NfBbGQmgc53F1E8UVz(cookies))
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠫࡱ࡯࡮࡬࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧল"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return YzowicIDTRusXZSU61(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ঳"),[Vk54F7GcROfCy6HunEI],[url]
		else:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i])+g7yJo2LVuqx1trPe(u"࠭ࠦࡥ࠿࠴ࠫ঴")
			HHA0ZI3kaPXocl7CsGjr = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡈࡇࡗࠫ঵"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪশ"))
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = HHA0ZI3kaPXocl7CsGjr.content
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬষ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i])
				if pnkrd2S84FJfN73KuiCYv(u"ࠪࡱࡵ࠺ࠧস") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࠴ࡪ࠯ࠨহ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
				else: return FGLEMi21Bfn(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ঺"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ঻"),[],[]
def RTvsb4O16t(ssfLBvkuNiXear2gPdxcyT4AQMhYSp):
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵ়ࠫ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		headers = {QYSAUI5r46yil8cfaO(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫঽ"):SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪা")}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡋࡊ࡚ࠧি"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭ী"))
		url = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if url: return WCPwmyVsb62KRlo(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨু"),[Vk54F7GcROfCy6HunEI],[url]
	else:
		itb54hH6eAY = RSuYINdeamsK0t.findall(eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧূ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if not itb54hH6eAY: itb54hH6eAY = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠧࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪৃ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		aPlrVesU3WkF79DXxAT8jHSECq6Q,rqMLoZpDlPfi95u = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
		oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡷࡵࡰࠬৄ"))
		url = oOv4sVqEAmyM+QYSAUI5r46yil8cfaO(u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ৅")
		data = {g7yJo2LVuqx1trPe(u"ࠪ࡭ࡩ࠭৆"):aPlrVesU3WkF79DXxAT8jHSECq6Q,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫ࡮࠭ে"):rqMLoZpDlPfi95u}
		headers = {wAU9jKvmTM0(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨৈ"):ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ৉"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ৊"):ssfLBvkuNiXear2gPdxcyT4AQMhYSp}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡒࡒࡗ࡙࠭ো"),url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫৌ"))
		nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ্"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if hj50MJnoOp6ZWaS1IQ8Elr:
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i]
			return NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧৎ"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	return FGLEMi21Bfn(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ৏"),[],[]
def Eiw38JANxcVHMWlF5m12CUKPohQ9ZO(LLiQgfhbvJ3VCX7jr):
	lCwIkQ4n1o = cad8TeSyMUYmfsEO0.getSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ৐"))
	headers = {NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ৑"):lCwIkQ4n1o} if lCwIkQ4n1o else Vk54F7GcROfCy6HunEI
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡉࡈࡘࠬ৒"),LLiQgfhbvJ3VCX7jr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠷ࡳࡵࠩ৓"))
	ImO4Ft6DnX = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ke4Sd8TVh3cAxPLfItHk = str(Iy3PA1SVXNfjOchtgHC5kuJBG.headers)
	ZhLKEoFg5kJ = Ke4Sd8TVh3cAxPLfItHk+ImO4Ft6DnX
	if ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪ࠲ࡲࡶ࠴ࠨ৔") in ZhLKEoFg5kJ: ydWEcgbFm0lNr42a8 = YOHXqtbQTBfKerIZ
	else:
		MMaXl7rYtwHcPZU3028OGpLosDe,cVbGQZ5wHCNO6pU8nKt2Ji,QZYB7Xmf3NbEjgi49x,C7P2pSw08jol5VIuJcaU9,ydWEcgbFm0lNr42a8 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I
		captcha = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৕"),ImO4Ft6DnX,RSuYINdeamsK0t.DOTALL)
		if captcha: QZYB7Xmf3NbEjgi49x,C7P2pSw08jol5VIuJcaU9 = captcha[ufmXvxgoHGDwZtjsLkR05i]
		FAWo3YN5i4n7LwMSuQXDGZ6b = h9zFQKnsNL.SITESURLS[Nlyfx1HnzOWCovke5(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ৖")][YzowicIDTRusXZSU61(u"࠸ඃ")]
		if ufmXvxgoHGDwZtjsLkR05i:
			data = {wAU9jKvmTM0(u"࠭ࡵࡴࡧࡵࠫৗ"):h9zFQKnsNL.AV_CLIENT_IDS,MzgKWUQ4V5H(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ৘"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡷࡵࡰࠬ৙"):LLiQgfhbvJ3VCX7jr,NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡮ࡩࡾ࠭৚"):C7P2pSw08jol5VIuJcaU9,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡭ࡩ࠭৛"):Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࡯ࡵࡢࠨড়"):ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭ঢ়")}
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,pnkrd2S84FJfN73KuiCYv(u"࠭ࡐࡐࡕࡗࠫ৞"),FAWo3YN5i4n7LwMSuQXDGZ6b,data,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧয়"))
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Vk54F7GcROfCy6HunEI
		if FjwObZSWkg8ahBdiQf9IeY135DpXoP.startswith(WsklGNp2CYzVQUag(u"ࠨࡗࡕࡐࡘࡃࠧৠ")):
			q3U5kprDyzQMwIu2ONZsxBc41aEtKT = Bw6jaUcFxlqdDT8bC(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡯࡭ࡸࡺࠧৡ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP.split(g7yJo2LVuqx1trPe(u"࡙ࠪࡗࡒࡓ࠾ࠩৢ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc])
			for MmpRngPUCzrJ0HlGfB in q3U5kprDyzQMwIu2ONZsxBc41aEtKT:
				url = MmpRngPUCzrJ0HlGfB[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡺࡸ࡬ࠨৣ")]
				n36U48jsVv = MmpRngPUCzrJ0HlGfB[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡳࡥࡵࡪࡲࡨࠬ৤")]
				data = MmpRngPUCzrJ0HlGfB[EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡤࡢࡶࡤࠫ৥")]
				headers = MmpRngPUCzrJ0HlGfB[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨ০")]
				Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,n36U48jsVv,url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ১"))
				ImO4Ft6DnX = Iy3PA1SVXNfjOchtgHC5kuJBG.content
				if XCYALgFs2O3hZdpHrlMmB(u"ࠩ࠱ࡱࡵ࠺ࠧ২") in ImO4Ft6DnX:
					ydWEcgbFm0lNr42a8 = YOHXqtbQTBfKerIZ
					break
				Ke4Sd8TVh3cAxPLfItHk = str(Iy3PA1SVXNfjOchtgHC5kuJBG.headers)
				ZhLKEoFg5kJ = Ke4Sd8TVh3cAxPLfItHk+ImO4Ft6DnX
				MMaXl7rYtwHcPZU3028OGpLosDe = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫ৩"),ZhLKEoFg5kJ,RSuYINdeamsK0t.DOTALL)
				cVbGQZ5wHCNO6pU8nKt2Ji = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬ৪"),ZhLKEoFg5kJ,RSuYINdeamsK0t.DOTALL)
				if cVbGQZ5wHCNO6pU8nKt2Ji: cVbGQZ5wHCNO6pU8nKt2Ji = cVbGQZ5wHCNO6pU8nKt2Ji[ufmXvxgoHGDwZtjsLkR05i]
				if MMaXl7rYtwHcPZU3028OGpLosDe or cVbGQZ5wHCNO6pU8nKt2Ji: break
		if not ydWEcgbFm0lNr42a8:
			if not MMaXl7rYtwHcPZU3028OGpLosDe:
				if captcha and not cVbGQZ5wHCNO6pU8nKt2Ji:
					if pwxH3oREFm5v98BCZ1QVtzMJOc: cVbGQZ5wHCNO6pU8nKt2Ji = ghFlf6dBacuQC8TXIWzS0Dno5Nq7(C7P2pSw08jol5VIuJcaU9,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡧࡲࠨ৫"),LLiQgfhbvJ3VCX7jr)
					else:
						if not FjwObZSWkg8ahBdiQf9IeY135DpXoP.startswith(WsklGNp2CYzVQUag(u"࠭ࡉࡅ࠿ࠪ৬")):
							data = {kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡶࡵࡨࡶࠬ৭"):h9zFQKnsNL.AV_CLIENT_IDS,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ৮"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,ynxXU3gaiQ9GPCftr1q(u"ࠩࡸࡶࡱ࠭৯"):LLiQgfhbvJ3VCX7jr,WXuJd8nz2spo146t(u"ࠪ࡯ࡪࡿࠧৰ"):C7P2pSw08jol5VIuJcaU9,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࡮ࡪࠧৱ"):Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡰ࡯ࡣࠩ৲"):NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡧࡦࡶ࡬ࡨࠬ৳")}
							Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡑࡑࡖࡘࠬ৴"),FAWo3YN5i4n7LwMSuQXDGZ6b,data,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨ৵"))
							FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
						else: FjwObZSWkg8ahBdiQf9IeY135DpXoP = g7yJo2LVuqx1trPe(u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪ৶")
						if FjwObZSWkg8ahBdiQf9IeY135DpXoP.startswith(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡍࡉࡃࠧ৷")):
							oYkArlvez1Uyctu0RXijN = RSuYINdeamsK0t.findall(WCPwmyVsb62KRlo(u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪ৸"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
							qqgO5vA7CGYQaHJi,e98nIYDOZyX05Tf3io2dpV = oYkArlvez1Uyctu0RXijN[ufmXvxgoHGDwZtjsLkR05i]
							BadMOTrh9Lnp0w6KZCQASE4uyk7fW = XCYALgFs2O3hZdpHrlMmB(u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪ৹")+e98nIYDOZyX05Tf3io2dpV+Nlyfx1HnzOWCovke5(u"࠭ࠠฬษ้๎ฮ࠭৺")
							uuyUxZ8tM1 = LfgAx0QSMK59hF()
							uuyUxZ8tM1.create(g7yJo2LVuqx1trPe(u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭৻"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
							dzM9knRJOQS7K = Gb6kwVlSQ4MU.time()
							E52h9nzdxK,qU3HsBa4SOyW = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
							while E52h9nzdxK<int(e98nIYDOZyX05Tf3io2dpV):
								yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,int(E52h9nzdxK/int(e98nIYDOZyX05Tf3io2dpV)*wAU9jKvmTM0(u"࠳࠳࠴඄")),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,Vk54F7GcROfCy6HunEI,e98nIYDOZyX05Tf3io2dpV+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࠢ࠲ࠤࠬৼ")+str(int(E52h9nzdxK))+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࠣࠤะอๆ๋หࠪ৽"))
								if E52h9nzdxK>qU3HsBa4SOyW+EM6qpnCBYQGA9kbgDVLfrP(u"࠴࠴අ"):
									data = {QYSAUI5r46yil8cfaO(u"ࠪࡹࡸ࡫ࡲࠨ৾"):h9zFQKnsNL.AV_CLIENT_IDS,ynxXU3gaiQ9GPCftr1q(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ৿"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,WXuJd8nz2spo146t(u"ࠬࡻࡲ࡭ࠩ਀"):LLiQgfhbvJ3VCX7jr,wYTDlJC5vpOKynUEX3ge6W(u"࠭࡫ࡦࡻࠪਁ"):C7P2pSw08jol5VIuJcaU9,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡪࡦࠪਂ"):qqgO5vA7CGYQaHJi,QYSAUI5r46yil8cfaO(u"ࠨ࡬ࡲࡦࠬਃ"):WsklGNp2CYzVQUag(u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫ਄")}
									Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡔࡔ࡙ࡔࠨਅ"),FAWo3YN5i4n7LwMSuQXDGZ6b,data,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫਆ"))
									FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
									if FjwObZSWkg8ahBdiQf9IeY135DpXoP.startswith(pnkrd2S84FJfN73KuiCYv(u"࡚ࠬࡏࡌࡇࡑࡁࠬਇ")):
										cVbGQZ5wHCNO6pU8nKt2Ji = FjwObZSWkg8ahBdiQf9IeY135DpXoP.split(QYSAUI5r46yil8cfaO(u"࠭ࡔࡐࡍࡈࡒࡂ࠭ਈ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠵ආ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
										break
									qU3HsBa4SOyW = E52h9nzdxK
								else: Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
								E52h9nzdxK = Gb6kwVlSQ4MU.time()-dzM9knRJOQS7K
							uuyUxZ8tM1.close()
				if cVbGQZ5wHCNO6pU8nKt2Ji:
					EZfA4wad1mK9SXCRcjGzIN8xiB = Iy3PA1SVXNfjOchtgHC5kuJBG.cookies
					Culrvnk2GYSIFWLt5x4O3N8we7ZiBK = RSuYINdeamsK0t.findall(YzowicIDTRusXZSU61(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧਉ"),ZhLKEoFg5kJ,RSuYINdeamsK0t.DOTALL)
					if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨਊ") in list(EZfA4wad1mK9SXCRcjGzIN8xiB.keys()): Culrvnk2GYSIFWLt5x4O3N8we7ZiBK = EZfA4wad1mK9SXCRcjGzIN8xiB[EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ਋")]
					elif Culrvnk2GYSIFWLt5x4O3N8we7ZiBK: Culrvnk2GYSIFWLt5x4O3N8we7ZiBK = Culrvnk2GYSIFWLt5x4O3N8we7ZiBK[ufmXvxgoHGDwZtjsLkR05i]
					captcha = RSuYINdeamsK0t.findall(V2RQwM8XjlrK(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਌"),ImO4Ft6DnX,RSuYINdeamsK0t.DOTALL)
					if captcha: QZYB7Xmf3NbEjgi49x,C7P2pSw08jol5VIuJcaU9 = captcha[ufmXvxgoHGDwZtjsLkR05i]
					if Culrvnk2GYSIFWLt5x4O3N8we7ZiBK and captcha:
						headers = {ESXZrtnCfcDJGo01vFg(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ਍"):wAU9jKvmTM0(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭਎")+Culrvnk2GYSIFWLt5x4O3N8we7ZiBK,MpJ8GOKoic(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਏ"):LLiQgfhbvJ3VCX7jr,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ਐ"):wAU9jKvmTM0(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ਑")}
						data = EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠪ਒")+cVbGQZ5wHCNO6pU8nKt2Ji
						Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,FGLEMi21Bfn(u"ࠪࡔࡔ࡙ࡔࠨਓ"),QZYB7Xmf3NbEjgi49x,data,headers,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫਔ"))
						ImO4Ft6DnX = Iy3PA1SVXNfjOchtgHC5kuJBG.content
						try: cookies = Iy3PA1SVXNfjOchtgHC5kuJBG.cookies
						except: cookies = {}
						MMaXl7rYtwHcPZU3028OGpLosDe = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦਕ"),str(cookies),RSuYINdeamsK0t.DOTALL)
			if MMaXl7rYtwHcPZU3028OGpLosDe:
				EDy0Rs9liwjZvJY,MMaXl7rYtwHcPZU3028OGpLosDe = MMaXl7rYtwHcPZU3028OGpLosDe[ufmXvxgoHGDwZtjsLkR05i]
				lCwIkQ4n1o = EDy0Rs9liwjZvJY+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭࠽ࠨਖ")+MMaXl7rYtwHcPZU3028OGpLosDe
				cad8TeSyMUYmfsEO0.setSetting(V2RQwM8XjlrK(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨਗ"),lCwIkQ4n1o)
				GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫਘ"),pnkrd2S84FJfN73KuiCYv(u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭ਙ"))
				if WCPwmyVsb62KRlo(u"ࠪ࠲ࡲࡶ࠴ࠨਚ") not in ImO4Ft6DnX:
					headers = {wAU9jKvmTM0(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫਛ"):lCwIkQ4n1o}
					Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡍࡅࡕࠩਜ"),LLiQgfhbvJ3VCX7jr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭ਝ"))
					ImO4Ft6DnX = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if not ydWEcgbFm0lNr42a8 and not lCwIkQ4n1o: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਞ"),YzowicIDTRusXZSU61(u"ࠨใื่ฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨਟ"))
	return ImO4Ft6DnX
def KIO4XePNEd(url,WypSQTO7504tHY,jMiru3pGns):
	MMJL8QqY6T7dv1onu,t8tfMv1VXZYQ5y3 = [],[]
	LLiQgfhbvJ3VCX7jr = url
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,jXWzIZcDva4ikEUfN(u"ࠩࡊࡉ࡙࠭ਠ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠷ࡳࡵࠩਡ"))
	nqzvfpjFuS42ywk8 = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Qf8yxXpgChkG43z76DUMaWc2b = []
	if YzowicIDTRusXZSU61(u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬਢ") in nqzvfpjFuS42ywk8 or XCYALgFs2O3hZdpHrlMmB(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩਣ") in nqzvfpjFuS42ywk8:
		DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵ࠴ࠪࡀ࠾࠲ࡥࡃ࠭ਤ"),nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
		if DatFuedGb45zR1KqIWNk:
			for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
				HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫਥ"),UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in HXhRgxEZ4d2Dek:
					if ssfLBvkuNiXear2gPdxcyT4AQMhYSp in MMJL8QqY6T7dv1onu: continue
					if eAMGzHRQVs2KyCwPXljYhB(u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩਦ") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp and QYSAUI5r46yil8cfaO(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ਧ") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
					if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪหࠬਨ") not in title:
						Qf8yxXpgChkG43z76DUMaWc2b.append((title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp))
						continue
					title = title.replace(MpJ8GOKoic(u"ࠫࡁ࠵ࡳࡱࡣࡱࡂࠬ਩"),Vk54F7GcROfCy6HunEI).replace(Nlyfx1HnzOWCovke5(u"ࠬࠦ࠭ࠡࠩਪ"),Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
					if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡳࡱࡣࡱࠫਫ") in title: continue
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
					t8tfMv1VXZYQ5y3.append(title)
			for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in Qf8yxXpgChkG43z76DUMaWc2b:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in MMJL8QqY6T7dv1onu:
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
					t8tfMv1VXZYQ5y3.append(title)
			qreJEpY8nZguD = ufmXvxgoHGDwZtjsLkR05i
			if len(MMJL8QqY6T7dv1onu)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧษ฻ู๋ฬ๊ࠦฮฬสะࠥ࠼࠰ࠡอส๊๏ฯࠧਬ"),t8tfMv1VXZYQ5y3)
				if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return QYSAUI5r46yil8cfaO(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ਭ"),[],[]
			if MMJL8QqY6T7dv1onu and qreJEpY8nZguD>=ufmXvxgoHGDwZtjsLkR05i: LLiQgfhbvJ3VCX7jr = MMJL8QqY6T7dv1onu[qreJEpY8nZguD]
	ImO4Ft6DnX = Eiw38JANxcVHMWlF5m12CUKPohQ9ZO(LLiQgfhbvJ3VCX7jr)
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,nWcb8JC7zEVouFjx9fILGh1vSQ = [],[]
	if WypSQTO7504tHY==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫਮ"):
		oKyeRTrpxGzEFMV435Cu7 = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਯ"),ImO4Ft6DnX,RSuYINdeamsK0t.DOTALL)
		if oKyeRTrpxGzEFMV435Cu7:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(oKyeRTrpxGzEFMV435Cu7[ufmXvxgoHGDwZtjsLkR05i])
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(jMiru3pGns)
	elif WypSQTO7504tHY==g7yJo2LVuqx1trPe(u"ࠫࡼࡧࡴࡤࡪࠪਰ"):
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall(pnkrd2S84FJfN73KuiCYv(u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ਱"),ImO4Ft6DnX,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,size in HXhRgxEZ4d2Dek:
			if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
			if jMiru3pGns in size:
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(size)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				break
		if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,size in HXhRgxEZ4d2Dek:
				if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: continue
				nWcb8JC7zEVouFjx9fILGh1vSQ.append(size)
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: return ESXZrtnCfcDJGo01vFg(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧਲ"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def cU2pfFhDjH(url,EDy0Rs9liwjZvJY):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MzgKWUQ4V5H(u"ࠧࡈࡇࡗࠫਲ਼"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧ਴"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	cookies = Iy3PA1SVXNfjOchtgHC5kuJBG.cookies
	if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩਵ") in list(cookies.keys()):
		lCwIkQ4n1o = cookies[WCPwmyVsb62KRlo(u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪਸ਼")]
		lCwIkQ4n1o = ZlBMJUAWRm9buv(ww25jXuxtpK1TOJEbGUgrm8(lCwIkQ4n1o))
		items = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"ࠫࡷࡵࡵࡵࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ਷"),lCwIkQ4n1o,RSuYINdeamsK0t.DOTALL)
		hj50MJnoOp6ZWaS1IQ8Elr = items[ufmXvxgoHGDwZtjsLkR05i].replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡢ࠯ࠨਸ"),WCPwmyVsb62KRlo(u"࠭࠯ࠨਹ"))
		hj50MJnoOp6ZWaS1IQ8Elr = ww25jXuxtpK1TOJEbGUgrm8(hj50MJnoOp6ZWaS1IQ8Elr)
	else: hj50MJnoOp6ZWaS1IQ8Elr = url
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ਺") in hj50MJnoOp6ZWaS1IQ8Elr:
		hbQR8K2TxmVruswlDGNcCEkv = hj50MJnoOp6ZWaS1IQ8Elr.split(WsklGNp2CYzVQUag(u"ࠨࠧ࠵ࡊࠬ਻"))[-pwxH3oREFm5v98BCZ1QVtzMJOc]
		hj50MJnoOp6ZWaS1IQ8Elr = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡥࡹࡩࡨ࠯࡫ࡶ࠳਼ࠬ")+hbQR8K2TxmVruswlDGNcCEkv
		return ynxXU3gaiQ9GPCftr1q(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭਽"),[Vk54F7GcROfCy6HunEI],[hj50MJnoOp6ZWaS1IQ8Elr]
	else:
		website = h9zFQKnsNL.SITESURLS[eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡆࡑࡏࡂࡏࠪਾ")][ufmXvxgoHGDwZtjsLkR05i]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,QYSAUI5r46yil8cfaO(u"ࠬࡍࡅࡕࠩਿ"),website,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬੀ"))
		eJd8trajHfWqBgh7LkU = Iy3PA1SVXNfjOchtgHC5kuJBG.url
		sHJFpPan6Gz0SWqgCXQ3jlAUm5et7E = hj50MJnoOp6ZWaS1IQ8Elr.split(wYTDlJC5vpOKynUEX3ge6W(u"ࠧ࠰ࠩੁ"))[RXnhpCUk4M1TvgJE]
		LLzKRSnmNi5Wuocjx9JkbhAIlp = eJd8trajHfWqBgh7LkU.split(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࠱ࠪੂ"))[RXnhpCUk4M1TvgJE]
		ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr.replace(sHJFpPan6Gz0SWqgCXQ3jlAUm5et7E,LLzKRSnmNi5Wuocjx9JkbhAIlp)
		headers = { l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭੃"):Vk54F7GcROfCy6HunEI , FGLEMi21Bfn(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭੄"):BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ੅") , BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭੆"):ynmiDuav5ICTeRsqj6Vb18Q }
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,XCYALgFs2O3hZdpHrlMmB(u"࠭ࡐࡐࡕࡗࠫੇ"), ynmiDuav5ICTeRsqj6Vb18Q, Vk54F7GcROfCy6HunEI, headers, eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭ੈ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		items = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੉"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if not items:
			items = RSuYINdeamsK0t.findall(WXuJd8nz2spo146t(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ੊"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
			if not items:
				items = RSuYINdeamsK0t.findall(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪੋ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
		if items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[ufmXvxgoHGDwZtjsLkR05i].replace(g7yJo2LVuqx1trPe(u"ࠫࡡ࠵ࠧੌ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬ࠵੍ࠧ"))
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.rstrip(WXuJd8nz2spo146t(u"࠭࠯ࠨ੎"))
			if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡩࡶࡷࡴࠬ੏") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡪࡷࡸࡵࡀࠧ੐") + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(cpHxZyU7vTtqmIw(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪੑ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ੒"))
			if EDy0Rs9liwjZvJY==Vk54F7GcROfCy6HunEI: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
			else: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Nlyfx1HnzOWCovke5(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ੓"),[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
		else: Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = cpHxZyU7vTtqmIw(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭੔"),[],[]
		return Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def p6m5OUzRc93ZTouexVbriQnFKY(url):
	headers = { wAU9jKvmTM0(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ੕") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ੖"))
	items = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੗"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,errno = [],[],Vk54F7GcROfCy6HunEI
	if items:
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,fqNDhEb7ic5rH2K9Rx in items:
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(fqNDhEb7ic5rH2K9Rx)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏࠨ੘"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def r6MDK7TQcuIWNeA450g2ZGyBx3kt1(url):
	w9UG3QYd7oV51ryigjs6kMO = url.split(wAU9jKvmTM0(u"ࠪ࠳ࠬਖ਼"))[NNjUsZzEcFOAoKry2CDMgb1(u"࠸ඇ")]
	data = QYSAUI5r46yil8cfaO(u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠩ࡭ࡩࡃࠧਗ਼")+w9UG3QYd7oV51ryigjs6kMO
	headers = {XCYALgFs2O3hZdpHrlMmB(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫਜ਼"):kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬੜ")}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡑࡑࡖࡘࠬ੝"),url,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡘࡄࡍ࠯࠴ࡷࡹ࠭ਫ਼"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡤࡨࡧࡲ࡯ࡤ࡭ࡢࡨࡪࡺࡥࡤࡶࡨࡨ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੟"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		url = items[ufmXvxgoHGDwZtjsLkR05i]
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	return SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡒࡅࡎࠪ੠"),[],[]
def a0eFS9pzw42Ayob(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,WCPwmyVsb62KRlo(u"ࠫࡌࡋࡔࠨ੡"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡎ࠱࠶ࡹࡴࠨ੢"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	try: FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.decode(jXWzIZcDva4ikEUfN(u"࠭ࡵࡵࡨ࠻ࠫ੣"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ੤"))
	except: pass
	items = RSuYINdeamsK0t.findall(ESXZrtnCfcDJGo01vFg(u"ࠨࡦࡲࡧࡸࡥ࡮ࡰࡡࡳࡶࡪࡼࡩࡦࡹࡢࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੥"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		url = items[ufmXvxgoHGDwZtjsLkR05i]
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	return WCPwmyVsb62KRlo(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡑࠧ੦"),[],[]
def ECDu5f3Fog(url):
	headers = {ESXZrtnCfcDJGo01vFg(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ੧"):Vk54F7GcROfCy6HunEI}
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ੨"))
	items = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ੩"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		url = items[ufmXvxgoHGDwZtjsLkR05i]+WXuJd8nz2spo146t(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ੪")+url
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	return MzgKWUQ4V5H(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩ੫"),[],[]
def PV3kOwAI1Gm9WLBroa4Xv5sbK(url):
	url = url.strip(SSBkx0WbN1asnDCQV6tIj(u"ࠨ࠱ࠪ੬"))
	if wAU9jKvmTM0(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ੭") in url: hbQR8K2TxmVruswlDGNcCEkv = url.split(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࠳ࠬ੮"))[BZm7TqLPJfAVblDKsya85zFWXNMY]
	else: hbQR8K2TxmVruswlDGNcCEkv = url.split(wYTDlJC5vpOKynUEX3ge6W(u"ࠫ࠴࠭੯"))[-pwxH3oREFm5v98BCZ1QVtzMJOc]
	url = SSBkx0WbN1asnDCQV6tIj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩੰ") + hbQR8K2TxmVruswlDGNcCEkv
	headers = { kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪੱ") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩੲ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(MzgKWUQ4V5H(u"ࠨ࡞࡟ࠫੳ"),Vk54F7GcROfCy6HunEI)
	items = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩੴ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ items[ufmXvxgoHGDwZtjsLkR05i] ]
	return ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧੵ"),[],[]
def TcE6ptAvNganoy5u02PR7zCiBkLU(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫ੶"))
	items = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ੷"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,fqNDhEb7ic5rH2K9Rx,jeKWBpHiawn82Y4VQ in items:
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(fqNDhEb7ic5rH2K9Rx+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jeKWBpHiawn82Y4VQ)
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return Nlyfx1HnzOWCovke5(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨ੸"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def vxgfYrUJKlz4WO0jXy(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ੹"))
	items = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ੺"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	items = set(items)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	for hbQR8K2TxmVruswlDGNcCEkv,Yz6schq9wSmiu3IOdke0DXPj5W,MOI9RXSAqDQ0G,fqNDhEb7ic5rH2K9Rx,jeKWBpHiawn82Y4VQ in items:
		url = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭੻")+hbQR8K2TxmVruswlDGNcCEkv+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ੼")+Yz6schq9wSmiu3IOdke0DXPj5W+cpHxZyU7vTtqmIw(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ੽")+MOI9RXSAqDQ0G
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ੾"))
		items = RSuYINdeamsK0t.findall(pnkrd2S84FJfN73KuiCYv(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੿"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(fqNDhEb7ic5rH2K9Rx+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+jeKWBpHiawn82Y4VQ)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==ufmXvxgoHGDwZtjsLkR05i: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭઀"),[],[]
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def LX3Kx2Spy157czwmdts9kRenoBa(url):
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Vk54F7GcROfCy6HunEI
	if pwxH3oREFm5v98BCZ1QVtzMJOc or MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡍࡨࡽࡂ࠭ઁ") not in url:
		hj50MJnoOp6ZWaS1IQ8Elr = url.replace(XCYALgFs2O3hZdpHrlMmB(u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭ં"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧઃ"))
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.split(NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࠴࠭઄"))
		hbQR8K2TxmVruswlDGNcCEkv = hj50MJnoOp6ZWaS1IQ8Elr[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		hj50MJnoOp6ZWaS1IQ8Elr = cpHxZyU7vTtqmIw(u"ࠬ࠵ࠧઅ").join(hj50MJnoOp6ZWaS1IQ8Elr[ufmXvxgoHGDwZtjsLkR05i:BZm7TqLPJfAVblDKsya85zFWXNMY])
		k8NxAwnQI2FzZCyJYthpaVubLscq = {pnkrd2S84FJfN73KuiCYv(u"࠭ࡩࡥࠩઆ"):hbQR8K2TxmVruswlDGNcCEkv,FGLEMi21Bfn(u"ࠧࡰࡲࠪઇ"):jXWzIZcDva4ikEUfN(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫઈ"),V2RQwM8XjlrK(u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧઉ"):NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪઊ")}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡕࡕࡓࡕࠩઋ"),hj50MJnoOp6ZWaS1IQ8Elr,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠲ࡵࡷࠫઌ"))
		if wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨઍ") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[WXuJd8nz2spo146t(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ઎")]
		if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp and Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠨ࡫ࡧࡁࠧࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬએ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,QYSAUI5r46yil8cfaO(u"ࠩࡊࡉ࡙࠭ઐ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩઑ"))
		if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭઒") in list(Iy3PA1SVXNfjOchtgHC5kuJBG.headers.keys()): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Iy3PA1SVXNfjOchtgHC5kuJBG.headers[jXWzIZcDva4ikEUfN(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧઓ")]
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return MpJ8GOKoic(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧઔ"),[],[]
def foKW8R9wMHsLv0B74OhnZq(url):
	headers = { MzgKWUQ4V5H(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫક") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪખ"))
	items = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨગ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	if items:
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(V2RQwM8XjlrK(u"ࠪࡱࡵ࠺ࠧઘ"))
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(items[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc])
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(jXWzIZcDva4ikEUfN(u"ࠫࡲ࠹ࡵ࠹ࠩઙ"))
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(items[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i])
		return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
	else: return wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡋࡌ࡚ࡎࡊࡅࡐࠩચ"),[],[]
def PEIoQ5fW1JN3S0OgnDhYlK8xqX(url):
	hbQR8K2TxmVruswlDGNcCEkv = url.split(WXuJd8nz2spo146t(u"࠭࠯ࠨછ"))[-pwxH3oREFm5v98BCZ1QVtzMJOc]
	hbQR8K2TxmVruswlDGNcCEkv = hbQR8K2TxmVruswlDGNcCEkv.split(wYTDlJC5vpOKynUEX3ge6W(u"ࠧࠧࠩજ"))[ufmXvxgoHGDwZtjsLkR05i]
	hbQR8K2TxmVruswlDGNcCEkv = hbQR8K2TxmVruswlDGNcCEkv.replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪઝ"),Vk54F7GcROfCy6HunEI)
	hj50MJnoOp6ZWaS1IQ8Elr = h9zFQKnsNL.SITESURLS[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪઞ")][ufmXvxgoHGDwZtjsLkR05i]+g7yJo2LVuqx1trPe(u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭ટ")+hbQR8K2TxmVruswlDGNcCEkv
	R32GKXQekBNHIlCpc6 = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࠧઠ")+hbQR8K2TxmVruswlDGNcCEkv
	hbLOTmiuwXyaeICo0RJ8Q5AW,EdalhkyDMgSq4wXjZHtING2Kr3Qm = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Vk54F7GcROfCy6HunEI
	HH4R2Wpk0cguS,zzUrvi7hkBJfIbps4 = Vk54F7GcROfCy6HunEI,{}
	gFIOCxTjBlWiN1ZpEwQ0K2s9,zZhlVTeynjpctMrH6wqF5PaLUY = Vk54F7GcROfCy6HunEI,{}
	headers = {kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩડ"):Vk54F7GcROfCy6HunEI}
	if ufmXvxgoHGDwZtjsLkR05i:
		A1edxVnfm8CHqhT6NtS0 = wAU9jKvmTM0(u"࠷ඈ")
		for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(A1edxVnfm8CHqhT6NtS0):
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,V2RQwM8XjlrK(u"࠭ࡇࡆࡖࠪઢ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨણ"))
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		c3viesQ2VarGbjg7npt4JBKWY = RSuYINdeamsK0t.findall(XCYALgFs2O3hZdpHrlMmB(u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬત"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		HH4R2Wpk0cguS = c3viesQ2VarGbjg7npt4JBKWY[ufmXvxgoHGDwZtjsLkR05i] if c3viesQ2VarGbjg7npt4JBKWY else FjwObZSWkg8ahBdiQf9IeY135DpXoP
		zzUrvi7hkBJfIbps4 = Bw6jaUcFxlqdDT8bC(NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡧ࡭ࡨࡺࠧથ"),HH4R2Wpk0cguS)
	else:
		ynmiDuav5ICTeRsqj6Vb18Q = h9zFQKnsNL.SITESURLS[V2RQwM8XjlrK(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫદ")][ufmXvxgoHGDwZtjsLkR05i]+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡴࡱࡧࡹࡦࡴࠪધ")
		xxp9EhudFLr = cad8TeSyMUYmfsEO0.getSetting(MzgKWUQ4V5H(u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧન"))
		if xxp9EhudFLr.count(V2RQwM8XjlrK(u"࠭࠺࠻࠼ࠪ઩"))==cpHxZyU7vTtqmIw(u"࠴ඉ"):
			FJSUmtAXh9L,key,pcqdGuymjhxZrkz1ROt4bLMY0C8XF5,C6jIWbGtMOk7polT9P1Ymfy,cVbGQZ5wHCNO6pU8nKt2Ji = xxp9EhudFLr.split(eAMGzHRQVs2KyCwPXljYhB(u"ࠧ࠻࠼࠽ࠫપ"))
			headers[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࡚࠰ࡋࡴࡵࡧ࠮ࡘ࡬ࡷ࡮ࡺ࡯ࡳ࠯ࡌࡨࠬફ")] = FJSUmtAXh9L
		headers[eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨબ")] = Nlyfx1HnzOWCovke5(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ભ")
		if pwxH3oREFm5v98BCZ1QVtzMJOc:
			FQAU5IsVfYLyoc7Da0J9veNidHGTw = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࢀࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫમ")+hbQR8K2TxmVruswlDGNcCEkv+FGLEMi21Bfn(u"ࠬࠨࠬࠡࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠸࠰࠵࠴࠷࠺࠱࠳࠲࠴࠲࠶࠾࠮࠱࠲ࠥ࠰ࠥࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠥࠨࡔࡗࡊࡗࡑࡑ࠻ࠢࡾࡿࢀࠫય")
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,cpHxZyU7vTtqmIw(u"࠭ࡐࡐࡕࡗࠫર"),ynmiDuav5ICTeRsqj6Vb18Q,FQAU5IsVfYLyoc7Da0J9veNidHGTw,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨ઱"))
			c3viesQ2VarGbjg7npt4JBKWY = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			if YzowicIDTRusXZSU61(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨલ") in c3viesQ2VarGbjg7npt4JBKWY:
				HH4R2Wpk0cguS = c3viesQ2VarGbjg7npt4JBKWY.replace(SSBkx0WbN1asnDCQV6tIj(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪળ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࠪࠬ઴"))
				zzUrvi7hkBJfIbps4 = Bw6jaUcFxlqdDT8bC(WXuJd8nz2spo146t(u"ࠫࡩ࡯ࡣࡵࠩવ"),HH4R2Wpk0cguS)
		if pwxH3oREFm5v98BCZ1QVtzMJOc:
			FQAU5IsVfYLyoc7Da0J9veNidHGTw = YzowicIDTRusXZSU61(u"ࠬࢁࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬશ")+hbQR8K2TxmVruswlDGNcCEkv+cpHxZyU7vTtqmIw(u"࠭ࠢ࠭ࠢࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠳࠼࠲࠹࠻࠮࠵ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡏࡏࡔࠤࢀࢁࢂ࠭ષ")
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,V2RQwM8XjlrK(u"ࠧࡑࡑࡖࡘࠬસ"),ynmiDuav5ICTeRsqj6Vb18Q,FQAU5IsVfYLyoc7Da0J9veNidHGTw,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠹ࡲࡥࠩહ"))
			c3viesQ2VarGbjg7npt4JBKWY = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			if WCPwmyVsb62KRlo(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ઺") in c3viesQ2VarGbjg7npt4JBKWY:
				gFIOCxTjBlWiN1ZpEwQ0K2s9 = c3viesQ2VarGbjg7npt4JBKWY.replace(jXWzIZcDva4ikEUfN(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ઻"),FGLEMi21Bfn(u"઼ࠫࠫ࠭"))
				zZhlVTeynjpctMrH6wqF5PaLUY = Bw6jaUcFxlqdDT8bC(NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡪࡩࡤࡶࠪઽ"),gFIOCxTjBlWiN1ZpEwQ0K2s9)
		if pwxH3oREFm5v98BCZ1QVtzMJOc and MzgKWUQ4V5H(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ા") not in HH4R2Wpk0cguS:
			HH4R2Wpk0cguS,zzUrvi7hkBJfIbps4,zzUrvi7hkBJfIbps4 = Vk54F7GcROfCy6HunEI,{},{}
			FQAU5IsVfYLyoc7Da0J9veNidHGTw = NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡼࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧિ")+hbQR8K2TxmVruswlDGNcCEkv+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࠤ࠯ࠤࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠶࠳࠸࠰࠳࠶࠳࠻࠷࠼࠮࠱࠳࠱࠴࠵ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡐ࡛ࡊࡈࠢࡾࡿࢀࠫી")
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡓࡓࡘ࡚ࠧુ"),ynmiDuav5ICTeRsqj6Vb18Q,FQAU5IsVfYLyoc7Da0J9veNidHGTw,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠵ࡶ࡫ࠫૂ"))
			c3viesQ2VarGbjg7npt4JBKWY = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			if XCYALgFs2O3hZdpHrlMmB(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫૃ") in c3viesQ2VarGbjg7npt4JBKWY:
				HH4R2Wpk0cguS = c3viesQ2VarGbjg7npt4JBKWY.replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ૄ"),XCYALgFs2O3hZdpHrlMmB(u"࠭ࠦࠨૅ"))
				zzUrvi7hkBJfIbps4 = Bw6jaUcFxlqdDT8bC(cpHxZyU7vTtqmIw(u"ࠧࡥ࡫ࡦࡸࠬ૆"),HH4R2Wpk0cguS)
		if pwxH3oREFm5v98BCZ1QVtzMJOc and MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨે") not in gFIOCxTjBlWiN1ZpEwQ0K2s9:
			gFIOCxTjBlWiN1ZpEwQ0K2s9,zZhlVTeynjpctMrH6wqF5PaLUY,zZhlVTeynjpctMrH6wqF5PaLUY = Vk54F7GcROfCy6HunEI,{},{}
			FQAU5IsVfYLyoc7Da0J9veNidHGTw = g7yJo2LVuqx1trPe(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩૈ")+hbQR8K2TxmVruswlDGNcCEkv+V2RQwM8XjlrK(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠹࠯࠴࠼࠲࠸࠽ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡅࡓࡊࡒࡐࡋࡇࠦ࠱ࠦࠢࡢࡰࡧࡶࡴ࡯ࡤࡔࡦ࡮࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠴࠳ࠥࢁࢂࢃࠧૉ")
			headers[eAMGzHRQVs2KyCwPXljYhB(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૊")] = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡩ࡯࡮࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡤࡲࡩࡸ࡯ࡪࡦ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳࠶࠿࠮࠳࠻࠱࠷࠼ࠦࠨࡍ࡫ࡱࡹࡽࡁࠠࡖ࠽ࠣࡅࡳࡪࡲࡰ࡫ࡧࠤ࠶࠸࠻ࠡࡉࡅ࠭ࠥ࡭ࡺࡪࡲࠪો")
			Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,FGLEMi21Bfn(u"࠭ࡐࡐࡕࡗࠫૌ"),ynmiDuav5ICTeRsqj6Vb18Q,FQAU5IsVfYLyoc7Da0J9veNidHGTw,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨ્"))
			c3viesQ2VarGbjg7npt4JBKWY = Iy3PA1SVXNfjOchtgHC5kuJBG.content
			if WCPwmyVsb62KRlo(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ૎") in c3viesQ2VarGbjg7npt4JBKWY:
				gFIOCxTjBlWiN1ZpEwQ0K2s9 = c3viesQ2VarGbjg7npt4JBKWY.replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ૏"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࠪࠬૐ"))
				zZhlVTeynjpctMrH6wqF5PaLUY = Bw6jaUcFxlqdDT8bC(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡩ࡯ࡣࡵࠩ૑"),gFIOCxTjBlWiN1ZpEwQ0K2s9)
	O6JtLbW1wu,PRcsxdrtVWXLHw,GsEz0WqVlyJdPnQ,YjDXGwmkF62 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,[],[]
	fiup8ZsenEh0oamX7btF,tdPOYJDaQ92Xy8MKnShBbLi3qHpGZ,Anrit5RWlp,jE8r7M9TURbvd = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,[],[]
	try: PRcsxdrtVWXLHw = zzUrvi7hkBJfIbps4[MzgKWUQ4V5H(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ૒")][MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ૓")]
	except: pass
	try: tdPOYJDaQ92Xy8MKnShBbLi3qHpGZ = zZhlVTeynjpctMrH6wqF5PaLUY[wAU9jKvmTM0(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ૔")][FGLEMi21Bfn(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ૕")]
	except: pass
	try: O6JtLbW1wu = zzUrvi7hkBJfIbps4[EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ૖")][ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ૗")]
	except: pass
	try: fiup8ZsenEh0oamX7btF = zZhlVTeynjpctMrH6wqF5PaLUY[ynxXU3gaiQ9GPCftr1q(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ૘")][wAU9jKvmTM0(u"ࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ૙")]
	except: pass
	try: GsEz0WqVlyJdPnQ = zzUrvi7hkBJfIbps4[MpJ8GOKoic(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭૚")][eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ૛")]
	except: pass
	try: Anrit5RWlp = zZhlVTeynjpctMrH6wqF5PaLUY[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ૜")][ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ૝")]
	except: pass
	try: YjDXGwmkF62 = zzUrvi7hkBJfIbps4[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ૞")][ynxXU3gaiQ9GPCftr1q(u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭૟")]
	except: pass
	try: jE8r7M9TURbvd = zZhlVTeynjpctMrH6wqF5PaLUY[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬૠ")][ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨૡ")]
	except: pass
	if not FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡈࡇࡗࠫૢ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠼ࡴࡩࠩૣ"))
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if not any([PRcsxdrtVWXLHw,tdPOYJDaQ92Xy8MKnShBbLi3qHpGZ,O6JtLbW1wu,fiup8ZsenEh0oamX7btF,GsEz0WqVlyJdPnQ,Anrit5RWlp,YjDXGwmkF62,jE8r7M9TURbvd]):
		burCKRDXAy9jY = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ૤"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		eeHAfglvTVoC0QE = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ૥"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		YtHmu8d3UpLj7XA = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ૦"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		lNKx2h7tHjsZR4XEf = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૧"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		CLJeagidpzPUNry7,CqOTrfZycdF7VElDg2ueNb5hoXLPk4,T7CKpu9eR8ZDPa = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
		try: CLJeagidpzPUNry7 = zzUrvi7hkBJfIbps4[HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ૨")][jXWzIZcDva4ikEUfN(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ૩")][wAU9jKvmTM0(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ૪")][jXWzIZcDva4ikEUfN(u"ࠩࡷ࡭ࡹࡲࡥࠨ૫")][ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡶࡺࡴࡳࠨ૬")][ufmXvxgoHGDwZtjsLkR05i][EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡹ࡫ࡸࡵࠩ૭")]
		except:
			try: CLJeagidpzPUNry7 = zZhlVTeynjpctMrH6wqF5PaLUY[QYSAUI5r46yil8cfaO(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ૮")][MpJ8GOKoic(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ૯")][WsklGNp2CYzVQUag(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ૰")][YzowicIDTRusXZSU61(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ૱")][ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡵࡹࡳࡹࠧ૲")][ufmXvxgoHGDwZtjsLkR05i][QYSAUI5r46yil8cfaO(u"ࠪࡸࡪࡾࡴࠨ૳")]
			except: pass
		try: CqOTrfZycdF7VElDg2ueNb5hoXLPk4 = zzUrvi7hkBJfIbps4[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ૴")][MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ૵")][V2RQwM8XjlrK(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ૶")][NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨ૷")][ufmXvxgoHGDwZtjsLkR05i][FGLEMi21Bfn(u"ࠨࡴࡸࡲࡸ࠭૸")][ufmXvxgoHGDwZtjsLkR05i][BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡷࡩࡽࡺࠧૹ")]
		except:
			try: CqOTrfZycdF7VElDg2ueNb5hoXLPk4 = zZhlVTeynjpctMrH6wqF5PaLUY[WXuJd8nz2spo146t(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧૺ")][MpJ8GOKoic(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩૻ")][XCYALgFs2O3hZdpHrlMmB(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ૼ")][wAU9jKvmTM0(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ૽")][ufmXvxgoHGDwZtjsLkR05i][ynxXU3gaiQ9GPCftr1q(u"ࠧࡳࡷࡱࡷࠬ૾")][ufmXvxgoHGDwZtjsLkR05i][pnkrd2S84FJfN73KuiCYv(u"ࠨࡶࡨࡼࡹ࠭૿")]
			except: pass
		try: T7CKpu9eR8ZDPa = zzUrvi7hkBJfIbps4[XCYALgFs2O3hZdpHrlMmB(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭଀")][XCYALgFs2O3hZdpHrlMmB(u"ࠪࡶࡪࡧࡳࡰࡰࠪଁ")]
		except:
			try: T7CKpu9eR8ZDPa = zZhlVTeynjpctMrH6wqF5PaLUY[YzowicIDTRusXZSU61(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨଂ")][V2RQwM8XjlrK(u"ࠬࡸࡥࡢࡵࡲࡲࠬଃ")]
			except: pass
		LRECJXnVhyH01 = Vk54F7GcROfCy6HunEI
		rtXWbTeI6LnNalU0GH4 = nMt0iueCy6K+wAU9jKvmTM0(u"࠭็ัษࠣห้็๊ะ์๋ࠤๆ๐็ࠡ็ื็้ฯࠠ࠯࠰ࠣวํฺ๋ࠦำ้้ࠣอฦๆࠢ็ฬ฾฼ࠠศๆ่ืฯิฯๆ์้ࠤ࠳࠴ࠠฤ๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠤ࠳࠴ࠠฤ๊ࠣ๎ํะ๊้สࠣ๎าะวอࠢื๎ฦࠦๅฮัาࠤ࠳࠴ࠠฤ๊ࠣ๎ํะ๊้สࠣ฾๏ืࠠใษาีࠥษๆࠡ์ื฾้ࠦวๅใํำ๏๎ࠠศๆล๊ࠬ଄")+ZZoLlKyInXc08j2pTGJ
		if burCKRDXAy9jY or eeHAfglvTVoC0QE or YtHmu8d3UpLj7XA or lNKx2h7tHjsZR4XEf or CLJeagidpzPUNry7 or CqOTrfZycdF7VElDg2ueNb5hoXLPk4 or T7CKpu9eR8ZDPa:
			if   burCKRDXAy9jY: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = burCKRDXAy9jY[ufmXvxgoHGDwZtjsLkR05i]
			elif eeHAfglvTVoC0QE: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = eeHAfglvTVoC0QE[ufmXvxgoHGDwZtjsLkR05i]
			elif YtHmu8d3UpLj7XA: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = YtHmu8d3UpLj7XA[ufmXvxgoHGDwZtjsLkR05i]
			elif lNKx2h7tHjsZR4XEf: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = lNKx2h7tHjsZR4XEf[ufmXvxgoHGDwZtjsLkR05i]
			elif CLJeagidpzPUNry7: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = CLJeagidpzPUNry7
			elif CqOTrfZycdF7VElDg2ueNb5hoXLPk4: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = CqOTrfZycdF7VElDg2ueNb5hoXLPk4
			elif T7CKpu9eR8ZDPa: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = T7CKpu9eR8ZDPa
			LRECJXnVhyH01 = BadMOTrh9Lnp0w6KZCQASE4uyk7fW.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			rtXWbTeI6LnNalU0GH4 += MzgKWUQ4V5H(u"ࠧ࡝ࡰ࡟ࡲࠬଅ")+d761ZWXHEvliYN45RzLP2+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨำึห้ฯࠠๆ่ࠣ๎ํะ๊้สࠪଆ")+ZZoLlKyInXc08j2pTGJ+ixrPWKeFMnqJyVodX6D9AaO2+LRECJXnVhyH01
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭ଇ"),rtXWbTeI6LnNalU0GH4)
		if LRECJXnVhyH01: LRECJXnVhyH01 = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪ࠾ࠥ࠭ଈ")+LRECJXnVhyH01
		return BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫଉ")+LRECJXnVhyH01,[],[]
	YYaOnpKegi5HlCI,Wj9nPHFKSzDLfrxhy0cC5igX,dvyo3E0Cs5BxSp9Yw6z = [],[],[]
	PlSFrHq6z4t1hQsWKRcjXg = [PRcsxdrtVWXLHw,tdPOYJDaQ92Xy8MKnShBbLi3qHpGZ]
	f3fegHlc4WFomjOu7LwyUJIArCZS = [O6JtLbW1wu,fiup8ZsenEh0oamX7btF]
	FMpUSlAmskvgKEZ,FFa6EYhQJWmcnjoNRMz5quAVi2P = [],[]
	for gb3Wy6fShH2JLT0z78jXQ1qkU in GsEz0WqVlyJdPnQ+Anrit5RWlp:
		if gb3Wy6fShH2JLT0z78jXQ1qkU[ESXZrtnCfcDJGo01vFg(u"ࠬ࡯ࡴࡢࡩࠪଊ")] not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(gb3Wy6fShH2JLT0z78jXQ1qkU[V2RQwM8XjlrK(u"࠭ࡩࡵࡣࡪࠫଋ")])
			FFa6EYhQJWmcnjoNRMz5quAVi2P.append(gb3Wy6fShH2JLT0z78jXQ1qkU)
	FMpUSlAmskvgKEZ,QMIu5Fc7v2WqYksRNV1bd8rE4xgS = [],[]
	for gb3Wy6fShH2JLT0z78jXQ1qkU in YjDXGwmkF62+jE8r7M9TURbvd:
		if gb3Wy6fShH2JLT0z78jXQ1qkU[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡪࡶࡤ࡫ࠬଌ")] not in FMpUSlAmskvgKEZ:
			FMpUSlAmskvgKEZ.append(gb3Wy6fShH2JLT0z78jXQ1qkU[WsklGNp2CYzVQUag(u"ࠨ࡫ࡷࡥ࡬࠭଍")])
			QMIu5Fc7v2WqYksRNV1bd8rE4xgS.append(gb3Wy6fShH2JLT0z78jXQ1qkU)
	for dict in FFa6EYhQJWmcnjoNRMz5quAVi2P+QMIu5Fc7v2WqYksRNV1bd8rE4xgS:
		if g7yJo2LVuqx1trPe(u"ࠩ࡬ࡸࡦ࡭ࠧ଎") in list(dict.keys()): dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠪ࡭ࡹࡧࡧࠨଏ")] = str(dict[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫ࡮ࡺࡡࡨࠩଐ")])
		if WXuJd8nz2spo146t(u"ࠬ࡬ࡰࡴࠩ଑") in list(dict.keys()): dict[WXuJd8nz2spo146t(u"࠭ࡦࡱࡵࠪ଒")] = str(dict[SSBkx0WbN1asnDCQV6tIj(u"ࠧࡧࡲࡶࠫଓ")])
		if pnkrd2S84FJfN73KuiCYv(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪଔ") in list(dict.keys()): dict[wAU9jKvmTM0(u"ࠩࡷࡽࡵ࡫ࠧକ")] = dict[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬଖ")]
		if MpJ8GOKoic(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭ଗ") in list(dict.keys()): dict[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩଘ")] = str(dict[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨଙ")])
		if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧଚ") in list(dict.keys()): dict[FGLEMi21Bfn(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩଛ")] = str(dict[jXWzIZcDva4ikEUfN(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩଜ")])
		if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡻ࡮ࡪࡴࡩࠩଝ") in list(dict.keys()): dict[QYSAUI5r46yil8cfaO(u"ࠫࡸ࡯ࡺࡦࠩଞ")] = str(dict[YzowicIDTRusXZSU61(u"ࠬࡽࡩࡥࡶ࡫ࠫଟ")])+jXWzIZcDva4ikEUfN(u"࠭ࡸࠨଠ")+str(dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡩࡧ࡬࡫࡭ࡺࠧଡ")])
		if WsklGNp2CYzVQUag(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫଢ") in list(dict.keys()): dict[pnkrd2S84FJfN73KuiCYv(u"ࠩ࡬ࡲ࡮ࡺࠧଣ")] = dict[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭ତ")][pnkrd2S84FJfN73KuiCYv(u"ࠫࡸࡺࡡࡳࡶࠪଥ")]+XCYALgFs2O3hZdpHrlMmB(u"ࠬ࠳ࠧଦ")+dict[wAU9jKvmTM0(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩଧ")][jXWzIZcDva4ikEUfN(u"ࠧࡦࡰࡧࠫନ")]
		if g7yJo2LVuqx1trPe(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ଩") in list(dict.keys()): dict[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡬ࡲࡩ࡫ࡸࠨପ")] = dict[wYTDlJC5vpOKynUEX3ge6W(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧଫ")][MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡸࡺࡡࡳࡶࠪବ")]+ESXZrtnCfcDJGo01vFg(u"ࠬ࠳ࠧଭ")+dict[Nlyfx1HnzOWCovke5(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪମ")][WCPwmyVsb62KRlo(u"ࠧࡦࡰࡧࠫଯ")]
		if pnkrd2S84FJfN73KuiCYv(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩର") in list(dict.keys()): dict[ESXZrtnCfcDJGo01vFg(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ଱")] = dict[V2RQwM8XjlrK(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫଲ")]
		if MzgKWUQ4V5H(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬଳ") in list(dict.keys()) and int(dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭଴")])>WXuJd8nz2spo146t(u"࠲࠳࠴࠶࠷࠸࠳࠴࠵ඊ"): del dict[XCYALgFs2O3hZdpHrlMmB(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧଵ")]
		if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩଶ") in list(dict.keys()):
			zcjC8X79NQg16WSVROU4J = dict[g7yJo2LVuqx1trPe(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪଷ")].split(pnkrd2S84FJfN73KuiCYv(u"ࠩࠩࠫସ"))
			for anbjzfuiDdgYP6vSXqwRex in zcjC8X79NQg16WSVROU4J:
				key,value = anbjzfuiDdgYP6vSXqwRex.split(cpHxZyU7vTtqmIw(u"ࠪࡁࠬହ"),YzowicIDTRusXZSU61(u"࠳උ"))
				dict[key] = ZlBMJUAWRm9buv(value)
		if NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡺࡸ࡬ࠨ଺") in list(dict.keys()): dict[FGLEMi21Bfn(u"ࠬࡻࡲ࡭ࠩ଻")] = ZlBMJUAWRm9buv(dict[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡵࡳ࡮଼ࠪ")])
		YYaOnpKegi5HlCI.append(dict)
	qNPU329neKupGMmzCx6sgoWaXk = Vk54F7GcROfCy6HunEI
	VThlJSvKB46oNcqApU98dm3WLCk = RSuYINdeamsK0t.findall(pnkrd2S84FJfN73KuiCYv(u"ࠧࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩଽ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if VThlJSvKB46oNcqApU98dm3WLCk:
		VThlJSvKB46oNcqApU98dm3WLCk = h9zFQKnsNL.SITESURLS[YzowicIDTRusXZSU61(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩା")][ufmXvxgoHGDwZtjsLkR05i]+VThlJSvKB46oNcqApU98dm3WLCk[ufmXvxgoHGDwZtjsLkR05i]
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,FGLEMi21Bfn(u"ࠩࡊࡉ࡙࠭ି"),VThlJSvKB46oNcqApU98dm3WLCk,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠹ࡶ࡫ࠫୀ"))
		qNPU329neKupGMmzCx6sgoWaXk = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if qNPU329neKupGMmzCx6sgoWaXk:
		if wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫୁ") in HH4R2Wpk0cguS+gFIOCxTjBlWiN1ZpEwQ0K2s9:
			import youtube_signature.cipher as mmwtW6AqvcaHESiChKokgQZs3Fb,youtube_signature.json_script_engine as buGsUyvVahSQ38
			zcjC8X79NQg16WSVROU4J = RQDmc8wAqi756E2OrFGp.zcjC8X79NQg16WSVROU4J.Cipher()
			zcjC8X79NQg16WSVROU4J._object_cache = {}
			jWqVihf0ZOTBpw5YI63Alc = zcjC8X79NQg16WSVROU4J._load_javascript(qNPU329neKupGMmzCx6sgoWaXk)
			ZWSTR6XVyrEDstAwpG5u3B7 = Bw6jaUcFxlqdDT8bC(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡹࡴࡳࠩୂ"),str(jWqVihf0ZOTBpw5YI63Alc))
			gzmw1CfADc0nG = RQDmc8wAqi756E2OrFGp.SrZ3gFl2WcGaEIMQN6eByvqoAOks.JsonScriptEngine(ZWSTR6XVyrEDstAwpG5u3B7)
		Jc9jghI4Mdq6nxrX = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࡸࠧࠨࠩࠫࡃࡽ࠯ࠊࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࡡ࠴ࡧࡦࡶ࡟ࠬࠧࡴࠢ࡝ࠫ࡟࠭ࠫࠬ࡜ࠩࡤࡀࢀࠏࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࡧࡃࡓࡵࡴ࡬ࡲ࡬ࡢ࠮ࡧࡴࡲࡱࡈ࡮ࡡࡳࡅࡲࡨࡪࡢࠨ࠲࠳࠳ࡠ࠮ࢂࠊࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡶࡸࡷࡥࡩࡥࡺࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࠰ࡠ࠯࠮ࠬࠦ࡝ࠪࡥࡁࠧࡴ࡮ࠣ࡞࡞ࡠ࠰࠮࠿ࡑ࠿ࡶࡸࡷࡥࡩࡥࡺࠬࡠࡢࠐࠉࠊࠋࠌ࠭ࠏࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍ࠱ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢࠨࡢ࡞ࠬ࠭ࡄ࠲ࡣ࠾ࡣ࡟࠲ࠏࠏࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࠏࡧࡦࡶ࡟ࠬࡧࡢࠩࡽࠌࠌࠍࠎࠏࠉࠊ࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬ࡞࡞ࡦࡡࡣ࡜ࡽ࡞ࡿࡲࡺࡲ࡬ࠋࠋࠌࠍࠎࠏࠩ࡝ࠫࠩࠪࡡ࠮ࡣ࠾ࡾࠍࠍࠎࠏࠉ࡝ࡤࠫࡃࡕࡂࡶࡢࡴࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡂࠐࠉࠊࠋࠬࠬࡄࡖ࠼࡯ࡨࡸࡲࡨࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩࠩࡁ࠽ࡠࡠ࠮࠿ࡑ࠾࡬ࡨࡽࡄ࡜ࡥ࠭ࠬࡠࡢ࠯࠿࡝ࠪ࡞ࡥ࠲ࢀࡁ࠮࡜ࡠࡠ࠮ࠐࠉࠊࠋࠫࡃ࠭ࡼࡡࡳࠫ࠯࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠳ࡹࡥࡵ࡞ࠫࠬࡄࡀࠢ࡯࠭ࠥࢀࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡢࠬࠩࡁࡓࡁࡻࡧࡲࠪ࡞ࠬ࠭ࠬ࠭ࠧୃ"),qNPU329neKupGMmzCx6sgoWaXk)
		if Jc9jghI4Mdq6nxrX:
			Jc9jghI4Mdq6nxrX = RSuYINdeamsK0t.findall(Jc9jghI4Mdq6nxrX[ufmXvxgoHGDwZtjsLkR05i][wAU9jKvmTM0(u"࠵ඌ")]+ynxXU3gaiQ9GPCftr1q(u"ࠧ࠾࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫୄ"),qNPU329neKupGMmzCx6sgoWaXk,RSuYINdeamsK0t.DOTALL)[ufmXvxgoHGDwZtjsLkR05i]
			r3fiuvkRC5wEjGKaSzmWp4Zh = qNPU329neKupGMmzCx6sgoWaXk.find(Jc9jghI4Mdq6nxrX+V2RQwM8XjlrK(u"ࠨ࠿ࡩࡹࡳࡩࡴࡪࡱࡱࠬࠬ୅"))
			fIKOiurbptvBcw1PWGjF = qNPU329neKupGMmzCx6sgoWaXk.find(ynxXU3gaiQ9GPCftr1q(u"ࠩࢀ࠿ࠬ୆"), r3fiuvkRC5wEjGKaSzmWp4Zh)
			WVIrsQKqPpymvBGL = qNPU329neKupGMmzCx6sgoWaXk[r3fiuvkRC5wEjGKaSzmWp4Zh:fIKOiurbptvBcw1PWGjF]+WXuJd8nz2spo146t(u"ࠪࢁࠬେ")
			TKzjX8MslnWht = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"ࠫࡻࡧࡲࠡ࠰࠭ࡃࡂ࠮࠮ࠫࡁࠬࡠ࠳࠭ୈ"),WVIrsQKqPpymvBGL,RSuYINdeamsK0t.DOTALL)[ufmXvxgoHGDwZtjsLkR05i]
			R0ROuhGjTyMt4ZUL = RSuYINdeamsK0t.findall(wAU9jKvmTM0(u"ࠬ࡯ࡦ࡝ࠪࡷࡽࡵ࡫࡯ࡧࠢ࠱࠮ࡄࡃ࠽࠾ࠤࡸࡲࡩ࡫ࡦࡪࡰࡨࡨࠧࡢࠩࡳࡧࡷࡹࡷࡴࠠࠨ୉")+TKzjX8MslnWht+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭࠻ࠨ୊"),WVIrsQKqPpymvBGL,RSuYINdeamsK0t.DOTALL)
			if R0ROuhGjTyMt4ZUL: WVIrsQKqPpymvBGL = WVIrsQKqPpymvBGL.replace(R0ROuhGjTyMt4ZUL[ufmXvxgoHGDwZtjsLkR05i],Vk54F7GcROfCy6HunEI)
			d1DOC5aETzPt37cWF0vsGiqmfB2NKp = {}
			for dict in YYaOnpKegi5HlCI:
				url = dict[NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡶࡴ࡯ࠫୋ")]
				if wAU9jKvmTM0(u"ࠨࠨࡱࡁࠬୌ") in url:
					WFfOn0A6yaDkYbHSxjQ = url.split(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࠩࡲࡂ୍࠭"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc].split(ESXZrtnCfcDJGo01vFg(u"ࠪࠪࠬ୎"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
					if WFfOn0A6yaDkYbHSxjQ not in list(d1DOC5aETzPt37cWF0vsGiqmfB2NKp.keys()): d1DOC5aETzPt37cWF0vsGiqmfB2NKp[WFfOn0A6yaDkYbHSxjQ] = OUbct7HKQeNvFhBIq6T2EV0W5(WVIrsQKqPpymvBGL,[Jc9jghI4Mdq6nxrX,WFfOn0A6yaDkYbHSxjQ])
					dict[XCYALgFs2O3hZdpHrlMmB(u"ࠫࡺࡸ࡬ࠨ୏")] = url.replace(MpJ8GOKoic(u"ࠬࠬ࡮࠾ࠩ୐")+WFfOn0A6yaDkYbHSxjQ+eAMGzHRQVs2KyCwPXljYhB(u"࠭ࠦࠨ୑"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࠧࡰࡀࠫ୒")+d1DOC5aETzPt37cWF0vsGiqmfB2NKp[WFfOn0A6yaDkYbHSxjQ]+eAMGzHRQVs2KyCwPXljYhB(u"ࠨࠨࠪ୓"))
	for dict in YYaOnpKegi5HlCI:
		url = dict[QYSAUI5r46yil8cfaO(u"ࠩࡸࡶࡱ࠭୔")]
		if ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧ୕") in url or url.count(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡸ࡯ࡧ࠾ࠩୖ"))>pwxH3oREFm5v98BCZ1QVtzMJOc:
			Wj9nPHFKSzDLfrxhy0cC5igX.append(dict)
		elif qNPU329neKupGMmzCx6sgoWaXk and V2RQwM8XjlrK(u"ࠬࡹࠧୗ") in list(dict.keys()) and kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡳࡱࠩ୘") in list(dict.keys()):
			yRrlUvoXMhjLCnYOx = gzmw1CfADc0nG.execute(dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡴࠩ୙")])
			if yRrlUvoXMhjLCnYOx!=dict[YzowicIDTRusXZSU61(u"ࠨࡵࠪ୚")]:
				dict[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡸࡶࡱ࠭୛")] = url+WsklGNp2CYzVQUag(u"ࠪࠪࠬଡ଼")+dict[V2RQwM8XjlrK(u"ࠫࡸࡶࠧଢ଼")]+NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡃࠧ୞")+yRrlUvoXMhjLCnYOx
				Wj9nPHFKSzDLfrxhy0cC5igX.append(dict)
	for dict in Wj9nPHFKSzDLfrxhy0cC5igX:
		k2kRdMUp0qmI9Hrv,AOXhcCuU3fezd,TKYIaQS4jc,N5RUprZIYG6ekHh,P5r6hYn03z4Gq8CmE2aQI7U,LL82RbVxIQF1XBfYZM3 = EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧୟ"),YzowicIDTRusXZSU61(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨୠ"),YzowicIDTRusXZSU61(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩୡ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪୢ"),Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠪ࠴ࠬୣ")
		try:
			R1gyvliQ6V = dict[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡹࡿࡰࡦࠩ୤")]
			R1gyvliQ6V = R1gyvliQ6V.replace(WsklGNp2CYzVQUag(u"ࠬ࠱ࠧ୥"),Vk54F7GcROfCy6HunEI)
			items = RSuYINdeamsK0t.findall(g7yJo2LVuqx1trPe(u"࠭ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୦"),R1gyvliQ6V,RSuYINdeamsK0t.DOTALL)
			N5RUprZIYG6ekHh,k2kRdMUp0qmI9Hrv,P5r6hYn03z4Gq8CmE2aQI7U = items[ufmXvxgoHGDwZtjsLkR05i]
			TTGjQP0mZcf3tdqNHoSCERDx9vVg = P5r6hYn03z4Gq8CmE2aQI7U.split(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧ࠭ࠩ୧"))
			AOXhcCuU3fezd = Vk54F7GcROfCy6HunEI
			for anbjzfuiDdgYP6vSXqwRex in TTGjQP0mZcf3tdqNHoSCERDx9vVg: AOXhcCuU3fezd += anbjzfuiDdgYP6vSXqwRex.split(EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ࠰ࠪ୨"))[ufmXvxgoHGDwZtjsLkR05i]+ESXZrtnCfcDJGo01vFg(u"ࠩ࠯ࠫ୩")
			AOXhcCuU3fezd = AOXhcCuU3fezd.strip(wAU9jKvmTM0(u"ࠪ࠰ࠬ୪"))
			if YzowicIDTRusXZSU61(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ୫") in list(dict.keys()): LL82RbVxIQF1XBfYZM3 = str(int(dict[wAU9jKvmTM0(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭୬")])//ynxXU3gaiQ9GPCftr1q(u"࠵࠵࠸࠴ඍ"))+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭࡫ࡣࡲࡶࠤࠥ࠭୭")
			else: LL82RbVxIQF1XBfYZM3 = Vk54F7GcROfCy6HunEI
			if N5RUprZIYG6ekHh==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡵࡧࡻࡸࠬ୮"): continue
			elif ESXZrtnCfcDJGo01vFg(u"ࠨ࠮ࠪ୯") in R1gyvliQ6V:
				N5RUprZIYG6ekHh = WXuJd8nz2spo146t(u"ࠩࡄ࠯࡛࠭୰")
				TKYIaQS4jc = k2kRdMUp0qmI9Hrv+YIPoWuLzfl93BTS+LL82RbVxIQF1XBfYZM3+dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡷ࡮ࢀࡥࠨୱ")].split(QYSAUI5r46yil8cfaO(u"ࠫࡽ࠭୲"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
			elif N5RUprZIYG6ekHh==eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡼࡩࡥࡧࡲࠫ୳"):
				N5RUprZIYG6ekHh = WXuJd8nz2spo146t(u"࠭ࡖࡪࡦࡨࡳࠬ୴")
				TKYIaQS4jc = LL82RbVxIQF1XBfYZM3+dict[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡴ࡫ࡽࡩࠬ୵")].split(QYSAUI5r46yil8cfaO(u"ࠨࡺࠪ୶"))[pwxH3oREFm5v98BCZ1QVtzMJOc]+YIPoWuLzfl93BTS+dict[ESXZrtnCfcDJGo01vFg(u"ࠩࡩࡴࡸ࠭୷")]+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡪࡵࡹࠧ୸")+YIPoWuLzfl93BTS+k2kRdMUp0qmI9Hrv
			elif N5RUprZIYG6ekHh==V2RQwM8XjlrK(u"ࠫࡦࡻࡤࡪࡱࠪ୹"):
				N5RUprZIYG6ekHh = WCPwmyVsb62KRlo(u"ࠬࡇࡵࡥ࡫ࡲࠫ୺")
				TKYIaQS4jc = LL82RbVxIQF1XBfYZM3+str(int(dict[wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ୻")])/l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠶࠶࠰࠱ඎ"))+pnkrd2S84FJfN73KuiCYv(u"ࠧ࡬ࡪࡽࠤࠥ࠭୼")+dict[WsklGNp2CYzVQUag(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ୽")]+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡦ࡬ࠬ୾")+YIPoWuLzfl93BTS+k2kRdMUp0qmI9Hrv
		except:
			ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
			if ovLGZ5jUxNzmiQC!=YzowicIDTRusXZSU61(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭୿"): yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
		if Nlyfx1HnzOWCovke5(u"ࠫࡩࡻࡲ࠾ࠩ஀") in dict[NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡻࡲ࡭ࠩ஁")]: GbwM6iseo0ZVlh4ydB = round(ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠰࠯࠷ඐ")+float(dict[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡵࡳ࡮ࠪஂ")].split(YzowicIDTRusXZSU61(u"ࠧࡥࡷࡵࡁࠬஃ"),pnkrd2S84FJfN73KuiCYv(u"࠷ඏ"))[pwxH3oREFm5v98BCZ1QVtzMJOc].split(ynxXU3gaiQ9GPCftr1q(u"ࠨࠨࠪ஄"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]))
		elif SSBkx0WbN1asnDCQV6tIj(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬஅ") in list(dict.keys()): GbwM6iseo0ZVlh4ydB = round(Nlyfx1HnzOWCovke5(u"࠱࠰࠸එ")+float(dict[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭ஆ")])/g7yJo2LVuqx1trPe(u"࠳࠳࠴࠵ඒ"))
		else: GbwM6iseo0ZVlh4ydB = WXuJd8nz2spo146t(u"ࠫ࠵࠭இ")
		if MpJ8GOKoic(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ஈ") not in list(dict.keys()): LL82RbVxIQF1XBfYZM3 = dict[pnkrd2S84FJfN73KuiCYv(u"࠭ࡳࡪࡼࡨࠫஉ")].split(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡹࠩஊ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
		else: LL82RbVxIQF1XBfYZM3 = str(int(dict[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ஋")])//MpJ8GOKoic(u"࠴࠴࠷࠺ඓ"))
		if NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡬ࡲ࡮ࡺࠧ஌") not in list(dict.keys()): dict[wYTDlJC5vpOKynUEX3ge6W(u"ࠪ࡭ࡳ࡯ࡴࠨ஍")] = NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࠵࠳࠰ࠨஎ")
		dict[eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡺࡩࡵ࡮ࡨࠫஏ")] = N5RUprZIYG6ekHh+WCPwmyVsb62KRlo(u"࠭࠺ࠡࠢࠪஐ")+TKYIaQS4jc+cpHxZyU7vTtqmIw(u"ࠧࠡࠢࠫࠫ஑")+AOXhcCuU3fezd+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ࠮ࠪஒ")+dict[g7yJo2LVuqx1trPe(u"ࠩ࡬ࡸࡦ࡭ࠧஓ")]+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪ࠭ࠬஔ")
		dict[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬக")] = TKYIaQS4jc.split(YIPoWuLzfl93BTS)[ufmXvxgoHGDwZtjsLkR05i].split(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡱࡢࡱࡵࠪ஖"))[ufmXvxgoHGDwZtjsLkR05i]
		dict[pnkrd2S84FJfN73KuiCYv(u"࠭ࡴࡺࡲࡨ࠶ࠬ஗")] = N5RUprZIYG6ekHh
		dict[SSBkx0WbN1asnDCQV6tIj(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ஘")] = k2kRdMUp0qmI9Hrv
		dict[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡥࡲࡨࡪࡩࡳࠨங")] = P5r6hYn03z4Gq8CmE2aQI7U
		dict[MzgKWUQ4V5H(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫச")] = GbwM6iseo0ZVlh4ydB
		dict[QYSAUI5r46yil8cfaO(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ஛")] = LL82RbVxIQF1XBfYZM3
		dvyo3E0Cs5BxSp9Yw6z.append(dict)
	sgoP5rJGHwaOpzhVnFcC8u9R7ix0kD,f5YZgQDCLtK3,Kv52GDqeLyIc8xpzH0dAmPQYuWr,J59wLTyEC0VOmInazXxMQhGgl213,JJ0TVO2iGBl3nSQPIzo6N = [],[],[],[],[]
	Im4zFTVQ5HAsDnvCJrbwk9Zl0dMPtK,Wh7RFgs5b2EeiwX9qPuMKxBDz,AACdEHIcboigWGsqS53K,bb95ULZdgFSuNx,TrAwN8daR5QBZq = [],[],[],[],[]
	for q97kMO8nQJXNvI in f3fegHlc4WFomjOu7LwyUJIArCZS:
		if not q97kMO8nQJXNvI: continue
		dict = {}
		dict[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡹࡿࡰࡦ࠴ࠪஜ")] = XCYALgFs2O3hZdpHrlMmB(u"ࠬࡇࠫࡗࠩ஝")
		dict[MpJ8GOKoic(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨஞ")] = EM6qpnCBYQGA9kbgDVLfrP(u"ࠧ࡮ࡲࡧࠫட")
		dict[eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ஠")] = dict[WCPwmyVsb62KRlo(u"ࠩࡷࡽࡵ࡫࠲ࠨ஡")]+FGLEMi21Bfn(u"ࠪ࠾ࠥࠦࠧ஢")+dict[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ண")]+YIPoWuLzfl93BTS+MpJ8GOKoic(u"ࠬา่ะหࠣิ่๐ษࠨத")
		dict[jXWzIZcDva4ikEUfN(u"࠭ࡵࡳ࡮ࠪ஥")] = q97kMO8nQJXNvI
		dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ஦")] = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࠲ࠪ஧")
		dict[EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪந")] = V2RQwM8XjlrK(u"ࠪ࠵࠶࠷࠲࠳࠴࠶࠷࠸࠭ன")
		dvyo3E0Cs5BxSp9Yw6z.append(dict)
	for KauCh8xwIPe in PlSFrHq6z4t1hQsWKRcjXg:
		if not KauCh8xwIPe: continue
		QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,vwYsD8UprydixO3n7L = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,KauCh8xwIPe)
		arLGKkf25Ocm7zH = list(zip(QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,vwYsD8UprydixO3n7L))
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in arLGKkf25Ocm7zH:
			dict = {}
			dict[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡹࡿࡰࡦ࠴ࠪப")] = cpHxZyU7vTtqmIw(u"ࠬࡇࠫࡗࠩ஫")
			dict[HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ஬")] = YzowicIDTRusXZSU61(u"ࠧ࡮࠵ࡸ࠼ࠬ஭")
			dict[MzgKWUQ4V5H(u"ࠨࡷࡵࡰࠬம")] = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡮ࡦࡵࡹࠧய") in title: dict[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫர")] = title.split(XCYALgFs2O3hZdpHrlMmB(u"ࠫࡰࡨࡰࡴࠩற"))[ufmXvxgoHGDwZtjsLkR05i].rsplit(YIPoWuLzfl93BTS)[-pwxH3oREFm5v98BCZ1QVtzMJOc]
			else: dict[MpJ8GOKoic(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ல")] = cpHxZyU7vTtqmIw(u"࠭࠱࠱ࠩள")
			if title.count(YIPoWuLzfl93BTS)>pwxH3oREFm5v98BCZ1QVtzMJOc:
				jMiru3pGns = title.rsplit(YIPoWuLzfl93BTS)[-wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
				if jMiru3pGns.isdigit(): dict[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨழ")] = jMiru3pGns
				else: dict[pnkrd2S84FJfN73KuiCYv(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩவ")] = WCPwmyVsb62KRlo(u"ࠩ࠳࠴࠵࠶ࠧஶ")
			if title==eAMGzHRQVs2KyCwPXljYhB(u"ࠪ࠱࠶࠭ஷ"): dict[YzowicIDTRusXZSU61(u"ࠫࡹ࡯ࡴ࡭ࡧࠪஸ")] = dict[NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡺࡹࡱࡧ࠵ࠫஹ")]+V2RQwM8XjlrK(u"࠭࠺ࠡࠢࠪ஺")+dict[eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ஻")]+YIPoWuLzfl93BTS+wYTDlJC5vpOKynUEX3ge6W(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ஼")
			else: dict[YzowicIDTRusXZSU61(u"ࠩࡷ࡭ࡹࡲࡥࠨ஽")] = dict[wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡸࡾࡶࡥ࠳ࠩா")]+MpJ8GOKoic(u"ࠫ࠿ࠦࠠࠨி")+dict[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧீ")]+YIPoWuLzfl93BTS+dict[SSBkx0WbN1asnDCQV6tIj(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧு")]+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧூ")+dict[XCYALgFs2O3hZdpHrlMmB(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ௃")]
			dvyo3E0Cs5BxSp9Yw6z.append(dict)
	dvyo3E0Cs5BxSp9Yw6z = sorted(dvyo3E0Cs5BxSp9Yw6z,reverse=YOHXqtbQTBfKerIZ,key=lambda key: int(key[YzowicIDTRusXZSU61(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ௄")]))
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧ௅")],[Vk54F7GcROfCy6HunEI]
	try: XHuKtzYRNmd7hTilPx2kM5bpAGJeWZ = zzUrvi7hkBJfIbps4[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭ெ")][kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩே")][HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭ை")]
	except: XHuKtzYRNmd7hTilPx2kM5bpAGJeWZ = []
	try: HHAdCM6JF2B = zzUrvi7hkBJfIbps4[YzowicIDTRusXZSU61(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩ௉")][ESXZrtnCfcDJGo01vFg(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬொ")][SSBkx0WbN1asnDCQV6tIj(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩோ")]
	except: HHAdCM6JF2B = []
	for T3hf4YaerDXq7OlRdgWjcV5Qx in XHuKtzYRNmd7hTilPx2kM5bpAGJeWZ+HHAdCM6JF2B:
		try:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = T3hf4YaerDXq7OlRdgWjcV5Qx[pnkrd2S84FJfN73KuiCYv(u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫௌ")]
			try: title = T3hf4YaerDXq7OlRdgWjcV5Qx[ESXZrtnCfcDJGo01vFg(u"ࠫࡳࡧ࡭ࡦ்ࠩ")][SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩ௎")]
			except: title = T3hf4YaerDXq7OlRdgWjcV5Qx[WXuJd8nz2spo146t(u"࠭࡮ࡢ࡯ࡨࠫ௏")][wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡳࡷࡱࡷࠬௐ")][ufmXvxgoHGDwZtjsLkR05i][l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡶࡨࡼࡹ࠭௑")]
		except: continue
		if title not in nWcb8JC7zEVouFjx9fILGh1vSQ:
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
	if len(nWcb8JC7zEVouFjx9fILGh1vSQ)>pwxH3oREFm5v98BCZ1QVtzMJOc:
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(WXuJd8nz2spo146t(u"ࠩสาฯืࠠศๆอีั๋ษࠡࠪࠪ௒")+str(len(nWcb8JC7zEVouFjx9fILGh1vSQ))+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࠤ๊๊แࠪࠩ௓"),nWcb8JC7zEVouFjx9fILGh1vSQ)
		if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return WCPwmyVsb62KRlo(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ௔"),[],[]
		elif qreJEpY8nZguD!=ufmXvxgoHGDwZtjsLkR05i:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]+MpJ8GOKoic(u"ࠬࠬࠧ௕")
			Up89CQfsYDl7qxG2B = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ௖"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			if Up89CQfsYDl7qxG2B: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(Up89CQfsYDl7qxG2B[ufmXvxgoHGDwZtjsLkR05i],ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨௗ"))
			else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+V2RQwM8XjlrK(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ௘")
			hbLOTmiuwXyaeICo0RJ8Q5AW = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip(eAMGzHRQVs2KyCwPXljYhB(u"ࠩࠩࠫ௙"))
	zzXIPMveV0NZ9qb = []
	for dict in dvyo3E0Cs5BxSp9Yw6z:
		if dict[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡸࡾࡶࡥ࠳ࠩ௚")]==ESXZrtnCfcDJGo01vFg(u"࡛ࠫ࡯ࡤࡦࡱࠪ௛"):
			sgoP5rJGHwaOpzhVnFcC8u9R7ix0kD.append(dict[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡺࡩࡵ࡮ࡨࠫ௜")])
			Im4zFTVQ5HAsDnvCJrbwk9Zl0dMPtK.append(dict)
		elif dict[g7yJo2LVuqx1trPe(u"࠭ࡴࡺࡲࡨ࠶ࠬ௝")]==WsklGNp2CYzVQUag(u"ࠧࡂࡷࡧ࡭ࡴ࠭௞"):
			f5YZgQDCLtK3.append(dict[jXWzIZcDva4ikEUfN(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ௟")])
			Wh7RFgs5b2EeiwX9qPuMKxBDz.append(dict)
		elif dict[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ௠")]==MzgKWUQ4V5H(u"ࠪࡱࡵࡪࠧ௡"):
			title = dict[pnkrd2S84FJfN73KuiCYv(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ௢")].replace(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ௣"),Vk54F7GcROfCy6HunEI)
			if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ௤") not in list(dict.keys()): LL82RbVxIQF1XBfYZM3 = WCPwmyVsb62KRlo(u"ࠧ࠱ࠩ௥")
			else: LL82RbVxIQF1XBfYZM3 = dict[NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௦")]
			zzXIPMveV0NZ9qb.append([dict,{},title,LL82RbVxIQF1XBfYZM3])
		else:
			title = dict[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡷ࡭ࡹࡲࡥࠨ௧")].replace(WsklGNp2CYzVQUag(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ௨"),Vk54F7GcROfCy6HunEI)
			if QYSAUI5r46yil8cfaO(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௩") not in list(dict.keys()): LL82RbVxIQF1XBfYZM3 = wAU9jKvmTM0(u"ࠬ࠶ࠧ௪")
			else: LL82RbVxIQF1XBfYZM3 = dict[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ௫")]
			zzXIPMveV0NZ9qb.append([dict,{},title,LL82RbVxIQF1XBfYZM3])
			Kv52GDqeLyIc8xpzH0dAmPQYuWr.append(title)
			AACdEHIcboigWGsqS53K.append(dict)
		jjT5GisngS8M6YxuXA = YOHXqtbQTBfKerIZ
		if ynxXU3gaiQ9GPCftr1q(u"ࠧࡤࡱࡧࡩࡨࡹࠧ௬") in list(dict.keys()):
			if EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡣࡹ࠴ࠬ௭") in dict[wAU9jKvmTM0(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ௮")]: jjT5GisngS8M6YxuXA = eu1NswY9zkKC60I
			elif gs15xoifvOt<V2RQwM8XjlrK(u"࠵࠽ඔ") and MzgKWUQ4V5H(u"ࠪࡥࡻࡩࠧ௯") not in dict[XCYALgFs2O3hZdpHrlMmB(u"ࠫࡨࡵࡤࡦࡥࡶࠫ௰")] and QYSAUI5r46yil8cfaO(u"ࠬࡳࡰ࠵ࡣࠪ௱") not in dict[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡣࡰࡦࡨࡧࡸ࠭௲")]: jjT5GisngS8M6YxuXA = eu1NswY9zkKC60I
		if jjT5GisngS8M6YxuXA and dict[eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡵࡻࡳࡩ࠷࠭௳")]==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡘ࡬ࡨࡪࡵࠧ௴") and dict[NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡬ࡲ࡮ࡺࠧ௵")]!=YzowicIDTRusXZSU61(u"ࠪ࠴࠲࠶ࠧ௶"):
			JJ0TVO2iGBl3nSQPIzo6N.append(dict[WCPwmyVsb62KRlo(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ௷")])
			TrAwN8daR5QBZq.append(dict)
		elif jjT5GisngS8M6YxuXA and dict[wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡺࡹࡱࡧ࠵ࠫ௸")]==eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡁࡶࡦ࡬ࡳࠬ௹") and dict[XCYALgFs2O3hZdpHrlMmB(u"ࠧࡪࡰ࡬ࡸࠬ௺")]!=jXWzIZcDva4ikEUfN(u"ࠨ࠲࠰࠴ࠬ௻"):
			J59wLTyEC0VOmInazXxMQhGgl213.append(dict[pnkrd2S84FJfN73KuiCYv(u"ࠩࡷ࡭ࡹࡲࡥࠨ௼")])
			bb95ULZdgFSuNx.append(dict)
	for qAOsTxoMtZ7zwgjIu in bb95ULZdgFSuNx:
		A8oDPnzuUpxJ4CXR2 = qAOsTxoMtZ7zwgjIu[QYSAUI5r46yil8cfaO(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ௽")]
		for nn2bOqP6wSXkvUGdAmVDFZs8HaWg in TrAwN8daR5QBZq:
			CNEgLo4dc1GWt693wpKhbFDumA5s = nn2bOqP6wSXkvUGdAmVDFZs8HaWg[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௾")]
			LL82RbVxIQF1XBfYZM3 = int(CNEgLo4dc1GWt693wpKhbFDumA5s)+int(A8oDPnzuUpxJ4CXR2)
			title = nn2bOqP6wSXkvUGdAmVDFZs8HaWg[EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡺࡩࡵ࡮ࡨࠫ௿")].replace(pnkrd2S84FJfN73KuiCYv(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨఀ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧ࡮ࡲࡧࠤࠥ࠭ఁ"))
			title = title.replace(nn2bOqP6wSXkvUGdAmVDFZs8HaWg[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪం")]+YIPoWuLzfl93BTS,Vk54F7GcROfCy6HunEI)
			title = title.replace(CNEgLo4dc1GWt693wpKhbFDumA5s+XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡮ࡦࡵࡹࠧః"),str(LL82RbVxIQF1XBfYZM3)+ESXZrtnCfcDJGo01vFg(u"ࠪ࡯ࡧࡶࡳࠨఄ"))
			title = title+Nlyfx1HnzOWCovke5(u"ࠫ࠭࠭అ")+qAOsTxoMtZ7zwgjIu[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡺࡩࡵ࡮ࡨࠫఆ")].split(wAU9jKvmTM0(u"࠭ࠨࠨఇ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
			zzXIPMveV0NZ9qb.append([nn2bOqP6wSXkvUGdAmVDFZs8HaWg,qAOsTxoMtZ7zwgjIu,title,LL82RbVxIQF1XBfYZM3])
	QneYm8uXW7o = []
	for stream in zzXIPMveV0NZ9qb:
		nn2bOqP6wSXkvUGdAmVDFZs8HaWg,qAOsTxoMtZ7zwgjIu,title,LL82RbVxIQF1XBfYZM3 = stream
		LeInSs4xpZuNJ6 = title[:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧัๅํอࠬఈ") in title: LeInSs4xpZuNJ6 += g7yJo2LVuqx1trPe(u"ࠨ࠭ࠪఉ")
		QneYm8uXW7o.append([stream,LeInSs4xpZuNJ6,int(LL82RbVxIQF1XBfYZM3)])
	p3S4WUQVwJeRbvf7 = eu1NswY9zkKC60I
	m7cJFA1zv65hMDdnxkWbw = NXWlZoh3QPaAwSYx(TVPm7Bz1XOwJ2,QneYm8uXW7o)
	if m7cJFA1zv65hMDdnxkWbw:
		bV8yBEp69o2OdfhHUw0C,bvNp9o8cOlACqJWUMnjwd4BQ,title,LL82RbVxIQF1XBfYZM3 = m7cJFA1zv65hMDdnxkWbw[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i]
		EdalhkyDMgSq4wXjZHtING2Kr3Qm = bV8yBEp69o2OdfhHUw0C[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡸࡶࡱ࠭ఊ")]
		if wAU9jKvmTM0(u"ࠪࡱࡵࡪࠧఋ") in title and EdalhkyDMgSq4wXjZHtING2Kr3Qm!=q97kMO8nQJXNvI: p3S4WUQVwJeRbvf7 = YOHXqtbQTBfKerIZ
		yJdonX8K69lWCHYhabM0w = title
	else:
		l983ZSiueYhbjwrI2tma1UGgDHk7 = NXWlZoh3QPaAwSYx(TVPm7Bz1XOwJ2,QneYm8uXW7o,ynxXU3gaiQ9GPCftr1q(u"࠶࠻࠰࠱ඕ"))
		l983ZSiueYhbjwrI2tma1UGgDHk7,bEFDKxlXPzaCjTf4QS,ppB8omKAnF0 = zip(*l983ZSiueYhbjwrI2tma1UGgDHk7)
		YUKIgtQ9PMj4683rOcWGJzylf,oo3L5YuVsk6ac,A87F1TUbDtBqChKedXuZr9 = [],[],ufmXvxgoHGDwZtjsLkR05i
		zzXIPMveV0NZ9qb = sorted(zzXIPMveV0NZ9qb, reverse=YOHXqtbQTBfKerIZ, key=lambda key: float(key[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]))
		pptdwqz7ZsJkmABaUbVfr9IWl,W3T4GdDX9emNOu8lq1HSUQLI5iP,unz98AvJK01Rx74 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
		try: pptdwqz7ZsJkmABaUbVfr9IWl = zzUrvi7hkBJfIbps4[cpHxZyU7vTtqmIw(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪఌ")][Nlyfx1HnzOWCovke5(u"ࠬࡧࡵࡵࡪࡲࡶࠬ఍")]
		except:
			try: pptdwqz7ZsJkmABaUbVfr9IWl = zZhlVTeynjpctMrH6wqF5PaLUY[MpJ8GOKoic(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬఎ")][MpJ8GOKoic(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧఏ")]
			except: pass
		try: W3T4GdDX9emNOu8lq1HSUQLI5iP = zzUrvi7hkBJfIbps4[Nlyfx1HnzOWCovke5(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧఐ")][MzgKWUQ4V5H(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ఑")]
		except:
			try: W3T4GdDX9emNOu8lq1HSUQLI5iP = zZhlVTeynjpctMrH6wqF5PaLUY[eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩఒ")][l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧఓ")]
			except: pass
		if pptdwqz7ZsJkmABaUbVfr9IWl and W3T4GdDX9emNOu8lq1HSUQLI5iP:
			A87F1TUbDtBqChKedXuZr9 += pwxH3oREFm5v98BCZ1QVtzMJOc
			title = nMt0iueCy6K+eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧఔ")+pptdwqz7ZsJkmABaUbVfr9IWl+ZZoLlKyInXc08j2pTGJ
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = h9zFQKnsNL.SITESURLS[jXWzIZcDva4ikEUfN(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧక")][ufmXvxgoHGDwZtjsLkR05i]+cpHxZyU7vTtqmIw(u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪఖ")+W3T4GdDX9emNOu8lq1HSUQLI5iP
			YUKIgtQ9PMj4683rOcWGJzylf.append(title)
			oo3L5YuVsk6ac.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			try: unz98AvJK01Rx74 = zzUrvi7hkBJfIbps4[cpHxZyU7vTtqmIw(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧగ")][SSBkx0WbN1asnDCQV6tIj(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬఘ")][cpHxZyU7vTtqmIw(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧఙ")][-pwxH3oREFm5v98BCZ1QVtzMJOc][HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡺࡸ࡬ࠨచ")]
			except:
				try: unz98AvJK01Rx74 = zZhlVTeynjpctMrH6wqF5PaLUY[ynxXU3gaiQ9GPCftr1q(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫఛ")][MpJ8GOKoic(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩజ")][MpJ8GOKoic(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫఝ")][-pwxH3oREFm5v98BCZ1QVtzMJOc][HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡷࡵࡰࠬఞ")]
				except: pass
		for nn2bOqP6wSXkvUGdAmVDFZs8HaWg,qAOsTxoMtZ7zwgjIu,title,LL82RbVxIQF1XBfYZM3 in l983ZSiueYhbjwrI2tma1UGgDHk7:
			YUKIgtQ9PMj4683rOcWGJzylf.append(title) ; oo3L5YuVsk6ac.append(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪట"))
		if Kv52GDqeLyIc8xpzH0dAmPQYuWr: YUKIgtQ9PMj4683rOcWGJzylf.append(EM6qpnCBYQGA9kbgDVLfrP(u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬఠ")) ; oo3L5YuVsk6ac.append(wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡲࡻࡸࡦࡦࠪడ"))
		if zzXIPMveV0NZ9qb: YUKIgtQ9PMj4683rOcWGJzylf.append(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩఢ")) ; oo3L5YuVsk6ac.append(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡡ࡭࡮ࠪణ"))
		if JJ0TVO2iGBl3nSQPIzo6N: YUKIgtQ9PMj4683rOcWGJzylf.append(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬత")) ; oo3L5YuVsk6ac.append(jXWzIZcDva4ikEUfN(u"ࠨ࡯ࡳࡨࠬథ"))
		if sgoP5rJGHwaOpzhVnFcC8u9R7ix0kD: YUKIgtQ9PMj4683rOcWGJzylf.append(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩద")) ; oo3L5YuVsk6ac.append(g7yJo2LVuqx1trPe(u"ࠪࡺ࡮ࡪࡥࡰࠩధ"))
		if f5YZgQDCLtK3: YUKIgtQ9PMj4683rOcWGJzylf.append(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫన")) ; oo3L5YuVsk6ac.append(QYSAUI5r46yil8cfaO(u"ࠬࡧࡵࡥ࡫ࡲࠫ఩"))
		while YOHXqtbQTBfKerIZ:
			qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(R32GKXQekBNHIlCpc6,YUKIgtQ9PMj4683rOcWGJzylf)
			if qreJEpY8nZguD==-pwxH3oREFm5v98BCZ1QVtzMJOc: return Nlyfx1HnzOWCovke5(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫప"),[],[]
			elif qreJEpY8nZguD==ufmXvxgoHGDwZtjsLkR05i and pptdwqz7ZsJkmABaUbVfr9IWl:
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = oo3L5YuVsk6ac[qreJEpY8nZguD]
				N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx = yBxCpcVaPow1bztQm4X.argv[ufmXvxgoHGDwZtjsLkR05i]+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧఫ")+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(pptdwqz7ZsJkmABaUbVfr9IWl)+WsklGNp2CYzVQUag(u"ࠨࠨࡸࡶࡱࡃࠧబ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				if unz98AvJK01Rx74: N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx = N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪభ")+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(unz98AvJK01Rx74)
				J2L6to3R1Z.executebuiltin(eAMGzHRQVs2KyCwPXljYhB(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢమ")+N2JAdPoeOLb9IhkRQpm6DGtyTvrZnx+WCPwmyVsb62KRlo(u"ࠦ࠮ࠨయ"))
				return HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪర"),[],[]
			OFEaiVuGrdSf20oxQl57Wp9A = oo3L5YuVsk6ac[qreJEpY8nZguD]
			yJdonX8K69lWCHYhabM0w = YUKIgtQ9PMj4683rOcWGJzylf[qreJEpY8nZguD]
			if OFEaiVuGrdSf20oxQl57Wp9A==wAU9jKvmTM0(u"࠭ࡤࡢࡵ࡫ࠫఱ"):
				EdalhkyDMgSq4wXjZHtING2Kr3Qm = q97kMO8nQJXNvI
				break
			elif OFEaiVuGrdSf20oxQl57Wp9A in [ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡢࡷࡧ࡭ࡴ࠭ల"),WsklGNp2CYzVQUag(u"ࠨࡸ࡬ࡨࡪࡵࠧళ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡰࡹࡽ࡫ࡤࠨఴ")]:
				if OFEaiVuGrdSf20oxQl57Wp9A==ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡱࡺࡾࡥࡥࠩవ"): nWcb8JC7zEVouFjx9fILGh1vSQ,odVChBZnqKLXGl83u = Kv52GDqeLyIc8xpzH0dAmPQYuWr,AACdEHIcboigWGsqS53K
				elif OFEaiVuGrdSf20oxQl57Wp9A==SSBkx0WbN1asnDCQV6tIj(u"ࠫࡻ࡯ࡤࡦࡱࠪశ"): nWcb8JC7zEVouFjx9fILGh1vSQ,odVChBZnqKLXGl83u = sgoP5rJGHwaOpzhVnFcC8u9R7ix0kD,Im4zFTVQ5HAsDnvCJrbwk9Zl0dMPtK
				elif OFEaiVuGrdSf20oxQl57Wp9A==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡧࡵࡥ࡫ࡲࠫష"): nWcb8JC7zEVouFjx9fILGh1vSQ,odVChBZnqKLXGl83u = f5YZgQDCLtK3,Wh7RFgs5b2EeiwX9qPuMKxBDz
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(jXWzIZcDva4ikEUfN(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬస")+str(len(nWcb8JC7zEVouFjx9fILGh1vSQ))+ynxXU3gaiQ9GPCftr1q(u"ࠧࠡ็็ๅ࠮࠭హ"),nWcb8JC7zEVouFjx9fILGh1vSQ)
				if qreJEpY8nZguD!=-pwxH3oREFm5v98BCZ1QVtzMJOc:
					EdalhkyDMgSq4wXjZHtING2Kr3Qm = odVChBZnqKLXGl83u[qreJEpY8nZguD][jXWzIZcDva4ikEUfN(u"ࠨࡷࡵࡰࠬ఺")]
					yJdonX8K69lWCHYhabM0w = nWcb8JC7zEVouFjx9fILGh1vSQ[qreJEpY8nZguD]
					break
			elif OFEaiVuGrdSf20oxQl57Wp9A==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡰࡴࡩ࠭఻"):
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(MzgKWUQ4V5H(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࠦࠨࠨ఼")+str(len(JJ0TVO2iGBl3nSQPIzo6N))+WsklGNp2CYzVQUag(u"๋ࠫࠥไโࠫࠪఽ"),JJ0TVO2iGBl3nSQPIzo6N)
				if qreJEpY8nZguD!=-pwxH3oREFm5v98BCZ1QVtzMJOc:
					yJdonX8K69lWCHYhabM0w = JJ0TVO2iGBl3nSQPIzo6N[qreJEpY8nZguD]
					bV8yBEp69o2OdfhHUw0C = TrAwN8daR5QBZq[qreJEpY8nZguD]
					qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(ynxXU3gaiQ9GPCftr1q(u"ࠬอฮหำࠣะํีษࠡษ็ูํะࠠࠩࠩా")+str(len(J59wLTyEC0VOmInazXxMQhGgl213))+ESXZrtnCfcDJGo01vFg(u"࠭ࠠๆๆไ࠭ࠬి"),J59wLTyEC0VOmInazXxMQhGgl213)
					if qreJEpY8nZguD!=-pwxH3oREFm5v98BCZ1QVtzMJOc:
						yJdonX8K69lWCHYhabM0w += kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࠡ࠭ࠣࠫీ")+J59wLTyEC0VOmInazXxMQhGgl213[qreJEpY8nZguD]
						bvNp9o8cOlACqJWUMnjwd4BQ = bb95ULZdgFSuNx[qreJEpY8nZguD]
						p3S4WUQVwJeRbvf7 = YOHXqtbQTBfKerIZ
						break
			elif OFEaiVuGrdSf20oxQl57Wp9A==wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡣ࡯ࡰࠬు"):
				GUBqzZdtHy9pNJR6jsc2koSQOVfD,NUpJyebPckL3tv,wnrZE3I1lymi0,CSN4fKMdG95 = list(zip(*zzXIPMveV0NZ9qb))
				qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨూ")+str(len(wnrZE3I1lymi0))+pnkrd2S84FJfN73KuiCYv(u"ࠪࠤ๊๊แࠪࠩృ"),wnrZE3I1lymi0)
				if qreJEpY8nZguD!=-pwxH3oREFm5v98BCZ1QVtzMJOc:
					yJdonX8K69lWCHYhabM0w = wnrZE3I1lymi0[qreJEpY8nZguD]
					bV8yBEp69o2OdfhHUw0C = GUBqzZdtHy9pNJR6jsc2koSQOVfD[qreJEpY8nZguD]
					if WsklGNp2CYzVQUag(u"ࠫࡲࡶࡤࠨౄ") in wnrZE3I1lymi0[qreJEpY8nZguD] and bV8yBEp69o2OdfhHUw0C[QYSAUI5r46yil8cfaO(u"ࠬࡻࡲ࡭ࠩ౅")]!=q97kMO8nQJXNvI:
						bvNp9o8cOlACqJWUMnjwd4BQ = NUpJyebPckL3tv[qreJEpY8nZguD]
						p3S4WUQVwJeRbvf7 = YOHXqtbQTBfKerIZ
					else: EdalhkyDMgSq4wXjZHtING2Kr3Qm = bV8yBEp69o2OdfhHUw0C[V2RQwM8XjlrK(u"࠭ࡵࡳ࡮ࠪె")]
					break
			elif OFEaiVuGrdSf20oxQl57Wp9A==SSBkx0WbN1asnDCQV6tIj(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨే"):
				GUBqzZdtHy9pNJR6jsc2koSQOVfD,NUpJyebPckL3tv,wnrZE3I1lymi0,CSN4fKMdG95 = list(zip(*l983ZSiueYhbjwrI2tma1UGgDHk7))
				bV8yBEp69o2OdfhHUw0C = GUBqzZdtHy9pNJR6jsc2koSQOVfD[qreJEpY8nZguD-A87F1TUbDtBqChKedXuZr9]
				if WsklGNp2CYzVQUag(u"ࠨ࡯ࡳࡨࠬై") in wnrZE3I1lymi0[qreJEpY8nZguD-A87F1TUbDtBqChKedXuZr9] and bV8yBEp69o2OdfhHUw0C[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡸࡶࡱ࠭౉")]!=q97kMO8nQJXNvI:
					bvNp9o8cOlACqJWUMnjwd4BQ = NUpJyebPckL3tv[qreJEpY8nZguD-A87F1TUbDtBqChKedXuZr9]
					p3S4WUQVwJeRbvf7 = YOHXqtbQTBfKerIZ
				else: EdalhkyDMgSq4wXjZHtING2Kr3Qm = bV8yBEp69o2OdfhHUw0C[WCPwmyVsb62KRlo(u"ࠪࡹࡷࡲࠧొ")]
				yJdonX8K69lWCHYhabM0w = wnrZE3I1lymi0[qreJEpY8nZguD-A87F1TUbDtBqChKedXuZr9]
				break
	if p3S4WUQVwJeRbvf7:
		ccEPXOnDQ4jzpeWdhvMr6g7kbU2 = int(bV8yBEp69o2OdfhHUw0C[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ో")])
		GGhA1NkPqIuUFbBrWQz3mZgfT = int(bvNp9o8cOlACqJWUMnjwd4BQ[eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧౌ")])
		GbwM6iseo0ZVlh4ydB = str(max(ccEPXOnDQ4jzpeWdhvMr6g7kbU2,GGhA1NkPqIuUFbBrWQz3mZgfT))
		eJVhou7wRYc6xCGMTKbBmzUyLFIWs = bV8yBEp69o2OdfhHUw0C[SSBkx0WbN1asnDCQV6tIj(u"࠭ࡵࡳ࡮్ࠪ")].replace(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࠧࠩ౎"),g7yJo2LVuqx1trPe(u"ࠨࠨࡤࡱࡵࡁࠧ౏"))
		psvjYkK29bNfSrCXW7RATqB4auFx = bvNp9o8cOlACqJWUMnjwd4BQ[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡸࡶࡱ࠭౐")].replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࠪࠬ౑"),cpHxZyU7vTtqmIw(u"ࠫࠫࡧ࡭ࡱ࠽ࠪ౒"))
		mpd = wAU9jKvmTM0(u"ࠬࡂࡍࡑࡆࠣࡱࡪࡪࡩࡢࡒࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࡄࡶࡴࡤࡸ࡮ࡵ࡮࠾ࠤࡓࡘࠬ౓")+GbwM6iseo0ZVlh4ydB+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡓࠣࡀ࡟ࡲࠬ౔")
		mpd += g7yJo2LVuqx1trPe(u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱౕࠫ")
		mpd += ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ౖࠬ")+bV8yBEp69o2OdfhHUw0C[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ౗")]+YzowicIDTRusXZSU61(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧౘ")+bV8yBEp69o2OdfhHUw0C[ESXZrtnCfcDJGo01vFg(u"ࠫࡨࡵࡤࡦࡥࡶࠫౙ")]+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࠨ࠾࡝ࡰࠪౚ")
		mpd += cpHxZyU7vTtqmIw(u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ౛")
		mpd += XCYALgFs2O3hZdpHrlMmB(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ౜")+eJVhou7wRYc6xCGMTKbBmzUyLFIWs+XCYALgFs2O3hZdpHrlMmB(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧౝ")
		mpd += SSBkx0WbN1asnDCQV6tIj(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ౞")+bV8yBEp69o2OdfhHUw0C[V2RQwM8XjlrK(u"ࠪ࡭ࡳࡪࡥࡹࠩ౟")]+FGLEMi21Bfn(u"ࠫࠧࡄ࡜࡯ࠩౠ")
		mpd += XCYALgFs2O3hZdpHrlMmB(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨౡ")+bV8yBEp69o2OdfhHUw0C[wAU9jKvmTM0(u"࠭ࡩ࡯࡫ࡷࠫౢ")]+cpHxZyU7vTtqmIw(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧౣ")
		mpd += Nlyfx1HnzOWCovke5(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ౤")
		mpd += kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ౥")
		mpd += NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ౦")
		mpd += XCYALgFs2O3hZdpHrlMmB(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨ౧")+bvNp9o8cOlACqJWUMnjwd4BQ[MpJ8GOKoic(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ౨")]+ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪ౩")+bvNp9o8cOlACqJWUMnjwd4BQ[WXuJd8nz2spo146t(u"ࠧࡤࡱࡧࡩࡨࡹࠧ౪")]+wYTDlJC5vpOKynUEX3ge6W(u"ࠨࠤࡁࡠࡳ࠭౫")
		mpd += g7yJo2LVuqx1trPe(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ౬")
		mpd += YzowicIDTRusXZSU61(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭౭")+psvjYkK29bNfSrCXW7RATqB4auFx+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ౮")
		mpd += XCYALgFs2O3hZdpHrlMmB(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ౯")+bvNp9o8cOlACqJWUMnjwd4BQ[ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡩ࡯ࡦࡨࡼࠬ౰")]+WCPwmyVsb62KRlo(u"ࠧࠣࡀ࡟ࡲࠬ౱")
		mpd += MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ౲")+bvNp9o8cOlACqJWUMnjwd4BQ[wYTDlJC5vpOKynUEX3ge6W(u"ࠩ࡬ࡲ࡮ࡺࠧ౳")]+WCPwmyVsb62KRlo(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ౴")
		mpd += SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ౵")
		mpd += FGLEMi21Bfn(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ౶")
		mpd += kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ౷")
		mpd += WsklGNp2CYzVQUag(u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ౸")
		mpd += g7yJo2LVuqx1trPe(u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪ౹")
		if PvwFsJK23NbU8XWAx:
			import http.server as bbfQ4DyrmNp
			import http.client as EEzOjT6kJlmQI
		else:
			import BaseHTTPServer as bbfQ4DyrmNp
			import httplib as EEzOjT6kJlmQI
		class MVX7yvfDICOiqEo6KL1tTg2(bbfQ4DyrmNp.HTTPServer):
			def __init__(VcpZjMdTsFyQ43ztmJhiKPL9xq,ip=ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ౺"),port=EM6qpnCBYQGA9kbgDVLfrP(u"࠻࠵࠱࠷࠸ඖ"),mpd=V2RQwM8XjlrK(u"ࠪࡀࡃ࠭౻")):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.ip = ip
				VcpZjMdTsFyQ43ztmJhiKPL9xq.port = port
				VcpZjMdTsFyQ43ztmJhiKPL9xq.mpd = mpd
				bbfQ4DyrmNp.HTTPServer.__init__(VcpZjMdTsFyQ43ztmJhiKPL9xq,(VcpZjMdTsFyQ43ztmJhiKPL9xq.ip,VcpZjMdTsFyQ43ztmJhiKPL9xq.port),wp54FYJcHS8sT)
				VcpZjMdTsFyQ43ztmJhiKPL9xq.mpdurl = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ౼")+ip+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡀࠧ౽")+str(port)+V2RQwM8XjlrK(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ౾")
			def start(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.threads = txAiQRKT0Dyl6VMq4hGeUmf(eu1NswY9zkKC60I)
				VcpZjMdTsFyQ43ztmJhiKPL9xq.threads.pUQTxO8zV5Jrw07WHesiY(pwxH3oREFm5v98BCZ1QVtzMJOc,VcpZjMdTsFyQ43ztmJhiKPL9xq.GGSrLpNoqyRcz3ljBi4fMh5UFCK)
			def GGSrLpNoqyRcz3ljBi4fMh5UFCK(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.keeprunning = YOHXqtbQTBfKerIZ
				while VcpZjMdTsFyQ43ztmJhiKPL9xq.keeprunning:
					VcpZjMdTsFyQ43ztmJhiKPL9xq.handle_request()
			def stop(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.keeprunning = eu1NswY9zkKC60I
				VcpZjMdTsFyQ43ztmJhiKPL9xq.N81zqaL5i3Q()
			def WCVLxEPcfZNT2JGguBn(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.stop()
				VcpZjMdTsFyQ43ztmJhiKPL9xq.bb3RGytoD6Mi1hAP.close()
				VcpZjMdTsFyQ43ztmJhiKPL9xq.server_close()
			def LNCJWsARG6fMQrKwUjvtBz50TE(VcpZjMdTsFyQ43ztmJhiKPL9xq,mpd):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.mpd = mpd
			def N81zqaL5i3Q(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				bIsz45VatWSMRmkyph63Zg1lf = EEzOjT6kJlmQI.HTTPConnection(VcpZjMdTsFyQ43ztmJhiKPL9xq.ip+NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࠻ࠩ౿")+str(VcpZjMdTsFyQ43ztmJhiKPL9xq.port))
				bIsz45VatWSMRmkyph63Zg1lf.request(QYSAUI5r46yil8cfaO(u"ࠣࡊࡈࡅࡉࠨಀ"), pnkrd2S84FJfN73KuiCYv(u"ࠤ࠲ࠦಁ"))
		class wp54FYJcHS8sT(bbfQ4DyrmNp.BaseHTTPRequestHandler):
			def cPDKEFCVOt62MuanTipBr(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.send_response(MpJ8GOKoic(u"࠲࠱࠲඗"))
				VcpZjMdTsFyQ43ztmJhiKPL9xq.send_header(QYSAUI5r46yil8cfaO(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩಂ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨಃ"))
				VcpZjMdTsFyQ43ztmJhiKPL9xq.end_headers()
				VcpZjMdTsFyQ43ztmJhiKPL9xq.wfile.write(VcpZjMdTsFyQ43ztmJhiKPL9xq.oOv4sVqEAmyM.mpd.encode(AoCWwJHgUPKXI7u2lEzym))
				Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
				if VcpZjMdTsFyQ43ztmJhiKPL9xq.path==ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ಄"): VcpZjMdTsFyQ43ztmJhiKPL9xq.oOv4sVqEAmyM.WCVLxEPcfZNT2JGguBn()
				if VcpZjMdTsFyQ43ztmJhiKPL9xq.path==ESXZrtnCfcDJGo01vFg(u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩಅ"): VcpZjMdTsFyQ43ztmJhiKPL9xq.oOv4sVqEAmyM.WCVLxEPcfZNT2JGguBn()
			def IJO7xELvikRu5P8sa(VcpZjMdTsFyQ43ztmJhiKPL9xq):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.send_response(MzgKWUQ4V5H(u"࠳࠲࠳඘"))
				VcpZjMdTsFyQ43ztmJhiKPL9xq.end_headers()
		navsNPcqIzxE3k = MVX7yvfDICOiqEo6KL1tTg2(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪಆ"),WsklGNp2CYzVQUag(u"࠷࠸࠴࠺࠻඙"),mpd)
		EdalhkyDMgSq4wXjZHtING2Kr3Qm = navsNPcqIzxE3k.mpdurl
		navsNPcqIzxE3k.start()
	else: navsNPcqIzxE3k = Vk54F7GcROfCy6HunEI
	if PvwFsJK23NbU8XWAx: vva9ZXdV61tscz8fxUITRAJ,v6NKhwIcCoLk3ifMT = Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨ࡞ࡷࠫಇ")
	else: vva9ZXdV61tscz8fxUITRAJ,v6NKhwIcCoLk3ifMT = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࡟ࡸࠬಈ"),Vk54F7GcROfCy6HunEI
	Jw9P35XfUm7u4BQLRdabAIHW8OoZ = vva9ZXdV61tscz8fxUITRAJ+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡅࡺࡪࡩࡰ࠼ࠣ࡟ࠥ࠭ಉ")+bvNp9o8cOlACqJWUMnjwd4BQ[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡺࡸ࡬ࠨಊ")]+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࠦ࡝࡝ࡰ࡟ࡸࡡࡺࠧಋ")+v6NKhwIcCoLk3ifMT+MpJ8GOKoic(u"࠭ࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩಌ")+bV8yBEp69o2OdfhHUw0C[XCYALgFs2O3hZdpHrlMmB(u"ࠧࡶࡴ࡯ࠫ಍")]+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࠢࡠࠫಎ") if p3S4WUQVwJeRbvf7 else vva9ZXdV61tscz8fxUITRAJ+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡄ࠯࡛ࡀࠠ࡜ࠢࠪಏ")+EdalhkyDMgSq4wXjZHtING2Kr3Qm+WCPwmyVsb62KRlo(u"ࠪࠤࡢ࠭ಐ")
	iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+pnkrd2S84FJfN73KuiCYv(u"ࠫࡡࡺࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡶࡵࡩࡦࡳ࠺ࠡ࡝ࠣࠫ಑")+yJdonX8K69lWCHYhabM0w+V2RQwM8XjlrK(u"ࠬࠦ࡝ࠡࠢࠣࠫಒ")+Jw9P35XfUm7u4BQLRdabAIHW8OoZ)
	if not EdalhkyDMgSq4wXjZHtING2Kr3Qm: return NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭ಓ"),[],[]
	return Vk54F7GcROfCy6HunEI,[yJdonX8K69lWCHYhabM0w],[[EdalhkyDMgSq4wXjZHtING2Kr3Qm,hbLOTmiuwXyaeICo0RJ8Q5AW,navsNPcqIzxE3k]]
def y9dBp80LTvZjFPwmMReYGDI6r(url):
	headers = { SSBkx0WbN1asnDCQV6tIj(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫಔ") : Vk54F7GcROfCy6HunEI }
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨಕ"))
	items = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭ಖ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	items = set(items)
	items = sorted(items, reverse=YOHXqtbQTBfKerIZ, key=lambda key: key[RXnhpCUk4M1TvgJE])
	QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,nWcb8JC7zEVouFjx9fILGh1vSQ,vwYsD8UprydixO3n7L,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[],[],[]
	if not items: return ESXZrtnCfcDJGo01vFg(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡄࡒࡆࠬಗ"),[],[]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,x7ohwWJScUpRi1K50qs,fqNDhEb7ic5rH2K9Rx in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(ESXZrtnCfcDJGo01vFg(u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫಘ"),pnkrd2S84FJfN73KuiCYv(u"ࠬ࡮ࡴࡵࡲ࠽ࠫಙ"))
		if eAMGzHRQVs2KyCwPXljYhB(u"࠭࠮࡮࠵ࡸ࠼ࠬಚ") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz,vwYsD8UprydixO3n7L = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 + vwYsD8UprydixO3n7L
			if QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz[ufmXvxgoHGDwZtjsLkR05i]==wYTDlJC5vpOKynUEX3ge6W(u"ࠧ࠮࠳ࠪಛ"): nWcb8JC7zEVouFjx9fILGh1vSQ.append(g7yJo2LVuqx1trPe(u"ࠨีํีๆืࠠฯษุࠫಜ")+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪಝ"))
			else:
				for title in QyKVgfIsr0BP1XUZJA9c4t26Nuqmjz:
					nWcb8JC7zEVouFjx9fILGh1vSQ.append(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪื๏ืแาࠢัหฺ࠭ಞ")+NaXBAuesz07inT4g6cDt+title)
		else:
			title = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ุࠫ๐ัโำࠣาฬ฻ࠧಟ")+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࠦࠠࠡ࡯ࡳ࠸ࠥࠦࠠࠨಠ")+fqNDhEb7ic5rH2K9Rx
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(title)
	return Vk54F7GcROfCy6HunEI,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
def WZEdv9hYqQDcjtxGn2Ul6f4(url,FjwObZSWkg8ahBdiQf9IeY135DpXoP):
	t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu,fEKuwQDhjX,VV2e6BuEOz9ta,HXhRgxEZ4d2Dek = [],[],[],[],[]
	if pnkrd2S84FJfN73KuiCYv(u"࠭ࡳࡵࡴࠪಡ") not in str(type(FjwObZSWkg8ahBdiQf9IeY135DpXoP)): FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.decode(AoCWwJHgUPKXI7u2lEzym,WsklGNp2CYzVQUag(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧಢ"))
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࠾ࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩಣ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = []
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨತ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = []
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall(pnkrd2S84FJfN73KuiCYv(u"ࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩಥ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp and not fLvc6uEJiq3(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = []
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[ufmXvxgoHGDwZtjsLkR05i]
		title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.rsplit(jXWzIZcDva4ikEUfN(u"ࠫ࠳࠭ದ"),QYSAUI5r46yil8cfaO(u"࠴ක"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
		t8tfMv1VXZYQ5y3.append(title)
		MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	else:
		DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠࠫࠪ࡟࡟࠳࠰࠿࡝࡟ࠬࠫಧ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not DatFuedGb45zR1KqIWNk: DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"࠭ࡶࡢࡴࠣࡷࡴࡻࡲࡤࡧࡶࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪࠩನ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not DatFuedGb45zR1KqIWNk: DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"ࠧࡷࡣࡵࠤ࡯ࡽࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬ಩"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not DatFuedGb45zR1KqIWNk: DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡸࡤࡶࠥࡶ࡬ࡢࡻࡨࡶࠥࡃࠠ࠯ࠬࡂࡠ࠭࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩ࡝ࠫࠪಪ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if DatFuedGb45zR1KqIWNk:
			DatFuedGb45zR1KqIWNk = DatFuedGb45zR1KqIWNk[ufmXvxgoHGDwZtjsLkR05i]
			DatFuedGb45zR1KqIWNk = RSuYINdeamsK0t.sub(EM6qpnCBYQGA9kbgDVLfrP(u"ࡴࠪࠬࡠࡢࡻ࡝࠮ࡠ࡟ࡡࡺ࡜ࡴ࡞ࡱࡠࡷࡣࠪࠪࠪ࡟ࡻ࠰ࡡ࡜ࡵ࡞ࡶࡡ࠯࠯࠺ࠨಫ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࡵࠫࡡ࠷ࠢ࡝࠴ࠥ࠾ࠬಬ"),DatFuedGb45zR1KqIWNk)
			DatFuedGb45zR1KqIWNk = Bw6jaUcFxlqdDT8bC(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡩ࡯ࡣࡵࠩಭ"),DatFuedGb45zR1KqIWNk)
			if isinstance(DatFuedGb45zR1KqIWNk,dict): DatFuedGb45zR1KqIWNk = [DatFuedGb45zR1KqIWNk]
			for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
				L73XUFYncRIVM,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
				if isinstance(UwcYSVZbdK3rI,dict):
					keys = list(UwcYSVZbdK3rI.keys())
					if   V2RQwM8XjlrK(u"ࠬࡺࡹࡱࡧࠪಮ") in keys: L73XUFYncRIVM = str(UwcYSVZbdK3rI[NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡴࡺࡲࡨࠫಯ")])
					if   EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡧ࡫࡯ࡩࠬರ") in keys: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = UwcYSVZbdK3rI[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡨ࡬ࡰࡪ࠭ಱ")]
					elif kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡫ࡰࡸ࠭ಲ") in keys: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = UwcYSVZbdK3rI[YzowicIDTRusXZSU61(u"ࠪ࡬ࡱࡹࠧಳ")]
					elif ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡸࡸࡣࠨ಴") in keys: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = UwcYSVZbdK3rI[XCYALgFs2O3hZdpHrlMmB(u"ࠬࡹࡲࡤࠩವ")]
					if   Nlyfx1HnzOWCovke5(u"࠭࡬ࡢࡤࡨࡰࠬಶ") in keys: title = str(UwcYSVZbdK3rI[FGLEMi21Bfn(u"ࠧ࡭ࡣࡥࡩࡱ࠭ಷ")])
					elif ESXZrtnCfcDJGo01vFg(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡩࡧ࡬࡫࡭ࡺࠧಸ") in keys: title = str(UwcYSVZbdK3rI[jXWzIZcDva4ikEUfN(u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡪࡨ࡭࡬࡮ࡴࠨಹ")])
					elif eAMGzHRQVs2KyCwPXljYhB(u"ࠪ࠲ࠬ಺") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.rsplit(WCPwmyVsb62KRlo(u"ࠫ࠳࠭಻"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
					else: title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				elif isinstance(UwcYSVZbdK3rI,str):
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = UwcYSVZbdK3rI
					title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.rsplit(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࠴಼ࠧ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
				if pwxH3oREFm5v98BCZ1QVtzMJOc:
					t8tfMv1VXZYQ5y3.append(title+YIPoWuLzfl93BTS+L73XUFYncRIVM)
					MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in list(zip(MMJL8QqY6T7dv1onu,t8tfMv1VXZYQ5y3)):
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace(ynxXU3gaiQ9GPCftr1q(u"࠭࡜࡝࠱ࠪಽ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧ࠰ࠩಾ"))
		oOv4sVqEAmyM = RRav1Sf7Px(url,Nlyfx1HnzOWCovke5(u"ࠨࡷࡵࡰࠬಿ"))
		rZigEYv8tbVk = p3QOAkrEuys81JqHobh()
		if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡫ࡸࡹࡶࠧೀ") not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = oOv4sVqEAmyM+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if SSBkx0WbN1asnDCQV6tIj(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩು") in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			headers = {NNjUsZzEcFOAoKry2CDMgb1(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨೂ"):rZigEYv8tbVk,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ೃ"):oOv4sVqEAmyM}
			fqJOC9GR65,jqLVOGcz37JNtr = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,headers)
			VV2e6BuEOz9ta += jqLVOGcz37JNtr
			fEKuwQDhjX += fqJOC9GR65
		else:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬೄ")+rZigEYv8tbVk+FGLEMi21Bfn(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ೅")+oOv4sVqEAmyM
			VV2e6BuEOz9ta.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			fEKuwQDhjX.append(title)
	Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = Vk54F7GcROfCy6HunEI,[],[]
	if VV2e6BuEOz9ta: Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu = Vk54F7GcROfCy6HunEI,fEKuwQDhjX,VV2e6BuEOz9ta
	else:
		if WCPwmyVsb62KRlo(u"ࠨ࠾ࠪೆ") not in FjwObZSWkg8ahBdiQf9IeY135DpXoP and len(FjwObZSWkg8ahBdiQf9IeY135DpXoP)<ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠵࠵࠶ඛ") and FjwObZSWkg8ahBdiQf9IeY135DpXoP: Q0WnJxCYdAINZk2tBjs5 = FjwObZSWkg8ahBdiQf9IeY135DpXoP
		else:
			msg = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"ࠩ࠿ࡨ࡮ࡼࠠࡴࡶࡼࡰࡪࡃࠢ࠯ࠬࡂࠦࡃ࠮ࡆࡪ࡮ࡨ࠲࠯ࡅࠩ࠽ࠩೇ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if not msg: msg = RSuYINdeamsK0t.findall(g7yJo2LVuqx1trPe(u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡸࡳࡣࡻ࡯ࡤࡦࡱࡢࡷࡹࡻࡢࡠࡶࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ೈ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if not msg: msg = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࠫࡁ࡮࠲࠿ࠪࡖࡳࡷࡸࡹ࠯ࠬࡂ࠭ࡁ࠭೉"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if msg: Q0WnJxCYdAINZk2tBjs5 = msg[ufmXvxgoHGDwZtjsLkR05i]
	return Q0WnJxCYdAINZk2tBjs5,t8tfMv1VXZYQ5y3,MMJL8QqY6T7dv1onu
def iBEH7RJKCGoXF(f8RNBobGIzj,url):
	global nvzg3Q5XojyaUYFJPOkql6rf
	url = url.strip(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࠵ࠧೊ"))
	xjofhAUmXqrE1,k8NxAwnQI2FzZCyJYthpaVubLscq = Vk54F7GcROfCy6HunEI,{}
	headers = {wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪೋ"):p3QOAkrEuys81JqHobh()}
	headers[WXuJd8nz2spo146t(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨೌ")] = RRav1Sf7Px(url,MpJ8GOKoic(u"ࠨࡷࡵࡰ್ࠬ"))
	headers[wAU9jKvmTM0(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫ೎")] = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫ೏")
	headers[Nlyfx1HnzOWCovke5(u"ࠫࡘ࡫ࡣ࠮ࡈࡨࡸࡨ࡮࠭ࡅࡧࡶࡸࠬ೐")] = eAMGzHRQVs2KyCwPXljYhB(u"ࠬ࡯ࡦࡳࡣࡰࡩࠬ೑")
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,V2RQwM8XjlrK(u"࠭ࡇࡆࡖࠪ೒"),url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ೓"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	oSHUwkrca7J3jKmpEdN8 = Iy3PA1SVXNfjOchtgHC5kuJBG.code
	if not isinstance(FjwObZSWkg8ahBdiQf9IeY135DpXoP,str): FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.decode(AoCWwJHgUPKXI7u2lEzym,eAMGzHRQVs2KyCwPXljYhB(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ೔"))
	if wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࠨೕ") in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		tcymZ7D4BiLadxl58 = RSuYINdeamsK0t.findall(MzgKWUQ4V5H(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮࡞ࡨࡷࡣ࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭ೖ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if tcymZ7D4BiLadxl58:
			try: xjofhAUmXqrE1 = xukS7TA9pKl(tcymZ7D4BiLadxl58[ufmXvxgoHGDwZtjsLkR05i])
			except: xjofhAUmXqrE1 = Vk54F7GcROfCy6HunEI
	if EM6qpnCBYQGA9kbgDVLfrP(u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠭ࠬ೗") in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		tcymZ7D4BiLadxl58 = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡪ࠯ࡹ࠱ࡴࠬࡵ࠮ࡨ࠰ࡷ࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ೘"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if tcymZ7D4BiLadxl58:
			try: xjofhAUmXqrE1 = nnAikQJ3CUMWVhfatgT(tcymZ7D4BiLadxl58[ufmXvxgoHGDwZtjsLkR05i])
			except: xjofhAUmXqrE1 = Vk54F7GcROfCy6HunEI
	nqzvfpjFuS42ywk8 = FjwObZSWkg8ahBdiQf9IeY135DpXoP+xjofhAUmXqrE1
	if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࠢࡪࡦ࠵ࠦࠬ೙") in nqzvfpjFuS42ywk8 or SSBkx0WbN1asnDCQV6tIj(u"ࠧࠣ࡫ࡧࠦࠬ೚") in nqzvfpjFuS42ywk8:
		JJPyqXx7SRhwBmIDk1bpYtG5dc39e = url.split(ESXZrtnCfcDJGo01vFg(u"ࠨ࠱ࠪ೛"))[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A].replace(cpHxZyU7vTtqmIw(u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ೜"),Vk54F7GcROfCy6HunEI).replace(pnkrd2S84FJfN73KuiCYv(u"ࠪ࠲࡭ࡺ࡭࡭ࠩೝ"),Vk54F7GcROfCy6HunEI)
		if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࠧ࡯ࡤ࠳ࠤࠪೞ") in nqzvfpjFuS42ywk8: k8NxAwnQI2FzZCyJYthpaVubLscq = {g7yJo2LVuqx1trPe(u"ࠬ࡯ࡤ࠳ࠩ೟"):JJPyqXx7SRhwBmIDk1bpYtG5dc39e,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭࡯ࡱࠩೠ"):QYSAUI5r46yil8cfaO(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪೡ")}
		elif jXWzIZcDva4ikEUfN(u"ࠨࠤ࡬ࡨࠧ࠭ೢ") in nqzvfpjFuS42ywk8: k8NxAwnQI2FzZCyJYthpaVubLscq = {eAMGzHRQVs2KyCwPXljYhB(u"ࠩ࡬ࡨࠬೣ"):JJPyqXx7SRhwBmIDk1bpYtG5dc39e,SSBkx0WbN1asnDCQV6tIj(u"ࠪࡳࡵ࠭೤"):MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ೥")}
		eDbTIrV6KLfz80 = headers.copy()
		eDbTIrV6KLfz80[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ೦")] = NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ೧")
		HHA0ZI3kaPXocl7CsGjr = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,MzgKWUQ4V5H(u"ࠧࡑࡑࡖࡘࠬ೨"),url,k8NxAwnQI2FzZCyJYthpaVubLscq,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,cpHxZyU7vTtqmIw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ೩"))
		nqzvfpjFuS42ywk8 = HHA0ZI3kaPXocl7CsGjr.content
	IIguLwlHafAOXDcRhy,i3sadfyJOLSnb,MHfYCdiutEqaXL46yz3IjBFGVT = WZEdv9hYqQDcjtxGn2Ul6f4(url,nqzvfpjFuS42ywk8)
	nvzg3Q5XojyaUYFJPOkql6rf[f8RNBobGIzj] = IIguLwlHafAOXDcRhy,i3sadfyJOLSnb,MHfYCdiutEqaXL46yz3IjBFGVT,oSHUwkrca7J3jKmpEdN8
	return
nvzg3Q5XojyaUYFJPOkql6rf,cenQA1yoRWNtl9f4J = {},ufmXvxgoHGDwZtjsLkR05i
def ToDvrmzes1w(url):
	global nvzg3Q5XojyaUYFJPOkql6rf,cenQA1yoRWNtl9f4J
	cenQA1yoRWNtl9f4J += wYTDlJC5vpOKynUEX3ge6W(u"࠶࠶࠰ග")
	u7NQK3WiJ0MTYg = cenQA1yoRWNtl9f4J
	HXhRgxEZ4d2Dek = [(pwxH3oREFm5v98BCZ1QVtzMJOc,url)]
	hj50MJnoOp6ZWaS1IQ8Elr = url.replace(YzowicIDTRusXZSU61(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ೪"),WXuJd8nz2spo146t(u"ࠪ࠳ࠬ೫"))
	itb54hH6eAY = RSuYINdeamsK0t.findall(WCPwmyVsb62KRlo(u"ࠫࡣ࠮࠮ࠫࡁ࠽࠳࠴࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩࠥࠩ೬"),hj50MJnoOp6ZWaS1IQ8Elr+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࠵ࠧ೭"),RSuYINdeamsK0t.DOTALL)
	try: start,a97BZqbu1t3TvLgy42r6c0foHxWM,end = itb54hH6eAY[ufmXvxgoHGDwZtjsLkR05i]
	except: return MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈࠩ೮"),[],[]
	end = end.strip(wAU9jKvmTM0(u"ࠧ࠰ࠩ೯"))
	Vdb9zaoiOj7NIeMFC = len(a97BZqbu1t3TvLgy42r6c0foHxWM)<BZm7TqLPJfAVblDKsya85zFWXNMY or a97BZqbu1t3TvLgy42r6c0foHxWM in [ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡨ࡬ࡰࡪ࠭೰"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡹ࡭ࡩ࡫࡯ࠨೱ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡺ࡮ࡪࡥࡰࡧࡰࡦࡪࡪࠧೲ"),wAU9jKvmTM0(u"ࠫࡦࡰࡡࡹࠩೳ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࡯ࡦࡳࡣࡰࡩࠬ೴"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡭ࡪࡴࡵࡳࡷ࠭೵")]
	if not Vdb9zaoiOj7NIeMFC: HXhRgxEZ4d2Dek.append([RXnhpCUk4M1TvgJE,start+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ೶")+a97BZqbu1t3TvLgy42r6c0foHxWM+EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ࠱ࠪ೷")+end])
	if end: HXhRgxEZ4d2Dek.append([wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A,start+EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࠲ࠫ೸")+a97BZqbu1t3TvLgy42r6c0foHxWM+XCYALgFs2O3hZdpHrlMmB(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ೹")+end])
	if cpHxZyU7vTtqmIw(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ೺") in a97BZqbu1t3TvLgy42r6c0foHxWM:
		NSjbmRWO6M8sXLE5c9vC2iwZQG7fF = a97BZqbu1t3TvLgy42r6c0foHxWM.replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ೻"),Vk54F7GcROfCy6HunEI)
		HXhRgxEZ4d2Dek.append([BZm7TqLPJfAVblDKsya85zFWXNMY,start+SSBkx0WbN1asnDCQV6tIj(u"࠭࠯ࠨ೼")+NSjbmRWO6M8sXLE5c9vC2iwZQG7fF+WsklGNp2CYzVQUag(u"ࠧ࠰ࠩ೽")+end])
		HXhRgxEZ4d2Dek.append([jXWzIZcDva4ikEUfN(u"࠻ඝ"),start+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ೾")+NSjbmRWO6M8sXLE5c9vC2iwZQG7fF+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࠲ࠫ೿")+end])
		if end: HXhRgxEZ4d2Dek.append([BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠶ඞ"),start+XCYALgFs2O3hZdpHrlMmB(u"ࠪ࠳ࠬഀ")+NSjbmRWO6M8sXLE5c9vC2iwZQG7fF+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬഁ")+end])
	elif Nlyfx1HnzOWCovke5(u"ࠬ࠴ࡨࡵ࡯࡯ࠫം") in end:
		xuXf1hjAIt = end.replace(HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭࠮ࡩࡶࡰࡰࠬഃ"),Vk54F7GcROfCy6HunEI)
		HXhRgxEZ4d2Dek.append([MpJ8GOKoic(u"࠸ඟ"),start+MpJ8GOKoic(u"ࠧ࠰ࠩഄ")+a97BZqbu1t3TvLgy42r6c0foHxWM+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨ࠱ࠪഅ")+xuXf1hjAIt])
		if not Vdb9zaoiOj7NIeMFC: HXhRgxEZ4d2Dek.append([NNjUsZzEcFOAoKry2CDMgb1(u"࠺ච"),start+WCPwmyVsb62KRlo(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪആ")+a97BZqbu1t3TvLgy42r6c0foHxWM+Nlyfx1HnzOWCovke5(u"ࠪ࠳ࠬഇ")+xuXf1hjAIt])
		HXhRgxEZ4d2Dek.append([YzowicIDTRusXZSU61(u"࠼ඡ"),start+jXWzIZcDva4ikEUfN(u"ࠫ࠴࠭ഈ")+a97BZqbu1t3TvLgy42r6c0foHxWM+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ഉ")+xuXf1hjAIt])
	else:
		if not Vdb9zaoiOj7NIeMFC: HXhRgxEZ4d2Dek.append([wYTDlJC5vpOKynUEX3ge6W(u"࠵࠵ජ"),start+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭࠯ࠨഊ")+a97BZqbu1t3TvLgy42r6c0foHxWM+V2RQwM8XjlrK(u"ࠧ࠯ࡪࡷࡱࡱ࠭ഋ")])
		if not Vdb9zaoiOj7NIeMFC: HXhRgxEZ4d2Dek.append([l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠶࠷ඣ"),start+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩഌ")+a97BZqbu1t3TvLgy42r6c0foHxWM+jXWzIZcDva4ikEUfN(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ഍")])
		if end: HXhRgxEZ4d2Dek.append([MzgKWUQ4V5H(u"࠷࠲ඤ"),start+NNjUsZzEcFOAoKry2CDMgb1(u"ࠪ࠳ࠬഎ")+a97BZqbu1t3TvLgy42r6c0foHxWM+WCPwmyVsb62KRlo(u"ࠫ࠴࠭ഏ")+end+Nlyfx1HnzOWCovke5(u"ࠬ࠴ࡨࡵ࡯࡯ࠫഐ")])
		if end: HXhRgxEZ4d2Dek.append([ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠱࠴ඥ"),start+SSBkx0WbN1asnDCQV6tIj(u"࠭࠯ࠨ഑")+a97BZqbu1t3TvLgy42r6c0foHxWM+pnkrd2S84FJfN73KuiCYv(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨഒ")+end+WCPwmyVsb62KRlo(u"ࠨ࠰࡫ࡸࡲࡲࠧഓ")])
	if Vdb9zaoiOj7NIeMFC and end:
		end = end.replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪഔ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪ࠳ࠬക"))
		HXhRgxEZ4d2Dek.append([MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠲࠶ඦ"),start+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫ࠴࠭ഖ")+end])
		HXhRgxEZ4d2Dek.append([V2RQwM8XjlrK(u"࠳࠸ට"),start+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ഗ")+end])
		if V2RQwM8XjlrK(u"࠭࠮ࡩࡶࡰࡰࠬഘ") in end:
			xuXf1hjAIt = end.replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠧ࠯ࡪࡷࡱࡱ࠭ങ"),Vk54F7GcROfCy6HunEI)
			HXhRgxEZ4d2Dek.append([YzowicIDTRusXZSU61(u"࠴࠺ඨ"),start+cpHxZyU7vTtqmIw(u"ࠨ࠱ࠪച")+xuXf1hjAIt])
			HXhRgxEZ4d2Dek.append([g7yJo2LVuqx1trPe(u"࠵࠼ඩ"),start+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪഛ")+xuXf1hjAIt])
		else:
			HXhRgxEZ4d2Dek.append([wYTDlJC5vpOKynUEX3ge6W(u"࠶࠾ඪ"),start+ynxXU3gaiQ9GPCftr1q(u"ࠪ࠳ࠬജ")+end+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࠳࡮ࡴ࡮࡮ࠪഝ")])
			HXhRgxEZ4d2Dek.append([SSBkx0WbN1asnDCQV6tIj(u"࠷࠹ණ"),start+WCPwmyVsb62KRlo(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ഞ")+end+WsklGNp2CYzVQUag(u"࠭࠮ࡩࡶࡰࡰࠬട")])
	Yb9g2lSqHX4RDKWdez6MOCJymv = []
	for w9UG3QYd7oV51ryigjs6kMO,YBDKFZOGfyCHLPA1EaUz9MJ in HXhRgxEZ4d2Dek:
		nvzg3Q5XojyaUYFJPOkql6rf[u7NQK3WiJ0MTYg+w9UG3QYd7oV51ryigjs6kMO] = [tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10]
		H1ye5d60StmrWXATviCaBUqZ = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=iBEH7RJKCGoXF,args=(u7NQK3WiJ0MTYg+w9UG3QYd7oV51ryigjs6kMO,YBDKFZOGfyCHLPA1EaUz9MJ))
		Yb9g2lSqHX4RDKWdez6MOCJymv.append(H1ye5d60StmrWXATviCaBUqZ)
	def lFaESUguGO0eKrW9Xx():
		S8qFckmG72duCn9pgb = eu1NswY9zkKC60I
		for MmPd59qzTto3eGuvrJNL in nvzg3Q5XojyaUYFJPOkql6rf:
			if not MmPd59qzTto3eGuvrJNL: break
		else: S8qFckmG72duCn9pgb = YOHXqtbQTBfKerIZ
		fS1J2Hvtmwc78DUy = J2L6to3R1Z.Player().isPlaying() if h9zFQKnsNL.resolveonly else YOHXqtbQTBfKerIZ
		return S8qFckmG72duCn9pgb or not fS1J2Hvtmwc78DUy
	yQXxP1eirFRKJ5gHbun(Yb9g2lSqHX4RDKWdez6MOCJymv,AFMqxwOy0Xtsiz1e,pt7CIKiU8PVBw194dkQEznq,pwxH3oREFm5v98BCZ1QVtzMJOc,lFaESUguGO0eKrW9Xx)
	Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = Vk54F7GcROfCy6HunEI,[],[]
	VqmY7vQrCJunW0E1taO9dbeKi86z = []
	for w9UG3QYd7oV51ryigjs6kMO,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
		tNZEO2bLYWjcF,szB8fhmcR4NbrWVjn,K51fQOtRTuLyx3qbUnV,B9JrGoycwxXv06DCuRPgSMhUm = nvzg3Q5XojyaUYFJPOkql6rf[u7NQK3WiJ0MTYg+w9UG3QYd7oV51ryigjs6kMO]
		if not yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 and K51fQOtRTuLyx3qbUnV: nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = szB8fhmcR4NbrWVjn,K51fQOtRTuLyx3qbUnV
		if not Q0WnJxCYdAINZk2tBjs5 and tNZEO2bLYWjcF: Q0WnJxCYdAINZk2tBjs5 = tNZEO2bLYWjcF
		if B9JrGoycwxXv06DCuRPgSMhUm: VqmY7vQrCJunW0E1taO9dbeKi86z.append(B9JrGoycwxXv06DCuRPgSMhUm)
	VqmY7vQrCJunW0E1taO9dbeKi86z = list(set(VqmY7vQrCJunW0E1taO9dbeKi86z))
	if not Q0WnJxCYdAINZk2tBjs5 and len(VqmY7vQrCJunW0E1taO9dbeKi86z)==pwxH3oREFm5v98BCZ1QVtzMJOc:
		oSHUwkrca7J3jKmpEdN8 = VqmY7vQrCJunW0E1taO9dbeKi86z[ufmXvxgoHGDwZtjsLkR05i]
		if oSHUwkrca7J3jKmpEdN8!=kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠲࠱࠲ඬ"):
			if oSHUwkrca7J3jKmpEdN8<ufmXvxgoHGDwZtjsLkR05i: Q0WnJxCYdAINZk2tBjs5 = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰࡢࡩࡨ࠳ࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࡩࡣࡦࡵࡶ࡭ࡧࡲࡥࠨഠ")
			else:
				Q0WnJxCYdAINZk2tBjs5 = Nlyfx1HnzOWCovke5(u"ࠨࡊࡗࡘࡕࠦࡅࡳࡴࡲࡶ࠿ࠦࠧഡ")+str(oSHUwkrca7J3jKmpEdN8)
				if PvwFsJK23NbU8XWAx: import http.client as EEzOjT6kJlmQI
				else: import httplib as EEzOjT6kJlmQI
				try: Q0WnJxCYdAINZk2tBjs5 += SSBkx0WbN1asnDCQV6tIj(u"ࠩࠣࠬࠥ࠭ഢ")+EEzOjT6kJlmQI.responses[oSHUwkrca7J3jKmpEdN8]+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࠤ࠮࠭ണ")
				except: pass
	Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
	return Q0WnJxCYdAINZk2tBjs5,nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9
class KK2HgEDzoVlexX6O3SFmy(SZDFRGim3j8L.WindowDialog):
	def __init__(VcpZjMdTsFyQ43ztmJhiKPL9xq, *args, **DmNcelICgHYqBOhudXbs9):
		p0BL8YT3FV1DjUXNACElJzw42qm = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT, EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧത"), kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩഥ"), FGLEMi21Bfn(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡨࡧ࠯ࡲࡱ࡫ࠬദ"))
		Odte1RXvBy2CKLquWzwM = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT, Nlyfx1HnzOWCovke5(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪധ"), wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬന"), wAU9jKvmTM0(u"ࠩࡶࡩࡱ࡫ࡣࡵࡧࡧ࠲ࡵࡴࡧࠨഩ"))
		gMs6dqQUt4whxD0Xv = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT, HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭പ"), Nlyfx1HnzOWCovke5(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨഫ"), kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡨࡵࡵࡶࡲࡲ࡫ࡵ࠮ࡱࡰࡪࠫബ"))
		QCOjG3NmwF97IWVZdiSTDeob5Mnh = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT, SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩഭ"), ESXZrtnCfcDJGo01vFg(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫമ"), ynxXU3gaiQ9GPCftr1q(u"ࠨࡤࡸࡸࡹࡵ࡮࡯ࡨ࠱ࡴࡳ࡭ࠧയ"))
		xxBYXpTE7QOfWF9ALHMNka8GIs = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT, l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬര"), wAU9jKvmTM0(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧറ"), ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡧࡻࡴࡵࡱࡱࡦ࡬࠴ࡰ࡯ࡩࠪല"))
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelled = eu1NswY9zkKC60I
		VcpZjMdTsFyQ43ztmJhiKPL9xq.chk = [ufmXvxgoHGDwZtjsLkR05i] * NNjUsZzEcFOAoKry2CDMgb1(u"࠺ත")
		VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton = [ufmXvxgoHGDwZtjsLkR05i] * pnkrd2S84FJfN73KuiCYv(u"࠻ථ")
		VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate = [eu1NswY9zkKC60I] * jXWzIZcDva4ikEUfN(u"࠼ද")
		tyLf20T9gWpncz1xAsmEPX, iRMF4JmExvzYGCXec9pwd, AA1PvgNb3Zdj6EMcYuS, F9VjW4Tb0q = cpHxZyU7vTtqmIw(u"࠶࠺࠶ධ"), ufmXvxgoHGDwZtjsLkR05i, SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠼࠶࠰න"), SSBkx0WbN1asnDCQV6tIj(u"࠽࠶࠱඲")
		mqM7k24sNOFXvG = tyLf20T9gWpncz1xAsmEPX+AA1PvgNb3Zdj6EMcYuS//RXnhpCUk4M1TvgJE
		peI09xoaADTJ2d8kMEWRl7Sngm, CTy2ZF97paXJgR5BGIKu6fw, XaFgwiTxK82pndR6SMkGbEceLvAJ0, WhpMXSDRt2J7ExqNT6cOs85Hg = wAU9jKvmTM0(u"࠴࠷࠸ප"), g7yJo2LVuqx1trPe(u"࠱࠳࠲ඳ"), eAMGzHRQVs2KyCwPXljYhB(u"࠷࠳࠴ඵ"), eAMGzHRQVs2KyCwPXljYhB(u"࠷࠳࠴ඵ")
		Q6mVfFad9LYZchkyO4t = peI09xoaADTJ2d8kMEWRl7Sngm+XaFgwiTxK82pndR6SMkGbEceLvAJ0//RXnhpCUk4M1TvgJE
		pFn1dOZ8QI, DquTA0xURGv9wj4NKiYISnHBF1Jl, JPeSV72hCA9onpjBQNkfcRtG, N1nCVyefu4vrqs6Jd5WlXxZO = pnkrd2S84FJfN73KuiCYv(u"࠵࠵࠶භ"), YzowicIDTRusXZSU61(u"࠻࠻࠵ම"), ynxXU3gaiQ9GPCftr1q(u"࠴࠹࠵බ"), MpJ8GOKoic(u"࠻࠰ඹ")
		ttQIMZs89K1aJrmkfA5LcRNnBOd = mqM7k24sNOFXvG-JPeSV72hCA9onpjBQNkfcRtG-pFn1dOZ8QI//RXnhpCUk4M1TvgJE
		U1Yt7jIyx8F = mqM7k24sNOFXvG+pFn1dOZ8QI//RXnhpCUk4M1TvgJE
		TatkSgj2bve7lAoK3ErLCU, X0JT2jsYEHkcpS, nnUofpuWAmB0xtDkMP2egSjs, HCbRBEqzV3 = MzgKWUQ4V5H(u"࠳࠶࠷ය"), pnkrd2S84FJfN73KuiCYv(u"࠴࠲ර"), WCPwmyVsb62KRlo(u"࠸࠴࠵ල"), l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠷࠳඼")
		SXQRoNvZMBewOgCKikzYp85rcl, sTF4QMD1kxceE9V8uONraJl, waT24juvUpybqhCLX, TT9SJdNiD6fmLjGl5tR0 = ogJClMiqPa4A0NUtTxpDVybEWG(u"࠷࠺࠻඾"), wYTDlJC5vpOKynUEX3ge6W(u"࠷࠱ශ"), V2RQwM8XjlrK(u"࠻࠰࠱ව"), ynxXU3gaiQ9GPCftr1q(u"࠺࠶඿")
		hMKX3fuEmWS2goNI = eAMGzHRQVs2KyCwPXljYhB(u"࠱࠰࠼ෂ")
		tyLf20T9gWpncz1xAsmEPX, iRMF4JmExvzYGCXec9pwd, AA1PvgNb3Zdj6EMcYuS, F9VjW4Tb0q = int(tyLf20T9gWpncz1xAsmEPX*hMKX3fuEmWS2goNI), int(iRMF4JmExvzYGCXec9pwd*hMKX3fuEmWS2goNI), int(AA1PvgNb3Zdj6EMcYuS*hMKX3fuEmWS2goNI), int(F9VjW4Tb0q*hMKX3fuEmWS2goNI)
		peI09xoaADTJ2d8kMEWRl7Sngm, CTy2ZF97paXJgR5BGIKu6fw, XaFgwiTxK82pndR6SMkGbEceLvAJ0, WhpMXSDRt2J7ExqNT6cOs85Hg = int(peI09xoaADTJ2d8kMEWRl7Sngm*hMKX3fuEmWS2goNI), int(CTy2ZF97paXJgR5BGIKu6fw*hMKX3fuEmWS2goNI), int(XaFgwiTxK82pndR6SMkGbEceLvAJ0*hMKX3fuEmWS2goNI), int(WhpMXSDRt2J7ExqNT6cOs85Hg*hMKX3fuEmWS2goNI)
		ttQIMZs89K1aJrmkfA5LcRNnBOd, x6VL1MYz9IlysNdrP5qBApXt, ppFteb5ZjE9NMxVJU8B2, DY4rn9xBTQs2mkwh = int(ttQIMZs89K1aJrmkfA5LcRNnBOd*hMKX3fuEmWS2goNI), int(DquTA0xURGv9wj4NKiYISnHBF1Jl*hMKX3fuEmWS2goNI), int(JPeSV72hCA9onpjBQNkfcRtG*hMKX3fuEmWS2goNI), int(N1nCVyefu4vrqs6Jd5WlXxZO*hMKX3fuEmWS2goNI)
		U1Yt7jIyx8F, mDkVGIShAyTE92vr03oN, GgCFznPvwspOA6V, DEfudecnmG6LRKAyzM1OWjZ49w = int(U1Yt7jIyx8F*hMKX3fuEmWS2goNI), int(DquTA0xURGv9wj4NKiYISnHBF1Jl*hMKX3fuEmWS2goNI), int(JPeSV72hCA9onpjBQNkfcRtG*hMKX3fuEmWS2goNI), int(N1nCVyefu4vrqs6Jd5WlXxZO*hMKX3fuEmWS2goNI)
		TatkSgj2bve7lAoK3ErLCU, X0JT2jsYEHkcpS, nnUofpuWAmB0xtDkMP2egSjs, HCbRBEqzV3 = int(TatkSgj2bve7lAoK3ErLCU*hMKX3fuEmWS2goNI), int(X0JT2jsYEHkcpS*hMKX3fuEmWS2goNI), int(nnUofpuWAmB0xtDkMP2egSjs*hMKX3fuEmWS2goNI), int(HCbRBEqzV3*hMKX3fuEmWS2goNI)
		SXQRoNvZMBewOgCKikzYp85rcl, sTF4QMD1kxceE9V8uONraJl, waT24juvUpybqhCLX, TT9SJdNiD6fmLjGl5tR0 = int(SXQRoNvZMBewOgCKikzYp85rcl*hMKX3fuEmWS2goNI), int(sTF4QMD1kxceE9V8uONraJl*hMKX3fuEmWS2goNI), int(waT24juvUpybqhCLX*hMKX3fuEmWS2goNI), int(TT9SJdNiD6fmLjGl5tR0*hMKX3fuEmWS2goNI)
		PjdJNLBYbm9Zq3i2 = SZDFRGim3j8L.ControlImage(tyLf20T9gWpncz1xAsmEPX, iRMF4JmExvzYGCXec9pwd, AA1PvgNb3Zdj6EMcYuS, F9VjW4Tb0q, p0BL8YT3FV1DjUXNACElJzw42qm)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(PjdJNLBYbm9Zq3i2)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.iteration = DmNcelICgHYqBOhudXbs9.get(jXWzIZcDva4ikEUfN(u"ࠬ࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࠨള"))
		L0J9uBGmyK = d761ZWXHEvliYN45RzLP2+V2RQwM8XjlrK(u"࠭แฮืࠣว๋อࠠฦ่ึห๋่ࠦๅีอࠤึ๎ศ้ฬࠣࠤࠥࠦࠠࠡࠢࠣࠤࠬഴ")+wAU9jKvmTM0(u"ࠧศๆ่ัฬ๎ไสࠢิๆ๊ࠦࠠࠨവ")+str(VcpZjMdTsFyQ43ztmJhiKPL9xq.iteration)+ZZoLlKyInXc08j2pTGJ
		VcpZjMdTsFyQ43ztmJhiKPL9xq.strActionInfo = SZDFRGim3j8L.ControlLabel(TatkSgj2bve7lAoK3ErLCU, X0JT2jsYEHkcpS, nnUofpuWAmB0xtDkMP2egSjs, HCbRBEqzV3, L0J9uBGmyK, cpHxZyU7vTtqmIw(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨശ"))
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.strActionInfo)
		afR4xElWyzgcNAUnKXBempC = SZDFRGim3j8L.ControlImage(peI09xoaADTJ2d8kMEWRl7Sngm, CTy2ZF97paXJgR5BGIKu6fw, XaFgwiTxK82pndR6SMkGbEceLvAJ0, WhpMXSDRt2J7ExqNT6cOs85Hg, DmNcelICgHYqBOhudXbs9.get(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡦࡥࡵࡺࡣࡩࡣࠪഷ")))
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(afR4xElWyzgcNAUnKXBempC)
		fmOKt5qdS81ZR = d761ZWXHEvliYN45RzLP2+DmNcelICgHYqBOhudXbs9.get(SSBkx0WbN1asnDCQV6tIj(u"ࠪࡱࡸ࡭ࠧസ"))+ZZoLlKyInXc08j2pTGJ
		VcpZjMdTsFyQ43ztmJhiKPL9xq.strActionInfo = SZDFRGim3j8L.ControlLabel(SXQRoNvZMBewOgCKikzYp85rcl, sTF4QMD1kxceE9V8uONraJl, waT24juvUpybqhCLX, TT9SJdNiD6fmLjGl5tR0, fmOKt5qdS81ZR, g7yJo2LVuqx1trPe(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫഹ"))
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.strActionInfo)
		text = d761ZWXHEvliYN45RzLP2+cpHxZyU7vTtqmIw(u"ࠬิั้ฮࠪഺ")+ZZoLlKyInXc08j2pTGJ
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton = SZDFRGim3j8L.ControlButton(ttQIMZs89K1aJrmkfA5LcRNnBOd, x6VL1MYz9IlysNdrP5qBApXt, ppFteb5ZjE9NMxVJU8B2, DY4rn9xBTQs2mkwh, text, focusTexture=xxBYXpTE7QOfWF9ALHMNka8GIs, noFocusTexture=gMs6dqQUt4whxD0Xv, alignment=V2RQwM8XjlrK(u"࠴ස"))
		text = d761ZWXHEvliYN45RzLP2+jXWzIZcDva4ikEUfN(u"࠭วิฬ่ีฬื഻ࠧ")+ZZoLlKyInXc08j2pTGJ
		VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton = SZDFRGim3j8L.ControlButton(U1Yt7jIyx8F, mDkVGIShAyTE92vr03oN, GgCFznPvwspOA6V, DEfudecnmG6LRKAyzM1OWjZ49w, text, focusTexture=xxBYXpTE7QOfWF9ALHMNka8GIs, noFocusTexture=gMs6dqQUt4whxD0Xv, alignment=V2RQwM8XjlrK(u"࠵හ"))
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton)
		rmHfN1ToIJQaRnhx4zyPtL, gn4bKukVeFT3jrOIyXvdM = WhpMXSDRt2J7ExqNT6cOs85Hg//wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A, XaFgwiTxK82pndR6SMkGbEceLvAJ0//wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
		for zHq7nBWJTNyY1I3aLco4AR in range(ynxXU3gaiQ9GPCftr1q(u"࠽ළ")):
			L9oXI3KmdDJVu = zHq7nBWJTNyY1I3aLco4AR // wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			CtKP4MiABvFlZk6qcNHrxwLgDJy = zHq7nBWJTNyY1I3aLco4AR % wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			MwnJo8shkyD4R73BKT = peI09xoaADTJ2d8kMEWRl7Sngm + (gn4bKukVeFT3jrOIyXvdM * CtKP4MiABvFlZk6qcNHrxwLgDJy)
			paStrzhBTMXDxisU0e6Fg3IqJ4Awc = CTy2ZF97paXJgR5BGIKu6fw + (rmHfN1ToIJQaRnhx4zyPtL * L9oXI3KmdDJVu)
			VcpZjMdTsFyQ43ztmJhiKPL9xq.chk[zHq7nBWJTNyY1I3aLco4AR] = SZDFRGim3j8L.ControlImage(MwnJo8shkyD4R73BKT, paStrzhBTMXDxisU0e6Fg3IqJ4Awc, gn4bKukVeFT3jrOIyXvdM, rmHfN1ToIJQaRnhx4zyPtL, Odte1RXvBy2CKLquWzwM)
			VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.chk[zHq7nBWJTNyY1I3aLco4AR])
			VcpZjMdTsFyQ43ztmJhiKPL9xq.chk[zHq7nBWJTNyY1I3aLco4AR].setVisible(eu1NswY9zkKC60I)
			VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR] = SZDFRGim3j8L.ControlButton(MwnJo8shkyD4R73BKT, paStrzhBTMXDxisU0e6Fg3IqJ4Awc, gn4bKukVeFT3jrOIyXvdM, rmHfN1ToIJQaRnhx4zyPtL, str(zHq7nBWJTNyY1I3aLco4AR + pwxH3oREFm5v98BCZ1QVtzMJOc), font=pnkrd2S84FJfN73KuiCYv(u"ࠧࡧࡱࡱࡸ࠶࠹഼ࠧ"), focusTexture=gMs6dqQUt4whxD0Xv, noFocusTexture=QCOjG3NmwF97IWVZdiSTDeob5Mnh)
			VcpZjMdTsFyQ43ztmJhiKPL9xq.addControl(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR])
		for zHq7nBWJTNyY1I3aLco4AR in range(WXuJd8nz2spo146t(u"࠾ෆ")):
			Y1x3dqjtG9WvrhLzO = (zHq7nBWJTNyY1I3aLco4AR // wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A) * wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			xFM9JU3Y6rCv5qLjikg = Y1x3dqjtG9WvrhLzO + (zHq7nBWJTNyY1I3aLco4AR + pwxH3oREFm5v98BCZ1QVtzMJOc) % wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			sM7h5SrU9Yo = Y1x3dqjtG9WvrhLzO + (zHq7nBWJTNyY1I3aLco4AR - pwxH3oREFm5v98BCZ1QVtzMJOc) % wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			by0KQ7ijNAP346 = (zHq7nBWJTNyY1I3aLco4AR - wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A) % kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠿෇")
			d6duFGJC28ImHM01fzKrSVischxjE = (zHq7nBWJTNyY1I3aLco4AR + wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A) % ESXZrtnCfcDJGo01vFg(u"࠹෈")
			VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlRight(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[xFM9JU3Y6rCv5qLjikg])
			VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlLeft(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[sM7h5SrU9Yo])
			if zHq7nBWJTNyY1I3aLco4AR <= RXnhpCUk4M1TvgJE:
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlUp(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
			else:
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlUp(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[by0KQ7ijNAP346])
			if zHq7nBWJTNyY1I3aLco4AR >= wAU9jKvmTM0(u"࠷෉"):
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlDown(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
			else:
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[zHq7nBWJTNyY1I3aLco4AR].controlDown(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[d6duFGJC28ImHM01fzKrSVischxjE])
		VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton.controlLeft(VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton.controlRight(VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton.controlLeft(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton.controlRight(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
		VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton.controlDown(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[RXnhpCUk4M1TvgJE])
		VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton.controlUp(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[eAMGzHRQVs2KyCwPXljYhB(u"࠺්")])
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton.controlDown(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[ufmXvxgoHGDwZtjsLkR05i])
		VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton.controlUp(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkbutton[MpJ8GOKoic(u"࠹෋")])
		VcpZjMdTsFyQ43ztmJhiKPL9xq.setFocus(VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton)
	def get(VcpZjMdTsFyQ43ztmJhiKPL9xq):
		VcpZjMdTsFyQ43ztmJhiKPL9xq.doModal()
		VcpZjMdTsFyQ43ztmJhiKPL9xq.close()
		if not VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelled:
			return [zHq7nBWJTNyY1I3aLco4AR for zHq7nBWJTNyY1I3aLco4AR in range(eAMGzHRQVs2KyCwPXljYhB(u"࠽෌")) if VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate[zHq7nBWJTNyY1I3aLco4AR]]
	def onControl(VcpZjMdTsFyQ43ztmJhiKPL9xq, UegzrGDOpAMb6):
		if UegzrGDOpAMb6.getId() == VcpZjMdTsFyQ43ztmJhiKPL9xq.okbutton.getId() and any(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate):
			VcpZjMdTsFyQ43ztmJhiKPL9xq.close()
		elif UegzrGDOpAMb6.getId() == VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelbutton.getId():
			VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelled = YOHXqtbQTBfKerIZ
			VcpZjMdTsFyQ43ztmJhiKPL9xq.close()
		else:
			fqNDhEb7ic5rH2K9Rx = UegzrGDOpAMb6.getLabel()
			if fqNDhEb7ic5rH2K9Rx.isnumeric():
				index = int(fqNDhEb7ic5rH2K9Rx) - pwxH3oREFm5v98BCZ1QVtzMJOc
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate[index] = not VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate[index]
				VcpZjMdTsFyQ43ztmJhiKPL9xq.chk[index].setVisible(VcpZjMdTsFyQ43ztmJhiKPL9xq.chkstate[index])
	def onAction(VcpZjMdTsFyQ43ztmJhiKPL9xq, fJFrAMYPDz):
		if fJFrAMYPDz == l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠶࠶෍"):
			VcpZjMdTsFyQ43ztmJhiKPL9xq.cancelled = YOHXqtbQTBfKerIZ
			VcpZjMdTsFyQ43ztmJhiKPL9xq.close()
def ghFlf6dBacuQC8TXIWzS0Dno5Nq7(key,bLsYAq6gD3mJW8Xw,url):
	headers = {jXWzIZcDva4ikEUfN(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩഽ"):url,g7yJo2LVuqx1trPe(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫാ"):bLsYAq6gD3mJW8Xw}
	NyJV6Ha3DxibAcC1Y2Gu7TwSh = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠯ࡢࡲ࡬࠳࡫ࡧ࡬࡭ࡤࡤࡧࡰࡅ࡫࠾ࠩി")+key
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡌࡋࡔࠨീ"),NyJV6Ha3DxibAcC1Y2Gu7TwSh,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡈࡘࡤࡘࡅࡄࡃࡓࡘࡈࡎࡁ࠳ࡡࡗࡓࡐࡋࡎ࠮࠳ࡶࡸࠬു"))
	cVbGQZ5wHCNO6pU8nKt2Ji,iteration = Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i
	while YOHXqtbQTBfKerIZ:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		k8NxAwnQI2FzZCyJYthpaVubLscq = RSuYINdeamsK0t.findall(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࠢࠩ࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠴࠲ࡴࡦࡿ࡬ࡰࡣࡧ࡟ࡣࠨ࡝ࠬࠫࠪൂ"), FjwObZSWkg8ahBdiQf9IeY135DpXoP)
		iteration += pwxH3oREFm5v98BCZ1QVtzMJOc
		message = RSuYINdeamsK0t.findall(MzgKWUQ4V5H(u"ࠧ࠽࡮ࡤࡦࡪࡲ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡵࡧࡻࡸࠧࡡ࡞࠿࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱࡧࡢࡦ࡮ࡁࠫൃ"), FjwObZSWkg8ahBdiQf9IeY135DpXoP)
		if not message: message = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ࠾ࡧ࡭ࡻࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡥࡳࡴࡲࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫൄ"), FjwObZSWkg8ahBdiQf9IeY135DpXoP)
		if not message:
			cVbGQZ5wHCNO6pU8nKt2Ji = RSuYINdeamsK0t.findall(cpHxZyU7vTtqmIw(u"ࠩࡵࡩࡦࡪ࡯࡯࡮ࡼࡂ࠭࠴ࠪࡀࠫ࠿ࠫ൅"), FjwObZSWkg8ahBdiQf9IeY135DpXoP)[ufmXvxgoHGDwZtjsLkR05i]
			break
		else:
			message = message[ufmXvxgoHGDwZtjsLkR05i]
			k8NxAwnQI2FzZCyJYthpaVubLscq = k8NxAwnQI2FzZCyJYthpaVubLscq[ufmXvxgoHGDwZtjsLkR05i]
		yL6z7HA3Ut2FpQoflMr0 = RSuYINdeamsK0t.findall(SSBkx0WbN1asnDCQV6tIj(u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡧࠧࡢࡳࠬࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩെ"), FjwObZSWkg8ahBdiQf9IeY135DpXoP)[ufmXvxgoHGDwZtjsLkR05i]
		z6JoDLq3lXP5FUvb = SSBkx0WbN1asnDCQV6tIj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲࠫࡳࠨേ") % (k8NxAwnQI2FzZCyJYthpaVubLscq.replace(XCYALgFs2O3hZdpHrlMmB(u"ࠬࠬࡡ࡮ࡲ࠾ࠫൈ"), EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࠦࠨ൉")))
		message = RSuYINdeamsK0t.sub(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧ࠽࠱ࡂࠬࡩ࡯ࡶࡽࡵࡷࡶࡴࡴࡧࠪ࡝ࡡࡂࡢ࠰࠾ࠨൊ"), Vk54F7GcROfCy6HunEI, message)
		SHLwJKv7Wus6qP = KK2HgEDzoVlexX6O3SFmy(captcha=z6JoDLq3lXP5FUvb, msg=message, iteration=iteration)
		fvSECI3JaM4nUQkVYro5D = SHLwJKv7Wus6qP.get()
		if not fvSECI3JaM4nUQkVYro5D: break
		data = {wAU9jKvmTM0(u"ࠨࡥࠪോ"): yL6z7HA3Ut2FpQoflMr0, ESXZrtnCfcDJGo01vFg(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫൌ"): fvSECI3JaM4nUQkVYro5D}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡔࡔ࡙ࡔࠨ്"),NyJV6Ha3DxibAcC1Y2Gu7TwSh,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠳ࡰࡧࠫൎ"))
	return cVbGQZ5wHCNO6pU8nKt2Ji
def qPwySnJRkGuX3hQdOLi(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ൏"))
	items = RSuYINdeamsK0t.findall(ESXZrtnCfcDJGo01vFg(u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ൐"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ items[ufmXvxgoHGDwZtjsLkR05i] ]
	else: return XCYALgFs2O3hZdpHrlMmB(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬ൑"),[],[]
def ZeGsbz1JVjFioIU(url):
	return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
def kx1ozQyOftL(url):
	oOv4sVqEAmyM = url.split(MzgKWUQ4V5H(u"ࠨ࠱ࠪ൒"))
	wwZFRmvVYclIdobGKaN4iHLgrp8U57 = ESXZrtnCfcDJGo01vFg(u"ࠩ࠲ࠫ൓").join(oOv4sVqEAmyM[ufmXvxgoHGDwZtjsLkR05i:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A])
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧൔ"))
	items = RSuYINdeamsK0t.findall(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ൕ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		ConymrfAVFKMTuhz,IID2SFskQaGtRgu0p4xqyLnvOU,cBfzEmAetGSDF64blZoXKwY57nN,r8rlzO7IjNvHGmdZoe4B2,U2DsrO7y5klcJxtZQfXWS43j,Baq9UdAKO37QV8mJjvfCM5FozY = items[ufmXvxgoHGDwZtjsLkR05i]
		qVFIRlAkhETb2J1OZMBjX5 = int(IID2SFskQaGtRgu0p4xqyLnvOU) % int(cBfzEmAetGSDF64blZoXKwY57nN) + int(r8rlzO7IjNvHGmdZoe4B2) % int(U2DsrO7y5klcJxtZQfXWS43j)
		url = wwZFRmvVYclIdobGKaN4iHLgrp8U57 + ConymrfAVFKMTuhz + str(qVFIRlAkhETb2J1OZMBjX5) + Baq9UdAKO37QV8mJjvfCM5FozY
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[url]
	else: return jXWzIZcDva4ikEUfN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫൖ"),[],[]
def ClKL7mkBz8VIqnYxPp9wTUSWajg(url):
	id = url.split(WXuJd8nz2spo146t(u"࠭࠯ࠨൗ"))[-pwxH3oREFm5v98BCZ1QVtzMJOc]
	headers = { WsklGNp2CYzVQUag(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭൘") : l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ൙") }
	k8NxAwnQI2FzZCyJYthpaVubLscq = { BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠤ࡬ࡨࠧ൚"):id , kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠥࡳࡵࠨ൛"):g7yJo2LVuqx1trPe(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠢ൜") }
	MmpRngPUCzrJ0HlGfB = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡖࡏࡔࡖࠪ൝"), url, k8NxAwnQI2FzZCyJYthpaVubLscq, headers, Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ൞"))
	if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩൟ") in list(MmpRngPUCzrJ0HlGfB.headers.keys()): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = MmpRngPUCzrJ0HlGfB.headers[pnkrd2S84FJfN73KuiCYv(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪൠ")]
	else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	else: return kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠧൡ"),[],[]
def rUKEGsRwtDF9VS5M(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡊࡐࡗ࡚ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭ൢ"))
	items = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠫࡲࡶ࠴࠻ࠢ࡟࡟ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧൣ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ items[ufmXvxgoHGDwZtjsLkR05i] ]
	else: return SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ൤"),[],[]
def IvurTMR8L94(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jXWzIZcDva4ikEUfN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ൥"))
	items = RSuYINdeamsK0t.findall(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ൦"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		url = url = Nlyfx1HnzOWCovke5(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ൧") + items[ufmXvxgoHGDwZtjsLkR05i]
		return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ url ]
	else: return WCPwmyVsb62KRlo(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡃࡉࡋ࡙ࡉࠬ൨"),[],[]
def L1qEhFWxlsr7ndt9(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ൩"))
	items = RSuYINdeamsK0t.findall(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ൪"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items: return Vk54F7GcROfCy6HunEI,[Vk54F7GcROfCy6HunEI],[ items[ufmXvxgoHGDwZtjsLkR05i] ]
	else: return wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ൫"),[],[]
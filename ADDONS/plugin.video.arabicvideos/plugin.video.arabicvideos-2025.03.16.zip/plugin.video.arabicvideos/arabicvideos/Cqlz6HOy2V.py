# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from C6bDm3h7Zp import *
import base64 as PnRA5dpzE18JU
TVPm7Bz1XOwJ2 = jXWzIZcDva4ikEUfN(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪำ")
if PvwFsJK23NbU8XWAx:
	ruMn0Ry9WJd8I1L = KFHneBUpcouQx9gWG1.translatePath(Nlyfx1HnzOWCovke5(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫิ"))
	Z7NtweOaCqhSgKuT1A5rip6sbP23 = KFHneBUpcouQx9gWG1.translatePath(YzowicIDTRusXZSU61(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬี"))
	UrJ5GQheX9YF2uMzcykWZPNt = KFHneBUpcouQx9gWG1.translatePath(WXuJd8nz2spo146t(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩึ"))
	qqcpbNo3gTyUdmsS10MGuKa = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,WsklGNp2CYzVQUag(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨื"),WXuJd8nz2spo146t(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦุࠩ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧู࠭"))
	iio06EkAzYL2JbGR = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤฺࠫ"),SSBkx0WbN1asnDCQV6tIj(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ฻"),cpHxZyU7vTtqmIw(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ฼"))
	KKx9waqGFuyfT = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,Nlyfx1HnzOWCovke5(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ฽"),cpHxZyU7vTtqmIw(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ฾"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ฿"))
	WWXlgMJx4SP910N = g7yJo2LVuqx1trPe(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩเ")
	from urllib.parse import quote as _BZx4zleFGV95ynuPi
else:
	ruMn0Ry9WJd8I1L = J2L6to3R1Z.translatePath(Nlyfx1HnzOWCovke5(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪแ"))
	Z7NtweOaCqhSgKuT1A5rip6sbP23 = J2L6to3R1Z.translatePath(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫโ"))
	UrJ5GQheX9YF2uMzcykWZPNt = J2L6to3R1Z.translatePath(MpJ8GOKoic(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨใ"))
	qqcpbNo3gTyUdmsS10MGuKa = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,XCYALgFs2O3hZdpHrlMmB(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧไ"),pnkrd2S84FJfN73KuiCYv(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨๅ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬๆ"))
	iio06EkAzYL2JbGR = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,Nlyfx1HnzOWCovke5(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ็"),SSBkx0WbN1asnDCQV6tIj(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨ่ࠫ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤ้ࠪ"))
	KKx9waqGFuyfT = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,WXuJd8nz2spo146t(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ๊࠭"),YzowicIDTRusXZSU61(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫๋ࠧ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭์"))
	WWXlgMJx4SP910N = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨํ").encode(AoCWwJHgUPKXI7u2lEzym)
	from urllib import quote as _BZx4zleFGV95ynuPi
uta6N9f2PIW8e = CR3aLOVKSIme5XFoYi6M.path.join(UrJ5GQheX9YF2uMzcykWZPNt,ynxXU3gaiQ9GPCftr1q(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ๎"))
DbAmP8JkBMXZciCI9nT = CR3aLOVKSIme5XFoYi6M.path.join(UrJ5GQheX9YF2uMzcykWZPNt,MzgKWUQ4V5H(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ๏"))
yH76LQ2Yigdkfp = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,MzgKWUQ4V5H(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ๐"))
TI7QuAnOoX2 = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,MzgKWUQ4V5H(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭๑"))
zB2N6o5eEpuUQ4xIDRFg30WSv = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ๒"))
n28VC34lcrAhgiJtKXU7WqjTOw9 = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,SSBkx0WbN1asnDCQV6tIj(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ๓"))
K1zl4dy3IfeHs506mhJLX = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,ynxXU3gaiQ9GPCftr1q(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ๔"))
M4zlTexHiEmjoS = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ๕"))
dQxGp0knIfj = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡬ࡱࡦ࡭ࡥࡴࠩ๖"))
YYFHjzBNpw97V = CR3aLOVKSIme5XFoYi6M.path.join(dQxGp0knIfj,QYSAUI5r46yil8cfaO(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫ๗"))
LK7CQmtyiX2 = CR3aLOVKSIme5XFoYi6M.path.join(dQxGp0knIfj,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡶࠫ๘"))
HBALC2smGtRxwFluDOgdX = CR3aLOVKSIme5XFoYi6M.path.join(YYFHjzBNpw97V,ynxXU3gaiQ9GPCftr1q(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨ๙"))
cbFKmEkqwLU0vYD3pT = ri6sIqCkQb4h.Addon().getAddonInfo(wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡰࡢࡶ࡫ࠫ๚"))
aa9QT64pMHJykDWewF25 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,cpHxZyU7vTtqmIw(u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩ๛"))
dZNWQ4pMIP5vkjmlr0y = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,YzowicIDTRusXZSU61(u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫ๜"))
giopwV7YFJZ1cXAz = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭๝"))
bbyfalQZVUCHXh3dR7cEIJnWtN4 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,V2RQwM8XjlrK(u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ๞"))
FJMD0bCjrXHqaS8Q9 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫ๟"))
NMyJ2BzeurhfwUvAP986XTESGW1 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,cpHxZyU7vTtqmIw(u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩ๠"))
S8BLAj6w1zsMTeq = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭๡"))
jjxTIX2z94FBaCRb7OsWmMZ = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,Nlyfx1HnzOWCovke5(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭๢"))
KC4gIs8aTpjqBNhYkrdR9ZVJMz = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,XCYALgFs2O3hZdpHrlMmB(u"ࠨ࡯ࡨࡲࡺࡥࡲࡦࡦࡢ࠶࠵࠶ࡸ࠳࠷࠳࠲ࡵࡴࡧࠨ๣"))
BLfQzvAhUyYdas4wHCPrbEXZkgn6J = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,MpJ8GOKoic(u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩ๤"))
HTx0geQ7siEXV = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,Nlyfx1HnzOWCovke5(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ๥"))
c8UQH9gLTjkAO2tMBeaJFGh05sYN = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭๦"),MzgKWUQ4V5H(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ๧"),DDXHAicJtj6)
ZZ0elhq5SkW1cpPUJz = CR3aLOVKSIme5XFoYi6M.path.join(c8UQH9gLTjkAO2tMBeaJFGh05sYN,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ๨"))
BsdjXEqRlKmkePz8F = CR3aLOVKSIme5XFoYi6M.path.join(ruMn0Ry9WJd8I1L,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡮ࡧࡧ࡭ࡦ࠭๩"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡈࡲࡲࡹࡹࠧ๪"),eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬ๫"))
class b8RlryPD5BkJoYs9jFTQga6t41V(IIRl9dofH3J2inXOjCeQatA18g):
	def __init__(j5ELIpxCMhNRo1UGZydYzcD,*aargs,**kkwargs):
		j5ELIpxCMhNRo1UGZydYzcD.choiceID = -pwxH3oREFm5v98BCZ1QVtzMJOc
	def onClick(j5ELIpxCMhNRo1UGZydYzcD,KcfkJ25MpFo1lCzYIjW0yX):
		if KcfkJ25MpFo1lCzYIjW0yX>=YzowicIDTRusXZSU61(u"࠻࠳࠵࠵᎝"): j5ELIpxCMhNRo1UGZydYzcD.choiceID = KcfkJ25MpFo1lCzYIjW0yX-YzowicIDTRusXZSU61(u"࠻࠳࠵࠵᎝")
		j5ELIpxCMhNRo1UGZydYzcD.U9ahP7fe4y1XNr8IkGHconE()
	def eV48fz316u5QhEglBRoUWCcLr0(j5ELIpxCMhNRo1UGZydYzcD,*aargs):
		j5ELIpxCMhNRo1UGZydYzcD.button0,j5ELIpxCMhNRo1UGZydYzcD.button1,j5ELIpxCMhNRo1UGZydYzcD.button2 = aargs[ufmXvxgoHGDwZtjsLkR05i],aargs[pwxH3oREFm5v98BCZ1QVtzMJOc],aargs[RXnhpCUk4M1TvgJE]
		j5ELIpxCMhNRo1UGZydYzcD.header,j5ELIpxCMhNRo1UGZydYzcD.text = aargs[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A],aargs[BZm7TqLPJfAVblDKsya85zFWXNMY]
		j5ELIpxCMhNRo1UGZydYzcD.profile,j5ELIpxCMhNRo1UGZydYzcD.direction = aargs[pnkrd2S84FJfN73KuiCYv(u"࠸᎞")],aargs[FGLEMi21Bfn(u"࠺᎟")]
		j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout,j5ELIpxCMhNRo1UGZydYzcD.closetimeout = aargs[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠽Ꭱ")],aargs[pnkrd2S84FJfN73KuiCYv(u"࠽Ꭰ")]
		if j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout>ufmXvxgoHGDwZtjsLkR05i or j5ELIpxCMhNRo1UGZydYzcD.closetimeout>cpHxZyU7vTtqmIw(u"࠰Ꭲ"): j5ELIpxCMhNRo1UGZydYzcD.enable_progressbar = YOHXqtbQTBfKerIZ
		else: j5ELIpxCMhNRo1UGZydYzcD.enable_progressbar = eu1NswY9zkKC60I
		j5ELIpxCMhNRo1UGZydYzcD.image_filename = HBALC2smGtRxwFluDOgdX.replace(NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ๬"),SSBkx0WbN1asnDCQV6tIj(u"ࠫࡤ࠭๭")+str(Gb6kwVlSQ4MU.time())+WCPwmyVsb62KRlo(u"ࠬࡥࠧ๮"))
		j5ELIpxCMhNRo1UGZydYzcD.image_filename = j5ELIpxCMhNRo1UGZydYzcD.image_filename.replace(cpHxZyU7vTtqmIw(u"࠭࡜࡝ࠩ๯"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧ࡝࡞࡟ࡠࠬ๰")).replace(ynxXU3gaiQ9GPCftr1q(u"ࠨ࠱࠲ࠫ๱"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࠲࠳࠴࠵ࠧ๲"))
		j5ELIpxCMhNRo1UGZydYzcD.image_height = HmN7xPhSEQLzrqU(j5ELIpxCMhNRo1UGZydYzcD.button0,j5ELIpxCMhNRo1UGZydYzcD.button1,j5ELIpxCMhNRo1UGZydYzcD.button2,j5ELIpxCMhNRo1UGZydYzcD.header,j5ELIpxCMhNRo1UGZydYzcD.text,j5ELIpxCMhNRo1UGZydYzcD.profile,j5ELIpxCMhNRo1UGZydYzcD.direction,j5ELIpxCMhNRo1UGZydYzcD.enable_progressbar,j5ELIpxCMhNRo1UGZydYzcD.image_filename)
		j5ELIpxCMhNRo1UGZydYzcD.show()
		j5ELIpxCMhNRo1UGZydYzcD.getControl(g7yJo2LVuqx1trPe(u"࠺࠲࠸࠴Ꭳ")).setImage(j5ELIpxCMhNRo1UGZydYzcD.image_filename)
		j5ELIpxCMhNRo1UGZydYzcD.getControl(pnkrd2S84FJfN73KuiCYv(u"࠻࠳࠹࠵Ꭴ")).setHeight(j5ELIpxCMhNRo1UGZydYzcD.image_height)
		if not j5ELIpxCMhNRo1UGZydYzcD.button1 and j5ELIpxCMhNRo1UGZydYzcD.button0 and j5ELIpxCMhNRo1UGZydYzcD.button2: j5ELIpxCMhNRo1UGZydYzcD.getControl(WsklGNp2CYzVQUag(u"࠽࠵࠷࠲Ꭶ")).setPosition(-Nlyfx1HnzOWCovke5(u"࠷࠸࠰Ꭷ"),WXuJd8nz2spo146t(u"࠳Ꭵ"))
		return j5ELIpxCMhNRo1UGZydYzcD.image_filename,j5ELIpxCMhNRo1UGZydYzcD.image_height
	def NykG4LxE0SldQ69TfcIMbuq(j5ELIpxCMhNRo1UGZydYzcD):
		if j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout:
			j5ELIpxCMhNRo1UGZydYzcD.th1 = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=j5ELIpxCMhNRo1UGZydYzcD.AqpE6RvtDc3ONX1C)
			j5ELIpxCMhNRo1UGZydYzcD.th1.start()
		else: j5ELIpxCMhNRo1UGZydYzcD.y8QVNgke2IvdiKApRrZPW()
	def AqpE6RvtDc3ONX1C(j5ELIpxCMhNRo1UGZydYzcD):
		j5ELIpxCMhNRo1UGZydYzcD.getControl(MzgKWUQ4V5H(u"࠿࠰࠳࠲Ꭸ")).setEnabled(YOHXqtbQTBfKerIZ)
		for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(pwxH3oREFm5v98BCZ1QVtzMJOc,j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout+pwxH3oREFm5v98BCZ1QVtzMJOc):
			Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
			coSpN5dWevQiExMTP82Y = int(Nlyfx1HnzOWCovke5(u"࠱࠱࠲Ꭹ")*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz/j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout)
			j5ELIpxCMhNRo1UGZydYzcD.KfmTsSbtH10R3(coSpN5dWevQiExMTP82Y)
			if j5ELIpxCMhNRo1UGZydYzcD.choiceID>EM6qpnCBYQGA9kbgDVLfrP(u"࠱Ꭺ"): break
		j5ELIpxCMhNRo1UGZydYzcD.y8QVNgke2IvdiKApRrZPW()
	def JgQYaw19VGcFRfqsM46PK(j5ELIpxCMhNRo1UGZydYzcD):
		if j5ELIpxCMhNRo1UGZydYzcD.closetimeout:
			j5ELIpxCMhNRo1UGZydYzcD.th2 = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=j5ELIpxCMhNRo1UGZydYzcD.CQ4EpX7gtUsY)
			j5ELIpxCMhNRo1UGZydYzcD.th2.start()
		else: j5ELIpxCMhNRo1UGZydYzcD.y8QVNgke2IvdiKApRrZPW()
	def CQ4EpX7gtUsY(j5ELIpxCMhNRo1UGZydYzcD):
		j5ELIpxCMhNRo1UGZydYzcD.getControl(FGLEMi21Bfn(u"࠻࠳࠶࠵Ꭻ")).setEnabled(YOHXqtbQTBfKerIZ)
		Gb6kwVlSQ4MU.sleep(j5ELIpxCMhNRo1UGZydYzcD.buttonstimeout)
		for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(j5ELIpxCMhNRo1UGZydYzcD.closetimeout-pwxH3oREFm5v98BCZ1QVtzMJOc,-pwxH3oREFm5v98BCZ1QVtzMJOc,-pwxH3oREFm5v98BCZ1QVtzMJOc):
			Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
			coSpN5dWevQiExMTP82Y = int(wAU9jKvmTM0(u"࠴࠴࠵Ꭼ")*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz/j5ELIpxCMhNRo1UGZydYzcD.closetimeout)
			j5ELIpxCMhNRo1UGZydYzcD.KfmTsSbtH10R3(coSpN5dWevQiExMTP82Y)
			if j5ELIpxCMhNRo1UGZydYzcD.choiceID>ufmXvxgoHGDwZtjsLkR05i: break
		if j5ELIpxCMhNRo1UGZydYzcD.closetimeout>ufmXvxgoHGDwZtjsLkR05i: j5ELIpxCMhNRo1UGZydYzcD.choiceID = pnkrd2S84FJfN73KuiCYv(u"࠵࠵Ꭽ")
		j5ELIpxCMhNRo1UGZydYzcD.U9ahP7fe4y1XNr8IkGHconE()
	def KfmTsSbtH10R3(j5ELIpxCMhNRo1UGZydYzcD,coSpN5dWevQiExMTP82Y):
		j5ELIpxCMhNRo1UGZydYzcD.precent = coSpN5dWevQiExMTP82Y
		j5ELIpxCMhNRo1UGZydYzcD.getControl(EM6qpnCBYQGA9kbgDVLfrP(u"࠾࠶࠲࠱Ꭾ")).setPercent(j5ELIpxCMhNRo1UGZydYzcD.precent)
	def y8QVNgke2IvdiKApRrZPW(j5ELIpxCMhNRo1UGZydYzcD):
		if j5ELIpxCMhNRo1UGZydYzcD.button0: j5ELIpxCMhNRo1UGZydYzcD.getControl(MpJ8GOKoic(u"࠿࠰࠲࠲Ꭿ")).setEnabled(YOHXqtbQTBfKerIZ)
		if j5ELIpxCMhNRo1UGZydYzcD.button1: j5ELIpxCMhNRo1UGZydYzcD.getControl(HOxJyt7l8osNeCjZFMQGi4Sr(u"࠹࠱࠳࠴Ꮀ")).setEnabled(YOHXqtbQTBfKerIZ)
		if j5ELIpxCMhNRo1UGZydYzcD.button2: j5ELIpxCMhNRo1UGZydYzcD.getControl(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠺࠲࠴࠶Ꮁ")).setEnabled(YOHXqtbQTBfKerIZ)
	def U9ahP7fe4y1XNr8IkGHconE(j5ELIpxCMhNRo1UGZydYzcD):
		j5ELIpxCMhNRo1UGZydYzcD.close()
		try: CR3aLOVKSIme5XFoYi6M.remove(j5ELIpxCMhNRo1UGZydYzcD.image_filename)
		except: pass
class txAiQRKT0Dyl6VMq4hGeUmf():
	def __init__(j5ELIpxCMhNRo1UGZydYzcD,showDialogs=eu1NswY9zkKC60I,logErrors=YOHXqtbQTBfKerIZ):
		j5ELIpxCMhNRo1UGZydYzcD.showDialogs = showDialogs
		j5ELIpxCMhNRo1UGZydYzcD.logErrors = logErrors
		j5ELIpxCMhNRo1UGZydYzcD.finishedLIST,j5ELIpxCMhNRo1UGZydYzcD.failedLIST = [],[]
		j5ELIpxCMhNRo1UGZydYzcD.statusDICT,j5ELIpxCMhNRo1UGZydYzcD.resultsDICT = {},{}
		j5ELIpxCMhNRo1UGZydYzcD.processesLIST = []
		j5ELIpxCMhNRo1UGZydYzcD.starttimeDICT,j5ELIpxCMhNRo1UGZydYzcD.finishtimeDICT,j5ELIpxCMhNRo1UGZydYzcD.elpasedtimeDICT = {},{},{}
	def bPA1DJrUHXmqZCQFeB(j5ELIpxCMhNRo1UGZydYzcD,zhKGRXd8jbiEOAcCJuIp5mL,O7ZwFcH3LTv,*aargs):
		zhKGRXd8jbiEOAcCJuIp5mL = str(zhKGRXd8jbiEOAcCJuIp5mL)
		j5ELIpxCMhNRo1UGZydYzcD.statusDICT[zhKGRXd8jbiEOAcCJuIp5mL] = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫ๳")
		if j5ELIpxCMhNRo1UGZydYzcD.showDialogs: qJAOp7HgfKeMQkDau(Vk54F7GcROfCy6HunEI,zhKGRXd8jbiEOAcCJuIp5mL)
		TTh4jOyVfgMDR9KL7Bqo0I = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=j5ELIpxCMhNRo1UGZydYzcD.xg1slSLZbAX78O4vyqdM5tHUoa,args=(zhKGRXd8jbiEOAcCJuIp5mL,O7ZwFcH3LTv,aargs))
		j5ELIpxCMhNRo1UGZydYzcD.processesLIST.append(TTh4jOyVfgMDR9KL7Bqo0I)
		return TTh4jOyVfgMDR9KL7Bqo0I
	def pUQTxO8zV5Jrw07WHesiY(j5ELIpxCMhNRo1UGZydYzcD,zhKGRXd8jbiEOAcCJuIp5mL,O7ZwFcH3LTv,*aargs):
		TTh4jOyVfgMDR9KL7Bqo0I = j5ELIpxCMhNRo1UGZydYzcD.bPA1DJrUHXmqZCQFeB(zhKGRXd8jbiEOAcCJuIp5mL,O7ZwFcH3LTv,*aargs)
		TTh4jOyVfgMDR9KL7Bqo0I.start()
	def xg1slSLZbAX78O4vyqdM5tHUoa(j5ELIpxCMhNRo1UGZydYzcD,zhKGRXd8jbiEOAcCJuIp5mL,O7ZwFcH3LTv,aargs):
		zhKGRXd8jbiEOAcCJuIp5mL = str(zhKGRXd8jbiEOAcCJuIp5mL)
		j5ELIpxCMhNRo1UGZydYzcD.starttimeDICT[zhKGRXd8jbiEOAcCJuIp5mL] = Gb6kwVlSQ4MU.time()
		try:
			j5ELIpxCMhNRo1UGZydYzcD.resultsDICT[zhKGRXd8jbiEOAcCJuIp5mL] = O7ZwFcH3LTv(*aargs)
			if XCYALgFs2O3hZdpHrlMmB(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ๴") in str(O7ZwFcH3LTv) and not j5ELIpxCMhNRo1UGZydYzcD.resultsDICT[zhKGRXd8jbiEOAcCJuIp5mL].succeeded: sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
			j5ELIpxCMhNRo1UGZydYzcD.finishedLIST.append(zhKGRXd8jbiEOAcCJuIp5mL)
			j5ELIpxCMhNRo1UGZydYzcD.statusDICT[zhKGRXd8jbiEOAcCJuIp5mL] = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧ๵")
		except Exception as MhfeRPFkU07j5ogmqbsYcCS:
			if j5ELIpxCMhNRo1UGZydYzcD.logErrors:
				ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
				if ovLGZ5jUxNzmiQC!=EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩ๶"): yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
			j5ELIpxCMhNRo1UGZydYzcD.failedLIST.append(zhKGRXd8jbiEOAcCJuIp5mL)
			j5ELIpxCMhNRo1UGZydYzcD.statusDICT[zhKGRXd8jbiEOAcCJuIp5mL] = ESXZrtnCfcDJGo01vFg(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ๷")
		j5ELIpxCMhNRo1UGZydYzcD.finishtimeDICT[zhKGRXd8jbiEOAcCJuIp5mL] = Gb6kwVlSQ4MU.time()
		j5ELIpxCMhNRo1UGZydYzcD.elpasedtimeDICT[zhKGRXd8jbiEOAcCJuIp5mL] = j5ELIpxCMhNRo1UGZydYzcD.finishtimeDICT[zhKGRXd8jbiEOAcCJuIp5mL] - j5ELIpxCMhNRo1UGZydYzcD.starttimeDICT[zhKGRXd8jbiEOAcCJuIp5mL]
	def rrph2BLDgHdlG(j5ELIpxCMhNRo1UGZydYzcD):
		for oLynTtrXCQF9g0Nz6d58HMp7Y3 in j5ELIpxCMhNRo1UGZydYzcD.processesLIST:
			oLynTtrXCQF9g0Nz6d58HMp7Y3.start()
	def PkA0Cf3L2c9jKRZeHXwON(j5ELIpxCMhNRo1UGZydYzcD):
		while g7yJo2LVuqx1trPe(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩ๸") in list(j5ELIpxCMhNRo1UGZydYzcD.statusDICT.values()): Gb6kwVlSQ4MU.sleep(WXuJd8nz2spo146t(u"࠳Ꮂ"))
def iXOlGa8T42PZKD1WsnJm3NFyz0Ebf():
	if not PPBQqyt8i5FVezK: return Nlyfx1HnzOWCovke5(u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬ๹")
	cqORCQ3UB0I19kZ5 = QYSAUI5r46yil8cfaO(u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ๺")
	vhUKG5dOpZ2jxn4SV1t = [WsklGNp2CYzVQUag(u"ࠫ࠽࠴࠵࠯࠲ࠪ๻"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ๼"),WCPwmyVsb62KRlo(u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ๽"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ๾"),YzowicIDTRusXZSU61(u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ๿"),QYSAUI5r46yil8cfaO(u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭຀"),Nlyfx1HnzOWCovke5(u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧກ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨຂ"),FGLEMi21Bfn(u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ຃"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪຄ"),FGLEMi21Bfn(u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ࠫ຅"),wAU9jKvmTM0(u"ࠨ࠴࠳࠶࠹࠴࠰࠸࠰࠵࠴ࠬຆ")]
	IeXTpJhPi1a90cwoDuHn7qQ = vhUKG5dOpZ2jxn4SV1t[-pwxH3oREFm5v98BCZ1QVtzMJOc]
	SAtegbZsfndV1GpylX69 = Iwj75bLuUMkrdDWc20m3OXsNFPefY(IeXTpJhPi1a90cwoDuHn7qQ)
	nEDNFe2fzVckGYl4Z9xXSAWKpa1 = Iwj75bLuUMkrdDWc20m3OXsNFPefY(ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk)
	if nEDNFe2fzVckGYl4Z9xXSAWKpa1>SAtegbZsfndV1GpylX69:
		cqORCQ3UB0I19kZ5 = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩງ")
	return cqORCQ3UB0I19kZ5
def GmHQgjsBNbXiCyPx4W2toz3c5():
	try: CR3aLOVKSIme5XFoYi6M.makedirs(GK4x3b6Erdk)
	except: pass
	EE09cbkOj8 = iXOlGa8T42PZKD1WsnJm3NFyz0Ebf()
	if EE09cbkOj8==g7yJo2LVuqx1trPe(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪຈ"): iQlMPpRZXWLd(yyhLQon4NGP5MpH,eAMGzHRQVs2KyCwPXljYhB(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪຉ")+zLxMfI0XGwHT8n+eAMGzHRQVs2KyCwPXljYhB(u"ࠬࠦ࡝ࠨຊ"))
	else: iQlMPpRZXWLd(yyhLQon4NGP5MpH,g7yJo2LVuqx1trPe(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ຋")+zLxMfI0XGwHT8n+jXWzIZcDva4ikEUfN(u"ࠧࠡ࡟ࠪຌ"))
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫຍ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩอ้ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦแ๋ࠢฯ๋ฬุใ࡝ࡰศ่๎ࠦวๅวุำฬืࠠาไ่࠾ࡡࡴ࡜࡯ࠩຎ")+ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk)
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ຏ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫฯ๋ࠠหอห๎ฯࠦร้ࠢอัิ๐หࠡษ็ษฺีวาࠢส่ัี๊ะࠢ็ฬึ์วๆฮࠣห้็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣวํࠦสๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰࠣื๏่่ๆࠢส่ว์ࠠศๆหี๋อๅอࠢหฬ฾฼ࠠศๆไัํ฻วหࠢ็ฺ๊อๆࠡ฻่่ࠥอไษำ้ห๊าࠠษื๋ีฮࠦีฮ์ะอࠥ๎ๅหๅส้้ฯࠧຐ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨຑ"),MzgKWUQ4V5H(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩຒ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪຓ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩດ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬຕ"),pnkrd2S84FJfN73KuiCYv(u"ࠪࡊࡔࡘࡗࡂࡔࡇࡗࠬຖ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,g7yJo2LVuqx1trPe(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧທ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪຘ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩນ"),ESXZrtnCfcDJGo01vFg(u"ࠧࡔࡋࡗࡉࡘࡥࡃࡉࡇࡆࡏࠬບ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,V2RQwM8XjlrK(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫປ"),MpJ8GOKoic(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨຜ"))
	cad8TeSyMUYmfsEO0.setSetting(XCYALgFs2O3hZdpHrlMmB(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡵࡳࡵࡣࠪຝ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭ພ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(MpJ8GOKoic(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨຟ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(WXuJd8nz2spo146t(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩຠ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(XCYALgFs2O3hZdpHrlMmB(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪມ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪຢ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(V2RQwM8XjlrK(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡵ࡫ࡳࡷࡺࠧຣ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(wAU9jKvmTM0(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪ຤"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨລ"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭຦"),Vk54F7GcROfCy6HunEI)
	cad8TeSyMUYmfsEO0.setSetting(eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨວ"),Vk54F7GcROfCy6HunEI)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨຨ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,WsklGNp2CYzVQUag(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨຩ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,SSBkx0WbN1asnDCQV6tIj(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨສ"))
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬຫ"))
	Rl9iZEjgtdhHAocuU1fk7wLPB6r(eu1NswY9zkKC60I)
	kfBIcpzCR4O(AOhmwtSyYBn4ZF7RuvQNU)
	import rrnsP3eh5Q
	rrnsP3eh5Q.hhiACvapbKSt(FGLEMi21Bfn(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫຬ"),eu1NswY9zkKC60I)
	rrnsP3eh5Q.hhiACvapbKSt(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨອ"),eu1NswY9zkKC60I)
	rrnsP3eh5Q.hhiACvapbKSt(cpHxZyU7vTtqmIw(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲࡫࡬࡭ࡱࡧࡪࡨ࡮ࡸࡥࡤࡶࠪຮ"),eu1NswY9zkKC60I)
	rrnsP3eh5Q.hFGk9YqAuCsE(YOHXqtbQTBfKerIZ)
	if EE09cbkOj8==ynxXU3gaiQ9GPCftr1q(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧຯ"):
		wGDkm38CytIvoEJTYlNgFu7(YOHXqtbQTBfKerIZ,[OKzSt0JnAdvh2mM])
	else:
		wGDkm38CytIvoEJTYlNgFu7(eu1NswY9zkKC60I,[])
		rrnsP3eh5Q.Es63UjSadM1BpQVL89AmqrG7gICN()
		try:
			jjGTef64gpCaDErmW = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,QYSAUI5r46yil8cfaO(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪະ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ັ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧາ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪຳ"))
			nUXChz0LdbFcA57DQuH9W = ri6sIqCkQb4h.Addon(id=EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩິ"))
			nUXChz0LdbFcA57DQuH9W.setSetting(QYSAUI5r46yil8cfaO(u"࠭ࡡࡷ࠰ࡤࡹࡹࡵ࡟ࡱ࡫ࡦ࡯ࠬີ"),pnkrd2S84FJfN73KuiCYv(u"ࠧࡇࡣ࡯ࡷࡪ࠭ຶ"))
		except: pass
		try:
			jjGTef64gpCaDErmW = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪື"),WXuJd8nz2spo146t(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦຸ࠭"),WXuJd8nz2spo146t(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲູࠪ"),ESXZrtnCfcDJGo01vFg(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮຺ࠪ"))
			nUXChz0LdbFcA57DQuH9W = ri6sIqCkQb4h.Addon(id=wAU9jKvmTM0(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬົ"))
			nUXChz0LdbFcA57DQuH9W.setSetting(Nlyfx1HnzOWCovke5(u"࠭ࡡࡷ࠰ࡹ࡭ࡩ࡫࡯ࡠࡳࡸࡥࡱ࡯ࡴࡺࠩຼ"),ynxXU3gaiQ9GPCftr1q(u"ࠧ࠴ࠩຽ"))
		except: pass
		try:
			jjGTef64gpCaDErmW = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ຾"),WsklGNp2CYzVQUag(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭຿"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪເ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪແ"))
			nUXChz0LdbFcA57DQuH9W = ri6sIqCkQb4h.Addon(id=SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬໂ"))
			nUXChz0LdbFcA57DQuH9W.setSetting(YzowicIDTRusXZSU61(u"࠭ࡡࡷ࠰ࡖࡘࡗࡋࡁࡎࡕࡈࡐࡊࡉࡔࡊࡑࡑࠫໃ"),SSBkx0WbN1asnDCQV6tIj(u"ࠧ࠳ࠩໄ"))
		except: pass
	MFWydLr2JXCuVlUgAw9ERH8Yoiep = b8phWg7UYlxwmD5ePBJ(yPQp8EHdSgmNcl04zOa)
	MFWydLr2JXCuVlUgAw9ERH8Yoiep = b8phWg7UYlxwmD5ePBJ(n28VC34lcrAhgiJtKXU7WqjTOw9)
	rrnsP3eh5Q.etBvcPSDwmNMR7Hj0ZrQ2O5(eu1NswY9zkKC60I)
	cad8TeSyMUYmfsEO0.setSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ໅"),ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk)
	YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def LLkgsHYGz0QyOv9EIC(M7IELOvt1eNWmjVrYnH2lBQ3kagq):
	W89zPFlbmaJwNRT = YlDdnyUO3S1gArpu(YOHXqtbQTBfKerIZ)
	if W89zPFlbmaJwNRT:
		return
	C1VLmqi7FR625IGz = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡵ࡫ࡳࡷࡺࠧໆ")))
	C1VLmqi7FR625IGz = ufmXvxgoHGDwZtjsLkR05i if not C1VLmqi7FR625IGz else int(C1VLmqi7FR625IGz)
	if not C1VLmqi7FR625IGz or not ufmXvxgoHGDwZtjsLkR05i<=npbh5qZo1PBiNkj-C1VLmqi7FR625IGz<=CnJ1ePvdKQ2R:
		cad8TeSyMUYmfsEO0.setSetting(SSBkx0WbN1asnDCQV6tIj(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡶ࡬ࡴࡸࡴࠨ໇"),DWBRli3pT90(npbh5qZo1PBiNkj))
		kfBIcpzCR4O(AOhmwtSyYBn4ZF7RuvQNU)
		return
	KVXbTlekpZ0x7qU8JAa = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ່࠭")))
	KVXbTlekpZ0x7qU8JAa = ufmXvxgoHGDwZtjsLkR05i if not KVXbTlekpZ0x7qU8JAa else int(KVXbTlekpZ0x7qU8JAa)
	F6jrzXVaqYEP24NZo8w = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹ້ࠧ")))
	F6jrzXVaqYEP24NZo8w = ufmXvxgoHGDwZtjsLkR05i if not F6jrzXVaqYEP24NZo8w else int(F6jrzXVaqYEP24NZo8w)
	if not KVXbTlekpZ0x7qU8JAa or not F6jrzXVaqYEP24NZo8w or not ufmXvxgoHGDwZtjsLkR05i<=npbh5qZo1PBiNkj-F6jrzXVaqYEP24NZo8w<=KVXbTlekpZ0x7qU8JAa:
		VG6fJbcRCgeh1Id0y2E(YOHXqtbQTBfKerIZ,KVXbTlekpZ0x7qU8JAa)
		return
	cLR0eINvKznbXh = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ໊࠭")))
	cLR0eINvKznbXh = ufmXvxgoHGDwZtjsLkR05i if not cLR0eINvKznbXh else int(cLR0eINvKznbXh)
	if not cLR0eINvKznbXh or not ufmXvxgoHGDwZtjsLkR05i<=npbh5qZo1PBiNkj-cLR0eINvKznbXh<=ddQIv6q9hTce1iA0nWSX5UuLaNb:
		cad8TeSyMUYmfsEO0.setSetting(WCPwmyVsb62KRlo(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸ໋ࠧ"),DWBRli3pT90(npbh5qZo1PBiNkj))
		YlDdnyUO3S1gArpu(eu1NswY9zkKC60I)
		return
	if eu1NswY9zkKC60I:
		XjlcJWaqAM6v50enB = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(SSBkx0WbN1asnDCQV6tIj(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ໌")))
		XjlcJWaqAM6v50enB = ufmXvxgoHGDwZtjsLkR05i if not XjlcJWaqAM6v50enB else int(XjlcJWaqAM6v50enB)
		if not XjlcJWaqAM6v50enB or not ufmXvxgoHGDwZtjsLkR05i<=npbh5qZo1PBiNkj-XjlcJWaqAM6v50enB<=sT9DURSXlOybaCQ:
			cad8TeSyMUYmfsEO0.setSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ໍ"),DWBRli3pT90(npbh5qZo1PBiNkj))
	return
def VG6fJbcRCgeh1Id0y2E(oX6deUmzM4yS0WfJg5pvxra,KVXbTlekpZ0x7qU8JAa):
	bNO72JQGjKvPBxCDqS1T = pwxH3oREFm5v98BCZ1QVtzMJOc
	X0ZUjFnaDHpGdfyr = eu1NswY9zkKC60I if h9zFQKnsNL.JizCr5lUSWf else YOHXqtbQTBfKerIZ
	if X0ZUjFnaDHpGdfyr:
		if not KVXbTlekpZ0x7qU8JAa: oX6deUmzM4yS0WfJg5pvxra = eu1NswY9zkKC60I
		Xt0iUuE28TYN = wDHvEzd4FOJ1tfBIWQxqur2(oX6deUmzM4yS0WfJg5pvxra)
		if len(Xt0iUuE28TYN)>pwxH3oREFm5v98BCZ1QVtzMJOc:
			iQlMPpRZXWLd(yyhLQon4NGP5MpH,jXWzIZcDva4ikEUfN(u"ࠪ࠲ࡡࡺࡓࡩࡱࡺ࡭ࡳ࡭ࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭໎")+zLxMfI0XGwHT8n+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࠥࡣࠧ໏"))
			zhKGRXd8jbiEOAcCJuIp5mL,igk6DQGT2ychz38,vy5uSAZOmWehispxjE1DLcl,TcjPsL1WbHfAtq,avBR5hpQq97e,euQMlv6PXcjI3mybnKsgtwBpHJ1 = Xt0iUuE28TYN[ufmXvxgoHGDwZtjsLkR05i]
			wDRZm4GS7MqlvjpEaxNrJ5eIdVFy,gaGFzTis7M8UcWh1PEDxy0SVKZ = TcjPsL1WbHfAtq.split(MpJ8GOKoic(u"ࠬࡢ࡮࠼࠽ࠪ໐"))
			del Xt0iUuE28TYN[ufmXvxgoHGDwZtjsLkR05i]
			YCTDbIRSKe7hA63B1axG = budUNB9jgpI8Pm5.sample(Xt0iUuE28TYN,pwxH3oREFm5v98BCZ1QVtzMJOc)
			zhKGRXd8jbiEOAcCJuIp5mL,igk6DQGT2ychz38,vy5uSAZOmWehispxjE1DLcl,TcjPsL1WbHfAtq,avBR5hpQq97e,euQMlv6PXcjI3mybnKsgtwBpHJ1 = YCTDbIRSKe7hA63B1axG[ufmXvxgoHGDwZtjsLkR05i]
			vy5uSAZOmWehispxjE1DLcl = wYTDlJC5vpOKynUEX3ge6W(u"࡛࠭ࡓࡖࡏࡡࠬ໑")+d761ZWXHEvliYN45RzLP2+YzowicIDTRusXZSU61(u"ࠧࠡ࠼ࠣࠫ໒")+zhKGRXd8jbiEOAcCJuIp5mL+ZZoLlKyInXc08j2pTGJ+vy5uSAZOmWehispxjE1DLcl
			avBR5hpQq97e = eAMGzHRQVs2KyCwPXljYhB(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧ໓")
			mkbAv8F4fjcQ6dPNu = MzgKWUQ4V5H(u"ࠩส่ฯฮัฺษอࠫ໔")
			button0,button1 = TcjPsL1WbHfAtq,avBR5hpQq97e
			zHu1amneXB7dxyWCNLKrZ = [button0,button1,mkbAv8F4fjcQ6dPNu]
			dZObgYpqrI7iTcx = pwxH3oREFm5v98BCZ1QVtzMJOc if h9zFQKnsNL.qUhMJ0k8yAs else ogJClMiqPa4A0NUtTxpDVybEWG(u"࠴࠴Ꮃ")
			B69G5sUjmDJelfod481KPAyHwc = -NNjUsZzEcFOAoKry2CDMgb1(u"࠽Ꮄ")
			while B69G5sUjmDJelfod481KPAyHwc<ufmXvxgoHGDwZtjsLkR05i:
				Ik3MQtVcAqCWR8ejXy70gF4L = budUNB9jgpI8Pm5.sample(zHu1amneXB7dxyWCNLKrZ,wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A)
				B69G5sUjmDJelfod481KPAyHwc = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,Ik3MQtVcAqCWR8ejXy70gF4L[ufmXvxgoHGDwZtjsLkR05i],Ik3MQtVcAqCWR8ejXy70gF4L[pwxH3oREFm5v98BCZ1QVtzMJOc],Ik3MQtVcAqCWR8ejXy70gF4L[RXnhpCUk4M1TvgJE],wDRZm4GS7MqlvjpEaxNrJ5eIdVFy,vy5uSAZOmWehispxjE1DLcl,eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ໕"),dZObgYpqrI7iTcx,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠻࠶Ꮅ"))
				if B69G5sUjmDJelfod481KPAyHwc==YzowicIDTRusXZSU61(u"࠷࠰Ꮆ"): break
				import rrnsP3eh5Q
				if B69G5sUjmDJelfod481KPAyHwc>=ufmXvxgoHGDwZtjsLkR05i and Ik3MQtVcAqCWR8ejXy70gF4L[B69G5sUjmDJelfod481KPAyHwc]==zHu1amneXB7dxyWCNLKrZ[pwxH3oREFm5v98BCZ1QVtzMJOc]:
					rrnsP3eh5Q.PPbAlF6upzw()
					if B69G5sUjmDJelfod481KPAyHwc>=ufmXvxgoHGDwZtjsLkR05i: B69G5sUjmDJelfod481KPAyHwc = -NNjUsZzEcFOAoKry2CDMgb1(u"࠹Ꮇ")
				elif B69G5sUjmDJelfod481KPAyHwc>=ufmXvxgoHGDwZtjsLkR05i and Ik3MQtVcAqCWR8ejXy70gF4L[B69G5sUjmDJelfod481KPAyHwc]==zHu1amneXB7dxyWCNLKrZ[RXnhpCUk4M1TvgJE]:
					rrnsP3eh5Q.iVKej0gmSCBlTvdGfMZ(eu1NswY9zkKC60I)
				if B69G5sUjmDJelfod481KPAyHwc==-pwxH3oREFm5v98BCZ1QVtzMJOc: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ໖"),d761ZWXHEvliYN45RzLP2+XCYALgFs2O3hZdpHrlMmB(u"ࠬิั้ฮࠣา฼ษࠧ໗")+ZZoLlKyInXc08j2pTGJ+WCPwmyVsb62KRlo(u"࠭࡜࡯ࠢ็่ำื่อࠢสฺ่ำ๊ฮࠢฦาฯื้ࠠษะำ๋ࠥๆࠡษ็วั๎ศสࠢส่๊ะ่โำฬࠫ໘"))
			bNO72JQGjKvPBxCDqS1T = pwxH3oREFm5v98BCZ1QVtzMJOc
		else: bNO72JQGjKvPBxCDqS1T = ufmXvxgoHGDwZtjsLkR05i
	cad8TeSyMUYmfsEO0.setSetting(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ໙"),DWBRli3pT90(npbh5qZo1PBiNkj))
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ໚"),WXuJd8nz2spo146t(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧ໛"),bNO72JQGjKvPBxCDqS1T,piwNWcJEe9m)
	return
def RBVKCqlWYJ(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx):
	if Rw2xfQUAeP9sy in [XCYALgFs2O3hZdpHrlMmB(u"ࠪ࠵ࠬໜ"),SSBkx0WbN1asnDCQV6tIj(u"ࠫ࠷࠭ໝ"),WXuJd8nz2spo146t(u"ࠬ࠹ࠧໞ"),g7yJo2LVuqx1trPe(u"࠭࠴ࠨໟ"),ESXZrtnCfcDJGo01vFg(u"ࠧ࠶ࠩ໠"),V2RQwM8XjlrK(u"ࠨ࠳࠴ࠫ໡"),XCYALgFs2O3hZdpHrlMmB(u"ࠩ࠴࠶ࠬ໢"),YzowicIDTRusXZSU61(u"ࠪ࠵࠸࠭໣")] and GZ6tYW82Hh0ekOmNLnzsx:
		import DVX8HOTEnm
		DVX8HOTEnm.RV2JzeiqBrX3IZNc5Fj8QUn(rF0ghTZEyQ,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx)
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I,zLxMfI0XGwHT8n)
	elif Rw2xfQUAeP9sy==g7yJo2LVuqx1trPe(u"ࠫ࠻࠭໤"):
		import Cqlz6HOy2V
		if GZ6tYW82Hh0ekOmNLnzsx==pnkrd2S84FJfN73KuiCYv(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ໥"): Cqlz6HOy2V.qJAOp7HgfKeMQkDau(MzgKWUQ4V5H(u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭໦"),WsklGNp2CYzVQUag(u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ໧"),Gb6kwVlSQ4MU=cpHxZyU7vTtqmIw(u"࠳࠲࠳࠴Ꮈ"))
		elif GZ6tYW82Hh0ekOmNLnzsx==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡆࡈࡐࡊ࡚ࡅࠨ໨"): r7rP6xHFYvepiTG(lI5ck2gjRCiw9bMTF0xHsG,eu1NswY9zkKC60I)
		w8YsNWfQ5gFluRvOmSd4Cb96H = Cqlz6HOy2V.BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,M7IELOvt1eNWmjVrYnH2lBQ3kagq,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
		if GZ6tYW82Hh0ekOmNLnzsx==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ໩"): sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	elif rF0ghTZEyQ==WsklGNp2CYzVQUag(u"ࠪ࠻ࠬ໪"):
		import BHk9b8G5AL
		BHk9b8G5AL.ISNDTYpvG7f6yzkjCbH8lMJF(wAU9jKvmTM0(u"ࠫࡤࡇࡌࡍࠩ໫"))
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	elif rF0ghTZEyQ==cpHxZyU7vTtqmIw(u"ࠬ࠾ࠧ໬"): J2L6to3R1Z.executebuiltin(eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ໭")+DDXHAicJtj6+jXWzIZcDva4ikEUfN(u"ࠧࡀ࡯ࡲࡨࡪࡃࠧ໮")+str(Fj9S5lYorenKWR2I30)+ESXZrtnCfcDJGo01vFg(u"ࠨࠨࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠩࠨ໯"))
	elif rF0ghTZEyQ==jXWzIZcDva4ikEUfN(u"ࠩ࠼ࠫ໰"):
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ)
	elif rF0ghTZEyQ==wAU9jKvmTM0(u"ࠪ࠵࠵࠭໱"):
		import BHk9b8G5AL
		BHk9b8G5AL.ISNDTYpvG7f6yzkjCbH8lMJF(cpHxZyU7vTtqmIw(u"ࠫࡤࡍࡏࡐࡉࡏࡉࠬ໲"))
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	elif rF0ghTZEyQ==FGLEMi21Bfn(u"ࠬ࠷࠴ࠨ໳"): YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫ໴"))
	elif rF0ghTZEyQ==FGLEMi21Bfn(u"ࠧ࠲࠷ࠪ໵"): YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭໶"))
	elif rF0ghTZEyQ==ESXZrtnCfcDJGo01vFg(u"ࠩ࠴࠺ࠬ໷"): YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡑࡊࡔࡕࡠࡆࡈࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑࠩ໸"))
	elif rF0ghTZEyQ==NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࠶࠽ࠧ໹"): YYtCylgzdv5aiwN7nZ2e8soVO9hF(YOHXqtbQTBfKerIZ,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡕࡇࡐࡔࠬ໺"))
	elif rF0ghTZEyQ==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࠱࠹ࠩ໻"):
		LL82RbVxIQF1XBfYZM3 = cad8TeSyMUYmfsEO0.getSetting(jXWzIZcDva4ikEUfN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫ໼"))
		cad8TeSyMUYmfsEO0.setSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ໽"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࠰ࠫ໾")+LL82RbVxIQF1XBfYZM3)
	if rF0ghTZEyQ in [MzgKWUQ4V5H(u"ࠪ࠽ࠬ໿"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࠶࠺ࠧༀ"),WsklGNp2CYzVQUag(u"ࠬ࠷࠵ࠨ༁"),QYSAUI5r46yil8cfaO(u"࠭࠱࠷ࠩ༂"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧ࠲࠹ࠪ༃")]: sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	return
def fhE1D2548FmzHJcdu(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx,fqNDhEb7ic5rH2K9Rx):
	if PPBQqyt8i5FVezK: GmHQgjsBNbXiCyPx4W2toz3c5()
	if rF0ghTZEyQ: RBVKCqlWYJ(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx)
	LLkgsHYGz0QyOv9EIC(M7IELOvt1eNWmjVrYnH2lBQ3kagq)
	global HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi,LMnQyYOz0U1Ix6B2jW9tvwCpFgV,IIJTHtKar50hg3UzuLdl4yDxvNQA1
	for PPmYnWkqTCfNH1u4yoRs in h9zFQKnsNL.BADWEBSITES:
		if PPmYnWkqTCfNH1u4yoRs in HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi: HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi.remove(PPmYnWkqTCfNH1u4yoRs)
		if PPmYnWkqTCfNH1u4yoRs in LMnQyYOz0U1Ix6B2jW9tvwCpFgV: LMnQyYOz0U1Ix6B2jW9tvwCpFgV.remove(PPmYnWkqTCfNH1u4yoRs)
		if PPmYnWkqTCfNH1u4yoRs in IIJTHtKar50hg3UzuLdl4yDxvNQA1: IIJTHtKar50hg3UzuLdl4yDxvNQA1.remove(PPmYnWkqTCfNH1u4yoRs)
	kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr = YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I,eu1NswY9zkKC60I
	o3LbREPir9DVOkyulqnYNITp2 = qcjRWIiklN3tZ9YQMU8(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,fqNDhEb7ic5rH2K9Rx,kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr)
	zXjVHxtcS4,s9sTYnbqIEHthVG3czOK1p8vxF,KJDPiS1HOjsvrg,ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6,uuGLWSjis1geyqQbzOmNZt,eRvnScGtXfMl8OBY6Cgy,DpTqfLBkI8bmHGy9MiZ1htrx3,UEibe4W6wOgLG8h1RCABxzY = o3LbREPir9DVOkyulqnYNITp2
	if zXjVHxtcS4: return
	if s9sTYnbqIEHthVG3czOK1p8vxF==g7yJo2LVuqx1trPe(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ༄"): kfBIcpzCR4O(AOhmwtSyYBn4ZF7RuvQNU)
	Rq6BxGQfNWkSiYDthKFo8(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡶࡸࡦࡸࡴࠨ༅"))
	if cad8TeSyMUYmfsEO0.getSetting(cpHxZyU7vTtqmIw(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ༆")) not in [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡆ࡛ࡔࡐࠩ༇"),YzowicIDTRusXZSU61(u"࡙ࠬࡔࡐࡒࠪ༈"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ༉")]:
		cad8TeSyMUYmfsEO0.setSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭༊"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡃࡘࡘࡔ࠭་"))
	if not cad8TeSyMUYmfsEO0.getSetting(QYSAUI5r46yil8cfaO(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩ༌")): cad8TeSyMUYmfsEO0.setSetting(FGLEMi21Bfn(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪ།"),h9zFQKnsNL.DNS_SERVERS[ufmXvxgoHGDwZtjsLkR05i])
	w8YsNWfQ5gFluRvOmSd4Cb96H = BZuqi6XbrL8j3zEsNxFenWVYDHgRlt(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
	if eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭༎") in RRG6QsiOkKU0ChovTBY3qdf: RMxkGV4KYArNWl8a3CFeizUIyEBJb = YOHXqtbQTBfKerIZ
	if WypSQTO7504tHY==FGLEMi21Bfn(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ༏"):
		if ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6!=QYSAUI5r46yil8cfaO(u"࠭࠮࠯ࠩ༐") and uuGLWSjis1geyqQbzOmNZt: u3DFOqsSJBc079Xg()
		if YBCwDWyFAe4XpJNxQK2smG>-pwxH3oREFm5v98BCZ1QVtzMJOc:
			v6O3VuKHwJLISdpoMlj5A4Ygmrn10 = [ufmXvxgoHGDwZtjsLkR05i,pnkrd2S84FJfN73KuiCYv(u"࠴࠹Ꮊ"),V2RQwM8XjlrK(u"࠵࠼Ꮋ"),g7yJo2LVuqx1trPe(u"࠶࠿Ꮌ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠴࠹Ꮉ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠴࠶Ꮏ"),wAU9jKvmTM0(u"࠻࠰Ꮍ"),cpHxZyU7vTtqmIw(u"࠵࠴Ꮎ")]
			if (w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡪࡰࡷࠫ༑"),WCPwmyVsb62KRlo(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ༒"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧ༓")) or M7IELOvt1eNWmjVrYnH2lBQ3kagq not in v6O3VuKHwJLISdpoMlj5A4Ygmrn10) and not h9zFQKnsNL.C7tWRO0bJdz3TV49j8eIklM1fDSxB:
				from GBPlghkIE8 import lkQJPwK9SIXMtY1U
				YMu8AkUvjgt5zK4FGTC2PasJdN69SQ = EEKTSdtU0bn3CIHQw64glWamXupJj(lkQJPwK9SIXMtY1U)
				zXjVHxtcS4 = TbFKCvLjE0OQISHfymke(KJDPiS1HOjsvrg,YMu8AkUvjgt5zK4FGTC2PasJdN69SQ,kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr)
				if YMu8AkUvjgt5zK4FGTC2PasJdN69SQ and eRvnScGtXfMl8OBY6Cgy:
					FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ༔")+DpTqfLBkI8bmHGy9MiZ1htrx3+wAU9jKvmTM0(u"ࠫࡤ࠭༕")+UEibe4W6wOgLG8h1RCABxzY,KJDPiS1HOjsvrg,YMu8AkUvjgt5zK4FGTC2PasJdN69SQ,ddQIv6q9hTce1iA0nWSX5UuLaNb)
			else:
				n8NU7czo3KqG.addDirectoryItem(YBCwDWyFAe4XpJNxQK2smG,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ༖")+DDXHAicJtj6+pnkrd2S84FJfN73KuiCYv(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭༗"),SZDFRGim3j8L.ListItem(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧๅัํ็๋ࠥิไๆฬࠤ๊์ࠠอ้สึ่༘࠭")))
				n8NU7czo3KqG.addDirectoryItem(YBCwDWyFAe4XpJNxQK2smG,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲༙ࠫ")+DDXHAicJtj6+g7yJo2LVuqx1trPe(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ༚"),SZDFRGim3j8L.ListItem(XCYALgFs2O3hZdpHrlMmB(u"ࠪวๆะอࠡๆอๆึษࠠศๆอๅฬ฻๊ๅࠩ༛")))
			n8NU7czo3KqG.endOfDirectory(YBCwDWyFAe4XpJNxQK2smG,kNQM9jAU6TVlhezn14cKtBb,RMxkGV4KYArNWl8a3CFeizUIyEBJb,Oe1F38LXDdV6Jr)
	return
def kfBIcpzCR4O(kWpYFq1KaAzdIsSUmwBZO5Ri):
	if Nlyfx1HnzOWCovke5(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭༜") in str(h9zFQKnsNL.SEND_THESE_EVENTS): return
	cQ3L2UODFjCX = eu1NswY9zkKC60I if kWpYFq1KaAzdIsSUmwBZO5Ri else YOHXqtbQTBfKerIZ
	if not cQ3L2UODFjCX:
		RF8yE2714XiD5vqbGCuKs9 = LMjdxBqyRenswWZGASmY5h2U(cad8TeSyMUYmfsEO0.getSetting(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭༝")))
		RF8yE2714XiD5vqbGCuKs9 = ufmXvxgoHGDwZtjsLkR05i if not RF8yE2714XiD5vqbGCuKs9 else int(RF8yE2714XiD5vqbGCuKs9)
		if not RF8yE2714XiD5vqbGCuKs9 or not ufmXvxgoHGDwZtjsLkR05i<=npbh5qZo1PBiNkj-RF8yE2714XiD5vqbGCuKs9<=kWpYFq1KaAzdIsSUmwBZO5Ri: cQ3L2UODFjCX = YOHXqtbQTBfKerIZ
	if not cQ3L2UODFjCX:
		K1KExcrJHOYfpmW2 = cad8TeSyMUYmfsEO0.getSetting(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ༞"))
		if K1KExcrJHOYfpmW2 in [Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭༟"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧ༠")]: cQ3L2UODFjCX = YOHXqtbQTBfKerIZ
	if not cQ3L2UODFjCX:
		EmF1V5JT23xh9DnbZoCgrpBMQRa = cad8TeSyMUYmfsEO0.getSetting(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ༡"))
		bIsz45VatWSMRmkyph63Zg1lf,C9frwiYhylNH2n14uDaG5 = ENGD7a3qU5AWfdMjZXP(OKzSt0JnAdvh2mM)
		NaHpiw3XnL8IRMGeOCby1u4VDo = k5CaeTXcbAnrh1sJOg(OKzSt0JnAdvh2mM,bIsz45VatWSMRmkyph63Zg1lf,C9frwiYhylNH2n14uDaG5,eu1NswY9zkKC60I,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࠤࡀ࠭༢"))
		NaHpiw3XnL8IRMGeOCby1u4VDo = NaHpiw3XnL8IRMGeOCby1u4VDo[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠲Ꮐ")][MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠲Ꮐ")]
		bIsz45VatWSMRmkyph63Zg1lf.close()
		KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠸Ꮑ")*EmF1V5JT23xh9DnbZoCgrpBMQRa.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
		KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠵࠹Ꮒ")*KJcupFnhxLbjTr6lUagHBsR3e.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
		KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(V2RQwM8XjlrK(u"࠶࠿Ꮓ")*KJcupFnhxLbjTr6lUagHBsR3e.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
		KJcupFnhxLbjTr6lUagHBsR3e = str(int(KJcupFnhxLbjTr6lUagHBsR3e[EM6qpnCBYQGA9kbgDVLfrP(u"࠳Ꮕ"):WCPwmyVsb62KRlo(u"࠲࠴Ꮖ")],MpJ8GOKoic(u"࠳࠹Ꮗ")))[:HOxJyt7l8osNeCjZFMQGi4Sr(u"࠿Ꮔ")]
		if KJcupFnhxLbjTr6lUagHBsR3e!=NaHpiw3XnL8IRMGeOCby1u4VDo: cQ3L2UODFjCX = YOHXqtbQTBfKerIZ
	if cQ3L2UODFjCX: O7lx3KHcgw(eu1NswY9zkKC60I)
	return
def KhWLUeoAF0CfZINwr4u(PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1,JlT9OB143U,showDialogs):
	PPmYnWkqTCfNH1u4yoRs = JlT9OB143U.split(ynxXU3gaiQ9GPCftr1q(u"ࠫ࠲࠭༣"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i] if FGLEMi21Bfn(u"ࠬ࠳ࠧ༤") in JlT9OB143U else JlT9OB143U
	if not showDialogs or JlT9OB143U in hhmKJHnG2Yw: return eu1NswY9zkKC60I
	fVb0ZjdIuEhTrGq = cad8TeSyMUYmfsEO0.getSetting(jXWzIZcDva4ikEUfN(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ༥"))
	cad8TeSyMUYmfsEO0.setSetting(MpJ8GOKoic(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ༦"),Vk54F7GcROfCy6HunEI)
	dIUVgDqtL3ie = PvV97U5qtXD38GlIJBmsxFjrELn in [QYSAUI5r46yil8cfaO(u"࠽Ꮛ"),WCPwmyVsb62KRlo(u"࠵࠶࠶࠰࠲Ꮙ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠴࠵࠵࠶࠲Ꮘ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࠶࠶࠰࠶࠶Ꮚ")]
	zYbBoO6NX8cAFi = euQMlv6PXcjI3mybnKsgtwBpHJ1.lower()
	ZGxYQdfakpscztI3qgrHJmAoy = PvV97U5qtXD38GlIJBmsxFjrELn in [ufmXvxgoHGDwZtjsLkR05i,WsklGNp2CYzVQUag(u"࠳࠳࠸Ꮞ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠱࠱࠲࠹࠵Ꮜ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠲࠳࠴Ꮝ")]
	QQGL94jgplftO = NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ༧") in zYbBoO6NX8cAFi
	CiEGtzW87lIqQnKmX4 = NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ༨") in zYbBoO6NX8cAFi
	MjCoOwuGdeUq742g = MpJ8GOKoic(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ༩") in zYbBoO6NX8cAFi
	caVGF2wOyq0 = g7yJo2LVuqx1trPe(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭༪") in zYbBoO6NX8cAFi
	uc7o2QzC9XSnpmBfIP65KaYkrFhs = cad8TeSyMUYmfsEO0.getSetting(V2RQwM8XjlrK(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ༫"))
	bnjDWeOuzEP6kJYMAiIR4lpK1oU = cad8TeSyMUYmfsEO0.getSetting(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ༬"))
	MW70q58PnBXhx6AJyuZRGVjp9O = jXWzIZcDva4ikEUfN(u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ༭")
	nvsJ7Cj6MN894QwBVt = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡇࡵࡶࡴࡸࠠࠨ༮")+str(PvV97U5qtXD38GlIJBmsxFjrELn)+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࠽ࠤࠬ༯")+euQMlv6PXcjI3mybnKsgtwBpHJ1
	nvsJ7Cj6MN894QwBVt = ZlBMJUAWRm9buv(nvsJ7Cj6MN894QwBVt)
	if ZGxYQdfakpscztI3qgrHJmAoy or QQGL94jgplftO or CiEGtzW87lIqQnKmX4 or MjCoOwuGdeUq742g or caVGF2wOyq0: MW70q58PnBXhx6AJyuZRGVjp9O += QYSAUI5r46yil8cfaO(u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ༰")
	if dIUVgDqtL3ie: MW70q58PnBXhx6AJyuZRGVjp9O += pnkrd2S84FJfN73KuiCYv(u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ༱")
	nvsJ7Cj6MN894QwBVt = ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+nvsJ7Cj6MN894QwBVt+ZZoLlKyInXc08j2pTGJ
	if uc7o2QzC9XSnpmBfIP65KaYkrFhs==pnkrd2S84FJfN73KuiCYv(u"ࠬࡇࡓࡌࠩ༲") or bnjDWeOuzEP6kJYMAiIR4lpK1oU==NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡁࡔࡍࠪ༳"):
		MW70q58PnBXhx6AJyuZRGVjp9O += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+jXWzIZcDva4ikEUfN(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩ༴")+ZZoLlKyInXc08j2pTGJ
	yArj1FaQ830dD = eu1NswY9zkKC60I
	if uc7o2QzC9XSnpmBfIP65KaYkrFhs==Nlyfx1HnzOWCovke5(u"ࠨࡃࡖࡏ༵ࠬ") or bnjDWeOuzEP6kJYMAiIR4lpK1oU==g7yJo2LVuqx1trPe(u"ࠩࡄࡗࡐ࠭༶"):
		B69G5sUjmDJelfod481KPAyHwc = rAdiM2DVzBuxjPvYFTQs(WCPwmyVsb62KRlo(u"ࠪࡧࡪࡴࡴࡦࡴ༷ࠪ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫำื่อࠩ༸"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬหัิษ็ࠤ้๊ๅษำ่ะ༹ࠬ"),FGLEMi21Bfn(u"࠭สึๆํัࠥอไๆึๆ่ฮ࠭༺"),PPmYnWkqTCfNH1u4yoRs+NaXBAuesz07inT4g6cDt+rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs),MW70q58PnBXhx6AJyuZRGVjp9O+ixrPWKeFMnqJyVodX6D9AaO2+nvsJ7Cj6MN894QwBVt)
		if B69G5sUjmDJelfod481KPAyHwc==pwxH3oREFm5v98BCZ1QVtzMJOc:
			from rrnsP3eh5Q import PPbAlF6upzw
			PPbAlF6upzw()
		elif B69G5sUjmDJelfod481KPAyHwc==RXnhpCUk4M1TvgJE: yArj1FaQ830dD = YOHXqtbQTBfKerIZ
	else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,PPmYnWkqTCfNH1u4yoRs+NaXBAuesz07inT4g6cDt+rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs),MW70q58PnBXhx6AJyuZRGVjp9O,nvsJ7Cj6MN894QwBVt)
	cad8TeSyMUYmfsEO0.setSetting(MzgKWUQ4V5H(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ༻"),fVb0ZjdIuEhTrGq)
	return yArj1FaQ830dD
def wGDkm38CytIvoEJTYlNgFu7(y2ALK5ZIefj=eu1NswY9zkKC60I,z8Ie72SBEYaPjFCAGXxpWv9VLTi6=[]):
	dcQBZhwAyVTNSfvRFUJ2a7tX = [yPQp8EHdSgmNcl04zOa,n28VC34lcrAhgiJtKXU7WqjTOw9]+z8Ie72SBEYaPjFCAGXxpWv9VLTi6
	for Hqxr3RAiJEadvFZWObS in CR3aLOVKSIme5XFoYi6M.listdir(GK4x3b6Erdk):
		if y2ALK5ZIefj and (Hqxr3RAiJEadvFZWObS.startswith(wYTDlJC5vpOKynUEX3ge6W(u"ࠨ࡫ࡳࡸࡻ࠭༼")) or Hqxr3RAiJEadvFZWObS.startswith(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡰ࠷ࡺ࠭༽"))): continue
		if Hqxr3RAiJEadvFZWObS.startswith(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡪ࡮ࡲࡥࡠࠩ༾")): continue
		abohnUCM2l6IXP89igGY4f = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,Hqxr3RAiJEadvFZWObS)
		if abohnUCM2l6IXP89igGY4f in dcQBZhwAyVTNSfvRFUJ2a7tX: continue
		try: CR3aLOVKSIme5XFoYi6M.remove(abohnUCM2l6IXP89igGY4f)
		except: pass
	if dQxGp0knIfj not in dcQBZhwAyVTNSfvRFUJ2a7tX: Agz62xbajVk15PieF4utWsGmBC(dQxGp0knIfj,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
	Gb6kwVlSQ4MU.sleep(eAMGzHRQVs2KyCwPXljYhB(u"࠴Ꮟ"))
	return
def JSh0AeVPMg4K8a72lxjknf9wi6u(HFGa2mt09bhEKoW3,V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7=YOHXqtbQTBfKerIZ,kNnrH6938aeRlGjKySB2CcIT=YOHXqtbQTBfKerIZ):
	N39NCXDAaVnx = N39NCXDAaVnx+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ༿")+HFGa2mt09bhEKoW3
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,hscbiOf5pLaXMzUnDk,showDialogs,JlT9OB143U,KMl6HEmOUCYyLtbJDP2df7,kNnrH6938aeRlGjKySB2CcIT)
	if N39NCXDAaVnx in s63mcpoNbCT79FW0dOfauhYrRyLV.content: s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded = eu1NswY9zkKC60I
	if not s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	return s63mcpoNbCT79FW0dOfauhYrRyLV
def bbxDq9lf4XvUN1cMegz(N39NCXDAaVnx):
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡍࡅࡕࠩཀ"),N39NCXDAaVnx,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧཁ"),YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
	Nt1CJn06vFRmjWqQEacbzkw79LSuO = []
	if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
		y3bJAkDqOdcjfhIu0op51Ma = RSuYINdeamsK0t.findall(Nlyfx1HnzOWCovke5(u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪག"),UwghkPtqZiWTvsMLrl5dc0nuOAQ)
		if y3bJAkDqOdcjfhIu0op51Ma: UwghkPtqZiWTvsMLrl5dc0nuOAQ = ixrPWKeFMnqJyVodX6D9AaO2.join(y3bJAkDqOdcjfhIu0op51Ma)
		YzwjLlne7PBMcrVUWm3y0H = UwghkPtqZiWTvsMLrl5dc0nuOAQ.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI).strip(ixrPWKeFMnqJyVodX6D9AaO2).split(ixrPWKeFMnqJyVodX6D9AaO2)
		Nt1CJn06vFRmjWqQEacbzkw79LSuO = []
		for HFGa2mt09bhEKoW3 in YzwjLlne7PBMcrVUWm3y0H:
			if HFGa2mt09bhEKoW3.count(V2RQwM8XjlrK(u"ࠨ࠰ࠪགྷ"))==wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A: Nt1CJn06vFRmjWqQEacbzkw79LSuO.append(HFGa2mt09bhEKoW3)
	return Nt1CJn06vFRmjWqQEacbzkw79LSuO
def nn0pSXU9gvN(*aargs):
	pzPc8gHVYWaN1mhuF2riD9SAf = wAU9jKvmTM0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪང")
	L1v8aqtbsfwiudm9XHpYyKz = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧཅ")
	Ab1IDUQjB6 = bbxDq9lf4XvUN1cMegz(L1v8aqtbsfwiudm9XHpYyKz)
	Nt1CJn06vFRmjWqQEacbzkw79LSuO = bbxDq9lf4XvUN1cMegz(pzPc8gHVYWaN1mhuF2riD9SAf)
	NXzbIR5ut9DKeUP = Ab1IDUQjB6+Nt1CJn06vFRmjWqQEacbzkw79LSuO
	iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪཆ")+str(len(Ab1IDUQjB6))+WCPwmyVsb62KRlo(u"ࠬ࠱ࠧཇ")+str(len(Nt1CJn06vFRmjWqQEacbzkw79LSuO))+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠠ࡞ࠩ཈"))
	HFGa2mt09bhEKoW3 = cad8TeSyMUYmfsEO0.getSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧཉ"))
	s63mcpoNbCT79FW0dOfauhYrRyLV = O8O0UxfNrsRKdw9()
	cad8TeSyMUYmfsEO0.setSetting(FGLEMi21Bfn(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨཊ"),Vk54F7GcROfCy6HunEI)
	if HFGa2mt09bhEKoW3 or NXzbIR5ut9DKeUP:
		zhKGRXd8jbiEOAcCJuIp5mL,e98nIYDOZyX05Tf3io2dpV = ufmXvxgoHGDwZtjsLkR05i,eAMGzHRQVs2KyCwPXljYhB(u"࠵࠵Ꮠ")
		vBA6MOrql7e = len(NXzbIR5ut9DKeUP)
		jGgEaVwWIs4Fn9tKxmzp5 = e98nIYDOZyX05Tf3io2dpV
		if vBA6MOrql7e>jGgEaVwWIs4Fn9tKxmzp5: mGN7a65ciXOAWvRSKypU = jGgEaVwWIs4Fn9tKxmzp5
		else: mGN7a65ciXOAWvRSKypU = vBA6MOrql7e
		faNg6HYEeI9R4M = budUNB9jgpI8Pm5.sample(NXzbIR5ut9DKeUP,mGN7a65ciXOAWvRSKypU)
		if HFGa2mt09bhEKoW3: faNg6HYEeI9R4M = [HFGa2mt09bhEKoW3]+faNg6HYEeI9R4M
		WWJZy30fThMICaPOwDYbmK = txAiQRKT0Dyl6VMq4hGeUmf(eu1NswY9zkKC60I,eu1NswY9zkKC60I)
		TT7ytNUaAEzleV2oMR9j3 = Gb6kwVlSQ4MU.time()
		while Gb6kwVlSQ4MU.time()-TT7ytNUaAEzleV2oMR9j3<=e98nIYDOZyX05Tf3io2dpV and not WWJZy30fThMICaPOwDYbmK.finishedLIST:
			if zhKGRXd8jbiEOAcCJuIp5mL<mGN7a65ciXOAWvRSKypU:
				HFGa2mt09bhEKoW3 = faNg6HYEeI9R4M[zhKGRXd8jbiEOAcCJuIp5mL]
				WWJZy30fThMICaPOwDYbmK.pUQTxO8zV5Jrw07WHesiY(zhKGRXd8jbiEOAcCJuIp5mL,JSh0AeVPMg4K8a72lxjknf9wi6u,HFGa2mt09bhEKoW3,*aargs)
			Gb6kwVlSQ4MU.sleep(eAMGzHRQVs2KyCwPXljYhB(u"࠵࠴࠷࠶Ꮡ"))
			zhKGRXd8jbiEOAcCJuIp5mL += pwxH3oREFm5v98BCZ1QVtzMJOc
			iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+WsklGNp2CYzVQUag(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫཋ")+HFGa2mt09bhEKoW3+WXuJd8nz2spo146t(u"ࠪࠤࡢ࠭ཌ"))
		finishedLIST = WWJZy30fThMICaPOwDYbmK.finishedLIST
		if finishedLIST:
			resultsDICT = WWJZy30fThMICaPOwDYbmK.resultsDICT
			zKGagbMLB4H = finishedLIST[ufmXvxgoHGDwZtjsLkR05i]
			s63mcpoNbCT79FW0dOfauhYrRyLV = resultsDICT[zKGagbMLB4H]
			HFGa2mt09bhEKoW3 = faNg6HYEeI9R4M[int(zKGagbMLB4H)]
			cad8TeSyMUYmfsEO0.setSetting(ESXZrtnCfcDJGo01vFg(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫཌྷ"),HFGa2mt09bhEKoW3)
			if zKGagbMLB4H!=ufmXvxgoHGDwZtjsLkR05i: iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+eAMGzHRQVs2KyCwPXljYhB(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨཎ")+HFGa2mt09bhEKoW3+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࠠ࡞ࠩཏ"))
			else: iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛ࠦࠡࠩཐ")+HFGa2mt09bhEKoW3+g7yJo2LVuqx1trPe(u"ࠨࠢࡠࠫད"))
	return s63mcpoNbCT79FW0dOfauhYrRyLV
def NuAKiZSnYzsp2BrTCRX73QFa0DHc(EMenbGcfTy3OJLN5XIHtug9,EFl75DTWxtVedjRskgnaZr,hDs2b5kGyradYUSHAgm0TK=YOHXqtbQTBfKerIZ):
	ZSkg1WTpqOjfFtLNyD5o6 = EMenbGcfTy3OJLN5XIHtug9.create_connection
	def IaGZB3TvxDhQERXrUPOebs(y7yD2Bozbhd,*aargs,**kkwargs):
		yXHTMfhui87IRLSQmNv,a6Yrzho9J2VksBEG4 = y7yD2Bozbhd
		ip = LUYAScDEWagR9o(yXHTMfhui87IRLSQmNv,EFl75DTWxtVedjRskgnaZr)
		if ip: yXHTMfhui87IRLSQmNv = ip[ufmXvxgoHGDwZtjsLkR05i]
		elif hDs2b5kGyradYUSHAgm0TK:
			if EFl75DTWxtVedjRskgnaZr in h9zFQKnsNL.DNS_SERVERS: h9zFQKnsNL.DNS_SERVERS.remove(EFl75DTWxtVedjRskgnaZr)
			if h9zFQKnsNL.DNS_SERVERS:
				jjgObdSemRunPEKQJXo7i = h9zFQKnsNL.DNS_SERVERS[ufmXvxgoHGDwZtjsLkR05i]
				ip = LUYAScDEWagR9o(yXHTMfhui87IRLSQmNv,jjgObdSemRunPEKQJXo7i)
				if ip: yXHTMfhui87IRLSQmNv = ip[ufmXvxgoHGDwZtjsLkR05i]
		if ip: h9zFQKnsNL.dns_succeeded_urls.append(yXHTMfhui87IRLSQmNv)
		y7yD2Bozbhd = (yXHTMfhui87IRLSQmNv,a6Yrzho9J2VksBEG4)
		return ZSkg1WTpqOjfFtLNyD5o6(y7yD2Bozbhd,*aargs,**kkwargs)
	EMenbGcfTy3OJLN5XIHtug9.create_connection = IaGZB3TvxDhQERXrUPOebs
	return ZSkg1WTpqOjfFtLNyD5o6
def WF4atTViZQ3we(N39NCXDAaVnx):
	Jynaqrfc3g2s89CkpIFv0WiRj1,E9ozhdxbrRvc2Il6uDWsAT7wBKNY = N39NCXDAaVnx.split(jXWzIZcDva4ikEUfN(u"ࠩ࠲ࠫདྷ"))[RXnhpCUk4M1TvgJE],pnkrd2S84FJfN73KuiCYv(u"࠾࠰Ꮢ")
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࠾ࠬན") in Jynaqrfc3g2s89CkpIFv0WiRj1: Jynaqrfc3g2s89CkpIFv0WiRj1,E9ozhdxbrRvc2Il6uDWsAT7wBKNY = Jynaqrfc3g2s89CkpIFv0WiRj1.split(QYSAUI5r46yil8cfaO(u"ࠫ࠿࠭པ"))
	ugfk6o5D8z = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࠵ࠧཕ")+ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࠯ࠨབ").join(N39NCXDAaVnx.split(V2RQwM8XjlrK(u"ࠧ࠰ࠩབྷ"))[EM6qpnCBYQGA9kbgDVLfrP(u"࠳Ꮣ"):])
	MmpRngPUCzrJ0HlGfB = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡉࡈࡘࠥ࠭མ")+ugfk6o5D8z+QYSAUI5r46yil8cfaO(u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩཙ")
	MmpRngPUCzrJ0HlGfB += kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡌࡴࡹࡴ࠻ࠢࠪཚ")+Jynaqrfc3g2s89CkpIFv0WiRj1+MzgKWUQ4V5H(u"ࠫࡡࡸ࡜࡯ࠩཛ")
	MmpRngPUCzrJ0HlGfB += WCPwmyVsb62KRlo(u"ࠬࡢࡲ࡝ࡰࠪཛྷ")
	from socket import socket as bb3RGytoD6Mi1hAP,AF_INET as znoB95HRCwUOrcKfY,SOCK_STREAM as PwU9AIMTYtLvbFeKjm
	try:
		X1Xrv2pNmAWMsoH5wYBnfCujIU = bb3RGytoD6Mi1hAP(znoB95HRCwUOrcKfY,PwU9AIMTYtLvbFeKjm)
		X1Xrv2pNmAWMsoH5wYBnfCujIU.connect((Jynaqrfc3g2s89CkpIFv0WiRj1,E9ozhdxbrRvc2Il6uDWsAT7wBKNY))
		X1Xrv2pNmAWMsoH5wYBnfCujIU.send(MmpRngPUCzrJ0HlGfB.encode(AoCWwJHgUPKXI7u2lEzym))
		wj7zlGYnta = X1Xrv2pNmAWMsoH5wYBnfCujIU.recv(HOxJyt7l8osNeCjZFMQGi4Sr(u"࠶࠳࠽࠻Ꮥ")*SSBkx0WbN1asnDCQV6tIj(u"࠲࠲࠵࠸Ꮤ"))
		UwghkPtqZiWTvsMLrl5dc0nuOAQ = repr(wj7zlGYnta)
	except: UwghkPtqZiWTvsMLrl5dc0nuOAQ = Vk54F7GcROfCy6HunEI
	return UwghkPtqZiWTvsMLrl5dc0nuOAQ
def RRav1Sf7Px(z9q2ova0OhKP1XemlViUbdx7Zu,WypSQTO7504tHY):
	if ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࠮ࠨཝ") not in z9q2ova0OhKP1XemlViUbdx7Zu: return z9q2ova0OhKP1XemlViUbdx7Zu
	z9q2ova0OhKP1XemlViUbdx7Zu = z9q2ova0OhKP1XemlViUbdx7Zu+Nlyfx1HnzOWCovke5(u"ࠧ࠰ࠩཞ")
	ddSXt1GMLrZceIh0FW5lTyUHV,bCF1XK9WrZ = z9q2ova0OhKP1XemlViUbdx7Zu.split(WXuJd8nz2spo146t(u"ࠨ࠰ࠪཟ"),wAU9jKvmTM0(u"࠴Ꮦ"))
	uuJ5STjv1VHEXhdmFaW7OKkQGoB2P,S8MCkxwpOaHFEhD = bCF1XK9WrZ.split(MpJ8GOKoic(u"ࠩ࠲ࠫའ"),XCYALgFs2O3hZdpHrlMmB(u"࠵Ꮧ"))
	m7wxoiP840qI = ddSXt1GMLrZceIh0FW5lTyUHV+Nlyfx1HnzOWCovke5(u"ࠪ࠲ࠬཡ")+uuJ5STjv1VHEXhdmFaW7OKkQGoB2P
	if WypSQTO7504tHY in [ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫ࡭ࡵࡳࡵࠩར"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡴࡡ࡮ࡧࠪལ")] and MpJ8GOKoic(u"࠭࠯ࠨཤ") in m7wxoiP840qI: m7wxoiP840qI = m7wxoiP840qI.rsplit(ESXZrtnCfcDJGo01vFg(u"ࠧ࠰ࠩཥ"),wYTDlJC5vpOKynUEX3ge6W(u"࠶Ꮨ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
	if WypSQTO7504tHY==Nlyfx1HnzOWCovke5(u"ࠨࡰࡤࡱࡪ࠭ས") and MzgKWUQ4V5H(u"ࠩ࠱ࠫཧ") in m7wxoiP840qI:
		FEBwTWaDy2u = m7wxoiP840qI.split(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࠲ࠬཨ"))
		ttGrwnx7dcQT8b = len(FEBwTWaDy2u)
		if wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩཀྵ") in m7wxoiP840qI: FEBwTWaDy2u = ynxXU3gaiQ9GPCftr1q(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪཪ")
		elif ttGrwnx7dcQT8b<=RXnhpCUk4M1TvgJE: FEBwTWaDy2u = FEBwTWaDy2u[ufmXvxgoHGDwZtjsLkR05i]
		elif ttGrwnx7dcQT8b>=wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A: FEBwTWaDy2u = FEBwTWaDy2u[pwxH3oREFm5v98BCZ1QVtzMJOc]
		if len(FEBwTWaDy2u)>pwxH3oREFm5v98BCZ1QVtzMJOc: m7wxoiP840qI = FEBwTWaDy2u
	return m7wxoiP840qI
def IZHqo3tkufgnFv0sAGTRMQwbjda(EmIDdAfx3T):
	ttg4niUd7982o6Ll3YfkOeKP = repr(EmIDdAfx3T.encode(AoCWwJHgUPKXI7u2lEzym)).replace(WCPwmyVsb62KRlo(u"ࠨࠧࠣཫ"),Vk54F7GcROfCy6HunEI)
	return ttg4niUd7982o6Ll3YfkOeKP
def YqgcrtzU8LVNymnp3Z(ohrlLIC5R18):
	jsrO4URPFLmEb8wiuJoGICaZSgWHM = Vk54F7GcROfCy6HunEI
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: ohrlLIC5R18 = ohrlLIC5R18.decode(AoCWwJHgUPKXI7u2lEzym)
	from unicodedata import decomposition as IRWaJDtc8pPE4
	for bwSXdqv9oiDYJRsKga1HE5mh in ohrlLIC5R18:
		if   bwSXdqv9oiDYJRsKga1HE5mh==ESXZrtnCfcDJGo01vFg(u"ࡵࠨฤࠪཬ"): jjtKsrRTGxaBqQ71mL3e5CApNc = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳ࠩ཭")
		elif bwSXdqv9oiDYJRsKga1HE5mh==wYTDlJC5vpOKynUEX3ge6W(u"ࡷࠪวࠬ཮"): jjtKsrRTGxaBqQ71mL3e5CApNc = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡠࡡࡻ࠰࠷࠴࠶ࠫ཯")
		elif bwSXdqv9oiDYJRsKga1HE5mh==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࡹࠬสࠧ཰"): jjtKsrRTGxaBqQ71mL3e5CApNc = FGLEMi21Bfn(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹ཱ࠭")
		elif bwSXdqv9oiDYJRsKga1HE5mh==pnkrd2S84FJfN73KuiCYv(u"ࡻࠧฦིࠩ"): jjtKsrRTGxaBqQ71mL3e5CApNc = SSBkx0WbN1asnDCQV6tIj(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨཱི")
		elif bwSXdqv9oiDYJRsKga1HE5mh==cpHxZyU7vTtqmIw(u"ࡶࠩษུࠫ"): jjtKsrRTGxaBqQ71mL3e5CApNc = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ཱུࠪ")
		else:
			DRwdS3nmkNaCQY0LgHfGrp25XblPA = IRWaJDtc8pPE4(bwSXdqv9oiDYJRsKga1HE5mh)
			if otBWsSAfu7dihVkP9e1JFKrvmYy2Q in DRwdS3nmkNaCQY0LgHfGrp25XblPA: jjtKsrRTGxaBqQ71mL3e5CApNc = V2RQwM8XjlrK(u"ࠪࡠࡡࡻࠧྲྀ")+DRwdS3nmkNaCQY0LgHfGrp25XblPA.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
			else:
				jjtKsrRTGxaBqQ71mL3e5CApNc = FGLEMi21Bfn(u"ࠫ࠵࠶࠰࠱ࠩཷ")+hex(ord(bwSXdqv9oiDYJRsKga1HE5mh)).replace(WXuJd8nz2spo146t(u"ࠬ࠶ࡸࠨླྀ"),Vk54F7GcROfCy6HunEI)
				jjtKsrRTGxaBqQ71mL3e5CApNc = ESXZrtnCfcDJGo01vFg(u"࠭࡜࡝ࡷࠪཹ")+jjtKsrRTGxaBqQ71mL3e5CApNc[-BZm7TqLPJfAVblDKsya85zFWXNMY:]
		jsrO4URPFLmEb8wiuJoGICaZSgWHM += jjtKsrRTGxaBqQ71mL3e5CApNc
	jsrO4URPFLmEb8wiuJoGICaZSgWHM = jsrO4URPFLmEb8wiuJoGICaZSgWHM.replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨེ"),ynxXU3gaiQ9GPCftr1q(u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ཻࠩ"))
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: jsrO4URPFLmEb8wiuJoGICaZSgWHM = jsrO4URPFLmEb8wiuJoGICaZSgWHM.decode(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧོࠪ")).encode(AoCWwJHgUPKXI7u2lEzym)
	else: jsrO4URPFLmEb8wiuJoGICaZSgWHM = jsrO4URPFLmEb8wiuJoGICaZSgWHM.encode(AoCWwJHgUPKXI7u2lEzym).decode(SSBkx0WbN1asnDCQV6tIj(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨཽࠫ"))
	return jsrO4URPFLmEb8wiuJoGICaZSgWHM
def p3bB2auMmSjXC0dE8FUfZ(header=cpHxZyU7vTtqmIw(u"้ࠫ๎อสࠢส่๊็วห์ะࠫཾ"),BmAVzcqta91Xnrjyfk=Vk54F7GcROfCy6HunEI,iM0paGy4vZNPIgXAVld=eu1NswY9zkKC60I,source=Vk54F7GcROfCy6HunEI):
	RRG6QsiOkKU0ChovTBY3qdf = ZC4pLj0kJ3xAq8wgnHzG1DEs(header,BmAVzcqta91Xnrjyfk,type=SZDFRGim3j8L.INPUT_ALPHANUM)
	RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(qMmCGK8cln5bID4fkhAF,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	if not RRG6QsiOkKU0ChovTBY3qdf and not iM0paGy4vZNPIgXAVld:
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ynxXU3gaiQ9GPCftr1q(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠾ࠥࠦࠠࠣࠩཿ")+RRG6QsiOkKU0ChovTBY3qdf+Nlyfx1HnzOWCovke5(u"࠭ࠢࠨྀ"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮཱྀࠪ"),QYSAUI5r46yil8cfaO(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫྂ"))
		return Vk54F7GcROfCy6HunEI
	if RRG6QsiOkKU0ChovTBY3qdf not in [Vk54F7GcROfCy6HunEI,otBWsSAfu7dihVkP9e1JFKrvmYy2Q]:
		RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		RRG6QsiOkKU0ChovTBY3qdf = YqgcrtzU8LVNymnp3Z(RRG6QsiOkKU0ChovTBY3qdf)
	if source!=l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫྃ") and tPps36BvDZLbj4X1yfGnxOTJhM(ynxXU3gaiQ9GPCftr1q(u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈ྄ࠬ"),Vk54F7GcROfCy6HunEI,[RRG6QsiOkKU0ChovTBY3qdf],eu1NswY9zkKC60I):
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,MzgKWUQ4V5H(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧ྅")+RRG6QsiOkKU0ChovTBY3qdf+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࠨࠧ྆"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ྇"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩྈ"))
		return Vk54F7GcROfCy6HunEI
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫྉ")+RRG6QsiOkKU0ChovTBY3qdf+XCYALgFs2O3hZdpHrlMmB(u"ࠩࠥࠫྊ"))
	return RRG6QsiOkKU0ChovTBY3qdf
def uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,hj50MJnoOp6ZWaS1IQ8Elr,eDbTIrV6KLfz80={}):
	N39NCXDAaVnx,ttYN4QneOoLyix,Mln9dk5vU0aRuFLhoXcgCB8HVy,psmSVgP5Eth8fXaxTlyF7G = hj50MJnoOp6ZWaS1IQ8Elr,{},{},Vk54F7GcROfCy6HunEI
	if Nlyfx1HnzOWCovke5(u"ࠪࢀࠬྋ") in hj50MJnoOp6ZWaS1IQ8Elr: N39NCXDAaVnx,ttYN4QneOoLyix = vULz8h3qpug7jMCVHQcRZ(hj50MJnoOp6ZWaS1IQ8Elr,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࢁ࠭ྌ"))
	okDhIgR3alfXw06UFBHQqMNi4c1 = list(set(list(eDbTIrV6KLfz80.keys())+list(ttYN4QneOoLyix.keys())))
	for FFjms1g35EHqb4th in okDhIgR3alfXw06UFBHQqMNi4c1:
		if FFjms1g35EHqb4th in list(ttYN4QneOoLyix.keys()): Mln9dk5vU0aRuFLhoXcgCB8HVy[FFjms1g35EHqb4th] = ttYN4QneOoLyix[FFjms1g35EHqb4th]
		else: Mln9dk5vU0aRuFLhoXcgCB8HVy[FFjms1g35EHqb4th] = eDbTIrV6KLfz80[FFjms1g35EHqb4th]
	if MpJ8GOKoic(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩྍ") not in okDhIgR3alfXw06UFBHQqMNi4c1: Mln9dk5vU0aRuFLhoXcgCB8HVy[pnkrd2S84FJfN73KuiCYv(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྎ")] = p3QOAkrEuys81JqHobh()
	if WCPwmyVsb62KRlo(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨྏ") not in okDhIgR3alfXw06UFBHQqMNi4c1: Mln9dk5vU0aRuFLhoXcgCB8HVy[wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩྐ")] = RRav1Sf7Px(N39NCXDAaVnx,jXWzIZcDva4ikEUfN(u"ࠩࡸࡶࡱ࠭ྑ"))
	if ESXZrtnCfcDJGo01vFg(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬྒ") not in okDhIgR3alfXw06UFBHQqMNi4c1: Mln9dk5vU0aRuFLhoXcgCB8HVy[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ྒྷ")] = wYTDlJC5vpOKynUEX3ge6W(u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾࠭ྔ")
	for FFjms1g35EHqb4th in list(Mln9dk5vU0aRuFLhoXcgCB8HVy.keys()): psmSVgP5Eth8fXaxTlyF7G += HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠦࠨྕ")+FFjms1g35EHqb4th+SSBkx0WbN1asnDCQV6tIj(u"ࠧ࠾ࠩྖ")+Mln9dk5vU0aRuFLhoXcgCB8HVy[FFjms1g35EHqb4th]
	if psmSVgP5Eth8fXaxTlyF7G: psmSVgP5Eth8fXaxTlyF7G = V2RQwM8XjlrK(u"ࠨࡾࠪྗ")+psmSVgP5Eth8fXaxTlyF7G[pwxH3oREFm5v98BCZ1QVtzMJOc:]
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,FGLEMi21Bfn(u"ࠩࡊࡉ࡙࠭྘"),N39NCXDAaVnx,Vk54F7GcROfCy6HunEI,Mln9dk5vU0aRuFLhoXcgCB8HVy,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,FGLEMi21Bfn(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧྙ"),eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
	if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨྚ") not in UwghkPtqZiWTvsMLrl5dc0nuOAQ: return [g7yJo2LVuqx1trPe(u"ࠬ࠳࠱ࠨྛ")],[N39NCXDAaVnx+psmSVgP5Eth8fXaxTlyF7G]
	if YzowicIDTRusXZSU61(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪྜ") in UwghkPtqZiWTvsMLrl5dc0nuOAQ: return [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧ࠮࠳ࠪྜྷ")],[N39NCXDAaVnx+psmSVgP5Eth8fXaxTlyF7G]
	if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬྞ") in UwghkPtqZiWTvsMLrl5dc0nuOAQ: return [SSBkx0WbN1asnDCQV6tIj(u"ࠩ࠰࠵ࠬྟ")],[N39NCXDAaVnx+psmSVgP5Eth8fXaxTlyF7G]
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,evoL4XjzlEH7sT,gk2BaUyzTfWZPAVcF = [],[],[],[]
	nsiJk9RY6DLarMI = RSuYINdeamsK0t.findall(YzowicIDTRusXZSU61(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫྠ"),UwghkPtqZiWTvsMLrl5dc0nuOAQ+ixrPWKeFMnqJyVodX6D9AaO2,RSuYINdeamsK0t.DOTALL)
	if not nsiJk9RY6DLarMI: return [pnkrd2S84FJfN73KuiCYv(u"ࠫ࠲࠷ࠧྡ")],[N39NCXDAaVnx+psmSVgP5Eth8fXaxTlyF7G]
	for uFt4KliraXEoVBR603WgGAI2wHy,z9q2ova0OhKP1XemlViUbdx7Zu in nsiJk9RY6DLarMI:
		TMaJOvKoAiqF5Xp486s3CIGLhtc,LL82RbVxIQF1XBfYZM3,jMiru3pGns = {},-wAU9jKvmTM0(u"࠷Ꮩ"),-wAU9jKvmTM0(u"࠷Ꮩ")
		huiVWpc2jIt = Vk54F7GcROfCy6HunEI
		zsld7YEq5LXNUnp = uFt4KliraXEoVBR603WgGAI2wHy.split(jXWzIZcDva4ikEUfN(u"ࠬ࠲ࠧྡྷ"))
		for L39t14lv2dr7IYqxERZM in zsld7YEq5LXNUnp:
			if cpHxZyU7vTtqmIw(u"࠭࠽ࠨྣ") in L39t14lv2dr7IYqxERZM:
				FFjms1g35EHqb4th,XXQtT5EUp6lZJ4hjMxyiL9a = L39t14lv2dr7IYqxERZM.split(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࠾ࠩྤ"),QYSAUI5r46yil8cfaO(u"࠱Ꮪ"))
				TMaJOvKoAiqF5Xp486s3CIGLhtc[FFjms1g35EHqb4th.lower()] = XXQtT5EUp6lZJ4hjMxyiL9a
		if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬྥ") in uFt4KliraXEoVBR603WgGAI2wHy.lower():
			LL82RbVxIQF1XBfYZM3 = int(TMaJOvKoAiqF5Xp486s3CIGLhtc[WCPwmyVsb62KRlo(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ྦ")])//kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠲࠲࠵࠸Ꮫ")
			huiVWpc2jIt += str(LL82RbVxIQF1XBfYZM3)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪྦྷ")
		elif eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧྨ") in uFt4KliraXEoVBR603WgGAI2wHy.lower():
			LL82RbVxIQF1XBfYZM3 = int(TMaJOvKoAiqF5Xp486s3CIGLhtc[NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྩ")])//ynxXU3gaiQ9GPCftr1q(u"࠳࠳࠶࠹Ꮬ")
			huiVWpc2jIt += str(LL82RbVxIQF1XBfYZM3)+ESXZrtnCfcDJGo01vFg(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ྪ")
		if MpJ8GOKoic(u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫྫ") in uFt4KliraXEoVBR603WgGAI2wHy.lower():
			jMiru3pGns = int(TMaJOvKoAiqF5Xp486s3CIGLhtc[eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬྫྷ")].split(MpJ8GOKoic(u"ࠩࡻࠫྭ"))[pwxH3oREFm5v98BCZ1QVtzMJOc])
			huiVWpc2jIt += str(jMiru3pGns)+YIPoWuLzfl93BTS
		huiVWpc2jIt = huiVWpc2jIt.strip(YIPoWuLzfl93BTS)
		if not huiVWpc2jIt: huiVWpc2jIt = FGLEMi21Bfn(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫྮ")
		if not z9q2ova0OhKP1XemlViUbdx7Zu.startswith(WCPwmyVsb62KRlo(u"ࠫ࡭ࡺࡴࡱࠩྯ")):
			if z9q2ova0OhKP1XemlViUbdx7Zu.startswith(MzgKWUQ4V5H(u"ࠬ࠵࠯ࠨྰ")): z9q2ova0OhKP1XemlViUbdx7Zu = N39NCXDAaVnx.split(cpHxZyU7vTtqmIw(u"࠭࠺ࠨྱ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]+Nlyfx1HnzOWCovke5(u"ࠧ࠻ࠩྲ")+z9q2ova0OhKP1XemlViUbdx7Zu
			elif z9q2ova0OhKP1XemlViUbdx7Zu.startswith(jXWzIZcDva4ikEUfN(u"ࠨ࠱ࠪླ")): z9q2ova0OhKP1XemlViUbdx7Zu = RRav1Sf7Px(N39NCXDAaVnx,QYSAUI5r46yil8cfaO(u"ࠩࡸࡶࡱ࠭ྴ"))+z9q2ova0OhKP1XemlViUbdx7Zu
			else: z9q2ova0OhKP1XemlViUbdx7Zu = N39NCXDAaVnx.rsplit(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࠳ࠬྵ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]+FGLEMi21Bfn(u"ࠫ࠴࠭ྶ")+z9q2ova0OhKP1XemlViUbdx7Zu
		if pnkrd2S84FJfN73KuiCYv(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧྷ") in list(TMaJOvKoAiqF5Xp486s3CIGLhtc.keys()):
			YBDKFZOGfyCHLPA1EaUz9MJ = TMaJOvKoAiqF5Xp486s3CIGLhtc[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨྸ")]
			YBDKFZOGfyCHLPA1EaUz9MJ = YBDKFZOGfyCHLPA1EaUz9MJ.replace(pnkrd2S84FJfN73KuiCYv(u"ࠧࠣࠩྐྵ"),Vk54F7GcROfCy6HunEI).replace(wAU9jKvmTM0(u"ࠣࠩࠥྺ"),Vk54F7GcROfCy6HunEI).split(MpJ8GOKoic(u"ࠩࠦࠫྻ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
			LJp6PbnjvSTEGF = fLvc6uEJiq3(YBDKFZOGfyCHLPA1EaUz9MJ)
			if LJp6PbnjvSTEGF: esUNcDaPg3QoX = huiVWpc2jIt+YIPoWuLzfl93BTS+LJp6PbnjvSTEGF
			else: esUNcDaPg3QoX = huiVWpc2jIt
			esUNcDaPg3QoX = esUNcDaPg3QoX+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪྼ")
			esUNcDaPg3QoX = esUNcDaPg3QoX+YIPoWuLzfl93BTS+RRav1Sf7Px(YBDKFZOGfyCHLPA1EaUz9MJ,ynxXU3gaiQ9GPCftr1q(u"ࠫࡳࡧ࡭ࡦࠩ྽"))
			nWcb8JC7zEVouFjx9fILGh1vSQ.append(esUNcDaPg3QoX)
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(YBDKFZOGfyCHLPA1EaUz9MJ)
			evoL4XjzlEH7sT.append(jMiru3pGns)
			gk2BaUyzTfWZPAVcF.append(LL82RbVxIQF1XBfYZM3)
		z9q2ova0OhKP1XemlViUbdx7Zu = z9q2ova0OhKP1XemlViUbdx7Zu.split(ynxXU3gaiQ9GPCftr1q(u"ࠬࠩࠧ྾"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
		LJp6PbnjvSTEGF = fLvc6uEJiq3(z9q2ova0OhKP1XemlViUbdx7Zu)
		if LJp6PbnjvSTEGF: huiVWpc2jIt = huiVWpc2jIt+YIPoWuLzfl93BTS+LJp6PbnjvSTEGF
		huiVWpc2jIt = huiVWpc2jIt+YIPoWuLzfl93BTS+RRav1Sf7Px(z9q2ova0OhKP1XemlViUbdx7Zu,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡮ࡢ࡯ࡨࠫ྿"))
		nWcb8JC7zEVouFjx9fILGh1vSQ.append(huiVWpc2jIt)
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(z9q2ova0OhKP1XemlViUbdx7Zu)
		evoL4XjzlEH7sT.append(jMiru3pGns)
		gk2BaUyzTfWZPAVcF.append(LL82RbVxIQF1XBfYZM3)
	UpghGQ1aLFEWI5Xd = list(zip(nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,evoL4XjzlEH7sT,gk2BaUyzTfWZPAVcF))
	UpghGQ1aLFEWI5Xd = sorted(UpghGQ1aLFEWI5Xd, reverse=YOHXqtbQTBfKerIZ, key=lambda key: key[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A])
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,evoL4XjzlEH7sT,gk2BaUyzTfWZPAVcF = list(zip(*UpghGQ1aLFEWI5Xd))
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = list(nWcb8JC7zEVouFjx9fILGh1vSQ),list(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)
	v6eOQW0xrkL = []
	for z9q2ova0OhKP1XemlViUbdx7Zu in yyVoU0rfb17SRL5XmGYwDckpnQ3BI9: v6eOQW0xrkL.append(z9q2ova0OhKP1XemlViUbdx7Zu+psmSVgP5Eth8fXaxTlyF7G)
	QneYm8uXW7o = list(zip(v6eOQW0xrkL,[wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡥࡷࡰࡱࡾ࠭࿀")]*len(v6eOQW0xrkL),gk2BaUyzTfWZPAVcF))
	Kp8eZB1vgi7 = NXWlZoh3QPaAwSYx(TVPm7Bz1XOwJ2,QneYm8uXW7o)
	if Kp8eZB1vgi7:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,x7ohwWJScUpRi1K50qs,LL82RbVxIQF1XBfYZM3 = Kp8eZB1vgi7[NNjUsZzEcFOAoKry2CDMgb1(u"࠳Ꮭ")]
		index = v6eOQW0xrkL.index(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		title = nWcb8JC7zEVouFjx9fILGh1vSQ[index]
		nWcb8JC7zEVouFjx9fILGh1vSQ,v6eOQW0xrkL = [title],[ssfLBvkuNiXear2gPdxcyT4AQMhYSp]
	return nWcb8JC7zEVouFjx9fILGh1vSQ,v6eOQW0xrkL
def LUYAScDEWagR9o(yXHTMfhui87IRLSQmNv,EFl75DTWxtVedjRskgnaZr=Vk54F7GcROfCy6HunEI):
	if not EFl75DTWxtVedjRskgnaZr: EFl75DTWxtVedjRskgnaZr = h9zFQKnsNL.DNS_SERVERS[ufmXvxgoHGDwZtjsLkR05i]
	if yXHTMfhui87IRLSQmNv.replace(QYSAUI5r46yil8cfaO(u"ࠨ࠰ࠪ࿁"),Vk54F7GcROfCy6HunEI).isdigit(): return [yXHTMfhui87IRLSQmNv]
	from struct import pack as jNcESWmx7iQRu,unpack_from as d2OhoiI3sYcmbHL8E
	from socket import socket as bb3RGytoD6Mi1hAP,AF_INET as znoB95HRCwUOrcKfY,SOCK_DGRAM as ndkD9j2lxE0zsZRN5Ir
	try:
		wXNqL15CzeZHPsDF9m2G4V3BbSku = jNcESWmx7iQRu(WCPwmyVsb62KRlo(u"ࠤࡁࡌࠧ࿂"), WCPwmyVsb62KRlo(u"࠵࠷࠶࠴࠺Ꮮ"))
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠥࡂࡍࠨ࿃"), WsklGNp2CYzVQUag(u"࠷࠻࠶Ꮯ"))
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠦࡃࡎࠢ࿄"), pwxH3oREFm5v98BCZ1QVtzMJOc)
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡄࡈࠣ࿅"), ufmXvxgoHGDwZtjsLkR05i)
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(YzowicIDTRusXZSU61(u"ࠨ࠾ࡉࠤ࿆"), ufmXvxgoHGDwZtjsLkR05i)
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(WXuJd8nz2spo146t(u"ࠢ࠿ࡊࠥ࿇"), ufmXvxgoHGDwZtjsLkR05i)
		if PvwFsJK23NbU8XWAx: pQDKJj7LXqyvxZ4Ni3PgR09s = yXHTMfhui87IRLSQmNv.split(Nlyfx1HnzOWCovke5(u"ࠨ࠰ࠪ࿈"))
		else: pQDKJj7LXqyvxZ4Ni3PgR09s = yXHTMfhui87IRLSQmNv.decode(AoCWwJHgUPKXI7u2lEzym).split(cpHxZyU7vTtqmIw(u"ࠩ࠱ࠫ࿉"))
		for JJW0Q6ILzUqmEAot7scb9HlNPVDTG8 in pQDKJj7LXqyvxZ4Ni3PgR09s:
			eq7BWI1NM8xfYDbwUGv2LS = JJW0Q6ILzUqmEAot7scb9HlNPVDTG8.encode(AoCWwJHgUPKXI7u2lEzym)
			wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(Nlyfx1HnzOWCovke5(u"ࠥࡆࠧ࿊"), len(JJW0Q6ILzUqmEAot7scb9HlNPVDTG8))
			for NN9PmKR8hZW in JJW0Q6ILzUqmEAot7scb9HlNPVDTG8:
				wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠦࡨࠨ࿋"), NN9PmKR8hZW.encode(AoCWwJHgUPKXI7u2lEzym))
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(SSBkx0WbN1asnDCQV6tIj(u"ࠧࡈࠢ࿌"), ufmXvxgoHGDwZtjsLkR05i)
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(MpJ8GOKoic(u"ࠨ࠾ࡉࠤ࿍"), pwxH3oREFm5v98BCZ1QVtzMJOc)
		wXNqL15CzeZHPsDF9m2G4V3BbSku += jNcESWmx7iQRu(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠢ࠿ࡊࠥ࿎"), pwxH3oREFm5v98BCZ1QVtzMJOc)
		zytKrqcPLWXON6 = bb3RGytoD6Mi1hAP(znoB95HRCwUOrcKfY,ndkD9j2lxE0zsZRN5Ir)
		zytKrqcPLWXON6.sendto(bytes(wXNqL15CzeZHPsDF9m2G4V3BbSku),(EFl75DTWxtVedjRskgnaZr,wAU9jKvmTM0(u"࠻࠳Ꮰ")))
		zytKrqcPLWXON6.settimeout(wAU9jKvmTM0(u"࠶Ꮱ"))
		MFWydLr2JXCuVlUgAw9ERH8Yoiep, bxTiydcOuXWw4p1LNh = zytKrqcPLWXON6.recvfrom(wYTDlJC5vpOKynUEX3ge6W(u"࠲࠲࠵࠸Ꮲ"))
		zytKrqcPLWXON6.close()
		CPYf9iDS0kEQ65hVuRXr3zGWbHsp = d2OhoiI3sYcmbHL8E(wAU9jKvmTM0(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ࿏"), MFWydLr2JXCuVlUgAw9ERH8Yoiep, ufmXvxgoHGDwZtjsLkR05i)
		oosAUimZak1Y9If2nrHE = CPYf9iDS0kEQ65hVuRXr3zGWbHsp[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		PTRuwyGhQbCp7o64Ng = len(yXHTMfhui87IRLSQmNv)+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠳࠻Ꮳ")
		TcjPsL1WbHfAtq = []
		for _PH9pKOUb0CwjnyBVg2GLvFq8JYczD in range(oosAUimZak1Y9If2nrHE):
			oQYe9d5HBNqbsC8MuPiUGW = PTRuwyGhQbCp7o64Ng
			xOmhPet3EFILZT = pwxH3oREFm5v98BCZ1QVtzMJOc
			H5Qs49njS31L2igV8rPoMvYuGZ = eu1NswY9zkKC60I
			while YOHXqtbQTBfKerIZ:
				NN9PmKR8hZW = d2OhoiI3sYcmbHL8E(MpJ8GOKoic(u"ࠤࡁࡆࠧ࿐"), MFWydLr2JXCuVlUgAw9ERH8Yoiep, oQYe9d5HBNqbsC8MuPiUGW)[ufmXvxgoHGDwZtjsLkR05i]
				if NN9PmKR8hZW == ufmXvxgoHGDwZtjsLkR05i:
					oQYe9d5HBNqbsC8MuPiUGW += pwxH3oREFm5v98BCZ1QVtzMJOc
					break
				if NN9PmKR8hZW >= ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠴࠽࠷Ꮴ"):
					XpoahCil7GmxeI12uP3 = d2OhoiI3sYcmbHL8E(XCYALgFs2O3hZdpHrlMmB(u"ࠥࡂࡇࠨ࿑"), MFWydLr2JXCuVlUgAw9ERH8Yoiep, oQYe9d5HBNqbsC8MuPiUGW + pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
					oQYe9d5HBNqbsC8MuPiUGW = ((NN9PmKR8hZW << BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠼Ꮵ")) + XpoahCil7GmxeI12uP3 - 0xc000) - pwxH3oREFm5v98BCZ1QVtzMJOc
					H5Qs49njS31L2igV8rPoMvYuGZ = YOHXqtbQTBfKerIZ
				oQYe9d5HBNqbsC8MuPiUGW += pwxH3oREFm5v98BCZ1QVtzMJOc
				if H5Qs49njS31L2igV8rPoMvYuGZ == eu1NswY9zkKC60I: xOmhPet3EFILZT += pwxH3oREFm5v98BCZ1QVtzMJOc
			if H5Qs49njS31L2igV8rPoMvYuGZ == YOHXqtbQTBfKerIZ: xOmhPet3EFILZT += pwxH3oREFm5v98BCZ1QVtzMJOc
			PTRuwyGhQbCp7o64Ng = PTRuwyGhQbCp7o64Ng + xOmhPet3EFILZT
			gudrnhjHZ0Vx = d2OhoiI3sYcmbHL8E(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠦࡃࡎࡈࡊࡊࠥ࿒"), MFWydLr2JXCuVlUgAw9ERH8Yoiep, PTRuwyGhQbCp7o64Ng)
			PTRuwyGhQbCp7o64Ng = PTRuwyGhQbCp7o64Ng + QYSAUI5r46yil8cfaO(u"࠶࠶Ꮶ")
			okIhAlaeVtGFzUfSY52uTPMJbgKn = gudrnhjHZ0Vx[ufmXvxgoHGDwZtjsLkR05i]
			yXa5qKOvpYRA972wBJEn = gudrnhjHZ0Vx[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
			if okIhAlaeVtGFzUfSY52uTPMJbgKn == pwxH3oREFm5v98BCZ1QVtzMJOc:
				ZHxiAgpoDMOLw1eK3GbrlmBzv82hC4 = d2OhoiI3sYcmbHL8E(V2RQwM8XjlrK(u"ࠧࡄࠢ࿓")+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡂࠣ࿔")*yXa5qKOvpYRA972wBJEn, MFWydLr2JXCuVlUgAw9ERH8Yoiep, PTRuwyGhQbCp7o64Ng)
				ip = Vk54F7GcROfCy6HunEI
				for NN9PmKR8hZW in ZHxiAgpoDMOLw1eK3GbrlmBzv82hC4: ip += str(NN9PmKR8hZW) + Nlyfx1HnzOWCovke5(u"ࠧ࠯ࠩ࿕")
				ip = ip[ufmXvxgoHGDwZtjsLkR05i:-pwxH3oREFm5v98BCZ1QVtzMJOc]
				TcjPsL1WbHfAtq.append(ip)
			if okIhAlaeVtGFzUfSY52uTPMJbgKn in [pwxH3oREFm5v98BCZ1QVtzMJOc,RXnhpCUk4M1TvgJE,FGLEMi21Bfn(u"࠶Ꮹ"),jXWzIZcDva4ikEUfN(u"࠸Ꮺ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠱࠶Ꮸ"),YzowicIDTRusXZSU61(u"࠸࠸Ꮷ")]: PTRuwyGhQbCp7o64Ng = PTRuwyGhQbCp7o64Ng + yXa5qKOvpYRA972wBJEn
	except: TcjPsL1WbHfAtq = []
	if not TcjPsL1WbHfAtq: iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧ࿖")+yXHTMfhui87IRLSQmNv+SSBkx0WbN1asnDCQV6tIj(u"ࠩࠣࡡࠬ࿗"))
	return TcjPsL1WbHfAtq
def tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,N39NCXDAaVnx,TwIJRB04mjGDfpz7CQMdco,showDialogs=YOHXqtbQTBfKerIZ):
	if TwIJRB04mjGDfpz7CQMdco:
		J4Xl9cVt31rhTQZ = [kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ็ออัࠨ࿘"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫออไ฻ࠩ࿙"),cpHxZyU7vTtqmIw(u"ࠬࡧࡤࡶ࡮ࡷࠫ࿚"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡸࡹࠩ࿛"),MpJ8GOKoic(u"ࠧࡴࡧࡻࠫ࿜")]
		if TVPm7Bz1XOwJ2!=EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡄࡒࡏࡗࡇࠧ࿝"):
			J4Xl9cVt31rhTQZ += [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡵ࠾ࠬ࿞"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡶ࠲࠭࿟"),MzgKWUQ4V5H(u"ࠫ࠲ࡳࡡࠨ࿠")]
			J4Xl9cVt31rhTQZ += [QYSAUI5r46yil8cfaO(u"ࠬࡀࡲࠨ࿡"),wAU9jKvmTM0(u"࠭࠭ࡳࠩ࿢"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧ࡮ࡣ࠰ࠫ࿣")]
		for uuw8OrnPmSMvWxEH32TfVRsIqXaZYD in TwIJRB04mjGDfpz7CQMdco:
			if pnkrd2S84FJfN73KuiCYv(u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ࿤") in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD: continue
			if EM6qpnCBYQGA9kbgDVLfrP(u"ࠩะ่็ฯࠧ࿥") in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD: continue
			uuw8OrnPmSMvWxEH32TfVRsIqXaZYD = uuw8OrnPmSMvWxEH32TfVRsIqXaZYD.lower()
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: uuw8OrnPmSMvWxEH32TfVRsIqXaZYD = uuw8OrnPmSMvWxEH32TfVRsIqXaZYD.decode(AoCWwJHgUPKXI7u2lEzym).encode(AoCWwJHgUPKXI7u2lEzym)
			uuw8OrnPmSMvWxEH32TfVRsIqXaZYD = uuw8OrnPmSMvWxEH32TfVRsIqXaZYD.replace(MpJ8GOKoic(u"ࠪ࠾ࠬ࿦"),Vk54F7GcROfCy6HunEI)
			EE7WjomwquRByLKdTf5Y6XH4rlc = RSuYINdeamsK0t.findall(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ࿧"),uuw8OrnPmSMvWxEH32TfVRsIqXaZYD,RSuYINdeamsK0t.DOTALL)
			BUKJSprVaxz9HA5c = eu1NswY9zkKC60I
			for klfqSEZMD3ALJ in EE7WjomwquRByLKdTf5Y6XH4rlc:
				if len(klfqSEZMD3ALJ)==RXnhpCUk4M1TvgJE:
					BUKJSprVaxz9HA5c = YOHXqtbQTBfKerIZ
					break
			if WsklGNp2CYzVQUag(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ࿨") in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD: continue
			elif EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ࿩") in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD: continue
			elif Nlyfx1HnzOWCovke5(u"ࠧ฻์ิࠤ๊฻ๆโࠩ࿪") in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD: continue
			elif oYqQF65i48Uhzmw3jkJPRGsZnV([cpHxZyU7vTtqmIw(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ࿫")])[ufmXvxgoHGDwZtjsLkR05i]: continue
			elif uuw8OrnPmSMvWxEH32TfVRsIqXaZYD in [ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡵࠫ࿬")] or BUKJSprVaxz9HA5c or any(value in uuw8OrnPmSMvWxEH32TfVRsIqXaZYD for value in J4Xl9cVt31rhTQZ):
				iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ࿭")+N39NCXDAaVnx+MzgKWUQ4V5H(u"ࠫࠥࡣࠧ࿮"))
				if showDialogs: qJAOp7HgfKeMQkDau(eAMGzHRQVs2KyCwPXljYhB(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿯"),jXWzIZcDva4ikEUfN(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ࿰"))
				return YOHXqtbQTBfKerIZ
	return eu1NswY9zkKC60I
def GHdYDixegkm9PJMN(*aargs,**kkwargs):
	if aargs:
		direction = aargs[ufmXvxgoHGDwZtjsLkR05i]
		nc4wgDyBRPEWiHf5mxYGNVql = aargs[pwxH3oREFm5v98BCZ1QVtzMJOc]
		if not direction: direction = pnkrd2S84FJfN73KuiCYv(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿱")
		if not nc4wgDyBRPEWiHf5mxYGNVql: nc4wgDyBRPEWiHf5mxYGNVql = pnkrd2S84FJfN73KuiCYv(u"ࠨษึฮ๊ืวาࠩ࿲")
		jCkV6rcG1ahI = aargs[RXnhpCUk4M1TvgJE]
		RRG6QsiOkKU0ChovTBY3qdf = ixrPWKeFMnqJyVodX6D9AaO2.join(aargs[pnkrd2S84FJfN73KuiCYv(u"࠶Ꮻ"):])
	else: direction,nc4wgDyBRPEWiHf5mxYGNVql,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf = Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠩࡒࡏࠬ࿳"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	rAdiM2DVzBuxjPvYFTQs(direction,Vk54F7GcROfCy6HunEI,nc4wgDyBRPEWiHf5mxYGNVql,Vk54F7GcROfCy6HunEI,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,**kkwargs)
	return
def WfM3l9n0GTFrVaeUxcsktQyJvYIC8(*aargs,**kkwargs):
	direction = aargs[ufmXvxgoHGDwZtjsLkR05i]
	UkjCcTf3DS0OQ = aargs[pwxH3oREFm5v98BCZ1QVtzMJOc]
	jiQdOIMupEN03Rxm29G = aargs[RXnhpCUk4M1TvgJE]
	if jiQdOIMupEN03Rxm29G or UkjCcTf3DS0OQ: PJ5WFuDSI1gcGv = YOHXqtbQTBfKerIZ
	else: PJ5WFuDSI1gcGv = eu1NswY9zkKC60I
	jCkV6rcG1ahI = aargs[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
	RRG6QsiOkKU0ChovTBY3qdf = aargs[BZm7TqLPJfAVblDKsya85zFWXNMY]
	if not direction: direction = MpJ8GOKoic(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࿴")
	if not UkjCcTf3DS0OQ: UkjCcTf3DS0OQ = WCPwmyVsb62KRlo(u"่๊ࠫวࠡࠢࡑࡳࠬ࿵")
	if not jiQdOIMupEN03Rxm29G: jiQdOIMupEN03Rxm29G = ESXZrtnCfcDJGo01vFg(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ࿶")
	if len(aargs)>=g7yJo2LVuqx1trPe(u"࠻Ꮽ"): RRG6QsiOkKU0ChovTBY3qdf += ixrPWKeFMnqJyVodX6D9AaO2+aargs[Nlyfx1HnzOWCovke5(u"࠹Ꮼ")]
	if len(aargs)>=FGLEMi21Bfn(u"࠽Ꮾ"): RRG6QsiOkKU0ChovTBY3qdf += ixrPWKeFMnqJyVodX6D9AaO2+aargs[l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠶Ꮿ")]
	B69G5sUjmDJelfod481KPAyHwc = rAdiM2DVzBuxjPvYFTQs(direction,UkjCcTf3DS0OQ,Vk54F7GcROfCy6HunEI,jiQdOIMupEN03Rxm29G,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,**kkwargs)
	if B69G5sUjmDJelfod481KPAyHwc==-ESXZrtnCfcDJGo01vFg(u"࠲Ᏸ") and PJ5WFuDSI1gcGv: B69G5sUjmDJelfod481KPAyHwc = -pwxH3oREFm5v98BCZ1QVtzMJOc
	elif B69G5sUjmDJelfod481KPAyHwc==-pwxH3oREFm5v98BCZ1QVtzMJOc and not PJ5WFuDSI1gcGv: B69G5sUjmDJelfod481KPAyHwc = eu1NswY9zkKC60I
	elif B69G5sUjmDJelfod481KPAyHwc==ufmXvxgoHGDwZtjsLkR05i: B69G5sUjmDJelfod481KPAyHwc = eu1NswY9zkKC60I
	elif B69G5sUjmDJelfod481KPAyHwc==RXnhpCUk4M1TvgJE: B69G5sUjmDJelfod481KPAyHwc = YOHXqtbQTBfKerIZ
	return B69G5sUjmDJelfod481KPAyHwc
def LcOJD0oVT1j5KHnbX3amFwueWC9lsi(*aargs,**kkwargs):
	return SZDFRGim3j8L.Dialog().select(*aargs,**kkwargs)
def qJAOp7HgfKeMQkDau(*aargs,**kkwargs):
	jCkV6rcG1ahI = aargs[ufmXvxgoHGDwZtjsLkR05i]
	RRG6QsiOkKU0ChovTBY3qdf = aargs[pwxH3oREFm5v98BCZ1QVtzMJOc]
	kLCrgOEchfHXm2njiUp6sSF40BVYM5 = kkwargs[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡴࡪ࡯ࡨࠫ࿷")] if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡵ࡫ࡰࡩࠬ࿸") in list(kkwargs.keys()) else g7yJo2LVuqx1trPe(u"࠳࠳࠴࠵Ᏹ")
	UYXtrDhFTbpW5ka473IEMQyw = aargs[RXnhpCUk4M1TvgJE] if len(aargs)>RXnhpCUk4M1TvgJE and SSBkx0WbN1asnDCQV6tIj(u"ࠨࡶ࡬ࡱࡪ࠭࿹") not in aargs[RXnhpCUk4M1TvgJE] else kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ࿺")
	TTh4jOyVfgMDR9KL7Bqo0I = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=z7sDjfgtRZ,args=(jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,UYXtrDhFTbpW5ka473IEMQyw,kLCrgOEchfHXm2njiUp6sSF40BVYM5))
	TTh4jOyVfgMDR9KL7Bqo0I.start()
	return
def z7sDjfgtRZ(jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,UYXtrDhFTbpW5ka473IEMQyw,kLCrgOEchfHXm2njiUp6sSF40BVYM5):
	Keukxq2U3mDCX9dgSpfn5ctl = UYXtrDhFTbpW5ka473IEMQyw.replace(FGLEMi21Bfn(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪ࿻"),Vk54F7GcROfCy6HunEI)
	name = jrELQfAuqnWc9pBSPivOb5Ft(YOHXqtbQTBfKerIZ,Keukxq2U3mDCX9dgSpfn5ctl+WCPwmyVsb62KRlo(u"ࠫࠥ࠳ࠠࠨ࿼")+jCkV6rcG1ahI+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࠦ࠭ࠡࠩ࿽")+RRG6QsiOkKU0ChovTBY3qdf)
	name = I1yWnMRpsx5(name)
	image_filename = CR3aLOVKSIme5XFoYi6M.path.join(LK7CQmtyiX2,name+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠮ࡱࡰࡪࠫ࿾"))
	if CR3aLOVKSIme5XFoYi6M.path.exists(image_filename):
		if UYXtrDhFTbpW5ka473IEMQyw==jXWzIZcDva4ikEUfN(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ࿿"): image_height = MpJ8GOKoic(u"࠴࠵࠼Ᏺ")
		elif UYXtrDhFTbpW5ka473IEMQyw==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬက"): image_height = ESXZrtnCfcDJGo01vFg(u"࠶࠶࠶Ᏻ")
	else: image_height = HmN7xPhSEQLzrqU(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,UYXtrDhFTbpW5ka473IEMQyw,WCPwmyVsb62KRlo(u"ࠩ࡯ࡩ࡫ࡺࠧခ"),eu1NswY9zkKC60I,image_filename)
	JEy40MGB7vZ3g = IIRl9dofH3J2inXOjCeQatA18g(WsklGNp2CYzVQUag(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪဂ"),cbFKmEkqwLU0vYD3pT,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬဃ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬ࠽࠲࠱ࡲࠪင"))
	JEy40MGB7vZ3g.show()
	if UYXtrDhFTbpW5ka473IEMQyw==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪစ"):
		JEy40MGB7vZ3g.getControl(wYTDlJC5vpOKynUEX3ge6W(u"࠿࠰࠵࠲Ᏽ")).setHeight(EM6qpnCBYQGA9kbgDVLfrP(u"࠷࠷࠵Ᏼ"))
		JEy40MGB7vZ3g.getControl(XCYALgFs2O3hZdpHrlMmB(u"࠻࠳࠸࠵ᏸ")).setPosition(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠵࠶᏶"),-ynxXU3gaiQ9GPCftr1q(u"࠹࠲᏷"))
		JEy40MGB7vZ3g.getControl(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠼࠴࠺࠶ᏹ")).setPosition(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠵࠷࠶ᏺ"),-SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠻࠶ᏻ"))
		JEy40MGB7vZ3g.getControl(WsklGNp2CYzVQUag(u"࠵࠲࠳᏾")).setPosition(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠿࠰ᏼ"),-pnkrd2S84FJfN73KuiCYv(u"࠳࠶ᏽ"))
	JEy40MGB7vZ3g.getControl(NNjUsZzEcFOAoKry2CDMgb1(u"࠶࠳࠵᏿")).setVisible(eu1NswY9zkKC60I)
	JEy40MGB7vZ3g.getControl(EM6qpnCBYQGA9kbgDVLfrP(u"࠷࠴࠷᐀")).setVisible(eu1NswY9zkKC60I)
	JEy40MGB7vZ3g.getControl(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠽࠵࠻࠰ᐁ")).setImage(image_filename)
	JEy40MGB7vZ3g.getControl(g7yJo2LVuqx1trPe(u"࠾࠶࠵࠱ᐂ")).setHeight(image_height)
	Gb6kwVlSQ4MU.sleep(kLCrgOEchfHXm2njiUp6sSF40BVYM5//kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠷࠰࠱࠲࠱࠴ᐃ"))
	return
def JJWH15tngbuPBpId(*aargs,**kkwargs):
	jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,profile,direction = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨဆ"),XCYALgFs2O3hZdpHrlMmB(u"ࠨ࡮ࡨࡪࡹ࠭ဇ")
	if len(aargs)>=pwxH3oREFm5v98BCZ1QVtzMJOc: jCkV6rcG1ahI = aargs[ufmXvxgoHGDwZtjsLkR05i]
	if len(aargs)>=RXnhpCUk4M1TvgJE: RRG6QsiOkKU0ChovTBY3qdf = aargs[pwxH3oREFm5v98BCZ1QVtzMJOc]
	if len(aargs)>=wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A: profile = aargs[RXnhpCUk4M1TvgJE]
	if len(aargs)>=BZm7TqLPJfAVblDKsya85zFWXNMY: direction = aargs[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
	return aaNxZcCAYds8FEjDqzgBhK4(direction,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,profile)
def Rx1mwkch5ZKu(*aargs,**kkwargs):
	return SZDFRGim3j8L.Dialog().contextmenu(*aargs,**kkwargs)
def Lx3W825r7KeO(*aargs,**kkwargs):
	return SZDFRGim3j8L.Dialog().browseSingle(*aargs,**kkwargs)
def ZC4pLj0kJ3xAq8wgnHzG1DEs(*aargs,**kkwargs):
	return SZDFRGim3j8L.Dialog().input(*aargs,**kkwargs)
def LfgAx0QSMK59hF(*aargs,**kkwargs):
	return SZDFRGim3j8L.DialogProgress(*aargs,**kkwargs)
def rAdiM2DVzBuxjPvYFTQs(direction,button0=Vk54F7GcROfCy6HunEI,button1=Vk54F7GcROfCy6HunEI,button2=Vk54F7GcROfCy6HunEI,jCkV6rcG1ahI=Vk54F7GcROfCy6HunEI,RRG6QsiOkKU0ChovTBY3qdf=Vk54F7GcROfCy6HunEI,profile=NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫဈ"),ZZE6AOehYUFRc9d2zBKkQJ=ufmXvxgoHGDwZtjsLkR05i,FSWT1uCJ0cpltrK=ufmXvxgoHGDwZtjsLkR05i):
	if not direction: direction = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡧࡪࡴࡴࡦࡴࠪဉ")
	JEy40MGB7vZ3g = b8RlryPD5BkJoYs9jFTQga6t41V(WsklGNp2CYzVQUag(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ည"),cbFKmEkqwLU0vYD3pT,pnkrd2S84FJfN73KuiCYv(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ဋ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࠷࠳࠲ࡳࠫဌ"))
	JEy40MGB7vZ3g.eV48fz316u5QhEglBRoUWCcLr0(button0,button1,button2,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,profile,direction,ZZE6AOehYUFRc9d2zBKkQJ,FSWT1uCJ0cpltrK)
	if ZZE6AOehYUFRc9d2zBKkQJ>ufmXvxgoHGDwZtjsLkR05i: JEy40MGB7vZ3g.NykG4LxE0SldQ69TfcIMbuq()
	if FSWT1uCJ0cpltrK>ufmXvxgoHGDwZtjsLkR05i: JEy40MGB7vZ3g.JgQYaw19VGcFRfqsM46PK()
	if ZZE6AOehYUFRc9d2zBKkQJ==ufmXvxgoHGDwZtjsLkR05i and FSWT1uCJ0cpltrK==ufmXvxgoHGDwZtjsLkR05i: JEy40MGB7vZ3g.y8QVNgke2IvdiKApRrZPW()
	JEy40MGB7vZ3g.doModal()
	B69G5sUjmDJelfod481KPAyHwc = JEy40MGB7vZ3g.choiceID
	return B69G5sUjmDJelfod481KPAyHwc
def aaNxZcCAYds8FEjDqzgBhK4(direction,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,profile=pnkrd2S84FJfN73KuiCYv(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨဍ")):
	if not direction: direction = wYTDlJC5vpOKynUEX3ge6W(u"ࠨ࡮ࡨࡪࡹ࠭ဎ")
	JEy40MGB7vZ3g = IIRl9dofH3J2inXOjCeQatA18g(NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬဏ"),cbFKmEkqwLU0vYD3pT,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫတ"),pnkrd2S84FJfN73KuiCYv(u"ࠫ࠼࠸࠰ࡱࠩထ"))
	image_filename = HBALC2smGtRxwFluDOgdX.replace(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬဒ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࡟ࠨဓ")+str(Gb6kwVlSQ4MU.time())+Nlyfx1HnzOWCovke5(u"ࠧࡠࠩန"))
	image_filename = image_filename.replace(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡞࡟ࠫပ"),Nlyfx1HnzOWCovke5(u"ࠩ࡟ࡠࡡࡢࠧဖ")).replace(YzowicIDTRusXZSU61(u"ࠪ࠳࠴࠭ဗ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࠴࠵࠯࠰ࠩဘ"))
	image_height = HmN7xPhSEQLzrqU(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jCkV6rcG1ahI,RRG6QsiOkKU0ChovTBY3qdf,profile,direction,eu1NswY9zkKC60I,image_filename)
	JEy40MGB7vZ3g.show()
	JEy40MGB7vZ3g.getControl(cpHxZyU7vTtqmIw(u"࠹࠱࠷࠳ᐄ")).setHeight(image_height)
	JEy40MGB7vZ3g.getControl(ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠺࠲࠸࠴ᐅ")).setImage(image_filename)
	fVn0BliHIa5h = JEy40MGB7vZ3g.doModal()
	try: CR3aLOVKSIme5XFoYi6M.remove(image_filename)
	except: pass
	return fVn0BliHIa5h
def p3QOAkrEuys81JqHobh(UwGQ4qegOomAj2KZbI5YdRVSBX=YOHXqtbQTBfKerIZ):
	if UwGQ4qegOomAj2KZbI5YdRVSBX:
		rZigEYv8tbVk = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡹࡴࡳࠩမ"),g7yJo2LVuqx1trPe(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩယ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪရ"))
		if rZigEYv8tbVk: return rZigEYv8tbVk
	RRG6QsiOkKU0ChovTBY3qdf = Vk54F7GcROfCy6HunEI
	if ufmXvxgoHGDwZtjsLkR05i and s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
		haQpuc6O5b = UwghkPtqZiWTvsMLrl5dc0nuOAQ.count(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢࠩလ"))
		if haQpuc6O5b>V2RQwM8XjlrK(u"࠺࠳ᐆ"):
			RRG6QsiOkKU0ChovTBY3qdf = RSuYINdeamsK0t.findall(MzgKWUQ4V5H(u"ࠩࡪࡩࡹ࠳ࡴࡩࡧ࠰ࡰ࡮ࡹࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫဝ"),UwghkPtqZiWTvsMLrl5dc0nuOAQ,RSuYINdeamsK0t.DOTALL)
			RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf[ufmXvxgoHGDwZtjsLkR05i]
	if not RRG6QsiOkKU0ChovTBY3qdf:
		Ie9FJ3zdcVGl6Unr7NB8jZS = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,g7yJo2LVuqx1trPe(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩသ"),V2RQwM8XjlrK(u"ࠫࡺࡹࡥࡳࡣࡪࡩࡳࡺࡳ࠯ࡶࡻࡸࠬဟ"))
		RRG6QsiOkKU0ChovTBY3qdf = open(Ie9FJ3zdcVGl6Unr7NB8jZS,wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡸࡢࠨဠ")).read()
		if PvwFsJK23NbU8XWAx: RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf.decode(AoCWwJHgUPKXI7u2lEzym)
		RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf.replace(gSiK7EQVNXClOUDZGs,Vk54F7GcROfCy6HunEI)
	Uxlc6PypwRNG0o = RSuYINdeamsK0t.findall(ESXZrtnCfcDJGo01vFg(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧအ"),RRG6QsiOkKU0ChovTBY3qdf,RSuYINdeamsK0t.DOTALL)
	QK4GXYZRnl96 = []
	for uFt4KliraXEoVBR603WgGAI2wHy in Uxlc6PypwRNG0o:
		QKmx0uPsH9I6yeapXLhN54v = uFt4KliraXEoVBR603WgGAI2wHy.lower()
		if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨဢ") in QKmx0uPsH9I6yeapXLhN54v: continue
		if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡷࡥࡹࡳࡺࡵࠨဣ") in QKmx0uPsH9I6yeapXLhN54v: continue
		if jXWzIZcDva4ikEUfN(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩဤ") in QKmx0uPsH9I6yeapXLhN54v: continue
		if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡧࡷࡵࡳࠨဥ") in QKmx0uPsH9I6yeapXLhN54v: continue
		QK4GXYZRnl96.append(uFt4KliraXEoVBR603WgGAI2wHy)
	rZigEYv8tbVk = budUNB9jgpI8Pm5.sample(QK4GXYZRnl96,pwxH3oREFm5v98BCZ1QVtzMJOc)
	rZigEYv8tbVk = rZigEYv8tbVk[ufmXvxgoHGDwZtjsLkR05i]
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,FGLEMi21Bfn(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧဦ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨဧ"),rZigEYv8tbVk,ddQIv6q9hTce1iA0nWSX5UuLaNb)
	return rZigEYv8tbVk
def ha6J2Q31InwURpklLx94TS75(ovLGZ5jUxNzmiQC=Vk54F7GcROfCy6HunEI):
	if h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX==eu1NswY9zkKC60I: return
	if not ovLGZ5jUxNzmiQC: ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
	if BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡓࡺࡵࡷࡩࡲࡋࡸࡪࡶࠪဨ") in ovLGZ5jUxNzmiQC or ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪဩ") in ovLGZ5jUxNzmiQC: return
	if ovLGZ5jUxNzmiQC!=FGLEMi21Bfn(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫဪ"): yBxCpcVaPow1bztQm4X.stderr.write(ovLGZ5jUxNzmiQC)
	nsiJk9RY6DLarMI = ovLGZ5jUxNzmiQC.splitlines()
	UzQpsgO6iuy2WP70RCSvjMn3VIqN = nsiJk9RY6DLarMI[-wYTDlJC5vpOKynUEX3ge6W(u"࠴ᐇ")]
	w83wXWLDo0fdGkKy7 = open(uta6N9f2PIW8e,wAU9jKvmTM0(u"ࠩࡵࡦࠬါ")).read()
	if PvwFsJK23NbU8XWAx: w83wXWLDo0fdGkKy7 = w83wXWLDo0fdGkKy7.decode(AoCWwJHgUPKXI7u2lEzym)
	w83wXWLDo0fdGkKy7 = w83wXWLDo0fdGkKy7[-WXuJd8nz2spo146t(u"࠼࠵࠶࠰ᐈ"):]
	wLMdNAUREnq0v = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡁࠬာ")*HOxJyt7l8osNeCjZFMQGi4Sr(u"࠶࠶࠰ᐉ")
	if wLMdNAUREnq0v in w83wXWLDo0fdGkKy7: w83wXWLDo0fdGkKy7 = w83wXWLDo0fdGkKy7.rsplit(wLMdNAUREnq0v,pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
	if UzQpsgO6iuy2WP70RCSvjMn3VIqN in w83wXWLDo0fdGkKy7: w83wXWLDo0fdGkKy7 = w83wXWLDo0fdGkKy7.rsplit(UzQpsgO6iuy2WP70RCSvjMn3VIqN,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
	LzpvmNuXZQDYr = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪိ"),w83wXWLDo0fdGkKy7,RSuYINdeamsK0t.DOTALL)
	for jPWvotAhpL76c,JlT9OB143U in reversed(LzpvmNuXZQDYr):
		if JlT9OB143U: break
	else: JlT9OB143U = WsklGNp2CYzVQUag(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬီ")
	l8IhwvESacb36y0fKG4noVLzDgu,uFt4KliraXEoVBR603WgGAI2wHy,O7ZwFcH3LTv = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY = XCYALgFs2O3hZdpHrlMmB(u"࡛࠭ࡓࡖࡏࡡࠬု")+d761ZWXHEvliYN45RzLP2+ynxXU3gaiQ9GPCftr1q(u"ࠧศๆั฻ศࡀࠠࠡࠩူ")+ZZoLlKyInXc08j2pTGJ+UzQpsgO6iuy2WP70RCSvjMn3VIqN
	tW8xaRsY0I25Sruv3wog4zJqO = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࡝ࡕࡘࡑࡣࠧေ")+d761ZWXHEvliYN45RzLP2+WsklGNp2CYzVQUag(u"ࠩส่๊฻ฯา࠼ࠣࠤࠬဲ")+ZZoLlKyInXc08j2pTGJ+JlT9OB143U
	for fVjNYZvuCIFiPald8hgqtBO4xJryz6 in reversed(nsiJk9RY6DLarMI):
		if wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡊ࡮ࡲࡥࠡࠤࠪဳ") in fVjNYZvuCIFiPald8hgqtBO4xJryz6 and NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪဴ") in fVjNYZvuCIFiPald8hgqtBO4xJryz6: break
	fVjNYZvuCIFiPald8hgqtBO4xJryz6 = RSuYINdeamsK0t.findall(wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨဵ"),fVjNYZvuCIFiPald8hgqtBO4xJryz6,RSuYINdeamsK0t.DOTALL)
	if fVjNYZvuCIFiPald8hgqtBO4xJryz6:
		l8IhwvESacb36y0fKG4noVLzDgu,uFt4KliraXEoVBR603WgGAI2wHy,O7ZwFcH3LTv = fVjNYZvuCIFiPald8hgqtBO4xJryz6[ufmXvxgoHGDwZtjsLkR05i]
		if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࠯ࠨံ") in l8IhwvESacb36y0fKG4noVLzDgu: l8IhwvESacb36y0fKG4noVLzDgu = l8IhwvESacb36y0fKG4noVLzDgu.rsplit(XCYALgFs2O3hZdpHrlMmB(u"ࠧ࠰့ࠩ"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
		else: l8IhwvESacb36y0fKG4noVLzDgu = l8IhwvESacb36y0fKG4noVLzDgu.rsplit(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࡞࡟ࠫး"),pwxH3oREFm5v98BCZ1QVtzMJOc)[pwxH3oREFm5v98BCZ1QVtzMJOc]
		FFVM3CWSntmDq4 = XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ္")+d761ZWXHEvliYN45RzLP2+ESXZrtnCfcDJGo01vFg(u"ࠪห้๋ไโ࠼ࠣࠤ်ࠬ")+ZZoLlKyInXc08j2pTGJ+l8IhwvESacb36y0fKG4noVLzDgu
		N7QnmSMfTj4 = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡠࡘࡔࡍ࡟ࠪျ")+d761ZWXHEvliYN45RzLP2+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬอไิูิ࠾ࠥࠦࠧြ")+ZZoLlKyInXc08j2pTGJ+uFt4KliraXEoVBR603WgGAI2wHy
		zXSjtPwA5uqC3ahV8oeKMIEWylvFR = EM6qpnCBYQGA9kbgDVLfrP(u"࡛࠭ࡓࡖࡏࡡࠬွ")+d761ZWXHEvliYN45RzLP2+ESXZrtnCfcDJGo01vFg(u"ࠧศๆ่็ฬ์࠺ࠡࠢࠪှ")+ZZoLlKyInXc08j2pTGJ+O7ZwFcH3LTv
		A3sitxjc2EyLhbFWVdg5UXTra = FFVM3CWSntmDq4+ixrPWKeFMnqJyVodX6D9AaO2+N7QnmSMfTj4+ixrPWKeFMnqJyVodX6D9AaO2+zXSjtPwA5uqC3ahV8oeKMIEWylvFR+ixrPWKeFMnqJyVodX6D9AaO2+tW8xaRsY0I25Sruv3wog4zJqO+ixrPWKeFMnqJyVodX6D9AaO2+Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY
		JduW815QOYTm0PibE = N7QnmSMfTj4+ixrPWKeFMnqJyVodX6D9AaO2+tW8xaRsY0I25Sruv3wog4zJqO+ixrPWKeFMnqJyVodX6D9AaO2+Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY+ixrPWKeFMnqJyVodX6D9AaO2+FFVM3CWSntmDq4+ixrPWKeFMnqJyVodX6D9AaO2+zXSjtPwA5uqC3ahV8oeKMIEWylvFR
		wSzsmCD03pTyOBncR5LiojN = N7QnmSMfTj4+ixrPWKeFMnqJyVodX6D9AaO2+Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY+ixrPWKeFMnqJyVodX6D9AaO2+FFVM3CWSntmDq4+ixrPWKeFMnqJyVodX6D9AaO2+zXSjtPwA5uqC3ahV8oeKMIEWylvFR
	else:
		FFVM3CWSntmDq4,N7QnmSMfTj4,zXSjtPwA5uqC3ahV8oeKMIEWylvFR = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
		A3sitxjc2EyLhbFWVdg5UXTra = tW8xaRsY0I25Sruv3wog4zJqO+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ࡞ࡱࡠࡳ࠭ဿ")+Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY
		JduW815QOYTm0PibE = tW8xaRsY0I25Sruv3wog4zJqO+EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࡟ࡲࡡࡴࠧ၀")+Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY
		wSzsmCD03pTyOBncR5LiojN = Iywz1Ts4RCtnBMLmPKl2c9fGEvJdhY
	vv1spWzSBMa9q = g7yJo2LVuqx1trPe(u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧ၁")+ixrPWKeFMnqJyVodX6D9AaO2
	YSZipFIzTtbfOmAn6hqVosklvJK4C = Bf6huHAGQTkZJYpL()
	PGpFbADydKwn = []
	w8YsNWfQ5gFluRvOmSd4Cb96H = YSZipFIzTtbfOmAn6hqVosklvJK4C[WsklGNp2CYzVQUag(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ၂")]
	nEDNFe2fzVckGYl4Z9xXSAWKpa1 = Iwj75bLuUMkrdDWc20m3OXsNFPefY(ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk)
	if EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ၃") in list(YSZipFIzTtbfOmAn6hqVosklvJK4C.keys()):
		for ZNzUSeG8bV,Fo9bZaWDkIxwe2OTHCtS05KrlAi43v,gRlYBw0rInFOVau in w8YsNWfQ5gFluRvOmSd4Cb96H:
			PGpFbADydKwn = max(PGpFbADydKwn,Fo9bZaWDkIxwe2OTHCtS05KrlAi43v)
		if nEDNFe2fzVckGYl4Z9xXSAWKpa1<PGpFbADydKwn:
			jCkV6rcG1ahI = ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ၄")
			B69G5sUjmDJelfod481KPAyHwc = rAdiM2DVzBuxjPvYFTQs(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭၅"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ၆"),XCYALgFs2O3hZdpHrlMmB(u"ࠩอัิ๐หࠨ၇"),MzgKWUQ4V5H(u"ࠪาึ๎ฬࠨ၈"),vv1spWzSBMa9q+jCkV6rcG1ahI,A3sitxjc2EyLhbFWVdg5UXTra)
			if B69G5sUjmDJelfod481KPAyHwc==pwxH3oREFm5v98BCZ1QVtzMJOc:
				import rrnsP3eh5Q
				rrnsP3eh5Q.hFGk9YqAuCsE(YOHXqtbQTBfKerIZ)
				sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
			elif B69G5sUjmDJelfod481KPAyHwc==RXnhpCUk4M1TvgJE: sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	IGBkXLWgwm = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,ESXZrtnCfcDJGo01vFg(u"ࠫࡱ࡯ࡳࡵࠩ၉"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ၊"),g7yJo2LVuqx1trPe(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ။"))
	if not IGBkXLWgwm: IGBkXLWgwm = []
	JduW815QOYTm0PibE = JduW815QOYTm0PibE.replace(ixrPWKeFMnqJyVodX6D9AaO2,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࡝࡞ࡱࠫ၌")).replace(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨ࡝ࡕࡘࡑࡣࠧ၍"),Vk54F7GcROfCy6HunEI).replace(d761ZWXHEvliYN45RzLP2,Vk54F7GcROfCy6HunEI).replace(ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI)
	wSzsmCD03pTyOBncR5LiojN = wSzsmCD03pTyOBncR5LiojN.replace(ixrPWKeFMnqJyVodX6D9AaO2,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࡟ࡠࡳ࠭၎")).replace(SSBkx0WbN1asnDCQV6tIj(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ၏"),Vk54F7GcROfCy6HunEI).replace(d761ZWXHEvliYN45RzLP2,Vk54F7GcROfCy6HunEI).replace(ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI)
	jjukXs4YHZR7Q = ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk+MpJ8GOKoic(u"ࠫ࠿ࡀࠧၐ")+wSzsmCD03pTyOBncR5LiojN
	if jjukXs4YHZR7Q in IGBkXLWgwm:
		jCkV6rcG1ahI = MpJ8GOKoic(u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪၑ")
		GHdYDixegkm9PJMN(wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡲࡪࡩ࡫ࡸࠬၒ"),Vk54F7GcROfCy6HunEI,vv1spWzSBMa9q+jCkV6rcG1ahI,A3sitxjc2EyLhbFWVdg5UXTra)
		return
	QjEkVCO3PG = str(gs15xoifvOt).split(V2RQwM8XjlrK(u"ࠧ࠯ࠩၓ"))[ufmXvxgoHGDwZtjsLkR05i]
	N39NCXDAaVnx = h9zFQKnsNL.SITESURLS[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨၔ")][HOxJyt7l8osNeCjZFMQGi4Sr(u"࠼ᐊ")]
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,MpJ8GOKoic(u"ࠩࡓࡓࡘ࡚ࠧၕ"),N39NCXDAaVnx,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫၖ"),eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
	ijr1mxMqBO04Ds5 = RSuYINdeamsK0t.findall(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫၗ"),UwghkPtqZiWTvsMLrl5dc0nuOAQ,RSuYINdeamsK0t.DOTALL)
	for ruwHDvhci1YXA,PlgOiBhoTaWjHNDAqQ8,esIJ25kwBGXMtP08NCbx19o,I8fZBKLoWXSR5qbA0MG in ijr1mxMqBO04Ds5:
		ruwHDvhci1YXA = ruwHDvhci1YXA.split(V2RQwM8XjlrK(u"ࠬ࠱ࠧၘ"))
		esIJ25kwBGXMtP08NCbx19o = esIJ25kwBGXMtP08NCbx19o.split(ESXZrtnCfcDJGo01vFg(u"࠭ࠫࠨၙ"))
		I8fZBKLoWXSR5qbA0MG = I8fZBKLoWXSR5qbA0MG.split(cpHxZyU7vTtqmIw(u"ࠧࠬࠩၚ"))
		if uFt4KliraXEoVBR603WgGAI2wHy in ruwHDvhci1YXA and UzQpsgO6iuy2WP70RCSvjMn3VIqN==PlgOiBhoTaWjHNDAqQ8 and ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk in esIJ25kwBGXMtP08NCbx19o and QjEkVCO3PG in I8fZBKLoWXSR5qbA0MG:
			jCkV6rcG1ahI = wYTDlJC5vpOKynUEX3ge6W(u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭ၛ")
			W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡵ࡭࡬࡮ࡴࠨၜ"),YzowicIDTRusXZSU61(u"ࠪาึ๎ฬࠨၝ"),WCPwmyVsb62KRlo(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨၞ"),vv1spWzSBMa9q+jCkV6rcG1ahI,A3sitxjc2EyLhbFWVdg5UXTra)
			if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc: GHdYDixegkm9PJMN(eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၟ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jCkV6rcG1ahI)
			return
	jCkV6rcG1ahI = V2RQwM8XjlrK(u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭ၠ")
	AeKozZdVLvk4GHJ65YUatyFDRi = rAdiM2DVzBuxjPvYFTQs(QYSAUI5r46yil8cfaO(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ၡ"),QYSAUI5r46yil8cfaO(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬၢ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩอัิ๐หࠡฮีส๏࠭ၣ"),Nlyfx1HnzOWCovke5(u"ࠪฮาี๊ฬࠢส่อืๆศ็ฯࠫၤ"),vv1spWzSBMa9q+jCkV6rcG1ahI,A3sitxjc2EyLhbFWVdg5UXTra)
	if AeKozZdVLvk4GHJ65YUatyFDRi==pwxH3oREFm5v98BCZ1QVtzMJOc:
		YlDdnyUO3S1gArpu(eu1NswY9zkKC60I)
		qJAOp7HgfKeMQkDau(ESXZrtnCfcDJGo01vFg(u"๋ࠫาอหࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠢส่ัุฦ๋ࠩၥ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ๓ࡓࡶࡥࡦࡩࡸࡹࠧၦ"),Gb6kwVlSQ4MU=YzowicIDTRusXZSU61(u"࠷࠶࠲ᐋ"))
		sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	elif AeKozZdVLvk4GHJ65YUatyFDRi==RXnhpCUk4M1TvgJE:
		import rrnsP3eh5Q
		rrnsP3eh5Q.hFGk9YqAuCsE(YOHXqtbQTBfKerIZ)
		sRUPStCcaqYo4ru2E3wZyVd1HzfAL()
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(MpJ8GOKoic(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၧ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၨ"),wAU9jKvmTM0(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩၩ"))
	if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc: SePcIk2NxaEw9D47RyBoUYMLgCml6 = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬၪ")
	else:
		GHdYDixegkm9PJMN(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡧࡪࡴࡴࡦࡴࠪၫ"),Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၬ"),d761ZWXHEvliYN45RzLP2+eAMGzHRQVs2KyCwPXljYhB(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬၭ")+ZZoLlKyInXc08j2pTGJ+cpHxZyU7vTtqmIw(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩၮ"))
		return
	Qe6XMhzKmCuI1qfwDAtBJlE4scVd3 = JduW815QOYTm0PibE
	import rrnsP3eh5Q
	kNQM9jAU6TVlhezn14cKtBb = rrnsP3eh5Q.G5GEld8on2FIazkY(cpHxZyU7vTtqmIw(u"ࠧࡆࡴࡵࡳࡷࡹࠧၯ"),Qe6XMhzKmCuI1qfwDAtBJlE4scVd3,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨၰ"),SePcIk2NxaEw9D47RyBoUYMLgCml6)
	if kNQM9jAU6TVlhezn14cKtBb and SePcIk2NxaEw9D47RyBoUYMLgCml6:
		IGBkXLWgwm.append(jjukXs4YHZR7Q)
		FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,WCPwmyVsb62KRlo(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬၱ"),WCPwmyVsb62KRlo(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬၲ"),IGBkXLWgwm,piwNWcJEe9m)
	return
def gA8um7hDcKC0pL6wHXqj1yFW(MFWydLr2JXCuVlUgAw9ERH8Yoiep,filename=tayEeSpKRJIdC8g10):
	Gb6kwVlSQ4MU.sleep(BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠱࠰࠳࠶࠺ᐌ"))
	if PvwFsJK23NbU8XWAx: MFWydLr2JXCuVlUgAw9ERH8Yoiep = MFWydLr2JXCuVlUgAw9ERH8Yoiep.encode(AoCWwJHgUPKXI7u2lEzym)
	if not filename: Hqxr3RAiJEadvFZWObS = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫၳ")+str(Gb6kwVlSQ4MU.time())+QYSAUI5r46yil8cfaO(u"ࠬ࠴ࡤࡢࡶࠪၴ")
	else: Hqxr3RAiJEadvFZWObS = Nlyfx1HnzOWCovke5(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ၵ")+filename+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧ࠯ࡦࡤࡸࠬၶ")
	open(Hqxr3RAiJEadvFZWObS,wAU9jKvmTM0(u"ࠨࡹࡥࠫၷ")).write(MFWydLr2JXCuVlUgAw9ERH8Yoiep)
	return
def wDHvEzd4FOJ1tfBIWQxqur2(oX6deUmzM4yS0WfJg5pvxra):
	if oX6deUmzM4yS0WfJg5pvxra:
		Xt0iUuE28TYN = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,QYSAUI5r46yil8cfaO(u"ࠩ࡯࡭ࡸࡺࠧၸ"),XCYALgFs2O3hZdpHrlMmB(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ၹ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧၺ"))
		if Xt0iUuE28TYN: return Xt0iUuE28TYN
	N39NCXDAaVnx = h9zFQKnsNL.SITESURLS[QYSAUI5r46yil8cfaO(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬၻ")][BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠷ᐍ")]
	igk6DQGT2ychz38 = cqgy5Dz7GR012EIPwVLsQ9Bnjuar(eu1NswY9zkKC60I) if not oX6deUmzM4yS0WfJg5pvxra else h9zFQKnsNL.AV_CLIENT_IDS
	UrKfGLt0hSOQpT6wMV1oN = aEAZWIlr32Q5z1ufmRqUX6MFS98sP()
	T3lKRZcek4aHVNfXCho5SsGngIqB07 = UrKfGLt0hSOQpT6wMV1oN.split(MpJ8GOKoic(u"࠭ࠬࠨၼ"))[RXnhpCUk4M1TvgJE]
	UOkpQXmszJhbqFwoRHW2D9v7ajA4 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ၽ"))
	MOa3Ze1C6WQHjfXb4nAcYuSv = uDL3ZW6dsapwXEmG8()
	NQw0ays5GT = {ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡷࡶࡩࡷ࠭ၾ"):igk6DQGT2ychz38,jXWzIZcDva4ikEUfN(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪၿ"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫႀ"):T3lKRZcek4aHVNfXCho5SsGngIqB07,WCPwmyVsb62KRlo(u"ࠫ࡮ࡪࡳࠨႁ"):DWBRli3pT90(MOa3Ze1C6WQHjfXb4nAcYuSv)}
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡖࡏࡔࡖࠪႂ"),N39NCXDAaVnx,NQw0ays5GT,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫႃ"))
	Xt0iUuE28TYN = []
	if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
		Xt0iUuE28TYN = UwghkPtqZiWTvsMLrl5dc0nuOAQ.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧ࡝࡞ࡵࠫႄ"),ixrPWKeFMnqJyVodX6D9AaO2).replace(ESXZrtnCfcDJGo01vFg(u"ࠨ࡞࡟ࡲࠬႅ"),ixrPWKeFMnqJyVodX6D9AaO2).replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡟ࡶࡡࡴࠧႆ"),ixrPWKeFMnqJyVodX6D9AaO2).replace(gSiK7EQVNXClOUDZGs,ixrPWKeFMnqJyVodX6D9AaO2)
		Xt0iUuE28TYN = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ႇ"),Xt0iUuE28TYN,RSuYINdeamsK0t.DOTALL)
		if Xt0iUuE28TYN:
			Xt0iUuE28TYN = sorted(Xt0iUuE28TYN,reverse=eu1NswY9zkKC60I,key=lambda key: int(key[ufmXvxgoHGDwZtjsLkR05i]))
			zhKGRXd8jbiEOAcCJuIp5mL,igk6DQGT2ychz38,vy5uSAZOmWehispxjE1DLcl,TcjPsL1WbHfAtq,avBR5hpQq97e,euQMlv6PXcjI3mybnKsgtwBpHJ1 = Xt0iUuE28TYN[ufmXvxgoHGDwZtjsLkR05i]
			d4sSOYoyXWjebHUQvDp = euQMlv6PXcjI3mybnKsgtwBpHJ1 if oYqQF65i48Uhzmw3jkJPRGsZnV([pnkrd2S84FJfN73KuiCYv(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪႈ")])[ufmXvxgoHGDwZtjsLkR05i] else vy5uSAZOmWehispxjE1DLcl
			cad8TeSyMUYmfsEO0.setSetting(eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧႉ"),d4sSOYoyXWjebHUQvDp)
			FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,cpHxZyU7vTtqmIw(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩႊ"),jXWzIZcDva4ikEUfN(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪႋ"),Xt0iUuE28TYN,ddQIv6q9hTce1iA0nWSX5UuLaNb)
			cad8TeSyMUYmfsEO0.setSetting(ynxXU3gaiQ9GPCftr1q(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪႌ"),DWBRli3pT90(npbh5qZo1PBiNkj))
	return Xt0iUuE28TYN
def Gtl57mNQ9UOCBf2SyYv(zsld7YEq5LXNUnp,XTyqO1za4sbDlc2tJh=ufmXvxgoHGDwZtjsLkR05i,IjLFzcNeu0lqWZ3E2wmpHPG=ufmXvxgoHGDwZtjsLkR05i):
	if XTyqO1za4sbDlc2tJh and not IjLFzcNeu0lqWZ3E2wmpHPG: IjLFzcNeu0lqWZ3E2wmpHPG = len(zsld7YEq5LXNUnp)//XTyqO1za4sbDlc2tJh
	raLvEqiRTwk3,sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz,aR310exys7FgI2WvQ = [],-pwxH3oREFm5v98BCZ1QVtzMJOc,ufmXvxgoHGDwZtjsLkR05i
	for L39t14lv2dr7IYqxERZM in zsld7YEq5LXNUnp:
		if aR310exys7FgI2WvQ%IjLFzcNeu0lqWZ3E2wmpHPG==ufmXvxgoHGDwZtjsLkR05i:
			sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz += pwxH3oREFm5v98BCZ1QVtzMJOc
			raLvEqiRTwk3.append([])
		raLvEqiRTwk3[sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz].append(L39t14lv2dr7IYqxERZM)
		aR310exys7FgI2WvQ += pwxH3oREFm5v98BCZ1QVtzMJOc
	return raLvEqiRTwk3
def CBdjk1flsnxegTcKJZWyVGXIa(Hqxr3RAiJEadvFZWObS,MFWydLr2JXCuVlUgAw9ERH8Yoiep):
	NMGgy2Ojlwu1nVxK = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,Hqxr3RAiJEadvFZWObS)
	if pwxH3oREFm5v98BCZ1QVtzMJOc or WsklGNp2CYzVQUag(u"ࠩࡌࡔ࡙࡜࡟ࠨႍ") not in Hqxr3RAiJEadvFZWObS or l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡑ࠸࡛࡟ࠨႎ") not in Hqxr3RAiJEadvFZWObS: RRG6QsiOkKU0ChovTBY3qdf = str(MFWydLr2JXCuVlUgAw9ERH8Yoiep)
	else:
		raLvEqiRTwk3 = Gtl57mNQ9UOCBf2SyYv(MFWydLr2JXCuVlUgAw9ERH8Yoiep,V2RQwM8XjlrK(u"࠻ᐎ"))
		RRG6QsiOkKU0ChovTBY3qdf = Vk54F7GcROfCy6HunEI
		for xPdYCcLQqhZwlB in raLvEqiRTwk3:
			RRG6QsiOkKU0ChovTBY3qdf += str(xPdYCcLQqhZwlB)+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪႏ")
		RRG6QsiOkKU0ChovTBY3qdf = RRG6QsiOkKU0ChovTBY3qdf.strip(Nlyfx1HnzOWCovke5(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ႐"))
	TPj8UGdu1FfSb4Moe3BcC9s = z9XtyO3YTkUHfqwKoN02xB.compress(RRG6QsiOkKU0ChovTBY3qdf)
	open(NMGgy2Ojlwu1nVxK,g7yJo2LVuqx1trPe(u"࠭ࡷࡣࠩ႑")).write(TPj8UGdu1FfSb4Moe3BcC9s)
	return
def KKtFwVRQPJUT(zxrMZONCHy3b4aSnKVY5kt2,Hqxr3RAiJEadvFZWObS):
	if zxrMZONCHy3b4aSnKVY5kt2==ynxXU3gaiQ9GPCftr1q(u"ࠧࡥ࡫ࡦࡸࠬ႒"): MFWydLr2JXCuVlUgAw9ERH8Yoiep = {}
	elif zxrMZONCHy3b4aSnKVY5kt2==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡮࡬ࡷࡹ࠭႓"): MFWydLr2JXCuVlUgAw9ERH8Yoiep = []
	elif zxrMZONCHy3b4aSnKVY5kt2==MzgKWUQ4V5H(u"ࠩࡶࡸࡷ࠭႔"): MFWydLr2JXCuVlUgAw9ERH8Yoiep = Vk54F7GcROfCy6HunEI
	elif zxrMZONCHy3b4aSnKVY5kt2==MzgKWUQ4V5H(u"ࠪ࡭ࡳࡺࠧ႕"): MFWydLr2JXCuVlUgAw9ERH8Yoiep = ufmXvxgoHGDwZtjsLkR05i
	else: MFWydLr2JXCuVlUgAw9ERH8Yoiep = tayEeSpKRJIdC8g10
	NMGgy2Ojlwu1nVxK = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,Hqxr3RAiJEadvFZWObS)
	TPj8UGdu1FfSb4Moe3BcC9s = open(NMGgy2Ojlwu1nVxK,WXuJd8nz2spo146t(u"ࠫࡷࡨࠧ႖")).read()
	RRG6QsiOkKU0ChovTBY3qdf = z9XtyO3YTkUHfqwKoN02xB.decompress(TPj8UGdu1FfSb4Moe3BcC9s)
	if g7yJo2LVuqx1trPe(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ႗") not in RRG6QsiOkKU0ChovTBY3qdf: MFWydLr2JXCuVlUgAw9ERH8Yoiep = eval(RRG6QsiOkKU0ChovTBY3qdf)
	else:
		raLvEqiRTwk3 = RRG6QsiOkKU0ChovTBY3qdf.split(NNjUsZzEcFOAoKry2CDMgb1(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ႘"))
		del RRG6QsiOkKU0ChovTBY3qdf
		MFWydLr2JXCuVlUgAw9ERH8Yoiep = []
		v0a9DAZipFWkE4fLlqKBwSxIU = txAiQRKT0Dyl6VMq4hGeUmf()
		zhKGRXd8jbiEOAcCJuIp5mL = ufmXvxgoHGDwZtjsLkR05i
		for xPdYCcLQqhZwlB in raLvEqiRTwk3:
			v0a9DAZipFWkE4fLlqKBwSxIU.bPA1DJrUHXmqZCQFeB(str(zhKGRXd8jbiEOAcCJuIp5mL),eval,xPdYCcLQqhZwlB)
			zhKGRXd8jbiEOAcCJuIp5mL += pwxH3oREFm5v98BCZ1QVtzMJOc
		del raLvEqiRTwk3
		v0a9DAZipFWkE4fLlqKBwSxIU.rrph2BLDgHdlG()
		v0a9DAZipFWkE4fLlqKBwSxIU.PkA0Cf3L2c9jKRZeHXwON()
		BJKHaXd9NEQqw4bW = list(v0a9DAZipFWkE4fLlqKBwSxIU.resultsDICT.keys())
		Ssa9M1JO3cAIh = sorted(BJKHaXd9NEQqw4bW,reverse=eu1NswY9zkKC60I,key=lambda key: int(key))
		for zhKGRXd8jbiEOAcCJuIp5mL in Ssa9M1JO3cAIh:
			MFWydLr2JXCuVlUgAw9ERH8Yoiep += v0a9DAZipFWkE4fLlqKBwSxIU.resultsDICT[zhKGRXd8jbiEOAcCJuIp5mL]
	return MFWydLr2JXCuVlUgAw9ERH8Yoiep
def n0e2oGE679sA1bQc(DDXHAicJtj6):
	NJBh4itklrFbn7dopWH3XqVZx = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡢࡦࡧࡳࡳࡹࠧ႙"),DDXHAicJtj6,jXWzIZcDva4ikEUfN(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫႚ"))
	try: ZZPEbqdI5nxVJ1BaCjMkrFve3h = open(NJBh4itklrFbn7dopWH3XqVZx,V2RQwM8XjlrK(u"ࠩࡵࡦࠬႛ")).read()
	except:
		ov0hHKM47RLsWVn = CR3aLOVKSIme5XFoYi6M.path.join(ruMn0Ry9WJd8I1L,g7yJo2LVuqx1trPe(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪႜ"),DDXHAicJtj6,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧႝ"))
		try: ZZPEbqdI5nxVJ1BaCjMkrFve3h = open(ov0hHKM47RLsWVn,XCYALgFs2O3hZdpHrlMmB(u"ࠬࡸࡢࠨ႞")).read()
		except: return Vk54F7GcROfCy6HunEI,[]
	if PvwFsJK23NbU8XWAx: ZZPEbqdI5nxVJ1BaCjMkrFve3h = ZZPEbqdI5nxVJ1BaCjMkrFve3h.decode(AoCWwJHgUPKXI7u2lEzym)
	PFRIbzasmEZ7Wq = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪ႟"),ZZPEbqdI5nxVJ1BaCjMkrFve3h,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	if not PFRIbzasmEZ7Wq: return Vk54F7GcROfCy6HunEI,[]
	HHOAwDBjaV84QChkv5,WoC09Qm86Z7Ns2 = PFRIbzasmEZ7Wq[ufmXvxgoHGDwZtjsLkR05i],Iwj75bLuUMkrdDWc20m3OXsNFPefY(PFRIbzasmEZ7Wq[ufmXvxgoHGDwZtjsLkR05i])
	return HHOAwDBjaV84QChkv5,WoC09Qm86Z7Ns2
def Bf6huHAGQTkZJYpL():
	tl2NuJqPF3ihcO4E5SvM8 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡥ࡫ࡦࡸࠬႠ"),XCYALgFs2O3hZdpHrlMmB(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫႡ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪႢ"))
	if tl2NuJqPF3ihcO4E5SvM8: return tl2NuJqPF3ihcO4E5SvM8
	YSZipFIzTtbfOmAn6hqVosklvJK4C,tl2NuJqPF3ihcO4E5SvM8 = {},{}
	LzpvmNuXZQDYr = [h9zFQKnsNL.SITESURLS[ynxXU3gaiQ9GPCftr1q(u"ࠪࡖࡊࡖࡏࡔࠩႣ")][ufmXvxgoHGDwZtjsLkR05i]]
	if gs15xoifvOt>BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠵࠼࠴࠹࠺ᐏ"): LzpvmNuXZQDYr.append(h9zFQKnsNL.SITESURLS[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡗࡋࡐࡐࡕࠪႤ")][pwxH3oREFm5v98BCZ1QVtzMJOc])
	if PvwFsJK23NbU8XWAx: LzpvmNuXZQDYr.append(h9zFQKnsNL.SITESURLS[WCPwmyVsb62KRlo(u"ࠬࡘࡅࡑࡑࡖࠫႥ")][RXnhpCUk4M1TvgJE])
	for a1aXGZ6QvCjx8 in LzpvmNuXZQDYr:
		s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,V2RQwM8XjlrK(u"࠭ࡇࡆࡖࠪႦ"),a1aXGZ6QvCjx8,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫႧ"))
		if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
			UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
			vFMJKpc2BRImi1jtC3yqVXdze = a1aXGZ6QvCjx8.rsplit(XCYALgFs2O3hZdpHrlMmB(u"ࠨ࠱ࠪႨ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶ᐐ"))[ufmXvxgoHGDwZtjsLkR05i]
			jGux5tv3wsTHgO0n9z6BaXKJ = RSuYINdeamsK0t.findall(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႩ"),UwghkPtqZiWTvsMLrl5dc0nuOAQ,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
			for DDXHAicJtj6,H9PGzZkh1gBK4867 in jGux5tv3wsTHgO0n9z6BaXKJ:
				ah7NlPVDiMB5t0Zs = vFMJKpc2BRImi1jtC3yqVXdze+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࠳ࠬႪ")+DDXHAicJtj6+XCYALgFs2O3hZdpHrlMmB(u"ࠫ࠴࠭Ⴋ")+DDXHAicJtj6+MzgKWUQ4V5H(u"ࠬ࠳ࠧႬ")+H9PGzZkh1gBK4867+WXuJd8nz2spo146t(u"࠭࠮ࡻ࡫ࡳࠫႭ")
				if DDXHAicJtj6 not in list(YSZipFIzTtbfOmAn6hqVosklvJK4C.keys()):
					YSZipFIzTtbfOmAn6hqVosklvJK4C[DDXHAicJtj6] = []
					tl2NuJqPF3ihcO4E5SvM8[DDXHAicJtj6] = []
				nTaj8sQ6MCFWby0D = Iwj75bLuUMkrdDWc20m3OXsNFPefY(H9PGzZkh1gBK4867)
				YSZipFIzTtbfOmAn6hqVosklvJK4C[DDXHAicJtj6].append((H9PGzZkh1gBK4867,nTaj8sQ6MCFWby0D,ah7NlPVDiMB5t0Zs))
	for DDXHAicJtj6 in list(YSZipFIzTtbfOmAn6hqVosklvJK4C.keys()):
		tl2NuJqPF3ihcO4E5SvM8[DDXHAicJtj6] = sorted(YSZipFIzTtbfOmAn6hqVosklvJK4C[DDXHAicJtj6],reverse=YOHXqtbQTBfKerIZ,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc])
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,WXuJd8nz2spo146t(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪႮ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩႯ"),tl2NuJqPF3ihcO4E5SvM8,ddQIv6q9hTce1iA0nWSX5UuLaNb)
	return tl2NuJqPF3ihcO4E5SvM8
def Iwj75bLuUMkrdDWc20m3OXsNFPefY(H9PGzZkh1gBK4867):
	nTaj8sQ6MCFWby0D = []
	OnJEH59ugjw6 = H9PGzZkh1gBK4867.split(cpHxZyU7vTtqmIw(u"ࠩ࠱ࠫႰ"))
	for CAtK3v2EFTXUOIZ4pl in OnJEH59ugjw6:
		eq7BWI1NM8xfYDbwUGv2LS = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧႱ"),CAtK3v2EFTXUOIZ4pl,RSuYINdeamsK0t.DOTALL)
		zAYwk8ud73tK6nF0HPfDjhe = []
		for JJW0Q6ILzUqmEAot7scb9HlNPVDTG8 in eq7BWI1NM8xfYDbwUGv2LS:
			if JJW0Q6ILzUqmEAot7scb9HlNPVDTG8.isdigit(): JJW0Q6ILzUqmEAot7scb9HlNPVDTG8 = int(JJW0Q6ILzUqmEAot7scb9HlNPVDTG8)
			zAYwk8ud73tK6nF0HPfDjhe.append(JJW0Q6ILzUqmEAot7scb9HlNPVDTG8)
		nTaj8sQ6MCFWby0D.append(zAYwk8ud73tK6nF0HPfDjhe)
	return nTaj8sQ6MCFWby0D
def bNdJaP0vfAUg3cRh6rye1t97K(nTaj8sQ6MCFWby0D):
	H9PGzZkh1gBK4867 = Vk54F7GcROfCy6HunEI
	for CAtK3v2EFTXUOIZ4pl in nTaj8sQ6MCFWby0D:
		for JJW0Q6ILzUqmEAot7scb9HlNPVDTG8 in CAtK3v2EFTXUOIZ4pl: H9PGzZkh1gBK4867 += str(JJW0Q6ILzUqmEAot7scb9HlNPVDTG8)
		H9PGzZkh1gBK4867 += HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࠳࠭Ⴒ")
	H9PGzZkh1gBK4867 = H9PGzZkh1gBK4867.strip(V2RQwM8XjlrK(u"ࠬ࠴ࠧႳ"))
	return H9PGzZkh1gBK4867
def aaSgYM8cEP(XE2yMYnvcBa):
	rUWTIdPJlh4uNp2w = {}
	YSZipFIzTtbfOmAn6hqVosklvJK4C = Bf6huHAGQTkZJYpL()
	vuKBI4MSFJYDWkzmf7a28gbNV5hXy = DUMs2h7lprZGTiAmLbu(XE2yMYnvcBa)
	for DDXHAicJtj6 in XE2yMYnvcBa:
		if DDXHAicJtj6 not in list(YSZipFIzTtbfOmAn6hqVosklvJK4C.keys()): continue
		tl2NuJqPF3ihcO4E5SvM8 = YSZipFIzTtbfOmAn6hqVosklvJK4C[DDXHAicJtj6]
		xVe01qnbcRyt8HDmBNMYOTk,AkRj4p61rcSeGaHxYCKVDvy07,ss2Ll5P6FDkB4x9VTf0RQvY3Z = tl2NuJqPF3ihcO4E5SvM8[ufmXvxgoHGDwZtjsLkR05i]
		OpJZ0jhHns85YrklBfL1,TDoK2XygjCO5VENYcLm = n0e2oGE679sA1bQc(DDXHAicJtj6)
		rrQkF1JVMuDnp9Ul7mz8esb2g,Xj93q8A5svT = vuKBI4MSFJYDWkzmf7a28gbNV5hXy[DDXHAicJtj6]
		wBiKzFye8nb4QW3tu672vVlUHdZo = AkRj4p61rcSeGaHxYCKVDvy07>TDoK2XygjCO5VENYcLm and rrQkF1JVMuDnp9Ul7mz8esb2g
		gTAWC1nqJj2h = YOHXqtbQTBfKerIZ
		if not rrQkF1JVMuDnp9Ul7mz8esb2g: dy5zuh214YvptWw6UmlsTQ = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧႴ")
		elif not Xj93q8A5svT: dy5zuh214YvptWw6UmlsTQ = g7yJo2LVuqx1trPe(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩႵ")
		elif wBiKzFye8nb4QW3tu672vVlUHdZo: dy5zuh214YvptWw6UmlsTQ = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡱ࡯ࡨࠬႶ")
		else:
			dy5zuh214YvptWw6UmlsTQ = ESXZrtnCfcDJGo01vFg(u"ࠩࡪࡳࡴࡪࠧႷ")
			gTAWC1nqJj2h = eu1NswY9zkKC60I
		rUWTIdPJlh4uNp2w[DDXHAicJtj6] = gTAWC1nqJj2h,OpJZ0jhHns85YrklBfL1,TDoK2XygjCO5VENYcLm,xVe01qnbcRyt8HDmBNMYOTk,AkRj4p61rcSeGaHxYCKVDvy07,dy5zuh214YvptWw6UmlsTQ,ss2Ll5P6FDkB4x9VTf0RQvY3Z
	return rUWTIdPJlh4uNp2w
def yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,ZCzUIjeyNGXofksSB,bbq3jLEhOQaJYmvHXGtSypx2=Vk54F7GcROfCy6HunEI,N7QnmSMfTj4=Vk54F7GcROfCy6HunEI,ruwHDvhci1YXA=Vk54F7GcROfCy6HunEI):
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: uuyUxZ8tM1.update(ZCzUIjeyNGXofksSB,bbq3jLEhOQaJYmvHXGtSypx2,N7QnmSMfTj4,ruwHDvhci1YXA)
	else: uuyUxZ8tM1.update(ZCzUIjeyNGXofksSB,bbq3jLEhOQaJYmvHXGtSypx2+ixrPWKeFMnqJyVodX6D9AaO2+N7QnmSMfTj4+ixrPWKeFMnqJyVodX6D9AaO2+ruwHDvhci1YXA)
	return
def xukS7TA9pKl(tcymZ7D4BiLadxl58):
	def QTzUqYile59CPysNMfbLv7a(BeH7a4qCL3yE1I,DhMFC4k3KQXdf6yv,Pqy4N71zUBW0lrAJb5g63sQcLZERv=SSBkx0WbN1asnDCQV6tIj(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥႸ")):
		return ((BeH7a4qCL3yE1I == ufmXvxgoHGDwZtjsLkR05i) and Pqy4N71zUBW0lrAJb5g63sQcLZERv[ufmXvxgoHGDwZtjsLkR05i]) or (QTzUqYile59CPysNMfbLv7a(BeH7a4qCL3yE1I // DhMFC4k3KQXdf6yv, DhMFC4k3KQXdf6yv, Pqy4N71zUBW0lrAJb5g63sQcLZERv).lstrip(Pqy4N71zUBW0lrAJb5g63sQcLZERv[ufmXvxgoHGDwZtjsLkR05i]) + Pqy4N71zUBW0lrAJb5g63sQcLZERv[BeH7a4qCL3yE1I % DhMFC4k3KQXdf6yv])
	def PKDYUHycsf1vox5CQR(Se6R39aLpDif1UmwbMHWuP8, BOGRYiPs2pANX4519WbJw, LbJiNWUPRoH90sVpk4m, lTEi4qICQP8n, iDpmL4X08Wvx91qyItSdGfOZ=tayEeSpKRJIdC8g10, MNUoVvL4Re=tayEeSpKRJIdC8g10, NMlDoHOE0Kstrdab=tayEeSpKRJIdC8g10):
		while (LbJiNWUPRoH90sVpk4m):
			LbJiNWUPRoH90sVpk4m-=BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠷ᐑ")
			if (lTEi4qICQP8n[LbJiNWUPRoH90sVpk4m]): Se6R39aLpDif1UmwbMHWuP8 = RSuYINdeamsK0t.sub(pnkrd2S84FJfN73KuiCYv(u"ࠦࡡࡢࡢࠣႹ") + QTzUqYile59CPysNMfbLv7a(LbJiNWUPRoH90sVpk4m, BOGRYiPs2pANX4519WbJw) + wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡢ࡜ࡣࠤႺ"),  lTEi4qICQP8n[LbJiNWUPRoH90sVpk4m], Se6R39aLpDif1UmwbMHWuP8)
		return Se6R39aLpDif1UmwbMHWuP8
	tcymZ7D4BiLadxl58 = tcymZ7D4BiLadxl58.split(WsklGNp2CYzVQUag(u"࠭ࡽࠩࠩႻ"))[pwxH3oREFm5v98BCZ1QVtzMJOc]
	tcymZ7D4BiLadxl58 = tcymZ7D4BiLadxl58.rsplit(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡴࡲ࡯࡭ࡹ࠭Ⴜ"))[ufmXvxgoHGDwZtjsLkR05i]+QYSAUI5r46yil8cfaO(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨႽ")
	xjofhAUmXqrE1 = eval(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪႾ")+tcymZ7D4BiLadxl58,{cpHxZyU7vTtqmIw(u"ࠪࡦࡦࡹࡥࡏࠩႿ"):QTzUqYile59CPysNMfbLv7a,WCPwmyVsb62KRlo(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫჀ"):PKDYUHycsf1vox5CQR})
	return xjofhAUmXqrE1
def nnAikQJ3CUMWVhfatgT(code):
	_YsvcPQe5ShR29C0GTiz=wAU9jKvmTM0(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞࠰࠵ࠢჁ")
	def jPpOLBcKrh4i7IE(MNUoVvL4Re,iDpmL4X08Wvx91qyItSdGfOZ,yrDKTJL0tldS2e6bQNRUI5P8mnqo):
		pyk4w5PvIuNY8l = list(_YsvcPQe5ShR29C0GTiz)
		rYB7DLC8owyjp0Alfxmu6TVaGbh = pyk4w5PvIuNY8l[YzowicIDTRusXZSU61(u"࠰ᐒ"):iDpmL4X08Wvx91qyItSdGfOZ]
		zHq7nBWJTNyY1I3aLco4AR = pyk4w5PvIuNY8l[SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠱ᐓ"):yrDKTJL0tldS2e6bQNRUI5P8mnqo]
		MNUoVvL4Re = list(MNUoVvL4Re)[::-WCPwmyVsb62KRlo(u"࠳ᐔ")]
		izP6de3EkWvy5rDxQAN = Nlyfx1HnzOWCovke5(u"࠳ᐕ")
		for LbJiNWUPRoH90sVpk4m,DhMFC4k3KQXdf6yv in enumerate(MNUoVvL4Re):
			if DhMFC4k3KQXdf6yv in rYB7DLC8owyjp0Alfxmu6TVaGbh: izP6de3EkWvy5rDxQAN = izP6de3EkWvy5rDxQAN + rYB7DLC8owyjp0Alfxmu6TVaGbh.index(DhMFC4k3KQXdf6yv)*iDpmL4X08Wvx91qyItSdGfOZ**LbJiNWUPRoH90sVpk4m
		lTEi4qICQP8n = WsklGNp2CYzVQUag(u"ࠨࠢჂ")
		while izP6de3EkWvy5rDxQAN > NNjUsZzEcFOAoKry2CDMgb1(u"࠴ᐖ"):
			lTEi4qICQP8n = zHq7nBWJTNyY1I3aLco4AR[izP6de3EkWvy5rDxQAN%yrDKTJL0tldS2e6bQNRUI5P8mnqo] + lTEi4qICQP8n
			izP6de3EkWvy5rDxQAN = (izP6de3EkWvy5rDxQAN - (izP6de3EkWvy5rDxQAN%yrDKTJL0tldS2e6bQNRUI5P8mnqo))//yrDKTJL0tldS2e6bQNRUI5P8mnqo
		return int(lTEi4qICQP8n) or ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠵ᐗ")
	def g2gailNxRVOoEkfTMsqYtjcr5QJ(rYB7DLC8owyjp0Alfxmu6TVaGbh,u,ZQd1VT5ywx,Rhp3txWZQsPbNed4m9XSFOJHVy0wM,iDpmL4X08Wvx91qyItSdGfOZ,NMlDoHOE0Kstrdab):
		NMlDoHOE0Kstrdab = ynxXU3gaiQ9GPCftr1q(u"ࠢࠣჃ");
		zHq7nBWJTNyY1I3aLco4AR = YzowicIDTRusXZSU61(u"࠶ᐘ")
		while zHq7nBWJTNyY1I3aLco4AR < len(rYB7DLC8owyjp0Alfxmu6TVaGbh):
			izP6de3EkWvy5rDxQAN = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠰ᐙ")
			Rq0Cpmt9bSzO = Nlyfx1HnzOWCovke5(u"ࠣࠤჄ")
			while rYB7DLC8owyjp0Alfxmu6TVaGbh[zHq7nBWJTNyY1I3aLco4AR] is not ZQd1VT5ywx[iDpmL4X08Wvx91qyItSdGfOZ]:
				Rq0Cpmt9bSzO = Vk54F7GcROfCy6HunEI.join([Rq0Cpmt9bSzO,rYB7DLC8owyjp0Alfxmu6TVaGbh[zHq7nBWJTNyY1I3aLco4AR]])
				zHq7nBWJTNyY1I3aLco4AR = zHq7nBWJTNyY1I3aLco4AR + FGLEMi21Bfn(u"࠲ᐚ")
			while izP6de3EkWvy5rDxQAN < len(ZQd1VT5ywx):
				Rq0Cpmt9bSzO = Rq0Cpmt9bSzO.replace(ZQd1VT5ywx[izP6de3EkWvy5rDxQAN],str(izP6de3EkWvy5rDxQAN))
				izP6de3EkWvy5rDxQAN = izP6de3EkWvy5rDxQAN + FGLEMi21Bfn(u"࠳ᐛ")
			NMlDoHOE0Kstrdab = Vk54F7GcROfCy6HunEI.join([NMlDoHOE0Kstrdab,Vk54F7GcROfCy6HunEI.join(map(chr, [jPpOLBcKrh4i7IE(Rq0Cpmt9bSzO,iDpmL4X08Wvx91qyItSdGfOZ,MzgKWUQ4V5H(u"࠴࠴ᐜ")) - Rhp3txWZQsPbNed4m9XSFOJHVy0wM]))])
			zHq7nBWJTNyY1I3aLco4AR = zHq7nBWJTNyY1I3aLco4AR + cpHxZyU7vTtqmIw(u"࠵ᐝ")
		return NMlDoHOE0Kstrdab
	code = code.replace(XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡟ࡲࠬჅ"),Vk54F7GcROfCy6HunEI).replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡠࡷ࠭჆"),Vk54F7GcROfCy6HunEI)
	pH7QtPNBL0DndWJ = RSuYINdeamsK0t.findall(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡡࢃ࡜ࠩࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮ࡢࠩ࡝ࠫࠪჇ"),code,RSuYINdeamsK0t.DOTALL)
	if pH7QtPNBL0DndWJ:
		pH7QtPNBL0DndWJ = list(pH7QtPNBL0DndWJ[ynxXU3gaiQ9GPCftr1q(u"࠵ᐞ")])
		for gl0SXqYIe9Qd8TJW,code in enumerate(pH7QtPNBL0DndWJ):
			if code.isdigit(): pH7QtPNBL0DndWJ[gl0SXqYIe9Qd8TJW] = int(code)
			else: pH7QtPNBL0DndWJ[gl0SXqYIe9Qd8TJW] = code.replace(QYSAUI5r46yil8cfaO(u"ࠬࡢࠢࠨ჈"),Vk54F7GcROfCy6HunEI)
		mYPkVG0Kx8atDS2s6vTHE4U5JZy = g2gailNxRVOoEkfTMsqYtjcr5QJ(*pH7QtPNBL0DndWJ)
		return mYPkVG0Kx8atDS2s6vTHE4U5JZy
	return Vk54F7GcROfCy6HunEI
def azf5rxyMwAGeSD3TUuR(N39NCXDAaVnx,fpAsxZkbla8XLiyUT04r3d=Vk54F7GcROfCy6HunEI):
	if fpAsxZkbla8XLiyUT04r3d==cpHxZyU7vTtqmIw(u"࠭࡬ࡰࡹࡨࡶࠬ჉"): N39NCXDAaVnx = RSuYINdeamsK0t.sub(ynxXU3gaiQ9GPCftr1q(u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧ჊"),lambda bbLZGsCJnMPo5N067vAceYiuyQO: bbLZGsCJnMPo5N067vAceYiuyQO.group(ufmXvxgoHGDwZtjsLkR05i).lower(),N39NCXDAaVnx)
	elif fpAsxZkbla8XLiyUT04r3d==ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡷࡳࡴࡪࡸࠧ჋"): N39NCXDAaVnx = RSuYINdeamsK0t.sub(MpJ8GOKoic(u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩ჌"),lambda bbLZGsCJnMPo5N067vAceYiuyQO: bbLZGsCJnMPo5N067vAceYiuyQO.group(ufmXvxgoHGDwZtjsLkR05i).upper(),N39NCXDAaVnx)
	return N39NCXDAaVnx
def DUMs2h7lprZGTiAmLbu(XE2yMYnvcBa):
	wRBPZghkTCD7U3IJSqVGWelfF,fEqBjuYV2n7 = eu1NswY9zkKC60I,eu1NswY9zkKC60I
	bIsz45VatWSMRmkyph63Zg1lf = U4xLTJsWfkMbNpicjY9SVOwAthED.connect(qqcpbNo3gTyUdmsS10MGuKa)
	bIsz45VatWSMRmkyph63Zg1lf.text_factory = str
	C9frwiYhylNH2n14uDaG5 = bIsz45VatWSMRmkyph63Zg1lf.cursor()
	if len(XE2yMYnvcBa)==pwxH3oREFm5v98BCZ1QVtzMJOc: aPBuFSTnYIHhtKi3pG = pnkrd2S84FJfN73KuiCYv(u"ࠪࠬࠧ࠭Ⴭ")+XE2yMYnvcBa[ufmXvxgoHGDwZtjsLkR05i]+wAU9jKvmTM0(u"ࠫࠧ࠯ࠧ჎")
	else: aPBuFSTnYIHhtKi3pG = str(tuple(XE2yMYnvcBa))
	C9frwiYhylNH2n14uDaG5.execute(MpJ8GOKoic(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ჏")+aPBuFSTnYIHhtKi3pG+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠠ࠼ࠩა"))
	V4XMdxhtyri6l18RLjG0voIge = C9frwiYhylNH2n14uDaG5.fetchall()
	bIsz45VatWSMRmkyph63Zg1lf.close()
	vuKBI4MSFJYDWkzmf7a28gbNV5hXy = {}
	for DDXHAicJtj6 in XE2yMYnvcBa: vuKBI4MSFJYDWkzmf7a28gbNV5hXy[DDXHAicJtj6] = (eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	for DDXHAicJtj6,fEqBjuYV2n7 in V4XMdxhtyri6l18RLjG0voIge:
		wRBPZghkTCD7U3IJSqVGWelfF = YOHXqtbQTBfKerIZ
		fEqBjuYV2n7 = fEqBjuYV2n7==pwxH3oREFm5v98BCZ1QVtzMJOc
		vuKBI4MSFJYDWkzmf7a28gbNV5hXy[DDXHAicJtj6] = (wRBPZghkTCD7U3IJSqVGWelfF,fEqBjuYV2n7)
	return vuKBI4MSFJYDWkzmf7a28gbNV5hXy
def b8phWg7UYlxwmD5ePBJ(l8IhwvESacb36y0fKG4noVLzDgu):
	w8YsNWfQ5gFluRvOmSd4Cb96H = Vk54F7GcROfCy6HunEI
	if CR3aLOVKSIme5XFoYi6M.path.exists(l8IhwvESacb36y0fKG4noVLzDgu):
		IOmoiweTvpJuaZz = open(l8IhwvESacb36y0fKG4noVLzDgu,MzgKWUQ4V5H(u"ࠧࡳࡤࠪბ")).read()
		if PvwFsJK23NbU8XWAx: IOmoiweTvpJuaZz = IOmoiweTvpJuaZz.decode(AoCWwJHgUPKXI7u2lEzym)
		wIDCKLkxvJdhQV730HzXponPiqu8 = Bw6jaUcFxlqdDT8bC(SSBkx0WbN1asnDCQV6tIj(u"ࠨࡦ࡬ࡧࡹ࠭გ"),IOmoiweTvpJuaZz)
		if wIDCKLkxvJdhQV730HzXponPiqu8:
			w8YsNWfQ5gFluRvOmSd4Cb96H = {}
			for FFjms1g35EHqb4th in wIDCKLkxvJdhQV730HzXponPiqu8.keys():
				w8YsNWfQ5gFluRvOmSd4Cb96H[FFjms1g35EHqb4th] = []
				for OolFQyGBV95tKh6ZCTNL0XEJS in wIDCKLkxvJdhQV730HzXponPiqu8[FFjms1g35EHqb4th]:
					WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
					WypSQTO7504tHY = OolFQyGBV95tKh6ZCTNL0XEJS[ufmXvxgoHGDwZtjsLkR05i]
					HpzRx8a4nj = OolFQyGBV95tKh6ZCTNL0XEJS[pwxH3oREFm5v98BCZ1QVtzMJOc]
					HpzRx8a4nj = oqfzZIP1Qxu(HpzRx8a4nj)
					N39NCXDAaVnx = OolFQyGBV95tKh6ZCTNL0XEJS[RXnhpCUk4M1TvgJE]
					Fj9S5lYorenKWR2I30 = OolFQyGBV95tKh6ZCTNL0XEJS[wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
					ylKTDSkdQmUChwbX45ALeiu = OolFQyGBV95tKh6ZCTNL0XEJS[BZm7TqLPJfAVblDKsya85zFWXNMY]
					H4TFmtAe5rM8oY1lfPviVC = OolFQyGBV95tKh6ZCTNL0XEJS[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠻ᐟ")]
					if len(OolFQyGBV95tKh6ZCTNL0XEJS)>V2RQwM8XjlrK(u"࠶ᐠ"): RRG6QsiOkKU0ChovTBY3qdf = OolFQyGBV95tKh6ZCTNL0XEJS[V2RQwM8XjlrK(u"࠶ᐠ")]
					if len(OolFQyGBV95tKh6ZCTNL0XEJS)>EM6qpnCBYQGA9kbgDVLfrP(u"࠸ᐡ"): rF0ghTZEyQ = OolFQyGBV95tKh6ZCTNL0XEJS[EM6qpnCBYQGA9kbgDVLfrP(u"࠸ᐡ")]
					if len(OolFQyGBV95tKh6ZCTNL0XEJS)>Nlyfx1HnzOWCovke5(u"࠺ᐢ"): Xb17xtEphFigA8dReBrGH = OolFQyGBV95tKh6ZCTNL0XEJS[Nlyfx1HnzOWCovke5(u"࠺ᐢ")]
					if l8IhwvESacb36y0fKG4noVLzDgu==n28VC34lcrAhgiJtKXU7WqjTOw9: iyuMJkYWNKHPxRdE3QDa = WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH
					else: iyuMJkYWNKHPxRdE3QDa = WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH
					w8YsNWfQ5gFluRvOmSd4Cb96H[FFjms1g35EHqb4th].append(iyuMJkYWNKHPxRdE3QDa)
		z1LfE2uZlBi0evYjxcTR7XgrC = str(w8YsNWfQ5gFluRvOmSd4Cb96H)
		if PvwFsJK23NbU8XWAx: z1LfE2uZlBi0evYjxcTR7XgrC = z1LfE2uZlBi0evYjxcTR7XgrC.encode(AoCWwJHgUPKXI7u2lEzym)
		open(l8IhwvESacb36y0fKG4noVLzDgu,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡺࡦࠬდ")).write(z1LfE2uZlBi0evYjxcTR7XgrC)
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs):
	N4EIr3MoWP7k5w = PPmYnWkqTCfNH1u4yoRs.split(WsklGNp2CYzVQUag(u"ࠪ࠱ࠬე"),pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
	tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	if   N4EIr3MoWP7k5w==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡆࡎࡗࡂࡍࠪვ")		:	from INiR8Z5JHn			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡇࡋࡐࡃࡐࠫზ")		:	from cU2pfFhDjH			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==WCPwmyVsb62KRlo(u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨთ")	:	from JfhGnxkT0C		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==jXWzIZcDva4ikEUfN(u"ࠧࡂࡍ࡚ࡅࡒ࠭ი")		:	from KIO4XePNEd			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫკ")	:	from XwWBQtcRYI		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ynxXU3gaiQ9GPCftr1q(u"ࠩࡄࡐࡆࡘࡁࡃࠩლ")	:	from PXIDHZvyGh			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==QYSAUI5r46yil8cfaO(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬმ")	:	from BPa8QdH7Gk		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧნ")	: 	from Zs5zYvgNJD		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==V2RQwM8XjlrK(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧო")	:	from kDcMnFYsiw		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ynxXU3gaiQ9GPCftr1q(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧპ")	:	from fEX2mhPgTw		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==WCPwmyVsb62KRlo(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩჟ")	:	from aVC8mI9T7q		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭რ"):	from FC4DifMwRH	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MpJ8GOKoic(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫს")	:	from fsHGYLNI5R		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==FGLEMi21Bfn(u"ࠪࡅ࡞ࡒࡏࡍࠩტ")		:	from coOaNQelht			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡇࡕࡋࡓࡃࠪუ")		:	from eeJOLScAxm			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡈࡒࡔࡖࡈࡎࠬფ")	:	from oaTpRbNj8U			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MzgKWUQ4V5H(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧქ")	:	from OOzshLHt2J		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧღ")	:	from yywYoiXMmG			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==YzowicIDTRusXZSU61(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨყ")	:	from KpTdiYPncX			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫშ")	:	from Mis0W8Q4a7		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬჩ")	:	from KVS3Zj7peQ		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪც"):	from G9GbcAVkDB	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧძ")	:	from xzMblkIAKs		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨწ")	:	from aKIkBgjWq0		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩჭ")	:	from QLDRgOfCVA		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==Nlyfx1HnzOWCovke5(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫხ")	:	from Z89L0fSra1		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪჯ")	:	from rm87i5wn64		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==XCYALgFs2O3hZdpHrlMmB(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬჰ")	:	from QLo9OEpqlB		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==XCYALgFs2O3hZdpHrlMmB(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩჱ"):	from sjqwv4CVyB	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨჲ")	:	from Clj93VJn8m		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧჳ")	:	from IIwj6ap74b		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==FGLEMi21Bfn(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨჴ")	:	from agMbSs938w		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MzgKWUQ4V5H(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪჵ")	:	from QQzUvhZY8P		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==V2RQwM8XjlrK(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫჶ")	:	from ggUmxYnW0l		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==V2RQwM8XjlrK(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬჷ")	:	from TICq46Es3M		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==Nlyfx1HnzOWCovke5(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ჸ")	:	from tSvc6xpWlE		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==QYSAUI5r46yil8cfaO(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭ჹ")	:	from mGsN7zp3Tr		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MpJ8GOKoic(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ჺ")	:	from MhGoTmEkg2			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MzgKWUQ4V5H(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ჻")	:	from WplIVr5uBO		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==QYSAUI5r46yil8cfaO(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫჼ")	:	from dUryeT1CJH		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪჽ")	:	from IVxRjUAok8		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==g7yJo2LVuqx1trPe(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ჾ")	:	from lUdgLk0izX		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬჿ")	:	from sJb8wcGRNI		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==YzowicIDTRusXZSU61(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᄀ")	:	from QBUiYm6CtO		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨᄁ")	:	from lU4NMcfLDY		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ESXZrtnCfcDJGo01vFg(u"ࠧࡇࡑࡖࡘࡆ࠭ᄂ")		:	from pVZljYfmER			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩᄃ")	:	from a2YrPhnIXl		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫᄄ")	:	from NOu4iJt5zj		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨᄅ"):	from IK6G3k8fMo	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪᄆ"):	from wlYHRpVvh5	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧᄇ")	:	from ahFMwSmWVy		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡉࡇࡋࡏࡑࠬᄈ")		:	from Re91HMbF8l			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==Nlyfx1HnzOWCovke5(u"ࠧࡊࡒࡗ࡚ࠬᄉ")		:	from WWria3lCPQ			import JwqdmWj19PZr as tlZBeT1Y2RjIu,FXrJ2CcKxVys6aM as hjBWFnCMqr,klWfTZXjDY4qbPhvOKxd as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==g7yJo2LVuqx1trPe(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫᄊ")	:	from JJOYjwKUzn		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫᄋ")	:	from w4L2zA5FyH		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==Nlyfx1HnzOWCovke5(u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬᄌ")	:	from ddeNSF5fca		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬᄍ")	:	from O7TiM6FkIC		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬᄎ")	:	from llhCVaYrkN			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==SSBkx0WbN1asnDCQV6tIj(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧᄏ")	:	from cotY0HQLr8		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==WCPwmyVsb62KRlo(u"ࠧࡎ࠵ࡘࠫᄐ")		:	from n4KTbzCNIs			import JwqdmWj19PZr as tlZBeT1Y2RjIu,FXrJ2CcKxVys6aM as hjBWFnCMqr,klWfTZXjDY4qbPhvOKxd as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==FGLEMi21Bfn(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫᄑ")	:	from tkd2Dhn8HN		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩᄒ")	:	from XXbVGhg7yo			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪᄓ")	:	from oCAyOMBasc			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡕࡇࡎࡆࡖࠪᄔ")		:	from k8qN7Fo1a0			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==YzowicIDTRusXZSU61(u"ࠬࡗࡆࡊࡎࡐࠫᄕ")		:	from rxFoDKgp4n			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==FGLEMi21Bfn(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪᄖ"):	from T9EvSY1rXI		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪᄗ")	:	from dIQC6Dc45p		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᄘ")	:	from RTvsb4O16t		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==WXuJd8nz2spo146t(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ᄙ"):	from xWmilpNGzf		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ESXZrtnCfcDJGo01vFg(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ᄚ")	:	from McyGYCaWgo		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==ynxXU3gaiQ9GPCftr1q(u"ࠫࡘࡎࡏࡇࡊࡄࠫᄛ")	:	from jZnLR47tB5			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧᄜ")	:	from d4TFuBPg3f		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==XCYALgFs2O3hZdpHrlMmB(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨᄝ")	:	from kVU4aLQhe7		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==MpJ8GOKoic(u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩᄞ")	:	from S5SGI6cZW1		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==g7yJo2LVuqx1trPe(u"ࠨࡖࡌࡏࡆࡇࡔࠨᄟ")	:	from fHls7bihum			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==V2RQwM8XjlrK(u"ࠩࡗ࡚ࡋ࡛ࡎࠨᄠ")		:	from YNmJdaRLhM			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==EM6qpnCBYQGA9kbgDVLfrP(u"࡚ࠪࡆࡘࡂࡐࡐࠪᄡ")	:	from dMbR5g6lLs			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨᄢ"):	from vkK52PxTij		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==Nlyfx1HnzOWCovke5(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ᄣ")	:	from qKo9G5Nwgz		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==WsklGNp2CYzVQUag(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧᄤ")	:	from HVdu8AmN05		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==SSBkx0WbN1asnDCQV6tIj(u"࡚ࠧࡃࡔࡓ࡙࠭ᄥ")		:	from tIX2QORNFS			import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==QYSAUI5r46yil8cfaO(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩᄦ")	:	from aXzHjfFhL2		import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	elif N4EIr3MoWP7k5w==NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨᄧ"):	from qC3TvE6xV8	import eKWDaEPho9wLl5 as tlZBeT1Y2RjIu,zDkgCMXBmx2A as hjBWFnCMqr,xzA9sM3rG6IHd7jl8T as e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
	return tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG
def jRf87LJug6qp4ZzTyhm(O8OPqo5m4gTw07cBLliGEy6fpRWI,imAJgoKCHE3DrTVOnPlf,showDialogs):
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,XCYALgFs2O3hZdpHrlMmB(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨᄨ")+O8OPqo5m4gTw07cBLliGEy6fpRWI+Nlyfx1HnzOWCovke5(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᄩ")+str(imAJgoKCHE3DrTVOnPlf)+MpJ8GOKoic(u"ࠬࠦ࡝ࠨᄪ"))
	uuyUxZ8tM1 = LfgAx0QSMK59hF()
	uuyUxZ8tM1.create(NNjUsZzEcFOAoKry2CDMgb1(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄫ"),WXuJd8nz2spo146t(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩᄬ"))
	bbYGkvuoSHB52R3TD84ZhmEI = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠴࠴࠷࠺ᐣ")*l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠴࠴࠷࠺ᐣ")
	oUXjRGMcA9y8WzwN4n = SSBkx0WbN1asnDCQV6tIj(u"࠵ᐤ")*bbYGkvuoSHB52R3TD84ZhmEI
	import requests as C56ifaczLBrtO7Vm
	s63mcpoNbCT79FW0dOfauhYrRyLV = C56ifaczLBrtO7Vm.get(O8OPqo5m4gTw07cBLliGEy6fpRWI,stream=YOHXqtbQTBfKerIZ,headers=imAJgoKCHE3DrTVOnPlf)
	dTS3ZqXubR2z = s63mcpoNbCT79FW0dOfauhYrRyLV.headers
	s63mcpoNbCT79FW0dOfauhYrRyLV.close()
	iBeCITVLGxlU9WymX = bytes()
	if not dTS3ZqXubR2z:
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᄭ"),YzowicIDTRusXZSU61(u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฬ่็๋ࠦๅ็ࠢอั๊๐ไࠡษ็้้็ࠠศๆ่฻้๎ศ๊ࠡสุ่ฮศࠡไาࠤ๏้่็ࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮ࠡฮิฬࠥะอๆ์็ࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠬᄮ"))
		uuyUxZ8tM1.close()
	else:
		if kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫᄯ") not in list(dTS3ZqXubR2z.keys()): D3DjWxmEPydrpR5Y = ufmXvxgoHGDwZtjsLkR05i
		else: D3DjWxmEPydrpR5Y = int(dTS3ZqXubR2z[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬᄰ")])
		n7fL5mG1vlihA4QWJowuqbk = str(int(ESXZrtnCfcDJGo01vFg(u"࠷࠰࠱࠲ᐦ")*D3DjWxmEPydrpR5Y/bbYGkvuoSHB52R3TD84ZhmEI)/jXWzIZcDva4ikEUfN(u"࠶࠶࠰࠱࠰࠳ᐥ"))
		o5jBD2UbLNrF90JT8t6xiCnumZcdXM = int(D3DjWxmEPydrpR5Y/oUXjRGMcA9y8WzwN4n)+pwxH3oREFm5v98BCZ1QVtzMJOc
		if FGLEMi21Bfn(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬᄱ") in list(dTS3ZqXubR2z.keys()) and D3DjWxmEPydrpR5Y>bbYGkvuoSHB52R3TD84ZhmEI:
			B4VXJzwAxYl2UI17S3idfMGNCRm9PK = YOHXqtbQTBfKerIZ
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU = []
			drwYucBRq7j = WsklGNp2CYzVQUag(u"࠱࠱ᐧ")
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(ufmXvxgoHGDwZtjsLkR05i*D3DjWxmEPydrpR5Y//drwYucBRq7j)+ynxXU3gaiQ9GPCftr1q(u"࠭࠭ࠨᄲ")+str(pwxH3oREFm5v98BCZ1QVtzMJOc*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(pwxH3oREFm5v98BCZ1QVtzMJOc*D3DjWxmEPydrpR5Y//drwYucBRq7j)+NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࠮ࠩᄳ")+str(RXnhpCUk4M1TvgJE*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(RXnhpCUk4M1TvgJE*D3DjWxmEPydrpR5Y//drwYucBRq7j)+XCYALgFs2O3hZdpHrlMmB(u"ࠨ࠯ࠪᄴ")+str(wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A*D3DjWxmEPydrpR5Y//drwYucBRq7j)+SSBkx0WbN1asnDCQV6tIj(u"ࠩ࠰ࠫᄵ")+str(BZm7TqLPJfAVblDKsya85zFWXNMY*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(BZm7TqLPJfAVblDKsya85zFWXNMY*D3DjWxmEPydrpR5Y//drwYucBRq7j)+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪ࠱ࠬᄶ")+str(EM6qpnCBYQGA9kbgDVLfrP(u"࠶ᐨ")*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(cpHxZyU7vTtqmIw(u"࠷ᐩ")*D3DjWxmEPydrpR5Y//drwYucBRq7j)+EM6qpnCBYQGA9kbgDVLfrP(u"ࠫ࠲࠭ᄷ")+str(jXWzIZcDva4ikEUfN(u"࠹ᐪ")*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(EM6qpnCBYQGA9kbgDVLfrP(u"࠻ᐬ")*D3DjWxmEPydrpR5Y//drwYucBRq7j)+Nlyfx1HnzOWCovke5(u"ࠬ࠳ࠧᄸ")+str(pnkrd2S84FJfN73KuiCYv(u"࠻ᐫ")*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(YzowicIDTRusXZSU61(u"࠷ᐮ")*D3DjWxmEPydrpR5Y//drwYucBRq7j)+WXuJd8nz2spo146t(u"࠭࠭ࠨᄹ")+str(SSBkx0WbN1asnDCQV6tIj(u"࠾ᐭ")*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠺ᐰ")*D3DjWxmEPydrpR5Y//drwYucBRq7j)+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧ࠮ࠩᄺ")+str(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠺ᐯ")*D3DjWxmEPydrpR5Y//drwYucBRq7j-pwxH3oREFm5v98BCZ1QVtzMJOc))
			XXp2ZtcxoKNj5wGlb01uOEfS7mIU.append(str(ESXZrtnCfcDJGo01vFg(u"࠼ᐱ")*D3DjWxmEPydrpR5Y//drwYucBRq7j)+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ࠯ࠪᄻ"))
			CpgIRqe6orb = float(o5jBD2UbLNrF90JT8t6xiCnumZcdXM)/drwYucBRq7j
			kq75c4RFOUdmDlbLV2fB8zK = CpgIRqe6orb/int(pwxH3oREFm5v98BCZ1QVtzMJOc+CpgIRqe6orb)
		else:
			B4VXJzwAxYl2UI17S3idfMGNCRm9PK = eu1NswY9zkKC60I
			drwYucBRq7j = pwxH3oREFm5v98BCZ1QVtzMJOc
			kq75c4RFOUdmDlbLV2fB8zK = pwxH3oREFm5v98BCZ1QVtzMJOc
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,SSBkx0WbN1asnDCQV6tIj(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪᄼ")+str(B4VXJzwAxYl2UI17S3idfMGNCRm9PK)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࠤࡢࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᄽ")+str(D3DjWxmEPydrpR5Y)+MpJ8GOKoic(u"ࠫࠥࡣࠧᄾ"))
		sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz,tI5Pc3YWo20uTaVE = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
		for aR310exys7FgI2WvQ in range(drwYucBRq7j):
			eDbTIrV6KLfz80 = imAJgoKCHE3DrTVOnPlf.copy()
			if B4VXJzwAxYl2UI17S3idfMGNCRm9PK: eDbTIrV6KLfz80[V2RQwM8XjlrK(u"ࠬࡘࡡ࡯ࡩࡨࠫᄿ")] = jXWzIZcDva4ikEUfN(u"࠭ࡢࡺࡶࡨࡷࡂ࠭ᅀ")+XXp2ZtcxoKNj5wGlb01uOEfS7mIU[aR310exys7FgI2WvQ]
			s63mcpoNbCT79FW0dOfauhYrRyLV = C56ifaczLBrtO7Vm.get(O8OPqo5m4gTw07cBLliGEy6fpRWI,stream=YOHXqtbQTBfKerIZ,headers=eDbTIrV6KLfz80,timeout=EM6qpnCBYQGA9kbgDVLfrP(u"࠷࠵࠶ᐲ"))
			for MZ94c821RJp7QafPg in s63mcpoNbCT79FW0dOfauhYrRyLV.iter_content(chunk_size=oUXjRGMcA9y8WzwN4n):
				if uuyUxZ8tM1.iscanceled():
					iQlMPpRZXWLd(yyhLQon4NGP5MpH,MpJ8GOKoic(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧᅁ"))
					break
				sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz += kq75c4RFOUdmDlbLV2fB8zK
				iBeCITVLGxlU9WymX += MZ94c821RJp7QafPg
				if not tI5Pc3YWo20uTaVE: tI5Pc3YWo20uTaVE = len(MZ94c821RJp7QafPg)
				if D3DjWxmEPydrpR5Y: yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠶࠶࠰ᐳ")*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz//o5jBD2UbLNrF90JT8t6xiCnumZcdXM,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩᅂ"),str(WsklGNp2CYzVQUag(u"࠷࠰࠱࠰࠳ᐴ")*tI5Pc3YWo20uTaVE*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz//oUXjRGMcA9y8WzwN4n//WsklGNp2CYzVQUag(u"࠷࠰࠱࠰࠳ᐴ"))+ESXZrtnCfcDJGo01vFg(u"ࠩࠣ࠳ࠥ࠭ᅃ")+n7fL5mG1vlihA4QWJowuqbk+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࠤࡒࡈࠧᅄ"))
				else: yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,tI5Pc3YWo20uTaVE*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz//oUXjRGMcA9y8WzwN4n,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩᅅ"),str(ynxXU3gaiQ9GPCftr1q(u"࠱࠱࠲࠱࠴ᐵ")*tI5Pc3YWo20uTaVE*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz//oUXjRGMcA9y8WzwN4n//ynxXU3gaiQ9GPCftr1q(u"࠱࠱࠲࠱࠴ᐵ"))+wYTDlJC5vpOKynUEX3ge6W(u"ࠬࠦࡍࡃࠩᅆ"))
			s63mcpoNbCT79FW0dOfauhYrRyLV.close()
		uuyUxZ8tM1.close()
		if len(iBeCITVLGxlU9WymX)<D3DjWxmEPydrpR5Y and D3DjWxmEPydrpR5Y>ufmXvxgoHGDwZtjsLkR05i:
			iQlMPpRZXWLd(yyhLQon4NGP5MpH,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩᅇ")+str(len(iBeCITVLGxlU9WymX)//bbYGkvuoSHB52R3TD84ZhmEI)+MzgKWUQ4V5H(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬᅈ")+n7fL5mG1vlihA4QWJowuqbk+wAU9jKvmTM0(u"ࠨࠢࡐࡆࠥࡣࠧᅉ"))
			B69G5sUjmDJelfod481KPAyHwc = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠩศ่฿อม๊ࠡัีําࠧᅊ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪᅋ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭ᅌ"),ynxXU3gaiQ9GPCftr1q(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅍ"),g7yJo2LVuqx1trPe(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪᅎ")+str(len(iBeCITVLGxlU9WymX)//bbYGkvuoSHB52R3TD84ZhmEI)+YzowicIDTRusXZSU61(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭ᅏ")+n7fL5mG1vlihA4QWJowuqbk+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪᅐ"))
			if B69G5sUjmDJelfod481KPAyHwc==RXnhpCUk4M1TvgJE: iBeCITVLGxlU9WymX = jRf87LJug6qp4ZzTyhm(O8OPqo5m4gTw07cBLliGEy6fpRWI,imAJgoKCHE3DrTVOnPlf,showDialogs)
			elif B69G5sUjmDJelfod481KPAyHwc==pwxH3oREFm5v98BCZ1QVtzMJOc: iQlMPpRZXWLd(yyhLQon4NGP5MpH,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࠱ࡠࡹࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨᅑ"))
			else: return Vk54F7GcROfCy6HunEI
			if not iBeCITVLGxlU9WymX: return Vk54F7GcROfCy6HunEI
		else: iQlMPpRZXWLd(yyhLQon4NGP5MpH,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧᅒ")+n7fL5mG1vlihA4QWJowuqbk+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࠥࡓࡂࠡ࡟ࠪᅓ"))
	return iBeCITVLGxlU9WymX
def MMLjCRy6rJ2tq3cWBQl4eskz(TVPm7Bz1XOwJ2):
	return s63mcpoNbCT79FW0dOfauhYrRyLV
def aEAZWIlr32Q5z1ufmRqUX6MFS98sP(ip=Vk54F7GcROfCy6HunEI):
	if h9zFQKnsNL.GEOLOCATION_DATA: return h9zFQKnsNL.GEOLOCATION_DATA
	cme92GCMFt6x75THBbasW,T3lKRZcek4aHVNfXCho5SsGngIqB07,h9hzZeS8xQu7RjBLMdcspTvUa,JJMUYNLzA3hgar7fVi0lHXGQ,CvM74N8LdzkWG,eoc1NhBfGrSzLpXTZ3YxH5 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	N39NCXDAaVnx = cpHxZyU7vTtqmIw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨᅔ")+ip+QYSAUI5r46yil8cfaO(u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᅕ")
	imAJgoKCHE3DrTVOnPlf = {NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᅖ"):Vk54F7GcROfCy6HunEI}
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,XCYALgFs2O3hZdpHrlMmB(u"ࠨࡉࡈࡘࠬᅗ"),N39NCXDAaVnx,Vk54F7GcROfCy6HunEI,imAJgoKCHE3DrTVOnPlf,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬᅘ"))
	if not s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		N39NCXDAaVnx = WXuJd8nz2spo146t(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵ࠳ࡡࡱ࡫࠱ࡧࡴࡳ࠯࡫ࡵࡲࡲ࠴࠭ᅙ")+ip+ESXZrtnCfcDJGo01vFg(u"ࠫࡄ࡬ࡩࡦ࡮ࡧࡷࡂࡷࡵࡦࡴࡼ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧ࠯ࡧ࡮ࡺࡹ࠭ࡱࡩࡪࡸ࡫ࡴࠨᅚ")
		s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,Nlyfx1HnzOWCovke5(u"ࠬࡍࡅࡕࠩᅛ"),N39NCXDAaVnx,Vk54F7GcROfCy6HunEI,imAJgoKCHE3DrTVOnPlf,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠸࡮ࡥࠩᅜ"))
	if s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = s63mcpoNbCT79FW0dOfauhYrRyLV.content
		pHLzYVDtC2r1Fs6xnmobZevaNI = MkuHT2blpeds34wXxDyvgitqWo.loads(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
		sfdmJaU0Yoi7qK2ITv6A = list(pHLzYVDtC2r1Fs6xnmobZevaNI.keys())
		if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡪࡲࠪᅝ") in sfdmJaU0Yoi7qK2ITv6A: ip = pHLzYVDtC2r1Fs6xnmobZevaNI[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡫ࡳࠫᅞ")]
		if ynxXU3gaiQ9GPCftr1q(u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬᅟ") in sfdmJaU0Yoi7qK2ITv6A: cme92GCMFt6x75THBbasW = pHLzYVDtC2r1Fs6xnmobZevaNI[ynxXU3gaiQ9GPCftr1q(u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭ᅠ")]
		if V2RQwM8XjlrK(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᅡ") in sfdmJaU0Yoi7qK2ITv6A: T3lKRZcek4aHVNfXCho5SsGngIqB07 = pHLzYVDtC2r1Fs6xnmobZevaNI[BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ᅢ")]
		if NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬᅣ") in sfdmJaU0Yoi7qK2ITv6A: h9hzZeS8xQu7RjBLMdcspTvUa = pHLzYVDtC2r1Fs6xnmobZevaNI[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭ᅤ")]
		if cpHxZyU7vTtqmIw(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨᅥ") in sfdmJaU0Yoi7qK2ITv6A: JJMUYNLzA3hgar7fVi0lHXGQ = pHLzYVDtC2r1Fs6xnmobZevaNI[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡵࡩ࡬࡯࡯࡯ࠩᅦ")]
		if l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡧ࡮ࡺࡹࠨᅧ") in sfdmJaU0Yoi7qK2ITv6A: CvM74N8LdzkWG = pHLzYVDtC2r1Fs6xnmobZevaNI[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡨ࡯ࡴࡺࠩᅨ")]
		if MpJ8GOKoic(u"ࠬࡷࡵࡦࡴࡼࠫᅩ") in sfdmJaU0Yoi7qK2ITv6A: ip = pHLzYVDtC2r1Fs6xnmobZevaNI[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡱࡶࡧࡵࡽࠬᅪ")]
		if ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡄࡱࡧࡩࠬᅫ") in sfdmJaU0Yoi7qK2ITv6A: h9hzZeS8xQu7RjBLMdcspTvUa = pHLzYVDtC2r1Fs6xnmobZevaNI[pnkrd2S84FJfN73KuiCYv(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠭ᅬ")]
		if ynxXU3gaiQ9GPCftr1q(u"ࠩࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠭ᅭ") in sfdmJaU0Yoi7qK2ITv6A: JJMUYNLzA3hgar7fVi0lHXGQ = pHLzYVDtC2r1Fs6xnmobZevaNI[QYSAUI5r46yil8cfaO(u"ࠪࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠧᅮ")]
		if EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ᅯ") in sfdmJaU0Yoi7qK2ITv6A:
			eoc1NhBfGrSzLpXTZ3YxH5 = pHLzYVDtC2r1Fs6xnmobZevaNI[WCPwmyVsb62KRlo(u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᅰ")][ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡵࡵࡥࠪᅱ")]
			if eoc1NhBfGrSzLpXTZ3YxH5[ufmXvxgoHGDwZtjsLkR05i] not in [ESXZrtnCfcDJGo01vFg(u"ࠧ࠮ࠩᅲ"),SSBkx0WbN1asnDCQV6tIj(u"ࠨ࠭ࠪᅳ")]: eoc1NhBfGrSzLpXTZ3YxH5 = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࠮ࠫᅴ")+eoc1NhBfGrSzLpXTZ3YxH5
		if WsklGNp2CYzVQUag(u"ࠪࡳ࡫࡬ࡳࡦࡶࠪᅵ") in sfdmJaU0Yoi7qK2ITv6A:
			eoc1NhBfGrSzLpXTZ3YxH5 = pHLzYVDtC2r1Fs6xnmobZevaNI[V2RQwM8XjlrK(u"ࠫࡴ࡬ࡦࡴࡧࡷࠫᅶ")]
			if eoc1NhBfGrSzLpXTZ3YxH5>=MpJ8GOKoic(u"࠱ᐶ"): eoc1NhBfGrSzLpXTZ3YxH5 = FGLEMi21Bfn(u"ࠬ࠱ࠧᅷ")+Gb6kwVlSQ4MU.strftime(wYTDlJC5vpOKynUEX3ge6W(u"ࠨࠥࡉ࠼ࠨࡑࠧᅸ"),Gb6kwVlSQ4MU.gmtime(eoc1NhBfGrSzLpXTZ3YxH5))
			else: eoc1NhBfGrSzLpXTZ3YxH5 = eAMGzHRQVs2KyCwPXljYhB(u"ࠧ࠮ࠩᅹ")+Gb6kwVlSQ4MU.strftime(WXuJd8nz2spo146t(u"ࠣࠧࡋ࠾ࠪࡓࠢᅺ"),Gb6kwVlSQ4MU.gmtime(-eoc1NhBfGrSzLpXTZ3YxH5))
	nQFcC14A2tDYkLM = ip+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࠯ࠫᅻ")+cme92GCMFt6x75THBbasW+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࠰ࠬᅼ")+T3lKRZcek4aHVNfXCho5SsGngIqB07+MpJ8GOKoic(u"ࠫ࠱࠭ᅽ")+JJMUYNLzA3hgar7fVi0lHXGQ+wAU9jKvmTM0(u"ࠬ࠲ࠧᅾ")+CvM74N8LdzkWG+QYSAUI5r46yil8cfaO(u"࠭ࠬࠨᅿ")+eoc1NhBfGrSzLpXTZ3YxH5
	nQFcC14A2tDYkLM = nQFcC14A2tDYkLM.encode(AoCWwJHgUPKXI7u2lEzym)
	if PvwFsJK23NbU8XWAx: nQFcC14A2tDYkLM = nQFcC14A2tDYkLM.decode(Nlyfx1HnzOWCovke5(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨᆀ"))
	h9zFQKnsNL.GEOLOCATION_DATA = ww25jXuxtpK1TOJEbGUgrm8(nQFcC14A2tDYkLM)
	return h9zFQKnsNL.GEOLOCATION_DATA
def HD6MGAiC4TrtXdc9ge7I(dn9PcSQWKE7se1i2RUB5ZDhO3kuo):
	RgByqYu0eANHlIfrOCd1m6Jah,showDialogs = Vk54F7GcROfCy6HunEI,YOHXqtbQTBfKerIZ
	if dn9PcSQWKE7se1i2RUB5ZDhO3kuo.count(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡡࠪᆁ"))>=RXnhpCUk4M1TvgJE:
		dn9PcSQWKE7se1i2RUB5ZDhO3kuo,RgByqYu0eANHlIfrOCd1m6Jah = dn9PcSQWKE7se1i2RUB5ZDhO3kuo.split(NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡢࠫᆂ"),pwxH3oREFm5v98BCZ1QVtzMJOc)
		RgByqYu0eANHlIfrOCd1m6Jah = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡣࠬᆃ")+RgByqYu0eANHlIfrOCd1m6Jah
		if XCYALgFs2O3hZdpHrlMmB(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᆄ") in RgByqYu0eANHlIfrOCd1m6Jah: showDialogs = eu1NswY9zkKC60I
		else: showDialogs = YOHXqtbQTBfKerIZ
	return dn9PcSQWKE7se1i2RUB5ZDhO3kuo,RgByqYu0eANHlIfrOCd1m6Jah,showDialogs
def uDL3ZW6dsapwXEmG8():
	UOkpQXmszJhbqFwoRHW2D9v7ajA4 = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,Nlyfx1HnzOWCovke5(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᆅ"))
	MOa3Ze1C6WQHjfXb4nAcYuSv = ufmXvxgoHGDwZtjsLkR05i
	if CR3aLOVKSIme5XFoYi6M.path.exists(UOkpQXmszJhbqFwoRHW2D9v7ajA4):
		for Hqxr3RAiJEadvFZWObS in CR3aLOVKSIme5XFoYi6M.listdir(UOkpQXmszJhbqFwoRHW2D9v7ajA4):
			if FGLEMi21Bfn(u"࠭࠮ࡱࡻࡲࠫᆆ") in Hqxr3RAiJEadvFZWObS: continue
			if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬᆇ") in Hqxr3RAiJEadvFZWObS: continue
			LLuDiZBH5QCGSRJ = CR3aLOVKSIme5XFoYi6M.path.join(UOkpQXmszJhbqFwoRHW2D9v7ajA4,Hqxr3RAiJEadvFZWObS)
			uukn9CUbI6A,haQpuc6O5b = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(LLuDiZBH5QCGSRJ)
			MOa3Ze1C6WQHjfXb4nAcYuSv += uukn9CUbI6A
	return MOa3Ze1C6WQHjfXb4nAcYuSv
def O7lx3KHcgw(showDialogs):
	CaUek70ESLYKDZ1VsoigGlpH = cad8TeSyMUYmfsEO0.getSetting(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ᆈ"))
	rbu7laYHNDcAZvU = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,MpJ8GOKoic(u"ࠩࡶࡸࡷ࠭ᆉ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᆊ"),ESXZrtnCfcDJGo01vFg(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᆋ"))
	NJIyx5zSvwdGc8gX2iEQRuDsVo,HHRqUxnuYCXkt39wszWAdVZl1 = CaUek70ESLYKDZ1VsoigGlpH,rbu7laYHNDcAZvU
	ehH2AZKoGivf,FhX0sPvkmxw4DZSL5pIfHU1TKCOy2 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	if eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᆌ") not in str(h9zFQKnsNL.SEND_THESE_EVENTS):
		N39NCXDAaVnx = h9zFQKnsNL.SITESURLS[eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᆍ")][wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]
		UrKfGLt0hSOQpT6wMV1oN = aEAZWIlr32Q5z1ufmRqUX6MFS98sP()
		T3lKRZcek4aHVNfXCho5SsGngIqB07 = UrKfGLt0hSOQpT6wMV1oN.split(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧ࠭ࠩᆎ"))[RXnhpCUk4M1TvgJE]
		MOa3Ze1C6WQHjfXb4nAcYuSv = uDL3ZW6dsapwXEmG8()
		NQw0ays5GT = {SSBkx0WbN1asnDCQV6tIj(u"ࠨࡷࡶࡩࡷ࠭ᆏ"):h9zFQKnsNL.AV_CLIENT_IDS,wAU9jKvmTM0(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᆐ"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᆑ"):T3lKRZcek4aHVNfXCho5SsGngIqB07,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࡮ࡪࡳࠨᆒ"):DWBRli3pT90(MOa3Ze1C6WQHjfXb4nAcYuSv)}
		s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡖࡏࡔࡖࠪᆓ"),N39NCXDAaVnx,NQw0ays5GT,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪᆔ"))
		if not s63mcpoNbCT79FW0dOfauhYrRyLV.succeeded:
			if CaUek70ESLYKDZ1VsoigGlpH in [Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡏࡇ࡚ࠫᆕ")]: NJIyx5zSvwdGc8gX2iEQRuDsVo = MzgKWUQ4V5H(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᆖ")
			elif CaUek70ESLYKDZ1VsoigGlpH==g7yJo2LVuqx1trPe(u"ࠩࡒࡐࡉ࠭ᆗ"): NJIyx5zSvwdGc8gX2iEQRuDsVo = wYTDlJC5vpOKynUEX3ge6W(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᆘ")
		else:
			pglBbdtqXzV = s63mcpoNbCT79FW0dOfauhYrRyLV.content
			pglBbdtqXzV = Bw6jaUcFxlqdDT8bC(cpHxZyU7vTtqmIw(u"ࠫࡱ࡯ࡳࡵࠩᆙ"),pglBbdtqXzV)
			pglBbdtqXzV = sorted(pglBbdtqXzV,reverse=YOHXqtbQTBfKerIZ,key=lambda key: int(key[ufmXvxgoHGDwZtjsLkR05i]))
			FhX0sPvkmxw4DZSL5pIfHU1TKCOy2,HHRqUxnuYCXkt39wszWAdVZl1 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
			for eF0Unv2tmQPZSlhafVD1qbWzYwp5,ND5RnrWhQ9gHUwx,Qe6XMhzKmCuI1qfwDAtBJlE4scVd3 in pglBbdtqXzV:
				if eF0Unv2tmQPZSlhafVD1qbWzYwp5==g7yJo2LVuqx1trPe(u"ࠬ࠶ࠧᆚ"):
					FhX0sPvkmxw4DZSL5pIfHU1TKCOy2 += Qe6XMhzKmCuI1qfwDAtBJlE4scVd3+ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭࠺࠻ࠩᆛ")
					continue
				if HHRqUxnuYCXkt39wszWAdVZl1: HHRqUxnuYCXkt39wszWAdVZl1 += ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᆜ")+ZZoLlKyInXc08j2pTGJ+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ࡞ࡱࡠࡳ࠭ᆝ")
				d1KjHFNElVYub7I8vwBar = Qe6XMhzKmCuI1qfwDAtBJlE4scVd3.split(ixrPWKeFMnqJyVodX6D9AaO2)[ufmXvxgoHGDwZtjsLkR05i]
				ewGlmFf52ByKobU = YzowicIDTRusXZSU61(u"ࠩิืฬ๊ษࠡะสูฮࠦไไࠢไๆ฼࠭ᆞ") if ND5RnrWhQ9gHUwx else Vk54F7GcROfCy6HunEI
				HHRqUxnuYCXkt39wszWAdVZl1 += Qe6XMhzKmCuI1qfwDAtBJlE4scVd3.replace(d1KjHFNElVYub7I8vwBar,d761ZWXHEvliYN45RzLP2+d1KjHFNElVYub7I8vwBar+ewGlmFf52ByKobU+ZZoLlKyInXc08j2pTGJ)+ixrPWKeFMnqJyVodX6D9AaO2
			HHRqUxnuYCXkt39wszWAdVZl1 = ixrPWKeFMnqJyVodX6D9AaO2+HHRqUxnuYCXkt39wszWAdVZl1+SSBkx0WbN1asnDCQV6tIj(u"ࠪࡠࡳࡢ࡮ࠨᆟ")
			FhX0sPvkmxw4DZSL5pIfHU1TKCOy2 = FhX0sPvkmxw4DZSL5pIfHU1TKCOy2.strip(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࠿ࡀࠧᆠ"))
			ehH2AZKoGivf = cad8TeSyMUYmfsEO0.getSetting(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨᆡ"))
			if HHRqUxnuYCXkt39wszWAdVZl1==rbu7laYHNDcAZvU and CaUek70ESLYKDZ1VsoigGlpH in [HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡏࡍࡆࠪᆢ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ᆣ")]: NJIyx5zSvwdGc8gX2iEQRuDsVo = eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡑࡏࡈࠬᆤ")
			else: NJIyx5zSvwdGc8gX2iEQRuDsVo = ynxXU3gaiQ9GPCftr1q(u"ࠩࡑࡉ࡜࠭ᆥ")
			FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,WCPwmyVsb62KRlo(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᆦ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᆧ"),HHRqUxnuYCXkt39wszWAdVZl1,piwNWcJEe9m)
			cad8TeSyMUYmfsEO0.setSetting(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ᆨ"),DWBRli3pT90(npbh5qZo1PBiNkj))
			cad8TeSyMUYmfsEO0.setSetting(QYSAUI5r46yil8cfaO(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩᆩ"),FhX0sPvkmxw4DZSL5pIfHU1TKCOy2)
			KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(WXuJd8nz2spo146t(u"࠷ᐷ")*FhX0sPvkmxw4DZSL5pIfHU1TKCOy2.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
			KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(WXuJd8nz2spo146t(u"࠴࠸ᐸ")*KJcupFnhxLbjTr6lUagHBsR3e.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
			KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(QYSAUI5r46yil8cfaO(u"࠵࠾ᐹ")*KJcupFnhxLbjTr6lUagHBsR3e.encode(AoCWwJHgUPKXI7u2lEzym)).hexdigest()
			bIsz45VatWSMRmkyph63Zg1lf,C9frwiYhylNH2n14uDaG5 = ENGD7a3qU5AWfdMjZXP(OKzSt0JnAdvh2mM)
			k5CaeTXcbAnrh1sJOg(OKzSt0JnAdvh2mM,bIsz45VatWSMRmkyph63Zg1lf,C9frwiYhylNH2n14uDaG5,eu1NswY9zkKC60I,ynxXU3gaiQ9GPCftr1q(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡤ࡯ࡤ࠾ࠩᆪ")+str(int(KJcupFnhxLbjTr6lUagHBsR3e[YzowicIDTRusXZSU61(u"࠹ᐻ"):cpHxZyU7vTtqmIw(u"࠱࠳ᐼ")],EM6qpnCBYQGA9kbgDVLfrP(u"࠲࠸ᐽ")))[:Nlyfx1HnzOWCovke5(u"࠾ᐺ")]+WCPwmyVsb62KRlo(u"ࠨࠢ࠾ࠫᆫ"))
			bIsz45VatWSMRmkyph63Zg1lf.close()
		MlHkaFZSnwh = YOHXqtbQTBfKerIZ if FhX0sPvkmxw4DZSL5pIfHU1TKCOy2!=ehH2AZKoGivf else eu1NswY9zkKC60I
		if MlHkaFZSnwh:
			gji3pZKkWv0aH1cI42Yd = h9zFQKnsNL.qUhMJ0k8yAs
			h9zFQKnsNL.C7tWRO0bJdz3TV49j8eIklM1fDSxB,h9zFQKnsNL.qUhMJ0k8yAs,h9zFQKnsNL.fNB1eMh5ytzOIPow2icAC6Sv,h9zFQKnsNL.JizCr5lUSWf = oYqQF65i48Uhzmw3jkJPRGsZnV([V2RQwM8XjlrK(u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪᆬ"),MpJ8GOKoic(u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫᆭ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡛ࡒࡗࡐࡘࡗ࡚࠻ࡈ࡙ࠩᆮ"),MzgKWUQ4V5H(u"ࠬࡕࡔ࠲࠻ࡍ࡙࠵ࡾࡂࡕࡗ࡯ࡈ࡝࠭ᆯ")])
			J3WgUjeYFvaMrfTNsu1l8P7 = h9zFQKnsNL.qUhMJ0k8yAs
			if not gji3pZKkWv0aH1cI42Yd and J3WgUjeYFvaMrfTNsu1l8P7 and ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫᆰ") in h9zFQKnsNL.SEND_THESE_EVENTS:
				h9zFQKnsNL.SEND_THESE_EVENTS.remove(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᆱ"))
				h9zFQKnsNL.SEND_THESE_EVENTS.append(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᆲ"))
			elif gji3pZKkWv0aH1cI42Yd and not J3WgUjeYFvaMrfTNsu1l8P7 and MzgKWUQ4V5H(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᆳ") in h9zFQKnsNL.SEND_THESE_EVENTS:
				h9zFQKnsNL.SEND_THESE_EVENTS.remove(FGLEMi21Bfn(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᆴ"))
				h9zFQKnsNL.SEND_THESE_EVENTS.append(MpJ8GOKoic(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩᆵ"))
			YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	if showDialogs:
		if NJIyx5zSvwdGc8gX2iEQRuDsVo in [jXWzIZcDva4ikEUfN(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫᆶ"),FGLEMi21Bfn(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᆷ")]:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆸ"),WCPwmyVsb62KRlo(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨᆹ"))
		else:
			aaNxZcCAYds8FEjDqzgBhK4(ynxXU3gaiQ9GPCftr1q(u"ࠩࡵ࡭࡬࡮ࡴࠨᆺ"),Nlyfx1HnzOWCovke5(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭ᆻ"),HHRqUxnuYCXkt39wszWAdVZl1,SSBkx0WbN1asnDCQV6tIj(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᆼ"))
			NJIyx5zSvwdGc8gX2iEQRuDsVo = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡕࡌࡅࠩᆽ")
	if NJIyx5zSvwdGc8gX2iEQRuDsVo!=CaUek70ESLYKDZ1VsoigGlpH:
		cad8TeSyMUYmfsEO0.setSetting(SSBkx0WbN1asnDCQV6tIj(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫᆾ"),NJIyx5zSvwdGc8gX2iEQRuDsVo)
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def JSmOA1XwhMN4IrcqeYPgEB652xl(yXHTMfhui87IRLSQmNv,a6Yrzho9J2VksBEG4):
	import socket as bb3RGytoD6Mi1hAP
	zytKrqcPLWXON6 = bb3RGytoD6Mi1hAP.socket(bb3RGytoD6Mi1hAP.AF_INET,bb3RGytoD6Mi1hAP.SOCK_STREAM)
	zytKrqcPLWXON6.settimeout(RXnhpCUk4M1TvgJE)
	try:
		TT7ytNUaAEzleV2oMR9j3 = Gb6kwVlSQ4MU.time()
		zytKrqcPLWXON6.connect((yXHTMfhui87IRLSQmNv,a6Yrzho9J2VksBEG4))
		OBuSrz9n5ARhJXN = Gb6kwVlSQ4MU.time()
		jtyaEDvzMYOLngm0 = round((OBuSrz9n5ARhJXN-TT7ytNUaAEzleV2oMR9j3)*NNjUsZzEcFOAoKry2CDMgb1(u"࠳࠳࠴࠵ᐾ"))
	except: jtyaEDvzMYOLngm0 = -pwxH3oREFm5v98BCZ1QVtzMJOc
	zytKrqcPLWXON6.close()
	return jtyaEDvzMYOLngm0
def Rl9iZEjgtdhHAocuU1fk7wLPB6r(showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆿ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧᇀ"))
	else: W8j2OheqsroDJIYzRupt6nG = YOHXqtbQTBfKerIZ
	if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
		for Hqxr3RAiJEadvFZWObS in CR3aLOVKSIme5XFoYi6M.listdir(GK4x3b6Erdk):
			if Hqxr3RAiJEadvFZWObS.endswith(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࠱ࡨࡧ࠭ᇁ")) and g7yJo2LVuqx1trPe(u"ࠪࡨࡦࡺࡡࠨᇂ") in Hqxr3RAiJEadvFZWObS:
				wxrfsAOmWb5X9cLYGo67RCz = CR3aLOVKSIme5XFoYi6M.path.join(GK4x3b6Erdk,Hqxr3RAiJEadvFZWObS)
				bIsz45VatWSMRmkyph63Zg1lf,C9frwiYhylNH2n14uDaG5 = ENGD7a3qU5AWfdMjZXP(wxrfsAOmWb5X9cLYGo67RCz)
				C9frwiYhylNH2n14uDaG5.execute(SSBkx0WbN1asnDCQV6tIj(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧᇃ"))
				C9frwiYhylNH2n14uDaG5.execute(Nlyfx1HnzOWCovke5(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡺࡥ࡮ࡲࡢࡷࡹࡵࡲࡦ࠿ࡐࡉࡒࡕࡒ࡚࠽ࠪᇄ"))
				C9frwiYhylNH2n14uDaG5.execute(FGLEMi21Bfn(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩᇅ"))
				C9frwiYhylNH2n14uDaG5.execute(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪᇆ"))
				C9frwiYhylNH2n14uDaG5.execute(cpHxZyU7vTtqmIw(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩᇇ"))
				bIsz45VatWSMRmkyph63Zg1lf.commit()
				bIsz45VatWSMRmkyph63Zg1lf.close()
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᇈ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫᇉ"))
	return
def igFtOzLBeQu(ngGD8xKEybaFP9itVCMScqJ,ExJyuTz4K8qLgwWVNQFBMoH,showDialogs):
	if ngGD8xKEybaFP9itVCMScqJ!=XVgJmyC4wSjDON:
		if ngGD8xKEybaFP9itVCMScqJ==vXgYbe8s9zknIMpaB: h9zFQKnsNL.ALLOW_DNS_FIX = YOHXqtbQTBfKerIZ
		elif ngGD8xKEybaFP9itVCMScqJ==b8f2icUnEswC9Ja: h9zFQKnsNL.ALLOW_DNS_FIX = eu1NswY9zkKC60I
		elif ngGD8xKEybaFP9itVCMScqJ==I3IivNQUYMoVL5zbmnZWgaAudfB: h9zFQKnsNL.ALLOW_DNS_FIX = YOHXqtbQTBfKerIZ
	if ExJyuTz4K8qLgwWVNQFBMoH!=XVgJmyC4wSjDON:
		if ExJyuTz4K8qLgwWVNQFBMoH==vXgYbe8s9zknIMpaB: h9zFQKnsNL.ALLOW_PROXY_FIX = YOHXqtbQTBfKerIZ
		elif ExJyuTz4K8qLgwWVNQFBMoH==b8f2icUnEswC9Ja: h9zFQKnsNL.ALLOW_PROXY_FIX = eu1NswY9zkKC60I
		elif ExJyuTz4K8qLgwWVNQFBMoH==I3IivNQUYMoVL5zbmnZWgaAudfB: h9zFQKnsNL.ALLOW_PROXY_FIX = YOHXqtbQTBfKerIZ
	if showDialogs!=XVgJmyC4wSjDON:
		if showDialogs==vXgYbe8s9zknIMpaB: h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX = YOHXqtbQTBfKerIZ
		elif showDialogs==b8f2icUnEswC9Ja: h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX = eu1NswY9zkKC60I
		elif showDialogs==I3IivNQUYMoVL5zbmnZWgaAudfB: h9zFQKnsNL.ALLOW_SHOWDIALOGS_FIX = YOHXqtbQTBfKerIZ
	return
def UApE5IrWKhyHZ(website,pxn83GwezcTmlQCf4WFL,OS9GsTAan7yDVuc4XYpfqtPCj=tayEeSpKRJIdC8g10):
	EpoqUXNL3iRST1OPlj47YrVtmdZwy = YzowicIDTRusXZSU61(u"࠴࠴ᐿ")
	ZEFwyl4LYUv3BDn = [ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),g7yJo2LVuqx1trPe(u"࠶࠶ᑁ"),g7yJo2LVuqx1trPe(u"࠻ᑂ"),g7yJo2LVuqx1trPe(u"࠶࠶ᑁ"),ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),ESXZrtnCfcDJGo01vFg(u"࠵ᑀ"),g7yJo2LVuqx1trPe(u"࠻ᑂ")]
	VzdO8PuWbBNg = []
	jpJXL7t2R5dVi3KTO9Yl6DMnG = [ESXZrtnCfcDJGo01vFg(u"࠰ᑃ")]*EpoqUXNL3iRST1OPlj47YrVtmdZwy
	eKuj4OACMy8YPVlJr15NtDk = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡩ࡯ࡣࡵࠩᇊ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙࡟ࡔࡖࡄࡘ࡚࡙ࠧᇋ"))
	for euAXR1aTdUVQnJk687trEh in list(eKuj4OACMy8YPVlJr15NtDk.keys()):
		if website not in euAXR1aTdUVQnJk687trEh: continue
		PPmYnWkqTCfNH1u4yoRs,cRbVDX4Hrhm5PuvWeQiZJfzGqOY7 = euAXR1aTdUVQnJk687trEh.split(Nlyfx1HnzOWCovke5(u"࠭࡟ࡠࠩᇌ"))
		jpJXL7t2R5dVi3KTO9Yl6DMnG[int(cRbVDX4Hrhm5PuvWeQiZJfzGqOY7)] = eKuj4OACMy8YPVlJr15NtDk[euAXR1aTdUVQnJk687trEh]
	for l5jaqCcHr6PGJQSFgoKM0s in range(EpoqUXNL3iRST1OPlj47YrVtmdZwy):
		if l5jaqCcHr6PGJQSFgoKM0s in h9zFQKnsNL.BADSCRAPERS+pxn83GwezcTmlQCf4WFL: continue
		if l5jaqCcHr6PGJQSFgoKM0s==OS9GsTAan7yDVuc4XYpfqtPCj: jpJXL7t2R5dVi3KTO9Yl6DMnG[l5jaqCcHr6PGJQSFgoKM0s] = jpJXL7t2R5dVi3KTO9Yl6DMnG[l5jaqCcHr6PGJQSFgoKM0s]+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠲ᑄ")
		if jpJXL7t2R5dVi3KTO9Yl6DMnG[l5jaqCcHr6PGJQSFgoKM0s]<ESXZrtnCfcDJGo01vFg(u"࠵ᑅ"): VzdO8PuWbBNg += [l5jaqCcHr6PGJQSFgoKM0s]*ZEFwyl4LYUv3BDn[l5jaqCcHr6PGJQSFgoKM0s]
	if not VzdO8PuWbBNg:
		for l5jaqCcHr6PGJQSFgoKM0s in range(EpoqUXNL3iRST1OPlj47YrVtmdZwy):
			jpJXL7t2R5dVi3KTO9Yl6DMnG[l5jaqCcHr6PGJQSFgoKM0s] = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠳ᑆ")
			if l5jaqCcHr6PGJQSFgoKM0s in h9zFQKnsNL.BADSCRAPERS+pxn83GwezcTmlQCf4WFL: continue
			VzdO8PuWbBNg += [l5jaqCcHr6PGJQSFgoKM0s]*ZEFwyl4LYUv3BDn[l5jaqCcHr6PGJQSFgoKM0s]
	for l5jaqCcHr6PGJQSFgoKM0s in h9zFQKnsNL.BADSCRAPERS: jpJXL7t2R5dVi3KTO9Yl6DMnG[l5jaqCcHr6PGJQSFgoKM0s] = ynxXU3gaiQ9GPCftr1q(u"࠽࠾࠿࠹ᑇ")
	RUbhX9cQ8glkAWeVm = []
	for l5jaqCcHr6PGJQSFgoKM0s in range(EpoqUXNL3iRST1OPlj47YrVtmdZwy): RUbhX9cQ8glkAWeVm.append(website+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡠࡡࠪᇍ")+str(l5jaqCcHr6PGJQSFgoKM0s))
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,ynxXU3gaiQ9GPCftr1q(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪᇎ"),RUbhX9cQ8glkAWeVm,jpJXL7t2R5dVi3KTO9Yl6DMnG,iXb0godyOHYS7n4KuArN9FWp*MzgKWUQ4V5H(u"࠺ᑈ"),YOHXqtbQTBfKerIZ)
	return VzdO8PuWbBNg
def rGOT0oqaguXHlC5SZJz(V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,PvV97U5qtXD38GlIJBmsxFjrELn=Vk54F7GcROfCy6HunEI,euQMlv6PXcjI3mybnKsgtwBpHJ1=Vk54F7GcROfCy6HunEI,pxn83GwezcTmlQCf4WFL=[]):
	website = JlT9OB143U.split(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩ࠰ࠫᇏ"))[ufmXvxgoHGDwZtjsLkR05i]
	D0XI7ajmBPeo1 = UApE5IrWKhyHZ(website,pxn83GwezcTmlQCf4WFL)
	pZGDafn8c5w = []
	if website==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᇐ"):
		if ufmXvxgoHGDwZtjsLkR05i in D0XI7ajmBPeo1: pZGDafn8c5w += [ufmXvxgoHGDwZtjsLkR05i]
		if pwxH3oREFm5v98BCZ1QVtzMJOc in D0XI7ajmBPeo1: pZGDafn8c5w += [pwxH3oREFm5v98BCZ1QVtzMJOc]
		if RXnhpCUk4M1TvgJE in D0XI7ajmBPeo1: pZGDafn8c5w += [RXnhpCUk4M1TvgJE]
		if wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A in D0XI7ajmBPeo1: pZGDafn8c5w += [wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]*V2RQwM8XjlrK(u"࠷࠰ᑉ")
		if BZm7TqLPJfAVblDKsya85zFWXNMY in D0XI7ajmBPeo1: pZGDafn8c5w += [BZm7TqLPJfAVblDKsya85zFWXNMY]*m5DECdgjU4KqpVhyJ9A2b
		if m5DECdgjU4KqpVhyJ9A2b in D0XI7ajmBPeo1: pZGDafn8c5w += [m5DECdgjU4KqpVhyJ9A2b]*WCPwmyVsb62KRlo(u"࠱࠱ᑊ")
		if YzowicIDTRusXZSU61(u"࠷ᑋ") in D0XI7ajmBPeo1: pZGDafn8c5w += [YzowicIDTRusXZSU61(u"࠷ᑋ")]
		if SSBkx0WbN1asnDCQV6tIj(u"࠹ᑌ") in D0XI7ajmBPeo1: pZGDafn8c5w += [SSBkx0WbN1asnDCQV6tIj(u"࠹ᑌ")]
	elif website==Nlyfx1HnzOWCovke5(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ᇑ"):
		if wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A in D0XI7ajmBPeo1: pZGDafn8c5w += [wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A]*EM6qpnCBYQGA9kbgDVLfrP(u"࠴࠴ᑍ")
	elif website==WXuJd8nz2spo146t(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧᇒ"):
		if pwxH3oREFm5v98BCZ1QVtzMJOc in D0XI7ajmBPeo1: pZGDafn8c5w += [pwxH3oREFm5v98BCZ1QVtzMJOc]
		if BZm7TqLPJfAVblDKsya85zFWXNMY in D0XI7ajmBPeo1: pZGDafn8c5w += [BZm7TqLPJfAVblDKsya85zFWXNMY]*m5DECdgjU4KqpVhyJ9A2b
		if m5DECdgjU4KqpVhyJ9A2b in D0XI7ajmBPeo1: pZGDafn8c5w += [m5DECdgjU4KqpVhyJ9A2b]*ESXZrtnCfcDJGo01vFg(u"࠵࠵ᑎ")
		if V2RQwM8XjlrK(u"࠻ᑏ") in D0XI7ajmBPeo1: pZGDafn8c5w += [V2RQwM8XjlrK(u"࠻ᑏ")]
		if ynxXU3gaiQ9GPCftr1q(u"࠽ᑐ") in D0XI7ajmBPeo1: pZGDafn8c5w += [ynxXU3gaiQ9GPCftr1q(u"࠽ᑐ")]
	elif website==WCPwmyVsb62KRlo(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᇓ"):
		if BZm7TqLPJfAVblDKsya85zFWXNMY in D0XI7ajmBPeo1: pZGDafn8c5w += [BZm7TqLPJfAVblDKsya85zFWXNMY]*m5DECdgjU4KqpVhyJ9A2b
		if m5DECdgjU4KqpVhyJ9A2b in D0XI7ajmBPeo1: pZGDafn8c5w += [m5DECdgjU4KqpVhyJ9A2b]*kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠱࠱ᑑ")
	elif website==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨᇔ"):
		if WCPwmyVsb62KRlo(u"࠺ᑒ") in D0XI7ajmBPeo1: pZGDafn8c5w += [WCPwmyVsb62KRlo(u"࠺ᑒ")]*SSBkx0WbN1asnDCQV6tIj(u"࠳࠳ᑓ")
	elif website==ynxXU3gaiQ9GPCftr1q(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩᇕ"):
		if pwxH3oREFm5v98BCZ1QVtzMJOc in D0XI7ajmBPeo1: pZGDafn8c5w += [pwxH3oREFm5v98BCZ1QVtzMJOc]
		if m5DECdgjU4KqpVhyJ9A2b in D0XI7ajmBPeo1: pZGDafn8c5w += [m5DECdgjU4KqpVhyJ9A2b]*QYSAUI5r46yil8cfaO(u"࠴࠴ᑔ")
	elif website==MpJ8GOKoic(u"ࠩࡊࡓࡔࡍࡌࡆࡕࡈࡅࡗࡉࡈࠨᇖ"):
		if BZm7TqLPJfAVblDKsya85zFWXNMY in D0XI7ajmBPeo1: pZGDafn8c5w += [BZm7TqLPJfAVblDKsya85zFWXNMY]*m5DECdgjU4KqpVhyJ9A2b
	elif website==EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᇗ"):
		if m5DECdgjU4KqpVhyJ9A2b in D0XI7ajmBPeo1: pZGDafn8c5w += [m5DECdgjU4KqpVhyJ9A2b]*ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠵࠵ᑕ")
		if NNjUsZzEcFOAoKry2CDMgb1(u"࠻ᑖ") in D0XI7ajmBPeo1: pZGDafn8c5w += [NNjUsZzEcFOAoKry2CDMgb1(u"࠻ᑖ")]
		if ESXZrtnCfcDJGo01vFg(u"࠽ᑗ") in D0XI7ajmBPeo1: pZGDafn8c5w += [ESXZrtnCfcDJGo01vFg(u"࠽ᑗ")]
		if V2RQwM8XjlrK(u"࠸ᑘ") in D0XI7ajmBPeo1: pZGDafn8c5w += [V2RQwM8XjlrK(u"࠸ᑘ")]
	elif website==NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ᇘ"):
		pZGDafn8c5w = []
	if pZGDafn8c5w: D0XI7ajmBPeo1 = pZGDafn8c5w
	if D0XI7ajmBPeo1:
		RDhlUSfqLmOVjKdCcQZMu1 = budUNB9jgpI8Pm5.sample(D0XI7ajmBPeo1,pwxH3oREFm5v98BCZ1QVtzMJOc)[ufmXvxgoHGDwZtjsLkR05i]
	else: RDhlUSfqLmOVjKdCcQZMu1 = -pwxH3oREFm5v98BCZ1QVtzMJOc
	nV0el8hbG1YxLwOH9E = SSBkx0WbN1asnDCQV6tIj(u"ู๊ࠬาใิࠤึ่ๅࠡࠩᇙ")+str(RDhlUSfqLmOVjKdCcQZMu1)
	iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᇚ")+str(RDhlUSfqLmOVjKdCcQZMu1)+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᇛ")+str(PvV97U5qtXD38GlIJBmsxFjrELn)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᇜ")+euQMlv6PXcjI3mybnKsgtwBpHJ1+g7yJo2LVuqx1trPe(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇝ")+JlT9OB143U+MpJ8GOKoic(u"ࠪࠤࡢࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᇞ")+hj50MJnoOp6ZWaS1IQ8Elr+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࠥࡣࠧᇟ"))
	qJAOp7HgfKeMQkDau(MzgKWUQ4V5H(u"ࠬฮฯฤฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇠ"),nV0el8hbG1YxLwOH9E,Gb6kwVlSQ4MU=HOxJyt7l8osNeCjZFMQGi4Sr(u"࠶࠲࠳ᑙ"))
	update = YOHXqtbQTBfKerIZ
	if RDhlUSfqLmOVjKdCcQZMu1==ufmXvxgoHGDwZtjsLkR05i:
		scraperserver = YzowicIDTRusXZSU61(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠳ࠪᇡ")
		g4jky7ZYVmp1 = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯࠾࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠾࠺࠹࠵࠴ࠩᇢ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+wAU9jKvmTM0(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇣ")+g4jky7ZYVmp1+eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇤ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==pwxH3oREFm5v98BCZ1QVtzMJOc:
		scraperserver = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠸ࠧᇥ")
		g4jky7ZYVmp1 = QYSAUI5r46yil8cfaO(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭ᇦ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+ESXZrtnCfcDJGo01vFg(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇧ")+g4jky7ZYVmp1+FGLEMi21Bfn(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇨ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==RXnhpCUk4M1TvgJE:
		scraperserver = pnkrd2S84FJfN73KuiCYv(u"ࠧࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬ࠫᇩ")
		g4jky7ZYVmp1 = jXWzIZcDva4ikEUfN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠾࡫࡯࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧᇪ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+WsklGNp2CYzVQUag(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇫ")+g4jky7ZYVmp1+wAU9jKvmTM0(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇬ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A:
		scraperserver = ynxXU3gaiQ9GPCftr1q(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ᇭ")
		ynmiDuav5ICTeRsqj6Vb18Q = hj50MJnoOp6ZWaS1IQ8Elr.replace(WXuJd8nz2spo146t(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧᇮ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧᇯ"))
		xIZTXEQJ7qtmF = ESXZrtnCfcDJGo01vFg(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲࡨࡹࡵ࠴ࡣࡰ࡯࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠩ࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡉࡥࡱࡹࡥࠧࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮ࠩࡹࡷࡲ࠽ࠨᇰ")+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(ynmiDuav5ICTeRsqj6Vb18Q)
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡉࡈࡘࠬᇱ"),xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==BZm7TqLPJfAVblDKsya85zFWXNMY:
		scraperserver = QYSAUI5r46yil8cfaO(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵࠩᇲ")
		xIZTXEQJ7qtmF = WsklGNp2CYzVQUag(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺ࠮ࡤࡱࡰ࠳ࡄࡺ࡯࡬ࡧࡱࡁࡦ࠺ࡦ࠸ࡨࡥ࠵࠹࠳࠲ࡥࡧࡩ࠱࠹࠶࠷࠲࠯࠻࠺࠹ࡨ࠭࠳࠴ࡨ࠷࠷࠼࠴ࡥ࠶ࡧࡨࡨࠬࡰࡳࡱࡻࡽࡈࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡷࡵࡰࡂ࠭ᇳ")+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(hj50MJnoOp6ZWaS1IQ8Elr)
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡌࡋࡔࠨᇴ"),xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
		try:
			IeBwLgl8iZvptJhq1sHRzfWkQGu3.content = Bw6jaUcFxlqdDT8bC(WCPwmyVsb62KRlo(u"ࠬࡪࡩࡤࡶࠪᇵ"),IeBwLgl8iZvptJhq1sHRzfWkQGu3.content)
			IeBwLgl8iZvptJhq1sHRzfWkQGu3.content = IeBwLgl8iZvptJhq1sHRzfWkQGu3.content[BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᇶ")]
		except: pass
	elif RDhlUSfqLmOVjKdCcQZMu1==m5DECdgjU4KqpVhyJ9A2b:
		scraperserver = MpJ8GOKoic(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠶࠭ᇷ")
		g4jky7ZYVmp1 = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡥࡶࡴࡽࡳࡦࡴࡀࡊࡦࡲࡳࡦࠨࡩࡳࡷࡽࡡࡳࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠼࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠲ࡨࡵ࡭࠻࠺࠳࠼࠵࠭ᇸ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇹ")+g4jky7ZYVmp1+XCYALgFs2O3hZdpHrlMmB(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇺ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸ᑚ"):
		scraperserver = YzowicIDTRusXZSU61(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠱ࠨᇻ")
		g4jky7ZYVmp1 = ESXZrtnCfcDJGo01vFg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡣ࠳࠸࠶ࡥࡧ࠷ࡥ࠶࠲࠷࠸ࡩ࠸ࡣࡢ࠷ࡧ࠹ࡩ࠹ࡦ࠺ࡧ࠶ࡧ࠸࠾࠶ࡦࡥࡤ࠵࠶࠶࠸࠴࠺࠼ࡥ࠼࠹࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩࠫ࡭ࡥࡰࡅࡲࡨࡪࡃࡩ࡭ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩᇼ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+YzowicIDTRusXZSU61(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᇽ")+g4jky7ZYVmp1+pnkrd2S84FJfN73KuiCYv(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᇾ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==wAU9jKvmTM0(u"࠺ᑛ"):
		scraperserver = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬᇿ")
		g4jky7ZYVmp1 = NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦࠨࡪࡩࡴࡉ࡯ࡥࡧࡀ࡭ࡱࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ሀ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+ESXZrtnCfcDJGo01vFg(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪሁ")+g4jky7ZYVmp1+wAU9jKvmTM0(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫሂ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==EM6qpnCBYQGA9kbgDVLfrP(u"࠼ᑜ"):
		scraperserver = WsklGNp2CYzVQUag(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩሃ")
		xIZTXEQJ7qtmF = ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭ࠨࡸࡶࡱࡃࠧሄ")+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(hj50MJnoOp6ZWaS1IQ8Elr)
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡈࡇࡗࠫህ"),xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	elif RDhlUSfqLmOVjKdCcQZMu1==pnkrd2S84FJfN73KuiCYv(u"࠾ᑝ"):
		scraperserver = V2RQwM8XjlrK(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠸ࠧሆ")
		g4jky7ZYVmp1 = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡶࡪࡺࡵࡳࡰࡢࡴࡦ࡭ࡥࡠࡵࡲࡹࡷࡩࡥ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪሇ")
		xIZTXEQJ7qtmF = hj50MJnoOp6ZWaS1IQ8Elr+eAMGzHRQVs2KyCwPXljYhB(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪለ")+g4jky7ZYVmp1+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫሉ")
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = yPi9tYgLIMo2qW1f5Arp68c(V3EjC5wJlI,xIZTXEQJ7qtmF,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	else:
		scraperserver,xIZTXEQJ7qtmF = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
		IeBwLgl8iZvptJhq1sHRzfWkQGu3 = O8O0UxfNrsRKdw9()
		update = eu1NswY9zkKC60I
	if update and not IeBwLgl8iZvptJhq1sHRzfWkQGu3.succeeded:
		UApE5IrWKhyHZ(website,[],RDhlUSfqLmOVjKdCcQZMu1)
		if len(list(set(D0XI7ajmBPeo1)))>pwxH3oREFm5v98BCZ1QVtzMJOc:
			W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨሊ"),g7yJo2LVuqx1trPe(u"࠭ไๅลึๅู๊ࠥาใิࠤ๊฿วๅฮฬࠤฬ๊ออสࠣี็๋ࠠࠨላ")+str(RDhlUSfqLmOVjKdCcQZMu1)+EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠡใื่ࠥ็๊ࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢอะฬ๎าࠡษ็ััฮࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤุ๐ัโำ้ࠣำะไโࠢยࠥࠬሌ"))
			if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
				pxn83GwezcTmlQCf4WFL.append(RDhlUSfqLmOVjKdCcQZMu1)
				IeBwLgl8iZvptJhq1sHRzfWkQGu3 = rGOT0oqaguXHlC5SZJz(V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,QQxtB4R1grIyH5blGpT2LDdP6,QLR0TuBGvEincdzjlUKO48g3IWPpo,JlT9OB143U,PvV97U5qtXD38GlIJBmsxFjrELn,euQMlv6PXcjI3mybnKsgtwBpHJ1,pxn83GwezcTmlQCf4WFL)
				return IeBwLgl8iZvptJhq1sHRzfWkQGu3
	IeBwLgl8iZvptJhq1sHRzfWkQGu3.scrapernumber = str(RDhlUSfqLmOVjKdCcQZMu1)
	scraperserver = scraperserver+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࠢ࠽ࠤࠬል")+str(RDhlUSfqLmOVjKdCcQZMu1)
	IeBwLgl8iZvptJhq1sHRzfWkQGu3.scraperserver = scraperserver
	IeBwLgl8iZvptJhq1sHRzfWkQGu3.scraperurl = xIZTXEQJ7qtmF
	if IeBwLgl8iZvptJhq1sHRzfWkQGu3.succeeded:
		iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩሎ")+scraperserver+jXWzIZcDva4ikEUfN(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬሏ")+JlT9OB143U+XCYALgFs2O3hZdpHrlMmB(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሐ")+hj50MJnoOp6ZWaS1IQ8Elr+ynxXU3gaiQ9GPCftr1q(u"ࠬࠦ࡝ࠨሑ"))
		qJAOp7HgfKeMQkDau(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨሒ"),nV0el8hbG1YxLwOH9E,Gb6kwVlSQ4MU=EM6qpnCBYQGA9kbgDVLfrP(u"࠻࠰࠱ᑞ"))
	else:
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫሓ")+scraperserver+XCYALgFs2O3hZdpHrlMmB(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨሔ")+str(IeBwLgl8iZvptJhq1sHRzfWkQGu3.code)+NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫሕ")+IeBwLgl8iZvptJhq1sHRzfWkQGu3.reason+WCPwmyVsb62KRlo(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬሖ")+JlT9OB143U+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሗ")+hj50MJnoOp6ZWaS1IQ8Elr+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࠦ࡝ࠨመ"))
		qJAOp7HgfKeMQkDau(eAMGzHRQVs2KyCwPXljYhB(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨሙ"),nV0el8hbG1YxLwOH9E,Gb6kwVlSQ4MU=ESXZrtnCfcDJGo01vFg(u"࠵࠱࠲ᑟ"))
	return IeBwLgl8iZvptJhq1sHRzfWkQGu3
def CZifHvYTr5oWzn7ecOS6(zpkoYB8x4vLuScXFiKPqOtRAj,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,showDialogs,JlT9OB143U):
	if not MFWydLr2JXCuVlUgAw9ERH8Yoiep or isinstance(MFWydLr2JXCuVlUgAw9ERH8Yoiep,dict): V3EjC5wJlI = QYSAUI5r46yil8cfaO(u"ࠧࡈࡇࡗࠫሚ")
	else:
		V3EjC5wJlI = Nlyfx1HnzOWCovke5(u"ࠨࡒࡒࡗ࡙࠭ማ")
		MFWydLr2JXCuVlUgAw9ERH8Yoiep = ZlBMJUAWRm9buv(MFWydLr2JXCuVlUgAw9ERH8Yoiep)
		HPAsT0b3IypCvLa,MFWydLr2JXCuVlUgAw9ERH8Yoiep = vULz8h3qpug7jMCVHQcRZ(MFWydLr2JXCuVlUgAw9ERH8Yoiep)
	s63mcpoNbCT79FW0dOfauhYrRyLV = LOp5or14udNYRXFKDxwh(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,YOHXqtbQTBfKerIZ,showDialogs,JlT9OB143U)
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = s63mcpoNbCT79FW0dOfauhYrRyLV.content
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = str(UwghkPtqZiWTvsMLrl5dc0nuOAQ)
	return UwghkPtqZiWTvsMLrl5dc0nuOAQ
def ppD6ewtT4LyNSgXxIQqYaA9U(N39NCXDAaVnx):
	WKhuUiZrSXB5 = N39NCXDAaVnx.split(wAU9jKvmTM0(u"ࠩࡿࢀࠬሜ"))
	hj50MJnoOp6ZWaS1IQ8Elr,SsAcDJaR2NuE7p4ZkO,ii5oPt8ldEp,HabAZ8CldGFjyvh = WKhuUiZrSXB5[ufmXvxgoHGDwZtjsLkR05i],tayEeSpKRJIdC8g10,tayEeSpKRJIdC8g10,YOHXqtbQTBfKerIZ
	for L39t14lv2dr7IYqxERZM in WKhuUiZrSXB5:
		if WXuJd8nz2spo146t(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨም") in L39t14lv2dr7IYqxERZM: SsAcDJaR2NuE7p4ZkO = L39t14lv2dr7IYqxERZM[cpHxZyU7vTtqmIw(u"࠲࠳ᑠ"):]
		elif QYSAUI5r46yil8cfaO(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧሞ") in L39t14lv2dr7IYqxERZM: ii5oPt8ldEp = L39t14lv2dr7IYqxERZM[MpJ8GOKoic(u"࠻ᑡ"):]
		elif l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪሟ") in L39t14lv2dr7IYqxERZM: HabAZ8CldGFjyvh = eu1NswY9zkKC60I
	return hj50MJnoOp6ZWaS1IQ8Elr,SsAcDJaR2NuE7p4ZkO,ii5oPt8ldEp,HabAZ8CldGFjyvh
def yae3sluFEcw(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,N39NCXDAaVnx,Et1fIgXTHcDW6BA,Pd7TIF5KcZh6raA2HeOby,LCQZEdgqs49r0j1xK2F,imAJgoKCHE3DrTVOnPlf=Vk54F7GcROfCy6HunEI):
	MAhWdoVDftUl6 = RRav1Sf7Px(N39NCXDAaVnx,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡵࡳ࡮ࠪሠ"))
	lW0D19hzG78veAdF4fXT = cad8TeSyMUYmfsEO0.getSetting(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩሡ")+Et1fIgXTHcDW6BA)
	if MAhWdoVDftUl6==lW0D19hzG78veAdF4fXT: cad8TeSyMUYmfsEO0.setSetting(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪሢ")+Et1fIgXTHcDW6BA,Vk54F7GcROfCy6HunEI)
	if lW0D19hzG78veAdF4fXT: ynmiDuav5ICTeRsqj6Vb18Q = N39NCXDAaVnx.replace(MAhWdoVDftUl6,lW0D19hzG78veAdF4fXT)
	else:
		ynmiDuav5ICTeRsqj6Vb18Q = N39NCXDAaVnx
		lW0D19hzG78veAdF4fXT = MAhWdoVDftUl6
	dey3bshxM9ST6o = LOp5or14udNYRXFKDxwh(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,imAJgoKCHE3DrTVOnPlf,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭ሣ"))
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = dey3bshxM9ST6o.content
	if PvwFsJK23NbU8XWAx:
		try: UwghkPtqZiWTvsMLrl5dc0nuOAQ = UwghkPtqZiWTvsMLrl5dc0nuOAQ.decode(AoCWwJHgUPKXI7u2lEzym,jXWzIZcDva4ikEUfN(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪሤ"))
		except: pass
	if not dey3bshxM9ST6o.succeeded or LCQZEdgqs49r0j1xK2F not in UwghkPtqZiWTvsMLrl5dc0nuOAQ:
		Pd7TIF5KcZh6raA2HeOby = Pd7TIF5KcZh6raA2HeOby.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࠰࠭ሥ"))
		hj50MJnoOp6ZWaS1IQ8Elr = ESXZrtnCfcDJGo01vFg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪሦ")+Pd7TIF5KcZh6raA2HeOby
		eDbTIrV6KLfz80 = {V2RQwM8XjlrK(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪሧ"):Vk54F7GcROfCy6HunEI}
		HHA0ZI3kaPXocl7CsGjr = LOp5or14udNYRXFKDxwh(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫረ"))
		if HHA0ZI3kaPXocl7CsGjr.succeeded:
			UwghkPtqZiWTvsMLrl5dc0nuOAQ = HHA0ZI3kaPXocl7CsGjr.content
			if PvwFsJK23NbU8XWAx:
				try: UwghkPtqZiWTvsMLrl5dc0nuOAQ = UwghkPtqZiWTvsMLrl5dc0nuOAQ.decode(AoCWwJHgUPKXI7u2lEzym,wAU9jKvmTM0(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨሩ"))
				except: pass
			HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪሪ"),UwghkPtqZiWTvsMLrl5dc0nuOAQ,RSuYINdeamsK0t.DOTALL)
			HydkEuWzciBPm5GbNlq = [lW0D19hzG78veAdF4fXT]
			zPkxGshr9QNSqBHn7FfTCVYJ = [kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡥࡵࡱࠧራ"),SSBkx0WbN1asnDCQV6tIj(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫሬ"),Nlyfx1HnzOWCovke5(u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭ር"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧሮ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩሯ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡲ࡫ࡴࠬሰ"),ynxXU3gaiQ9GPCftr1q(u"ࠩࡤࡸࡱࡧࡱࠨሱ"),XCYALgFs2O3hZdpHrlMmB(u"ࠪࡷ࡮ࡺࡥࡪࡰࡧ࡭ࡨ࡫ࡳࠨሲ"),jXWzIZcDva4ikEUfN(u"ࠫࡸࡻࡲ࠯࡮ࡼࠫሳ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧሴ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡩ࡯ࡨࡲࡶࡲ࡫ࡲࠨስ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡴ࡫ࡷࡩࡱ࡯࡫ࡦࠩሶ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࡫ࡱࡷࡹࡧࡧࡳࡣࡰࠫሷ"),jXWzIZcDva4ikEUfN(u"ࠩࡶࡲࡦࡶࡣࡩࡣࡷࠫሸ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪ࡬ࡹࡺࡰ࠮ࡧࡴࡹ࡮ࡼࠧሹ"),jXWzIZcDva4ikEUfN(u"ࠫ࡫ࡧࡳࡦ࡮ࡳࡰࡺࡹࠧሺ")]
			for z9q2ova0OhKP1XemlViUbdx7Zu in HXhRgxEZ4d2Dek:
				if any(value in z9q2ova0OhKP1XemlViUbdx7Zu for value in zPkxGshr9QNSqBHn7FfTCVYJ): continue
				lW0D19hzG78veAdF4fXT = RRav1Sf7Px(z9q2ova0OhKP1XemlViUbdx7Zu,WsklGNp2CYzVQUag(u"ࠬࡻࡲ࡭ࠩሻ"))
				if lW0D19hzG78veAdF4fXT in HydkEuWzciBPm5GbNlq: continue
				if len(HydkEuWzciBPm5GbNlq)==WsklGNp2CYzVQUag(u"࠼ᑢ"):
					iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ሼ")+Et1fIgXTHcDW6BA+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬሽ")+MAhWdoVDftUl6+pnkrd2S84FJfN73KuiCYv(u"ࠨࠢࡠࠫሾ"))
					cad8TeSyMUYmfsEO0.setSetting(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሿ")+Et1fIgXTHcDW6BA,Vk54F7GcROfCy6HunEI)
					break
				HydkEuWzciBPm5GbNlq.append(lW0D19hzG78veAdF4fXT)
				ynmiDuav5ICTeRsqj6Vb18Q = N39NCXDAaVnx.replace(MAhWdoVDftUl6,lW0D19hzG78veAdF4fXT)
				dey3bshxM9ST6o = LOp5or14udNYRXFKDxwh(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,imAJgoKCHE3DrTVOnPlf,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧቀ"))
				UwghkPtqZiWTvsMLrl5dc0nuOAQ = dey3bshxM9ST6o.content
				if dey3bshxM9ST6o.succeeded and LCQZEdgqs49r0j1xK2F in UwghkPtqZiWTvsMLrl5dc0nuOAQ:
					iQlMPpRZXWLd(ffiklMUwZtgvO3CmG,ySVOsdu270(TVPm7Bz1XOwJ2)+wYTDlJC5vpOKynUEX3ge6W(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫቁ")+Et1fIgXTHcDW6BA+SSBkx0WbN1asnDCQV6tIj(u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫቂ")+lW0D19hzG78veAdF4fXT+WCPwmyVsb62KRlo(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫቃ")+MAhWdoVDftUl6+FGLEMi21Bfn(u"ࠧࠡ࡟ࠪቄ"))
					cad8TeSyMUYmfsEO0.setSetting(g7yJo2LVuqx1trPe(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪቅ")+Et1fIgXTHcDW6BA,lW0D19hzG78veAdF4fXT)
					break
	return lW0D19hzG78veAdF4fXT,ynmiDuav5ICTeRsqj6Vb18Q,dey3bshxM9ST6o
def rLjksYNqhOBoHl3WREm8p(RRG6QsiOkKU0ChovTBY3qdf):
	hxd2OJqbWXv6 = {
	 ESXZrtnCfcDJGo01vFg(u"ࠩࡤ࡬ࡼࡧ࡫ࠨቆ")				:MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬቇ")
	,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡦࡱ࡯ࡢ࡯ࠪቈ")				:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩ቉")
	,MpJ8GOKoic(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨቊ")				:Nlyfx1HnzOWCovke5(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨቋ")
	,WsklGNp2CYzVQUag(u"ࠨࡣ࡮ࡻࡦࡳࠧቌ")				:cpHxZyU7vTtqmIw(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ቍ")
	,cpHxZyU7vTtqmIw(u"ࠪࡥࡰࡽࡡ࡮ࡶࡸࡦࡪ࠭቎")			:MpJ8GOKoic(u"๊ࠫ๎โฺࠢส็ํอๅࠡฬํ์อ࠭቏")
	,EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬቐ")				:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ቑ")
	,ynxXU3gaiQ9GPCftr1q(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩቒ")				:cpHxZyU7vTtqmIw(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧቓ")
	,Nlyfx1HnzOWCovke5(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬቔ")			:MzgKWUQ4V5H(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭ቕ")
	,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭ቖ")				:wYTDlJC5vpOKynUEX3ge6W(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ቗")
	,wAU9jKvmTM0(u"࠭ࡡ࡭࡯ࡶࡸࡧࡧࠧቘ")				:ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧๆ๊ๅ฽ࠥอไๆืฺฬฮ࠭቙")
	,Nlyfx1HnzOWCovke5(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪቚ")				:wAU9jKvmTM0(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨቛ")
	,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨቜ")			:HOxJyt7l8osNeCjZFMQGi4Sr(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ቝ")
	,V2RQwM8XjlrK(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ቞")				:Nlyfx1HnzOWCovke5(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭቟")
	,WsklGNp2CYzVQUag(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩበ")				:MpJ8GOKoic(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩቡ")
	,jXWzIZcDva4ikEUfN(u"ࠩࡤࡽࡱࡵ࡬ࠨቢ")				:ITXLHQdeVC2icEOAU8hqG470afPB3(u"้ࠪํู่ࠡลํ่ํ๊ࠧባ")
	,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡧࡵ࡫ࡳࡣࠪቤ")				:ogJClMiqPa4A0NUtTxpDVybEWG(u"๋่ࠬใ฻ࠣฬ่ืวࠨብ")
	,QYSAUI5r46yil8cfaO(u"࠭ࡢࡳࡵࡷࡩ࡯࠭ቦ")				:WCPwmyVsb62KRlo(u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬቧ")
	,MpJ8GOKoic(u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩቨ")				:jXWzIZcDva4ikEUfN(u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩቩ")
	,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡧ࡮ࡳࡡ࠵ࡲࠪቪ")				:HOxJyt7l8osNeCjZFMQGi4Sr(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิࠤอ๐ࠧቫ")
	,ynxXU3gaiQ9GPCftr1q(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬቬ")				:wYTDlJC5vpOKynUEX3ge6W(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨቭ")
	,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩቮ")				:BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩቯ")
	,WXuJd8nz2spo146t(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫተ")				:ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫቱ")
	,g7yJo2LVuqx1trPe(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪቲ")			:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪታ")
	,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨቴ")				:QYSAUI5r46yil8cfaO(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨት")
	,jXWzIZcDva4ikEUfN(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪቶ")				:wAU9jKvmTM0(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪቷ")
	,cpHxZyU7vTtqmIw(u"ࠪࡧ࡮ࡳࡡࡧࡴࡨࡩࠬቸ")				:FGLEMi21Bfn(u"๊ࠫ๎โฺࠢึ๎๊อࠠโำํࠫቹ")
	,g7yJo2LVuqx1trPe(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨቺ")			:ynxXU3gaiQ9GPCftr1q(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧቻ")
	,SSBkx0WbN1asnDCQV6tIj(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨቼ")				:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨች")
	,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡦ࡭ࡲࡧࡷࡣࡣࡶࠫቾ")				:YzowicIDTRusXZSU61(u"้ࠪํู่ࠡีํ้ฬ่ࠦษีࠪቿ")
	,wAU9jKvmTM0(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩኀ")			:jXWzIZcDva4ikEUfN(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠧኁ")
	,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ኂ")	:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢืฯิฯๆ์้ࠫኃ")
	,NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡨࡢࡵ࡫ࡸࡦ࡭ࡳࠨኄ")	:MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫኅ")
	,YzowicIDTRusXZSU61(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮࡮࡬ࡺࡪࡹࠧኆ")	:MzgKWUQ4V5H(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅษษืีࠬኇ")
	,NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ኈ"):NNjUsZzEcFOAoKry2CDMgb1(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧ኉")
	,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬኊ")	:WCPwmyVsb62KRlo(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪኋ")
	,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧኌ")	:MzgKWUQ4V5H(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧኍ")
	,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭኎")				:Nlyfx1HnzOWCovke5(u"๋ࠬส้ไไࠫ኏")
	,ESXZrtnCfcDJGo01vFg(u"࠭ࡤࡳࡣࡰࡥࡨࡧࡦࡦࠩነ")			:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤ่อแ๋้ࠪኑ")
	,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩኒ")				:Nlyfx1HnzOWCovke5(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩና")
	,ESXZrtnCfcDJGo01vFg(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫኔ")				:MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬን")
	,FGLEMi21Bfn(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧኖ")				:BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩኗ")
	,MpJ8GOKoic(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩኘ")				:ESXZrtnCfcDJGo01vFg(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫኙ")
	,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫኚ")				:ESXZrtnCfcDJGo01vFg(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭ኛ")
	,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭ኜ")				:WXuJd8nz2spo146t(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨኝ")
	,WXuJd8nz2spo146t(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪኞ")			:NNjUsZzEcFOAoKry2CDMgb1(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬኟ")
	,wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩአ")				:SSBkx0WbN1asnDCQV6tIj(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩኡ")
	,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪኢ")				:Nlyfx1HnzOWCovke5(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫኣ")
	,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧኤ")				:wAU9jKvmTM0(u"࠭ๅ้ไ฼ࠤ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬእ")
	,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡦ࡮࡬ࡪࡻ࡯ࡤࡦࡱࠪኦ")			:kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨ็๋ๆ฾ࠦรๅ์ไࠤๆ๐ฯ๋๊ࠪኧ")
	,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪከ")				:wAU9jKvmTM0(u"้ࠪํู่ࠡใหี่ฯࠧኩ")
	,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫኪ")				:Nlyfx1HnzOWCovke5(u"ࠬ็ิๅࠩካ")
	,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩኬ")			:kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬክ")
	,V2RQwM8XjlrK(u"ࠨࡨࡤࡶࡪࡹ࡫ࡰࠩኮ")				:HOxJyt7l8osNeCjZFMQGi4Sr(u"่ࠩ์็฿ࠠโษิื่๎ࠧኯ")
	,V2RQwM8XjlrK(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬኰ")				:kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭኱")
	,WsklGNp2CYzVQUag(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧኲ")				:BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩኳ")
	,YzowicIDTRusXZSU61(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧኴ")				:ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ็ฯ่ิ࠭ኵ")
	,jXWzIZcDva4ikEUfN(u"ࠩࡩࡳࡸࡺࡡࠨ኶")				:SSBkx0WbN1asnDCQV6tIj(u"้ࠪํู่ࠡใ๋ืฯอࠧ኷")
	,WCPwmyVsb62KRlo(u"ࠫ࡫ࡻ࡮ࡰࡰࡷࡺࠬኸ")				:jXWzIZcDva4ikEUfN(u"๋่ࠬใ฻ࠣๅ๋๎ๆࠡฬํๅ๏࠭ኹ")
	,XCYALgFs2O3hZdpHrlMmB(u"࠭ࡦࡶࡵ࡫ࡥࡷࡺࡶࠨኺ")				:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤฯ๐แ๋ࠩኻ")
	,cpHxZyU7vTtqmIw(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ኼ")			:YzowicIDTRusXZSU61(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬኽ")
	,SSBkx0WbN1asnDCQV6tIj(u"ࠪ࡫ࡴࡵࡤࠨኾ")					:ESXZrtnCfcDJGo01vFg(u"ࠫั๐ฯࠨ኿")
	,V2RQwM8XjlrK(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧዀ")				:ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭዁")
	,WsklGNp2CYzVQUag(u"ࠧࡩࡧ࡯ࡥࡱ࠭ዂ")				:ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫዃ")
	,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨዄ")				:WCPwmyVsb62KRlo(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧዅ")
	,MpJ8GOKoic(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪ዆")			:wAU9jKvmTM0(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧ዇")
	,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭ወ")		:wYTDlJC5vpOKynUEX3ge6W(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬዉ")
	,MzgKWUQ4V5H(u"ࠨ࡫ࡳࡸࡻ࠭ዊ")					:ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡌࡔ࡙࡜ࠧዋ")
	,WsklGNp2CYzVQUag(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ዌ")			:wAU9jKvmTM0(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨው")
	,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪዎ")			:XCYALgFs2O3hZdpHrlMmB(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪዏ")
	,Nlyfx1HnzOWCovke5(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬዐ")			:BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧዑ")
	,Nlyfx1HnzOWCovke5(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬዒ")			:BBflQamoVNRxMegHLKUvW6s9yAhP(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭ዓ")
	,pnkrd2S84FJfN73KuiCYv(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ዔ")				:kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧዕ")
	,g7yJo2LVuqx1trPe(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨዖ")				:MzgKWUQ4V5H(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫ዗")
	,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ࡭࡬ࡶࡲࡧ࡬࡬ࠩዘ")				:pnkrd2S84FJfN73KuiCYv(u"่ࠩ์็฿ࠠไำ่ห้้ࠧዙ")
	,Nlyfx1HnzOWCovke5(u"ࠪࡰࡦࡸ࡯ࡻࡣࠪዚ")				:ogJClMiqPa4A0NUtTxpDVybEWG(u"๊ࠫ๎โฺࠢ็หึ๎าศࠩዛ")
	,QYSAUI5r46yil8cfaO(u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭ዜ")				:Nlyfx1HnzOWCovke5(u"࠭ๅๅใࠪዝ")
	,V2RQwM8XjlrK(u"ࠧ࡭࡫ࡹࡩࠬዞ")					:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨไ้หฮ࠭ዟ")
	,jXWzIZcDva4ikEUfN(u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩዠ")				:XCYALgFs2O3hZdpHrlMmB(u"้้ࠪ็ࠧዡ")
	,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬዢ")				:MzgKWUQ4V5H(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫዣ")
	,NNjUsZzEcFOAoKry2CDMgb1(u"࠭࡭࠴ࡷࠪዤ")					:wAU9jKvmTM0(u"ࠧࡎ࠵ࡘࠫዥ")
	,WCPwmyVsb62KRlo(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪዦ")				:MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬዧ")
	,ynxXU3gaiQ9GPCftr1q(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧየ")			:ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧዩ")
	,wAU9jKvmTM0(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩዪ")			:MpJ8GOKoic(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫያ")
	,NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱࠪዬ")			:ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ็๋ๆ฾ࠦๅศีสࠤๆ๐ฯ๋๊ࠪይ")
	,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪዮ")				:eAMGzHRQVs2KyCwPXljYhB(u"้ࠪๆ่่ะࠩዯ")
	,YzowicIDTRusXZSU61(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫደ")				:ynxXU3gaiQ9GPCftr1q(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧዱ")
	,YzowicIDTRusXZSU61(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ዲ")				:ynxXU3gaiQ9GPCftr1q(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧዳ")
	,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡱ࡯ࡨࠬዴ")					:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩๅำ๏๋ࠧድ")
	,EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡴࡦࡴࡥࡵࠩዶ")				:ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"๊ࠫ๎โฺࠢหห๋๐สࠨዷ")
	,YzowicIDTRusXZSU61(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫዸ")			:cpHxZyU7vTtqmIw(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩዹ")
	,MzgKWUQ4V5H(u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ዺ")			:ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ዻ")
	,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡴࡪ࡮ࡲ࡭ࠨዼ")				:kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"้ࠪํู่ࠡๅํ์ࠥ็๊ๅ็ࠪዽ")
	,WsklGNp2CYzVQUag(u"ࠫࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥࠨዾ")			:MpJ8GOKoic(u"๋่ࠬใ฻ࠣื๏ื๊ิࠢอห๏๋ࠧዿ")
	,WXuJd8nz2spo146t(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩጀ")			:MzgKWUQ4V5H(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫጁ")
	,jXWzIZcDva4ikEUfN(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪጂ")				:BBflQamoVNRxMegHLKUvW6s9yAhP(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫጃ")
	,cpHxZyU7vTtqmIw(u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧጄ")			:SSBkx0WbN1asnDCQV6tIj(u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬጅ")
	,cpHxZyU7vTtqmIw(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨጆ")			:MzgKWUQ4V5H(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨጇ")
	,MpJ8GOKoic(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪገ")		:g7yJo2LVuqx1trPe(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩጉ")
	,WsklGNp2CYzVQUag(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬጊ")		:BBflQamoVNRxMegHLKUvW6s9yAhP(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬጋ")
	,wAU9jKvmTM0(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨጌ")	:QYSAUI5r46yil8cfaO(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬግ")
	,V2RQwM8XjlrK(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭ጎ")				:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩጏ")
	,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡵ࡫ࡳࡴ࡬࡭ࡢࡺࠪጐ")				:SSBkx0WbN1asnDCQV6tIj(u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩ጑")
	,V2RQwM8XjlrK(u"ࠪࡷ࡭ࡵ࡯ࡧࡰࡨࡸࠬጒ")				:wAU9jKvmTM0(u"๊ࠫ๎โฺࠢื์ๆࠦๆหࠩጓ")
	,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧጔ")				:SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬጕ")
	,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡵ࡫࡮ࡥࡦࡺࠧ጖")				:ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨ็๋ๆ฾ࠦสไษอࠫ጗")
	,g7yJo2LVuqx1trPe(u"ࠩࡷࡺ࡫ࡻ࡮ࠨጘ")				:WXuJd8nz2spo146t(u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪጙ")
	,MzgKWUQ4V5H(u"ࠫࡻࡧࡲࡣࡱࡱࠫጚ")				:cpHxZyU7vTtqmIw(u"๋่ࠬใ฻ࠣๅฬืศ้่ࠪጛ")
	,SSBkx0WbN1asnDCQV6tIj(u"࠭ࡶࡪࡦࡨࡳࠬጜ")				:jXWzIZcDva4ikEUfN(u"ࠧโ์า๎ํ࠭ጝ")
	,MpJ8GOKoic(u"ࠨࡸ࡬ࡨࡪࡵ࡮ࡴࡣࡨࡱࠬጞ")			:YzowicIDTRusXZSU61(u"่ࠩ์็฿ࠠโ์า๎ํࠦๆิษษ้ࠬጟ")
	,WXuJd8nz2spo146t(u"ࠪࡻࡪࡩࡩ࡮ࡣ࠴ࠫጠ")				:EM6qpnCBYQGA9kbgDVLfrP(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠣ࠵ࠬጡ")
	,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡽࡥࡤ࡫ࡰࡥ࠷࠭ጢ")				:WXuJd8nz2spo146t(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠥ࠸ࠧጣ")
	,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡺࡣࡴࡳࡹ࠭ጤ")				:pnkrd2S84FJfN73KuiCYv(u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬጥ")
	,wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪጦ")				:wAU9jKvmTM0(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨጧ")
	,WXuJd8nz2spo146t(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧጨ")		:wAU9jKvmTM0(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩጩ")
	,wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪጪ")	:MpJ8GOKoic(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫጫ")
	,QYSAUI5r46yil8cfaO(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠩጬ")		:WCPwmyVsb62KRlo(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩጭ")
	,WCPwmyVsb62KRlo(u"ࠪࡽࡹࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩጮ")			:ogJClMiqPa4A0NUtTxpDVybEWG(u"๊ࠫ๎วใ฻้๋๊้ࠣࠦฬํ์อ࠭ጯ")
	}
	vK50AI6UlwnHMuWExS7 = RRG6QsiOkKU0ChovTBY3qdf.lower()
	for key in list(hxd2OJqbWXv6.keys()):
		OqxWMQFVcAeN6yzdsXhwBZJaGUT0pH = key.lower()
		if vK50AI6UlwnHMuWExS7==OqxWMQFVcAeN6yzdsXhwBZJaGUT0pH:
			RRG6QsiOkKU0ChovTBY3qdf = hxd2OJqbWXv6[key]
			break
	return RRG6QsiOkKU0ChovTBY3qdf
def sRUPStCcaqYo4ru2E3wZyVd1HzfAL():
	yjsIKYfTL4vHnte3oa2h9 = J2L6to3R1Z.executeJSONRPC(eAMGzHRQVs2KyCwPXljYhB(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬጰ"))
	raise ValueError(ynxXU3gaiQ9GPCftr1q(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩጱ"))
def YYtCylgzdv5aiwN7nZ2e8soVO9hF(MYHJSVCGvrk,DupBW2cCoOhxb8lk=Vk54F7GcROfCy6HunEI):
	h9zFQKnsNL.oMt0Iw2GKZ47PeLBj13JO = YOHXqtbQTBfKerIZ
	if not DupBW2cCoOhxb8lk and MYHJSVCGvrk: DupBW2cCoOhxb8lk = QYSAUI5r46yil8cfaO(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨጲ")
	cad8TeSyMUYmfsEO0.setSetting(XCYALgFs2O3hZdpHrlMmB(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬጳ"),DupBW2cCoOhxb8lk)
	return
def FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(N39NCXDAaVnx,QQyREG9JzAXuiKZl=MpJ8GOKoic(u"ࠩ࠽࠳ࠬጴ")):
	return _BZx4zleFGV95ynuPi(N39NCXDAaVnx,QQyREG9JzAXuiKZl)
def RbfxYorCNwiqvBMuy65Z(fQ8Ydl6bgty):
	if fQ8Ydl6bgty in [Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࠴ࠬጵ"),ufmXvxgoHGDwZtjsLkR05i]: return Vk54F7GcROfCy6HunEI
	fQ8Ydl6bgty = int(fQ8Ydl6bgty)
	nFOxYig86fKh = fQ8Ydl6bgty^sT9DURSXlOybaCQ
	NgSoRabTUrzZh09DI1d = fQ8Ydl6bgty^ddQIv6q9hTce1iA0nWSX5UuLaNb
	KE2CB1zL0moAhYS = fQ8Ydl6bgty^CnJ1ePvdKQ2R
	fVn0BliHIa5h = str(nFOxYig86fKh)+str(NgSoRabTUrzZh09DI1d)+str(KE2CB1zL0moAhYS)
	return fVn0BliHIa5h
def qkXwRnPL3UbE(fQ8Ydl6bgty):
	if fQ8Ydl6bgty in [Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠫ࠵࠭ጶ"),ufmXvxgoHGDwZtjsLkR05i]: return Vk54F7GcROfCy6HunEI
	fQ8Ydl6bgty = str(fQ8Ydl6bgty)
	fVn0BliHIa5h = Vk54F7GcROfCy6HunEI
	if len(fQ8Ydl6bgty)==WCPwmyVsb62KRlo(u"࠵࠺ᑣ"):
		nFOxYig86fKh,NgSoRabTUrzZh09DI1d,KE2CB1zL0moAhYS = fQ8Ydl6bgty[ufmXvxgoHGDwZtjsLkR05i:BZm7TqLPJfAVblDKsya85zFWXNMY],fQ8Ydl6bgty[BZm7TqLPJfAVblDKsya85zFWXNMY:Nlyfx1HnzOWCovke5(u"࠾ᑤ")],fQ8Ydl6bgty[Nlyfx1HnzOWCovke5(u"࠾ᑤ"):]
		nFOxYig86fKh = int(nFOxYig86fKh)^CnJ1ePvdKQ2R
		NgSoRabTUrzZh09DI1d = int(NgSoRabTUrzZh09DI1d)^ddQIv6q9hTce1iA0nWSX5UuLaNb
		KE2CB1zL0moAhYS = int(KE2CB1zL0moAhYS)^sT9DURSXlOybaCQ
		if nFOxYig86fKh==NgSoRabTUrzZh09DI1d==KE2CB1zL0moAhYS: fVn0BliHIa5h = str(nFOxYig86fKh*kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠼࠰ᑥ"))
	return fVn0BliHIa5h
def DWBRli3pT90(fQ8Ydl6bgty,XW9Mdyb72KLV=SSBkx0WbN1asnDCQV6tIj(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧጷ")):
	if fQ8Ydl6bgty==Vk54F7GcROfCy6HunEI: return Vk54F7GcROfCy6HunEI
	fQ8Ydl6bgty = int(fQ8Ydl6bgty)+int(XW9Mdyb72KLV)
	nFOxYig86fKh = fQ8Ydl6bgty^sT9DURSXlOybaCQ
	NgSoRabTUrzZh09DI1d = fQ8Ydl6bgty^ddQIv6q9hTce1iA0nWSX5UuLaNb
	KE2CB1zL0moAhYS = fQ8Ydl6bgty^CnJ1ePvdKQ2R
	fVn0BliHIa5h = str(nFOxYig86fKh)+str(NgSoRabTUrzZh09DI1d)+str(KE2CB1zL0moAhYS)
	return fVn0BliHIa5h
def LMjdxBqyRenswWZGASmY5h2U(fQ8Ydl6bgty,XW9Mdyb72KLV=g7yJo2LVuqx1trPe(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨጸ")):
	if fQ8Ydl6bgty==Vk54F7GcROfCy6HunEI: return Vk54F7GcROfCy6HunEI
	fQ8Ydl6bgty = str(fQ8Ydl6bgty)
	ttGrwnx7dcQT8b = int(len(fQ8Ydl6bgty)/wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A)
	nFOxYig86fKh = int(fQ8Ydl6bgty[ufmXvxgoHGDwZtjsLkR05i:ttGrwnx7dcQT8b])^sT9DURSXlOybaCQ
	NgSoRabTUrzZh09DI1d = int(fQ8Ydl6bgty[ttGrwnx7dcQT8b:RXnhpCUk4M1TvgJE*ttGrwnx7dcQT8b])^ddQIv6q9hTce1iA0nWSX5UuLaNb
	KE2CB1zL0moAhYS = int(fQ8Ydl6bgty[RXnhpCUk4M1TvgJE*ttGrwnx7dcQT8b:wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A*ttGrwnx7dcQT8b])^CnJ1ePvdKQ2R
	fVn0BliHIa5h = Vk54F7GcROfCy6HunEI
	if nFOxYig86fKh==NgSoRabTUrzZh09DI1d==KE2CB1zL0moAhYS: fVn0BliHIa5h = str(int(nFOxYig86fKh)-int(XW9Mdyb72KLV))
	return fVn0BliHIa5h
def PdYBVMTK41gjAERSO8o7H(ohALbWRm3ru0OTatS):
	RrCaPOBdvLXiTeID4H8M0WZl = h9zFQKnsNL.SITESURLS[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧጹ")][pnkrd2S84FJfN73KuiCYv(u"࠸ᑦ")]
	V0hmlvxy5E28rNtUFC = CR3aLOVKSIme5XFoYi6M.path.join(cbFKmEkqwLU0vYD3pT,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫጺ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡶ࡯࡮ࡴࡳࠨጻ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫጼ"),cpHxZyU7vTtqmIw(u"ࠫ࠼࠸࠰ࡱࠩጽ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧጾ"))
	tQyaPl9TIDnU14N6e78i2uX,U08SyZpxt7nVWiTAzLH5 = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(V0hmlvxy5E28rNtUFC)
	tQyaPl9TIDnU14N6e78i2uX = DWBRli3pT90(tQyaPl9TIDnU14N6e78i2uX,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩጿ"))
	B4q7Jl0yAgOi2 = {ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡪࡦࡶࠫፀ"):HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡆࡌࡅࡑࡕࡇࠨፁ"),g7yJo2LVuqx1trPe(u"ࠩࡸࡷࡷ࠭ፂ"):h9zFQKnsNL.AV_CLIENT_IDS,jXWzIZcDva4ikEUfN(u"ࠪࡺࡪࡸࠧፃ"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,jXWzIZcDva4ikEUfN(u"ࠫࡸࡩࡲࠨፄ"):ohALbWRm3ru0OTatS,g7yJo2LVuqx1trPe(u"ࠬࡹࡩࡻࠩፅ"):tQyaPl9TIDnU14N6e78i2uX}
	WquGJkmdITfFcLoMHBb6 = {pnkrd2S84FJfN73KuiCYv(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬፆ"):ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ፇ")}
	xeh7cbZB3s = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,MpJ8GOKoic(u"ࠨࡒࡒࡗ࡙࠭ፈ"),RrCaPOBdvLXiTeID4H8M0WZl,B4q7Jl0yAgOi2,WquGJkmdITfFcLoMHBb6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪፉ"))
	YTyPsqXQ6ek = xeh7cbZB3s.content
	try:
		if not YTyPsqXQ6ek: QeiFBR7mqEH
		oBFJCfRsP0YgD8tHI3mSpGAxX = Bw6jaUcFxlqdDT8bC(jXWzIZcDva4ikEUfN(u"ࠪࡨ࡮ࡩࡴࠨፊ"),YTyPsqXQ6ek)
		yEcNwFlSMKA6jT2zDG9CrgJx38LoXP = oBFJCfRsP0YgD8tHI3mSpGAxX[WCPwmyVsb62KRlo(u"ࠫࡲࡹࡧࠨፋ")]
		k6y7eb4aYDFXnKsRSwQmfNWG = oBFJCfRsP0YgD8tHI3mSpGAxX[V2RQwM8XjlrK(u"ࠬࡹࡥࡤࠩፌ")]
		ib0slJoT4UBCmNq9uaPWf2wkn = oBFJCfRsP0YgD8tHI3mSpGAxX[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡳࡵࡲࠪፍ")]
		k6y7eb4aYDFXnKsRSwQmfNWG = int(LMjdxBqyRenswWZGASmY5h2U(k6y7eb4aYDFXnKsRSwQmfNWG,WsklGNp2CYzVQUag(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪፎ")))
		ib0slJoT4UBCmNq9uaPWf2wkn = int(LMjdxBqyRenswWZGASmY5h2U(ib0slJoT4UBCmNq9uaPWf2wkn,cpHxZyU7vTtqmIw(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫፏ")))
		for CUy02EWVqMY3J in range(k6y7eb4aYDFXnKsRSwQmfNWG,ufmXvxgoHGDwZtjsLkR05i,-ib0slJoT4UBCmNq9uaPWf2wkn):
			if not eval(YzowicIDTRusXZSU61(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧፐ"),{WXuJd8nz2spo146t(u"ࠪࡼࡧࡳࡣࠨፑ"):J2L6to3R1Z}): QeiFBR7mqEH
			qJAOp7HgfKeMQkDau(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪፒ"),str(CUy02EWVqMY3J)+wAU9jKvmTM0(u"ࠬࠦࠠฬษ้๎ฮ࠭ፓ"),Gb6kwVlSQ4MU=cpHxZyU7vTtqmIw(u"࠲࠲࠳ᑧ")*ib0slJoT4UBCmNq9uaPWf2wkn)
			J2L6to3R1Z.sleep(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠳࠳࠴࠵ᑨ")*ib0slJoT4UBCmNq9uaPWf2wkn)
		if eval(FGLEMi21Bfn(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫፔ"),{EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡹࡤࡰࡧࠬፕ"):J2L6to3R1Z}):
			yEcNwFlSMKA6jT2zDG9CrgJx38LoXP = yEcNwFlSMKA6jT2zDG9CrgJx38LoXP.replace(ixrPWKeFMnqJyVodX6D9AaO2,QYSAUI5r46yil8cfaO(u"ࠨ࡞࡟ࡲࠬፖ")).replace(gSiK7EQVNXClOUDZGs,SSBkx0WbN1asnDCQV6tIj(u"ࠩ࡟ࡠࡷ࠭ፗ"))
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠪาึ๎ฬࠨፘ"),g7yJo2LVuqx1trPe(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፙ"),yEcNwFlSMKA6jT2zDG9CrgJx38LoXP)
		QeiFBR7mqEH
	except: exec(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬፚ"),{MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡸࡣ࡯ࡦࠫ፛"):J2L6to3R1Z})
	return
def PPdj0l4GkHDRJySveb():
	exec(QYSAUI5r46yil8cfaO(u"ࠧࠨࠩࠐࠎࡹࡸࡹ࠻ࠏࠍࠍࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱࡛࡮ࡴࡤࡰࡹࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠐࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡸࡲࡥࡦࡲࠫ࠵࠵࠶࠰ࠪࠏࠍࠍࠎࡺࡲࡺ࠼ࠣࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸࠴ࡧࡦࡶࡉࡳࡨࡻࡳࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡨࡲࡦࡣ࡮ࠑࠏࠏࡺࡤࡴࡨࡥࡹ࡫࡟ࡦࡴࡲࡶࡷࠓࠊࡦࡺࡦࡩࡵࡺ࠺ࠡࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠎࠌࠪࠫࠬ፜"),{YzowicIDTRusXZSU61(u"ࠨࡺࡥࡱࡨ࡭ࡵࡪࠩ፝"):SZDFRGim3j8L,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡻࡦࡲࡩࠧ፞"):J2L6to3R1Z})
	return
def xUAYwuFSIJo2h7g0NXCetMiTydZVk6(l8IhwvESacb36y0fKG4noVLzDgu):
	uukn9CUbI6A,haQpuc6O5b = ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
	if CR3aLOVKSIme5XFoYi6M.path.exists(l8IhwvESacb36y0fKG4noVLzDgu):
		try: uukn9CUbI6A = CR3aLOVKSIme5XFoYi6M.path.getsize(l8IhwvESacb36y0fKG4noVLzDgu)
		except: pass
		if not uukn9CUbI6A:
			try: uukn9CUbI6A = CR3aLOVKSIme5XFoYi6M.stat(l8IhwvESacb36y0fKG4noVLzDgu).st_size
			except: pass
		if not uukn9CUbI6A:
			try:
				from pathlib import Path as HhOS57sCp0dcBPtUwAfiTankz4o
				uukn9CUbI6A = HhOS57sCp0dcBPtUwAfiTankz4o(l8IhwvESacb36y0fKG4noVLzDgu).stat().st_size
			except: pass
		if uukn9CUbI6A: haQpuc6O5b = pwxH3oREFm5v98BCZ1QVtzMJOc
	return uukn9CUbI6A,haQpuc6O5b
def r7rP6xHFYvepiTG(A8EVKYJ6Uz0ZCItleHPjO,showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭፟"),A8EVKYJ6Uz0ZCItleHPjO+SSBkx0WbN1asnDCQV6tIj(u"ࠫࡡࡴ࡜࡯ࠩ፠")+nMt0iueCy6K+pnkrd2S84FJfN73KuiCYv(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩ፡")+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=jXWzIZcDva4ikEUfN(u"࠴ᑩ"): return eu1NswY9zkKC60I
	succeeded = YOHXqtbQTBfKerIZ
	if CR3aLOVKSIme5XFoYi6M.path.exists(A8EVKYJ6Uz0ZCItleHPjO):
		try: CR3aLOVKSIme5XFoYi6M.remove(A8EVKYJ6Uz0ZCItleHPjO.decode(AoCWwJHgUPKXI7u2lEzym))
		except:
			try: CR3aLOVKSIme5XFoYi6M.remove(UeNaJctxRyK4)
			except Exception as MhfeRPFkU07j5ogmqbsYcCS:
				succeeded = eu1NswY9zkKC60I
				if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ።"),str(MhfeRPFkU07j5ogmqbsYcCS))
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፣"),g7yJo2LVuqx1trPe(u"ࠨใื่ฯูࠦๆๆํอ๋ࠥำฮࠢส่๊๊แࠨ፤"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ፥"),QYSAUI5r46yil8cfaO(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ፦"))
	return succeeded
def Agz62xbajVk15PieF4utWsGmBC(qpVRTBfHtKCIFza8Zeiy5QXsgv,iEwpmbu3jyTdlZDn1RVN,showDialogs):
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ፧"),qpVRTBfHtKCIFza8Zeiy5QXsgv+FGLEMi21Bfn(u"ࠬࡢ࡮࡝ࡰࠪ፨")+nMt0iueCy6K+FGLEMi21Bfn(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤࠫ፩")+ZZoLlKyInXc08j2pTGJ)
		if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return eu1NswY9zkKC60I
	succeeded = YOHXqtbQTBfKerIZ
	if CR3aLOVKSIme5XFoYi6M.path.exists(qpVRTBfHtKCIFza8Zeiy5QXsgv):
		for II47El3LywZWjh,LThQwsi9O0glYPMkoJq1der457j,jDCuyJxcOvUi85NX3g in CR3aLOVKSIme5XFoYi6M.walk(qpVRTBfHtKCIFza8Zeiy5QXsgv,topdown=eu1NswY9zkKC60I):
			for l8IhwvESacb36y0fKG4noVLzDgu in jDCuyJxcOvUi85NX3g:
				NMGgy2Ojlwu1nVxK = CR3aLOVKSIme5XFoYi6M.path.join(II47El3LywZWjh,l8IhwvESacb36y0fKG4noVLzDgu)
				try: CR3aLOVKSIme5XFoYi6M.remove(NMGgy2Ojlwu1nVxK)
				except Exception as MhfeRPFkU07j5ogmqbsYcCS:
					succeeded = eu1NswY9zkKC60I
					if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፪"),str(MhfeRPFkU07j5ogmqbsYcCS))
			if iEwpmbu3jyTdlZDn1RVN:
				for dir in LThQwsi9O0glYPMkoJq1der457j:
					eHRDrFjqLwl7vzc5Tf4 = CR3aLOVKSIme5XFoYi6M.path.join(II47El3LywZWjh,dir)
					try: CR3aLOVKSIme5XFoYi6M.rmdir(eHRDrFjqLwl7vzc5Tf4)
					except: pass
		if iEwpmbu3jyTdlZDn1RVN:
			try: CR3aLOVKSIme5XFoYi6M.rmdir(II47El3LywZWjh)
			except: pass
	if showDialogs:
		if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ፫"),g7yJo2LVuqx1trPe(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ፬"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭፭"),g7yJo2LVuqx1trPe(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭፮"))
	return succeeded
def m1VEeZzHklxsf(zpkoYB8x4vLuScXFiKPqOtRAj,V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,JlT9OB143U):
	hj50MJnoOp6ZWaS1IQ8Elr,SsAcDJaR2NuE7p4ZkO,ii5oPt8ldEp,HabAZ8CldGFjyvh = ppD6ewtT4LyNSgXxIQqYaA9U(N39NCXDAaVnx)
	L39t14lv2dr7IYqxERZM = V3EjC5wJlI,hj50MJnoOp6ZWaS1IQ8Elr,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf
	if zpkoYB8x4vLuScXFiKPqOtRAj<MzgKWUQ4V5H(u"࠴ᑪ"):
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,WsklGNp2CYzVQUag(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭፯"),L39t14lv2dr7IYqxERZM)
		zpkoYB8x4vLuScXFiKPqOtRAj = -zpkoYB8x4vLuScXFiKPqOtRAj
	if zpkoYB8x4vLuScXFiKPqOtRAj>WsklGNp2CYzVQUag(u"࠵ᑫ"):
		UwghkPtqZiWTvsMLrl5dc0nuOAQ = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡳࡵࡴࠪ፰"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ፱"),L39t14lv2dr7IYqxERZM)
		if UwghkPtqZiWTvsMLrl5dc0nuOAQ:
			R68OB3VtYS0WK(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭፲"),N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,JlT9OB143U,V3EjC5wJlI)
			return UwghkPtqZiWTvsMLrl5dc0nuOAQ
	UwghkPtqZiWTvsMLrl5dc0nuOAQ = ttSVmd8ijOyIF5vEAJ(V3EjC5wJlI,N39NCXDAaVnx,MFWydLr2JXCuVlUgAw9ERH8Yoiep,imAJgoKCHE3DrTVOnPlf,JlT9OB143U)
	if UwghkPtqZiWTvsMLrl5dc0nuOAQ and zpkoYB8x4vLuScXFiKPqOtRAj: FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ፳"),L39t14lv2dr7IYqxERZM,UwghkPtqZiWTvsMLrl5dc0nuOAQ,zpkoYB8x4vLuScXFiKPqOtRAj)
	return UwghkPtqZiWTvsMLrl5dc0nuOAQ
def NXWlZoh3QPaAwSYx(TVPm7Bz1XOwJ2,zzXIPMveV0NZ9qb,TTfusxjm9ILiV=ufmXvxgoHGDwZtjsLkR05i):
	orgtSuiUwKZ8kmH0xO2WQ = cad8TeSyMUYmfsEO0.getSetting(cpHxZyU7vTtqmIw(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ፴"))
	if orgtSuiUwKZ8kmH0xO2WQ and kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫ࠲࠭፵") not in orgtSuiUwKZ8kmH0xO2WQ: PSo6Hynm5cdOBMzL,SSQZX5qn2LY3NITgOFuM = int(orgtSuiUwKZ8kmH0xO2WQ),YOHXqtbQTBfKerIZ
	elif TTfusxjm9ILiV: PSo6Hynm5cdOBMzL,SSQZX5qn2LY3NITgOFuM = TTfusxjm9ILiV,eu1NswY9zkKC60I
	else: return []
	l983ZSiueYhbjwrI2tma1UGgDHk7,OVYaD62f4MubUAtXsdpC = [],Vk54F7GcROfCy6HunEI
	Ga2ACc1jDuMvbtQi6dOXxRfhHL,ZOgsv6rNL04TiYcz1jpRbJS,R4RYcGuJkZUNBp9,KKiwgbvNMUZlJSF8BL6nmHxd1O7As = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i,ufmXvxgoHGDwZtjsLkR05i
	zzXIPMveV0NZ9qb = sorted(zzXIPMveV0NZ9qb,reverse=YOHXqtbQTBfKerIZ,key=lambda key: (key[pwxH3oREFm5v98BCZ1QVtzMJOc],key[RXnhpCUk4M1TvgJE]))
	for stream,LeInSs4xpZuNJ6,LL82RbVxIQF1XBfYZM3 in zzXIPMveV0NZ9qb+[[Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i]]:
		if LeInSs4xpZuNJ6==OVYaD62f4MubUAtXsdpC:
			if LL82RbVxIQF1XBfYZM3>PSo6Hynm5cdOBMzL: ZOgsv6rNL04TiYcz1jpRbJS,KKiwgbvNMUZlJSF8BL6nmHxd1O7As = stream,LL82RbVxIQF1XBfYZM3
			elif not Ga2ACc1jDuMvbtQi6dOXxRfhHL: Ga2ACc1jDuMvbtQi6dOXxRfhHL,R4RYcGuJkZUNBp9 = stream,LL82RbVxIQF1XBfYZM3
		else:
			if ZOgsv6rNL04TiYcz1jpRbJS or Ga2ACc1jDuMvbtQi6dOXxRfhHL:
				if Ga2ACc1jDuMvbtQi6dOXxRfhHL: l983ZSiueYhbjwrI2tma1UGgDHk7.append([Ga2ACc1jDuMvbtQi6dOXxRfhHL,OVYaD62f4MubUAtXsdpC,R4RYcGuJkZUNBp9])
				elif ZOgsv6rNL04TiYcz1jpRbJS: l983ZSiueYhbjwrI2tma1UGgDHk7.append([ZOgsv6rNL04TiYcz1jpRbJS,OVYaD62f4MubUAtXsdpC,KKiwgbvNMUZlJSF8BL6nmHxd1O7As])
			if LL82RbVxIQF1XBfYZM3>PSo6Hynm5cdOBMzL:
				ZOgsv6rNL04TiYcz1jpRbJS,KKiwgbvNMUZlJSF8BL6nmHxd1O7As = stream,LL82RbVxIQF1XBfYZM3
				Ga2ACc1jDuMvbtQi6dOXxRfhHL,R4RYcGuJkZUNBp9 = Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i
			else:
				ZOgsv6rNL04TiYcz1jpRbJS,KKiwgbvNMUZlJSF8BL6nmHxd1O7As = Vk54F7GcROfCy6HunEI,ufmXvxgoHGDwZtjsLkR05i
				Ga2ACc1jDuMvbtQi6dOXxRfhHL,R4RYcGuJkZUNBp9 = stream,LL82RbVxIQF1XBfYZM3
		OVYaD62f4MubUAtXsdpC = LeInSs4xpZuNJ6
	if SSQZX5qn2LY3NITgOFuM:
		BzM5GvfomTOyqRrC1l4WJd3,bEFDKxlXPzaCjTf4QS,ppB8omKAnF0 = zip(*l983ZSiueYhbjwrI2tma1UGgDHk7)
		ggA1pokSBhCn850eQXM = [cpHxZyU7vTtqmIw(u"ࠬࡳࡰ࠵ࠩ፶"),wYTDlJC5vpOKynUEX3ge6W(u"࠭࡭ࡱࡦࠪ፷"),SSBkx0WbN1asnDCQV6tIj(u"ࠧࡵࡵࠪ፸"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨ࡯࠶ࡹࠬ፹")]
		for LeInSs4xpZuNJ6 in ggA1pokSBhCn850eQXM:
			if LeInSs4xpZuNJ6 in bEFDKxlXPzaCjTf4QS:
				index = bEFDKxlXPzaCjTf4QS.index(LeInSs4xpZuNJ6)
				l983ZSiueYhbjwrI2tma1UGgDHk7 = [[BzM5GvfomTOyqRrC1l4WJd3[index],bEFDKxlXPzaCjTf4QS[index],ppB8omKAnF0[index]]]
				break
	return l983ZSiueYhbjwrI2tma1UGgDHk7
def UUOlq467VQ3hpTcaJiuBKzxwY(YGX2vc8yQ71TFfHat):
	PwDslImZiv4xUgArG,cITdv8VoylMiQjLCR1XzxfmsG = [],tayEeSpKRJIdC8g10
	for PPmYnWkqTCfNH1u4yoRs in HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi:
		if PPmYnWkqTCfNH1u4yoRs==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪ፺"): cITdv8VoylMiQjLCR1XzxfmsG = (eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡰ࡮ࡴ࡫ࠨ፻"),nMt0iueCy6K+ogJClMiqPa4A0NUtTxpDVybEWG(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫ፼")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"࠷࠵࠸ᑬ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)
		elif PPmYnWkqTCfNH1u4yoRs==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡓࡉ࡙ࡇࡇࠫ፽"): cITdv8VoylMiQjLCR1XzxfmsG = (kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭࡬ࡪࡰ࡮ࠫ፾"),nMt0iueCy6K+ynxXU3gaiQ9GPCftr1q(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭፿")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"࠱࠶࠹ᑭ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)
		elif PPmYnWkqTCfNH1u4yoRs==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡒࡘࡆࡑࡏࡃࠨᎀ"): cITdv8VoylMiQjLCR1XzxfmsG = (ESXZrtnCfcDJGo01vFg(u"ࠩ࡯࡭ࡳࡱࠧᎁ"),nMt0iueCy6K+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪᎂ")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"࠲࠷࠺ᑮ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)
		if PPmYnWkqTCfNH1u4yoRs not in YGX2vc8yQ71TFfHat: continue
		if cITdv8VoylMiQjLCR1XzxfmsG:
			PwDslImZiv4xUgArG.append(cITdv8VoylMiQjLCR1XzxfmsG)
			cITdv8VoylMiQjLCR1XzxfmsG = tayEeSpKRJIdC8g10
		if PPmYnWkqTCfNH1u4yoRs not in [SSBkx0WbN1asnDCQV6tIj(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᎃ"),WCPwmyVsb62KRlo(u"ࠬࡓࡉ࡙ࡇࡇࠫᎄ"),MpJ8GOKoic(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ᎅ")]: PwDslImZiv4xUgArG.append(PPmYnWkqTCfNH1u4yoRs)
	return PwDslImZiv4xUgArG
def OUbct7HKQeNvFhBIq6T2EV0W5(AL4txjYuIJ9bVgcsFQd5UHwSMnvWC7,args=[]):
	WquGJkmdITfFcLoMHBb6 = {ESXZrtnCfcDJGo01vFg(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᎆ"):MpJ8GOKoic(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᎇ")}
	HHwfpcB9hJqCZ5yVENbnY,r42QpoWhzJj,Ra5oew28iA = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨᎈ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩᎉ"),int(Gb6kwVlSQ4MU.time())
	IQAe0MCcH5s67Uq = HHwfpcB9hJqCZ5yVENbnY+G8ovzUcaC9I1+str(Ra5oew28iA)+ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk+r42QpoWhzJj
	KJcupFnhxLbjTr6lUagHBsR3e = F0eNCYrxts8TpvwlWcmd5IfVEM.md5(IQAe0MCcH5s67Uq.encode(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡺࡺࡦ࠹ࠩᎊ"))).hexdigest()[:kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠵࠵ᑯ")]
	B4q7Jl0yAgOi2 = {kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡰࡳࡤࡱࡧࡩࠬᎋ"):AL4txjYuIJ9bVgcsFQd5UHwSMnvWC7,MzgKWUQ4V5H(u"࠭ࡡࡳࡩࡶࠫᎌ"):args,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡶࡵࡨࡶࠬᎍ"):G8ovzUcaC9I1,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᎎ"):ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk,QYSAUI5r46yil8cfaO(u"ࠩ࡬ࡨࡸ࠭ᎏ"):KJcupFnhxLbjTr6lUagHBsR3e}
	B4q7Jl0yAgOi2 = MkuHT2blpeds34wXxDyvgitqWo.dumps(B4q7Jl0yAgOi2)
	FF16Z29dYvAaDi = h9zFQKnsNL.SITESURLS[pnkrd2S84FJfN73KuiCYv(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ᎐")][SSBkx0WbN1asnDCQV6tIj(u"࠴࠴ᑰ")]
	xeh7cbZB3s = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,SSBkx0WbN1asnDCQV6tIj(u"ࠫࡕࡕࡓࡕࠩ᎑"),FF16Z29dYvAaDi,B4q7Jl0yAgOi2,WquGJkmdITfFcLoMHBb6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧ᎒"))
	YTyPsqXQ6ek = xeh7cbZB3s.content
	return YTyPsqXQ6ek
def yQXxP1eirFRKJ5gHbun(cCKjoONGpF9HnRrd57S3sAlZDghf,timeout,ss3wJxHOnTEq70,iitczegN8hs4wC3I6HlJfE9j5,gmAORHDCbUJXZ2G4xja):
	wZpWd8MYkNatno = eu1NswY9zkKC60I
	for P9ycfF67CML in cCKjoONGpF9HnRrd57S3sAlZDghf:
		P9ycfF67CML.start()
		Gb6kwVlSQ4MU.sleep(ss3wJxHOnTEq70)
		wZpWd8MYkNatno = gmAORHDCbUJXZ2G4xja()
		if wZpWd8MYkNatno: break
	else:
		MkQ92B6JqTbh4mRwYE57ncdyDFKui = int(timeout-len(cCKjoONGpF9HnRrd57S3sAlZDghf)*ss3wJxHOnTEq70)
		if MkQ92B6JqTbh4mRwYE57ncdyDFKui>ufmXvxgoHGDwZtjsLkR05i:
			for x7ohwWJScUpRi1K50qs in range(MkQ92B6JqTbh4mRwYE57ncdyDFKui//iitczegN8hs4wC3I6HlJfE9j5):
				Gb6kwVlSQ4MU.sleep(iitczegN8hs4wC3I6HlJfE9j5)
				wZpWd8MYkNatno = gmAORHDCbUJXZ2G4xja()
				if wZpWd8MYkNatno: break
	for P9ycfF67CML in cCKjoONGpF9HnRrd57S3sAlZDghf:
		try: P9ycfF67CML.join(ss3wJxHOnTEq70)
		except: pass
	return wZpWd8MYkNatno
def WWyMvQzapJOkdYeH0b(aaJhbOvi8R0ZsMSEYpj32VlwBTretq=jwOTI5eWEfcPZlXiQBq):
	QdoBfs92irmFAzSD81v = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠵࠵࠸࠴ᑱ")
	amKxG7yuBpA8stlCbJhL9j56eSnwP = ufmXvxgoHGDwZtjsLkR05i
	try:
		OQqfyBTMaKD1osNX = J2L6to3R1Z.getInfoLabel(FGLEMi21Bfn(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳࡧࡨࡗࡵࡧࡣࡦࠩ᎓"))
		OQqfyBTMaKD1osNX = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠩ࡞ࡧ࠯࠭ࡅ࠺࡝࠰࡟ࡨ࠰࠯࠿ࠪ࠰࠭ࡃ࡚࠭ࡂࡽࡉࡅࢀࡒࡈࡼࡌࡄࡿࡆ࠮࠭᎔"),OQqfyBTMaKD1osNX)
		if OQqfyBTMaKD1osNX:
			OQqfyBTMaKD1osNX,value = OQqfyBTMaKD1osNX[SSBkx0WbN1asnDCQV6tIj(u"࠵ᑲ")]
			OQqfyBTMaKD1osNX = float(OQqfyBTMaKD1osNX)
			if   value==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡖࡅࠫ᎕"): amKxG7yuBpA8stlCbJhL9j56eSnwP = OQqfyBTMaKD1osNX*QdoBfs92irmFAzSD81v**BZm7TqLPJfAVblDKsya85zFWXNMY
			elif value==eAMGzHRQVs2KyCwPXljYhB(u"ࠩࡊࡆࠬ᎖"): amKxG7yuBpA8stlCbJhL9j56eSnwP = OQqfyBTMaKD1osNX*QdoBfs92irmFAzSD81v**wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
			elif value==g7yJo2LVuqx1trPe(u"ࠪࡑࡇ࠭᎗"): amKxG7yuBpA8stlCbJhL9j56eSnwP = OQqfyBTMaKD1osNX*QdoBfs92irmFAzSD81v**RXnhpCUk4M1TvgJE
			elif value==XCYALgFs2O3hZdpHrlMmB(u"ࠫࡐࡈࠧ᎘"): amKxG7yuBpA8stlCbJhL9j56eSnwP = OQqfyBTMaKD1osNX*QdoBfs92irmFAzSD81v
			elif value==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡈࠧ᎙") : amKxG7yuBpA8stlCbJhL9j56eSnwP = OQqfyBTMaKD1osNX
	except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP and hasattr(CR3aLOVKSIme5XFoYi6M,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡳࡵࡣࡷࡺ࡫ࡹࠧ᎚")):
		try:
			VgTY2UK8kXwA9enL64j = CR3aLOVKSIme5XFoYi6M.statvfs(aaJhbOvi8R0ZsMSEYpj32VlwBTretq)
			amKxG7yuBpA8stlCbJhL9j56eSnwP = VgTY2UK8kXwA9enL64j.f_frsize * VgTY2UK8kXwA9enL64j.f_bavail
		except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP and hasattr(CR3aLOVKSIme5XFoYi6M,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡧࡵࡷࡥࡹࡼࡦࡴࠩ᎛")):
		try:
			VgTY2UK8kXwA9enL64j = CR3aLOVKSIme5XFoYi6M.fstatvfs(aaJhbOvi8R0ZsMSEYpj32VlwBTretq)
			amKxG7yuBpA8stlCbJhL9j56eSnwP = VgTY2UK8kXwA9enL64j.f_frsize * VgTY2UK8kXwA9enL64j.f_bavail
		except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP:
		try:
			import shutil as OktoTVrJaf
			amKxG7yuBpA8stlCbJhL9j56eSnwP = OktoTVrJaf.disk_usage(aaJhbOvi8R0ZsMSEYpj32VlwBTretq).free
		except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP:
		try:
			import psutil as W8sFhw0H7ZRukMxLX4DGCOf
			amKxG7yuBpA8stlCbJhL9j56eSnwP = W8sFhw0H7ZRukMxLX4DGCOf.disk_usage(aaJhbOvi8R0ZsMSEYpj32VlwBTretq).free
		except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP and yBxCpcVaPow1bztQm4X.platform == jXWzIZcDva4ikEUfN(u"ࠨࡹ࡬ࡲ࠸࠸ࠧ᎜"):
		try:
			import ctypes as eKNG6HR79FOMYs2iB4V
			cFvWDCN7jsLAxptm = eKNG6HR79FOMYs2iB4V.c_ulonglong(ufmXvxgoHGDwZtjsLkR05i)
			eKNG6HR79FOMYs2iB4V.windll.kernel32.GetDiskFreeSpaceExW(eKNG6HR79FOMYs2iB4V.c_wchar_p(aaJhbOvi8R0ZsMSEYpj32VlwBTretq),None,None,eKNG6HR79FOMYs2iB4V.pointer(cFvWDCN7jsLAxptm))
			amKxG7yuBpA8stlCbJhL9j56eSnwP = cFvWDCN7jsLAxptm.value
		except: pass
	if not amKxG7yuBpA8stlCbJhL9j56eSnwP: amKxG7yuBpA8stlCbJhL9j56eSnwP = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼ᑳ")
	return int(amKxG7yuBpA8stlCbJhL9j56eSnwP)
from VhoC9ADvuL import *
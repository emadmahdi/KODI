# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
qJAOp7HgfKeMQkDau(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡙ࠫࡋࡓࡕࠩᆒ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࡚ࠬࡅࡔࡖࠪᆓ"))
O8OPqo5m4gTw07cBLliGEy6fpRWI = wAU9jKvmTM0(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡸ࠷࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡩ࡫ࡱ࡯ࡧࡸ࡯ࡢࡦࡥࡥࡳࡪ࠮ࡤࡱࡰ࠳࠶࠶ࡍࡃ࠰ࡽ࡭ࡵ࠭ᆔ")
O8OPqo5m4gTw07cBLliGEy6fpRWI = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡨࡩࡩࡺࡥࡴࡶ࠱ࡪࡹࡶ࠮ࡰࡶࡨࡲࡪࡺ࠮ࡨࡴ࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡩࡸࡺ࠱࠱࠲࡮࠲ࡩࡨࠧᆕ")
jRf87LJug6qp4ZzTyhm(O8OPqo5m4gTw07cBLliGEy6fpRWI,{},YOHXqtbQTBfKerIZ)
lI5ck2gjRCiw9bMTF0xHsG = ESXZrtnCfcDJGo01vFg(u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ๅา฻࠮࡮ࡲ࠶ࠫᆖ")
lI5ck2gjRCiw9bMTF0xHsG = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠ࡫࡯࡬ࡦࡡ࠷࠼࠸࠺࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧᆗ")
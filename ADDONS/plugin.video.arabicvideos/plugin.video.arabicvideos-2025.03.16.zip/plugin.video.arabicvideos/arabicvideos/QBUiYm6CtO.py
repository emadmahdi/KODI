# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'FASELHD1'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_FH1_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['جوائز الأوسكار','المراجعات','wwe']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==570: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==571: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==572: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==573: w8YsNWfQ5gFluRvOmSd4Cb96H = d3dvo9txDeRB7uzFLQ(url,text)
	elif mode==576: w8YsNWfQ5gFluRvOmSd4Cb96H = ggMHQnVw0lPJImj()
	elif mode==579: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+'لماذا الموقع بطيء',Vk54F7GcROfCy6HunEI,576)
	lseWcUVP5qY,url = FFLhlYUAsfJBXeQmRpzD7c14ZP6,FFLhlYUAsfJBXeQmRpzD7c14ZP6
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD1-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',lseWcUVP5qY,579,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'المميزة',lseWcUVP5qY,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured1')
	items = RSuYINdeamsK0t.findall('class="h3">(.*?)<.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details1')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"menu-primary"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		YbgxWEosLAIqy5CZD8 = RSuYINdeamsK0t.findall('<li (.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		OnJEH59ugjw6 = [Vk54F7GcROfCy6HunEI,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz = 0
		for Ak1pcoVisreCFTRyH6J7WgL in YbgxWEosLAIqy5CZD8:
			if sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz>0: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',Ak1pcoVisreCFTRyH6J7WgL,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
				if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				if title==Vk54F7GcROfCy6HunEI: continue
				if any(value in title.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
				title = OnJEH59ugjw6[sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz]+title
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details2')
			sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz += 1
	return
def ggMHQnVw0lPJImj():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD1-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('class="h4">(.*?)</div>(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not QQHXiFSA0jUsklmxbpaMztu: return
	if type=='filters':
		Ry3L7fdNGh = [FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"homeSlide"(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		q0ZrEo62YLbBCfJ,HXhRgxEZ4d2Dek,ss285HRGmwx = zip(*items)
		items = zip(HXhRgxEZ4d2Dek,q0ZrEo62YLbBCfJ,ss285HRGmwx)
	elif type=='featured2':
		title,UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	elif type=='details2' and len(QQHXiFSA0jUsklmxbpaMztu)>1:
		title = QQHXiFSA0jUsklmxbpaMztu[0][0]
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured2')
		title = QQHXiFSA0jUsklmxbpaMztu[1][0]
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details3')
		return
	else:
		title,UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[-1]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if any(value in title.lower() for value in wXPtB6I0QKLTyD932sl5d): continue
		afR4xElWyzgcNAUnKXBempC = ww25jXuxtpK1TOJEbGUgrm8(afR4xElWyzgcNAUnKXBempC)
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.split('?resize=')[0]
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) (الحلقة|حلقة).\d+',title,RSuYINdeamsK0t.DOTALL)
		if '/collections/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,571,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and type==Vk54F7GcROfCy6HunEI:
			title = '_MOD_'+AWjJSatwokZ[0][0]
			title = title.strip(' –')
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,573,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif 'episodes/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or 'movies/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or 'hindi/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,572,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,573,afR4xElWyzgcNAUnKXBempC)
	if type=='filters':
		lyNAzPtVKoUXJxYMb = RSuYINdeamsK0t.findall('"more_button_page":(.*?),',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if lyNAzPtVKoUXJxYMb:
			count = lyNAzPtVKoUXJxYMb[0]
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url+'/offset/'+count
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة أخرى',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'filters')
	elif 'details' in type:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall("class='pagination(.*?)</div>",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall("href='(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = 'صفحة '+Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,571,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'details4')
	return
def d3dvo9txDeRB7uzFLQ(url,type=Vk54F7GcROfCy6HunEI):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD1-SEASONS_EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Yo3AtpSIM5ax6dUTwLk1qCgjeym7P = False
	if not type:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"seasonList"(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if len(items)>1:
				lseWcUVP5qY = RRav1Sf7Px(url,'url')
				Yo3AtpSIM5ax6dUTwLk1qCgjeym7P = True
				for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,name,title in items:
					name = Uo7Tbc29Eu(name)
					if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
					title = name+' - '+title
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,573,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,'episodes')
	if type=='episodes' or not Yo3AtpSIM5ax6dUTwLk1qCgjeym7P:
		ylKTDSkdQmUChwbX45ALeiu = RSuYINdeamsK0t.findall('"posterImg".*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if ylKTDSkdQmUChwbX45ALeiu: afR4xElWyzgcNAUnKXBempC = ylKTDSkdQmUChwbX45ALeiu[0]
		else: afR4xElWyzgcNAUnKXBempC = Vk54F7GcROfCy6HunEI
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"epAll"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = Uo7Tbc29Eu(title)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,572,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	MMJL8QqY6T7dv1onu,EKTx69zw3SMdmlPnkeb,VV2e6BuEOz9ta = [],[],[]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'FASELHD1-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Od2iYMok9sHT6qXuSmvtKJ = RSuYINdeamsK0t.findall('مستوى المشاهدة.*?">(.*?)</span>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Od2iYMok9sHT6qXuSmvtKJ:
		TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('"tag">(.*?)</a>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"videoRow"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&img=')[0]
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=__embed')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="streamHeader(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall("href = '(.*?)'.*?</i>(.*?)</a>",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&img=')[0]
			name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__watch')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="downloadLinks(.*?)blackwindow',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?</span>(.*?)</a>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('&img=')[0]
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__download')
	for JrvbaUIyLx9cWpY4HqZD32j in MMJL8QqY6T7dv1onu:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name = JrvbaUIyLx9cWpY4HqZD32j.split('?named')
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp not in EKTx69zw3SMdmlPnkeb:
			EKTx69zw3SMdmlPnkeb.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			VV2e6BuEOz9ta.append(JrvbaUIyLx9cWpY4HqZD32j)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(VV2e6BuEOz9ta,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr,'details5')
	return
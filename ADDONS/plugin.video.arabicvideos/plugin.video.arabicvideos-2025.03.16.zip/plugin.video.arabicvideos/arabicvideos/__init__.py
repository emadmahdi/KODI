# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from C6bDm3h7Zp import *
TVPm7Bz1XOwJ2 = ESXZrtnCfcDJGo01vFg(u"ࠪࡍࡓࡏࡔࠨᆘ")
k8jPV3moIuSBzH = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠫᆙ")
WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = cmeXCvAZnH86gJ(zLxMfI0XGwHT8n)
M7IELOvt1eNWmjVrYnH2lBQ3kagq = int(Fj9S5lYorenKWR2I30)
fqNDhEb7ic5rH2K9Rx = J2L6to3R1Z.getInfoLabel(V2RQwM8XjlrK(u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ᆚ"))
fqNDhEb7ic5rH2K9Rx = fqNDhEb7ic5rH2K9Rx.replace(ZdD4q6gA50I,Vk54F7GcROfCy6HunEI).replace(kH6Bj7pebUaxIf,Vk54F7GcROfCy6HunEI)
if M7IELOvt1eNWmjVrYnH2lBQ3kagq==WXuJd8nz2spo146t(u"࠳࠸࠳ᇀ"): T7TEW3YZKBSlsHOFe0pudfbNgxhoji = EM6qpnCBYQGA9kbgDVLfrP(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧᆛ")+ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧᆜ")+QXxcFjsL4MB09+ynxXU3gaiQ9GPCftr1q(u"ࠨࠢࡠࠫᆝ")
else:
	kB9USInxzlZhmFs4OprCjTvb8y = ZlBMJUAWRm9buv(zLxMfI0XGwHT8n).replace(nMt0iueCy6K,Vk54F7GcROfCy6HunEI).replace(d761ZWXHEvliYN45RzLP2,Vk54F7GcROfCy6HunEI)
	kB9USInxzlZhmFs4OprCjTvb8y = kB9USInxzlZhmFs4OprCjTvb8y.replace(ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	kB9USInxzlZhmFs4OprCjTvb8y = kB9USInxzlZhmFs4OprCjTvb8y.replace(qMmCGK8cln5bID4fkhAF,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	T7TEW3YZKBSlsHOFe0pudfbNgxhoji = NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨᆞ")+fqNDhEb7ic5rH2K9Rx+WsklGNp2CYzVQUag(u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪᆟ")+Fj9S5lYorenKWR2I30+WXuJd8nz2spo146t(u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫᆠ")+kB9USInxzlZhmFs4OprCjTvb8y+QYSAUI5r46yil8cfaO(u"ࠬࠦ࡝ࠨᆡ")
iQlMPpRZXWLd(yyhLQon4NGP5MpH,k8jPV3moIuSBzH+ixrPWKeFMnqJyVodX6D9AaO2+ySVOsdu270(TVPm7Bz1XOwJ2)+T7TEW3YZKBSlsHOFe0pudfbNgxhoji)
if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭࡟ࠨᆢ") in rF0ghTZEyQ: Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx = rF0ghTZEyQ.split(eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡠࠩᆣ"),pwxH3oREFm5v98BCZ1QVtzMJOc)
else: Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx = rF0ghTZEyQ,Vk54F7GcROfCy6HunEI
h9zFQKnsNL.oMt0Iw2GKZ47PeLBj13JO,ovLGZ5jUxNzmiQC = eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI
if Rw2xfQUAeP9sy in [QYSAUI5r46yil8cfaO(u"ࠨ࠳ࠪᆤ"),SSBkx0WbN1asnDCQV6tIj(u"ࠩ࠵ࠫᆥ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪ࠷ࠬᆦ"),WCPwmyVsb62KRlo(u"ࠫ࠹࠭ᆧ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬ࠻ࠧᆨ"),EM6qpnCBYQGA9kbgDVLfrP(u"࠭࠱࠲ࠩᆩ"),WXuJd8nz2spo146t(u"ࠧ࠲࠴ࠪᆪ"),V2RQwM8XjlrK(u"ࠨ࠳࠶ࠫᆫ")] and (SSBkx0WbN1asnDCQV6tIj(u"ࠩࡄࡈࡉ࠭ᆬ") in GZ6tYW82Hh0ekOmNLnzsx or NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡖࡊࡓࡏࡗࡇࠪᆭ") in GZ6tYW82Hh0ekOmNLnzsx or ynxXU3gaiQ9GPCftr1q(u"࡚ࠫࡖࠧᆮ") in GZ6tYW82Hh0ekOmNLnzsx or Nlyfx1HnzOWCovke5(u"ࠬࡊࡏࡘࡐࠪᆯ") in GZ6tYW82Hh0ekOmNLnzsx):
	from DVX8HOTEnm import RV2JzeiqBrX3IZNc5Fj8QUn
	RV2JzeiqBrX3IZNc5Fj8QUn(rF0ghTZEyQ,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx)
	cad8TeSyMUYmfsEO0.setSetting(WXuJd8nz2spo146t(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᆰ"),zLxMfI0XGwHT8n)
	h9zFQKnsNL.oMt0Iw2GKZ47PeLBj13JO = YOHXqtbQTBfKerIZ
elif not PPBQqyt8i5FVezK and M7IELOvt1eNWmjVrYnH2lBQ3kagq in [Nlyfx1HnzOWCovke5(u"࠴࠶࠹ᇁ"),QYSAUI5r46yil8cfaO(u"࠺࠵࠺ᇂ")]:
	vEznYtihqcojIFrOkUTXdLR = str(Xb17xtEphFigA8dReBrGH[HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆱ")])
	TVPm7Bz1XOwJ2 = V2RQwM8XjlrK(u"ࠨࡋࡓࡘ࡛࠭ᆲ") if M7IELOvt1eNWmjVrYnH2lBQ3kagq==wAU9jKvmTM0(u"࠶࠸࠻ᇃ") else MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡐ࠷࡚࠭ᆳ")
	iOqEpc4RS8HoDYWIMTUjNQer3 = TVPm7Bz1XOwJ2.lower()
	rZigEYv8tbVk = cad8TeSyMUYmfsEO0.getSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡥࡻ࠴ࠧᆴ")+iOqEpc4RS8HoDYWIMTUjNQer3+eAMGzHRQVs2KyCwPXljYhB(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩᆵ")+vEznYtihqcojIFrOkUTXdLR)
	yCJq05F7M4TB = cad8TeSyMUYmfsEO0.getSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡧࡶ࠯ࠩᆶ")+iOqEpc4RS8HoDYWIMTUjNQer3+ESXZrtnCfcDJGo01vFg(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩᆷ")+vEznYtihqcojIFrOkUTXdLR)
	if rZigEYv8tbVk or yCJq05F7M4TB:
		N39NCXDAaVnx += ESXZrtnCfcDJGo01vFg(u"ࠧࡽࠩᆸ")
		if rZigEYv8tbVk: N39NCXDAaVnx += l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧᆹ")+rZigEYv8tbVk
		if yCJq05F7M4TB: N39NCXDAaVnx += V2RQwM8XjlrK(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᆺ")+yCJq05F7M4TB
		N39NCXDAaVnx = N39NCXDAaVnx.replace(ESXZrtnCfcDJGo01vFg(u"ࠪࢀࠫ࠭ᆻ"),jXWzIZcDva4ikEUfN(u"ࠫࢁ࠭ᆼ"))
	M7QcihzvNgKUXpmIVCLdJk8 = cad8TeSyMUYmfsEO0.getSetting(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡧࡶ࠯ࠩᆽ")+iOqEpc4RS8HoDYWIMTUjNQer3+g7yJo2LVuqx1trPe(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨᆾ")+vEznYtihqcojIFrOkUTXdLR)
	if M7QcihzvNgKUXpmIVCLdJk8:
		RKfNiW7MeuUAptozChb8VmgqQD36 = RSuYINdeamsK0t.findall(WsklGNp2CYzVQUag(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪᆿ"),N39NCXDAaVnx,RSuYINdeamsK0t.DOTALL)
		N39NCXDAaVnx = N39NCXDAaVnx.replace(RKfNiW7MeuUAptozChb8VmgqQD36[ufmXvxgoHGDwZtjsLkR05i],M7QcihzvNgKUXpmIVCLdJk8)
	qnUlyF2JXuGYdSA6Iac1(N39NCXDAaVnx,TVPm7Bz1XOwJ2,WypSQTO7504tHY)
else:
	import Cqlz6HOy2V
	try: Cqlz6HOy2V.fhE1D2548FmzHJcdu(WypSQTO7504tHY,HpzRx8a4nj,N39NCXDAaVnx,Fj9S5lYorenKWR2I30,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,RRG6QsiOkKU0ChovTBY3qdf,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH,M7IELOvt1eNWmjVrYnH2lBQ3kagq,Rw2xfQUAeP9sy,GZ6tYW82Hh0ekOmNLnzsx,fqNDhEb7ic5rH2K9Rx)
	except Exception as UzQpsgO6iuy2WP70RCSvjMn3VIqN: ovLGZ5jUxNzmiQC = DeF4y1NAfRrqO5mTHavCUx6L792uwG.format_exc()
HQM8BD6dTcX(h9zFQKnsNL.oMt0Iw2GKZ47PeLBj13JO,ovLGZ5jUxNzmiQC)
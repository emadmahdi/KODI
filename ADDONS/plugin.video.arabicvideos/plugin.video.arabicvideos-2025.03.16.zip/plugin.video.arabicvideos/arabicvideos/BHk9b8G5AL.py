# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'GLOBALSEARCH'
xzA9sM3rG6IHd7jl8T = '_GLS_'
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO,H4TFmtAe5rM8oY1lfPviVC):
	if   Yz6schq9wSmiu3IOdke0DXPj5W==540: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==541: w8YsNWfQ5gFluRvOmSd4Cb96H = aPnpNWwrK9(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==542: w8YsNWfQ5gFluRvOmSd4Cb96H = lAJcuH4gSIFM(YWCso5NMKO,lI5ck2gjRCiw9bMTF0xHsG,H4TFmtAe5rM8oY1lfPviVC)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==543: w8YsNWfQ5gFluRvOmSd4Cb96H = ak6T4YuSbKgnP3eXL9cHAOC07BmWFQ()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==548: w8YsNWfQ5gFluRvOmSd4Cb96H = njJHKa5SByWrDxCFzUtPEvI(lI5ck2gjRCiw9bMTF0xHsG,YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==549: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(YWCso5NMKO)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','بحث جديد لجميع المواقع',Vk54F7GcROfCy6HunEI,549)
	v0TjHlLZqkRxUCpmNwSy8AndO('link','كيف يعمل بحث جميع المواقع','',543)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'==== كلمات البحث المخزنة ===='+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	lDthGpmQvkZEq4WBd27caV5oPn = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if lDthGpmQvkZEq4WBd27caV5oPn:
		lDthGpmQvkZEq4WBd27caV5oPn = lDthGpmQvkZEq4WBd27caV5oPn['__SEQUENCED_COLUMNS__']
		for rXEdWpTOxkiLqY8vfjUBn in reversed(lDthGpmQvkZEq4WBd27caV5oPn):
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',rXEdWpTOxkiLqY8vfjUBn,Vk54F7GcROfCy6HunEI,549,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,rXEdWpTOxkiLqY8vfjUBn)
	return
def zDkgCMXBmx2A(rXEdWpTOxkiLqY8vfjUBn):
	if not rXEdWpTOxkiLqY8vfjUBn:
		rXEdWpTOxkiLqY8vfjUBn = p3bB2auMmSjXC0dE8FUfZ()
		if not rXEdWpTOxkiLqY8vfjUBn: return
		rXEdWpTOxkiLqY8vfjUBn = rXEdWpTOxkiLqY8vfjUBn.lower()
	QTu5DMfvn62aRLhKq07 = rXEdWpTOxkiLqY8vfjUBn.replace(xzA9sM3rG6IHd7jl8T,Vk54F7GcROfCy6HunEI)
	gDkiOuodEZ(QTu5DMfvn62aRLhKq07,'_ALL',True)
	v0TjHlLZqkRxUCpmNwSy8AndO('link','بحث جماعي للمواقع - '+QTu5DMfvn62aRLhKq07,'search_sites_all',542,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','بحث منفرد للمواقع - '+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,541,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','نتائج البحث مفصلة - '+QTu5DMfvn62aRLhKq07,'opened_sites_all',542,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','نتائج البحث مقسمة - '+QTu5DMfvn62aRLhKq07,'listed_sites_all',542,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QTu5DMfvn62aRLhKq07)
	return
def gDkiOuodEZ(vhWnXqe2paC3R6k7rz08DZIBfcd,OTkfxvAVU7,Oins0BwVge7b2zl):
	if OTkfxvAVU7=='_ALL': ugsWdDEf5yv0Nn = '_GLS_'
	elif OTkfxvAVU7=='_GOOGLE': ugsWdDEf5yv0Nn = '_GOS_'
	w8yNHveri7SXkRu5WVEQdCx = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,vhWnXqe2paC3R6k7rz08DZIBfcd)
	gl4FZ9Jh7jRxQwrXHDAa = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,ugsWdDEf5yv0Nn+vhWnXqe2paC3R6k7rz08DZIBfcd)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,vhWnXqe2paC3R6k7rz08DZIBfcd)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,ugsWdDEf5yv0Nn+vhWnXqe2paC3R6k7rz08DZIBfcd)
	eCzxUMctIGpm1aNEwhBb = w8yNHveri7SXkRu5WVEQdCx+gl4FZ9Jh7jRxQwrXHDAa
	if eCzxUMctIGpm1aNEwhBb and Oins0BwVge7b2zl: vhWnXqe2paC3R6k7rz08DZIBfcd = ugsWdDEf5yv0Nn+vhWnXqe2paC3R6k7rz08DZIBfcd
	FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,vhWnXqe2paC3R6k7rz08DZIBfcd,eCzxUMctIGpm1aNEwhBb,mXdxepDh683FuUKlb0)
	return
def ISNDTYpvG7f6yzkjCbH8lMJF(OTkfxvAVU7):
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if W8j2OheqsroDJIYzRupt6nG!=1: return
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DETAILED'+OTkfxvAVU7)
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DIVIDED'+OTkfxvAVU7)
	if OTkfxvAVU7=='_GOOGLE': kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GOOGLESEARCH_RESULTS')
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def lAJcuH4gSIFM(DKXP9Sy3xIB,PfeJCqUoA1kjHQW7zgTNLt54,EdLyT71sH8Ih=Vk54F7GcROfCy6HunEI,l60lMErGLtXhkcmpQ4DW1=LMnQyYOz0U1Ix6B2jW9tvwCpFgV,vosYzkNCa9QGim3f2MwJeFu0nD={}):
	mbkDP4HleQG2yqA6CKNV3s8FZIU9,QsuAqvaWRrVYmkfO94dJZiB3XlD,dMEqP9hBfoTvVSA,j3ULEfqAmXVGtZHF,Mo9lQ7Iux1bKmPtFa8W = [],{},{},{},{}
	if '_all' in PfeJCqUoA1kjHQW7zgTNLt54: OTkfxvAVU7,zodCYIev4gjbVTux7,ugsWdDEf5yv0Nn = '_ALL','_all','_GLS_'
	elif '_google' in PfeJCqUoA1kjHQW7zgTNLt54: OTkfxvAVU7,zodCYIev4gjbVTux7,ugsWdDEf5yv0Nn = '_GOOGLE','_google','_GOS_'
	if PfeJCqUoA1kjHQW7zgTNLt54 in ['listed_sites'+zodCYIev4gjbVTux7,'opened_sites'+zodCYIev4gjbVTux7,'closed_sites'+zodCYIev4gjbVTux7]:
		if PfeJCqUoA1kjHQW7zgTNLt54=='listed_sites'+zodCYIev4gjbVTux7: mbkDP4HleQG2yqA6CKNV3s8FZIU9 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,ugsWdDEf5yv0Nn+DKXP9Sy3xIB)
		elif PfeJCqUoA1kjHQW7zgTNLt54=='opened_sites'+zodCYIev4gjbVTux7: mbkDP4HleQG2yqA6CKNV3s8FZIU9 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_DETAILED'+OTkfxvAVU7,DKXP9Sy3xIB)
		elif PfeJCqUoA1kjHQW7zgTNLt54=='closed_sites'+zodCYIev4gjbVTux7: mbkDP4HleQG2yqA6CKNV3s8FZIU9 = w79OlVdv3DWPBfnmHsNjhQ4bCTzU(OKzSt0JnAdvh2mM,'list','GLOBALSEARCH_DIVIDED'+OTkfxvAVU7,(EdLyT71sH8Ih,DKXP9Sy3xIB))
	if not mbkDP4HleQG2yqA6CKNV3s8FZIU9:
		burCKRDXAy9jY = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		eeHAfglvTVoC0QE = 'هل تريد الآن البحث في جميع المواقع عن \n "'+d761ZWXHEvliYN45RzLP2+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+DKXP9Sy3xIB+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+ZZoLlKyInXc08j2pTGJ+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if PfeJCqUoA1kjHQW7zgTNLt54=='search_sites'+zodCYIev4gjbVTux7: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = eeHAfglvTVoC0QE
		else: BadMOTrh9Lnp0w6KZCQASE4uyk7fW = burCKRDXAy9jY+eeHAfglvTVoC0QE
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج',BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		if W8j2OheqsroDJIYzRupt6nG!=1: return
		igFtOzLBeQu(b8f2icUnEswC9Ja,b8f2icUnEswC9Ja,b8f2icUnEswC9Ja)
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Search For: [ '+DKXP9Sy3xIB+' ]')
		htb7VcAOWvsp5mlMI2kF = 1
		for PPmYnWkqTCfNH1u4yoRs in l60lMErGLtXhkcmpQ4DW1:
			qTtfDW472sod = vosYzkNCa9QGim3f2MwJeFu0nD[PPmYnWkqTCfNH1u4yoRs] if vosYzkNCa9QGim3f2MwJeFu0nD else DKXP9Sy3xIB
			try: tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
			except: continue
			QsuAqvaWRrVYmkfO94dJZiB3XlD[PPmYnWkqTCfNH1u4yoRs] = []
			tFleBaQ2fUrNiPdu3k8cpjWCxS7 = '_NODIALOGS_'
			if '-' in PPmYnWkqTCfNH1u4yoRs: tFleBaQ2fUrNiPdu3k8cpjWCxS7 = tFleBaQ2fUrNiPdu3k8cpjWCxS7+'_REMEMBERRESULTS__'+PPmYnWkqTCfNH1u4yoRs+'_'
			if htb7VcAOWvsp5mlMI2kF:
				Gb6kwVlSQ4MU.sleep(0.75)
				Mo9lQ7Iux1bKmPtFa8W[PPmYnWkqTCfNH1u4yoRs] = rsUhzDpy6TZLVHdt7RE1YOaAwSMlWo(daemon=YOHXqtbQTBfKerIZ,target=hjBWFnCMqr,args=(qTtfDW472sod+tFleBaQ2fUrNiPdu3k8cpjWCxS7,))
				Mo9lQ7Iux1bKmPtFa8W[PPmYnWkqTCfNH1u4yoRs].start()
			else: hjBWFnCMqr(qTtfDW472sod+tFleBaQ2fUrNiPdu3k8cpjWCxS7)
			qJAOp7HgfKeMQkDau(rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs),Vk54F7GcROfCy6HunEI,Gb6kwVlSQ4MU=1000)
		if htb7VcAOWvsp5mlMI2kF:
			Gb6kwVlSQ4MU.sleep(2)
			for PPmYnWkqTCfNH1u4yoRs in l60lMErGLtXhkcmpQ4DW1: Mo9lQ7Iux1bKmPtFa8W[PPmYnWkqTCfNH1u4yoRs].join(10)
			Gb6kwVlSQ4MU.sleep(2)
		for PPmYnWkqTCfNH1u4yoRs in l60lMErGLtXhkcmpQ4DW1:
			try: tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
			except: continue
			for UjJmZkLhvwxtl4Hzob7nRd5 in h9zFQKnsNL.menuItemsLIST:
				hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH = UjJmZkLhvwxtl4Hzob7nRd5
				if e6TULIp9Qk3XgJ1C84AoSfsWh7dOG in EDy0Rs9liwjZvJY:
					if 'IPTV-' in PPmYnWkqTCfNH1u4yoRs and (239>=Yz6schq9wSmiu3IOdke0DXPj5W>=230 or 289>=Yz6schq9wSmiu3IOdke0DXPj5W>=280):
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['IPTV-LIVE']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['IPTV-MOVIES']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['IPTV-SERIES']: continue
						if 'صفحة' not in EDy0Rs9liwjZvJY:
							if   hArRgv5l10sU2yVSCO9JBHbE=='live': PPmYnWkqTCfNH1u4yoRs = 'IPTV-LIVE'
							elif hArRgv5l10sU2yVSCO9JBHbE=='video': PPmYnWkqTCfNH1u4yoRs = 'IPTV-MOVIES'
							elif hArRgv5l10sU2yVSCO9JBHbE=='folder': PPmYnWkqTCfNH1u4yoRs = 'IPTV-SERIES'
						else:
							if   'LIVE' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'IPTV-LIVE'
							elif 'MOVIES' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'IPTV-MOVIES'
							elif 'SERIES' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'IPTV-SERIES'
					elif 'M3U-' in PPmYnWkqTCfNH1u4yoRs and 729>=Yz6schq9wSmiu3IOdke0DXPj5W>=710:
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['M3U-LIVE']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['M3U-MOVIES']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['M3U-SERIES']: continue
						if 'صفحة' not in EDy0Rs9liwjZvJY:
							if   hArRgv5l10sU2yVSCO9JBHbE=='live': PPmYnWkqTCfNH1u4yoRs = 'M3U-LIVE'
							elif hArRgv5l10sU2yVSCO9JBHbE=='video': PPmYnWkqTCfNH1u4yoRs = 'M3U-MOVIES'
							elif hArRgv5l10sU2yVSCO9JBHbE=='folder': PPmYnWkqTCfNH1u4yoRs = 'M3U-SERIES'
						else:
							if   'LIVE' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'M3U-LIVE'
							elif 'MOVIES' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'M3U-MOVIES'
							elif 'SERIES' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'M3U-SERIES'
					elif 'YOUTUBE-' in PPmYnWkqTCfNH1u4yoRs and 149>=Yz6schq9wSmiu3IOdke0DXPj5W>=140:
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['YOUTUBE-CHANNELS']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['YOUTUBE-PLAYLISTS']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in EDy0Rs9liwjZvJY or ':: ' in EDy0Rs9liwjZvJY:
							continue
						else:
							if   Yz6schq9wSmiu3IOdke0DXPj5W==144 and 'USER' in EDy0Rs9liwjZvJY: PPmYnWkqTCfNH1u4yoRs = 'YOUTUBE-CHANNELS'
							elif Yz6schq9wSmiu3IOdke0DXPj5W==144 and 'CHNL' in EDy0Rs9liwjZvJY: PPmYnWkqTCfNH1u4yoRs = 'YOUTUBE-CHANNELS'
							elif Yz6schq9wSmiu3IOdke0DXPj5W==144 and 'LIST' in EDy0Rs9liwjZvJY: PPmYnWkqTCfNH1u4yoRs = 'YOUTUBE-PLAYLISTS'
							elif Yz6schq9wSmiu3IOdke0DXPj5W==143: PPmYnWkqTCfNH1u4yoRs = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in PPmYnWkqTCfNH1u4yoRs and 419>=Yz6schq9wSmiu3IOdke0DXPj5W>=400:
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['DAILYMOTION-PLAYLISTS']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['DAILYMOTION-CHANNELS']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['DAILYMOTION-VIDEOS']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['DAILYMOTION-LIVES']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['DAILYMOTION-HASHTAGS']: continue
						if   Yz6schq9wSmiu3IOdke0DXPj5W in [401,405]: PPmYnWkqTCfNH1u4yoRs = 'DAILYMOTION-PLAYLISTS'
						elif Yz6schq9wSmiu3IOdke0DXPj5W in [402,406]: PPmYnWkqTCfNH1u4yoRs = 'DAILYMOTION-CHANNELS'
						elif Yz6schq9wSmiu3IOdke0DXPj5W in [404]: PPmYnWkqTCfNH1u4yoRs = 'DAILYMOTION-VIDEOS'
						elif Yz6schq9wSmiu3IOdke0DXPj5W in [415]: PPmYnWkqTCfNH1u4yoRs = 'DAILYMOTION-LIVES'
						elif Yz6schq9wSmiu3IOdke0DXPj5W in [416]: PPmYnWkqTCfNH1u4yoRs = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in PPmYnWkqTCfNH1u4yoRs and 39>=Yz6schq9wSmiu3IOdke0DXPj5W>=30:
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['PANET-SERIES']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['PANET-MOVIES']: continue
						if   Yz6schq9wSmiu3IOdke0DXPj5W in [32,39]: PPmYnWkqTCfNH1u4yoRs = 'PANET-SERIES'
						elif Yz6schq9wSmiu3IOdke0DXPj5W in [33,39]: PPmYnWkqTCfNH1u4yoRs = 'PANET-MOVIES'
					elif 'IFILM-' in PPmYnWkqTCfNH1u4yoRs and 29>=Yz6schq9wSmiu3IOdke0DXPj5W>=20:
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['IFILM-ARABIC']: continue
						if UjJmZkLhvwxtl4Hzob7nRd5 in QsuAqvaWRrVYmkfO94dJZiB3XlD['IFILM-ENGLISH']: continue
						if   '/ar.' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'IFILM-ARABIC'
						elif '/en.' in lI5ck2gjRCiw9bMTF0xHsG: PPmYnWkqTCfNH1u4yoRs = 'IFILM-ENGLISH'
					QsuAqvaWRrVYmkfO94dJZiB3XlD[PPmYnWkqTCfNH1u4yoRs].append(UjJmZkLhvwxtl4Hzob7nRd5)
		for PPmYnWkqTCfNH1u4yoRs in list(QsuAqvaWRrVYmkfO94dJZiB3XlD.keys()):
			dMEqP9hBfoTvVSA[PPmYnWkqTCfNH1u4yoRs] = []
			j3ULEfqAmXVGtZHF[PPmYnWkqTCfNH1u4yoRs] = []
			for hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in QsuAqvaWRrVYmkfO94dJZiB3XlD[PPmYnWkqTCfNH1u4yoRs]:
				UjJmZkLhvwxtl4Hzob7nRd5 = (hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
				if 'صفحة' in EDy0Rs9liwjZvJY and hArRgv5l10sU2yVSCO9JBHbE=='folder': j3ULEfqAmXVGtZHF[PPmYnWkqTCfNH1u4yoRs].append(UjJmZkLhvwxtl4Hzob7nRd5)
				else: dMEqP9hBfoTvVSA[PPmYnWkqTCfNH1u4yoRs].append(UjJmZkLhvwxtl4Hzob7nRd5)
		HsquvZinRS4w,R52Ro4OSC3JkdmGAtcnueqiHWP = [],[]
		YGX2vc8yQ71TFfHat = list(dMEqP9hBfoTvVSA.keys())
		PwDslImZiv4xUgArG = UUOlq467VQ3hpTcaJiuBKzxwY(YGX2vc8yQ71TFfHat)
		cITdv8VoylMiQjLCR1XzxfmsG = []
		for PPmYnWkqTCfNH1u4yoRs in PwDslImZiv4xUgArG:
			if 'tuple' in str(type(PPmYnWkqTCfNH1u4yoRs)):
				cITdv8VoylMiQjLCR1XzxfmsG = [PPmYnWkqTCfNH1u4yoRs]
				continue
			if PPmYnWkqTCfNH1u4yoRs not in l60lMErGLtXhkcmpQ4DW1: continue
			if dMEqP9hBfoTvVSA[PPmYnWkqTCfNH1u4yoRs]:
				zl1BiuU3fVnM5Qt2e = rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs)
				SUGka72ObyfKZo4qVF = [('link',d761ZWXHEvliYN45RzLP2+'===== '+zl1BiuU3fVnM5Qt2e+' ====='+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)]
				if 0: SQ6aWgTdjLr7lh8uY3mko2Iq = DKXP9Sy3xIB+' - '+'بحث'+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+zl1BiuU3fVnM5Qt2e
				else: SQ6aWgTdjLr7lh8uY3mko2Iq = 'بحث'+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+zl1BiuU3fVnM5Qt2e+' - '+DKXP9Sy3xIB
				if len(dMEqP9hBfoTvVSA[PPmYnWkqTCfNH1u4yoRs])<8: w8XrhGMzAxE7RNB4Hvy2W = []
				else:
					HHZmQWECjFX1zt = nMt0iueCy6K+SQ6aWgTdjLr7lh8uY3mko2Iq+ZZoLlKyInXc08j2pTGJ
					w8XrhGMzAxE7RNB4Hvy2W = [('folder',ugsWdDEf5yv0Nn+HHZmQWECjFX1zt,'closed_sites'+zodCYIev4gjbVTux7,542,Vk54F7GcROfCy6HunEI,PPmYnWkqTCfNH1u4yoRs,DKXP9Sy3xIB,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)]
				hNU8IOLFSsw75aXngfodk9peVtlE = dMEqP9hBfoTvVSA[PPmYnWkqTCfNH1u4yoRs]+j3ULEfqAmXVGtZHF[PPmYnWkqTCfNH1u4yoRs]
				H1PCpW8yzNDgfTu = cITdv8VoylMiQjLCR1XzxfmsG+SUGka72ObyfKZo4qVF+hNU8IOLFSsw75aXngfodk9peVtlE[:7]+w8XrhGMzAxE7RNB4Hvy2W
				HsquvZinRS4w += H1PCpW8yzNDgfTu
				CSdE0K6Jht9nqV = [('folder',ugsWdDEf5yv0Nn+SQ6aWgTdjLr7lh8uY3mko2Iq,'closed_sites'+zodCYIev4gjbVTux7,542,Vk54F7GcROfCy6HunEI,PPmYnWkqTCfNH1u4yoRs,DKXP9Sy3xIB,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI)]
				Q0OFu5TUzdSwaY9 = cITdv8VoylMiQjLCR1XzxfmsG+CSdE0K6Jht9nqV
				R52Ro4OSC3JkdmGAtcnueqiHWP += Q0OFu5TUzdSwaY9
				FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DIVIDED'+OTkfxvAVU7,(PPmYnWkqTCfNH1u4yoRs,DKXP9Sy3xIB),hNU8IOLFSsw75aXngfodk9peVtlE,mXdxepDh683FuUKlb0)
				cITdv8VoylMiQjLCR1XzxfmsG = []
		FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'GLOBALSEARCH_DETAILED'+OTkfxvAVU7,DKXP9Sy3xIB,HsquvZinRS4w,mXdxepDh683FuUKlb0)
		kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,DKXP9Sy3xIB)
		FgY4iT81AjHC6239Q(OKzSt0JnAdvh2mM,'GLOBALSEARCH_SPLITTED'+OTkfxvAVU7,ugsWdDEf5yv0Nn+DKXP9Sy3xIB,R52Ro4OSC3JkdmGAtcnueqiHWP,mXdxepDh683FuUKlb0)
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		mbkDP4HleQG2yqA6CKNV3s8FZIU9 = R52Ro4OSC3JkdmGAtcnueqiHWP if PfeJCqUoA1kjHQW7zgTNLt54=='listed_sites'+zodCYIev4gjbVTux7 and R52Ro4OSC3JkdmGAtcnueqiHWP else HsquvZinRS4w
	if PfeJCqUoA1kjHQW7zgTNLt54 in ['listed_sites'+zodCYIev4gjbVTux7,'opened_sites'+zodCYIev4gjbVTux7,'closed_sites'+zodCYIev4gjbVTux7]:
		for hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH in mbkDP4HleQG2yqA6CKNV3s8FZIU9:
			if PfeJCqUoA1kjHQW7zgTNLt54 in ['listed_sites'+zodCYIev4gjbVTux7,'opened_sites'+zodCYIev4gjbVTux7] and 'صفحة' in EDy0Rs9liwjZvJY and hArRgv5l10sU2yVSCO9JBHbE=='folder': continue
			v0TjHlLZqkRxUCpmNwSy8AndO(hArRgv5l10sU2yVSCO9JBHbE,EDy0Rs9liwjZvJY,lI5ck2gjRCiw9bMTF0xHsG,Yz6schq9wSmiu3IOdke0DXPj5W,ylKTDSkdQmUChwbX45ALeiu,H4TFmtAe5rM8oY1lfPviVC,YWCso5NMKO,rF0ghTZEyQ,Xb17xtEphFigA8dReBrGH)
	igFtOzLBeQu(I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB,I3IivNQUYMoVL5zbmnZWgaAudfB)
	return
def aPnpNWwrK9(search):
	PwDslImZiv4xUgArG = UUOlq467VQ3hpTcaJiuBKzxwY(HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi)
	for PPmYnWkqTCfNH1u4yoRs in PwDslImZiv4xUgArG:
		if '-' in PPmYnWkqTCfNH1u4yoRs: continue
		if 'tuple' in str(type(PPmYnWkqTCfNH1u4yoRs)):
			h9zFQKnsNL.menuItemsLIST.append(PPmYnWkqTCfNH1u4yoRs)
			continue
		tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
		name = rLjksYNqhOBoHl3WREm8p(PPmYnWkqTCfNH1u4yoRs)+' - '+search
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',e6TULIp9Qk3XgJ1C84AoSfsWh7dOG+name,PPmYnWkqTCfNH1u4yoRs,548,'','',search)
	return
def njJHKa5SByWrDxCFzUtPEvI(PPmYnWkqTCfNH1u4yoRs,search):
	tlZBeT1Y2RjIu,hjBWFnCMqr,e6TULIp9Qk3XgJ1C84AoSfsWh7dOG = gqabt6CPSOkZnsyY418zoHD0Ucp(PPmYnWkqTCfNH1u4yoRs)
	hjBWFnCMqr(search)
	return
def ak6T4YuSbKgnP3eXL9cHAOC07BmWFQ():
	GHdYDixegkm9PJMN('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def Icj876ivtblFxVqw43MW(DKXP9Sy3xIB=Vk54F7GcROfCy6HunEI):
	rXEdWpTOxkiLqY8vfjUBn,tFleBaQ2fUrNiPdu3k8cpjWCxS7,showDialogs = HD6MGAiC4TrtXdc9ge7I(DKXP9Sy3xIB)
	if not rXEdWpTOxkiLqY8vfjUBn:
		rXEdWpTOxkiLqY8vfjUBn = p3bB2auMmSjXC0dE8FUfZ()
		if not rXEdWpTOxkiLqY8vfjUBn: return
		rXEdWpTOxkiLqY8vfjUBn = rXEdWpTOxkiLqY8vfjUBn.lower()
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+'   Search For: [ '+rXEdWpTOxkiLqY8vfjUBn+' ]')
	HJVMp5sLkG7EnixWo3QOg = rXEdWpTOxkiLqY8vfjUBn+tFleBaQ2fUrNiPdu3k8cpjWCxS7
	if 0: lHuoCvsZ8wIcAdYKNRbai5zx0nBWP,QTu5DMfvn62aRLhKq07 = rXEdWpTOxkiLqY8vfjUBn+' - ',Vk54F7GcROfCy6HunEI
	else: lHuoCvsZ8wIcAdYKNRbai5zx0nBWP,QTu5DMfvn62aRLhKq07 = Vk54F7GcROfCy6HunEI,' - '+rXEdWpTOxkiLqY8vfjUBn
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'مواقع سيرفرات خاصة - قليلة المشاكل'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,157)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_M3U_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث M3U'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,719,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_IPT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث IPTV'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,239,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_BKR_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع بكرا'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,379,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_ART_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع تونز عربية'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,739,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_KRB_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع قناة كربلاء'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,329,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FH2_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فاصل الثاني'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,599,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_KTV_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع كتكوت تيفي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,819,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_EB1_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع ايجي بيست 1'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,779,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_EB2_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع ايجي بيست 2'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,789,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_IFL_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'  بحث موقع قناة آي فيلم'+QTu5DMfvn62aRLhKq07+YIPoWuLzfl93BTS,Vk54F7GcROfCy6HunEI,29,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_AKO_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع أكوام القديم'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,79,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_AKW_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع أكوام الجديد'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,249,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_MRF_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع قناة المعارف'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,49,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SHM_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شوف ماكس'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,59,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,157)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_LRZ_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع لاروزا'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,709,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FJS_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+' بحث موقع فجر شو'+QTu5DMfvn62aRLhKq07+otBWsSAfu7dihVkP9e1JFKrvmYy2Q,Vk54F7GcROfCy6HunEI,399,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TVF_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع تيفي فان'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,469,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_LDN_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع لودي نت'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,459,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CMN_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما ناو'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,309,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SHN_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شاهد نيوز'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,589,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg+'_NODIALOGS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_ARS_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع عرب سييد'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,259,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CCB_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما كلوب'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,829,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SH4_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شاهد فوريو'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,119,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg+'_NODIALOGS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SHT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شوفها تيفي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,649,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_WC1_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع وي سيما 1'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,569,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_WC2_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع وي سيما 2'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,1009,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'مواقع سيرفرات عامة - كثيرة المشاكل'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,157)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_TKT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع تكات'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,949,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FST_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فوستا'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,609,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FBK_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فبركة'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,629,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_YQT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع ياقوت'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,669,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SHB_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شبكتي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,969,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_VRB_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فاربون'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,879,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_BRS_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع برستيج'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,659,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_KRM_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع كرمالك'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,929,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_ANZ_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع انمي زد'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,979,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FSK_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فارسكو'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,999,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_HLC_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع هلا سيما'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,89,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_MST_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع المصطبة'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,869,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SNT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع شوف نت'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,849,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_DR7_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع دراما صح'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,689,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CFR_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما فري'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,839,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CMF_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما فانز'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,99,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CML_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما لايت'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,479,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_C4H_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما 400'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,699,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_ABD_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما عبدو'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,559,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_AKT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع اكوام تيوب'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,859,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_DCF_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع دراما كافيه'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,939,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FTV_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فوشار تيفي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,919,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_CWB_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما وبس'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,989,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_AHK_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع أهواك تيفي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,619,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_SRT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيريس تايم'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,899,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_FVD_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع فوشار فيديو'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,909,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_C4P_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع سيما فور بي'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,889,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_EB4_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع ايجي بيست 4'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,809,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+'مواقع سيرفرات خاصة - قليلة المشاكل'+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,157)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_YUT_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع يوتيوب'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,149,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder','_DLM_'+lHuoCvsZ8wIcAdYKNRbai5zx0nBWP+'بحث موقع دايلي موشن'+QTu5DMfvn62aRLhKq07,Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HJVMp5sLkG7EnixWo3QOg)
	return
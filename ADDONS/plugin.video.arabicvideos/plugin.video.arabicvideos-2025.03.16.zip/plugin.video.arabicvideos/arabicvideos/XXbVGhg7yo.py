# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'MOVS4U'
xzA9sM3rG6IHd7jl8T = '_M4U_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['انواع افلام','جودات افلام']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==380: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==381: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==382: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==383: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==389: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,389,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المميزة',FFLhlYUAsfJBXeQmRpzD7c14ZP6,381,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الجانبية',FFLhlYUAsfJBXeQmRpzD7c14ZP6,381,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'sider')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MOVS4U-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = RSuYINdeamsK0t.findall('<header>.*?<h2>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for W7SMIpbzhori2JE9mv in range(len(items)):
		title = items[W7SMIpbzhori2JE9mv]
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,FFLhlYUAsfJBXeQmRpzD7c14ZP6,381,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'latest'+str(W7SMIpbzhori2JE9mv))
	UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="menu"(.*?)id="contenedor"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh: UwcYSVZbdK3rI += Ry3L7fdNGh[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="sidebar(.*?)aside',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh: UwcYSVZbdK3rI += Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	jnyGYUoM3gNOVf = True
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		title = Uo7Tbc29Eu(title)
		if title=='الأعلى مشاهدة':
			if jnyGYUoM3gNOVf:
				title = 'الافلام '+title
				jnyGYUoM3gNOVf = False
			else: title = 'المسلسلات '+title
		if title not in wXPtB6I0QKLTyD932sl5d:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,381)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,type):
	UwcYSVZbdK3rI,items = [],[]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MOVS4U-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if type=='search':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="search-page"(.*?)class="sidebar',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	elif type=='sider':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="widget(.*?)class="widget',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		qGwD7PzckpIjt2VOYBJXT8MeLRradu = RSuYINdeamsK0t.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,UmRYTiht1H8oqzwKr,nWcb8JC7zEVouFjx9fILGh1vSQ = zip(*qGwD7PzckpIjt2VOYBJXT8MeLRradu)
		items = zip(UmRYTiht1H8oqzwKr,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,nWcb8JC7zEVouFjx9fILGh1vSQ)
	elif type=='featured':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="slider-movies-tvshows"(.*?)<header>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	elif 'latest' in type:
		W7SMIpbzhori2JE9mv = int(type[-1:])
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('<header>','<end><start>')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace('<div class="sidebar','<end><div class="sidebar')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<start>(.*?)<end>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[W7SMIpbzhori2JE9mv]
		if W7SMIpbzhori2JE9mv==2: items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="content"(.*?)class="(pagination|sidebar)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0][0]
			if '/collection/' in url:
				items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			elif '/quality/' in url:
				items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if not items and UwcYSVZbdK3rI:
		items = RSuYINdeamsK0t.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if 'serie' in title:
			title = RSuYINdeamsK0t.findall('^(.*?)<.*?serie">(.*?)<',title,RSuYINdeamsK0t.DOTALL)
			title = title[0][1]
			if title in GEzxBN8rAh1d: continue
			GEzxBN8rAh1d.append(title)
			title = '_MOD_'+title
		esUNcDaPg3QoX = RSuYINdeamsK0t.findall('^(.*?)<',title,RSuYINdeamsK0t.DOTALL)
		if esUNcDaPg3QoX: title = esUNcDaPg3QoX[0]
		title = Uo7Tbc29Eu(title)
		if '/tvshows/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,383,afR4xElWyzgcNAUnKXBempC)
		elif '/episodes/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,383,afR4xElWyzgcNAUnKXBempC)
		elif '/seasons/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,383,afR4xElWyzgcNAUnKXBempC)
		elif '/collection/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,381,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,382,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		NIZyMKFmouYp12l8nS0JWB75T = Ry3L7fdNGh[0][0]
		wOApjmQckCWbLd3UheMFPa158SI2Xi = Ry3L7fdNGh[0][1]
		UwcYSVZbdK3rI = Ry3L7fdNGh[0][2]
		items = RSuYINdeamsK0t.findall("href='(.*?)'.*?>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title==Vk54F7GcROfCy6HunEI or title==wOApjmQckCWbLd3UheMFPa158SI2Xi: continue
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,381,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('/page/'+title+'/','/page/'+wOApjmQckCWbLd3UheMFPa158SI2Xi+'/')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'اخر صفحة '+wOApjmQckCWbLd3UheMFPa158SI2Xi,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,381,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,type)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MOVS4U-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('class="C rated".*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco,False):
		v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+'المسلسل للكبار والمبرمج منعه',Vk54F7GcROfCy6HunEI,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('''class='item'><a href="(.*?)"''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if hj50MJnoOp6ZWaS1IQ8Elr:
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[1]
			SQr4lDstIa0NdFyp7Pf23BG6jnLY(hj50MJnoOp6ZWaS1IQ8Elr)
			return
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''class='episodios'(.*?)id="cast"''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,AWjJSatwokZ,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			title = AWjJSatwokZ+' : '+name+' الحلقة'
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,382)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'MOVS4U-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('class="C rated".*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0][0]
		items = RSuYINdeamsK0t.findall("data-url='(.*?)'.*?class='server'>(.*?)<",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="remodal"(.*?)class="remodal-close"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/?s='+search
	txsXO7gSMnrwAh6NmJ9D(url,'search')
	return
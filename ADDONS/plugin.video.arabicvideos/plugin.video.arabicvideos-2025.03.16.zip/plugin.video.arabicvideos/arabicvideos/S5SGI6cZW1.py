# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SHOOFPRO'
xzA9sM3rG6IHd7jl8T = '_SHP_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['مصارعة','بث مباشر']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==480: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==481: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==482: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==483: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,text)
	elif mode==489: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,url)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFPRO-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RSuYINdeamsK0t.findall('href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	lseWcUVP5qY = lseWcUVP5qY[0].strip('/')
	lseWcUVP5qY = RRav1Sf7Px(lseWcUVP5qY,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',lseWcUVP5qY,489,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أحدث المواضيع',lseWcUVP5qY,481)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"navigation"(.*?)"myAccount"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?</span>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
		if title in wXPtB6I0QKLTyD932sl5d: continue
		title = Uo7Tbc29Eu(title)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,481)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,cLsbuoidlKTYVI8F9C0hkZ):
	items = []
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFPRO-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"post(.*?)"footer"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	CCBKIYR8LFtJq = '/'.join(cLsbuoidlKTYVI8F9C0hkZ.strip('/').split('/')[4:]).split('-')
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
		title = Uo7Tbc29Eu(title)
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) حلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if cLsbuoidlKTYVI8F9C0hkZ:
			YBDKFZOGfyCHLPA1EaUz9MJ = '/'.join(ssfLBvkuNiXear2gPdxcyT4AQMhYSp.strip('/').split('/')[4:]).split('-')
			UC4guQ2jmP = len([M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa for M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa in CCBKIYR8LFtJq if M8p5bXVOCkqwiFU4lQ3InSmBdLtEGa in YBDKFZOGfyCHLPA1EaUz9MJ])
			if UC4guQ2jmP>2 and '/episodes/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,482,afR4xElWyzgcNAUnKXBempC)
		else:
			if not AWjJSatwokZ: AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
			if set(title.split()) & set(dCniDoJbH5Kkqaty14f8RQI) and 'مسلسل' not in title:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,482,afR4xElWyzgcNAUnKXBempC)
			elif AWjJSatwokZ and 'حلقة' in title:
				title = '_MOD_' + AWjJSatwokZ[0]
				if title not in GEzxBN8rAh1d:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,483,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,url)
					GEzxBN8rAh1d.append(title)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,483,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,url)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall("'pagination'(.*?)</div>",FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall("href='(.*?)'.*?>(.*?)</a>",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			title = Uo7Tbc29Eu(title)
			title = title.replace('الصفحة ',Vk54F7GcROfCy6HunEI)
			if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,481,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cLsbuoidlKTYVI8F9C0hkZ)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,hj50MJnoOp6ZWaS1IQ8Elr):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFPRO-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"img-responsive" src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if afR4xElWyzgcNAUnKXBempC: afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
	else: afR4xElWyzgcNAUnKXBempC = J2L6to3R1Z.getInfoLabel('ListItem.Thumb')
	ZZUlFGqWyzpkwNrTLCgJOP6tKbnsD = True
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"listSeasons(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x and '/ajax/seasons' not in url:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		count = UwcYSVZbdK3rI.count('data-slug=')
		if count==0: count = UwcYSVZbdK3rI.count('data-season=')
		if count>1:
			ZZUlFGqWyzpkwNrTLCgJOP6tKbnsD = False
			if 'data-slug="' in UwcYSVZbdK3rI:
				items = RSuYINdeamsK0t.findall('data-slug="(.*?)">(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for id,title in items:
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,483,afR4xElWyzgcNAUnKXBempC)
			else:
				items = RSuYINdeamsK0t.findall('data-season="(.*?)">(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
				for id,title in items:
					ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,483,afR4xElWyzgcNAUnKXBempC)
	if ZZUlFGqWyzpkwNrTLCgJOP6tKbnsD:
		UwcYSVZbdK3rI = Vk54F7GcROfCy6HunEI
		if '/ajax/seasons' in url: UwcYSVZbdK3rI = FjwObZSWkg8ahBdiQf9IeY135DpXoP
		else:
			QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"eplist"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			if QQHXiFSA0jUsklmxbpaMztu: UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,482,afR4xElWyzgcNAUnKXBempC)
	if not h9zFQKnsNL.menuItemsLIST: txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr,url)
	return
def h5hmzOAeWEPip(url):
	hj50MJnoOp6ZWaS1IQ8Elr = url.strip('/')+'/?do=watch'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFPRO-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	lseWcUVP5qY = RRav1Sf7Px(url,'url')
	X9PVULyJeCSviHfhmj0Gku6tgZz2 = RSuYINdeamsK0t.findall('vo_postID = "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not X9PVULyJeCSviHfhmj0Gku6tgZz2: X9PVULyJeCSviHfhmj0Gku6tgZz2 = RSuYINdeamsK0t.findall('\(this\.id\,0\,(.*?)\)',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	X9PVULyJeCSviHfhmj0Gku6tgZz2 = X9PVULyJeCSviHfhmj0Gku6tgZz2[0]
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"serversList"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('id="(.*?)".*?">(.*?)</li>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for Ljqg7JpF5Rmk12,title in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+X9PVULyJeCSviHfhmj0Gku6tgZz2+'&video='+Ljqg7JpF5Rmk12[2:]+'?named='+title+'__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('"getEmbed".*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		title = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0],'url')
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]+'?named='+title+'__embed'
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	hj50MJnoOp6ZWaS1IQ8Elr = url.strip('/')+'/?do=download'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFPRO-PLAY-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"table-responsive"(.*?)</table>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('<td>(.*?)</td>.*?href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'anavidz' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: esUNcDaPg3QoX = '__خاص'
			else: esUNcDaPg3QoX = Vk54F7GcROfCy6HunEI
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__download'+esUNcDaPg3QoX
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search,lseWcUVP5qY=Vk54F7GcROfCy6HunEI):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	if lseWcUVP5qY==Vk54F7GcROfCy6HunEI: lseWcUVP5qY = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	url = lseWcUVP5qY+'/search/'+search+'/'
	txsXO7gSMnrwAh6NmJ9D(url,Vk54F7GcROfCy6HunEI)
	return
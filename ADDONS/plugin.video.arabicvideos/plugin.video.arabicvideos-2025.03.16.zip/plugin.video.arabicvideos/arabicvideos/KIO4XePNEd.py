# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
headers = { 'User-Agent' : Vk54F7GcROfCy6HunEI }
TVPm7Bz1XOwJ2 = 'AKWAM'
xzA9sM3rG6IHd7jl8T = '_AKW_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
tqXiUkhm1YWvfsp = Vk54F7GcROfCy6HunEI
wXPtB6I0QKLTyD932sl5d = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==240: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==241: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==242: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==243: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==244: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'FILTERS___'+text)
	elif mode==245: w8YsNWfQ5gFluRvOmSd4Cb96H = dm9YWrf845oej12ICpRnTgtSiQxV(url,'CATEGORIES___'+text)
	elif mode==246: w8YsNWfQ5gFluRvOmSd4Cb96H = QSHFupMwek4XK(url)
	elif mode==247: w8YsNWfQ5gFluRvOmSd4Cb96H = XcikCAhSReImLGMof1aOTErz85JP(url)
	elif mode==248: w8YsNWfQ5gFluRvOmSd4Cb96H = qodbXMrVAlkaKTZhGv1SuE()
	elif mode==249: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def qodbXMrVAlkaKTZhGv1SuE():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'AKWAM-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	wRdcoue4j95HWftLpYC = RSuYINdeamsK0t.findall('home-site-btn-container.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if wRdcoue4j95HWftLpYC: wRdcoue4j95HWftLpYC = wRdcoue4j95HWftLpYC[0]
	else: wRdcoue4j95HWftLpYC = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',wRdcoue4j95HWftLpYC,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'AKWAM-MENU-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,249,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6,246)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6,247)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المميزة',wRdcoue4j95HWftLpYC,241,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	recent = RSuYINdeamsK0t.findall('recently-container.*?href="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = recent[0]
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'أضيف حديثا',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,241)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name,UwcYSVZbdK3rI in Ry3L7fdNGh:
		if name in wXPtB6I0QKLTyD932sl5d: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,241)
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title in wXPtB6I0QKLTyD932sl5d: continue
			title = name+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+title
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,241)
	return
def QSHFupMwek4XK(website=Vk54F7GcROfCy6HunEI):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'AKWAM-MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="menu(.*?)<nav',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?text">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title not in wXPtB6I0QKLTyD932sl5d:
				title = title+' مصنفة'
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,245)
		if website==Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def XcikCAhSReImLGMof1aOTErz85JP(website=Vk54F7GcROfCy6HunEI):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'AKWAM-MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="menu(.*?)<nav',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?text">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title not in wXPtB6I0QKLTyD932sl5d:
				title = title+' مفلترة'
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,244)
		if website==Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def txsXO7gSMnrwAh6NmJ9D(url,type=Vk54F7GcROfCy6HunEI):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': Ry3L7fdNGh = RSuYINdeamsK0t.findall('swiper-container(.*?)swiper-button-prev',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	else: Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="widget"(.*?)main-footer',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if not items:
			items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if '/series/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp or '/shows/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,242,afR4xElWyzgcNAUnKXBempC)
			elif '/movies/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,243,afR4xElWyzgcNAUnKXBempC)
			elif '/games/' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,243,afR4xElWyzgcNAUnKXBempC)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('pagination(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Uo7Tbc29Eu(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,241)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/search?q='+HJVMp5sLkG7EnixWo3QOg
	w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		afR4xElWyzgcNAUnKXBempC = J2L6to3R1Z.getInfoLabel('ListItem.Icon')
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+'رابط التشغيل',url,243,afR4xElWyzgcNAUnKXBempC)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('-episodes">(.*?)<div class="widget-4',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		NTaCesPm04 = RSuYINdeamsK0t.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in NTaCesPm04:
			title = title.replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,242,afR4xElWyzgcNAUnKXBempC)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,243,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,True,'AKWAM-PLAY-1st')
	TwIJRB04mjGDfpz7CQMdco = RSuYINdeamsK0t.findall('badge-danger.*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if TwIJRB04mjGDfpz7CQMdco and tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,url,TwIJRB04mjGDfpz7CQMdco): return
	zHu1amneXB7dxyWCNLKrZ = RSuYINdeamsK0t.findall('li><a href="#(.*?)".*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,nWcb8JC7zEVouFjx9fILGh1vSQ,DatFuedGb45zR1KqIWNk,X1im9dY2EaQvN6 = [],[],[],[]
	if zHu1amneXB7dxyWCNLKrZ:
		k2kRdMUp0qmI9Hrv = 'mp4'
		for nc4wgDyBRPEWiHf5mxYGNVql,jMiru3pGns in zHu1amneXB7dxyWCNLKrZ:
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('tab-content quality" id="'+nc4wgDyBRPEWiHf5mxYGNVql+'".*?</div>.\s*</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			DatFuedGb45zR1KqIWNk.append(UwcYSVZbdK3rI)
			X1im9dY2EaQvN6.append(jMiru3pGns)
	else:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="qualities(.*?)<h3.*?>(.*?)<',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if not Ry3L7fdNGh:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			UwcYSVZbdK3rI,filename = Ry3L7fdNGh[0]
			bBwKX6xvjLkq = ['zip','rar','txt','pdf','htm','tar','iso','html']
			k2kRdMUp0qmI9Hrv = filename.rsplit('.',1)[1].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if k2kRdMUp0qmI9Hrv in bBwKX6xvjLkq:
				GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		DatFuedGb45zR1KqIWNk.append(UwcYSVZbdK3rI)
		X1im9dY2EaQvN6.append(Vk54F7GcROfCy6HunEI)
	for zHq7nBWJTNyY1I3aLco4AR in range(len(DatFuedGb45zR1KqIWNk)):
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('href="(.*?)".*?icon-(.*?)"',DatFuedGb45zR1KqIWNk[zHq7nBWJTNyY1I3aLco4AR],RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,CC9KDn4X1v0poIrkTbj in HXhRgxEZ4d2Dek:
			if 'torrent' in CC9KDn4X1v0poIrkTbj: continue
			elif 'download' in CC9KDn4X1v0poIrkTbj: type = 'download'
			elif 'play' in CC9KDn4X1v0poIrkTbj: type = 'watch'
			else: type = 'unknown'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named=__'+type+'____'+X1im9dY2EaQvN6[zHq7nBWJTNyY1I3aLco4AR]+'__akwam'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	jVTGDSdXIEbQJ6ueqK19w = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='CATEGORIES':
		if jVTGDSdXIEbQJ6ueqK19w[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(jVTGDSdXIEbQJ6ueqK19w[0:-1])):
			if jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'all')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='FILTERS':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'all')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'?'+KMbV6CGYIuH
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها',hj50MJnoOp6ZWaS1IQ8Elr,241,Vk54F7GcROfCy6HunEI,'1')
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',hj50MJnoOp6ZWaS1IQ8Elr,241,Vk54F7GcROfCy6HunEI,'1')
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,headers,True,'AKWAM-FILTERS_MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('<form id(.*?)</form>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ugep4NW1YS = RSuYINdeamsK0t.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	dict = {}
	for kuKGA8HpgN7PyjvxeLZ,name,UwcYSVZbdK3rI in Ugep4NW1YS:
		items = RSuYINdeamsK0t.findall('<option(.*?)>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='CATEGORIES':
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<=1:
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]: txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'CATEGORIES___'+Ng1Jod47fp0S)
				return
			else:
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,241,Vk54F7GcROfCy6HunEI,'1')
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,245,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='FILTERS':
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع : '+name,hj50MJnoOp6ZWaS1IQ8Elr,244,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			if 'value' not in value: value = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			else: value = RSuYINdeamsK0t.findall('"(.*?)"',value,RSuYINdeamsK0t.DOTALL)[0]
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' : '#+dict[kuKGA8HpgN7PyjvxeLZ]['0']
			title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' : '+name
			if type=='FILTERS': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,244,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='CATEGORIES' and jVTGDSdXIEbQJ6ueqK19w[-2]+'=' in UWFh8TfCJpRomD3:
				aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'all')
				ynmiDuav5ICTeRsqj6Vb18Q = url+'?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,241,Vk54F7GcROfCy6HunEI,'1')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,245,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	LJSlAbTd4vknNqtOUZDm = ['section','category','rating','year','language','formats','quality']
	for key in LJSlAbTd4vknNqtOUZDm:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	return PpjxGzO7yqD0AXSJL1Mw
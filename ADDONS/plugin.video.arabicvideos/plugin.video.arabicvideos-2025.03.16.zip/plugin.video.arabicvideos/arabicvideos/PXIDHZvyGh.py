# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ALARAB'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_KLA_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==10: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==11: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==12: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==13: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==14: w8YsNWfQ5gFluRvOmSd4Cb96H = DZjbwYA1GS7tsv()
	elif mode==15: w8YsNWfQ5gFluRvOmSd4Cb96H = XQGSEczOZMRoxgbi1WqeCt()
	elif mode==16: w8YsNWfQ5gFluRvOmSd4Cb96H = nPtvlBeUcTW4ZaIC0s7bmVLj()
	elif mode==19: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,19,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'آخر الإضافات',Vk54F7GcROfCy6HunEI,14)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان',Vk54F7GcROfCy6HunEI,15)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,'ALARAB-MENU-1st')
	Ry3L7fdNGh=RSuYINdeamsK0t.findall('id="nav-slider"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	kegG92RvhzJYTQO = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',kegG92RvhzJYTQO,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,11)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="navbar"(.*?)</div>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	v8e07ENZbVzIjaMSQPAxLUyuKcWho = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',v8e07ENZbVzIjaMSQPAxLUyuKcWho,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,11)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def XQGSEczOZMRoxgbi1WqeCt():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'جميع المسلسلات العربية',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/view-8/مسلسلات-عربية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات السنة الأخيرة',Vk54F7GcROfCy6HunEI,16)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان الأخيرة 1',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/view-8/مسلسلات-رمضان-2022',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان الأخيرة 2',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/view-8/مسلسلات-رمضان-2023',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2023',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2023/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2022',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2022/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2021',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2021/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2020',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2020/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2019',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2019/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2018',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2018/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2017',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2017/مصرية',11)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات رمضان 2016',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/ramadan2016/مصرية',11)
	return
def DZjbwYA1GS7tsv():
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,True,'ALARAB-LATEST-1st')
	Ry3L7fdNGh=RSuYINdeamsK0t.findall('heading-top(.*?)div class=',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]+Ry3L7fdNGh[1]
	items=RSuYINdeamsK0t.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if 'series' in url: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,11,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,12,afR4xElWyzgcNAUnKXBempC)
	return
def txsXO7gSMnrwAh6NmJ9D(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,headers,True,True,'ALARAB-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('video-category(.*?)right_content',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	ydWEcgbFm0lNr42a8 = False
	items = RSuYINdeamsK0t.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d,neAK1NjwRgb2 = [],[]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
		if title==Vk54F7GcROfCy6HunEI: title = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-1].replace('-',otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = RSuYINdeamsK0t.findall('(\d+)',title,RSuYINdeamsK0t.DOTALL)
		if A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl: A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = int(A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl[0])
		else: A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl = 0
		neAK1NjwRgb2.append([afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl])
	neAK1NjwRgb2 = sorted(neAK1NjwRgb2, reverse=True, key=lambda key: key[3])
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,A9zrYc73tsQ5PgimeGqJ2Z1SBRXLl in neAK1NjwRgb2:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',Vk54F7GcROfCy6HunEI)
		title = title.replace('عالية على العرب',Vk54F7GcROfCy6HunEI)
		title = title.replace('مشاهدة مباشرة',Vk54F7GcROfCy6HunEI)
		title = title.replace('اون لاين',Vk54F7GcROfCy6HunEI)
		title = title.replace('اونلاين',Vk54F7GcROfCy6HunEI)
		title = title.replace('بجودة عالية',Vk54F7GcROfCy6HunEI)
		title = title.replace('جودة عالية',Vk54F7GcROfCy6HunEI)
		title = title.replace('بدون تحميل',Vk54F7GcROfCy6HunEI)
		title = title.replace('على العرب',Vk54F7GcROfCy6HunEI)
		title = title.replace('مباشرة',Vk54F7GcROfCy6HunEI)
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		title = '_MOD_'+title
		esUNcDaPg3QoX = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
			if AWjJSatwokZ: esUNcDaPg3QoX = AWjJSatwokZ[0]
		if esUNcDaPg3QoX not in GEzxBN8rAh1d:
			GEzxBN8rAh1d.append(esUNcDaPg3QoX)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+esUNcDaPg3QoX,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,13,afR4xElWyzgcNAUnKXBempC)
				ydWEcgbFm0lNr42a8 = True
			elif 'series' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,11,afR4xElWyzgcNAUnKXBempC)
				ydWEcgbFm0lNr42a8 = True
			else:
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,12,afR4xElWyzgcNAUnKXBempC)
				ydWEcgbFm0lNr42a8 = True
	if ydWEcgbFm0lNr42a8:
		items = RSuYINdeamsK0t.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,H4TFmtAe5rM8oY1lfPviVC in items:
			url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+H4TFmtAe5rM8oY1lfPviVC,url,11)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,headers,True,'ALARAB-EPISODES-1st')
	Bs8RqnbjT6tXJYE5IogcD3yzamN = RSuYINdeamsK0t.findall('href="(/series.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6+Bs8RqnbjT6tXJYE5IogcD3yzamN[0]
	w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(hj50MJnoOp6ZWaS1IQ8Elr)
	return
def h5hmzOAeWEPip(url):
	yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = []
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(CnJ1ePvdKQ2R,url,Vk54F7GcROfCy6HunEI,headers,True,'ALARAB-PLAY-1st')
	hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('class="resp-iframe" src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if hj50MJnoOp6ZWaS1IQ8Elr:
		hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('^(http.*?)(http.*?)$',hj50MJnoOp6ZWaS1IQ8Elr,RSuYINdeamsK0t.DOTALL)
		if HXhRgxEZ4d2Dek:
			jnyGYUoM3gNOVf = HXhRgxEZ4d2Dek[0][0]
			eeUdLSOF4Y3jBlbgT1IH2wxA5r,KE2CB1zL0moAhYS = HXhRgxEZ4d2Dek[0][1].rsplit('/',1)
			ynmiDuav5ICTeRsqj6Vb18Q = eeUdLSOF4Y3jBlbgT1IH2wxA5r+'?named=__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ynmiDuav5ICTeRsqj6Vb18Q)
			xIZTXEQJ7qtmF = jnyGYUoM3gNOVf+KE2CB1zL0moAhYS
		else:
			nqzvfpjFuS42ywk8 = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,headers,False,'ALARAB-PLAY-2nd')
			hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('"src": "(.*?)"',nqzvfpjFuS42ywk8,RSuYINdeamsK0t.DOTALL)
			if hj50MJnoOp6ZWaS1IQ8Elr:
				hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]+'?named=__watch__m3u8'
				yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(hj50MJnoOp6ZWaS1IQ8Elr)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('searchBox(.*?)<style>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		hj50MJnoOp6ZWaS1IQ8Elr = RSuYINdeamsK0t.findall('href="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if hj50MJnoOp6ZWaS1IQ8Elr:
			hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr[0]+'?named=__watch'
			yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(hj50MJnoOp6ZWaS1IQ8Elr)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9,TVPm7Bz1XOwJ2,'video',url)
	return
def nPtvlBeUcTW4ZaIC0s7bmVLj():
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,headers,True,'ALARAB-RAMADAN-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="content_sec"(.*?)id="left_content"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	sRY2BS9nMg0Ph = RSuYINdeamsK0t.findall('/ramadan([0-9]+)/',str(items),RSuYINdeamsK0t.DOTALL)
	sRY2BS9nMg0Ph = sRY2BS9nMg0Ph[0]
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)+otBWsSAfu7dihVkP9e1JFKrvmYy2Q+sRY2BS9nMg0Ph
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,11)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + "/q/" + HJVMp5sLkG7EnixWo3QOg
	w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	return
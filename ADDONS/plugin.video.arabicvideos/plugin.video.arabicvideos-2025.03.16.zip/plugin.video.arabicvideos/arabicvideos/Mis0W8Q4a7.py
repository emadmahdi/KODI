# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'CIMAABDO'
xzA9sM3rG6IHd7jl8T = '_ABD_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['الرئيسية']
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==550: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==551: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,text)
	elif mode==552: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==553: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==559: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/home',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RRav1Sf7Px(FFLhlYUAsfJBXeQmRpzD7c14ZP6,'url')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,559,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'اخترنا لك',lseWcUVP5qY+'/home',551,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'featured')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('main-content(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('data-name="(.*?)".*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for U8tZVnuiQqYjG5KdEWNbXF,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/ajax/getItem?item='+U8tZVnuiQqYjG5KdEWNbXF+'&Ajax=1'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,551)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"nav-main"(.*?)</nav>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,551)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=='#': continue
		if title in wXPtB6I0QKLTyD932sl5d: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,551)
	return
def txsXO7gSMnrwAh6NmJ9D(url,U8tZVnuiQqYjG5KdEWNbXF=Vk54F7GcROfCy6HunEI):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(url)
		eDbTIrV6KLfz80 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-TITLES-1st')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		Ry3L7fdNGh = [FjwObZSWkg8ahBdiQf9IeY135DpXoP]
	else:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-TITLES-2nd')
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
		if U8tZVnuiQqYjG5KdEWNbXF=='featured':
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('"container"(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		elif '"section-post mb-10"' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('"section-post mb-10"(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		else:
			Ry3L7fdNGh = RSuYINdeamsK0t.findall('<article(.*?)"pagination"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh: return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if not items:
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if not items: items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	GEzxBN8rAh1d = []
	dCniDoJbH5Kkqaty14f8RQI = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ZlBMJUAWRm9buv(ssfLBvkuNiXear2gPdxcyT4AQMhYSp).strip('/')
		AWjJSatwokZ = RSuYINdeamsK0t.findall('(.*?) الحلقة \d+',title,RSuYINdeamsK0t.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in dCniDoJbH5Kkqaty14f8RQI):
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,552,afR4xElWyzgcNAUnKXBempC)
		elif AWjJSatwokZ and 'الحلقة' in title:
			title = '_MOD_' + AWjJSatwokZ[0]
			if title not in GEzxBN8rAh1d:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,553,afR4xElWyzgcNAUnKXBempC)
				GEzxBN8rAh1d.append(title)
		elif '/movies/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,551,afR4xElWyzgcNAUnKXBempC)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,553,afR4xElWyzgcNAUnKXBempC)
	if U8tZVnuiQqYjG5KdEWNbXF==Vk54F7GcROfCy6HunEI:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('"pagination"(.*?)<footer',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		if Ry3L7fdNGh:
			UwcYSVZbdK3rI = Ry3L7fdNGh[0]
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp=="": continue
				if title!=Vk54F7GcROfCy6HunEI: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'هناك المزيد',url,551)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-EPISODES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	WvDVRHAc37CGulIhPagimorZSy0x = RSuYINdeamsK0t.findall('"getSeasonsBySeries(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	QQHXiFSA0jUsklmxbpaMztu = RSuYINdeamsK0t.findall('"list-episodes"(.*?)"container"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if WvDVRHAc37CGulIhPagimorZSy0x and '/series/' not in url:
		UwcYSVZbdK3rI = WvDVRHAc37CGulIhPagimorZSy0x[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,afR4xElWyzgcNAUnKXBempC in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,553,afR4xElWyzgcNAUnKXBempC)
	elif QQHXiFSA0jUsklmxbpaMztu:
		afR4xElWyzgcNAUnKXBempC = RSuYINdeamsK0t.findall('"image" src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC[0]
		UwcYSVZbdK3rI = QQHXiFSA0jUsklmxbpaMztu[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,552,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	ynmiDuav5ICTeRsqj6Vb18Q = url.replace('/movies/','/watch_movies/')
	ynmiDuav5ICTeRsqj6Vb18Q = ynmiDuav5ICTeRsqj6Vb18Q.replace('/episodes/','/watch_episodes/')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',ynmiDuav5ICTeRsqj6Vb18Q,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	lseWcUVP5qY = RRav1Sf7Px(ynmiDuav5ICTeRsqj6Vb18Q,'url')
	MMJL8QqY6T7dv1onu = []
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('''<iframe.*?src=["'](.*?)["']''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
		oOv4sVqEAmyM = RRav1Sf7Px(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,'url')
		MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+oOv4sVqEAmyM+'__embed')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"servers"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		aPlrVesU3WkF79DXxAT8jHSECq6Q = RSuYINdeamsK0t.findall('postID = "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		aPlrVesU3WkF79DXxAT8jHSECq6Q = aPlrVesU3WkF79DXxAT8jHSECq6Q[0]
		items = RSuYINdeamsK0t.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for oOv4sVqEAmyM,title in items:
				title = title.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/ajax/getPlayer?server='+oOv4sVqEAmyM+'&postID='+aPlrVesU3WkF79DXxAT8jHSECq6Q+'&Ajax=1'
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+title+'__watch'
				MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		else:
			items = RSuYINdeamsK0t.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			if items:
				oOv4sVqEAmyM,ZhFxrE8P1T,title = items[0]
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = lseWcUVP5qY+'/ajax/getPlayerByName?server='+oOv4sVqEAmyM+'&multipleServers='+ZhFxrE8P1T+'&postID='+aPlrVesU3WkF79DXxAT8jHSECq6Q+'&Ajax=1'
				hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5 = vULz8h3qpug7jMCVHQcRZ(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
				eDbTIrV6KLfz80 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',hj50MJnoOp6ZWaS1IQ8Elr,zWochUpvu80mn5,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-PLAY-2nd')
				FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
				pZGDafn8c5w = RSuYINdeamsK0t.findall('''<iframe src=["'](.*?)["']''',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
				YBDKFZOGfyCHLPA1EaUz9MJ = pZGDafn8c5w[0] if pZGDafn8c5w else Vk54F7GcROfCy6HunEI
				if '/iframe/' in YBDKFZOGfyCHLPA1EaUz9MJ:
					Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',YBDKFZOGfyCHLPA1EaUz9MJ,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-PLAY-3rd')
					FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
					vbeiLuMzJsNdjKHhSXZW0 = RSuYINdeamsK0t.findall('version&quot;:&quot;(.*?)&',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
					vbeiLuMzJsNdjKHhSXZW0 = vbeiLuMzJsNdjKHhSXZW0[0]
					eDbTIrV6KLfz80 = {}
					eDbTIrV6KLfz80['X-Inertia-Partial-Component'] = 'files/mirror/video'
					eDbTIrV6KLfz80['X-Inertia'] = 'true'
					eDbTIrV6KLfz80['X-Inertia-Partial-Data'] = 'streams'
					eDbTIrV6KLfz80['X-Inertia-Version'] = vbeiLuMzJsNdjKHhSXZW0
					Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',YBDKFZOGfyCHLPA1EaUz9MJ,Vk54F7GcROfCy6HunEI,eDbTIrV6KLfz80,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'CIMAABDO-PLAY-4th')
					FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
					T1T0MKwulB8bnZx = Bw6jaUcFxlqdDT8bC('dict',FjwObZSWkg8ahBdiQf9IeY135DpXoP)
					groups = T1T0MKwulB8bnZx['props']['streams']['data']
					for group in groups:
						jMiru3pGns = group['label'].replace(' (source)',Vk54F7GcROfCy6HunEI)
						n7VMgaLypOYzIDuB = group['mirrors']
						for O8o49zSD0NAMm in n7VMgaLypOYzIDuB:
							oOv4sVqEAmyM = O8o49zSD0NAMm['driver']
							ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+O8o49zSD0NAMm['link']+'?named='+oOv4sVqEAmyM+'__watch____'+jMiru3pGns
							MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"downs"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)" title="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?named='+name+'__download'
			if 'http' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'http:'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'-')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'.html'
	txsXO7gSMnrwAh6NmJ9D(url)
	return
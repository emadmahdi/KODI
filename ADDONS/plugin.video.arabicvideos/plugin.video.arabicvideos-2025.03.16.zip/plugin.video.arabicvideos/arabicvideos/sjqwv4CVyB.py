# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'DAILYMOTION'
xzA9sM3rG6IHd7jl8T = '_DLM_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
PqQp5bd4ZAeVu6DM1Kjrt = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][1]
def X42LMUrFfIY3oWeazj(mode,url,text,type,H4TFmtAe5rM8oY1lfPviVC):
	if	 mode==400: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==401: w8YsNWfQ5gFluRvOmSd4Cb96H = GcTyEjYAxHqIOe(url,text)
	elif mode==402: w8YsNWfQ5gFluRvOmSd4Cb96H = k7O3uITSy5MAoYLxihaCqg09GJvWtP(url,text)
	elif mode==403: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url,text)
	elif mode==404: w8YsNWfQ5gFluRvOmSd4Cb96H = SSzXUkj9tBCOI2svn3ZFyA(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==405: w8YsNWfQ5gFluRvOmSd4Cb96H = AAnaIwDBqjGLYf(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==406: w8YsNWfQ5gFluRvOmSd4Cb96H = R3BqXNDzI2wlv(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==407: w8YsNWfQ5gFluRvOmSd4Cb96H = Su4F8bTpKxihWkvo9fdUZODEJl(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==408: w8YsNWfQ5gFluRvOmSd4Cb96H = pKzIEq5uDRvesfihdo(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==409: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==411: w8YsNWfQ5gFluRvOmSd4Cb96H = w4eZpPgRfJCTkBSiMzarY(url,text)
	elif mode==414: w8YsNWfQ5gFluRvOmSd4Cb96H = GGKxMrusQX5ejn7WA3yNtbgpqER4o(text)
	elif mode==415: w8YsNWfQ5gFluRvOmSd4Cb96H = AAhSgmte7UZbd(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==416: w8YsNWfQ5gFluRvOmSd4Cb96H = sXVHhtnA27iIL5ao0vP(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==417: w8YsNWfQ5gFluRvOmSd4Cb96H = P9UDFdH5zQM381eVOycLNI(url,H4TFmtAe5rM8oY1lfPviVC)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الرئيسية',Vk54F7GcROfCy6HunEI,414)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن فيديوهات',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'videos?sortBy=','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن آخر الفيديوهات',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن الفيديوهات الأكثر مشاهدة',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن قوائم التشغيل',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'playlists','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن مستخدم',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'channels','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن بث حي',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'lives','_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن هاشتاك',Vk54F7GcROfCy6HunEI,409,Vk54F7GcROfCy6HunEI,'hashtags','_REMEMBERRESULTS_')
	return
def k7O3uITSy5MAoYLxihaCqg09GJvWtP(url,VGwxbDHftRuLjFiM8JBegTCyPI2):
	if '/dm_' in url:
		Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,False,Vk54F7GcROfCy6HunEI,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = Iy3PA1SVXNfjOchtgHC5kuJBG.headers
		if 'Location' in list(headers.keys()): url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+headers['Location']
	VGwxbDHftRuLjFiM8JBegTCyPI2 = nMt0iueCy6K+VGwxbDHftRuLjFiM8JBegTCyPI2+ZZoLlKyInXc08j2pTGJ
	VGwxbDHftRuLjFiM8JBegTCyPI2 = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(VGwxbDHftRuLjFiM8JBegTCyPI2)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: بث حي',url,411,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'channel_lives_now')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: آخر الفيديوهات',url+'/videos',408)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: المميزة',url,411,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'channel_featured_videos')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: قوائم التشغيل',url+'/playlists',407)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+':: قنوات ذات صلة',url,411,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'channel_related_channel')
	return
def aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title):
	title = title.rstrip('\\').strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace('\\\\','\\')
	title = ww25jXuxtpK1TOJEbGUgrm8(title)
	return title
def h5hmzOAeWEPip(url,AadlWS7x4gL5YMCt6921ZTiQ):
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3([url],TVPm7Bz1XOwJ2,'video',url)
	return
def SSzXUkj9tBCOI2svn3ZFyA(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = Vk54F7GcROfCy6HunEI
	search = search.split('/videos')[0]
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	if sort==Vk54F7GcROfCy6HunEI: MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysortmethod',Vk54F7GcROfCy6HunEI)
	else: MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/videos'
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"videos"(.*?)"VideoConnection"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,title,xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2,GbwM6iseo0ZVlh4ydB,afR4xElWyzgcNAUnKXBempC in items:
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+id
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			AadlWS7x4gL5YMCt6921ZTiQ = xUJ452pAgLGWbdI3DyBPRHK8ZkMF+'::'+VGwxbDHftRuLjFiM8JBegTCyPI2
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,AadlWS7x4gL5YMCt6921ZTiQ)
		if '"hasNextPage":true' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,404,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def AAnaIwDBqjGLYf(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/playlists'
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	items = RSuYINdeamsK0t.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for id,name,AoWjRcV5t6,xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2,afR4xElWyzgcNAUnKXBempC,count in items:
		afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
		AadlWS7x4gL5YMCt6921ZTiQ = xUJ452pAgLGWbdI3DyBPRHK8ZkMF+'::'+VGwxbDHftRuLjFiM8JBegTCyPI2
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,401,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,AadlWS7x4gL5YMCt6921ZTiQ)
	if '"hasNextPage":true' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
		H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,405,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def R3BqXNDzI2wlv(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/channels'
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"channels"(.*?)"ChannelConnection"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,name,afR4xElWyzgcNAUnKXBempC in items:
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+id
			title = 'USER:  '+name
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,402,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,name)
		if '"hasNextPage":true' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,406,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def GGKxMrusQX5ejn7WA3yNtbgpqER4o(k94XOA0m5Z):
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['home']['neon']['sections']['edges']
		if not k94XOA0m5Z:
			B0CejYi4ZrDMGO3mh5X = []
			for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
				CAtK3v2EFTXUOIZ4pl = fFdAe4JLrbzq8xagHsGC['node']['title']
				if CAtK3v2EFTXUOIZ4pl not in B0CejYi4ZrDMGO3mh5X: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+CAtK3v2EFTXUOIZ4pl,Vk54F7GcROfCy6HunEI,414,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,CAtK3v2EFTXUOIZ4pl)
				B0CejYi4ZrDMGO3mh5X.append(CAtK3v2EFTXUOIZ4pl)
		else:
			for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
				CAtK3v2EFTXUOIZ4pl = fFdAe4JLrbzq8xagHsGC['node']['title']
				if CAtK3v2EFTXUOIZ4pl==k94XOA0m5Z:
					rrQ4FuvXTaJwm1gNtCV3iyUIojG = fFdAe4JLrbzq8xagHsGC['node']['components']['edges']
					for sa8zhlgn9defrj in rrQ4FuvXTaJwm1gNtCV3iyUIojG:
						GbwM6iseo0ZVlh4ydB = str(sa8zhlgn9defrj['node']['duration'])
						title = ww25jXuxtpK1TOJEbGUgrm8(sa8zhlgn9defrj['node']['title'])
						title = title.replace('\/','/')
						etwxW0DgUb7FVRN6X = sa8zhlgn9defrj['node']['xid']
						afR4xElWyzgcNAUnKXBempC = sa8zhlgn9defrj['node']['thumbnailx480']
						afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
						ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+etwxW0DgUb7FVRN6X
						v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
	return
def AAhSgmte7UZbd(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/lives'
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		try: sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['search']['lives']['edges']
		except: sCdTUXnbwNxKlS = []
		for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
			name = fFdAe4JLrbzq8xagHsGC['node']['title']
			name = ww25jXuxtpK1TOJEbGUgrm8(name)
			etwxW0DgUb7FVRN6X = fFdAe4JLrbzq8xagHsGC['node']['xid']
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+etwxW0DgUb7FVRN6X
			v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'LIVE: '+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403)
		if '"hasNextPage":true' in c3viesQ2VarGbjg7npt4JBKWY:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,415,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def Ip72T3uBvsLXKAilR1OGHtZ8(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/topics'
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		try: sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['search']['topics']['edges']
		except: sCdTUXnbwNxKlS = []
		for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
			name = fFdAe4JLrbzq8xagHsGC['node']['name']
			etwxW0DgUb7FVRN6X = fFdAe4JLrbzq8xagHsGC['node']['xid']
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/topic/'+etwxW0DgUb7FVRN6X
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'TOPIC: '+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,413)
		if '"hasNextPage":true' in c3viesQ2VarGbjg7npt4JBKWY:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,412,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def uJjS2UhzNTD1APZ8VF9xc(url,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	etwxW0DgUb7FVRN6X = url.split('/')[-1]
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mytopicid',etwxW0DgUb7FVRN6X)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['topic']['videos']['edges']
		for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
			GbwM6iseo0ZVlh4ydB = str(fFdAe4JLrbzq8xagHsGC['node']['duration'])
			title = ww25jXuxtpK1TOJEbGUgrm8(fFdAe4JLrbzq8xagHsGC['node']['title'])
			title = title.replace('\/','/')
			etwxW0DgUb7FVRN6X = fFdAe4JLrbzq8xagHsGC['node']['xid']
			afR4xElWyzgcNAUnKXBempC = fFdAe4JLrbzq8xagHsGC['node']['thumbnailx480']
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+etwxW0DgUb7FVRN6X
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
		if '"hasNextPage":true' in c3viesQ2VarGbjg7npt4JBKWY:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,413,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC)
	return
def GcTyEjYAxHqIOe(url,AadlWS7x4gL5YMCt6921ZTiQ):
	id = url.split('/')[-1]
	xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2 = AadlWS7x4gL5YMCt6921ZTiQ.split('::',1)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+xUJ452pAgLGWbdI3DyBPRHK8ZkMF
	VGwxbDHftRuLjFiM8JBegTCyPI2 = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(VGwxbDHftRuLjFiM8JBegTCyPI2)
	title = nMt0iueCy6K+'OWNER:  '+VGwxbDHftRuLjFiM8JBegTCyPI2+ZZoLlKyInXc08j2pTGJ
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,402,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,VGwxbDHftRuLjFiM8JBegTCyPI2)
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('myplaylistid',id)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"collection_videos"(.*?)"SectionEdge"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,title,GbwM6iseo0ZVlh4ydB,afR4xElWyzgcNAUnKXBempC,xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2 in items:
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+id
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			AadlWS7x4gL5YMCt6921ZTiQ = xUJ452pAgLGWbdI3DyBPRHK8ZkMF+'::'+VGwxbDHftRuLjFiM8JBegTCyPI2
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,AadlWS7x4gL5YMCt6921ZTiQ)
	return
def pKzIEq5uDRvesfihdo(url,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	w9UG3QYd7oV51ryigjs6kMO = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mychannelid',w9UG3QYd7oV51ryigjs6kMO)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysortmethod',sort)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,title,GbwM6iseo0ZVlh4ydB,xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2,afR4xElWyzgcNAUnKXBempC in items:
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+id
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			AadlWS7x4gL5YMCt6921ZTiQ = xUJ452pAgLGWbdI3DyBPRHK8ZkMF+'::'+VGwxbDHftRuLjFiM8JBegTCyPI2
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,AadlWS7x4gL5YMCt6921ZTiQ)
		if '"hasNextPage":true' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,408,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC)
	return
def Su4F8bTpKxihWkvo9fdUZODEJl(url,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	w9UG3QYd7oV51ryigjs6kMO = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mychannelid',w9UG3QYd7oV51ryigjs6kMO)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysortmethod',sort)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for id,name,afR4xElWyzgcNAUnKXBempC,count,AoWjRcV5t6,xUJ452pAgLGWbdI3DyBPRHK8ZkMF,VGwxbDHftRuLjFiM8JBegTCyPI2 in items:
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			AadlWS7x4gL5YMCt6921ZTiQ = xUJ452pAgLGWbdI3DyBPRHK8ZkMF+'::'+VGwxbDHftRuLjFiM8JBegTCyPI2
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,401,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,AadlWS7x4gL5YMCt6921ZTiQ)
		if '"hasNextPage":true' in FjwObZSWkg8ahBdiQf9IeY135DpXoP:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,407,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC)
	return
def w4eZpPgRfJCTkBSiMzarY(url,dEBKXJNStQa9kZqzUhyeI0C):
	w9UG3QYd7oV51ryigjs6kMO = url.split('/')[3]
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mychannelid',w9UG3QYd7oV51ryigjs6kMO)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	d1SOnwfQKLRlZXebkiI = MkuHT2blpeds34wXxDyvgitqWo.loads(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	try: items = d1SOnwfQKLRlZXebkiI['data']['channel'][dEBKXJNStQa9kZqzUhyeI0C]['edges']
	except: items = []
	if not items: v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+'لا توجد نتائج',Vk54F7GcROfCy6HunEI,9999)
	else:
		for anbjzfuiDdgYP6vSXqwRex in items:
			mcAYgnWtZUwx9q = anbjzfuiDdgYP6vSXqwRex['node']
			etwxW0DgUb7FVRN6X = mcAYgnWtZUwx9q['xid']
			keys = list(mcAYgnWtZUwx9q.keys())
			o8fZRA1HnDBwIjCStPJe = mcAYgnWtZUwx9q['__typename'].lower()
			if o8fZRA1HnDBwIjCStPJe=='channel':
				name = mcAYgnWtZUwx9q['name']
				mHQWCYFDOePUwguIso4KNZd3 = mcAYgnWtZUwx9q['displayName']
				title = 'USER:  '+mHQWCYFDOePUwguIso4KNZd3
				afR4xElWyzgcNAUnKXBempC = mcAYgnWtZUwx9q['coverURLx375']
			else:
				name = mcAYgnWtZUwx9q['channel']['name']
				mHQWCYFDOePUwguIso4KNZd3 = mcAYgnWtZUwx9q['channel']['displayName']
				title = mcAYgnWtZUwx9q['title']
				afR4xElWyzgcNAUnKXBempC = mcAYgnWtZUwx9q['thumbnailx360']
				if o8fZRA1HnDBwIjCStPJe=='live': title = 'LIVE:  '+title
			title = aP7gB8QAlvm0TfJ4XIoGOyWEi6Fs(title)
			AadlWS7x4gL5YMCt6921ZTiQ = name+'::'+mHQWCYFDOePUwguIso4KNZd3
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
				title = title.encode(AoCWwJHgUPKXI7u2lEzym)
				AadlWS7x4gL5YMCt6921ZTiQ = AadlWS7x4gL5YMCt6921ZTiQ.encode(AoCWwJHgUPKXI7u2lEzym)
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			if o8fZRA1HnDBwIjCStPJe=='channel':
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+etwxW0DgUb7FVRN6X
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,402,afR4xElWyzgcNAUnKXBempC,Vk54F7GcROfCy6HunEI,AadlWS7x4gL5YMCt6921ZTiQ)
			else:
				if o8fZRA1HnDBwIjCStPJe=='video': GbwM6iseo0ZVlh4ydB = str(mcAYgnWtZUwx9q['duration'])
				else: GbwM6iseo0ZVlh4ydB = Vk54F7GcROfCy6HunEI
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+etwxW0DgUb7FVRN6X
				v0TjHlLZqkRxUCpmNwSy8AndO(o8fZRA1HnDBwIjCStPJe,xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB,AadlWS7x4gL5YMCt6921ZTiQ)
	return
def sXVHhtnA27iIL5ao0vP(search,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mysearchwords',search)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagelimit','40')
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/'+search+'/hashtags'
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		try: sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['search']['hashtags']['edges']
		except: sCdTUXnbwNxKlS = []
		for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
			name = fFdAe4JLrbzq8xagHsGC['node']['name']
			name = ww25jXuxtpK1TOJEbGUgrm8(name)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/hashtag/'+name[1:]
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'HSHTG: '+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,417)
		if '"hasNextPage":true' in c3viesQ2VarGbjg7npt4JBKWY:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,416,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,search)
	return
def P9UDFdH5zQM381eVOycLNI(url,H4TFmtAe5rM8oY1lfPviVC=Vk54F7GcROfCy6HunEI):
	if H4TFmtAe5rM8oY1lfPviVC==Vk54F7GcROfCy6HunEI: H4TFmtAe5rM8oY1lfPviVC = '1'
	name = url.split('/')[-1]
	MmpRngPUCzrJ0HlGfB = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('myhashtagname',name)
	MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.replace('mypagenumber',H4TFmtAe5rM8oY1lfPviVC)
	c3viesQ2VarGbjg7npt4JBKWY = jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB)
	if c3viesQ2VarGbjg7npt4JBKWY:
		ZZtgJPkWdbyHXA1GT4BmMf = Bw6jaUcFxlqdDT8bC('dict',c3viesQ2VarGbjg7npt4JBKWY)
		sCdTUXnbwNxKlS = ZZtgJPkWdbyHXA1GT4BmMf['data']['contentFeed']['edges']
		for fFdAe4JLrbzq8xagHsGC in sCdTUXnbwNxKlS:
			GbwM6iseo0ZVlh4ydB = str(fFdAe4JLrbzq8xagHsGC['node']['post']['duration'])
			title = ww25jXuxtpK1TOJEbGUgrm8(fFdAe4JLrbzq8xagHsGC['node']['post']['title'])
			title = title.replace('\/','/')
			etwxW0DgUb7FVRN6X = fFdAe4JLrbzq8xagHsGC['node']['post']['xid']
			afR4xElWyzgcNAUnKXBempC = fFdAe4JLrbzq8xagHsGC['node']['post']['thumbnailx480']
			afR4xElWyzgcNAUnKXBempC = afR4xElWyzgcNAUnKXBempC.replace('\/','/')
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/'+etwxW0DgUb7FVRN6X
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,403,afR4xElWyzgcNAUnKXBempC,GbwM6iseo0ZVlh4ydB)
		if '"hasNextPage":true' in c3viesQ2VarGbjg7npt4JBKWY:
			H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)+1)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+H4TFmtAe5rM8oY1lfPviVC,url,416,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC)
	return
def jjK5LHC3FXbEnfY(MmpRngPUCzrJ0HlGfB,search=Vk54F7GcROfCy6HunEI):
	if PvwFsJK23NbU8XWAx: MmpRngPUCzrJ0HlGfB = MmpRngPUCzrJ0HlGfB.encode(AoCWwJHgUPKXI7u2lEzym)
	PQJD4U76AbTtZg5 = tNH4QPZxygYu5aJ()
	headers = {"Authorization":PQJD4U76AbTtZg5,"Origin":FFLhlYUAsfJBXeQmRpzD7c14ZP6,'Content-Type':'text/plain; charset=utf-8'}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',PqQp5bd4ZAeVu6DM1Kjrt,MmpRngPUCzrJ0HlGfB,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'DAILYMOTION-GET_PAGEDATA-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def tNH4QPZxygYu5aJ():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'DAILYMOTION-GET_AUTHINTICATION-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	LS6w05KBugx9NYyiV27Whsq = RSuYINdeamsK0t.findall('var r="(.*?)",o="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	MtZTagVLmUWkAiu6b5j3,XXmbWs5CTOoixrJc = LS6w05KBugx9NYyiV27Whsq[-1]
	NwOBDGyIAbKi9LrXRkoftY = 'https://graphql.api.dailymotion.com/oauth/token'
	dAN7laz3x89YbQ0p = 'client_credentials'
	data = {'client_id':MtZTagVLmUWkAiu6b5j3,'client_secret':XXmbWs5CTOoixrJc,'grant_type':dAN7laz3x89YbQ0p}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'POST',NwOBDGyIAbKi9LrXRkoftY,data,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	LS6w05KBugx9NYyiV27Whsq = RSuYINdeamsK0t.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	qnSFkRT92KP7e0crsba4vHi,E17qrpesbJWwoN5CFQv0DygMtA = LS6w05KBugx9NYyiV27Whsq[0]
	PQJD4U76AbTtZg5 = E17qrpesbJWwoN5CFQv0DygMtA+" "+qnSFkRT92KP7e0crsba4vHi
	return PQJD4U76AbTtZg5
def zDkgCMXBmx2A(search,N5RUprZIYG6ekHh=Vk54F7GcROfCy6HunEI):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not N5RUprZIYG6ekHh and showDialogs:
		pXqDyZMAxdF = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('موقع ديلي موشن - اختر البحث',pXqDyZMAxdF)
		if qreJEpY8nZguD==-1: return
		elif qreJEpY8nZguD==0: N5RUprZIYG6ekHh = 'videos?sortBy='
		elif qreJEpY8nZguD==1: N5RUprZIYG6ekHh = 'videos?sortBy=RECENT'
		elif qreJEpY8nZguD==2: N5RUprZIYG6ekHh = 'videos?sortBy=VIEW_COUNT'
		elif qreJEpY8nZguD==3: N5RUprZIYG6ekHh = 'playlists'
		elif qreJEpY8nZguD==4: N5RUprZIYG6ekHh = 'channels'
		elif qreJEpY8nZguD==5: N5RUprZIYG6ekHh = 'lives'
		elif qreJEpY8nZguD==6: N5RUprZIYG6ekHh = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in iwX378tMyTW9KUB: N5RUprZIYG6ekHh = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in iwX378tMyTW9KUB: N5RUprZIYG6ekHh = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in iwX378tMyTW9KUB: N5RUprZIYG6ekHh = 'channels'
	elif '_DAILYMOTION-LIVES_' in iwX378tMyTW9KUB: N5RUprZIYG6ekHh = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in iwX378tMyTW9KUB: N5RUprZIYG6ekHh = 'hashtags'
	elif not N5RUprZIYG6ekHh: N5RUprZIYG6ekHh = 'videos?sortBy='
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	if 'videos' in N5RUprZIYG6ekHh: SSzXUkj9tBCOI2svn3ZFyA(search+'/'+N5RUprZIYG6ekHh)
	elif 'playlists' in N5RUprZIYG6ekHh: AAnaIwDBqjGLYf(search)
	elif 'channels' in N5RUprZIYG6ekHh: R3BqXNDzI2wlv(search)
	elif 'lives' in N5RUprZIYG6ekHh: AAhSgmte7UZbd(search)
	elif 'hashtags' in N5RUprZIYG6ekHh: sXVHhtnA27iIL5ao0vP(search)
	return
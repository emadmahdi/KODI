﻿# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'ALMAAREF'
headers = {'User-Agent':Vk54F7GcROfCy6HunEI}
xzA9sM3rG6IHd7jl8T = '_MRF_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
wXPtB6I0QKLTyD932sl5d = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def X42LMUrFfIY3oWeazj(mode,url,text,H4TFmtAe5rM8oY1lfPviVC):
	if   mode==40: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==41: w8YsNWfQ5gFluRvOmSd4Cb96H = xU0lJEy5CG3O1YRbic()
	elif mode==42: w8YsNWfQ5gFluRvOmSd4Cb96H = jjqfQ6shkKUBXbPDwlW7rIVx(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==43: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==44: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(text,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==49: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,49)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'البث الحي لقناة المعارف',Vk54F7GcROfCy6HunEI,41)
	jjqfQ6shkKUBXbPDwlW7rIVx(Vk54F7GcROfCy6HunEI,'1')
	return
def u3we68CyFm59ZN(iwX378tMyTW9KUB,kk8b7OqmC25EBeTMd4wIS):
	search,sort,Bs8RqnbjT6tXJYE5IogcD3yzamN,MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,llzL6MmB5dtRUYQ8kaXG4pf = Vk54F7GcROfCy6HunEI,[],[],[],[]
	x7ohwWJScUpRi1K50qs,d9wFRcWTLn6yZrbNH0VlYAv3DxUa = vULz8h3qpug7jMCVHQcRZ(iwX378tMyTW9KUB)
	for CCPw5ZS83fxa7AXzQ9VvUIrNDbo in list(d9wFRcWTLn6yZrbNH0VlYAv3DxUa.keys()):
		value = d9wFRcWTLn6yZrbNH0VlYAv3DxUa[CCPw5ZS83fxa7AXzQ9VvUIrNDbo]
		if not value: continue
		if   CCPw5ZS83fxa7AXzQ9VvUIrNDbo=='sort': sort = [value]
		elif CCPw5ZS83fxa7AXzQ9VvUIrNDbo=='series': Bs8RqnbjT6tXJYE5IogcD3yzamN = [value]
		elif CCPw5ZS83fxa7AXzQ9VvUIrNDbo=='search': search = value
		elif CCPw5ZS83fxa7AXzQ9VvUIrNDbo=='category': MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = [value]
		elif CCPw5ZS83fxa7AXzQ9VvUIrNDbo=='specialist': llzL6MmB5dtRUYQ8kaXG4pf = [value]
	k8NxAwnQI2FzZCyJYthpaVubLscq = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,"specialist":llzL6MmB5dtRUYQ8kaXG4pf,"series":Bs8RqnbjT6tXJYE5IogcD3yzamN,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(kk8b7OqmC25EBeTMd4wIS)}}
	k8NxAwnQI2FzZCyJYthpaVubLscq = MkuHT2blpeds34wXxDyvgitqWo.dumps(k8NxAwnQI2FzZCyJYthpaVubLscq)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'POST',ssfLBvkuNiXear2gPdxcyT4AQMhYSp,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	data = Bw6jaUcFxlqdDT8bC('dict',FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	return data
def jjqfQ6shkKUBXbPDwlW7rIVx(iwX378tMyTW9KUB,level):
	DatFuedGb45zR1KqIWNk = u3we68CyFm59ZN(iwX378tMyTW9KUB,'1')
	UwcYSVZbdK3rI = DatFuedGb45zR1KqIWNk['facets']
	if level=='1':
		UwcYSVZbdK3rI = UwcYSVZbdK3rI['video_categories']
		items = RSuYINdeamsK0t.findall('<div(.*?)/div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for anbjzfuiDdgYP6vSXqwRex in items:
			OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',anbjzfuiDdgYP6vSXqwRex+'<',RSuYINdeamsK0t.DOTALL)
			if not OFskSRKaxrlLWPGz9: OFskSRKaxrlLWPGz9 = RSuYINdeamsK0t.findall('data-value=\\"(.*?)\\">(.*?)<',anbjzfuiDdgYP6vSXqwRex+'<',RSuYINdeamsK0t.DOTALL)
			MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,title = OFskSRKaxrlLWPGz9[0]
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
			if not iwX378tMyTW9KUB: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,42,Vk54F7GcROfCy6HunEI,'2','?category='+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,42,Vk54F7GcROfCy6HunEI,'2',iwX378tMyTW9KUB+'&category='+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb)
	if level=='2':
		UwcYSVZbdK3rI = UwcYSVZbdK3rI['specialist']
		items = RSuYINdeamsK0t.findall('value="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for llzL6MmB5dtRUYQ8kaXG4pf,title in items:
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
			if not llzL6MmB5dtRUYQ8kaXG4pf: title = title = 'الجميع'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,42,Vk54F7GcROfCy6HunEI,'3',iwX378tMyTW9KUB+'&specialist='+llzL6MmB5dtRUYQ8kaXG4pf)
	elif level=='3':
		UwcYSVZbdK3rI = UwcYSVZbdK3rI['series']
		items = RSuYINdeamsK0t.findall('value="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for Bs8RqnbjT6tXJYE5IogcD3yzamN,title in items:
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
			if not Bs8RqnbjT6tXJYE5IogcD3yzamN: title = title = 'الجميع'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,42,Vk54F7GcROfCy6HunEI,'4',iwX378tMyTW9KUB+'&series='+Bs8RqnbjT6tXJYE5IogcD3yzamN)
	elif level=='4':
		UwcYSVZbdK3rI = UwcYSVZbdK3rI['sort_video']
		items = RSuYINdeamsK0t.findall('value="(.*?)".*?>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for sort,title in items:
			if not sort: continue
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,44,Vk54F7GcROfCy6HunEI,'1',iwX378tMyTW9KUB+'&sort='+sort)
	return
def txsXO7gSMnrwAh6NmJ9D(iwX378tMyTW9KUB,kk8b7OqmC25EBeTMd4wIS):
	DatFuedGb45zR1KqIWNk = u3we68CyFm59ZN(iwX378tMyTW9KUB,kk8b7OqmC25EBeTMd4wIS)
	UwcYSVZbdK3rI = DatFuedGb45zR1KqIWNk['template']
	items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,43,afR4xElWyzgcNAUnKXBempC)
	UwcYSVZbdK3rI = DatFuedGb45zR1KqIWNk['facets']['pagination']
	items = RSuYINdeamsK0t.findall('data-page="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for H4TFmtAe5rM8oY1lfPviVC,title in items:
		if kk8b7OqmC25EBeTMd4wIS==H4TFmtAe5rM8oY1lfPviVC: continue
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: title = ww25jXuxtpK1TOJEbGUgrm8(title)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+title,Vk54F7GcROfCy6HunEI,44,Vk54F7GcROfCy6HunEI,H4TFmtAe5rM8oY1lfPviVC,iwX378tMyTW9KUB)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMAAREF-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('<video src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('youtube_url.*?(http.*?)&',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	MMJL8QqY6T7dv1onu = []
	if ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0].replace('\/','/')
		MMJL8QqY6T7dv1onu.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3(MMJL8QqY6T7dv1onu,TVPm7Bz1XOwJ2,'video',url)
	return
def xU0lJEy5CG3O1YRbic():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/بث-مباشر',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ALMAAREF-LIVE-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	url = RSuYINdeamsK0t.findall('"svpPlayer".*?(http.*?)&',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	url = url[0].replace('\\',Vk54F7GcROfCy6HunEI)
	qnUlyF2JXuGYdSA6Iac1(url,TVPm7Bz1XOwJ2,'live')
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	xHR80DhALZfI3UNiSm2 = False
	if search==Vk54F7GcROfCy6HunEI:
		search = p3bB2auMmSjXC0dE8FUfZ()
		xHR80DhALZfI3UNiSm2 = True
	if search==Vk54F7GcROfCy6HunEI: return
	if not xHR80DhALZfI3UNiSm2: txsXO7gSMnrwAh6NmJ9D('?search='+search,'1')
	else: jjqfQ6shkKUBXbPDwlW7rIVx('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'IFILM'
xzA9sM3rG6IHd7jl8T = '_IFL_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
PqQp5bd4ZAeVu6DM1Kjrt = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][1]
SqBTU5EndeQb1pYMhcgJKIl = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][2]
l67Z49grJnW3hOXG8kLUoq = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][3]
def X42LMUrFfIY3oWeazj(mode,url,H4TFmtAe5rM8oY1lfPviVC,text):
	if   mode==20: w8YsNWfQ5gFluRvOmSd4Cb96H = hFYxzANSjKgpvCswoHD7WlGct()
	elif mode==21: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5(url)
	elif mode==22: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==23: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,H4TFmtAe5rM8oY1lfPviVC)
	elif mode==24: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url,text)
	elif mode==25: w8YsNWfQ5gFluRvOmSd4Cb96H = igGhHkcR4vCqTFpXVaz(url)
	elif mode==27: w8YsNWfQ5gFluRvOmSd4Cb96H = xU0lJEy5CG3O1YRbic(url)
	elif mode==28: w8YsNWfQ5gFluRvOmSd4Cb96H = JrYlGnhgemtFXP()
	elif mode==29: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def hFYxzANSjKgpvCswoHD7WlGct():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'عربي',FFLhlYUAsfJBXeQmRpzD7c14ZP6,21,Vk54F7GcROfCy6HunEI,'101')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'English',PqQp5bd4ZAeVu6DM1Kjrt,21,Vk54F7GcROfCy6HunEI,'101')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فارسى',SqBTU5EndeQb1pYMhcgJKIl,21,Vk54F7GcROfCy6HunEI,'101')
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فارسى 2',l67Z49grJnW3hOXG8kLUoq,21,Vk54F7GcROfCy6HunEI,'101')
	return
def JrYlGnhgemtFXP():
	v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'عربي',FFLhlYUAsfJBXeQmRpzD7c14ZP6,27)
	v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'English',PqQp5bd4ZAeVu6DM1Kjrt,27)
	v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'فارسى',SqBTU5EndeQb1pYMhcgJKIl,27)
	v0TjHlLZqkRxUCpmNwSy8AndO('live',xzA9sM3rG6IHd7jl8T+'فارسى 2',l67Z49grJnW3hOXG8kLUoq,27)
	return
def eKWDaEPho9wLl5(CrMYibZLOy4PBFdzTUKtokA):
	TVPm7Bz1XOwJ2 = CrMYibZLOy4PBFdzTUKtokA
	if CrMYibZLOy4PBFdzTUKtokA=='IFILM-ARABIC': CrMYibZLOy4PBFdzTUKtokA = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	elif CrMYibZLOy4PBFdzTUKtokA=='IFILM-ENGLISH': CrMYibZLOy4PBFdzTUKtokA = PqQp5bd4ZAeVu6DM1Kjrt
	else: TVPm7Bz1XOwJ2 = Vk54F7GcROfCy6HunEI
	bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(CrMYibZLOy4PBFdzTUKtokA)
	if bLsYAq6gD3mJW8Xw=='ar' or TVPm7Bz1XOwJ2=='IFILM-ARABIC':
		YzhqwlTWrKCdj0k3PuMS4G = 'بحث في الموقع'
		jjlvNYP47uXIK2 = 'مسلسلات - حالية'
		KK4WEqy9u1mj = 'مسلسلات - أحدث'
		zjB19pntWJaDObVhmYu4NLZk = 'مسلسلات - أبجدي'
		yitgUex8mRzu0MAEj3cs5 = 'بث حي آي فيلم'
		mk4ostX5FyU7pVE2q = 'أفلام'
		TRdyxLnuJVsXGHQF3 = 'موسيقى'
		DmFvGRda9HY = 'برامج'
	elif bLsYAq6gD3mJW8Xw=='en' or TVPm7Bz1XOwJ2=='IFILM-ENGLISH':
		YzhqwlTWrKCdj0k3PuMS4G = 'Search in site'
		jjlvNYP47uXIK2 = 'Series - Current'
		KK4WEqy9u1mj = 'Series - Latest'
		zjB19pntWJaDObVhmYu4NLZk = 'Series - Alphabet'
		yitgUex8mRzu0MAEj3cs5 = 'Live iFilm channel'
		mk4ostX5FyU7pVE2q = 'Movies'
		TRdyxLnuJVsXGHQF3 = 'Music'
		DmFvGRda9HY = 'Shows'
	elif bLsYAq6gD3mJW8Xw in ['fa','fa2']:
		YzhqwlTWrKCdj0k3PuMS4G = 'جستجو در سایت'
		jjlvNYP47uXIK2 = 'سريال - جاری'
		KK4WEqy9u1mj = 'سريال - آخرین'
		zjB19pntWJaDObVhmYu4NLZk = 'سريال - الفبا'
		yitgUex8mRzu0MAEj3cs5 = 'پخش زنده اي فيلم'
		mk4ostX5FyU7pVE2q = 'فيلم'
		TRdyxLnuJVsXGHQF3 = 'موسيقى'
		DmFvGRda9HY = 'برنامه ها'
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+YzhqwlTWrKCdj0k3PuMS4G,CrMYibZLOy4PBFdzTUKtokA,29,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('live',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+yitgUex8mRzu0MAEj3cs5,CrMYibZLOy4PBFdzTUKtokA,27)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ak1pcoVisreCFTRyH6J7WgL = ['Series','Program','Music']
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,CrMYibZLOy4PBFdzTUKtokA+'/home',Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-MENU-1st')
	Ry3L7fdNGh=RSuYINdeamsK0t.findall('button-menu(.*?)/Contact',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
			if any(value in ssfLBvkuNiXear2gPdxcyT4AQMhYSp for value in Ak1pcoVisreCFTRyH6J7WgL):
				url = CrMYibZLOy4PBFdzTUKtokA+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				if 'Series' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,url,22,Vk54F7GcROfCy6HunEI,'100')
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+KK4WEqy9u1mj,url,22,Vk54F7GcROfCy6HunEI,'101')
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+zjB19pntWJaDObVhmYu4NLZk,url,22,Vk54F7GcROfCy6HunEI,'201')
				elif 'Film' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+mk4ostX5FyU7pVE2q,url,22,Vk54F7GcROfCy6HunEI,'100')
				elif 'Music' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+TRdyxLnuJVsXGHQF3,url,25,Vk54F7GcROfCy6HunEI,'101')
				elif 'Program' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+DmFvGRda9HY,url,22,Vk54F7GcROfCy6HunEI,'101')
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def igGhHkcR4vCqTFpXVaz(url):
	CrMYibZLOy4PBFdzTUKtokA = Enb1tcxHl9PvIMrae6z4uAZ(url)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-MUSIC_MENU-1st')
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('Music-tools-header(.*?)Music-body',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	title = RSuYINdeamsK0t.findall('<p>(.*?)</p>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)[0]
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,22,Vk54F7GcROfCy6HunEI,'101')
	items = RSuYINdeamsK0t.findall('href="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = CrMYibZLOy4PBFdzTUKtokA + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,23,Vk54F7GcROfCy6HunEI,'101')
	return
def txsXO7gSMnrwAh6NmJ9D(url,H4TFmtAe5rM8oY1lfPviVC):
	CrMYibZLOy4PBFdzTUKtokA = Enb1tcxHl9PvIMrae6z4uAZ(url)
	bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(url)
	type = url.split('/')[-1]
	Sl0mRvDYAzQo1hI7LfjkaCgreqX = str(int(H4TFmtAe5rM8oY1lfPviVC)//100)
	H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)%100)
	if type=='Series' and H4TFmtAe5rM8oY1lfPviVC=='0':
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-TITLES-1st')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('serial-body(.*?)class="row',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			title = ww25jXuxtpK1TOJEbGUgrm8(title)
			title = Uo7Tbc29Eu(title)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = CrMYibZLOy4PBFdzTUKtokA + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			afR4xElWyzgcNAUnKXBempC = CrMYibZLOy4PBFdzTUKtokA + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,23,afR4xElWyzgcNAUnKXBempC,Sl0mRvDYAzQo1hI7LfjkaCgreqX+'01')
	rlUNiLE5V0ZTwDARJfXSuG=0
	if type=='Series': MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb='3'
	if type=='Film': MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb='5'
	if type=='Program': MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb='7'
	if type in ['Series','Program','Film'] and H4TFmtAe5rM8oY1lfPviVC!='0':
		hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Home/PageingItem?category='+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&orderby='+Sl0mRvDYAzQo1hI7LfjkaCgreqX
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-TITLES-2nd')
		items = RSuYINdeamsK0t.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for id,title,afR4xElWyzgcNAUnKXBempC in items:
			title = ww25jXuxtpK1TOJEbGUgrm8(title)
			title = title.replace('\\',Vk54F7GcROfCy6HunEI)
			title = title.replace('"',Vk54F7GcROfCy6HunEI)
			rlUNiLE5V0ZTwDARJfXSuG += 1
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = CrMYibZLOy4PBFdzTUKtokA + '/' + type + '/Content/' + id
			afR4xElWyzgcNAUnKXBempC = CrMYibZLOy4PBFdzTUKtokA + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
			if type=='Film': v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,24,afR4xElWyzgcNAUnKXBempC,Sl0mRvDYAzQo1hI7LfjkaCgreqX+'01')
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,23,afR4xElWyzgcNAUnKXBempC,Sl0mRvDYAzQo1hI7LfjkaCgreqX+'01')
	if type=='Music':
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,CrMYibZLOy4PBFdzTUKtokA+'/Music/Index?page='+H4TFmtAe5rM8oY1lfPviVC,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-TITLES-3rd')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('pagination-demo(.*?)pagination-demo',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			rlUNiLE5V0ZTwDARJfXSuG += 1
			afR4xElWyzgcNAUnKXBempC = CrMYibZLOy4PBFdzTUKtokA + afR4xElWyzgcNAUnKXBempC
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = CrMYibZLOy4PBFdzTUKtokA + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,23,afR4xElWyzgcNAUnKXBempC,'101')
	if rlUNiLE5V0ZTwDARJfXSuG>20:
		title='صفحة '
		if bLsYAq6gD3mJW8Xw=='en': title = 'Page '
		if bLsYAq6gD3mJW8Xw=='fa': title = 'صفحه '
		if bLsYAq6gD3mJW8Xw=='fa2': title = 'صفحه '
		for s7Anx4kwfulCv1dgm in range(1,11) :
			if not H4TFmtAe5rM8oY1lfPviVC==str(s7Anx4kwfulCv1dgm):
				lFYwVxIgL7ha3r1265kCNjui = '0'+str(s7Anx4kwfulCv1dgm)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title+str(s7Anx4kwfulCv1dgm),url,22,Vk54F7GcROfCy6HunEI,Sl0mRvDYAzQo1hI7LfjkaCgreqX+lFYwVxIgL7ha3r1265kCNjui[-2:])
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url,H4TFmtAe5rM8oY1lfPviVC):
	if not H4TFmtAe5rM8oY1lfPviVC: H4TFmtAe5rM8oY1lfPviVC = 0
	CrMYibZLOy4PBFdzTUKtokA = Enb1tcxHl9PvIMrae6z4uAZ(url)
	Kqac3FD7fN9QXzEHR1Vt = Enb1tcxHl9PvIMrae6z4uAZ(url)
	bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(url)
	itb54hH6eAY = url.split('/')
	id,type = itb54hH6eAY[-1],itb54hH6eAY[3]
	Sl0mRvDYAzQo1hI7LfjkaCgreqX = str(int(H4TFmtAe5rM8oY1lfPviVC)//100)
	H4TFmtAe5rM8oY1lfPviVC = str(int(H4TFmtAe5rM8oY1lfPviVC)%100)
	rlUNiLE5V0ZTwDARJfXSuG = 0
	if type=='Series':
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-1st')
		items = RSuYINdeamsK0t.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		title = ' - الحلقة '
		if bLsYAq6gD3mJW8Xw=='en': title = ' - Episode '
		if bLsYAq6gD3mJW8Xw=='fa': title = ' - قسمت '
		if bLsYAq6gD3mJW8Xw=='fa2': title = ' - قسمت '
		if bLsYAq6gD3mJW8Xw=='fa': IiC3HkFz65S1LjUvg = Vk54F7GcROfCy6HunEI
		else: IiC3HkFz65S1LjUvg = bLsYAq6gD3mJW8Xw
		Ijt9LEgihU0SayoBxMFmn7D = RSuYINdeamsK0t.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		for name,count,afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
			for AWjJSatwokZ in range(int(count),0,-1):
				dS1DFQRyeUiwZlHBGPYj8 = afR4xElWyzgcNAUnKXBempC + IiC3HkFz65S1LjUvg + id + '/' + str(AWjJSatwokZ) + '.png'
				jjlvNYP47uXIK2 = name + title + str(AWjJSatwokZ)
				jjlvNYP47uXIK2 = Uo7Tbc29Eu(jjlvNYP47uXIK2)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,url,24,dS1DFQRyeUiwZlHBGPYj8,Vk54F7GcROfCy6HunEI,str(AWjJSatwokZ))
	elif type=='Program':
		hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&orderby=1'
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-2nd')
		items = RSuYINdeamsK0t.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		title = ' - الحلقة '
		if bLsYAq6gD3mJW8Xw=='en': title = ' - Episode '
		if bLsYAq6gD3mJW8Xw=='fa': title = ' - قسمت '
		if bLsYAq6gD3mJW8Xw=='fa2': title = ' - قسمت '
		for AWjJSatwokZ,afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jTZb9HIuvsRAtwY,name in items:
			rlUNiLE5V0ZTwDARJfXSuG += 1
			dS1DFQRyeUiwZlHBGPYj8 = Kqac3FD7fN9QXzEHR1Vt + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
			name = ww25jXuxtpK1TOJEbGUgrm8(name)
			jjlvNYP47uXIK2 = name + title + str(AWjJSatwokZ)
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,hj50MJnoOp6ZWaS1IQ8Elr,24,dS1DFQRyeUiwZlHBGPYj8,Vk54F7GcROfCy6HunEI,str(rlUNiLE5V0ZTwDARJfXSuG))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Music/GetTracksBy?id='+str(id)+'&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&type=0'
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-3rd')
			items = RSuYINdeamsK0t.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name,title in items:
				rlUNiLE5V0ZTwDARJfXSuG += 1
				dS1DFQRyeUiwZlHBGPYj8 = Kqac3FD7fN9QXzEHR1Vt + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
				jjlvNYP47uXIK2 = name + ' - ' + title
				jjlvNYP47uXIK2 = jjlvNYP47uXIK2.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				jjlvNYP47uXIK2 = ww25jXuxtpK1TOJEbGUgrm8(jjlvNYP47uXIK2)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,hj50MJnoOp6ZWaS1IQ8Elr,24,dS1DFQRyeUiwZlHBGPYj8,Vk54F7GcROfCy6HunEI,str(rlUNiLE5V0ZTwDARJfXSuG))
		elif 'Clips' in url:
			hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Music/GetTracksBy?id=0&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&type=15'
			FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-4th')
			items = RSuYINdeamsK0t.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			for afR4xElWyzgcNAUnKXBempC,title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
				rlUNiLE5V0ZTwDARJfXSuG += 1
				dS1DFQRyeUiwZlHBGPYj8 = Kqac3FD7fN9QXzEHR1Vt + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
				jjlvNYP47uXIK2 = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				jjlvNYP47uXIK2 = ww25jXuxtpK1TOJEbGUgrm8(jjlvNYP47uXIK2)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,hj50MJnoOp6ZWaS1IQ8Elr,24,dS1DFQRyeUiwZlHBGPYj8,Vk54F7GcROfCy6HunEI,str(rlUNiLE5V0ZTwDARJfXSuG))
		elif 'category' in url:
			if 'category=6' in url:
				hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Music/GetTracksBy?id=0&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&type=6'
				FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				hj50MJnoOp6ZWaS1IQ8Elr = CrMYibZLOy4PBFdzTUKtokA+'/Music/GetTracksBy?id=0&page='+H4TFmtAe5rM8oY1lfPviVC+'&size=30&type=4'
				FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-EPISODES-6th')
			items = RSuYINdeamsK0t.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
			for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name,title in items:
				rlUNiLE5V0ZTwDARJfXSuG += 1
				dS1DFQRyeUiwZlHBGPYj8 = Kqac3FD7fN9QXzEHR1Vt + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
				jjlvNYP47uXIK2 = name + ' - ' + title
				jjlvNYP47uXIK2 = jjlvNYP47uXIK2.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				jjlvNYP47uXIK2 = ww25jXuxtpK1TOJEbGUgrm8(jjlvNYP47uXIK2)
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+jjlvNYP47uXIK2,hj50MJnoOp6ZWaS1IQ8Elr,24,dS1DFQRyeUiwZlHBGPYj8,Vk54F7GcROfCy6HunEI,str(rlUNiLE5V0ZTwDARJfXSuG))
	if type=='Music' or type=='Program':
		if rlUNiLE5V0ZTwDARJfXSuG>25:
			title='صفحة '
			if bLsYAq6gD3mJW8Xw=='en': title = ' Page '
			if bLsYAq6gD3mJW8Xw=='fa': title = ' صفحه '
			if bLsYAq6gD3mJW8Xw=='fa2': title = ' صفحه '
			for s7Anx4kwfulCv1dgm in range(1,11):
				if not H4TFmtAe5rM8oY1lfPviVC==str(s7Anx4kwfulCv1dgm):
					lFYwVxIgL7ha3r1265kCNjui = '0'+str(s7Anx4kwfulCv1dgm)
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title+str(s7Anx4kwfulCv1dgm),url,23,Vk54F7GcROfCy6HunEI,Sl0mRvDYAzQo1hI7LfjkaCgreqX+lFYwVxIgL7ha3r1265kCNjui[-2:])
	return
def h5hmzOAeWEPip(url,AWjJSatwokZ):
	Kqac3FD7fN9QXzEHR1Vt = Enb1tcxHl9PvIMrae6z4uAZ(url)
	nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = [],[]
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-PLAY-1st')
	items = RSuYINdeamsK0t.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(url)
		itb54hH6eAY = url.split('/')
		id,type = itb54hH6eAY[-1],itb54hH6eAY[3]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[0][0]+bLsYAq6gD3mJW8Xw+id+'/,'+AWjJSatwokZ+','+AWjJSatwokZ+'_'+items[0][2]
		nWcb8JC7zEVouFjx9fILGh1vSQ.append('m3u8')
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	items = RSuYINdeamsK0t.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(url)
		itb54hH6eAY = url.split('/')
		id,type = itb54hH6eAY[-1],itb54hH6eAY[3]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[0][0]+bLsYAq6gD3mJW8Xw+id+'/'+AWjJSatwokZ+items[0][2]
		nWcb8JC7zEVouFjx9fILGh1vSQ.append('mp4 url')
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	items = RSuYINdeamsK0t.findall('source src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.replace('//','/')
		nWcb8JC7zEVouFjx9fILGh1vSQ.append('mp4 src')
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	items = RSuYINdeamsK0t.findall('VideoAddress":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[int(AWjJSatwokZ)-1]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Kqac3FD7fN9QXzEHR1Vt+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		nWcb8JC7zEVouFjx9fILGh1vSQ.append('mp4 address')
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	items = RSuYINdeamsK0t.findall('VoiceAddress":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = items[int(AWjJSatwokZ)-1]
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = Kqac3FD7fN9QXzEHR1Vt+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
		nWcb8JC7zEVouFjx9fILGh1vSQ.append('mp3 address')
		yyVoU0rfb17SRL5XmGYwDckpnQ3BI9.append(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
	if len(yyVoU0rfb17SRL5XmGYwDckpnQ3BI9)==1: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[0]
	else:
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر الفيديو المناسب:', nWcb8JC7zEVouFjx9fILGh1vSQ)
		if qreJEpY8nZguD == -1 : return
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	qnUlyF2JXuGYdSA6Iac1(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,TVPm7Bz1XOwJ2,'video')
	return
def Enb1tcxHl9PvIMrae6z4uAZ(url):
	if FFLhlYUAsfJBXeQmRpzD7c14ZP6 in url: PPmYnWkqTCfNH1u4yoRs = FFLhlYUAsfJBXeQmRpzD7c14ZP6
	elif PqQp5bd4ZAeVu6DM1Kjrt in url: PPmYnWkqTCfNH1u4yoRs = PqQp5bd4ZAeVu6DM1Kjrt
	elif SqBTU5EndeQb1pYMhcgJKIl in url: PPmYnWkqTCfNH1u4yoRs = SqBTU5EndeQb1pYMhcgJKIl
	elif l67Z49grJnW3hOXG8kLUoq in url: PPmYnWkqTCfNH1u4yoRs = l67Z49grJnW3hOXG8kLUoq
	else: PPmYnWkqTCfNH1u4yoRs = Vk54F7GcROfCy6HunEI
	return PPmYnWkqTCfNH1u4yoRs
def ubTEnwYZJ4(url):
	if   FFLhlYUAsfJBXeQmRpzD7c14ZP6 in url: bLsYAq6gD3mJW8Xw = 'ar'
	elif PqQp5bd4ZAeVu6DM1Kjrt in url: bLsYAq6gD3mJW8Xw = 'en'
	elif SqBTU5EndeQb1pYMhcgJKIl in url: bLsYAq6gD3mJW8Xw = 'fa'
	elif l67Z49grJnW3hOXG8kLUoq in url: bLsYAq6gD3mJW8Xw = 'fa2'
	else: bLsYAq6gD3mJW8Xw = Vk54F7GcROfCy6HunEI
	return bLsYAq6gD3mJW8Xw
def xU0lJEy5CG3O1YRbic(url):
	bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(url)
	hj50MJnoOp6ZWaS1IQ8Elr = url + '/Home/Live'
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-LIVE-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	items = RSuYINdeamsK0t.findall('source src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	ynmiDuav5ICTeRsqj6Vb18Q = items[0]
	qnUlyF2JXuGYdSA6Iac1(ynmiDuav5ICTeRsqj6Vb18Q,TVPm7Bz1XOwJ2,'live')
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search:
		search = p3bB2auMmSjXC0dE8FUfZ()
		if not search: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	if showDialogs:
		bbMoq8kVm9BzE6YRZdlr = [ FFLhlYUAsfJBXeQmRpzD7c14ZP6 , PqQp5bd4ZAeVu6DM1Kjrt , SqBTU5EndeQb1pYMhcgJKIl , l67Z49grJnW3hOXG8kLUoq ]
		ZlgD1VuYNwp5dxqCmFJnrcRXPLMG = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('اختر اللغة المناسبة:', ZlgD1VuYNwp5dxqCmFJnrcRXPLMG)
		if qreJEpY8nZguD == -1 : return
		website = bbMoq8kVm9BzE6YRZdlr[qreJEpY8nZguD]
	else:
		if '_IFILM-ARABIC_' in iwX378tMyTW9KUB: website = FFLhlYUAsfJBXeQmRpzD7c14ZP6
		elif '_IFILM-ENGLISH_' in iwX378tMyTW9KUB: website = PqQp5bd4ZAeVu6DM1Kjrt
		else: website = Vk54F7GcROfCy6HunEI
	if not website: return
	bLsYAq6gD3mJW8Xw = ubTEnwYZJ4(website)
	hj50MJnoOp6ZWaS1IQ8Elr = website + "/Home/Search?searchstring=" + HJVMp5sLkG7EnixWo3QOg
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'IFILM-SEARCH-1st')
	items = RSuYINdeamsK0t.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if items:
		for afR4xElWyzgcNAUnKXBempC,MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb,id,title in items:
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb in ['3','7']:
				title = title.replace('\\',Vk54F7GcROfCy6HunEI)
				title = title.replace('"',Vk54F7GcROfCy6HunEI)
				if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='3':
					type = 'Series'
					if bLsYAq6gD3mJW8Xw=='ar': name = 'مسلسل : '
					elif bLsYAq6gD3mJW8Xw=='en': name = 'Series : '
					elif bLsYAq6gD3mJW8Xw=='fa': name = 'سريال ها : '
					elif bLsYAq6gD3mJW8Xw=='fa2': name = 'سريال ها : '
				elif MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='5':
					type = 'Film'
					if bLsYAq6gD3mJW8Xw=='ar': name = 'فيلم : '
					elif bLsYAq6gD3mJW8Xw=='en': name = 'Movie : '
					elif bLsYAq6gD3mJW8Xw=='fa': name = 'فيلم : '
					elif bLsYAq6gD3mJW8Xw=='fa2': name = 'فلم ها : '
				elif MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb=='7':
					type = 'Program'
					if bLsYAq6gD3mJW8Xw=='ar': name = 'برنامج : '
					elif bLsYAq6gD3mJW8Xw=='en': name = 'Program : '
					elif bLsYAq6gD3mJW8Xw=='fa': name = 'برنامه ها : '
					elif bLsYAq6gD3mJW8Xw=='fa2': name = 'برنامه ها : '
				title = name + title
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = website + '/' + type + '/Content/' + id
				afR4xElWyzgcNAUnKXBempC = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(afR4xElWyzgcNAUnKXBempC)
				afR4xElWyzgcNAUnKXBempC = website+afR4xElWyzgcNAUnKXBempC
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,23,afR4xElWyzgcNAUnKXBempC,'101')
	return
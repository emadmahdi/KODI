# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
ufmXvxgoHGDwZtjsLkR05i = FGLEMi21Bfn(u"࠵਱")
pwxH3oREFm5v98BCZ1QVtzMJOc = wYTDlJC5vpOKynUEX3ge6W(u"࠷ਲ")
RXnhpCUk4M1TvgJE = pwxH3oREFm5v98BCZ1QVtzMJOc+pwxH3oREFm5v98BCZ1QVtzMJOc
wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A = RXnhpCUk4M1TvgJE+pwxH3oREFm5v98BCZ1QVtzMJOc
BZm7TqLPJfAVblDKsya85zFWXNMY = wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A+pwxH3oREFm5v98BCZ1QVtzMJOc
m5DECdgjU4KqpVhyJ9A2b = BZm7TqLPJfAVblDKsya85zFWXNMY+pwxH3oREFm5v98BCZ1QVtzMJOc
Vk54F7GcROfCy6HunEI = HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࠧन")
otBWsSAfu7dihVkP9e1JFKrvmYy2Q = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࠡࠩऩ")
YIPoWuLzfl93BTS = otBWsSAfu7dihVkP9e1JFKrvmYy2Q*RXnhpCUk4M1TvgJE
NaXBAuesz07inT4g6cDt = otBWsSAfu7dihVkP9e1JFKrvmYy2Q*wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A
qMmCGK8cln5bID4fkhAF = otBWsSAfu7dihVkP9e1JFKrvmYy2Q*BZm7TqLPJfAVblDKsya85zFWXNMY
tayEeSpKRJIdC8g10 = None
YOHXqtbQTBfKerIZ = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࡗࡶࡺ࡫੒")
eu1NswY9zkKC60I = wYTDlJC5vpOKynUEX3ge6W(u"ࡊࡦࡲࡳࡦ੓")
vXgYbe8s9zknIMpaB = jXWzIZcDva4ikEUfN(u"ࠨࡶࡵࡹࡪ࠭प")
b8f2icUnEswC9Ja = wYTDlJC5vpOKynUEX3ge6W(u"ࠩࡩࡥࡱࡹࡥࠨफ")
XVgJmyC4wSjDON = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪब")
I3IivNQUYMoVL5zbmnZWgaAudfB = SSBkx0WbN1asnDCQV6tIj(u"ࠫࡩ࡫ࡦࡢࡷ࡯ࡸࠬभ")
nMt0iueCy6K = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡅ࠹࠷ࡌ࡝ࠨम")
d761ZWXHEvliYN45RzLP2 = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩय")
hh6BmGb5aUH = g7yJo2LVuqx1trPe(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈ࠶࠷ࡊ࠺࠳࠴࡟ࠪर")
X8sIqoceCwHlQ6bt5n9r1OVSFpA = YzowicIDTRusXZSU61(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉ࠵ࡋ࠻࠱ࡇࡈࡠࠫऱ")
XYvSoxmf0QGpbngZ = WXuJd8nz2spo146t(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇࡈࡉࡡࠬल")
ZZoLlKyInXc08j2pTGJ = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ")
AoCWwJHgUPKXI7u2lEzym = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡺࡺࡦ࠹ࠩऴ")
yyhLQon4NGP5MpH = MzgKWUQ4V5H(u"ࠬࡔࡏࡕࡋࡆࡉࠬव")
ffiklMUwZtgvO3CmG = EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬश")
pp63TBDPameUrjgqfnhG8d9 = cpHxZyU7vTtqmIw(u"ࠧࡆࡔࡕࡓࡗ࠭ष")
sD4g6xukbfCjlJHFUaE = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭स")
ixrPWKeFMnqJyVodX6D9AaO2 = Nlyfx1HnzOWCovke5(u"ࠩ࡟ࡲࠬह")
gSiK7EQVNXClOUDZGs = eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡠࡷ࠭ऺ")
pt7CIKiU8PVBw194dkQEznq = jXWzIZcDva4ikEUfN(u"࠰࠯࠴࠸ਲ਼")
LLFKptWI7nsuHOCTiGhd = wYTDlJC5vpOKynUEX3ge6W(u"࠲࠷਴")
DjFy4Lsm3dqlzSOtWN = eAMGzHRQVs2KyCwPXljYhB(u"࠵࠳ਵ")
AFMqxwOy0Xtsiz1e = cpHxZyU7vTtqmIw(u"࠴࠴ਸ਼")
u4QzxGDBLsmkHbr6Mgtewahi = HOxJyt7l8osNeCjZFMQGi4Sr(u"࠵࠷࠶਷")
hhmKJHnG2Yw = [
						 cpHxZyU7vTtqmIw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪऻ")
						,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵ़ࠩ")
						,FGLEMi21Bfn(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧऽ")
						,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨा")
						,QYSAUI5r46yil8cfaO(u"ࠨࡋࡓࡘ࡛࠳ࡃࡉࡇࡆࡏࡤࡇࡃࡄࡑࡘࡒ࡙࠳࠱ࡴࡶࠪि")
						,V2RQwM8XjlrK(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬी")
						,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧु")
						,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨू")
						,ESXZrtnCfcDJGo01vFg(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩृ")
						,FGLEMi21Bfn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪॄ")
						,Nlyfx1HnzOWCovke5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧॅ")
						,wAU9jKvmTM0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨॆ")
						,Nlyfx1HnzOWCovke5(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨे")
						,g7yJo2LVuqx1trPe(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬै")
						,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ॉ")
						]
F8DIvARTeocz1hymWkEr = hhmKJHnG2Yw+[
				 wAU9jKvmTM0(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧॊ")
				,SSBkx0WbN1asnDCQV6tIj(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫो")
				,MzgKWUQ4V5H(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪौ")
				,g7yJo2LVuqx1trPe(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧ्ࠫ")
				,QYSAUI5r46yil8cfaO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬॎ")
				,jXWzIZcDva4ikEUfN(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭ॏ")
				,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭ॐ")
				,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧ॑")
				,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨ॒")
				,WsklGNp2CYzVQUag(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ॓")
				,WsklGNp2CYzVQUag(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ॔")
				,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬॕ")
				,WXuJd8nz2spo146t(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭ॖ")
				,SSBkx0WbN1asnDCQV6tIj(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩॗ")
				,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭क़")
				,pnkrd2S84FJfN73KuiCYv(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨख़")
				]
aIOMVn2y65xAKSBXmJGbzPc4djeu = [
						 wAU9jKvmTM0(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩग़")
						,WCPwmyVsb62KRlo(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪज़")
						,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡕࡍࡖࡌࡣ࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪड़")
						]
YWQb3r2CoU = m5DECdgjU4KqpVhyJ9A2b
DVO3m2tJ4Hdh = [ESXZrtnCfcDJGo01vFg(u"ูࠪๆืࠧढ़"),YzowicIDTRusXZSU61(u"ࠫศ๎ไࠨफ़"),wYTDlJC5vpOKynUEX3ge6W(u"ࠬัว็์ࠪय़"),YzowicIDTRusXZSU61(u"࠭หศๆฮࠫॠ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠧาษห฽ࠬॡ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨะสุ้࠭ॢ"),MpJ8GOKoic(u"ࠩึหิูࠧॣ"),MpJ8GOKoic(u"ࠪืฬฮูࠨ।"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫะอๅ็ࠩ॥"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠬะวิ฻ࠪ०"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ู࠭ศึิࠫ१")]
ff5W2BhvKHz9QIYSqOERgaN = WXuJd8nz2spo146t(u"࠻࠶ਸ")
uuXTYKmMekIRQfcDd0 = cpHxZyU7vTtqmIw(u"࠼࠰ਹ")*ff5W2BhvKHz9QIYSqOERgaN
iXb0godyOHYS7n4KuArN9FWp = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠲࠵਺")*uuXTYKmMekIRQfcDd0
AdujPXSMIVE = EM6qpnCBYQGA9kbgDVLfrP(u"࠴࠲਻")*iXb0godyOHYS7n4KuArN9FWp
AOhmwtSyYBn4ZF7RuvQNU = ufmXvxgoHGDwZtjsLkR05i
HHvEOMNGCeQKIZybal7 = V2RQwM8XjlrK(u"࠵࠳਼")*ff5W2BhvKHz9QIYSqOERgaN
CnJ1ePvdKQ2R = RXnhpCUk4M1TvgJE*uuXTYKmMekIRQfcDd0
ddQIv6q9hTce1iA0nWSX5UuLaNb = Nlyfx1HnzOWCovke5(u"࠴࠺਽")*uuXTYKmMekIRQfcDd0
sT9DURSXlOybaCQ = wnrFQZc0iHv3gbYoRy4h2mBVdeIM7A*iXb0godyOHYS7n4KuArN9FWp
mXdxepDh683FuUKlb0 = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠷࠵ਾ")*iXb0godyOHYS7n4KuArN9FWp
piwNWcJEe9m = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶࠸ਿ")*AdujPXSMIVE
GK0mSeb1BCXqyuUavI9zifL = uuXTYKmMekIRQfcDd0
PFp1RMzqiYA7NyOEU = [YzowicIDTRusXZSU61(u"ࠧࡃࡑࡎࡖࡆ࠭२"),ESXZrtnCfcDJGo01vFg(u"ࠨࡒࡄࡒࡊ࡚ࠧ३"),WsklGNp2CYzVQUag(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ४"),SSBkx0WbN1asnDCQV6tIj(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭५"),pnkrd2S84FJfN73KuiCYv(u"ࠫࡎࡌࡉࡍࡏࠪ६"),MpJ8GOKoic(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ७"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭८")]
PFp1RMzqiYA7NyOEU += [WCPwmyVsb62KRlo(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭९"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ॰"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡄࡏࡔࡇࡍࠨॱ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡅࡐ࡝ࡁࡎࠩॲ"),FGLEMi21Bfn(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ॳ"),SSBkx0WbN1asnDCQV6tIj(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧॴ")]
lXVNd7C89KcjAW3Pvba5OHpfzDE = [WXuJd8nz2spo146t(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ॵ"),MzgKWUQ4V5H(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪॶ"),MpJ8GOKoic(u"ࠨࡖ࡙ࡊ࡚ࡔࠧॷ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪॸ"),Nlyfx1HnzOWCovke5(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫॹ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨॺ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧॻ")]
lXVNd7C89KcjAW3Pvba5OHpfzDE += [EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨॼ"),QYSAUI5r46yil8cfaO(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩॽ"),MpJ8GOKoic(u"ࠨࡕࡋࡓࡋࡎࡁࠨॾ"),jXWzIZcDva4ikEUfN(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪॿ"),wAU9jKvmTM0(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫঀ")]
FZbHESxh7WRPz0MTjf65V9 = [ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࡙ࠫࡏࡋࡂࡃࡗࠫঁ"),WXuJd8nz2spo146t(u"ࠬࡇ࡙ࡍࡑࡏࠫং"),XCYALgFs2O3hZdpHrlMmB(u"࠭ࡆࡐࡕࡗࡅࠬঃ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ঄"),wAU9jKvmTM0(u"ࠨ࡛ࡄࡕࡔ࡚ࠧঅ"),V2RQwM8XjlrK(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬআ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࡚ࠪࡆࡘࡂࡐࡐࠪই"),MzgKWUQ4V5H(u"ࠫࡇࡘࡓࡕࡇࡍࠫঈ")]
FZbHESxh7WRPz0MTjf65V9 += [MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭উ"),eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨঊ"),ynxXU3gaiQ9GPCftr1q(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨঋ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪঌ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪ঍"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬ঎"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬএ")]
FZbHESxh7WRPz0MTjf65V9 += [wYTDlJC5vpOKynUEX3ge6W(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧঐ"),ESXZrtnCfcDJGo01vFg(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ঑"),wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪ঒"),eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩও"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬঔ"),cpHxZyU7vTtqmIw(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫক"),ESXZrtnCfcDJGo01vFg(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭খ")]
FZbHESxh7WRPz0MTjf65V9 += [wAU9jKvmTM0(u"ࠬࡇࡋࡘࡃࡐࡘ࡚ࡈࡅࠨগ"),eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩঘ"),WXuJd8nz2spo146t(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪঙ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪচ"),YzowicIDTRusXZSU61(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫছ"),pnkrd2S84FJfN73KuiCYv(u"ࠪࡅࡍ࡝ࡁࡌࠩজ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨঝ")]
FZbHESxh7WRPz0MTjf65V9 += [pnkrd2S84FJfN73KuiCYv(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧঞ"),MzgKWUQ4V5H(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪট"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬঠ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨড"),MpJ8GOKoic(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫঢ"),ynxXU3gaiQ9GPCftr1q(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬণ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ত")]
qlQWNytMGwL6YA = [pnkrd2S84FJfN73KuiCYv(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭থ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧদ"),WXuJd8nz2spo146t(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫধ"),SSBkx0WbN1asnDCQV6tIj(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫন")]
qlQWNytMGwL6YA += [wAU9jKvmTM0(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ঩"),pnkrd2S84FJfN73KuiCYv(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨপ"),jXWzIZcDva4ikEUfN(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬফ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬব"),WCPwmyVsb62KRlo(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪভ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧম")]
qlQWNytMGwL6YA += [kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨࡋࡓࡘ࡛࠭য"),MzgKWUQ4V5H(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬর"),ynxXU3gaiQ9GPCftr1q(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ঱"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩল")]
qlQWNytMGwL6YA += [Nlyfx1HnzOWCovke5(u"ࠬࡓ࠳ࡖࠩ঳"),MpJ8GOKoic(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),ynxXU3gaiQ9GPCftr1q(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
DDnAiFr2uoOjXwY4Rhy = [SSBkx0WbN1asnDCQV6tIj(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨষ")]
J1J4oB5lrvgZTQtOHypLUDhCV  = [XCYALgFs2O3hZdpHrlMmB(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),WXuJd8nz2spo146t(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭হ"),Nlyfx1HnzOWCovke5(u"ࠬࡈࡏࡌࡔࡄࠫ঺"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡁࡌࡑࡄࡑࠬ঻"),QYSAUI5r46yil8cfaO(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ়ࠩ"),QYSAUI5r46yil8cfaO(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩঽ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫা"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬি"),MzgKWUQ4V5H(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫী")]
J1J4oB5lrvgZTQtOHypLUDhCV += [g7yJo2LVuqx1trPe(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧু"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩূ"),Nlyfx1HnzOWCovke5(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨৃ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩৄ"),MzgKWUQ4V5H(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ৅"),Nlyfx1HnzOWCovke5(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ৆"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡋࡕࡓࡕࡃࠪে"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡇࡈࡘࡃࡎࠫৈ"),WXuJd8nz2spo146t(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨ৉")]
J1J4oB5lrvgZTQtOHypLUDhCV += [MzgKWUQ4V5H(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫ৊"),V2RQwM8XjlrK(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫো"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬৌ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵্ࠬ"),XCYALgFs2O3hZdpHrlMmB(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ৎ"),XCYALgFs2O3hZdpHrlMmB(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ৏"),YzowicIDTRusXZSU61(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ৐"),SSBkx0WbN1asnDCQV6tIj(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪ৑")]
J1J4oB5lrvgZTQtOHypLUDhCV += [WCPwmyVsb62KRlo(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ৒"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৓"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৔"),ynxXU3gaiQ9GPCftr1q(u"࡙ࠫ࡜ࡆࡖࡐࠪ৕"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ৖"),Nlyfx1HnzOWCovke5(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ৗ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡗࡃࡕࡆࡔࡔࠧ৘"),FGLEMi21Bfn(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩ৙"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ৚")]
J1J4oB5lrvgZTQtOHypLUDhCV += [kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ৛"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫ࡞ࡇࡑࡐࡖࠪড়"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ঢ়"),SSBkx0WbN1asnDCQV6tIj(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ৞"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬয়"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪৠ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫৡ"),YzowicIDTRusXZSU61(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪৢ"),Nlyfx1HnzOWCovke5(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ৣ")]
J1J4oB5lrvgZTQtOHypLUDhCV += [MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ৤"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨ৥"),wAU9jKvmTM0(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ০"),ynxXU3gaiQ9GPCftr1q(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ১"),YzowicIDTRusXZSU61(u"ࠩࡗࡍࡐࡇࡁࡕࠩ২"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭৩"),jXWzIZcDva4ikEUfN(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭৪")]
llbnTaxqJ4VseQA5Y80PrpE1v  = [HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ৫"),QYSAUI5r46yil8cfaO(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ৬"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ৭"),FGLEMi21Bfn(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬ৮"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ৯")]
llbnTaxqJ4VseQA5Y80PrpE1v += [V2RQwM8XjlrK(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩৰ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫৱ")]
llbnTaxqJ4VseQA5Y80PrpE1v += [ESXZrtnCfcDJGo01vFg(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭৲"),ESXZrtnCfcDJGo01vFg(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ৳"),EM6qpnCBYQGA9kbgDVLfrP(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ৴")]
llbnTaxqJ4VseQA5Y80PrpE1v += [QYSAUI5r46yil8cfaO(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ৵"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ৶"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ৷")]
llbnTaxqJ4VseQA5Y80PrpE1v += [ynxXU3gaiQ9GPCftr1q(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭৸"),FGLEMi21Bfn(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ৹"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ৺")]
JdDmgPHnGsj30fq9YF4 = [V2RQwM8XjlrK(u"ࠧࡎ࠵ࡘࠫ৻"),FGLEMi21Bfn(u"ࠨࡋࡓࡘ࡛࠭ৼ"),MzgKWUQ4V5H(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ৽"),MpJ8GOKoic(u"ࠪࡍࡋࡏࡌࡎࠩ৾"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ৿")]
WjMzbLpa1rUo5Pq = J1J4oB5lrvgZTQtOHypLUDhCV+JdDmgPHnGsj30fq9YF4
LMnQyYOz0U1Ix6B2jW9tvwCpFgV = J1J4oB5lrvgZTQtOHypLUDhCV+llbnTaxqJ4VseQA5Y80PrpE1v
IIJTHtKar50hg3UzuLdl4yDxvNQA1 = LMnQyYOz0U1Ix6B2jW9tvwCpFgV+DDnAiFr2uoOjXwY4Rhy
HUQ7LsrZE5n1q06Ige4NaYmP8jfuzi = [HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭਀")]+PFp1RMzqiYA7NyOEU+[wYTDlJC5vpOKynUEX3ge6W(u"࠭ࡍࡊ࡚ࡈࡈࠬਁ")]+lXVNd7C89KcjAW3Pvba5OHpfzDE+[EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡑࡗࡅࡐࡎࡉࠧਂ")]+FZbHESxh7WRPz0MTjf65V9+[ynxXU3gaiQ9GPCftr1q(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩਃ")]+qlQWNytMGwL6YA
kB9H0W4xSJEpXDTd = [MzgKWUQ4V5H(u"ࠩࡄࡏࡔࡇࡍࠨ਄"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡅࡐ࡝ࡁࡎࠩਅ"),FGLEMi21Bfn(u"ࠫࡎࡌࡉࡍࡏࠪਆ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨਇ"),XCYALgFs2O3hZdpHrlMmB(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨਈ"),cpHxZyU7vTtqmIw(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩਉ"),MpJ8GOKoic(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫਊ"),MpJ8GOKoic(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ਋"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ਌"),MpJ8GOKoic(u"ࠫࡒ࠹ࡕࠨ਍"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬࡏࡐࡕࡘࠪ਎"),MpJ8GOKoic(u"࠭ࡂࡐࡍࡕࡅࠬਏ"),XCYALgFs2O3hZdpHrlMmB(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩਐ"),WXuJd8nz2spo146t(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭਑")]
NOT_TO_TEST_ALL_SERVERS = [QYSAUI5r46yil8cfaO(u"ࠩࡢࡅࡐࡕ࡟ࠨ਒"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡣࡆࡑࡗࡠࠩਓ"),g7yJo2LVuqx1trPe(u"ࠫࡤࡏࡆࡍࡡࠪਔ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡥࡋࡓࡄࡢࠫਕ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭࡟ࡎࡔࡉࡣࠬਖ"),FGLEMi21Bfn(u"ࠧࡠࡕࡋࡑࡤ࠭ਗ"),cpHxZyU7vTtqmIw(u"ࠨࡡࡖࡌ࡛ࡥࠧਘ"),MzgKWUQ4V5H(u"ࠩࡢ࡝࡚࡚࡟ࠨਙ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡣࡉࡒࡍࡠࠩਚ"),Nlyfx1HnzOWCovke5(u"ࠫࡤࡓࡕࠨਛ"),MpJ8GOKoic(u"ࠬࡥࡉࡑࠩਜ"),WsklGNp2CYzVQUag(u"࠭࡟ࡃࡍࡕࡣࠬਝ"),V2RQwM8XjlrK(u"ࠧࡠࡇࡏࡇࡤ࠭ਞ"),V2RQwM8XjlrK(u"ࠨࡡࡄࡖ࡙ࡥࠧਟ")]
PPFb4eNE52s = [YzowicIDTRusXZSU61(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧਠ"),XCYALgFs2O3hZdpHrlMmB(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨਡ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪਢ"),WCPwmyVsb62KRlo(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬਣ"),WsklGNp2CYzVQUag(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫਤ"),pnkrd2S84FJfN73KuiCYv(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬਥ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧਦ"),QYSAUI5r46yil8cfaO(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩਧ")]
X34XVDTA8KQJs = [ufmXvxgoHGDwZtjsLkR05i,WXuJd8nz2spo146t(u"࠷࠵࠱ੀ"),V2RQwM8XjlrK(u"࠷࠶࠱੎"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠳࠺࠴ੑ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠷࠹࠱ੇ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠴࠹࠴੊"),Nlyfx1HnzOWCovke5(u"࠷࠾࠰੍"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠳࠴࠲ੈ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠶࠸࠵ੋ"),QYSAUI5r46yil8cfaO(u"࠴࠲࠲ੁ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶࠲࠳੐"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠺࠸࠰੆"),cpHxZyU7vTtqmIw(u"࠹࠸࠶ੌ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࠶࠶࠳੉"),ESXZrtnCfcDJGo01vFg(u"࠷࠷࠲੏"),ynxXU3gaiQ9GPCftr1q(u"࠵࠵࠷࠰੅"),V2RQwM8XjlrK(u"࠼࠽࠾࠶੄"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠲࠲࠵࠴ੂ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠳࠳࠼࠵੃")]
yvjPbS3FXxlBVc = [l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨਨ"),V2RQwM8XjlrK(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭਩"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧਪ"),cpHxZyU7vTtqmIw(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫਫ"),jXWzIZcDva4ikEUfN(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬਬ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪਭ"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧਮ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬਯ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ਰ")]
# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SHOOFMAX'
xzA9sM3rG6IHd7jl8T = '_SHM_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
PqQp5bd4ZAeVu6DM1Kjrt = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][1]
SqBTU5EndeQb1pYMhcgJKIl = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][2]
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==50: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==51: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==52: w8YsNWfQ5gFluRvOmSd4Cb96H = SQr4lDstIa0NdFyp7Pf23BG6jnLY(url)
	elif mode==53: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==55: w8YsNWfQ5gFluRvOmSd4Cb96H = rJvwYqgVfB2bdKMuL5()
	elif mode==56: w8YsNWfQ5gFluRvOmSd4Cb96H = btpYTIW68PadSniEewyNlm5uGXC()
	elif mode==57: w8YsNWfQ5gFluRvOmSd4Cb96H = sj9BODtKv7C4Rl(url,1)
	elif mode==58: w8YsNWfQ5gFluRvOmSd4Cb96H = sj9BODtKv7C4Rl(url,2)
	elif mode==59: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,59,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'المسلسلات',Vk54F7GcROfCy6HunEI,56)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'الافلام',Vk54F7GcROfCy6HunEI,55)
	return Vk54F7GcROfCy6HunEI
def rJvwYqgVfB2bdKMuL5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أفلام مرتبة بسنة الإنتاج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/movie/1/yop',57)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أفلام مرتبة بالأفضل تقييم',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/movie/1/review',57)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أفلام مرتبة بالأكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/movie/1/views',57)
	return
def btpYTIW68PadSniEewyNlm5uGXC():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات مرتبة بسنة الإنتاج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/series/1/yop',57)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات مرتبة بالأفضل تقييم',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/series/1/review',57)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسلات مرتبة بالأكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/series/1/views',57)
	return
def txsXO7gSMnrwAh6NmJ9D(url):
	if '?' in url:
		itb54hH6eAY = url.split('?')
		url = itb54hH6eAY[0]
		filter = '?' + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(itb54hH6eAY[1],'=&:/%')
	else: filter = Vk54F7GcROfCy6HunEI
	type,H4TFmtAe5rM8oY1lfPviVC,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': qOjIGBrnXhlx='فيلم'
		elif type=='series': qOjIGBrnXhlx='مسلسل'
		url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/genre/filter/' + FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(qOjIGBrnXhlx) + '/' + H4TFmtAe5rM8oY1lfPviVC + '/' + sort + filter
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFMAX-TITLES-1st')
		items = RSuYINdeamsK0t.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		rlUNiLE5V0ZTwDARJfXSuG=0
		for id,title,yTa7jJAo5GmBrzcO,afR4xElWyzgcNAUnKXBempC in items:
			rlUNiLE5V0ZTwDARJfXSuG += 1
			afR4xElWyzgcNAUnKXBempC = SqBTU5EndeQb1pYMhcgJKIl + '/v2/img/program/main/' + afR4xElWyzgcNAUnKXBempC + '-2.jpg'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/program/' + id
			if type=='movie': v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,53,afR4xElWyzgcNAUnKXBempC)
			if type=='series': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسل '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?ep='+yTa7jJAo5GmBrzcO+'='+title+'='+afR4xElWyzgcNAUnKXBempC,52,afR4xElWyzgcNAUnKXBempC)
	else:
		if type=='movie': qOjIGBrnXhlx='movies'
		elif type=='series': qOjIGBrnXhlx='series'
		url = PqQp5bd4ZAeVu6DM1Kjrt + '/json/selected/' + sort + '-' + qOjIGBrnXhlx + '-WW.json'
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFMAX-TITLES-2nd')
		items = RSuYINdeamsK0t.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		rlUNiLE5V0ZTwDARJfXSuG=0
		for id,yTa7jJAo5GmBrzcO,afR4xElWyzgcNAUnKXBempC,title in items:
			rlUNiLE5V0ZTwDARJfXSuG += 1
			afR4xElWyzgcNAUnKXBempC = PqQp5bd4ZAeVu6DM1Kjrt + '/img/program/' + afR4xElWyzgcNAUnKXBempC + '-2.jpg'
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/program/' + id
			if type=='movie': v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,53,afR4xElWyzgcNAUnKXBempC)
			elif type=='series': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مسلسل '+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp+'?ep='+yTa7jJAo5GmBrzcO+'='+title+'='+afR4xElWyzgcNAUnKXBempC,52,afR4xElWyzgcNAUnKXBempC)
	title='صفحة '
	if rlUNiLE5V0ZTwDARJfXSuG==16:
		for s7Anx4kwfulCv1dgm in range(1,13) :
			if not H4TFmtAe5rM8oY1lfPviVC==str(s7Anx4kwfulCv1dgm):
				url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/genre/filter/'+type+'/'+str(s7Anx4kwfulCv1dgm)+'/'+sort+filter
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title+str(s7Anx4kwfulCv1dgm),url,51)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(url):
	itb54hH6eAY = url.split('=')
	yTa7jJAo5GmBrzcO = int(itb54hH6eAY[1])
	name = ZlBMJUAWRm9buv(itb54hH6eAY[2])
	name = name.replace('_MOD_مسلسل ',Vk54F7GcROfCy6HunEI)
	afR4xElWyzgcNAUnKXBempC = itb54hH6eAY[3]
	url = url.split('?')[0]
	if yTa7jJAo5GmBrzcO==0:
		FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(ddQIv6q9hTce1iA0nWSX5UuLaNb,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFMAX-EPISODES-1st')
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('<select(.*?)</select>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('option value="(.*?)"',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		yTa7jJAo5GmBrzcO = int(items[-1])
	for AWjJSatwokZ in range(yTa7jJAo5GmBrzcO,0,-1):
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url + '?ep=' + str(AWjJSatwokZ)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(AWjJSatwokZ)
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,53,afR4xElWyzgcNAUnKXBempC)
	return
def h5hmzOAeWEPip(url):
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFMAX-PLAY-1st')
	iiV8LfT4brgqQ6SzYC = RSuYINdeamsK0t.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if iiV8LfT4brgqQ6SzYC:
		Gb6kwVlSQ4MU = iiV8LfT4brgqQ6SzYC[1].replace('T',qMmCGK8cln5bID4fkhAF)
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+ixrPWKeFMnqJyVodX6D9AaO2+Gb6kwVlSQ4MU)
		return
	jbgkv9s6nVPfh,RRrXt1ehNJWMFxHTdVQ3 = [],[]
	EeQI5W40Jux3VfTLA9mRMc2 = RSuYINdeamsK0t.findall('var origin_link = "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	WKzTHuD7q1pSkI2bljg = RSuYINdeamsK0t.findall('var backup_origin_link = "(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)[0]
	HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('hls: (.*?)_link\+"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for oOv4sVqEAmyM,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
		if 'backup' in oOv4sVqEAmyM:
			oOv4sVqEAmyM = 'backup server'
			url = WKzTHuD7q1pSkI2bljg + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		else:
			oOv4sVqEAmyM = 'main server'
			url = EeQI5W40Jux3VfTLA9mRMc2 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		if '.m3u8' in url:
			jbgkv9s6nVPfh.append(url)
			RRrXt1ehNJWMFxHTdVQ3.append('m3u8  '+oOv4sVqEAmyM)
	HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	HXhRgxEZ4d2Dek += RSuYINdeamsK0t.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	for oOv4sVqEAmyM,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in HXhRgxEZ4d2Dek:
		filename = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.split('/')[-1]
		filename = filename.replace('fallback',Vk54F7GcROfCy6HunEI)
		filename = filename.replace('.mp4',Vk54F7GcROfCy6HunEI)
		filename = filename.replace('-',Vk54F7GcROfCy6HunEI)
		if 'backup' in oOv4sVqEAmyM:
			oOv4sVqEAmyM = 'backup server'
			url = WKzTHuD7q1pSkI2bljg + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		else:
			oOv4sVqEAmyM = 'main server'
			url = EeQI5W40Jux3VfTLA9mRMc2 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		jbgkv9s6nVPfh.append(url)
		RRrXt1ehNJWMFxHTdVQ3.append('mp4  '+oOv4sVqEAmyM+YIPoWuLzfl93BTS+filename)
	qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('Select Video Quality:', RRrXt1ehNJWMFxHTdVQ3)
	if qreJEpY8nZguD == -1 : return
	url = jbgkv9s6nVPfh[qreJEpY8nZguD]
	qnUlyF2JXuGYdSA6Iac1(url,TVPm7Bz1XOwJ2,'video')
	return
def sj9BODtKv7C4Rl(url,type):
	if 'series' in url: hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/genre/مسلسل'
	else: hj50MJnoOp6ZWaS1IQ8Elr = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + '/genre/فيلم'
	hj50MJnoOp6ZWaS1IQ8Elr = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(hj50MJnoOp6ZWaS1IQ8Elr)
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = CZifHvYTr5oWzn7ecOS6(sT9DURSXlOybaCQ,hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHOOFMAX-FILTERS-1st')
	if type==1: Ry3L7fdNGh = RSuYINdeamsK0t.findall('subgenre(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	elif type==2: Ry3L7fdNGh = RSuYINdeamsK0t.findall('country(.*?)div',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('option value="(.*?)">(.*?)</option',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if type==1:
		for U50M34gSTuC1yLcWGdsbj,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url+'?subgenre='+U50M34gSTuC1yLcWGdsbj,58)
	elif type==2:
		url,U50M34gSTuC1yLcWGdsbj = url.split('?')
		for T3lKRZcek4aHVNfXCho5SsGngIqB07,title in items:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url+'?country='+T3lKRZcek4aHVNfXCho5SsGngIqB07+'&'+U50M34gSTuC1yLcWGdsbj,51)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if not search: search = p3bB2auMmSjXC0dE8FUfZ()
	if not search: return
	HJVMp5sLkG7EnixWo3QOg = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search?q='+HJVMp5sLkG7EnixWo3QOg
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,True,Vk54F7GcROfCy6HunEI,'SHOOFMAX-SEARCH-2nd')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('general-body(.*?)search-bottom-padding',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	if items:
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title in items:
			url = FFLhlYUAsfJBXeQmRpzD7c14ZP6 + ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(title)+'='+afR4xElWyzgcNAUnKXBempC
					v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,52,afR4xElWyzgcNAUnKXBempC)
				else:
					title = '_MOD_فيلم '+title
					v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,url,53,afR4xElWyzgcNAUnKXBempC)
	return
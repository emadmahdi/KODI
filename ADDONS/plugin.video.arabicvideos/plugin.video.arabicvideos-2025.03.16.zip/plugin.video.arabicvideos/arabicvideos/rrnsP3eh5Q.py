# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨ෎")
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,YWCso5NMKO=Vk54F7GcROfCy6HunEI):
	if   Yz6schq9wSmiu3IOdke0DXPj5W==wAU9jKvmTM0(u"࠰჻"): vKOw7TQipRgVJ2uj6L(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==YzowicIDTRusXZSU61(u"࠲ჼ"): pass
	elif Yz6schq9wSmiu3IOdke0DXPj5W==XCYALgFs2O3hZdpHrlMmB(u"࠴ჽ"): PPbAlF6upzw(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==jXWzIZcDva4ikEUfN(u"࠶ჾ"): hZztpFRygKaCM4XvNcSoOV0fw7BWdj()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==FGLEMi21Bfn(u"࠸ჿ"): JofGDhHkUQMTuq(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ogJClMiqPa4A0NUtTxpDVybEWG(u"࠺ᄀ"): UomQJTZ5gniLhH3v9dy()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠼ᄁ"): pAUuvy2wzOYfkItGqShabx()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ynxXU3gaiQ9GPCftr1q(u"࠷ᄂ"): I2wujS7YQ9g1GL3NcOF()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠹ᄃ"): wJuiVEm4FkAyh863xWH1YIo()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠳࠸࠴ᄄ"): bbJfYhgByLTePxWVNQ41uI2CKRn()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠴࠹࠶ᄅ"): hF57XKjDTlsMtU9()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WCPwmyVsb62KRlo(u"࠵࠺࠸ᄆ"): iXB8YZDgu3mMUh9sywlQd4bzrVf6FS()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠶࠻࠳ᄇ"): VvrfA1eNnPt6Om()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==cpHxZyU7vTtqmIw(u"࠷࠵࠵ᄈ"): pnuKhFTvJr4dIHPemgsj()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==Nlyfx1HnzOWCovke5(u"࠱࠶࠷ᄉ"): bN6okKjryIDtPXHQ()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==wYTDlJC5vpOKynUEX3ge6W(u"࠲࠷࠹ᄊ"): bRYCa1p64ZTJrSG()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ynxXU3gaiQ9GPCftr1q(u"࠳࠸࠻ᄋ"): mrvj2l1W3VUGI6hg()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WXuJd8nz2spo146t(u"࠴࠹࠽ᄌ"): PpBHNMzFGh9ORmSl2U3()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==V2RQwM8XjlrK(u"࠵࠺࠿ᄍ"): xu3Nf2nY1AlDLs9aQBM0eRtV45(YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MzgKWUQ4V5H(u"࠶࠽࠰ᄎ"): vXKWY3PrB1f()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==EM6qpnCBYQGA9kbgDVLfrP(u"࠷࠷࠲ᄏ"): xde5n04IjMfUgkl3VbHNhrytRsq()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠱࠸࠴ᄐ"): JoZC8kepNQbxWhIyw1E2iFTSgd90([YWCso5NMKO],YOHXqtbQTBfKerIZ,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠲࠹࠶ᄑ"): hhiACvapbKSt(Nlyfx1HnzOWCovke5(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧා"),YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==FGLEMi21Bfn(u"࠳࠺࠸ᄒ"): hhiACvapbKSt(cpHxZyU7vTtqmIw(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫැ"),YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WCPwmyVsb62KRlo(u"࠴࠻࠺ᄓ"): pGDQh5UOsEbrP8vljFB79Z36wK()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==g7yJo2LVuqx1trPe(u"࠵࠼࠼ᄔ"): Gh41l8npkrwoYPOLgQX3m27M()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠶࠽࠷ᄕ"): GfjdlRbw1Zng7OoStNq4IpMQryKeu(MzgKWUQ4V5H(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ෑ"))
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠷࠷࠺ᄖ"): GfjdlRbw1Zng7OoStNq4IpMQryKeu(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪි"))
	elif Yz6schq9wSmiu3IOdke0DXPj5W==cpHxZyU7vTtqmIw(u"࠱࠺࠲ᄗ"): ccUmXov1LtjWkps6D7l3gx2z()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==EM6qpnCBYQGA9kbgDVLfrP(u"࠲࠻࠴ᄘ"): mmB9hH5Wkcz()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ynxXU3gaiQ9GPCftr1q(u"࠳࠼࠶ᄙ"): cksnWQRdq6ZXM()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==V2RQwM8XjlrK(u"࠴࠽࠸ᄚ"): ccvpRmIn3yweJ()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠵࠾࠺ᄛ"): VucPRFZqU4xfgGa9owQdSBl()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ESXZrtnCfcDJGo01vFg(u"࠶࠿࠵ᄜ"): UUR63ar4ucVZn0OPXfFkb()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠷࠹࠷ᄝ"): HPEOL9UBn4asVkN()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠱࠺࠹ᄞ"): xxnrcQilY7wKuB0fm()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==XCYALgFs2O3hZdpHrlMmB(u"࠲࠻࠻ᄟ"): Bbu2wWZCF8yir3HcY0RnDTQl()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==XCYALgFs2O3hZdpHrlMmB(u"࠳࠼࠽ᄠ"): ATQXCtyENu2Si4p()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠶࠸࠵ᄡ"): i6Owafmbkvu0cLzTteX(YWCso5NMKO)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WXuJd8nz2spo146t(u"࠷࠹࠷ᄢ"): Es63UjSadM1BpQVL89AmqrG7gICN()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==cpHxZyU7vTtqmIw(u"࠸࠺࠲ᄣ"): fNMCHET8dOcDt5X()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==pnkrd2S84FJfN73KuiCYv(u"࠹࠴࠴ᄤ"): bbdOMB1HQ6PIhi8yvRwCzp2JnY()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ogJClMiqPa4A0NUtTxpDVybEWG(u"࠳࠵࠷ᄥ"): gZSUiYr2zxaJXpuvbN7BndltGmM0()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ogJClMiqPa4A0NUtTxpDVybEWG(u"࠴࠶࠹ᄦ"): iVKej0gmSCBlTvdGfMZ(eu1NswY9zkKC60I)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==WXuJd8nz2spo146t(u"࠵࠷࠻ᄧ"): hFGk9YqAuCsE(YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠶࠸࠽ᄨ"): kf5pwbUI6s39lgvecn0PxR2BuT8()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==cpHxZyU7vTtqmIw(u"࠷࠹࠿ᄩ"): RexMqYz6sFoCOLBwjXa89GtKgvHJD(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩී"),YOHXqtbQTBfKerIZ,YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠺࠶࠰ᄪ"): gxwurBfvXqoRnbPtDpk6Je5ji7()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠻࠰࠲ᄫ"): YcXVrRIZjo0x2Mtp4H7iJyn()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==eAMGzHRQVs2KyCwPXljYhB(u"࠵࠱࠴ᄬ"): ffVHjy6qiX24QxtKdgsWehU()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ynxXU3gaiQ9GPCftr1q(u"࠶࠲࠶ᄭ"): gXjd3xutD76HYlTUeFo(yPQp8EHdSgmNcl04zOa)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠷࠳࠸ᄮ"): gXjd3xutD76HYlTUeFo(n28VC34lcrAhgiJtKXU7WqjTOw9)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==g7yJo2LVuqx1trPe(u"࠸࠴࠺ᄯ"): UyCOleSGjugpNLaxd()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SSBkx0WbN1asnDCQV6tIj(u"࠹࠵࠼ᄰ"): Rl9iZEjgtdhHAocuU1fk7wLPB6r(YOHXqtbQTBfKerIZ)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠺࠶࠷ᄱ"): mKiy8eOt75ZplnTH421hA()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠻࠰࠹ᄲ"): A9jfXnvEkM1LFrW4yc8Iwp()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠱࠱࠴࠳ᄳ"): MqGvpyJsIYl30no()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠲࠲࠵࠵ᄴ"): YfBDqXU0KgtWm13NSPcp7G()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==MzgKWUQ4V5H(u"࠳࠳࠶࠷ᄵ"): GfjdlRbw1Zng7OoStNq4IpMQryKeu(g7yJo2LVuqx1trPe(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪු"))
	elif Yz6schq9wSmiu3IOdke0DXPj5W==EM6qpnCBYQGA9kbgDVLfrP(u"࠴࠴࠷࠹ᄶ"): hyboHCtVl9nmFR5i4kEA1w2gITXz3j()
	return
def hyboHCtVl9nmFR5i4kEA1w2gITXz3j():
	LL82RbVxIQF1XBfYZM3 = cad8TeSyMUYmfsEO0.getSetting(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ෕"))
	message = jXWzIZcDva4ikEUfN(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭ූ")+str(LL82RbVxIQF1XBfYZM3)+eAMGzHRQVs2KyCwPXljYhB(u"ࠨࠢ࡮ࡦࡵࡹࠧ෗") if LL82RbVxIQF1XBfYZM3 else EM6qpnCBYQGA9kbgDVLfrP(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨෘ")
	message = nMt0iueCy6K+message+YzowicIDTRusXZSU61(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩෙ")+ZZoLlKyInXc08j2pTGJ
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫේ"),cpHxZyU7vTtqmIw(u"ࠬิั้ฮࠪෛ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ล๋ไสๅࠬො"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧหึ฽๎้࠭ෝ"),ynxXU3gaiQ9GPCftr1q(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫෞ"),MzgKWUQ4V5H(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส๊ࠢ๎ࠥ฿ๅๅ์ฬࠤ๏่่ๆࠢห๋ฬࠦวๅสิ๊ฬ๋ฬࠡสสาฯ๐วาࠢฦ฽้๏ࠠอ๊าอ๋ࠥส้ใิอ๊ࠥัใ็ࠣห้า่ะหࠣห้ึ๊ࠡษ้ฮࠥะอะั๊ࠤๆ๐่ࠠา๊ࠤฬ๊ิศึฬࠤ࠳࠴้้ࠠำหู๋ࠥ็ษ๊ࠤ฾์ฯๆษࠣฮ็๎ๅࠡษ้ฮࠥฮสี฼ํ่ࠥ็๊ะ์๋ࠤๆอๆࠡษ็ฬึ์วๆฮ่๋๊ࠣࠦิล็็ࠥ฿ๆࠡษ็ะํีษࠡษ็ฮ๏ࠦสา์า๋ฬࠦไฤ่ࠣห้ฮั็ษ่ะู่ࠥโࠢําฯอัࠡษ็ะํีษࠡล๋ฮํ๋วห์ๆ๎ฬࠦ࠮࠯ࠢ฼่๊อࠠศ่๊ࠤ๏าศࠡษัฮ๏อัࠡำๅ้ࠥา่ะหูࠣ฿๐ัࠡวำห้ࠥว็ฬࠣห้หๆหำ้ฮࠥ฿ๆะๅࠣฬ฼๐ฦสࠢฦ์่ࠥไ๋ๆฬࡠࡳࡢ࡮ࠨෟ")+message)
	if OFEaiVuGrdSf20oxQl57Wp9A in [-eAMGzHRQVs2KyCwPXljYhB(u"࠵ᄷ"),WsklGNp2CYzVQUag(u"࠵ᄸ")]: return
	if OFEaiVuGrdSf20oxQl57Wp9A==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠷ᄹ"):
		LL82RbVxIQF1XBfYZM3 = Vk54F7GcROfCy6HunEI
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭෠"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"๋ࠫาอหࠢ฼้้๐ษࠡวํๆฬ็ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠧ෡"))
	else:
		items = [NNjUsZzEcFOAoKry2CDMgb1(u"ࠬ࠸࠵࠱ࠢ࡮ࡦࡵࡹࠧ෢"),V2RQwM8XjlrK(u"࠭࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ෣"),MpJ8GOKoic(u"ࠧ࠸࠷࠳ࠤࡰࡨࡰࡴࠩ෤"),XCYALgFs2O3hZdpHrlMmB(u"ࠨ࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ෥"),jXWzIZcDva4ikEUfN(u"ࠩ࠴࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬ෦"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪ࠵࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭෧"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫ࠶࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧ෨"),YzowicIDTRusXZSU61(u"ࠬ࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ෩"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭࠲࠶࠲࠳ࠤࡰࡨࡰࡴࠩ෪"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࠴࠲࠳࠴ࠥࡱࡢࡱࡵࠪ෫"),WsklGNp2CYzVQUag(u"ࠨ࠵࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫ෬"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩ࠷࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ෭"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠪ࠸࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭෮"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫ࠺࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ෯"),eAMGzHRQVs2KyCwPXljYhB(u"ࠬ࠼࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ෰"),HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭࠷࠱࠲࠳ࠤࡰࡨࡰࡴࠩ෱"),pnkrd2S84FJfN73KuiCYv(u"ࠧ࠹࠲࠳࠴ࠥࡱࡢࡱࡵࠪෲ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨ࠻࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫෳ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠩ࠴࠴࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭෴"),FGLEMi21Bfn(u"ࠪ࠵࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ෵"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫ࠶࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ෶"),YzowicIDTRusXZSU61(u"ࠬ࠿࠹࠺࠻࠼ࠤࡰࡨࡰࡴࠩ෷")]
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(YzowicIDTRusXZSU61(u"࠭วฯฬิࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤฬ๊ๅ็ษึฬฮ࠭෸"),items)
		if qreJEpY8nZguD==-XCYALgFs2O3hZdpHrlMmB(u"࠱ᄺ"): return
		LL82RbVxIQF1XBfYZM3 = str(items[qreJEpY8nZguD][:-wYTDlJC5vpOKynUEX3ge6W(u"࠶ᄻ")])
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ෹"),QYSAUI5r46yil8cfaO(u"ࠨ่ฯัฯูࠦๆๆํอࠥะิ฻์็ࠤํะอะ์าࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษ࡝ࡰ࡟ࡲࠬ෺")+nMt0iueCy6K+LL82RbVxIQF1XBfYZM3+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࠣ࡯ࡧࡶࡳࠨ෻")+ZZoLlKyInXc08j2pTGJ)
	cad8TeSyMUYmfsEO0.setSetting(cpHxZyU7vTtqmIw(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ෼"),LL82RbVxIQF1XBfYZM3)
	return
def YfBDqXU0KgtWm13NSPcp7G(Db1rWd3ICTAVKh8owc9QB7GLXug6ZH=eu1NswY9zkKC60I):
	fEqBjuYV2n7 = mGFoAfjJb59P3hnp()
	fJHXGS7YqL3kaR = Nlyfx1HnzOWCovke5(u"ࠫฬ๊สี฼ํ่ࠥอไๅษะๆࠥ๐ูๆๆࠪ෽") if fEqBjuYV2n7 else SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬอไหึ฽๎้ࠦวๅๆสั็ࠦๅห๊ๅๅࠬ෾")
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(MzgKWUQ4V5H(u"࠭ࡣࡦࡰࡷࡩࡷ࠭෿"),Nlyfx1HnzOWCovke5(u"ࠧฯำ๋ะࠬ฀"),jXWzIZcDva4ikEUfN(u"ࠨวํๆฬ็ࠧก"),g7yJo2LVuqx1trPe(u"ࠩอุ฿๐ไࠨข"),SSBkx0WbN1asnDCQV6tIj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ฃ"),nMt0iueCy6K+fJHXGS7YqL3kaR+ZZoLlKyInXc08j2pTGJ+ixrPWKeFMnqJyVodX6D9AaO2+MpJ8GOKoic(u"ࠫ์ึ็ࠡษ็์฽๐แสࠢอะ฾๊ࠠไ๊า๎ࠥษ่ห๊่หฯ๐ใ๋ษࠣ๎็๎ๅࠡสอุ฿๐ไࠡษ็ๅ๏ี๊้ࠢส่้ออใࠢ࠱࠲ࠥหๅศࠢห฽ิࠦว็ฬ๊หฦࠦวๅใํำ๏๎ࠠศๆะห้๐ࠠษลๆ้้ํࠠ࠯࠰ࠣวํࠦศฺัࠣห้์โาࠢ฼่๎ࠦาาࠢࠥฮัอ่ำࠢศ่๎ࠦวๅๆสั็ࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠฦๆ฽หฦࠦวๅฬื฾๏๊ࠠศๆ็หา่ࠠษษ็๊็ืฺࠠๆ์ࠤืืࠠࠣวํๆฬ็ࠠศๆไ๎ิ๐่ࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢส่ฬูสโษาอ๋ࠥๆࠡฬ฽๎๏ืࠠหำอ๎อࠦๅฮฬ๋๎ฬะࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤํิวึหࠣฮึะ๊ษࠢะ่็อสࠡษ็ุ้๊ำๅษอࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่ࠥํะ่ࠢส่ํ฾๊โหࠣว๊ࠦล๋ไสๅ์อࠠภࠣࠤࠫค"))
	if OFEaiVuGrdSf20oxQl57Wp9A==pwxH3oREFm5v98BCZ1QVtzMJOc: yjsIKYfTL4vHnte3oa2h9 = J2L6to3R1Z.executeJSONRPC(WCPwmyVsb62KRlo(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࡡ࡝ࡾࡿࠪฅ"))
	elif OFEaiVuGrdSf20oxQl57Wp9A==RXnhpCUk4M1TvgJE: yjsIKYfTL4vHnte3oa2h9 = J2L6to3R1Z.executeJSONRPC(V2RQwM8XjlrK(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀ࡛࠲࡟ࢀࢁࠬฆ"))
	if OFEaiVuGrdSf20oxQl57Wp9A in [pwxH3oREFm5v98BCZ1QVtzMJOc,RXnhpCUk4M1TvgJE]:
		if SSBkx0WbN1asnDCQV6tIj(u"ࠧࡵࡴࡸࡩࠬง") in str(yjsIKYfTL4vHnte3oa2h9): GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫจ"),ESXZrtnCfcDJGo01vFg(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา࠭ฉ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ช"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩซ"))
	return
def MqGvpyJsIYl30no():
	url = h9zFQKnsNL.SITESURLS[FGLEMi21Bfn(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧฌ")][FGLEMi21Bfn(u"࠲ᄼ")]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,SSBkx0WbN1asnDCQV6tIj(u"࠭ࡇࡆࡖࠪญ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬฎ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	jDCuyJxcOvUi85NX3g = RSuYINdeamsK0t.findall(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨฏ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	jDCuyJxcOvUi85NX3g = sorted(jDCuyJxcOvUi85NX3g,reverse=YOHXqtbQTBfKerIZ)
	qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫฐ"),jDCuyJxcOvUi85NX3g)
	if qreJEpY8nZguD>=pnkrd2S84FJfN73KuiCYv(u"࠳ᄽ"):
		pWZ2u81BLxsot7 = url.rsplit(FGLEMi21Bfn(u"ࠪ࠳ࠬฑ"),MzgKWUQ4V5H(u"࠵ᄾ"))[ynxXU3gaiQ9GPCftr1q(u"࠵ᄿ")]+SSBkx0WbN1asnDCQV6tIj(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬฒ")+jDCuyJxcOvUi85NX3g[qreJEpY8nZguD]+HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬ࠴ࡺࡪࡲࠪณ")
		succeeded = ssCKhpFQLgf1MyV7GnHOlqeS86w(Nlyfx1HnzOWCovke5(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫด"),pWZ2u81BLxsot7,YOHXqtbQTBfKerIZ)
		if succeeded:
			cad8TeSyMUYmfsEO0.setSetting(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫต"),Vk54F7GcROfCy6HunEI)
			W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫถ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩอ้ࠥะหษ์อࠤส฻ฯศำࠣๆิ๐ๅࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦไไ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอะอะ์ฮࠤัฺ๋๊ࠢส่อืวๆฮࠣฬฬูสฯัส้ࠥศฮาࠢศูิอัࠡ็อ์ๆืࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ๊ิฬࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬท"))
			if W8j2OheqsroDJIYzRupt6nG: RexMqYz6sFoCOLBwjXa89GtKgvHJD(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨธ"),YOHXqtbQTBfKerIZ,YOHXqtbQTBfKerIZ)
	return
def mKiy8eOt75ZplnTH421hA():
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧน"),WsklGNp2CYzVQUag(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥํะศࠢสู่๊อࠡี๋ๅࠥ๐ำษสࠣฮาี๊ฬࠢไ์ึ๐ࠠๅฮ่๎฾ู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡ็ิ์ึ่ࠦใฬ้ࠣ฾๐ๆࠨบ"))
	if W8j2OheqsroDJIYzRupt6nG:
		cad8TeSyMUYmfsEO0.setSetting(ESXZrtnCfcDJGo01vFg(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫป"),Vk54F7GcROfCy6HunEI)
		cad8TeSyMUYmfsEO0.setSetting(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧผ"),Vk54F7GcROfCy6HunEI)
		cad8TeSyMUYmfsEO0.setSetting(NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬฝ"),Vk54F7GcROfCy6HunEI)
		cad8TeSyMUYmfsEO0.setSetting(EM6qpnCBYQGA9kbgDVLfrP(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪพ"),Vk54F7GcROfCy6HunEI)
		cad8TeSyMUYmfsEO0.setSetting(MzgKWUQ4V5H(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬฟ"),Vk54F7GcROfCy6HunEI)
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧภ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬะๅࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๋ࠢืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮสฮัํฯࠥํะ่ࠢส่ส฿ฯศัสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠหฯา๎ะู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡษ็์็ะࠧม"))
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def UyCOleSGjugpNLaxd():
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩย"),V2RQwM8XjlrK(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪร"))
	Xt0iUuE28TYN = wDHvEzd4FOJ1tfBIWQxqur2(eu1NswY9zkKC60I)
	n0nUhd3RCeb2xwuJN = ixrPWKeFMnqJyVodX6D9AaO2
	gdG92bIJaWVoCKSDi0 = d761ZWXHEvliYN45RzLP2+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤࠬฤ")+ZZoLlKyInXc08j2pTGJ
	Ai3ejTdxI75O9Mzp840DGysuhLCW = ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+FGLEMi21Bfn(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ล")+ZZoLlKyInXc08j2pTGJ+EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡠࡳࡢ࡮ࠨฦ")
	for id,igk6DQGT2ychz38,vy5uSAZOmWehispxjE1DLcl,TcjPsL1WbHfAtq,avBR5hpQq97e,reason in reversed(Xt0iUuE28TYN):
		if id==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫ࠵࠭ว"):
			wDRZm4GS7MqlvjpEaxNrJ5eIdVFy,gaGFzTis7M8UcWh1PEDxy0SVKZ = TcjPsL1WbHfAtq.split(g7yJo2LVuqx1trPe(u"ࠬࡢ࡮࠼࠽ࠪศ"))
			continue
		if n0nUhd3RCeb2xwuJN!=ixrPWKeFMnqJyVodX6D9AaO2: n0nUhd3RCeb2xwuJN += Ai3ejTdxI75O9Mzp840DGysuhLCW
		burCKRDXAy9jY = QYSAUI5r46yil8cfaO(u"࡛࠭ࡓࡖࡏࡡࠬษ")+d761ZWXHEvliYN45RzLP2+id+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࠡ࠼ࠣࠫส")+MpJ8GOKoic(u"ࠨษ็ืษอไࠡ࠼ࠣࠫห")+ZZoLlKyInXc08j2pTGJ+vy5uSAZOmWehispxjE1DLcl
		eeHAfglvTVoC0QE = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟ࠪฬ")+d761ZWXHEvliYN45RzLP2+ynxXU3gaiQ9GPCftr1q(u"ࠪห้า่ศสࠣ࠾ࠥ࠭อ")+ZZoLlKyInXc08j2pTGJ+TcjPsL1WbHfAtq
		YtHmu8d3UpLj7XA = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡠࡘࡔࡍ࡟ࠪฮ")+d761ZWXHEvliYN45RzLP2+jXWzIZcDva4ikEUfN(u"ࠬอไฯูฦࠤ࠿ࠦࠧฯ")+ZZoLlKyInXc08j2pTGJ+avBR5hpQq97e
		lNKx2h7tHjsZR4XEf = g7yJo2LVuqx1trPe(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧะ")+d761ZWXHEvliYN45RzLP2+WsklGNp2CYzVQUag(u"ࠧศๆึฬอࠦ࠺ࠡࠩั")+ZZoLlKyInXc08j2pTGJ+reason
		n0nUhd3RCeb2xwuJN += burCKRDXAy9jY+eeHAfglvTVoC0QE+ixrPWKeFMnqJyVodX6D9AaO2+gdG92bIJaWVoCKSDi0+ixrPWKeFMnqJyVodX6D9AaO2+YtHmu8d3UpLj7XA+lNKx2h7tHjsZR4XEf+ixrPWKeFMnqJyVodX6D9AaO2
	aaNxZcCAYds8FEjDqzgBhK4(pnkrd2S84FJfN73KuiCYv(u"ࠨࡴ࡬࡫࡭ࡺࠧา"),gaGFzTis7M8UcWh1PEDxy0SVKZ,n0nUhd3RCeb2xwuJN,g7yJo2LVuqx1trPe(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪำ"))
	return
def gXjd3xutD76HYlTUeFo(file):
	if file==n28VC34lcrAhgiJtKXU7WqjTOw9: fuiqQtzGFy4CkJhEa9YSDKLx12ZWM = EM6qpnCBYQGA9kbgDVLfrP(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪิ")
	elif file==yPQp8EHdSgmNcl04zOa: fuiqQtzGFy4CkJhEa9YSDKLx12ZWM = wAU9jKvmTM0(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫี")
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(WXuJd8nz2spo146t(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬึ"),MzgKWUQ4V5H(u"࠭ๅิฯࠪื"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧฦื็หาุ࠭"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨะิ์ัู࠭"),WCPwmyVsb62KRlo(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะฺࠬ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨ฻")+fuiqQtzGFy4CkJhEa9YSDKLx12ZWM+SSBkx0WbN1asnDCQV6tIj(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫ฼"))
	if OFEaiVuGrdSf20oxQl57Wp9A==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠶ᅀ"):
		if CR3aLOVKSIme5XFoYi6M.path.exists(file):
			try: CR3aLOVKSIme5XFoYi6M.remove(file)
			except: pass
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ฽"),ynxXU3gaiQ9GPCftr1q(u"࠭สๆ่ࠢืาࠦๅๅใࠣࠫ฾")+fuiqQtzGFy4CkJhEa9YSDKLx12ZWM)
	elif OFEaiVuGrdSf20oxQl57Wp9A==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠱ᅁ"):
		data = b8phWg7UYlxwmD5ePBJ(file)
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ฿"),ESXZrtnCfcDJGo01vFg(u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨเ")+fuiqQtzGFy4CkJhEa9YSDKLx12ZWM)
	return
def YcXVrRIZjo0x2Mtp4H7iJyn():
	if gs15xoifvOt<SSBkx0WbN1asnDCQV6tIj(u"࠲࠺ᅂ"):
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = XCYALgFs2O3hZdpHrlMmB(u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬแ")+str(gs15xoifvOt)+MpJ8GOKoic(u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫโ")
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧใ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
		return
	nshIMkbZEPQr452WV8 = J2L6to3R1Z.executeJSONRPC(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨไ"))
	rUWTIdPJlh4uNp2w = aaSgYM8cEP([QYSAUI5r46yil8cfaO(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬๅ")])
	gTAWC1nqJj2h,SsP3uepLczdZR5FGaV,GUC679coq1EInpNwXm3Of,RNWnE5t6Gcqvh,hUQECY1J9cswZnfB6mtbFdWI,ZKMzxnXtwRYODLQUp9aJPgoT7E2Sjf,jjDGnkvcqdBRohrTIpa3CbVUAXu = rUWTIdPJlh4uNp2w[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ๆ")]
	if gTAWC1nqJj2h or wYTDlJC5vpOKynUEX3ge6W(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ็") not in str(nshIMkbZEPQr452WV8):
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ่ࠬ"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ้"))
		kNQM9jAU6TVlhezn14cKtBb = ffVHjy6qiX24QxtKdgsWehU()
		if not kNQM9jAU6TVlhezn14cKtBb: return
	etBvcPSDwmNMR7Hj0ZrQ2O5(YOHXqtbQTBfKerIZ)
	return
def etBvcPSDwmNMR7Hj0ZrQ2O5(showDialogs=YOHXqtbQTBfKerIZ):
	nshIMkbZEPQr452WV8 = J2L6to3R1Z.executeJSONRPC(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃ๊ࠧ"))
	if ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ๋ࠫ") not in str(nshIMkbZEPQr452WV8):
		if showDialogs:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ์"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬํ"))
		return
	lJ0XZmaMUHwqSpYrPOxc = CR3aLOVKSIme5XFoYi6M.path.join(Z7NtweOaCqhSgKuT1A5rip6sbP23,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡣࡧࡨࡴࡴࡳࠨ๎"),cpHxZyU7vTtqmIw(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ๏"),FGLEMi21Bfn(u"ࠪ࠻࠷࠶ࡰࠨ๐"),WsklGNp2CYzVQUag(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ๑"))
	if not CR3aLOVKSIme5XFoYi6M.path.exists(lJ0XZmaMUHwqSpYrPOxc): return
	IOmoiweTvpJuaZz = open(lJ0XZmaMUHwqSpYrPOxc,YzowicIDTRusXZSU61(u"ࠬࡸࡢࠨ๒")).read()
	if PvwFsJK23NbU8XWAx: IOmoiweTvpJuaZz = IOmoiweTvpJuaZz.decode(AoCWwJHgUPKXI7u2lEzym)
	ehpc0kiZu61Vf3MOLwQvyrGD5B2 = RSuYINdeamsK0t.findall(FGLEMi21Bfn(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠨ࡝ࡦ࠮࠰ࡡࡪࠫ࠭࡞ࡧ࠯࠮࠲ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭๓"),IOmoiweTvpJuaZz,RSuYINdeamsK0t.DOTALL)
	jPyrBYC6M7Lb4mkGFZQK9f,l9W2EXMaZcHodrxkift1OU03u = ehpc0kiZu61Vf3MOLwQvyrGD5B2[ufmXvxgoHGDwZtjsLkR05i]
	puj4tMoCrc = pnkrd2S84FJfN73KuiCYv(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨ๔")+jPyrBYC6M7Lb4mkGFZQK9f+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨ࠮ࠪ๕")+l9W2EXMaZcHodrxkift1OU03u+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ๖")
	if showDialogs:
		EbdAit7SmFqD96zp3nN = J2L6to3R1Z.getInfoLabel(V2RQwM8XjlrK(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡖࡪࡧࡺࡱࡴࡪࡥࠨ๗"))
		if EbdAit7SmFqD96zp3nN==SSBkx0WbN1asnDCQV6tIj(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ๘"): k3jSrJXBQaf9Y8IDZ7HAcoyV = MzgKWUQ4V5H(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ๙")
		elif EbdAit7SmFqD96zp3nN==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ๚"): k3jSrJXBQaf9Y8IDZ7HAcoyV = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ๛")
		else: k3jSrJXBQaf9Y8IDZ7HAcoyV = WXuJd8nz2spo146t(u"ࠨไ๋หห๋ࠠฤะิํࠬ๜")
		OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(cpHxZyU7vTtqmIw(u"ࠩࡦࡩࡳࡺࡥࡳࠩ๝"),g7yJo2LVuqx1trPe(u"ࠪๆํอฦๆࠢฦาึ๏ࠧ๞"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫ็๎วว็ࠣห้้สศสฬࠫ๟"),eAMGzHRQVs2KyCwPXljYhB(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ๠"),XCYALgFs2O3hZdpHrlMmB(u"࠭ว็ฬࠣัฬ๊๊ศࠢอืฯิฯๆࠢࠪ๡")+k3jSrJXBQaf9Y8IDZ7HAcoyV,V2RQwM8XjlrK(u"ࠧศ่อࠤฬ๊ย็ࠢอืฯิฯๆࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣ์์ึวࠡ็฼๊ฬํࠠศ่ๆࠤฯูสุ์฼ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠษั็ห๋ࠥๆࠡไ๋หห๋ࠠศๆๆฮฬฮษࠡ࠰ࠣ์ศ๐ึศࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ษࠣๅ๏ࠦร๋๋ࠢๆฯࠦสีษฤࠤࡡࡴ࡜࡯ࠢࠪ๢")+d761ZWXHEvliYN45RzLP2+SSBkx0WbN1asnDCQV6tIj(u"ࠨࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࠬ๣")+ZZoLlKyInXc08j2pTGJ)
		if OFEaiVuGrdSf20oxQl57Wp9A==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠳ᅃ"): xqmXBr1IMVoYu = NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ๤")
		elif OFEaiVuGrdSf20oxQl57Wp9A==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠵ᅄ"): xqmXBr1IMVoYu = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ๥")
		else: xqmXBr1IMVoYu = Vk54F7GcROfCy6HunEI
	else:
		EbdAit7SmFqD96zp3nN = cad8TeSyMUYmfsEO0.getSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ๦"))
		if   EbdAit7SmFqD96zp3nN==Vk54F7GcROfCy6HunEI: OFEaiVuGrdSf20oxQl57Wp9A = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠴ᅅ")
		elif EbdAit7SmFqD96zp3nN==ynxXU3gaiQ9GPCftr1q(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ๧"): OFEaiVuGrdSf20oxQl57Wp9A = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠶ᅆ")
		elif EbdAit7SmFqD96zp3nN==QYSAUI5r46yil8cfaO(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ๨"): OFEaiVuGrdSf20oxQl57Wp9A = WXuJd8nz2spo146t(u"࠸ᅇ")
		xqmXBr1IMVoYu = EbdAit7SmFqD96zp3nN
	if   OFEaiVuGrdSf20oxQl57Wp9A==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠰ᅈ"): jMGKY3kXniP6q7ED8H9FS54Wslegcu = QYSAUI5r46yil8cfaO(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫ๩")
	elif OFEaiVuGrdSf20oxQl57Wp9A==WXuJd8nz2spo146t(u"࠲ᅉ"): jMGKY3kXniP6q7ED8H9FS54Wslegcu = MzgKWUQ4V5H(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬ๪")
	elif OFEaiVuGrdSf20oxQl57Wp9A==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠴ᅊ"): jMGKY3kXniP6q7ED8H9FS54Wslegcu = ynxXU3gaiQ9GPCftr1q(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭๫")
	else: return
	cad8TeSyMUYmfsEO0.setSetting(g7yJo2LVuqx1trPe(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ๬"),xqmXBr1IMVoYu)
	fvOxXU34pMmLJFRuQdr1zjAYI2CcDN = Nlyfx1HnzOWCovke5(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬ๭")+jMGKY3kXniP6q7ED8H9FS54Wslegcu+EM6qpnCBYQGA9kbgDVLfrP(u"ࠬ࠲ࠧ๮")+l9W2EXMaZcHodrxkift1OU03u+wAU9jKvmTM0(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ๯")
	z1LfE2uZlBi0evYjxcTR7XgrC = IOmoiweTvpJuaZz.replace(puj4tMoCrc,fvOxXU34pMmLJFRuQdr1zjAYI2CcDN)
	if PvwFsJK23NbU8XWAx: z1LfE2uZlBi0evYjxcTR7XgrC = z1LfE2uZlBi0evYjxcTR7XgrC.encode(AoCWwJHgUPKXI7u2lEzym)
	open(lJ0XZmaMUHwqSpYrPOxc,XCYALgFs2O3hZdpHrlMmB(u"ࠧࡸࡤࠪ๰")).write(z1LfE2uZlBi0evYjxcTR7XgrC)
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨ࠰࡟ࡸࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭๱")+jMGKY3kXniP6q7ED8H9FS54Wslegcu+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࠣࡡࠬ๲"))
	if showDialogs: J2L6to3R1Z.executebuiltin(g7yJo2LVuqx1trPe(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩ๳"))
	return
def gxwurBfvXqoRnbPtDpk6Je5ji7():
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ๴"),MzgKWUQ4V5H(u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪ๵"))
	if W8j2OheqsroDJIYzRupt6nG==BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠴ᅋ"): I2wujS7YQ9g1GL3NcOF()
	return
def wJuiVEm4FkAyh863xWH1YIo():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๶"),QYSAUI5r46yil8cfaO(u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆࠪ๷"))
	return
def kf5pwbUI6s39lgvecn0PxR2BuT8():
	burCKRDXAy9jY = d761ZWXHEvliYN45RzLP2+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨฬ฼ำฬีࠠี์฼อࠥศไࠡ็ะ้ิࠦไิ่ฬࠤ࠷࠶࠲࠲ࠢ࠽ࠤࠬ๸")+ZZoLlKyInXc08j2pTGJ
	burCKRDXAy9jY += XCYALgFs2O3hZdpHrlMmB(u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨ๹")
	burCKRDXAy9jY += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+SSBkx0WbN1asnDCQV6tIj(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴࠨ๺")+ZZoLlKyInXc08j2pTGJ
	eeHAfglvTVoC0QE = d761ZWXHEvliYN45RzLP2+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫอืๆศ็ฯࠤูืุ๊ࠢสู่๊ไๆࠢ࠽ࠤࠬ๻")+ZZoLlKyInXc08j2pTGJ
	eeHAfglvTVoC0QE += QYSAUI5r46yil8cfaO(u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩ๼")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷ࠭๽")+ZZoLlKyInXc08j2pTGJ
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = pnkrd2S84FJfN73KuiCYv(u"ࠧ࡜ࡔࡗࡐࡢ࠭๾")+burCKRDXAy9jY+jXWzIZcDva4ikEUfN(u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭๿")+eeHAfglvTVoC0QE
	aaNxZcCAYds8FEjDqzgBhK4(WsklGNp2CYzVQUag(u"ࠩࡵ࡭࡬࡮ࡴࠨ຀"),Vk54F7GcROfCy6HunEI,BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def iVKej0gmSCBlTvdGfMZ(oX6deUmzM4yS0WfJg5pvxra):
	kfBIcpzCR4O(AOhmwtSyYBn4ZF7RuvQNU)
	Xt0iUuE28TYN = wDHvEzd4FOJ1tfBIWQxqur2(oX6deUmzM4yS0WfJg5pvxra)
	for wa6JNfixUTIWdpe3ROE2Z4XgmQzCrF in [kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬກ"),WsklGNp2CYzVQUag(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧຂ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪ຃"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࡡࡗࡗࠬຄ")]:
		if wa6JNfixUTIWdpe3ROE2Z4XgmQzCrF in h9zFQKnsNL.SEND_THESE_EVENTS: h9zFQKnsNL.SEND_THESE_EVENTS.remove(wa6JNfixUTIWdpe3ROE2Z4XgmQzCrF)
	uDgqdPIMJYjQpiG6VKhySfObaLz(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡅࡑࡑࡅ࡙ࡏࡏࡏࡕࠪ຅"))
	id,igk6DQGT2ychz38,vy5uSAZOmWehispxjE1DLcl,TcjPsL1WbHfAtq,avBR5hpQq97e,reason = Xt0iUuE28TYN[ufmXvxgoHGDwZtjsLkR05i]
	wDRZm4GS7MqlvjpEaxNrJ5eIdVFy,gaGFzTis7M8UcWh1PEDxy0SVKZ = TcjPsL1WbHfAtq.split(g7yJo2LVuqx1trPe(u"ࠨ࡞ࡱ࠿ࡀ࠭ຆ"))
	eeHAfglvTVoC0QE,YtHmu8d3UpLj7XA,lNKx2h7tHjsZR4XEf = avBR5hpQq97e.split(wYTDlJC5vpOKynUEX3ge6W(u"ࠩ࡟ࡲࡀࡁࠧງ"))
	bwvgY4rkez3OM = YOHXqtbQTBfKerIZ
	while bwvgY4rkez3OM:
		VixLZSzHD6j3 = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪาึ๎ฬࠨຈ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪຉ"),XCYALgFs2O3hZdpHrlMmB(u"่ࠬวว็ฬࠤฬ๊สษำ฼หฯ࠭ຊ"),WXuJd8nz2spo146t(u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢ࠽ࠤࠥะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ั࠭຋"),eeHAfglvTVoC0QE)
		if VixLZSzHD6j3==WXuJd8nz2spo146t(u"࠶ᅌ"): TEc8GMnI0taJSH1PxrqyipvWCZh = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ฺ๊ࠧาอࠬຌ"),Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ็หำศࠦวๅฬหี฾ฺ๋ࠦำࠣๆฬฮไࠡๆ็๊็อิࠨຍ"),YtHmu8d3UpLj7XA,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭ຎ"))
		elif VixLZSzHD6j3==ogJClMiqPa4A0NUtTxpDVybEWG(u"࠶ᅍ"): PPbAlF6upzw()
		else: bwvgY4rkez3OM = eu1NswY9zkKC60I
	if oX6deUmzM4yS0WfJg5pvxra: YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def gZSUiYr2zxaJXpuvbN7BndltGmM0():
	ccUmXov1LtjWkps6D7l3gx2z()
	BWhcrEC1I8dxDKsTLNl6GaVQ = cad8TeSyMUYmfsEO0.getSetting(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩຏ"))
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = {}
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[jXWzIZcDva4ikEUfN(u"ࠫࡆ࡛ࡔࡐࠩຐ")] = wAU9jKvmTM0(u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫຑ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[V2RQwM8XjlrK(u"࠭ࡓࡕࡑࡓࠫຒ")] = pnkrd2S84FJfN73KuiCYv(u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭ຓ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩດ")] = QYSAUI5r46yil8cfaO(u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪຕ")+str(GK0mSeb1BCXqyuUavI9zifL/V2RQwM8XjlrK(u"࠼࠰ᅎ"))+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧຖ")
	WO9ijIRZnlNPUHt = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWhcrEC1I8dxDKsTLNl6GaVQ]
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"่ࠫอิࠡࠩທ")+str(GK0mSeb1BCXqyuUavI9zifL/wYTDlJC5vpOKynUEX3ge6W(u"࠶࠱ᅏ"))+EM6qpnCBYQGA9kbgDVLfrP(u"ࠬࠦฯใ์ๅอࠬຘ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬນ"),QYSAUI5r46yil8cfaO(u"ࠧฦ์ๅหๆࠦใศ็็ࠫບ"),WO9ijIRZnlNPUHt,ynxXU3gaiQ9GPCftr1q(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫປ"))
	if OFEaiVuGrdSf20oxQl57Wp9A==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠱ᅐ"): BWithdbVQuT3AsXqeFk = FGLEMi21Bfn(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪຜ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==MzgKWUQ4V5H(u"࠳ᅑ"): BWithdbVQuT3AsXqeFk = ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡅ࡚࡚ࡏࠨຝ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠵ᅒ"): BWithdbVQuT3AsXqeFk = g7yJo2LVuqx1trPe(u"ࠫࡘ࡚ࡏࡑࠩພ")
	else: BWithdbVQuT3AsXqeFk = Vk54F7GcROfCy6HunEI
	if BWithdbVQuT3AsXqeFk:
		cad8TeSyMUYmfsEO0.setSetting(WXuJd8nz2spo146t(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫຟ"),BWithdbVQuT3AsXqeFk)
		f308WNPBr2Rae7lwA9jZS = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWithdbVQuT3AsXqeFk]
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,f308WNPBr2Rae7lwA9jZS)
	return
def bbdOMB1HQ6PIhi8yvRwCzp2JnY():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = {}
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[QYSAUI5r46yil8cfaO(u"࠭ࡁࡖࡖࡒࠫຠ")] = NNjUsZzEcFOAoKry2CDMgb1(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣห้ะไใษษ๎ࠥ๐ูๆๆ࠽ࠤࠬມ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨࡃࡖࡏࠬຢ")] = V2RQwM8XjlrK(u"ࠩึ๎ึ็ัࠡࡆࡑࡗฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊࠾ࠥ࠭ຣ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡗ࡙ࡕࡐࠨ຤")] = FGLEMi21Bfn(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧລ")
	d7THte9YuIpmfbJXNrqj = cad8TeSyMUYmfsEO0.getSetting(V2RQwM8XjlrK(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ຦"))
	BWhcrEC1I8dxDKsTLNl6GaVQ = cad8TeSyMUYmfsEO0.getSetting(WCPwmyVsb62KRlo(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩວ"))
	WO9ijIRZnlNPUHt = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWhcrEC1I8dxDKsTLNl6GaVQ]+d7THte9YuIpmfbJXNrqj
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬຨ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧຩ"),WCPwmyVsb62KRlo(u"ࠩศ๎็อแࠡๅส้้࠭ສ"),WO9ijIRZnlNPUHt,QYSAUI5r46yil8cfaO(u"ࠪื๏ืแาࠢࡇࡒࡘࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯ๊ࠦใ๊่ࠤอะอ้์็ࠤศูๅศรࠣห้๋่ศไ฼ࠤํอไิ์ิๅึอสࠡว็ํࠥษัใษ่ࠤํ฿ๆะࠢห฽฻ࠦวๅ่สืࠥ๐โ้็ࠣฬาาศ๊่๊ࠡ฾่ࠦฮุิࠤอ฿ึࠡษ็้ํอโฺࠢ࠱ࠤ้ะิ฻์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠠใ็ࠣฬฬิส๋ษิࠤฬ๊ำ๋ำไีࠥอไๆ่สือࠦร้ࠢๅ้ࠥฮล๋ไสๅ์ࠦศศๆๆห๊๊ࠧຫ"))
	if OFEaiVuGrdSf20oxQl57Wp9A==WCPwmyVsb62KRlo(u"࠴ᅓ"): BWithdbVQuT3AsXqeFk = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫࡆ࡙ࡋࠨຬ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠶ᅔ"): BWithdbVQuT3AsXqeFk = QYSAUI5r46yil8cfaO(u"ࠬࡇࡕࡕࡑࠪອ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==V2RQwM8XjlrK(u"࠸ᅕ"): BWithdbVQuT3AsXqeFk = ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡓࡕࡑࡓࠫຮ")
	if OFEaiVuGrdSf20oxQl57Wp9A in [MzgKWUQ4V5H(u"࠱ᅗ"),jXWzIZcDva4ikEUfN(u"࠱ᅖ")]:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(jXWzIZcDva4ikEUfN(u"ࠧࡤࡧࡱࡸࡪࡸࠧຯ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨีํีๆื࠺ࠡࠩະ")+h9zFQKnsNL.DNS_SERVERS[pwxH3oREFm5v98BCZ1QVtzMJOc],cpHxZyU7vTtqmIw(u"ࠩึ๎ึ็ั࠻ࠢࠪັ")+h9zFQKnsNL.DNS_SERVERS[ufmXvxgoHGDwZtjsLkR05i],Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩາ"))
		if W8j2OheqsroDJIYzRupt6nG==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠳ᅘ"): lW0D19hzG78veAdF4fXT = h9zFQKnsNL.DNS_SERVERS[ufmXvxgoHGDwZtjsLkR05i]
		else: lW0D19hzG78veAdF4fXT = h9zFQKnsNL.DNS_SERVERS[pwxH3oREFm5v98BCZ1QVtzMJOc]
	elif OFEaiVuGrdSf20oxQl57Wp9A==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠵ᅙ"): lW0D19hzG78veAdF4fXT = Vk54F7GcROfCy6HunEI
	else: BWithdbVQuT3AsXqeFk = Vk54F7GcROfCy6HunEI
	if BWithdbVQuT3AsXqeFk:
		cad8TeSyMUYmfsEO0.setSetting(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧຳ"),BWithdbVQuT3AsXqeFk)
		cad8TeSyMUYmfsEO0.setSetting(WsklGNp2CYzVQUag(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬິ"),lW0D19hzG78veAdF4fXT)
		f308WNPBr2Rae7lwA9jZS = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWithdbVQuT3AsXqeFk]+lW0D19hzG78veAdF4fXT
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,f308WNPBr2Rae7lwA9jZS)
	return
def fNMCHET8dOcDt5X():
	BWhcrEC1I8dxDKsTLNl6GaVQ = cad8TeSyMUYmfsEO0.getSetting(ESXZrtnCfcDJGo01vFg(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫີ"))
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = {}
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡂࡗࡗࡓࠬຶ")] = kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨษ็ฬึ๎ใิ์ࠣห้ะไใษษ๎ࠥาว่ิ่้ࠣ฿ๅๅࠩື")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[MpJ8GOKoic(u"ࠩࡄࡗࡐຸ࠭")] = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪห้ฮั้ๅึ๎ฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊ູࠫ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW[V2RQwM8XjlrK(u"ࠫࡘ࡚ࡏࡑ຺ࠩ")] = ynxXU3gaiQ9GPCftr1q(u"ࠬอไษำ๋็ุ๐ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧົ")
	WO9ijIRZnlNPUHt = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWhcrEC1I8dxDKsTLNl6GaVQ]
	OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(Vk54F7GcROfCy6HunEI,wYTDlJC5vpOKynUEX3ge6W(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫຼ"),ynxXU3gaiQ9GPCftr1q(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ຽ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨวํๆฬ็ࠠไษ่่ࠬ຾"),WO9ijIRZnlNPUHt,ESXZrtnCfcDJGo01vFg(u"ࠩส่อื่ไีํࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏฿ๅๅ๋ࠢื๏฽ࠠษ์้ࠤัํวำๅࠣ์ฬ๊ล็ฬิ๊๏ะࠠ࠯๊ࠢ์ࠥ๐ำหๆ่ࠤ฼๊ศศฬๆࠤํ๐โ้็ࠣฬุำศ่ษࠣฬิ๊วࠡ็้็ࠥัๅࠡ์ห฽ะํวࠡๆๆࠤ࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎้ࠦรๆࠢศ๎็อแࠡษ็ฬึ๎ใิ์ࠣรࠬ຿"))
	if OFEaiVuGrdSf20oxQl57Wp9A==HOxJyt7l8osNeCjZFMQGi4Sr(u"࠴ᅚ"): BWithdbVQuT3AsXqeFk = V2RQwM8XjlrK(u"ࠪࡅࡘࡑࠧເ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==wAU9jKvmTM0(u"࠶ᅛ"): BWithdbVQuT3AsXqeFk = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡆ࡛ࡔࡐࠩແ")
	elif OFEaiVuGrdSf20oxQl57Wp9A==wAU9jKvmTM0(u"࠸ᅜ"): BWithdbVQuT3AsXqeFk = wYTDlJC5vpOKynUEX3ge6W(u"࡙ࠬࡔࡐࡒࠪໂ")
	else: BWithdbVQuT3AsXqeFk = Vk54F7GcROfCy6HunEI
	if BWithdbVQuT3AsXqeFk:
		cad8TeSyMUYmfsEO0.setSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫໃ"),BWithdbVQuT3AsXqeFk)
		f308WNPBr2Rae7lwA9jZS = BadMOTrh9Lnp0w6KZCQASE4uyk7fW[BWithdbVQuT3AsXqeFk]
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,f308WNPBr2Rae7lwA9jZS)
	return
def A9jfXnvEkM1LFrW4yc8Iwp():
	KOVjGL7w0Iydxo5abqZ2JYXC = cad8TeSyMUYmfsEO0.getSetting(jXWzIZcDva4ikEUfN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧໄ"))
	if KOVjGL7w0Iydxo5abqZ2JYXC==BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡕࡗࡓࡕ࠭໅"): header = wAU9jKvmTM0(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨໆ")
	else: header = g7yJo2LVuqx1trPe(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨ໇")
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,g7yJo2LVuqx1trPe(u"ࠫส๐โศใ່ࠪ"),jXWzIZcDva4ikEUfN(u"ࠬะแฺ์็້ࠫ"),header,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟ໊ࠢࠣࠪ"))
	if W8j2OheqsroDJIYzRupt6nG==-BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠱ᅝ"): return
	elif W8j2OheqsroDJIYzRupt6nG:
		cad8TeSyMUYmfsEO0.setSetting(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫໋ࠧ"),WCPwmyVsb62KRlo(u"ࠨࡃࡘࡘࡔ࠭໌"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬໍ"),pnkrd2S84FJfN73KuiCYv(u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬ໎"))
	else:
		cad8TeSyMUYmfsEO0.setSetting(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫ໏"),WsklGNp2CYzVQUag(u"࡙ࠬࡔࡐࡒࠪ໐"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ໑"),MpJ8GOKoic(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩ໒"))
	return
def vKOw7TQipRgVJ2uj6L(YWCso5NMKO):
	if YWCso5NMKO!=Vk54F7GcROfCy6HunEI:
		YWCso5NMKO = YqgcrtzU8LVNymnp3Z(YWCso5NMKO)
		YWCso5NMKO = YWCso5NMKO.decode(AoCWwJHgUPKXI7u2lEzym).encode(AoCWwJHgUPKXI7u2lEzym)
		hyq03oZSn19MGz5VLtr = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠲࠲࠴࠴࠸ᅞ")
		x8oRkwze61WhbGPLD5 = SZDFRGim3j8L.Window(hyq03oZSn19MGz5VLtr)
		x8oRkwze61WhbGPLD5.getControl(SSBkx0WbN1asnDCQV6tIj(u"࠵࠴࠵ᅟ")).setLabel(YWCso5NMKO)
	return
Cx64eJT9AEcPg7 = [
			 HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨ໓")
			,cpHxZyU7vTtqmIw(u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬ໔")
			,V2RQwM8XjlrK(u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬ໕")
			,QYSAUI5r46yil8cfaO(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭໖")
			,YzowicIDTRusXZSU61(u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭໗")
			,WCPwmyVsb62KRlo(u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨ໘")
			,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱ࠭໙")+WsklGNp2CYzVQUag(u"ࠨࠥࠪ໚")+QYSAUI5r46yil8cfaO(u"ࠩࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨ໛")
			,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭ໜ")
			,FGLEMi21Bfn(u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡩࡂ࠶ࠦࡵࡧࡻࡸࡹࡃࠧໝ")
			,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭ໞ")
			,g7yJo2LVuqx1trPe(u"࠭࡞࡟ࡠࡡࡢࠬໟ")
			,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬ໠")
			,XCYALgFs2O3hZdpHrlMmB(u"ࠨ࡮ࡤࡶ࡬࡫ࠠࡢࡷࡧ࡭ࡴࠦࡳࡺࡰࡦࠤࡪࡸࡲࡰࡴ࠽ࠫ໡")
			]
def WWQutXyP9HJCvTl5Owf(bBpKQ53S0agq6lRw1):
	if kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧ໢") in bBpKQ53S0agq6lRw1 and EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ໣") in bBpKQ53S0agq6lRw1: return YOHXqtbQTBfKerIZ
	for YWCso5NMKO in Cx64eJT9AEcPg7:
		if YWCso5NMKO in bBpKQ53S0agq6lRw1: return YOHXqtbQTBfKerIZ
	return eu1NswY9zkKC60I
def s93IyLFvSeCNOYK0xpk(data):
	f3CgQWX0eYbOwxM9NdnoKRzSA1 = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠻ᅡ") if PvwFsJK23NbU8XWAx else kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠴࠹ᅠ")
	data = data.replace(WCPwmyVsb62KRlo(u"࠸࠶ᅢ")*otBWsSAfu7dihVkP9e1JFKrvmYy2Q,f3CgQWX0eYbOwxM9NdnoKRzSA1*otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	data = data.replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࠥࡂࡧࡦࡰࡨࡶࡦࡲ࠾࠻ࠢࠪ໤"),MpJ8GOKoic(u"ࠬࡀࠠࠨ໥"))
	zWochUpvu80mn5 = Vk54F7GcROfCy6HunEI
	for bBpKQ53S0agq6lRw1 in data.splitlines():
		U9ahP7fe4y1XNr8IkGHconE = RSuYINdeamsK0t.findall(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠬ࠳࠰࠿ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠯ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ໦"),bBpKQ53S0agq6lRw1,RSuYINdeamsK0t.DOTALL)
		if U9ahP7fe4y1XNr8IkGHconE: bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(U9ahP7fe4y1XNr8IkGHconE[ufmXvxgoHGDwZtjsLkR05i],Vk54F7GcROfCy6HunEI)
		zWochUpvu80mn5 += ixrPWKeFMnqJyVodX6D9AaO2+bBpKQ53S0agq6lRw1
	return zWochUpvu80mn5
def i6Owafmbkvu0cLzTteX(vv2TScCAuqQPstM3):
	if V2RQwM8XjlrK(u"ࠧࡐࡎࡇࠫ໧") in vv2TScCAuqQPstM3:
		nFZ8LMesz0rXmxTG5H = DbAmP8JkBMXZciCI9nT
		header = wYTDlJC5vpOKynUEX3ge6W(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ໨")
	else:
		nFZ8LMesz0rXmxTG5H = uta6N9f2PIW8e
		header = wYTDlJC5vpOKynUEX3ge6W(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ໩")
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,header,V2RQwM8XjlrK(u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭໪"))
	if W8j2OheqsroDJIYzRupt6nG!=QYSAUI5r46yil8cfaO(u"࠷ᅣ"): return
	ADjbthgpFqoyYa6vfS21cOL,RRQ2wKuh8BJfde0Zr = [],kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠰ᅤ")
	size,count = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(nFZ8LMesz0rXmxTG5H)
	file = open(nFZ8LMesz0rXmxTG5H,WXuJd8nz2spo146t(u"ࠫࡷࡨࠧ໫"))
	if size>V2RQwM8XjlrK(u"࠳࠳࠴࠷࠶࠰ᅦ"): file.seek(-Nlyfx1HnzOWCovke5(u"࠲࠲࠳࠵࠵࠶ᅥ"),CR3aLOVKSIme5XFoYi6M.SEEK_END)
	data = file.read()
	file.close()
	if PvwFsJK23NbU8XWAx: data = data.decode(AoCWwJHgUPKXI7u2lEzym)
	data = s93IyLFvSeCNOYK0xpk(data)
	nsiJk9RY6DLarMI = data.split(ixrPWKeFMnqJyVodX6D9AaO2)
	for bBpKQ53S0agq6lRw1 in reversed(nsiJk9RY6DLarMI):
		Tswla1yW7AZqLXuzghRK4F = WWQutXyP9HJCvTl5Owf(bBpKQ53S0agq6lRw1)
		if Tswla1yW7AZqLXuzghRK4F: continue
		bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(V2RQwM8XjlrK(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡥࠧ໬"),d761ZWXHEvliYN45RzLP2+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ໭")+ZZoLlKyInXc08j2pTGJ)
		bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡆࡔࡕࡓࡗࡀࠧ໮"),wYTDlJC5vpOKynUEX3ge6W(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋ࠶࠰࠱࠲ࡠࠫ໯")+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ໰")+ZZoLlKyInXc08j2pTGJ)
		G57Mfhk8QgB = Vk54F7GcROfCy6HunEI
		eWoKONvVRZqgUuidGLS = RSuYINdeamsK0t.findall(ynxXU3gaiQ9GPCftr1q(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ໱"),bBpKQ53S0agq6lRw1,RSuYINdeamsK0t.DOTALL)
		if eWoKONvVRZqgUuidGLS:
			bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i],eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]).replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][RXnhpCUk4M1TvgJE],Vk54F7GcROfCy6HunEI)
			G57Mfhk8QgB = eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]
		else:
			eWoKONvVRZqgUuidGLS = RSuYINdeamsK0t.findall(jXWzIZcDva4ikEUfN(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ໲"),bBpKQ53S0agq6lRw1,RSuYINdeamsK0t.DOTALL)
			if eWoKONvVRZqgUuidGLS:
				bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc],Vk54F7GcROfCy6HunEI)
				G57Mfhk8QgB = eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i]
		if G57Mfhk8QgB: bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(G57Mfhk8QgB,nMt0iueCy6K+G57Mfhk8QgB+ZZoLlKyInXc08j2pTGJ)
		ADjbthgpFqoyYa6vfS21cOL.append(bBpKQ53S0agq6lRw1)
		if len(str(ADjbthgpFqoyYa6vfS21cOL))>SSBkx0WbN1asnDCQV6tIj(u"࠸࠴࠶࠶࠰ᅧ"): break
	ADjbthgpFqoyYa6vfS21cOL = reversed(ADjbthgpFqoyYa6vfS21cOL)
	nHSaZ82AXCRjcBTLVxYG9Mf = ixrPWKeFMnqJyVodX6D9AaO2.join(ADjbthgpFqoyYa6vfS21cOL)
	aaNxZcCAYds8FEjDqzgBhK4(V2RQwM8XjlrK(u"ࠬࡲࡥࡧࡶࠪ໳"),WXuJd8nz2spo146t(u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪ໴"),nHSaZ82AXCRjcBTLVxYG9Mf,YzowicIDTRusXZSU61(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ໵"))
	return
def ATQXCtyENu2Si4p():
	AAwiO741aVRoFDeWzNm0sTEYc = open(BLfQzvAhUyYdas4wHCPrbEXZkgn6J,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡴࡥࠫ໶")).read()
	if PvwFsJK23NbU8XWAx: AAwiO741aVRoFDeWzNm0sTEYc = AAwiO741aVRoFDeWzNm0sTEYc.decode(AoCWwJHgUPKXI7u2lEzym)
	AAwiO741aVRoFDeWzNm0sTEYc = AAwiO741aVRoFDeWzNm0sTEYc.replace(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡟ࡸࠬ໷"),SSBkx0WbN1asnDCQV6tIj(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬ໸"))
	rUWTIdPJlh4uNp2w = RSuYINdeamsK0t.findall(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ໹"),AAwiO741aVRoFDeWzNm0sTEYc,RSuYINdeamsK0t.DOTALL)
	for bBpKQ53S0agq6lRw1 in rUWTIdPJlh4uNp2w:
		AAwiO741aVRoFDeWzNm0sTEYc = AAwiO741aVRoFDeWzNm0sTEYc.replace(bBpKQ53S0agq6lRw1,d761ZWXHEvliYN45RzLP2+bBpKQ53S0agq6lRw1+ZZoLlKyInXc08j2pTGJ)
	JJWH15tngbuPBpId(MzgKWUQ4V5H(u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭໺"),AAwiO741aVRoFDeWzNm0sTEYc)
	return
def Bbu2wWZCF8yir3HcY0RnDTQl():
	burCKRDXAy9jY = ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ໻")
	eeHAfglvTVoC0QE = XCYALgFs2O3hZdpHrlMmB(u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ໼")
	YtHmu8d3UpLj7XA = wAU9jKvmTM0(u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ໽")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = burCKRDXAy9jY+wAU9jKvmTM0(u"ࠩ࠽ࠤࠬ໾")+eeHAfglvTVoC0QE+V2RQwM8XjlrK(u"ࠪࠤ࠳ࠦࠧ໿")+YtHmu8d3UpLj7XA
	aaNxZcCAYds8FEjDqzgBhK4(XCYALgFs2O3hZdpHrlMmB(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫༀ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༁"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,ynxXU3gaiQ9GPCftr1q(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ༂"))
	return
def G5GEld8on2FIazkY(type,BadMOTrh9Lnp0w6KZCQASE4uyk7fW,showDialogs=YOHXqtbQTBfKerIZ,url=Vk54F7GcROfCy6HunEI,JlT9OB143U=Vk54F7GcROfCy6HunEI,YWCso5NMKO=Vk54F7GcROfCy6HunEI,h1hCuxyBEI=Vk54F7GcROfCy6HunEI):
	OqpWixtCwu9dV = YOHXqtbQTBfKerIZ
	if not h9zFQKnsNL.C7tWRO0bJdz3TV49j8eIklM1fDSxB:
		if showDialogs:
			uNTZUmOltaHWX15fJg34AEky = (WsklGNp2CYzVQUag(u"ࠧศๆึ฻ึࡀࠧ༃") in BadMOTrh9Lnp0w6KZCQASE4uyk7fW and SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨษ็้่อๆ࠻ࠩ༄") in BadMOTrh9Lnp0w6KZCQASE4uyk7fW and EM6qpnCBYQGA9kbgDVLfrP(u"ࠩส่๊๊แ࠻ࠩ༅") in BadMOTrh9Lnp0w6KZCQASE4uyk7fW and ESXZrtnCfcDJGo01vFg(u"ࠪห้ิืฤࠩ༆") in BadMOTrh9Lnp0w6KZCQASE4uyk7fW and ESXZrtnCfcDJGo01vFg(u"ࠫฬ๊ๅึัิ࠾ࠬ༇") in BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
			if not uNTZUmOltaHWX15fJg34AEky: OqpWixtCwu9dV = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(g7yJo2LVuqx1trPe(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ༈"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ༉"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW.replace(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡝࡞ࡱࠫ༊"),ixrPWKeFMnqJyVodX6D9AaO2))
	elif showDialogs:
		BadMOTrh9Lnp0w6KZCQASE4uyk7fW = WsklGNp2CYzVQUag(u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨ་")
		WW3u4Fgc0q = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(WCPwmyVsb62KRlo(u"ࠩࡦࡩࡳࡺࡥࡳࠩ༌"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ།")+FGLEMi21Bfn(u"ࠫࠥࠦ࠱࠰࠷ࠪ༎"),XCYALgFs2O3hZdpHrlMmB(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ༏"))
		G4MJRxbgr9z = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༐"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ༑")+EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࠢࠣ࠶࠴࠻ࠧ༒"),FGLEMi21Bfn(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ༓"))
		XX5OrHsaZz = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(YzowicIDTRusXZSU61(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༔"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ༕")+XCYALgFs2O3hZdpHrlMmB(u"ࠬࠦࠠ࠴࠱࠸ࠫ༖"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ༗"))
		Ddo3QyHcOmhN6jx5aRg7MS4F = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(MzgKWUQ4V5H(u"ࠧࡤࡧࡱࡸࡪࡸ༘ࠧ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ༙")+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࠣࠤ࠹࠵࠵ࠨ༚"),WXuJd8nz2spo146t(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ༛"))
		OqpWixtCwu9dV = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Nlyfx1HnzOWCovke5(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ༜"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ༝")+ESXZrtnCfcDJGo01vFg(u"࠭ࠠࠡ࠷࠲࠹ࠬ༞"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ༟"))
	igk6DQGT2ychz38 = cqgy5Dz7GR012EIPwVLsQ9Bnjuar(eu1NswY9zkKC60I)
	GdcxYNo1hSF3bv0MliWumE = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࡃ࡙࠾ࠥ࠭༠")+igk6DQGT2ychz38+V2RQwM8XjlrK(u"ࠩ࠰ࠫ༡")+type
	SePcIk2NxaEw9D47RyBoUYMLgCml6 = YOHXqtbQTBfKerIZ if BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭༢") in YWCso5NMKO else eu1NswY9zkKC60I
	if not OqpWixtCwu9dV:
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༣"),V2RQwM8XjlrK(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ༤"))
		return eu1NswY9zkKC60I
	sgx0B8wKYFt7vyWUSNXhRd = J2L6to3R1Z.getInfoLabel(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ༥"))
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += YzowicIDTRusXZSU61(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭༦")+ZIxrV4Lbw6jTqKMNpUWo0Hh7QOJk+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࠢ࠽ࡠࡡࡴࠧ༧")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪ༨")+igk6DQGT2ychz38+g7yJo2LVuqx1trPe(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ༩")+QXxcFjsL4MB09+WsklGNp2CYzVQUag(u"ࠫࠥࡀ࡜࡝ࡰࠪ༪")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += QYSAUI5r46yil8cfaO(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪ༫")+sgx0B8wKYFt7vyWUSNXhRd
	UrKfGLt0hSOQpT6wMV1oN = aEAZWIlr32Q5z1ufmRqUX6MFS98sP()
	UrKfGLt0hSOQpT6wMV1oN = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(UrKfGLt0hSOQpT6wMV1oN)
	if UrKfGLt0hSOQpT6wMV1oN: BadMOTrh9Lnp0w6KZCQASE4uyk7fW += SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨ༬")+UrKfGLt0hSOQpT6wMV1oN
	if url: BadMOTrh9Lnp0w6KZCQASE4uyk7fW += EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫ༭")+url
	if JlT9OB143U: BadMOTrh9Lnp0w6KZCQASE4uyk7fW += BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨ༮")+JlT9OB143U
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += WsklGNp2CYzVQUag(u"ࠩࠣ࠾ࡡࡢ࡮ࠨ༯")
	if showDialogs: qJAOp7HgfKeMQkDau(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩ༰"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭༱"))
	if h1hCuxyBEI:
		nHSaZ82AXCRjcBTLVxYG9Mf = h1hCuxyBEI
		if PvwFsJK23NbU8XWAx: nHSaZ82AXCRjcBTLVxYG9Mf = nHSaZ82AXCRjcBTLVxYG9Mf.encode(AoCWwJHgUPKXI7u2lEzym)
		nHSaZ82AXCRjcBTLVxYG9Mf = PnRA5dpzE18JU.b64encode(nHSaZ82AXCRjcBTLVxYG9Mf)
	elif SePcIk2NxaEw9D47RyBoUYMLgCml6:
		if MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬ༲") in YWCso5NMKO: ccGLlYsNbATOi82U1kWxR7J = DbAmP8JkBMXZciCI9nT
		else: ccGLlYsNbATOi82U1kWxR7J = uta6N9f2PIW8e
		if not CR3aLOVKSIme5XFoYi6M.path.exists(ccGLlYsNbATOi82U1kWxR7J):
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ༳"),eAMGzHRQVs2KyCwPXljYhB(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬ༴"))
			return eu1NswY9zkKC60I
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨ࠰࡟ࡸࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡪࡴࡤࠡࡶ࡫ࡩࠥࡲ࡯ࡨࡨ࡬ࡰࡪ༵࠭"))
		ADjbthgpFqoyYa6vfS21cOL,RRQ2wKuh8BJfde0Zr = [],ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠴ᅨ")
		file = open(ccGLlYsNbATOi82U1kWxR7J,NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡵࡦࠬ༶"))
		size,count = xUAYwuFSIJo2h7g0NXCetMiTydZVk6(ccGLlYsNbATOi82U1kWxR7J)
		if size>QYSAUI5r46yil8cfaO(u"࠸࠶࠱࠱࠲࠳ᅩ"): file.seek(-QYSAUI5r46yil8cfaO(u"࠸࠶࠱࠱࠲࠳ᅩ"),CR3aLOVKSIme5XFoYi6M.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(AoCWwJHgUPKXI7u2lEzym)
		data = s93IyLFvSeCNOYK0xpk(data)
		nsiJk9RY6DLarMI = data.splitlines()
		for bBpKQ53S0agq6lRw1 in reversed(nsiJk9RY6DLarMI):
			Tswla1yW7AZqLXuzghRK4F = WWQutXyP9HJCvTl5Owf(bBpKQ53S0agq6lRw1)
			if Tswla1yW7AZqLXuzghRK4F: continue
			eWoKONvVRZqgUuidGLS = RSuYINdeamsK0t.findall(eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤ༷ࠬࠫࠪ"),bBpKQ53S0agq6lRw1,RSuYINdeamsK0t.DOTALL)
			if eWoKONvVRZqgUuidGLS:
				bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][ufmXvxgoHGDwZtjsLkR05i],eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc]).replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][RXnhpCUk4M1TvgJE],Vk54F7GcROfCy6HunEI)
			else:
				eWoKONvVRZqgUuidGLS = RSuYINdeamsK0t.findall(YzowicIDTRusXZSU61(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ༸"),bBpKQ53S0agq6lRw1,RSuYINdeamsK0t.DOTALL)
				if eWoKONvVRZqgUuidGLS: bBpKQ53S0agq6lRw1 = bBpKQ53S0agq6lRw1.replace(eWoKONvVRZqgUuidGLS[ufmXvxgoHGDwZtjsLkR05i][pwxH3oREFm5v98BCZ1QVtzMJOc],Vk54F7GcROfCy6HunEI)
			ADjbthgpFqoyYa6vfS21cOL.append(bBpKQ53S0agq6lRw1)
			if len(str(ADjbthgpFqoyYa6vfS21cOL))>WXuJd8nz2spo146t(u"࠸࠵࠲࠲࠳࠴ᅪ"): break
		ADjbthgpFqoyYa6vfS21cOL = reversed(ADjbthgpFqoyYa6vfS21cOL)
		nHSaZ82AXCRjcBTLVxYG9Mf = WCPwmyVsb62KRlo(u"ࠬࡢࡲ࡝ࡰ༹ࠪ").join(ADjbthgpFqoyYa6vfS21cOL)
		nHSaZ82AXCRjcBTLVxYG9Mf = nHSaZ82AXCRjcBTLVxYG9Mf.encode(AoCWwJHgUPKXI7u2lEzym)
		nHSaZ82AXCRjcBTLVxYG9Mf = PnRA5dpzE18JU.b64encode(nHSaZ82AXCRjcBTLVxYG9Mf)
	else: nHSaZ82AXCRjcBTLVxYG9Mf = Vk54F7GcROfCy6HunEI
	url = h9zFQKnsNL.SITESURLS[ESXZrtnCfcDJGo01vFg(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭༺")][RXnhpCUk4M1TvgJE]
	k8NxAwnQI2FzZCyJYthpaVubLscq = {FGLEMi21Bfn(u"ࠧࡴࡷࡥ࡮ࡪࡩࡴࠨ༻"):GdcxYNo1hSF3bv0MliWumE,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ༼"):BadMOTrh9Lnp0w6KZCQASE4uyk7fW,eAMGzHRQVs2KyCwPXljYhB(u"ࠩ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪ༽"):nHSaZ82AXCRjcBTLVxYG9Mf}
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,V2RQwM8XjlrK(u"ࠪࡔࡔ࡙ࡔࠨ༾"),url,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,NNjUsZzEcFOAoKry2CDMgb1(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ༿"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if SSBkx0WbN1asnDCQV6tIj(u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧཀ") in FjwObZSWkg8ahBdiQf9IeY135DpXoP: kNQM9jAU6TVlhezn14cKtBb = YOHXqtbQTBfKerIZ
	else: kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
	if showDialogs:
		if kNQM9jAU6TVlhezn14cKtBb:
			qJAOp7HgfKeMQkDau(WCPwmyVsb62KRlo(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩཁ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡔࡷࡦࡧࡪࡹࡳࠨག"))
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠧགྷ"),SSBkx0WbN1asnDCQV6tIj(u"ࠩอ้ࠥหัิษ็ࠤฬ๊ัิษ็อࠥฮๆอษะࠫང"))
		else:
			qJAOp7HgfKeMQkDau(MpJ8GOKoic(u"่้ࠪษำโࠢไุ้ࠦวๅวิืฬ๊ࠧཅ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡋࡧࡩ࡭ࡷࡵࡩࠬཆ"))
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,QYSAUI5r46yil8cfaO(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨཇ"),ynxXU3gaiQ9GPCftr1q(u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫ཈"))
	return kNQM9jAU6TVlhezn14cKtBb
def hF57XKjDTlsMtU9():
	burCKRDXAy9jY = MpJ8GOKoic(u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠤࡲ࡫࡮ࡶࠢ࡬ࡸࡪࡳࡳࠡࡶࡲࠤࡦࠦ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠡࡱࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡇࡲࡢࡤ࡬ࡧࠥ࠴࠮ࠡࡑࡵࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡶ࡬ࡴࡽࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡺࡥࡹࡶࠣࡃࠦ࠭ཉ")
	eeHAfglvTVoC0QE = MpJ8GOKoic(u"ࠨ้็ࠤฯื๊ะࠢอีั๋ษࠡไ๋หห๋ࠠศๆหี๋อๅอࠢศ่๎ࠦไ฻หࠣวำื้ࠡ฼ํีࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษ฽ํวาࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอࠥลࠡࠨཊ")
	AeKozZdVLvk4GHJ65YUatyFDRi = rAdiM2DVzBuxjPvYFTQs(cpHxZyU7vTtqmIw(u"ࠩࡦࡩࡳࡺࡥࡳࠩཋ"),ESXZrtnCfcDJGo01vFg(u"ࠪาึ๎ฬࠡࡇࡻ࡭ࡹ࠭ཌ"),YzowicIDTRusXZSU61(u"࡙ࠫࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠠหำฯ้ฮ࠭ཌྷ"),g7yJo2LVuqx1trPe(u"ࠬ฿ัษ์ࠣࡅࡷࡧࡢࡪࡥࠪཎ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཏ"),burCKRDXAy9jY+XCYALgFs2O3hZdpHrlMmB(u"ࠧ࡝ࡰ࡟ࡲࠬཐ")+eeHAfglvTVoC0QE)
	if AeKozZdVLvk4GHJ65YUatyFDRi in [-wYTDlJC5vpOKynUEX3ge6W(u"࠱ᅫ"),WsklGNp2CYzVQUag(u"࠱ᅬ")]: return
	elif AeKozZdVLvk4GHJ65YUatyFDRi==Nlyfx1HnzOWCovke5(u"࠳ᅭ"):
		import GBPlghkIE8
		GBPlghkIE8.hweyCxfXSFTLOMt5NHzVgqrjo4I()
		return
	U6xTn2ENzSkKPqsHrtL0 = YOHXqtbQTBfKerIZ
	while U6xTn2ENzSkKPqsHrtL0:
		U6xTn2ENzSkKPqsHrtL0 = eu1NswY9zkKC60I
		message = V2RQwM8XjlrK(u"ࠨวำหࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฤฯิๅࠥอไฺำห๎ฮࠦแศา๊ฬࠥหไ๊ࠢࠥษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠣࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆเ๊าࠢส่ั๊ฯࠡว็ํࠥษ๊ࠡฮ็ำࠥัว็์ࠣๅ๏ํࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࠮࠯ࠢฮ้ࠥฮูะ้สࠤ฿๐ัࠡษ็า฼ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠤࡡࡴࠠฦาสࠤ้๎อสࠢส่๊็วห์ะࠤฬู๊าสํอ๊ࠥวࠡฬ฻๋ึࠦไไࠢ࠱࠲ࠥอะ่สࠣษ้๏ࠠࠣว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠨࠠ࠯࠰ࠣฯฺ๊๋ࠦำࠣษ฾ีวะษอࠤฬ๊ๅ้ไ฼ࠤฬ๊ฬ฻ำสๅ๏ࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥอไร่ࠣๅฯำࠠࠣว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠨࠠภࠣࠪད")
		AeKozZdVLvk4GHJ65YUatyFDRi = rAdiM2DVzBuxjPvYFTQs(YzowicIDTRusXZSU61(u"ࠩࡦࡩࡳࡺࡥࡳࠩདྷ"),ESXZrtnCfcDJGo01vFg(u"ࠪࡉࡽ࡯ࡴࠡะิ์ั࠭ན"),SSBkx0WbN1asnDCQV6tIj(u"ࠫ࡞࡫ࡳ่ࠡ฼้ࠬཔ"),MzgKWUQ4V5H(u"ࠬࡋ࡮ࡨ࡮࡬ࡷ࡭ࠦล็ฮ็๎ื๐ࠧཕ"),WXuJd8nz2spo146t(u"ู࠭ะ็ࠣ฼์๎ัࠡษ็วาืแ๊ࠡส่่ะวษหࠣห้฿ัษ์ฬࠫབ"),message,profile=ESXZrtnCfcDJGo01vFg(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬབྷ"))
		if AeKozZdVLvk4GHJ65YUatyFDRi==SSBkx0WbN1asnDCQV6tIj(u"࠵ᅮ"):
			message = V2RQwM8XjlrK(u"ࠨࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡰࡳࡱࡥࡰࡪࡳࠠࡸ࡫ࡷ࡬ࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡴࡩࡧࡱࠤࡴࡶࡥ࡯ࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡣࡢࡰ࡟ࠫࡹࠦࡦࡪࡰࡧࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࡬࡯࡯ࡶࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡹ࡫ࡪࡰࠣࡸࡴࠦࡡ࡯ࡻࠣࡳࡹ࡮ࡥࡳࠢࡶ࡯࡮ࡴࠠࡵࡪࡤࡸࠥ࡮ࡡࡷࡧࠣࡠࠧࡇࡲࡪࡣ࡯ࡠࠧࠦࡦࡰࡰࡷࠤ࠳࠴ࠠࡂࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤࡎ࡬ࠠࡂࡴࡤࡦ࡮ࡩࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥ࠴࠮ࠡࡖ࡫ࡩࡳࠦ࡯ࡱࡧࡱࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡶࡪ࡭ࡩࡰࡰࡤࡰࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠ࡝ࡰ࡟ࡲࠥࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡲࡴࡽࠠࡵࡱࠣࡳࡵ࡫࡮ࠡࡶ࡫ࡩࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡃࠦ࠭མ")
			AeKozZdVLvk4GHJ65YUatyFDRi = rAdiM2DVzBuxjPvYFTQs(wAU9jKvmTM0(u"ࠩࡦࡩࡳࡺࡥࡳࠩཙ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡉࡽ࡯ࡴࠡะิ์ั࠭ཚ"),g7yJo2LVuqx1trPe(u"ࠫ࡞࡫ࡳ่ࠡ฼้ࠬཛ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥ฿ัษ์ࠪཛྷ"),EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡂࡴࡤࡦ࡮ࡩࠠࡇࡱࡱࡸࠥࠬࠠࡕࡧࡻࡸࠬཝ"),message,profile=eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬཞ"))
			if AeKozZdVLvk4GHJ65YUatyFDRi==cpHxZyU7vTtqmIw(u"࠶ᅯ"): U6xTn2ENzSkKPqsHrtL0 = YOHXqtbQTBfKerIZ
		if AeKozZdVLvk4GHJ65YUatyFDRi==EM6qpnCBYQGA9kbgDVLfrP(u"࠶ᅰ"): pAUuvy2wzOYfkItGqShabx()
	return
def VvrfA1eNnPt6Om():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫཟ"),g7yJo2LVuqx1trPe(u"ࠩ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬ๊ࠡ็่ฯษใะࠢๅ้ࠥฮสี฼ํ่ࠥอไาษห฻ࠥอไั์่ࠣฬฺ๊ࠦ็็ࠤะ๋ࠠใ็ࠣฬสืำศๆู้้ࠣไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣห้่วว็ฬࠤฬ๊ัว์ึ๎ฮࠦไๅสิ๊ฬ๋ฬࠨའ"))
	return
def pnuKhFTvJr4dIHPemgsj():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = wAU9jKvmTM0(u"๋ࠪีอࠠศๆหี๋อๅอ่ࠢาฺ฻ࠠโไฺࠤฺ้๊สࠢส่฾ืศ๋หࠣ์้้ๆ้ࠡำห๊ࠥวࠡ์่๊฾่ࠦอ๊าࠤ๊๎วใ฻ࠣๅ๏ํวࠡลไ่ฬ๋้ࠠ็ึุ่๊วห่ࠢฮึาๅสࠢฦ์๋ࠥฯษๆฯอࠥหไ๊ࠢส่้เษࠡษ็฽ึฮ๊ส๋ࠢห้๏ࠠๅ฼สฮࠥอฮา๋ࠣ์้อ๋๊ࠠฯำูࠥศษࠢ็่ฯ้ัศำࠪཡ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧར"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def bN6okKjryIDtPXHQ():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = XCYALgFs2O3hZdpHrlMmB(u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩལ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཤ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def bRYCa1p64ZTJrSG():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫཥ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫས"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫཧ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def mrvj2l1W3VUGI6hg():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = Nlyfx1HnzOWCovke5(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨཨ")
	aaNxZcCAYds8FEjDqzgBhK4(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫཀྵ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨཪ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩཫ"))
	return
def PpBHNMzFGh9ORmSl2U3():
	burCKRDXAy9jY = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨཬ")
	eeHAfglvTVoC0QE = g7yJo2LVuqx1trPe(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪ཭")
	YtHmu8d3UpLj7XA = XCYALgFs2O3hZdpHrlMmB(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ཮")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭཯"),burCKRDXAy9jY,eeHAfglvTVoC0QE,YtHmu8d3UpLj7XA)
	return
def ccUmXov1LtjWkps6D7l3gx2z():
	eeHAfglvTVoC0QE = BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬ཰")
	eeHAfglvTVoC0QE += BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬࡢ࡮࡝ࡰཱࠪ") + V2RQwM8XjlrK(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤིࠬ") + str(piwNWcJEe9m/wAU9jKvmTM0(u"࠼࠰ᅱ")/wAU9jKvmTM0(u"࠼࠰ᅱ")/ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠲࠵ᅲ")/Nlyfx1HnzOWCovke5(u"࠴࠲ᅳ")) + MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠧࠡึ๊ีཱིࠬ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + YzowicIDTRusXZSU61(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ུࠦࠧ") + str(mXdxepDh683FuUKlb0/XCYALgFs2O3hZdpHrlMmB(u"࠸࠳ᅴ")/XCYALgFs2O3hZdpHrlMmB(u"࠸࠳ᅴ")/EM6qpnCBYQGA9kbgDVLfrP(u"࠵࠸ᅵ")) + SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠩࠣ๎ํ๋ཱུࠧ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + WsklGNp2CYzVQUag(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧྲྀ") + str(sT9DURSXlOybaCQ/XCYALgFs2O3hZdpHrlMmB(u"࠺࠵ᅶ")/XCYALgFs2O3hZdpHrlMmB(u"࠺࠵ᅶ")/EM6qpnCBYQGA9kbgDVLfrP(u"࠷࠺ᅷ")) + kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫࠥ๐่ๆࠩཷ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧླྀ") + str(ddQIv6q9hTce1iA0nWSX5UuLaNb/eAMGzHRQVs2KyCwPXljYhB(u"࠼࠰ᅸ")/eAMGzHRQVs2KyCwPXljYhB(u"࠼࠰ᅸ")) + g7yJo2LVuqx1trPe(u"࠭ࠠิษ฼อࠬཹ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ེࠣࠫ") + str(CnJ1ePvdKQ2R/wAU9jKvmTM0(u"࠶࠱ᅹ")/wAU9jKvmTM0(u"࠶࠱ᅹ")) + FGLEMi21Bfn(u"ࠨࠢึห฾ฯཻࠧ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + V2RQwM8XjlrK(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ོࠢࠪ") + str(HHvEOMNGCeQKIZybal7/MpJ8GOKoic(u"࠷࠲ᅺ")) + V2RQwM8XjlrK(u"ࠪࠤิ่๊ใหཽࠪ")
	eeHAfglvTVoC0QE += ixrPWKeFMnqJyVodX6D9AaO2 + kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭ཾ") + str(AOhmwtSyYBn4ZF7RuvQNU) + ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࠦฯใ์ๅอࠬཿ")
	eeHAfglvTVoC0QE += WXuJd8nz2spo146t(u"࠭࡜࡯࡞ࡱྀࠫ") + wYTDlJC5vpOKynUEX3ge6W(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษཱྀࠣࠫ") + str(ddQIv6q9hTce1iA0nWSX5UuLaNb/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")) + EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩྂ") + str(sT9DURSXlOybaCQ/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")/SSBkx0WbN1asnDCQV6tIj(u"࠵࠸ᅼ")) + g7yJo2LVuqx1trPe(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨྃ") + str(CnJ1ePvdKQ2R/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")) + jXWzIZcDva4ikEUfN(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์྄ࠦࠧ") + str(HHvEOMNGCeQKIZybal7/kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠸࠳ᅻ")) + ESXZrtnCfcDJGo01vFg(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭྅") + str(AOhmwtSyYBn4ZF7RuvQNU) + MpJ8GOKoic(u"ࠬࠦฯใ์ๅอࠬ྆")
	aaNxZcCAYds8FEjDqzgBhK4(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡲࡪࡩ࡫ࡸࠬ྇"),WsklGNp2CYzVQUag(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬྈ"),eeHAfglvTVoC0QE,SSBkx0WbN1asnDCQV6tIj(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫྉ"))
	return
def mmB9hH5Wkcz():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬྊ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྋ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def cksnWQRdq6ZXM():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = NNjUsZzEcFOAoKry2CDMgb1(u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬྌ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨྍ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def ccvpRmIn3yweJ():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = wAU9jKvmTM0(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪྎ")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྏ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def VucPRFZqU4xfgGa9owQdSBl():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྐ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧྑ"))
	hhiACvapbKSt(wYTDlJC5vpOKynUEX3ge6W(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪྒ"),YOHXqtbQTBfKerIZ)
	return
def UUR63ar4ucVZn0OPXfFkb():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW  = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭ྒྷ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬྔ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+EM6qpnCBYQGA9kbgDVLfrP(u"࠭เ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำࠪྕ")+ZZoLlKyInXc08j2pTGJ+ixrPWKeFMnqJyVodX6D9AaO2
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += NNjUsZzEcFOAoKry2CDMgb1(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧྖ")
	aaNxZcCAYds8FEjDqzgBhK4(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡴ࡬࡫࡭ࡺࠧྗ"),wYTDlJC5vpOKynUEX3ge6W(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ྘"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,ESXZrtnCfcDJGo01vFg(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ྙ"))
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = g7yJo2LVuqx1trPe(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧྚ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫྛ")+ZZoLlKyInXc08j2pTGJ
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += WCPwmyVsb62KRlo(u"࠭࡜࡯࡞ࡱࠫྜ")+YzowicIDTRusXZSU61(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨྜྷ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪྞ")+ZZoLlKyInXc08j2pTGJ
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡟ࡲࡡࡴࠧྟ")+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫྠ")
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += nMt0iueCy6K+ynxXU3gaiQ9GPCftr1q(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭ྡ")+ZZoLlKyInXc08j2pTGJ
	aaNxZcCAYds8FEjDqzgBhK4(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡸࡩࡨࡪࡷࠫྡྷ"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩྣ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,jXWzIZcDva4ikEUfN(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪྤ"))
	return
def HPEOL9UBn4asVkN():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨྥ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࠬྦ")+nMt0iueCy6K+cpHxZyU7vTtqmIw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࠬྦྷ")+ZZoLlKyInXc08j2pTGJ+V2RQwM8XjlrK(u"ࠫࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣࠫྨ")+nMt0iueCy6K+YzowicIDTRusXZSU61(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫྩ")+ZZoLlKyInXc08j2pTGJ)
	return
def JofGDhHkUQMTuq(showDialogs=YOHXqtbQTBfKerIZ):
	if not showDialogs: showDialogs = YOHXqtbQTBfKerIZ
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(AOhmwtSyYBn4ZF7RuvQNU,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡇࡆࡖࠪྪ"),ESXZrtnCfcDJGo01vFg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭ྫ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫྫྷ"))
	if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
		nnSUdYrGzkJpoHlZhMBLxAe1iD0C = eu1NswY9zkKC60I
		ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6 = jrELQfAuqnWc9pBSPivOb5Ft(eu1NswY9zkKC60I)
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧྭ")+ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6+YzowicIDTRusXZSU61(u"ࠪࡡࠬྮ"))
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྯ"),MpJ8GOKoic(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩྰ"))
	else:
		nnSUdYrGzkJpoHlZhMBLxAe1iD0C = YOHXqtbQTBfKerIZ
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩྱ"),SSBkx0WbN1asnDCQV6tIj(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫྲ"))
	if not nnSUdYrGzkJpoHlZhMBLxAe1iD0C and showDialogs: iXB8YZDgu3mMUh9sywlQd4bzrVf6FS()
	return nnSUdYrGzkJpoHlZhMBLxAe1iD0C
def iXB8YZDgu3mMUh9sywlQd4bzrVf6FS():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,YzowicIDTRusXZSU61(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫླ"),FGLEMi21Bfn(u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨྴ"))
	tKRbJoPWAm8pg()
	return
def PPbAlF6upzw(YWCso5NMKO=Vk54F7GcROfCy6HunEI):
	SePcIk2NxaEw9D47RyBoUYMLgCml6 = YOHXqtbQTBfKerIZ
	if Nlyfx1HnzOWCovke5(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ྵ") not in YWCso5NMKO:
		SePcIk2NxaEw9D47RyBoUYMLgCml6 = eu1NswY9zkKC60I
		OFEaiVuGrdSf20oxQl57Wp9A = rAdiM2DVzBuxjPvYFTQs(wYTDlJC5vpOKynUEX3ge6W(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫྶ"),V2RQwM8XjlrK(u"ࠬิั้ฮࠪྷ"),SSBkx0WbN1asnDCQV6tIj(u"࠭ลาีส่๋ࠥิไๆฬࠫྸ"),pnkrd2S84FJfN73KuiCYv(u"ࠧฦำึห้ࠦัิษ็อࠬྐྵ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྺ"),ESXZrtnCfcDJGo01vFg(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬྻ"))
		if OFEaiVuGrdSf20oxQl57Wp9A in [-Nlyfx1HnzOWCovke5(u"࠵ᅽ"),ynxXU3gaiQ9GPCftr1q(u"࠵ᅾ")]: return
		elif OFEaiVuGrdSf20oxQl57Wp9A==EM6qpnCBYQGA9kbgDVLfrP(u"࠷ᅿ"):
			SePcIk2NxaEw9D47RyBoUYMLgCml6 = YOHXqtbQTBfKerIZ
			YWCso5NMKO = ESXZrtnCfcDJGo01vFg(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ྼ")
	if SePcIk2NxaEw9D47RyBoUYMLgCml6:
		if WXuJd8nz2spo146t(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫ྽") not in YWCso5NMKO:
			W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(pnkrd2S84FJfN73KuiCYv(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ྾"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭྿"),jXWzIZcDva4ikEUfN(u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧ࿀"))
			if W8j2OheqsroDJIYzRupt6nG!=EM6qpnCBYQGA9kbgDVLfrP(u"࠱ᆀ"):
				GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫ࿁"),ynxXU3gaiQ9GPCftr1q(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࿂"))
				return
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿃"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫๆ๐ࠠศๆืหูฯࠠศๆๅหิ๋ษࠡฯส์้ࠦร็ࠢอ็ฯฮࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอิาฯࠣๅ๏ํวࠡษ็ู้้ไสࠢฦ์ࠥอไๆู๊์฾่ࠦฦาสࠤศืฯหࠢฯ์ฬฮࠠๆ่ࠣห้๋ศา็ฯࠤๆหะ็ࠢฦ็ฯฮฺ่๋ࠠห๋ࠦศา์า็ࠥษไฦๆๆฮึ๎ๆ๋ࠢส่ส๐ๅ๋ๆࠣ์ฯึใา๋่ࠢฬࠦส็ี์ࠤศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࿄"))
	search = p3bB2auMmSjXC0dE8FUfZ(header=MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ࿅"),source=TVPm7Bz1XOwJ2)
	if not search: return
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = search
	if SePcIk2NxaEw9D47RyBoUYMLgCml6: type = V2RQwM8XjlrK(u"࠭ࡐࡳࡱࡥࡰࡪࡳ࿆ࠧ")
	else: type = YzowicIDTRusXZSU61(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠨ࿇")
	kNQM9jAU6TVlhezn14cKtBb = G5GEld8on2FIazkY(type,BadMOTrh9Lnp0w6KZCQASE4uyk7fW,YOHXqtbQTBfKerIZ,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫ࿈"),YWCso5NMKO)
	return
def hZztpFRygKaCM4XvNcSoOV0fw7BWdj():
	YWCso5NMKO = ynxXU3gaiQ9GPCftr1q(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭࿉")
	aaNxZcCAYds8FEjDqzgBhK4(cpHxZyU7vTtqmIw(u"ࠪࡶ࡮࡭ࡨࡵࠩ࿊"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫ࿋"),YWCso5NMKO,SSBkx0WbN1asnDCQV6tIj(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࿌"))
	YWCso5NMKO = QYSAUI5r46yil8cfaO(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩ࿍")
	aaNxZcCAYds8FEjDqzgBhK4(cpHxZyU7vTtqmIw(u"ࠧ࡭ࡧࡩࡸࠬ࿎"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭࿏"),YWCso5NMKO,WCPwmyVsb62KRlo(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ࿐"))
	return
def xde5n04IjMfUgkl3VbHNhrytRsq():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ESXZrtnCfcDJGo01vFg(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿑"),YzowicIDTRusXZSU61(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩ࿒"))
	ccvpRmIn3yweJ()
	return
def Gh41l8npkrwoYPOLgQX3m27M():
	burCKRDXAy9jY,eeHAfglvTVoC0QE,YtHmu8d3UpLj7XA,lNKx2h7tHjsZR4XEf,byj2RrsfQADh6kC5xwnXIq,yjWJ9SPqFDd,NdVgaJkiCLBjKTPxMoQIvs1 = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	k8NxAwnQI2FzZCyJYthpaVubLscq,I2vYlw7G9FuparNZRbUg,T21TB6MqDt8NPaingkGwXmZfIAY4Ex,apxDytPMidSZ37OohebWg0s9JILcFq = {ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡧࠧ࿓"):Nlyfx1HnzOWCovke5(u"࠭ࡡࠨ࿔")},{},[],{}
	url = h9zFQKnsNL.SITESURLS[XCYALgFs2O3hZdpHrlMmB(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࿕")][pwxH3oREFm5v98BCZ1QVtzMJOc]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(HHvEOMNGCeQKIZybal7,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨࡒࡒࡗ࡙࠭࿖"),url,k8NxAwnQI2FzZCyJYthpaVubLscq,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧ࿗"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(V2RQwM8XjlrK(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡗࡹࡧࡴࡦࡵࠪ࿘"),MpJ8GOKoic(u"࡚࡙ࠫࡁࠨ࿙"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(BBflQamoVNRxMegHLKUvW6s9yAhP(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡑࡩ࡯ࡩࡧࡳࡲ࠭࿚"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ࡕࡌࠩ࿛"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧ࿜"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࡗࡄࡉࠬ࿝"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࡖࡥࡺࡪࡩࠡࡃࡵࡥࡧ࡯ࡡࠨ࿞"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪࡏࡘࡇࠧ࿟"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(ynxXU3gaiQ9GPCftr1q(u"ࠫࡓࡵࡲࡵࡪࠣࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭࿠"),SSBkx0WbN1asnDCQV6tIj(u"ࠬࡔ࠮ࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ࿡"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(jXWzIZcDva4ikEUfN(u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ࿢"),eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡘ࠰ࡖࡥ࡭ࡧࡲࡢࠩ࿣"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = FjwObZSWkg8ahBdiQf9IeY135DpXoP.replace(EM6qpnCBYQGA9kbgDVLfrP(u"ࠨࡡࡢࡣࠬ࿤"),YIPoWuLzfl93BTS)
	try: drb3fKv98Ly5qlpA0eQ = Bw6jaUcFxlqdDT8bC(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩ࡯࡭ࡸࡺࠧ࿥"),FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	except:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿦"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫ࿧"))
		return
	ppDaYgFmwn7k5LM3yoJ01OQZvqe,ac5erqk4CI9u81oNy7O,pfsJET8Z3c = drb3fKv98Ly5qlpA0eQ
	apxDytPMidSZ37OohebWg0s9JILcFq = {}
	eeMgwOZW2bQ = [XCYALgFs2O3hZdpHrlMmB(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨ࿨"),MzgKWUQ4V5H(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬ࿩")]
	pvn2BfVGRrgb4duthX5KM0DF = [WCPwmyVsb62KRlo(u"ࠧࡂࡎࡏࠫ࿪"),WsklGNp2CYzVQUag(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ࿫"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ࿬"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ࿭"),EM6qpnCBYQGA9kbgDVLfrP(u"ࠫࡗࡋࡐࡐࡕࠪ࿮")]+eeMgwOZW2bQ+h9zFQKnsNL.api_python_actions+h9zFQKnsNL.api_repos_actions
	for PPmYnWkqTCfNH1u4yoRs,SpZUf26IjrdEbg,EDoX70yFuT9xwfZdm83QPrUO in ac5erqk4CI9u81oNy7O:
		EDoX70yFuT9xwfZdm83QPrUO = ww25jXuxtpK1TOJEbGUgrm8(EDoX70yFuT9xwfZdm83QPrUO)
		EDoX70yFuT9xwfZdm83QPrUO = EDoX70yFuT9xwfZdm83QPrUO.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(wYTDlJC5vpOKynUEX3ge6W(u"ࠬࠦ࠮ࠨ࿯"))
		lNKx2h7tHjsZR4XEf += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+PPmYnWkqTCfNH1u4yoRs+MpJ8GOKoic(u"࠭࠺ࠡࠩ࿰")+ZZoLlKyInXc08j2pTGJ+EDoX70yFuT9xwfZdm83QPrUO+ixrPWKeFMnqJyVodX6D9AaO2
		if SpZUf26IjrdEbg.isdigit():
			apxDytPMidSZ37OohebWg0s9JILcFq[PPmYnWkqTCfNH1u4yoRs] = int(SpZUf26IjrdEbg)
			if int(SpZUf26IjrdEbg)>BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲࠲࠳ᆁ"): SpZUf26IjrdEbg = WsklGNp2CYzVQUag(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ࿱")
			else: SpZUf26IjrdEbg = ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ࿲")
		if PPmYnWkqTCfNH1u4yoRs not in pvn2BfVGRrgb4duthX5KM0DF:
			if   SpZUf26IjrdEbg==ESXZrtnCfcDJGo01vFg(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ࿳"): burCKRDXAy9jY += YIPoWuLzfl93BTS+PPmYnWkqTCfNH1u4yoRs
			elif SpZUf26IjrdEbg==ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ࿴"): eeHAfglvTVoC0QE += YIPoWuLzfl93BTS+PPmYnWkqTCfNH1u4yoRs
	OVAmyNBaJx8nPLgjqZ9cG3blk,yRHWPapk2cM8UnSehJX,Uo0KQljVEcvxPOergT = list(zip(*ac5erqk4CI9u81oNy7O))
	for PPmYnWkqTCfNH1u4yoRs in sorted(WjMzbLpa1rUo5Pq):
		if PPmYnWkqTCfNH1u4yoRs not in OVAmyNBaJx8nPLgjqZ9cG3blk:
			lNKx2h7tHjsZR4XEf += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+PPmYnWkqTCfNH1u4yoRs+WsklGNp2CYzVQUag(u"ࠫ࠿ࠦࠧ࿵")+ZZoLlKyInXc08j2pTGJ+ynxXU3gaiQ9GPCftr1q(u"๊ࠬวࠡ์๋ะิ࠭࿶")+FGLEMi21Bfn(u"࠭࡜࡯࡞ࡱࠫ࿷")
			if PPmYnWkqTCfNH1u4yoRs not in pvn2BfVGRrgb4duthX5KM0DF: YtHmu8d3UpLj7XA += YIPoWuLzfl93BTS+PPmYnWkqTCfNH1u4yoRs
	for EDoX70yFuT9xwfZdm83QPrUO,RRQ2wKuh8BJfde0Zr in ppDaYgFmwn7k5LM3yoJ01OQZvqe:
		EDoX70yFuT9xwfZdm83QPrUO = ww25jXuxtpK1TOJEbGUgrm8(EDoX70yFuT9xwfZdm83QPrUO)
		byj2RrsfQADh6kC5xwnXIq += EDoX70yFuT9xwfZdm83QPrUO+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧ࠻ࠢࠪ࿸")+nMt0iueCy6K+str(RRQ2wKuh8BJfde0Zr)+ZZoLlKyInXc08j2pTGJ+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࠢࠣࠤࠬ࿹")
	burCKRDXAy9jY = burCKRDXAy9jY.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	eeHAfglvTVoC0QE = eeHAfglvTVoC0QE.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	YtHmu8d3UpLj7XA = YtHmu8d3UpLj7XA.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	CqOTrfZycdF7VElDg2ueNb5hoXLPk4 = burCKRDXAy9jY+YIPoWuLzfl93BTS+eeHAfglvTVoC0QE
	CLJeagidpzPUNry7  = wYTDlJC5vpOKynUEX3ge6W(u"่ࠩ์ฬู่่ࠡฯัࠥอไษำ้ห๊าࠠษฬื฾๏๊ࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭࿺")+ixrPWKeFMnqJyVodX6D9AaO2+g7yJo2LVuqx1trPe(u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨ࿻")+ixrPWKeFMnqJyVodX6D9AaO2
	CLJeagidpzPUNry7 += nMt0iueCy6K+CqOTrfZycdF7VElDg2ueNb5hoXLPk4+ZZoLlKyInXc08j2pTGJ+pnkrd2S84FJfN73KuiCYv(u"ࠫࡡࡴ࡜࡯ࠩ࿼")
	CLJeagidpzPUNry7 += ITXLHQdeVC2icEOAU8hqG470afPB3(u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫ࿽")+ixrPWKeFMnqJyVodX6D9AaO2+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪ࿾")+ixrPWKeFMnqJyVodX6D9AaO2
	CLJeagidpzPUNry7 += nMt0iueCy6K+YtHmu8d3UpLj7XA+ZZoLlKyInXc08j2pTGJ
	HKyIsWNhF2YxAv,SMDryZCcdQ,J9rdpNq46nf0Xj1GxCsHt2i3hkz7B,sEkWXU96Dl08Gjpwh4IJrY = BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲ᆂ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲ᆂ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲ᆂ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠲ᆂ")
	all = apxDytPMidSZ37OohebWg0s9JILcFq[ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡂࡎࡏࠫ࿿")]
	if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨက") in list(apxDytPMidSZ37OohebWg0s9JILcFq.keys()): HKyIsWNhF2YxAv = apxDytPMidSZ37OohebWg0s9JILcFq[V2RQwM8XjlrK(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩခ")]
	if SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫဂ") in list(apxDytPMidSZ37OohebWg0s9JILcFq.keys()): SMDryZCcdQ = apxDytPMidSZ37OohebWg0s9JILcFq[cpHxZyU7vTtqmIw(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬဃ")]
	if FGLEMi21Bfn(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩင") in list(apxDytPMidSZ37OohebWg0s9JILcFq.keys()): J9rdpNq46nf0Xj1GxCsHt2i3hkz7B = apxDytPMidSZ37OohebWg0s9JILcFq[cpHxZyU7vTtqmIw(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪစ")]
	if ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࡓࡇࡓࡓࡘ࠭ဆ") in list(apxDytPMidSZ37OohebWg0s9JILcFq.keys()): sEkWXU96Dl08Gjpwh4IJrY = apxDytPMidSZ37OohebWg0s9JILcFq[MzgKWUQ4V5H(u"ࠨࡔࡈࡔࡔ࡙ࠧဇ")]
	PXLKNJaczkirIF8sveCRqG = all-HKyIsWNhF2YxAv-SMDryZCcdQ-J9rdpNq46nf0Xj1GxCsHt2i3hkz7B-sEkWXU96Dl08Gjpwh4IJrY
	x7ohwWJScUpRi1K50qs,P7n40Wp6TYdVvURGZe5AcDz = pfsJET8Z3c[ufmXvxgoHGDwZtjsLkR05i]
	x7ohwWJScUpRi1K50qs,eiao3V8Yj6RIxs = pfsJET8Z3c[pwxH3oREFm5v98BCZ1QVtzMJOc]
	XXtK4VGyhTf3uLlUorSbE9 = P7n40Wp6TYdVvURGZe5AcDz-eiao3V8Yj6RIxs
	NdVgaJkiCLBjKTPxMoQIvs1 += d761ZWXHEvliYN45RzLP2+str(eiao3V8Yj6RIxs)+ZZoLlKyInXc08j2pTGJ+V2RQwM8XjlrK(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭ဈ")
	NdVgaJkiCLBjKTPxMoQIvs1 += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(XXtK4VGyhTf3uLlUorSbE9)+ZZoLlKyInXc08j2pTGJ+XCYALgFs2O3hZdpHrlMmB(u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧဉ")
	NdVgaJkiCLBjKTPxMoQIvs1 += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(P7n40Wp6TYdVvURGZe5AcDz)+ZZoLlKyInXc08j2pTGJ+YzowicIDTRusXZSU61(u"ࠫฬู๊ะัࠣห้้ไ๋ࠢ็ะ๊๐ูࠡษ็วัําสࠢ࠽ࠤࠬည")
	NdVgaJkiCLBjKTPxMoQIvs1 += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(len(pfsJET8Z3c[Nlyfx1HnzOWCovke5(u"࠵ᆃ"):]))+ZZoLlKyInXc08j2pTGJ+eAMGzHRQVs2KyCwPXljYhB(u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪဋ")
	for T3lKRZcek4aHVNfXCho5SsGngIqB07,igk6DQGT2ychz38 in pfsJET8Z3c[MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶ᆄ"):]:
		T3lKRZcek4aHVNfXCho5SsGngIqB07 = ww25jXuxtpK1TOJEbGUgrm8(T3lKRZcek4aHVNfXCho5SsGngIqB07)
		T3lKRZcek4aHVNfXCho5SsGngIqB07 = T3lKRZcek4aHVNfXCho5SsGngIqB07.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q).strip(BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࠠ࠯ࠩဌ"))
		NdVgaJkiCLBjKTPxMoQIvs1 += T3lKRZcek4aHVNfXCho5SsGngIqB07+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧ࠻ࠢࠪဍ")+nMt0iueCy6K+str(igk6DQGT2ychz38)+ZZoLlKyInXc08j2pTGJ+XCYALgFs2O3hZdpHrlMmB(u"ࠨࠢࠣࠤࠬဎ")
	yjWJ9SPqFDd += d761ZWXHEvliYN45RzLP2+str(PXLKNJaczkirIF8sveCRqG)+ZZoLlKyInXc08j2pTGJ+pnkrd2S84FJfN73KuiCYv(u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧဏ")
	yjWJ9SPqFDd += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(HKyIsWNhF2YxAv)+ZZoLlKyInXc08j2pTGJ+WsklGNp2CYzVQUag(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡสส๎ะ๎ๆࠡ࠼ࠣࠫတ")
	yjWJ9SPqFDd += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(sEkWXU96Dl08Gjpwh4IJrY)+ZZoLlKyInXc08j2pTGJ+WXuJd8nz2spo146t(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼ࠤ࠿ࠦࠧထ")
	yjWJ9SPqFDd += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(SMDryZCcdQ)+ZZoLlKyInXc08j2pTGJ+pnkrd2S84FJfN73KuiCYv(u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩဒ")
	yjWJ9SPqFDd += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(J9rdpNq46nf0Xj1GxCsHt2i3hkz7B)+ZZoLlKyInXc08j2pTGJ+ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬဓ")
	yjWJ9SPqFDd += ixrPWKeFMnqJyVodX6D9AaO2+d761ZWXHEvliYN45RzLP2+str(len(ppDaYgFmwn7k5LM3yoJ01OQZvqe))+ZZoLlKyInXc08j2pTGJ+V2RQwM8XjlrK(u"ࠧะ๊็ࠤูเไหࠢไ๎ิ๐่่ษอࠤ࠿ࠦࠧန")
	yjWJ9SPqFDd += ESXZrtnCfcDJGo01vFg(u"ࠨ࡞ࡱࡠࡳ࠭ပ")+byj2RrsfQADh6kC5xwnXIq
	aaNxZcCAYds8FEjDqzgBhK4(jXWzIZcDva4ikEUfN(u"ࠩࡦࡩࡳࡺࡥࡳࠩဖ"),MpJ8GOKoic(u"ࠪ฽ิีࠠศๆฦะ์ุษࠡษ็ฮ๏ࠦวิฬัำ๊ะ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪဗ"),NdVgaJkiCLBjKTPxMoQIvs1,V2RQwM8XjlrK(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧဘ"))
	aaNxZcCAYds8FEjDqzgBhK4(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬမ"),MpJ8GOKoic(u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧယ"),yjWJ9SPqFDd,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪရ"))
	aaNxZcCAYds8FEjDqzgBhK4(YzowicIDTRusXZSU61(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨလ"),eAMGzHRQVs2KyCwPXljYhB(u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬဝ"),CLJeagidpzPUNry7,NNjUsZzEcFOAoKry2CDMgb1(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭သ"))
	aaNxZcCAYds8FEjDqzgBhK4(XCYALgFs2O3hZdpHrlMmB(u"ࠫࡱ࡫ࡦࡵࠩဟ"),QYSAUI5r46yil8cfaO(u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐ࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤฬูสฯั่ฮࠥอไษำ้ห๊าࠧဠ"),lNKx2h7tHjsZR4XEf,cpHxZyU7vTtqmIw(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧအ"))
	return
def xxnrcQilY7wKuB0fm():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = MzgKWUQ4V5H(u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯ࠩဢ")+d761ZWXHEvliYN45RzLP2+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧဣ")+ZZoLlKyInXc08j2pTGJ+NNjUsZzEcFOAoKry2CDMgb1(u"ࠩ࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣวํࠦสฮ็ํ่์ࠦๅ็࡞ࡱࠫဤ")+d761ZWXHEvliYN45RzLP2+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲࠫဥ")+ZZoLlKyInXc08j2pTGJ+pnkrd2S84FJfN73KuiCYv(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫဦ")
	aaNxZcCAYds8FEjDqzgBhK4(cpHxZyU7vTtqmIw(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬဧ"),ESXZrtnCfcDJGo01vFg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩဨ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,XCYALgFs2O3hZdpHrlMmB(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪဩ"))
	return
def Es63UjSadM1BpQVL89AmqrG7gICN():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = WXuJd8nz2spo146t(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ဪ")+ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+h9zFQKnsNL.SITESURLS[MpJ8GOKoic(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨါ")][ufmXvxgoHGDwZtjsLkR05i]+ZZoLlKyInXc08j2pTGJ+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠧာ")+nMt0iueCy6K+h9zFQKnsNL.SITESURLS[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪိ")][pwxH3oREFm5v98BCZ1QVtzMJOc]+ZZoLlKyInXc08j2pTGJ
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += V2RQwM8XjlrK(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬီ")+nMt0iueCy6K+h9zFQKnsNL.SITESURLS[WsklGNp2CYzVQUag(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬု")][ufmXvxgoHGDwZtjsLkR05i]+ZZoLlKyInXc08j2pTGJ+WCPwmyVsb62KRlo(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫူ")+nMt0iueCy6K+h9zFQKnsNL.SITESURLS[WsklGNp2CYzVQUag(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧေ")][pwxH3oREFm5v98BCZ1QVtzMJOc]+ZZoLlKyInXc08j2pTGJ
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW += l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬဲ")+ixrPWKeFMnqJyVodX6D9AaO2+nMt0iueCy6K+h9zFQKnsNL.SITESURLS[MpJ8GOKoic(u"ࠪࡊࡎࡒࡅࡔࡡࡖࡓ࡚ࡘࡃࡆࡕࠪဳ")][ufmXvxgoHGDwZtjsLkR05i]+ZZoLlKyInXc08j2pTGJ
	aaNxZcCAYds8FEjDqzgBhK4(WCPwmyVsb62KRlo(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫဴ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫဵ"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩံ"))
	return
def GfjdlRbw1Zng7OoStNq4IpMQryKeu(aw54UXhLMcRSGOioPg):
	J2L6to3R1Z.executebuiltin(V2RQwM8XjlrK(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ့࠭࠭")+aw54UXhLMcRSGOioPg+NNjUsZzEcFOAoKry2CDMgb1(u"ࠨࠫࠪး"), YOHXqtbQTBfKerIZ)
	return
def pAUuvy2wzOYfkItGqShabx():
	Rq6BxGQfNWkSiYDthKFo8(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩࡶࡸࡴࡶ္ࠧ"))
	J2L6to3R1Z.executebuiltin(SSBkx0WbN1asnDCQV6tIj(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤ်"))
	return
def UomQJTZ5gniLhH3v9dy():
	J2L6to3R1Z.executebuiltin(jXWzIZcDva4ikEUfN(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪျ"), YOHXqtbQTBfKerIZ)
	return
def vXKWY3PrB1f():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨြ"),wYTDlJC5vpOKynUEX3ge6W(u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭ွ"))
	return
def bbJfYhgByLTePxWVNQ41uI2CKRn():
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪှ"),ESXZrtnCfcDJGo01vFg(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫဿ"))
	return
def ffVHjy6qiX24QxtKdgsWehU(jNoJ4KeV9UPbGQ=ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ၀"),showDialogs=YOHXqtbQTBfKerIZ):
	nshIMkbZEPQr452WV8 = J2L6to3R1Z.executeJSONRPC(MpJ8GOKoic(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭၁"))
	data = MkuHT2blpeds34wXxDyvgitqWo.loads(nshIMkbZEPQr452WV8)
	KKnfrPcTqwNziB3YDQuXJ = data[V2RQwM8XjlrK(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ၂")][WCPwmyVsb62KRlo(u"ࠬࡼࡡ࡭ࡷࡨࠫ၃")]
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: KKnfrPcTqwNziB3YDQuXJ = KKnfrPcTqwNziB3YDQuXJ.encode(AoCWwJHgUPKXI7u2lEzym)
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ၄"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬ၅")+KKnfrPcTqwNziB3YDQuXJ+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪ၆")+jNoJ4KeV9UPbGQ+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠩࠣรࠦ࠭၇"))
		if W8j2OheqsroDJIYzRupt6nG!=MpJ8GOKoic(u"࠶ᆅ"): return eu1NswY9zkKC60I
	kNQM9jAU6TVlhezn14cKtBb,nuqsyO49FtjrRVwCBGYDg3Mp,AAB5YIkLbxUw = ln4rLBUSfY0J6eAg8tEOC(jNoJ4KeV9UPbGQ,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	if kNQM9jAU6TVlhezn14cKtBb:
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,XCYALgFs2O3hZdpHrlMmB(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭၈"),NNjUsZzEcFOAoKry2CDMgb1(u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭၉"))
		MmPd59qzTto3eGuvrJNL = J2L6to3R1Z.executeJSONRPC(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩ၊")+jNoJ4KeV9UPbGQ+wAU9jKvmTM0(u"࠭ࠢࡾࡿࠪ။"))
		kNQM9jAU6TVlhezn14cKtBb = YOHXqtbQTBfKerIZ if wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡐࡍࠪ၌") in MmPd59qzTto3eGuvrJNL else eu1NswY9zkKC60I
		Gb6kwVlSQ4MU.sleep(FGLEMi21Bfn(u"࠷ᆆ"))
		J2L6to3R1Z.executebuiltin(jXWzIZcDva4ikEUfN(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ၍"))
	elif showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ၎"),WXuJd8nz2spo146t(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬ၏"))
	return kNQM9jAU6TVlhezn14cKtBb
def tKRbJoPWAm8pg():
	url = NNjUsZzEcFOAoKry2CDMgb1(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩၐ")
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬࡍࡅࡕࠩၑ"),url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MpJ8GOKoic(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩၒ"))
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	LLg8EF5TPYfd9 = RSuYINdeamsK0t.findall(EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭ၓ"),FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	LLg8EF5TPYfd9 = LLg8EF5TPYfd9[ufmXvxgoHGDwZtjsLkR05i].split(WXuJd8nz2spo146t(u"ࠨ࠯ࠪၔ"))[ufmXvxgoHGDwZtjsLkR05i]
	p2WbRM6iko = str(gs15xoifvOt)
	lNKx2h7tHjsZR4XEf = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫၕ")+d761ZWXHEvliYN45RzLP2+LLg8EF5TPYfd9+ZZoLlKyInXc08j2pTGJ
	lNKx2h7tHjsZR4XEf += ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡠࡳࡢ࡮ࠨၖ")+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่๊ࠢ์ࠥࡀࠠࠡࠢࠪၗ")+d761ZWXHEvliYN45RzLP2+p2WbRM6iko+ZZoLlKyInXc08j2pTGJ
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨၘ"),lNKx2h7tHjsZR4XEf)
	return
def mokPL7iqhAOxGgw3fTUQ():
	uW2Yx936rUfN8G0CXgnVkavZQpOD,KT4u8tJkIDXboFlVOwjpmUCvzgLS,Wos6y4EtDG = eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	MXyRadKAbE9Tu,kMwdoge7QljchX5CKL2P8Vnp36xEJD,ATv2h1NsCwbWj3PYcBxo = eu1NswY9zkKC60I,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	XE2yMYnvcBa = [SSBkx0WbN1asnDCQV6tIj(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၙ"),WXuJd8nz2spo146t(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩၚ"),MzgKWUQ4V5H(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧၛ")]
	rUWTIdPJlh4uNp2w = aaSgYM8cEP(XE2yMYnvcBa)
	for DDXHAicJtj6 in XE2yMYnvcBa:
		if DDXHAicJtj6 not in list(rUWTIdPJlh4uNp2w.keys()): continue
		gTAWC1nqJj2h,OpJZ0jhHns85YrklBfL1,TDoK2XygjCO5VENYcLm,xVe01qnbcRyt8HDmBNMYOTk,AkRj4p61rcSeGaHxYCKVDvy07,lu5FZaLDsOMiN3Wxf47Td,ss2Ll5P6FDkB4x9VTf0RQvY3Z = rUWTIdPJlh4uNp2w[DDXHAicJtj6]
		if DDXHAicJtj6==kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧၜ"):
			MXyRadKAbE9Tu = gTAWC1nqJj2h
			kMwdoge7QljchX5CKL2P8Vnp36xEJD = OpJZ0jhHns85YrklBfL1+WCPwmyVsb62KRlo(u"ࠪࠤࠥࠦࠠࠩࠢࠪၝ")+rLjksYNqhOBoHl3WREm8p(lu5FZaLDsOMiN3Wxf47Td)+cpHxZyU7vTtqmIw(u"ࠫࠥ࠯ࠧၞ")
			ATv2h1NsCwbWj3PYcBxo = xVe01qnbcRyt8HDmBNMYOTk
		elif DDXHAicJtj6==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧၟ"):
			uW2Yx936rUfN8G0CXgnVkavZQpOD = uW2Yx936rUfN8G0CXgnVkavZQpOD or gTAWC1nqJj2h
			KT4u8tJkIDXboFlVOwjpmUCvzgLS += YzowicIDTRusXZSU61(u"࠭ࠠࠡ࠮ࠣࠤࠬၠ")+OpJZ0jhHns85YrklBfL1+SSBkx0WbN1asnDCQV6tIj(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧၡ")+rLjksYNqhOBoHl3WREm8p(lu5FZaLDsOMiN3Wxf47Td)+ynxXU3gaiQ9GPCftr1q(u"ࠨࠢࠬࠫၢ")
			Wos6y4EtDG += V2RQwM8XjlrK(u"ࠩࠣࠤ࠱ࠦࠠࠨၣ")+xVe01qnbcRyt8HDmBNMYOTk
		elif DDXHAicJtj6==WCPwmyVsb62KRlo(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩၤ"):
			pE6ZVsv27mUt5LO4jdegcGIla8Q = gTAWC1nqJj2h
			mpC74FeofqNtjx2wD = OpJZ0jhHns85YrklBfL1+V2RQwM8XjlrK(u"ࠫࠥࠦࠠࠡࠪࠣࠫၥ")+rLjksYNqhOBoHl3WREm8p(lu5FZaLDsOMiN3Wxf47Td)+YzowicIDTRusXZSU61(u"ࠬࠦࠩࠨၦ")
			ya3TUEhRAioMw = xVe01qnbcRyt8HDmBNMYOTk
	KT4u8tJkIDXboFlVOwjpmUCvzgLS = KT4u8tJkIDXboFlVOwjpmUCvzgLS.strip(pnkrd2S84FJfN73KuiCYv(u"࠭ࠠࠡ࠮ࠣࠤࠬၧ"))
	Wos6y4EtDG = Wos6y4EtDG.strip(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࠡࠢ࠯ࠤࠥ࠭ၨ"))
	Nlvjm0siXK7dDP  = XCYALgFs2O3hZdpHrlMmB(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ၩ")+d761ZWXHEvliYN45RzLP2+ATv2h1NsCwbWj3PYcBxo+ZZoLlKyInXc08j2pTGJ
	Nlvjm0siXK7dDP += ixrPWKeFMnqJyVodX6D9AaO2+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫၪ")+d761ZWXHEvliYN45RzLP2+kMwdoge7QljchX5CKL2P8Vnp36xEJD+ZZoLlKyInXc08j2pTGJ
	Nlvjm0siXK7dDP += ESXZrtnCfcDJGo01vFg(u"ࠪࡠࡳࡢ࡮ࠨၫ")+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำู่๊ࠣส้ั฼ࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩၬ")+d761ZWXHEvliYN45RzLP2+Wos6y4EtDG+ZZoLlKyInXc08j2pTGJ
	Nlvjm0siXK7dDP += ixrPWKeFMnqJyVodX6D9AaO2+QYSAUI5r46yil8cfaO(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ึฮํีูࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧၭ")+d761ZWXHEvliYN45RzLP2+KT4u8tJkIDXboFlVOwjpmUCvzgLS+ZZoLlKyInXc08j2pTGJ
	Nlvjm0siXK7dDP += MzgKWUQ4V5H(u"࠭࡜࡯࡞ࡱࠫၮ")+WXuJd8nz2spo146t(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫၯ")+d761ZWXHEvliYN45RzLP2+ya3TUEhRAioMw+ZZoLlKyInXc08j2pTGJ
	Nlvjm0siXK7dDP += ixrPWKeFMnqJyVodX6D9AaO2+WsklGNp2CYzVQUag(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩၰ")+d761ZWXHEvliYN45RzLP2+mpC74FeofqNtjx2wD+ZZoLlKyInXc08j2pTGJ
	gTAWC1nqJj2h = MXyRadKAbE9Tu or uW2Yx936rUfN8G0CXgnVkavZQpOD
	if gTAWC1nqJj2h:
		header = MzgKWUQ4V5H(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫၱ")
		z3r2yNQqDC9EBj6 = Nlyfx1HnzOWCovke5(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫၲ")
	else:
		header = Nlyfx1HnzOWCovke5(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬၳ")
		z3r2yNQqDC9EBj6 = NNjUsZzEcFOAoKry2CDMgb1(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧၴ")
	mSO9iEG348ao = ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧၵ")
	giuXKqNSk3js = Nlvjm0siXK7dDP+FGLEMi21Bfn(u"ࠧ࡝ࡰ࡟ࡲࠬၶ")+z3r2yNQqDC9EBj6+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨ࡞ࡱࡠࡳ࠭ၷ")+mSO9iEG348ao
	aaNxZcCAYds8FEjDqzgBhK4(ESXZrtnCfcDJGo01vFg(u"ࠩࡵ࡭࡬࡮ࡴࠨၸ"),header,giuXKqNSk3js,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ၹ"))
	return gTAWC1nqJj2h
def ssCKhpFQLgf1MyV7GnHOlqeS86w(DDXHAicJtj6,ss2Ll5P6FDkB4x9VTf0RQvY3Z,showDialogs):
	kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
	if showDialogs:
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၺ"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨၻ"))
		if W8j2OheqsroDJIYzRupt6nG!=pwxH3oREFm5v98BCZ1QVtzMJOc: return eu1NswY9zkKC60I
	wuhRxzyjf26dU5qSKPm = jRf87LJug6qp4ZzTyhm(ss2Ll5P6FDkB4x9VTf0RQvY3Z,{},showDialogs)
	if wuhRxzyjf26dU5qSKPm:
		eHRDrFjqLwl7vzc5Tf4 = CR3aLOVKSIme5XFoYi6M.path.join(HTx0geQ7siEXV,DDXHAicJtj6)
		Agz62xbajVk15PieF4utWsGmBC(eHRDrFjqLwl7vzc5Tf4,YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I)
		import zipfile as hP2ONwAEom8dj1T5zyVIGgD3Wv,io as ad8i7FUIJfSYwg4
		hkg54iWl3R7LNjw0qbBHrS = ad8i7FUIJfSYwg4.BytesIO(wuhRxzyjf26dU5qSKPm)
		try:
			iyf1HlSe3GaJIrszM4Ed9Y2 = hP2ONwAEom8dj1T5zyVIGgD3Wv.ZipFile(hkg54iWl3R7LNjw0qbBHrS)
			iyf1HlSe3GaJIrszM4Ed9Y2.extractall(HTx0geQ7siEXV)
			Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
			J2L6to3R1Z.executebuiltin(eAMGzHRQVs2KyCwPXljYhB(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪၼ"))
			Gb6kwVlSQ4MU.sleep(pwxH3oREFm5v98BCZ1QVtzMJOc)
			kNQM9jAU6TVlhezn14cKtBb = kmXefl4aE0c(DDXHAicJtj6)
		except: kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
	if showDialogs:
		if kNQM9jAU6TVlhezn14cKtBb: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၽ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬၾ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V2RQwM8XjlrK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၿ"),Nlyfx1HnzOWCovke5(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨႀ"))
	return kNQM9jAU6TVlhezn14cKtBb
def hhiACvapbKSt(DDXHAicJtj6,showDialogs=YOHXqtbQTBfKerIZ):
	if showDialogs==Vk54F7GcROfCy6HunEI: showDialogs = YOHXqtbQTBfKerIZ
	vuKBI4MSFJYDWkzmf7a28gbNV5hXy = DUMs2h7lprZGTiAmLbu([DDXHAicJtj6])
	rrQkF1JVMuDnp9Ul7mz8esb2g,Xj93q8A5svT = vuKBI4MSFJYDWkzmf7a28gbNV5hXy[DDXHAicJtj6]
	if Xj93q8A5svT:
		kNQM9jAU6TVlhezn14cKtBb = YOHXqtbQTBfKerIZ
		if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႁ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧႂ")+DDXHAicJtj6+cpHxZyU7vTtqmIw(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩႃ"))
	else:
		kNQM9jAU6TVlhezn14cKtBb = eu1NswY9zkKC60I
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(QYSAUI5r46yil8cfaO(u"ࠧࡤࡧࡱࡸࡪࡸࠧႄ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႅ"),Vk54F7GcROfCy6HunEI+DDXHAicJtj6+MzgKWUQ4V5H(u"ࠩࠣࡠࡳࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ฿๐ัࠡ็ไ฽้ฯࠠฤ๊ࠣ฾๏ืࠠๆ๊ฯ์ิฯ้ࠠษ็ฬึ์วๆฮࠣฬาอฬสࠢ็๋ฬࠦ࠮้ࠡ็ࠤฯื๊ะࠢอฯอ๐ส๊ࠡอๅ฾๐ไ้ࠡำ๋ࠥอไฦุสๅฮࠦวๅฤ้ࠤฤ࠭ႆ"))
		if W8j2OheqsroDJIYzRupt6nG==ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠱ᆇ"):
			J2L6to3R1Z.executebuiltin(FGLEMi21Bfn(u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪႇ")+DDXHAicJtj6+ESXZrtnCfcDJGo01vFg(u"ࠫ࠮࠭ႈ"))
			Gb6kwVlSQ4MU.sleep(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠲ᆈ"))
			J2L6to3R1Z.executebuiltin(g7yJo2LVuqx1trPe(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬႉ"))
			Gb6kwVlSQ4MU.sleep(wAU9jKvmTM0(u"࠳ᆉ"))
			while J2L6to3R1Z.getCondVisibility(XCYALgFs2O3hZdpHrlMmB(u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪႊ")): Gb6kwVlSQ4MU.sleep(V2RQwM8XjlrK(u"࠴ᆊ"))
			kNQM9jAU6TVlhezn14cKtBb = kmXefl4aE0c(DDXHAicJtj6)
			if showDialogs and kNQM9jAU6TVlhezn14cKtBb: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႋ"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨฬ่ࠤๆำีࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨႌ"))
			elif showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะႍࠬ"),eAMGzHRQVs2KyCwPXljYhB(u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬႎ"))
	return kNQM9jAU6TVlhezn14cKtBb
def xu3Nf2nY1AlDLs9aQBM0eRtV45(showDialogs):
	if not showDialogs: W8j2OheqsroDJIYzRupt6nG = YOHXqtbQTBfKerIZ
	else: W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႏ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ႐"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢฦ๊ࠥะืๅส้๋ࠣࠦใ้ัํࠤๆำี๊ࠡอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡมࠪ႑"))
	if W8j2OheqsroDJIYzRupt6nG==kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠵ᆋ"):
		J2L6to3R1Z.executebuiltin(eAMGzHRQVs2KyCwPXljYhB(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ႒"))
		if showDialogs:
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ႓"),ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠩอ้ࠥหัิษ็ࠤ฼๊ศࠡว็ํࠥฮั็ษ่ะ้่ࠥะ์ࠣห้ึ๊ࠡใํࠤัํวำๅ่่ࠣ๐๋ࠠไ๋้ࠥฮสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡ࠰ࠣฬ๊อࠠโ์๊หࠥะอะ์ฮࠤ์ึวࠡษ็ฬึ์วๆฮࠣ์ฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩ႔"))
	return
def I2wujS7YQ9g1GL3NcOF():
	kABUWj3fdD0Hgrt2VSGsIQw47MeFzp(OKzSt0JnAdvh2mM,cpHxZyU7vTtqmIw(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭႕"),SSBkx0WbN1asnDCQV6tIj(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ႖"))
	tKRbJoPWAm8pg()
	gTAWC1nqJj2h = mokPL7iqhAOxGgw3fTUQ()
	if gTAWC1nqJj2h:
		hFGk9YqAuCsE(YOHXqtbQTBfKerIZ)
		xu3Nf2nY1AlDLs9aQBM0eRtV45(YOHXqtbQTBfKerIZ)
		YYtCylgzdv5aiwN7nZ2e8soVO9hF(eu1NswY9zkKC60I)
	return
def kmXefl4aE0c(DDXHAicJtj6):
	w8YsNWfQ5gFluRvOmSd4Cb96H = J2L6to3R1Z.executeJSONRPC(QYSAUI5r46yil8cfaO(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ႗")+DDXHAicJtj6+YzowicIDTRusXZSU61(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ႘"))
	succeeded = YOHXqtbQTBfKerIZ if ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡐࡍࠪ႙") in w8YsNWfQ5gFluRvOmSd4Cb96H else eu1NswY9zkKC60I
	return succeeded
def yfGELj6nlQ4bgXS(DDXHAicJtj6):
	w8YsNWfQ5gFluRvOmSd4Cb96H = J2L6to3R1Z.executeJSONRPC(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫႚ")+DDXHAicJtj6+XCYALgFs2O3hZdpHrlMmB(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨႛ"))
	succeeded = YOHXqtbQTBfKerIZ if V2RQwM8XjlrK(u"ࠪࡓࡐ࠭ႜ") in w8YsNWfQ5gFluRvOmSd4Cb96H else eu1NswY9zkKC60I
	return succeeded
def ln4rLBUSfY0J6eAg8tEOC(DDXHAicJtj6,showDialogs,cJm7Bb84PhrzAp,rUWTIdPJlh4uNp2w=None):
	W8j2OheqsroDJIYzRupt6nG,succeeded,nuqsyO49FtjrRVwCBGYDg3Mp,OpJZ0jhHns85YrklBfL1 = YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I,WCPwmyVsb62KRlo(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫႝ"),Vk54F7GcROfCy6HunEI
	if not rUWTIdPJlh4uNp2w: rUWTIdPJlh4uNp2w = aaSgYM8cEP([DDXHAicJtj6])
	if DDXHAicJtj6 in list(rUWTIdPJlh4uNp2w.keys()):
		gTAWC1nqJj2h,OpJZ0jhHns85YrklBfL1,TDoK2XygjCO5VENYcLm,xVe01qnbcRyt8HDmBNMYOTk,AkRj4p61rcSeGaHxYCKVDvy07,lu5FZaLDsOMiN3Wxf47Td,ss2Ll5P6FDkB4x9VTf0RQvY3Z = rUWTIdPJlh4uNp2w[DDXHAicJtj6]
		if lu5FZaLDsOMiN3Wxf47Td==g7yJo2LVuqx1trPe(u"ࠬ࡭࡯ࡰࡦࠪ႞"):
			succeeded,nuqsyO49FtjrRVwCBGYDg3Mp = YOHXqtbQTBfKerIZ,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧ႟")
			if cJm7Bb84PhrzAp and showDialogs:
				W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,EM6qpnCBYQGA9kbgDVLfrP(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႠ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨႡ")+DDXHAicJtj6+WXuJd8nz2spo146t(u"ࠩ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห้ࠣึฯࠠฤะิํࠬႢ"))
				if W8j2OheqsroDJIYzRupt6nG:
					succeeded = ssCKhpFQLgf1MyV7GnHOlqeS86w(DDXHAicJtj6,ss2Ll5P6FDkB4x9VTf0RQvY3Z,eu1NswY9zkKC60I)
					if succeeded:
						nuqsyO49FtjrRVwCBGYDg3Mp = SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪࡶࡪ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨႣ")
						if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႤ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็๋ะํีษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอหูศัฬࠤฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩႥ")+DDXHAicJtj6)
					else:
						nuqsyO49FtjrRVwCBGYDg3Mp = V2RQwM8XjlrK(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭Ⴆ")
						GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႧ"),ynxXU3gaiQ9GPCftr1q(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡว฼หิฯࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨႨ")+DDXHAicJtj6)
		else:
			if showDialogs:
				if lu5FZaLDsOMiN3Wxf47Td==MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫႩ"): BadMOTrh9Lnp0w6KZCQASE4uyk7fW = Nlyfx1HnzOWCovke5(u"้ࠪฯ๎โโหࠪႪ")
				elif lu5FZaLDsOMiN3Wxf47Td==WsklGNp2CYzVQUag(u"ࠫࡴࡲࡤࠨႫ"): BadMOTrh9Lnp0w6KZCQASE4uyk7fW = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"่ࠬฯ๋็ฬࠫႬ")
				elif lu5FZaLDsOMiN3Wxf47Td==SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧႭ"): BadMOTrh9Lnp0w6KZCQASE4uyk7fW = MpJ8GOKoic(u"ࠧ฻์ิࠤ๊ัศหหࠪႮ")
				W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႯ"),wAU9jKvmTM0(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨႰ")+BadMOTrh9Lnp0w6KZCQASE4uyk7fW+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬႱ")+DDXHAicJtj6)
			if not W8j2OheqsroDJIYzRupt6nG: nuqsyO49FtjrRVwCBGYDg3Mp = eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭Ⴒ")
			else:
				if lu5FZaLDsOMiN3Wxf47Td==ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧႳ"):
					succeeded = kmXefl4aE0c(DDXHAicJtj6)
					if succeeded:
						nuqsyO49FtjrRVwCBGYDg3Mp = HOxJyt7l8osNeCjZFMQGi4Sr(u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧႴ")
						if showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႵ"),WXuJd8nz2spo146t(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭Ⴖ")+DDXHAicJtj6)
					elif showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,eAMGzHRQVs2KyCwPXljYhB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႷ"),BBflQamoVNRxMegHLKUvW6s9yAhP(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭Ⴘ")+DDXHAicJtj6)
				elif lu5FZaLDsOMiN3Wxf47Td in [SSBkx0WbN1asnDCQV6tIj(u"ࠫࡴࡲࡤࠨႹ"),g7yJo2LVuqx1trPe(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭Ⴚ")]:
					succeeded = ssCKhpFQLgf1MyV7GnHOlqeS86w(DDXHAicJtj6,ss2Ll5P6FDkB4x9VTf0RQvY3Z,eu1NswY9zkKC60I)
					if succeeded:
						if lu5FZaLDsOMiN3Wxf47Td==eAMGzHRQVs2KyCwPXljYhB(u"࠭࡯࡭ࡦࠪႻ"): nuqsyO49FtjrRVwCBGYDg3Mp = jXWzIZcDva4ikEUfN(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨႼ")
						elif lu5FZaLDsOMiN3Wxf47Td==YzowicIDTRusXZSU61(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩႽ"): nuqsyO49FtjrRVwCBGYDg3Mp = kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬႾ")
						OpJZ0jhHns85YrklBfL1 = xVe01qnbcRyt8HDmBNMYOTk
						if showDialogs:
							if nuqsyO49FtjrRVwCBGYDg3Mp==WCPwmyVsb62KRlo(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫႿ"): GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჀ"),FGLEMi21Bfn(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩჁ")+DDXHAicJtj6)
							elif nuqsyO49FtjrRVwCBGYDg3Mp==l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩჂ"): GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WsklGNp2CYzVQUag(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪჃ"),ESXZrtnCfcDJGo01vFg(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩჄ")+DDXHAicJtj6)
					elif showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬჅ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"่้ࠪษำโࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣฮาี๊ฬࠢฦ์ࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭჆")+DDXHAicJtj6)
	elif showDialogs: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჇ"),WsklGNp2CYzVQUag(u"๊ࠬไฤีไࠤ࠳࠴่ࠠา๊ࠤฬ๊ลืษไอࠥเ๊า่ࠢ์ั๎ฯสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ჈")+DDXHAicJtj6)
	return succeeded,nuqsyO49FtjrRVwCBGYDg3Mp,OpJZ0jhHns85YrklBfL1
def RexMqYz6sFoCOLBwjXa89GtKgvHJD(DDXHAicJtj6,showDialogs,zA1GOInBNPvwlMZUF0mHa):
	TB8Ap7fa2RvSQcGbN = U4xLTJsWfkMbNpicjY9SVOwAthED.connect(qqcpbNo3gTyUdmsS10MGuKa)
	TB8Ap7fa2RvSQcGbN.text_factory = str
	C9frwiYhylNH2n14uDaG5 = TB8Ap7fa2RvSQcGbN.cursor()
	succeeded,AKwLHmecXlF7N = YOHXqtbQTBfKerIZ,eu1NswY9zkKC60I
	try:
		wUa6ugsBZWpnkyYKPJ2reO = l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ჉")
		C9frwiYhylNH2n14uDaG5.execute(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ჊")+DDXHAicJtj6+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠨࠤࠣ࠿ࠬ჋"))
		V4XMdxhtyri6l18RLjG0voIge = C9frwiYhylNH2n14uDaG5.fetchall()
		if V4XMdxhtyri6l18RLjG0voIge and wUa6ugsBZWpnkyYKPJ2reO not in str(V4XMdxhtyri6l18RLjG0voIge): C9frwiYhylNH2n14uDaG5.execute(V2RQwM8XjlrK(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭჌")+wUa6ugsBZWpnkyYKPJ2reO+BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩჍ")+DDXHAicJtj6+SSBkx0WbN1asnDCQV6tIj(u"ࠫࠧࠦ࠻ࠨ჎"))
		jXWIudMirakR = V2RQwM8XjlrK(u"ࠬࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠨ჏") if HHKJDQzRtNxmaOLAq8FcjyGbuViUog else MzgKWUQ4V5H(u"࠭ࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠬა")
		C9frwiYhylNH2n14uDaG5.execute(wYTDlJC5vpOKynUEX3ge6W(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨბ")+jXWIudMirakR+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭გ")+DDXHAicJtj6+QYSAUI5r46yil8cfaO(u"ࠩࠥࠤࡀ࠭დ"))
		V4XMdxhtyri6l18RLjG0voIge = C9frwiYhylNH2n14uDaG5.fetchall()
		if V4XMdxhtyri6l18RLjG0voIge:
			if showDialogs: W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ე"),YzowicIDTRusXZSU61(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨვ")+DDXHAicJtj6+MzgKWUQ4V5H(u"ࠬࠦ࡜࡯࡞ࡱࠤࠬზ")+nMt0iueCy6K+EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠࠨთ")+ZZoLlKyInXc08j2pTGJ+g7yJo2LVuqx1trPe(u"ࠧࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬი"))
			else: W8j2OheqsroDJIYzRupt6nG = pwxH3oREFm5v98BCZ1QVtzMJOc
			if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
				AKwLHmecXlF7N = YOHXqtbQTBfKerIZ
				C9frwiYhylNH2n14uDaG5.execute(WCPwmyVsb62KRlo(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧკ")+jXWIudMirakR+kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧლ")+DDXHAicJtj6+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࠦࠥࡁࠧმ"))
		elif zA1GOInBNPvwlMZUF0mHa:
			if showDialogs: W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MzgKWUQ4V5H(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧნ"),kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩო")+DDXHAicJtj6+BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࠠ࡝ࡰ࡟ࡲࠥ࠭პ")+nMt0iueCy6K+MzgKWUQ4V5H(u"ࠧࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࠬჟ")+ZZoLlKyInXc08j2pTGJ+Nlyfx1HnzOWCovke5(u"ࠨࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭რ"))
			else: W8j2OheqsroDJIYzRupt6nG = pwxH3oREFm5v98BCZ1QVtzMJOc
			if W8j2OheqsroDJIYzRupt6nG==pwxH3oREFm5v98BCZ1QVtzMJOc:
				AKwLHmecXlF7N = YOHXqtbQTBfKerIZ
				if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: C9frwiYhylNH2n14uDaG5.execute(MzgKWUQ4V5H(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨს")+jXWIudMirakR+l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪტ")+DDXHAicJtj6+ESXZrtnCfcDJGo01vFg(u"ࠫࠧ࠯ࠠ࠼ࠩუ"))
				else: C9frwiYhylNH2n14uDaG5.execute(WCPwmyVsb62KRlo(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫფ")+jXWIudMirakR+BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࠮ࡸࡴࡩࡧࡴࡦࡔࡸࡰࡪ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪქ")+DDXHAicJtj6+XCYALgFs2O3hZdpHrlMmB(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧღ"))
	except: succeeded = eu1NswY9zkKC60I
	TB8Ap7fa2RvSQcGbN.commit()
	TB8Ap7fa2RvSQcGbN.close()
	if AKwLHmecXlF7N:
		Gb6kwVlSQ4MU.sleep(WCPwmyVsb62KRlo(u"࠶ᆌ"))
		J2L6to3R1Z.executebuiltin(FGLEMi21Bfn(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬყ"))
		Gb6kwVlSQ4MU.sleep(MpJ8GOKoic(u"࠷ᆍ"))
		if showDialogs:
			if succeeded: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SSBkx0WbN1asnDCQV6tIj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬშ"),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫჩ")+DDXHAicJtj6)
			else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧც"),MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ძ")+DDXHAicJtj6)
	return AKwLHmecXlF7N
def JoZC8kepNQbxWhIyw1E2iFTSgd90(XE2yMYnvcBa,showDialogs,cJm7Bb84PhrzAp,zA1GOInBNPvwlMZUF0mHa):
	rUWTIdPJlh4uNp2w = aaSgYM8cEP(XE2yMYnvcBa)
	yHu014BULK3 = eu1NswY9zkKC60I
	for DDXHAicJtj6 in XE2yMYnvcBa:
		succeeded,nuqsyO49FtjrRVwCBGYDg3Mp,OpJZ0jhHns85YrklBfL1 = ln4rLBUSfY0J6eAg8tEOC(DDXHAicJtj6,showDialogs,cJm7Bb84PhrzAp,rUWTIdPJlh4uNp2w)
		AKwLHmecXlF7N = RexMqYz6sFoCOLBwjXa89GtKgvHJD(DDXHAicJtj6,showDialogs,zA1GOInBNPvwlMZUF0mHa)
		if AKwLHmecXlF7N: yHu014BULK3 = YOHXqtbQTBfKerIZ
	if yHu014BULK3:
		Gb6kwVlSQ4MU.sleep(V2RQwM8XjlrK(u"࠱ᆎ"))
		J2L6to3R1Z.executebuiltin(Nlyfx1HnzOWCovke5(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪწ"))
		Gb6kwVlSQ4MU.sleep(kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"࠲ᆏ"))
	if showDialogs:
		if len(XE2yMYnvcBa)>BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠳ᆐ"): GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪჭ"),kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠอ็ํ฽ࠥอไฦุสๅฬะࠧხ"))
		else: GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,WXuJd8nz2spo146t(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬჯ"),YzowicIDTRusXZSU61(u"ࠪฮ๊ࠦศ็ฮสัࠥ็อึࠢส่ส฼วโห࡟ࡲࡡࡴࠧჰ")+XE2yMYnvcBa[EM6qpnCBYQGA9kbgDVLfrP(u"࠳ᆑ")])
	return
def hFGk9YqAuCsE(showDialogs):
	YYIOMNrKaDP7zd = [eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩჱ"),MpJ8GOKoic(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧჲ"),cpHxZyU7vTtqmIw(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪჳ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧჴ")]
	zl7e5JZM1c = [eAMGzHRQVs2KyCwPXljYhB(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪჵ"),YzowicIDTRusXZSU61(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪჶ"),g7yJo2LVuqx1trPe(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭ჷ"),ynxXU3gaiQ9GPCftr1q(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭ჸ"),l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭ჹ"),MpJ8GOKoic(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪჺ")]
	for DDXHAicJtj6 in zl7e5JZM1c: yfGELj6nlQ4bgXS(DDXHAicJtj6)
	JoZC8kepNQbxWhIyw1E2iFTSgd90(YYIOMNrKaDP7zd,showDialogs,eu1NswY9zkKC60I,eu1NswY9zkKC60I)
	return
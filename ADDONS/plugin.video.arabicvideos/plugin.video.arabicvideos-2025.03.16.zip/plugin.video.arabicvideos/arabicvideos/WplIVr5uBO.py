# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
import bs4 as HuEDJWIc1MsmtT7r0K
TVPm7Bz1XOwJ2 = 'ELCINEMA'
xzA9sM3rG6IHd7jl8T = '_ELC_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
headers = {'Referer':FFLhlYUAsfJBXeQmRpzD7c14ZP6}
wXPtB6I0QKLTyD932sl5d = []
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==510: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==511: w8YsNWfQ5gFluRvOmSd4Cb96H = u6k0SoiwyMZtm19cEjeslDrbTFqz4I(url)
	elif mode==512: w8YsNWfQ5gFluRvOmSd4Cb96H = Zj4VthEgG1(url)
	elif mode==513: w8YsNWfQ5gFluRvOmSd4Cb96H = HxrsWypOJ9jzbeBwhLaS(url)
	elif mode==514: w8YsNWfQ5gFluRvOmSd4Cb96H = kkciaMI4EDN5WtY(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: w8YsNWfQ5gFluRvOmSd4Cb96H = kkciaMI4EDN5WtY(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: w8YsNWfQ5gFluRvOmSd4Cb96H = fvYl4iaUVst5QgZCkeLS3ynNHmp(text)
	elif mode==517: w8YsNWfQ5gFluRvOmSd4Cb96H = VWKfkAmXdNbP32Meo(url)
	elif mode==518: w8YsNWfQ5gFluRvOmSd4Cb96H = QgvryW1UfqCzYjL0(url)
	elif mode==519: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	elif mode==520: w8YsNWfQ5gFluRvOmSd4Cb96H = MMphmEACTK7wWLvPB8D4O(url)
	elif mode==521: w8YsNWfQ5gFluRvOmSd4Cb96H = PJvbZVB54plLWHjDeRgh(url)
	elif mode==522: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==523: w8YsNWfQ5gFluRvOmSd4Cb96H = muZajiKTDIqAvnMVXlRx6hCS(text)
	elif mode==524: w8YsNWfQ5gFluRvOmSd4Cb96H = fV0vhEBNZsJ7Tjz()
	elif mode==525: w8YsNWfQ5gFluRvOmSd4Cb96H = c1IGtX7JwaOQgj()
	elif mode==526: w8YsNWfQ5gFluRvOmSd4Cb96H = DMK6N2SG8tVeb7n()
	elif mode==527: w8YsNWfQ5gFluRvOmSd4Cb96H = aHpWMFAtcnR4xY2()
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث بموسوعة السينما',Vk54F7GcROfCy6HunEI,519)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'موسوعة الأعمال',Vk54F7GcROfCy6HunEI,525)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'موسوعة الأشخاص',Vk54F7GcROfCy6HunEI,526)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'موسوعة المصنفات',Vk54F7GcROfCy6HunEI,527)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'موسوعة المنوعات',Vk54F7GcROfCy6HunEI,524)
	return
def fV0vhEBNZsJ7Tjz():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' فيديوهات - خاصة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video',520)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فيديوهات - أحدث',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/latest',521)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فيديوهات - أقدم',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/oldest',521)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فيديوهات - أكثر مشاهدة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/video/views',521)
	return
def c1IGtX7JwaOQgj():
	RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup?utf8=%E2%9C%93'
	avbArEMO1B = RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf+'&type=2&category=1&foreign=false&tag='
	uBNH7JtpYEoP = RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf+'&type=2&category=3&foreign=false&tag='
	l3zBQitVIw7RD8YdSrecZFoLg = RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf+'&type=2&category=1&foreign=true&tag='
	uUNGbZ4gtWQpV = RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf+'&type=2&category=3&foreign=true&tag='
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات أفلام عربي',avbArEMO1B,511)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات مسلسلات عربي',uBNH7JtpYEoP,511)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات أفلام اجنبي',l3zBQitVIw7RD8YdSrecZFoLg,511)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات مسلسلات اجنبي',uUNGbZ4gtWQpV,511)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس أعمال أبجدي',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/work/alphabet',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس  بلد الإنتاج',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/work/country',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس اللغة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/work/language',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس مصنفات العمل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/work/genre',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس سنة الإصدار',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/work/release_year',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مواسم - فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/seasonals',515)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مواسم - فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/seasonals',514)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات - فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup',515)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات - فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup',514)
	return
def aHpWMFAtcnR4xY2():
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup',Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	UwcYSVZbdK3rI = iP5YpRbDf3W9tVG.find('select',attrs={'name':'tag'})
	iwX378tMyTW9KUB = UwcYSVZbdK3rI.find_all('option')
	for CCPw5ZS83fxa7AXzQ9VvUIrNDbo in iwX378tMyTW9KUB:
		value = CCPw5ZS83fxa7AXzQ9VvUIrNDbo.get('value')
		if not value: continue
		title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo.text
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.encode(AoCWwJHgUPKXI7u2lEzym)
			value = value.encode(AoCWwJHgUPKXI7u2lEzym)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',Vk54F7GcROfCy6HunEI)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,511)
	return
def DMK6N2SG8tVeb7n():
	RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup?utf8=%E2%9C%93'
	ZhKvMoPs3BX12tN = RZ7DmSQYTwN1cGJ9d0eu8PBFjbkf+'&type=1&category=&foreign=&tag='
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات أشخاص',ZhKvMoPs3BX12tN,511)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس أشخاص أبجدي',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/person/alphabet',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس موطن',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/person/nationality',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس  تاريخ الميلاد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/person/birth_year',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'فهرس  تاريخ الوفاة',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/index/person/death_year',517)
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات - فلتر محدد',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup',515)
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'مصنفات - فلتر كامل',FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/lineup',514)
	return
def u6k0SoiwyMZtm19cEjeslDrbTFqz4I(url):
	if '/seasonals' in url: p1pTyjFEIDr3lgUHhdJsm5t9MBwS = 0
	elif '/lineup' in url: p1pTyjFEIDr3lgUHhdJsm5t9MBwS = 1
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-LISTS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	DatFuedGb45zR1KqIWNk = iP5YpRbDf3W9tVG.find_all(class_='jumbo-theater clearfix')
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		title = UwcYSVZbdK3rI.find_all('a')[p1pTyjFEIDr3lgUHhdJsm5t9MBwS].text
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+UwcYSVZbdK3rI.find_all('a')[p1pTyjFEIDr3lgUHhdJsm5t9MBwS].get('href')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
		if not DatFuedGb45zR1KqIWNk:
			Zj4VthEgG1(ssfLBvkuNiXear2gPdxcyT4AQMhYSp)
			return
		else:
			title = title.replace('قائمة ',Vk54F7GcROfCy6HunEI)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,512)
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(iP5YpRbDf3W9tVG,511)
	return
def zHSF4cMRhPp9ibC6ou1Yxna2lBq0(iP5YpRbDf3W9tVG,mode):
	UwcYSVZbdK3rI = iP5YpRbDf3W9tVG.find(class_='pagination')
	if UwcYSVZbdK3rI:
		f6yKSzoPZRd3IkOn = UwcYSVZbdK3rI.find_all('a')
		Awfe3QDp20htgyn = UwcYSVZbdK3rI.find_all('li')
		mrPYvglfSOTWt3Q9BL7VKF = list(zip(f6yKSzoPZRd3IkOn,Awfe3QDp20htgyn))
		sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz = -1
		AxNVaEwzRTBJn5 = len(mrPYvglfSOTWt3Q9BL7VKF)
		for M87xAQqm352BynDjzF6pLJl9N,TGakMhr8tXzU in mrPYvglfSOTWt3Q9BL7VKF:
			sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz += 1
			TGakMhr8tXzU = TGakMhr8tXzU['class']
			if 'unavailable' in TGakMhr8tXzU or 'current' in TGakMhr8tXzU: continue
			KK4WEqy9u1mj = M87xAQqm352BynDjzF6pLJl9N.text
			YBDKFZOGfyCHLPA1EaUz9MJ = FFLhlYUAsfJBXeQmRpzD7c14ZP6+M87xAQqm352BynDjzF6pLJl9N.get('href')
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
				KK4WEqy9u1mj = KK4WEqy9u1mj.encode(AoCWwJHgUPKXI7u2lEzym)
				YBDKFZOGfyCHLPA1EaUz9MJ = YBDKFZOGfyCHLPA1EaUz9MJ.encode(AoCWwJHgUPKXI7u2lEzym)
			if   sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz==0: KK4WEqy9u1mj = 'أولى'
			elif sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz==1: KK4WEqy9u1mj = 'سابقة'
			elif sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz==AxNVaEwzRTBJn5-2: KK4WEqy9u1mj = 'لاحقة'
			elif sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz==AxNVaEwzRTBJn5-1: KK4WEqy9u1mj = 'أخيرة'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'صفحة '+KK4WEqy9u1mj,YBDKFZOGfyCHLPA1EaUz9MJ,mode)
	return
def Zj4VthEgG1(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-TITLES1-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	DatFuedGb45zR1KqIWNk = iP5YpRbDf3W9tVG.find_all(class_='row')
	items,jnyGYUoM3gNOVf = [],True
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		if not UwcYSVZbdK3rI.find(class_='thumbnail-wrapper'): continue
		if jnyGYUoM3gNOVf: jnyGYUoM3gNOVf = False ; continue
		v5vpAIXh6yNWeYfm = []
		SGbLHKgn1FWpQdq5oxmBX3 = UwcYSVZbdK3rI.find_all(class_=['censorship red','censorship purple'])
		for ljaFtIB7MiKNQfO1u9 in SGbLHKgn1FWpQdq5oxmBX3:
			uuw8OrnPmSMvWxEH32TfVRsIqXaZYD = ljaFtIB7MiKNQfO1u9.find_all('li')[1].text
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
				uuw8OrnPmSMvWxEH32TfVRsIqXaZYD = uuw8OrnPmSMvWxEH32TfVRsIqXaZYD.encode(AoCWwJHgUPKXI7u2lEzym)
			v5vpAIXh6yNWeYfm.append(uuw8OrnPmSMvWxEH32TfVRsIqXaZYD)
		if not tPps36BvDZLbj4X1yfGnxOTJhM(TVPm7Bz1XOwJ2,Vk54F7GcROfCy6HunEI,v5vpAIXh6yNWeYfm,False):
			ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('data-src')
			title = UwcYSVZbdK3rI.find('h3')
			name = title.find('a').text
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+title.find('a').get('href')
			PBdIsg6vYOGboxXN27UAC93T = UwcYSVZbdK3rI.find(class_='no-margin')
			Rzdy9VSAcO1KasYoQm = UwcYSVZbdK3rI.find(class_='legend')
			if PBdIsg6vYOGboxXN27UAC93T: PBdIsg6vYOGboxXN27UAC93T = PBdIsg6vYOGboxXN27UAC93T.text
			if Rzdy9VSAcO1KasYoQm: Rzdy9VSAcO1KasYoQm = Rzdy9VSAcO1KasYoQm.text
			if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
				ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.encode(AoCWwJHgUPKXI7u2lEzym)
				name = name.encode(AoCWwJHgUPKXI7u2lEzym)
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
				if PBdIsg6vYOGboxXN27UAC93T: PBdIsg6vYOGboxXN27UAC93T = PBdIsg6vYOGboxXN27UAC93T.encode(AoCWwJHgUPKXI7u2lEzym)
			Xb17xtEphFigA8dReBrGH = {}
			if Rzdy9VSAcO1KasYoQm: Xb17xtEphFigA8dReBrGH['stars'] = Rzdy9VSAcO1KasYoQm
			if PBdIsg6vYOGboxXN27UAC93T:
				PBdIsg6vYOGboxXN27UAC93T = PBdIsg6vYOGboxXN27UAC93T.replace(ixrPWKeFMnqJyVodX6D9AaO2,' .. ')
				Xb17xtEphFigA8dReBrGH['plot'] = PBdIsg6vYOGboxXN27UAC93T.replace('...اقرأ المزيد',Vk54F7GcROfCy6HunEI)
			if '/work/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,516,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH)
			elif '/person/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,513,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH)
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(iP5YpRbDf3W9tVG,512)
	return
def HxrsWypOJ9jzbeBwhLaS(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-TITLES2-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	DatFuedGb45zR1KqIWNk = iP5YpRbDf3W9tVG.find_all('li')
	eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK,items = [],[]
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		if not UwcYSVZbdK3rI.find(class_='thumbnail-wrapper'): continue
		if not UwcYSVZbdK3rI.find(class_=['unstyled','unstyled text-center']): continue
		if UwcYSVZbdK3rI.find(class_='hide'): continue
		title = UwcYSVZbdK3rI.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK: continue
		eFC4kIYuZmfhJoi7UsQOWc5BPpEvSK.append(name)
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+title.find('a').get('href')
		if '/search/work/' in url: ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('src')
		elif '/search/person/' in url: ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('data-src')
		elif '/search/video/' in url: ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('data-src')
		else: ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('src')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			name = name.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
			ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.encode(AoCWwJHgUPKXI7u2lEzym)
		name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		items.append((name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,ylKTDSkdQmUChwbX45ALeiu))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,ylKTDSkdQmUChwbX45ALeiu in items:
		if '/search/video/' in url: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,522,ylKTDSkdQmUChwbX45ALeiu)
		elif '/search/person/' in url: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,513,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,516,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name)
	return
def fvYl4iaUVst5QgZCkeLS3ynNHmp(text):
	text = text.replace('الإعلان',Vk54F7GcROfCy6HunEI).replace('لفيلم',Vk54F7GcROfCy6HunEI).replace('الرسمي',Vk54F7GcROfCy6HunEI)
	text = text.replace('إعلان',Vk54F7GcROfCy6HunEI).replace('فيلم',Vk54F7GcROfCy6HunEI).replace('البرومو',Vk54F7GcROfCy6HunEI)
	text = text.replace('التشويقي',Vk54F7GcROfCy6HunEI).replace('لمسلسل',Vk54F7GcROfCy6HunEI).replace('مسلسل',Vk54F7GcROfCy6HunEI)
	text = text.replace(':',Vk54F7GcROfCy6HunEI).replace(')',Vk54F7GcROfCy6HunEI).replace('(',Vk54F7GcROfCy6HunEI).replace(',',Vk54F7GcROfCy6HunEI)
	text = text.replace('_',Vk54F7GcROfCy6HunEI).replace(';',Vk54F7GcROfCy6HunEI).replace('-',Vk54F7GcROfCy6HunEI).replace('.',Vk54F7GcROfCy6HunEI)
	text = text.replace('\'',Vk54F7GcROfCy6HunEI).replace('\"',Vk54F7GcROfCy6HunEI)
	text = text.replace(qMmCGK8cln5bID4fkhAF,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	text = text.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	aOzwP48Wic21spvoSgZ = text.count(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)+1
	if aOzwP48Wic21spvoSgZ==1:
		muZajiKTDIqAvnMVXlRx6hCS(text)
		return
	v0TjHlLZqkRxUCpmNwSy8AndO('link',xzA9sM3rG6IHd7jl8T+nMt0iueCy6K+'==== كلمات للبحث ===='+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	tQBibgXj9JLZO0 = text.split(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
	fcJZPOpHENkQK9WDVeXl2oLtIhS8R = pow(2,aOzwP48Wic21spvoSgZ)
	dvORyV1FmMbTjcPn7hlg = []
	def zXJEG6TMFC(BOGRYiPs2pANX4519WbJw,DhMFC4k3KQXdf6yv):
		if BOGRYiPs2pANX4519WbJw=='1': return DhMFC4k3KQXdf6yv
		return Vk54F7GcROfCy6HunEI
	for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(fcJZPOpHENkQK9WDVeXl2oLtIhS8R,0,-1):
		X1EodvgBlDxRyzYO4S = list(aOzwP48Wic21spvoSgZ*'0'+bin(sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz)[2:])[-aOzwP48Wic21spvoSgZ:]
		X1EodvgBlDxRyzYO4S = reversed(X1EodvgBlDxRyzYO4S)
		MmPd59qzTto3eGuvrJNL = map(zXJEG6TMFC,X1EodvgBlDxRyzYO4S,tQBibgXj9JLZO0)
		title = otBWsSAfu7dihVkP9e1JFKrvmYy2Q.join(filter(None,MmPd59qzTto3eGuvrJNL))
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: esUNcDaPg3QoX = title.decode(AoCWwJHgUPKXI7u2lEzym)
		else: esUNcDaPg3QoX = title
		if len(esUNcDaPg3QoX)>2 and title not in dvORyV1FmMbTjcPn7hlg:
			dvORyV1FmMbTjcPn7hlg.append(title)
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,Vk54F7GcROfCy6HunEI,523,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,title)
	return
def muZajiKTDIqAvnMVXlRx6hCS(QTu5DMfvn62aRLhKq07):
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
		QTu5DMfvn62aRLhKq07 = QTu5DMfvn62aRLhKq07.decode(AoCWwJHgUPKXI7u2lEzym)
		import arabic_reshaper as sszMPfg2clhyDwjOVZBIbnU,bidi.algorithm as XTO5h0Fqprge621
		QTu5DMfvn62aRLhKq07 = sszMPfg2clhyDwjOVZBIbnU.ArabicReshaper().reshape(QTu5DMfvn62aRLhKq07)
		QTu5DMfvn62aRLhKq07 = XTO5h0Fqprge621.get_display(QTu5DMfvn62aRLhKq07)
	import BHk9b8G5AL
	QTu5DMfvn62aRLhKq07 = p3bB2auMmSjXC0dE8FUfZ(BmAVzcqta91Xnrjyfk=QTu5DMfvn62aRLhKq07)
	BHk9b8G5AL.zDkgCMXBmx2A(QTu5DMfvn62aRLhKq07)
	return
def VWKfkAmXdNbP32Meo(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-INDEXES_LISTS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	UwcYSVZbdK3rI = iP5YpRbDf3W9tVG.find(class_='list-separator list-title')
	ss285HRGmwx = UwcYSVZbdK3rI.find_all('a')
	items = []
	for title in ss285HRGmwx:
		name = title.text
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+title.get('href')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			name = name.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
		if '#' not in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: items.append((name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for anbjzfuiDdgYP6vSXqwRex in items:
		name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp = anbjzfuiDdgYP6vSXqwRex
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,518)
	return
def QgvryW1UfqCzYjL0(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-INDEXES_TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	DatFuedGb45zR1KqIWNk = iP5YpRbDf3W9tVG.find(class_='expand').find_all('tr')
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		cTCrKvnU7JmpZfN3Bk = UwcYSVZbdK3rI.find_all('a')
		if not cTCrKvnU7JmpZfN3Bk: continue
		ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('data-src')
		name = cTCrKvnU7JmpZfN3Bk[1].text
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+cTCrKvnU7JmpZfN3Bk[1].get('href')
		Rzdy9VSAcO1KasYoQm = UwcYSVZbdK3rI.find(class_='legend')
		if Rzdy9VSAcO1KasYoQm: Rzdy9VSAcO1KasYoQm = Rzdy9VSAcO1KasYoQm.text
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			name = name.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
			ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.encode(AoCWwJHgUPKXI7u2lEzym)
		Xb17xtEphFigA8dReBrGH = {}
		if Rzdy9VSAcO1KasYoQm: Xb17xtEphFigA8dReBrGH['stars'] = Rzdy9VSAcO1KasYoQm
		if '/work/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp:
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,516,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH)
		elif '/person/' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+name,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,513,ylKTDSkdQmUChwbX45ALeiu,Vk54F7GcROfCy6HunEI,name,Vk54F7GcROfCy6HunEI,Xb17xtEphFigA8dReBrGH)
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(iP5YpRbDf3W9tVG,518)
	return
def MMphmEACTK7wWLvPB8D4O(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-VIDEOS_LISTS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	ss285HRGmwx = iP5YpRbDf3W9tVG.find_all(class_='section-title inline')
	HXhRgxEZ4d2Dek = iP5YpRbDf3W9tVG.find_all(class_='button green small right')
	items = zip(ss285HRGmwx,HXhRgxEZ4d2Dek)
	for title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp in items:
		title = title.text
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp.get('href')
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
		title = title.replace(qMmCGK8cln5bID4fkhAF,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(NaXBAuesz07inT4g6cDt,otBWsSAfu7dihVkP9e1JFKrvmYy2Q).replace(YIPoWuLzfl93BTS,otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,521)
	return
def PJvbZVB54plLWHjDeRgh(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-VIDEOS_TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	witDvQ1qy7 = iP5YpRbDf3W9tVG.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	DatFuedGb45zR1KqIWNk = witDvQ1qy7.find_all('li')
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		title = UwcYSVZbdK3rI.find(class_='title').text
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+UwcYSVZbdK3rI.find('a').get('href')
		ylKTDSkdQmUChwbX45ALeiu = UwcYSVZbdK3rI.find('img').get('data-src')
		GbwM6iseo0ZVlh4ydB = UwcYSVZbdK3rI.find(class_='duration').text
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.encode(AoCWwJHgUPKXI7u2lEzym)
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
			ylKTDSkdQmUChwbX45ALeiu = ylKTDSkdQmUChwbX45ALeiu.encode(AoCWwJHgUPKXI7u2lEzym)
			GbwM6iseo0ZVlh4ydB = GbwM6iseo0ZVlh4ydB.encode(AoCWwJHgUPKXI7u2lEzym)
		GbwM6iseo0ZVlh4ydB = GbwM6iseo0ZVlh4ydB.replace(ixrPWKeFMnqJyVodX6D9AaO2,Vk54F7GcROfCy6HunEI).strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,522,ylKTDSkdQmUChwbX45ALeiu,GbwM6iseo0ZVlh4ydB)
	zHSF4cMRhPp9ibC6ou1Yxna2lBq0(iP5YpRbDf3W9tVG,521)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = iP5YpRbDf3W9tVG.find(class_='flex-video').find('iframe').get('src')
	if HHKJDQzRtNxmaOLAq8FcjyGbuViUog: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = ssfLBvkuNiXear2gPdxcyT4AQMhYSp.encode(AoCWwJHgUPKXI7u2lEzym)
	import f37xHeSwPL
	f37xHeSwPL.DmVB0sUPLbNuzdToH7RM3([ssfLBvkuNiXear2gPdxcyT4AQMhYSp],TVPm7Bz1XOwJ2,'video',url)
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'%20')
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search/?q='+search
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-SEARCH-1st')
	if not Iy3PA1SVXNfjOchtgHC5kuJBG.succeeded:
		ZhKvMoPs3BX12tN = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search_entity/?q='+search+'&entity=work'
		YBDKFZOGfyCHLPA1EaUz9MJ = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search_entity/?q='+search+'&entity=person'
		J4GX5SPIvY1anesyTKWVZr8 = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search_entity/?q='+search+'&entity=video'
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن أعمال',ZhKvMoPs3BX12tN,513,Vk54F7GcROfCy6HunEI,search)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن أشخاص',YBDKFZOGfyCHLPA1EaUz9MJ,513,Vk54F7GcROfCy6HunEI,search)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث عن فيديوهات',J4GX5SPIvY1anesyTKWVZr8,513,Vk54F7GcROfCy6HunEI,search)
		return
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	iP5YpRbDf3W9tVG = HuEDJWIc1MsmtT7r0K.BeautifulSoup(FjwObZSWkg8ahBdiQf9IeY135DpXoP,'html.parser',multi_valued_attributes=None)
	DatFuedGb45zR1KqIWNk = iP5YpRbDf3W9tVG.find_all(class_='section-title left')
	for UwcYSVZbdK3rI in DatFuedGb45zR1KqIWNk:
		title = UwcYSVZbdK3rI.text
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			title = title.encode(AoCWwJHgUPKXI7u2lEzym)
		title = title.split('(',1)[0].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if   'أعمال' in title: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = url.replace('/search/','/search/video/')
		else: continue
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,513)
	return
def kkciaMI4EDN5WtY(url,text):
	global jVTGDSdXIEbQJ6ueqK19w,LJSlAbTd4vknNqtOUZDm
	if '/seasonals' in url:
		jVTGDSdXIEbQJ6ueqK19w = ['seasonal','year','category']
		LJSlAbTd4vknNqtOUZDm = ['seasonal','year','category']
	elif '/lineup' in url:
		jVTGDSdXIEbQJ6ueqK19w = ['category','foreign','type']
		LJSlAbTd4vknNqtOUZDm = ['category','foreign','type']
	dm9YWrf845oej12ICpRnTgtSiQxV(url,text)
	return
def xkK0Y7fnciMQvjyq(url):
	url = url.split('/smartemadfilter?')[0]
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',url,Vk54F7GcROfCy6HunEI,headers,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('form action="/(.*?)</form>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	Ugep4NW1YS = RSuYINdeamsK0t.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return Ugep4NW1YS
def uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI):
	items = RSuYINdeamsK0t.findall('<option value="(.*?)">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	return items
def eW2Btjung49(url):
	zxAP2BC6ekOXpHnwF = url.split('/smartemadfilter?')[0]
	iFJVwrXDlfRUKN20 = RRav1Sf7Px(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def iiWkfZnCbt(ssCfIvyG3epxY4OtkHK,url):
	aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(ssCfIvyG3epxY4OtkHK,'all_filters')
	ynmiDuav5ICTeRsqj6Vb18Q = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	ynmiDuav5ICTeRsqj6Vb18Q = eW2Btjung49(ynmiDuav5ICTeRsqj6Vb18Q)
	return ynmiDuav5ICTeRsqj6Vb18Q
def dm9YWrf845oej12ICpRnTgtSiQxV(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==Vk54F7GcROfCy6HunEI: UWFh8TfCJpRomD3,KMbV6CGYIuH = Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI
	else: UWFh8TfCJpRomD3,KMbV6CGYIuH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if jVTGDSdXIEbQJ6ueqK19w[0]+'=' not in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[0]
		for zHq7nBWJTNyY1I3aLco4AR in range(len(jVTGDSdXIEbQJ6ueqK19w[0:-1])):
			if jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR]+'=' in UWFh8TfCJpRomD3: MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb = jVTGDSdXIEbQJ6ueqK19w[zHq7nBWJTNyY1I3aLco4AR+1]
		xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb+'=0'
		Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C.strip('&')+'___'+ssCfIvyG3epxY4OtkHK.strip('&')
		aCWGTw0JDhu8dLnPoFfcrXU7Mb = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+aCWGTw0JDhu8dLnPoFfcrXU7Mb
	elif type=='ALL_ITEMS_FILTER':
		KmFMrdROtg = APTvCRrcgVt4m(UWFh8TfCJpRomD3,'modified_values')
		KmFMrdROtg = ZlBMJUAWRm9buv(KmFMrdROtg)
		if KMbV6CGYIuH!=Vk54F7GcROfCy6HunEI: KMbV6CGYIuH = APTvCRrcgVt4m(KMbV6CGYIuH,'modified_filters')
		if KMbV6CGYIuH==Vk54F7GcROfCy6HunEI: hj50MJnoOp6ZWaS1IQ8Elr = url
		else: hj50MJnoOp6ZWaS1IQ8Elr = url+'/smartemadfilter?'+KMbV6CGYIuH
		hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'أظهار قائمة الفيديو التي تم اختيارها ',hj50MJnoOp6ZWaS1IQ8Elr,511)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+' [[   '+KmFMrdROtg+'   ]]',hj50MJnoOp6ZWaS1IQ8Elr,511)
		v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	Ugep4NW1YS = xkK0Y7fnciMQvjyq(url)
	dict = {}
	for name,kuKGA8HpgN7PyjvxeLZ,UwcYSVZbdK3rI in Ugep4NW1YS:
		name = name.replace('--',Vk54F7GcROfCy6HunEI)
		items = uuAzVMDy3ceGUYfrN841oOpT5LhZEP(UwcYSVZbdK3rI)
		if '=' not in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr = url
		if type=='SPECIFIED_FILTER':
			if kuKGA8HpgN7PyjvxeLZ not in jVTGDSdXIEbQJ6ueqK19w: continue
			if MjeA6kfH2cOm0IdwRxyW1sPQaFUzGb!=kuKGA8HpgN7PyjvxeLZ: continue
			elif len(items)<2:
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]:
					url = eW2Btjung49(url)
					Zj4VthEgG1(url)
				else: dm9YWrf845oej12ICpRnTgtSiQxV(hj50MJnoOp6ZWaS1IQ8Elr,'SPECIFIED_FILTER___'+Ng1Jod47fp0S)
				return
			else:
				hj50MJnoOp6ZWaS1IQ8Elr = eW2Btjung49(hj50MJnoOp6ZWaS1IQ8Elr)
				if kuKGA8HpgN7PyjvxeLZ==jVTGDSdXIEbQJ6ueqK19w[-1]: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,511)
				else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع',hj50MJnoOp6ZWaS1IQ8Elr,515,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		elif type=='ALL_ITEMS_FILTER':
			if kuKGA8HpgN7PyjvxeLZ not in LJSlAbTd4vknNqtOUZDm: continue
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'=0'
			Ng1Jod47fp0S = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'الجميع: '+name,hj50MJnoOp6ZWaS1IQ8Elr,514,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Ng1Jod47fp0S)
		dict[kuKGA8HpgN7PyjvxeLZ] = {}
		for value,CCPw5ZS83fxa7AXzQ9VvUIrNDbo in items:
			if CCPw5ZS83fxa7AXzQ9VvUIrNDbo in wXPtB6I0QKLTyD932sl5d: continue
			if 'مصنفات أخرى' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			if 'الكل' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			if 'اللغة' in CCPw5ZS83fxa7AXzQ9VvUIrNDbo: continue
			CCPw5ZS83fxa7AXzQ9VvUIrNDbo = CCPw5ZS83fxa7AXzQ9VvUIrNDbo.replace('قائمة ',Vk54F7GcROfCy6HunEI)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[kuKGA8HpgN7PyjvxeLZ][value] = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			xky6Wr2FvDpJiSdhEZ5C = UWFh8TfCJpRomD3+'&'+kuKGA8HpgN7PyjvxeLZ+'='+CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			ssCfIvyG3epxY4OtkHK = KMbV6CGYIuH+'&'+kuKGA8HpgN7PyjvxeLZ+'='+value
			V7l0eBcbHnq48LYCdOa6IySAGD2zj5 = xky6Wr2FvDpJiSdhEZ5C+'___'+ssCfIvyG3epxY4OtkHK
			if name: title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo+' :'+name
			else: title = CCPw5ZS83fxa7AXzQ9VvUIrNDbo
			if type=='ALL_ITEMS_FILTER': v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,514,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
			elif type=='SPECIFIED_FILTER' and jVTGDSdXIEbQJ6ueqK19w[-2]+'=' in UWFh8TfCJpRomD3:
				ynmiDuav5ICTeRsqj6Vb18Q = iiWkfZnCbt(ssCfIvyG3epxY4OtkHK,url)
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ynmiDuav5ICTeRsqj6Vb18Q,511)
			else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,url,515,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,V7l0eBcbHnq48LYCdOa6IySAGD2zj5)
	return
def APTvCRrcgVt4m(iiRIXOcxv1An6k30Z2ULMwYB,mode):
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.replace('=&','=0&')
	iiRIXOcxv1An6k30Z2ULMwYB = iiRIXOcxv1An6k30Z2ULMwYB.strip('&')
	og8wRH5eO04T3uylM = {}
	if '=' in iiRIXOcxv1An6k30Z2ULMwYB:
		items = iiRIXOcxv1An6k30Z2ULMwYB.split('&')
		for anbjzfuiDdgYP6vSXqwRex in items:
			qVFIRlAkhETb2J1OZMBjX5,value = anbjzfuiDdgYP6vSXqwRex.split('=')
			og8wRH5eO04T3uylM[qVFIRlAkhETb2J1OZMBjX5] = value
	PpjxGzO7yqD0AXSJL1Mw = Vk54F7GcROfCy6HunEI
	for key in LJSlAbTd4vknNqtOUZDm:
		if key in list(og8wRH5eO04T3uylM.keys()): value = og8wRH5eO04T3uylM[key]
		else: value = '0'
		if '%' not in value: value = FW2Ak3YHe6jCKbDzdTtOa1qUJiNu8(value)
		if mode=='modified_values' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+' + '+value
		elif mode=='modified_filters' and value!='0': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
		elif mode=='all_filters': PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw+'&'+key+'='+value
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip(' + ')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.strip('&')
	PpjxGzO7yqD0AXSJL1Mw = PpjxGzO7yqD0AXSJL1Mw.replace('=0','=')
	return PpjxGzO7yqD0AXSJL1Mw
jVTGDSdXIEbQJ6ueqK19w = []
LJSlAbTd4vknNqtOUZDm = []
# -*- coding: utf-8 -*-
import sys as yBxCpcVaPow1bztQm4X
HnrXbdO6q7JYkQg2SoRy0aMuFATwU1 = yBxCpcVaPow1bztQm4X.version_info [0] == 2
JJvLhr5KtWYNuM1z7f = 2048
HV0T1ldZEtbN = 7
def pTuqzbokU49F (jflq53yxT28pAU):
	global eHyr0LZKhWONtod2CREgw
	poDPGrMhOfa7zBbdsHVguIZF = ord (jflq53yxT28pAU [-1])
	GGwhrHb5MFn9tKvyNAoTDqj4m = jflq53yxT28pAU [:-1]
	ct3K4VDUQl = poDPGrMhOfa7zBbdsHVguIZF % len (GGwhrHb5MFn9tKvyNAoTDqj4m)
	AAdRgVz046keUxnNqYsWc = GGwhrHb5MFn9tKvyNAoTDqj4m [:ct3K4VDUQl] + GGwhrHb5MFn9tKvyNAoTDqj4m [ct3K4VDUQl:]
	if HnrXbdO6q7JYkQg2SoRy0aMuFATwU1:
		EkWmxRv7p5fgZ = unicode () .join ([unichr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	else:
		EkWmxRv7p5fgZ = str () .join ([chr (ord (QQdOpqSghyPcGosVXa9KCibfEAnNv) - JJvLhr5KtWYNuM1z7f - (GhfElAp23t + poDPGrMhOfa7zBbdsHVguIZF) % HV0T1ldZEtbN) for GhfElAp23t, QQdOpqSghyPcGosVXa9KCibfEAnNv in enumerate (AAdRgVz046keUxnNqYsWc)])
	return eval (EkWmxRv7p5fgZ)
YzowicIDTRusXZSU61,cpHxZyU7vTtqmIw,NNjUsZzEcFOAoKry2CDMgb1=pTuqzbokU49F,pTuqzbokU49F,pTuqzbokU49F
ttmCxT5RhNl7f8HdjWXwczD9Gvr4,QYSAUI5r46yil8cfaO,wYTDlJC5vpOKynUEX3ge6W=NNjUsZzEcFOAoKry2CDMgb1,cpHxZyU7vTtqmIw,YzowicIDTRusXZSU61
kTvOE5l4bwNQ2jsfgFHRDSUIJ,wAU9jKvmTM0,EM6qpnCBYQGA9kbgDVLfrP=wYTDlJC5vpOKynUEX3ge6W,QYSAUI5r46yil8cfaO,ttmCxT5RhNl7f8HdjWXwczD9Gvr4
XCYALgFs2O3hZdpHrlMmB,SSBkx0WbN1asnDCQV6tIj,ESXZrtnCfcDJGo01vFg=EM6qpnCBYQGA9kbgDVLfrP,wAU9jKvmTM0,kTvOE5l4bwNQ2jsfgFHRDSUIJ
FGLEMi21Bfn,jXWzIZcDva4ikEUfN,ogJClMiqPa4A0NUtTxpDVybEWG=ESXZrtnCfcDJGo01vFg,SSBkx0WbN1asnDCQV6tIj,XCYALgFs2O3hZdpHrlMmB
ynxXU3gaiQ9GPCftr1q,WXuJd8nz2spo146t,kGjoOpYbcFWrUX1lt5Din40ym6e2=ogJClMiqPa4A0NUtTxpDVybEWG,jXWzIZcDva4ikEUfN,FGLEMi21Bfn
MpJ8GOKoic,g7yJo2LVuqx1trPe,SB1nDH5yph4lNCA0JxXkti6rVRcv=kGjoOpYbcFWrUX1lt5Din40ym6e2,WXuJd8nz2spo146t,ynxXU3gaiQ9GPCftr1q
l4V9IFYOwhBjRNz3oQkEfrpK81s2,ITXLHQdeVC2icEOAU8hqG470afPB3,eAMGzHRQVs2KyCwPXljYhB=SB1nDH5yph4lNCA0JxXkti6rVRcv,g7yJo2LVuqx1trPe,MpJ8GOKoic
Nlyfx1HnzOWCovke5,BBflQamoVNRxMegHLKUvW6s9yAhP,WCPwmyVsb62KRlo=eAMGzHRQVs2KyCwPXljYhB,ITXLHQdeVC2icEOAU8hqG470afPB3,l4V9IFYOwhBjRNz3oQkEfrpK81s2
HOxJyt7l8osNeCjZFMQGi4Sr,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,pnkrd2S84FJfN73KuiCYv=WCPwmyVsb62KRlo,BBflQamoVNRxMegHLKUvW6s9yAhP,Nlyfx1HnzOWCovke5
MzgKWUQ4V5H,V2RQwM8XjlrK,WsklGNp2CYzVQUag=pnkrd2S84FJfN73KuiCYv,MuQX8DgLwzlATjnB94YI0kf6PJhmCV,HOxJyt7l8osNeCjZFMQGi4Sr
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = eAMGzHRQVs2KyCwPXljYhB(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੔")
def X42LMUrFfIY3oWeazj(Yz6schq9wSmiu3IOdke0DXPj5W,lI5ck2gjRCiw9bMTF0xHsG):
	if   Yz6schq9wSmiu3IOdke0DXPj5W==NNjUsZzEcFOAoKry2CDMgb1(u"࠸࠹࠰૧"): w8YsNWfQ5gFluRvOmSd4Cb96H = ZXGC1Oyzsrtx42IbPBq()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==YzowicIDTRusXZSU61(u"࠹࠳࠲૨"): w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(lI5ck2gjRCiw9bMTF0xHsG)
	elif Yz6schq9wSmiu3IOdke0DXPj5W==ESXZrtnCfcDJGo01vFg(u"࠳࠴࠴૩"): w8YsNWfQ5gFluRvOmSd4Cb96H = aqtSIon9CkhB7Mc0RiAOF()
	elif Yz6schq9wSmiu3IOdke0DXPj5W==QYSAUI5r46yil8cfaO(u"࠴࠵࠶૪"): w8YsNWfQ5gFluRvOmSd4Cb96H = qqASI1tNwTn6QVz4oidlcU7()
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = eu1NswY9zkKC60I
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def h5hmzOAeWEPip(lI5ck2gjRCiw9bMTF0xHsG):
	qnUlyF2JXuGYdSA6Iac1(lI5ck2gjRCiw9bMTF0xHsG,TVPm7Bz1XOwJ2,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࠭ࡶࡪࡦࡨࡳࠬ੕"))
	return
def qqASI1tNwTn6QVz4oidlcU7():
	BadMOTrh9Lnp0w6KZCQASE4uyk7fW = MpJ8GOKoic(u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭੖")
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧ੗"),BadMOTrh9Lnp0w6KZCQASE4uyk7fW)
	return
def ZXGC1Oyzsrtx42IbPBq():
	v0TjHlLZqkRxUCpmNwSy8AndO(ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠩ࡯࡭ࡳࡱࠧ੘"),nMt0iueCy6K+cpHxZyU7vTtqmIw(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨਖ਼")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,WCPwmyVsb62KRlo(u"࠵࠶࠷૫"))
	v0TjHlLZqkRxUCpmNwSy8AndO(eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡱ࡯࡮࡬ࠩਗ਼"),nMt0iueCy6K+ESXZrtnCfcDJGo01vFg(u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬਜ਼")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,Nlyfx1HnzOWCovke5(u"࠶࠷࠷૬"))
	v0TjHlLZqkRxUCpmNwSy8AndO(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭࡬ࡪࡰ࡮ࠫੜ"),nMt0iueCy6K+QYSAUI5r46yil8cfaO(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭੝")+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠽࠾࠿࠹૭"))
	XcP83JBQIzgVfd = o2jZ8VAKpwf539PGt6lJUEdFHkyir()
	rS5Rgx2an4Efw8qvVLI = CR3aLOVKSIme5XFoYi6M.stat(XcP83JBQIzgVfd).st_mtime
	jDCuyJxcOvUi85NX3g = []
	if PvwFsJK23NbU8XWAx: QEdz3I1Xb2hMYytLCNSkKc = CR3aLOVKSIme5XFoYi6M.listdir(XcP83JBQIzgVfd.encode(AoCWwJHgUPKXI7u2lEzym))
	else: QEdz3I1Xb2hMYytLCNSkKc = CR3aLOVKSIme5XFoYi6M.listdir(XcP83JBQIzgVfd.decode(AoCWwJHgUPKXI7u2lEzym))
	for z9zanu6eDOHMZjbfiyEkB in QEdz3I1Xb2hMYytLCNSkKc:
		if PvwFsJK23NbU8XWAx: z9zanu6eDOHMZjbfiyEkB = z9zanu6eDOHMZjbfiyEkB.decode(AoCWwJHgUPKXI7u2lEzym)
		if not z9zanu6eDOHMZjbfiyEkB.startswith(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠨࡨ࡬ࡰࡪࡥࠧਫ਼")): continue
		MMDcNX5yjJA941zSQaisvVp = CR3aLOVKSIme5XFoYi6M.path.join(XcP83JBQIzgVfd,z9zanu6eDOHMZjbfiyEkB)
		rS5Rgx2an4Efw8qvVLI = CR3aLOVKSIme5XFoYi6M.path.getmtime(MMDcNX5yjJA941zSQaisvVp)
		jDCuyJxcOvUi85NX3g.append([z9zanu6eDOHMZjbfiyEkB,rS5Rgx2an4Efw8qvVLI])
	jDCuyJxcOvUi85NX3g = sorted(jDCuyJxcOvUi85NX3g,reverse=YOHXqtbQTBfKerIZ,key=lambda key: key[pwxH3oREFm5v98BCZ1QVtzMJOc])
	for z9zanu6eDOHMZjbfiyEkB,rS5Rgx2an4Efw8qvVLI in jDCuyJxcOvUi85NX3g:
		if HHKJDQzRtNxmaOLAq8FcjyGbuViUog:
			try: z9zanu6eDOHMZjbfiyEkB = z9zanu6eDOHMZjbfiyEkB.decode(AoCWwJHgUPKXI7u2lEzym)
			except: pass
			z9zanu6eDOHMZjbfiyEkB = z9zanu6eDOHMZjbfiyEkB.encode(AoCWwJHgUPKXI7u2lEzym)
		MMDcNX5yjJA941zSQaisvVp = CR3aLOVKSIme5XFoYi6M.path.join(XcP83JBQIzgVfd,z9zanu6eDOHMZjbfiyEkB)
		v0TjHlLZqkRxUCpmNwSy8AndO(NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ੟"),z9zanu6eDOHMZjbfiyEkB,MMDcNX5yjJA941zSQaisvVp,Nlyfx1HnzOWCovke5(u"࠸࠹࠱૮"))
	return
def o2jZ8VAKpwf539PGt6lJUEdFHkyir():
	XcP83JBQIzgVfd = cad8TeSyMUYmfsEO0.getSetting(eAMGzHRQVs2KyCwPXljYhB(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭੠"))
	if XcP83JBQIzgVfd: return XcP83JBQIzgVfd
	cad8TeSyMUYmfsEO0.setSetting(eAMGzHRQVs2KyCwPXljYhB(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧ੡"),GK4x3b6Erdk)
	return GK4x3b6Erdk
def aqtSIon9CkhB7Mc0RiAOF():
	XcP83JBQIzgVfd = o2jZ8VAKpwf539PGt6lJUEdFHkyir()
	wjWBHstyrV3lxJvKiSLopnAhZGTEz = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(NNjUsZzEcFOAoKry2CDMgb1(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ੢"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪ੣"),d761ZWXHEvliYN45RzLP2+XcP83JBQIzgVfd+ZZoLlKyInXc08j2pTGJ+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨ੤"))
	if wjWBHstyrV3lxJvKiSLopnAhZGTEz==XCYALgFs2O3hZdpHrlMmB(u"࠷૯"):
		dWsLzhVmnqKMlU8I = Lx3W825r7KeO(MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠳૰"),HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬ੥"),V2RQwM8XjlrK(u"ࠩ࡯ࡳࡨࡧ࡬ࠨ੦"),Vk54F7GcROfCy6HunEI,eu1NswY9zkKC60I,YOHXqtbQTBfKerIZ,XcP83JBQIzgVfd)
		W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(YzowicIDTRusXZSU61(u"ࠪࡧࡪࡴࡴࡦࡴࠪ੧"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,jXWzIZcDva4ikEUfN(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨ੨"),d761ZWXHEvliYN45RzLP2+XcP83JBQIzgVfd+ZZoLlKyInXc08j2pTGJ+YzowicIDTRusXZSU61(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭੩"))
		if W8j2OheqsroDJIYzRupt6nG==QYSAUI5r46yil8cfaO(u"࠲૱"):
			cad8TeSyMUYmfsEO0.setSetting(MzgKWUQ4V5H(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩ੪"),dWsLzhVmnqKMlU8I)
			GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,pnkrd2S84FJfN73KuiCYv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ੫"),ynxXU3gaiQ9GPCftr1q(u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩ੬"))
	return
def ZtOXNzWPfsF1T2vSiGEja5uy7(lI5ck2gjRCiw9bMTF0xHsG,LJp6PbnjvSTEGF=Vk54F7GcROfCy6HunEI,website=Vk54F7GcROfCy6HunEI):
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+WCPwmyVsb62KRlo(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ੭")+lI5ck2gjRCiw9bMTF0xHsG+EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࠤࡢ࠭੮"))
	if not LJp6PbnjvSTEGF: LJp6PbnjvSTEGF = fLvc6uEJiq3(lI5ck2gjRCiw9bMTF0xHsG)
	XcP83JBQIzgVfd = o2jZ8VAKpwf539PGt6lJUEdFHkyir()
	ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6 = jrELQfAuqnWc9pBSPivOb5Ft(eu1NswY9zkKC60I)
	z9zanu6eDOHMZjbfiyEkB = ppZmLj3ldhP8M9JzbXGOnyEoKg2xQ6.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࡤ࠭੯"))
	z9zanu6eDOHMZjbfiyEkB = I1yWnMRpsx5(z9zanu6eDOHMZjbfiyEkB)
	z9zanu6eDOHMZjbfiyEkB = MzgKWUQ4V5H(u"ࠬ࡬ࡩ࡭ࡧࡢࠫੰ")+str(int(npbh5qZo1PBiNkj))[-MpJ8GOKoic(u"࠶૲"):]+jXWzIZcDva4ikEUfN(u"࠭࡟ࠨੱ")+z9zanu6eDOHMZjbfiyEkB+LJp6PbnjvSTEGF
	XhJu54Ejt8 = CR3aLOVKSIme5XFoYi6M.path.join(XcP83JBQIzgVfd,z9zanu6eDOHMZjbfiyEkB)
	KT67DQI1xk9XG34ezN0hH = {}
	KT67DQI1xk9XG34ezN0hH[EM6qpnCBYQGA9kbgDVLfrP(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩੲ")] = Vk54F7GcROfCy6HunEI
	KT67DQI1xk9XG34ezN0hH[SSBkx0WbN1asnDCQV6tIj(u"ࠨࡃࡦࡧࡪࡶࡴࠨੳ")] = ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠩ࠭࠳࠯࠭ੴ")
	lI5ck2gjRCiw9bMTF0xHsG = lI5ck2gjRCiw9bMTF0xHsG.replace(ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ੵ"),Vk54F7GcROfCy6HunEI)
	if NNjUsZzEcFOAoKry2CDMgb1(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ੶") in lI5ck2gjRCiw9bMTF0xHsG:
		hj50MJnoOp6ZWaS1IQ8Elr,rZigEYv8tbVk = lI5ck2gjRCiw9bMTF0xHsG.rsplit(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ੷"),SSBkx0WbN1asnDCQV6tIj(u"࠴૳"))
		rZigEYv8tbVk = rZigEYv8tbVk.replace(NNjUsZzEcFOAoKry2CDMgb1(u"࠭ࡼࠨ੸"),Vk54F7GcROfCy6HunEI).replace(SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠧࠧࠩ੹"),Vk54F7GcROfCy6HunEI)
	else: hj50MJnoOp6ZWaS1IQ8Elr,rZigEYv8tbVk = lI5ck2gjRCiw9bMTF0xHsG,None
	if not rZigEYv8tbVk: rZigEYv8tbVk = p3QOAkrEuys81JqHobh()
	if rZigEYv8tbVk: KT67DQI1xk9XG34ezN0hH[ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ੺")] = rZigEYv8tbVk
	if NNjUsZzEcFOAoKry2CDMgb1(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ੻") in hj50MJnoOp6ZWaS1IQ8Elr: hj50MJnoOp6ZWaS1IQ8Elr,yCJq05F7M4TB = hj50MJnoOp6ZWaS1IQ8Elr.rsplit(pnkrd2S84FJfN73KuiCYv(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ੼"),ogJClMiqPa4A0NUtTxpDVybEWG(u"࠵૴"))
	else: hj50MJnoOp6ZWaS1IQ8Elr,yCJq05F7M4TB = hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI
	hj50MJnoOp6ZWaS1IQ8Elr = hj50MJnoOp6ZWaS1IQ8Elr.strip(QYSAUI5r46yil8cfaO(u"ࠫࢁ࠭੽")).strip(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࠬࠧ੾")).strip(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࡼࠨ੿")).strip(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧࠧࠩ઀"))
	yCJq05F7M4TB = yCJq05F7M4TB.replace(jXWzIZcDva4ikEUfN(u"ࠨࡾࠪઁ"),Vk54F7GcROfCy6HunEI).replace(eAMGzHRQVs2KyCwPXljYhB(u"ࠩࠩࠫં"),Vk54F7GcROfCy6HunEI)
	if yCJq05F7M4TB:	KT67DQI1xk9XG34ezN0hH[MzgKWUQ4V5H(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫઃ")] = yCJq05F7M4TB
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ઄")+hj50MJnoOp6ZWaS1IQ8Elr+ESXZrtnCfcDJGo01vFg(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨઅ")+str(KT67DQI1xk9XG34ezN0hH)+g7yJo2LVuqx1trPe(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭આ")+XhJu54Ejt8+ogJClMiqPa4A0NUtTxpDVybEWG(u"ࠧࠡ࡟ࠪઇ"))
	bbYGkvuoSHB52R3TD84ZhmEI = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶࠶࠲࠵૵")*MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠶࠶࠲࠵૵")
	gHNrTGfQpklb2A1MBx8ueo9OJV6Kh = WWyMvQzapJOkdYeH0b()//bbYGkvuoSHB52R3TD84ZhmEI
	if not gHNrTGfQpklb2A1MBx8ueo9OJV6Kh:
		aaNxZcCAYds8FEjDqzgBhK4(SSBkx0WbN1asnDCQV6tIj(u"ࠨࡴ࡬࡫࡭ࡺࠧઈ"),wYTDlJC5vpOKynUEX3ge6W(u"่ࠩืฬำษࠡษ็ฮำุ๊็่ࠢะ์๎ไสࠩઉ"),WXuJd8nz2spo146t(u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํัิีࠠๆไาหึࠦๅิษะอࠥอไหะี๎๋ࠦวๅใสี฿ฯࠠโ์ࠣะ์อาไ๋ࠢ฽้๐็ࠡใส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡๆ้ࠤ๏฿ๅๅࠢ฼๊ิ้ࠠฦๆ์ࠤศ์๋ࠠไ๋้๋ࠥศา็ฯ๎ࠥฮั็ษ่ะ้่ࠥะ์ࠣฬา๊่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ่ࠥฯࠡ์ึฬอࠦวๆฬ็หฦࠦฬ่ษี็ࠥฮวๅ็็ๅฬะ้้ࠠำหࠥ็๊่ࠢั฻ํืษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสุ์ึฯࠠึฯํัฮ่ࠦๅ้ำหࠥอไิสหࠤ็อๅࠡษ็้อืๅอ่ࠢศ็ะวࠡส่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧઊ"),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧઋ"))
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+wAU9jKvmTM0(u"ࠬࠦࠠࠡࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡵࡪࡨࠤࡩ࡯ࡳ࡬ࠢࡩࡶࡪ࡫ࠠࡴࡲࡤࡧࡪ࠭ઌ"))
		return eu1NswY9zkKC60I
	if LJp6PbnjvSTEGF==WsklGNp2CYzVQUag(u"࠭࠮࡮࠵ࡸ࠼ࠬઍ"):
		nWcb8JC7zEVouFjx9fILGh1vSQ,yyVoU0rfb17SRL5XmGYwDckpnQ3BI9 = uuwHf4DJ2jcAQ1CPUgxZzSsO0E(TVPm7Bz1XOwJ2,hj50MJnoOp6ZWaS1IQ8Elr,KT67DQI1xk9XG34ezN0hH)
		if len(nWcb8JC7zEVouFjx9fILGh1vSQ)==g7yJo2LVuqx1trPe(u"࠶૶"):
			qJAOp7HgfKeMQkDau(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫ઎"),Vk54F7GcROfCy6HunEI)
			return eu1NswY9zkKC60I
		elif len(nWcb8JC7zEVouFjx9fILGh1vSQ)==QYSAUI5r46yil8cfaO(u"࠱૷"): qreJEpY8nZguD = ynxXU3gaiQ9GPCftr1q(u"࠱૸")
		elif len(nWcb8JC7zEVouFjx9fILGh1vSQ)>BBflQamoVNRxMegHLKUvW6s9yAhP(u"࠳ૹ"):
			qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi(pnkrd2S84FJfN73KuiCYv(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭એ"), nWcb8JC7zEVouFjx9fILGh1vSQ)
			if qreJEpY8nZguD == -MzgKWUQ4V5H(u"࠴ૺ") :
				qJAOp7HgfKeMQkDau(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬઐ"),Vk54F7GcROfCy6HunEI)
				return eu1NswY9zkKC60I
		hj50MJnoOp6ZWaS1IQ8Elr = yyVoU0rfb17SRL5XmGYwDckpnQ3BI9[qreJEpY8nZguD]
	icw2kJBfYZeA = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠴ૻ")
	import requests as C56ifaczLBrtO7Vm
	if LJp6PbnjvSTEGF==HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩઑ"):
		XhJu54Ejt8 = XhJu54Ejt8.rsplit(g7yJo2LVuqx1trPe(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ઒"))[ufmXvxgoHGDwZtjsLkR05i]+SSBkx0WbN1asnDCQV6tIj(u"ࠬ࠴࡭ࡱ࠶ࠪઓ")
		aaspUWRrCE4nLAlGf = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,ITXLHQdeVC2icEOAU8hqG470afPB3(u"࠭ࡇࡆࡖࠪઔ"),hj50MJnoOp6ZWaS1IQ8Elr,Vk54F7GcROfCy6HunEI,KT67DQI1xk9XG34ezN0hH,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧક"))
		b0bnNrdiZYhe9sufSECjwcHTyx = aaspUWRrCE4nLAlGf.content
		HXhRgxEZ4d2Dek = RSuYINdeamsK0t.findall(MpJ8GOKoic(u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩખ"),b0bnNrdiZYhe9sufSECjwcHTyx+XCYALgFs2O3hZdpHrlMmB(u"ࠩ࡟ࡲࡡࡸࠧગ"),RSuYINdeamsK0t.DOTALL)
		if not HXhRgxEZ4d2Dek:
			iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+eAMGzHRQVs2KyCwPXljYhB(u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ઘ")+hj50MJnoOp6ZWaS1IQ8Elr+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠫࠥࡣࠧઙ"))
			return eu1NswY9zkKC60I
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = HXhRgxEZ4d2Dek[ufmXvxgoHGDwZtjsLkR05i]
		if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(cpHxZyU7vTtqmIw(u"ࠬ࡮ࡴࡵࡲࠪચ")):
			if ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(pnkrd2S84FJfN73KuiCYv(u"࠭࠯࠰ࠩછ")): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = hj50MJnoOp6ZWaS1IQ8Elr.split(l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"ࠧ࠻ࠩજ"),NNjUsZzEcFOAoKry2CDMgb1(u"࠶ૼ"))[ufmXvxgoHGDwZtjsLkR05i]+g7yJo2LVuqx1trPe(u"ࠨ࠼ࠪઝ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			elif ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(MzgKWUQ4V5H(u"ࠩ࠲ࠫઞ")): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠪࡹࡷࡲࠧટ"))+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = hj50MJnoOp6ZWaS1IQ8Elr.rsplit(eAMGzHRQVs2KyCwPXljYhB(u"ࠫ࠴࠭ઠ"),MpJ8GOKoic(u"࠷૽"))[ufmXvxgoHGDwZtjsLkR05i]+wYTDlJC5vpOKynUEX3ge6W(u"ࠬ࠵ࠧડ")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		aaspUWRrCE4nLAlGf = C56ifaczLBrtO7Vm.request(ogJClMiqPa4A0NUtTxpDVybEWG(u"࠭ࡇࡆࡖࠪઢ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,headers=KT67DQI1xk9XG34ezN0hH,verify=eu1NswY9zkKC60I)
		THrFjQm8yvhDdwt = aaspUWRrCE4nLAlGf.content
		PHl2Y4VTMC8WJoLxwny = len(THrFjQm8yvhDdwt)
		o5jBD2UbLNrF90JT8t6xiCnumZcdXM = len(HXhRgxEZ4d2Dek)
		icw2kJBfYZeA = PHl2Y4VTMC8WJoLxwny*o5jBD2UbLNrF90JT8t6xiCnumZcdXM
	else:
		PHl2Y4VTMC8WJoLxwny = SSBkx0WbN1asnDCQV6tIj(u"࠱૾")*bbYGkvuoSHB52R3TD84ZhmEI
		aaspUWRrCE4nLAlGf = C56ifaczLBrtO7Vm.request(kGjoOpYbcFWrUX1lt5Din40ym6e2(u"ࠧࡈࡇࡗࠫણ"),hj50MJnoOp6ZWaS1IQ8Elr,headers=KT67DQI1xk9XG34ezN0hH,verify=eu1NswY9zkKC60I,stream=YOHXqtbQTBfKerIZ)
		if Nlyfx1HnzOWCovke5(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩત") in aaspUWRrCE4nLAlGf.headers: icw2kJBfYZeA = int(aaspUWRrCE4nLAlGf.headers[SSBkx0WbN1asnDCQV6tIj(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪથ")])
		o5jBD2UbLNrF90JT8t6xiCnumZcdXM = int(icw2kJBfYZeA//PHl2Y4VTMC8WJoLxwny)
	n7fL5mG1vlihA4QWJowuqbk = int(icw2kJBfYZeA//bbYGkvuoSHB52R3TD84ZhmEI)+MpJ8GOKoic(u"࠲૿")
	if icw2kJBfYZeA<l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠴࠴࠴࠵࠶଀"):
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+WXuJd8nz2spo146t(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡴࡰࡱࠣࡷࡲࡧ࡬࡭ࠢࡲࡶࠥ࡯ࡴࠡ࡫ࡶࠤࡲ࠹ࡵ࠹ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬદ")+hj50MJnoOp6ZWaS1IQ8Elr+cpHxZyU7vTtqmIw(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨધ")+str(n7fL5mG1vlihA4QWJowuqbk)+QYSAUI5r46yil8cfaO(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫન")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+kGjoOpYbcFWrUX1lt5Din40ym6e2(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ઩")+XhJu54Ejt8+Nlyfx1HnzOWCovke5(u"ࠧࠡ࡟ࠪપ"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫફ"),WCPwmyVsb62KRlo(u"ࠩไุ้ࠦแ๋่ࠢ฽ึ็ษࠡฯฯ้๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣวํࠦวๅ็็ๅࠥ฻ฺ๋ำࠣะิอ้ࠠๆ๊ิฬࠦไศࠢํ้่์ࠠๅๆหี๋อๅอࠢอั๊๐ไ้ࠡำหࠥอไๆๆไࠫબ"))
		return eu1NswY9zkKC60I
	ggQvqF0fPi21Ay4a = wYTDlJC5vpOKynUEX3ge6W(u"࠷࠴࠵ଁ")
	vYaVR0hqjTF2SbIGMBz = gHNrTGfQpklb2A1MBx8ueo9OJV6Kh-n7fL5mG1vlihA4QWJowuqbk
	if vYaVR0hqjTF2SbIGMBz<ggQvqF0fPi21Ay4a:
		iQlMPpRZXWLd(sD4g6xukbfCjlJHFUaE,ySVOsdu270(TVPm7Bz1XOwJ2)+XCYALgFs2O3hZdpHrlMmB(u"ࠪࠤࠥࠦࡎࡰࡶࠣࡩࡳࡵࡵࡨࡪࠣࡨ࡮ࡹ࡫ࠡࡵࡳࡥࡨ࡫ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩભ")+hj50MJnoOp6ZWaS1IQ8Elr+MpJ8GOKoic(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨમ")+str(n7fL5mG1vlihA4QWJowuqbk)+ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫય")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+SSBkx0WbN1asnDCQV6tIj(u"࠭ࠠࡎࡄࠣ࠱ࠥ࠭ર")+str(ggQvqF0fPi21Ay4a)+ynxXU3gaiQ9GPCftr1q(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ઱")+XhJu54Ejt8+WXuJd8nz2spo146t(u"ࠨࠢࡠࠫલ"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠩ็หࠥ๐่อัุ้ࠣออสࠢๆหๆ๐ษࠡๆ็ฮา๋๊ๅࠩળ"),ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣัั๋็ࠡࠩ઴")+str(n7fL5mG1vlihA4QWJowuqbk)+ogJClMiqPa4A0NUtTxpDVybEWG(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢࠪવ")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+WsklGNp2CYzVQUag(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡ็่๊ำวโฺฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอี่็ุ่ࠢฬ้ไࠡ์ฯฬࠥหศใษฤࠤࠬશ")+str(ggQvqF0fPi21Ay4a)+MpJ8GOKoic(u"࠭ࠠๆ์฽หออ๊หࠢไหึเษࠡัสส๊อ้้ࠠำหู๋ࠥ็ษ๊ࠤศ์ࠠอ้สึ่ࠦไศࠢอ์ัีࠠโ์๊ࠤู๊วฮหࠣ็ฬ็๊สࠢ็ฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศࠨષ"))
		return eu1NswY9zkKC60I
	W8j2OheqsroDJIYzRupt6nG = WfM3l9n0GTFrVaeUxcsktQyJvYIC8(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠧࡤࡧࡱࡸࡪࡸࠧસ"),Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠨ้็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠภࠩહ"),wAU9jKvmTM0(u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢะะ๊ํࠠหไิ๎ออࠠࠨ઺")+str(n7fL5mG1vlihA4QWJowuqbk)+ynxXU3gaiQ9GPCftr1q(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡฬๅี๏ฮวࠡࠩ઻")+str(gHNrTGfQpklb2A1MBx8ueo9OJV6Kh)+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"๋๊ࠫࠥ฻ษหห๏ะ้้ࠠำหࠥอไๆๆไࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ็่ฯำๅ๋ๆ้๋ࠣࠦวๅว้ฮึ์สࠡว็ํࠥา็ศิๆࠤ࠳ࠦ็ๅࠢส๊ฯࠦๅหลๆำࠥ๎สา์าࠤฬ๊วิฬ่ีฬืࠠษฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥล઼ࠧ"))
	if W8j2OheqsroDJIYzRupt6nG!=l4V9IFYOwhBjRNz3oQkEfrpK81s2(u"࠵ଂ"):
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,ynxXU3gaiQ9GPCftr1q(u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪઽ"))
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+MpJ8GOKoic(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨા")+hj50MJnoOp6ZWaS1IQ8Elr+wAU9jKvmTM0(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧિ")+XhJu54Ejt8+ynxXU3gaiQ9GPCftr1q(u"ࠨࠢࡠࠫી"))
		return eu1NswY9zkKC60I
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+YzowicIDTRusXZSU61(u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠧુ"))
	uuyUxZ8tM1 = LfgAx0QSMK59hF()
	uuyUxZ8tM1.create(XhJu54Ejt8,V2RQwM8XjlrK(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫૂ"))
	wZpWd8MYkNatno = YOHXqtbQTBfKerIZ
	TT7ytNUaAEzleV2oMR9j3 = Gb6kwVlSQ4MU.time()
	if not h9zFQKnsNL.qUhMJ0k8yAs:
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,cpHxZyU7vTtqmIw(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧૃ"),WXuJd8nz2spo146t(u"ࠬฮำษสࠣ฽ิ๋ࠠศๆอฬึ฿ࠠห็ࠣษ้เวยࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ૄ"))
		return eu1NswY9zkKC60I
	if PvwFsJK23NbU8XWAx: ShW5HPetFK67wU = open(XhJu54Ejt8,EM6qpnCBYQGA9kbgDVLfrP(u"࠭ࡷࡣࠩૅ"))
	else: ShW5HPetFK67wU = open(XhJu54Ejt8.decode(AoCWwJHgUPKXI7u2lEzym),ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࡸࡤࠪ૆"))
	if LJp6PbnjvSTEGF==MpJ8GOKoic(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧે"):
		for sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz in range(eAMGzHRQVs2KyCwPXljYhB(u"࠶ଃ"),o5jBD2UbLNrF90JT8t6xiCnumZcdXM+eAMGzHRQVs2KyCwPXljYhB(u"࠶ଃ")):
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = HXhRgxEZ4d2Dek[sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz-g7yJo2LVuqx1trPe(u"࠷଄")]
			if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(Nlyfx1HnzOWCovke5(u"ࠩ࡫ࡸࡹࡶࠧૈ")):
				if ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(BBflQamoVNRxMegHLKUvW6s9yAhP(u"ࠪ࠳࠴࠭ૉ")): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = hj50MJnoOp6ZWaS1IQ8Elr.split(HOxJyt7l8osNeCjZFMQGi4Sr(u"ࠫ࠿࠭૊"),wYTDlJC5vpOKynUEX3ge6W(u"࠱ଅ"))[ufmXvxgoHGDwZtjsLkR05i]+ynxXU3gaiQ9GPCftr1q(u"ࠬࡀࠧો")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				elif ssfLBvkuNiXear2gPdxcyT4AQMhYSp.startswith(MzgKWUQ4V5H(u"࠭࠯ࠨૌ")): ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RRav1Sf7Px(hj50MJnoOp6ZWaS1IQ8Elr,kTvOE5l4bwNQ2jsfgFHRDSUIJ(u"ࠧࡶࡴ࡯્ࠫ"))+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				else: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = hj50MJnoOp6ZWaS1IQ8Elr.rsplit(WCPwmyVsb62KRlo(u"ࠨ࠱ࠪ૎"),ynxXU3gaiQ9GPCftr1q(u"࠲ଆ"))[ufmXvxgoHGDwZtjsLkR05i]+YzowicIDTRusXZSU61(u"ࠩ࠲ࠫ૏")+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			aaspUWRrCE4nLAlGf = C56ifaczLBrtO7Vm.request(EM6qpnCBYQGA9kbgDVLfrP(u"ࠪࡋࡊ࡚ࠧૐ"),ssfLBvkuNiXear2gPdxcyT4AQMhYSp,headers=KT67DQI1xk9XG34ezN0hH,verify=eu1NswY9zkKC60I)
			THrFjQm8yvhDdwt = aaspUWRrCE4nLAlGf.content
			aaspUWRrCE4nLAlGf.close()
			ShW5HPetFK67wU.write(THrFjQm8yvhDdwt)
			UL8JQrvutPzAdhNgjcSkb = Gb6kwVlSQ4MU.time()
			OZi2vn1lhpmC = UL8JQrvutPzAdhNgjcSkb-TT7ytNUaAEzleV2oMR9j3
			XxNR3dZlALJY1UzH5VTCOSEfMwau = OZi2vn1lhpmC//sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz
			esdxj7O92LzWYyhticBIRCoD1Gn = XxNR3dZlALJY1UzH5VTCOSEfMwau*(o5jBD2UbLNrF90JT8t6xiCnumZcdXM+pnkrd2S84FJfN73KuiCYv(u"࠳ଇ"))
			PiJjw50fl3st = esdxj7O92LzWYyhticBIRCoD1Gn-OZi2vn1lhpmC
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,int(MpJ8GOKoic(u"࠵࠵࠶ଉ")*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz//(o5jBD2UbLNrF90JT8t6xiCnumZcdXM+SB1nDH5yph4lNCA0JxXkti6rVRcv(u"࠴ଈ"))),g7yJo2LVuqx1trPe(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬ૑"),WCPwmyVsb62KRlo(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ૒"),str(sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz*PHl2Y4VTMC8WJoLxwny//bbYGkvuoSHB52R3TD84ZhmEI)+WCPwmyVsb62KRlo(u"࠭࠯ࠨ૓")+str(n7fL5mG1vlihA4QWJowuqbk)+ITXLHQdeVC2icEOAU8hqG470afPB3(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ૔")+Gb6kwVlSQ4MU.strftime(XCYALgFs2O3hZdpHrlMmB(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ૕"),Gb6kwVlSQ4MU.gmtime(PiJjw50fl3st))+Nlyfx1HnzOWCovke5(u"ࠩࠣไࠬ૖"))
			if uuyUxZ8tM1.iscanceled():
				wZpWd8MYkNatno = eu1NswY9zkKC60I
				break
	else:
		sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz = MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࠵ଊ")
		for THrFjQm8yvhDdwt in aaspUWRrCE4nLAlGf.iter_content(chunk_size=PHl2Y4VTMC8WJoLxwny):
			ShW5HPetFK67wU.write(THrFjQm8yvhDdwt)
			sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz = sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz+QYSAUI5r46yil8cfaO(u"࠷ଋ")
			UL8JQrvutPzAdhNgjcSkb = Gb6kwVlSQ4MU.time()
			OZi2vn1lhpmC = UL8JQrvutPzAdhNgjcSkb-TT7ytNUaAEzleV2oMR9j3
			XxNR3dZlALJY1UzH5VTCOSEfMwau = OZi2vn1lhpmC/sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz
			esdxj7O92LzWYyhticBIRCoD1Gn = XxNR3dZlALJY1UzH5VTCOSEfMwau*(o5jBD2UbLNrF90JT8t6xiCnumZcdXM+V2RQwM8XjlrK(u"࠱ଌ"))
			PiJjw50fl3st = esdxj7O92LzWYyhticBIRCoD1Gn-OZi2vn1lhpmC
			yJabe7zoLFSkXQC5WIPdYf2wEs4VnU(uuyUxZ8tM1,int(SSBkx0WbN1asnDCQV6tIj(u"࠳࠳࠴଎")*sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz/(o5jBD2UbLNrF90JT8t6xiCnumZcdXM+MpJ8GOKoic(u"࠲଍"))),SB1nDH5yph4lNCA0JxXkti6rVRcv(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ૗"),Nlyfx1HnzOWCovke5(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ૘"),str(sRqlPyNg8uiTmBMSXtC5rUF9ohHnIz*PHl2Y4VTMC8WJoLxwny//bbYGkvuoSHB52R3TD84ZhmEI)+g7yJo2LVuqx1trPe(u"ࠬ࠵ࠧ૙")+str(n7fL5mG1vlihA4QWJowuqbk)+g7yJo2LVuqx1trPe(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ૚")+Gb6kwVlSQ4MU.strftime(ttmCxT5RhNl7f8HdjWXwczD9Gvr4(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ૛"),Gb6kwVlSQ4MU.gmtime(PiJjw50fl3st))+WsklGNp2CYzVQUag(u"ࠨࠢใࠫ૜"))
			if uuyUxZ8tM1.iscanceled():
				wZpWd8MYkNatno = eu1NswY9zkKC60I
				break
		aaspUWRrCE4nLAlGf.close()
	ShW5HPetFK67wU.close()
	uuyUxZ8tM1.close()
	if not wZpWd8MYkNatno:
		iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+FGLEMi21Bfn(u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠴࡯࡮ࡵࡧࡵࡶࡺࡶࡴࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡶࡴࡩࡥࡴࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭૝")+hj50MJnoOp6ZWaS1IQ8Elr+XCYALgFs2O3hZdpHrlMmB(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ૞")+XhJu54Ejt8+QYSAUI5r46yil8cfaO(u"ࠫࠥࡣࠧ૟"))
		GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,wAU9jKvmTM0(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨૠ"),WXuJd8nz2spo146t(u"࠭ศฮีหࠤ฼๊ศไࠢอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧૡ"))
		return YOHXqtbQTBfKerIZ
	iQlMPpRZXWLd(yyhLQon4NGP5MpH,ySVOsdu270(TVPm7Bz1XOwJ2)+MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ૢ")+hj50MJnoOp6ZWaS1IQ8Elr+WCPwmyVsb62KRlo(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨૣ")+XhJu54Ejt8+cpHxZyU7vTtqmIw(u"ࠩࠣࡡࠬ૤"))
	GHdYDixegkm9PJMN(Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,MuQX8DgLwzlATjnB94YI0kf6PJhmCV(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭૥"),MzgKWUQ4V5H(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪ૦"))
	return YOHXqtbQTBfKerIZ
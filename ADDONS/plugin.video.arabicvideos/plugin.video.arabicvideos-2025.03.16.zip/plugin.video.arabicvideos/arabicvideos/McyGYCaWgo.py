# -*- coding: utf-8 -*-
from Cqlz6HOy2V import *
TVPm7Bz1XOwJ2 = 'SHIAVOICE'
xzA9sM3rG6IHd7jl8T = '_SHV_'
FFLhlYUAsfJBXeQmRpzD7c14ZP6 = h9zFQKnsNL.SITESURLS[TVPm7Bz1XOwJ2][0]
headers = {'User-Agent':None}
def X42LMUrFfIY3oWeazj(mode,url,text):
	if   mode==310: w8YsNWfQ5gFluRvOmSd4Cb96H = eKWDaEPho9wLl5()
	elif mode==311: w8YsNWfQ5gFluRvOmSd4Cb96H = txsXO7gSMnrwAh6NmJ9D(url)
	elif mode==312: w8YsNWfQ5gFluRvOmSd4Cb96H = h5hmzOAeWEPip(url)
	elif mode==313: w8YsNWfQ5gFluRvOmSd4Cb96H = dsDBEo3OcL405hbJRMGQ7(url)
	elif mode==314: w8YsNWfQ5gFluRvOmSd4Cb96H = DZjbwYA1GS7tsv(text)
	elif mode==319: w8YsNWfQ5gFluRvOmSd4Cb96H = zDkgCMXBmx2A(text)
	else: w8YsNWfQ5gFluRvOmSd4Cb96H = False
	return w8YsNWfQ5gFluRvOmSd4Cb96H
def eKWDaEPho9wLl5():
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+'بحث في الموقع',Vk54F7GcROfCy6HunEI,319,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'_REMEMBERRESULTS_')
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(sT9DURSXlOybaCQ,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-MENU-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('id="menulinks"(.*?)</ul>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	items = RSuYINdeamsK0t.findall('<h5>(.*?)</h5>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL|RSuYINdeamsK0t.IGNORECASE)
	for W7SMIpbzhori2JE9mv in range(len(items)):
		title = items[W7SMIpbzhori2JE9mv].strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,FFLhlYUAsfJBXeQmRpzD7c14ZP6,314,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,str(W7SMIpbzhori2JE9mv+1))
	v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+'مقاطع شهر',FFLhlYUAsfJBXeQmRpzD7c14ZP6,314,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'0')
	v0TjHlLZqkRxUCpmNwSy8AndO('link',nMt0iueCy6K+' ===== ===== ===== '+ZZoLlKyInXc08j2pTGJ,Vk54F7GcROfCy6HunEI,9999)
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?<B>(.*?)</B>',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		v0TjHlLZqkRxUCpmNwSy8AndO('folder',TVPm7Bz1XOwJ2+'_SCRIPT_'+xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,311)
	return FjwObZSWkg8ahBdiQf9IeY135DpXoP
def DZjbwYA1GS7tsv(W7SMIpbzhori2JE9mv):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',FFLhlYUAsfJBXeQmRpzD7c14ZP6,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-LATEST-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	if W7SMIpbzhori2JE9mv=='0':
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="tab-content"(.*?)</table>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		items = RSuYINdeamsK0t.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,name,title in items:
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			title = title+' ('+name+')'
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312)
	elif W7SMIpbzhori2JE9mv in ['1','2','3']:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('(<h5>.*?)<div class="col-lg',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		iXfehComjSvKIsywzc9rlH = int(W7SMIpbzhori2JE9mv)-1
		UwcYSVZbdK3rI = Ry3L7fdNGh[iXfehComjSvKIsywzc9rlH]
		if W7SMIpbzhori2JE9mv=='1': items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		else: items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title,name in items:
			afR4xElWyzgcNAUnKXBempC = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+afR4xElWyzgcNAUnKXBempC
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			title = title+' ('+name+')'
			v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,311,afR4xElWyzgcNAUnKXBempC)
	elif W7SMIpbzhori2JE9mv in ['4','5','6']:
		Ry3L7fdNGh = RSuYINdeamsK0t.findall('(<h5>.*?)</table>',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
		W7SMIpbzhori2JE9mv = int(W7SMIpbzhori2JE9mv)-4
		UwcYSVZbdK3rI = Ry3L7fdNGh[W7SMIpbzhori2JE9mv]
		items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,jjlvNYP47uXIK2,title,KK4WEqy9u1mj in items:
			afR4xElWyzgcNAUnKXBempC = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+afR4xElWyzgcNAUnKXBempC
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			jjlvNYP47uXIK2 = jjlvNYP47uXIK2.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			KK4WEqy9u1mj = KK4WEqy9u1mj.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
			if jjlvNYP47uXIK2: name = jjlvNYP47uXIK2
			else: name = KK4WEqy9u1mj
			title = title+' ('+name+')'
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312,afR4xElWyzgcNAUnKXBempC)
	return
def txsXO7gSMnrwAh6NmJ9D(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-TITLES-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('ibox-heading"(.*?)class="float-right',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	if 'catsum-mobile' in UwcYSVZbdK3rI:
		items = RSuYINdeamsK0t.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		if items:
			for afR4xElWyzgcNAUnKXBempC,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,count in items:
				afR4xElWyzgcNAUnKXBempC = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+afR4xElWyzgcNAUnKXBempC
				ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
				count = count.replace(' الصوتية: ',':')
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = title+' ('+count+')'
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,311,afR4xElWyzgcNAUnKXBempC)
	else:
		items = RSuYINdeamsK0t.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
		for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,z1h39MHj6en5vLWPfgByFZu,GbwM6iseo0ZVlh4ydB in items:
			if title==Vk54F7GcROfCy6HunEI or z1h39MHj6en5vLWPfgByFZu==Vk54F7GcROfCy6HunEI: continue
			ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
			title = title+' ('+GbwM6iseo0ZVlh4ydB+')'
			v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312)
	if not items: SQr4lDstIa0NdFyp7Pf23BG6jnLY(FjwObZSWkg8ahBdiQf9IeY135DpXoP)
	return
def SQr4lDstIa0NdFyp7Pf23BG6jnLY(FjwObZSWkg8ahBdiQf9IeY135DpXoP):
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="ibox-content"(.*?)class="pagination',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,name,count,GbwM6iseo0ZVlh4ydB in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		title = title+' ('+name+')'
		v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312,Vk54F7GcROfCy6HunEI,GbwM6iseo0ZVlh4ydB)
	return
def dsDBEo3OcL405hbJRMGQ7(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-SEARCH_ITEMS-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="ibox-content p-1"(.*?)class="ibox-content"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not Ry3L7fdNGh:
		txsXO7gSMnrwAh6NmJ9D(url)
		return
	UwcYSVZbdK3rI = Ry3L7fdNGh[0]
	items = RSuYINdeamsK0t.findall('href="(.*?)".*?<strong>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
	for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title in items:
		ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/'+ssfLBvkuNiXear2gPdxcyT4AQMhYSp
		title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
		if '/play-' in ssfLBvkuNiXear2gPdxcyT4AQMhYSp: v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312)
		else: v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,311)
	return
def h5hmzOAeWEPip(url):
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(CnJ1ePvdKQ2R,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-PLAY-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('<audio.*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if not ssfLBvkuNiXear2gPdxcyT4AQMhYSp: ssfLBvkuNiXear2gPdxcyT4AQMhYSp = RSuYINdeamsK0t.findall('<video.*?src="(.*?)"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	ssfLBvkuNiXear2gPdxcyT4AQMhYSp = FFLhlYUAsfJBXeQmRpzD7c14ZP6+ssfLBvkuNiXear2gPdxcyT4AQMhYSp[0]
	qnUlyF2JXuGYdSA6Iac1(ssfLBvkuNiXear2gPdxcyT4AQMhYSp,TVPm7Bz1XOwJ2,'video')
	return
def zDkgCMXBmx2A(search):
	search,iwX378tMyTW9KUB,showDialogs = HD6MGAiC4TrtXdc9ge7I(search)
	if search==Vk54F7GcROfCy6HunEI: search = p3bB2auMmSjXC0dE8FUfZ()
	if search==Vk54F7GcROfCy6HunEI: return
	search = search.replace(otBWsSAfu7dihVkP9e1JFKrvmYy2Q,'+')
	oeYL9ZP7s5Xm8MfphaunUirbKSc = ['&t=a','&t=c','&t=s']
	if showDialogs:
		Q4Xc1dSvwKGL = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		qreJEpY8nZguD = LcOJD0oVT1j5KHnbX3amFwueWC9lsi('موقع صوت الشيعة - أختر البحث', Q4Xc1dSvwKGL)
		if qreJEpY8nZguD == -1: return
	elif '_SHIAVOICE-PERSONS_' in iwX378tMyTW9KUB: qreJEpY8nZguD = 0
	elif '_SHIAVOICE-ALBUMS_' in iwX378tMyTW9KUB: qreJEpY8nZguD = 1
	elif '_SHIAVOICE-AUDIOS_' in iwX378tMyTW9KUB: qreJEpY8nZguD = 2
	else: return
	type = oeYL9ZP7s5Xm8MfphaunUirbKSc[qreJEpY8nZguD]
	url = FFLhlYUAsfJBXeQmRpzD7c14ZP6+'/search.php?q='+search+type
	Iy3PA1SVXNfjOchtgHC5kuJBG = LOp5or14udNYRXFKDxwh(ddQIv6q9hTce1iA0nWSX5UuLaNb,'GET',url,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,Vk54F7GcROfCy6HunEI,'SHIAVOICE-SEARCH-1st')
	FjwObZSWkg8ahBdiQf9IeY135DpXoP = Iy3PA1SVXNfjOchtgHC5kuJBG.content
	Ry3L7fdNGh = RSuYINdeamsK0t.findall('class="ibox-content"(.*?)class="ibox-content"',FjwObZSWkg8ahBdiQf9IeY135DpXoP,RSuYINdeamsK0t.DOTALL)
	if Ry3L7fdNGh:
		UwcYSVZbdK3rI = Ry3L7fdNGh[0]
		if qreJEpY8nZguD in [0,1]:
			items = RSuYINdeamsK0t.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,afR4xElWyzgcNAUnKXBempC,title,name in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = title+' ('+name+')'
				v0TjHlLZqkRxUCpmNwSy8AndO('folder',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,313,afR4xElWyzgcNAUnKXBempC)
		elif qreJEpY8nZguD==2:
			items = RSuYINdeamsK0t.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',UwcYSVZbdK3rI,RSuYINdeamsK0t.DOTALL)
			for ssfLBvkuNiXear2gPdxcyT4AQMhYSp,title,name in items:
				title = title.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				name = name.strip(otBWsSAfu7dihVkP9e1JFKrvmYy2Q)
				title = title+' ('+name+')'
				v0TjHlLZqkRxUCpmNwSy8AndO('video',xzA9sM3rG6IHd7jl8T+title,ssfLBvkuNiXear2gPdxcyT4AQMhYSp,312)
	return
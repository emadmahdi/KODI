# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ怩")
headers = l11lll_l1_ (u"࠭ࠧ怪") #{ l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ怫") : l11lll_l1_ (u"ࠨࠩ怬") }
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨ怭")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ怮"),l11lll_l1_ (u"ࠫฬ๊ใๅࠩ怯"),l11lll_l1_ (u"ࠬอแๅษ่ࠫ怰"),l11lll_l1_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ怱"),l11lll_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ怲")]
# l1l1ll11_l1_	https://l1lll1l1l1l11_l1_.l1lll1lll11_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/l1111l1ll111_l1_.net
# l1llll111l1_l1_	https://l1llll111l1_l1_.com/l1lll1l1l11ll_l1_
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1111l_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llllll_l1_(url,True)
	elif mode==114: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ怳")+text)
	elif mode==115: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭怴")+text)
	elif mode==116: results = l1llllll_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1l1lllll1l_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ怵"),l11lll_l1_ (u"ูࠫอ็ะࠢไ์ึ๐่ࠡ࠯ࠣࡗ࡭ࡧࡨࡪࡦࠣ࠸ࡺ࠭怶"),l11lll_l1_ (u"ࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ怷"),headers)
	html = response.content
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怸"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ怹"),l11lll_l1_ (u"ࠨࠩ怺"),119,l11lll_l1_ (u"ࠩࠪ总"),l11lll_l1_ (u"ࠪࠫ怼"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ怽"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怾"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ怿"),l1ll1l1_l1_,115)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ恀"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ恁"),l1ll1l1_l1_,114)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ恂"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恃"),l11lll_l1_ (u"ࠫࠬ恄"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ恅"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ恆"),l1ll1l1_l1_,111,l11lll_l1_ (u"ࠧࠨ恇"),l11lll_l1_ (u"ࠨࠩ恈"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ恉"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷ࡮ࡳࡰ࡭ࡧ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡢࡦࡹ࠱࡫࡯࡬ࡵࡧࡵࠫ恊"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ恋"),l11lll_l1_ (u"ࠬ࠭恌"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨ恍"),l11lll_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥห๊อษาࠤ฾์่ศ่ࠣห้๋่ใ฻ࠣวํࠦสึ็ํ้ࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠪ恎"))
		return
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡁࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ恏"),block,re.DOTALL)
		for filter,l1llll_l1_,title in items:
			url = l1ll1l1_l1_+filter
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ恐"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ恑")+l111ll_l1_+title,url,111,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ恒"),filter)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ恓"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭恔"),l11lll_l1_ (u"ࠧࠨ恕"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࡀࠪ恖"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ恗"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭恘"),l11lll_l1_ (u"ࠫࠬ恙")).replace(l11lll_l1_ (u"ࠬࡢࡲࠨ恚"),l11lll_l1_ (u"࠭ࠧ恛")).strip(l11lll_l1_ (u"ࠧࠡࠩ恜"))
			if title in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭恝") not in link: link = l1ll1l1_l1_+link
			if l11lll_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ恞") in link: title = l11lll_l1_ (u"๊ࠪ๏ะแๅๅึࠫ恟")
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ恠"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ恡")+l111ll_l1_+title,link,111)
	return html
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"࠭ࠧ恢"),response=l11lll_l1_ (u"ࠧࠨ恣")):
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ恤"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ恥")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ恦"),url,l11lll_l1_ (u"ࠫࠬ恧"),headers,l11lll_l1_ (u"ࠬ࠭恨"),l11lll_l1_ (u"࠭ࠧ恩"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭恪"))
	html = response.content
	l1l1ll1_l1_,items,l1l1_l1_ = [],[],[]
	if l1lll1ll11_l1_==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ恫"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡪࡰ࡮ࡪࡥࡠࡡࡶࡰ࡮ࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ恬"),html,re.DOTALL)
	#elif l1lll1ll11_l1_==l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ恭"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡒ࡫ࡤࡪࡣࡊࡶ࡮ࡪࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ恮"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡨࡰࡹࡶ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ息"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#if l1lll1ll11_l1_==l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭恰"): items = re.findall(l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ恱"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ恲"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ恳"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ恴"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ恵"),l11lll_l1_ (u"้ࠬไ๋สࠪ恶"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ恷"),l11lll_l1_ (u"่ࠧัสๅࠬ恸"),l11lll_l1_ (u"ࠨ็หหึอษࠨ恹"),l11lll_l1_ (u"ࠩ฼ี฻࠭恺"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ恻"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ恼")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ恽") in link: continue
		#if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ恾") in link: continue
		#link = link.replace(l11lll_l1_ (u"ࠧࠧࠥ࠳࠷࠽ࡁࠧ恿"),l11lll_l1_ (u"ࠨࠨࠪ悀"))
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ悁"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ悂"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ悃"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ悄") in link or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ悅"),l111ll_l1_+title,link,112,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ悆") in title and l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ悇") not in url:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ悈") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悉"),l111ll_l1_+title,link,113,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵ࠳ࠬ悊") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悋"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ悌") in link and l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭悍") not in url:
			link = link+l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ悎")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ悏"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ悐") in url and l11lll_l1_ (u"ࠫา๊โสࠩ悑") in title:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ悒"),l111ll_l1_+title,link,112,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭悓"),l111ll_l1_+title,link,113,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ悔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ悕"): items = re.findall(l11lll_l1_ (u"ࠩࠫࡹࡵࡪࡡࡵࡧࡔࡹࡪࡸࡹࠪ࠰࠭ࡃࡃ࠮࠮ࠬࡁࠬࡀࠬ悖"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ悗"),block,re.DOTALL)
		for link,title in items:
			if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ悘"):
				title = title.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ悙"),l11lll_l1_ (u"࠭ࠧ悚")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ悛"),l11lll_l1_ (u"ࠨࠩ悜"))
				if l11lll_l1_ (u"ࠩࡂࠫ悝") in url: link = url+l11lll_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ悞")+title
				else: link = url+l11lll_l1_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫ悟")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悠"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ悡")+title,link,111,l11lll_l1_ (u"ࠧࠨ悢"),l11lll_l1_ (u"ࠨࠩ患"),l1lll1ll11_l1_)
	return
def l1llllll_l1_(url,l1lll1l1l11l1_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭悤"),url,l11lll_l1_ (u"ࠪࠫ悥"),headers,l11lll_l1_ (u"ࠫࠬ悦"),l11lll_l1_ (u"ࠬ࠭悧"),l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ您"))
	html = response.content
	# l1lllll_l1_ & l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡶࡨࡱࡸࠦࡤ࠮ࡨ࡯ࡩࡽ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ悩"),html,re.DOTALL)
	if len(l1l1ll1_l1_)>1:
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ悪") in l1l1ll1_l1_[0]: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[1]
		else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[1],l1l1ll1_l1_[0]
	else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[0]
	for l11ll111l1_l1_ in range(2):
		if l1lll1l1l11l1_l1_: mode,type,block = 116,l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ悫"),l1lllll_l1_
		else: mode,type,block = 112,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ悬"),l1l1l_l1_
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ悭"),block,re.DOTALL)
		if l1lll1l1l11l1_l1_ and len(items)<2:
			l1lll1l1l11l1_l1_ = False
			continue
		for link,l11l1ll11_l1_,l1lll1lll_l1_ in items:
			title = l11l1ll11_l1_+l11lll_l1_ (u"ࠬࠦࠧ悮")+l1lll1lll_l1_
			addMenuItem(type,l111ll_l1_+title,link,mode)
		break
	# l1l1l_l1_ l11l1ll1_l1_
	if not items and l11lll_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ悯") in html:
		l1l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡴࡨࡥࡩࡩࡲࡶ࡯ࡥࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ悰"),html,re.DOTALL)
		if l1l1l111l_l1_:
			block = l1l1l111l_l1_[0]
			links = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ悱"),block,re.DOTALL)
			if len(links)>2:
				link = links[2]+l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ悲")
				l1111l_l1_(link)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ悳"),url,l11lll_l1_ (u"ࠫࠬ悴"),headers,l11lll_l1_ (u"ࠬ࠭悵"),l11lll_l1_ (u"࠭ࠧ悶"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ悷"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡦࡸ࡮ࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭悸"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ悹"),block,re.DOTALL)
	l11l1ll1l_l1_ = l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ悺") in block
	download = l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ悻") in block
	if   l11l1ll1l_l1_ and not download: l1lll1l1l1l1l_l1_,l11l11l11l1l_l1_ = links[0],l11lll_l1_ (u"ࠬ࠭悼")
	elif not l11l1ll1l_l1_ and download: l1lll1l1l1l1l_l1_,l11l11l11l1l_l1_ = l11lll_l1_ (u"࠭ࠧ悽"),links[0]
	elif l11l1ll1l_l1_ and download: l1lll1l1l1l1l_l1_,l11l11l11l1l_l1_ = links[0],links[1]
	else: l1lll1l1l1l1l_l1_,l11l11l11l1l_l1_ = l11lll_l1_ (u"ࠧࠨ悾"),l11lll_l1_ (u"ࠨࠩ悿")
	# l11l1ll1l_l1_
	if l11l1ll1l_l1_:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭惀"),l1lll1l1l1l1l_l1_,l11lll_l1_ (u"ࠪࠫ惁"),headers,l11lll_l1_ (u"ࠫࠬ惂"),l11lll_l1_ (u"ࠬ࠭惃"),l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ惄"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡭ࡧࡷࠤࡸ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫࡳࡰࡦࡿࡥࡳࠩ情"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ惆"),l11l1_l1_,re.DOTALL)
			for title,link in l1l1lll_l1_:
				link = link.replace(l11lll_l1_ (u"ࠩ࡟ࡠ࠴࠭惇"),l11lll_l1_ (u"ࠪ࠳ࠬ惈"))
				link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ惉")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭惊")
				l1111_l1_.append(link)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ惋"),l11l11l11l1l_l1_,l11lll_l1_ (u"ࠧࠨ惌"),headers,l11lll_l1_ (u"ࠨࠩ惍"),l11lll_l1_ (u"ࠩࠪ惎"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ惏"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭࡮ࡴࡦࡰ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ惐"),l11lll1l_l1_,re.DOTALL)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭惑"),l11l1_l1_,re.DOTALL)
			for link,title,l11l111l_l1_ in l1l1lll_l1_:
				link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ惒")+title+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ惓")+l11lll_l1_ (u"ࠨࡡࡢࡣࡤ࠭惔")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ惕"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ惖"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭惗"),l11lll_l1_ (u"ࠬ࠱ࠧ惘"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ惙")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1l1lllll1l_l1_(url,l11lll_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ惚"),l11lll_l1_ (u"ࠨึส๋ิࠦแ้ำํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪࠠ࠵ࡷࠪ惛"),l11lll_l1_ (u"ࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩ惜"),headers)
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ惝"),l1ll111ll_l1_)
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ惞"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ惟"),url,l11lll_l1_ (u"࠭ࠧ惠"),headers,l11lll_l1_ (u"ࠧࠨ惡"),l11lll_l1_ (u"ࠨࠩ惢"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭惣"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭惤"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࠩ惥"),block,re.DOTALL)
		l1llll1llll_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1llll1llll_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿࡞ࡶ࠮࠭࠴ࠪࡀࠫ࡟ࡷ࠯ࡂࠧ惦"),block,re.DOTALL)
	return items
def l1llll1l1l1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"࠭ࡣࡢࡶࡀࠫ惧"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ惨"))
	if l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ惩") not in url: url = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭惪")
	l1llllll11_l1_ = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ惫"))[0]
	l1llll1lll_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ惬"))
	url = url.replace(l1llllll11_l1_,l1llll1lll_l1_)
	#url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ惭"),l11lll_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪ惮"))
	url = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ惯"),l11lll_l1_ (u"ࠨ࠱ࡂࠫ惰"))
	return url
l1lllll1l11_l1_ = [l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ惱"),l11lll_l1_ (u"ࠪࡽࡪࡧࡲࠨ惲"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ想"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ惴")]
l1lllll1l1l_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ惵"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭惶"),l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭惷")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ惸"),l11lll_l1_ (u"ࠪࠫ惹"))
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ惺"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ惻"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ惼"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ惽"),l11lll_l1_ (u"ࠨࠩ惾")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭惿"))
	if type==l11lll_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ愀"):
		if l1lllll1l1l_l1_[0]+l11lll_l1_ (u"ࠫࡂ࠭愁") not in l1l11l1l_l1_: category = l1lllll1l1l_l1_[0]
		for i in range(len(l1lllll1l1l_l1_[0:-1])):
			if l1lllll1l1l_l1_[i]+l11lll_l1_ (u"ࠬࡃࠧ愂") in l1l11l1l_l1_: category = l1lllll1l1l_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ愃")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ愄")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ愅")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ愆")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ愇"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ愈")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ愉"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ愊"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ愋")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭愌"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ愍"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠪࠫ愎"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ意"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠬ࠭愐"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ愑")+l1l11l11_l1_
		l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ愒"),l111ll_l1_+l11lll_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ愓"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ愔"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ愕")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ愖"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ愗"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭愘"),l11lll_l1_ (u"ࠧࠨ愙"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠨๅ็ࠤࠬ愚"),l11lll_l1_ (u"ࠩࠪ愛"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠪࡁࠬ愜") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ愝"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ愞")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭感"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ愠"),l11l1l1_l1_,111)
				else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ愡"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ愢"),l11l11l_l1_,115,l11lll_l1_ (u"ࠪࠫ愣"),l11lll_l1_ (u"ࠫࠬ愤"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ愥"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ愦")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ愧")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ愨")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ愩")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ愪")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ愫"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ愬")+name,l11l11l_l1_,114,l11lll_l1_ (u"࠭ࠧ愭"),l11lll_l1_ (u"ࠧࠨ愮"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ愯"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ愰"): option = l11lll_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ愱")
			elif value==l11lll_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ愲"): option = l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ愳")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ愴") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ愵"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ愶")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ愷")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ愸")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭愹")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ愺")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩ愻")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠧ࠱ࠩ愼")]
			title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫ愽")+name
			if type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ愾"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愿"),l111ll_l1_+title,url,114,l11lll_l1_ (u"ࠫࠬ慀"),l11lll_l1_ (u"ࠬ࠭慁"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ慂"))
			elif type==l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ慃") and l1lllll1l1l_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࠪ慄") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ慅"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ慆")+l1l1111l_l1_
				l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ慇"),l111ll_l1_+title,l11l1l1_l1_,111)
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ慈"),l111ll_l1_+title,url,115,l11lll_l1_ (u"࠭ࠧ慉"),l11lll_l1_ (u"ࠧࠨ慊"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ態")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ慌")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧ慍")					all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠫࡂࠬࠧ慎"),l11lll_l1_ (u"ࠬࡃ࠰ࠧࠩ慏"))
	filters = filters.strip(l11lll_l1_ (u"࠭ࠦࠨ慐"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠧ࠾ࠩ慑") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠪ慒"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࠫ慓"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠪࠫ慔")
	for key in l1lllll1l11_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠫ࠵࠭慕")
		if l11lll_l1_ (u"ࠬࠫࠧ慖") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ慗") and value!=l11lll_l1_ (u"ࠧ࠱ࠩ慘"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ慙")+value
		elif mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ慚") and value!=l11lll_l1_ (u"ࠪ࠴ࠬ慛"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭慜")+key+l11lll_l1_ (u"ࠬࡃࠧ慝")+value
		elif mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪ慞"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ慟")+key+l11lll_l1_ (u"ࠨ࠿ࠪ慠")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭慡"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ慢"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠫࡂ࠶ࠧ慣"),l11lll_l1_ (u"ࠬࡃࠧ慤"))
	return l1ll1l1l_l1_
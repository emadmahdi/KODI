# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ掙")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪ掚")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllllll_l1_ = l1ll11l_l1_[script_name][1]
l1l11ll1lll_l1_ = l1ll11l_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1111l_l1_(url)
	elif mode==52: results = l1llllll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1lll1l11l111_l1_()
	elif mode==56: results = l1lll1l111l1l_l1_()
	elif mode==57: results = l1lll11ll1l_l1_(url,1)
	elif mode==58: results = l1lll11ll1l_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ掛"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭掜"),l11lll_l1_ (u"ࠧࠨ掝"),59,l11lll_l1_ (u"ࠨࠩ掞"),l11lll_l1_ (u"ࠩࠪ掟"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ掠"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ採"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ探"),l11lll_l1_ (u"࠭ࠧ掣"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ掤"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ接")+l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠬ掦"),l11lll_l1_ (u"ࠪࠫ控"),56)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ推"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ掩")+l111ll_l1_+l11lll_l1_ (u"࠭วๅษไ่ฬ๋ࠧ措"),l11lll_l1_ (u"ࠧࠨ掫"),55)
	return l11lll_l1_ (u"ࠨࠩ掬")
def l1lll1l11l111_l1_():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掭"),l111ll_l1_+l11lll_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩ掮"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵࡮ࡦࡹࡨࡷࡹ࠭掯"),51)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ掰"),l111ll_l1_+l11lll_l1_ (u"࠭วโๆส้ࠥืววฮฬࠫ掱"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪ掲"),51)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ掳"),l111ll_l1_+l11lll_l1_ (u"ࠩสาึࠦวืษไหฯࠦวๅษไ่ฬ๋ࠧ掴"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡲࡡࡵࡧࡶࡸࠬ掵"),51)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ掶"),l111ll_l1_+l11lll_l1_ (u"ࠬอแๅษ่ࠤ่๊วิ์ๆ๎ฮ࠭掷"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡥ࡯ࡥࡸࡹࡩࡤࠩ掸"),51)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ掹"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ掺"),l11lll_l1_ (u"ࠩࠪ掻"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ掼"),l111ll_l1_+l11lll_l1_ (u"ࠫฬิส๋ษิࠤฬ็ไศ็้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ掽"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡺࡱࡳࠫ掾"),57)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭掿"),l111ll_l1_+l11lll_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ揀"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡶࡪࡼࡩࡦࡹࠪ揁"),57)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ揂"),l111ll_l1_+l11lll_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ揃"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡶࡪࡧࡺࡷࠬ揄"),57)
	return
def l1lll1l111l1l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ揅"),l111ll_l1_+l11lll_l1_ (u"࠭วฮัฮࠤฬ๊ๅิๆึ่ฬะࠧ揆"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡲࡪࡽࡥࡴࡶࠪ揇"),51)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ揈"),l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠣีฬฬฬสࠩ揉"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡰࡰࡲࡸࡰࡦࡸࠧ揊"),51)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ揋"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮาࠢสฺฬ็วหࠢสู่๊ไิๆสฮࠬ揌"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱࡯ࡥࡹ࡫ࡳࡵࠩ揍"),51)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揎"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢๆ่ฬู๊ไ์ฬࠫ描"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡩ࡬ࡢࡵࡶ࡭ࡨ࠭提"),51)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ揑"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ插"),l11lll_l1_ (u"ࠬ࠭揓"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭揔"),l111ll_l1_+l11lll_l1_ (u"ࠧศะอ๎ฬืࠠๆี็ื้อสࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭揕"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡾࡵࡰࠨ揖"),57)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ揗"),l111ll_l1_+l11lll_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ揘"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡳࡧࡹ࡭ࡪࡽࠧ揙"),57)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ揚"),l111ll_l1_+l11lll_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ換"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡺ࡮࡫ࡷࡴࠩ揜"),57)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ揝"),l11lll_l1_ (u"ࠩࠪ揞"),url,url)
	if l11lll_l1_ (u"ࠪࡃࠬ揟") in url:
		parts = url.split(l11lll_l1_ (u"ࠫࡄ࠭揠"))
		url = parts[0]
		filter = l11lll_l1_ (u"ࠬࡅࠧ握") + QUOTE(parts[1],l11lll_l1_ (u"࠭࠽ࠧ࠼࠲ࠩࠬ揢"))
	else: filter = l11lll_l1_ (u"ࠧࠨ揣")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ揤"),l11lll_l1_ (u"ࠩࠪ揥"),filter,l11lll_l1_ (u"ࠪࠫ揦"))
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭揧"))
	sort,l1l11l1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11lll_l1_ (u"ࠬࡿ࡯ࡱࠩ揨"),l11lll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭揩"),l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡸ࠭揪")]:
		if type==l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ揫"): l11lll1l1_l1_=l11lll_l1_ (u"ࠩไ๎้๋ࠧ揬")
		elif type==l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ揭"): l11lll1l1_l1_=l11lll_l1_ (u"ู๊ࠫไิๆࠪ揮")
		#url = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡷࡩࡷ࠳ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩ揯") + QUOTE(l11lll1l1_l1_) + l11lll_l1_ (u"࠭࠯ࠨ揰") + l1l11l1_l1_ + l11lll_l1_ (u"ࠧ࠰ࠩ揱") + sort + filter
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩ揲") + QUOTE(l11lll1l1_l1_) + l11lll_l1_ (u"ࠩ࠲ࠫ揳") + l1l11l1_l1_ + l11lll_l1_ (u"ࠪ࠳ࠬ援") + sort + filter
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ揵"),l11lll_l1_ (u"ࠬ࠭揶"),l11lll_l1_ (u"࠭ࠧ揷"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ揸"),l11lll_l1_ (u"ࠨࠩ揹"),l11lll_l1_ (u"ࠩࠪ揺"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ揻"))
		#items = re.findall(l11lll_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡲࡺࡳࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡶࡪࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ揼"),html,re.DOTALL)
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡱࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡶࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡳࡶࡪࡹࡢࡢࡵࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭揽"),html,re.DOTALL)
		l1l11l1ll11_l1_=0
		for id,title,l1lll1l11111l_l1_,l1llll_l1_ in items:
			l1l11l1ll11_l1_ += 1
			#l1llll_l1_ = l11lllllll_l1_ + l11lll_l1_ (u"࠭࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭揾") + l1llll_l1_ + l11lll_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ揿")
			l1llll_l1_ = l1l11ll1lll_l1_ + l11lll_l1_ (u"ࠨ࠱ࡹ࠶࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࡱࡦ࡯࡮࠰ࠩ搀") + l1llll_l1_ + l11lll_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ搁")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭搂") + id
			if type==l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ搃"): addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ搄"),l111ll_l1_+title,link,53,l1llll_l1_)
			if type==l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭搅"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ搆"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊ࠠࠨ搇")+title,link+l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ搈")+l1lll1l11111l_l1_+l11lll_l1_ (u"ࠪࡁࠬ搉")+title+l11lll_l1_ (u"ࠫࡂ࠭搊")+l1llll_l1_,52,l1llll_l1_)
	else:
		if type==l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ搋"): l11lll1l1_l1_=l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭搌")
		elif type==l11lll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ損"): l11lll1l1_l1_=l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ搎")
		url = l11lllllll_l1_ + l11lll_l1_ (u"ࠩ࠲࡮ࡸࡵ࡮࠰ࡵࡨࡰࡪࡩࡴࡦࡦ࠲ࠫ搏") + sort + l11lll_l1_ (u"ࠪ࠱ࠬ搐") + l11lll1l1_l1_ + l11lll_l1_ (u"ࠫ࠲࡝ࡗ࠯࡬ࡶࡳࡳ࠭搑")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭搒"),l11lll_l1_ (u"࠭ࠧ搓"),l11lll_l1_ (u"ࠧࠨ搔"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ搕"))
		items = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ搖"),html,re.DOTALL)
		l1l11l1ll11_l1_=0
		for id,l1lll1l11111l_l1_,l1llll_l1_,title in items:
			l1l11l1ll11_l1_ += 1
			l1llll_l1_ = l11lllllll_l1_ + l11lll_l1_ (u"ࠪ࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ搗") + l1llll_l1_ + l11lll_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ搘")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ搙") + id
			if type==l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ搚"): addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭搛"),l111ll_l1_+title,link,53,l1llll_l1_)
			elif type==l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ搜"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ搝"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪ搞")+title,link+l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ搟")+l1lll1l11111l_l1_+l11lll_l1_ (u"ࠬࡃࠧ搠")+title+l11lll_l1_ (u"࠭࠽ࠨ搡")+l1llll_l1_,52,l1llll_l1_)
	title=l11lll_l1_ (u"ࠧึใะอࠥ࠭搢")
	if l1l11l1ll11_l1_==16:
		for l1l11lll111_l1_ in range(1,13) :
			if not l1l11l1_l1_==str(l1l11lll111_l1_):
				#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠯ࡳࡶࡴ࡭ࡲࡢ࡯ࡶ࠳ࠬ搣")+type+l11lll_l1_ (u"ࠩ࠲ࠫ搤")+str(l1l11lll111_l1_)+l11lll_l1_ (u"ࠪ࠳ࠬ搥")+sort + filter
				url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ搦")+type+l11lll_l1_ (u"ࠬ࠵ࠧ搧")+str(l1l11lll111_l1_)+l11lll_l1_ (u"࠭࠯ࠨ搨")+sort + filter
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ搩"),l111ll_l1_+title+str(l1l11lll111_l1_),url,51)
	return
def l1llllll_l1_(url):
	parts = url.split(l11lll_l1_ (u"ࠨ࠿ࠪ搪"))
	l1lll1l11111l_l1_ = int(parts[1])
	name = l111l_l1_(parts[2])
	name = name.replace(l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ搫"),l11lll_l1_ (u"ࠪࠫ搬"))
	l1llll_l1_ = parts[3]
	url = url.split(l11lll_l1_ (u"ࠫࡄ࠭搭"))[0]
	if l1lll1l11111l_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭搮"),l11lll_l1_ (u"࠭ࠧ搯"),l11lll_l1_ (u"ࠧࠨ搰"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ搱"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ搲"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ搳"),block,re.DOTALL)
		l1lll1l11111l_l1_ = int(items[-1])
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ搴"),l11lll_l1_ (u"ࠬ࠭搵"),l1lll1l11111l_l1_,l11lll_l1_ (u"࠭ࠧ搶"))
	#name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠣ搷") )
	#l1llll_l1_ = xbmc.getInfoLabel( l11lll_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠤ搸") )
	for l1lll11_l1_ in range(l1lll1l11111l_l1_,0,-1):
		link = url + l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ搹") + str(l1lll11_l1_)
		title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ携")+name+l11lll_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ搻")+str(l1lll11_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ搼"),l111ll_l1_+title,link,53,l1llll_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧ搽"),l11lll_l1_ (u"ࠧࠨ搾"),l11lll_l1_ (u"ࠨࠩ搿"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭摀"))
	l1lll1l111l11_l1_ = re.findall(l11lll_l1_ (u"้ࠪฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำ࠳࠰࠿࡮ࡱࡰࡩࡳࡺ࡜ࠩࠤࠫ࠲࠯ࡅࠩࠣࠩ摁"),html,re.DOTALL)
	if l1lll1l111l11_l1_:
		time = l1lll1l111l11_l1_[1].replace(l11lll_l1_ (u"࡙ࠫ࠭摂"),l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ摃"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ摄"),l11lll_l1_ (u"ࠧࠨ摅"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠪ摆"),l11lll_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠิ์ๆ์๋ࠦๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ้ࠡำหࠥอไ้ไอࠫ摇")+l11lll_l1_ (u"ࠪࡠࡳ࠭摈")+time)
		return
	#if l11lll_l1_ (u"๋ࠫ฿สัำࠣ฽้๏้ࠠไ๋฽ࠥิืฤࠩ摉") in html:
	#	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭摊"),l11lll_l1_ (u"࠭ࠧ摋"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩ摌"),l11lll_l1_ (u"ࠨ่฼ฮีืฺࠠๆ์ࠤํฺ่่ࠢั฻ศ࠭摍"))
	#	return
	l1lll11llllll_l1_,l1lll1l111ll1_l1_ = [],[]
	l1lll1l111lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ摎"),html,re.DOTALL)[0]
	l1lll1l1111ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ摏"),html,re.DOTALL)[0]
	# l1llll1l1_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ摐"),html,re.DOTALL)
	for server,link in links:
		if l11lll_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ摑") in server:
			server = l11lll_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭摒")
			url = l1lll1l1111ll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ摓")
			url = l1lll1l111lll_l1_ + link
		if l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ摔") in url:
			l1lll11llllll_l1_.append(url)
			l1lll1l111ll1_l1_.append(l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ摕")+server)
		l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸ࠩࡷࡵࡰ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟ࡶࡴ࡯࠲ࡦࡶࡰࡦࡰࡧࠬࡺࡸ࡬ࠪࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡴࡡ࡮ࡧ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫࡲ࠹ࡵ࠹ࠢࠣࠫ࠰ࡹࡥࡳࡸࡨࡶ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡣࡱ࡫ࡪ࠮࡬ࡦࡰࠫࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠩ࠻ࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥࡵࡳ࡮࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡠ࡯࡝ࠪࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹࡿࡰࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡷࡵࡲࡩࡵࠪࠪࠤࠬ࠯࡛࠱࡟ࠍࠍࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࡩ࡭ࡱ࡫ࡴࡺࡲࡨ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠡࠢࠣࠫ࠱࠭ࠠࠡࠩࠬࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡰࡤࡱࡪ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡦࡪ࡮ࡨࡸࡾࡶࡥࠬࠩࠣࠤࠬ࠱ࡳࡦࡴࡹࡩࡷ࠱ࠧࠡࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠢࠣࠤ摖")
	# l1111lll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡤࡲࡩ࡯࡭࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭摗"),html,re.DOTALL)
	links += re.findall(l11lll_l1_ (u"ࠬࡳࡰ࠵࠼࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭摘"),html,re.DOTALL)
	for server,link in links:
		filename = link.split(l11lll_l1_ (u"࠭࠯ࠨ摙"))[-1]
		filename = filename.replace(l11lll_l1_ (u"ࠧࡧࡣ࡯ࡰࡧࡧࡣ࡬ࠩ摚"),l11lll_l1_ (u"ࠨࠩ摛"))
		filename = filename.replace(l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ摜"),l11lll_l1_ (u"ࠪࠫ摝"))
		filename = filename.replace(l11lll_l1_ (u"ࠫ࠲࠭摞"),l11lll_l1_ (u"ࠬ࠭摟"))
		if l11lll_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵ࠭摠") in server:
			server = l11lll_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠠࡴࡧࡵࡺࡪࡸࠧ摡")
			url = l1lll1l1111ll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠭摢")
			url = l1lll1l111lll_l1_ + link
		l1lll11llllll_l1_.append(url)
		l1lll1l111ll1_l1_.append(l11lll_l1_ (u"ࠩࡰࡴ࠹ࠦࠠࠨ摣")+server+l11lll_l1_ (u"ࠪࠤࠥ࠭摤")+filename)
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤ࡛࡯ࡤࡦࡱࠣࡕࡺࡧ࡬ࡪࡶࡼ࠾ࠬ摥"), l1lll1l111ll1_l1_)
	if l1l_l1_ == -1 : return
	url = l1lll11llllll_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ摦"))
	return
def l1lll11ll1l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ摧"),l11lll_l1_ (u"ࠧࠨ摨"),url,url)
	if l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ摩") in url: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ摪")
	else: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ摫")
	l11l11l_l1_ = QUOTE(l11l11l_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ摬"),l11lll_l1_ (u"ࠬ࠭摭"),l11lll_l1_ (u"࠭ࠧ摮"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ摯"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ摰"),l11lll_l1_ (u"ࠩࠪ摱"),url,html)
	if type==1: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡺࡨࡧࡦࡰࡵࡩ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭摲"),html,re.DOTALL)
	elif type==2: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭摳"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࠬ摴"),block,re.DOTALL)
	if type==1:
		for l1lll1l111111_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭摵"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠧࡀࡵࡸࡦ࡬࡫࡮ࡳࡧࡀࠫ摶")+l1lll1l111111_l1_,58)
	elif type==2:
		url,l1lll1l111111_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࠪ摷"))
		for l1ll111l1l1l_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ摸"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠪࡃࡨࡵࡵ࡯ࡶࡵࡽࡂ࠭摹")+l1ll111l1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭摺")+l1lll1l111111_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭摻"),l11lll_l1_ (u"࠭ࠧ摼"),search,search)
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ摽"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ摾"))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭摿"), l11ll1_l1_, l11lll_l1_ (u"ࠪࠫ撀"), l11lll_l1_ (u"ࠫࠬ撁"), True,l11lll_l1_ (u"ࠬ࠭撂"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ撃"))
	#html = response.content
	#cookies = response.cookies
	#l11l1l1l1_l1_ = cookies[l11lll_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࠨ撄")]
	#l1lll1l1111l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡥࡶࡶ࡫ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ撅"),html,re.DOTALL)
	#l1lll1l1111l1_l1_ = l1lll1l1111l1_l1_[0]
	#payload = l11lll_l1_ (u"ࠩࡢࡧࡸࡸࡦ࠾ࠩ撆") + l1lll1l1111l1_l1_ + l11lll_l1_ (u"ࠪࠪࡶࡃࠧ撇") + QUOTE(l111l1l_l1_)
	#headers = { l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ撈"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ撉") , l11lll_l1_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭撊"):l11lll_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠩ撋")+l11l1l1l1_l1_ }
	#url = l11ll1_l1_ + l11lll_l1_ (u"ࠣ࠱ࡶࡩࡦࡸࡣࡩࠤ撌")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ撍"), url, payload, headers, True,l11lll_l1_ (u"ࠪࠫ撎"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠲࡯ࡦࠪ撏"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ撐")+l111l1l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ撑"),url,l11lll_l1_ (u"ࠧࠨ撒"),l11lll_l1_ (u"ࠨࠩ撓"),True,l11lll_l1_ (u"ࠩࠪ撔"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ撕"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ撖"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ撗"),block,re.DOTALL)
	if items:
		for link,l1llll_l1_,title in items:
			#title = title.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ撘")).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ撙"))
			url = l11ll1_l1_ + link
			if l11lll_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ撚") in url:
				if l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ撛") in url:
					title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ撜")+title
					url = url.replace(l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾࠳ࠪ撝"),l11lll_l1_ (u"ࠬࡅࡥࡱ࠿࠳ࠫ撞"))
					url = url+l11lll_l1_ (u"࠭࠽ࠨ撟")+QUOTE(title)+l11lll_l1_ (u"ࠧ࠾ࠩ撠")+l1llll_l1_
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撡"),l111ll_l1_+title,url,52,l1llll_l1_)
				else:
					title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟โ์็้ࠥ࠭撢")+title
					addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ撣"),l111ll_l1_+title,url,53,l1llll_l1_)
	#else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ撤"),l11lll_l1_ (u"ࠬ࠭撥"),l11lll_l1_ (u"࠭࡮ࡰࠢࡵࡩࡸࡻ࡬ࡵࡵࠪ撦"),l11lll_l1_ (u"ࠧๅษࠣฮําฯ่ࠡอหหาࠠๅๆหัะ࠭撧"))
	return
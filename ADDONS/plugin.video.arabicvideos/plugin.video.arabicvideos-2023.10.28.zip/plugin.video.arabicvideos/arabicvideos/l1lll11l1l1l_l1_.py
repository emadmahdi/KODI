# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ敍")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ敎")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧษอ้ࠣออิาࠩ敏")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l1111l_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llllll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ敐"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ救"),l11lll_l1_ (u"ࠪࠫ敒"),l11lll_l1_ (u"ࠫࠬ敓"),l11lll_l1_ (u"ࠬ࠭敔"),l11lll_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ敕"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ敖"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ敗"),l11lll_l1_ (u"ࠩࠪ敘"),469,l11lll_l1_ (u"ࠪࠫ教"),l11lll_l1_ (u"ࠫࠬ敚"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ敛"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭敜"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ敝")+l111ll_l1_+l11lll_l1_ (u"ࠨลัีࠥอไฮๆๅหฯ࠭敞"),l11ll1_l1_,461,l11lll_l1_ (u"ࠩࠪ敟"),l11lll_l1_ (u"ࠪࠫ敠"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ敡"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ敢"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭散"),l11lll_l1_ (u"ࠧࠨ敤"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ敥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ敦"),block,re.DOTALL)
		for link,title in items:
			#if link==l11lll_l1_ (u"ࠪࠧࠬ敧"): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ敨") not in link: link = l11ll1_l1_+link
			if title==l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ敩"): title = l11lll_l1_ (u"࠭ฬะ์าࠤา๊โศฬࠣฮ๏็๊ࠡใส๊ࠬ敪")
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ敫"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ敬")+l111ll_l1_+title,link,461)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡊࡴࡵࡴࡦࡴࡆࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ敭"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ敮"),block,re.DOTALL)
	#	for link,title in items:
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ敯"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ数")+l111ll_l1_+title,link,461)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"࠭ࠧ敱")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ敲"),l11lll_l1_ (u"ࠨࠩ敳"),l1lll1ll11_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭整"),url,l11lll_l1_ (u"ࠪࠫ敵"),l11lll_l1_ (u"ࠫࠬ敶"),l11lll_l1_ (u"ࠬ࠭敷"),l11lll_l1_ (u"࠭ࠧ數"),l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ敹"))
	html = response.content
	#if l1lll1ll11_l1_==l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ敺"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩฦาึࠦวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ敻"),html,re.DOTALL)
	#else:
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ敼"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ敽"),block,re.DOTALL)
		l1l1_l1_ = []
		l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ敾"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ敿"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭斀"),l11lll_l1_ (u"ࠨๅ็๎อ࠭斁"),l11lll_l1_ (u"ࠩส฽้อๆࠨ斂"),l11lll_l1_ (u"๋ࠪิอแࠨ斃"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ斄"),l11lll_l1_ (u"ࠬ฿ัืࠩ斅"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭斆"),l11lll_l1_ (u"ࠧศๆห์๊࠭文")]
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭斈") not in link: link = l11ll1_l1_+link
			link = l111l_l1_(link)	#.strip(l11lll_l1_ (u"ࠩ࠲ࠫ斉"))
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭斊"),title,re.DOTALL)
			if any(value in title for value in l1lll1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ斋"),l111ll_l1_+title,link,462,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ斌") in title:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ斍") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斎"),l111ll_l1_+title,link,463,l1llll_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ斏"),l111ll_l1_+title,link,463,l1llll_l1_)
	if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ斐"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ斑"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ斒"),block,re.DOTALL)
			for link,title in items:
				link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ斓"))
				if link==l11lll_l1_ (u"ࠨࠢ斔"): continue
				if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ斕") not in link: link = l11ll1_l1_+link
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠨࠩ斖"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斗"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ斘")+title,link,461)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ料"),l11lll_l1_ (u"ࠬ࠭斚"),l11lll_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࠨ斛"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ斜"),url,l11lll_l1_ (u"ࠨࠩ斝"),l11lll_l1_ (u"ࠩࠪ斞"),l11lll_l1_ (u"ࠪࠫ斟"),l11lll_l1_ (u"ࠫࠬ斠"),l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ斡"))
	html = response.content
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭斢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ斣"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭斤") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ斥"),l111ll_l1_+title,link,462,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ斦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭斧"),block,re.DOTALL)
		for link,title in items:
			link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ斨"))
			if link==l11lll_l1_ (u"ࠨࠢ斩"): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ斪") not in link: link = l11ll1_l1_+link
			#title = unescapeHTML(title)
			if title!=l11lll_l1_ (u"ࠨࠩ斫"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斬"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ断")+title,link,463)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ斮"),url,l11lll_l1_ (u"ࠬ࠭斯"),l11lll_l1_ (u"࠭ࠧ新"),l11lll_l1_ (u"ࠧࠨ斱"),l11lll_l1_ (u"ࠨࠩ斲"),l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ斳"))
	html = response.content
	# l1l111lll_l1_ link
	l1111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ斴"),html,re.DOTALL)
	if l1111l1l11_l1_:
		l1111l1l11_l1_ = l1111l1l11_l1_[0]
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ斵") not in l1111l1l11_l1_:
			if l11lll_l1_ (u"ࠬ࠵࠯ࠨ斶") in l1111l1l11_l1_: l1111l1l11_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ斷")+l1111l1l11_l1_
			else: l1111l1l11_l1_ = l11ll1_l1_+l1111l1l11_l1_
		l1111l1l11_l1_ = l1111l1l11_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ斸")
		l1111_l1_.append(l1111l1l11_l1_)
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ方"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lll11lll111_l1_,l1lll11lll11l_l1_ = l1l1ll1_l1_[0]
		names = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ斺"),l1lll11lll111_l1_,re.DOTALL)
		links = re.findall(l11lll_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ斻"),l1lll11lll11l_l1_,re.DOTALL)
		l1lll11ll1lll_l1_ = zip(names,links)
		for name,l11111ll11ll_l1_ in l1lll11ll1lll_l1_:
			l11111ll11ll_l1_ = l11111ll11ll_l1_[2:]
			if kodi_version<19: l11111ll11ll_l1_ = l11111ll11ll_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ於"))
			l11111ll11ll_l1_ = base64.b64decode(l11111ll11ll_l1_)
			if kodi_version>18.99: l11111ll11ll_l1_ = l11111ll11ll_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ施"))
			link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ斾"),l11111ll11ll_l1_,re.DOTALL)
			link = link[0]
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ斿") not in link:
				if l11lll_l1_ (u"ࠨ࠱࠲ࠫ旀") in link: link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ旁")+link
				else: link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ旂")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ旃")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ旄"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ旅"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11lll_l1_ (u"ࠧࠡࠩ旆") in search:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ旇"),l11lll_l1_ (u"ࠩࠪ旈"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ旉"),l11lll_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ旊"))
		return
	#search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ旋"),l11lll_l1_ (u"࠭࠭ࠨ旌"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ旍")+search
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡴ࠳ࠬ旎")+search+l11lll_l1_ (u"ࠩ࠲ࠫ族")
	l1111l_l1_(url)
	return
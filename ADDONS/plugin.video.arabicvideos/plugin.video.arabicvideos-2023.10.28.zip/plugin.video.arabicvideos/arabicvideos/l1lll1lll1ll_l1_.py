# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭押")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭抽")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ抾"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ抿"),l11lll_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭拀")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1111l_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11111_l1_(url,text)
	elif mode==644: results = l1l11l_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ拁"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭拂"),l11lll_l1_ (u"࠭ࠧ拃"),l11lll_l1_ (u"ࠧࠨ拄"),l11lll_l1_ (u"ࠨࠩ担"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ拆"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ拇"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ拈"),l11lll_l1_ (u"ࠬ࠭拉"),649,l11lll_l1_ (u"࠭ࠧ拊"),l11lll_l1_ (u"ࠧࠨ拋"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ拌"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ拍"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ拎"),l11lll_l1_ (u"ࠫࠬ拏"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ拐"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ拑")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ拒"),l11ll1_l1_,641,l11lll_l1_ (u"ࠨࠩ拓"),l11lll_l1_ (u"ࠩࠪ拔"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ拕"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ拖"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ拗")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫ拘"),l11ll1_l1_,641,l11lll_l1_ (u"ࠧࠨ拙"),l11lll_l1_ (u"ࠨࠩ拚"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ招"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ拜"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ拝"),l11lll_l1_ (u"ࠬ࠭拞"),9999)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭拟"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ拠")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧ拡"),l11ll1_l1_,641,l11lll_l1_ (u"ࠩࠪ拢"),l11lll_l1_ (u"ࠪࠫ拣"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ拤"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ拥"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ拦")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫ拧"),l11ll1_l1_,641,l11lll_l1_ (u"ࠨࠩ拨"),l11lll_l1_ (u"ࠩࠪ择"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ拪"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ拫"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭括"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭拭"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ拮")+l111ll_l1_+title,link,644)
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭拯"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ拰"),l11lll_l1_ (u"ࠪࠫ拱"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ拲"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ拳"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"࠭ࠧ拴"))
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ拵"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ拶"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ拷")+l111ll_l1_+title,link,644)
	return
def l1l11l_l1_(url):
	l1111ll1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ拸"),url,l11lll_l1_ (u"ࠫࠬ拹"),l11lll_l1_ (u"ࠬ࠭拺"),l11lll_l1_ (u"࠭ࠧ拻"),l11lll_l1_ (u"ࠧࠨ拼"),l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭拽"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭拾"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ拿"),l11lll_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ挀"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ持"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"࠭ࠧ挂"),block)]
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ挃"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭挄"),l11lll_l1_ (u"ࠩࠪ挅"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			l1111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ挆"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠫ࠿ࠦࠧ指")
			for link,title in l1111ll1l_l1_:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ挈"),l111ll_l1_+title,link,641)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ按"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ挊"),block,re.DOTALL)
		if len(l1l1lll_l1_)<30:
			if l1111ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭挋"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ挌"),l11lll_l1_ (u"ࠪࠫ挍"),9999)
			for link,title in l1l1lll_l1_:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ挎"),l111ll_l1_+title,link,641)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠬ࠭挏")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ挐"),l11lll_l1_ (u"ࠧࠨ挑"),request,url)
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭挒"):
		url,search = url.split(l11lll_l1_ (u"ࠩࡂࠫ挓"),1)
		data = l11lll_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ挔")+search
		headers = {l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ挕"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ挖")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ挗"),url,data,headers,l11lll_l1_ (u"ࠧࠨ挘"),l11lll_l1_ (u"ࠨࠩ挙"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭挚"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ挛"),url,l11lll_l1_ (u"ࠫࠬ挜"),l11lll_l1_ (u"ࠬ࠭挝"),l11lll_l1_ (u"࠭ࠧ挞"),l11lll_l1_ (u"ࠧࠨ挟"),l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ挠"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠩࠪ挡"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ挢"))
	if request==l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ挣"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ挤"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ挥"),link,title))
	elif request==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ挦"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ挧"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ挨"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ挩"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ挪"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ挫"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ挬"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ挭"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ挮"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠩࠪ振"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ挰"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭挱"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ挲"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ挳"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭挴"),l11lll_l1_ (u"ࠨๅ็๎อ࠭挵"),l11lll_l1_ (u"ࠩส฽้อๆࠨ挶"),l11lll_l1_ (u"๋ࠪิอแࠨ挷"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ挸"),l11lll_l1_ (u"ࠬ฿ัืࠩ挹"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭挺"),l11lll_l1_ (u"ࠧศๆห์๊࠭挻"),l11lll_l1_ (u"ࠨ็ึีา๐ษࠨ挼")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ挽"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ挾") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭挿")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ捀"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ捁") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ捂")+l1llll_l1_.strip(l11lll_l1_ (u"ࠨ࠱ࠪ捃"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ捄"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭捅"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ捆"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ捇"):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ捈"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭捉") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ捊"),l111ll_l1_+title,link,643,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ捋") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ捌"),l111ll_l1_+title,link,641,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ捍"),l111ll_l1_+title,link,643,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ捎"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ捏")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ捐"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭捑"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠩࠦࠫ捒"): continue
				if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ捓") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭捔")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ捕"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭捖"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭捗")+title,link,641)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ捘"),l11lll_l1_ (u"ࠩࠪ捙"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ捚"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ捛"),url,l11lll_l1_ (u"ࠬ࠭捜"),l11lll_l1_ (u"࠭ࠧ捝"),l11lll_l1_ (u"ࠧࠨ捞"),l11lll_l1_ (u"ࠨࠩ损"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ捠"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭捡"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭换"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠬ࠭捣")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ捤"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠤࠩ捥"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ捦"),l111ll_l1_+title,url,643,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ捧"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ捨")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ捩"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ捪"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ捫"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ捬") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ捭")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ据"))
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ捯"),l11lll_l1_ (u"ࠫࠥ࠭捰"))
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ捱"),l111ll_l1_+title,link,642,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ捲"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ捳") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ捴")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ捵"))
		#		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ捶"),l111ll_l1_+title,link,642,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l11l1ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ捷"),l11lll_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠲ࡵ࡮ࡰࠨ捸"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ捹"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ捺"),l11lll_l1_ (u"ࠨࠩ捻"),l11lll_l1_ (u"ࠩࠪ捼"),l11lll_l1_ (u"ࠪࠫ捽"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭捾"))
	html = response.content
	# l1l111lll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ捿"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ掀"),block,re.DOTALL)
		if links:
			link = links[0]
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ掁"))
				l1111_l1_.append(link)
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ掂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ掃"),block,re.DOTALL)
		block = block.replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ掄"),l11lll_l1_ (u"ࠫࠧ࠭掅")).replace(l11lll_l1_ (u"ࠬࡢ࠯ࠨ掆"),l11lll_l1_ (u"࠭࠯ࠨ掇"))
		links = re.findall(l11lll_l1_ (u"ࠧࠣ࠾࡬ࡪࡷࡧ࡭ࡦ࠰ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ授"),block,re.DOTALL)
		if len(l11111ll1_l1_)==len(links):
			for id,title in l11111ll1_l1_:
				link = links[int(id)]
				if link not in l1111_l1_:
					l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ掉")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ掊"))
					l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ掋"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ掌"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭掍")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ掎"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l11l1ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ掏"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ掐"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ掑"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ排"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭掓"),l11lll_l1_ (u"ࠬ࠱ࠧ掔"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ掕")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ掖"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ掗")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ掘"))
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ僭")
#l111llll1lll_l1_ = [ l11lll_l1_ (u"ࠬࡳࡹࡴࡶࡵࡩࡦࡳࠧ僮"),l11lll_l1_ (u"࠭ࡶࡪ࡯ࡳࡰࡪ࠭僯"),l11lll_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡳࠧ僰"),l11lll_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭僱") ]
l111llll1lll_l1_ = []
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭僲"):l11lll_l1_ (u"ࠪࠫ僳")}
def l11_l1_(l1lllll1_l1_,source,type,url):
	#DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่ึอศุࠢส่๊์วิสࠪ僴"),l1lllll1_l1_)
	if not l1lllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ僵"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭僶")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨ僷")+type+l11lll_l1_ (u"ࠨࠢࡠࠫ僸"))
		l11l11llll11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ價"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭僺"),l11lll_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ僻"))
		datetime = time.strftime(l11lll_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭僼"),time.gmtime(now))
		line = datetime,url
		key = source+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ僽")+l11ll111111_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠬ僾")+str(kodi_version)
		message = l11lll_l1_ (u"ࠨࠩ僿")
		if key not in list(l11l11llll11_l1_.keys()): l11l11llll11_l1_[key] = [line]
		else:
			if url not in str(l11l11llll11_l1_[key]): l11l11llll11_l1_[key].append(line)
			else: message = l11lll_l1_ (u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧ儀")
		total = 0
		for key in list(l11l11llll11_l1_.keys()):
			l11l11llll11_l1_[key] = list(set(l11l11llll11_l1_[key]))
			total += len(l11l11llll11_l1_[key])
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ儁"),l11lll_l1_ (u"ࠫࠬ儂"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ儃"),l11lll_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ億")+message+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭儅")+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭儆")+l11lll_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ儇")+str(total))
		if total>=5:
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ儈"),l11lll_l1_ (u"ࠫࠬ儉"),l11lll_l1_ (u"ࠬ࠭儊"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ儋"),l11lll_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ儌"))
			if l1ll11l111_l1_==1:
				l11l11lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ儍")
				for key in list(l11l11llll11_l1_.keys()):
					l11l11lllll1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ儎")+key
					l1111l1ll1ll_l1_ = sorted(l11l11llll11_l1_[key],reverse=False,key=lambda l111ll1l1l11_l1_: l111ll1l1l11_l1_[0])
					for datetime,url in l1111l1ll1ll_l1_:
						l11l11lllll1_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭儏")+datetime+l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠩ儐")+l111l_l1_(url)
					l11l11lllll1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ儑")
				import l11ll1ll1ll_l1_
				succeeded = l11ll1ll1ll_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"࠭ࡖࡪࡦࡨࡳࡸ࠭儒"),l11lll_l1_ (u"ࠧࠨ儓"),False,l11lll_l1_ (u"ࠨࠩ儔"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭儕"),l11lll_l1_ (u"ࠪࠫ儖"),l11l11lllll1_l1_)
				if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ儗"),l11lll_l1_ (u"ࠬ࠭儘"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ儙"),l11lll_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ儚"))
				else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ儛"),l11lll_l1_ (u"ࠩࠪ儜"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭儝"),l11lll_l1_ (u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩ儞"))
			if l1ll11l111_l1_!=-1:
				l11l11llll11_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ償"),l11lll_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ儠"))
		if l11l11llll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ儡"),l11lll_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ儢"),l11l11llll11_l1_,PERMANENT_CACHE)
		return
	l1lllll1_l1_ = list(set(l1lllll1_l1_))
	l1lll1ll_l1_,l1111_l1_ = l1111lll11l1_l1_(l1lllll1_l1_,source)
	l1111l1ll11l_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ儣"))
	l1111lll1lll_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ儤"))
	l1111l1lll1l_l1_ = len(l1111_l1_)-l1111l1ll11l_l1_-l1111lll1lll_l1_
	l111l1111111_l1_ = l11lll_l1_ (u"ฺ๊ࠫว่ัฬ࠾ࠬ儥")+str(l1111l1ll11l_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩ儦")+str(l1111lll1lll_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠣวำื้࠻ࠩ儧")+str(l1111l1lll1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ儨"),l11lll_l1_ (u"ࠨࠩ儩"),str(l1111l1ll11l_l1_),str(l1111lll1lll_l1_))
	#l1l_l1_ = DIALOG_SELECT(l111l1111111_l1_, l1111_l1_)
	if not l1111_l1_: result,l11ll11111ll_l1_ = l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭優"),l11lll_l1_ (u"ࠪࠫ儫")
	else:
		while True:
			l11ll11111ll_l1_ = l11lll_l1_ (u"ࠫࠬ儬")
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l111l1111111_l1_,l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ儭")
			else:
				title = l1lll1ll_l1_[l1l_l1_]
				link = l1111_l1_[l1l_l1_]
				#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ儮"),l11lll_l1_ (u"ࠧࠨ儯"),title,link)
				if l11lll_l1_ (u"ࠨีํีๆืࠧ儰") in title and l11lll_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ儱") in title:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ儲"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ儳")+title+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ儴")+link+l11lll_l1_ (u"࠭ࠠ࡞ࠩ儵"))
					import l11ll1ll1ll_l1_
					l11ll1ll1ll_l1_.MAIN(156)
					result = l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ儶")
				else:
					LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ儷"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ儸")+title+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ儹")+link+l11lll_l1_ (u"ࠫࠥࡣࠧ儺"))
					result,l11ll11111ll_l1_,l11llll1lll1_l1_ = l111l111ll11_l1_(link,source,type)
					#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭儻"),l11lll_l1_ (u"࠭ࠧ儼"),result,l11ll11111ll_l1_)
			if l11lll_l1_ (u"ࠧ࡝ࡰࠪ儽") not in l11ll11111ll_l1_: l11l1ll1ll11_l1_,l111l1ll1ll_l1_ = l11ll11111ll_l1_,l11lll_l1_ (u"ࠨࠩ儾")
			else: l11l1ll1ll11_l1_,l111l1ll1ll_l1_ = l11ll11111ll_l1_.split(l11lll_l1_ (u"ࠩ࡟ࡲࠬ儿"),1)
			if result in [l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ兀"),l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭允"),l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭兂"),l11lll_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ元")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ兄"),l11lll_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ充"),l11lll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ兆")]: break
			elif result not in [l11lll_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ兇"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ先")]: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭光"),l11lll_l1_ (u"࠭ࠧ兊"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ克"),l11lll_l1_ (u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࠫ兌")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ免")+l11l1ll1ll11_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭兎")+l111l1ll1ll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ兏"),l11lll_l1_ (u"ࠬ࠭児"),l11lll_l1_ (u"࠭ࠧ兑"),str(l11llll1lll1_l1_))
	if result==l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ兒") and len(l1lll1ll_l1_)>0: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ兓"),l11lll_l1_ (u"ࠩࠪ兔"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭兕"),l11lll_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ兖")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ兗")+l11ll11111ll_l1_)
	elif result in [l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭兘"),l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ兙")] and l11ll11111ll_l1_!=l11lll_l1_ (u"ࠨࠩ党"): DIALOG_OK(l11lll_l1_ (u"ࠩࠪ兛"),l11lll_l1_ (u"ࠪࠫ兜"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ兝"),l11ll11111ll_l1_)
	#elif l11ll11111ll_l1_==l11lll_l1_ (u"ࠬࡘࡅࡕࡗࡕࡒࡤ࡚ࡏࡠ࡛ࡒ࡙࡙࡛ࡂࡆࠩ兞"): result = l11llll1lll1_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡱࠤࡠ࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ࠰ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩࡠ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࡗࡩࡸࡺ࠺ࠡࠢࠣࠫ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠱࡟࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠸࡝ࠪࠌࠌࠍࡽࡨ࡭ࡤࡲ࡯ࡹ࡬࡯࡮࠯ࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࡤࡨࡩࡵ࡮ࡠࡪࡤࡲࡩࡲࡥ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭࠯ࠩࠋࠋࠌࡴࡱࡧࡹࡠ࡫ࡷࡩࡲࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬࡵࡧࡴࡩ࠿ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡃࡲࡵࡤࡦ࠿࠴࠸࠸ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࠪ࠹ࡆࡷࠧ࠶ࡈ࡬ࡽࡢ࠲ࡲࡻ࡚ࡹࡽ࠹ࡒࠩࠬࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡰ࡭ࡣࡼࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࡭ࡸ࠴࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰࡫ࡳ࡬ࡴࡴࡥ࠰࠳࠵࠷࠹࠺࠷࠯࡯ࡳ࠸ࠬ࠲ࡰ࡭ࡣࡼࡣ࡮ࡺࡥ࡮ࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไศๆ฽หฦ࠭ࠬࠨࠩࠬࠎࠎࠨࠢࠣ兟")
	return result
	#if source==l11lll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ兠"): l111ll_l1_ = l11lll_l1_ (u"ࠨࡊࡏࡅࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ兡")
	#elif source==l11lll_l1_ (u"ࠩ࠷ࡌࡊࡒࡁࡍࠩ兢"): l111ll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡎࡅࡍࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ兣")
	#elif source==l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ兤"): l111ll_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡂࡍࡐࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭入")
	#elif source==l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ兦"): l111ll_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡖࡌ࠹ࠦࠧ內")
	#size = len(l1ll1lll11_l1_)
	#for i in range(0,size):
	#	title = l11ll111111l_l1_[i]
	#	link = l1ll1lll11_l1_[i]
	#	addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ全"),l111ll_l1_+title,link,160,l11lll_l1_ (u"ࠩࠪ兩"),l11lll_l1_ (u"ࠪࠫ兪"),source)
def l111l111ll11_l1_(url,source,type=l11lll_l1_ (u"ࠫࠬ八")):
	url = url.strip(l11lll_l1_ (u"ࠬࠦࠧ公")).strip(l11lll_l1_ (u"࠭ࠦࠨ六")).strip(l11lll_l1_ (u"ࠧࡀࠩ兮")).strip(l11lll_l1_ (u"ࠨ࠱ࠪ兯"))
	l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11l11l_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ兰"),l11lll_l1_ (u"ࠪࠫ共"),url,l11ll11111ll_l1_)
	if l11ll11111ll_l1_==l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ兲"): return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_:
		while True:
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ关"), l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ兴")
			else:
				l111ll11l1l1_l1_ = l1111_l1_[l1l_l1_]
				title = l1lll1ll_l1_[l1l_l1_]
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ兵"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡥ࡭ࡧࡦࡸࡪࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ其")+title+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ具")+str(l111ll11l1l1_l1_)+l11lll_l1_ (u"ࠪࠤࡢ࠭典"))
				if l11lll_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ兹") in l111ll11l1l1_l1_ and l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ兺") in l111ll11l1l1_l1_:
					l111lll1l1l1_l1_,l11llll11ll1_l1_,l11llll1lll1_l1_ = l11l1l11ll11_l1_(l111ll11l1l1_l1_)
					if l11llll1lll1_l1_: l111ll11l1l1_l1_ = l11llll1lll1_l1_[0]
					else: l111ll11l1l1_l1_ = l11lll_l1_ (u"࠭ࠧ养")
				if not l111ll11l1l1_l1_: result = l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ兼")
				else: result = PLAY_VIDEO(l111ll11l1l1_l1_,source,type)
			if result in [l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ兽"),l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭兾")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ兿"),l11lll_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ冀"),l11lll_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ冁")]: break
			else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ冂"),l11lll_l1_ (u"ࠧࠨ冃"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ冄"),l11lll_l1_ (u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨ内"))
	else:
		result = l11lll_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ円")
		l111llll11_l1_ = l11l1llll1_l1_(url)
		if l111llll11_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11ll11111ll_l1_,l1111_l1_
	#title = xbmc.getInfoLabel( l11lll_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ冇") )
	#if l11lll_l1_ (u"ู๊ࠬาใิࠤ฾อๅࠡ็ฯ๋ํ๊ࠧ冈") in title:
	#	import l11ll1ll1ll_l1_
	#	l11ll1ll1ll_l1_.MAIN(156)
	#	return l11lll_l1_ (u"࠭ࠧ冉")
def l11111ll111l_l1_(url,source):
	# url = url+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ冊")+name+l11lll_l1_ (u"ࠨࡡࡢࠫ冋")+type+l11lll_l1_ (u"ࠩࡢࡣࠬ册")+l1l1111_l1_+l11lll_l1_ (u"ࠪࡣࡤ࠭再")+l11l111l_l1_
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺ࠿࡯ࡣࡰࡩࡩࡃࡡ࡬ࡹࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣ࠼࠸࠰ࠨ冎")
	l11l11l_l1_,l11l1l1ll111_l1_,server,l111ll1l1l1l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = url,l11lll_l1_ (u"ࠬ࠭冏"),l11lll_l1_ (u"࠭ࠧ冐"),l11lll_l1_ (u"ࠧࠨ冑"),l11lll_l1_ (u"ࠨࠩ冒"),l11lll_l1_ (u"ࠩࠪ冓"),l11lll_l1_ (u"ࠪࠫ冔"),l11lll_l1_ (u"ࠫࠬ冕")
	#source = source.lower()
	if l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭冖") in url:
		l11l11l_l1_,l11l1l1ll111_l1_ = url.split(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ冗"),1)
		l11l1l1ll111_l1_ = l11l1l1ll111_l1_+l11lll_l1_ (u"ࠧࡠࡡࠪ冘")+l11lll_l1_ (u"ࠨࡡࡢࠫ写")+l11lll_l1_ (u"ࠩࡢࡣࠬ冚")+l11lll_l1_ (u"ࠪࡣࡤ࠭军")
		l11l1l1ll111_l1_ = l11l1l1ll111_l1_.lower()
		name,type,l1l1111_l1_,l11l111l_l1_,l1lll1l11111_l1_ = l11l1l1ll111_l1_.split(l11lll_l1_ (u"ࠫࡤࡥࠧ农"))[:5]
	if l11l111l_l1_==l11lll_l1_ (u"ࠬ࠭冝"): l11l111l_l1_ = l11lll_l1_ (u"࠭࠰ࠨ冞")
	else: l11l111l_l1_ = l11l111l_l1_.replace(l11lll_l1_ (u"ࠧࡱࠩ冟"),l11lll_l1_ (u"ࠨࠩ冠")).replace(l11lll_l1_ (u"ࠩࠣࠫ冡"),l11lll_l1_ (u"ࠪࠫ冢"))
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠫࡄ࠭冣")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ冤")).strip(l11lll_l1_ (u"࠭ࠦࠨ冥"))
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠧࡩࡱࡶࡸࠬ冦"))
	if name: l111ll1l1l1l_l1_ = name
	#elif source: l111ll1l1l1l_l1_ = source
	else: l111ll1l1l1l_l1_ = server
	l111ll1l1l1l_l1_ = SERVER(l111ll1l1l1l_l1_,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭冧"))
	name = name.replace(l11lll_l1_ (u"่ࠩฬฬฺัࠨ冨"),l11lll_l1_ (u"ࠪࠫ冩")).replace(l11lll_l1_ (u"ุࠫ๐ัโำࠪ冪"),l11lll_l1_ (u"ࠬ࠭冫")).replace(l11lll_l1_ (u"࠭วๅࠢࠪ冬"),l11lll_l1_ (u"ࠧࠡࠩ冭")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ冮"),l11lll_l1_ (u"ࠩࠣࠫ冯"))
	l11l1l1ll111_l1_ = l11l1l1ll111_l1_.replace(l11lll_l1_ (u"้ࠪออิาࠩ冰"),l11lll_l1_ (u"ࠫࠬ冱")).replace(l11lll_l1_ (u"ู๊ࠬาใิࠫ冲"),l11lll_l1_ (u"࠭ࠧ决")).replace(l11lll_l1_ (u"ࠧศๆࠣࠫ冴"),l11lll_l1_ (u"ࠨࠢࠪ况")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ冶"),l11lll_l1_ (u"ࠪࠤࠬ冷"))
	l111ll1l1l1l_l1_ = l111ll1l1l1l_l1_.replace(l11lll_l1_ (u"๊ࠫฮวีำࠪ冸"),l11lll_l1_ (u"ࠬ࠭冹")).replace(l11lll_l1_ (u"࠭ำ๋ำไีࠬ冺"),l11lll_l1_ (u"ࠧࠨ冻")).replace(l11lll_l1_ (u"ࠨษ็ࠤࠬ冼"),l11lll_l1_ (u"ࠩࠣࠫ冽")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭冾"),l11lll_l1_ (u"ࠫࠥ࠭冿"))
	return l11l11l_l1_,l11l1l1ll111_l1_,server,l111ll1l1l1l_l1_,name,type,l1l1111_l1_,l11l111l_l1_
def l11l1llll1ll_l1_(url,source):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭净"),l11lll_l1_ (u"࠭ࠧ凁"),url,l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ凂"))
	# l1lll1ll1_l1_	: سيرفر خاص
	# l11l1ll11l1l_l1_		: سيرفر محدد
	# l11l1l1l1ll1_l1_		: سيرفر عام معروف
	# l1ll1ll11_l1_	: سيرفر عام خارجي
	# l1111ll1111l_l1_	: سيرفر عام خارجي
	l111ll1111l1_l1_,name,l1lll1ll1_l1_,l11l1l1l1ll1_l1_,l1ll1ll11_l1_,l11l1ll11l1l_l1_,l1111ll1111l_l1_ = l11lll_l1_ (u"ࠨࠩ凃"),l11lll_l1_ (u"ࠩࠪ凄"),None,None,None,None,None
	l11l11l_l1_,l11l1l1ll111_l1_,server,l111ll1l1l1l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111ll111l_l1_(url,source)
	if l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ凅") in url:
		if   type==l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ准"): type = l11lll_l1_ (u"ࠬࠦࠧ凇")+l11lll_l1_ (u"࠭ๅโุ็ࠫ凈")
		elif type==l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭凉"): type = l11lll_l1_ (u"ࠨࠢࠪ凊")+l11lll_l1_ (u"ࠩࠨู้อ็ะหࠪ凋")
		elif type==l11lll_l1_ (u"ࠪࡦࡴࡺࡨࠨ凌"): type = l11lll_l1_ (u"ࠫࠥ࠭凍")+l11lll_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ凎")
		elif type==l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ减"): type = l11lll_l1_ (u"ࠧࠡࠩ凐")+l11lll_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ凑")
		elif type==l11lll_l1_ (u"ࠩࠪ凒"): type = l11lll_l1_ (u"ࠪࠤࠬ凓")+l11lll_l1_ (u"ࠫࠪࠫࠥࠦࠩ凔")
		if l1l1111_l1_!=l11lll_l1_ (u"ࠬ࠭凕"):
			if l11lll_l1_ (u"࠭࡭ࡱ࠶ࠪ凖") not in l1l1111_l1_: l1l1111_l1_ = l11lll_l1_ (u"ࠧࠦࠩ凗")+l1l1111_l1_
			l1l1111_l1_ = l11lll_l1_ (u"ࠨࠢࠪ凘")+l1l1111_l1_
		if l11l111l_l1_!=l11lll_l1_ (u"ࠩࠪ凙"):
			l11l111l_l1_ = l11lll_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭凚")+l11l111l_l1_
			l11l111l_l1_ = l11lll_l1_ (u"ࠫࠥ࠭凛")+l11l111l_l1_[-9:]
	#if any(value in server for value in l111llll1lll_l1_): return l11lll_l1_ (u"ࠬ࠭凜")
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ凝"),l11lll_l1_ (u"ࠧࠨ凞"),name,l111ll1l1l1l_l1_)
	if   l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ凟")		in source: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ几")		in source: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ凡")
	elif l11lll_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭凢")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ凣")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ凤")	in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ凥")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ処")
	#elif l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ凧") in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ凨")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ凩")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	#elif l11lll_l1_ (u"ࠬࡶࡣࡳࡧࡹ࡭ࡪࡽࠧ凪")	in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ凫")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ凬")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ凭")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ凮")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ凯")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ凰")	in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ凱")
	elif l11lll_l1_ (u"࠭แอำࠪ凲")			in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭凳")
	elif l11lll_l1_ (u"ࠨใ็ื฼๐ๆࠨ凴")		in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬ凵")
	elif l11lll_l1_ (u"ࠪ࡫ࡩࡸࡩࡷࡧࠪ凶")		in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ凷")
	elif l11lll_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ凸")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭凹")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ出")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ击")		in name:   l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ凼")	in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ函")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ凾")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ凿")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ刀")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ刁")		in server: l1lll1ll1_l1_	= l111ll1l1l1l_l1_
	#elif l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭刂")	in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࠣࠫ刃")
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ刄")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭刅")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ分")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭切")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ刈")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ刉")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ刊")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ刋")
	elif l11lll_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ刌")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭刍")
	elif l11lll_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ刎")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ刏")
	elif l11lll_l1_ (u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ刐")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ刑")
	elif l11lll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ划")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭刓")
	#elif l11lll_l1_ (u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ刔")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ刕")
	elif l11lll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ刖")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ列")
	elif l11lll_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ刘")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ则")
	elif l11lll_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ刚")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱࠬ创")
	elif l11lll_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ刜")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ初")
	elif l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ刞")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ刟")
	elif l11lll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ删")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ刡")
	elif l11lll_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ刢")	 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"࠭ࡣࡢࡶࡦ࡬ࠬ刣")
	elif l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ判")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ別")
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ刦")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ刧")
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ刨")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫ利")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"࠭࡭ࡺࡸ࡬࡭ࡩ࠭刪")		in server: l11l1ll11l1l_l1_	= l111ll1l1l1l_l1_
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ别")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ刬")
	elif l11lll_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ刭")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ刮")
	elif l11lll_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭刯") 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ到")
	elif l11lll_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ刱")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ刲")
	elif l11lll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭刳")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ刴")
	elif l11lll_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ刵") 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ制")
	elif l11lll_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭刷")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ券")
	elif l11lll_l1_ (u"ࠧࡶࡲࡳࠫ刹") 			in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ刺")
	elif l11lll_l1_ (u"ࠩࡸࡴࡧ࠭刻") 			in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ刼")
	elif l11lll_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ刽") 		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ刾")
	elif l11lll_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ刿") 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ剀")
	elif l11lll_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ剁")		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ剂")
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ剃") 		in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ剄")
	elif l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ剅") 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ剆")
	elif l11lll_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ則")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ剈")
	elif l11lll_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭剉")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ削")
	#elif l11lll_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ剋") 	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭剌")
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ前")	in server: l11l1l1l1ll1_l1_	= l11lll_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ剎")
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡺࡸ࡬ࠬࠩࡀࡁࡂ࠭ࠫࡶࡴ࡯࠶࠮ࠐࠉࠊࡶࡵࡽ࠿ࠐࠉࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱࠐࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮࠱ࡌࡴࡹࡴࡦࡦࡐࡩࡩ࡯ࡡࡇ࡫࡯ࡩ࠭ࡻࡲ࡭࠴ࠬ࠲ࡻࡧ࡬ࡪࡦࡢࡹࡷࡲࠨࠪࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠋࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠵࠶࠷࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡉࡥࡱࡹࡥࠋࠋࠌࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠲ࡴࡸࡧࠋࠋࠌࠍࡱ࡯ࡳࡵࡡࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡹࡪ࡬࠮ࡱࡵ࡫࠳࡭ࡩࡵࡪࡸࡦ࠳࡯࡯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡧࡰ࠴ࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡴ࡫ࡷࡩࡸ࠴ࡨࡵ࡯࡯ࠫࠏࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲࡬ࡪࡵࡷࡣࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈ࠱࠶ࡹࡴࠨࠫࠍࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡩࡶࡰࡰ࠿ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࡜࠲ࡠ࠲ࡱࡵࡷࡦࡴࠫ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿ࡰ࡮ࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽ࡤࡁࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰࡮࡬ࡂࠬ࠲ࠧࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠷࠸࠲࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨࠫࠍࠍࠎࠏࠉࡱࡣࡵࡸࡸࠦ࠽ࠡࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠰ࠪ࠭ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡱࡣࡵࡸࡸࡀࠊࠊࠋࠌࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡶࡡࡳࡶࠬࡀ࠹ࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࠉࡦ࡮࡬ࡪࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠎࠎࠨࠢࠣ剏")
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ剐"),l11lll_l1_ (u"ࠪࠫ剑"),url,l11l11l_l1_)
	if   l1lll1ll1_l1_:	l111ll1111l1_l1_,name = l11lll_l1_ (u"ࠫำอีࠨ剒"),l1lll1ll1_l1_
	elif l11l1ll11l1l_l1_:		l111ll1111l1_l1_,name = l11lll_l1_ (u"ࠬࠫๅฮัาࠫ剓"),l11l1ll11l1l_l1_
	elif l11l1l1l1ll1_l1_:		l111ll1111l1_l1_,name = l11lll_l1_ (u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫ剔"),l11l1l1l1ll1_l1_
	elif l1ll1ll11_l1_:	l111ll1111l1_l1_,name = l11lll_l1_ (u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭剕"),l1ll1ll11_l1_
	elif l1111ll1111l_l1_:	l111ll1111l1_l1_,name = l11lll_l1_ (u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨ剖"),l111ll1l1l1l_l1_
	else:			l111ll1111l1_l1_,name = l11lll_l1_ (u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆࠪ剗"),l111ll1l1l1l_l1_
	return l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡰ࡭ࡣࡼࡶ࠳࠺ࡨࡦ࡮ࡤࡰࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡵࡸࡩࡷࡣࡷࡩࠥࡃࠠࠨࡪࡨࡰࡦࡲࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡴࡩࡧࡹ࡭ࡩ࡫࡯ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹࡩࡻ࠴ࡩࡰࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡥࡷࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡢࡰ࡯ࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡤࡲࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨ࡭ࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠋࠋࠥࠦࠧ剘")
def l111l11ll1l1_l1_(url,source):
	l11l11l_l1_,l11l1l1ll111_l1_,server,l111ll1l1l1l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111ll111l_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ剙"),l11lll_l1_ (u"ࠬ࠭剚"),l11l1ll11l1l_l1_,server)
	#if l11lll_l1_ (u"࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫ剛")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ剜"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ剝"))
	#if any(value in server for value in l111llll1lll_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡉࡘࡕࡌࡗࡇࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࠦࡴࡩ࡫ࡶࠤࡸ࡫ࡲࡷࡧࡵࠫ剞")],[]
	if   l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ剟")		in source: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l111l_l1_(l11l11l_l1_,name)
	elif l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ剠")		in source: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111_l1_(l11l11l_l1_,type,l11l111l_l1_)
	elif l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ剡")		in source: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lll1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭剢")		in source: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llllllll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ剣")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11l11l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫ剤")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ剥")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1lll11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ剦")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭剧")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢࠨ剨")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭剩")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭剪")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ剫")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫ剬")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ剭")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭剮")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ副")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11ll1ll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ剰")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1l11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡷࡵ࠷ࡹࠬ剱")			in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1ll111ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ割")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1llll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ剳")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ剴")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨ創")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨ剶")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭剷")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1111ll11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ剸")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11ll1ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ剹")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ剺")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ剻")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ剼")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡹ࡫ࡣࡩࠩ剽")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡧࡶ࡮ࡩࡸࡪࡩࡨࠨ剾")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡲࡢࡶࡨࠫ剿")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡲࡦࡶࡪࡼࡩࡦࡹࠪ劀")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࠩ劁")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ劂")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ劃")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭劄"),[l11lll_l1_ (u"࠭ࠧ劅")],[l11l11l_l1_]
	#elif l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ劆")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ劇")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1ll11_l1_(url)
	elif l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ劈")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩ劉")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111111ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࡢ࡯ࠪ劊") 		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭劋"),[l11lll_l1_ (u"࠭ࠧ劌")],[l11l11l_l1_]
	else: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ劍"),[l11lll_l1_ (u"ࠨࠩ劎")],[l11l11l_l1_]
	return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
def l11l1l1l1l11_l1_(url,source):
	server = SERVER(url,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ劏"))
	#if l11lll_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ劐")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ劑"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ劒"))
	#if any(value in server for value in l111llll1lll_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ劓")],[]
	l111l11ll11l_l1_ = False
	if   l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭劔")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll11l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ劕")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll11l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠭劖") in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll1ll11l_l1_(url)
	elif l11lll_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ劗")	in url: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lllll11l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭劘")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(url)
	elif l11lll_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ劙")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(url)
	elif l11lll_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ劚")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1lll_l1_(url)
	elif l11lll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ力")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l11ll11_l1_(url)
	elif l11lll_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ劜")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lll1lll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ劝")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1lll1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ办")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111ll111_l1_(url)
	elif l11lll_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ功")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1lllll1_l1_(url)
	elif l11lll_l1_ (u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ加")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11ll1111_l1_(url)
	elif l11lll_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ务")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11ll1l1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ劢")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11ll1l1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ劣")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ劤")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ劥")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ劦")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ劧")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ动")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ助")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1lll1_l1_(url)
	elif l11lll_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ努")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1lll1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ劫") 		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠪࠫ劬"),[l11lll_l1_ (u"ࠫࠬ劭")],[url]
	#elif l11lll_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ劮")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111l1lll_l1_(url)
	elif l11lll_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ劯") 	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll1l11_l1_(url)
	elif l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ劰")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l111l1l1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࡮࡯ࠨ励")in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll11llll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭劲") 	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1111l1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ劳")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l111ll_l1_(url)
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࠨ労") 			in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111111ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠬࡻࡰࡱࠩ劵") 			in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111111ll1l_l1_(url)
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ劶") 	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1lll11l_l1_(url)
	#elif l11lll_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ劷")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1lll11l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ劸") 		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111lll111l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ効") 	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll1ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ劺")		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11l1l11_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ劻") 		in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1111l1l_l1_(url)
	elif l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ劼") 	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1111ll11_l1_(url)
	elif l11lll_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ劽")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111lll1l1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ劾")	in server: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1llll1l_l1_(url)
	else: l111l11ll11l_l1_ = True
	if l111l11ll11l_l1_ or l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ势") in l11ll11111ll_l1_:
		l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ勀"),[],[]
	return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈࡗ࡙ࡘࡅࡂࡏࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡇࡐࡗࡑࡐࡎࡓࡉࡕࡇࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡊࡐࡗࡓ࡚ࡖࡌࡐࡃࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁ࡚ࠥࡈࡆࡘࡌࡈࡊࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡇ࡙ࡍࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡵࡲࡡࡺࡴ࠱࠸࡭࡫࡬ࡢ࡮ࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡌࡊࡒࡁࡍࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡇࡕࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡌࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡗࡍࡇࡒࡆࠪࡸࡶࡱ࠯ࠊࠊࠤࠥࠦ勁")
def l111lll11ll1_l1_(l11lllll1ll1_l1_):
	if l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ勂") in str(type(l11lllll1ll1_l1_)):
		links = []
		for link in l11lllll1ll1_l1_:
			if l11lll_l1_ (u"ࠬࡹࡴࡳࠩ勃") in str(type(link)):
				link = link.replace(l11lll_l1_ (u"࠭࡜ࡳࠩ勄"),l11lll_l1_ (u"ࠧࠨ勅")).replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ勆"),l11lll_l1_ (u"ࠩࠪ勇")).strip(l11lll_l1_ (u"ࠪࠤࠬ勈"))
			links.append(link)
	else: links = l11lllll1ll1_l1_.replace(l11lll_l1_ (u"ࠫࡡࡸࠧ勉"),l11lll_l1_ (u"ࠬ࠭勊")).replace(l11lll_l1_ (u"࠭࡜࡯ࠩ勋"),l11lll_l1_ (u"ࠧࠨ勌")).strip(l11lll_l1_ (u"ࠨࠢࠪ勍"))
	return links
def l1111l11l11l_l1_(url,source):
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ勎"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ勏")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ勐"))
	l1111ll1111l_l1_,link,l111lll11lll_l1_ = l11lll_l1_ (u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩ勑"),l11lll_l1_ (u"࠭ࠧ勒"),l11lll_l1_ (u"ࠧࠨ勓")
	l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11ll1l1_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ勔"),l11lll_l1_ (u"ࠩࠪ動"),l11lll_l1_ (u"ࠪࠫ勖"),l11ll11111ll_l1_)
	l1111_l1_ = l111lll11ll1_l1_(l1111_l1_)
	if l11ll11111ll_l1_==l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ勗"): return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_: link = l1111_l1_[0]
	if l11ll11111ll_l1_==l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ勘"):
		#l11ll11111ll_l1_ = l11ll11111ll_l1_.replace(l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ務"),l11lll_l1_ (u"ࠧࠨ勚"))
		l1111ll1111l_l1_ = l11lll_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ勛")
		l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l1l11_l1_(link,source)
		l1111_l1_ = l111lll11ll1_l1_(l1111_l1_)
		if l11ll11111ll_l1_==l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ勜"): return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
		elif l11lll_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ勝") in l11ll11111ll_l1_:
			l111lll11lll_l1_ += l11lll_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠬ勞")+l11ll11111ll_l1_
			l1111ll1111l_l1_ = l11lll_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ募")
			l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l11ll_l1_(link,source)
			l1111_l1_ = l111lll11ll1_l1_(l1111_l1_)
			if l11ll11111ll_l1_==l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ勠"): return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
			elif l11lll_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭勡") in l11ll11111ll_l1_:
				l111lll11lll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸࠺ࠡࠩ勢")+l11ll11111ll_l1_
				l1111ll1111l_l1_ = l11lll_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ勣")
				l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l11l1_l1_(link,source)
				l1111_l1_ = l111lll11ll1_l1_(l1111_l1_)
				if l11ll11111ll_l1_==l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ勤"): return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
				elif l11lll_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ勥") in l11ll11111ll_l1_:
					l111lll11lll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥ࠭勦")+l11ll11111ll_l1_
	elif l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ勧") in l11ll11111ll_l1_: l111lll11lll_l1_ = l11lll_l1_ (u"ࠧࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠳࠾ࠥ࠭勨")+l11ll11111ll_l1_
	if l1111_l1_: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ勩"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ勪")+l1111ll1111l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ勫")+url+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ勬")+link+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹࡵ࡭ࡶࡶ࠾ࠥࡡࠠࠨ勭")+str(l1111_l1_)+l11lll_l1_ (u"࠭ࠠ࡞ࠩ勮"))
	else: LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ勯"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ勰")+url+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ勱")+link+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡇࡵࡶࡴࡸࡳ࠻ࠢ࡞ࠤࠬ勲")+l111lll11lll_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ勳"))
	l111lll11lll_l1_ = l111l_l1_(l111lll11lll_l1_)
	return l111lll11lll_l1_,l1lll1ll_l1_,l1111_l1_
def l1111lll11l1_l1_(l11llll1lll1_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ勴"),l11llll1lll1_l1_)
	l11lll1ll11_l1_ = l11111l_l1_
	data = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ勵"),l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ勶"),l11llll1lll1_l1_)
	if data:
		l1lll1ll_l1_,l1111_l1_ = list(zip(*data))
		return l1lll1ll_l1_,l1111_l1_
	l1lll1ll_l1_,l1111_l1_,l11ll111111l_l1_ = [],[],[]
	for link in l11llll1lll1_l1_:
		if l11lll_l1_ (u"ࠨ࠱࠲ࠫ勷") not in link: continue
		l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11l1llll1ll_l1_(link,source)
		l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭勸"),l11l111l_l1_,re.DOTALL)
		if l11l111l_l1_: l11l111l_l1_ = int(l11l111l_l1_[0])
		else: l11l111l_l1_ = 0
		#if l11l111l_l1_:
		#	l11l1l11l11l_l1_ = sorted(l11l111l_l1_,reverse=True,key=lambda key: int(key))
		#	l11l111l_l1_ = int(l11l1l11l11l_l1_[0])
		#else: l11l111l_l1_ = 0
		server = SERVER(link,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ勹"))
		l11ll111111l_l1_.append([l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server])
	if l11ll111111l_l1_:
		#l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link = zip(*l11ll111111l_l1_)
		#name = reversed(name)
		#l11ll111111l_l1_ = zip(l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link)
		l1lll11ll1ll_l1_ = sorted(l11ll111111l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111lll11111_l1_ = []
		for line in l1lll11ll1ll_l1_:
			if line not in l111lll11111_l1_:
				l111lll11111_l1_.append(line)
				#LOG_THIS(l11lll_l1_ (u"ࠫࠬ勺"),str(line))
		for l111ll1111l1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server in l111lll11111_l1_:
			if l11l111l_l1_: l11l111l_l1_ = str(l11l111l_l1_)
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭勻")
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ勼"),l11lll_l1_ (u"ࠧࠨ勽"),name,link)
			title = l11lll_l1_ (u"ࠨีํีๆืࠧ勾")+l11lll_l1_ (u"ࠩࠣࠫ勿")+type+l11lll_l1_ (u"ࠪࠤࠬ匀")+l111ll1111l1_l1_+l11lll_l1_ (u"ࠫࠥ࠭匁")+l11l111l_l1_+l11lll_l1_ (u"ࠬࠦࠧ匂")+l1l1111_l1_+l11lll_l1_ (u"࠭ࠠࠨ匃")+name
			if server not in title: title = title+l11lll_l1_ (u"ࠧࠡࠩ匄")+server
			title = title.replace(l11lll_l1_ (u"ࠨࠧࠪ包"),l11lll_l1_ (u"ࠩࠪ匆")).strip(l11lll_l1_ (u"ࠪࠤࠬ匇")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ匈"),l11lll_l1_ (u"ࠬࠦࠧ匉")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ匊"),l11lll_l1_ (u"ࠧࠡࠩ匋")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ匌"),l11lll_l1_ (u"ࠩࠣࠫ匍"))
			if link not in l1111_l1_:
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		if l1111_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ匎"),l1111_l1_)
			data = list(zip(l1lll1ll_l1_,l1111_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ匏"),l11llll1lll1_l1_,data,l11lll1ll11_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭匐"),l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠾࠷ࡀࠠࠡࠢࠪ匑")+str(data))
	return l1lll1ll_l1_,l1111_l1_
def l11l1l1l11ll_l1_(url,source):
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ匒")
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ匓")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l1ll11ll1_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lll1lllll1_l1_ = str(error)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ匔"),l11lll_l1_ (u"ࠪࠫ匕"),l11lll_l1_ (u"ࠫࠬ化"),str(results))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭北"),l11lll_l1_ (u"࠭ࠧ匘"),l11lll_l1_ (u"ࠧࠨ匙"),str(l1lll1lllll1_l1_))
	# resolveurl l1111l1lll_l1_ l1ll1l11111_l1_ l1111l1lll11_l1_ with l11111l11l1l_l1_ error or l111lll1ll11_l1_ value False
	if not results:
		if l1lll1lllll1_l1_==l11lll_l1_ (u"ࠨࠩ匚"):
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ匛"),l11lll_l1_ (u"ࠪࠫ匜"),l11lll_l1_ (u"ࠫࠬ匝"),str(l1lll1lllll1_l1_))
		l11ll11111ll_l1_ = l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠤࡋࡧࡩ࡭ࡧࡧࠫ匞")
		l11ll11111ll_l1_ += l11lll_l1_ (u"࠭ࠠࠨ匟")+l1lll1lllll1_l1_.splitlines()[-1]
		return l11ll11111ll_l1_,[],[]
	return l11lll_l1_ (u"ࠧࠨ匠"),[l11lll_l1_ (u"ࠨࠩ匡")],[results]
def l11l1l1l11l1_l1_(url,source):
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡈࡡࡘࡡ࡭ࡩࡳࡵࡺࡌࡥࠪ匢")
	#url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯࠲ࡺ࡮ࡪࡥࡰ࠱ࡻ࠻ࡾࡿ࠴࠲ࡵࠪ匣")
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ匤"),l11lll_l1_ (u"ࠬ࠭匥"),url,l11lll_l1_ (u"࠭ࠧ匦"))
	#return l11lll_l1_ (u"ࠧࠨ匧"),[],[]
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ匨")
	results = False
	try:
		import youtube_dl
		l11l1lll1l11_l1_ = youtube_dl.YoutubeDL({l11lll_l1_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ匩"): True})
		results = l11l1lll1l11_l1_.extract_info(url,download=False)
	except Exception as error: l1lll1lllll1_l1_ = str(error)
	# youtube_dl l1111l1lll_l1_ l1ll1l11111_l1_ l1111l1lll11_l1_ with l11111l11l1l_l1_ error or l111lll1ll11_l1_ value False
	if not results or l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ匪") not in list(results.keys()):
		if l1lll1lllll1_l1_==l11lll_l1_ (u"ࠫࠬ匫"):
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭匬"),l11lll_l1_ (u"࠭ࠧ匭"),l11lll_l1_ (u"ࠧࠨ匮"),l1lll1lllll1_l1_)
		l11ll11111ll_l1_ = l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠠࡇࡣ࡬ࡰࡪࡪࠧ匯")
		l11ll11111ll_l1_ += l11lll_l1_ (u"ࠩࠣࠫ匰")+l1lll1lllll1_l1_.splitlines()[-1]
		return l11ll11111ll_l1_,[],[]
	else:
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link in results[l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ匱")]:
			l1lll1ll_l1_.append(link[l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫ匲")])
			l1111_l1_.append(link[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ匳")])
		return l11lll_l1_ (u"࠭ࠧ匴"),l1lll1ll_l1_,l1111_l1_
def l11l1lll11l1_l1_(url):
	if l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭匵") in url:
		l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(url)
		if l1111_l1_: return l11lll_l1_ (u"ࠨࠩ匶"),l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡁࡓࡃࡅࠫ匷"),[],[]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭匸"),[l11lll_l1_ (u"ࠫࠬ匹")],[url]
def l1l11l11l11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭区"),l11lll_l1_ (u"࠭ࠧ医"),l11lll_l1_ (u"ࠧࠨ匼"),url)
	l1lllll1_l1_,l1llll1ll1l_l1_ = [],[]
	if l11lll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴ࠰ࡰࡴ࠹ࡅࡶࡪࡦࡀࠫ匽") in url:
		# l11l111l11l1_l1_:
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1111ll111ll_l1_.html
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l11ll1l111_l1_.l1111lll_l1_?l1l11l1l111_l1_=49e3a27b4
		# l111l1ll11l1_l1_: https://l111llll1111_l1_.l1ll1l1lll1_l1_.l111111llll1_l1_.l1ll1ll11l1_l1_/15/items/40animeHD/l111lll1l111_l1_.l1111lll_l1_
		# l11l111l11l1_l1_:
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l111l1111ll1_l1_-l11l11111111_l1_.html
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l11ll1l111_l1_.l1111lll_l1_?l1l11l1l111_l1_=l11111lll1ll_l1_
		# l111l1ll11l1_l1_: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l11ll1l111_l1_/l111ll1ll1ll_l1_%20.l1111lll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭匾"),url,l11lll_l1_ (u"ࠪࠫ匿"),l11lll_l1_ (u"ࠫࠬ區"),False,l11lll_l1_ (u"ࠬ࠭十"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨ卂"))
		if l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ千") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ卄")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ卅"))
			l1llll1ll1l_l1_.append(server)
	elif l11lll_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ卆") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l11l111l11l1_l1_:
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l1ll1l1ll_l1_.html
		# link: https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l11l1lll1lll_l1_/?link=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1l1ll1ll_l1_&l11111ll1l11_l1_=
		# l11l111l11l1_l1_:
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# link: https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l1l111lll_l1_.l1ll1lllll_l1_?url=l11111l1l111_l1_==&sub=https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l11l111ll111_l1_/l11111l11ll1_l1_.l1111l11111l_l1_&l11111ll1l11_l1_=https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l1111ll1ll11_l1_/l111111l111l_l1_-1.l111l11111l1_l1_
		# l11l111l11l1_l1_:
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll1l1lll_l1_.html
		# link: https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l111l1llllll_l1_/?url=https://photos.l111l1l1111_l1_.l11l1111lll1_l1_.l11ll11l1lll_l1_/l111lll1llll_l1_&sub=&l11111ll1l11_l1_=http://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l1111ll1ll11_l1_/4723b8ebe-1.l111l11111l1_l1_
		# l11l111l11l1_l1_:
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l1lll1111_l1_.html
		# https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l11l1lll1lll_l1_/?link=https://l1l111111l1_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1l1ll1ll_l1_&sub=&l11111ll1l11_l1_=https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l1111ll1ll11_l1_/2e8bc4c34-1.l111l11111l1_l1_
		# l11l111l11l1_l1_:
		# https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_111l11l1ll1_l1_.html
		# https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l11l1lll1lll_l1_/?link=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1l1lll1l_l1_=l11l1l1ll1l1_l1_&l11111ll1l11_l1_=https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l1111ll1ll11_l1_/l11l111l111l_l1_-1.l111l11111l1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ升"),url,l11lll_l1_ (u"ࠬ࠭午"),l11lll_l1_ (u"࠭ࠧ卉"),l11lll_l1_ (u"ࠧࠨ半"),l11lll_l1_ (u"ࠨࠩ卋"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠳ࡰࡧࠫ卌"))
		html = response.content
		l1ll11l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࡧࡠ࠮࠴ࠪࡀ࡞ࠬࡠ࠮࠯࠮࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ卍"),html,re.DOTALL)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ华"),str(l1ll11l1llll_l1_))
		if l1ll11l1llll_l1_:
			l1ll11l1llll_l1_ = l1ll11l1llll_l1_[0]
			l1l1l1ll1l1l_l1_ = l1l1ll1llll1_l1_(l1ll11l1llll_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭协"),str(l1l1l1ll1l1l_l1_))
			l1l1l1l111ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ卐"),l1l1l1ll1l1l_l1_,re.DOTALL)
			if l1l1l1l111ll_l1_:
				l1l1l1l111ll_l1_ = l1l1l1l111ll_l1_[0]
				l1l1l1l111ll_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ卑"),l1l1l1l111ll_l1_)
				for dict in l1l1l1l111ll_l1_:
					link = dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪ࠭卒")]
					l11l111l_l1_ = dict[l11lll_l1_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ卓")]
					#link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭協")+l11l111l_l1_
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ单"))
					l1llll1ll1l_l1_.append(l11l111l_l1_+l11lll_l1_ (u"ࠬࠦࠧ卖")+server)
		elif l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ南") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ単")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭卙"))
			l1llll1ll1l_l1_.append(server)
		# l11l111l11l1_l1_: 5
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll1l1lll_l1_.html
		# link: https://www.l1l11l11ll1_l1_.com/l11111lll1l1_l1_/l111l1llllll_l1_/?url=https://photos.l111l1l1111_l1_.l11l1111lll1_l1_.l11ll11l1lll_l1_/l111lll1llll_l1_&sub=&l11111ll1l11_l1_=http://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l1111l11l1ll_l1_/l1111ll1ll11_l1_/4723b8ebe-1.l111l11111l1_l1_
		if l11lll_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ博") in url:
			link = url.split(l11lll_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࠩ卛"))[1]
			link = link.split(l11lll_l1_ (u"ࠫࠫ࠭卜"))[0]
			if link:
				l1lllll1_l1_.append(link)
				l1llll1ll1l_l1_.append(l11lll_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ卝"))
	else:
		# l11l111l11l1_l1_:
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_11111ll11l1_l1_.html
		# link: http://ok.l11l1111llll_l1_/l11l11l1ll11_l1_/1676019108395
		# l11l111l11l1_l1_:
		# url: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_11111lll11l_l1_.html
		# link: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1l1ll1ll_l1_
		l1lllll1_l1_.append(url)
		server = SERVER(url,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ卞"))
		l1llll1ll1l_l1_.append(server)
	if not l1lllll1_l1_: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ卟"),[],[]
	elif len(l1lllll1_l1_)==1: link = l1lllll1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭占"),l1llll1ll1l_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ卡"),[],[]
		link = l1lllll1_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭卢"),[l11lll_l1_ (u"ࠫࠬ卣")],[link]
def l111ll1ll11l_l1_(url):
	# test from: https://www.l1l11l11ll1_l1_.com/l11l1ll1l_l1_/l11l1l1lllll_l1_-l111ll1lll11_l1_-l111l1ll11ll_l1_-l1111llll1l1_l1_-l111l111111l_l1_-l11ll1l111_l1_-1-date.html
	# url = https://l11l11llllll_l1_.l111111l11l1_l1_.com/l111l1l1ll1l_l1_=l111llllll1l_l1_
	headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ卤"):l11lll_l1_ (u"࠭ࡋࡰࡦ࡬࠳ࠬ卥")+str(kodi_version)}
	for l11ll111l1_l1_ in range(50):
		time.sleep(0.100)
		response = l11lll11l11_l1_(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ卦"),url,l11lll_l1_ (u"ࠨࠩ卧"),headers,False,l11lll_l1_ (u"ࠩࠪ卨"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ卩"))
		if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭卪") in list(response.headers.keys()):
			link = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ卫")]
			link = link+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ卬")+headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ卭")]
			return l11lll_l1_ (u"ࠨࠩ卮"),[l11lll_l1_ (u"ࠩࠪ卯")],[link]
		if response.code!=429: break
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ印"),[],[]
def l111lllll11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ危"),l11lll_l1_ (u"ࠬ࠭卲"),l11lll_l1_ (u"࠭ࠧ即"),url)
	# https://photos.l111l1l1111_l1_.l11l1111lll1_l1_.l11ll11l1lll_l1_/l111lll1llll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ却"),url,l11lll_l1_ (u"ࠨࠩ卵"),l11lll_l1_ (u"ࠩࠪ卶"),l11lll_l1_ (u"ࠪࠫ卷"),l11lll_l1_ (u"ࠫࠬ卸"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫ卹"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ卺"),html,re.DOTALL)
	if link:
		link,l11l111l_l1_ = link[0]
		return l11lll_l1_ (u"ࠧࠨ卻"),[l11l111l_l1_],[link]
	return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩ卼"),[],[]
def l1l1lll1lll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ卽"),l11lll_l1_ (u"ࠪࠫ卾"),l11lll_l1_ (u"ࠫࠬ卿"),url)
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡴࡴࡥ࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡪ࡫ࡨ࠷࠱࠺ࡦ࠵࠾࠸ࡣ࠳࠺ࡧ࠵࠶࠸࠰࠳ࡣࡧ࠵࠽ࡪࡤ࠲࠴ࡦ࠺࠽࠶࠶ࠨ厀")
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡶࡩࡱ࡮ࡤ࠮ࡧࡰࡦࡪࡪ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡦ࠵࠷࠵࠺࠲࠷ࡥ࠽ࡧࡣࡧ࠹࠼࠹࠻ࡪ࠱ࡦ࠹࠹࠷࠵ࡨࡥ࠲࠹࠹࠹࠽࠽࠳ࠨ厁")
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ厂"),url,l11lll_l1_ (u"ࠨࠩ厃"),l11lll_l1_ (u"ࠩࠪ厄"),l11lll_l1_ (u"ࠪࠫ厅"),l11lll_l1_ (u"ࠫࠬ历"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ厇"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ厈"),html)
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ厉"),html,re.DOTALL)
	if link: return l11lll_l1_ (u"ࠨࠩ厊"),[l11lll_l1_ (u"ࠩࠪ压")],[link[0]]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ厌"),[],[]
def l1llllllll_l1_(url):
	if l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ厍") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ厎"),url,l11lll_l1_ (u"࠭ࠧ厏"),l11lll_l1_ (u"ࠧࠨ厐"),l11lll_l1_ (u"ࠨࠩ厑"),l11lll_l1_ (u"ࠩࠪ厒"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪ厓"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ厔"),html,re.DOTALL)
		link = link[0]
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ厕") in link: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ厖"),[l11lll_l1_ (u"ࠧࠨ厗")],[link]
		return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪ厘"),[],[]
	else: return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ厙"),[l11lll_l1_ (u"ࠪࠫ厚")],[url]
def l1ll1l1l1ll_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ厛"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭厜"),l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ厝"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ厞")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭原"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ厠"),l11lll_l1_ (u"ࠪࠫ厡"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫ厢"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ厣"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨ厤"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ厥"),[l11lll_l1_ (u"ࠨࠩ厦")],[link]
def l1l11ll1ll1l_l1_(url):
	headers = {l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ厧"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ厨")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ厩"),url,l11lll_l1_ (u"ࠬ࠭厪"),headers,l11lll_l1_ (u"࠭ࠧ厫"),l11lll_l1_ (u"ࠧࠨ厬"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪ厭"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ厮"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧ厯"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ厰"),[l11lll_l1_ (u"ࠬ࠭厱")],[link]
def l1l1l111l11_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ厲"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ厳")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭厴"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ厵"),l11lll_l1_ (u"ࠪࠫ厶"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭厷"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ厸"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪ厹"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ厺") not in link: link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ去")+link
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ厼"),l11lll_l1_ (u"ࠪࠫ厽"),l11lll_l1_ (u"ࠫࠬ厾"),link)
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ县"),[l11lll_l1_ (u"࠭ࠧ叀")],[link]
def l1lll1l111_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭叁"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ参")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ參"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ叄"),l11lll_l1_ (u"ࠫࠬ叅"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ叆"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ叇"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡁࡃࡆࡒࠫ又"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ叉"),[l11lll_l1_ (u"ࠩࠪ及")],[link]
def l1lll11l1l1l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ友"),l11lll_l1_ (u"ࠫࠬ双"),l11lll_l1_ (u"ࠬ࠭反"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ収"),url,l11lll_l1_ (u"ࠧࠨ叏"),l11lll_l1_ (u"ࠨࠩ叐"),l11lll_l1_ (u"ࠩࠪ发"),l11lll_l1_ (u"ࠪࠫ叒"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪ叓"))
	html = response.content
	l11111ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ叔"),html,re.DOTALL|re.IGNORECASE)
	if l11111ll11ll_l1_:
		l11111ll11ll_l1_ = l11111ll11ll_l1_[0][2:]
		#l11111ll11ll_l1_ = l11111ll11ll_l1_.decode(l11lll_l1_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭叕"))
		l11111ll11ll_l1_ = base64.b64decode(l11111ll11ll_l1_)
		if kodi_version>18.99: l11111ll11ll_l1_ = l11111ll11ll_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ取"))
		link = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭受"),l11111ll11ll_l1_,re.DOTALL)
	else: link = l11lll_l1_ (u"ࠩࠪ变")
	if not link: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫ叙"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ叚") not in link: link = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ叛")+link
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ叜"),[l11lll_l1_ (u"ࠧࠨ叝")],[link]
def l1111l1l11l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ叞"),url,l11lll_l1_ (u"ࠩࠪ叟"),l11lll_l1_ (u"ࠪࠫ叠"),l11lll_l1_ (u"ࠫࠬ叡"),l11lll_l1_ (u"ࠬ࠭叢"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨ口"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ古"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬ句"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ另"),[l11lll_l1_ (u"ࠪࠫ叧")],[link]
def l11lll1lll_l1_(url):
	id = url.split(l11lll_l1_ (u"ࠫ࠴࠭叨"))[-1]
	if l11lll_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ叩") in url: url = url.replace(l11lll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭只"),l11lll_l1_ (u"ࠧࠨ叫"))
	url = url.replace(l11lll_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࠧ召"),l11lll_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪ叭"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ叮"),url,l11lll_l1_ (u"ࠫࠬ可"),l11lll_l1_ (u"ࠬ࠭台"),l11lll_l1_ (u"࠭ࠧ叱"),l11lll_l1_ (u"ࠧࠨ史"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭右"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ叴"),url)
	l11ll11111ll_l1_ = l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ叵")
	error = re.findall(l11lll_l1_ (u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ叶"),html,re.DOTALL)
	if error: l11ll11111ll_l1_ = error[0]
	url = re.findall(l11lll_l1_ (u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ号"),html,re.DOTALL)
	if not url and l11ll11111ll_l1_:
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ司"),l11lll_l1_ (u"ࠧࠨ叹"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠪ叺"),l11ll11111ll_l1_)
		return l11ll11111ll_l1_,[],[]
	link = url[0].replace(l11lll_l1_ (u"ࠩ࡟ࡠࠬ叻"),l11lll_l1_ (u"ࠪࠫ叼"))
	l11llll11ll1_l1_,l11llll1lll1_l1_ = l11ll11lll_l1_(link)
	owner = re.findall(l11lll_l1_ (u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿ࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ叽"),html,re.DOTALL)
	if owner: l111l1l1l1ll_l1_,l11l1lll11ll_l1_,l11l11l11l11_l1_ = owner[0]
	else: l111l1l1l1ll_l1_,l11l1lll11ll_l1_,l11l11l11l11_l1_ = l11lll_l1_ (u"ࠬ࠭叾"),l11lll_l1_ (u"࠭ࠧ叿"),l11lll_l1_ (u"ࠧࠨ吀")
	l11l11l11l11_l1_ = l11l11l11l11_l1_.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ吁"),l11lll_l1_ (u"ࠩ࠲ࠫ吂"))
	l11l1lll11ll_l1_ = escapeUNICODE(l11l1lll11ll_l1_)
	l1lll1ll_l1_ = [l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ吃")+l11l1lll11ll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭各")]+l11llll11ll1_l1_
	l1111_l1_ = [l11l11l11l11_l1_]+l11llll1lll1_l1_
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭吅")+str(len(l1111_l1_)-1)+l11lll_l1_ (u"࠭ࠠๆๆไ࠭ࠬ吆"),l1lll1ll_l1_)
	if l1l_l1_==-1: return l11lll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ吇"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11lll_l1_ (u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧ合")+l11l11l11l11_l1_+l11lll_l1_ (u"ࠩࠩࡸࡪࡾࡴ࠾ࠩ吉")+l11l1lll11ll_l1_
		xbmc.executebuiltin(l11lll_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ吊")+new_path+l11lll_l1_ (u"ࠦ࠮ࠨ吋"))
		return l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ同"),[],[]
	link =  l1111_l1_[l1l_l1_]
	return l11lll_l1_ (u"࠭ࠧ名"),[l11lll_l1_ (u"ࠧࠨ后")],[link]
def l1111l11l_l1_(link):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ吏"),link,l11lll_l1_ (u"ࠩࠪ吐"),l11lll_l1_ (u"ࠪࠫ向"),l11lll_l1_ (u"ࠫࠬ吒"),l11lll_l1_ (u"ࠬ࠭吓"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅࡓࡐࡘࡁ࠮࠳ࡶࡸࠬ吔"))
	html = response.content
	if l11lll_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭吕") in link: url = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ吖"),html,re.DOTALL)
	else: url = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吗"),html,re.DOTALL)
	if not url: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡏࡌࡔࡄࠫ吘"),[],[]
	url = url[0]
	if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ吙") not in url: url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ吚")+url
	return l11lll_l1_ (u"࠭ࠧ君"),[l11lll_l1_ (u"ࠧࠨ吜")],[url]
def l11l1l11ll11_l1_(url):
	# http://l111l11lll11_l1_.l1lll111111l_l1_/l11l1llll1l1_l1_.html?l11l1ll11l1l_l1_=l111ll1llll1_l1_
	# http://l111l11lll11_l1_.l1lll111111l_l1_/l11l1l11l1ll_l1_?op=l11111l1111l_l1_&id=l11l1llll1l1_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ吝") : l11lll_l1_ (u"ࠩࠪ吞") }
	if l11lll_l1_ (u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭吟") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ吠"),headers,l11lll_l1_ (u"ࠬ࠭吡"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠶ࡹࡴࠨ吢"))
		#xbmc.log(html)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ吣"),l11lll_l1_ (u"ࠨࠩ吤"),url,html)
		items = re.findall(l11lll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ吥"),html,re.DOTALL)
		if items: return l11lll_l1_ (u"ࠪࠫ否"),[l11lll_l1_ (u"ࠫࠬ吧")],[items[0]]
		else:
			message = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ吨"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧ吩"),l11lll_l1_ (u"ࠧࠨ吪"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ含"),message[0])
				return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ听")+message[0],[],[]
	else:
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ吭"),l11lll_l1_ (u"ࠫࠬ吮"),link,l11lll_l1_ (u"ࠬ࠭启"))
		#url,l1ll111l11l_l1_ = url.split(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ吰"))
		#l1ll111l11l_l1_ = l1ll111l11l_l1_.lower()
		l1ll111l11l_l1_ = l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ吱")
		# l11l1ll1l_l1_ links
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ吲"),headers,l11lll_l1_ (u"ࠩࠪ吳"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬ吴"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭吵"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ吶"),[],[]
		l1lllll1ll_l1_ = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		if l11lll_l1_ (u"࠭࠮ࡳࡣࡵࠫ吷") in block or l11lll_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ吸") in block: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭吹"),[],[]
		items = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ吺"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l1ll_l1_(payload)
		html = OPENURL_CACHED(l1lll1111_l1_,l1lllll1ll_l1_,data,headers,l11lll_l1_ (u"ࠪࠫ吻"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭吼"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ吽"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ吾"),[],[]
		download = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		items = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ吿"),block,re.DOTALL)
		l11l11ll11ll_l1_,l1lll1ll_l1_,l11l1l1ll11l_l1_,l1111_l1_,l111l111l11l_l1_ = [],[],[],[],[]
		for link,title in items:
			if l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ呀") in link:
				l11l11ll11ll_l1_,l11l1l1ll11l_l1_ = l11ll11lll_l1_(link)
				l1111_l1_ = l1111_l1_ + l11l1l1ll11l_l1_
				if l11l11ll11ll_l1_[0]==l11lll_l1_ (u"ࠩ࠰࠵ࠬ呁"): l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ呂")+l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ呃")+l1ll111l11l_l1_)
				else:
					for title in l11l11ll11ll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ呄")+l11lll_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ呅")+l1ll111l11l_l1_+l11lll_l1_ (u"ࠧࠡࠩ呆")+title)
			else:
				title = title.replace(l11lll_l1_ (u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪ呇"),l11lll_l1_ (u"ࠩࠪ呈"))
				title = title.strip(l11lll_l1_ (u"ࠪࠦࠬ呉"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ告"),l11lll_l1_ (u"ࠬ࠭呋"),title,str(l111l111l11l_l1_))
				title = l11lll_l1_ (u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ呌")+l11lll_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭呍")+l1ll111l11l_l1_+l11lll_l1_ (u"ࠨࠢࠪ呎")+title
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		# download links
		link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ呏") + download
		html = OPENURL_CACHED(l1lll1111_l1_,link,l11lll_l1_ (u"ࠪࠫ呐"),headers,l11lll_l1_ (u"ࠫࠬ呑"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧ呒"))
		items = re.findall(l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥ呓"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11lll_l1_ (u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫ呔")+l11lll_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ呕")+l1ll111l11l_l1_+l11lll_l1_ (u"ࠩࠣࠫ呖")+resolution.split(l11lll_l1_ (u"ࠪࡼࠬ呗"))[1]
			link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ员")+id+l11lll_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ呙")+mode+l11lll_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭呚")+hash
			l111l111l11l_l1_.append(resolution)
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		l111l111l11l_l1_ = set(l111l111l11l_l1_)
		l111l1l11111_l1_,l11l11l1l111_l1_ = [],[]
		for title in l1lll1ll_l1_:
			#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ呛"),l11lll_l1_ (u"ࠨࠩ呜"),title,l11lll_l1_ (u"ࠩࠪ呝"))
			res = re.findall(l11lll_l1_ (u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥ呞"),title+l11lll_l1_ (u"ࠫࠫࠬࠧ呟"),re.DOTALL)
			for resolution in l111l111l11l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11lll_l1_ (u"ࠬࡾࠧ呠"))[1])
			l111l1l11111_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1111_l1_)):
			items = re.findall(l11lll_l1_ (u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢ呡"),l11lll_l1_ (u"ࠧࠧࠨࠪ呢")+l111l1l11111_l1_[i]+l11lll_l1_ (u"ࠨࠨࠩࠫ呣"),re.DOTALL)
			l11l11l1l111_l1_.append( [l111l1l11111_l1_[i],l1111_l1_[i],items[0][0],items[0][1]] )
		l11l11l1l111_l1_ = sorted(l11l11l1l111_l1_, key=lambda x: x[3], reverse=True)
		l11l11l1l111_l1_ = sorted(l11l11l1l111_l1_, key=lambda x: x[2], reverse=False)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for i in range(len(l11l11l1l111_l1_)):
			l1lll1ll_l1_.append(l11l11l1l111_l1_[i][0])
			l1111_l1_.append(l11l11l1l111_l1_[i][1])
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭呤"),[],[]
	return l11lll_l1_ (u"ࠪࠫ呥"),l1lll1ll_l1_,l1111_l1_
def l11l11ll1111_l1_(url):
	# http://l11111l11111_l1_.com/717254
	parts = url.split(l11lll_l1_ (u"ࠫࡄ࠭呦"))
	l11l11l_l1_ = parts[0]
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ呧") : l11lll_l1_ (u"࠭ࠧ周") }
	html = OPENURL_CACHED(l1lll1111_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ呩"),headers,l11lll_l1_ (u"ࠨࠩ呪"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩ呫"))
	items = re.findall(l11lll_l1_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ呬"),html,re.DOTALL)
	url = items[0]
	#l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11llll_l1_(url)
	#return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ呭"),[l11lll_l1_ (u"ࠬ࠭呮")],[url]
def l111l1lllll1_l1_(url):
	# https://l1ll1llllll_l1_.l1ll1ll11l1_l1_/l1lll1111l1_l1_
	# https://l1ll1ll11ll_l1_.cc/l1lll1111l1_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ呯") : l11lll_l1_ (u"ࠧࠨ呰") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠨࠩ呱"),headers,l11lll_l1_ (u"ࠩࠪ呲"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ味"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ呴"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠬ࠭呵"),[l11lll_l1_ (u"࠭ࠧ呶")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪ呷"),[],[]
def l11l11ll1l1l_l1_(url):
	# https://l1ll1llllll_l1_.l1ll1ll11l1_l1_/l1lll1111l1_l1_
	# https://l1ll1ll11ll_l1_.cc/l1lll1111l1_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ呸") : l11lll_l1_ (u"ࠩࠪ呹") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠪࠫ呺"),headers,l11lll_l1_ (u"ࠫࠬ呻"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ呼"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩ命"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠧࠨ呾"),[l11lll_l1_ (u"ࠨࠩ呿")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ咀"),[],[]
def l1l1llll11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ咁"),l11lll_l1_ (u"ࠫࠬ咂"),l11lll_l1_ (u"ࠬ࠭咃"),url)
	# l11l1ll1l_l1_    https://show.l111l1l1llll_l1_.com/l111l1l11l1l_l1_-l111l1l1111l_l1_/l111l1l1111l_l1_-l11l111111l1_l1_.l1ll1lllll_l1_?action=l111l111l1l1_l1_&post=32513&l1l1llll1l1_l1_=1&type=l1lll111111_l1_
	# download https://show.l111l1l1llll_l1_.com/links/l1111l11ll11_l1_
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"࠭ࠧ咄")
	# l11l1ll1l_l1_
	if l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࠫ咅") in url:
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ咆"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ咇")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ咈"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ咉"),l11lll_l1_ (u"ࠬ࠭咊"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩ咋"))
		l11lll1l_l1_ = response.content
		if l11lll1l_l1_.startswith(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ和")): l11l11l_l1_ = l11lll1l_l1_
		else:
			l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩ咍"),l11lll1l_l1_,re.DOTALL)
			if l11l1l1_l1_:
				l11l11l_l1_ = l11l1l1_l1_[0]
				l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩࠥࠩ咎"),l11l11l_l1_,re.DOTALL)
				if l11l1l1_l1_:
					l11l11l_l1_ = l111l_l1_(l11l1l1_l1_[0])
					return l11lll_l1_ (u"ࠪࠫ咏"),[l11lll_l1_ (u"ࠫࠬ咐")],[l11l11l_l1_]
	# download
	elif l11lll_l1_ (u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࠭咑") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ咒"),url,l11lll_l1_ (u"ࠧࠨ咓"),l11lll_l1_ (u"ࠨࠩ咔"),True,l11lll_l1_ (u"ࠩࠪ咕"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠴ࡷࡹ࠭咖"))
		l11lll1l_l1_ = response.content
		if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咗") in list(response.headers.keys()): l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咘")]
		else: l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ咙"),l11lll1l_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ咚"),l11lll_l1_ (u"ࠨࠩ咛"),l11l11l_l1_,str(2222))
	if l11lll_l1_ (u"ࠩ࠲ࡺ࠴࠭咜") in l11l11l_l1_ or l11lll_l1_ (u"ࠪ࠳࡫࠵ࠧ咝") in l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࠴࡬࠯ࠨ咞"),l11lll_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ咟"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭࠯ࡷ࠱ࠪ咠"),l11lll_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭咡"))
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ咢"),l11lll_l1_ (u"ࠩࠪ咣"),l11l11l_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ咤"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ咥"),l11lll_l1_ (u"ࠬ࠭咦"),l11lll_l1_ (u"࠭ࠧ咧"),l11lll_l1_ (u"ࠧࠨ咨"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ咩"))
		l11lll1l_l1_ = response.content
		items = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ咪"),l11lll1l_l1_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l11lll_l1_ (u"ࠪࡠࡡ࠭咫"),l11lll_l1_ (u"ࠫࠬ咬"))
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭咭"),l11lll1l_l1_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l11lll_l1_ (u"࠭࡜࡝ࠩ咮"),l11lll_l1_ (u"ࠧࠨ咯"))
				l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨࠩ咰"))
				l1111_l1_.append(link)
	else: return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ咱"),[l11lll_l1_ (u"ࠪࠫ咲")],[l11l11l_l1_]
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ咳"),l11lll_l1_ (u"ࠬ࠭咴"),str(l11ll1l11_l1_),l11l11l_l1_)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ咵"),[],[]
	return l11lll_l1_ (u"ࠧࠨ咶"),l1lll1ll_l1_,l1111_l1_
def l1l1ll111ll1_l1_(url):
	# l11l1ll1l_l1_ l1111lll_l1_  https://l111ll1l11ll_l1_.l11l1l1l1lll_l1_.l1ll1ll11l1_l1_/l11ll1111ll_l1_/l1111111lll1_l1_.l1ll1lllll_l1_?s=07&id=l11ll1111ll1_l1_,&l1llll_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l111l11111l1_l1_&l11l111llll1_l1_=l11111ll1111_l1_&l111l1lll111_l1_=l111111ll11l_l1_
	# l11l1ll1l_l1_ l1llll1l1_l1_ https://l11l1l1lll11_l1_.l11l1l1l1lll_l1_.l1ll1ll11l1_l1_/l11ll1111ll_l1_/l11111lllll1_l1_.l1ll1lllll_l1_?l11l11llll1l_l1_=l111l11lll1l_l1_&l111lll1l11l_l1_=8a26a6cc61a884e89076504130c71626&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l111l11111l1_l1_&l11l111llll1_l1_=l11111ll1111_l1_&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l111l11111l1_l1_&l11l111llll1_l1_=l11111ll1111_l1_&l111l1lll111_l1_=l111l11llll1_l1_
	# download https://www.l11l1l11l1l1_l1_.l111l1l11ll1_l1_/l11l11l11l1l_l1_?server=l11111llll11_l1_&id=l111lllll1ll_l1_,,
	# l1l111lll_l1_ https://l11l1l11l1l1_l1_.l1lll111ll_l1_/l1l111lll_l1_/l11l111l1lll_l1_
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ咷"),url,l11lll_l1_ (u"ࠩࠪ咸"),l11lll_l1_ (u"ࠪࠫ咹"),l11lll_l1_ (u"ࠫࠬ咺"),l11lll_l1_ (u"ࠬ࠭咻"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭咼"))
	html = response.content
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠧࠨ咽")
	if l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ咾") in url or l11lll_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ咿") in url:
		if l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭哀") in url:
			l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ品"),html,re.DOTALL)
			l11l11l_l1_ = l11l11l_l1_[0]
		else: l11l11l_l1_ = url
		if l11lll_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ哂") not in l11l11l_l1_: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ哃"),[l11lll_l1_ (u"ࠧࠨ哄")],[l11l11l_l1_]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ哅"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ哆"),l11lll_l1_ (u"ࠪࠫ哇"),l11lll_l1_ (u"ࠫࠬ哈"),l11lll_l1_ (u"ࠬ࠭哉"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭哊"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪ哋"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哌"),block,re.DOTALL)
		if items:
			for link,l1ll11l1l11l_l1_ in items:
				l1lll1ll_l1_.append(l1ll11l1l11l_l1_)
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫ响") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ哎"),html,re.DOTALL)
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ哏"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭哐"),l11lll_l1_ (u"࠭ࠧ哑"),l11lll_l1_ (u"ࠧࠨ哒"),l11lll_l1_ (u"ࠨࠩ哓"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ哔"))
		html = response.content
		l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ哕"),html,re.DOTALL)
		l11l1l1_l1_ = l11l1l1_l1_[0]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࠬ哖"))
		l1111_l1_.append(l11l1l1_l1_)
	elif l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬ哗") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哘"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ哙"),[l11lll_l1_ (u"ࠨࠩ哚")],[l11l11l_l1_]
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ哛"),[],[]
	return l11lll_l1_ (u"ࠪࠫ哜"),l1lll1ll_l1_,l1111_l1_
def l1llll1ll11_l1_(url):
	l1llll1ll1l_l1_,l1lllll1_l1_ = [],[]
	if l11lll_l1_ (u"ࠫ࠴࠷࠯ࠨ哝") in url:
		link = url.replace(l11lll_l1_ (u"ࠬ࠵࠱࠰ࠩ哞"),l11lll_l1_ (u"࠭࠯࠵࠱ࠪ哟"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ哠"),link,l11lll_l1_ (u"ࠨࠩ員"),l11lll_l1_ (u"ࠩࠪ哢"),False,l11lll_l1_ (u"ࠪࠫ哣"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭哤"))
		l11lll1l_l1_ = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫ哥"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ哦"),block,re.DOTALL)
			for link,l11l111l_l1_ in items:
				if link not in l1lllll1_l1_:
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ哧"))
					l1llll1ll1l_l1_.append(server+l11lll_l1_ (u"ࠨࠢࠣࠫ哨")+l11l111l_l1_)
			return l11lll_l1_ (u"ࠩࠪ哩"),l1llll1ll1l_l1_,l1lllll1_l1_
	elif l11lll_l1_ (u"ࠪ࠳ࡩ࠵ࠧ哪") in url:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ哫"),url,l11lll_l1_ (u"ࠬ࠭哬"),l11lll_l1_ (u"࠭ࠧ哭"),l11lll_l1_ (u"ࠧࠨ哮"),l11lll_l1_ (u"ࠨࠩ哯"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫ哰"))
		l11lll1l_l1_ = response.content
		link = re.findall(l11lll_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ哱"),l11lll1l_l1_,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"ࠫ࠴࠷࠯ࠨ哲"),l11lll_l1_ (u"ࠬ࠵࠴࠰ࠩ哳"))
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ哴"),link,l11lll_l1_ (u"ࠧࠨ哵"),l11lll_l1_ (u"ࠨࠩ哶"),False,l11lll_l1_ (u"ࠩࠪ哷"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࠬ哸"))
			l11lll1l_l1_ = response.content
			link = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ哹"),l11lll1l_l1_,re.DOTALL)
			if link: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ哺"),[l11lll_l1_ (u"࠭ࠧ哻")],[link[0]]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ哼"),[],[]
def l1lll11l1ll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ哽"),l11lll_l1_ (u"ࠩࠪ哾"),l11lll_l1_ (u"ࠪࠫ哿"),url)
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ唀"),url,l11lll_l1_ (u"ࠬ࠭唁"),l11lll_l1_ (u"࠭ࠧ唂"),l11lll_l1_ (u"ࠧࠨ唃"),l11lll_l1_ (u"ࠨࠩ唄"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫ唅"))
	html = response.content
	data = re.findall(l11lll_l1_ (u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ唆"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l11lll_l1_ (u"ࠫࡴࡶ࠽ࠨ唇")+op+l11lll_l1_ (u"ࠬࠬࡩࡥ࠿ࠪ唈")+id+l11lll_l1_ (u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧ唉")+fname
		headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭唊"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ唋")}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ唌"),url,data,headers,l11lll_l1_ (u"ࠪࠫ唍"),l11lll_l1_ (u"ࠫࠬ唎"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧ唏"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ唐"),html,re.DOTALL)
		if link: return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ唑"),[l11lll_l1_ (u"ࠨࠩ唒")],[link[0]]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭唓"),[],[]
def l11111ll1l_l1_(url):
	# https://l1lllll1111_l1_.l1llll1l1ll_l1_/l11ll1lll11_l1_?call=l11l111ll1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1ll11l1l_l1_=l111ll1ll1l1_l1_
	# https://l1lllll1111_l1_.l1llll1l1ll_l1_/l11ll1lll11_l1_?call=l11l111ll1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1ll11l1l_l1_=l111l1l11l11_l1_
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ唔"),1)[0].strip(l11lll_l1_ (u"ࠫࡄ࠭唕")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ唖")).strip(l11lll_l1_ (u"࠭ࠦࠨ唗"))
	l1lll1ll_l1_,l1111_l1_,items,l11l1l1_l1_ = [],[],[],l11lll_l1_ (u"ࠧࠨ唘")
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ唙"):l11lll_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩ唚") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ唛"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ唜"),headers,True,l11lll_l1_ (u"ࠬ࠭唝"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠵ࡸࡺࠧ唞"))
	if l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ唟") in list(response.headers.keys()): l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ唠")]
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭唡"),l11l1l1_l1_,l11lll_l1_ (u"ࠪࠫ唢"),headers,False,l11lll_l1_ (u"ࠫࠬ唣"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠵ࡲࡩ࠭唤"))
	#if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ唥") in response.headers: l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ唦")]
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ唧"),l11lll_l1_ (u"ࠩࠪ唨"),l11l1l1_l1_,response.content)
	if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ唩") in l11l1l1_l1_:
		# https://l1111l11ll_l1_.top/f/l11l11111lll_l1_/?l111ll11l1_l1_=l11ll11l11l1_l1_
		# https://l1111l11ll_l1_.top/v/l11l11111lll_l1_/?l111ll11l1_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ唪") in url: l11l1l1_l1_ = l11l1l1_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ唫"),l11lll_l1_ (u"࠭࠯ࡷ࠱ࠪ唬"))
		l11l1ll1l1l1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ唭"))[1]
		headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ售"):headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭唯")] , l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ唰"):l11lll_l1_ (u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ唱")+l11l1ll1l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ唲"),l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ唳"),headers,False,l11lll_l1_ (u"ࠧࠨ唴"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ唵"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1lll1111_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠩࠪ唶"),headers,l11lll_l1_ (u"ࠪࠫ唷"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠵ࡵࡨࠬ唸"))
		if l11lll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ唹") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唺"),html,re.DOTALL)
		elif l11lll_l1_ (u"ࠧ࠰ࡸ࠲ࠫ唻") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唼"),html,re.DOTALL)
		if items: return [],[l11lll_l1_ (u"ࠩࠪ唽")],[ items[0] ]
		elif l11lll_l1_ (u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩ唾") in html:
			return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧ唿"),[],[]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨ啀"),[],[]
	#xbmc.log(html)
def l11111111ll_l1_(link):
	# https://l11ll11l1l1l_l1_.net/?l11llll1_l1_=147043&l1l11111_l1_=5
	parts = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ啁"),link+l11lll_l1_ (u"ࠧࠧࠨࠪ啂"),re.DOTALL|re.IGNORECASE)
	l11llll1_l1_,l1l11111_l1_ = parts[0]
	url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ啃")+l11llll1_l1_+l11lll_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭啄")+l1l11111_l1_
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ啅"):l11lll_l1_ (u"ࠫࠬ商") , l11lll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ啇"):l11lll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ啈") }
	l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ啉"),headers,l11lll_l1_ (u"ࠨࠩ啊"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ啋"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ啌"),l11lll_l1_ (u"ࠫࠬ啍"),url,l11l11l_l1_)
	#l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11llll_l1_(l11l11l_l1_)
	#return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ啎"),[l11lll_l1_ (u"࠭ࠧ問")],[l11l11l_l1_]
def l1ll1111ll11_l1_(url):
	# https://l111111lll1l_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l11111ll1_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11l1lll1_l1_=1608181746
	server = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ啐"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ啑"):server,l11lll_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ啒"):l11lll_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ啓")}
	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ啔"),url,l11lll_l1_ (u"ࠬ࠭啕"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ啖"),l11lll_l1_ (u"ࠧࠨ啗"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ啘"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ啙"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠪࠫ啚")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ啛"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ啜"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࠧ啝"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ啞"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ啟"),[],[]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ啠"),[l11lll_l1_ (u"ࠪࠫ啡")],[l11l11l_l1_]
def l1l1l11ll1ll_l1_(url):
	# https://l11ll11l1ll1_l1_.l1111l1l111l_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l11111ll1_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11l1lll1_l1_=1608181746
	# https://l11ll11l1ll1_l1_.l1llll1l1ll_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l11l11111ll1_l1_=l11l1lllll1l_l1_&l11l11l1lll1_l1_=1684182121
	server = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ啢"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭啣"):server,l11lll_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ啤"):l11lll_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ啥")}
	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ啦"),url,l11lll_l1_ (u"ࠩࠪ啧"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ啨"),l11lll_l1_ (u"ࠫࠬ啩"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ啪"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ啫"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠧࠨ啬")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ啭"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ啮"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠪࠫ啯"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	if not l11l11l_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ啰"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ啱"),[],[]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ啲"),[l11lll_l1_ (u"ࠧࠨ啳")],[l11l11l_l1_]
def l1l1l111_l1_(link):
	# https://w.l111l11l1l1l_l1_.l1lll1lll11_l1_/l111l1l11l1l_l1_-content/l11ll1111l1l_l1_/l111l11l1111_l1_/l11l1l11lll1_l1_/l111l111llll_l1_/l111ll1l11l1_l1_/l111l1l1l111_l1_.l1ll1lllll_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ啴"),l11lll_l1_ (u"ࠩࠪ啵"),link,html)
	parts = re.findall(l11lll_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ啶"),link+l11lll_l1_ (u"ࠫࠫࠬࠧ啷"),re.DOTALL)
	url,l11llll1_l1_,l1l11111_l1_ = parts[0]
	data = {l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭啸"):l11llll1_l1_,l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭啹"):l1l11111_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ啺"),url,data,l11lll_l1_ (u"ࠨࠩ啻"),l11lll_l1_ (u"ࠩࠪ啼"),l11lll_l1_ (u"ࠪࠫ啽"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭啾"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ啿"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ喀"),[l11lll_l1_ (u"ࠧࠨ喁")],[l11l11l_l1_]
def l1ll1ll11l_l1_(url):
	# https://l11l11l1l1l1_l1_.l1lll111l1_l1_-l11l11ll1ll1_l1_.com/l1l111lll_l1_.l1ll1lllll_l1_?l1l11l1l111_l1_=l111l1lll1l1_l1_
	# https://l.l111l1l1l11l_l1_.l111l1l11ll1_l1_/l1l111lll_l1_.l1ll1lllll_l1_?l1l11l1l111_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ喂"),url,l11lll_l1_ (u"ࠩࠪ喃"),l11lll_l1_ (u"ࠪࠫ善"),l11lll_l1_ (u"ࠫࠬ喅"),l11lll_l1_ (u"ࠬ࠭喆"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࠷ࡳࡵࠩ喇"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喈"),html,re.DOTALL)
	if link:
		link = link[0]
		if link: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ喉"),[l11lll_l1_ (u"ࠩࠪ喊")],[link]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ喋"),[],[]
def l1lll11l1l_l1_(url):
	# https://l1lll1111l_l1_.l1lll111l1_l1_-l1lll111ll_l1_.l1lll111ll_l1_/l111l1l11l1l_l1_-content/l11ll1111l1l_l1_/old/l1llll1_l1_/server.l1ll1lllll_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ喌"),url,l11lll_l1_ (u"ࠬ࠭喍"),l11lll_l1_ (u"࠭ࠧ喎"),l11lll_l1_ (u"ࠧࠨ喏"),l11lll_l1_ (u"ࠨࠩ喐"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ喑"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ喒"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ喓"),[l11lll_l1_ (u"ࠬ࠭喔")],[link]
def l1ll1l1lll_l1_(url):
	# https://l11llll1ll1_l1_.l1l111llll1l_l1_.cc/l111l1l11l1l_l1_-content/l11ll1111l1l_l1_/l1111ll11l1l_l1_%20Now%20New/l1111l11l1l1_l1_.l1ll1lllll_l1_?action=l11l11ll111l_l1_&index=00&id=58504
	# https://l11l11111l1l_l1_.l1l111llll1l_l1_.net/l1111l11l1ll_l1_/2021/04/05/_111l1llll11_l1_-l11ll11l1111_l1_.l111111l1111_l1_ 200.l1111l1111l1_l1_.2020.l1111l1l1l1l_l1_/[l1111ll11l1l_l1_-l11ll11l1111_l1_.l1111lll1l11_l1_] 200.l1111l1111l1_l1_.2020.l1111l1l1l1l_l1_-360p.l1111lll_l1_
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ喕"))
	if l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ喖") in url:
		headers = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ喗"):l1llllll11_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭喘"),url,l11lll_l1_ (u"ࠪࠫ喙"),headers,l11lll_l1_ (u"ࠫࠬ喚"),l11lll_l1_ (u"ࠬ࠭喛"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ喜"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ喝"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			if l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ喞") in l11l11l_l1_:
				l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ喟"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ喠"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ喡"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭喢"),headers,l11lll_l1_ (u"࠭ࠧ喣"),l11lll_l1_ (u"ࠧࠨ喤"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ喥"))
				l11lll1l_l1_ = response.content
				items = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喦"),l11lll1l_l1_,re.DOTALL)
				l1lll1ll_l1_,l1111_l1_ = [],[]
				l1llll1lll_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ喧"))
				for link,l11l111l_l1_ in reversed(items):
					link = l1llll1lll_l1_+link+l11lll_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ喨")+l1llll1lll_l1_
					l1lll1ll_l1_.append(l11l111l_l1_)
					l1111_l1_.append(link)
				return l11lll_l1_ (u"ࠬ࠭喩"),l1lll1ll_l1_,l1111_l1_
			else: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ喪"),[l11lll_l1_ (u"ࠧࠨ喫")],[l11l11l_l1_]
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ喬")+l1llllll11_l1_
	return l11lll_l1_ (u"ࠩࠪ喭"),[l11lll_l1_ (u"ࠪࠫ單")],[l11l11l_l1_]
def l111lll11l1l_l1_(link):
	# https://l1l111llll1l_l1_.l1lll1lll11_l1_/l111l1l11l1l_l1_-content/l11ll1111l1l_l1_/l11l11l1llll_l1_/l1111l11ll1l_l1_/server.l1ll1lllll_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	# https://l11l1l1llll1_l1_.l1l111llll1l_l1_.net/l1111l11l1ll_l1_/2020/08/14/_111l1llll11_l1_-l11ll11l1111_l1_.l111111l1111_l1_ l1111ll111l1_l1_.l111ll1lll1l_l1_.2020.l111ll111l1l_l1_-l111lll111l1_l1_/[l1111ll11l1l_l1_-l11ll11l1111_l1_.l1111lll1l11_l1_] l1111ll111l1_l1_.l111ll1lll1l_l1_.2020.l111ll111l1l_l1_-l111lll111l1_l1_-1080p.l1111lll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ喯"),l11lll_l1_ (u"ࠬ࠭喰"),url,html)
	l1llllll11_l1_ = SERVER(link,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ喱"))
	if l11lll_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ喲") in link:
		parts = re.findall(l11lll_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ喳"),link+l11lll_l1_ (u"ࠩࠩࠪࠬ喴"),re.DOTALL)
		url,l11llll1_l1_,l1l11111_l1_ = parts[0]
		data = {l11lll_l1_ (u"ࠪ࡭ࡩ࠭喵"):l11llll1_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ営"):l1l11111_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ喷"),url,data,l11lll_l1_ (u"࠭ࠧ喸"),l11lll_l1_ (u"ࠧࠨ喹"),l11lll_l1_ (u"ࠨࠩ喺"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ喻"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喼"),html,re.DOTALL)[0]
		if l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ喽") in l11l11l_l1_:
			headers = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭喾"):l1llllll11_l1_,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ喿"):l11lll_l1_ (u"ࠧࠨ嗀")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ嗁"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ嗂"),headers,l11lll_l1_ (u"ࠪࠫ嗃"),l11lll_l1_ (u"ࠫࠬ嗄"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭嗅"))
			l11lll1l_l1_ = response.content
			items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嗆"),l11lll1l_l1_,re.DOTALL)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			l1llll1lll_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ嗇"))
			for link,l11l111l_l1_ in reversed(items):
				link = l1llll1lll_l1_+link+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ嗈")+l1llll1lll_l1_
				l1lll1ll_l1_.append(l11l111l_l1_)
				l1111_l1_.append(link)
			return l11lll_l1_ (u"ࠩࠪ嗉"),l1lll1ll_l1_,l1111_l1_
		else: return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嗊"),[l11lll_l1_ (u"ࠫࠬ嗋")],[l11l11l_l1_]
	else:
		link = link+l11lll_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ嗌")+l1llllll11_l1_
		return l11lll_l1_ (u"࠭ࠧ嗍"),[l11lll_l1_ (u"ࠧࠨ嗎")],[link]
def l111lll1l_l1_(link):
	# http://l11l1llll11l_l1_.tv/?l11llll1_l1_=159485&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ嗏") in link:
		parts = re.findall(l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ嗐"),link+l11lll_l1_ (u"ࠪࠪࠫ࠭嗑"),re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		host = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ嗒"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭嗓"),l11lll_l1_ (u"࠭ࠧ嗔"),link,host)
		url = host+l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ嗕")+l11llll1_l1_+l11lll_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ嗖")+l1l11111_l1_
		headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嗗"):l11lll_l1_ (u"ࠪࠫ嗘") , l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ嗙"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭嗚") }
		l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ嗛"),headers,l11lll_l1_ (u"ࠧࠨ嗜"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ嗝"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ嗞"),l11lll_l1_ (u"ࠪࠫ嗟")).replace(l11lll_l1_ (u"ࠫࡡࡸࠧ嗠"),l11lll_l1_ (u"ࠬ࠭嗡"))
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嗢"),l11lll_l1_ (u"ࠧࠨ嗣"),url,l11l11l_l1_)
		#l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11llll_l1_(l11l11l_l1_)
		#return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嗤"),[l11lll_l1_ (u"ࠩࠪ嗥")],[l11l11l_l1_]
	elif l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ嗦") in link:
		counts = 0
		while l11lll_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ嗧") in link and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ嗨"),link,l11lll_l1_ (u"࠭ࠧ嗩"),l11lll_l1_ (u"ࠧࠨ嗪"),l11lll_l1_ (u"ࠨࠩ嗫"),l11lll_l1_ (u"ࠩࠪ嗬"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬ嗭"))
			if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭嗮") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ嗯")]
			counts += 1
		return l11lll_l1_ (u"࠭ࠧ嗰"),[l11lll_l1_ (u"ࠧࠨ嗱")],[link]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ嗲"),[],[]
def l11l1l111_l1_(url):
	# https://l111l1ll111l_l1_.l1111lll1111_l1_.me/l/l11ll1111111_l1_=
	# https://l11l111lll11_l1_.l1111l1l1lll_l1_.net/l1l111lll_l1_-l1l111lll_l1_-l1111l1llll1_l1_.html
	# https://m.l1111l1l1lll_l1_.net/l1111l1llll1_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嗳"),l11lll_l1_ (u"ࠪࠫ嗴"),l11lll_l1_ (u"ࠫࠬ嗵"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嗶"))
	if l11lll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ嗷") in url and l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ嗸") not in url: url = server+l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ嗹")+url.split(l11lll_l1_ (u"ࠩ࠲ࠫ嗺"))[-1]+l11lll_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ嗻")
	headers = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ嗼"):server,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ嗽"):l1l11111l_l1_()}
	if l11lll_l1_ (u"࠭࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ嗾") in url:
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭嗿"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ嘀")}
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ嘁"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠪࠫ嘂"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠴ࡷࡹ࠭嘃"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࡙ࠬࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嘄"),html,re.DOTALL|re.IGNORECASE)
		if link: return l11lll_l1_ (u"࠭ࠧ嘅"),[l11lll_l1_ (u"ࠧࠨ嘆")],[link[0]]
	elif l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ嘇") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ嘈"),headers,l11lll_l1_ (u"ࠪࠫ嘉"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭嘊"))
		link = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嘋"),html,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ嘌"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ嘍"))
			return l11lll_l1_ (u"ࠨࠩ嘎"),[l11lll_l1_ (u"ࠩࠪ嘏")],[link]
	else:
		l111l1ll1l11_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嘐"),url,l11lll_l1_ (u"ࠫࠬ嘑"),headers,l11lll_l1_ (u"ࠬ࠭嘒"),l11lll_l1_ (u"࠭ࠧ嘓"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ嘔"))
		html = l111l1ll1l11_l1_.content
		link = re.findall(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ嘕"),html,re.DOTALL)
		if link:
			link = l111l_l1_(link[0])+l11lll_l1_ (u"ࠩࠩࡨࡂ࠷ࠧ嘖")
			l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嘗"),link,l11lll_l1_ (u"ࠫࠬ嘘"),headers,l11lll_l1_ (u"ࠬ࠭嘙"),l11lll_l1_ (u"࠭ࠧ嘚"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ嘛"))
			html = l1ll111ll_l1_.content
			link = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嘜"),html,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠩࠪ嘝"),[l11lll_l1_ (u"ࠪࠫ嘞")],[link]
		if l11lll_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ嘟") in list(l111l1ll1l11_l1_.headers.keys()):
			cookies = l111l1ll1l11_l1_.headers[l11lll_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ嘠")]
			link = re.findall(l11lll_l1_ (u"࠭࡟࡭ࡰ࡮ࡣ࠳࠰࠿࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ嘡"),cookies,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嘢"),[l11lll_l1_ (u"ࠨࠩ嘣")],[link]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡕࡈࡉࡉ࠭嘤"),[],[]
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠥࠣࡲࡴࡺࠠࡸࡱࡵ࡯࡮ࡴࡧࠋࠋࠌࠧࠥ࡯ࡴࠡࡰࡨࡩࡩࡹࠠࡤࡱࡲ࡯࡮࡫ࠠࡧࡴࡲࡱࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠌࠌࠍࠨࠦࡃࡰࡱ࡮࡭ࡪࡀࠠࡤࡨࡢࡧࡱ࡫ࡡࡳࡣࡱࡧࡪࡃࡃࡎࡧ࠱ࡌࡐࡍࡑ࡬࡯ࡺࡲࡘ࡜ࡵ࡯ࡼ࡙ࡍࡵࡷ࡯ࡸࡳࡖࡅ࡟ࡩࡰ࡯ࡈ࠺࡮ࡇࡖࡕࡐࡓࡥ࡝ࡇࡌ࠰࠮࠳࠹࠺࠸࠷࠱࠳࠲࠳࠺࠲࠶࠭࠳࠷࠳ࠎࠎࠏࡳࡦࡴࡹࡩࡷࠦ࠽ࠡࡕࡈࡖ࡛ࡋࡒࠩࡷࡵࡰ࠱࠭ࡵࡳ࡮ࠪ࠭ࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࠽ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠮ࠩ࠭ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡸ࡫ࡲࡷࡧࡵࢁࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࡭࡫ࡱ࡯࠳࡮ࡲࡦࡨࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࡽࡴࡨ࠲ࡎࡍࡎࡐࡔࡈࡇࡆ࡙ࡅࠪࠌࠌࠍ࡮࡬ࠠ࡭࡫ࡱ࡯ࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡫࡭ࡣࡧࡧ࠱ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭࡝ࠪࠫࡢ࠲࡛࡭࡫ࡱ࡯ࡢࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡷࡵࡰࠥࡃࠠ࡭࡫ࡱ࡯ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠬࡩࡶࡰࡰ࠮ࠐࠉࠊࠥ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍࠎࠩࡩࡧࠢࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠤࠋࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠣࠊࡴࡨࡸࡺࡸ࡮ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠋࠋࠌࠧࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠤࠥࠦ嘥")
	#if l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵࠰࡫ࡸࡲࡲࠧ嘦") in url:
	#	l1ll11ll11l1_l1_ = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ嘧"))
	#	url = l11lll_l1_ (u"࠭࠯ࠨ嘨").join(l1ll11ll11l1_l1_[:4])
	#	tmp = re.findall(l11lll_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀ࠱࠲࠲࠯ࡅ࠯ࠪࠪ࠱࠮ࡄ࠯ࠤࠨ嘩"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11lll_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ嘪")+tmp[0][1]+l11lll_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ嘫")
	#	#return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嘬"),[l11lll_l1_ (u"ࠫࠬ嘭")],[url]
	#	#l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1ll1_l1_(url)
	#	#return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
	# l1l111lll_l1_ link
	#return l11lll_l1_ (u"ࠬ࠭嘮"),[l11lll_l1_ (u"࠭ࠧ嘯")],[link]
def l1l1l11l1l11_l1_(link):
	# https://l111ll11ll11_l1_.l111lll11l11_l1_/l1111111l1ll_l1_?_1111llll111_l1_=l11111l11lll_l1_&_111l111ll1l_l1_=86046&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠧࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠫ嘰") in link:
		headers = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ嘱"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ嘲")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嘳"),link,l11lll_l1_ (u"ࠫࠬ嘴"),headers,l11lll_l1_ (u"ࠬ࠭嘵"),l11lll_l1_ (u"࠭ࠧ嘶"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠷ࡳࡵࠩ嘷"))
		url = response.content
		if url: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嘸"),[l11lll_l1_ (u"ࠩࠪ嘹")],[url]
	else:
		# https://l1111l1ll111_l1_.net/?l11llll1_l1_=142302&l1l11111_l1_=4
		parts = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ嘺"),link,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11lll_l1_ (u"ࠫࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ嘻"),link,re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		server = SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嘼"))
		#url = server+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ嘽")
		url = server+l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ嘾")
		#url = server+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭嘿")+l11llll1_l1_+l11lll_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭噀")+l1l11111_l1_
		#data = {l11lll_l1_ (u"ࠪ࡭ࡩ࠭噁"):l11llll1_l1_,l11lll_l1_ (u"ࠫ࡮࠭噂"):l1l11111_l1_,l11lll_l1_ (u"ࠬࡳࡥࡵࡣࠪ噃"):l11lll_l1_ (u"࠭࡯࡭ࡦࡢࡷࡪࡸࡶࡦࡴࡶࠫ噄"),l11lll_l1_ (u"ࠧࡵࡻࡳࡩࠬ噅"):l11lll_l1_ (u"ࠨࡱ࡯ࡨࠬ噆")}
		data = {l11lll_l1_ (u"ࠩ࡬ࡨࠬ噇"):l11llll1_l1_,l11lll_l1_ (u"ࠪ࡭ࠬ噈"):l1l11111_l1_}
		headers = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ噉"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭噊"),l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ噋"):link}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ噌"),url,data,headers,l11lll_l1_ (u"ࠨࠩ噍"),l11lll_l1_ (u"ࠩࠪ噎"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬ噏"))
		l11lll1l_l1_ = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ噐"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ噑"),[l11lll_l1_ (u"࠭ࠧ噒")],[l11l11l_l1_]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ噓"),[],[]
def l111llll11l1_l1_(l1111l111111_l1_):
	l11l1l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡵࡷࡶࠬ噔"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ噕"),l11lll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࡡ࡙ࡉࡗࡏࡆࡊࡅࡄࡘࡎࡕࡎࠨ噖"))
	headers = {l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ噗"):l11l1l1l1_l1_} if l11l1l1l1_l1_ else l11lll_l1_ (u"ࠬ࠭噘")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ噙"),l1111l111111_l1_,l11lll_l1_ (u"ࠧࠨ噚"),headers,l11lll_l1_ (u"ࠨࠩ噛"),l11lll_l1_ (u"ࠩࠪ噜"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪ噝"))
	l1111l111l1l_l1_ = response.content
	l1111ll11111_l1_ = str(response.headers)
	l1111lll1ll1_l1_ = l1111ll11111_l1_+l1111l111l1l_l1_
	if l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ噞") in l1111lll1ll1_l1_: l1ll1ll1l_l1_ = True
	else:
		l11111l1l1l1_l1_,token,l11l11ll1l11_l1_,l111l111l111_l1_,l1ll1ll1l_l1_ = l11lll_l1_ (u"ࠬ࠭噟"),l11lll_l1_ (u"࠭ࠧ噠"),l11lll_l1_ (u"ࠧࠨ噡"),l11lll_l1_ (u"ࠨࠩ噢"),False
		l11l1l11l111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ噣"),l1111l111l1l_l1_,re.DOTALL)
		if l11l1l11l111_l1_: l11l11ll1l11_l1_,l111l111l111_l1_ = l11l1l11l111_l1_[0]
		l111ll111l11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ噤")][7]
		user = l11llll111l_l1_(32)
		if 0:
			data = {l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ噥"):user,l11lll_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭噦"):l11ll111111_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ噧"):l1111l111111_l1_,l11lll_l1_ (u"ࠧ࡬ࡧࡼࠫ器"):l111l111l111_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࠫ噩"):l11lll_l1_ (u"ࠩࠪ噪"),l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ噫"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬ噬")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ噭"),l111ll111l11_l1_,data,l11lll_l1_ (u"࠭ࠧ噮"),l11lll_l1_ (u"ࠧࠨ噯"),l11lll_l1_ (u"ࠨࠩ噰"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠸࡮ࡥࠩ噱"))
			html = response.content
		html = l11lll_l1_ (u"ࠪࠫ噲")
		if html.startswith(l11lll_l1_ (u"࡚ࠫࡘࡌࡔ࠿ࠪ噳")):
			l11lllll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ噴"),html.split(l11lll_l1_ (u"࠭ࡕࡓࡎࡖࡁࠬ噵"),1)[1])
			for request in l11lllll1ll1_l1_:
				url = request[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ噶")]
				method = request[l11lll_l1_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࠨ噷")]
				data = request[l11lll_l1_ (u"ࠩࡧࡥࡹࡧࠧ噸")]
				headers = request[l11lll_l1_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫ噹")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠫࠬ噺"),l11lll_l1_ (u"ࠬ࠭噻"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭噼"))
				l1111l111l1l_l1_ = response.content
				if l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ噽") in l1111l111l1l_l1_:
					l1ll1ll1l_l1_ = True
					break
				l1111ll11111_l1_ = str(response.headers)
				l1111lll1ll1_l1_ = l1111ll11111_l1_+l1111l111l1l_l1_
				l11111l1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡢࡷࠬࠫ࠱࠮ࡄࠨࠨࡦࡻࡍ࠲࠯ࡅࠩࠣࠩ噾"),l1111lll1ll1_l1_,re.DOTALL)
				token = re.findall(l11lll_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱ࠲࠯ࡅࠢࠩ࠲࠶ࡅ࠳࠰࠿ࠪࠤࠪ噿"),l1111lll1ll1_l1_,re.DOTALL)
				if token: token = token[0]
				if l11111l1l1l1_l1_ or token: break
		if not l1ll1ll1l_l1_:
			if not l11111l1l1l1_l1_:
				if not token and l11l1l11l111_l1_:
					if 1 and not html.startswith(l11lll_l1_ (u"ࠪࡍࡉࡃࠧ嚀")):
						data = {l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ嚁"):user,l11lll_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭嚂"):l11ll111111_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ嚃"):l1111l111111_l1_,l11lll_l1_ (u"ࠧ࡬ࡧࡼࠫ嚄"):l111l111l111_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࠫ嚅"):l11lll_l1_ (u"ࠩࠪ嚆"),l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ嚇"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡪࡦࠪ嚈")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ嚉"),l111ll111l11_l1_,data,l11lll_l1_ (u"࠭ࠧ嚊"),l11lll_l1_ (u"ࠧࠨ嚋"),l11lll_l1_ (u"ࠨࠩ嚌"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩ嚍"))
						html = response.content
					else: html = l11lll_l1_ (u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫ嚎")
					if html.startswith(l11lll_l1_ (u"ࠫࡎࡊ࠽ࠨ嚏")):
						l1111llll11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫ嚐"),html,re.DOTALL)
						l111l111l1ll_l1_,timeout = l1111llll11l_l1_[0]
						message = l11lll_l1_ (u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫ嚑")+timeout+l11lll_l1_ (u"ࠧࠡอส๊๏ฯࠧ嚒")
						l11l1ll11l_l1_ = DIALOG_PROGRESS()
						l11l1ll11l_l1_.create(l11lll_l1_ (u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧ嚓"),message)
						t1 = time.time()
						l11l1ll11111_l1_,l11l1l111111_l1_ = 0,0
						while l11l1ll11111_l1_<int(timeout):
							PROGRESS_UPDATE(l11l1ll11l_l1_,int(l11l1ll11111_l1_/int(timeout)*100),message,l11lll_l1_ (u"ࠩࠪ嚔"),timeout+l11lll_l1_ (u"ࠪࠤ࠴ࠦࠧ嚕")+str(int(l11l1ll11111_l1_))+l11lll_l1_ (u"ࠫࠥࠦหศ่ํอࠬ嚖"))
							#if l11l1ll11l_l1_.iscanceled(): break
							if l11l1ll11111_l1_>l11l1l111111_l1_+10:
								data = {l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ嚗"):user,l11lll_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ嚘"):l11ll111111_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ嚙"):l1111l111111_l1_,l11lll_l1_ (u"ࠨ࡭ࡨࡽࠬ嚚"):l111l111l111_l1_,l11lll_l1_ (u"ࠩ࡬ࡨࠬ嚛"):l111l111l1ll_l1_,l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ嚜"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡵࡱ࡮ࡩࡳ࠭嚝")}
								response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ嚞"),l111ll111l11_l1_,data,l11lll_l1_ (u"࠭ࠧ嚟"),l11lll_l1_ (u"ࠧࠨ嚠"),l11lll_l1_ (u"ࠨࠩ嚡"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩ嚢"))
								html = response.content
								if html.startswith(l11lll_l1_ (u"ࠪࡘࡔࡑࡅࡏ࠿ࠪ嚣")):
									token = html.split(l11lll_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ嚤"),1)[1]
									break
								l11l1l111111_l1_ = l11l1ll11111_l1_
							else: time.sleep(1)
							l11l1ll11111_l1_ = time.time()-t1
						l11l1ll11l_l1_.close()
				if token:
					l11l11ll1lll_l1_ = response.cookies
					l1l1111l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬ࠿ࠬ嚥"),l1111lll1ll1_l1_,re.DOTALL)
					if l11lll_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭嚦") in list(l11l11ll1lll_l1_.keys()): l1l1111l11l1_l1_ = l11l11ll1lll_l1_[l11lll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ嚧")]
					elif l1l1111l11l1_l1_: l1l1111l11l1_l1_ = l1l1111l11l1_l1_[0]
					l11l1l11l111_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嚨"),l1111l111l1l_l1_,re.DOTALL)
					if l11l1l11l111_l1_: l11l11ll1l11_l1_,l111l111l111_l1_ = l11l1l11l111_l1_[0]
					if l1l1111l11l1_l1_ and l11l1l11l111_l1_:
						headers = {l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ嚩"):l11lll_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠫ嚪")+l1l1111l11l1_l1_,l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ嚫"):l1111l111111_l1_,l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ嚬"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ嚭")}
						data = l11lll_l1_ (u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠨ嚮")+token
						response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭嚯"),l11l11ll1l11_l1_,data,headers,False,l11lll_l1_ (u"ࠩࠪ嚰"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ嚱"))
						l1111l111l1l_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11111l1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ嚲"),str(cookies),re.DOTALL)
			if l11111l1l1l1_l1_:
				name,l11111l1l1l1_l1_ = l11111l1l1l1_l1_[0]
				l11l1l1l1_l1_ = name+l11lll_l1_ (u"ࠬࡃࠧ嚳")+l11111l1l1l1_l1_
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ嚴"),l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒࡥࡖࡆࡔࡌࡊࡎࡉࡁࡕࡋࡒࡒࠬ嚵"),l11l1l1l1_l1_,PERMANENT_CACHE)
				DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嚶"),l11lll_l1_ (u"ࠩࠪ嚷"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嚸"),l11lll_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡใะูࠥษๆศࠢศุ๊อๆࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอิา็้ࠢฮฬฬฬ้ࠡำหࠥอไโฯุࠤ้้๊ࠡ์ึฮำีๅ่ษ่ࠣฬำโศࠢ࠱࠲ࠥ๎ไศࠢอ์ัีࠠฮษฯอ๊ࠥลฺษาอࠥํะศࠢส่ๆำีࠡๆ฼ำฮࠦรี้ิࠤࡡࡴ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆไัฺࠦำ้ใࠣ๎ฯ้ัาࠢไ๎ࠥำวๅหࠣฮ฿๐ัࠡำห฻ࠥอไอ้สึࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฦูไหฦࠦัศ๊อีࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦแึๆࠣื้้ࠠศๆิหํะัࠡ࠰࠱ࠤศ๎ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡสิ์ู่๊ࠨ嚹"))
				if l11lll_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ嚺") not in l1111l111l1l_l1_:
					headers = {l11lll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭嚻"):l11l1l1l1_l1_}
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ嚼"),l1111l111111_l1_,l11lll_l1_ (u"ࠨࠩ嚽"),headers,l11lll_l1_ (u"ࠩࠪ嚾"),l11lll_l1_ (u"ࠪࠫ嚿"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫ囀"))
					l1111l111l1l_l1_ = response.content
	if not l1ll1ll1l_l1_ and not l11l1l1l1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭囁"),l11lll_l1_ (u"࠭ࠧ囂"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ囃"),l11lll_l1_ (u"ࠨ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠโึ็ฮࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨ囄"))
	return l1111l111l1l_l1_
def l111111_l1_(url,type,l11l111l_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ囅"),l11lll_l1_ (u"ࠪࠫ囆"),url,type)
	# http://l111l1ll1111_l1_.l11l1ll1l11l_l1_.io/link/136530
	l1lllll1_l1_,l1llll1ll1l_l1_ = [],[]
	#l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ囇"),l11lll_l1_ (u"ࠬ࠭囈"),True,l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍ࠮࠳ࡶࡸࠬ囉"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ囊"),url,l11lll_l1_ (u"ࠨࠩ囋"),l11lll_l1_ (u"ࠩࠪ囌"),l11lll_l1_ (u"ࠪࠫ囍"),l11lll_l1_ (u"ࠫࠬ囎"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ囏"))
	l11lll1l_l1_ = response.content
	l111l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࡁ࠵ࡡ࠿ࠩ囐"),l11lll1l_l1_,re.DOTALL)
	for block in l111l11_l1_:
		links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ囑"),block,re.DOTALL)
		for link,title in links:
			if link in l1lllll1_l1_: continue
			if l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ囒") not in link and l11lll_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭囓") not in link: continue
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫ囔"),l11lll_l1_ (u"ࠫࠬ囕")).replace(l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ囖"),l11lll_l1_ (u"࠭ࠧ囗")).strip(l11lll_l1_ (u"ࠧࠡࠩ囘")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ囙"),l11lll_l1_ (u"ࠩࠣࠫ囚"))
			l1lllll1_l1_.append(link)
			l1llll1ll1l_l1_.append(title)
	if len(l1lllll1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪฬ฾฼็ศࠢํัฯอฬࠡ࠸࠳ࠤะอๆ๋หࠪ四"),l1llll1ll1l_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ囜"),[],[]
	elif len(l1lllll1_l1_)==1: l1l_l1_ = 0
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭囝"),[],[]
	l1111l111111_l1_ = l1lllll1_l1_[l1l_l1_]
	l1111l111l1l_l1_ = l111llll11l1_l1_(l1111l111111_l1_)
	l1111_l1_,l1lll1ll_l1_ = [],[]
	if type==l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ回"):
		l111l1l1ll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ囟"),l1111l111l1l_l1_,re.DOTALL)
		if l111l1l1ll11_l1_:
			link = l111l_l1_(l111l1l1ll11_l1_[0])
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(l11l111l_l1_)
	elif type==l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ因"):
		links = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ囡"),l1111l111l1l_l1_,re.DOTALL)
		for link,size in links:
			if not link: continue
			if l11l111l_l1_ in size:
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
				break
		if not l1111_l1_:
			for link,size in links:
				if not link: continue
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ团"),l1111_l1_)
	if not l1111_l1_: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ団"),[],[]
	return l11lll_l1_ (u"ࠬ࠭囤"),l1lll1ll_l1_,l1111_l1_
def l1l111l_l1_(url,name):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ囥"),l11lll_l1_ (u"ࠧࠨ囦"),url,l11l1ll11l1l_l1_)
	# http://l11l1l11111_l1_.l111l11l1l1l_l1_.net/5cf68c23e6e79			?l11l1ll11l1l_l1_=			__11ll111ll1l_l1_
	# http://w.l11ll1l1_l1_.l1ll1ll11l1_l1_/5e14fd0a2806e			?l11l1ll11l1l_l1_=			ok.l111l1ll1lll_l1_
	#l11l1ll11l1l_l1_ = l11l1ll11l1l_l1_.replace(l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࡟ࡠࠩ囧"),l11lll_l1_ (u"ࠩࠪ囨")).split(l11lll_l1_ (u"ࠪࡣࡤ࠭囩"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ囪"),url,l11lll_l1_ (u"ࠬ࠭囫"),l11lll_l1_ (u"࠭ࠧ囬"),True,l11lll_l1_ (u"ࠧࠨ园"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧ囮"))
	html = response.content
	cookies = response.cookies
	if l11lll_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ囯") in list(cookies.keys()):
		l11l1l1l1_l1_ = cookies[l11lll_l1_ (u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪ困")]
		l11l1l1l1_l1_ = l111l_l1_(escapeUNICODE(l11l1l1l1_l1_))
		items = re.findall(l11lll_l1_ (u"ࠫࡷࡵࡵࡵࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ囱"),l11l1l1l1_l1_,re.DOTALL)
		l11l11l_l1_ = items[0].replace(l11lll_l1_ (u"ࠬࡢ࠯ࠨ囲"),l11lll_l1_ (u"࠭࠯ࠨ図"))
		l11l11l_l1_ = escapeUNICODE(l11l11l_l1_)
	else: l11l11l_l1_ = url
	if l11lll_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ围") in l11l11l_l1_:
		id = l11l11l_l1_.split(l11lll_l1_ (u"ࠨࠧ࠵ࡊࠬ囵"))[-1]
		l11l11l_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡥࡹࡩࡨ࠯࡫ࡶ࠳ࠬ囶")+id
		return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭囷"),[l11lll_l1_ (u"ࠫࠬ囸")],[l11l11l_l1_]
	else:
		l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ囹")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ固"),l1l1ll11_l1_,l11lll_l1_ (u"ࠧࠨ囻"),l11lll_l1_ (u"ࠨࠩ囼"),True,l11lll_l1_ (u"ࠩࠪ国"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠸࡮ࡥࠩ图"))
		l11l1ll111ll_l1_ = response.url
		#l11l1ll111ll_l1_ = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭囿")]
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭圀"),l11lll_l1_ (u"࠭ࠧ圁"),response.url,l1l1ll11_l1_)
		l111ll111ll1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠧ࠰ࠩ圂"))[2]#.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭圃"))
		l11ll11ll111_l1_ = l11l1ll111ll_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ圄"))[2]#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ圅"))
		l11l1l1_l1_ = l11l11l_l1_.replace(l111ll111ll1_l1_,l11ll11ll111_l1_)
		headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ圆"):l11lll_l1_ (u"ࠬ࠭圇") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ圈"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ圉") , l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ圊"):l11l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ國"), l11l1l1_l1_, l11lll_l1_ (u"ࠪࠫ圌"), headers, False,l11lll_l1_ (u"ࠫࠬ圍"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫ圎"))
		html = response.content
		#xbmc.log(str(l11l1l1_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭圏"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圐"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圑"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ園"),l11lll_l1_ (u"ࠪࠫ圓"),str(items),html)
		if items:
			link = items[0].replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ圔"),l11lll_l1_ (u"ࠬ࠵ࠧ圕"))
			link = link.rstrip(l11lll_l1_ (u"࠭࠯ࠨ圖"))
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ圗") not in link: link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ團") + link
			link = link.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ圙"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ圚"))
			if name==l11lll_l1_ (u"ࠫࠬ圛"): l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭圜"),[l11lll_l1_ (u"࠭ࠧ圝")],[link]
			else: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ圞"),[l11lll_l1_ (u"ࠨࠩ土")],[link]
		else: l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡏࡂࡏࠪ圠"),[],[]
		return l11ll11111ll_l1_,l1lll1ll_l1_,l1111_l1_
def l11l1l1111l1_l1_(url):
	# https://www.l11l1l1l111l_l1_.com/e/l1111l1lllll_l1_
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ圡") : l11lll_l1_ (u"ࠫࠬ圢") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭圣"),headers,l11lll_l1_ (u"࠭ࠧ圤"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ圥"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ圦"),l11lll_l1_ (u"ࠩࠪ圧"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ在"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠫࠬ圩")
	if items:
		for link,l1ll11l1l11l_l1_ in items:
			l1lll1ll_l1_.append(l1ll11l1l11l_l1_)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒࠫ圪"),[],[]
	return l11lll_l1_ (u"࠭ࠧ圫"),l1lll1ll_l1_,l1111_l1_
def l1111lll111l_l1_(url):
	# https://l111l11lllll_l1_.io/l1l111lll_l1_-l1111lll11ll_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ圬"),l11lll_l1_ (u"ࠨࠩ圭"))
	headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭圮"):l11lll_l1_ (u"ࠪࠫ圯")}
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ地"),headers,l11lll_l1_ (u"ࠬ࠭圱"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡕࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭圲"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ圳"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ圴"),l11lll_l1_ (u"ࠩࠪ圵"),url,items[0])
	if items:
		url = items[0]+l11lll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭圶")+url
		return l11lll_l1_ (u"ࠫࠬ圷"),[l11lll_l1_ (u"ࠬ࠭圸")],[url]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨ圹"),[],[]
def l111lll1ll1l_l1_(url):
	# https://l1111111ll11_l1_.to/l1l111lll_l1_/5c83f14297d62
	url = url.strip(l11lll_l1_ (u"ࠧ࠰ࠩ场"))
	if l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ圻") in url: id = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ圼"))[4]
	else: id = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ圽"))[-1]
	url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ圾") + id
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ圿") : l11lll_l1_ (u"࠭ࠧ址") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ坁"),headers,l11lll_l1_ (u"ࠨࠩ坂"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡃࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ坃"))
	html = html.replace(l11lll_l1_ (u"ࠪࡠࡡ࠭坄"),l11lll_l1_ (u"ࠫࠬ坅"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭坆"),l11lll_l1_ (u"࠭ࠧ均"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ坈"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠨࠩ坉"),[l11lll_l1_ (u"ࠩࠪ坊")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧ坋"),[],[]
def l111l1111l1l_l1_(url):
	# https://l11l1lll1ll1_l1_.net/l1l111lll_l1_-l11l11l1ll1l_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ坌"),l11lll_l1_ (u"ࠬ࠭坍"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ坎"),l11lll_l1_ (u"ࠧࠨ坏"),l11lll_l1_ (u"ࠨࠩ坐"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ坑"))
	items = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ坒"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for link,l1ll11l1l11l_l1_,res in items:
		l1lll1ll_l1_.append(l1ll11l1l11l_l1_+l11lll_l1_ (u"ࠫࠥ࠭坓")+res)
		l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ坔"),[],[]
	return l11lll_l1_ (u"࠭ࠧ坕"),l1lll1ll_l1_,l1111_l1_
def l11l1111ll11_l1_(url):
	# https://l11ll1111l11_l1_.l1ll1l1lll1_l1_/l1l111lll_l1_-l111l11l11ll_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ坖"),l11lll_l1_ (u"ࠨࠩ块"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ坘"),l11lll_l1_ (u"ࠪࠫ坙"),l11lll_l1_ (u"ࠫࠬ坚"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ坛"))
	items = re.findall(l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡂ࠯ࡵࡦࡁࠦ坜"),html,re.DOTALL)
	items = set(items)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for id,mode,hash,l1ll11l1l11l_l1_,res in items:
		url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳ࠳ࡻࡳ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ坝")+id+l11lll_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ坞")+mode+l11lll_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ坟")+hash
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ坠"),l11lll_l1_ (u"ࠫࠬ坡"),l11lll_l1_ (u"ࠬ࠭坢"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪ坣"))
		items = re.findall(l11lll_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭坤"),html,re.DOTALL)
		for link in items:
			l1lll1ll_l1_.append(l1ll11l1l11l_l1_+l11lll_l1_ (u"ࠨࠢࠪ坥")+res)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏࠨ坦"),[],[]
	return l11lll_l1_ (u"ࠪࠫ坧"),l1lll1ll_l1_,l1111_l1_
def l1111111ll1l_l1_(url):
	# https://l11111l1l11l_l1_.com:2053/l11111l1ll1l_l1_/l111l111lll1_l1_.l11l111ll11l_l1_.l11ll11l11ll_l1_.1080p.l11ll111l1ll_l1_.l11l1ll11l11_l1_.l111111lll11_l1_.l1111lll_l1_.html?l11l11111ll1_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l11l1lll1_l1_=1624070560
	# http://l1111l111lll_l1_.l1111llllll_l1_/l11l111l11ll_l1_/l11l111lll1l_l1_.l111ll1l1ll1_l1_.l11l11l1l11l_l1_.2018.1080p.l111ll111l1l_l1_-l111lll111l1_l1_.l1111l111l11_l1_.l1111lll_l1_.html
	link = l11lll_l1_ (u"ࠫࠬ坨")
	if 1 or l11lll_l1_ (u"ࠬࡑࡥࡺ࠿ࠪ坩") not in url:
		l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭ࡵࡱࡤࡲࡱ࠳ࡲࡩࡷࡧࠪ坪"),l11lll_l1_ (u"ࠧࡶࡲࡳࡳࡲ࠴࡬ࡪࡸࡨࠫ坫"))
		l11l11l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠨ࠱ࠪ坬"))
		id = l11l11l_l1_[3]
		l11l11l_l1_ = l11lll_l1_ (u"ࠩ࠲ࠫ坭").join(l11l11l_l1_[0:4])
		#headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ坮"):l1l11111l_l1_(),l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ坯"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ坰")}
		payload = {l11lll_l1_ (u"࠭ࡩࡥࠩ坱"):id,l11lll_l1_ (u"ࠧࡰࡲࠪ坲"):l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ坳"),l11lll_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧ坴"):l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪ坵")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ坶"),l11l11l_l1_,payload,l11lll_l1_ (u"ࠬ࠭坷"),l11lll_l1_ (u"࠭ࠧ坸"),l11lll_l1_ (u"ࠧࠨ坹"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠵ࡸࡺࠧ坺"))
		if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ坻") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ坼")]
		if not link and response.succeeded:
			html = response.content
			link = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坽"),html,re.DOTALL)
			if link: link = link[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ坾"),url,l11lll_l1_ (u"࠭ࠧ坿"),l11lll_l1_ (u"ࠧࠨ垀"),l11lll_l1_ (u"ࠨࠩ垁"),l11lll_l1_ (u"ࠩࠪ垂"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩ垃"))
		if l11lll_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭垄") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ垅")]
	if link: return l11lll_l1_ (u"࠭ࠧ垆"),[l11lll_l1_ (u"ࠧࠨ垇")],[link]
	return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡕࡈࡏࡎࠩ垈"),[],[]
def l111llll1l11_l1_(url):
	# https://www.l111ll11lll1_l1_.com/012ocyw9li6g.html
	headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭垉") : l11lll_l1_ (u"ࠪࠫ垊") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ型"),headers,l11lll_l1_ (u"ࠬ࠭垌"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ垍"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垎"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	if items:
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨ࡯ࡳ࠸ࠬ垏"))
		l1111_l1_.append(items[0][1])
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ垐"))
		l1111_l1_.append(items[0][0])
		return l11lll_l1_ (u"ࠪࠫ垑"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ垒"),[],[]
def l111llll11l_l1_(url):
	# l11l111ll111_l1_ l11l1l11llll_l1_			url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡜࠻࡜࠺࠱ࡗࡏࡻࡽࡖࡋࠧ垓")
	# l11111ll1lll_l1_ .l11ll111lll1_l1_ l11l1l11llll_l1_		url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡜ࡻࡳࡓࡏࡃࡼࡩࡾࡌࡉࠨ垔")
	# l11l111l1l11_l1_ l11l1l1lll_l1_ .l1llll1l1_l1_ l11l1l11llll_l1_		url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡌ࡬࠲࠮ࡐࡖࡸࡘࡹࡎࡸࠩ垕")
	# l111lllll1l1_l1_ l11l1l11llll_l1_			url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡫࡟ࡔ࠻࡙ࡺࡏࡓ࠱ࡑࡋࠪ垖")
	# l111l11lll_l1_ files have l111lll1lll1_l1_ l1l111l1lll1_l1_		url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃ࠱ࡸࡆࡕ࡙࡛ࡩࡓࡺࡡࡔࠫ垗")
	# url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ垘")
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾ࠸ࡵ࠯ࡤࡨ࠳ࡪࡊ࡬࡛࠷ࡹࡅࡓࡗࡕࡨࠩ垙")
	# url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡧࡰࡦࡪࡪ࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ垚")
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨ垛")
	# url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡵࡌࡅ࡭࡭࡬ࡣࡏ࠷࡙࡬ࠨࡤࡦࡤࡩࡨࡢࡰࡱࡩࡱࡃࡇࡰ࡮ࡧࡩࡳࡒࡩ࡯ࡧࡩࡳࡷ࡚ࡖࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡥࡳࡪࡄࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡄࡹࡹ࡯ࡦ࡬ࡧࡦࡺࡩࡰࡰࡀ࠶࠼࠽࠵࠸࠷ࠪ垜")
	# l1ll1llll_l1_ l1111ll1ll1l_l1_ details   https://l111l11l11l1_l1_.me/l11111l11l11_l1_/l111111l1l1l_l1_-l11111l111ll_l1_-l1111ll1l1l1_l1_
	id = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ垝"))[-1]
	id = id.split(l11lll_l1_ (u"ࠩࠩࠫ垞"))[0]
	id = id.replace(l11lll_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ垟"),l11lll_l1_ (u"ࠫࠬ垠"))
	#id = l11lll_l1_ (u"ࠬ࡫࡟ࡔ࠻࡙ࡺࡏࡓ࠱ࡑࡋࠪ垡")
	#url = l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ垢")+id
	#return l11lll_l1_ (u"ࠧࠨ垣"),[l11lll_l1_ (u"ࠨࠩ垤")],[url]
	l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ垥")][0]+l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭垦")+id
	l1111111llll_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࠧ垧")+id
	l111ll1ll111_l1_,l11111l1ll11_l1_,l11ll11l1l11_l1_,l11111llll1l_l1_ = l11lll_l1_ (u"ࠬ࠭垨"),l11lll_l1_ (u"࠭ࠧ垩"),l11lll_l1_ (u"ࠧࠨ垪"),l11lll_l1_ (u"ࠨࠩ垫")
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠩࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࡟ࠫ࠱࠭ࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶ࠭࠴ࠪࡀࠫࡧࡩ࡫ࡧࡵ࡭ࡶࡄࡹࡩ࡯࡯ࡕࡴࡤࡧࡰࡏ࡮ࡥࡧࡻࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠫ࠭ࠩࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡾࠦࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡉ࡯ࡥࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠ࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪࡡ࠱ࡡࠧࠨ࡟ࠍࠍࠎࠏࡦࡰࡴࠣࡰࡦࡴࡧ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯ࡥࡳ࡭ࠩࠋࠋࠌࠍࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ࠲ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࠬࠎࠎࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࡮ࡰࡶࠣ࡭ࡳ࡛ࠦ࠱࠮࠰࠵ࡢࡀࠊࠊࠋࠌࠍࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࠏࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏ࡟࠵ࡣࠫࠨࠨࡩࡱࡹࡃࡶࡵࡶࠩࡸࡾࡶࡥ࠾ࡶࡵࡥࡨࡱࠦࡵ࡮ࡤࡲ࡬ࡃࠧࠬ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࠴࠭ࠠࡪࡰࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠾ࠥࡪࡡࡴࡪࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡨࡦࡹࡨࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡷ࠴࠭ࠬࠨ࠱ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࠴࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡭ࡲࡳࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠦ࡬ࡹࡳ࡬࠳ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯࡬ࡱࡹࡕࡓࡎ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧࠪࠌࠌࠍࠨ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡝࠳ࡍࡆࡆࡌࡅ࠿࡛ࡒࡊ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖ࠰ࡌࡘࡏࡖࡒ࠰ࡍࡉࡃࠢࡷࡶࡷࠫ࠱࡮ࡴ࡮࡮࠵࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠠࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠥ࠮ࠫࠫ࡬࡭ࡵ࠿ࡹࡸࡹࠬࡴࡺࡲࡨࡁࡹࡸࡡࡤ࡭ࠩࡸࡱࡧ࡮ࡨ࠿ࠪࠎࠎࡨ࡬ࡰࡥ࡮ࡷ࠱ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠱࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲ࡻࡾࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡷࡵࡰࡤ࡫࡮ࡤࡱࡧࡩࡩࡥࡦ࡮ࡶࡢࡷࡹࡸࡥࡢ࡯ࡢࡱࡦࡶࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡦࡶࡴࡪࡸࡨࡣ࡫ࡳࡴࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡩࡧࠢࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪࡲࡺ࡟࡭࡫ࡶࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠢ࠿࡞ࠫࠬࡣ࠺ࠋࠋࠌࠍ࡫ࡳࡴࡠ࡮࡬ࡷࡹࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡬࡭ࡵࡡ࡬ࡸࡦ࡭ࡳࠡ࠿ࠣࡪࡲࡺ࡟࡭࡫ࡶࡸ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠲ࠧࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣࡪࡲࡺ࡟ࡪࡶࡤ࡫ࡸࡀࠊࠊࠋࠌࠍ࡮ࡺࡡࡨ࠮ࡶ࡭ࡿ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬࠎࠎࠏࠉࠊࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࡜࡫ࡷࡥ࡬ࡣࠠ࠾ࠢࡶ࡭ࡿ࡫ࠊࠊࡨࡲࡶࠥࡨ࡬ࡰࡥ࡮ࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡦࡱࡵࡣ࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉ࡭࡫ࡱࡩࡸࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠭ࠩࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴࡥࠡ࡫ࡱࠤࡱ࡯࡮ࡦࡵ࠽ࠎࠎࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࠫࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠬ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋࠌࠍࠨࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨ࡭࡫ࡱࡩ࠱ࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࠊࠋ࡯࡭ࡳ࡫ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡰ࡮ࡴࡥࠪࠌࠌࠍࠎࡪࡩࡤࡶࠣࡁࠥࢁࡽࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡲࡩ࡯ࡧ࠱ࡷࡵࡲࡩࡵࠪࠪࠪࠫ࠭ࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏ࡫ࡦࡻ࠯ࡺࡦࡲࡵࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩࡀࠫ࠱࠷ࠩࠋࠋࠌࠍࠎࡪࡩࡤࡶ࡞࡯ࡪࡿ࡝ࠡ࠿ࠣࡺࡦࡲࡵࡦࠌࠌࠍࠎ࡯ࡦࠡࠩࡶ࡭ࡿ࡫ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭ࠥࡧ࡮ࡥࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠎࠎࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡽࡩࠬࡣࠠ࠾ࠢࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࡝ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝࡞ࠌࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶࠬࠎࠎࡨ࡬ࡰࡥ࡮ࡷ࠱ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶ࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡦࡰࡴࡰࡥࡹࡹࠢ࠻࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠢ࠻࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࠪࠫ࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡀࠦࠬ࠲ࠧ࠾ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠢࠣࠩ࠯ࠫࠧ࠭ࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡀࡴࡳࡷࡨࠫ࠱࠭࠺ࡕࡴࡸࡩࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠽ࡪࡦࡲࡳࡦࠩ࠯ࠫ࠿ࡌࡡ࡭ࡵࡨࠫ࠮ࠐࠉࠊ࡫ࡩࠤࠬࡡࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡤ࡯ࡳࡨࡱࠠ࠾ࠢࠪ࡟ࠬ࠱ࡢ࡭ࡱࡦ࡯࠰࠭࡝ࠨࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡦࡱࡵࡣ࡬ࠫࠍࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺࠠࡪࡰࠣࡦࡱࡵࡣ࡬࠼ࠍࠍࠎࠏࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠬࠎࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡴࡺࡲࡨࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠽ࠨ࠮ࠪࡁࠧ࠭ࠩࠬࠩࠥࠫࠏࠏࠉࠊ࡫ࡩࠤࠬ࡬ࡰࡴࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡪࡵࡹࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡧࡲࡶࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡻ࡮ࡪࡴࡩࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡷ࡮ࢀࡥࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡹ࡬ࡨࡹ࡮ࠧ࡞ࠫ࠮ࠫࡽ࠭ࠫࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪ࡬ࡪ࡯ࡧࡩࡶࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡷࡹࡧࡲࡵࠩࡠ࠯ࠬ࠳ࠧࠬࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡥ࡯ࡦࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࡠ࡟ࠬࡹࡴࡢࡴࡷࠫࡢ࠱ࠧ࠮ࠩ࠮ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡨࡲࡩ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭ࠥࡧ࡮ࡥࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࡂ࠶࠷࠱࠳࠴࠵࠷࠸࠹࠺ࠡࡦࡨࡰࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠎࠎࠏࠉࠊࡥ࡬ࡴ࡭࡫ࡲࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠦࠨࠫࠍࠍࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥࡩࡩࡱࡪࡨࡶ࠿ࠐࠉࠊࠋࠌࠍࡰ࡫ࡹ࠭ࡸࡤࡰࡺ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠾ࠩ࠯࠵࠮ࠐࠉࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝࡮ࡩࡾࡣࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡺࡦࡲࡵࡦࠫࠍࠍࠎࠏࠣࡪࡨࠣࠫࡺࡸ࡬ࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡸࡶࡱ࠭࡝ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࡝ࠪࡹࡷࡲࠧ࡞ࠫࠍࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠭ࠏࠏࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠲࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠵࠱ࡹࡴࡳࡧࡤࡱࡸ࠸ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠊࠊ࡫ࡩࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴ࠤࡦࡴࡤࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠻ࠌࠌࠍ࡫ࡵࡲࠡࡦ࡬ࡧࡹ࠷ࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠽ࠎࠎࠏࠉࡶࡴ࡯࠵ࠥࡃࠠࡥ࡫ࡦࡸ࠶ࡡࠧࡶࡴ࡯ࠫࡢࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠥࡸࡶࡱ࠷ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇ࡙ࠫࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࠳࡞ࠫࡺࡸ࡬ࠨ࡟ࠬ࠭ࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵ࠴ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࡀࠊࠊࠋࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡩ࡯ࡣࡵ࠴࡞ࠫࡺࡸ࡬ࠨ࡟࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎࠏࠣࡶࡴ࡯࠶ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࠲࡜ࠩࡸࡶࡱ࠭࡝ࠪࠫ࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎࠏࡩࡧࠢࡸࡶࡱ࠷࠽࠾ࡷࡵࡰ࠷ࠦࡡ࡯ࡦࠣࡹࡷࡲ࠱ࠡࡰࡲࡸࠥ࡯࡮ࠡࡷࡵࡰࡤࡲࡩࡴࡶ࠽ࠎࠎࠏࠉࠊࠋࡸࡶࡱࡥ࡬ࡪࡵࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡺࡸ࡬࠲ࠫࠍࠍࠎࠏࠉࠊࡦ࡬ࡧࡹ࠷࠮ࡶࡲࡧࡥࡹ࡫ࠨࡥ࡫ࡦࡸ࠷࠯ࠊࠊࠋࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸ࠶࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠶࠯ࠊࠊࡧ࡯ࡷࡪࡀࠠࡴࡶࡵࡩࡦࡳࡳ࠱ࠢࡀࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠯ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵ࠎࠎࠨࠢࠣ垬")
	# l1111l1111ll_l1_ json data
	# l1l111lll_l1_ url l11l1l11llll_l1_:    https://www.l1ll1llll_l1_.com/l1l111lll_l1_/l11l11l11lll_l1_
	# list of l11l1l1l1111_l1_ & l1l111ll1l11_l1_
	# https://github.com/l1111ll1l11l_l1_-l111ll11l11l_l1_/l1111ll1l11l_l1_-l111ll11l11l_l1_/blob/master/l11l1l1111ll_l1_/l111ll1l1111_l1_/l1ll1llll_l1_.py
	# all the below l111l11111ll_l1_ were l111llll11ll_l1_ using:	https://www.l1ll1llll_l1_.com/l11l1ll1ll1l_l1_/l1l1l1llll11_l1_/l11ll1111ll_l1_?l111111l1l11_l1_=l11111ll1111_l1_	&	l11l11lll11l_l1_ = l11l11l11lll_l1_
	# 3 l1ll111l111l_l1_:	13KB:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ垭"): l11lll_l1_ (u"ࠫࡎࡕࡓࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ垮"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ垯"): l11lll_l1_ (u"࠭࠲࠳࠰࠶࠷࠳࠷࠰࠲ࠩ垰")
	# 7 l1ll111l111l_l1_		44KB:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ垱"): l11lll_l1_ (u"ࠨࡋࡒࡗࡤࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡆ࡚ࡗࡉࡓ࡙ࡉࡐࡐࠪ垲"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ垳"): l11lll_l1_ (u"ࠪ࠵࠼࠴࠳࠴࠰࠵ࠫ垴")
	# 7 l1ll111l111l_l1_		58KB:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ垵"): l11lll_l1_ (u"ࠬࡏࡏࡔࠩ垶"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭垷"): l11lll_l1_ (u"ࠧ࠲࠹࠱࠷࠸࠴࠲ࠨ垸")
	# 9 l1ll111l111l_l1_		24KB:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ垹"): l11lll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡇࡗࡋࡁࡕࡑࡕࠫ垺"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ垻"): l11lll_l1_ (u"ࠫ࠷࠸࠮࠴࠲࠱࠵࠵࠶ࠧ垼")
	# no json file:		21 l1ll111l111l_l1_	95KB:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ垽"): l11lll_l1_ (u"࠭ࡗࡆࡄࡢࡇࡗࡋࡁࡕࡑࡕࠫ垾"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ垿"): l11lll_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠵࠺࠳࠶࠰࠯࠲࠳ࠫ埀")
	# no json file:		21 l1ll111l111l_l1_	121KB:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭埁"): l11lll_l1_ (u"࡛ࠪࡊࡈࠧ埂"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ埃"): l11lll_l1_ (u"ࠬ࠸࠮࠳࠲࠵࠶࠵࠾࠰࠲࠰࠳࠴࠳࠶࠰ࠨ埄")
	# no json file: 	26 l1ll111l111l_l1_	115KB:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ埅"): l11lll_l1_ (u"ࠧࡎ࡙ࡈࡆࠬ埆"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ埇"): l11lll_l1_ (u"ࠩ࠵࠲࠷࠶࠲࠳࠲࠻࠴࠶࠴࠰࠱࠰࠳࠴ࠬ埈")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ埉"): l11lll_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࠬ埊"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ埋"): l11lll_l1_ (u"࠭࠱࠸࠰࠶࠵࠳࠹࠵ࠨ埌")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ埍"): l11lll_l1_ (u"ࠨ࡙ࡈࡆࡤࡘࡅࡎࡋ࡛ࠫ城"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ埏"): l11lll_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠷࠽࠮࠱࠳࠱࠴࠵࠭埐")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ埑"): l11lll_l1_ (u"ࠬ࡝ࡅࡃࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ埒"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭埓"): l11lll_l1_ (u"ࠧ࠲࠰࠵࠴࠷࠸࠰࠸࠵࠴࠲࠵࠶࠮࠱࠲ࠪ埔")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ埕"): l11lll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡉࡒࡈࡅࡅࡆࡈࡈࡤࡖࡌࡂ࡛ࡈࡖࠬ埖"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ埗"): l11lll_l1_ (u"ࠫ࠶࠽࠮࠴࠳࠱࠷࠺࠭埘")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ埙"): l11lll_l1_ (u"࠭ࡁࡏࡆࡕࡓࡎࡊ࡟ࡎࡗࡖࡍࡈ࠭埚"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ埛"): l11lll_l1_ (u"ࠨ࠷࠱࠵࠻࠴࠵࠲ࠩ埜")
	# l11lll111l11_l1_:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭埝"): l11lll_l1_ (u"ࠪࡘ࡛ࡎࡔࡎࡎ࠸ࡣࡘࡏࡍࡑࡎ࡜ࡣࡊࡓࡂࡆࡆࡇࡉࡉࡥࡐࡍࡃ࡜ࡉࡗ࠭埞"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ域"): l11lll_l1_ (u"ࠬ࠸࠮࠱ࠩ埠")
	# l11lll111l11_l1_:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ埡"): l11lll_l1_ (u"ࠧࡊࡑࡖࡣࡒ࡛ࡓࡊࡅࠪ埢"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ埣"): l11lll_l1_ (u"ࠩ࠸࠲࠷࠷ࠧ埤")
	# l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ埥")][0]+l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡴࡱࡧࡹࡦࡴࡂࡴࡷ࡫ࡴࡵࡻࡓࡶ࡮ࡴࡴ࠾ࡶࡵࡹࡪ࠭埦")  # l11111ll1111_l1_ l1ll1l1l1lll_l1_ l11111l1llll_l1_ and l1111ll1llll_l1_ l1ll11l1ll1l_l1_ l1l1l1llll_l1_ l1111l1l1ll1_l1_ file size
	#l11ll1l11_l1_ = l11lll_l1_ (u"ࠬࢁࠧ埧")l111111l11ll_l1_ (u"࠭࠺ࡪࡦ࠯ࠫ埨")l111ll111lll_l1_ (u"ࠧ࠻ࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࢀࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠧࡇࡎࡅࡔࡒࡍࡉࠨࠬࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠥ࠵࠼࠴࠳࠲࠰࠶࠹ࠧࢃࡽࡾࠩ埩")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭埪"),l11l11l_l1_,l11ll1l11_l1_,l11lll_l1_ (u"ࠩࠪ埫"),l11lll_l1_ (u"ࠪࠫ埬"),l11lll_l1_ (u"ࠫࠬ埭"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭埮"))
	#html = response.content
	for l11ll111l1_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭วๅ็ะหํ๊ษࠡำๅ้࠿ࠦࠠࠨ埯")+str(l11ll111l1_l1_+1),l11lll_l1_ (u"ࠧࠨ埰"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ埱"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ埲"),l11lll_l1_ (u"ࠪࠫ埳"),l11lll_l1_ (u"ࠫࠬ埴"),l11lll_l1_ (u"ࠬ࠭埵"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ埶"))
		html = response.content
		if l11lll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ執") in html: break
		time.sleep(2)
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ埸"),html)
	l11lll1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡒ࡯ࡥࡾ࡫ࡲࡓࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭培"),html,re.DOTALL)
	if l11lll1l11_l1_: l11lll1l11_l1_ = l11lll1l11_l1_[0]
	else: l11lll1l11_l1_ = html
	l11lll1l11_l1_ = l11lll1l11_l1_.replace(l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ基"),l11lll_l1_ (u"ࠫࠫ࠭埻"))
	l1111ll11ll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ埼"),l11lll1l11_l1_)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ埽"),str(l1111ll11ll1_l1_))
	# l1111l1111ll_l1_ l11l11l1l1ll_l1_ & l11ll111l11l_l1_
	# l1ll1llll_l1_ l11l111ll111_l1_ link l11llll1l_l1_ l11lll_l1_ (u"ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠩ埾") to l111l1l1l1_l1_ on l1111ll111l_l1_
	l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ埿")],[l11lll_l1_ (u"ࠩࠪ堀")]
	try:
		l11l11l1l1ll_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ堁")][l11lll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ堂")][l11lll_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ堃")]
		for l111llllll11_l1_ in l11l11l1l1ll_l1_:
			link = l111llllll11_l1_[l11lll_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ堄")]
			try: title = l111llllll11_l1_[l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ堅")][l11lll_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ堆")]
			except: title = l111llllll11_l1_[l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ堇")][l11lll_l1_ (u"ࠪࡶࡺࡴࡳࠨ堈")][0][l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ堉")]
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(title)
	except: pass
	if len(l1lll1ll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ堊"), l1lll1ll_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ堋"),[],[]
		elif l1l_l1_!=0:
			link = l1111_l1_[l1l_l1_]+l11lll_l1_ (u"ࠧࠧࠩ堌")
			l111l11ll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭堍"),link)
			if l111l11ll1ll_l1_: link = link.replace(l111l11ll1ll_l1_[0],l11lll_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ堎"))
			else: link = link+l11lll_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ堏")
			l111ll1ll111_l1_ = link.strip(l11lll_l1_ (u"ࠫࠫ࠭堐"))
	formats,l11ll1111lll_l1_,l11l1l111l1l_l1_,l11l1l111ll1_l1_,l11l1l111l11_l1_ = [],[],[],[],[]
	# l1111l1111ll_l1_ l111ll1lllll_l1_ l1ll111l111l_l1_
	try: l11111l1ll11_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ堑")][l11lll_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ堒")]
	except: pass
	# l1111l1111ll_l1_ l11l111l1l11_l1_ stream
	try: l11ll11l1l11_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ堓")][l11lll_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ堔")]
	except: pass
	# l1111l1111ll_l1_ l1ll1l1l1l_l1_ l1111lll_l1_ l1ll111l111l_l1_
	try: formats = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ堕")][l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ堖")]
	except: pass
	# l1111l1111ll_l1_ l1ll1l1l1l_l1_ l11ll111lll1_l1_ l1ll111l111l_l1_
	try: l11ll1111lll_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ堗")][l11lll_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ堘")]
	except: pass
	l11l111l1111_l1_ = formats+l11ll1111lll_l1_
	for dict in l11l111l1111_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ堙"),str(dict))
		if l11lll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ堚") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭堛")] = str(dict[l11lll_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ堜")])
		if l11lll_l1_ (u"ࠪࡪࡵࡹࠧ堝") in list(dict.keys()): dict[l11lll_l1_ (u"ࠫ࡫ࡶࡳࠨ堞")] = str(dict[l11lll_l1_ (u"ࠬ࡬ࡰࡴࠩ堟")])
		if l11lll_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ堠") in list(dict.keys()): dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩࠬ堡")] = dict[l11lll_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ堢")]		#.replace(l11lll_l1_ (u"ࠩࡀࠫ堣"),l11lll_l1_ (u"ࠪࡁࠬ堤"))+l11lll_l1_ (u"ࠫࠧ࠭堥")
		if l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ堦") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ堧")] = str(dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ堨")])
		if l11lll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ堩") in list(dict.keys()): dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ堪")] = str(dict[l11lll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ堫")])
		if l11lll_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ堬") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬࡹࡩࡻࡧࠪ堭")] = str(dict[l11lll_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ堮")])+l11lll_l1_ (u"ࠧࡹࠩ堯")+str(dict[l11lll_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ堰")])
		if l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ報") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ堲")] = dict[l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ堳")][l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ場")]+l11lll_l1_ (u"࠭࠭ࠨ堵")+dict[l11lll_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ堶")][l11lll_l1_ (u"ࠨࡧࡱࡨࠬ堷")]
		if l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭堸") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ堹")] = dict[l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ堺")][l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ堻")]+l11lll_l1_ (u"࠭࠭ࠨ堼")+dict[l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ堽")][l11lll_l1_ (u"ࠨࡧࡱࡨࠬ堾")]
		if l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ堿") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ塀")] = dict[l11lll_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬ塁")]
		if l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭塂") in list(dict.keys()) and int(dict[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ塃")])>111222333: del dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ塄")]
		if l11lll_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ塅") in list(dict.keys()):
			cipher = dict[l11lll_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ塆")].split(l11lll_l1_ (u"ࠪࠪࠬ塇"))
			for item in cipher:
				key,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭塈"),1)
				dict[key] = l111l_l1_(value)
		if l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ塉") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ塊")] = l111l_l1_(dict[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ塋")])
		#if l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳ࠾ࠩ塌") in dict[l11lll_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ塍")]: dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ塎")] = dict[l11lll_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭塏")].split(l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࡂࡢࠢࠨ塐"))[1].strip(l11lll_l1_ (u"࠭࡜ࠣࠩ塑"))
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ塒"),dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭塓")]+l11lll_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢࠪ塔")+dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥࠨ塕")])
		l11l1l111l1l_l1_.append(dict)
	l11l1lll1_l1_ = l11lll_l1_ (u"ࠫࠬ塖")
	if l11lll_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ塗") in l11lll1l11_l1_:
		#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡹࡵࡵ࠲࡮ࡸࡨࡩ࡯࠱ࡳࡰࡦࡿࡥࡳࡡ࠱࠮ࡄ࠯ࠢࠨ塘"),html,re.DOTALL)
		# l11l1l11llll_l1_:	/s/l11ll1111ll_l1_/6dde7fb4/l1111l1l1l11_l1_.l111ll11111l_l1_/l111lll111ll_l1_/base.l1111l1l1111_l1_
		#l1111l1ll1l1_l1_ = [l11lll_l1_ (u"ࠧ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡨ࠽࠽ࡤ࠶࠺࠴ࡪ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࡯ࡡࡴ࠰ࡹࡪࡱࡹࡥࡵ࠱ࡨࡲࡤ࡛ࡓ࠰ࡤࡤࡷࡪ࠴ࡪࡴࠩ塙")]
		l1111l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡠࡼ࠰࠿࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠ࠰࠱࠳ࡧࡧࡳࡦ࠰࡭ࡷ࠮ࠨࠧ塚"),html,re.DOTALL)
		if l1111l1ll1l1_l1_:
			l1111l1ll1l1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ塛")][0]+l1111l1ll1l1_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ塜"),l1111l1ll1l1_l1_,l11lll_l1_ (u"ࠫࠬ塝"),l11lll_l1_ (u"ࠬ࠭塞"),l11lll_l1_ (u"࠭ࠧ塟"),l11lll_l1_ (u"ࠧࠨ塠"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩ塡"))
			l11l1lll1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1111l11l111_l1_ = cipher._load_javascript(l11l1lll1_l1_)
			l11111l1l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭塢"),str(l1111l11l111_l1_))
			l1111llllll1_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11111l1l1ll_l1_)
	for dict in l11l1l111l1l_l1_:
		url = dict[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ塣")]
		if l11lll_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨ塤") in url or url.count(l11lll_l1_ (u"ࠬࡹࡩࡨ࠿ࠪ塥"))>1:
			l11l1l111ll1_l1_.append(dict)
		elif l11l1lll1_l1_ and l11lll_l1_ (u"࠭ࡳࠨ塦") in list(dict.keys()) and l11lll_l1_ (u"ࠧࡴࡲࠪ塧") in list(dict.keys()):
			l111lllll1l1_l1_ = l1111llllll1_l1_.execute(dict[l11lll_l1_ (u"ࠨࡵࠪ塨")])
			if l111lllll1l1_l1_!=dict[l11lll_l1_ (u"ࠩࡶࠫ塩")]:
				dict[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ塪")] = url+l11lll_l1_ (u"ࠫࠫ࠭填")+dict[l11lll_l1_ (u"ࠬࡹࡰࠨ塬")]+l11lll_l1_ (u"࠭࠽ࠨ塭")+l111lllll1l1_l1_
				l11l1l111ll1_l1_.append(dict)
	for dict in l11l1l111ll1_l1_:
		l1l1111_l1_,l1111ll11lll_l1_,l1111ll1l1ll_l1_,l11ll1ll1_l1_,codecs,l111l1lllll_l1_ = l11lll_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ塮"),l11lll_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ塯"),l11lll_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ塰"),l11lll_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ塱"),l11lll_l1_ (u"ࠫࠬ塲"),l11lll_l1_ (u"ࠬ࠶ࠧ塳")
		try:
			l11l1l111lll_l1_ = dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ塴")]
			l11l1l111lll_l1_ = l11l1l111lll_l1_.replace(l11lll_l1_ (u"ࠧࠬࠩ塵"),l11lll_l1_ (u"ࠨࠩ塶"))
			items = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ塷"),l11l1l111lll_l1_,re.DOTALL)
			l11ll1ll1_l1_,l1l1111_l1_,codecs = items[0]
			l11l1llllll1_l1_ = codecs.split(l11lll_l1_ (u"ࠪ࠰ࠬ塸"))
			l1111ll11lll_l1_ = l11lll_l1_ (u"ࠫࠬ塹")
			for item in l11l1llllll1_l1_: l1111ll11lll_l1_ += item.split(l11lll_l1_ (u"ࠬ࠴ࠧ塺"))[0]+l11lll_l1_ (u"࠭ࠬࠨ塻")
			l1111ll11lll_l1_ = l1111ll11lll_l1_.strip(l11lll_l1_ (u"ࠧ࠭ࠩ塼"))
			if l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ塽") in list(dict.keys()): l111l1lllll_l1_ = str(float(dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ塾")]*10)//1024/10)+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ塿")
			else: l111l1lllll_l1_ = l11lll_l1_ (u"ࠫࠬ墀")
			if l11ll1ll1_l1_==l11lll_l1_ (u"ࠬࡺࡥࡹࡶࠪ墁"): continue
			elif l11lll_l1_ (u"࠭ࠬࠨ墂") in l11l1l111lll_l1_:
				l11ll1ll1_l1_ = l11lll_l1_ (u"ࠧࡂ࡙࠭ࠫ境")
				l1111ll1l1ll_l1_ = l1l1111_l1_+l11lll_l1_ (u"ࠨࠢࠣࠫ墄")+l111l1lllll_l1_+dict[l11lll_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ墅")].split(l11lll_l1_ (u"ࠪࡼࠬ墆"))[1]
			elif l11ll1ll1_l1_==l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ墇"):
				l11ll1ll1_l1_ = l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ墈")
				l1111ll1l1ll_l1_ = l111l1lllll_l1_+dict[l11lll_l1_ (u"࠭ࡳࡪࡼࡨࠫ墉")].split(l11lll_l1_ (u"ࠧࡹࠩ墊"))[1]+l11lll_l1_ (u"ࠨࠢࠣࠫ墋")+dict[l11lll_l1_ (u"ࠩࡩࡴࡸ࠭墌")]+l11lll_l1_ (u"ࠪࡪࡵࡹࠧ墍")+l11lll_l1_ (u"ࠫࠥࠦࠧ墎")+l1l1111_l1_
			elif l11ll1ll1_l1_==l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ墏"):
				l11ll1ll1_l1_ = l11lll_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ墐")
				l1111ll1l1ll_l1_ = l111l1lllll_l1_+str(int(dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫ墑")])/1000)+l11lll_l1_ (u"ࠨ࡭࡫ࡾࠥࠦࠧ墒")+dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ墓")]+l11lll_l1_ (u"ࠪࡧ࡭࠭墔")+l11lll_l1_ (u"ࠫࠥࠦࠧ墕")+l1l1111_l1_
		except:
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		if l11lll_l1_ (u"ࠬࡪࡵࡳ࠿ࠪ墖") in dict[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ増")]: l1l1l1111_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ墘")].split(l11lll_l1_ (u"ࠨࡦࡸࡶࡂ࠭墙"),1)[1].split(l11lll_l1_ (u"ࠩࠩࠫ墚"),1)[0]))
		elif l11lll_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭墛") in list(dict.keys()): l1l1l1111_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧ墜")])/1000)
		else: l1l1l1111_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ墝")
		if l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ增") not in list(dict.keys()): l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ墟")].split(l11lll_l1_ (u"ࠨࡺࠪ墠"))[1]
		else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ墡")]
		if l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ墢") not in list(dict.keys()): dict[l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ墣")] = l11lll_l1_ (u"ࠬ࠶࠭࠱ࠩ墤")
		dict[l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ墥")] = l11ll1ll1_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ墦")+l1111ll1l1ll_l1_+l11lll_l1_ (u"ࠨࠢࠣࠬࠬ墧")+l1111ll11lll_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ墨")+dict[l11lll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ墩")]+l11lll_l1_ (u"ࠫ࠮࠭墪")
		dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭墫")] = l1111ll1l1ll_l1_.split(l11lll_l1_ (u"࠭ࠠࠡࠩ墬"))[0].split(l11lll_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ墭"))[0]
		dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ墮")] = l11ll1ll1_l1_
		dict[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ墯")] = l1l1111_l1_
		dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ墰")] = codecs
		dict[l11lll_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭墱")] = l1l1l1111_l1_
		dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭墲")] = l111l1lllll_l1_
		l11l1l111l11_l1_.append(dict)
	l11l1111ll1l_l1_,l11l1ll1111l_l1_,l11ll111llll_l1_,l111ll11l111_l1_,l11l11ll11l1_l1_ = [],[],[],[],[]
	l111l1ll1ll1_l1_,l11l1l11ll1l_l1_,l111l1l111l1_l1_,l11l1lllll11_l1_,l11ll111l1l1_l1_ = [],[],[],[],[]
	if l11111l1ll11_l1_:
		dict = {}
		dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ墳")] = l11lll_l1_ (u"ࠧࡂ࡙࠭ࠫ墴")
		dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ墵")] = l11lll_l1_ (u"ࠩࡰࡴࡩ࠭墶")
		dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ墷")] = dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ墸")]+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ墹")+dict[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ墺")]+l11lll_l1_ (u"ࠧࠡࠢࠪ墻")+l11lll_l1_ (u"ࠨฮ๋ำฮࠦะไ์ฬࠫ墼")
		dict[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭墽")] = l11111l1ll11_l1_
		dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ墾")] = l11lll_l1_ (u"ࠫ࠵࠭墿") # for l11l1l1l11_l1_ l11111l1ll11_l1_ any l1l11l11l_l1_ will l11l11lll111_l1_ l1lll1lll1l_l1_ sort l1l11l1l1ll_l1_
		dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭壀")] = l11lll_l1_ (u"࠭࠹࠹࠹࠹࠹࠹࠹࠲࠲࠲ࠪ壁") # 20
		l11l1l111l11_l1_.append(dict)
	if l11ll11l1l11_l1_:
		l11l11ll11ll_l1_,l11l1l1ll11l_l1_ = l11ll11lll_l1_(l11ll11l1l11_l1_)
		l11l1ll1lll1_l1_ = list(zip(l11l11ll11ll_l1_,l11l1l1ll11l_l1_))
		for title,link in l11l1ll1lll1_l1_:
			dict = {}
			dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭壂")] = l11lll_l1_ (u"ࠨࡃ࠮࡚ࠬ壃")
			dict[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ壄")] = l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ壅")
			dict[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ壆")] = link
			#if l11lll_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ壇") in title: dict[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ壈")] = title.split(l11lll_l1_ (u"ࠧࠡࠢࠪ壉"))[1].split(l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭壊"))[0]
			#if l11lll_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ壋") in title: dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ壌")] = title.split(l11lll_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ壍"))[1]
			# title = l11lll_l1_ (u"ࠧ࠺࠲࠷࠹࡮ࡦࡵࡹࠠࠡ࠹࠵࠴ࠥࠦ࠮࡮࠵ࡸ࠼ࠧ壎")
			if l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠫ壏") in title: dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ壐")] = title.split(l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭壑"))[0].rsplit(l11lll_l1_ (u"ࠩࠣࠤࠬ壒"))[-1]
			else: dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ壓")] = l11lll_l1_ (u"ࠫ࠶࠶ࠧ壔")
			if title.count(l11lll_l1_ (u"ࠬࠦࠠࠨ壕"))>1:
				l11l111l_l1_ = title.rsplit(l11lll_l1_ (u"࠭ࠠࠡࠩ壖"))[-3]
				if l11l111l_l1_.isdigit(): dict[l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ壗")] = l11l111l_l1_
				else: dict[l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ壘")] = l11lll_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ壙")
			#dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ壚")] = title
			if title==l11lll_l1_ (u"ࠫ࠲࠷ࠧ壛"): dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ壜")] = dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ壝")]+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ壞")+dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ壟")]+l11lll_l1_ (u"ࠩࠣࠤࠬ壠")+l11lll_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭壡")
			else: dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ壢")] = dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ壣")]+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ壤")+dict[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ壥")]+l11lll_l1_ (u"ࠨࠢࠣࠫ壦")+dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ壧")]+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ壨")+dict[l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ壩")]
			l11l1l111l11_l1_.append(dict)
	l11l1l111l11_l1_ = sorted(l11l1l111l11_l1_,reverse=True,key=lambda key: float(key[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭壪")]))
	if not l11l1l111l11_l1_:
		l1l1ll1111l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ士"),html,re.DOTALL)
		l1l1ll111l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻࡞ࡾࠦࡷࡻ࡮ࡴࠤ࠽ࡠࡠࡢࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ壬"),html,re.DOTALL)
		l11l1111l111_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ壭"),html,re.DOTALL)
		l11l1111l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ壮"),html,re.DOTALL)
		try: l11l1111l1l1_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ壯")][l11lll_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ声")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭壱")][l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ売")][l11lll_l1_ (u"ࠧࡳࡷࡱࡷࠬ壳")][0][l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭壴")]
		except: l11l1111l1l1_l1_ = l11lll_l1_ (u"ࠩࠪ壵")
		try: l11l1111l1ll_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ壶")][l11lll_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ壷")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭壸")][l11lll_l1_ (u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ壹")][0][l11lll_l1_ (u"ࠧࡳࡷࡱࡷࠬ壺")][0][l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭壻")]
		except: l11l1111l1ll_l1_ = l11lll_l1_ (u"ࠩࠪ壼")
		try: l1111lllll1l_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ壽")][l11lll_l1_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ壾")]
		except: l1111lllll1l_l1_ = l11lll_l1_ (u"ࠬ࠭壿")
		if l1l1ll1111l_l1_ or l1l1ll111l1_l1_ or l11l1111l111_l1_ or l11l1111l11l_l1_ or l11l1111l1l1_l1_ or l11l1111l1ll_l1_ or l1111lllll1l_l1_:
			if   l1l1ll1111l_l1_: message = l1l1ll1111l_l1_[0]
			elif l1l1ll111l1_l1_: message = l1l1ll111l1_l1_[0]
			elif l11l1111l111_l1_: message = l11l1111l111_l1_[0]
			elif l11l1111l11l_l1_: message = l11l1111l11l_l1_[0]
			elif l11l1111l1l1_l1_: message = l11l1111l1l1_l1_
			elif l11l1111l1ll_l1_: message = l11l1111l1ll_l1_
			elif l1111lllll1l_l1_: message = l1111lllll1l_l1_
			l111l11l1lll_l1_ = message.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ夀"),l11lll_l1_ (u"ࠧࠨ夁")).strip(l11lll_l1_ (u"ࠨࠢࠪ夂"))
			l11l11l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦๅีๅ็อࠥ๎โะࠢํ็ํ์ࠠ฻์ิࠤ๊๊วว็่ࠣอ฿ึࠡษ็ุ้ะฮะ็ํ๊ࠥษ่ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ夃")
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ处"),l11lll_l1_ (u"ࠫࠬ夅"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿้ࠠษ็้อืๅอࠩ夆"),l11l11l11ll1_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ备")+l111l11l1lll_l1_)
			return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠩ夈")+l111l11l1lll_l1_,[],[]
		else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ変"),[],[]
	l1111lllllll_l1_,l111111ll1l1_l1_,l111llll1ll1_l1_ = [],[],[]
	for dict in l11l1l111l11_l1_:
		if dict[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ夊")]==l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ夋"):
			l11l1111ll1l_l1_.append(dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ夌")])
			l111l1ll1ll1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ复")]==l11lll_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ夎"):
			l11l1ll1111l_l1_.append(dict[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭夏")])
			l11l1l11ll1l_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ夐")]==l11lll_l1_ (u"ࠩࡰࡴࡩ࠭夑"):
			title = dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ夒")].replace(l11lll_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ夓"),l11lll_l1_ (u"ࠬ࠭夔"))
			if l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ夕") not in list(dict.keys()): l111l1lllll_l1_ = l11lll_l1_ (u"ࠧ࠱ࠩ外")
			else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ夗")]
			l1111lllllll_l1_.append([dict,{},title,l111l1lllll_l1_])
		else:
			title = dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ夘")].replace(l11lll_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ夙"),l11lll_l1_ (u"ࠫࠬ多"))
			if l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭夛") not in list(dict.keys()): l111l1lllll_l1_ = l11lll_l1_ (u"࠭࠰ࠨ夜")
			else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ夝")]
			l1111lllllll_l1_.append([dict,{},title,l111l1lllll_l1_])
			l11ll111llll_l1_.append(title)
			l111l1l111l1_l1_.append(dict)
		l11l1lll111l_l1_ = True
		if l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ夞") in list(dict.keys()):
			if l11lll_l1_ (u"ࠩࡤࡺ࠵࠭够") in dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ夠")]: l11l1lll111l_l1_ = False
			elif kodi_version<18:
				if l11lll_l1_ (u"ࠫࡦࡼࡣࠨ夡") not in dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ夢")] and l11lll_l1_ (u"࠭࡭ࡱ࠶ࡤࠫ夣") not in dict[l11lll_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ夤")]: l11l1lll111l_l1_ = False
		if dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ夥")]==l11lll_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ夦") and dict[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ大")]!=l11lll_l1_ (u"ࠫ࠵࠳࠰ࠨ夨") and l11l1lll111l_l1_==True:
			l11l11ll11l1_l1_.append(dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ天")])
			l11ll111l1l1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ太")]==l11lll_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭夫") and dict[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭夬")]!=l11lll_l1_ (u"ࠩ࠳࠱࠵࠭夭") and l11l1lll111l_l1_==True:
			l111ll11l111_l1_.append(dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ央")])
			l11l1lllll11_l1_.append(dict)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ夯"),l11lll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ夰")+dict[l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭失")])
	for l11l1ll1l111_l1_ in l11l1lllll11_l1_:
		l111ll11l1ll_l1_ = l11l1ll1l111_l1_[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ夲")]
		for l11l111111ll_l1_ in l11ll111l1l1_l1_:
			l1111ll1lll1_l1_ = l11l111111ll_l1_[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ夳")]
			l111l1lllll_l1_ = l1111ll1lll1_l1_+l111ll11l1ll_l1_
			title = l11l111111ll_l1_[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ头")].replace(l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ夵"),l11lll_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ夶"))
			title = title.replace(l11l111111ll_l1_[l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ夷")]+l11lll_l1_ (u"࠭ࠠࠡࠩ夸"),l11lll_l1_ (u"ࠧࠨ夹"))
			title = title.replace(str((float(l1111ll1lll1_l1_*10)//1024/10))+l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭夺"),str((float(l111l1lllll_l1_*10)//1024/10))+l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ夻"))
			title = title+l11lll_l1_ (u"ࠪࠬࠬ夼")+l11l1ll1l111_l1_[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ夽")].split(l11lll_l1_ (u"ࠬ࠮ࠧ夾"),1)[1]
			l1111lllllll_l1_.append([l11l111111ll_l1_,l11l1ll1l111_l1_,title,l111l1lllll_l1_])
	l1111lllllll_l1_ = sorted(l1111lllllll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l11l111111ll_l1_,l11l1ll1l111_l1_,title,l111l1lllll_l1_ in l1111lllllll_l1_:
		l11l1l11111l_l1_ = l11l111111ll_l1_[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ夿")]
		if l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ奀") in list(l11l1ll1l111_l1_.keys()):
			l11l1l11111l_l1_ = l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ奁")
			#l11l1l11111l_l1_ = l11l1l11111l_l1_+l11l1ll1l111_l1_[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ奂")]
		if l11l1l11111l_l1_ not in l111llll1ll1_l1_:
			l111llll1ll1_l1_.append(l11l1l11111l_l1_)
			l111111ll1l1_l1_.append([l11l111111ll_l1_,l11l1ll1l111_l1_,title,l111l1lllll_l1_])
			#LOG_THIS(l11lll_l1_ (u"ࠪࠫ奃"),str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ奄")+title)
	#l111111ll1l1_l1_ = sorted(l111111ll1l1_l1_, reverse=True, key=lambda key: int(key[3]))
	l1111lllll11_l1_,l111ll111111_l1_,shift = [],[],0
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࡷ࡭࡯ࡦࡵࠢ࠮ࡁࠥ࠷ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ࠭ࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠳ࡠࠎࠎࠏࡳࡦ࡮ࡨࡧࡹࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡩࡨࡰ࡫ࡦࡩࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ奅")
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࡳࡼࡴࡥࡳࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭ࡡ࡭ࡷࡴࡴࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡥࡺࡺࡨࡰࡴࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰࡤࡰࡳࡰࡰ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴࡢࡲࡦࡳࡥ࠻ࠌࠌࠍ࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠤࠫ࠲࠯ࡅࠩࠣࡣ࡯ࡰࡴࡽࡒࡢࡶ࡬ࡲ࡬ࡹࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࠏࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡺࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬࠻ࠢ࡬ࡱࡦ࡭ࡥࠡ࠿ࠣ࡭ࡲࡧࡧࡦࡵࡢࡹࡷࡲ࡛࠮࠳ࡠࠎࠎࠏ࡯ࡸࡰࡨࡶࠥࡃࠠࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨ࡟࠵ࡣࠊࠊࠋࡶ࡬࡮࡬ࡴࠡ࠭ࡀࠤ࠶ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧࠬࡱࡺࡲࡪࡸࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦࡗࡆࡄࡖࡍ࡙ࡋࡓ࡜ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪࡡࡠ࠶࡝ࠬࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ࠱࡯ࡸࡰࡨࡶࡤࡩࡨࡢࡰࡱࡩࡱࡡ࠰࡞ࠌࠌࠍࡸ࡫࡬ࡦࡥࡷࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡧ࡭ࡵࡩࡤࡧࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ奆")
	l11l1lll11ll_l1_,l11l11lll1l1_l1_ = l11lll_l1_ (u"ࠧࠨ奇"),l11lll_l1_ (u"ࠨࠩ奈")
	try: l11l1lll11ll_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ奉")][l11lll_l1_ (u"ࠪࡥࡺࡺࡨࡰࡴࠪ奊")]
	except: l11l1lll11ll_l1_ = l11lll_l1_ (u"ࠫࠬ奋")
	try: l111l11ll111_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ奌")][l11lll_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ奍")]
	except: l111l11ll111_l1_ = l11lll_l1_ (u"ࠧࠨ奎")
	if l11l1lll11ll_l1_ and l111l11ll111_l1_:
		shift += 1
		title = l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ奏")+l11l1lll11ll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ奐")
		link = l1ll11l_l1_[l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ契")][0]+l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ奒")+l111l11ll111_l1_
		l1111lllll11_l1_.append(title)
		l111ll111111_l1_.append(link)
		try: l11l11lll1l1_l1_ = l1111ll11ll1_l1_[l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ奓")][l11lll_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ奔")][l11lll_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ奕")][-1][l11lll_l1_ (u"ࠨࡷࡵࡰࠬ奖")]
		except: pass
	#if l11111l1ll11_l1_:
	#	shift += 1
	#	l1111lllll11_l1_.append(l11lll_l1_ (u"ࠩࡰࡴࡩࠦฬ้ัฬࠤี้๊สࠩ套")) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠪࡨࡦࡹࡨࠨ奘"))
	for l11l111111ll_l1_,l11l1ll1l111_l1_,title,l111l1lllll_l1_ in l111111ll1l1_l1_:
		l1111lllll11_l1_.append(title) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ奙"))
	if l11ll111llll_l1_: l1111lllll11_l1_.append(l11lll_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧ奚")) ; l111ll111111_l1_.append(l11lll_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ奛"))
	if l1111lllllll_l1_: l1111lllll11_l1_.append(l11lll_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫ奜")) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ奝"))
	if l11l11ll11l1_l1_: l1111lllll11_l1_.append(l11lll_l1_ (u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ奞")) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠪࡱࡵࡪࠧ奟"))
	if l11l1111ll1l_l1_: l1111lllll11_l1_.append(l11lll_l1_ (u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫ奠")) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ奡"))
	if l11l1ll1111l_l1_: l1111lllll11_l1_.append(l11lll_l1_ (u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭奢")) ; l111ll111111_l1_.append(l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭奣"))
	l11ll11l111l_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1111111llll_l1_, l1111lllll11_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭奤"),[],[]
		elif l1l_l1_==0 and l11l1lll11ll_l1_:
			link = l111ll111111_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11lll_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩ奥")+QUOTE(l11l1lll11ll_l1_)+l11lll_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ奦")+link
			if l11l11lll1l1_l1_: new_path = new_path+l11lll_l1_ (u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬ奧")+QUOTE(l11l11lll1l1_l1_)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ奨")+new_path+l11lll_l1_ (u"ࠨࠩࠣ奩"))
			return l11lll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ奪"),[],[]
		choice = l111ll111111_l1_[l1l_l1_]
		l1111l1l11ll_l1_ = l1111lllll11_l1_[l1l_l1_]
		if choice==l11lll_l1_ (u"ࠨࡦࡤࡷ࡭࠭奫"):
			l11111llll1l_l1_ = l11111l1ll11_l1_
			break
		elif choice in [l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ奬"),l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ奭"),l11lll_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ奮")]:
			if choice==l11lll_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ奯"): l1lll1ll_l1_,l111l1l11lll_l1_ = l11ll111llll_l1_,l111l1l111l1_l1_
			elif choice==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ奰"): l1lll1ll_l1_,l111l1l11lll_l1_ = l11l1111ll1l_l1_,l111l1ll1ll1_l1_
			elif choice==l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭奱"): l1lll1ll_l1_,l111l1l11lll_l1_ = l11l1ll1111l_l1_,l11l1l11ll1l_l1_
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ奲"), l1lll1ll_l1_)
			if l1l_l1_!=-1:
				l11111llll1l_l1_ = l111l1l11lll_l1_[l1l_l1_][l11lll_l1_ (u"ࠩࡸࡶࡱ࠭女")]
				l1111l1l11ll_l1_ = l1lll1ll_l1_[l1l_l1_]
				break
		elif choice==l11lll_l1_ (u"ࠪࡱࡵࡪࠧ奴"):
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ奵"), l11l11ll11l1_l1_)
			if l1l_l1_!=-1:
				l1111l1l11ll_l1_ = l11l11ll11l1_l1_[l1l_l1_]
				l11l11lll1ll_l1_ = l11ll111l1l1_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ奶"), l111ll11l111_l1_)
				if l1l_l1_!=-1:
					l1111l1l11ll_l1_ += l11lll_l1_ (u"࠭ࠠࠬࠢࠪ奷")+l111ll11l111_l1_[l1l_l1_]
					l11l1111111l_l1_ = l11l1lllll11_l1_[l1l_l1_]
					l11ll11l111l_l1_ = True
					break
		elif choice==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ奸"):
			l11l1l1l1l1l_l1_,l111ll1l111l_l1_,l111111lllll_l1_,l11l11l111l1_l1_ = list(zip(*l1111lllllll_l1_))
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ她"), l111111lllll_l1_)
			if l1l_l1_!=-1:
				l1111l1l11ll_l1_ = l111111lllll_l1_[l1l_l1_]
				l11l11lll1ll_l1_ = l11l1l1l1l1l_l1_[l1l_l1_]
				if l11lll_l1_ (u"ࠩࡰࡴࡩ࠭奺") in l111111lllll_l1_[l1l_l1_] and l11l11lll1ll_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ奻")]!=l11111l1ll11_l1_:
					l11l1111111l_l1_ = l111ll1l111l_l1_[l1l_l1_]
					l11ll11l111l_l1_ = True
				else: l11111llll1l_l1_ = l11l11lll1ll_l1_[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ奼")]
				break
		elif choice==l11lll_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭好"):
			#shift += 1
			l11l1l1l1l1l_l1_,l111ll1l111l_l1_,l111111lllll_l1_,l11l11l111l1_l1_ = list(zip(*l111111ll1l1_l1_))
			l11l11lll1ll_l1_ = l11l1l1l1l1l_l1_[l1l_l1_-shift]
			if l11lll_l1_ (u"࠭࡭ࡱࡦࠪ奾") in l111111lllll_l1_[l1l_l1_-shift] and l11l11lll1ll_l1_[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ奿")]!=l11111l1ll11_l1_:
				l11l1111111l_l1_ = l111ll1l111l_l1_[l1l_l1_-shift]
				l11ll11l111l_l1_ = True
			else: l11111llll1l_l1_ = l11l11lll1ll_l1_[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ妀")]
			l1111l1l11ll_l1_ = l111111lllll_l1_[l1l_l1_-shift]
			break
	if not l11ll11l111l_l1_: l11111lll111_l1_ = l11111llll1l_l1_
	else: l11111lll111_l1_ = l11lll_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ妁")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ如")]+l11lll_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ妃")+l11l1111111l_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ妄")]
	if l11ll11l111l_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ妅"),l11lll_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ妆")+str(l11l11lll1ll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ妇"),l11lll_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭妈")+str(l11l1111111l_l1_))
		#if l11ll111l111_l1_>l111llll111l_l1_: l1l1l1111_l1_ = str(l11ll111l111_l1_)
		#else: l1l1l1111_l1_ = str(l111llll111l_l1_)
		#l1l1l1111_l1_ = str(l11ll111l111_l1_) if l11ll111l111_l1_>l111llll111l_l1_ else str(l111llll111l_l1_)
		l11ll111l111_l1_ = int(l11l11lll1ll_l1_[l11lll_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ妉")])
		l111llll111l_l1_ = int(l11l1111111l_l1_[l11lll_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭妊")])
		l1l1l1111_l1_ = str(max(l11ll111l111_l1_,l111llll111l_l1_))
		l111lll1111l_l1_ = l11l11lll1ll_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ妋")].replace(l11lll_l1_ (u"࠭ࠦࠨ妌"),l11lll_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭妍"))		# +l11lll_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ妎")
		l11l1ll111l1_l1_ = l11l1111111l_l1_[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭妏")].replace(l11lll_l1_ (u"ࠪࠪࠬ妐"),l11lll_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ妑"))		# +l11lll_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠲࠳࠴࠵࠶࠰࠱ࠩ妒")
		l11ll111lll1_l1_ = l11lll_l1_ (u"࠭࠼ࡀࡺࡰࡰࠥࡼࡥࡳࡵ࡬ࡳࡳࡃࠢ࠲࠰࠳ࠦࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࠣࡗࡗࡊ࠲࠾ࠢࡀࡀ࡟ࡲࠬ妓")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡏࡓࡈࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡹࡩ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠲࠱࠲࠴࠳࡝ࡓࡌࡔࡥ࡫ࡩࡲࡧ࠭ࡪࡰࡶࡸࡦࡴࡣࡦࠤࠣࡼࡲࡲ࡮ࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠧࠦࡸ࡮࡮ࡱࡷ࠿ࡾ࡬ࡪࡰ࡮ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠴࠽࠾࠿࠯ࡹ࡮࡬ࡲࡰࠨࠠࡹࡵ࡬࠾ࡸࡩࡨࡦ࡯ࡤࡐࡴࡩࡡࡵ࡫ࡲࡲࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠡࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡳࡪࡡࡳࡦࡶ࠲࡮ࡹ࡯࠯ࡱࡵ࡫࠴࡯ࡴࡵࡨ࠲ࡔࡺࡨ࡬ࡪࡥ࡯ࡽࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࡓࡵࡣࡱࡨࡦࡸࡤࡴ࠱ࡐࡔࡊࡍ࠭ࡅࡃࡖࡌࡤࡹࡣࡩࡧࡰࡥࡤ࡬ࡩ࡭ࡧࡶ࠳ࡉࡇࡓࡉ࠯ࡐࡔࡉ࠴ࡸࡴࡦࠥࠤࡲ࡯࡮ࡃࡷࡩࡪࡪࡸࡔࡪ࡯ࡨࡁࠧࡖࡔ࠲࠰࠸ࡗࠧࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨ妔")+l1l1l1111_l1_+l11lll_l1_ (u"ࠨࡕࠥࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࡂࡡࡴࠧ妕")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭妖")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠲ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡷ࡫ࡧࡩࡴ࠵ࠧ妗")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭妘")]+l11lll_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ妙")		# l111lllll111_l1_=l11lll_l1_ (u"ࠨ࠱ࠣ妚") l11ll111ll11_l1_=l11lll_l1_ (u"ࠢࡵࡴࡸࡩࠧ妛") default=l11lll_l1_ (u"ࠣࡶࡵࡹࡪࠨ妜")>\n
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ妝")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ妞")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ妟")]+l11lll_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ妠")+l11l11lll1ll_l1_[l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭妡")]+l11lll_l1_ (u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤࠪ妢")+str(l11l11lll1ll_l1_[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ妣")])+l11lll_l1_ (u"ࠩࠥࠤࡼ࡯ࡤࡵࡪࡀࠦࠬ妤")+str(l11l11lll1ll_l1_[l11lll_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ妥")])+l11lll_l1_ (u"ࠫࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠨ妦")+str(l11l11lll1ll_l1_[l11lll_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ妧")])+l11lll_l1_ (u"࠭ࠢࠡࡨࡵࡥࡲ࡫ࡒࡢࡶࡨࡁࠧ࠭妨")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠧࡧࡲࡶࠫ妩")]+l11lll_l1_ (u"ࠨࠤࡁࡠࡳ࠭妪")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ妫")+l111lll1111l_l1_+l11lll_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ妬")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ妭")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ妮")]+l11lll_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ妯")	# l111111ll1ll_l1_=l11lll_l1_ (u"ࠢࡵࡴࡸࡩࠧ妰")>\n
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ妱")+l11l11lll1ll_l1_[l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ妲")]+l11lll_l1_ (u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ妳")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ妴")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ妵")
		l11ll111lll1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ妶")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠷ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫ妷")+l11l1111111l_l1_[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ妸")]+l11lll_l1_ (u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ࠭妹")		# l111lllll111_l1_=l11lll_l1_ (u"ࠥ࠵ࠧ妺") l11ll111ll11_l1_=l11lll_l1_ (u"ࠦࡹࡸࡵࡦࠤ妻") default=l11lll_l1_ (u"ࠧࡺࡲࡶࡧࠥ妼")>\n
		l11ll111lll1_l1_ += l11lll_l1_ (u"࠭࠼ࡓࡱ࡯ࡩࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡄࡂࡕࡋ࠾ࡷࡵ࡬ࡦ࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣ࡯ࡤ࡭ࡳࠨ࠯࠿࡞ࡱࠫ妽")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠢ࡬ࡨࡂࠨࠧ妾")+l11l1111111l_l1_[l11lll_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭妿")]+l11lll_l1_ (u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭姀")+l11l1111111l_l1_[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ姁")]+l11lll_l1_ (u"ࠫࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥ࠵࠸࠶࠴࠸࠷ࠥࡂࡡࡴࠧ姂")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠬࡂࡁࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽࠶࠸࠶࠰࠴࠼࠶࠾ࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠫ姃")+l11l1111111l_l1_[l11lll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ姄")]+l11lll_l1_ (u"ࠧࠣ࠱ࡁࡠࡳ࠭姅")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ姆")+l11l1ll111l1_l1_+l11lll_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ姇")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ姈")+l11l1111111l_l1_[l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ姉")]+l11lll_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ姊")	# l111111ll1ll_l1_=l11lll_l1_ (u"ࠨࡴࡳࡷࡨࠦ始")>\n
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ姌")+l11l1111111l_l1_[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭姍")]+l11lll_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ姎")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭姏")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ姐")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ姑")
		l11ll111lll1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ姒")
		l11ll111lll1_l1_ += l11lll_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ姓")
		#open(l11lll_l1_ (u"ࠨࡵ࠽ࡠࡡࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ委"),l11lll_l1_ (u"ࠩࡺࡦࠬ姕")).write(l11ll111lll1_l1_)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ姖"),l11ll111lll1_l1_)
		#l11ll111lll1_l1_ = OPENURL_CACHED(NO_CACHE,l11111l1ll11_l1_,l11lll_l1_ (u"ࠫࠬ姗"),l11lll_l1_ (u"ࠬ࠭姘"),l11lll_l1_ (u"࠭ࠧ姙"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠾ࡺࡨࠨ姚"))
		if kodi_version>18.99:
			import http.server as l11l111l1ll1_l1_
			import http.client as l1111llll1ll_l1_
		else:
			import BaseHTTPServer as l11l111l1ll1_l1_
			import httplib as l1111llll1ll_l1_
		class l1111l11lll1_l1_(l11l111l1ll1_l1_.HTTPServer):
			#l11ll111lll1_l1_ = l11lll_l1_ (u"ࠨ࠾ࡁࠫ姛")
			def __init__(self,l1l1ll1l1lll_l1_=l11lll_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ姜"),port=55055,l11ll111lll1_l1_=l11lll_l1_ (u"ࠪࡀࡃ࠭姝")):
				self.l1l1ll1l1lll_l1_ = l1l1ll1l1lll_l1_
				self.port = port
				self.l11ll111lll1_l1_ = l11ll111lll1_l1_
				l11l111l1ll1_l1_.HTTPServer.__init__(self,(self.l1l1ll1l1lll_l1_,self.port),l111ll1111ll_l1_)
				self.l1111l111ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ姞")+l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠬࡀࠧ姟")+str(port)+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ姠")
				#print(l11lll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡹࡵࠦ࡮ࡰࡹࠣࡰ࡮ࡹࡴࡦࡰ࡬ࡲ࡬ࠦ࡯࡯ࠢࡳࡳࡷࡺ࠺ࠡࠩ姡")+str(port))
			def start(self):
				self.threads = l11111lllll_l1_(False)
				self.threads.start_new_thread(1,self.l111lll1l1ll_l1_)
			def l111lll1l1ll_l1_(self):
				#print(l11lll_l1_ (u"ࠨࡵࡨࡶࡻ࡯࡮ࡨࠢࡵࡩࡶࡻࡥࡴࡶࡶࠤࡸࡺࡡࡳࡶࡨࡨࠬ姢"))
				self.l111111l1ll1_l1_ = True
				#l1l11l1ll1l_l1_ = 0
				while self.l111111l1ll1_l1_:
					#l1l11l1ll1l_l1_ += 1
					#print(l11lll_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠣࡥࠥࡹࡩ࡯ࡩ࡯ࡩࠥ࡮ࡡ࡯ࡦ࡯ࡩࡤࡸࡥࡲࡷࡨࡷࡹ࠮ࠩࠡࡰࡲࡻ࠿ࠦࠧ姣")+str(l1l11l1ll1l_l1_)+l11lll_l1_ (u"ࠪࠫ姤"))
					#settimeout l1111lll1l_l1_ not l111l1l1l1_l1_ l111l11l111l_l1_ to error message if it l1111ll11l11_l1_ l11111l11l1l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111lll1l1ll_l1_ l111llll1l1l_l1_ request l11111llllll_l1_ 60 seconds)
					self.handle_request()
				#print(l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡲࡴࡵ࡫ࡤ࡝ࡰࠪ姥"))
			def stop(self):
				self.l111111l1ll1_l1_ = False
				self.l11l11111l11_l1_()	# needed to l11l1lllllll_l1_ self.handle_request() to l111lll1l1ll_l1_ l1lllllll1ll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳࠦ࡮ࡰࡹ࡟ࡲࠬ姦"))
			def load(self,l11ll111lll1_l1_):
				self.l11ll111lll1_l1_ = l11ll111lll1_l1_
			def l11l11111l11_l1_(self):
				conn = l1111llll1ll_l1_.HTTPConnection(self.l1l1ll1l1lll_l1_+l11lll_l1_ (u"࠭࠺ࠨ姧")+str(self.port))
				conn.request(l11lll_l1_ (u"ࠢࡉࡇࡄࡈࠧ姨"), l11lll_l1_ (u"ࠣ࠱ࠥ姩"))
		class l111ll1111ll_l1_(l11l111l1ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11lll_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡉࡈࡘࠥࠦࠧ姪")+self.path)
				self.send_response(200)
				self.send_header(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ姫"),l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ姬"))
				self.end_headers()
				#self.wfile.write(self.path+l11lll_l1_ (u"ࠬࡢ࡮ࠨ姭"))
				self.wfile.write(self.server.l11ll111lll1_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ姮")))
				time.sleep(1)
				if self.path==l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭姯"): self.server.shutdown()
				if self.path==l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ姰"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11lll_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡊࡈࡅࡉࠦࠠࠨ姱")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1111l11lll1_l1_(l11lll_l1_ (u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭姲"),55055,l11ll111lll1_l1_)
		#httpd.load(l11ll111lll1_l1_)
		l11111llll1l_l1_ = httpd.l1111l111ll1_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l11111llll1l_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠴ࡤࡢࡵ࡫࡭࡫࠴࡯ࡳࡩ࠲ࡰ࡮ࡼࡥࡴ࡫ࡰ࠳ࡨ࡮ࡵ࡯࡭ࡧࡹࡷࡥ࠱࠰ࡣࡷࡳࡤ࠽࠯ࡵࡧࡶࡸࡵ࡯ࡣ࠵ࡡ࠻ࡷ࠴ࡓࡡ࡯࡫ࡩࡩࡸࡺ࠮࡮ࡲࡧࠫ姳")
		#l11111llll1l_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡢࡵ࡫࠲ࡦࡱࡡ࡮ࡣ࡬ࡾࡪࡪ࠮࡯ࡧࡷ࠳ࡩࡧࡳࡩ࠴࠹࠸࠴࡚ࡥࡴࡶࡆࡥࡸ࡫ࡳ࠰࠴ࡦ࠳ࡶࡻࡡ࡭ࡥࡲࡱࡲ࠵࠱࠰ࡏࡸࡰࡹ࡯ࡒࡦࡵࡐࡔࡊࡍ࠲࠯࡯ࡳࡨࠬ姴")
		#l11111llll1l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡶࡶ࡭࠳ࡺࡥ࡭ࡧࡦࡳࡲ࠳ࡰࡢࡴ࡬ࡷࡹ࡫ࡣࡩ࠰ࡩࡶ࠴࡭ࡰࡢࡥ࠲ࡈࡆ࡙ࡈࡠࡅࡒࡒࡋࡕࡒࡎࡃࡑࡇࡊ࠵ࡔࡦ࡮ࡨࡧࡴࡳࡐࡢࡴ࡬ࡷ࡙࡫ࡣࡩ࠱ࡰࡴ࠹࠳࡬ࡪࡸࡨ࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠳࡭ࡱࡦ࠰ࡅ࡛࠳ࡂࡔ࠰ࡰࡴࡩ࠭姵")
		#l11111llll1l_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡳࡦࡰࡩࡩ࡯ࡡ࠯ࡤࡥࡧ࠳ࡩ࡯࠯ࡷ࡮࠳ࡩࡧࡳࡩ࠱ࡲࡲࡩ࡫࡭ࡢࡰࡧ࠳ࡹ࡫ࡳࡵࡥࡤࡶࡩ࠵࠱࠰ࡥ࡯࡭ࡪࡴࡴࡠ࡯ࡤࡲ࡮࡬ࡥࡴࡶ࠰ࡩࡻ࡫࡮ࡵࡵ࠰ࡱࡺࡲࡴࡪ࡮ࡤࡲ࡬࠴࡭ࡱࡦࠪ姶")
		#l11111llll1l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ姷")
	else: httpd = l11lll_l1_ (u"ࠩࠪ姸")
	if not l11111llll1l_l1_: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ姹"),[],[]
	return l11lll_l1_ (u"ࠫࠬ姺"),[l11lll_l1_ (u"ࠬ࠭姻")],[[l11111llll1l_l1_,l111ll1ll111_l1_,httpd]]
def l111l11l1l11_l1_(url):
	# https://l11l1llll111_l1_.com/l111l1ll1l1l_l1_
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ姼") : l11lll_l1_ (u"ࠧࠨ姽") }
	#url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ姾"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ姿"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ娀"),headers,l11lll_l1_ (u"ࠫࠬ威"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬ娂"))
	items = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪ娃"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11l11ll11ll_l1_,l1lll1ll_l1_,l11l1l1ll11l_l1_,l1111_l1_ = [],[],[],[]
	if items:
		for link,dummy,l1ll11l1l11l_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ娄"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ娅"))
			if l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ娆") in link:
				l11l11ll11ll_l1_,l11l1l1ll11l_l1_ = l11ll11lll_l1_(link)
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ娇"),l11lll_l1_ (u"ࠫࠬ娈"),str(l1111_l1_),str(l11l1l1ll11l_l1_))
				l1111_l1_ = l1111_l1_ + l11l1l1ll11l_l1_
				if l11l11ll11ll_l1_[0]==l11lll_l1_ (u"ࠬ࠳࠱ࠨ娉"): l1lll1ll_l1_.append(l11lll_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ娊")+l11lll_l1_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ娋"))
				else:
					for title in l11l11ll11ll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨีํีๆืࠠฯษุࠫ娌")+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭娍")+title)
			else:
				title = l11lll_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭娎")+l11lll_l1_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ娏")+l1ll11l1l11l_l1_
				l1111_l1_.append(link)
				l1lll1ll_l1_.append(title)
		return l11lll_l1_ (u"ࠬ࠭娐"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨ娑"),[],[]
def l11111l1lll1_l1_(url):
	# https://l11ll11111l1_l1_.cc/l1l111lll_l1_-1qrpoobdg7bu.html
	# https://l111llllllll_l1_.cc//l1l111lll_l1_-l11l11l111ll_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ娒"),url,l11lll_l1_ (u"ࠨࠩ娓"),l11lll_l1_ (u"ࠩࠪ娔"),l11lll_l1_ (u"ࠪࠫ娕"),l11lll_l1_ (u"ࠫࠬ娖"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚࡙ࡍࡉࡋࡏࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ娗"))
	html = response.content
	links = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ娘"),html,re.DOTALL)
	if links:
		link = links[0]
		return l11lll_l1_ (u"ࠧࠨ娙"),[l11lll_l1_ (u"ࠨࠩ娚")],[link]
	return l11lll_l1_ (u"ࠩࠪ娛"),[],[]
def l11111ll1ll1_l1_(url):
	# https://l11111ll1l1l_l1_.in/l1111ll1l111_l1_
	# https://l11111ll1l1l_l1_.in/l1l111lll_l1_-l1111ll1l111_l1_.html
	# https://l11l111ll1ll_l1_.l111l1111l11_l1_/l11l1ll1llll_l1_
	# https://l11l111ll1ll_l1_.l111l1111l11_l1_/l1l111lll_l1_-l11l1ll1llll_l1_.html
	# https://www.l11l1lll1l1l_l1_.com/l1l111lll_l1_-l111ll11ll1l_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ娜"),l11lll_l1_ (u"ࠫࠬ娝")).replace(l11lll_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ娞"),l11lll_l1_ (u"࠭ࠧ娟"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ娠"),url,l11lll_l1_ (u"ࠨࠩ娡"),l11lll_l1_ (u"ࠩࠪ娢"),l11lll_l1_ (u"ࠪࠫ娣"),l11lll_l1_ (u"ࠫࠬ娤"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡉࡍࡑࡋࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ娥"))
	html = response.content
	l1ll11l1llll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪ࡞ࠬ࠭ࠬ娦"),html,re.DOTALL)
	if l1ll11l1llll_l1_:
		l1ll11l1llll_l1_ = l1ll11l1llll_l1_[0]
		l1l1l1ll1l1l_l1_ = l1l1ll1llll1_l1_(l1ll11l1llll_l1_)
		links = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭娧"),l1l1l1ll1l1l_l1_,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨࠪࡿࠪ娨"),l1l1l1ll1l1l_l1_,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link,title in links:
			if not title: title = link.rsplit(l11lll_l1_ (u"ࠩ࠱ࠫ娩"),1)[1]
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		return l11lll_l1_ (u"ࠪࠫ娪"),l1lll1ll_l1_,l1111_l1_
	id = url.split(l11lll_l1_ (u"ࠫ࠴࠭娫"))[3]
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ娬"):l11lll_l1_ (u"࠭ࠧ娭") , l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭娮"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ娯") }
	payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ娰"):id , l11lll_l1_ (u"ࠪࡳࡵ࠭娱"):l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ娲") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ娳"),url,payload,headers,l11lll_l1_ (u"࠭ࠧ娴"),l11lll_l1_ (u"ࠧࠨ娵"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ娶"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ娷"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠪࠫ娸"),[l11lll_l1_ (u"ࠫࠬ娹")],[ items[0] ]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠭娺"),[],[]
l11lll_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡇࡐࡘࡌࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡲࡺ࡮ࡪ࠮ࡤࡱ࠲ࡺ࡮ࡪࡥࡰ࠱ࡳࡰࡦࡿ࠯ࡂࡃ࡙ࡉࡓࡪࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀࠦࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࠥࡀࠠࠨࠩࠣࢁࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒ࡚ࡎࡊ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻ࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡹ࡫࡭ࡱ࡝࠳ࡡࡂࡃࠧ࠮࠳ࠪ࠾ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨࠫࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠻ࠌࠌࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥ࠭ࠫࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠ࡮ࡲ࠷ࠫࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣࠫࠬ࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑ࡙ࡍࡉ࠭ࠬ࡜࡟࠯࡟ࡢࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠶ࡳ࠮ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡶࡸࡷ࡫ࡡ࡮࠱࠵࠶࠾࠴࡭࠴ࡷ࠻ࠎࠧࠨࠢ娻")
#####################################################
#    l11l1ll11lll_l1_ l111l1lll1ll_l1_ l111l1111lll_l1_
#    16-06-2019
#####################################################
def l111l1l1lll1_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ娼"),l11lll_l1_ (u"ࠨࠩ娽"),l11lll_l1_ (u"ࠩࠪ娾"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭娿"))
	items = re.findall(l11lll_l1_ (u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ婀"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠬ࠭婁"),[l11lll_l1_ (u"࠭ࠧ婂")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬ婃"),[],[]
def l111l1l111ll_l1_(url):
	return l11lll_l1_ (u"ࠨࠩ婄"),[l11lll_l1_ (u"ࠩࠪ婅")],[ url ]
def l111l1llll1l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ婆"),l11lll_l1_ (u"ࠫࠬ婇"),url,l11lll_l1_ (u"ࠬ࠭婈"))
	server = url.split(l11lll_l1_ (u"࠭࠯ࠨ婉"))
	basename = l11lll_l1_ (u"ࠧ࠰ࠩ婊").join(server[0:3])
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ婋"),l11lll_l1_ (u"ࠩࠪ婌"),l11lll_l1_ (u"ࠪࠫ婍"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡛࠭ࡋࡓࡔ࡞࡙ࡈࡂࡔࡈ࠱࠶ࡹࡴࠨ婎"))
	items = re.findall(l11lll_l1_ (u"ࠬࡪ࡬ࡣࡷࡷࡸࡴࡴ࡜ࠨ࡞ࠬ࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠥࡢࠫࠡ࡞ࠫࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࠤࡡ࠱ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩ࡝ࠫࠣࡠ࠰ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ婏"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ婐"),l11lll_l1_ (u"ࠧࠨ婑"),url,str(var))
	if items:
		l11llll1l111_l1_,l11lllll1l11_l1_,l11lllll1l1l_l1_,l11l11l11111_l1_,l11l11l1111l_l1_,l11l111lllll_l1_ = items[0]
		var = int(l11lllll1l11_l1_) % int(l11lllll1l1l_l1_) + int(l11l11l11111_l1_) % int(l11l11l1111l_l1_)
		url = basename + l11llll1l111_l1_ + str(var) + l11l111lllll_l1_
		return l11lll_l1_ (u"ࠨࠩ婒"),[l11lll_l1_ (u"ࠩࠪ婓")],[url]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ婔"),[],[]
def l11l111l1l1l_l1_(url):
	url = url.replace(l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ婕"),l11lll_l1_ (u"ࠬ࠭婖"))
	url = url.replace(l11lll_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ婗"),l11lll_l1_ (u"ࠧࠨ婘"))
	id = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ婙"))[-1]
	headers = { l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ婚") : l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ婛") }
	payload = { l11lll_l1_ (u"ࠦ࡮ࡪࠢ婜"):id , l11lll_l1_ (u"ࠧࡵࡰࠣ婝"):l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤ婞") }
	request = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ婟"), url, payload, headers, l11lll_l1_ (u"ࠨࠩ婠"),l11lll_l1_ (u"ࠩࠪ婡"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭婢"))
	if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭婣") in list(request.headers.keys()): link = request.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ婤")]
	else: link = url
	if link: return l11lll_l1_ (u"࠭ࠧ婥"),[l11lll_l1_ (u"ࠧࠨ婦")],[link]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭婧"),[],[]
def l1111lll1l1l_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ婨"),l11lll_l1_ (u"ࠪࠫ婩"),l11lll_l1_ (u"ࠫࠬ婪"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ婫"))
	items = re.findall(l11lll_l1_ (u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ婬"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠧࠨ婭"),[l11lll_l1_ (u"ࠨࠩ婮")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧ婯"),[],[]
def l111111ll111_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ婰"),l11lll_l1_ (u"ࠫࠬ婱"),l11lll_l1_ (u"ࠬ࠭婲"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ婳"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ婴"),html,re.DOTALL)
	#l111lllllll1_l1_.l11111l111l1_l1_(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ婵") + items[0])
	if items:
		url = url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ婶") + items[0]
		return l11lll_l1_ (u"ࠪࠫ婷"),[l11lll_l1_ (u"ࠫࠬ婸")],[ url ]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨ婹"),[],[]
def l111ll11llll_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ婺"),l11lll_l1_ (u"ࠧࠨ婻"),l11lll_l1_ (u"ࠨࠩ婼"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚࠭࠲ࡵࡷࠫ婽"))
	items = re.findall(l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ婾"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ婿"),l11lll_l1_ (u"ࠬ࠭媀"),str(items),html)
	if items: return l11lll_l1_ (u"࠭ࠧ媁"),[l11lll_l1_ (u"ࠧࠨ媂")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘࠬ媃"),[],[]
def l111l1l1l1l1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ媄"),l11lll_l1_ (u"ࠪࠫ媅"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ媆"),l11lll_l1_ (u"ࠬ࠭媇"),l11lll_l1_ (u"࠭ࠧ媈"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ媉"))
	items = re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ媊"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ媋"),l11lll_l1_ (u"ࠪࠫ媌"),items[0],items[0])
	if items: return l11lll_l1_ (u"ࠫࠬ媍"),[l11lll_l1_ (u"ࠬ࠭媎")],[ items[0] ]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎࠩ媏"),[],[]
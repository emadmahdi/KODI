# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ䎜")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ䎝")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ䎞"),l11lll_l1_ (u"ࠧศีอๅุอัหๅ่ࠤํࠦวๅู็ฬฬะࠧ䎟")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1111l_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1llll_l1_(url)
	elif mode==454: results = l1llllll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䎠"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ䎡"),l11lll_l1_ (u"ࠪࠫ䎢"),l11lll_l1_ (u"ࠫࠬ䎣"),l11lll_l1_ (u"ࠬ࠭䎤"),l11lll_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䎥"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ䎦"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎧"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䎨"),l11lll_l1_ (u"ࠪࠫ䎩"),459,l11lll_l1_ (u"ࠫࠬ䎪"),l11lll_l1_ (u"ࠬ࠭䎫"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䎬"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎭"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䎮")+l111ll_l1_+l11lll_l1_ (u"่ࠩฯอะวหࠢ็์ิ๐ࠠ็ฬࠪ䎯"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠪࠫ䎰"),l11lll_l1_ (u"ࠫࠬ䎱"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䎲"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎳"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䎴")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ䎵"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠩࠪ䎶"),l11lll_l1_ (u"ࠪࠫ䎷"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䎸"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎹"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䎺")+l111ll_l1_+l11lll_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䎻"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠨࠩ䎼"),l11lll_l1_ (u"ࠩࠪ䎽"),l11lll_l1_ (u"ࠪࡥࡨࡺ࡯ࡳࡵࠪ䎾"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎿"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䏀")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะ่่ࠠา๎ฮ࠭䏁"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠧࠨ䏂"),l11lll_l1_ (u"ࠨࠩ䏃"),l11lll_l1_ (u"ࠩ࠳ࠫ䏄"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䏅"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䏆")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอ๋ࠥฯษๆฯอࠬ䏇"),l1ll1l1_l1_,451,l11lll_l1_ (u"࠭ࠧ䏈"),l11lll_l1_ (u"ࠧࠨ䏉"),l11lll_l1_ (u"ࠨ࠳ࠪ䏊"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏋"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䏌")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ็ไศ็๋๋ࠣี๊สࠩ䏍"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠬ࠭䏎"),l11lll_l1_ (u"࠭ࠧ䏏"),l11lll_l1_ (u"ࠧ࠳ࠩ䏐"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䏑"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䏒"),l11lll_l1_ (u"ࠪࠫ䏓"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡓࡡࡪࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠫ䏔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏕"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"࠭ࠣࠨ䏖"): continue
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏗"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䏘")+l111ll_l1_+title,link,451)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"ࠩࠪ䏙")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䏚"),l11lll_l1_ (u"ࠫࠬ䏛"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䏜"),url,l11lll_l1_ (u"࠭ࠧ䏝"),l11lll_l1_ (u"ࠧࠨ䏞"),l11lll_l1_ (u"ࠨࠩ䏟"),l11lll_l1_ (u"ࠩࠪ䏠"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ䏡"))
	html = response.content
	if l1lll1ll11_l1_==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䏢"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡺࡥࡻ࡫ࡳࠣࠩ䏣"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l1lll1ll11_l1_==l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䏤"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡔࡨࡧࡪࡴࡴࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ䏥"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠧ䏦") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ䏧"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࠢࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏨"),block,re.DOTALL)
	elif l1lll1ll11_l1_ in [l11lll_l1_ (u"ࠫ࠵࠭䏩"),l11lll_l1_ (u"ࠬ࠷ࠧ䏪"),l11lll_l1_ (u"࠭࠲ࠨ䏫")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫ䏬"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(l1lll1ll11_l1_)]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ䏭"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ䏮"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ䏯"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ䏰"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ䏱"),l11lll_l1_ (u"࠭ร฻่ํอࠬ䏲"),l11lll_l1_ (u"ࠧไๆํฬࠬ䏳"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ䏴"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ䏵"),l11lll_l1_ (u"้ࠪออัศหࠪ䏶"),l11lll_l1_ (u"ࠫ฾ืึࠨ䏷"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ䏸"),l11lll_l1_ (u"࠭วๅส๋้ࠬ䏹")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭䏺") in html and l11lll_l1_ (u"ࠨࡵࡵࡧࡂ࠭䏻") in l1llll_l1_:
			l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䏼"),l1llll_l1_,re.DOTALL)
			l1llll_l1_ = l1llll_l1_[0]
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ䏽"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ䏾"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ䏿"),title,re.DOTALL)
		#if any(value in title for value in l1lll1_l1_):
		if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"࠭ๅิๆึ่ࠬ䐀") not in title:
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䐁"),l111ll_l1_+title,link,452,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠨฯ็ๆฮ࠭䐂") in title:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䐃") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐄"),l111ll_l1_+title,link,453,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐅"),l111ll_l1_+title,link,453,l1llll_l1_)
	if l1lll1ll11_l1_ in [l11lll_l1_ (u"ࠬ࠭䐆"),l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䐇")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䐈"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐉"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠤࠥ䐊"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠪࠫ䐋"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐌"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䐍")+title,link,451)
	return
def l1lll1llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䐎"),url,l11lll_l1_ (u"ࠧࠨ䐏"),l11lll_l1_ (u"ࠨࠩ䐐"),l11lll_l1_ (u"ࠩࠪ䐑"),l11lll_l1_ (u"ࠪࠫ䐒"),l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪ䐓"))
	html = response.content
	# l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡔࡷࡥࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䐔"),html,re.DOTALL)
	if l1l1l11_l1_ and l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬ䐕") in str(l1l1l11_l1_):
		title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮࠳ࠧ䐖"),html,re.DOTALL)
		title = title[0].strip(l11lll_l1_ (u"ࠨࠢࠪ䐗"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䐘"),l111ll_l1_+title,url,454)
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐙"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐚"),l111ll_l1_+title,link,454)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䐛"),url,l11lll_l1_ (u"࠭ࠧ䐜"),l11lll_l1_ (u"ࠧࠨ䐝"),l11lll_l1_ (u"ࠨࠩ䐞"),l11lll_l1_ (u"ࠩࠪ䐟"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䐠"))
	html = response.content
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ䐡"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ䐢"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䐣"),l111ll_l1_+title,link,452,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䐤"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐥"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠤࠥ䐦"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠪࠫ䐧"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐨"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䐩")+title,link,454)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䐪"),l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䐫"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䐬"),l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䐭"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䐮"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ䐯"),l11lll_l1_ (u"ࠬ࠭䐰"),l11lll_l1_ (u"࠭ࠧ䐱"),l11lll_l1_ (u"ࠧࠨ䐲"),l11lll_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䐳"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭䐴"))
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡗ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡶ࡭ࡩ࡫࠾ࠨ䐵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭䐶"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䐷")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䐸")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡴࡧ࡯ࡥࡷࡿࠢࠨ䐹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ䐺"),block,re.DOTALL)
		for link,name in items:
			name = unescapeHTML(name)
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ䐻"),name,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䐼")+l11l111l_l1_[0]
				name = l11lll_l1_ (u"ࠫࠬ䐽")
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭䐾")
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䐿")+name+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䑀")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䑁"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䑂"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ䑃"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ䑄"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ䑅"),l11lll_l1_ (u"࠭ࠫࠨ䑆"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ䑇")+search
	l1111l_l1_(url)
	return
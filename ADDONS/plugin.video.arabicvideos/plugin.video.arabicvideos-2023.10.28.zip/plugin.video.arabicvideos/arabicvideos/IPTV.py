# -*- coding: utf-8 -*-
from LIBSTWO import *

script_namee = 'IPTV'
menu_namee = '_IPT_'

UNIQUE_TYPESs = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]

def MAIN(modee,urll,textt,typee,pagee,infodictt):
	global menu_namee
	try:
		folderr = str(infodictt['folder'])
		menu_namee = '_IP'+folderr+'_'
	except: folderr = ''
	if   modee==230: resultss = FOLDERS_MENU()
	elif modee==231: resultss = ADD_ACCOUNT(folderr)
	elif modee==232: resultss = CREATE_STREAMS(folderr)
	elif modee==233: resultss = GROUPS(folderr,urll,textt,pagee)
	elif modee==234: resultss = ITEMS(folderr,urll,textt,pagee)
	elif modee==235: resultss = PLAY(folderr,urll,typee)
	elif modee==236: resultss = CHECK_ACCOUNT(folderr,True)
	elif modee==237: resultss = DELETE_FILES(folderr,True)
	elif modee==238: resultss = EPG_ITEMS(folderr,urll,textt)
	elif modee==239: resultss = SEARCH(textt,folderr,urll,pagee)
	elif modee==280: resultss = MENU(folderr,True)
	elif modee==281: resultss = COUNTS(folderr)
	elif modee==282: resultss = USE_FASTER_SERVER(folderr)
	elif modee==283: resultss = ADD_USERAGENT(folderr)
	elif modee==285: resultss = XTREAM_MENUS(folderr,urll,textt)
	elif modee==286: resultss = ADD_REFERER(folderr)
	elif modee==289: resultss = SEARCH_ONE_FOLDER(textt,folderr,urll,pagee)
	else: resultss = False
	return resultss

def FOLDERS_MENU():
	for folderr in range(1,FOLDERS_COUNT+1):
		#folderr2 = ' IPTV'+str(folderr)
		menu_namee = '_IP'+str(folderr)+'_'
		addMenuItem('folder',menu_namee+'قائمة مجلد '+text_numbers[folderr],'',280,'','','','',{'folder':folderr})
	return

def MENU(folderr,showDialogss):
	if folderr:
		folderr1 = {'folder':folderr}
		folderr2 = ''  # ' IPTV'+str(folderr)
	else:
		folderr1 = ''
		folderr2 = ''
	streams_existt = CHECK_TABLES_EXIST(folderr,showDialogss)
	if not streams_existt:
		addMenuItem('link',menu_namee+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+folderr2+' [/COLOR]','',231,'','','','',folderr1)
		addMenuItem('link',menu_namee+'[COLOR FFFFFF00] جلب ملفات'+folderr2+' [/COLOR]','',232,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	else:
		addMenuItem('folder',menu_namee+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'بحث في الملفات'+folderr2,'',289,'','','_REMEMBERRESULTS_','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'قنوات مصنفة مرتبة'+folderr2,'LIVE_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'أفلام مصنفة مرتبة'+folderr2,'VOD_MOVIES_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'مسلسلات مصنفة مرتبة'+folderr2,'VOD_SERIES_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'فيديوهات مجهولة مرتبة'+folderr2,'VOD_UNKNOWN_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'قنوات مجهولة مرتبة'+folderr2,'LIVE_UNKNOWN_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'قنوات مصنفة من القسم'+folderr2,'LIVE_FROM_GROUP_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'فيديوهات مصنفة من القسم'+folderr2,'VOD_FROM_GROUP_SORTED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'قنوات مصنفة من الاسم'+folderr2,'LIVE_FROM_NAME_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'فيديوهات مصنفة من الاسم'+folderr2,'VOD_FROM_NAME_SORTED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'قنوات مصنفة أصلية'+folderr2,'LIVE_GROUPED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'أفلام مصنفة أصلية'+folderr2,'VOD_MOVIES_GROUPED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'مسلسلات مصنفة أصلية'+folderr2,'VOD_SERIES_GROUPED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'فيديوهات مجهولة أصلية'+folderr2,'VOD_UNKNOWN_GROUPED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'قنوات مجهولة أصلية'+folderr2,'LIVE_UNKNOWN_GROUPED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'قنوات أصلية'+folderr2,'LIVE_ORIGINAL_GROUPED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'فيديوهات أصلية'+folderr2,'VOD_ORIGINAL_GROUPED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		addMenuItem('folder',menu_namee+'برامج القنوات (جدول فقط)'+folderr2,'LIVE_EPG_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'أرشيف القنوات للأيام الماضية'+folderr2,'LIVE_TIMESHIFT_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('folder',menu_namee+'أرشيف برامج القنوات للأيام الماضية'+folderr2,'LIVE_ARCHIVED_GROUPED_SORTED',233,'','','','',folderr1)
		addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('link',menu_namee+'إضافة أو تغيير اشتراك'+folderr2,'',231,'','','','',folderr1)
	addMenuItem('link',menu_namee+'جلب ملفات'+folderr2,'',232,'','','','',folderr1)
	addMenuItem('link',menu_namee+'فحص اشتراك'+folderr2,'',236,'','','','',folderr1)
	addMenuItem('link',menu_namee+'عدد فيديوهات'+folderr2,'',281,'','','','',folderr1)
	addMenuItem('link',menu_namee+'مسح ملفات'+folderr2,'',237,'','','','',folderr1)
	addMenuItem('link',menu_namee+'استخدام السيرفر الأسرع'+folderr2,'',282,'','','','',folderr1)
	addMenuItem('link',menu_namee+'User-Agent تغيير'+folderr2,'',283,'','','','',folderr1)
	addMenuItem('link',menu_namee+'Referer تغيير'+folderr2,'',286,'','','','',folderr1)
	return

def CHECK_ACCOUNT(folderr,showDialogss=True):
	okk,statuss = False,''
	new_hostt,new_portt = '',''
	URL_playerr,URL_gett,serverr,usernamee,passwordd = GET_URL(folderr)
	if usernamee=='': return False,'',''
	headerss = GET_HEADERS(folderr)
	if URL_playerr:
		responsee = OPENURL_REQUESTS_CACHED(NO_CACHE,'GET',URL_playerr,'',headerss,False,'','IPTV-CHECK_ACCOUNT-1st')
		htmll = responsee.content
		if responsee.succeeded:
			timestampp,timedifff,time_noww,created_att,exp_datee = 0,0,'','',''
			try:
				dictt = EVAL('dict',htmll)
				statuss = dictt['user_info']['status']
				okk = True
				time_noww = dictt['server_info']['time_now']
			except: pass
			if time_noww:
				try:
					structt = time.strptime(time_noww,'%Y.%m.%d %H:%M:%S')
					timestampp = int(time.mktime(structt))
					timedifff = int(now-timestampp)
					timedifff = int((timedifff+900)/1800)*1800
				except: pass
				try:
					structt = time.localtime(int(dictt['user_info']['created_at']))
					created_att = time.strftime('%Y.%m.%d %H:%M:%S',structt)
				except: pass
				try:
					structt = time.localtime(int(dictt['user_info']['exp_date']))
					exp_datee = time.strftime('%Y.%m.%d %H:%M:%S',structt)
				except: pass
			settings.setSetting('av.iptv.timestamp_'+folderr,str(now))
			settings.setSetting('av.iptv.timediff_'+folderr,str(timedifff))
			try:
				server_infoo = '"server_info":'+htmll.split('"server_info":')[1]
				server_infoo = server_infoo.replace(':',': ').replace(',',', ').replace('}}','}')
				neww = re.findall('"url": "(.*?)", "port": "(.*?)"',server_infoo,re.DOTALL)
				new_hostt,new_portt = neww[0]
			except: okk = False
			if okk and showDialogss:
				max = dictt['user_info']['max_connections']
				activee = dictt['user_info']['active_cons']
				is_triall = dictt['user_info']['is_trial']
				partss = URL_playerr.split('?',1)
				messagee = 'URL:  [COLOR FFC89008]'+URL_playerr+'[/COLOR]'
				messagee += '\n\nStatus:  '+'[COLOR FFC89008]'+statuss+'[/COLOR]'
				messagee += '\nTrial:    '+'[COLOR FFC89008]'+str(is_triall=='1')+'[/COLOR]'
				messagee += '\nCreated  At:  '+'[COLOR FFC89008]'+created_att+'[/COLOR]'
				messagee += '\nExpiry Date:  '+'[COLOR FFC89008]'+exp_datee+'[/COLOR]'
				messagee += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+activee+' / '+max+'[/COLOR]'
				messagee += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(dictt['user_info']['allowed_output_formats'])+'[/COLOR]'
				messagee += '\n\n'+server_infoo
				if statuss=='Active': DIALOG_TEXTVIEWER('الاشتراك يعمل بدون مشاكل',messagee)
				else: DIALOG_TEXTVIEWER('يبدو أن هناك مشكلة في الاشتراك',messagee)
	if URL_playerr and okk and statuss=='Active':
		LOG_THIS('NOTICE','.  Checking IPTV URL   [ IPTV account is OK ]   [ '+URL_playerr+' ]')
		succeededd = True
	else:
		LOG_THIS('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+URL_playerr+' ]')
		if showDialogss: DIALOG_OK('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		succeededd = False
	return succeededd,new_hostt,new_portt

def ITEMS(folderr,TYPEe,GROUPp,PAGEe,showDialogss=True):
	if not PAGEe: PAGEe = '1'
	if not CHECK_TABLES_EXIST(folderr,showDialogss): return
	dbfilee = GET_DBFILE_NAME(folderr,TYPEe)
	streamss = READ_FROM_SQL3(dbfilee,'list',TYPEe,GROUPp)
	endd = int(PAGEe)*100
	startt = endd-100
	for contextt,titlee,urll,imgg in streamss[startt:endd]:
		condd1 = ('GROUPED' in TYPEe or TYPEe=='ALL')
		condd2 = ('GROUPED' not in TYPEe and TYPEe!='ALL')
		if condd1 or condd2:
			if   'ARCHIVED'  in TYPEe: menuItemsLIST.append(['folder',menu_namee+titlee,urll,238,imgg,'','ARCHIVED','',{'folder':folderr}])
			elif 'EPG' 		 in TYPEe: menuItemsLIST.append(['folder',menu_namee+titlee,urll,238,imgg,'','FULL_EPG','',{'folder':folderr}])
			elif 'TIMESHIFT' in TYPEe: menuItemsLIST.append(['folder',menu_namee+titlee,urll,238,imgg,'','TIMESHIFT','',{'folder':folderr}])
			elif 'LIVE' 	 in TYPEe: menuItemsLIST.append(['live',menu_namee+titlee,urll,235,imgg,'','',contextt,{'folder':folderr}])
			else: menuItemsLIST.append(['video',menu_namee+titlee,urll,235,imgg,'','','',{'folder':folderr}])
	totall = len(streamss)
	PAGINATION(folderr,PAGEe,TYPEe,234,totall,GROUPp)
	return
	
def SHOW_EMPTY(menu_namee2):
	addMenuItem('link',menu_namee2+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	addMenuItem('link',menu_namee2+'أو الخدمة غير موجودة في اشتراكك','',9999)
	addMenuItem('link',menu_namee2+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return

def GROUPS(folderr,TYPEe,GROUPp,PAGEe,websitee='',showDialogss=True):
	if not PAGEe: PAGEe = '1'
	menu_namee2 = menu_namee
	if not CHECK_TABLES_EXIST(folderr,showDialogss): return False
	if '__SERIES__' in GROUPp: MAINGROUPp,SUBGROUPp = GROUPp.split('__SERIES__')
	else: MAINGROUPp,SUBGROUPp = GROUPp,''
	dbfilee = GET_DBFILE_NAME(folderr,TYPEe)
	uniquegroupss = READ_FROM_SQL3(dbfilee,'list',TYPEe,'__GROUPS__')
	if not uniquegroupss: return False
	uniquee = []
	for groupp,imgg in uniquegroupss:
		if websitee:
			if '__SERIES__' in groupp: menu_namee2 = 'SERIES'
			elif '!!__UNKNOWN__!!' in groupp: menu_namee2 = 'UNKNOWN'
			elif 'LIVE' in TYPEe: menu_namee2 = 'LIVE'
			else: menu_namee2 = 'VIDEOS'
			menu_namee2 = ',[COLOR FFC89008]'+menu_namee2+': [/COLOR]'
		if '__SERIES__' in groupp: maingroupp,subgroupp = groupp.split('__SERIES__')
		else: maingroupp,subgroupp = groupp,''
		if not GROUPp:
			if maingroupp in uniquee: continue
			uniquee.append(maingroupp)
			if 'RANDOM' in websitee: addMenuItem('folder',menu_namee2+maingroupp,TYPEe,167,'','1',groupp,'',{'folder':folderr})
			elif '__SERIES__' in groupp: addMenuItem('folder',menu_namee2+maingroupp,TYPEe,233,'','1',groupp,'',{'folder':folderr})
			else: addMenuItem('folder',menu_namee2+maingroupp,TYPEe,234,'','1',groupp,'',{'folder':folderr})
		elif '__SERIES__' in groupp and maingroupp==MAINGROUPp:
			if subgroupp in uniquee: continue
			uniquee.append(subgroupp)
			if 'RANDOM' in websitee: addMenuItem('folder',menu_namee2+subgroupp,TYPEe,167,'','1',groupp,'',{'folder':folderr})
			else: addMenuItem('folder',menu_namee2+subgroupp,TYPEe,234,imgg,'1',groupp,'',{'folder':folderr})
	#if 'SORTED' in TYPEe:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda keyy: keyy[1].lower())
	if not websitee:
		endd = int(PAGEe)*100
		startt = endd-100
		totall = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[startt:endd]
		PAGINATION(folderr,PAGEe,TYPEe,233,totall,GROUPp)
	return True

def EPG_ITEMS(folderr,urll,functionn):
	if not CHECK_TABLES_EXIST(folderr,True): return
	headerss = GET_HEADERS(folderr)
	timestampp = settings.getSetting('av.iptv.timestamp_'+folderr)
	if not timestampp or now-int(timestampp)>24*HOUR:
		succeededd,new_hostt,new_portt = CHECK_ACCOUNT(folderr,False)
		if not succeededd: return
	timedifff = int(settings.getSetting('av.iptv.timediff_'+folderr))
	serverr = settings.getSetting('av.iptv.server_'+folderr)
	usernamee = settings.getSetting('av.iptv.username_'+folderr)
	passwordd = settings.getSetting('av.iptv.password_'+folderr)
	url_partss = urll.split('/')
	stream_idd = url_partss[-1].replace('.ts','').replace('.m3u8','')
	if functionn=='SHORT_EPG': url_actionn = 'get_short_epg'
	else: url_actionn = 'get_simple_data_table'
	URL_playerr,URL_gett,serverr,usernamee,passwordd = GET_URL(folderr)
	if not usernamee: return
	epg_urll = URL_playerr+'&action='+url_actionn+'&stream_id='+stream_idd
	htmll = OPENURL_CACHED(NO_CACHE,epg_urll,'',headerss,'','IPTV-EPG_ITEMS-2nd')
	archive_filess = EVAL('dict',htmll)
	all_epgg = archive_filess['epg_listings']
	epg_itemss = []
	if functionn in ['ARCHIVED','TIMESHIFT']:
		for dictt in all_epgg:
			if dictt['has_archive']==1:
				epg_itemss.append(dictt)
				if functionn in ['TIMESHIFT']: break
		if not epg_itemss: return
		addMenuItem('link',menu_namee+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if functionn in ['TIMESHIFT']:
			length_hourss = 2
			length_secss = length_hourss*HOUR
			epg_itemss = []
			initial_timestampp = int(int(dictt['start_timestamp'])/length_secss)*length_secss
			finish_timestampp = now+length_secss
			videos_countt = int((finish_timestampp-initial_timestampp)/HOUR)
			for countt in range(videos_countt):
				if countt>=6:
					if countt%length_hourss!=0: continue
					durationn = length_secss
				else: durationn = length_secss//2
				start_timestampp = initial_timestampp+countt*HOUR
				dictt = {}
				dictt['title'] = ''
				structt = time.localtime(start_timestampp-timedifff-HOUR)
				dictt['start'] = time.strftime('%Y.%m.%d %H:%M:%S',structt)
				dictt['start_timestamp'] = str(start_timestampp)
				dictt['stop_timestamp'] = str(start_timestampp+durationn)
				epg_itemss.append(dictt)
	elif functionn in ['SHORT_EPG','FULL_EPG']: epg_itemss = all_epgg
	if functionn=='FULL_EPG' and len(epg_itemss)>0:
		addMenuItem('link',menu_namee+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	epg_listt = []
	imgg = xbmc.getInfoLabel('ListItem.Icon')
	for dictt in epg_itemss:
		titlee = base64.b64decode(dictt['title'])
		if kodi_version>18.99: titlee = titlee.decode('utf8')
		start_timestampp = int(dictt['start_timestamp'])
		stop_timestampp = int(dictt['stop_timestamp'])
		duration_minutess = str(int((stop_timestampp-start_timestampp+59)/60))
		start_stringg = dictt['start'].replace(' ',':')
		structt = time.localtime(start_timestampp-HOUR)
		time_stringg = time.strftime('%H:%M',structt)
		english_daynamee = time.strftime('%a',structt)
		if functionn=='SHORT_EPG': titlee = '[COLOR FFFFFF00]'+time_stringg+' ـ '+titlee+'[/COLOR]'
		elif functionn=='TIMESHIFT': titlee = english_daynamee+' '+time_stringg+' ('+duration_minutess+'min)'
		else: titlee = english_daynamee+' '+time_stringg+' ('+duration_minutess+'min)   '+titlee+' ـ'
		if functionn in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			timeshift_urll = serverr+'/timeshift/'+usernamee+'/'+passwordd+'/'+duration_minutess+'/'+start_stringg+'/'+stream_idd+'.m3u8'
			if functionn=='FULL_EPG': addMenuItem('link',menu_namee+titlee,timeshift_urll,9999,imgg,'','','',{'folder':folderr})
			else: addMenuItem('video',menu_namee+titlee,timeshift_urll,235,imgg,'','','',{'folder':folderr})
		epg_listt.append(titlee)
	if functionn=='SHORT_EPG' and epg_listt: selectionn = DIALOG_CONTEXTMENU(epg_listt)
	return epg_listt

def USE_FASTER_SERVER(folderr):
	if not CHECK_TABLES_EXIST(folderr,True): return
	serverr,pingTime_newserverr,pingTime_orgserverr = '',0,0
	succeededd,new_hostt,new_portt = CHECK_ACCOUNT(folderr,False)
	if succeededd:
		new_host_ipp = DNS_RESOLVER(new_hostt)
		pingTime_newserverr = PING(new_host_ipp[0],int(new_portt))
		dbfilee = GET_DBFILE_NAME(folderr,'LIVE_GROUPED')
		groupss = READ_FROM_SQL3(dbfilee,'list','LIVE_GROUPED')
		streamss = READ_FROM_SQL3(dbfilee,'list','LIVE_GROUPED',groupss[1])
		urll = streamss[0][2]
		org_serverr = re.findall('://(.*?)/',urll,re.DOTALL)
		org_serverr = org_serverr[0]
		if ':' in org_serverr: org_hostt,org_portt = org_serverr.split(':')
		else: org_hostt,org_portt = org_serverr,'80'
		org_host_ipp = DNS_RESOLVER(org_hostt)
		pingTime_orgserverr = PING(org_host_ipp[0],int(org_portt))
	if pingTime_newserverr and pingTime_orgserverr:
		messagee = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		messagee += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(pingTime_orgserverr*1000))+' ملي ثانية'
		messagee += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(pingTime_newserverr*1000))+' ملي ثانية'
		yess = DIALOG_YESNO('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',messagee)
		if yess==1 and pingTime_newserverr<pingTime_orgserverr: serverr = new_hostt+':'+new_portt
	else: DIALOG_OK('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	settings.setSetting('av.iptv.server_'+folderr,serverr)
	return

def PLAY(folderr,urll,typee):
	useragentt = settings.getSetting('av.iptv.useragent_'+folderr)
	refererr = settings.getSetting('av.iptv.referer_'+folderr)
	if useragentt or refererr:
		urll += '|'
		if useragentt: urll += '&User-Agent='+useragentt
		if refererr: urll += '&Referer='+refererr
		urll = urll.replace('|&','|')
	new_serverr = settings.getSetting('av.iptv.server_'+folderr)
	if new_serverr:
		old_serverr = re.findall('://(.*?)/',urll,re.DOTALL)
		urll = urll.replace(old_serverr[0],new_serverr)
	PLAY_VIDEO(urll,script_namee,typee)
	return

def ADD_USERAGENT(folderr):
	DIALOG_OK('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	useragentt = settings.getSetting('av.iptv.useragent_'+folderr)
	answerr = DIALOG_YESNO('center','استخدام الأصلي','تعديل القديم',useragentt,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if answerr==1: useragentt = OPEN_KEYBOARD('أكتب ـIPTV User-Agent جديد',useragentt,True)
	else: useragentt = 'Unknown'
	if useragentt==' ':
		DIALOG_OK('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	answerr = DIALOG_YESNO('center','','',useragentt,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if answerr!=1:
		DIALOG_OK('','','رسالة من المبرمج','تم الإلغاء')
		return
	settings.setSetting('av.iptv.useragent_'+folderr,useragentt)
	DELETE_OLD_MENUS_CACHE(folderr)
	return

def ADD_REFERER(folderr):
	DIALOG_OK('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	refererr = settings.getSetting('av.iptv.referer_'+folderr)
	answerr = DIALOG_YESNO('center','استخدام الأصلي','تعديل القديم',refererr,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if answerr==1: refererr = OPEN_KEYBOARD('أكتب ـIPTV Referer جديد',refererr,True)
	else: refererr = ''
	if refererr==' ':
		DIALOG_OK('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	answerr = DIALOG_YESNO('center','','',refererr,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if answerr!=1:
		DIALOG_OK('','','رسالة من المبرمج','تم الإلغاء')
		return
	settings.setSetting('av.iptv.referer_'+folderr,refererr)
	DELETE_OLD_MENUS_CACHE(folderr)
	return

def GET_URL(folderr,iptvURLl=''):
	if not iptvURLl: iptvURLl = settings.getSetting('av.iptv.url_'+folderr)
	serverr = SERVER(iptvURLl,'url')
	usernamee = re.findall('username=(.*?)&',iptvURLl+'&',re.DOTALL)
	passwordd = re.findall('password=(.*?)&',iptvURLl+'&',re.DOTALL)
	if not usernamee or not passwordd:
		DIALOG_OK('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	usernamee = usernamee[0]
	passwordd = passwordd[0]
	URL_playerr = serverr+'/player_api.php?username='+usernamee+'&password='+passwordd
	URL_gett = serverr+'/get.php?username='+usernamee+'&password='+passwordd+'&type=m3u_plus'
	return URL_playerr,URL_gett,serverr,usernamee,passwordd

def GET_FILENAME(folderr,URLl=''):
	fullfilee = URLl.replace('/','_').replace(':','_').replace('.','_')
	fullfilee = fullfilee.replace('?','_').replace('=','_').replace('&','_')
	fullfilee = os.path.join(addoncachefolder,fullfilee).strip('.m3u')+'.m3u'
	return fullfilee

def ADD_ACCOUNT(folderr):
	old_URLl = settings.getSetting('av.iptv.url_'+folderr)
	getneww = True
	if old_URLl:
		answerr = DIALOG_THREEBUTTONS_TIMEOUT('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+old_URLl+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if answerr==-1: return
		elif answerr==0: old_URLl = ''
		elif answerr==2:
			answerr = DIALOG_YESNO('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if answerr in [-1,0]: return
			DIALOG_OK('','','رسالة من المبرمج','تم مسح الرابط')
			getneww = False
			new_URLl = ''
	if getneww:
		new_URLl = OPEN_KEYBOARD('اكتب رابط ـIPTV كاملا',old_URLl)
		new_URLl = new_URLl.strip(' ')
		if not new_URLl:
			answerr = DIALOG_YESNO('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if answerr in [-1,0]: return
			DIALOG_OK('','','رسالة من المبرمج','تم مسح الرابط')
	else:
		URL_playerr,URL_gett,serverr,usernamee,passwordd = GET_URL(folderr,new_URLl)
		if not usernamee: return
		messagee = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		messagee += '\n[COLOR FFFFFF00]'+serverr+'[/COLOR]عنوان السيرفر: '
		messagee += '\n[COLOR FFFFFF00]'+usernamee+'[/COLOR]اسم المستخدم: '
		messagee += '\n[COLOR FFFFFF00]'+passwordd+'[/COLOR]كلمة السر: '
		answerr = DIALOG_YESNO('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+new_URLl+'[/COLOR]'+'\n\n'+messagee)
		if answerr!=1:
			DIALOG_OK('','','رسالة من المبرمج','تم الإلغاء')
			return
	settings.setSetting('av.iptv.url_'+folderr,new_URLl)
	settings.setSetting('av.iptv.timestamp_'+folderr,'')
	settings.setSetting('av.iptv.timediff_'+folderr,'')
	useragentt = settings.getSetting('av.iptv.useragent_'+folderr)
	if not useragentt: settings.setSetting('av.iptv.useragent_'+folderr,'Unknown')
	#refererr = settings.getSetting('av.iptv.referer_'+folderr)
	#if not refererr: settings.setSetting('av.iptv.referer_'+folderr,'Unknown')
	yess1 = DIALOG_YESNO('center','','','',new_URLl+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if yess1==1: succeededd,new_hostt,new_portt = CHECK_ACCOUNT(folderr,True)
	#yess2 = DIALOG_YESNO('center','','','','هل تريد جلب ملفات جديدة الآن ؟')
	#if yess2: CREATE_STREAMS(folderr)
	DELETE_OLD_MENUS_CACHE(folderr)
	return

def READ_ALL_LINES(liness,live_epg_channelss,live_archived_channelss,pDialogg,lengthh,jjjj,URL_gett):
	streamss,ignored_streamss = [],[]
	vod_typess = ['.avi','.mp4','.mkv','.mp3','.webm']
	for linee in liness:
		if jjjj%473==0:
			PROGRESS_UPDATE(pDialogg,40+int(10*jjjj/lengthh),'قراءة الفيديوهات','الفيديو رقم:-',str(jjjj)+' / '+str(lengthh))
			if pDialogg.iscanceled():
				pDialogg.close()
				return None,None,None
		urll = re.findall('^(.*?)\n+((http|https|rtmp).*?)$',linee,re.DOTALL)
		if urll:
			linee,urll,dummyy = urll[0]
			urll = urll.replace('\n','')
			linee = linee.replace('\n','')
		else:
			ignored_streamss.append({'line':linee})
			continue
		dictt1,contextt,groupp,titlee,typee,is_vod_urll = {},'','','','',False
		try:
			linee,titlee = linee.rsplit('",',1)
			linee = linee+'"'
		except:
			try: linee,titlee = linee.rsplit('1,',1)
			except: titlee = ''
		dictt1['url'] = urll
		paramss = re.findall(' (.*?)="(.*?)"',linee,re.DOTALL)
		for keyy,valuee in paramss:
			keyy = keyy.replace('"','').strip(' ')
			dictt1[keyy] = valuee.strip(' ')
		keyss = list(dictt1.keys())
		if not titlee:
			if 'name' in keyss and dictt1['name']: titlee = dictt1['name']
		dictt1['title'] = titlee.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in keyss:
			dictt1['img'] = dictt1['logo']
			del dictt1['logo']
		else: dictt1['img'] = ''
		if 'group' in keyss and dictt1['group']: groupp = dictt1['group']
		if any(value in url.lower() for value in vod_types):
			is_vod_url = True if 'm3u' not in url else False
		if is_vod_urll or '__SERIES__' in groupp or '__MOVIES__' in groupp:
			typee = 'VOD'
			if '__SERIES__' in groupp: typee = typee+'_SERIES'
			elif '__MOVIES__' in groupp: typee = typee+'_MOVIES'
			else: typee = typee+'_UNKNOWN'
			groupp = groupp.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			typee = 'LIVE'
			if titlee in live_epg_channelss: contextt = contextt+'_EPG'
			if titlee in live_archived_channelss: contextt = contextt+'_ARCHIVED'
			if not groupp: typee = typee+'_UNKNOWN'
			else: typee = typee+contextt
		groupp = groupp.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in typee: groupp = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in typee: groupp = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in typee:
			series_titlee = re.findall('(.*?) [Ss]\d+ +[Ee]\d+',dictt1['title'],re.DOTALL)
			if series_titlee: series_titlee = series_titlee[0]
			else: series_titlee = '!!__UNKNOWN_SERIES__!!'
			groupp = groupp+'__SERIES__'+series_titlee
		if 'id' in keyss: del dictt1['id']
		if 'ID' in keyss: del dictt1['ID']
		if 'name' in keyss: del dictt1['name']
		titlee = dictt1['title']
		titlee = escapeUNICODE(titlee)
		titlee = CLEAN_NAME(titlee)
		languagee,groupp = SPLIT_NAME(groupp)
		countryy,titlee = SPLIT_NAME(titlee)
		dictt1['type'] = typee
		dictt1['context'] = contextt
		dictt1['group'] = groupp.upper()
		dictt1['title'] = titlee.upper()
		dictt1['country'] = countryy.upper()
		dictt1['language'] = languagee.upper()
		streamss.append(dictt1)
		jjjj += 1
	return streamss,jjjj,ignored_streamss

def CLEAN_NAME(titlee):
	titlee = titlee.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	titlee = titlee.replace('||','|').replace('___',':').replace('--','-')
	titlee = titlee.replace('[[','[').replace(']]',']')
	titlee = titlee.replace('((','(').replace('))',')')
	titlee = titlee.replace('<<','<').replace('>>','>')
	titlee = titlee.strip(' ')
	return titlee

def CREATE_GROUPED_STREAMS(streams_not_sortedd,pDialogg):
	grouped_streamss = {}
	for typee1 in UNIQUE_TYPESs: grouped_streamss[typee1] = []
	lengthh = len(streams_not_sortedd)
	textt3 = str(lengthh)
	jjjj = 0
	ignored_streamss = []
	for dictt1 in streams_not_sortedd:
		if jjjj%873==0:
			PROGRESS_UPDATE(pDialogg,50+int(5*jjjj/lengthh),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(jjjj)+' / '+textt3)
			if pDialogg.iscanceled():
				pDialogg.close()
				return None,None
		groupp,contextt,titlee,urll,imgg = dictt1['group'],dictt1['context'],dictt1['title'],dictt1['url'],dictt1['img']
		countryy,languagee,typee1 = dictt1['country'],dictt1['language'],dictt1['type']
		tuplee2 = (groupp,contextt,titlee,urll,imgg)
		faill = False
		if 'LIVE' in typee1:
			if 'UNKNOWN' in typee1: grouped_streamss['LIVE_UNKNOWN_GROUPED'].append(tuplee2)
			elif 'LIVE' in typee1: grouped_streamss['LIVE_GROUPED'].append(tuplee2)
			else: faill = True
			grouped_streamss['LIVE_ORIGINAL_GROUPED'].append(tuplee2)
		elif 'VOD' in typee1:
			if 'UNKNOWN' in typee1: grouped_streamss['VOD_UNKNOWN_GROUPED'].append(tuplee2)
			elif 'MOVIES' in typee1: grouped_streamss['VOD_MOVIES_GROUPED'].append(tuplee2)
			elif 'SERIES' in typee1: grouped_streamss['VOD_SERIES_GROUPED'].append(tuplee2)
			else: faill = True
			grouped_streamss['VOD_ORIGINAL_GROUPED'].append(tuplee2)
		else: faill = True
		if faill: ignored_streamss.append(dictt1)
		jjjj += 1
	streams_sortedd = sorted(streams_not_sortedd,reverse=False,key=lambda keyy: keyy['title'].lower())
	del streams_not_sortedd
	textt3 = str(lengthh)
	jjjj = 0
	for dictt1 in streams_sortedd:
		jjjj += 1
		if jjjj%873==0:
			PROGRESS_UPDATE(pDialogg,55+int(5*jjjj/lengthh),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(jjjj)+' / '+textt3)
			if pDialogg.iscanceled():
				pDialogg.close()
				return None,None
		typee1 = dictt1['type']
		groupp,contextt,titlee,urll,imgg = dictt1['group'],dictt1['context'],dictt1['title'],dictt1['url'],dictt1['img']
		countryy,languagee = dictt1['country'],dictt1['language']
		tuplee1 = (groupp,contextt+'_TIMESHIFT',titlee,urll,imgg)
		tuplee2 = (groupp,contextt,titlee,urll,imgg)
		tuplee3 = (countryy,contextt,titlee,urll,imgg)
		tuplee4 = (languagee,contextt,titlee,urll,imgg)
		if 'LIVE' in typee1:
			if 'UNKNOWN' in typee1: grouped_streamss['LIVE_UNKNOWN_GROUPED_SORTED'].append(tuplee2)
			else: grouped_streamss['LIVE_GROUPED_SORTED'].append(tuplee2)
			if 'EPG'		in typee1: grouped_streamss['LIVE_EPG_GROUPED_SORTED'].append(tuplee2)
			if 'ARCHIVED'	in typee1: grouped_streamss['LIVE_ARCHIVED_GROUPED_SORTED'].append(tuplee2)
			if 'ARCHIVED'	in typee1: grouped_streamss['LIVE_TIMESHIFT_GROUPED_SORTED'].append(tuplee1)
			grouped_streamss['LIVE_FROM_NAME_SORTED'].append(tuplee3)
			grouped_streamss['LIVE_FROM_GROUP_SORTED'].append(tuplee4)
		elif 'VOD' in typee1:
			if   'UNKNOWN'	in typee1: grouped_streamss['VOD_UNKNOWN_GROUPED_SORTED'].append(tuplee2)
			elif 'MOVIES'	in typee1: grouped_streamss['VOD_MOVIES_GROUPED_SORTED'].append(tuplee2)
			elif 'SERIES'	in typee1: grouped_streamss['VOD_SERIES_GROUPED_SORTED'].append(tuplee2)
			grouped_streamss['VOD_FROM_NAME_SORTED'].append(tuplee3)
			grouped_streamss['VOD_FROM_GROUP_SORTED'].append(tuplee4)
	return grouped_streamss,ignored_streamss

def SPLIT_NAME(titlee):
	if len(titlee)<3: return titlee,titlee
	langg,sepp = '',''
	titlee2 = titlee
	firstt = titlee[:1]
	restt = titlee[1:]
	if   firstt=='(': sepp = ')'
	elif firstt=='[': sepp = ']'
	elif firstt=='<': sepp = '>'
	elif firstt=='|': sepp = '|'
	if sepp and (sepp in restt):
		partt1,partt2 = restt.split(sepp,1)
		langg = partt1
		titlee2 = firstt+partt1+sepp+' '+partt2
	elif titlee.count('|')>=2:
		partt1,partt2 = titlee.split('|',1)
		langg = partt1
		titlee2 = partt1+' |'+partt2
	else:
		sepp = re.findall('^\w{2}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',titlee,re.DOTALL)
		if not sepp: sepp = re.findall('^\w{3}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',titlee,re.DOTALL)
		if not sepp: sepp = re.findall('^\w{4}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',titlee,re.DOTALL)
		if sepp:
			partt1,partt2 = titlee.split(sepp[0],1)
			langg = partt1
			titlee2 = partt1+' '+sepp[0]+' '+partt2
	titlee2 = titlee2.replace('   ',' ').replace('  ',' ')
	langg = langg.replace('  ',' ')
	if not langg: langg = '!!__UNKNOWN__!!'
	langg = langg.strip(' ')
	titlee2 = titlee2.strip(' ')
	return langg,titlee2

def GET_HEADERS(folderr):
	headerss = {}
	useragentt = settings.getSetting('av.iptv.useragent_'+folderr)
	if useragentt: headerss['User-Agent'] = useragentt
	refererr = settings.getSetting('av.iptv.referer_'+folderr)
	if refererr: headerss['Referer'] = refererr
	return headerss

def CREATE_STREAMS(folderr):
	global pDialogg,grouped_streamss,total_saved_countt,finalstreamss,menus_countss,groupss,total_menus_countt,kkkk,types_countt
	#URL_gett = settings.getSetting('av.iptv.url_'+folderr+'_'+sequencee)
	URL_playerr,URL_gett,serverr,usernamee,passwordd = GET_URL(folderr)
	if not usernamee: return
	headerss = GET_HEADERS(folderr)
	yess = DIALOG_YESNO('center','','','رسالة من المبرمج','عملية جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if yess!=1: return
	fullfilee = fulliptvfile.replace('___','_'+folderr)
	if 1:
		succeededd,new_hostt,new_portt = CHECK_ACCOUNT(folderr,False)
		if not succeededd:
			DIALOG_OK('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not URL_gett: LOG_THIS('ERROR_LINES',LOGGING(script_namee)+'   No IPTV URL found to download IPTV files')
			else: LOG_THIS('ERROR_LINES',LOGGING(script_namee)+'   Failed to download IPTV files')
			return
		m3u_textt = DOWNLOAD_USING_PROGRESSBAR(URL_gett,headerss,True)
		if not m3u_textt: return
		open(fullfilee,'wb').write(m3u_textt)
	else: m3u_textt = open(fullfilee,'rb').read()
	if kodi_version>18.99 and m3u_textt: m3u_textt = m3u_textt.decode('utf8')
	#m3u_textt = m3u_textt[501000:502000]
	pDialogg = DIALOG_PROGRESS()
	pDialogg.create('جلب ملفات ـIPTV جديدة','')
	PROGRESS_UPDATE(pDialogg,15,'تنظيف الملف الرئيسي','')
	m3u_textt = m3u_textt.replace('"tvg-','" tvg-')
	m3u_textt = m3u_textt.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	m3u_textt = m3u_textt.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	m3u_textt = m3u_textt.replace('group-title=','group=').replace('tvg-','')
	live_archived_channelss,live_epg_channelss = [],[]
	PROGRESS_UPDATE(pDialogg,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if pDialogg.iscanceled():
		pDialogg.close()
		return
	urll = URL_playerr+'&action=get_series_categories'
	responsee = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,'GET',urll,'',headerss,'','','IPTV-CREATE_STREAMS-1st')
	htmll = responsee.content
	htmll = escapeUNICODE(htmll)
	series_groupss = re.findall('category_name":"(.*?)"',htmll,re.DOTALL)
	del htmll
	for groupp in series_groupss:
		groupp = groupp.replace('\/','/')
		if kodi_version<19: groupp = groupp.decode('utf8').encode('utf8')
		m3u_textt = m3u_textt.replace('group="'+groupp+'"','group="__SERIES__'+groupp+'"')
	del series_groupss
	PROGRESS_UPDATE(pDialogg,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if pDialogg.iscanceled():
		pDialogg.close()
		return
	urll = URL_playerr+'&action=get_vod_categories'
	responsee = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,'GET',urll,'',headerss,'','','IPTV-CREATE_STREAMS-2nd')
	htmll = responsee.content
	htmll = escapeUNICODE(htmll)
	vod_groupss = re.findall('category_name":"(.*?)"',htmll,re.DOTALL)
	del htmll
	for groupp in vod_groupss:
		groupp = groupp.replace('\/','/')
		if kodi_version<19: groupp = groupp.decode('utf8').encode('utf8')
		m3u_textt = m3u_textt.replace('group="'+groupp+'"','group="__MOVIES__'+groupp+'"')
	del vod_groupss
	PROGRESS_UPDATE(pDialogg,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if pDialogg.iscanceled():
		pDialogg.close()
		return
	urll = URL_playerr+'&action=get_live_streams'
	responsee = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,'GET',urll,'',headerss,'','','IPTV-CREATE_STREAMS-3rd')
	htmll = responsee.content
	htmll = escapeUNICODE(htmll)
	live_archivedd = re.findall('"name":"(.*?)".*?"tv_archive":(.*?),',htmll,re.DOTALL)
	for namee,archivedd in live_archivedd:
		if archivedd=='1': live_archived_channelss.append(namee)
	del live_archivedd
	live_epgg = re.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',htmll,re.DOTALL)
	del htmll
	for namee,epgg in live_epgg:
		if epgg!='null': live_epg_channelss.append(namee)
	del live_epgg
	m3u_textt = m3u_textt.replace('\r','\n')
	liness = re.findall('NF:(.+?)#EXTI',m3u_textt+'\n+#EXTINF:',re.DOTALL)
	if not liness:
		LOG_THIS('ERROR_LINES',LOGGING(script_namee)+'   Folder:'+folderr+'   No video links found in IPTV file')
		DIALOG_OK('','','رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+folderr)
		pDialogg.close()
		return
	liness1 = []
	for linee in liness:
		line_lowerr = linee.lower()
		if 'adult' in line_lowerr: continue
		if 'xxx' in line_lowerr: continue
		liness1.append(linee)
	liness = liness1
	del liness1
	MegaBytee = 1024*1024
	splits_countt = 1+len(m3u_textt)//MegaBytee//10
	del m3u_textt
	m3u_streams_countt = len(liness)
	liness2 = SPLIT_BIGLIST(liness,splits_countt)
	del liness
	for iiii in range(splits_countt):
		PROGRESS_UPDATE(pDialogg,35+int(5*iiii/splits_countt),'تقطيع الملف الرئيسي','الجزء رقم:-',str(iiii+1)+' / '+str(splits_countt))
		if pDialogg.iscanceled():
			pDialogg.close()
			return
		lines_textt = str(liness2[iiii])
		if kodi_version>18.99: lines_textt = lines_textt.encode('utf8')
		open(fullfilee+'.00'+str(iiii),'wb').write(lines_textt)
	del liness2,lines_textt
	all_ignored_streamss,streams_not_sortedd,jjjj = [],[],0
	for iiii in range(splits_countt):
		if pDialogg.iscanceled():
			pDialogg.close()
			return
		lines_textt = open(fullfilee+'.00'+str(iiii),'rb').read()
		time.sleep(1)
		try: os.remove(fullfilee+'.00'+str(iiii))
		except: pass
		if kodi_version>18.99: lines_textt = lines_textt.decode('utf8')
		liness3 = EVAL('list',lines_textt)
		del lines_textt
		streamss,jjjj,ignored_streamss = READ_ALL_LINES(liness3,live_epg_channelss,live_archived_channelss,pDialogg,m3u_streams_countt,jjjj,URL_gett)
		if pDialogg.iscanceled():
			pDialogg.close()
			return
		if not streamss:
			pDialogg.close()
			return
		streams_not_sortedd += streamss
		all_ignored_streamss += ignored_streamss
	del liness3,streamss
	grouped_streamss,ignored_streamss = CREATE_GROUPED_STREAMS(streams_not_sortedd,pDialogg)
	if pDialogg.iscanceled():
		pDialogg.close()
		return
	all_ignored_streamss += ignored_streamss
	del streams_not_sortedd,ignored_streamss
	finalstreamss,menus_countss,groupss,total_menus_countt,kkkk = {},{},{},0,0
	NOT_EMPTY_TYPESs = list(grouped_streamss.keys())
	types_countt = len(NOT_EMPTY_TYPESs)*3
	import threading
	if 1:
		threadss = {}
		for TYPEe in NOT_EMPTY_TYPESs:
			threadss[TYPEe] = threading.Thread(target=CREATE_MENUS,args=(TYPEe,))
			threadss[TYPEe].start()
		for TYPEe in NOT_EMPTY_TYPESs:
			threadss[TYPEe].join()
		if pDialogg.iscanceled():
			pDialogg.close()
			return
	else:
		for TYPEe in NOT_EMPTY_TYPESs:
			CREATE_MENUS(TYPEe)
			if pDialogg.iscanceled():
				pDialogg.close()
				return
	DELETE_FILES(folderr,False)
	NOT_EMPTY_TYPESs = list(finalstreamss.keys())
	total_saved_countt = 0
	if 1:
		threadss = {}
		for TYPEe in NOT_EMPTY_TYPESs:
			threadss[TYPEe] = threading.Thread(target=SAVE_MENUS,args=(folderr,TYPEe))
			threadss[TYPEe].start()
		for TYPEe in NOT_EMPTY_TYPESs:
			threadss[TYPEe].join()
		if pDialogg.iscanceled():
			pDialogg.close()
			return
	else:
		for TYPEe in NOT_EMPTY_TYPESs:
			SAVE_MENUS(folderr,TYPEe)
			if pDialogg.iscanceled():
				pDialogg.close()
				return
	iiii = 0
	ignoredCountt = len(all_ignored_streamss)
	dbfilee = GET_DBFILE_NAME(folderr,'IGNORED')
	for streamm in all_ignored_streamss:
		if iiii%27==0:
			PROGRESS_UPDATE(pDialogg,95+int(5*iiii//ignoredCountt),'تخزين المهملة','الفيديو رقم:-',str(iiii)+' / '+str(ignoredCountt))
			if pDialogg.iscanceled():
				pDialogg.close()
				return
		WRITE_TO_SQL3(dbfilee,'IGNORED',str(streamm),'',PERMANENT_CACHE)
		iiii += 1
	WRITE_TO_SQL3(dbfilee,'IGNORED','__COUNT__',str(ignoredCountt),PERMANENT_CACHE)
	WRITE_TO_SQL3(dbfilee,'DUMMY','__DUMMY__','1',PERMANENT_CACHE)
	#open(dummyiptvfile,'w').write('')
	pDialogg.close()
	time.sleep(1)
	countsMessagee = COUNTS(folderr,False)
	DIALOG_OK('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+countsMessagee)
	xbmc.executebuiltin('Container.Refresh')
	DELETE_OLD_MENUS_CACHE(folderr)
	return

def CREATE_MENUS(TYPEe):
	global pDialogg,grouped_streamss,total_saved_countt,finalstreamss,menus_countss,groupss,total_menus_countt,kkkk,types_countt
	finalstreamss[TYPEe] = {}
	unique_tupless,groups_tupless = {},[]
	streams_type_countt = len(grouped_streamss[TYPEe])
	finalstreamss[TYPEe]['__COUNT__'] = streams_type_countt
	if streams_type_countt>0:
		grouplistt,contextlistt,titlelistt,urllistt,imglistt = zip(*grouped_streamss[TYPEe])
		del contextlistt,titlelistt,urllistt
		groups_listt = list(set(grouplistt))
		for groupp in groups_listt:
			unique_tupless[groupp] = ''
			finalstreamss[TYPEe][groupp] = []
		PROGRESS_UPDATE(pDialogg,60+int(15*kkkk//types_countt),'تصنيع القوائم','الجزء رقم:-',str(kkkk)+' / '+str(types_countt))
		if pDialogg.iscanceled(): return
		kkkk += 1
		groups_countt = len(groups_listt)
		del groups_listt
		groups_tupless = list(set(zip(grouplistt,imglistt)))
		del grouplistt,imglistt
		for groupp,imagee in groups_tupless:
			if not unique_tupless[groupp] and imagee: unique_tupless[groupp] = imagee
		PROGRESS_UPDATE(pDialogg,60+int(15*kkkk//types_countt),'تصنيع القوائم','الجزء رقم:-',str(kkkk)+' / '+str(types_countt))
		if pDialogg.iscanceled(): return
		kkkk += 1
		grouplistt2 = list(unique_tupless.keys())
		imglistt2 = list(unique_tupless.values())
		del unique_tupless
		groups_tupless = list(zip(grouplistt2,imglistt2))
		del grouplistt2,imglistt2
		groups_tupless = sorted(groups_tupless)
	else: kkkk += 2
	finalstreamss[TYPEe]['__GROUPS__'] = groups_tupless
	del groups_tupless
	for groupp,contextt,titlee,urll,imgg in grouped_streamss[TYPEe]:
		finalstreamss[TYPEe][groupp].append((contextt,titlee,urll,imgg))
	PROGRESS_UPDATE(pDialogg,60+int(15*kkkk//types_countt),'تصنيع القوائم','الجزء رقم:-',str(kkkk)+' / '+str(types_countt))
	if pDialogg.iscanceled(): return
	kkkk += 1
	del grouped_streamss[TYPEe]
	groupss[TYPEe] = list(finalstreamss[TYPEe].keys())
	menus_countss[TYPEe] = len(groupss[TYPEe])
	total_menus_countt += menus_countss[TYPEe]
	return

def SAVE_MENUS(folderr,TYPEe):
	global pDialogg,grouped_streamss,total_saved_countt,finalstreamss,menus_countss,groupss,total_menus_countt,kkkk,types_countt
	dbfilee = GET_DBFILE_NAME(folderr,TYPEe)
	for jjjj in range(1+menus_countss[TYPEe]//273):
		data_listt = []
		groups_chunkk = groupss[TYPEe][0:273]
		for groupp in groups_chunkk:
			data_listt.append(finalstreamss[TYPEe][groupp])
		WRITE_TO_SQL3(dbfilee,TYPEe,groups_chunkk,data_listt,PERMANENT_CACHE,True)
		total_saved_countt += len(groups_chunkk)
		PROGRESS_UPDATE(pDialogg,75+int(20*total_saved_countt//total_menus_countt),'تخزين القوائم','القائمة رقم:-',str(total_saved_countt)+' / '+str(total_menus_countt))
		if pDialogg.iscanceled(): return
		del groupss[TYPEe][0:273]
	del finalstreamss[TYPEe],groupss[TYPEe],menus_countss[TYPEe]
	return

def COUNTS(folderr,showDialogss=True):
	if not CHECK_TABLES_EXIST(folderr,showDialogss): return
	header_messagee = 'رسالة من المبرمج'
	dbfilee1 = GET_DBFILE_NAME(folderr,'LIVE_ORIGINAL_GROUPED')
	dbfilee2 = GET_DBFILE_NAME(folderr,'VOD_ORIGINAL_GROUPED')
	ignoredCountt = READ_FROM_SQL3(dbfilee1,'int','IGNORED','__COUNT__')
	originalLIVEcountt = READ_FROM_SQL3(dbfilee1,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	originalVODcountt = READ_FROM_SQL3(dbfilee2,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	knownLIVEcountt = READ_FROM_SQL3(dbfilee1,'int','LIVE_GROUPED','__COUNT__')
	unknownLIVEcountt = READ_FROM_SQL3(dbfilee1,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	moviesVODcountt = READ_FROM_SQL3(dbfilee1,'int','VOD_MOVIES_GROUPED','__COUNT__')
	episodesVODcountt = READ_FROM_SQL3(dbfilee2,'int','VOD_SERIES_GROUPED','__COUNT__')
	unknownVODcountt = READ_FROM_SQL3(dbfilee1,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	groupss = READ_FROM_SQL3(dbfilee2,'list','VOD_SERIES_GROUPED','__GROUPS__')
	seriesLISTt = []
	for groupp,imgg in groupss:
		seriesNamee = groupp.split('__SERIES__')[1]
		seriesLISTt.append(seriesNamee)
	seriesVODcountt = len(seriesLISTt)
	totall = int(moviesVODcountt)+int(episodesVODcountt)+int(unknownVODcountt)+int(unknownLIVEcountt)+int(knownLIVEcountt)
	countsMessagee = ''
	countsMessagee += 'قنوات: '+str(knownLIVEcountt)
	countsMessagee += '   .   أفلام: '+str(moviesVODcountt)
	countsMessagee += '\nمسلسلات: '+str(seriesVODcountt)
	countsMessagee += '   .   حلقات: '+str(episodesVODcountt)
	countsMessagee += '\nقنوات مجهولة: '+str(unknownLIVEcountt)
	countsMessagee += '   .   فيدوهات مجهولة: '+str(unknownVODcountt)
	countsMessagee += '\nمجموع القنوات: '+str(originalLIVEcountt)
	countsMessagee += '   .   مجموع الفيديوهات: '+str(originalVODcountt)
	countsMessagee += '\n\nمجموع المضافة: '+str(totall)
	countsMessagee += '   .   مجموع المهملة: '+str(ignoredCountt)
	if showDialogss: DIALOG_OK('center','',header_messagee,countsMessagee)
	logMssagee = countsMessagee.replace('\n\n','\n')
	LOG_THIS('NOTICE','.  Counts of IPTV videos   Folder: '+folderr+'\n'+logMssagee)
	return countsMessagee

def DELETE_FILES(folderr,showDialogss=True):
	if showDialogss:
		yess = DIALOG_YESNO('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if yess!=1: return
		filee = fulliptvfile.replace('___','_'+folderr)
		try: os.remove(filee)
		except: pass
	filee = iptv1_dbfile.replace('___','_'+folderr)
	try: os.remove(filee)
	except: pass
	filee = iptv2_dbfile.replace('___','_'+folderr)
	try: os.remove(filee)
	except: pass
	DELETE_FROM_SQL3(main_dbfile,'SECTIONS_IPTV','SECTIONS_IPTV_'+folderr)
	DELETE_FROM_SQL3(main_dbfile,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	FIX_ALL_DATABASES(False)
	DELETE_OLD_MENUS_CACHE(folderr)
	if showDialogss:
		DIALOG_OK('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		xbmc.executebuiltin('Container.Refresh')
	return

def CHECK_TABLES_EXIST(folderr='',showDialogss=True):
	if folderr:
		dbfilee = GET_DBFILE_NAME(str(folderr),'DUMMY')
		dummyy = READ_FROM_SQL3(dbfilee,'str','DUMMY','__DUMMY__')
		if dummyy: return True
	else:
		folderr = '1'
		for folderr2 in range(1,FOLDERS_COUNT+1):
			dbfilee = GET_DBFILE_NAME(str(folderr2),'DUMMY')
			dummyy = READ_FROM_SQL3(dbfilee,'str','DUMMY','__DUMMY__')
			if dummyy: return True
	if showDialogss:
		DIALOG_OK('','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		header_messagee = 'إضافة وتغيير رابط '+text_numbers[1]+' (مجلد '+text_numbers[int(folderr)]+')'
		yess = DIALOG_YESNO('','','',header_messagee,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if yess==1: ADD_ACCOUNT(folderr)
		else: MENU(folderr,False)
	#SHOW_EMPTY(menu_namee)
	return False

def SEARCH(search_orgg,folderr='',TYPEe='',PAGEe=''):
	if not PAGEe: PAGEe = '1'
	searchh,optionss,showDialogss = SEARCH_OPTIONS(search_orgg)
	if not CHECK_TABLES_EXIST(folderr,showDialogss): return
	if not searchh:
		searchh = OPEN_KEYBOARD()
		if not searchh: return
	typeListt = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not TYPEe:
		if not showDialogss:
			if   '_IPTV-LIVE_' in optionss: TYPEe = typeListt[1]
			elif '_IPTV-MOVIES' in optionss: TYPEe = typeListt[2]
			elif '_IPTV-SERIES' in optionss: TYPEe = typeListt[3]
			else: TYPEe = typeListt[0]
		else:
			searchTitlee = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			choicee = DIALOG_SELECT('أختر البحث المناسب', searchTitlee)
			if choicee==-1: return
			TYPEe = typeListt[choicee]
	searchh = searchh+'_NODIALOGS_'
	if folderr: SEARCH_ONE_FOLDER(searchh,folderr,TYPEe,PAGEe)
	else:
		for folderr in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(searchh,str(folderr),TYPEe,PAGEe)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda keyy: keyy[1].lower())
	return

def SEARCH_ONE_FOLDER(search_orgg,folderr,TYPEe='',PAGEe=''):
	if not PAGEe: PAGEe = '1'
	searchh,optionss,showDialogss = SEARCH_OPTIONS(search_orgg)
	if not folderr: return
	if not CHECK_TABLES_EXIST(folderr,showDialogss): return
	if not searchh:
		searchh = OPEN_KEYBOARD()
		if not searchh: return
	typeListt = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not TYPEe:
		if not showDialogss:
			if   '_IPTV-LIVE_' in optionss: TYPEe = typeListt[1]
			elif '_IPTV-MOVIES' in optionss: TYPEe = typeListt[2]
			elif '_IPTV-SERIES' in optionss: TYPEe = typeListt[3]
			else: TYPEe = typeListt[0]
		else:
			searchTitlee = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			choicee = DIALOG_SELECT('أختر البحث المناسب', searchTitlee)
			if choicee==-1: return
			TYPEe = typeListt[choicee]
	searchLowerr = searchh.lower()
	dbfilee = GET_DBFILE_NAME(folderr,'SEARCH')
	resultss = READ_FROM_SQL3(dbfilee,'list','SEARCH',(TYPEe,searchLowerr))
	if not resultss:
		allgroupss,alltitless = [],[]
		if not TYPEe: choicess = [1,2,3,4,5]
		else: choicess = [typeListt.index(TYPEe)]
		for iiii in choicess:
			dbfilee = GET_DBFILE_NAME(folderr,typeListt[iiii])
			if iiii!=3:
				streamss = READ_FROM_SQL3(dbfilee,'dict',typeListt[iiii])
				del streamss['__COUNT__']
				del streamss['__GROUPS__']
				del streamss['__SEQUENCED_COLUMNS__']
				groupss = list(streamss.keys())
				for groupp in groupss:
					for contextt,titlee,urll,imgg in streamss[groupp]:
						if searchLowerr in titlee.lower(): alltitless.append((titlee,urll,imgg))
					del streamss[groupp]
				del streamss
			else: groupss = READ_FROM_SQL3(dbfilee,'list',typeListt[iiii],'__GROUPS__')
			for groupp in groupss:
				try: groupp,imgg = groupp
				except: imgg = ''
				if searchLowerr in groupp.lower():
					if iiii!=3: groupp2 = groupp
					else:
						maingroupp,subgroupp = groupp.split('__SERIES__')
						if searchLowerr in maingroupp.lower(): groupp2 = maingroupp
						else: groupp2 = subgroupp
					allgroupss.append((groupp,groupp2,typeListt[iiii],imgg))
			del groupss
		allgroupss = set(allgroupss)
		alltitless = set(alltitless)
		allgroupss = sorted(allgroupss,reverse=False,key=lambda keyy: keyy[1])
		alltitless = sorted(alltitless,reverse=False,key=lambda keyy: keyy[0])
		WRITE_TO_SQL3(dbfilee,'SEARCH',(TYPEe,searchLowerr),(allgroupss,alltitless),PERMANENT_CACHE)
	else: allgroupss,alltitless = resultss
	groupss = len(allgroupss)
	titless = len(alltitless)
	pagee = int(PAGEe) 
	ssss1 = max(0,(pagee-1)*100)
	eeee1 = max(0,pagee*100)
	ssss2 = max(0,ssss1-groupss)
	eeee2 = max(0,eeee1-groupss)
	for groupp,groupp2,TYPEe2,imgg in allgroupss[ssss1:eeee1]:
		addMenuItem('folder',menu_namee+groupp2,TYPEe2,234,imgg,'1',groupp,'',{'folder':folderr})
	del allgroupss
	for titlee,urll,imgg in alltitless[ssss2:eeee2]:
		videofilee = urll.split('/')[-1]
		if '.' in videofilee and '.m3u8' not in videofilee: addMenuItem('video',menu_namee+titlee,urll,235,imgg,'','','',{'folder':folderr})
		else: addMenuItem('live',menu_namee+titlee,urll,235,imgg,'','','',{'folder':folderr})
	del alltitless
	PAGINATION(folderr,PAGEe,TYPEe,239,groupss+titless,searchh+'_NODIALOGS_')
	return

def PAGINATION(folderr,PAGEe,TYPEe,modee,totall,textt):
	if PAGEe!='1': addMenuItem('folder',menu_namee+'صفحة '+str(1),TYPEe,modee,'',str(1),textt,'',{'folder':folderr})
	if not totall: totall = 0
	pagess = int(totall/100)+1
	for pagee in range(2,pagess):
		condd1 = (pagee%10==0 or int(PAGEe)-4<pagee<int(PAGEe)+4)
		condd2 = (condd1 and int(PAGEe)-40<pagee<int(PAGEe)+40)
		if str(pagee)!=PAGEe and (pagee%100==0 or condd2):
			addMenuItem('folder',menu_namee+'صفحة '+str(pagee),TYPEe,modee,'',str(pagee),textt,'',{'folder':folderr})
	if str(pagess)!=PAGEe: addMenuItem('folder',menu_namee+'أخر صفحة '+str(pagess),TYPEe,modee,'',str(pagess),textt,'',{'folder':folderr})
	return

def GET_DBFILE_NAME(folderr,TYPEe):
	if 'SERIES' in TYPEe or 'VOD_ORIGINAL' in TYPEe: dbfilee = iptv2_dbfile
	else: dbfilee = iptv1_dbfile
	dbfilee = dbfilee.replace('___','_'+folderr)
	return dbfilee

def XTREAM_MENUS(folderr,TYPEe,GROUPp):
	# https://www.worldofiptv.com/threads/collection-for-xtream-codes-panel-commands.986/post-11878
	# https://blog.csdn.net/qq_31199395/article/details/121198301
	URL_playerr,URL_gett,serverr,usernamee,passwordd = GET_URL(folderr)
	if not usernamee: return
	headerss = GET_HEADERS(folderr)
	if   TYPEe=='XTREAM_LIVE_GROUPS': urll = URL_playerr+'&action=get_live_categories'
	elif TYPEe=='XTREAM_VOD_GROUPS': urll = URL_playerr+'&action=get_vod_categories'
	elif TYPEe=='XTREAM_SERIES_GROUPS': urll = URL_playerr+'&action=get_series_categories'
	elif TYPEe=='XTREAM_LIVE_ITEMS': urll = URL_playerr+'&action=get_live_streams&category_id='+GROUPp
	elif TYPEe=='XTREAM_VOD_ITEMS': urll = URL_playerr+'&action=get_vod_streams&category_id='+GROUPp
	elif TYPEe=='XTREAM_SERIES_ITEMS': urll = URL_playerr+'&action=get_series&category_id='+GROUPp
	elif TYPEe=='XTREAM_EPISODES': urll = URL_playerr+'&action=get_series_info&series_id='+GROUPp
	#elif TYPEe=='XTREAM_PLAY': urll = URL_playerr+'&action=get_vod_info&vod_id='+GROUPp
	else: return
	responsee = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,'GET',urll,'',headerss,'','','IPTV-XTREAM_MENUS-1st')
	htmll = responsee.content
	if kodi_version<19: htmll = htmll.decode('utf8').encode('utf8')
	#import json
	#jsonn = json.loads(htmll)
	jsonn = EVAL('list',htmll)
	if 'GROUPS' in TYPEe:
		TYPEe = TYPEe.replace('_GROUPS','_ITEMS')
		jsonn = sorted(jsonn,reverse=False,key=lambda keyy: keyy['category_name'].lower())
		for groupp in jsonn:
			idd = groupp['category_id']
			titlee = groupp['category_name']
			addMenuItem('folder',menu_namee+titlee,TYPEe,285,'','',str(idd),'',{'folder':folderr})
	elif TYPEe=='XTREAM_SERIES_ITEMS':
		jsonn = sorted(jsonn,reverse=False,key=lambda keyy: keyy['name'].lower())
		for seriess in jsonn:
			titlee = seriess['name']
			imagee = seriess['cover']
			idd = seriess['series_id']
			addMenuItem('folder',menu_namee+titlee,'XTREAM_EPISODES',285,imagee,'',str(idd),'',{'folder':folderr})
	elif TYPEe=='XTREAM_EPISODES':
		imagee = jsonn['info']['cover']
		namee = jsonn['info']['name']
		seasonss = jsonn['episodes']
		for seasonn in seasonss:
			episodess = seasonss[seasonn]
			#episodess = sorted(episodess,reverse=False,key=lambda keyy: keyy['title'].lower())
			for episodee in episodess:
				titlee = episodee['title']
				tmpp = re.findall('\d+.(S\d+E\d+)',titlee,re.DOTALL)
				if tmpp: titlee = namee+' '+tmpp[0]
				idd = episodee['id']
				extensionn = episodee['container_extension']
				urll = URL_playerr.split('/player_api.php')[0]+'/series/'+usernamee+'/'+passwordd+'/'+str(idd)+'.'+extensionn
				addMenuItem('video',menu_namee+titlee,urll,235,imagee,'','','',{'folder':folderr})
	elif 'ITEMS' in TYPEe:
		typee = 'live' if 'LIVE' in TYPEe else 'video'
		jsonn = sorted(jsonn,reverse=False,key=lambda keyy: keyy['name'].lower())
		for videoo in jsonn:
			titlee = videoo['name']
			imagee = videoo['stream_icon']
			idd = videoo['stream_id']
			try:
				extensionn = videoo['container_extension']
				if extensionn: extensionn = '.'+extensionn
			except: extensionn = ''
			if videoo['stream_type']=='live': typee1,typee2 = '','live'
			elif videoo['stream_type']=='movie': typee1,typee2 = 'movie/','video'
			urll = URL_playerr.split('/player_api.php')[0]+'/'+typee1+usernamee+'/'+passwordd+'/'+str(idd)+extensionn
			addMenuItem(typee,menu_namee+titlee,urll,235,imagee,'','','',{'folder':folderr})
	return

def DELETE_OLD_MENUS_CACHE(folderr):
	trans_providerr = settings.getSetting('av.language.provider')
	trans_codee = settings.getSetting('av.language.code')
	DELETE_FROM_SQL3(main_dbfile,'MENUS_CACHE_'+trans_providerr+'_'+trans_codee,'%_IP'+folderr+'_%')
	return


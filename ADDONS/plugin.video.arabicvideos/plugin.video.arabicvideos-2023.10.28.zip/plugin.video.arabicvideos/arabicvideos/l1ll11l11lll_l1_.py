# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠭䉿")
l11ll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ䊀")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11lll_l1_ (u"ࠨ࠲ࠪ䊁"),True)
	elif mode==102: results = ITEMS(l11lll_l1_ (u"ࠩ࠴ࠫ䊂"),True)
	elif mode==103: results = ITEMS(l11lll_l1_ (u"ࠪ࠶ࠬ䊃"),True)
	elif mode==104: results = ITEMS(l11lll_l1_ (u"ࠫ࠸࠭䊄"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11lll_l1_ (u"ࠬ࠺ࠧ䊅"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊆"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䊇")+l11lll_l1_ (u"ࠨไ๋หห๋ࠠโ์า๎ํํวหࠢࡐ࠷࡚࠭䊈"),l11lll_l1_ (u"ࠩࠪ䊉"),762)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊊"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪ䊋")+l11lll_l1_ (u"่่ࠬศศ่ࠤๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠫ䊌"),l11lll_l1_ (u"࠭ࠧ䊍"),761)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊎"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠵ࡥࠧ䊏")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ็้ࠤ๊๎วใ฻๊หࠥอไฤื็๎ฮ࠭䊐"),l11lll_l1_ (u"ࠪࠫ䊑"),101)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊒"),l11lll_l1_ (u"ࠬࡥࡔࡗ࠶ࡢࠫ䊓")+l11lll_l1_ (u"࠭โ็๊สฮ๋ࠥฮหษิอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䊔"),l11lll_l1_ (u"ࠧࠨ䊕"),106)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"),l11lll_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ䊗")+l11lll_l1_ (u"ࠪๆ๋๎วหࠢ฼ีอ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ䊘"),l11lll_l1_ (u"ࠫࠬ䊙"),147)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊚"),l11lll_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ䊛")+l11lll_l1_ (u"ࠧใ่๋หฯࠦรอ่ห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ䊜"),l11lll_l1_ (u"ࠨࠩ䊝"),148)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊞"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ䊟")+l11lll_l1_ (u"ࠫࠥࠦโ็ษฬࠤว๐ࠠโ์็้๋ࠥๆࠡ็๋ๆ฾ํๅࠡࠢࠪ䊠"),l11lll_l1_ (u"ࠬ࠭䊡"),28)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䊢"),l11lll_l1_ (u"ࠧࡠࡏࡕࡊࡤ࠭䊣")+l11lll_l1_ (u"ࠨไ้หฮࠦวๅ็฼หึ็ࠠๆ่้ࠣํู่่็ࠪ䊤"),l11lll_l1_ (u"ࠩࠪ䊥"),41)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䊦"),l11lll_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ䊧")+l11lll_l1_ (u"่ࠬๆศหࠣห้้่ฬำ้๋ࠣࠦๅ้ไ฼๋๊࠭䊨"),l11lll_l1_ (u"࠭ࠧ䊩"),135)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䊪"),l11lll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ䊫")+l11lll_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ䊬"),l11lll_l1_ (u"ࠪࠫ䊭"),38)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䊮"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䊯"),l11lll_l1_ (u"࠭ࠧ䊰"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊱"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠶ࡥࠧ䊲")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ฾อๅสࠩ䊳"),l11lll_l1_ (u"ࠪࠫ䊴"),102)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊵"),l11lll_l1_ (u"ࠬࡥࡔࡗ࠴ࡢࠫ䊶")+l11lll_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡะสูฮ࠭䊷"),l11lll_l1_ (u"ࠧࠨ䊸"),103)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊹"),l11lll_l1_ (u"ࠩࡢࡘ࡛࠹࡟ࠨ䊺")+l11lll_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอ๊ࠥไโฯุࠫ䊻"),l11lll_l1_ (u"ࠫࠬ䊼"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡔࡗࠩ䊽")+menu+l11lll_l1_ (u"࠭࡟ࠨ䊾")
	user = l11llll111l_l1_(32)
	payload = {l11lll_l1_ (u"ࠧࡪࡦࠪ䊿"):l11lll_l1_ (u"ࠨࠩ䋀"),l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ䋁"):user,l11lll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ䋂"):l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䋃"),l11lll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ䋄"):menu}
	#data = l1ll1l1ll_l1_(payload)
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䋅"),str(payload))
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䋆"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䋇"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠩࠪ䋈"), True,l11lll_l1_ (u"ࠪࠫ䋉"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䋊"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䋋"),l11ll1_l1_,payload,l11lll_l1_ (u"࠭ࠧ䋌"),l11lll_l1_ (u"ࠧࠨ䋍"),l11lll_l1_ (u"ࠨࠩ䋎"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䋏"))
	html = response.content
	#html = html.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭䋐"),l11lll_l1_ (u"ࠫࠬ䋑"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䋒"),l11lll_l1_ (u"࠭ࠧ䋓"),html,html)
	#file = open(l11lll_l1_ (u"ࠧࡴ࠼࠲ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭䋔"), l11lll_l1_ (u"ࠨࡹࠪ䋕"))
	#file.write(html)
	#file.close()
	items = re.findall(l11lll_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ䋖"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11lll_l1_ (u"ࠪࡥࡱ࠭䋗"),l11lll_l1_ (u"ࠫࡆࡲࠧ䋘"))
			start = start.replace(l11lll_l1_ (u"ࠬࡋ࡬ࠨ䋙"),l11lll_l1_ (u"࠭ࡁ࡭ࠩ䋚"))
			start = start.replace(l11lll_l1_ (u"ࠧࡂࡎࠪ䋛"),l11lll_l1_ (u"ࠨࡃ࡯ࠫ䋜"))
			start = start.replace(l11lll_l1_ (u"ࠩࡈࡐࠬ䋝"),l11lll_l1_ (u"ࠪࡅࡱ࠭䋞"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11lll_l1_ (u"ࠫࡆࡲ࠭ࠨ䋟"),l11lll_l1_ (u"ࠬࡇ࡬ࠨ䋠"))
			start = start.replace(l11lll_l1_ (u"࠭ࡁ࡭ࠢࠪ䋡"),l11lll_l1_ (u"ࠧࡂ࡮ࠪ䋢"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1ll1_l1_,name,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࠥࠪ䋣") in source: continue
			#if source in [l11lll_l1_ (u"ࠩࡑࡘࠬ䋤"),l11lll_l1_ (u"ࠪ࡝࡚࠭䋥"),l11lll_l1_ (u"ࠫ࡜࡙࠰ࠨ䋦"),l11lll_l1_ (u"ࠬࡘࡌ࠲ࠩ䋧"),l11lll_l1_ (u"࠭ࡒࡍ࠴ࠪ䋨")]: continue
			if source!=l11lll_l1_ (u"ࠧࡖࡔࡏࠫ䋩"): name = name+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࠥࠦࠧ䋪")+source+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䋫")
			url = source+l11lll_l1_ (u"ࠪ࠿ࡀ࠭䋬")+server+l11lll_l1_ (u"ࠫࡀࡁࠧ䋭")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠬࡁ࠻ࠨ䋮")+menu
			addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䋯"),l111ll_l1_+l11lll_l1_ (u"ࠧࠨ䋰")+name,url,105,l1llll_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䋱"),l111ll_l1_+l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䋲"),l11lll_l1_ (u"ࠪࠫ䋳"),9999)
		#if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䋴"),l11lll_l1_ (u"ࠬ࠭䋵"),l11lll_l1_ (u"࠭ࠧ䋶"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䋷"))
		#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䋸"),l111ll_l1_+l11lll_l1_ (u"ࠩ็่ศูแࠡๆสࠤฯ๎ฬะࠢๅ๊ํอสࠡฬ็ๅื๎ๆ๋ห่่ࠣ࠭䋹"),l11lll_l1_ (u"ࠪࠫ䋺"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䋻"),l111ll_l1_+l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็ห็ืศศรࠣ์ฬ๊วึัๅหฦࠦแใูࠪ䋼"),l11lll_l1_ (u"࠭ࠧ䋽"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䋾"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䋿"),l11lll_l1_ (u"ࠩࠪ䌀"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䌁"),l111ll_l1_+l11lll_l1_ (u"࡚ࠫࡴࡦࡰࡴࡷࡹࡳࡧࡴࡦ࡮ࡼ࠰ࠥࡴ࡯ࠡࡖ࡙ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠦࡦࡰࡴࠣࡽࡴࡻࠧ䌂"),l11lll_l1_ (u"ࠬ࠭䌃"),9999)
		#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䌄"),l111ll_l1_+l11lll_l1_ (u"ࠧࡊࡶࠣ࡭ࡸࠦࡦࡰࡴࠣࡶࡪࡲࡡࡵ࡫ࡹࡩࡸࠦࠦࠡࡨࡵ࡭ࡪࡴࡤࡴࠢࡲࡲࡱࡿࠧ䌅"),l11lll_l1_ (u"ࠨࠩ䌆"),9999)
	return
def PLAY(id):
	source,server,l11lll1ll1_l1_,menu = id.split(l11lll_l1_ (u"ࠩ࠾࠿ࠬ䌇"))
	url = l11lll_l1_ (u"ࠪࠫ䌈")
	user = l11llll111l_l1_(32)
	if source==l11lll_l1_ (u"࡚ࠫࡘࡌࠨ䌉"): url = l11lll1ll1_l1_
	elif source==l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䌊"):
		url = l1ll11l_l1_[l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䌋")][0]+l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ䌌")+l11lll1ll1_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䌍"),url)
		return
	elif source==l11lll_l1_ (u"ࠩࡊࡅࠬ䌎"):
		payload = { l11lll_l1_ (u"ࠪ࡭ࡩ࠭䌏") : l11lll_l1_ (u"ࠫࠬ䌐"), l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ䌑") : user , l11lll_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ䌒") : l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠱ࠨ䌓") , l11lll_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭䌔") : l11lll_l1_ (u"ࠩࠪ䌕") }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䌖"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠫࠬ䌗"),False,l11lll_l1_ (u"ࠬ࠭䌘"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䌙"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䌚"),l11lll_l1_ (u"ࠨࠩ䌛"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䌜"),l11lll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ䌝"))
			return
		html = response.content
		cookies = response.cookies
		l1l1111l11l1_l1_ = cookies[l11lll_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤࠨ䌞")]
		url = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䌟")]
		payload = { l11lll_l1_ (u"࠭ࡩࡥࠩ䌠") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ䌡") : user , l11lll_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ䌢") : l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠴ࠪ䌣") , l11lll_l1_ (u"ࠪࡱࡪࡴࡵࠨ䌤") : l11lll_l1_ (u"ࠫࠬ䌥") }
		headers = { l11lll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䌦") : l11lll_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࡀࠫ䌧")+l1l1111l11l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䌨"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠨࠩ䌩"),l11lll_l1_ (u"ࠩࠪ䌪"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䌫"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䌬"),l11lll_l1_ (u"ࠬ࠭䌭"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䌮"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䌯"))
			return
		html = response.content
		url = re.findall(l11lll_l1_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ䌰"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ䌱"),l11lll_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠫ䌲")+link)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ䌳"),l11lll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭䌴")+params)
		l1l1111l111l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠹࠰ࠪ䌵")+server+l11lll_l1_ (u"ࠧ࠸࠹࠺࠳ࠬ䌶")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ䌷")+params
		l1l1111l1111_l1_ = l1l1111l111l_l1_.replace(l11lll_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ䌸"),l11lll_l1_ (u"ࠪ࠸࠵ࡀ࠷ࠨ䌹")).replace(l11lll_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭䌺"),l11lll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䌻"))
		l1l1111l11ll_l1_ = l1l1111l111l_l1_.replace(l11lll_l1_ (u"࠭࠳࠷࠼࠺ࠫ䌼"),l11lll_l1_ (u"ࠧ࠵࠴࠽࠻ࠬ䌽")).replace(l11lll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ䌾"),l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䌿"))
		l1lll1ll_l1_ = [l11lll_l1_ (u"ࠪࡌࡉ࠭䍀"),l11lll_l1_ (u"ࠫࡘࡊ࠱ࠨ䍁"),l11lll_l1_ (u"࡙ࠬࡄ࠳ࠩ䍂")]
		l1111_l1_ = [l1l1111l111l_l1_,l1l1111l1111_l1_,l1l1111l11ll_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䍃"), l1lll1ll_l1_)
		if l1l_l1_ == -1: return
		else: url = l1111_l1_[l1l_l1_]
	elif source==l11lll_l1_ (u"ࠧࡏࡖࠪ䍄"):
		headers = { l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䍅") : l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ䍆") }
		payload = { l11lll_l1_ (u"ࠪ࡭ࡩ࠭䍇") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ䍈") : user , l11lll_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ䍉") : l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡒ࡙࠭䍊") , l11lll_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ䍋") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䍌"), l11ll1_l1_, payload, headers, False,l11lll_l1_ (u"ࠩࠪ䍍"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䍎"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䍏"),l11lll_l1_ (u"ࠬ࠭䍐"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䍑"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䍒"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䍓")]
		url = url.replace(l11lll_l1_ (u"ࠩࠨ࠶࠵࠭䍔"),l11lll_l1_ (u"ࠪࠤࠬ䍕"))
		url = url.replace(l11lll_l1_ (u"ࠫࠪ࠹ࡄࠨ䍖"),l11lll_l1_ (u"ࠬࡃࠧ䍗"))
		if l11lll_l1_ (u"࠭ࡌࡦࡣࡵࡲࠬ䍘") in l11lll1ll1_l1_:
			url = url.replace(l11lll_l1_ (u"ࠧࡏࡖࡑࡒ࡮ࡲࡥࠨ䍙"),l11lll_l1_ (u"ࠨࠩ䍚"))
			url = url.replace(l11lll_l1_ (u"ࠩ࡯ࡩࡦࡸ࡮ࡪࡰࡪ࠵ࠬ䍛"),l11lll_l1_ (u"ࠪࡐࡪࡧࡲ࡯࡫ࡱ࡫ࠬ䍜"))
	elif source==l11lll_l1_ (u"ࠫࡕࡒࠧ䍝"):
		#headers = { l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䍞") : l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䍟") }
		payload = { l11lll_l1_ (u"ࠧࡪࡦࠪ䍠") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䍡") : user , l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䍢") : l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡑࡎࠪ䍣") , l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䍤") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䍥"), l11ll1_l1_, payload, l11lll_l1_ (u"࠭ࠧ䍦"),False,l11lll_l1_ (u"ࠧࠨ䍧"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ䍨"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䍩"),l11lll_l1_ (u"ࠪࠫ䍪"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䍫"),l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭䍬"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䍭")]
		headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䍮"):response.headers[l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䍯")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䍰"),url, l11lll_l1_ (u"ࠪࠫ䍱"),headers , l11lll_l1_ (u"ࠫࠬ䍲"),l11lll_l1_ (u"ࠬ࠭䍳"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ䍴"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䍵"),l11lll_l1_ (u"ࠨࠩ䍶"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䍷"),l11lll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ䍸"))
			return
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䍹"),html,re.DOTALL)
		url = items[0]
	elif source in [l11lll_l1_ (u"࡚ࠬࡁࠨ䍺"),l11lll_l1_ (u"࠭ࡆࡎࠩ䍻"),l11lll_l1_ (u"࡚ࠧࡗࠪ䍼"),l11lll_l1_ (u"ࠨ࡙ࡖ࠵ࠬ䍽"),l11lll_l1_ (u"࡚ࠩࡗ࠷࠭䍾"),l11lll_l1_ (u"ࠪࡖࡑ࠷ࠧ䍿"),l11lll_l1_ (u"ࠫࡗࡒ࠲ࠨ䎀")]:
		if source==l11lll_l1_ (u"࡚ࠬࡁࠨ䎁"): l11lll1ll1_l1_ = id
		headers = { l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䎂") : l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䎃") }
		payload = { l11lll_l1_ (u"ࠨ࡫ࡧࠫ䎄") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ䎅") : user , l11lll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ䎆") : l11lll_l1_ (u"ࠫࡵࡲࡡࡺࠩ䎇")+source , l11lll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ䎈") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ䎉"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠧࠨ䎊"),l11lll_l1_ (u"ࠨࠩ䎋"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ䎌"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䎍"),l11lll_l1_ (u"ࠫࠬ䎎"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䎏"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䎐"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䎑")]
		if source==l11lll_l1_ (u"ࠨࡈࡐࠫ䎒"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䎓"), url, l11lll_l1_ (u"ࠪࠫ䎔"), l11lll_l1_ (u"ࠫࠬ䎕"), False,l11lll_l1_ (u"ࠬ࠭䎖"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠼ࡺࡨࠨ䎗"))
			url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䎘")]
			url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䎙"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䎚"))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䎛"))
	return
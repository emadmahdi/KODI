# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ䨯")
headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䨰") : l11lll_l1_ (u"ࠩࠪ䨱") }
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡒ࡜࡚ࡠࠩ䨲")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllllll_l1_ = l1ll11l_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l1111l_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llllll_l1_(url)
	elif mode==188: results = l11lllll11ll_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11lllll11ll_l1_():
	message = l11lll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ䨳")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䨴"),l11lll_l1_ (u"࠭ࠧ䨵"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䨶"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䨷"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䨸"),l11lll_l1_ (u"ࠪࠫ䨹"),189,l11lll_l1_ (u"ࠫࠬ䨺"),l11lll_l1_ (u"ࠬ࠭䨻"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䨼"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䨽"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䨾")+l111ll_l1_+l11lll_l1_ (u"ࠩห์ู่ࠠศ๊ไ๎ุࠦๅ้ใํึ๊ࠥว็ัࠪ䨿"),l11ll1_l1_,181,l11lll_l1_ (u"ࠪࠫ䩀"),l11lll_l1_ (u"ࠫࠬ䩁"),l11lll_l1_ (u"ࠬࡨ࡯ࡹ࠯ࡲࡪ࡫࡯ࡣࡦࠩ䩂"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䩃"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䩄")+l111ll_l1_+l11lll_l1_ (u"ࠨละำะࠦวๅษไ่ฬ๋ࠧ䩅"),l11ll1_l1_,181,l11lll_l1_ (u"ࠩࠪ䩆"),l11lll_l1_ (u"ࠪࠫ䩇"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ䩈"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䩉"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䩊")+l111ll_l1_+l11lll_l1_ (u"ࠧหๆํๅื๐่็่ࠢ์ๆ๐าࠡๆส๊ิ࠭䩋"),l11ll1_l1_,181,l11lll_l1_ (u"ࠨࠩ䩌"),l11lll_l1_ (u"ࠩࠪ䩍"),l11lll_l1_ (u"ࠪࡸࡻ࠭䩎"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䩏"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䩐")+l111ll_l1_+l11lll_l1_ (u"࠭วๅษๆฯึࠦๅีษ๊ำฮ࠭䩑"),l11ll1_l1_,181,l11lll_l1_ (u"ࠧࠨ䩒"),l11lll_l1_ (u"ࠨࠩ䩓"),l11lll_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䩔"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䩕"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䩖")+l111ll_l1_+l11lll_l1_ (u"ࠬษโ้๋ࠣห้อแๅษ่ࠤฬ๊อศๆํอࠬ䩗"),l11ll1_l1_,181,l11lll_l1_ (u"࠭ࠧ䩘"),l11lll_l1_ (u"ࠧࠨ䩙"),l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䩚"))
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ䩛"),headers,l11lll_l1_ (u"ࠪࠫ䩜"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䩝"))
	items = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠳ࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䩞"),html,re.DOTALL)
	for link,title in items:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䩟"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䩠")+l111ll_l1_+title,link,181)
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠨࠩ䩡")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠩࠪ䩢"),headers,l11lll_l1_ (u"ࠪࠫ䩣"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ䩤"))
	if type==l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䩥"): block = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄรฮัฮࠤฬ๊รโๆส้ࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࡪ࠴ࠫ䩦"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ䩧"): block = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ส๋็ุࠦว้ใํื๋่ࠥโ์ีࠤ้อๆะ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࡮࠱ࠨ䩨"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䩩"): block = re.findall(l11lll_l1_ (u"ࠪࡦࡹࡴ࠭࠳࠯ࡲࡺࡪࡸ࡬ࡢࡻࠫ࠲࠯ࡅࠩ࠽ࡵࡷࡽࡱ࡫࠾ࠨ䩪"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䩫"): block = re.findall(l11lll_l1_ (u"ࠬࡨࡴ࡯࠯࠴ࠤࡧࡺ࡮࠮ࡣࡥࡷࡴࡲࡹࠩ࠰࠭ࡃ࠮ࡨࡴ࡯࠯࠵ࠤࡧࡺ࡮࠮ࡣࡥࡷࡴࡲࡹࠨ䩬"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"࠭ࡴࡷࠩ䩭"): block = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾หๆํๅื๐่็่ࠢ์ๆ๐าࠡๆส๊ิࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡧࠣࠩ䩮"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䩯"),l11lll_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䩰")]:
		items = re.findall(l11lll_l1_ (u"ࠪࡷࡹࡿ࡬ࡦ࠿ࠥࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵࡴࡵࡱࡰ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䩱"),block,re.DOTALL)
	else: items = re.findall(l11lll_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࡁࠧ࠹࡛࠱࠯࠼ࡡ࠰ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡱࡷࡸࡴࡳ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䩲"),block,re.DOTALL)
	l1l1_l1_ = []
	l111llll1_l1_ = [l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ䩳"),l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭䩴"),l11lll_l1_ (u"ࠧศๆะ่็ํࠧ䩵"),l11lll_l1_ (u"ࠨ฻ิฺࠬ䩶"),l11lll_l1_ (u"ࠩࡕࡥࡼ࠭䩷"),l11lll_l1_ (u"ࠪࡗࡲࡧࡣ࡬ࡆࡲࡻࡳ࠭䩸"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ䩹"),l11lll_l1_ (u"ࠬอฬำษฤࠫ䩺")]
	for l1llll_l1_,l11llll1l111_l1_,l11lllll1l11_l1_,l11lllll1l1l_l1_ in items:
		if type in [l11lll_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䩻"),l11lll_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䩼")]:
			l1llll_l1_,link,l1lllll1ll_l1_,title = l1llll_l1_,l11llll1l111_l1_,l11lllll1l11_l1_,l11lllll1l1l_l1_
		else: l1llll_l1_,title,link,l1lllll1ll_l1_ = l1llll_l1_,l11llll1l111_l1_,l11lllll1l11_l1_,l11lllll1l1l_l1_
		link = l111l_l1_(link)
		link = link.replace(l11lll_l1_ (u"ࠨࡁࡹ࡭ࡪࡽ࠽ࡵࡴࡸࡩࠬ䩽"),l11lll_l1_ (u"ࠩࠪ䩾"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䩿"),l11lll_l1_ (u"ࠫࠬ䪀"),link,l1lllll1ll_l1_)
		title = unescapeHTML(title)
		#l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠬอา่ะหࡿฬั๎ฯ่ࠫࠪ䪁"),title,re.DOTALL)
		#if l1lll1lll_l1_: title = l1lll1lll_l1_[0][0]
		if l11lll_l1_ (u"࠭ศอ๊าอࠥ࠭䪂") in title or l11lll_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ䪃") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䪄") + title.replace(l11lll_l1_ (u"ࠩหะํีษࠡࠩ䪅"),l11lll_l1_ (u"ࠪࠫ䪆")).replace(l11lll_l1_ (u"ࠫอา่ะ้ࠣࠫ䪇"),l11lll_l1_ (u"ࠬ࠭䪈"))
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ䪉"))
		if l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ䪊") in title or l11lll_l1_ (u"ࠨษ็ั้่็ࠨ䪋") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧ䪌"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䪍") + l1lll11_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䪎"),l111ll_l1_+title,link,183,l1llll_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l111llll1_l1_):
			link = link + l11lll_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䪏") + l1lllll1ll_l1_
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䪐"),l111ll_l1_+title,link,182,l1llll_l1_)
		else:
			link = link + l11lll_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䪑") + l1lllll1ll_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䪒"),l111ll_l1_+title,link,183,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠩࠪ䪓"):
		items = re.findall(l11lll_l1_ (u"ࠪࡠࡳࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䪔"),html,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ䪕"),l11lll_l1_ (u"ࠬ࠭䪖"))
			if title!=l11lll_l1_ (u"࠭ࠧ䪗"):
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䪘"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ䪙")+title,link,181)
	return
def l1llllll_l1_(url):
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䪚"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ䪛"),headers,l11lll_l1_ (u"ࠫࠬ䪜"),l11lll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䪝"))
	block = re.findall(l11lll_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠴ࠪࡀࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࡟࠵࠳࠹࡞࠭ࠬࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䪞"),html,re.DOTALL)
	title,dummy,l1llll_l1_ = block[0]
	name = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡝࠳࠱࠾ࡣࠫࠨ䪟"),title,re.DOTALL)
	if name: name = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䪠") + name[0][0]
	else: name = title
	items = []
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶࡒࡺࡳࡢࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䪡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䪢"),l11lll_l1_ (u"ࠫࠬ䪣"),l11l11l_l1_,str(l1l1ll1_l1_))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䪤"),block,re.DOTALL)
		for link in items:
			link = l111l_l1_(link)
			title = re.findall(l11lll_l1_ (u"࠭ࠨศๆะ่็ฯࡼศๆะ่็ํࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䪥"),link.split(l11lll_l1_ (u"ࠧ࠰ࠩ䪦"))[-2],re.DOTALL)
			if not title: title = re.findall(l11lll_l1_ (u"ࠨࠪࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䪧"),link.split(l11lll_l1_ (u"ࠩ࠲ࠫ䪨"))[-2],re.DOTALL)
			if title: title = l11lll_l1_ (u"ࠪࠤࠬ䪩") + title[0][1]
			else: title = l11lll_l1_ (u"ࠫࠬ䪪")
			title = name + l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ䪫") + l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭䪬") + title
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䪭"),l111ll_l1_+title,link,182,l1llll_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠨสฯ์ิฯࠠࠨ䪮") in title or l11lll_l1_ (u"ࠩหะํี็ࠡࠩ䪯") in title:
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䪰") + title.replace(l11lll_l1_ (u"ࠫอา่ะหࠣࠫ䪱"),l11lll_l1_ (u"ࠬ࠭䪲")).replace(l11lll_l1_ (u"࠭ศอ๊า๋ࠥ࠭䪳"),l11lll_l1_ (u"ࠧࠨ䪴"))
		addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䪵"),l111ll_l1_+title,url,182,l1llll_l1_)
	return
def PLAY(url):
	l11lllll1ll1_l1_ = url.split(l11lll_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䪶"))
	l11l11l_l1_ = l11lllll1ll1_l1_[0]
	del l11lllll1ll1_l1_[0]
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ䪷"),headers,l11lll_l1_ (u"ࠫࠬ䪸"),l11lll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䪹"))
	link = re.findall(l11lll_l1_ (u"࠭ࡦࡰࡰࡷ࠱ࡸ࡯ࡺࡦ࠼ࠣ࠶࠺ࡶࡸ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䪺"),html,re.DOTALL)[0]
	if link not in l11lllll1ll1_l1_: l11lllll1ll1_l1_.append(link)
	l1111_l1_ = []
	# l11lllll1111_l1_
	for link in l11lllll1ll1_l1_:
		if l11lll_l1_ (u"ࠧ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䪻") in link:
			l11lllll1111_l1_ = link
			l1111_l1_.append(l11lllll1111_l1_+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡤ࡭ࡳ࠭䪼"))
	# l11llll1llll_l1_
	for link in l11lllll1ll1_l1_:
		if l11lll_l1_ (u"ࠩ࠽࠳࠴ࡼࡢ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࠬ䪽") in link:
			html = OPENURL_CACHED(l11111l_l1_,link,l11lll_l1_ (u"ࠪࠫ䪾"),headers,l11lll_l1_ (u"ࠫࠬ䪿"),l11lll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䫀"))
			html = html.decode(l11lll_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡹ࠭࠲࠴࠸࠺ࠬ䫁")).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䫂"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11llll11lll_l1_><l11llll1l1ll_l1_ /><l11llll11lll_l1_ l11lllll11l1_l1_=l11lll_l1_ (u"ࠣࡥࡨࡲࡹ࡫ࡲࠣ䫃")>(\*\*\*\*\*\*\*\*|13721411411.l11llll11l1l_l1_|)
			html = html.replace(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࡣࡰ࡯࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䫄"),l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䫅"))
			html = html.replace(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䫆"),l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䫇"))
			html = html.replace(l11lll_l1_ (u"࠭࠼࠰ࡣࡁࡀ࠴ࡪࡩࡷࡀ࠿ࡦࡷࠦ࠯࠿࠾ࡧ࡭ࡻࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨ࠾ࠨ䫈"),l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䫉"))
			html = html.replace(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡥࡳࡷࡪࡥࡳࠤࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠫ䫊"),l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䫋"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䫌"),html,re.DOTALL)
			if l1l1ll1_l1_:
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䫍"),l11lll_l1_ (u"ࠬ࠭䫎"),url,str(len(l1l1ll1_l1_)))
				l11llll11ll1_l1_,l11llll1lll1_l1_ = [],[]
				if len(l1l1ll1_l1_)==1:
					title = l11lll_l1_ (u"࠭ࠧ䫏")
					block = html
				else:
					for block in l1l1ll1_l1_:
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲࠭ࡵ࡮࡭࡫ࡱࡩࢁࡩ࡯࡮ࠫ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠳࠰࠿࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪࠬࠪ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䫐"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࠪ䫑") + l11l1_l1_[0][1]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࠧࠦ࠯࠿ࠪ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䫒"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ䫓") + l11l1_l1_[0]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࠪ࠾࡫ࡶࠥࡹࡩࡻࡧࡀࠦ࠶ࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࠨࠠ࠰ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䫔"),block,re.DOTALL)
						if l11l1_l1_: block = l11l1_l1_[0] + l11lll_l1_ (u"ࠬࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䫕")
						l11lllll111l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࠩ࠰࠭ࡃ࠮࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲࠭ࡵ࡮࡭࡫ࡱࡩࢁࡩ࡯࡮ࠫ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳ࠬ䫖"),block,re.DOTALL)
						title = re.findall(l11lll_l1_ (u"ࠧ࠿ࠢ࠭ࠬࡠࡤ࠼࠿࡟࠮࠭ࠥ࠰࠼ࠨ䫗"),l11lllll111l_l1_[0][0],re.DOTALL)
						title = l11lll_l1_ (u"ࠨࠢࠪ䫘").join(title)
						title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ䫙"))
						title = title.replace(l11lll_l1_ (u"ࠪࠤࠥ࠭䫚"),l11lll_l1_ (u"ࠫࠥ࠭䫛")).replace(l11lll_l1_ (u"ࠬࠦࠠࠨ䫜"),l11lll_l1_ (u"࠭ࠠࠨ䫝")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ䫞"),l11lll_l1_ (u"ࠨࠢࠪ䫟")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ䫠"),l11lll_l1_ (u"ࠪࠤࠬ䫡")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ䫢"),l11lll_l1_ (u"ࠬࠦࠧ䫣"))
						l11llll11ll1_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆู็์อࡀࠧ䫤"), l11llll11ll1_l1_)
					if l1l_l1_ == -1 : return
					title = l11llll11ll1_l1_[l1l_l1_]
					block = l1l1ll1_l1_[l1l_l1_]
				link = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠫࠥࠫ䫥"),block,re.DOTALL)
				l11llll1ll11_l1_ = link[0]
				l1111_l1_.append(l11llll1ll11_l1_+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡈࡲࡶࡺࡳࠧ䫦"))
				block = block.replace(l11lll_l1_ (u"ࠩใࠫ䫧"),l11lll_l1_ (u"ࠪࠫ䫨"))
				block = block.replace(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠹࠶࠽࠴࠲࠴࠴࠻࠺࠸࠹࠷࠰ࡳࡲ࡬ࠨࠧ䫩"),l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡦࡴࡺࡨࠣࠢࠣࡠࡳࠦࠠࠨ䫪"))
				block = block.replace(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡧࡴࡳ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠸࠵࠼࠺࠱࠳࠳࠺࠹࠷࠿࠶࠯ࡲࡱ࡫ࠧ࠭䫫"),l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䫬"))
				block = block.replace(l11lll_l1_ (u"ࠨีํีๆืวหࠢส่ฯำๅ๋ๆࠪ䫭"),l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠣࠤࡡࡴࠠࠡࠩ䫮"))
				block = block.replace(l11lll_l1_ (u"ࠪีํอศุࠢส่ฯำๅ๋ๆࠪ䫯"),l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ䫰"))
				block = block.replace(l11lll_l1_ (u"ู๊ࠬาใิหฯࠦวๅ็ืห์ีࠧ䫱"),l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡼࡧࡴࡤࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䫲"))
				block = block.replace(l11lll_l1_ (u"ࠧา๊สฬ฼ࠦวๅ็ืห์ีࠧ䫳"),l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䫴"))
				l11llll1l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳ࡡࡪࠫࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䫵"),block,re.DOTALL)
				for l11llll1ll1l_l1_ in l11llll1l11l_l1_:
					#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䫶"),l11lll_l1_ (u"ࠫࠬ䫷"),l11lll_l1_ (u"ࠬ࠭䫸"),str(l11llll1ll1l_l1_))
					type = re.findall(l11lll_l1_ (u"࠭ࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠫ䫹"),l11llll1ll1l_l1_)
					if type:
						if type[0]!=l11lll_l1_ (u"ࠧࡣࡱࡷ࡬ࠬ䫺"): type = l11lll_l1_ (u"ࠨࡡࡢࠫ䫻")+type[0]
						else: type = l11lll_l1_ (u"ࠩࠪ䫼")
					items = re.findall(l11lll_l1_ (u"ࠪࠬࡄࡂࠡࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳࠮࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾࠲ࡪࡴࡴࡴ࠿࠰࠭ࡃࢁࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽ࡤࡵࠤ࠴ࡄ࠮ࠫࡁࠬ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࠯ࠬࡂ࠭ࠧ࠭䫽"),l11llll1ll1l_l1_,re.DOTALL)
					for l11llll1l1l1_l1_,link in items:
						title = re.findall(l11lll_l1_ (u"ࠫ࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪࠪ࠾ࠪ䫾"),l11llll1l1l1_l1_)
						title = title[-1]
						link = link + l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䫿") + title + type
						l1111_l1_.append(link)
	# l11lllll1lll_l1_
	l11l1l1_l1_ = l11l11l_l1_.replace(l11ll1_l1_,l11lllllll_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ䬀"),headers,l11lll_l1_ (u"ࠧࠨ䬁"),l11lll_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䬂"))
	items = re.findall(l11lll_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬃"),html,re.DOTALL)
	#l11lll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴࡫࡭ࡣࡧࡧࡑ࠲࠮࡜ࡸ࠭ࠬ࠱࠳࠰࠿࠯ࡪࡷࡱࡱ࠯ࠧ䬄"),html,re.DOTALL)
	#if l11lll1ll1_l1_:
	if items:
		#l11lllll1lll_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࠧ䬅") + l11lll1ll1_l1_[-1] + l11lll_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ䬆")
		l11lllll1lll_l1_ = items[-1]
		l1111_l1_.append(l11lllll1lll_l1_+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡍࡰࡤ࡬ࡰࡪ࠭䬇"))
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䬈"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩ䬉"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪ䬊"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ䬋"),l11lll_l1_ (u"ࠫ࠰࠭䬌"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭䬍"),headers,l11lll_l1_ (u"࠭ࠧ䬎"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䬏"))
	items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡲࡴࡹ࡯࡯࡯ࡀࠪ䬐"),html,re.DOTALL)
	l111lll11_l1_ = [ l11lll_l1_ (u"ࠩࠪ䬑") ]
	l111l1l11_l1_ = [ l11lll_l1_ (u"ࠪห้้ไ๊ࠡหำํ์ࠠโๆอีࠬ䬒") ]
	for category,title in items:
		l111lll11_l1_.append(category)
		l111l1l11_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ䬓"), l111l1l11_l1_)
		if l1l_l1_ == -1 : return
		category = l111lll11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"ࠬ࠭䬔")
	url = l11ll1_l1_ + l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫ䬕")+search+l11lll_l1_ (u"ࠧࠧ࡯ࡦࡥࡹࡃࠧ䬖")+category
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䬗"),l11lll_l1_ (u"ࠩࠪ䬘"),url,url)
	l1111l_l1_(url)
	return
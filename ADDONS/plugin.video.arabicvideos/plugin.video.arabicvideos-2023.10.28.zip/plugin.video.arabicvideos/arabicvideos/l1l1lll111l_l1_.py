# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ⶒ")
headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩⶓ"):l11lll_l1_ (u"࠭ࠧⶔ")}
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡈࡋ࠶ࡤ࠭ⶕ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1l1ll1lll1_l1_.faselhd.l1l1lll1111_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/faselhd.l1lll111ll_l1_
# l1llll11ll1_l1_	https://www.l1llll11ll1_l1_.com/faselhd
# l1llll111l1_l1_	https://l1llll111l1_l1_.com/l1l1lll1l11_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨࡹࡺࡩࠬⶖ")]
def MAIN(mode,url,text):
	if   mode==590: results = MENU()
	elif mode==591: results = l1111l_l1_(url,text)
	elif mode==592: results = PLAY(url)
	elif mode==593: results = l1lllll111l_l1_(url,text)
	#elif mode==594: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ⶗")+text)
	#elif mode==595: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ⶘")+text)
	elif mode==599: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ⶙"):l1ll1l1_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⶚"):l1l11111l_l1_(False)}
	l1ll1l1_l1_ = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⶛"),l1ll1l1_l1_,l11lll_l1_ (u"ࠧࠨ⶜"),l11lll_l1_ (u"ࠨࠩ⶝"),l11lll_l1_ (u"ࠩࠪ⶞"),l11lll_l1_ (u"ࠪࠫ⶟"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨⶠ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶡ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ⶢ"),l1ll1l1_l1_,599,l11lll_l1_ (u"ࠧࠨⶣ"),l11lll_l1_ (u"ࠨࠩⶤ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ⶥ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶦ"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ⶧"),l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬⶨ"),594)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶩ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪⶪ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨⶫ"),595)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⶬ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⶭ"),l11lll_l1_ (u"ࠫࠬⶮ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⶯"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧⶰ"),l1ll1l1_l1_,591,l11lll_l1_ (u"ࠧࠨⶱ"),l11lll_l1_ (u"ࠨࠩⶲ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠵ࠬⶳ"))
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⶴ"),html,re.DOTALL)
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶵ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⶶ")+l111ll_l1_+title,link,591,l11lll_l1_ (u"࠭ࠧ⶷"),l11lll_l1_ (u"ࠧࠨⶸ"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠳ࠪⶹ"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⶺ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⶻ"),l11lll_l1_ (u"ࠫࠬⶼ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡨࡦࡣࡧࡩࡷ࠳ࡳࡰࡥ࡬ࡥࡱ࠭ⶽ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1lll1l1l1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼࡭࡫ࠣࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧⶾ"),block,re.DOTALL)
		for menu in l1lll1l1l1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⶿"),menu,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ⷀ") not in link: link = l1ll1l1_l1_+link
				#if any(value in title.lower() for value in l1l1l1_l1_): continue
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷁ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⷂ")+l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠫࠬⷃ"),l11lll_l1_ (u"ࠬ࠭ⷄ"),l11lll_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨⷅ"))
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠧࠨⷆ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⷇"),l11lll_l1_ (u"ࠩࠪⷈ"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫⷉ"):url,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨⷊ"):l1l11111l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⷋ"),url,l11lll_l1_ (u"࠭ࠧⷌ"),l11lll_l1_ (u"ࠧࠨⷍ"),l11lll_l1_ (u"ࠨࠩⷎ"),l11lll_l1_ (u"ࠩࠪ⷏"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩⷐ"))
	html = response.content
	l1l1ll1llll_l1_ = 0
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡳ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡀ࡭࠺࠾ࠨⷑ"),html,re.DOTALL)
	if l1l11ll_l1_: l11l1_l1_ = l1l11ll_l1_[0]
	else: l11l1_l1_ = l11lll_l1_ (u"ࠬ࠭ⷒ")
	if type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠲ࠩⷓ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵ࡯࡭ࡩ࡫ࡲ࠮ࡥࡤࡶࡴࡻࡳࡦ࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡄࠧⷔ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⷕ"),block,re.DOTALL)
		l111l111l_l1_,l1l111_l1_,links = zip(*items)
		items = zip(links,l111l111l_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠶ࠬⷖ"):
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⷗"),l11l1_l1_,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬⷘ"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠬࡢ࡜࠰ࠩⷙ"),l11lll_l1_ (u"࠭࠯ࠨⷚ")).replace(l11lll_l1_ (u"ࠧ࡝࡞ࠥࠫⷛ"),l11lll_l1_ (u"ࠨࠤࠪⷜ"))]
	elif type==l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠵ࠫⷝ") and l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨⷞ") in l11l1_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠾ࠨ⷟"),html,re.DOTALL)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷠ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅๆ์ีอࠬⷡ"),url,591,l11lll_l1_ (u"ࠧࠨⷢ"),l11lll_l1_ (u"ࠨࠩⷣ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠶ࠬⷤ"))
		title = l1l1ll1_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷥ"),l111ll_l1_+title,url,591,l11lll_l1_ (u"ࠫࠬⷦ"),l11lll_l1_ (u"ࠬ࠭ⷧ"),l11lll_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠳ࠨⷨ"))
		return
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡁࠫⷩ"),html,re.DOTALL)
		title,block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿࡬࠸࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭ⷪ"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩⷫ"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨⷬ"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪⷭ"),l11lll_l1_ (u"้ࠬไ๋สࠪⷮ"),l11lll_l1_ (u"࠭วฺๆส๊ࠬⷯ"),l11lll_l1_ (u"่ࠧัสๅࠬⷰ"),l11lll_l1_ (u"ࠨ็หหึอษࠨⷱ"),l11lll_l1_ (u"ࠩ฼ี฻࠭ⷲ"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪⷳ"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪⷴ"),l11lll_l1_ (u"๋ࠬำาฯํอࠬⷵ"),l11lll_l1_ (u"࠭อๅไฬࠫⷶ")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠩⷷ"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫⷸ"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧⷹ") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷺ"),l111ll_l1_+title,link,591,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"ࠫࠬⷻ"):
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫⷼ")+l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷽ"),l111ll_l1_+title,link,593,l1llll_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ⷾ"),l111ll_l1_+title,link,592,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷿ"),l111ll_l1_+title,link,593,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⸀"):
		l1lll111lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ⸁"),block,re.DOTALL)
		if l1lll111lll_l1_:
			count = l1lll111lll_l1_[0]
			link = url+l11lll_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭⸂")+count
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸃"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⸄"),link,591,l11lll_l1_ (u"ࠧࠨ⸅"),l11lll_l1_ (u"ࠨࠩ⸆"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⸇"))
	elif l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶࠫ⸈") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⸉"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⸊"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"࠭ีโฯฬࠤࠬ⸋")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸌"),l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠨࠩ⸍"),l11lll_l1_ (u"ࠩࠪ⸎"),l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠸ࠬ⸏"))
	return
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠫࠬ⸐")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⸑"),url,l11lll_l1_ (u"࠭ࠧ⸒"),l11lll_l1_ (u"ࠧࠨ⸓"),l11lll_l1_ (u"ࠨࠩ⸔"),l11lll_l1_ (u"ࠩࠪ⸕"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲࡙ࡅࡂࡕࡒࡒࡘࡥࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⸖"))
	html = response.content
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡥࡢࡵࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡢࡵࡲࡲࡸࡄࠧ⸗"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ⸘"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⸙"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸚"),l111ll_l1_+title,link,593,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ⸛"),l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⸜"))
	if type==l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⸝") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡨ࡫ำࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠣࡀ࠿࠳ࡧࡱ࠾ࠨ⸞"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"ࠬ࠭⸟")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡢ࡮࡯࠱ࡪࡶࡩࡴࡱࡧࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࡬࡭࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࡂࠬ⸠"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⸡"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⸢"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⸣"),l111ll_l1_+title,link,592,l1llll_l1_)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1lll1ll1_l1_,l1l1llll111_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⸤"),url,l11lll_l1_ (u"ࠫࠬ⸥"),l11lll_l1_ (u"ࠬ࠭⸦"),l11lll_l1_ (u"࠭ࠧ⸧"),l11lll_l1_ (u"ࠧࠨ⸨"),l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⸩"))
	html = response.content
	l1l1lll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠩส่฾๋ัࠡ࠼࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨ⸪"),html,re.DOTALL)
	if l1l1lll11l1_l1_ and l11ll11_l1_(script_name,url,l1l1lll11l1_l1_): return
	# l1l111lll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⸫"),html,re.DOTALL)
	if link:
		link = link[0]
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ⸬"))
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳ࡭࡫ࡦࡩ࠲ࡺࡩࡵ࡮ࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⸭"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ⸮"),block,re.DOTALL)
		for link,name in items:
			name = name.strip(l11lll_l1_ (u"ࠧࠡࠩⸯ"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⸰")+name+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⸱"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࡴࡀࠪ⸲"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⸳"),block,re.DOTALL)
		for link,name in items:
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⸴")+name+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⸵"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไๆ่สือ࠭⸶"), l1lllll1_l1_)
	for l1l1lll1l1l_l1_ in l1lllll1_l1_:
		link,name = l1l1lll1l1l_l1_.split(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤࠨ⸷"))
		if link not in l1l1lll1ll1_l1_:
			l1l1lll1ll1_l1_.append(link)
			l1l1llll111_l1_.append(l1l1lll1l1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆ่๊ฬูศࠨ⸸"), l1l1llll111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1llll111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⸹"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ⸺"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭⸻"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ⸼"),l11lll_l1_ (u"ࠧࠬࠩ⸽"))
	#l1ll1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠴ࡨࡰࡵࡷࠫ⸾"))
	#if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⸿")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠹ࠬ⹀"))
	return
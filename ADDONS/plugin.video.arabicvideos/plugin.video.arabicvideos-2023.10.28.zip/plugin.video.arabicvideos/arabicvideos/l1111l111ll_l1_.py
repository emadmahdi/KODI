# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ䵁")
headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䵂"):l11lll_l1_ (u"ࠫࠬ䵃")}
script_name = l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ䵄")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ䵅")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11lll_l1_ (u"ࠧ࠴ࠩ䵆"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11lll_l1_ (u"ࠨ࠳ࠪ䵇"))
	elif mode==36: results = CATEGORIES(url,l11lll_l1_ (u"ࠩ࠵ࠫ䵈"))
	elif mode==37: results = CATEGORIES(url,l11lll_l1_ (u"ࠪ࠸ࠬ䵉"))
	elif mode==38: results = l1l1lll1l_l1_()
	elif mode==39: results = SEARCH(text,l1l11l1_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵊"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䵋"),l11lll_l1_ (u"࠭ࠧ䵌"),39,l11lll_l1_ (u"ࠧࠨ䵍"),l11lll_l1_ (u"ࠨࠩ䵎"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䵏"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䵐"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䵑"),l11lll_l1_ (u"ࠬ࠭䵒"),9999)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䵓"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䵔")+l111ll_l1_+l11lll_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ䵕"),l11lll_l1_ (u"ࠩࠪ䵖"),38)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵗"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䵘")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯ่ࠦษำส้ั࠭䵙"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䵚"),31)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䵛"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䵜")+l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไศๅฮี๋ࠥิศ้าอࠬ䵝"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䵞"),37)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵟"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䵠")+l111ll_l1_+l11lll_l1_ (u"࠭วโๆส้ࠥำำษࠢส่๋๎ูࠨ䵡"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ䵢"),35)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵣"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䵤")+l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠢะือࠦวๅ็่ฯ้࠭䵥"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ䵦"),36)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䵧"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䵨")+l111ll_l1_+l11lll_l1_ (u"ࠧศฯาฯࠥอไศใ็ห๊࠭䵩"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ䵪"),32)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䵫"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䵬")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫัฮ์สฮࠬ䵭"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡧࡦࡰࡵࡩ࠴࠺࠯࠲ࠩ䵮"),32)
	return l11lll_l1_ (u"࠭ࠧ䵯")
def CATEGORIES(url,select=l11lll_l1_ (u"ࠧࠨ䵰")):
	type = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ䵱"))[3]
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䵲"),l11lll_l1_ (u"ࠪࠫ䵳"),type, url)
	if type==l11lll_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䵴"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭䵵"),headers,l11lll_l1_ (u"࠭ࠧ䵶"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ䵷"))
		if select==l11lll_l1_ (u"ࠨ࠵ࠪ䵸"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸࡓࡥ࡯ࡷࠫ࠲࠯ࡅࠩࡴࡧࡵ࡭ࡪࡹࡆࡰࡴࡰࠫ䵹"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䵺"),block,re.DOTALL)
			for link,name in items:
				if l11lll_l1_ (u"่๊๊ࠫษษอࠤ๊฼อไหࠪ䵻") in name: continue
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ䵼"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䵽"),l111ll_l1_+name,url,32)
		if select==l11lll_l1_ (u"ࠧ࠵ࠩ䵾"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡥࡧࡷࡥ࡮ࡲࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡻࡄ࠼࠰ࡣࡁࡀ࠴ࡪࡩࡷࡀࠪ䵿"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶀"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				url = l11ll1_l1_ + link
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ䶁"))
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶂"),l111ll_l1_+title,url,32,l1llll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䶃"),l11lll_l1_ (u"࠭ࠧ䶄"),url,l11lll_l1_ (u"ࠧࠨ䶅"))
	if type==l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䶆"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ䶇"),headers,l11lll_l1_ (u"ࠪࠫ䶈"),l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠳ࡰࡧࠫ䶉"))
		if select==l11lll_l1_ (u"ࠬ࠷ࠧ䶊"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡍࡥ࡯ࡦࡨࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ䶋"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䶌"),block,re.DOTALL)
			for value,name in items:
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰ࠩ䶍") + value
				name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ䶎"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶏"),l111ll_l1_+name,url,32)
		elif select==l11lll_l1_ (u"ࠫ࠷࠭䶐"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡆࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡴࡧ࡯ࡩࡨࡺࠧ䶑"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䶒"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ䶓"))
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡤࡧࡹࡵࡲ࠰ࠩ䶔") + value
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶕"),l111ll_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䶖"),l11lll_l1_ (u"ࠫࠬ䶗"),url,l11lll_l1_ (u"ࠬ࠭䶘"))
	type = url.split(l11lll_l1_ (u"࠭࠯ࠨ䶙"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ䶚"),headers,l11lll_l1_ (u"ࠨࠩ䶛"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䶜"))
	if l11lll_l1_ (u"ࠪ࡬ࡴࡳࡥࠨ䶝") in url: type=l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䶞")
	if type==l11lll_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ䶟"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠪ࠱࠮ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ䶠"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䶡"),block,re.DOTALL)
			for link,l1llll_l1_,name in items:
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ䶢"))
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶣"),l111ll_l1_+name,url,32,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䶤"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ䶥"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠰ࡅࠩࠣࠩ䶦"),block,re.DOTALL)
		for link,l1llll_l1_,name in items:
			name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ䶧"))
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䶨"),l111ll_l1_+name,url,33,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䶩"):
		l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ䶪"))[-1]
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䶫"),l11lll_l1_ (u"ࠫࠬ䶬"),url,l11lll_l1_ (u"ࠬ࠭䶭"))
		if l1l11l1_l1_==l11lll_l1_ (u"࠭࠱ࠨ䶮"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷࠬ䶯"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࠩ䶰"),block,re.DOTALL)
			count = 0
			for link,l1llll_l1_,l1lll11_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭䶱") + l1lll11_l1_
				url = l11ll1_l1_ + link
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䶲"),l111ll_l1_+name,url,33,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳ࠯ࠬࡂࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䶳"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠭䶴"),block,re.DOTALL)
		for link,l1llll_l1_,title,l1lll11_l1_ in items:
			l1lll11_l1_ = l1lll11_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ䶵"))
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ䶶"))
			name = title + l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ䶷") + l1lll11_l1_
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䶸"),l111ll_l1_+name,url,33,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡫ࡱࡿࡰࡩ࡫ࡦࡳࡳ࠳ࡣࡩࡧࡹࡶࡴࡴ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠬࡁࠬࡨࡦࡺࡡ࠮ࡴࡨࡺ࡮ࡼࡥ࠮ࡼࡲࡲࡪ࡯ࡤ࠾ࠤ࠷ࠦࠬ䶹"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶺"),block,re.DOTALL)
	for link,l1l11l1_l1_ in items:
		url = l11ll1_l1_ + link
		name = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䶻") + l1l11l1_l1_
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䶼"),l111ll_l1_+name,url,32)
	return
def PLAY(url):
	if l11lll_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䶽") in url:
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࡶ࠲࠱ࡶࡩࡷ࡯ࡥࡴࡎ࡬ࡲࡰ࠵ࠧ䶾") + url.split(l11lll_l1_ (u"ࠩ࠲ࠫ䶿"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䷀"),url,l11lll_l1_ (u"ࠫࠬ䷁"),headers,l11lll_l1_ (u"ࠬ࠭䷂"),l11lll_l1_ (u"࠭ࠧ䷃"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䷄"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠨࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷅"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11lll_l1_ (u"ࠩ࡟࠳ࠬ䷆"),l11lll_l1_ (u"ࠪ࠳ࠬ䷇"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䷈"),url,l11lll_l1_ (u"ࠬ࠭䷉"),headers,l11lll_l1_ (u"࠭ࠧ䷊"),l11lll_l1_ (u"ࠧࠨ䷋"),l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䷌"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷍"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䷎"))
	return
def SEARCH(search,l1l11l1_l1_=l11lll_l1_ (u"ࠫࠬ䷏")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ䷐"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ䷑"))
	l1ll1111l_l1_ = [l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䷒"),l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䷓")]
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠩ࠴ࠫ䷔")
	else: l1l11l1_l1_,type = l1l11l1_l1_.split(l11lll_l1_ (u"ࠪ࠳ࠬ䷕"))
	if l1ll_l1_:
		l1l11l1ll_l1_ = [ l11lll_l1_ (u"ࠫอำหࠡ฻้ࠤฬ็ไศ็ࠪ䷖") , l11lll_l1_ (u"ࠬฮอฬࠢ฼๊๋ࠥำๅี็หฯ࠭䷗")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣ࠱ࠥอฮหำࠣห้ฮอฬࠩ䷘"), l1l11l1ll_l1_)
		if l1l_l1_ == -1 : return
		type = l1ll1111l_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠧࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨ䷙") in options: type = l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䷚")
		elif l11lll_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࡡࠪ䷛") in options: type = l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䷜")
		else: return
	headers[l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䷝")] = l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䷞")
	data = {l11lll_l1_ (u"࠭ࡱࡶࡧࡵࡽࠬ䷟"):l111l1l_l1_ , l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡄࡰ࡯ࡤ࡭ࡳ࠭䷠"):type}
	if l1l11l1_l1_!=l11lll_l1_ (u"ࠨ࠳ࠪ䷡"): data[l11lll_l1_ (u"ࠩࡩࡶࡴࡳࠧ䷢")] = l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷣"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ䷤"),data,headers,l11lll_l1_ (u"ࠬ࠭䷥"),l11lll_l1_ (u"࠭ࠧ䷦"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䷧"))
	html = response.content
	items=re.findall(l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷨"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l11ll1_l1_ + link.replace(l11lll_l1_ (u"ࠩ࡟࠳ࠬ䷩"),l11lll_l1_ (u"ࠪ࠳ࠬ䷪"))
			if l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭䷫") in url: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䷬"),l111ll_l1_+l11lll_l1_ (u"࠭แ๋ๆ่ࠤࠬ䷭")+title,url,33)
			elif l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䷮") in url:
				url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ䷯"),l11lll_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࠨ䷰"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷱"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆࠣࠫ䷲")+title,url+l11lll_l1_ (u"ࠬ࠵࠱ࠨ䷳"),32)
	count=re.findall(l11lll_l1_ (u"࠭ࠢࡵࡱࡷࡥࡱࠨ࠺ࠩ࠰࠭ࡃ࠮ࢃࠧ䷴"),html,re.DOTALL)
	if count:
		l1l1ll11l_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll11l1l_l1_ in range(1,l1l1ll11l_l1_):
			l1ll11l1l_l1_ = str(l1ll11l1l_l1_)
			if l1ll11l1l_l1_!=l1l11l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䷵"),l11lll_l1_ (u"ࠨืไัฮࠦࠧ䷶")+l1ll11l1l_l1_,l11lll_l1_ (u"ࠩࠪ䷷"),39,l11lll_l1_ (u"ࠪࠫ䷸"),l1ll11l1l_l1_+l11lll_l1_ (u"ࠫ࠴࠭䷹")+type,search)
	return
def l1l1lll1l_l1_():
	link = l11lll_l1_ (u"ࠬࡧࡈࡓ࠲ࡦࡈࡴࡼࡌ࠳ࡦࡽࡨࡍࡐ࡬࡚࡙࠳࠴ࡑࡴࡂࡩࡤࡰ࡚࠵ࡒ࡭ࡏࡸࡏࡱࡱࡹࡌ࠳ࡘ࡮࡞࠷࡜ࡦ࡚࡙ࡍࡽࡑ࠸ࡨࡩࡤࡊࡊ࡚࡜ࡩ࠺ࡹࡥࡋࡋ࠻ࡢࡈ࡮ࡽࡨࡈ࠻ࡴࡎ࠵ࡘ࠸ࠬ䷺")
	link = base64.b64decode(link)
	link = link.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䷻"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䷼"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
l11lll_l1_ (u"ࠧࠨࠢࠋࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠹ࡨࡥࡴࡶ࠱ࡧࡴࡳࠧࠋࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠶࠴ࡢࡦࡵࡷࠫࠏࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠫࠏࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡶࡪࡲࠪࠎࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽ࠮ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡴࡼࡩࡦࡵ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡸ࡯ࡴࡦࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡹࡼࠧࠋࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤࡧࡰ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡤࡱࠪࠎࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡯ࡳ࡬࠭ࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡧࡤࡶ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴࡭ࡦࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠭ࠊࠣࠤࠥ⁺")
script_name = l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ⁻")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡇࡊࡆࡤ࠭⁼")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ⁽"):l11lll_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶ࠧ⁾")}
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==120: results = MENU()
	elif mode==121: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==122: results = l1l11l_l1_(url)
	elif mode==123: results = PLAY(url)
	elif mode==124: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩⁿ")+text)
	elif mode==125: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ₀")+text)
	elif mode==129: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ₁"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭₂"),l11lll_l1_ (u"ࠧࠨ₃"),129,l11lll_l1_ (u"ࠨࠩ₄"),l11lll_l1_ (u"ࠩࠪ₅"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ₆"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ₇"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ₈"),l11lll_l1_ (u"࠭ࠧ₉"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ₊"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ₋"),headers,l11lll_l1_ (u"ࠩࠪ₌"),l11lll_l1_ (u"ࠪࠫ₍"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ₎"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࠠࡪ࠯࡫ࡳࡲ࡫ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࠠࡪ࠯ࡩࡳࡱࡪࡥࡳࠤࠪ₏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨₐ"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠧศๆู่ฬืูสࠩₑ") in title: continue
			title = title.rsplit(l11lll_l1_ (u"ࠨࡀࠪₒ"),1)[1]
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫₓ"))
			link = link.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬₔ"))
			link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫₕ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧₖ")+l111ll_l1_+title,link,122)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫₗ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧₘ"),l11lll_l1_ (u"ࠨࠩₙ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡢ࡫ࡱࡐࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡅࡻࡱࡥࡲ࡯ࡣࠣࠩₚ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡴࡩࡧࠠࡣࡦࡥࠦࡃࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧₛ"),html,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ₜ"))
			link = link.rstrip(l11lll_l1_ (u"ࠬ࠵ࠧ₝"))
			link = l11ll1_l1_+link
			if l11lll_l1_ (u"࠭วๅ็ุหึ฿ษࠨ₞") in title: continue
			if l11lll_l1_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩ₟") in link: continue
			if not title and l11lll_l1_ (u"ࠨ࠱ࡷࡺ࠴ࡧࡲࡢࡤ࡬ࡧࠬ₠") in link: title = l11lll_l1_ (u"่ࠩืู้ไศฬࠣ฽ึฮ๊สࠩ₡")
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ₢"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭₣")+l111ll_l1_+title,link,121)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ₤"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭₥"),l11lll_l1_ (u"ࠧࠨ₦"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡤࠬ࠳࠰࠿ࠪࡀࡈ࡫ࡾࡈࡥࡴࡶ࠿࠳ࡦࡄࠧ₧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ₨"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ₩"))
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ₪"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ₫")+l111ll_l1_+title,link,121)
	return html
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ€"),url,l11lll_l1_ (u"ࠧࠨ₭"),headers,l11lll_l1_ (u"ࠨࠩ₮"),l11lll_l1_ (u"ࠩࠪ₯"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ₰"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡹ࡟ࡴࡥࡵࡳࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ₱"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭₲"),block,re.DOTALL)
	if l11lll_l1_ (u"࠭ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ₳") not in url:
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ₴"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ₵"),url,125)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₶"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭₷"),url,124)
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ₸"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ₹"),l11lll_l1_ (u"࠭ࠧ₺"),9999)
	for link,title in items:
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ₻"),l111ll_l1_+title,link,121)
	return
def l1111l_l1_(url,l1l11l1_l1_=l11lll_l1_ (u"ࠨ࠳ࠪ₼")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ₽"),l11lll_l1_ (u"ࠪࠫ₾"),l11lll_l1_ (u"࡙ࠫࡏࡔࡍࡇࡖࠫ₿"),url)
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠬ࠷ࠧ⃀")
	#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ⃁") not in url: url = l11ll1_l1_+url
	if l11lll_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࠪ⃂") in url or l11lll_l1_ (u"ࠨࡁࠪ⃃") in url: l11l11l_l1_ = url + l11lll_l1_ (u"ࠩࠩࠫ⃄")
	else: l11l11l_l1_ = url + l11lll_l1_ (u"ࠪࡃࠬ⃅")
	l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"ࠫࡴࡻࡴࡱࡷࡷࡣ࡫ࡵࡲ࡮ࡣࡷࡁ࡯ࡹ࡯࡯ࠨࡲࡹࡹࡶࡵࡵࡡࡰࡳࡩ࡫࠽࡮ࡱࡹ࡭ࡪࡹ࡟࡭࡫ࡶࡸࠫࡶࡡࡨࡧࡀࠫ⃆")+l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⃇"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ⃈"),headers,l11lll_l1_ (u"ࠧࠨ⃉"),l11lll_l1_ (u"ࠨࠩ⃊"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⃋"))
	html = response.content
	name,items = l11lll_l1_ (u"ࠪࠫ⃌"),[]
	if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭⃍") in url:
		name = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⃎"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l11lll_l1_ (u"࠭ࠠࠨ⃏")) + l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ⃐")
		else: name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠤ⃑") ) + l11lll_l1_ (u"ࠩࠣ࠱⃒ࠥ࠭")
	if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ⃓ࠫ") not in url: items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬࡡࡢ࡜࡝࡞࠲ࡷࡪࡧࡳࡰࡰ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࡴࡴࡦࡁࡡࡢ࡜࡝ࠤࠫ࠲࠯ࡅࠩ࡝࡞࡟ࡠࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥ࡝࡞࡟ࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⃔"),html,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡷࡷࡩ࠽࡝࡞࡟ࡠࠧ࠮࠮ࠫࡁࠬࡠࡡࡢ࡜ࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧ࡟ࡠࡡࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⃕"),html,re.DOTALL)
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⃖") in url and l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࡝࠱ࠪ⃗") not in link: continue
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱⃘ࠪ") in url and l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡠ࠴⃙࠭") not in link: continue
		title = name+escapeUNICODE(title).strip(l11lll_l1_ (u"ࠪࠤ⃚ࠬ"))
		link = link.replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ⃛"),l11lll_l1_ (u"ࠬ࠵ࠧ⃜"))
		l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ⃝"),l11lll_l1_ (u"ࠧ࠰ࠩ⃞"))
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⃟") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ⃠")+l1llll_l1_
		l11l11l_l1_ = l11ll1_l1_+link
		if l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲ࠫ⃡") in l11l11l_l1_ or l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ⃢") in l11l11l_l1_ or l11lll_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫ⃣") in url:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⃤"),l111ll_l1_+title,l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠧ࠰⃥ࠩ")),123,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃦"),l111ll_l1_+title,l11l11l_l1_,121,l1llll_l1_)
	if len(items)>=12:
		l1111ll1ll_l1_ = [l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ⃧"),l11lll_l1_ (u"ࠪ࠳ࡹࡼ࠯ࠨ⃨"),l11lll_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵ࠧ⃩"),l11lll_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧ࠰⃪ࠩ"),l11lll_l1_ (u"࠭࠯࡮ࡣࡶࡶࡦ࡮ࡩࡺࡣࡷ࠳⃫ࠬ")]
		l1l11l1_l1_ = int(l1l11l1_l1_)
		if any(value in url for value in l1111ll1ll_l1_):
			for n in range(0,1100,100):
				if int(l1l11l1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1l11l1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1l11l1_l1_==j and j!=0:
									addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ⃬ࠧ"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮ⃭ࠦࠧ")+str(j),url,121,l11lll_l1_ (u"⃮ࠩࠪ"),str(j))
						elif i!=0: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ⃯ࠪ"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ⃰")+str(i),url,121,l11lll_l1_ (u"ࠬ࠭⃱"),str(i))
						else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⃲"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭⃳")+str(1),url,121,l11lll_l1_ (u"ࠨࠩ⃴"),str(1))
				elif n!=0: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⃵"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ⃶")+str(n),url,121,l11lll_l1_ (u"ࠫࠬ⃷"),str(n))
				else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⃸"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ⃹")+str(1),url,121)
	return
def PLAY(url):
	headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⃺"):l11lll_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵࠭⃻")}
	#url = url.replace(l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ⃼"),l11lll_l1_ (u"ࠪࡻ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ⃽"))
	# cache l1111lll1l_l1_ not l111l1l1l1_l1_ l11111lll1_l1_ 3 minutes
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⃾"),url,l11lll_l1_ (u"ࠬ࠭⃿"),headers,l11lll_l1_ (u"࠭ࠧ℀"),l11lll_l1_ (u"ࠧࠨ℁"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫℂ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡸࡩࡄวๅฬุ๊๏็࠼࠰ࡶࡧࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ℃"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡴ࡭࠺ࡶࡴ࡯ࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ℄"),html,re.DOTALL)
	if l1111l1ll1_l1_: server = SERVER(l1111l1ll1_l1_[0],l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ℅"))
	else: server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ℆"))
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡶࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡹࡨ࡯ࡥࡻࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡲࡴࡺࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡆࡌࡅࡑࡕࡇࡠࡐࡒࡘࡎࡌࡉࡄࡃࡗࡍࡔࡔࠨࠨะฺว๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨ࠮้้ࠪ็ࠠศๆไ๎ิ๐่ࠡ฼ํี๋ࠥส้ใิࠫ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠨࠢࠣℇ")
	# l1111l1l11_l1_ https://l111l1l111_l1_.net/l11l1ll1l_l1_/?v=l11111l1ll_l1_&h=5de8bb072d336de05092297ec8b61643
	# l111ll1lll_l1_ https://l1111l11ll_l1_.top/l1l111lll_l1_/l111ll1l11_l1_/?l111ll11l1_l1_=44711370a2655b3f2d23487cb74c05e5347648e8bb9571dfa7c5d5e4zlllsCGMDslElsMaYXobviuROhYfamfMOhlsEslsWQUlslElsMOcSbzMykqapaqlsEslsxMcGlslElsOGsabiZusOxySMgOpEaucSxiSVGEBOlOouQzsEslsxWdlslElsmmmlRPMMslnfpaqlsEslsCMcGlslElsOEOEEZlEMOuzslh
	l1lll1ll_l1_,l1111_l1_ = [],[]
	# l11l1ll1l_l1_ & download links
	#l1111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ℈"),html,re.DOTALL)
	l1111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡸࡸࡴ࠳ࡳࡪࡼࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ℉"),html,re.DOTALL)
	if l1111l1l11_l1_:
		l1111l1l11_l1_ = server+l1111l1l11_l1_[0]		#+l11lll_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡀ࠯࠰࠹࠼࠲࠶࠼࠵࠯࠴࠷࠶࠳࠾࠴࠻࠶࠴࠸࠺࠭ℊ")
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫℋ"),l11lll_l1_ (u"ࠫࠬℌ"),l11lll_l1_ (u"ࠬ࠭ℍ"),l1111l1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪℎ"),l1111l1l11_l1_,l11lll_l1_ (u"ࠧࠨℏ"),headers,l11lll_l1_ (u"ࠨࠩℐ"),l11lll_l1_ (u"ࠩࠪℑ"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ℒ"))
		l11lll1l_l1_ = response.content
		#WRITE_THIS(l11lll1l_l1_)
		if l11lll_l1_ (u"ࠫࡩࡵࡳࡵࡴࡨࡥࡲ࠭ℓ") not in l11lll1l_l1_:
			l1111lllll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡤࡴ࡬ࡴࡹ࠴ࠪࡀࡀࡩࡹࡳࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ℔"),l11lll1l_l1_,re.DOTALL)
			l1111lllll_l1_ = l1111lllll_l1_[0]
			result = l111111lll_l1_(l1111lllll_l1_)
			try: l1llllll11l_l1_,l1lllllllll_l1_,l111ll1ll1_l1_ = result
			except:
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧℕ"),l11lll_l1_ (u"ࠧࠨ№"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ℗"),l11lll_l1_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣ࠲่ࠥฯࠡ์ๆ์๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦโศ็ࠣฬฯำฯ๋อูࠣๆำวห้ࠣ์ฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡ฻็ํ่ࠥัศรฬࠤฬ๊ีโฯสฮࠥอไอัํำฮ࠭℘"))
				return
			l1lllllllll_l1_ = server+l1lllllllll_l1_
			l1llllll11l_l1_ = server+l1llllll11l_l1_
			cookies = response.cookies
			if l11lll_l1_ (u"ࠪࡔࡘ࡙ࡉࡅࠩℙ") in cookies.keys():
				l1llllllll1_l1_ = cookies[l11lll_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࠪℚ")]
				#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩℛ"):l1l11111l_l1_(),l11lll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ℜ"):l11lll_l1_ (u"ࠧࡑࡕࡖࡍࡉࡃࠧℝ")+l1llllllll1_l1_}
				headers[l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ℞")] = l11lll_l1_ (u"ࠩࡓࡗࡘࡏࡄ࠾ࠩ℟")+l1llllllll1_l1_
				l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠊࠋࠌࡥࡺࡺࡨࡶࡴ࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࠉࡪࡨࠣࡥࡺࡺࡨࡶࡴ࡯࠾ࠏࠏࠉࠊࠋࠌࡥࡺࡺࡨࡶࡴ࡯ࠤࡂࠦࡳࡦࡴࡹࡩࡷ࠱ࡡࡶࡶ࡫ࡹࡷࡲ࡛࠱࡟ࠍࠍࠎࠏࠉࠊࠥࡤࡹࡹ࡮ࡵࡳ࡮ࠣࡁࠥࡧࡵࡵࡪࡸࡶࡱ࠱ࠧࠧࡸࡀ࠵ࠬࠐࠉࠊࠋࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࠺ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠫ࠭ࢂࠐࠉࠊࠋࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡓࡕ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡧࡵࡵࡪࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ࠩࠋࠋࠌࠍࠎࠏࡨࡵ࡯࡯࠷ࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠎࠏࠉࠊࡥࡲࡳࡰ࡯ࡥࡴࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡱ࡮࡭ࡪࡹࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࠩࡓࡗࡘࡏࡄࠨࠢ࡬ࡲࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡫ࡦࡻࡶࠬ࠮ࡀࠠࠋࠋࠌࠍࠎࠏࠉࡑࡕࡖࡍࡉࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡔࡘ࡙ࡉࡅࠩࡠࠎࠎࠏࠉࠊࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡔࡘ࡙ࡉࡅ࠿ࠪ࠯ࡕ࡙ࡓࡊࡆࠍࠍࠎࠏࠉࠊ࡚ࠥࡖࡎ࡚ࡅࡠࡖࡋࡍࡘ࠮ࡨࡵ࡯࡯࠷࠮ࠐࠉࠊࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯࡬ࡹࡳ࡬࠴ࠫࠍࠍࠎࠏࠉࠊࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫ࡬ࡹࡳ࡬࠴ࠫࠬࠎࠎࠏࠉࠊࠤࠥࠦ℠")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ℡"),l1llllll11l_l1_,l11lll_l1_ (u"ࠬ࠭™"),headers,l11lll_l1_ (u"࠭ࠧ℣"),l11lll_l1_ (u"ࠧࠨℤ"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ℥"))
				#headers = l11lll_l1_ (u"ࠩࠪΩ")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ℧"),l1lllllllll_l1_,l111ll1ll1_l1_,headers,l11lll_l1_ (u"ࠫࠬℨ"),l11lll_l1_ (u"ࠬ࠭℩"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩK"))
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫÅ"),l1111l1l11_l1_,l11lll_l1_ (u"ࠨࠩℬ"),headers,l11lll_l1_ (u"ࠩࠪℭ"),l11lll_l1_ (u"ࠪࠫ℮"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧℯ"))
				l11lll1l_l1_ = response.content
		l1llll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪℰ"),l11lll1l_l1_,re.DOTALL)
		if l1llll1l1_l1_:
			l1llll1l1_l1_ = server+l1llll1l1_l1_[0]
			l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(l1llll1l1_l1_,headers)
			#LOG_THIS(l11lll_l1_ (u"࠭ࠧℱ"),str(l1lll1ll_l1_))
			zz = zip(l1lll1ll_l1_,l1111_l1_)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			for title,link in zz:
				l11l111l_l1_ = title.split(l11lll_l1_ (u"ࠧࠡࠢࠪℲ"))[1]
				# l11l1ll1l_l1_ links
				l1111_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡸ࡬ࡨࡸࡺࡲࡦࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳ࠳ࡶ࠺ࡢࡣࠬℳ")+l11l111l_l1_)
				# download links
				l111ll1l1l_l1_ = link.replace(l11lll_l1_ (u"ࠩ࠲ࡷࡹࡸࡥࡢ࡯࠲ࠫℴ"),l11lll_l1_ (u"ࠪ࠳ࡩࡲ࠯ࠨℵ")).replace(l11lll_l1_ (u"ࠫ࠴ࡹࡴࡳࡧࡤࡱ࠳ࡳ࠳ࡶ࠺ࠪℶ"),l11lll_l1_ (u"ࠬ࠭ℷ"))
				l1111_l1_.append(l111ll1l1l_l1_+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡶࡪࡦࡶࡸࡷ࡫ࡡ࡮ࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡭ࡱ࠶ࡢࡣࠬℸ")+l11l111l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨℹ"),str(l1111_l1_))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ℺"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ℻"),url)
	return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠤࠢࡱࡩࡪࡪࠠࡢࡥࡦࡳࡺࡴࡴࠡࡷࡶࡩࡷ࠵ࡰࡢࡵࡶࠎࠎࠩࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡺࡳࡷࡱࠠࡪࡰࠣࡥࡱࡲࠠࡤࡱࡸࡲࡹࡸࡩࡦࡵࠍࠍࠨࠦࡤࡰࡹࡱࡰࡴࡧࡤࠬࡹࡤࡸࡨ࡮ࠠ࡭࡫ࡱ࡯ࡸࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡳ࡫ࡴ࠰ࡣࡳ࡭ࡄࡩࡡ࡭࡮ࡀࡔࡊࡋࡅ࡫ࡥࡌࡵࡊࡰࡅࡷࡇ࡭ࡱ࡙ࡶࡪࡆ࡛ࡗࡉࡻࡘ࡙ࡆࡇ࡜ࡘࡊࡳࡅࡆ࡬ࡹ࡮ࡊࡰࡅࡈ࡯ࡈ࡮ࡊࡼࡅ࡫ࡪࡎࡥࡵࡋࡨࡂࡥࡦ࡮ࡨ࡛ࡃࡸ࡛ࡈࡲࡩ࡫ࡪࡷ࡬ࡈ࡮ࡽࡏࡡ࡫ࡇࡹࡉ࡯࡬ࡉࡢࡋࡻࡍࡪࡓࡨࡷ࡛ࡈ࡮ࡻࡰࡅ࡫ࡹࡩࡷࡧࡩࡉࡱࡹࡨ࡮ࡊࡼ࡭ࡕࡤࡰࡘࡊࡳࡶࡷࡐࡥࡱࡧࡳࡢ࡮ࡊ࡭ࡉ࡯ࡺࡡࡆ࡬ࡈࡺࡊࡰ࡭ࡕࡲࡥࡻ࡫ࡔࡢ࡮ࡖࡤ࡮ࡻࡰࡅ࡫ࡲࡎࡔࡊࡰࡅࡷࡇ࡭ࡧࡲࡏ࡮ࡥࡧࡦ࡝ࡵࡑࡨࡹࡆࡈ࡮ࡻࡰࡅ࡫ࡥࡌࡼࡊࡰࡅࡷࡇ࡭ࡱ࡞࡟ࡔࡕࡖࡤ࡮ࡊࡨࠦࡢࡷࡷ࡬ࡂ࠶࠹ࡣ࠷ࡦ࠶࠼࠸࠵࠸࠸࠴ࡩ࠶࠺࠹ࡧ࠸࠺࠵࠽࠸࠷ࡤ࠷࠻ࡧ࠹࠸࠵࠷ࡤࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࠿࠳ࡹ࡮ࡥࡢࡦࡁࠤࡁࡺࡢࡰࡦࡼࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠣࡀ࠴ࡹࡰࡢࡰࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀ࠴ࡺࡤ࠿ࠢ࠿ࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢࡴࡹࡦࡲࡩࡵࡻ࠯ࡰ࡮ࡴ࡫࠲࠮࡯࡭ࡳࡱ࠲ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡱࡶࡣ࡯࡭ࡹࡿࠠ࠾ࠢࡴࡹࡦࡲࡩࡵࡻ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠡࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࡹࡷࡲ࠱ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱࡬ࡪࡰ࡮࠵ࠥࠩࠠࠬࠢࠪࠪࡻࡃ࠱ࠨࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫ࡭࡫ࡱ࡯࠷ࠦࠣࠡ࠭ࠣࠫࠫࡼ࠽࠲ࠩࠍࠍࠎࠩࡵࡳ࡮ࠣࡁࠥࡻࡲ࡭࠭ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬ࠱ࡐࡉࡒࡖࡍࡉࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲ࠱ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࡹ࡭ࡩࡹࡴࡳࡧࡤࡱࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡰࡴ࠹ࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠬࠎࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡷࡵࡰ࠷࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲࡶ࠴ࡠࡡࠪ࠯ࡶࡻࡡ࡭࡫ࡷࡽ࠮ࠐࠉࠣࠤࠥℼ")
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊࠥࡦࡳࡴࡱࡩࡦࡵࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡲ࡯࡮࡫ࡳࠋࠋࠦࡔࡍࡖࡓࡊࡆࠣࡁࠥࡩ࡯ࡰ࡭࡬ࡩࡸࡡࠧࡑࡊࡓࡗࡎࡊࠧ࡞ࠌࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳࠋࠋࠦ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡱ࡮࡭ࡪ࠭࡝ࠡ࠿ࠣࠫࡕࡎࡐࡔࡋࡇࡁࠬ࠱ࡐࡉࡒࡖࡍࡉࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠸ࠬࡇࡣ࡯ࡷࡪ࠲ࠧࠨ࠮ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࠲ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠵࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡶࡴ࡯࠷ࠥࡃࠠࡴࡧࡵࡺࡪࡸࠫࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡹࡷࡲ࠳ࠪࠌࠌࠍࡿࠦ࠽ࠡࡼ࡬ࡴ࠭ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠬࠎࠎࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠࡪࡰࠣࡾ࠿ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦࡵ࠽ࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡴࡹࡦࡲࡩࡵࡻࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡗ࡫ࡳ࠻ࠢࠪ࠭ࡠ࠷࡝ࠋࠋࠌࠍࡪࡲࡩࡧࠢࠪࡆ࡜ࡀࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡷࡵࡢ࡮࡬ࡸࡾࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡃ࡙࠽ࠤࠬ࠯࡛࠲࡟࠱ࡷࡵࡲࡩࡵࠪࠪ࡯ࡧࡶࡳࠨࠫ࡞࠴ࡢࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡳࡸࡥࡱ࡯ࡴࡺࠢࡀࠤࠬ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࡻ࡯ࡤࡴࡶࡵࡩࡦࡳ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯࠶ࡹ࠽ࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠬࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠶࠰࠭࠿࡯ࡣࡰࡩࡩࡃࡶࡪࡦࡶࡸࡷ࡫ࡡ࡮ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱ࠸ࡻ࠸ࠨࠫࠍࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࠺ࠋࠋࠦࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠࠬࠢࠪ࠳ࡦࡶࡩࡀࡥࡤࡰࡱࡃࠧࠡ࠭ࠣࡻࡦࡺࡣࡩ࡫ࡷࡩࡲࡡ࠰࡞ࠌࠌࡉࡌ࡛ࡄࡊ࠮ࠣࡉࡌ࡛ࡓࡊࡆ࠯ࠤࡊࡍࡕࡔࡕࠣࡁࠥࡍࡅࡕࡡࡓࡐࡆ࡟࡟ࡕࡑࡎࡉࡓ࡙ࠨࠪࠌࠌ࡭࡫ࠦࡅࡈࡗࡇࡍࡂࡃࠧࠨ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࠻ࠩࡊࡳࡴ࡭࡬ࡦࡤࡲࡸ࠴࠸࠮࠲ࠢࠫ࠯࡭ࡺࡴࡱࠫࠪ࠰ࠥ࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠻ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠥ࠭ࡃࡰࡱ࡮࡭ࡪ࠭࠺ࠨࡇࡊ࡙ࡉࡏ࠽ࠨ࠭ࡈࡋ࡚ࡊࡉࠬࠩ࠾ࠤࡊࡍࡕࡔࡋࡇࡁࠬ࠱ࡅࡈࡗࡖࡍࡉ࠱ࠧ࠼ࠢࡈࡋ࡚࡙ࡓ࠾ࠩ࠮ࡉࡌ࡛ࡓࡔࠢࢀࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࠣࡹࡷࡲࠬࠡࠩࠪ࠰ࠥ࡮ࡥࡢࡦࡨࡶࡸ࠲ࠠࡇࡣ࡯ࡷࡪ࠲ࠧࠨ࠮ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠳࠰࠿ࡓࡇࡖࡓࡑ࡛ࡔࡊࡑࡑࡁ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡫ࡵࡲࠡࡳࡸࡥࡱࡺࡩࡺ࠮ࡸࡶࡱࠦࡩ࡯ࠢࡵࡩࡻ࡫ࡲࡴࡧࡧࠬ࡮ࡺࡥ࡮ࡵࠬ࠾ࠏࠏࠉࠊࡳࡸࡥࡱ࡯ࡴࡺࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩࠦࠨࠨ࡯࠶ࡹ࠽ࠦࠠࠡࠩ࠮ࡵࡺࡧ࡬ࡵ࡫ࡼ࠭ࠏࠏࠉࠊࡦࡤࡸࡦࡩࡡ࡭࡮ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠠࠩࡷࡵࡰ࠮ࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ࠮ࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࠤ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࠦ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠦࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋ࡬ࡪࠥ࠭ࡨࡵࡶࡳࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎࠏࡵࡳ࡮ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࠫ࠴ࡧࡰࡪࡁࡦࡥࡱࡲ࠽ࠨࠢ࠮ࠤࡱ࡯࡮࡬ࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࠻ࠩࡊࡳࡴ࡭࡬ࡦࡤࡲࡸ࠴࠸࠮࠲ࠢࠫ࠯࡭ࡺࡴࡱࠫࠪ࠰ࠥ࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠻ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠥ࠭ࡃࡰࡱ࡮࡭ࡪ࠭࠺ࠨࡇࡊ࡙ࡉࡏ࠽ࠨ࠭ࡈࡋ࡚ࡊࡉࠬࠩ࠾ࠤࡊࡍࡕࡔࡋࡇࡁࠬ࠱ࡅࡈࡗࡖࡍࡉ࠱ࠧ࠼ࠢࡈࡋ࡚࡙ࡓ࠾ࠩ࠮ࡉࡌ࡛ࡓࡔࠢࢀࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࠤࡺࡸ࡬࠭ࠢࠪࠫ࠱ࠦࡨࡦࡣࡧࡩࡷࡹࠬࠡࡈࡤࡰࡸ࡫ࠬࠨࠩ࠯ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧࠪࠌࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣ࡭࡫ࡱ࡯ࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍࠨࡻࡲ࡭ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠࠬࠢࠪ࠳ࡦࡶࡩࡀࡥࡤࡰࡱࡃࠧࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠧ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࠻ࠩࡊࡳࡴ࡭࡬ࡦࡤࡲࡸ࠴࠸࠮࠲ࠢࠫ࠯࡭ࡺࡴࡱࠫࠪ࠰ࠥ࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠻ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠥ࠭ࡃࡰࡱ࡮࡭ࡪ࠭࠺ࠨࡇࡊ࡙ࡉࡏ࠽ࠨ࠭ࡈࡋ࡚ࡊࡉࠬࠩ࠾ࠤࡊࡍࡕࡔࡋࡇࡁࠬ࠱ࡅࡈࡗࡖࡍࡉ࠱ࠧ࠼ࠢࡈࡋ࡚࡙ࡓ࠾ࠩ࠮ࡉࡌ࡛ࡓࡔࠢࢀࠎࠎࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࠥࡻࡲ࡭࠮ࠣࠫࠬ࠲ࠠࡩࡧࡤࡨࡪࡸࡳ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨࠫࠍࠍࠎࠩࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠍࠨࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮࠲ࠠ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋࠌࠧ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡷࡵࡰࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍࠨ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦࡹࡷࡲࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࡻࡲ࡭ࠢࡀࠤࡺࡸ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠣࡳࡧࡶࡹࡱࡺࠠ࠾ࠢࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮ࡵࡳ࡮࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࠩࡹ࡭ࡩ࡫࡯ࠨࠫࠍࠍࠧࠨࠢℽ")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭ℾ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧℿ"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ⅀"),l11lll_l1_ (u"ࠨ࠭ࠪ⅁"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄࡷ࠽ࠨ⅂") + l111l1l_l1_
	l1111l_l1_(url)
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
l1l11lll_l1_ = [l11lll_l1_ (u"ࠪห้์ฺ่ࠩ⅃"),l11lll_l1_ (u"ࠫฬ๊ำ็หࠪ⅄"),l11lll_l1_ (u"ࠬอไษๆาࠫⅅ")]
l1ll11ll_l1_ = [l11lll_l1_ (u"࠭วๅี้อࠬⅆ"),l11lll_l1_ (u"ࠧศๆ็฾ฮ࠭ⅇ"),l11lll_l1_ (u"ࠨษ็ฬ้ีࠧⅈ"),l11lll_l1_ (u"ࠩส่ิ่ษࠨⅉ"),l11lll_l1_ (u"ࠪห้า่ะหࠪ⅊"),l11lll_l1_ (u"ࠫฬ๊สาฮ่อࠬ⅋"),l11lll_l1_ (u"ࠬอไ็๊฼ࠫ⅌"),l11lll_l1_ (u"࠭วๅฬุ๊๏็ࠧ⅍")]
l1l1l1_l1_ = []
def l1lllllll1_l1_(url):		# should be l11111111l_l1_ to match l1l1ll11_l1_ l111ll1111_l1_
	url = url.split(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫⅎ"))[0]
	#server = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⅏"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⅐"),url,l11lll_l1_ (u"ࠪࠫ⅑"),headers,l11lll_l1_ (u"ࠫࠬ⅒"),l11lll_l1_ (u"ࠬ࠭⅓"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ⅔"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡴࡲࡴࡩࡵࡷ࡯ࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶࠦࠬ⅕"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	zz = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡸࡶࡷ࡫࡮ࡵࡡࡲࡴࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⅖"),block,re.DOTALL)
	l111l1l1ll_l1_,l111l11l1l_l1_ = zip(*zz)
	l1lll11l_l1_ = zip(l111l1l1ll_l1_,l111l11l1l_l1_,l111l1l1ll_l1_)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):		# should be l11111111l_l1_ to match l1l1ll11_l1_ l111ll1111_l1_
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⅗"),block,re.DOTALL)
	l1llllll1l1_l1_ = []
	for link,name in items:
		name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ⅘"))
		value = link.rsplit(l11lll_l1_ (u"ࠫ࠴࠭⅙"),1)[1]
		if name in l1l1l1_l1_: continue
		if l11lll_l1_ (u"๊ࠬไไสสีࠬ⅚") in name: continue
		if l11lll_l1_ (u"࠭ࡔࡗ࠯ࡐࡅࠬ⅛") in name: continue
		if l11lll_l1_ (u"ࠧࡕࡘ࠰࠵࠹࠭⅜") in name: continue
		#if value==l11lll_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨ⅝"): name = l11lll_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩ⅞")
		#elif value==l11lll_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪ⅟"): name = l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭Ⅰ")
		#if l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫⅡ") not in value: value = name
		#else: value = re.findall(l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧⅢ"),value,re.DOTALL)[0]
		l1llllll1l1_l1_.append((value,name))
	return l1llllll1l1_l1_
def l11111llll_l1_(l1l1llll_l1_,url):		# should be l11111111l_l1_ to match l1l1ll11_l1_ l111ll1111_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨⅣ"),l11lll_l1_ (u"ࠨࠩⅤ"),l11lll_l1_ (u"ࠩࡊࡉ࡙ࡥࡆࡊࡐࡄࡐࡤ࡛ࡒࡍࡡࡢࡣࡎࡔࠧⅥ"),l1l1llll_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨⅦ")+url)
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨⅧ"),1)[0]
	url = url.strip(l11lll_l1_ (u"ࠬ࠵ࠧⅨ"))
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨⅩ"))		# l1lllllll1l_l1_ be l11111111l_l1_
	l1l1111l_l1_ = l1l1111l_l1_.replace(l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫⅪ"),l11lll_l1_ (u"ࠨ࠯ࠪⅫ"))
	url = url+l11lll_l1_ (u"ࠩ࠲ࠫⅬ")+l1l1111l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫⅭ"),l11lll_l1_ (u"ࠫࠬⅮ"),l11lll_l1_ (u"ࠬࡍࡅࡕࡡࡉࡍࡓࡇࡌࡠࡗࡕࡐࡤࡥ࡟ࡐࡗࡗࠫⅯ"),url)
	return url
def l1lll1l1_l1_(url,filter):		# l1111l1lll_l1_ l11111l11l_l1_ l111l11lll_l1_ minor l1llllll1ll_l1_ l1l1l1llll_l1_ it is l111l11111_l1_ not to l11l111ll1_l1_ l111l1llll_l1_ all
	#filter = filter.replace(l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⅰ"),l11lll_l1_ (u"ࠧࠨⅱ"))
	if l11lll_l1_ (u"ࠨࡁࠪⅲ") in url: url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ⅳ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧⅴ"),1)
	if filter==l11lll_l1_ (u"ࠫࠬⅵ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠬ࠭ⅶ"),l11lll_l1_ (u"࠭ࠧⅷ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫⅸ"))
	if type==l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫⅹ"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠩࡀࠫⅺ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠪࡁࠬⅻ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ⅼ")+category+l11lll_l1_ (u"ࠬࡃ࠰ࠨⅽ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨⅾ")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪⅿ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪↀ"))+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ↁ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬↂ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧↃ")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩↄ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩↅ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩↆ")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫↇ")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ↈ")+l1l11l11_l1_
		l11l1l1_l1_ = l11111llll_l1_(l1l11l11_l1_,l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ↉"),l111ll_l1_+l11lll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ↊"),l11l1l1_l1_,121)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ↋"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭↌")+l11lll11_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭↍"),l11l1l1_l1_,121)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭↎"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ↏"),l11lll_l1_ (u"ࠪࠫ←"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		l1ll1lll_l1_ = l1ll1lll_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭↑"))
		name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ→"))
		name = name.replace(l11lll_l1_ (u"࠭࠭࠮ࠩ↓"),l11lll_l1_ (u"ࠧࠨ↔"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠨ࠿ࠪ↕") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ↖"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					l11l1l1_l1_ = l11111llll_l1_(l1l11l11_l1_,url)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ↗")+l1l1l11l_l1_)
				return
			else:
				l11l1l1_l1_ = l11111llll_l1_(l1l11l11_l1_,l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ↘"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭↙"),l11l1l1_l1_,121)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↚"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ↛"),l11l11l_l1_,125,l11lll_l1_ (u"ࠨࠩ↜"),l11lll_l1_ (u"ࠩࠪ↝"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭↞"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭↟")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ↠")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ↡")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ↢")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ↣")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ↤"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ↥")+name,l11l11l_l1_,124,l11lll_l1_ (u"ࠫࠬ↦"),l11lll_l1_ (u"ࠬ࠭↧"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ↨"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ↩")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ↪")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ↫")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ↬")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ↭")+l1l1llll_l1_
			#title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ↮")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"࠭࠰ࠨ↯")]
			title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ↰")+name
			if type==l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ↱"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ↲"),l111ll_l1_+title,url,124,l11lll_l1_ (u"ࠪࠫ↳"),l11lll_l1_ (u"ࠫࠬ↴"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ↵"))
			elif type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ↶") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠧ࠾ࠩ↷") in l1l11l1l_l1_:
				l11l1l1_l1_ = l11111llll_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↸"),l111ll_l1_+title,l11l1l1_l1_,121)
			else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ↹"),l111ll_l1_+title,url,125,l11lll_l1_ (u"ࠪࠫ↺"),l11lll_l1_ (u"ࠫࠬ↻"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):		# l1111l1l1l_l1_ not l11l111ll1_l1_ l111111l11_l1_ here
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ↼")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ↽")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ↾")			all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠨ࠿ࠩࠫ↿"),l11lll_l1_ (u"ࠩࡀ࠴ࠫ࠭⇀"))
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠬ⇁"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠫࡂ࠭⇂") in filters:
		items = filters.split(l11lll_l1_ (u"ࠬࠬࠧ⇃"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"࠭࠽ࠨ⇄"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠧࠨ⇅")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪ⇆")
		if l11lll_l1_ (u"ࠩࠨࠫ⇇") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⇈") and value!=l11lll_l1_ (u"ࠫ࠵࠭⇉"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩ⇊")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⇋") and value!=l11lll_l1_ (u"ࠧ࠱ࠩ⇌"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⇍")+key+l11lll_l1_ (u"ࠩࡀࠫ⇎")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⇏"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭⇐")+key+l11lll_l1_ (u"ࠬࡃࠧ⇑")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪ⇒"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⇓"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨ࠿࠳ࠫ⇔"),l11lll_l1_ (u"ࠩࡀࠫ⇕"))
	return l1ll1l1l_l1_
l11lll_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡋࡊ࡚࡟ࡖࡕࡈࡖࡓࡇࡍࡆࡡࡓࡅࡘ࡙ࡗࡐࡔࡇࠬ࠮ࡀࠊࠊࡶࡨࡼࡹࠦ࠽๊ࠡࠩิฬࠦวๅ็๋ๆ฾๊ࠦฮฬสะࠥอำๆࠢาาํ๊้ࠠๅ็้ฮࠦวๅีิࠤ้้๊ࠡฬึฮ฼๐ูࠡฬื฾๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎࠮ࠡๆ็ัฺ๎ไࠡ฻็๎์๋ࠠใ็ࠣฬๆะอࠡฯึหอࠦๅอษ้๎๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨࠌࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭วๅ็๋ๆ฾ࠦวๅษุ่๏ࠦࠠࠨ࠭ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠱ࡺࡥࡹࡶࠬࠎࠎࡵ࡬ࡥࡷࡶࡩࡷࡴࡡ࡮ࡧࠣࡁࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡨࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡸࡷࡪࡸࠧࠪࠌࠌࡳࡱࡪࡰࡢࡵࡶࡻࡴࡸࡤࠡ࠿ࠣࡷࡪࡺࡴࡪࡰࡪࡷ࠳࡭ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡱࡣࡶࡷࠬ࠯ࠊࠊࡺࡥࡱࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࡢࡶ࡫࡯ࡸ࡮ࡴࠨࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠥࡴࠫࠪࠤࠪࡧࡤࡥࡱࡱࡣ࡮ࡪࠬࠡࡖࡵࡹࡪ࠯ࠊࠊࡰࡨࡻࡺࡹࡥࡳࡰࡤࡱࡪࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡻࡳࡦࡴࠪ࠭ࠏࠏ࡮ࡦࡹࡳࡥࡸࡹࡷࡰࡴࡧࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡴࡦࡹࡳࠨࠫࠍࠍ࡮࡬ࠠࡰ࡮ࡧࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠦࡃ࡮ࡦࡹࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠤࡴࡸࠠࡰ࡮ࡧࡴࡦࡹࡳࡸࡱࡵࡨࠦࡃ࡮ࡦࡹࡳࡥࡸࡹࡷࡰࡴࡧ࠾ࠏࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡅࡋࠪ࠰ࠬ࠭ࠩࠋࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡎࡊࠧ࠭ࠩࠪ࠭ࠏࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡔࡕࠪ࠰ࠬ࠭ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠍࡨࡪ࡬ࠠࡈࡇࡗࡣࡕࡒࡁ࡚ࡡࡗࡓࡐࡋࡎࡔࠪࠬ࠾ࠏࠏࡅࡈࡗࡇࡍࠥࡃࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡪࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡅࡋࠪ࠭ࠏࠏࡅࡈࡗࡖࡍࡉࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡋࡇࡖࡕࡌࡈࠬ࠯ࠊࠊࡇࡊ࡙ࡘ࡙ࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡖࡗࠬ࠯ࠊࠊࡷࡶࡩࡷࡴࡡ࡮ࡧࠣࡁࠥࡓࡉ࡙ࡡࡄࡖࡆࡈࡉࡄࠪࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡵࡴࡧࡵࠫ࠮࠯ࠊࠊࡲࡤࡷࡸࡽ࡯ࡳࡦࠣࡁࠥࡓࡉ࡙ࡡࡄࡖࡆࡈࡉࡄࠪࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡰࡢࡵࡶࠫ࠮࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡹࡥࡳࡰࡤࡱࡪ࠲ࡰࡢࡵࡶࡻࡴࡸࡤࠪࠌࠌ࡭࡫ࠦࡵࡴࡧࡵࡲࡦࡳࡥ࠾࠿ࠪࠫࠥࡵࡲࠡࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࡁࠬ࠭࠺ࠋࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡈࡎ࠭ࠬࠨࠩࠬࠎࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡓࡊࡆࠪ࠰ࠬ࠭ࠩࠋࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡘ࠭ࠬࠨࠩࠬࠎࠎࠏࡇࡆࡖࡢ࡙ࡘࡋࡒࡏࡃࡐࡉࡤࡖࡁࡔࡕ࡚ࡓࡗࡊࠨࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡠ࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭࡝ࠋࠋ࡬ࡪࠥࡋࡇࡖࡆࡌࠥࡂ࠭ࠧ࠻ࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠢࠪࡇࡴࡵ࡫ࡪࡧࠪ࠾ࠬࡋࡇࡖࡆࡌࡁࠬ࠱ࡅࡈࡗࡇࡍ࠰࠭࠻ࠡࡇࡊ࡙ࡘࡏࡄ࠾ࠩ࠮ࡉࡌ࡛ࡓࡊࡆ࠮ࠫࡀࠦࡅࡈࡗࡖࡗࡂ࠭ࠫࡆࡉࡘࡗࡘࠦࡽࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠥ࠭ࠧ࠭ࠢ࡫ࡩࡦࡪࡥࡳࡵ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡉࡈࡘࡤࡖࡌࡂ࡛ࡢࡘࡔࡑࡅࡏࡕ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࡷ࡫ࡧࡪࡵࡷࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡴ࡮࠱ࡩ࡬࡫ࡸࡢ࠰ࡦࡳࡲࡢ࠯ࡳࡧࡪ࡭ࡸࡺࡥࡳࠩ࠯ࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡴࡨ࡫࡮ࡹࡴࡦࡴ࠽ࠎࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡅࡋࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡇࡊ࡙ࡘࡏࡄࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡖࡗࠬ࠲ࠧࠨࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫࡳࡵࠠ࡯ࡧࡺࠤࡱࡵࡧࡪࡰࠣࡲࡪ࡫ࡤࡦࡦ࠯ࠤࡾࡵࡵࠡࡹࡨࡶࡪࠦࡡ࡭ࡴࡨࡥࡩࡿࠠ࡭ࡱࡪ࡫ࡪࡪࠠࡪࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡠࠦࡅࡈࡗࡇࡍ࠱ࠦࡅࡈࡗࡖࡍࡉ࠲ࠠࡆࡉࡘࡗࡘࠦ࡝ࠋࠋࡦ࡬ࡦࡸ࡟ࡴࡧࡷࠤࡂࠦࡳࡵࡴ࡬ࡲ࡬࠴ࡡࡴࡥ࡬࡭ࡤࡻࡰࡱࡧࡵࡧࡦࡹࡥࠡ࠭ࠣࡷࡹࡸࡩ࡯ࡩ࠱ࡨ࡮࡭ࡩࡵࡵࠣ࠯ࠥࡹࡴࡳ࡫ࡱ࡫࠳ࡧࡳࡤ࡫࡬ࡣࡱࡵࡷࡦࡴࡦࡥࡸ࡫ࠊࠊࡴࡤࡲࡩࡵ࡭ࡔࡶࡵ࡭ࡳ࡭ࠠ࠾ࠢࠪࠫ࠳ࡰ࡯ࡪࡰࠫࡶࡦࡴࡤࡰ࡯࠱ࡷࡦࡳࡰ࡭ࡧࠫࡧ࡭ࡧࡲࡠࡵࡨࡸ࠯࠷࠵࠭ࠢ࠴࠹࠮࠯ࠊࠊࡷࡵࡰࠥࡃࠠࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡷࡱ࠴ࡥࡨࡧࡻࡥ࠳ࡩ࡯࡮࠱࡯ࡳ࡬࡯࡮࠰ࠤࠍࠍࠨࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠡ࠿ࠣࠫ࠵࠹ࡁࡐࡎࡗࡆࡑࡗࡄࡵ࡯ࡨࡍࡨ࡚࠸ࡍ࠷࠼ࡈࡵࢀ࡮ࡈ࠲ࡳ࠵࡜ࡉ࡫ࡩࡪࡸࡱ࡭࡫࡫ࡢ࡯࡛ࡓࡩࡇ࠱࡬࠻ࡎ࠺ࡨ࡙ࡵࡠࡇ࡜ࡥࡹࡼࡪࡉ࠯ࡕࡴࡰࡎ࡮ࡒࡪ࠷ࡘࡐ࡮ࡊ࡭࠺ࡕ࡚ࡻࡹ࡟ࡪࡲࡻ࡮ࡨ࠼ࡪࡊࡧࡄ࡝ࡗࡪࡢࡨࡧࡢࡋࡷࡗࡤࡷࡖ࠷ࡻࡍ࡝࡭ࡠࡎࡹ࠺ࡑ࠸࠳࡛ࡇࡪࡊࡔࡲࡸࡩࡣࡹ࡚࡭ࡽࡨࡲ࠴ࡒࡩࡉࡍࡋ࠮ࡤࡲࡲࡘ࡙ࡓࡊࡗ࠷ࡵ࡮ࡎࡏࡵࡔࡩࡦࡼ࡝࠸ࡋࡨࡋࡒ࠲ࡏࡺࡹࡤ࠰ࡘࡽࡓ࠶ࡐ࡙࡝ࡐ࠷ࡰࡵࡉࡻࡪࡰ࡯ࡳࡆࡄ࡬ࡉ࡜࠺ࡋ࡟ࡵࡨ࡜࠶࡝ࡐࡶࡎࡳࡊࡗ࡯࡮ࡆࡢ࠷ࡻ࡝ࡼࡧࡴ࡙࠯ࡦࡱࡵ࡞࠷࡙࠲ࡐࡽ࠾ࡗ࠷࡮࡭ࡳࡹ࠽࠼ࡁ࠮ࡌࡰ࡜ࡹࡩ࡯ࡵࡥ࡛ࡳࡓ࠼ࡗࡂ࡯࡙ࡻ࡚࡟࡯࡮ࡎࡓࡔ࡞ࡾࡰࡧࡣࡳࡎࡳ࡬ࡗ࡙࠵ࡅࡻ࠽࠹࠳࡚ࡍࡇࡣࡇࡊࡗࡸࡸࡗ࡜࡯࡬ࡗࡠࡒࡨࡒ࡚ࡪࡊࡉ࠹ࡉࡻࡑ࠿ࡴ࡯࠷ࡢ࡫࡭ࡊࡱࡗࡧࡢࡰࡖࡱࡨࡱ࠸ࡲࡳ࡝ࡳࡖࡵ࡬ࡐࡅࡳ࠿࡟ࡎ࠶ࠪࠎࠎࠩࡲࡦࡥࡤࡴࡹࡩࡨࡢࠢࡀࠤࠬ࠭ࠊࠊࡲࡤࡽࡱࡵࡡࡥࠢࡀࠤࠧࠨࠊࠊࡲࡤࡽࡱࡵࡡࡥࠢ࠮ࡁࠥࠨ࠭࠮࠯࠰࠱࠲࡝ࡥࡣࡍ࡬ࡸࡋࡵࡲ࡮ࡄࡲࡹࡳࡪࡡࡳࡻࠥ࠯ࡷࡧ࡮ࡥࡱࡰࡗࡹࡸࡩ࡯ࡩ࠮ࠦࡡࡴࡃࡰࡰࡷࡩࡳࡺ࠭ࡅ࡫ࡶࡴࡴࡹࡩࡵ࡫ࡲࡲ࠿ࠦࡦࡰࡴࡰ࠱ࡩࡧࡴࡢ࠽ࠣࡲࡦࡳࡥ࠾࡞ࠥࡥ࡯ࡧࡸ࡝ࠤ࡟ࡲࡡࡴ࠱࡝ࡰࠥࠎࠎࡶࡡࡺ࡮ࡲࡥࡩࠦࠫ࠾ࠢࠥ࠱࠲࠳࠭࠮࠯࡚ࡩࡧࡑࡩࡵࡈࡲࡶࡲࡈ࡯ࡶࡰࡧࡥࡷࡿࠢࠬࡴࡤࡲࡩࡵ࡭ࡔࡶࡵ࡭ࡳ࡭ࠫࠣ࡞ࡱࡇࡴࡴࡴࡦࡰࡷ࠱ࡉ࡯ࡳࡱࡱࡶ࡭ࡹ࡯࡯࡯࠼ࠣࡪࡴࡸ࡭࠮ࡦࡤࡸࡦࡁࠠ࡯ࡣࡰࡩࡂࡢࠢࡥࡱ࡟ࠦࡡࡴ࡜࡯࡮ࡲ࡫࡮ࡴ࡜࡯ࠤࠍࠍࡵࡧࡹ࡭ࡱࡤࡨࠥ࠱࠽ࠡࠤ࠰࠱࠲࠳࠭࠮࡙ࡨࡦࡐ࡯ࡴࡇࡱࡵࡱࡇࡵࡵ࡯ࡦࡤࡶࡾࠨࠫࡳࡣࡱࡨࡴࡳࡓࡵࡴ࡬ࡲ࡬࠱ࠢ࡝ࡰࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡈ࡮ࡹࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠻ࠢࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦ࡮ࡢ࡯ࡨࡁࡡࠨࡥ࡮ࡣ࡬ࡰࡡࠨ࡜࡯࡞ࡱࠦ࠰ࡻࡳࡦࡴࡱࡥࡲ࡫ࠫࠣ࡞ࡱࠦࠏࠏࡰࡢࡻ࡯ࡳࡦࡪࠠࠬ࠿ࠣࠦ࠲࠳࠭࠮࠯࠰࡛ࡪࡨࡋࡪࡶࡉࡳࡷࡳࡂࡰࡷࡱࡨࡦࡸࡹࠣ࠭ࡵࡥࡳࡪ࡯࡮ࡕࡷࡶ࡮ࡴࡧࠬࠤ࡟ࡲࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡊࡩࡴࡲࡲࡷ࡮ࡺࡩࡰࡰ࠽ࠤ࡫ࡵࡲ࡮࠯ࡧࡥࡹࡧ࠻ࠡࡰࡤࡱࡪࡃ࡜ࠣࡲࡤࡷࡸࡽ࡯ࡳࡦ࡟ࠦࡡࡴ࡜࡯ࠤ࠮ࡴࡦࡹࡳࡸࡱࡵࡨ࠰ࠨ࡜࡯ࠤࠍࠍࠨࡶࡡࡺ࡮ࡲࡥࡩࠦࠫ࠾ࠢࠥ࠱࠲࠳࠭࠮࠯࡚ࡩࡧࡑࡩࡵࡈࡲࡶࡲࡈ࡯ࡶࡰࡧࡥࡷࡿࠢࠬࡴࡤࡲࡩࡵ࡭ࡔࡶࡵ࡭ࡳ࡭ࠫࠣ࡞ࡱࡇࡴࡴࡴࡦࡰࡷ࠱ࡉ࡯ࡳࡱࡱࡶ࡭ࡹ࡯࡯࡯࠼ࠣࡪࡴࡸ࡭࠮ࡦࡤࡸࡦࡁࠠ࡯ࡣࡰࡩࡂࡢࠢࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࡜ࠣ࡞ࡱࡠࡳࠨࠫࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠮ࠦࡡࡴࠢࠋࠋࡳࡥࡾࡲ࡯ࡢࡦࠣ࠯ࡂࠦࠢ࠮࠯࠰࠱࠲࠳ࡗࡦࡤࡎ࡭ࡹࡌ࡯ࡳ࡯ࡅࡳࡺࡴࡤࡢࡴࡼࠦ࠰ࡸࡡ࡯ࡦࡲࡱࡘࡺࡲࡪࡰࡪ࠯ࠧࡢ࡮ࡄࡱࡱࡸࡪࡴࡴ࠮ࡆ࡬ࡷࡵࡵࡳࡪࡶ࡬ࡳࡳࡀࠠࡧࡱࡵࡱ࠲ࡪࡡࡵࡣ࠾ࠤࡳࡧ࡭ࡦ࠿࡟ࠦࡻࡧ࡬ࡇࡱࡵࡱࡡࠨ࡜࡯࡞ࡱࡠࡳࠨࠊࠊࡲࡤࡽࡱࡵࡡࡥࠢ࠮ࡁࠥࠨ࠭࠮࠯࠰࠱࠲࡝ࡥࡣࡍ࡬ࡸࡋࡵࡲ࡮ࡄࡲࡹࡳࡪࡡࡳࡻࠥ࠯ࡷࡧ࡮ࡥࡱࡰࡗࡹࡸࡩ࡯ࡩ࠮ࠦ࠲࠳ࠢࠋࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭ࡶࡡࡺ࡮ࡲࡥࡩ࠲ࠠ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠊࠊࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ࠼ࠣࠦࡲࡻ࡬ࡵ࡫ࡳࡥࡷࡺ࠯ࡧࡱࡵࡱ࠲ࡪࡡࡵࡣ࠾ࠤࡧࡵࡵ࡯ࡦࡤࡶࡾࡃ࠭࠮࠯࠰࡛ࡪࡨࡋࡪࡶࡉࡳࡷࡳࡂࡰࡷࡱࡨࡦࡸࡹࠣ࠭ࡵࡥࡳࡪ࡯࡮ࡕࡷࡶ࡮ࡴࡧ࠭ࠌࠌࠧࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠠࠣࡒࡖࡗࡎࡊ࠽ࠣ࠭ࡓࡗࡘࡏࡄࠬࠤ࠾ࠤࡏ࡙࡟ࡕࡋࡐࡉ࡟ࡕࡎࡆࡡࡒࡊࡋ࡙ࡅࡕ࠿࠴࠼࠵࠶࠰ࠣ࠮ࠍࠍࠬࡘࡥࡧࡧࡵࡩࡷ࠭࠺ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡸࡲ࠮ࡦࡩࡨࡼࡦ࠴ࡣࡰ࡯࠲ࡰࡴ࡭ࡩ࡯࠱ࡂࡨࡴࡳࡡࡪࡰࡀࠫ࠰ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱࠲ࠫ࠮ࡡ࠱࡞࠭ࠪࠪࡺࡸ࡬࠾ࡴࡨࡪࠬࠐࠉࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡓࡓࡘ࡚ࠧ࠭ࠢࡸࡶࡱ࠲ࠠࡱࡣࡼࡰࡴࡧࡤ࠭ࠢ࡫ࡩࡦࡪࡥࡳࡵ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡉࡈࡘࡤࡖࡌࡂ࡛ࡢࡘࡔࡑࡅࡏࡕ࠰࠶ࡳࡪࠧࠪࠌࠌࡧࡴࡵ࡫ࡪࡧࡶࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡳࡰ࡯ࡥࡴࠌࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮ࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵ࠮ࠣࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎ࡯ࡦࠡࠩࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠧࡩࡡࡱࡶࡦ࡬ࡦࠨࠧࠡ࡫ࡱࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺ࠺ࠋࠋࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ๅีๅ็อࠥาฯศ่ࠢึ฾าษࠡฬัูࠥา็ศิๆࠤๆ่ืࠨ࠮้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ๏ืแืࠢาาํ๊ใࠡษ็๎์๋ࠠษวึฮำีวๆࠢๆ์ิ๐ࠠ࠯࠰࠱ࠤาอ่ๅࠢไู้ࠦวๅษ้ฮึ์๊ห๋ࠢห฾อฯสࠢิฬ฼ํวࠡๆอัฺฺ๊ࠠๆ์ࠤ฾์่ศ่ࠣࡍࡕࠦฬะ์าࠤ࠳࠴࠮ࠡษ๋ࠤฬ฿ฯࠡษ็้าอ่ๅหࠣฬ฾ีฺࠠัฬࠤฬ๐วๆࠢส์ࠥ฿ฯสࠢสืฬฮฺ๊ࠩࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳ࡛ࠦࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࡟ࠍࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡨࡵ࡯࡬࡫ࡨࡷ࠮ࡂ࠳࠻ࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧๆึๆ่ฮࠦแ๋ࠢอืั๐ไࠡษ็ำำ๎ไࠡๆ็้ํู่ࠨ࠮ࠪัฬ๎ไࠡษุ่ฬำࠠศี่ࠤฬ๊ฯฯ๊็ࠤํ้ไๆหࠣหู้ัࠡๆๆ๎ࠥะสๆๅ้ࠤ๊์ࠠหึ฽๎้ࠦวๅใํำ๏๎ࠠษื๋ีฮࠦีฮ์ะอࠬ࠯ࠊࠊࠋࡊࡉ࡙ࡥࡕࡔࡇࡕࡒࡆࡓࡅࡠࡒࡄࡗࡘ࡝ࡏࡓࡆࠫ࠭ࠏࠏࠉࡳࡧࡷࡹࡷࡴࠠ࡜ࠩࠪ࠰ࠬ࠭ࠬࠨࠩࡠࠎࠎࡋࡇࡖࡆࡌࠤࡂࠦࡣࡰࡱ࡮࡭ࡪࡹ࡛ࠨࡇࡊ࡙ࡉࡏࠧ࡞ࠌࠌࡉࡌ࡛ࡓࡊࡆࠣࡁࠥࡩ࡯ࡰ࡭࡬ࡩࡸࡡࠧࡆࡉࡘࡗࡎࡊࠧ࡞ࠌࠌࡉࡌ࡛ࡓࡔࠢࡀࠤࡨࡵ࡯࡬࡫ࡨࡷࡠ࠭ࡅࡈࡗࡖࡗࠬࡣࠊࠊࡶ࡬ࡱࡪ࠴ࡳ࡭ࡧࡨࡴ࠭࠷ࠩࠋࠋࡸࡶࡱࠦ࠽ࠡࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡸࡲ࠮ࡦࡩࡨࡼࡦ࠴ࡣࡰ࡯࠲ࡪ࡮ࡴࡩࡴࡪ࠲ࠦࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡆࡉࡘࡈࡎࡃࠧࠬࡇࡊ࡙ࡉࡏࠫࠨ࠽ࠣࡉࡌ࡛ࡓࡊࡆࡀࠫ࠰ࡋࡇࡖࡕࡌࡈ࠰࠭࠻ࠡࡇࡊ࡙ࡘ࡙࠽ࠨ࠭ࡈࡋ࡚࡙ࡓࠡࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࠢࡸࡶࡱ࠲ࠠࠨࠩ࠯ࠤ࡭࡫ࡡࡥࡧࡵࡷ࠱ࠦࡔࡳࡷࡨ࠰ࠬ࠭ࠬࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡊࡉ࡙ࡥࡐࡍࡃ࡜ࡣ࡙ࡕࡋࡆࡐࡖ࠱࠸ࡸࡤࠨࠫࠍࠍࡨࡵ࡯࡬࡫ࡨࡷࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡴࡱࡩࡦࡵࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡴࡶࡵࠬࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠩ࠭ࡵࡷࡶ࠭ࡩ࡯ࡰ࡭࡬ࡩࡸ࠯ࠩࠋࠋࡈࡋ࡚ࡊࡉࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡋࡇࡖࡆࡌࠫࡢࠐࠉࡆࡉࡘࡗࡎࡊࠠ࠾ࠢࡦࡳࡴࡱࡩࡦࡵ࡞ࠫࡊࡍࡕࡔࡋࡇࠫࡢࠐࠉࡆࡉࡘࡗࡘࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡉࡌ࡛ࡓࡔࠩࡠࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚ࡊࡉࠨ࠮ࡈࡋ࡚ࡊࡉࠪࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡎࡊࠧ࠭ࡇࡊ࡙ࡘࡏࡄࠪࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡘ࠭ࠬࡆࡉࡘࡗࡘ࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬࡹࡵࡤࡥࡨࡷࡸ࠲ࠠࡺࡱࡸࠤ࡯ࡻࡳࡵࠢ࡯ࡳ࡬࡭ࡥࡥࠢ࡬ࡲࠥࡴ࡯ࡸࠩ࠯ࠫࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡ࡝ࠣࡉࡌ࡛ࡄࡊ࠮ࠣࡉࡌ࡛ࡓࡊࡆ࠯ࠤࡊࡍࡕࡔࡕࠣࡡࠏࠨࠢࠣ⇖")
#===================================================================================================
# l11111ll11_l1_ of the below code l1111111l1_l1_ added from:
# https://github.com/zombiB/zombi-addons/blob/master/plugin.video.matrix/resources/l111l111ll_l1_/l111l1l111_l1_.py
# https://gitlab.com/Rgysoft/iptv-host-e2iplayer/-/blob/master/IPTVPlayer/tsiplayer/l11111l111_l1_/l1111ll111_l1_.py
#===================================================================================================
def l111l1ll11_l1_(l111111111_l1_):
	m = re.search(l11lll_l1_ (u"ࡶࠬࡤࠨ࡝ࡦ࠮࠭ࡠ࠴ࠬ࡞ࡁ࡟ࡨ࠯ࡅࠧ⇗"), str(l111111111_l1_))
	return int(m.groups()[-1]) if m and not callable(l111111111_l1_) else 0
def l111ll111l_l1_(l1111l1111_l1_):
	try:
		l111l111l1_l1_ = base64.b64decode(l1111l1111_l1_)
	except:
		try:
			l111l111l1_l1_ = base64.b64decode(l1111l1111_l1_+l11lll_l1_ (u"ࠬࡃࠧ⇘"))
		except:
			try:
				l111l111l1_l1_ = base64.b64decode(l1111l1111_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩ⇙"))
			except:
				l111l111l1_l1_ = l11lll_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡨࡡࡴࡧ࠹࠸ࠥࡪࡥࡤࡱࡧࡩࠥ࡫ࡲࡳࡱࡵࠫ⇚")
	if kodi_version>18.99: l111l111l1_l1_ = l111l111l1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⇛"))
	return l111l111l1_l1_
def l111111ll1_l1_(l111l1111l_l1_,l1111lll11_l1_,a):
	a = a - l1111lll11_l1_
	if a<0:
		c = l11lll_l1_ (u"ࠩࡸࡲࡩ࡫ࡦࡪࡰࡨࡨࠬ⇜")
	else:
		c = l111l1111l_l1_[a]
	return c
def x(l111l1111l_l1_,l1111lll11_l1_,a):
	return(l111111ll1_l1_(l111l1111l_l1_,l1111lll11_l1_,a))
def l1111llll1_l1_(l111l1lll1_l1_,step,l1111lll11_l1_,l1111l111l_l1_):
	l1111l111l_l1_ = l1111l111l_l1_.replace(l11lll_l1_ (u"ࠪࡺࡦࡸࠠࠨ⇝"),l11lll_l1_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯ࠤࡩࡁࠠࠨ⇞"))
	l1111l111l_l1_ = l1111l111l_l1_.replace(l11lll_l1_ (u"ࠬࡾࠨࠨ⇟"),l11lll_l1_ (u"࠭ࡸࠩࡶࡤࡦ࠱ࡹࡴࡦࡲ࠵࠰ࠬ⇠"))
	#exec(l1111l111l_l1_)
	l1111l111l_l1_ = l1111l111l_l1_.replace(l11lll_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡥ࠽ࠣࡨࡂ࠭⇡"),l11lll_l1_ (u"ࠨࠩ⇢"))
	d = eval(l1111l111l_l1_,{l11lll_l1_ (u"ࠩࡳࡥࡷࡹࡥࡊࡰࡷࠫ⇣"):l111l1ll11_l1_,l11lll_l1_ (u"ࠪࡼࠬ⇤"):x,l11lll_l1_ (u"ࠫࡹࡧࡢࠨ⇥"):l111l1lll1_l1_,l11lll_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫ⇦"):l1111lll11_l1_})
	l111lll11l_l1_=0
	while True:
		l111lll11l_l1_=l111lll11l_l1_+1
		l111l1lll1_l1_.append(l111l1lll1_l1_[0])
		del l111l1lll1_l1_[0]
		#_print([i for i in l111l1lll1_l1_[0:10]])
		#_print(str(l111lll11l_l1_)+l11lll_l1_ (u"࠭࠺ࠨ⇧")+str(c))
		#exec(l1111l111l_l1_)
		d = eval(l1111l111l_l1_,{l11lll_l1_ (u"ࠧࡱࡣࡵࡷࡪࡏ࡮ࡵࠩ⇨"):l111l1ll11_l1_,l11lll_l1_ (u"ࠨࡺࠪ⇩"):x,l11lll_l1_ (u"ࠩࡷࡥࡧ࠭⇪"):l111l1lll1_l1_,l11lll_l1_ (u"ࠪࡷࡹ࡫ࡰ࠳ࠩ⇫"):l1111lll11_l1_})
		if ((d == step) or (l111lll11l_l1_>10000)): break
	return
def l111111lll_l1_(l1111lllll_l1_):
	tmp = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲ࠯ࠬࡂࡁ࠭࠴ࡻ࠳࠮࠷ࢁ࠮ࡢࠨ࡝ࠫࠪ⇬"), l1111lllll_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠬࡋࡒࡓ࠼࡙ࡥࡷࡩ࡯࡯ࡵࡷࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ⇭")
	l1111111ll_l1_ = tmp[0].strip()
	_print(l11lll_l1_ (u"࠭ࡖࡢࡴࡦࡳࡳࡹࡴࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪ⇮") % l1111111ll_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠧࡾ࡞ࠫࠫ⇯")+l1111111ll_l1_+l11lll_l1_ (u"ࠨࡁ࠯ࠬ࠵ࡾ࡛࠱࠯࠼ࡥ࠲࡬࡝ࡼ࠳࠯࠵࠵ࢃࠩ࡝ࠫ࡟࠭ࡀ࠭⇰"), l1111lllll_l1_)
	if not tmp: return l11lll_l1_ (u"ࠩࡈࡖࡗࡀࠠࡔࡶࡨࡴ࠶ࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ⇱")
	step = eval(tmp[0])
	_print(l11lll_l1_ (u"ࠪࡗࡹ࡫ࡰ࠲ࠢࠣࠤࠥࠦࠠࠡࠢࡀࠤ࠵ࡾࠥࡴࠩ⇲") % l11lll_l1_ (u"ࠫࢀࡀ࠰࠳࡚ࢀࠫ⇳").format(step).lower())
	tmp = re.findall(l11lll_l1_ (u"ࠬࡪ࠽ࡥ࠯ࠫ࠴ࡽࡡ࠰࠮࠻ࡤ࠱࡫ࡣࡻ࠲࠮࠴࠴ࢂ࠯࠻ࠨ⇴"), l1111lllll_l1_)
	if not tmp: return l11lll_l1_ (u"࠭ࡅࡓࡔ࠽ࡗࡹ࡫ࡰ࠳ࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬ⇵")
	l1111lll11_l1_ = eval(tmp[0])
	_print(l11lll_l1_ (u"ࠧࡔࡶࡨࡴ࠷ࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡ࠲ࡻࠩࡸ࠭⇶") % l11lll_l1_ (u"ࠨࡽ࠽࠴࠷࡞ࡽࠨ⇷").format(l1111lll11_l1_).lower())
	tmp = re.findall(l11lll_l1_ (u"ࠤࡷࡶࡾࢁࠨࡷࡣࡵ࠲࠯ࡅࠩ࠼ࠤ⇸"), l1111lllll_l1_)
	if not tmp: return l11lll_l1_ (u"ࠪࡉࡗࡘ࠺ࡥࡧࡦࡥࡱࡥࡦ࡯ࡥࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭⇹")
	l1111l111l_l1_ = tmp[0]
	_print(l11lll_l1_ (u"ࠫࡉ࡫ࡣࡢ࡮ࠣࡪࡺࡴࡣࠡࠢࠣࡁࠥࠨࠠࠦࡵ࠱࠲࠳ࠨࠧ⇺") % l1111l111l_l1_[0:135])
	tmp = re.findall(l11lll_l1_ (u"ࠧ࠭ࡤࡢࡶࡤࠫ࠿ࢁࠧࠩࡡ࡞࠴࠲࠿ࡡ࠮ࡼࡄ࠱࡟ࡣࡻ࠲࠲࠯࠶࠵ࢃࠩࠨ࠼ࠪࡳࡰ࠭ࠢ⇻"), l1111lllll_l1_)
	if not tmp: return l11lll_l1_ (u"࠭ࡅࡓࡔ࠽ࡔࡴࡹࡴࡌࡧࡼࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ⇼")
	l111l1l11l_l1_ = tmp[0]
	_print(l11lll_l1_ (u"ࠧࡑࡱࡶࡸࡐ࡫ࡹࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ⇽") % l111l1l11l_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠣࡨࡸࡲࡨࡺࡩࡰࡰࠣࠦ⇾")+l1111111ll_l1_+l11lll_l1_ (u"ࠤ࠱࠮ࡄࡼࡡࡳ࠰࠭ࡃࡂ࠮࡜࡜࠰࠭ࡃࡢ࠯ࠢ⇿"), l1111lllll_l1_)
	if not tmp: return l11lll_l1_ (u"ࠪࡉࡗࡘ࠺ࡕࡣࡥࡐ࡮ࡹࡴࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ∀")
	l1111ll11l_l1_ = tmp[0]
	l1111ll11l_l1_ = l1111111ll_l1_ + l11lll_l1_ (u"ࠦࡂࠨ∁") + l1111ll11l_l1_
	exec(l1111ll11l_l1_) in globals(), locals()
	l111l1111l_l1_ = locals()[l1111111ll_l1_]
	_print(l1111111ll_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩ࠳࠿࠰ࡴ࠰࠱࠲ࠬ∂")%str(l111l1111l_l1_))
	l1111llll1_l1_(l111l1111l_l1_,step,l1111lll11_l1_,l1111l111l_l1_)
	_print(l1111111ll_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪ࠴࠹࠱ࡵ࠱࠲࠳࠭∃")%str(l111l1111l_l1_))
	tmp = re.findall(l11lll_l1_ (u"ࠢ࡝ࠪ࡟࠭ࡀ࠮ࡶࡢࡴࠣ࠲࠯ࡅࠩ࡝ࠦ࡟ࠬࠬࡢࠪࠨ࡞ࠬࠦ∄"), l1111lllll_l1_, re.S)
	if not tmp:
		tmp = re.findall(l11lll_l1_ (u"ࠣࡣ࠳ࡥࡡ࠮࡜ࠪ࠽ࠫ࠲࠯ࡅࠩ࡝ࠦ࡟ࠬࠬࡢࠪࠨ࡞ࠬࠦ∅"), l1111lllll_l1_, re.S)
		if not tmp:
			return l11lll_l1_ (u"ࠩࡈࡖࡗࡀࡌࡪࡵࡷࡣ࡛ࡧࡲࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ∆")
	l111lll111_l1_ = tmp[0]
	l111lll111_l1_ = re.sub(l11lll_l1_ (u"ࠥࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦ࠮ࠫࡁࢀ࠲࠯ࡅࡽࠪࠤ∇"), l11lll_l1_ (u"ࠦࠧ∈"), l111lll111_l1_)
	_print(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡢ࡚ࡦࡸࠠࠡࠢࠣࠤࡂࠦࠥ࠯࠻࠳ࡷ࠳࠴࠮ࠨ∉") % l111lll111_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠨࠨࡠ࡝ࡤ࠱ࡿࡇ࠭ࡻ࠲࠰࠽ࡢࢁ࠴࠭࠺ࢀ࠭ࡂࡢ࡛࡝࡟ࠥ∊") , l111lll111_l1_)
	if not tmp: return l11lll_l1_ (u"ࠧࡆࡔࡕ࠾࠸࡜ࡡࡳࡵࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭∋")
	_1111ll1l1_l1_ = tmp
	_print(l11lll_l1_ (u"ࠨ࠵࡙ࡥࡷࡹࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ∌")%str(_1111ll1l1_l1_))
	l111l11ll1_l1_ = _1111ll1l1_l1_[1]
	_print(l11lll_l1_ (u"ࠩࡥ࡭࡬ࡥࡳࡵࡴࡢࡺࡦࡸࠠࠡ࠿ࠣࠩࡸ࠭∍")%l111l11ll1_l1_)
	l111lll111_l1_ = l111lll111_l1_.replace(l11lll_l1_ (u"ࠪ࠰ࠬ∎"),l11lll_l1_ (u"ࠫࡀ࠭∏")).split(l11lll_l1_ (u"ࠬࡁࠧ∐"))
	for l1111l1111_l1_ in l111lll111_l1_:
		l1111l1111_l1_ = l1111l1111_l1_.strip()
		if l11lll_l1_ (u"࠭ࡩࡴ࡯ࡲࡦࠬ∑") in l1111l1111_l1_: l1111l1111_l1_=l11lll_l1_ (u"ࠧࠨ−")
		if l11lll_l1_ (u"ࠨ࠿࡞ࡡࠬ∓")   in l1111l1111_l1_: l1111l1111_l1_ = l1111l1111_l1_.replace(l11lll_l1_ (u"ࠩࡀ࡟ࡢ࠭∔"),l11lll_l1_ (u"ࠪࡁࢀࢃࠧ∕"))
		l1111l1111_l1_ = re.sub(l11lll_l1_ (u"ࠦ࠭ࡧ࠰࠯࡞ࠫ࠭ࠧ∖"), l11lll_l1_ (u"ࠧࡧ࠰ࡥࠪࡰࡥ࡮ࡴ࡟ࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠦ∗"), l1111l1111_l1_)
		#if l11lll_l1_ (u"࠭ࡡ࠱ࡉࠫࠫ∘")  in l1111l1111_l1_: l1111l1111_l1_ = l1111l1111_l1_.replace(l11lll_l1_ (u"ࠧࡢ࠲ࡊࠬࠬ∙"),l11lll_l1_ (u"ࠨࡣ࠳ࡋ࠭ࡳࡡࡪࡰࡢࡸࡦࡨࠬࡴࡶࡨࡴ࠷࠲ࠧ√"))
		if l1111l1111_l1_!=l11lll_l1_ (u"ࠩࠪ∛"):
			#_print(l11lll_l1_ (u"ࠪࡩࡱࡳࠠ࠾ࠢࠨࡷࠬ∜") % l1111l1111_l1_)
			l1111l1111_l1_ = l1111l1111_l1_.replace(l11lll_l1_ (u"࡛ࠫࠦࠧ࡞ࠩ∝"),l11lll_l1_ (u"࡚ࠬࡲࡶࡧࠪ∞"));
			l1111l1111_l1_ = l1111l1111_l1_.replace(l11lll_l1_ (u"࠭ࠡ࡜࡟ࠪ∟"),l11lll_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭∠"));
			l1111l1111_l1_ = l1111l1111_l1_.replace(l11lll_l1_ (u"ࠨࡸࡤࡶࠥ࠭∡"),l11lll_l1_ (u"ࠩࠪ∢"));
			#_print(l11lll_l1_ (u"ࠪࡩࡱࡳࠠ࠾ࠢࠨࡷࠬ∣") % l1111l1111_l1_)
			try:
				exec(l1111l1111_l1_,{l11lll_l1_ (u"ࠫࡵࡧࡲࡴࡧࡌࡲࡹ࠭∤"):l111l1ll11_l1_,l11lll_l1_ (u"ࠬࡧࡴࡰࡤࠪ∥"):l111ll111l_l1_,l11lll_l1_ (u"࠭ࡡ࠱ࡦࠪ∦"):l111111ll1_l1_,l11lll_l1_ (u"ࠧࡹࠩ∧"):x,l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡴࡢࡤࠪ∨"):l111l1111l_l1_,l11lll_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨ∩"):l1111lll11_l1_},locals())
			except:
				#_print(l11lll_l1_ (u"ࠪࡩࡱࡳࠠ࠾ࠢࠨࡷࠬ∪") % l1111l1111_l1_)
				#_print(l11lll_l1_ (u"ࠫࡻࠦ࠽ࠡࠤࠨࡷࠧࠦࡥࡹࡧࡦࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠦ࠭∫") % l1111l1111_l1_, sys.exc_info()[0])
				pass
	l111ll11ll_l1_ = l11lll_l1_ (u"ࠬ࠭∬")
	for i in range(0,len(locals()[_1111ll1l1_l1_[2]])):
		if locals()[_1111ll1l1_l1_[2]][i] in locals()[_1111ll1l1_l1_[1]]:
			l111ll11ll_l1_ = l111ll11ll_l1_ + locals()[_1111ll1l1_l1_[1]][locals()[_1111ll1l1_l1_[2]][i]]
	_print(l11lll_l1_ (u"࠭ࡢࡪࡩࡖࡸࡷ࡯࡮ࡨࠢࠣࠤࠥࡃࠠࠦ࠰࠼࠴ࡸ࠴࠮࠯ࠩ∭")%l111ll11ll_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡧࡃ࡜ࠨ࠱࡟ࠫࡡ࠱ࠨ࠯ࠬࡂ࠭࠭ࡅ࠺࠭ࡾ࠾࠭ࠬ∮"), l1111lllll_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡇࡦࡶࡘࡶࡱࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ∯")
	l1111l11l1_l1_ = str(tmp[0])
	_print(l11lll_l1_ (u"ࠩࡊࡩࡹ࡛ࡲ࡭ࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩࡸ࠭∰") % l1111l11l1_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠪࠬࡤ࠴ࠪࡀࠫ࡟࡟ࠬ∱"), l1111l11l1_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠫࡊࡘࡒ࠻ࠢࡊࡩࡹ࡜ࡡࡳࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬ∲")
	l111l1ll1l_l1_ = tmp[0]
	_print(l11lll_l1_ (u"ࠬࡍࡥࡵࡘࡤࡶࠥࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩ∳") % l111l1ll1l_l1_)
	l111l11l11_l1_ = locals()[l111l1ll1l_l1_][0]
	l111l11l11_l1_ = l111ll111l_l1_(l111l11l11_l1_)
	_print(l11lll_l1_ (u"࠭ࡇࡦࡶ࡙ࡥࡱࠦࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪ∴") % l111l11l11_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠧࡾࡸࡤࡶࠥ࠮ࡦ࠾࠰࠭ࡃ࠮ࡁࠧ∵"), l1111lllll_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡐࡰࡵࡷ࡙ࡷࡲࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪ∶")
	l11111l1l1_l1_ = str(tmp[0])
	_print(l11lll_l1_ (u"ࠩࡓࡳࡸࡺࡕࡳ࡮ࠣࠤࠥࠦࠠࠡ࠿ࠣࠩࡸ࠭∷") % l11111l1l1_l1_)
	l11111l1l1_l1_ = re.sub(l11lll_l1_ (u"ࠥࠬࡼ࡯࡮ࡥࡱࡺࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠧ∸"), l11lll_l1_ (u"ࠦࡦࡺ࡯ࡣࠤ∹"), l11111l1l1_l1_)
	l11111l1l1_l1_ = re.sub(l11lll_l1_ (u"ࠧ࠮࡛ࡂ࠯࡝ࡡࢀ࠷ࠬ࠳ࡿ࡟ࠬ࠮ࠨ∺"), l11lll_l1_ (u"ࠨࡡ࠱ࡦࠫࡱࡦ࡯࡮ࡠࡶࡤࡦ࠱ࡹࡴࡦࡲ࠵࠰ࠧ∻"), l11111l1l1_l1_)
	l11111l1l1_l1_ = l11lll_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡧ࠽ࠣࠫ∼")+l11111l1l1_l1_
	verify = re.findall(l11lll_l1_ (u"ࠨ࡞࠮ࠬࡤ࠴ࠪࡀࠫࠧࠫ∽"),l11111l1l1_l1_,re.DOTALL)[0]
	l111111l1l_l1_ = eval(verify)
	#exec(l11111l1l1_l1_)
	l11111l1l1_l1_ = l11111l1l1_l1_.replace(l11lll_l1_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࠢࡩ࠿ࠥ࡬࠽ࠨ∾"),l11lll_l1_ (u"ࠪࠫ∿"))
	f = eval(l11111l1l1_l1_,{l11lll_l1_ (u"ࠫࡦࡺ࡯ࡣࠩ≀"):l111ll111l_l1_,l11lll_l1_ (u"ࠬࡧ࠰ࡥࠩ≁"):l111111ll1_l1_,l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࡣࡹࡧࡢࠨ≂"):l111l1111l_l1_,l11lll_l1_ (u"ࠧࡴࡶࡨࡴ࠷࠭≃"):l1111lll11_l1_,verify:l111111l1l_l1_})
	_print(l11lll_l1_ (u"ࠨ࠱ࠪ≄")+l111l11l11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠧ≅")+f+l111ll11ll_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ≆")+l111l1l11l_l1_)
	return([l11lll_l1_ (u"ࠫ࠴࠭≇")+l111l11l11_l1_,f+l111ll11ll_l1_,{ l111l1l11l_l1_ : l11lll_l1_ (u"ࠬࡵ࡫ࠨ≈")}])
def _print(text):
	#text = text.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ≉"),l11lll_l1_ (u"ࠧࠡࠢࠪ≊")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠥ࠭≋"),l11lll_l1_ (u"ࠩࠣࠤࠬ≌")).replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ≍"),l11lll_l1_ (u"ࠫࠥࠦࠧ≎"))
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭≏"),str(text))
	return
l11lll_l1_ (u"ࠨࠢࠣࠌࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠵࡭ࡰࡸ࡬ࡩ࠴ࡲࡡࡶࡩ࡫࠱ࡰ࡯࡬࡭ࡧࡵ࠱ࡱࡧࡵࡨࡪ࠰࠶࠵࠷࠵ࠨࠌࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠵࡭ࡰࡸ࡬ࡩ࠴ࡧ࡬࡭࠯࡫ࡥࡱࡲ࡯ࡸࡵ࠰ࡩࡻ࡫࠭࠳࠯࠵࠴࠶࠻࠯ࡀࡴࡨࡪࡂࡹࡩ࡮࡫࡯ࡥࡷ࠭ࠊࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡲࡳࡱ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮࡭ࡶࡧ࠳ࡲࡵࡶࡪࡧ࠲ࡥࡩࡼࡥࡳࡵࡨ࠱࠷࠶࠲࠱࠱ࡂࡶࡪ࡬࠽࡮ࡱࡹ࡭ࡪࡹ࠭ࡱ࠳ࠪࠎࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡓࡕ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡖࡈࡗ࡙࠷ࠧࠪࠌ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯࠮ࡵ࡬ࡾࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋ࡮࡬ࡲࡰࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠭ࠫ࡭࡫ࡱ࡯ࡠ࠶࡝ࠋࠥ࡯࡭ࡳࡱࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡵ࡯࡭࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡰࡹࡪ࠯ࡸࡣࡷࡧ࡭࠵࠿ࡷ࠿࡜࡬࡭࡮ࡥࡈ࡜࡬࡞ࡌࡪࡘࡗࡴࡨ࡬ࡖ࡮ࡨࡩࡧࡊࡰࡊ࡮ࡥࡩࡓ࡫ࡩ࡫࡙ࡋࡌ࡙ࡻࡑࡩࡪࡥࡥ࡭࡬࡞࡫࡮ࡋࡣࡨࡎ࡬ࡪࡗࡥࡩࡧࡆࡏࡩࡻࡥࡩࡓ࡫ࡩࡉࡲࡏࡥࡲࡌࡨࡪࡑࡦࡅ࡚ࡕࡈࡶ࡚ࡖ࡛ࡨ࡫࡬ࡪ࡮࡙ࡒࡧ࡫ࡩࡩ࡙ࡋࡩࡧ࡫ࡕ࡭࡫ࡤࡌ࡛ࡇࡗࡳࡋࡖࡥࡪࡧ࡞࡜ࡍࡨࡦࡓࡨ࡬ࡪࡠࡶࡰ࡛ࡧࡗࡱࡠࡗࡦࡪࡔࡈࡳ࡟ࡄ࡯ࡪࡇࡕࡉࡳࡃࡥࡆࡩࡕࡖ࡫ࡨࡦࡍࡖࡒࡪ࡮ࡑࡩࡧࡶࡨࡘࡑࡇࡧ࡮ࡳࡒࡴ࡮ࡤࡱࡱࡧ࡞ࡵࡑࡨࡦࡓࡨ࡬ࡪࡪࡓࡤࡪࡨ࡬ࡖ࡮ࡥࡅࡰ࡯ࡩ࡭࡬࡮ࡩࡓࡵࡪ࡭࡮ࡦ࡯ࡪࡇ࡬࡭࡫ࡨ࡚ࠨ࡫ࡁ࠺ࡪࡥ࠹ࡤࡥ࠴࠼࠸ࡤ࠴࠵࠹ࡨࡪ࠶࠵࠱࠻࠵࠶࠾࠽ࡥࡤ࠺ࡥ࠺࠶࠼࠴࠴ࠩࠍࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡒࡔࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡱ࡯࡮࡬࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡖࡈࡗ࡙࠸ࠧࠪࠌ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࡺࡲࡺ࠼ࠍࠍࡷ࡫ࡳࡶ࡮ࡷࠤࡂࠦࡖࡪࡦࡖࡸࡷ࡫ࡡ࡮ࠪ࡫ࡸࡲࡲࠩࠋࠋ࡯ࡲ࠶࠲࡬࡯࠴࠯ࡴࡷࡳࠠ࠾ࠢࡵࡩࡸࡻ࡬ࡵࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡈࡑࡆࡊࠠࡆࡏࡄࡈ࠿ࠦࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭ࡰ࠴࠭࠮ࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡅࡎࡃࡇࠤࡊࡓࡁࡅ࠼ࠣࠤࠥ࠭ࠫࡴࡶࡵࠬࡱࡴ࠲ࠪࠫࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪࡉࡒࡇࡄࠡࡇࡐࡅࡉࡀࠠࠡࠢࠪ࠯ࡸࡺࡲࠩࡲࡵࡱ࠮࠯ࠊࡦࡺࡦࡩࡵࡺ࠺ࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡇࡐࡅࡉࠦࡅࡎࡃࡇ࠾ࠥࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡲࡦࡵࡸࡰࡹ࠯ࠩࠋࠤࠥࠦ≐")
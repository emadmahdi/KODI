# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧബ")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡇࡖࡐࡣࠬഭ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1ll1l11l_l1_ = [l11lll_l1_ (u"ࠧ࠲࠴࠶࠽ࠬമ"),l11lll_l1_ (u"ࠨ࠳࠵࠹࠵࠭യ"),l11lll_l1_ (u"ࠩ࠴࠶࠹࠻ࠧര"),l11lll_l1_ (u"ࠪ࠶࠵࠭റ"),l11lll_l1_ (u"ࠫ࠶࠸࠵࠺ࠩല"),l11lll_l1_ (u"ࠬ࠸࠱࠹ࠩള"),l11lll_l1_ (u"࠭࠴࠹࠷ࠪഴ"),l11lll_l1_ (u"ࠧ࠲࠴࠶࠼ࠬവ"),l11lll_l1_ (u"ࠨ࠳࠵࠹࠽࠭ശ"),l11lll_l1_ (u"ࠩ࠵࠽࠷࠭ഷ")]
l1ll1l111_l1_ = [l11lll_l1_ (u"ࠪ࠷࠵࠹࠰ࠨസ"),l11lll_l1_ (u"ࠫ࠻࠸࠸ࠨഹ")]
def MAIN(mode,url,text):
	if   mode==60: results = MENU()
	elif mode==61: results = l1111l_l1_(url,text)
	elif mode==62: results = l1llllll_l1_(url)
	elif mode==63: results = PLAY(url)
	elif mode==64: results = l1ll1l1l1_l1_(text)
	elif mode==69: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬഺ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾഻࠭"),l11lll_l1_ (u"ࠧࠨ഼"),69,l11lll_l1_ (u"ࠨࠩഽ"),l11lll_l1_ (u"ࠩࠪാ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧി"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫീ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧു")+l111ll_l1_+l11lll_l1_ (u"࠭ๅศࠢํฮ๊ࠦๅีษ๊ำฯํࠠศๆส๊ࠬൂ"),l11ll1_l1_,64,l11lll_l1_ (u"ࠧࠨൃ"),l11lll_l1_ (u"ࠨࠩൄ"),l11lll_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵࡡࡹ࡭ࡪࡽࡥࡥࡡࡹ࡭ࡩࡹࠧ൅"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪെ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭േ")+l111ll_l1_+l11lll_l1_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬൈ"),l11ll1_l1_,64,l11lll_l1_ (u"࠭ࠧ൉"),l11lll_l1_ (u"ࠧࠨൊ"),l11lll_l1_ (u"ࠨ࡯ࡲࡷࡹࡥࡶࡪࡧࡺࡩࡩࡥࡶࡪࡦࡶࠫോ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩൌ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ്ࠬ")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ฼๊โฬ้ࠣษิัศࠩൎ"),l11ll1_l1_,64,l11lll_l1_ (u"ࠬ࠭൏"),l11lll_l1_ (u"࠭ࠧ൐"),l11lll_l1_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺࡡࡤࡨࡩ࡫ࡤࡠࡸ࡬ࡨࡸ࠭൑"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ൒"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ൓")+l111ll_l1_+l11lll_l1_ (u"ࠪๅ๏ี๊้ࠢ฼ุํอฦ๋ࠩൔ"),l11ll1_l1_,64,l11lll_l1_ (u"ࠫࠬൕ"),l11lll_l1_ (u"ࠬ࠭ൖ"),l11lll_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡥࡶࡪࡦࡶࠫൗ"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ൘"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ൙")+l111ll_l1_+l11lll_l1_ (u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪ൚"),l11ll1_l1_,61,l11lll_l1_ (u"ࠪࠫ൛"),l11lll_l1_ (u"ࠫࠬ൜"),l11lll_l1_ (u"ࠬ࠳࠱ࠨ൝"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭൞"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩൟ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ฬึอๅอࠢส่ิ๐ๆ๋หࠪൠ"),l11ll1_l1_,61,l11lll_l1_ (u"ࠩࠪൡ"),l11lll_l1_ (u"ࠪࠫൢ"),l11lll_l1_ (u"ࠫ࠲࠸ࠧൣ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ൤"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ൥")+l111ll_l1_+l11lll_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠡࡘ࡬ࡨࡪࡵࡳࠨ൦"),l11ll1_l1_,61,l11lll_l1_ (u"ࠨࠩ൧"),l11lll_l1_ (u"ࠩࠪ൨"),l11lll_l1_ (u"ࠪ࠱࠸࠭൩"))
	return l11lll_l1_ (u"ࠫࠬ൪")
def l1111l_l1_(url,category):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭൫"),l11lll_l1_ (u"࠭ࠧ൬"),l11lll_l1_ (u"ࠧࠨ൭"), category)
	cat = l11lll_l1_ (u"ࠨࠩ൮")
	if category not in [l11lll_l1_ (u"ࠩ࠰࠵ࠬ൯"),l11lll_l1_ (u"ࠪ࠱࠷࠭൰"),l11lll_l1_ (u"ࠫ࠲࠹ࠧ൱")]: cat = l11lll_l1_ (u"ࠬࡅࡣࡢࡶࡀࠫ൲")+category
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡧࡱࡹࡤࡲࡥࡷࡧ࡯࠲ࡵ࡮ࡰࠨ൳")+cat
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ൴"),l11lll_l1_ (u"ࠨࠩ൵"),l11lll_l1_ (u"ࠩࠪ൶"),l11lll_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ൷"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ൸"),html,re.DOTALL)
	l1ll11lll_l1_,l1ll1ll1l_l1_ = False,False
	for link,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ൹"))
		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫൺ") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ൻ")+link
		cat = re.findall(l11lll_l1_ (u"ࠨࡥࡤࡸࡂ࠮࠮ࠫࡁࠬࠪࠬർ"),link,re.DOTALL)[0]
		if category==cat: l1ll11lll_l1_ = True
		elif l1ll11lll_l1_ 	or (category==l11lll_l1_ (u"ࠩ࠰࠵ࠬൽ") and cat in l1ll1l11l_l1_) \
						or (category==l11lll_l1_ (u"ࠪ࠱࠷࠭ൾ") and cat not in l1ll1l111_l1_ and cat not in l1ll1l11l_l1_) \
						or (category==l11lll_l1_ (u"ࠫ࠲࠹ࠧൿ") and cat in l1ll1l111_l1_):
							if count==l11lll_l1_ (u"ࠬ࠷ࠧ඀"): addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬඁ"),l111ll_l1_+title,link,63)
							else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧං"),l111ll_l1_+title,link,61,l11lll_l1_ (u"ࠨࠩඃ"),l11lll_l1_ (u"ࠩࠪ඄"),cat)
							l1ll1ll1l_l1_ = True
	if not l1ll1ll1l_l1_: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫඅ"),l11lll_l1_ (u"ࠫࠬආ"),True,l11lll_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ඇ"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧඈ"),l11lll_l1_ (u"ࠧࠨඉ"),url , html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷ࠭ඊ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡪࡶ࡮ࡪ࡟ࡷ࡫ࡨࡻ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧඋ"),block,re.DOTALL)
	link = l11lll_l1_ (u"ࠪࠫඌ")
	for l1llll_l1_,title,link in items:
		title = title.replace(l11lll_l1_ (u"ࠫࡆࡪࡤࠨඍ"),l11lll_l1_ (u"ࠬ࠭ඎ")).replace(l11lll_l1_ (u"࠭ࡴࡰࠢࡔࡹ࡮ࡩ࡫࡭࡫ࡶࡸࠬඏ"),l11lll_l1_ (u"ࠧࠨඐ")).strip(l11lll_l1_ (u"ࠨࠢࠪඑ"))
		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧඒ") not in link: link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩඓ")+link
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪඔ"),l111ll_l1_+title,link,63,l1llll_l1_)
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧඕ"),block,re.DOTALL)
	block=l1l1ll1_l1_[0]
	block=re.findall(l11lll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧඖ"),html,re.DOTALL)[0]
	items=re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ඗"),block,re.DOTALL)
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࠪ඘"))[0]
	for link,l1ll11l1l_l1_ in items:
		link = l11l11l_l1_ + link
		title = unescapeHTML(l1ll11l1l_l1_)
		title = l11lll_l1_ (u"ุࠩๅาฯࠠࠨ඙") + title
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪක"),l111ll_l1_+title,link,62)
	return link
def PLAY(url):
	if l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࠨඛ") in url: url = l1llllll_l1_(url)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭ග"),l11lll_l1_ (u"࠭ࠧඝ"),True,l11lll_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫඞ"))
	items = re.findall(l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨඟ"),html,re.DOTALL)
	url = items[0]
	if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧච") not in url: url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩඡ")+url
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪජ"))
	return
def l1ll1l1l1_l1_(category):
	payload = { l11lll_l1_ (u"ࠬࡳ࡯ࡥࡧࠪඣ") : category }
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭ࡨࡤࡸ࡮ࡳࡩ࠯ࡶࡹ࠳ࡦࡰࡡࡹ࠰ࡳ࡬ࡵ࠭ඤ")
	headers = { l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ඥ") : l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧඦ") }
	data = l1ll1l1ll_l1_(payload)
	html = OPENURL_CACHED(l1lll1111_l1_,url,data,headers,True,l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡒࡕࡓࡕࡕ࠰࠵ࡸࡺࠧට"))
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࠫඨ"),html,re.DOTALL)
	for link,title,l1llll_l1_ in items:
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ඩ"))
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪඪ") not in link: link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬණ")+link
		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ඬ"),l111ll_l1_+title,link,63,l1llll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩත"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪථ"): return
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫද"),l11lll_l1_ (u"ࠫࠬධ"),search, l11ll1_l1_)
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧන"),l11lll_l1_ (u"࠭ࠫࠨ඲"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡠࡴࡨࡷࡺࡲࡴ࠯ࡲ࡫ࡴࡄࡷࡵࡦࡴࡼࡁࠬඳ") + l111l1l_l1_ # + l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽࠲ࠩප")
	l1llllll_l1_(url)
	return
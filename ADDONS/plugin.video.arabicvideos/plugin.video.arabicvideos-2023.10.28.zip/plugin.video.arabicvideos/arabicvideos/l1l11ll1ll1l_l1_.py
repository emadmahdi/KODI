# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ撨")
#headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭撩"):l11lll_l1_ (u"ࠪࠫ撪")}
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪ撫")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๋ࠬีศำ฼อࠬ撬"),l11lll_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ播")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l1111l_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llllll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ撮"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ撯"),l11lll_l1_ (u"ࠩࠪ撰"),l11lll_l1_ (u"ࠪࠫ撱"),l11lll_l1_ (u"ࠫࠬ撲"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ撳"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ撴"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩ撵"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ撶"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撷"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ撸"),l1ll1l1_l1_,489,l11lll_l1_ (u"ࠫࠬ撹"),l11lll_l1_ (u"ࠬ࠭撺"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ撻"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ撼"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ撽"),l11lll_l1_ (u"ࠩࠪ撾"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撿"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭擀")+l111ll_l1_+l11lll_l1_ (u"ࠬษอะอࠣห้๋่ศุํ฽ࠬ擁"),l1ll1l1_l1_,481)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫࠥࡱࡾࡇࡣࡤࡱࡸࡲࡹࠨࠧ擂"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ擃"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠨࠥࠪ擄"): continue
		if title in l1l1l1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ擅"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ擆")+l111ll_l1_+title,link,481)
	return html
def l1111l_l1_(url,l1lll11llll11_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ擇"),url,l11lll_l1_ (u"ࠬ࠭擈"),l11lll_l1_ (u"࠭ࠧ擉"),l11lll_l1_ (u"ࠧࠨ擊"),l11lll_l1_ (u"ࠨࠩ擋"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ擌"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡵࡳࡵࠪ࠱࠮ࡄ࠯ࠢࡧࡱࡲࡸࡪࡸࠢࠨ操"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ擎"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ擏"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ擐"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭擑"),l11lll_l1_ (u"ࠨล฽๊๏ฯࠧ擒"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ擓"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ擔"),l11lll_l1_ (u"ࠫ์ีวโࠩ擕"),l11lll_l1_ (u"๋ࠬศศำสอࠬ擖"),l11lll_l1_ (u"ู࠭าุࠪ擗"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ擘"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ擙"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ據")]
	l1lll11llll1l_l1_ = l11lll_l1_ (u"ࠪ࠳ࠬ擛").join(l1lll11llll11_l1_.strip(l11lll_l1_ (u"ࠫ࠴࠭擜")).split(l11lll_l1_ (u"ࠬ࠵ࠧ擝"))[4:]).split(l11lll_l1_ (u"࠭࠭ࠨ擞"))
	for link,title,l1llll_l1_ in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ擟"),title,re.DOTALL)
		if l1lll11llll11_l1_:
			l1lllll1ll_l1_ = l11lll_l1_ (u"ࠨ࠱ࠪ擠").join(link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ擡")).split(l11lll_l1_ (u"ࠪ࠳ࠬ擢"))[4:]).split(l11lll_l1_ (u"ࠫ࠲࠭擣"))
			l1lll11lllll1_l1_ = len([x for x in l1lll11llll1l_l1_ if x in l1lllll1ll_l1_])
			if l1lll11lllll1_l1_>2 and l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ擤") in link:
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ擥"),l111ll_l1_+title,link,482,l1llll_l1_)
		else:
			if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ擦"),title,re.DOTALL)
			#if any(value in title for value in l1lll1_l1_):
			if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ擧") not in title:
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ擨"),l111ll_l1_+title,link,482,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠪั้่ษࠨ擩") in title:
				title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ擪") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ擫"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ擬"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ擭"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ擮"),url)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ擯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ擰"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ擱"),l11lll_l1_ (u"ࠬ࠭擲"))
			if title!=l11lll_l1_ (u"࠭ࠧ擳"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ擴"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ擵")+title,link,481,l11lll_l1_ (u"ࠩࠪ擶"),l11lll_l1_ (u"ࠪࠫ擷"),l1lll11llll11_l1_)
	return
def l1llllll_l1_(url,l11l11l_l1_):
	headers = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ擸"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭擹")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ擺"),url,l11lll_l1_ (u"ࠧࠨ擻"),headers,l11lll_l1_ (u"ࠨࠩ擼"),l11lll_l1_ (u"ࠩࠪ擽"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ擾"))
	html = response.content
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ擿"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭攀"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ攁"))
	l1lll11lll1ll_l1_ = True
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࡙ࡥࡢࡵࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ攂"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ攃") not in url:
		block = l1l1l11_l1_[0]
		count = block.count(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂ࠭攄"))
		if count==0: count = block.count(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠩ攅"))
		if count>1:
			l1lll11lll1ll_l1_ = False
			if l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠩ攆") in block:
				items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭攇"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠳࠰ࡳ࡬ࡵࡅࡳ࡭ࡷࡪࡁࠬ攈")+id
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ攉"),l111ll_l1_+title,link,483,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ攊"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠲ࡵ࡮ࡰࡀࡵࡨࡶ࡮࡫ࡳࡊࡆࡀࠫ攋")+id
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ攌"),l111ll_l1_+title,link,483,l1llll_l1_)
	# l1l1l_l1_
	if l1lll11lll1ll_l1_:
		block = l11lll_l1_ (u"ࠫࠬ攍")
		if l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ攎") in url: block = html
		else:
			l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡦࡲ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ攏"),html,re.DOTALL)
			if l1l11ll_l1_: block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭攐"),block,re.DOTALL)
		if items:
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ攑"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ攒"),l111ll_l1_+title,link,482,l1llll_l1_)
	if not menuItemsLIST: l1111l_l1_(l11l11l_l1_,url)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ攓"))+l11lll_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡺࡥࡹࡩࡨࠨ攔")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ攕"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ攖"),l11lll_l1_ (u"ࠧࠨ攗"),l11lll_l1_ (u"ࠨࠩ攘"),l11lll_l1_ (u"ࠩࠪ攙"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ攚"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ攛"))
	l1lll11111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡼ࡯ࡠࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ攜"),html,re.DOTALL)
	if not l1lll11111_l1_: l1lll11111_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ攝"),html,re.DOTALL)
	l1lll11111_l1_ = l1lll11111_l1_[0]
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ攞"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭攟"),block,re.DOTALL)
		for l1lll11l11_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ攠"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳࡮࡬ࡲࡢ࡯ࡨ࠶࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭攡")+l1lll11111_l1_+l11lll_l1_ (u"ࠫࠫࡼࡩࡥࡧࡲࡁࠬ攢")+l1lll11l11_l1_[2:]+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭攣")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ攤")
			l1111_l1_.append(link)
	# l1l111lll_l1_ l11l1ll1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡩࡨࡸࡊࡳࡢࡦࡦࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ攥"),html,re.DOTALL)
	if link:
		title = SERVER(link[0],l11lll_l1_ (u"ࠨࡷࡵࡰࠬ攦"))
		link = link[0]+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ攧")+title+l11lll_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ攨")
		l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠫ࠴࠭攩"))+l11lll_l1_ (u"ࠬ࠵࠿ࡥࡱࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ攪")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ攫"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ攬"),l11lll_l1_ (u"ࠨࠩ攭"),l11lll_l1_ (u"ࠩࠪ攮"),l11lll_l1_ (u"ࠪࠫ支"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ攰"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡢࡤ࡯ࡩ࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ攱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ攲"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ攳"))
			if l11lll_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ攴") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠩࡢࡣำอีࠨ攵")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠪࠫ收")
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ攷")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ攸")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ改"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭攺"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠨࠩ攻")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ攼"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ攽"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭放"),l11lll_l1_ (u"ࠬ࠱ࠧ政"))
	if l1ll1l1_l1_==l11lll_l1_ (u"࠭ࠧ敀"): l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ敁")+search+l11lll_l1_ (u"ࠨ࠱ࠪ敂")
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࠪ敃"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ✹")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ✺")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ✻"),l11lll_l1_ (u"࠭วๅๅ็ࠫ✼"),l11lll_l1_ (u"ࠧ࡯࠱ࡄࠫ✽"),l11lll_l1_ (u"ࠨษ็้ื๐ฯࠨ✾"),l11lll_l1_ (u"ࠩๅูฮูࠦีไࠪ✿")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l1111l_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1llllll_l1_(url)
	elif mode==434: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ❀")+text)
	elif mode==435: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ❁")+text)
	elif mode==436: results = l1l11l_l1_(url)
	elif mode==437: results = l1llll11ll_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ❂"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭❃"),l11lll_l1_ (u"ࠧࠨ❄"),l11lll_l1_ (u"ࠨࠩ❅"),l11lll_l1_ (u"ࠩࠪ❆"),l11lll_l1_ (u"ࠪࠫ❇"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭❈"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ❉"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"࠭࠯ࠨ❊"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ❋"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❌"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ❍"),l11lll_l1_ (u"ࠪࠫ❎"),439,l11lll_l1_ (u"ࠫࠬ❏"),l11lll_l1_ (u"ࠬ࠭❐"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ❑"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❒"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ❓"),l1ll1l1_l1_,435)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❔"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭❕"),l1ll1l1_l1_,434)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ❖"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ❗"),l11lll_l1_ (u"࠭ࠧ❘"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❙"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❚")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨ❛"),l1ll1l1_l1_,431)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❜"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭❝")+l111ll_l1_+l11lll_l1_ (u"ࠬอแๅษ่ࠤฬ๎ๆࠡๆส๎๋࠭❞"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠷ࠧ❟"),436)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❠"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❡")+l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠣหํ์ࠠๅษํ๊ࠬ❢"),l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱ࡦࡲ࡬࠲ࠩ❣"),436)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❤"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ❥")+l111ll_l1_+l11lll_l1_ (u"࠭โศศ่อࠥะแึ์็๎ฮ࠭❦"),l1ll1l1_l1_,437)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ❧"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ❨"),l11lll_l1_ (u"ࠩࠪ❩"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❪"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭❫")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭❬"),l1ll1l1_l1_,431,l11lll_l1_ (u"࠭ࠧ❭"),l11lll_l1_ (u"ࠧࠨ❮"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ❯"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❰"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❱")+l111ll_l1_+l11lll_l1_ (u"ࠫศ็ไศ็ࠪ❲"),l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷ࠴࠭❳"),436)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❴"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ❵")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหࠩ❶"),l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠰࠵࠴࠭❷"),436)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬ❸"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭❹"),block,re.DOTALL)
	for link,title in items:
		#if title==l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ❺"): title = l11lll_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ❻")
		if title in l1l1l1_l1_: continue
		if title==l11lll_l1_ (u"ࠧศๆิส๏ู๊สࠩ❼"): continue
		if l11lll_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠪ❽") in title: continue
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❾"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❿")+l111ll_l1_+title,link,431)
	return
def l1llll11ll_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬ➀")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ➁"),l1l1ll11_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭➂"),l11lll_l1_ (u"ࠧࠨ➃"),l11lll_l1_ (u"ࠨࠩ➄"),l11lll_l1_ (u"ࠩࠪ➅"),l11lll_l1_ (u"ࠪࠫ➆"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭➇"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ➈"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"࠭࠯ࠨ➉"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ➊"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡏ࡭ࡸࡺࡄࡳࡱࡳࡩࡩࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨ➋"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭➌"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l1l1_l1_: continue
		link = l1l1ll11_l1_+l11lll_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧ➍")+category+l11lll_l1_ (u"ࠫࡂ࠭➎")+value
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➏"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ➐")+l111ll_l1_+title,link,431)
	return
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ➑"),l11lll_l1_ (u"ࠨࠩ➒"),l11lll_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠪ➓"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ➔"),link)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ➕"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ➖"),url,l11lll_l1_ (u"࠭ࠧ➗"),l11lll_l1_ (u"ࠧࠨ➘"),l11lll_l1_ (u"ࠨࠩ➙"),l11lll_l1_ (u"ࠩࠪ➚"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ➛"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➜"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠬ➝"),url,431)
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭➞"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭➟"),block,re.DOTALL)
	for l1lll1ll11_l1_,title in items:
		if title in l1l1l1_l1_: continue
		l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡏࡲࡺ࡮࡫ࡳ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࡂ࡯ࡪࡿ࠽ࠨ➠")+l1lll1ll11_l1_
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➡"),l111ll_l1_+title,l11l11l_l1_,431)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ➢"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ➣"),l11lll_l1_ (u"ࠬ࠭➤"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡊࡰࡱࡩࡷࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠭➥"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ➦"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l1l1_l1_: continue
	#	if l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠰ࠩ➧") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡗࡩࡷࡳࡳ࠯ࡲ࡫ࡴࡄ࠭➨")+category+l11lll_l1_ (u"ࠪࡁࠬ➩")+value
	#	elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲࠭➪") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡥࡳ࡫ࡨࡷ࠴ࡍࡥࡵ࠰ࡳ࡬ࡵࡅࠧ➫")+category+l11lll_l1_ (u"࠭࠽ࠨ➬")+value
	#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➭"),l111ll_l1_+title,l11l11l_l1_,431)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠨࠩ➮")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ➯"),l11lll_l1_ (u"ࠪࠫ➰"),request,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ➱"))
	items = []
	if l11lll_l1_ (u"ࠬ࠵ࡔࡦࡴࡰࡷ࠳ࡶࡨࡱࠩ➲") in url or l11lll_l1_ (u"࠭࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࠨ➳") in url or l11lll_l1_ (u"ࠧ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࠪ➴") in url:
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ➵"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ➶"),l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ➷"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ➸")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ➹"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ➺"),l11lll_l1_ (u"ࠧࠨ➻"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ➼"))
		html = response.content
		block = html
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ➽"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ➾"),url,l11lll_l1_ (u"ࠫࠬ➿"),l11lll_l1_ (u"ࠬ࠭⟀"),l11lll_l1_ (u"࠭ࠧ⟁"),l11lll_l1_ (u"ࠧࠨ⟂"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⟃"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡍࡢࡶࡦ࡬ࡪࡹࡔࡢࡤ࡯ࡩࠧ࠭⟄"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭⟅"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⟆"),url,l11lll_l1_ (u"ࠬ࠭⟇"),l11lll_l1_ (u"࠭ࠧ⟈"),l11lll_l1_ (u"ࠧࠨ⟉"),l11lll_l1_ (u"ࠨࠩ⟊"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⟋"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠪ⟌"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫ⟍"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⟎"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"࠭ๅีษ๊ำฮ࠭⟏"),l11lll_l1_ (u"ࠧโ์็้ࠬ⟐"),l11lll_l1_ (u"ࠨษ฽๊๏ฯࠧ⟑"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ⟒"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ⟓"),l11lll_l1_ (u"ࠫ์ีวโࠩ⟔"),l11lll_l1_ (u"๋ࠬศศำสอࠬ⟕"),l11lll_l1_ (u"ู࠭าุࠪ⟖"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ⟗"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ⟘")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ⟙"))
		#link = unescapeHTML(link)
		title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⟚"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ⟛"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⟜"),l111ll_l1_+title,link,432,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭⟝") in title:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⟞") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⟟"),l111ll_l1_+title,link,433,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⟠") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟡"),l111ll_l1_+title,link,431,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟢"),l111ll_l1_+title,link,433,l1llll_l1_)
	if request!=l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⟣"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⟤"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⟥"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⟦") not in link: link = l1ll1l1_l1_+link
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠩࠪ⟧"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟨"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ⟩")+title,link,431)
		l1lllll111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⟪"),html,re.DOTALL)
		if l1lllll111_l1_:
			link = l1lllll111_l1_[0]
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟫"),l111ll_l1_+l11lll_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ⟬"),link,431)
	return
def l1llllll_l1_(url):
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ⟭"),l11lll_l1_ (u"ࠩ࠴࠵࠶࠷ࠠࠡࠩ⟮")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ⟯"))
	l1l1l11_l1_,l1l11ll_l1_ = [],[]
	if l11lll_l1_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࠪ⟰") in url:
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ⟱"):l11lll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ⟲"),l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⟳"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ⟴")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⟵"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ⟶"),l11lll_l1_ (u"ࠫࠬ⟷"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⟸"))
		html = response.content
		l1l11ll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⟹"),url,l11lll_l1_ (u"ࠧࠨ⟺"),l11lll_l1_ (u"ࠨࠩ⟻"),l11lll_l1_ (u"ࠩࠪ⟼"),l11lll_l1_ (u"ࠪࠫ⟽"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⟾"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⟿"),html,re.DOTALL)
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡆࡲ࡬ࡷࡴࡪࡥࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⠀"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡱࡪ࠾࡮ࡳࡡࡨࡧࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠁"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⠂"),block,re.DOTALL)
		for post,l1ll1l1l11l_l1_,title in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠲ࡵ࡮ࡰࡀࠩ⠃")+l11lll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡀࠫ⠄")+l1ll1l1l11l_l1_+l11lll_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ⠅")+post
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⠆"),l111ll_l1_+title,link,433,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ⠇"))
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ⠈"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠨࠢࠪ⠉")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⠊"),l111ll_l1_+title,link,432,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ⠋")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⠌"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭⠍"),l11lll_l1_ (u"࠭ࠧ⠎"),l11lll_l1_ (u"ࠧࠨ⠏"),l11lll_l1_ (u"ࠨࠩ⠐"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⠑"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ⠒"))
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮ࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⠓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1lll11111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⠔"),block,re.DOTALL)
		if l1lll11111_l1_:
			l1lll11111_l1_ = l1lll11111_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ⠕"),l11lll_l1_ (u"ࠧࠨ⠖"),l11lll_l1_ (u"ࠨࠩ⠗"),l1lll11111_l1_)
			items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ⠘"),block,re.DOTALL)
			for server,title in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ⠙")+server+l11lll_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ⠚")+l1lll11111_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⠛")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⠜")
				l1111_l1_.append(link)
	# l1l111lll_l1_ link
	l1l111lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡮࡬ࡲࡢ࡯ࡨࠦࡃࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⠝"),html,re.DOTALL)
	if l1l111lll_l1_:
		l1l111lll_l1_ = l1l111lll_l1_[0].replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ⠞"),l11lll_l1_ (u"ࠩࠪ⠟"))
		title = SERVER(l1l111lll_l1_,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ⠠"))
		link = l1l111lll_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⠡")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⠢")
		l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⠣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⠤"),block,re.DOTALL)
		for link,title,l11l111l_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ⠥"),l11lll_l1_ (u"ࠩࠪ⠦"))
			if l11l111l_l1_!=l11lll_l1_ (u"ࠪࠫ⠧"): l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ⠨")+l11l111l_l1_
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⠩")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⠪")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⠫"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⠬"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ⠭"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ⠮"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭⠯"),l11lll_l1_ (u"ࠬࠫ࠲࠱ࠩ⠰"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫ⠱")+search
	l1111l_l1_(url)
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⠲"))[0]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⠳"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⠴"),l1ll1l1_l1_,l11lll_l1_ (u"ࠪࠫ⠵"),l11lll_l1_ (u"ࠫࠬ⠶"),l11lll_l1_ (u"ࠬ࠭⠷"),l11lll_l1_ (u"࠭ࠧ⠸"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ⠹"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭⠺"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬࠫ⠻"),block,re.DOTALL)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⠼"),block,re.DOTALL)
	return items
def l1llll1ll1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ⠽"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ⠾"))
	l1llllll11_l1_ = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⠿"))[0]
	l1llll1lll_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ⡀"))
	url = url.replace(l1llllll11_l1_,l1llll1lll_l1_)
	url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⡁"),l11lll_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭⡂"))
	return url
def l1ll1l1l1l1_l1_(l1l1llll_l1_,url):
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⡃")) # l1lllllll1l_l1_ be l11111111l_l1_
	l11l1l1_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⡄")+l1l1111l_l1_
	l11l1l1_l1_ = l1llll1ll1_l1_(l11l1l1_l1_)
	return l11l1l1_l1_
l1l11lll_l1_ = [l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⡅"),l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ⡆"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭⡇"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ⡈")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ⡉"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ⡊"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ⡋"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⡌"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ⡍"),l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ⡎")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⡏"),l11lll_l1_ (u"ࠩࠪ⡐"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⡑"),l11lll_l1_ (u"ࠫࠬ⡒"),filter,url)
	if l11lll_l1_ (u"ࠬࡅࠧ⡓") in url: url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⡔"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⡕"),1)
	if filter==l11lll_l1_ (u"ࠨࠩ⡖"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠩࠪ⡗"),l11lll_l1_ (u"ࠪࠫ⡘")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⡙"))
	if type==l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⡚"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"࠭࠽ࠨ⡛") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠧ࠾ࠩ⡜") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⡝")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⡞")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⡟")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⡠")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⡡"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⡢")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⡣"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⡤")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⡥")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⡦"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⡧")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠬ࠭⡨"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⡩")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		if l1l11l11_l1_==l11lll_l1_ (u"ࠧࠨ⡪"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⡫")+l1l11l11_l1_
		l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡬"),l111ll_l1_+l11lll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭⡭"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡮"),l111ll_l1_+l11lll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ⡯")+l11lll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ⡰"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⡱"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⡲"),l11lll_l1_ (u"ࠩࠪ⡳"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠪ࠱࠲࠭⡴"),l11lll_l1_ (u"ࠫࠬ⡵"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧ⡶") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⡷"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l1llll1ll1_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⡸")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡹"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ⡺"),l11l11l_l1_,431)
				else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡻"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ⡼"),l11l11l_l1_,435,l11lll_l1_ (u"ࠬ࠭⡽"),l11lll_l1_ (u"࠭ࠧ⡾"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ⡿"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⢀")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⢁")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⢂")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⢃")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⢄")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢅"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ⢆")+name,l11l11l_l1_,434,l11lll_l1_ (u"ࠨࠩ⢇"),l11lll_l1_ (u"ࠩࠪ⢈"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⢉"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ⢊"): option = l11lll_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ⢋")
			elif value==l11lll_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭⢌"): option = l11lll_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ⢍")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ⢎") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ⢏"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⢐")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭⢑")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧ⢒")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨ⢓")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⢔")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫ⢕")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠩ࠳ࠫ⢖")]
			title = option+l11lll_l1_ (u"ࠪࠤ࠿࠭⢗")+name
			if type==l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ⢘"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢙"),l111ll_l1_+title,url,434,l11lll_l1_ (u"࠭ࠧ⢚"),l11lll_l1_ (u"ࠧࠨ⢛"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⢜"))
			elif type==l11lll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⢝") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠪࡁࠬ⢞") in l1l11l1l_l1_:
				l11l1l1_l1_ = l1ll1l1l1l1_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢟"),l111ll_l1_+title,l11l1l1_l1_,431)
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢠"),l111ll_l1_+title,url,435,l11lll_l1_ (u"࠭ࠧ⢡"),l11lll_l1_ (u"ࠧࠨ⢢"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⢣"),l11lll_l1_ (u"ࠩࠪ⢤"),filters,l11lll_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫ⢥"))
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⢦")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⢧")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⢨")			all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠧ࠾ࠨࠪ⢩"),l11lll_l1_ (u"ࠨ࠿࠳ࠪࠬ⢪"))
	filters = filters.strip(l11lll_l1_ (u"ࠩࠩࠫ⢫"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠪࡁࠬ⢬") in filters:
		items = filters.split(l11lll_l1_ (u"ࠫࠫ࠭⢭"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠬࡃࠧ⢮"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"࠭ࠧ⢯")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠧ࠱ࠩ⢰")
		if l11lll_l1_ (u"ࠨࠧࠪ⢱") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⢲") and value!=l11lll_l1_ (u"ࠪ࠴ࠬ⢳"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ⢴")+value
		elif mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⢵") and value!=l11lll_l1_ (u"࠭࠰ࠨ⢶"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ⢷")+key+l11lll_l1_ (u"ࠨ࠿ࠪ⢸")+value
		elif mode==l11lll_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⢹"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⢺")+key+l11lll_l1_ (u"ࠫࡂ࠭⢻")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠦࠫࠡࠩ⢼"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨ⢽"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠧ࠾࠲ࠪ⢾"),l11lll_l1_ (u"ࠨ࠿ࠪ⢿"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⣀"),l11lll_l1_ (u"ࠪࠫ⣁"),filters,l11lll_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬ⣂"))
	return l1ll1l1l_l1_
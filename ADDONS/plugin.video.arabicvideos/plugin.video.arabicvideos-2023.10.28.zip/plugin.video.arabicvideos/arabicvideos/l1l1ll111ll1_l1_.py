# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ䬙")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ䬚")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอๆ้ษ฼ࠤฬ็ไศ็ࠪ䬛"),l11lll_l1_ (u"࠭ฬ้ัสฮࠥอแๅษ่ࠫ䬜")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1111l_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llllll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䬝"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䬞"),l11lll_l1_ (u"ࠩࠪ䬟"),389,l11lll_l1_ (u"ࠪࠫ䬠"),l11lll_l1_ (u"ࠫࠬ䬡"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䬢"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䬣"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䬤"),l11lll_l1_ (u"ࠨࠩ䬥"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䬦"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䬧")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䬨"),l11ll1_l1_,381,l11lll_l1_ (u"ࠬ࠭䬩"),l11lll_l1_ (u"࠭ࠧ䬪"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䬫"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䬬"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䬭")+l111ll_l1_+l11lll_l1_ (u"ࠪห้าว็สํอࠬ䬮"),l11ll1_l1_,381,l11lll_l1_ (u"ࠫࠬ䬯"),l11lll_l1_ (u"ࠬ࠭䬰"),l11lll_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ䬱"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䬲"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ䬳"),l11lll_l1_ (u"ࠩࠪ䬴"),l11lll_l1_ (u"ࠪࠫ䬵"),l11lll_l1_ (u"ࠫࠬ䬶"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䬷"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䬸"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䬹"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䬺")+l111ll_l1_+title,l11ll1_l1_,381,l11lll_l1_ (u"ࠩࠪ䬻"),l11lll_l1_ (u"ࠪࠫ䬼"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䬽")+str(seq))
	block = l11lll_l1_ (u"ࠬ࠭䬾")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫ䬿"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫ䭀"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䭁"),block,re.DOTALL)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䭂"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䭃"),l11lll_l1_ (u"ࠫࠬ䭄"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬ䭅"):
			if first:
				title = l11lll_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨ䭆")+title
				first = False
			else: title = l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫ䭇")+title
		if title not in l1l1l1_l1_:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭈"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䭉")+l111ll_l1_+title,link,381)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䭊"),l11lll_l1_ (u"ࠫࠬ䭋"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䭌"),url,l11lll_l1_ (u"࠭ࠧ䭍"),l11lll_l1_ (u"ࠧࠨ䭎"),l11lll_l1_ (u"ࠨࠩ䭏"),l11lll_l1_ (u"ࠩࠪ䭐"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䭑"))
	html = response.content
	if type==l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ䭒"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡢࡴࡦ࡬࠲ࡶࡡࡨࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䭓"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䭔"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭䭕"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸࠬ䭖"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		z = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭗"),block,re.DOTALL)
		l1111_l1_,l1l111l11_l1_,l1lll1ll_l1_ = zip(*z)
		items = zip(l1l111l11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䭘"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡶࡹࡷ࡭ࡵࡷࡴࠤࠫ࠲࠯ࡅࠩ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ䭙"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭚"),block,re.DOTALL)
	elif l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䭛") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ䭜"),l11lll_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡴࡶࡤࡶࡹࡄࠧ䭝"))
		html = html.replace(l11lll_l1_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䭞"),l11lll_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ䭟"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡴࡢࡴࡷࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡳࡪ࠾ࠨ䭠"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==2: items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䭡"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡿࡷ࡮ࡪࡥࡣࡣࡵ࠭ࠬ䭢"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭䭣") in url:
				items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭤"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠩ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳ࠬ䭥") in url:
				items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䭦"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䭧"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࠫ䭨") in title:
			title = re.findall(l11lll_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡩࡷ࡯ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䭩"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ䭪")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䭫")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾ࠪ䭬"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭䭭") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭮"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ䭯") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭰"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ䭱") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭲"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ䭳") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䭴"),l111ll_l1_+title,link,381,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䭵"),l111ll_l1_+title,link,382,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡖࡡࡨࡧࠣࠬ࠳࠰࠿ࠪࠢࡲࡪࠥ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䭶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		current = l1l1ll1_l1_[0][0]
		last = l1l1ll1_l1_[0][1]
		block = l1l1ll1_l1_[0][2]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ䭷"),block,re.DOTALL)
		for link,title in items:
			if title==l11lll_l1_ (u"ࠧࠨ䭸") or title==last: continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭹"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ䭺")+title,link,381,l11lll_l1_ (u"ࠪࠫ䭻"),l11lll_l1_ (u"ࠫࠬ䭼"),type)
		#if title==last:
		link = link.replace(l11lll_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ䭽")+title+l11lll_l1_ (u"࠭࠯ࠨ䭾"),l11lll_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ䭿")+last+l11lll_l1_ (u"ࠨ࠱ࠪ䮀"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䮁"),l111ll_l1_+l11lll_l1_ (u"ࠪหำืࠠึใะอࠥ࠭䮂")+last,link,381,l11lll_l1_ (u"ࠫࠬ䮃"),l11lll_l1_ (u"ࠬ࠭䮄"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䮅"),url,l11lll_l1_ (u"ࠧࠨ䮆"),l11lll_l1_ (u"ࠨࠩ䮇"),l11lll_l1_ (u"ࠩࠪ䮈"),l11lll_l1_ (u"ࠪࠫ䮉"),l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䮊"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䮋"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,False):
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䮌"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่ืู้ไࠡๆ็็ออั๊ࠡส่๊ฮัๆฮ้๋ࠣ฿็ࠨ䮍"),l11lll_l1_ (u"ࠨࠩ䮎"),9999)
		return
	if l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭䮏") in url or l11lll_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭䮐") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡩࡵࡧࡰࠫࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ䮑"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[1]
			l1llllll_l1_(l11l11l_l1_)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡦࡲ࡬ࡷࡴࡪࡩࡰࡵࠪࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩࡡࡴࡶࠥࠫࠬ࠭䮒"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡰࡸࡱࡪࡸࡡ࡯ࡦࡲࠫࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠧࠨ䮓"),block,re.DOTALL)
		for l1llll_l1_,l1lll11_l1_,link,name in items:
			title = l1lll11_l1_+l11lll_l1_ (u"ࠧࠡ࠼ࠣࠫ䮔")+name+l11lll_l1_ (u"ࠨࠢส่า๊โสࠩ䮕")
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䮖"),l111ll_l1_+title,link,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䮗"),url,l11lll_l1_ (u"ࠫࠬ䮘"),l11lll_l1_ (u"ࠬ࠭䮙"),l11lll_l1_ (u"࠭ࠧ䮚"),l11lll_l1_ (u"ࠧࠨ䮛"),l11lll_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䮜"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䮝"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠦࠧ࡯ࡤ࠾ࠩࡳࡰࡦࡿࡥࡳ࠯ࡲࡴࡹ࡯࡯࡯࠯࠴ࠫ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠪࠥࡷ࡭࡫ࡡࡥࡧࡵࠦࢁ࠭ࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࠯ࠢࠣࠤ䮞"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡶࡩࡷࡼࡥࡳࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥ䮟"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䮠")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䮡")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲ࠭ࡤ࡮ࡲࡷࡪࠨࠧ䮢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡡࡢࡣࡩࡲ࡟ࡨࡦࡵ࡭ࡻ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䮣"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䮤")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䮥")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ䮦"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䮧"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ䮨"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ䮩"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ䮪"),l11lll_l1_ (u"ࠩ࠮ࠫ䮫"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ䮬")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ䮭"))
	return
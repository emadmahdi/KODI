# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ䮮")
headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䮯"):l11lll_l1_ (u"ࠧࠨ䮰")}
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ䮱")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭䮲"),l11lll_l1_ (u"ࠪࡻࡼ࡫ࠧ䮳")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1111l_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llllll_l1_(url,text)
	elif mode==364: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䮴")+text)
	elif mode==365: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ䮵")+text)
	elif mode==366: results = l1l11l_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䮶"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䮷"),l11lll_l1_ (u"ࠨࠩ䮸"),False,l11lll_l1_ (u"ࠩࠪ䮹"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䮺"))
	#hostname = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䮻")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠬ࠵ࠧ䮼"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䮽")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䮾"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ䮿"),l11lll_l1_ (u"ࠩࠪ䯀"),l11lll_l1_ (u"ࠪࠫ䯁"),l11lll_l1_ (u"ࠫࠬ䯂"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䯃"))
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䯄"),l111ll_l1_+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䯅"),l11lll_l1_ (u"ࠨࠩ䯆"),8)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䯇"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䯈"),l11lll_l1_ (u"ࠫࠬ䯉"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䯊"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䯋"),l11ll1_l1_,369,l11lll_l1_ (u"ࠧࠨ䯌"),l11lll_l1_ (u"ࠨࠩ䯍"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䯎"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䯏"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䯐"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䯑"),364)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯒"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ䯓"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䯔"),365)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䯕"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䯖"),l11lll_l1_ (u"ࠫࠬ䯗"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䯘"):hostname,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䯙"):l11lll_l1_ (u"ࠧࠨ䯚")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ䯛"),l11lll_l1_ (u"ࠩ࠲ࠫ䯜"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࡤࡤࡶ࠭࠴ࠪࡀࠫࡩ࡭ࡱࡺࡥࡳࠩ䯝"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䯞"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠬࠫࡤ࠺ࠧ࠻࠹ࠪࡪ࠸ࠦࡤ࠸ࠩࡩ࠾ࠥࡢ࠹ࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡨ࠹ࠦࡦ࠻ࠩࡦ࠿࠭ࠦࡦ࠻ࠩࡦࡪࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡤ࠽ࠬ䯟") in link: continue
	#		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯠"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䯡")+l111ll_l1_+title,link,366)
	#	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䯢"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䯣"),l11lll_l1_ (u"ࠪࠫ䯤"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䯥"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭䯦"),l11lll_l1_ (u"࠭ࠧ䯧"),l11lll_l1_ (u"ࠧࠨ䯨"),l11lll_l1_ (u"ࠨࠩ䯩"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ䯪"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ䯫"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䯬"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䯭") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ䯮"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠧࠨ䯯"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯰"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䯱")+l111ll_l1_+title,link,366)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䯲"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䯳"),l11lll_l1_ (u"ࠬ࠭䯴"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ䯵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䯶"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯷"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䯸")+l111ll_l1_+title,link,366,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䯹"),l11lll_l1_ (u"ࠫࠬ䯺"),url,l11lll_l1_ (u"ࠬ࠭䯻"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䯼"):url,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䯽"):l11lll_l1_ (u"ࠨࠩ䯾")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䯿"),url,l11lll_l1_ (u"ࠪࠫ䰀"),l11lll_l1_ (u"ࠫࠬ䰁"),l11lll_l1_ (u"ࠬ࠭䰂"),l11lll_l1_ (u"࠭ࠧ䰃"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䰄"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䰅"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ䰆"),url,364)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰇"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ䰈"),url,365)
	if l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦࠬ䰉") in html:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䰊"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ䰋"),url,361,l11lll_l1_ (u"ࠨࠩ䰌"),l11lll_l1_ (u"ࠩࠪ䰍"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䰎"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ䰏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䰐"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䰑"),l111ll_l1_+title,link,361)
	return
def l1111l_l1_(l1ll11l111ll_l1_,type=l11lll_l1_ (u"ࠧࠨ䰒")):
	if l11lll_l1_ (u"ࠨ࠼࠽ࠫ䰓") in l1ll11l111ll_l1_:
		l11l1l1_l1_,url = l1ll11l111ll_l1_.split(l11lll_l1_ (u"ࠩ࠽࠾ࠬ䰔"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ䰕"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l111ll_l1_,l1ll11l111ll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䰖"):l11l1l1_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䰗"):l11lll_l1_ (u"࠭ࠧ䰘")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䰙"),url,l11lll_l1_ (u"ࠨࠩ䰚"),l11lll_l1_ (u"ࠩࠪ䰛"),l11lll_l1_ (u"ࠪࠫ䰜"),l11lll_l1_ (u"ࠫࠬ䰝"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䰞"))
	html = response.content
	if type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䰟"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ䰠"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䰡"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠩ࡟ࡠ࠴࠭䰢"),l11lll_l1_ (u"ࠪ࠳ࠬ䰣")).replace(l11lll_l1_ (u"ࠫࡡࡢࠢࠨ䰤"),l11lll_l1_ (u"ࠬࠨࠧ䰥"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲ࡓࡹࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ䰦"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭䰧"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠡࠩ䰨"),l11lll_l1_ (u"ࠩࠪ䰩"))
			if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䰪") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䰫"),l111ll_l1_+title,link,363,l1llll_l1_)
			elif l11lll_l1_ (u"ࠬำไใหࠪ䰬") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ䰭"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䰮") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䰯"),l111ll_l1_+title,link,363,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䰰"),l111ll_l1_+title,link,362,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䰱"):
			l1lll111lll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ䰲"),block,re.DOTALL)
			if l1lll111lll_l1_:
				count = l1lll111lll_l1_[0]
				link = url+l11lll_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ䰳")+count
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䰴"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ䰵"),link,361,l11lll_l1_ (u"ࠨࠩ䰶"),l11lll_l1_ (u"ࠩࠪ䰷"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䰸"))
		elif type==l11lll_l1_ (u"ࠫࠬ䰹"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䰺"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䰻"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ࠧึใะอࠥ࠭䰼")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䰽"),l111ll_l1_+title,link,361)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠩࠪ䰾")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䰿"),url,l11lll_l1_ (u"ࠫࠬ䱀"),l11lll_l1_ (u"ࠬ࠭䱁"),l11lll_l1_ (u"࠭ࠧ䱂"),l11lll_l1_ (u"ࠧࠨ䱃"),l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䱄"))
	html = response.content
	html = l111l_l1_(html)
	name = re.findall(l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ䱅"),html,re.DOTALL)
	if name: name = name[-1].replace(l11lll_l1_ (u"ࠪ࠱ࠬ䱆"),l11lll_l1_ (u"ࠫࠥ࠭䱇")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ䱈"))
	if l11lll_l1_ (u"࠭ๅ้ี่ࠫ䱉") in name and type==l11lll_l1_ (u"ࠧࠨ䱊"):
		name = name.split(l11lll_l1_ (u"ࠨ็๋ื๊࠭䱋"))[0]
		name = name.replace(l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ䱌"),l11lll_l1_ (u"ࠪࠫ䱍")).strip(l11lll_l1_ (u"ࠫࠥ࠭䱎"))
	elif l11lll_l1_ (u"ࠬำไใหࠪ䱏") in name:
		name = name.split(l11lll_l1_ (u"࠭อๅไฬࠫ䱐"))[0]
		name = name.replace(l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ䱑"),l11lll_l1_ (u"ࠨࠩ䱒")).strip(l11lll_l1_ (u"ࠩࠣࠫ䱓"))
	else: name = name
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࠧ䱔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if type==l11lll_l1_ (u"ࠫࠬ䱕"):
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䱖"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ䱗") in title: continue
				if l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ䱘") in title: continue
				title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ䱙")+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䱚"),l111ll_l1_+title,link,363,l11lll_l1_ (u"ࠪࠫ䱛"),l11lll_l1_ (u"ࠫࠬ䱜"),l11lll_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䱝"))
		if len(menuItemsLIST)==0:
			l11l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࠯ࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䱞"),block+l11lll_l1_ (u"ࠧࠧࠨࠪ䱟"),re.DOTALL)
			if l11l1_l1_: block = l11l1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䱠"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ䱡"))
				title = name+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ䱢")+title
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䱣"),l111ll_l1_+title,link,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ䱤"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ䱥"),l11lll_l1_ (u"ࠧࠨ䱦")).replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠡࠩ䱧"),l11lll_l1_ (u"ࠩࠪ䱨"))
		else: title = l11lll_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ䱩")
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䱪"),l111ll_l1_+title,url,362)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䱫"),url,l11lll_l1_ (u"࠭ࠧ䱬"),l11lll_l1_ (u"ࠧࠨ䱭"),l11lll_l1_ (u"ࠨࠩ䱮"),l11lll_l1_ (u"ࠩࠪ䱯"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䱰"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䱱"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ䱲"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䱳"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ䱴") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"ࠨีํีๆืࠠๆษํࠤุ๐ๅศࠩ䱵"): name = l11lll_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䱶")
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䱷")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䱸")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䱹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䱺"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ䱻") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䱼"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧ䱽")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠪࠫ䱾")
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡲࡿࡣࡪ࡯ࡤࠫ䱿")+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䲀")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䲁"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䲂"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"ࠨࠩ䲃")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ䲄"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ䲅"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭䲆"),l11lll_l1_ (u"ࠬ࠱ࠧ䲇"))
	l1111_l1_ = [l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ䲈"),l11lll_l1_ (u"ࠧ࠰ࠩ䲉"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ䲊"),l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ䲋"),l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ䲌")]
	l1l11l1ll_l1_ = [l11lll_l1_ (u"ࠫฬ๊ใๅࠩ䲍"),l11lll_l1_ (u"ࠬอไฤใ็ห๊࠭䲎"),l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠩ䲏"),l11lll_l1_ (u"ࠧศๆส๊๏๋๊๊ࠡࠣห้้ัห๊้ࠫ䲐"),l11lll_l1_ (u"ࠨษ็ฬึอๅอࠢอ่๏็า๋๊้๎ฮ࠭䲑")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ䲒"), l1l11l1ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11lll_l1_ (u"ࠪࠫ䲓"):
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䲔"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭䲕"),l11lll_l1_ (u"࠭ࠧ䲖"),False,l11lll_l1_ (u"ࠧࠨ䲗"),l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䲘"))
		hostname = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䲙")]
		hostname = hostname.strip(l11lll_l1_ (u"ࠪ࠳ࠬ䲚"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭䲛")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l111ll_l1_,filter):
	if l11lll_l1_ (u"ࠬࡅ࠿ࠨ䲜") in l1ll11l111ll_l1_: url = l1ll11l111ll_l1_.split(l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䲝"))[0]
	else: url = l1ll11l111ll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䲞"):l1ll11l111ll_l1_,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䲟"):l11lll_l1_ (u"ࠩࠪ䲠")}
	filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䲡"),l11lll_l1_ (u"ࠫࠬ䲢"))
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ䲣"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ䲤"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ䲥"),l11lll_l1_ (u"ࠨࠩ䲦")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭䲧"))
	if type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䲨"):
		if l1l111ll1_l1_[0]+l11lll_l1_ (u"ࠫࡂࡃࠧ䲩") not in l1l11l1l_l1_: category = l1l111ll1_l1_[0]
		for i in range(len(l1l111ll1_l1_[0:-1])):
			if l1l111ll1_l1_[i]+l11lll_l1_ (u"ࠬࡃ࠽ࠨ䲪") in l1l11l1l_l1_: category = l1l111ll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ䲫")+category+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ䲬")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ䲭")+category+l11lll_l1_ (u"ࠩࡀࡁ࠵࠭䲮")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠫ࠭䲯"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ䲰")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ䲱"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䲲"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䲳")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䲴"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䲵"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠪࠫ䲶"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䲷"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠬ࠭䲸"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䲹")+l1l11l11_l1_
		l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111ll_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䲺"),l111ll_l1_+l11lll_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ䲻"),l1111111_l1_,361,l11lll_l1_ (u"ࠩࠪ䲼"),l11lll_l1_ (u"ࠪࠫ䲽"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䲾"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䲿"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭䳀")+l11lll11_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭䳁"),l1111111_l1_,361,l11lll_l1_ (u"ࠨࠩ䳂"),l11lll_l1_ (u"ࠩࠪ䳃"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䳄"))
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䳅"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䳆"),l11lll_l1_ (u"࠭ࠧ䳇"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䳈"),url,l11lll_l1_ (u"ࠨࠩ䳉"),l11lll_l1_ (u"ࠩࠪ䳊"),l11lll_l1_ (u"ࠪࠫ䳋"),l11lll_l1_ (u"ࠫࠬ䳌"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䳍"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"࠭࡜࡝ࠤࠪ䳎"),l11lll_l1_ (u"ࠧࠣࠩ䳏")).replace(l11lll_l1_ (u"ࠨ࡞࡟࠳ࠬ䳐"),l11lll_l1_ (u"ࠩ࠲ࠫ䳑"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭䳒"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ䳓"),block+l11lll_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ䳔"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ䳕") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ䳖"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠨ࠿ࡀࠫ䳗") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䳘"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ䳙")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111ll_l1_)
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳚"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠬ䳛"),l1111111_l1_,361,l11lll_l1_ (u"࠭ࠧ䳜"),l11lll_l1_ (u"ࠧࠨ䳝"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䳞"))
				else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳟"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠪ䳠"),l11l11l_l1_,364,l11lll_l1_ (u"ࠫࠬ䳡"),l11lll_l1_ (u"ࠬ࠭䳢"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ䳣"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ䳤")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䳥")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ䳦")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧ䳧")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ䳨")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳩"),l111ll_l1_+name+l11lll_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ䳪"),l11l11l_l1_,365,l11lll_l1_ (u"ࠧࠨ䳫"),l11lll_l1_ (u"ࠨࠩ䳬"),l1l1l11l_l1_+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䳭"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠪࡶࠬ䳮") or value==l11lll_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ䳯"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䳰") in option: continue
			if l11lll_l1_ (u"࠭วๅๅ็ࠫ䳱") in option: continue
			if l11lll_l1_ (u"ࠧ࡯࠯ࡤࠫ䳲") in value: continue
			#if value in [l11lll_l1_ (u"ࠨࡴࠪ䳳"),l11lll_l1_ (u"ࠩࡱࡧ࠲࠷࠷ࠨ䳴"),l11lll_l1_ (u"ࠪࡸࡻ࠳࡭ࡢࠩ䳵")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ䳶"): option = value
			if option==l11lll_l1_ (u"ࠬ࠭䳷"): option = value
			l11l1ll11_l1_ = option
			l1l11l1llll_l1_ = re.findall(l11lll_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ䳸"),option,re.DOTALL)
			if l1l11l1llll_l1_: l11l1ll11_l1_ = l1l11l1llll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠧ࠻ࠢࠪ䳹")+l11l1ll11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ䳺")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࡁࠬ䳻")+l11l1ll11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭䳼")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂࡃࠧ䳽")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ䳾")+l1l1llll_l1_
			if type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ䳿"):
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴀"),l111ll_l1_+l1lll1lll_l1_,url,365,l11lll_l1_ (u"ࠨࠩ䴁"),l11lll_l1_ (u"ࠩࠪ䴂"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䴃"))
			elif type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䴄") and l1l111ll1_l1_[-2]+l11lll_l1_ (u"ࠬࡃ࠽ࠨ䴅") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䴆"))
				#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䴇"),l11lll_l1_ (u"ࠨࠩ䴈"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䴉")+l1l1111l_l1_
				l1111111_l1_ = l11ll1lll_l1_(l11l1l1_l1_,l1ll11l111ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䴊"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,361,l11lll_l1_ (u"ࠫࠬ䴋"),l11lll_l1_ (u"ࠬ࠭䴌"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䴍"))
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴎"),l111ll_l1_+l1lll1lll_l1_,url,364,l11lll_l1_ (u"ࠨࠩ䴏"),l11lll_l1_ (u"ࠩࠪ䴐"),l1ll1ll1_l1_)
	return
l1l111ll1_l1_ = [l11lll_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ䴑"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ䴒"),l11lll_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ䴓")]
l1l1111l1_l1_ = [l11lll_l1_ (u"࠭࡭ࡱࡣࡤࠫ䴔"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䴕"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䴖"),l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ䴗"),l11lll_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫ䴘"),l11lll_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭䴙"),l11lll_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ䴚"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䴛")]
def l11ll1lll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䴜") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䴝"),l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࠪ䴞"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䴟"),l11lll_l1_ (u"ࠫ࠿ࡀ࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭࠯ࠨ䴠"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬࡃ࠽ࠨ䴡"),l11lll_l1_ (u"࠭࠯ࠨ䴢"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧࠧࠨࠪ䴣"),l11lll_l1_ (u"ࠨ࠱ࠪ䴤"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䴥"),l11lll_l1_ (u"ࠪࠫ䴦"),filters,l11lll_l1_ (u"ࠫࡎࡔࠠࠡࠢࠣࠫ䴧")+mode)
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ䴨")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䴩")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ䴪")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠩࠫ䴫"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠩࠪ䴬")
	if l11lll_l1_ (u"ࠪࡁࡂ࠭䴭") in filters:
		items = filters.split(l11lll_l1_ (u"ࠫࠫࠬࠧ䴮"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠬࡃ࠽ࠨ䴯"))
			l1l11ll1_l1_[var] = value
	for key in l1l1111l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ䴰")
		if l11lll_l1_ (u"ࠧࠦࠩ䴱") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䴲") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ䴳"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ䴴")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䴵") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ䴶"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ䴷")+key+l11lll_l1_ (u"ࠧ࠾࠿ࠪ䴸")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ䴹"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ䴺")+key+l11lll_l1_ (u"ࠪࡁࡂ࠭䴻")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ䴼"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ䴽"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䴾"),l11lll_l1_ (u"ࠧࠨ䴿"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠨࡑࡘࡘࠬ䵀"))
	return l1ll1l1l_l1_
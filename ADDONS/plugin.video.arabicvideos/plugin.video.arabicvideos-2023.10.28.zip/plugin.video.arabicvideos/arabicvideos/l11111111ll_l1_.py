# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭媐")
headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ媑") : l11lll_l1_ (u"ࠩࠪ媒") }
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ媓")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1111l_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llllll_l1_(url)
	elif mode==214: results = l1111111l111_l1_(url)
	elif mode==215: results = l1111111l11l_l1_(url)
	elif mode==218: results = l11lllll11ll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11lllll11ll_l1_():
	message = l11lll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ媔")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭媕"),l11lll_l1_ (u"࠭ࠧ媖"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ媗"),l11lll_l1_ (u"ࠨษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠧ媘"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媙"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ媚"),l11lll_l1_ (u"ࠫࠬ媛"),219,l11lll_l1_ (u"ࠬ࠭媜"),l11lll_l1_ (u"࠭ࠧ媝"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ媞"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媟"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠧ媠"),l11lll_l1_ (u"ࠪࠫ媡"),114,l11ll1_l1_)
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ媢")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媣"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ媤")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ媥"),url,211)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ媦"),headers,l11lll_l1_ (u"ࠩࠪ媧"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ媨"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ媩"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媪"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ媫")+link
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媬"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媭")+l111ll_l1_+title,url,211)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ媮"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭媯"),block,re.DOTALL)
	l1l1l1_l1_ = [l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ媰"),l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ媱")]
	#l111l11l1_l1_ = [l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ媲"),l11lll_l1_ (u"ࠧศใ็ห๊ࠦࠧ媳"),l11lll_l1_ (u"ࠨสิห๊าࠧ媴"),l11lll_l1_ (u"ࠩ฼ีํ฼ࠧ媵"),l11lll_l1_ (u"ࠪ็้๐ศศฬࠪ媶"),l11lll_l1_ (u"ࠫฬเว็๋ࠪ媷")]
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ媸"))
		if not any(value in title for value in l1l1l1_l1_):
		#	if any(value in title for value in l111l11l1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媹"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ媺")+l111ll_l1_+title,link,211)
	return html
def l1111l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ媻"),headers,l11lll_l1_ (u"ࠩࠪ媼"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭媽"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ媾"),l11lll_l1_ (u"ࠬ࠭媿"),url,html)
	if l11lll_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ嫀") in url or l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ嫁") in url: block = html
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡏࡨࡨ࡮ࡧࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ嫂"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: return
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫃"),block,re.DOTALL)
	l1l1_l1_ = []
	l111llll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ嫄"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ嫅"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ嫆"),l11lll_l1_ (u"࠭ใๅ์หࠫ嫇"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭嫈"),l11lll_l1_ (u"ࠨ้าหๆ࠭嫉"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ嫊"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ嫋"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ嫌"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ嫍")]
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ嫎") in link: continue
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩ嫏"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ嫐"))
		if l11lll_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ嫑") in link or any(value in title for value in l111llll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嫒"),l111ll_l1_+title,link,212,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ嫓") in link and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ嫔") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ嫕"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭嫖") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫗"),l111ll_l1_+title,link,213,l1llll_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫘"),l111ll_l1_+title,link,213,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ嫙"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫚"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠬอไึใะอࠥ࠭嫛"),l11lll_l1_ (u"࠭ࠧ嫜"))
			if title!=l11lll_l1_ (u"ࠧࠨ嫝"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫞"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ嫟")+title,link,211)
	return
def l1llllll_l1_(url):
	l11l1111l_l1_,items,l111l11l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫ嫠"),headers,l11lll_l1_ (u"ࠫࠬ嫡"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ嫢"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡴࡪ࠯࡯࡭ࡸࡺ࠭࡯ࡷࡰࡦࡪࡸࡥࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嫣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11_l1_ = l11lll_l1_ (u"ࠧࠨ嫤").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嫥"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ嫦"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ嫧"))
		title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ嫨") + link.split(l11lll_l1_ (u"ࠬ࠵ࠧ嫩"))[-1].replace(l11lll_l1_ (u"࠭࠭ࠨ嫪"),l11lll_l1_ (u"ࠧࠡࠩ嫫"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨษ็ั้่ษ࠮ࠪ࡟ࡨ࠰࠯ࠧ嫬"),link.split(l11lll_l1_ (u"ࠩ࠲ࠫ嫭"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠪ࠴ࠬ嫮")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lllll_l1_ = str(items).count(l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭嫯"))
	l11l1111l_l1_ = str(items).count(l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ嫰"))
	if l111lllll_l1_>1 and l11l1111l_l1_>0 and l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ嫱") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ嫲") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫳"),l111ll_l1_+title,link,213)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ嫴") not in link: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嫵"),l111ll_l1_+title,link,212)
	return
def PLAY(url):
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭嫶"))
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭嫷"),headers,l11lll_l1_ (u"࠭ࠧ嫸"),l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ嫹"))
	# l11l1ll1l_l1_ links
	if l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ嫺") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ嫻"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ嫼"),headers,l11lll_l1_ (u"ࠫࠬ嫽"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭嫾"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ嫿"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ嬀"),block,re.DOTALL)
			if items:
				id = re.findall(l11lll_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ嬁"),l11lll1l_l1_,re.DOTALL)
				if id:
					l11lll1ll1_l1_ = id[0]
					for link,title in items:
						link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ嬂")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ嬃")+link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嬄")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嬅")
						l1111_l1_.append(link)
			else:
				# https://l1111111l1l1_l1_.tv/l11l1ll1l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ嬆"),block,re.DOTALL)
				for link,dummy in items:
					l1111_l1_.append(link)
	# download links
	if l11lll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ嬇") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ嬈"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ嬉"),headers,l11lll_l1_ (u"ࠪࠫ嬊"),l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ嬋"))
		id = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嬌"),l11lll1l_l1_,re.DOTALL)
		if id:
			l11lll1ll1_l1_ = id[0]
			l1l1ll1ll_l1_ = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ嬍"):l11lll_l1_ (u"ࠧࠨ嬎") , l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ嬏"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ嬐") }
			l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭嬑")+l11lll1ll1_l1_
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ嬒"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭嬓"),l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ嬔"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠶࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ嬕"),l11lll1l_l1_,re.DOTALL)
			if l1l1ll1_l1_:
				for resolution,block in l1l1ll1_l1_:
					items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嬖"),block,re.DOTALL)
					for name,link in items:
						l1111_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ嬗")+name+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ嬘")+l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ嬙")+resolution)
			else:
				l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠷ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ嬚"),l11lll1l_l1_,re.DOTALL)
				if not l1l1ll1_l1_: l1l1ll1_l1_ = [l11lll1l_l1_]
				for block in l1l1ll1_l1_:
					l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡥࡳࡸࡨࡶࡸ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠎࠎࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࡜࠯࠴ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧศๆาๆฮࠦࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡲࡦࡳࡥࠢ࠿ࠪࠫ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨࠤ࠰ࠦࠧࠡโࠣࠫࠏࠏࠉࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࠪࠫࠏࠏࠉࠊࠋࠌࠦࠧࠨ嬛")
					name = l11lll_l1_ (u"ࠧࠨ嬜")
					items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ嬝"),block,re.DOTALL)
					for link in items:
						server = l11lll_l1_ (u"ࠩࠩࠪࠬ嬞") + link.split(l11lll_l1_ (u"ࠪ࠳ࠬ嬟"))[2].lower() + l11lll_l1_ (u"ࠫࠫࠬࠧ嬠")
						server = server.replace(l11lll_l1_ (u"ࠬ࠴ࡣࡰ࡯ࠩࠪࠬ嬡"),l11lll_l1_ (u"࠭ࠧ嬢")).replace(l11lll_l1_ (u"ࠧ࠯ࡥࡲࠪࠫ࠭嬣"),l11lll_l1_ (u"ࠨࠩ嬤"))
						server = server.replace(l11lll_l1_ (u"ࠩ࠱ࡲࡪࡺࠦࠧࠩ嬥"),l11lll_l1_ (u"ࠪࠫ嬦")).replace(l11lll_l1_ (u"ࠫ࠳ࡵࡲࡨࠨࠩࠫ嬧"),l11lll_l1_ (u"ࠬ࠭嬨"))
						server = server.replace(l11lll_l1_ (u"࠭࠮࡭࡫ࡹࡩࠫࠬࠧ嬩"),l11lll_l1_ (u"ࠧࠨ嬪")).replace(l11lll_l1_ (u"ࠨ࠰ࡲࡲࡱ࡯࡮ࡦࠨࠩࠫ嬫"),l11lll_l1_ (u"ࠩࠪ嬬"))
						server = server.replace(l11lll_l1_ (u"ࠪࠪࠫ࡮ࡤ࠯ࠩ嬭"),l11lll_l1_ (u"ࠫࠬ嬮")).replace(l11lll_l1_ (u"ࠬࠬࠦࡸࡹࡺ࠲ࠬ嬯"),l11lll_l1_ (u"࠭ࠧ嬰"))
						server = server.replace(l11lll_l1_ (u"ࠧࠧࠨࠪ嬱"),l11lll_l1_ (u"ࠨࠩ嬲"))
						link = link + l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ嬳") + name + server + l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ嬴")
						l1111_l1_.append(link)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嬵"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭嬶"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ嬷"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ嬸"),l11lll_l1_ (u"ࠨ࠭ࠪ嬹"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭嬺")+search
	l1111l_l1_(url)
	return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠤࡸ࡫ࡣࡰࡰࡧࡥࡷࡿࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣࡩࡧࡦ࡯ࡲࡧࡲ࡬࠯ࡥࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡥࡤࡸࡪ࡭࡯ࡳࡻࠬࠎࠎࠏࠉࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ࠲ࠠࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵ࠥࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭ࠫࡴࡧࡤࡶࡨ࡮ࠫࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ࠱ࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ嬻")
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ戎")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ戏")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭成"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1111l_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1lll1l11l1l1_l1_(url)
	elif mode==314: results = l1lllll1l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ我"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ戒"),l11lll_l1_ (u"ࠬ࠭戓"),319,l11lll_l1_ (u"࠭ࠧ戔"),l11lll_l1_ (u"ࠧࠨ戕"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ或"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ戗"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠨ战"),l11lll_l1_ (u"ࠫࠬ戙"),114,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ戚"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ戛"),l11lll_l1_ (u"ࠧࠨ戜"),l11lll_l1_ (u"ࠨࠩ戝"),l11lll_l1_ (u"ࠩࠪ戞"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ戟"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ戠"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ戡"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭戢"),l11lll_l1_ (u"ࠧࠨ戣"),9999)
	items = re.findall(l11lll_l1_ (u"ࠨ࠾࡫࠹ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠵࠿ࠩ戤"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11lll_l1_ (u"ࠩࠣࠫ戥"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ戦"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭戧")+l111ll_l1_+title,l11ll1_l1_,314,l11lll_l1_ (u"ࠬ࠭戨"),l11lll_l1_ (u"࠭ࠧ戩"),str(seq+1))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ截"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ戫")+l111ll_l1_+l11lll_l1_ (u"่ࠩๆฬ฽ูࠡึ๊ีࠬ戬"),l11ll1_l1_,314,l11lll_l1_ (u"ࠪࠫ戭"),l11lll_l1_ (u"ࠫࠬ戮"),l11lll_l1_ (u"ࠬ࠶ࠧ戯"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ戰"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ戱"),l11lll_l1_ (u"ࠨࠩ戲"),9999)
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡇࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂ࠿ࠩ戳"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ戴")+link
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭戵"))
		#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫ戶")
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭户"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ戸")+l111ll_l1_+title,link,311)
	return html
def l1lllll1l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ戹"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ戺"),l11lll_l1_ (u"ࠪࠫ戻"),l11lll_l1_ (u"ࠫࠬ戼"),l11lll_l1_ (u"ࠬ࠭戽"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭戾"))
	html = response.content
	if seq==l11lll_l1_ (u"ࠧ࠱ࠩ房"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭所"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ扁"),block,re.DOTALL)
		for link,name,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ扂")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭扃"))
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ扄"))
			title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ扅")+name+l11lll_l1_ (u"ࠧࠪࠩ扆")
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ扇"),l111ll_l1_+title,link,312)
	elif seq in [l11lll_l1_ (u"ࠩ࠴ࠫ扈"),l11lll_l1_ (u"ࠪ࠶ࠬ扉"),l11lll_l1_ (u"ࠫ࠸࠭扊")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ手"),html,re.DOTALL)
		l1lll1l11l1ll_l1_ = int(seq)-1
		block = l1l1ll1_l1_[l1lll1l11l1ll_l1_]
		if seq==l11lll_l1_ (u"࠭࠱ࠨ扌"): items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ才"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ扎"),block,re.DOTALL)
		for link,l1llll_l1_,title,name in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ扏")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ扐")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭扑"))
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ扒"))
			title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ打")+name+l11lll_l1_ (u"ࠧࠪࠩ扔")
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ払"),l111ll_l1_+title,link,311,l1llll_l1_)
	elif seq in [l11lll_l1_ (u"ࠩ࠷ࠫ扖"),l11lll_l1_ (u"ࠪ࠹ࠬ扗"),l11lll_l1_ (u"ࠫ࠻࠭托")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ扙"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1ll1_l1_[seq]
		items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ扚"),block,re.DOTALL)
		for l1llll_l1_,link,l1l11l1llll_l1_,title,l1ll111l11l_l1_ in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ扛")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ扜")+link
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ扝"))
			l1l11l1llll_l1_ = l1l11l1llll_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ扞"))
			l1ll111l11l_l1_ = l1ll111l11l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭扟"))
			if l1l11l1llll_l1_: name = l1l11l1llll_l1_
			else: name = l1ll111l11l_l1_
			title = title+l11lll_l1_ (u"ࠬࠦࠨࠨ扠")+name+l11lll_l1_ (u"࠭ࠩࠨ扡")
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭扢"),l111ll_l1_+title,link,312,l1llll_l1_)
	return
def l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ扣"),url,l11lll_l1_ (u"ࠩࠪ扤"),l11lll_l1_ (u"ࠪࠫ扥"),l11lll_l1_ (u"ࠫࠬ扦"),l11lll_l1_ (u"ࠬ࠭执"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭扨"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ扩"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	if l11lll_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ扪") in block:
		items = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ扫"),block,re.DOTALL)
		if items:
			for l1llll_l1_,link,title,count in items:
				l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ扬")+l1llll_l1_
				link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭扭")+link
				count = count.replace(l11lll_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ扮"),l11lll_l1_ (u"࠭࠺ࠨ扯"))
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ扰"))
				title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ扱")+count+l11lll_l1_ (u"ࠩࠬࠫ扲")
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ扳"),l111ll_l1_+title,link,311,l1llll_l1_)
	else:
		items = re.findall(l11lll_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ扴"),block,re.DOTALL)
		for link,title,l1lll1l11ll11_l1_,l1l1l1111_l1_ in items:
			if title==l11lll_l1_ (u"ࠬ࠭扵") or l1lll1l11ll11_l1_==l11lll_l1_ (u"࠭ࠧ扶"): continue
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ扷")+link
			title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ扸")+l1l1l1111_l1_+l11lll_l1_ (u"ࠩࠬࠫ批")
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ扺"),l111ll_l1_+title,link,312)
	if not items: l1llllll_l1_(html)
	return
def l1llllll_l1_(html):
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ扻"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ扼"),block,re.DOTALL)
	for link,title,name,count,l1l1l1111_l1_ in items:
		link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ扽")+link
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ找"))
		name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ承"))
		title = title+l11lll_l1_ (u"ࠩࠣࠬࠬ技")+name+l11lll_l1_ (u"ࠪ࠭ࠬ抁")
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ抂"),l111ll_l1_+title,link,312,l11lll_l1_ (u"ࠬ࠭抃"),l1l1l1111_l1_)
	return
def l1lll1l11l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ抄"),url,l11lll_l1_ (u"ࠧࠨ抅"),l11lll_l1_ (u"ࠨࠩ抆"),l11lll_l1_ (u"ࠩࠪ抇"),l11lll_l1_ (u"ࠪࠫ抈"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ抉"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭把"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		l1111l_l1_(url)
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ抋"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ抌")+link
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ抍"))
		if l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ抎") in link: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ抏"),l111ll_l1_+title,link,312)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ抐"),l111ll_l1_+title,link,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ抑"),url,l11lll_l1_ (u"࠭ࠧ抒"),l11lll_l1_ (u"ࠧࠨ抓"),l11lll_l1_ (u"ࠨࠩ抔"),l11lll_l1_ (u"ࠩࠪ投"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ抖"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ抗"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ折"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ抙"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ抚"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ抛"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ抜"),l11lll_l1_ (u"ࠪ࠯ࠬ抝"))
	l1lll1l11ll1l_l1_ = [l11lll_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ択"),l11lll_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ抟"),l11lll_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ抠")]
	if l1ll_l1_:
		l1lll1l11l11l_l1_ = [l11lll_l1_ (u"ࠧใษิสࠬ抡"),l11lll_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ抢"),l11lll_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ抣")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ护"), l1lll1l11l11l_l1_)
		if l1l_l1_ == -1: return
	elif l11lll_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ报") in options: l1l_l1_ = 0
	elif l11lll_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ抦") in options: l1l_l1_ = 1
	elif l11lll_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ抧") in options: l1l_l1_ = 2
	else: return
	type = l1lll1l11ll1l_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ抨")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ抩"),url,l11lll_l1_ (u"ࠩࠪ抪"),l11lll_l1_ (u"ࠪࠫ披"),l11lll_l1_ (u"ࠫࠬ抬"),l11lll_l1_ (u"ࠬ࠭抭"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭抮"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ抯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ抰"),block,re.DOTALL)
			for link,l1llll_l1_,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ抱"))
				name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ抲"))
				title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ抳")+name+l11lll_l1_ (u"ࠬ࠯ࠧ抴")
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抵"),l111ll_l1_+title,link,313,l1llll_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭抶"),block,re.DOTALL)
			for link,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ抷"))
				name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ抸"))
				title = title+l11lll_l1_ (u"ࠪࠤ࠭࠭抹")+name+l11lll_l1_ (u"ࠫ࠮࠭抺")
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ抻"),l111ll_l1_+title,link,312)
	return
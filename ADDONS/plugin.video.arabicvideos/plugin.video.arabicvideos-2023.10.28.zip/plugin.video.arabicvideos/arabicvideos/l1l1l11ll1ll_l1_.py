# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ旐")
headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ旑"):l11lll_l1_ (u"ࠬ࠭旒")}
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ旓")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ旔"),l11lll_l1_ (u"ࠨࡹࡺࡩࠬ旕")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1111l_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llllll_l1_(url,text)
	elif mode==564: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ旖")+text)
	elif mode==565: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ旗")+text)
	elif mode==566: results = l1l11l_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ旘"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭旙"),l11lll_l1_ (u"࠭ࠧ旚"),False,l11lll_l1_ (u"ࠧࠨ旛"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ旜"))
	#hostname = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ旝")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠪ࠳ࠬ旞"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ旟")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ无"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ旡"),l11lll_l1_ (u"ࠧࠨ既"),l11lll_l1_ (u"ࠨࠩ旣"),l11lll_l1_ (u"ࠩࠪ旤"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ日"))
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ旦"),l111ll_l1_+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ旧"),l11lll_l1_ (u"࠭ࠧ旨"),8)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ早"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ旪"),l11lll_l1_ (u"ࠩࠪ旫"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ旬"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ旭"),l11ll1_l1_,569,l11lll_l1_ (u"ࠬ࠭旮"),l11lll_l1_ (u"࠭ࠧ旯"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ旰"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ旱"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ旲"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ旳"),564)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ旴"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ旵"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭时"),565)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ旷"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ旸"),l11lll_l1_ (u"ࠩࠪ旹"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ旺"):hostname,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ旻"):l11lll_l1_ (u"ࠬ࠭旼")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ旽"),l11lll_l1_ (u"ࠧ࠰ࠩ旾"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࡢࡢࡴࠫ࠲࠯ࡅࠩࡧ࡫࡯ࡸࡪࡸࠧ旿"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ昀"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠪࠩࡩ࠿ࠥ࠹࠷ࠨࡨ࠽ࠫࡢ࠶ࠧࡧ࠼ࠪࡧ࠷ࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡦ࠾ࠫࡤ࠹ࠧࡤ࠽࠲ࠫࡤ࠹ࠧࡤࡨࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡢ࠻ࠪ昁") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昂"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ昃")+l111ll_l1_+title,link,566)
	#	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ昄"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ昅"),l11lll_l1_ (u"ࠨࠩ昆"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭昇"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ昈"),l11lll_l1_ (u"ࠫࠬ昉"),l11lll_l1_ (u"ࠬ࠭昊"),l11lll_l1_ (u"࠭ࠧ昋"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ昌"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡷࡑ࡯ࡳࡵࡄࡸࡸࡹࡵ࡮ࠣࠩ昍"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭明"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ昏") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ昐"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠬ࠭昑"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭昒"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ易")+l111ll_l1_+title,link,566)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭昔"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ昕"),l11lll_l1_ (u"ࠪࠫ昖"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭昗"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ昘"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭昙"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ昚")+l111ll_l1_+title,link,566,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ昛"),l11lll_l1_ (u"ࠩࠪ昜"),url,l11lll_l1_ (u"ࠪࠫ昝"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ昞"):url,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ星"):l11lll_l1_ (u"࠭ࠧ映")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ昡"),url,l11lll_l1_ (u"ࠨࠩ昢"),l11lll_l1_ (u"ࠩࠪ昣"),l11lll_l1_ (u"ࠪࠫ昤"),l11lll_l1_ (u"ࠫࠬ春"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ昦"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭昧"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ昨"),url,564)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ昩"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ昪"),url,565)
	if l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ昫") in html:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昬"),l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭昭"),url,561,l11lll_l1_ (u"࠭ࠧ昮"),l11lll_l1_ (u"ࠧࠨ是"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ昰"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ昱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭昲"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昳"),l111ll_l1_+title,link,561)
	return
def l1111l_l1_(l1ll11l111ll_l1_,type=l11lll_l1_ (u"ࠬ࠭昴")):
	if l11lll_l1_ (u"࠭࠺࠻ࠩ昵") in l1ll11l111ll_l1_:
		l11l1l1_l1_,url = l1ll11l111ll_l1_.split(l11lll_l1_ (u"ࠧ࠻࠼ࠪ昶"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ昷"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l111ll_l1_,l1ll11l111ll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ昸"):l11l1l1_l1_,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ昹"):l11lll_l1_ (u"ࠫࠬ昺")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ昻"),url,l11lll_l1_ (u"࠭ࠧ昼"),l11lll_l1_ (u"ࠧࠨ昽"),l11lll_l1_ (u"ࠨࠩ显"),l11lll_l1_ (u"ࠩࠪ昿"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ晀"))
	html = response.content
	if type==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭晁"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠩ時"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ晃"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ晄"),l11lll_l1_ (u"ࠨ࠱ࠪ晅")).replace(l11lll_l1_ (u"ࠩ࡟ࡠࠧ࠭晆"),l11lll_l1_ (u"ࠪࠦࠬ晇"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ晈"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ晉"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ晊"),l11lll_l1_ (u"ࠧࠨ晋"))
			if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ晌") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晍"),l111ll_l1_+title,link,563,l1llll_l1_)
			elif l11lll_l1_ (u"ࠪั้่ษࠨ晎") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠯า๊โสࠢ࠮ࡠࡩ࠱ࠧ晏"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ晐") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭晑"),l111ll_l1_+title,link,563,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭晒"),l111ll_l1_+title,link,562,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ晓"):
			l1lll111lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ晔"),block,re.DOTALL)
			if l1lll111lll_l1_:
				count = l1lll111lll_l1_[0]
				link = url+l11lll_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ晕")+count
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ晖"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ晗"),link,561,l11lll_l1_ (u"࠭ࠧ晘"),l11lll_l1_ (u"ࠧࠨ晙"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ晚"))
		elif type==l11lll_l1_ (u"ࠩࠪ晛"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ晜"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ晝"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ晞")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭晟"),l111ll_l1_+title,link,561)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠧࠨ晠")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ晡"),l11lll_l1_ (u"ࠩࠪ晢"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ晣"),url,l11lll_l1_ (u"ࠫࠬ晤"),l11lll_l1_ (u"ࠬ࠭晥"),l11lll_l1_ (u"࠭ࠧ晦"),l11lll_l1_ (u"ࠧࠨ晧"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ晨"))
	html = response.content
	html = l111l_l1_(html)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࡡ࠭࠲࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠳ࠧ࠭ࠩࠣࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍ࡮࡬ࠠࠨ็๋ื๊࠭ࠠࡪࡰࠣࡲࡦࡳࡥࠡࡣࡱࡨࠥࡴ࡯ࡵࠢࡷࡽࡵ࡫࠺ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨ็๋ื๊࠭ࠩ࡜࠲ࡠࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ๅีษ๊ำฮ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࡨࡰ࡮࡬ࠠࠨฯ็ๆฮ࠭ࠠࡪࡰࠣࡲࡦࡳࡥ࠻ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩะ่็ฯࠧࠪ࡝࠳ࡡࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧๆึส๋ิฯࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠦࠧࠨ晩")
	# l1lllll_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ晪"),html,re.DOTALL)
	if not type and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭晫"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ晬")+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭晭"),l111ll_l1_+title,link,563,l11lll_l1_ (u"ࠧࠨ普"),l11lll_l1_ (u"ࠨࠩ景"),l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ晰"))
			return
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࡵࡁࠫ晱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ晲"),block)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭晳"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ晴"),str(items))
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ晵"))
			#title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ晶")+title
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ晷"),l111ll_l1_+title,link,562)
	if not menuItemsLIST:
		title = re.findall(l11lll_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ晸"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠫࠥ࠳ࠠๆษํࠤุ๐ๅศࠩ晹"),l11lll_l1_ (u"ࠬ࠭智")).replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ晻"),l11lll_l1_ (u"ࠧࠨ晼"))
		else: title = l11lll_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭晽")
		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ晾"),l111ll_l1_+title,url,562)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ晿"),url,l11lll_l1_ (u"ࠫࠬ暀"),l11lll_l1_ (u"ࠬ࠭暁"),l11lll_l1_ (u"࠭ࠧ暂"),l11lll_l1_ (u"ࠧࠨ暃"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ暄"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ษ็ฮฺ์๊โ࠾࠱࠮ࡄࡂࡡ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ暅"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡈࡱࡧ࡫ࡤࠣࠩ暆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ暇"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ暈") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"࠭ำ๋ำไีࠥ๎๊ࠡีํ้ฬ࠭暉"): name = l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ暊")
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ暋")+name+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ暌")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡹࡴ࠮࠯ࡇࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ暍"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ暎"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ暏") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ暐"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬ暑")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠨࠩ暒")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡺࡩࡨ࡯࡭ࡢࠩ暓")+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ暔")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ暕"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ暖"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"࠭ࠧ暗")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ暘"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ暙"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ暚"),l11lll_l1_ (u"ࠪ࠯ࠬ暛"))
	l1111_l1_ = [l11lll_l1_ (u"ࠫ࠴࠭暜"),l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ暝"),l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ暞"),l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ暟"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ暠")]
	l1l11l1ll_l1_ = [l11lll_l1_ (u"ࠩฦๅ้อๅࠨ暡"),l11lll_l1_ (u"ุ้๊ࠪำๅษอࠫ暢"),l11lll_l1_ (u"ࠫศ์๊ๆ์ࠣ์่ืส้่ࠪ暣"),l11lll_l1_ (u"ࠬฮัศ็ฯࠤฯ๊๊โิํ์๋࠭暤"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠล้๎๊๐ࠧ暥")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅุๆ๋ฬ࠿࠭暦"), l1l11l1ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11ll1_l1_
		#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ暧"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ暨"),l11lll_l1_ (u"ࠪࠫ暩"),False,l11lll_l1_ (u"ࠫࠬ暪"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ暫"))
		#hostname = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ暬")]
		#hostname = response.url
		#hostname = hostname.strip(l11lll_l1_ (u"ࠧ࠰ࠩ暭"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ暮")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l111ll_l1_,filter):
	if l11lll_l1_ (u"ࠩࡂࡃࠬ暯") in l1ll11l111ll_l1_: url = l1ll11l111ll_l1_.split(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ暰"))[0]
	else: url = l1ll11l111ll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ暱"):l1ll11l111ll_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ暲"):l11lll_l1_ (u"࠭ࠧ暳")}
	filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ暴"),l11lll_l1_ (u"ࠨࠩ暵"))
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭暶"),1)
	if filter==l11lll_l1_ (u"ࠪࠫ暷"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬ暸"),l11lll_l1_ (u"ࠬ࠭暹")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ暺"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ暻"):
		if l1l111ll1_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࡀࠫ暼") not in l1l11l1l_l1_: category = l1l111ll1_l1_[0]
		for i in range(len(l1l111ll1_l1_[0:-1])):
			if l1l111ll1_l1_[i]+l11lll_l1_ (u"ࠩࡀࡁࠬ暽") in l1l11l1l_l1_: category = l1l111ll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭暾")+category+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨ暿")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ曀")+category+l11lll_l1_ (u"࠭࠽࠾࠲ࠪ曁")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ曂"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ曃")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ曄"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭曅"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ曆")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭曇"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ曈"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨ曉"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ曊"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪ曋"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ曌")+l1l11l11_l1_
		l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111ll_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ曍"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ曎"),l1111111_l1_,561,l11lll_l1_ (u"࠭ࠧ曏"),l11lll_l1_ (u"ࠧࠨ曐"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ曑"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ曒"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ曓")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ曔"),l1111111_l1_,561,l11lll_l1_ (u"ࠬ࠭曕"),l11lll_l1_ (u"࠭ࠧ曖"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ曗"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭曘"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ曙"),l11lll_l1_ (u"ࠪࠫ曚"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ曛"),url,l11lll_l1_ (u"ࠬ࠭曜"),l11lll_l1_ (u"࠭ࠧ曝"),l11lll_l1_ (u"ࠧࠨ曞"),l11lll_l1_ (u"ࠨࠩ曟"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ曠"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ曡"),l11lll_l1_ (u"ࠫࠧ࠭曢")).replace(l11lll_l1_ (u"ࠬࡢ࡜࠰ࠩ曣"),l11lll_l1_ (u"࠭࠯ࠨ曤"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ曥"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭曦"),block+l11lll_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭曧"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ曨") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭曩"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠬࡃ࠽ࠨ曪") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ曫"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ曬")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111ll_l1_)
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ曭"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩ曮"),l1111111_l1_,561,l11lll_l1_ (u"ࠪࠫ曯"),l11lll_l1_ (u"ࠫࠬ曰"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭曱"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曲"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ曳"),l11l11l_l1_,564,l11lll_l1_ (u"ࠨࠩ更"),l11lll_l1_ (u"ࠩࠪ曵"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ曶"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ曷")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ書")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ曹")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ曺")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ曻")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ曼"),l111ll_l1_+name+l11lll_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ曽"),l11l11l_l1_,565,l11lll_l1_ (u"ࠫࠬ曾"),l11lll_l1_ (u"ࠬ࠭替"),l1l1l11l_l1_+l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ最"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠧࡳࠩ朁") or value==l11lll_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ朂"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ會") in option: continue
			if l11lll_l1_ (u"ࠪห้้ไࠨ朄") in option: continue
			if l11lll_l1_ (u"ࠫࡳ࠳ࡡࠨ朅") in value: continue
			#if value in [l11lll_l1_ (u"ࠬࡸࠧ朆"),l11lll_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ朇"),l11lll_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭月")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ有"): option = value
			if option==l11lll_l1_ (u"ࠩࠪ朊"): option = value
			l11l1ll11_l1_ = option
			l1l11l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ朋"),option,re.DOTALL)
			if l1l11l1llll_l1_: l11l1ll11_l1_ = l1l11l1llll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠫ࠿ࠦࠧ朌")+l11l1ll11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ服")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩ朎")+l11l1ll11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ朏")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫ朐")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭朑")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ朒"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朓"),l111ll_l1_+l1lll1lll_l1_,url,565,l11lll_l1_ (u"ࠬ࠭朔"),l11lll_l1_ (u"࠭ࠧ朕"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ朖"))
			elif type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ朗") and l1l111ll1_l1_[-2]+l11lll_l1_ (u"ࠩࡀࡁࠬ朘") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭朙"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ朚"),l11lll_l1_ (u"ࠬ࠭望"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ朜")+l1l1111l_l1_
				l1111111_l1_ = l11ll1lll_l1_(l11l1l1_l1_,l1ll11l111ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ朝"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,561,l11lll_l1_ (u"ࠨࠩ朞"),l11lll_l1_ (u"ࠩࠪ期"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ朠"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朡"),l111ll_l1_+l1lll1lll_l1_,url,564,l11lll_l1_ (u"ࠬ࠭朢"),l11lll_l1_ (u"࠭ࠧ朣"),l1ll1ll1_l1_)
	return
l1l111ll1_l1_ = [l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭朤"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ朥"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ朦")]
l1l1111l1_l1_ = [l11lll_l1_ (u"ࠪࡱࡵࡧࡡࠨ朧"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ木"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ朩"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ未"),l11lll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ末"),l11lll_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ本"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ札"),l11lll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ朮")]
def l11ll1lll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ术") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ朰"),l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ朱"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭朲"),l11lll_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ朳"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩࡀࡁࠬ朴"),l11lll_l1_ (u"ࠪ࠳ࠬ朵"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫࠫࠬࠧ朶"),l11lll_l1_ (u"ࠬ࠵ࠧ朷"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ朸"),l11lll_l1_ (u"ࠧࠨ朹"),filters,l11lll_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ机")+mode)
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ朻")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭朼")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ朽")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ朾"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"࠭ࠧ朿")
	if l11lll_l1_ (u"ࠧ࠾࠿ࠪ杀") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠩࠫ杁"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࡁࠬ杂"))
			l1l11ll1_l1_[var] = value
	for key in l1l1111l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠪ࠴ࠬ权")
		if l11lll_l1_ (u"ࠫࠪ࠭杄") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ杅") and value!=l11lll_l1_ (u"࠭࠰ࠨ杆"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ杇")+value
		elif mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ杈") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ杉"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭杊")+key+l11lll_l1_ (u"ࠫࡂࡃࠧ杋")+value
		elif mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ杌"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ杍")+key+l11lll_l1_ (u"ࠧ࠾࠿ࠪ李")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ杏"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ材"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ村"),l11lll_l1_ (u"ࠫࠬ杒"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠬࡕࡕࡕࠩ杓"))
	return l1ll1l1l_l1_
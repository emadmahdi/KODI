# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll11l_l1_ import *
script_name = l11lll_l1_ (u"ࠫࡎࡔࡉࡕࠩ炐")
LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ炑"),l11lll_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠫ炒"))
l1l1l1l11ll_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = l1l1l1l11ll_l1_
l1l1ll11ll1l_l1_ = int(mode)
l1ll11l1l11l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ炓"))
l1ll11l1l11l_l1_ = l1ll11l1l11l_l1_.replace(ltr,l11lll_l1_ (u"ࠨࠩ炔")).replace(rtl,l11lll_l1_ (u"ࠩࠪ炕"))
if l1l1ll11ll1l_l1_==260: message = l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ炖")+l11ll111111_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ炗")+l11lll111ll_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ炘")
else:
	l1ll1lll1l1l1_l1_ = l111l_l1_(addon_path).replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ炙"),l11lll_l1_ (u"ࠧࠨ炚")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ炛"),l11lll_l1_ (u"ࠩࠪ炜"))
	l1ll1lll1l1l1_l1_ = l1ll1lll1l1l1_l1_.replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ炝"),l11lll_l1_ (u"ࠫࠬ炞")).strip(l11lll_l1_ (u"ࠬࠦࠧ炟"))
	l1ll1lll1l1l1_l1_ = l1ll1lll1l1l1_l1_.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ炠"),l11lll_l1_ (u"ࠧࠡࠩ炡")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ炢"),l11lll_l1_ (u"ࠩࠣࠫ炣")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭炤"),l11lll_l1_ (u"ࠫࠥ࠭炥"))
	message = l11lll_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ炦")+l1ll11l1l11l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭炧")+mode+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ炨")+l1ll1lll1l1l1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ炩")
LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ炪"),LOGGING(script_name)+message)
l1l1l1lll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ炫"))
l1llll11lll1_l1_ = True if l1l1l1lll11l_l1_==l11ll111111_l1_ else False
if not l1llll11lll1_l1_ and l1l1ll11ll1l_l1_ in [235,715]:
	l11lll111111_l1_ = str(l1ll11111ll_l1_[l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ炬")])
	script_name = l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ炭") if l1l1ll11ll1l_l1_==235 else l11lll_l1_ (u"࠭࡭࠴ࡷࠪ炮")
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࠫ炯")+script_name+l11lll_l1_ (u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭炰")+l11lll111111_l1_)
	l11l11l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭炱")+script_name+l11lll_l1_ (u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭炲")+l11lll111111_l1_)
	if l111llll1l_l1_ or l11l11l11l_l1_:
		url += l11lll_l1_ (u"ࠫࢁ࠭炳")
		if l111llll1l_l1_: url += l11lll_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ炴")+l111llll1l_l1_
		if l11l11l11l_l1_: url += l11lll_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ炵")+l11l11l11l_l1_
		url = url.replace(l11lll_l1_ (u"ࠧࡽࠨࠪ炶"),l11lll_l1_ (u"ࠨࡾࠪ炷"))
	l1111l1ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭炸")+script_name+l11lll_l1_ (u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ点")+l11lll111111_l1_)
	if l1111l1ll1_l1_:
		l1ll1lll1l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ為"),url,re.DOTALL)
		url = url.replace(l1ll1lll1l1ll_l1_[0],l1111l1ll1_l1_)
	script_name = script_name.upper()
	l11llll11l1_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠬ࠭炻")
	l1ll11l11_l1_(l11lll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ炼"))
	try: l1lll111lll1_l1_(l1l1l1l11ll_l1_,l1ll11l1l11l_l1_)
	except Exception as error: l1lll1lllll1_l1_ = traceback.format_exc()
	l1ll11l11_l1_(l11lll_l1_ (u"ࠧࡴࡶࡲࡴࠬ炽"))
	l1l1lll1111l_l1_(l1lll1lllll1_l1_)
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
import bs4
script_name = l11lll_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ⣃")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡆࡎࡆࡣࠬ⣄")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1ll11111l1_l1_(url)
	elif mode==512: results = l1ll1l11lll_l1_(url)
	elif mode==513: results = l1ll1l11ll1_l1_(url)
	elif mode==514: results = l1ll1111l11_l1_(url,l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⣅")+text)
	elif mode==515: results = l1ll1111l11_l1_(url,l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⣆")+text)
	elif mode==516: results = l1ll11l1l1l_l1_(text)
	elif mode==517: results = l1ll11llll1_l1_(url)
	elif mode==518: results = l1ll11lllll_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1ll11ll111_l1_(url)
	elif mode==521: results = l1ll111111l_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1ll1111lll_l1_(text)
	elif mode==524: results = l1ll111l1l1_l1_()
	elif mode==525: results = l1ll1l11l1l_l1_()
	elif mode==526: results = l1ll11l1lll_l1_()
	elif mode==527: results = l1ll111l1ll_l1_()
	else: results = False
	return results
def MENU(l1l1ll11_l1_=l11lll_l1_ (u"ࠩࠪ⣇")):
	if not l1l1ll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣈"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⣉"),l11lll_l1_ (u"ࠬ࠭⣊"),519)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⣋"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⣌"),l11lll_l1_ (u"ࠨࠩ⣍"),9999)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣎"),l111ll_l1_+l11lll_l1_ (u"้ࠪํฺู่หࠣห้ษูๆษ็ࠫ⣏"),l11lll_l1_ (u"ࠫࠬ⣐"),525)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣑"),l111ll_l1_+l11lll_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅลืาฬ฻ࠧ⣒"),l11lll_l1_ (u"ࠧࠨ⣓"),526)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣔"),l111ll_l1_+l11lll_l1_ (u"่ࠩ์ุ๎ูสࠢส่๊฻ๆโษอࠫ⣕"),l11lll_l1_ (u"ࠪࠫ⣖"),527)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣗"),l111ll_l1_+l11lll_l1_ (u"๋่ࠬิ๊฼อࠥอไๆ่๋฽ฬะࠧ⣘"),l11lll_l1_ (u"࠭ࠧ⣙"),524)
	return
def l1ll111l1l1_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣚"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ࠲ࠦฮศืฬࠫ⣛"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࠩ⣜"),520)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣝"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡละำะ࠭⣞"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡲࡡࡵࡧࡶࡸࠬ⣟"),521)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣠"),l111ll_l1_+l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศ่ฯๆࠩ⣡"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࡱ࡯ࡨࡪࡹࡴࠨ⣢"),521)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣣"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠳ࠠฤๅฮี๋ࠥิศ้าอࠬ⣤"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࡻ࡯ࡥࡸࡵࠪ⣥"),521)
	return
def l1ll1l11l1l_l1_():
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࡸࡾࡶࡥࠡ࠿ࠣ࠵ࠥࠩࠠࡢࡥࡷࡳࡷࡹࠍࠋࠋࡷࡽࡵ࡫ࠠ࠾ࠢ࠵ࠤࠨࠦࡶࡪࡦࡨࡳࡸࠓࠊࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠷ࠠࠤࠢࡰࡳࡻ࡯ࡥࡴࠏࠍࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡ࠵ࠣࠧࠥࡹࡥࡳ࡫ࡨࡷࠒࠐࠉࡧࡱࡵࡩ࡮࡭࡮ࠡ࠿ࠣࡪࡦࡲࡳࡦࠢࠦࠤࡦࡸࡡࡣ࡫ࡦࠑࠏࠏࡦࡰࡴࡨ࡭࡬ࡴࠠ࠾ࠢࡷࡶࡺ࡫ࠠࠤࠢࡨࡲ࡬ࡲࡩࡴࡪࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไ๋่ࠣวๆ๊วๆࠢ฼ีอ๐ࠧ࠭࡮࡬ࡲࡰ࠸ࠬ࠶࠳࠴࠭ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊๋ࠥำๅี็หฯูࠦาสํࠫ࠱ࡲࡩ࡯࡭࠶࠰࠺࠷࠱ࠪࠏࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥ่้ࠬࠩะ๊๊็ࠢฦๅ้อๅࠡษฯ๊อ๐ࠧ࠭࡮࡬ࡲࡰ࠺ࠬ࠶࠳࠴࠭ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊๋ࠥำๅี็หฯࠦวอ่ห๎ࠬ࠲࡬ࡪࡰ࡮࠹࠱࠻࠱࠲ࠫࠐࠎࠎࡲࡩ࡯࡭࠴ࠤࡂࠦ࡬ࡪࡰ࡮࠴࠰࠭ࠦࡵࡻࡳࡩࡂ࠷ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠩࡪࡴࡸࡥࡪࡩࡱࡁࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠶ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠷ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠸ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩࠐࠎࠎࡲࡩ࡯࡭࠸ࠤࡂࠦ࡬ࡪࡰ࡮࠴࠰࠭ࠦࡵࡻࡳࡩࡂ࠷ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠶ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨࠏࠍࠍࠧࠨࠢ⣦")
	l1ll1111l1l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨ⣧")
	l1ll11l111l_l1_ = l1ll1111l1l_l1_+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪ⣨")
	l1ll1l11l11_l1_ = l1ll1111l1l_l1_+l11lll_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫ⣩")
	l1ll111ll11_l1_ = l1ll1111l1l_l1_+l11lll_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫ⣪")
	l1ll111ll1l_l1_ = l1ll1111l1l_l1_+l11lll_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬ⣫")
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣬"),l111ll_l1_+l11lll_l1_ (u"๋ࠬี็ใสฮࠥษแๅษ่ࠤ฾ืศ๋ࠩ⣭"),l1ll11l111l_l1_,511)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣮"),l111ll_l1_+l11lll_l1_ (u"ࠧๆื้ๅฬะࠠๆี็ื้อสࠡ฻ิฬ๏࠭⣯"),l1ll1l11l11_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣰"),l111ll_l1_+l11lll_l1_ (u"ู่๋ࠩ็วหࠢฦๅ้อๅࠡษฯ๊อ๐ࠧ⣱"),l1ll111ll11_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣲"),l111ll_l1_+l11lll_l1_ (u"๊ࠫ฻ๆโษอࠤู๊ไิๆสฮࠥอฬ็สํࠫ⣳"),l1ll111ll1l_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⣴"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⣵"),l11lll_l1_ (u"ࠧࠨ⣶"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣷"),l111ll_l1_+l11lll_l1_ (u"ࠩไ๋ึูࠠฤ฻่ห้ࠦรษฮา๎ࠬ⣸"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪ⣹"),517)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣺"),l111ll_l1_+l11lll_l1_ (u"ࠬ็็าีࠣࠤอ๊ฯࠡษ็ษ๋ะวอࠩ⣻"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡨࡵࡵ࡯ࡶࡵࡽࠬ⣼"),517)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣽"),l111ll_l1_+l11lll_l1_ (u"ࠨใ๊ีุࠦวๅๆ฽อࠬ⣾"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ⣿"),517)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⤀"),l111ll_l1_+l11lll_l1_ (u"ࠫๆํัิู่๋ࠢ็วหࠢส่฾๋ไࠨ⤁"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲࡫ࡪࡴࡲࡦࠩ⤂"),517)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤃"),l111ll_l1_+l11lll_l1_ (u"ࠧโ้ิืูࠥๆสࠢส่ส฻ฯศำࠪ⤄"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࡟ࡺࡧࡤࡶࠬ⤅"),517)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⤆"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠸ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠵࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⤇"),l11lll_l1_ (u"ࠫࠬ⤈"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤉"),l111ll_l1_+l11lll_l1_ (u"࠭ๅ้ษึ้ࠥ࠳ࠠโๆอี๋ࠥอะัࠪ⤊"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ⤋"),515)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤌"),l111ll_l1_+l11lll_l1_ (u"่ࠩ์ฬูๅࠡ࠯ࠣๅ้ะัࠡๅส้้࠭⤍"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ⤎"),514)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⤏"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠴ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠸ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⤐"),l11lll_l1_ (u"࠭ࠧ⤑"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤒"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭⤓"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ⤔"),515)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⤕"),l111ll_l1_+l11lll_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ⤖"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭⤗"),514)
	return
def l1ll111l1ll_l1_():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⤘"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ⤙"),l11lll_l1_ (u"ࠨࠩ⤚"),l11lll_l1_ (u"ࠩࠪ⤛"),l11lll_l1_ (u"ࠪࠫ⤜"),l11lll_l1_ (u"ࠫࠬ⤝"),l11lll_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⤞"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ⤟"),multi_valued_attributes=None)
	block = l1ll1111111_l1_.find(l11lll_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠧ⤠"),attrs={l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭⤡"):l11lll_l1_ (u"ࠩࡷࡥ࡬࠭⤢")})	# <select name=l11lll_l1_ (u"ࠪࡸࡦ࡭ࠧ⤣")>
	options = block.find_all(l11lll_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠫ⤤"))
	for option in options:
		value = option.get(l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ⤥"))		# or option[l11lll_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ⤦")] l1l1l1llll_l1_ it will l1ll1l11111_l1_ if not l1l1l11l1_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⤧"))
			value = value.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⤨"))
		link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠪࡹࡿࡰࡦ࠿ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭⤩")+value
		title = title.replace(l11lll_l1_ (u"ࠪๆฬฬๅสࠢࠪ⤪"),l11lll_l1_ (u"ࠫࠬ⤫"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤬"),l111ll_l1_+title,link,511)
	return
def l1ll11l1lll_l1_():
	l1ll1111l1l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨ⤭")
	l1ll11l1111_l1_ = l1ll1111l1l_l1_+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫ⤮")
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤯"),l111ll_l1_+l11lll_l1_ (u"ู่๋ࠩ็วหࠢฦุำอีࠨ⤰"),l1ll11l1111_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⤱"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⤲"),l11lll_l1_ (u"ࠬ࠭⤳"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤴"),l111ll_l1_+l11lll_l1_ (u"ࠧโ้ิืࠥษิฯษุࠤศฮฬะ์ࠪ⤵"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪ⤶"),517)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⤷"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ์ืำࠡ็๋฻๋࠭⤸"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡳࡧࡴࡪࡱࡱࡥࡱ࡯ࡴࡺࠩ⤹"),517)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤺"),l111ll_l1_+l11lll_l1_ (u"࠭แ่ำึࠤࠥะวา์ัࠤฬ๊ๅ๋ๆสำࠬ⤻"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯ࡣ࡫ࡵࡸ࡭ࡥࡹࡦࡣࡵࠫ⤼"),517)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤽"),l111ll_l1_+l11lll_l1_ (u"ࠩไ๋ึูࠠࠡฬสี๏ิࠠศๆ๋ๅฬฯࠧ⤾"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡨࡪࡧࡴࡩࡡࡼࡩࡦࡸࠧ⤿"),517)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⥀"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⥁"),l11lll_l1_ (u"࠭ࠧ⥂"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥃"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭⥄"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ⥅"),515)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⥆"),l111ll_l1_+l11lll_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ⥇"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭⥈"),514)
	return
def l1ll11111l1_l1_(url):
	if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ⥉") in url: index = 0
	elif l11lll_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ⥊") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⥋"),url,l11lll_l1_ (u"ࠩࠪ⥌"),l11lll_l1_ (u"ࠪࠫ⥍"),l11lll_l1_ (u"ࠫࠬ⥎"),l11lll_l1_ (u"ࠬ࠭⥏"),l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ⥐"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⥑"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111111_l1_.find_all(class_=l11lll_l1_ (u"ࠨ࡬ࡸࡱࡧࡵ࠭ࡵࡪࡨࡥࡹ࡫ࡲࠡࡥ࡯ࡩࡦࡸࡦࡪࡺࠪ⥒"))
	for block in l111l11_l1_:
		title = block.find_all(l11lll_l1_ (u"ࠩࡤࠫ⥓"))[index].text
		link = l11ll1_l1_+block.find_all(l11lll_l1_ (u"ࠪࡥࠬ⥔"))[index].get(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⥕"))
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⥖"))
			link = link.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⥗"))
		if not l111l11_l1_:
			l1ll1l11lll_l1_(link)
			return
		else:
			title = title.replace(l11lll_l1_ (u"ࠧใษษ้ฮࠦࠧ⥘"),l11lll_l1_ (u"ࠨࠩ⥙"))
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥚"),l111ll_l1_+title,link,512)
	PAGINATION(l1ll1111111_l1_,511)
	return
def PAGINATION(l1ll1111111_l1_,mode):
	block = l1ll1111111_l1_.find(class_=l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ⥛"))
	if block:
		l1l1ll11l_l1_ = block.find_all(l11lll_l1_ (u"ࠫࡦ࠭⥜"))
		l1l1lllllll_l1_ = block.find_all(l11lll_l1_ (u"ࠬࡲࡩࠨ⥝"))
		l1ll11l1ll1_l1_ = list(zip(l1l1ll11l_l1_,l1l1lllllll_l1_))
		l11ll111l1_l1_ = -1
		length = len(l1ll11l1ll1_l1_)
		for l1ll11l1l_l1_,l1ll1111ll1_l1_ in l1ll11l1ll1_l1_:
			l11ll111l1_l1_ += 1
			l1ll1111ll1_l1_ = l1ll1111ll1_l1_[l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ⥞")]
			if l11lll_l1_ (u"ࠧࡶࡰࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠬ⥟") in l1ll1111ll1_l1_ or l11lll_l1_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࠩ⥠") in l1ll1111ll1_l1_: continue
			l1ll111l11l_l1_ = l1ll11l1l_l1_.text
			l1lllll1ll_l1_ = l11ll1_l1_+l1ll11l1l_l1_.get(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ⥡"))
			if kodi_version<19:
				l1ll111l11l_l1_ = l1ll111l11l_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⥢"))
				l1lllll1ll_l1_ = l1lllll1ll_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⥣"))
			if   l11ll111l1_l1_==0: l1ll111l11l_l1_ = l11lll_l1_ (u"ࠬษ่ๅ๋ࠪ⥤")
			elif l11ll111l1_l1_==1: l1ll111l11l_l1_ = l11lll_l1_ (u"࠭ำศสๅอࠬ⥥")
			elif l11ll111l1_l1_==length-2: l1ll111l11l_l1_ = l11lll_l1_ (u"ࠧๅษะๆฮ࠭⥦")
			elif l11ll111l1_l1_==length-1: l1ll111l11l_l1_ = l11lll_l1_ (u"ࠨลั๎ึฯࠧ⥧")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥨"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ⥩")+l1ll111l11l_l1_,l1lllll1ll_l1_,mode)
	return
def l1ll1l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⥪"),url,l11lll_l1_ (u"ࠬ࠭⥫"),l11lll_l1_ (u"࠭ࠧ⥬"),l11lll_l1_ (u"ࠧࠨ⥭"),l11lll_l1_ (u"ࠨࠩ⥮"),l11lll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠵࠲࠷ࡳࡵࠩ⥯"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⥰"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111111_l1_.find_all(class_=l11lll_l1_ (u"ࠫࡷࡵࡷࠨ⥱"))
	items,first = [],True
	for block in l111l11_l1_:
		if not block.find(class_=l11lll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠮ࡹࡵࡥࡵࡶࡥࡳࠩ⥲")): continue
		if first: first = False ; continue
		l1ll11lll1l_l1_ = []
		l1l1llllll1_l1_ = block.find_all(class_=[l11lll_l1_ (u"࠭ࡣࡦࡰࡶࡳࡷࡹࡨࡪࡲࠣࡶࡪࡪࠧ⥳"),l11lll_l1_ (u"ࠧࡤࡧࡱࡷࡴࡸࡳࡩ࡫ࡳࠤࡵࡻࡲࡱ࡮ࡨࠫ⥴")])
		for l1ll111l111_l1_ in l1l1llllll1_l1_:
			l1ll1ll1l1_l1_ = l1ll111l111_l1_.find_all(l11lll_l1_ (u"ࠨ࡮࡬ࠫ⥵"))[1].text
			if kodi_version<19:
				l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⥶"))
			l1ll11lll1l_l1_.append(l1ll1ll1l1_l1_)
		if not l11ll11_l1_(script_name,l11lll_l1_ (u"ࠪࠫ⥷"),l1ll11lll1l_l1_,False):
			l11l_l1_ = block.find(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠨ⥸")).get(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ⥹"))
			title = block.find(l11lll_l1_ (u"࠭ࡨ࠴ࠩ⥺"))
			name = title.find(l11lll_l1_ (u"ࠧࡢࠩ⥻")).text
			link = l11ll1_l1_+title.find(l11lll_l1_ (u"ࠨࡣࠪ⥼")).get(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ⥽"))
			l1ll111lll1_l1_ = block.find(class_=l11lll_l1_ (u"ࠪࡲࡴ࠳࡭ࡢࡴࡪ࡭ࡳ࠭⥾"))
			l1ll111llll_l1_ = block.find(class_=l11lll_l1_ (u"ࠫࡱ࡫ࡧࡦࡰࡧࠫ⥿"))
			if l1ll111lll1_l1_: l1ll111lll1_l1_ = l1ll111lll1_l1_.text
			if l1ll111llll_l1_: l1ll111llll_l1_ = l1ll111llll_l1_.text
			if kodi_version<19:
				l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⦀"))
				name = name.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⦁"))
				link = link.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⦂"))
				if l1ll111lll1_l1_: l1ll111lll1_l1_ = l1ll111lll1_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⦃"))
			l1ll11111ll_l1_ = {}
			if l1ll111llll_l1_: l1ll11111ll_l1_[l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨ⦄")] = l1ll111llll_l1_
			if l1ll111lll1_l1_:
				l1ll111lll1_l1_ = l1ll111lll1_l1_.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭⦅"),l11lll_l1_ (u"ࠫࠥ࠴࠮ࠡࠩ⦆"))
				l1ll11111ll_l1_[l11lll_l1_ (u"ࠬࡶ࡬ࡰࡶࠪ⦇")] = l1ll111lll1_l1_.replace(l11lll_l1_ (u"࠭࠮࠯࠰สๆึษࠠศๆ่ึ๏ีࠧ⦈"),l11lll_l1_ (u"ࠧࠨ⦉"))
			if l11lll_l1_ (u"ࠨ࠱ࡺࡳࡷࡱ࠯ࠨ⦊") in link:
				#name = l11lll_l1_ (u"ࠩหัะูࠦ็ࠢࠪ⦋")+name
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦌"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"ࠫࠬ⦍"),name,l11lll_l1_ (u"ࠬ࠭⦎"),l1ll11111ll_l1_)
			elif l11lll_l1_ (u"࠭࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⦏") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦐"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"ࠨࠩ⦑"),name,l11lll_l1_ (u"ࠩࠪ⦒"),l1ll11111ll_l1_)
	PAGINATION(l1ll1111111_l1_,512)
	return
def l1ll1l11ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⦓"),url,l11lll_l1_ (u"ࠫࠬ⦔"),l11lll_l1_ (u"ࠬ࠭⦕"),l11lll_l1_ (u"࠭ࠧ⦖"),l11lll_l1_ (u"ࠧࠨ⦗"),l11lll_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠵࠱࠶ࡹࡴࠨ⦘"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ⦙"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111111_l1_.find_all(l11lll_l1_ (u"ࠪࡰ࡮࠭⦚"))
	names,items = [],[]
	for block in l111l11_l1_:
		if not block.find(class_=l11lll_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠭ࡸࡴࡤࡴࡵ࡫ࡲࠨ⦛")): continue
		if not block.find(class_=[l11lll_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠧ⦜"),l11lll_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠡࡶࡨࡼࡹ࠳ࡣࡦࡰࡷࡩࡷ࠭⦝")]): continue
		if block.find(class_=l11lll_l1_ (u"ࠧࡩ࡫ࡧࡩࠬ⦞")): continue
		title = block.find(class_=[l11lll_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠪ⦟"),l11lll_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠤࡹ࡫ࡸࡵ࠯ࡦࡩࡳࡺࡥࡳࠩ⦠")])
		name = title.find(l11lll_l1_ (u"ࠪࡥࠬ⦡")).text
		if name in names: continue
		names.append(name)
		link = l11ll1_l1_+title.find(l11lll_l1_ (u"ࠫࡦ࠭⦢")).get(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ⦣"))
		if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡸࡱࡵ࡯࠴࠭⦤") in url: l11l_l1_ = block.find(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠫ⦥")).get(l11lll_l1_ (u"ࠨࡵࡵࡧࠬ⦦"))
		elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⦧") in url: l11l_l1_ = block.find(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠧ⦨")).get(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭⦩"))
		elif l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⦪") in url: l11l_l1_ = block.find(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠪ⦫")).get(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ⦬"))
		else: l11l_l1_ = block.find(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⦭")).get(l11lll_l1_ (u"ࠩࡶࡶࡨ࠭⦮"))
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⦯"))
			link = link.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⦰"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⦱"))
		name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ⦲"))
		items.append((name,link,l11l_l1_))
	if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⦳") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,link,l11l_l1_ in items:
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ⦴") in url: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⦵"),l111ll_l1_+name,link,522,l11l_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⦶") in url: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦷"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"ࠬ࠭⦸"),name)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⦹"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"ࠧࠨ⦺"),name)
	return
def l1ll11l1l1l_l1_(text):
	text = text.replace(l11lll_l1_ (u"ࠨษ็ษ฾๊ว็ࠩ⦻"),l11lll_l1_ (u"ࠩࠪ⦼")).replace(l11lll_l1_ (u"่ࠪๆ๐ไๆࠩ⦽"),l11lll_l1_ (u"ࠫࠬ⦾")).replace(l11lll_l1_ (u"ࠬอไาี่๎ࠬ⦿"),l11lll_l1_ (u"࠭ࠧ⧀"))
	text = text.replace(l11lll_l1_ (u"ࠧฦ฻็ห๋࠭⧁"),l11lll_l1_ (u"ࠨࠩ⧂")).replace(l11lll_l1_ (u"ࠩไ๎้๋ࠧ⧃"),l11lll_l1_ (u"ࠪࠫ⧄")).replace(l11lll_l1_ (u"ࠫฬ๊ศา๊่์ࠬ⧅"),l11lll_l1_ (u"ࠬ࠭⧆"))
	text = text.replace(l11lll_l1_ (u"࠭วๅฬื์๏่๊ࠨ⧇"),l11lll_l1_ (u"ࠧࠨ⧈")).replace(l11lll_l1_ (u"ࠨๆ่ืู้ไࠨ⧉"),l11lll_l1_ (u"ࠩࠪ⧊")).replace(l11lll_l1_ (u"ุ้๊ࠪำๅࠩ⧋"),l11lll_l1_ (u"ࠫࠬ⧌"))
	text = text.replace(l11lll_l1_ (u"ࠬࡀࠧ⧍"),l11lll_l1_ (u"࠭ࠧ⧎")).replace(l11lll_l1_ (u"ࠧࠪࠩ⧏"),l11lll_l1_ (u"ࠨࠩ⧐")).replace(l11lll_l1_ (u"ࠩࠫࠫ⧑"),l11lll_l1_ (u"ࠪࠫ⧒")).replace(l11lll_l1_ (u"ࠫ࠱࠭⧓"),l11lll_l1_ (u"ࠬ࠭⧔"))
	text = text.replace(l11lll_l1_ (u"࠭࡟ࠨ⧕"),l11lll_l1_ (u"ࠧࠨ⧖")).replace(l11lll_l1_ (u"ࠨ࠽ࠪ⧗"),l11lll_l1_ (u"ࠩࠪ⧘")).replace(l11lll_l1_ (u"ࠪ࠱ࠬ⧙"),l11lll_l1_ (u"ࠫࠬ⧚")).replace(l11lll_l1_ (u"ࠬ࠴ࠧ⧛"),l11lll_l1_ (u"࠭ࠧ⧜"))
	text = text.replace(l11lll_l1_ (u"ࠧ࡝ࠩࠪ⧝"),l11lll_l1_ (u"ࠨࠩ⧞")).replace(l11lll_l1_ (u"ࠩ࡟ࠦࠬ⧟"),l11lll_l1_ (u"ࠪࠫ⧠"))
	text = text.replace(l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠩ⧡"),l11lll_l1_ (u"ࠬࠦࠧ⧢")).replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠪ⧣"),l11lll_l1_ (u"ࠧࠡࠩ⧤")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ⧥"),l11lll_l1_ (u"ࠩࠣࠫ⧦"))
	text = text.strip(l11lll_l1_ (u"ࠪࠤࠬ⧧"))
	l1ll1l111ll_l1_ = text.count(l11lll_l1_ (u"ࠫࠥ࠭⧨"))+1
	if l1ll1l111ll_l1_==1:
		l1ll1111lll_l1_(text)
		return
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⧩"),l111ll_l1_+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࠦใๅ็สฮ๊ࠥไษฯฮࠤࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⧪"),l11lll_l1_ (u"ࠧࠨ⧫"),9999)
	l1ll11l11ll_l1_ = text.split(l11lll_l1_ (u"ࠨࠢࠪ⧬"))
	l1ll1l111l1_l1_ = pow(2,l1ll1l111ll_l1_)
	l1ll11ll1l1_l1_ = []
	def l1ll11l11l1_l1_(a,b):
		if a==l11lll_l1_ (u"ࠩ࠴ࠫ⧭"): return b
		return l11lll_l1_ (u"ࠪࠫ⧮")
	for l11ll111l1_l1_ in range(l1ll1l111l1_l1_,0,-1):
		l1ll11ll11l_l1_ = list(l1ll1l111ll_l1_*l11lll_l1_ (u"ࠫ࠵࠭⧯")+bin(l11ll111l1_l1_)[2:])[-l1ll1l111ll_l1_:]
		l1ll11ll11l_l1_ = reversed(l1ll11ll11l_l1_)
		result = map(l1ll11l11l1_l1_,l1ll11ll11l_l1_,l1ll11l11ll_l1_)
		title = l11lll_l1_ (u"ࠬࠦࠧ⧰").join(filter(None,result))
		if kodi_version<19: l1lll1lll_l1_ = title.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⧱"))
		else: l1lll1lll_l1_ = title
		if len(l1lll1lll_l1_)>2 and title not in l1ll11ll1l1_l1_:
			l1ll11ll1l1_l1_.append(title)
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧲"),l111ll_l1_+title,l11lll_l1_ (u"ࠨࠩ⧳"),523,l11lll_l1_ (u"ࠩࠪ⧴"),l11lll_l1_ (u"ࠪࠫ⧵"),title)
	return
def l1ll1111lll_l1_(l1ll1l1111l_l1_):
	if kodi_version<19:
		l1ll1l1111l_l1_ = l1ll1l1111l_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⧶"))
		import arabic_reshaper
		l1ll1l1111l_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1ll1l1111l_l1_)
		l1ll1l1111l_l1_ = bidi.algorithm.get_display(l1ll1l1111l_l1_)
	import l1ll11lll11_l1_
	l1ll1l1111l_l1_ = OPEN_KEYBOARD(default=l1ll1l1111l_l1_)
	l1ll11lll11_l1_.SEARCH(l1ll1l1111l_l1_)
	return
def l1ll11llll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⧷"),url,l11lll_l1_ (u"࠭ࠧ⧸"),l11lll_l1_ (u"ࠧࠨ⧹"),l11lll_l1_ (u"ࠨࠩ⧺"),l11lll_l1_ (u"ࠩࠪ⧻"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡏࡎࡅࡇ࡛ࡉࡘࡥࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ⧼"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⧽"),multi_valued_attributes=None)
	block = l1ll1111111_l1_.find(class_=l11lll_l1_ (u"ࠬࡲࡩࡴࡶ࠰ࡷࡪࡶࡡࡳࡣࡷࡳࡷࠦ࡬ࡪࡵࡷ࠱ࡹ࡯ࡴ࡭ࡧࠪ⧾"))
	l1l111_l1_ = block.find_all(l11lll_l1_ (u"࠭ࡡࠨ⧿"))
	items = []
	for title in l1l111_l1_:
		name = title.text
		link = l11ll1_l1_+title.get(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࠬ⨀"))
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⨁"))
			link = link.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⨂"))
		if l11lll_l1_ (u"ࠪࠧࠬ⨃") not in link: items.append((name,link))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,link = item
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨄"),l111ll_l1_+name,link,518)
	return
def l1ll11lllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⨅"),url,l11lll_l1_ (u"࠭ࠧ⨆"),l11lll_l1_ (u"ࠧࠨ⨇"),l11lll_l1_ (u"ࠨࠩ⨈"),l11lll_l1_ (u"ࠩࠪ⨉"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡏࡎࡅࡇ࡛ࡉࡘࡥࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⨊"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⨋"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111111_l1_.find(class_=l11lll_l1_ (u"ࠬ࡫ࡸࡱࡣࡱࡨࠬ⨌")).find_all(l11lll_l1_ (u"࠭ࡴࡳࠩ⨍"))
	for block in l111l11_l1_:
		l1ll11l1l11_l1_ = block.find_all(l11lll_l1_ (u"ࠧࡢࠩ⨎"))
		if not l1ll11l1l11_l1_: continue
		l11l_l1_ = block.find(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⨏")).get(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ⨐"))
		name = l1ll11l1l11_l1_[1].text
		link = l11ll1_l1_+l1ll11l1l11_l1_[1].get(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ⨑"))
		l1ll111llll_l1_ = block.find(class_=l11lll_l1_ (u"ࠫࡱ࡫ࡧࡦࡰࡧࠫ⨒"))
		if l1ll111llll_l1_: l1ll111llll_l1_ = l1ll111llll_l1_.text
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⨓"))
			link = link.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⨔"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⨕"))
		l1ll11111ll_l1_ = {}
		if l1ll111llll_l1_: l1ll11111ll_l1_[l11lll_l1_ (u"ࠨࡵࡷࡥࡷࡹࠧ⨖")] = l1ll111llll_l1_
		if l11lll_l1_ (u"ࠩ࠲ࡻࡴࡸ࡫࠰ࠩ⨗") in link:
			#name = l11lll_l1_ (u"ࠪฬาัฺ่ࠠࠣࠫ⨘")+name
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨙"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"ࠬ࠭⨚"),name,l11lll_l1_ (u"࠭ࠧ⨛"),l1ll11111ll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⨜") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨝"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"ࠩࠪ⨞"),name,l11lll_l1_ (u"ࠪࠫ⨟"),l1ll11111ll_l1_)
	PAGINATION(l1ll1111111_l1_,518)
	return
def l1ll11ll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⨠"),url,l11lll_l1_ (u"ࠬ࠭⨡"),l11lll_l1_ (u"࠭ࠧ⨢"),l11lll_l1_ (u"ࠧࠨ⨣"),l11lll_l1_ (u"ࠨࠩ⨤"),l11lll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡛ࡏࡄࡆࡑࡖࡣࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ⨥"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⨦"),multi_valued_attributes=None)
	l1l111_l1_ = l1ll1111111_l1_.find_all(class_=l11lll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡺࡩࡵ࡮ࡨࠤ࡮ࡴ࡬ࡪࡰࡨࠫ⨧"))
	links = l1ll1111111_l1_.find_all(class_=l11lll_l1_ (u"ࠬࡨࡵࡵࡶࡲࡲࠥ࡭ࡲࡦࡧࡱࠤࡸࡳࡡ࡭࡮ࠣࡶ࡮࡭ࡨࡵࠩ⨨"))
	items = zip(l1l111_l1_,links)
	for title,link in items:
		title = title.text
		link = l11ll1_l1_+link.get(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠫ⨩"))
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⨪"))
			link = link.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⨫"))
		title = title.replace(l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠧ⨬"),l11lll_l1_ (u"ࠪࠤࠬ⨭")).replace(l11lll_l1_ (u"ࠫࠥࠦࠠࠨ⨮"),l11lll_l1_ (u"ࠬࠦࠧ⨯")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ⨰"),l11lll_l1_ (u"ࠧࠡࠩ⨱"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨲"),l111ll_l1_+title,link,521)
	return
def l1ll111111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⨳"),url,l11lll_l1_ (u"ࠪࠫ⨴"),l11lll_l1_ (u"ࠫࠬ⨵"),l11lll_l1_ (u"ࠬ࠭⨶"),l11lll_l1_ (u"࠭ࠧ⨷"),l11lll_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯࡙ࡍࡉࡋࡏࡔࡡࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⨸"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⨹"),multi_valued_attributes=None)
	l1ll1l1l111_l1_ = l1ll1111111_l1_.find(class_=l11lll_l1_ (u"ࠩ࡯ࡥࡷ࡭ࡥ࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠺ࠠ࡮ࡧࡧ࡭ࡺࡳ࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠹ࠦࡳ࡮ࡣ࡯ࡰ࠲ࡨ࡬ࡰࡥ࡮࠱࡬ࡸࡩࡥ࠯࠵ࠫ⨺"))
	l111l11_l1_ = l1ll1l1l111_l1_.find_all(l11lll_l1_ (u"ࠪࡰ࡮࠭⨻"))
	for block in l111l11_l1_:
		title = block.find(class_=l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ⨼")).text
		link = l11ll1_l1_+block.find(l11lll_l1_ (u"ࠬࡧࠧ⨽")).get(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠫ⨾"))
		l11l_l1_ = block.find(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠫ⨿")).get(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ⩀"))
		l1l1l1111_l1_ = block.find(class_=l11lll_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ⩁")).text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⩂"))
			link = link.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⩃"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⩄"))
			l1l1l1111_l1_ = l1l1l1111_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⩅"))
		l1l1l1111_l1_ = l1l1l1111_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ⩆"),l11lll_l1_ (u"ࠨࠩ⩇")).strip(l11lll_l1_ (u"ࠩࠣࠫ⩈"))
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⩉"),l111ll_l1_+title,link,522,l11l_l1_,l1l1l1111_l1_)
	PAGINATION(l1ll1111111_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⩊"),url,l11lll_l1_ (u"ࠬ࠭⩋"),l11lll_l1_ (u"࠭ࠧ⩌"),l11lll_l1_ (u"ࠧࠨ⩍"),l11lll_l1_ (u"ࠨࠩ⩎"),l11lll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⩏"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⩐"),multi_valued_attributes=None)
	link = l1ll1111111_l1_.find(class_=l11lll_l1_ (u"ࠫ࡫ࡲࡥࡹ࠯ࡹ࡭ࡩ࡫࡯ࠨ⩑")).find(l11lll_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠬ⩒")).get(l11lll_l1_ (u"࠭ࡳࡳࡥࠪ⩓"))
	if kodi_version<19: link = link.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⩔"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⩕"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ⩖"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ⩗"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭⩘"),l11lll_l1_ (u"ࠬࠫ࠲࠱ࠩ⩙"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡀࡳࡀࠫ⩚")+search
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⩛"),url,l11lll_l1_ (u"ࠨࠩ⩜"),l11lll_l1_ (u"ࠩࠪ⩝"),l11lll_l1_ (u"ࠪࠫ⩞"),l11lll_l1_ (u"ࠫࠬ⩟"),l11lll_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ⩠"))
	html = response.content
	l1ll1111111_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ⩡"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111111_l1_.find_all(class_=l11lll_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡶ࡬ࡸࡱ࡫ࠠ࡭ࡧࡩࡸࠬ⩢"))
	for block in l111l11_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⩣"))
		title = title.split(l11lll_l1_ (u"ࠩࠫࠫ⩤"),1)[0].strip(l11lll_l1_ (u"ࠪࠤࠬ⩥"))
		if   l11lll_l1_ (u"ࠫศ฿ๅศๆࠪ⩦") in title: link = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⩧"),l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡸࡱࡵ࡯࠴࠭⩨"))
		elif l11lll_l1_ (u"ࠧฤึัหฺ࠭⩩") in title: link = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⩪"),l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⩫"))
		#elif l11lll_l1_ (u"ࠪวาีวฬࠩ⩬") in title: link = url.replace(l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⩭"),l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡥࡷࡧࡱࡸ࠴࠭⩮"))
		#elif l11lll_l1_ (u"࠭ๅ่ำฯห๋อสࠨ⩯") in title: link = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⩰"),l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡩࡩࡸࡺࡩࡷࡣ࡯࠳ࠬ⩱"))
		elif l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠫ⩲") in title: link = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⩳"),l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡼࡩࡥࡧࡲ࠳ࠬ⩴"))
		#elif l11lll_l1_ (u"ࠬษฮษษิࠫ⩵") in title: link = url.replace(l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⩶"),l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡶࡲࡴ࡮ࡩ࠯ࠨ⩷"))
		else: continue
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩸"),l111ll_l1_+title,link,513)
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
def l1ll1111l11_l1_(url,text):
	global l1l11lll_l1_,l1ll11ll_l1_
	if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭⩹") in url:
		l1l11lll_l1_ = [l11lll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ⩺"),l11lll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ⩻"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⩼")]
		l1ll11ll_l1_ = [l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⩽"),l11lll_l1_ (u"ࠧࡺࡧࡤࡶࠬ⩾"),l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⩿")]
	elif l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ⪀") in url:
		l1l11lll_l1_ = [l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⪁"),l11lll_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ⪂"),l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ⪃")]
		l1ll11ll_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⪄"),l11lll_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ⪅"),l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭⪆")]
	l1lll1l1_l1_(url,text)
	return
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⪇"))[0]
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ⪈"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⪉"),url,l11lll_l1_ (u"ࠬ࠭⪊"),l11lll_l1_ (u"࠭ࠧ⪋"),l11lll_l1_ (u"ࠧࠨ⪌"),l11lll_l1_ (u"ࠨࠩ⪍"),l11lll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭⪎"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࠡࡣࡦࡸ࡮ࡵ࡮࠾ࠤ࠲ࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ⪏"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + category + options block
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⪐"),block,re.DOTALL)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⪑"),block,re.DOTALL)
	return items
def l1llll1ll1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"࠭ࡣࡢࡶࡀࠫ⪒"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ⪓"))
	l1llllll11_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⪔"))[0]
	l1llll1lll_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭⪕"))
	#url = url.replace(l1llllll11_l1_,l1llll1lll_l1_)
	url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⪖"),l11lll_l1_ (u"ࠫ࠴ࡅࡵࡵࡨ࠻ࡁࠪࡋ࠲ࠦ࠻ࡆࠩ࠾࠹ࠦࠨ⪗"))
	return url
def l11111llll_l1_(l1l1llll_l1_,url):
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⪘")) # l1lllllll1l_l1_ be l11111111l_l1_
	l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⪙")+l1l1111l_l1_
	l11l1l1_l1_ = l1llll1ll1_l1_(l11l1l1_l1_)
	return l11l1l1_l1_
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⪚"),l11lll_l1_ (u"ࠨࠩ⪛"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⪜"),l11lll_l1_ (u"ࠪࠫ⪝"),filter,url)
	if l11lll_l1_ (u"ࠫࡄ࠭⪞") in url: url = url.split(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⪟"))[0]
	type,filter = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⪠"),1)
	if filter==l11lll_l1_ (u"ࠧࠨ⪡"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠨࠩ⪢"),l11lll_l1_ (u"ࠩࠪ⪣")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ⪤"))
	if type==l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⪥"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠬࡃࠧ⪦") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"࠭࠽ࠨ⪧") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ⪨")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫ⪩")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ⪪")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭⪫")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭⪬"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⪭")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨ⪮"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⪯")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⪰")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ⪱"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⪲")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠫࠬ⪳"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⪴")) # l1lllllll11_l1_ l1111l1l1l_l1_ not l11l111ll1_l1_
		if l1l11l11_l1_==l11lll_l1_ (u"࠭ࠧ⪵"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⪶")+l1l11l11_l1_
		l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⪷"),l111ll_l1_+l11lll_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ⪸"),l11l11l_l1_,511)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪹"),l111ll_l1_+l11lll_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ⪺")+l11lll11_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ⪻"),l11l11l_l1_,511)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⪼"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⪽"),l11lll_l1_ (u"ࠨࠩ⪾"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠩ࠰࠱ࠬ⪿"),l11lll_l1_ (u"ࠪࠫ⫀"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠫࡂ࠭⫁") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⫂"):
			if l1ll1lll_l1_ not in l1l11lll_l1_: continue
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l1llll1ll1_l1_(url)
					l1ll1l11lll_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ⫃")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫄"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠨ⫅"),l11l11l_l1_,511)
				else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⫆"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠪ⫇"),l11l11l_l1_,515,l11lll_l1_ (u"ࠫࠬ⫈"),l11lll_l1_ (u"ࠬ࠭⫉"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⫊"):
			if l1ll1lll_l1_ not in l1ll11ll_l1_: continue
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ⫋")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿࠳ࠫ⫌")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ⫍")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁ࠵࠭⫎")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⫏")+l1l1llll_l1_
			if   name==l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ⫐"): name = l11lll_l1_ (u"࠭วๅ่๋฽ࠬ⫑")
			elif name==l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⫒"): name = l11lll_l1_ (u"ࠨษ็฽๊๊ࠧ⫓")
			elif name==l11lll_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ⫔"): name = l11lll_l1_ (u"ࠪหฺ้๊สࠩ⫕")
			elif name==l11lll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ⫖"): name = l11lll_l1_ (u"ࠬอไิ่ฬࠫ⫗")
			elif name==l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⫘"): name = l11lll_l1_ (u"ࠧศๆ่์ุ๋ࠧ⫙")
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⫚"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊࠼ࠣࠫ⫛")+name,l11l11l_l1_,514,l11lll_l1_ (u"ࠪࠫ⫝̸"),l11lll_l1_ (u"ࠫࠬ⫝"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⫞"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"࠭ๅึ่ไหฯࠦรฯำ์ࠫ⫟") in option: continue
			if l11lll_l1_ (u"ࠧศๆๆ่ࠬ⫠") in option: continue
			if l11lll_l1_ (u"ࠨษ็่฿ฯࠧ⫡") in option: continue
			option = option.replace(l11lll_l1_ (u"ࠩๅหห๋ษࠡࠩ⫢"),l11lll_l1_ (u"ࠪࠫ⫣"))
			if   name==l11lll_l1_ (u"ࠫࡹࡿࡰࡦࠩ⫤"): name = l11lll_l1_ (u"ࠬอไ็๊฼ࠫ⫥")
			elif name==l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⫦"): name = l11lll_l1_ (u"ࠧศๆ฼้้࠭⫧")
			elif name==l11lll_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⫨"): name = l11lll_l1_ (u"ࠩส่้เษࠨ⫩")
			elif name==l11lll_l1_ (u"ࠪࡽࡪࡧࡲࠨ⫪"): name = l11lll_l1_ (u"ࠫฬ๊ำ็หࠪ⫫")
			elif name==l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ⫬"): name = l11lll_l1_ (u"࠭วๅ็๋ื๊࠭⫭")
			#if l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭⫮") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩࠣࠩ⫯"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⫰")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ⫱")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭⫲")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃࠧ⫳")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⫴")+l1l1llll_l1_
			if name: title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ⫵")+name
			else: title = option   #+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠨ࠲ࠪ⫶")]
			if type==l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ⫷"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⫸"),l111ll_l1_+title,url,514,l11lll_l1_ (u"ࠫࠬ⫹"),l11lll_l1_ (u"ࠬ࠭⫺"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⫻"))
			elif type==l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⫼") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࠪ⫽") in l1l11l1l_l1_:
				l11l1l1_l1_ = l11111llll_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⫾"),l111ll_l1_+title,l11l1l1_l1_,511)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⫿"),l111ll_l1_+title,url,515,l11lll_l1_ (u"ࠫࠬ⬀"),l11lll_l1_ (u"ࠬ࠭⬁"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ⬂"),l11lll_l1_ (u"ࠧࠨ⬃"),filters,l11lll_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠱࠲ࠩ⬄"))
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⬅")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⬆")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⬇")			all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠬࡃࠦࠨ⬈"),l11lll_l1_ (u"࠭࠽࠱ࠨࠪ⬉"))
	filters = filters.strip(l11lll_l1_ (u"ࠧࠧࠩ⬊"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠨ࠿ࠪ⬋") in filters:
		items = filters.split(l11lll_l1_ (u"ࠩࠩࠫ⬌"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠪࡁࠬ⬍"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠫࠬ⬎")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠬ࠶ࠧ⬏")
		if l11lll_l1_ (u"࠭ࠥࠨ⬐") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⬑") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ⬒"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭⬓")+value
		elif mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⬔") and value!=l11lll_l1_ (u"ࠫ࠵࠭⬕"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ⬖")+key+l11lll_l1_ (u"࠭࠽ࠨ⬗")+value
		elif mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⬘"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⬙")+key+l11lll_l1_ (u"ࠩࡀࠫ⬚")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ⬛"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭⬜"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠬࡃ࠰ࠨ⬝"),l11lll_l1_ (u"࠭࠽ࠨ⬞"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⬟"),l11lll_l1_ (u"ࠨࠩ⬠"),filters,l11lll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠳࠴ࠪ⬡"))
	return l1ll1l1l_l1_
l1l11lll_l1_ = []
l1ll11ll_l1_ = []
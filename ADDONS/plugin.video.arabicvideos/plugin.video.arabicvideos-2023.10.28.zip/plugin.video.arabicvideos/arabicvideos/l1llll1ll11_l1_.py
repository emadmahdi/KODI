# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ≑")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡈࡆ࠶ࡥࠧ≒")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#l1l1ll11_l1_: https://n-l1lllll1111_l1_.l1llll1l1ll_l1_
#l1llll1lll1_l1_: https://www.l1llll1lll1_l1_.com/profile.l1ll1lllll_l1_?id=100091282963836
l1l1l1_l1_ = [l11lll_l1_ (u"่ࠩ็ฯฮส๋ࠩ≓"),l11lll_l1_ (u"ࠪห๏า๊ࠡสึฮࠬ≔")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==770: results = MENU()
	elif mode==771: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==772: results = l1l11l_l1_(url)
	elif mode==773: results = PLAY(url)
	elif mode==774: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ≕")+text)
	elif mode==775: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ≖")+text)
	elif mode==776: results = l1lllll111l_l1_(url,l1l11l1_l1_)
	elif mode==779: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭≗"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ≘"),l11lll_l1_ (u"ࠨࠩ≙"),779,l11lll_l1_ (u"ࠩࠪ≚"),l11lll_l1_ (u"ࠪࠫ≛"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ≜"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ≝"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≞"),l11lll_l1_ (u"ࠧࠨ≟"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ≠"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ≡"),l11lll_l1_ (u"ࠪࠫ≢"),l11lll_l1_ (u"ࠫࠬ≣"),l11lll_l1_ (u"ࠬ࠭≤"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ≥"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡯ࡣࡹ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ≦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ≧"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ≨"))
			if any(value in title for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≩"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭≪")+l111ll_l1_+title,link,771)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ≫"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≬"),l11lll_l1_ (u"ࠧࠨ≭"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࡸࡵࡣࡪࡣ࡯࠱ࡧࡵࡸࠨ≮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ≯"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ≰"))
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≱"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ≲")+l111ll_l1_+title,link,771,l11lll_l1_ (u"࠭ࠧ≳"),l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠩ≴"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭≵"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ≶"),l11lll_l1_ (u"ࠪࠫ≷"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ≸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ≹"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ≺"))
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ≻"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ≼")+l111ll_l1_+title,link,771)
	return html
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪ≽")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ≾"),l11lll_l1_ (u"ࠫࠬ≿"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⊀"),url,l11lll_l1_ (u"࠭ࠧ⊁"),l11lll_l1_ (u"ࠧࠨ⊂"),l11lll_l1_ (u"ࠨࠩ⊃"),l11lll_l1_ (u"ࠩࠪ⊄"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࡙ࡅࡂࡕࡒࡒࡘࡥࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⊅"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡤࡶࡹ࡯ࡣ࡭ࡧࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭⊆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠬ࠭⊇"),l11lll_l1_ (u"࠭ࠧ⊈"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠧฮๆๅหฯ࠭⊉") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"ࠨ็๋หุ๋ࠧ⊊") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⊋"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⊌"),l111ll_l1_+title,link,776,l1llll_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ⊍"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⊎"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⊏"),l111ll_l1_+title,link,773,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⊐"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⊑"),l111ll_l1_+title,link,773)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪ⊒")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⊓"),l11lll_l1_ (u"ࠫࠬ⊔"),l11lll_l1_ (u"࡚ࠬࡉࡕࡎࡈࡗࠬ⊕"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⊖"),url,l11lll_l1_ (u"ࠧࠨ⊗"),l11lll_l1_ (u"ࠨࠩ⊘"),l11lll_l1_ (u"ࠩࠪ⊙"),l11lll_l1_ (u"ࠪࠫ⊚"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⊛"))
	html = response.content
	items,l1llllll111_l1_,filters = [],False,False
	if not type:
		# l1llllll111_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⊜"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⊝"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ⊞"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊟"),l111ll_l1_+title,link,771,l11lll_l1_ (u"ࠩࠪ⊠"),l11lll_l1_ (u"ࠪࡷࡺࡨ࡭ࡦࡰࡸࠫ⊡"))
				l1llllll111_l1_ = True
	if not type:
		# filter
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡪࡴࡸ࡭ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭⊢"),html,re.DOTALL)
		if l1l1ll1_l1_:
			if l1llllll111_l1_: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⊣"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⊤"),l11lll_l1_ (u"ࠧࠨ⊥"),9999)
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊦"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ⊧"),url,775,l11lll_l1_ (u"ࠪࠫ⊨"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⊩"))
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⊪"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ⊫"),url,774,l11lll_l1_ (u"ࠧࠨ⊬"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⊭"))
			filters = True
	if not l1llllll111_l1_ and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ⊮"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⊯"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠫࡡࡴࠧ⊰"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩ࠴࠭⊱") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊲"),l111ll_l1_+title,link,776,l1llll_l1_,l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⊳"))
				else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⊴"),l111ll_l1_+title,link,773,l1llll_l1_)
		# l1lllll11ll_l1_
			l1l11l1_l1_ = l11lll_l1_ (u"ࠩ࠴ࠫ⊵")
			if l11lll_l1_ (u"ࠪࡴࡂ࠭⊶") in url: url,l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠫࡵࡃࠧ⊷"),1)
			conn = l11lll_l1_ (u"ࠬࠬࠧ⊸") if l11lll_l1_ (u"࠭࠿ࠨ⊹") in url else l11lll_l1_ (u"ࠧࡀࠩ⊺")
			if len(items)==40:
				url = url[:-1]+conn+l11lll_l1_ (u"ࠨࡲࡀࠫ⊻")+str(int(l1l11l1_l1_)+1)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⊼"),l111ll_l1_+l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ะวๅ์ฬࠫ⊽"),url,771)
			elif l1l11l1_l1_!=l11lll_l1_ (u"ࠫ࠶࠭⊾"):
				url = url[:-1]+conn+l11lll_l1_ (u"ࠬࡶ࠽ࠨ⊿")+str(int(l1l11l1_l1_)-1)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋀"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆุๅาฯࠠศๆึหอ่ษࠨ⋁"),url,771)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⋂"),url,l11lll_l1_ (u"ࠩࠪ⋃"),l11lll_l1_ (u"ࠪࠫ⋄"),l11lll_l1_ (u"ࠫࠬ⋅"),l11lll_l1_ (u"ࠬ࠭⋆"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⋇"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽࡮ࡤࡦࡪࡲ࠾ศๆอู๋๐แ࠽࠱࡯ࡥࡧ࡫࡬࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⋈"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1llll1ll1l_l1_,l1lllll1_l1_,l1lllll1lll_l1_ = [],[],[]
	# l1l111lll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡱ࡮ࡤࡽ࠲࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋉"),html,re.DOTALL)
	if link:
		link = link[0]
		if link not in l1lllll1lll_l1_:
			l1lllll1lll_l1_.append(link)
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ⋊"))
	# download links
	items = re.findall(l11lll_l1_ (u"ࠪࠦࡹࡸࠠࡧ࡮ࡨࡼ࠲ࡹࡴࡢࡴࡷࠦ࠳࠰࠿࠽ࡦ࡬ࡺࡃࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫࠪ࡟ࡨࢀ࠹ࠬ࠵ࡿࠬ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⋋"),html,re.DOTALL)
	for l11l111l_l1_,link in items:
		if link not in l1lllll1lll_l1_:
			l1lllll1lll_l1_.append(link)
			l11l111l_l1_ = l11l111l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭⋌"))
			server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⋍"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋎")+server+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ⋏")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ⋐"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⋑"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠪࠤࠬ⋒"),l11lll_l1_ (u"ࠫࠪ࠸࠰ࠨ⋓"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭⋔")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭⋕"))
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_ l1lllll1l_l1_ 2023-10-22
# ===========================================
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⋖"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⋗"),url,l11lll_l1_ (u"ࠩࠪ⋘"),l11lll_l1_ (u"ࠪࠫ⋙"),l11lll_l1_ (u"ࠫࠬ⋚"),l11lll_l1_ (u"ࠬ࠭⋛"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ⋜"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡧࡱࡵࡱ࠲ࡸ࡯ࡸࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ⋝"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴࠡࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺࠧ⋞"),block,re.DOTALL)
		l1llll1llll_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1llll1llll_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⋟"),block,re.DOTALL)
	return items
def l1llll1l1l1_l1_(url):
	# filter url
	url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⋠"),l11lll_l1_ (u"ࠫࡄࡺࡩࡵ࡮ࡨࡁࠫ࠭⋡"))
	return url
l1lllll1l11_l1_ = [l11lll_l1_ (u"ࠬࡿࡥࡢࡴࠪ⋢"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࠫ⋣"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭⋤")]
l1lllll1l1l_l1_ = [l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭⋥"),l11lll_l1_ (u"ࠩ࡯ࡥࡳ࡭ࠧ⋦"),l11lll_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ⋧")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭⋨"),l11lll_l1_ (u"ࠬ࠭⋩"))
	url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⋪"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⋫"),1)
	if filter==l11lll_l1_ (u"ࠨࠩ⋬"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠩࠪ⋭"),l11lll_l1_ (u"ࠪࠫ⋮")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⋯"))
	if type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⋰"):
		if l1lllll1l1l_l1_[0]+l11lll_l1_ (u"࠭࠽ࠨ⋱") not in l1l11l1l_l1_: category = l1lllll1l1l_l1_[0]
		for i in range(len(l1lllll1l1l_l1_[0:-1])):
			if l1lllll1l1l_l1_[i]+l11lll_l1_ (u"ࠧ࠾ࠩ⋲") in l1l11l1l_l1_: category = l1lllll1l1l_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⋳")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⋴")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⋵")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⋶")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⋷"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⋸")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⋹"))
		# l1lllll11l1_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ⋺"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⋻")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ⋼"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⋽"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1lllll1ll1_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ⋾"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⋿")+l1l11l11_l1_
		l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌀"),l111ll_l1_+l11lll_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ⌁"),l11l1l1_l1_,771,l11lll_l1_ (u"ࠩࠪ⌂"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⌃"))
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌄"),l111ll_l1_+l11lll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ⌅")+l11lll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ⌆"),l11l1l1_l1_,771,l11lll_l1_ (u"ࠧࠨ⌇"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⌈"))
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⌉"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⌊"),l11lll_l1_ (u"ࠫࠬ⌋"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"้ࠬไࠡࠩ⌌"),l11lll_l1_ (u"࠭ࠧ⌍"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠧ࠾ࠩ⌎") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⌏"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⌐")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌑"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ⌒"),l11l1l1_l1_,771,l11lll_l1_ (u"ࠬ࠭⌓"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⌔"))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌕"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ⌖"),l11l11l_l1_,775,l11lll_l1_ (u"ࠩࠪ⌗"),l11lll_l1_ (u"ࠪࠫ⌘"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ⌙"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ⌚")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩ⌛")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩ⌜")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿࠳ࠫ⌝")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭⌞")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌟"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭⌠")+name,l11l11l_l1_,774,l11lll_l1_ (u"ࠬ࠭⌡"),l11lll_l1_ (u"࠭ࠧ⌢"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⌣"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⌤")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ⌥")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⌦")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭⌧")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⌨")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩ〈")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠧ࠱ࠩ〉")]
			title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫ⌫")+name
			if type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ⌬"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌭"),l111ll_l1_+title,url,774,l11lll_l1_ (u"ࠫࠬ⌮"),l11lll_l1_ (u"ࠬ࠭⌯"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⌰"))
			elif type==l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⌱") and l1lllll1l1l_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࠪ⌲") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⌳"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⌴")+l1l1111l_l1_
				l11l1l1_l1_ = l1llll1l1l1_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌵"),l111ll_l1_+title,l11l1l1_l1_,771,l11lll_l1_ (u"ࠬ࠭⌶"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⌷"))
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌸"),l111ll_l1_+title,url,775,l11lll_l1_ (u"ࠨࠩ⌹"),l11lll_l1_ (u"ࠩࠪ⌺"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⌻")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⌼")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ⌽")					all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩ⌾"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫ⌿"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪ⍀"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫ⍁") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬ⍂"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭⍃"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭⍄")
	for key in l1lllll1l11_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ⍅")
		if l11lll_l1_ (u"ࠧࠦࠩ⍆") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⍇") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ⍈"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ⍉")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⍊") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ⍋"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⍌")+key+l11lll_l1_ (u"ࠧ࠾ࠩ⍍")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ⍎"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⍏")+key+l11lll_l1_ (u"ࠪࡁࠬ⍐")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ⍑"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⍒"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩ⍓"),l11lll_l1_ (u"ࠧ࠾ࠩ⍔"))
	return l1ll1l1l_l1_
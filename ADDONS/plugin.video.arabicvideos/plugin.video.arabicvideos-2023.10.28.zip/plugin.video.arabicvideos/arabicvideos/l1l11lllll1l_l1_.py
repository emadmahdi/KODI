# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ䷽")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡐࡘ࡚࡟ࠨ䷾")
l11lll1l1l11_l1_ = 4
l11lll11llll_l1_ = 10
def MAIN(mode,url,text,l1l11l1_l1_,l1ll11111ll_l1_):
	try: l11lll111111_l1_ = str(l1ll11111ll_l1_[l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷿")])
	except: l11lll111111_l1_ = l11lll_l1_ (u"ࠫࠬ一")
	if   mode==160: results = MENU()
	elif mode==161: results = l11llll11l11_l1_(text)
	elif mode==162: results = l11ll1ll1l1l_l1_(text,162)
	elif mode==163: results = l11ll1ll1l1l_l1_(text,163)
	elif mode==164: results = l11llll111l1_l1_(text)
	elif mode==165: results = l11ll1l1l1l1_l1_(url,text)
	elif mode==166: results = l11lll1ll11l_l1_(url,text)
	elif mode==167: results = l11ll1l1l11l_l1_(url,text)
	elif mode==168: results = l11ll11llll1_l1_(url,text)
	elif mode==761: results = l11lll1lllll_l1_()
	elif mode==762: results = l11lll111l1l_l1_()
	elif mode==763: results = l11lll1111ll_l1_(l11lll111111_l1_,text,l1l11l1_l1_)
	elif mode==764: results = l11lll1l111l_l1_(l11lll111111_l1_,text)
	elif mode==765: results = l11lll1lll1l_l1_(l11lll111111_l1_,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丁"),l11lll_l1_ (u"࠭โ็๊สฮࠥะไโิํ์ู๋ࠦี๊สส๏ฯࠧ丂"),l11lll_l1_ (u"ࠧࠨ七"),161,l11lll_l1_ (u"ࠨࠩ丄"),l11lll_l1_ (u"ࠩࠪ丅"),l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ丆"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ万"),l11lll_l1_ (u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ丈"),l11lll_l1_ (u"࠭ࠧ三"),162,l11lll_l1_ (u"ࠧࠨ上"),l11lll_l1_ (u"ࠨࠩ下"),l11lll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭丌"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ不"),l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ与"),l11lll_l1_ (u"ࠬ࠭丏"),163,l11lll_l1_ (u"࠭ࠧ丐"),l11lll_l1_ (u"ࠧࠨ丑"),l11lll_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭丒"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ专"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥฮอฬࠢ฼ุํอฦ๋ࠩ且"),l11lll_l1_ (u"ࠫࠬ丕"),164,l11lll_l1_ (u"ࠬ࠭世"),l11lll_l1_ (u"࠭ࠧ丗"),l11lll_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ丘"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丙"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ业"),l11lll_l1_ (u"ࠪࠫ丛"),763,l11lll_l1_ (u"ࠫࠬ东"),l11lll_l1_ (u"ࠬ࠭丝"),l11lll_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ丞"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ丟"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ丠"),l11lll_l1_ (u"ࠩࠪ両"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丢"),l11lll_l1_ (u"ࠫ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ丣"),l11lll_l1_ (u"ࠬ࠭两"),163,l11lll_l1_ (u"࠭ࠧ严"),l11lll_l1_ (u"ࠧࠨ並"),l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ丧"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ丨"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ丩"),l11lll_l1_ (u"ࠫࠬ个"),163,l11lll_l1_ (u"ࠬ࠭丫"),l11lll_l1_ (u"࠭ࠧ丬"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ中"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丮"),l11lll_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ丯"),l11lll_l1_ (u"ࠪࠫ丰"),162,l11lll_l1_ (u"ࠫࠬ丱"),l11lll_l1_ (u"ࠬ࠭串"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ丳"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ临"),l11lll_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ丵"),l11lll_l1_ (u"ࠩࠪ丶"),162,l11lll_l1_ (u"ࠪࠫ丷"),l11lll_l1_ (u"ࠫࠬ丸"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ丹"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭为"),l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷࡚ࠦศฮอࠣ฽ู๎วว์ࠪ主"),l11lll_l1_ (u"ࠨࠩ丼"),164,l11lll_l1_ (u"ࠩࠪ丽"),l11lll_l1_ (u"ࠪࠫ举"),l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ丿"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乀"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭乁"),l11lll_l1_ (u"ࠧࠨ乂"),765,l11lll_l1_ (u"ࠨࠩ乃"),l11lll_l1_ (u"ࠩࠪ乄"),l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭久"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ乆"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ乇"),l11lll_l1_ (u"࠭ࠧ么"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ义"),l11lll_l1_ (u"ࠨไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭乊"),l11lll_l1_ (u"ࠩࠪ之"),163,l11lll_l1_ (u"ࠪࠫ乌"),l11lll_l1_ (u"ࠫࠬ乍"),l11lll_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ乎"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭乏"),l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ乐"),l11lll_l1_ (u"ࠨࠩ乑"),163,l11lll_l1_ (u"ࠩࠪ乒"),l11lll_l1_ (u"ࠪࠫ乓"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭乔"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乕"),l11lll_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ乖"),l11lll_l1_ (u"ࠧࠨ乗"),162,l11lll_l1_ (u"ࠨࠩ乘"),l11lll_l1_ (u"ࠩࠪ乙"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ乚"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乛"),l11lll_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭乜"),l11lll_l1_ (u"࠭ࠧ九"),162,l11lll_l1_ (u"ࠧࠨ乞"),l11lll_l1_ (u"ࠨࠩ也"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ习"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乡"),l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ乢"),l11lll_l1_ (u"ࠬ࠭乣"),164,l11lll_l1_ (u"࠭ࠧ乤"),l11lll_l1_ (u"ࠧࠨ乥"),l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ书"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乧"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ乨"),l11lll_l1_ (u"ࠫࠬ乩"),764,l11lll_l1_ (u"ࠬ࠭乪"),l11lll_l1_ (u"࠭ࠧ乫"),l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ乬"))
	return
def l11lll1lllll_l1_():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ乭"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ乮")+l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨ乯"),l11lll_l1_ (u"ࠫࠬ买"),764)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ乱"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭乲"),l11lll_l1_ (u"ࠧࠨ乳"),9999)
	for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
		l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡌࡔࠬ乴")+str(l11lll111111_l1_)+l11lll_l1_ (u"ࠩࡢࠫ乵")
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乶"),l111ll_l1_+l11lll_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭乷")+text_numbers[l11lll111111_l1_],l11lll_l1_ (u"ࠬ࠭乸"),764,l11lll_l1_ (u"࠭ࠧ乹"),l11lll_l1_ (u"ࠧࠨ乺"),l11lll_l1_ (u"ࠨࠩ乻"),l11lll_l1_ (u"ࠩࠪ乼"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乽"):l11lll111111_l1_})
	return
def l11lll111l1l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乾"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ乿")+l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪ亀"),l11lll_l1_ (u"ࠧࠨ亁"),765)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭亂"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ亃"),l11lll_l1_ (u"ࠪࠫ亄"),9999)
	for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
		#l11ll1llll11_l1_ = l11lll_l1_ (u"ࠫࠥࡓ࠳ࡖࠩ亅")+str(l11lll111111_l1_)
		l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡍࡖࠩ了")+str(l11lll111111_l1_)+l11lll_l1_ (u"࠭࡟ࠨ亇")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ予"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪ争")+text_numbers[l11lll111111_l1_],l11lll_l1_ (u"ࠩࠪ亊"),765,l11lll_l1_ (u"ࠪࠫ事"),l11lll_l1_ (u"ࠫࠬ二"),l11lll_l1_ (u"ࠬ࠭亍"),l11lll_l1_ (u"࠭ࠧ于"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亏"):l11lll111111_l1_})
	return
def l11lll1llll1_l1_(l1l1l1l1ll1_l1_):
	l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_ = l1l1l11l11l_l1_(l1l1l1l1ll1_l1_)
	try:
		if l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ亐") in l1l1l1l1ll1_l1_: l1l1l11ll1l_l1_(l1l1l1l1ll1_l1_)
		else: l1l1l11ll1l_l1_()
		l11lll111l11_l1_ = False
	except: l11lll111l11_l1_ = True
	l1l1l1l1ll1_l1_ = TRANSLATE(l1l1l1l1ll1_l1_)
	if l11lll111l11_l1_: DIALOG_NOTIFICATION(l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠩไุ้ࠦศ่าสࠤฬ๊ๅ้ไ฼ࠫ云"),time=2000)
	else: DIALOG_NOTIFICATION(l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠪฮ๊ࠦฬๅสࠣห้ษโิษ่ࠫ互"),time=2000)
	return l11lll111l11_l1_
def l11ll1lllll1_l1_(l11lll111ll1_l1_=True):
	if not l11lll111ll1_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ亓"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭五"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ井"))
		if results:
			contentsDICT = results
			return
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ亖"),l11lll_l1_ (u"ࠨࠩ亗"),l11lll_l1_ (u"ࠩࠪ亘"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭亙"),l11lll_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ亚"))
	if l1ll11l111_l1_!=1: return
	l11ll1l111ll_l1_ = menuItemsLIST
	l11ll1lll1ll_l1_,l11ll1lll11l_l1_ = 0,l11lll_l1_ (u"ࠬ࠭些")
	for l1l1l1l1ll1_l1_ in l11l1l11ll1_l1_:
		time.sleep(0.5)
		l11lll111l11_l1_ = l11lll1llll1_l1_(l1l1l1l1ll1_l1_)
		if l11lll111l11_l1_:
			l11ll1lll1ll_l1_ += 1
			l11ll1lll11l_l1_ += l11lll_l1_ (u"࠭ࠠࠨ亜")+l1l1l1l1ll1_l1_
			if l11ll1lll1ll_l1_>=l11lll11llll_l1_: break
	menuItemsLIST[:] = l11ll1l111ll_l1_
	if l11ll1lll1ll_l1_>=l11lll11llll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ亝"),l11lll_l1_ (u"ࠨࠩ亞"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ亟"),l11lll_l1_ (u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫ亠")+str(l11ll1lll1ll_l1_)+l11lll_l1_ (u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩ亡")+l11ll1lll11l_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭亢"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ亣"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ交"),l11lll_l1_ (u"ࠨࠩ亥"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ亦"),l11lll_l1_ (u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩ产"))
	return
def l11ll1ll11l1_l1_(l11lll111111_l1_,options):
	l11llllll1l_l1_ = False
	l11ll11lllll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllll1l_l1_ and l11lll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ亨") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ亩"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭亪"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ享")+l11lll111111_l1_)
	elif l11lll_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ京") not in options or l11lll_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ亭") not in options:
		import IPTV
		message = l11lll_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ亮")
		if l11lll_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ亯") not in options:
			try: IPTV.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ亰"),l11lll_l1_ (u"࠭ࠧ亱"),l11lll_l1_ (u"ࠧࠨ亲"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭亳"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ亴"),l11lll_l1_ (u"ࠪࠫ亵"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ亶"),message)
			try: IPTV.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ亷"),l11lll_l1_ (u"࠭ࠧ亸"),l11lll_l1_ (u"ࠧࠨ亹"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭人"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ亻"),l11lll_l1_ (u"ࠪࠫ亼"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ亽"),message)
			try: IPTV.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ亾"),l11lll_l1_ (u"࠭ࠧ亿"),l11lll_l1_ (u"ࠧࠨ什"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭仁"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ仂"),l11lll_l1_ (u"ࠪࠫ仃"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ仄"),message)
		if l11lll_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ仅") not in options:
			try: IPTV.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭仆"),l11lll_l1_ (u"ࠧࠨ仇"),l11lll_l1_ (u"ࠨࠩ仈"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ仉"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ今"),l11lll_l1_ (u"ࠫࠬ介"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ仌"),message)
			try: IPTV.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ仍"),l11lll_l1_ (u"ࠧࠨ从"),l11lll_l1_ (u"ࠨࠩ仏"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ仐"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ仑"),l11lll_l1_ (u"ࠫࠬ仒"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ仓"),message)
		results = menuItemsLIST
		if l11llllll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭仔"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ仕")+l11lll111111_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll11lllll_l1_
	return results
def l11lll1111l1_l1_(l11lll111111_l1_,options):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ他"),l11lll_l1_ (u"ࠩࠪ仗"),l11lll_l1_ (u"ࠪࠫ付"),options)
	l11llllll1l_l1_ = False
	l11ll11lllll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllll1l_l1_ and l11lll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ仙") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ仚"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ仛"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ仜")+l11lll111111_l1_)
	elif l11lll_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ仝") not in options or l11lll_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ仞") not in options:
		import M3U
		message = l11lll_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ仟")
		if l11lll_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ仠") not in options:
			try: M3U.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ仡"),l11lll_l1_ (u"࠭ࠧ仢"),l11lll_l1_ (u"ࠧࠨ代"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭令"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ以"),l11lll_l1_ (u"ࠪࠫ仦"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ仧"),message)
			try: M3U.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ仨"),l11lll_l1_ (u"࠭ࠧ仩"),l11lll_l1_ (u"ࠧࠨ仪"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭仫"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ们"),l11lll_l1_ (u"ࠪࠫ仭"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ仮"),message)
			try: M3U.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ仯"),l11lll_l1_ (u"࠭ࠧ仰"),l11lll_l1_ (u"ࠧࠨ仱"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭仲"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ仳"),l11lll_l1_ (u"ࠪࠫ仴"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ仵"),message)
		if l11lll_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ件") not in options:
			try: M3U.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭价"),l11lll_l1_ (u"ࠧࠨ仸"),l11lll_l1_ (u"ࠨࠩ仹"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ仺"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ任"),l11lll_l1_ (u"ࠫࠬ仼"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ份"),message)
			try: M3U.GROUPS(l11lll111111_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ仾"),l11lll_l1_ (u"ࠧࠨ仿"),l11lll_l1_ (u"ࠨࠩ伀"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ企"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ伂"),l11lll_l1_ (u"ࠫࠬ伃"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ伄"),message)
		results = menuItemsLIST
		if l11llllll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ伅"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ伆")+l11lll111111_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll11lllll_l1_
	return results
def l11lll1111ll_l1_(l11lll111111_l1_,options,l11ll1l1ll11_l1_):
	if l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭伇") in options and l11ll1l1ll11_l1_==l11lll_l1_ (u"ࠩࠪ伈"): l11ll1lllll1_l1_(True)
	elif l11ll1l1ll11_l1_: l11ll1lllll1_l1_(False)
	l11ll1l1llll_l1_ = options.replace(l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ伉"),l11lll_l1_ (u"ࠫࠬ伊")).replace(l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ伋"),l11lll_l1_ (u"࠭ࠧ伌")).replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ伍"),l11lll_l1_ (u"ࠨࠩ伎"))
	if not l11ll1l1ll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ伏"),l11lll_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ伐"),l11lll_l1_ (u"ࠫࠬ休"),763,l11lll_l1_ (u"ࠬ࠭伒"),l11lll_l1_ (u"࠭ࠧ伓"),l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ伔")+l11ll1l1llll_l1_,l11lll_l1_ (u"ࠨࠩ伕"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伖"):l11lll111111_l1_})
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ众"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ优"),l11lll_l1_ (u"ࠬ࠭伙"),9999)
	l1ll1l11l1_l1_ = [l11lll_l1_ (u"࠭รโๆส้ࠬ会"),l11lll_l1_ (u"ࠧๆี็ื้อสࠨ伛"),l11lll_l1_ (u"ࠨ็ึีา๐วหࠩ伜"),l11lll_l1_ (u"ࠩหีฬ๋ฬࠨ伝"),l11lll_l1_ (u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩ伞"),l11lll_l1_ (u"ࠫึ๋ึศ่ࠪ伟"),l11lll_l1_ (u"ࠬษอะอ࠰วำืࠧ传"),l11lll_l1_ (u"࠭ำๅษึ่ࠬ伡"),l11lll_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ伢"),l11lll_l1_ (u"ࠨลื๋ึ࠳รไอิࠫ伣"),l11lll_l1_ (u"ࠩส่ว์ࠧ伤"),l11lll_l1_ (u"ฺࠪา้ࠧ伥"),l11lll_l1_ (u"ࠫึ๐วืหࠪ伦"),l11lll_l1_ (u"ࠬ์๊หใ็็ุ࠭伧"),l11lll_l1_ (u"࠭ๅๆอ็๎๋࠭伨"),l11lll_l1_ (u"ࠧษอࠣั๏࠭伩"),l11lll_l1_ (u"ࠨัํ๊๏ฯࠧ伪"),l11lll_l1_ (u"ࠩึ๊ํอสࠨ伫"),l11lll_l1_ (u"ࠪวำื้ࠨ伬")]
	l11ll1l11l11_l1_ = [l11lll_l1_ (u"ࠫฬ็ไศ็ࠪ伭"),l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ伮"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ伯"),l11lll_l1_ (u"ࠧโๆ่ࠫ估")]
	l11lll1l11l1_l1_ = [l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ伱"),l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ伲")]
	l11llll111ll_l1_ = [l11lll_l1_ (u"ุ้ࠪอัฮࠩ伳"),l11lll_l1_ (u"ู๊ࠫัฮ์สฮࠬ伴")]
	l11ll1l1lll1_l1_ = [l11lll_l1_ (u"ࠬฮัศ็ฯࠫ伵"),l11lll_l1_ (u"࠭ࡳࡩࡱࡺࠫ伶"),l11lll_l1_ (u"ࠧหๆไึ๏๎ๆࠨ伷"),l11lll_l1_ (u"ࠨฬ็๎ๆุ๊้่ࠪ伸")]
	l11lll11ll1l_l1_ = [l11lll_l1_ (u"ࠩส๊๊๐ࠧ伹"),l11lll_l1_ (u"ࠪ็ึะ่็ࠩ伺"),l11lll_l1_ (u"่ࠫอัห๊้ࠫ伻"),l11lll_l1_ (u"ࠬࡱࡩࡥࡵࠪ似"),l11lll_l1_ (u"࠭ืโๆࠪ伽"),l11lll_l1_ (u"ࠧศูไห้࠭伾")]
	l111l111_l1_ = [l11lll_l1_ (u"ࠨำฺ่ฬ์ࠧ伿")]
	l1lllll1l_l1_ = [l11lll_l1_ (u"ࠩสัิัࠧ佀"),l11lll_l1_ (u"ࠪหำืࠧ佁"),l11lll_l1_ (u"๊ࠫ๎ฮาࠩ佂"),l11lll_l1_ (u"ࠬาฯ๋ัࠪ佃"),l11lll_l1_ (u"࠭ๅืษไࠫ佄"),l11lll_l1_ (u"ࠧฮัํฯࠬ佅")]
	l11ll1ll11ll_l1_ = [l11lll_l1_ (u"ࠨี็หุ๊ࠧ但"),l11lll_l1_ (u"ࠩึุ่๊็ࠨ佇")]
	l11ll11lll1l_l1_ = [l11lll_l1_ (u"ࠪห฿อๆ๋ࠩ佈"),l11lll_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ佉"),l11lll_l1_ (u"้ࠬไ๋สࠪ佊"),l11lll_l1_ (u"࠭อโๆࠪ佋"),l11lll_l1_ (u"ࠧ࡮ࡷࡶ࡭ࡨ࠭佌")]
	l11111l11_l1_ = [l11lll_l1_ (u"ࠨษๆฯึ࠭位"),l11lll_l1_ (u"ࠩสุ์ืࠧ低"),l11lll_l1_ (u"้๊ࠪ๐า่ࠩ住"),l11lll_l1_ (u"ࠫฬ฿ไ๊ࠩ佐"),l11lll_l1_ (u"๋ࠬฮหษิ๋ࠬ佑"),l11lll_l1_ (u"࠭ๅฯฬสีฬะࠧ佒"),l11lll_l1_ (u"ࠧศไ๋ํࠬ体")]
	l11ll11lll11_l1_ = [l11lll_l1_ (u"ࠨษ็ห๋࠭佔"),l11lll_l1_ (u"ࠩะห้๐ࠧ何"),l11lll_l1_ (u"้ࠪะฮสࠨ佖"),l11lll_l1_ (u"ࠫึอฦอࠩ佗")]
	l11ll1l11111_l1_ = [l11lll_l1_ (u"ࠬ฼อไࠩ佘"),l11lll_l1_ (u"࠭ใ้็ํำ๏࠭余")]
	l11lll1ll111_l1_ = [l11lll_l1_ (u"ࠧา์สฺ์࠭佚"),l11lll_l1_ (u"ࠨๅ๋ี์࠭佛"),l11lll_l1_ (u"ู่ࠩฬืู่ࠩ作"),l11lll_l1_ (u"ุࠪํะࠧ佝"),l11lll_l1_ (u"ࠫึ๐วืหࠪ佞")]
	l11lll11l111_l1_ = [l11lll_l1_ (u"ࠬ์๊หใ็็ุ࠭佟"),l11lll_l1_ (u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧ你"),l11lll_l1_ (u"ࠧ็์อๅ้๐ใิࠩ佡")]
	l11ll1l111l1_l1_ = [l11lll_l1_ (u"ࠨ็่ฯ้๐ๆࠨ佢"),l11lll_l1_ (u"ࠩสุำอีࠨ佣"),l11lll_l1_ (u"๊ࠪั๎ๅࠨ佤")]
	l1l1lll1l_l1_ = [l11lll_l1_ (u"ࠫอัࠠฮ์ࠪ佥"),l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ佦"),l11lll_l1_ (u"࠭โ็ษ๊ࠫ佧"),l11lll_l1_ (u"ࠧใ่๋หฯ࠭佨")]
	l11lll11l1ll_l1_ = [l11lll_l1_ (u"ࠨัํ๊ࠬ佩"),l11lll_l1_ (u"ࠩสำ฾๐็ࠨ佪"),l11lll_l1_ (u"ࠪึ๏อัศฬࠪ佫"),l11lll_l1_ (u"้ࠫ฽ๅ๋ษอࠫ佬"),l11lll_l1_ (u"ࠬีูศรࠪ佭"),l11lll_l1_ (u"࠭โาษ้ࠫ佮"),l11lll_l1_ (u"ࠧใืสสิ࠭佯"),l11lll_l1_ (u"ࠨำฮหฦ࠭佰"),l11lll_l1_ (u"่ࠩีั฿๊่ࠩ佱"),l11lll_l1_ (u"ࠪหีอๆࠨ佲"),l11lll_l1_ (u"ࠫฬูไศ็ࠪ佳"),l11lll_l1_ (u"ࠬะ่ศึํัࠬ佴"),l11lll_l1_ (u"࠭ฮุสࠪ併"),l11lll_l1_ (u"ࠧฮ๊ี์๏࠭佶"),l11lll_l1_ (u"ࠨ฻อฬฬะࠧ佷"),l11lll_l1_ (u"่ࠩ์ฬ๊๊ะࠩ佸"),l11lll_l1_ (u"๊ࠪํอู๋ࠩ佹"),l11lll_l1_ (u"ࠫ฾่ววัࠪ佺"),l11lll_l1_ (u"ࠬอๆศึํำࠬ佻")]
	l11ll1l11l1l_l1_ = [l11lll_l1_ (u"࠭࠱࠺ࠩ佼"),l11lll_l1_ (u"ࠧ࠳࠲ࠪ佽"),l11lll_l1_ (u"ࠨ࠴࠴ࠫ佾"),l11lll_l1_ (u"ࠩ࠵࠶ࠬ使"),l11lll_l1_ (u"ࠪ࠶࠸࠭侀"),l11lll_l1_ (u"ࠫ࠷࠺ࠧ侁"),l11lll_l1_ (u"ࠬ࠸࠵ࠨ侂"),l11lll_l1_ (u"࠭࠲࠷ࠩ侃")]
	if not l11ll1l1ll11_l1_:
		l11ll1l1ll11_l1_ = 0
		for l11ll1llllll_l1_ in l1ll1l11l1_l1_:
			l11ll1l1ll11_l1_ += 1
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侄"),l111ll_l1_+l11ll1llllll_l1_,l11lll_l1_ (u"ࠨࠩ侅"),763,l11lll_l1_ (u"ࠩࠪ來"),str(l11ll1l1ll11_l1_),l11ll1l1llll_l1_,l11lll_l1_ (u"ࠪࠫ侇"),{l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侈"):l11lll111111_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1ll111l11l_l1_ = name.lower()
			category = []
			if any(value in l1ll111l11l_l1_ for value in l11ll1l11l11_l1_): category.append(1)
			if any(value in l1ll111l11l_l1_ for value in l11lll1l11l1_l1_): category.append(2)
			if any(value in l1ll111l11l_l1_ for value in l11llll111ll_l1_): category.append(3)
			if any(value in l1ll111l11l_l1_ for value in l11ll1l1lll1_l1_): category.append(4)
			if any(value in l1ll111l11l_l1_ for value in l11lll11ll1l_l1_): category.append(5)
			if any(value in l1ll111l11l_l1_ for value in l111l111_l1_): category.append(6)
			if any(value in l1ll111l11l_l1_ for value in l1lllll1l_l1_) and l1ll111l11l_l1_ not in [l11lll_l1_ (u"ࠬอฮา๋ࠪ侉")]: category.append(7)
			if any(value in l1ll111l11l_l1_ for value in l11ll1ll11ll_l1_): category.append(8)
			if any(value in l1ll111l11l_l1_ for value in l11ll11lll1l_l1_): category.append(9)
			if any(value in l1ll111l11l_l1_ for value in l11111l11_l1_): category.append(10)
			if any(value in l1ll111l11l_l1_ for value in l11ll11lll11_l1_): category.append(11)
			if any(value in l1ll111l11l_l1_ for value in l11ll1l11111_l1_): category.append(12)
			if any(value in l1ll111l11l_l1_ for value in l11lll1ll111_l1_): category.append(13)
			if any(value in l1ll111l11l_l1_ for value in l11lll11l111_l1_): category.append(14)
			if any(value in l1ll111l11l_l1_ for value in l11ll1l111l1_l1_): category.append(15)
			if any(value in l1ll111l11l_l1_ for value in l1l1lll1l_l1_): category.append(16)
			if any(value in l1ll111l11l_l1_ for value in l11lll11l1ll_l1_): category.append(17)
			if any(value in l1ll111l11l_l1_ for value in l11ll1l11l1l_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l11ll1l1ll11_l1_:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侊"),l111ll_l1_+name,name,166,l11lll_l1_ (u"ࠧࠨ例"),l11lll_l1_ (u"ࠨࠩ侌"),l11ll1l1llll_l1_+l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭侍"))
	return
def l11lll1l111l_l1_(l11lll111111_l1_,options):
	l11llllll1l_l1_ = False
	if l11llllll1l_l1_:
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ侎"),l11lll_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ侏"),l11lll_l1_ (u"ࠬ࠭侐"),764,l11lll_l1_ (u"࠭ࠧ侑"),l11lll_l1_ (u"ࠧࠨ侒"),l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭侓"),l11lll_l1_ (u"ࠩࠪ侔"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侕"):l11lll111111_l1_})
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ侖"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ侗"),l11lll_l1_ (u"࠭ࠧ侘"),9999)
	l11ll11lllll_l1_ = menuItemsLIST[:]
	import IPTV
	if l11lll111111_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l11lll111111_l1_,True): return
		l11ll1ll1l11_l1_ = l11ll1ll11l1_l1_(l11lll111111_l1_,options)
		l1ll1ll1l1l_l1_ = sorted(l11ll1ll1l11_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠧࠨ侙"),True): return
		if l11llllll1l_l1_ and l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭侚") not in options:
			l1ll1ll1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ供"),l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ侜"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨ依"))
		else:
			l11ll1l11ll1_l1_,l1ll1ll1l1l_l1_,l11ll1ll1l11_l1_ = [],[],[]
			for l11ll1llll11_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1ll1l1l_l1_ += l11ll1ll11l1_l1_(str(l11ll1llll11_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in l1ll1ll1l1l_l1_:
				if text not in l11ll1l11ll1_l1_:
					l11ll1l11ll1_l1_.append(text)
					l11lll1ll1l1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll11111ll_l1_
					l11ll1ll1l11_l1_.append(l11lll1ll1l1_l1_)
			l1ll1ll1l1l_l1_ = sorted(l11ll1ll1l11_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ侞"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪ侟"),l1ll1ll1l1l_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll11lllll_l1_+l1ll1ll1l1l_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ侠"))
	return
def l11lll1lll1l_l1_(l11lll111111_l1_,options):
	l11llllll1l_l1_ = False
	if l11llllll1l_l1_:
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭価"),l11lll_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭侢"),l11lll_l1_ (u"ࠪࠫ侣"),765,l11lll_l1_ (u"ࠫࠬ侤"),l11lll_l1_ (u"ࠬ࠭侥"),l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ侦"),l11lll_l1_ (u"ࠧࠨ侧"),{l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侨"):l11lll111111_l1_})
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ侩"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ侪"),l11lll_l1_ (u"ࠫࠬ侫"),9999)
	l11ll11lllll_l1_ = menuItemsLIST[:]
	import M3U
	if l11lll111111_l1_:
		if not M3U.CHECK_TABLES_EXIST(l11lll111111_l1_,True): return
		l11ll1ll1l11_l1_ = l11lll1111l1_l1_(l11lll111111_l1_,options)
		l1ll1ll1l1l_l1_ = sorted(l11ll1ll1l11_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠬ࠭侬"),True): return
		if l11llllll1l_l1_ and l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ侭") not in options:
			l1ll1ll1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ侮"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ侯"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬ侰"))
		else:
			l11ll1l11ll1_l1_,l1ll1ll1l1l_l1_,l11ll1ll1l11_l1_ = [],[],[]
			for l11ll1llll11_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1ll1l1l_l1_ += l11lll1111l1_l1_(str(l11ll1llll11_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in l1ll1ll1l1l_l1_:
				if text not in l11ll1l11ll1_l1_:
					l11ll1l11ll1_l1_.append(text)
					l11lll1ll1l1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll11111ll_l1_
					l11ll1ll1l11_l1_.append(l11lll1ll1l1_l1_)
			l1ll1ll1l1l_l1_ = sorted(l11ll1ll1l11_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ侱"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ侲"),l1ll1ll1l1l_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll11lllll_l1_+l1ll1ll1l1l_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ侳"))
	return
def l11ll1l1l1l1_l1_(group,options):
	# l11ll1l1l111_l1_ & iptv
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ侴"),l11lll_l1_ (u"ࠧࠨ侵"),group,options)
	l11llllll1l_l1_ = False
	results = []
	l11lll11111l_l1_ = l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ侶") if l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ侷") in options else l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ侸")
	if l11llllll1l_l1_: results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ侹"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ侺")+l11lll11111l_l1_[:-1],group)
	if not results:
		for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
			if l11llllll1l_l1_: results += READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ侻"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ侼")+l11lll11111l_l1_[:-1],l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ侽")+l11lll11111l_l1_+str(l11lll111111_l1_))
			elif l11lll11111l_l1_==l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ侾"): results += l11ll1ll11l1_l1_(str(l11lll111111_l1_),l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ便"))
			elif l11lll11111l_l1_==l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ俀"): results += l11lll1111l1_l1_(str(l11lll111111_l1_),l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ俁"))
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in results:
			if text==group: l1l1l1l111l1_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_)
		items,l1l1lll_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in menuItemsLIST:
			l11lll11l1l1_l1_ = type,name[4:],url,mode,l11l_l1_,l1l11l1_l1_,text,context,l11lll_l1_ (u"࠭ࠧ係")
			if l11lll11l1l1_l1_ not in l1l1lll_l1_:
				l1l1lll_l1_.append(l11lll11l1l1_l1_)
				item = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_
				items.append(item)
		results = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l11llllll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ促")+l11lll11111l_l1_[:-1],group,results,PERMANENT_CACHE)
	if l11lll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ俄") in options and len(results)>l11lll1l1l11_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俅"),l11lll_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ俆")+group+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ俇"),group,165,l11lll_l1_ (u"ࠬ࠭俈"),l11lll_l1_ (u"࠭ࠧ俉"),l11lll11111l_l1_+l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俊"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俋"),l11lll_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ俌"),group,165,l11lll_l1_ (u"ࠪࠫ俍"),l11lll_l1_ (u"ࠫࠬ俎"),l11lll11111l_l1_+l11lll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俏"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ俐"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ俑"),l11lll_l1_ (u"ࠨࠩ俒"),9999)
		results = menuItemsLIST+random.sample(results,l11lll1l1l11_l1_)
	menuItemsLIST[:] = results
	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭俓"))
	return
def l11llll11l11_l1_(options):
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俔"),l11lll_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ俕"),l11lll_l1_ (u"ࠬ࠭俖"),161,l11lll_l1_ (u"࠭ࠧ俗"),l11lll_l1_ (u"ࠧࠨ俘"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ俙"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ俚"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ俛"),l11lll_l1_ (u"ࠫࠬ俜"),9999)
	l1l1l11lll11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ保"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢ࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ俞")+l11lll_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ俟"),l11lll_l1_ (u"ࠨࠩ俠"),147)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ信"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ俢")+l11lll_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭俣"),l11lll_l1_ (u"ࠬ࠭俤"),148)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俥"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ俦")+l11lll_l1_ (u"ࠨไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠪ俧"),l11lll_l1_ (u"ࠩࠪ俨"),28)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ俩"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ俪")+l11lll_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ俫"),l11lll_l1_ (u"࠭ࠧ俬"),41)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ俭"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ修")+l11lll_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ俯"),l11lll_l1_ (u"ࠪࠫ俰"),135)
	import l1ll11l11lll_l1_
	l1ll11l11lll_l1_.ITEMS(l11lll_l1_ (u"ࠫ࠵࠭俱"),False)
	l1ll11l11lll_l1_.ITEMS(l11lll_l1_ (u"ࠬ࠷ࠧ俲"),False)
	l1ll11l11lll_l1_.ITEMS(l11lll_l1_ (u"࠭࠲ࠨ俳"),False)
	#l1ll11l11lll_l1_.ITEMS(l11lll_l1_ (u"ࠧ࠴ࠩ俴"),False)
	if l11lll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ俵") in options:
		menuItemsLIST[:] = l11ll1lll111_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11lll1l1l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1l1l11_l1_)
	menuItemsLIST[:] = l1l1l11lll11_l1_+menuItemsLIST
	return
def l11llll111l1_l1_(options):
	options = options.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俶"),l11lll_l1_ (u"ࠪࠫ俷")).replace(l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俸"),l11lll_l1_ (u"ࠬ࠭俹"))
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ俺") : l11lll_l1_ (u"ࠧࠨ俻") }
	url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ俼")
	data = {l11lll_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ俽"):l11lll_l1_ (u"ࠪ࠹࠵࠭俾")}
	data = l1ll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ俿"),url,data,headers,l11lll_l1_ (u"ࠬ࠭倀"),l11lll_l1_ (u"࠭ࠧ倁"),l11lll_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩ倂"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ倃"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ倄"),block,re.DOTALL)
	l11ll11ll1l1_l1_,l11ll1l11lll_l1_ = list(zip(*items))
	l11lll1lll11_l1_ = []
	l11llll1111l_l1_ = [l11lll_l1_ (u"ࠪࠤࠬ倅"),l11lll_l1_ (u"ࠫࠧ࠭倆"),l11lll_l1_ (u"ࠬࡦࠧ倇"),l11lll_l1_ (u"࠭ࠬࠨ倈"),l11lll_l1_ (u"ࠧ࠯ࠩ倉"),l11lll_l1_ (u"ࠨ࠼ࠪ倊"),l11lll_l1_ (u"ࠩ࠾ࠫ個"),l11lll_l1_ (u"ࠥࠫࠧ倌"),l11lll_l1_ (u"ࠫ࠲࠭倍")]
	l11lll1l1111_l1_ = l11ll1l11lll_l1_+l11ll11ll1l1_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭倎"),l11lll_l1_ (u"࠭ࠧ倏"),l11lll_l1_ (u"ࠧࠨ倐"),str(l11lll1l1111_l1_))
	for word in l11lll1l1111_l1_:
		if word in l11ll1l11lll_l1_: l11lll111lll_l1_ = 2
		if word in l11ll11ll1l1_l1_: l11lll111lll_l1_ = 4
		l11ll1ll111l_l1_ = [i in word for i in l11llll1111l_l1_]
		if any(l11ll1ll111l_l1_):
			index = l11ll1ll111l_l1_.index(True)
			l11ll1l1ll1l_l1_ = l11llll1111l_l1_[index]
			l11lll1l1ll1_l1_ = l11lll_l1_ (u"ࠨࠩ們")
			if word.count(l11ll1l1ll1l_l1_)>1: l11lll1l1lll_l1_,l11lll1l1l1l_l1_,l11lll1l1ll1_l1_ = word.split(l11ll1l1ll1l_l1_,2)
			else: l11lll1l1lll_l1_,l11lll1l1l1l_l1_ = word.split(l11ll1l1ll1l_l1_,1)
			if len(l11lll1l1lll_l1_)>l11lll111lll_l1_: l11lll1lll11_l1_.append(l11lll1l1lll_l1_.lower())
			if len(l11lll1l1l1l_l1_)>l11lll111lll_l1_: l11lll1lll11_l1_.append(l11lll1l1l1l_l1_.lower())
			if len(l11lll1l1ll1_l1_)>l11lll111lll_l1_: l11lll1lll11_l1_.append(l11lll1l1ll1_l1_.lower())
		elif len(word)>l11lll111lll_l1_: l11lll1lll11_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11lll1lll11_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11lll1lll11_l1_)),l11lll1lll11_l1_)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ倒")
	if l11lll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ倓") in options:
		l11ll1l1111l_l1_ = l1l1ll11l111_l1_
	elif l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ倔") in options:
		l11ll1l1111l_l1_ = [l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ倕")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"࠭ࠧ倖"),True): return
	elif l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭倗") in options:
		l11ll1l1111l_l1_ = [l11lll_l1_ (u"ࠨࡏ࠶࡙ࠬ倘")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ候"),True): return
	count,l11ll1llll1l_l1_ = 0,0
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倚"),l11lll_l1_ (u"ࠫࡠࠦࠠ࡞ࠢ࠽ห้ฮอฬࠢ฼๊ࠬ倛"),l11lll_l1_ (u"ࠬ࠭倜"),164,l11lll_l1_ (u"࠭ࠧ倝"),l11lll_l1_ (u"ࠧࠨ倞"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭借")+options)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ倠"),l11lll_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ倡"),l11lll_l1_ (u"ࠫࠬ倢"),164,l11lll_l1_ (u"ࠬ࠭倣"),l11lll_l1_ (u"࠭ࠧ値"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倥")+options)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭倦"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倧"),l11lll_l1_ (u"ࠪࠫ倨"),9999)
	l11ll11ll11l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11llll11111_l1_ = []
	for word in l11lll1lll11_l1_:
		l11lll1l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࡠࠨࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩ倩"),word,re.DOTALL)
		if l11lll1l1l1l_l1_: word = word.split(l11lll1l1l1l_l1_[0],1)[0]
		l11lll11lll1_l1_ = word.replace(l11lll_l1_ (u"ࠬ๗ࠧ倪"),l11lll_l1_ (u"࠭ࠧ倫")).replace(l11lll_l1_ (u"ࠧ๏ࠩ倬"),l11lll_l1_ (u"ࠨࠩ倭")).replace(l11lll_l1_ (u"ࠩ๎ࠫ倮"),l11lll_l1_ (u"ࠪࠫ倯")).replace(l11lll_l1_ (u"ࠫ๔࠭倰"),l11lll_l1_ (u"ࠬ࠭倱")).replace(l11lll_l1_ (u"࠭์ࠨ倲"),l11lll_l1_ (u"ࠧࠨ倳"))
		l11lll11lll1_l1_ = l11lll11lll1_l1_.replace(l11lll_l1_ (u"ࠨ๒ࠪ倴"),l11lll_l1_ (u"ࠩࠪ倵")).replace(l11lll_l1_ (u"ࠪ๑ࠬ倶"),l11lll_l1_ (u"ࠫࠬ倷")).replace(l11lll_l1_ (u"ࠬ๘ࠧ倸"),l11lll_l1_ (u"࠭ࠧ倹")).replace(l11lll_l1_ (u"ࠧญࠩ债"),l11lll_l1_ (u"ࠨࠩ倻")).replace(l11lll_l1_ (u"ࠩใࠫ值"),l11lll_l1_ (u"ࠪࠫ倽"))
		if l11lll11lll1_l1_: l11llll11111_l1_.append(l11lll11lll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11llll11111_l1_)),l11llll11111_l1_)
	l11lll11ll11_l1_ = []
	for l11ll111l1_l1_ in range(0,20):
		search = random.sample(l11llll11111_l1_,1)[0]
		if search in l11lll11ll11_l1_: continue
		l11lll11ll11_l1_.append(search)
		l1l1l1l1ll1_l1_ = random.sample(l11ll1l1111l_l1_,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ倾"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡘ࡬ࡨࡪࡵࠠࡔࡧࡤࡶࡨ࡮ࠠࠡࠢࡶ࡭ࡹ࡫࠺ࠨ倿")+str(l1l1l1l1ll1_l1_)+l11lll_l1_ (u"࠭ࠠࠡࡵࡨࡥࡷࡩࡨ࠻ࠩ偀")+search)
		#results = l1l1l1l111l1_l1_(l11lll_l1_ (u"ࠧࠨ偁"),l11lll_l1_ (u"ࠨࠩ偂"),l11lll_l1_ (u"ࠩࠪ偃"),l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠪࠫ偄"),l11lll_l1_ (u"ࠫࠬ偅"),search+l11lll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ偆"),l11lll_l1_ (u"࠭ࠧ假"),l11lll_l1_ (u"ࠧࠨ偈"))
		l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_ = l1l1l11l11l_l1_(l1l1l1l1ll1_l1_)
		l1l1l1l1l1l_l1_(search+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭偉"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ偊"),l11lll_l1_ (u"ࠪࠫ偋"))
	l11ll11ll11l_l1_[0][1] = l11lll_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ偌")+search+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻สะฯࠥ฿ๆ࡞ࠩ偍")
	menuItemsLIST[:] = l11ll1lll111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11lll1l1l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1l1l11_l1_)
	menuItemsLIST[:] = l11ll11ll11l_l1_+menuItemsLIST
	#import l1ll11lll11_l1_
	#l1ll11lll11_l1_.SEARCH(search)
	return
def l11lll1ll11l_l1_(l11ll1l1l1ll_l1_,options):
	l11ll1l1l1ll_l1_ = l11ll1l1l1ll_l1_.replace(l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ偎"),l11lll_l1_ (u"ࠧࠨ偏"))
	options = options.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ偐"),l11lll_l1_ (u"ࠩࠪ偑")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ偒"),l11lll_l1_ (u"ࠫࠬ偓"))
	l11ll1lllll1_l1_(False)
	if contentsDICT=={}: return
	if l11lll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ偔") in options:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭偕"),l11lll_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ偖")+l11ll1l1l1ll_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ偗"),l11ll1l1l1ll_l1_,166,l11lll_l1_ (u"ࠩࠪ偘"),l11lll_l1_ (u"ࠪࠫ偙"),l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ做")+options)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ偛"),l11lll_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ停"),l11ll1l1l1ll_l1_,166,l11lll_l1_ (u"ࠧࠨ偝"),l11lll_l1_ (u"ࠨࠩ偞"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ偟")+options)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ偠"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ偡"),l11lll_l1_ (u"ࠬ࠭偢"),9999)
	for l1l1ll11_l1_ in sorted(list(contentsDICT[l11ll1l1l1ll_l1_].keys())):
		type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = contentsDICT[l11ll1l1l1ll_l1_][l1l1ll11_l1_]
		if l11lll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ偣") in options or len(contentsDICT[l11ll1l1l1ll_l1_])==1:
			l1l1l1l111l1_l1_(type,l11lll_l1_ (u"ࠧࠨ偤"),url,l1l1ll11lll1_l1_,l11lll_l1_ (u"ࠨࠩ健"),l1l11l1_l1_,text,l11lll_l1_ (u"ࠩࠪ偦"),l11lll_l1_ (u"ࠪࠫ偧"))
			menuItemsLIST[:] = l11ll1lll111_l1_(menuItemsLIST)
			l11ll11lllll_l1_,l1ll1ll1l1l_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1ll1ll1l1l_l1_)
			if l11lll_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭偨") in options: menuItemsLIST[:] = l11ll11lllll_l1_+l1ll1ll1l1l_l1_[:l11lll1l1l11_l1_]
			else: menuItemsLIST[:] = l11ll11lllll_l1_+l1ll1ll1l1l_l1_
		elif l11lll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭偩") in options: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭偪"),l1l1ll11_l1_,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_)
	return
def l11ll1ll1l1l_l1_(options,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ偫"),l11lll_l1_ (u"ࠨࠩ偬"),l11lll_l1_ (u"ࠩࠪ偭"),options)
	options = options.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ偮"),l11lll_l1_ (u"ࠫࠬ偯")).replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ偰"),l11lll_l1_ (u"࠭ࠧ偱"))
	name,l11ll1ll1111_l1_ = l11lll_l1_ (u"ࠧࠨ偲"),[]
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ偳"),l11lll_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭側")+name+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭偵"),l11lll_l1_ (u"ࠫࠬ偶"),mode,l11lll_l1_ (u"ࠬ࠭偷"),l11lll_l1_ (u"࠭ࠧ偸"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ偹")+options)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ偺"),l11lll_l1_ (u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩ偻"),l11lll_l1_ (u"ࠪࠫ偼"),mode,l11lll_l1_ (u"ࠫࠬ偽"),l11lll_l1_ (u"ࠬ࠭偾"),l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ偿")+options)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ傀"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ傁"),l11lll_l1_ (u"ࠩࠪ傂"),9999)
	l11ll11lllll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	results = []
	if l11lll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ傃") in options:
		l11ll1lllll1_l1_(False)
		if contentsDICT=={}: return
		l11ll1ll1lll_l1_ = list(contentsDICT.keys())
		l11ll1l1l1ll_l1_ = random.sample(l11ll1ll1lll_l1_,1)[0]
		l11lll1lll11_l1_ = list(contentsDICT[l11ll1l1l1ll_l1_].keys())
		l1l1ll11_l1_ = random.sample(l11lll1lll11_l1_,1)[0]
		type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = contentsDICT[l11ll1l1l1ll_l1_][l1l1ll11_l1_]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ傄"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡽࡥࡣࡵ࡬ࡸࡪࡀࠠࠨ傅")+l1l1ll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ傆")+name+l11lll_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ傇")+url+l11lll_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ傈")+str(l1l1ll11lll1_l1_))
	elif l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ傉") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠪࠫ傊"),True): return
		for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11ll1ll11l1_l1_(str(l11lll111111_l1_),options)
		if not results: return
		type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ傋"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ傌")+name+l11lll_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ傍")+url+l11lll_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ傎")+str(l1l1ll11lll1_l1_))
	elif l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ傏") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ傐"),True): return
		for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11lll1111l1_l1_(str(l11lll111111_l1_),options)
		if not results: return
		type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ傑"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ傒")+name+l11lll_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ傓")+url+l11lll_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ傔")+str(l1l1ll11lll1_l1_))
	l11lll11l11l_l1_ = name
	l11ll1lll1l1_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ傕"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ傖")+name+l11lll_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ傗")+url+l11lll_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭傘")+str(l1l1ll11lll1_l1_))
		menuItemsLIST[:] = []
		if l1l1ll11lll1_l1_==234 and l11lll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ備") in text: l1l1ll11lll1_l1_ = 233
		if l1l1ll11lll1_l1_==714 and l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ傚") in text: l1l1ll11lll1_l1_ = 713
		if l1l1ll11lll1_l1_==144: l1l1ll11lll1_l1_ = 291
		dummy = l1l1l1l111l1_l1_(type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_)
		#if l11lll_l1_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ傛") in html: l11ll1ll1l1l_l1_(options,mode)
		if l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ傜") in options and l1l1ll11lll1_l1_==167: del menuItemsLIST[:3]
		if l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ傝") in options and l1l1ll11lll1_l1_==168: del menuItemsLIST[:3]
		l11ll1ll1111_l1_[:] = l11ll1lll111_l1_(menuItemsLIST)
		if l11ll1lll1l1_l1_ and l1l11llllll1_l1_(l11lll_l1_ (u"ࡷࠪั้่ษࠨ傞")) in str(l11ll1ll1111_l1_) or l1l11llllll1_l1_(l11lll_l1_ (u"ࡸࠫา๊โ่ࠩ傟")) in str(l11ll1ll1111_l1_):
			name = l11lll11l11l_l1_
			l11ll1ll1111_l1_[:] = l11ll1lll1l1_l1_
			break
		l11lll11l11l_l1_ = name
		l11ll1lll1l1_l1_ = l11ll1ll1111_l1_
		if str(l11ll1ll1111_l1_).count(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ傠"))>0: break
		if str(l11ll1ll1111_l1_).count(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ傡"))>0: break
		if l1l1ll11lll1_l1_==233: break	# iptv l111ll11_l1_ names l11l1lll1l1_l1_ of l1l1l_l1_ name
		if l1l1ll11lll1_l1_==713: break	# l11ll1l1l111_l1_ l111ll11_l1_ names l11l1lll1l1_l1_ of l1l1l_l1_ name
		if l1l1ll11lll1_l1_==291: break	# l1ll1llll_l1_ l11lll1ll1ll_l1_ names l11l1lll1l1_l1_ of l1ll1llll_l1_ l11lll1ll1ll_l1_ contents
		if l11ll1ll1111_l1_: type,name,url,l1l1ll11lll1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = random.sample(l11ll1ll1111_l1_,1)[0]
	if not name: name = l11lll_l1_ (u"࠭࠮࠯࠰࠱ࠫ傢")
	elif name.count(l11lll_l1_ (u"ࠧࡠࠩ傣"))>1: name = name.split(l11lll_l1_ (u"ࠨࡡࠪ傤"),2)[2]
	name = name.replace(l11lll_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐ࠽ࠤࠬ傥"),l11lll_l1_ (u"ࠪࠫ傦"))#.replace(l11lll_l1_ (u"ࠫ࠱ࡓࡏࡗࡋࡈࡗ࠿ࠦࠧ傧"),l11lll_l1_ (u"ࠬ࠭储")).replace(l11lll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ傩"),l11lll_l1_ (u"ࠧࠨ傪")).replace(l11lll_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ傫"),l11lll_l1_ (u"ࠩࠪ催"))
	name = name.replace(l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ傭"),l11lll_l1_ (u"ࠫࠬ傮"))
	l11ll11lllll_l1_[0][1] = l11lll_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ傯")+name+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ傰")
	for i in range(9): random.shuffle(l11ll1ll1111_l1_)
	if l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ傱") in options: menuItemsLIST[:] = l11ll11lllll_l1_+l11ll1ll1111_l1_[:l11lll1l1l11_l1_]
	else: menuItemsLIST[:] = l11ll11lllll_l1_+l11ll1ll1111_l1_
	return
def l11ll1l1l11l_l1_(l11ll11ll1ll_l1_,l11lll1l11ll_l1_):
	l11lll1l11ll_l1_ = l11lll1l11ll_l1_.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ傲"),l11lll_l1_ (u"ࠩࠪ傳")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傴"),l11lll_l1_ (u"ࠫࠬ債"))
	l11ll1ll1ll1_l1_ = l11lll1l11ll_l1_
	if l11lll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭傶") in l11lll1l11ll_l1_:
		l11ll1ll1ll1_l1_ = l11lll1l11ll_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ傷"))[0]
		type = l11lll_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ傸")
	elif l11lll_l1_ (u"ࠨࡘࡒࡈࠬ傹") in l11ll11ll1ll_l1_: type = l11lll_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ傺")
	elif l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ傻") in l11ll11ll1ll_l1_: type = l11lll_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ傼")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傽"),l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ傾")+type+l11ll1ll1ll1_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ傿"),l11ll11ll1ll_l1_,167,l11lll_l1_ (u"ࠨࠩ僀"),l11lll_l1_ (u"ࠩࠪ僁"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僂")+l11lll1l11ll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僃"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ僄"),l11ll11ll1ll_l1_,167,l11lll_l1_ (u"࠭ࠧ僅"),l11lll_l1_ (u"ࠧࠨ僆"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僇")+l11lll1l11ll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ僈"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ僉"),l11lll_l1_ (u"ࠫࠬ僊"),9999)
	import IPTV
	for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭僋") in l11lll1l11ll_l1_: IPTV.GROUPS(str(l11lll111111_l1_),l11ll11ll1ll_l1_,l11lll1l11ll_l1_,l11lll_l1_ (u"࠭ࠧ僌"),False)
		else: IPTV.ITEMS(str(l11lll111111_l1_),l11ll11ll1ll_l1_,l11lll1l11ll_l1_,l11lll_l1_ (u"ࠧࠨ働"),False)
	menuItemsLIST[:] = l11ll1lll111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1l1l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1l1l11_l1_)
	return
def l11ll11llll1_l1_(l11ll11ll1ll_l1_,l11lll1l11ll_l1_):
	l11lll1l11ll_l1_ = l11lll1l11ll_l1_.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ僎"),l11lll_l1_ (u"ࠩࠪ像")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ僐"),l11lll_l1_ (u"ࠫࠬ僑"))
	l11ll1ll1ll1_l1_ = l11lll1l11ll_l1_
	if l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ僒") in l11lll1l11ll_l1_:
		l11ll1ll1ll1_l1_ = l11lll1l11ll_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭僓"))[0]
		type = l11lll_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ僔")
	elif l11lll_l1_ (u"ࠨࡘࡒࡈࠬ僕") in l11ll11ll1ll_l1_: type = l11lll_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ僖")
	elif l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ僗") in l11ll11ll1ll_l1_: type = l11lll_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ僘")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僙"),l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ僚")+type+l11ll1ll1ll1_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ僛"),l11ll11ll1ll_l1_,168,l11lll_l1_ (u"ࠨࠩ僜"),l11lll_l1_ (u"ࠩࠪ僝"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僞")+l11lll1l11ll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僟"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ僠"),l11ll11ll1ll_l1_,168,l11lll_l1_ (u"࠭ࠧ僡"),l11lll_l1_ (u"ࠧࠨ僢"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僣")+l11lll1l11ll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ僤"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ僥"),l11lll_l1_ (u"ࠫࠬ僦"),9999)
	import M3U
	for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ僧") in l11lll1l11ll_l1_: M3U.GROUPS(str(l11lll111111_l1_),l11ll11ll1ll_l1_,l11lll1l11ll_l1_,l11lll_l1_ (u"࠭ࠧ僨"),False)
		else: M3U.ITEMS(str(l11lll111111_l1_),l11ll11ll1ll_l1_,l11lll1l11ll_l1_,l11lll_l1_ (u"ࠧࠨ僩"),False)
	menuItemsLIST[:] = l11ll1lll111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1l1l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1l1l11_l1_)
	return
def l11ll1lll111_l1_(menuItemsLIST):
	l11ll1ll1111_l1_ = []
	for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in menuItemsLIST:
		if l11lll_l1_ (u"ࠨืไัฮ࠭僪") in name or l11lll_l1_ (u"ุࠩๅาํࠧ僫") in name or l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ僬") in name.lower(): continue
		l11ll1ll1111_l1_.append([type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_])
	return l11ll1ll1111_l1_
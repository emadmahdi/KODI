# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ欏")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ欐")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠫࠬ欑")
#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ欒"):l11lll_l1_ (u"࠭ࠧ欓")}
def MAIN(mode,url,text,type,l1l11l1_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l1111l1l_l1_(url)
	#elif mode==142: results = l1ll1llll1lll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l11l1_l1_)
	elif mode==145: results = l1lll11ll111l_l1_(url)
	elif mode==146: results = l1ll1llll11l1_l1_(url)
	elif mode==147: results = l1lll111lll1l_l1_()
	elif mode==148: results = l1lll111lllll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡊ࠳࡙ࡥ࡛ࡏࡇ࡛ࡳࡻ࡮ࡅࡸࡒ࡙ࡷࡇࡨ࡝࡞࡛࡚ࡌࡑࡍࡽࡾࡵࡸࡸࡐࡕࠪ欔")
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ欕"),l111ll_l1_+l11lll_l1_ (u"ࠩࡗࡉࡘ࡚࡚ࠠࡑࡘࡘ࡚ࡈࡅࠨ欖"),url,144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ欗"),l111ll_l1_+l11lll_l1_ (u"ࠫࡴࡲࡤࡦࡴࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࠥࡴ࡯ࡵࠢ࡯࡭ࡸࡺࡩ࡯ࡩࠣࡲࡪࡽࡥࡳࠢࡳࡰࡾࡧ࡬ࡪࡵࡷࠫ欘"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡊࡵࡷࡥ࡚ࡼ࡛࡞࡫ࡱࠦ࡭࡫ࡶࡸࡂࡘࡄࡒࡏ࠹࠷ࡻࡎࡪࡑ࠲࡫ࡩ࡙ࡹࠧ欙"),144)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭欚"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วา฼ࠪ欛"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡺࡏࡷࡱࡱ࡮࠹ࡍࡹࡰࡲࡐࡘࡒࡈࡡ࠳࠵ࡴ࡙ࡨࡽࠧ欜"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欝"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ欞"),l11lll_l1_ (u"ࠫࠬ欟"),149,l11lll_l1_ (u"ࠬ࠭欠"),l11lll_l1_ (u"࠭ࠧ次"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ欢"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ欣"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ欤")+l11lll_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ欥")+l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ欦"),l11lll_l1_ (u"ࠬ࠭欧"),290)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭欨"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ欩")+l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ欪"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ欫"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ欬"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭欭")+l111ll_l1_+l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ欮"),l11ll1_l1_,144,l11lll_l1_ (u"࠭ࠧ欯"),l11lll_l1_ (u"ࠧࠨ欰"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ欱"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欲"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ欳")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ欴"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭欵"),146)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ欶"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ欷"),l11lll_l1_ (u"ࠨࠩ欸"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欹"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ欺")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ欻"),l11lll_l1_ (u"ࠬ࠭欼"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭欽"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ款")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ欿"),l11lll_l1_ (u"ࠩࠪ歀"),148)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ歁"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭歂")+l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ歃"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ歄"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歅"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ歆")+l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭歇"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ歈"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ歉"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ歊")+l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ歋"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ歌"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ歍"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ歎")+l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ歏"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ歐"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ歑"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ歒")+l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭歓"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ歔"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ歕"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ歖")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ歗"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ歘"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭歙"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ歚")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭歛"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭歜"),144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ歝"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭歞")+l111ll_l1_+l11lll_l1_ (u"ࠬอไฺำสๆࠥิืษหࠣห้๋ัอ฻ํอࠬ歟"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎ࠷࡮࡚ࡷ࠶ࡱࡰࡊ࠷࠻ࡗࡪࡶ࡚ࡇ࡬ࡓࡴࡉ࡭ࡴ࡬ࡹࡿࡸ࡯ࡕࡈࡷࡱ࡫ࡸࠧ歠"),144)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歡"),l111ll_l1_+l11lll_l1_ (u"ࠨษ฼ำฬีวหࠢสฺฬ็ษࠡ์๋ฮ๏๎ศࠨ止"),l11lll_l1_ (u"ࠩࠪ正"),144)
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ此"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ步"),l11lll_l1_ (u"ࠬํะศࠢส่ฬิส๋ษิࠤุ๎แࠡ์ัีั้ࠠๆ่ࠣห้ฮั็ษ่ะࠬ武"),l11lll_l1_ (u"࠭ไฤ่๊ࠤุ๎แࠡ์ๅ์๊ࠦศหึ฽๎้ࠦศา่ส้ั๊้ࠦฬํ์อ࠭歧"))
	#if l1ll11l111_l1_==1:
	#	url = l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ歨")
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ歩"))
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡕࡩࡵࡲࡡࡤࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡹ࡭ࡩ࡫࡯ࡴ࠮ࠪ歪")+url+l11lll_l1_ (u"ࠪ࠭ࠬ歫"))
	#	#xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡗࡻ࡮ࡂࡦࡧࡳࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ歬"))
	return
l11lll_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡓࡁࡊࡐࡓࡅࡌࡋࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰ࠱ࡩࡣ࠭ࡦࡤࡸࡦࠦ࠽ࠡࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁࠩࡷࡵࡰ࠮ࠐࠉࡪࡨࠣࠫࡗ࡫ࡦࡢࡣࡷࠤࡆࡲ࠭ࡈࡣࡰࡱࡦࡲࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡽࡪࡹࠧࠪࠌࠌࡨࡩࠦ࠽ࠡࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠎࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡰࡤ࡫ࡪ࠮࡬ࡦࡰࠫࡨࡩ࠯ࠩ࠻ࠌࠌࠍ࡮ࡺࡥ࡮ࠢࡀࠤࡩࡪ࡛ࡪ࡟ࠍࠍࠎࡏࡎࡔࡇࡕࡘࡤࡏࡔࡆࡏࡢࡘࡔࡥࡍࡆࡐࡘࠬ࡮ࡺࡥ࡮ࠫࠍࠍࡎ࡚ࡅࡎࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ歭")
def l1lll111lll1l_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭歮"))
	return
def l1lll111lllll_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ歯"))
	return
def PLAY(url,type):
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ歰")
	#items = re.findall(l11lll_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ歱"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ歲")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ歳"))
	#return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ歴")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1llll11l1_l1_(url):
	html,cc,data = l1lll111ll111_l1_(url)
	dd = cc[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ歵")][l11lll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ歶")][l11lll_l1_ (u"ࠨࡶࡤࡦࡸ࠭歷")]
	for l11ll111l1_l1_ in range(len(dd)):
		item = dd[l11ll111l1_l1_]
		l1lll11l1ll11_l1_(item,url,str(l11ll111l1_l1_))
	ee = dd[0][l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ歸")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ歹")][l11lll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ歺")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ死")]
	s = 0
	for l11ll111l1_l1_ in range(len(ee)):
		item = ee[l11ll111l1_l1_][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ歼")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ歽")][0]
		if list(item[l11lll_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ歾")][l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ歿")].keys())[0]==l11lll_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ殀"): continue
		succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_ = l1lll11ll1l1l_l1_(item)
		if not title:
			s += 1
			title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭殁")+str(s)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殂"),l111ll_l1_+title,url,144,l11lll_l1_ (u"࠭ࠧ殃"),str(l11ll111l1_l1_))
	key = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ殄"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭殅")+key[0]
	html,cc,l11ll1l11_l1_ = l1lll111ll111_l1_(l11l11l_l1_)
	for l1ll111ll11l_l1_ in range(3,4):
		dd = cc[l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ殆")][l1ll111ll11l_l1_][l11lll_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殇")][l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ殈")]
		for l11ll111l1_l1_ in range(len(dd)):
			item = dd[l11ll111l1_l1_]
			if l11lll_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ殉") in str(item): continue
			l1lll11l1ll11_l1_(item)
	return
def ITEMS(url,data=l11lll_l1_ (u"࠭ࠧ殊"),index=0):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ残"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ殌"),l11lll_l1_ (u"ࠩࠪ殍"))
	html,cc,l11ll1l11_l1_ = l1lll111ll111_l1_(url,data)
	l1l11111l1_l1_,ff = l11lll_l1_ (u"ࠪࠫ殎"),l11lll_l1_ (u"ࠫࠬ殏")
	#if l11lll_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠫ殐") in html.lower(): DIALOG_OK(l11lll_l1_ (u"࠭ࠧ殑"),l11lll_l1_ (u"ࠧࠨ殒"),l11lll_l1_ (u"ࠨࡱࡺࡲࡪࡸࠠࡦࡺ࡬ࡷࡹ࠭殓"),l11lll_l1_ (u"ࠩ࡬ࡲࠥ࡮ࡴ࡮࡮ࠪ殔"))
	owner = re.findall(l11lll_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ殕"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ殖"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ殗"),html,re.DOTALL)
	if owner:
		l1l11111l1_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ殘")+owner[0][0]+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ殙")
		link = owner[0][1]
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭殚") not in link: link = l11ll1_l1_+link
		#if l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭殛") in url and l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭殜") not in url and l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ殝") not in url and l11lll_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ殞") not in url:
		if l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ殟") in url: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ殠"),l111ll_l1_+l1l11111l1_l1_,link,144)
	#if cc==l11lll_l1_ (u"ࠨࠩ殡"): l1ll1llll1ll1_l1_(url,html) ; return
	l1ll1llll1l11_l1_ = [l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ殢"),l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ殣"),l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ殤"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ殥"),l11lll_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ殦"),l11lll_l1_ (u"ࠧࡴࡵࡀࠫ殧"),l11lll_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ殨"),l11lll_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ殩"),l11lll_l1_ (u"ࠪࡦࡵࡃࠧ殪"),l11lll_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ殫")]
	l1ll1llll1111_l1_ = not any(value in url for value in l1ll1llll1l11_l1_)
	if l1ll1llll1111_l1_ and l1l11111l1_l1_:
		l11l1ll11_l1_ = l11lll_l1_ (u"ࠬอไษฯฮࠫ殬")
		l1lll1lll_l1_ = l11lll_l1_ (u"࠭โ้ษษ้ࠥอไหึ฽๎้࠭殭")
		l11l1l1ll_l1_ = l11lll_l1_ (u"ࠧศๆไ๎ิ๐่่ษอࠫ殮")
		l1ll1llll111l_l1_ = l11lll_l1_ (u"ࠨษ็ๆ๋๎วหࠩ殯")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ殰"),l111ll_l1_+l1l11111l1_l1_,url,9999)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧฮอฬࠤࠪ殱") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ殲"),l111ll_l1_+l11l1ll11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭殳"),l11lll_l1_ (u"࠭ࠧ殴"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ段"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ殶") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ殷"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ殸"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ殹") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殺"),l111ll_l1_+l11l1l1ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ殻"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ殼") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ殽"),l111ll_l1_+l1ll1llll111l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ殾"),144)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾࡙ࠧࡥࡢࡴࡦ࡬ࠧ࠭殿") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毀"),l111ll_l1_+l11l1ll11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭毁"),l11lll_l1_ (u"࠭ࠧ毂"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ毃"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ毄") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毅"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ毆"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ毇") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毈"),l111ll_l1_+l11l1l1ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ毉"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ毊") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毋"),l111ll_l1_+l1ll1llll111l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ毌"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ母"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ毎"),l11lll_l1_ (u"ࠬ࠭每"),9999)
	if l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ毐") in url:
		dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ毑")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ毒")][l11lll_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ毓")][l11lll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ比")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭毕")]
		l1ll1lll1llll_l1_ = 0
		for i in range(len(dd)):
			if l11lll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ毖") in list(dd[i].keys()):
				l1ll1lll1lll1_l1_ = dd[i][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ毗")]
				length = len(str(l1ll1lll1lll1_l1_))
				if length>l1ll1lll1llll_l1_:
					l1ll1lll1llll_l1_ = length
					ff = l1ll1lll1lll1_l1_
		if l1ll1lll1llll_l1_==0: return
	elif l11lll_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ毘") in url or l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ毙") in url or l11lll_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ毚") in url or l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ毛") in url or l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ毜") in url or url==l11ll1_l1_:
		l1lll11111l1l_l1_ = []
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ毝"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ毞"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ毟"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ毠"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ毡"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠲࠷࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ毢"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ毣"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰ࡚ࡥࡹࡩࡨࡏࡧࡻࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟ࠥ毤"))
		l1ll1llll11ll_l1_,ff = l1ll1lllll1l1_l1_(cc,l11lll_l1_ (u"࠭ࠧ毥"),l1lll11111l1l_l1_)
	if not ff:
		try:
			dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ毦")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ毧")][l11lll_l1_ (u"ࠩࡷࡥࡧࡹࠧ毨")]
			l1ll11llll11_l1_ = l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ毩") in url or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ毪") in url or l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ毫") in url
			l1ll1lllllll1_l1_ = l11lll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭毬") in html or l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ毭") in html or l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ毮") in html
			l1ll1llllll1l_l1_ = l11lll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ毯") in html or l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ毰") in html or l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ毱") in html
			if l1ll11llll11_l1_ and (l1ll1lllllll1_l1_ or l1ll1llllll1l_l1_):
				for l11ll111l1_l1_ in range(len(dd)):
					if l11lll_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ毲") not in list(dd[l11ll111l1_l1_].keys()): continue
					ee = dd[l11ll111l1_l1_][l11lll_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ毳")]
					try: gg = ee[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ毴")][l11lll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ毵")][l11lll_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ毶")][l11lll_l1_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ毷")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ毸")][l11ll111l1_l1_]
					except: gg = ee
					try: link = gg[l11lll_l1_ (u"ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ毹")][l11lll_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ毺")][l11lll_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ毻")][l11lll_l1_ (u"ࠨࡷࡵࡰࠬ毼")]
					except: continue
					if   l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ毽")		in link	and l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ毾")		in url: ee = dd[l11ll111l1_l1_] ; break
					elif l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ毿")	in link	and l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ氀")	in url: ee = dd[l11ll111l1_l1_] ; break
					elif l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ氁")	in link	and l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ氂")		in url: ee = dd[l11ll111l1_l1_] ; break
					else: ee = dd[0]
			elif l11lll_l1_ (u"ࠨࡤࡳࡁࠬ氃") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ氄")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ氅")]
		except: pass
	if not ff: return
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氆"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ氇"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ氈"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氉"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ氊"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ氋"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ氌"))
	if l11lll_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ氍") not in url: l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡻࡢࡎࡧࡱࡹࠬࡣ࡛ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩࡠࠦ氎"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氏"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ氐"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ民"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氒"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ氓"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ气"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ氕"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ氖"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨࠥ気"))
	l1111l1111l_l1_ = l1l11llllll1_l1_(l11lll_l1_ (u"ࡶࠩๆ่่่ࠥศศ่ࠤฬ๊สี฼ํ่ࠬ氘"))
	l1111l111l1_l1_ = l1l11llllll1_l1_(l11lll_l1_ (u"ࡷࠪ็้ࠦวๅใํำ๏๎็ศฬࠪ氙"))
	l1ll1lllll111_l1_ = l1l11llllll1_l1_(l11lll_l1_ (u"ࡸ่๊ࠫࠠศๆๅ๊ํอสࠨ氚"))
	l11ll1ll1lll_l1_ = [l1111l1111l_l1_,l1111l111l1_l1_,l1ll1lllll111_l1_,l11lll_l1_ (u"ࠫࡆࡲ࡬ࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ氛"),l11lll_l1_ (u"ࠬࡇ࡬࡭ࠢࡹ࡭ࡩ࡫࡯ࡴࠩ氜"),l11lll_l1_ (u"࠭ࡁ࡭࡮ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ氝")]
	l1ll1llll1l1l_l1_,gg = l1ll1lllll1l1_l1_(ff,index,l1lll11111l1l_l1_)
	if l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ氞") in str(type(gg)) and any(value in str(gg[0]) for value in l11ll1ll1lll_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1lll11111l1l_l1_ = []
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ氟"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ氠"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ氡"))
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ氢"))		#4
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ氣"))		#7
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ氤"))		#6
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ氥"))		#5
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ氦"))
		l1ll1llll11ll_l1_,item = l1ll1lllll1l1_l1_(gg,index2,l1lll11111l1l_l1_)
		#if l1ll1llll11ll_l1_ not in [l11lll_l1_ (u"ࠩ࠵ࠫ氧"),l11lll_l1_ (u"ࠪ࠸ࠬ氨"),l11lll_l1_ (u"ࠫ࠺࠭氩")]: l1lll11l1ll11_l1_(item)		# 2,4,7
		#else: l1lll11l1ll11_l1_(item,url,str(index2))
		l1lll11l1ll11_l1_(item,url,str(index2))
		if l1ll1llll11ll_l1_==l11lll_l1_ (u"ࠬ࠺ࠧ氪"):
			try:
				hh = item[l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭氫")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ氬")][l11lll_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ氭")][l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ氮")]
				for l1lll111ll1ll_l1_ in range(len(hh)):
					l11lll11l1l1_l1_ = hh[l1lll111ll1ll_l1_]
					l1lll11l1ll11_l1_(l11lll11l1l1_l1_)
			except: pass
	l1llllll111_l1_ = False
	if l11lll_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ氯") not in url and l1ll1llll1l1l_l1_==l11lll_l1_ (u"ࠫ࠽࠭氰"): l1llllll111_l1_ = True
	if l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ氱") in l11ll1l11_l1_: l1lll11l11l11_l1_,key,l1lll11ll1l11_l1_,l1lll111llll1_l1_,token,l1lll111l1111_l1_ = l11ll1l11_l1_.split(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ氲"))
	else: l1lll11l11l11_l1_,key,l1lll11ll1l11_l1_,l1lll111llll1_l1_,token,l1lll111l1111_l1_ = l11lll_l1_ (u"ࠧࠨ氳"),l11lll_l1_ (u"ࠨࠩ水"),l11lll_l1_ (u"ࠩࠪ氵"),l11lll_l1_ (u"ࠪࠫ氶"),l11lll_l1_ (u"ࠫࠬ氷"),l11lll_l1_ (u"ࠬ࠭永")
	l11l11l_l1_,l1lll111lll_l1_ = l11lll_l1_ (u"࠭ࠧ氹"),l11lll_l1_ (u"ࠧࠨ氺")
	if menuItemsLIST:
		l1ll1llllll11_l1_ = str(menuItemsLIST[-1][1])
		if   l111ll_l1_+l11lll_l1_ (u"ࠨࡅࡋࡒࡑ࠭氻") in l1ll1llllll11_l1_: l1lll111lll_l1_ = l11lll_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ氼")
		elif l111ll_l1_+l11lll_l1_ (u"࡙ࠪࡘࡋࡒࠨ氽") in l1ll1llllll11_l1_: l1lll111lll_l1_ = l11lll_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭氾")
		elif l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ氿") in l1ll1llllll11_l1_: l1lll111lll_l1_ = l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ汀")
	if l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ汁") in html and l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ求") not in url and not l1llllll111_l1_ and l11lll_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ汃") not in url:	# and (index!=l11lll_l1_ (u"ࠪࠫ汄") or l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ汅") in url or l11lll_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ汆") in url or l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭汇") in url or l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭汈") in url):
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ汉")+l1lll11ll1l11_l1_
	elif l11lll_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ汊") in html and l11lll_l1_ (u"ࠪࡦࡵࡃࠧ汋") not in url and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ汌") in url or l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ汍") in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ汎")+key
	elif l11lll_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ汏") in html and l11lll_l1_ (u"ࠨࡤࡳࡁࠬ汐") not in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭汑")+key
	if l11l11l_l1_: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ汒"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ汓"),l11l11l_l1_,144,l1lll111lll_l1_,l11lll_l1_ (u"ࠬ࠭汔"),l11ll1l11_l1_)
	return
def l1ll1lllll1l1_l1_(l11llll1l111_l1_,l11lllll1l11_l1_,l1lll1111ll1l_l1_):
	cc = l11llll1l111_l1_
	ff,index = l11llll1l111_l1_,l11lllll1l11_l1_
	gg,index2 = l11llll1l111_l1_,l11lllll1l11_l1_
	item,render = l11llll1l111_l1_,l11lllll1l11_l1_
	count = len(l1lll1111ll1l_l1_)
	for l11ll111l1_l1_ in range(count):
		try:
			out = eval(l1lll1111ll1l_l1_[l11ll111l1_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"࠭ࠧ汕")
			return str(l11ll111l1_l1_+1),out
		except: pass
	return l11lll_l1_ (u"ࠧࠨ汖"),l11lll_l1_ (u"ࠨࠩ汗")
def l1lll11ll1l1l_l1_(item):
	try: l1lll11l1l111_l1_ = list(item.keys())[0]
	except: return False,l11lll_l1_ (u"ࠩࠪ汘"),l11lll_l1_ (u"ࠪࠫ汙"),l11lll_l1_ (u"ࠫࠬ汚"),l11lll_l1_ (u"ࠬ࠭汛"),l11lll_l1_ (u"࠭ࠧ汜"),l11lll_l1_ (u"ࠧࠨ汝"),l11lll_l1_ (u"ࠨࠩ汞")
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_ = False,l11lll_l1_ (u"ࠩࠪ江"),l11lll_l1_ (u"ࠪࠫ池"),l11lll_l1_ (u"ࠫࠬ污"),l11lll_l1_ (u"ࠬ࠭汢"),l11lll_l1_ (u"࠭ࠧ汣"),l11lll_l1_ (u"ࠧࠨ汤"),l11lll_l1_ (u"ࠨࠩ汥")
	#WRITE_THIS(l11lll_l1_ (u"ࠩࠪ汦"),str(item))
	render = item[l1lll11l1l111_l1_]
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ汧"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ汨"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ汩"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ汪"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ汫"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ汬"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ汭"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ汮"))
	l1ll1llll11ll_l1_,title = l1ll1lllll1l1_l1_(item,render,l1lll11111l1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ汯"),l11lll_l1_ (u"ࠬ࠭汰"),l11lll_l1_ (u"࠭ࠧ汱"),title)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ汲"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ汳"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ汴"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ汵")) # required for l11lll1ll1ll_l1_ l1llllll111_l1_
	l1ll1llll11ll_l1_,link = l1ll1lllll1l1_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ汶"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ汷"))
	l1ll1llll11ll_l1_,l1llll_l1_ = l1ll1lllll1l1_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ汸"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ汹"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ決"))
	l1ll1llll11ll_l1_,count = l1ll1lllll1l1_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ汻"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ汼"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ汽"))
	l1ll1llll11ll_l1_,l1l1l1111_l1_ = l1ll1lllll1l1_l1_(item,render,l1lll11111l1l_l1_)
	if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ汾") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ汿"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ沀")
	if l11lll_l1_ (u"ࠨ็หหูืࠧ沁") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠩࠪ沂"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ沃")
	if l11lll_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ沄") in list(render.keys()):
		l1lll11l1ll1l_l1_ = str(render[l11lll_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ沅")])
		if l11lll_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭沆") in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠧࠥ࠼ࠪ沇")
		if l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ沈") in l1lll11l1ll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ沉")
		if l11lll_l1_ (u"ࠪࡆࡺࡿࠧ沊") in l1lll11l1ll1l_l1_ or l11lll_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ沋") in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠬࠪࠤ࠻ࠩ沌")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡻࠧๆสสุึ࠭沍")) in l1lll11l1ll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ沎")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡶࠩืีฬวࠧ沏")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿࠭沐")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡸࠫฬูสวฮสีࠬ沑")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠫࠩࠪ࠺ࠨ沒")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ沓")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"࠭ࠤ࠻ࠩ沔")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ沕") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠨࡁࠪ沖"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ沗") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ沘")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll111ll11l_l1_: title = l1lll111ll11l_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ沙")+title
	#title = unescapeHTML(title)
	l1l1l1111_l1_ = l1l1l1111_l1_.replace(l11lll_l1_ (u"ࠬ࠲ࠧ沚"),l11lll_l1_ (u"࠭ࠧ沛"))
	count = count.replace(l11lll_l1_ (u"ࠧ࠭ࠩ沜"),l11lll_l1_ (u"ࠨࠩ沝"))
	count = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭沞"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"ࠪࠫ沟")
	return True,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_
def l1lll11l1ll11_l1_(item,url=l11lll_l1_ (u"ࠫࠬ沠"),index=l11lll_l1_ (u"ࠬ࠭没")):
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_ = l1lll11ll1l1l_l1_(item)
	#if l11lll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ沢") in url and index==l11lll_l1_ (u"ࠧ࠱ࠩ沣"):
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ沤"),l111ll_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭沥") in str(item): return	# l1lll11ll1l11_l1_ not items
	elif l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ沦") in str(item): return			# l1lll11l1l1l1_l1_ not items
	elif not link and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ沧") in url: return			# separator l1ll1lll1ll1l_l1_ list not items
	elif title and not link and (l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ沨") in url or l11lll_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭沩") in str(item) or url==l11ll1_l1_):
		title = l11lll_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ沪")+title+l11lll_l1_ (u"ࠨࠢࡀࡁࡂ࠭沫")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ沬"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ沭"),9999)
	elif title and l11lll_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭沮") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ沯"),l111ll_l1_+title,l11lll_l1_ (u"࠭ࠧ沰"),9999)
	elif l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ沱") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ沲"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif not title: return
	elif l1111llllll_l1_: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ河"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	#elif l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ沴") in link and l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ沵") not in link and l11lll_l1_ (u"ࠬࡺ࠽࠱ࠩ沶") not in link:
	#	l1lll111ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ沷"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ沸")+l1lll111ll1l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ油"),l111ll_l1_+l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ沺")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ治")+title,link,144,l1llll_l1_)
	elif l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭沼") in link or l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ沽") in link:
		if l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭沾") in link and l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ沿") not in link:
			l1lll111ll1l1_l1_ = link.split(l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ泀"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ況")+l1lll111ll1l1_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ泂"),l111ll_l1_+l11lll_l1_ (u"ࠫࡑࡏࡓࡕࠩ泃")+count+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ泄")+title,link,144,l1llll_l1_)
		else:
			link = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭泅"),1)[0]
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭泆"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	else:
		type = l11lll_l1_ (u"ࠨࠩ泇")
		if not link: link = url
		#if l11lll_l1_ (u"ࠩࡶࡷࡂ࠭泈") in link: link = url
		#elif l11lll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭泉") in link: link = url		# not needed it will stop l1ll1lllll11l_l1_ l11lll1ll1ll_l1_ l1llllll111_l1_
		elif not any(value in link for value in [l11lll_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ泊"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ泋"),l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ泌"),l11lll_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ泍"),l11lll_l1_ (u"ࠨࡵࡶࡁࠬ泎"),l11lll_l1_ (u"ࠩࡥࡴࡂ࠭泏")]):
			if l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭泐")	in link or l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ泑") in link: type = l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ泒")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ泓")
			if l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ泔") in link: type = l11lll_l1_ (u"ࠨࡗࡖࡉࡗ࠭法")+count+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭泖")
			index,l1lll11l111l1_l1_ = l11lll_l1_ (u"ࠪࠫ泗"),l11lll_l1_ (u"ࠫࠬ泘")
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ泙"),l111ll_l1_+type+title,link,144,l1llll_l1_,index)
	return
def l1lll111ll111_l1_(url,data=l11lll_l1_ (u"࠭ࠧ泚"),request=l11lll_l1_ (u"ࠧࠨ泛")):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ泜"))
	#if l11lll_l1_ (u"ࠩࡢࡣࠬ泝") in l1lll11l111l1_l1_: l1lll11l111l1_l1_ = l11lll_l1_ (u"ࠪࠫ泞")
	#if l11lll_l1_ (u"ࠫࡸࡹ࠽ࠨ泟") in url: url = url.split(l11lll_l1_ (u"ࠬࡹࡳ࠾ࠩ泠"))[0]
	if request==l11lll_l1_ (u"࠭ࠧ泡"): request = l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ波")
	l111llll1l_l1_ = l1l11111l_l1_()
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ泣"):l111llll1l_l1_,l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ泤"):l11lll_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ泥")}
	#l1l1ll1ll_l1_ = headers.copy()
	if l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ泦") in data: l1lll11l11l11_l1_,key,l1lll11ll1l11_l1_,l1lll111llll1_l1_,token,l1lll111l1111_l1_ = data.split(l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ泧"))
	else: l1lll11l11l11_l1_,key,l1lll11ll1l11_l1_,l1lll111llll1_l1_,token,l1lll111l1111_l1_ = l11lll_l1_ (u"࠭ࠧ注"),l11lll_l1_ (u"ࠧࠨ泩"),l11lll_l1_ (u"ࠨࠩ泪"),l11lll_l1_ (u"ࠩࠪ泫"),l11lll_l1_ (u"ࠪࠫ泬"),l11lll_l1_ (u"ࠫࠬ泭")
	if l11lll_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ泮") in url:
		l11ll1l11_l1_ = {}
		l11ll1l11_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ泯")] = {l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ泰"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ泱"):l11lll_l1_ (u"ࠤࡤࡶࠧ泲"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ泳"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ泴"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ泵"):l1lll111llll1_l1_}}
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ泶"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ泷"))
	elif l11lll_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭泸") in url and l1lll11l11l11_l1_:
		l11ll1l11_l1_ = {l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ泹"):token}
		l11ll1l11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ泺")] = {l11lll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ泻"):{l11lll_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ泼"):l1lll11l11l11_l1_,l11lll_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ泽"):l11lll_l1_ (u"ࠢࡘࡇࡅࠦ泾"),l11lll_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ泿"):l1lll111llll1_l1_}}
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ洀"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ洁"))
	elif l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ洂") in url and l1lll111l1111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭洃"):l11lll_l1_ (u"࠭࠱ࠨ洄"),l11lll_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ洅"):l1lll111llll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ洆"):l11lll_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ洇")+l1lll111l1111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ洈"),url,l11lll_l1_ (u"ࠫࠬ洉"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭洊"),l11lll_l1_ (u"࠭ࠧ洋"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ洌"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ洍"),url,l11lll_l1_ (u"ࠩࠪ洎"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ洏"),l11lll_l1_ (u"ࠫࠬ洐"),l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ洑"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭洒"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭洓"),html,re.DOTALL|re.I)
	if tmp: l1lll111llll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ洔"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ洕"),html,re.DOTALL|re.I)
	if tmp: l1lll11l11l11_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ洖"),html,re.DOTALL|re.I)
	if tmp: l1lll11ll1l11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ洗") in list(cookies.keys()): l1lll111l1111_l1_ = cookies[l11lll_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ洘")]
	data = l1lll11l11l11_l1_+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ洙")+key+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ洚")+l1lll11ll1l11_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ洛")+l1lll111llll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭洜")+token+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ洝")+l1lll111l1111_l1_
	if request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ洞") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ洟") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ洠"),html,re.DOTALL)
		if not l111lll11l_l1_: l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ洡"),html,re.DOTALL)
		l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠨࡵࡷࡶࠬ洢"),l111lll11l_l1_[0])
	elif request==l11lll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ洣") and l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ洤") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ津"),html,re.DOTALL)
		l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡹࡴࡳࠩ洦"),l111lll11l_l1_[0])
	elif l11lll_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ洧") not in html: l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ洨"),html)
	else: l1lll11111ll1_l1_ = l11lll_l1_ (u"ࠨࠩ洩")
	#open(l11lll_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭洪"),l11lll_l1_ (u"ࠪࡻࠬ洫")).write(str(l1lll11111ll1_l1_))
	#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ洬"),l11lll_l1_ (u"ࠬࡽࠧ洭")).write(html)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ洮"),data)
	return html,l1lll11111ll1_l1_,data
def l1lll11ll111l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ洯"),l11lll_l1_ (u"ࠨ࠭ࠪ洰"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ洱")+search
	ITEMS(l11l11l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ洲"),l11lll_l1_ (u"ࠫ࠰࠭洳"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ洴")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ洵") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ洶")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ洷") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ洸")
		elif l11lll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ洹") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ洺")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111l11l1_l1_
	else:
		l1lll111l111l_l1_,l1lll111111l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠬ࠭活")
		l1lll11111l11_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ洼"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭洽"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ派"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ洿"),l11lll_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ浀")]
		l1lll11l1l11l_l1_ = [l11lll_l1_ (u"ࠫࠬ流"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ浂"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ浃"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭浄"),l11lll_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ浅")]
		l1lll11l1lll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ浆"),l1lll11111l11_l1_)
		if l1lll11l1lll1_l1_ == -1: return
		l1lll1111llll_l1_ = l1lll11l1l11l_l1_[l1lll11l1lll1_l1_]
		html,c,data = l1lll111ll111_l1_(l11l11l_l1_+l1lll1111llll_l1_)
		if c:
			d = c[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ浇")][l11lll_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ浈")][l11lll_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ浉")][l11lll_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ浊")][l11lll_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ测")][l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ浌")][l11lll_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ浍")]
			for l1lll1111111l_l1_ in range(len(d)):
				group = d[l1lll1111111l_l1_][l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ济")][l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ浏")]
				for l1lll11ll11l1_l1_ in range(len(group)):
					render = group[l1lll11ll11l1_l1_][l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ浐")]
					if l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ浑") in list(render.keys()):
						link = render[l11lll_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ浒")][l11lll_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ浓")][l11lll_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ浔")][l11lll_l1_ (u"ࠪࡹࡷࡲࠧ浕")]
						link = link.replace(l11lll_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ浖"),l11lll_l1_ (u"ࠬࠬࠧ浗"))
						title = render[l11lll_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ浘")]
						title = title.replace(l11lll_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ浙"),l11lll_l1_ (u"ࠨࠩ浚"))
						if l11lll_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ浛") in title: continue
						if l11lll_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ浜") in title:
							title = l11lll_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ浝")+title
							l1lll1lll_l1_ = title
							l1lllll1ll_l1_ = link
						if l11lll_l1_ (u"ࠬะัห์หࠤาูศࠨ浞") in title: continue
						title = title.replace(l11lll_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ浟"),l11lll_l1_ (u"ࠧࠨ浠"))
						if l11lll_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ浡") in title: continue
						if l11lll_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ浢") in title:
							title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ浣")+title
							l1lll1lll_l1_ = title
							l1lllll1ll_l1_ = link
						if l11lll_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ浤") in title: continue
						l1lll111l111l_l1_.append(escapeUNICODE(title))
						l1lll111111l1_l1_.append(link)
		if not l1lll1lll_l1_: l1lll11l11ll1_l1_ = l11lll_l1_ (u"ࠬ࠭浥")
		else:
			l1lll111l111l_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ浦"),l1lll1lll_l1_]+l1lll111l111l_l1_
			l1lll111111l1_l1_ = [l11lll_l1_ (u"ࠧࠨ浧"),l1lllll1ll_l1_]+l1lll111111l1_l1_
			l1lll11ll1111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭浨"),l1lll111l111l_l1_)
			if l1lll11ll1111_l1_ == -1: return
			l1lll11l11ll1_l1_ = l1lll111111l1_l1_[l1lll11ll1111_l1_]
		if l1lll11l11ll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll11l11ll1_l1_
		elif l1lll1111llll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1lll1111llll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡓࡧࡰࡳࡻ࡫ࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠩ࠯ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬ࡯ࡳࡶࠣࡦࡾ࠭ࠬࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠦࠧࠨ浩")
	ITEMS(l11l1l1_l1_)
	return
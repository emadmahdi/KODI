# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㐎")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡌࡔࡅࡣࠬ㐏")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㐐"):l11lll_l1_ (u"ࠨࠩ㐑")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l1111l_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㐒"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ㐓"),l11lll_l1_ (u"ࠫࠬ㐔"),329,l11lll_l1_ (u"ࠬ࠭㐕"),l11lll_l1_ (u"࠭ࠧ㐖"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㐗"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㐘"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㐙"),l11lll_l1_ (u"ࠪࠫ㐚"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㐛"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㐜"),l11lll_l1_ (u"࠭ࠧ㐝"),headers,l11lll_l1_ (u"ࠧࠨ㐞"),l11lll_l1_ (u"ࠨࠩ㐟"),l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㐠"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮ࡰ࠯ࡳࡰࡺࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㐡"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㐢"),block,re.DOTALL)
	for link,title in items:
		if title==l11lll_l1_ (u"ࠬอไๆๅอฬฮࠦวๅ็ิส๏ฯࠧ㐣"): continue
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐤"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㐥")+l111ll_l1_+title,link,321)
	return html
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㐦"),l11lll_l1_ (u"ࠩࠪ㐧"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㐨"),url,l11lll_l1_ (u"ࠫࠬ㐩"),headers,l11lll_l1_ (u"ࠬ࠭㐪"),l11lll_l1_ (u"࠭ࠧ㐫"),l11lll_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ㐬"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ㐭"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡵࡪ࠵ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㐮"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㐯"),block,re.DOTALL)
	for link,l1llll_l1_,count,title in items:
		count = count.replace(l11lll_l1_ (u"ࠫ฾ีฯࠡࠩ㐰"),l11lll_l1_ (u"ࠬ࠭㐱")).replace(l11lll_l1_ (u"࠭ࠠࠨ㐲"),l11lll_l1_ (u"ࠧࠨ㐳"))
		link = link.replace(l11lll_l1_ (u"ࠨ࠱ࠪ㐴"),l11lll_l1_ (u"ࠩࠪ㐵"))
		l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠥࠫࠧ㐶"),l11lll_l1_ (u"ࠫࠬ㐷"))
		if l11lll_l1_ (u"ࠬ࠴ࡰࡩࡲࠪ㐸") not in link: link = l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㐹")+link
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㐺")+link
		l1llll_l1_ = l11ll1_l1_+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ㐻"))
		title = title+l11lll_l1_ (u"ࠩࠣࠬࠬ㐼")+count+l11lll_l1_ (u"ࠪ࠭ࠬ㐽")
		if l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㐾") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐿"),l111ll_l1_+title,link,321,l1llll_l1_)
		elif l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩ㑀") in link: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㑁"),l111ll_l1_+title,link,322,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ㑂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㑃"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㑄")+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑅"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ㑆")+title,link,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㑇"),url,l11lll_l1_ (u"ࠧࠨ㑈"),headers,l11lll_l1_ (u"ࠨࠩ㑉"),l11lll_l1_ (u"ࠩࠪ㑊"),l11lll_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㑋"))
	html = response.content
	#link = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㑌"),html,re.DOTALL)
	#if not link:
	link = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㑍"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]#+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ㑎")+l1l11111l_l1_()+l11lll_l1_ (u"ࠧࠧࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂࡺࡲࡶࡧࠪ㑏")
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㑐"))
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"่ࠩาฯอัࠨ㑑")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ㑒"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ㑓"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ㑔"),l11lll_l1_ (u"࠭ࠫࠨ㑕"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ㑖")+search
	l1111l_l1_(url)
	return
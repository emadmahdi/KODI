# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ⯷")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭⯸")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ฮฺ์๊โษอࠫ⯹"),l11lll_l1_ (u"ࠩสู๊อมࠡฯึหอ࠭⯺"),l11lll_l1_ (u"ࠪ฻้ฮวหࠢส่ื๎๑ศำࠪ⯻")]
#headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⯼"):l11lll_l1_ (u"ࠬ࠭⯽")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l1111l_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llllll_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯾"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⯿"),l11lll_l1_ (u"ࠨࠩⰀ"),399,l11lll_l1_ (u"ࠩࠪⰁ"),l11lll_l1_ (u"ࠪࠫⰂ"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⰃ"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⰄ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⰵ"),l11lll_l1_ (u"ࠧࠨⰆ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⰇ"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪⰈ"),l11lll_l1_ (u"ࠪࠫⰉ"),l11lll_l1_ (u"ࠫࠬⰊ"),l11lll_l1_ (u"ࠬ࠭Ⰻ"),l11lll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫⰌ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨⰍ"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰎ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⰏ")+l111ll_l1_+title,l11ll1_l1_,391,l11lll_l1_ (u"ࠪࠫⰐ"),l11lll_l1_ (u"ࠫࠬⰑ"),l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬⰒ")+str(seq))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱃ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⰔ")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ัฮฬืวหࠢ฼ุํอฦ๋หࠪⰕ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠩࠪⰖ"),l11lll_l1_ (u"ࠪࠫⰗ"),l11lll_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬⰘ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰙ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⰚ")+l111ll_l1_+l11lll_l1_ (u"ࠧฤ฻็ํࠥอไฤใ็ห๊ࠦสใ์ํ้ฬ๑ࠧⰛ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠨࠩⰜ"),l11lll_l1_ (u"ࠩࠪⰝ"),l11lll_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬⰞ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰟ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⰠ")+l111ll_l1_+l11lll_l1_ (u"࠭รฺๆ์ࠤฬ๊ๅิๆึ่ฬะࠠหไํ๎๊อ๋ࠨⰡ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠧࠨⰢ"),l11lll_l1_ (u"ࠨࠩⰣ"),l11lll_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫⰤ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰥ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ⱖ")+l111ll_l1_+l11lll_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪⰧ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧⰨ"),391,l11lll_l1_ (u"ࠧࠨⰩ"),l11lll_l1_ (u"ࠨࠩⰪ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫⰫ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰬ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ⱝ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬⰮ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳࠨⰯ"),391,l11lll_l1_ (u"ࠧࠨⰰ"),l11lll_l1_ (u"ࠨࠩⰱ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬⰲ"))
	block = l11lll_l1_ (u"ࠪࠫⰳ")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡩࡩࡵࡲࠣࠩⰴ"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⰵ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧⰶ"),l11lll_l1_ (u"ࠧࠨⰷ"),l11lll_l1_ (u"ࠨࠩⰸ"),l11lll_l1_ (u"ࠩࠪⰹ"),l11lll_l1_ (u"ࠪࠫⰺ"),l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩⰻ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡭ࡧࡤࡷࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫⰼ"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰽ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰾ"),l11lll_l1_ (u"ࠨࠩⰿ"),9999)
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨⱀ"),block,re.DOTALL)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠪห้ษูๅู๋้ࠣอ็ะหࠪⱁ"):
			if first:
				title = l11lll_l1_ (u"ࠫฬ๊วโๆส้ࠥ࠭ⱂ")+title
				first = False
			else: title = l11lll_l1_ (u"ࠬอไๆี็ื้อสࠡࠩⱃ")+title
		if title not in l1l1l1_l1_:
			if title==l11lll_l1_ (u"࠭รโๆส้ࠬⱄ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱅ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⱆ")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪⱇ"),391,l11lll_l1_ (u"ࠪࠫⱈ"),l11lll_l1_ (u"ࠫࠬⱉ"),l11lll_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪⱊ"))
			elif title==l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠧⱋ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱌ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⱍ")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶࠫⱎ"),391,l11lll_l1_ (u"ࠪࠫⱏ"),l11lll_l1_ (u"ࠫࠬⱐ"),l11lll_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪⱑ"))
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱒ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⱓ")+l111ll_l1_+title,link,391)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩⱔ"),l11lll_l1_ (u"ࠩࠪⱕ"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧⱖ"),url,l11lll_l1_ (u"ࠫࠬⱗ"),l11lll_l1_ (u"ࠬ࠭ⱘ"),l11lll_l1_ (u"࠭ࠧⱙ"),l11lll_l1_ (u"ࠧࠨⱚ"),l11lll_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨⱛ"))
	html = response.content
	if type in [l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫⱜ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭ⱝ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪⱞ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ⱟ"),l11lll_l1_ (u"࠭ࠧⱠ"),url,block)
	elif type==l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬⱡ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪⱢ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif type==l11lll_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡲࡵࡶࡪࡧࡶࠫⱣ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡱ࡫ࡦࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴࡳ࡫ࡪ࡬ࡹࠨⱤ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠫࠬⱥ"),l11lll_l1_ (u"ࠬ࠭ⱦ"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤⱧ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩⱨ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࠧⱩ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪⱪ"),l11lll_l1_ (u"ࠪࠫⱫ"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢⱬ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬⱭ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪⱮ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⱯ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧⱰ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭ⱱ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬⱲ"),block,re.DOTALL)
		l1111_l1_,l1l111l11_l1_,l1lll1ll_l1_ = zip(*l111l1_l1_)
		items = zip(l1l111l11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬⱳ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪⱴ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⱵ"),block,re.DOTALL)
	elif l11lll_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧⱶ") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪⱷ"),l11lll_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨⱸ"))
		html = html.replace(l11lll_l1_ (u"ࠪࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨⱹ"),l11lll_l1_ (u"ࠫࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡨࡲࡩࡄࠧⱺ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩⱻ"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==6:
			l111l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⱼ"),block,re.DOTALL)
			l1l111l11_l1_,l1lll1ll_l1_,l1111_l1_ = zip(*l111l1_l1_)
			items = zip(l1l111l11_l1_,l1111_l1_,l1lll1ll_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭ⱽ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧⱾ") in url:
				items = re.findall(l11lll_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⱿ"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭Ⲁ") in url:
				items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⲁ"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧⲂ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠫⲃ") in title: continue
		if l11lll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭Ⲅ") in title:
			title = re.findall(l11lll_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫⲅ"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭Ⲇ")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩⲇ")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬⲈ"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨⲉ") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲋ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫⲋ") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲌ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬⲍ") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲎ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪⲏ") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲐ"),l111ll_l1_+title,link,391,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⲑ"),l111ll_l1_+title,link,392,l1llll_l1_)
	if type not in [l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩⲒ"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫⲓ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬⲔ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬⲕ"),block,re.DOTALL)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲖ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫⲗ")+title,link,391,l11lll_l1_ (u"࠭ࠧⲘ"),l11lll_l1_ (u"ࠧࠨⲙ"),type)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩⲚ"),l11lll_l1_ (u"ࠩࠪⲛ"),l11lll_l1_ (u"ࠪࠫⲜ"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨⲝ"))
	url = url.replace(server,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⲞ"),url,l11lll_l1_ (u"࠭ࠧⲟ"),l11lll_l1_ (u"ࠧࠨⲠ"),l11lll_l1_ (u"ࠨࠩⲡ"),l11lll_l1_ (u"ࠩࠪⲢ"),l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬⲣ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩⲤ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧⲥ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨⲦ"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ⲧ"),l111ll_l1_+title,link,392,l1llll_l1_)
	return
def PLAY(url):
	html = l1ll1l1l11_l1_(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⲨ"),url,l11lll_l1_ (u"ࠩࠪⲩ"),l11lll_l1_ (u"ࠪࠫⲪ"),l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩⲫ"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⲬ"),url,l11lll_l1_ (u"࠭ࠧⲭ"),l11lll_l1_ (u"ࠧࠨⲮ"),l11lll_l1_ (u"ࠨࠩⲯ"),l11lll_l1_ (u"ࠩࠪⲰ"),l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨⲱ"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩⲲ"),l11lll_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬⲳ"))
		except: pass
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫⲴ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡟ࠧࢂ࡜ࠨ࡟ࠫࡷ࡭࡫ࡡࡥࡧࡵࢀࡵࡧࡧࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠬ࡟ࠧࢂ࡜ࠨ࡟ࠪⲵ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡴࡴࡹࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡷࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡸ࡬ࡨࡤࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⲶ"),block,re.DOTALL)
		for type,post,l1l1llll1l1_l1_,title in items:
			#link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵࡷ࠯ࡣ࡯ࡪࡦࡰࡥࡳࡶࡹ࠲ࡨࡵ࡭࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࡥࡩࡳࡩ࡯࠯ࡤ࡮ࡦࡾ࠮ࡱࡪࡳࠫⲷ")
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡥࡱࡲࡣࡵࡲࡡࡺࡧࡵࡣࡦࡰࡡࡹࠨࡳࡳࡸࡺ࠽ࠨⲸ")+post+l11lll_l1_ (u"ࠫࠫࡴࡵ࡮ࡧࡀࠫⲹ")+l1l1llll1l1_l1_+l11lll_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬⲺ")+type
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧⲻ")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨⲼ")
			l1111_l1_.append(link)
	# download links
	#WRITE_THIS(html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠩࠪ࡭ࡩࡃ࡛ࠣࠩࡠࡨࡴࡽ࡮࡭ࡱࡤࡨࡠࠨࠧ࡞ࠢࡦࡰࡦࡹࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࠨࠧ࡞ࡵࡥࡳࡽࡡࠢࠨ࡟ࠪࠫࠬⲽ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡ࠳࠰࠿ࡩࡴࡨࡪࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡ࠳࠰࠿࡜ࠤࠪࡡࡶࡻࡡ࡭࡫ࡷࡽࡠࠨࠧ࡞ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪⲾ"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫⲿ"),l11lll_l1_ (u"ࠫࠬⳀ"),str(items),str(block))
		for l1llll_l1_,link,l11l111l_l1_,l1l1llll1ll_l1_ in items:
			if l11lll_l1_ (u"ࠬࡃࠧⳁ") in l1llll_l1_:
				host = l1llll_l1_.split(l11lll_l1_ (u"࠭࠽ࠨⳂ"))[1]
				title = SERVER(host,l11lll_l1_ (u"ࠧࡩࡱࡶࡸࠬⳃ"))
			else: title = l11lll_l1_ (u"ࠨࠩⳄ")
			title = l1l1llll1ll_l1_+l11lll_l1_ (u"ࠩࠣࠫⳅ")+title
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫⳆ")+title+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬⳇ")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪⳈ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⳉ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨⳊ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩⳋ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫⳌ"),l11lll_l1_ (u"ࠪ࠯ࠬⳍ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩⳎ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬⳏ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ核")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ根")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠬ࠭栺")
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ栻"):l11lll_l1_ (u"ࠧࠨ格")}
l1lll1111l1l1_l1_ = 0
def MAIN(mode,url,text,type,l1l11l1_l1_,name,l11l_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1lll1111l111_l1_(url,name,l11l_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1111l_l1_(url,l1l11l1_l1_,text)
	elif mode==145: results = l1lll11ll111l_l1_(url,l1l11l1_l1_)
	elif mode==147: results = l1lll111lll1l_l1_()
	elif mode==148: results = l1lll111lllll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ栽"),l111ll_l1_+l11lll_l1_ (u"ࠩๅหห๋ษࠨ栾"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ栿"),144)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桀"),l111ll_l1_+l11lll_l1_ (u"ฺࠬฮึࠩ桁"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ桂"),144)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ桃"),l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ๆ฾࠭桄"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ桅"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ框"),l111ll_l1_+l11lll_l1_ (u"ࠫาูวษࠩ桇"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭案"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桉"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ฼หอ࠭桊"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ桋"),144)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ桌"),l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠩ桍"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ桎"),144)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ桏"),l111ll_l1_+l11lll_l1_ (u"࠭ๅฯฬสีฬะࠧ桐"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭桑"),144)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ桒"),l111ll_l1_+l11lll_l1_ (u"ࠩๅู๏ืษࠨ桓"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ桔"),144,l11lll_l1_ (u"ࠫࠬ桕"),l11lll_l1_ (u"ࠬ࠭桖"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ桗"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ桘"),l111ll_l1_+l11lll_l1_ (u"ࠨฬุๅา࠭桙"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ桚"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ桛"),l111ll_l1_+l11lll_l1_ (u"ࠫึฬ๊ิ์ฬࠫ桜"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠭桝"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桞"),l111ll_l1_+l11lll_l1_ (u"ࠧาษษะࠬ桟"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭桠"),144)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ桡"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ桢"),l11lll_l1_ (u"ࠫࠬ档"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ桤"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭桥"),l11lll_l1_ (u"ࠧࠨ桦"),149,l11lll_l1_ (u"ࠨࠩ桧"),l11lll_l1_ (u"ࠩࠪ桨"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ桩"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ桪"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ桫"),l11lll_l1_ (u"࠭ࠧ桬"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ桭"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ桮"),l11ll1_l1_+l11lll_l1_ (u"ࠩࠪ桯"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ桰"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ัศศฯอࠬ桱"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭桲"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桳"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆอูๆำࠧ桴"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ桵"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ桶"),l111ll_l1_+l11lll_l1_ (u"ࠪห้่ี๋ำฬࠫ桷"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ桸"),144,l11lll_l1_ (u"ࠬ࠭桹"),l11lll_l1_ (u"࠭ࠧ桺"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ桻"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ桼"),l111ll_l1_+l11lll_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ桽"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ桾"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桿"),l111ll_l1_+l11lll_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ梀"),l11lll_l1_ (u"࠭ࠧ梁"),290)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ梂"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ梃"),l11lll_l1_ (u"ࠩࠪ梄"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梅"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ梆"),l11lll_l1_ (u"ࠬ࠭梇"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭梈"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ梉"),l11lll_l1_ (u"ࠨࠩ梊"),148)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梋"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭梌"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ梍"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ梎"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ梏"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ梐"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ梑"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ梒"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ梓"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ梔"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ梕"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ梖"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ梗"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ梘"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ梙"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梚"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ梛"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ梜"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭條"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ梞"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ梟"),144)
	return
def l1lll1111l111_l1_(url,name,l11l_l1_):
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梠"),l111ll_l1_+l11lll_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ梡")+name,url,144,l11l_l1_)
	return
def l1lll111lll1l_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ梢"))
	return
def l1lll111lllll_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ梣"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ梤"),l11lll_l1_ (u"ࠧࠨ梥"),l11lll_l1_ (u"ࠨࠩ梦"),url)
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ梧")
	#items = re.findall(l11lll_l1_ (u"ࠪࡺࡂ࠮࠮ࠫࡁࠬࠨࠬ梨"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ梩")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ梪"))
	#return
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ梫")
	url = url.split(l11lll_l1_ (u"ࠧࠧࠩ梬"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1lll111l1l1l_l1_(cc,url,index):
	level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ梭"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ梮"),l11lll_l1_ (u"ࠪࠫ梯"),index,l11lll_l1_ (u"ࠫࡋࡏࡒࡔࡖࠪ械")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ梱")+url)
	l1lll11111l1l_l1_,l1lll11111lll_l1_ = [],[]
	# l11ll1lll11_l1_ l11l1l1lllll_l1_    should be the first item in the l1lll11111l1l_l1_ list
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ梲") in url: l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠࠦ梳"))
	# l11ll1lll11_l1_ search l1lll11ll1l11_l1_      should be the first item in the l1lll11111l1l_l1_ list
	if l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ梴") in url: l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣࠢ梵"))
	# main l1l11l1_l1_
	if level==l11lll_l1_ (u"ࠪ࠵ࠬ梶"): l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ梷"))
	# search results
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ梸"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣࠢ梹"))
	# l1lll11l1111l_l1_ l1lll111lll11_l1_ & main l1l11l1_l1_ l1lll111lll11_l1_ l1lll11ll1l11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬࡣࠢ梺"))
	# l1lll111l1ll1_l1_ menu
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࡡ࠳࡞࡝ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ梻"))
	l1lll11l111ll_l1_,dd,l1ll1llllllll_l1_ = l1lll111111ll_l1_(cc,l11lll_l1_ (u"ࠩࠪ梼"),l1lll11111l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ梽"),str(dd))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ梾"),l11lll_l1_ (u"ࠬ࠭梿"),l11lll_l1_ (u"࠭ࠧ检"),str(len(dd)))
	if level==l11lll_l1_ (u"ࠧ࠲ࠩ棁") and l1lll11l111ll_l1_:
		if len(dd)>1 and l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ棂") not in url:
			for zz in range(len(dd)):
				l1lll1111lll1_l1_ = str(zz)
				l1lll11111l1l_l1_ = []
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠࠨ棃")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ棄"))
				# l1lll11l1111l_l1_ l1lll111lll11_l1_
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛ࠣ棅")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ棆"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ棇")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠢ࡞ࠤ棈"))
				succeeded,item,l111ll1l_l1_ = l1lll111111ll_l1_(dd,l11lll_l1_ (u"ࠨࠩ棉"),l1lll11111l1l_l1_)
				if succeeded: l1lll11111lll_l1_.append([item,url,l11lll_l1_ (u"ࠩ࠵࠾࠿࠭棊")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ棋")])
				#l1l1l111111l_l1_ = l1lll11l1ll11_l1_(item,url,l11lll_l1_ (u"ࠫ࠷ࡀ࠺ࠨ棌")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ棍"))
				#if l1l1l111111l_l1_: l1ll11ll11_l1_ += 1
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token = l1lll11ll1l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棎"),l111ll_l1_+title,link,144,l11lll_l1_ (u"ࠧࠨ棏"),l11lll_l1_ (u"ࠨ࠴࠽࠾ࠬ棐")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ棑"))
				#l1ll11ll11_l1_ += 1
			# main l1l11l1_l1_ l1lll111lll11_l1_ l1lll11ll1l11_l1_
			l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ棒"))
			succeeded,item,l111ll1l_l1_ = l1lll111111ll_l1_(cc,l11lll_l1_ (u"ࠫࠬ棓"),l1lll11111l1l_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭棔"),str(cc))
			if succeeded and l1lll11111lll_l1_ and l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ棕") in list(item.keys()):
				link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ棖")
				l1lll11111lll_l1_.append([item,link,l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ棗")])
	return dd,l1lll11l111ll_l1_,l1lll11111lll_l1_,l1ll1llllllll_l1_
def l1lll11111111_l1_(cc,dd,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ棘"),l11lll_l1_ (u"ࠪࠫ棙"),index,l11lll_l1_ (u"ࠫࡘࡋࡃࡐࡐࡇࠫ棚")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ棛")+url)
	level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = index.split(l11lll_l1_ (u"࠭࠺࠻ࠩ棜"))
	l1lll11111l1l_l1_,l1lll111l1lll_l1_ = [],[]
	# search results
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ棝"))
	# main l1l11l1_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ棞")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ棟"))
	# l11lll1ll1ll_l1_ l1lll111lll11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ棠"))
	# l11ll1lll11_l1_ search & l11l1l1lllll_l1_ & l1lll11ll1l11_l1_
	if l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ棡") in url: l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ棢"))
	elif l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ棣") in url: l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ棤"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ棥")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ棦"))
	# l11lll1ll1ll_l1_ l11ll1l111_l1_ & l1lll111lll11_l1_ filters
	if l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ棧") in url or (l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ棨") in url and l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ棩") not in url):
		l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ棪")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ棫"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ棬")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ棭"))
	# l1lll11l1111l_l1_ search
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡࠢ森")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ棯"))
	# main l1l11l1_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ棰")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ棱"))
	# l11ll1lll11_l1_ l11l1l1lllll_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞ࠦ棲")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ棳"))
	l1lll11l11111_l1_,ee,l1lll111l11ll_l1_ = l1lll111111ll_l1_(dd,l11lll_l1_ (u"ࠩࠪ棴"),l1lll11111l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ棵"),str(ee))
	#DIALOG_OK()
	if level==l11lll_l1_ (u"ࠫ࠷࠭棶") and l1lll11l11111_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1lll11111l1l_l1_ = []
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ棷")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ棸"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ棹")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ棺"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ棻")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ棼"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ棽")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ棾"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ棿")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ椀"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ椁")+index2+l11lll_l1_ (u"ࠤࡠࠦ椂"))
				succeeded,item,l111ll1l_l1_ = l1lll111111ll_l1_(ee,l11lll_l1_ (u"ࠪࠫ椃"),l1lll11111l1l_l1_)
				if succeeded: l1lll111l1lll_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠸ࡀ࠺ࠨ椄")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ椅")+index2+l11lll_l1_ (u"࠭࠺࠻࠲ࠪ椆")])
				#l1l1l111111l_l1_ = l1lll11l1ll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽ࠫ椇")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ椈")+index2+l11lll_l1_ (u"ࠩ࠽࠾࠵࠭椉"))
				#if l1l1l111111l_l1_: l1l1l11ll1_l1_ += 1
				#LOG_THIS(l11lll_l1_ (u"ࠪࠫ椊"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ椋")+str(item))
				#l1l1l11ll1_l1_ += 1
				#item = ee[zz]
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token = l1lll11ll1l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椌"),l111ll_l1_+title,link,144,l1llll_l1_,l11lll_l1_ (u"࠭࠳࠻࠼ࠪ植")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ椎")+index2+l11lll_l1_ (u"ࠨ࠼࠽࠴ࠬ椏"))
			# search l1lll11ll1l11_l1_
			l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ椐"))
			# search l1lll11ll1l11_l1_
			l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞ࠤ椑"))
			succeeded,item,l111ll1l_l1_ = l1lll111111ll_l1_(dd,l11lll_l1_ (u"ࠫࠬ椒"),l1lll11111l1l_l1_)
			if succeeded and l1lll111l1lll_l1_ and l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ椓") in list(item.keys()):
				l1lll111l1lll_l1_.append([item,url,l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ椔")])
			#l1l1l111111l_l1_ = l1lll11l1ll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ椕"))
			#if l1l1l111111l_l1_: l1l1l11ll1_l1_ += 1
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ椖"),str(item))
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ椗"),link+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ椘")+token)
	return ee,l1lll11l11111_l1_,l1lll111l1lll_l1_,l1lll111l11ll_l1_
def l1lll1111l11l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ椙"),l11lll_l1_ (u"ࠬ࠭椚"),index,l11lll_l1_ (u"࠭ࡔࡉࡋࡕࡈࠬ椛")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ検")+url)
	level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ椝"))
	l1lll11111l1l_l1_,l1lll1111ll11_l1_ = [],[]
	# search results
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ椞")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ椟"))
	# l11ll1lll11_l1_ l11l1l1lllll_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ椠")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ椡"))
	# l1lll11l1l1ll_l1_ menu l1lll111lll11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ椢")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ椣"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ椤")+index2+l11lll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ椥"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡࠢ椦")+index2+l11lll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ椧"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ椨")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ椩"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ椪")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ椫"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ椬")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ椭"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ椮"))
	# l1lll11l1111l_l1_ l1lll11ll1ll1_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ椯"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ椰"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ椱")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ椲"))
	# main l1l11l1_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ椳")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ椴"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫ࠢ椵"))
	l1lll11l11l1l_l1_,ff,l1lll11ll11ll_l1_ = l1lll111111ll_l1_(ee,l11lll_l1_ (u"ࠬ࠭椶"),l1lll11111l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ椷"),str(ff))
	if level==l11lll_l1_ (u"ࠧ࠴ࠩ椸") and l1lll11l11l1l_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1lll111ll1ll_l1_ = str(zz)
				#DIALOG_OK()
				l1lll11111l1l_l1_ = []
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠧ椹")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ椺"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠢ椻")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ椼"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠤ椽")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ椾"))
				l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠦ椿")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ楀"))
				succeeded,item,l111ll1l_l1_ = l1lll111111ll_l1_(ff,l11lll_l1_ (u"ࠩࠪ楁"),l1lll11111l1l_l1_)
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token = l1lll11ll1l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ楂"),l111ll_l1_+link,link,143,l1llll_l1_)
				if succeeded: l1lll1111ll11_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠹ࡀ࠺ࠨ楃")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ楄")+index2+l11lll_l1_ (u"࠭࠺࠻ࠩ楅")+l1lll111ll1ll_l1_])
				#l1l1l111111l_l1_ = l1lll11l1ll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠵࠼࠽ࠫ楆")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ楇")+index2+l11lll_l1_ (u"ࠩ࠽࠾ࠬ楈")+l1lll111ll1ll_l1_)
				#if l1l1l111111l_l1_: l1l1l11lll_l1_ += 1
	return ff,l1lll11l11l1l_l1_,l1lll1111ll11_l1_,l1lll11ll11ll_l1_
def l1lll111111ll_l1_(l11llll1l111_l1_,l11lllll1l11_l1_,l1lll1111ll1l_l1_):
	cc,l11lllll1l11_l1_ = l11llll1l111_l1_,l11lllll1l11_l1_
	dd,l11lllll1l11_l1_ = l11llll1l111_l1_,l11lllll1l11_l1_
	ee,l11lllll1l11_l1_ = l11llll1l111_l1_,l11lllll1l11_l1_
	ff,l11lllll1l11_l1_ = l11llll1l111_l1_,l11lllll1l11_l1_
	item,render = l11llll1l111_l1_,l11lllll1l11_l1_
	count = len(l1lll1111ll1l_l1_)
	for l11ll111l1_l1_ in range(count):
		try:
			out = eval(l1lll1111ll1l_l1_[l11ll111l1_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"ࠪࠫ楉")
			return True,out,l11ll111l1_l1_+1
		except: pass
	return False,l11lll_l1_ (u"ࠫࠬ楊"),0
def l1111l_l1_(url,index=l11lll_l1_ (u"ࠬ࠭楋"),data=l11lll_l1_ (u"࠭ࠧ楌")):
	l1lll11111lll_l1_,l1lll111l1lll_l1_,l1lll1111ll11_l1_ = [],[],[]
	if l11lll_l1_ (u"ࠧ࠻࠼ࠪ楍") not in index: index = l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ楎")
	level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = index.split(l11lll_l1_ (u"ࠩ࠽࠾ࠬ楏"))
	if level==l11lll_l1_ (u"ࠪ࠸ࠬ楐"): level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭楑"),l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭楒"),l11lll_l1_ (u"࠭ࠧ楓"),index,url)
	data = data.replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ楔"),l11lll_l1_ (u"ࠨࠩ楕"))
	html,cc,l11ll1l11_l1_ = l1lll111ll111_l1_(url,data)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡰࡴࠣࠫ࠴ࡻࡳࡦࡴ࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠥࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡵࡷ࡯ࡧࡵ࠾ࠥࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠩࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࠫࡰࡹࡱࡩࡷࡔࡁࡎࡇ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠷࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱࠬ࠲࠶࠷࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠧࠨࠢ楖")
	index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭楗")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ楘")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ楙")+l1lll111ll1ll_l1_
	if level in [l11lll_l1_ (u"࠭࠱ࠨ楚"),l11lll_l1_ (u"ࠧ࠳ࠩ楛"),l11lll_l1_ (u"ࠨ࠵ࠪ楜")]:
		dd,l1lll11l111ll_l1_,l1lll11111lll_l1_,l1ll1llllllll_l1_ = l1lll111l1l1l_l1_(cc,url,index)
		if not l1lll11l111ll_l1_: return
		l1ll11ll11_l1_ = len(l1lll11111lll_l1_)
		if l1ll11ll11_l1_<2:
			if level==l11lll_l1_ (u"ࠩ࠴ࠫ楝"): level = l11lll_l1_ (u"ࠪ࠶ࠬ楞")
			l1lll11111lll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ楟"),l11lll_l1_ (u"ࠬ࠭楠"),index,l11lll_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠱࡝ࡰࠪ楡")+l11lll_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ楢")+str(l1ll1llllllll_l1_)+l11lll_l1_ (u"ࠨ࡞ࡱࠫ楣")+l11lll_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ楤")+str(len(dd))+l11lll_l1_ (u"ࠪࡠࡳ࠭楥")+l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ楦")+str(l1ll11ll11_l1_)+l11lll_l1_ (u"ࠬࡢ࡮ࠨ楧")+url)
	index = level+l11lll_l1_ (u"࠭࠺࠻ࠩ楨")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ楩")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ楪")+l1lll111ll1ll_l1_
	if level in [l11lll_l1_ (u"ࠩ࠵ࠫ楫"),l11lll_l1_ (u"ࠪ࠷ࠬ楬")]:
		ee,l1lll11l11111_l1_,l1lll111l1lll_l1_,l1lll111l11ll_l1_ = l1lll11111111_l1_(cc,dd,url,index)
		if not l1lll11l11111_l1_: return
		l1l1l11ll1_l1_ = len(l1lll111l1lll_l1_)
		if l1l1l11ll1_l1_<2:
			if level==l11lll_l1_ (u"ࠫ࠷࠭業"): level = l11lll_l1_ (u"ࠬ࠹ࠧ楮")
			l1lll111l1lll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ楯"),l11lll_l1_ (u"ࠧࠨ楰"),index,l11lll_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠴࡟ࡲࠬ楱")+l11lll_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭楲")+str(l1lll111l11ll_l1_)+l11lll_l1_ (u"ࠪࡠࡳ࠭楳")+l11lll_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭楴")+str(len(ee))+l11lll_l1_ (u"ࠬࡢ࡮ࠨ極")+l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ楶")+str(l1l1l11ll1_l1_)+l11lll_l1_ (u"ࠧ࡝ࡰࠪ楷")+url)
	index = level+l11lll_l1_ (u"ࠨ࠼࠽ࠫ楸")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ楹")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭楺")+l1lll111ll1ll_l1_
	if level in [l11lll_l1_ (u"ࠫ࠸࠭楻")]:
		ff,l1lll11l11l1l_l1_,l1lll1111ll11_l1_,l1lll11ll11ll_l1_ = l1lll1111l11l_l1_(cc,ee,url,index)
		if not l1lll11l11l1l_l1_: return
		l1l1l11lll_l1_ = len(l1lll1111ll11_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭楼"),l11lll_l1_ (u"࠭ࠧ楽"),index,l11lll_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠴࡞ࡱࠫ楾")+l11lll_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ楿")+str(l1lll11ll11ll_l1_)+l11lll_l1_ (u"ࠩ࡟ࡲࠬ榀")+l11lll_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ榁")+str(len(ff))+l11lll_l1_ (u"ࠫࡡࡴࠧ概")+l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭榃")+str(l1l1l11lll_l1_)+l11lll_l1_ (u"࠭࡜࡯ࠩ榄")+url)
	for item,url,index in l1lll11111lll_l1_+l1lll111l1lll_l1_+l1lll1111ll11_l1_:
		l1l1l111111l_l1_ = l1lll11l1ll11_l1_(item,url,index)
	return
def l1lll11l1ll11_l1_(item,url=l11lll_l1_ (u"ࠧࠨ榅"),index=l11lll_l1_ (u"ࠨࠩ榆")):
	if l11lll_l1_ (u"ࠩ࠽࠾ࠬ榇") in index: level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = index.split(l11lll_l1_ (u"ࠪ࠾࠿࠭榈"))
	else: level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭榉"),l11lll_l1_ (u"ࠬ࠶ࠧ榊"),l11lll_l1_ (u"࠭࠰ࠨ榋"),l11lll_l1_ (u"ࠧ࠱ࠩ榌")
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,l1lll11l1llll_l1_ = l1lll11ll1l1l_l1_(item)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ榍"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ榎"),link)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ榏"),link+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ榐")+title)
	# needed for l1lll11l1111l_l1_ l1lll11ll1ll1_l1_ next l1l11l1_l1_
	# and needed for l1lll11l1111l_l1_ l1lll11ll1ll1_l1_ sub-menu
	#if (l11lll_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭榑") in link or l11lll_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ榒") in link) and (l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ榓") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ榔") in link): link = url
	l1ll11llll11_l1_ = l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ榕") in link or l11lll_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭榖") in link or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ榗") in link
	l1ll11lll1l1_l1_ = l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ榘") in link or l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ榙") in link
	if l1ll11llll11_l1_ or l1ll11lll1l1_l1_: link = url
	l1ll11llll11_l1_ = l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ榚") not in link and l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ榛") not in link
	l1ll11lll1l1_l1_ = l11lll_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ榜") not in link  and l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭榝") not in link
	if index[0:5]==l11lll_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ榞") and l1ll11llll11_l1_ and l1ll11lll1l1_l1_: link = url
	if l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ榟") in url or l11lll_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ榠") in link:
		level,l1lll1111lll1_l1_,index2,l1lll111ll1ll_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ榡"),l11lll_l1_ (u"ࠨ࠲ࠪ榢"),l11lll_l1_ (u"ࠩ࠳ࠫ榣"),l11lll_l1_ (u"ࠪ࠴ࠬ榤")
		index = l11lll_l1_ (u"ࠫࠬ榥")
	l11ll1l11_l1_ = l11lll_l1_ (u"ࠬ࠭榦")
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ榧") in link or l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭榨") in link or l11lll_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭榩") in url:
		data = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ榪"))
		if data.count(l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ榫"))==4:
			l1lll11l11l11_l1_,key,l1lll111llll1_l1_,l1lll111l1111_l1_,token = data.split(l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ榬"))
			l11ll1l11_l1_ = l1lll11l11l11_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ榭")+key+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ榮")+l1lll111llll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ榯")+l1lll111l1111_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ榰")+l1lll11l1llll_l1_
			if l11lll_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ榱") in url and not link: link = url
			else: link = link+l11lll_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ榲")+key
	if not title:
		global l1lll1111l1l1_l1_
		l1lll1111l1l1_l1_ += 1
		title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ榳")+str(l1lll1111l1l1_l1_)
		index = l11lll_l1_ (u"ࠬ࠹ࠧ榴")+l11lll_l1_ (u"࠭࠺࠻ࠩ榵")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ榶")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ榷")+l1lll111ll1ll_l1_
	#if l11lll_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ榸") in url: link = url
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ榹"),l11lll_l1_ (u"ࠫࠬ榺"),title,index+l11lll_l1_ (u"ࠬࡢ࡮ࠨ榻")+link)
	#if not link: link = url
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ榼"),l11lll_l1_ (u"ࠧࠨ榽"),str(succeeded),title+l11lll_l1_ (u"ࠨࠢ࠽࠾࠿ࠦࠧ榾")+link)
	#if l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ榿") in url and index==l11lll_l1_ (u"ࠪ࠴ࠬ槀"):
	#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ槁"),l111ll_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ槂") in str(item): return False			# l1lll11l1l1l1_l1_ not items
	elif l11lll_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭槃") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ槄") in link: return False
	elif l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ槅") in list(item.keys()) or l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ槆") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭槇")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ槈")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ槉")+l1lll111ll1ll_l1_
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭槊"),l111ll_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠣࠫ構")+l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ槌"),link,144,l1llll_l1_,index,l11ll1l11_l1_)
	elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ槍") in link:
		title = l11lll_l1_ (u"ࠪ࠾࠿ࠦࠧ槎")+title
		index = l11lll_l1_ (u"ࠫ࠸࠭槏")+l11lll_l1_ (u"ࠬࡀ࠺ࠨ槐")+l1lll1111lll1_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ槑")+index2+l11lll_l1_ (u"ࠧ࠻࠼ࠪ槒")+l1lll111ll1ll_l1_
		url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ槓"),l11lll_l1_ (u"ࠩࠪ槔"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槕"),l111ll_l1_+title,url,145,l11lll_l1_ (u"ࠫࠬ槖"),index,l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ槗"))
	elif l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ様") in url and not link:
		index = l11lll_l1_ (u"ࠧ࠴ࠩ槙")+l11lll_l1_ (u"ࠨ࠼࠽ࠫ槚")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ槛")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭槜")+l1lll111ll1ll_l1_
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ槝")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ槞"),l111ll_l1_+title,url,144,l1llll_l1_,index,l11ll1l11_l1_)
	#elif l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ槟") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ槠") in link and url==l11ll1_l1_:
		title = l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬ槡")+title
		index = l11lll_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭槢")
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槣"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11ll1l11_l1_)
	elif not link and l11lll_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ槤") in str(item):
		title = l11lll_l1_ (u"ࠬࡀ࠺ࠡࠩ槥")+title
		index = l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ槦")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ槧"),l111ll_l1_+title,url,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ槨") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ槩"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ槪"),9999)
	#elif l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ槫") in link and l11lll_l1_ (u"ࠬࡨࡰ࠾ࠩ槬") not in link:
	#	title = l11lll_l1_ (u"࠭࠺࠻ࠢࠪ槭")+title
	#	index = l11lll_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ槮")
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ槯"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif l1111llllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ槰"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	elif l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ槱") in link:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ槲"),l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ槳")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ槴")+title,link,144,l1llll_l1_,index)
	#elif l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭槵") in link and l11lll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ槶") not in link and l11lll_l1_ (u"ࠩࡷࡁ࠵࠭槷") not in link:
	#	l1lll111ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ槸"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭槹")+l1lll111ll1l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ槺"),l111ll_l1_+l11lll_l1_ (u"࠭ࡌࡊࡕࡗࠫ槻")+count+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ槼")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ槽") in link:
		link = link.split(l11lll_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ槾"),1)[0]
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ槿"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	elif l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ樀") in link:
		if l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ樁") in link and count:
			l1lll111ll1l1_l1_ = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭樂"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ樃")+l1lll111ll1l1_l1_
			index = l11lll_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ樄")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ樅"),l111ll_l1_+l11lll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ樆")+count+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ樇")+title,link,144,l1llll_l1_,index)
		else:
			link = link.split(l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ樈"),1)[0]
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ樉"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	elif l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ樊") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ樋") in link or (l11lll_l1_ (u"ࠩ࠲ࡄࠬ樌") in link and link.count(l11lll_l1_ (u"ࠪ࠳ࠬ樍"))==3):
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ樎"),l111ll_l1_+l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ樏")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ樐")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ樑") in link:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樒"),l111ll_l1_+l11lll_l1_ (u"ࠩࡘࡗࡊࡘࠧ樓")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ樔")+title,link,144,l1llll_l1_,index)
	else:
		if not link: link = url
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ樕")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樖"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11ll1l11_l1_)
	return True
def l1lll11ll1l1l_l1_(item):
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token = False,l11lll_l1_ (u"࠭ࠧ樗"),l11lll_l1_ (u"ࠧࠨ樘"),l11lll_l1_ (u"ࠨࠩ標"),l11lll_l1_ (u"ࠩࠪ樚"),l11lll_l1_ (u"ࠪࠫ樛"),l11lll_l1_ (u"ࠫࠬ樜"),l11lll_l1_ (u"ࠬ࠭樝"),l11lll_l1_ (u"࠭ࠧ樞")
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ樟"),str(item))
	if not isinstance(item,dict): return succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token
	for l1lll11l1l111_l1_ in list(item.keys()):
		render = item[l1lll11l1l111_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ樠"),str(render))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ模"),str(render))
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ樢"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ樣"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡰ࡮ࡴࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ樤"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ樥"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ樦"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ樧"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ樨"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ権"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ横"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ樫"))
	# required for l11lll1ll1ll_l1_ l1lll111l1l11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ樬"))
	# l1lll11l1111l_l1_ l1lll111lll11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ樭"))
	succeeded,title,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ樮"),l11lll_l1_ (u"ࠩࠪ樯"),l11lll_l1_ (u"ࠪࠫ樰"),str(l111ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ樱"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ樲")+str(title))
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ樳"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ樴"))
	# l1lll11ll1l11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ樵"))
	# header feed
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ樶"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ樷"))
	# required for l11lll1ll1ll_l1_ l1llllll111_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ樸"))
	# l1lll11l1111l_l1_ l1lll111lll11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ樹"))
	succeeded,link,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ樺"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ樻"))
	# l1lll11l1111l_l1_ l1lll111lll11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ樼"))
	succeeded,l1llll_l1_,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ樽"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ樾")+l1llll_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ樿"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ橀"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ橁"))
	succeeded,count,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ橂"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ橃"))
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ橄"))
	# l1lll11l11lll_l1_ l1lll11l1111l_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࡖࡼࡴࡪ࠭࡝ࠣ橅"))
	# l1lll11l11lll_l1_ l1lll11l1111l_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡺࡹ࡭ࡧࠪࡡࠧ橆"))
	succeeded,l1l1l1111_l1_,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	#l1lll11111l1l_l1_ = []
	# l1lll11ll1l11_l1_
	#l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡰ࡮ࡩ࡫ࡕࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ橇"))
	# l11ll1lll11_l1_ l11l1l1lllll_l1_
	#l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡶࡵࡥࡨࡱࡩ࡯ࡩࡓࡥࡷࡧ࡭ࡴࠩࡠࠦ橈"))
	#succeeded,l1lll1111l1ll_l1_,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	l1lll11111l1l_l1_ = []
	# l11ll1lll11_l1_ l11l1l1lllll_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ橉"))
	# l1lll11ll1l11_l1_
	l1lll11111l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ橊"))
	succeeded,token,l111ll1l_l1_ = l1lll111111ll_l1_(item,render,l1lll11111l1l_l1_)
	if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ橋") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠪࠫ橌"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ橍")
	if l11lll_l1_ (u"๋ࠬศศึิࠫ橎") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ橏"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ橐")
	if l11lll_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ橑") in list(render.keys()):
		l1lll11l1ll1l_l1_ = str(render[l11lll_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ橒")])
		if l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ橓") in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠫࠩࡀࠠࠡࠩ橔")
		if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ橕") in l1lll11l1ll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ橖")
		if l11lll_l1_ (u"ࠧࡃࡷࡼࠫ橗") in l1lll11l1ll1l_l1_ or l11lll_l1_ (u"ࠨࡔࡨࡲࡹ࠭橘") in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ橙")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡸ๊ࠫฮวีำࠪ橚")) in l1lll11l1ll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ橛")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡺ࠭ิาษฤࠫ橜")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ橝")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡵࠨษึฮหาวาࠩ橞")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ機")
		if l1l11llllll1_l1_(l11lll_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ橠")) in l1lll11l1ll1l_l1_: l1lll111ll11l_l1_ = l11lll_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ橡")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ橢") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠬࡅࠧ橣"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ橤") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ橥")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll111ll11l_l1_: title = l1lll111ll11l_l1_+title
	#title = unescapeHTML(title)
	l1l1l1111_l1_ = l1l1l1111_l1_.replace(l11lll_l1_ (u"ࠨ࠮ࠪ橦"),l11lll_l1_ (u"ࠩࠪ橧"))
	count = count.replace(l11lll_l1_ (u"ࠪ࠰ࠬ橨"),l11lll_l1_ (u"ࠫࠬ橩"))
	count = re.findall(l11lll_l1_ (u"ࠬࡢࡤࠬࠩ橪"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"࠭ࠧ橫")
	return True,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1lll111ll11l_l1_,token
def l1lll111ll111_l1_(url,data=l11lll_l1_ (u"ࠧࠨ橬"),request=l11lll_l1_ (u"ࠨࠩ橭")):
	if request==l11lll_l1_ (u"ࠩࠪ橮"): request = l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ橯")
	#if l11lll_l1_ (u"ࠫࡤࡥࠧ橰") in l1lll11l111l1_l1_: l1lll11l111l1_l1_ = l11lll_l1_ (u"ࠬ࠭橱")
	#if l11lll_l1_ (u"࠭ࡳࡴ࠿ࠪ橲") in url: url = url.split(l11lll_l1_ (u"ࠧࡴࡵࡀࠫ橳"))[0]
	l111llll1l_l1_ = l1l11111l_l1_()
	#l111llll1l_l1_ = l11lll_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠰࠺࠰࠳࠲࠵࠴࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠡࡇࡧ࡫࠴࠷࠰࠺࠰࠳࠲࠶࠻࠱࠹࠰࠺࠴ࠬ橴")
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭橵"):l111llll1l_l1_,l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ橶"):l11lll_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ橷")}
	#l1l1ll1ll_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ橸"))
	if data.count(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ橹"))==4: l1lll11l11l11_l1_,key,l1lll111llll1_l1_,l1lll111l1111_l1_,token = data.split(l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ橺"))
	else: l1lll11l11l11_l1_,key,l1lll111llll1_l1_,l1lll111l1111_l1_,token = l11lll_l1_ (u"ࠨࠩ橻"),l11lll_l1_ (u"ࠩࠪ橼"),l11lll_l1_ (u"ࠪࠫ橽"),l11lll_l1_ (u"ࠫࠬ橾"),l11lll_l1_ (u"ࠬ࠭橿")
	l11ll1l11_l1_ = {l11lll_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ檀"):{l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ檁"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ檂"):l11lll_l1_ (u"ࠤࡤࡶࠧ檃"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ檄"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ檅"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ檆"):l1lll111llll1_l1_}}}
	if url==l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ檇") or l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ檈") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ檉")+l11lll_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ檊")+key
		l11ll1l11_l1_[l11lll_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ檋")] = l1lll11l11l11_l1_
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ檌"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ檍"))
	elif l11lll_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ檎") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ檏")+key
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭檐"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ檑"))
	elif l11lll_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ檒") in url and l1lll11l11l11_l1_:
		l11ll1l11_l1_[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ檓")] = token
		l11ll1l11_l1_[l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭檔")][l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭檕")][l11lll_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ檖")] = l1lll11l11l11_l1_
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭檗"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ檘"))
	elif l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ檙") in url and l1lll111l1111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ檚"):l11lll_l1_ (u"ࠬ࠷ࠧ檛"),l11lll_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ檜"):l1lll111llll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ檝"):l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ檞")+l1lll111l1111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭檟"),url,l11lll_l1_ (u"ࠪࠫ檠"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ檡"),l11lll_l1_ (u"ࠬ࠭檢"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ檣"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ檤"),url,l11lll_l1_ (u"ࠨࠩ檥"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ檦"),l11lll_l1_ (u"ࠪࠫ檧"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ檨"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ檩"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ檪"),html,re.DOTALL|re.I)
	if tmp: l1lll111llll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ檫"),html,re.DOTALL|re.I)
	if tmp: l1lll11l11l11_l1_ = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ檬"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭檭"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠥ࠾ࢀࠨࡴࡰ࡭ࡨࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ檮"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ檯"),l11lll_l1_ (u"ࠬ࠭檰"),l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ檱"),str(len(tmp)))
	#if tmp: l1lll11ll1l11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ檲") in list(cookies.keys()): l1lll111l1111_l1_ = cookies[l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭檳")]
	l11ll1l1l_l1_ = l1lll11l11l11_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭檴")+key+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ檵")+l1lll111llll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ檶")+l1lll111l1111_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ檷")+token
	if request==l11lll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭檸") and l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ檹") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ檺"),html,re.DOTALL)
		if not l111lll11l_l1_: l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ檻"),html,re.DOTALL)
		l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠪࡷࡹࡸࠧ檼"),l111lll11l_l1_[0])
	elif request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ檽") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ檾") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ檿"),html,re.DOTALL)
		l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ櫀"),l111lll11l_l1_[0])
	elif l11lll_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ櫁") not in html: l1lll11111ll1_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭櫂"),html)
	else: l1lll11111ll1_l1_ = l11lll_l1_ (u"ࠪࠫ櫃")
	if 0:
		cc = str(l1lll11111ll1_l1_)
		if kodi_version>18.99: cc = cc.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ櫄"))
		open(l11lll_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ櫅"),l11lll_l1_ (u"࠭ࡷࡣࠩ櫆")).write(cc)
		#open(l11lll_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ櫇"),l11lll_l1_ (u"ࠨࡹࠪ櫈")).write(html)
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ櫉"),l11ll1l1l_l1_)
	return html,l1lll11111ll1_l1_,l11ll1l1l_l1_
def l1lll11ll111l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ櫊"),l11lll_l1_ (u"ࠫ࠰࠭櫋"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭櫌")+search
	l1111l_l1_(l11l11l_l1_,index)
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ櫍")+l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ櫎")+l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ櫏")+l11lll_l1_ (u"ࠩࡢࠫ櫐")+search
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ櫑"),l11lll_l1_ (u"ࠫࠬ櫒"),l11lll_l1_ (u"ࠬ࠭櫓"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ櫔"),l11lll_l1_ (u"ࠧࠨ櫕"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ櫖"),l11lll_l1_ (u"ࠩ࠮ࠫ櫗"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ櫘")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ櫙") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ櫚")
		elif l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ櫛") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ櫜")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭櫝") in options: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ櫞")
		else: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠪࠫ櫟")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111l11l1_l1_
	else:
		l1lll111l111l_l1_,l1lll111111l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠫࠬ櫠")
		l1lll11111l11_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ櫡"),l11lll_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ櫢"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ櫣"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ櫤"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭櫥")]
		l1lll11l1l11l_l1_ = [l11lll_l1_ (u"ࠪࠫ櫦"),l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ櫧"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ櫨"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ櫩"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭櫪")]
		l1lll11l1lll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ櫫"),l1lll11111l11_l1_)
		if l1lll11l1lll1_l1_ == -1: return
		l1lll1111llll_l1_ = l1lll11l1l11l_l1_[l1lll11l1lll1_l1_]
		html,c,data = l1lll111ll111_l1_(l11l11l_l1_+l1lll1111llll_l1_)
		if c:
			try:
				d = c[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ櫬")][l11lll_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭櫭")][l11lll_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭櫮")][l11lll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ櫯")][l11lll_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ櫰")][l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫱")][l11lll_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ櫲")]
				for l1lll1111111l_l1_ in range(len(d)):
					group = d[l1lll1111111l_l1_][l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ櫳")][l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ櫴")]
					for l1lll11ll11l1_l1_ in range(len(group)):
						render = group[l1lll11ll11l1_l1_][l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ櫵")]
						if l11lll_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ櫶") in list(render.keys()):
							link = render[l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ櫷")][l11lll_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ櫸")][l11lll_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭櫹")][l11lll_l1_ (u"ࠩࡸࡶࡱ࠭櫺")]
							link = link.replace(l11lll_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ櫻"),l11lll_l1_ (u"ࠫࠫ࠭櫼"))
							title = render[l11lll_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭櫽")]
							title = title.replace(l11lll_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ櫾"),l11lll_l1_ (u"ࠧࠨ櫿"))
							if l11lll_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ欀") in title: continue
							if l11lll_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ欁") in title:
								title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ欂")+title
								l1lll1lll_l1_ = title
								l1lllll1ll_l1_ = link
							if l11lll_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ欃") in title: continue
							title = title.replace(l11lll_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ欄"),l11lll_l1_ (u"࠭ࠧ欅"))
							if l11lll_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ欆") in title: continue
							if l11lll_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ欇") in title:
								title = l11lll_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ欈")+title
								l1lll1lll_l1_ = title
								l1lllll1ll_l1_ = link
							if l11lll_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ欉") in title: continue
							l1lll111l111l_l1_.append(escapeUNICODE(title))
							l1lll111111l1_l1_.append(link)
			except: pass
		if not l1lll1lll_l1_: l1lll11l11ll1_l1_ = l11lll_l1_ (u"ࠫࠬ權")
		else:
			l1lll111l111l_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ欋"),l1lll1lll_l1_]+l1lll111l111l_l1_
			l1lll111111l1_l1_ = [l11lll_l1_ (u"࠭ࠧ欌"),l1lllll1ll_l1_]+l1lll111111l1_l1_
			l1lll11ll1111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ欍"),l1lll111l111l_l1_)
			if l1lll11ll1111_l1_ == -1: return
			l1lll11l11ll1_l1_ = l1lll111111l1_l1_[l1lll11ll1111_l1_]
		if l1lll11l11ll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll11l11ll1_l1_
		elif l1lll1111llll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1lll1111llll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ欎")
	#DIALOG_OK()
	l1111l_l1_(l11l1l1_l1_)
	return
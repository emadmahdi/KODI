# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨ⼘")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡌࡒࡓࡠࠩ⼙")
def MAIN(mode,url,text,l1l11l1_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1l1ll11111_l1_(text)
	elif mode==542: results = l1l1l1l1l11_l1_(text,url,l1l11l1_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼚"),l11lll_l1_ (u"ࠬฮอฬࠢฯำ๏ีࠧ⼛"),l11lll_l1_ (u"࠭ࠧ⼜"),549)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⼝"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๆะี๊ฮࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⼞"),l11lll_l1_ (u"ࠩࠪ⼟"),9999)
	l1l1l1ll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⼠"),l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⼡"))
	if l1l1l1ll1ll_l1_:
		l1l1l1ll1ll_l1_ = l1l1l1ll1ll_l1_[l11lll_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭⼢")]
		for search in reversed(l1l1l1ll1ll_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼣"),search,l11lll_l1_ (u"ࠧࠨ⼤"),549,l11lll_l1_ (u"ࠨࠩ⼥"),l11lll_l1_ (u"ࠩࠪ⼦"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l111l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1ll1l1111l_l1_ = search.replace(l111ll_l1_,l11lll_l1_ (u"ࠪࠫ⼧"))
	l1l1l11ll11_l1_(l1ll1l1111l_l1_)
	#l1l1l111lll_l1_ = search+options+l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⼨")
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⼩"),l11lll_l1_ (u"ู࠭ๆๆࠣฬาัࠠอ็ส฽๏ࠦ࠭ࠡࠩ⼪")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⼫"),542,l11lll_l1_ (u"ࠨࠩ⼬"),l11lll_l1_ (u"ࠩࠪ⼭"),l1ll1l1111l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⼮"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⼯"),l11lll_l1_ (u"ࠬ࠭⼰"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼱"),l11lll_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥแึๆฬࠤ࠲ࠦࠧ⼲")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⼳"),542,l11lll_l1_ (u"ࠩࠪ⼴"),l11lll_l1_ (u"ࠪࠫ⼵"),l1ll1l1111l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼶"),l11lll_l1_ (u"ࠬ์สศศฯࠤฬ๊ศฮอ้ࠣ็ูๅสࠢ࠰ࠤࠬ⼷")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ⼸"),542,l11lll_l1_ (u"ࠧࠨ⼹"),l11lll_l1_ (u"ࠨࠩ⼺"),l1ll1l1111l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼻"),l11lll_l1_ (u"ࠪฬาัࠠๆ่ไีิࠦ࠭ࠡࠩ⼼")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬ⼽"),541,l11lll_l1_ (u"ࠬ࠭⼾"),l11lll_l1_ (u"࠭ࠧ⼿"),l1ll1l1111l_l1_)
	return
def l1l1l11ll11_l1_(l1l1ll11l1l_l1_):
	l1l1ll11lll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⽀"),l11lll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⽁"),l1l1ll11l1l_l1_)
	l1l1ll11ll1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⽂"),l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⽃"),l111ll_l1_+l1l1ll11l1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⽄"),l1l1ll11l1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⽅"),l111ll_l1_+l1l1ll11l1l_l1_)
	old_value = l1l1ll11lll_l1_+l1l1ll11ll1_l1_
	if old_value: l1l1ll11l1l_l1_ = l111ll_l1_+l1l1ll11l1l_l1_
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⽆"),l1l1ll11l1l_l1_,old_value,VERYLONG_CACHE)
	return
def l1l1l1l1111_l1_():
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࠨ⽇"),l11lll_l1_ (u"ࠨࠩ⽈"),l11lll_l1_ (u"ࠩࠪ⽉"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⽊"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ⽋"))
	if l1ll11l111_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⽌"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⽍"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭⽎"))
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⽏"),l11lll_l1_ (u"ࠩࠪ⽐"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⽑"),l11lll_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ⽒"))
	return
def l1l1l1l1l11_l1_(l1l1l1l111l_l1_,action,l1l1l1l1ll1_l1_=l11lll_l1_ (u"ࠬ࠭⽓")):
	l1l1l1l1lll_l1_,l1l1l1ll111_l1_,l1l1l1lll1l_l1_,l1l1l111l1l_l1_,l1l1l11l111_l1_,l1l1l1lll11_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⽔"):
		if action==l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⽕"): l1l1l1lll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⽖"),l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⽗"),l111ll_l1_+l1l1l1l111l_l1_)
		elif action==l11lll_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⽘"): l1l1l1lll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⽙"),l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫ⽚"),l1l1l1l111l_l1_)
		elif action==l11lll_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬ⽛"): l1l1l1lll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⽜"),l11lll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⽝"),(l1l1l1l1ll1_l1_,l1l1l1l111l_l1_))
	if not l1l1l1lll1l_l1_:
		l1l1ll1111l_l1_ = l11lll_l1_ (u"๊ࠩิฬࠦวๅสะฯࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮࡝ࡰࠪ⽞")
		l1l1ll111l1_l1_ = l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็ࠢส่อำหࠡใํࠤัฺ๋๊ࠢส่๊๎วใ฻ࠣ฽๋ࠦ࡜࡯ࠢࠥ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦࠧ⽟")+l1l1l1l111l_l1_+l11lll_l1_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࠡ࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่อำหࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯ࠭⽠")
		if action==l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫ⽡"): message = l1l1ll111l1_l1_
		else: message = l1l1ll1111l_l1_+l1l1ll111l1_l1_
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ⽢"),l11lll_l1_ (u"ࠧࠨ⽣"),l11lll_l1_ (u"ࠨࠩ⽤"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⽥"),message)
		if l1ll11l111_l1_!=1: return
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⽦"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ⽧")+l1l1l1l111l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ⽨"))
		#global menuItemsLIST
		import threading
		#l1l1l1ll1l1_l1_ = [l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ⽩"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ⽪"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ⽫")]
		l1l1ll1ll11_l1_ = 1
		for l1l1l1l1ll1_l1_ in l1l1l1ll1l1_l1_:
			l1l1l111l1l_l1_[l1l1l1l1ll1_l1_] = []
			options = l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⽬")
			if l11lll_l1_ (u"ࠪ࠱ࠬ⽭") in l1l1l1l1ll1_l1_: options = options+l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⽮")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠬࡥࠧ⽯")
			l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_ = l1l1l11l11l_l1_(l1l1l1l1ll1_l1_)
			if l1l1ll1ll11_l1_:
				time.sleep(0.5)
				threads[l1l1l1l1ll1_l1_] = threading.Thread(target=l1l1l1l1l1l_l1_,args=(l1l1l1l111l_l1_+options,))
				threads[l1l1l1l1ll1_l1_].start()
			else: l1l1l1l1l1l_l1_(l1l1l1l111l_l1_+options)
			DIALOG_NOTIFICATION(TRANSLATE(l1l1l1l1ll1_l1_),l11lll_l1_ (u"࠭ࠧ⽰"),time=1000)
		if l1l1ll1ll11_l1_:
			time.sleep(2)
			for l1l1l1l1ll1_l1_ in l1l1l1ll1l1_l1_:
				threads[l1l1l1l1ll1_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⽱"),l11lll_l1_ (u"ࠨࠩ⽲"),l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠡࡨࡲࡹࡳࡪࡥࡥ࠼ࠪ⽳"),str(len(menuItemsLIST)))
		for l1l1l1l1ll1_l1_ in l1l1l1ll1l1_l1_:
			l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_ = l1l1l11l11l_l1_(l1l1l1l1ll1_l1_)
			for l1l1l1l11ll_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = l1l1l1l11ll_l1_
				if l1l1ll1l1ll_l1_ in name:
					if l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࠩ⽴") in l1l1l1l1ll1_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⽵")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⽶")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⽷")]: continue
						if l11lll_l1_ (u"ࠧึใะอࠬ⽸") not in name:
							if   type==l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⽹"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⽺")
							elif type==l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⽻"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⽼")
							elif type==l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⽽"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⽾")
						else:
							if   l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ⽿") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⾀")
							elif l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ⾁") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⾂")
							elif l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ⾃") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ⾄")
					elif l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࠫ⾅") in l1l1l1l1ll1_l1_ and 729>=mode>=710:
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⾆")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⾇")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⾈")]: continue
						if l11lll_l1_ (u"ูࠪๆำษࠨ⾉") not in name:
							if   type==l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⾊"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ⾋")
							elif type==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⾌"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ⾍")
							elif type==l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⾎"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⾏")
						else:
							if   l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ⾐") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭⾑")
							elif l11lll_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ⾒") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⾓")
							elif l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ⾔") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ⾕")
					elif l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࠫ⾖") in l1l1l1l1ll1_l1_ and 149>=mode>=140:
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⾗")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⾘")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⾙")]: continue
						if l11lll_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⾚") in name or l11lll_l1_ (u"ࠧ࠻࠼ࠣࠫ⾛") in name:
							continue
							#if   l11l_l1_==l11lll_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ⾜"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⾝")
							#elif l11l_l1_==l11lll_l1_ (u"ࠪࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭⾞"): l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⾟")
							#else: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⾠")
						else:
							if   mode==144 and l11lll_l1_ (u"࠭ࡕࡔࡇࡕࠫ⾡") in name: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⾢")
							elif mode==144 and l11lll_l1_ (u"ࠨࡅࡋࡒࡑ࠭⾣") in name: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⾤")
							elif mode==144 and l11lll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ⾥") in name: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⾦")
							elif mode==143: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭⾧")
							else: continue
					elif l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࠬ⾨") in l1l1l1l1ll1_l1_ and 419>=mode>=400:
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⾩")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⾪")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⾫")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ⾬")]: continue
						if   mode in [401,405]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⾭")
						elif mode in [402,406]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⾮")
						elif mode in [403,404]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ⾯")
						elif mode in [412,413]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ⾰")
					elif l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࠨ⾱") in l1l1l1l1ll1_l1_ and 39>=mode>=30:
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ⾲")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⾳")]: continue
						if   mode in [32,39]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⾴")
						elif mode in [33,39]: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⾵")
					elif l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࠭⾶") in l1l1l1l1ll1_l1_ and 29>=mode>=20:
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⾷")]: continue
						if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⾸")]: continue
						if   l11lll_l1_ (u"ࠩ࠲ࡥࡷ࠴ࠧ⾹") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⾺")
						elif l11lll_l1_ (u"ࠫ࠴࡫࡮࠯ࠩ⾻") in url: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⾼")
					#elif l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࠪ⾽") in l1l1l1l1ll1_l1_ and 319>=mode>=310:
					#	if l1l1l1l11ll_l1_ in l1l1l111l1l_l1_[l1l1l1l1ll1_l1_]: continue
					#	if mode==312: l1l1l1l1ll1_l1_ = l1l1l11lll1_l1_+l11lll_l1_ (u"ࠧ࠮ࡃࡘࡈࡎࡕࡓࠨ⾾")
					#	elif l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࠳ࠧ⾿") in url: l1l1l1l1ll1_l1_ = l1l1l11lll1_l1_+l11lll_l1_ (u"ࠩ࠰ࡅࡑࡈࡕࡎࡕࠪ⿀")
					#	else: l1l1l1l1ll1_l1_ = l1l1l11lll1_l1_+l11lll_l1_ (u"ࠪ࠱ࡕࡋࡒࡔࡑࡑࡗࠬ⿁")
					l1l1l111l1l_l1_[l1l1l1l1ll1_l1_].append(l1l1l1l11ll_l1_)
		menuItemsLIST[:] = []
		for l1l1l1l1ll1_l1_ in list(l1l1l111l1l_l1_.keys()):
			l1l1l11l111_l1_[l1l1l1l1ll1_l1_] = []
			l1l1l1lll11_l1_[l1l1l1l1ll1_l1_] = []
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in l1l1l111l1l_l1_[l1l1l1l1ll1_l1_]:
				l1l1l1l11ll_l1_ = (type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_)
				if l11lll_l1_ (u"ฺࠫ็อสࠩ⿂") in name and type==l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿃"): l1l1l1lll11_l1_[l1l1l1l1ll1_l1_].append(l1l1l1l11ll_l1_)
				else: l1l1l11l111_l1_[l1l1l1l1ll1_l1_].append(l1l1l1l11ll_l1_)
		l1l1l1lllll_l1_ = [(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⿄"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⿅"),l11lll_l1_ (u"ࠨࠩ⿆"),157,l11lll_l1_ (u"ࠩࠪ⿇"),l11lll_l1_ (u"ࠪࠫ⿈"),l11lll_l1_ (u"ࠫࠬ⿉"),l11lll_l1_ (u"ࠬ࠭⿊"),l11lll_l1_ (u"࠭ࠧ⿋"))]
		for l1l1l1l1ll1_l1_ in l1l1l1ll11l_l1_:
			if l1l1l1l1ll1_l1_==l1l1l11llll_l1_[0]: l1l1l1lllll_l1_ = [(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⿌"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⿍"),l11lll_l1_ (u"ࠩࠪ⿎"),157,l11lll_l1_ (u"ࠪࠫ⿏"),l11lll_l1_ (u"ࠫࠬ⿐"),l11lll_l1_ (u"ࠬ࠭⿑"),l11lll_l1_ (u"࠭ࠧ⿒"),l11lll_l1_ (u"ࠧࠨ⿓"))]
			elif l1l1l1l1ll1_l1_==l1l1ll1l111_l1_[0]: l1l1l1lllll_l1_ = [(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⿔"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⿕"),l11lll_l1_ (u"ࠪࠫ⿖"),157,l11lll_l1_ (u"ࠫࠬ⿗"),l11lll_l1_ (u"ࠬ࠭⿘"),l11lll_l1_ (u"࠭ࠧ⿙"),l11lll_l1_ (u"ࠧࠨ⿚"),l11lll_l1_ (u"ࠨࠩ⿛"))]
			elif l1l1l1l1ll1_l1_==l1l1l111ll1_l1_[0]: l1l1l1lllll_l1_ = [(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⿜"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⿝"),l11lll_l1_ (u"ࠫࠬ⿞"),157,l11lll_l1_ (u"ࠬ࠭⿟"),l11lll_l1_ (u"࠭ࠧ⿠"),l11lll_l1_ (u"ࠧࠨ⿡"),l11lll_l1_ (u"ࠨࠩ⿢"),l11lll_l1_ (u"ࠩࠪ⿣"))]
			if l1l1l1l1ll1_l1_ not in l1l1l11l111_l1_.keys(): continue
			if l1l1l11l111_l1_[l1l1l1l1ll1_l1_]:
				l1l1l11l1ll_l1_ = TRANSLATE(l1l1l1l1ll1_l1_)
				l1l1l1l11l1_l1_ = [(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⿤"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭⿥")+l1l1l11l1ll_l1_+l11lll_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⿦"),l11lll_l1_ (u"࠭ࠧ⿧"),9999,l11lll_l1_ (u"ࠧࠨ⿨"),l11lll_l1_ (u"ࠨࠩ⿩"),l11lll_l1_ (u"ࠩࠪ⿪"),l11lll_l1_ (u"ࠪࠫ⿫"),l11lll_l1_ (u"ࠫࠬ⿬"))]
				if 0:
					l1l1ll1l11l_l1_ = l1l1l1l111l_l1_+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ⿭")+l11lll_l1_ (u"࠭ศฮอࠪ⿮")+l11lll_l1_ (u"ࠧࠡࠩ⿯")+l1l1l11l1ll_l1_
				else:
					l1l1ll1l11l_l1_ = l11lll_l1_ (u"ࠨสะฯࠬ⿰")+l11lll_l1_ (u"ࠩࠣࠫ⿱")+l1l1l11l1ll_l1_+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ⿲")+l1l1l1l111l_l1_
				if len(l1l1l11l111_l1_[l1l1l1l1ll1_l1_])<8: l1l1l1llll1_l1_ = []
				else:
					l1l1ll1l1l1_l1_ = l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ⿳")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⿴")
					l1l1l1llll1_l1_ = [(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿵"),l111ll_l1_+l1l1ll1l1l1_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⿶"),542,l11lll_l1_ (u"ࠨࠩ⿷"),l1l1l1l1ll1_l1_,l1l1l1l111l_l1_,l11lll_l1_ (u"ࠩࠪ⿸"),l11lll_l1_ (u"ࠪࠫ⿹"))]
				l1l1ll111ll_l1_ = l1l1l11l111_l1_[l1l1l1l1ll1_l1_]+l1l1l1lll11_l1_[l1l1l1l1ll1_l1_]
				l1l1l1ll111_l1_ += l1l1l1lllll_l1_+l1l1l1l11l1_l1_+l1l1ll111ll_l1_[:7]+l1l1l1llll1_l1_
				l1l1l11l1l1_l1_ = [(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿺"),l111ll_l1_+l1l1ll1l11l_l1_,l11lll_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫ⿻"),542,l11lll_l1_ (u"࠭ࠧ⿼"),l1l1l1l1ll1_l1_,l1l1l1l111l_l1_,l11lll_l1_ (u"ࠧࠨ⿽"),l11lll_l1_ (u"ࠨࠩ⿾"))]
				l1l1l1l1lll_l1_ += l1l1l1lllll_l1_+l1l1l11l1l1_l1_
				l1l1l1lllll_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨ⿿"),(l1l1l1l1ll1_l1_,l1l1l1l111l_l1_),l1l1ll111ll_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩ　"),l1l1l1l111l_l1_,l1l1l1ll111_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ、"),l1l1l1l111l_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ。"),l111ll_l1_+l1l1l1l111l_l1_,l1l1l1l1lll_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ〃"),l11lll_l1_ (u"ࠧࠨ〄"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ々"),l11lll_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬ〆"))
		if action==l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ〇") and l1l1l1l1lll_l1_: l1l1l1lll1l_l1_ = l1l1l1l1lll_l1_
		else: l1l1l1lll1l_l1_ = l1l1l1ll111_l1_
	if action!=l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪ〈"):
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ in l1l1l1lll1l_l1_:
			if action in [l11lll_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫ〉"),l11lll_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬ《")] and l11lll_l1_ (u"ࠧึใะอࠬ》") in name and type==l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ「"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_)
	return
def l1l1ll11111_l1_(l1l1l1l111l_l1_=l11lll_l1_ (u"ࠩࠪ」")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l111l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ『"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ』")+search+l11lll_l1_ (u"ࠬࠦ࡝ࠨ【"))
	l111l1l_l1_ = search+options
	if 0:
		l1l1ll11l11_l1_,l1ll1l1111l_l1_ = search+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪ】"),l11lll_l1_ (u"ࠧࠨ〒")
	else:
		l1l1ll11l11_l1_,l1ll1l1111l_l1_ = l11lll_l1_ (u"ࠨࠩ〓"),l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭〔")+search
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ〕"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〖"),l11lll_l1_ (u"ࠬ࠭〗"),157)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭〘"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭〙")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯࠥࡓ࠳ࡖࠩ〚")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪ〛"),719,l11lll_l1_ (u"ࠪࠫ〜"),l11lll_l1_ (u"ࠫࠬ〝"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〞"),l11lll_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ〟")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤࡎࡖࡔࡗࠩ〠")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩ〡"),239,l11lll_l1_ (u"ࠩࠪ〢"),l11lll_l1_ (u"ࠪࠫ〣"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ〤"),l11lll_l1_ (u"ࠬࡥࡂࡌࡔࡢࠫ〥")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสๆีฬ࠭〦")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨ〧"),379,l11lll_l1_ (u"ࠨࠩ〨"),l11lll_l1_ (u"ࠩࠪ〩"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ〪ࠪ"),l11lll_l1_ (u"ࠫࡤࡖࡎࡕࡡ〫ࠪ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯ࠭〬")+l1ll1l1111l_l1_,l11lll_l1_ (u"〭࠭ࠧ"),39,l11lll_l1_ (u"ࠧࠨ〮"),l11lll_l1_ (u"ࠨ〯ࠩ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〰"),l11lll_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ〱")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫ〲"),l11lll_l1_ (u"ࠬ࠭〳"),39,l11lll_l1_ (u"࠭ࠧ〴"),l11lll_l1_ (u"ࠧࠨ〵"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࡤ࠭〶"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〷"),l11lll_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ〸")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭〹"),l11lll_l1_ (u"ࠬ࠭〺"),39,l11lll_l1_ (u"࠭ࠧ〻"),l11lll_l1_ (u"ࠧࠨ〼"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭〽"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〾"),l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ〿")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ぀"),l11lll_l1_ (u"ࠬ࠭ぁ"),149,l11lll_l1_ (u"࠭ࠧあ"),l11lll_l1_ (u"ࠧࠨぃ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨい"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩぅ"),l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩう")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬぇ"),l11lll_l1_ (u"ࠬ࠭え"),149,l11lll_l1_ (u"࠭ࠧぉ"),l11lll_l1_ (u"ࠧࠨお"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫか"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩが"),l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩき")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬぎ"),l11lll_l1_ (u"ࠬ࠭く"),149,l11lll_l1_ (u"࠭ࠧぐ"),l11lll_l1_ (u"ࠧࠨけ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪげ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩこ"),l11lll_l1_ (u"ࠪࡣࡐࡒࡁࡠࠩご")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨさ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭ざ"),19,l11lll_l1_ (u"࠭ࠧし"),l11lll_l1_ (u"ࠧࠨじ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨす"),l11lll_l1_ (u"ࠩࡢࡅࡗ࡚࡟ࠨず")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩせ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬぜ"),739,l11lll_l1_ (u"ࠬ࠭そ"),l11lll_l1_ (u"࠭ࠧぞ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧた"),l11lll_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧだ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩち")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠪࠫぢ"),329,l11lll_l1_ (u"ࠫࠬっ"),l11lll_l1_ (u"ࠬ࠭つ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭づ"),l11lll_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭て")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧで")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪと"),579,l11lll_l1_ (u"ࠪࠫど"),l11lll_l1_ (u"ࠫࠬな"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬに"),l11lll_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬぬ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠬね")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩの"),129,l11lll_l1_ (u"ࠩࠪは"),l11lll_l1_ (u"ࠪࠫば"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫぱ"),l11lll_l1_ (u"ࠬࡥࡅࡃ࠳ࡢࠫひ")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭び")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨぴ"),779,l11lll_l1_ (u"ࠨࠩふ"),l11lll_l1_ (u"ࠩࠪぶ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪぷ"),l11lll_l1_ (u"ࠫࡤࡋࡂ࠳ࡡࠪへ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬべ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧぺ"),789,l11lll_l1_ (u"ࠧࠨほ"),l11lll_l1_ (u"ࠨࠩぼ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩぽ"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩま")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫみ"),l11lll_l1_ (u"ࠬ࠭む"),409,l11lll_l1_ (u"࠭ࠧめ"),l11lll_l1_ (u"ࠧࠨも"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࡣࠬゃ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩや"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩゅ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨゆ"),l11lll_l1_ (u"ࠬ࠭ょ"),409,l11lll_l1_ (u"࠭ࠧよ"),l11lll_l1_ (u"ࠧࠨら"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨり"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩる"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩれ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ๊ํอสࠨろ"),l11lll_l1_ (u"ࠬ࠭ゎ"),409,l11lll_l1_ (u"࠭ࠧわ"),l11lll_l1_ (u"ࠧࠨゐ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧゑ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩを"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩん")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫࠥࠦศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧゔ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠬࠦࠠࠨゕ"),l11lll_l1_ (u"࠭ࠧゖ"),29,l11lll_l1_ (u"ࠧࠨ゗"),l11lll_l1_ (u"ࠨࠩ゘"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ゙ࠩ"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠ゚ࠩ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪ゛"),l11lll_l1_ (u"ࠬ࠭゜"),29,l11lll_l1_ (u"࠭ࠧゝ"),l11lll_l1_ (u"ࠧࠨゞ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭ゟ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ゠"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩァ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ア"),l11lll_l1_ (u"ࠬ࠭ィ"),29,l11lll_l1_ (u"࠭ࠧイ"),l11lll_l1_ (u"ࠧࠨゥ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍࡥࠧウ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩェ"),l11lll_l1_ (u"ࠪࡣࡆࡑࡏࡠࠩエ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬォ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭オ"),79,l11lll_l1_ (u"࠭ࠧカ"),l11lll_l1_ (u"ࠧࠨガ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨキ"),l11lll_l1_ (u"ࠩࡢࡅࡐ࡝࡟ࠨギ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫク")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬグ"),249,l11lll_l1_ (u"ࠬ࠭ケ"),l11lll_l1_ (u"࠭ࠧゲ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧコ"),l11lll_l1_ (u"ࠨࡡࡐࡖࡋ࠭ゴ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪサ"),l11lll_l1_ (u"ࠪࠫザ"),49,l11lll_l1_ (u"ࠫࠬシ"),l11lll_l1_ (u"ࠬ࠭ジ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ス"),l11lll_l1_ (u"ࠧࡠࡕࡋࡑࡤ࠭ズ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็ࠠๆษๆืࠬセ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪゼ"),59,l11lll_l1_ (u"ࠪࠫソ"),l11lll_l1_ (u"ࠫࠬゾ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬタ"),l11lll_l1_ (u"࠭࡟ࡇࡖࡐࡣࠬダ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส่๊์ศาࠢส่ๆอืๆ์ࠪチ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩヂ"),69,l11lll_l1_ (u"ࠩࠪッ"),l11lll_l1_ (u"ࠪࠫツ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫヅ"),l11lll_l1_ (u"ࠬࡥࡋࡘࡖࡢࠫテ")+l1ll1l1111l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭デ"),l11lll_l1_ (u"ࠧࠨト"),139,l11lll_l1_ (u"ࠨࠩド"),l11lll_l1_ (u"ࠩࠪナ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪニ"),l11lll_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪヌ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫネ"),l11lll_l1_ (u"࠭ࠧノ"),319,l11lll_l1_ (u"ࠧࠨハ"),l11lll_l1_ (u"ࠨࠩバ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩパ"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩヒ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨビ"),l11lll_l1_ (u"ࠬ࠭ピ"),319,l11lll_l1_ (u"࠭ࠧフ"),l11lll_l1_ (u"ࠧࠨブ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫプ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩヘ"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩベ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊ห้ࠣั๊ฯࠨペ"),l11lll_l1_ (u"ࠬ࠭ホ"),319,l11lll_l1_ (u"࠭ࠧボ"),l11lll_l1_ (u"ࠧࠨポ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪマ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩミ"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩム")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪメ"),l11lll_l1_ (u"ࠬ࠭モ"),319,l11lll_l1_ (u"࠭ࠧャ"),l11lll_l1_ (u"ࠧࠨヤ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪュ"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧユ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬョ"),l11lll_l1_ (u"ࠫࠬヨ"),157)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬラ"),l11lll_l1_ (u"࠭࡟ࡌࡖࡎࡣࠬリ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๆฮ่๎สࠨル")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩレ"),679,l11lll_l1_ (u"ࠩࠪロ"),l11lll_l1_ (u"ࠪࠫヮ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫワ"),l11lll_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫヰ")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ࠠษฯฮࠤ๊๎โฺࠢไะึࠦิ้ࠩヱ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠧࠡࠩヲ"),l11lll_l1_ (u"ࠨࠩン"),399,l11lll_l1_ (u"ࠩࠪヴ"),l11lll_l1_ (u"ࠪࠫヵ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫヶ"),l11lll_l1_ (u"ࠬࡥࡔࡗࡈࡢࠫヷ")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡฬํๅ๏ࠦแศ่ࠪヸ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨヹ"),469,l11lll_l1_ (u"ࠨࠩヺ"),l11lll_l1_ (u"ࠩࠪ・"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪー"),l11lll_l1_ (u"ࠫࡤࡒࡄࡏࡡࠪヽ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๅ๊า๎ࠥ์สࠨヾ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧヿ"),459,l11lll_l1_ (u"ࠧࠨ㄀"),l11lll_l1_ (u"ࠨࠩ㄁"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㄂"),l11lll_l1_ (u"ࠪࡣࡈࡓࡎࡠࠩ㄃")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ㄄")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭ㄅ"),309,l11lll_l1_ (u"࠭ࠧㄆ"),l11lll_l1_ (u"ࠧࠨㄇ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄈ"),l11lll_l1_ (u"ࠩࡢ࡛ࡈࡓ࡟ࠨㄉ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭ㄊ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬㄋ"),569,l11lll_l1_ (u"ࠬ࠭ㄌ"),l11lll_l1_ (u"࠭ࠧㄍ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄎ"),l11lll_l1_ (u"ࠨࡡࡖࡌࡓࡥࠧㄏ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧㄐ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠪࠫㄑ"),589,l11lll_l1_ (u"ࠫࠬㄒ"),l11lll_l1_ (u"ࠬ࠭ㄓ"),l111l1l_l1_+l11lll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫㄔ"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄕ"),l11lll_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧㄖ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭ㄗ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠪࠫㄘ"),369,l11lll_l1_ (u"ࠫࠬㄙ"),l11lll_l1_ (u"ࠬ࠭ㄚ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄛ"),l11lll_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭ㄜ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็ࠠษำ๋ࠫㄝ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪㄞ"),489,l11lll_l1_ (u"ࠪࠫㄟ"),l11lll_l1_ (u"ࠫࠬㄠ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄡ"),l11lll_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬㄢ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦำ๋์าࠫㄣ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩㄤ"),259,l11lll_l1_ (u"ࠩࠪㄥ"),l11lll_l1_ (u"ࠪࠫㄦ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄧ"),l11lll_l1_ (u"ࠬࡥࡃ࠵ࡗࡢࠫㄨ")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦแ้ำํ์ࠬㄩ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨㄪ"),429,l11lll_l1_ (u"ࠨࠩㄫ"),l11lll_l1_ (u"ࠩࠪㄬ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄭ"),l11lll_l1_ (u"ࠫࡤ࡙ࡈ࠵ࡡࠪㄮ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫㄯ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧ㄰"),119,l11lll_l1_ (u"ࠧࠨㄱ"),l11lll_l1_ (u"ࠨࠩㄲ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧㄳ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄴ"),l11lll_l1_ (u"ࠫࡤࡋࡂ࠴ࡡࠪㄵ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬㄶ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧㄷ"),799,l11lll_l1_ (u"ࠧࠨㄸ"),l11lll_l1_ (u"ࠨࠩㄹ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄺ"),l11lll_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩㄻ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪㄼ"),l11lll_l1_ (u"ࠬ࠭ㄽ"),389,l11lll_l1_ (u"࠭ࠧㄾ"),l11lll_l1_ (u"ࠧࠨㄿ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅀ"),l11lll_l1_ (u"ࠩࡢࡉࡌ࡜࡟ࠨㅁ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬㅂ"),l11lll_l1_ (u"ࠫࠬㅃ"),229,l11lll_l1_ (u"ࠬ࠭ㅄ"),l11lll_l1_ (u"࠭ࠧㅅ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬㅆ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㅇ"),l11lll_l1_ (u"ࠩࠪㅈ"),157)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅉ"),l11lll_l1_ (u"ࠫࡤࡒࡒ࡛ࡡࠪㅊ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๅษิ์ือࠧㅋ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧㅌ"),709,l11lll_l1_ (u"ࠧࠨㅍ"),l11lll_l1_ (u"ࠨࠩㅎ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅏ"),l11lll_l1_ (u"ࠪࡣࡋ࡙ࡔࡠࠩㅐ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแ้ีอหࠬㅑ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭ㅒ"),609,l11lll_l1_ (u"࠭ࠧㅓ"),l11lll_l1_ (u"ࠧࠨㅔ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅕ"),l11lll_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨㅖ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็ศาๅฬࠫㅗ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬㅘ"),629,l11lll_l1_ (u"ࠬ࠭ㅙ"),l11lll_l1_ (u"࠭ࠧㅚ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㅛ"),l11lll_l1_ (u"ࠨࡡ࡜ࡕ࡙ࡥࠧㅜ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏อโ้ฬࠪㅝ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠪࠫㅞ"),669,l11lll_l1_ (u"ࠫࠬㅟ"),l11lll_l1_ (u"ࠬ࠭ㅠ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅡ"),l11lll_l1_ (u"ࠧࡠࡄࡕࡗࡤ࠭ㅢ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬึูส๋ฮࠪㅣ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪㅤ"),659,l11lll_l1_ (u"ࠪࠫㅥ"),l11lll_l1_ (u"ࠫࠬㅦ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅧ"),l11lll_l1_ (u"࠭࡟ࡉࡎࡆࡣࠬㅨ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๊่ࠢฬࠦำ๋็สࠫㅩ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩㅪ"),89,l11lll_l1_ (u"ࠩࠪㅫ"),l11lll_l1_ (u"ࠪࠫㅬ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅭ"),l11lll_l1_ (u"ࠬࡥࡄࡓ࠹ࡢࠫㅮ")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัิห๊อࠠึฯࠪㅯ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨㅰ"),689,l11lll_l1_ (u"ࠨࠩㅱ"),l11lll_l1_ (u"ࠩࠪㅲ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅳ"),l11lll_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪㅴ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็ว็ิࠪㅵ")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧㅶ"),99,l11lll_l1_ (u"ࠧࠨㅷ"),l11lll_l1_ (u"ࠨࠩㅸ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅹ"),l11lll_l1_ (u"ࠪࡣࡈࡓࡌࡠࠩㅺ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩㅻ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭ㅼ"),479,l11lll_l1_ (u"࠭ࠧㅽ"),l11lll_l1_ (u"ࠧࠨㅾ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅿ"),l11lll_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨㆀ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨㆁ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬㆂ"),559,l11lll_l1_ (u"ࠬ࠭ㆃ"),l11lll_l1_ (u"࠭ࠧㆄ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆅ"),l11lll_l1_ (u"ࠨࡡࡆ࠸ࡍࡥࠧㆆ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭ㆇ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠪࠫㆈ"),699,l11lll_l1_ (u"ࠫࠬㆉ"),l11lll_l1_ (u"ࠬ࠭ㆊ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆋ"),l11lll_l1_ (u"ࠧࡠࡃࡋࡏࡤ࠭ㆌ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧㆍ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠩࠪㆎ"),619,l11lll_l1_ (u"ࠪࠫ㆏"),l11lll_l1_ (u"ࠫࠬ㆐"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㆑"),l11lll_l1_ (u"࠭࡟ࡄࡅࡅࡣࠬ㆒")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㆓")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠨࠩ㆔"),639,l11lll_l1_ (u"ࠩࠪ㆕"),l11lll_l1_ (u"ࠪࠫ㆖"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㆗"),l11lll_l1_ (u"ࠬࡥࡓࡉࡖࡢࠫ㆘")+l1l1ll11l11_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬ㆙")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠧࠨ㆚"),649,l11lll_l1_ (u"ࠨࠩ㆛"),l11lll_l1_ (u"ࠩࠪ㆜"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㆝"),l11lll_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ㆞")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩ㆟")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧㆠ"),439,l11lll_l1_ (u"ࠧࠨㆡ"),l11lll_l1_ (u"ࠨࠩㆢ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆣ"),l11lll_l1_ (u"ࠪࡣࡋࡎ࠲ࡠࠩㆤ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫㆥ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭ㆦ"),599,l11lll_l1_ (u"࠭ࠧㆧ"),l11lll_l1_ (u"ࠧࠨㆨ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㆩ"),l11lll_l1_ (u"ࠩࡢࡉࡇ࠺࡟ࠨㆪ")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪㆫ")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬㆬ"),809,l11lll_l1_ (u"ࠬ࠭ㆭ"),l11lll_l1_ (u"࠭ࠧㆮ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆯ"),l11lll_l1_ (u"ࠨࡡࡈࡋࡉࡥࠧㆰ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭ㆱ"),l11lll_l1_ (u"ࠪࠫㆲ"),449,l11lll_l1_ (u"ࠫࠬㆳ"),l11lll_l1_ (u"ࠬ࠭ㆴ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆵ"),l11lll_l1_ (u"ࠧࡠࡃࡎࡇࡤ࠭ㆶ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห่๎วๆࠢๆห๊࠭ㆷ"),l11lll_l1_ (u"ࠩࠪㆸ"),359,l11lll_l1_ (u"ࠪࠫㆹ"),l11lll_l1_ (u"ࠫࠬㆺ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㆻ"),l11lll_l1_ (u"࠭࡟ࡄࡏࡆࡣࠬㆼ")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬㆽ"),l11lll_l1_ (u"ࠨࠩㆾ"),499,l11lll_l1_ (u"ࠩࠪㆿ"),l11lll_l1_ (u"ࠪࠫ㇀"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㇁"),l11lll_l1_ (u"ࠬࡥࡁࡓࡎࡢࠫ㇂")+l1ll1l1111l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ฻ิฬ๊๊้่ࠥีࠫ㇃"),l11lll_l1_ (u"ࠧࠨ㇄"),209,l11lll_l1_ (u"ࠨࠩ㇅"),l11lll_l1_ (u"ࠩࠪ㇆"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㇇"),l11lll_l1_ (u"ࠫࡤࡎࡅࡍࡡࠪ㇈")+l1ll1l1111l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ㇉"),l11lll_l1_ (u"࠭ࠧ㇊"),99,l11lll_l1_ (u"ࠧࠨ㇋"),l11lll_l1_ (u"ࠨࠩ㇌"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇍"),l11lll_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ㇎")+search+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋ำํืࠥ็่า๋ࠢฮู࠭㇏"),l11lll_l1_ (u"ࠬ࠭㇐"),218,l11lll_l1_ (u"࠭ࠧ㇑"),l11lll_l1_ (u"ࠧࠨ㇒"),search) # 219
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇓"),l11lll_l1_ (u"ࠩࡢࡑ࡛ࡠ࡟ࠨ㇔")+search+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๋่ࠥโ์ีࠤ้อๆะࠩ㇕"),l11lll_l1_ (u"ࠫࠬ㇖"),188,l11lll_l1_ (u"ࠬ࠭㇗"),l11lll_l1_ (u"࠭ࠧ㇘"),search)# 189
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㇙"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㇚"),l11lll_l1_ (u"ࠩࠪ㇛"),157)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㇜"),l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㇝")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠧ㇞")+l1ll1l1111l_l1_,l11lll_l1_ (u"࠭ࠧ㇟"),149,l11lll_l1_ (u"ࠧࠨ㇠"),l11lll_l1_ (u"ࠨࠩ㇡"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇢"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ㇣")+l1l1ll11l11_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ㇤")+l1ll1l1111l_l1_,l11lll_l1_ (u"ࠬ࠭㇥"),409,l11lll_l1_ (u"࠭ࠧ㇦"),l11lll_l1_ (u"ࠧࠨ㇧"),l111l1l_l1_)
	return
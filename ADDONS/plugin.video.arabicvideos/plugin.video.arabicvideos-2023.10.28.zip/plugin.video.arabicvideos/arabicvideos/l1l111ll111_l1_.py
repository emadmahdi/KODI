﻿# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#import unicodedata,simplejson
def MAIN(mode,l1l111lllll_l1_):
	if l1l111lllll_l1_==l11lll_l1_ (u"ࠪࠫ㔹"): return
	if mode==1:
		l1l111llll1_l1_ = xbmcgui.l1l111lll1l_l1_()
		l1l111lll11_l1_ = xbmcgui.l1l111l1l11_l1_(l1l111llll1_l1_)
		l1l111lllll_l1_ = l1l111ll1ll_l1_(l1l111lllll_l1_)
		l1l111lll11_l1_.getControl(311).l1l11l1111l_l1_(l1l111lllll_l1_)
	if mode==0:
		#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㔺"))
		#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㔻"))
		#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㔼"))
		l1l111l1ll1_l1_=l11lll_l1_ (u"࡙ࠧࠩ㔽")
		if kodi_version>18.99: check = isinstance(l1l111lllll_l1_,str)
		else: check = isinstance(l1l111lllll_l1_,unicode)
		if check==True: l1l111l1ll1_l1_=l11lll_l1_ (u"ࠨࡗࠪ㔾")
		l1l111l1l1l_l1_=str(type(l1l111lllll_l1_))+l11lll_l1_ (u"ࠩࠣࠫ㔿")+l1l111lllll_l1_+l11lll_l1_ (u"ࠪࠤࠬ㕀")+l1l111l1ll1_l1_+l11lll_l1_ (u"ࠫࠥ࠭㕁")
		for i in range(0,len(l1l111lllll_l1_),1):
			l1l111l1l1l_l1_ += hex(ord(l1l111lllll_l1_[i])).replace(l11lll_l1_ (u"ࠬ࠶ࡸࠨ㕂"),l11lll_l1_ (u"࠭ࠧ㕃"))+l11lll_l1_ (u"ࠧࠡࠩ㕄")
		l1l111lllll_l1_ = l1l111ll1ll_l1_(l1l111lllll_l1_)
		#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㕅"))
		l1l111l1ll1_l1_=l11lll_l1_ (u"࡛ࠩࠫ㕆")
		if kodi_version>18.99: check = isinstance(l1l111lllll_l1_, str)
		else: check = isinstance(l1l111lllll_l1_, unicode)
		if check==True: l1l111l1ll1_l1_=l11lll_l1_ (u"࡙ࠪࠬ㕇")
		l1l111l1lll_l1_=str(type(l1l111lllll_l1_))+l11lll_l1_ (u"ࠫࠥ࠭㕈")+l1l111lllll_l1_+l11lll_l1_ (u"ࠬࠦࠧ㕉")+l1l111l1ll1_l1_+l11lll_l1_ (u"࠭ࠠࠨ㕊")
		for i in range(0,len(l1l111lllll_l1_),1):
			l1l111l1lll_l1_ += hex(ord(l1l111lllll_l1_[i])).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㕋"),l11lll_l1_ (u"ࠨࠩ㕌"))+l11lll_l1_ (u"ࠩࠣࠫ㕍")
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㕎"),l11lll_l1_ (u"ࠫࠬ㕏"),l1l111l1l1l_l1_,l1l111l1lll_l1_)
	return
	#for i in range(0,len(l1l111lllll_l1_)-2,3):
	#	string=hex(ord(l1l111lllll_l1_[i+0]))+l11lll_l1_ (u"ࠬࠦࠠࠨ㕐")+hex(ord(l1l111lllll_l1_[i+1]))+l11lll_l1_ (u"࠭ࠠࠡࠩ㕑")+hex(ord(l1l111lllll_l1_[i+2]))
	#	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㕒"),l11lll_l1_ (u"ࠨࠩ㕓"),l11lll_l1_ (u"ࠩࠪ㕔"),string)
	#return
	#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㕕"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㕖"),l11lll_l1_ (u"ࠬ࠭㕗"),l11lll_l1_ (u"࠭ࠧ㕘"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111ll1ll_l1_(l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㕙"))
	#l1l111lllll_l1_ = unicodedata.normalize(l11lll_l1_ (u"ࠨࡐࡉࡏࡉ࠭㕚"),l1l111lllll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㕛"),l11lll_l1_ (u"ࠪࠫ㕜"),l11lll_l1_ (u"ࠫࠬ㕝"),   hex(  unicodedata.combining(l1l111lllll_l1_[0])  )   )
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㕞"),l11lll_l1_ (u"࠭ࠧ㕟"),l1l111lllll_l1_,   hex(ord(  l1l111lllll_l1_[0]  ))   )
	#new = l11lll_l1_ (u"ࠧࠨ㕠")
	#for l1l111ll11l_l1_ in l1l111lllll_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㕡"),l11lll_l1_ (u"ࠩࠪ㕢"),l11lll_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㕣"),unicodedata.decomposition(l1l111ll11l_l1_) )
	#	new += l11lll_l1_ (u"ࠫࡡࡻ࠰ࠨ㕤") + hex(ord(l1l111ll11l_l1_)).replace(l11lll_l1_ (u"ࠬ࠶ࡸࠨ㕥"),l11lll_l1_ (u"࠭ࠧ㕦"))
	#l1l111lllll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㕧"),l11lll_l1_ (u"ࠨࠩ㕨"),l11lll_l1_ (u"ࠩࠪ㕩"),l1l111lllll_l1_)
	#new = l11lll_l1_ (u"ࠪࠫ㕪")
	#for i in range(len(l1l111lllll_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㕫"),l11lll_l1_ (u"ࠬ࠭㕬"),l11lll_l1_ (u"࠭ࠧ㕭"),str(i))
	#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1] + l1l111lllll_l1_[i+2] + l1l111lllll_l1_[i+3] + l1l111lllll_l1_[i+4] + l1l111lllll_l1_[i+5]
	#l1l111lllll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㕮"),l11lll_l1_ (u"ࠨࠩ㕯"),l11lll_l1_ (u"ࠩࠪ㕰"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㕱"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㕲"),l11lll_l1_ (u"ࠬ࠭㕳"),l11lll_l1_ (u"࠭ࠧ㕴"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111lllll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㕵"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㕶"),l11lll_l1_ (u"ࠩࠪ㕷"),l11lll_l1_ (u"ࠪࠫ㕸"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l11lll_l1_ (u"ࠫࡪࡳࡡࡥࠩ㕹")
	#l1l111ll1l1_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡎࡴࡰࡶࡶ࠱ࡗࡪࡴࡤࡕࡧࡻࡸࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠫ㕺")+l1l111lllll_l1_+l11lll_l1_ (u"࠭ࠢ࠭ࠤࡧࡳࡳ࡫ࠢ࠻ࡨࡤࡰࡸ࡫ࡽ࠭ࠤ࡬ࡨࠧࡀ࠱ࡾࠩ㕻"))
	#simplejson.loads(l1l111ll1l1_l1_)
	#l1l111lllll_l1_ = l1l111lllll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㕼"))
	#new = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㕽"))
	#l1l111lllll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㕾"),l11lll_l1_ (u"ࠪࠫ㕿"),l11lll_l1_ (u"ࠫࠬ㖀"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111ll1ll_l1_(l1l111lllll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㖁"),l11lll_l1_ (u"࠭ࠧ㖂"),l11lll_l1_ (u"ࠧࠨ㖃"),l1l111lllll_l1_)
	#new = l11lll_l1_ (u"ࠨࠩ㖄")
	#for i in range(len(l1l111lllll_l1_)-2,-1,-2):
	#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1]
	#l1l111lllll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㖅"),l11lll_l1_ (u"ࠪࠫ㖆"),l11lll_l1_ (u"ࠫࠬ㖇"),l1l111lllll_l1_)
	#l1l111lllll_l1_ = l1l111lllll_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㖈"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㖉"),l11lll_l1_ (u"ࠧࠨ㖊"),l11lll_l1_ (u"ࠨࠩ㖋"),l1l111lllll_l1_)
	#new = l11lll_l1_ (u"ࠩࠪ㖌")
	#for i in range(len(l1l111lllll_l1_)-2,-1,-2):
	#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1]
	#l1l111lllll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㖍"),l11lll_l1_ (u"ࠫࠬ㖎"),l11lll_l1_ (u"ࠬ࠭㖏"),l1l111lllll_l1_)
		#l1l111lllll_l1_ = l1l111lllll_l1_.replace(l11lll_l1_ (u"࠭ࠠࠨ㖐"),l11lll_l1_ (u"ࠧࠨ㖑"))
		#new = l11lll_l1_ (u"ࠨࠩ㖒")
		#for i in range(len(l1l111lllll_l1_)-3,-2,-3):
		#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1] + l1l111lllll_l1_[i+2]
		#l1l111lllll_l1_ = new
		#new = l11lll_l1_ (u"ࠩࠪ㖓")
		#for i in range(len(l1l111lllll_l1_)-2,-1,-2):
		#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1]
		#l1l111lllll_l1_ = new
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㖔"),l11lll_l1_ (u"ࠫࠬ㖕"),l11lll_l1_ (u"ࠬ࠭㖖"),l1l111lllll_l1_)
		#l1l111lllll_l1_ = l1l111lllll_l1_.l1l11l11111_l1_(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㖗"))
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㖘"),l11lll_l1_ (u"ࠨࠩ㖙"),str(ord(l1l111lllll_l1_[0]))+l11lll_l1_ (u"ࠩࠣࠫ㖚")+str(ord(l1l111lllll_l1_[1]))+l11lll_l1_ (u"ࠪࠤࠬ㖛")+str(ord(l1l111lllll_l1_[2])),str(len(l1l111lllll_l1_)))
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㖜"),l11lll_l1_ (u"ࠬ࠭㖝"),l11lll_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵ࠦࡌࡦࡶࡷࡩࡷࡹࠧ㖞"),l1l111lllll_l1_)
		#new = l11lll_l1_ (u"ࠧࠨ㖟")
		#for i in range(len(l1l111lllll_l1_)-2,-1,-2):
		#	new += l1l111lllll_l1_[i] + l1l111lllll_l1_[i+1]
		#l1l111lllll_l1_ = new
		#new = l1l111lllll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㖠"))
		#new = new.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㖡"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㖢"),l11lll_l1_ (u"ࠫࠬ㖣"),l11lll_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㖤"),new )
		#l1l111l1l1l_l1_ = l11lll_l1_ (u"࠭ࠧ㖥")
		#for l1l111ll11l_l1_ in new:
		#	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㖦"),l11lll_l1_ (u"ࠨࠩ㖧"),l11lll_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ㖨"),unicodedata.decomposition(l1l111ll11l_l1_) )
		#	l1l111l1l1l_l1_ += l11lll_l1_ (u"ࠪࡠࡺ࠭㖩") + hex(ord(l1l111ll11l_l1_)).replace(l11lll_l1_ (u"ࠫࡽ࠭㖪"),l11lll_l1_ (u"ࠬ࠭㖫"))
		#l1l111l1l1l_l1_ = l1l111l1l1l_l1_.decode(l11lll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㖬"))
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㖭"),l11lll_l1_ (u"ࠨࠩ㖮"),l11lll_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ㖯"),l1l111l1l1l_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l111ll1ll_l1_(new)
		#l1l111lllll_l1_ = new.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㖰"))
		#new = new.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㖱")) #.decode(l11lll_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㖲"))
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㖳"),l11lll_l1_ (u"ࠧࠨ㖴"),l11lll_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨ㖵"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㖶")))   )
		#l1l111lllll_l1_ = l1l111ll1ll_l1_(new)
		#l1l111lllll_l1_ = l1l111ll1ll_l1_(l1l111lllll_l1_)
		#method=l11lll_l1_ (u"ࠥࡍࡳࡶࡵࡵ࠰ࡖࡩࡳࡪࡔࡦࡺࡷࠦ㖷")
		#params=l11lll_l1_ (u"ࠫࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠥࡴࠤ࠯ࠤࠧࡪ࡯࡯ࡧࠥ࠾࡫ࡧ࡬ࡴࡧࢀࠫ㖸") % l1l111lllll_l1_
		#l1l111ll1l1_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠣࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠦࠢࠦࡵࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࠡࠧࡶ࠰ࠥࠨࡩࡥࠤ࠽ࠤ࠶ࢃࠧ㖹") % (method, params))
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll11l_l1_ import *
import traceback,bidi.algorithm
#import l1l1l1l1llll_l1_
script_name = l11lll_l1_ (u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ㟙")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1lll11ll111_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ㟚"))
	l1l1l111l1_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭㟛"))
	l11l11111ll_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ㟜"))
	l1l1l11ll1l1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㟝"),l11lll_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㟞"),l11lll_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ㟟"))
	l111l11lll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㟠"),l11lll_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㟡"),l11lll_l1_ (u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ㟢"))
	l1ll11l11l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㟣"),l11lll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㟤"),l11lll_l1_ (u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ㟥"))
	half_triangular_colon = l11lll_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ㟦")
	from urllib.parse import quote as _1ll1l11l1l1_l1_
	#from io import BytesIO as _1ll111l11ll_l1_
else:
	l1lll11ll111_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ㟧"))
	l1l1l111l1_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ㟨"))
	l11l11111ll_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ㟩"))
	l1l1l11ll1l1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㟪"),l11lll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㟫"),l11lll_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭㟬"))
	l111l11lll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㟭"),l11lll_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㟮"),l11lll_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ㟯"))
	l1ll11l11l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㟰"),l11lll_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㟱"),l11lll_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ㟲"))
	half_triangular_colon = l11lll_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ㟳").encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㟴"))
	from urllib import quote as _1ll1l11l1l1_l1_
	#from StringIO import StringIO as _1ll111l11ll_l1_
#l1lll1ll11ll_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11l1ll1ll1_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡌ࡯࡭ࡦࡨࡶࡕࡧࡴࡩࠩ㟵"))
l1ll1l11ll1l_l1_ = os.path.join(l11l11111ll_l1_,l11lll_l1_ (u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭㟶"))
l1ll1llll11l_l1_ = os.path.join(l11l11111ll_l1_,l11lll_l1_ (u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫ㟷"))
iptv1_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㟸"))
iptv2_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㟹"))
m3u_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㟺"))
#l1ll1lllll11_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩࡻࡸࡷ࡫ࡡ࡮ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㟻"))
#l1ll1lll111l_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪࡰࡦࡹࡴ࡮ࡧࡱࡹ࠳ࡪࡡࡵࠩ㟼"))
favoritesfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫ࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳ࠯ࡦࡤࡸࠬ㟽"))
#dummyiptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬࡪࡵ࡮࡯ࡼ࡭ࡵࡺࡶ࠯ࡦࡤࡸࠬ㟾"))
fulliptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ㟿"))
fullm3ufile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ㠀"))
l1l111l111l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡨࡦࡺࠧ㠁"))
l1l111lll1l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬ㠂"))
l11lll1l1ll_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠪࡴࡦࡺࡨࠨ㠃"))
defaulticon = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭㠄"))
defaultthumb = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ㠅"))
defaultfanart = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㠆"))
defaultbanner = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ㠇"))
defaultlandscape = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨ㠈"))
defaultposter = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭㠉"))
defaultclearlogo = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪ㠊"))
defaultclearart = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㠋"))
l1l1lll11111_l1_ = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬ㠌"))
l1ll1l111l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㠍"))
l1l1ll1l11ll_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㠎"),l11lll_l1_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ㠏"),addon_id,l11lll_l1_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ㠐"))
l1lll1l1l111_l1_ = os.path.join(l1lll11ll111_l1_,l11lll_l1_ (u"ࠪࡱࡪࡪࡩࡢࠩ㠑"),l11lll_l1_ (u"ࠫࡋࡵ࡮ࡵࡵࠪ㠒"),l11lll_l1_ (u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨ㠓"))
FOLDERS_COUNT = 5
text_numbers = [l11lll_l1_ (u"࠭ีโำࠪ㠔"),l11lll_l1_ (u"ࠧฤ๊็ࠫ㠕"),l11lll_l1_ (u"ࠨอส๊๏࠭㠖"),l11lll_l1_ (u"ࠩฮห้ัࠧ㠗"),l11lll_l1_ (u"ࠪีฬฮูࠨ㠘"),l11lll_l1_ (u"ࠫำอๅิࠩ㠙"),l11lll_l1_ (u"ูࠬวะีࠪ㠚"),l11lll_l1_ (u"࠭ำศส฼ࠫ㠛"),l11lll_l1_ (u"ࠧฬษ่๊ࠬ㠜"),l11lll_l1_ (u"ࠨฬสื฾࠭㠝"),l11lll_l1_ (u"ࠩ฼หูืࠧ㠞")]
l1ll1lll1lll_l1_ = l11lll_l1_ (u"ࠪ⸿ࠥ⼣ࠠ⸫ࠢ⸾ࠫ㠟")
NO_CACHE = 0
l1ll11111l11_l1_ = 30*l11llllllll_l1_
l1lll1111_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
VERYLONG_CACHE = 30*l11l1lll111_l1_
l11l1llllll_l1_ = 1*HOUR
l1l1l111l1ll_l1_ = [l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㠠"),l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㠡")]
l1ll1lll1l11_l1_ = [l11lll_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ㠢")]
l1lll11l1lll_l1_ = [l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ㠣"),l11lll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㠤"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㠥"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㠦"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㠧"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㠨"),l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㠩"),l11lll_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㠪")]
l1lll11l1lll_l1_ += [l11lll_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ㠫"),l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ㠬"),l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㠭"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㠮"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㠯"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㠰"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㠱"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㠲")]
l1l111l11l1l_l1_ = [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㠳"),l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㠴"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㠵"),l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㠶")]
l1l111l11l1l_l1_ += [l11lll_l1_ (u"࠭ࡍ࠴ࡗࠪ㠷"),l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㠸"),l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㠹"),l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㠺")]
l1l111l11l1l_l1_ += [l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㠻"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㠼"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㠽")]
l1l111l11l1l_l1_ += [l11lll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㠾"),l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㠿"),l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㡀"),l11lll_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㡁"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㡂"),l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㡃")]
l1l111l11l1l_l1_ += [l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㡄"),l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㡅"),l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㡆"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㡇"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㡈"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㡉")]
#l1l111l11l1l_l1_ += [l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㡊"),l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ㡋"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ㡌"),l11lll_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㡍")]
#l1l111l11l1l_l1_ += [l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ㡎"),l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࠬ㡏"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ㡐"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ㡑")]
l1l1l111ll1_l1_ = [l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㡒"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㡓"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㡔"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㡕")]
l1l1l111ll1_l1_ += [l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㡖"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㡗"),l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㡘"),l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㡙"),l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㡚")]
l1l1l11llll_l1_ = [l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㡛"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㡜"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㡝"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㡞"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㡟"),l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㡠")]
l1l1l11llll_l1_ += [l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㡡"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㡢"),l11lll_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㡣"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㡤"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㡥")]
#l1l1l11llll_l1_ += [l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㡦"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㡧")]
l1l1ll1l111_l1_ = [l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㡨"),l11lll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㡩"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㡪"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㡫"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㡬"),l11lll_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㡭"),l11lll_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㡮"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㡯")]
l1l1ll1l111_l1_ += [l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㡰"),l11lll_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㡱"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㡲"),l11lll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㡳"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㡴"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㡵")]
#l1l1ll1l111_l1_ += [l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㡶"),l11lll_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㡷"),l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㡸"),l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ㡹"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ㡺"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㡻"),l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㡼")]
l1l1lll11ll1_l1_  = [l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㡽"),l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㡾"),l11lll_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㡿"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㢀"),l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㢁"),l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㢂"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㢃"),l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㢄")]
l1l1lll11ll1_l1_ += [l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㢅"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㢆"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㢇"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㢈"),l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㢉"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㢊"),l11lll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㢋"),l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㢌"),l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㢍")]
l1l1lll11ll1_l1_ += [l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㢎"),l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㢏"),l11lll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㢐"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㢑"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ㢒"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㢓"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㢔")]
l1l1lll11ll1_l1_ += [l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㢕"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㢖"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭㢗"),l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㢘"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㢙"),l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㢚")]
l1l1lll11ll1_l1_ += [l11lll_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㢛"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㢜"),l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㢝"),l11lll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㢞"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㢟"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㢠")]
l1l11lll1l1l_l1_  = [l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㢡"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㢢"),l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㢣"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㢤")]
l1l11lll1l1l_l1_ += [l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㢥"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㢦")]
l1l11lll1l1l_l1_ += [l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㢧"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㢨"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㢩")]
l1l11lll1l1l_l1_ += [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㢪"),l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㢫"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㢬")]
l1l11lll1l1l_l1_ += [l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ㢭"),l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㢮"),l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㢯")]
#l1l11lll1l1l_l1_ += [l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㢰"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ㢱")]
#l1l11lll1l1l_l1_ += [l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ㢲"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ㢳"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࠨ㢴")]
l1l1l11ll111_l1_ = [l11lll_l1_ (u"࠭ࡍ࠴ࡗࠪ㢵"),l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㢶"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㢷"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㢸"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㢹")]		# l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㢺"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㢻")
l1l1l1ll1l1_l1_ = l1l1lll11ll1_l1_+l1l11lll1l1l_l1_
l1l1ll11l111_l1_ = l1l1lll11ll1_l1_+l1l1l11ll111_l1_
l11l1l11ll1_l1_ = l1l1lll11ll1_l1_+l1l1l11ll111_l1_+l1l1l111l1ll_l1_
l1l1l1ll11l_l1_ = l1l111l11l1l_l1_+l1l1l11llll_l1_+l1l1ll1l111_l1_+l1l1l111ll1_l1_
# l1ll1llll1l1_l1_ will not show l1llll1ll111_l1_ errors and will not exit from the l11l11ll111_l1_
l1lllllll111_l1_ = [
						l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㢼")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ㢽")
						,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ㢾")
						,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㢿")
						,l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ㣀")
						,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㣁")
						,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㣂")
						,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ㣃")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㣄")
						,l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ㣅")
						,l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ㣆")
						,l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ㣇")
						]
l1111lll111_l1_ = l1lllllll111_l1_+[
				 l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㣈")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㣉")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㣊")
				,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ㣋")
				,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ㣌")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ㣍")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ㣎")
				,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭㣏")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ㣐")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㣑")
				,l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㣒")
				,l11lll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫ㣓")
				,l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬ㣔")
				,l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ㣕")
				,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㣖")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㣗")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㣘")
				#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㣙")
				#,l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㣚")
				#,l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ㣛")
				#,l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㣜")
				#,l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭㣝")
				#,l11lll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡈࡇࡗࡣࡑࡇࡔࡆࡕࡗࡣ࡛ࡋࡒࡔࡋࡒࡒࡤࡔࡕࡎࡄࡈࡖࡘ࠳࠱ࡴࡶࠪ㣞")
				#,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㣟")
				#,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭㣠")
				#,l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㣡")
				]
l1lll1l11lll_l1_ = [l11lll_l1_ (u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ㣢"),l11lll_l1_ (u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫ㣣"),l11lll_l1_ (u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ㣤"),l11lll_l1_ (u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭㣥"),l11lll_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ㣦"),l11lll_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ㣧")]
l1ll11l_l1_ = {
			#,l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ㣨")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭㣩")]
			#,l11lll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㣪")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡰࡰࡧࡷࡵࡪࡤࡶࡹࡼ࠮ࡪࡴࠪ㣫")]
			#,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧ㣬")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡱࡩࡹ࠭㣭")]
			#,l11lll_l1_ (u"ࠧࡆࡉ࡜࠸ࡇࡋࡓࡕࠩ㣮")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ㣯")]
			#,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㣰")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ㣱")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㣲")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡩ࡬ࡿ࡮ࡰࡹ࠱ࡰ࡮ࡼࡥࠨ㣳")]
			#,l11lll_l1_ (u"࠭ࡈࡆࡎࡄࡐࠬ㣴")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࠶࡫ࡩࡱࡧ࡬࠯࡯ࡨࠫ㣵")]
			#,l11lll_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㣶")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭㣷"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦࠩ㣸")]
			#,l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㣹")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡴࡼࡳ࠵ࡷ࠱ࡻࡸ࠭㣺")]
			#,l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㣻")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡲࠫ㣼")]
			#,l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㣽"):[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠭㣾")]
			#,l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭㣿")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠯ࡥࡲࡱࠬ㤀")]
			#,l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ㤁")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࠰ࡶ࡬ࡴࡵࡦࡱࡴࡲ࠲ࡴࡴ࡬ࡪࡰࡨࠫ㤂")]    #	 https://l1l1l111lll1_l1_.com
			#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㤃")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦ࠳࡯࡯ࠨ㤄")]
			#,l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㤅")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨ࠮ࡷ࡫ࡳࠫ㤆")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㤇")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㤈")]
			#,l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㤉")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡤࡶࡴࢀࡡ࠯ࡱࡱࡩࠬ㤊")]
			 l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㤋")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡱࡩࡹ࠭㤌")]
			,l11lll_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㤍")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭㤎")]
			,l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㤏")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶࠪ㤐")]
			,l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㤑")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪ㤒")]
			,l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㤓")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶࠨ㤔")]
			,l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㤕")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ㤖")]
			,l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㤗")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ㤘")]
			,l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㤙")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ㤚")]
			,l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㤛")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ㤜")]
			,l11lll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㤝")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ㤞")]
			,l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㤟")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ㤠")]
			,l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㤡")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ㤢")]
			,l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㤣")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ㤤")]
			,l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㤥")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ㤦")]
			,l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㤧")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠼࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸࠬ㤨")]
			,l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㤩")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡲࡴࡽ࠮ࡤࡱࡰࠫ㤪")]
			,l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㤫")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㤬"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㤭")]
			,l11lll_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㤮")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫ㤯")]
			,l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㤰")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴ࠭ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ㤱")]
			,l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㤲")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡩࡻ࠭㤳")]
			,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㤴")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨ㤵")]
			,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㤶")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㤷")]
			,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㤸")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬ㤹")]
			,l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ㤺")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ㤻")]
			,l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㤼")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ㤽")]
			,l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㤾")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩ㤿")]
			,l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㥀")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡼࡩࡱࠩ㥁")]
			,l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ㥂")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧ㥃")]
			,l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㥄")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧ㥅")]
			,l11lll_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㥆")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯ࡷࡶࠫ㥇")]
			,l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㥈")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㥉"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㥊"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㥋"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㥌"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫ㥍")]
			,l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㥎")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧ㥏")]
			,l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ㥐")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ㥑")]
			,l11lll_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ㥒")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ㥓"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪ㥔")]
			,l11lll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㥕")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡥࡤࡱࠬ㥖")]
			,l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㥗")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ㥘")]
			,l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㥙")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠷࠮ࡷ࡫ࡳࠫ㥚")]
			,l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㥛")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ㥜")]
			,l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㥝")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭㥞")]
			,l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㥟")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㥠"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ㥡"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ㥢")]
			,l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㥣")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ㥤")]
			,l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㥥")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡨ࡯࡭ࡢ࠰ࡷࡹࡧ࡫ࠧ㥦")]
			,l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㥧")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ㥨")]
			,l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㥩")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ㥪")]
			#,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㥫")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㥬"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㥭"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㥮"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㥯"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㥰"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㥱"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㥲")]
			#,l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㥳")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㥴"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㥵"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㥶"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㥷"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㥸"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㥹"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㥺")]
			#,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㥻")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㥼"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㥽"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㥾"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㥿"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㦀"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㦁"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㦂")]
			#,l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㦃")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㦄"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㦅"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㦆"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㦇"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㦈"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㦉"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㦊"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㦋")]
			#,l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㦌")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㦍"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㦎"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㦏"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㦐"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㦑"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㦒"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㦓"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㦔")]
			,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㦕")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㦖"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㦗"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㦘"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㦙"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㦚"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㦛"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㦜"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㦝")]
			,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㦞")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㦟"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㦠"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㦡"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㦢"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㦣"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㦤"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㦥"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㦦")]
			,l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㦧")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㦨"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ㦩"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ㦪")]
			,l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ㦫")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㦬"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ㦭"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ㦮")]
			,l11lll_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ㦯")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ㦰"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫ࠫ㦱"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ㦲")]
			}
class l1ll11l1111l_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l11l1l1l_l1_ = -1
	def onClick(self,l1lll1l1l1ll_l1_):
		if l1lll1l1l1ll_l1_>=9010: self.l11l11l1l1l_l1_ = l1lll1l1l1ll_l1_-9010
		self.delete()
	def l1111111l1l_l1_(self,*args):
		#self.getControl(9001).l1l11l1111l_l1_(header)
		#self.getControl(9009).l1ll1ll1llll_l1_(text)
		#self.getControl(9010).l1l11l1111l_l1_(l1llll1l11l1_l1_)
		#self.getControl(9011).l1l11l1111l_l1_(l1l1l111ll11_l1_)
		#self.getControl(9012).l1l11l1111l_l1_(l1llll1l1lll_l1_)
		self.l1llll1l11l1_l1_,self.l1l1l111ll11_l1_,self.l1llll1l1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l1llll1lll_l1_ = args[5],args[6]
		self.l1l1llllll11_l1_,self.l1l1111llll1_l1_,self.l1l11l1lll11_l1_ = args[7],args[8],args[9]
		if self.l1l1111llll1_l1_>0 or self.l1l11l1lll11_l1_>0: self.l1l1ll1ll11l_l1_ = True
		else: self.l1l1ll1ll11l_l1_ = False
		self.l1ll1llllll1_l1_,self.l1111111ll1_l1_ = l1l11ll111ll_l1_(self.l1llll1l11l1_l1_,self.l1l1l111ll11_l1_,self.l1llll1l1lll_l1_,self.header,self.text,self.profile,self.l1l1llll1lll_l1_,self.l1l1llllll11_l1_,self.l1l1ll1ll11l_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1ll1llllll1_l1_)
		self.getControl(9050).setHeight(self.l1111111ll1_l1_)
		if not self.l1l1l111ll11_l1_ and self.l1llll1l11l1_l1_ and self.l1llll1l1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1ll1llllll1_l1_,self.l1111111ll1_l1_
	def l11l11l1111_l1_(self):
		if self.l1l1111llll1_l1_:
			import threading
			self.l11l1lll1ll_l1_ = threading.Thread(target=self.l1ll111l1111_l1_,args=())
			self.l11l1lll1ll_l1_.start()
			#self.l11l1lll1ll_l1_.join()
		else: self.enableButtons()
	def l1ll111l1111_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11ll111l1_l1_ in range(1,self.l1l1111llll1_l1_+1):
			time.sleep(1)
			l1l111l111ll_l1_ = int(100*l11ll111l1_l1_/self.l1l1111llll1_l1_)
			self.l1l11l11111l_l1_(l1l111l111ll_l1_)
			if self.l11l11l1l1l_l1_>0: break
		self.enableButtons()
	def l111llll111_l1_(self):
		if self.l1l11l1lll11_l1_:
			import threading
			self.l1l1ll111lll_l1_ = threading.Thread(target=self.l1lll1111l11_l1_,args=())
			self.l1l1ll111lll_l1_.start()
			#self.l1l1ll111lll_l1_.join()
		else: self.enableButtons()
	def l1lll1111l11_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1111llll1_l1_)
		for l11ll111l1_l1_ in range(self.l1l11l1lll11_l1_-1,-1,-1):
			time.sleep(1)
			l1l111l111ll_l1_ = int(100*l11ll111l1_l1_/self.l1l11l1lll11_l1_)
			self.l1l11l11111l_l1_(l1l111l111ll_l1_)
			if self.l11l11l1l1l_l1_>0: break
		if self.l1l11l1lll11_l1_>0: self.l11l11l1l1l_l1_ = 10
		self.delete()
	def l1l11l11111l_l1_(self,l1l111l111ll_l1_):
		self.l1ll1llll111_l1_ = l1l111l111ll_l1_
		self.getControl(9020).setPercent(self.l1ll1llll111_l1_)
	def enableButtons(self):
		if self.l1llll1l11l1_l1_!=l11lll_l1_ (u"ࠨࠩ㦳"): self.getControl(9010).setEnabled(True)
		if self.l1l1l111ll11_l1_!=l11lll_l1_ (u"ࠩࠪ㦴"): self.getControl(9011).setEnabled(True)
		if self.l1llll1l1lll_l1_!=l11lll_l1_ (u"ࠪࠫ㦵"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1ll1llllll1_l1_)
		except: pass
		#del self
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࡧࡩ࡫ࠦࡵࡱࡦࡤࡸࡪ࠮ࡳࡦ࡮ࡩ࠰ࡵ࡫ࡲࡤࡧࡱࡸ࠱࠰ࡡࡳࡩࡶ࠭࠿ࠓࠊࠊࠋࡷࡩࡽࡺࠠ࠾ࠢࡤࡶ࡬ࡹ࡛࠱࡟ࠐࠎࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡡࡳࡩࡶ࠭ࡃ࠷࠺ࠡࡶࡨࡼࡹࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࡢࡴࡪࡷࡠ࠷࡝ࠎࠌࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡦࡸࡧࡴࠫࡁ࠶࠿ࠦࡴࡦࡺࡷࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰ࡧࡲࡨࡵ࡞࠶ࡢࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡱࡧࡵࡧࡪࡴࡴ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷࠤࡂࠦࡰࡦࡴࡦࡩࡳࡺࠬࡵࡧࡻࡸࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡭࡫ࡩࡨࡪࡷࠤࡂࠦࡳࡦ࡮ࡩ࠲ࡨࡸࡥࡢࡶࡨࡗ࡭ࡵࡷࡊ࡯ࡤ࡫ࡪ࠮ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠴࠱ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠴࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯࠴࠯ࡷࡪࡲࡦ࠯ࡪࡨࡥࡩ࡫ࡲ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷ࠰ࡸ࡫࡬ࡧ࠰ࡳࡶࡴ࡬ࡩ࡭ࡧ࠯ࡷࡪࡲࡦ࠯ࡦ࡬ࡶࡪࡩࡴࡪࡱࡱ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡹ࡬ࡨࡹ࡮ࠬࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲࡸࡺࡩ࡮ࡧࡲࡹࡹ࠲ࡳࡦ࡮ࡩ࠲ࡨࡲ࡯ࡴࡧࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠑࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪࡳࡩࡷࡩࡥ࡯ࡶࠬࠑࠏࠏࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢ࡬ࡪ࡯ࡧࡩࡶࠐࠎࠎࠨࠢࠣ㦶")
class l11111lllll_l1_():
	def __init__(self,l1ll_l1_=False,l1l1ll1lll11_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1l1ll1lll11_l1_ = l1l1ll1lll11_l1_
		self.l1111ll11l1_l1_,self.l11l1l11l1l_l1_ = [],[]
		self.l1lll1l1ll11_l1_,self.l1ll1l1lll1l_l1_ = {},{}
		self.l1llllll111l_l1_ = []
		self.l1lll1l11l1l_l1_,self.l1l11l1l1111_l1_,self.l11l111l11l_l1_ = {},{},{}
	def l11111l11ll_l1_(self,id,func,*args):
		id = str(id)
		self.l1lll1l1ll11_l1_[id] = l11lll_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㦷")
		if self.l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ࠧ㦸"),id)
		# l1llllll11l1_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1llllll11l1_l1_ 2 & 3
		import threading
		l11l11l1lll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1llllll111l_l1_.append(l11l11l1lll_l1_)
		#l11l11l1lll_l1_.start()
		return l11l11l1lll_l1_
	def start_new_thread(self,id,func,*args):
		l11l11l1lll_l1_ = self.l11111l11ll_l1_(id,func,*args)
		l11l11l1lll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1lll1l11l1l_l1_[id] = time.time()
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㦹"),l11lll_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢ࡬ࡨ࠿ࠦࠧ㦺")+id)
		try:
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㦻"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄ࠻࠼ࠣࠫ㦼")+str(func))
			self.l1ll1l1lll1l_l1_[id] = func(*args)
			if l11lll_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ㦽") in str(func) and not self.l1ll1l1lll1l_l1_[id].succeeded:
				l1lll11l1111_l1_(l11lll_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ㦾"))
			self.l1111ll11l1_l1_.append(id)
			self.l1lll1l1ll11_l1_[id] = l11lll_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㦿")
			#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㧀"),l11lll_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠣ࡭ࡩࡀࠠࠨ㧁")+id)
		except Exception as err:
			#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㧂"),l11lll_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣ࡭ࡩࡀࠠࠨ㧃")+id)
			if self.l1l1ll1lll11_l1_:
				l1lll1lllll1_l1_ = traceback.format_exc()
				sys.stderr.write(l1lll1lllll1_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l1l11l1l_l1_.append(id)
			self.l1lll1l1ll11_l1_[id] = l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㧄")
		self.l1l11l1l1111_l1_[id] = time.time()
		self.l11l111l11l_l1_[id] = self.l1l11l1l1111_l1_[id] - self.l1lll1l11l1l_l1_[id]
	def l1l1ll1ll1ll_l1_(self):
		for proc in self.l1llllll111l_l1_:
			proc.start()
	def l1l111l1l111_l1_(self):
		while l11lll_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㧅") in list(self.l1lll1l1ll11_l1_.values()): time.sleep(1.000)
def l1l1lll1llll_l1_():
	l1l1l1lll11l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㧆"))
	l1llll11lll1_l1_ = True
	if l1l1l1lll11l_l1_==l11ll111111_l1_:
		status = l11lll_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ㧇")
		l1llll11lll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭㧈")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11lll_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ㧉")
	else:
		status = l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ㧊")
		l111l11l1ll_l1_ = [l11lll_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ㧋"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ㧌"),l11lll_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ㧍"),l11lll_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ㧎"),l11lll_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ㧏"),l11lll_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭㧐"),l11lll_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ㧑"),l11lll_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ㧒"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ㧓"),l11lll_l1_ (u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪ㧔")]
		l1ll1l1l1111_l1_ = l111l11l1ll_l1_[-1]
		l1llll1ll1ll_l1_ = l1l111l1111l_l1_(l1ll1l1l1111_l1_)
		l1ll11ll11ll_l1_ = l1l111l1111l_l1_(l11ll111111_l1_)
		if l1ll11ll11ll_l1_>l1llll1ll1ll_l1_:
			status = l11lll_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㧕")
			l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࠉࠊࡨ࡬ࡰࡪࡹࠠ࠾ࠢࡲࡷ࠳ࡲࡩࡴࡶࡧ࡭ࡷ࠮ࡡࡥࡦࡲࡲࡨࡧࡣࡩࡧࡩࡳࡱࡪࡥࡳࠫࠐࠎࠎࠏࠉࡧ࡫࡯ࡩࡸࠦ࠽ࠡࡵࡲࡶࡹ࡫ࡤࠩࡨ࡬ࡰࡪࡹࠬࡳࡧࡹࡩࡷࡹࡥ࠾ࡖࡵࡹࡪ࠯ࠍࠋࠋࠌࠍ࡫ࡵࡲࠡࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣ࡭ࡳࠦࡦࡪ࡮ࡨࡷ࠿ࠓࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡦࡤࡸࡦࡥࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࠦࡡ࡯ࡦࠣࠫ࠳ࡪࡢࠨࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫࠺ࠎࠌࠌࠍࠎࠏࠉࡰ࡮ࡧࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣࡢࠬ࠳࠰࠿ࠪ࡞࠱ࡨࡧ࠭ࠬࡧ࡫࡯ࡩࡳࡧ࡭ࡦ࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠓࠊࠊࠋࠌࠍࠎࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰࠣࡁࠥࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰ࡞࠴ࡢࠓࠊࠊࠋࠌࠍࠎࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰࡢࡧࡴࡳࡰࡢࡴࡨࠤࡂࠦࡖࡆࡔࡖࡍࡔࡔ࡟ࡄࡑࡐࡔࡆࡘࡅࡠࡒࡄࡖࡘࡋࡒࠩࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳ࠯ࠍࠋࠋࠌࠍࠎࠏࡩࡧࠢࠪࡱࡦ࡯࡮ࡥࡣࡷࡥࡤ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠿ࠓࠊࠊࠋࠌࠍࠎࠏࡩࡧࠢࡲࡰࡩࡥࡶࡦࡴࡶ࡭ࡴࡴ࡟ࡤࡱࡰࡴࡦࡸࡥ࠿࠿࡯ࡥࡸࡺࡦࡶ࡮࡯ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡤࡩ࡯࡮ࡲࡤࡶࡪࡀࠍࠋࠋࠌࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩࠥࡃࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡡࡥࡦࡲࡲࡨࡧࡣࡩࡧࡩࡳࡱࡪࡥࡳ࠮ࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠒࠐࠉࠊࠋࠌࠍࠎࠏࡴࡳࡻ࠽ࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡩࡧࠢࡲࡰࡩࡥࡤࡣࡨ࡬ࡰࡪࠧ࠽࡮ࡣ࡬ࡲࡤࡪࡢࡧ࡫࡯ࡩ࠿ࠦ࡯ࡴ࠰ࡵࡩࡳࡧ࡭ࡦࠪࡲࡰࡩࡥࡤࡣࡨ࡬ࡰࡪ࠲࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠒࠐࠉࠊࠋࠌࠍࠎࠏࠉࡴࡶࡤࡸࡺࡹࠠ࠾ࠢࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡢࡳࡧࡤ࡯ࠒࠐࠉࠊࠋࠌࠍࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠒࠐࠉࠊࠋࠥࠦࠧ㧖")
	return status,l1llll11lll1_l1_
def l1lll111lll1_l1_(l1l1l1l11ll_l1_,l1ll11l1l11l_l1_):
	succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,False
	type,name,l11lll11lll_l1_,mode,l11llll1111_l1_,l11l1l1ll1l_l1_,text,context,l1ll11111ll_l1_ = l1l1l1l11ll_l1_
	l1l11llll1ll_l1_ = type,name,l11lll11lll_l1_,mode,l11llll1111_l1_,l11l1l1ll1l_l1_,text,l11lll_l1_ (u"ࠩࠪ㧗"),l1ll11111ll_l1_
	l1l1ll11ll1l_l1_ = int(mode)
	l111111l111_l1_ = int(l1l1ll11ll1l_l1_%10)
	l1l1ll11lll1_l1_ = int(l1l1ll11ll1l_l1_/10)
	l1l111l11lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㧘"))
	l1llll1111ll_l1_,l1llll11lll1_l1_ = l1l1lll1llll_l1_()
	if l1llll11lll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㧙"),l11lll_l1_ (u"ࠬ࠭㧚"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㧛"),l11lll_l1_ (u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧ㧜")+l11ll111111_l1_)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㧝"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㧞"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㧟"),l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ㧠"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㧡"),l11lll_l1_ (u"࠭ࡁࡖࡖࡋࠫ㧢"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ㧣"),l11lll_l1_ (u"ࠨࠩ㧤"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩ㧥"),l11lll_l1_ (u"ࠪࠫ㧦"))
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭㧧"),l11lll_l1_ (u"ࠬ࠭㧨"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㧩"),l11lll_l1_ (u"ࠧࠨ㧪"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㧫"),l11lll_l1_ (u"ࠩࠪ㧬"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㧭"),l11lll_l1_ (u"ࠫࠬ㧮"))
		#settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㧯"),l11lll_l1_ (u"࠭ࠧ㧰"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㧱"),l11lll_l1_ (u"ࠨࠩ㧲"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ㧳"),l11lll_l1_ (u"ࠪࠫ㧴"))
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ㧵"),l11lll_l1_ (u"ࠬ࠭㧶"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩࡵࡵࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㧷"),l11lll_l1_ (u"ࠧࠨ㧸"))
		#if not l1l111l11lll_l1_: settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㧹"),l11lll_l1_ (u"ࠩࠪ㧺"))
		#l1l1l1lll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㧻"))
		#if l1l1l1lll11l_l1_:
		#	settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㧼"),l11lll_l1_ (u"ࠬ࠭㧽"))
		#	xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㧾"))
		#	return
		#l111l11ll11_l1_([main_dbfile])
		import l11ll1ll1ll_l1_
		if l1llll1111ll_l1_==l11lll_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㧿"):
			LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㨀"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㨁")+addon_path+l11lll_l1_ (u"ࠪࠤࡢ࠭㨂"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ㨃"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ㨄"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ㨅"))
		else:
			LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㨆"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㨇")+addon_path+l11lll_l1_ (u"ࠩࠣࡡࠬ㨈"))
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㨉"),l11lll_l1_ (u"ࠫࠬ㨊"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㨋"),l11lll_l1_ (u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ㨌"))
			l111l11ll11_l1_()
			FIX_ALL_DATABASES(False)
			user = l11llll111l_l1_(32)
			l11ll1ll1ll_l1_.l1l1l1111l11_l1_()
			l11ll1ll1ll_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㨍"),False)
			l11ll1ll1ll_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㨎"),False)
			l11ll1ll1ll_l1_.l1ll1lllll1l_l1_(False)
			l11ll1ll1ll_l1_.l1l11llll11l_l1_(False)
			l11ll1ll1ll_l1_.l1l1l11111l1_l1_(l11lll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㨏"),l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ㨐"),False)
			l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࠌࠍࡹࡸࡹ࠻ࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴࡨ࡬ࡰࡪ࠸ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡷࡶࡩࡷ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ࠮ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ࠭ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ࠯ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ࠭ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠷ࠦ࠽ࠡࡺࡥࡱࡨࡧࡤࡥࡱࡱ࠲ࡆࡪࡤࡰࡰࠫ࡭ࡩࡃࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧࠪࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠴࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨ࡭ࡲࡨ࡮ࡵ࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡲࡷࡤࡰ࡮ࡺࡹ࠯ࡣࡶ࡯ࠬ࠲ࠧࡵࡴࡸࡩࠬ࠯ࠍࠋࠋࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠐࠎࠎࠏࠉࠣࠤࠥ㨑")
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㨒"),l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㨓"),l11lll_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ㨔"),l11lll_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㨕"))
				l1l11l1111l1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭㨖"))
				l1l11l1111l1_l1_.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ㨗"),l11lll_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ㨘"))
			except: pass
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㨙"),l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㨚"),l11lll_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ㨛"),l11lll_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㨜"))
				l1l11l1111l1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭㨝"))
				l1l11l1111l1_l1_.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭㨞"),l11lll_l1_ (u"ࠫ࠸࠭㨟"))
			except: pass
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㨠"),l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㨡"),l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㨢"),l11lll_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㨣"))
				l1l11l1111l1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㨤"))
				l1l11l1111l1_l1_.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ㨥"),l11lll_l1_ (u"ࠫ࠷࠭㨦"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㨧"),l11lll_l1_ (u"࠭ࠧ㨨"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㨩"),l11lll_l1_ (u"ࠨวำห้ࠥๆหࠢอืฯิฯๆࠢัำ๊ฯࠠแࡋࡓࡘ࡛ࠦวๅ็๋ะํีษࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦสๅไสส๏อࠠษฮ็ฬ๋ࠥไโษอࠤๅࡏࡐࡕࡘࠣะิ๐ฯสࠩ㨪"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(dummym3ufile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㨫"),l11lll_l1_ (u"ࠪࠫ㨬"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㨭"),l11lll_l1_ (u"ࠬหะศࠢๆ๊ฯࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡓ࠳ࡖࠢส่๊๎ฬ้ัฬࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦแิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢอ่็อฦ๋ษࠣฬั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㨮"))
			#	import M3U
			#	M3U.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11lll11111_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l111l111l1_l1_)
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㨯"),l11ll111111_l1_)
		l11ll1ll1ll_l1_.l111lll11l1_l1_(False)
		#return
	#text = text.replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㨰"),l11lll_l1_ (u"ࠨࠩ㨱"))
	l1l1l11111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㨲"))
	l11l1lllll_l1_ = RESTORE_PATH_NAME(l1ll11l1l11l_l1_)
	l11ll1l1l11_l1_ = RESTORE_PATH_NAME(name)
	l1lll11l11l1_l1_ = [0,15,17,19,26,34,50,53]
	l1l1lllll1l1_l1_ = [0,15,17,19,26,34,50,53]
	l11l111lll1_l1_ = l1l1ll11lll1_l1_ not in l1l1lllll1l1_l1_
	l1l111l1l1l1_l1_ = l1l1ll11lll1_l1_ in [23,28,71,72]
	l1ll11l111l1_l1_ = l1l1ll11ll1l_l1_ in [265,270]
	l1ll1ll11l11_l1_ = (l11l111lll1_l1_ or l1l111l1l1l1_l1_) and not l1ll11l111l1_l1_
	l111l111ll1_l1_ = l1l1l11111_l1_!=l11lll_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㨳") and (l1l1l11111_l1_!=l11lll_l1_ (u"ࠫࠬ㨴") or context==l11lll_l1_ (u"ࠬ࠭㨵"))
	l1l1ll1l1l1l_l1_ = l11lll_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ㨶") in l1l1l11111_l1_
	l1l11lllll1l_l1_ = l1l1ll11ll1l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	SEARCH = l111111l111_l1_==9 or l1l1ll11ll1l_l1_ in [145,516,523]
	l111lllll1l_l1_ = not l1l11lllll1l_l1_
	l1111l1llll_l1_ = not SEARCH
	l1l1l1ll1l11_l1_ = l11l1lllll_l1_ in [l11lll_l1_ (u"ࠧࠨ㨷"),l11lll_l1_ (u"ࠨ࠰࠱ࠫ㨸")]
	l1llll1l1ll1_l1_ = l1l1l1ll1l11_l1_ or l111lllll1l_l1_
	l1lll11l1ll1_l1_ = l1l1l1ll1l11_l1_ or l1111l1llll_l1_ or l1l1ll1l1l1l_l1_
	l1l11l1l1l11_l1_ = l1l1ll11ll1l_l1_ not in [260,265,270,330,540]
	if l1l111l11lll_l1_: l1llll1l11ll_l1_ = SEARCH or l1l11lllll1l_l1_
	else: l1llll1l11ll_l1_ = True
	l1l1ll111l_l1_ = l1l1ll11lll1_l1_ in [74,75]
	l111lll1l11_l1_ = l1l1ll11ll1l_l1_ in [280,720]
	l1lllll111ll_l1_ = not l1l1ll111l_l1_ and not l111lll1l11_l1_
	l1ll11ll1l1l_l1_ = l1llll1l1ll1_l1_ and l1lll11l1ll1_l1_ and l1l11l1l1l11_l1_ and l1llll1l11ll_l1_ and l1lllll111ll_l1_
	l1111l1l11l_l1_ = l1l11l1l1l11_l1_ and l1llll1l11ll_l1_ and l1lllll111ll_l1_
	l111l1l11ll_l1_ = l1111l1l11l_l1_ and l111l111ll1_l1_ and l1ll11ll1l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㨹"),l11lll_l1_ (u"ࠪࠫ㨺"),l11lll_l1_ (u"ࠫࠬ㨻"),type+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㨼")+l1l1l11111_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㨽")+str(l1l1lllll1ll_l1_))
	l11l1l1l111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡶࡲࡰࡸ࡬ࡨࡪࡸࠧ㨾"))
	trans_code = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡣࡰࡦࡨࠫ㨿"))
	if 1 and l111l111ll1_l1_ and l1ll11ll1l1l_l1_:
		l1ll1l1ll1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㩀"),l11lll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㩁")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠫࡤ࠭㩂")+trans_code,l1l11llll1ll_l1_)
		if l1ll1l1ll1l1_l1_:
			#xbmcgui.Dialog().l1l11lll1111_l1_(l11lll_l1_ (u"ࠬ࠭㩃"),l11lll_l1_ (u"࠭ࡲࡦࡣࡧ࡭ࡳ࡭ࠠࡤࡣࡦ࡬ࡪ࠭㩄"),l11lll_l1_ (u"ࠧࠨ㩅"),100,False)
			LOG_THIS(l11lll_l1_ (u"ࠨࠩ㩆"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㩇")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠪࡣࠬ㩈")+trans_code+l11lll_l1_ (u"ࠫࠥࠦࠠࡍࡱࡤࡨ࡮ࡴࡧࠡ࡯ࡨࡲࡺࠦࡦࡳࡱࡰࠤࡨࡧࡣࡩࡧࠪ㩉"))
			if 1 and l1l1ll1l1l1l_l1_:
				#xbmcgui.Dialog().l1l11lll1111_l1_(l11lll_l1_ (u"ࠬ࠭㩊"),l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪࡾ࡯࡮ࡨࠢࡩࡥࡻࡵࡲࡪࡶࡨࡷࠬ㩋"),l11lll_l1_ (u"ࠧࠨ㩌"),100,False)
				l111lll1ll1_l1_ = []
				import l1l11ll11l1l_l1_,FAVORITES
				l1ll11l1l1ll_l1_ = l1l11ll11l1l_l1_.l1ll1l1l1l1l_l1_
				l111ll1llll_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lll1l1llll_l1_ = l1l1l11111_l1_
				l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll11l111ll_l1_,l1l1ll111l1l_l1_,l1l11ll11l11_l1_,l1lll111l1l1_l1_,l1111ll1l11_l1_,l1ll11111111_l1_,l1lll1111ll1_l1_ = EXTRACT_KODI_PATH(l1lll1l1llll_l1_)
				l1ll11l1lll1_l1_ = l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll11l111ll_l1_,l1l1ll111l1l_l1_,l1l11ll11l11_l1_,l1lll111l1l1_l1_,l1111ll1l11_l1_,l11lll_l1_ (u"ࠨࠩ㩍"),l1lll1111ll1_l1_
				#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㩎"),str(l1ll11l1lll1_l1_))
				for l1l1lll1l111_l1_ in l1ll1l1ll1l1_l1_:
					l1l1l11lllll_l1_ = l1l1lll1l111_l1_[l11lll_l1_ (u"ࠪࡱࡪࡴࡵࡊࡶࡨࡱࠬ㩏")]
					#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㩐"),str(l1l1l11lllll_l1_))
					if l1l1l11lllll_l1_==l1ll11l1lll1_l1_ or l1l1lll1l111_l1_[l11lll_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ㩑")] in [265,270]:
						l1l1lll1l111_l1_ = GET_LIST_ITEM(l1l1l11lllll_l1_,l1ll11l1l1ll_l1_,l111ll1llll_l1_)
						if l1l1lll1l111_l1_[l11lll_l1_ (u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ㩒")]:
							#xbmcgui.Dialog().l1l11lll1111_l1_(l11lll_l1_ (u"ࠧࠨ㩓"),l11lll_l1_ (u"ࠨࡷࡳࡨࡦࡺࡩ࡯ࡩࠣࡧࡴࡴࡴࡦࡺࡷࠫ㩔"),l11lll_l1_ (u"ࠩࠪ㩕"),100,False)
							l1l1l1lll1l1_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111ll1llll_l1_,l1l1l11lllll_l1_,l1l1lll1l111_l1_[l11lll_l1_ (u"ࠪࡲࡪࡽࡰࡢࡶ࡫ࠫ㩖")])
							#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㩗"),str(l1l1l1lll1l1_l1_))
							#LOG_THIS(l11lll_l1_ (u"ࠬ࠭㩘"),str(l1l1lll1l111_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㩙")]))
							l1l1lll1l111_l1_[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭㩚")] = l1l1l1lll1l1_l1_+l1l1lll1l111_l1_[l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ㩛")]
					l111lll1ll1_l1_.append(l1l1lll1l111_l1_)
				settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㩜"),l11lll_l1_ (u"ࠪࠫ㩝"))
				if type==l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩞"): WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㩟")+l11l1l1l111_l1_+l11lll_l1_ (u"࠭࡟ࠨ㩠")+trans_code,l1l11llll1ll_l1_,l111lll1ll1_l1_,REGULAR_CACHE)
			else: l111lll1ll1_l1_ = l1ll1l1ll1l1_l1_
			if type==l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩡") and l11l1lllll_l1_!=l11lll_l1_ (u"ࠨ࠰࠱ࠫ㩢") and l1ll1ll11l11_l1_: l11lll1llll_l1_()
			l1111llll11_l1_ = CREATE_KODI_MENU(l1l11llll1ll_l1_,l111lll1ll1_l1_,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
			#xbmcgui.Dialog().l1l11lll1111_l1_(l11lll_l1_ (u"ࠩࠪ㩣"),l11lll_l1_ (u"ࠪࡧࡷ࡫ࡡࡵ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠪ㩤"),l11lll_l1_ (u"ࠫࠬ㩥"),100,False)
			return
	elif type==l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩦") and l1l1l11111_l1_==l11lll_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㩧") and l1111l1l11l_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㩨"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㩩")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠩࡢࠫ㩪")+trans_code+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡦ࡮ࡨࡸ࡮ࡴࡧࠡࡱ࡯ࡨࠥࡩࡡࡤࡪࡨࡨࠥࡳࡥ࡯ࡷࠪ㩫"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㩬")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠬࡥࠧ㩭")+trans_code,l1l11llll1ll_l1_)
	#context = l11lll_l1_ (u"࠭ࠧ㩮")
	if l11lll_l1_ (u"ࠧࡠࠩ㩯") in context: l1l1llllll1l_l1_,l1l11l1ll111_l1_ = context.split(l11lll_l1_ (u"ࠨࡡࠪ㩰"),1)
	else: l1l1llllll1l_l1_,l1l11l1ll111_l1_ = context,l11lll_l1_ (u"ࠩࠪ㩱")
	if l1l1llllll1l_l1_ in [l11lll_l1_ (u"ࠪ࠵ࠬ㩲"),l11lll_l1_ (u"ࠫ࠷࠭㩳"),l11lll_l1_ (u"ࠬ࠹ࠧ㩴"),l11lll_l1_ (u"࠭࠴ࠨ㩵"),l11lll_l1_ (u"ࠧ࠶ࠩ㩶")] and l1l11l1ll111_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㩷") l11l11llll_l1_ l1l11llll1l1_l1_ l1l11l111lll_l1_ is no addon_handle l1l11l11l_l1_ to l111l111l1l_l1_ for l1ll1ll11lll_l1_ directory
		#l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩࠬ㩸") l11l11llll_l1_ to open a menu list using l1l11lllllll_l1_ addon_path
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ㩹")+sys.argv[0]+addon_path.split(l11lll_l1_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃࠧ㩺"))[0]+l11lll_l1_ (u"ࠬࠬࡣࡰࡰࡷࡩࡽࡺ࠽࠱ࠩ㩻")+l11lll_l1_ (u"ࠨࠩࠣ㩼"))
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㩽")+addon_id+l11lll_l1_ (u"ࠨ࠱ࡂࡸࡪࡾࡴ࠾ࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠬࠫ㩾"))
		# l1111l1l1l_l1_ not remove addon_path .. it is needed to update l1l1l1lll1ll_l1_ status
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㩿"),addon_path)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㪀"))
		return
	elif l1l1llllll1l_l1_==l11lll_l1_ (u"ࠫ࠻࠭㪁"):
		if l1l11l1ll111_l1_==l11lll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㪂"): DIALOG_NOTIFICATION(l11lll_l1_ (u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭㪃"),l11lll_l1_ (u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ㪄"))
		elif l1l11l1ll111_l1_==l11lll_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠨ㪅"): l1l1ll11ll1l_l1_ = 334
		results = l1l1l1l111l1_l1_(type,l11ll1l1l11_l1_,l11lll11lll_l1_,l1l1ll11ll1l_l1_,l11llll1111_l1_,l11l1l1ll1l_l1_,text,context,l1ll11111ll_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㪆"))
		return
	elif context==l11lll_l1_ (u"ࠪ࠻ࠬ㪇"):
		import l1ll11lll11_l1_
		l1ll11lll11_l1_.l1l1l1l1111_l1_()
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㪈"))
		return
	elif context==l11lll_l1_ (u"ࠬ࠾ࠧ㪉"):
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㪊")+addon_id+l11lll_l1_ (u"ࠧࡀ࡯ࡲࡨࡪࡃࠧ㪋")+str(mode)+l11lll_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠩࠨ㪌"))
		return
	elif context==l11lll_l1_ (u"ࠩ࠼ࠫ㪍"):
		# l1l1lll11lll_l1_ update the l1l111ll11ll_l1_ menu
		#results = l1l1l1l111l1_l1_(type,l11ll1l1l11_l1_,l11lll11lll_l1_,mode,l11llll1111_l1_,l11l1l1ll1l_l1_,text,context,l1ll11111ll_l1_)
		# l1l1lll11lll_l1_ update the l1ll1l1llll1_l1_ menu
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㪎"),l11lll_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ㪏"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㪐"))
		return
	if settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㪑")) not in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ㪒"),l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭㪓"),l11lll_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ㪔")]: settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㪕"),l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㪖"))
	if not settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㪗")): settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭㪘"),l1lll1l11lll_l1_[0])
	l1l111ll1lll_l1_ = False if l11l1llll1l_l1_(l11lll_l1_ (u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ㪙")) else True
	l11l11l11ll_l1_ = l1lll1111_l1_ if l1l111ll1lll_l1_ else REGULAR_CACHE
	l111lllllll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㪚"))
	l1l11l1l1l1l_l1_ = l1lll111ll1l_l1_(settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㪛")))
	l1l11l1l1l1l_l1_ = 0 if not l1l11l1l1l1l_l1_ else int(l1l11l1l1l1l_l1_)
	if l111lllllll_l1_ in [l11lll_l1_ (u"ࠪࠫ㪜"),l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㪝")] or not l11l11l11ll_l1_ or not l1l11l1l1l1l_l1_ or now-l1l11l1l1l1l_l1_<0 or now-l1l11l1l1l1l_l1_>l11l11l11ll_l1_:
		l111lllllll_l1_ = l11111l1ll1_l1_(True,False)
	l11l111l1l1_l1_ = l1lll111ll1l_l1_(settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪࠧ㪞")))
	l11l111l1l1_l1_ = 0 if not l11l111l1l1_l1_ else int(l11l111l1l1_l1_)
	l1111ll1111_l1_ = l1lll111ll1l_l1_(settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㪟")))
	l1111ll1111_l1_ = 0 if not l1111ll1111_l1_ else int(l1111ll1111_l1_)
	if not l11l111l1l1_l1_ or not l1111ll1111_l1_ or now-l1111ll1111_l1_<0 or now-l1111ll1111_l1_>l11l111l1l1_l1_:
		auth = 1
		if l1l111ll1lll_l1_:
			# https://www.l1lll1l1111l_l1_.com/l1l1l1111l1l_l1_/l111111111l_l1_
			# unescapeHTML(l11lll_l1_ (u"ࠧࠡࠨࠦࡼ࠷࠼࠳ࡃ࠽ࠣࠪࠨࡾ࠲࠸࠳ࡇ࠿ࠥࠬࠣࡹ࠴࠹࠶ࡆࡁࠠࠧࠥࡻ࠶࠻࠹ࡂ࠼ࠩ㪠"))
			#l1ll11ll1111_l1_ = l11lll_l1_ (u"ࠨ⸽ࠣ⼡ࠥࠦ⾊ࠡࠢ⸭ࠤ⹀࠭㪡")
			#l1lll11111l1_l1_ = l11lll_l1_ (u"ࠩ⸾ࠤ⼢ࠦࠠ⾌ࠢࠣ⸮ࠥ⹁ࠧ㪢")
			l1l1l1l1111l_l1_ = l11l1111ll1_l1_(True)
			if len(l1l1l1l1111l_l1_)>1:
				LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㪣"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㪤")+addon_path+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㪥"))
				id,l1l1111lllll_l1_,l1l11l111ll1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l1l1111l_l1_[0]
				#if l11lll_l1_ (u"࠭࡜࡯࠽࠾ࠫ㪦") in reason: l1l1llll11l1_l1_,l1l1llll11ll_l1_,l1l1llll1l11_l1_ = reason.split(l11lll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㪧"),2)
				#else: l1l1llll11l1_l1_,l1l1llll11ll_l1_,l1l1llll1l11_l1_ = reason,reason,reason
				l1lll1l1ll1l_l1_,l1lll1l1lll1_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㪨"))
				del l1l1l1l1111l_l1_[0]
				l1l1ll11llll_l1_ = random.sample(l1l1l1l1111l_l1_,1)
				id,l1l1111lllll_l1_,l1l11l111ll1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1ll11llll_l1_[0]
				l1l11l111ll1_l1_ = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠾ࠥ࠭㪩")+id+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㪪")+l1l11l111ll1_l1_
				l11111l1l11_l1_ = l11lll_l1_ (u"ࠫสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠩ㪫")
				l1ll1lll1lll_l1_ = l11lll_l1_ (u"ࠬอไหสิ฽ฬะࠧ㪬")
				l1llll1l11l1_l1_,l1l1l111ll11_l1_ = l11111lll11_l1_,l11111l1l11_l1_
				l11l1l11_l1_ = [l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1ll1lll1lll_l1_]
				l1111111l11_l1_ = 5 if l11l1llll1l_l1_(l11lll_l1_ (u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ㪭")) else 15
				choice = -9
				while choice<0:
					l1111ll1lll_l1_ = random.sample(l11l1l11_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ㪮"),l1111ll1lll_l1_[0],l1111ll1lll_l1_[1],l1111ll1lll_l1_[2],l1lll1l1ll1l_l1_,l1l11l111ll1_l1_,l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㪯"),l1111111l11_l1_,60)
					if choice==10: break
					import l11ll1ll1ll_l1_
					if choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ㪰"),l11lll_l1_ (u"ࠪࠫ㪱"),l11lll_l1_ (u"ࠫ฾๎ฯสࠩ㪲"),l11lll_l1_ (u"ࠬ࠭㪳"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㪴"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ั๎วษࠢั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ㪵")+reason,l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㪶"),20)
						l11ll1ll1ll_l1_.l1l1lll111l1_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[2]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ㪷"),l11lll_l1_ (u"ࠪࠫ㪸"),l1ll1lll1lll_l1_,l11lll_l1_ (u"ࠫࠬ㪹"),l1lll1l1ll1l_l1_,l1l11l111ll1_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㪺")+l11l1l11_l1_[0]+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㪻"),l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㪼"),30)
						l11ll1ll1ll_l1_.l11lll1l11l_l1_(False)
					if choice==-1: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㪽"),l11lll_l1_ (u"ࠩࠪ㪾"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㪿"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭㫀"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㫁"),l1l1lll11l1l_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㫂"),l11lll_l1_ (u"ࠧࡂࡗࡗࡌࠬ㫃"),auth,PERMANENT_CACHE)
	# l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㫄")	l111l111l1l_l1_ file to read/write the l1l1l11lll11_l1_ menu list
	# l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㫅")		no l11l1l11111_l1_ l1l11llll111_l1_ to the l1l1l11lll11_l1_ menu list
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࡕࡌࡘࡊ࡙࡟ࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡌࡘࡊ࡙࡟ࡎࡑࡇࡉࡘࠦࡡ࡯ࡦࠣࡱࡴࡪࡥ࠲࠿ࡀ࠽ࠒࠐࠉࡐࡖࡋࡉࡗࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠻ࠬ࠶࠳࠹࠰࠺࠸࠳࡞ࠏࠍࠍࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁ࡙ࠥࡉࡕࡇࡖࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡳࡷࠦࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠑࠏࠏࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠷ࡃ࠽࠲࠸ࠣࡥࡳࡪࠠ࡮ࡱࡧࡩ࠵ࠧ࠽࠲࠸࠳ࠑࠏࠏ࡙ࡐࡗࡗ࡙ࡇࡋ࡟ࡎࡇࡑ࡙ࡘࠦ࠽ࠡ࡯ࡲࡨࡪ࠶ࠠࡪࡰࠣ࡟࠶࠺࠴࡞ࠏࠍࠍࠨࡴࡡ࡮ࡧࡢࠤࡂࠦࡃࡍࡇࡄࡒࡤࡓࡅࡏࡗࡢࡐࡆࡈࡅࡍࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡳࡧ࡭ࡦࡡࠣࡁࠥࡘࡅࡔࡖࡒࡖࡊࡥࡐࡂࡖࡋࡣࡓࡇࡍࡆࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡗࡋࡍࡆࡏࡅࡉࡗࡥࡒࡆࡕࡘࡐ࡙࡙࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣࡖࡆࡔࡄࡐࡏࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠒࠐࠉࡪࡨࠣࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗ࠿ࠓࠊࠊࠋࠦ࡭࡫ࠦࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗ࠿ࠦࡣࡰࡰࡧ࠵ࠥࡃࠠࠩ࡯ࡨࡲࡺࡥ࡬ࡢࡤࡨࡰࠥ࡯࡮ࠡ࡝ࠪ࠲࠳࠭ࠬࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫࡢ࠯ࠍࠋࠋࠌࠧࡪࡲࡩࡧࠢࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓ࠻ࠢࡦࡳࡳࡪ࠱ࠡ࠿ࠣࠬࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࠎ࡯ࡦࠡࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠠࡪࡰࠣࡸࡪࡾࡴࠡࡣࡱࡨࠥࡳࡥ࡯ࡷࡢࡰࡦࡨࡥ࡭ࠣࡀࡲࡦࡳࡥࡠࠢࡤࡲࡩࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨ࡭ࡣࡶࡸࡲ࡫࡮ࡶࡨ࡬ࡰࡪ࠯࠺ࠎࠌࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠲ࠥࠦࡒࡦࡣࡧ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡱ࡯ࡨࡋࡏࡌࡆࠢࡀࠤࡴࡶࡥ࡯ࠪ࡯ࡥࡸࡺ࡭ࡦࡰࡸࡪ࡮ࡲࡥ࠭ࠩࡵࡦࠬ࠯࠮ࡳࡧࡤࡨ࠭࠯ࠍࠋࠋࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦ࡯࡭ࡦࡉࡍࡑࡋࠠ࠾ࠢࡲࡰࡩࡌࡉࡍࡇ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠑࠏࠏࠉࠊ࡯ࡨࡲࡺࡏࡴࡦ࡯ࡶࡐࡎ࡙ࡔ࡜࠼ࡠࠤࡂࠦࡅࡗࡃࡏࠬࠬࡲࡩࡴࡶࠪ࠰ࡴࡲࡤࡇࡋࡏࡉ࠮ࠓࠊࠊࠋࡨࡰࡸ࡫࠺ࠎࠌࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠲ࠥࠦࡗࡳ࡫ࡷ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡴࡨࡷࡺࡲࡴࡴࠢࡀࠤࡒࡇࡉࡏࡡࡇࡍࡘࡖࡁࡕࡅࡋࡉࡗ࠮ࡴࡺࡲࡨ࠰ࡳࡧ࡭ࡦࡡ࠯ࡹࡷࡲ࡟࠭࡯ࡲࡨࡪ࠲ࡩ࡮ࡣࡪࡩࡤ࠲ࡰࡢࡩࡨࡣ࠱ࡺࡥࡹࡶ࠯ࡧࡴࡴࡴࡦࡺࡷ࠰࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠯ࠍࠋࠋࠌࠍࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠࡴࡶࡵࠬࡲ࡫࡮ࡶࡋࡷࡩࡲࡹࡌࡊࡕࡗ࠭ࠒࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠ࡯ࡧࡺࡊࡎࡒࡅ࠯ࡧࡱࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠏࠍࠍࠎࠏ࡯ࡱࡧࡱࠬࡱࡧࡳࡵ࡯ࡨࡲࡺ࡬ࡩ࡭ࡧ࠯ࠫࡼࡨࠧࠪ࠰ࡺࡶ࡮ࡺࡥࠩࡰࡨࡻࡋࡏࡌࡆࠫࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡃࠠࡎࡃࡌࡒࡤࡊࡉࡔࡒࡄࡘࡈࡎࡅࡓࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩࡤ࠲ࡵࡳ࡮ࡢ࠰ࡲࡵࡤࡦ࠮࡬ࡱࡦ࡭ࡥࡠ࠮ࡳࡥ࡬࡫࡟࠭ࡶࡨࡼࡹ࠲ࡣࡰࡰࡷࡩࡽࡺࠬࡪࡰࡩࡳࡩ࡯ࡣࡵࠫࠐࠎࠎࠨࠢࠣ㫆")
	results = l1l1l1l111l1_l1_(type,l11ll1l1l11_l1_,l11lll11lll_l1_,mode,l11llll1111_l1_,l11l1l1ll1l_l1_,text,context,l1ll11111ll_l1_)
	# l1111ll111l_l1_ l1llll11ll11_l1_: succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,True
	# l1lll1llll11_l1_ = True => l1ll1l1l1lll_l1_ this list is l1l1l1llllll_l1_ and will exit to main menu
	# l1lll1llll11_l1_ = False => l1ll1l1l1lll_l1_ this list is l1llllll1l1l_l1_ and will exit to l1l1l11lll11_l1_ menu
	# l111ll1l1l1_l1_ = True => will cause the l1l111l11ll1_l1_ status to l1l111l1ll1l_l1_ l1l1ll1l1111_l1_
	# l111ll1l1l1_l1_ = False => will l1l1ll11l11l_l1_ the l1l111l11ll1_l1_ status to l111l111l11_l1_ l1llll1ll11l_l1_
	#succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,True
	#if not l11l1l1111l_l1_: l111ll1l1l1_l1_ = False
	if l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㫇") in text: l1lll1llll11_l1_ = True
	if type==l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㫈"):
		if l11l1lllll_l1_!=l11lll_l1_ (u"࠭࠮࠯ࠩ㫉") and l1ll1ll11l11_l1_: l11lll1llll_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡪࡰࡷࠫ㫊"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㫋"),l11lll_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ㫌")) or l1l1ll11ll1l_l1_ not in l1lll11l11l1_l1_) and not l11l1llll1l_l1_(l11lll_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㫍")):
				import l1l11ll11l1l_l1_
				l1ll1l1ll1l1_l1_ = GET_ALL_LIST_ITEMS(l1l11ll11l1l_l1_.l1ll1l1l1l1l_l1_)
				l1111llll11_l1_ = CREATE_KODI_MENU(l1l11llll1ll_l1_,l1ll1l1ll1l1_l1_,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
				if 1 and l1ll1l1ll1l1_l1_ and l111l1l11ll_l1_:
					#xbmcgui.Dialog().l1l11lll1111_l1_(l11lll_l1_ (u"ࠫࠬ㫎"),l11lll_l1_ (u"ࠬࡽࡲࡪࡶ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࠬ㫏"),l11lll_l1_ (u"࠭ࠧ㫐"),100,False)
					WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㫑")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠨࡡࠪ㫒")+trans_code,l1l11llll1ll_l1_,l1ll1l1ll1l1_l1_,REGULAR_CACHE)
				#elif 1 and not l1ll1l1ll1l1_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㫓")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠪࡣࠬ㫔")+trans_code,l1l11llll1ll_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ㫕")+addon_id+l11lll_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ㫖"),xbmcgui.ListItem(l11lll_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ㫗")))
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㫘")+addon_id+l11lll_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ㫙"),xbmcgui.ListItem(l11lll_l1_ (u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ㫚")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
	return
def l1l1l1l111l1_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_):
	l1l1ll11ll1l_l1_ = int(mode)
	l1l1ll11lll1_l1_ = int(l1l1ll11ll1l_l1_//10)
	if   l1l1ll11lll1_l1_==0:  import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==1:  import l111l1l1_l1_ 		; results = l111l1l1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==2:  import l1l1l1111ll_l1_ 		; results = l1l1l1111ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==3:  import l1111l111ll_l1_ 		; results = l1111l111ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==4:  import l1l1l1lll_l1_ 	; results = l1l1l1lll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==5:  import l11l111l111_l1_ 	; results = l11l111l111_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==6:  import l1ll11ll1_l1_ 	; results = l1ll11ll1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==7:  import l1l111l_l1_ 		; results = l1l111l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==8:  import l1l1l111l11_l1_ 	; results = l1l1l111l11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==9:  import l1ll1lll1l_l1_		; results = l1ll1lll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==10: import l1ll11l11lll_l1_ 		; results = l1ll11l11lll_l1_.MAIN(l1l1ll11ll1l_l1_,url)
	elif l1l1ll11lll1_l1_==11: import l1l1l11l1l11_l1_ 	; results = l1l1l11l1l11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==12: import l11111ll1l_l1_ 		; results = l11111ll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==13: import l1l1ll111_l1_	; results = l1l1ll111_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==14: import l111llll11l_l1_ 		; results = l111llll11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_,name,l11l_l1_)
	elif l1l1ll11lll1_l1_==15: import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==16: import l1l11lllll1l_l1_	 	; results = l1l11lllll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==17: import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==18: import l1l111ll111l_l1_	; results = l1l111ll111l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==19: import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==20: import l111lll1l_l1_		; results = l111lll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==21: import l11111111ll_l1_ ; results = l11111111ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==22: import l1ll1ll1l11_l1_ 	; results = l1ll1ll1l11_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==23: import IPTV 		; results = IPTV.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==24: import l111111_l1_ 		; results = l111111_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==25: import l11l1l111_l1_ 	; results = l11l1l111_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==26: import l1l11ll11l1l_l1_ 		; results = l1l11ll11l1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1l1ll11ll1l_l1_,context)
	elif l1l1ll11lll1_l1_==28: import IPTV 		; results = IPTV.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==29: import l111l1lll1l_l1_	; results = l111l1lll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==30: import l1ll1l1lll_l1_		; results = l1ll1l1lll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==31: import l1111l1l1l1_l1_	; results = l1111l1l1l1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==32: import l1l11l1l1l1_l1_	; results = l1l11l1l1l1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==33: import l11l111lll_l1_		; results = l11l111lll_l1_.MAIN(l1l1ll11ll1l_l1_,url)
	elif l1l1ll11lll1_l1_==34: import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==35: import l1l1l111_l1_		; results = l1l1l111_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==36: import l1ll1111ll11_l1_		; results = l1ll1111ll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==37: import l1111l11l_l1_		; results = l1111l11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==38: import l1l1ll111ll1_l1_ 		; results = l1l1ll111ll1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==39: import l1l1llll11l_l1_	; results = l1l1llll11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==40: import l11lll1lll_l1_	; results = l11lll1lll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11lll1_l1_==41: import l11lll1lll_l1_	; results = l11lll1lll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11lll1_l1_==42: import l1llllllll_l1_		; results = l1llllllll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==43: import l1ll1l1l1ll_l1_		; results = l1ll1l1l1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==44: import l1ll1l1ll11_l1_		; results = l1ll1l1ll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==45: import l11l11ll11l_l1_		; results = l11l11ll11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==46: import l1lll11l1l1l_l1_		; results = l1lll11l1l1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==47: import l1ll1ll11l_l1_	; results = l1ll1ll11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==48: import l1l11ll1ll1l_l1_		; results = l1l11ll1ll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==49: import l1lll11l1l_l1_		; results = l1lll11l1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==50: import l11ll1ll1ll_l1_ 	; results = l11ll1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,text)
	elif l1l1ll11lll1_l1_==51: import l1ll11ll1ll_l1_ 	; results = l1ll11ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==52: import l1ll11ll1ll_l1_ 	; results = l1ll11ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==53: import l1l11ll11l1l_l1_ 		; results = l1l11ll11l1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==54: import l1ll11lll11_l1_	; results = l1ll11lll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll11lll1_l1_==55: import l1lll1l111_l1_ 	; results = l1lll1l111_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==56: import l1l1l11ll1ll_l1_		; results = l1l1l11ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==57: import l1l1lll1lll_l1_		; results = l1l1lll1lll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==58: import l111ll1ll1l_l1_	; results = l111ll1ll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==59: import l1l1lll111l_l1_		; results = l1l1lll111l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==60: import l1l1ll1ll1l_l1_		; results = l1l1ll1ll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==61: import l1ll1ll_l1_		; results = l1ll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==62: import l1l1lllll11_l1_		; results = l1l1lllll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==63: import l1lll11ll1_l1_		; results = l1lll11ll1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==64: import l1lll1lll1ll_l1_		; results = l1lll1lll1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==65: import l111111l1_l1_		; results = l111111l1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==66: import l111llllll1_l1_		; results = l111llllll1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==67: import l1l11l11l11_l1_		; results = l1l11l11l11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==68: import l111lll1l1_l1_		; results = l111lll1l1_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==69: import l1111111l_l1_		; results = l1111111l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==70: import l1l111l11ll_l1_		; results = l1l111l11ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==71: import M3U			; results = M3U.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==72: import M3U			; results = M3U.MAIN(l1l1ll11ll1l_l1_,url,text,type,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==73: import l1l11ll11_l1_	; results = l1l11ll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,text)
	elif l1l1ll11lll1_l1_==74: import l1l1ll111l_l1_		; results = l1l1ll111l_l1_.MAIN(l1l1ll11ll1l_l1_)
	elif l1l1ll11lll1_l1_==75: import l1l1ll111l_l1_		; results = l1l1ll111l_l1_.MAIN(l1l1ll11ll1l_l1_)
	elif l1l1ll11lll1_l1_==76: import l1l11lllll1l_l1_	 	; results = l1l11lllll1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,text,l1l11l1_l1_,l1ll11111ll_l1_)
	elif l1l1ll11lll1_l1_==77: import l1llll1ll11_l1_ 	; results = l1llll1ll11_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==78: import l1lll1l1l1l_l1_ 	; results = l1lll1l1l1l_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==79: import l1lll11l1ll_l1_ 	; results = l1lll11l1ll_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11lll1_l1_==80: import l1lll11l11l_l1_ 	; results = l1lll11l11l_l1_.MAIN(l1l1ll11ll1l_l1_,url,l1l11l1_l1_,text)
	else: results = None
	return results
def l11l1ll111_l1_(name=l11lll_l1_ (u"ࠪࠫ㫛")):
	if not name: name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ㫜"))
	name = name.replace(l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㫝"),l11lll_l1_ (u"࠭ࠧ㫞"))
	name = name.replace(l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠬ㫟"),l11lll_l1_ (u"ࠨࠢࠪ㫠")).replace(l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㫡"),l11lll_l1_ (u"ࠪࠤࠬ㫢")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ㫣"),l11lll_l1_ (u"ࠬࠦࠧ㫤")).strip(l11lll_l1_ (u"࠭ࠠࠨ㫥"))
	name = name.replace(l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㫦"),l11lll_l1_ (u"ࠨࠩ㫧")).replace(l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㫨"),l11lll_l1_ (u"ࠪࠫ㫩"))
	tmp = re.findall(l11lll_l1_ (u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠࠨ㫪"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11lll_l1_ (u"ࠬࡓࡡࡪࡰࠣࡑࡪࡴࡵࠨ㫫")
	return name
def l1ll1l1l1ll1_l1_(code,reason,source,l1ll_l1_):
	l1lll1111l1l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㫬"))
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㫭"),l11lll_l1_ (u"ࠨࠩ㫮"))
	if l11lll_l1_ (u"ࠩ࠰ࠫ㫯") in source: l1l1l1l1ll1_l1_ = source.split(l11lll_l1_ (u"ࠪ࠱ࠬ㫰"),1)[0]
	else: l1l1l1l1ll1_l1_ = source
	l1111llll1l_l1_ = code in [7,11001,11002,10054]
	l1l111l1ll11_l1_ = reason.lower()
	l1ll1l111l1l_l1_ = code in [0,104,10061,111]
	l1ll1l111l11_l1_ = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㫱") in l1l111l1ll11_l1_
	l1ll1l1111ll_l1_ = l11lll_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ㫲") in l1l111l1ll11_l1_
	l1ll1l1111l1_l1_ = l11lll_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭㫳") in l1l111l1ll11_l1_
	l1ll1l11111l_l1_ = l11lll_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ㫴") in l1l111l1ll11_l1_
	l1l1l11111ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ㫵"))
	l1l11ll111l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㫶"))
	l1lll11lll1l_l1_ = l11lll_l1_ (u"ࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ㫷")
	l1l1ll1ll111_l1_ = l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠫ㫸")+str(code)+l11lll_l1_ (u"ࠬࡀࠠࠨ㫹")+reason
	l1l1ll1ll111_l1_ = l111l_l1_(l1l1ll1ll111_l1_)
	if l1ll1l111l1l_l1_ or l1ll1l111l11_l1_ or l1ll1l1111ll_l1_ or l1ll1l1111l1_l1_ or l1ll1l11111l_l1_:
		l1lll11lll1l_l1_ += l11lll_l1_ (u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣฬฬ๊ๅ้ไ฼ࡠࡳ࠭㫺")
	if l1111llll1l_l1_: l1lll11lll1l_l1_ += l11lll_l1_ (u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࡡࡴࠧ㫻")
	l1l1ll1ll111_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㫼")+l1l1ll1ll111_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㫽")
	if l1l1l11111ll_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ㫾") or l1l11ll111l1_l1_==l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ㫿"):
		l1lll11lll1l_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊่ࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㬀")
	l11l1111l11_l1_ = False
	if l1ll_l1_ and source not in l1lllllll111_l1_:
		if l1l1l11111ll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ㬁") or l1l11ll111l1_l1_==l11lll_l1_ (u"ࠧࡂࡕࡎࠫ㬂"):
			#if kodi_version<19: l1l1ll1ll111_l1_ = l1l1ll1ll111_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㬃"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㬄"),l11lll_l1_ (u"ࠪาึ๎ฬࠨ㬅"),l11lll_l1_ (u"ࠫสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠩ㬆"),l11lll_l1_ (u"ࠬหีๅษะࠤฬ๊ๅีๅ็อࠬ㬇"),l1l1l1l1ll1_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㬈")+TRANSLATE(l1l1l1l1ll1_l1_),l1lll11lll1l_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㬉")+l1l1ll1ll111_l1_)
			if choice==1:
				import l11ll1ll1ll_l1_
				l11ll1ll1ll_l1_.l1l1lll111l1_l1_()
			elif choice==2: l11l1111l11_l1_ = True
		else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㬊"),l11lll_l1_ (u"ࠩࠪ㬋"),l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㬌")+TRANSLATE(l1l1l1l1ll1_l1_),l1lll11lll1l_l1_,l1l1ll1ll111_l1_)
	#if reason.endswith(l11lll_l1_ (u"ࠫࠥ࠯ࠧ㬍")): reason = reason.rsplit(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㬎"))[0]
	#if l11l1111l11_l1_: LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㬏"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㬐")+str(code)+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㬑")+reason+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㬒")+source+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡃࡕࡅࡇࡏࡃ࠻ࠢ࡞ࠤࠬ㬓")+l1lll11lll1l_l1_+l11lll_l1_ (u"ࠫࠥࡣ࡝ࠡࠢࠣࡉࡓࡍࡌࡊࡕࡋ࠾ࠥࡡࠠࠨ㬔")+l1l1ll1ll111_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㬕"))
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㬖"),l1lll1111l1l_l1_)
	return l11l1111l11_l1_
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡦࡱࡷࠥࡵࡲࠡࡤ࡯ࡳࡨࡱࡥࡥ࠳ࠣࡳࡷࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠲ࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠸ࡀࠍࠋࠋࠌࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠤࡂࠦࠧ็๊฼ࠤ๊์ࠠศๆะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅ࠱ࠫࠒࠐࠉࠊ࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠤ࠰ࡃࠠࠨ๊่ࠢࠥะั๋ัࠣฮๆอี๋ๆࠣห่ััࠡมࠪࠑࠏࠏࠉࡪࡨࠣࡨࡳࡹ࠺ࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇࠥࡃࠠࠨๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้ࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠭ࡀࠤ่ࠬࠦศๆึฬอࠦโะࠢํ็ํ์ࠠࠨ࠭ࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠐࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇࠥࡃࠠࠨ้ำหࠥอไๆ๊ๅ฽ࠥ็๊่ࠢࠪ࠯ࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠒࠐࠉࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ࠯ࡐࡔࡍࡇࡊࡐࡊࠬࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠫ࠮ࠫࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ࠰ࡹ࡯ࡶࡴࡦࡩ࠰࠭ࠠ࡞ࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ࠫࡴࡶࡵࠬࡨࡵࡤࡦࠫ࠮ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ࠫࡳࡧࡤࡷࡴࡴࠫࠨࠢࡠࠤࠥࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠯ࠬࠦ࡝࡞ࠢࠣࠤࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠿࡛ࠦࠡࠩ࠮ࡱࡪࡹࡳࡢࡩࡨࡉࡓࡍࡌࡊࡕࡋ࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࡩࡧࠢࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹ࠺ࠎࠌࠌࠍࠎࡿࡥࡴࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣ࡞ࡋࡓࡏࡑࠫࠫࡨ࡫࡮ࡵࡧࡵࠫ࠱ࡹࡩࡵࡧ࠮ࠫࠥࠦࠠࠨ࠭ࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠭ࡹࡩࡵࡧࠬ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠱࠭ࠧ࠭ࠩๆ่ฬ࠭ࠬࠨ่฼้ࠬ࠯ࠍࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠷࠺ࠡ࡫ࡰࡴࡴࡸࡴࠡࡕࡈࡖ࡛ࡏࡃࡆࡕࠣ࠿࡙ࠥࡅࡓࡘࡌࡇࡊ࡙࠮ࡎࡃࡌࡒ࠭࠷࠹࠶ࠫࠐࠎࠎ࡫࡬ࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠏࠍࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠷ࠦ࠽ࠡ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠬࠩࠣ࠲ࠥํไࠡฬิ๎ิࠦๅฺำไอࠥอไฤีหหอ่ࠦศๆะ่ํ๊ࠠภࠩࠐࠎࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲ࡳࡪࡶࡨ࠯ࠬࠦࠠࠡࠩ࠮ࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠮ࡳࡪࡶࡨ࠭࠱ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠷࠲࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎࠬࠨࠩ࠯่๊ࠫวࠨ࠮๊ࠪ฾๋ࠧࠪࠏࠍࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠱࠻ࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠ࠾ࠢࠪๆิ๊ࠦไ๊้ࠤ์์วไ้ࠢ์฾ࠦๅ็ࠢส่าาศࠡ฻้ำ่࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้หๆหำ้ฮࠥ฿ๆะๅ้ࠣๆ฻่ๅหࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦไศࠢํ฽ฺ๊๊่ࠠา็ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠ฻์ิࠤ์ึ็ࠡษ็ูๆำษ๊ࠡส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰ࡟ࡲࠬ࠱ࠧอำหࠤู๊อࠡษ็็ฬฺࠠࠩ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯ࠭ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢฦีุ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠࠩ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯ࠭ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢฯีอࠦืาไࠣีๆ฿ࠠศๆะะอࠦࠨๆอ็หࠥ࡜ࡐࡏࠢ࠯ࠤࡕࡸ࡯ࡹࡻࠣ࠰ࠥࡊࡎࡔࠫࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠอำหࠤ฼๊ศ้ࠡำหࠥอไๆ๊ๅ฽๊ࠥวฮไสࠫࠒࠐࠉࠊࠋࡇࡍࡆࡒࡏࡈࡡࡗࡉ࡝࡚ࡖࡊࡇ࡚ࡉࡗ࠮ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ࠯ࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖ࠭ࠒࠐࠉࠣࠤࠥ㬗")
def l111l11ll11_l1_(l1l11ll1111l_l1_=False):
	l1lll1l111ll_l1_ = [l11lll11111_l1_,favoritesfile,l1l111l111l1_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l11ll1111l_l1_ and (filename.startswith(l11lll_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭㬘")) or filename.startswith(l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠭㬙"))): continue
		if filename.startswith(l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩ㬚")): continue
		l1ll1l1lll11_l1_ = os.path.join(addoncachefolder,filename)
		if l1ll1l1lll11_l1_ in l1lll1l111ll_l1_: continue
		try: os.remove(l1ll1l1lll11_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll111ll1l1_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll1l_l1_=True):
	l1l1l11l1ll1_l1_,l1ll111lll11_l1_ = proxy.split(l11lll_l1_ (u"ࠫ࠿࠭㬛"))
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"๋ࠬิไๆฬࠤส์สา่ํฮࠥ࠴ࠠิละหํ๊ࠠฦื็หาํวࠨ㬜"),l11lll_l1_ (u"࠭ำฤฮิฬࠥ࠭㬝")+name,time=2000)
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㬞"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࠬ㬟")+name+l11lll_l1_ (u"ࠩࠣࡷࡪࡸࡶࡦࡴࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㬠")+proxy+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㬡")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㬢"))
	url = url+l11lll_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ㬣")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_,l1l1lll1ll1l_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㬤"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࠫ㬥")+name+l11lll_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㬦")+proxy+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㬧")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㬨"))
		l1lll11l1111_l1_(l11lll_l1_ (u"ࠫࡍ࡚ࡔࡑࠢࡕࡩࡶࡻࡥࡴࡶࠣࡊࡦ࡯࡬ࡶࡴࡨࠫ㬩"))
	#else: LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㬪"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㬫")+proxy+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㬬")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㬭"))
	return response
def l1l11ll11ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㬮"),url,l11lll_l1_ (u"ࠪࠫ㬯"),l11lll_l1_ (u"ࠫࠬ㬰"),True,l11lll_l1_ (u"ࠬ࠭㬱"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ㬲"),True,False)
	l1llll1l1l11_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l111111_l1_
		l1l1lll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ㬳"),html)
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㬴"),str(l1l1lll111ll_l1_))
		if l1l1lll111ll_l1_: html = l11lll_l1_ (u"ࠩ࡟ࡲࠬ㬵").join(l1l1lll111ll_l1_)
		proxies = html.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭㬶"),l11lll_l1_ (u"ࠫࠬ㬷")).strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㬸")).split(l11lll_l1_ (u"࠭࡜࡯ࠩ㬹"))
		l1llll1l1l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l11lll_l1_ (u"ࠧ࠯ࠩ㬺"))==3: l1llll1l1l11_l1_.append(proxy)
	return l1llll1l1l11_l1_
def l111ll1l111_l1_(*args):
	#l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠶࠸࠲࠸࠹࠮࠲࠹࠱࠵࠷࠽࠯ࡢࡲ࡬࠳ࡵࡸ࡯ࡹࡻࡂࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡳࡱࡧࡨࡨࡂ࠷࠰ࠧ࡮ࡤࡷࡹࡥࡣࡩࡧࡦ࡯ࡂ࠷࠰ࠧࡪࡷࡸࡵࡹ࠽ࡵࡴࡸࡩࠫࡶ࡯ࡴࡶࡀࡸࡷࡻࡥࠧࡨࡲࡶࡲࡧࡴ࠾ࡶࡻࡸࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬ㬻")
	l11l111l1ll_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ㬼")
	l1ll1l11l1ll_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ㬽")
	#l1llll1l1l1l_l1_ = l1l11ll11ll1_l1_(l1l1llll1ll1_l1_)
	l1llll1l1l1l_l1_ = l1l11ll11ll1_l1_(l1ll1l11l1ll_l1_)
	l1llll1l1l11_l1_ = l1l11ll11ll1_l1_(l11l111l1ll_l1_)
	l11l11ll1l1_l1_ = l1llll1l1l1l_l1_+l1llll1l1l11_l1_
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㬾"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫ㬿")+str(len(l1llll1l1l1l_l1_))+l11lll_l1_ (u"࠭ࠫࠨ㭀")+str(len(l1llll1l1l11_l1_))+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㭁"))
	proxy = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㭂"))
	response = l1l1111l11l_l1_()
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㭃"),l11lll_l1_ (u"ࠪࠫ㭄"))
	if proxy or l11l11ll1l1_l1_:
		id,timeout = 0,10
		l1l11lllll11_l1_ = len(l11l11ll1l1_l1_)
		l1111111111_l1_ = timeout
		if l1l11lllll11_l1_>l1111111111_l1_: counts = l1111111111_l1_
		else: counts = l1l11lllll11_l1_
		l1111ll1ll1_l1_ = random.sample(l11l11ll1l1_l1_,counts)
		if proxy: l1111ll1ll1_l1_ = [proxy]+l1111ll1ll1_l1_
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㭅"),str(l1111ll1ll1_l1_))
		threads = l11111lllll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l1111ll11l1_l1_:
			if id<counts:
				proxy = l1111ll1ll1_l1_[id]
				threads.start_new_thread(id,l1ll111ll1l1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㭆"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㭇")+proxy+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㭈"))
		l1111ll11l1_l1_ = threads.l1111ll11l1_l1_
		if l1111ll11l1_l1_:
			l1ll1l1lll1l_l1_ = threads.l1ll1l1lll1l_l1_
			l1lll111l11l_l1_ = l1111ll11l1_l1_[0]
			response = l1ll1l1lll1l_l1_[l1lll111l11l_l1_]
			proxy = l1111ll1ll1_l1_[int(l1lll111l11l_l1_)]
			settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㭉"),proxy)
			if l1lll111l11l_l1_!=0: LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㭊"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㭋")+proxy+l11lll_l1_ (u"ࠫࠥࡣࠧ㭌"))
			else: LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㭍"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㭎")+proxy+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㭏"))
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㭐"),l11lll_l1_ (u"ࠩࡳࡶࡴࡾࡩࡦࡵࡏࡍࡘ࡚࠲ࠡ࠼࠽ࠤࠬ㭑")+str(l1111ll1ll1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㭒"),l11lll_l1_ (u"ࠫࡵࡸ࡯ࡹ࡫ࡨࡷࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭㭓")+str(l11l11ll1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㭔"),l11lll_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ㭕")+str(threads.l1111ll11l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㭖"),l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ㭗")+str(threads.l11l1l11l1l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㭘"),l11lll_l1_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࡶࡈࡎࡉࡔࠡ࠼࠽ࠤࠬ㭙")+str(threads.l1ll1l1lll1l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㭚"),l11lll_l1_ (u"ࠬ࡫࡬ࡱࡣࡶࡩࡩࡺࡩ࡮ࡧࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ㭛")+str(threads.l11l111l11l_l1_))
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㭜"),l11lll_l1_ (u"ࠧࡴࡱࡵࡸࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ㭝")+str(l1lll11ll1ll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㭞"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㭟")+l1l11lll1l11_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㭠")+str(l1lll11ll1ll_l1_))
	return response
def l1l11l11ll11_l1_(connection,l1l111ll1ll1_l1_):
	l11111l1lll_l1_ = connection.create_connection
	def l1l1l1l11ll1_l1_(address,*args,**kwargs):
		host,port = address
		l1l1ll1l1lll_l1_ = DNS_RESOLVER(host,l1l111ll1ll1_l1_)
		if l1l1ll1l1lll_l1_: host = l1l1ll1l1lll_l1_[0]
		else:
			if l1l111ll1ll1_l1_ in l1lll1l11lll_l1_: l1lll1l11lll_l1_.remove(l1l111ll1ll1_l1_)
			if l1lll1l11lll_l1_:
				l1llllll1l11_l1_ = l1lll1l11lll_l1_[0]
				#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㭡"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡘ࡫࡯ࡰࠥࡺࡲࡺࠢࡷ࡬ࡪࠦ࡯ࡵࡪࡨࡶࠥࡊࡎࡔ࠼࡞ࠤࠬ㭢")+l1llllll1l11_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍࡵࡳࡵ࠼࡞ࠤࠬ㭣")+str(host)+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㭤"))
				l1l1ll1l1lll_l1_ = DNS_RESOLVER(host,l1llllll1l11_l1_)
				if l1l1ll1l1lll_l1_: host = l1l1ll1l1lll_l1_[0]
		address = (host,port)
		return l11111l1lll_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1l1l11ll1_l1_
	return l11111l1lll_l1_
def l1ll1l1l11_l1_(l11lll1ll11_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡵࡷࡶࠬ㭥"),l11lll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ㭦"),(method,url,data,headers))
	if html:
		l11lll1lll1_l1_(l11lll_l1_ (u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨ㭧"),url,data,headers,source,method)
		return html
	html = l1lllll11l_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ㭨"),(method,url,data,headers),html,l11lll1ll11_l1_)
	return html
def l1l111l1llll_l1_(url):
	l111l111lll_l1_,l111l1l1l1l_l1_ = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ㭩"))[2],80
	if l11lll_l1_ (u"࠭࠺ࠨ㭪") in l111l111lll_l1_: l111l111lll_l1_,l111l1l1l1l_l1_ = l111l111lll_l1_.split(l11lll_l1_ (u"ࠧ࠻ࠩ㭫"))
	l111111ll1l_l1_ = l11lll_l1_ (u"ࠨ࠱ࠪ㭬")+l11lll_l1_ (u"ࠩ࠲ࠫ㭭").join(url.split(l11lll_l1_ (u"ࠪ࠳ࠬ㭮"))[3:])
	request = l11lll_l1_ (u"ࠫࡌࡋࡔࠡࠩ㭯")+l111111ll1l_l1_+l11lll_l1_ (u"ࠬࠦࡈࡕࡖࡓ࠳࠶࠴࠱࡝ࡴ࡟ࡲࠬ㭰")
	#request += l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ࠽ࠤࡡࡸ࡜࡯ࠩ㭱")
	request += l11lll_l1_ (u"ࠧࡉࡱࡶࡸ࠿ࠦࠧ㭲")+l111l111lll_l1_+l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㭳")
	request += l11lll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㭴")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l111l111lll_l1_,l111l1l1l1l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11lll_l1_ (u"ࠪࠫ㭵")
	return html
def SERVER(link,type):
	# url:	http://www.l1llll1lll1l_l1_.com
	# host:	www.l1llll1lll1l_l1_.com
	# name:	l1llll1lll1l_l1_
	#server = l11lll_l1_ (u"ࠫ࠴࠭㭶").join(link.split(l11lll_l1_ (u"ࠬ࠵ࠧ㭷"))[:3])
	if l11lll_l1_ (u"࠭࠮ࠨ㭸") not in link: return link
	link = link+l11lll_l1_ (u"ࠧ࠰ࠩ㭹")
	l1l1l1ll11ll_l1_,l1l1l1ll11l1_l1_ = link.split(l11lll_l1_ (u"ࠨ࠰ࠪ㭺"),1)
	l1l1l1ll111l_l1_,l1l1l1ll1111_l1_ = l1l1l1ll11l1_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ㭻"),1)
	server = l1l1l1ll11ll_l1_+l11lll_l1_ (u"ࠪ࠲ࠬ㭼")+l1l1l1ll111l_l1_
	if type in [l11lll_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ㭽"),l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㭾")] and l11lll_l1_ (u"࠭࠯ࠨ㭿") in server: server = server.rsplit(l11lll_l1_ (u"ࠧ࠰ࠩ㮀"),1)[1]
	if type==l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㮁") and l11lll_l1_ (u"ࠩ࠱ࠫ㮂") in server:
		l1l1lllll111_l1_ = server.split(l11lll_l1_ (u"ࠪ࠲ࠬ㮃"))
		length = len(l1l1lllll111_l1_)
		if length<=2 or l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㮄") in server: l1l1lllll111_l1_ = l1l1lllll111_l1_[0]
		elif length>=3: l1l1lllll111_l1_ = l1l1lllll111_l1_[1]
		if len(l1l1lllll111_l1_)>1: server = l1l1lllll111_l1_
	return server
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࠫ࠴࠭ࠫࡶࡴ࡯࠶࠰࠭࠯ࠨࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡴࡥࡵ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡯࡮࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡵࡲࡨ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡲࡩࡷࡧ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡴࡷ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡽࡳ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡹࡵ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡱࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡦࡳ࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡴࡸ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤࡣࡰ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡰ࡮ࡼࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡲࡵࡣ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡲࡩࡧࡧ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡭ࡹ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳࡯࡮࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡼࡽࡷ࠯ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡲ࠴ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡨࡱࡧ࡫ࡤ࠯ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࠦࠧࠨ㮅")
def l1l11llllll1_l1_(l1111l1111l_l1_):
	l1111l111l1_l1_ = repr(l1111l1111l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮆"))).replace(l11lll_l1_ (u"ࠢࠨࠤ㮇"),l11lll_l1_ (u"ࠨࠩ㮈"))
	return l1111l111l1_l1_
def l1l111ll1ll_l1_(string):
	#if l11lll_l1_ (u"ࠩ࡟ࡹࠬ㮉") in string:
	#	string = string.decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㮊"))
	#	l1ll1ll1ll11_l1_=re.findall(l11lll_l1_ (u"ࡶࠬࡢࡵ࡜࠲࠰࠽ࡆ࠳ࡆ࡞ࠩ㮋"),string)
	#	for unicode in l1ll1ll1ll11_l1_
	#		char = l1l1111ll1ll_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㮌"))
	l1l11l11lll1_l1_ = l11lll_l1_ (u"࠭ࠧ㮍")
	if kodi_version<19: string = string.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㮎"))
	import unicodedata
	for l1l111ll11l_l1_ in string:
		if   l1l111ll11l_l1_==l11lll_l1_ (u"ࡶࠩลࠫ㮏"): l111111l11l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ࠪ㮐")
		elif l1l111ll11l_l1_==l11lll_l1_ (u"ࡸࠫศ࠭㮑"): l111111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬ㮒")
		elif l1l111ll11l_l1_==l11lll_l1_ (u"ࡺ࠭ฤࠨ㮓"): l111111l11l_l1_ = l11lll_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧ㮔")
		elif l1l111ll11l_l1_==l11lll_l1_ (u"ࡵࠨวࠪ㮕"): l111111l11l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ࠩ㮖")
		elif l1l111ll11l_l1_==l11lll_l1_ (u"ࡷࠪสࠬ㮗"): l111111l11l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠹ࠫ㮘")
		else:
			l1l1111l1lll_l1_ = unicodedata.decomposition(l1l111ll11l_l1_)
			if l11lll_l1_ (u"ࠫࠥ࠭㮙") in l1l1111l1lll_l1_: l111111l11l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶࠩ㮚")+l1l1111l1lll_l1_.split(l11lll_l1_ (u"࠭ࠠࠨ㮛"),1)[1]
			else:
				l111111l11l_l1_ = l11lll_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ㮜")+hex(ord(l1l111ll11l_l1_)).replace(l11lll_l1_ (u"ࠨ࠲ࡻࠫ㮝"),l11lll_l1_ (u"ࠩࠪ㮞"))
				l111111l11l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻࠧ㮟")+l111111l11l_l1_[-4:]
			#if ord(l1l111ll11l_l1_)<256: l111111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵ࠱࠲ࠪ㮠")+l1l1l1lll111_l1_
			#elif ord(l1l111ll11l_l1_)<4096: l111111l11l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶ࠲ࠪ㮡")+l1l1l1lll111_l1_
			#elif l11lll_l1_ (u"࠭ࠠࠨ㮢") in l1l1111l1lll_l1_: l111111l11l_l1_ = l11lll_l1_ (u"ࠧ࡝࡞ࡸࠫ㮣")+l1l1111l1lll_l1_.split(l11lll_l1_ (u"ࠨࠢࠪ㮤"),1)[1]
			#else: l111111l11l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠭㮥")+l1l1l1lll111_l1_
		l1l11l11lll1_l1_ += l111111l11l_l1_
	l1l11l11lll1_l1_ = l1l11l11lll1_l1_.replace(l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷ࡅࡆࠫ㮦"),l11lll_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠷࠽ࠬ㮧"))
	if kodi_version<19: l1l11l11lll1_l1_ = l1l11l11lll1_l1_.decode(l11lll_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㮨")).encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮩"))
	else: l1l11l11lll1_l1_ = l1l11l11lll1_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㮪")).decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㮫"))
	return l1l11l11lll1_l1_
def OPEN_KEYBOARD(header=l11lll_l1_ (u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩ㮬"),default=l11lll_l1_ (u"ࠪࠫ㮭"),l1lllllllll1_l1_=False,source=l11lll_l1_ (u"ࠫࠬ㮮")):
	text = l111l1l1lll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11lll_l1_ (u"ࠬࠦࠠࠨ㮯"),l11lll_l1_ (u"࠭ࠠࠨ㮰")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ㮱"),l11lll_l1_ (u"ࠨࠢࠪ㮲")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ㮳"),l11lll_l1_ (u"ࠪࠤࠬ㮴"))
	if not text and not l1lllllllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㮵"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠾ࠥࠦࠠࠣࠩ㮶")+text+l11lll_l1_ (u"࠭ࠢࠨ㮷"))
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㮸"),l11lll_l1_ (u"ࠨࠩ㮹"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㮺"),l11lll_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦััห้࠭㮻"))
		return l11lll_l1_ (u"ࠫࠬ㮼")
	if text not in [l11lll_l1_ (u"ࠬ࠭㮽"),l11lll_l1_ (u"࠭ࠠࠨ㮾")]:
		text = text.strip(l11lll_l1_ (u"ࠧࠡࠩ㮿"))
		text = l1l111ll1ll_l1_(text)
	if source!=l11lll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪ㯀") and l11ll11_l1_(l11lll_l1_ (u"ࠩࡎࡉ࡞ࡈࡏࡂࡔࡇࠫ㯁"),l11lll_l1_ (u"ࠪࠫ㯂"),[text],False):
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㯃"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨ㯄")+text+l11lll_l1_ (u"࠭ࠢࠨ㯅"))
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㯆"),l11lll_l1_ (u"ࠨࠩ㯇"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㯈"),l11lll_l1_ (u"ࠪห๋ะࠠไฬหฮ้ࠥไๆหࠣวํࠦัใ็่ࠣ์ูࠦๅษๅอࠥฮรโๆส้๊ࠥไไสสีࠥ็โุࠢ࠱࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์ึ้าࠦศศีอาิอๅ้ࠡๆิฬࠦใๅ็สฮࠬ㯉"))
		return l11lll_l1_ (u"ࠫࠬ㯊")
	LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㯋"),l11lll_l1_ (u"࠭࠮ࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩ㯌")+text+l11lll_l1_ (u"ࠧࠣࠩ㯍"))
	return text
def l11ll11lll_l1_(l11l11l_l1_,headers={}):
	#if headers[l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㯎")]==l11lll_l1_ (u"ࠩࠪ㯏"): headers[l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㯐")] = l11lll_l1_ (u"ࠫࠥ࠭㯑")
	#l1ll1lll11l1_l1_ = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㯒") : l11lll_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠻࠺࠴࠰࠯࠵࠺࠻࠵࠴࠱࠵࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ㯓") }
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡧ࠼࠹࠴࡭ࡺࡥࡧࡲ࠳ࡳࡥ࠰ࡸ࡬ࡨࡪࡵ࠮࡮࠵ࡸ࠼ࠬ㯔")
	#open(l11lll_l1_ (u"ࠨࡕ࠽ࡠࡡࡺࡥࡴࡶ࠵࠲ࡲ࠹ࡵ࠹ࠩ㯕"), l11lll_l1_ (u"ࠩࡵࠫ㯖")).read()
	url,params = l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㯗")
	if l11lll_l1_ (u"ࠫࢁ࠭㯘") in l11l11l_l1_:
		url,params = l11l11l_l1_.split(l11lll_l1_ (u"ࠬࢂࠧ㯙"),1)
		if l11lll_l1_ (u"࠭࠽ࠨ㯚") not in params: url,params = l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ㯛")
	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㯜"),url,l11lll_l1_ (u"ࠩࠪ㯝"),headers,l11lll_l1_ (u"ࠪࠫ㯞"),l11lll_l1_ (u"ࠫࠬ㯟"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ㯠"),False,False)
	html = response.content
	if l11lll_l1_ (u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ㯡") not in html: return [l11lll_l1_ (u"ࠧ࠮࠳ࠪ㯢")],[l11l11l_l1_]
	#	if l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㯣") in list(headers.keys()): del headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㯤")]
	#	else: headers[l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㯥")] = l11lll_l1_ (u"ࠫࠬ㯦")
	#	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㯧"),url,l11lll_l1_ (u"࠭ࠧ㯨"),headers,l11lll_l1_ (u"ࠧࠨ㯩"),l11lll_l1_ (u"ࠨࠩ㯪"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠵ࡲࡩ࠭㯫"),False,False)
	#	html = response.content
	if l11lll_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡃࡘࡈࡎࡕࠧ㯬") in html: return [l11lll_l1_ (u"ࠫ࠲࠷ࠧ㯭")],[l11l11l_l1_]
	if l11lll_l1_ (u"࡚࡙ࠬࡑࡇࡀ࡚ࡎࡊࡅࡐࠩ㯮") in html: return [l11lll_l1_ (u"࠭࠭࠲ࠩ㯯")],[l11l11l_l1_]
	#if l11lll_l1_ (u"ࠧࡕ࡛ࡓࡉࡂ࡙ࡕࡃࡖࡌࡘࡑࡋࡓࠨ㯰") in html: return [l11lll_l1_ (u"ࠨ࠯࠴ࠫ㯱")],[l11l11l_l1_]
	l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l1l_l1_ = [],[],[],[]
	lines = re.findall(l11lll_l1_ (u"ࠩ࡟ࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫ㯲"),html+l11lll_l1_ (u"ࠪࡠࡳ࠭㯳"),re.DOTALL)
	if not lines: return [l11lll_l1_ (u"ࠫ࠲࠷ࠧ㯴")],[l11l11l_l1_]
	for line,link in lines:
		l1l11l1111ll_l1_,l111l1lllll_l1_,l11l111l_l1_ = {},-1,-1
		title = l11lll_l1_ (u"ࠬ࠭㯵")
		#hostname = SERVER(link,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㯶"))
		#title = title+l11lll_l1_ (u"ࠧࠡࠢࠪ㯷")+hostname+l11lll_l1_ (u"ࠨࠢࠣࠫ㯸")
		#line = line.lower()
		items = line.split(l11lll_l1_ (u"ࠩ࠯ࠫ㯹"))
		for item in items:
			#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㯺"),l11lll_l1_ (u"ࠫࠬ㯻"),item,l11lll_l1_ (u"ࠬ࠭㯼"))
			#if l11lll_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ㯽") in item: l1l11l1111ll_l1_[key] = value
			if l11lll_l1_ (u"ࠧ࠾ࠩ㯾") in item:
				key,value = item.split(l11lll_l1_ (u"ࠨ࠿ࠪ㯿"),1)
				l1l11l1111ll_l1_[key.lower()] = value
		if l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㰀") in line.lower():
			l111l1lllll_l1_ = int(l1l11l1111ll_l1_[l11lll_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ㰁")])//1024
			#title += l11lll_l1_ (u"ࠫࡆࡼࡧࡃ࡙࠽ࠤࠬ㰂")+str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ㰃")
			title += str(l111l1lllll_l1_)+l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭㰄")
		elif l11lll_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㰅") in line.lower():
			l111l1lllll_l1_ = int(l1l11l1111ll_l1_[l11lll_l1_ (u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㰆")])//1024
			#title += l11lll_l1_ (u"ࠩࡅ࡛࠿ࠦࠧ㰇")+str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㰈")
			title += str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㰉")
		if l11lll_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㰊") in line.lower():
			l11l111l_l1_ = int(l1l11l1111ll_l1_[l11lll_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ㰋")].split(l11lll_l1_ (u"ࠧࡹࠩ㰌"))[1])
			#title += l11lll_l1_ (u"ࠨࡔࡨࡷ࠿ࠦࠧ㰍")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠬ㰎")
			title += str(l11l111l_l1_)+l11lll_l1_ (u"ࠪࠤࠥ࠭㰏")
		title = title.strip(l11lll_l1_ (u"ࠫࠥࠦࠧ㰐"))
		if not title: title = l11lll_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭㰑")
		if not link.startswith(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㰒")):
			if link.startswith(l11lll_l1_ (u"ࠧ࠰࠱ࠪ㰓")): link = url.split(l11lll_l1_ (u"ࠨ࠼ࠪ㰔"),1)[0]+l11lll_l1_ (u"ࠩ࠽ࠫ㰕")+link
			elif link.startswith(l11lll_l1_ (u"ࠪ࠳ࠬ㰖")): link = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ㰗"))+link
			else: link = url.rsplit(l11lll_l1_ (u"ࠬ࠵ࠧ㰘"),1)[0]+l11lll_l1_ (u"࠭࠯ࠨ㰙")+link
		if params!=l11lll_l1_ (u"ࠧࠨ㰚"): link = link+l11lll_l1_ (u"ࠨࡾࠪ㰛")+params
		if l11lll_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㰜") in list(l1l11l1111ll_l1_.keys()):
			l1lllll1ll_l1_ = l1l11l1111ll_l1_[l11lll_l1_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ㰝")]
			l1lllll1ll_l1_ = l1lllll1ll_l1_.replace(l11lll_l1_ (u"ࠫࠧ࠭㰞"),l11lll_l1_ (u"ࠬ࠭㰟")).replace(l11lll_l1_ (u"ࠨࠧࠣ㰠"),l11lll_l1_ (u"ࠧࠨ㰡")).split(l11lll_l1_ (u"ࠨࠥࠪ㰢"),1)[0]
			l111llll11_l1_ = l11l1llll1_l1_(l1lllll1ll_l1_)
			if l111llll11_l1_: l1lll1lll_l1_ = title+l11lll_l1_ (u"ࠩࠣࠤࠬ㰣")+l111llll11_l1_
			else: l1lll1lll_l1_ = title
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪ㰤")
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ㰥")+SERVER(l1lllll1ll_l1_,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㰦"))
			l1lll1ll_l1_.append(l1lll1lll_l1_)
			l1111_l1_.append(l1lllll1ll_l1_)
			l1lllll1111l_l1_.append(l11l111l_l1_)
			l1l1llll1l1l_l1_.append(l111l1lllll_l1_)
		link = link.split(l11lll_l1_ (u"࠭ࠣࠨ㰧"),1)[0]
		l111llll11_l1_ = l11l1llll1_l1_(link)
		if l111llll11_l1_: title = title+l11lll_l1_ (u"ࠧࠡࠢࠪ㰨")+l111llll11_l1_
		title = title+l11lll_l1_ (u"ࠨࠢࠣࠫ㰩")+SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㰪"))
		l1lll1ll_l1_.append(title)
		l1111_l1_.append(link)
		l1lllll1111l_l1_.append(l11l111l_l1_)
		l1l1llll1l1l_l1_.append(l111l1lllll_l1_)
	zz = list(zip(l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l1l_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l1l_l1_ = list(zip(*zz))
	l1lll1ll_l1_,l1111_l1_ = list(l1lll1ll_l1_),list(l1111_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪࠫ㰫"), l1lll1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫࠬ㰬"), l1111_l1_)
	return l1lll1ll_l1_,l1111_l1_
def DNS_RESOLVER(host,l1l111ll1ll1_l1_=l11lll_l1_ (u"ࠬ࠭㰭")):
	if not l1l111ll1ll1_l1_: l1l111ll1ll1_l1_ = l1lll1l11lll_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㰮"),l11lll_l1_ (u"ࠧࠨ㰯"),str(l1l111ll1ll1_l1_),str(host))
	if host.replace(l11lll_l1_ (u"ࠨ࠰ࠪ㰰"),l11lll_l1_ (u"ࠩࠪ㰱")).isdigit(): return [host]
	import struct,socket
	try:
		l1111l11lll_l1_ = struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㰲"), 12049)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠦࡃࡎࠢ㰳"), 256)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡄࡈࠣ㰴"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠨ࠾ࡉࠤ㰵"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠢ࠿ࡊࠥ㰶"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠣࡀࡋࠦ㰷"), 0)
		if kodi_version>18.99: l1ll1l1l1l11_l1_ = host.split(l11lll_l1_ (u"ࠩ࠱ࠫ㰸"))
		else: l1ll1l1l1l11_l1_ = host.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㰹")).split(l11lll_l1_ (u"ࠫ࠳࠭㰺"))
		for part in l1ll1l1l1l11_l1_:
			parts = part.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㰻"))
			l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠨࡂࠣ㰼"), len(part))
			for l1llll111l1l_l1_ in part:
				l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠢࡤࠤ㰽"), l1llll111l1l_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㰾")))
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠤࡅࠦ㰿"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㱀"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠦࡃࡎࠢ㱁"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l1111l11lll_l1_), (l1l111ll1ll1_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1111lll1ll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ㱂"), data, 0)
		l1lllll1lll1_l1_ = l1111lll1ll_l1_[3]
		offset = len(host)+18
		l11111lll11_l1_ = []
		for _ in range(l1lllll1lll1_l1_):
			l1llll1lllll_l1_ = offset
			l1ll11l11l11_l1_ = 1
			l1lll11lll11_l1_ = False
			while True:
				l1llll111l1l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠨ࠾ࡃࠤ㱃"), data, l1llll1lllll_l1_)[0]
				if l1llll111l1l_l1_ == 0:
					l1llll1lllll_l1_ += 1
					break
				# l1l1l1l1ll11_l1_ the field l1l1l11l111l_l1_ the first l111l1111l1_l1_ bits l1l1ll1l1l11_l1_ to 1, l1lllllll1ll_l1_ a pointer
				if l1llll111l1l_l1_ >= 192:
					l1lll1llll1l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠢ࠿ࡄࠥ㱄"), data, l1llll1lllll_l1_ + 1)[0]
					# l1l111lll1ll_l1_ the pointer
					l1llll1lllll_l1_ = ((l1llll111l1l_l1_ << 8) + l1lll1llll1l_l1_ - 0xc000) - 1
					l1lll11lll11_l1_ = True
				l1llll1lllll_l1_ += 1
				if l1lll11lll11_l1_ == False: l1ll11l11l11_l1_ += 1
			if l1lll11lll11_l1_ == True: l1ll11l11l11_l1_ += 1
			offset = offset + l1ll11l11l11_l1_
			l11l11l1ll1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠣࡀࡋࡌࡎࡎࠢ㱅"), data, offset)
			offset = offset + 10
			l111l1111ll_l1_ = l11l11l1ll1_l1_[0]
			l1lll11llll1_l1_ = l11l11l1ll1_l1_[3]
			if l111l1111ll_l1_ == 1: # l11111ll11l_l1_ type
				l1llll111ll1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠤࡁࠦ㱆")+l11lll_l1_ (u"ࠥࡆࠧ㱇")*l1lll11llll1_l1_, data, offset)
				l1l1ll1l1lll_l1_ = l11lll_l1_ (u"ࠫࠬ㱈")
				for l1llll111l1l_l1_ in l1llll111ll1_l1_: l1l1ll1l1lll_l1_ += str(l1llll111l1l_l1_) + l11lll_l1_ (u"ࠬ࠴ࠧ㱉")
				l1l1ll1l1lll_l1_ = l1l1ll1l1lll_l1_[0:-1]
				l11111lll11_l1_.append(l1l1ll1l1lll_l1_)
			if l111l1111ll_l1_ in [1,2,5,6,15,28]: offset = offset + l1lll11llll1_l1_
	except: l11111lll11_l1_ = []
	if not l11111lll11_l1_: LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㱊"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡍࡵࡳࡵ࠼ࠣ࡟ࠥ࠭㱋")+host+l11lll_l1_ (u"ࠨࠢࡠࠫ㱌"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㱍"),l11lll_l1_ (u"ࠪࠫ㱎"),str(host),str(l11111lll11_l1_))
	return l11111lll11_l1_
def l11ll11_l1_(script_name,url,l11ll1l_l1_,l1ll_l1_=True):
	if l11ll1l_l1_:
		l1111lll11l_l1_ = [l11lll_l1_ (u"่ࠫฮวาࠩ㱏"),l11lll_l1_ (u"ࠬฮวๅ฼ࠪ㱐"),l11lll_l1_ (u"࠭ࡡࡥࡷ࡯ࡸࠬ㱑"),l11lll_l1_ (u"ࠧࡹࡺࠪ㱒"),l11lll_l1_ (u"ࠨࡵࡨࡼࠬ㱓")]
		if script_name!=l11lll_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㱔"):
			l1111lll11l_l1_ += [l11lll_l1_ (u"ࠪࡶ࠿࠭㱕"),l11lll_l1_ (u"ࠫࡷ࠳ࠧ㱖"),l11lll_l1_ (u"ࠬ࠳࡭ࡢࠩ㱗")]
			l1111lll11l_l1_ += [l11lll_l1_ (u"࠭࠺ࡳࠩ㱘"),l11lll_l1_ (u"ࠧ࠮ࡴࠪ㱙"),l11lll_l1_ (u"ࠨ࡯ࡤ࠱ࠬ㱚")]
		for l1ll1ll1l1_l1_ in l11ll1l_l1_:
			if l11lll_l1_ (u"ࠩࡪࡩࡹ࠴ࡰࡩࡲࡂࠫ㱛") in l1ll1ll1l1_l1_: continue
			if l11lll_l1_ (u"ࠪั้่ษࠨ㱜") in l1ll1ll1l1_l1_: continue
			l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.lower()
			if kodi_version<19: l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㱝")).encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㱞"))
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㱟"),l11lll_l1_ (u"ࠧࠨ㱠"),l11lll_l1_ (u"ࠨࠩ㱡"),str(l1ll1ll1l1_l1_))
			#l1lllll1l111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬ࠶ࡡ࠶࠮࠻ࡠࢀ࠷ࡡ࠰࠮࠻ࡠ࠭ࠩ࠭㱢"),l1ll1ll1l1_l1_,re.DOTALL)
			#l1lllll1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢࡡ࠱ࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ㱣"),l1ll1ll1l1_l1_,re.DOTALL)
			#l1lllll1l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࠱࡜࠸࠰࠽ࡢࢂ࠲࡜࠲࠰࠽ࡢ࠯࡜ࠬࠦࠪ㱤"),l1ll1ll1l1_l1_,re.DOTALL)
			#l11111l1l1l_l1_ = any(l1lllll1l111_l1_,l1lllll1l1l1_l1_,l1lllll1l11l_l1_,l1lllll11ll1_l1_)
			l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.replace(l11lll_l1_ (u"ࠬࡀࠧ㱥"),l11lll_l1_ (u"࠭ࠧ㱦"))
			l11111l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫ㱧"),l1ll1ll1l1_l1_,re.DOTALL)
			l1l1lllll11l_l1_ = False
			for digits in l11111l1l1l_l1_:
				if len(digits)==2:
					l1l1lllll11l_l1_ = True
					break
			if l11lll_l1_ (u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫ㱨") in l1ll1ll1l1_l1_: continue
			elif l11lll_l1_ (u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ㱩") in l1ll1ll1l1_l1_: continue
			elif l11lll_l1_ (u"ࠪ฾๏ืࠠๆื้ๅࠬ㱪") in l1ll1ll1l1_l1_: continue
			elif l11l1llll1l_l1_(l11lll_l1_ (u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭㱫")): continue
			elif l1ll1ll1l1_l1_ in [l11lll_l1_ (u"ࠬࡸࠧ㱬")] or l1l1lllll11l_l1_ or any(value in l1ll1ll1l1_l1_ for value in l1111lll11l_l1_):
				LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㱭"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㱮")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㱯"))
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱰"),l11lll_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ㱱"))
				return True
	return False
def l1l11l11llll_l1_(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬ㱲"),l11l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭㱳")):
	global l1l111l111l_l1_
	import threading
	l11l1lll1ll_l1_ = threading.Thread(target=l1lllll11l1l_l1_,args=(l11l1l1_l1_,l1l1ll11_l1_,l11l1l1ll11_l1_))
	l11l1lll1ll_l1_.start()
	l11l1lll1ll_l1_.join()
	return l1l111l111l_l1_
def PLAY_VIDEO(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"࠭ࠧ㱴"),l11l1l1ll11_l1_=l11lll_l1_ (u"ࠧࠨ㱵")):
	global l1l111l111l_l1_
	if not l11l1l1ll11_l1_: l11l1l1ll11_l1_ = l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㱶")
	l1l111l111l_l1_,l111l11111l_l1_,httpd = l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ㱷"),l11lll_l1_ (u"ࠪࠫ㱸"),l11lll_l1_ (u"ࠫࠬ㱹")
	if len(l11l1l1_l1_)==3:
		url,l1ll1111ll1l_l1_,httpd = l11l1l1_l1_
		if l1ll1111ll1l_l1_: l111l11111l_l1_ = l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ㱺")+l1ll1111ll1l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㱻")
	else: url,l1ll1111ll1l_l1_,httpd = l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨ㱼"),l11lll_l1_ (u"ࠨࠩ㱽")
	#url = l111l_l1_(url)		# cause l1l1111lll1l_l1_ for l1ll1llll_l1_ l1llll1l1_l1_ l1111llllll_l1_ l1ll111l111l_l1_
	url = url.replace(l11lll_l1_ (u"ࠩࠨ࠶࠵࠭㱾"),l11lll_l1_ (u"ࠪࠤࠬ㱿"))	# needed for l1l111llll1l_l1_
	l111llll11_l1_ = l11l1llll1_l1_(url,l1l1ll11_l1_)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㲀"),l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ㲁")]:
		if l1l1ll11_l1_!=l11lll_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㲂"): url = url.replace(l11lll_l1_ (u"ࠧࠡࠩ㲃"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ㲄"))
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㲅"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㲆")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㲇")+l111l11111l_l1_)
		if l111llll11_l1_==l11lll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㲈") and l1l1ll11_l1_ not in [l11lll_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㲉"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㲊")]:
			headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㲋"):l11lll_l1_ (u"ࠩࠪ㲌")}
			l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(url,headers)
			count = len(l1111_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ㲍")+str(count)+l11lll_l1_ (u"๋ࠫࠥไโࠫࠪ㲎"), l1lll1ll_l1_)
				if l1l_l1_ == -1:
					DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ㲏"),l11lll_l1_ (u"࠭ࠧ㲐"))
					return l1l111l111l_l1_
			else: l1l_l1_ = 0
			url = l1111_l1_[l1l_l1_]
			if l1lll1ll_l1_[0]!=l11lll_l1_ (u"ࠧ࠮࠳ࠪ㲑"):
				LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㲒"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ㲓")+l1lll1ll_l1_[l1l_l1_]+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㲔")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㲕"))
		#url = url+l11lll_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠳࠻࠺࠵࠶࠰࠱ࠩ㲖")
		#url = url+l11lll_l1_ (u"࠭ࡼࡅࡐࡗࡁ࠶ࠬࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠶ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࡁ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠪࡆࡩࡣࡦࡲࡷࡁ࠯࠵ࠪࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬࡑ࡯࡮ࡶࡺ࠾ࠤࡆࡴࡤࡳࡱ࡬ࡨࠥ࠽࠮࠱࠽ࠣࡗࡒ࠳ࡇ࠹࠻࠵ࡅࠥࡈࡵࡪ࡮ࡧ࠳ࡓࡘࡄ࠺࠲ࡐ࠿ࠥࡽࡶࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠯࠵࠰࠳ࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠽࠮࠱࠰࠶࠷࠾࠼࠮࠹࠹ࠣࡑࡴࡨࡩ࡭ࡧࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ㲗")
		if l11lll_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ㲘") in url: url = url+l11lll_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㲙")
		elif l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㲚") in url.lower() and l11lll_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ㲛") not in url and l11lll_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㲜") not in url:
			if l11lll_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ㲝") not in url and l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ㲞") in url.lower():
				if l11lll_l1_ (u"ࠧࡽࠩ㲟") not in url: url = url+l11lll_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㲠")
				else: url = url+l11lll_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭㲡")
			if l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ㲢") not in url.lower() and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ㲣"),l11lll_l1_ (u"ࠬࡓ࠳ࡖࠩ㲤")]:
				if l11lll_l1_ (u"࠭ࡼࠨ㲥") not in url: url = url+l11lll_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㲦")
				else: url = url+l11lll_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㲧")
		#url = url.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ㲨"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ㲩"))
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㲪"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㲫")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㲬"))
	l11l1ll111l_l1_ = xbmcgui.ListItem()
	#l11l1ll111l_l1_ = xbmcgui.ListItem(l11lll_l1_ (u"ࠧࡵࡧࡶࡸࠬ㲭"))
	l11l1l1ll11_l1_,l11ll1l1l11_l1_,l11lll11lll_l1_,l11l1ll1l11_l1_,l11llll1111_l1_,l11l1l1ll1l_l1_,l11ll1l11ll_l1_,l11ll1l111l_l1_,l11lll1111l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㲮"),l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㲯")]:
		if kodi_version<19: l1l11ll11111_l1_ = l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭㲰")
		else: l1l11ll11111_l1_ = l11lll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ㲱")
		#l11l1ll111l_l1_ = xbmcgui.ListItem(path=url)
		l11l1ll111l_l1_.setProperty(l1l11ll11111_l1_, l11lll_l1_ (u"ࠬ࠭㲲"))
		l11l1ll111l_l1_.setMimeType(l11lll_l1_ (u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ㲳"))
		if kodi_version<20: l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㲴"),{l11lll_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ㲵"):l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㲶")})
		else:
			l1l11l1ll1l1_l1_ = l11l1ll111l_l1_.getVideoInfoTag()
			l1l11l1ll1l1_l1_.setMediaType(l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ㲷"))
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡩࡤࡱࡱࠫ㲸"))
		#LOG_THIS(l11lll_l1_ (u"ࠬ࠭㲹"),l11lll_l1_ (u"࠭ࡅࡎࡃࡇ࠾࠿ࡀ࠺࠻ࠢࠪ㲺")+l11l_l1_)
		#l11l1ll111l_l1_.setArt({l11lll_l1_ (u"ࠧࡪࡥࡲࡲࠬ㲻"):l11l_l1_,l11lll_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ㲼"):l11l_l1_,l11lll_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ㲽"):l11l_l1_})
		l11l1ll111l_l1_.setArt({l11lll_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ㲾"):l11llll1111_l1_,l11lll_l1_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ㲿"):l11llll1111_l1_,l11lll_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ㳀"):l11llll1111_l1_,l11lll_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭㳁"):l11llll1111_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ㳂"):l11llll1111_l1_,l11lll_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ㳃"):l11llll1111_l1_,l11lll_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ㳄"):l11llll1111_l1_,l11lll_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ㳅"):l11llll1111_l1_})
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳆"),{l11lll_l1_ (u"࡚ࠬࡩࡵ࡮ࡨࠫ㳇"):name})
		#name = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㳈"))
		#name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ㳉"))
		# when set to l11lll_l1_ (u"ࠣࡈࡤࡰࡸ࡫ࠢ㳊") it l111l1l1l11_l1_ l1l1ll11ll11_l1_ l1ll11l1ll1l_l1_ and l1l1ll11l11l_l1_ l111111lll1_l1_ l1l111llllll_l1_ l1l1llll1l_l1_
		if l111llll11_l1_ in [l11lll_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ㳋"),l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㳌")]: l11l1ll111l_l1_.setContentLookup(True)
		else: l11l1ll111l_l1_.setContentLookup(False)
		#if l111llll11_l1_ in [l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㳍")]: l11l1ll111l_l1_.setContentLookup(False)
		if l11lll_l1_ (u"ࠬࡸࡴ࡮ࡲࠪ㳎") in url:
			import l11ll1ll1ll_l1_
			l11ll1ll1ll_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ㳏"),False)
		elif l111llll11_l1_==l11lll_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ㳐") or l11lll_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ㳑") in url:
			import l11ll1ll1ll_l1_
			l11ll1ll1ll_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㳒"),False)
			l11l1ll111l_l1_.setProperty(l1l11ll11111_l1_,l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㳓"))
			l11l1ll111l_l1_.setProperty(l11lll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫ㳔"),l11lll_l1_ (u"ࠬࡳࡰࡥࠩ㳕"))
			#l11l1ll111l_l1_.setMimeType(l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡩࡧࡳࡩ࠭ࡻࡱࡱ࠭㳖"))
			#l11l1ll111l_l1_.setContentLookup(False)
		if l1ll1111ll1l_l1_:
			l11l1ll111l_l1_.setSubtitles([l1ll1111ll1l_l1_])
			#xbmc.log(LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠥࠦࡁࡥࡦࡨࡨࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀ࡛ࠨ㳗")+l1ll1111ll1l_l1_+l11lll_l1_ (u"ࠨ࡟ࠪ㳘"), level=xbmc.LOGNOTICE)
	if l11l1l1ll11_l1_==l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㳙") and l1l1ll11_l1_==l11lll_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㳚"):
		l1l111l111l_l1_ = l11lll_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㳛")
		l1l1ll11_l1_ = l11lll_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬ㳜")
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㳝") and l11ll1l111l_l1_.startswith(l11lll_l1_ (u"ࠧ࠷ࠩ㳞")):
		l1l111l111l_l1_ = l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㳟")
		l1l1ll11_l1_ = l1l1ll11_l1_+l11lll_l1_ (u"ࠩࡢࡈࡑ࠭㳠")
	# l11l1ll1l1l_l1_ l1l1111l111_l1_
	#	l11ll1l1lll_l1_ = l11lll1l1l1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11llll_l1_ with xbmc.sleep(step*1000)
	if l1l111l111l_l1_!=l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㳡"): l11lll1llll_l1_()
	l11ll1l1lll_l1_ = l11lll1l1l1_l1_()
	if l11ll1l1lll_l1_.status:
		l1l111l111l_l1_ == l11lll_l1_ (u"ࠫࠬ㳢")
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㳣"),l11lll_l1_ (u"࠭ࠧ㳤"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㳥"),l11lll_l1_ (u"ࠨๆๅำ่ࠥวๆࠢส่๊ฮัๆฮࠣฬส๐โศใࠣฮูเ๊ๅ๋ࠢฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋๊ࠢิฬࠦวๅฮ๊หื࠭㳦"))
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㳧") and not l11ll1l111l_l1_.startswith(l11lll_l1_ (u"ࠪ࠺ࠬ㳨")):
		#title = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠬ㳩"))
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㳪"),{l11lll_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ㳫"): 3600})
		#xbmcplugin.setContent(addon_handle,l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ㳬"))
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㳭"),{l11lll_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ㳮"):l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ㳯")})
		#l11l1ll111l_l1_.setProperty(l11lll_l1_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ㳰"),l11lll_l1_ (u"ࠬࡺࡲࡶࡧࠪ㳱"))
		#l11l1ll111l_l1_.setInfo(type=l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㳲"),l1l11l1l11l1_l1_={l11lll_l1_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ㳳"):l11lll_l1_ (u"ࠨࡪࡨࡰࡱࡵࠠࡸࡱࡵࡰࡩ࠭㳴")})
		l11l1ll111l_l1_.setPath(url)
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㳵"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㳶")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㳷"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll111l_l1_)
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ㳸"):
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㳹"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡐ࡮ࡼࡥࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡶ࡬ࡢࡻࠫ࠭ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㳺")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㳻"))
		l11ll1l1lll_l1_.play(url,l11l1ll111l_l1_)
		#xbmc.Player().play(url,l11l1ll111l_l1_)
	succeeded = False
	if l1l111l111l_l1_==l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㳼"):
		import l11l111lll_l1_
		succeeded = l11l111lll_l1_.l11l11ll1l_l1_(url,l111llll11_l1_,l1l1ll11_l1_)
		if succeeded: l11lll1llll_l1_()
	else:
		timeout,l1l111l111l_l1_ = 10,l11lll_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ㳽")
		for l11ll111l1_l1_ in range(timeout):
			# l11l1ll1l1l_l1_ l1l1111l111_l1_
			#	if using time.sleep() l11l1lll1l1_l1_ of xbmc.sleep() l1l11111l11_l1_ the l11ll1111ll_l1_ status
			#	l11lll_l1_ (u"ࠦࡲࡿࡰ࡭ࡣࡼࡩࡷ࠴ࡳࡵࡣࡷࡹࡸࠨ㳾") will stop l11ll1ll111_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l111l_l1_ = l11ll1l1lll_l1_.status
			if l1l111l111l_l1_==l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㳿"):
				DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭วๅใํำ๏๎๋ࠠ฻่่ࠬ㴀"),l11lll_l1_ (u"ࠧࠨ㴁"),time=500)
				LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㴂"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࡷ࡫ࡧࡩࡴࠦࡩࡴࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㴃")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㴄")+l111l11111l_l1_)
				break
			elif l1l111l111l_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㴅"):
				LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㴆"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㴇")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㴈")+l111l11111l_l1_)
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ㴉"),l11lll_l1_ (u"ࠩࠪ㴊"),time=500)
				break
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪะฬื๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ㴋"),l11lll_l1_ (u"ࠫออโ๋ࠢࠪ㴌")+str(timeout-l11ll111l1_l1_)+l11lll_l1_ (u"ࠬࠦหศ่ํอࠬ㴍"))
			if l1l111l111l_l1_:
				LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㴎"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㴏")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㴐"))
				break
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠫ㴑"),l11lll_l1_ (u"ࠪࠫ㴒"),time=500)
			LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㴓"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡖ࡬ࡱࡪࡵࡵࡵࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㴔")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㴕")+l111l11111l_l1_)
			l1l111l111l_l1_ = l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ㴖")
	l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢ࡫ࡸࡹࡶࡤ࠻ࠏࠍࠍࠎࠩࠠࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠯ࠍࠋࠋࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪ࠭ࠒࠐࠉࠊࡶ࡬ࡱࡪ࠴ࡳ࡭ࡧࡨࡴ࠭࠷ࠩࠎࠌࠌࠍ࡭ࡺࡴࡱࡦ࠱ࡷ࡭ࡻࡴࡥࡱࡺࡲ࠭࠯ࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳ࠭ࠬࠨࠩࠬࠑࠏࠏࠢࠣࠤ㴗")
	if l1l111l111l_l1_ in [l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㴘"),l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㴙")] or succeeded: response = l1l1111ll11_l1_(l1l1ll11_l1_)
	else: l11ll1l1lll_l1_.stop()
	#if l1l111l111l_l1_ in [l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㴚"),l11lll_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ㴛"),l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㴜"),l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ㴝"),l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㴞")]: l111l11l11l_l1_(l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠳ࡰࡧࠫ㴟"),False)
	#l111l11l11l_l1_(l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏ࠮࠵ࡵࡨࠬ㴠"))
	#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㴡") in url and l1l111l111l_l1_ in [l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㴢"),l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㴣")]:
	#	l11ll1ll111_l1_ = HTTPS(False)
	#	if not l11ll1ll111_l1_:
	#		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㴤"),l11lll_l1_ (u"ࠨࠩ㴥"),l11lll_l1_ (u"ࠩส่ฬะีศๆู้ࠣ็ัࠨ㴦"),l11lll_l1_ (u"ู้้ࠪไสࠢ࠱࠲࠳ࠦ็ัษࠣห้็๊ะ์๋ࠤ๏ำสศฮࠣห้๏ࠠศฬุห้ࠦๅีใิࠤ࠭ืศุุ่ࠢๆื๊ࠩࠡ็็๋ࠦไๅลึๅࠥอไศฬุห้ࠦวๅ็ืๅึࠦไศࠢํ฽ฺ๊๊ࠠๆ์ࠤัํวำๅࠪ㴧"))
	#		return l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㴨")
	#sys.exit()
	if 0 and l1l111l111l_l1_==l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㴩"):
		LOG_THIS(l11lll_l1_ (u"࠭ࠧ㴪"),l11lll_l1_ (u"ࠧࡑࡎࡄ࡝ࡤ࡙ࡔࡂࡖࡘࡗ࠿ࡀࠠࠡࠢࠪ㴫")+l11lll_l1_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ㴬"))
		while True:
			l1l111l111l_l1_ = l11ll1l1lll_l1_.status
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㴭"),l11lll_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡕࡗࡅ࡙࡛ࡓ࠻࠼ࠣࠤࠥ࠭㴮")+l1l111l111l_l1_)
			if l1l111l111l_l1_!=l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㴯"): break
			xbmc.sleep(1000)
		LOG_THIS(l11lll_l1_ (u"ࠬ࠭㴰"),l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ㴱")+l11lll_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ㴲"))
	return l1l111l111l_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1llll1lll_l1_ = args[0]
		l11l1ll1_l1_ = args[1]
		if not l1l1llll1lll_l1_: l1l1llll1lll_l1_ = l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㴳")
		if not l11l1ll1_l1_: l11l1ll1_l1_ = l11lll_l1_ (u"ࠩสืฯ๋ัศำࠪ㴴")
		header = args[2]
		text = l11lll_l1_ (u"ࠪࡠࡳ࠭㴵").join(args[3:])
	else: l1l1llll1lll_l1_,l11l1ll1_l1_,header,text = l11lll_l1_ (u"ࠫࠬ㴶"),l11lll_l1_ (u"ࠬࡕࡋࠨ㴷"),l11lll_l1_ (u"࠭ࠧ㴸"),l11lll_l1_ (u"ࠧࠨ㴹")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1lll_l1_,l11lll_l1_ (u"ࠨࠩ㴺"),l11l1ll1_l1_,l11lll_l1_ (u"ࠩࠪ㴻"),header,text,**kwargs)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1llll1lll_l1_ = args[0]
	l1ll11lll11l_l1_ = args[1]
	l1ll11l11111_l1_ = args[2]
	if l1ll11l11111_l1_ or l1ll11lll11l_l1_: l1ll11ll1l11_l1_ = True
	else: l1ll11ll1l11_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1llll1lll_l1_: l1l1llll1lll_l1_ = l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㴼")
	if not l1ll11lll11l_l1_: l1ll11lll11l_l1_ = l11lll_l1_ (u"่๊ࠫวࠨ㴽")
	if not l1ll11l11111_l1_: l1ll11l11111_l1_ = l11lll_l1_ (u"ࠬ์ูๆࠩ㴾")
	if len(args)>=6: text += l11lll_l1_ (u"࠭࡜࡯ࠩ㴿")+args[5]
	if len(args)>=7: text += l11lll_l1_ (u"ࠧ࡝ࡰࠪ㵀")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1lll_l1_,l1ll11lll11l_l1_,l11lll_l1_ (u"ࠨࠩ㵁"),l1ll11l11111_l1_,header,text,**kwargs)
	if choice==-1 and l1ll11ll1l11_l1_: choice = -1
	elif choice==-1 and not l1ll11ll1l11_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1lll11l11ll_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11lll_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㵂") in list(kwargs.keys()): l11l1l111ll_l1_ = kwargs[l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㵃")]
	else: l11l1l111ll_l1_ = 1000
	if len(args)>2 and l11lll_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ㵄") not in args[2]: profile = args[2]
	else: profile = l11lll_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ㵅")
	l1l11l1ll11l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭㵆"),l11lll1l1ll_l1_,l11lll_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㵇"),l11lll_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㵈"))
	l1ll1llllll1_l1_,l1111111ll1_l1_ = l1l11ll111ll_l1_(l11lll_l1_ (u"ࠩࠪ㵉"),l11lll_l1_ (u"ࠪࠫ㵊"),l11lll_l1_ (u"ࠫࠬ㵋"),header,text,profile,l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ㵌"),720,False)
	#time.sleep(0.200)
	l1l11l1ll11l_l1_.show()
	if profile==l11lll_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ㵍"):
		l1l11l1ll11l_l1_.getControl(9040).setHeight(215)
		l1l11l1ll11l_l1_.getControl(9040).setPosition(55,-80)
		l1l11l1ll11l_l1_.getControl(9050).setPosition(120,-60)
		l1l11l1ll11l_l1_.getControl(400).setPosition(90,-35)
	l1l11l1ll11l_l1_.getControl(401).setVisible(False)
	l1l11l1ll11l_l1_.getControl(402).setVisible(False)
	l1l11l1ll11l_l1_.getControl(9050).setImage(l1ll1llllll1_l1_)
	l1l11l1ll11l_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	import threading
	l11l11l1lll_l1_ = threading.Thread(target=l1l1111ll11l_l1_,args=(l1l11l1ll11l_l1_,l1ll1llllll1_l1_,l11l1l111ll_l1_))
	l11l11l1lll_l1_.start()
	#l11l11l1lll_l1_.join()
	return
	#return xbmcgui.Dialog().l1l11lll1111_l1_(l1l1lll1l1l1_l1_=False,*args,**kwargs)
def l1l1111ll11l_l1_(l1l11l1ll11l_l1_,l1ll1llllll1_l1_,l11l1l111ll_l1_):
	time.sleep(l11l1l111ll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1ll1llllll1_l1_):
		try: os.remove(l1ll1llllll1_l1_)
		except: pass
	#del l1l11l1ll11l_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l1llll1lll_l1_ = l11lll_l1_ (u"ࠧࠨ㵎"),l11lll_l1_ (u"ࠨࠩ㵏"),l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㵐"),l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㵑")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l1llll1lll_l1_ = args[3]
	return l11ll1l1l1_l1_(l1l1llll1lll_l1_,header,text,profile)
	#return xbmcgui.Dialog().l1ll1l111lll_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1l1ll1lll_l1_(*args,**kwargs)
def l11l1l11l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111l1l1lll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text,profile,l1l1llll1lll_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l11l1ll11l_l1_ = l1ll11l1111l_l1_(l11lll_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㵒"),l11lll1l1ll_l1_,l11lll_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭㵓"),l11lll_l1_ (u"࠭࠷࠳࠲ࡳࠫ㵔"))
	#l1l11l1ll11l_l1_.l1111111l1l_l1_(l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text,profile,l1l1llll1lll_l1_,855)
	#return l1l11l1ll11l_l1_
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡶ࡬ࡱࡪࡵࡵࡵࡀ࠳࠾ࠥࡪࡩࡢ࡮ࡲ࡫࠳ࡹࡴࡢࡴࡷࡆࡺࡺࡴࡰࡰࡶࡘ࡮ࡳࡥࡰࡷࡷࠬࡹ࡯࡭ࡦࡱࡸࡸ࠮ࠓࠊࠊࡧ࡯ࡷࡪࡀࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡦࡰࡤࡦࡱ࡫ࡂࡶࡶࡷࡳࡳࡹࠨࠪࠏࠍࠍࠨࡪࡩࡢ࡮ࡲ࡫࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪ࠺࠴࠮ࠏࠣࠡ࠹࠳ࠩࠒࠐࠉࡥ࡫ࡤࡰࡴ࡭࠮ࡥࡱࡐࡳࡩࡧ࡬ࠩࠫࠐࠎࠎࡩࡨࡰ࡫ࡦࡩࠥࡃࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡤࡪࡲ࡭ࡨ࡫ࡉࡅࠏࠍࠍࡹࡸࡹ࠻ࠢࡲࡷ࠳ࡸࡥ࡮ࡱࡹࡩ࠭ࡪࡩࡢ࡮ࡲ࡫࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠯ࠍࠋࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠧࡩ࡫࡬ࠡࡦ࡬ࡥࡱࡵࡧࠎࠌࠌࡶࡪࡺࡵࡳࡰࠣࡧ࡭ࡵࡩࡤࡧࠐࠎࠎࠨࠢࠣ㵕")
def l1ll11l11_l1_(l1ll111ll1ll_l1_):
	if kodi_version>17.99: l1l11l1ll11l_l1_ = l11lll_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭㵖")
	else: l1l11l1ll11l_l1_ = l11lll_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭㵗")
	l1ll111ll1ll_l1_ = l1ll111ll1ll_l1_.lower()
	if l1ll111ll1ll_l1_==l11lll_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ㵘"): xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭㵙")+l1l11l1ll11l_l1_+l11lll_l1_ (u"ࠬ࠯ࠧ㵚"))
	elif l1ll111ll1ll_l1_==l11lll_l1_ (u"࠭ࡳࡵࡱࡳࠫ㵛"): xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧ㵜")+l1l11l1ll11l_l1_+l11lll_l1_ (u"ࠨࠫࠪ㵝"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1lll_l1_,l1llll1l11l1_l1_=l11lll_l1_ (u"ࠩࠪ㵞"),l1l1l111ll11_l1_=l11lll_l1_ (u"ࠪࠫ㵟"),l1llll1l1lll_l1_=l11lll_l1_ (u"ࠫࠬ㵠"),header=l11lll_l1_ (u"ࠬ࠭㵡"),text=l11lll_l1_ (u"࠭ࠧ㵢"),profile=l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㵣"),l1ll11ll111l_l1_=0,l1l1ll11l1l1_l1_=0):
	if not l1l1llll1lll_l1_: l1l1llll1lll_l1_ = l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㵤")
	l1l11l1ll11l_l1_ = l1ll11l1111l_l1_(l11lll_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㵥"),l11lll1l1ll_l1_,l11lll_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㵦"),l11lll_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㵧"))
	l1l11l1ll11l_l1_.l1111111l1l_l1_(l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text,profile,l1l1llll1lll_l1_,900,l1ll11ll111l_l1_,l1l1ll11l1l1_l1_)
	if l1ll11ll111l_l1_>0: l1l11l1ll11l_l1_.l11l11l1111_l1_()
	if l1l1ll11l1l1_l1_>0: l1l11l1ll11l_l1_.l111llll111_l1_()
	if l1ll11ll111l_l1_==0 and l1l1ll11l1l1_l1_==0: l1l11l1ll11l_l1_.enableButtons()
	l1l11l1ll11l_l1_.doModal()
	choice = l1l11l1ll11l_l1_.l11l11l1l1l_l1_
	return choice
def l11ll1l1l1_l1_(l1l1llll1lll_l1_,header,text,profile=l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㵨")):
	if not l1l1llll1lll_l1_: l1l1llll1lll_l1_ = l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ㵩")
	#text = l11lll_l1_ (u"ࠧ࡝ࡰࠪ㵪").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11lll_l1_ (u"ࠨࠩ㵫")
	l1l11l1ll11l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ㵬"),l11lll1l1ll_l1_,l11lll_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㵭"),l11lll_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㵮"))
	l1ll1llllll1_l1_,l1111111ll1_l1_ = l1l11ll111ll_l1_(l11lll_l1_ (u"ࠬ࠭㵯"),l11lll_l1_ (u"࠭ࠧ㵰"),l11lll_l1_ (u"ࠧࠨ㵱"),header,text,profile,l1l1llll1lll_l1_,1270,False)
	l1l11l1ll11l_l1_.show()
	#time.sleep(1)
	#l1l11l1ll11l_l1_.getControl(9050).l1l11l11l1ll_l1_(1270-60)
	l1l11l1ll11l_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	l1l11l1ll11l_l1_.getControl(9050).setImage(l1ll1llllll1_l1_)
	result = l1l11l1ll11l_l1_.doModal()
	#del l1l11l1ll11l_l1_
	try: os.remove(l1ll1llllll1_l1_)
	except: pass
	return result
def l1l11111l_l1_(l1l1l1llll1l_l1_=True):
	if l1l1l1llll1l_l1_:
		l111llll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡵࡷࡶࠬ㵲"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㵳"),l11lll_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㵴"))
		if l111llll1l_l1_: return l111llll1l_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㵵"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡻࡳࡦࡴࡤ࡫ࡪࡴࡴ࠻ࠢࠪ㵶")+results)
	# l11l11l1l11_l1_ and l11111ll11_l1_ common user l1ll111111l1_l1_ (l111l111l11_l1_ l11l11l111l_l1_)
	text = l11lll_l1_ (u"࠭ࠧ㵷")
	url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡨࡧ࡭ࡨ࡬ࡰࡩ࠱ࡻ࡮ࡲ࡬ࡴࡪࡲࡹࡸ࡫࠮ࡤࡱࡰ࠳࠷࠶࠱࠳࠱࠳࠵࠴࠶࠳࠰࡯ࡲࡷࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡶ࠳ࠬ㵸")
	headers = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㵹"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㵺"),url,l11lll_l1_ (u"ࠪࠫ㵻"),headers,l11lll_l1_ (u"ࠫࠬ㵼"),l11lll_l1_ (u"ࠬ࠭㵽"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧ㵾"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11lll_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ㵿"))
		if count>80:
			text = re.findall(l11lll_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㶀"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㶁"),l11lll_l1_ (u"ࠪࠫ㶂"),l11lll_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠧ㶃"),l11lll_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࡙ࠣࡘࡋࡒ࠮ࡃࡊࡉࡓ࡚ࡓࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠬ㶄"))
	if not text:
		l1ll1l1l11ll_l1_ = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㶅"),l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨ㶆"))
		text = open(l1ll1l1l11ll_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㶇")).read()
		if kodi_version>18.99: text = text.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㶈"))
		text = text.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭㶉"),l11lll_l1_ (u"ࠫࠬ㶊"))
	l1ll1ll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡍࡰࡼ࡬ࡰࡱࡧ࠮ࠫࡁࠬࡠࡳ࠭㶋"),text,re.DOTALL)
	l111ll11l1l_l1_ = []
	for line in l1ll1ll1ll1l_l1_:
		l1ll111ll111_l1_ = line.lower()
		if l11lll_l1_ (u"࠭ࡡ࡯ࡦࡵࡳ࡮ࡪࠧ㶌") in l1ll111ll111_l1_: continue
		if l11lll_l1_ (u"ࠧࡶࡤࡸࡲࡹࡻࠧ㶍") in l1ll111ll111_l1_: continue
		if l11lll_l1_ (u"ࠨ࡫ࡳ࡬ࡴࡴࡥࠨ㶎") in l1ll111ll111_l1_: continue
		if l11lll_l1_ (u"ࠩࡦࡶࡴࡹࠧ㶏") in l1ll111ll111_l1_: continue
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡳ࡬ࠨ㶐") in l1ll111ll111_l1_: continue
		l111ll11l1l_l1_.append(line)
	l111llll1l_l1_ = random.sample(l111ll11l1l_l1_,1)
	l111llll1l_l1_ = l111llll1l_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㶑"),l11lll_l1_ (u"ࠬ࠭㶒"),str(len(l1ll1ll1ll1l_l1_)),l111llll1l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㶓"),l11lll_l1_ (u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㶔"),l111llll1l_l1_,REGULAR_CACHE)
	return l111llll1l_l1_
def l11l11l11l1_l1_(l1lll1lllll1_l1_):
	#if l11lll_l1_ (u"ࠨࡨࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹ࠭㶕") in str(error).lower(): return
	#l1lll1lllll1_l1_ = traceback.format_exc()
	sys.stderr.write(l1lll1lllll1_l1_)
	lines = l1lll1lllll1_l1_.splitlines()
	error = lines[-1]
	l1lllll11111_l1_ = open(l1ll1l11ll1l_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ㶖")).read()
	if kodi_version>18.99: l1lllll11111_l1_ = l1lllll11111_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㶗"))
	l1lllll11111_l1_ = l1lllll11111_l1_[-8000:]
	sep = l11lll_l1_ (u"ࠫࡂ࠭㶘")*100
	if sep in l1lllll11111_l1_: l1lllll11111_l1_ = l1lllll11111_l1_.rsplit(sep,1)[1]
	if error in l1lllll11111_l1_: l1lllll11111_l1_ = l1lllll11111_l1_.rsplit(error,1)[0]
	#l11ll1l1l1_l1_(l11lll_l1_ (u"ࠬ࠭㶙"),error,l1lllll11111_l1_)
	#l11lllll111_l1_ = l1lllll11111_l1_.splitlines()
	#for line in reversed(l11lllll111_l1_):
	#	if l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴࠩ㶚") in line or l11lll_l1_ (u"ࠧࡢ࡯ࡳࡰ࡮ࡺࡵࡥࡧ࠱ࡧࡴࡳࠧ㶛") in line: continue
	#	if l11lll_l1_ (u"ࠨࡏࡲࡨࡪࡀࠠ࡜ࠩ㶜") not in line: continue
	l1l1l1l111ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡗࡴࡻࡲࡤࡧࡿࡑࡴࡪࡥࠪ࠼ࠣࡠࡠࠦࠨ࠯ࠬࡂ࠭ࠥࡢ࡝ࠨ㶝"),l1lllll11111_l1_,re.DOTALL)
	for typ,source in reversed(l1l1l1l111ll_l1_):
		#if l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࠬ㶞") in source: continue
		#if l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࠧ㶟") in source: continue
		if source: break
	else: source = l11lll_l1_ (u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬ㶠")
	#l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࠧ㶡"),source,str(l1l1l1l111ll_l1_))
	file,line,func = l11lll_l1_ (u"ࠧࠨ㶢"),l11lll_l1_ (u"ࠨࠩ㶣"),l11lll_l1_ (u"ࠩࠪ㶤")
	l111l1ll1ll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㶥")+error
	l1lll1l11111_l1_ = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅึัิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㶦")+source
	for l1ll11ll1lll_l1_ in reversed(lines):
		if l11lll_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦࠬ㶧") in l1ll11ll1lll_l1_ and l11lll_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㶨") in l1ll11ll1lll_l1_: break
	l1ll11ll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪ㶩"),l1ll11ll1lll_l1_,re.DOTALL)
	if l1ll11ll1lll_l1_:
		file,line,func = l1ll11ll1lll_l1_[0]
		if l11lll_l1_ (u"ࠨ࠱ࠪ㶪") in file: file = file.rsplit(l11lll_l1_ (u"ࠩ࠲ࠫ㶫"),1)[1]
		else: file = file.rsplit(l11lll_l1_ (u"ࠪࡠࡡ࠭㶬"),1)[1]
		l1l11l1l11ll_l1_ = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅๅใ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㶭")+file
		line2 = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิูิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㶮")+line
		l1111l1l111_l1_ = l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ๆห๋ࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㶯")+func
		l1lllll111l1_l1_ = l1l11l1l11ll_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㶰")+line2+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㶱")+l1111l1l111_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㶲")+l1lll1l11111_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㶳")+l111l1ll1ll_l1_
		l1ll11111ll1_l1_ = line2+l11lll_l1_ (u"ࠫࡡࡴࠧ㶴")+l1lll1l11111_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㶵")+l111l1ll1ll_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㶶")+l1l11l1l11ll_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㶷")+l1111l1l111_l1_
		l111lll11ll_l1_ = line2+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㶸")+l111l1ll1ll_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㶹")+l1l11l1l11ll_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㶺")+l1111l1l111_l1_
	else:
		l1l11l1l11ll_l1_,line2,l1111l1l111_l1_ = l11lll_l1_ (u"ࠫࠬ㶻"),l11lll_l1_ (u"ࠬ࠭㶼"),l11lll_l1_ (u"࠭ࠧ㶽")
		l1lllll111l1_l1_ = l1lll1l11111_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㶾")+l111l1ll1ll_l1_
		l1ll11111ll1_l1_ = l1lll1l11111_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㶿")+l111l1ll1ll_l1_
		l111lll11ll_l1_ = l111l1ll1ll_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l11lll_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㷀"),time=2000)
	l1111l11l11_l1_ = l11lll_l1_ (u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧ㷁")+l11lll_l1_ (u"ࠫࡡࡴࠧ㷂")
	addons = l1llllllll1l_l1_()
	l1ll1l11l11l_l1_ = []
	results = addons[l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㷃")]
	l1ll11ll11ll_l1_ = l1l111l1111l_l1_(l11ll111111_l1_)
	if l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㷄") in list(addons.keys()):
		for l1l1l1lll11l_l1_,l1lll1ll1l1l_l1_,l111l1lll11_l1_ in results: l1ll1l11l11l_l1_ = max(l1ll1l11l11l_l1_,l1lll1ll1l1l_l1_)
		if l1ll11ll11ll_l1_<l1ll1l11l11l_l1_:
			header = l11lll_l1_ (u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪ㷅")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㷆"),l11lll_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㷇"),l11lll_l1_ (u"ࠪฮาี๊ฬࠩ㷈"),l11lll_l1_ (u"ࠫำื่อࠩ㷉"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
			if choice==0:
				l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㷊"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ㷋"),l11lll_l1_ (u"ࠧหฯา๎ะ࠭㷌"),l11lll_l1_ (u"ࠨࠩ㷍"),header)
				if l1ll11l111_l1_==1: choice = 1
			if choice==1:
				import l11ll1ll1ll_l1_
				l11ll1ll1ll_l1_.l1ll111lllll_l1_()
			return
	l1l1111ll111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㷎"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㷏"),l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㷐"))
	if not l1l1111ll111_l1_: l1l1111ll111_l1_ = []
	l1ll11111ll1_l1_ = l1ll11111ll1_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㷑"),l11lll_l1_ (u"࠭࡜࡝ࡰࠪ㷒")).replace(l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㷓"),l11lll_l1_ (u"ࠨࠩ㷔")).replace(l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㷕"),l11lll_l1_ (u"ࠪࠫ㷖")).replace(l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㷗"),l11lll_l1_ (u"ࠬ࠭㷘"))
	l111lll11ll_l1_ = l111lll11ll_l1_.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ㷙"),l11lll_l1_ (u"ࠧ࡝࡞ࡱࠫ㷚")).replace(l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㷛"),l11lll_l1_ (u"ࠩࠪ㷜")).replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㷝"),l11lll_l1_ (u"ࠫࠬ㷞")).replace(l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㷟"),l11lll_l1_ (u"࠭ࠧ㷠"))
	l1l111l1l1ll_l1_ = l11ll111111_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ㷡")+l111lll11ll_l1_
	if l1l111l1l1ll_l1_ in l1l1111ll111_l1_:
		header = l11lll_l1_ (u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㷢")
		#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㷣"),l11lll_l1_ (u"ࠪาึ๎ฬࠨ㷤"),l11lll_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㷥"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
		#if l1ll11l111_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㷦"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ㷧"),l11lll_l1_ (u"ࠧࠨ㷨"),header)
		DIALOG_OK(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㷩"),l11lll_l1_ (u"ࠩࠪ㷪"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
		return
	l1l111ll1l1l_l1_ = str(kodi_version).split(l11lll_l1_ (u"ࠪ࠲ࠬ㷫"))[0]
	#l111lll1lll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㷬"),l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㷭"),l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡏࡓࡕࡗࡏࡡࡈࡖࡗࡕࡒࡔࠩ㷮"))
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㷯")][6]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㷰"),url,l11lll_l1_ (u"ࠩࠪ㷱"),l11lll_l1_ (u"ࠪࠫ㷲"),l11lll_l1_ (u"ࠫࠬ㷳"),l11lll_l1_ (u"ࠬ࠭㷴"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗ࠲࠷ࡳࡵࠩ㷵"),False,False)
	html = response.content
	l111lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡋࡎࡅ࠼࠽ࡉࡓࡊࠧ㷶"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㷷"),l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡋࡏࡑ࡚ࡒࡤࡋࡒࡓࡑࡕࡗࠬ㷸"),l111lll1lll_l1_,REGULAR_CACHE)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㷹"),line+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㷺")+error+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㷻")+l11ll111111_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㷼")+l1l111ll1l1l_l1_)
	for l1111l11111_l1_,l111l1ll1l1_l1_,l1lll1111lll_l1_,l1ll11111l1l_l1_ in l111lll1lll_l1_:
		l1111l11111_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"ࠧࠬࠩ㷽"))
		l1lll1111lll_l1_ = l1lll1111lll_l1_.split(l11lll_l1_ (u"ࠨ࠭ࠪ㷾"))
		l1ll11111l1l_l1_ = l1ll11111l1l_l1_.split(l11lll_l1_ (u"ࠩ࠮ࠫ㷿"))
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㸀"),str(l1111l11111_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㸁")+l111l1ll1l1_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㸂")+str(l1lll1111lll_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㸃")+str(l1ll11111l1l_l1_))
		if line in l1111l11111_l1_ and error==l111l1ll1l1_l1_ and l11ll111111_l1_ in l1lll1111lll_l1_ and l1l111ll1l1l_l1_ in l1ll11111l1l_l1_:
			header = l11lll_l1_ (u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬ㸄")
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㸅"),l11lll_l1_ (u"ࠩัีําࠧ㸆"),l11lll_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㸇"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
			if l1ll11l111_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㸈"),l11lll_l1_ (u"ࠬ࠭㸉"),l11lll_l1_ (u"࠭ࠧ㸊"),header)
			return
	header = l11lll_l1_ (u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ㸋")
	DIALOG_OK(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㸌"),l11lll_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㸍"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㸎"),l11lll_l1_ (u"่๊ࠫวࠨ㸏"),l11lll_l1_ (u"ࠬ์ูๆࠩ㸐"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㸑"),l11lll_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏฿ัโࠢส่๊ฮัๆฮࠣว๏์้ࠠ็อํࠥ๎ใ๋ใࠣ์้๋วัษࠣัฺ๊ส้ࠡำ๋ࠥอไๆึๆ่ฮࠦไฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠤํ๊วࠡ์ึฮ฼๐ูࠡษุ่ฬำࠠๆึๆ่ฮ่่๊่ࠦࠣฬฺ๊ࠦำไࠤ่๐แฺ๊ࠡีฯ่ࠦๅ็สิฬุ่ࠦำอࠤํ๋ส๊ࠢ฻๋ึะ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ࠴่ࠠๆࠣฮึ๐ฯࠡลิืฬ๊ࠠศๆึะ้ࠦฟࠨ㸒"))
	if l1ll11l111_l1_==1: l1l111l1lll1_l1_ = l11lll_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ㸓")
	else:
		DIALOG_OK(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㸔"),l11lll_l1_ (u"ࠪࠫ㸕"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㸖"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪ㸗"))
		return
	message = l1ll11111ll1_l1_
	import l11ll1ll1ll_l1_
	succeeded = l11ll1ll1ll_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶࡸ࠭㸘"),message,True,l11lll_l1_ (u"ࠧࠨ㸙"),l11lll_l1_ (u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲ࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪ㸚"),l1l111l1lll1_l1_)
	if succeeded and l1l111l1lll1_l1_:
		l1l1111ll111_l1_.append(l1l111l1l1ll_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㸛"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㸜"),l1l1111ll111_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㸝"))
	filename = l11lll_l1_ (u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬ㸞")+str(time.time())+l11lll_l1_ (u"࠭࠮ࡥࡣࡷࠫ㸟")
	open(filename,l11lll_l1_ (u"ࠧࡸࡤࠪ㸠")).write(data)
	return
def l11l1111ll1_l1_(l11llllll1l_l1_):
	if l11llllll1l_l1_:
		l1l1l1l1111l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㸡"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㸢"),l11lll_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㸣"))
		if l1l1l1l1111l_l1_: return l1l1l1l1111l_l1_
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㸤")][5]
	user = l11llll111l_l1_(32)
	l1lll1ll1lll_l1_ = l11l1ll1111_l1_()
	l1ll111l1l1l_l1_ = l1lll1ll1lll_l1_.split(l11lll_l1_ (u"ࠬ࠲ࠧ㸥"))[2]
	l1l1lll1l1ll_l1_ = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㸦"))
	l1ll1ll1l11l_l1_ = l1l11l11l1l1_l1_()
	payload = {l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ㸧"):user,l11lll_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ㸨"):l11ll111111_l1_,l11lll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㸩"):l1ll111l1l1l_l1_,l11lll_l1_ (u"ࠪ࡭ࡩࡹࠧ㸪"):l1l1lll11l1l_l1_(l1ll1ll1l11l_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ㸫"),url,payload,l11lll_l1_ (u"ࠬ࠭㸬"),l11lll_l1_ (u"࠭ࠧ㸭"),l11lll_l1_ (u"ࠧࠨ㸮"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭㸯"))
	if not response.succeeded: return []
	html = response.content
	l1l1l1l1111l_l1_ = html.replace(l11lll_l1_ (u"ࠩ࡟ࡠࡷ࠭㸰"),l11lll_l1_ (u"ࠪࡠࡳ࠭㸱")).replace(l11lll_l1_ (u"ࠫࡡࡢ࡮ࠨ㸲"),l11lll_l1_ (u"ࠬࡢ࡮ࠨ㸳")).replace(l11lll_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ㸴"),l11lll_l1_ (u"ࠧ࡝ࡰࠪ㸵")).replace(l11lll_l1_ (u"ࠨ࡞ࡵࠫ㸶"),l11lll_l1_ (u"ࠩ࡟ࡲࠬ㸷"))
	l1l1l1l1111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㸸"),l1l1l1l1111l_l1_,re.DOTALL)
	if not l1l1l1l1111l_l1_: return []
	l1l1l1l1111l_l1_ = sorted(l1l1l1l1111l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1111lllll_l1_,l1l11l111ll1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l1l1111l_l1_[0]
	#if l11lll_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ㸹") in reason: l1l1llll11l1_l1_,l1l1llll11ll_l1_,l1l1llll1l11_l1_ = reason.split(l11lll_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ㸺"),2)
	#else: l1l1llll11l1_l1_,l1l1llll11ll_l1_,l1l1llll1l11_l1_ = reason,reason,reason
	l1ll1111l11l_l1_ = reason if l11l1llll1l_l1_(l11lll_l1_ (u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬ㸻")) else l1l11l111ll1_l1_
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ㸼"),l1ll1111l11l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㸽"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㸾"),l1l1l1l1111l_l1_,REGULAR_CACHE)
	return l1l1l1l1111l_l1_
def SPLIT_BIGLIST(items,l1l111l1l11l_l1_=0,l1ll1l1ll1ll_l1_=0):
	if l1l111l1l11l_l1_ and not l1ll1l1ll1ll_l1_: l1ll1l1ll1ll_l1_ = len(items)//l1l111l1l11l_l1_
	l1ll11ll11l1_l1_,l11ll111l1_l1_,l1ll111ll11l_l1_ = [],-1,0
	for item in items:
		if l1ll111ll11l_l1_%l1ll1l1ll1ll_l1_==0:
			l11ll111l1_l1_ += 1
			l1ll11ll11l1_l1_.append([])
		l1ll11ll11l1_l1_[l11ll111l1_l1_].append(item)
		l1ll111ll11l_l1_ += 1
	return l1ll11ll11l1_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡮ࡨࡲ࡬ࡺࡨࠡ࠿ࠣࡰࡪࡴࠨࡣ࡫ࡪࡰ࡮ࡹࡴࠪࠏࠍࠍࡸࡶ࡬ࡪࡶࡷࡩࡩࠦ࠽ࠡ࡝ࡠࠑࠏࠏࡦࡰࡴࠣ࡭࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࠳࠯ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵ࠭࠴࠭࠿ࠓࠊࠊࠋ࡬ࡪࠥ࡯ࡩࠢ࠿ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴ࠻ࠏࠍࠍࠎࠏ࡬ࡪࡰࡨࡷ࠵ࠦ࠽ࠡࡤ࡬࡫ࡱ࡯ࡳࡵ࡝࠳࠾࡮ࡴࡴࠩ࡮ࡨࡲ࡬ࡺࡨ࠰ࡵࡳࡰ࡮ࡺࡳࡠࡥࡲࡹࡳࡺࠩ࡞ࠏࠍࠍࠎࠏࡤࡦ࡮ࠣࡦ࡮࡭࡬ࡪࡵࡷ࡟࠵ࡀࡩ࡯ࡶࠫࡰࡪࡴࡧࡵࡪ࠲ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵࠫࡠࠍࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡱ࡯࡮ࡦࡵ࠳ࠤࡂࠦࡢࡪࡩ࡯࡭ࡸࡺࠍࠋࠋࠌࠍࡩ࡫࡬ࠡࡤ࡬࡫ࡱ࡯ࡳࡵࠏࠍࠍࠎࡹࡰ࡭࡫ࡷࡸࡪࡪ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱࡩࡸ࠶ࠩࠎࠌࠌࠍࡩ࡫࡬ࠡ࡮࡬ࡲࡪࡹ࠰ࠎࠌࠌࡶࡪࡺࡵࡳࡰࠣࡷࡵࡲࡩࡵࡶࡨࠑࠏࠏࠢࠣࠤ㸿")
def l1llllll1ll1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11lll_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ㹀"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11lll_l1_ (u"ࠬࡏࡐࡕࡘࡢࠫ㹁") not in filename or l11lll_l1_ (u"࠭ࡍ࠴ࡗࡢࠫ㹂") not in filename: text = str(data)
	else:
		l1ll11ll11l1_l1_ = SPLIT_BIGLIST(data,8)
		text = l11lll_l1_ (u"ࠧࠨ㹃")
		for split in l1ll11ll11l1_l1_:
			text += str(split)+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㹄")
		text = text.strip(l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㹅"))
	l11lll1l111_l1_ = zlib.compress(text)
	open(filepath,l11lll_l1_ (u"ࠪࡻࡧ࠭㹆")).write(l11lll1l111_l1_)
	return
def l111ll111ll_l1_(l11lll1ll1l_l1_,filename):
	if l11lll1ll1l_l1_==l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㹇"): data = {}
	elif l11lll1ll1l_l1_==l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ㹈"): data = []
	elif l11lll1ll1l_l1_==l11lll_l1_ (u"࠭ࡳࡵࡴࠪ㹉"): data = l11lll_l1_ (u"ࠧࠨ㹊")
	elif l11lll1ll1l_l1_==l11lll_l1_ (u"ࠨ࡫ࡱࡸࠬ㹋"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l11lll1l111_l1_ = open(filepath,l11lll_l1_ (u"ࠩࡵࡦࠬ㹌")).read()
	text = zlib.decompress(l11lll1l111_l1_)
	#open(l11lll_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡊࡒࡗ࡚࠶࠴ࡴࡹࡶࠪ㹍"),l11lll_l1_ (u"ࠫࡼࡨࠧ㹎")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11lll_l1_ (u"ࠬࡪࡵ࡮࡯ࡼࡲࡦࡳࡥࠨ㹏"))
	#if l11lll_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㹐") not in text: data = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ㹑"),text)
	if l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㹒") not in text: data = eval(text)
	else:
		l1ll11ll11l1_l1_ = text.split(l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㹓"))
		del text
		data = []
		l1111ll1l1l_l1_ = l11111lllll_l1_()
		id = 0
		for split in l1ll11ll11l1_l1_:
			#data += EVAL(l11lll_l1_ (u"ࠪࡷࡹࡸࠧ㹔"),split)
			l1111ll1l1l_l1_.l11111l11ll_l1_(str(id),eval,split)
			id += 1
		del l1ll11ll11l1_l1_
		l1111ll1l1l_l1_.l1l1ll1ll1ll_l1_()
		l1111ll1l1l_l1_.l1l111l1l111_l1_()
		l1l11l111l1l_l1_ = list(l1111ll1l1l_l1_.l1ll1l1lll1l_l1_.keys())
		l1l11lll1lll_l1_ = sorted(l1l11l111l1l_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l11lll1lll_l1_:
			data += l1111ll1l1l_l1_.l1ll1l1lll1l_l1_[id]
	return data
def l1ll111llll1_l1_(addon_id):
	l111l1l11l1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㹕"),addon_id,l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ㹖"))
	try: l1ll1ll1l1ll_l1_ = open(l111l1l11l1_l1_,l11lll_l1_ (u"࠭ࡲࡣࠩ㹗")).read()
	except:
		l1ll111l1ll1_l1_ = os.path.join(l1lll11ll111_l1_,l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㹘"),addon_id,l11lll_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ㹙"))
		try: l1ll1ll1l1ll_l1_ = open(l1ll111l1ll1_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ㹚")).read()
		except: return l11lll_l1_ (u"ࠪࠫ㹛"),[]
	if kodi_version>18.99: l1ll1ll1l1ll_l1_ = l1ll1ll1l1ll_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㹜"))
	version = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩ㹝"),l1ll1ll1l1ll_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11lll_l1_ (u"࠭ࠧ㹞"),[]
	l11l11lll11_l1_,l11111l1111_l1_ = version[0],l1l111l1111l_l1_(version[0])
	return l11l11lll11_l1_,l11111l1111_l1_
def l1llllllll1l_l1_():
	l1llll11llll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㹟"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㹠"),l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㹡"))
	if l1llll11llll_l1_: return l1llll11llll_l1_
	addons,l1llll11llll_l1_ = {},{}
	l1l1l1l111ll_l1_ = [l1ll11l_l1_[l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㹢")][0]]
	if kodi_version>17.99: l1l1l1l111ll_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㹣")][1])
	if kodi_version>18.99: l1l1l1l111ll_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㹤")][2])
	for l1l1l1111lll_l1_ in l1l1l1l111ll_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㹥"),l1l1l1111lll_l1_,l11lll_l1_ (u"ࠧࠨ㹦"),l11lll_l1_ (u"ࠨࠩ㹧"),l11lll_l1_ (u"ࠩࠪ㹨"),l11lll_l1_ (u"ࠪࠫ㹩"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㹪"))
		if response.succeeded:
			html = response.content
			l1l111ll11l1_l1_ = l1l1l1111lll_l1_.rsplit(l11lll_l1_ (u"ࠬ࠵ࠧ㹫"),1)[0]
			l1llll1l111l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㹬"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1llllll11ll_l1_ in l1llll1l111l_l1_:
				l11111l111l_l1_ = l1l111ll11l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㹭")+addon_id+l11lll_l1_ (u"ࠨ࠱ࠪ㹮")+addon_id+l11lll_l1_ (u"ࠩ࠰ࠫ㹯")+l1llllll11ll_l1_+l11lll_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ㹰")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1llll11llll_l1_[addon_id] = []
				l1lll111l1ll_l1_ = l1l111l1111l_l1_(l1llllll11ll_l1_)
				addons[addon_id].append((l1llllll11ll_l1_,l1lll111l1ll_l1_,l11111l111l_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㹱"),str(addon_id)+l11lll_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫ㹲")+str(addons[addon_id]))
		l1llll11llll_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㹳"),l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ㹴"),l1llll11llll_l1_,REGULAR_CACHE)
	return l1llll11llll_l1_
	l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ࠯ࠍࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡰࡦࡨࡦࡪࡸࡧ࠯ࡱࡵ࡫࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡦࡷࡧ࡮ࡤࡪ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡧࡤ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡢࡳࡣࡱࡧ࡭࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸࡪ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠷࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࠨࠢࠣ㹵")
def l1l111l1111l_l1_(l1llllll11ll_l1_):
	l1lll111l1ll_l1_ = []
	l1l1lll11ll_l1_ = l1llllll11ll_l1_.split(l11lll_l1_ (u"ࠩ࠱ࠫ㹶"))
	for l1l111l111_l1_ in l1l1lll11ll_l1_:
		parts = re.findall(l11lll_l1_ (u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧ㹷"),l1l111l111_l1_,re.DOTALL)
		l1l11l11l111_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11l11l111_l1_.append(part)
		l1lll111l1ll_l1_.append(l1l11l11l111_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㹸"),str(l1llllll11ll_l1_)+l11lll_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫ㹹")+str(l1lll111l1ll_l1_))
	return l1lll111l1ll_l1_
def l1l1llllllll_l1_(l1lll111l1ll_l1_):
	l1llllll11ll_l1_ = l11lll_l1_ (u"࠭ࠧ㹺")
	for l1l111l111_l1_ in l1lll111l1ll_l1_:
		for part in l1l111l111_l1_: l1llllll11ll_l1_ += str(part)
		l1llllll11ll_l1_ += l11lll_l1_ (u"ࠧ࠯ࠩ㹻")
	l1llllll11ll_l1_ = l1llllll11ll_l1_.strip(l11lll_l1_ (u"ࠨ࠰ࠪ㹼"))
	return l1llllll11ll_l1_
def l1ll1lll1l1l_l1_(l111ll11111_l1_):
	# l1l1l11ll11l_l1_ not l111l111l1l_l1_ l1l1ll1l1ll1_l1_ l1l11llll1l1_l1_ addons status l1lllllll1l_l1_ l11l111ll1_l1_ l111l1llll_l1_ l1111111lll_l1_
	#l1l111ll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㹽"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㹾"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ㹿"))
	#if l1l111ll1l11_l1_: return l1l111ll1l11_l1_
	l1l111ll1l11_l1_ = {}
	addons = l1llllllll1l_l1_()
	l111lllll11_l1_ = l1l1ll1ll1l1_l1_(l111ll11111_l1_)
	for addon_id in l111ll11111_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1llll11llll_l1_ = addons[addon_id]
		l1ll1l11l111_l1_,l111lll111l_l1_,l1l1111l1l11_l1_ = l1llll11llll_l1_[0]
		#l1llll111111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬ㺀")+addon_id+l11lll_l1_ (u"࠭ࠩࠨ㺁"))
		l1llll111111_l1_,l111111ll11_l1_ = l1ll111llll1_l1_(addon_id)
		l111l11ll1l_l1_,l1ll1l1ll111_l1_ = l111lllll11_l1_[addon_id]
		l11l1111lll_l1_ = l111lll111l_l1_>l111111ll11_l1_ and l111l11ll1l_l1_
		l1l1111l1ll1_l1_ = True
		if not l111l11ll1l_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ㺂")
		elif not l1ll1l1ll111_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ㺃")
		elif l11l1111lll_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"ࠩࡲࡰࡩ࠭㺄")
		else:
			l11l11lllll_l1_ = l11lll_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ㺅")
			l1l1111l1ll1_l1_ = False
		l1l111ll1l11_l1_[addon_id] = (l1l1111l1ll1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l11l111_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1l11_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㺆"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ㺇"),l1l111ll1l11_l1_,REGULAR_CACHE)
	return l1l111ll1l11_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍࠨ࡯ࡦࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴ࠯࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠱࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡂࠦࡶࡦࡴࡶ࡭ࡴࡴࠬࡕࡴࡸࡩ࠱࡚ࡲࡶࡧࠐࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠱࡯ࡳࡠࡧࡻ࡭ࡸࡺࠬࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡࠩࠪ࠰ࡋࡧ࡬ࡴࡧ࠯ࡊࡦࡲࡳࡦࠏࠍࠍࠨ࡯ࡳࡠࡧࡻ࡭ࡸࡺࠠ࠾ࠢࠫࡼࡧࡳࡣ࠯ࡩࡨࡸࡈࡵ࡮ࡥࡘ࡬ࡷ࡮ࡨࡩ࡭࡫ࡷࡽ࠭࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠩࠨࠫࡀࡁ࠶࠯ࠍࠋࠋࠦ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡀࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵࡂࠬ࠭ࠍࠋࠋࠦ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤ࠭ࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡃࡰࡰࡧ࡚࡮ࡹࡩࡣ࡫࡯࡭ࡹࡿࠨࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡉࡴࡇࡱࡥࡧࡲࡥࡥࠪࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠪࠩࠬࡁࡂ࠷ࠩࠎࠌࠌࠧࡪࡲࡳࡦ࠼ࠣ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࡱࡳࡹࠦࠨࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡪࡵࡢࡩࡽ࡯ࡳࡵࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࡠࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࡣࡻ࡫ࡲࡠࡥࡲࡱࡵࡧࡲࡦࠋࠌࠫ࠰ࡹࡴࡳࠪ࡫࡭࡬࡮ࡥࡴࡶࡢࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲࡠࡥࡲࡱࡵࡧࡲࡦࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠌࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡳࡱࡪࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡵ࡬ࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠌࠍࠬ࠱ࡳࡵࡴࠫࡲࡪ࡫ࡤࡠࡷࡳࡨࡦࡺࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡴࡶࡤࡸࡺࡹࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡷࡹࡧࡴࡶࡵࠬ࠭ࠒࠐࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࡴ࠼ࠣࠤࠬ࠱ࡳࡵࡴࠫࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠯ࠫࠨࠢࠣࠫ࠰ࡹࡴࡳࠪ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩ࠯ࠩࠎࠌࠌࠦࠧࠨ㺈")
def PROGRESS_UPDATE(l11l1ll11l_l1_,l1lll1l1l1l1_l1_,l11111llll1_l1_=l11lll_l1_ (u"ࠧࠨ㺉"),line2=l11lll_l1_ (u"ࠨࠩ㺊"),l1111l11111_l1_=l11lll_l1_ (u"ࠩࠪ㺋")):
	if kodi_version<19: l11l1ll11l_l1_.update(l1lll1l1l1l1_l1_,l11111llll1_l1_,line2,l1111l11111_l1_)
	else: l11l1ll11l_l1_.update(l1lll1l1l1l1_l1_,l11111llll1_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㺌")+line2+l11lll_l1_ (u"ࠫࡡࡴࠧ㺍")+l1111l11111_l1_)
	return
def l1l1ll1llll1_l1_(l1ll11l1llll_l1_):
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,d)
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,r)
	# l1lll111111l_l1_ l1l1l1l1ll1l_l1_:  https://l1ll11ll1ll1_l1_.io
	def l1ll1ll1l111_l1_(num,b,l1l1ll111111_l1_=l11lll_l1_ (u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧ㺎")):
		return ((num == 0) and l1l1ll111111_l1_[0]) or (l1ll1ll1l111_l1_(num // b, b, l1l1ll111111_l1_).lstrip(l1l1ll111111_l1_[0]) + l1l1ll111111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11lll_l1_ (u"ࠨ࡜࡝ࡤࠥ㺏") + l1ll1ll1l111_l1_(c, a) + l11lll_l1_ (u"ࠢ࡝࡞ࡥࠦ㺐"),  k[c], p)
		return p
	l1ll11l1llll_l1_ = l1ll11l1llll_l1_.split(l11lll_l1_ (u"ࠨࡿࠫࠫ㺑"))[1][:-1]
	l1l1l1ll1l1l_l1_ = eval(l11lll_l1_ (u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ㺒")+l1ll11l1llll_l1_,{l11lll_l1_ (u"ࠪࡦࡦࡹࡥࡏࠩ㺓"):l1ll1ll1l111_l1_,l11lll_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ㺔"):unpack})   #,locals())
	return l1l1l1ll1l1l_l1_
def l1ll1l1ll1_l1_(url,l1ll11l1l111_l1_=l11lll_l1_ (u"ࠬ࠭㺕")):
	if l1ll11l1l111_l1_==l11lll_l1_ (u"࠭࡬ࡰࡹࡨࡶࠬ㺖"): url = re.sub(l11lll_l1_ (u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧ㺗"),lambda l11l111llll_l1_: l11l111llll_l1_.group(0).lower(),url)
	elif l1ll11l1l111_l1_==l11lll_l1_ (u"ࠨࡷࡳࡴࡪࡸࠧ㺘"): url = re.sub(l11lll_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩ㺙"),lambda l11l111llll_l1_: l11l111llll_l1_.group(0).upper(),url)
	return url
def l1l1ll1ll1l1_l1_(l111ll11111_l1_):
	installed,l1lll11ll11l_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1l11ll1l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll11111_l1_)==1: l1llllllll11_l1_ = l11lll_l1_ (u"ࠪࠬࠧ࠭㺚")+l111ll11111_l1_[0]+l11lll_l1_ (u"ࠫࠧ࠯ࠧ㺛")
	else: l1llllllll11_l1_ = str(tuple(l111ll11111_l1_))
	cc.execute(l11lll_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ㺜")+l1llllllll11_l1_+l11lll_l1_ (u"࠭ࠠ࠼ࠩ㺝"))
	l11ll1ll11l_l1_ = cc.fetchall()
	l111lllll11_l1_ = {}
	for addon_id in l111ll11111_l1_: l111lllll11_l1_[addon_id] = (False,False)
	for addon_id,l1lll11ll11l_l1_ in l11ll1ll11l_l1_:
		installed = True
		l1lll11ll11l_l1_ = l1lll11ll11l_l1_==1
		l111lllll11_l1_[addon_id] = (installed,l1lll11ll11l_l1_)
	conn.close()
	return l111lllll11_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11lll_l1_ (u"ࠧࠨ㺞")
	if file==l1l111l111l1_l1_: status = l11111l1ll1_l1_(True,False)
	if os.path.exists(file):
		l11ll11llll_l1_ = open(file,l11lll_l1_ (u"ࠨࡴࡥࠫ㺟")).read()
		if kodi_version>18.99: l11ll11llll_l1_ = l11ll11llll_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㺠"))
		if file==l1l111l111l1_l1_: results = l11ll11llll_l1_
		else:
			l1llll111l11_l1_ = EVAL(l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㺡"),l11ll11llll_l1_)
			if l1llll111l11_l1_:
				results = {}
				for key in l1llll111l11_l1_.keys():
					results[key] = []
					for l1ll1lll1ll1_l1_ in l1llll111l11_l1_[key]:
						type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_ = l11lll_l1_ (u"ࠫࠬ㺢"),l11lll_l1_ (u"ࠬ࠭㺣"),l11lll_l1_ (u"࠭ࠧ㺤"),l11lll_l1_ (u"ࠧࠨ㺥"),l11lll_l1_ (u"ࠨࠩ㺦"),l11lll_l1_ (u"ࠩࠪ㺧"),l11lll_l1_ (u"ࠪࠫ㺨"),l11lll_l1_ (u"ࠫࠬ㺩"),l11lll_l1_ (u"ࠬ࠭㺪")
						type = l1ll1lll1ll1_l1_[0]
						name = l1ll1lll1ll1_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1ll1lll1ll1_l1_[2]
						mode = l1ll1lll1ll1_l1_[3]
						l11l_l1_ = l1ll1lll1ll1_l1_[4]
						l1l11l1_l1_ = l1ll1lll1ll1_l1_[5]
						if len(l1ll1lll1ll1_l1_)>6: text = l1ll1lll1ll1_l1_[6]
						if len(l1ll1lll1ll1_l1_)>7: context = l1ll1lll1ll1_l1_[7]
						if len(l1ll1lll1ll1_l1_)>8: l1ll11111ll_l1_ = l1ll1lll1ll1_l1_[8]
						if file==favoritesfile: l1l111lllll1_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,l11lll_l1_ (u"࠭ࠧ㺫"),l1ll11111ll_l1_
						else: l1l111lllll1_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111ll_l1_
						results[key].append(l1l111lllll1_l1_)
			l11ll11111l_l1_ = str(results)
			if kodi_version>18.99: l11ll11111l_l1_ = l11ll11111l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㺬"))
			open(file,l11lll_l1_ (u"ࠨࡹࡥࠫ㺭")).write(l11ll11111l_l1_)
	return results
def l1l1l11l11l_l1_(l1l1l1l1ll1_l1_):
	l1l1l11lll1_l1_ = l1l1l1l1ll1_l1_.split(l11lll_l1_ (u"ࠩ࠰ࠫ㺮"),1)[0]
	l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_ = l11lll_l1_ (u"ࠪࠫ㺯"),l11lll_l1_ (u"ࠫࠬ㺰"),l11lll_l1_ (u"ࠬ࠭㺱")
	if   l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㺲")		:	from l1l111l_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㺳")	:	from l1l1l111_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㺴")		:	from l111111_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㺵")	:	from l111l1l1_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㺶")	:	from l1ll11ll1_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㺷")	: 	from l1l1ll111_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㺸")	:	from l1l1l1lll_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㺹")	:	from l11l1l111_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㺺")		:	from l1111l11l_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㺻")	:	from l1llllllll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ㺼")	:	from l1lll11l1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㺽")	:	from l1ll1lll1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㺾")	:	from l1ll1ll11l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㺿"):	from l111ll1ll1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㻀")		:	from l1l1ll1ll1l_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㻁")		:	from l1ll1ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㻂")	:	from l1l1lllll11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㻃")	:	from l1lll11ll1_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㻄")	:	from l1lll1lll1ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㻅")	:	from l1111111l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ㻆")	:	from l1l111l11ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㻇")	:	from l111111l1_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㻈")		:	from l111llllll1_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ㻉")	:	from l1l11l11l11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㻊"):	from l1l11ll11_l1_	import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㻋")	:	from l111lll1l1_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㻌")	:	from l1ll1l1lll_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㻍"):	from l11lll1lll_l1_	import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ㻎")	:	from l11111ll1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㻏")	:	from l1llll1ll11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㻐")	:	from l1lll1l1l1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㻑")	:	from l1lll11l1ll_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㻒")	:	from l1lll11l11l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㻓")	:	from l1ll1l1ll11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㻔")	:	from l1ll1l1l1ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㻕")	:	from l1l1llll11l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㻖")	:	from l1l1l111l11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㻗")	:	from l1lll1l111_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㻘")		:	from l1l1l1111ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㻙")		:	from IPTV			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,menu_namee as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡒ࠹ࡕࠨ㻚")		:	from M3U			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㻛")	:	from l1l11l1l1l1_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㻜")	:	from l11l11ll11l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㻝")	:	from l1l1ll111ll1_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㻞")	:	from l1ll1111ll11_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㻟")	:	from l1l1l11ll1ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㻠")	:	from l1l1lll1lll_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㻡")	:	from l1l1lll111l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㻢")		:	from l1111l111ll_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㻣")	:	from l1l1l11l1l11_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㻤")	:	from l1111l1l1l1_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㻥")	:	from l11l111l111_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㻦")	:	from l1l11ll1ll1l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㻧")		:	from l1lll11l1l1l_l1_			import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㻨")	:	from l111llll11l_l1_		import MENU as l1l1l11ll1l_l1_,SEARCH as l1l1l1l1l1l_l1_,l111ll_l1_ as l1l1ll1l1ll_l1_
	elif l1l1l11lll1_l1_==l11lll_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㻩"):	from l111l1lll1l_l1_	import MENU as l1l1l11ll1l_l1_
	return l1l1l11ll1l_l1_,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l1111l1l1l_l1_,headers,l1ll_l1_):
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ㻪"),l11lll_l1_ (u"ࠧࠨ㻫"),l11lll_l1_ (u"ࠨࠩ㻬"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㻭"),l11lll_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆู็์อࠦๅ็ࠢส่ส์สา่อࠤํ่ฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠥࠬ㻮"))
	#if l1ll11l111_l1_!=1: return l11lll_l1_ (u"ࠫࠬ㻯")
	LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㻰"),l11lll_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫ㻱")+l1l1111l1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ㻲")+str(headers)+l11lll_l1_ (u"ࠨࠢࡠࠫ㻳"))
	l11l1ll11l_l1_ = DIALOG_PROGRESS()
	l11l1ll11l_l1_.create(l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㻴"),l11lll_l1_ (u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬ㻵"))
	l11ll11ll1_l1_ = 1024*1024
	l111l1ll111_l1_ = bytes()
	chunk_size = 2*l11ll11ll1_l1_
	import requests
	response = requests.get(l1l1111l1l1l_l1_,stream=True,headers=headers)
	l1l11ll1ll11_l1_ = response.headers
	response.close()
	if not l1l11ll1ll11_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㻶"),l11lll_l1_ (u"ࠬ࠭㻷"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㻸"),l11lll_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪ㻹"))
		l11l1ll11l_l1_.close()
	else:
		if l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ㻺") not in list(l1l11ll1ll11_l1_.keys()): filesize = 0
		else: filesize = int(l1l11ll1ll11_l1_[l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪ㻻")])
		l11ll11111_l1_ = str(int(1000*filesize/l11ll11ll1_l1_)/1000.0)
		l11l11l1ll_l1_ = int(filesize/chunk_size)+1
		if l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪ㻼") in list(l1l11ll1ll11_l1_.keys()) and filesize>l11ll11ll1_l1_:
			l1l1l111l11l_l1_ = True
			ranges = []
			l1l1l11l1lll_l1_ = 10
			ranges.append(str(0*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠫ࠲࠭㻽")+str(1*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(1*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ㻾")+str(2*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(2*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"࠭࠭ࠨ㻿")+str(3*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(3*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠧ࠮ࠩ㼀")+str(4*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(4*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠨ࠯ࠪ㼁")+str(5*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(5*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠩ࠰ࠫ㼂")+str(6*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(6*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ㼃")+str(7*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(7*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠫ࠲࠭㼄")+str(8*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(8*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ㼅")+str(9*filesize//l1l1l11l1lll_l1_-1))
			ranges.append(str(9*filesize//l1l1l11l1lll_l1_)+l11lll_l1_ (u"࠭࠭ࠨ㼆"))
			l111ll1l1ll_l1_ = float(l11l11l1ll_l1_)/l1l1l11l1lll_l1_
			l1lll111l111_l1_ = l111ll1l1ll_l1_/int(1+l111ll1l1ll_l1_)
		else:
			l1l1l111l11l_l1_ = False
			l1l1l11l1lll_l1_ = 1
			l1lll111l111_l1_ = 1
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㼇"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡵࡴ࡫ࡱ࡫ࠥࡸࡡ࡯ࡩࡨࡷ࠿࡛ࠦࠡࠩ㼈")+str(l1l1l111l11l_l1_)+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ㼉")+str(filesize)+l11lll_l1_ (u"ࠪࠤࡢ࠭㼊"))
		l11ll111l1_l1_ = 0
		#t1 = time.time()-30
		for l1ll111ll11l_l1_ in range(l1l1l11l1lll_l1_):
			l1l1ll1ll_l1_ = headers
			if l1l1l111l11l_l1_: l1l1ll1ll_l1_[l11lll_l1_ (u"ࠫࡗࡧ࡮ࡨࡧࠪ㼋")] = l11lll_l1_ (u"ࠬࡨࡹࡵࡧࡶࡁࠬ㼌")+ranges[l1ll111ll11l_l1_]
			response = requests.get(l1l1111l1l1l_l1_,stream=True,headers=l1l1ll1ll_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1ll11l_l1_.iscanceled():
					LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㼍"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧ㼎"))
					break
				l11ll111l1_l1_ += l1lll111l111_l1_
				PROGRESS_UPDATE(l11l1ll11l_l1_,100*l11ll111l1_l1_//l11l11l1ll_l1_,l11lll_l1_ (u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩ㼏"),str(int(100*l11ll111l1_l1_*chunk_size//l11ll11ll1_l1_)/100.0)+l11lll_l1_ (u"ࠩࠣ࠳ࠥ࠭㼐")+l11ll11111_l1_+l11lll_l1_ (u"ࠪࠤࡒࡈࠧ㼑"))
				l111l1ll111_l1_ += chunk
				#PROGRESS_UPDATE(l11l1ll11l_l1_,0+int(35*l11ll111l1_l1_/l11l11l1ll_l1_),l11lll_l1_ (u"ࠫั๊ศࠡษ็้้็ࠠศๆิส๏ู๊࠻࠯ࠣห้าายࠢิๆ๊࠭㼒")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㼓")+str(l11ll111l1_l1_*chunksize/l11ll11ll1_l1_)+l11lll_l1_ (u"࠭ࠠ࠰ࠢࠪ㼔")+l11ll11111_l1_+l11lll_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ㼕")+time.strftime(l11lll_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ㼖")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㼗")+time.gmtime(l11l111l1l_l1_))+l11lll_l1_ (u"ࠪࠤๅ࠭㼘"))
				#l11l1111l1_l1_ = time.time()
				#l111lllll1_l1_ = l11l1111l1_l1_-t1
				#l11l11111l_l1_ = l111lllll1_l1_/l11ll111l1_l1_
				#l11l1l11ll_l1_ = l11l11111l_l1_*(l11l11l1ll_l1_+1)
				#l11l111l1l_l1_ = l11l1l11ll_l1_-l111lllll1_l1_
			response.close()
		l11l1ll11l_l1_.close()
		if len(l111l1ll111_l1_)<filesize and filesize>0:
			LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㼙"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨ㼚")+str(len(l111l1ll111_l1_)//l11ll11ll1_l1_)+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫ㼛")+l11ll11111_l1_+l11lll_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㼜"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ㼝"),l11lll_l1_ (u"ࠩศ่฿อม๊ࠡัีําࠧ㼞"),l11lll_l1_ (u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪ㼟"),l11lll_l1_ (u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭㼠"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㼡"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪ㼢")+str(len(l111l1ll111_l1_)//l11ll11ll1_l1_)+l11lll_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭㼣")+l11ll11111_l1_+l11lll_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪ㼤"))
			if choice==2: l111l1ll111_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111l1l1l_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㼥"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩ㼦"))
			else: return l11lll_l1_ (u"ࠫࠬ㼧")
			if not l111l1ll111_l1_: return l11lll_l1_ (u"ࠬ࠭㼨")
		else: LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㼩"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ㼪")+l11ll11111_l1_+l11lll_l1_ (u"ࠨࠢࡐࡆࠥࡣࠧ㼫"))
	return l111l1ll111_l1_
def l1lll111ll11_l1_(script_name):
	# old l1lll11ll1l1_l1_ l1ll11l1ll11_l1_ l1l1l1llll11_l1_
	# hit method:    https://l11ll11l111_l1_.google.com/l11llll1l11_l1_/l1ll1l1ll11l_l1_/collection/protocol/l1l1l1llll11_l1_/l1ll1ll1111l_l1_
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠴ࠪࡹ࡯ࡤ࠾ࡗࡄ࠱࠶࠸࠷࠱࠶࠸࠵࠵࠺࠭࠶ࠨࡦ࡭ࡩࡃࠧ㼬")+l11llll111l_l1_(32)+l11lll_l1_ (u"ࠪࠪࡹࡃࡥࡷࡧࡱࡸࠫࡹࡣ࠾ࡧࡱࡨࠫ࡫ࡣ࠾ࠩ㼭")+l11ll111111_l1_+l11lll_l1_ (u"ࠫࠫࡧࡶ࠾ࠩ㼮")+l11ll111111_l1_+l11lll_l1_ (u"ࠬࠬࡡ࡯࠿ࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࡡࡑࡉ࡜ࡉࡌࡊࡇࡑࡘࡎࡊࠦࡦࡣࡀࠫ㼯")+script_name+l11lll_l1_ (u"࠭ࠦࡦ࡮ࡀࠫ㼰")+str(kodi_version)+l11lll_l1_ (u"ࠧࠧࡼࡀࠫ㼱")+l11ll11l1l1_l1_
	#response = l11lll11l11_l1_(l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㼲"),url,l11lll_l1_ (u"ࠩࠪ㼳"),l11lll_l1_ (u"ࠪࠫ㼴"),l11lll_l1_ (u"ࠫࠬ㼵"),l11lll_l1_ (u"ࠬ࠭㼶"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㼷"))
	# new l1ll1lll1111_l1_ l1ll11l1ll11_l1_ 4
	# l1l1ll11111l_l1_ test:    https://l111llll1ll_l1_-l1llll11111_l1_-l111l11l1l1_l1_.google/l1ll1111l1l1_l1_/l1llll1ll1l1_l1_-l1l1l1ll1ll1_l1_
	# l1l1ll11111l_l1_ json method:    https://l11ll11l111_l1_.google.com/l11llll1l11_l1_/l1ll1l1ll11l_l1_/collection/protocol/l1ll1111l1l1_l1_/l1ll11lll1ll_l1_/l1l1ll11111l_l1_
	# l1l1ll11111l_l1_ json method:    https://l11ll11l111_l1_.google.com/l11llll1l11_l1_/l1ll1l1ll11l_l1_/collection/protocol/l1ll1111l1l1_l1_/l1ll11lll1ll_l1_?l1l11ll1lll1_l1_=l1l11l11l11l_l1_
	# l1l1ll11111l_l1_ hit method:   https://www.l1lll1ll11l1_l1_.com/l1ll1111l1l1_l1_-l1llll1lll11_l1_-protocol-l1lll11111ll_l1_
	# l1l1ll11111l_l1_ hit method:   https://www.l1lll1ll11l1_l1_.com/l111l1l1111_l1_-l111ll111l1_l1_-google-l11llll1l11_l1_-l1llll1lll11_l1_-protocol-version-2
	# l1l1ll11111l_l1_ params:  https://data.l1l11l1ll1ll_l1_.com
	# l1l1l1lllll1_l1_ json method
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴ࡳࡰ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡤࡴ࡮ࡥࡳࡦࡥࡵࡩࡹࡃ࠰࠮ࡸ࠴࠹ࡆࡪࡣࡓࡉࡤࡔ࡬ࡷࡲࡰࡩ࡯࠹࠾ࡑࡁࠧ࡯ࡨࡥࡸࡻࡲࡦ࡯ࡨࡲࡹࡥࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠨ㼸")
	#headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㼹"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ㼺")}
	#params = {l11lll_l1_ (u"ࠪࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㼻"):l11ll111111_l1_,l11lll_l1_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ㼼"):kodi_version}
	#data = {l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡤ࡯ࡤࠨ㼽"):l11llll111l_l1_(32),l11lll_l1_ (u"࠭ࡥࡷࡧࡱࡸࡸ࠭㼾"):[{l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㼿"):script_name,l11lll_l1_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ㽀"):params}]}
	#response = l11lll11l11_l1_(l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㽁"),url,str(data),headers,l11lll_l1_ (u"ࠪࠫ㽂"),l11lll_l1_ (u"ࠫࠬ㽃"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ㽄"))
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡪࡼࡥ࡯ࡶࡑࡥࡲ࡫ࠍࠋࠋࡤࡴࡵ࡜ࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡱࡳࡩࡷࡧࡴࡪࡰࡪࡗࡾࡹࡴࡦ࡯࡙ࡩࡷࡹࡩࡰࡰࠐࠎࠎࡻࡡࡱࡸࠐࠎࠎࡻࡳࡦࡴࡢ࡭ࡩࠓࠊࠊࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢࡺࡪࡸࡳࡪࡱࡱࠑࠏࠏࡥࡷࡧࡱࡸࡤࡴࡡ࡮ࡧࠐࠎࠎࠨࠢࠣ㽅")
	# l1l1l1lllll1_l1_ hit method (l11l11llll_l1_ l11l1l1l11l_l1_ l1l11ll1l1ll_l1_)
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡥ࡬ࡨࡂ࠭㽆")+l11llll111l_l1_(32)+l11lll_l1_ (u"ࠨࠨࡢࡷࡂ࠷ࠦࡦࡰࡀࠫ㽇")+script_name+l11lll_l1_ (u"ࠩࠩࡹࡵ࠴ࡡࡷࡡࡹࡩࡷࡃࠧ㽈")+l11ll111111_l1_+l11lll_l1_ (u"ࠪࠪࡺࡶ࠮࡬ࡱࡧ࡭ࡤࡼࡥࡳ࠿ࠪ㽉")+str(kodi_version)
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡡࡧࡦ࡬ࡃ࠱ࠧࡥ࡬ࡨࡂ࠷࠸࠶࠸࠳࠸࠽࠺࠹࠸࠰࠴࠺࠾࠶࠱࠵࠷࠷࠹࠼࠭㽊")
	#l11ll11l1l1_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡧ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠷ࠬࡴࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠨࡢࡨࡧ࡭࠽࠲ࠨࡦ࡭ࡩࡃࠧ㽋")+str(l11ll11l1l1_l1_)+l11lll_l1_ (u"࠭࠮ࠨ㽌")+str(int(time.time()))
	#url += l11lll_l1_ (u"ࠧࠧࡷࡤࡴࡻࡃ࠱࠺࠰࠴ࠪࡩࡺ࠽ࡌࡑࡇࡍࠪ࠸࠰ࡆࡏࡄࡈࠫ࡫࡮࠾ࡲࡤ࡫ࡪࡥࡶࡪࡧࡺࠪࡤ࡫ࡥ࠾࠳ࠩࡹ࡮ࡪ࠽࠳࠴࠵࠶࠲࠸࠲࠳࠴࠰࠷࠸࠹࠳ࠧࡡࡶࡷࡂ࠷ࠧ㽍")
	#response = l11lll11l11_l1_(l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㽎"),url,l11lll_l1_ (u"ࠩࠪ㽏"),l11lll_l1_ (u"ࠪࠫ㽐"),l11lll_l1_ (u"ࠫࠬ㽑"),l11lll_l1_ (u"ࠬ࠭㽒"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㽓"))
	# l1l1l1lllll1_l1_ modified (not good l1l111lll11l_l1_)
	#l11ll11l1l1_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡥ࡬ࡨࡂ࠭㽔")+l11llll111l_l1_(32)+l11lll_l1_ (u"ࠨࠨࡢࡷࡂ࠷ࠦࡦࡰࡀࠫ㽕")+script_name+l11lll_l1_ (u"ࠩࠩࡹࡵ࠴ࡡࡷࡡࡹࡩࡷࡃࠧ㽖")+l11ll111111_l1_+l11lll_l1_ (u"ࠪࠪࡺࡧࡰࡷ࠿ࠪ㽗")+str(kodi_version)+l11lll_l1_ (u"ࠫࠫࡥࡰ࠾ࠩ㽘")+l11ll11l1l1_l1_
	#l11ll1llll1_l1_ = l11l1ll1111_l1_()
	#l1l1ll1l1lll_l1_ = l11ll1llll1_l1_.split(l11lll_l1_ (u"ࠬ࠲ࠧ㽙"),1)[0]
	return response
def l11l1ll1111_l1_(l1l1ll1l1lll_l1_=l11lll_l1_ (u"࠭ࠧ㽚")):
	# url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡰࡴࡩࡡࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ㽛")
	# l1l1l1llll11_l1_   url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡴࡼ࡮࡯ࡪࡵ࠱ࡥࡵࡶ࠯࡫ࡵࡲࡲ࠴࠭㽜")+l1l1ll1l1lll_l1_
	# l11l1ll11l1_l1_   url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㽝")
	l1l1l11l11ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡷࡹࡸࠧ㽞"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㽟"),l11lll_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ㽠"))
	if l1l1l11l11ll_l1_: return l1l1l11l11ll_l1_
	l1l1ll1l1lll_l1_,l1l1l11lll1l_l1_,l1ll111l1l1l_l1_,l11l1l111l1_l1_,l1ll111l1l11_l1_,l1llll11l1ll_l1_,timezone = l11lll_l1_ (u"࠭ࠧ㽡"),l11lll_l1_ (u"ࠧࠨ㽢"),l11lll_l1_ (u"ࠨࠩ㽣"),l11lll_l1_ (u"ࠩࠪ㽤"),l11lll_l1_ (u"ࠪࠫ㽥"),l11lll_l1_ (u"ࠫࠬ㽦"),l11lll_l1_ (u"ࠬ࠭㽧")
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡹ࡫ࡳ࠳࡯ࡳ࠰ࠩ㽨")+l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠧࡀࡱࡸࡸࡵࡻࡴ࠾࡬ࡶࡳࡳࠬࡦࡪࡧ࡯ࡨࡸࡃࡩࡱ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩ࠱ࡸࡥࡨ࡫ࡲࡲ࠱ࡩࡩࡵࡻ࠯ࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㽩")
	headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㽪"):l11lll_l1_ (u"ࠩࠪ㽫")}
	response = l11lll11l11_l1_(l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㽬"),url,l11lll_l1_ (u"ࠫࠬ㽭"),headers,l11lll_l1_ (u"ࠬ࠭㽮"),l11lll_l1_ (u"࠭ࠧ㽯"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ㽰"))
	if not response.succeeded: l1lll1ll1lll_l1_ = l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ㽱")+l1l1l11lll1l_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ㽲")+l1ll111l1l1l_l1_+l11lll_l1_ (u"ࠪ࠰ࠬ㽳")+l1ll111l1l11_l1_+l11lll_l1_ (u"ࠫ࠱࠭㽴")+l1llll11l1ll_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ㽵")+timezone
	else:
		html = response.content
		html = re.findall(l11lll_l1_ (u"࠭࡜ࡼ࠰࠭ࡃࡡࢃ࡜ࡾࠩ㽶"),html,re.DOTALL)
		if html:
			html = html[0]
			l11111ll111_l1_ = EVAL(l11lll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㽷"),html)
			if l11lll_l1_ (u"ࠨ࡫ࡳࠫ㽸") in list(l11111ll111_l1_.keys()): l1l1ll1l1lll_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠩ࡬ࡴࠬ㽹")]
			if l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭㽺") in list(l11111ll111_l1_.keys()): l1l1l11lll1l_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ㽻")]
			if l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㽼") in list(l11111ll111_l1_.keys()): l1ll111l1l1l_l1_ = l11111ll111_l1_[l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㽽")]
			if l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭㽾") in list(l11111ll111_l1_.keys()): l11l1l111l1_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧ㽿")]
			if l11lll_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ㾀") in list(l11111ll111_l1_.keys()): l1ll111l1l11_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ㾁")]
			if l11lll_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ㾂") in list(l11111ll111_l1_.keys()): l1llll11l1ll_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠬࡩࡩࡵࡻࠪ㾃")]
			if l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㾄") in list(l11111ll111_l1_.keys()):
				timezone = l11111ll111_l1_[l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ㾅")][l11lll_l1_ (u"ࠨࡷࡷࡧࠬ㾆")]
				if timezone[0] not in [l11lll_l1_ (u"ࠩ࠰ࠫ㾇"),l11lll_l1_ (u"ࠪ࠯ࠬ㾈")]: timezone = l11lll_l1_ (u"ࠫ࠰࠭㾉")+timezone
			l1lll1ll1lll_l1_ = l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ㾊")+l1l1l11lll1l_l1_+l11lll_l1_ (u"࠭ࠬࠨ㾋")+l1ll111l1l1l_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ㾌")+l1ll111l1l11_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ㾍")+l1llll11l1ll_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ㾎")+timezone
			if kodi_version>18.99: l1lll1ll1lll_l1_ = l1lll1ll1lll_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㾏")).decode(l11lll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㾐"))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㾑"),l11lll_l1_ (u"࠭ࡉࡑࡎࡒࡇࡆ࡚ࡉࡐࡐࠪ㾒"),l1lll1ll1lll_l1_,l1lll1111_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㾓"),l1lll1ll1lll_l1_)
	return l1lll1ll1lll_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11lll_l1_ (u"ࠨࠩ㾔"),True
	if search.count(l11lll_l1_ (u"ࠩࡢࠫ㾕"))>=2:
		search,options = search.split(l11lll_l1_ (u"ࠪࡣࠬ㾖"),1)
		options = l11lll_l1_ (u"ࠫࡤ࠭㾗")+options
		if l11lll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ㾘") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㾙"),l11lll_l1_ (u"ࠧࠨ㾚"),search,options)
	return search,options,l1ll_l1_
def l1l11l11l1l1_l1_():
	l1l1lll1l1ll_l1_ = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㾛"))
	l1ll1ll1l11l_l1_ = 0
	if os.path.exists(l1l1lll1l1ll_l1_):
		for filename in os.listdir(l1l1lll1l1ll_l1_):
			if l11lll_l1_ (u"ࠩ࠱ࡴࡾࡵࠧ㾜") in filename: continue
			if l11lll_l1_ (u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨ㾝") in filename: continue
			l1l11l1l1l_l1_ = os.path.join(l1l1lll1l1ll_l1_,filename)
			size,count = l1l1l1l111_l1_(l1l11l1l1l_l1_)
			l1ll1ll1l11l_l1_ += size
	return l1ll1ll1l11l_l1_
def l11111l1ll1_l1_(l11llllll1l_l1_,l1ll_l1_):
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㾞")][3]
	user = l11llll111l_l1_(32)
	l1lll1ll1lll_l1_ = l11l1ll1111_l1_()
	l1ll111l1l1l_l1_ = l1lll1ll1lll_l1_.split(l11lll_l1_ (u"ࠬ࠲ࠧ㾟"))[2]
	l1ll1ll1l11l_l1_ = l1l11l11l1l1_l1_()
	payload = {l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ㾠"):user,l11lll_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㾡"):l11ll111111_l1_,l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㾢"):l1ll111l1l1l_l1_,l11lll_l1_ (u"ࠩ࡬ࡨࡸ࠭㾣"):l1l1lll11l1l_l1_(l1ll1ll1l11l_l1_)}
	if not l11llllll1l_l1_: DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㾤"),(l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ㾥"),url,payload,l11lll_l1_ (u"ࠬ࠭㾦"),l11lll_l1_ (u"࠭ࠧ㾧"),l11lll_l1_ (u"ࠧࠨ㾨")))
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㾩"),l11lll_l1_ (u"ࠩࠪ㾪"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㾫"),url,payload,l11lll_l1_ (u"ࠫࠬ㾬"),l11lll_l1_ (u"ࠬ࠭㾭"),l11lll_l1_ (u"࠭ࠧ㾮"),l11lll_l1_ (u"ࠧࡎࡇࡑ࡙ࡘ࠳ࡓࡉࡑ࡚ࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪ㾯"),True,True)
	l11l1111l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㾰"))
	if not l11l1111l1l_l1_: l11l1111l1l_l1_ = l11lll_l1_ (u"ࠩࡑࡉ࡜࠭㾱")
	l1ll1111111l_l1_ = l11l1111l1l_l1_
	if not response.succeeded: l1ll1111111l_l1_ = l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㾲")
	else:
		l11ll11ll1l_l1_,l1lll1llllll_l1_,l1llll11l1l1_l1_,l1llll11111l_l1_ = l11lll_l1_ (u"ࠫࠬ㾳"),l11lll_l1_ (u"ࠬ࠭㾴"),l11lll_l1_ (u"࠭ࠧ㾵"),[]
		newfile = response.content
		if newfile:
			l1llll11111l_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㾶"),newfile)
			for l1ll1l11llll_l1_,l1l1l1l11l11_l1_,message in l1llll11111l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㾷")).decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㾸"))
				if l1ll1l11llll_l1_==l11lll_l1_ (u"ࠪ࠴ࠬ㾹"): l11ll11ll1l_l1_ += message+l11lll_l1_ (u"ࠫ࠿ࡀࠧ㾺")
				else: l1lll1llllll_l1_ += message+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㾻")
			l1lll1llllll_l1_ = l1lll1llllll_l1_.strip(l11lll_l1_ (u"࠭࡜࡯ࠩ㾼"))
			l11ll11ll1l_l1_ = l11ll11ll1l_l1_.strip(l11lll_l1_ (u"ࠧ࠻࠼ࠪ㾽"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㾾"),l11ll11ll1l_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㾿"),l1l1lll11l1l_l1_(now))
		if os.path.exists(l1l111l111l1_l1_): l1llll11l1l1_l1_ = open(l1l111l111l1_l1_,l11lll_l1_ (u"ࠪࡶࡧ࠭㿀")).read()
		if kodi_version>18.99: l1lll1llllll_l1_ = l1lll1llllll_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㿁"))
		if l1lll1llllll_l1_!=l1llll11l1l1_l1_:
			l1ll1111111l_l1_ = l11lll_l1_ (u"ࠬࡔࡅࡘࠩ㿂")
			try: open(l1l111l111l1_l1_,l11lll_l1_ (u"࠭ࡷࡣࠩ㿃")).write(l1lll1llllll_l1_)
			except: pass
		if l1ll_l1_:
			l1llll11111l_l1_ = sorted(l1llll11111l_l1_,reverse=True,key=lambda key: int(key[0]))
			l1llll11l11l_l1_ = l11lll_l1_ (u"ࠧࠨ㿄")
			for l1ll1l11llll_l1_,l1l1l1l11l11_l1_,message in l1llll11111l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㿅")).decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㿆"))
				if l1llll11l11l_l1_: l1llll11l11l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ㿇")
				if l1ll1l11llll_l1_==l11lll_l1_ (u"ࠫ࠵࠭㿈"): continue
				date = message.split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㿉"))[0]
				l1lll1ll1_l1_ = l11lll_l1_ (u"࠭ࠧ㿊")
				if l1l1l1l11l11_l1_:
					l1lll1ll1_l1_ = l11lll_l1_ (u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫ㿋")
					if kodi_version>18.99: l1lll1ll1_l1_ = l1lll1ll1_l1_.encode(l11lll_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㿌")).decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㿍"))
				l1llll11l11l_l1_ += message.replace(date,l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㿎")+date+l1lll1ll1_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㿏"))+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㿐")
			l1llll11l11l_l1_ = escapeUNICODE(l1llll11l11l_l1_)
			l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㿑"),l11lll_l1_ (u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪ㿒"),l1llll11l11l_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㿓"))
			l1ll1111111l_l1_ = l11lll_l1_ (u"ࠩࡒࡐࡉ࠭㿔")
	if l1ll1111111l_l1_!=l11l1111l1l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㿕"),l1ll1111111l_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㿖"))
	return l1ll1111111l_l1_
def l11l1llll1_l1_(url,l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭㿗")):
	l111llll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴࡭ࡱ࠶ࡿࡠ࠳ࡳ࠳ࡶࡾ࡟࠲ࡲ࠹ࡵ࠹ࡾ࡟࠲ࡲࡶࡤࡽ࡞࠱ࡱࡰࡼࡼ࡝࠰ࡩࡰࡻࢂ࡜࠯࡯ࡳ࠷ࢁࡢ࠮ࡸࡧࡥࡱ࠮࠮ࡼ࡝ࡁ࠱࠮ࡄࢂ࠯࡝ࡁ࠱࠮ࡄࢂ࡜ࡽ࠰࠭ࡃ࠮ࠪࠧ㿘"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111llll11_l1_: l111llll11_l1_ = l111llll11_l1_[0][0]
	else: l111llll11_l1_ = l11lll_l1_ (u"ࠧࠨ㿙")
	return l111llll11_l1_
	#elif not l111llll11_l1_ and l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㿚") in l1l1ll11_l1_: l111llll11_l1_ = l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ㿛")
	#elif not l111llll11_l1_ and l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㿜") in l1l1ll11_l1_: l111llll11_l1_ = l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㿝")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l1l111111l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l1l111111l_l1_ = False
	l11l1111l1_l1_ = time.time()
	if l1l1l111111l_l1_: resp = l11l1111l1_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭㿞"),l11lll_l1_ (u"࠭ࠧ㿟"),l11lll_l1_ (u"ࠧࠨ㿠"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㿡"),l11lll_l1_ (u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨ㿢"))
	else: l1ll11l111_l1_ = True
	if l1ll11l111_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11lll_l1_ (u"ࠪ࠲ࡩࡨࠧ㿣")) and l11lll_l1_ (u"ࠫࡩࡧࡴࡢࠩ㿤") in filename:
				l1l1ll11ll_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l11111ll1_l1_(l1l1ll11ll_l1_)
				except: return
				cc.execute(l11lll_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨ㿥"))
				cc.execute(l11lll_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩ㿦"))
				cc.execute(l11lll_l1_ (u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨ㿧"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㿨"),l11lll_l1_ (u"ࠩࠪ㿩"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㿪"),l11lll_l1_ (u"ࠫฯ๋สࠡส้ะฬำฺࠠ็็๎ฮࠦลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ㿫"))
	return
def l1l1lll1l11l_l1_(word):
	if l11lll_l1_ (u"ࠬࡡࠧ㿬") in word and l11lll_l1_ (u"࠭࡝ࠨ㿭") in word:
		l111ll11ll1_l1_ = [l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㿮"),l11lll_l1_ (u"ࠨ࡝࠲ࡖ࡙ࡒ࡝ࠨ㿯"),l11lll_l1_ (u"ࠩ࡞࠳ࡑࡋࡆࡕ࡟ࠪ㿰"),l11lll_l1_ (u"ࠪ࡟࠴ࡘࡉࡈࡊࡗࡡࠬ㿱"),l11lll_l1_ (u"ࠫࡠ࠵ࡃࡆࡐࡗࡉࡗࡣࠧ㿲"),l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ㿳"),l11lll_l1_ (u"࡛࠭ࡍࡇࡉࡘࡢ࠭㿴"),l11lll_l1_ (u"ࠧ࡜ࡔࡌࡋࡍ࡚࡝ࠨ㿵"),l11lll_l1_ (u"ࠨ࡝ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ㿶")]
		l1l1l111llll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠣ࠲࠯ࡅ࡜࡞ࠩ㿷"),word,re.DOTALL)
		l111l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠧࠨࠩ࠮ࠫࡁ࡟ࡡࠬ㿸"),word,re.DOTALL)
		l1l1l1l11111_l1_ = l111ll11ll1_l1_+l1l1l111llll_l1_+l111l1l111l_l1_
		for tag in l1l1l1l11111_l1_: word = word.replace(tag,l11lll_l1_ (u"ࠫࠬ㿹"))
	return word
def l1ll1l1l11l1_l1_(l11l1l11lll_l1_,l1lll1l111l1_l1_,l1ll11l11ll1_l1_,l1l1ll1111l1_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll1111l_l1_,l1111l1ll11_l1_,l1l11ll1l111_l1_ = l11lll_l1_ (u"ࠬ࠭㿺"),0,15000
	l11l1l11lll_l1_ = l11l1l11lll_l1_.replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࠧ㿻"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠣࠤࠥࠪ㿼"))
	l1l111llll11_l1_ = PIL.ImageFont.truetype(l1lll1l1l111_l1_,size=l1lll1l111l1_l1_)
	l1ll11l11ll1_l1_ -= l1lll1l111l1_l1_*2
	txt = PIL.Image.new(l11lll_l1_ (u"ࠨࡔࡊࡆࡆ࠭㿽"),(l1ll11l11ll1_l1_,99),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l1l1111ll1_l1_ in l11l1l11lll_l1_.splitlines():
		l1111l1ll11_l1_ += l1l1ll1111l1_l1_
		l1lll1l11ll1_l1_,newline = 0,l11lll_l1_ (u"ࠩࠪ㿾")
		for word in l1l1l1111ll1_l1_.split(l11lll_l1_ (u"ࠪࠤࠬ㿿")):
			l1lllll11l11_l1_ = l1l1lll1l11l_l1_(l11lll_l1_ (u"ࠫࠥ࠭䀀")+word)
			l1l1l1l11l1l_l1_,l1lllll1l1ll_l1_ = l1llllll1lll_l1_.textsize(l1lllll11l11_l1_,font=l1l111llll11_l1_)
			if l1lll1l11ll1_l1_+l1l1l1l11l1l_l1_<l1ll11l11ll1_l1_:
				if not newline: newline += word
				else: newline += l11lll_l1_ (u"ࠬࠦࠧ䀁")+word
				l1lll1l11ll1_l1_ += l1l1l1l11l1l_l1_
			else:
				if l1l1l1l11l1l_l1_<l1ll11l11ll1_l1_:
					newline += l11lll_l1_ (u"࠭࡜࡯ࠢࠪ䀂")+word
					l1111l1ll11_l1_ += l1l1ll1111l1_l1_
					l1lll1l11ll1_l1_ = l1l1l1l11l1l_l1_
				else:
					while l1l1l1l11l1l_l1_>l1ll11l11ll1_l1_:
						for l11ll111l1_l1_ in range(1,len(l11lll_l1_ (u"ࠧࠡࠩ䀃")+word),1):
							l1lllllll1l1_l1_ = l11lll_l1_ (u"ࠨࠢࠪ䀄")+word[:l11ll111l1_l1_]
							l11111lll1_l1_ = word[l11ll111l1_l1_:]
							l1l11l1l1lll_l1_ = l1l1lll1l11l_l1_(l1lllllll1l1_l1_)
							l111l1ll11l_l1_,l1llll1l1111_l1_ = l1llllll1lll_l1_.textsize(l1l11l1l1lll_l1_,font=l1l111llll11_l1_)
							if l1lll1l11ll1_l1_+l111l1ll11l_l1_>l1ll11l11ll1_l1_:
								l1ll111l11l1_l1_ = l1l1l1l11l1l_l1_-l111l1ll11l_l1_
								newline += l1lllllll1l1_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ䀅")
								l1111l1ll11_l1_ += l1l1ll1111l1_l1_
								l1l1l1l11l1l_l1_ = l1ll111l11l1_l1_
								if l1ll111l11l1_l1_>l1ll11l11ll1_l1_:
									l1lll1l11ll1_l1_ = 0
									word = l11111lll1_l1_
								else:
									l1lll1l11ll1_l1_ = l1ll111l11l1_l1_
									newline += l11111lll1_l1_
								break
				if l1111l1ll11_l1_>l1l11ll1l111_l1_: break
		l111ll1111l_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭䀆")+newline
		if l1111l1ll11_l1_>l1l11ll1l111_l1_: break
	l111ll1111l_l1_ = l111ll1111l_l1_[1:]
	l111ll1111l_l1_ = l111ll1111l_l1_.replace(l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠧࠨࠩࠧ䀇"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭䀈"))
	return l111ll1111l_l1_
def l1111lll1l1_l1_(text):
	text = text.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ䀉"),l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ䀊"))
	text = text.replace(l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ䀋"),l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ䀌"))
	text = text.replace(l11lll_l1_ (u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪ䀍"),l11lll_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭䀎"))
	text = text.replace(l11lll_l1_ (u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭䀏"),l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ䀐"))
	text = text.replace(l11lll_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ䀑"),l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ䀒"))
	text = text.replace(l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀓"),l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡨࡲࡩࡩ࡯࡭ࡱࡵࡣࠬ䀔"))
	l1ll1ll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠮࠮ࠫࡁࠬࡠࡢ࠭䀕"),text,re.DOTALL)
	for l1ll1111l1ll_l1_ in l1ll1ll11ll1_l1_: text = text.replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭䀖")+l1ll1111l1ll_l1_+l11lll_l1_ (u"࠭࡝ࠨ䀗"),l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨ䀘")+l1ll1111l1ll_l1_+l11lll_l1_ (u"ࠨࡡࠪ䀙"))
	return text
def l1l11ll111ll_l1_(l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text,profile,l111l1llll1_l1_,l1l1llllll11_l1_,l1l1ll1ll11l_l1_):
	l1lll1111l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ䀚"))
	if l1lll1111l1l_l1_:
		results = LANGUAGE_TRANSLATE([l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text])
		if results: l1llll1l11l1_l1_,l1l1l111ll11_l1_,l1llll1l1lll_l1_,header,text = results
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䀛"))
		header = header.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䀜"))
		l1llll1l11l1_l1_ = l1llll1l11l1_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䀝"))
		l1l1l111ll11_l1_ = l1l1l111ll11_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䀞"))
		l1llll1l1lll_l1_ = l1llll1l1lll_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䀟"))
	l1lllll1llll_l1_ = 5
	l1l111lll111_l1_ = 20
	l1ll1l111ll1_l1_ = 20
	l1ll111l1lll_l1_ = 0
	l11l1l1l1l1_l1_ = l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䀠")
	l1l11l1lll1l_l1_ = 0
	l1l11lll11ll_l1_ = 19
	l1111l1l1ll_l1_ = 30
	l1ll11llllll_l1_ = 8
	l1ll1111llll_l1_ = True
	l1l1l111ll1l_l1_ = 375
	l1l11l111l11_l1_ = 410
	l1l1ll1l11l1_l1_ = 50
	l1l1ll111l11_l1_ = 280
	l1llll111lll_l1_ = 28
	l1l11l1l1ll1_l1_ = 5
	l1lll11l1l11_l1_ = 0
	l1ll11l11l1l_l1_ = 31
	l111111l1ll_l1_ = [36,32,28]
	if profile in [l11lll_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ䀡"),l11lll_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ䀢")]:
		if profile==l11lll_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ䀣"):
			l11l1l11l11_l1_ = l11lll_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ䀤")
			l11l1l1l1l1_l1_ = l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ䀥")
			l1ll1111llll_l1_ = True
			l1ll111l1lll_l1_ = 10
		else:
			l11l1l11l11_l1_ = 97+20
			l11l1l1l1l1_l1_ = l11lll_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ䀦")
			l1ll1111llll_l1_ = False
		l111111l1ll_l1_ = [33,33,33]
		l1ll1l111ll1_l1_ = 20
		l1l111lll111_l1_ = 0
		l1111l1l1ll_l1_ = 20
		l1l11lll11ll_l1_ = 25+10
	elif profile==l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ䀧"): l111111l1ll_l1_ = [28,24,20] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ䀨"): l111111l1ll_l1_ = [32,28,24] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ䀩"): l111111l1ll_l1_ = [36,32,28] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ䀪"): l11l1l11l11_l1_ = 740
	elif profile==l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭䀫"): l11l1l11l11_l1_ = l11lll_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ䀬")
	elif profile==l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ䀭"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = 740
	elif profile==l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ䀮"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = l11lll_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ䀯")
	l1lll11lllll_l1_ = l111111l1ll_l1_[0]
	l11111ll1ll_l1_ = l111111l1ll_l1_[1]
	l11l11lll1l_l1_ = l111111l1ll_l1_[2]
	l1lll1l1l11l_l1_ = PIL.ImageFont.truetype(l1lll1l1l111_l1_,size=l1lll11lllll_l1_)
	l1ll1l11ll11_l1_ = PIL.ImageFont.truetype(l1lll1l1l111_l1_,size=l11111ll1ll_l1_)
	l1ll1ll11l1l_l1_ = PIL.ImageFont.truetype(l1lll1l1l111_l1_,size=l11l11lll1l_l1_)
	txt = PIL.Image.new(l11lll_l1_ (u"ࠪࡖࡌࡈࡁࠨ䀰"),(100,100),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	l1lllll11lll_l1_,l1l1lll1ll11_l1_ = l1llllll1lll_l1_.textsize(l11lll_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭䀱"),font=l1ll1l11ll11_l1_)
	l1l1l111l111_l1_,l1llll11ll1l_l1_ = l1llllll1lll_l1_.textsize(l11lll_l1_ (u"ࠬࡎࡈࡉࠢࡅࡆࡇࠦ࠸࠹࠺ࠣ࠴࠵࠶ࠧ䀲"),font=l1lll1l1l11l_l1_)
	l1l11l1lllll_l1_ = header.count(l11lll_l1_ (u"࠭࡜࡯ࠩ䀳"))+1
	l1l1ll1lll1l_l1_ = l1l111lll111_l1_+l1l11l1lllll_l1_*(l1llll11ll1l_l1_+l1ll111l1lll_l1_)-l1ll111l1lll_l1_
	l1l11ll1l11l_l1_ = {l11lll_l1_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡩࡣࡵࡥࡰࡧࡴࠨ䀴"):False,l11lll_l1_ (u"ࠨࡵࡸࡴࡵࡵࡲࡵࡡ࡯࡭࡬ࡧࡴࡶࡴࡨࡷࠬ䀵"):True,l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࠢࡏࡍࡌࡇࡔࡖࡔࡈࠤࡆࡒࡌࡂࡊࠪ䀶"):False}
	l111l1l1ll1_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l11ll1l11l_l1_)
	if text:
		l11l11ll1ll_l1_ = l1l1llllll11_l1_-l1111l1l1ll_l1_*2
		l1l11lll111l_l1_ = l1l1lll1ll11_l1_+l1ll11llllll_l1_
		l1ll111111ll_l1_ = l111l1l1ll1_l1_.reshape(text)
		if l1ll1111llll_l1_:
			l1l1111ll1l1_l1_ = l1ll1l1l11l1_l1_(l1ll111111ll_l1_,l11111ll1ll_l1_,l11l11ll1ll_l1_,l1l11lll111l_l1_)
			l1ll1lllllll_l1_ = l1l1lll1l11l_l1_(l1l1111ll1l1_l1_)
			l1l1lllllll1_l1_ = l1ll1lllllll_l1_.count(l11lll_l1_ (u"ࠪࡠࡳ࠭䀷"))+1
			if l1l1lllllll1_l1_<6:
				#l1l1l11l1111_l1_ = int(0.8*l11l11ll1ll_l1_) if l1l1lllllll1_l1_<4 else int(0.9*l11l11ll1ll_l1_)
				l1l1l11l1111_l1_ = l11l11ll1ll_l1_
				l1l1111ll1l1_l1_ = l1ll1l1l11l1_l1_(l1ll111111ll_l1_,l11111ll1ll_l1_,l1l1l11l1111_l1_,l1l11lll111l_l1_)
				l1ll1lllllll_l1_ = l1l1lll1l11l_l1_(l1l1111ll1l1_l1_)
				l1l1lllllll1_l1_ = l1ll1lllllll_l1_.count(l11lll_l1_ (u"ࠫࡡࡴࠧ䀸"))+1
			l111lll1l1l_l1_ = l1l11lll11ll_l1_+l1l1lllllll1_l1_*l1l11lll111l_l1_-l1ll11llllll_l1_
		else:
			l111lll1l1l_l1_ = l1l11lll11ll_l1_+l1l1lll1ll11_l1_
			l1ll1lllllll_l1_ = l1ll111111ll_l1_.split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䀹"))[0]
			l1l1111ll1l1_l1_ = l1ll111111ll_l1_.split(l11lll_l1_ (u"࠭࡜࡯ࠩ䀺"))[0]
	else: l111lll1l1l_l1_ = l1l11lll11ll_l1_
	l1ll111lll1l_l1_ = l1lll11l1l11_l1_+l1ll11l11l1l_l1_
	if l1l1ll1ll11l_l1_:
		l1l1l1l1lll1_l1_ = l1l11l111l11_l1_-l1l1l111ll1l_l1_
		l1ll111lll1l_l1_ += l1l1l1l1lll1_l1_
	else: l1l1l1l1lll1_l1_ = 0
	if l1llll1l11l1_l1_ or l1l1l111ll11_l1_ or l1llll1l1lll_l1_: l1ll111lll1l_l1_ += l1l1ll1l11l1_l1_
	if l11l1l11l11_l1_!=l11lll_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭䀻"): l1111111ll1_l1_ = l11l1l11l11_l1_
	else: l1111111ll1_l1_ = l1l1ll1lll1l_l1_+l111lll1l1l_l1_+l1ll111lll1l_l1_
	l1ll1lll11ll_l1_ = l1111111ll1_l1_-l1l1ll1lll1l_l1_-l1ll111lll1l_l1_-l1l11lll11ll_l1_
	txt = PIL.Image.new(l11lll_l1_ (u"ࠨࡔࡊࡆࡆ࠭䀼"),(l1l1llllll11_l1_,l1111111ll1_l1_),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l1l111ll11_l1_ and l1llll1l11l1_l1_ and l1llll1l1lll_l1_:
		l1llll111lll_l1_ += 105
		l1l11l1l1ll1_l1_ -= 110
	if header:
		l1llllll1111_l1_ = l1l111lll111_l1_
		header = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1ll11111lll_l1_ = l1llllll1lll_l1_.textsize(line,font=l1lll1l1l11l_l1_)
				if l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䀽"): l1l1l11l1l1l_l1_ = l1lllll1llll_l1_+(l1l1llllll11_l1_-width)/2
				elif l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ䀾"): l1l1l11l1l1l_l1_ = l1lllll1llll_l1_+l1l1llllll11_l1_-width-l1ll1l111ll1_l1_
				elif l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ䀿"): l1l1l11l1l1l_l1_ = l1lllll1llll_l1_+l1ll1l111ll1_l1_
				l1llllll1lll_l1_.text((l1l1l11l1l1l_l1_,l1llllll1111_l1_),line,font=l1lll1l1l11l_l1_,fill=l11lll_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ䁀"))
			l1llllll1111_l1_ += l1lll11lllll_l1_+l1ll111l1lll_l1_
	if l1llll1l11l1_l1_ or l1l1l111ll11_l1_ or l1llll1l1lll_l1_:
		l1llll11l111_l1_ = l1l1ll1lll1l_l1_+l1ll1lll11ll_l1_+l1l11lll11ll_l1_+l1l1l1l1lll1_l1_+l1lll11l1l11_l1_
		if l1llll1l11l1_l1_:
			l1llll1l11l1_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1llll1l11l1_l1_))
			l1l1llll111l_l1_,l11111111l1_l1_ = l1llllll1lll_l1_.textsize(l1llll1l11l1_l1_,font=l1ll1ll11l1l_l1_)
			l111111l1l1_l1_ = l1llll111lll_l1_+0*(l1l11l1l1ll1_l1_+l1l1ll111l11_l1_)+(l1l1ll111l11_l1_-l1l1llll111l_l1_)/2
			l1llllll1lll_l1_.text((l111111l1l1_l1_,l1llll11l111_l1_),l1llll1l11l1_l1_,font=l1ll1ll11l1l_l1_,fill=l11lll_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭䁁"))
		if l1l1l111ll11_l1_:
			l1l1l111ll11_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1l1l111ll11_l1_))
			l1ll1l111111_l1_,l1ll11l1l1l1_l1_ = l1llllll1lll_l1_.textsize(l1l1l111ll11_l1_,font=l1ll1ll11l1l_l1_)
			l11111ll1l1_l1_ = l1llll111lll_l1_+1*(l1l11l1l1ll1_l1_+l1l1ll111l11_l1_)+(l1l1ll111l11_l1_-l1ll1l111111_l1_)/2
			l1llllll1lll_l1_.text((l11111ll1l1_l1_,l1llll11l111_l1_),l1l1l111ll11_l1_,font=l1ll1ll11l1l_l1_,fill=l11lll_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ䁂"))
		if l1llll1l1lll_l1_:
			l1llll1l1lll_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1llll1l1lll_l1_))
			l111l11l111_l1_,l11l11llll1_l1_ = l1llllll1lll_l1_.textsize(l1llll1l1lll_l1_,font=l1ll1ll11l1l_l1_)
			l1lll11l111l_l1_ = l1llll111lll_l1_+2*(l1l11l1l1ll1_l1_+l1l1ll111l11_l1_)+(l1l1ll111l11_l1_-l111l11l111_l1_)/2
			l1llllll1lll_l1_.text((l1lll11l111l_l1_,l1llll11l111_l1_),l1llll1l1lll_l1_,font=l1ll1ll11l1l_l1_,fill=l11lll_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ䁃"))
	if text:
		l1l111ll1111_l1_,l111l11llll_l1_ = [],[]
		l1l1111ll1l1_l1_ = l1111lll1l1_l1_(l1l1111ll1l1_l1_)
		l1l11lll11l1_l1_ = l1l1111ll1l1_l1_.split(l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ䁄"))
		for l1l11l11ll1l_l1_ in l1l11lll11l1_l1_:
			l111llll1l1_l1_ = l111l1llll1_l1_
			if   l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ䁅") in l1l11l11ll1l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ䁆")
			elif l11lll_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ䁇") in l1l11l11ll1l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ䁈")
			elif l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ䁉") in l1l11l11ll1l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䁊")
			l11l11111l1_l1_ = l1l11l11ll1l_l1_
			l111ll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࠰࠭ࡃࡤ࠭䁋"),l1l11l11ll1l_l1_,re.DOTALL)
			for tag in l111ll11ll1_l1_: l11l11111l1_l1_ = l11l11111l1_l1_.replace(tag,l11lll_l1_ (u"ࠪࠫ䁌"))
			if l11l11111l1_l1_==l11lll_l1_ (u"ࠫࠬ䁍"): width,l1ll11111lll_l1_ = 0,l1l11lll111l_l1_
			else: width,l1ll11111lll_l1_ = l1llllll1lll_l1_.textsize(l11l11111l1_l1_,font=l1ll1l11ll11_l1_)
			if   l111llll1l1_l1_==l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ䁎"): l1lll1lll11l_l1_ = l1l11l1lll1l_l1_+l1111l1l1ll_l1_
			elif l111llll1l1_l1_==l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ䁏"): l1lll1lll11l_l1_ = l1l11l1lll1l_l1_+l1111l1l1ll_l1_+l11l11ll1ll_l1_-width
			elif l111llll1l1_l1_==l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䁐"): l1lll1lll11l_l1_ = l1l11l1lll1l_l1_+l1111l1l1ll_l1_+(l11l11ll1ll_l1_-width)/2
			if l1lll1lll11l_l1_<l1111l1l1ll_l1_: l1lll1lll11l_l1_ = l1l11l1lll1l_l1_+l1111l1l1ll_l1_
			l1l111ll1111_l1_.append(l1lll1lll11l_l1_)
			l111l11llll_l1_.append(width)
		l1lll1lll11l_l1_ = l1l111ll1111_l1_[0]
		l1l1l11l11l1_l1_ = l1l1111ll1l1_l1_.split(l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥࠧ䁑"))
		l11l111ll1l_l1_ = (255,255,255,255)
		l1ll1l1l111l_l1_ = l11l111ll1l_l1_
		l1l11ll1llll_l1_,l1ll11lll111_l1_ = 0,0
		l1lll111llll_l1_ = False
		l1llll1llll1_l1_ = 0
		l1l11l1llll1_l1_ = l1l1ll1lll1l_l1_+l1l11lll11ll_l1_/2
		if l111lll1l1l_l1_<(l1ll1lll11ll_l1_+l1l11lll11ll_l1_):
			l1lllll1ll11_l1_ = (l1ll1lll11ll_l1_+l1l11lll11ll_l1_-l111lll1l1l_l1_)/2
			l1l11l1llll1_l1_ = l1l1ll1lll1l_l1_+l1l11lll11ll_l1_+l1lllll1ll11_l1_-l1l1lll1ll11_l1_/2
		for line in l1l1l11l11l1_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1l1l1l11l_l1_ = line.split(l11lll_l1_ (u"ࠩࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ䁒"),1)
			l1l1l1l1l1l1_l1_ = line.split(l11lll_l1_ (u"ࠪࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭䁓"),1)
			l1l1l1l1l1ll_l1_ = line.split(l11lll_l1_ (u"ࠫࡤ࡫࡮ࡥࡥࡲࡰࡴࡸ࡟ࠨ䁔"),1)
			l1ll1l1lllll_l1_ = line.split(l11lll_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡶࡹࡲ࡟ࠨ䁕"),1)
			l1ll1ll111l1_l1_ = line.split(l11lll_l1_ (u"࠭࡟࡭࡫ࡱࡩࡱ࡫ࡦࡵࡡࠪ䁖"),1)
			l1ll1ll111ll_l1_ = line.split(l11lll_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡸࡩࡨࡪࡷࡣࠬ䁗"),1)
			l1l1l1l1l111_l1_ = line.split(l11lll_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧ䁘"),1)
			if len(l1l1l1l1l11l_l1_)>1:
				l1llll1llll1_l1_ += 1
				line = l1l1l1l1l11l_l1_[1]
				l1l11ll1llll_l1_ = 0
				l1lll1lll11l_l1_ = l1l111ll1111_l1_[l1llll1llll1_l1_]
				l1ll11lll111_l1_ += l1l11lll111l_l1_
				l1lll111llll_l1_ = False
			elif len(l1l1l1l1l1l1_l1_)>1:
				line = l1l1l1l1l1l1_l1_[1]
				l1ll1l1l111l_l1_ = line[0:8]
				l1ll1l1l111l_l1_ = l11lll_l1_ (u"ࠩࠦࠫ䁙")+l1ll1l1l111l_l1_[2:]
				line = line[9:]
			elif len(l1l1l1l1l1ll_l1_)>1:
				line = l1l1l1l1l1ll_l1_[1]
				l1ll1l1l111l_l1_ = l11l111ll1l_l1_
			elif len(l1ll1l1lllll_l1_)>1:
				line = l1ll1l1lllll_l1_[1]
				l1lll111llll_l1_ = True
				l1l11ll1llll_l1_ = l111l11llll_l1_[l1llll1llll1_l1_]
			elif len(l1ll1ll111l1_l1_)>1:
				line = l1ll1ll111l1_l1_[1]
			elif len(l1ll1ll111ll_l1_)>1:
				line = l1ll1ll111ll_l1_[1]
			elif len(l1l1l1l1l111_l1_)>1:
				line = l1l1l1l1l111_l1_[1]
			if line:
				l1l1ll1111ll_l1_ = l1l11l1llll1_l1_+l1ll11lll111_l1_
				line = bidi.algorithm.get_display(line)
				width,l1ll11111lll_l1_ = l1llllll1lll_l1_.textsize(line,font=l1ll1l11ll11_l1_)
				if l1lll111llll_l1_: l1l11ll1llll_l1_ -= width
				l1lll1lll111_l1_ = l1lll1lll11l_l1_+l1l11ll1llll_l1_
				l1llllll1lll_l1_.text((l1lll1lll111_l1_,l1l1ll1111ll_l1_),line,font=l1ll1l11ll11_l1_,fill=l1ll1l1l111l_l1_)
				if not l1lll111llll_l1_: l1l11ll1llll_l1_ += width
				if l1l1ll1111ll_l1_>l1ll1lll11ll_l1_+l1l11lll111l_l1_: break
	l1ll1llllll1_l1_ = l1l111lll1l1_l1_.replace(l11lll_l1_ (u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ䁚"),l11lll_l1_ (u"ࠫࡤ࠭䁛")+str(time.time())+l11lll_l1_ (u"ࠬࡥࠧ䁜"))
	l1ll1llllll1_l1_ = l1ll1llllll1_l1_.replace(l11lll_l1_ (u"࠭࡜࡝ࠩ䁝"),l11lll_l1_ (u"ࠧ࡝࡞࡟ࡠࠬ䁞")).replace(l11lll_l1_ (u"ࠨ࠱࠲ࠫ䁟"),l11lll_l1_ (u"ࠩ࠲࠳࠴࠵ࠧ䁠"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1ll1llllll1_l1_)
	return l1ll1llllll1_l1_,l1111111ll1_l1_
def l11lll11l11_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll1l_l1_=True):
	# should l1l1111lll11_l1_ ==l11lll_l1_ (u"ࠪࠫ䁡") l1111l1l1l_l1_ not l11l111ll1_l1_ it to l11lll_l1_ (u"ࠫࡳࡵࡴࠨ䁢")
	if allow_redirects==l11lll_l1_ (u"ࠬ࠭䁣"): allow_redirects = True
	if l1ll_l1_==l11lll_l1_ (u"࠭ࠧ䁤"): l1ll_l1_ = True
	if l111ll11lll_l1_==l11lll_l1_ (u"ࠧࠨ䁥"): l111ll11lll_l1_ = True
	if l1l1lll1ll1l_l1_==l11lll_l1_ (u"ࠨࠩ䁦"): l1l1lll1ll1l_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll1111lll1_l1_ = list(headers.keys())
	if l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䁧") not in l1ll1111lll1_l1_: headers[l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䁨")] = l11lll_l1_ (u"ࠫࡅࡆࡀࡔࡍࡌࡔࡤࡎࡅࡂࡆࡈࡖࡅࡆࡀࠨ䁩")
	#if l11lll_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䁪") not in l1ll1111lll1_l1_: headers[l11lll_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䁫")] = l11lll_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࡪࡥࡧ࡮ࡤࡸࡪ࠭䁬")
	l11l11l_l1_,l1l11lll1ll1_l1_,l1l1llll1111_l1_,l1l1ll1l111l_l1_ = l1l1l111l1l1_l1_(url)
	l1l111ll1ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ䁭"))
	l1l11ll111l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ䁮"))
	l1l1l11111ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ䁯"))
	l1l11l111111_l1_ = (l1l11lll1ll1_l1_==None and l1l1llll1111_l1_==None and l1l1ll1l111l_l1_==None)
	l1lllll1ll1l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䁰")]
	l1l11ll11lll_l1_ = l11l11l_l1_ in l1lllll1ll1l_l1_
	l1lllllll11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ䁱")]
	l111ll1ll11_l1_ = l11l11l_l1_ in l1lllllll11l_l1_
	l1llllllllll_l1_ = l1l11ll11lll_l1_ or l111ll1ll11_l1_
	if l1l11l111111_l1_ and l1llllllllll_l1_:
		if l1l11ll11lll_l1_:
			l1ll1ll1lll1_l1_ = l1lllll1ll1l_l1_.index(l11l11l_l1_)
			l1lll1lll1l1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ䁲")][l1ll1ll1lll1_l1_]
			l1llll1111l1_l1_ = [l11lll_l1_ (u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩ䁳"),l11lll_l1_ (u"ࠨࡔࡈࡔࡔࡘࡔࡔࠩ䁴"),l11lll_l1_ (u"ࠩࡈࡑࡆࡏࡌࡔࠩ䁵"),l11lll_l1_ (u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ䁶"),l11lll_l1_ (u"ࠫࡎ࡙ࡌࡂࡏࡌࡇࡘ࠭䁷"),l11lll_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ䁸"),l11lll_l1_ (u"࠭ࡋࡏࡑ࡚ࡒࡊࡘࡒࡐࡔࡖࠫ䁹"),l11lll_l1_ (u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨ䁺")]
			l1llll1ll1l1_l1_ = l1llll1111l1_l1_[l1ll1ll1lll1_l1_]
		elif l111ll1ll11_l1_:
			l1ll1ll1lll1_l1_ = l1lllllll11l_l1_.index(l11l11l_l1_)
			l1lll1lll1l1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ䁻")][l1ll1ll1lll1_l1_]
			l1111l11l1l_l1_ = [l11lll_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔࠩ䁼"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬ䁽"),l11lll_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭䁾")]
			l1llll1ll1l1_l1_ = l1111l11l1l_l1_[l1ll1ll1lll1_l1_]
	if l1l1llll1111_l1_==l11lll_l1_ (u"ࠬ࠭䁿"): l1l1llll1111_l1_ = l1l111ll1ll1_l1_
	elif l1l1llll1111_l1_==None and l1l11ll111l1_l1_ in [l11lll_l1_ (u"࠭ࡁࡖࡖࡒࠫ䂀"),l11lll_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ䂁")] and l111ll11lll_l1_: l1l1llll1111_l1_ = l1l111ll1ll1_l1_
	l1l1lll1lll1_l1_ = l11l11l_l1_==l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ䂂")][7]
	if source==l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ䂃"): timeout = 120
	elif source==l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ䂄"): timeout = 20
	elif source==l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ䂅"): timeout = 20
	elif source in l1lllllll111_l1_: timeout = 10
	elif l1l11ll11lll_l1_ or l111ll1ll11_l1_: timeout = 15
	elif l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓࠧ䂆") in source: timeout = 70
	elif l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭䂇") in source: timeout = 75
	elif l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ䂈") in source: timeout = 25
	elif l11lll_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ䂉") in source: timeout = 20
	elif l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ䂊") in source: timeout = 20
	elif l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ䂋") in source: timeout = 20
	elif l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䂌") in source: timeout = 25
	elif l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䂍") in source: timeout = 30
	else: timeout = 15
	if l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ䂎") in source and not data and l11lll_l1_ (u"ࠧࠧࠩ䂏") not in l11l11l_l1_ and l11lll_l1_ (u"ࠨࡁࠪ䂐") not in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫ䂑"))+l11lll_l1_ (u"ࠪ࠳ࠬ䂒")
	l111lll1111_l1_ = (l1l11lll1ll1_l1_!=None)
	l1l1lll11l11_l1_ = (l1l1llll1111_l1_!=None and l1l11ll111l1_l1_!=l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䂓"))
	if l111lll1111_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨ䂔"),l1l11lll1ll1_l1_)
	elif l1l1lll11l11_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭䂕"),l1l1llll1111_l1_)
	if l111lll1111_l1_:
		proxies = {l11lll_l1_ (u"ࠢࡩࡶࡷࡴࠧ䂖"):l1l11lll1ll1_l1_,l11lll_l1_ (u"ࠣࡪࡷࡸࡵࡹࠢ䂗"):l1l11lll1ll1_l1_}
		l1ll1llll1ll_l1_ = l1l11lll1ll1_l1_
	else: proxies,l1ll1llll1ll_l1_ = {},l11lll_l1_ (u"ࠩࠪ䂘")
	if l1l1lll11l11_l1_:
		import urllib3.util.connection as connection
		l11111l1lll_l1_ = l1l11l11ll11_l1_(connection,l1l111ll1ll1_l1_)
	verify = True
	l1lll1ll1ll1_l1_,l1lll1l11111_l1_,l11ll11ll_l1_,l11l111111l_l1_,l111ll1lll1_l1_ = allow_redirects,source,method,False,False
	if l1l1lll1lll1_l1_: l111ll1lll1_l1_ = True
	#if l1llllllllll_l1_ or (method==l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䂙") and allow_redirects): l1lll1ll1ll1_l1_ = False
	if l1llllllllll_l1_ or allow_redirects: l1lll1ll1ll1_l1_ = False
	if l1l11ll11lll_l1_: l11ll11ll_l1_ = l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䂚")
	import requests
	code,reason = -1,l11lll_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ䂛")
	for l11ll111l1_l1_ in range(9):
		l1ll1l11lll1_l1_ = True
		succeeded = False
		try:
			if l11ll111l1_l1_: l1lll1l11111_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧ䂜")
			if not l111lll1111_l1_: l11lll1lll1_l1_(l11lll_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡓࡕࡋࡎࡠࡗࡕࡐࠬ䂝"),l11l11l_l1_,data,headers,l1lll1l11111_l1_,l11ll11ll_l1_)
			try: response.close()
			except: pass
			l11l1l1_l1_ = l11l11l_l1_
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ䂞"),str(l11ll11ll_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭䂟")+str(l11l11l_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ䂠")+str(data)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ䂡")+str(headers)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ䂢")+str(verify)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ䂣")+str(l1lll1ll1ll1_l1_)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ䂤")+str(timeout)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ䂥")+str(proxies))
			response = requests.request(l11ll11ll_l1_,l11l11l_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll1ll1ll1_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l111111l_l1_:
					l1lll1111111_l1_ = list(response.headers.keys())
					if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䂦") in l1lll1111111_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䂧")]
					elif l11lll_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭䂨") in l1lll1111111_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䂩")]
					else: l11l111111l_l1_ = True
					if l11l11l_l1_!=l11l1l1_l1_: l11l11l_l1_ = l11l11l_l1_.encode(l11lll_l1_ (u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧ䂪"),l11lll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ䂫")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䂬"),l11lll_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ䂭"))
					if l1llllllllll_l1_ and response.status_code==307:
						l1lll1ll1ll1_l1_ = allow_redirects
						l11ll11ll_l1_ = method
						l11l111111l_l1_ = True
						l1ll1111l111_l1_
				if not l11l111111l_l1_ or allow_redirects:
					if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䂮") not in l11l11l_l1_:
						server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ䂯"))
						l11l11l_l1_ = server+l11lll_l1_ (u"ࠬ࠵ࠧ䂰")+l11l11l_l1_
				if not l11l111111l_l1_ and allow_redirects:
					l111llll11_l1_ = l11l1llll1_l1_(l11l11l_l1_)
					if l111llll11_l1_ not in [l11lll_l1_ (u"࠭࠮ࡢࡸ࡬ࠫ䂱"),l11lll_l1_ (u"ࠧ࠯ࡶࡶࠫ䂲"),l11lll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䂳"),l11lll_l1_ (u"ࠩ࠱ࡱࡰࡼࠧ䂴"),l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ䂵"),l11lll_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ䂶")]: l1ll1111l111_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111ll1lll1_l1_ = True
			l11l1l1_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status l1ll1ll11111_l1_ a log line: l11lll_l1_ (u"ࠧࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࠨ䂷")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l11lll_l1_ (u"࠭࠺ࠡࠩ䂸"))[1]
			else: reason = str(err).split(l11lll_l1_ (u"ࠧ࠻ࠢࠪ䂹"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l11lll_l1_ (u"ࠨࡇࡵࡶࡳࡵࠧ䂺") in error: code,reason = re.findall(l11lll_l1_ (u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦ䂻"),error)[0]
				elif l11lll_l1_ (u"ࠪ࠰ࠥ࡫ࡲࡳࡱࡵࠬࠬ䂼") in error: code,reason = re.findall(l11lll_l1_ (u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䂽"),error)[0]
				elif error.count(l11lll_l1_ (u"ࠬࡀࠧ䂾"))>=2: reason,code = re.findall(l11lll_l1_ (u"࠭࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪࠩ䂿"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1ll1l11lll1_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䃀"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭䃁")+str(code)+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ䃂")+reason+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ䃃")+source+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ䃄")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ䃅"))
		if l1ll1l11lll1_l1_ and l1llllllllll_l1_ and not l111ll1lll1_l1_ and code!=200:
			l11l11l_l1_ = l1lll1lll1l1_l1_
			l111ll1lll1_l1_ = True
			continue
		if l1ll1l11lll1_l1_: break
	if l1l1llll1111_l1_!=None and l1l11ll111l1_l1_!=l11lll_l1_ (u"࠭ࡓࡕࡑࡓࠫ䃆"): connection.create_connection = l11111l1lll_l1_
	if l1l11ll111l1_l1_==l11lll_l1_ (u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧ䃇") and l111ll11lll_l1_: l1l1llll1111_l1_ = None
	if not succeeded and l1l11lll1ll1_l1_==None and source not in l1lllllll111_l1_:
		l1lll1lllll1_l1_ = traceback.format_exc()
		sys.stderr.write(l1lll1lllll1_l1_)
	l1ll111ll_l1_ = l1l1111l11l_l1_()
	l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡴࡳࡻ࠽ࠑࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦ࠴࠱ࡶࡦࡽࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡷࡧࡷࠎࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸࠮ࡵࡧࡻࡸࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡷࡩࡽࡺࠍࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩ࠷࠴ࡪࡴࡱࡱࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯࡬ࡶࡳࡳ࠮ࠩࠎࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸࠮ࡩ࡫ࡶࡸࡴࡸࡹࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࡮ࡩࡴࡶࡲࡶࡾࠓࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠳࡫࡬ࡢࡲࡶࡩࡩࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡩࡱࡧࡰࡴࡧࡧࠑࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦ࠴࠱ࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡨࡲࡨࡵࡤࡪࡰࡪࠑࠏࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠒࠐࠉࠣࠤࠥ䃈")
	l1ll111ll_l1_.url = l11l1l1_l1_
	try: content = response.content
	except: content = l11lll_l1_ (u"ࠩࠪ䃉")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䃊"))
		except: pass
	code = int(code)
	l1ll111ll_l1_.code = code
	l1ll111ll_l1_.reason = reason
	l1ll111ll_l1_.content = content
	l1ll111ll_l1_.headers = headers
	l1ll111ll_l1_.cookies = cookies
	l1ll111ll_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1ll111ll_l1_.content,str): l1l11ll1l1l1_l1_ = l1ll111ll_l1_.content.lower()
	else: l1l11ll1l1l1_l1_ = l11lll_l1_ (u"ࠫࠬ䃋")
	l1ll11llll11_l1_ = (l11lll_l1_ (u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ䃌") in l1l11ll1l1l1_l1_ or l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭䃍") in l1l11ll1l1l1_l1_) and l1l11ll1l1l1_l1_.count(l11lll_l1_ (u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ䃎"))>2 and l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䃏") not in source and l11lll_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱࠫ䃐") not in l1l11ll1l1l1_l1_
	if code==200 and l1ll11llll11_l1_: l1ll111ll_l1_.succeeded = False
	if l1ll111ll_l1_.succeeded and l1l11l111111_l1_ and l1llllllllll_l1_:
		if l1l1lll1lll1_l1_: l1llll1ll1l1_l1_ = l11lll_l1_ (u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫ䃑")+data[l11lll_l1_ (u"ࠫ࡯ࡵࡢࠨ䃒")].upper()
		l1ll111l1_l1_ = l1l1111ll11_l1_(l1llll1ll1l1_l1_)
	if not l1ll111ll_l1_.succeeded and l1l11l111111_l1_:
		l1ll11lll1l1_l1_ = (l11lll_l1_ (u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ䃓") in l1l11ll1l1l1_l1_ and l11lll_l1_ (u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨ䃔") in l1l11ll1l1l1_l1_)
		l1lll1ll1111_l1_ = (l11lll_l1_ (u"ࠧ࠶ࠢࡶࡩࡨ࠭䃕") in l1l11ll1l1l1_l1_ and l11lll_l1_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩ䃖") in l1l11ll1l1l1_l1_)
		l1ll11llll1l_l1_ = (code in [403] and l11lll_l1_ (u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬ䃗") in l1l11ll1l1l1_l1_)
		l1ll11lllll1_l1_ = (l11lll_l1_ (u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬ䃘") in l1l11ll1l1l1_l1_ and l11lll_l1_ (u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨ䃙") in l1l11ll1l1l1_l1_)
		if   l1ll11llll11_l1_: reason = l11lll_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ䃚")
		elif l1ll11lll1l1_l1_: reason = l11lll_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ䃛")
		elif l1lll1ll1111_l1_: reason = l11lll_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ䃜")
		elif l1ll11llll1l_l1_: reason = l11lll_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩ䃝")
		elif l1ll11lllll1_l1_: reason = l11lll_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ䃞")
		else: reason = str(reason)
		if source in l1lllllll111_l1_:
			LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ䃟"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭䃠")+str(code)+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭䃡")+reason+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䃢")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䃣")+l11l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ䃤"))
		else: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䃥"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ䃦")+str(code)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭䃧")+reason+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䃨")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䃩")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䃪"))
		l1lll1l11l11_l1_ = l111l_l1_(l11l11l_l1_)
		if kodi_version<19 and isinstance(l1lll1l11l11_l1_,unicode): l1lll1l11l11_l1_ = l1lll1l11l11_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䃫"))
		if l1llllllllll_l1_: l1lll1l11l11_l1_ = l1lll1l11l11_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ䃬"))[-1]
		reason = str(reason)+l11lll_l1_ (u"ࠪࡠࡳ࠮ࠠࠨ䃭")+l1lll1l11l11_l1_+l11lll_l1_ (u"ࠫࠥ࠯ࠧ䃮")
		if l1ll11llll11_l1_ or l1ll11lll1l1_l1_ or l1lll1ll1111_l1_ or l1ll11llll1l_l1_ or l1ll11lllll1_l1_:
			code = -2
			l1ll111ll_l1_.code = code
			l1ll111ll_l1_.reason = reason
		l1ll11l111_l1_ = True
		if (l1l11ll111l1_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䃯") or l1l1l11111ll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䃰")) and (l111ll11lll_l1_ or l1l1lll1ll1l_l1_):
			l1ll11l111_l1_ = l1ll1l1l1ll1_l1_(code,reason,source,l1ll_l1_)
			if l1ll11l111_l1_ and l1l11ll111l1_l1_==l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䃱"): l1l11ll111l1_l1_ = l11lll_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ䃲")
			else: l1l11ll111l1_l1_ = l11lll_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ䃳")
			if l1ll11l111_l1_ and l1l1l11111ll_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ䃴"): l1l1l11111ll_l1_ = l11lll_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭䃵")
			else: l1l1l11111ll_l1_ = l11lll_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ䃶")
			settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䃷"),l1l11ll111l1_l1_)
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ䃸"),l1l1l11111ll_l1_)
		if l1ll11l111_l1_:
			l1lll1ll1l11_l1_ = True
			if code==8 and l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䃹") in l11l11l_l1_ and l1lll1ll1l11_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ䃺"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䃻"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ䃼")
				l1ll111l1_l1_ = l11lll11l11_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ䃽"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䃾")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭䃿")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ䄀"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭䄁"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䄂"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䄃"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ䄄")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䄅")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䄆"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫ䄇"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䄈"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l1l11111ll_l1_ in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䄉"),l11lll_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭䄊")] and l1l1lll1ll1l_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ䄋"),l11lll_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ䄌"),time=2000)
				l1ll111l1_l1_ = l111ll1l111_l1_(method,l11l11l_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭䄍"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䄎")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ䄏")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭䄐"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ䄑"),l11lll_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ䄒"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䄓"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ䄔")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䄕")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䄖"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ䄗"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䄘"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l11ll111l1_l1_ in [l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ䄙"),l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䄚")] and l111ll11lll_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩ䄛"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䄜"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ䄝")
				l1ll111l1_l1_ = l11lll11l11_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ䄞"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ䄟")+l1l111ll1ll1_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䄠")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䄡")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䄢"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩ䄣"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䄤"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䄥"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ䄦")+l1l111ll1ll1_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䄧")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䄨")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䄩"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨ䄪"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䄫"),time=2000)
		if l1l1l11111ll_l1_==l11lll_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ䄬") or l1l11ll111l1_l1_==l11lll_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭䄭"): l1ll_l1_ = False
		if not l1ll111ll_l1_.succeeded:
			if l1ll_l1_: l11l1111l11_l1_ = l1ll1l1l1ll1_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l1111lll111_l1_ and l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩ䄮") not in source:
				l1lll11l1111_l1_(l11lll_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬ䄯")+source)
	if settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䄰")) not in [l11lll_l1_ (u"ࠨࡃࡘࡘࡔ࠭䄱"),l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ䄲"),l11lll_l1_ (u"ࠪࡅࡘࡑࠧ䄳")]: settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ䄴"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䄵"))
	if settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䄶")) not in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ䄷"),l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭䄸"),l11lll_l1_ (u"ࠩࡄࡗࡐ࠭䄹")]: settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ䄺"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䄻"))
	return l1ll111ll_l1_
def OPENURL_REQUESTS_CACHED(l11lll1ll11_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll1l_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	if l11lll1ll11_l1_:
		response = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ䄼"),l11lll_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ䄽"),item)
		if response.succeeded:
			l11lll1lll1_l1_(l11lll_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ䄾"),url,data,headers,source,method)
			return response
	response = l11lll11l11_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_,l1l1lll1ll1l_l1_)
	if response.succeeded:
		if l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ䄿") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l11lll1ll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ䅀"),item,response,l11lll1ll11_l1_)
	return response
def OPENURL_CACHED(l11lll1ll11_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䅁")
	else:
		method = l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䅂")
		data = l111l_l1_(data)
		dummy,data = l1lll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l11lll1ll11_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䅃"))
	html = str(html)
	return html
def l1l1l111l1l1_l1_(url):
	l1l1l1111111_l1_ = url.split(l11lll_l1_ (u"࠭ࡼࡽࠩ䅄"))
	l11l11l_l1_,l1l11lll1ll1_l1_,l1l1llll1111_l1_,l1l1ll1l111l_l1_ = l1l1l1111111_l1_[0],None,None,None
	for item in l1l1l1111111_l1_:
		if l11lll_l1_ (u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ䅅") in item: l1l11lll1ll1_l1_ = item.split(l11lll_l1_ (u"ࠨ࠿ࠪ䅆"))[1]
		elif l11lll_l1_ (u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ䅇") in item: l1l1llll1111_l1_ = item.split(l11lll_l1_ (u"ࠪࡁࠬ䅈"))[1]
		elif l11lll_l1_ (u"ࠫࡒࡿࡓࡔࡎࡘࡶࡱࡃࠧ䅉") in item: l1l1ll1l111l_l1_ = item.split(l11lll_l1_ (u"ࠬࡃࠧ䅊"))[1]
	return l11l11l_l1_,l1l11lll1ll1_l1_,l1l1llll1111_l1_,l1l1ll1l111l_l1_
def RESTORE_PATH_NAME(name):
	start,l1l1l1l1ll1_l1_,modified = l11lll_l1_ (u"࠭ࠧ䅋"),l11lll_l1_ (u"ࠧࠨ䅌"),l11lll_l1_ (u"ࠨࠩ䅍")
	name = name.replace(ltr,l11lll_l1_ (u"ࠩࠪ䅎")).replace(rtl,l11lll_l1_ (u"ࠪࠫ䅏"))
	tmp = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫ䅐"),name,re.DOTALL)
	if tmp: start,l1l1l1l1ll1_l1_,name = tmp[0]
	if start not in [l11lll_l1_ (u"ࠬࠦࠧ䅑"),l11lll_l1_ (u"࠭ࠬࠨ䅒"),l11lll_l1_ (u"ࠧࠨ䅓")]: modified = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䅔")
	if l1l1l1l1ll1_l1_: l1l1l1l1ll1_l1_ = l11lll_l1_ (u"ࠩࡢࠫ䅕")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠪࡣࠬ䅖")
	#datetime = re.findall(l11lll_l1_ (u"ࠫ࠭ࡥ࡜ࡥ࡞ࡧࡠ࠳ࡢࡤ࡝ࡦࡢࡠࡩࡢࡤ࡝࠼࡟ࡨࡡࡪ࡟ࠪࠩ䅗"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11lll_l1_ (u"ࠬ࠭䅘"))
	name = l1l1l1l1ll1_l1_+modified+name
	return name
def l1l1lllll1l_l1_(url,l1l1ll11l1ll_l1_,l1l1ll1lllll_l1_,l1ll1ll1l1l1_l1_,headers={}):
	l1l111l11l11_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ䅙"))
	l1111l1ll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ䅚")+l1l1ll11l1ll_l1_)
	if l1111l1ll1l_l1_: l11l1l1_l1_ = url.replace(l1l111l11l11_l1_,l1111l1ll1l_l1_)
	else:
		l11l1l1_l1_ = url
		l1111l1ll1l_l1_ = l1l111l11l11_l1_
	l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䅛"),l11l1l1_l1_,l11lll_l1_ (u"ࠩࠪ䅜"),headers,l11lll_l1_ (u"ࠪࠫ䅝"),l11lll_l1_ (u"ࠫࠬ䅞"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ䅟"))
	html = l1ll111l1_l1_.content
	try: html = html.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䅠"),l11lll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ䅡"))
	except: pass
	if not l1ll111l1_l1_.succeeded or l1ll1ll1l1l1_l1_ not in html:
		l11l11l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭䅢")+l1l1ll1lllll_l1_
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䅣"):l11lll_l1_ (u"ࠪࠫ䅤")}
		l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䅥"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭䅦"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ䅧"),l11lll_l1_ (u"ࠧࠨ䅨"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬ䅩"))
		if l1ll111ll_l1_.succeeded:
			html = l1ll111ll_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䅪"),l11lll_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ䅫"))
				except: pass
			links = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡶࡴ࡯ࡠࡄࡷ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ䅬"),html,re.DOTALL)
			l1lll1ll111l_l1_ = [l1111l1ll1l_l1_]
			for link in links:
				l1111l1ll1l_l1_ = SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䅭"))
				if l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯ࠪ䅮") in link: continue
				if l1111l1ll1l_l1_ in l1lll1ll111l_l1_: continue
				if len(l1lll1ll111l_l1_)==9:
					LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䅯"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ䅰")+l1l1ll11l1ll_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ䅱")+l1l111l11l11_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭䅲"))
					settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭䅳")+l1l1ll11l1ll_l1_,l11lll_l1_ (u"ࠬ࠭䅴"))
					break
				l1lll1ll111l_l1_.append(l1111l1ll1l_l1_)
				l11l1l1_l1_ = url.replace(l1l111l11l11_l1_,l1111l1ll1l_l1_)
				l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䅵"),l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨ䅶"),headers,l11lll_l1_ (u"ࠨࠩ䅷"),l11lll_l1_ (u"ࠩࠪ䅸"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ䅹"))
				html = l1ll111l1_l1_.content
				if l1ll111l1_l1_.succeeded and l1ll1ll1l1l1_l1_ in html:
					LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䅺"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ䅻")+l1l1ll11l1ll_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬ䅼")+l1111l1ll1l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ䅽")+l1l111l11l11_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ䅾"))
					settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ䅿")+l1l1ll11l1ll_l1_,l1111l1ll1l_l1_)
					break
	return l1111l1ll1l_l1_,l11l1l1_l1_,l1ll111l1_l1_
def TRANSLATE(text):
	dict = {
	 l11lll_l1_ (u"ࠪࡳࡱࡪࠧ䆀")			:l11lll_l1_ (u"ࠫ็ี๊ๆࠩ䆁")
	,l11lll_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ䆂")		:l11lll_l1_ (u"࠭ๅห๊ๅๅࠬ䆃")
	,l11lll_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ䆄")		:l11lll_l1_ (u"ࠨ็ไๆํีࠧ䆅")
	,l11lll_l1_ (u"ࠩࡪࡳࡴࡪࠧ䆆")			:l11lll_l1_ (u"ࠪะ๏ีࠧ䆇")
	,l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䆈")		:l11lll_l1_ (u"ࠬ็ิๅࠩ䆉")
	,l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䆊")		:l11lll_l1_ (u"ࠧๆฮ็ำࠬ䆋")
	,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䆌")		:l11lll_l1_ (u"ࠩไ๎ิ๐่ࠨ䆍")
	,l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䆎")			:l11lll_l1_ (u"ࠫ็์วสࠩ䆏")
	,l11lll_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࠫ䆐")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ䆑")
	,l11lll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭䆒")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬ䆓")
	,l11lll_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࡤࡣࡰࠫ䆔")		:l11lll_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫ䆕")
	,l11lll_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䆖")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬ䆗")
	,l11lll_l1_ (u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨ䆘")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭䆙")
	,l11lll_l1_ (u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫ䆚")	:l11lll_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ䆛")
	,l11lll_l1_ (u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬ䆜")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨ䆝")
	,l11lll_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ䆞")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧ䆟")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ䆠")	:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭䆡")
	,l11lll_l1_ (u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫ䆢")		:l11lll_l1_ (u"้ࠪํู่ࠡษ็ื๏์ๅศࠩ䆣")
	,l11lll_l1_ (u"ࠫ࡭࡫࡬ࡢ࡮ࠪ䆤")		:l11lll_l1_ (u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨ䆥")
	,l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨ䆦")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨ䆧")
	,l11lll_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ䆨")		:l11lll_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫ䆩")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬ䆪")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫ䆫")
	,l11lll_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䆬")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭䆭")
	,l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䆮")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ䆯")
	,l11lll_l1_ (u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬ䆰")	:l11lll_l1_ (u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭䆱")
	,l11lll_l1_ (u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䆲")	:l11lll_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫ䆳")
	,l11lll_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䆴")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧ䆵")
	,l11lll_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ䆶")		:l11lll_l1_ (u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠨ䆷")
	,l11lll_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ䆸")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭䆹")
	,l11lll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧ䆺")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩ䆻")
	,l11lll_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䆼")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦศไำสࠫ䆽")
	,l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䆾")		:l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫ䆿")
	,l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࡶࡹࠫ䇀")		:l11lll_l1_ (u"๋ࠬไโࠩ䇁")
	,l11lll_l1_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ䇂")		:l11lll_l1_ (u"ࠧๆๆไࠫ䇃")
	,l11lll_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䇄")		:l11lll_l1_ (u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ䇅")
	,l11lll_l1_ (u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭䇆")	:l11lll_l1_ (u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩ䇇")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䇈")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ䇉")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ䇊")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ䇋")
	,l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ䇌")		:l11lll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭䇍")
	,l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭䇎")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨ䇏")
	,l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨ䇐")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪ䇑")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨ䇒")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫ䇓")
	,l11lll_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ䇔")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫ䇕")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭䇖")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭䇗")
	,l11lll_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䇘")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ䇙")
	,l11lll_l1_ (u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪ䇚")		:l11lll_l1_ (u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩ䇛")
	,l11lll_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䇜")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬ䇝")
	,l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ䇞")	:l11lll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ䇟")
	,l11lll_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬ䇠")	:l11lll_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪ䇡")
	,l11lll_l1_ (u"ࠪࡪࡴࡹࡴࡢࠩ䇢")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢไ์ุะวࠨ䇣")
	,l11lll_l1_ (u"ࠬࡧࡨࡸࡣ࡮ࠫ䇤")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨ䇥")
	,l11lll_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ䇦")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦแษำๆอࠬ䇧")
	,l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫ䇨")		:l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫ䇩")
	,l11lll_l1_ (u"ࠫࡸ࡮࡯ࡧࡪࡤࠫ䇪")		:l11lll_l1_ (u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧ䇫")
	,l11lll_l1_ (u"࠭ࡢࡳࡵࡷࡩ࡯࠭䇬")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬ䇭")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩ䇮")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩ䇯")
	,l11lll_l1_ (u"ࠪࡰࡦࡸ࡯ࡻࡣࠪ䇰")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢ็หึ๎าศࠩ䇱")
	,l11lll_l1_ (u"ࠬࡿࡡࡲࡱࡷࠫ䇲")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏อโ้ฬࠪ䇳")
	,l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ䇴")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ䇵")
	,l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧ䇶")	:l11lll_l1_ (u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬ䇷")
	,l11lll_l1_ (u"ࠫࡩࡸࡡ࡮ࡣࡶ࠻ࠬ䇸")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣำึอๅศุࠢัࠬ䇹")
	,l11lll_l1_ (u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ䇺")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭䇻")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪ䇼")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪ䇽")
	,l11lll_l1_ (u"ࠪ࡭࡫࡯࡬࡮ࠩ䇾")				:l11lll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ䇿")
	,l11lll_l1_ (u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫ䈀")			:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨ䈁")
	,l11lll_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧ䈂")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭䈃")
	,l11lll_l1_ (u"ࠩࡳࡥࡳ࡫ࡴࠨ䈄")				:l11lll_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠧ䈅")
	,l11lll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䈆")			:l11lll_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨ䈇")
	,l11lll_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬ䈈")			:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬ䈉")
	,l11lll_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ䈊")				:l11lll_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧ䈋")
	,l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠫ䈌")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫ䈍")
	,l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ䈎")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪ䈏")
	,l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䈐")		:l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ䈑")
	,l11lll_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬ䈒")			:l11lll_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬ䈓")
	,l11lll_l1_ (u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨ䈔")	:l11lll_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬ䈕")
	,l11lll_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩ䈖")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨ䈗")
	,l11lll_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫ䈘")		:l11lll_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫ䈙")
	,l11lll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䈚")			:l11lll_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠬ䈛")
	,l11lll_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵࠪ䈜")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ䈝")
	,l11lll_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ䈞"):l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨ䈟")
	,l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䈠")	:l11lll_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪ䈡")
	,l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡷࡳࡵ࡯ࡣࡴࠩ䈢")	:l11lll_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦๅ้ษู๎฾࠭䈣")
	,l11lll_l1_ (u"࠭ࡩࡱࡶࡹࠫ䈤")					:l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䈥")
	,l11lll_l1_ (u"ࠨ࡫ࡳࡸࡻ࠳࡬ࡪࡸࡨࠫ䈦")			:l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭䈧")
	,l11lll_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䈨")			:l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨ䈩")
	,l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡷࡪࡸࡩࡦࡵࠪ䈪")			:l11lll_l1_ (u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬ䈫")
	,l11lll_l1_ (u"ࠧ࡮࠵ࡸࠫ䈬")					:l11lll_l1_ (u"ࠨࡏ࠶࡙ࠬ䈭")
	,l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ䈮")				:l11lll_l1_ (u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭䈯")
	,l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䈰")			:l11lll_l1_ (u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨ䈱")
	,l11lll_l1_ (u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ䈲")			:l11lll_l1_ (u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬ䈳")
	}
	try: result = dict[text.lower()]
	except: result = l11lll_l1_ (u"ࠨࠩ䈴")
	return result
def l1lll11l1111_l1_(message=l11lll_l1_ (u"ࠩࠪ䈵")):
	l1l1lll1111l_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11lll_l1_ (u"ࠪ࠾࠴࠭䈶")):
	return _1ll1l11l1l1_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l111111llll_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠫࠬ䈷"),l11lll_l1_ (u"ࠬ࠶ࠧ䈸"),0]: return l11lll_l1_ (u"࠭ࠧ䈹")
	l1l11l11l_l1_ = int(l1l11l11l_l1_)
	first = l1l11l11l_l1_^l11111l_l1_
	second = l1l11l11l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l11l11l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1l11l1l111l_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠧࠨ䈺"),l11lll_l1_ (u"ࠨ࠲ࠪ䈻"),0]: return l11lll_l1_ (u"ࠩࠪ䈼")
	l1l11l11l_l1_ = str(l1l11l11l_l1_)
	result = l11lll_l1_ (u"ࠪࠫ䈽")
	if len(l1l11l11l_l1_)==15:
		first,second,l1lll111l_l1_ = l1l11l11l_l1_[0:4],l1l11l11l_l1_[4:9],l1l11l11l_l1_[9:]
		first = int(first)^l1lll1111_l1_
		second = int(second)^REGULAR_CACHE
		l1lll111l_l1_ = int(l1lll111l_l1_)^l11111l_l1_
		if first==second==l1lll111l_l1_: result = str(first*60)
	return result
def l1l1lll11l1l_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠫࠬ䈾"),l11lll_l1_ (u"ࠬ࠶ࠧ䈿"),0]: return l11lll_l1_ (u"࠭ࠧ䉀")
	l1l11l11l_l1_ = int(l1l11l11l_l1_)+63841823
	first = l1l11l11l_l1_^l11111l_l1_
	second = l1l11l11l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l11l11l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1lll111ll1l_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠧࠨ䉁"),l11lll_l1_ (u"ࠨ࠲ࠪ䉂"),0]: return l11lll_l1_ (u"ࠩࠪ䉃")
	l1l11l11l_l1_ = str(l1l11l11l_l1_)
	length = int(len(l1l11l11l_l1_)/3)
	first = int(l1l11l11l_l1_[0:length])^l11111l_l1_
	second = int(l1l11l11l_l1_[length:2*length])^REGULAR_CACHE
	l1lll111l_l1_ = int(l1l11l11l_l1_[2*length:3*length])^l1lll1111_l1_
	result = l11lll_l1_ (u"ࠪࠫ䉄")
	if first==second==l1lll111l_l1_: result = str(int(first)-63841823)
	return result
def l1l1l1l111_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11ll1l_l1_(l1l1l1l11lll_l1_,l1l1l11llll1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ䉅"),l11lll_l1_ (u"ࠬ࠭䉆"),l11lll_l1_ (u"࠭ࠧ䉇"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䉈"),l1l1l1l11lll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䉉")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䉊"))
		if l1ll11l111_l1_!=1: return
	error = False
	if os.path.exists(l1l1l1l11lll_l1_):
		#os.chmod(l1l1l1l11lll_l1_,0o777)
		for root,dirs,files in os.walk(l1l1l1l11lll_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䉋"),l11lll_l1_ (u"ࠫࠬ䉌"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䉍"),str(err))
					error = True
			if l1l1l11llll1_l1_:
				for dir in dirs:
					l1l111l11111_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l111l11111_l1_)
					except: pass
		if l1l1l11llll1_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䉎"),l11lll_l1_ (u"ࠧࠨ䉏"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䉐"),l11lll_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ䉑"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ䉒"),l11lll_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ䉓"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䉔"))
	return
def l1l1lll1111l_l1_(l1lll1lllll1_l1_=l11lll_l1_ (u"࠭ࠧ䉕")):
	#if l1lll1lllll1_l1_:
	#	if l11lll_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ䉖") in l1lll1lllll1_l1_:
	#		message  = l1lll1lllll1_l1_.split(l11lll_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ䉗"))[1]
	#		LOG_THIS(l11lll_l1_ (u"ࠩࠪ䉘"),l11lll_l1_ (u"ࠪࡊࡔࡘࡃࡆࡆࠣࡉ࡝ࡏࡔࠡࠢࠣࠤ࠳ࠦࠠࠡࠩ䉙")+message)
	#		#sys.stderr.write(l11lll_l1_ (u"ࠫࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕ࠼࡟ࡲࠬ䉚")+message+l11lll_l1_ (u"ࠬࡢ࡮ࡠࠩ䉛"))
	#	else: l11l11l11l1_l1_(l1lll1lllll1_l1_)
	if l1lll1lllll1_l1_:
		l1lll1111l1l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ䉜"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ䉝"),l11lll_l1_ (u"ࠨࠩ䉞"))
		l11l11l11l1_l1_(l1lll1lllll1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ䉟"),l1lll1111l1l_l1_)
	l1l1l11111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ䉠"))
	if l1l1l11111_l1_==l11lll_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ䉡"): settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ䉢"),l11lll_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ䉣"))
	elif l1l1l11111_l1_==l11lll_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ䉤"): settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ䉥"),l11lll_l1_ (u"ࠩࠪ䉦"))
	if settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ䉧")) not in [l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䉨"),l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ䉩"),l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䉪")]: settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䉫"),l11lll_l1_ (u"ࠨࡃࡖࡏࠬ䉬"))
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䉭")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䉮"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䉯"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䉰")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䉱"),l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䉲"))
	l11l111ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ䉳"))
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ䉴"))
	if l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䉵") in str(l11111lll1l_l1_) and l11l111ll11_l1_ in [l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ䉶"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ䉷")]:
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ࠧ䉸"),l11l111ll11_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡗࡪࡺࡖࡪࡧࡺࡑࡴࡪࡥࠩ࠲ࠬࠫ䉹"))
	#l111ll11l11_l1_ = sys.version_info[0]
	#l11111l11l1_l1_ = sys.version_info[1]
	#if l111ll11l11_l1_==2: python_version = l11lll_l1_ (u"ࠨ࠴࠺ࠫ䉺")
	#else: python_version = str(l111ll11l11_l1_)+str(l11111l11l1_l1_)
	#l11l1111111_l1_ = os.path.join(l11lll1l1ll_l1_,l11lll_l1_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ䉻")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䉼"),l11lll_l1_ (u"ࠫࠬ䉽"),l11lll_l1_ (u"ࠬ࠭䉾"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
	return
from EXCLUDES import *
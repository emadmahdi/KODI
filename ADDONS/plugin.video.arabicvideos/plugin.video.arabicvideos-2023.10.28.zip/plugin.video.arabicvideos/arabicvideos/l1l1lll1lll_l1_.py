# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨⳐ")
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫⳑ"):l11lll_l1_ (u"ࠨࠩⳒ")}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⳓ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://www.faselhd.l1ll1l1llll_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/faselhd.l1lll111ll_l1_
# l1llll11ll1_l1_	https://www.l1llll11ll1_l1_.com/faselhd
# l1llll111l1_l1_	https://l1llll111l1_l1_.com/l1l1lll1l11_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪะํอฦำࠢส่ศ๎ำไษิࠫⳔ"),l11lll_l1_ (u"ࠫฬ๊ๅาษฯ฽ฬะࠧⳕ"),l11lll_l1_ (u"ࠬࡽࡷࡦࠩⳖ")]
def MAIN(mode,url,text):
	if   mode==570: results = MENU()
	elif mode==571: results = l1111l_l1_(url,text)
	elif mode==572: results = PLAY(url)
	elif mode==573: results = l1lllll111l_l1_(url,text)
	#elif mode==574: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ⳗ")+text)
	#elif mode==575: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫⳘ")+text)
	elif mode==579: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩⳙ"):l1ll1l1_l1_,l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ⳛ"):l1l11111l_l1_(False)}
	l1ll1l1_l1_,url,response = l1l1lllll1l_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬⳛ"),l11lll_l1_ (u"ࠫๆอีๅࠢศ฽้อๆ๋ࠩⳜ"),l11lll_l1_ (u"ࠬࡪࡵࡣࡤࡨࡨ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬⳝ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳟ"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧⳟ"),l1ll1l1_l1_,579,l11lll_l1_ (u"ࠨࠩⳠ"),l11lll_l1_ (u"ࠩࠪⳡ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧⳢ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳣ"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨⳤ"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭⳥"),574)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳦"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ⳧"),l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ⳨"),575)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⳩"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⳪"),l11lll_l1_ (u"ࠬ࠭Ⳬ"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳬ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨⳭ"),l1ll1l1_l1_,571,l11lll_l1_ (u"ࠨࠩⳮ"),l11lll_l1_ (u"ࠩࠪ⳯"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⳰"))
	items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࠹ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⳱"),html,re.DOTALL)
	if not items:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭Ⳳ"),l11lll_l1_ (u"࠭ࠧⳳ"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣหัࠦฯ๋๋ࠢหาีࠧ⳴"),l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦล๋ฮสำࠥ฿ๆ้ษ้ࠤฬ๊ๅ้ไ฼ࠤศ๎ࠠหื่๎๊ࠦวๅ็๋ๆ฾ࠦส฻์ิࠫ⳵"))
		return
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⳷")+l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠫࠬ⳸"),l11lll_l1_ (u"ࠬ࠭⳹"),l11lll_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠱ࠨ⳺"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡯ࡨࡲࡺ࠳ࡰࡳ࡫ࡰࡥࡷࡿࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⳻"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1lll1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾࡯࡭ࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⳼"),block,re.DOTALL)
		l1l1lll11ll_l1_ = [l11lll_l1_ (u"ࠩࠪ⳽"),l11lll_l1_ (u"ࠪวๆ๊วๆ࠼ࠣࠫ⳾"),l11lll_l1_ (u"ู๊ࠫไิๆสฮ࠿ࠦࠧ⳿"),l11lll_l1_ (u"ࠬฮัศ็ฯ࠾ࠥ࠭ⴀ"),l11lll_l1_ (u"࠭ยิ์๋๎࠿ࠦࠧⴁ"),l11lll_l1_ (u"ࠧฤ่่๎࠿ࠦࠧⴂ")]
		l11ll111l1_l1_ = 0
		for menu in l1lll1l1l1_l1_:
			if l11ll111l1_l1_>0: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴃ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⴄ"),l11lll_l1_ (u"ࠪࠫⴅ"),9999)
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⴆ"),menu,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠬࠩࠧⴇ"): continue
				if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫⴈ") not in link: link = l1ll1l1_l1_+link
				if title==l11lll_l1_ (u"ࠧࠨⴉ"): continue
				if any(value in title.lower() for value in l1l1l1_l1_): continue
				title = l1l1lll11ll_l1_[l11ll111l1_l1_]+title
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴊ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⴋ")+l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠪࠫⴌ"),l11lll_l1_ (u"ࠫࠬⴍ"),l11lll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠸ࠧⴎ"))
			l11ll111l1_l1_ += 1
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"࠭ࠧⴏ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨⴐ"),l11lll_l1_ (u"ࠨࠩⴑ"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪⴒ"):url,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧⴓ"):l1l11111l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨⴔ"),url,l11lll_l1_ (u"ࠬ࠭ⴕ"),l11lll_l1_ (u"࠭ࠧⴖ"),l11lll_l1_ (u"ࠧࠨⴗ"),l11lll_l1_ (u"ࠨࠩⴘ"),l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨⴙ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬࠹ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧⴚ"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	if type==l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬⴛ"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠬࡢ࡜࠰ࠩⴜ"),l11lll_l1_ (u"࠭࠯ࠨⴝ")).replace(l11lll_l1_ (u"ࠧ࡝࡞ࠥࠫⴞ"),l11lll_l1_ (u"ࠨࠤࠪⴟ"))]
	elif type==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠵ࠬⴠ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦࡕ࡯࡭ࡩ࡫ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪⴡ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨⴢ"),block,re.DOTALL)
		l111l111l_l1_,links,l1l111_l1_ = zip(*items)
		items = zip(links,l111l111l_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨⴣ"):
		title,block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⴤ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩⴥ") and len(l1l11ll_l1_)>1:
		title = l1l11ll_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⴦"),l111ll_l1_+title,url,571,l11lll_l1_ (u"ࠩࠪⴧ"),l11lll_l1_ (u"ࠪࠫ⴨"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠸ࠧ⴩"))
		title = l1l11ll_l1_[1][0]
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⴪"),l111ll_l1_+title,url,571,l11lll_l1_ (u"࠭ࠧ⴫"),l11lll_l1_ (u"ࠧࠨ⴬"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠵ࠪⴭ"))
		return
	else:
		title,block = l1l11ll_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥ࡬࠶ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⴮"),block,re.DOTALL)
	#l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ⴯"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩⴰ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫⴱ"),l11lll_l1_ (u"࠭ใๅ์หࠫⴲ"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭ⴳ"),l11lll_l1_ (u"ࠨ้าหๆ࠭ⴴ"),l11lll_l1_ (u"่ࠩฬฬืวสࠩⴵ"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧⴶ"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫⴷ"),l11lll_l1_ (u"ࠬอไษ๊่ࠫⴸ"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭ⴹ")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		l1llll_l1_ = escapeUNICODE(l1llll_l1_)
		l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠧࡀࡴࡨࡷ࡮ࢀࡥ࠾ࠩⴺ"))[0]
		title = unescapeHTML(title)
		#title = escapeUNICODE(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫⴻ"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳ࠰ࠩⴼ") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴽ"),l111ll_l1_+title,link,571,l1llll_l1_)
		#elif any(value in title for value in l1lll1_l1_):
		#	addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⴾ"),l111ll_l1_+title,link,572,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"ࠬ࠭ⴿ"):
			title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬⵀ")+l1lll11_l1_[0][0]
			title = title.strip(l11lll_l1_ (u"ࠧࠡ⠕ࠪⵁ"))
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵂ"),l111ll_l1_+title,link,573,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬⵃ") in link or l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵ࠲ࠫⵄ") in link or l11lll_l1_ (u"ࠫ࡭࡯࡮ࡥ࡫࠲ࠫⵅ") in link:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⵆ"),l111ll_l1_+title,link,572,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵇ"),l111ll_l1_+title,link,573,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨⵈ"):
		l1lll111lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ⵉ"),block,re.DOTALL)
		if l1lll111lll_l1_:
			count = l1lll111lll_l1_[0]
			link = url+l11lll_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫⵊ")+count
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵋ"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧⵌ"),link,571,l11lll_l1_ (u"ࠬ࠭ⵍ"),l11lll_l1_ (u"࠭ࠧⵎ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨⵏ"))
	elif l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴࠩⵐ") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠥⵑ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧⵒ"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"ฺࠫ็อสࠢࠪⵓ")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵔ"),l111ll_l1_+title,link,571,l11lll_l1_ (u"࠭ࠧⵕ"),l11lll_l1_ (u"ࠧࠨⵖ"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠶ࠪⵗ"))
	return
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪⵘ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧⵙ"),url,l11lll_l1_ (u"ࠫࠬⵚ"),l11lll_l1_ (u"ࠬ࠭ⵛ"),l11lll_l1_ (u"࠭ࠧⵜ"),l11lll_l1_ (u"ࠧࠨⵝ"),l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳࠰ࡗࡊࡇࡓࡐࡐࡖࡣࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪⵞ"))
	html = response.content
	#link = l11lll_l1_ (u"ࠩࠪⵟ")
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡡࡴࡱࡱࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫⵠ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࠣࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧⵡ"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩⵢ"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,name,title in items:
					name = unescapeHTML(name)
					if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫⵣ") not in link: link = l1ll1l1_l1_+link
					title = name+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫⵤ")+title
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵥ"),l111ll_l1_+title,link,573,l1llll_l1_,l11lll_l1_ (u"ࠩࠪⵦ"),l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬⵧ"))
	if type==l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⵨") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡰࡵࡷࡩࡷࡏ࡭ࡨࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⵩"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"࠭ࠧ⵪")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡧࡳࡅࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⵫"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⵬"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⵭"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⵮"),l111ll_l1_+title,link,572,l1llll_l1_)
	#if not link: l1111l_l1_(url)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1lll1ll1_l1_,l1l1llll111_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨⵯ"),url,l11lll_l1_ (u"ࠬ࠭⵰"),l11lll_l1_ (u"࠭ࠧ⵱"),l11lll_l1_ (u"ࠧࠨ⵲"),l11lll_l1_ (u"ࠨࠩ⵳"),l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⵴"))
	html = response.content
	l1l1lll11l1_l1_ = re.findall(l11lll_l1_ (u"ุ้ࠪะ่๊ࠢสฺ่๊ว่ัฬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ⵵"),html,re.DOTALL)
	if l1l1lll11l1_l1_:
		l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡺࡡࡨࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⵶"),html,re.DOTALL)
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l1l111lll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡶࡪࡦࡨࡳࡗࡵࡷࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⵷"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⵸"),block,re.DOTALL)
		for link in items:
			link = link.split(l11lll_l1_ (u"ࠧࠧ࡫ࡰ࡫ࡂ࠭⵹"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ⵺"))
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡸࡷ࡫ࡡ࡮ࡊࡨࡥࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⵻"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠥ࡬ࡷ࡫ࡦࠡ࠿ࠣࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ⵼"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"ࠫࠫ࡯࡭ࡨ࠿ࠪ⵽"))[0]
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ⵾"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ⵿ࠧ")+name+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨⶀ"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡏ࡭ࡳࡱࡳࠩ࠰࠭ࡃ࠮ࡨ࡬ࡢࡥ࡮ࡻ࡮ࡴࡤࡰࡹࠪⶁ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ⶂ"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"ࠪࠪ࡮ࡳࡧ࠾ࠩⶃ"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬⶄ")+name+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩⶅ"))
	for l1l1lll1l1l_l1_ in l1lllll1_l1_:
		link,name = l1l1lll1l1l_l1_.split(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩ࠭ⶆ"))
		if link not in l1l1lll1ll1_l1_:
			l1l1lll1ll1_l1_.append(link)
			l1l1llll111_l1_.append(l1l1lll1l1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไๆ่สือ࠭ⶇ"), l1l1llll111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1llll111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⶈ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪⶉ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫⶊ"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭ⶋ"),l11lll_l1_ (u"ࠬ࠱ࠧⶌ"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫⶍ")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1l1lllll1l_l1_(url,l11lll_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩⶎ"),l11lll_l1_ (u"ࠨใสู้ࠦลฺๆส๊๏࠭ⶏ"),l11lll_l1_ (u"ࠩࡧࡹࡧࡨࡥࡥ࠯ࡰࡳࡻ࡯ࡥࡴࠩⶐ"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠹ࠬⶑ"))
	return
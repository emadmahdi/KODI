# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭嬼")
def MAIN(mode,text=l11lll_l1_ (u"ࠬ࠭嬽")):
	if   mode==  0: l1llll1l1l111_l1_(text)
	elif mode==  2: l1l1lll111l1_l1_(text)
	elif mode==  3: l1lllll1lll11_l1_()
	elif mode==  4: l1ll1lllll1l_l1_(text)
	elif mode==  5: l1llll1l11l11_l1_()
	elif mode==  6: l1llllll1111l_l1_()
	elif mode==  7: l1ll111lllll_l1_()
	elif mode==  8: l1llll11lll1l_l1_()
	elif mode==  9: l1llll11lllll_l1_()
	elif mode==150: l1llll11l11l1_l1_()
	elif mode==151: l1lll1l1ll1l1_l1_()
	elif mode==152: l1llll1llll11_l1_()
	elif mode==153: l1111111111l_l1_()
	elif mode==154: l1llllll1l1ll_l1_()
	elif mode==155: l1llll1l1ll11_l1_()
	elif mode==156: l1lll1l1l1lll_l1_()
	elif mode==157: l1llllll111l1_l1_()
	elif mode==158: l1llll1llll1l_l1_()
	elif mode==159: l1llll111l1l1_l1_(True)
	elif mode==170: l1llll111ll11_l1_()
	elif mode==171: l1lllll11l1ll_l1_()
	elif mode==172: l1lll1llll1ll_l1_(text,True,True)
	elif mode==173: l111ll1l11l_l1_(l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭嬾"),True)
	elif mode==174: l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ嬿"),True)
	elif mode==175: l1llll1ll11ll_l1_()
	elif mode==176: l1lll1lllll11_l1_()
	elif mode==177: l1llllll1l111_l1_(l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ孀"))
	elif mode==178: l1llllll1l111_l1_(l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭孁"))
	elif mode==179: l1llllll1l111_l1_(l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ孂"))
	elif mode==190: l1llll1l11lll_l1_()
	elif mode==191: l1lll1lll1111_l1_()
	elif mode==192: l1lll1lllll1l_l1_()
	elif mode==193: l1lllll11ll1l_l1_()
	elif mode==194: l1lll1llll111_l1_()
	elif mode==195: l1llll11l111l_l1_()
	elif mode==196: l1llll1l111ll_l1_()
	elif mode==197: l1llll11ll111_l1_()
	elif mode==198: l1lllll11l11l_l1_()
	elif mode==199: l1llll11l1ll1_l1_()
	elif mode==340: l1lll1ll1l1l1_l1_(text)
	elif mode==341: l1l1l1111l11_l1_()
	elif mode==342: l1llll1l1llll_l1_()
	elif mode==343: l1llll11ll11l_l1_()
	elif mode==344: l1lll1lll111l_l1_(True)
	elif mode==345: l1lllll1111l1_l1_()
	elif mode==346: l11lll1l11l_l1_(False)
	elif mode==347: l1l11llll11l_l1_(True)
	elif mode==348: l1lllll11ll11_l1_()
	elif mode==349: l1lllll1ll1l1_l1_(l1l111l111l1_l1_)
	elif mode==500: l1lll1lll11l1_l1_()
	elif mode==501: l1lll1ll111ll_l1_()
	elif mode==502: l1lllll11l111_l1_(l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ孃"),True)
	elif mode==503: l1lllll1ll1l1_l1_(l11lll11111_l1_)
	elif mode==504: l1lllll1ll1l1_l1_(favoritesfile)
	elif mode==505: l1llll1ll111l_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l11111l1_l1_(text,l11lll_l1_ (u"ࠬ࠭孄"),True)
	elif mode==508: l1lllll11l1l1_l1_()
	elif mode==509: l1llllllllll1_l1_()
	return
def l1llllllllll1_l1_():
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ孅"),l11lll_l1_ (u"ࠧࠨ孆"),l11lll_l1_ (u"ࠨࠩ孇"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ孈"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬ孉"))
	if l1ll11l111_l1_:
		l1lll1lll111l_l1_(False)
		l1ll11ll1l_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ孊"),l11lll_l1_ (u"ࠬ࠭孋"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ孌"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩ孍"))
	return
def l1l1l11111l1_l1_(addon_id,function,l1ll_l1_):
	# function: l11lll_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ孎"),l11lll_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ孏"),l11lll_l1_ (u"ࠪࠫ子")
	conn = sqlite3.connect(l1l1l11ll1l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1llll1111111_l1_ = l11lll_l1_ (u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧ孑")
	else: l1llll1111111_l1_ = l11lll_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫ孒")
	cc.execute(l11lll_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧ孓")+l1llll1111111_l1_+l11lll_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ孔")+addon_id+l11lll_l1_ (u"ࠨࠤࠣ࠿ࠬ孕"))
	l11ll1ll11l_l1_ = cc.fetchall()
	if l11ll1ll11l_l1_ and function in [l11lll_l1_ (u"ࠩࠪ孖"),l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ字")]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ存"),l11lll_l1_ (u"ࠬ࠭孙"),l11lll_l1_ (u"࠭ࠧ孚"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ孛"),l11lll_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ孜")+addon_id+l11lll_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ孝"))
		if l1ll11l111_l1_!=1: return
		cc.execute(l11lll_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩ孞")+l1llll1111111_l1_+l11lll_l1_ (u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ孟")+addon_id+l11lll_l1_ (u"ࠬࠨࠠ࠼ࠩ孠"))
	elif function in [l11lll_l1_ (u"࠭ࠧ孡"),l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨ孢")]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ季"),l11lll_l1_ (u"ࠩࠪ孤"),l11lll_l1_ (u"ࠪࠫ孥"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ学"),l11lll_l1_ (u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ孧")+addon_id+l11lll_l1_ (u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ孨"))
		if l1ll11l111_l1_!=1: return
		if kodi_version<19: cc.execute(l11lll_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧ孩")+addon_id+l11lll_l1_ (u"ࠨࠤࠬࠤࡀ࠭孪"))
		else: cc.execute(l11lll_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ孫")+addon_id+l11lll_l1_ (u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪ孬"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11lll_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ孭"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭孮"),l11lll_l1_ (u"࠭ࠧ孯"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ孰"),l11lll_l1_ (u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬ孱"))
	if function in [l11lll_l1_ (u"ࠩࠪ孲"),l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ孳")]: l1llll111l1l1_l1_(l1ll_l1_)
	return
def l1llll1ll111l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ孴"),l11lll_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ孵"))
	l1l1l1l1111l_l1_ = l11l1111ll1_l1_(False)
	l1llll11l11l_l1_ = l11lll_l1_ (u"࠭࡜࡯ࠩ孶")
	l111111111ll_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ孷")
	l111111111l1_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ學")
	for id,l1l1111lllll_l1_,l1l11l111ll1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason in reversed(l1l1l1l1111l_l1_):
		if id==l11lll_l1_ (u"ࠩ࠳ࠫ孹"):
			l1lll1l1ll1l_l1_,l1lll1l1lll1_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ孺"))
			continue
		if l1llll11l11l_l1_!=l11lll_l1_ (u"ࠫࡡࡴࠧ孻"): l1llll11l11l_l1_ += l111111111l1_l1_
		l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭孼")+id+l11lll_l1_ (u"࠭ࠠ࠻ࠢࠪ孽")+l11lll_l1_ (u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ孾")+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ孿")+l1l11l111ll1_l1_
		l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ宀")+l11111lll11_l1_
		l11l1111l111_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭宁")+l11111l1l11_l1_
		l11l1111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ宂")+reason
		l1llll11l11l_l1_ += l1l1ll1111l_l1_+l1l1ll111l1_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ它")+l111111111ll_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ宄")+l11l1111l111_l1_+l11l1111l11l_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ宅")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ宆"),l1lll1l1lll1_l1_,l1llll11l11l_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ宇"))
	return
def l1lllll1ll1l1_l1_(file):
	if file==favoritesfile: l1llll1ll1ll1_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ守")
	elif file==l1l111l111l1_l1_: l1llll1ll1ll1_l1_ = l11lll_l1_ (u"ࠫฬ๊ัิษษ่ࠬ安")
	elif file==l11lll11111_l1_: l1llll1ll1ll1_l1_ = l11lll_l1_ (u"่่ࠬศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬ宊")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭宋"),l11lll_l1_ (u"ࠧๆีะࠫ完"),l11lll_l1_ (u"ࠨวุ่ฬำࠧ宍"),l11lll_l1_ (u"ࠩัีําࠧ宎"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭宏"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩ宐")+l1llll1ll1ll1_l1_+l11lll_l1_ (u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬ宑"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ宒"),l11lll_l1_ (u"ࠧࠨ宓"),l11lll_l1_ (u"ࠨࠩ宔"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ宕"),l11lll_l1_ (u"ࠪࠫ宖"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ宗"),l11lll_l1_ (u"ࠬะๅࠡ็ึั๋ࠥไโࠢࠪ官")+l1llll1ll1ll1_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ宙"),l11lll_l1_ (u"ࠧࠨ定"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ宛"),l11lll_l1_ (u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ宜")+l1llll1ll1ll1_l1_)
	return
def l1lll1ll111ll_l1_():
	if kodi_version<18:
		message = l11lll_l1_ (u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭宝")+str(kodi_version)+l11lll_l1_ (u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ实")
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭実"),l11lll_l1_ (u"࠭ࠧ宠"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ审"),message)
		return
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ客"))
	l1l111ll1l11_l1_ = l1ll1lll1l1l_l1_([l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ宣")])
	l1l1111l1ll1_l1_,l1lllll1l1lll_l1_,l1lllll1ll11l_l1_,l1lllll1ll111_l1_,l1lllll1l1l1l_l1_,l1lll1ll1l11l_l1_,l1lllll1l1ll1_l1_ = l1l111ll1l11_l1_[l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ室")]
	if l1l1111l1ll1_l1_ or l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ宥") not in str(l11111lll1l_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭宦"),l11lll_l1_ (u"࠭ࠧ宧"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ宨"),l11lll_l1_ (u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭宩"))
		succeeded = l1lllll11l111_l1_(l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ宪"),True)
		if not succeeded: return
	l111lll11l1_l1_(True)
	return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠫ࠮ࠐࠉࡪࡨࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊ࠽࠾ࠩ࠸࠸࠹࠭࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ࠊࠊࡧ࡯࡭࡫ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࡀࡁࠬ࠻࠵࠶ࠩ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡษ็ูํืࠧࠋࠋࡨࡰࡸ࡫࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้๋ࠥฬ่๊็อࠬࠐࠉࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠵ࡀࠉࠊࠥࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡶࡪࡧࡺࡸࡾࡶࡥࠋࠋࠌࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪࠫࠏࠏࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡶࡪࡧࡺࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡥࡦࠤࡂࠦࡣࡰࡰࡱ࠲ࡨࡻࡲࡴࡱࡵࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠷࠹࠸࠳࠴࠻ࠥࡁࠧࠪࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠺࠻࠶࠸࠱ࠢ࠾ࠫ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣࡰ࡯ࡰ࡭ࡹ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࡩࡱ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠴࠾ࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠻࠴࠵ࠩࠌࠧࠥࠨࡌࡪࡵࡷࠤࡊࡳࡡࡥࠤࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠏࠏࡥ࡭࡫ࡩࠤࡨ࡮࡯ࡪࡥࡨࡁࡂ࠸࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨ࠷࠸࠹ࠬࠏࠣࠡࠤࡊࡥࡱࡲࡥࡳࡻࡢࡉࡲࡧࡤࠣࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠪ࠰ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠪࠌࠌࠦࠧࠨ宫")
def l111lll11l1_l1_(l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ宬"))
	if l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ宭") not in str(l11111lll1l_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ宮"),l11lll_l1_ (u"ࠧࠨ宯"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ宰"),l11lll_l1_ (u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ宱"))
		return
	l1lllll1lllll_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ宲"),l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ害"),l11lll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ宴"),l11lll_l1_ (u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧ宵"))
	if not os.path.exists(l1lllll1lllll_l1_): return
	l11ll11llll_l1_ = open(l1lllll1lllll_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ家")).read()
	if kodi_version>18.99: l11ll11llll_l1_ = l11ll11llll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭宷"))
	l1lll1ll11111_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ宸"),l11ll11llll_l1_,re.DOTALL)
	l1lll1ll1ll11_l1_,l11111111111_l1_ = l1lll1ll11111_l1_[0]
	l1llllll1lll1_l1_ = l11lll_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ容")+l1lll1ll1ll11_l1_+l11lll_l1_ (u"ࠫ࠱࠭宺")+l11111111111_l1_+l11lll_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ宻")
	if l1ll_l1_:
		l1lllllll1111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫ宼"))
		if l1lllllll1111_l1_==l11lll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ宽"): l11l111ll11_l1_ = l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨ宾")
		elif l1lllllll1111_l1_==l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ宿"): l11l111ll11_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ寀")
		else: l11l111ll11_l1_ = l11lll_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ寁")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ寂"),l11lll_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ寃"),l11lll_l1_ (u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ寄"),l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭寅"),l11lll_l1_ (u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭密")+l11l111ll11_l1_,l11lll_l1_ (u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ寇"))
		if choice==1: l1llll1ll1l11_l1_ = l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ寈")
		elif choice==2: l1llll1ll1l11_l1_ = l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ寉")
		else: l1llll1ll1l11_l1_ = l11lll_l1_ (u"࠭ࠧ寊")
	else:
		l1lllllll1111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ寋"))
		if   l1lllllll1111_l1_==l11lll_l1_ (u"ࠨࠩ富"): choice = 0
		elif l1lllllll1111_l1_==l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ寍"): choice = 1
		elif l1lllllll1111_l1_==l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ寎"): choice = 2
		l1llll1ll1l11_l1_ = l1lllllll1111_l1_
	if   choice==0: l1llll1l11ll1_l1_ = l11lll_l1_ (u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨ寏")
	elif choice==1: l1llll1l11ll1_l1_ = l11lll_l1_ (u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩ寐")
	elif choice==2: l1llll1l11ll1_l1_ = l11lll_l1_ (u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪ寑")
	else: return
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ寒"),l1llll1ll1l11_l1_)
	l1lll1lll1l11_l1_ = l11lll_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ寓")+l1llll1l11ll1_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ寔")+l11111111111_l1_+l11lll_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ寕")
	l11ll11111l_l1_ = l11ll11llll_l1_.replace(l1llllll1lll1_l1_,l1lll1lll1l11_l1_)
	if kodi_version>18.99: l11ll11111l_l1_ = l11ll11111l_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ寖"))
	open(l1lllll1lllll_l1_,l11lll_l1_ (u"ࠬࡽࡢࠨ寗")).write(l11ll11111l_l1_)
	LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭寘"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬ寙")+l1llll1l11ll1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ寚"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨ寛"))
	return
def l1lll1lll11l1_l1_():
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ寜"),l11lll_l1_ (u"่๊ࠫวࠨ寝"),l11lll_l1_ (u"ࠬ์ูๆࠩ寞"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ察"),l11lll_l1_ (u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬ寠"))
	if l1ll11l111_l1_==1: l1ll111lllll_l1_()
	return
def l1llll11lll1l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ寡"),l11lll_l1_ (u"ࠩࠪ寢"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭寣"),l11lll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧ寤"))
	return
def l1lllll11ll11_l1_():
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห฻าหิࠦิ๋฻ฬࠤว๊ࠠๆฯ่ำ๊ࠥำ็หࠣ࠶࠵࠸࠱ࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ寥")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬ實")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ寧")
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮุࠣึ๐ืࠡษ็ุ้๊ๅࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ寨")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭審")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ寪")
	message = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ寫")+l1l1ll1111l_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪ寬")+l1l1ll111l1_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ寭"),l11lll_l1_ (u"ࠧࠨ寮"),message)
	return
def l11lll1l11l_l1_(l11llllll1l_l1_):
	try: status = l11111l1ll1_l1_(l11llllll1l_l1_,False)
	except: pass
	l1l1l1l1111l_l1_ = l11l1111ll1_l1_(l11llllll1l_l1_)
	id,l1l1111lllll_l1_,l1l11l111ll1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l1l1111l_l1_[0]
	l1lll1l1ll1l_l1_,l1lll1l1lll1_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭寯"))
	l1l1ll111l1_l1_,l11l1111l111_l1_,l11l1111l11l_l1_ = l11111l1l11_l1_.split(l11lll_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ寰"))
	l1l1111lll11_l1_ = True
	while l1l1111lll11_l1_:
		l1llll1l1111l_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ寱"),l11lll_l1_ (u"ࠫำื่อࠩ寲"),l11lll_l1_ (u"ࠬหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ寳"),l11lll_l1_ (u"࠭โศศ่อࠥอไหสิ฽ฬะࠧ寴"),l11lll_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧ寵"),l1l1ll111l1_l1_)
		if l1llll1l1111l_l1_==2: l1llll1l11111_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ寶"),l11lll_l1_ (u"ࠩࠪ寷"),l11lll_l1_ (u"ࠪ฽ํีษࠨ寸"),l11lll_l1_ (u"ࠫࠬ对"),l11lll_l1_ (u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ寺"),l11l1111l111_l1_,l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪ寻"))
		elif l1llll1l1111l_l1_==1: l1l1lll111l1_l1_()
		else: l1l1111lll11_l1_ = False
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ导"),l1l1lll11l1l_l1_(now))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ寽"))
	return
def l1lll1lll111l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ対"),l11lll_l1_ (u"ࠪࠫ寿"),l11lll_l1_ (u"ࠫࠬ尀"),l11lll_l1_ (u"ูࠬฤศๆࠪ封"),l11lll_l1_ (u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧ専"))
	else: l1ll11l111_l1_ = True
	if l1ll11l111_l1_:
		succeeded = True
		if os.path.exists(l1l1ll1l11ll_l1_):
			try: os.remove(l1l1ll1l11ll_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ尃"),l11lll_l1_ (u"ࠨࠩ射"),l11lll_l1_ (u"ࠩࠪ尅"),l11lll_l1_ (u"ࠪฮ๊ࠦศ็ฮสั๋ࠥำฮ๋ࠢฮฺ็๊า่่ࠢๆࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ将"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ將"),l11lll_l1_ (u"ࠬ࠭專"),l11lll_l1_ (u"࠭ࠧ尉"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หุ้ࠣำࠠๆๆไࠤฬ๊ลฺัสำฬะࠧ尊"))
	return
def l1lllll1111l1_l1_():
	l1llll1l11lll_l1_()
	l1lllllll1l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ尋"))
	message = {}
	message[l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ尌")] = l11lll_l1_ (u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩ對")
	message[l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ導")] = l11lll_l1_ (u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ小")
	message[l11lll_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ尐")] = l11lll_l1_ (u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨ少")+str(l11l1llllll_l1_/60)+l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬ尒")
	l1llll111l11l_l1_ = message[l1lllllll1l1l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ尓"),l11lll_l1_ (u"ࠪ็ฬฺࠠࠨ尔")+str(l11l1llllll_l1_/60)+l11lll_l1_ (u"ࠫࠥีโ๋ไฬࠫ尕"),l11lll_l1_ (u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ尖"),l11lll_l1_ (u"࠭ล๋ไสๅ้ࠥวๆๆࠪ尗"),l1llll111l11l_l1_,l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪ尘"))
	if choice==0: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ尙")
	elif choice==1: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ尚")
	elif choice==2: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ尛")
	else: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠫࠬ尜")
	if l1llll1111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ尝"),l1llll1111ll1_l1_)
		l1lll1llll1l1_l1_ = message[l1llll1111ll1_l1_]
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ尞"),l11lll_l1_ (u"ࠧࠨ尟"),l11lll_l1_ (u"ࠨࠩ尠"),l1lll1llll1l1_l1_)
	return
def l1llll11ll11l_l1_():
	message = {}
	message[l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ尡")] = l11lll_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨ尢")
	message[l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ尣")] = l11lll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩ尤")
	message[l11lll_l1_ (u"࠭ࡓࡕࡑࡓࠫ尥")] = l11lll_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ尦")
	l1llllll11l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ尧"))
	l1lllllll1l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ尨"))
	l1llll111l11l_l1_ = message[l1lllllll1l1l_l1_]+l1llllll11l11_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ尩"),l11lll_l1_ (u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩ尪"),l11lll_l1_ (u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ尫"),l11lll_l1_ (u"࠭ล๋ไสๅ้ࠥวๆๆࠪ尬"),l1llll111l11l_l1_,l11lll_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕ๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎็๎ๅࠡสอัํ๐ไࠡลึ้ฬวࠠศๆ่์ฬู่๊ࠡสุ่๐ัโำสฮࠥหไ๊ࠢฦี็อๅ๊ࠡ฼๊ิࠦศฺุࠣห้์วิࠢํๆํ๋ࠠษฯฯฬࠥ๎ๅ็฻ࠣ์า฼ัࠡส฼ฺࠥอไๆ๊สๆ฾ࠦ࠮ࠡๆอุ฿๐ไࠡีํีๆืࠠࡅࡐࡖࠤ็๋ࠠษษัฮ๏อัࠡษ็ื๏ืแาࠢส่๊์วิสࠣวํࠦโๆࠢหษ๏่วโ้ࠣฬฬ๊ใศ็็ࠫ尭"))
	if choice==0: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠨࡃࡖࡏࠬ尮")
	elif choice==1: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ尯")
	elif choice==2: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ尰")
	if choice in [0,1]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ就"),l11lll_l1_ (u"ู๊ࠬาใิ࠾ࠥ࠭尲")+l1lll1l11lll_l1_[1],l11lll_l1_ (u"࠭ำ๋ำไี࠿ࠦࠧ尳")+l1lll1l11lll_l1_[0],l11lll_l1_ (u"ࠧࠨ尴"),l11lll_l1_ (u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧ尵"))
		if l1ll11l111_l1_==1: l1111l1ll1l_l1_ = l1lll1l11lll_l1_[0]
		else: l1111l1ll1l_l1_ = l1lll1l11lll_l1_[1]
	elif choice==2: l1111l1ll1l_l1_ = l11lll_l1_ (u"ࠩࠪ尶")
	else: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠪࠫ尷")
	if l1llll1111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ尸"),l1llll1111ll1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ尹"),l1111l1ll1l_l1_)
		l1lll1llll1l1_l1_ = message[l1llll1111ll1_l1_]+l1111l1ll1l_l1_
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ尺"),l11lll_l1_ (u"ࠧࠨ尻"),l11lll_l1_ (u"ࠨࠩ尼"),l1lll1llll1l1_l1_)
	return
def l1llll1l1llll_l1_():
	l1lllllll1l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ尽"))
	message = {}
	message[l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ尾")] = l11lll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬ尿")
	message[l11lll_l1_ (u"ࠬࡇࡓࡌࠩ局")] = l11lll_l1_ (u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧ屁")
	message[l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ层")] = l11lll_l1_ (u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ屃")
	l1llll111l11l_l1_ = message[l1lllllll1l1l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ屄"),l11lll_l1_ (u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ居"),l11lll_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ屆"),l11lll_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ屇"),l1llll111l11l_l1_,l11lll_l1_ (u"࠭วๅสิ์ู่๊้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์฼้้่ࠦิ์ฺࠤอ๐ๆࠡฮ๊หื้้ࠠษ็ษ๋ะั็์อࠤ࠳ࠦ็้ࠢํืฯ๊ๅูࠡ็ฬฬะใ๊ࠡํๆํ๋ࠠษีะฬ์อࠠษั็ห๋ࠥๆไࠢฮ้ࠥ๐ศฺอ๊ห๊ࠥใࠡ࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣว๊ࠦล๋ไสๅࠥอไษำ๋็ุ๐ࠠภࠩ屈"))
	if choice==0: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠧࡂࡕࡎࠫ屉")
	elif choice==1: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠨࡃࡘࡘࡔ࠭届")
	elif choice==2: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ屋")
	else: l1llll1111ll1_l1_ = l11lll_l1_ (u"ࠪࠫ屌")
	if l1llll1111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭屍"),l1llll1111ll1_l1_)
		l1lll1llll1l1_l1_ = message[l1llll1111ll1_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭屎"),l11lll_l1_ (u"࠭ࠧ屏"),l11lll_l1_ (u"ࠧࠨ屐"),l1lll1llll1l1_l1_)
	return
def l1lllll11l1l1_l1_():
	l1l111l11lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ屑"))
	if l1l111l11lll_l1_==l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ屒"): header = l11lll_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣฯ๎โโࠩ屓")
	else: header = l11lll_l1_ (u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊็ูๅࠩ屔")
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭展"),l11lll_l1_ (u"࠭ล๋ไสๅࠬ屖"),l11lll_l1_ (u"ࠧหใ฼๎้࠭屗"),header,l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆหี๋อๅอࠢํฮ๊ࠦสฮัํฯ์อࠠฤ๊อ์๊อส๋ๅํหࠥฮูะࠢ࠴࠺ูࠥวฺห้๋ࠣࠦร้ๆࠣวุะฮะษ่ࠤ࠳࠴้ࠠวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋๋ࠠฦา๎ࠥหไ๊ࠢอัิ๐ห่ษࠣๅ๏ࠦใๅ่ࠢีฮ๊ࠦห็ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥ࠴࠮๊๊ࠡิฬ๊ࠦิสหࠤอ฽ฦࠡใํࠤๆะอࠡไ๋หห๋ࠠศๆหี๋อๅอ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠠภࠣࠤࠫ屘"))
	if l1ll11l111_l1_==-1: return
	elif l1ll11l111_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ屙"),l11lll_l1_ (u"ࠪࠫ屚"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ屛"),l11lll_l1_ (u"ࠬ࠭屜"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ屝"),l11lll_l1_ (u"ࠧห็ࠣฮๆ฿๊ๅࠢอาื๐ๆࠡษ็ๆํอฦๆࠩ属"))
	else:
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ屟"),l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ屠"))
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ屡"),l11lll_l1_ (u"ࠫࠬ屢"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ屣"),l11lll_l1_ (u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ層"))
	return
def l1llll1l1l111_l1_(text):
	if text!=l11lll_l1_ (u"ࠧࠨ履"):
		text = l1l111ll1ll_l1_(text)
		text = text.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭屦")).encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ屧"))
		l1l111llll1_l1_ = 10103
		l1l111lll11_l1_ = xbmcgui.l1l111l1l11_l1_(l1l111llll1_l1_)
		l1l111lll11_l1_.getControl(311).l1l11l1111l_l1_(text)
		#l1l11l1ll11l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡎࡩࡾࡨ࡯ࡢࡴࡧ࠶࠷࠴ࡸ࡮࡮ࠪ屨"), xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠫࡵࡧࡴࡩࠩ屩")).decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ屪")),l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ屫"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ屬"))
		#l1l11l1ll11l_l1_.show()
		#l1l11l1ll11l_l1_.getControl(99991).setPosition(0,0)
		#l1l11l1ll11l_l1_.getControl(311).l1l11l1111l_l1_(text)
		#l1l11l1ll11l_l1_.getControl(5).l1ll1ll1llll_l1_(l1llllll11111_l1_)
		#width = xbmcgui.l1llll11111l1_l1_()
		#l1ll11111lll_l1_ = xbmcgui.l1llll1lll1ll_l1_()
		#resolution = (0.0+width)/l1ll11111lll_l1_
		#l1l11l1ll11l_l1_.getControl(5).l1l11l11l1ll_l1_(width-180)
		#l1l11l1ll11l_l1_.getControl(5).setHeight(l1ll11111lll_l1_-180)
		#l1l11l1ll11l_l1_.doModal()
		#del l1l11l1ll11l_l1_
	return
l1lll1ll1lll1_l1_ = [
			 l11lll_l1_ (u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࠬ࠭ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨ屭")
			,l11lll_l1_ (u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬ屮")
			,l11lll_l1_ (u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬ屯")
			,l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭屰")
			,l11lll_l1_ (u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭山")
			,l11lll_l1_ (u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨ屲")
			,l11lll_l1_ (u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱࠩࡳࡴ࡮࠰ࡻࡦࡸ࡮ࡪࡰࡪࡷࠬ屳")
			,l11lll_l1_ (u"ࠨࡋࡱࡷࡪࡩࡵࡳࡧࡕࡩࡶࡻࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩ࠯ࠫ屴")
			,l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࠲ࡃࡲࡵࡤࡦ࠿࠳ࠪࡹ࡫ࡸࡵ࠿ࠪ屵")
			,l11lll_l1_ (u"ࠪࡻࡦࡸ࡮ࡪࡰࡪࡷ࠳ࡽࡡࡳࡰࠫࠫ屶")
			,l11lll_l1_ (u"ࠫࡣࡤ࡞࡟ࡠࠪ屷")
			,l11lll_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪ屸")
			]
def l1llll11lll11_l1_(line):
	if l11lll_l1_ (u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫ屹") in line and l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ屺") in line: return True
	for text in l1lll1ll1lll1_l1_:
		if text in line: return True
	return False
def l1lll1l1lll1l_l1_(data):
	data = data.replace(l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭屻")+51*l11lll_l1_ (u"ࠩࠣࠫ屼")+l11lll_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ屽"),l11lll_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ屾"))
	data = data.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ屿")+51*l11lll_l1_ (u"࠭ࠠࠨ岀")+l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ岁"),l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭岂"))
	data = data.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ岃")+51*l11lll_l1_ (u"ࠪࠤࠬ岄")+l11lll_l1_ (u"ࠫࡡࡴࠧ岅"),l11lll_l1_ (u"ࠬࡢ࡮ࠨ岆"))
	data = data.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ岇")+51*l11lll_l1_ (u"ࠧࠡࠩ岈"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ岉")+31*l11lll_l1_ (u"ࠩࠣࠫ岊"))
	#data = data.replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢ࠰ࡵࡷࡳࡷࡧࡧࡦ࠱ࡨࡱࡺࡲࡡࡵࡧࡧ࠳࠵࠵ࡁ࡯ࡦࡵࡳ࡮ࡪ࠯ࡥࡣࡷࡥ࠴ࡵࡲࡨ࠰ࡻࡦࡲࡩ࠮࡬ࡱࡧ࡭࠴࡬ࡩ࡭ࡧࡶ࠳࠳ࡱ࡯ࡥ࡫࠲ࡥࡩࡪ࡯࡯ࡵ࠲ࠫ岋"),l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠩ岌"))
	data = data.replace(l11lll_l1_ (u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫ岍"),l11lll_l1_ (u"࠭࠺ࠡࠩ岎"))
	l11ll1l11_l1_ = l11lll_l1_ (u"ࠧࠨ岏")
	for line in data.splitlines():
		delete = re.findall(l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ岐"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11lll_l1_ (u"ࠩࠪ岑"))
		l11ll1l11_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭岒")+line
	#WRITE_THIS(l11lll_l1_ (u"ࠫࠬ岓"),l11ll1l11_l1_)
	return l11ll1l11_l1_
def l1lll1ll1l1l1_l1_(l1llll1ll1l1l_l1_):
	if l11lll_l1_ (u"ࠬࡕࡌࡅࠩ岔") in l1llll1ll1l1l_l1_:
		l1llllll11l1l_l1_ = l1ll1llll11l_l1_
		header = l11lll_l1_ (u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭岕")
	else:
		l1llllll11l1l_l1_ = l1ll1l11ll1l_l1_
		header = l11lll_l1_ (u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧ岖")
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ岗"),l11lll_l1_ (u"ࠩࠪ岘"),l11lll_l1_ (u"ࠪࠫ岙"),header,l11lll_l1_ (u"ุࠫาไࠡษ็วำ฽วยࠢํัฯ๎๊ࠡลํฺฬูࠦๅ๋ࠣืั๊ࠠศๆสืฯิฯศ็ࠣ࠲ࠥ๎วๅษฮ๊๏์ࠠืำ๋ี๏ฯࠠๅ็฼ีๆฯࠠไ์ไࠤาีหหࠢสฺ่๊ใๅหࠣ์๊อ่๊ࠠࠣห้๋ใศ่ࠣห้ึ๊ࠡีหฬࠥำฯ้อࠣห้๋ิไๆฬࠤ࠳ࠦใ้ัํࠤ๏ำสโฺࠣฬุาไ๋่ࠣ࠲ࠥอไฤ๊็ࠤ์๎ࠠศๆึะ้ࠦวๅฯส่๏่ࠦโ์๊ࠤ๊฿ไ้็สฮࠥะศะล้๋ࠣึࠠษัส๎ฮࠦวๅฬื฾๏๊ࠠศๆะห้๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦศๆ์ࠤฬ๊ย็ࠢ࠱ࠤศ๋วࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠโ้๋ࠤฬ๊ำอๆࠣหู้วษไࠣห้ึ๊ࠡฬ่ࠤัู๋่่๊ࠢࠥฮั็ษ่ะ้่ࠥะ์ࠣๆอ๊ࠠระิࠤส฽แศร่ࠣ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ岚"))
	if l1ll11l111_l1_!=1: return
	l1lll1ll1111l_l1_,counts = [],0
	size,count = l1l1l1l111_l1_(l1llllll11l1l_l1_)
	#size = os.path.getsize(l1llllll11l1l_l1_)
	file = open(l1llllll11l1l_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ岛"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ岜"))
	data = l1lll1l1lll1l_l1_(data)
	lines = data.split(l11lll_l1_ (u"ࠧ࡝ࡰࠪ岝"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭岞"))
		#if line.strip(l11lll_l1_ (u"ࠩࠣࠫ岟"))==l11lll_l1_ (u"ࠪࠫ岠"): continue
		ignore = l1llll11lll11_l1_(line)
		if ignore: continue
		line = line.replace(l11lll_l1_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡢࠫ岡"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭岢"))
		line = line.replace(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖ࠿࠭岣"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࡈࡖࡗࡕࡒ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ岤"))
		l1llll1ll1lll_l1_ = l11lll_l1_ (u"ࠨࠩ岥")
		l1lll1ll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ岦"),line,re.DOTALL)
		if l1lll1ll1ll1l_l1_:
			line = line.replace(l1lll1ll1ll1l_l1_[0][0],l1lll1ll1ll1l_l1_[0][1]).replace(l1lll1ll1ll1l_l1_[0][2],l11lll_l1_ (u"ࠪࠫ岧"))
			l1llll1ll1lll_l1_ = l1lll1ll1ll1l_l1_[0][1]
		else:
			l1lll1ll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ岨"),line,re.DOTALL)
			if l1lll1ll1ll1l_l1_:
				line = line.replace(l1lll1ll1ll1l_l1_[0][1],l11lll_l1_ (u"ࠬ࠭岩"))
				l1llll1ll1lll_l1_ = l1lll1ll1ll1l_l1_[0][0]
		if l1llll1ll1lll_l1_: line = line.replace(l1llll1ll1lll_l1_,l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ岪")+l1llll1ll1lll_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ岫"))
		l1lll1ll1111l_l1_.append(line)
		if len(str(l1lll1ll1111l_l1_))>50100: break
	l1lll1ll1111l_l1_ = reversed(l1lll1ll1111l_l1_)
	l1llllll11111_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱࠫ岬").join(l1lll1ll1111l_l1_)
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ岭"),l11lll_l1_ (u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ岮"),l1llllll11111_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ岯"))
	return
def l1llll11l1ll1_l1_():
	l1llllll11ll1_l1_ = open(l1l1lll11111_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ岰")).read()
	if kodi_version>18.99: l1llllll11ll1_l1_ = l1llllll11ll1_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ岱"))
	l1llllll11ll1_l1_ = l1llllll11ll1_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡶࠪ岲"),l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪ岳"))
	l1l111ll1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ岴"),l1llllll11ll1_l1_,re.DOTALL)
	for line in l1l111ll1l11_l1_:
		l1llllll11ll1_l1_ = l1llllll11ll1_l1_.replace(line,l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭岵")+line+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭岶"))
	DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭岷"),l1llllll11ll1_l1_)
	return
def l1lllll11l11l_l1_():
	l1l1ll1111l_l1_ = l11lll_l1_ (u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ岸")
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ岹")
	l11l1111l111_l1_ = l11lll_l1_ (u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ岺")
	message = l1l1ll1111l_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬ岻")+l1l1ll111l1_l1_+l11lll_l1_ (u"ࠪࠤ࠳ࠦࠧ岼")+l11l1111l111_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ岽"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ岾"),message,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ岿"))
	return
def l1111l1lll1_l1_(type,message,l1ll_l1_=True,url=l11lll_l1_ (u"ࠧࠨ峀"),source=l11lll_l1_ (u"ࠨࠩ峁"),text=l11lll_l1_ (u"ࠩࠪ峂"),l11l11lllll1_l1_=l11lll_l1_ (u"ࠪࠫ峃")):
	l1lll1l1ll111_l1_ = True
	if not l11l1llll1l_l1_(l11lll_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ峄")):
		if l1ll_l1_:
			#if message.count(l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ峅"))>1: l1l1llll1lll_l1_ = l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ峆")
			#else: l1l1llll1lll_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ峇")
			l1lll1lll1l1l_l1_ = (l11lll_l1_ (u"ࠨษ็ื฼ื࠺ࠨ峈") in message and l11lll_l1_ (u"ࠩส่๊้ว็࠼ࠪ峉") in message and l11lll_l1_ (u"ࠪห้๋ไโ࠼ࠪ峊") in message and l11lll_l1_ (u"ࠫฬ๊ฮุลࠪ峋") in message and l11lll_l1_ (u"ࠬอไๆืาี࠿࠭峌") in message)
			if not l1lll1lll1l1l_l1_: l1lll1l1ll111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭峍"),l11lll_l1_ (u"ࠧࠨ峎"),l11lll_l1_ (u"ࠨࠩ峏"),l11lll_l1_ (u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭峐"),message.replace(l11lll_l1_ (u"ࠪࡠࡡࡴࠧ峑"),l11lll_l1_ (u"ࠫࡡࡴࠧ峒")))
	elif l1ll_l1_:
		message = l11lll_l1_ (u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬ峓")
		l1llllllll111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭峔"),l11lll_l1_ (u"ࠧࠨ峕"),l11lll_l1_ (u"ࠨࠩ峖"),l11lll_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ峗")+l11lll_l1_ (u"ࠪࠤࠥ࠷࠯࠶ࠩ峘"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ峙"))
		l1lllllll1lll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ峚"),l11lll_l1_ (u"࠭ࠧ峛"),l11lll_l1_ (u"ࠧࠨ峜"),l11lll_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ峝")+l11lll_l1_ (u"ࠩࠣࠤ࠷࠵࠵ࠨ峞"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ峟"))
		l1lllllll1ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ峠"),l11lll_l1_ (u"ࠬ࠭峡"),l11lll_l1_ (u"࠭ࠧ峢"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ峣")+l11lll_l1_ (u"ࠨࠢࠣ࠷࠴࠻ࠧ峤"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ峥"))
		l1llllllll1ll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ峦"),l11lll_l1_ (u"ࠫࠬ峧"),l11lll_l1_ (u"ࠬ࠭峨"),l11lll_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭峩")+l11lll_l1_ (u"ࠧࠡࠢ࠷࠳࠺࠭峪"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭峫"))
		l1lll1l1ll111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ峬"),l11lll_l1_ (u"ࠪࠫ峭"),l11lll_l1_ (u"ࠫࠬ峮"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ峯")+l11lll_l1_ (u"࠭ࠠࠡ࠷࠲࠹ࠬ峰"),l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ峱"))
	user = l11llll111l_l1_(32,False)
	l1lllll1l1l11_l1_ = l11lll_l1_ (u"ࠨࡃ࡙࠾ࠥ࠭峲")+user+l11lll_l1_ (u"ࠩ࠰ࠫ峳")+type
	l1l111l1lll1_l1_ = True if l11lll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭峴") in text else False
	if not l1lll1l1ll111_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ峵"),l11lll_l1_ (u"ࠬ࠭島"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ峷"),l11lll_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪ峸"))
		return False
	l1lllllllll11_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧ峹"))
	message += l11lll_l1_ (u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨ峺")+l11ll111111_l1_+l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ峻")
	message += l11lll_l1_ (u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬ峼")+user+l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ峽")+l11lll111ll_l1_+l11lll_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ峾")
	message += l11lll_l1_ (u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬ峿")+l1lllllllll11_l1_
	#l11ll1llll1_l1_ = l11l1ll1111_l1_(l11lll_l1_ (u"ࠨ࠹࠹࠲࠻࠻࠮࠲࠵࠻࠲࠷࠹࠰ࠨ崀"))
	l1lll1ll1lll_l1_ = l11l1ll1111_l1_()
	l1lll1ll1lll_l1_ = QUOTE(l1lll1ll1lll_l1_)
	if l1lll1ll1lll_l1_: message += l11lll_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡍࡱࡦࡥࡹ࡯࡯࡯࠼ࠣࠫ崁")+l1lll1ll1lll_l1_
	if url: message += l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡗࡕࡐ࠿ࠦࠧ崂")+url
	if source: message += l11lll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡖࡳࡺࡸࡣࡦ࠼ࠣࠫ崃")+source
	message += l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ崄")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ฬศำํࠤฬ๊ลาีส่ࠬ崅"),l11lll_l1_ (u"ࠧศๆิะฬวࠠศๆส๊ฯ฾วาࠩ崆"))
	if l11l11lllll1_l1_:
		l1llllll11111_l1_ = l11l11lllll1_l1_
		if kodi_version>18.99: l1llllll11111_l1_ = l1llllll11111_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭崇"))
		l1llllll11111_l1_ = base64.b64encode(l1llllll11111_l1_)
	elif l1l111l1lll1_l1_:
		if l11lll_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩ崈") in text: l1lllllll1l11_l1_ = l1ll1llll11l_l1_
		else: l1lllllll1l11_l1_ = l1ll1l11ll1l_l1_
		if not os.path.exists(l1lllllll1l11_l1_):
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ崉"),l11lll_l1_ (u"ࠫࠬ崊"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ崋"),l11lll_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ崌"))
			return False
		l1lll1ll1111l_l1_,counts = [],0
		size,count = l1l1l1l111_l1_(l1lllllll1l11_l1_)
		#size = os.path.getsize(l1lllllll1l11_l1_)
		file = open(l1lllllll1l11_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ崍"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭崎"))
		data = l1lll1l1lll1l_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ崏"))
			ignore = l1llll11lll11_l1_(line)
			if ignore: continue
			l1lll1ll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ崐"),line,re.DOTALL)
			if l1lll1ll1ll1l_l1_:
				line = line.replace(l1lll1ll1ll1l_l1_[0][0],l1lll1ll1ll1l_l1_[0][1]).replace(l1lll1ll1ll1l_l1_[0][2],l11lll_l1_ (u"ࠫࠬ崑"))
			else:
				l1lll1ll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ崒"),line,re.DOTALL)
				if l1lll1ll1ll1l_l1_: line = line.replace(l1lll1ll1ll1l_l1_[0][1],l11lll_l1_ (u"࠭ࠧ崓"))
			l1lll1ll1111l_l1_.append(line)
			if len(str(l1lll1ll1111l_l1_))>121000: break
		l1lll1ll1111l_l1_ = reversed(l1lll1ll1111l_l1_)
		l1llllll11111_l1_ = l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ崔").join(l1lll1ll1111l_l1_)
		l1llllll11111_l1_ = l1llllll11111_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭崕"))
		l1llllll11111_l1_ = base64.b64encode(l1llllll11111_l1_)
	else: l1llllll11111_l1_ = l11lll_l1_ (u"ࠩࠪ崖")
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ崗")][2]
	payload = {l11lll_l1_ (u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬ崘"):l1lllll1l1l11_l1_,l11lll_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭崙"):message,l11lll_l1_ (u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧ崚"):l1llllll11111_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ崛"),url,payload,l11lll_l1_ (u"ࠨࠩ崜"),l11lll_l1_ (u"ࠩࠪ崝"),l11lll_l1_ (u"ࠪࠫ崞"),l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ崟"))
	#succeeded = response.succeeded
	html = response.content
	if l11lll_l1_ (u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧ崠") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สๆࠢส่สืำศๆࠪ崡"),l11lll_l1_ (u"ࠧษ่ฯหา࠭崢"))
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ崣"),l11lll_l1_ (u"ࠩࠪ崤"),l11lll_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩ崥"),l11lll_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭崦"))
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"๊ࠬไฤีไࠫ崧"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦวๅวิืฬ๊ࠧ崨"))
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ崩"),l11lll_l1_ (u"ࠨࠩ崪"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ崫"),l11lll_l1_ (u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨ崬"))
	return succeeded
def l1lll1l1ll1l1_l1_():
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ崭")
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠศๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ崮")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ崯"),l11lll_l1_ (u"ࠧࠨ崰"),l11lll_l1_ (u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ崱"),l1l1ll1111l_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ崲")+l1l1ll111l1_l1_)
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩ崳")
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦวๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ崴")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭崵"),l11lll_l1_ (u"࠭ࠧ崶"),l11lll_l1_ (u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭崷"),l1l1ll1111l_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭崸")+l1l1ll111l1_l1_)
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ崹"),l11lll_l1_ (u"ࠪࠫ崺"),l11lll_l1_ (u"ࠫࠬ崻"),l11lll_l1_ (u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ崼"),l11lll_l1_ (u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪ崽")+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ崾")+l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨ崿"))
	if l1ll11l111_l1_==1: l1llllll1111l_l1_()
	return
def l1111111111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嵀"),l11lll_l1_ (u"ࠪࠫ嵁"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ嵂"),l11lll_l1_ (u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ嵃"))
	return
def l1llllll1l1ll_l1_():
	message = l11lll_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭嵄")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嵅"),l11lll_l1_ (u"ࠨࠩ嵆"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嵇"),message)
	return
def l1llll1l1ll11_l1_():
	message = l11lll_l1_ (u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧ嵈")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ嵉"),l11lll_l1_ (u"ࠬ࠭嵊"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嵋"),message)
	return
def l1lll1l1l1lll_l1_():
	message = l11lll_l1_ (u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫ嵌")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嵍"),l11lll_l1_ (u"ࠩࠪ嵎"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嵏"),l11lll_l1_ (u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭嵐"),message)
	return
def l1llllll111l1_l1_():
	message = l11lll_l1_ (u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ嵑")
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭嵒"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嵓"),message,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ嵔"))
	return
def l1llll1llll1l_l1_():
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪ嵕")
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬ嵖")
	l11l1111l111_l1_ = l11lll_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ嵗")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭嵘"),l11lll_l1_ (u"࠭ࠧ嵙"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嵚"),l1l1ll1111l_l1_,l1l1ll111l1_l1_,l11l1111l111_l1_)
	return
def l1llll1l11lll_l1_():
	l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩ嵛")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ嵜") + l11lll_l1_ (u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩ嵝") + str(PERMANENT_CACHE/60/60/24/30) + l11lll_l1_ (u"ฺࠫࠥ็าࠩ嵞")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ嵟") + l11lll_l1_ (u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ嵠") + str(VERYLONG_CACHE/60/60/24) + l11lll_l1_ (u"ࠧࠡ์๋้ࠬ嵡")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ嵢") + l11lll_l1_ (u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭嵣") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠪࠤ๏๎ๅࠨ嵤")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ嵥") + l11lll_l1_ (u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ嵦") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"࠭ࠠิษ฼อࠬ嵧")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࠪ嵨") + l11lll_l1_ (u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬ嵩") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ࠩࠣืฬ฿ษࠨ嵪")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭嵫") + l11lll_l1_ (u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ嵬") + str(l1ll11111l11_l1_/60) + l11lll_l1_ (u"ࠬࠦฯใ์ๅอࠬ嵭")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ嵮") + l11lll_l1_ (u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩ嵯") + str(NO_CACHE) + l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠨ嵰")
	l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ嵱") + l11lll_l1_ (u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧ嵲") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬ嵳") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫ嵴") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪ嵵") + str(l1ll11111l11_l1_/60) + l11lll_l1_ (u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩ嵶") + str(NO_CACHE) + l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠨ嵷")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ嵸"),l11lll_l1_ (u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ嵹"),l1l1ll111l1_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ嵺"))
	return
def l1lll1lll1111_l1_():
	message = l11lll_l1_ (u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨ嵻")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嵼"),l11lll_l1_ (u"ࠧࠨ嵽"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嵾"),message)
	return
def l1lll1lllll1l_l1_():
	message = l11lll_l1_ (u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪ嵿")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嶀"),l11lll_l1_ (u"ࠫࠬ嶁"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嶂"),message)
	return
def l1lllll11ll1l_l1_():
	message = l11lll_l1_ (u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ嶃")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嶄"),l11lll_l1_ (u"ࠨࠩ嶅"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嶆"),message)
	return
def l1lll1llll111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嶇"),l11lll_l1_ (u"ࠫࠬ嶈"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嶉"),l11lll_l1_ (u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ嶊"))
	l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ嶋"),True)
	return
def l1llll11l111l_l1_():
	message  = l11lll_l1_ (u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪ嶌")
	#message += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ่่าสࠤฬู๊ศศๅࠤ์๎ࠠࡳࡧࡆࡅࡕ࡚ࡃࡉࡃࠣห้ิวึࠢหุึ้ษࠡฮ๋ะ้ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ嶍")
	#message += l11lll_l1_ (u"ࠪ์ฬ๊ะุ๋๊ࠢ฾ะ็ࠡึิ็ฮࠦฬ้ฮ็ࠤำ฻๊ึษ่๊ࠣ์ูࠡสิห๊าࠠๆอ็ࠤ่๎ฯ๋่๊ࠢࠥะีโฯࠣห้หๆหำ้ฮࠬ嶎")
	message += l11lll_l1_ (u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ嶏")
	message += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ嶐")
	message += l11lll_l1_ (u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭嶑")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭嶒"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嶓"),message,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ嶔"))
	message = l11lll_l1_ (u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭嶕")
	message += l11lll_l1_ (u"ࠫࡡࡴࠧ嶖")+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶗")
	message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ嶘")+l11lll_l1_ (u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ嶙")
	message += l11lll_l1_ (u"ࠨ࡞ࡱࠫ嶚")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊฻ัࠡࠢส่่๎๊หࠢࠣว๊๐ัไษࠣࠤ่์ฯศࠢࠣๅึ์ำศࠢࠣห้๐่็ษ้ࠤࠥฮัู๋ส๊๏อࠠศๆศ้ฬืวหࠢฦ่๊อๆ๋ษࠣีํู๊ศࠢส่๏อศศ่ࠣหูู้้ัํอࠥื่ๆษ้๎ฬࠦ็้ๆ้ำฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶛")
	message += l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ嶜")+l11lll_l1_ (u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬ嶝")
	message += l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ศำึ่ࠥืำศๆฬࠤ๊สฯษหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡส็ฯฮࠠโ์๊หࠥอำๆࠢห่ิ้้ࠠลึ้ฬวࠠศๆ่์ฬู่ࠡษ็ฮ๏ࠦไศࠢอืฯ฽ฺ๊ࠢาาํ๊็ศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嶞")
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ嶟"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嶠"),message,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ嶡"))
	#l1l1lll111l1_l1_(l11lll_l1_ (u"ࠩࡌࡷࡕࡸ࡯ࡣ࡮ࡨࡱࡂࡌࡡ࡭ࡵࡨࠫ嶢"))
	#message = l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ嶣")+l11lll_l1_ (u"ࠫํ๊โะࠢ็หา฾ๆศࠢส๎฻อࠠฤ่ࠣห้๋่ศไ฼ࠤฬ๊ๅฺษๅอࠥะฮหๆไࠤออฮหๆสๅࠥอไษๆาࠤํะฮหๆไࠤออฮหๆสๅฺࠥัไหࠣห้อๆหำ้๎ฯࠦแ๋ࠢำ่่ࠦวๅส็ำࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊์ࠦอห๋่ࠣํࠦสๆࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣࡔࡷࡵࡸࡺࠢฦ์ࠥษ๊๊ࠡึ๎้ฯࠠศะิํࠥ็ว็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤุ๎แࠡฬัฮ้็้ࠠๆๆ๊์อࠠๅ่ࠣฮ฾๋ไࠡฮ่๎฾ํวࠨ嶤")
	#message += l11lll_l1_ (u"๊ࠬอๅࠢสฺ่๊ใๅหࠣๆ๊ࠦศฺ็็๎๋ࡀࠠࠡࠢࠣห้ษ่ๅ࠼ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮่ࠦศๅอฬู๋่ࠥࠢสื๊ࠦศๅัๆࠤํอำๆࠢืี่ฯࠠศๆศ๊ฯืๆ๋ฬࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะูๆๆࠣ฽๋ีใࠨ嶥")
	#message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ嶦")+l11lll_l1_ (u"้ࠧษ็ฯฬ์๊࠻ࠢฯีอࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤํ฿ๆะࠢส่อ฿ึࠡไาࠤฯำสศฮࠣๅ็฽ࠠห฼ํ๎ึࠦࡄࡏࡕࠣ์ฬ๊รฮี้ࠤศ์๋ࠠๅ๋๊ࠥ็๊ࠡส็ำࠥอฮาࠢ฼่๊อࠠศ่ࠣหุะฮะษ่ࠤࡕࡸ࡯ࡹࡻࠣๆิ๊ࠦฮๆู้้ࠣไสࠢห฽฻ࠦวๅ็๋ห็฿้ࠠๆๆ๊๊๊ࠥิࠢไ๎ࠥาๅ๋฻ࠣห้ี่ๅࠩ嶧")
	#DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠨ็ื็้ฯฺ่ࠠาࠤอ฿ึࠡษ็๊ฬูࠧ嶨"),message)
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ嶩"),l11lll_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭嶪"),l11lll_l1_ (u"ࠫ์ึวࠡษ็ๅา฻่๊่๊ࠠࠣ฿ัโห๋้ࠣࠦวๅ็ื็้ฯࠠๆ่ࠣ฽๋ีใࠡษ่ࠤ๊์ࠠศๆหี๋อๅอ࠰ࠣื๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหๅา฻ࠠๆ๊สๆ฾ํࠠๆำอ๎๋ࠦวๅล๋่๎ࠦศุ้฼็ࠥอไุสํ฽๏่ࠦศๆฮห๋๐ษࠡสสืฯิฯศ็ࠣฬึ๎ใิ์้ࠣัอๆ๋ࠢส๊ฯࠦสฯฬสี์ࠦๅ็ࠢส่็อฦๆหࠣห้ะ๊ࠡีอ฼์ืࠠๅษะๆฬ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิรࠬ嶫"),l11lll_l1_ (u"ࠬ࠭嶬"),l11lll_l1_ (u"࠭ࠧ嶭"),l11lll_l1_ (u"ࠧไๆสࠫ嶮"),l11lll_l1_ (u"ࠨ่฼้ࠬ嶯"))
	#if l1ll11l111_l1_==1:
	#l1llll1ll11ll_l1_()
	return
def l1llll1l111ll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嶰"),l11lll_l1_ (u"ࠪࠫ嶱"),l11lll_l1_ (u"ࠫะ๊วฬฺࠢี็ࠦไๅฬ๋หฺ๊ࠠๆ฻ࠣห้๋ศา็ฯࠫ嶲"),l11lll_l1_ (u"ࠬษัิๆࠣีุอไสࠢฦ์๋ࠥิไๆฬࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥํะศࠢส่อืๆศ็ฯࡠࡳࡢ࡮ฤ๊ࠣฬฬูสฯัส้ࠥอไโ์ึฬํ้ࠠฤั้ห์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嶳"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嶴"),l11lll_l1_ (u"ࠧࠨ嶵"),l11lll_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ嶶"),l11lll_l1_ (u"ࠩ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࡡࡴ࡜࡯࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࡤ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࡡࡍࡎࡏࡐࡊ࠲ࡡࡎࡏࡐࡑࡋ࠲ࡡࡏࡐࡑࡒࡌ࠲ࡡࡐࡑࡒࡓࡍ࠲ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤࡆࡇࡁࡂࡃ࠵ࡣࡇࡈࡂࡃࡄ࠵ࡣࡈࡉࡃࡄࡅ࠵ࡣࡉࡊࡄࡅࡆ࠵ࡣࡊࡋࡅࡆࡇ࠵ࡣࡋࡌࡆࡇࡈ࠵ࡣࡌࡍࡇࡈࡉ࠵ࡣࡍࡎࡈࡉࡊ࠵ࡣࡎࡏࡉࡊࡋ࠵ࡣࡏࡐࡊࡋࡌ࠵ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࠤ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇࠠࡃࡄࡅࡆࡇ࠭嶷"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嶸"),l11lll_l1_ (u"ࠫࠬ嶹"),l11lll_l1_ (u"ࠬࡈࡂࡃࡄࡅࡆࡇࡈࡂࡃࠢࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ嶺"),l11lll_l1_ (u"࠭࠰ࠡ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠿ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ嶻"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嶼"),l11lll_l1_ (u"ࠨࠩ嶽"),l11lll_l1_ (u"ࠩࡅࡆࡇࡈࡂࡃࡄࡅࡆࡇࠦࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ嶾"),l11lll_l1_ (u"ࠪ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠩ嶿"))
	#text = l11lll_l1_ (u"ࠫ࠭ࠦࡁࡂࡃࡄࡅ࠶ࡥࡂࡃࡄࡅࡆ࠶ࡥࡃࡄࡅࡆࡇ࠶ࡥࡄࡅࡆࡇࡈ࠶ࡥࡅࡆࡇࡈࡉ࠶ࡥࡆࡇࡈࡉࡊ࠶ࡥࡇࡈࡉࡊࡋ࠶ࡥࡈࡉࡊࡋࡌ࠶ࡥࡉࡊࡋࡌࡍ࠶ࠦࠩࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠧ巀")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭巁"),l11lll_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ巂"),l11lll_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ巃"),l11lll_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ巄"),l11lll_l1_ (u"ࠩ࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶࠷࠸࠲࠳࠴ࠪ巅"),text,l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ巆"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࠬ巇"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ巈"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭巉"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ巊"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ巋"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭巌"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ巍"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巎"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ巏"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭巐"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巑"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ巒"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ巓"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ巔"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巕"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ巖"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巗"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巘"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ巙"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ巚"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ巛"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ巜"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈ࡝ࡰࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ川"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ州"))
	return
def l1llll11lllll_l1_():
	l1llll1l11lll_l1_()
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ巟"),l11lll_l1_ (u"ࠨࠩ巠"),l11lll_l1_ (u"ࠩࠪ巡"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧ巢"),l11lll_l1_ (u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ์ฬ๊ๅิฯࠣ๎ฯ๋ࠠหๆๅหห๐วࠡ฻้ำࠥอๆห้สลࠥ฿ๅาࠢสฺ่็อศฬࠣ์ฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫ巣"))
	if l1ll11l111_l1_==1:
		l111l11ll11_l1_(True)
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭巤"),l11lll_l1_ (u"࠭ࠧ工"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧ左"),l11lll_l1_ (u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩ巧"))
	return l1ll11l111_l1_
def l1ll1lllll1l_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭巨"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩ巩"),l11lll_l1_ (u"ࠫࠬ巪"),l11lll_l1_ (u"ࠬ࠭巫"),False,l11lll_l1_ (u"࠭ࠧ巬"),l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ巭"))
	#html = response.content
	if not response.succeeded:
		l1llll111lll1_l1_ = False
		l11l1lllll_l1_ = l11l1ll111_l1_()
		LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭差"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧ巯")+l11l1lllll_l1_+l11lll_l1_ (u"ࠪࡡࠬ巰"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ己"),l11lll_l1_ (u"ࠬ࠭已"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ巳"),l11lll_l1_ (u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ巴"))
	else:
		l1llll111lll1_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ巵"),l11lll_l1_ (u"ࠩࠪ巶"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭巷"),l11lll_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ巸"))
	if not l1llll111lll1_l1_ and l1ll_l1_: l1llll1llll11_l1_()
	return l1llll111lll1_l1_
def l1llll1llll11_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭巹"),l11lll_l1_ (u"࠭ࠧ巺"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ巻"),l11lll_l1_ (u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧ巼"))
	#l1l1ll111l1_l1_ = l11lll_l1_ (u"ࠩื๋ฬีษࠡษ็ฮู็๊า๊ࠢ๎๋ࠥไโࠢํัฯ๎๊ࠡ฻็ํฺࠥแาหࠣาฬ฻ษࠡล๋ࠤฯ๎วใ์฼ࠤำอีสࠢ็ุึ้วห่ࠢ฽ึ๎แส๋่ࠢ์ࠦสศำําࠥ฻ไศฯํอࠥ๎ๆโษำࠤํอไ฻ำูࠤ๊์็้๋ࠡࠤฯฮวะๆࠣหู้๋ๅ๊่หฯࠦศุำํๆฮࠦๅีใิอࠥ๐ีฺสࠣหำะัศไ๊หࠥ๎แ่็๊หࠬ巽")
	l1lllll11lll1_l1_()
	return
def l1l1lll111l1_l1_(text=l11lll_l1_ (u"ࠪࠫ巾")):
	l1l111l1lll1_l1_ = True
	if l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ巿") not in text:
		l1l111l1lll1_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ帀"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ币"),l11lll_l1_ (u"ࠧฦำึห้ࠦๅีๅ็อࠬ市"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠาีส่ฮ࠭布"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ帄"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠๆึๆ่ฮࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤ࠭帅"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l111l1lll1_l1_ = True
			text = l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ帆")
	if l1l111l1lll1_l1_:
		#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ帇"),l11lll_l1_ (u"࠭ࠧ师"),l11lll_l1_ (u"ࠧࠨ帉"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ帊"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ帋"))
		#if not l1ll11l111_l1_:
		#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ希"),l11lll_l1_ (u"ࠫࠬ帍"),l11lll_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ帎"),l11lll_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ帏"))
		#	return
		l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ帐")
		if l11lll_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ帑") not in text:
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ帒"),l11lll_l1_ (u"ࠪࠫ帓"),l11lll_l1_ (u"ࠫࠬ帔"),l11lll_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ帕"),l11lll_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭帖"))
			if l1ll11l111_l1_!=1:
				DIALOG_OK(l11lll_l1_ (u"ࠧࠨ帗"),l11lll_l1_ (u"ࠨࠩ帘"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ帙"),l11lll_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭帚"))
				return
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ帛"),l11lll_l1_ (u"ࠬ࠭帜"),l11lll_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ帝"),l11lll_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ帞"))
	search = OPEN_KEYBOARD(header=l11lll_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ帟"),source=script_name)
	if not search: return
	message = search
	if l1l111l1lll1_l1_: type = l11lll_l1_ (u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪ帠")
	else: type = l11lll_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫ帡")
	succeeded = l1111l1lll1_l1_(type,message,True,l11lll_l1_ (u"ࠫࠬ帢"),l11lll_l1_ (u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡘࡗࡊࡘࡓࠨ帣"),text)
	#	url = l11lll_l1_ (u"࠭࡭ࡺࠢࡄࡔࡎࠦࡡ࡯ࡦ࠲ࡳࡷࠦࡓࡎࡖࡓࠤࡸ࡫ࡲࡷࡧࡵࠫ帤")
	#	payload = l11lll_l1_ (u"ࠧࡼࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ࠾ࠧࡓ࡙ࠡࡃࡓࡍࠥࡑࡅ࡚ࠤ࠯ࠦࡹࡵࠢ࠻࡝ࠥࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠤࡠ࠰ࠧࡹࡥ࡯ࡦࡨࡶࠧࡀࠢ࡮ࡧࡃࡩࡲࡧࡩ࡭࠰ࡦࡳࡲࠨࠬࠣࡵࡸࡦ࡯࡫ࡣࡵࠤ࠽ࠦࡋࡸ࡯࡮ࠢࡄࡶࡦࡨࡩࡤ࡙ࠢ࡭ࡩ࡫࡯ࡴࠤ࠯ࠦࡹ࡫ࡸࡵࡡࡥࡳࡩࡿࠢ࠻ࠤࠪ帥")+message+l11lll_l1_ (u"ࠨࠤࢀࠫ带")
	#	#auth=(l11lll_l1_ (u"ࠤࡤࡴ࡮ࠨ帧"), l11lll_l1_ (u"ࠥࡱࡾࠦࡰࡦࡴࡶࡳࡳࡧ࡬ࠡࡣࡳ࡭ࠥࡱࡥࡺࠤ帨")),
	#	import requests
	#	response = requests.request(l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ帩"),url, data=payload, headers=l11lll_l1_ (u"ࠬ࠭帪"), auth=l11lll_l1_ (u"࠭ࠧ師"))
	#	response = requests.post(url, data=payload, headers=l11lll_l1_ (u"ࠧࠨ帬"), auth=l11lll_l1_ (u"ࠨࠩ席"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ帮"),l11lll_l1_ (u"ࠪࠫ帯"),l11lll_l1_ (u"ࠫࠬ帰"),l11lll_l1_ (u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ帱"))
	#	else:
	#		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ帲"),l11lll_l1_ (u"ࠧࠨ帳"),l11lll_l1_ (u"ࠨะฺวࠥ็๊ࠡษ็ษึูวๅࠩ帴"),l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࡽࢀ࠾ࠥࢁࠡࡳࡿࠪ帵").format(response.status_code, response.content))
	#	l1llll1111lll_l1_ = l11lll_l1_ (u"ࠪࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩ帶")
	#	l1llll1l111l1_l1_ = l11lll_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ帷")
	#	header = l11lll_l1_ (u"ࠬ࠭常")
	#	#header += l11lll_l1_ (u"࠭ࡆࡳࡱࡰ࠾ࠥ࠭帹") + l1llll1111lll_l1_
	#	#header += l11lll_l1_ (u"ࠧ࡝ࡰࡗࡳ࠿ࠦࠧ帺") + l1lll1l1l1ll1_l1_
	#	#header += l11lll_l1_ (u"ࠨ࡞ࡱࡇࡨࡀࠠࠨ帻") + l1lll1l1l1ll1_l1_
	#	header += l11lll_l1_ (u"ࠩ࡟ࡲࡘࡻࡢ࡫ࡧࡦࡸ࠿ࠦๅ็ࠢๆ์ิ๐ࠠศๆไ๎ิ๐่ࠡษ็฽ึฮ๊ࠨ帼")
	#	server = l1lllllll111l_l1_.l1llll11l11ll_l1_(l11lll_l1_ (u"ࠪࡷࡲࡺࡰ࠮ࡵࡨࡶࡻ࡫ࡲࠨ帽"),25)
	#	#server.l1llll1l1lll1_l1_()
	#	server.l1llll1ll11l1_l1_(l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪ࠭帾"),l11lll_l1_ (u"ࠬࡶࡡࡴࡵࡺࡳࡷࡪࠧ帿"))
	#	response = server.l1lllll111l11_l1_(l1llll1111lll_l1_,l1llll1l111l1_l1_, header + l11lll_l1_ (u"࠭࡜࡯ࠩ幀") + message)
	#	server.quit()
	return
def l1lllll1lll11_l1_():
	text = l11lll_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫ幁")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ幂"),l11lll_l1_ (u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩ幃"),text,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭幄"))
	text = l11lll_l1_ (u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧ幅")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ幆"),l11lll_l1_ (u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫ幇"),text,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ幈"))
	return
def l1llll1ll1111_l1_(addon_id):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ幉"),l11lll_l1_ (u"ࠩࠪ幊"),l11lll_l1_ (u"ࠪࠫ幋"),addon_id)
	result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ幌")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡪࡦࡲࡳࡦࡿࢀࠫ幍"))
	l1l1l11111_l1_ = True
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡷ࡭ࡻࡴࡪ࡮ࠍࠍࡽࡨ࡭ࡤࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡹࡤࡰࡧ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡧࡤࡥࡱࡱࡷࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠌࠌ࡭࡫ࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫ࠽ࠎࠎࠏࡳࡩࡷࡷ࡭ࡱ࠴ࡲ࡮ࡶࡵࡩࡪ࠮ࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠪࠌࠌࠍࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡃࠠࡕࡴࡸࡩࠏࠏࡵࡴࡧࡵࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡸࡷࡪࡸࡦࡰ࡮ࡧࡩࡷ࠲ࠧࡢࡦࡧࡳࡳࡹࠧ࠭ࡣࡧࡨࡴࡴ࡟ࡪࡦࠬࠎࠎ࡯ࡦࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰ࡨࡼ࡮ࡹࡴࡴࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭࠿ࠐࠉࠊࡵ࡫ࡹࡹ࡯࡬࠯ࡴࡰࡸࡷ࡫ࡥࠩࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡲࡦࡨࡵࡩࡸ࡮ࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࠥ࡬ࡱࡵࡵࡲࡵࠢࡶࡵࡱ࡯ࡴࡦ࠵ࠍࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡡࡥࡦࡲࡲࡸࡥࡤࡣࡨ࡬ࡰࡪ࠯ࠊࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࡩࡣࠡ࠿ࠣࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫࠍࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫࠧࠦ࠻ࠨࠫࠍࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡢࡦࡧࡳࡳࡹࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠤࠣ࠿ࠬ࠯ࠊࠊࠥࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡸࡥࡱࡱࡶࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡴࡳ࡭ࡪࡶࠫ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠢࠣࠤ幎")
	if l1l1l11111_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ幏"))
		time.sleep(1)
	return
def l1lllll11l1ll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ幐"),l11lll_l1_ (u"ࠩࠪ幑"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幒"),l11lll_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩ幓"))
	l1lllll11ll1l_l1_()
	return
def l1lllll11lll1_l1_():
	#	https://l1111ll111l_l1_.tv/download/849
	#   https://play.google.com/l1llll11ll1ll_l1_/l1llll1l1ll1l_l1_/details?id=l1ll1ll11l1_l1_.xbmc.l1111ll111l_l1_
	#	http://mirror.l1lllll111lll_l1_.l1llll111l111_l1_.l1lllllllllll_l1_/l1lllll111111_l1_/xbmc/l1llll11l1lll_l1_/l1lll1l1lll11_l1_/l1lllll1111ll_l1_
	#	http://l1lll1llll11l_l1_.l1lll1ll11lll_l1_.l1lllllllllll_l1_/l1111ll111l_l1_/l1llll11l1lll_l1_/l1lll1l1lll11_l1_/l1lllll1111ll_l1_
	url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳࡩࡳࡴࡲࡶࡸ࠴࡫ࡰࡦ࡬࠲ࡹࡼ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡴ࠱ࡺ࡭ࡳࡪ࡯ࡸࡵ࠲ࡻ࡮ࡴ࠶࠵࠱ࠪ幔")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ幕"),url,l11lll_l1_ (u"ࠧࠨ幖"),l11lll_l1_ (u"ࠨࠩ幗"),l11lll_l1_ (u"ࠩࠪ幘"),l11lll_l1_ (u"ࠪࠫ幙"),l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡉࡑ࡚ࡣࡑࡇࡔࡆࡕࡗࡣࡐࡕࡄࡊࡡ࡙ࡉࡗ࡙ࡉࡐࡐ࠰࠵ࡸࡺࠧ幚"))
	html = response.content
	l1lll1ll11l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡁࠧࡱ࡯ࡥ࡫࠰ࠬࡡࡪࠫ࡝࠰࡟ࡨ࠰࠳࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠫ࠰ࠫ幛"),html,re.DOTALL)
	l1lll1ll11l11_l1_ = l1lll1ll11l11_l1_[0].split(l11lll_l1_ (u"࠭࠭ࠨ幜"))[0]
	l1llllllll1l1_l1_ = str(kodi_version)
	#l11l1111l11l_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ幝")+l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮ่ࠣฬฺ๊ࠦ็็ࠤ๊฿ࠠไ๊า๎ࠥหีะษิࠤ࠶࠿้ࠠ็สࠤอ฿ฯ่ࠩ幞")+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ幟")
	l11l1111l11l_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไฤะํีࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ幠")+l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ幡")+l1lll1ll11l11_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ幢")
	l11l1111l11l_l1_ += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ幣")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭幤")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ幥")+l1llllllll1l1_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ幦")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ幧"),l11lll_l1_ (u"ࠫࠬ幨"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ幩"),l11l1111l11l_l1_)
	return
def l1lll1lllll11_l1_():
	# https://l111llll1ll_l1_-l1llll11111_l1_-l111l11l1l1_l1_.l11111111l1l_l1_.com/request-l1llll1l1l11l_l1_
	# https://l111llll1ll_l1_-l1llll11111_l1_-l111l11l1l1_l1_.l11111111l1l_l1_.com/query-l1lll1ll11l1l_l1_
	l1l1ll1111l_l1_,l1l1ll111l1_l1_,l11l1111l111_l1_,l11l1111l11l_l1_,l1lllll1l1111_l1_,l1lll1l1ll1ll_l1_,l1llll11l1l11_l1_ = l11lll_l1_ (u"࠭ࠧ幪"),l11lll_l1_ (u"ࠧࠨ幫"),l11lll_l1_ (u"ࠨࠩ幬"),l11lll_l1_ (u"ࠩࠪ幭"),l11lll_l1_ (u"ࠪࠫ幮"),l11lll_l1_ (u"ࠫࠬ幯"),l11lll_l1_ (u"ࠬ࠭幰")
	payload,l1lll1ll11ll1_l1_,l1llll1llllll_l1_,l1lll1l1llll1_l1_ = {l11lll_l1_ (u"࠭ࡡࠨ幱"):l11lll_l1_ (u"ࠧࡢࠩ干")},{},[],{}
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ平")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll11111l11_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ年"),url,payload,l11lll_l1_ (u"ࠪࠫ幵"),l11lll_l1_ (u"ࠫࠬ并"),l11lll_l1_ (u"ࠬ࠭幷"),l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫ幸"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡔࡶࡤࡸࡪࡹࠧ幹"),l11lll_l1_ (u"ࠨࡗࡖࡅࠬ幺"))
	html = html.replace(l11lll_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ幻"),l11lll_l1_ (u"࡙ࠪࡐ࠭幼"))
	html = html.replace(l11lll_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡆࡸࡡࡣࠢࡈࡱ࡮ࡸࡡࡵࡧࡶࠫ幽"),l11lll_l1_ (u"࡛ࠬࡁࡆࠩ幾"))
	html = html.replace(l11lll_l1_ (u"࠭ࡓࡢࡷࡧ࡭ࠥࡇࡲࡢࡤ࡬ࡥࠬ广"),l11lll_l1_ (u"ࠧࡌࡕࡄࠫ庀"))
	html = html.replace(l11lll_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ庁"),l11lll_l1_ (u"ࠩࡑ࠲ࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧ庂"))
	html = html.replace(l11lll_l1_ (u"࡛ࠪࡪࡹࡴࡦࡴࡱࠤࡘࡧࡨࡢࡴࡤࠫ広"),l11lll_l1_ (u"ࠫ࡜࠴ࡓࡢࡪࡤࡶࡦ࠭庄"))
	html = html.replace(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ庅"),l11lll_l1_ (u"࠭ࠠࠡࠩ庆"))
	try: l1llll1lllll1_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ庇"),html)
	except:
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ庈"),l11lll_l1_ (u"ࠩࠪ庉"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭床"),l11lll_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫ庋"))
		return
	l1llllll1l11l_l1_,l1lllllllll1l_l1_,l1llll1l11l1l_l1_ = l1llll1lllll1_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭庌"),str(l1llllll1l11l_l1_))
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ庍"),str(l1lllllllll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ庎"),str(l1llll1l11l1l_l1_))
	l1lll1l1llll1_l1_ = {}
	l1111l11l1l_l1_ = [l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࠨ序"),l11lll_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ庐"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ庑")]
	l1llll1111l1_l1_ = [l11lll_l1_ (u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭庒"),l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭库"),l11lll_l1_ (u"࠭ࡅࡎࡃࡌࡐࡘ࠭应"),l11lll_l1_ (u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ底"),l11lll_l1_ (u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ庖"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ店"),l11lll_l1_ (u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ庘"),l11lll_l1_ (u"ࠫࡈࡇࡐࡕࡅࡋࡅࡌࡋࡔࡊࡆࠪ庙"),l11lll_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡖࡒࡏࡊࡔࠧ庚")]
	l11111111ll1_l1_ = [l11lll_l1_ (u"࠭ࡁࡍࡎࠪ庛"),l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ府"),l11lll_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ庝"),l11lll_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭庞"),l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ废")]+l1llll1111l1_l1_+l1111l11l1l_l1_
	for l1l1l1l1ll1_l1_,l1lllllll11l1_l1_,l1llllll11lll_l1_ in l1lllllllll1l_l1_:
		l1llllll11lll_l1_ = escapeUNICODE(l1llllll11lll_l1_)
		l1llllll11lll_l1_ = l1llllll11lll_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭庠")).strip(l11lll_l1_ (u"ࠬࠦ࠮ࠨ庡"))
		l11l1111l11l_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ庢")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ庣")+l1llllll11lll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ庤")
		if l1lllllll11l1_l1_.isdigit():
			l1lll1l1llll1_l1_[l1l1l1l1ll1_l1_] = int(l1lllllll11l1_l1_)
			if int(l1lllllll11l1_l1_)>100: l1lllllll11l1_l1_ = l11lll_l1_ (u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ庥")
			else: l1lllllll11l1_l1_ = l11lll_l1_ (u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ度")
		if l1l1l1l1ll1_l1_ not in l11111111ll1_l1_:
			if   l1lllllll11l1_l1_==l11lll_l1_ (u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ座"): l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠨ庨")+l1l1l1l1ll1_l1_
			elif l1lllllll11l1_l1_==l11lll_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ庩"): l1l1ll111l1_l1_ += l11lll_l1_ (u"ࠧࠡࠢࠪ庪")+l1l1l1l1ll1_l1_
	l11111111l11_l1_,l1llll111llll_l1_,l1llll11l1l1l_l1_ = list(zip(*l1lllllllll1l_l1_))
	for l1l1l1l1ll1_l1_ in sorted(l1l1ll11l111_l1_):
		if l1l1l1l1ll1_l1_ not in l11111111l11_l1_:
			l11l1111l11l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭庫")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭庬")+l11lll_l1_ (u"่ࠪฬ๊้ࠦฮาࠫ庭")+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ庮")
			if l1l1l1l1ll1_l1_ not in l11111111ll1_l1_: l11l1111l111_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠨ庯")+l1l1l1l1ll1_l1_
	for l1llllll11lll_l1_,counts in l1llllll1l11l_l1_:
		l1llllll11lll_l1_ = escapeUNICODE(l1llllll11lll_l1_)
		l1lllll1l1111_l1_ += l1llllll11lll_l1_+l11lll_l1_ (u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ庰")+str(counts)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬ庱")
	l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ庲"))
	l1l1ll111l1_l1_ = l1l1ll111l1_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ庳"))
	l11l1111l111_l1_ = l11l1111l111_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ庴"))
	l11l1111l1ll_l1_ = l1l1ll1111l_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ庵")+l1l1ll111l1_l1_
	#l1111lllll1l_l1_  = l11lll_l1_ (u"ࠬࡢ࡮ࡉ࡫ࡪ࡬࡚ࡹࡡࡨࡧ࠽ࠤࡠࠦࠧ庶")+l1l1ll1111l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ康")
	#l1111lllll1l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࡏࡳࡼ࡛ࡳࡢࡩࡨࠤ࠿࡛ࠦࠡࠩ庸")+l1l1ll111l1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ庹")
	#l1111lllll1l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡓࡵࡕࡴࡣࡪࡩࠥࠦ࠺ࠡ࡝ࠣࠫ庺")+l11l1111l111_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭庻")
	l11l1111l1l1_l1_  = l11lll_l1_ (u"๊ࠫ๎วใ฻๊ࠣัำࠠศๆหี๋อๅอࠢหฮูเ๊ๅࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ庼")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ庽")+l11lll_l1_ (u"่่࠭าสࠤ๊฿ๆศ้ࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠫ庾")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ庿")
	l11l1111l1l1_l1_ += l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ廀")+l11l1111l1ll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ廁")
	l11l1111l1l1_l1_ += l11lll_l1_ (u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩ廂")+l11lll_l1_ (u"ࠫࡡࡴࠧ廃")+l11lll_l1_ (u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩ廄")+l11lll_l1_ (u"࠭࡜࡯ࠩ廅")
	l11l1111l1l1_l1_ += l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ廆")+l11l1111l111_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廇")
	l1llllll11l1_l1_,l1lll1llllll1_l1_,l1lllll111ll1_l1_,l1lll1lll1lll_l1_ = 0,0,0,0
	all = l1lll1l1llll1_l1_[l11lll_l1_ (u"ࠩࡄࡐࡑ࠭廈")]
	if l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ廉") in list(l1lll1l1llll1_l1_.keys()): l1llllll11l1_l1_ = l1lll1l1llll1_l1_[l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ廊")]
	if l11lll_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭廋") in list(l1lll1l1llll1_l1_.keys()): l1lll1llllll1_l1_ = l1lll1l1llll1_l1_[l11lll_l1_ (u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ廌")]
	if l11lll_l1_ (u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ廍") in list(l1lll1l1llll1_l1_.keys()): l1lllll111ll1_l1_ = l1lll1l1llll1_l1_[l11lll_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ廎")]
	if l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ廏") in list(l1lll1l1llll1_l1_.keys()): l1lll1lll1lll_l1_ = l1lll1l1llll1_l1_[l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ廐")]
	l1llll11111ll_l1_ = all-l1llllll11l1_l1_-l1lll1llllll1_l1_-l1lllll111ll1_l1_-l1lll1lll1lll_l1_
	dummy,l1llll1lll1l1_l1_ = l1llll1l11l1l_l1_[0]
	dummy,l1lll1ll1llll_l1_ = l1llll1l11l1l_l1_[1]
	l1llll1111l11_l1_ = l1llll1lll1l1_l1_-l1lll1ll1llll_l1_
	l1llll11l1l11_l1_ += l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ廑")+str(l1lll1ll1llll_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ廒")+l11lll_l1_ (u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪ廓")
	l1llll11l1l11_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ廔")+str(l1llll1111l11_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廕")+l11lll_l1_ (u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭廖")
	l1llll11l1l11_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ廗")+str(l1llll1lll1l1_l1_)+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭廘")+l11lll_l1_ (u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾ࠥ࠭廙")
	l1llll11l1l11_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ廚")+str(len(l1llll1l11l1l_l1_[2:]))+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ廛")+l11lll_l1_ (u"ࠨ฻าำࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎์อࠠฤฮ๊ึฮࠦ࠺ࠡ࡞ࡱࡠࡳ࠭廜")
	for l1ll111l1l1l_l1_,l1l1111lllll_l1_ in l1llll1l11l1l_l1_[2:]:
		l1ll111l1l1l_l1_ = escapeUNICODE(l1ll111l1l1l_l1_)
		l1ll111l1l1l_l1_ = l1ll111l1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ廝")).strip(l11lll_l1_ (u"ࠪࠤ࠳࠭廞"))
		l1llll11l1l11_l1_ += l1ll111l1l1l_l1_+l11lll_l1_ (u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ廟")+str(l1l1111lllll_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠪ廠")
	#l1llll11l1l11_l1_ += l11lll_l1_ (u"࠭࡜࡯࠰ࠪ廡")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ廢")+str(l1llll11111ll_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廣")+l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧ廤")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ廥")+str(l1llllll11l1_l1_)+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭廦")+l11lll_l1_ (u"ࠬ฽ไษษอࠤุ๐ัโำࠣฬฬ๐ห้่ࠣ࠾ࠥ࠭廧")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ廨")+str(l1lll1lll1lll_l1_)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ廩")+l11lll_l1_ (u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫ廪")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ廫")+str(l1lll1llllll1_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ廬")+l11lll_l1_ (u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨ廭")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ廮")+str(l1lllll111ll1_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ廯")+l11lll_l1_ (u"ࠧหอห๎ฯࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠾ࠥ࠭廰")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭廱")+str(len(l1llllll1l11l_l1_))+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ廲")+l11lll_l1_ (u"ࠪำํ๊ࠠี฼็ฮࠥ็๊ะ์๋๋ฬะࠠ࠻ࠢࠪ廳")
	#l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ廴")+l11lll_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥอไฺษ็้ࠥ๐่ๆࠢฦุ้ࠦࠨศๆหหึำษࠪࠩ廵")+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ延")
	l1lll1l1ll1ll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ廷")+l1lllll1l1111_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ廸"),l11lll_l1_ (u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ廹"),l1llll11l1l11_l1_,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭建"))
	#l11ll1l1l1_l1_(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ廻"),l11lll_l1_ (u"ࠬาๅ๋฻๋ࠣีํࠠศๆฦี็อๅࠡฬัูࠥษำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥࠦแใูࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ廼"),l1lll1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ廽"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ廾"),l11lll_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ廿"),l1lll1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ开"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ弁"),l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ异"),l11l1111l1l1_l1_,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ弃"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ弄"),l11lll_l1_ (u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩ弅"),l11l1111l11l_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ弆"))
	return
def l1llll11ll111_l1_():
	message = l11lll_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨ弇")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ弈"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ弉"),message,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ弊"))
	return
def l1l1l1111l11_l1_():
	message = l11lll_l1_ (u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫ弋")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ弌")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ弍")+l1ll11l_l1_[l11lll_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ弎")][0]+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ式")+l1ll11l_l1_[l11lll_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ弐")][1]+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ弑")
	message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ弒")+l1ll11l_l1_[l11lll_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ弓")][1]+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ弔")
	message += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬ引")+l11lll_l1_ (u"ࠪࡠࡳ࠭弖")+l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ弗")+l1ll11l_l1_[l11lll_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭弘")][2]+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ弙")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ弚"),l11lll_l1_ (u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ弛"),message,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ弜"))
	return
def l1llllll1l111_l1_(l1llllll1l1l1_l1_):
	xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩ弝")+l1llllll1l1l1_l1_+l11lll_l1_ (u"ࠫ࠮࠭弞"), True)
	return
def l1llllll1111l_l1_():
	l1ll11l11_l1_(l11lll_l1_ (u"ࠬࡹࡴࡰࡲࠪ弟"))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧ张"))
	return
def l1llll1l11l11_l1_():
	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭弡"), True)
	return
def l1llll111l1l1_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll11l111_l1_ = True
	else: l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ弢"),l11lll_l1_ (u"ࠩࠪ弣"),l11lll_l1_ (u"ࠪࠫ弤"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ弥"),l11lll_l1_ (u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥอไร่ࠣรࠬ弦"))
	if l1ll11l111_l1_==1:
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩ弧"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ弨"),l11lll_l1_ (u"ࠨࠩ弩"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ弪"),l11lll_l1_ (u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪ弫"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ弬"))
	return
def l1llll111ll11_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭弭"),l11lll_l1_ (u"࠭ࠧ弮"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ弯"),l11lll_l1_ (u"ࠨๆ่ืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้่วว็ฬࠤฬ๊ส๋ࠢอี๏ีࠠๆีะ๋ฬ่ࠦๅษࠣฮิิไࠡว็๎์อ้ࠠๆๆ๊ࠥฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥษ่ࠡษึฮำีๅࠡࠤส่่๐ศ้ำาࠦࠥ๎วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢสฺ฿฽ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨ弰"))
	return
def l1llll11l11l1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ弱"),l11lll_l1_ (u"ࠪࠫ弲"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ弳"),l11lll_l1_ (u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨ弴"))
	return
#l1llllll1ll11_l1_ 	  required	and l1llllll1ll11_l1_     installed	and		not l1l1111l1ll1_l1_		ignore
#l1llllll1ll11_l1_ not required	and	l1llllll1ll11_l1_ not installed 	and 	    l1l1111l1ll1_l1_		ignore
#l1llllll1ll11_l1_ not required	and	l1llllll1ll11_l1_ not installed 	and 	not l1l1111l1ll1_l1_		ignore
#l1llllll1ll11_l1_ not required	and	l1llllll1ll11_l1_     installed 	and 	not l1l1111l1ll1_l1_		ignore
#l1llllll1ll11_l1_     required	and	l1llllll1ll11_l1_ not installed 	and 	    l1l1111l1ll1_l1_		l11111l11l_l1_ l1lll1llllll1_l1_	l1lllll1l111l_l1_
#l1llllll1ll11_l1_     required	and	l1llllll1ll11_l1_ not installed 	and 	not l1l1111l1ll1_l1_		l11111l11l_l1_ l1lll1llllll1_l1_	l1lllll1l111l_l1_
#l1llllll1ll11_l1_     required 	and l1llllll1ll11_l1_     installed 	and 	    l1l1111l1ll1_l1_		l11111l11l_l1_ l1llllllll11l_l1_	l1lllll1l111l_l1_
#l1llllll1ll11_l1_ not required	and	l1llllll1ll11_l1_     installed 	and 	    l1l1111l1ll1_l1_		l11111l11l_l1_ l1llllllll11l_l1_	l1lllll1l111l_l1_
#l1ll11llll11_l1_: required and not installed: l11111l11l_l1_ l1lll1llllll1_l1_
#l1ll11lll1l1_l1_: installed and l11111l11l_l1_ update: l11111l11l_l1_ l1llllllll11l_l1_
def l1l11llll11l_l1_(l1ll_l1_=True):
	l1llll1lll111_l1_ = [l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ張"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨ弶"),l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ強"),l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫ弸"),l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ弹"),l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨ强")]
	l1lllll11111l_l1_ = l1llll1lll111_l1_+[l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ弻"),l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ弼"),l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭弽"),l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡰࡩࡧࡱࡳࡲ࡫࡮ࡢ࡮ࡈࡑࡆࡊࠧ弾"),l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭弿"),l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ彀")]		# ,l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰࡬ࡲࡸࡺࡡ࡭࡮ࡈࡑࡆࡊࠧ彁")
	l1l111ll1l11_l1_ = l1ll1lll1l1l_l1_([l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ彂")])
	l1lllll111l1l_l1_ = []
	for addon_id in [l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ彃")]:
		if addon_id not in list(l1l111ll1l11_l1_.keys()): continue
		l1l1111l1ll1_l1_,l1llll111111_l1_,l1lllll1ll11l_l1_,l1lllll1ll111_l1_,l1lllll1l1l1l_l1_,l1lll1ll1l11l_l1_,l1lllll1l1ll1_l1_ = l1l111ll1l11_l1_[addon_id]
		if not l1llll111111_l1_ or (l1llll111111_l1_ and l1l1111l1ll1_l1_): l1lllll111l1l_l1_.append(addon_id)
	l1lll1l1ll11l_l1_ = len(l1lllll111l1l_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1l11ll1l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1lllll1llll1_l1_ = []
	for addon_id in l1llll1lll111_l1_:
		cc.execute(l11lll_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥࠨ࠱ࠣࠢࡤࡲࡩࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ彄")+addon_id+l11lll_l1_ (u"ࠨࠤࠣ࠿ࠬ彅"))
		l11ll1ll11l_l1_ = cc.fetchall()
		if l11ll1ll11l_l1_: l1lllll1llll1_l1_.append(addon_id)
	l1llll11llll1_l1_ = len(l1lllll1llll1_l1_)>0
	for addon_id in l1lllll11111l_l1_:
		cc.execute(l11lll_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ彆")+addon_id+l11lll_l1_ (u"ࠪࠦࠥࡁࠧ彇"))
		l11111111lll_l1_ = cc.fetchall()
		if l11111111lll_l1_ and l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭彈") not in str(l11111111lll_l1_): l1lllll111l1l_l1_.append(addon_id)
	l1llll111111l_l1_ = len(l1lllll111l1l_l1_)>0
	l1lllll111l1l_l1_ = list(set(l1lllll111l1l_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭彉"),l11lll_l1_ (u"࠭࡮ࡦࡧࡧࡣ࡫࡯ࡸࡪࡰࡪࡣࡷ࡫ࡰࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱ࠾ࠥࠦࠧ彊")+str(l1lll1l1ll11l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ彋"),l11lll_l1_ (u"ࠨࡰࡨࡩࡩࡥࡤࡦ࡮ࡨࡸ࡮ࡴࡧࡠࡱ࡯ࡨࡤࡧࡤࡥࡱࡱࡷ࠿ࠦࠠࠨ彌")+str(l1llll11llll1_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ彍"),l11lll_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡨ࡬ࡼ࡮ࡴࡧࡠࡱࡵ࡭࡬࡯࡮࠻ࠢࠣࠫ彎")+str(l1llll111111l_l1_))
	l1l1111l1ll1_l1_ = False
	if l1llll11llll1_l1_ or l1llll111111l_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ彏"),l11lll_l1_ (u"ࠬ࠭彐"),l11lll_l1_ (u"࠭ࠧ彑"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ归"),l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮࠣ์ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤู๊้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦวๅฤ้ࠤฤࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ当"))
		if l1ll11l111_l1_==1:
			l1lllllll11ll_l1_ = True
			if l1lll1l1ll11l_l1_:
				l1lllllll11ll_l1_ = l1lll1llll1ll_l1_(l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ彔"),False,False)
			l1lll1lll11ll_l1_ = True
			if l1llll11llll1_l1_:
				for addon_id in l1lllll1llll1_l1_: l1llll1ll1111_l1_(addon_id)
				l1lll1lll11ll_l1_ = True
			l1lll1lll1ll1_l1_ = True
			if l1llll111111l_l1_:
				conn = sqlite3.connect(l1l1l11ll1l1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1lllll111l1l_l1_:
					if l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࠭录") in addon_id: l11111111lll_l1_ = addon_id
					else: l11111111lll_l1_ = l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭彖")
					try: cc.execute(l11lll_l1_ (u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩ彗")+l11111111lll_l1_+l11lll_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ彘")+addon_id+l11lll_l1_ (u"ࠧࠣࠢ࠾ࠫ彙"))
					except: l1lll1lll1ll1_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ彚"))
			time.sleep(1)
			if l1lllllll11ll_l1_ or l1lll1lll11ll_l1_ or l1lll1lll1ll1_l1_:
				l1l1111l1ll1_l1_ = False
				DIALOG_OK(l11lll_l1_ (u"ࠩࠪ彛"),l11lll_l1_ (u"ࠪࠫ彜"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ彝"),l11lll_l1_ (u"ࠬา๊ะࠢ࠱࠲ࠥะๅࠡส้ะฬำࠠหใ฼๎้่ࠦฦื็หาࠦวๅ็ึฮํีู๊ࠡส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥฬๆ์฼ࠤส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ彞"))
			else:
				l1l1111l1ll1_l1_ = True
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧ彟"),l11lll_l1_ (u"ࠧࠨ彠"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ彡"),l11lll_l1_ (u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎ลึๆสัࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ形"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ彣"),l11lll_l1_ (u"ࠫࠬ彤"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彥"),l11lll_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥษ่ࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭彦"))
	return l1l1111l1ll1_l1_
def l1lll1lllllll_l1_():
	l1lll1l1lllll_l1_,l1llllll1llll_l1_,l1lllll1l11l1_l1_ = False,l11lll_l1_ (u"ࠧࠨ彧"),l11lll_l1_ (u"ࠨࠩ彨")
	l1llllll1ll1l_l1_,l1llll1l1l1ll_l1_,l1llll1lll11l_l1_ = False,l11lll_l1_ (u"ࠩࠪ彩"),l11lll_l1_ (u"ࠪࠫ彪")
	l1l111ll1l11_l1_ = l1ll1lll1l1l_l1_([l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ彫"),l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ彬"),l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ彭")])
	for addon_id in [l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ彮"),l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ彯"),l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ彰")]:
		if addon_id not in list(l1l111ll1l11_l1_.keys()): continue
		l1l1111l1ll1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l11l111_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1l11_l1_ = l1l111ll1l11_l1_[addon_id]
		if addon_id==l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ影"):
			l1llllll1ll1l_l1_ = l1l1111l1ll1_l1_
			l1llll1l1l1ll_l1_ = l11lll_l1_ (u"ࠫ࠭࠭彲")+l1llll111111_l1_+l11lll_l1_ (u"ࠬࠦࠧ彳")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"࠭ࠩࠨ彴")
			l1llll1lll11l_l1_ = l1ll1l11l111_l1_
		elif addon_id==l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ彵"):
			l1lll1l1lllll_l1_ = l1lll1l1lllll_l1_ or l1l1111l1ll1_l1_
			l1llllll1llll_l1_ += l11lll_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠨࠨ彶")+l1llll111111_l1_+l11lll_l1_ (u"ࠩࠣࠫ彷")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"ࠪ࠭ࠬ彸")
			l1lllll1l11l1_l1_ += l11lll_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ役")+l1ll1l11l111_l1_
		elif addon_id==l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ彺"):
			l1llll11ll1l1_l1_ = l1l1111l1ll1_l1_
			l1llll11l1111_l1_ = l11lll_l1_ (u"࠭ࠨࠨ彻")+l1llll111111_l1_+l11lll_l1_ (u"ࠧࠡࠩ彼")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"ࠨࠫࠪ彽")
			l1lllll11llll_l1_ = l1ll1l11l111_l1_
	l1llllll1llll_l1_ = l1llllll1llll_l1_.strip(l11lll_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ彾"))
	l1lllll1l11l1_l1_ = l1lllll1l11l1_l1_.strip(l11lll_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠩ彿"))
	l1l11lll11_l1_  = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ往")+l1llll1lll11l_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ征")
	l1l11lll11_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ徂")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ徃")+l1llll1l1l1ll_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ径")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ待")+l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ徆")+l1lllll1l11l1_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徇")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ很")+l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ徉")+l1llllll1llll_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ徊")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭律")+l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ後")+l1lllll11llll_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ徍")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ徎")+l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ徏")+l1llll11l1111_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ徐")
	l1l1111l1ll1_l1_ = (l1llllll1ll1l_l1_ or l1lll1l1lllll_l1_)
	if l1l1111l1ll1_l1_:
		header = l11lll_l1_ (u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩ徑")
		l1l1l1lll1_l1_ = l11lll_l1_ (u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠩ徒")
	else:
		header = l11lll_l1_ (u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪ従")
		l1l1l1lll1_l1_ = l11lll_l1_ (u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬ徔")
	l1l1l1ll1l_l1_ = l11lll_l1_ (u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ徕")
	l1ll11llll_l1_ = l1l11lll11_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ徖")+l1l1l1lll1_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ得")+l1l1l1ll1l_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭徘"),header,l1ll11llll_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ徙"))
	return
def l1ll111lllll_l1_(l1ll_l1_=True,l1llll1111l1l_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ徚"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࡠࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ徛"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ徜"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭徝"))
	if l1ll_l1_:
		l1lll1lllllll_l1_()
		l1lllll11lll1_l1_()
	if l1llll1111l1l_l1_:
		l1l11llll11l_l1_(False)
		l1l1l111111l_l1_ = []
		l1lllll1ll1ll_l1_ = [l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ從"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ徟"),l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ徠"),l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭御")]
		for l1llll111l1ll_l1_ in l1lllll1ll1ll_l1_:
			succeeded,l1lllll1l11ll_l1_,l1llll111111_l1_ = l1lll1llll1ll_l1_(l1llll111l1ll_l1_,True,False)
			l1l1l111111l_l1_.append(succeeded)
		l1llll111l1l1_l1_(l1ll_l1_)
		l1l11111l11l_l1_ = l11lll_l1_ (u"ࠪࠫ徢") if all(l1l1l111111l_l1_) else l11lll_l1_ (u"ࠫ࠶࠭徣")
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡴࡴࡹ࠮࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩࠬ徤"),l1l11111l11l_l1_)
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩࡵࡵࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ徥"),str(now))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ徦"))
	return
def l1lllll11l111_l1_(l1llllll111ll_l1_=l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ徧"),l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ徨"))
	import json
	data = json.loads(l11111lll1l_l1_)
	l1lll1ll1l111_l1_ = data[l11lll_l1_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ復")][l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ循")]
	if kodi_version<19: l1lll1ll1l111_l1_ = l1lll1ll1l111_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ徫"))
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ徬"),l11lll_l1_ (u"ࠧࠨ徭"),l11lll_l1_ (u"ࠨࠩ微"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ徯"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨ徰")+l1lll1ll1l111_l1_+l11lll_l1_ (u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭徱")+l1llllll111ll_l1_+l11lll_l1_ (u"ࠬࠦฟࠢࠩ徲"))
		if l1ll11l111_l1_!=1: return False
	succeeded,l1lllll1l11ll_l1_,l1lll1ll1l1ll_l1_ = l1lll1llll1ll_l1_(l1llllll111ll_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ徳"),l11lll_l1_ (u"ࠧࠨ徴"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ徵"),l11lll_l1_ (u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫ徶"))
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧ德")+l1llllll111ll_l1_+l11lll_l1_ (u"ࠫࠧࢃࡽࠨ徸"))
		if l11lll_l1_ (u"ࠬࡕࡋࠨ徹") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭徺"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ徻"),l11lll_l1_ (u"ࠨࠩ徼"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ徽"),l11lll_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬ徾"))
	return succeeded
def l111ll1l11l_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11lll_l1_ (u"ࠫࠬ徿"): l1ll_l1_ = True
	#l1ll1l1ll111_l1_ = xbmc.getCondVisibility(l11lll_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ忀")+addon_id+l11lll_l1_ (u"࠭ࠩࠨ忁"))
	l111lllll11_l1_ = l1l1ll1ll1l1_l1_([addon_id])
	l111l11ll1l_l1_,l1ll1l1ll111_l1_ = l111lllll11_l1_[addon_id]
	if l1ll1l1ll111_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ忂"),l11lll_l1_ (u"ࠨࠩ心"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ忄"),l11lll_l1_ (u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬ必")+addon_id+l11lll_l1_ (u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧ忆"))
	else:
		succeeded = False
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ忇"),l11lll_l1_ (u"࠭ࠧ忈"),l11lll_l1_ (u"ࠧࠨ忉"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忊"),l11lll_l1_ (u"ࠩࠪ忋")+addon_id+l11lll_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨ忌"))
		if l1ll11l111_l1_==1:
			xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫ忍")+addon_id+l11lll_l1_ (u"ࠬ࠯ࠧ忎"))
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭忏"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11lll_l1_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ忐")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ忑")+addon_id+l11lll_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ忒"))
			if l11lll_l1_ (u"ࠪࡓࡐ࠭忓") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ忔"),l11lll_l1_ (u"ࠬ࠭忕"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ忖"),l11lll_l1_ (u"ࠧห็ࠣๅา฻ࠠฤ๊ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭志"))
			elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ忘"),l11lll_l1_ (u"ࠩࠪ忙"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭忚"),l11lll_l1_ (u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭忛"))
	return succeeded
def l1llll111ll1l_l1_(addon_id,l1l1111l1l11_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭応"),l11lll_l1_ (u"࠭ࠧ忝"),l11lll_l1_ (u"ࠧࠨ忞"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忟"),l11lll_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬ忠"))
		if l1ll11l111_l1_!=1: return False
	l1lll1ll111l1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111l1l11_l1_,{},l1ll_l1_)
	if l1lll1ll111l1_l1_:
		l1l111l11111_l1_ = os.path.join(l1ll1l111l_l1_,addon_id)
		l1ll11ll1l_l1_(l1l111l11111_l1_,True,False)
		import zipfile,io
		l1llll1l1l1l1_l1_ = io.BytesIO(l1lll1ll111l1_l1_)
		zf = zipfile.ZipFile(l1llll1l1l1l1_l1_)
		zf.extractall(l1ll1l111l_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ忡"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ忢")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ忣"))
		if l11lll_l1_ (u"࠭ࡏࡌࠩ忤") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ忥"),l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ忦"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ忧"),l11lll_l1_ (u"ࠪࠫ忨"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ忩"),l11lll_l1_ (u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ忪"))
		else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ快"),l11lll_l1_ (u"ࠧࠨ忬"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忭"),l11lll_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ忮"))
	return succeeded
def l1lll1llll1ll_l1_(addon_id,l1ll_l1_,l1lllll1lll1l_l1_):
	l1ll11l111_l1_,succeeded,l1lllll1l11ll_l1_,l1llll111111_l1_ = True,False,l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ忯"),l11lll_l1_ (u"ࠫࠬ忰")
	l1l111ll1l11_l1_ = l1ll1lll1l1l_l1_([addon_id])
	if addon_id in list(l1l111ll1l11_l1_.keys()):
		l1l1111l1ll1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l11l111_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1l11_l1_ = l1l111ll1l11_l1_[addon_id]
		if l11l11lllll_l1_==l11lll_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ忱"):
			succeeded,l1lllll1l11ll_l1_ = True,l11lll_l1_ (u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧ忲")
			if l1lllll1lll1l_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ忳"),l11lll_l1_ (u"ࠨࠩ忴"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ念"),l11lll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠไ๊า๎ࠥ๐ำหะา้ࠥษฮาࠢศูิอัࠡ็อ์ๆืࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠๅ้ำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ忶")+addon_id)
		else:
			if l1ll_l1_:
				if l11l11lllll_l1_==l11lll_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭忷"): message = l11lll_l1_ (u"๋ࠬส้ไไอࠬ忸")
				elif l11l11lllll_l1_==l11lll_l1_ (u"࠭࡯࡭ࡦࠪ忹"): message = l11lll_l1_ (u"ࠧใัํ้ฮ࠭忺")
				elif l11l11lllll_l1_==l11lll_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ忻"): message = l11lll_l1_ (u"ࠩ฽๎ึࠦๅฬสออࠬ忼")
				l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ忽"),l11lll_l1_ (u"ࠫࠬ忾"),l11lll_l1_ (u"ࠬ࠭忿"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怀"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭态")+message+l11lll_l1_ (u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪ怂")+addon_id)
			if not l1ll11l111_l1_: l1lllll1l11ll_l1_ = l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ怃")
			else:
				if l11l11lllll_l1_==l11lll_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ怄"):
					results = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ怅")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ怆"))
					if l11lll_l1_ (u"࠭ࡏࡌࠩ怇") in results:
						succeeded,l1lllll1l11ll_l1_ = True,l11lll_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨ怈")
						if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ怉"),l11lll_l1_ (u"ࠩࠪ怊"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭怋"),l11lll_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩ怌")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭怍"),l11lll_l1_ (u"࠭ࠧ怎"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ怏"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫ怐")+addon_id)
				elif l11l11lllll_l1_ in [l11lll_l1_ (u"ࠩࡲࡰࡩ࠭怑"),l11lll_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ怒")]:
					succeeded = l1llll111ll1l_l1_(addon_id,l1l1111l1l11_l1_,False)
					if succeeded:
						if l11l11lllll_l1_==l11lll_l1_ (u"ࠫࡴࡲࡤࠨ怓"): l1lllll1l11ll_l1_ = l11lll_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭怔")
						elif l11l11lllll_l1_==l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ怕"): l1lllll1l11ll_l1_ = l11lll_l1_ (u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪ怖")
						l1llll111111_l1_ = l1ll1l11l111_l1_
						if l1ll_l1_:
							if l1lllll1l11ll_l1_==l11lll_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩ怗"): DIALOG_OK(l11lll_l1_ (u"ࠩࠪ怘"),l11lll_l1_ (u"ࠪࠫ怙"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ怚"),l11lll_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ怛")+addon_id)
							elif l1lllll1l11ll_l1_==l11lll_l1_ (u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ怜"): DIALOG_OK(l11lll_l1_ (u"ࠧࠨ思"),l11lll_l1_ (u"ࠨࠩ怞"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ怟"),l11lll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫ怠")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ怡"),l11lll_l1_ (u"ࠬ࠭怢"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怣"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ怤")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ急"),l11lll_l1_ (u"ࠩࠪ怦"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭性"),l11lll_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦ็ั้ࠣห้หึศใฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨ怨")+addon_id)
	return succeeded,l1lllll1l11ll_l1_,l1llll111111_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ╇")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡊࡈ࠴ࡠࠩ╈")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1lllll1111_l1_-l1llll1l1ll_l1_.net
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/l111l1l111_l1_.l1lll11l1l1_l1_
# l1lll1l11l1_l1_	https://t.me/l1lll11l111_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯ࠭╉"),l11lll_l1_ (u"ࠬอสึๆࠣฬ๋อࠧ╊"),l11lll_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็หฺ๊๊ࠨ╋"),l11lll_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่ัี๊ะࠩ╌"),l11lll_l1_ (u"ࠨษํะ๏ࠦศิฬࠣห้ฮฯ๋ๆࠪ╍"),l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ╎"),l11lll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศิฬࠪ╏")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==800: results = MENU()
	elif mode==801: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==802: results = l1l11l_l1_(url)
	elif mode==803: results = PLAY(url)
	elif mode==804: results = l1lll11ll1l_l1_(url)
	elif mode==806: results = l1lllll111l_l1_(url,l1l11l1_l1_)
	elif mode==809: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ═"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ║"),l11lll_l1_ (u"࠭ࠧ╒"),809,l11lll_l1_ (u"ࠧࠨ╓"),l11lll_l1_ (u"ࠨࠩ╔"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭╕"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╖"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠩ╗"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ╘"),804,l11lll_l1_ (u"࠭ࠧ╙"),l11lll_l1_ (u"ࠧࠨ╚"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ╛"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ╜"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ╝"),l11lll_l1_ (u"ࠫࠬ╞"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ╟"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ╠"),l11lll_l1_ (u"ࠧࠨ╡"),l11lll_l1_ (u"ࠨࠩ╢"),l11lll_l1_ (u"ࠩࠪ╣"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ╤"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡳࡧࡶ࠮ࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ╥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ╦"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ╧"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ╨") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╩"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ╪")+l111ll_l1_+title,link,801)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ╫"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ╬"),l11lll_l1_ (u"ࠬ࠭╭"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ╮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭╯"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ╰"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ╱") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╲"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭╳")+l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠬ࠭╴"),l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࡱࡪࡴࡵࠨ╵"))
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╶"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ╷"),l11lll_l1_ (u"ࠩࠪ╸"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ╹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ╺"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ╻"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ╼") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╽"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ╾")+l111ll_l1_+title,link,801)
	return html
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪ╿")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ▀"),l11lll_l1_ (u"ࠫࠬ▁"),type,url)
	#if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ▂") in url: type = l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭▃")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ▄"),url,l11lll_l1_ (u"ࠨࠩ▅"),l11lll_l1_ (u"ࠩࠪ▆"),l11lll_l1_ (u"ࠪࠫ▇"),l11lll_l1_ (u"ࠫࠬ█"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ▉"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࡘ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫࡳࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠧ▊"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠧࠨ▋"),l11lll_l1_ (u"ࠨࠩ▌"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠩะ่็อสࠨ▍") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"้ࠪํอำๆࠩ▎") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭▏"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▐"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭░"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ▒"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ▓"),l111ll_l1_+title,link,803,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ▔"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ▕"),l111ll_l1_+title,link,803)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠫࠬ▖")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭▗"),l11lll_l1_ (u"࠭ࠧ▘"),l11lll_l1_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠧ▙"),url)
	limit,start,l11ll1ll1_l1_,select,l1lll1l1111_l1_ = 0,0,l11lll_l1_ (u"ࠨࠩ▚"),l11lll_l1_ (u"ࠩࠪ▛"),l11lll_l1_ (u"ࠪࠫ▜")
	if l11lll_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ▝") in type:
		# next l1l11l1_l1_
		l1lll1l1l11_l1_,l11ll1l11_l1_ = url.split(l11lll_l1_ (u"ࠬࡅ࡮ࡦࡺࡷࡁࡵࡧࡧࡦࠨࠪ▞"))
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ▟"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭■")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭□"),l1lll1l1l11_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ▢"),l11lll_l1_ (u"ࠪࠫ▣"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ▤"))
		html = response.content
		l11lll1l_l1_ = l11lll_l1_ (u"ࠬࡹࡥࡤࡅࡲࡲࡹ࡫࡮ࡵࠩ▥")+html+l11lll_l1_ (u"࠭࠼ࡧࡱࡲࡸࡪࡸ࠾ࠨ▦")
	else:
		# l11ll1l111_l1_ html
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ▧"),url,l11lll_l1_ (u"ࠨࠩ▨"),l11lll_l1_ (u"ࠩࠪ▩"),l11lll_l1_ (u"ࠪࠫ▪"),l11lll_l1_ (u"ࠫࠬ▫"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ▬"))
		html = response.content
		l11lll1l_l1_ = html
	items,l1llllll111_l1_,filters = [],False,False
	if not type and l11lll_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷࠬ▭") not in url:
		# l1llllll111_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ▮"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ▯"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ▰"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▱"),l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠫࠬ▲"),l11lll_l1_ (u"ࠬࡹࡵࡣ࡯ࡨࡲࡺ࠭△"))
				l1llllll111_l1_ = True
	if not l1llllll111_l1_:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡦࡥࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲࡈࡵ࡮ࡵࡧࡱࡸࠬ▴"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ▵"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				link = l111l_l1_(link)
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠨ࡞ࡱࠫ▶"))
				title = unescapeHTML(title)
				if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ▷") in link and type==l11lll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪ▸"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▹"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ►"))
				elif l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ▻") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▼"),l111ll_l1_+title,link,806,l1llll_l1_)
				elif l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ▽") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▾"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪ▿"))
				elif l11lll_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡵࠪ◀") in url: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◁"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"࠭ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠫ◂"))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭◃"),l111ll_l1_+title,link,803,l1llll_l1_)
		# l1lllll11ll_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡮ࡲࡥࡩࡓ࡯ࡳࡧࡓࡥࡷࡧ࡭ࡴࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾ࠫ◄"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			params = EVAL(l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ◅"),block)
			l1lll1l1111_l1_ = params[l11lll_l1_ (u"ࠪࡥ࡯ࡧࡸࡶࡴ࡯ࠫ◆")]
			l1lll111lll_l1_ = int(params[l11lll_l1_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡶࡡࡨࡧࠪ◇")])+1
			l1lll111ll1_l1_ = int(params[l11lll_l1_ (u"ࠬࡳࡡࡹࡡࡳࡥ࡬࡫ࠧ◈")])
			query = params[l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡷࠬ◉")].replace(l11lll_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭◊"),l11lll_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ○")).replace(l11lll_l1_ (u"ࠩࡗࡶࡺ࡫ࠧ◌"),l11lll_l1_ (u"ࠪࡸࡷࡻࡥࠨ◍")).replace(l11lll_l1_ (u"ࠫࡓࡵ࡮ࡦࠩ◎"),l11lll_l1_ (u"ࠬࡴࡵ࡭࡮ࠪ●"))
			if l1lll111lll_l1_<l1lll111ll1_l1_:
				l11ll1l11_l1_ = l11lll_l1_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡃ࡬ࡰࡣࡧࡱࡴࡸࡥࠧࡳࡸࡩࡷࡿ࠽ࠨ◐")+QUOTE(query,l11lll_l1_ (u"ࠧࠨ◑"))+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ◒")+str(l1lll111lll_l1_)
				l11l11l_l1_ = l1lll1l1111_l1_+l11lll_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ◓")+l11ll1l11_l1_
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◔"),l111ll_l1_+l11lll_l1_ (u"ࠫั๊ศࠡษ็้ื๐ฯࠨ◕"),l11l11l_l1_,801,l11lll_l1_ (u"ࠬ࠭◖"),l11lll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡢࠫ◗")+type)
		elif l11lll_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ◘") in url:
			l11ll1l11_l1_,l1ll11l1l_l1_ = l11ll1l11_l1_.rsplit(l11lll_l1_ (u"ࠨ࠿ࠪ◙"),1)
			l1ll11l1l_l1_ = int(l1ll11l1l_l1_)+1
			l11l11l_l1_ = l1lll1l1l11_l1_+l11lll_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ◚")+l11ll1l11_l1_+l11lll_l1_ (u"ࠪࡁࠬ◛")+str(l1ll11l1l_l1_)
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◜"),l111ll_l1_+l11lll_l1_ (u"ࠬาไษࠢสุ่๊๊ะࠩ◝"),l11l11l_l1_,801,l11lll_l1_ (u"࠭ࠧ◞"),l11lll_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࡣࠬ◟")+type)
	return
def l1lll11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ◠"),url,l11lll_l1_ (u"ࠩࠪ◡"),l11lll_l1_ (u"ࠪࠫ◢"),l11lll_l1_ (u"ࠫࠬ◣"),l11lll_l1_ (u"ࠬ࠭◤"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡈࡌࡐ࡙ࡋࡒࡔ࠯࠴ࡷࡹ࠭◥"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡷࡥࡣࡳࡧࡶࠩ࠰࠭ࡃ࠮ࡹࡥࡤࡅࡲࡲࡹ࡫࡮ࡵࠢࠪ◦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & options block
		l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡦࡹࡷࡸࡥ࡯ࡶࡢࡳࡵࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ◧"),block,re.DOTALL)
		for name,block in l111l11_l1_:
			if l11lll_l1_ (u"ࠩส่ฯ฻ๆ๋ใࠪ◨") in name: continue
			name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ◩"))
			# link & value
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ◪"),block,re.DOTALL)
			for link,value in items:
				title = name+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ◫")+value
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◬"),l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠧࠨ◭"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ◮"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭◯"),url,l11lll_l1_ (u"ࠪࠫ◰"),l11lll_l1_ (u"ࠫࠬ◱"),l11lll_l1_ (u"ࠬ࠭◲"),l11lll_l1_ (u"࠭ࠧ◳"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ◴"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ◵"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lllll1lll_l1_ = [],[]
	# l11l1ll1l_l1_ links
	l1lll1ll111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡅ࡮ࡤࡨࡨ࠳࠰࠿ࡱࡱࡶࡸࡂ࠮࠮ࠫࡁࠬࠦࠬ◶"),html,re.DOTALL)
	if l1lll1ll111_l1_:
		links = base64.b64decode(l1lll1ll111_l1_[0])
		if kodi_version>18.99: links = links.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ◷"))
		links = EVAL(l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ◸"),links)
		links = list(links.values())
		for link in links:
			if link not in l1lllll1lll_l1_:
				l1lllll1lll_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ◹"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ◺")+server+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ◻"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹࡊ࡯ࡸࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ◼"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡸࡷࡄ࠮ࠫࡁ࠿ࡸࡩࡄ࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬࠫࡠࡩࢁ࠳࠭࠶ࢀ࠭ࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ◽"),block,re.DOTALL)
		for l11l111l_l1_,link in items:
			if link not in l1lllll1lll_l1_:
				if l11lll_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ◾") in link: link = link.split(l11lll_l1_ (u"ࠫ࠴ࡅࡵࡳ࡮ࡀࠫ◿"))[1]
				l1lllll1lll_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ☀"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ☁")+server+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ☂")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ☃"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ☄"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠪࠤࠬ★"),l11lll_l1_ (u"ࠫ࠰࠭☆"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ☇")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭☈"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ歀")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ歁")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠫࠬ歂")
#headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ歃"):l11ll1_l1_ (u"࠭ࠧ歄")}
def MAIN(mode,url,text,type,l1l1111_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l1111l11_l1_(url)
	#elif mode==142: results = l1ll1l1llll11_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l1111_l1_)
	elif mode==145: results = l1ll1llll1lll_l1_(url)
	elif mode==146: results = l1ll1l1ll1ll1_l1_(url)
	elif mode==147: results = l1ll1lll111ll_l1_()
	elif mode==148: results = l1ll1lll11l1l_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡊ࠳࡙ࡥ࡛ࡏࡇ࡛ࡳࡻ࡮ࡅࡸࡒ࡙ࡷࡇࡨ࡝࡞࡛࡚ࡌࡑࡍࡽࡾࡵࡸࡸࡐࡕࠪ歅")
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ歆"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡗࡉࡘ࡚࡚ࠠࡑࡘࡘ࡚ࡈࡅࠨ歇"),url,144)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ歈"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡴࡲࡤࡦࡴࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࠥࡴ࡯ࡵࠢ࡯࡭ࡸࡺࡩ࡯ࡩࠣࡲࡪࡽࡥࡳࠢࡳࡰࡾࡧ࡬ࡪࡵࡷࠫ歉"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡊࡵࡷࡥ࡚ࡼ࡛࡞࡫ࡱࠦ࡭࡫ࡶࡸࡂࡘࡄࡒࡏ࠹࠷ࡻࡎࡪࡑ࠲࡫ࡩ࡙ࡹࠧ歊"),144)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭歋"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วา฼ࠪ歌"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡺࡏࡷࡱࡱ࡮࠹ࡍࡹࡰࡲࡐࡘࡒࡈࡡ࠳࠵ࡴ࡙ࡨࡽࠧ歍"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ歎"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ歏"),l11ll1_l1_ (u"ࠫࠬ歐"),149,l11ll1_l1_ (u"ࠬ࠭歑"),l11ll1_l1_ (u"࠭ࠧ歒"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ歓"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ歔"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ歕")+l11ll1_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ歖")+l11ll1_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ歗"),l11ll1_l1_ (u"ࠬ࠭歘"),290)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭歙"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ歚")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ歛"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ歜"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ歝"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭歞")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ歟"),l11l1l_l1_,144,l11ll1_l1_ (u"࠭ࠧ歠"),l11ll1_l1_ (u"ࠧࠨ歡"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ止"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ正"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ此")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ步"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭武"),146)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ歧"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ歨"),l11ll1_l1_ (u"ࠨࠩ歩"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ歪"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ歫")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ歬"),l11ll1_l1_ (u"ࠬ࠭歭"),147)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭歮"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ歯")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ歰"),l11ll1_l1_ (u"ࠩࠪ歱"),148)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ歲"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭歳")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ歴"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ歵"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歶"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ歷")+l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭歸"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ歹"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ歺"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ死")+l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ歼"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ歽"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ歾"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ歿")+l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ殀"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ殁"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殂"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ殃")+l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭殄"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ殅"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ殆"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ殇")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ殈"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ殉"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭殊"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ残")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭殌"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭殍"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ殎"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭殏")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไฺำสๆࠥิืษหࠣห้๋ัอ฻ํอࠬ殐"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎ࠷࡮࡚ࡷ࠶ࡱࡰࡊ࠷࠻ࡗࡪࡶ࡚ࡇ࡬ࡓࡴࡉ࡭ࡴ࡬ࡹࡿࡸ࡯ࡕࡈࡷࡱ࡫ࡸࠧ殑"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ殒"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ฼ำฬีวหࠢสฺฬ็ษࠡ์๋ฮ๏๎ศࠨ殓"),l11ll1_l1_ (u"ࠩࠪ殔"),144)
	#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ殕"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ殖"),l11ll1_l1_ (u"ࠬํะศࠢส่ฬิส๋ษิࠤุ๎แࠡ์ัีั้ࠠๆ่ࠣห้ฮั็ษ่ะࠬ殗"),l11ll1_l1_ (u"࠭ไฤ่๊ࠤุ๎แࠡ์ๅ์๊ࠦศหึ฽๎้ࠦศา่ส้ั๊้ࠦฬํ์อ࠭殘"))
	#if l1ll111lll_l1_==1:
	#	url = l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ殙")
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ殚"))
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡕࡩࡵࡲࡡࡤࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡹ࡭ࡩ࡫࡯ࡴ࠮ࠪ殛")+url+l11ll1_l1_ (u"ࠪ࠭ࠬ殜"))
	#	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡗࡻ࡮ࡂࡦࡧࡳࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ殝"))
	return
l11ll1_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡓࡁࡊࡐࡓࡅࡌࡋࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰ࠱ࡩࡣ࠭ࡦࡤࡸࡦࠦ࠽ࠡࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁࠩࡷࡵࡰ࠮ࠐࠉࡪࡨࠣࠫࡗ࡫ࡦࡢࡣࡷࠤࡆࡲ࠭ࡈࡣࡰࡱࡦࡲࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡽࡪࡹࠧࠪࠌࠌࡨࡩࠦ࠽ࠡࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠎࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡰࡤ࡫ࡪ࠮࡬ࡦࡰࠫࡨࡩ࠯ࠩ࠻ࠌࠌࠍ࡮ࡺࡥ࡮ࠢࡀࠤࡩࡪ࡛ࡪ࡟ࠍࠍࠎࡏࡎࡔࡇࡕࡘࡤࡏࡔࡆࡏࡢࡘࡔࡥࡍࡆࡐࡘࠬ࡮ࡺࡥ࡮ࠫࠍࠍࡎ࡚ࡅࡎࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ殞")
def l1ll1lll111ll_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭殟"))
	return
def l1ll1lll11l1l_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ殠"))
	return
def PLAY(url,type):
	#url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ殡")
	#items = re.findall(l11ll1_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ殢"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ殣")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ殤"))
	#return
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ殥")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1l1ll1ll1_l1_(url):
	html,cc,data = l1ll1ll1llll1_l1_(url)
	dd = cc[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ殦")][l11ll1_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殧")][l11ll1_l1_ (u"ࠨࡶࡤࡦࡸ࠭殨")]
	for l11ll1111l_l1_ in range(len(dd)):
		item = dd[l11ll1111l_l1_]
		l1ll1llll11l1_l1_(item,url,str(l11ll1111l_l1_))
	ee = dd[0][l11ll1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ殩")][l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ殪")][l11ll1_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殫")][l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ殬")]
	s = 0
	for l11ll1111l_l1_ in range(len(ee)):
		item = ee[l11ll1111l_l1_][l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ殭")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ殮")][0]
		if list(item[l11ll1_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ殯")][l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ殰")].keys())[0]==l11ll1_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ殱"): continue
		succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_ = l1ll1lllll1ll_l1_(item)
		if not title:
			s += 1
			title = l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭殲")+str(s)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ殳"),l111l1_l1_+title,url,144,l11ll1_l1_ (u"࠭ࠧ殴"),str(l11ll1111l_l1_))
	key = re.findall(l11ll1_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ段"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭殶")+key[0]
	html,cc,l11ll11l1_l1_ = l1ll1ll1llll1_l1_(l111lll_l1_)
	for l1ll1l11ll11_l1_ in range(3,4):
		dd = cc[l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ殷")][l1ll1l11ll11_l1_][l11ll1_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殸")][l11ll1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ殹")]
		for l11ll1111l_l1_ in range(len(dd)):
			item = dd[l11ll1111l_l1_]
			if l11ll1_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ殺") in str(item): continue
			l1ll1llll11l1_l1_(item)
	return
def ITEMS(url,data=l11ll1_l1_ (u"࠭ࠧ殻"),index=0):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ殼"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ殽"),l11ll1_l1_ (u"ࠩࠪ殾"))
	html,cc,l11ll11l1_l1_ = l1ll1ll1llll1_l1_(url,data)
	l1l111111l_l1_,ff = l11ll1_l1_ (u"ࠪࠫ殿"),l11ll1_l1_ (u"ࠫࠬ毀")
	#if l11ll1_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠫ毁") in html.lower(): DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ毂"),l11ll1_l1_ (u"ࠧࠨ毃"),l11ll1_l1_ (u"ࠨࡱࡺࡲࡪࡸࠠࡦࡺ࡬ࡷࡹ࠭毄"),l11ll1_l1_ (u"ࠩ࡬ࡲࠥ࡮ࡴ࡮࡮ࠪ毅"))
	owner = re.findall(l11ll1_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ毆"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ毇"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ毈"),html,re.DOTALL)
	if owner:
		l1l111111l_l1_ = l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ毉")+owner[0][0]+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ毊")
		l1lllll_l1_ = owner[0][1]
		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭毋") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		#if l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭毌") in url and l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭母") not in url and l11ll1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ毎") not in url and l11ll1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ每") not in url:
		if l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ毐") in url: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ毑"),l111l1_l1_+l1l111111l_l1_,l1lllll_l1_,144)
	#if cc==l11ll1_l1_ (u"ࠨࠩ毒"): l1ll1l1lll1ll_l1_(url,html) ; return
	l1ll1l1lll11l_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ毓"),l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ比"),l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ毕"),l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ毖"),l11ll1_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ毗"),l11ll1_l1_ (u"ࠧࡴࡵࡀࠫ毘"),l11ll1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ毙"),l11ll1_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ毚"),l11ll1_l1_ (u"ࠪࡦࡵࡃࠧ毛"),l11ll1_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ毜")]
	l1ll1l1ll1l11_l1_ = not any(value in url for value in l1ll1l1lll11l_l1_)
	if l1ll1l1ll1l11_l1_ and l1l111111l_l1_:
		l11l1l1l1_l1_ = l11ll1_l1_ (u"ࠬอไษฯฮࠫ毝")
		l1lll1l1l_l1_ = l11ll1_l1_ (u"࠭โ้ษษ้ࠥอไหึ฽๎้࠭毞")
		l11l1l11l_l1_ = l11ll1_l1_ (u"ࠧศๆไ๎ิ๐่่ษอࠫ毟")
		l1ll1l1ll1l1l_l1_ = l11ll1_l1_ (u"ࠨษ็ๆ๋๎วหࠩ毠")
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ毡"),l111l1_l1_+l1l111111l_l1_,url,9999)
		if l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧฮอฬࠤࠪ毢") in html: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毣"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠬ࠭毤"),l11ll1_l1_ (u"࠭ࠧ毥"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ毦"))
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ毧") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毨"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ毩"),144)
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ毪") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毫"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ毬"),144)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ毭") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毮"),l111l1_l1_+l1ll1l1ll1l1l_l1_,url+l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ毯"),144)
		if l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾࡙ࠧࡥࡢࡴࡦ࡬ࠧ࠭毰") in html: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毱"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠬ࠭毲"),l11ll1_l1_ (u"࠭ࠧ毳"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ毴"))
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ毵") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毶"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ毷"),144)
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ毸") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毹"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ毺"),144)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ毻") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毼"),l111l1_l1_+l1ll1l1ll1l1l_l1_,url+l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ毽"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ毾"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ毿"),l11ll1_l1_ (u"ࠬ࠭氀"),9999)
	if l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ氁") in url:
		dd = cc[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ氂")][l11ll1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ氃")][l11ll1_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ氄")][l11ll1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ氅")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭氆")]
		l1ll1l1ll11ll_l1_ = 0
		for i in range(len(dd)):
			if l11ll1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ氇") in list(dd[i].keys()):
				l1ll1l1ll11l1_l1_ = dd[i][l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ氈")]
				length = len(str(l1ll1l1ll11l1_l1_))
				if length>l1ll1l1ll11ll_l1_:
					l1ll1l1ll11ll_l1_ = length
					ff = l1ll1l1ll11l1_l1_
		if l1ll1l1ll11ll_l1_==0: return
	elif l11ll1_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ氉") in url or l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ氊") in url or l11ll1_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ氋") in url or l11ll1_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ氌") in url or l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ氍") in url or url==l11l1l_l1_:
		l1ll1ll11l1l1_l1_ = []
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ氎"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ氏"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ氐"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ民"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ氒"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠲࠷࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ氓"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ气"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰ࡚ࡥࡹࡩࡨࡏࡧࡻࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟ࠥ氕"))
		l1ll1l1lll111_l1_,ff = l1ll1l1llllll_l1_(cc,l11ll1_l1_ (u"࠭ࠧ氖"),l1ll1ll11l1l1_l1_)
	if not ff:
		try:
			dd = cc[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ気")][l11ll1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ氘")][l11ll1_l1_ (u"ࠩࡷࡥࡧࡹࠧ氙")]
			l1ll1lll1111_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ氚") in url or l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ氛") in url or l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ氜") in url
			l1ll1ll1111ll_l1_ = l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭氝") in html or l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ氞") in html or l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ氟") in html
			l1ll1ll1111l1_l1_ = l11ll1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ氠") in html or l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ氡") in html or l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ氢") in html
			if l1ll1lll1111_l1_ and (l1ll1ll1111ll_l1_ or l1ll1ll1111l1_l1_):
				for l11ll1111l_l1_ in range(len(dd)):
					if l11ll1_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ氣") not in list(dd[l11ll1111l_l1_].keys()): continue
					ee = dd[l11ll1111l_l1_][l11ll1_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ氤")]
					try: gg = ee[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ氥")][l11ll1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ氦")][l11ll1_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ氧")][l11ll1_l1_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ氨")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ氩")][l11ll1111l_l1_]
					except: gg = ee
					try: l1lllll_l1_ = gg[l11ll1_l1_ (u"ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ氪")][l11ll1_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ氫")][l11ll1_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ氬")][l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ氭")]
					except: continue
					if   l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ氮")		in l1lllll_l1_	and l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ氯")		in url: ee = dd[l11ll1111l_l1_] ; break
					elif l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ氰")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ氱")	in url: ee = dd[l11ll1111l_l1_] ; break
					elif l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ氲")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ氳")		in url: ee = dd[l11ll1111l_l1_] ; break
					else: ee = dd[0]
			elif l11ll1_l1_ (u"ࠨࡤࡳࡁࠬ水") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11ll1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ氵")][l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ氶")]
		except: pass
	if not ff: return
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氷"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ永"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ氹"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ氺"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ氻"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ氼"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ氽"))
	if l11ll1_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ氾") not in url: l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡻࡢࡎࡧࡱࡹࠬࡣ࡛ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩࡠࠦ氿"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ汀"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ汁"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ求"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ汃"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ汄"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ汅"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ汆"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ汇"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨࠥ汈"))
	l111l1ll111_l1_ = l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡶࠩๆ่่่ࠥศศ่ࠤฬ๊สี฼ํ่ࠬ汉"))
	l111l1ll11l_l1_ = l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡷࠪ็้ࠦวๅใํำ๏๎็ศฬࠪ汊"))
	l1ll1l1ll1lll_l1_ = l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡸ่๊ࠫࠠศๆๅ๊ํอสࠨ汋"))
	l11l1ll1lll1_l1_ = [l111l1ll111_l1_,l111l1ll11l_l1_,l1ll1l1ll1lll_l1_,l11ll1_l1_ (u"ࠫࡆࡲ࡬ࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ汌"),l11ll1_l1_ (u"ࠬࡇ࡬࡭ࠢࡹ࡭ࡩ࡫࡯ࡴࠩ汍"),l11ll1_l1_ (u"࠭ࡁ࡭࡮ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ汎")]
	l1ll1l1lll1l1_l1_,gg = l1ll1l1llllll_l1_(ff,index,l1ll1ll11l1l1_l1_)
	if l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ汏") in str(type(gg)) and any(value in str(gg[0]) for value in l11l1ll1lll1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll1ll11l1l1_l1_ = []
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ汐"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ汑"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ汒"))
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ汓"))		#4
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ汔"))		#7
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ汕"))		#6
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ汖"))		#5
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ汗"))
		l1ll1l1lll111_l1_,item = l1ll1l1llllll_l1_(gg,index2,l1ll1ll11l1l1_l1_)
		#if l1ll1l1lll111_l1_ not in [l11ll1_l1_ (u"ࠩ࠵ࠫ汘"),l11ll1_l1_ (u"ࠪ࠸ࠬ汙"),l11ll1_l1_ (u"ࠫ࠺࠭汚")]: l1ll1llll11l1_l1_(item)		# 2,4,7
		#else: l1ll1llll11l1_l1_(item,url,str(index2))
		l1ll1llll11l1_l1_(item,url,str(index2))
		if l1ll1l1lll111_l1_==l11ll1_l1_ (u"ࠬ࠺ࠧ汛"):
			try:
				hh = item[l11ll1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭汜")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ汝")][l11ll1_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ汞")][l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ江")]
				for l1ll1lll1111l_l1_ in range(len(hh)):
					l1ll1l1llll1l_l1_ = hh[l1ll1lll1111l_l1_]
					l1ll1llll11l1_l1_(l1ll1l1llll1l_l1_)
			except: pass
	l1ll1ll1l11l1_l1_ = False
	if l11ll1_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ池") not in url and l1ll1l1lll1l1_l1_==l11ll1_l1_ (u"ࠫ࠽࠭污"): l1ll1ll1l11l1_l1_ = True
	if l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ汢") in l11ll11l1_l1_: l1ll1lll1l1l1_l1_,key,l1ll1lllll1l1_l1_,l1ll1lll11l11_l1_,token,l1ll1ll1l1ll1_l1_ = l11ll11l1_l1_.split(l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ汣"))
	else: l1ll1lll1l1l1_l1_,key,l1ll1lllll1l1_l1_,l1ll1lll11l11_l1_,token,l1ll1ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠧࠨ汤"),l11ll1_l1_ (u"ࠨࠩ汥"),l11ll1_l1_ (u"ࠩࠪ汦"),l11ll1_l1_ (u"ࠪࠫ汧"),l11ll1_l1_ (u"ࠫࠬ汨"),l11ll1_l1_ (u"ࠬ࠭汩")
	l111lll_l1_,l1ll1l111ll_l1_ = l11ll1_l1_ (u"࠭ࠧ汪"),l11ll1_l1_ (u"ࠧࠨ汫")
	if menuItemsLIST:
		l1ll1ll11111l_l1_ = str(menuItemsLIST[-1][1])
		if   l111l1_l1_+l11ll1_l1_ (u"ࠨࡅࡋࡒࡑ࠭汬") in l1ll1ll11111l_l1_: l1ll1l111ll_l1_ = l11ll1_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ汭")
		elif l111l1_l1_+l11ll1_l1_ (u"࡙ࠪࡘࡋࡒࠨ汮") in l1ll1ll11111l_l1_: l1ll1l111ll_l1_ = l11ll1_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭汯")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠬࡒࡉࡔࡖࠪ汰") in l1ll1ll11111l_l1_: l1ll1l111ll_l1_ = l11ll1_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ汱")
	if l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ汲") in html and l11ll1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ汳") not in url and not l1ll1ll1l11l1_l1_ and l11ll1_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ汴") not in url:	# and (index!=l11ll1_l1_ (u"ࠪࠫ汵") or l11ll1_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ汶") in url or l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ汷") in url or l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭汸") in url or l11ll1_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭汹") in url):
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ決")+l1ll1lllll1l1_l1_
	elif l11ll1_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ汻") in html and l11ll1_l1_ (u"ࠪࡦࡵࡃࠧ汼") not in url and l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ汽") in url or l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ汾") in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ汿")+key
	elif l11ll1_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ沀") in html and l11ll1_l1_ (u"ࠨࡤࡳࡁࠬ沁") not in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭沂")+key
	if l111lll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ沃"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ沄"),l111lll_l1_,144,l1ll1l111ll_l1_,l11ll1_l1_ (u"ࠬ࠭沅"),l11ll11l1_l1_)
	return
def l1ll1l1llllll_l1_(l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l1ll1ll1l11ll_l1_):
	cc = l11ll11l1l1l_l1_
	ff,index = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	gg,index2 = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	item,render = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	count = len(l1ll1ll1l11ll_l1_)
	for l11ll1111l_l1_ in range(count):
		try:
			out = eval(l1ll1ll1l11ll_l1_[l11ll1111l_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"࠭ࠧ沆")
			return str(l11ll1111l_l1_+1),out
		except: pass
	return l11ll1_l1_ (u"ࠧࠨ沇"),l11ll1_l1_ (u"ࠨࠩ沈")
def l1ll1lllll1ll_l1_(item):
	try: l1ll1lll1lll1_l1_ = list(item.keys())[0]
	except: return False,l11ll1_l1_ (u"ࠩࠪ沉"),l11ll1_l1_ (u"ࠪࠫ沊"),l11ll1_l1_ (u"ࠫࠬ沋"),l11ll1_l1_ (u"ࠬ࠭沌"),l11ll1_l1_ (u"࠭ࠧ沍"),l11ll1_l1_ (u"ࠧࠨ沎"),l11ll1_l1_ (u"ࠨࠩ沏")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_ = False,l11ll1_l1_ (u"ࠩࠪ沐"),l11ll1_l1_ (u"ࠪࠫ沑"),l11ll1_l1_ (u"ࠫࠬ沒"),l11ll1_l1_ (u"ࠬ࠭沓"),l11ll1_l1_ (u"࠭ࠧ沔"),l11ll1_l1_ (u"ࠧࠨ沕"),l11ll1_l1_ (u"ࠨࠩ沖")
	#WRITE_THIS(l11ll1_l1_ (u"ࠩࠪ沗"),str(item))
	render = item[l1ll1lll1lll1_l1_]
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ沘"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ沙"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ沚"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ沛"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ沜"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ沝"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ沞"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ沟"))
	l1ll1l1lll111_l1_,title = l1ll1l1llllll_l1_(item,render,l1ll1ll11l1l1_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ沠"),l11ll1_l1_ (u"ࠬ࠭没"),l11ll1_l1_ (u"࠭ࠧ沢"),title)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ沣"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ沤"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ沥"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ沦")) # required for l11ll111l11l_l1_ l1ll1ll1l11l1_l1_
	l1ll1l1lll111_l1_,l1lllll_l1_ = l1ll1l1llllll_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ沧"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ沨"))
	l1ll1l1lll111_l1_,l1lll1_l1_ = l1ll1l1llllll_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ沩"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ沪"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ沫"))
	l1ll1l1lll111_l1_,count = l1ll1l1llllll_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ沬"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ沭"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ沮"))
	l1ll1l1lll111_l1_,l1l11lll1_l1_ = l1ll1l1llllll_l1_(item,render,l1ll1ll11l1l1_l1_)
	if l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ沯") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ沰"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ沱")
	if l11ll1_l1_ (u"ࠨ็หหูืࠧ沲") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll1ll1_l1_ = l11ll1_l1_ (u"ࠩࠪ河"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ沴")
	if l11ll1_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ沵") in list(render.keys()):
		l1ll1llll11ll_l1_ = str(render[l11ll1_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ沶")])
		if l11ll1_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭沷") in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠧࠥ࠼ࠪ沸")
		if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ油") in l1ll1llll11ll_l1_: l111lll1ll1_l1_ = l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ沺")
		if l11ll1_l1_ (u"ࠪࡆࡺࡿࠧ治") in l1ll1llll11ll_l1_ or l11ll1_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ沼") in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠬࠪࠤ࠻ࠩ沽")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡻࠧๆสสุึ࠭沾")) in l1ll1llll11ll_l1_: l111lll1ll1_l1_ = l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ沿")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡶࠩืีฬวࠧ泀")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠩࠧࠨ࠿࠭況")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡸࠫฬูสวฮสีࠬ泂")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠫࠩࠪ࠺ࠨ泃")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ泄")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"࠭ࠤ࠻ࠩ泅")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ泆") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠨࡁࠪ泇"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ泈") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ泉")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll1lllll_l1_: title = l1ll1ll1lllll_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠧ泊")+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠬ࠲ࠧ泋"),l11ll1_l1_ (u"࠭ࠧ泌"))
	count = count.replace(l11ll1_l1_ (u"ࠧ࠭ࠩ泍"),l11ll1_l1_ (u"ࠨࠩ泎"))
	count = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨ࠰࠭泏"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠪࠫ泐")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_
def l1ll1llll11l1_l1_(item,url=l11ll1_l1_ (u"ࠫࠬ泑"),index=l11ll1_l1_ (u"ࠬ࠭泒")):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_ = l1ll1lllll1ll_l1_(item)
	#if l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ泓") in url and index==l11ll1_l1_ (u"ࠧ࠱ࠩ泔"):
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ法"),l111l1_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭泖") in str(item): return	# l1ll1lllll1l1_l1_ not items
	elif l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ泗") in str(item): return			# l1ll1llll1111_l1_ not items
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ泘") in url: return			# separator l1ll1l1ll111l_l1_ list not items
	elif title and not l1lllll_l1_ and (l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ泙") in url or l11ll1_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭泚") in str(item) or url==l11l1l_l1_):
		title = l11ll1_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ泛")+title+l11ll1_l1_ (u"ࠨࠢࡀࡁࡂ࠭泜")
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ泝"),l111l1_l1_+title,l11ll1_l1_ (u"ࠪࠫ泞"),9999)
	elif title and l11ll1_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭泟") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ泠"),l111l1_l1_+title,l11ll1_l1_ (u"࠭ࠧ泡"),9999)
	elif l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ波") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ泣"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif not title: return
	elif l111lll1ll1_l1_: addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ泤"),l111l1_l1_+l111lll1ll1_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	#elif l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ泥") in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ泦") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠬࡺ࠽࠱ࠩ泧") not in l1lllll_l1_:
	#	l1ll1lll11111_l1_ = re.findall(l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ注"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ泩")+l1ll1lll11111_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ泪"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ泫")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ泬")+title,l1lllll_l1_,144,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭泭") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ泮") in l1lllll_l1_:
		if l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭泯") in l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ泰") not in l1lllll_l1_:
			l1ll1lll11111_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ泱"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ泲")+l1ll1lll11111_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ泳"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡑࡏࡓࡕࠩ泴")+count+l11ll1_l1_ (u"ࠬࡀࠠࠡࠩ泵")+title,l1lllll_l1_,144,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭泶"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭泷"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	else:
		type = l11ll1_l1_ (u"ࠨࠩ泸")
		if not l1lllll_l1_: l1lllll_l1_ = url
		#if l11ll1_l1_ (u"ࠩࡶࡷࡂ࠭泹") in l1lllll_l1_: l1lllll_l1_ = url
		#elif l11ll1_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭泺") in l1lllll_l1_: l1lllll_l1_ = url		# not needed it will stop l1ll1l1lllll1_l1_ l11ll111l11l_l1_ l1ll1ll1l11l1_l1_
		elif not any(value in l1lllll_l1_ for value in [l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ泻"),l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ泼"),l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ泽"),l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ泾"),l11ll1_l1_ (u"ࠨࡵࡶࡁࠬ泿"),l11ll1_l1_ (u"ࠩࡥࡴࡂ࠭洀")]):
			if l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭洁")	in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ洂") in l1lllll_l1_: type = l11ll1_l1_ (u"ࠬࡉࡈࡏࡎࠪ洃")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ洄")
			if l11ll1_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ洅") in l1lllll_l1_: type = l11ll1_l1_ (u"ࠨࡗࡖࡉࡗ࠭洆")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭洇")
			index,l1ll1lll1l111_l1_ = l11ll1_l1_ (u"ࠪࠫ洈"),l11ll1_l1_ (u"ࠫࠬ洉")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ洊"),l111l1_l1_+type+title,l1lllll_l1_,144,l1lll1_l1_,index)
	return
def l1ll1ll1llll1_l1_(url,data=l11ll1_l1_ (u"࠭ࠧ洋"),request=l11ll1_l1_ (u"ࠧࠨ洌")):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ洍"))
	#if l11ll1_l1_ (u"ࠩࡢࡣࠬ洎") in l1ll1lll1l111_l1_: l1ll1lll1l111_l1_ = l11ll1_l1_ (u"ࠪࠫ洏")
	#if l11ll1_l1_ (u"ࠫࡸࡹ࠽ࠨ洐") in url: url = url.split(l11ll1_l1_ (u"ࠬࡹࡳ࠾ࠩ洑"))[0]
	if request==l11ll1_l1_ (u"࠭ࠧ洒"): request = l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ洓")
	l111llll11_l1_ = l11llllll_l1_()
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ洔"):l111llll11_l1_,l11ll1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ洕"):l11ll1_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ洖")}
	#l1l1ll11l_l1_ = headers.copy()
	if l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ洗") in data: l1ll1lll1l1l1_l1_,key,l1ll1lllll1l1_l1_,l1ll1lll11l11_l1_,token,l1ll1ll1l1ll1_l1_ = data.split(l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ洘"))
	else: l1ll1lll1l1l1_l1_,key,l1ll1lllll1l1_l1_,l1ll1lll11l11_l1_,token,l1ll1ll1l1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ洙"),l11ll1_l1_ (u"ࠧࠨ洚"),l11ll1_l1_ (u"ࠨࠩ洛"),l11ll1_l1_ (u"ࠩࠪ洜"),l11ll1_l1_ (u"ࠪࠫ洝"),l11ll1_l1_ (u"ࠫࠬ洞")
	if l11ll1_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ洟") in url:
		l11ll11l1_l1_ = {}
		l11ll11l1_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ洠")] = {l11ll1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ洡"):{l11ll1_l1_ (u"ࠣࡪ࡯ࠦ洢"):l11ll1_l1_ (u"ࠤࡤࡶࠧ洣"),l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ洤"):l11ll1_l1_ (u"ࠦ࡜ࡋࡂࠣ津"),l11ll1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ洦"):l1ll1lll11l11_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ洧"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ洨"))
	elif l11ll1_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭洩") in url and l1ll1lll1l1l1_l1_:
		l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ洪"):token}
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ洫")] = {l11ll1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ洬"):{l11ll1_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ洭"):l1ll1lll1l1l1_l1_,l11ll1_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ洮"):l11ll1_l1_ (u"ࠢࡘࡇࡅࠦ洯"),l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ洰"):l1ll1lll11l11_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ洱"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ洲"))
	elif l11ll1_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ洳") in url and l1ll1ll1l1ll1_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭洴"):l11ll1_l1_ (u"࠭࠱ࠨ洵"),l11ll1_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ洶"):l1ll1lll11l11_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ洷"):l11ll1_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ洸")+l1ll1ll1l1ll1_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ洹"),url,l11ll1_l1_ (u"ࠫࠬ洺"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠬ࠭活"),l11ll1_l1_ (u"࠭ࠧ洼"),l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ洽"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ派"),url,l11ll1_l1_ (u"ࠩࠪ洿"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠪࠫ浀"),l11ll1_l1_ (u"ࠫࠬ流"),l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ浂"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭浃"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭浄"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll11l11_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ浅"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ浆"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll1l1l1_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ浇"),html,re.DOTALL|re.I)
	if tmp: l1ll1lllll1l1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ浈") in list(cookies.keys()): l1ll1ll1l1ll1_l1_ = cookies[l11ll1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ浉")]
	data = l1ll1lll1l1l1_l1_+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ浊")+key+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ测")+l1ll1lllll1l1_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ浌")+l1ll1lll11l11_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭浍")+token+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ济")+l1ll1ll1l1ll1_l1_
	if request==l11ll1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ浏") and l11ll1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ浐") in html:
		l111lll111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ浑"),html,re.DOTALL)
		if not l111lll111_l1_: l111lll111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ浒"),html,re.DOTALL)
		l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ浓"),l111lll111_l1_[0])
	elif request==l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ浔") and l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ浕") in html:
		l111lll111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ浖"),html,re.DOTALL)
		l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ浗"),l111lll111_l1_[0])
	elif l11ll1_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ浘") not in html: l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ浙"),html)
	else: l1ll1ll11l1ll_l1_ = l11ll1_l1_ (u"ࠨࠩ浚")
	#open(l11ll1_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭浛"),l11ll1_l1_ (u"ࠪࡻࠬ浜")).write(str(l1ll1ll11l1ll_l1_))
	#open(l11ll1_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ浝"),l11ll1_l1_ (u"ࠬࡽࠧ浞")).write(html)
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ浟"),data)
	return html,l1ll1ll11l1ll_l1_,data
def l1ll1llll1lll_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ浠"),l11ll1_l1_ (u"ࠨ࠭ࠪ浡"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ浢")+search
	ITEMS(l111lll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ浣"),l11ll1_l1_ (u"ࠫ࠰࠭浤"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ浥")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ浦") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ浧")
		elif l11ll1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ浨") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ浩")
		elif l11ll1_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ浪") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ浫")
		l11l111_l1_ = l111lll_l1_+l1ll1ll1ll111_l1_
	else:
		l1ll1ll1l1lll_l1_,l1ll1ll111lll_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠬ࠭浬")
		l1ll1ll11l11l_l1_ = [l11ll1_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ浭"),l11ll1_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭浮"),l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ浯"),l11ll1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ浰"),l11ll1_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ浱")]
		l1ll1lll1llll_l1_ = [l11ll1_l1_ (u"ࠫࠬ浲"),l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ浳"),l11ll1_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ浴"),l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭浵"),l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ浶")]
		l1ll1llll1l11_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ海"),l1ll1ll11l11l_l1_)
		if l1ll1llll1l11_l1_ == -1: return
		l1ll1ll1l1l1l_l1_ = l1ll1lll1llll_l1_[l1ll1llll1l11_l1_]
		html,c,data = l1ll1ll1llll1_l1_(l111lll_l1_+l1ll1ll1l1l1l_l1_)
		if c:
			d = c[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ浸")][l11ll1_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ浹")][l11ll1_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ浺")][l11ll1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ浻")][l11ll1_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ浼")][l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ浽")][l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ浾")]
			for l1ll1ll111ll1_l1_ in range(len(d)):
				group = d[l1ll1ll111ll1_l1_][l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ浿")][l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ涀")]
				for l1ll1lllll111_l1_ in range(len(group)):
					render = group[l1ll1lllll111_l1_][l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ涁")]
					if l11ll1_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ涂") in list(render.keys()):
						l1lllll_l1_ = render[l11ll1_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ涃")][l11ll1_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ涄")][l11ll1_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ涅")][l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ涆")]
						l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ涇"),l11ll1_l1_ (u"ࠬࠬࠧ消"))
						title = render[l11ll1_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ涉")]
						title = title.replace(l11ll1_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ涊"),l11ll1_l1_ (u"ࠨࠩ涋"))
						if l11ll1_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ涌") in title: continue
						if l11ll1_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ涍") in title:
							title = l11ll1_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ涎")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠨ涏") in title: continue
						title = title.replace(l11ll1_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ涐"),l11ll1_l1_ (u"ࠧࠨ涑"))
						if l11ll1_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ涒") in title: continue
						if l11ll1_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ涓") in title:
							title = l11ll1_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ涔")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ涕") in title: continue
						l1ll1ll1l1lll_l1_.append(escapeUNICODE(title))
						l1ll1ll111lll_l1_.append(l1lllll_l1_)
		if not l1lll1l1l_l1_: l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠬ࠭涖")
		else:
			l1ll1ll1l1lll_l1_ = [l11ll1_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ涗"),l1lll1l1l_l1_]+l1ll1ll1l1lll_l1_
			l1ll1ll111lll_l1_ = [l11ll1_l1_ (u"ࠧࠨ涘"),l1lllll11l_l1_]+l1ll1ll111lll_l1_
			l1ll1llll1ll1_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭涙"),l1ll1ll1l1lll_l1_)
			if l1ll1llll1ll1_l1_ == -1: return
			l1ll1lll1ll11_l1_ = l1ll1ll111lll_l1_[l1ll1llll1ll1_l1_]
		if l1ll1lll1ll11_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1lll1ll11_l1_
		elif l1ll1ll1l1l1l_l1_: l11l111_l1_ = l111lll_l1_+l1ll1ll1l1l1l_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡓࡧࡰࡳࡻ࡫ࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠩ࠯ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬ࡯ࡳࡶࠣࡦࡾ࠭ࠬࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠦࠧࠨ涚")
	ITEMS(l11l111_l1_)
	return
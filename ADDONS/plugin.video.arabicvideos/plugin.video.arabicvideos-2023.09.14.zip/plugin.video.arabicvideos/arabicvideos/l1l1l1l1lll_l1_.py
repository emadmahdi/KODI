# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭み")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡋࡕࡍࡢࠫむ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨめ"),l11ll1_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨも"),l11ll1_l1_ (u"ࠨษ็ว็ูวๆࠩゃ")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l11111_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l1llll1_l1_(url,text)
	elif mode==674: results = l1l111_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭や"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫゅ"),l11ll1_l1_ (u"ࠫࠬゆ"),l11ll1_l1_ (u"ࠬ࠭ょ"),l11ll1_l1_ (u"࠭ࠧよ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫら"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨり"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩる"),l11ll1_l1_ (u"ࠪࠫれ"),679,l11ll1_l1_ (u"ࠫࠬろ"),l11ll1_l1_ (u"ࠬ࠭ゎ"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪわ"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬゐ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨゑ"),l11ll1_l1_ (u"ࠩࠪを"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪん"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ゔ")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭ゕ"),l11l1l_l1_,671,l11ll1_l1_ (u"࠭ࠧゖ"),l11ll1_l1_ (u"ࠧࠨ゗"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ゘"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ゙ࠩ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ゚ࠬ")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ゛"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠬ࠭゜"),l11ll1_l1_ (u"࠭ࠧゝ"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ゞ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨゟ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ゠")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩァ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠫࠬア"),l11ll1_l1_ (u"ࠬ࠭ィ"),l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪイ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧゥ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪウ")+l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭ェ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠪࠫエ"),l11ll1_l1_ (u"ࠫࠬォ"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧオ"))
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫカ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧガ"),l11ll1_l1_ (u"ࠨࠩキ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪギ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬク"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if title==l11ll1_l1_ (u"ࠫฬ๊รใีส้ࠬグ"): mode = 675
		else: mode = 674
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬケ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨゲ")+l111l1_l1_+title,l1lllll_l1_,mode)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬコ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨゴ"),l11ll1_l1_ (u"ࠩࠪサ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧザ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤシ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠬ࠭ジ"))
	#items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫス"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧズ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪセ")+l111l1_l1_+title,l1lllll_l1_,674)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧゼ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪソ"),l11ll1_l1_ (u"ࠫࠬゾ"),9999)
	items = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡨࡲࡰࡹࡶࡩ࠳࡮ࡴ࡮࡮ࠪタ"))
	for l1lllll_l1_,l1lll1_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ダ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩチ")+l111l1_l1_+title,l1lllll_l1_,674,l1lll1_l1_)
	return
def CATEGORIES(url):
	l1ll1l111l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭ヂ"),l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫッ"),l11ll1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧツ"))
	if l1ll1l111l_l1_: return l1ll1l111l_l1_
	#DIALOG_OK()
	l1ll1l111l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨヅ"),url,l11ll1_l1_ (u"ࠬ࠭テ"),l11ll1_l1_ (u"࠭ࠧデ"),l11ll1_l1_ (u"ࠧࠨト"),l11ll1_l1_ (u"ࠨࠩド"),l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸࠬナ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡨࡦࡣࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࡃ࠭ニ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1ll1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨヌ"),block,re.DOTALL)
		if l1ll1l111l_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧネ"),l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪノ"),l1ll1l111l_l1_,l1llllll_l1_)
	return l1ll1l111l_l1_
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫハ"),url,l11ll1_l1_ (u"ࠨࠩバ"),l11ll1_l1_ (u"ࠩࠪパ"),l11ll1_l1_ (u"ࠪࠫヒ"),l11ll1_l1_ (u"ࠫࠬビ"),l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬピ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪフ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨブ"),l11ll1_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧプ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヘ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠪࠫベ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩペ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪホ"),l11ll1_l1_ (u"࠭ࠧボ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬポ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣࠫマ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩミ"),l111l1_l1_+title,l1lllll_l1_,671)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧム"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭メ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪモ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ャ"),l11ll1_l1_ (u"ࠧࠨヤ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨュ"),l111l1_l1_+title,l1lllll_l1_,671)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠩࠪユ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫョ"),l11ll1_l1_ (u"ࠫࠬヨ"),request,url)
	if request==l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪラ"):
		url,search = url.split(l11ll1_l1_ (u"࠭࠿ࠨリ"),1)
		data = l11ll1_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ル")+search
		headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧレ"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩロ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨヮ"),url,data,headers,l11ll1_l1_ (u"ࠫࠬワ"),l11ll1_l1_ (u"ࠬ࠭ヰ"),l11ll1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬヱ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫヲ"),url,l11ll1_l1_ (u"ࠨࠩン"),l11ll1_l1_ (u"ࠩࠪヴ"),l11ll1_l1_ (u"ࠪࠫヵ"),l11ll1_l1_ (u"ࠫࠬヶ"),l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫヷ"))
	html = response.content
	block,items = l11ll1_l1_ (u"࠭ࠧヸ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫヹ"))
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ヺ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ・"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠪࠫー"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ヽ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヾ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬヿ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㄀"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ㄁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㄂"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㄃"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭㄄"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧㄅ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"࠭ࠧㄆ"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨㄇ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩㄈ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩㄉ"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨㄊ"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪㄋ"),l11ll1_l1_ (u"้ࠬไ๋สࠪㄌ"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬㄍ"),l11ll1_l1_ (u"่ࠧัสๅࠬㄎ"),l11ll1_l1_ (u"ࠨ็หหึอษࠨㄏ"),l11ll1_l1_ (u"ࠩ฼ี฻࠭ㄐ"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪㄑ"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪㄒ"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬㄓ"),l11ll1_l1_ (u"࠭แๅ็ࠪㄔ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩㄕ"))
		#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ㄖ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫㄗ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬㄘ"))
		#if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩㄙ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧㄚ")+l1lll1_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨㄛ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩㄜ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫㄝ"),title,re.DOTALL)
		#addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㄞ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄟ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪㄠ"):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄡ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬㄢ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄣ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ㄤ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄥ"),l111l1_l1_+title,l1lllll_l1_,671,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄦ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄧ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㄨ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"࠭ࠣࠨㄩ"): continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬㄪ") not in l1lllll_l1_:
				l111lll_l1_ = url.rsplit(l11ll1_l1_ (u"ࠨ࠱ࠪㄫ"),1)[0]
				l1lllll_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫㄬ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬㄭ"))
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄮ"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫㄯ")+title,l1lllll_l1_,671,l11ll1_l1_ (u"࠭ࠧ㄰"),l11ll1_l1_ (u"ࠧࠨㄱ"),request)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㄲ"),l11ll1_l1_ (u"ࠩࠪㄳ"),l1l1l_l1_,url)
	addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄴ"),l111l1_l1_+l11ll1_l1_ (u"ࠫฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫㄵ"),url,672)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪㄶ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ㄷ"),l11ll1_l1_ (u"ࠧࠨㄸ"),9999)
	l1ll1l111l_l1_ = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡤࡵࡳࡼࡹࡥ࠯ࡪࡷࡱࡱ࠭ㄹ"))
	l1l1l1l1ll1_l1_,l1l1l1l1l1l_l1_,l1l1l1lll11_l1_ = zip(*l1ll1l111l_l1_)
	l1l1l1ll111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ㄺ"),url,l11ll1_l1_ (u"ࠪࠫㄻ"),l11ll1_l1_ (u"ࠫࠬㄼ"),l11ll1_l1_ (u"ࠬ࠭ㄽ"),l11ll1_l1_ (u"࠭ࠧㄾ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨㄿ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡪࡨࡥࡩ࡯࡮ࡨࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦࠬㅀ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡽࡇࡻࡴࡵࡱࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡥࡂ࠭࠴ࠪࡀࠫ࠿ࠫㅁ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1l1l1l1ll1_l1_:
				item = (l1lllll_l1_,title)
				l1l1l1ll111_l1_.append(item)
		if len(l1l1l1ll111_l1_)==1:
			l1lllll_l1_,title = l1l1l1ll111_l1_[0]
			l11111_l1_(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㅂ"))
			return
		else:
			for l1lllll_l1_,title in l1l1l1ll111_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅃ"),l111l1_l1_+title,l1lllll_l1_,671,l11ll1_l1_ (u"ࠬ࠭ㅄ"),l11ll1_l1_ (u"࠭ࠧㅅ"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ㅆ"))
	if not l1l1l1ll111_l1_: l11111_l1_(url,l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㅇ"))
	return
#https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l11ll11lll_l1_.l1ll1lll1l_l1_?l1l1l1ll1ll_l1_=l1l1l1ll1l1_l1_
#https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1ll_l1_=l1l1l1ll1l1_l1_
def PLAY(url):
	l1llll11_l1_ = []
	#url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫࠳ๆ๐ไๆ࠯ๆีฯ๎ๆ࠮สสีอ๐࠭โ์࠰้฿อๅาห࠰้ฯ๊รๅศฬ࠱๊ีศࡠࡦ࠼࠻࠺ࡩࡢ࠸࠷࠶࠲࡭ࡺ࡭࡭ࠩㅈ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧㅉ"),url,l11ll1_l1_ (u"ࠫࠬㅊ"),l11ll1_l1_ (u"ࠬ࠭ㅋ"),l11ll1_l1_ (u"࠭ࠧㅌ"),l11ll1_l1_ (u"ࠧࠨㅍ"),l11ll1_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬㅎ"))
	html = response.content
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪࡨ࡯ࡥࡸ࡮ࡰ࡭ࡣࡼࡩࡷ࠭ㅏ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㅐ"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࡤࡥࠧㅑ")+l111llll_l1_
			l1llll11_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅒ"),html,re.DOTALL)
	if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡦࡪ࡮ࡨ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨㅓ"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬㅔ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧㅕ")+l1lllll_l1_
		l1llll11_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪㅖ"))
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨㅗ"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪㅘ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ㅙ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧㅚ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩㅛ"),l11ll1_l1_ (u"ࠨ࠭ࠪㅜ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩㅝ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪㅞ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨㅟ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪㅠ"))
	return
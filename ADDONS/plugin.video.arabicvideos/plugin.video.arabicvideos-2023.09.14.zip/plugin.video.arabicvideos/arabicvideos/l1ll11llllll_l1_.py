# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ䴜")
headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䴝"):l11ll1_l1_ (u"ࠩࠪ䴞")}
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩ䴟")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ䴠"),l11ll1_l1_ (u"ࠬࡽࡷࡦࠩ䴡")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11111_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llll1l_l1_(url,text)
	elif mode==364: results = l1lll111_l1_(url,l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭䴢")+text)
	elif mode==365: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ䴣")+text)
	elif mode==366: results = l1l111_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䴤"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䴥"),l11ll1_l1_ (u"ࠪࠫ䴦"),False,l11ll1_l1_ (u"ࠫࠬ䴧"),l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䴨"))
	#hostname = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䴩")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ䴪"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䴫")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䴬"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䴭"),l11ll1_l1_ (u"ࠫࠬ䴮"),l11ll1_l1_ (u"ࠬ࠭䴯"),l11ll1_l1_ (u"࠭ࠧ䴰"),l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䴱"))
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䴲"),l111l1_l1_+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䴳"),l11ll1_l1_ (u"ࠪࠫ䴴"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䴵"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䴶"),l11ll1_l1_ (u"࠭ࠧ䴷"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴸"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䴹"),l11l1l_l1_,369,l11ll1_l1_ (u"ࠩࠪ䴺"),l11ll1_l1_ (u"ࠪࠫ䴻"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䴼"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴽"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䴾"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䴿"),364)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵀"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ䵁"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䵂"),365)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䵃"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䵄"),l11ll1_l1_ (u"࠭ࠧ䵅"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䵆"):hostname,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䵇"):l11ll1_l1_ (u"ࠩࠪ䵈")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭䵉"),l11ll1_l1_ (u"ࠫ࠴࠭䵊"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ䵋"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䵌"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ䵍") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵎"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䵏")+l111l1_l1_+title,l1lllll_l1_,366)
	#	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䵐"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䵑"),l11ll1_l1_ (u"ࠬ࠭䵒"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ䵓"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ䵔"),l11ll1_l1_ (u"ࠨࠩ䵕"),l11ll1_l1_ (u"ࠩࠪ䵖"),l11ll1_l1_ (u"ࠪࠫ䵗"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䵘"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䵙"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䵚"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ䵛") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ䵜"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠩࠪ䵝"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵞"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䵟")+l111l1_l1_+title,l1lllll_l1_,366)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䵠"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䵡"),l11ll1_l1_ (u"ࠧࠨ䵢"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ䵣"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䵤"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵥"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䵦")+l111l1_l1_+title,l1lllll_l1_,366,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䵧"),l11ll1_l1_ (u"࠭ࠧ䵨"),url,l11ll1_l1_ (u"ࠧࠨ䵩"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䵪"):url,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䵫"):l11ll1_l1_ (u"ࠪࠫ䵬")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䵭"),url,l11ll1_l1_ (u"ࠬ࠭䵮"),l11ll1_l1_ (u"࠭ࠧ䵯"),l11ll1_l1_ (u"ࠧࠨ䵰"),l11ll1_l1_ (u"ࠨࠩ䵱"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䵲"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵳"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䵴"),url,364)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䵵"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䵶"),url,365)
	if l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ䵷") in html:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵸"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊๋๊ำหࠪ䵹"),url,361,l11ll1_l1_ (u"ࠪࠫ䵺"),l11ll1_l1_ (u"ࠫࠬ䵻"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䵼"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䵽"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䵾"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵿"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l11111_l1_(l1ll1l1l1ll1_l1_,type=l11ll1_l1_ (u"ࠩࠪ䶀")):
	if l11ll1_l1_ (u"ࠪ࠾࠿࠭䶁") in l1ll1l1l1ll1_l1_:
		l11l111_l1_,url = l1ll1l1l1ll1_l1_.split(l11ll1_l1_ (u"ࠫ࠿ࡀࠧ䶂"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ䶃"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l1ll1_l1_,l1ll1l1l1ll1_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䶄"):l11l111_l1_,l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䶅"):l11ll1_l1_ (u"ࠨࠩ䶆")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䶇"),url,l11ll1_l1_ (u"ࠪࠫ䶈"),l11ll1_l1_ (u"ࠫࠬ䶉"),l11ll1_l1_ (u"ࠬ࠭䶊"),l11ll1_l1_ (u"࠭ࠧ䶋"),l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䶌"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䶍"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭䶎"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䶏"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠫࡡࡢ࠯ࠨ䶐"),l11ll1_l1_ (u"ࠬ࠵ࠧ䶑")).replace(l11ll1_l1_ (u"࠭࡜࡝ࠤࠪ䶒"),l11ll1_l1_ (u"ࠧࠣࠩ䶓"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡎࡻࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䶔"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ䶕"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠣࠫ䶖"),l11ll1_l1_ (u"ࠫࠬ䶗"))
			if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䶘") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䶙"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠧฮๆๅอࠬ䶚") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ䶛"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䶜") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶝"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䶞"),l111l1_l1_+title,l1lllll_l1_,362,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䶟"):
			l1ll1l111ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ䶠"),block,re.DOTALL)
			if l1ll1l111ll_l1_:
				count = l1ll1l111ll_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ䶡")+count
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶢"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ䶣"),l1lllll_l1_,361,l11ll1_l1_ (u"ࠪࠫ䶤"),l11ll1_l1_ (u"ࠫࠬ䶥"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䶦"))
		elif type==l11ll1_l1_ (u"࠭ࠧ䶧"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䶨"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䶩"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ䶪")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶫"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"ࠫࠬ䶬")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䶭"),url,l11ll1_l1_ (u"࠭ࠧ䶮"),l11ll1_l1_ (u"ࠧࠨ䶯"),l11ll1_l1_ (u"ࠨࠩ䶰"),l11ll1_l1_ (u"ࠩࠪ䶱"),l11ll1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䶲"))
	html = response.content
	html = l1111_l1_(html)
	name = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ䶳"),html,re.DOTALL)
	if name: name = name[-1].replace(l11ll1_l1_ (u"ࠬ࠳ࠧ䶴"),l11ll1_l1_ (u"࠭ࠠࠨ䶵")).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ䶶"))
	if l11ll1_l1_ (u"ࠨ็๋ื๊࠭䶷") in name and type==l11ll1_l1_ (u"ࠩࠪ䶸"):
		name = name.split(l11ll1_l1_ (u"้ࠪํูๅࠨ䶹"))[0]
		name = name.replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ䶺"),l11ll1_l1_ (u"ࠬ࠭䶻")).strip(l11ll1_l1_ (u"࠭ࠠࠨ䶼"))
	elif l11ll1_l1_ (u"ࠧฮๆๅอࠬ䶽") in name:
		name = name.split(l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭䶾"))[0]
		name = name.replace(l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩ䶿"),l11ll1_l1_ (u"ࠪࠫ䷀")).strip(l11ll1_l1_ (u"ࠫࠥ࠭䷁"))
	else: name = name
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࠩ䷂"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if type==l11ll1_l1_ (u"࠭ࠧ䷃"):
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ䷄"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ䷅") in title: continue
				if l11ll1_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ䷆") in title: continue
				title = name+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧ䷇")+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷈"),l111l1_l1_+title,l1lllll_l1_,363,l11ll1_l1_ (u"ࠬ࠭䷉"),l11ll1_l1_ (u"࠭ࠧ䷊"),l11ll1_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䷋"))
		if len(menuItemsLIST)==0:
			l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䷌"),block+l11ll1_l1_ (u"ࠩࠩࠪࠬ䷍"),re.DOTALL)
			if l111l_l1_: block = l111l_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䷎"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭䷏"))
				title = name+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ䷐")+title
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䷑"),l111l1_l1_+title,l1lllll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䷒"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭䷓"),l11ll1_l1_ (u"ࠩࠪ䷔")).replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠣࠫ䷕"),l11ll1_l1_ (u"ࠫࠬ䷖"))
		else: title = l11ll1_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ䷗")
		addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䷘"),l111l1_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䷙"),url,l11ll1_l1_ (u"ࠨࠩ䷚"),l11ll1_l1_ (u"ࠩࠪ䷛"),l11ll1_l1_ (u"ࠪࠫ䷜"),l11ll1_l1_ (u"ࠫࠬ䷝"),l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䷞"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䷟"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭䷠"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䷡"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䷢") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ࠪื๏ืแา่ࠢห๏ࠦำ๋็สࠫ䷣"): name = l11ll1_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ䷤")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䷥")+name+l11ll1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䷦")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䷧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䷨"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䷩") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ䷪"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ䷫")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠬ࠭䷬")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡭ࡺࡥ࡬ࡱࡦ࠭䷭")+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䷮")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䷯"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䷰"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠪࠫ䷱")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ䷲"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭䷳"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ䷴"),l11ll1_l1_ (u"ࠧࠬࠩ䷵"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ䷶"),l11ll1_l1_ (u"ࠩ࠲ࠫ䷷"),l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ䷸"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ䷹"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ䷺")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"࠭วๅๅ็ࠫ䷻"),l11ll1_l1_ (u"ࠧศๆฦๅ้อๅࠨ䷼"),l11ll1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ䷽"),l11ll1_l1_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭䷾"),l11ll1_l1_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ䷿")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ一"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11ll1_l1_ (u"ࠬ࠭丁"):
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ丂"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ七"),l11ll1_l1_ (u"ࠨࠩ丄"),False,l11ll1_l1_ (u"ࠩࠪ丅"),l11ll1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ丆"))
		hostname = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭万")]
		hostname = hostname.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ丈"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ三")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l1ll1_l1_,filter):
	if l11ll1_l1_ (u"ࠧࡀࡁࠪ上") in l1ll1l1l1ll1_l1_: url = l1ll1l1l1ll1_l1_.split(l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ下"))[0]
	else: url = l1ll1l1l1ll1_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ丌"):l1ll1l1l1ll1_l1_,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ不"):l11ll1_l1_ (u"ࠫࠬ与")}
	filter = filter.replace(l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ丏"),l11ll1_l1_ (u"࠭ࠧ丐"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ丑"),1)
	if filter==l11ll1_l1_ (u"ࠨࠩ丒"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠩࠪ专"),l11ll1_l1_ (u"ࠪࠫ且")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ丕"))
	if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ世"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"࠭࠽࠾ࠩ丗") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ丘") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ丙")+category+l11ll1_l1_ (u"ࠩࡀࡁ࠵࠭业")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭丛")+category+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ东")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ丝"))+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ丞")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ丟"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ丠"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ両")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ丢"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭丣"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠬ࠭两"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ严"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠧࠨ並"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ丧")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1ll1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ丨"),l111l1_l1_+l11ll1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭丩"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠫࠬ个"),l11ll1_l1_ (u"ࠬ࠭丫"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ丬"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ中"),l111l1_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ丮")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ丯"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠪࠫ丰"),l11ll1_l1_ (u"ࠫࠬ丱"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭串"))
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ丳"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ临"),l11ll1_l1_ (u"ࠨࠩ丵"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭丶"),url,l11ll1_l1_ (u"ࠪࠫ丷"),l11ll1_l1_ (u"ࠫࠬ丸"),l11ll1_l1_ (u"ࠬ࠭丹"),l11ll1_l1_ (u"࠭ࠧ为"),l11ll1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ主"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠦࠬ丼"),l11ll1_l1_ (u"ࠩࠥࠫ丽")).replace(l11ll1_l1_ (u"ࠪࡠࡡ࠵ࠧ举"),l11ll1_l1_ (u"ࠫ࠴࠭丿"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂ࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ乀"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ乁"),block+l11ll1_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ乂"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ乃") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ乄"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠪࡁࡂ࠭久") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ乆"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ乇")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1ll1_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭么"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠧ义"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠨࠩ乊"),l11ll1_l1_ (u"ࠩࠪ之"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ乌"))
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ乍"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬ乎"),l111lll_l1_,364,l11ll1_l1_ (u"࠭ࠧ乏"),l11ll1_l1_ (u"ࠧࠨ乐"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ乑"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ乒")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ乓")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ乔")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ乕")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ乖")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乗"),l111l1_l1_+name+l11ll1_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ乘"),l111lll_l1_,365,l11ll1_l1_ (u"ࠩࠪ乙"),l11ll1_l1_ (u"ࠪࠫ乚"),l1l11lll_l1_+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭乛"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠬࡸࠧ乜") or value==l11ll1_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ九"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ乞") in option: continue
			if l11ll1_l1_ (u"ࠨษ็็้࠭也") in option: continue
			if l11ll1_l1_ (u"ࠩࡱ࠱ࡦ࠭习") in value: continue
			#if value in [l11ll1_l1_ (u"ࠪࡶࠬ乡"),l11ll1_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ乢"),l11ll1_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ乣")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ乤"): option = value
			if option==l11ll1_l1_ (u"ࠧࠨ乥"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭书"),option,re.DOTALL)
			if l1l1ll111l1_l1_: l11l1l1l1_l1_ = l1l1ll111l1_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠩ࠽ࠤࠬ乧")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭乨")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃࠧ乩")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ乪")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠾ࠩ乫")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ乬")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ乭"):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乮"),l111l1_l1_+l1lll1l1l_l1_,url,365,l11ll1_l1_ (u"ࠪࠫ乯"),l11ll1_l1_ (u"ࠫࠬ买"),l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ乱"))
			elif type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ乲") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ乳") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ乴"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ乵"),l11ll1_l1_ (u"ࠪࠫ乶"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ乷")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l1ll1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乸"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,361,l11ll1_l1_ (u"࠭ࠧ乹"),l11ll1_l1_ (u"ࠧࠨ乺"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ乻"))
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乼"),l111l1_l1_+l1lll1l1l_l1_,url,364,l11ll1_l1_ (u"ࠪࠫ乽"),l11ll1_l1_ (u"ࠫࠬ乾"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ乿"),l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ亀"),l11ll1_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ亁")]
l1l111111_l1_ = [l11ll1_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭亂"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ亃"),l11ll1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ亄"),l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭亅"),l11ll1_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭了"),l11ll1_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ亇"),l11ll1_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ予"),l11ll1_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ争")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ亊") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ事"),l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ二"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ亍"),l11ll1_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ于"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠾࠿ࠪ亏"),l11ll1_l1_ (u"ࠨ࠱ࠪ亐"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩࠩࠪࠬ云"),l11ll1_l1_ (u"ࠪ࠳ࠬ互"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ亓"),l11ll1_l1_ (u"ࠬ࠭五"),filters,l11ll1_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭井")+mode)
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ亖")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ亗")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭亘")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠪࠪࠫ࠭亙"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠫࠬ亚")
	if l11ll1_l1_ (u"ࠬࡃ࠽ࠨ些") in filters:
		items = filters.split(l11ll1_l1_ (u"࠭ࠦࠧࠩ亜"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠧ࠾࠿ࠪ亝"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠨ࠲ࠪ亞")
		if l11ll1_l1_ (u"ࠩࠨࠫ亟") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ亠") and value!=l11ll1_l1_ (u"ࠫ࠵࠭亡"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ亢")+value
		elif mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ亣") and value!=l11ll1_l1_ (u"ࠧ࠱ࠩ交"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ亥")+key+l11ll1_l1_ (u"ࠩࡀࡁࠬ亦")+value
		elif mode==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ产"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ亨")+key+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ亩")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠬࠢࠪ亪"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ享"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ京"),l11ll1_l1_ (u"ࠩࠪ亭"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠪࡓ࡚࡚ࠧ亮"))
	return l1ll11ll_l1_
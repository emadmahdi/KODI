# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭ࡔࡆࡕࡗࠫ數"),l11ll1_l1_ (u"ࠧࡕࡇࡖࡘࠬ敹"))
#url = l11ll1_l1_ (u"ࠨࡅ࠽ࡠࡡࡖ࡯ࡳࡶࡤࡦࡱ࡫ࠠࡑࡴࡲ࡫ࡷࡧ࡭ࡴ࡞࡟ࡏࡔࡊࡉࡠࡸ࠴࠼ࡤ࠼࠴ࡣ࡫ࡷࡠࡡࡑ࡯ࡥ࡫࡟ࡠࡵࡵࡲࡵࡣࡥࡰࡪࡥࡤࡢࡶࡤࡠࡡࡩࡡࡤࡪࡨࡠࡡࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࡟ࡠ࡫࡯࡬ࡦࡡ࠳࠼࠾࠼࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧ敺")
#url = l11ll1_l1_ (u"ࠩࡦ࠾ࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ敻")
#url = l11ll1_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ敼")
#url = l11ll1_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ敽")
url = l11ll1_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜โฯุ࠲ࡲࡶ࠳ࠨ敾")
url = l11ll1_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡨ࡬ࡰࡪࡥ࠴࠹࠵࠷ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫ敿")
#url = url.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ斀"))
xbmc.Player().play(url)
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᝓ")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧ᝔")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ᝕")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l11111_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l1llll1l_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ᝖"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ᝗"),l11ll1_l1_ (u"ࠬ࠭᝘"),l11ll1_l1_ (u"࠭ࠧ᝙"),l11ll1_l1_ (u"ࠧࠨ᝚"),l11ll1_l1_ (u"ࠨࠩ᝛"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᝜"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ᝝"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᝞"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ᝟"),l11ll1_l1_ (u"࠭ࠧᝠ"),559,l11ll1_l1_ (u"ࠧࠨᝡ"),l11ll1_l1_ (u"ࠨࠩᝢ"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᝣ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᝤ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᝥ"),l11ll1_l1_ (u"ࠬ࠭ᝦ"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝧ"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะอี๋อࠠๅๅࠪᝨ"),l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᝩ"),551,l11ll1_l1_ (u"ࠩࠪᝪ"),l11ll1_l1_ (u"ࠪࠫᝫ"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᝬ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᝭"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᝮ"),block,re.DOTALL)
	for l1lll1l1l1_l1_,title in items:
		l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭ᝯ")+l1lll1l1l1_l1_+l11ll1_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩᝰ")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᝱"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᝲ")+l111l1_l1_+title,l1lllll_l1_,551)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᝳ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᝴"),l11ll1_l1_ (u"࠭ࠧ᝵"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨ᝶"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᝷"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠩࠦࠫ᝸"): continue
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ุ้๊ࠪำๅࠢࠪ᝹") in title: continue
		if l11ll1_l1_ (u"ࠫศำฯฬࠩ᝺") in title: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᝻"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᝼")+l111l1_l1_+title,l1lllll_l1_,551)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᝽"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᝾"),l11ll1_l1_ (u"ࠩࠪ᝿"),9999)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠪࠧࠬក"): continue
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ู๊ࠫไิๆࠣࠫខ") in title: continue
		if l11ll1_l1_ (u"ࠬษอะอࠪគ") not in title: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឃ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩង")+l111l1_l1_+title,l1lllll_l1_,551)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠨࠩច")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪឆ"),l11ll1_l1_ (u"ࠪࠫជ"),url)
	items = []
	# l1lll11lll_l1_ l1lll1l111_l1_
	if l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫឈ") in url or l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ញ") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬដ"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧឋ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ឌ"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪឍ"),l11ll1_l1_ (u"ࠪࠫណ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪត"))
		html = response.content
		l1l1l11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩថ"),url,l11ll1_l1_ (u"࠭ࠧទ"),l11ll1_l1_ (u"ࠧࠨធ"),l11ll1_l1_ (u"ࠨࠩន"),l11ll1_l1_ (u"ࠩࠪប"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩផ"))
		html = response.content
		# l1lll1l1l1_l1_ items
		if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ព"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬភ"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬម"),block,re.DOTALL)
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨយ"),l11ll1_l1_ (u"ࠨࠩរ"),l11ll1_l1_ (u"ࠩࠪល"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠪវ") in html:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ឝ"),html,re.DOTALL)
		else:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪឞ"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items:
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨស"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ហ"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨឡ"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧអ"),l11ll1_l1_ (u"ࠪห฿์๊สࠩឣ"),l11ll1_l1_ (u"่๊๊ࠫษࠩឤ"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫឥ"),l11ll1_l1_ (u"࠭็ะษไࠫឦ"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧឧ"),l11ll1_l1_ (u"ࠨ฻ิฺࠬឨ"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩឩ"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩឪ")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭ឫ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨឬ"),title,re.DOTALL)
		if l11ll1_l1_ (u"࠭ำๅษึ่ࠬឭ") not in url and any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ឮ"),l111l1_l1_+title,l1lllll_l1_,552,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠨษ็ั้่ษࠨឯ") in title:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨឰ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឱ"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ឲ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឳ"),l111l1_l1_+title,l1lllll_l1_,551,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭឴"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠧࠨ឵"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬា"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫិ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠥࠦី"): continue
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠫࠬឹ"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឺ"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬុ")+title,l1lllll_l1_,551)
	if l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧូ") in url or l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩួ") in url:
		if l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩើ") in url:
			url = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪឿ"),l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬៀ"))+l11ll1_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃ࠲࠱ࠩេ")
		elif l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧែ") in url:
			url,offset = url.split(l11ll1_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩៃ"))
			offset = int(offset)+20
			url = url+l11ll1_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪោ")+str(offset)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩៅ"),l111l1_l1_+l11ll1_l1_ (u"๋๋ࠪอใࠡษ็้ื๐ฯࠨំ"),url,551)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨះ"),url,l11ll1_l1_ (u"ࠬ࠭ៈ"),l11ll1_l1_ (u"࠭ࠧ៉"),l11ll1_l1_ (u"ࠧࠨ៊"),l11ll1_l1_ (u"ࠨࠩ់"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ៌"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࡃࡻࡖࡩࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ៍"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡲࡩࡴࡶ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ៎"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ៏") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ័"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ៑"),l111l1_l1_+title,l1lllll_l1_,553,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ្ࠧ"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៓"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#title = title.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭។"),l11ll1_l1_ (u"ࠫࠬ៕")).strip(l11ll1_l1_ (u"ࠬࠦࠧ៖"))
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬៗ"),l111l1_l1_+title,l1lllll_l1_,552,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ៘"),l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ៙"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭៚"),l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭៛"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨៜ"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭៝"),l11ll1_l1_ (u"࠭ࠧ៞"),l11ll1_l1_ (u"ࠧࠨ៟"),l11ll1_l1_ (u"ࠨࠩ០"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭១"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ២"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ៣"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៤"),html,re.DOTALL)
		l11lll11_l1_ = l11lll11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ៥"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ៦"),l11ll1_l1_ (u"ࠨࠩ៧")).strip(l11ll1_l1_ (u"ࠩࠣࠫ៨"))
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭៩")+server+l11ll1_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭៪")+l11lll11_l1_+l11ll1_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭៫")
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៬")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ៭")
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡆࡾࡔࡡ࡮ࡧ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࡞ࠥࡷࡪࡸࡶࡦࡴ࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ៮"),block,re.DOTALL)
			for server,l1lll11l1l_l1_,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ៯"),l11ll1_l1_ (u"ࠪࠫ៰")).strip(l11ll1_l1_ (u"ࠫࠥ࠭៱"))
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸࡂࡺࡐࡤࡱࡪࡅࡳࡦࡴࡹࡩࡷࡃࠧ៲")+server+l11ll1_l1_ (u"࠭ࠦ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࡕࡨࡶࡻ࡫ࡲࡴ࠿ࠪ៳")+l1lll11l1l_l1_+l11ll1_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩ៴")+l11lll11_l1_+l11ll1_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ៵")
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ៶")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ៷")
				l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ៸"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៹"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៺")+name+l11ll1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ៻")
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭៼") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ៽")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ៾"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ៿"),url)
	return
l11ll1_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡖࡌࡂ࡛ࡢࡓࡑࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࡥࡣࡷࡥࠥࡃࠠࡼ࡙ࠩ࡭ࡪࡽࠧ࠻࠳ࢀࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ࠽ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪࢁࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡑࡑࡖࡘࠬ࠲ࡵࡳ࡮࠯ࡨࡦࡺࡡ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢࠐࠉࠤࠢࡺࡥࡹࡩࡨࠡ࡮࡬ࡲࡰࡹࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡸࡣࡷࡧ࡭ࡇࡲࡦࡣࡐࡥࡸࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡨࡦࡺࡡ࠮࡮࡬ࡲࡰࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠨࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡ࡮࡬ࡲࡰࡹࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡥࡱࡱࡻࡱࡵࡡࡥ࠯ࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡷࡪࡸ࠭࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨ࠰ࡶࡻࡡ࡭࡫ࡷࡽ࠱ࡲࡩ࡯࡭ࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ࠰࠭࡟ࡠࡡࡢࠫ࠰ࡷࡵࡢ࡮࡬ࡸࡾࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࡪࡨࠣࡰࡪࡴࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࡀࡁ࠵ࡀࠠࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࠬࠨษ็ีฬฮืࠡๆํืࠥ็๊่ࠢไ๎ิ๐่ࠨࠫࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࠌࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠬࠨࡸ࡬ࡨࡪࡵࠧ࠭ࡷࡵࡰ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠣࠤࠥ᠀")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧ᠁"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ᠂"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ᠃"),l11ll1_l1_ (u"ࠩ࠰ࠫ᠄"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ᠅")+search+l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ᠆")
	l11111_l1_(url)
	return
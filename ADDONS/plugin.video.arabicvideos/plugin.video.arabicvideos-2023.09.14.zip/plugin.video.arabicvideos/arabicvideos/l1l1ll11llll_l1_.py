# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭昄")
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ昅"):l11ll1_l1_ (u"ࠨࠩ昆")}
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢ࡛ࡈࡓ࡟ࠨ昇")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ昈"),l11ll1_l1_ (u"ࠫࡼࡽࡥࠨ昉")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11111_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llll1l_l1_(url,text)
	elif mode==564: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ昊")+text)
	elif mode==565: results = l1lll111_l1_(url,l11ll1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ昋")+text)
	elif mode==566: results = l1l111_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ昌"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ昍"),l11ll1_l1_ (u"ࠩࠪ明"),False,l11ll1_l1_ (u"ࠪࠫ昏"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭昐"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ昑")]
	#hostname = hostname.strip(l11ll1_l1_ (u"࠭࠯ࠨ昒"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ易")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ昔"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ昕"),l11ll1_l1_ (u"ࠪࠫ昖"),l11ll1_l1_ (u"ࠫࠬ昗"),l11ll1_l1_ (u"ࠬ࠭昘"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ昙"))
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ昚"),l111l1_l1_+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋ีอࠠศๆ่์็฿ࠠๆ฼็ๆࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭昛"),l11ll1_l1_ (u"ࠩࠪ昜"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ昝"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ昞"),l11ll1_l1_ (u"ࠬ࠭星"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭映"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ昡"),l11l1l_l1_,569,l11ll1_l1_ (u"ࠨࠩ昢"),l11ll1_l1_ (u"ࠩࠪ昣"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ昤"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ春"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ昦"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭昧"),564)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ昨"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ昩"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ昪"),565)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ昫"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ昬"),l11ll1_l1_ (u"ࠬ࠭昭"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ昮"):hostname,l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ是"):l11ll1_l1_ (u"ࠨࠩ昰")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠩ࡟࠳ࠬ昱"),l11ll1_l1_ (u"ࠪ࠳ࠬ昲"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࡥࡥࡷ࠮࠮ࠫࡁࠬࡪ࡮ࡲࡴࡦࡴࠪ昳"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ昴"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"࠭ࠥࡥ࠻ࠨ࠼࠺ࠫࡤ࠹ࠧࡥ࠹ࠪࡪ࠸ࠦࡣ࠺ࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡢ࠺ࠧࡧ࠼ࠪࡧ࠹࠮ࠧࡧ࠼ࠪࡧࡤࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡥ࠾࠭昵") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ昶"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ昷")+l111l1_l1_+title,l1lllll_l1_,566)
	#	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ昸"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ昹"),l11ll1_l1_ (u"ࠫࠬ昺"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ昻"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ昼"),l11ll1_l1_ (u"ࠧࠨ昽"),l11ll1_l1_ (u"ࠨࠩ显"),l11ll1_l1_ (u"ࠩࠪ昿"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ晀"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡳࡍ࡫ࡶࡸࡇࡻࡴࡵࡱࡱࠦࠬ晁"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ時"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ晃") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ晄"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠨࠩ晅"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晆"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ晇")+l111l1_l1_+title,l1lllll_l1_,566)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ晈"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ晉"),l11ll1_l1_ (u"࠭ࠧ晊"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠮࠮ࠫࡁࠬ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠩ晋"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ晌"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晍"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ晎")+l111l1_l1_+title,l1lllll_l1_,566,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ晏"),l11ll1_l1_ (u"ࠬ࠭晐"),url,l11ll1_l1_ (u"࠭ࠧ晑"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ晒"):url,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ晓"):l11ll1_l1_ (u"ࠩࠪ晔")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ晕"),url,l11ll1_l1_ (u"ࠫࠬ晖"),l11ll1_l1_ (u"ࠬ࠭晗"),l11ll1_l1_ (u"࠭ࠧ晘"),l11ll1_l1_ (u"ࠧࠨ晙"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭晚"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晛"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭晜"),url,564)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ晝"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ晞"),url,565)
	if l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠭晟") in html:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ晠"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩ晡"),url,561,l11ll1_l1_ (u"ࠩࠪ晢"),l11ll1_l1_ (u"ࠪࠫ晣"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭晤"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭晥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ晦"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ晧"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l11111_l1_(l1ll1l1l1ll1_l1_,type=l11ll1_l1_ (u"ࠨࠩ晨")):
	if l11ll1_l1_ (u"ࠩ࠽࠾ࠬ晩") in l1ll1l1l1ll1_l1_:
		l11l111_l1_,url = l1ll1l1l1ll1_l1_.split(l11ll1_l1_ (u"ࠪ࠾࠿࠭晪"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ晫"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l1ll1_l1_,l1ll1l1l1ll1_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭晬"):l11l111_l1_,l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ晭"):l11ll1_l1_ (u"ࠧࠨ普")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ景"),url,l11ll1_l1_ (u"ࠩࠪ晰"),l11ll1_l1_ (u"ࠪࠫ晱"),l11ll1_l1_ (u"ࠫࠬ晲"),l11ll1_l1_ (u"ࠬ࠭晳"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ晴"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ晵"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ晶"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ晷"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠪࡠࡡ࠵ࠧ晸"),l11ll1_l1_ (u"ࠫ࠴࠭晹")).replace(l11ll1_l1_ (u"ࠬࡢ࡜ࠣࠩ智"),l11ll1_l1_ (u"࠭ࠢࠨ晻"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡈࡴ࡬ࡨ࠲࠳ࡗࡦࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ晼"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ晽"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ุ่ࠩฬํฯสࠢࠪ晾"),l11ll1_l1_ (u"ࠪࠫ晿"))
			if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭暀") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ暁"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			elif l11ll1_l1_ (u"࠭อๅไฬࠫ暂") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ暃"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ暄") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ暅"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ暆"),l111l1_l1_+title,l1lllll_l1_,562,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ暇"):
			l1ll1l111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ暈"),block,re.DOTALL)
			if l1ll1l111ll_l1_:
				count = l1ll1l111ll_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ暉")+count
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ暊"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ暋"),l1lllll_l1_,561,l11ll1_l1_ (u"ࠩࠪ暌"),l11ll1_l1_ (u"ࠪࠫ暍"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ暎"))
		elif type==l11ll1_l1_ (u"ࠬ࠭暏"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ暐"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭暑"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ࠨืไัฮࠦࠧ暒")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ暓"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"ࠪࠫ暔")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ暕"),l11ll1_l1_ (u"ࠬ࠭暖"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ暗"),url,l11ll1_l1_ (u"ࠧࠨ暘"),l11ll1_l1_ (u"ࠨࠩ暙"),l11ll1_l1_ (u"ࠩࠪ暚"),l11ll1_l1_ (u"ࠪࠫ暛"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ暜"))
	html = response.content
	html = l1111_l1_(html)
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥ࡭ࡹ࡫࡭ࠣࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠤࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࡝࠰࠵ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠯ࠪ࠰ࠬࠦࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩ࠲ࠫ࠮ࠐࠉࡪࡨ๊ࠣࠫ๎ำๆࠩࠣ࡭ࡳࠦ࡮ࡢ࡯ࡨࠤࡦࡴࡤࠡࡰࡲࡸࠥࡺࡹࡱࡧ࠽ࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡸࡶ࡬ࡪࡶ๊ࠫࠫ๎ำๆࠩࠬ࡟࠵ࡣࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡳࡧࡳࡰࡦࡩࡥุ่ࠩࠩฬํฯสࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎ࡫࡬ࡪࡨࠣࠫา๊โสࠩࠣ࡭ࡳࠦ࡮ࡢ࡯ࡨ࠾ࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡹࡰ࡭࡫ࡷࠬࠬำไใหࠪ࠭ࡠ࠶࡝ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡴࡨࡴࡱࡧࡣࡦู้ࠪࠪอ็ะหࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠢࠣࠤ暝")
	# l1lll1l_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ暞"),html,re.DOTALL)
	if not type and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ暟"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬ暠")+title
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ暡"),l111l1_l1_+title,l1lllll_l1_,563,l11ll1_l1_ (u"ࠪࠫ暢"),l11ll1_l1_ (u"ࠫࠬ暣"),l11ll1_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ暤"))
			return
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࠯ࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡩ࡯ࡩ࡯ࡩࡸ࡫ࡣࡵ࡫ࡲࡲࡸࡄࠧ暥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ暦"),block)
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠩ暧"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ暨"),str(items))
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ暩"))
			#title = name+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ暪")+title
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ暫"),l111l1_l1_+title,l1lllll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11ll1_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭暬"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠧࠡ࠯้ࠣฬ๐ࠠิ์่หࠬ暭"),l11ll1_l1_ (u"ࠨࠩ暮")).replace(l11ll1_l1_ (u"ุ่ࠩฬํฯสࠢࠪ暯"),l11ll1_l1_ (u"ࠪࠫ暰"))
		else: title = l11ll1_l1_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ暱")
		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ暲"),l111l1_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ暳"),url,l11ll1_l1_ (u"ࠧࠨ暴"),l11ll1_l1_ (u"ࠨࠩ暵"),l11ll1_l1_ (u"ࠩࠪ暶"),l11ll1_l1_ (u"ࠪࠫ暷"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭暸"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂฬ๊สึ่ํๅࡁ࠴ࠪࡀ࠾ࡤ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ暹"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡋ࡭ࡣࡧࡧࠦࠬ暺"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ暻"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭暼") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ࠩึ๎ึ็ั๊ࠡํࠤุ๐ๅศࠩ暽"): name = l11ll1_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ暾")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ暿")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭曀")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ曁"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ曂"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭曃") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ曄"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ曅")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠫࠬ曆")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡽࡥࡤ࡫ࡰࡥࠬ曇")+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ曈")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ曉"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ曊"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠩࠪ曋")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ曌"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ曍"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ曎"),l11ll1_l1_ (u"࠭ࠫࠨ曏"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠧ࠰ࠩ曐"),l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ曑"),l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ曒"),l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ曓"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ曔")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"ࠬษแๅษ่ࠫ曕"),l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠧ曖"),l11ll1_l1_ (u"ࠧฤ่ํ้๏่ࠦไำอ์๋࠭曗"),l11ll1_l1_ (u"ࠨสิห๊าࠠหๆํๅื๐่็ࠩ曘"),l11ll1_l1_ (u"่ࠩืู้ไศฬࠣ์ศ์๊ๆ์ࠪ曙")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็๊ํ฿ࠠศๆ่฻้๎ศ࠻ࠩ曚"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l1l_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ曛"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭曜"),l11ll1_l1_ (u"࠭ࠧ曝"),False,l11ll1_l1_ (u"ࠧࠨ曞"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ曟"))
		#hostname = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ曠")]
		#hostname = response.url
		#hostname = hostname.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ曡"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭曢")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l1ll1_l1_,filter):
	if l11ll1_l1_ (u"ࠬࡅ࠿ࠨ曣") in l1ll1l1l1ll1_l1_: url = l1ll1l1l1ll1_l1_.split(l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ曤"))[0]
	else: url = l1ll1l1l1ll1_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ曥"):l1ll1l1l1ll1_l1_,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ曦"):l11ll1_l1_ (u"ࠩࠪ曧")}
	filter = filter.replace(l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ曨"),l11ll1_l1_ (u"ࠫࠬ曩"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ曪"),1)
	if filter==l11ll1_l1_ (u"࠭ࠧ曫"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠧࠨ曬"),l11ll1_l1_ (u"ࠨࠩ曭")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭曮"))
	if type==l11ll1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ曯"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"ࠫࡂࡃࠧ曰") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ曱") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ曲")+category+l11ll1_l1_ (u"ࠧ࠾࠿࠳ࠫ曳")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ更")+category+l11ll1_l1_ (u"ࠩࡀࡁ࠵࠭曵")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠫ࠭曶"))+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ曷")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ書"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ曹"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭曺")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ曻"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ曼"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠪࠫ曽"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ曾"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠬ࠭替"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ最")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1ll1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ朁"),l111l1_l1_+l11ll1_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ朂"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠩࠪ會"),l11ll1_l1_ (u"ࠪࠫ朄"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ朅"))
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朆"),l111l1_l1_+l11ll1_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭朇")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭月"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠨࠩ有"),l11ll1_l1_ (u"ࠩࠪ朊"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ朋"))
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ朌"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ服"),l11ll1_l1_ (u"࠭ࠧ朎"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ朏"),url,l11ll1_l1_ (u"ࠨࠩ朐"),l11ll1_l1_ (u"ࠩࠪ朑"),l11ll1_l1_ (u"ࠪࠫ朒"),l11ll1_l1_ (u"ࠫࠬ朓"),l11ll1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ朔"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"࠭࡜࡝ࠤࠪ朕"),l11ll1_l1_ (u"ࠧࠣࠩ朖")).replace(l11ll1_l1_ (u"ࠨ࡞࡟࠳ࠬ朗"),l11ll1_l1_ (u"ࠩ࠲ࠫ朘"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭朙"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ朚"),block+l11ll1_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ望"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ朜") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ朝"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠨ࠿ࡀࠫ朞") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭期"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ朠")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1ll1_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朡"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬ朢"),l1llllll1_l1_,561,l11ll1_l1_ (u"࠭ࠧ朣"),l11ll1_l1_ (u"ࠧࠨ朤"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ朥"))
				else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ朦"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠪ朧"),l111lll_l1_,564,l11ll1_l1_ (u"ࠫࠬ木"),l11ll1_l1_ (u"ࠬ࠭朩"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ未"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ末")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨ࠿ࡀ࠴ࠬ本")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ札")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ朮")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ术")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朰"),l111l1_l1_+name+l11ll1_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ朱"),l111lll_l1_,565,l11ll1_l1_ (u"ࠧࠨ朲"),l11ll1_l1_ (u"ࠨࠩ朳"),l1l11lll_l1_+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ朴"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠪࡶࠬ朵") or value==l11ll1_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ朶"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ朷") in option: continue
			if l11ll1_l1_ (u"࠭วๅๅ็ࠫ朸") in option: continue
			if l11ll1_l1_ (u"ࠧ࡯࠯ࡤࠫ朹") in value: continue
			#if value in [l11ll1_l1_ (u"ࠨࡴࠪ机"),l11ll1_l1_ (u"ࠩࡱࡧ࠲࠷࠷ࠨ朻"),l11ll1_l1_ (u"ࠪࡸࡻ࠳࡭ࡢࠩ朼")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ朽"): option = value
			if option==l11ll1_l1_ (u"ࠬ࠭朾"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll111l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ朿"),option,re.DOTALL)
			if l1l1ll111l1_l1_: l11l1l1l1_l1_ = l1l1ll111l1_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠧ࠻ࠢࠪ杀")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ杁")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠩࡀࡁࠬ杂")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭权")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃࠧ杄")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ杅")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ杆"):
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杇"),l111l1_l1_+l1lll1l1l_l1_,url,565,l11ll1_l1_ (u"ࠨࠩ杈"),l11ll1_l1_ (u"ࠩࠪ杉"),l1ll1l11_l1_+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ杊"))
			elif type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ杋") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ杌") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ杍"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ李"),l11ll1_l1_ (u"ࠨࠩ杏"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ材")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l1ll1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ村"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,561,l11ll1_l1_ (u"ࠫࠬ杒"),l11ll1_l1_ (u"ࠬ࠭杓"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ杔"))
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杕"),l111l1_l1_+l1lll1l1l_l1_,url,564,l11ll1_l1_ (u"ࠨࠩ杖"),l11ll1_l1_ (u"ࠩࠪ杗"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ杘"),l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ杙"),l11ll1_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ杚")]
l1l111111_l1_ = [l11ll1_l1_ (u"࠭࡭ࡱࡣࡤࠫ杛"),l11ll1_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭杜"),l11ll1_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ杝"),l11ll1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ杞"),l11ll1_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫ束"),l11ll1_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭杠"),l11ll1_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ条"),l11ll1_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ杢")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ杣") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ杤"),l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࠪ来"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ杦"),l11ll1_l1_ (u"ࠫ࠿ࡀ࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭࠯ࠨ杧"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬࡃ࠽ࠨ杨"),l11ll1_l1_ (u"࠭࠯ࠨ杩"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧࠧࠨࠪ杪"),l11ll1_l1_ (u"ࠨ࠱ࠪ杫"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ杬"),l11ll1_l1_ (u"ࠪࠫ杭"),filters,l11ll1_l1_ (u"ࠫࡎࡔࠠࠡࠢࠣࠫ杮")+mode)
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ杯")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ杰")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫ東")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫ杲"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠩࠪ杳")
	if l11ll1_l1_ (u"ࠪࡁࡂ࠭杴") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠫࠫࠬࠧ杵"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠬࡃ࠽ࠨ杶"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"࠭࠰ࠨ杷")
		if l11ll1_l1_ (u"ࠧࠦࠩ杸") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ杹") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫ杺"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠤ࠰ࠦࠧ杻")+value
		elif mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ杼") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧ杽"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ松")+key+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ板")+value
		elif mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ枀"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ极")+key+l11ll1_l1_ (u"ࠪࡁࡂ࠭枂")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨ枃"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ构"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ枅"),l11ll1_l1_ (u"ࠧࠨ枆"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠨࡑࡘࡘࠬ枇"))
	return l1ll11ll_l1_
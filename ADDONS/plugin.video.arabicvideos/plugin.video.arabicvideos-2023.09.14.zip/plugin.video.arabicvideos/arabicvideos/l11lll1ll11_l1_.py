# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3
#import l11lllll1ll_l1_ as pickle
script_name = l11ll1_l1_ (u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩ㋖")
l1l111llll1_l1_ = xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ㋗"))
l11lll11ll1_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬ㋘"))
sys.path.append(l11lll11ll1_l1_)
l1l111l1ll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥ㋙"))
kodi_version = re.findall(l11ll1_l1_ (u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩ㋚"),l1l111l1ll1_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11lll111l1_l1_ = xbmc.LOGINFO
	ltr,rtl = l11ll1_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ㋛"),l11ll1_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ㋜")
	l1l1111ll1l_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩ㋝"))
	from urllib.parse import unquote as _1l111l1l1l_l1_
else:
	l11lll111l1_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l11ll1_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪ㋞").encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㋟")),l11ll1_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ㋠").encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㋡"))
	l1l1111ll1l_l1_ = xbmc.translatePath(l11ll1_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ㋢"))
	from urllib import unquote as _1l111l1l1l_l1_
l1l11ll11l1_l1_ = 60
HOUR = 60*l1l11ll11l1_l1_
l11lll1l1ll_l1_ = 24*HOUR
l1l11l1ll11_l1_ = 30*l11lll1l1ll_l1_
l1llllll_l1_ = 3*l11lll1l1ll_l1_
PERMANENT_CACHE = 12*l1l11l1ll11_l1_
addon_id = sys.argv[0].split(l11ll1_l1_ (u"ࠧ࠰ࠩ㋣"))[2]	# plugin.video.l11lll1l11l_l1_
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
l1l11ll1ll1_l1_ = addon_id.split(l11ll1_l1_ (u"ࠨ࠰ࠪ㋤"))[2]		# l11lll1l11l_l1_
l11llll11ll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩ㋥")+addon_id+l11ll1_l1_ (u"ࠪ࠭ࠬ㋦"))
addoncachefolder = os.path.join(l1l1111ll1l_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠫࡲࡧࡩ࡯ࡦࡤࡸࡦ࠴ࡤࡣࠩ㋧"))
l1l111l11ll_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠬࡲࡡࡴࡶࡹ࡭ࡩ࡫࡯ࡴ࠰ࡧࡥࡹ࠭㋨"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1lll1l11l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㋩"),l11ll1_l1_ (u"ࠧࠨ㋪"),url,l11ll1_l1_ (u"ࠨࡗࡕࡐࡉࡋࡃࡐࡆࡈࠫ㋫"))
	if l11ll1_l1_ (u"ࠩࡀࠫ㋬") in url:
		if l11ll1_l1_ (u"ࠪࡃࠬ㋭") in url: l111lll_l1_,filters = url.split(l11ll1_l1_ (u"ࠫࡄ࠭㋮"))
		else: l111lll_l1_,filters = l11ll1_l1_ (u"ࠬ࠭㋯"),url
		filters = filters.split(l11ll1_l1_ (u"࠭ࠦࠨ㋰"))
		l11ll11l1_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㋱"),l11ll1_l1_ (u"ࠨࠩ㋲"),filter,str(filters))
			key,value = filter.split(l11ll1_l1_ (u"ࠩࡀࠫ㋳"))
			l11ll11l1_l1_[key] = value
	else: l111lll_l1_,l11ll11l1_l1_ = url,{}
	return l111lll_l1_,l11ll11l1_l1_
def l1111_l1_(urll):
	return _1l111l1l1l_l1_(urll)
	#return urllib2.unquote(urll)
def EXTRACT_KODI_PATH(l11lll1l1l1_l1_):
	l1l1l1111l1_l1_ = {l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ㋴"):l11ll1_l1_ (u"ࠫࠬ㋵"),l11ll1_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ㋶"):l11ll1_l1_ (u"࠭ࠧ㋷"),l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ㋸"):l11ll1_l1_ (u"ࠨࠩ㋹"),l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࠧ㋺"):l11ll1_l1_ (u"ࠪࠫ㋻"),l11ll1_l1_ (u"ࠫࡵࡧࡧࡦࠩ㋼"):l11ll1_l1_ (u"ࠬ࠭㋽"),l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㋾"):l11ll1_l1_ (u"ࠧࠨ㋿"),l11ll1_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ㌀"):l11ll1_l1_ (u"ࠩࠪ㌁"),l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ㌂"):l11ll1_l1_ (u"ࠫࠬ㌃"),l11ll1_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ㌄"):l11ll1_l1_ (u"࠭ࠧ㌅")}
	if l11ll1_l1_ (u"ࠧࡀࠩ㌆") in l11lll1l1l1_l1_: l11lll1l1l1_l1_ = l11lll1l1l1_l1_.split(l11ll1_l1_ (u"ࠨࡁࠪ㌇"),1)[1]
	l111lll_l1_,l1l1l11111l_l1_ = l1lll1l11l_l1_(l11lll1l1l1_l1_)
	args = dict(list(l1l1l1111l1_l1_.items())+list(l1l1l11111l_l1_.items()))
	l11lll11lll_l1_ = args[l11ll1_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㌈")]
	l1l111ll1l1_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ㌉")])
	l1l11111ll1_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ㌊")])
	l11lll11111_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠬࡶࡡࡨࡧࠪ㌋")])
	l11ll1lllll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ㌌")])
	l1l11111lll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㌍")])
	l1l11l111ll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ㌎")])
	l1l11111l11_l1_ = args[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ㌏")]
	l1l111l1l11_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬ㌐")])
	if l1l111l1l11_l1_: l1l111l1l11_l1_ = eval(l1l111l1l11_l1_)
	else: l1l111l1l11_l1_ = {}
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ㌑"))
	#l111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬ㌒"))
	if not l11lll11lll_l1_: l11ll1lllll_l1_ = l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㌓") ; l11lll11lll_l1_ = l11ll1_l1_ (u"ࠧ࠳࠸࠳ࠫ㌔")
	return l11ll1lllll_l1_,l1l11111lll_l1_,l1l111ll1l1_l1_,l11lll11lll_l1_,l1l11l111ll_l1_,l11lll11111_l1_,l1l11111ll1_l1_,l1l11111l11_l1_,l1l111l1l11_l1_
def LOGGING(script_name):
	l1l11111l1l_l1_ = sys._getframe(1).f_code.co_name
	if not script_name or not l1l11111l1l_l1_ or l1l11111l1l_l1_==l11ll1_l1_ (u"ࠨ࠾ࡰࡳࡩࡻ࡬ࡦࡀࠪ㌕"):
		return l11ll1_l1_ (u"ࠩ࡞ࠤࠬ㌖")+l1l11ll1ll1_l1_.upper()+l11ll1_l1_ (u"ࠪ࠱ࠬ㌗")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠫ࠲࠭㌘")+str(kodi_version)+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㌙")
	return l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࠫ㌚")+l1l11111l1l_l1_
def LOG_THIS(level,message):
	l11llll1l1l_l1_ = l11lll111l1_l1_
	lines = [l11ll1_l1_ (u"ࠧࠨ㌛"),l11ll1_l1_ (u"ࠨࠩ㌜")]
	if level:
		message = message.replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㌝"),l11ll1_l1_ (u"ࠪࠫ㌞")).replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㌟"),l11ll1_l1_ (u"ࠬ࠭㌠"))
		message = message.replace(l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㌡"),l11ll1_l1_ (u"ࠧࠨ㌢"))
	else: level = l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㌣")
	l111l1ll1l_l1_,sep,shift = l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ㌤"),l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ㌥"),l11ll1_l1_ (u"ࠫࠬ㌦")
	if l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㌧") in level: l11llll1l1l_l1_ = xbmc.LOGERROR
	if level==l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㌨"):
		message = message+sep
		lines = message.split(sep)
		shift = l111l1ll1l_l1_
	elif level==l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㌩"):
		message = message.replace(l11ll1_l1_ (u"ࠨ࠰ࠪ㌪")+sep,l11ll1_l1_ (u"ࠩ࠱ࠤࠥ࠭㌫"))
		lines = message.split(sep)
		shift = l111l1ll1l_l1_+sep
	elif level in [l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㌬"),l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㌭")]: lines = message.split(l111l1ll1l_l1_)
	shift += 6*l111l1ll1l_l1_
	l11lllll11l_l1_ = 3*l111l1ll1l_l1_
	if kodi_version>17.99: shift += 11*l11ll1_l1_ (u"ࠬࠦࠧ㌮")
	l1l11l1l1ll_l1_ = lines[0]
	for line in lines[1:]:
		if l11ll1_l1_ (u"࠭࡜࡯ࠩ㌯") in line: line = line.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㌰"),l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㌱")+l111l1ll1l_l1_+l111l1ll1l_l1_)
		l11lllll11l_l1_ += l111l1ll1l_l1_
		l1l11l1l1ll_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡶࠬ㌲")+shift+l11lllll11l_l1_+line
	l1l11l1l1ll_l1_ += l11ll1_l1_ (u"ࠪࠤࡤ࠭㌳")
	if l11ll1_l1_ (u"ࠫࠪ࠭㌴") in l1l11l1l1ll_l1_: l1l11l1l1ll_l1_ = l1111_l1_(l1l11l1l1ll_l1_)
	xbmc.log(l1l11l1l1ll_l1_,level=l11llll1l1l_l1_)
	return
def l1l11lll11l_l1_(l1l1ll11l1_l1_):
	conn = sqlite3.connect(l1l1ll11l1_l1_)
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫ㌵"))
	cc.execute(l11ll1_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟࡬ࡧࡼࡷࡂࡴ࡯࠼ࠩ㌶"))
	cc.execute(l11ll1_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳ࠼ࠩ㌷"))
	cc.execute(l11ll1_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉ࠿ࠬ㌸"))
	cc.execute(l11ll1_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧ㌹"))
	cc.execute(l11ll1_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࡀ࠭㌺"))
	conn.text_factory = str
	return conn,cc
def DELETE_FROM_SQL3(l1l1ll11l1_l1_,table,l1l111ll11l_l1_=None):
	try: conn,cc = l1l11lll11l_l1_(l1l1ll11l1_l1_)
	except: return
	if l1l111ll11l_l1_==None: cc.execute(l11ll1_l1_ (u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㌻")+table+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ㌼"))
	else:
		tt = (str(l1l111ll11l_l1_),)
		try:
			if l11ll1_l1_ (u"࠭ࠥࠨ㌽") in l1l111ll11l_l1_: cc.execute(l11ll1_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㌾")+table+l11ll1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫ㌿"),tt)
			else: cc.execute(l11ll1_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㍀")+table+l11ll1_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㍁"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l11l1ll1l_l1_(): pass
class l1l11llll11_l1_(l1l11l1ll1l_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l11ll1_l1_ (u"ࠫࠬ㍂")
		self.content = l11ll1_l1_ (u"ࠬ࠭㍃")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l11ll1_l1_ (u"࠭ࠧ㍄")
def l1l111ll111_l1_(type):
	if type==l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㍅"): data = {}
	elif type==l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㍆"): data = []
	elif type==l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭㍇"): data = l11ll1_l1_ (u"ࠪࠫ㍈")
	elif type==l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ㍉"): data = 0
	elif type==l11ll1_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ㍊"): data = l1l11llll11_l1_()
	elif not type: data = None
	else: data = None
	return data
def READ_FROM_SQL3(l1l1ll11l1_l1_,l1l11l11111_l1_,table,l1l111ll11l_l1_=None):
	data = l1l111ll111_l1_(l1l11l11111_l1_)
	l1l11lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㍋"))
	if l1l11lllll_l1_==l11ll1_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㍌") and table!=l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㍍") and l1l1ll11l1_l1_==main_dbfile:
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,table,l1l111ll11l_l1_)
		return data
	l1l1l111l1l_l1_ = 0
	cache = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㍎"))
	if cache==l11ll1_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㍏"): return data
	elif cache==l11ll1_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㍐"): l1l1l111l1l_l1_ = l11llll11l1_l1_
	try: conn,cc = l1l11lll11l_l1_(l1l1ll11l1_l1_)
	except: return data
	l1l111l11l1_l1_ = True
	try: cc.execute(l11ll1_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥࠨࠧ㍑")+table+l11ll1_l1_ (u"࠭ࠢࠡࡎࡌࡑࡎ࡚ࠠ࠲ࠢ࠾ࠫ㍒"))
	except: l1l111l11l1_l1_ = False
	if l1l111l11l1_l1_:
		if l1l1l111l1l_l1_: cc.execute(l11ll1_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㍓")+table+l11ll1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺࡀࠪ㍔")+str(now+l1l1l111l1l_l1_)+l11ll1_l1_ (u"ࠩࠣ࠿ࠬ㍕"))
		conn.commit()
		cc.execute(l11ll1_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㍖")+table+l11ll1_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡁ࠭㍗")+str(now)+l11ll1_l1_ (u"ࠬࠦ࠻ࠨ㍘"))
		conn.commit()
		if l1l111ll11l_l1_:
			tt = (str(l1l111ll11l_l1_),)
			cc.execute(l11ll1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ㍙")+table+l11ll1_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㍚"),tt)
			l1l1111ll11_l1_ = cc.fetchall()
			if l1l1111ll11_l1_:
				try:
					text = zlib.decompress(l1l1111ll11_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11ll1_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㍛")+table+l11ll1_l1_ (u"ࠩࠥࠤࡀ࠭㍜"))
			l1l1111ll11_l1_ = cc.fetchall()
			if l1l1111ll11_l1_:
				data,l1l11lll111_l1_ = {},[]
				for l1l11l1l1l1_l1_,l11ll11l1_l1_ in l1l1111ll11_l1_:
					l1l1l1ll1l_l1_ = zlib.decompress(l11ll11l1_l1_)
					l11ll11l1_l1_ = pickle.loads(l1l1l1ll1l_l1_)
					data[l1l11l1l1l1_l1_] = l11ll11l1_l1_
					l1l11lll111_l1_.append(l1l11l1l1l1_l1_)
				if l1l11lll111_l1_:
					data[l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡒࡗࡈࡒࡈࡋࡄࡠࡅࡒࡐ࡚ࡓࡎࡔࡡࡢࠫ㍝")] = l1l11lll111_l1_
					if l1l11l11111_l1_==l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㍞"): data = l1l11lll111_l1_
	conn.close()
	return data
def l1l111l1111_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11l11l11_l1_(length=32):
	try: l11llll1l1_l1_,l1l11ll1l11_l1_,l11lllll111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ㍟"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㍠"),l11ll1_l1_ (u"ࠧࡊࡆࡖࠫ㍡"))
	except: l11llll1l1_l1_,l1l11ll1l11_l1_,l11lllll111_l1_ = l11ll1_l1_ (u"ࠨࠩ㍢"),l11ll1_l1_ (u"ࠩࠪ㍣"),l11ll1_l1_ (u"ࠪࠫ㍤")
	l11lll1111l_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡓ࡫ࡴࡸࡱࡵ࡯࠳ࡏࡐࡂࡦࡧࡶࡪࡹࡳࠨ㍥"))
	l1l11l11ll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡪࡧࡱࡨࡱࡿࡎࡢ࡯ࡨࠫ㍦"))
	if l11llll1l1_l1_ and l11lll1111l_l1_==l1l11ll1l11_l1_ and l1l11l11ll1_l1_==l11lllll111_l1_: return l11llll1l1_l1_
	#import uuid
	#node = str(uuid.getnode())
	#l1l11l1l111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡎࡣࡦࡅࡩࡪࡲࡦࡵࡶࠫ㍧"))
	#if l1l11l1l111_l1_.count(l11ll1_l1_ (u"ࠧ࠻ࠩ㍨"))==5 and l1l11l1l111_l1_.count(l11ll1_l1_ (u"ࠨ࠲ࠪ㍩"))<9: l11lllll1l1_l1_ = l1l11l1l111_l1_
	global mac
	length = length//2
	import threading
	l11lll1lll1_l1_ = threading.Thread(target=l1l111l1111_l1_,args=())
	l11lll1lll1_l1_.start()
	mac = l11ll1_l1_ (u"ࠩࠪ㍪")
	for l11ll1111l_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11ll1_l1_ (u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭㍫")
	else:
		mac = mac.replace(l11ll1_l1_ (u"ࠫ࠿࠭㍬"),l11ll1_l1_ (u"ࠬ࠭㍭"))
		node = str(int(mac,16))
	node = re.findall(l11ll1_l1_ (u"࡛࠭࠱࠯࠼ࡡ࠰࠭㍮"),node,re.DOTALL)
	node = length*l11ll1_l1_ (u"ࠧ࠱ࠩ㍯")+node[0]
	node = node[-length:]
	mm,ss = l11ll1_l1_ (u"ࠨࠩ㍰"),l11ll1_l1_ (u"ࠩࠪ㍱")
	l1l1111l11l_l1_ = str(int(l11ll1_l1_ (u"ࠪ࠽ࠬ㍲")*(length+1))-int(node))[-length:]
	for l11ll1111l_l1_ in list(range(0,length,4)):
		l11llll111l_l1_ = l1l1111l11l_l1_[l11ll1111l_l1_:l11ll1111l_l1_+4]
		mm += l11llll111l_l1_+l11ll1_l1_ (u"ࠫ࠲࠭㍳")
		ss += str(sum(map(int,node[l11ll1111l_l1_:l11ll1111l_l1_+4]))%10)
	l1l11llll1l_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㍴"),l11ll1_l1_ (u"࠭ࡉࡅࡕࠪ㍵"),[l1l11llll1l_l1_,l11lll1111l_l1_,l1l11l11ll1_l1_],l1llllll_l1_)
	return l1l11llll1l_l1_
def l11llll1111_l1_(l1l1l111111_l1_):
	l11llllllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㍶"))
	#l1l1l111111_l1_ = l1l1l111111_l1_.encode(l11ll1_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ㍷")).replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㍸"),l11ll1_l1_ (u"ࠪࠫ㍹"))
	user = l1l11l11l11_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11ll1_l1_ (u"ࠫ࡝࠷࠹ࠨ㍺")+l1l1l111111_l1_+l11ll1_l1_ (u"ࠬ࠷࠸࠾ࠩ㍻")+user).encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㍼"))).hexdigest()[0:32]
	if md5 in l11llllllll_l1_: return True
	return False
class l1l111lll1l_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11ll1_l1_ (u"ࠧࠨ㍽")
		if l11llll1111_l1_(l11ll1_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ㍾")) or not l11llll1111_l1_(l11ll1_l1_ (u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪ㍿")):
			self.status = l11ll1_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㎀")
			import l1l1111lll1_l1_
			l1l1111lll1_l1_.l1l111lll11_l1_(False)
	def onPlayBackStopped(self):
		self.status=l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㎁")
	def onPlayBackStarted(self):
		self.status = l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㎂")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㎃")
	def onPlayBackEnded(self):
		self.status = l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㎄")
def l1l11l1111l_l1_(l1l1111111l_l1_,url,data,headers,source,method):
	l1l1ll11l_l1_ = str(headers)[0:250].replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㎅"),l11ll1_l1_ (u"ࠩ࡟ࡠࡳ࠭㎆")).replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭㎇"),l11ll1_l1_ (u"ࠫࡡࡢࡲࠨ㎈")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠪ㎉"),l11ll1_l1_ (u"࠭ࠠࠨ㎊")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㎋"),l11ll1_l1_ (u"ࠨࠢࠪ㎌"))
	if len(str(headers))>250: l1l1ll11l_l1_ = l1l1ll11l_l1_+l11ll1_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㎍")
	l11ll11l1_l1_ = str(data)[0:250].replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭㎎"),l11ll1_l1_ (u"ࠫࡡࡢ࡮ࠨ㎏")).replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ㎐"),l11ll1_l1_ (u"࠭࡜࡝ࡴࠪ㎑")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠣࠤࠬ㎒"),l11ll1_l1_ (u"ࠨࠢࠪ㎓")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㎔"),l11ll1_l1_ (u"ࠪࠤࠬ㎕"))
	if len(str(data))>250: l11ll11l1_l1_ = l11ll11l1_l1_+l11ll1_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ㎖")
	if l1l1111111l_l1_: LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㎗"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡩࡦࡪࡩ࡯ࡩࠣࡇࡆࡉࡈࡆ࠼ࠣ࡟ࠥ࠭㎘")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㎙")+source+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪ㎚")+method+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ㎛")+str(l1l1ll11l_l1_)+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪ㎜")+l11ll11l1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㎝"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㎞"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡒࡴࡪࡴࡩ࡯ࡩ࡙ࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㎟")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㎠")+source+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪ㎡")+method+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ㎢")+str(l1l1ll11l_l1_)+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪ㎣")+l11ll11l1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㎤"))
	return
def l1llll1lll_l1_(method,url,data=l11ll1_l1_ (u"ࠬ࠭㎥"),headers=l11ll1_l1_ (u"࠭ࠧ㎦"),source=l11ll1_l1_ (u"ࠧࠨ㎧")):
	l1l11l1111l_l1_(False,url,data,headers,source,l11ll1_l1_ (u"ࠨࠩ㎨"))
	if kodi_version>18.99: import urllib.request as l1l11l1llll_l1_
	else: import urllib2 as l1l11l1llll_l1_
	if not headers: headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㎩"):l11ll1_l1_ (u"ࠪࠫ㎪")}
	if not data: data = {}
	if method==l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㎫"):
		url = url+l11ll1_l1_ (u"ࠬࡅࠧ㎬")+l1ll1l11l_l1_(data)
		data = None
	elif method==l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㎭"): data = data.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㎮"))
	try:
		req = l1l11l1llll_l1_.Request(url,headers=headers,data=data)
		http_response = l1l11l1llll_l1_.urlopen(req)
		html = http_response.read()
	except: html = l11ll1_l1_ (u"ࠨࠩ㎯")
	#try:
	#	req = l1l11l1llll_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l1l11l1llll_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l11ll1_l1_ (u"ࠩࠪ㎰")
	return html
def l1l11llllll_l1_(script_name):
	# https://www.l1l11ll1l1l_l1_.l1l11ll1111_l1_.l11llllll1l_l1_.com/l1l11l11lll_l1_/l1l111111ll_l1_/http-l11lll11l1l_l1_-l1l1111llll_l1_
	# https://help.l11llllll1l_l1_.com/l1l11111111_l1_/l1l11l1l11l_l1_-l1llll11111_l1_/l1l11ll111l_l1_/215562387-l1l1111l111_l1_-property-l11ll1llll1_l1_
	# https://www.l1l11ll1l1l_l1_.l1l11ll1111_l1_.l11llllll1l_l1_.com/l1l11l11lll_l1_/l1l111111ll_l1_/l11lllllll1_l1_-rest-l1l1111llll_l1_
	l11llllll11_l1_ = str(random.randrange(111111111111,999999999999))
	#l1l111l111l_l1_ = l11lll111ll_l1_()
	#l1l11lllll1_l1_ = l1l111l111l_l1_.split(l11ll1_l1_ (u"ࠪ࠰ࠬ㎱"),1)[0]
	headers = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㎲"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ㎳")}
	data = {l11ll1_l1_ (u"ࠨࡡࡱ࡫ࡢ࡯ࡪࡿࠢ㎴"):l11ll1_l1_ (u"ࠧ࠳࠷࠷ࡨࡩ࠹ࡡ࠵࠲࠼ࡨ࠽ࡨ࠶࠹࠳ࡧ࠸ࡪ࠷࠱࠸ࡧࡨ࠻࠽ࡩࡥࡣࡨ࠵࠽ࠬ㎵"),
			l11ll1_l1_ (u"ࠣ࡫ࡱࡷࡪࡸࡴࡠ࡫ࡧࠦ㎶"):l11llllll11_l1_,
			l11ll1_l1_ (u"ࠤࡨࡺࡪࡴࡴࡴࠤ㎷"): [{
				l11ll1_l1_ (u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ㎸"):l1l11l11l11_l1_(32),
				l11ll1_l1_ (u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ㎹"):str(kodi_version),
				l11ll1_l1_ (u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥ㎺"):l11llll11ll_l1_,
				l11ll1_l1_ (u"ࠨࡣࡢࡴࡵ࡭ࡪࡸࠢ㎻"):l11llll11ll_l1_,
				l11ll1_l1_ (u"ࠢࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠦ㎼"):script_name,
				l11ll1_l1_ (u"ࠣࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ㎽"):{l11ll1_l1_ (u"ࠤࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ㎾"):script_name},
				l11ll1_l1_ (u"ࠥࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧ㎿"): {l11ll1_l1_ (u"࡚ࠦࡹࡥࡳࡡࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ㏀"):script_name},
				l11ll1_l1_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢ㏁"): l11ll1_l1_ (u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨ㏂"),
				l11ll1_l1_ (u"ࠢࠥࡵ࡮࡭ࡵࡥࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࡠࡵࡼࡲࡨࠨ㏃"):False,
				l11ll1_l1_ (u"ࠣ࡫ࡳࠦ㏄"): l11ll1_l1_ (u"ࠤࠧࡶࡪࡳ࡯ࡵࡧࠥ㏅")
			}]
		}
	url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠳࠰ࡤࡱࡵࡲࡩࡵࡷࡧࡩ࠳ࡩ࡯࡮࠱࠵࠳࡭ࡺࡴࡱࡣࡳ࡭ࠬ㏆")
	import json
	data = json.dumps(data)
	#response = l1l111l1lll_l1_(l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㏇"),url,data,headers,l11ll1_l1_ (u"ࠬ࠭㏈"),l11ll1_l1_ (u"࠭ࠧ㏉"),l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ㏊"),False,False)
	response = l1llll1lll_l1_(l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㏋"),url,data,headers,script_name)
	return response
def l1l11l11l1l_l1_(url,script_name,type):
	l11lll11l11_l1_ = xbmcgui.ListItem()
	l1l1111l1l1_l1_ = l1l111lll1l_l1_()
	if l1l1111l1l1_l1_.status: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㏌"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡄࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㏍")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㏎"))
	else:
		if type==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㏏"):
			l11lll11l11_l1_.setPath(url)
			LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㏐"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡺ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㏑")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㏒"))
			xbmcplugin.setResolvedUrl(addon_handle,True,l11lll11l11_l1_)
		else:
			LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㏓"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡓࡪ࡯ࡳࡰࡪࠦ࡬ࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㏔")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㏕"))
			l1l1111l1l1_l1_.play(url,l11lll11l11_l1_)
		l1l11l111l1_l1_()
		timeout = 5
		for l11ll1111l_l1_ in range(timeout):
			# l11lll1l111_l1_ l1l11lll1ll_l1_
			#	if using time.sleep() l11lll1ll1l_l1_ of xbmc.sleep() l1l11ll1lll_l1_ the l11llll1ll1_l1_ status
			#	l11ll1_l1_ (u"ࠧࡳࡹࡱ࡮ࡤࡽࡪࡸ࠮ࡴࡶࡤࡸࡺࡹࠢ㏖") will stop l1l1111l1ll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l1l111l11_l1_ = l1l1111l1l1_l1_.status
			if l1l1l111l11_l1_ in [l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㏗"),l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㏘")]: break
		if l1l1l111l11_l1_==l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㏙"): response = l1l11llllll_l1_(script_name)
	return
def EVAL(l1l11l11111_l1_,text):
	#text = text.replace(l11ll1_l1_ (u"ࠤࡸࠫࠧ㏚"),l11ll1_l1_ (u"ࠥࠫࠧ㏛"))
	text = text.replace(l11ll1_l1_ (u"ࠫࡳࡻ࡬࡭ࠩ㏜"),l11ll1_l1_ (u"ࠬࡔ࡯࡯ࡧࠪ㏝"))
	text = text.replace(l11ll1_l1_ (u"࠭ࡴࡳࡷࡨࠫ㏞"),l11ll1_l1_ (u"ࠧࡕࡴࡸࡩࠬ㏟"))
	text = text.replace(l11ll1_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ㏠"),l11ll1_l1_ (u"ࠩࡉࡥࡱࡹࡥࠨ㏡"))
	text = text.replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭㏢"),l11ll1_l1_ (u"ࠫ࠴࠭㏣"))
	try: l1l1l1ll1l_l1_ = eval(text)
	except: l1l1l1ll1l_l1_ = l1l111ll111_l1_(l1l11l11111_l1_)
	return l1l1l1ll1l_l1_
def l1l11l111l1_l1_():
	type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11ll1_l1_ (u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡࠬ㏤"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11ll1_l1_ (u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭㏥"),time.localtime(now))
	name = name+datetime
	l1ll1111ll1_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_
	if os.path.exists(l1l111l11ll_l1_):
		l1l111111l1_l1_ = open(l1l111l11ll_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ㏦")).read()
		if kodi_version>18.99: l1l111111l1_l1_ = l1l111111l1_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㏧"))
		l1l111111l1_l1_ = EVAL(l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㏨"),l1l111111l1_l1_)
	else: l1l111111l1_l1_ = {}
	l11llll1l11_l1_ = {}
	for l1l11ll11ll_l1_ in list(l1l111111l1_l1_.keys()):
		if l1l11ll11ll_l1_!=type: l11llll1l11_l1_[l1l11ll11ll_l1_] = l1l111111l1_l1_[l1l11ll11ll_l1_]
		else:
			if name and name!=l11ll1_l1_ (u"ࠪ࠲࠳࠭㏩"):
				l11lll1llll_l1_ = l1l111111l1_l1_[l1l11ll11ll_l1_]
				if l1ll1111ll1_l1_ in l11lll1llll_l1_:
					index = l11lll1llll_l1_.index(l1ll1111ll1_l1_)
					del l11lll1llll_l1_[index]
				l1llll11lll_l1_ = [l1ll1111ll1_l1_]+l11lll1llll_l1_
				l1llll11lll_l1_ = l1llll11lll_l1_[:50]
				l11llll1l11_l1_[l1l11ll11ll_l1_] = l1llll11lll_l1_
			else: l11llll1l11_l1_[l1l11ll11ll_l1_] = l1l111111l1_l1_[l1l11ll11ll_l1_]
	if type not in list(l11llll1l11_l1_.keys()): l11llll1l11_l1_[type] = [l1ll1111ll1_l1_]
	l11llll1l11_l1_ = str(l11llll1l11_l1_)
	if kodi_version>18.99: l11llll1l11_l1_ = l11llll1l11_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㏪"))
	open(l1l111l11ll_l1_,l11ll1_l1_ (u"ࠬࡽࡢࠨ㏫")).write(l11llll1l11_l1_)
	return
def WRITE_TO_SQL3(l1l1ll11l1_l1_,table,l1l111ll11l_l1_,data,l1l111lllll_l1_,l1l11l1lll1_l1_=False):
	cache = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㏬"))
	if cache==l11ll1_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ㏭") and l1l111lllll_l1_>l11llll11l1_l1_: l1l111lllll_l1_ = l11llll11l1_l1_
	if l1l11l1lll1_l1_:
		l11l1ll1l_l1_,l11l1lll1_l1_ = [],[]
		for l11ll1111l_l1_ in range(len(l1l111ll11l_l1_)):
			text = pickle.dumps(data[l11ll1111l_l1_])
			l11llll1lll_l1_ = zlib.compress(text)
			l11l1ll1l_l1_.append((l1l111ll11l_l1_[l11ll1111l_l1_],))
			l11l1lll1_l1_.append((l1l111lllll_l1_+now,str(l1l111ll11l_l1_[l11ll1111l_l1_]),l11llll1lll_l1_))
	else:
		text = pickle.dumps(data)
		l1l111ll1ll_l1_ = zlib.compress(text)
	try: conn,cc = l1l11lll11l_l1_(l1l1ll11l1_l1_)
	except: return
	while True:
		try:
			cc.execute(l11ll1_l1_ (u"ࠨࡄࡈࡋࡎࡔࠠࡊࡏࡐࡉࡉࡏࡁࡕࡇࠣࡘࡗࡇࡎࡔࡃࡆࡘࡎࡕࡎࠡ࠽ࠪ㏮"))
			break
		except: time.sleep(0.5)
	cc.execute(l11ll1_l1_ (u"ࠩࡆࡖࡊࡇࡔࡆࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡓࡕࡔࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ㏯")+table+l11ll1_l1_ (u"ࠪࠦࠥ࠮ࡥࡹࡲ࡬ࡶࡾ࠲ࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤ࠭ࠥࡁࠧ㏰"))
	if l1l11l1lll1_l1_:
		cc.executemany(l11ll1_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㏱")+table+l11ll1_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㏲"),l11l1ll1l_l1_)
		cc.executemany(l11ll1_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭㏳")+table+l11ll1_l1_ (u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ㏴"),l11l1lll1_l1_)
	else:
		if l1l111lllll_l1_:
			tt = (str(l1l111ll11l_l1_),)
			cc.execute(l11ll1_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㏵")+table+l11ll1_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㏶"),tt)
			tt = (l1l111lllll_l1_+now,str(l1l111ll11l_l1_),l1l111ll1ll_l1_)
			cc.execute(l11ll1_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪ㏷")+table+l11ll1_l1_ (u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩ㏸"),tt)
		else:
			tt = (l1l111ll1ll_l1_,str(l1l111ll11l_l1_))
			cc.execute(l11ll1_l1_ (u"࡛ࠬࡐࡅࡃࡗࡉࠥࠨࠧ㏹")+table+l11ll1_l1_ (u"࠭ࠢࠡࡕࡈࡘࠥࡪࡡࡵࡣࠣࡁࠥࡅࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㏺"),tt)
	conn.commit()
	conn.close()
	return
def l1ll1l11l_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l11lll1l1_l1_
	else: import urllib as l1l11lll1l1_l1_
	l1l1l1111ll_l1_ = l1l11lll1l1_l1_.urlencode(data)
	return l1l1l1111ll_l1_
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ宏")
def MAIN(mode,text=l11ll1_l1_ (u"ࠫࠬ宐")):
	if   mode==  0: l1lll1ll1llll_l1_(text)
	elif mode==  2: l1ll111ll111_l1_(text)
	elif mode==  3: l1llll11ll1l1_l1_()
	elif mode==  4: l1lll1ll111l_l1_(text)
	elif mode==  5: l1lll1ll1l1ll_l1_()
	elif mode==  6: l1llll1l11ll1_l1_()
	elif mode==  7: l1ll1l1l11l1_l1_()
	elif mode==  8: l1lll1ll11l11_l1_()
	elif mode==  9: l1lll1ll11ll1_l1_()
	elif mode==150: l1lll1l1ll111_l1_()
	elif mode==151: l1lll11l1111l_l1_()
	elif mode==152: l1llll11111l1_l1_()
	elif mode==153: l1lllll111l1l_l1_()
	elif mode==154: l1llll1ll1111_l1_()
	elif mode==155: l1lll1lll11ll_l1_()
	elif mode==156: l1lll111llll1_l1_()
	elif mode==157: l1llll1l11lll_l1_()
	elif mode==158: l1llll1111l11_l1_()
	elif mode==159: l1lll1l1l111l_l1_(True)
	elif mode==170: l1lll1l1l11l1_l1_()
	elif mode==171: l1llll11l111l_l1_()
	elif mode==172: l1lll1l1111l1_l1_(text,True,True)
	elif mode==173: l11l11llll1_l1_(l11ll1_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ宑"),True)
	elif mode==174: l11l11llll1_l1_(l11ll1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ宒"),True)
	elif mode==175: l1lll1llll1l1_l1_()
	elif mode==176: l1lll1l1111ll_l1_()
	elif mode==177: l1llll1l1ll1l_l1_(l11ll1_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ宓"))
	elif mode==178: l1llll1l1ll1l_l1_(l11ll1_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ宔"))
	elif mode==179: l1llll1l1ll1l_l1_(l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ宕"))
	elif mode==190: l1lll1ll1lll1_l1_()
	elif mode==191: l1lll11ll1lll_l1_()
	elif mode==192: l1lll1l111l11_l1_()
	elif mode==193: l1llll11l11ll_l1_()
	elif mode==194: l1lll11llllll_l1_()
	elif mode==195: l1lll1l1l1lll_l1_()
	elif mode==196: l1lll1ll1l1l1_l1_()
	elif mode==197: l1lll1l1llll1_l1_()
	elif mode==198: l1llll111llll_l1_()
	elif mode==199: l1lll1l1lll11_l1_()
	elif mode==340: l1lll11ll111l_l1_(text)
	elif mode==341: l1l1l1lll111_l1_()
	elif mode==342: l1lll1lll1ll1_l1_()
	elif mode==343: l1lll1l1lllll_l1_()
	elif mode==344: l1lll11lll111_l1_(True)
	elif mode==345: l1llll111l111_l1_()
	elif mode==346: l1l111lll11_l1_(False)
	elif mode==347: l1l1l1l1ll11_l1_(True)
	elif mode==348: l1llll11l11l1_l1_()
	elif mode==349: l1llll1l11111_l1_(l1l11l1l1l11_l1_)
	elif mode==500: l1lll11lll11l_l1_()
	elif mode==501: l1lll11l1l1l1_l1_()
	elif mode==502: l1llll111lll1_l1_(l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ宖"),True)
	elif mode==503: l1llll1l11111_l1_(l1l111l11ll_l1_)
	elif mode==504: l1llll1l11111_l1_(favoritesfile)
	elif mode==505: l1lll1llll111_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1ll1ll1_l1_(text,l11ll1_l1_ (u"ࠫࠬ宗"),True)
	elif mode==508: l1llll11l1111_l1_()
	elif mode==509: l1lllll1111l1_l1_()
	return
def l1lllll1111l1_l1_():
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭官"),l11ll1_l1_ (u"࠭ࠧ宙"),l11ll1_l1_ (u"ࠧࠨ定"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ宛"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣๅ฾๊วࠡ็ึัࠥาๅ๋฻ࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦ࠮࠯ุ๋้ࠢำࠠอ็ํ฽๋ࠥไโษอࠤฬ๊ศา่ส้ัࠦวๅไา๎๊ฯࠠ࠯࠰่่ࠣ๐๋ࠠ฻๋ำࠥอไษำ้ห๊าࠠฦๆ์ࠤาอไสࠢสฺ่็ัࠡ࠰࠱ࠤ๏฿ๆ๋ࠢอะิ๐ฯࠡษ็ฬึ์วๆฮࠣ์ฯ฻แ๋ำ๊ࠤํ๎ึฺ้ࠣฬาอไสࠢส่๊฻ๆฺࠢส่ฯ๐ุ้ࠠ฼๋ฬࠦวๅ็หี๊าࠠภࠣࠤࠫ宜"))
	if l1ll111lll_l1_:
		l1lll11lll111_l1_(False)
		l1ll11ll11_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ宝"),l11ll1_l1_ (u"ࠫࠬ实"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ実"),l11ll1_l1_ (u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ฿วะࠢส่อืๆศ็ฯࠤสู๊้๊ࠡ฽๏ฯࠠศๆุๅึࠦ࠮࠯ฺ๋ࠢ฾๐ษࠡษ็ฺ้์ูࠨ宠"))
	return
def l1l1l1ll1ll1_l1_(addon_id,function,l1ll_l1_):
	# function: l11ll1_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࠧ审"),l11ll1_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࠩ客"),l11ll1_l1_ (u"ࠩࠪ宣")
	conn = sqlite3.connect(l11111l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1lll1l111lll_l1_ = l11ll1_l1_ (u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭室")
	else: l1lll1l111lll_l1_ = l11ll1_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪ宥")
	cc.execute(l11ll1_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭宦")+l1lll1l111lll_l1_+l11ll1_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ宧")+addon_id+l11ll1_l1_ (u"ࠧࠣࠢ࠾ࠫ宨"))
	l1l1111ll11_l1_ = cc.fetchall()
	if l1l1111ll11_l1_ and function in [l11ll1_l1_ (u"ࠨࠩ宩"),l11ll1_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ宪")]:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ宫"),l11ll1_l1_ (u"ࠫࠬ宬"),l11ll1_l1_ (u"ࠬ࠭宭"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ宮"),l11ll1_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ宯")+addon_id+l11ll1_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ宰"))
		if l1ll111lll_l1_!=1: return
		cc.execute(l11ll1_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ宱")+l1lll1l111lll_l1_+l11ll1_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ宲")+addon_id+l11ll1_l1_ (u"ࠫࠧࠦ࠻ࠨ害"))
	elif function in [l11ll1_l1_ (u"ࠬ࠭宴"),l11ll1_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࠧ宵")]:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ家"),l11ll1_l1_ (u"ࠨࠩ宷"),l11ll1_l1_ (u"ࠩࠪ宸"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭容"),l11ll1_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ宺")+addon_id+l11ll1_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ宻"))
		if l1ll111lll_l1_!=1: return
		if kodi_version<19: cc.execute(l11ll1_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭宼")+addon_id+l11ll1_l1_ (u"ࠧࠣࠫࠣ࠿ࠬ宽"))
		else: cc.execute(l11ll1_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ宾")+addon_id+l11ll1_l1_ (u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩ宿"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ寀"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ寁"),l11ll1_l1_ (u"ࠬ࠭寂"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ寃"),l11ll1_l1_ (u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ寄"))
	if function in [l11ll1_l1_ (u"ࠨࠩ寅"),l11ll1_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ密")]: l1lll1l1l111l_l1_(l1ll_l1_)
	return
def l1lll1llll111_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭寇"),l11ll1_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ寈"))
	l1l1ll1l1l1l_l1_ = l11l1lll1ll_l1_(False)
	l1lllllllll1_l1_ = l11ll1_l1_ (u"ࠬࡢ࡮ࠨ寉")
	l1lllll11l11l_l1_ = l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ寊")
	l1lllll111ll1_l1_ = l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ寋")
	for id,l1l11l1l111l_l1_,l1l11lll1lll_l1_,l111l1l11ll_l1_,l111l11l1l1_l1_,reason in reversed(l1l1ll1l1l1l_l1_):
		if id==l11ll1_l1_ (u"ࠨ࠲ࠪ富"):
			l1lllll1111l_l1_,l1lllll111l1_l1_ = l111l1l11ll_l1_.split(l11ll1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ寍"))
			continue
		if l1lllllllll1_l1_!=l11ll1_l1_ (u"ࠪࡠࡳ࠭寎"): l1lllllllll1_l1_ += l1lllll111ll1_l1_
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ寏")+id+l11ll1_l1_ (u"ࠬࠦ࠺ࠡࠩ寐")+l11ll1_l1_ (u"࠭วๅีวห้ࠦ࠺ࠡࠩ寑")+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ寒")+l1l11lll1lll_l1_
		l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ寓")+l111l1l11ll_l1_
		l111ll111ll1_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽รࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ寔")+l111l11l1l1_l1_
		l111ll111lll_l1_ = l11ll1_l1_ (u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิสหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ寕")+reason
		l1lllllllll1_l1_ += l1ll11l1l11_l1_+l1ll11l1l1l_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ寖")+l1lllll11l11l_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ寗")+l111ll111ll1_l1_+l111ll111lll_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ寘")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭寙"),l1lllll111l1_l1_,l1lllllllll1_l1_,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ寚"))
	return
def l1llll1l11111_l1_(file):
	if file==favoritesfile: l1lll1lllll1l_l1_ = l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ寛")
	elif file==l1l11l1l1l11_l1_: l1lll1lllll1l_l1_ = l11ll1_l1_ (u"ࠪห้ืำศศ็ࠫ寜")
	elif file==l1l111l11ll_l1_: l1lll1lllll1l_l1_ = l11ll1_l1_ (u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ寝")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ寞"),l11ll1_l1_ (u"࠭ๅิฯࠪ察"),l11ll1_l1_ (u"ࠧฦื็หา࠭寠"),l11ll1_l1_ (u"ࠨะิ์ั࠭寡"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ寢"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨ寣")+l1lll1lllll1l_l1_+l11ll1_l1_ (u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫ寤"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭寥"),l11ll1_l1_ (u"࠭ࠧ實"),l11ll1_l1_ (u"ࠧࠨ寧"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ寨"),l11ll1_l1_ (u"ࠩࠪ審"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭寪"),l11ll1_l1_ (u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩ寫")+l1lll1lllll1l_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭寬"),l11ll1_l1_ (u"࠭ࠧ寭"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ寮"),l11ll1_l1_ (u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨ寯")+l1lll1lllll1l_l1_)
	return
def l1lll11l1l1l1_l1_():
	if kodi_version<18:
		message = l11ll1_l1_ (u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬ寰")+str(kodi_version)+l11ll1_l1_ (u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫ寱")
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ寲"),l11ll1_l1_ (u"ࠬ࠭寳"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ寴"),message)
		return
	l111l1l1l11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ寵"))
	l1l11ll11lll_l1_ = l1l1l1111ll1_l1_([l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ寶")])
	l1l11l111lll_l1_,l1llll11lll1l_l1_,l1llll11lllll_l1_,l1llll11llll1_l1_,l1llll11ll1ll_l1_,l1lll11ll1111_l1_,l1llll11lll11_l1_ = l1l11ll11lll_l1_[l11ll1_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ寷")]
	if l1l11l111lll_l1_ or l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ寸") not in str(l111l1l1l11_l1_):
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ对"),l11ll1_l1_ (u"ࠬ࠭寺"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ寻"),l11ll1_l1_ (u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ导"))
		succeeded = l1llll111lll1_l1_(l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ寽"),True)
		if not succeeded: return
	l11l1l11lll_l1_(True)
	return
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡨࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠪ࠭ࠏࠏࡩࡧࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࡃ࠽ࠨ࠷࠷࠸ࠬࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤฬ๊ใหษหอࠬࠐࠉࡦ࡮࡬ࡪࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅ࠿ࡀࠫ࠺࠻࠵ࠨ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠศๆุ์ึ࠭ࠊࠊࡧ࡯ࡷࡪࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤ๊า็้ๆฬࠫࠏࠏࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠴࠿ࠏࠉࠤࠢࡤࡲࡾࠦ࡯ࡵࡪࡨࡶࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࠋࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࠦ࠽ࠡࠩࠪࠎࠎࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡼࡩࡦࡹࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡤࡥࠣࡁࠥࡩ࡯࡯ࡰ࠱ࡧࡺࡸࡳࡰࡴࠫ࠭ࠏࠏࠉࡤࡱࡱࡲ࠳ࡺࡥࡹࡶࡢࡪࡦࡩࡴࡰࡴࡼࠤࡂࠦࡳࡵࡴࠍࠍࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࡹ࡭ࡪࡽ࡙ࠢࠡࡋࡉࡗࡋࠠࡷ࡫ࡨࡻࡒࡵࡤࡦࠢࡀࠤ࠶࠿࠷࠲࠳࠺ࠤࡀ࠭ࠩࠋࠋࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࡷ࡫ࡨࡻࠧࠦࡗࡉࡇࡕࡉࠥࡼࡩࡦࡹࡐࡳࡩ࡫ࠠ࠾ࠢ࠹࠺࠵࠾࠰ࠡ࠽ࠪ࠭ࠏࠏࠉࡤࡱࡱࡲ࠳ࡩ࡯࡮࡯࡬ࡸ࠭࠯ࠊࠊࠋࡦࡳࡳࡴ࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࡨࡰ࡮࡬ࠠࡤࡪࡲ࡭ࡨ࡫࠽࠾࠳࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠡ࠿ࠣࠫ࠺࠺࠴ࠨࠋࠦࠤࠧࡒࡩࡴࡶࠣࡉࡲࡧࡤࠣࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎ࡫࡬ࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠷ࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࠧ࠶࠷࠸ࠫࠎࠩࠠࠣࡉࡤࡰࡱ࡫ࡲࡺࡡࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩ࠯ࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠩࠋࠋࠥࠦࠧ対")
def l11l1l11lll_l1_(l1ll_l1_=True):
	l111l1l1l11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭寿"))
	if l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ尀") not in str(l111l1l1l11_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭封"),l11ll1_l1_ (u"࠭ࠧ専"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ尃"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭射"))
		return
	l1llll1l11l11_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ尅"),l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ将"),l11ll1_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ將"),l11ll1_l1_ (u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭專"))
	if not os.path.exists(l1llll1l11l11_l1_): return
	l1l111111l1_l1_ = open(l1llll1l11l11_l1_,l11ll1_l1_ (u"࠭ࡲࡣࠩ尉")).read()
	if kodi_version>18.99: l1l111111l1_l1_ = l1l111111l1_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ尊"))
	l1lll11l11lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ尋"),l1l111111l1_l1_,re.DOTALL)
	l1lll11ll11ll_l1_,l1lllll111l11_l1_ = l1lll11l11lll_l1_[0]
	l1llll1ll11ll_l1_ = l11ll1_l1_ (u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ尌")+l1lll11ll11ll_l1_+l11ll1_l1_ (u"ࠪ࠰ࠬ對")+l1lllll111l11_l1_+l11ll1_l1_ (u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭導")
	if l1ll_l1_:
		l1llll1ll1l11_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪ小"))
		if l1llll1ll1l11_l1_==l11ll1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ尐"): l11ll11111l_l1_ = l11ll1_l1_ (u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ少")
		elif l1llll1ll1l11_l1_==l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ尒"): l11ll11111l_l1_ = l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ尓")
		else: l11ll11111l_l1_ = l11ll1_l1_ (u"ࠪๆํอฦๆࠢฦาึ๏ࠧ尔")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ尕"),l11ll1_l1_ (u"่่ࠬศศ่ࠤศิั๊ࠩ尖"),l11ll1_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭尗"),l11ll1_l1_ (u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ尘"),l11ll1_l1_ (u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬ尙")+l11ll11111l_l1_,l11ll1_l1_ (u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ尚"))
		if choice==1: l1lll1llll1ll_l1_ = l11ll1_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭尛")
		elif choice==2: l1lll1llll1ll_l1_ = l11ll1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ尜")
		else: l1lll1llll1ll_l1_ = l11ll1_l1_ (u"ࠬ࠭尝")
	else:
		l1llll1ll1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ尞"))
		if   l1llll1ll1l11_l1_==l11ll1_l1_ (u"ࠧࠨ尟"): choice = 0
		elif l1llll1ll1l11_l1_==l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫ尠"): choice = 1
		elif l1llll1ll1l11_l1_==l11ll1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ尡"): choice = 2
		l1lll1llll1ll_l1_ = l1llll1ll1l11_l1_
	if   choice==0: l1lll1ll1ll1l_l1_ = l11ll1_l1_ (u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧ尢")
	elif choice==1: l1lll1ll1ll1l_l1_ = l11ll1_l1_ (u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨ尣")
	elif choice==2: l1lll1ll1ll1l_l1_ = l11ll1_l1_ (u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩ尤")
	else: return
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ尥"),l1lll1llll1ll_l1_)
	l1lll11lll1ll_l1_ = l11ll1_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨ尦")+l1lll1ll1ll1l_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ尧")+l1lllll111l11_l1_+l11ll1_l1_ (u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ尨")
	l11llll1l11_l1_ = l1l111111l1_l1_.replace(l1llll1ll11ll_l1_,l1lll11lll1ll_l1_)
	if kodi_version>18.99: l11llll1l11_l1_ = l11llll1l11_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ尩"))
	open(l1llll1l11l11_l1_,l11ll1_l1_ (u"ࠫࡼࡨࠧ尪")).write(l11llll1l11_l1_)
	LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ尫"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬ尬")+l1lll1ll1ll1l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ尭"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ尮"))
	return
def l1lll11lll11l_l1_():
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ尯"),l11ll1_l1_ (u"ࠪ็้อࠧ尰"),l11ll1_l1_ (u"๋ࠫ฿ๅࠨ就"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ尲"),l11ll1_l1_ (u"࠭ศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦรๅวุำฬืࠠใัํ้ࠥ࠴࠮࠯ࠢฦ์ࠥอๆห่้๋ࠢ๎ูࠡ็้ࠤฬูสฯัส้ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤศ๎ࠠๅัํ็๋ࠥิไๆฬࠤศิั๊ࠢอาฺࠦฬ่ษี็ࠥษๆห๋่ࠢฬࠦสฯืࠣฬ็๐ษࠡะ็ๆࠥอไๅ้ࠣࡠࡳࡢ࡮ࠡฯส์้ࠦสฮัํฯࠥอไษำ้ห๊าࠠฤ๊ࠣหฯ฻ไࠡสส่๊ฮัๆฮ่๊ࠣ฿ัโหࠣือฮࠠศๆุ่่๊ษࠡ฻้ำ่ࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำีࠡษ็ฮาี๊ฬษอࠤฬ๊ย็ࠢยࠫ尳"))
	if l1ll111lll_l1_==1: l1ll1l1l11l1_l1_()
	return
def l1lll1ll11l11_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ尴"),l11ll1_l1_ (u"ࠨࠩ尵"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ尶"),l11ll1_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭尷"))
	return
def l1llll11l11l1_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ尸")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫ尹")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ尺")
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟หี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ尻")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬ尼")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ尽")
	message = l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ尾")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ尿")+l1ll11l1l1l_l1_
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ局"),l11ll1_l1_ (u"࠭ࠧ屁"),message)
	return
def l1l111lll11_l1_(l1111l11l11_l1_):
	try: status = l111l11ll11_l1_(l1111l11l11_l1_,False)
	except: pass
	l1l1ll1l1l1l_l1_ = l11l1lll1ll_l1_(l1111l11l11_l1_)
	id,l1l11l1l111l_l1_,l1l11lll1lll_l1_,l111l1l11ll_l1_,l111l11l1l1_l1_,reason = l1l1ll1l1l1l_l1_[0]
	l1lllll1111l_l1_,l1lllll111l1_l1_ = l111l1l11ll_l1_.split(l11ll1_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ层"))
	l1ll11l1l1l_l1_,l111ll111ll1_l1_,l111ll111lll_l1_ = l111l11l1l1_l1_.split(l11ll1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭屃"))
	l1l1l11l11l1_l1_ = True
	while l1l1l11l11l1_l1_:
		l1lll1ll1l111_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ屄"),l11ll1_l1_ (u"ࠪาึ๎ฬࠨ居"),l11ll1_l1_ (u"ࠫศืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠩ屆"),l11ll1_l1_ (u"่ࠬวว็ฬࠤฬ๊สษำ฼ࠫ屇"),l11ll1_l1_ (u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢๅ้ࠥฮวๅฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอ่๊ࠢࠥา็ศิๆࠫ屈"),l1ll11l1l1l_l1_)
		if l1lll1ll1l111_l1_==2: l1lll1ll11lll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ屉"),l11ll1_l1_ (u"ࠨࠩ届"),l11ll1_l1_ (u"ࠩ฼์ิฯࠧ屋"),l11ll1_l1_ (u"ࠪࠫ屌"),l11ll1_l1_ (u"ࠫฬ๊วฺฬิห฻ูࠦๅ๋้ࠣอีรࠡษ็ฮอืูࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪ屍"),l111ll111ll1_l1_,l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩ屎"))
		elif l1lll1ll1l111_l1_==1: l1ll111ll111_l1_()
		else: l1l1l11l11l1_l1_ = False
	xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ屏"))
	return
def l1lll11lll111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ屐"),l11ll1_l1_ (u"ࠨࠩ屑"),l11ll1_l1_ (u"ࠩࠪ屒"),l11ll1_l1_ (u"ࠪืษอไࠨ屓"),l11ll1_l1_ (u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬ屔"))
	else: l1ll111lll_l1_ = True
	if l1ll111lll_l1_:
		succeeded = True
		if os.path.exists(l1ll1111l1l1_l1_):
			try: os.remove(l1ll1111l1l1_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭展"),l11ll1_l1_ (u"࠭ࠧ屖"),l11ll1_l1_ (u"ࠧࠨ屗"),l11ll1_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ屘"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ屙"),l11ll1_l1_ (u"ࠪࠫ屚"),l11ll1_l1_ (u"ࠫࠬ屛"),l11ll1_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ屜"))
	return
def l1llll111l111_l1_():
	l1lll1ll1lll1_l1_()
	l1llll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ屝"))
	message = {}
	message[l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ属")] = l11ll1_l1_ (u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ屟")
	message[l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ屠")] = l11ll1_l1_ (u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ屡")
	message[l11ll1_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ屢")] = l11ll1_l1_ (u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭屣")+str(l11llll11l1_l1_/60)+l11ll1_l1_ (u"࠭ࠠะไํๆฮࠦแใูࠪ層")
	l1lll1l1l1111_l1_ = message[l1llll1lll11l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ履"),l11ll1_l1_ (u"ࠨๅสุࠥ࠭屦")+str(l11llll11l1_l1_/60)+l11ll1_l1_ (u"ࠩࠣำ็๐โสࠩ屧"),l11ll1_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ屨"),l11ll1_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ屩"),l1lll1l1l1111_l1_,l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ屪"))
	if choice==0: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ屫")
	elif choice==1: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ屬")
	elif choice==2: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭屭")
	else: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠩࠪ屮")
	if l1lll1l11ll1l_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ屯"),l1lll1l11ll1l_l1_)
		l1lll1l11111l_l1_ = message[l1lll1l11ll1l_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ屰"),l11ll1_l1_ (u"ࠬ࠭山"),l11ll1_l1_ (u"࠭ࠧ屲"),l1lll1l11111l_l1_)
	return
def l1lll1l1lllll_l1_():
	message = {}
	message[l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ屳")] = l11ll1_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭屴")
	message[l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭屵")] = l11ll1_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ屶")
	message[l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ屷")] = l11ll1_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ屸")
	l1llll1l1l11l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭屹"))
	l1llll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ屺"))
	l1lll1l1l1111_l1_ = message[l1llll1lll11l_l1_]+l1llll1l1l11l_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ屻"),l11ll1_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ屼"),l11ll1_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ屽"),l11ll1_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ屾"),l1lll1l1l1111_l1_,l11ll1_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩ屿"))
	if choice==0: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ岀")
	elif choice==1: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ岁")
	elif choice==2: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭岂")
	if choice in [0,1]:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ岃"),l11ll1_l1_ (u"ࠪื๏ืแา࠼ࠣࠫ岄")+l1llll1ll1ll_l1_[1],l11ll1_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ岅")+l1llll1ll1ll_l1_[0],l11ll1_l1_ (u"ࠬ࠭岆"),l11ll1_l1_ (u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ岇"))
		if l1ll111lll_l1_==1: l111ll111ll_l1_ = l1llll1ll1ll_l1_[0]
		else: l111ll111ll_l1_ = l1llll1ll1ll_l1_[1]
	elif choice==2: l111ll111ll_l1_ = l11ll1_l1_ (u"ࠧࠨ岈")
	else: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠨࠩ岉")
	if l1lll1l11ll1l_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ岊"),l1lll1l11ll1l_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ岋"),l111ll111ll_l1_)
		l1lll1l11111l_l1_ = message[l1lll1l11ll1l_l1_]+l111ll111ll_l1_
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ岌"),l11ll1_l1_ (u"ࠬ࠭岍"),l11ll1_l1_ (u"࠭ࠧ岎"),l1lll1l11111l_l1_)
	return
def l1lll1lll1ll1_l1_():
	l1llll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ岏"))
	message = {}
	message[l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭岐")] = l11ll1_l1_ (u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪ岑")
	message[l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ岒")] = l11ll1_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ岓")
	message[l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ岔")] = l11ll1_l1_ (u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ岕")
	l1lll1l1l1111_l1_ = message[l1llll1lll11l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ岖"),l11ll1_l1_ (u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭岗"),l11ll1_l1_ (u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ岘"),l11ll1_l1_ (u"ࠪษ๏่วโࠢๆห๊๊ࠧ岙"),l1lll1l1l1111_l1_,l11ll1_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧ岚"))
	if choice==0: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠬࡇࡓࡌࠩ岛")
	elif choice==1: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"࠭ࡁࡖࡖࡒࠫ岜")
	elif choice==2: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ岝")
	else: l1lll1l11ll1l_l1_ = l11ll1_l1_ (u"ࠨࠩ岞")
	if l1lll1l11ll1l_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ岟"),l1lll1l11ll1l_l1_)
		l1lll1l11111l_l1_ = message[l1lll1l11ll1l_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ岠"),l11ll1_l1_ (u"ࠫࠬ岡"),l11ll1_l1_ (u"ࠬ࠭岢"),l1lll1l11111l_l1_)
	return
def l1llll11l1111_l1_():
	l1l11l1ll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ岣"))
	if l1l11l1ll11l_l1_==l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ岤"): header = l11ll1_l1_ (u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧ岥")
	else: header = l11ll1_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧ岦")
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ岧"),l11ll1_l1_ (u"ࠫส๐โศใࠪ岨"),l11ll1_l1_ (u"ࠬะแฺ์็ࠫ岩"),header,l11ll1_l1_ (u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱ๋้ࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ岪"))
	if l1ll111lll_l1_==-1: return
	elif l1ll111lll_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ岫"),l11ll1_l1_ (u"ࠨࠩ岬"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ岭"),l11ll1_l1_ (u"ࠪࠫ岮"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ岯"),l11ll1_l1_ (u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ岰"))
	else:
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ岱"),l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ岲"))
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岳"),l11ll1_l1_ (u"ࠩࠪ岴"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭岵"),l11ll1_l1_ (u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭岶"))
	return
def l1lll1ll1llll_l1_(text):
	if text!=l11ll1_l1_ (u"ࠬ࠭岷"):
		text = l1l1l11lll1_l1_(text)
		text = text.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ岸")).encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ岹"))
		l1l1l1l111l_l1_ = 10103
		l1l1l11llll_l1_ = xbmcgui.l1l1l111lll_l1_(l1l1l1l111l_l1_)
		l1l1l11llll_l1_.getControl(311).l1l1l1l1l11_l1_(text)
		#l1l1l111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡌࡧࡼࡦࡴࡧࡲࡥ࠴࠵࠲ࡽࡳ࡬ࠨ岺"), xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ岻")).decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ岼")),l11ll1_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ岽"),l11ll1_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ岾"))
		#l1l1l111l1l1_l1_.show()
		#l1l1l111l1l1_l1_.getControl(99991).setPosition(0,0)
		#l1l1l111l1l1_l1_.getControl(311).l1l1l1l1l11_l1_(text)
		#l1l1l111l1l1_l1_.getControl(5).l1lll1l111ll_l1_(l1llll1l11l1l_l1_)
		#width = xbmcgui.l1lll1l11l11l_l1_()
		#l1ll11lll1ll_l1_ = xbmcgui.l1llll111111l_l1_()
		#resolution = (0.0+width)/l1ll11lll1ll_l1_
		#l1l1l111l1l1_l1_.getControl(5).l1l11lllll11_l1_(width-180)
		#l1l1l111l1l1_l1_.getControl(5).setHeight(l1ll11lll1ll_l1_-180)
		#l1l1l111l1l1_l1_.doModal()
		#del l1l1l111l1l1_l1_
	return
l1lll11ll1l1l_l1_ = [
			 l11ll1_l1_ (u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࠪࠫࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦ岿")
			,l11ll1_l1_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪ峀")
			,l11ll1_l1_ (u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪ峁")
			,l11ll1_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼࠫ峂")
			,l11ll1_l1_ (u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫ峃")
			,l11ll1_l1_ (u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭峄")
			,l11ll1_l1_ (u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠧࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪ峅")
			,l11ll1_l1_ (u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ峆")
			,l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫࠽࠱ࠨࡷࡩࡽࡺ࠽ࠨ峇")
			,l11ll1_l1_ (u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ峈")
			,l11ll1_l1_ (u"ࠩࡡࡢࡣࡤ࡞ࠨ峉")
			,l11ll1_l1_ (u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ峊")
			]
def l1lll1ll111l1_l1_(line):
	if l11ll1_l1_ (u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ峋") in line and l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ峌") in line: return True
	for text in l1lll11ll1l1l_l1_:
		if text in line: return True
	return False
def l1lll11l11l11_l1_(data):
	data = data.replace(l11ll1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ峍")+51*l11ll1_l1_ (u"ࠧࠡࠩ峎")+l11ll1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭峏"),l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ峐"))
	data = data.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭峑")+51*l11ll1_l1_ (u"ࠫࠥ࠭峒")+l11ll1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ峓"),l11ll1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ峔"))
	data = data.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ峕")+51*l11ll1_l1_ (u"ࠨࠢࠪ峖")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ峗"),l11ll1_l1_ (u"ࠪࡠࡳ࠭峘"))
	data = data.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ峙")+51*l11ll1_l1_ (u"ࠬࠦࠧ峚"),l11ll1_l1_ (u"࠭࡜࡯ࠩ峛")+31*l11ll1_l1_ (u"ࠧࠡࠩ峜"))
	#data = data.replace(l11ll1_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳࠳ࡆࡴࡤࡳࡱ࡬ࡨ࠴ࡪࡡࡵࡣ࠲ࡳࡷ࡭࠮ࡹࡤࡰࡧ࠳ࡱ࡯ࡥ࡫࠲ࡪ࡮ࡲࡥࡴ࠱࠱࡯ࡴࡪࡩ࠰ࡣࡧࡨࡴࡴࡳ࠰ࠩ峝"),l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨࠧ峞"))
	data = data.replace(l11ll1_l1_ (u"ࠪࠤࡁ࡭ࡥ࡯ࡧࡵࡥࡱࡄ࠺ࠡࠩ峟"),l11ll1_l1_ (u"ࠫ࠿ࠦࠧ峠"))
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠬ࠭峡")
	for line in data.splitlines():
		delete = re.findall(l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠬ࠳࠰࠿ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠯ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ峢"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11ll1_l1_ (u"ࠧࠨ峣"))
		l11ll11l1_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ峤")+line
	#WRITE_THIS(l11ll1_l1_ (u"ࠩࠪ峥"),l11ll11l1_l1_)
	return l11ll11l1_l1_
def l1lll11ll111l_l1_(l1lll1lllll11_l1_):
	if l11ll1_l1_ (u"ࠪࡓࡑࡊࠧ峦") in l1lll1lllll11_l1_:
		l1llll1l1l1l1_l1_ = l1lll1l1ll1l_l1_
		header = l11ll1_l1_ (u"ࠫ็ืวยหࠣหู้ฬๅࠢส่็ี๊ๆࠢยࠫ峧")
	else:
		l1llll1l1l1l1_l1_ = l1lll111111l_l1_
		header = l11ll1_l1_ (u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้ำวๅ์ࠣรࠬ峨")
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ峩"),l11ll1_l1_ (u"ࠧࠨ峪"),l11ll1_l1_ (u"ࠨࠩ峫"),header,l11ll1_l1_ (u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ峬"))
	if l1ll111lll_l1_!=1: return
	l1lll11l1l111_l1_,counts = [],0
	size,count = l1l1l11lll_l1_(l1llll1l1l1l1_l1_)
	#size = os.path.getsize(l1llll1l1l1l1_l1_)
	file = open(l1llll1l1l1l1_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭峭"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ峮"))
	data = l1lll11l11l11_l1_(data)
	lines = data.split(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ峯"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ峰"))
		#if line.strip(l11ll1_l1_ (u"ࠧࠡࠩ峱"))==l11ll1_l1_ (u"ࠨࠩ峲"): continue
		ignore = l1lll1ll111l1_l1_(line)
		if ignore: continue
		line = line.replace(l11ll1_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠࡠࠩ峳"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ峴"))
		line = line.replace(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔ࠽ࠫ峵"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈ࠳࠴࠵࠶࡝ࡆࡔࡕࡓࡗࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ島"))
		l1lll1llllll1_l1_ = l11ll1_l1_ (u"࠭ࠧ峷")
		l1lll11ll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ峸"),line,re.DOTALL)
		if l1lll11ll1l11_l1_:
			line = line.replace(l1lll11ll1l11_l1_[0][0],l1lll11ll1l11_l1_[0][1]).replace(l1lll11ll1l11_l1_[0][2],l11ll1_l1_ (u"ࠨࠩ峹"))
			l1lll1llllll1_l1_ = l1lll11ll1l11_l1_[0][1]
		else:
			l1lll11ll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ峺"),line,re.DOTALL)
			if l1lll11ll1l11_l1_:
				line = line.replace(l1lll11ll1l11_l1_[0][1],l11ll1_l1_ (u"ࠪࠫ峻"))
				l1lll1llllll1_l1_ = l1lll11ll1l11_l1_[0][0]
		if l1lll1llllll1_l1_: line = line.replace(l1lll1llllll1_l1_,l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ峼")+l1lll1llllll1_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ峽"))
		l1lll11l1l111_l1_.append(line)
		if len(str(l1lll11l1l111_l1_))>50100: break
	l1lll11l1l111_l1_ = reversed(l1lll11l1l111_l1_)
	l1llll1l11l1l_l1_ = l11ll1_l1_ (u"࠭࡜࡯ࠩ峾").join(l1lll11l1l111_l1_)
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ峿"),l11ll1_l1_ (u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬ崀"),l1llll1l11l1l_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ崁"))
	return
def l1lll1l1lll11_l1_():
	l1llll1l1l1ll_l1_ = open(l1ll111l1ll1_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭崂")).read()
	if kodi_version>18.99: l1llll1l1l1ll_l1_ = l1llll1l1l1ll_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ崃"))
	l1llll1l1l1ll_l1_ = l1llll1l1l1ll_l1_.replace(l11ll1_l1_ (u"ࠬࡢࡴࠨ崄"),l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠨ崅"))
	l1l11ll11lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡸ࡟ࡨ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ崆"),l1llll1l1l1ll_l1_,re.DOTALL)
	for line in l1l11ll11lll_l1_:
		l1llll1l1l1ll_l1_ = l1llll1l1l1ll_l1_.replace(line,l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ崇")+line+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ崈"))
	DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫ崉"),l1llll1l1l1ll_l1_)
	return
def l1llll111llll_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭崊")
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩ崋")
	l111ll111ll1_l1_ = l11ll1_l1_ (u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩ崌")
	message = l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢࠪ崍")+l1ll11l1l1l_l1_+l11ll1_l1_ (u"ࠨࠢ࠱ࠤࠬ崎")+l111ll111ll1_l1_
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ崏"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭崐"),message,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ崑"))
	return
def l111ll11l11_l1_(l1ll1ll111l1_l1_,message,l1ll_l1_=True,url=l11ll1_l1_ (u"ࠬ࠭崒"),source=l11ll1_l1_ (u"࠭ࠧ崓"),text=l11ll1_l1_ (u"ࠧࠨ崔"),l111lllll1l1_l1_=l11ll1_l1_ (u"ࠨࠩ崕")):
	if l11ll1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ崖") in text: l1l11ll1111l_l1_ = True
	else: l1l11ll1111l_l1_ = False
	l1lll111lllll_l1_ = True
	if not l11llll1111_l1_(l11ll1_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ崗")):
		if l1ll_l1_:
			#if message.count(l11ll1_l1_ (u"ࠫࡡࡢ࡮ࠨ崘"))>1: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ崙")
			#else: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭崚")
			l1lll11llll11_l1_ = (l11ll1_l1_ (u"ࠧศๆึ฻ึࡀࠧ崛") in message and l11ll1_l1_ (u"ࠨษ็้่อๆ࠻ࠩ崜") in message and l11ll1_l1_ (u"ࠩส่๊๊แ࠻ࠩ崝") in message and l11ll1_l1_ (u"ࠪห้ิืฤࠩ崞") in message and l11ll1_l1_ (u"ࠫฬ๊ๅึัิ࠾ࠬ崟") in message)
			if not l1lll11llll11_l1_: l1lll111lllll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ崠"),l11ll1_l1_ (u"࠭ࠧ崡"),l11ll1_l1_ (u"ࠧࠨ崢"),l11ll1_l1_ (u"ࠨ้็ࠤฯืำๅ๊ࠢิ์ࠦวๅำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ崣"),message.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࡳ࠭崤"),l11ll1_l1_ (u"ࠪࡠࡳ࠭崥")))
	elif l1ll_l1_:
		message = l11ll1_l1_ (u"ࠫࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࠫ崦")
		l1llll1llll11_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ崧"),l11ll1_l1_ (u"࠭ࠧ崨"),l11ll1_l1_ (u"ࠧࠨ崩"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ崪")+l11ll1_l1_ (u"ࠩࠣࠤ࠶࠵࠵ࠨ崫"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ崬"))
		l1llll1lll1ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ崭"),l11ll1_l1_ (u"ࠬ࠭崮"),l11ll1_l1_ (u"࠭ࠧ崯"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ崰")+l11ll1_l1_ (u"ࠨࠢࠣ࠶࠴࠻ࠧ崱"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ崲"))
		l1llll1lll1l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ崳"),l11ll1_l1_ (u"ࠫࠬ崴"),l11ll1_l1_ (u"ࠬ࠭崵"),l11ll1_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭崶")+l11ll1_l1_ (u"ࠧࠡࠢ࠶࠳࠺࠭崷"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭崸"))
		l1llll1llllll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ崹"),l11ll1_l1_ (u"ࠪࠫ崺"),l11ll1_l1_ (u"ࠫࠬ崻"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ崼")+l11ll1_l1_ (u"࠭ࠠࠡ࠶࠲࠹ࠬ崽"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ崾"))
		l1lll111lllll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ崿"),l11ll1_l1_ (u"ࠩࠪ嵀"),l11ll1_l1_ (u"ࠪࠫ嵁"),l11ll1_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ嵂")+l11ll1_l1_ (u"ࠬࠦࠠ࠶࠱࠸ࠫ嵃"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ嵄"))
	if l1lll111lllll_l1_!=1:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嵅"),l11ll1_l1_ (u"ࠨࠩ嵆"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嵇"),l11ll1_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭嵈"))
		return False
	l1lllll111111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪ嵉"))
	message += l11ll1_l1_ (u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ嵊")+l11llll11ll_l1_+l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ嵋")
	message += l11ll1_l1_ (u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨ嵌")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧ嵍")+l1l111l1ll1_l1_+l11ll1_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࠨ嵎")
	message += l11ll1_l1_ (u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨ嵏")+l1lllll111111_l1_
	#l1l111l111l_l1_ = l11lll111ll_l1_(l11ll1_l1_ (u"ࠫ࠼࠼࠮࠷࠷࠱࠵࠸࠾࠮࠳࠵࠳ࠫ嵐"))
	l1lllll1ll11_l1_ = l11lll111ll_l1_()
	l1lllll1ll11_l1_ = QUOTE(l1lllll1ll11_l1_)
	if l1lllll1ll11_l1_: message += l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡐࡴࡩࡡࡵ࡫ࡲࡲ࠿ࠦࠧ嵑")+l1lllll1ll11_l1_
	if url: message += l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲ࡚ࡘࡌ࠻ࠢࠪ嵒")+url
	if source: message += l11ll1_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࡙࡯ࡶࡴࡦࡩ࠿ࠦࠧ嵓")+source
	message += l11ll1_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ嵔")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩฯหึ๐ࠠศๆศีุอไࠨ嵕"),l11ll1_l1_ (u"ࠪห้ืฬศรࠣห้อๆหฺสีࠬ嵖"))
	if l111lllll1l1_l1_:
		l1llll1l11l1l_l1_ = l111lllll1l1_l1_
		if kodi_version>18.99: l1llll1l11l1l_l1_ = l1llll1l11l1l_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嵗"))
		l1llll1l11l1l_l1_ = base64.b64encode(l1llll1l11l1l_l1_)
	elif l1l11ll1111l_l1_:
		if l11ll1_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬ嵘") in text: l1llll1lll111_l1_ = l1lll1l1ll1l_l1_
		else: l1llll1lll111_l1_ = l1lll111111l_l1_
		if not os.path.exists(l1llll1lll111_l1_):
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嵙"),l11ll1_l1_ (u"ࠧࠨ嵚"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嵛"),l11ll1_l1_ (u"ࠩึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ฿๐ัࠡ็๋ะํีࠧ嵜"))
			return False
		l1lll11l1l111_l1_,counts = [],0
		size,count = l1l1l11lll_l1_(l1llll1lll111_l1_)
		#size = os.path.getsize(l1llll1lll111_l1_)
		file = open(l1llll1lll111_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭嵝"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嵞"))
		data = l1lll11l11l11_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ嵟"))
			ignore = l1lll1ll111l1_l1_(line)
			if ignore: continue
			l1lll11ll1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࡞ࡧ࠯࠲࠮࡜ࡥ࠭࠰ࡠࡩ࠱ࠠ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭ࠬ࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭嵠"),line,re.DOTALL)
			if l1lll11ll1l11_l1_:
				line = line.replace(l1lll11ll1l11_l1_[0][0],l1lll11ll1l11_l1_[0][1]).replace(l1lll11ll1l11_l1_[0][2],l11ll1_l1_ (u"ࠧࠨ嵡"))
			else:
				l1lll11ll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ嵢"),line,re.DOTALL)
				if l1lll11ll1l11_l1_: line = line.replace(l1lll11ll1l11_l1_[0][1],l11ll1_l1_ (u"ࠩࠪ嵣"))
			l1lll11l1l111_l1_.append(line)
			if len(str(l1lll11l1l111_l1_))>121000: break
		l1lll11l1l111_l1_ = reversed(l1lll11l1l111_l1_)
		l1llll1l11l1l_l1_ = l11ll1_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ嵤").join(l1lll11l1l111_l1_)
		l1llll1l11l1l_l1_ = l1llll1l11l1l_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嵥"))
		l1llll1l11l1l_l1_ = base64.b64encode(l1llll1l11l1l_l1_)
	else: l1llll1l11l1l_l1_ = l11ll1_l1_ (u"ࠬ࠭嵦")
	url = l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭嵧")][2]
	payload = {l11ll1_l1_ (u"ࠧࡴࡷࡥ࡮ࡪࡩࡴࠨ嵨"):l1ll1ll111l1_l1_,l11ll1_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ嵩"):message,l11ll1_l1_ (u"ࠩ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪ嵪"):l1llll1l11l1l_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ嵫"),url,payload,l11ll1_l1_ (u"ࠫࠬ嵬"),l11ll1_l1_ (u"ࠬ࠭嵭"),l11ll1_l1_ (u"࠭ࠧ嵮"),l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡖࡉࡓࡊ࡟ࡆࡏࡄࡍࡑ࠳࠱ࡴࡶࠪ嵯"))
	#succeeded = response.succeeded
	html = response.content
	if l11ll1_l1_ (u"ࠨࠤࡶࡹࡨࡩࡥࡦࡦࡨࡨࠧࡀࠠ࠲࠮ࠪ嵰") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩอ้ࠥอไฦำึห้࠭嵱"),l11ll1_l1_ (u"ࠪฬ๋าวฮࠩ嵲"))
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嵳"),l11ll1_l1_ (u"ࠬ࠭嵴"),l11ll1_l1_ (u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠬ嵵"),l11ll1_l1_ (u"ࠧห็ࠣษึูวๅࠢส่ึูวๅหࠣฬ๋าวฮࠩ嵶"))
		else:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨๆ็วุ็ࠧ嵷"),l11ll1_l1_ (u"ࠩไุ้ࠦแ๋ࠢส่สืำศๆࠪ嵸"))
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嵹"),l11ll1_l1_ (u"ࠫࠬ嵺"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嵻"),l11ll1_l1_ (u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫ嵼"))
	return succeeded
def l1lll11l1111l_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠧ࠲࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢࡷࡩࡽࡺࠠࡵࡪࡨࡲࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠬ嵽")
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠨ࠳࠱ࠤࠥࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์ࠣห้ษอาใࠣห้฿ัษ์ฬࠤๆอะ่สࠣห้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪ嵾")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嵿"),l11ll1_l1_ (u"ࠪࠫ嶀"),l11ll1_l1_ (u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬ嶁"),l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ嶂")+l1ll11l1l1l_l1_)
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"࠭࠲࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡨࡧ࡮࡝ࠩࡷࠤ࡫࡯࡮ࡥࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡪࡴࡴࡴࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡷࡰ࡯࡮ࠡࡣࡱࡨࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠬ嶃")
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠧ࠳࠰ࠣࠤࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใๅ้ࠥฮส฻์ํีࠥอไอๆาࠤะ๋ࠠใ็ࠣฬฯเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢส่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ嶄")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嶅"),l11ll1_l1_ (u"ࠩࠪ嶆"),l11ll1_l1_ (u"ࠪࡊࡴࡴࡴࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ嶇"),l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ嶈")+l1ll11l1l1l_l1_)
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ嶉"),l11ll1_l1_ (u"࠭ࠧ嶊"),l11ll1_l1_ (u"ࠧࠨ嶋"),l11ll1_l1_ (u"ࠨࡈࡲࡲࡹࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ嶌"),l11ll1_l1_ (u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠ࡯ࡱࡺࠤࡄ࠭嶍")+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ嶎")+l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥอไั้สฬࠥหไ๊ࠢ็์าฯࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥษไร่ยࠫ嶏"))
	if l1ll111lll_l1_==1: l1llll1l11ll1_l1_()
	return
def l1lllll111l1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嶐"),l11ll1_l1_ (u"࠭ࠧ嶑"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嶒"),l11ll1_l1_ (u"ࠨ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊า้ࠠๆ็ฮศ้ฯࠡไ่ࠤอะิ฻์็ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢ็หࠥ๐ูๆๆࠣฯ๊ࠦโๆࠢหษึูวๅุ่่๊ࠢษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢส่็อฦๆหࠣห้ืฦ๋ีํอ๊ࠥไษำ้ห๊าࠧ嶓"))
	return
def l1llll1ll1111_l1_():
	message = l11ll1_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ็ัฺูࠦแใู่้ࠣเษࠡษ็฽ึฮ๊ส๋่่ࠢ์่ࠠาสࠤ้อ๋ࠠ็้฽ࠥ๎ฬ้ั้ࠣํอโฺࠢไ๎์อࠠฤใ็ห๊่ࠦๆี็ื้อสࠡ็อีั๋ษࠡล๋ࠤ๊ีศๅฮฬࠤส๊้ࠡษ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡส่๎ࠦไ฻ษอࠤฬิั๊๋่ࠢฬ๊้ࠦฮาࠤุฮศࠡๆ็ฮ่ืวาࠩ嶔")
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嶕"),l11ll1_l1_ (u"ࠫࠬ嶖"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嶗"),message)
	return
def l1lll1lll11ll_l1_():
	message = l11ll1_l1_ (u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪ嶘")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嶙"),l11ll1_l1_ (u"ࠨࠩ嶚"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嶛"),message)
	return
def l1lll111llll1_l1_():
	message = l11ll1_l1_ (u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧ嶜")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嶝"),l11ll1_l1_ (u"ࠬ࠭嶞"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嶟"),l11ll1_l1_ (u"ࠧิ์ิๅึอสࠡีํสฮࠦร้่ࠢะ์๎ไสࠩ嶠"),message)
	return
def l1llll1l11lll_l1_():
	message = l11ll1_l1_ (u"ࠨษ็ื๏ืแาษอࠤฬู๊ศ็ฬࠤ์๐ࠠิ์ิๅึอสࠡะสีั๐ษ๊ࠡ฽๎ึࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥะำหะา้์อ้ࠠ฻สำฮࠦสไ๊้ࠤ๊าว็์ฬࠤํ๋ิศๅ็๋ฬࠦใฬ์ิอ๊ࠥว็ࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋้สࠤส๋วࠡสฺ๎หฯࠠฤ๊้๊ࠣ์ฺ่หࠣวํࠦๅฮา๋ๅฮࠦร้ࠢไ๎์อࠠๆึๆ่ฮࠦอใ๊ๅࠤฬ๊ๅๅๅํอࡡࡴ࡜࡯࡞ࡱหู้๊าใิหฯࠦวๅะสูฮࠦ็๋ࠢึ๎ึ็ัศฬࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไุ๋๋้ࠢะฮะ็ฬࠤๆ๐ࠠๆ๊สๆ฾ࠦโๅ์็อࠥาฯศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅะใ๋฽ฮࠦวๅลฯีࠥษ่ࠡ์่่่ํวࠡษ็้ํู่ࠡษ็วฺ๊๊๊ࠡ็๋ีอࠠโ้ํࠤั๐ฯส้ࠢือ๐ว๊ࠡึี๏฿ษุ๊่ࠡฬ้ไ่ษࠣๆ้๐ไสࠢฯำฬ࠭嶡")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ嶢"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嶣"),message,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ嶤"))
	return
def l1llll1111l11_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅัๅอࠥอไฺษ็๎ฮ࠭嶥")
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠฤๆࠣࡱ࠸ࡻ࠸ࠨ嶦")
	l111ll111ll1_l1_ = l11ll1_l1_ (u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ฮา๋๊ๅ๋ࠢห้ีว้่็์ิࠦࡤࡰࡹࡱࡰࡴࡧࡤࠨ嶧")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嶨"),l11ll1_l1_ (u"ࠩࠪ嶩"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嶪"),l1ll11l1l11_l1_,l1ll11l1l1l_l1_,l111ll111ll1_l1_)
	return
def l1lll1ll1lll1_l1_():
	l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬ嶫")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ嶬") + l11ll1_l1_ (u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬ嶭") + str(PERMANENT_CACHE/60/60/24/30) + l11ll1_l1_ (u"ࠧࠡึ๊ีࠬ嶮")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ嶯") + l11ll1_l1_ (u"ࠩ࠵࠲ࠥาฯศฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆ่ๅึ๎ึࠡล้๋ฬࠦไศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ嶰") + str(VERYLONG_CACHE/60/60/24) + l11ll1_l1_ (u"ࠪࠤ๏๎ๅࠨ嶱")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ嶲") + l11ll1_l1_ (u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ嶳") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"๋๊่࠭ࠠࠫ嶴")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嶵") + l11ll1_l1_ (u"ࠨ࠶࠱ࠤ๊ะ่ิูࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡไาࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪ嶶") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ࠩࠣืฬ฿ษࠨ嶷")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭嶸") + l11ll1_l1_ (u"ࠫ࠺࠴ࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢาหห๋ว๊่ࠡำฯํࠠࠨ嶹") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ࠬࠦำศ฻ฬࠫ嶺")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࠩ嶻") + l11ll1_l1_ (u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨ嶼") + str(l1ll11lll111_l1_/60) + l11ll1_l1_ (u"ࠨࠢาๆ๏่ษࠨ嶽")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ嶾") + l11ll1_l1_ (u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬ嶿") + str(NO_CACHE) + l11ll1_l1_ (u"ࠫࠥีโ๋ไฬࠫ巀")
	l1ll11l1l1l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ巁") + l11ll1_l1_ (u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪ巂") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨ巃") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧ巄") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭巅") + str(l1ll11lll111_l1_/60) + l11ll1_l1_ (u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬ巆") + str(NO_CACHE) + l11ll1_l1_ (u"ࠫࠥีโ๋ไฬࠫ巇")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ巈"),l11ll1_l1_ (u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫ巉"),l1ll11l1l1l_l1_,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ巊"))
	return
def l1lll11ll1lll_l1_():
	message = l11ll1_l1_ (u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫ巋")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ巌"),l11ll1_l1_ (u"ࠪࠫ巍"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ巎"),message)
	return
def l1lll1l111l11_l1_():
	message = l11ll1_l1_ (u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭巏")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ巐"),l11ll1_l1_ (u"ࠧࠨ巑"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ巒"),message)
	return
def l1llll11l11ll_l1_():
	message = l11ll1_l1_ (u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭巓")
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ巔"),l11ll1_l1_ (u"ࠫࠬ巕"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ巖"),message)
	return
def l1lll11llllll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ巗"),l11ll1_l1_ (u"ࠧࠨ巘"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ巙"),l11ll1_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ巚"))
	l11l11llll1_l1_(l11ll1_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ巛"),True)
	return
def l1lll1l1l1lll_l1_():
	message  = l11ll1_l1_ (u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭巜")
	#message += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๋๋ีอࠠศๆ฼หห่่๊ࠠࠣࡶࡪࡉࡁࡑࡖࡆࡌࡆࠦวๅะสูࠥฮิาๅฬࠤั๎ฬๅ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࠬ川")
	#message += l11ll1_l1_ (u"่࠭ศๆำ๎ࠥ฻ๆฺฬ๊ࠤูืใสࠢฯ์ั๊ࠠฯืํูฬࠦไๆ่฼ࠤอืวๆฮ้ࠣะ๊ࠠไ๊า๎๋ࠥๆࠡฬุๅาࠦวๅว้ฮึ์สࠨ州")
	message += l11ll1_l1_ (u"๊้ࠧࠡฮ๏าษࠡๆ๊ิฬࠦวๅ฻สส็ࠦแศ่๊ࠤฯ่ั๋สสࠤัฺ๋๊่ࠢืฯิฯๆ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡๆสࠤ๏ูสุ์฼์๋ࠦวๅัั์้ࠦไอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ัࠦอห๋้ࠣ฾ࠦวิฬัำฬ๋ࠧ巟")
	message += l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢๆࠠࠡࡘࡓࡒࠥࠦร้ࠢࠣࡔࡷࡵࡸࡺࠢࠣวํࠦࠠࡅࡐࡖࠤࠥษ่ࠡลํࠤา๊ࠠษีํ฻ࠥศฮา࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࠬ巠")
	message += l11ll1_l1_ (u"ࠩ࡟ࡲ้อๆ้ࠡำห๊ࠥๆࠡ์ะ่ࠥอไๆึๆ่ฮ่ࠦฦ่่หࠥ็โุࠢึ๎็๎ๅࠡสศู้ออࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฦ฻สๆฮࠦๅ้ษๅ฽ࠥอฮา๋ࠣ็ฬ์สࠡฬ฼้้ࠦำศสๅหࠥฮฯู้่้ࠣอใๅࠩ巡")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ巢"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ巣"),message,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ巤"))
	message = l11ll1_l1_ (u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩ工")
	message += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ左")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡰࡵࡡ࡮ࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠢࠣࡱࡴࡼࡩࡻ࡮ࡤࡲࡩࠦࠠࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭ࠦࠠࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ巧")
	message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ巨")+l11ll1_l1_ (u"ࠪห้ี่ๅࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ巩")
	message += l11ll1_l1_ (u"ࠫࡡࡴࠧ巪")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆืิࠤࠥอไไ๊ํฮࠥࠦรๆ์ิ็ฬࠦࠠไ่าหࠥࠦแา่ึหࠥࠦวๅ์๋๊ฬ์ࠠࠡสิ๎฼อๆ๋ษࠣห้หๅศำสฮࠥษไๆษ้๎ฬࠦั้ีํหࠥอไ๋ษหห๋ࠦวๅี฼์ิ๐ษࠡำ๋้ฬ์๊ศ๊ࠢ์้์ฯศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ巫")
	message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ巬")+l11ll1_l1_ (u"ࠧศๆ่ฬึ๋ฬ๊ࠡฯำࠥ฽ั๋ไฬࠤ้ะฬศ๊ีࠤฬู๊ศศๅࠤํ๊ใ็้สࠤฯำสศฮࠣะ์ีࠠไสํีࠥ๎วๅ็หี๊าฺ๋้ࠠࠤฬ๊ๅีๅ็อࠥ฻ฺ๋ำฬࠤํ๊วࠡฬึฮา่ࠠศๆอ฽อࠦแฦาสࠤ้ี๊ไุ่่๊ࠢษࠡสส่ิิ่ๅࠢ็ฬ฾฼ࠠศๆ่์ฬู่๊ࠡฦ๎฻อࠠๅๅํࠤ๏ะึฮࠢะะ๊ࠦวๅ็ื็้ฯࠠࠨ巭")
	message += l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠหึูไࠡำึห้ฯࠠๆฦาฬฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอใหสࠣๅ๏ํวࠡษึ้ࠥฮไะๅࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะำหูํ฽ࠥีฮ้ๆ๊หࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭差")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ巯"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭巰"),message,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ己"))
	#l1ll111ll111_l1_(l11ll1_l1_ (u"ࠬࡏࡳࡑࡴࡲࡦࡱ࡫࡭࠾ࡈࡤࡰࡸ࡫ࠧ已"))
	#message = l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ巳")+l11ll1_l1_ (u"้ࠧๆๅำ๊ࠥวฮฺ้หࠥอ๊ืษࠣว๋ࠦวๅ็๋ห็฿ࠠศๆ่฽ฬ่ษࠡฬัฮ้็ࠠษษัฮ้อแࠡษ็ฬ้ี้ࠠฬัฮ้็ࠠษษัฮ้อแࠡึิ็ฮࠦวๅษ้ฮึ์๊หࠢไ๎ࠥึไไࠢส่อ๊ฯ๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆ่ࠢะฮ๎ࠦไ้ࠢอ้ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦࡐࡳࡱࡻࡽࠥษ่ࠡลํࠤํู๊ๅหࠣหำื้ࠡใส๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠิ๊ไࠤฯิสๅใࠣ์้้ๆ่ษ่๋ࠣࠦสฺ็็ࠤัฺ๋๊้สࠫ巴")
	#message += l11ll1_l1_ (u"ࠨๆะ่ࠥอไๆึๆ่ฮࠦโๆࠢห฽๊๊๊็࠼ࠣࠤࠥࠦวๅล๋่࠿ࠦราี็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ๋࠭ๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๋ࠪࠢห่ะศࠡ็฼๋ࠥอำๆࠢห่ิ้้ࠠษึฺ้ࠥัไหࠣห้หๆหำ้๎ฯ่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠫ巵")
	#message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ巶")+l11ll1_l1_ (u"ࠪ์ฬ๊หศ่ํ࠾ࠥาัษࠢสืฯิฯศ็࡚ࠣࡕࡔ้ࠠ฻้ำࠥอไษ฻ูࠤ็ีࠠหฯอหัࠦแใูࠣฮ฿๐๊าࠢࡇࡒࡘ่ࠦศๆฦัุ์ࠠฤ่ࠣ๎่๎ๆࠡใํࠤอ๊ฯࠡษัีࠥ฿ไๆษࠣห๋ࠦวิฬัำฬ๋ࠠࡑࡴࡲࡼࡾࠦโะࠢํั้ࠦๅีๅ็อࠥฮูืࠢส่๊๎วใ฻ࠣ์้้ๆࠡๆํืࠥ็๊ࠡฮ่๎฾ࠦวๅั๋่ࠬ巷")
	#DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ฺ๊ࠫใๅหࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠪ巸"),message)
	#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ巹"),l11ll1_l1_ (u"࠭แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠩ巺"),l11ll1_l1_ (u"่ࠧาสࠤฬ๊แฮื๋ࠣํࠦไๆ฻ิๅฮࠦ็ๅࠢสฺ่๊ใๅหู้๋ࠣࠦ็ัๆࠤฬ๋ࠠๆ่ࠣห้ฮั็ษ่ะ࠳ࠦำ๋ไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮแฮื้ࠣํอโฺ้้ࠣึะ๊็ࠢส่ศ๎ไ๊ࠢห์฻฿ใࠡษ็฻อ๐ู๋๋ࠢห้ัว็์ฬࠤออำหะาห๊ࠦศา๊ๆื๏ࠦๅอษ้๎ࠥอๆหࠢอาฯอั่่๊ࠢࠥอไใษษ้ฮࠦวๅฬํࠤุะุ่ำ่ࠣฬำโศ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืฟࠨ巻"),l11ll1_l1_ (u"ࠨࠩ巼"),l11ll1_l1_ (u"ࠩࠪ巽"),l11ll1_l1_ (u"ࠪ็้อࠧ巾"),l11ll1_l1_ (u"๋ࠫ฿ๅࠨ巿"))
	#if l1ll111lll_l1_==1:
	#l1lll1llll1l1_l1_()
	return
def l1lll1ll1l1l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭帀"),l11ll1_l1_ (u"࠭ࠧ币"),l11ll1_l1_ (u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧ市"),l11ll1_l1_ (u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢัำ๊อส้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲศ๎ࠠษษิืฬ๊ࠠศ์่๎้ࠦวๅ๋ࠣวิ์ว่ࠢࠣࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࡄ࡬ࡳࡡࡪ࡮࠱ࡧࡴࡳ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ布"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ帄"),l11ll1_l1_ (u"ࠪࠫ帅"),l11ll1_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ帆"),l11ll1_l1_ (u"ࠬ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳࡝ࡰ࡟ࡲ࠹࠺࠴࠵࠶ࠣ࠹࠺࠻࠵࠶ࠢ࠹࠺࠻࠼࠶ࡠ࠹࠺࠻࠼࠽ࠠ࠹࠺࠻࠼࠽ࠦ࠹࠺࠻࠼࠽ࠥࡇࡁࡂࡃࡄ࠵ࡤࡈࡂࡃࡄࡅ࠵ࡤࡉࡃࡄࡅࡆ࠵ࡤࡊࡄࡅࡆࡇ࠵ࡤࡋࡅࡆࡇࡈ࠵ࡤࡌࡆࡇࡈࡉ࠵ࡤࡍࡇࡈࡉࡊ࠵ࡤࡎࡈࡉࡊࡋ࠵ࡤࡏࡉࡊࡋࡌ࠵ࡤࡐࡊࡋࡌࡍ࠵ࡤࡑࡋࡌࡍࡎ࠵ࡤࡒࡌࡍࡎࡏ࠵ࡤࡓࡍࡎࡏࡐ࠵ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠࡂࡃࡄࡅࡆ࠸࡟ࡃࡄࡅࡆࡇ࠸࡟ࡄࡅࡆࡇࡈ࠸࡟ࡅࡆࡇࡈࡉ࠸࡟ࡆࡇࡈࡉࡊ࠸࡟ࡇࡈࡉࡊࡋ࠸࡟ࡈࡉࡊࡋࡌ࠸࡟ࡉࡊࡋࡌࡍ࠸࡟ࡊࡋࡌࡍࡎ࠸࡟ࡋࡌࡍࡎࡏ࠸ࠠ࠱࠲࠳࠴࠵ࠦ࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵ࠤ࠸࠹࠳࠴࠵ࠣ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼ࠠ࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃࠣࡆࡇࡈࡂࡃࠩ帇"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ师"),l11ll1_l1_ (u"ࠧࠨ帉"),l11ll1_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ帊"),l11ll1_l1_ (u"ࠩ࠳ࠤ࠵ࠦ࠰ࠡ࠲ࠣ࠴ࠥ࠷ࠠ࠲ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠴ࠣ࠶ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠸ࠦ࠳ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠵ࠢ࠷ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠹ࠥ࠻ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠶ࠡ࠸ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠺ࠤ࠼ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠾ࠠ࠹ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠻ࠣ࠽ࠥ࠿ࠠ࠺ࠢ࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ帋"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ希"),l11ll1_l1_ (u"ࠫࠬ帍"),l11ll1_l1_ (u"ࠬࡈࡂࡃࡄࡅࡆࡇࡈࡂࡃࠢࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ帎"),l11ll1_l1_ (u"࠭࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠬ帏"))
	#text = l11ll1_l1_ (u"ࠧࠩࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࠢࠬࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࠣࡳࠥࡶࠠࡲࠢࡵࠤࡸࠦࡴࠡࡷࠣࡺࠥࡽࠠࡹࠢࡼࠤࡿࠦ࠰ࠡ࠳ࠣ࠶ࠥ࠹ࠠ࠵ࠢ࠸ࠤ࠻ࠦ࠷ࠡ࠺ࠣ࠽ࠥࡧࠠࡣࠢࡦࠤࡩࠦࡥࠡࡨࠣ࡫ࠥ࡮ࠠࡪࠢ࡭ࠤࡰࠦ࡬ࠡ࡯ࠣࡲࠥࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠥࡼࠠࡸࠢࡻࠤࡾࠦࡺࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࡳࠥࡶࠠࡲࠢࡵࠤࡸࠦࡴࠡࡷࠪ帐")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ帑"),l11ll1_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ帒"),l11ll1_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ帓"),l11ll1_l1_ (u"ࠫ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹࠱࠳࠵࠷࠹࠭帔"),l11ll1_l1_ (u"ࠬ࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲࠳࠴࠵࠶࠷࠭帕"),text,l11ll1_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ帖"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ帗"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ帘"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ帙"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ帚"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ帛"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ帜"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ帝"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帞"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ帟"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ帠"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帡"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ帢"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭帣"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭帤"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帥"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ带"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帧"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帨"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ帩"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ帪"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭師"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ帬"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡠࡳࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ席"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ帮"))
	return
def l1lll1ll11ll1_l1_():
	l1lll1ll1lll1_l1_()
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ帯"),l11ll1_l1_ (u"ࠫࠬ帰"),l11ll1_l1_ (u"ࠬ࠭帱"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪ帲"),l11ll1_l1_ (u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬ่ࠦศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯ่ࠦศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ帳"))
	if l1ll111lll_l1_==1:
		l11l11111l1_l1_(True)
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ帴"),l11ll1_l1_ (u"ࠩࠪ帵"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪ帶"),l11ll1_l1_ (u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ帷"))
	return l1ll111lll_l1_
def l1lll1ll111l_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ常"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬ帹"),l11ll1_l1_ (u"ࠧࠨ帺"),l11ll1_l1_ (u"ࠨࠩ帻"),False,l11ll1_l1_ (u"ࠩࠪ帼"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭帽"))
	#html = response.content
	if not response.succeeded:
		l1lll1l1l1l11_l1_ = False
		l11l1llll1_l1_ = l11l1l1lll_l1_()
		LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ帾"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝ࠪ帿")+l11l1llll1_l1_+l11ll1_l1_ (u"࠭࡝ࠨ幀"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ幁"),l11ll1_l1_ (u"ࠨࠩ幂"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ幃"),l11ll1_l1_ (u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧ幄"))
	else:
		l1lll1l1l1l11_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ幅"),l11ll1_l1_ (u"ࠬ࠭幆"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ幇"),l11ll1_l1_ (u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ幈"))
	if not l1lll1l1l1l11_l1_ and l1ll_l1_: l1llll11111l1_l1_()
	return l1lll1l1l1l11_l1_
def l1llll11111l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ幉"),l11ll1_l1_ (u"ࠩࠪ幊"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幋"),l11ll1_l1_ (u"ࠫอ฿ึࠡษ็้ํอโฺࠢอัฯอฬࠡำห฻๋ࠥิโำࠣ์็ี๋ࠠๅ๋๊ࠥา็ศิๆࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣห้ืศุࠢสฺ่๊แาࠢฦ์ࠥํๆศๅู้้ࠣไสࠢไ๎ฺࠥ็ศัฬࠤฬ๊สีใํีࠥอไฯษุอࠥฮใ้ัํࠤ฾์ฯไࠢ฼่๊อࠠศ่๊ࠤฯ๋ࠠโฯุࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣ็ํี๊ࠡษ็ษฺีวาษอࠤࡡࡴࠠ࠲࠹࠱࠺ࠥࠦࠦࠡࠢ࠴࠼࠳ࡡ࠰࠮࠻ࡠࠤࠥࠬࠠࠡ࠳࠼࠲ࡠ࠶࠭࠴࡟ࠪ幌"))
	#l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ฺࠬ็ศัฬࠤฬ๊สีใํีࠥํ๊ࠡ็็ๅࠥ๐อห๊ํࠤ฾๊้ࠡึไีฮࠦฮศืฬࠤศ๎ࠠห๊สๆ๏฿ࠠฯษุอ๊ࠥิาๅสฮู๋ࠥา๊ไอࠥ๎ไ่ࠢอหึ๐ฮࠡื็หา๐ษ๊้ࠡๅฬึ้ࠠษ็฾ึ฼ࠠๆ่๊ࠤ์๎ࠠหสสำ้ࠦวๅ็฼่ํ๋วหࠢห฻ึ๐โสุ่ࠢๆืษࠡ์ุ฽อࠦวฯฬิห็ํว๊ࠡไ๋๊ํวࠨ幍")
	l1llll11l1l11_l1_()
	return
def l1ll111ll111_l1_(text=l11ll1_l1_ (u"࠭ࠧ幎")):
	l1l11ll1111l_l1_ = True
	if l11ll1_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ幏") not in text:
		l1l11ll1111l_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ幐"),l11ll1_l1_ (u"ࠩัีําࠧ幑"),l11ll1_l1_ (u"ࠪษึูวๅุ่่๊ࠢษࠨ幒"),l11ll1_l1_ (u"ࠫสืำศๆࠣีุอไสࠩ幓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ幔"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩ幕"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l11ll1111l_l1_ = True
			text = l11ll1_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ幖")
	if l1l11ll1111l_l1_:
		#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ幗"),l11ll1_l1_ (u"ࠩࠪ幘"),l11ll1_l1_ (u"ࠪࠫ幙"),l11ll1_l1_ (u"ࠫสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬ幚"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํืฯ฽ฺ๊ࠢส่๊ฮัๆฮ้ࠣ฾ืแสࠢสฺ่๊ใๅหࠣ์ส฻ไศฯ๊หࠬ幛"))
		#if not l1ll111lll_l1_:
		#	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ幜"),l11ll1_l1_ (u"ࠧࠨ幝"),l11ll1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫ幞"),l11ll1_l1_ (u"ࠩ็่ศูแࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ幟"))
		#	return
		l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࡸࡪࡾࡴࠡ࠭ࡀࠤࠬࡲ࡯ࡨࡵࡀࡽࡪࡹࠧࠋࠋࠌࠍࡾ࡫ࡳࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢ࡝ࡊ࡙ࡎࡐࠪࠪࡧࡪࡴࡴࡦࡴࠪ࠰ࠬํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠫ࠱࠭โษๆࠣหึูวๅࠢึะ้ࠦวๅษั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ฼่๏้ࠠศ่ࠣฮ็๎ๅࠡสอุ฿๐ไࠡษ็ๅ๏ี๊้ࠢส์ࠥอไาษห฻ࠥอไั์ࠣ๎฾฽๊ไࠢสฺ่๊ใๅห่่ࠣ๐๋ࠠฬ่ࠤฯูฬ๋ๆࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊วฯูสลࠥ๎วๅษึฮำีวๆ࠰๋้ࠣࠦสา์าࠤฬ๊วาีส่ࠥอไศ่ࠣรࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ใๅษࠪ࠰ࠬ์ูๆࠩࠬࠎࠎࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠲࠽ࠎࠎࠏࠉࠊࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧห็ࠣห้เวยࠢส่ฬืำศๆࠪ࠭ࠏࠏࠉࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࠪࠫࠏࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ࠱࠭วัษࠣ็ฬ์สࠡๆา๎่ࠦๅีๅ็อࠥ็วๅำฯหฦࠦโาษฤอ่ࠥำๆࠢสฺ่๊วไๆࠣ์ฬ๊วิศ็อࠥ๎วัษ่๊ࠣࠦสอัࠣห้ำไ้้ࠡห่ࠦแฮษ๋่้ࠥสศสฬࠤัฺ๋๊ࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅห่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨࠫࠍࠍࠎࠨࠢࠣ幠")
		if l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫ幡") not in text:
			l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ幢"),l11ll1_l1_ (u"࠭ࠧ幣"),l11ll1_l1_ (u"ࠧࠨ幤"),l11ll1_l1_ (u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨ幥"),l11ll1_l1_ (u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩ幦"))
			if l1ll111lll_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ幧"),l11ll1_l1_ (u"ࠫࠬ幨"),l11ll1_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ幩"),l11ll1_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ幪"))
				return
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ幫"),l11ll1_l1_ (u"ࠨࠩ幬"),l11ll1_l1_ (u"ࠩๆฮฬฮษ๊ࠡืีาࠦวๅ็ฺ๋ํ฿ࠠๅๆ่ฬึ๋ฬࠨ幭"),l11ll1_l1_ (u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ห๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ幮"))
	search = OPEN_KEYBOARD(header=l11ll1_l1_ (u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬ幯"),source=script_name)
	if not search: return
	message = search
	if l1l11ll1111l_l1_: type = l11ll1_l1_ (u"ࠬ࠳ࡐࡳࡱࡥࡰࡪࡳࠧ幰")
	else: type = l11ll1_l1_ (u"࠭࠭ࡎࡧࡶࡷࡦ࡭ࡥࠨ幱")
	l1ll1ll111l1_l1_ = l11ll1_l1_ (u"ࠧࡂࡘ࠽ࠤࠬ干")+l1l11l11l11_l1_(32)+type
	succeeded = l111ll11l11_l1_(l1ll1ll111l1_l1_,message,True,l11ll1_l1_ (u"ࠨࠩ平"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬ年"),text)
	#	url = l11ll1_l1_ (u"ࠪࡱࡾࠦࡁࡑࡋࠣࡥࡳࡪ࠯ࡰࡴࠣࡗࡒ࡚ࡐࠡࡵࡨࡶࡻ࡫ࡲࠨ幵")
	#	payload = l11ll1_l1_ (u"ࠫࢀࠨࡡࡱ࡫ࡢ࡯ࡪࡿࠢ࠻ࠤࡐ࡝ࠥࡇࡐࡊࠢࡎࡉ࡞ࠨࠬࠣࡶࡲࠦ࠿ࡡࠢ࡮ࡧࡃࡩࡲࡧࡩ࡭࠰ࡦࡳࡲࠨ࡝࠭ࠤࡶࡩࡳࡪࡥࡳࠤ࠽ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥ࠰ࠧࡹࡵࡣ࡬ࡨࡧࡹࠨ࠺ࠣࡈࡵࡳࡲࠦࡁࡳࡣࡥ࡭ࡨࠦࡖࡪࡦࡨࡳࡸࠨࠬࠣࡶࡨࡼࡹࡥࡢࡰࡦࡼࠦ࠿ࠨࠧ并")+message+l11ll1_l1_ (u"ࠬࠨࡽࠨ幷")
	#	#auth=(l11ll1_l1_ (u"ࠨࡡࡱ࡫ࠥ幸"), l11ll1_l1_ (u"ࠢ࡮ࡻࠣࡴࡪࡸࡳࡰࡰࡤࡰࠥࡧࡰࡪࠢ࡮ࡩࡾࠨ幹")),
	#	import requests
	#	response = requests.request(l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭幺"),url, data=payload, headers=l11ll1_l1_ (u"ࠩࠪ幻"), auth=l11ll1_l1_ (u"ࠪࠫ幼"))
	#	response = requests.post(url, data=payload, headers=l11ll1_l1_ (u"ࠫࠬ幽"), auth=l11ll1_l1_ (u"ࠬ࠭幾"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ广"),l11ll1_l1_ (u"ࠧࠨ庀"),l11ll1_l1_ (u"ࠨࠩ庁"),l11ll1_l1_ (u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬ庂"))
	#	else:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ広"),l11ll1_l1_ (u"ࠫࠬ庄"),l11ll1_l1_ (u"ࠬิืฤࠢไ๎ࠥอไฦำึห้࠭庅"),l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࢁࡽ࠻ࠢࡾࠥࡷࢃࠧ庆").format(response.status_code, response.content))
	#	l1lll1l11lll1_l1_ = l11ll1_l1_ (u"ࠧ࡮ࡧࡃࡩࡲࡧࡩ࡭࠰ࡦࡳࡲ࠭庇")
	#	l1lll1ll1l11l_l1_ = l11ll1_l1_ (u"ࠨ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠧ庈")
	#	header = l11ll1_l1_ (u"ࠩࠪ庉")
	#	#header += l11ll1_l1_ (u"ࠪࡊࡷࡵ࡭࠻ࠢࠪ床") + l1lll1l11lll1_l1_
	#	#header += l11ll1_l1_ (u"ࠫࡡࡴࡔࡰ࠼ࠣࠫ庋") + l1lll111lll1l_l1_
	#	#header += l11ll1_l1_ (u"ࠬࡢ࡮ࡄࡥ࠽ࠤࠬ庌") + l1lll111lll1l_l1_
	#	header += l11ll1_l1_ (u"࠭࡜࡯ࡕࡸࡦ࡯࡫ࡣࡵ࠼้๋ࠣࠦใ้ัํࠤฬ๊แ๋ัํ์ࠥอไฺำห๎ࠬ庍")
	#	server = l1llll1ll1l1l_l1_.l1lll1l1ll11l_l1_(l11ll1_l1_ (u"ࠧࡴ࡯ࡷࡴ࠲ࡹࡥࡳࡸࡨࡶࠬ庎"),25)
	#	#server.l1lll1lll1l1l_l1_()
	#	server.l1lll1llll11l_l1_(l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࠪ序"),l11ll1_l1_ (u"ࠩࡳࡥࡸࡹࡷࡰࡴࡧࠫ庐"))
	#	response = server.l1llll111l1l1_l1_(l1lll1l11lll1_l1_,l1lll1ll1l11l_l1_, header + l11ll1_l1_ (u"ࠪࡠࡳ࠭庑") + message)
	#	server.quit()
	return
def l1llll11ll1l1_l1_():
	text = l11ll1_l1_ (u"ࠫ์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊้ࠦฮาࠤ้ํࠠฤ์ࠣื๏ืแาࠢํืฯ฼๊โࠢฦ๎๋ࠥอห๊ํหฯ࠴ࠠศๆหี๋อๅอࠢํืฯิฯๆࠢิ์ฬฮื๊ࠡอฺ๊๐ๆࠡๆ่ัฯ๎๊ศฬ้ࠣึ็ฺ่หࠣ฽้๏ࠠิ์ิๅึอสࠡะสีั๐ษ࠯ࠢส่อืๆศ็ฯࠤ฿๐ัࠡ็ึศํฺ๊่ࠠࠣว๏ࠦๅฮฬ๋๎ฬะࠠห็ࠣฮา๋๊ๅ้สࠤ฾๊้ࠡีํีๆืวห๋้ࠢํอโฺࠢัหึา๊ส้ࠢࠥํอโฺฺࠢีๆࠦหศๆฮࠦ࠳ࠦฬๆ์฼ࠤฬ๊ริ็สลࠥ๎วๅ็สี่อส๊ࠡสฺ่๎ั๊ࠡส่๊์ิ้ำสฮࠥํ๊ࠡะสูฮࠦศศืะหอํว࠯ࠢส่อืๆศ็ฯࠤ้อ๋่ࠠอ๋่ࠦอใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮࠦࡄࡎࡅࡄࠤสึวࠡๅส๊๊ࠥฯ๋ๅุ่ࠣ๎้ࠡะสูฮࠦศศๆิ์ฬฮื๊ࠡส่ฯ฼วๆ์้ࠤฬ๊ฮศำฯ๎ฮࠦแศๆิะฬวࠠศๆอ์ฬ฻ไࠡ็฼ࠤสีวาห๋ࠣีํࠠศๆึ๎ึ็ัศฬࠣ์ฬ๊ๅ้ษๅ฽ࠥอไฯษิะ๏ฯ࠮้ࠡำหࠥอไษำ้ห๊า่๊ࠠࠣฬอูวุห้ࠣฯ฻แฮࠢ็้ํอโฺࠢส่ํ๐ศࠨ庒")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ库"),l11ll1_l1_ (u"࠭อใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮ࠭应"),text,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ底"))
	text = l11ll1_l1_ (u"ࠨࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢ࡫ࡳࡸࡺࠠࡢࡰࡼࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡵ࡮ࠡࡣࡱࡽࠥࡹࡥࡳࡸࡨࡶ࠳ࠦࡉࡵࠢࡲࡲࡱࡿࠠࡶࡵࡨࡷࠥࡲࡩ࡯࡭ࡶࠤࡹࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡸ࡭ࡧࡴࠡࡹࡤࡷࠥࡻࡰ࡭ࡱࡤࡨࡪࡪࠠࡵࡱࠣࡴࡴࡶࡵ࡭ࡣࡵࠤࡴࡴ࡬ࡪࡰࡨࠤࡻ࡯ࡤࡦࡱࠣ࡬ࡴࡹࡴࡪࡰࡪࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡆࡲ࡬ࠡࡶࡵࡥࡩ࡫࡭ࡢࡴ࡮ࡷ࠱ࠦࡶࡪࡦࡨࡳࡸ࠲ࠠࡵࡴࡤࡨࡪࠦ࡮ࡢ࡯ࡨࡷ࠱ࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠ࡮ࡣࡵ࡯ࡸ࠲ࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࡨࡨࠥࡽ࡯ࡳ࡭࠯ࠤࡱࡵࡧࡰࡵࠣࡶࡪ࡬ࡥࡳࡧࡱࡧࡪࡪࠠࡩࡧࡵࡩ࡮ࡴࠠࡣࡧ࡯ࡳࡳ࡭ࠠࡵࡱࠣࡸ࡭࡫ࡩࡳࠢࡵࡩࡸࡶࡥࡤࡶ࡬ࡺࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡥࡲࡱࡵࡧ࡮ࡪࡧࡶ࠲࡚ࠥࡨࡦࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡶ࡭ࡧࡲࡥࠡࡨࡲࡶࠥࡽࡨࡢࡶࠣࡳࡹ࡮ࡥࡳࠢࡳࡩࡴࡶ࡬ࡦࠢࡸࡴࡱࡵࡡࡥࠢࡷࡳࠥ࠹ࡲࡥࠢࡳࡥࡷࡺࡹࠡࡵ࡬ࡸࡪࡹ࠮࡙ࠡࡨࠤࡺࡸࡧࡦࠢࡤࡰࡱࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡲࡻࡳ࡫ࡲࡴ࠮ࠣࡸࡴࠦࡲࡦࡥࡲ࡫ࡳ࡯ࡺࡦࠢࡷ࡬ࡦࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬ࡵࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡷࡪࡶ࡫࡭ࡳࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡧࡲࡦࠢ࡯ࡳࡨࡧࡴࡦࡦࠣࡷࡴࡳࡥࡸࡪࡨࡶࡪࠦࡥ࡭ࡵࡨࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࠡࡱࡵࠤࡻ࡯ࡤࡦࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡧࡲࡦࠢࡩࡶࡴࡳࠠࡰࡶ࡫ࡩࡷࠦࡶࡢࡴ࡬ࡳࡺࡹࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡧ࡮ࡺࠢ࡯ࡩ࡬ࡧ࡬ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡲ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡤࡴࡵࡸ࡯ࡱࡴ࡬ࡥࡹ࡫ࠠ࡮ࡧࡧ࡭ࡦࠦࡦࡪ࡮ࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡨࡰࡵࡷࡩࡷࡹ࠮ࠡࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡷ࡮ࡳࡰ࡭ࡻࠣࡥࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴ࠱ࠫ庖")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ店"),l11ll1_l1_ (u"ࠪࡈ࡮࡭ࡩࡵࡣ࡯ࠤࡒ࡯࡬࡭ࡧࡱࡲ࡮ࡻ࡭ࠡࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤࡆࡩࡴࠡࠪࡇࡑࡈࡇࠩࠨ庘"),text,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ庙"))
	return
def l1lll1lll1lll_l1_(addon_id):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭庚"),l11ll1_l1_ (u"࠭ࠧ庛"),l11ll1_l1_ (u"ࠧࠨ府"),addon_id)
	result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ庝")+addon_id+l11ll1_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨ庞"))
	l1l11lllll_l1_ = True
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡪ࡯ࡳࡳࡷࡺࠠࡴࡪࡸࡸ࡮ࡲࠊࠊࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡽࡨ࡭ࡤࡨࡲࡰࡩ࡫ࡲ࠭ࠩࡤࡨࡩࡵ࡮ࡴࠩ࠯ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮ࠐࠉࡪࡨࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲ࡪࡾࡩࡴࡶࡶࠬࡽࡨ࡭ࡤࡨ࡬ࡰࡪ࠯࠺ࠋࠋࠌࡷ࡭ࡻࡴࡪ࡮࠱ࡶࡲࡺࡲࡦࡧࠫࡼࡧࡳࡣࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡴࡨࡪࡷ࡫ࡳࡩࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࡹࡸ࡫ࡲࡧ࡫࡯ࡩࠥࡃࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡵࡴࡧࡵࡪࡴࡲࡤࡦࡴ࠯ࠫࡦࡪࡤࡰࡰࡶࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠋࠋ࡬ࡪࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮ࡵࡴࡧࡵࡪ࡮ࡲࡥࠪ࠼ࠍࠍࠎࡹࡨࡶࡶ࡬ࡰ࠳ࡸ࡭ࡵࡴࡨࡩ࠭ࡻࡳࡦࡴࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡶࡪ࡬ࡲࡦࡵ࡫ࠤࡂࠦࡔࡳࡷࡨࠎࠎࠩࡩ࡮ࡲࡲࡶࡹࠦࡳࡲ࡮࡬ࡸࡪ࠹ࠊࠊࡥࡲࡲࡳࠦ࠽ࠡࡵࡴࡰ࡮ࡺࡥ࠴࠰ࡦࡳࡳࡴࡥࡤࡶࠫࡥࡩࡪ࡯࡯ࡵࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡸࡪࡾࡴࡠࡨࡤࡧࡹࡵࡲࡺࠢࡀࠤࡸࡺࡲࠋࠋࡦࡧࠥࡃࠠࡤࡱࡱࡲ࠳ࡩࡵࡳࡵࡲࡶ࠭࠯ࠊࠊࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠤࠣ࠿ࠬ࠯ࠊࠊࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡦࡪࡤࡰࡰࡶࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࠩࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡵࡩࡵࡵࡳ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࡦࡳࡳࡴ࠮ࡤࡱࡰࡱ࡮ࡺࠨࠪࠌࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠦࠧࠨ废")
	if l1l11lllll_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ庠"))
		time.sleep(1)
	return
def l1llll11l111l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭庡"),l11ll1_l1_ (u"࠭ࠧ庢"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ庣"),l11ll1_l1_ (u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭庤"))
	l1llll11l11ll_l1_()
	return
def l1llll11l1l11_l1_():
	#	https://l11l1lll111_l1_.tv/download/849
	#   https://play.google.com/l1lll1ll1111l_l1_/l1lll1lll1l11_l1_/details?id=l1llll11l11_l1_.xbmc.l11l1lll111_l1_
	#	http://mirror.l1llll111ll1l_l1_.l1lll1l11llll_l1_.l1lllll1111ll_l1_/l1llll1111lll_l1_/xbmc/l1lll1l1lll1l_l1_/l1lll11l111ll_l1_/l1llll111l11l_l1_
	#	http://l1lll1l111111_l1_.l1lll11l1lll1_l1_.l1lllll1111ll_l1_/l11l1lll111_l1_/l1lll1l1lll1l_l1_/l1lll11l111ll_l1_/l1llll111l11l_l1_
	url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧ庥")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ度"),url,l11ll1_l1_ (u"ࠫࠬ座"),l11ll1_l1_ (u"ࠬ࠭庨"),l11ll1_l1_ (u"࠭ࠧ庩"),l11ll1_l1_ (u"ࠧࠨ庪"),l11ll1_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫ庫"))
	html = response.content
	l1lll11l1l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨ庬"),html,re.DOTALL)
	l1lll11l1l1ll_l1_ = l1lll11l1l1ll_l1_[0].split(l11ll1_l1_ (u"ࠪ࠱ࠬ庭"))[0]
	l1llll1lllll1_l1_ = str(kodi_version)
	#l111ll111lll_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ庮")+l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠๅษࠣ๎฾๋ไࠡ็฼ࠤ่๎ฯ๋ࠢศูิอัࠡ࠳࠼ࠤํ๋วࠡส฼ำ์࠭庯")+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ庰")
	l111ll111lll_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ศิ๊าࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ庱")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ庲")+l1lll11l1l1ll_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ庳")
	l111ll111lll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ庴")+l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่๊ࠢ์ࠥࡀࠠࠡࠢࠪ庵")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ庶")+l1llll1lllll1_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ康")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ庸"),l11ll1_l1_ (u"ࠨࠩ庹"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庺"),l111ll111lll_l1_)
	return
def l1lll1l1111ll_l1_():
	# https://l11l1ll1111_l1_-l111ll11l1l_l1_-l11l1111111_l1_.l1lllll11l1ll_l1_.com/request-l1lll1lll1111_l1_
	# https://l11l1ll1111_l1_-l111ll11l1l_l1_-l11l1111111_l1_.l1lllll11l1ll_l1_.com/query-l1lll11l1ll11_l1_
	l1ll11l1l11_l1_,l1ll11l1l1l_l1_,l111ll111ll1_l1_,l111ll111lll_l1_,l1llll11l1ll1_l1_,l1lll11l111l1_l1_,l1lll1l1ll1l1_l1_ = l11ll1_l1_ (u"ࠪࠫ庻"),l11ll1_l1_ (u"ࠫࠬ庼"),l11ll1_l1_ (u"ࠬ࠭庽"),l11ll1_l1_ (u"࠭ࠧ庾"),l11ll1_l1_ (u"ࠧࠨ庿"),l11ll1_l1_ (u"ࠨࠩ廀"),l11ll1_l1_ (u"ࠩࠪ廁")
	payload,l1lll11l1ll1l_l1_,l1llll1111ll1_l1_,l1lll11l11l1l_l1_ = {l11ll1_l1_ (u"ࠪࡥࠬ廂"):l11ll1_l1_ (u"ࠫࡦ࠭廃")},{},[],{}
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ廄")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ廅"),url,payload,l11ll1_l1_ (u"ࠧࠨ廆"),l11ll1_l1_ (u"ࠨࠩ廇"),l11ll1_l1_ (u"ࠩࠪ廈"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ廉"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ廊"),l11ll1_l1_ (u"࡛ࠬࡓࡂࠩ廋"))
	html = html.replace(l11ll1_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡋࡪࡰࡪࡨࡴࡳࠧ廌"),l11ll1_l1_ (u"ࠧࡖࡍࠪ廍"))
	html = html.replace(l11ll1_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨ廎"),l11ll1_l1_ (u"ࠩࡘࡅࡊ࠭廏"))
	html = html.replace(l11ll1_l1_ (u"ࠪࡗࡦࡻࡤࡪࠢࡄࡶࡦࡨࡩࡢࠩ廐"),l11ll1_l1_ (u"ࠫࡐ࡙ࡁࠨ廑"))
	html = html.replace(l11ll1_l1_ (u"ࠬࡔ࡯ࡳࡶ࡫ࠤࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧ廒"),l11ll1_l1_ (u"࠭ࡎ࠯ࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ廓"))
	html = html.replace(l11ll1_l1_ (u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨ廔"),l11ll1_l1_ (u"ࠨ࡙࠱ࡗࡦ࡮ࡡࡳࡣࠪ廕"))
	html = html.replace(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭廖"),l11ll1_l1_ (u"ࠪࠤࠥ࠭廗"))
	try: l1llll1111l1l_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ廘"),html)
	except:
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭廙"),l11ll1_l1_ (u"࠭ࠧ廚"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ廛"),l11ll1_l1_ (u"ࠨใื่ࠥ็๊ࠡฮ็ฬ๋ࠥอห๊ํหฯࠦสใำํีࠥอไศีอาิอๅࠨ廜"))
		return
	l1llll1l1lll1_l1_,l1lllll11111l_l1_,l1lll1ll1ll11_l1_ = l1llll1111l1l_l1_
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ廝"),str(l1llll1l1lll1_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ廞"),str(l1lllll11111l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ廟"),str(l1lll1ll1ll11_l1_))
	l1lll11l11l1l_l1_ = {}
	l1lllll11ll11_l1_ = [l11ll1_l1_ (u"ࠬࡇࡌࡍࠩ廠"),l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭廡"),l11ll1_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ廢"),l11ll1_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ廣"),l11ll1_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ廤")]+l1llllll1lll_l1_+l111l1lll11_l1_
	for l1ll111l11l_l1_,l1llll1ll1ll1_l1_,l1llll1l1ll11_l1_ in l1lllll11111l_l1_:
		l1llll1l1ll11_l1_ = escapeUNICODE(l1llll1l1ll11_l1_)
		l1llll1l1ll11_l1_ = l1llll1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ廥")).strip(l11ll1_l1_ (u"ࠫࠥ࠴ࠧ廦"))
		l111ll111lll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ廧")+l1ll111l11l_l1_+l11ll1_l1_ (u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廨")+l1llll1l1ll11_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ廩")
		if l1llll1ll1ll1_l1_.isdigit():
			l1lll11l11l1l_l1_[l1ll111l11l_l1_] = int(l1llll1ll1ll1_l1_)
			if int(l1llll1ll1ll1_l1_)>100: l1llll1ll1ll1_l1_ = l11ll1_l1_ (u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫ廪")
			else: l1llll1ll1ll1_l1_ = l11ll1_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ廫")
		if l1ll111l11l_l1_ not in l1lllll11ll11_l1_:
			if   l1llll1ll1ll1_l1_==l11ll1_l1_ (u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭廬"): l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࠥࠦࠧ廭")+l1ll111l11l_l1_
			elif l1llll1ll1ll1_l1_==l11ll1_l1_ (u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧ廮"): l1ll11l1l1l_l1_ += l11ll1_l1_ (u"࠭ࠠࠡࠩ廯")+l1ll111l11l_l1_
	l1lllll11l1l1_l1_,l1lll1l1l1l1l_l1_,l1lll1l1ll1ll_l1_ = list(zip(*l1lllll11111l_l1_))
	for l1ll111l11l_l1_ in sorted(l1l1lllllll1_l1_):
		if l1ll111l11l_l1_ not in l1lllll11l1l1_l1_:
			l111ll111lll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ廰")+l1ll111l11l_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ廱")+l11ll1_l1_ (u"ࠩ็หࠥ๐่อัࠪ廲")+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ廳")
			if l1ll111l11l_l1_ not in l1lllll11ll11_l1_: l111ll111ll1_l1_ += l11ll1_l1_ (u"ࠫࠥࠦࠧ廴")+l1ll111l11l_l1_
	for l1llll1l1ll11_l1_,counts in l1llll1l1lll1_l1_:
		l1llll1l1ll11_l1_ = escapeUNICODE(l1llll1l1ll11_l1_)
		l1llll11l1ll1_l1_ += l1llll1l1ll11_l1_+l11ll1_l1_ (u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ廵")+str(counts)+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫ延")
	l1ll11l1l11_l1_ = l1ll11l1l11_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ廷"))
	l1ll11l1l1l_l1_ = l1ll11l1l1l_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ廸"))
	l111ll111ll1_l1_ = l111ll111ll1_l1_.strip(l11ll1_l1_ (u"ࠩࠣࠫ廹"))
	l111ll11l11l_l1_ = l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠪࠤࠥ࠭建")+l1ll11l1l1l_l1_
	#l11111llll11_l1_  = l11ll1_l1_ (u"ࠫࡡࡴࡈࡪࡩ࡫࡙ࡸࡧࡧࡦ࠼ࠣ࡟ࠥ࠭廻")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ廼")
	#l11111llll11_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࡎࡲࡻ࡚ࡹࡡࡨࡧࠣ࠾ࠥࡡࠠࠨ廽")+l1ll11l1l1l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ廾")
	#l11111llll11_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡒࡴ࡛ࡳࡢࡩࡨࠤࠥࡀࠠ࡜ࠢࠪ廿")+l111ll111ll1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ开")
	l111ll11l111_l1_  = l11ll1_l1_ (u"้ࠪํอโฺࠢื฾้ࠦๅ็้สࠤฬ๊ศา่ส้ัࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣๅ๏ี๊้้สฮࠥฮฯู้่้ࠣอใๅࠩ弁")+l11ll1_l1_ (u"ࠫࡡࡴࠧ异")+l11ll1_l1_ (u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ์๐ࠠๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠪ弃")+l11ll1_l1_ (u"࠭࡜࡯ࠩ弄")
	l111ll11l111_l1_ += l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ弅")+l111ll11l11l_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ弆")
	l111ll11l111_l1_ += l11ll1_l1_ (u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢส่ออัฮหࠣࠬ๏๎ๅࠡล่ื࠮ࠦร๋ࠢไ๎ิ๐่่ษอࠫ弇")+l11ll1_l1_ (u"ࠪࡠࡳ࠭弈")+l11ll1_l1_ (u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไࠡๅห๎ึ่ࠦอ๊าࠤฺ๊ใๅหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ弉")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ弊")
	l111ll11l111_l1_ += l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ弋")+l111ll111ll1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ弌")
	l1111l1l1l1_l1_,l1lll1l111l1l_l1_,l1llll111ll11_l1_,l1lll11lllll1_l1_ = 0,0,0,0
	all = l1lll11l11l1l_l1_[l11ll1_l1_ (u"ࠨࡃࡏࡐࠬ弍")]
	if l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ弎") in list(l1lll11l11l1l_l1_.keys()): l1111l1l1l1_l1_ = l1lll11l11l1l_l1_[l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ式")]
	if l11ll1_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ弐") in list(l1lll11l11l1l_l1_.keys()): l1lll1l111l1l_l1_ = l1lll11l11l1l_l1_[l11ll1_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭弑")]
	if l11ll1_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ弒") in list(l1lll11l11l1l_l1_.keys()): l1llll111ll11_l1_ = l1lll11l11l1l_l1_[l11ll1_l1_ (u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ弓")]
	if l11ll1_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ弔") in list(l1lll11l11l1l_l1_.keys()): l1lll11lllll1_l1_ = l1lll11l11l1l_l1_[l11ll1_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ引")]
	l11lll11111l_l1_ = all-l1111l1l1l1_l1_-l1lll1l111l1l_l1_-l1llll111ll11_l1_-l1lll11lllll1_l1_
	dummy,l1llll1111111_l1_ = l1lll1ll1ll11_l1_[0]
	dummy,l1lll11ll1ll1_l1_ = l1lll1ll1ll11_l1_[1]
	l1lll1l11l1ll_l1_ = l1llll1111111_l1_-l1lll11ll1ll1_l1_
	l1lll1l1ll1l1_l1_ += l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭弖")+str(l1lll11ll1ll1_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭弗")+l11ll1_l1_ (u"ࠬอไฺัาࠤฬ๊อใ์ๅ๎๊ࠥไฤฮ๊ึฮࠦ࠺ࠡࠩ弘")
	l1lll1l1ll1l1_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ弙")+str(l1lll1l11l1ll_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ弚")+l11ll1_l1_ (u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬ弛")
	l1lll1l1ll1l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ弜")+str(l1llll1111111_l1_)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ弝")+l11ll1_l1_ (u"ࠫฬู๊ะัࠣห้้ไ๋ࠢ็ะ๊๐ูࠡษ็วัําสࠢ࠽ࠤࠬ弞")
	l1lll1l1ll1l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ弟")+str(len(l1lll1ll1ll11_l1_[2:]))+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ张")+l11ll1_l1_ (u"ฺࠧัาࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡใํ๋ฬࠦรอ้ีอࠥࡀࠠ࡝ࡰ࡟ࡲࠬ弡")
	for l1ll1l11l111_l1_,l1l11l1l111l_l1_ in l1lll1ll1ll11_l1_[2:]:
		l1ll1l11l111_l1_ = escapeUNICODE(l1ll1l11l111_l1_)
		l1ll1l11l111_l1_ = l1ll1l11l111_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ弢")).strip(l11ll1_l1_ (u"ࠩࠣ࠲ࠬ弣"))
		l1lll1l1ll1l1_l1_ += l1ll1l11l111_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ弤")+str(l1l11l1l111l_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠩ弥")
	#l1lll1l1ll1l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࠯ࠩ弦")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ弧")+str(l11lll11111l_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ弨")+l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭弩")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ弪")+str(l1111l1l1l1_l1_)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ弫")+l11ll1_l1_ (u"ࠫ฼๊ศศฬࠣื๏ืแาࠢหห๏ั่็ࠢ࠽ࠤࠬ弬")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ弭")+str(l1lll11lllll1_l1_)+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ弮")+l11ll1_l1_ (u"ุࠧๆหหฯࠦำ๋ำไีࠥอไๆะสึ๋ࠦ࠺ࠡࠩ弯")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭弰")+str(l1lll1l111l1l_l1_)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ弱")+l11ll1_l1_ (u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧ弲")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ弳")+str(l1llll111ll11_l1_)+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ弴")+l11ll1_l1_ (u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬ張")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ弶")+str(len(l1llll1l1lll1_l1_))+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ強")+l11ll1_l1_ (u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩ弸")
	#l1lll11l111l1_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ弹")+l11ll1_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤฬู๊ศๆ่ࠤ๏๎ๅࠡล่ืࠥ࠮วๅสสีาฯࠩࠨ强")+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ弻")
	l1lll11l111l1_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ弼")+l1llll11l1ll1_l1_
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ弽"),l11ll1_l1_ (u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤฬ๊ศศำะอࠥ࠮๊้็ࠣวู๊ࠩࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨ弾"),l1lll1l1ll1l1_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ弿"))
	#l11ll1l11l_l1_(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ彀"),l11ll1_l1_ (u"ࠫัฺ๋๊๊ࠢิ์ࠦวๅลิๆฬ๋ࠠหะุࠤศูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤࠥ็โุࠢํ์๊ࠦรๆีࠣࠬฬ๊ศศำะอ࠮࠭彁"),l1lll11l111l1_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ彂"))
	l11ll1l11l_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭彃"),l11ll1_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤฬ๊ศศำะอࠥ࠮๊้็ࠣวู๊ࠩࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨ彄"),l1lll11l111l1_l1_,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ彅"))
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ彆"),l11ll1_l1_ (u"้ࠪํอโฺࠢสุฯเไหࠢส่ออัฮหࠣࠬ๏๎ๅࠡล่ื࠮ࠦࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ彇"),l111ll11l111_l1_,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ彈"))
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠬࡲࡥࡧࡶࠪ彉"),l11ll1_l1_ (u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥอำหะา้ฯࠦวๅสิ๊ฬ๋ฬࠨ彊"),l111ll111lll_l1_,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ彋"))
	return
def l1lll1l1llll1_l1_():
	message = l11ll1_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬ彌")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ彍"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭彎"),message,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ彏"))
	return
def l1l1l1lll111_l1_():
	message = l11ll1_l1_ (u"ࠬอไาษห฻๏์ࠠฤั้ห์ࠦแ๋้่หࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬี้้๋ࠠࠤ฾ฮวาหࠣ฽๋ࠦสฬสํฮ้ࠥวๆๆࠣหํะ่ๆษอ๎่๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦๆ฻๊ࠤฬ฼วโหࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ่ࠦๆ฻๊ࠤฬ฼วโหࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี้ࠠ็฼๋ࠥอึศใฬࠤ๊ิา็ࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨ彐")+l11ll1_l1_ (u"࠭࡜࡯ࠩ彑")+l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ归")+l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ当")][0]+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭彔")+l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ录")][1]+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭彖")
	message += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺ๎๋ࠦระ่ส๋ࠥํๅศࠢสุ่๎ัิࠢส่ี๐๋ࠠฯอหัํࠠๆัํี๋ࠥไโษอࠤ่๎ฯ๋ࠢ็ฮะฮ๊หࠢหี๋อๅอࠢ฼้ฬีࠠษษ็฻ึ๐โสࠢส่ฯ่ไ๋ัํอࠥอไใัํ้ฮࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ彗")+l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ彘")][1]+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ彙")+l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ彚")][0]+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ彛")
	message += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰฯ้๏฿ࠠๆๆไหฯูࠦๆษาࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆ่์็฿ࠠฤั้ห์࠭彜")+l11ll1_l1_ (u"ࠫࡡࡴࠧ彝")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ彞")+l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ彟")][2]+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ彠")
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ彡"),l11ll1_l1_ (u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ形"),message,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭彣"))
	return
def l1llll1l1ll1l_l1_(l1llll1l1llll_l1_):
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪ彤")+l1llll1l1llll_l1_+l11ll1_l1_ (u"ࠬ࠯ࠧ彥"), True)
	return
def l1llll1l11ll1_l1_():
	l1ll111l1_l1_(l11ll1_l1_ (u"࠭ࡳࡵࡱࡳࠫ彦"))
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨ彧"))
	return
def l1lll1ll1l1ll_l1_():
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧ彨"), True)
	return
def l1lll1l1l111l_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111lll_l1_ = True
	else: l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ彩"),l11ll1_l1_ (u"ࠪࠫ彪"),l11ll1_l1_ (u"ࠫࠬ彫"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彬"),l11ll1_l1_ (u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦวๅฤ้ࠤฤ࠭彭"))
	if l1ll111lll_l1_==1:
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ彮"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ彯"),l11ll1_l1_ (u"ࠩࠪ彰"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭影"),l11ll1_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦืๅสࠣษ้๏ࠠษำ้ห๊าࠠไ๊า๎ࠥอไั์ࠣๅ๏ࠦฬ่ษี็๊ࠥใ๋ࠢํๆํ๋ࠠษฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣ࠲ࠥฮๅศࠢไ๎์อࠠหฯา๎ะࠦ็ัษࠣห้ฮั็ษ่ะࠥ๎สฮัํฯ๋ࠥฮำ่ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩ彲"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ彳"))
	return
def l1lll1l1l11l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ彴"),l11ll1_l1_ (u"ࠧࠨ彵"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ彶"),l11ll1_l1_ (u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦร้ࠢสืฯิฯๆࠢࠥห้้๊ษ๊ิำ่ࠧࠦศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣห฻เืࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠩ彷"))
	return
def l1lll1l1ll111_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ彸"),l11ll1_l1_ (u"ࠫࠬ役"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彺"),l11ll1_l1_ (u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ฻เืࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ彻"))
	return
#l1llll1ll111l_l1_ 	  required	and l1llll1ll111l_l1_     installed	and		not l1l11l111lll_l1_		ignore
#l1llll1ll111l_l1_ not required	and	l1llll1ll111l_l1_ not installed 	and 	    l1l11l111lll_l1_		ignore
#l1llll1ll111l_l1_ not required	and	l1llll1ll111l_l1_ not installed 	and 	not l1l11l111lll_l1_		ignore
#l1llll1ll111l_l1_ not required	and	l1llll1ll111l_l1_     installed 	and 	not l1l11l111lll_l1_		ignore
#l1llll1ll111l_l1_     required	and	l1llll1ll111l_l1_ not installed 	and 	    l1l11l111lll_l1_		l11111l111_l1_ l1lll1l111l1l_l1_	l1llll11l1lll_l1_
#l1llll1ll111l_l1_     required	and	l1llll1ll111l_l1_ not installed 	and 	not l1l11l111lll_l1_		l11111l111_l1_ l1lll1l111l1l_l1_	l1llll11l1lll_l1_
#l1llll1ll111l_l1_     required 	and l1llll1ll111l_l1_     installed 	and 	    l1l11l111lll_l1_		l11111l111_l1_ l1llll1llll1l_l1_	l1llll11l1lll_l1_
#l1llll1ll111l_l1_ not required	and	l1llll1ll111l_l1_     installed 	and 	    l1l11l111lll_l1_		l11111l111_l1_ l1llll1llll1l_l1_	l1llll11l1lll_l1_
#l1ll1lll1111_l1_: required and not installed: l11111l111_l1_ l1lll1l111l1l_l1_
#l1ll1ll1lll1_l1_: installed and l11111l111_l1_ update: l11111l111_l1_ l1llll1llll1l_l1_
def l1l1l1l1ll11_l1_(l1ll_l1_=True):
	l1l11ll11lll_l1_ = l1l1l1111ll1_l1_([l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ彼")])
	l1llll111l1ll_l1_ = []
	for addon_id in [l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ彽")]:
		if addon_id not in list(l1l11ll11lll_l1_.keys()): continue
		l1l11l111lll_l1_,l1llllll1l1l_l1_,l1llll11lllll_l1_,l1llll11llll1_l1_,l1llll11ll1ll_l1_,l1lll11ll1111_l1_,l1llll11lll11_l1_ = l1l11ll11lll_l1_[addon_id]
		if not l1llllll1l1l_l1_ or (l1llllll1l1l_l1_ and l1l11l111lll_l1_): l1llll111l1ll_l1_.append(addon_id)
	l1lll11l11111_l1_ = len(l1llll111l1ll_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l11111l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1llll1l111ll_l1_ = []
	for addon_id in l11ll1ll1ll_l1_:
		cc.execute(l11ll1_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡪࡴࡡࡣ࡮ࡨࡨࠥࡃࠠࠣ࠳ࠥࠤࡦࡴࡤࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭彾")+addon_id+l11ll1_l1_ (u"ࠪࠦࠥࡁࠧ彿"))
		l1l1111ll11_l1_ = cc.fetchall()
		if l1l1111ll11_l1_: l1llll1l111ll_l1_.append(addon_id)
	l1lll1ll11l1l_l1_ = len(l1llll1l111ll_l1_)>0
	for addon_id in l11111111l1_l1_:
		cc.execute(l11ll1_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ往")+addon_id+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ征"))
		l1lllll11ll1l_l1_ = cc.fetchall()
		if l1lllll11ll1l_l1_ and l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ徂") not in str(l1lllll11ll1l_l1_): l1llll111l1ll_l1_.append(addon_id)
	l1lll1l11l111_l1_ = len(l1llll111l1ll_l1_)>0
	l1llll111l1ll_l1_ = list(set(l1llll111l1ll_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ徃"),l11ll1_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥࡲࡦࡲࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࡀࠠࠡࠩ径")+str(l1lll11l11111_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ待"),l11ll1_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡦࡨࡰࡪࡺࡩ࡯ࡩࡢࡳࡱࡪ࡟ࡢࡦࡧࡳࡳࡹ࠺ࠡࠢࠪ徆")+str(l1lll1ll11l1l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ徇"),l11ll1_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡳࡷ࡯ࡧࡪࡰ࠽ࠤࠥ࠭很")+str(l1lll1l11l111_l1_))
	l1l11l111lll_l1_ = False
	if l1lll1ll11l1l_l1_ or l1lll1l11l111_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭徉"),l11ll1_l1_ (u"ࠧࠨ徊"),l11ll1_l1_ (u"ࠨࠩ律"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ後"),l11ll1_l1_ (u"ࠪห้ฮั็ษ่ะࠥ๎ฬะุ่่๊ࠢษࠡใํࠤ๊ิวำ่ࠣ฽๊อฯࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠศๆล๊ࠥล࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ徍"))
		if l1ll111lll_l1_==1:
			l1llll1ll1lll_l1_ = True
			if l1lll11l11111_l1_:
				l1llll1ll1lll_l1_ = l1lll1l1111l1_l1_(l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭徎"),False,False)
			l1llll11111ll_l1_ = True
			if l1lll1ll11l1l_l1_:
				for addon_id in l1llll1l111ll_l1_: l1lll1lll1lll_l1_(addon_id)
				l1llll11111ll_l1_ = True
			l1lll11llll1l_l1_ = True
			if l1lll1l11l111_l1_:
				conn = sqlite3.connect(l11111l11ll_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1llll111l1ll_l1_:
					if l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࠨ徏") in addon_id: l1lllll11ll1l_l1_ = addon_id
					else: l1lllll11ll1l_l1_ = l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ徐")
					try: cc.execute(l11ll1_l1_ (u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫ徑")+l1lllll11ll1l_l1_+l11ll1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ徒")+addon_id+l11ll1_l1_ (u"ࠩࠥࠤࡀ࠭従"))
					except: l1lll11llll1l_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ徔"))
			time.sleep(1)
			if l1llll1ll1lll_l1_ or l1llll11111ll_l1_ or l1lll11llll1l_l1_:
				l1l11l111lll_l1_ = False
				DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ徕"),l11ll1_l1_ (u"ࠬ࠭徖"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ得"),l11ll1_l1_ (u"ࠧอ์าࠤ࠳࠴ࠠห็ࠣฬ๋าวฮࠢอๅ฾๐ไ๊ࠡศู้ออࠡษ็้ำอา็๋ࠢห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไอ็ํ฽ࠥหึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ徘"))
			else:
				l1l11l111lll_l1_ = True
				DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ徙"),l11ll1_l1_ (u"ࠩࠪ徚"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭徛"),l11ll1_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮ่ࠢาฬุๆࠡ฻่หิ่ࠦฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ徜"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭徝"),l11ll1_l1_ (u"࠭ࠧ從"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ徟"),l11ll1_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆึๆ่ฮࠦแ๋่ࠢาฬุๆࠡ฻่หิࠦร้ࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ徠"))
	return l1l11l111lll_l1_
def l1lll1l111ll1_l1_():
	l1lll11l11ll1_l1_,l1llll1l1111l_l1_,l1llll11ll111_l1_ = False,l11ll1_l1_ (u"ࠩࠪ御"),l11ll1_l1_ (u"ࠪࠫ徢")
	l1llll1ll11l1_l1_,l1lll1lll11l1_l1_,l1lll1lllllll_l1_ = False,l11ll1_l1_ (u"ࠫࠬ徣"),l11ll1_l1_ (u"ࠬ࠭徤")
	l1l11ll11lll_l1_ = l1l1l1111ll1_l1_([l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ徥"),l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ徦"),l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ徧")])
	for addon_id in [l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ徨"),l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ復"),l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ循")]:
		if addon_id not in list(l1l11ll11lll_l1_.keys()): continue
		l1l11l111lll_l1_,l1llllll1l1l_l1_,l111l1111ll_l1_,l1ll1lllll11_l1_,l11ll1l11l1_l1_,l11l1l11ll1_l1_,l1l11l111l1l_l1_ = l1l11ll11lll_l1_[addon_id]
		if addon_id==l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ徫"):
			l1llll1ll11l1_l1_ = l1l11l111lll_l1_
			l1lll1lll11l1_l1_ = l11ll1_l1_ (u"࠭ࠨࠨ徬")+l1llllll1l1l_l1_+l11ll1_l1_ (u"ࠧࠡࠩ徭")+TRANSLATE(l11l1l11ll1_l1_)+l11ll1_l1_ (u"ࠨࠫࠪ微")
			l1lll1lllllll_l1_ = l1ll1lllll11_l1_
		elif addon_id==l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ徯"):
			l1lll11l11ll1_l1_ = l1lll11l11ll1_l1_ or l1l11l111lll_l1_
			l1llll1l1111l_l1_ += l11ll1_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠪࠪ徰")+l1llllll1l1l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭徱")+TRANSLATE(l11l1l11ll1_l1_)+l11ll1_l1_ (u"ࠬ࠯ࠧ徲")
			l1llll11ll111_l1_ += l11ll1_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ徳")+l1ll1lllll11_l1_
		elif addon_id==l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭徴"):
			l1lll1ll11111_l1_ = l1l11l111lll_l1_
			l1lll1l1l1ll1_l1_ = l11ll1_l1_ (u"ࠨࠪࠪ徵")+l1llllll1l1l_l1_+l11ll1_l1_ (u"ࠩࠣࠫ徶")+TRANSLATE(l11l1l11ll1_l1_)+l11ll1_l1_ (u"ࠪ࠭ࠬ德")
			l1llll11l1l1l_l1_ = l1ll1lllll11_l1_
	l1llll1l1111l_l1_ = l1llll1l1111l_l1_.strip(l11ll1_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ徸"))
	l1llll11ll111_l1_ = l1llll11ll111_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠫ徹"))
	l1l11ll1ll_l1_  = l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭徺")+l1lll1lllllll_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ徻")
	l1l11ll1ll_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ徼")+l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭徽")+l1lll1lll11l1_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ徾")
	l1l11ll1ll_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ徿")+l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ฮำ่ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忀")+l1llll11ll111_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ忁")
	l1l11ll1ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ忂")+l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่๊ࠣิา็ࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ心")+l1llll1l1111l_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ忄")
	l1l11ll1ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ必")+l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忆")+l1llll11l1l1l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ忇")
	l1l11ll1ll_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࠩ忈")+l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忉")+l1lll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ忊")
	l1l11l111lll_l1_ = (l1llll1ll11l1_l1_ or l1lll11l11ll1_l1_)
	if l1l11l111lll_l1_:
		header = l11ll1_l1_ (u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫ忋")
		l1l1l1ll1l_l1_ = l11ll1_l1_ (u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅฯิ้ࠤ฾๋วะࠩ忌")
	else:
		header = l11ll1_l1_ (u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆะี๊ࠥ฿ๅศัࠪ忍")
		l1l1l1ll1l_l1_ = l11ll1_l1_ (u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧ忎")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ忏")
	l1ll11lll1_l1_ = l1l11ll1ll_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ忐")+l1l1l1ll1l_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭忑")+l1l1l1ll11_l1_
	l11ll1l11l_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ忒"),header,l1ll11lll1_l1_,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭忓"))
	return
def l1ll1l1l11l1_l1_(l1ll_l1_=True,l1lll1l11ll11_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ忔"),l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ忕"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ忖"),l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ志"))
	if l1ll_l1_:
		l1lll1l111ll1_l1_()
		l1llll11l1l11_l1_()
	if l1lll1l11ll11_l1_:
		l1l1l1l1ll11_l1_(False)
		l1lllll111lll_l1_,l1lll11lll1l1_l1_,l1lll1l11l1l1_l1_ = l1lll1l1111l1_l1_(l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭忘"),True,False)
		l1lllll11l111_l1_,l1lll11lll1l1_l1_,l1llll1l111l1_l1_ = l1lll1l1111l1_l1_(l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ忙"),True,False)
		l1lll1l1l111l_l1_(l1ll_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ忚"))
	return
def l1llll111lll1_l1_(l1llll1l1l111_l1_=l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ忛"),l1ll_l1_=True):
	l111l1l1l11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ応"))
	import json
	data = json.loads(l111l1l1l11_l1_)
	l1lll11l1llll_l1_ = data[l11ll1_l1_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭忝")][l11ll1_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭忞")]
	if kodi_version<19: l1lll11l1llll_l1_ = l1lll11l1llll_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭忟"))
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ忠"),l11ll1_l1_ (u"ࠪࠫ忡"),l11ll1_l1_ (u"ࠫࠬ忢"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ忣"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫ忤")+l1lll11l1llll_l1_+l11ll1_l1_ (u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩ忥")+l1llll1l1l111_l1_+l11ll1_l1_ (u"ࠨࠢยࠥࠬ忦"))
		if l1ll111lll_l1_!=1: return False
	succeeded,l1llll11ll11l_l1_,l1lll11ll11l1_l1_ = l1lll1l1111l1_l1_(l1llll1l1l111_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ忧"),l11ll1_l1_ (u"ࠪࠫ忨"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ忩"),l11ll1_l1_ (u"ࠬะๅหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆฯ่ิࠦวๅฮา๎ิ่่๊ࠦࠣะฬําࠡๆ็หุะฮะษ่ࠤ࠳ࠦำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥะฺ๋์ิࠤส฿ฯศัสฮ้่ࠥะ์่่ࠣ๐๋ࠠีอ฽๊๊ࠠศๆฯ่ิࠦวๅฮา๎ิࠦศะๆสࠤ๊์ࠠศๆๅำ๏๋ࠧ忪"))
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠤࠪ快")+l1llll1l1l111_l1_+l11ll1_l1_ (u"ࠧࠣࡿࢀࠫ忬"))
		if l11ll1_l1_ (u"ࠨࡑࡎࠫ忭") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩ忮"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ忯"),l11ll1_l1_ (u"ࠫࠬ忰"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ忱"),l11ll1_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨ忲"))
	return succeeded
def l11l11llll1_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11ll1_l1_ (u"ࠧࠨ忳"): l1ll_l1_ = True
	#l1lll111ll11_l1_ = xbmc.getCondVisibility(l11ll1_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠫ忴")+addon_id+l11ll1_l1_ (u"ࠩࠬࠫ念"))
	l11l1ll111l_l1_ = l1ll111l1111_l1_([addon_id])
	l11l11111ll_l1_,l1lll111ll11_l1_ = l11l1ll111l_l1_[addon_id]
	if l1lll111ll11_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ忶"),l11ll1_l1_ (u"ࠫࠬ忷"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ忸"),l11ll1_l1_ (u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨ忹")+addon_id+l11ll1_l1_ (u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ忺"))
	else:
		succeeded = False
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ忻"),l11ll1_l1_ (u"ࠩࠪ忼"),l11ll1_l1_ (u"ࠪࠫ忽"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ忾"),l11ll1_l1_ (u"ࠬ࠭忿")+addon_id+l11ll1_l1_ (u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫ怀"))
		if l1ll111lll_l1_==1:
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧ态")+addon_id+l11ll1_l1_ (u"ࠨࠫࠪ怂"))
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩ怃"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11ll1_l1_ (u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧ怄")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ怅")+addon_id+l11ll1_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ怆"))
			if l11ll1_l1_ (u"࠭ࡏࡌࠩ怇") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ怈"),l11ll1_l1_ (u"ࠨࠩ怉"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ怊"),l11ll1_l1_ (u"ࠪฮ๊ࠦแฮืࠣวํࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ๎็๋ࠢส่ว์ࠠอษ๊ึฮࠦไๅษึฮำีวๆࠩ怋"))
			elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ怌"),l11ll1_l1_ (u"ࠬ࠭怍"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怎"),l11ll1_l1_ (u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩ怏"))
	return succeeded
def l1lll1l1l11ll_l1_(addon_id,l1l11l111l1l_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ怐"),l11ll1_l1_ (u"ࠩࠪ怑"),l11ll1_l1_ (u"ࠪࠫ怒"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ怓"),l11ll1_l1_ (u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨ怔"))
		if l1ll111lll_l1_!=1: return False
	l1lll11l1l11l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l111l1l_l1_,{},l1ll_l1_)
	if l1lll11l1l11l_l1_:
		l1l11l1l11l1_l1_ = os.path.join(l1ll1l1111_l1_,addon_id)
		l1ll11ll11_l1_(l1l11l1l11l1_l1_,True,False)
		import zipfile,io
		l1lll1lll111l_l1_ = io.BytesIO(l1lll11l1l11l_l1_)
		zf = zipfile.ZipFile(l1lll1lll111l_l1_)
		zf.extractall(l1ll1l1111_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ怕"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ怖")+addon_id+l11ll1_l1_ (u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭怗"))
		if l11ll1_l1_ (u"ࠩࡒࡏࠬ怘") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭怙"),l11ll1_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ怚"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭怛"),l11ll1_l1_ (u"࠭ࠧ怜"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ思"),l11ll1_l1_ (u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬ怞"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ怟"),l11ll1_l1_ (u"ࠪࠫ怠"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ怡"),l11ll1_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪ怢"))
	return succeeded
def l1lll1l1111l1_l1_(addon_id,l1ll_l1_,l1lll1ll111ll_l1_):
	l1ll111lll_l1_,succeeded,l1llll11ll11l_l1_,l1llllll1l1l_l1_ = True,False,l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭怣"),l11ll1_l1_ (u"ࠧࠨ怤")
	l1l11ll11lll_l1_ = l1l1l1111ll1_l1_([addon_id])
	if addon_id in list(l1l11ll11lll_l1_.keys()):
		l1l11l111lll_l1_,l1llllll1l1l_l1_,l111l1111ll_l1_,l1ll1lllll11_l1_,l11ll1l11l1_l1_,l11l1l11ll1_l1_,l1l11l111l1l_l1_ = l1l11ll11lll_l1_[addon_id]
		if l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠨࡩࡲࡳࡩ࠭急"):
			succeeded,l1llll11ll11l_l1_ = True,l11ll1_l1_ (u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪ怦")
			if l1lll1ll111ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ性"),l11ll1_l1_ (u"ࠫࠬ怨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ怩"),l11ll1_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥฮำ่ࠣ฽๊อฯࠡๆ๊ิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫ怪")+addon_id)
		else:
			if l1ll_l1_:
				if l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ怫"): message = l11ll1_l1_ (u"ࠨ็อ์็็ษࠨ怬")
				elif l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠩࡲࡰࡩ࠭怭"): message = l11ll1_l1_ (u"ࠪๆิ๐ๅสࠩ怮")
				elif l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ怯"): message = l11ll1_l1_ (u"ࠬเ๊า่ࠢฯอะษࠨ怰")
				l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ怱"),l11ll1_l1_ (u"ࠧࠨ怲"),l11ll1_l1_ (u"ࠨࠩ怳"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ怴"),l11ll1_l1_ (u"๋ࠪีํࠠศๆศฺฬ็ษࠡࠩ怵")+message+l11ll1_l1_ (u"ࠫࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦฟࠢ࡞ࡱࡠࡳ࠭怶")+addon_id)
			if not l1ll111lll_l1_: l1llll11ll11l_l1_ = l11ll1_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧ怷")
			else:
				if l11l1l11ll1_l1_==l11ll1_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ怸"):
					results = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ怹")+addon_id+l11ll1_l1_ (u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭怺"))
					if l11ll1_l1_ (u"ࠩࡒࡏࠬ总") in results:
						succeeded,l1llll11ll11l_l1_ = True,l11ll1_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫ怼")
						if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ怽"),l11ll1_l1_ (u"ࠬ࠭怾"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怿"),l11ll1_l1_ (u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬ้ࠣฯ๎โโหࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ํว࡝ࡰ࡟ࡲࠬ恀")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ恁"),l11ll1_l1_ (u"ࠩࠪ恂"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭恃"),l11ll1_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦวๅวูหๆฯࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์้๋๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧ恄")+addon_id)
				elif l11l1l11ll1_l1_ in [l11ll1_l1_ (u"ࠬࡵ࡬ࡥࠩ恅"),l11ll1_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ恆")]:
					succeeded = l1lll1l1l11ll_l1_(addon_id,l1l11l111l1l_l1_,False)
					if succeeded:
						if l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠧࡰ࡮ࡧࠫ恇"): l1llll11ll11l_l1_ = l11ll1_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩ恈")
						elif l11l1l11ll1_l1_==l11ll1_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ恉"): l1llll11ll11l_l1_ = l11ll1_l1_ (u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭恊")
						l1llllll1l1l_l1_ = l1ll1lllll11_l1_
						if l1ll_l1_:
							if l1llll11ll11l_l1_==l11ll1_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬ恋"): DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭恌"),l11ll1_l1_ (u"࠭ࠧ恍"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ恎"),l11ll1_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ็ี๊ๆหࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหฯา๎ะํว࡝ࡰ࡟ࡲࠬ恏")+addon_id)
							elif l1llll11ll11l_l1_==l11ll1_l1_ (u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬ恐"): DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ恑"),l11ll1_l1_ (u"ࠫࠬ恒"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ恓"),l11ll1_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧ恔")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ恕"),l11ll1_l1_ (u"ࠨࠩ恖"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ恗"),l11ll1_l1_ (u"่้ࠪษำโࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣฮาี๊ฬࠢฦ์ࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭恘")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ恙"),l11ll1_l1_ (u"ࠬ࠭恚"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ恛"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯๊ࠢิ์ࠦวๅวูหๆฯࠠ฻์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠๆ๊สๆ฾ࠦๅฯิ้ࠤ฾๋วะࠢ࠱࠲ࠥ๎ไ่าสࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢฦ๊ࠥ๐โ้็ࠣฬฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡล๋ࠤฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ恜")+addon_id)
	return succeeded,l1llll11ll11l_l1_,l1llllll1l1l_l1_
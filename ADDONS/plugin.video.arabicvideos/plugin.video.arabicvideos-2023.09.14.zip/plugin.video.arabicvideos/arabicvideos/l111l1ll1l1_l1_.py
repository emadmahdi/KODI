# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ亯")
headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ亰"):l11ll1_l1_ (u"࠭ࠧ亱")}
script_name = l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭亲")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ亳")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11ll1_l1_ (u"ࠩ࠶ࠫ亴"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11ll1_l1_ (u"ࠪ࠵ࠬ亵"))
	elif mode==36: results = CATEGORIES(url,l11ll1_l1_ (u"ࠫ࠷࠭亶"))
	elif mode==37: results = CATEGORIES(url,l11ll1_l1_ (u"ࠬ࠺ࠧ亷"))
	elif mode==38: results = l1l1ll1ll_l1_()
	elif mode==39: results = SEARCH(text,l1l1111_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭亸"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ亹"),l11ll1_l1_ (u"ࠨࠩ人"),39,l11ll1_l1_ (u"ࠩࠪ亻"),l11ll1_l1_ (u"ࠪࠫ亼"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ亽"))
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ亾"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭亿"),l11ll1_l1_ (u"ࠧࠨ什"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭仁"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ仂")+l111l1_l1_+l11ll1_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ仃"),l11ll1_l1_ (u"ࠫࠬ仄"),38)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ仅"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ仆")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อส๊ࠡหีฬ๋ฬࠨ仇"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭仈"),31)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ仉"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ今")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆส็ะืࠠๆึส๋ิฯࠧ介"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ仌"),37)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭仍"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ从")+l111l1_l1_+l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠠฮีหࠤฬ๊ๆ้฻ࠪ仏"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ仐"),35)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ仑"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭仒")+l111l1_l1_+l11ll1_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็้๊ัไࠨ仓"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ仔"),36)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ仕"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ他")+l111l1_l1_+l11ll1_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ仗"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ付"),32)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ仙"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ仚")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅิำะ๎ฬะࠧ仛"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯࠵࠱࠴ࠫ仜"),32)
	return l11ll1_l1_ (u"ࠨࠩ仝")
def CATEGORIES(url,select=l11ll1_l1_ (u"ࠩࠪ仞")):
	type = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ仟"))[3]
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ仠"),l11ll1_l1_ (u"ࠬ࠭仡"),type, url)
	if type==l11ll1_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ仢"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠧࠨ代"),headers,l11ll1_l1_ (u"ࠨࠩ令"),l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ以"))
		if select==l11ll1_l1_ (u"ࠪ࠷ࠬ仦"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭仧"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ仨"),block,re.DOTALL)
			for l1lllll_l1_,name in items:
				if l11ll1_l1_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬ仩") in name: continue
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠧࠡࠩ仪"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ仫"),l111l1_l1_+name,url,32)
		if select==l11ll1_l1_ (u"ࠩ࠷ࠫ们"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬ仭"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭仮"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title in items:
				url = l11l1l_l1_ + l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ仯"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭仰"),l111l1_l1_+title,url,32,l1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ仱"),l11ll1_l1_ (u"ࠨࠩ仲"),url,l11ll1_l1_ (u"ࠩࠪ仳"))
	if type==l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ仴"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬ仵"),headers,l11ll1_l1_ (u"ࠬ࠭件"),l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠵ࡲࡩ࠭价"))
		if select==l11ll1_l1_ (u"ࠧ࠲ࠩ仸"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡈࡧࡱࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ仹"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ仺"),block,re.DOTALL)
			for value,name in items:
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳࡬࡫࡮ࡳࡧ࠲ࠫ任") + value
				name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭仼"))
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ份"),l111l1_l1_+name,url,32)
		elif select==l11ll1_l1_ (u"࠭࠲ࠨ仾"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡁࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ仿"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ伀"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ企"))
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࡦࡩࡴࡰࡴ࠲ࠫ伂") + value
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伃"),l111l1_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭伄"),l11ll1_l1_ (u"࠭ࠧ伅"),url,l11ll1_l1_ (u"ࠧࠨ伆"))
	type = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ伇"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠩࠪ伈"),headers,l11ll1_l1_ (u"ࠪࠫ伉"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭伊"))
	if l11ll1_l1_ (u"ࠬ࡮࡯࡮ࡧࠪ伋") in url: type=l11ll1_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ伌")
	if type==l11ll1_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ伍"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠬ࠳࠰࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ伎"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ伏"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,name in items:
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ伐"))
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ休"),l111l1_l1_+name,url,32,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ伒"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ伓"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠫࡀࠫࠥࠫ伔"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,name in items:
			name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ伕"))
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ伖"),l111l1_l1_+name,url,33,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ众"):
		l1l1111_l1_ = url.split(l11ll1_l1_ (u"ࠫ࠴࠭优"))[-1]
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭伙"),l11ll1_l1_ (u"࠭ࠧ会"),url,l11ll1_l1_ (u"ࠧࠨ伛"))
		if l1l1111_l1_==l11ll1_l1_ (u"ࠨ࠳ࠪ伜"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠧ伝"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࠫ伞"),block,re.DOTALL)
			count = 0
			for l1lllll_l1_,l1lll1_l1_,l1ll1l1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ伟") + l1ll1l1_l1_
				url = l11l1l_l1_ + l1lllll_l1_
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ传"),l111l1_l1_+name,url,33,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵ࠱࠮ࡄࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ伡"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲ࠨ伢"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,l1ll1l1_l1_ in items:
			l1ll1l1_l1_ = l1ll1l1_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ伣"))
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ伤"))
			name = title + l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧ伥") + l1ll1l1_l1_
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ伦"),l111l1_l1_+name,url,33,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡵ࡭࡬࡮ࡴࠩ࠰࠮ࡃ࠮ࡪࡡࡵࡣ࠰ࡶࡪࡼࡩࡷࡧ࠰ࡾࡴࡴࡥࡪࡦࡀࠦ࠹ࠨࠧ伧"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ伨"),block,re.DOTALL)
	for l1lllll_l1_,l1l1111_l1_ in items:
		url = l11l1l_l1_ + l1lllll_l1_
		name = l11ll1_l1_ (u"ࠧึใะอࠥ࠭伩") + l1l1111_l1_
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ伪"),l111l1_l1_+name,url,32)
	return
def PLAY(url):
	if l11ll1_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭伫") in url:
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࡸ࠴࠳ࡸ࡫ࡲࡪࡧࡶࡐ࡮ࡴ࡫࠰ࠩ伬") + url.split(l11ll1_l1_ (u"ࠫ࠴࠭伭"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ伮"),url,l11ll1_l1_ (u"࠭ࠧ伯"),headers,l11ll1_l1_ (u"ࠧࠨ估"),l11ll1_l1_ (u"ࠨࠩ伱"),l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ伲"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠪࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ伳"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ伴"),l11ll1_l1_ (u"ࠬ࠵ࠧ伵"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ伶"),url,l11ll1_l1_ (u"ࠧࠨ伷"),headers,l11ll1_l1_ (u"ࠨࠩ伸"),l11ll1_l1_ (u"ࠩࠪ伹"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ伺"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ伻"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ似"))
	return
def SEARCH(search,l1l1111_l1_=l11ll1_l1_ (u"࠭ࠧ伽")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ伾"),l11ll1_l1_ (u"ࠨࠧ࠵࠴ࠬ伿"))
	l1l1lllll_l1_ = [l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ佀"),l11ll1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ佁")]
	if not l1l1111_l1_: l1l1111_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭佂")
	else: l1l1111_l1_,type = l1l1111_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ佃"))
	if l1ll_l1_:
		l1l11l11l_l1_ = [ l11ll1_l1_ (u"࠭ศฮอࠣ฽๋ࠦวโๆส้ࠬ佄") , l11ll1_l1_ (u"ࠧษฯฮࠤ฾์ࠠๆี็ื้อสࠨ佅")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥ࠳ࠠศะอีࠥอไษฯฮࠫ但"), l1l11l11l_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lllll_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࡡࠪ佇") in options: type = l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ佈")
		elif l11ll1_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࡣࠬ佉") in options: type = l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ佊")
		else: return
	headers[l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ佋")] = l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ佌")
	data = {l11ll1_l1_ (u"ࠨࡳࡸࡩࡷࡿࠧ位"):l1111ll_l1_ , l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡆࡲࡱࡦ࡯࡮ࠨ低"):type}
	if l1l1111_l1_!=l11ll1_l1_ (u"ࠪ࠵ࠬ住"): data[l11ll1_l1_ (u"ࠫ࡫ࡸ࡯࡮ࠩ佐")] = l1l1111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ佑"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ佒"),data,headers,l11ll1_l1_ (u"ࠧࠨ体"),l11ll1_l1_ (u"ࠨࠩ佔"),l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ何"))
	html = response.content
	items=re.findall(l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭佖"),html,re.DOTALL)
	if items:
		for title,l1lllll_l1_ in items:
			url = l11l1l_l1_ + l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ佗"),l11ll1_l1_ (u"ࠬ࠵ࠧ佘"))
			if l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ余") in url: addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭佚"),l111l1_l1_+l11ll1_l1_ (u"ࠨใํ่๊ࠦࠧ佛")+title,url,33)
			elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ作") in url:
				url = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ佝"),l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࠪ佞"))
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佟"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ࠥ࠭你")+title,url+l11ll1_l1_ (u"ࠧ࠰࠳ࠪ佡"),32)
	count=re.findall(l11ll1_l1_ (u"ࠨࠤࡷࡳࡹࡧ࡬ࠣ࠼ࠫ࠲࠯ࡅࠩࡾࠩ佢"),html,re.DOTALL)
	if count:
		l1l1l1lll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll111ll_l1_ in range(1,l1l1l1lll_l1_):
			l1ll111ll_l1_ = str(l1ll111ll_l1_)
			if l1ll111ll_l1_!=l1l1111_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ佣"),l11ll1_l1_ (u"ูࠪๆำษࠡࠩ佤")+l1ll111ll_l1_,l11ll1_l1_ (u"ࠫࠬ佥"),39,l11ll1_l1_ (u"ࠬ࠭佦"),l1ll111ll_l1_+l11ll1_l1_ (u"࠭࠯ࠨ佧")+type,search)
	return
def l1l1ll1ll_l1_():
	l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡢࡊࡕ࠴ࡨࡊ࡯ࡷࡎ࠵ࡨࡿࡪࡈࡋ࡮࡜࡛࠵࠶ࡌ࡯ࡄ࡫ࡦࡲ࡜࠰ࡍ࡯ࡑࡺࡑࡳ࡬ࡴࡎ࠵࡚ࡰࡠ࠲ࡗࡨ࡜࡛ࡏࡿࡌ࠳ࡪ࡫ࡦࡌࡌࡕࡗ࡫࠼ࡻࡧࡍࡆ࠶ࡤࡊࡰࡿࡪࡃ࠶ࡶࡐ࠷࡚࠺ࠧ佨")
	l1lllll_l1_ = base64.b64decode(l1lllll_l1_)
	l1lllll_l1_ = l1lllll_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭佩"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ佪"))
	return
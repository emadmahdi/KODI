# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ䮝")
headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䮞") : l11ll1_l1_ (u"ࠫࠬ䮟") }
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫ䮠")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11llllll1_l1_ = l1l1lll_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11111_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llll1l_l1_(url)
	elif mode==188: results = l11ll1l11111_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11ll1l11111_l1_():
	message = l11ll1_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ䮡")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䮢"),l11ll1_l1_ (u"ࠨࠩ䮣"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䮤"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䮥"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䮦"),l11ll1_l1_ (u"ࠬ࠭䮧"),189,l11ll1_l1_ (u"࠭ࠧ䮨"),l11ll1_l1_ (u"ࠧࠨ䮩"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䮪"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䮫"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䮬")+l111l1_l1_+l11ll1_l1_ (u"ࠫอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࠬ䮭"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠬ࠭䮮"),l11ll1_l1_ (u"࠭ࠧ䮯"),l11ll1_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ䮰"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䮱"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䮲")+l111l1_l1_+l11ll1_l1_ (u"ࠪวาีหࠡษ็หๆ๊วๆࠩ䮳"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠫࠬ䮴"),l11ll1_l1_ (u"ࠬ࠭䮵"),l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䮶"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䮷"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䮸")+l111l1_l1_+l11ll1_l1_ (u"ࠩอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䮹"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠪࠫ䮺"),l11ll1_l1_ (u"ࠫࠬ䮻"),l11ll1_l1_ (u"ࠬࡺࡶࠨ䮼"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䮽"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䮾")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨ䮿"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠩࠪ䯀"),l11ll1_l1_ (u"ࠪࠫ䯁"),l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䯂"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䯃"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䯄")+l111l1_l1_+l11ll1_l1_ (u"ࠧฤไ๋ํࠥอไศใ็ห๊ࠦวๅฯส่๏ฯࠧ䯅"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠨࠩ䯆"),l11ll1_l1_ (u"ࠩࠪ䯇"),l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䯈"))
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ䯉"),headers,l11ll1_l1_ (u"ࠬ࠭䯊"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䯋"))
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䯌"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯍"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䯎")+l111l1_l1_+title,l1lllll_l1_,181)
	return html
def l11111_l1_(url,type=l11ll1_l1_ (u"ࠪࠫ䯏")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ䯐"),headers,l11ll1_l1_ (u"ࠬ࠭䯑"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䯒"))
	if type==l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䯓"): block = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ละำะࠦวๅลไ่ฬ๋࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䯔"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭䯕"): block = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ䯖"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䯗"): block = re.findall(l11ll1_l1_ (u"ࠬࡨࡴ࡯࠯࠵࠱ࡴࡼࡥࡳ࡮ࡤࡽ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ䯘"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䯙"): block = re.findall(l11ll1_l1_ (u"ࠧࡣࡶࡱ࠱࠶ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠫ࠲࠯ࡅࠩࡣࡶࡱ࠱࠷ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠪ䯚"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠨࡶࡹࠫ䯛"): block = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡩࠥࠫ䯜"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䯝"),l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䯞")]:
		items = re.findall(l11ll1_l1_ (u"ࠬࡹࡴࡺ࡮ࡨࡁࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䯟"),block,re.DOTALL)
	else: items = re.findall(l11ll1_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠴࡝࠳࠱࠾ࡣࠫࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯠"),block,re.DOTALL)
	l11l_l1_ = []
	l111lll11_l1_ = [l11ll1_l1_ (u"ࠧโ์็้ࠬ䯡"),l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ䯢"),l11ll1_l1_ (u"ࠩส่า๊โ่ࠩ䯣"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧ䯤"),l11ll1_l1_ (u"ࠫࡗࡧࡷࠨ䯥"),l11ll1_l1_ (u"࡙ࠬ࡭ࡢࡥ࡮ࡈࡴࡽ࡮ࠨ䯦"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ䯧"),l11ll1_l1_ (u"ࠧศฮีหฦ࠭䯨")]
	for l1lll1_l1_,l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l11ll1l111l1_l1_ in items:
		if type in [l11ll1_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䯩"),l11ll1_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䯪")]:
			l1lll1_l1_,l1lllll_l1_,l1lllll11l_l1_,title = l1lll1_l1_,l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l11ll1l111l1_l1_
		else: l1lll1_l1_,title,l1lllll_l1_,l1lllll11l_l1_ = l1lll1_l1_,l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l11ll1l111l1_l1_
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡃࡻ࡯ࡥࡸ࠿ࡷࡶࡺ࡫ࠧ䯫"),l11ll1_l1_ (u"ࠫࠬ䯬"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䯭"),l11ll1_l1_ (u"࠭ࠧ䯮"),l1lllll_l1_,l1lllll11l_l1_)
		title = unescapeHTML(title)
		#l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠮ศอ๊าอࢁฮฬ้ั๊࠭ࠬ䯯"),title,re.DOTALL)
		#if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0][0]
		if l11ll1_l1_ (u"ࠨสฯ์ิฯࠠࠨ䯰") in title or l11ll1_l1_ (u"ࠩหะํี็ࠡࠩ䯱") in title:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䯲") + title.replace(l11ll1_l1_ (u"ࠫอา่ะหࠣࠫ䯳"),l11ll1_l1_ (u"ࠬ࠭䯴")).replace(l11ll1_l1_ (u"࠭ศอ๊า๋ࠥ࠭䯵"),l11ll1_l1_ (u"ࠧࠨ䯶"))
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ䯷"))
		if l11ll1_l1_ (u"ࠩส่า๊โสࠩ䯸") in title or l11ll1_l1_ (u"ࠪห้ำไใ้ࠪ䯹") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ䯺"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䯻") + l1ll1l1_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯼"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111lll11_l1_):
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䯽") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䯾"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䯿") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰀"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠫࠬ䰁"):
		items = re.findall(l11ll1_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䰂"),html,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"࠭วๅืไัฮࠦࠧ䰃"),l11ll1_l1_ (u"ࠧࠨ䰄"))
			if title!=l11ll1_l1_ (u"ࠨࠩ䰅"):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䰆"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䰇")+title,l1lllll_l1_,181)
	return
def l1llll1l_l1_(url):
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䰈"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭䰉"),headers,l11ll1_l1_ (u"࠭ࠧ䰊"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䰋"))
	block = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰌"),html,re.DOTALL)
	title,dummy,l1lll1_l1_ = block[0]
	name = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ䰍"),title,re.DOTALL)
	if name: name = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䰎") + name[0][0]
	else: name = title
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䰏"),html,re.DOTALL)
	if l1l1l11_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䰐"),l11ll1_l1_ (u"࠭ࠧ䰑"),l111lll_l1_,str(l1l1l11_l1_))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰒"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			title = re.findall(l11ll1_l1_ (u"ࠨࠪส่า๊โสࡾส่า๊โ่ࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ䰓"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫ䰔"))[-2],re.DOTALL)
			if not title: title = re.findall(l11ll1_l1_ (u"ࠪࠬ࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ䰕"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭䰖"))[-2],re.DOTALL)
			if title: title = l11ll1_l1_ (u"ࠬࠦࠧ䰗") + title[0][1]
			else: title = l11ll1_l1_ (u"࠭ࠧ䰘")
			title = name + l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ䰙") + l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ䰚") + title
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䰛"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠪฬั๎ฯสࠢࠪ䰜") in title or l11ll1_l1_ (u"ࠫอา่ะ้ࠣࠫ䰝") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䰞") + title.replace(l11ll1_l1_ (u"࠭ศอ๊าอࠥ࠭䰟"),l11ll1_l1_ (u"ࠧࠨ䰠")).replace(l11ll1_l1_ (u"ࠨสฯ์ิํࠠࠨ䰡"),l11ll1_l1_ (u"ࠩࠪ䰢"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䰣"),l111l1_l1_+title,url,182,l1lll1_l1_)
	return
def PLAY(url):
	l11ll1l111ll_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䰤"))
	l111lll_l1_ = l11ll1l111ll_l1_[0]
	del l11ll1l111ll_l1_[0]
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭䰥"),headers,l11ll1_l1_ (u"࠭ࠧ䰦"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䰧"))
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨࡲࡲࡹ࠳ࡳࡪࡼࡨ࠾ࠥ࠸࠵ࡱࡺ࠾ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰨"),html,re.DOTALL)[0]
	if l1lllll_l1_ not in l11ll1l111ll_l1_: l11ll1l111ll_l1_.append(l1lllll_l1_)
	l1llll_l1_ = []
	# l11ll11lll1l_l1_
	for l1lllll_l1_ in l11ll1l111ll_l1_:
		if l11ll1_l1_ (u"ࠩ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䰩") in l1lllll_l1_:
			l11ll11lll1l_l1_ = l1lllll_l1_
			l1llll_l1_.append(l11ll11lll1l_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡦ࡯࡮ࠨ䰪"))
	# l11ll11lll11_l1_
	for l1lllll_l1_ in l11ll1l111ll_l1_:
		if l11ll1_l1_ (u"ࠫ࠿࠵࠯ࡷࡤ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠧ䰫") in l1lllll_l1_:
			html = OPENURL_CACHED(l1llllll_l1_,l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭䰬"),headers,l11ll1_l1_ (u"࠭ࠧ䰭"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䰮"))
			html = html.decode(l11ll1_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴ࠯࠴࠶࠺࠼ࠧ䰯")).encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䰰"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11ll11l1l11_l1_><l11ll11ll111_l1_ /><l11ll11l1l11_l1_ l11ll11lllll_l1_=l11ll1_l1_ (u"ࠥࡧࡪࡴࡴࡦࡴࠥ䰱")>(\*\*\*\*\*\*\*\*|13721411411.l11ll11l11l1_l1_|)
			html = html.replace(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䰲"),l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䰳"))
			html = html.replace(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䰴"),l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䰵"))
			html = html.replace(l11ll1_l1_ (u"ࠨ࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࡁࡨࡲࠡ࠱ࡁࡀࡩ࡯ࡶࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࡀࠪ䰶"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䰷"))
			html = html.replace(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡧࡵࡲࡥࡧࡵࠦࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧ࠭䰸"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䰹"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䰺"),html,re.DOTALL)
			if l1l1l11_l1_:
				#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䰻"),l11ll1_l1_ (u"ࠧࠨ䰼"),url,str(len(l1l1l11_l1_)))
				l11ll11l11ll_l1_,l11ll11ll1ll_l1_ = [],[]
				if len(l1l1l11_l1_)==1:
					title = l11ll1_l1_ (u"ࠨࠩ䰽")
					block = html
				else:
					for block in l1l1l11_l1_:
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠮ࠫࡁ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࠮ࠬ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䰾"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ䰿") + l111l_l1_[0][1]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䱀"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䱁") + l111l_l1_[0]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࠬࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䱂"),block,re.DOTALL)
						if l111l_l1_: block = l111l_l1_[0] + l11ll1_l1_ (u"ࠧࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䱃")
						l11ll11llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࠫ࠲࠯ࡅࠩࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵ࠧ䱄"),block,re.DOTALL)
						title = re.findall(l11ll1_l1_ (u"ࠩࡁࠤ࠯࠮࡛࡟࠾ࡁࡡ࠰࠯ࠠࠫ࠾ࠪ䱅"),l11ll11llll1_l1_[0][0],re.DOTALL)
						title = l11ll1_l1_ (u"ࠪࠤࠬ䱆").join(title)
						title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭䱇"))
						title = title.replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䱈"),l11ll1_l1_ (u"࠭ࠠࠨ䱉")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䱊"),l11ll1_l1_ (u"ࠨࠢࠪ䱋")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䱌"),l11ll1_l1_ (u"ࠪࠤࠬ䱍")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䱎"),l11ll1_l1_ (u"ࠬࠦࠧ䱏")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䱐"),l11ll1_l1_ (u"ࠧࠡࠩ䱑"))
						l11ll11l11ll_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศ࠻ࠩ䱒"), l11ll11l11ll_l1_)
					if l1l_l1_ == -1 : return
					title = l11ll11l11ll_l1_[l1l_l1_]
					block = l1l1l11_l1_[l1l_l1_]
				l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯࠭ࠧ࠭䱓"),block,re.DOTALL)
				l11ll11ll11l_l1_ = l1lllll_l1_[0]
				l1llll_l1_.append(l11ll11ll11l_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡊࡴࡸࡵ࡮ࠩ䱔"))
				block = block.replace(l11ll1_l1_ (u"ࠫๅ࠭䱕"),l11ll1_l1_ (u"ࠬ࠭䱖"))
				block = block.replace(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ䱗"),l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䱘"))
				block = block.replace(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ䱙"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䱚"))
				block = block.replace(l11ll1_l1_ (u"ࠪื๏ืแาษอࠤฬ๊สฮ็ํ่ࠬ䱛"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ䱜"))
				block = block.replace(l11ll1_l1_ (u"ࠬื่ศสฺࠤฬ๊สฮ็ํ่ࠬ䱝"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭䱞"))
				block = block.replace(l11ll1_l1_ (u"ࠧิ์ิๅึอสࠡษ็ู้อ็ะࠩ䱟"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䱠"))
				block = block.replace(l11ll1_l1_ (u"ࠩิ์ฬฮืࠡษ็ู้อ็ะࠩ䱡"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䱢"))
				l11ll11l1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࡜ࡥ࠭ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䱣"),block,re.DOTALL)
				for l11ll11ll1l1_l1_ in l11ll11l1ll1_l1_:
					#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䱤"),l11ll1_l1_ (u"࠭ࠧ䱥"),l11ll1_l1_ (u"ࠧࠨ䱦"),str(l11ll11ll1l1_l1_))
					type = re.findall(l11ll1_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭䱧"),l11ll11ll1l1_l1_)
					if type:
						if type[0]!=l11ll1_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䱨"): type = l11ll1_l1_ (u"ࠪࡣࡤ࠭䱩")+type[0]
						else: type = l11ll1_l1_ (u"ࠫࠬ䱪")
					items = re.findall(l11ll1_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ䱫"),l11ll11ll1l1_l1_,re.DOTALL)
					for l11ll11l1lll_l1_,l1lllll_l1_ in items:
						title = re.findall(l11ll1_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ䱬"),l11ll11l1lll_l1_)
						title = title[-1]
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䱭") + title + type
						l1llll_l1_.append(l1lllll_l1_)
	# l11ll1l11l11_l1_
	l11l111_l1_ = l111lll_l1_.replace(l11l1l_l1_,l11llllll1_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠨࠩ䱮"),headers,l11ll1_l1_ (u"ࠩࠪ䱯"),l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䱰"))
	items = re.findall(l11ll1_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱱"),html,re.DOTALL)
	#l11lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯ࡦ࡯ࡥࡩࡩࡓ࠭ࠩ࡞ࡺ࠯࠮࠳࠮ࠫࡁ࠱࡬ࡹࡳ࡬ࠪࠩ䱲"),html,re.DOTALL)
	#if l11lll1l1l_l1_:
	if items:
		#l11ll1l11l11_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࠩ䱳") + l11lll1l1l_l1_[-1] + l11ll1_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭䱴")
		l11ll1l11l11_l1_ = items[-1]
		l1llll_l1_.append(l11ll1l11l11_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡲࡦ࡮ࡲࡥࠨ䱵"))
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䱶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ䱷"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ䱸"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ䱹"),l11ll1_l1_ (u"࠭ࠫࠨ䱺"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ䱻"),headers,l11ll1_l1_ (u"ࠨࠩ䱼"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䱽"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࡂࠬ䱾"),html,re.DOTALL)
	l111ll1l1_l1_ = [ l11ll1_l1_ (u"ࠫࠬ䱿") ]
	l111l11l1_l1_ = [ l11ll1_l1_ (u"ࠬอไไๆࠣ์อี่็ࠢไ่ฯืࠧ䲀") ]
	for category,title in items:
		l111ll1l1_l1_.append(category)
		l111l11l1_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭䲁"), l111l11l1_l1_)
		if l1l_l1_ == -1 : return
		category = l111ll1l1_l1_[l1l_l1_]
	else: category = l11ll1_l1_ (u"ࠧࠨ䲂")
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭䲃")+search+l11ll1_l1_ (u"ࠩࠩࡱࡨࡧࡴ࠾ࠩ䲄")+category
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䲅"),l11ll1_l1_ (u"ࠫࠬ䲆"),url,url)
	l11111_l1_(url)
	return
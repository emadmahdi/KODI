# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡅࡏࡉࡆࡔࡅࡓࠩᯗ")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡇࡑࡔ࡟ࠨᯘ")
l1l1lll11l_l1_ = os.path.join(l1ll1l1111_l1_,l11ll1_l1_ (u"ࠪࡸࡪࡳࡰࠨᯙ"))
l1l11l1lll_l1_ = os.path.join(l1ll1l1111_l1_,l11ll1_l1_ (u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࠭ᯚ"))
l1l1ll1lll_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧᯛ"),l11ll1_l1_ (u"࠭ࡔࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪᯜ"))
l1l1l111l1_l1_ = l1ll11l111_l1_
l1l11ll111_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪᯝ")
l1l11ll11l_l1_ = l11ll1_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨᯞ")
l1l1ll1ll1_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬᯟ")
l1l1lll1l1_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩᯠ")
l1l11lll11_l1_ = l11ll1_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧᯡ")
l1l11lll1l_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨᯢ")
def MAIN(mode):
	if   mode==740: results = l1ll11llll_l1_()
	elif mode==741: results = l1ll11ll11_l1_(l1l1lll11l_l1_,True,True)
	elif mode==742: results = l1ll11ll11_l1_(l1l11l1lll_l1_,True,True)
	elif mode==743: results = l1ll11ll11_l1_(l1l1ll1lll_l1_,False,True)
	elif mode==744: results = l1l1l11111_l1_(l1l1l111l1_l1_,True)
	elif mode==745: results = l1l11l1l1l_l1_(True)
	elif mode==750: results = l1l1l1llll_l1_()
	elif mode==751: results = l1ll11ll11_l1_(l1l11ll111_l1_,False,True)
	elif mode==752: results = l1ll11ll11_l1_(l1l11ll11l_l1_,False,True)
	elif mode==753: results = l1ll11ll11_l1_(l1l1ll1ll1_l1_,False,True)
	elif mode==754: results = l1ll11ll11_l1_(l1l1lll1l1_l1_,False,True)
	elif mode==755: results = l1ll11ll11_l1_(l1l11lll11_l1_,False,True)
	elif mode==756: results = l1ll11ll11_l1_(l1l11lll1l_l1_,False,True)
	elif mode==757: results = l1l1ll111l_l1_(True)
	elif mode==758: results = l1l1l1l1ll_l1_()
	else: results = False
	return results
def l1ll11llll_l1_():
	l1l1llllll_l1_,l1ll11l1ll_l1_ = l1l11ll1l1_l1_(l1l1lll11l_l1_)
	l1l1lllll1_l1_,l1l1l11l1l_l1_ = l1l11ll1l1_l1_(l1l11l1lll_l1_)
	l1l1llll1l_l1_,l1l1l11ll1_l1_ = l1l11ll1l1_l1_(l1l1ll1lll_l1_)
	l1ll1111l1_l1_,l1l1l111ll_l1_ = l1l1l11lll_l1_(l1l1l111l1_l1_)
	l1ll1111l1_l1_ -= 36864
	l1l1l111ll_l1_ -= 1
	l1l11ll1ll_l1_ = l11ll1_l1_ (u"࠭ࠠࠩࠩᯣ")+l1ll11ll1l_l1_(l1l1llllll_l1_)+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫᯤ")+str(l1ll11l1ll_l1_)+l11ll1_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᯥ")
	l1l1l1ll1l_l1_ = l11ll1_l1_ (u"᯦ࠩࠣࠬࠬ")+l1ll11ll1l_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧᯧ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᯨ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠬࠦࠨࠨᯩ")+l1ll11ll1l_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᯪ")+str(l1l1l11ll1_l1_)+l11ll1_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᯫ")
	l1ll11lll1_l1_ = l11ll1_l1_ (u"ࠨࠢࠫࠫᯬ")+l1ll11ll1l_l1_(l1ll1111l1_l1_)+l11ll1_l1_ (u"ࠩࠬࠫᯭ")
	size = l1l1llllll_l1_+l1l1lllll1_l1_+l1l1llll1l_l1_+l1ll1111l1_l1_
	count = l1ll11l1ll_l1_+l1l1l11l1l_l1_+l1l1l11ll1_l1_+l1l1l111ll_l1_
	text = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᯮ")+l1ll11ll1l_l1_(size)+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨᯯ")+str(count)+l11ll1_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᯰ")
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᯱ"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤฬ๊ฬๆ์฼᯲ࠫ")+text,l11ll1_l1_ (u"ࠨ᯳ࠩ"),745)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᯴"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᯵"),l11ll1_l1_ (u"ࠫࠬ᯶"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᯷"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิฯࠣห้๋ไโษอࠤฬ๊ๅลไออࠬ᯸")+l1l11ll1ll_l1_,l11ll1_l1_ (u"ࠧࠨ᯹"),741)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᯺"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩ᯻")+l1l1l1ll1l_l1_,l11ll1_l1_ (u"ࠪࠫ᯼"),742)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᯽"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠩ᯾")+l1l1l1ll11_l1_,l11ll1_l1_ (u"࠭ࠧ᯿"),743)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰀ"),l111l1_l1_+l11ll1_l1_ (u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪᰁ")+l1ll11lll1_l1_,l11ll1_l1_ (u"ࠩࠪᰂ"),744)
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᰃ"),l11ll1_l1_ (u"ࠫࠬᰄ"))
	return
def l1l1l1llll_l1_():
	l1ll11l1l1_l1_ = True if l11ll1_l1_ (u"ࠬ࠵ࠧᰅ") in l1l1l1111l_l1_ else False
	if not l1ll11l1l1_l1_:
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᰆ"),l11ll1_l1_ (u"ࠧࠨᰇ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᰈ"),l11ll1_l1_ (u"ࠩ฼้้๐ษࠡฬ้฼๏็ࠠศๆฯ๋ฬุࠠๆฬ๋ๅึฯࠠโไฺࠤ้ษฬ่ิฬࠤ๏๎ๆไีࠣ࠲࠳่ࠦอ้สึ่ࠦไ๋ี้๋ࠣࠦๆ้฻ࠣ๎ํ์ใิࠩᰉ"))
		return
	l1l11lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᰊ"))
	if not l1l11lllll_l1_: l1l1l1l1ll_l1_()
	l1l1llllll_l1_,l1ll11l1ll_l1_ = l1l11ll1l1_l1_(l1l11ll111_l1_)
	l1l1lllll1_l1_,l1l1l11l1l_l1_ = l1l11ll1l1_l1_(l1l11ll11l_l1_)
	l1l1llll1l_l1_,l1l1l11ll1_l1_ = l1l11ll1l1_l1_(l1l1ll1ll1_l1_)
	l1ll1111l1_l1_,l1l1l111ll_l1_ = l1l11ll1l1_l1_(l1l1lll1l1_l1_)
	l1ll11111l_l1_,l1l1l11l11_l1_ = l1l11ll1l1_l1_(l1l11lll11_l1_)
	l1ll111111_l1_,l1l1lll1ll_l1_ = l1l11ll1l1_l1_(l1l11lll1l_l1_)
	l1l11ll1ll_l1_ = l11ll1_l1_ (u"ࠫࠥ࠮ࠧᰋ")+l1ll11ll1l_l1_(l1l1llllll_l1_)+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩᰌ")+str(l1ll11l1ll_l1_)+l11ll1_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᰍ")
	l1l1l1ll1l_l1_ = l11ll1_l1_ (u"ࠧࠡࠪࠪᰎ")+l1ll11ll1l_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᰏ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᰐ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᰑ")+l1ll11ll1l_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨᰒ")+str(l1l1l11ll1_l1_)+l11ll1_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᰓ")
	l1ll11lll1_l1_ = l11ll1_l1_ (u"࠭ࠠࠩࠩᰔ")+l1ll11ll1l_l1_(l1ll1111l1_l1_)+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫᰕ")+str(l1l1l111ll_l1_)+l11ll1_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᰖ")
	l1l1l1l111_l1_ = l11ll1_l1_ (u"ࠩࠣࠬࠬᰗ")+l1ll11ll1l_l1_(l1ll11111l_l1_)+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧᰘ")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᰙ")
	l1l1l1l1l1_l1_ = l11ll1_l1_ (u"ࠬࠦࠨࠨᰚ")+l1ll11ll1l_l1_(l1ll111111_l1_)+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᰛ")+str(l1l1lll1ll_l1_)+l11ll1_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᰜ")
	size = l1l1llllll_l1_+l1l1lllll1_l1_+l1l1llll1l_l1_+l1ll1111l1_l1_+l1ll11111l_l1_+l1ll111111_l1_
	count = l1ll11l1ll_l1_+l1l1l11l1l_l1_+l1l1l11ll1_l1_+l1l1l111ll_l1_+l1l1l11l11_l1_+l1l1lll1ll_l1_
	text = l11ll1_l1_ (u"ࠨࠢࠫࠫᰝ")+l1ll11ll1l_l1_(size)+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ᰞ")+str(count)+l11ll1_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᰟ")
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰠ"),l111l1_l1_+l11ll1_l1_ (u"ࠬหูุษฤࠤึิีสࠢๅีฬวษ๊ࠡๆฮฬฮษࠨᰡ"),l11ll1_l1_ (u"࠭ࠧᰢ"),758)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰣ"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึัࠥอไอ็ํ฽ࠬᰤ")+text,l11ll1_l1_ (u"ࠩࠪᰥ"),757)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᰦ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᰧ"),l11ll1_l1_ (u"ࠬ࠭ᰨ"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰩ"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧᰪ")+l1l11ll1ll_l1_,l11ll1_l1_ (u"ࠨࠩᰫ"),751)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰬ"),l111l1_l1_+l11ll1_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡤࡳࡱࡳࡦࡴࡾࠧᰭ")+l1l1l1ll1l_l1_,l11ll1_l1_ (u"ࠫࠬᰮ"),752)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰯ"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡷࡳࡲࡨࡳࡵࡱࡱࡩࡸ࠭ᰰ")+l1l1l1ll11_l1_,l11ll1_l1_ (u"ࠧࠨᰱ"),753)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰲ"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡲ࡯ࡨࡩࡨࡶࠬᰳ")+l1ll11lll1_l1_,l11ll1_l1_ (u"ࠪࠫᰴ"),754)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰵ"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫ࠬᰶ")+l1l1l1l111_l1_,l11ll1_l1_ (u"᰷࠭ࠧ"),755)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᰸"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨ᰹")+l1l1l1l1l1_l1_,l11ll1_l1_ (u"ࠩࠪ᰺"),756)
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᰻"),l11ll1_l1_ (u"ࠫࠬ᰼"))
	return
def l1l1l1l1ll_l1_():
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭᰽"),l11ll1_l1_ (u"࠭ࠧ᰾"),l11ll1_l1_ (u"ࠧࠨ᰿"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᱀"),l11ll1_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩ᱁"))
	if l1ll111lll_l1_==-1: return
	if l1ll111lll_l1_:
		l1ll11l11l_l1_ = True
		import subprocess
		try: subprocess.Popen(l11ll1_l1_ (u"ࠪࡷࡺ࠭᱂"))
		except: l1ll11l11l_l1_ = False
		if l1ll11l11l_l1_:
			l1l1ll11ll_l1_ = l1l11ll111_l1_+l11ll1_l1_ (u"ࠫࠥ࠭᱃")+l1l11ll11l_l1_+l11ll1_l1_ (u"ࠬࠦࠧ᱄")+l1l1ll1ll1_l1_+l11ll1_l1_ (u"࠭ࠠࠨ᱅")+l1l1lll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠩ᱆")+l1l11lll11_l1_+l11ll1_l1_ (u"ࠨࠢࠪ᱇")+l1l11lll1l_l1_
			proc = subprocess.Popen(l11ll1_l1_ (u"ࠩࡶࡹࠥ࠳ࡣࠡࠤࡦ࡬ࡲࡵࡤࠡ࠯ࡕࠤ࠵࠽࠷࠸ࠢࠪ᱈")+l1l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠦࠬ᱉"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ᱊"),l11ll1_l1_ (u"ࠬ࠭᱋"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᱌"),l11ll1_l1_ (u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส฿ืศรࠣห้ืฮึหࠪᱍ"))
			settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᱎ"),l11ll1_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᱏ"))
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ᱐"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ᱑"),l11ll1_l1_ (u"ࠬ࠭᱒"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᱓"),l11ll1_l1_ (u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧ᱔"))
	return
def l1ll11ll1l_l1_(size):
	for x in [l11ll1_l1_ (u"ࠨࡄࠪ᱕"),l11ll1_l1_ (u"ࠩࡎࡆࠬ᱖"),l11ll1_l1_ (u"ࠪࡑࡇ࠭᱗"),l11ll1_l1_ (u"ࠫࡌࡈࠧ᱘"),l11ll1_l1_ (u"࡚ࠬࡂࠨ᱙")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11ll1_l1_ (u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣᱚ")%(size,x)
	return text
def l1l11ll1l1_l1_(l1ll111ll1_l1_=l11ll1_l1_ (u"ࠧ࠯ࠩᱛ")):
	global l1l1ll1l1l_l1_,l1ll111l11_l1_
	l1l1ll1l1l_l1_,l1ll111l11_l1_ = 0,0
	def l1l1lll111_l1_(l1ll111ll1_l1_):
		global l1l1ll1l1l_l1_,l1ll111l11_l1_
		if os.path.exists(l1ll111ll1_l1_):
			if 0 and l11ll1_l1_ (u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩᱜ") in dir(os):
				# using l1l1llll11_l1_ l11ll1_l1_ (u"ࠩࡲࡷ࠳ࡹࡣࡢࡰࡧ࡭ࡷ࠭ᱝ") method (new in version 3.5)
				for l1l11l1ll1_l1_ in os.scandir(l1ll111ll1_l1_):
					if l1l11l1ll1_l1_.l1ll111l1l_l1_(follow_symlinks=False):
						l1l1lll111_l1_(l1l11l1ll1_l1_.path)
					elif l1l11l1ll1_l1_.l1l1l1l11l_l1_(follow_symlinks=False):
						l1l1ll1l1l_l1_ += l1l11l1ll1_l1_.stat().st_size
						l1ll111l11_l1_ += 1
			else:
				# using l11lll1l1_l1_, l1l1l1lll1_l1_ l1l11llll1_l1_ l11ll1_l1_ (u"ࠪࡳࡸ࠴࡬ࡪࡵࡷࡨ࡮ࡸࠧᱞ") method
				for l1l11l1ll1_l1_ in os.listdir(l1ll111ll1_l1_):
					l1l11l1l11_l1_ = os.path.abspath(os.path.join(l1ll111ll1_l1_,l1l11l1ll1_l1_))
					if os.path.isdir(l1l11l1l11_l1_):
						l1l1lll111_l1_(l1l11l1l11_l1_)
					elif os.path.isfile(l1l11l1l11_l1_):
						size,count = l1l1l11lll_l1_(l1l11l1l11_l1_)
						l1l1ll1l1l_l1_ += size
						l1ll111l11_l1_ += count
		return
	try: l1l1lll111_l1_(l1ll111ll1_l1_)
	except: pass
	return l1l1ll1l1l_l1_,l1ll111l11_l1_
def l1ll1111ll_l1_(l1l1ll1l11_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬᱟ"),l11ll1_l1_ (u"ࠬ࠭ᱠ"),l11ll1_l1_ (u"࠭ࠧᱡ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱢ"),l1l1ll1l11_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭ᱣ")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็็ๅࠥลࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᱤ"))
		if l1ll111lll_l1_!=1: return
	error = False
	if os.path.exists(l1l1ll1l11_l1_):
		try: os.remove(l1l1ll1l11_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᱥ"),l11ll1_l1_ (u"ࠫࠬᱦ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᱧ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᱨ"),l11ll1_l1_ (u"ࠧࠨᱩ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᱪ"),l11ll1_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᱫ"))
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᱬ"),l11ll1_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᱭ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᱮ"))
	return
def l1l11l1l1l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧᱯ"),l11ll1_l1_ (u"ࠧࠨᱰ"),l11ll1_l1_ (u"ࠨࠩᱱ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᱲ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯࠪᱳ")+l11ll1_l1_ (u"ࠫࡡࡴࠧᱴ")+l11ll1_l1_ (u"๋ࠬฬๅัࠣห้๋ไโษอࠤฬ๊ๅลไออࠥ࠴࠮๊่ࠡะ้ีࠠศๆ่่ๆอสࠡษ็้฻เุ่หࠣ࠲࠳่ࠦๆฮ็ำࠥอไึ๊ิࠤฬ๊โะ์่อࠥ࠴࠮๊ࠡอๅึ๐ฺࠡ็็ๅࠥ฻่าࠢส่ส฼วโษอࠫᱵ")+l11ll1_l1_ (u"࠭࡜࡯ࠩᱶ")+l11ll1_l1_ (u"ࠧภࠣࠤࠫᱷ")+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᱸ"))
		if l1ll111lll_l1_!=1: return
	l1ll11ll11_l1_(l1l1lll11l_l1_,True,False)
	l1ll11ll11_l1_(l1l11l1lll_l1_,True,False)
	l1ll11ll11_l1_(l1l1ll1lll_l1_,False,False)
	l1l1l11111_l1_(l1l1l111l1_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᱹ"),l11ll1_l1_ (u"ࠪࠫᱺ"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᱻ"),l11ll1_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᱼ"))
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᱽ"),l11ll1_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ᱾"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ᱿"))
	return
def l1l1ll111l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪᲀ"),l11ll1_l1_ (u"ࠪࠫᲁ"),l11ll1_l1_ (u"ࠫࠬᲂ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᲃ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦๅๅใสฮࠬᲄ")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪᲅ")+l11ll1_l1_ (u"ࠨࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠥ࠴࠮ࠡࡦࡵࡳࡵࡨ࡯ࡹࠢ࠱࠲ࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠢ࠱࠲ࠥࡲ࡯ࡨࡩࡨࡶࠥ࠴࠮ࠡ࡮ࡲ࡫ࠥ࠴࠮ࠡࡣࡱࡶࠬᲆ")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬᲇ")+l11ll1_l1_ (u"ࠪࡃࠦࠧࠧᲈ")+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ᲊ"))
		if l1ll111lll_l1_!=1: return
	l1ll11ll11_l1_(l1l11ll111_l1_,False,False)
	l1ll11ll11_l1_(l1l11ll11l_l1_,False,False)
	l1ll11ll11_l1_(l1l1ll1ll1_l1_,False,False)
	l1ll11ll11_l1_(l1l1lll1l1_l1_,False,False)
	l1ll11ll11_l1_(l1l11lll11_l1_,False,False)
	l1ll11ll11_l1_(l1l11lll1l_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ᲊ"),l11ll1_l1_ (u"࠭ࠧ᲋"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᲌"),l11ll1_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ᲍"))
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭᲎"),l11ll1_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭᲏"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨᲐ"))
	return
def l1l1l11111_l1_(l1l1ll11l1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭Ბ"),l11ll1_l1_ (u"࠭ࠧᲒ"),l11ll1_l1_ (u"ࠧࠨᲓ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᲔ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรࠦࠧࠧᲕ")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᲖ"))
		if l1ll111lll_l1_!=1: return
	conn = sqlite3.connect(l1l1ll11l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨᲗ"))
	cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪᲘ"))
	cc.execute(l11ll1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭Კ"))
	conn.commit()
	cc.execute(l11ll1_l1_ (u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨᲚ"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᲛ"),l11ll1_l1_ (u"ࠩࠪᲜ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ო"),l11ll1_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᲞ"))
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᲟ"),l11ll1_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᲠ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᲡ"))
	return
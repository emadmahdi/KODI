# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࠪ⭛")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡇࡍࡕࡢࠫ⭜")
def MAIN(mode,url,text,l1l1111_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll11l11ll_l1_(text)
	elif mode==542: results = l1ll1111lll_l1_(text,url,l1l1111_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭝"),l11ll1_l1_ (u"ࠧษฯฮࠤัี๊ะࠩ⭞"),l11ll1_l1_ (u"ࠨࠩ⭟"),549)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⭠"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࠣ็้๋วห่ࠢาื์ษࠡ࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⭡"),l11ll1_l1_ (u"ࠫࠬ⭢"),9999)
	l1ll111lll1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ⭣"),l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⭤"))
	if l1ll111lll1_l1_:
		l1ll111lll1_l1_ = l1ll111lll1_l1_[l11ll1_l1_ (u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ⭥")]
		for search in reversed(l1ll111lll1_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭦"),search,l11ll1_l1_ (u"ࠩࠪ⭧"),549,l11ll1_l1_ (u"ࠪࠫ⭨"),l11ll1_l1_ (u"ࠫࠬ⭩"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll1111l11_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll1l11ll_l1_ = search.replace(l111l1_l1_,l11ll1_l1_ (u"ࠬ࠭⭪"))
	l1l1lllllll_l1_(l1lll1l11ll_l1_)
	#l1l1llll1l1_l1_ = search+options+l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⭫")
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⭬"),l11ll1_l1_ (u"ࠨ฻่่ࠥฮอฬࠢฯ้ฬ฿๊ࠡ࠯ࠣࠫ⭭")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⭮"),542,l11ll1_l1_ (u"ࠪࠫ⭯"),l11ll1_l1_ (u"ࠫࠬ⭰"),l1lll1l11ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭱"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⭲"),l11ll1_l1_ (u"ࠧࠨ⭳"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭴"),l11ll1_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆใุ่ฮࠦ࠭ࠡࠩ⭵")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⭶"),542,l11ll1_l1_ (u"ࠫࠬ⭷"),l11ll1_l1_ (u"ࠬ࠭⭸"),l1lll1l11ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭹"),l11ll1_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥโิ็ฬࠤ࠲ࠦࠧ⭺")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⭻"),542,l11ll1_l1_ (u"ࠩࠪ⭼"),l11ll1_l1_ (u"ࠪࠫ⭽"),l1lll1l11ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭾"),l11ll1_l1_ (u"ࠬฮอฬ่๊ࠢๆืฯࠡ࠯ࠣࠫ⭿")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧ⮀"),541,l11ll1_l1_ (u"ࠧࠨ⮁"),l11ll1_l1_ (u"ࠨࠩ⮂"),l1lll1l11ll_l1_)
	return
def l1l1lllllll_l1_(l1ll11ll111_l1_):
	l1ll11ll1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮃"),l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮄"),l1ll11ll111_l1_)
	l1ll11ll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮅"),l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮆"),l111l1_l1_+l1ll11ll111_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮇"),l1ll11ll111_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮈"),l111l1_l1_+l1ll11ll111_l1_)
	old_value = l1ll11ll1l1_l1_+l1ll11ll11l_l1_
	if old_value: l1ll11ll111_l1_ = l111l1_l1_+l1ll11ll111_l1_
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮉"),l1ll11ll111_l1_,old_value,VERYLONG_CACHE)
	return
def l1ll11111ll_l1_():
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ⮊"),l11ll1_l1_ (u"ࠪࠫ⮋"),l11ll1_l1_ (u"ࠫࠬ⮌"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⮍"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪ⮎"))
	if l1ll111lll_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮏"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⮐"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨ⮑"))
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⮒"),l11ll1_l1_ (u"ࠫࠬ⮓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⮔"),l11ll1_l1_ (u"࠭สๆࠢห๊ัออࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠧ⮕"))
	return
def l1ll1111lll_l1_(l1ll1111l11_l1_,action,l1ll111l11l_l1_=l11ll1_l1_ (u"ࠧࠨ⮖")):
	l1ll111l1l1_l1_,l1ll111l1ll_l1_,l1ll11l1111_l1_,l1l1llll111_l1_,l1l1llll1ll_l1_,l1ll111llll_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⮗"):
		if action==l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮘"): l1ll11l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮙"),l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮚"),l111l1_l1_+l1ll1111l11_l1_)
		elif action==l11ll1_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⮛"): l1ll11l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ⮜"),l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⮝"),l1ll1111l11_l1_)
		elif action==l11ll1_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⮞"): l1ll11l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮟"),l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⮠"),(l1ll111l11l_l1_,l1ll1111l11_l1_))
	if not l1ll11l1111_l1_:
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫ์ึวࠡษ็ฬาัࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰ࡟ࡲࠬ⮡")
		l1ll11l1l1l_l1_ = l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤฬ๊ศฮอࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥ฿ๆࠡ࡞ࡱࠤࠧࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡࠩ⮢")+l1ll1111l11_l1_+l11ll1_l1_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠣࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊ศฮอࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠨ⮣")
		if action==l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⮤"): message = l1ll11l1l1l_l1_
		else: message = l1ll11l1l11_l1_+l1ll11l1l1l_l1_
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ⮥"),l11ll1_l1_ (u"ࠩࠪ⮦"),l11ll1_l1_ (u"ࠪࠫ⮧"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⮨"),message)
		if l1ll111lll_l1_!=1: return
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⮩"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪ⮪")+l1ll1111l11_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ⮫"))
		#global menuItemsLIST
		import threading
		#l1ll111ll1l_l1_ = [l11ll1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ⮬"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ⮭"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ⮮")]
		l1ll11lllll_l1_ = 1
		for l1ll111l11l_l1_ in l1ll111ll1l_l1_:
			l1l1llll111_l1_[l1ll111l11l_l1_] = []
			options = l11ll1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ⮯")
			if l11ll1_l1_ (u"ࠬ࠳ࠧ⮰") in l1ll111l11l_l1_: options = options+l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࠫ⮱")+l1ll111l11l_l1_+l11ll1_l1_ (u"ࠧࡠࠩ⮲")
			l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_ = l1l1lllll11_l1_(l1ll111l11l_l1_)
			if l1ll11lllll_l1_:
				threads[l1ll111l11l_l1_] = threading.Thread(target=l1ll111l111_l1_,args=(l1ll1111l11_l1_+options,))
				threads[l1ll111l11l_l1_].start()
			else: l1ll111l111_l1_(l1ll1111l11_l1_+options)
			DIALOG_NOTIFICATION(TRANSLATE(l1ll111l11l_l1_),l11ll1_l1_ (u"ࠨࠩ⮳"),time=1000)
		if l1ll11lllll_l1_:
			time.sleep(2)
			for l1ll111l11l_l1_ in l1ll111ll1l_l1_:
				threads[l1ll111l11l_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⮴"),l11ll1_l1_ (u"ࠪࠫ⮵"),l11ll1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠣࡪࡴࡻ࡮ࡥࡧࡧ࠾ࠬ⮶"),str(len(menuItemsLIST)))
		for l1ll111l11l_l1_ in l1ll111ll1l_l1_:
			l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_ = l1l1lllll11_l1_(l1ll111l11l_l1_)
			for l1ll1111ll1_l1_ in menuItemsLIST:
				type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ = l1ll1111ll1_l1_
				if l1ll11llll1_l1_ in name:
					if l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࠫ⮷") in l1ll111l11l_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⮸")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⮹")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⮺")]: continue
						if l11ll1_l1_ (u"ุࠩๅาฯࠧ⮻") not in name:
							if   type==l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⮼"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⮽")
							elif type==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⮾"): l1ll111l11l_l1_ = l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⮿")
							elif type==l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯀"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⯁")
						else:
							if   l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ⯂") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭⯃")
							elif l11ll1_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫ⯄") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⯅")
							elif l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭⯆") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯇")
					elif l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲࠭⯈") in l1ll111l11l_l1_ and 729>=mode>=710:
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ⯉")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯊")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⯋")]: continue
						if l11ll1_l1_ (u"ࠬ฻แฮหࠪ⯌") not in name:
							if   type==l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ⯍"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⯎")
							elif type==l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⯏"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⯐")
							elif type==l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯑"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⯒")
						else:
							if   l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ⯓") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ⯔")
							elif l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧ⯕") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⯖")
							elif l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ⯗") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯘")
					elif l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࠭⯙") in l1ll111l11l_l1_ and 149>=mode>=140:
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯚")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯛")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯜")]: continue
						if l11ll1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⯝") in name or l11ll1_l1_ (u"ࠩ࠽࠾ࠥ࠭⯞") in name:
							continue
							#if   l111_l1_==l11ll1_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯟"): l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯠")
							#elif l111_l1_==l11ll1_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯡"): l1ll111l11l_l1_ = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯢")
							#else: l1ll111l11l_l1_ = l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯣")
						else:
							if   mode==144 and l11ll1_l1_ (u"ࠨࡗࡖࡉࡗ࠭⯤") in name: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯥")
							elif mode==144 and l11ll1_l1_ (u"ࠪࡇࡍࡔࡌࠨ⯦") in name: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯧")
							elif mode==144 and l11ll1_l1_ (u"ࠬࡒࡉࡔࡖࠪ⯨") in name: l1ll111l11l_l1_ = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯩")
							elif mode==143: l1ll111l11l_l1_ = l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯪")
							else: continue
					elif l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࠧ⯫") in l1ll111l11l_l1_ and 419>=mode>=400:
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯬")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯭")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ⯮")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ⯯")]: continue
						if   mode in [401,405]: l1ll111l11l_l1_ = l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ⯰")
						elif mode in [402,406]: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯱")
						elif mode in [403,404]: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭⯲")
						elif mode in [412,413]: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ⯳")
					elif l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࠪ⯴") in l1ll111l11l_l1_ and 39>=mode>=30:
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⯵")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⯶")]: continue
						if   mode in [32,39]: l1ll111l11l_l1_ = l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ⯷")
						elif mode in [33,39]: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭⯸")
					elif l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࠨ⯹") in l1ll111l11l_l1_ and 29>=mode>=20:
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⯺")]: continue
						if l1ll1111ll1_l1_ in l1l1llll111_l1_[l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⯻")]: continue
						if   l11ll1_l1_ (u"ࠫ࠴ࡧࡲ࠯ࠩ⯼") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⯽")
						elif l11ll1_l1_ (u"࠭࠯ࡦࡰ࠱ࠫ⯾") in url: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⯿")
					#elif l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࠬⰀ") in l1ll111l11l_l1_ and 319>=mode>=310:
					#	if l1ll1111ll1_l1_ in l1l1llll111_l1_[l1ll111l11l_l1_]: continue
					#	if mode==312: l1ll111l11l_l1_ = l1ll111111l_l1_+l11ll1_l1_ (u"ࠩ࠰ࡅ࡚ࡊࡉࡐࡕࠪⰁ")
					#	elif l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴ࠮ࠩⰂ") in url: l1ll111l11l_l1_ = l1ll111111l_l1_+l11ll1_l1_ (u"ࠫ࠲ࡇࡌࡃࡗࡐࡗࠬⰃ")
					#	else: l1ll111l11l_l1_ = l1ll111111l_l1_+l11ll1_l1_ (u"ࠬ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧⰄ")
					l1l1llll111_l1_[l1ll111l11l_l1_].append(l1ll1111ll1_l1_)
		menuItemsLIST[:] = []
		for l1ll111l11l_l1_ in list(l1l1llll111_l1_.keys()):
			l1l1llll1ll_l1_[l1ll111l11l_l1_] = []
			l1ll111llll_l1_[l1ll111l11l_l1_] = []
			for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ in l1l1llll111_l1_[l1ll111l11l_l1_]:
				l1ll1111ll1_l1_ = (type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_)
				if l11ll1_l1_ (u"࠭ีโฯฬࠫⰅ") in name and type==l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰆ"): l1ll111llll_l1_[l1ll111l11l_l1_].append(l1ll1111ll1_l1_)
				else: l1l1llll1ll_l1_[l1ll111l11l_l1_].append(l1ll1111ll1_l1_)
		l1ll11l11l1_l1_ = [(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⰷ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰈ"),l11ll1_l1_ (u"ࠪࠫⰉ"),157,l11ll1_l1_ (u"ࠫࠬⰊ"),l11ll1_l1_ (u"ࠬ࠭Ⰻ"),l11ll1_l1_ (u"࠭ࠧⰌ"),l11ll1_l1_ (u"ࠧࠨⰍ"),l11ll1_l1_ (u"ࠨࠩⰎ"))]
		for l1ll111l11l_l1_ in l1ll111ll11_l1_:
			if l1ll111l11l_l1_==l1ll11111l1_l1_[0]: l1ll11l11l1_l1_ = [(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰏ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰐ"),l11ll1_l1_ (u"ࠫࠬⰑ"),157,l11ll1_l1_ (u"ࠬ࠭Ⱂ"),l11ll1_l1_ (u"࠭ࠧⰓ"),l11ll1_l1_ (u"ࠧࠨⰔ"),l11ll1_l1_ (u"ࠨࠩⰕ"),l11ll1_l1_ (u"ࠩࠪⰖ"))]
			elif l1ll111l11l_l1_==l1ll11ll1ll_l1_[0]: l1ll11l11l1_l1_ = [(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰗ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰘ"),l11ll1_l1_ (u"ࠬ࠭Ⱉ"),157,l11ll1_l1_ (u"࠭ࠧⰚ"),l11ll1_l1_ (u"ࠧࠨⰛ"),l11ll1_l1_ (u"ࠨࠩⰜ"),l11ll1_l1_ (u"ࠩࠪⰝ"),l11ll1_l1_ (u"ࠪࠫⰞ"))]
			elif l1ll111l11l_l1_==l1l1llll11l_l1_[0]: l1ll11l11l1_l1_ = [(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰟ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰠ"),l11ll1_l1_ (u"࠭ࠧⰡ"),157,l11ll1_l1_ (u"ࠧࠨⰢ"),l11ll1_l1_ (u"ࠨࠩⰣ"),l11ll1_l1_ (u"ࠩࠪⰤ"),l11ll1_l1_ (u"ࠪࠫⰥ"),l11ll1_l1_ (u"ࠫࠬⰦ"))]
			if l1ll111l11l_l1_ not in l1l1llll1ll_l1_.keys(): continue
			if l1l1llll1ll_l1_[l1ll111l11l_l1_]:
				l1l1llllll1_l1_ = TRANSLATE(l1ll111l11l_l1_)
				l1ll1111l1l_l1_ = [(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⰧ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞࠿ࡀࡁࡂࡃࠠࠨⰨ")+l1l1llllll1_l1_+l11ll1_l1_ (u"ࠧࠡ࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰩ"),l11ll1_l1_ (u"ࠨࠩⰪ"),9999,l11ll1_l1_ (u"ࠩࠪⰫ"),l11ll1_l1_ (u"ࠪࠫⰬ"),l11ll1_l1_ (u"ࠫࠬⰭ"),l11ll1_l1_ (u"ࠬ࠭Ⱞ"),l11ll1_l1_ (u"࠭ࠧⰯ"))]
				if 0:
					l1ll11lll11_l1_ = l1ll1111l11_l1_+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫⰰ")+l11ll1_l1_ (u"ࠨสะฯࠬⰱ")+l11ll1_l1_ (u"ࠩࠣࠫⰲ")+l1l1llllll1_l1_
				else:
					l1ll11lll11_l1_ = l11ll1_l1_ (u"ࠪฬาัࠧⰳ")+l11ll1_l1_ (u"ࠫࠥ࠭ⰴ")+l1l1llllll1_l1_+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩⰵ")+l1ll1111l11_l1_
				if len(l1l1llll1ll_l1_[l1ll111l11l_l1_])<8: l1ll11l111l_l1_ = []
				else:
					l1ll11lll1l_l1_ = l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩⰶ")+l1ll11lll11_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⰷ")
					l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰸ"),l111l1_l1_+l1ll11lll1l_l1_,l11ll1_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨⰹ"),542,l11ll1_l1_ (u"ࠪࠫⰺ"),l1ll111l11l_l1_,l1ll1111l11_l1_,l11ll1_l1_ (u"ࠫࠬⰻ"),l11ll1_l1_ (u"ࠬ࠭ⰼ"))]
				l1ll11l1ll1_l1_ = l1l1llll1ll_l1_[l1ll111l11l_l1_]+l1ll111llll_l1_[l1ll111l11l_l1_]
				l1ll111l1ll_l1_ += l1ll11l11l1_l1_+l1ll1111l1l_l1_+l1ll11l1ll1_l1_[:7]+l1ll11l111l_l1_
				l1l1lllll1l_l1_ = [(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰽ"),l111l1_l1_+l1ll11lll11_l1_,l11ll1_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⰾ"),542,l11ll1_l1_ (u"ࠨࠩⰿ"),l1ll111l11l_l1_,l1ll1111l11_l1_,l11ll1_l1_ (u"ࠩࠪⱀ"),l11ll1_l1_ (u"ࠪࠫⱁ"))]
				l1ll111l1l1_l1_ += l1ll11l11l1_l1_+l1l1lllll1l_l1_
				l1ll11l11l1_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪⱂ"),(l1ll111l11l_l1_,l1ll1111l11_l1_),l1ll11l1ll1_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫⱃ"),l1ll1111l11_l1_,l1ll111l1ll_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱄ"),l1ll1111l11_l1_)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬⱅ"),l111l1_l1_+l1ll1111l11_l1_,l1ll111l1l1_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩⱆ"),l11ll1_l1_ (u"ࠩࠪⱇ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ⱈ"),l11ll1_l1_ (u"ࠫฬ๊ศฮอࠣห้าๅศ฻ํࠤฬ์ส่๋ࠣฬ๋าวฮࠢ࡟ࡲࡡࡴࠠห็ࠣฮำุ๊็ࠢส่๋ะววฮࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะ๊ࠥๅะหࠣฯ้อห๋่ࠣ๎ํ๋ࠠๅๅํࠤฯูสุ์฼ࠤฬู๊้ัฬࠤส๊๊่ษࠣฬิ๎ๆࠡ฻่่ࠥฮอฬࠢฯำ๏ีࠧⱉ"))
		if action==l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⱊ") and l1ll111l1l1_l1_: l1ll11l1111_l1_ = l1ll111l1l1_l1_
		else: l1ll11l1111_l1_ = l1ll111l1ll_l1_
	if action!=l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬⱋ"):
		for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ in l1ll11l1111_l1_:
			if action in [l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱌ"),l11ll1_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱍ")] and l11ll1_l1_ (u"ุࠩๅาฯࠧⱎ") in name and type==l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱏ"): continue
			addMenuItem(type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_)
	return
def l1ll11l11ll_l1_(l1ll1111l11_l1_=l11ll1_l1_ (u"ࠫࠬⱐ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll1111l11_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬⱑ"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪⱒ")+search+l11ll1_l1_ (u"ࠧࠡ࡟ࠪⱓ"))
	l1111ll_l1_ = search+options
	if 0:
		l1ll11l1lll_l1_,l1lll1l11ll_l1_ = search+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬⱔ"),l11ll1_l1_ (u"ࠩࠪⱕ")
	else:
		l1ll11l1lll_l1_,l1lll1l11ll_l1_ = l11ll1_l1_ (u"ࠪࠫⱖ"),l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨⱗ")+search
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⱘ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⱙ"),l11ll1_l1_ (u"ࠧࠨⱚ"),157)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱛ"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨⱜ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠࡎ࠵ࡘࠫⱝ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬⱞ"),719,l11ll1_l1_ (u"ࠬ࠭ⱟ"),l11ll1_l1_ (u"࠭ࠧⱠ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱡ"),l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧⱢ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦࡉࡑࡖ࡙ࠫⱣ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⱤ"),239,l11ll1_l1_ (u"ࠫࠬⱥ"),l11ll1_l1_ (u"ࠬ࠭ⱦ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱨ"),l11ll1_l1_ (u"ࠧࡠࡄࡎࡖࡤ࠭ⱨ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬ่ืวࠨⱩ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࠪⱪ"),379,l11ll1_l1_ (u"ࠪࠫⱫ"),l11ll1_l1_ (u"ࠫࠬⱬ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱭ"),l11ll1_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬⱮ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหห๋๐สࠨⱯ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨࠩⱰ"),39,l11ll1_l1_ (u"ࠩࠪⱱ"),l11ll1_l1_ (u"ࠪࠫⱲ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱳ"),l11ll1_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫⱴ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠศใ็ห๊࠭Ⱶ"),l11ll1_l1_ (u"ࠧࠨⱶ"),39,l11ll1_l1_ (u"ࠨࠩⱷ"),l11ll1_l1_ (u"ࠩࠪⱸ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨⱹ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱺ"),l11ll1_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫⱻ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨⱼ"),l11ll1_l1_ (u"ࠧࠨⱽ"),39,l11ll1_l1_ (u"ࠨࠩⱾ"),l11ll1_l1_ (u"ࠩࠪⱿ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙࡟ࠨⲀ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲁ"),l11ll1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲂ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪⲃ"),l11ll1_l1_ (u"ࠧࠨⲄ"),149,l11ll1_l1_ (u"ࠨࠩⲅ"),l11ll1_l1_ (u"ࠩࠪⲆ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪⲇ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲈ"),l11ll1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲉ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧⲊ"),l11ll1_l1_ (u"ࠧࠨⲋ"),149,l11ll1_l1_ (u"ࠨࠩⲌ"),l11ll1_l1_ (u"ࠩࠪⲍ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭Ⲏ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲏ"),l11ll1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲐ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧⲑ"),l11ll1_l1_ (u"ࠧࠨⲒ"),149,l11ll1_l1_ (u"ࠨࠩⲓ"),l11ll1_l1_ (u"ࠩࠪⲔ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬⲕ"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲖ"),l11ll1_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫⲗ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪⲘ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠧࠨⲙ"),19,l11ll1_l1_ (u"ࠨࠩⲚ"),l11ll1_l1_ (u"ࠩࠪⲛ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲜ"),l11ll1_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪⲝ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫⲞ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧⲟ"),739,l11ll1_l1_ (u"ࠧࠨⲠ"),l11ll1_l1_ (u"ࠨࠩⲡ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲢ"),l11ll1_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩⲣ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫⲤ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭ⲥ"),329,l11ll1_l1_ (u"࠭ࠧⲦ"),l11ll1_l1_ (u"ࠧࠨⲧ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲨ"),l11ll1_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⲩ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩⲪ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬⲫ"),579,l11ll1_l1_ (u"ࠬ࠭Ⲭ"),l11ll1_l1_ (u"࠭ࠧⲭ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲮ"),l11ll1_l1_ (u"ࠨࡡࡈࡋࡇࡥࠧⲯ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧⲰ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⲱ"),129,l11ll1_l1_ (u"ࠫࠬⲲ"),l11ll1_l1_ (u"ࠬ࠭ⲳ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲵ"),l11ll1_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭ⲵ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨⲶ"),l11ll1_l1_ (u"ࠩࠪⲷ"),409,l11ll1_l1_ (u"ࠪࠫⲸ"),l11ll1_l1_ (u"ࠫࠬⲹ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࡠࠩⲺ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲻ"),l11ll1_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭Ⲽ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬⲽ"),l11ll1_l1_ (u"ࠩࠪⲾ"),409,l11ll1_l1_ (u"ࠪࠫⲿ"),l11ll1_l1_ (u"ࠫࠬⳀ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬⳁ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳃ"),l11ll1_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭ⳃ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬⳄ"),l11ll1_l1_ (u"ࠩࠪⳅ"),409,l11ll1_l1_ (u"ࠪࠫⳆ"),l11ll1_l1_ (u"ࠫࠬⳇ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫⳈ"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳉ"),l11ll1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭Ⳋ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨࠢࠣฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫⳋ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠬⳌ"),l11ll1_l1_ (u"ࠪࠫⳍ"),29,l11ll1_l1_ (u"ࠫࠬⳎ"),l11ll1_l1_ (u"ࠬ࠭ⳏ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳑ"),l11ll1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭ⳑ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧⳒ"),l11ll1_l1_ (u"ࠩࠪⳓ"),29,l11ll1_l1_ (u"ࠪࠫⳔ"),l11ll1_l1_ (u"ࠫࠬⳕ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࡡࠪⳖ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳗ"),l11ll1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭Ⳙ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪⳙ"),l11ll1_l1_ (u"ࠩࠪⳚ"),29,l11ll1_l1_ (u"ࠪࠫⳛ"),l11ll1_l1_ (u"ࠫࠬⳜ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࡢࠫⳝ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳟ"),l11ll1_l1_ (u"ࠧࡠࡃࡎࡓࡤ࠭ⳟ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩⳠ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࠪⳡ"),79,l11ll1_l1_ (u"ࠪࠫⳢ"),l11ll1_l1_ (u"ࠫࠬⳣ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳤ"),l11ll1_l1_ (u"࠭࡟ࡂࡍ࡚ࡣࠬ⳥")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨ⳦")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨࠩ⳧"),249,l11ll1_l1_ (u"ࠩࠪ⳨"),l11ll1_l1_ (u"ࠪࠫ⳩"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳪"),l11ll1_l1_ (u"ࠬࡥࡍࡓࡈࠪⳫ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧⳬ"),l11ll1_l1_ (u"ࠧࠨⳭ"),49,l11ll1_l1_ (u"ࠨࠩⳮ"),l11ll1_l1_ (u"ࠩࠪ⳯"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳰"),l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪ⳱")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไࠤ๊อใิࠩⳲ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧⳳ"),59,l11ll1_l1_ (u"ࠧࠨ⳴"),l11ll1_l1_ (u"ࠨࠩ⳵"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),l11ll1_l1_ (u"ࠪࡣࡋ࡚ࡍࡠࠩ⳷")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧ⳸")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭⳹"),69,l11ll1_l1_ (u"࠭ࠧ⳺"),l11ll1_l1_ (u"ࠧࠨ⳻"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳼"),l11ll1_l1_ (u"ࠩࡢࡏ࡜࡚࡟ࠨ⳽")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪ⳾"),l11ll1_l1_ (u"ࠫࠬ⳿"),139,l11ll1_l1_ (u"ࠬ࠭ⴀ"),l11ll1_l1_ (u"࠭ࠧⴁ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴂ"),l11ll1_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧⴃ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨⴄ"),l11ll1_l1_ (u"ࠪࠫⴅ"),319,l11ll1_l1_ (u"ࠫࠬⴆ"),l11ll1_l1_ (u"ࠬ࠭ⴇ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴈ"),l11ll1_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴉ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬⴊ"),l11ll1_l1_ (u"ࠩࠪⴋ"),319,l11ll1_l1_ (u"ࠪࠫⴌ"),l11ll1_l1_ (u"ࠫࠬⴍ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙࡟ࠨⴎ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l11ll1_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴐ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠๆฮ็ำࠬⴑ"),l11ll1_l1_ (u"ࠩࠪⴒ"),319,l11ll1_l1_ (u"ࠪࠫⴓ"),l11ll1_l1_ (u"ࠫࠬⴔ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘࡥࠧⴕ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴖ"),l11ll1_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴗ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧⴘ"),l11ll1_l1_ (u"ࠩࠪⴙ"),319,l11ll1_l1_ (u"ࠪࠫⴚ"),l11ll1_l1_ (u"ࠫࠬⴛ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘࡥࠧⴜ"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴝ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⴞ"),l11ll1_l1_ (u"ࠨࠩⴟ"),157)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴠ"),l11ll1_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩⴡ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใหๅ๋ฮࠬⴢ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭ⴣ"),679,l11ll1_l1_ (u"࠭ࠧⴤ"),l11ll1_l1_ (u"ࠧࠨⴥ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⴦"),l11ll1_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨⴧ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪࠤอำหࠡ็๋ๆ฾ࠦแอำุࠣํ࠭⴨")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠭⴩"),l11ll1_l1_ (u"ࠬ࠭⴪"),399,l11ll1_l1_ (u"࠭ࠧ⴫"),l11ll1_l1_ (u"ࠧࠨ⴬"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴭ"),l11ll1_l1_ (u"ࠩࡢࡘ࡛ࡌ࡟ࠨ⴮")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ⴯")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬⴰ"),469,l11ll1_l1_ (u"ࠬ࠭ⴱ"),l11ll1_l1_ (u"࠭ࠧⴲ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴳ"),l11ll1_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧⴴ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬⴵ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⴶ"),459,l11ll1_l1_ (u"ࠫࠬⴷ"),l11ll1_l1_ (u"ࠬ࠭ⴸ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴹ"),l11ll1_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭ⴺ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋ว่ࠡส์ࠬⴻ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࠪⴼ"),309,l11ll1_l1_ (u"ࠪࠫⴽ"),l11ll1_l1_ (u"ࠫࠬⴾ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴿ"),l11ll1_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬⵀ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๋ࠢ๎ู๊ࠥๆษࠪⵁ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨࠩⵂ"),569,l11ll1_l1_ (u"ࠩࠪⵃ"),l11ll1_l1_ (u"ࠪࠫⵄ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵅ"),l11ll1_l1_ (u"ࠬࡥࡓࡉࡐࡢࠫⵆ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦๆ๋๊ีࠫⵇ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠧࠨⵈ"),589,l11ll1_l1_ (u"ࠨࠩⵉ"),l11ll1_l1_ (u"ࠩࠪⵊ"),l1111ll_l1_+l11ll1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨⵋ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵌ"),l11ll1_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫⵍ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ็ส๎ู๊ࠥๆษࠪⵎ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠧࠨⵏ"),369,l11ll1_l1_ (u"ࠨࠩⵐ"),l11ll1_l1_ (u"ࠩࠪⵑ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵒ"),l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪⵓ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไࠤอื่ࠨⵔ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧⵕ"),489,l11ll1_l1_ (u"ࠧࠨⵖ"),l11ll1_l1_ (u"ࠨࠩⵗ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵘ"),l11ll1_l1_ (u"ࠪࡣࡆࡘࡓࡠࠩⵙ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨⵚ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭ⵛ"),259,l11ll1_l1_ (u"࠭ࠧⵜ"),l11ll1_l1_ (u"ࠧࠨⵝ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵞ"),l11ll1_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨⵟ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩⵠ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬⵡ"),429,l11ll1_l1_ (u"ࠬ࠭ⵢ"),l11ll1_l1_ (u"࠭ࠧⵣ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵤ"),l11ll1_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧⵥ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨⵦ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⵧ"),119,l11ll1_l1_ (u"ࠫࠬ⵨"),l11ll1_l1_ (u"ࠬ࠭⵩"),l1111ll_l1_+l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ⵪"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⵫"),l11ll1_l1_ (u"ࠨࡡࡐ࠸࡚ࡥࠧ⵬")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨ⵭"),l11ll1_l1_ (u"ࠪࠫ⵮"),389,l11ll1_l1_ (u"ࠫࠬⵯ"),l11ll1_l1_ (u"ࠬ࠭⵰"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵱"),l11ll1_l1_ (u"ࠧࡠࡇࡊ࡚ࡤ࠭⵲")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡสํืฯࠦࡶࡪࡲࠪ⵳"),l11ll1_l1_ (u"ࠩࠪ⵴"),229,l11ll1_l1_ (u"ࠪࠫ⵵"),l11ll1_l1_ (u"ࠫࠬ⵶"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⵷"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⵸"),l11ll1_l1_ (u"ࠧࠨ⵹"),157)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵺"),l11ll1_l1_ (u"ࠩࡢࡐࡗࡠ࡟ࠨ⵻")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๊ࠥวา๊ีหࠬ⵼")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬ⵽"),709,l11ll1_l1_ (u"ࠬ࠭⵾"),l11ll1_l1_ (u"⵿࠭ࠧ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶀ"),l11ll1_l1_ (u"ࠨࡡࡉࡗ࡙ࡥࠧⶁ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆ๎ำหษࠪⶂ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⶃ"),609,l11ll1_l1_ (u"ࠫࠬⶄ"),l11ll1_l1_ (u"ࠬ࠭ⶅ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶆ"),l11ll1_l1_ (u"ࠧࡠࡈࡅࡏࡤ࠭ⶇ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅอืใสࠩⶈ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࠪⶉ"),629,l11ll1_l1_ (u"ࠪࠫⶊ"),l11ll1_l1_ (u"ࠫࠬⶋ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶌ"),l11ll1_l1_ (u"࠭࡟࡚ࡓࡗࡣࠬⶍ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํห็๎สࠨⶎ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨࠩⶏ"),669,l11ll1_l1_ (u"ࠩࠪⶐ"),l11ll1_l1_ (u"ࠪࠫⶑ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶒ"),l11ll1_l1_ (u"ࠬࡥࡂࡓࡕࡢࠫⶓ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสิืฯ๐ฬࠨⶔ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠧࠨⶕ"),659,l11ll1_l1_ (u"ࠨࠩⶖ"),l11ll1_l1_ (u"ࠩࠪ⶗"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶘"),l11ll1_l1_ (u"ࠫࡤࡎࡌࡄࡡࠪ⶙")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿่ࠠๆสࠤุ๐ๅศࠩ⶚")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧ⶛"),89,l11ll1_l1_ (u"ࠧࠨ⶜"),l11ll1_l1_ (u"ࠨࠩ⶝"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⶞"),l11ll1_l1_ (u"ࠪࡣࡉࡘ࠷ࡠࠩ⶟")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨⶠ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭ⶡ"),689,l11ll1_l1_ (u"࠭ࠧⶢ"),l11ll1_l1_ (u"ࠧࠨⶣ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶤ"),l11ll1_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨⶥ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨⶦ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬ⶧"),99,l11ll1_l1_ (u"ࠬ࠭ⶨ"),l11ll1_l1_ (u"࠭ࠧⶩ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶪ"),l11ll1_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧⶫ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧⶬ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫⶭ"),479,l11ll1_l1_ (u"ࠫࠬⶮ"),l11ll1_l1_ (u"ࠬ࠭⶯"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶰ"),l11ll1_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ⶱ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡ฻หำํ࠭ⶲ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠩࠪⶳ"),559,l11ll1_l1_ (u"ࠪࠫⶴ"),l11ll1_l1_ (u"ࠫࠬⶵ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶶ"),l11ll1_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬ⶷")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫⶸ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠨࠩⶹ"),699,l11ll1_l1_ (u"ࠩࠪⶺ"),l11ll1_l1_ (u"ࠪࠫⶻ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶼ"),l11ll1_l1_ (u"ࠬࡥࡁࡉࡍࡢࠫⶽ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬⶾ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠧࠨ⶿"),619,l11ll1_l1_ (u"ࠨࠩⷀ"),l11ll1_l1_ (u"ࠩࠪⷁ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷂ"),l11ll1_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪⷃ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪⷄ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"࠭ࠧⷅ"),639,l11ll1_l1_ (u"ࠧࠨⷆ"),l11ll1_l1_ (u"ࠨࠩ⷇"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷈ"),l11ll1_l1_ (u"ࠪࡣࡘࡎࡔࡠࠩⷉ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪⷊ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭ⷋ"),649,l11ll1_l1_ (u"࠭ࠧⷌ"),l11ll1_l1_ (u"ࠧࠨⷍ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷎ"),l11ll1_l1_ (u"ࠩࡢࡉࡌࡔ࡟ࠨ⷏")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์๊ࠣฬ๎ࠧⷐ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬⷑ"),439,l11ll1_l1_ (u"ࠬ࠭ⷒ"),l11ll1_l1_ (u"࠭ࠧⷓ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷔ"),l11ll1_l1_ (u"ࠨࡡࡉࡌ࠷ࡥࠧⷕ")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩⷖ")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠪࠫ⷗"),599,l11ll1_l1_ (u"ࠫࠬⷘ"),l11ll1_l1_ (u"ࠬ࠭ⷙ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷚ"),l11ll1_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭ⷛ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡัํำࠬⷜ"),l11ll1_l1_ (u"ࠩࠪⷝ"),449,l11ll1_l1_ (u"ࠪࠫⷞ"),l11ll1_l1_ (u"ࠫࠬ⷟"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷠ"),l11ll1_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬⷡ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส็ํอๅࠡๅส้ࠬⷢ"),l11ll1_l1_ (u"ࠨࠩⷣ"),359,l11ll1_l1_ (u"ࠩࠪⷤ"),l11ll1_l1_ (u"ࠪࠫⷥ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷦ"),l11ll1_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫⷧ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫⷨ"),l11ll1_l1_ (u"ࠧࠨⷩ"),499,l11ll1_l1_ (u"ࠨࠩⷪ"),l11ll1_l1_ (u"ࠩࠪⷫ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷬ"),l11ll1_l1_ (u"ࠫࡤࡇࡒࡍࡡࠪⷭ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ฺࠠำหࠤ้๐่็ิࠪⷮ"),l11ll1_l1_ (u"࠭ࠧⷯ"),209,l11ll1_l1_ (u"ࠧࠨⷰ"),l11ll1_l1_ (u"ࠨࠩⷱ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷲ"),l11ll1_l1_ (u"ࠪࡣࡍࡋࡌࡠࠩⷳ")+l1lll1l11ll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫⷴ"),l11ll1_l1_ (u"ࠬ࠭ⷵ"),99,l11ll1_l1_ (u"࠭ࠧⷶ"),l11ll1_l1_ (u"ࠧࠨⷷ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷸ"),l11ll1_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨⷹ")+search+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥา์ึࠤๆ๎ั๊ࠡอุࠬⷺ"),l11ll1_l1_ (u"ࠫࠬⷻ"),218,l11ll1_l1_ (u"ࠬ࠭ⷼ"),l11ll1_l1_ (u"࠭ࠧⷽ"),search) # 219
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷾ"),l11ll1_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧⷿ")+search+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ⸀"),l11ll1_l1_ (u"ࠪࠫ⸁"),188,l11ll1_l1_ (u"ࠫࠬ⸂"),l11ll1_l1_ (u"ࠬ࠭⸃"),search)# 189
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⸄"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⸅"),l11ll1_l1_ (u"ࠨࠩ⸆"),157)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸇"),l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ⸈")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อ࠭⸉")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠬ࠭⸊"),149,l11ll1_l1_ (u"࠭ࠧ⸋"),l11ll1_l1_ (u"ࠧࠨ⸌"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸍"),l11ll1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ⸎")+l1ll11l1lll_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨ⸏")+l1lll1l11ll_l1_,l11ll1_l1_ (u"ࠫࠬ⸐"),409,l11ll1_l1_ (u"ࠬ࠭⸑"),l11ll1_l1_ (u"࠭ࠧ⸒"),l1111ll_l1_)
	return
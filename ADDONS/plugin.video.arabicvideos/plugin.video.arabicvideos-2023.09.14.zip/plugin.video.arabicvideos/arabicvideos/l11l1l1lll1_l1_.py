# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ桬")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭桭")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠨࠩ桮")
#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭桯"):l11ll1_l1_ (u"ࠪࠫ桰")}
l1ll1ll11llll_l1_ = 0
def MAIN(mode,url,text,type,l1l1111_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1ll11ll1l_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11111_l1_(url,l1l1111_l1_,text)
	elif mode==145: results = l1ll1llll1lll_l1_(url,l1l1111_l1_)
	elif mode==147: results = l1ll1lll111ll_l1_()
	elif mode==148: results = l1ll1lll11l1l_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桱"),l111l1_l1_+l11ll1_l1_ (u"่ࠬวว็ฬࠫ桲"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎࡄ࡮࠺ࡍࡳ࠹ࡈࡋ࠼࡟ࡴࡕࡣࡈ࠳ࡖ࡛࠳࠷ࡈ࠵ࡅࡳࡶࡏࡹ࡛ࡃ࠷ࡹࡘࡇࠧ桳"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ桴"),l111l1_l1_+l11ll1_l1_ (u"ࠨึัูࠬ桵"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࡖࡆࡒࡴ࡬ࡦࡪࡥ࡬ࡥࡱ࠭桶"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ桷"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎โฺࠩ桸"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡖࡅࡴ࠹࠾ࡧࡇࡏࡵࡴ࠽ࡧࡨࡨࡸࡘࡗࡵ࠶࡛ࡴࡷࡩࡺࠫ桹"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桺"),l111l1_l1_+l11ll1_l1_ (u"ࠧฮีสฬࠬ桻"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡃࡘ࡭࡫ࡓࡰࡥ࡬ࡥࡱࡉࡔࡗࠩ桼"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ桽"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้฿วษࠩ桾"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ桿"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ梀"),l111l1_l1_+l11ll1_l1_ (u"࠭วโๆส้ࠬ梁"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡳࡵࡱࡵࡩ࡫ࡸ࡯࡯ࡶࠪ梂"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ梃"),l111l1_l1_+l11ll1_l1_ (u"่ࠩาฯอัศฬࠪ梄"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ梅"),144)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ梆"),l111l1_l1_+l11ll1_l1_ (u"่ࠬี๋ำฬࠫ梇"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ梈"),144,l11ll1_l1_ (u"ࠧࠨ梉"),l11ll1_l1_ (u"ࠨࠩ梊"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭梋"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梌"),l111l1_l1_+l11ll1_l1_ (u"ࠫฯ฻แฮࠩ梍"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ梎"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭梏"),l111l1_l1_+l11ll1_l1_ (u"ࠧาศํื๏ฯࠧ梐"),l11l1l_l1_+l11ll1_l1_ (u"ࠨࠩ梑"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梒"),l111l1_l1_+l11ll1_l1_ (u"ࠪีฬฬฬࠨ梓"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࡄࡨࡰ࠾ࠩ梔"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ梕"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭梖"),l11ll1_l1_ (u"ࠧࠨ梗"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ梘"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ梙"),l11ll1_l1_ (u"ࠪࠫ梚"),149,l11ll1_l1_ (u"ࠫࠬ梛"),l11ll1_l1_ (u"ࠬ࠭梜"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ條"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ梞"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ梟"),l11l1l_l1_+l11ll1_l1_ (u"ࠩࠪ梠"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梡"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ัศศฯอࠬ梢"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭梣"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭梤"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆอูๆำࠧ梥"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ梦"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梧"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้่ี๋ำฬࠫ梨"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ梩"),144,l11ll1_l1_ (u"ࠬ࠭梪"),l11ll1_l1_ (u"࠭ࠧ梫"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ梬"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ梭"),l111l1_l1_+l11ll1_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ梮"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ梯"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ械"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ梱"),l11ll1_l1_ (u"࠭ࠧ梲"),290)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ梳"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ梴"),l11ll1_l1_ (u"ࠩࠪ梵"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梶"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ梷"),l11ll1_l1_ (u"ࠬ࠭梸"),147)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭梹"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ梺"),l11ll1_l1_ (u"ࠨࠩ梻"),148)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梼"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭梽"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ梾"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ梿"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ检"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ棁"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ棂"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ棃"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ棄"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ棅"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ棆"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ棇"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ棈"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ棉"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ棊"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ棋"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ棌"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ棍"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棎"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ棏"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ棐"),144)
	return
def l1ll1ll11ll1l_l1_(url,name,l111_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棑"),l111l1_l1_+l11ll1_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ棒")+name,url,144,l111_l1_)
	return
def l1ll1lll111ll_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ棓"))
	return
def l1ll1lll11l1l_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ棔"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ棕"),l11ll1_l1_ (u"ࠧࠨ棖"),l11ll1_l1_ (u"ࠨࠩ棗"),url)
	#url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ棘")
	#items = re.findall(l11ll1_l1_ (u"ࠪࡺࡂ࠮࠮ࠫࡁࠬࠨࠬ棙"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ棚")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ棛"))
	#return
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ棜")
	url = url.split(l11ll1_l1_ (u"ࠧࠧࠩ棝"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1ll1ll1ll_l1_(cc,url,index):
	level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = index.split(l11ll1_l1_ (u"ࠨ࠼࠽ࠫ棞"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ棟"),l11ll1_l1_ (u"ࠪࠫ棠"),index,l11ll1_l1_ (u"ࠫࡋࡏࡒࡔࡖࠪ棡")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ棢")+url)
	l1ll1ll11l1l1_l1_,l1ll1ll11ll11_l1_ = [],[]
	# l1l1111llll_l1_ l11l111ll11l_l1_    should be the first item in the l1ll1ll11l1l1_l1_ list
	if l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ棣") in url: l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠࠦ棤"))
	# l1l1111llll_l1_ search l1ll1lllll1l1_l1_      should be the first item in the l1ll1ll11l1l1_l1_ list
	if l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ棥") in url: l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣࠢ棦"))
	# main l1l1111_l1_
	if level==l11ll1_l1_ (u"ࠪ࠵ࠬ棧"): l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ棨"))
	# search results
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ棩"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣࠢ棪"))
	# l1ll1lll11lll_l1_ l1ll1lll111l1_l1_ & main l1l1111_l1_ l1ll1lll111l1_l1_ l1ll1lllll1l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬࡣࠢ棫"))
	# l1ll1ll1lll11_l1_ menu
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࡡ࠳࡞࡝ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ棬"))
	l1ll1lll1l11l_l1_,dd,l1ll1ll111l11_l1_ = l1ll1ll11l111_l1_(cc,l11ll1_l1_ (u"ࠩࠪ棭"),l1ll1ll11l1l1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ森"),str(dd))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ棯"),l11ll1_l1_ (u"ࠬ࠭棰"),l11ll1_l1_ (u"࠭ࠧ棱"),str(len(dd)))
	if level==l11ll1_l1_ (u"ࠧ࠲ࠩ棲") and l1ll1lll1l11l_l1_:
		if len(dd)>1 and l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ棳") not in url:
			for zz in range(len(dd)):
				l1ll1ll1l1l11_l1_ = str(zz)
				l1ll1ll11l1l1_l1_ = []
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠࠨ棴")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ棵"))
				# l1ll1lll11lll_l1_ l1ll1lll111l1_l1_
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ棶")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ棷"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ棸")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠢ࡞ࠤ棹"))
				succeeded,item,l111l1ll_l1_ = l1ll1ll11l111_l1_(dd,l11ll1_l1_ (u"ࠨࠩ棺"),l1ll1ll11l1l1_l1_)
				if succeeded: l1ll1ll11ll11_l1_.append([item,url,l11ll1_l1_ (u"ࠩ࠵࠾࠿࠭棻")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ棼")])
				#l1l1l1ll1l1l_l1_ = l1ll1llll11l1_l1_(item,url,l11ll1_l1_ (u"ࠫ࠷ࡀ࠺ࠨ棽")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ棾"))
				#if l1l1l1ll1l1l_l1_: l1ll11l1ll_l1_ += 1
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token = l1ll1lllll1ll_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棿"),l111l1_l1_+title,l1lllll_l1_,144,l11ll1_l1_ (u"ࠧࠨ椀"),l11ll1_l1_ (u"ࠨ࠴࠽࠾ࠬ椁")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ椂"))
				#l1ll11l1ll_l1_ += 1
			# main l1l1111_l1_ l1ll1lll111l1_l1_ l1ll1lllll1l1_l1_
			l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ椃"))
			succeeded,item,l111l1ll_l1_ = l1ll1ll11l111_l1_(cc,l11ll1_l1_ (u"ࠫࠬ椄"),l1ll1ll11l1l1_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭椅"),str(cc))
			if succeeded and l1ll1ll11ll11_l1_ and l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ椆") in list(item.keys()):
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ椇")
				l1ll1ll11ll11_l1_.append([item,l1lllll_l1_,l11ll1_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ椈")])
	return dd,l1ll1lll1l11l_l1_,l1ll1ll11ll11_l1_,l1ll1ll111l11_l1_
def l1ll1ll111l1l_l1_(cc,dd,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ椉"),l11ll1_l1_ (u"ࠪࠫ椊"),index,l11ll1_l1_ (u"ࠫࡘࡋࡃࡐࡐࡇࠫ椋")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ椌")+url)
	level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = index.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ植"))
	l1ll1ll11l1l1_l1_,l1ll1ll1lll1l_l1_ = [],[]
	# search results
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ椎"))
	# main l1l1111_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ椏")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ椐"))
	# l11ll111l11l_l1_ l1ll1lll111l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ椑"))
	# l1l1111llll_l1_ search & l11l111ll11l_l1_ & l1ll1lllll1l1_l1_
	if l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ椒") in url: l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ椓"))
	elif l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ椔") in url: l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ椕"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ椖")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ椗"))
	# l11ll111l11l_l1_ l11ll11lll_l1_ & l1ll1lll111l1_l1_ filters
	if l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ椘") in url or (l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ椙") in url and l11ll1_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ椚") not in url):
		l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ椛")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ検"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ椝")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ椞"))
	# l1ll1lll11lll_l1_ search
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡࠢ椟")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ椠"))
	# main l1l1111_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ椡")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ椢"))
	# l1l1111llll_l1_ l11l111ll11l_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞ࠦ椣")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠣ࡟ࠥ椤"))
	l1ll1lll11ll1_l1_,ee,l1ll1ll1ll11l_l1_ = l1ll1ll11l111_l1_(dd,l11ll1_l1_ (u"ࠩࠪ椥"),l1ll1ll11l1l1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ椦"),str(ee))
	#DIALOG_OK()
	if level==l11ll1_l1_ (u"ࠫ࠷࠭椧") and l1ll1lll11ll1_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll1ll11l1l1_l1_ = []
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ椨")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ椩"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ椪")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ椫"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ椬")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ椭"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ椮")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ椯"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ椰")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ椱"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ椲")+index2+l11ll1_l1_ (u"ࠤࡠࠦ椳"))
				succeeded,item,l111l1ll_l1_ = l1ll1ll11l111_l1_(ee,l11ll1_l1_ (u"ࠪࠫ椴"),l1ll1ll11l1l1_l1_)
				if succeeded: l1ll1ll1lll1l_l1_.append([item,url,l11ll1_l1_ (u"ࠫ࠸ࡀ࠺ࠨ椵")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ椶")+index2+l11ll1_l1_ (u"࠭࠺࠻࠲ࠪ椷")])
				#l1l1l1ll1l1l_l1_ = l1ll1llll11l1_l1_(item,url,l11ll1_l1_ (u"ࠧ࠴࠼࠽ࠫ椸")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ椹")+index2+l11ll1_l1_ (u"ࠩ࠽࠾࠵࠭椺"))
				#if l1l1l1ll1l1l_l1_: l1l1l11l1l_l1_ += 1
				#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ椻"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ椼")+str(item))
				#l1l1l11l1l_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token = l1ll1lllll1ll_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椽"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,l11ll1_l1_ (u"࠭࠳࠻࠼ࠪ椾")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ椿")+index2+l11ll1_l1_ (u"ࠨ࠼࠽࠴ࠬ楀"))
			# search l1ll1lllll1l1_l1_
			l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ楁"))
			# search l1ll1lllll1l1_l1_
			l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡ࠱࡞ࠤ楂"))
			succeeded,item,l111l1ll_l1_ = l1ll1ll11l111_l1_(dd,l11ll1_l1_ (u"ࠫࠬ楃"),l1ll1ll11l1l1_l1_)
			if succeeded and l1ll1ll1lll1l_l1_ and l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ楄") in list(item.keys()):
				l1ll1ll1lll1l_l1_.append([item,url,l11ll1_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ楅")])
			#l1l1l1ll1l1l_l1_ = l1ll1llll11l1_l1_(item,url,l11ll1_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ楆"))
			#if l1l1l1ll1l1l_l1_: l1l1l11l1l_l1_ += 1
			#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ楇"),str(item))
			#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ楈"),l1lllll_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ楉")+token)
	return ee,l1ll1lll11ll1_l1_,l1ll1ll1lll1l_l1_,l1ll1ll1ll11l_l1_
def l1ll1ll11lll1_l1_(cc,ee,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ楊"),l11ll1_l1_ (u"ࠬ࠭楋"),index,l11ll1_l1_ (u"࠭ࡔࡉࡋࡕࡈࠬ楌")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ楍")+url)
	level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = index.split(l11ll1_l1_ (u"ࠨ࠼࠽ࠫ楎"))
	l1ll1ll11l1l1_l1_,l1ll1ll1l111l_l1_ = [],[]
	# search results
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ楏")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ楐"))
	# l1l1111llll_l1_ l11l111ll11l_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ楑")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ楒"))
	# l1ll1llll111l_l1_ menu l1ll1lll111l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ楓")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ楔"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ楕")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ楖"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ楗")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ楘"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ楙")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ楚"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ楛")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ楜"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ楝")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ楞"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ楟"))
	# l1ll1lll11lll_l1_ l1ll1llllll11_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ楠"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ楡"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ楢")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ楣"))
	# main l1l1111_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ楤")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ楥"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫ࠢ楦"))
	l1ll1lll1l1ll_l1_,ff,l1ll1lllll11l_l1_ = l1ll1ll11l111_l1_(ee,l11ll1_l1_ (u"ࠬ࠭楧"),l1ll1ll11l1l1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ楨"),str(ff))
	if level==l11ll1_l1_ (u"ࠧ࠴ࠩ楩") and l1ll1lll1l1ll_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1ll1lll1111l_l1_ = str(zz)
				#DIALOG_OK()
				l1ll1ll11l1l1_l1_ = []
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠧ楪")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ楫"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠢ楬")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ業"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠤ楮")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ楯"))
				l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠦ楰")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"ࠣ࡟ࠥ楱"))
				succeeded,item,l111l1ll_l1_ = l1ll1ll11l111_l1_(ff,l11ll1_l1_ (u"ࠩࠪ楲"),l1ll1ll11l1l1_l1_)
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token = l1ll1lllll1ll_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ楳"),l111l1_l1_+l1lllll_l1_,l1lllll_l1_,143,l1lll1_l1_)
				if succeeded: l1ll1ll1l111l_l1_.append([item,url,l11ll1_l1_ (u"ࠫ࠹ࡀ࠺ࠨ楴")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ極")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ楶")+l1ll1lll1111l_l1_])
				#l1l1l1ll1l1l_l1_ = l1ll1llll11l1_l1_(item,url,l11ll1_l1_ (u"ࠧ࠵࠼࠽ࠫ楷")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ楸")+index2+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ楹")+l1ll1lll1111l_l1_)
				#if l1l1l1ll1l1l_l1_: l1l1l11ll1_l1_ += 1
	return ff,l1ll1lll1l1ll_l1_,l1ll1ll1l111l_l1_,l1ll1lllll11l_l1_
def l1ll1ll11l111_l1_(l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l1ll1ll1l11ll_l1_):
	cc,l11ll1l1111l_l1_ = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	dd,l11ll1l1111l_l1_ = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	ee,l11ll1l1111l_l1_ = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	ff,l11ll1l1111l_l1_ = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	item,render = l11ll11l1l1l_l1_,l11ll1l1111l_l1_
	count = len(l1ll1ll1l11ll_l1_)
	for l11ll1111l_l1_ in range(count):
		try:
			out = eval(l1ll1ll1l11ll_l1_[l11ll1111l_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠪࠫ楺")
			return True,out,l11ll1111l_l1_+1
		except: pass
	return False,l11ll1_l1_ (u"ࠫࠬ楻"),0
def l11111_l1_(url,index=l11ll1_l1_ (u"ࠬ࠭楼"),data=l11ll1_l1_ (u"࠭ࠧ楽")):
	l1ll1ll11ll11_l1_,l1ll1ll1lll1l_l1_,l1ll1ll1l111l_l1_ = [],[],[]
	if l11ll1_l1_ (u"ࠧ࠻࠼ࠪ楾") not in index: index = l11ll1_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ楿")
	level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = index.split(l11ll1_l1_ (u"ࠩ࠽࠾ࠬ榀"))
	if level==l11ll1_l1_ (u"ࠪ࠸ࠬ榁"): level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭概"),l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭榃"),l11ll1_l1_ (u"࠭ࠧ榄"),index,url)
	data = data.replace(l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ榅"),l11ll1_l1_ (u"ࠨࠩ榆"))
	html,cc,l11ll11l1_l1_ = l1ll1ll1llll1_l1_(url,data)
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡰࡴࠣࠫ࠴ࡻࡳࡦࡴ࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠥࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡵࡷ࡯ࡧࡵ࠾ࠥࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠩࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࠫࡰࡹࡱࡩࡷࡔࡁࡎࡇ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠷࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱࠬ࠲࠶࠷࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠧࠨࠢ榇")
	index = level+l11ll1_l1_ (u"ࠪ࠾࠿࠭榈")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ榉")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ榊")+l1ll1lll1111l_l1_
	if level in [l11ll1_l1_ (u"࠭࠱ࠨ榋"),l11ll1_l1_ (u"ࠧ࠳ࠩ榌"),l11ll1_l1_ (u"ࠨ࠵ࠪ榍")]:
		dd,l1ll1lll1l11l_l1_,l1ll1ll11ll11_l1_,l1ll1ll111l11_l1_ = l1ll1ll1ll1ll_l1_(cc,url,index)
		if not l1ll1lll1l11l_l1_: return
		l1ll11l1ll_l1_ = len(l1ll1ll11ll11_l1_)
		if l1ll11l1ll_l1_<2:
			if level==l11ll1_l1_ (u"ࠩ࠴ࠫ榎"): level = l11ll1_l1_ (u"ࠪ࠶ࠬ榏")
			l1ll1ll11ll11_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ榐"),l11ll1_l1_ (u"ࠬ࠭榑"),index,l11ll1_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠱࡝ࡰࠪ榒")+l11ll1_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ榓")+str(l1ll1ll111l11_l1_)+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ榔")+l11ll1_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ榕")+str(len(dd))+l11ll1_l1_ (u"ࠪࡠࡳ࠭榖")+l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ榗")+str(l1ll11l1ll_l1_)+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ榘")+url)
	index = level+l11ll1_l1_ (u"࠭࠺࠻ࠩ榙")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ榚")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ榛")+l1ll1lll1111l_l1_
	if level in [l11ll1_l1_ (u"ࠩ࠵ࠫ榜"),l11ll1_l1_ (u"ࠪ࠷ࠬ榝")]:
		ee,l1ll1lll11ll1_l1_,l1ll1ll1lll1l_l1_,l1ll1ll1ll11l_l1_ = l1ll1ll111l1l_l1_(cc,dd,url,index)
		if not l1ll1lll11ll1_l1_: return
		l1l1l11l1l_l1_ = len(l1ll1ll1lll1l_l1_)
		if l1l1l11l1l_l1_<2:
			if level==l11ll1_l1_ (u"ࠫ࠷࠭榞"): level = l11ll1_l1_ (u"ࠬ࠹ࠧ榟")
			l1ll1ll1lll1l_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ榠"),l11ll1_l1_ (u"ࠧࠨ榡"),index,l11ll1_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠴࡟ࡲࠬ榢")+l11ll1_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭榣")+str(l1ll1ll1ll11l_l1_)+l11ll1_l1_ (u"ࠪࡠࡳ࠭榤")+l11ll1_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭榥")+str(len(ee))+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ榦")+l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ榧")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ榨")+url)
	index = level+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ榩")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ榪")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭榫")+l1ll1lll1111l_l1_
	if level in [l11ll1_l1_ (u"ࠫ࠸࠭榬")]:
		ff,l1ll1lll1l1ll_l1_,l1ll1ll1l111l_l1_,l1ll1lllll11l_l1_ = l1ll1ll11lll1_l1_(cc,ee,url,index)
		if not l1ll1lll1l1ll_l1_: return
		l1l1l11ll1_l1_ = len(l1ll1ll1l111l_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭榭"),l11ll1_l1_ (u"࠭ࠧ榮"),index,l11ll1_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠴࡞ࡱࠫ榯")+l11ll1_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ榰")+str(l1ll1lllll11l_l1_)+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ榱")+l11ll1_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ榲")+str(len(ff))+l11ll1_l1_ (u"ࠫࡡࡴࠧ榳")+l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭榴")+str(l1l1l11ll1_l1_)+l11ll1_l1_ (u"࠭࡜࡯ࠩ榵")+url)
	for item,url,index in l1ll1ll11ll11_l1_+l1ll1ll1lll1l_l1_+l1ll1ll1l111l_l1_:
		l1l1l1ll1l1l_l1_ = l1ll1llll11l1_l1_(item,url,index)
	return
def l1ll1llll11l1_l1_(item,url=l11ll1_l1_ (u"ࠧࠨ榶"),index=l11ll1_l1_ (u"ࠨࠩ榷")):
	if l11ll1_l1_ (u"ࠩ࠽࠾ࠬ榸") in index: level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = index.split(l11ll1_l1_ (u"ࠪ࠾࠿࠭榹"))
	else: level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭榺"),l11ll1_l1_ (u"ࠬ࠶ࠧ榻"),l11ll1_l1_ (u"࠭࠰ࠨ榼"),l11ll1_l1_ (u"ࠧ࠱ࠩ榽")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,l1ll1llll1l1l_l1_ = l1ll1lllll1ll_l1_(item)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ榾"),url)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ榿"),l1lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ槀"),l1lllll_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ槁")+title)
	# needed for l1ll1lll11lll_l1_ l1ll1llllll11_l1_ next l1l1111_l1_
	# and needed for l1ll1lll11lll_l1_ l1ll1llllll11_l1_ sub-menu
	#if (l11ll1_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭槂") in l1lllll_l1_ or l11ll1_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ槃") in l1lllll_l1_) and (l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ槄") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ槅") in l1lllll_l1_): l1lllll_l1_ = url
	l1ll1lll1111_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ槆") in l1lllll_l1_ or l11ll1_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭槇") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ槈") in l1lllll_l1_
	l1ll1ll1lll1_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ槉") in l1lllll_l1_ or l11ll1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ槊") in l1lllll_l1_
	if l1ll1lll1111_l1_ or l1ll1ll1lll1_l1_: l1lllll_l1_ = url
	l1ll1lll1111_l1_ = l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ構") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ槌") not in l1lllll_l1_
	l1ll1ll1lll1_l1_ = l11ll1_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ槍") not in l1lllll_l1_  and l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭槎") not in l1lllll_l1_
	if index[0:5]==l11ll1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ槏") and l1ll1lll1111_l1_ and l1ll1ll1lll1_l1_: l1lllll_l1_ = url
	if l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ槐") in url or l11ll1_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ槑") in l1lllll_l1_:
		level,l1ll1ll1l1l11_l1_,index2,l1ll1lll1111l_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ槒"),l11ll1_l1_ (u"ࠨ࠲ࠪ槓"),l11ll1_l1_ (u"ࠩ࠳ࠫ槔"),l11ll1_l1_ (u"ࠪ࠴ࠬ槕")
		index = l11ll1_l1_ (u"ࠫࠬ槖")
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠬ࠭槗")
	if l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ様") in l1lllll_l1_ or l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭槙") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭槚") in url:
		data = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ槛"))
		if data.count(l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ槜"))==4:
			l1ll1lll1l1l1_l1_,key,l1ll1lll11l11_l1_,l1ll1ll1l1ll1_l1_,token = data.split(l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ槝"))
			l11ll11l1_l1_ = l1ll1lll1l1l1_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ槞")+key+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ槟")+l1ll1lll11l11_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ槠")+l1ll1ll1l1ll1_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ槡")+l1ll1llll1l1l_l1_
			if l11ll1_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ槢") in url and not l1lllll_l1_: l1lllll_l1_ = url
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ槣")+key
	if not title:
		global l1ll1ll11llll_l1_
		l1ll1ll11llll_l1_ += 1
		title = l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ槤")+str(l1ll1ll11llll_l1_)
		index = l11ll1_l1_ (u"ࠬ࠹ࠧ槥")+l11ll1_l1_ (u"࠭࠺࠻ࠩ槦")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ槧")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ槨")+l1ll1lll1111l_l1_
	#if l11ll1_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ槩") in url: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ槪"),l11ll1_l1_ (u"ࠫࠬ槫"),title,index+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ槬")+l1lllll_l1_)
	#if not l1lllll_l1_: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ槭"),l11ll1_l1_ (u"ࠧࠨ槮"),str(succeeded),title+l11ll1_l1_ (u"ࠨࠢ࠽࠾࠿ࠦࠧ槯")+l1lllll_l1_)
	#if l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ槰") in url and index==l11ll1_l1_ (u"ࠪ࠴ࠬ槱"):
	#	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ槲"),l111l1_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ槳") in str(item): return False			# l1ll1llll1111_l1_ not items
	elif l11ll1_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭槴") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ槵") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ槶") in list(item.keys()) or l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ槷") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11ll1_l1_ (u"ࠪ࠾࠿࠭槸")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ槹")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ槺")+l1ll1lll1111l_l1_
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭槻"),l111l1_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠣࠫ槼")+l11ll1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ槽"),l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ槾") in l1lllll_l1_:
		title = l11ll1_l1_ (u"ࠪ࠾࠿ࠦࠧ槿")+title
		index = l11ll1_l1_ (u"ࠫ࠸࠭樀")+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ樁")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"࠭࠺࠻ࠩ樂")+index2+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ樃")+l1ll1lll1111l_l1_
		url = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ樄"),l11ll1_l1_ (u"ࠩࠪ樅"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樆"),l111l1_l1_+title,url,145,l11ll1_l1_ (u"ࠫࠬ樇"),index,l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ樈"))
	elif l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ樉") in url and not l1lllll_l1_:
		index = l11ll1_l1_ (u"ࠧ࠴ࠩ樊")+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ樋")+l1ll1ll1l1l11_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ樌")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭樍")+l1ll1lll1111l_l1_
		title = l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ樎")+title
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樏"),l111l1_l1_+title,url,144,l1lll1_l1_,index,l11ll11l1_l1_)
	#elif l11ll1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ樐") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ樑") in l1lllll_l1_ and url==l11l1l_l1_:
		title = l11ll1_l1_ (u"ࠨ࠼࠽ࠤࠬ樒")+title
		index = l11ll1_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭樓")
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樔"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ樕") in str(item):
		title = l11ll1_l1_ (u"ࠬࡀ࠺ࠡࠩ樖")+title
		index = l11ll1_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ樗")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ樘"),l111l1_l1_+title,url,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ標") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ樚"),l111l1_l1_+title,l11ll1_l1_ (u"ࠪࠫ樛"),9999)
	#elif l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ樜") in l1lllll_l1_ and l11ll1_l1_ (u"ࠬࡨࡰ࠾ࠩ樝") not in l1lllll_l1_:
	#	title = l11ll1_l1_ (u"࠭࠺࠻ࠢࠪ樞")+title
	#	index = l11ll1_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ樟")
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樠"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l111lll1ll1_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ模"),l111l1_l1_+l111lll1ll1_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ樢") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ樣"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡒࡉࡔࡖࠪ樤")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ樥")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	#elif l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭樦") in l1lllll_l1_ and l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ樧") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠩࡷࡁ࠵࠭樨") not in l1lllll_l1_:
	#	l1ll1lll11111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ権"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭横")+l1ll1lll11111_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樫"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡌࡊࡕࡗࠫ樬")+count+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ樭")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ樮") in l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ樯"),1)[0]
		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ樰"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ樱") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ樲") in l1lllll_l1_ and count:
			l1ll1lll11111_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭樳"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ樴")+l1ll1lll11111_l1_
			index = l11ll1_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ樵")
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ樶"),l111l1_l1_+l11ll1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ樷")+count+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ樸")+title,l1lllll_l1_,144,l1lll1_l1_,index)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ樹"),1)[0]
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ樺"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ樻") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡦ࠳ࠬ樼") in l1lllll_l1_ or (l11ll1_l1_ (u"ࠩ࠲ࡄࠬ樽") in l1lllll_l1_ and l1lllll_l1_.count(l11ll1_l1_ (u"ࠪ࠳ࠬ樾"))==3):
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ樿"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡉࡈࡏࡎࠪ橀")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ橁")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ橂") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ橃"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡘࡗࡊࡘࠧ橄")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ橅")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	else:
		if not l1lllll_l1_: l1lllll_l1_ = url
		title = l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ橆")+title
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ橇"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	return True
def l1ll1lllll1ll_l1_(item):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token = False,l11ll1_l1_ (u"࠭ࠧ橈"),l11ll1_l1_ (u"ࠧࠨ橉"),l11ll1_l1_ (u"ࠨࠩ橊"),l11ll1_l1_ (u"ࠩࠪ橋"),l11ll1_l1_ (u"ࠪࠫ橌"),l11ll1_l1_ (u"ࠫࠬ橍"),l11ll1_l1_ (u"ࠬ࠭橎"),l11ll1_l1_ (u"࠭ࠧ橏")
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ橐"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token
	for l1ll1lll1lll1_l1_ in list(item.keys()):
		render = item[l1ll1lll1lll1_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11ll1_l1_ (u"ࠨࠩ橑"),str(render))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ橒"),str(render))
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ橓"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ橔"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡰ࡮ࡴࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ橕"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ橖"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ橗"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ橘"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ橙"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ橚"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ橛"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ橜"))
	# required for l11ll111l11l_l1_ l1ll1ll1ll1l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ橝"))
	# l1ll1lll11lll_l1_ l1ll1lll111l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ橞"))
	succeeded,title,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ機"),l11ll1_l1_ (u"ࠩࠪ橠"),l11ll1_l1_ (u"ࠪࠫ橡"),str(l111l1ll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ橢"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ橣")+str(title))
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ橤"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ橥"))
	# l1ll1lllll1l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ橦"))
	# header feed
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ橧"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ橨"))
	# required for l11ll111l11l_l1_ l1ll1ll1l11l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ橩"))
	# l1ll1lll11lll_l1_ l1ll1lll111l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ橪"))
	succeeded,l1lllll_l1_,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ橫"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ橬"))
	# l1ll1lll11lll_l1_ l1ll1lll111l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ橭"))
	succeeded,l1lll1_l1_,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ橮"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ橯")+l1lll1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ橰"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ橱"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ橲"))
	succeeded,count,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ橳"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ橴"))
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ橵"))
	# l1ll1lll1ll1l_l1_ l1ll1lll11lll_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࡖࡼࡴࡪ࠭࡝ࠣ橶"))
	# l1ll1lll1ll1l_l1_ l1ll1lll11lll_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡺࡹ࡭ࡧࠪࡡࠧ橷"))
	succeeded,l1l11lll1_l1_,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	#l1ll1ll11l1l1_l1_ = []
	# l1ll1lllll1l1_l1_
	#l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡰ࡮ࡩ࡫ࡕࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ橸"))
	# l1l1111llll_l1_ l11l111ll11l_l1_
	#l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡶࡵࡥࡨࡱࡩ࡯ࡩࡓࡥࡷࡧ࡭ࡴࠩࡠࠦ橹"))
	#succeeded,l1ll1ll1l1111_l1_,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	l1ll1ll11l1l1_l1_ = []
	# l1l1111llll_l1_ l11l111ll11l_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ橺"))
	# l1ll1lllll1l1_l1_
	l1ll1ll11l1l1_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ橻"))
	succeeded,token,l111l1ll_l1_ = l1ll1ll11l111_l1_(item,render,l1ll1ll11l1l1_l1_)
	if l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ橼") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll1ll1_l1_ = l11ll1_l1_ (u"ࠪࠫ橽"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ橾")
	if l11ll1_l1_ (u"๋ࠬศศึิࠫ橿") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ檀"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ檁")
	if l11ll1_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ檂") in list(render.keys()):
		l1ll1llll11ll_l1_ = str(render[l11ll1_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ檃")])
		if l11ll1_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ檄") in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠫࠩࡀࠠࠡࠩ檅")
		if l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ檆") in l1ll1llll11ll_l1_: l111lll1ll1_l1_ = l11ll1_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ檇")
		if l11ll1_l1_ (u"ࠧࡃࡷࡼࠫ檈") in l1ll1llll11ll_l1_ or l11ll1_l1_ (u"ࠨࡔࡨࡲࡹ࠭檉") in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ檊")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡸ๊ࠫฮวีำࠪ檋")) in l1ll1llll11ll_l1_: l111lll1ll1_l1_ = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ檌")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡺ࠭ิาษฤࠫ檍")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ檎")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡵࠨษึฮหาวาࠩ檏")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ檐")
		if l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ檑")) in l1ll1llll11ll_l1_: l1ll1ll1lllll_l1_ = l11ll1_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ檒")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ檓") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠬࡅࠧ檔"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ檕") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ檖")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll1lllll_l1_: title = l1ll1ll1lllll_l1_+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠨ࠮ࠪ檗"),l11ll1_l1_ (u"ࠩࠪ檘"))
	count = count.replace(l11ll1_l1_ (u"ࠪ࠰ࠬ檙"),l11ll1_l1_ (u"ࠫࠬ檚"))
	count = re.findall(l11ll1_l1_ (u"ࠬࡢࡤࠬࠩ檛"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"࠭ࠧ檜")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll1ll1_l1_,l1ll1ll1lllll_l1_,token
def l1ll1ll1llll1_l1_(url,data=l11ll1_l1_ (u"ࠧࠨ檝"),request=l11ll1_l1_ (u"ࠨࠩ檞")):
	if request==l11ll1_l1_ (u"ࠩࠪ檟"): request = l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ檠")
	#if l11ll1_l1_ (u"ࠫࡤࡥࠧ檡") in l1ll1lll1l111_l1_: l1ll1lll1l111_l1_ = l11ll1_l1_ (u"ࠬ࠭檢")
	#if l11ll1_l1_ (u"࠭ࡳࡴ࠿ࠪ檣") in url: url = url.split(l11ll1_l1_ (u"ࠧࡴࡵࡀࠫ檤"))[0]
	l111llll11_l1_ = l11llllll_l1_()
	#l111llll11_l1_ = l11ll1_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠰࠺࠰࠳࠲࠵࠴࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠡࡇࡧ࡫࠴࠷࠰࠺࠰࠳࠲࠶࠻࠱࠹࠰࠺࠴ࠬ檥")
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭檦"):l111llll11_l1_,l11ll1_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ檧"):l11ll1_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ檨")}
	#l1l1ll11l_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ檩"))
	if data.count(l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ檪"))==4: l1ll1lll1l1l1_l1_,key,l1ll1lll11l11_l1_,l1ll1ll1l1ll1_l1_,token = data.split(l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ檫"))
	else: l1ll1lll1l1l1_l1_,key,l1ll1lll11l11_l1_,l1ll1ll1l1ll1_l1_,token = l11ll1_l1_ (u"ࠨࠩ檬"),l11ll1_l1_ (u"ࠩࠪ檭"),l11ll1_l1_ (u"ࠪࠫ檮"),l11ll1_l1_ (u"ࠫࠬ檯"),l11ll1_l1_ (u"ࠬ࠭檰")
	l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ檱"):{l11ll1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ檲"):{l11ll1_l1_ (u"ࠣࡪ࡯ࠦ檳"):l11ll1_l1_ (u"ࠤࡤࡶࠧ檴"),l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ檵"):l11ll1_l1_ (u"ࠦ࡜ࡋࡂࠣ檶"),l11ll1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ檷"):l1ll1lll11l11_l1_}}}
	if url==l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ檸") or l11ll1_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ檹") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ檺")+l11ll1_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ檻")+key
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ檼")] = l1ll1lll1l1l1_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ檽"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ檾"))
	elif l11ll1_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ檿") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ櫀")+key
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭櫁"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ櫂"))
	elif l11ll1_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ櫃") in url and l1ll1lll1l1l1_l1_:
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ櫄")] = token
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭櫅")][l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭櫆")][l11ll1_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ櫇")] = l1ll1lll1l1l1_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭櫈"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ櫉"))
	elif l11ll1_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ櫊") in url and l1ll1ll1l1ll1_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ櫋"):l11ll1_l1_ (u"ࠬ࠷ࠧ櫌"),l11ll1_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ櫍"):l1ll1lll11l11_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ櫎"):l11ll1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ櫏")+l1ll1ll1l1ll1_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭櫐"),url,l11ll1_l1_ (u"ࠪࠫ櫑"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠫࠬ櫒"),l11ll1_l1_ (u"ࠬ࠭櫓"),l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ櫔"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ櫕"),url,l11ll1_l1_ (u"ࠨࠩ櫖"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ櫗"),l11ll1_l1_ (u"ࠪࠫ櫘"),l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ櫙"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ櫚"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ櫛"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll11l11_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ櫜"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll1l1l1_l1_ = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ櫝"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭櫞"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠥ࠾ࢀࠨࡴࡰ࡭ࡨࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ櫟"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ櫠"),l11ll1_l1_ (u"ࠬ࠭櫡"),l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ櫢"),str(len(tmp)))
	#if tmp: l1ll1lllll1l1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ櫣") in list(cookies.keys()): l1ll1ll1l1ll1_l1_ = cookies[l11ll1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭櫤")]
	l11ll11ll_l1_ = l1ll1lll1l1l1_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭櫥")+key+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ櫦")+l1ll1lll11l11_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ櫧")+l1ll1ll1l1ll1_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ櫨")+token
	if request==l11ll1_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭櫩") and l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ櫪") in html:
		l111lll111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ櫫"),html,re.DOTALL)
		if not l111lll111_l1_: l111lll111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ櫬"),html,re.DOTALL)
		l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ櫭"),l111lll111_l1_[0])
	elif request==l11ll1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ櫮") and l11ll1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ櫯") in html:
		l111lll111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ櫰"),html,re.DOTALL)
		l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ櫱"),l111lll111_l1_[0])
	elif l11ll1_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ櫲") not in html: l1ll1ll11l1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭櫳"),html)
	else: l1ll1ll11l1ll_l1_ = l11ll1_l1_ (u"ࠪࠫ櫴")
	if 0:
		cc = str(l1ll1ll11l1ll_l1_)
		if kodi_version>18.99: cc = cc.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ櫵"))
		open(l11ll1_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ櫶"),l11ll1_l1_ (u"࠭ࡷࡣࠩ櫷")).write(cc)
		#open(l11ll1_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ櫸"),l11ll1_l1_ (u"ࠨࡹࠪ櫹")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ櫺"),l11ll11ll_l1_)
	return html,l1ll1ll11l1ll_l1_,l11ll11ll_l1_
def l1ll1llll1lll_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ櫻"),l11ll1_l1_ (u"ࠫ࠰࠭櫼"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭櫽")+search
	l11111_l1_(l111lll_l1_,index)
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ櫾")+l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ櫿")+l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ欀")+l11ll1_l1_ (u"ࠩࡢࠫ欁")+search
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ欂"),l11ll1_l1_ (u"ࠫࠬ欃"),l11ll1_l1_ (u"ࠬ࠭欄"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ欅"),l11ll1_l1_ (u"ࠧࠨ欆"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ欇"),l11ll1_l1_ (u"ࠩ࠮ࠫ欈"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ欉")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ權") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ欋")
		elif l11ll1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ欌") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ欍")
		elif l11ll1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭欎") in options: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ欏")
		else: l1ll1ll1ll111_l1_ = l11ll1_l1_ (u"ࠪࠫ欐")
		l11l111_l1_ = l111lll_l1_+l1ll1ll1ll111_l1_
	else:
		l1ll1ll1l1lll_l1_,l1ll1ll111lll_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠫࠬ欑")
		l1ll1ll11l11l_l1_ = [l11ll1_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ欒"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ欓"),l11ll1_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ欔"),l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ欕"),l11ll1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭欖")]
		l1ll1lll1llll_l1_ = [l11ll1_l1_ (u"ࠪࠫ欗"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ欘"),l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ欙"),l11ll1_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ欚"),l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭欛")]
		l1ll1llll1l11_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ欜"),l1ll1ll11l11l_l1_)
		if l1ll1llll1l11_l1_ == -1: return
		l1ll1ll1l1l1l_l1_ = l1ll1lll1llll_l1_[l1ll1llll1l11_l1_]
		html,c,data = l1ll1ll1llll1_l1_(l111lll_l1_+l1ll1ll1l1l1l_l1_)
		if c:
			try:
				d = c[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ欝")][l11ll1_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭欞")][l11ll1_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭欟")][l11ll1_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ欠")][l11ll1_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ次")][l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ欢")][l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ欣")]
				for l1ll1ll111ll1_l1_ in range(len(d)):
					group = d[l1ll1ll111ll1_l1_][l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ欤")][l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ欥")]
					for l1ll1lllll111_l1_ in range(len(group)):
						render = group[l1ll1lllll111_l1_][l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ欦")]
						if l11ll1_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ欧") in list(render.keys()):
							l1lllll_l1_ = render[l11ll1_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ欨")][l11ll1_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ欩")][l11ll1_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭欪")][l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭欫")]
							l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ欬"),l11ll1_l1_ (u"ࠫࠫ࠭欭"))
							title = render[l11ll1_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭欮")]
							title = title.replace(l11ll1_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ欯"),l11ll1_l1_ (u"ࠧࠨ欰"))
							if l11ll1_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ欱") in title: continue
							if l11ll1_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ欲") in title:
								title = l11ll1_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ欳")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ欴") in title: continue
							title = title.replace(l11ll1_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ欵"),l11ll1_l1_ (u"࠭ࠧ欶"))
							if l11ll1_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ欷") in title: continue
							if l11ll1_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ欸") in title:
								title = l11ll1_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ欹")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ欺") in title: continue
							l1ll1ll1l1lll_l1_.append(escapeUNICODE(title))
							l1ll1ll111lll_l1_.append(l1lllll_l1_)
			except: pass
		if not l1lll1l1l_l1_: l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠫࠬ欻")
		else:
			l1ll1ll1l1lll_l1_ = [l11ll1_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ欼"),l1lll1l1l_l1_]+l1ll1ll1l1lll_l1_
			l1ll1ll111lll_l1_ = [l11ll1_l1_ (u"࠭ࠧ欽"),l1lllll11l_l1_]+l1ll1ll111lll_l1_
			l1ll1llll1ll1_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ款"),l1ll1ll1l1lll_l1_)
			if l1ll1llll1ll1_l1_ == -1: return
			l1ll1lll1ll11_l1_ = l1ll1ll111lll_l1_[l1ll1llll1ll1_l1_]
		if l1ll1lll1ll11_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1lll1ll11_l1_
		elif l1ll1ll1l1l1l_l1_: l11l111_l1_ = l111lll_l1_+l1ll1ll1l1l1l_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ欿")
	#DIALOG_OK()
	l11111_l1_(l11l111_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡩ࠴࠴ࡩࡧ࡯ࡥࡱ࠴ࡴࡷࠩᦨ")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠹࡮ࡥ࡭ࡣ࡯࠲ࡹࡼࠧᦩ")
#l11l1l_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰࠷࡬ࡪࡲࡡ࡭࠰ࡷࡺࠬᦪ")
script_name = l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧᦫ")
headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᦬") : l11ll1_l1_ (u"ࠧࠨ᦭") }
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡆࡑࡋࡥࠧ᦮")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1llll1ll_l1_()
	elif mode==95: results = l1llll1l_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᦯"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᦰ"),l11ll1_l1_ (u"ࠫࠬᦱ"),99,l11ll1_l1_ (u"ࠬ࠭ᦲ"),l11ll1_l1_ (u"࠭ࠧᦳ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᦴ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᦵ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᦶ"),l11ll1_l1_ (u"ࠪࠫᦷ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦸ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᦹ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬᦺ"),l11ll1_l1_ (u"ࠧࠨᦻ"),94)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᦼ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᦽ")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้ษอะอࠪᦾ"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱࡧࡴࡦࡵࡷࠫᦿ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᧀ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᧁ")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฦ฽้๏ࠠหไํ้ฬ๑ࠧᧂ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡫ࡰࡨࡧ࠭ᧃ"),91)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᧄ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᧅ")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊รไอิࠤฺ๊ว่ัฬࠫᧆ"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡼࡩࡦࡹࠪᧇ"),91)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᧈ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᧉ")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้ะฮสࠨ᧊"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡳ࡭ࡳ࠭᧋"),91)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᧌"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᧍")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ᧎"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡮ࡦࡹࡐࡳࡻ࡯ࡥࡴࠩ᧏"),91)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᧐"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᧑")+l111l1_l1_+l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨ᧒"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡲࡪࡽࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨ᧓"),91)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᧔"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᧕"),l11ll1_l1_ (u"࠭ࠧ᧖"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᧗"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᧘")+l111l1_l1_+l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆ่์็฿ࠧ᧙"),l11l1l_l1_,91)
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ᧚"),headers,l11ll1_l1_ (u"ࠫࠬ᧛"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ᧜"))
	#upper menu
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡢ࡫ࡱࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡴࡡࡷࠩ᧝"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᧞"),block,re.DOTALL)
	l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠫ᧟")]
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ᧠"))
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᧡"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᧢")+l111l1_l1_+title,l1lllll_l1_,91)
	return html
def ITEMS(url):
	if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࠪ᧣") in url:
		url,search = url.split(l11ll1_l1_ (u"࠭࠿ࡵ࠿ࠪ᧤"))
		headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᧥") : l11ll1_l1_ (u"ࠨࠩ᧦") , l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ᧧") : l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ᧨") }
		data = { l11ll1_l1_ (u"ࠫࡹ࠭᧩") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ᧪"),url,data,headers,l11ll1_l1_ (u"࠭ࠧ᧫"),l11ll1_l1_ (u"ࠧࠨ᧬"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭᧭"))
		html = response.content
	else:
		headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᧮") : l11ll1_l1_ (u"ࠪࠫ᧯") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ᧰"),headers,l11ll1_l1_ (u"ࠬ࠭᧱"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠳ࡰࡧࠫ᧲"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࡫ࡵ࡯ࡵࠤࠪ᧳"),html,re.DOTALL)
	if l1l1l11_l1_: block = l1l1l11_l1_[0]
	else: block = l11ll1_l1_ (u"ࠨࠩ᧴")
	items = re.findall(l11ll1_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡮ࡱࡹ࡭ࡪ࠳ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᧵"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠪห้ำไใหࠪ᧶") in title and l11ll1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ᧷") not in url and l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶ࠲ࠫ᧸") not in url:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡡ࠰࠮࠻ࡠ࠯ࠬ᧹"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭᧺")+l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧻"),l111l1_l1_+title,l1lllll_l1_,95,l1lll1_l1_)
					l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ᧼") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᧽"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᧾"),l111l1_l1_+title,l1lllll_l1_,91,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ᧿"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᨀ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠧศๆุๅาฯࠠࠨᨁ"),l11ll1_l1_ (u"ࠨࠩᨂ"))
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᨃ"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩᨄ")+title,l1lllll_l1_,91)
	return
def l1llll1l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬᨅ"),headers,l11ll1_l1_ (u"ࠬ࠭ᨆ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᨇ"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨈ"),html,re.DOTALL)
	l1lll1_l1_ = l1lll1_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧ࡫ࡰࡪࡵࡲࡨࡪࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᨉ"),html,re.DOTALL)
	if l1l1l11_l1_:
		name = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᨊ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫᨋ"))
			if l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᨌ") in name: name = name.split(l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᨍ"),1)[1]
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᨎ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᨏ"),l111l1_l1_+name+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᨐ")+title,l1lllll_l1_,92,l1lll1_l1_)
	else:
		tmp = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡳࡻ࡯ࡥࡵ࡫ࡷࡰࡪࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᨑ"),html,re.DOTALL)
		if tmp: l1lllll_l1_,title = tmp[0]
		else: l1lllll_l1_,title = url,name
		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᨒ"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll1ll1l1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬᨓ"),headers,l11ll1_l1_ (u"ࠬ࠭ᨔ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᨕ"))
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡵࡧࡻࡸ࠲ࡹࡨࡢࡦࡲࡻ࠿ࠦ࡮ࡰࡰࡨ࠿ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᨖ"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫᨗ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᨘ"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᨙ")
			l1llll_l1_.append(l1lllll_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡳࡧࡶ࠮ࡶࡤࡦࡸࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࠰ࡴࡦࡴࡥ࡭࠯ࡰࡳࡷ࡫ࠧᨚ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l11l1l1ll_l1_ l1l1_l1_
		items = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡪࡳࡢࡦࡦࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᨛ"),block,re.DOTALL)
		for id,l1lllll_l1_ in items:
			title = l11ll1_l1_ (u"࠭ำ๋ำไีࠥ࠭᨜")+id
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᨝")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᨞")
			l1llll_l1_.append(l1lllll_l1_)
		# other l1l1_l1_
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᨟"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᨠ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᨡ")+l1lllll_l1_
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᨢ"),url)
	return
def l1llll1ll_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧᨣ"),headers,l11ll1_l1_ (u"ࠧࠨᨤ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧᨥ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡩ࡯ࡦࡨࡼ࠲ࡲࡡࡴࡶ࠰ࡱࡴࡼࡩࡦࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥ࡭ࡳࡪࡥࡹ࠯ࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࠨᨦ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨧ"),block,re.DOTALL)
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬᨨ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᨩ"),l111l1_l1_+title,l1lllll_l1_,92,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨪ"),l111l1_l1_+title,l1lllll_l1_,91,l1lll1_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨᨫ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩᨬ"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫᨭ"),l11ll1_l1_ (u"ࠪ࠯ࠬᨮ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡷࡁࠬᨯ")+search
	ITEMS(url)
	return
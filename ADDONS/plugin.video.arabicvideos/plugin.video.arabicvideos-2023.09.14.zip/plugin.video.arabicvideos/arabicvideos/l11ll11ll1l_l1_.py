# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㾄")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡎࡇࡒࡤ࠭㾅")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ㾆"),l11ll1_l1_ (u"ࠩสืฯ็ำศำอ็๊่ࠦࠡษ็฻้ฮวหࠩ㾇")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l11111_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1ll1l_l1_(url)
	elif mode==454: results = l1llll1l_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㾈"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ㾉"),l11ll1_l1_ (u"ࠬ࠭㾊"),l11ll1_l1_ (u"࠭ࠧ㾋"),l11ll1_l1_ (u"ࠧࠨ㾌"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㾍"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㾎"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾏"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㾐"),l11ll1_l1_ (u"ࠬ࠭㾑"),459,l11ll1_l1_ (u"࠭ࠧ㾒"),l11ll1_l1_ (u"ࠧࠨ㾓"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㾔"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㾕"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㾖")+l111l1_l1_+l11ll1_l1_ (u"๊ࠫัศหษอࠤ้๎ฯ๋้ࠢฮࠬ㾗"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠬ࠭㾘"),l11ll1_l1_ (u"࠭ࠧ㾙"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㾚"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾛"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㾜")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ㾝"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠫࠬ㾞"),l11ll1_l1_ (u"ࠬ࠭㾟"),l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㾠"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㾡"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㾢")+l111l1_l1_+l11ll1_l1_ (u"่้ࠩะ๊๊็ࠩ㾣"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠪࠫ㾤"),l11ll1_l1_ (u"ࠫࠬ㾥"),l11ll1_l1_ (u"ࠬࡧࡣࡵࡱࡵࡷࠬ㾦"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾧"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㾨")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วห๊๊ࠢิ๐ษࠨ㾩"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠩࠪ㾪"),l11ll1_l1_ (u"ࠪࠫ㾫"),l11ll1_l1_ (u"ࠫ࠵࠭㾬"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㾭"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㾮")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อส้้ࠡำ๏ฯࠠๆัห่ัฯࠧ㾯"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠨࠩ㾰"),l11ll1_l1_ (u"ࠩࠪ㾱"),l11ll1_l1_ (u"ࠪ࠵ࠬ㾲"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㾳"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㾴")+l111l1_l1_+l11ll1_l1_ (u"࠭วโๆส้ࠥํๆะ์ฬࠫ㾵"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠧࠨ㾶"),l11ll1_l1_ (u"ࠨࠩ㾷"),l11ll1_l1_ (u"ࠩ࠵ࠫ㾸"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㾹"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㾺"),l11ll1_l1_ (u"ࠬ࠭㾻"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠭㾼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㾽"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ㾾"): continue
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㾿"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㿀")+l111l1_l1_+title,l1lllll_l1_,451)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬ㿁")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㿂"),l11ll1_l1_ (u"࠭ࠧ㿃"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㿄"),url,l11ll1_l1_ (u"ࠨࠩ㿅"),l11ll1_l1_ (u"ࠩࠪ㿆"),l11ll1_l1_ (u"ࠪࠫ㿇"),l11ll1_l1_ (u"ࠫࠬ㿈"),l11ll1_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㿉"))
	html = response.content
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㿊"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡼࡧࡶࡦࡵࠥࠫ㿋"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㿌"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡖࡪࡩࡥ࡯ࡶࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ㿍"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ㿎") in html:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㿏"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࠤࡄࡧࡹࡵࡲࡏࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿐"),block,re.DOTALL)
	elif l1lll1l1l1_l1_ in [l11ll1_l1_ (u"࠭࠰ࠨ㿑"),l11ll1_l1_ (u"ࠧ࠲ࠩ㿒"),l11ll1_l1_ (u"ࠨ࠴ࠪ㿓")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭㿔"),html,re.DOTALL)
		block = l1l1l11_l1_[int(l1lll1l1l1_l1_)]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ㿕"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭㿖"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ㿗"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ㿘"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭㿙"),l11ll1_l1_ (u"ࠨล฽๊๏ฯࠧ㿚"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧ㿛"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩ㿜"),l11ll1_l1_ (u"ࠫ์ีวโࠩ㿝"),l11ll1_l1_ (u"๋ࠬศศำสอࠬ㿞"),l11ll1_l1_ (u"ู࠭าุࠪ㿟"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧ㿠"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧ㿡")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠨ㿢") in html and l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠨ㿣") in l1lll1_l1_:
			l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㿤"),l1lll1_l1_,re.DOTALL)
			l1lll1_l1_ = l1lll1_l1_[0]
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ㿥"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ㿦"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㿧"),title,re.DOTALL)
		#if any(value in title for value in l1ll1l_l1_):
		if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ㿨") not in title:
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㿩"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪั้่ษࠨ㿪") in title:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㿫") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿬"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿭"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
	if l1lll1l1l1_l1_ in [l11ll1_l1_ (u"ࠧࠨ㿮"),l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㿯")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㿰"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㿱"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ㿲"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠬ࠭㿳"):
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿴"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭㿵")+title,l1lllll_l1_,451)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㿶"),url,l11ll1_l1_ (u"ࠩࠪ㿷"),l11ll1_l1_ (u"ࠪࠫ㿸"),l11ll1_l1_ (u"ࠫࠬ㿹"),l11ll1_l1_ (u"ࠬ࠭㿺"),l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㿻"))
	html = response.content
	# l1lll1l_l1_
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡖࡹࡧࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㿼"),html,re.DOTALL)
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠧ㿽") in str(l1l11l1_l1_):
		title = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠮ࠩ㿾"),html,re.DOTALL)
		title = title[0].strip(l11ll1_l1_ (u"ࠪࠤࠬ㿿"))
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䀀"),l111l1_l1_+title,url,454)
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䀁"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀂"),l111l1_l1_+title,l1lllll_l1_,454)
	else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䀃"),url,l11ll1_l1_ (u"ࠨࠩ䀄"),l11ll1_l1_ (u"ࠩࠪ䀅"),l11ll1_l1_ (u"ࠪࠫ䀆"),l11ll1_l1_ (u"ࠫࠬ䀇"),l11ll1_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䀈"))
	html = response.content
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭䀉"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ䀊"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䀋"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䀌"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䀍"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ䀎"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠬ࠭䀏"):
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀐"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭䀑")+title,l1lllll_l1_,454)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䀒"),l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䀓"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䀔"),l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䀕"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䀖"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ䀗"),l11ll1_l1_ (u"ࠧࠨ䀘"),l11ll1_l1_ (u"ࠨࠩ䀙"),l11ll1_l1_ (u"ࠩࠪ䀚"),l11ll1_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䀛"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䀜"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬࡙࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡸ࡯ࡤࡦࡀࠪ䀝"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ䀞"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䀟")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䀠")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡶࡩࡱࡧࡲࡺࠤࠪ䀡"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ䀢"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			name = unescapeHTML(name)
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䀣"),name,re.DOTALL)
			if l111llll_l1_:
				l111llll_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䀤")+l111llll_l1_[0]
				name = l11ll1_l1_ (u"࠭ࠧ䀥")
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠧࠨ䀦")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䀧")+name+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䀨")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䀩"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䀪"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭䀫"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ䀬"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ䀭"),l11ll1_l1_ (u"ࠨ࠭ࠪ䀮"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ䀯")+search
	l11111_l1_(url)
	return
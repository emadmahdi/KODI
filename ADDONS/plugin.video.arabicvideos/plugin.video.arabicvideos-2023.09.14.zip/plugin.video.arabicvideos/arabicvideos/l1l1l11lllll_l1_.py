# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭擜")
#headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ擝"):l11ll1_l1_ (u"࠭ࠧ擞")}
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭擟")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨ็ุหึ฿ษࠨ擠"),l11ll1_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ擡")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11111_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llll1l_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ擢"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ擣"),l11ll1_l1_ (u"ࠬ࠭擤"),l11ll1_l1_ (u"࠭ࠧ擥"),l11ll1_l1_ (u"ࠧࠨ擦"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ擧"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ擨"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠪ࠳ࠬ擩"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ擪"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ擫"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭擬"),l1ll111_l1_,489,l11ll1_l1_ (u"ࠧࠨ擭"),l11ll1_l1_ (u"ࠨࠩ擮"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭擯"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ擰"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ擱"),l11ll1_l1_ (u"ࠬ࠭擲"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擳"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ擴")+l111l1_l1_+l11ll1_l1_ (u"ࠨละำะࠦวๅ็๋ห฻๐ูࠨ擵"),l1ll111_l1_,481)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨ࡭ࡺࡃࡦࡧࡴࡻ࡮ࡵࠤࠪ擶"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ擷"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭擸"): continue
		if title in l1l11l_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ擹"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ擺")+l111l1_l1_+title,l1lllll_l1_,481)
	return html
def l11111_l1_(url,l1lll111111l1_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ擻"),url,l11ll1_l1_ (u"ࠨࠩ擼"),l11ll1_l1_ (u"ࠩࠪ擽"),l11ll1_l1_ (u"ࠪࠫ擾"),l11ll1_l1_ (u"ࠫࠬ擿"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ攀"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡱࡶࡸ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ攁"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭攂"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ攃"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ攄"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ攅"),l11ll1_l1_ (u"ࠫศเๆ๋หࠪ攆"),l11ll1_l1_ (u"้ࠬไ๋สࠪ攇"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ攈"),l11ll1_l1_ (u"่ࠧัสๅࠬ攉"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ攊"),l11ll1_l1_ (u"ࠩ฼ี฻࠭攋"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ攌"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ攍"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬ攎")]
	l1lll111111ll_l1_ = l11ll1_l1_ (u"࠭࠯ࠨ攏").join(l1lll111111l1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ攐")).split(l11ll1_l1_ (u"ࠨ࠱ࠪ攑"))[4:]).split(l11ll1_l1_ (u"ࠩ࠰ࠫ攒"))
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ攓"),title,re.DOTALL)
		if l1lll111111l1_l1_:
			l1lllll11l_l1_ = l11ll1_l1_ (u"ࠫ࠴࠭攔").join(l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ攕")).split(l11ll1_l1_ (u"࠭࠯ࠨ攖"))[4:]).split(l11ll1_l1_ (u"ࠧ࠮ࠩ攗"))
			l1lll11111l11_l1_ = len([x for x in l1lll111111ll_l1_ if x in l1lllll11l_l1_])
			if l1lll11111l11_l1_>2 and l11ll1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ攘") in l1lllll_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ攙"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
		else:
			if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭攚"),title,re.DOTALL)
			#if any(value in title for value in l1ll1l_l1_):
			if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ู๊ࠫไิๆࠪ攛") not in title:
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ攜"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"࠭อๅไฬࠫ攝") in title:
				title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭攞") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攟"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ攠"),url)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ攡"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ攢"),url)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠣ攣"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ攤"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠧศๆุๅาฯࠠࠨ攥"),l11ll1_l1_ (u"ࠨࠩ攦"))
			if title!=l11ll1_l1_ (u"ࠩࠪ攧"): addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ攨"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ攩")+title,l1lllll_l1_,481,l11ll1_l1_ (u"ࠬ࠭攪"),l11ll1_l1_ (u"࠭ࠧ攫"),l1lll111111l1_l1_)
	return
def l1llll1l_l1_(url,l111lll_l1_):
	headers = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ攬"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ攭")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭攮"),url,l11ll1_l1_ (u"ࠪࠫ支"),headers,l11ll1_l1_ (u"ࠫࠬ攰"),l11ll1_l1_ (u"ࠬ࠭攱"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ攲"))
	html = response.content
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ攳"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ攴"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ攵"))
	l1lll1111111l_l1_ = True
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡱ࡯ࡳࡵࡕࡨࡥࡸࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ收"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ攷") not in url:
		block = l1l11l1_l1_[0]
		count = block.count(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠩ攸"))
		if count==0: count = block.count(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠬ改"))
		if count>1:
			l1lll1111111l_l1_ = False
			if l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦࠬ攺") in block:
				items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ攻"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠶࠳ࡶࡨࡱࡁࡶࡰࡺ࡭࠽ࠨ攼")+id
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ攽"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
			else:
				items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ放"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠮ࡱࡪࡳࡃࡸ࡫ࡲࡪࡧࡶࡍࡉࡃࠧ政")+id
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭敀"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
	# l1l11_l1_
	if l1lll1111111l_l1_:
		block = l11ll1_l1_ (u"ࠧࠨ敁")
		if l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ敂") in url: block = html
		else:
			l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡩࡵࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ敃"),html,re.DOTALL)
			if l1l111l_l1_: block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ敄"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭故"))
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ敆"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
	if not menuItemsLIST: l11111_l1_(l111lll_l1_,url)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"࠭࠯ࠨ敇"))+l11ll1_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡽࡡࡵࡥ࡫ࠫ效")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ敉"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ敊"),l11ll1_l1_ (u"ࠪࠫ敋"),l11ll1_l1_ (u"ࠫࠬ敌"),l11ll1_l1_ (u"ࠬ࠭敍"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ敎"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ敏"))
	l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡲࡣࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ敐"),html,re.DOTALL)
	if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡟ࠬࡹ࡮ࡩࡴ࡞࠱࡭ࡩࡢࠬ࠱࡞࠯ࠬ࠳࠰࠿ࠪ࡞ࠬࠫ救"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭敒"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ敓"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ敔"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡪࡨࡵࡥࡲ࡫࠲࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ敕")+l1ll1llll1_l1_+l11ll1_l1_ (u"ࠧࠧࡸ࡬ࡨࡪࡵ࠽ࠨ敖")+l1lll111l1_l1_[2:]+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ敗")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ敘")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l11l1l1ll_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡬࡫ࡴࡆ࡯ࡥࡩࡩࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ教"),html,re.DOTALL)
	if l1lllll_l1_:
		title = SERVER(l1lllll_l1_[0],l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ敚"))
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭敛")+title+l11ll1_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ敜")
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ敝"))+l11ll1_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡤࡰࡹࡱࡰࡴࡧࡤࠨ敞")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭敟"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ敠"),l11ll1_l1_ (u"ࠫࠬ敡"),l11ll1_l1_ (u"ࠬ࠭敢"),l11ll1_l1_ (u"࠭ࠧ散"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ敤"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡷࡥࡧࡲࡥ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ敥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ敦"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ敧"))
			if l11ll1_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ敨") in l1lllll_l1_: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ฯษุࠫ敩")
			else: l1lll1l1l_l1_ = l11ll1_l1_ (u"࠭ࠧ敪")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ敫")+title+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ敬")+l1lll1l1l_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ敭"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ敮"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"ࠫࠬ敯")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭数"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ敱"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ敲"),l11ll1_l1_ (u"ࠨ࠭ࠪ敳"))
	if l1ll111_l1_==l11ll1_l1_ (u"ࠩࠪ整"): l1ll111_l1_ = l11l1l_l1_
	url = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ敵")+search+l11ll1_l1_ (u"ࠫ࠴࠭敶")
	l11111_l1_(url,l11ll1_l1_ (u"ࠬ࠭敷"))
	return
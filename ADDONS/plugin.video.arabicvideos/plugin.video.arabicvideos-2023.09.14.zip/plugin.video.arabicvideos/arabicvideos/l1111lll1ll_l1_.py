# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ嫣")
headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嫤") : l11ll1_l1_ (u"ࠨࠩ嫥") }
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨ嫦")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l11111_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llll1l_l1_(url)
	elif mode==214: results = l1lllll11lll1_l1_(url)
	elif mode==215: results = l1lllll11llll_l1_(url)
	elif mode==218: results = l11ll1l11111_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11ll1l11111_l1_():
	message = l11ll1_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ嫧")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嫨"),l11ll1_l1_ (u"ࠬ࠭嫩"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嫪"),l11ll1_l1_ (u"ࠧศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้࠭嫫"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫬"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ嫭"),l11ll1_l1_ (u"ࠪࠫ嫮"),219,l11ll1_l1_ (u"ࠫࠬ嫯"),l11ll1_l1_ (u"ࠬ࠭嫰"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ嫱"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫲"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึ࠭嫳"),l11ll1_l1_ (u"ࠩࠪ嫴"),114,l11l1l_l1_)
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡖࡩ࡯ࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࡳ࡭ࡳࠬ࡬ࡪ࡯࡬ࡸࡂ࠸࠵ࠨ嫵")
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫶"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ嫷")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧ嫸"),url,211)
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ嫹"),headers,l11ll1_l1_ (u"ࠨࠩ嫺"),l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ嫻"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡊ࡮ࡲࡴࡦࡴࡶࡆࡺࡺࡴࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ嫼"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡪࡩࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嫽"),block,re.DOTALL)
	for l1lllll_l1_,title in items:#[1:-1]:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࠩ嫾")+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫿"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嬀")+l111l1_l1_+title,url,211)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嬁"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嬂"),block,re.DOTALL)
	l1l11l_l1_ = [l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩ嬃"),l11ll1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭嬄")]
	#l111l1111_l1_ = [l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦࠧ嬅"),l11ll1_l1_ (u"࠭วโๆส้ࠥ࠭嬆"),l11ll1_l1_ (u"ࠧษำส้ั࠭嬇"),l11ll1_l1_ (u"ࠨ฻ิ์฻࠭嬈"),l11ll1_l1_ (u"ࠩๆ่๏ฮวหࠩ嬉"),l11ll1_l1_ (u"ࠪห฿อๆ๊ࠩ嬊")]
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭嬋"))
		if not any(value in title for value in l1l11l_l1_):
		#	if any(value in title for value in l111l1111_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬌"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ嬍")+l111l1_l1_+title,l1lllll_l1_,211)
	return html
def l11111_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠧࠨ嬎"),headers,l11ll1_l1_ (u"ࠨࠩ嬏"),l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ嬐"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嬑"),l11ll1_l1_ (u"ࠫࠬ嬒"),url,html)
	if l11ll1_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ嬓") in url or l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ嬔") in url: block = html
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭嬕"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: return
	items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬖"),block,re.DOTALL)
	l11l_l1_ = []
	l111lll11_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩ嬗"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ嬘"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪ嬙"),l11ll1_l1_ (u"้ࠬไ๋สࠪ嬚"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ嬛"),l11ll1_l1_ (u"่ࠧัสๅࠬ嬜"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ嬝"),l11ll1_l1_ (u"ࠩ฼ี฻࠭嬞"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ嬟"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ嬠")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ嬡") in l1lllll_l1_: continue
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"࠭࠯ࠨ嬢"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ嬣"))
		if l11ll1_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ嬤") in l1lllll_l1_ or any(value in title for value in l111lll11_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嬥"),l111l1_l1_+title,l1lllll_l1_,212,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭嬦") in l1lllll_l1_ and l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫ嬧") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ嬨"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ嬩") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬪"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
					l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬫"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嬬"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬭"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ嬮"),l11ll1_l1_ (u"ࠬ࠭嬯"))
			if title!=l11ll1_l1_ (u"࠭ࠧ嬰"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬱"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ嬲")+title,l1lllll_l1_,211)
	return
def l1llll1l_l1_(url):
	l111lllll_l1_,items,l1111lll_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠩࠪ嬳"),headers,l11ll1_l1_ (u"ࠪࠫ嬴"),l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ嬵"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ嬶"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1111l1_l1_ = l11ll1_l1_ (u"࠭ࠧ嬷").join(l1l1l11_l1_)
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嬸"),l1111l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ嬹"))
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ嬺"))
		title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ嬻") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭嬼"))[-1].replace(l11ll1_l1_ (u"ࠬ࠳ࠧ嬽"),l11ll1_l1_ (u"࠭ࠠࠨ嬾"))
		l111l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧศๆะ่็ฯ࠭ࠩ࡞ࡧ࠯࠮࠭嬿"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ孀"))[-1],re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = l111l1ll_l1_[0]
		else: l111l1ll_l1_ = l11ll1_l1_ (u"ࠩ࠳ࠫ孁")
		l1111lll_l1_.append([l1lllll_l1_,title,l111l1ll_l1_])
	items = sorted(l1111lll_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lll1l_l1_ = str(items).count(l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ孂"))
	l111lllll_l1_ = str(items).count(l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ孃"))
	if l111lll1l_l1_>1 and l111lllll_l1_>0 and l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ孄") not in url:
		for l1lllll_l1_,title,l111l1ll_l1_ in items:
			if l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ孅") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孆"),l111l1_l1_+title,l1lllll_l1_,213)
	else:
		for l1lllll_l1_,title,l111l1ll_l1_ in items:
			if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ孇") not in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ孈"),l111l1_l1_+title,l1lllll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ孉"))
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬ孊"),headers,l11ll1_l1_ (u"ࠬ࠭孋"),l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ孌"))
	# l11l1l1ll_l1_ l1l1_l1_
	if l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ孍") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ孎"))
		l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ孏"),headers,l11ll1_l1_ (u"ࠪࠫ子"),l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ孑"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ孒"),l11ll1ll_l1_,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡧࡵࡺࡪࡸ࡟ࡪ࡯ࡤ࡫ࡪࠨ࠾࡝ࡰࠫ࠲࠯ࡅࠩ࡝ࡰࠪ孓"),block,re.DOTALL)
			if items:
				id = re.findall(l11ll1_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ孔"),l11ll1ll_l1_,re.DOTALL)
				if id:
					l11lll1l1l_l1_ = id[0]
					for l1lllll_l1_,title in items:
						l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫ孕")+l11lll1l1l_l1_+l11ll1_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭孖")+l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ字")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ存")
						l1llll_l1_.append(l1lllll_l1_)
			else:
				# https://l1lllll1l1111_l1_.tv/l11l1l1ll_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭孙"),block,re.DOTALL)
				for l1lllll_l1_,dummy in items:
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	if l11ll1_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ孚") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ孛"))
		l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ孜"),headers,l11ll1_l1_ (u"ࠩࠪ孝"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ孞"))
		id = re.findall(l11ll1_l1_ (u"ࠫࡵࡵࡳࡵࡋࡧ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ孟"),l11ll1ll_l1_,re.DOTALL)
		if id:
			l11lll1l1l_l1_ = id[0]
			l1l1ll11l_l1_ = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ孠"):l11ll1_l1_ (u"࠭ࠧ孡") , l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ孢"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ季") }
			l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ孤")+l11lll1l1l_l1_
			l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ孥"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠫࠬ学"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭孧"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ孨"),l11ll1ll_l1_,re.DOTALL)
			if l1l1l11_l1_:
				for resolution,block in l1l1l11_l1_:
					items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ孩"),block,re.DOTALL)
					for name,l1lllll_l1_ in items:
						l1llll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ孪")+name+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭孫")+l11ll1_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ孬")+resolution)
			else:
				l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁ࡮࠶ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ孭"),l11ll1ll_l1_,re.DOTALL)
				if not l1l1l11_l1_: l1l1l11_l1_ = [l11ll1ll_l1_]
				for block in l1l1l11_l1_:
					l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡸ࡫ࡲࡷࡧࡵࡷ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡳࡧ࡭ࡦ࠼ࠍࠍࠎࠏࠉࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࡛࠮࠳ࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭วๅัๅอࠥ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫ࠡ࠾ࠩࠪ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧࠣ࠯ࠥ࠭ࠠแࠢࠪࠎࠎࠏࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࠩࠪࠎࠎࠏࠉࠊࠋࠥࠦࠧ孮")
					name = l11ll1_l1_ (u"࠭ࠧ孯")
					items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ孰"),block,re.DOTALL)
					for l1lllll_l1_ in items:
						server = l11ll1_l1_ (u"ࠨࠨࠩࠫ孱") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫ孲"))[2].lower() + l11ll1_l1_ (u"ࠪࠪࠫ࠭孳")
						server = server.replace(l11ll1_l1_ (u"ࠫ࠳ࡩ࡯࡮ࠨࠩࠫ孴"),l11ll1_l1_ (u"ࠬ࠭孵")).replace(l11ll1_l1_ (u"࠭࠮ࡤࡱࠩࠪࠬ孶"),l11ll1_l1_ (u"ࠧࠨ孷"))
						server = server.replace(l11ll1_l1_ (u"ࠨ࠰ࡱࡩࡹࠬࠦࠨ學"),l11ll1_l1_ (u"ࠩࠪ孹")).replace(l11ll1_l1_ (u"ࠪ࠲ࡴࡸࡧࠧࠨࠪ孺"),l11ll1_l1_ (u"ࠫࠬ孻"))
						server = server.replace(l11ll1_l1_ (u"ࠬ࠴࡬ࡪࡸࡨࠪࠫ࠭孼"),l11ll1_l1_ (u"࠭ࠧ孽")).replace(l11ll1_l1_ (u"ࠧ࠯ࡱࡱࡰ࡮ࡴࡥࠧࠨࠪ孾"),l11ll1_l1_ (u"ࠨࠩ孿"))
						server = server.replace(l11ll1_l1_ (u"ࠩࠩࠪ࡭ࡪ࠮ࠨ宀"),l11ll1_l1_ (u"ࠪࠫ宁")).replace(l11ll1_l1_ (u"ࠫࠫࠬࡷࡸࡹ࠱ࠫ宂"),l11ll1_l1_ (u"ࠬ࠭它"))
						server = server.replace(l11ll1_l1_ (u"࠭ࠦࠧࠩ宄"),l11ll1_l1_ (u"ࠧࠨ宅"))
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ宆") + name + server + l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭宇")
						l1llll_l1_.append(l1lllll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ守"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ安"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭宊"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ宋"),l11ll1_l1_ (u"ࠧࠬࠩ完"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ宍")+search
	l11111_l1_(url)
	return
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡷࡪࡧࡲࡤࡪࠣࡷࡪࡩ࡯࡯ࡦࡤࡶࡾ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡩࡡࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩࡨࡦࡥ࡮ࡱࡦࡸ࡫࠮ࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠰࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌࠍ࡫ࡵࡲࠡࡥࡤࡸࡪ࡭࡯ࡳࡻ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࠌࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠋࡗࡍ࡙ࡒࡅࡔࠪࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ宎")
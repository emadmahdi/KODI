# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ枈")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣ࡞ࡗࡔࡠࠩ枉")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭枊"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭枋"),l11ll1_l1_ (u"࠭สิฮํ่ࠬ枌"),l11ll1_l1_ (u"ࠧหีฯ๎้ࠦวๅัั์้࠭枍"),l11ll1_l1_ (u"ࠨ฻ิฺࠥอไๆิํำࠬ枎")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l11111_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l1llll1_l1_(url,text)
	elif mode==664: results = l1l111_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭枏"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ析"),l11ll1_l1_ (u"ࠫࠬ枑"),l11ll1_l1_ (u"ࠬ࠭枒"),l11ll1_l1_ (u"࠭ࠧ枓"),l11ll1_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ枔"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枕"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ枖"),l11ll1_l1_ (u"ࠪࠫ林"),669,l11ll1_l1_ (u"ࠫࠬ枘"),l11ll1_l1_ (u"ࠬ࠭枙"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ枚"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ枛"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ果"),l11ll1_l1_ (u"ࠩࠪ枝"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ枞"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭枟")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭枠"),l11l1l_l1_,661,l11ll1_l1_ (u"࠭ࠧ枡"),l11ll1_l1_ (u"ࠧࠨ枢"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ枣"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ枤"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ枥")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ枦"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠬ࠭枧"),l11ll1_l1_ (u"࠭ࠧ枨"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭枩"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枪"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ枫")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ枬"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠫࠬ枭"),l11ll1_l1_ (u"ࠬ࠭枮"),l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ枯"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ枰"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ枱")+l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭枲"),l11l1l_l1_,661,l11ll1_l1_ (u"ࠪࠫ枳"),l11ll1_l1_ (u"ࠫࠬ枴"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ枵"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ架"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ枷"),l11ll1_l1_ (u"ࠨࠩ枸"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ枹"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ枺"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ枻"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ枼")+l111l1_l1_+title,l1lllll_l1_,664)
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ枽"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ枾"),l11ll1_l1_ (u"ࠨࠩ枿"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭柀"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ柁"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠫࠬ柂"))
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ柃"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = title.replace(l11ll1_l1_ (u"࠭࠼ࡣࡀࠪ柄"),l11ll1_l1_ (u"ࠧࠨ柅")).replace(l11ll1_l1_ (u"ࠨ࠾࠲ࡦࡃ࠭柆"),l11ll1_l1_ (u"ࠩࠪ柇")).replace(l11ll1_l1_ (u"ࠪࡀࡧࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡴࡨࡸࠧࡄࠧ柈"),l11ll1_l1_ (u"ࠫࠬ柉")).replace(l11ll1_l1_ (u"ࠬࡂࡢ࠿ࠩ柊"),l11ll1_l1_ (u"࠭ࠧ柋")).strip(l11ll1_l1_ (u"ࠧࠡࠩ柌"))
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ柍"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ柎")+l111l1_l1_+title,l1lllll_l1_,664)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ柏"),url,l11ll1_l1_ (u"ࠫࠬ某"),l11ll1_l1_ (u"ࠬ࠭柑"),l11ll1_l1_ (u"࠭ࠧ柒"),l11ll1_l1_ (u"ࠧࠨ染"),l11ll1_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ柔"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ柕"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ柖"),l11ll1_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ柗"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ柘"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"࠭ࠧ柙"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ柚"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭柛"),l11ll1_l1_ (u"ࠩࠪ柜"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ柝"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ柞")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ柟"),l111l1_l1_+title,l1lllll_l1_,661)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ柠"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ柡"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭柢"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ柣"),l11ll1_l1_ (u"ࠪࠫ柤"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ查"),l111l1_l1_+title,l1lllll_l1_,661)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠬ࠭柦")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ柧"),l11ll1_l1_ (u"ࠧࠨ柨"),request,url)
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭柩"):
		url,search = url.split(l11ll1_l1_ (u"ࠩࡂࠫ柪"),1)
		data = l11ll1_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ柫")+search
		headers = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ柬"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ柭")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ柮"),url,data,headers,l11ll1_l1_ (u"ࠧࠨ柯"),l11ll1_l1_ (u"ࠨࠩ柰"),l11ll1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ柱"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ柲"),url,l11ll1_l1_ (u"ࠫࠬ柳"),l11ll1_l1_ (u"ࠬ࠭柴"),l11ll1_l1_ (u"࠭ࠧ柵"),l11ll1_l1_ (u"ࠧࠨ柶"),l11ll1_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ柷"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠩࠪ柸"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ柹"))
	if request==l11ll1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ柺"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ査"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"࠭ࠧ柼"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ柽"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ柾"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ柿"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ栀"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ栁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ栂"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ栃"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ栄"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ栅"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠩࠪ栆"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ标"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ栈"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ栉"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ栊"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭栋"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭栌"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ栍"),l11ll1_l1_ (u"๋ࠪิอแࠨ栎"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ栏"),l11ll1_l1_ (u"ࠬ฿ัืࠩ栐"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭树"),l11ll1_l1_ (u"ࠧศๆห์๊࠭栒"),l11ll1_l1_ (u"ࠨ็ึีา๐ษࠨ栓")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		title = title.replace(l11ll1_l1_ (u"ࠩส์๋ࠦไศ์้ࠤࠬ栔"),l11ll1_l1_ (u"ࠪࠫ栕")).replace(l11ll1_l1_ (u"ࠫฬ๎ๆๅษํ๊ࠥ࠭栖"),l11ll1_l1_ (u"ࠬ࠭栗")).replace(l11ll1_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ栘"),l11ll1_l1_ (u"ࠧࠨ栙"))
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ栚"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ栛") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ栜")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭栝"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ栞") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ栟")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ栠"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ校"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ栢"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ栣"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ栤"):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ栥"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ栦") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ栧"),l111l1_l1_+title,l1lllll_l1_,663,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭栨") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ栩"),l111l1_l1_+title,l1lllll_l1_,661,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ株"),l111l1_l1_+title,l1lllll_l1_,663,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ栫"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ栬")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ栭"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ栮"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ栯"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ栰")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ栱"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ栲"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ栳")+title,l1lllll_l1_,661)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ栴"),l11ll1_l1_ (u"ࠧࠨ栵"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ栶"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭样"),url,l11ll1_l1_ (u"ࠪࠫ核"),l11ll1_l1_ (u"ࠫࠬ根"),l11ll1_l1_ (u"ࠬ࠭栺"),l11ll1_l1_ (u"࠭ࠧ栻"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭格"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ栽"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ栾"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠪࠫ栿")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ桀"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠩࠧ桁"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桂"),l111l1_l1_+title,url,663,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ桃"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ桄")+l1l1l_l1_+l11ll1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ桅"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ框"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		#if not items: items = re.findall(l11ll1_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ桇"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ案")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠮࠰ࠩ桉"))
			title = title.replace(l11ll1_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ桊"),l11ll1_l1_ (u"ࠨࠢࠪ桋"))
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ桌"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ桍"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ桎") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ桏")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ桐"))
		#		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭桑"),l111l1_l1_+title,l1lllll_l1_,662,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l11l_l1_,l1llll11_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ桒"),l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬ桓"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ桔"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ桕"),l11ll1_l1_ (u"ࠬ࠭桖"),l11ll1_l1_ (u"࠭ࠧ桗"),l11ll1_l1_ (u"ࠧࠨ桘"),l11ll1_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ桙"))
	html = response.content
	# l1l111l1l_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡐ࡭ࡣࡼࡩࡷ࡮࡯࡭ࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ桚"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ桛"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ桜"))
			l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ桝"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧ桞"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ桟")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ桠"))
				l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠣࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡰ࡮ࡴ࡫ࡴࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭ࠬࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳ࡶࡨࡱࠩࠬࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨ࡛ࡄࡕࡔ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡵࡳ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍࠎࠏ࡮ࡢ࡯ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ桡")
	l1111l_l1_ = zip(l1llll_l1_,l1l11l11l_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1llll11_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ桢"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ档"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭桤"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ桥"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ桦"),l11ll1_l1_ (u"ࠨ࠭ࠪ桧"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪ桨")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ桩"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨ桪")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ桫"))
	return
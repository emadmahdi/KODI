# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭扂")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ扃")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ扄"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11111_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1lll111l111l_l1_(url)
	elif mode==314: results = l1llll1ll_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭扅"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ扆"),l11ll1_l1_ (u"ࠨࠩ扇"),319,l11ll1_l1_ (u"ࠩࠪ扈"),l11ll1_l1_ (u"ࠪࠫ扉"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ扊"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ手"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠫ扌"),l11ll1_l1_ (u"ࠧࠨ才"),114,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ扎"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ扏"),l11ll1_l1_ (u"ࠪࠫ扐"),l11ll1_l1_ (u"ࠫࠬ扑"),l11ll1_l1_ (u"ࠬ࠭扒"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ打"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶ࡮࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ扔"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭払"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ扖"),l11ll1_l1_ (u"ࠪࠫ扗"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠫࡁ࡮࠵࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠸ࡂࠬ托"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11ll1_l1_ (u"ࠬࠦࠧ扙"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭扚"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ扛")+l111l1_l1_+title,l11l1l_l1_,314,l11ll1_l1_ (u"ࠨࠩ扜"),l11ll1_l1_ (u"ࠩࠪ扝"),str(seq+1))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ扞"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭扟")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬโศู฼ࠤูํัࠨ扠"),l11l1l_l1_,314,l11ll1_l1_ (u"࠭ࠧ扡"),l11ll1_l1_ (u"ࠧࠨ扢"),l11ll1_l1_ (u"ࠨ࠲ࠪ扣"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ扤"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ扥"),l11ll1_l1_ (u"ࠫࠬ扦"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡃࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡅࡂࠬ执"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ扨")+l1lllll_l1_
		#title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ扩"))
		#url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡃࡪ࡯ࡤࡒࡴࡽ࠯ࡊࡰࡷࡩࡷ࡬ࡡࡤࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠱ࡴ࡭ࡶࠧ扪")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ扫"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ扬")+l111l1_l1_+title,l1lllll_l1_,311)
	return html
def l1llll1ll_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ扭"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭扮"),l11ll1_l1_ (u"࠭ࠧ扯"),l11ll1_l1_ (u"ࠧࠨ扰"),l11ll1_l1_ (u"ࠨࠩ扱"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ扲"))
	html = response.content
	if seq==l11ll1_l1_ (u"ࠪ࠴ࠬ扳"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ扴"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ扵"),block,re.DOTALL)
		for l1lllll_l1_,name,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ扶")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ扷"))
			name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ扸"))
			title = title+l11ll1_l1_ (u"ࠩࠣࠬࠬ批")+name+l11ll1_l1_ (u"ࠪ࠭ࠬ扺")
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ扻"),l111l1_l1_+title,l1lllll_l1_,312)
	elif seq in [l11ll1_l1_ (u"ࠬ࠷ࠧ扼"),l11ll1_l1_ (u"࠭࠲ࠨ扽"),l11ll1_l1_ (u"ࠧ࠴ࠩ找")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠿࡬࠺ࡄ࠮ࠫࡁࠬࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡲࡧࠨ承"),html,re.DOTALL)
		l1lll111l1111_l1_ = int(seq)-1
		block = l1l1l11_l1_[l1lll111l1111_l1_]
		if seq==l11ll1_l1_ (u"ࠩ࠴ࠫ技"): items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ抁"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ抂"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,name in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ抃")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ抄")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ抅"))
			name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ抆"))
			title = title+l11ll1_l1_ (u"ࠩࠣࠬࠬ抇")+name+l11ll1_l1_ (u"ࠪ࠭ࠬ抈")
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ抉"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	elif seq in [l11ll1_l1_ (u"ࠬ࠺ࠧ把"),l11ll1_l1_ (u"࠭࠵ࠨ抋"),l11ll1_l1_ (u"ࠧ࠷ࠩ抌")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠿࡬࠺ࡄ࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ抍"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1l11_l1_[seq]
		items = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࠳ࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ抎"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,l1l1ll111l1_l1_,title,l1ll1lll1ll_l1_ in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ抏")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࠭抐")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ抑"))
			l1l1ll111l1_l1_ = l1l1ll111l1_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ抒"))
			l1ll1lll1ll_l1_ = l1ll1lll1ll_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ抓"))
			if l1l1ll111l1_l1_: name = l1l1ll111l1_l1_
			else: name = l1ll1lll1ll_l1_
			title = title+l11ll1_l1_ (u"ࠨࠢࠫࠫ抔")+name+l11ll1_l1_ (u"ࠩࠬࠫ投")
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ抖"),l111l1_l1_+title,l1lllll_l1_,312,l1lll1_l1_)
	return
def l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ抗"),url,l11ll1_l1_ (u"ࠬ࠭折"),l11ll1_l1_ (u"࠭ࠧ抙"),l11ll1_l1_ (u"ࠧࠨ抚"),l11ll1_l1_ (u"ࠨࠩ抛"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ抜"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡧࡵࡸ࠮ࡪࡨࡥࡩ࡯࡮ࡨࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧ࡮ࡲࡥࡹ࠳ࡲࡪࡩ࡫ࡸࠬ抝"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	if l11ll1_l1_ (u"ࠫࡨࡧࡴࡴࡷࡰ࠱ࡲࡵࡢࡪ࡮ࡨࠫ択") in block:
		items = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂࡧࡦࡺࡳࡶ࡯࠰ࡱࡴࡨࡩ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ抟"),block,re.DOTALL)
		if items:
			for l1lll1_l1_,l1lllll_l1_,title,count in items:
				l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ抠")+l1lll1_l1_
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ抡")+l1lllll_l1_
				count = count.replace(l11ll1_l1_ (u"ࠨࠢสฺ่๎ส๋ห࠽ࠤࠬ抢"),l11ll1_l1_ (u"ࠩ࠽ࠫ抣"))
				title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ护"))
				title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ报")+count+l11ll1_l1_ (u"ࠬ࠯ࠧ抦")
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抧"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	else:
		items = re.findall(l11ll1_l1_ (u"ࠧࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ抨"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll111l11l1_l1_,l1l11lll1_l1_ in items:
			if title==l11ll1_l1_ (u"ࠨࠩ抩") or l1lll111l11l1_l1_==l11ll1_l1_ (u"ࠩࠪ抪"): continue
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ披")+l1lllll_l1_
			title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ抬")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠬ࠯ࠧ抭")
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ抮"),l111l1_l1_+title,l1lllll_l1_,312)
	if not items: l1llll1l_l1_(html)
	return
def l1llll1l_l1_(html):
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ抯"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭抰"),block,re.DOTALL)
	for l1lllll_l1_,title,name,count,l1l11lll1_l1_ in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ抱")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ抲"))
		name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭抳"))
		title = title+l11ll1_l1_ (u"ࠬࠦࠨࠨ抴")+name+l11ll1_l1_ (u"࠭ࠩࠨ抵")
		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭抶"),l111l1_l1_+title,l1lllll_l1_,312,l11ll1_l1_ (u"ࠨࠩ抷"),l1l11lll1_l1_)
	return
def l1lll111l111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭抸"),url,l11ll1_l1_ (u"ࠪࠫ抹"),l11ll1_l1_ (u"ࠫࠬ抺"),l11ll1_l1_ (u"ࠬ࠭抻"),l11ll1_l1_ (u"࠭ࠧ押"),l11ll1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡗࡊࡇࡒࡄࡊࡢࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭抽"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠠࡱ࠯࠴ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ抾"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l11111_l1_(url)
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ抿"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ拀")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭拁"))
		if l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠱ࠬ拂") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ拃"),l111l1_l1_+title,l1lllll_l1_,312)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拄"),l111l1_l1_+title,l1lllll_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ担"),url,l11ll1_l1_ (u"ࠩࠪ拆"),l11ll1_l1_ (u"ࠪࠫ拇"),l11ll1_l1_ (u"ࠫࠬ拈"),l11ll1_l1_ (u"ࠬ࠭拉"),l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ拊"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࡸࡨ࡮ࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ拋"),html,re.DOTALL)
	if not l1lllll_l1_: l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ拌"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ拍"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ拎"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ拏"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ拐"),l11ll1_l1_ (u"࠭ࠫࠨ拑"))
	l11lllll111l_l1_ = [l11ll1_l1_ (u"ࠧࠧࡶࡀࡥࠬ拒"),l11ll1_l1_ (u"ࠨࠨࡷࡁࡨ࠭拓"),l11ll1_l1_ (u"ࠩࠩࡸࡂࡹࠧ拔")]
	if l1ll_l1_:
		l1l1111l1111_l1_ = [l11ll1_l1_ (u"ࠪๆฬืฦࠨ拕"),l11ll1_l1_ (u"ࠫส฻ฯศำࠣ࠳๋ࠥฬๅัࠪ拖"),l11ll1_l1_ (u"๋ࠬโุ฻ࠣห้฻่ห์ࠪ拗")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡ࠯ࠣวำะัࠡษ็ฬาัࠧ拘"), l1l1111l1111_l1_)
		if l1l_l1_ == -1: return
	elif l11ll1_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࡤ࠭拙") in options: l1l_l1_ = 0
	elif l11ll1_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࡤ࠭拚") in options: l1l_l1_ = 1
	elif l11ll1_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘࡥࠧ招") in options: l1l_l1_ = 2
	else: return
	type = l11lllll111l_l1_[l1l_l1_]
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫ拜")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ拝"),url,l11ll1_l1_ (u"ࠬ࠭拞"),l11ll1_l1_ (u"࠭ࠧ拟"),l11ll1_l1_ (u"ࠧࠨ拠"),l11ll1_l1_ (u"ࠨࠩ拡"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ拢"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ拣"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭拤"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ拥"))
				name = name.strip(l11ll1_l1_ (u"࠭ࠠࠨ拦"))
				title = title+l11ll1_l1_ (u"ࠧࠡࠪࠪ拧")+name+l11ll1_l1_ (u"ࠨࠫࠪ拨")
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ择"),l111l1_l1_+title,l1lllll_l1_,313,l1lll1_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽ࠩ拪"),block,re.DOTALL)
			for l1lllll_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭拫"))
				name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ括"))
				title = title+l11ll1_l1_ (u"࠭ࠠࠩࠩ拭")+name+l11ll1_l1_ (u"ࠧࠪࠩ拮")
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ拯"),l111l1_l1_+title,l1lllll_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11lll1ll11_l1_ import *
script_name = l11ll1_l1_ (u"ࠫࡎࡔࡉࡕࠩ烁")
LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ烂"),l11ll1_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠫ烃"))
l1ll1111ll1_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ = l1ll1111ll1_l1_
l1ll111111ll_l1_ = int(mode)
l1ll1l1lll11_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ烄"))
l1ll1l1lll11_l1_ = l1ll1l1lll11_l1_.replace(ltr,l11ll1_l1_ (u"ࠨࠩ烅")).replace(rtl,l11ll1_l1_ (u"ࠩࠪ烆"))
if l1ll111111ll_l1_==260: message = l11ll1_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ烇")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ烈")+l1l111l1ll1_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ烉")
else:
	l1ll1l1l1llll_l1_ = l1111_l1_(addon_path).replace(l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ烊"),l11ll1_l1_ (u"ࠧࠨ烋")).replace(l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ烌"),l11ll1_l1_ (u"ࠩࠪ烍"))
	l1ll1l1l1llll_l1_ = l1ll1l1l1llll_l1_.replace(l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ烎"),l11ll1_l1_ (u"ࠫࠬ烏")).strip(l11ll1_l1_ (u"ࠬࠦࠧ烐"))
	l1ll1l1l1llll_l1_ = l1ll1l1l1llll_l1_.replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠫ烑"),l11ll1_l1_ (u"ࠧࠡࠩ烒")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ烓"),l11ll1_l1_ (u"ࠩࠣࠫ烔")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭烕"),l11ll1_l1_ (u"ࠫࠥ࠭烖"))
	message = l11ll1_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ烗")+l1ll1l1lll11_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭烘")+mode+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ烙")+l1ll1l1l1llll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ烚")
LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ烛"),LOGGING(script_name)+message)
l1l1lll1lll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ烜"))
l1111111l11_l1_ = True if l1l1lll1lll1_l1_==l11llll11ll_l1_ else False
if not l1111111l11_l1_ and l1ll111111ll_l1_ in [235,715]:
	l1lll111llll_l1_ = str(l1ll1ll1l1l_l1_[l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ烝")])
	script_name = l11ll1_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ烞") if l1ll111111ll_l1_==235 else l11ll1_l1_ (u"࠭࡭࠴ࡷࠪ烟")
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࠫ烠")+script_name+l11ll1_l1_ (u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭烡")+l1lll111llll_l1_)
	l11l11l111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࠭烢")+script_name+l11ll1_l1_ (u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭烣")+l1lll111llll_l1_)
	if l111llll11_l1_ or l11l11l111_l1_:
		url += l11ll1_l1_ (u"ࠫࢁ࠭烤")
		if l111llll11_l1_: url += l11ll1_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ烥")+l111llll11_l1_
		if l11l11l111_l1_: url += l11ll1_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ烦")+l11l11l111_l1_
		url = url.replace(l11ll1_l1_ (u"ࠧࡽࠨࠪ烧"),l11ll1_l1_ (u"ࠨࡾࠪ烨"))
	l1111l1l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࠭烩")+script_name+l11ll1_l1_ (u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ烪")+l1lll111llll_l1_)
	if l1111l1l1l_l1_:
		l1l11111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ烫"),url,re.DOTALL)
		url = url.replace(l1l11111l1l1_l1_[0],l1111l1l1l_l1_)
	script_name = script_name.upper()
	l1l11l11l1l_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1llllll11ll_l1_ = l11ll1_l1_ (u"ࠬ࠭烬")
	l1ll111l1_l1_(l11ll1_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ热"))
	try: l1llll1111l1_l1_(l1ll1111ll1_l1_,l1ll1l1lll11_l1_)
	except Exception as error: l1llllll11ll_l1_ = traceback.format_exc()
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠧࡴࡶࡲࡴࠬ烮"))
	l1ll111l1lll_l1_(l1llllll11ll_l1_)
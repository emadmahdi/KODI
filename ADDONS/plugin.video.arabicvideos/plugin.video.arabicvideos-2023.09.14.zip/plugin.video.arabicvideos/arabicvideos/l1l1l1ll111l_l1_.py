# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫ佫")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡒࡓࡕࡡࠪ佬")
l11ll1111l11_l1_ = 5
l11l1llll111_l1_ = 10
def MAIN(mode,url,text,l1l1111_l1_,l1ll1ll1l1l_l1_):
	try: l1lll111llll_l1_ = str(l1ll1ll1l1l_l1_[l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佭")])
	except: l1lll111llll_l1_ = l11ll1_l1_ (u"࠭ࠧ佮")
	if   mode==160: results = MENU()
	elif mode==161: results = l11ll11l111l_l1_(text)
	elif mode==162: results = l11l1ll1ll11_l1_(text,162)
	elif mode==163: results = l11l1ll1ll11_l1_(text,163)
	elif mode==164: results = l11ll111llll_l1_(text)
	elif mode==165: results = l11ll11111ll_l1_(l1lll111llll_l1_,text,l1l1111_l1_)
	elif mode==166: results = l11ll111l111_l1_(url,text)
	elif mode==167: results = l11l1ll111l1_l1_(url,text)
	elif mode==168: results = l11l1l1l1lll_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ佯"),l11ll1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆࠡ฻ื์ฬฬ๊สࠩ佰"),l11ll1_l1_ (u"ࠩࠪ佱"),161,l11ll1_l1_ (u"ࠪࠫ佲"),l11ll1_l1_ (u"ࠫࠬ佳"),l11ll1_l1_ (u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ佴"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭併"),l11ll1_l1_ (u"ࠧใี่ࠤ฾ฺ่ศศํࠫ佶"),l11ll1_l1_ (u"ࠨࠩ佷"),162,l11ll1_l1_ (u"ࠩࠪ佸"),l11ll1_l1_ (u"ࠪࠫ佹"),l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ佺"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佻"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩ佼"),l11ll1_l1_ (u"ࠧࠨ佽"),163,l11ll1_l1_ (u"ࠨࠩ佾"),l11ll1_l1_ (u"ࠩࠪ使"),l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ侀"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侁"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํࠫ侂"),l11ll1_l1_ (u"࠭ࠧ侃"),164,l11ll1_l1_ (u"ࠧࠨ侄"),l11ll1_l1_ (u"ࠨࠩ侅"),l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ來"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侇"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ侈"),l11ll1_l1_ (u"ࠬ࠭侉"),165,l11ll1_l1_ (u"࠭ࠧ侊"),l11ll1_l1_ (u"ࠧࠨ例"),l11ll1_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ侌"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ侍"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ侎"),l11ll1_l1_ (u"ࠫࠬ侏"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侐"),l11ll1_l1_ (u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ侑"),l11ll1_l1_ (u"ࠧࠨ侒"),163,l11ll1_l1_ (u"ࠨࠩ侓"),l11ll1_l1_ (u"ࠩࠪ侔"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ侕"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侖"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ侗"),l11ll1_l1_ (u"࠭ࠧ侘"),163,l11ll1_l1_ (u"ࠧࠨ侙"),l11ll1_l1_ (u"ࠨࠩ侚"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ供"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侜"),l11ll1_l1_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ依"),l11ll1_l1_ (u"ࠬ࠭侞"),162,l11ll1_l1_ (u"࠭ࠧ侟"),l11ll1_l1_ (u"ࠧࠨ侠"),l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ価"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侢"),l11ll1_l1_ (u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ侣"),l11ll1_l1_ (u"ࠫࠬ侤"),162,l11ll1_l1_ (u"ࠬ࠭侥"),l11ll1_l1_ (u"࠭ࠧ侦"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ侧"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侨"),l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡสะฯࠥ฿ิ้ษษ๎ࠬ侩"),l11ll1_l1_ (u"ࠪࠫ侪"),164,l11ll1_l1_ (u"ࠫࠬ侫"),l11ll1_l1_ (u"ࠬ࠭侬"),l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ侭"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侮"),l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ侯"),l11ll1_l1_ (u"ࠩࠪ侰"),165,l11ll1_l1_ (u"ࠪࠫ侱"),l11ll1_l1_ (u"ࠫࠬ侲"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ侳"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ侴"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ侵"),l11ll1_l1_ (u"ࠨࠩ侶"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侷"),l11ll1_l1_ (u"ࠪๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ侸"),l11ll1_l1_ (u"ࠫࠬ侹"),163,l11ll1_l1_ (u"ࠬ࠭侺"),l11ll1_l1_ (u"࠭ࠧ侻"),l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ侼"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侽"),l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ侾"),l11ll1_l1_ (u"ࠪࠫ便"),163,l11ll1_l1_ (u"ࠫࠬ俀"),l11ll1_l1_ (u"ࠬ࠭俁"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ係"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ促"),l11ll1_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ俄"),l11ll1_l1_ (u"ࠩࠪ俅"),162,l11ll1_l1_ (u"ࠪࠫ俆"),l11ll1_l1_ (u"ࠫࠬ俇"),l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ俈"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俉"),l11ll1_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ俊"),l11ll1_l1_ (u"ࠨࠩ俋"),162,l11ll1_l1_ (u"ࠩࠪ俌"),l11ll1_l1_ (u"ࠪࠫ俍"),l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ俎"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俏"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘ࡛ࠦศฮอࠣ฽ู๎วว์ࠪ俐"),l11ll1_l1_ (u"ࠧࠨ俑"),164,l11ll1_l1_ (u"ࠨࠩ俒"),l11ll1_l1_ (u"ࠩࠪ俓"),l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ俔"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ俕"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭俖"),l11ll1_l1_ (u"࠭ࠧ俗"),165,l11ll1_l1_ (u"ࠧࠨ俘"),l11ll1_l1_ (u"ࠨࠩ俙"),l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俚"))
	return
def l11ll11l111l_l1_(options):
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俛"),l11ll1_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ俜"),l11ll1_l1_ (u"ࠬ࠭保"),161,l11ll1_l1_ (u"࠭ࠧ俞"),l11ll1_l1_ (u"ࠧࠨ俟"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ俠"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ信"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ俢"),l11ll1_l1_ (u"ࠫࠬ俣"),9999)
	l1l1ll1l1111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俤"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢ࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ俥")+l11ll1_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ俦"),l11ll1_l1_ (u"ࠨࠩ俧"),147)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俨"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ俩")+l11ll1_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭俪"),l11ll1_l1_ (u"ࠬ࠭俫"),148)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俬"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ俭")+l11ll1_l1_ (u"ࠨไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠪ修"),l11ll1_l1_ (u"ࠩࠪ俯"),28)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ俰"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ俱")+l11ll1_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ俲"),l11ll1_l1_ (u"࠭ࠧ俳"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ俴"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ俵")+l11ll1_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ俶"),l11ll1_l1_ (u"ࠪࠫ俷"),135)
	import l1lll11l11ll_l1_
	l1lll11l11ll_l1_.ITEMS(l11ll1_l1_ (u"ࠫ࠵࠭俸"),False)
	l1lll11l11ll_l1_.ITEMS(l11ll1_l1_ (u"ࠬ࠷ࠧ俹"),False)
	l1lll11l11ll_l1_.ITEMS(l11ll1_l1_ (u"࠭࠲ࠨ俺"),False)
	#l1lll11l11ll_l1_.ITEMS(l11ll1_l1_ (u"ࠧ࠴ࠩ俻"),False)
	if l11ll1_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ俼") in options:
		menuItemsLIST[:] = l11l1ll1llll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11ll1111l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11ll1111l11_l1_)
	menuItemsLIST[:] = l1l1ll1l1111_l1_+menuItemsLIST
	return
def l11ll111llll_l1_(options):
	options = options.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俽"),l11ll1_l1_ (u"ࠪࠫ俾")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俿"),l11ll1_l1_ (u"ࠬ࠭倀"))
	headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ倁") : l11ll1_l1_ (u"ࠧࠨ倂") }
	url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ倃")
	payload = { l11ll1_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ倄") : l11ll1_l1_ (u"ࠪ࠹࠵࠭倅") }
	data = l1ll1l11l_l1_(payload)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ倆"),l11ll1_l1_ (u"ࠬ࠭倇"),l11ll1_l1_ (u"࠭ࠧ倈"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ倉"),url,data,headers,l11ll1_l1_ (u"ࠨࠩ倊"),l11ll1_l1_ (u"ࠩࠪ個"),l11ll1_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖ࠱ࡗࡇࡎࡅࡑࡐࡣ࡛ࡏࡄࡆࡑࡖࡣࡋࡘࡏࡎࡡ࡚ࡓࡗࡊࡓ࠮࠳ࡶࡸࠬ倌"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭倍"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ倎"),block,re.DOTALL)
	l11l1l1l1l11_l1_,l11l1ll11111_l1_ = list(zip(*items))
	l11ll111l1l1_l1_ = []
	l11ll111lll1_l1_ = [l11ll1_l1_ (u"࠭ࠠࠨ倏"),l11ll1_l1_ (u"ࠧࠣࠩ倐"),l11ll1_l1_ (u"ࠨࡢࠪ們"),l11ll1_l1_ (u"ࠩ࠯ࠫ倒"),l11ll1_l1_ (u"ࠪ࠲ࠬ倓"),l11ll1_l1_ (u"ࠫ࠿࠭倔"),l11ll1_l1_ (u"ࠬࡁࠧ倕"),l11ll1_l1_ (u"ࠨࠧࠣ倖"),l11ll1_l1_ (u"ࠧ࠮ࠩ倗")]
	l11ll111111l_l1_ = l11l1ll11111_l1_+l11l1l1l1l11_l1_
	for word in l11ll111111l_l1_:
		if word in l11l1ll11111_l1_: l11l1llll1ll_l1_ = 2
		if word in l11l1l1l1l11_l1_: l11l1llll1ll_l1_ = 4
		l11ll111l1ll_l1_ = [i in word for i in l11ll111lll1_l1_]
		if any(l11ll111l1ll_l1_):
			index = l11ll111l1ll_l1_.index(True)
			l11l1ll11l1l_l1_ = l11ll111lll1_l1_[index]
			l11ll1111ll1_l1_ = l11ll1_l1_ (u"ࠨࠩ倘")
			if word.count(l11l1ll11l1l_l1_)>1: l11ll1111lll_l1_,l11ll1111l1l_l1_,l11ll1111ll1_l1_ = word.split(l11l1ll11l1l_l1_,2)
			else: l11ll1111lll_l1_,l11ll1111l1l_l1_ = word.split(l11l1ll11l1l_l1_,1)
			if len(l11ll1111lll_l1_)>l11l1llll1ll_l1_: l11ll111l1l1_l1_.append(l11ll1111lll_l1_.lower())
			if len(l11ll1111l1l_l1_)>l11l1llll1ll_l1_: l11ll111l1l1_l1_.append(l11ll1111l1l_l1_.lower())
			if len(l11ll1111ll1_l1_)>l11l1llll1ll_l1_: l11ll111l1l1_l1_.append(l11ll1111ll1_l1_.lower())
		elif len(word)>l11l1llll1ll_l1_: l11ll111l1l1_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11ll111l1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll111l1l1_l1_)),l11ll111l1l1_l1_)
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ候")
	if l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ倚") in options:
		l11l1lll11ll_l1_ = l1l1lllllll1_l1_
	elif l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ倛") in options:
		l11l1lll11ll_l1_ = [l11ll1_l1_ (u"ࠬࡏࡐࡕࡘࠪ倜")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"࠭ࠧ倝"),True): return
	elif l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭倞") in options:
		l11l1lll11ll_l1_ = [l11ll1_l1_ (u"ࠨࡏ࠶࡙ࠬ借")]
		import l1l1l111ll1l_l1_
		if not l1l1l111ll1l_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠩࠪ倠"),True): return
	count,l11l1l1l1l1l_l1_ = 0,0
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倡"),l11ll1_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦ࠺ࠡ࡝ࠣࠤࡢ࠭倢"),l11ll1_l1_ (u"ࠬ࠭倣"),164,l11ll1_l1_ (u"࠭ࠧ値"),l11ll1_l1_ (u"ࠧࠨ倥"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倦")+options)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ倧"),l11ll1_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ倨"),l11ll1_l1_ (u"ࠫࠬ倩"),164,l11ll1_l1_ (u"ࠬ࠭倪"),l11ll1_l1_ (u"࠭ࠧ倫"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倬")+options)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭倭"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倮"),l11ll1_l1_ (u"ࠪࠫ倯"),9999)
	l11l1l1l11ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11ll111ll1l_l1_ = []
	for word in l11ll111l1l1_l1_:
		l11ll1111l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࡠࠨࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩ倰"),word,re.DOTALL)
		if l11ll1111l1l_l1_: word = word.split(l11ll1111l1l_l1_[0],1)[0]
		l11ll1111111_l1_ = word.replace(l11ll1_l1_ (u"ࠬ๗ࠧ倱"),l11ll1_l1_ (u"࠭ࠧ倲")).replace(l11ll1_l1_ (u"ࠧ๏ࠩ倳"),l11ll1_l1_ (u"ࠨࠩ倴")).replace(l11ll1_l1_ (u"ࠩ๎ࠫ倵"),l11ll1_l1_ (u"ࠪࠫ倶")).replace(l11ll1_l1_ (u"ࠫ๔࠭倷"),l11ll1_l1_ (u"ࠬ࠭倸")).replace(l11ll1_l1_ (u"࠭์ࠨ倹"),l11ll1_l1_ (u"ࠧࠨ债"))
		l11ll1111111_l1_ = l11ll1111111_l1_.replace(l11ll1_l1_ (u"ࠨ๒ࠪ倻"),l11ll1_l1_ (u"ࠩࠪ值")).replace(l11ll1_l1_ (u"ࠪ๑ࠬ倽"),l11ll1_l1_ (u"ࠫࠬ倾")).replace(l11ll1_l1_ (u"ࠬ๘ࠧ倿"),l11ll1_l1_ (u"࠭ࠧ偀")).replace(l11ll1_l1_ (u"ࠧญࠩ偁"),l11ll1_l1_ (u"ࠨࠩ偂")).replace(l11ll1_l1_ (u"ࠩใࠫ偃"),l11ll1_l1_ (u"ࠪࠫ偄"))
		if l11ll1111111_l1_: l11ll111ll1l_l1_.append(l11ll1111111_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll111ll1l_l1_)),l11ll111ll1l_l1_)
	l11l1llllll1_l1_ = []
	for l11ll1111l_l1_ in range(0,20):
		search = random.sample(l11ll111ll1l_l1_,1)[0]
		if search in l11l1llllll1_l1_: continue
		l11l1llllll1_l1_.append(search)
		l1ll111l11l_l1_ = random.sample(l11l1lll11ll_l1_,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ偅"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡘ࡬ࡨࡪࡵࠠࡔࡧࡤࡶࡨ࡮ࠠࠡࠢࡶ࡭ࡹ࡫࠺ࠨ偆")+str(l1ll111l11l_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࡵࡨࡥࡷࡩࡨ࠻ࠩ假")+search)
		#results = l1l1ll1l1ll1_l1_(l11ll1_l1_ (u"ࠧࠨ偈"),l11ll1_l1_ (u"ࠨࠩ偉"),l11ll1_l1_ (u"ࠩࠪ偊"),l1ll111l11l_l1_,l11ll1_l1_ (u"ࠪࠫ偋"),l11ll1_l1_ (u"ࠫࠬ偌"),search+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ偍"),l11ll1_l1_ (u"࠭ࠧ偎"),l11ll1_l1_ (u"ࠧࠨ偏"))
		l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_ = l1l1lllll11_l1_(l1ll111l11l_l1_)
		l1ll111l111_l1_(search+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭偐"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ偑"),l11ll1_l1_ (u"ࠪࠫ偒"))
	l11l1l1l11ll_l1_[0][1] = l11ll1_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ偓")+search+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆหัะูࠦ็ࠢ࠽ࠤࡠࠦࠧ偔")
	menuItemsLIST[:] = l11l1ll1llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11ll1111l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11ll1111l11_l1_)
	menuItemsLIST[:] = l11l1l1l11ll_l1_+menuItemsLIST
	#import l1lll11lll1_l1_
	#l1lll11lll1_l1_.SEARCH(search)
	return
def l11ll111ll11_l1_(l1ll111l11l_l1_):
	l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_ = l1l1lllll11_l1_(l1ll111l11l_l1_)
	try:
		if l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ偕") in l1ll111l11l_l1_: l1ll1111111_l1_(l1ll111l11l_l1_)
		else: l1ll1111111_l1_()
		l11l1lllll1l_l1_ = False
	except: l11l1lllll1l_l1_ = True
	l1ll111l11l_l1_ = TRANSLATE(l1ll111l11l_l1_)
	if l11l1lllll1l_l1_: DIALOG_NOTIFICATION(l1ll111l11l_l1_,l11ll1_l1_ (u"ࠧโึ็ࠤอํะศࠢส่๊๎โฺࠩ偖"),time=2000)
	else: DIALOG_NOTIFICATION(l1ll111l11l_l1_,l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡษ็ว็ูวๆࠩ偗"),time=2000)
	return l11l1lllll1l_l1_
def l11l1l1ll1l1_l1_(l11l1llll11l_l1_=True):
	if not l11l1llll11l_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ偘"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭偙"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ做"))
		if results:
			contentsDICT = results
			return
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ偛"),l11ll1_l1_ (u"࠭ࠧ停"),l11ll1_l1_ (u"ࠧࠨ偝"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ偞"),l11ll1_l1_ (u"ࠩ็็๏ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱ࠤฬ๊ศา่ส้ั๊ࠦฮฬสะࠥษๆࠡ์ไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠๅๅํࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱ࠤะ๋๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะี๊ࠥํะ่ࠢส่ศ่ำศ็ࠣัฯ๏ࠠๅษࠣฮาะวอࠢฦ๊ࠥะๅๅศ๊ห๋ࠥัสࠢฦาึ๏ࠠ࠯ࠢ฼้้๐ษࠡ็็สࠥาๅ๋฻ࠣห้ษโิษ่ࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࠱ࠤ์๊ࠠหำํำࠥษๆࠡฬฯ้฾ࠦโศศ่อࠥอไฤไึห๊ࠦวๅฤ้ࠤฤ࠭偟"))
	if l1ll111lll_l1_!=1: return
	l11l1l1lll11_l1_ = menuItemsLIST[:]
	l11l1lll11l1_l1_,l11l1lll1111_l1_ = 0,l11ll1_l1_ (u"ࠪࠫ偠")
	for l1ll111l11l_l1_ in l11ll1ll11l_l1_:
		l11l1lllll1l_l1_ = l11ll111ll11_l1_(l1ll111l11l_l1_)
		if l11l1lllll1l_l1_:
			l11l1lll11l1_l1_ += 1
			l11l1lll1111_l1_ += l11ll1_l1_ (u"ࠫࠥ࠭偡")+l1ll111l11l_l1_
			if l11l1lll11l1_l1_>=l11l1llll111_l1_: break
	menuItemsLIST[:] = l11l1l1lll11_l1_
	if l11l1lll11l1_l1_>=l11l1llll111_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭偢"),l11ll1_l1_ (u"࠭ࠧ偣"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ偤"),l11ll1_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡࠩ健")+str(l11l1lll11l1_l1_)+l11ll1_l1_ (u"้ࠩࠣํอโฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์ุฮศ่ษࠣๆิ๊ࠦไ๊้ࠤ฾ีๅ๊ࠡฯ์ิࠦล็ฬิ๊๏ะࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࡀࠧ偦")+l11l1lll1111_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭偧"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ偨"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭偩"),l11ll1_l1_ (u"࠭ࠧ偪"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ偫"),l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧ偬"))
	return
def l11l1ll1l1l1_l1_(l1lll111llll_l1_,options):
	if l11ll1_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ偭") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ偮"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ偯"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭偰")+l1lll111llll_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ偱")
	import IPTV
	if l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ偲") in options and l11ll1_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ偳") not in options:
		try: IPTV.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ側"),l11ll1_l1_ (u"ࠪࠫ偵"),l11ll1_l1_ (u"ࠫࠬ偶"),options+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ偷"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ偸"),l11ll1_l1_ (u"ࠧࠨ偹"),l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ偺"),message)
		try: IPTV.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ偻"),l11ll1_l1_ (u"ࠪࠫ偼"),l11ll1_l1_ (u"ࠫࠬ偽"),options+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ偾"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ偿"),l11ll1_l1_ (u"ࠧࠨ傀"),l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ傁"),message)
		try: IPTV.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ傂"),l11ll1_l1_ (u"ࠪࠫ傃"),l11ll1_l1_ (u"ࠫࠬ傄"),options+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ傅"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ傆"),l11ll1_l1_ (u"ࠧࠨ傇"),l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ傈"),message)
	if l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ傉") in options and l11ll1_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ傊") not in options:
		try: IPTV.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ傋"),l11ll1_l1_ (u"ࠬ࠭傌"),l11ll1_l1_ (u"࠭ࠧ傍"),options+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ傎"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ傏"),l11ll1_l1_ (u"ࠩࠪ傐"),l11ll1_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ傑"),message)
		try: IPTV.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ傒"),l11ll1_l1_ (u"ࠬ࠭傓"),l11ll1_l1_ (u"࠭ࠧ傔"),options+l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ傕"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ傖"),l11ll1_l1_ (u"ࠩࠪ傗"),l11ll1_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ傘"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ備"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭傚")+l1lll111llll_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11l1lll1ll1_l1_(l1lll111llll_l1_,options):
	if l11ll1_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ傛") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ傜"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ傝"),l11ll1_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ傞")+l1lll111llll_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ傟")
	import l1l1l111ll1l_l1_
	if l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ傠") in options and l11ll1_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ傡") not in options:
		try: l1l1l111ll1l_l1_.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ傢"),l11ll1_l1_ (u"ࠧࠨ傣"),l11ll1_l1_ (u"ࠨࠩ傤"),options+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傥"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ傦"),l11ll1_l1_ (u"ࠫࠬ傧"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ储"),message)
		try: l1l1l111ll1l_l1_.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ傩"),l11ll1_l1_ (u"ࠧࠨ傪"),l11ll1_l1_ (u"ࠨࠩ傫"),options+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ催"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ傭"),l11ll1_l1_ (u"ࠫࠬ傮"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ傯"),message)
		try: l1l1l111ll1l_l1_.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ傰"),l11ll1_l1_ (u"ࠧࠨ傱"),l11ll1_l1_ (u"ࠨࠩ傲"),options+l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傳"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ傴"),l11ll1_l1_ (u"ࠫࠬ債"),l11ll1_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ傶"),message)
	if l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ傷") in options and l11ll1_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭傸") not in options:
		try: l1l1l111ll1l_l1_.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ傹"),l11ll1_l1_ (u"ࠩࠪ傺"),l11ll1_l1_ (u"ࠪࠫ傻"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傼"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭傽"),l11ll1_l1_ (u"࠭ࠧ傾"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ傿"),message)
		try: l1l1l111ll1l_l1_.GROUPS(l1lll111llll_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ僀"),l11ll1_l1_ (u"ࠩࠪ僁"),l11ll1_l1_ (u"ࠪࠫ僂"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ僃"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭僄"),l11ll1_l1_ (u"࠭ࠧ僅"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ僆"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ僇"),l11ll1_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ僈")+l1lll111llll_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11ll11111ll_l1_(l1lll111llll_l1_,options,l11l1ll11l11_l1_):
	if l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ僉") in options:
		if l11ll1_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ僊") in options and l11l1ll11l11_l1_==l11ll1_l1_ (u"ࠬ࠭僋"): l11l1l1ll1l1_l1_(True)
		elif l11l1ll11l11_l1_: l11l1l1ll1l1_l1_(False)
		#if contentsDICT=={}: return
	l11l1llll1l1_l1_ = options.replace(l11ll1_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ僌"),l11ll1_l1_ (u"ࠧࠨ働")).replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ僎"),l11ll1_l1_ (u"ࠩࠪ像")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ僐"),l11ll1_l1_ (u"ࠫࠬ僑"))
	if not l11l1ll11l11_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ僒"),l11ll1_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ僓"),l11ll1_l1_ (u"ࠧࠨ僔"),165,l11ll1_l1_ (u"ࠨࠩ僕"),l11ll1_l1_ (u"ࠩࠪ僖"),l11ll1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ僗")+l11l1llll1l1_l1_,l11ll1_l1_ (u"ࠫࠬ僘"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僙"):l1lll111llll_l1_})
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ僚"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ僛"),l11ll1_l1_ (u"ࠨࠩ僜"),9999)
	if l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ僝") in options:
		l1ll1l111l_l1_ = [l11ll1_l1_ (u"ࠪวๆ๊วๆࠩ僞"),l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠬ僟"),l11ll1_l1_ (u"๋ࠬำาฯํหฯ࠭僠"),l11ll1_l1_ (u"࠭ศาษ่ะࠬ僡"),l11ll1_l1_ (u"ࠧฤูไห้่ࠦไำอ์๋࠭僢"),l11ll1_l1_ (u"ࠨำฺ่ฬ์ࠧ僣"),l11ll1_l1_ (u"ࠩฦัิั࠭ฤะิࠫ僤"),l11ll1_l1_ (u"ࠪื้อำๅࠩ僥"),l11ll1_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ僦"),l11ll1_l1_ (u"ࠬษิ่ำ࠰ว่ััࠨ僧"),l11ll1_l1_ (u"࠭วๅฤ้ࠫ僨"),l11ll1_l1_ (u"ࠧืฯๆࠫ僩"),l11ll1_l1_ (u"ࠨำํห฻ฯࠧ僪"),l11ll1_l1_ (u"้ࠩ๎ฯ็ไไีࠪ僫"),l11ll1_l1_ (u"้๊ࠪัไ๋่ࠪ僬"),l11ll1_l1_ (u"ࠫอัࠠฮ์ࠪ僭"),l11ll1_l1_ (u"ࠬี๊็์ฬࠫ僮"),l11ll1_l1_ (u"࠭ำ็๊สฮࠬ僯"),l11ll1_l1_ (u"ࠧฤะิํࠬ僰")]
		l11l1l1lll1l_l1_ = [l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠧ僱"),l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ僲"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ僳"),l11ll1_l1_ (u"ࠫๆ๊ๅࠨ僴")]
		l11l1ll11lll_l1_ = [l11ll1_l1_ (u"๋ࠬำๅี็ࠫ僵"),l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭僶")]
		l11ll11l1111_l1_ = [l11ll1_l1_ (u"ࠧๆีสีา࠭僷"),l11ll1_l1_ (u"ࠨ็ึีา๐วหࠩ僸")]
		l11l1ll11ll1_l1_ = [l11ll1_l1_ (u"ࠩหีฬ๋ฬࠨ價"),l11ll1_l1_ (u"ࠪࡷ࡭ࡵࡷࠨ僺"),l11ll1_l1_ (u"ࠫฯ๊แำ์๋๊ࠬ僻"),l11ll1_l1_ (u"ࠬะไ๋ใี๎ํ์ࠧ僼")]
		l11l1lllllll_l1_ = [l11ll1_l1_ (u"࠭ว็็ํࠫ僽"),l11ll1_l1_ (u"ࠧไำอ์๋࠭僾"),l11ll1_l1_ (u"ࠨๅสีฯ๎ๆࠨ僿"),l11ll1_l1_ (u"ࠩ࡮࡭ࡩࡹࠧ儀"),l11ll1_l1_ (u"ࠪ฻ๆ๊ࠧ儁"),l11ll1_l1_ (u"ࠫฬ฽แศๆࠪ儂")]
		l1111ll1_l1_ = [l11ll1_l1_ (u"ࠬืๅืษ้ࠫ儃")]
		l1llll1ll_l1_ = [l11ll1_l1_ (u"࠭วฮัฮࠫ億"),l11ll1_l1_ (u"ࠧศะิࠫ儅"),l11ll1_l1_ (u"ࠨ็๋าึ࠭儆"),l11ll1_l1_ (u"ࠩฯำ๏ีࠧ儇"),l11ll1_l1_ (u"้ࠪ฻อแࠨ儈"),l11ll1_l1_ (u"ࠫาี๊ฬࠩ儉")]
		l11l1ll1l1ll_l1_ = [l11ll1_l1_ (u"ูࠬไศี็ࠫ儊"),l11ll1_l1_ (u"࠭ำๅี็๋ࠬ儋")]
		l11l1l1l1ll1_l1_ = [l11ll1_l1_ (u"ࠧศ฼ส๊๏࠭儌"),l11ll1_l1_ (u"ࠨ็๋ื๏่้ࠨ儍"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧ儎"),l11ll1_l1_ (u"ࠪัๆ๊ࠧ儏"),l11ll1_l1_ (u"ࠫࡲࡻࡳࡪࡥࠪ儐")]
		l111111l1_l1_ = [l11ll1_l1_ (u"ࠬอใฬำࠪ儑"),l11ll1_l1_ (u"࠭วี้ิࠫ儒"),l11ll1_l1_ (u"ࠧๆ็ํึ์࠭儓"),l11ll1_l1_ (u"ࠨษ฼่๎࠭儔"),l11ll1_l1_ (u"่ࠩาฯอั่ࠩ儕"),l11ll1_l1_ (u"้ࠪำะวาษอࠫ儖"),l11ll1_l1_ (u"ࠫฬ่่๊ࠩ儗")]
		l11l1l1ll1ll_l1_ = [l11ll1_l1_ (u"ࠬอไศ่ࠪ儘"),l11ll1_l1_ (u"࠭อศๆํࠫ儙"),l11ll1_l1_ (u"ࠧๆอหฮࠬ儚"),l11ll1_l1_ (u"ࠨำสสั࠭儛")]
		l11l1l1ll11l_l1_ = [l11ll1_l1_ (u"ูࠩั่࠭儜"),l11ll1_l1_ (u"ࠪ็ํ๋๊ะ์ࠪ儝")]
		l11l1l1llll1_l1_ = [l11ll1_l1_ (u"ࠫึ๐วื้ࠪ儞"),l11ll1_l1_ (u"้่ࠬา้ࠪ償"),l11ll1_l1_ (u"࠭ๅึษิ฽์࠭儠"),l11ll1_l1_ (u"ࠧี๊อࠫ儡"),l11ll1_l1_ (u"ࠨำํห฻ฯࠧ儢")]
		l11l1lllll11_l1_ = [l11ll1_l1_ (u"้ࠩ๎ฯ็ไไีࠪ儣"),l11ll1_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫ儤"),l11ll1_l1_ (u"๋ࠫ๐สโๆํ็ุ࠭儥")]
		l11l1lll1l1l_l1_ = [l11ll1_l1_ (u"๋ࠬๅฬๆํ๊ࠬ儦"),l11ll1_l1_ (u"࠭วีะสูࠬ儧"),l11ll1_l1_ (u"ࠧ็ฮ๋้ࠬ儨")]
		l1l1ll1ll_l1_ = [l11ll1_l1_ (u"ࠨสฮࠤา๐ࠧ儩"),l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ優"),l11ll1_l1_ (u"ࠪๆ๋อ็ࠨ儫"),l11ll1_l1_ (u"ࠫ็์่ศฬࠪ儬")]
		l11l1lll1lll_l1_ = [l11ll1_l1_ (u"ࠬี๊็ࠩ儭"),l11ll1_l1_ (u"࠭วะ฻ํ๋ࠬ儮"),l11ll1_l1_ (u"ࠧำ์สีฬะࠧ儯"),l11ll1_l1_ (u"ࠨๆฺ้๏อสࠨ儰"),l11ll1_l1_ (u"ࠩา฽ฬวࠧ儱"),l11ll1_l1_ (u"ࠪๆึอๆࠨ儲"),l11ll1_l1_ (u"ࠫ็฻ววัࠪ儳"),l11ll1_l1_ (u"ࠬืหศรࠪ儴"),l11ll1_l1_ (u"࠭ๅาฮ฼๎์࠭儵"),l11ll1_l1_ (u"ࠧศาส๊ࠬ儶"),l11ll1_l1_ (u"ࠨษึ่ฬ๋ࠧ儷"),l11ll1_l1_ (u"ࠩอ์ฬฺ๊ฮࠩ儸"),l11ll1_l1_ (u"ࠪา฼ฮࠧ儹"),l11ll1_l1_ (u"ࠫา๎า้์ࠪ儺"),l11ll1_l1_ (u"ࠬ฿สษษอࠫ儻"),l11ll1_l1_ (u"࠭ๅ้ษ็๎ิ࠭儼"),l11ll1_l1_ (u"ࠧ็๊ส฽๏࠭儽"),l11ll1_l1_ (u"ࠨ฻ๅหหีࠧ儾"),l11ll1_l1_ (u"ࠩส๊ฬฺ๊ะࠩ儿")]
		l11ll11111l1_l1_ = [l11ll1_l1_ (u"ࠪ࠵࠾࠭兀"),l11ll1_l1_ (u"ࠫ࠷࠶ࠧ允"),l11ll1_l1_ (u"ࠬ࠸࠱ࠨ兂"),l11ll1_l1_ (u"࠭࠲࠳ࠩ元"),l11ll1_l1_ (u"ࠧ࠳࠵ࠪ兄"),l11ll1_l1_ (u"ࠨ࠴࠷ࠫ充"),l11ll1_l1_ (u"ࠩ࠵࠹ࠬ兆"),l11ll1_l1_ (u"ࠪ࠶࠻࠭兇")]
		if not l11l1ll11l11_l1_:
			l11l1ll11l11_l1_ = 0
			for l11l1lll1l11_l1_ in l1ll1l111l_l1_:
				l11l1ll11l11_l1_ += 1
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ先"),l111l1_l1_+l11l1lll1l11_l1_,l11ll1_l1_ (u"ࠬ࠭光"),165,l11ll1_l1_ (u"࠭ࠧ兊"),str(l11l1ll11l11_l1_),l11l1llll1l1_l1_,l11ll1_l1_ (u"ࠧࠨ克"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ兌"):l1lll111llll_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1lll1ll_l1_ = name.lower()
				category = []
				if any(value in l1ll1lll1ll_l1_ for value in l11l1l1lll1l_l1_): category.append(1)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1ll11lll_l1_): category.append(2)
				if any(value in l1ll1lll1ll_l1_ for value in l11ll11l1111_l1_): category.append(3)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1ll11ll1_l1_): category.append(4)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1lllllll_l1_): category.append(5)
				if any(value in l1ll1lll1ll_l1_ for value in l1111ll1_l1_): category.append(6)
				if any(value in l1ll1lll1ll_l1_ for value in l1llll1ll_l1_) and l1ll1lll1ll_l1_ not in [l11ll1_l1_ (u"ࠩสาึ๏ࠧ免")]: category.append(7)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1ll1l1ll_l1_): category.append(8)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1l1l1ll1_l1_): category.append(9)
				if any(value in l1ll1lll1ll_l1_ for value in l111111l1_l1_): category.append(10)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1l1ll1ll_l1_): category.append(11)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1l1ll11l_l1_): category.append(12)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1l1llll1_l1_): category.append(13)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1lllll11_l1_): category.append(14)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1lll1l1l_l1_): category.append(15)
				if any(value in l1ll1lll1ll_l1_ for value in l1l1ll1ll_l1_): category.append(16)
				if any(value in l1ll1lll1ll_l1_ for value in l11l1lll1lll_l1_): category.append(17)
				if any(value in l1ll1lll1ll_l1_ for value in l11ll11111l1_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l11l1ll11l11_l1_:
						addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ兎"),l111l1_l1_+name,name,166,l11ll1_l1_ (u"ࠫࠬ兏"),l11ll1_l1_ (u"ࠬ࠭児"),l11l1llll1l1_l1_+l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ兑"))
	elif l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ兒") in options:
		import IPTV
		#if l11ll1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭兓") in options:
		l11l1l1ll111_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111llll_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1lll111llll_l1_,True): return
			l11l1ll1l1l1_l1_(l1lll111llll_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠩࠪ兔"),True): return
			for l1lll111llll_l1_ in range(FOLDERS_COUNT):
				l11l1ll1l1l1_l1_(str(l1lll111llll_l1_),options)
			#else: l11l1l1ll111_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1ll111_l1_+menuItemsLIST[:]
	elif l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ兕") in options:
		import l1l1l111ll1l_l1_
		#if l11ll1_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ兖") in options:
		l11l1l1ll111_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111llll_l1_:
			if not l1l1l111ll1l_l1_.CHECK_TABLES_EXIST(l1lll111llll_l1_,True): return
			l11l1lll1ll1_l1_(l1lll111llll_l1_,options)
		else:
			if not l1l1l111ll1l_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠬ࠭兗"),True): return
			for l1lll111llll_l1_ in range(FOLDERS_COUNT):
				l11l1lll1ll1_l1_(str(l1lll111llll_l1_),options)
			#else: l11l1l1ll111_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1ll111_l1_+menuItemsLIST[:]
	return
def l11ll111l111_l1_(l11l1ll111ll_l1_,options):
	l11l1ll111ll_l1_ = l11l1ll111ll_l1_.replace(l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ兘"),l11ll1_l1_ (u"ࠧࠨ兙"))
	options = options.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ党"),l11ll1_l1_ (u"ࠩࠪ兛")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ兜"),l11ll1_l1_ (u"ࠫࠬ兝"))
	l11l1l1ll1l1_l1_(False)
	if contentsDICT=={}: return
	if l11ll1_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ兞") in options:
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭兟"),l11ll1_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ兠")+l11l1ll111ll_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ兡"),l11l1ll111ll_l1_,166,l11ll1_l1_ (u"ࠩࠪ兢"),l11ll1_l1_ (u"ࠪࠫ兣"),l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ兤")+options)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ入"),l11ll1_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ兦"),l11l1ll111ll_l1_,166,l11ll1_l1_ (u"ࠧࠨ內"),l11ll1_l1_ (u"ࠨࠩ全"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ兩")+options)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ兪"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ八"),l11ll1_l1_ (u"ࠬ࠭公"),9999)
	for l1l1l1l1_l1_ in sorted(list(contentsDICT[l11l1ll111ll_l1_].keys())):
		type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ = contentsDICT[l11l1ll111ll_l1_][l1l1l1l1_l1_]
		if l11ll1_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ六") in options or len(contentsDICT[l11l1ll111ll_l1_])==1:
			l1l1ll1l1ll1_l1_(type,l11ll1_l1_ (u"ࠧࠨ兮"),url,l1ll11111l11_l1_,l11ll1_l1_ (u"ࠨࠩ兯"),l1l1111_l1_,text,l11ll1_l1_ (u"ࠩࠪ兰"),l11ll1_l1_ (u"ࠪࠫ共"))
			menuItemsLIST[:] = l11l1ll1llll_l1_(menuItemsLIST)
			l11l1l1ll111_l1_,l1llll11lll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1llll11lll_l1_)
			if l11ll1_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭兲") in options: menuItemsLIST[:] = l11l1l1ll111_l1_+l1llll11lll_l1_[:l11ll1111l11_l1_]
			else: menuItemsLIST[:] = l11l1l1ll111_l1_+l1llll11lll_l1_
		elif l11ll1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭关") in options: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭兴"),l1l1l1l1_l1_,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_)
	return
def l11l1ll1ll11_l1_(options,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ兵"),l11ll1_l1_ (u"ࠨࠩ其"),str(mode),options)
	options = options.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ具"),l11ll1_l1_ (u"ࠪࠫ典")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ兹"),l11ll1_l1_ (u"ࠬ࠭兺"))
	name,l11l1ll1l11l_l1_ = l11ll1_l1_ (u"࠭ࠧ养"),[]
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ兼"),l11ll1_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭兽")+name+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊โิ็ࠣ࠾ࠥࡡࠠࠨ兾"),l11ll1_l1_ (u"ࠪࠫ兿"),mode,l11ll1_l1_ (u"ࠫࠬ冀"),l11ll1_l1_ (u"ࠬ࠭冁"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ冂")+options)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冃"),l11ll1_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨ冄"),l11ll1_l1_ (u"ࠩࠪ内"),mode,l11ll1_l1_ (u"ࠪࠫ円"),l11ll1_l1_ (u"ࠫࠬ冇"),l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ冈")+options)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ冉"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ冊"),l11ll1_l1_ (u"ࠨࠩ冋"),9999)
	l11l1l1ll111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ册") in options:
		l11l1l1ll1l1_l1_(False)
		if contentsDICT=={}: return
		l11l1ll1lll1_l1_ = list(contentsDICT.keys())
		l11l1ll111ll_l1_ = random.sample(l11l1ll1lll1_l1_,1)[0]
		l11ll111l1l1_l1_ = list(contentsDICT[l11l1ll111ll_l1_].keys())
		l1l1l1l1_l1_ = random.sample(l11ll111l1l1_l1_,1)[0]
		type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ = contentsDICT[l11l1ll111ll_l1_][l1l1l1l1_l1_]
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ再"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧ冎")+l1l1l1l1_l1_+l11ll1_l1_ (u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ冏")+name+l11ll1_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ冐")+url+l11ll1_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ冑")+str(l1ll11111l11_l1_))
	elif l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ冒") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠩࠪ冓"),True): return
		for l1lll111llll_l1_ in range(FOLDERS_COUNT):
			l11l1ll1l1l1_l1_(str(l1lll111llll_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ冔"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ冕")+name+l11ll1_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ冖")+url+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ冗")+str(l1ll11111l11_l1_))
	elif l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭冘") in options:
		import l1l1l111ll1l_l1_
		if not l1l1l111ll1l_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠨࠩ写"),True): return
		for l1lll111llll_l1_ in range(FOLDERS_COUNT):
			l11l1lll1ll1_l1_(str(l1lll111llll_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ冚"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ军")+name+l11ll1_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭农")+url+l11ll1_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ冝")+str(l1ll11111l11_l1_))
	l11l1ll1l111_l1_ = name
	l11l1lll111l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭冞"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ冟")+name+l11ll1_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ冠")+url+l11ll1_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ冡")+str(l1ll11111l11_l1_))
		menuItemsLIST[:] = []
		if l1ll11111l11_l1_==234 and l11ll1_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ冢") in text: l1ll11111l11_l1_ = 233
		if l1ll11111l11_l1_==714 and l11ll1_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ冣") in text: l1ll11111l11_l1_ = 713
		if l1ll11111l11_l1_==144: l1ll11111l11_l1_ = 291
		html = l1l1ll1l1ll1_l1_(type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_)
		#if l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ冤") in html: l11l1ll1ll11_l1_(options,mode)
		if l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭冥") in options and l1ll11111l11_l1_==167: del menuItemsLIST[:3]
		if l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭冦") in options and l1ll11111l11_l1_==168: del menuItemsLIST[:3]
		l11l1ll1l11l_l1_[:] = l11l1ll1llll_l1_(menuItemsLIST)
		if l11l1lll111l_l1_ and l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡶࠩะ่็ฯࠧ冧")) in str(l11l1ll1l11l_l1_) or l1l1l1ll11l1_l1_(l11ll1_l1_ (u"ࡷࠪั้่็ࠨ冨")) in str(l11l1ll1l11l_l1_):
			name = l11l1ll1l111_l1_
			l11l1ll1l11l_l1_[:] = l11l1lll111l_l1_
			break
		l11l1ll1l111_l1_ = name
		l11l1lll111l_l1_ = l11l1ll1l11l_l1_[:]
		if str(l11l1ll1l11l_l1_).count(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ冩"))>0: break
		if str(l11l1ll1l11l_l1_).count(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ冪"))>0: break
		if l1ll11111l11_l1_==233: break	# iptv l111l1l1_l1_ names l11lll1ll1l_l1_ of l1l11_l1_ name
		if l1ll11111l11_l1_==713: break	# l11l1ll1111l_l1_ l111l1l1_l1_ names l11lll1ll1l_l1_ of l1l11_l1_ name
		if l1ll11111l11_l1_==291: break	# l1ll1ll1l_l1_ l11ll111l11l_l1_ names l11lll1ll1l_l1_ of l1ll1ll1l_l1_ l11ll111l11l_l1_ contents
		if l11l1ll1l11l_l1_: type,name,url,l1ll11111l11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ = random.sample(l11l1ll1l11l_l1_,1)[0]
	if not name: name = l11ll1_l1_ (u"ࠬ࠴࠮࠯࠰ࠪ冫")
	elif name.count(l11ll1_l1_ (u"࠭࡟ࠨ冬"))>1: name = name.split(l11ll1_l1_ (u"ࠧࡠࠩ冭"),2)[2]
	name = name.replace(l11ll1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫ冮"),l11ll1_l1_ (u"ࠩࠪ冯"))#.replace(l11ll1_l1_ (u"ࠪ࠰ࡒࡕࡖࡊࡇࡖ࠾ࠥ࠭冰"),l11ll1_l1_ (u"ࠫࠬ冱")).replace(l11ll1_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ冲"),l11ll1_l1_ (u"࠭ࠧ决")).replace(l11ll1_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ冴"),l11ll1_l1_ (u"ࠨࠩ况"))
	name = name.replace(l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ冶"),l11ll1_l1_ (u"ࠪࠫ冷"))
	l11l1l1ll111_l1_[0][1] = l11ll1_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ冸")+name+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ冹")
	for i in range(9): random.shuffle(l11l1ll1l11l_l1_)
	if l11ll1_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ冺") in options: menuItemsLIST[:] = l11l1l1ll111_l1_+l11l1ll1l11l_l1_[:l11ll1111l11_l1_]
	else: menuItemsLIST[:] = l11l1l1ll111_l1_+l11l1ll1l11l_l1_
	return
def l11l1ll111l1_l1_(l1l111111111_l1_,l1l1111llll1_l1_):
	l1l1111llll1_l1_ = l1l1111llll1_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ冻"),l11ll1_l1_ (u"ࠨࠩ冼")).replace(l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭冽"),l11ll1_l1_ (u"ࠪࠫ冾"))
	l11l1ll1ll1l_l1_ = l1l1111llll1_l1_
	if l11ll1_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ冿") in l1l1111llll1_l1_:
		l11l1ll1ll1l_l1_ = l1l1111llll1_l1_.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭净"))[0]
		type = l11ll1_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ凁")
	elif l11ll1_l1_ (u"ࠧࡗࡑࡇࠫ凂") in l1l111111111_l1_: type = l11ll1_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ凃")
	elif l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ凄") in l1l111111111_l1_: type = l11ll1_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ凅")
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ准"),l11ll1_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ凇")+type+l11l1ll1ll1l_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ凈"),l1l111111111_l1_,167,l11ll1_l1_ (u"ࠧࠨ凉"),l11ll1_l1_ (u"ࠨࠩ凊"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凋")+l1l1111llll1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ凌"),l11ll1_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ凍"),l1l111111111_l1_,167,l11ll1_l1_ (u"ࠬ࠭凎"),l11ll1_l1_ (u"࠭ࠧ减"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ凐")+l1l1111llll1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭凑"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ凒"),l11ll1_l1_ (u"ࠪࠫ凓"),9999)
	import IPTV
	for l1lll111llll_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ凔") in l1l1111llll1_l1_: IPTV.GROUPS(str(l1lll111llll_l1_),l1l111111111_l1_,l1l1111llll1_l1_,l11ll1_l1_ (u"ࠬ࠭凕"),False)
		else: IPTV.ITEMS(str(l1lll111llll_l1_),l1l111111111_l1_,l1l1111llll1_l1_,l11ll1_l1_ (u"࠭ࠧ凖"),False)
	menuItemsLIST[:] = l11l1ll1llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11ll1111l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11ll1111l11_l1_)
	return
def l11l1l1l1lll_l1_(l1l111111111_l1_,l1l1111llll1_l1_):
	l1l1111llll1_l1_ = l1l1111llll1_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ凗"),l11ll1_l1_ (u"ࠨࠩ凘")).replace(l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭凙"),l11ll1_l1_ (u"ࠪࠫ凚"))
	l11l1ll1ll1l_l1_ = l1l1111llll1_l1_
	if l11ll1_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ凛") in l1l1111llll1_l1_:
		l11l1ll1ll1l_l1_ = l1l1111llll1_l1_.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ凜"))[0]
		type = l11ll1_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ凝")
	elif l11ll1_l1_ (u"ࠧࡗࡑࡇࠫ凞") in l1l111111111_l1_: type = l11ll1_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ凟")
	elif l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ几") in l1l111111111_l1_: type = l11ll1_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ凡")
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ凢"),l11ll1_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ凣")+type+l11l1ll1ll1l_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ凤"),l1l111111111_l1_,168,l11ll1_l1_ (u"ࠧࠨ凥"),l11ll1_l1_ (u"ࠨࠩ処"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凧")+l1l1111llll1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ凨"),l11ll1_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ凩"),l1l111111111_l1_,168,l11ll1_l1_ (u"ࠬ࠭凪"),l11ll1_l1_ (u"࠭ࠧ凫"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ凬")+l1l1111llll1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭凭"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ凮"),l11ll1_l1_ (u"ࠪࠫ凯"),9999)
	import l1l1l111ll1l_l1_
	for l1lll111llll_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ凰") in l1l1111llll1_l1_: l1l1l111ll1l_l1_.GROUPS(str(l1lll111llll_l1_),l1l111111111_l1_,l1l1111llll1_l1_,l11ll1_l1_ (u"ࠬ࠭凱"),False)
		else: l1l1l111ll1l_l1_.ITEMS(str(l1lll111llll_l1_),l1l111111111_l1_,l1l1111llll1_l1_,l11ll1_l1_ (u"࠭ࠧ凲"),False)
	menuItemsLIST[:] = l11l1ll1llll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11ll1111l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11ll1111l11_l1_)
	return
def l11l1ll1llll_l1_(menuItemsLIST):
	l11l1ll1l11l_l1_ = []
	for type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_ in menuItemsLIST:
		if l11ll1_l1_ (u"ࠧึใะอࠬ凳") in name or l11ll1_l1_ (u"ࠨืไั์࠭凴") in name or l11ll1_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ凵") in name.lower(): continue
		l11l1ll1l11l_l1_.append([type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1lllll_l1_,l1ll1ll1l1l_l1_])
	return l11l1ll1l11l_l1_
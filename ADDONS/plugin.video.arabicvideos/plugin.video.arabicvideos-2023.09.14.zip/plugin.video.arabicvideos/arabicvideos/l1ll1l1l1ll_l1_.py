# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ⠸")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭⠹")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ฮฺ์๊โษอࠫ⠺"),l11ll1_l1_ (u"ࠩสู๊อมࠡฯึหอ࠭⠻"),l11ll1_l1_ (u"ࠪ฻้ฮวหࠢส่ื๎๑ศำࠪ⠼")]
#headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⠽"):l11ll1_l1_ (u"ࠬ࠭⠾")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l11111_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llll1l_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⠿"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⡀"),l11ll1_l1_ (u"ࠨࠩ⡁"),399,l11ll1_l1_ (u"ࠩࠪ⡂"),l11ll1_l1_ (u"ࠪࠫ⡃"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⡄"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⡅"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⡆"),l11ll1_l1_ (u"ࠧࠨ⡇"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⡈"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ⡉"),l11ll1_l1_ (u"ࠪࠫ⡊"),l11ll1_l1_ (u"ࠫࠬ⡋"),l11ll1_l1_ (u"ࠬ࠭⡌"),l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⡍"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⡎"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡏"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡐")+l111l1_l1_+title,l11l1l_l1_,391,l11ll1_l1_ (u"ࠪࠫ⡑"),l11ll1_l1_ (u"ࠫࠬ⡒"),l11ll1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ⡓")+str(seq))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⡔"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⡕")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ัฮฬืวหࠢ฼ุํอฦ๋หࠪ⡖"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠩࠪ⡗"),l11ll1_l1_ (u"ࠪࠫ⡘"),l11ll1_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬ⡙"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡚"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡛")+l111l1_l1_+l11ll1_l1_ (u"ࠧฤ฻็ํࠥอไฤใ็ห๊ࠦสใ์ํ้ฬ๑ࠧ⡜"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠨࠩ⡝"),l11ll1_l1_ (u"ࠩࠪ⡞"),l11ll1_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⡟"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡠"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⡡")+l111l1_l1_+l11ll1_l1_ (u"࠭รฺๆ์ࠤฬ๊ๅิๆึ่ฬะࠠหไํ๎๊อ๋ࠨ⡢"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠧࠨ⡣"),l11ll1_l1_ (u"ࠨࠩ⡤"),l11ll1_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫ⡥"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡦"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⡧")+l111l1_l1_+l11ll1_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪ⡨"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ⡩"),391,l11ll1_l1_ (u"ࠧࠨ⡪"),l11ll1_l1_ (u"ࠨࠩ⡫"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ⡬"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡭"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⡮")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬ⡯"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳࠨ⡰"),391,l11ll1_l1_ (u"ࠧࠨ⡱"),l11ll1_l1_ (u"ࠨࠩ⡲"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬ⡳"))
	block = l11ll1_l1_ (u"ࠪࠫ⡴")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡩࡩࡵࡲࠣࠩ⡵"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⡶"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ⡷"),l11ll1_l1_ (u"ࠧࠨ⡸"),l11ll1_l1_ (u"ࠨࠩ⡹"),l11ll1_l1_ (u"ࠩࠪ⡺"),l11ll1_l1_ (u"ࠪࠫ⡻"),l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ⡼"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡭ࡧࡤࡷࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫ⡽"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⡾"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⡿"),l11ll1_l1_ (u"ࠨࠩ⢀"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⢁"),block,re.DOTALL)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠪห้ษูๅู๋้ࠣอ็ะหࠪ⢂"):
			if first:
				title = l11ll1_l1_ (u"ࠫฬ๊วโๆส้ࠥ࠭⢃")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠬอไๆี็ื้อสࠡࠩ⢄")+title
		if title not in l1l11l_l1_:
			if title==l11ll1_l1_ (u"࠭รโๆส้ࠬ⢅"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢆"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⢇")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ⢈"),391,l11ll1_l1_ (u"ࠪࠫ⢉"),l11ll1_l1_ (u"ࠫࠬ⢊"),l11ll1_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⢋"))
			elif title==l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠧ⢌"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢍"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⢎")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶࠫ⢏"),391,l11ll1_l1_ (u"ࠪࠫ⢐"),l11ll1_l1_ (u"ࠫࠬ⢑"),l11ll1_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⢒"))
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢓"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⢔")+l111l1_l1_+title,l1lllll_l1_,391)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⢕"),l11ll1_l1_ (u"ࠩࠪ⢖"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⢗"),url,l11ll1_l1_ (u"ࠫࠬ⢘"),l11ll1_l1_ (u"ࠬ࠭⢙"),l11ll1_l1_ (u"࠭ࠧ⢚"),l11ll1_l1_ (u"ࠧࠨ⢛"),l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⢜"))
	html = response.content
	if type in [l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ⢝"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭⢞")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ⢟"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⢠"),l11ll1_l1_ (u"࠭ࠧ⢡"),url,block)
	elif type==l11ll1_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⢢"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ⢣"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif type==l11ll1_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡲࡵࡶࡪࡧࡶࠫ⢤"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡱ࡫ࡦࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴࡳ࡫ࡪ࡬ࡹࠨ⢥"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⢦"),l11ll1_l1_ (u"ࠬ࠭⢧"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⢨"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩ⢩"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࠧ⢪"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⢫"),l11ll1_l1_ (u"ࠪࠫ⢬"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⢭"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⢮"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ⢯"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢰"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ⢱"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭⢲"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ⢳"),block,re.DOTALL)
		l1llll_l1_,l1l1111l1_l1_,l1lll11l_l1_ = zip(*l1111l_l1_)
		items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	elif type==l11ll1_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬ⢴"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⢵"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⢶"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⢷") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⢸"),l11ll1_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ⢹"))
		html = html.replace(l11ll1_l1_ (u"ࠪࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ⢺"),l11ll1_l1_ (u"ࠫࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡨࡲࡩࡄࠧ⢻"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ⢼"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==6:
			l1111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⢽"),block,re.DOTALL)
			l1l1111l1_l1_,l1lll11l_l1_,l1llll_l1_ = zip(*l1111l_l1_)
			items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭⢾"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ⢿") in url:
				items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⣀"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭⣁") in url:
				items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⣂"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⣃"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠫ⣄") in title: continue
		if l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭⣅") in title:
			title = re.findall(l11ll1_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⣆"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭⣇")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⣈")+title
		l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ⣉"),title,re.DOTALL)
		if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ⣊") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣋"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ⣌") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣍"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ⣎") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣏"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ⣐") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣑"),l111l1_l1_+title,l1lllll_l1_,391,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⣒"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	if type not in [l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⣓"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⣔")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⣕"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⣖"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣗"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ⣘")+title,l1lllll_l1_,391,l11ll1_l1_ (u"࠭ࠧ⣙"),l11ll1_l1_ (u"ࠧࠨ⣚"),type)
	return
def l1llll1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⣛"),l11ll1_l1_ (u"ࠩࠪ⣜"),l11ll1_l1_ (u"ࠪࠫ⣝"),url)
	server = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ⣞"))
	url = url.replace(server,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⣟"),url,l11ll1_l1_ (u"࠭ࠧ⣠"),l11ll1_l1_ (u"ࠧࠨ⣡"),l11ll1_l1_ (u"ࠨࠩ⣢"),l11ll1_l1_ (u"ࠩࠪ⣣"),l11ll1_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⣤"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⣥"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ⣦"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⣧"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⣨"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	return
def PLAY(url):
	html = l1ll1l11ll_l1_(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⣩"),url,l11ll1_l1_ (u"ࠩࠪ⣪"),l11ll1_l1_ (u"ࠪࠫ⣫"),l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⣬"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⣭"),url,l11ll1_l1_ (u"࠭ࠧ⣮"),l11ll1_l1_ (u"ࠧࠨ⣯"),l11ll1_l1_ (u"ࠨࠩ⣰"),l11ll1_l1_ (u"ࠩࠪ⣱"),l11ll1_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⣲"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⣳"),l11ll1_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ⣴"))
		except: pass
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⣵"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡟ࠧࢂ࡜ࠨ࡟ࠫࡷ࡭࡫ࡡࡥࡧࡵࢀࡵࡧࡧࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠬ࡟ࠧࢂ࡜ࠨ࡟ࠪ⣶"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡴࡴࡹࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡷࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡸ࡬ࡨࡤࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⣷"),block,re.DOTALL)
		for type,post,l1ll1l1ll11_l1_,title in items:
			#l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵࡷ࠯ࡣ࡯ࡪࡦࡰࡥࡳࡶࡹ࠲ࡨࡵ࡭࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࡥࡩࡳࡩ࡯࠯ࡤ࡮ࡦࡾ࠮ࡱࡪࡳࠫ⣸")
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡥࡱࡲࡣࡵࡲࡡࡺࡧࡵࡣࡦࡰࡡࡹࠨࡳࡳࡸࡺ࠽ࠨ⣹")+post+l11ll1_l1_ (u"ࠫࠫࡴࡵ࡮ࡧࡀࠫ⣺")+l1ll1l1ll11_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ⣻")+type
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⣼")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⣽")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	#WRITE_THIS(html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣ࡫ࡧࡁࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧࠡࡥ࡯ࡥࡸࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡟ࡡࠨࡼࠨ࡟ࡶࡦࡴࡾ࡛࡝ࠤࡿࠫࡢࠨ⣾"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠤ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⣿"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⤀"),l11ll1_l1_ (u"ࠫࠬ⤁"),str(items),str(block))
		for l1lll1_l1_,l1lllll_l1_,l111llll_l1_,l1ll1l1ll1l_l1_ in items:
			if l11ll1_l1_ (u"ࠬࡃࠧ⤂") in l1lll1_l1_:
				host = l1lll1_l1_.split(l11ll1_l1_ (u"࠭࠽ࠨ⤃"))[1]
				title = SERVER(host,l11ll1_l1_ (u"ࠧࡩࡱࡶࡸࠬ⤄"))
			else: title = l11ll1_l1_ (u"ࠨࠩ⤅")
			title = l1ll1l1ll1l_l1_+l11ll1_l1_ (u"ࠩࠣࠫ⤆")+title
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⤇")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬ⤈")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⤉"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⤊"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⤋"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⤌"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⤍"),l11ll1_l1_ (u"ࠪ࠯ࠬ⤎"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⤏")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⤐"))
	return
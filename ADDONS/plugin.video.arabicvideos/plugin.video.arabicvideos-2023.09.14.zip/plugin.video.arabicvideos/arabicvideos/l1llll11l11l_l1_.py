# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ斁")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡘ࡛ࡌ࡟ࠨ斂")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪฬะࠦๅษษืีࠬ斃")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l11111_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llll1l_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ斄"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭斅"),l11ll1_l1_ (u"࠭ࠧ斆"),l11ll1_l1_ (u"ࠧࠨ文"),l11ll1_l1_ (u"ࠨࠩ斈"),l11ll1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ斉"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ斊"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ斋"),l11ll1_l1_ (u"ࠬ࠭斌"),469,l11ll1_l1_ (u"࠭ࠧ斍"),l11ll1_l1_ (u"ࠧࠨ斎"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ斏"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斐"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ斑")+l111l1_l1_+l11ll1_l1_ (u"ࠫศิัࠡษ็ั้่วหࠩ斒"),l11l1l_l1_,461,l11ll1_l1_ (u"ࠬ࠭斓"),l11ll1_l1_ (u"࠭ࠧ斔"),l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ斕"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭斖"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ斗"),l11ll1_l1_ (u"ࠪࠫ斘"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡳࡥ࡯ࡷ࠰ࡦࡹࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ料"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ斚"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l1lllll_l1_==l11ll1_l1_ (u"࠭ࠣࠨ斛"): continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ斜") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if title==l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ斝"): title = l11ll1_l1_ (u"ࠩฯำ๏ีࠠฮๆๅหฯࠦส๋ใํࠤๆอๆࠨ斞")
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ斟"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭斠")+l111l1_l1_+title,l1lllll_l1_,461)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡆࡰࡱࡷࡩࡷࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭斡"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ斢"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斣"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ斤")+l111l1_l1_+title,l1lllll_l1_,461)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ斥")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ斦"),l11ll1_l1_ (u"ࠫࠬ斧"),l1lll1l1l1_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ斨"),url,l11ll1_l1_ (u"࠭ࠧ斩"),l11ll1_l1_ (u"ࠧࠨ斪"),l11ll1_l1_ (u"ࠨࠩ斫"),l11ll1_l1_ (u"ࠩࠪ斬"),l11ll1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭断"))
	html = response.content
	#if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ斮"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ斯"),html,re.DOTALL)
	#else:
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭新"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ斱"),block,re.DOTALL)
		l11l_l1_ = []
		l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ斲"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ斳"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ斴"),l11ll1_l1_ (u"่๊๊ࠫษࠩ斵"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ斶"),l11ll1_l1_ (u"࠭็ะษไࠫ斷"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ斸"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ方"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ斺"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ斻")]
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ於") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)	#.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ施"))
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ斾"),title,re.DOTALL)
			if any(value in title for value in l1ll1l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭斿"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ旀") in title:
				title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ旁") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ旂"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ旃"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
	if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ旄"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ旅"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ旆"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ旇"))
				if l1lllll_l1_==l11ll1_l1_ (u"ࠤࠥ旈"): continue
				if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ旉") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠫࠬ旊"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ旋"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ旌")+title,l1lllll_l1_,461)
	return
def l1llll1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ旍"),l11ll1_l1_ (u"ࠨࠩ旎"),l11ll1_l1_ (u"ࠩࡈࡔࡎ࡙ࡏࡅࡇࡖࠫ族"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ旐"),url,l11ll1_l1_ (u"ࠫࠬ旑"),l11ll1_l1_ (u"ࠬ࠭旒"),l11ll1_l1_ (u"࠭ࠧ旓"),l11ll1_l1_ (u"ࠧࠨ旔"),l11ll1_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭旕"))
	html = response.content
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡫ࡩࡦࡪ࠭ࡵ࡫ࡷࡰࡪࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ旖"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡭ࡻ࡭ࡣࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ旗"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ旘") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ旙"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ旚"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ旛"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ旜"))
			if l1lllll_l1_==l11ll1_l1_ (u"ࠤࠥ旝"): continue
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ旞") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			#title = unescapeHTML(title)
			if title!=l11ll1_l1_ (u"ࠫࠬ旟"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ无"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ旡")+title,l1lllll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ既"),url,l11ll1_l1_ (u"ࠨࠩ旣"),l11ll1_l1_ (u"ࠩࠪ旤"),l11ll1_l1_ (u"ࠪࠫ日"),l11ll1_l1_ (u"ࠫࠬ旦"),l11ll1_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭旧"))
	html = response.content
	# l1l111l1l_l1_ l1lllll_l1_
	l1111l11ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡛ࡲ࡭ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ旨"),html,re.DOTALL)
	if l1111l11ll_l1_:
		l1111l11ll_l1_ = l1111l11ll_l1_[0]
		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ早") not in l1111l11ll_l1_:
			if l11ll1_l1_ (u"ࠨ࠱࠲ࠫ旪") in l1111l11ll_l1_: l1111l11ll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ旫")+l1111l11ll_l1_
			else: l1111l11ll_l1_ = l11l1l_l1_+l1111l11ll_l1_
		l1111l11ll_l1_ = l1111l11ll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ旬")
		l1llll_l1_.append(l1111l11ll_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡧ࠷࠵࠻ࡤࡨࡪࡴࡸࡥࠩ࠰࠭ࡃ࠮ࡹ࡭ࡢ࡮࡯࠲࠯ࡅࠢࡗ࡫ࡧࡩࡴ࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡖ࡬ࡢࡻࠥࠫ旭"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1ll1lllllll1_l1_,l1ll1llllllll_l1_ = l1l1l11_l1_[0]
		names = re.findall(l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ旮"),l1ll1lllllll1_l1_,re.DOTALL)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡳࡦࡶ࡙࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧ旯"),l1ll1llllllll_l1_,re.DOTALL)
		l1ll1llllll1l_l1_ = zip(names,l1l1_l1_)
		for name,l1llllllll111_l1_ in l1ll1llllll1l_l1_:
			l1llllllll111_l1_ = l1llllllll111_l1_[2:]
			if kodi_version<19: l1llllllll111_l1_ = l1llllllll111_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ旰"))
			l1llllllll111_l1_ = base64.b64decode(l1llllllll111_l1_)
			if kodi_version>18.99: l1llllllll111_l1_ = l1llllllll111_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭旱"))
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ旲"),l1llllllll111_l1_,re.DOTALL)
			l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ旳") not in l1lllll_l1_:
			if l11ll1_l1_ (u"ࠫ࠴࠵ࠧ旴") in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ旵")+l1lllll_l1_
			else: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ时")+name+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ旷")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭旸"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ旹"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11ll1_l1_ (u"ࠪࠤࠬ旺") in search:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ旻"),l11ll1_l1_ (u"ࠬ࠭旼"),l11ll1_l1_ (u"࠭ࡔࡗࡈࡘࡒ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬ旽"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦวๅสะฯࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽๊ࠥวࠡ์฼ู้้ࠦ็ัࠣ฻้ฮࠠฤๅฮี๋ࠥๆࠡๅ็้ฮ่ࠦศฯาอࠥ࠴࠮࠯ࠢํีั๏ࠠศๆหัะูࠦ็ࠢๆ่๊ฯ้ࠠษะำฮࠦแใูࠪ旾"))
		return
	#search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ旿"),l11ll1_l1_ (u"ࠩ࠰ࠫ昀"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫ昁")+search
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡷ࠯ࠨ昂")+search+l11ll1_l1_ (u"ࠬ࠵ࠧ昃")
	l11111_l1_(url)
	return
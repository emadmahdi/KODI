# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ㹧")
l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㹨")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11ll1_l1_ (u"ࠪ࠴ࠬ㹩"),True)
	elif mode==102: results = ITEMS(l11ll1_l1_ (u"ࠫ࠶࠭㹪"),True)
	elif mode==103: results = ITEMS(l11ll1_l1_ (u"ࠬ࠸ࠧ㹫"),True)
	elif mode==104: results = ITEMS(l11ll1_l1_ (u"࠭࠳ࠨ㹬"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11ll1_l1_ (u"ࠧ࠵ࠩ㹭"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㹮"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㹯")+l11ll1_l1_ (u"่้๋ࠪิหำๆ๎๋ࠦศฯั่อࠥࡓ࠳ࡖࠩ㹰"),l11ll1_l1_ (u"ࠫࠬ㹱"),710)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㹲"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ㹳")+l11ll1_l1_ (u"ࠧๅๆุ่ฯืใ๋่ࠣฬำีๅสࠢࡌࡔ࡙࡜ࠧ㹴"),l11ll1_l1_ (u"ࠨࠩ㹵"),230)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㹶"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠰ࡠࠩ㹷")+l11ll1_l1_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨ㹸"),l11ll1_l1_ (u"ࠬ࠭㹹"),101)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㹺"),l11ll1_l1_ (u"ࠧࡠࡖ࡙࠸ࡤ࠭㹻")+l11ll1_l1_ (u"ࠨไ้์ฬะࠠๆะอหึฯࠠๆ่ࠣ๎ํะ๊้สࠪ㹼"),l11ll1_l1_ (u"ࠩࠪ㹽"),106)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㹾"),l11ll1_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㹿")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤ฾ืศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㺀"),l11ll1_l1_ (u"࠭ࠧ㺁"),147)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㺂"),l11ll1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ㺃")+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡลฯ๊อ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㺄"),l11ll1_l1_ (u"ࠪࠫ㺅"),148)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺆"),l11ll1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㺇")+l11ll1_l1_ (u"࠭ࠠࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠣࠤࠬ㺈"),l11ll1_l1_ (u"ࠧࠨ㺉"),28)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㺊"),l11ll1_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨ㺋")+l11ll1_l1_ (u"ࠪๆ๋อษࠡษ็้฾อัโ่๊๋่ࠢࠥใ฻๊้ࠬ㺌"),l11ll1_l1_ (u"ࠫࠬ㺍"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㺎"),l11ll1_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬ㺏")+l11ll1_l1_ (u"ࠧใ่สอࠥอไไ๊ฮี๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㺐"),l11ll1_l1_ (u"ࠨࠩ㺑"),135)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㺒"),l11ll1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ㺓")+l11ll1_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭㺔"),l11ll1_l1_ (u"ࠬ࠭㺕"),38)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㺖"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㺗"),l11ll1_l1_ (u"ࠨࠩ㺘"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺙"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠱ࡠࠩ㺚")+l11ll1_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮูࠦศ็ฬࠫ㺛"),l11ll1_l1_ (u"ࠬ࠭㺜"),102)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺝"),l11ll1_l1_ (u"ࠧࡠࡖ࡙࠶ࡤ࠭㺞")+l11ll1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣาฬ฻ษࠨ㺟"),l11ll1_l1_ (u"ࠩࠪ㺠"),103)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺡"),l11ll1_l1_ (u"ࠫࡤ࡚ࡖ࠴ࡡࠪ㺢")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠๅๆไัฺ࠭㺣"),l11ll1_l1_ (u"࠭ࠧ㺤"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡖ࡙ࠫ㺥")+menu+l11ll1_l1_ (u"ࠨࡡࠪ㺦")
	client = l1l11l11l11_l1_(32)
	payload = {l11ll1_l1_ (u"ࠩ࡬ࡨࠬ㺧"):l11ll1_l1_ (u"ࠪࠫ㺨"),l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㺩"):client,l11ll1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㺪"):l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㺫"),l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㺬"):menu}
	#data = l1ll1l11l_l1_(payload)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㺭"),str(payload))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㺮"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㺯"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠫࠬ㺰"), True,l11ll1_l1_ (u"ࠬ࠭㺱"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㺲"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㺳"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠨࠩ㺴"),l11ll1_l1_ (u"ࠩࠪ㺵"),l11ll1_l1_ (u"ࠪࠫ㺶"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㺷"))
	html = response.content
	#html = html.replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ㺸"),l11ll1_l1_ (u"࠭ࠧ㺹"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㺺"),l11ll1_l1_ (u"ࠨࠩ㺻"),html,html)
	#file = open(l11ll1_l1_ (u"ࠩࡶ࠾࠴࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ㺼"), l11ll1_l1_ (u"ࠪࡻࠬ㺽"))
	#file.write(html)
	#file.close()
	items = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡡ࡞࠼࡞ࡵࡠࡳࡣࠫࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿ࠬ㺾"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11ll1_l1_ (u"ࠬࡧ࡬ࠨ㺿"),l11ll1_l1_ (u"࠭ࡁ࡭ࠩ㻀"))
			start = start.replace(l11ll1_l1_ (u"ࠧࡆ࡮ࠪ㻁"),l11ll1_l1_ (u"ࠨࡃ࡯ࠫ㻂"))
			start = start.replace(l11ll1_l1_ (u"ࠩࡄࡐࠬ㻃"),l11ll1_l1_ (u"ࠪࡅࡱ࠭㻄"))
			start = start.replace(l11ll1_l1_ (u"ࠫࡊࡒࠧ㻅"),l11ll1_l1_ (u"ࠬࡇ࡬ࠨ㻆"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11ll1_l1_ (u"࠭ࡁ࡭࠯ࠪ㻇"),l11ll1_l1_ (u"ࠧࡂ࡮ࠪ㻈"))
			start = start.replace(l11ll1_l1_ (u"ࠨࡃ࡯ࠤࠬ㻉"),l11ll1_l1_ (u"ࠩࡄࡰࠬ㻊"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1l1l_l1_,name,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠪࠧࠬ㻋") in source: continue
			#if source in [l11ll1_l1_ (u"ࠫࡓ࡚ࠧ㻌"),l11ll1_l1_ (u"ࠬ࡟ࡕࠨ㻍"),l11ll1_l1_ (u"࠭ࡗࡔ࠲ࠪ㻎"),l11ll1_l1_ (u"ࠧࡓࡎ࠴ࠫ㻏"),l11ll1_l1_ (u"ࠨࡔࡏ࠶ࠬ㻐")]: continue
			if source!=l11ll1_l1_ (u"ࠩࡘࡖࡑ࠭㻑"): name = name+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠࠡࠩ㻒")+source+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㻓")
			url = source+l11ll1_l1_ (u"ࠬࡁ࠻ࠨ㻔")+server+l11ll1_l1_ (u"࠭࠻࠼ࠩ㻕")+l11lll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠼࠽ࠪ㻖")+menu
			addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㻗"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠪ㻘")+name,url,105,l1lll1_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㻙"),l111l1_l1_+l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㻚"),l11ll1_l1_ (u"ࠬ࠭㻛"),9999)
		#if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㻜"),l11ll1_l1_ (u"ࠧࠨ㻝"),l11ll1_l1_ (u"ࠨࠩ㻞"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㻟"))
		#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㻠"),l111l1_l1_+l11ll1_l1_ (u"้๊ࠫริใ่ࠣฬࠦส้ฮาࠤ็์่ศฬࠣฮ้็า้่ํอ๊ࠥใࠨ㻡"),l11ll1_l1_ (u"ࠬ࠭㻢"),9999)
		#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㻣"),l111l1_l1_+l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้ࠣอโาสสลࠥ๎วๅษุำ็อมࠡใๅ฻ࠬ㻤"),l11ll1_l1_ (u"ࠨࠩ㻥"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㻦"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㻧"),l11ll1_l1_ (u"ࠫࠬ㻨"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㻩"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡕ࡯ࡨࡲࡶࡹࡻ࡮ࡢࡶࡨࡰࡾ࠲ࠠ࡯ࡱࠣࡘ࡛ࠦࡣࡩࡣࡱࡲࡪࡲࡳࠡࡨࡲࡶࠥࡿ࡯ࡶࠩ㻪"),l11ll1_l1_ (u"ࠧࠨ㻫"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㻬"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡌࡸࠥ࡯ࡳࠡࡨࡲࡶࠥࡸࡥ࡭ࡣࡷ࡭ࡻ࡫ࡳࠡࠨࠣࡪࡷ࡯ࡥ࡯ࡦࡶࠤࡴࡴ࡬ࡺࠩ㻭"),l11ll1_l1_ (u"ࠪࠫ㻮"),9999)
	return
def PLAY(id):
	source,server,l11lll1l1l_l1_,menu = id.split(l11ll1_l1_ (u"ࠫࡀࡁࠧ㻯"))
	url = l11ll1_l1_ (u"ࠬ࠭㻰")
	if source==l11ll1_l1_ (u"࠭ࡕࡓࡎࠪ㻱"): url = l11lll1l1l_l1_
	elif source==l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㻲"):
		url = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㻳")][0]+l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ㻴")+l11lll1l1l_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㻵"),url)
		return
	elif source==l11ll1_l1_ (u"ࠫࡌࡇࠧ㻶"):
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㻷") : l11ll1_l1_ (u"࠭ࠧ㻸"), l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࠬ㻹") : l1l11l11l11_l1_(32) , l11ll1_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㻺") : l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠳ࠪ㻻") , l11ll1_l1_ (u"ࠪࡱࡪࡴࡵࠨ㻼") : l11ll1_l1_ (u"ࠫࠬ㻽") }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㻾"),l11l1l_l1_,payload,l11ll1_l1_ (u"࠭ࠧ㻿"),False,l11ll1_l1_ (u"ࠧࠨ㼀"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㼁"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㼂"),l11ll1_l1_ (u"ࠪࠫ㼃"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㼄"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㼅"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l11l1111ll_l1_ = cookies[l11ll1_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࠪ㼆")]
		url = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㼇")]
		payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ㼈") : l11lll1l1l_l1_ , l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㼉") : l1l11l11l11_l1_(32) , l11ll1_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㼊") : l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠶ࠬ㼋") , l11ll1_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㼌") : l11ll1_l1_ (u"࠭ࠧ㼍") }
		headers = { l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ㼎") : l11ll1_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࡂ࠭㼏")+l1l11l1111ll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㼐"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠪࠫ㼑"),l11ll1_l1_ (u"ࠫࠬ㼒"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ㼓"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㼔"),l11ll1_l1_ (u"ࠧࠨ㼕"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㼖"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㼗"))
			return
		html = response.content
		url = re.findall(l11ll1_l1_ (u"ࠪࡶࡪࡹࡰࠣ࠼ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃࡲ࠹ࡵ࠹ࠫࠫ࠲࠯ࡅࠩࠣࠩ㼘"),html,re.DOTALL)
		l1lllll_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㼙"),l11ll1_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭㼚")+l1lllll_l1_)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㼛"),l11ll1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠠࠨ㼜")+params)
		l1l11l1111l1_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠵࠻࠲ࠬ㼝")+server+l11ll1_l1_ (u"ࠩ࠺࠻࠼࠵ࠧ㼞")+l11lll1l1l_l1_+l11ll1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㼟")+params
		l1l11l11111l_l1_ = l1l11l1111l1_l1_.replace(l11ll1_l1_ (u"ࠫ࠸࠼࠺࠸ࠩ㼠"),l11ll1_l1_ (u"ࠬ࠺࠰࠻࠹ࠪ㼡")).replace(l11ll1_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㼢"),l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㼣"))
		l1l11l111l11_l1_ = l1l11l1111l1_l1_.replace(l11ll1_l1_ (u"ࠨ࠵࠹࠾࠼࠭㼤"),l11ll1_l1_ (u"ࠩ࠷࠶࠿࠽ࠧ㼥")).replace(l11ll1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㼦"),l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㼧"))
		l1lll11l_l1_ = [l11ll1_l1_ (u"ࠬࡎࡄࠨ㼨"),l11ll1_l1_ (u"࠭ࡓࡅ࠳ࠪ㼩"),l11ll1_l1_ (u"ࠧࡔࡆ࠵ࠫ㼪")]
		l1llll_l1_ = [l1l11l1111l1_l1_,l1l11l11111l_l1_,l1l11l111l11_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ㼫"), l1lll11l_l1_)
		if l1l_l1_ == -1: return
		else: url = l1llll_l1_[l1l_l1_]
	elif source==l11ll1_l1_ (u"ࠩࡑࡘࠬ㼬"):
		headers = { l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㼭") : l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㼮") }
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㼯") : l11lll1l1l_l1_ , l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㼰") : l1l11l11l11_l1_(32) , l11ll1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㼱") : l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨ㼲") , l11ll1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㼳") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㼴"), l11l1l_l1_, payload, headers, False,l11ll1_l1_ (u"ࠫࠬ㼵"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㼶"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㼷"),l11ll1_l1_ (u"ࠧࠨ㼸"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㼹"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㼺"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㼻")]
		url = url.replace(l11ll1_l1_ (u"ࠫࠪ࠸࠰ࠨ㼼"),l11ll1_l1_ (u"ࠬࠦࠧ㼽"))
		url = url.replace(l11ll1_l1_ (u"࠭ࠥ࠴ࡆࠪ㼾"),l11ll1_l1_ (u"ࠧ࠾ࠩ㼿"))
		if l11ll1_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧ㽀") in l11lll1l1l_l1_:
			url = url.replace(l11ll1_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪ㽁"),l11ll1_l1_ (u"ࠪࠫ㽂"))
			url = url.replace(l11ll1_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧ㽃"),l11ll1_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧ㽄"))
	elif source==l11ll1_l1_ (u"࠭ࡐࡍࠩ㽅"):
		#headers = { l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㽆") : l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㽇") }
		payload = { l11ll1_l1_ (u"ࠩ࡬ࡨࠬ㽈") : l11lll1l1l_l1_ , l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㽉") : l1l11l11l11_l1_(32) , l11ll1_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㽊") : l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡓࡐࠬ㽋") , l11ll1_l1_ (u"࠭࡭ࡦࡰࡸࠫ㽌") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㽍"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠨࠩ㽎"),False,l11ll1_l1_ (u"ࠩࠪ㽏"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ㽐"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㽑"),l11ll1_l1_ (u"ࠬ࠭㽒"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㽓"),l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㽔"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㽕")]
		headers = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㽖"):response.headers[l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㽗")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㽘"),url, l11ll1_l1_ (u"ࠬ࠭㽙"),headers , l11ll1_l1_ (u"࠭ࠧ㽚"),l11ll1_l1_ (u"ࠧࠨ㽛"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ㽜"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㽝"),l11ll1_l1_ (u"ࠪࠫ㽞"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㽟"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㽠"))
			return
		html = response.content
		items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㽡"),html,re.DOTALL)
		url = items[0]
	elif source in [l11ll1_l1_ (u"ࠧࡕࡃࠪ㽢"),l11ll1_l1_ (u"ࠨࡈࡐࠫ㽣"),l11ll1_l1_ (u"ࠩ࡜࡙ࠬ㽤"),l11ll1_l1_ (u"࡛ࠪࡘ࠷ࠧ㽥"),l11ll1_l1_ (u"ࠫ࡜࡙࠲ࠨ㽦"),l11ll1_l1_ (u"ࠬࡘࡌ࠲ࠩ㽧"),l11ll1_l1_ (u"࠭ࡒࡍ࠴ࠪ㽨")]:
		if source==l11ll1_l1_ (u"ࠧࡕࡃࠪ㽩"): l11lll1l1l_l1_ = id
		headers = { l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㽪") : l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㽫") }
		payload = { l11ll1_l1_ (u"ࠪ࡭ࡩ࠭㽬") : l11lll1l1l_l1_ , l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㽭") : l1l11l11l11_l1_(32) , l11ll1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㽮") : l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࠫ㽯")+source , l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㽰") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㽱"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠩࠪ㽲"),l11ll1_l1_ (u"ࠪࠫ㽳"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠹ࡸ࡭࠭㽴"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㽵"),l11ll1_l1_ (u"࠭ࠧ㽶"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㽷"),l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㽸"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㽹")]
		if source==l11ll1_l1_ (u"ࠪࡊࡒ࠭㽺"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㽻"), url, l11ll1_l1_ (u"ࠬ࠭㽼"), l11ll1_l1_ (u"࠭ࠧ㽽"), False,l11ll1_l1_ (u"ࠧࠨ㽾"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪ㽿"))
			url = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㾀")]
			url = url.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㾁"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㾂"))
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㾃"))
	return
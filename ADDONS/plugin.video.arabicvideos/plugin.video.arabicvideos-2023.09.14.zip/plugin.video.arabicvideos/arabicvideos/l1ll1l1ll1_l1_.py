# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪᬆ")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡈࡓࡎࡠࠩᬇ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫ็อฦๆฬํࠫᬈ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l111_l1_(url)
	elif mode==302: results = l11111_l1_(url)
	elif mode==303: results = l1lll1ll1l_l1_(url)
	elif mode==304: results = l1llll1l_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll1l11l1_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᬉ"),l111l1_l1_+l11ll1_l1_ (u"࠭ไๆษำหࠥอไๆ๊ๅ฽ࠥฮื๋รࠪᬊ"),l11ll1_l1_ (u"ࠧࠨᬋ"),306)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᬌ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᬍ"),l11ll1_l1_ (u"ࠪࠫᬎ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬏ"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᬐ"),l11ll1_l1_ (u"࠭ࠧᬑ"),309,l11ll1_l1_ (u"ࠧࠨᬒ"),l11ll1_l1_ (u"ࠨࠩᬓ"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬔ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᬕ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᬖ"),l11ll1_l1_ (u"ࠬ࠭ᬗ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᬘ"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭ᬙ"),l11ll1_l1_ (u"ࠨࠩᬚ"),l11ll1_l1_ (u"ࠩࠪᬛ"),l11ll1_l1_ (u"ࠪࠫᬜ"),l11ll1_l1_ (u"ࠫࠬᬝ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᬞ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧᬟ"),html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪࡨࡥࡩ࡫ࡲ࠿ࠩᬠ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᬡ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		#l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫᬢ"))
		#if title==l11ll1_l1_ (u"ࠪี๊฼ว็ࠩᬣ"): l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯า็ูห๋࠵ࠧᬤ")
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬥ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᬦ")+l111l1_l1_+title,l1lllll_l1_,301)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᬧ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᬨ"),l11ll1_l1_ (u"ࠩࠪᬩ"),9999)
	l1l111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᬪ"),html)
	return html
def l1ll1l11l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᬫ"),l11ll1_l1_ (u"ࠬ࠭ᬬ"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᬭ"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠠษูํล๋ࠥๆࠡษ็ฺ้ีัࠡ࠰࠱ࠤอูศษࠢๅ๎ฬ๋ࠠฤืะหอࠦวๅ็๋ๆ฾ࠦศหึไ๎ึࠦๅฮฬ๋๎ฬะࠠอ็ํ฽ࠥ฻แฮษอࠤฬ๊ๅ้ไ฼ࠤ࠳࠴้ࠠษ็์็ะࠠศๆูหห฿๋ࠠา๊ฬࠥ็๊ࠡ็฼ห้าษࠡฬืๅ๏ืࠠศๆุๅาอสࠡษ็ู้็ัสࠢๅฬู้ࠦาุ้ࠣาะ่๋ษอ๋ฬࠦแ๋ࠢๅ์ฬฬๅ้ࠡำหࠥอไษำ้ห๊าࠧᬮ"))
	return
def l1l111_l1_(url,html=l11ll1_l1_ (u"ࠨࠩᬯ")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᬰ"),url,l11ll1_l1_ (u"ࠪࠫᬱ"),l11ll1_l1_ (u"ࠫࠬᬲ"),l11ll1_l1_ (u"ࠬ࠭ᬳ"),l11ll1_l1_ (u"᬴࠭ࠧ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᬵ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳࠰࠿࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁ࠭ࠬᬶ"),html,re.DOTALL)
	if l1l1l11_l1_:
		for block in l1l1l11_l1_:
			seq += 1
			items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᬷ"),block,re.DOTALL)
			for title,test,l1lllll_l1_ in items:
				title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬᬸ"))
				if title==l11ll1_l1_ (u"ࠫࠬᬹ"): title = l11ll1_l1_ (u"ࠬฮ่้๊๋์ࠬᬺ")
				if l11ll1_l1_ (u"࠭ࡥ࡮ࡀ࠿ࡥࠬᬻ") not in test:
					if block.count(l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫᬼ"))>0:
						l1ll1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᬽ"),block,re.DOTALL)
						for l1lllll_l1_ in l1ll1l111l_l1_:
							title = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫᬾ"))[-2]
							addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᬿ"),l111l1_l1_+title,l1lllll_l1_,301)
						continue
					else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᭀ")+str(seq)
				#l111l1111_l1_ = [l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦࠧᭁ"),l11ll1_l1_ (u"࠭วโๆส้ࠥ࠭ᭂ"),l11ll1_l1_ (u"ࠧษำส้ั࠭ᭃ"),l11ll1_l1_ (u"ࠨ฻ิ์฻᭄࠭"),l11ll1_l1_ (u"ࠩๆ่๏ฮวหࠩᭅ"),l11ll1_l1_ (u"ࠪห฿อๆ๊ࠩᭆ")]
				#if any(value in title for value in l111l1111_l1_):
				if not any(value in title for value in l1l11l_l1_):
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᭇ"),l111l1_l1_+title,l1lllll_l1_,302)
	else: l11111_l1_(url,html)
	return
def l11111_l1_(url,html=l11ll1_l1_ (u"ࠬ࠭ᭈ")):
	if html==l11ll1_l1_ (u"࠭ࠧᭉ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᭊ"),url,l11ll1_l1_ (u"ࠨࠩᭋ"),l11ll1_l1_ (u"ࠩࠪᭌ"),l11ll1_l1_ (u"ࠪࠫ᭍"),l11ll1_l1_ (u"ࠫࠬ᭎"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ᭏"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11ll1_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪ᭐") in url:
		url,seq = url.split(l11ll1_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫ᭑"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳࠰࠿࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁ࠭ࠬ᭒"),html,re.DOTALL)
		block = l1l1l11_l1_[int(seq)-1]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡳࡩࡿ࠾ࠨ᭓"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪࡀࡦ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᭔"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,data,l1lll1_l1_ in items:
		title = re.findall(l11ll1_l1_ (u"ࠫࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠯ࠬࡂࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࡦ࡯ࡁࠫ᭕"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ᭖"),l11ll1_l1_ (u"࠭ࠧ᭗")).strip(l11ll1_l1_ (u"ࠧࠡࠩ᭘"))
		if not title or title==l11ll1_l1_ (u"ࠨࠩ᭙"):
			title = re.findall(l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣࡀ࠱࠮ࡄࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᭚"),data,re.DOTALL)
			if title: title = title[0].replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭᭛"),l11ll1_l1_ (u"ࠫࠬ᭜")).strip(l11ll1_l1_ (u"ࠬࠦࠧ᭝"))
			if not title or title==l11ll1_l1_ (u"࠭ࠧ᭞"):
				title = re.findall(l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᭟"),data,re.DOTALL)
				title = title[0].replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ᭠"),l11ll1_l1_ (u"ࠩࠪ᭡")).strip(l11ll1_l1_ (u"ࠪࠤࠬ᭢"))
		title = unescapeHTML(title)
		#if title==l11ll1_l1_ (u"ࠫࠬ᭣"): continue
		if title not in l11l_l1_:
			l11l_l1_.append(title)
			l111l_l1_ = l1lllll_l1_+data+l1lll1_l1_
			if l11ll1_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ᭤") in l111l_l1_ or l11ll1_l1_ (u"࠭ๅิๆึ่ࠬ᭥") in l111l_l1_ or l11ll1_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࠤࠪ᭦") in l111l_l1_:
				if l11ll1_l1_ (u"ࠨสิห๊าࠧ᭧") in data: title = l11ll1_l1_ (u"ࠩหี๋อๅอࠢࠪ᭨")+title
				elif l11ll1_l1_ (u"ุ้๊ࠪำๅࠩ᭩") in data or l11ll1_l1_ (u"๊ࠫ๎ำๆࠩ᭪") in data: title = l11ll1_l1_ (u"๋ࠬำๅี็ࠤࠬ᭫")+title
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᭬࠭"),l111l1_l1_+title,l1lllll_l1_,303,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᭭"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᭮"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᭯"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭰"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ᭱")+title,l1lllll_l1_,302)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ᭲"),url,l11ll1_l1_ (u"࠭ࠧ᭳"),l11ll1_l1_ (u"ࠧࠨ᭴"),l11ll1_l1_ (u"ࠨࠩ᭵"),l11ll1_l1_ (u"ࠩࠪ᭶"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠷ࡳࡵࠩ᭷"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11ll1_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹ࡯ࡴ࡭ࡧࡁࠫ᭸"),html,re.DOTALL)
	name = name[0].replace(l11ll1_l1_ (u"ࠬࢂࠠิ์่หࠥ์ว้ࠩ᭹"),l11ll1_l1_ (u"࠭ࠧ᭺")).replace(l11ll1_l1_ (u"ࠧࡄ࡫ࡰࡥࠥࡔ࡯ࡸࠩ᭻"),l11ll1_l1_ (u"ࠨࠩ᭼")).strip(l11ll1_l1_ (u"ࠩࠣࠫ᭽")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭᭾"),l11ll1_l1_ (u"ࠫࠥ࠭᭿"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠩᮀ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᮁ"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠧࠡࠩᮂ")+title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫᮃ"),l11ll1_l1_ (u"ࠩࠪᮄ")).strip(l11ll1_l1_ (u"ࠪࠤࠬᮅ"))
				title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧᮆ"),l11ll1_l1_ (u"ࠬ࠭ᮇ")).strip(l11ll1_l1_ (u"࠭ࠠࠨᮈ"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᮉ"),l111l1_l1_+title,l1lllll_l1_,304)
		else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪᮊ") not in url: url = url.strip(l11ll1_l1_ (u"ࠩ࠲ࠫᮋ"))+l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࡬ࡲ࡬࠭ᮌ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᮍ"),url,l11ll1_l1_ (u"ࠬ࠭ᮎ"),l11ll1_l1_ (u"࠭ࠧᮏ"),l11ll1_l1_ (u"ࠧࠨᮐ"),l11ll1_l1_ (u"ࠨࠩᮑ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᮒ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠪࠫᮓ"),html)
	if l11ll1_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭ᮔ") not in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᮕ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᮖ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪᮗ"),l11ll1_l1_ (u"ࠨࠩᮘ")).strip(l11ll1_l1_ (u"ࠩࠣࠫᮙ"))
			title = l11ll1_l1_ (u"ࠪห้ำไใหࠣࠫᮚ")+title
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᮛ"),l111l1_l1_+title,l1lllll_l1_,305)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡦࡶࡤ࡭ࡱࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡲࡦ࡮ࡤࡸࡪࡪࠢࠨᮜ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᮝ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪᮞ"),l11ll1_l1_ (u"ࠨࠩᮟ")).strip(l11ll1_l1_ (u"ࠩࠣࠫᮠ"))
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᮡ"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	return
def PLAY(url):
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫ࡬ࡹࡳ࡬ࠪࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡭࡯࡮ࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱ࠯ࠊࠊࡥࡲࡳࡰ࡯ࡥࡴࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡱ࡮࡭ࡪࡹ࠮ࡨࡧࡷࡣࡩ࡯ࡣࡵࠪࠬࠎࠎࡖࡈࡑࡕࡈࡗࡘࡏࡄࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄࠨ࡟ࠍࠍࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠤ࡫ࡶࡪ࡬ࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠰ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀࠫ࠰ࡖࡈࡑࡕࡈࡗࡘࡏࡄࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠪࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡤࡨࠧࠦࡴࡢࡴࡪࡩࡹࡃࠢࡠࡤ࡯ࡥࡳࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡣࡧࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡪ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡡࡥࡡ࡫ࡸࡲࡲࠩࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡥࡸࡳࠨࠠࡴࡶࡼࡰࡪࡃࠢࡥ࡫ࡶࡴࡱࡧࡹ࠻ࠢࡱࡳࡳ࡫࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࡞࠴ࡢ࠱ࠧ࠰ࠩࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡤ࠱ࡧ࡮ࡳࡡࡷ࡫ࡧࡷ࠳ࡲࡩࡷࡧ࠲ࠫࢂࠐࠉࠣࠤࠥᮢ")
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫࡭ࡳ࡭࠯ࠨᮣ")
	#server = SERVER(l111lll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᮤ"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᮥ"):None,l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᮦ"):server}
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᮧ"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫᮨ"),l11ll1_l1_ (u"ࠫࠬᮩ"),l11ll1_l1_ (u"᮪ࠬ࠭"),l11ll1_l1_ (u"᮫࠭ࠧ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪᮬ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l111lll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧᮭ"))
	#html = l1ll1l11ll_l1_(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᮮ"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫᮯ"),l11ll1_l1_ (u"ࠫࠬ᮰"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠻ࡺࡨࠨ᮱"))
	#if html and kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ᮲"))
	#html = DECODE_ADILBO_HTML(html)
	l1llll_l1_ = []
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᮳"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᮴"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ᮵"),l11ll1_l1_ (u"ࠪࠫ᮶")).strip(l11ll1_l1_ (u"ࠫࠥ࠭᮷"))
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭᮸"),title,re.DOTALL)
			if l111llll_l1_:
				l111llll_l1_ = l11ll1_l1_ (u"࠭࡟ࡠࡡࡢࠫ᮹")+l111llll_l1_[0]
				#title = l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᮺ")
				title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭ᮻ"))
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠩࠪᮼ")
			l1lllll11l_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᮽ")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᮾ")+l111llll_l1_
			l1llll_l1_.append(l1lllll11l_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᮿ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l1l_l1_ l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠰࠱࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬᯀ"),block,re.DOTALL)
		for l1lllll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᯁ")+l1lllll_l1_
			title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭ᯂ"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᯃ")+title+l11ll1_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫᯄ")
			l1llll_l1_.append(l1lllll_l1_)
		# l1ll1l1l11_l1_ l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡦࡰࡡࡹ࡞ࠫࡿࡺࡸ࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᯅ"),html,re.DOTALL)
		if l1l1_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡳࡪࡥࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧᯆ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩᯇ"),l11ll1_l1_ (u"ࠧࠨᯈ")).strip(l11ll1_l1_ (u"ࠨࠢࠪᯉ"))
				title = title.replace(l11ll1_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫᯊ"),l11ll1_l1_ (u"ࠪࡇ࡮ࡳࡡࡏࡱࡺࠫᯋ"))
				l1lllll_l1_ = l1l1_l1_[0]+l11ll1_l1_ (u"ࠫࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡷࡪࡶࡦ࡬ࠫ࡯࡮ࡥࡧࡻࡁࠬᯌ")+index+l11ll1_l1_ (u"ࠬࠬࡩࡥ࠿ࠪᯍ")+id+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᯎ")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᯏ")
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᯐ"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᯑ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫᯒ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬᯓ"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧᯔ"),l11ll1_l1_ (u"࠭ࠫࠨᯕ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡁࡶࡁࠬᯖ")+search
	l11111_l1_(url)
	return
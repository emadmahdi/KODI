# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ拰")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡘࡎࡔࡠࠩ拱")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭拲"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭拳"),l11ll1_l1_ (u"࠭รโๆส้๊ࠥไไสสีࠥ็โุࠩ拴")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l11111_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l1llll1_l1_(url,text)
	elif mode==644: results = l1l111_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ拵"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ拶"),l11ll1_l1_ (u"ࠩࠪ拷"),l11ll1_l1_ (u"ࠪࠫ拸"),l11ll1_l1_ (u"ࠫࠬ拹"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ拺"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭拻"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ拼"),l11ll1_l1_ (u"ࠨࠩ拽"),649,l11ll1_l1_ (u"ࠩࠪ拾"),l11ll1_l1_ (u"ࠪࠫ拿"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ挀"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ持"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭挂"),l11ll1_l1_ (u"ࠧࠨ挃"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ挄"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ挅")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ挆"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠫࠬ指"),l11ll1_l1_ (u"ࠬ࠭挈"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ按"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ挊"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ挋")+l111l1_l1_+l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆ่์็฿ࠧ挌"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠪࠫ挍"),l11ll1_l1_ (u"ࠫࠬ挎"),l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ挏"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭挐"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ挑")+l111l1_l1_+l11ll1_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧ挒"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠩࠪ挓"),l11ll1_l1_ (u"ࠪࠫ挔"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ挕"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ挖"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ挗")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫ挘"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠨࠩ挙"),l11ll1_l1_ (u"ࠩࠪ挚"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ挛"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ挜"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挝"),l11ll1_l1_ (u"࠭ࠧ挞"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡻࡷࡧࡰࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ挟"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ挠"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挡"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ挢")+l111l1_l1_+title,l1lllll_l1_,644)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ挣"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挤"),l11ll1_l1_ (u"࠭ࠧ挥"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ挦"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ挧"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠩࠪ挨"))
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ挩"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ挪"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ挫")+l111l1_l1_+title,l1lllll_l1_,644)
	return
def l1l111_l1_(url):
	l1111l1ll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ挬"),url,l11ll1_l1_ (u"ࠧࠨ挭"),l11ll1_l1_ (u"ࠨࠩ挮"),l11ll1_l1_ (u"ࠩࠪ振"),l11ll1_l1_ (u"ࠪࠫ挰"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ挱"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ挲"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ挳"),l11ll1_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭挴"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ挵"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠩࠪ挶"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ挷"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ挸"),l11ll1_l1_ (u"ࠬ࠭挹"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			l1111l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ挺"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢࠪ挻")
			for l1lllll_l1_,title in l1111l1ll_l1_:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ挼"),l111l1_l1_+title,l1lllll_l1_,641)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭挽"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ挾"),block,re.DOTALL)
		if len(l1l1l1l_l1_)<30:
			if l1111l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ挿"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ捀"),l11ll1_l1_ (u"࠭ࠧ捁"),9999)
			for l1lllll_l1_,title in l1l1l1l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ捂"),l111l1_l1_+title,l1lllll_l1_,641)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠨࠩ捃")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ捄"),l11ll1_l1_ (u"ࠪࠫ捅"),request,url)
	if request==l11ll1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ捆"):
		url,search = url.split(l11ll1_l1_ (u"ࠬࡅࠧ捇"),1)
		data = l11ll1_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ捈")+search
		headers = {l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭捉"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ捊")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ捋"),url,data,headers,l11ll1_l1_ (u"ࠪࠫ捌"),l11ll1_l1_ (u"ࠫࠬ捍"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ捎"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ捏"),url,l11ll1_l1_ (u"ࠧࠨ捐"),l11ll1_l1_ (u"ࠨࠩ捑"),l11ll1_l1_ (u"ࠩࠪ捒"),l11ll1_l1_ (u"ࠪࠫ捓"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ捔"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠬ࠭捕"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ捖"))
	if request==l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ捗"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ捘"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠩࠪ捙"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ捚"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ捛"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ捜"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭捝"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ捞"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ损"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ捠"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ捡"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭换"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠬ࠭捣"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ捤"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ捥"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ捦"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ捧"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ捨"),l11ll1_l1_ (u"่๊๊ࠫษࠩ捩"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ捪"),l11ll1_l1_ (u"࠭็ะษไࠫ捫"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ捬"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ捭"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ据"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ捯"),l11ll1_l1_ (u"ู๊ࠫัฮ์ฬࠫ捰")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ捱"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ捲") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ捳")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ捴"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ捵") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ捶")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭捷"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ捸"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ捹"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭捺"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ捻"):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ捼"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ捽") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ捾"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ捿") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭掀"),l111l1_l1_+title,l1lllll_l1_,641,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ掁"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ掂"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ掃")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ掄"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ掅"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧ掆"): continue
				if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ掇") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ授")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ掉"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掊"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ掋")+title,l1lllll_l1_,641)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ掌"),l11ll1_l1_ (u"ࠬ࠭掍"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ掎"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ掏"),url,l11ll1_l1_ (u"ࠨࠩ掐"),l11ll1_l1_ (u"ࠩࠪ掑"),l11ll1_l1_ (u"ࠪࠫ排"),l11ll1_l1_ (u"ࠫࠬ掓"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ掔"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ掕"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ掖"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩ掗")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ掘"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠪࠧࠬ掙"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ掚"),l111l1_l1_+title,url,643,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭掛"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠧ掜")+l1l1l_l1_+l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭掝"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪ掞"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		#if not items: items = re.findall(l11ll1_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ掟"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ掠") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭採")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ探"))
			title = title.replace(l11ll1_l1_ (u"࠭࠼࠰ࡵࡳࡥࡳࡄ࠼ࡦ࡯ࡁࠫ掣"),l11ll1_l1_ (u"ࠧࠡࠩ掤"))
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ接"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ掦"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ控") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭推")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ掩"))
		#		addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ措"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l11l_l1_,l1llll11_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ掫"),l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡪࡽ࠮ࡱࡪࡳࠫ掬"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭掭"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ掮"),l11ll1_l1_ (u"ࠫࠬ掯"),l11ll1_l1_ (u"ࠬ࠭掰"),l11ll1_l1_ (u"࠭ࠧ掱"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ掲"))
	html = response.content
	# l1l111l1l_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡥࡧࡧ࠱ࡻ࡯ࡤࡦࡱࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ掳"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ掴"),block,re.DOTALL)
		if l1l1_l1_:
			l1lllll_l1_ = l1l1_l1_[0]
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ掵"))
				l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ掶"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ掷"),block,re.DOTALL)
		block = block.replace(l11ll1_l1_ (u"࠭࡜࡝ࠤࠪ掸"),l11ll1_l1_ (u"ࠧࠣࠩ掹")).replace(l11ll1_l1_ (u"ࠨ࡞࠲ࠫ掺"),l11ll1_l1_ (u"ࠩ࠲ࠫ掻"))
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡁ࡯ࡦࡳࡣࡰࡩ࠳ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ掼"),block,re.DOTALL)
		if len(l11111l11_l1_)==len(l1l1_l1_):
			for id,title in l11111l11_l1_:
				l1lllll_l1_ = l1l1_l1_[int(id)]
				if l1lllll_l1_ not in l1llll_l1_:
					l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ掽")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭掾"))
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡕࡨࡶࡻ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭掿"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ揀"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ揁")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭揂"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l11l_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1llll11_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ揃"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ揄"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭揅"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ揆"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ揇"),l11ll1_l1_ (u"ࠨ࠭ࠪ揈"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪ揉")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ揊"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨ揋")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ揌"))
	return
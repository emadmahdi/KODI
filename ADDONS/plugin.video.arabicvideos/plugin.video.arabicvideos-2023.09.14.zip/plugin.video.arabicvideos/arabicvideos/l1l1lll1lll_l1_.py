# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ⸓")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡋࡐࡈࡥࠧ⸔")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ู่ࠩฬืูสࠩ⸕"),l11ll1_l1_ (u"ࠪหาีหࠡษ็ฬึอๅอࠩ⸖"),l11ll1_l1_ (u"ࠫฬำฯฬࠢส่ฬู๊ศสࠪ⸗"),l11ll1_l1_ (u"ࠬออะอࠣห้อฺศ่์ࠫ⸘")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l11111_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l1llll1l_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⸙"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ⸚"),l11ll1_l1_ (u"ࠨࠩ⸛"),l11ll1_l1_ (u"ࠩࠪ⸜"),l11ll1_l1_ (u"ࠪࠫ⸝"),l11ll1_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⸞"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⸟"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸠"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⸡"),l11ll1_l1_ (u"ࠨࠩ⸢"),89,l11ll1_l1_ (u"ࠩࠪ⸣"),l11ll1_l1_ (u"ࠪࠫ⸤"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⸥"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸦"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬิ๊ฬࠦไไࠩ⸧"),l1ll111_l1_,81,l11ll1_l1_ (u"ࠧࠨ⸨"),l11ll1_l1_ (u"ࠨࠩ⸩"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ⸪"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⸫"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⸬"),block,re.DOTALL)
	for l1lll1l1l1_l1_,title in items:
		l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࡄ࡯ࡴࡦ࡯ࡀࠫ⸭")+l1lll1l1l1_l1_+l11ll1_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧ⸮")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⸯ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⸰")+l111l1_l1_+title,l1lllll_l1_,81)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⸱"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⸲"),l11ll1_l1_ (u"ࠫࠬ⸳"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡮ࡢࡸ࠰ࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡺࡃ࠭⸴"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⸵"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ⸶"): continue
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸷"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⸸")+l111l1_l1_+title,l1lllll_l1_,81)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠪࠫ⸹")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⸺"),l11ll1_l1_ (u"ࠬ࠭⸻"),url)
	items = []
	# l1lll11lll_l1_ l1lll1l111_l1_
	if l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⸼") in url or l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ⸽") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⸾"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ⸿")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⹀"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠫࠬ⹁"),l11ll1_l1_ (u"ࠬ࠭⹂"),l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⹃"))
		html = response.content
		l1l1l11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⹄"),url,l11ll1_l1_ (u"ࠨࠩ⹅"),l11ll1_l1_ (u"ࠩࠪ⹆"),l11ll1_l1_ (u"ࠪࠫ⹇"),l11ll1_l1_ (u"ࠫࠬ⹈"),l11ll1_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⹉"))
		html = response.content
		# l1lll1l1l1_l1_ items
		if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⹊"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⹋"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹌"),block,re.DOTALL)
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⹍"),l11ll1_l1_ (u"ࠪࠫ⹎"),l11ll1_l1_ (u"ࠫࠬ⹏"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l11ll1_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦࠬ⹐") in html:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡲࡲࡷࡹࠦ࡭ࡣ࠯࠴࠴ࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⹑"),html,re.DOTALL)
		else:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࡵࡸ࡮ࡩ࡬ࡦࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⹒"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items:
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡰࡴ࡬࡫࡮ࡴࡡ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⹓"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⹔"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ⹕"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ⹖"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫ⹗"),l11ll1_l1_ (u"࠭ใๅ์หࠫ⹘"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭⹙"),l11ll1_l1_ (u"ࠨ้าหๆ࠭⹚"),l11ll1_l1_ (u"่ࠩฬฬืวสࠩ⹛"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧ⹜"),l11ll1_l1_ (u"๊ࠫํัอษ้ࠫ⹝"),l11ll1_l1_ (u"ࠬอไษ๊่ࠫ⹞")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"࠭࠯ࠨ⹟"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ⹠"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⹡") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹢"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠪื้อำๅࠩ⹣") not in url and any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⹤"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ⹥") in title:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⹦") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹧"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ⹨") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹩"),l111l1_l1_+title,l1lllll_l1_,81,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹪"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫࠬ⹫"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࠩ⹬"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⹭"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠢࠣ⹮"): continue
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠨࠩ⹯"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹰"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ⹱")+title,l1lllll_l1_,81)
	if l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ⹲") in url or l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭⹳") in url:
		if l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⹴") in url:
			url = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧ⹵"),l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩ⹶"))+l11ll1_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀ࠶࠵࠭⹷")
		elif l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫ⹸") in url:
			url,offset = url.split(l11ll1_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭⹹"))
			offset = int(offset)+20
			url = url+l11ll1_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧ⹺")+str(offset)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹻"),l111l1_l1_+l11ll1_l1_ (u"่่ࠧส็ࠥอไๆิํำࠬ⹼"),url,81)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⹽"),url,l11ll1_l1_ (u"ࠩࠪ⹾"),l11ll1_l1_ (u"ࠪࠫ⹿"),l11ll1_l1_ (u"ࠫࠬ⺀"),l11ll1_l1_ (u"ࠬ࠭⺁"),l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⺂"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡩࡨࡸࡘ࡫ࡡࡴࡱࡱࡷࡇࡿࡓࡦࡴ࡬ࡩࡸ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⺃"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡯࡭ࡸࡺ࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⺄"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⺅") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⺆"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺇"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡩ࡮ࡣࡪࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺈"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⺉"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ⺊"),l11ll1_l1_ (u"ࠨࠩ⺋")).strip(l11ll1_l1_ (u"ࠩࠣࠫ⺌"))
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⺍"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭⺎"),l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤࡳ࡯ࡷ࡫ࡨࡷ࠴࠭⺏"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ⺐"),l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ⺑"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⺒"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ⺓"),l11ll1_l1_ (u"ࠪࠫ⺔"),l11ll1_l1_ (u"ࠫࠬ⺕"),l11ll1_l1_ (u"ࠬ࠭⺖"),l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⺗"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ⺘"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⺙"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡳࡳࡸࡺࡉࡅࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ⺚"),html,re.DOTALL)
		l11lll11_l1_ = l11lll11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠥ࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ⺛"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ⺜"),l11ll1_l1_ (u"ࠬ࠭⺝")).strip(l11ll1_l1_ (u"࠭ࠠࠨ⺞"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡓࡰࡦࡿࡥࡳࡁࡶࡩࡷࡼࡥࡳ࠿ࠪ⺟")+server+l11ll1_l1_ (u"ࠨࠨࡳࡳࡸࡺࡉࡅ࠿ࠪ⺠")+l11lll11_l1_+l11ll1_l1_ (u"ࠩࠩࡅ࡯ࡧࡸ࠾࠳ࠪ⺡")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⺢")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⺣")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡰࡹࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⺤"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⺥"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⺦")+name+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⺧")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⺨"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⺩"),url)
	return
l11ll1_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡕࡒࡁ࡚ࡡࡒࡐࡉ࠮ࡵࡳ࡮ࠬ࠾ࠏࠏࡤࡢࡶࡤࠤࡂࠦࡻࠨࡘ࡬ࡩࡼ࠭࠺࠲ࡿࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ࠼ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩࢀࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠮ࡧࡥࡹࡧࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࡡࠏࠏࠣࠡࡹࡤࡸࡨ࡮ࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫࠏࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠧࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡶࡩࡷ࠳࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡵࡺࡧ࡬ࡪࡶࡼ࠰ࡱ࡯࡮࡬ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ࠯ࠬࡥ࡟ࡠࡡࠪ࠯ࡶࡻࡡ࡭࡫ࡷࡽࠏࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠧࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ࠮࡯࡭ࡳࡱࡌࡊࡕࡗ࠭ࠏࠏࡩࡧࠢ࡯ࡩࡳ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪ࠿ࡀ࠴࠿ࠦࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࠲ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐็ࠡใํำ๏๎ࠧࠪࠌࠌࡩࡱࡹࡥ࠻ࠌࠌࠍ࡮ࡳࡰࡰࡴࡷࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠊࠊࠋࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࠧࡷ࡫ࡧࡩࡴ࠭ࠬࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤ⺪")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭⺫"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ⺬"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ⺭"),l11ll1_l1_ (u"ࠨ࠯ࠪ⺮"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⺯")+search+l11ll1_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ⺰")
	l11111_l1_(url)
	return
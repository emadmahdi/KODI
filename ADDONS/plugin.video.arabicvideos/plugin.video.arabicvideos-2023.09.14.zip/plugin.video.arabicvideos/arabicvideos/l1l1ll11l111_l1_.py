# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ恝")
headers = l11ll1_l1_ (u"ࠩࠪ恞") #{ l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ恟") : l11ll1_l1_ (u"ࠫࠬ恠") }
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ恡")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫ恢"),l11ll1_l1_ (u"ࠧศๆๆ่ࠬ恣"),l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠧ恤"),l11ll1_l1_ (u"ࠩ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹ࠭恥"),l11ll1_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ恦")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11111_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llll1l_l1_(url,True)
	elif mode==114: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ恧")+text)
	elif mode==115: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ恨")+text)
	elif mode==116: results = l1llll1l_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1lll1_l1_(l11l1l_l1_,l11ll1_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ恩"),l11ll1_l1_ (u"ࠧีษ๊ำࠥ็่าࠢํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪ࠴ࡶࠩ恪"),l11ll1_l1_ (u"ࠨࡱࡵࡨࡪࡸ࠽࡭ࡣࡶࡸࡤ࡬ࡩ࡭࡯ࡶࠫ恫"),headers)
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ恬"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ恭"),l11ll1_l1_ (u"ࠫࠬ恮"),119,l11ll1_l1_ (u"ࠬ࠭息"),l11ll1_l1_ (u"࠭ࠧ恰"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ恱"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ恲"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ恳"),l1ll111_l1_,115)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ恴"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ恵"),l1ll111_l1_,114)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ恶"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭恷"),l11ll1_l1_ (u"ࠧࠨ恸"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ恹"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊๋๊ำหࠪ恺"),l1ll111_l1_,111,l11ll1_l1_ (u"ࠪࠫ恻"),l11ll1_l1_ (u"ࠫࠬ恼"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ恽"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠧ恾"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ恿"),l11ll1_l1_ (u"ࠨࠩ悀"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ悁"),l11ll1_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭悂"))
		return
	else:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࠽ࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ悃"),block,re.DOTALL)
		for filter,l1lll1_l1_,title in items:
			url = l1ll111_l1_+filter
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悄"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ悅")+l111l1_l1_+title,url,111,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ悆"),filter)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭悇"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ悈"),l11ll1_l1_ (u"ࠪࠫ悉"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡩࡸ࡯ࡱࡦࡲࡻࡳࠨࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭悊"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ悋"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ悌"),l11ll1_l1_ (u"ࠧࠨ悍")).replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ悎"),l11ll1_l1_ (u"ࠩࠪ悏")).strip(l11ll1_l1_ (u"ࠪࠤࠬ悐"))
			if title in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ悑") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
			if l11ll1_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭悒") in l1lllll_l1_: title = l11ll1_l1_ (u"࠭ๆ๋ฬไู่่ࠧ悓")
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ悔"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ悕")+l111l1_l1_+title,l1lllll_l1_,111)
	return html
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ悖"),response=l11ll1_l1_ (u"ࠪࠫ悗")):
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ悘"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭悙")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ悚"),url,l11ll1_l1_ (u"ࠧࠨ悛"),headers,l11ll1_l1_ (u"ࠨࠩ悜"),l11ll1_l1_ (u"ࠩࠪ悝"),l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ悞"))
	html = response.content
	l1l1l11_l1_,items,l11l_l1_ = [],[],[]
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭悟"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡭࡬ࡪࡦࡨࡣࡤࡹ࡬ࡪࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ悠"),html,re.DOTALL)
	elif l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭悡"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠫ࠲࠯ࡅࠩࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ悢"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡼࡹ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠫ࠲࠯ࡅࠩࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ患"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ悤"): items = re.findall(l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ悥"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫ悦"),block,re.DOTALL)
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ悧"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ您"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭悩"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭悪"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ悫"),l11ll1_l1_ (u"๋ࠪิอแࠨ悬"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ悭"),l11ll1_l1_ (u"ࠬ฿ัืࠩ悮"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭悯"),l11ll1_l1_ (u"ࠧศๆห์๊࠭悰")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ悱") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ悲") in l1lllll_l1_: continue
		#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࠪࠨ࠶࠳࠹࠽ࠪ悳"),l11ll1_l1_ (u"ࠫࠫ࠭悴"))
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ悵"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ悶"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ悷"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠨใํ่๊࠭悸") in l1lllll_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ悹"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪห้ำไใหࠪ悺") in title and l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ悻") not in url:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ悼") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭悽"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸ࠯ࠨ悾") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ悿"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ惀") in l1lllll_l1_ and l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ惁") not in url:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ惂")
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ惃"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ惄") in url and l11ll1_l1_ (u"ࠧฮๆๅอࠬ情") in title:
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ惆"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ惇"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ惈"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ惉"): items = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡵࡱࡦࡤࡸࡪࡗࡵࡦࡴࡼ࠭࠳࠰࠿࠿ࠪ࠱࠯ࡄ࠯࠼ࠨ惊"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"࠭࠼࡭࡫ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ惋"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ惌"):
				title = title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ惍"),l11ll1_l1_ (u"ࠩࠪ惎")).replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭惏"),l11ll1_l1_ (u"ࠫࠬ惐"))
				if l11ll1_l1_ (u"ࠬࡅࠧ惑") in url: l1lllll_l1_ = url+l11ll1_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭惒")+title
				else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠧ惓")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ惔"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ惕")+title,l1lllll_l1_,111,l11ll1_l1_ (u"ࠪࠫ惖"),l11ll1_l1_ (u"ࠫࠬ惗"),l1lll1l1l1_l1_)
	return
def l1llll1l_l1_(url,l1lll111lll11_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ惘"),url,l11ll1_l1_ (u"࠭ࠧ惙"),headers,l11ll1_l1_ (u"ࠧࠨ惚"),l11ll1_l1_ (u"ࠨࠩ惛"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ惜"))
	html = response.content
	# l1lll1l_l1_ & l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠢࡧ࠱࡫ࡲࡥࡹࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭惝"),html,re.DOTALL)
	if len(l1l1l11_l1_)>1:
		if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭惞") in l1l1l11_l1_[0]: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[1]
		else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[1],l1l1l11_l1_[0]
	else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[0]
	for l11ll1111l_l1_ in range(2):
		if l1lll111lll11_l1_: mode,type,block = 116,l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ惟"),l1lll1l_l1_
		else: mode,type,block = 112,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ惠"),l1l11_l1_
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ惡"),block,re.DOTALL)
		if l1lll111lll11_l1_ and len(items)<2:
			l1lll111lll11_l1_ = False
			continue
		for l1lllll_l1_,l11l1l1l1_l1_,l1lll1l1l_l1_ in items:
			title = l11l1l1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠪ惢")+l1lll1l1l_l1_
			addMenuItem(type,l111l1_l1_+title,l1lllll_l1_,mode)
		break
	# l1l11_l1_ l11l1l11_l1_
	if not items and l11ll1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ惣") in html:
		l1l11llll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡷ࡫ࡡࡥࡥࡵࡹࡲࡨࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ惤"),html,re.DOTALL)
		if l1l11llll_l1_:
			block = l1l11llll_l1_[0]
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ惥"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1lllll_l1_ = l1l1_l1_[2]+l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ惦")
				l11111_l1_(l1lllll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ惧"),url,l11ll1_l1_ (u"ࠧࠨ惨"),headers,l11ll1_l1_ (u"ࠨࠩ惩"),l11ll1_l1_ (u"ࠩࠪ惪"),l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ惫"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡦࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ惬"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ惭"),block,re.DOTALL)
	l11l1l1ll_l1_ = l11ll1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ惮") in block
	download = l11ll1_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ惯") in block
	if   l11l1l1ll_l1_ and not download: l1lll111ll111_l1_,l111lll111ll_l1_ = l1l1_l1_[0],l11ll1_l1_ (u"ࠨࠩ惰")
	elif not l11l1l1ll_l1_ and download: l1lll111ll111_l1_,l111lll111ll_l1_ = l11ll1_l1_ (u"ࠩࠪ惱"),l1l1_l1_[0]
	elif l11l1l1ll_l1_ and download: l1lll111ll111_l1_,l111lll111ll_l1_ = l1l1_l1_[0],l1l1_l1_[1]
	else: l1lll111ll111_l1_,l111lll111ll_l1_ = l11ll1_l1_ (u"ࠪࠫ惲"),l11ll1_l1_ (u"ࠫࠬ想")
	# l11l1l1ll_l1_
	if l11l1l1ll_l1_:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ惴"),l1lll111ll111_l1_,l11ll1_l1_ (u"࠭ࠧ惵"),headers,l11ll1_l1_ (u"ࠧࠨ惶"),l11ll1_l1_ (u"ࠨࠩ惷"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭惸"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰࡪࡺࠠࡴࡧࡵࡺࡪࡸࡳࠩ࠰࠭ࡃ࠮ࡶ࡬ࡢࡻࡨࡶࠬ惹"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ惺"),l111l_l1_,re.DOTALL)
			for title,l1lllll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࡜࠰ࠩ惻"),l11ll1_l1_ (u"࠭࠯ࠨ惼"))
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ惽")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ惾")
				l1llll_l1_.append(l1lllll_l1_)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭惿"),l111lll111ll_l1_,l11ll1_l1_ (u"ࠪࠫ愀"),headers,l11ll1_l1_ (u"ࠫࠬ愁"),l11ll1_l1_ (u"ࠬ࠭愂"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ愃"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩࡪࡰࡩࡳ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ愄"),l11ll1ll_l1_,re.DOTALL)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾࠯࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ愅"),l111l_l1_,re.DOTALL)
			for l1lllll_l1_,title,l111llll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ愆")+title+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ愇")+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ愈")+l111llll_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ愉"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ愊"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ愋"),l11ll1_l1_ (u"ࠨ࠭ࠪ愌"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭愍")+search
	l1ll111_l1_,l111lll_l1_,l1ll1111l_l1_ = l1ll1l1lll1_l1_(url,l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ愎"),l11ll1_l1_ (u"ูࠫอ็ะࠢไ์ึ๊้ࠦࠢ࠰ࠤࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭意"),l11ll1_l1_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠨ愐"),headers)
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭愑"),l1ll1111l_l1_)
	return
# ===========================================
#     l1lll1llll_l1_ l1lll1lll1_l1_ l1llll1111_l1_
# ===========================================
def l1llllll11_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ愒"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ愓"),url,l11ll1_l1_ (u"ࠩࠪ愔"),headers,l11ll1_l1_ (u"ࠪࠫ愕"),l11ll1_l1_ (u"ࠫࠬ愖"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ愗"))
	html = response.content
	l1ll1lll_l1_ = []
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ愘"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# name & category & options block
		l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡑࡶࡧࡵࡽࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡴࡧ࡯ࡩࡨࡺࠧ愙"),block,re.DOTALL)
		l1lll111ll1l1_l1_,names,l1111l1_l1_ = zip(*l1ll1lll_l1_)
		l1ll1lll_l1_ = zip(names,l1lll111ll1l1_l1_,l1111l1_l1_)
	return l1ll1lll_l1_
def l1llll11ll_l1_(block):
	# id & title
	items = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠰ࠫ࠲࠯ࡅࠩ࠯࠾ࠪ愚"),block,re.DOTALL)
	return items
def l1lll111l1lll_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠩࡦࡥࡹࡃࠧ愛"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭愜"))
	if l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ愝") not in url: url = url+l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ愞")
	l1lllll1l1_l1_ = url.split(l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ感"))[0]
	l1llll1l1l_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ愠"))
	url = url.replace(l1lllll1l1_l1_,l1llll1l1l_l1_)
	#url = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ愡"),l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭愢"))
	url = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ愣"),l11ll1_l1_ (u"ࠫ࠴ࡅࠧ愤"))
	return url
l1lll111ll11l_l1_ = [l11ll1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭愥"),l11ll1_l1_ (u"࠭ࡹࡦࡣࡵࠫ愦"),l11ll1_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭愧"),l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ愨")]
l1lll111ll1ll_l1_ = [l11ll1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ愩"),l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ愪"),l11ll1_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ愫")]
def l1lll111_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ愬"),l11ll1_l1_ (u"࠭ࠧ愭"))
	url = url.split(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ愮"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ愯"),1)
	if filter==l11ll1_l1_ (u"ࠩࠪ愰"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ愱"),l11ll1_l1_ (u"ࠫࠬ愲")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ愳"))
	if type==l11ll1_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ愴"):
		if l1lll111ll1ll_l1_[0]+l11ll1_l1_ (u"ࠧ࠾ࠩ愵") not in l1l111ll_l1_: category = l1lll111ll1ll_l1_[0]
		for i in range(len(l1lll111ll1ll_l1_[0:-1])):
			if l1lll111ll1ll_l1_[i]+l11ll1_l1_ (u"ࠨ࠿ࠪ愶") in l1l111ll_l1_: category = l1lll111ll1ll_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ愷")+category+l11ll1_l1_ (u"ࠪࡁ࠵࠭愸")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭愹")+category+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ愺")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨ愻"))+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ愼")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪ愽"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ愾"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ愿")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ慀"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ慁"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"࠭ࠧ慂"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ慃"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠨࠩ慄"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭慅")+l1l111l1_l1_
		l11l111_l1_ = l1lll111l1lll_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ慆"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ慇"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ慈"),l111l1_l1_+l11ll1_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭慉")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭慊"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭態"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ慌"),l11ll1_l1_ (u"ࠪࠫ慍"),9999)
	l1ll1lll_l1_ = l1llllll11_l1_(url)
	dict = {}
	for name,l1ll1l1l_l1_,block in l1ll1lll_l1_:
		name = name.replace(l11ll1_l1_ (u"่๊ࠫࠠࠨ慎"),l11ll1_l1_ (u"ࠬ࠭慏"))
		items = l1llll11ll_l1_(block)
		if l11ll1_l1_ (u"࠭࠽ࠨ慐") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ慑"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<2:
				if l1ll1l1l_l1_==l1lll111ll1ll_l1_[-1]:
					l11l111_l1_ = l1lll111l1lll_l1_(l111lll_l1_)
					l11111_l1_(l11l111_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ慒")+l1l11lll_l1_)
				return
			else:
				if l1ll1l1l_l1_==l1lll111ll1ll_l1_[-1]:
					l11l111_l1_ = l1lll111l1lll_l1_(l111lll_l1_)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ慓"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ慔"),l11l111_l1_,111)
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ慕"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭慖"),l111lll_l1_,115,l11ll1_l1_ (u"࠭ࠧ慗"),l11ll1_l1_ (u"ࠧࠨ慘"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭慙"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ慚")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁ࠵࠭慛")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭慜")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ慝")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ慞")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ慟"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ慠")+name,l111lll_l1_,114,l11ll1_l1_ (u"ࠩࠪ慡"),l11ll1_l1_ (u"ࠪࠫ慢"),l1l11lll_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭慣"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬ慤"): option = l11ll1_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭慥")
			elif value==l11ll1_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧ慦"): option = l11ll1_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪ慧")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ慨") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ慩"),value,re.DOTALL)[0]
			dict[l1ll1l1l_l1_][value] = option
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫ࠭慪")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃࠧ慫")+option
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ慬")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾ࠩ慭")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ慮")+l1l1ll1l_l1_
			title = option+l11ll1_l1_ (u"ࠩࠣ࠾ࠬ慯")#+dict[l1ll1l1l_l1_][l11ll1_l1_ (u"ࠪ࠴ࠬ慰")]
			title = option+l11ll1_l1_ (u"ࠫࠥࡀࠧ慱")+name
			if type==l11ll1_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ慲"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭慳"),l111l1_l1_+title,url,114,l11ll1_l1_ (u"ࠧࠨ慴"),l11ll1_l1_ (u"ࠨࠩ慵"),l1ll1l11_l1_)		# +l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ慶"))
			elif type==l11ll1_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ慷") and l1lll111ll1ll_l1_[-2]+l11ll1_l1_ (u"ࠫࡂ࠭慸") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ慹"))
				l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ慺")+l11lllll_l1_
				l11l111_l1_ = l1lll111l1lll_l1_(l111lll_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ慻"),l111l1_l1_+title,l11l111_l1_,111)
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ慼"),l111l1_l1_+title,url,115,l11ll1_l1_ (u"ࠩࠪ慽"),l11ll1_l1_ (u"ࠪࠫ慾"),l1ll1l11_l1_)
	return
def l1l11111_l1_(filters,mode):
	# mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭慿")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ憀")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪ憁")					all l1l1l1ll_l1_ & l1lllll111_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠧ࠾ࠨࠪ憂"),l11ll1_l1_ (u"ࠨ࠿࠳ࠪࠬ憃"))
	filters = filters.strip(l11ll1_l1_ (u"ࠩࠩࠫ憄"))
	l1l11l11_l1_ = {}
	if l11ll1_l1_ (u"ࠪࡁࠬ憅") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠫࠫ࠭憆"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠬࡃࠧ憇"))
			l1l11l11_l1_[var] = value
	l1ll11ll_l1_ = l11ll1_l1_ (u"࠭ࠧ憈")
	for key in l1lll111ll11l_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠧ࠱ࠩ憉")
		if l11ll1_l1_ (u"ࠨࠧࠪ憊") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ憋") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬ憌"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨ憍")+value
		elif mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ憎") and value!=l11ll1_l1_ (u"࠭࠰ࠨ憏"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࠧࠩ憐")+key+l11ll1_l1_ (u"ࠨ࠿ࠪ憑")+value
		elif mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭憒"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠪࠬ憓")+key+l11ll1_l1_ (u"ࠫࡂ࠭憔")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ憕"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨ憖"))
	l1ll11ll_l1_ = l1ll11ll_l1_.replace(l11ll1_l1_ (u"ࠧ࠾࠲ࠪ憗"),l11ll1_l1_ (u"ࠨ࠿ࠪ憘"))
	return l1ll11ll_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭憙")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡘࡎࡎࡠࠩ憚")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫ็์่ศฬࠣๅ฻อฦ๋หࠪ憛"),l11ll1_l1_ (u"ࠬ็วาีๆ์ࠬ憜"),l11ll1_l1_ (u"࠭ࡓࡩࡱࡺࠤࡲࡵࡲࡦࠩ憝")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l11111_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1llll1l_l1_(url,text)
	elif mode==584: results = l1l111_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ憞"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ憟"),l11ll1_l1_ (u"ࠩࠪ憠"),l11ll1_l1_ (u"ࠪࠫ憡"),l11ll1_l1_ (u"ࠫࠬ憢"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ憣"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭憤"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ憥"),l11ll1_l1_ (u"ࠨࠩ憦"),589,l11ll1_l1_ (u"ࠩࠪ憧"),l11ll1_l1_ (u"ࠪࠫ憨"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ憩"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ憪"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭憫"),l11ll1_l1_ (u"ࠧࠨ憬"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ憭"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ憮"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠪࠫ憯"))
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ憰"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ憱"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ憲")+l111l1_l1_+title,l1lllll_l1_,584)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ憳"),url,l11ll1_l1_ (u"ࠨࠩ憴"),l11ll1_l1_ (u"ࠩࠪ憵"),l11ll1_l1_ (u"ࠪࠫ憶"),l11ll1_l1_ (u"ࠫࠬ憷"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ憸"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ憹"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ憺"),l11ll1_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ憻"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭憼"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠪࠫ憽"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ憾"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ憿"),l11ll1_l1_ (u"࠭ࠧ懀"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ懁"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣࠫ懂")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ懃"),l111l1_l1_+title,l1lllll_l1_,581)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ懄"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭懅"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ懆"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭懇"),l11ll1_l1_ (u"ࠧࠨ懈"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ應"),l111l1_l1_+title,l1lllll_l1_,581)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠩࠪ懊")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ懋"),l11ll1_l1_ (u"ࠫࠬ懌"),request,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ懍"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ懎"),url,l11ll1_l1_ (u"ࠧࠨ懏"),l11ll1_l1_ (u"ࠨࠩ懐"),l11ll1_l1_ (u"ࠩࠪ懑"),l11ll1_l1_ (u"ࠪࠫ懒"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ懓"))
	html = response.content
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭懔"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭懕"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ懖"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭懗"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ懘"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ懙"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ懚"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ懛"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ懜"),l11ll1_l1_ (u"ࠧไๆํฬࠬ懝"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ懞"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ懟"),l11ll1_l1_ (u"้ࠪออัศหࠪ懠"),l11ll1_l1_ (u"ࠫ฾ืึࠨ懡"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ懢"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ懣"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧ懤")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ懥"))
		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ懦") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ懧")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭懨"))
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ懩") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ懪")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ懫"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ懬"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ懭"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ懮"),l111l1_l1_+title,l1lllll_l1_,582,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫ懯") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ懰") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭懱"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ懲") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ懳"),l111l1_l1_+title,l1lllll_l1_,581,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ懴"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
	if request not in [l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬ懵"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭懶")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭懷"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ懸"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ懹"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ懺")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ懻"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ懼"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ懽")+title,l1lllll_l1_,581)
		l1llll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ懾"),html,re.DOTALL)
		if l1llll1ll1_l1_:
			l1lllll_l1_ = l1llll1ll1_l1_[0]
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭懿"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ戀"),l1lllll_l1_,581)
	return
def l1llll1l_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ戁"),l11ll1_l1_ (u"ࠩࠪ戂"),l1l1l_l1_,url)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ戃"),l11ll1_l1_ (u"ࠫ࠶࠷࠱࠲ࠢࠣࠫ戄")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ戅"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ戆"),url,l11ll1_l1_ (u"ࠧࠨ戇"),l11ll1_l1_ (u"ࠨࠩ戈"),l11ll1_l1_ (u"ࠩࠪ戉"),l11ll1_l1_ (u"ࠪࠫ戊"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ戋"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡴࡡࡷ࠯ࡶࡩࡦࡹ࡯࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ戌"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ戍"),str(l1l1l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ戎"),str(l1l111l_l1_))
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ戏"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩࠦࠫ成"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ我"),l111l1_l1_+title,url,583,l11ll1_l1_ (u"ࠫࠬ戒"),l11ll1_l1_ (u"ࠬ࠭戓"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࠫ戔")+l1l1l_l1_+l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭戕"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ或"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ戗")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ战"))
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ戙"),l111l1_l1_+title,l1lllll_l1_,582)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭戚"),block,re.DOTALL)
			for l1lllll_l1_,title,l1lll1_l1_ in items:
				if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ戛") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ戜")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ戝"))
				addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ戞"),l111l1_l1_+title,l1lllll_l1_,582)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ戟"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ戠"),url,l11ll1_l1_ (u"ࠬ࠭戡"),l11ll1_l1_ (u"࠭ࠧ戢"),l11ll1_l1_ (u"ࠧࠨ戣"),l11ll1_l1_ (u"ࠨࠩ戤"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ戥"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ戦"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ戧") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ戨")+l1lllll_l1_
	#//www.l1lll111l1l11_l1_.l1lll111l11ll_l1_/l1lll111l1l1l_l1_/?l1lll111l1ll1_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࡨࡢࡵ࡫ࡁࠬ戩"))[1]
	parts = hash.split(l11ll1_l1_ (u"ࠧࡠࡡࠪ截"))
	l1l11llll11l_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11ll1_l1_ (u"ࠨ࠿ࠪ戫"))
			if kodi_version>18.99: part = part.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ戬"))
			l1l11llll11l_l1_.append(part)
		except: pass
	l1l1_l1_ = l11ll1_l1_ (u"ࠪࡂࠬ戭").join(l1l11llll11l_l1_)
	l1l1_l1_ = l1l1_l1_.splitlines()
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ戮"),str(l1l1_l1_))
	if l11ll1_l1_ (u"ࠬ࡬ࡡࡳࡵࡲࡰࠬ戯") not in str(l1l1_l1_):
		for l1lllll_l1_ in l1l1_l1_:
			title,l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࠠ࠾ࡀࠣࠫ戰"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ戱")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ戲")
			l1llll_l1_.append(l1lllll_l1_)
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ戳"),l1llll_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ戴"),url)
	else:
		title,l1lllll_l1_ = l1l1_l1_[0].split(l11ll1_l1_ (u"ࠫࠥࡃ࠾ࠡࠩ戵"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭戶"),l11ll1_l1_ (u"࠭ࠧ户"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ戸"),l11ll1_l1_ (u"ࠨ้ำหࠥอไโ์า๎ํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์ࠧ戹")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ戺")+l11ll1_l1_ (u"ࠪ๎ึา้ࠡษ็้าอ่ๅห่ࠣฬำโศࠩ戻")+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ戼")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭戽"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ戾"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ房"),l11ll1_l1_ (u"ࠨ࠭ࠪ所"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪ扁")+search
	l11111_l1_(url)
	return
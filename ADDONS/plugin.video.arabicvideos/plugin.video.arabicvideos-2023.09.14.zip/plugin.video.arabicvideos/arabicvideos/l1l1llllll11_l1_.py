# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ䲇")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬ䲈")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧศ่๋ห฾ࠦวโๆส้ࠬ䲉"),l11ll1_l1_ (u"ࠨฮ๋ำฬะࠠศใ็ห๊࠭䲊")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11111_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llll1l_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲋"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䲌"),l11ll1_l1_ (u"ࠫࠬ䲍"),389,l11ll1_l1_ (u"ࠬ࠭䲎"),l11ll1_l1_ (u"࠭ࠧ䲏"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䲐"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䲑"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䲒"),l11ll1_l1_ (u"ࠪࠫ䲓"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䲔"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䲕")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧ䲖"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠧࠨ䲗"),l11ll1_l1_ (u"ࠨࠩ䲘"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䲙"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲚"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䲛")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไอษ้ฬ๏ฯࠧ䲜"),l11l1l_l1_,381,l11ll1_l1_ (u"࠭ࠧ䲝"),l11ll1_l1_ (u"ࠧࠨ䲞"),l11ll1_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ䲟"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䲠"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䲡"),l11ll1_l1_ (u"ࠫࠬ䲢"),l11ll1_l1_ (u"ࠬ࠭䲣"),l11ll1_l1_ (u"࠭ࠧ䲤"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䲥"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䲦"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲧"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䲨")+l111l1_l1_+title,l11l1l_l1_,381,l11ll1_l1_ (u"ࠫࠬ䲩"),l11ll1_l1_ (u"ࠬ࠭䲪"),l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䲫")+str(seq))
	block = l11ll1_l1_ (u"ࠧࠨ䲬")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡦࡦࡲࡶࠧ࠭䲭"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭䲮"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䲯"),block,re.DOTALL)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䲰"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䲱"),l11ll1_l1_ (u"࠭ࠧ䲲"),9999)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠧศๆฦ฽้๏ࠠๆึส๋ิฯࠧ䲳"):
			if first:
				title = l11ll1_l1_ (u"ࠨษ็หๆ๊วๆࠢࠪ䲴")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠥ࠭䲵")+title
		if title not in l1l11l_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲶"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䲷")+l111l1_l1_+title,l1lllll_l1_,381)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䲸"),l11ll1_l1_ (u"࠭ࠧ䲹"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䲺"),url,l11ll1_l1_ (u"ࠨࠩ䲻"),l11ll1_l1_ (u"ࠩࠪ䲼"),l11ll1_l1_ (u"ࠪࠫ䲽"),l11ll1_l1_ (u"ࠫࠬ䲾"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䲿"))
	html = response.content
	if type==l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䳀"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡤࡶࡨ࡮࠭ࡱࡣࡪࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䳁"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳂"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ䳃"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠧ䳄"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		z = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䳅"),block,re.DOTALL)
		l1llll_l1_,l1l1111l1_l1_,l1lll11l_l1_ = zip(*z)
		items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	elif type==l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䳆"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࡵ࠰ࡸࡻࡹࡨࡰࡹࡶࠦ࠭࠴ࠪࡀࠫ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䳇"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䳈"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䳉") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䳊"),l11ll1_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡶࡸࡦࡸࡴ࠿ࠩ䳋"))
		html = html.replace(l11ll1_l1_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䳌"),l11ll1_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䳍"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡶࡤࡶࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡮ࡥࡀࠪ䳎"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==2: items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䳏"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠩࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࢁࡹࡩࡥࡧࡥࡥࡷ࠯ࠧ䳐"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ䳑") in url:
				items = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䳒"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠫ࠴ࡷࡵࡢ࡮࡬ࡸࡾ࠵ࠧ䳓") in url:
				items = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳔"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䳕"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭䳖") in title:
			title = re.findall(l11ll1_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳗"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭䳘")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䳙")+title
		l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ䳚"),title,re.DOTALL)
		if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ䳛") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳜"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䳝") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䳞"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ䳟") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳠"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ䳡") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳢"),l111l1_l1_+title,l1lllll_l1_,381,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䳣"),l111l1_l1_+title,l1lllll_l1_,382,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࡑࡣࡪࡩࠥ࠮࠮ࠫࡁࠬࠤࡴ࡬ࠠࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䳤"),html,re.DOTALL)
	if l1l1l11_l1_:
		current = l1l1l11_l1_[0][0]
		last = l1l1l11_l1_[0][1]
		block = l1l1l11_l1_[0][2]
		items = re.findall(l11ll1_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥ䳥"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title==l11ll1_l1_ (u"ࠩࠪ䳦") or title==last: continue
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳧"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ䳨")+title,l1lllll_l1_,381,l11ll1_l1_ (u"ࠬ࠭䳩"),l11ll1_l1_ (u"࠭ࠧ䳪"),type)
		#if title==last:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ䳫")+title+l11ll1_l1_ (u"ࠨ࠱ࠪ䳬"),l11ll1_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ䳭")+last+l11ll1_l1_ (u"ࠪ࠳ࠬ䳮"))
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳯"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮาุࠢๅาฯࠠࠨ䳰")+last,l1lllll_l1_,381,l11ll1_l1_ (u"࠭ࠧ䳱"),l11ll1_l1_ (u"ࠧࠨ䳲"),type)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䳳"),url,l11ll1_l1_ (u"ࠩࠪ䳴"),l11ll1_l1_ (u"ࠪࠫ䳵"),l11ll1_l1_ (u"ࠫࠬ䳶"),l11ll1_l1_ (u"ࠬ࠭䳷"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䳸"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䳹"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,False):
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䳺"),l111l1_l1_+l11ll1_l1_ (u"ࠩสู่๊ไิๆ่้้ࠣศศำࠣ์ฬ๊ๅษำ่ะ๋ࠥๆฺ้ࠪ䳻"),l11ll1_l1_ (u"ࠪࠫ䳼"),9999)
		return
	if l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ䳽") in url or l11ll1_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ䳾") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨ࡫ࡷࡩࡲ࠭࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ䳿"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[1]
			l1llll1l_l1_(l111lll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠬ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡣࡶࡸࠧ࠭ࠧࠨ䴀"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡲࡺࡳࡥࡳࡣࡱࡨࡴ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ䴁"),block,re.DOTALL)
		for l1lll1_l1_,l1ll1l1_l1_,l1lllll_l1_,name in items:
			title = l1ll1l1_l1_+l11ll1_l1_ (u"ࠩࠣ࠾ࠥ࠭䴂")+name+l11ll1_l1_ (u"ࠪࠤฬ๊อๅไฬࠫ䴃")
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䴄"),l111l1_l1_+title,l1lllll_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䴅"),url,l11ll1_l1_ (u"࠭ࠧ䴆"),l11ll1_l1_ (u"ࠧࠨ䴇"),l11ll1_l1_ (u"ࠨࠩ䴈"),l11ll1_l1_ (u"ࠩࠪ䴉"),l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䴊"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴋"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠨࠢࡪࡦࡀࠫࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶࠭ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠬࠧࡹࡨࡦࡣࡧࡩࡷࠨࡼࠨࡲࡤ࡫ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧࠪࠤࠥࠦ䴌"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡸ࡫ࡲࡷࡧࡵࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ䴍"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䴎")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䴏")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭࠯ࡦࡰࡴࡹࡥࠣࠩ䴐"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡣࡤࡥࡤ࡭ࡡࡪࡨࡷ࡯ࡶࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䴑"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䴒")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䴓")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䴔"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䴕"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ䴖"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ䴗"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ䴘"),l11ll1_l1_ (u"ࠫ࠰࠭䴙"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䴚")+search
	l11111_l1_(url,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䴛"))
	return
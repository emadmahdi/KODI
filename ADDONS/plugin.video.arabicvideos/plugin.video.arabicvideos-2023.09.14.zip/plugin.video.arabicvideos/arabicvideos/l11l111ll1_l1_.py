# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬỆ")
def MAIN(mode,url):
	if   mode==330: results = l11ll11l11_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l11llll_l1_()
	elif mode==333: results = l111lllll1_l1_()
	elif mode==334: results = l1ll1111ll_l1_(url)
	else: results = False
	return results
def l1ll1111ll_l1_(l11l1l1l11_l1_):
	try: os.remove(l11l1l1l11_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩệ")))
	except: os.remove(l11l1l1l11_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫỈ"))
	return
def l111lllll1_l1_():
	message = l11ll1_l1_ (u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬỉ")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨỊ"),l11ll1_l1_ (u"ࠨࠩị"),l11ll1_l1_ (u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠศๆ่่ๆอสࠨỌ"),message)
	return
def l11ll11l11_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨọ"),l11ll1_l1_ (u"ࠫ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩỎ"),l11ll1_l1_ (u"ࠬ࠭ỏ"),333)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫỐ"),l11ll1_l1_ (u"ࠧห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧố"),l11ll1_l1_ (u"ࠨࠩỒ"),332)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧồ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪỔ"),l11ll1_l1_ (u"ࠫࠬổ"),9999)
	l11l1ll1l1_l1_ = l11l11ll1l_l1_()
	mtime = os.stat(l11l1ll1l1_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1ll11l_l1_ = os.listdir(l11l1ll1l1_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪỖ")))
	else: l11l1ll11l_l1_ = os.listdir(l11l1ll1l1_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫỗ")))
	for filename in l11l1ll11l_l1_:
		if kodi_version>18.99: filename = filename.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬỘ"))
		if not filename.startswith(l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧộ")): continue
		filepath = os.path.join(l11l1ll1l1_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11ll11111_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧỚ"))
			except: pass
			filename = filename.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨớ"))
		filepath = os.path.join(l11l1ll1l1_l1_,filename)
		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪỜ"),filename,filepath,331)
	return
def l11l11ll1l_l1_():
	l11l1ll1l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨờ"))
	if l11l1ll1l1_l1_: return l11l1ll1l1_l1_
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩỞ"),addoncachefolder)
	return addoncachefolder
def l11l11llll_l1_():
	l11l1ll1l1_l1_ = l11l11ll1l_l1_()
	l11l111l1l_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧở"),l11ll1_l1_ (u"ࠨࠩỠ"),l11ll1_l1_ (u"ࠩࠪỡ"),l11l1ll1l1_l1_,l11ll1_l1_ (u"๋ࠪีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧỢ"))
	if l11l111l1l_l1_==1:
		newpath = l11l1l111l_l1_(3,l11ll1_l1_ (u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨợ"),l11ll1_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯ࠫỤ"),l11ll1_l1_ (u"࠭ࠧụ"),False,True,l11l1ll1l1_l1_)
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧỦ"),l11ll1_l1_ (u"ࠨࠩủ"),l11ll1_l1_ (u"ࠩࠪỨ"),newpath,l11ll1_l1_ (u"๋ࠪีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧứ"))
		if l1ll111lll_l1_==1:
			settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧỪ"),newpath)
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ừ"),l11ll1_l1_ (u"࠭ࠧỬ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪử"),l11ll1_l1_ (u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩỮ"))
	#if not l11l111l1l_l1_ or not l1ll111lll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪữ"),l11ll1_l1_ (u"ࠪࠫỰ"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧự"),l11ll1_l1_ (u"ࠬะๅࠡษ็฾ฬวࠠศๆ฼้้๐ษࠨỲ"))
	return
def l11l1l1111_l1_(filename):
	l11ll111ll_l1_ = l11ll1_l1_ (u"࠭ࠧỳ").join(l11ll1111l_l1_ for l11ll1111l_l1_ in filename if l11ll1111l_l1_ not in l11ll1_l1_ (u"ࠧ࡝࠱ࠥ࠾࠯ࡅ࠼࠿ࡾࠪỴ")+half_triangular_colon)
	return l11ll111ll_l1_
def l11l11ll11_l1_(url,l111lll1ll_l1_=l11ll1_l1_ (u"ࠨࠩỵ"),l1l1l1l1_l1_=l11ll1_l1_ (u"ࠩࠪỶ")):
	#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪỷ"),l11ll1_l1_ (u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫỸ"))
	LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬỹ"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ỻ")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪỻ"))
	if not l111lll1ll_l1_: l111lll1ll_l1_ = l11l1lll1l_l1_(url,l1l1l1l1_l1_)
	#if not l111lll1ll_l1_:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩỼ"),l11ll1_l1_ (u"ࠩࠪỽ"),l11ll1_l1_ (u"ࠪฮุ๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧỾ"),l11ll1_l1_ (u"ࠫฬ๊ๅๅใ้๋ࠣࠦๆ้฻ࠣࠫỿ")+l111lll1ll_l1_+l11ll1_l1_ (u"่ࠬࠦศๆหี๋อๅอࠢะห้๐วࠡ฼ํีࠥาว่ิ่ࠣฯำๅ๋ๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่๊๊แศฬࠪἀ"))
	#	LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫἁ"),LOGGING(script_name)+l11ll1_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡷࡽࡵ࡫࠯ࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩἂ")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫἃ"))
	#	return False
	l11l1ll1l1_l1_ = l11l11ll1l_l1_()
	l11l1llll1_l1_ = l11l1l1lll_l1_()
	filename = l11l1llll1_l1_.replace(l11ll1_l1_ (u"ࠩࠣࠫἄ"),l11ll1_l1_ (u"ࠪࡣࠬἅ"))
	filename = l11l1l1111_l1_(filename)
	#l111lll1ll_l1_ = l111lll1ll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩἆ"))
	filename = l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡢࠫἇ")+str(int(now))[-4:]+l11ll1_l1_ (u"࠭࡟ࠨἈ")+filename+l111lll1ll_l1_
	l111llllll_l1_ = os.path.join(l11l1ll1l1_l1_,filename)
	headers = {}
	headers[l11ll1_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩἉ")] = l11ll1_l1_ (u"ࠨࠩἊ")
	headers[l11ll1_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩἋ")] = l11ll1_l1_ (u"ࠪ࠮࠴࠰ࠧἌ")
	url = url.replace(l11ll1_l1_ (u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧἍ"),l11ll1_l1_ (u"ࠬ࠭Ἆ"))
	if l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫἏ") in url:
		l111lll_l1_,l111llll11_l1_ = url.rsplit(l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬἐ"),1)
		l111llll11_l1_ = l111llll11_l1_.replace(l11ll1_l1_ (u"ࠨࡾࠪἑ"),l11ll1_l1_ (u"ࠩࠪἒ")).replace(l11ll1_l1_ (u"ࠪࠪࠬἓ"),l11ll1_l1_ (u"ࠫࠬἔ"))
	else: l111lll_l1_,l111llll11_l1_ = url,None
	if not l111llll11_l1_: l111llll11_l1_ = l11llllll_l1_()
	if l111llll11_l1_: headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩἕ")] = l111llll11_l1_
	if l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ἖") in l111lll_l1_: l111lll_l1_,l11l11l111_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ἗"),1)
	else: l111lll_l1_,l11l11l111_l1_ = l111lll_l1_,l11ll1_l1_ (u"ࠨࠩἘ")
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠩࡿࠫἙ")).strip(l11ll1_l1_ (u"ࠪࠪࠬἚ")).strip(l11ll1_l1_ (u"ࠫࢁ࠭Ἓ")).strip(l11ll1_l1_ (u"ࠬࠬࠧἜ"))
	l11l11l111_l1_ = l11l11l111_l1_.replace(l11ll1_l1_ (u"࠭ࡼࠨἝ"),l11ll1_l1_ (u"ࠧࠨ἞")).replace(l11ll1_l1_ (u"ࠨࠨࠪ἟"),l11ll1_l1_ (u"ࠩࠪἠ"))
	if l11l11l111_l1_:	headers[l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫἡ")] = l11l11l111_l1_
	LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫἢ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ἣ")+l111lll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩἤ")+str(headers)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧἥ")+l111llllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫἦ"))
	l11ll11l1l_l1_ = 1024*1024
	l11l1lll11_l1_ = 0
	try:
		l11l1ll1ll_l1_ =	xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬἧ"))
		l11l1ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡠࡩ࠱ࠧἨ"),l11l1ll1ll_l1_)
		l11l1lll11_l1_ = int(l11l1ll1ll_l1_[0])
	except: pass
	if not l11l1lll11_l1_:
		try:
			l11l1l1l1l_l1_ = os.l111lll1l1_l1_(l11l1ll1l1_l1_)
			l11l1lll11_l1_ = l11l1l1l1l_l1_.f_frsize*l11l1l1l1l_l1_.f_bavail//l11ll11l1l_l1_
		except: pass
	if not l11l1lll11_l1_:
		try:
			l11l1l1l1l_l1_ = os.l11ll111l1_l1_(l11l1ll1l1_l1_)
			l11l1lll11_l1_ = l11l1l1l1l_l1_.f_frsize*l11l1l1l1l_l1_.f_bavail//l11ll11l1l_l1_
		except: pass
	if not l11l1lll11_l1_:
		try:
			import shutil
			total,l11l11lll1_l1_,l11l11l1ll_l1_ = shutil.l11ll1l111_l1_(l11l1ll1l1_l1_)
			l11l1lll11_l1_ = l11l11l1ll_l1_//l11ll11l1l_l1_
		except: pass
	if not l11l1lll11_l1_:
		l11ll1l11l_l1_(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪἩ"),l11ll1_l1_ (u"๋ࠬำศฯฬࠤฬ๊สฯิํ๊๋ࠥฬ่๊็อࠬἪ"),l11ll1_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐อะั้ࠣ็ีวา่ࠢืฬำษࠡษ็ฮำุ๊็ࠢส่ๆอั฻หࠣๅ๏ࠦฬ่ษี็ࠥ๎ูๅ์๊ࠤๆอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ้์๋ࠠ฻่่ࠥ฿ๆะๅࠣษ้๏ࠠฤ่ࠣ๎็๎ๅࠡ็หี๊า๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦศฮๆ๋ࠣีํࠠศๆุ่่๊ษࠡๆส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡไาࠤ๏ูศษࠢส้ฯ๊วยࠢฯ๋ฬุใࠡสส่๊๊แศฬࠣ์์ึวࠡใํ๋ࠥิื้ำฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอ฻่าหูࠣา๐อส๋่ࠢ์ึวࠡษ็ือฮࠠใษ่ࠤฬ๊ๅษำ่ะ๋ࠥฤใฬสࠤอ๋ๆฺࠢส่อืๆศ็ฯࠤ๊์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪἫ"),l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪἬ"))
		LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ἥ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡦ࡬ࡷࡰࠦࡦࡳࡧࡨࠤࡸࡶࡡࡤࡧࠪἮ"))
		return False
	import requests
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩἯ"):
		l1lll11l_l1_,l1llll_l1_ = l11ll11ll1_l1_(l111lll_l1_,headers)
		#DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩἰ"), l1lll11l_l1_)
		#DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪἱ"), l1llll_l1_)
		if len(l1lll11l_l1_)==0:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪἲ"),l11ll1_l1_ (u"ࠧࠨἳ"))
			return False
		elif len(l1lll11l_l1_)==1: l1l_l1_ = 0
		elif len(l1lll11l_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ἴ"), l1lll11l_l1_)
			if l1l_l1_ == -1 :
				DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬἵ"),l11ll1_l1_ (u"ࠪࠫἶ"))
				return False
		l111lll_l1_ = l1llll_l1_[l1l_l1_]
	filesize = 0
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪἷ"):
		l111llllll_l1_ = l111llllll_l1_.rsplit(l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫἸ"))[0]+l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫἹ")
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫἺ"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩἻ"),headers,l11ll1_l1_ (u"ࠩࠪἼ"),l11ll1_l1_ (u"ࠪࠫἽ"),l11ll1_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡠࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫἾ"))
		l1llll111_l1_ = response.content
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢࠣࡆ࡚ࡗࡍࡓࡌ࠺࠯ࠬࡂ࡟ࡡࡴ࡜ࡳ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧἿ"),l1llll111_l1_+l11ll1_l1_ (u"࠭࡜࡯࡞ࡵࠫὀ"),re.DOTALL)
		if not l1l1_l1_:
			LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬὁ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤ࡙࡮ࡥࠡ࡯࠶ࡹ࠽ࠦࡦࡪ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡮ࡡࡷࡧࠣࡸ࡭࡫ࠠࡳࡧࡴࡹ࡮ࡸࡥࡥࠢ࡯࡭ࡳࡱࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫὂ")+l111lll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬὃ"))
			return False
		l1lllll_l1_ = l1l1_l1_[0]
		if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨὄ")):
			if l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠫ࠴࠵ࠧὅ")): l1lllll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠬࡀࠧ὆"),1)[0]+l11ll1_l1_ (u"࠭࠺ࠨ὇")+l1lllll_l1_
			elif l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠧ࠰ࠩὈ")): l1lllll_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬὉ"))+l1lllll_l1_
			else: l1lllll_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠩ࠲ࠫὊ"),1)[0]+l11ll1_l1_ (u"ࠪ࠳ࠬὋ")+l1lllll_l1_
		response = requests.request(l11ll1_l1_ (u"ࠫࡌࡋࡔࠨὌ"),l1lllll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l11l1l1_l1_ = len(l1l1_l1_)
		filesize = chunksize*l11l11l1l1_l1_
	else:
		chunksize = 1*l11ll11l1l_l1_
		response = requests.request(l11ll1_l1_ (u"ࠬࡍࡅࡕࠩὍ"),l111lll_l1_,headers=headers,verify=False,stream=True)
		if l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ὎") in response.headers: filesize = int(response.headers[l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ὏")])
		l11l11l1l1_l1_ = int(filesize//chunksize)
	#l11l1lllll_l1_ = l11l11l1l1_l1_+1
	l11l1lllll_l1_ = int(filesize//l11ll11l1l_l1_)+1
	if filesize<21000:
		LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ὐ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫὑ")+l111lll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧὒ")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪὓ")+str(l11l1lll11_l1_)+l11ll1_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨὔ")+l111llllll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩὕ"))
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨὖ"),l11ll1_l1_ (u"ࠨࠩὗ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ὘"),l11ll1_l1_ (u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬὙ"))
		return False
	l11l111lll_l1_ = 400
	l11l1111l1_l1_ = l11l1lll11_l1_-l11l1lllll_l1_
	if l11l1111l1_l1_<l11l111lll_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ὚"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫὛ")+l111lll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ὜")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭Ὕ")+str(l11l1lll11_l1_)+l11ll1_l1_ (u"ࠨࠢࡐࡆࠥ࠳ࠠࠨ὞")+str(l11l111lll_l1_)+l11ll1_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬὟ")+l111llllll_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭ὠ"))
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬὡ"),l11ll1_l1_ (u"ࠬ࠭ὢ"),l11ll1_l1_ (u"࠭ไศࠢํ์ัีࠠๆีสัฮࠦใศใํอ๊ࠥไหฯ่๎้࠭ὣ"),l11ll1_l1_ (u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํࠠฮฮ่๋ࠥ࠭ὤ")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦࠧὥ")+str(l11l1lll11_l1_)+l11ll1_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ไๅ็ะหๆ฾ษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสา์๋ࠦๅีษๆ่ࠥ๐ฬษࠢศฬ็อมࠡࠩὦ")+str(l11l111lll_l1_)+l11ll1_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦแศำ฽อࠥีวว็สࠤํํะศ่ࠢ฽๋อ็ࠡล้ࠤัํวำๅ่ࠣฬࠦส้ฮาࠤๆ๐็ࠡ็ึหาฯࠠไษไ๎ฮࠦไหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬࠬὧ"))
		return False
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫὨ"),l11ll1_l1_ (u"ࠬ࠭Ὡ"),l11ll1_l1_ (u"࠭ࠧὪ"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦฟࠨὫ"),l11ll1_l1_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฯฯ้์ࠦสใำํฬฬࠦࠧὬ")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠหไิ๎ออࠠࠨὭ")+str(l11l1lll11_l1_)+l11ll1_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่่ࠦาสࠤฬ๊ๅๅใࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡๆ็ฮา๋๊ๅ่๊ࠢࠥอไฦ่อี๋ะࠠฦๆ์ࠤัํวำๅࠣ࠲ࠥํไࠡษ้ฮ๋ࠥสฤๅาࠤํะั๋ัࠣห้อำห็ิหึࠦศหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฤ࠭Ὦ"))
	if l1ll111lll_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬὯ"),l11ll1_l1_ (u"ࠬ࠭ὰ"),l11ll1_l1_ (u"࠭ࠧά"),l11ll1_l1_ (u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬὲ"))
		LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨέ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡶࡪ࡬ࡵࡴࡧࡧࠤࡹࡵࠠࡴࡶࡤࡶࡹࠦࡴࡩࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡵࡦࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬὴ")+l111lll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪή")+l111llllll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧὶ"))
		return False
	LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬί"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸࡺࡡࡳࡶࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠫὸ"))
	l11l1ll111_l1_ = DIALOG_PROGRESS()
	l11l1ll111_l1_.create(l111llllll_l1_,l11ll1_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨό"))
	l11l11l11l_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111llllll_l1_,l11ll1_l1_ (u"ࠨࡹࡥࠫὺ"))
	else: file = open(l111llllll_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧύ")),l11ll1_l1_ (u"ࠪࡻࡧ࠭ὼ"))
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪώ"): # l11l11lll1_l1_ for l1llll111_l1_ and l11l1111ll_l1_ chunks video files such as .l11l1l1ll1_l1_
		for l11ll1111l_l1_ in range(1,l11l11l1l1_l1_+1):
			l1lllll_l1_ = l1l1_l1_[l11ll1111l_l1_-1]
			if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ὾")):
				if l1lllll_l1_.startswith(l11ll1_l1_ (u"࠭࠯࠰ࠩ὿")): l1lllll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠧ࠻ࠩᾀ"),1)[0]+l11ll1_l1_ (u"ࠨ࠼ࠪᾁ")+l1lllll_l1_
				elif l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠩ࠲ࠫᾂ")): l1lllll_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧᾃ"))+l1lllll_l1_
				else: l1lllll_l1_ = l111lll_l1_.rsplit(l11ll1_l1_ (u"ࠫ࠴࠭ᾄ"),1)[0]+l11ll1_l1_ (u"ࠬ࠵ࠧᾅ")+l1lllll_l1_
			response = requests.request(l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᾆ"),l1lllll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11l11111l_l1_ = time.time()
			l111llll1l_l1_ = l11l11111l_l1_-t1
			l11l111111_l1_ = l111llll1l_l1_//l11ll1111l_l1_
			l11l1l11l1_l1_ = l11l111111_l1_*(l11l11l1l1_l1_+1)
			l11l111l11_l1_ = l11l1l11l1_l1_-l111llll1l_l1_
			PROGRESS_UPDATE(l11l1ll111_l1_,int(100*l11ll1111l_l1_//(l11l11l1l1_l1_+1)),l11ll1_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᾇ"),l11ll1_l1_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨᾈ"),str(l11ll1111l_l1_*chunksize//l11ll11l1l_l1_)+l11ll1_l1_ (u"ࠩ࠲ࠫᾉ")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨᾊ")+time.strftime(l11ll1_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᾋ"),time.gmtime(l11l111l11_l1_))+l11ll1_l1_ (u"ࠬࠦเࠨᾌ"))
			if l11l1ll111_l1_.iscanceled():
				l11l11l11l_l1_ = False
				break
	else: # l1111l1l_l1_ and other l11l1l11ll_l1_ file l11ll11lll_l1_
		l11ll1111l_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11ll1111l_l1_ = l11ll1111l_l1_+1
			l11l11111l_l1_ = time.time()
			l111llll1l_l1_ = l11l11111l_l1_-t1
			l11l111111_l1_ = l111llll1l_l1_/l11ll1111l_l1_
			l11l1l11l1_l1_ = l11l111111_l1_*(l11l11l1l1_l1_+1)
			l11l111l11_l1_ = l11l1l11l1_l1_-l111llll1l_l1_
			PROGRESS_UPDATE(l11l1ll111_l1_,int(100*l11ll1111l_l1_/(l11l11l1l1_l1_+1)),l11ll1_l1_ (u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧᾍ"),l11ll1_l1_ (u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᾎ"),str(l11ll1111l_l1_*chunksize//l11ll11l1l_l1_)+l11ll1_l1_ (u"ࠨ࠱ࠪᾏ")+str(l11l1lllll_l1_)+l11ll1_l1_ (u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧᾐ")+time.strftime(l11ll1_l1_ (u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᾑ"),time.gmtime(l11l111l11_l1_))+l11ll1_l1_ (u"ࠫࠥๆࠧᾒ"))
			if l11l1ll111_l1_.iscanceled():
				l11l11l11l_l1_ = False
				break
		response.close()
	file.close()
	l11l1ll111_l1_.close()
	if not l11l11l11l_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᾓ"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᾔ")+l111lll_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᾕ")+l111llllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫᾖ"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᾗ"),l11ll1_l1_ (u"ࠪࠫᾘ"),l11ll1_l1_ (u"ࠫࠬᾙ"),l11ll1_l1_ (u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᾚ"))
		return True
	LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᾛ"),LOGGING(script_name)+l11ll1_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᾜ")+l111lll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᾝ")+l111llllll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬᾞ"))
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᾟ"),l11ll1_l1_ (u"ࠫࠬᾠ"),l11ll1_l1_ (u"ࠬ࠭ᾡ"),l11ll1_l1_ (u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬᾢ"))
	return True
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡑ࠸࡛ࠧ䀰")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䀱")
l11llllll111_l1_ = [
		 l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䀲")
		,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䀳"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䀴")
		,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䀵"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䀶")
		#,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䀷"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䀸"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䀹")
		,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䀺"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䀻")
		,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䀼"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ䀽"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ䀾")
		,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䀿"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䁀")
		,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䁁"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䁂")
		,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䁃"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ䁄"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ䁅")
		]
l11lllll11ll_l1_ = 4
def MAIN(mode,url,text,type,l1l1111_l1_,l1ll1ll1l1l_l1_):
	global l111l1_l1_
	try:
		l1lll111llll_l1_ = str(l1ll1ll1l1l_l1_[l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䁆")])
		l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍࡖࠩ䁇")+l1lll111llll_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䁈")
	except: l1lll111llll_l1_ = l11ll1_l1_ (u"ࠧࠨ䁉")
	try: l111l1ll_l1_ = str(l1ll1ll1l1l_l1_[l11ll1_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࠪ䁊")])
	except: l111l1ll_l1_ = l11ll1_l1_ (u"ࠩࠪ䁋")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1lll111llll_l1_,l111l1ll_l1_)
	elif mode==712: results = l1l1111lll1l_l1_(l1lll111llll_l1_)
	elif mode==713: results = GROUPS(l1lll111llll_l1_,url,text,l1l1111_l1_)
	elif mode==714: results = ITEMS(l1lll111llll_l1_,url,text,l1l1111_l1_)
	elif mode==715: results = PLAY(l1lll111llll_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1lll111llll_l1_,True)
	elif mode==717: results = l1l111ll1l11_l1_(l1lll111llll_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1lll111llll_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1lll111llll_l1_,url,l1l1111_l1_)
	elif mode==720: results = MENU(l1lll111llll_l1_)
	elif mode==721: results = l1l11111ll11_l1_(l1lll111llll_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1lll111llll_l1_)
	elif mode==723: results = ADD_USERAGENT(l1lll111llll_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==726: results = ADD_REFERER(l1lll111llll_l1_)
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1lll111llll_l1_,url,l1l1111_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1lll111llll_l1_ in range(1,FOLDERS_COUNT+1):
		l11llllll11l_l1_ = l11ll1_l1_ (u"ࠪࠤࡒ࠹ࡕࠨ䁌")+str(l1lll111llll_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓࡕࠨ䁍")+str(l1lll111llll_l1_)+l11ll1_l1_ (u"ࠬࡥࠧ䁎")
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁏"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆฮ็ำࠥ࠭䁐")+text_numbers[l1lll111llll_l1_]+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࠩ䁑"),720,l11ll1_l1_ (u"ࠩࠪ䁒"),l11ll1_l1_ (u"ࠪࠫ䁓"),l11ll1_l1_ (u"ࠫࠬ䁔"),l11ll1_l1_ (u"ࠬ࠭䁕"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁖"):l1lll111llll_l1_})
	return
def SECTIONS_MENU():
	global l111l1_l1_
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁗"),l111l1_l1_+l11ll1_l1_ (u"ࠨฮ่๎฾ࠦรใีส้ࠬ䁘"),l11ll1_l1_ (u"ࠩࠪ䁙"),165,l11ll1_l1_ (u"ࠪࠫ䁚"),l11ll1_l1_ (u"ࠫࠬ䁛"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䁜"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䁝"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䁞"),l11ll1_l1_ (u"ࠨࠩ䁟"),9999)
	for l1lll111llll_l1_ in range(1,FOLDERS_COUNT+1):
		l11llllll11l_l1_ = l11ll1_l1_ (u"ࠩࠣࡑ࠸࡛ࠧ䁠")+str(l1lll111llll_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡒ࡛ࠧ䁡")+str(l1lll111llll_l1_)+l11ll1_l1_ (u"ࠫࡤ࠭䁢")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁣"),l111l1_l1_+l11ll1_l1_ (u"࠭รใีส้๋ࠥฬๅัࠣࠫ䁤")+text_numbers[l1lll111llll_l1_]+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࠨ䁥"),165,l11ll1_l1_ (u"ࠨࠩ䁦"),l11ll1_l1_ (u"ࠩࠪ䁧"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䁨"),l11ll1_l1_ (u"ࠫࠬ䁩"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁪"):l1lll111llll_l1_})
	return
def MENU(l1lll111llll_l1_=l11ll1_l1_ (u"࠭ࠧ䁫")):
	if l1lll111llll_l1_:
		l11lll1lll1l_l1_ = {l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁬"):l1lll111llll_l1_}
		l11llllll11l_l1_ = l11ll1_l1_ (u"ࠨࠩ䁭")  # l11ll1_l1_ (u"ࠩࠣࡑ࠸࡛ࠧ䁮")+str(l1lll111llll_l1_)
	else:
		l11lll1lll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ䁯")
		l11llllll11l_l1_ = l11ll1_l1_ (u"ࠫࠬ䁰")
	if CHECK_TABLES_EXIST(l1lll111llll_l1_,True):
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁱"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็็ๅฬะࠧ䁲")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࠨ䁳"),729,l11ll1_l1_ (u"ࠨࠩ䁴"),l11ll1_l1_ (u"ࠩࠪ䁵"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䁶"),l11ll1_l1_ (u"ࠫࠬ䁷"),l11lll1lll1l_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁸"),l111l1_l1_+l11ll1_l1_ (u"࠭โศศ่อࠥษโิษ่ࠫ䁹")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࠨ䁺"),165,l11ll1_l1_ (u"ࠨࠩ䁻"),l11ll1_l1_ (u"ࠩࠪ䁼"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䁽"),l11ll1_l1_ (u"ࠫࠬ䁾"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䁿"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䂀"),l11ll1_l1_ (u"ࠧࠨ䂁"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂂"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠠๆ่ࠣวุ๋วว้สࠫ䂃")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ䂄"),713,l11ll1_l1_ (u"ࠫࠬ䂅"),l11ll1_l1_ (u"ࠬ࠭䂆"),l11ll1_l1_ (u"࠭ࠧ䂇"),l11ll1_l1_ (u"ࠧࠨ䂈"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂉"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโห้๋ࠣࠦริ็สส์อࠧ䂊")+l11llllll11l_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ䂋"),713,l11ll1_l1_ (u"ࠫࠬ䂌"),l11ll1_l1_ (u"ࠬ࠭䂍"),l11ll1_l1_ (u"࠭ࠧ䂎"),l11ll1_l1_ (u"ࠧࠨ䂏"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䂐"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䂑"),l11ll1_l1_ (u"ࠪࠫ䂒"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂓"),l111l1_l1_+l11ll1_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโห้๋ࠣࠦรใีส้์อࠧ䂔")+l11llllll11l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ䂕"),713,l11ll1_l1_ (u"ࠧࠨ䂖"),l11ll1_l1_ (u"ࠨࠩ䂗"),l11ll1_l1_ (u"ࠩࠪ䂘"),l11ll1_l1_ (u"ࠪࠫ䂙"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂚"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢฦๆุอๅ่ษࠪ䂛")+l11llllll11l_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ䂜"),713,l11ll1_l1_ (u"ࠧࠨ䂝"),l11ll1_l1_ (u"ࠨࠩ䂞"),l11ll1_l1_ (u"ࠩࠪ䂟"),l11ll1_l1_ (u"ࠪࠫ䂠"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䂡"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䂢"),l11ll1_l1_ (u"࠭ࠧ䂣"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂤"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ๆ๋๎วหࠢส่ศ฻ไ๋หࠪ䂥")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䂦"),713,l11ll1_l1_ (u"ࠪࠫ䂧"),l11ll1_l1_ (u"ࠫࠬ䂨"),l11ll1_l1_ (u"ࠬ࠭䂩"),l11ll1_l1_ (u"࠭ࠧ䂪"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂫"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠥอไฤื็๎ฮ࠭䂬")+l11llllll11l_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䂭"),713,l11ll1_l1_ (u"ࠪࠫ䂮"),l11ll1_l1_ (u"ࠫࠬ䂯"),l11ll1_l1_ (u"ࠬ࠭䂰"),l11ll1_l1_ (u"࠭ࠧ䂱"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䂲"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䂳"),l11ll1_l1_ (u"ࠩࠪ䂴"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂵"),l111l1_l1_+l11ll1_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แสࠩ䂶")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䂷"),713,l11ll1_l1_ (u"࠭ࠧ䂸"),l11ll1_l1_ (u"ࠧࠨ䂹"),l11ll1_l1_ (u"ࠨࠩ䂺"),l11ll1_l1_ (u"ࠩࠪ䂻"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂼"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอࠬ䂽")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䂾"),713,l11ll1_l1_ (u"࠭ࠧ䂿"),l11ll1_l1_ (u"ࠧࠨ䃀"),l11ll1_l1_ (u"ࠨࠩ䃁"),l11ll1_l1_ (u"ࠩࠪ䃂"),l11lll1lll1l_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃃"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ็ไศ็ฺ้ࠣ์แสࠩ䃄")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䃅"),713,l11ll1_l1_ (u"࠭ࠧ䃆"),l11ll1_l1_ (u"ࠧࠨ䃇"),l11ll1_l1_ (u"ࠨࠩ䃈"),l11ll1_l1_ (u"ࠩࠪ䃉"),l11lll1lll1l_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃊"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥี็ใฬࠫ䃋")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䃌"),713,l11ll1_l1_ (u"࠭ࠧ䃍"),l11ll1_l1_ (u"ࠧࠨ䃎"),l11ll1_l1_ (u"ࠨࠩ䃏"),l11ll1_l1_ (u"ࠩࠪ䃐"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃑"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅอ้๋่ฮ࠭䃒")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䃓"),713,l11ll1_l1_ (u"࠭ࠧ䃔"),l11ll1_l1_ (u"ࠧࠨ䃕"),l11ll1_l1_ (u"ࠨࠩ䃖"),l11ll1_l1_ (u"ࠩࠪ䃗"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃘"),l111l1_l1_+l11ll1_l1_ (u"ࠫ็์่ศฬ้ࠣัํ่ๅหࠪ䃙")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䃚"),713,l11ll1_l1_ (u"࠭ࠧ䃛"),l11ll1_l1_ (u"ࠧࠨ䃜"),l11ll1_l1_ (u"ࠨࠩ䃝"),l11ll1_l1_ (u"ࠩࠪ䃞"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䃟"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䃠"),l11ll1_l1_ (u"ࠬ࠭䃡"),9999)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃢"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอࠥ๎ๅาฬหอࠬ䃣")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䃤"),713,l11ll1_l1_ (u"ࠩࠪ䃥"),l11ll1_l1_ (u"ࠪࠫ䃦"),l11ll1_l1_ (u"ࠫࠬ䃧"),l11ll1_l1_ (u"ࠬ࠭䃨"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃩"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ䃪")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䃫"),713,l11ll1_l1_ (u"ࠩࠪ䃬"),l11ll1_l1_ (u"ࠪࠫ䃭"),l11ll1_l1_ (u"ࠫࠬ䃮"),l11ll1_l1_ (u"ࠬ࠭䃯"),l11lll1lll1l_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃰"),l111l1_l1_+l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๅึ่ไอࠥ๎ๅาฬหอࠬ䃱")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䃲"),713,l11ll1_l1_ (u"ࠩࠪ䃳"),l11ll1_l1_ (u"ࠪࠫ䃴"),l11ll1_l1_ (u"ࠫࠬ䃵"),l11ll1_l1_ (u"ࠬ࠭䃶"),l11lll1lll1l_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃷"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ䃸")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䃹"),713,l11ll1_l1_ (u"ࠩࠪ䃺"),l11ll1_l1_ (u"ࠪࠫ䃻"),l11ll1_l1_ (u"ࠫࠬ䃼"),l11ll1_l1_ (u"ࠬ࠭䃽"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃾"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไส๋้ࠢึะศสࠩ䃿")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䄀"),713,l11ll1_l1_ (u"ࠩࠪ䄁"),l11ll1_l1_ (u"ࠪࠫ䄂"),l11ll1_l1_ (u"ࠫࠬ䄃"),l11ll1_l1_ (u"ࠬ࠭䄄"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄅"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ่ࠦๆำอฬฮ࠭䄆")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䄇"),713,l11ll1_l1_ (u"ࠩࠪ䄈"),l11ll1_l1_ (u"ࠪࠫ䄉"),l11ll1_l1_ (u"ࠫࠬ䄊"),l11ll1_l1_ (u"ࠬ࠭䄋"),l11lll1lll1l_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䄌"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䄍"),l11ll1_l1_ (u"ࠨࠩ䄎"),9999)
	for seq in range(1,l11lllll11ll_l1_+1):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䄏"),l111l1_l1_+l11ll1_l1_ (u"ࠪษ฻อแส๋ࠢฮ฿๐๊าࠢิหอ฽ࠧ䄐")+l11llllll11l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭䄑")+text_numbers[seq],l11ll1_l1_ (u"ࠬ࠭䄒"),711,l11ll1_l1_ (u"࠭ࠧ䄓"),l11ll1_l1_ (u"ࠧࠨ䄔"),l11ll1_l1_ (u"ࠨࠩ䄕"),l11ll1_l1_ (u"ࠩࠪ䄖"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䄗"):l1lll111llll_l1_,l11ll1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭䄘"):seq})
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄙"),l111l1_l1_+l11ll1_l1_ (u"࠭ศาษ่ะࠥอไใ่๋หฯࠦࠨอั๋่ࠥ็โุࠫࠪ䄚")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䄛"),713,l11ll1_l1_ (u"ࠨࠩ䄜"),l11ll1_l1_ (u"ࠩࠪ䄝"),l11ll1_l1_ (u"ࠪࠫ䄞"),l11ll1_l1_ (u"ࠫࠬ䄟"),l11lll1lll1l_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄠"),l111l1_l1_+l11ll1_l1_ (u"࠭ราึํๅࠥอไใ่๋หฯࠦไๅลํห๊ࠦวๅ็สฺ๏ฯࠧ䄡")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䄢"),713,l11ll1_l1_ (u"ࠨࠩ䄣"),l11ll1_l1_ (u"ࠩࠪ䄤"),l11ll1_l1_ (u"ࠪࠫ䄥"),l11ll1_l1_ (u"ࠫࠬ䄦"),l11lll1lll1l_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄧"),l111l1_l1_+l11ll1_l1_ (u"࠭ราึํๅࠥฮัศ็ฯࠤฬ๊โ็๊สฮ๊ࠥไฤ์ส้ࠥอไๆษู๎ฮ࠭䄨")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䄩"),713,l11ll1_l1_ (u"ࠨࠩ䄪"),l11ll1_l1_ (u"ࠩࠪ䄫"),l11ll1_l1_ (u"ࠪࠫ䄬"),l11ll1_l1_ (u"ࠫࠬ䄭"),l11lll1lll1l_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䄮"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䄯"),l11ll1_l1_ (u"ࠧࠨ䄰"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䄱"),l111l1_l1_+l11ll1_l1_ (u"ࠩศฺฬ็ษࠡล๋ࠤฯเ๊๋ำࠣหูะัศๅࠪ䄲")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䄳"),711,l11ll1_l1_ (u"ࠫࠬ䄴"),l11ll1_l1_ (u"ࠬ࠭䄵"),l11ll1_l1_ (u"࠭ࠧ䄶"),l11ll1_l1_ (u"ࠧࠨ䄷"),l11lll1lll1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䄸"),l111l1_l1_+l11ll1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠨ䄹")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䄺"),721,l11ll1_l1_ (u"ࠫࠬ䄻"),l11ll1_l1_ (u"ࠬ࠭䄼"),l11ll1_l1_ (u"࠭ࠧ䄽"),l11ll1_l1_ (u"ࠧࠨ䄾"),l11lll1lll1l_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䄿"),l111l1_l1_+l11ll1_l1_ (u"ࠩไัฺࠦวีฬิห่࠭䅀")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅁"),716,l11ll1_l1_ (u"ࠫࠬ䅂"),l11ll1_l1_ (u"ࠬ࠭䅃"),l11ll1_l1_ (u"࠭ࠧ䅄"),l11ll1_l1_ (u"ࠧࠨ䅅"),l11lll1lll1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅆"),l111l1_l1_+l11ll1_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠬ䅇")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅈"),712,l11ll1_l1_ (u"ࠫࠬ䅉"),l11ll1_l1_ (u"ࠬ࠭䅊"),l11ll1_l1_ (u"࠭ࠧ䅋"),l11ll1_l1_ (u"ࠧࠨ䅌"),l11lll1lll1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅍"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠬ䅎")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅏"),717,l11ll1_l1_ (u"ࠫࠬ䅐"),l11ll1_l1_ (u"ࠬ࠭䅑"),l11ll1_l1_ (u"࠭ࠧ䅒"),l11ll1_l1_ (u"ࠧࠨ䅓"),l11lll1lll1l_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅔"),l111l1_l1_+l11ll1_l1_ (u"ࠩสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊ริำ฼ࠫ䅕")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅖"),722,l11ll1_l1_ (u"ࠫࠬ䅗"),l11ll1_l1_ (u"ࠬ࠭䅘"),l11ll1_l1_ (u"࠭ࠧ䅙"),l11ll1_l1_ (u"ࠧࠨ䅚"),l11lll1lll1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅛"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦส฻์ํีࠬ䅜")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅝"),723,l11ll1_l1_ (u"ࠫࠬ䅞"),l11ll1_l1_ (u"ࠬ࠭䅟"),l11ll1_l1_ (u"࠭ࠧ䅠"),l11ll1_l1_ (u"ࠧࠨ䅡"),l11lll1lll1l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅢"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠣฮ฿๐๊าࠩ䅣")+l11llllll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䅤"),726,l11ll1_l1_ (u"ࠫࠬ䅥"),l11ll1_l1_ (u"ࠬ࠭䅦"),l11ll1_l1_ (u"࠭ࠧ䅧"),l11ll1_l1_ (u"ࠧࠨ䅨"),l11lll1lll1l_l1_)
	return
def CHECK_ACCOUNT(l1lll111llll_l1_,l1ll_l1_=True):
	ok,status = False,l11ll1_l1_ (u"ࠨࠩ䅩")
	l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = l11ll1_l1_ (u"ࠩࠪ䅪"),l11ll1_l1_ (u"ࠪࠫ䅫")
	l1l111lllll1_l1_,l11lllll1l1l_l1_,server,username,password = GET_URL(l1lll111llll_l1_)
	if username==l11ll1_l1_ (u"ࠫࠬ䅬"): return
	headers = GET_HEADERS(l1lll111llll_l1_)
	if l1l111lllll1_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䅭"),l1l111lllll1_l1_,l11ll1_l1_ (u"࠭ࠧ䅮"),headers,False,l11ll1_l1_ (u"ࠧࠨ䅯"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ䅰"))
		html = response.content
		if response.succeeded:
			timestamp,l11lll1l1ll1_l1_,l11lll1l111l_l1_,l11lll111111_l1_,l11lllll1lll_l1_ = 0,0,l11ll1_l1_ (u"ࠩࠪ䅱"),l11ll1_l1_ (u"ࠪࠫ䅲"),l11ll1_l1_ (u"ࠫࠬ䅳")
			try:
				dict = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ䅴"),html)
				status = dict[l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ䅵")][l11ll1_l1_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ䅶")]
				ok = True
				l11lll1l111l_l1_ = dict[l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䅷")][l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡟࡯ࡱࡺࠫ䅸")]
			except: pass
			if l11lll1l111l_l1_:
				try:
					struct = time.strptime(l11lll1l111l_l1_,l11ll1_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ䅹"))
					timestamp = int(time.mktime(struct))
					l11lll1l1ll1_l1_ = int(now-timestamp)
					l11lll1l1ll1_l1_ = int((l11lll1l1ll1_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䅺")][l11ll1_l1_ (u"ࠬࡩࡲࡦࡣࡷࡩࡩࡥࡡࡵࠩ䅻")]))
					l11lll111111_l1_ = time.strftime(l11ll1_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ䅼"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䅽")][l11ll1_l1_ (u"ࠨࡧࡻࡴࡤࡪࡡࡵࡧࠪ䅾")]))
					l11lllll1lll_l1_ = time.strftime(l11ll1_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭䅿"),struct)
				except: pass
			settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ䆀")+l1lll111llll_l1_,str(now))
			settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫ࡥࠧ䆁")+l1lll111llll_l1_,str(l11lll1l1ll1_l1_))
			try:
				l11llllllll1_l1_ = l11ll1_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠦ࠿࠭䆂")+html.split(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠧࡀࠧ䆃"))[1]
				l11llllllll1_l1_ = l11llllllll1_l1_.replace(l11ll1_l1_ (u"ࠧ࠻ࠩ䆄"),l11ll1_l1_ (u"ࠨ࠼ࠣࠫ䆅")).replace(l11ll1_l1_ (u"ࠩ࠯ࠫ䆆"),l11ll1_l1_ (u"ࠪ࠰ࠥ࠭䆇")).replace(l11ll1_l1_ (u"ࠫࢂࢃࠧ䆈"),l11ll1_l1_ (u"ࠬࢃࠧ䆉"))
				new = re.findall(l11ll1_l1_ (u"࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࠤࡳࡳࡷࡺࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䆊"),l11llllllll1_l1_,re.DOTALL)
				l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䆋")][l11ll1_l1_ (u"ࠨ࡯ࡤࡼࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࡵࠪ䆌")]
				l1l111111l1l_l1_ = dict[l11ll1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ䆍")][l11ll1_l1_ (u"ࠪࡥࡨࡺࡩࡷࡧࡢࡧࡴࡴࡳࠨ䆎")]
				l1l1111l1l11_l1_ = dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䆏")][l11ll1_l1_ (u"ࠬ࡯ࡳࡠࡶࡵ࡭ࡦࡲࠧ䆐")]
				parts = l1l111lllll1_l1_.split(l11ll1_l1_ (u"࠭࠿ࠨ䆑"),1)
				message = l11ll1_l1_ (u"ࠧࡖࡔࡏ࠾࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆒")+l1l111lllll1_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆓")
				message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࡓࡵࡣࡷࡹࡸࡀࠠࠡࠩ䆔")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䆕")+status+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆖")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡕࡴ࡬ࡥࡱࡀࠠࠡࠢࠣࠫ䆗")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆘")+str(l1l1111l1l11_l1_==l11ll1_l1_ (u"ࠧ࠲ࠩ䆙"))+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆚")
				message += l11ll1_l1_ (u"ࠩ࡟ࡲࡈࡸࡥࡢࡶࡨࡨࠥࠦࡁࡵ࠼ࠣࠤࠬ䆛")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䆜")+l11lll111111_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆝")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡆࡺࡳ࡭ࡷࡿࠠࡅࡣࡷࡩ࠿ࠦࠠࠨ䆞")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆟")+l11lllll1lll_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䆠")
				message += l11ll1_l1_ (u"ࠨ࡞ࡱࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࡳࠡࠢࠣࠬࠥࡇࡣࡵ࡫ࡹࡩࠥ࠵ࠠࡎࡣࡻ࡭ࡲࡻ࡭ࠡࠫࠣ࠾ࠥࠦࠧ䆡")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䆢")+l1l111111l1l_l1_+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䆣")+max+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆤")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡂ࡮࡯ࡳࡼ࡫ࡤࠡࡑࡸࡸࡵࡻࡴࡴ࠼ࠣࠤࠥ࠭䆥")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆦")+l11ll1_l1_ (u"ࠢࠡ࠮ࠣࠦ䆧").join(dict[l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ䆨")][l11ll1_l1_ (u"ࠩࡤࡰࡱࡵࡷࡦࡦࡢࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡶࠫ䆩")])+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䆪")
				message += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䆫")+l11llllllll1_l1_
				if status==l11ll1_l1_ (u"ࠬࡇࡣࡵ࡫ࡹࡩࠬ䆬"): DIALOG_TEXTVIEWER(l11ll1_l1_ (u"࠭วๅษืฮึอใࠡ์฼้้ࠦศะ๊้ࠤฺ๊วไๆࠪ䆭"),message)
				else: DIALOG_TEXTVIEWER(l11ll1_l1_ (u"๋ࠧสา์ࠥษๆ้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡษ็หูะัศๅࠪ䆮"),message)
	if l1l111lllll1_l1_ and ok and status==l11ll1_l1_ (u"ࠨࡃࡦࡸ࡮ࡼࡥࠨ䆯"):
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䆰"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡐ࠷࡚ࠦࡕࡓࡎࠣࠤࠥࡡࠠࡎ࠵ࡘࠤࡦࡩࡣࡰࡷࡱࡸࠥ࡯ࡳࠡࡑࡎࠤࡢࠦࠠࠡ࡝ࠣࠫ䆱")+l1l111lllll1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ䆲"))
		succeeded = True
	else:
		LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䆳"),l11ll1_l1_ (u"࠭ࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡏ࠶࡙࡛ࠥࡒࡍࠢࠣࠤࡠࠦࡄࡰࡧࡶࠤࡳࡵࡴࠡࡹࡲࡶࡰࠦ࡝ࠡࠢࠣ࡟ࠥ࠭䆴")+l1l111lllll1_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ䆵"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䆶"),l11ll1_l1_ (u"ࠩࠪ䆷"),l11ll1_l1_ (u"ࠪๅา฻ࠠศึอีฬ้ࠠแࡏ࠶࡙ࠬ䆸"),l11ll1_l1_ (u"ࠫึอศุࠢสุฯืวไࠢใࡑ࠸࡛ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡏ࠶࡙ࠥ๎โๆࠢหษ฻อแสࠢิหอ฽ࠠแࡏ࠶࡙ࠥาฯ๋ัࠣวํࠦโๆࠢหษฺ๊วฮࠢส่ึอศุࠢส่็ี๊ๆࠩ䆹"))
		succeeded = False
	return succeeded,l11lll1ll1ll_l1_,l1l111ll1ll1_l1_
def ITEMS(l1lll111llll_l1_,l1l111111111_l1_,l1l1111llll1_l1_,l11llll11111_l1_,l1ll_l1_=True):
	if not l11llll11111_l1_: l11llll11111_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ䆺")
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,l1ll_l1_): return
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l1l111111111_l1_)
	l1ll1l111l11_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ䆻"),l1l111111111_l1_,l1l1111llll1_l1_)
	end = int(l11llll11111_l1_)*100
	start = end-100
	for context,title,url,l1lll1_l1_ in l1ll1l111l11_l1_[start:end]:
		l1ll1lll1111_l1_ = (l11ll1_l1_ (u"ࠧࡈࡔࡒ࡙ࡕࡋࡄࠨ䆼") in l1l111111111_l1_ or l1l111111111_l1_==l11ll1_l1_ (u"ࠨࡃࡏࡐࠬ䆽"))
		l1ll1ll1lll1_l1_ = (l11ll1_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡆࡆࠪ䆾") not in l1l111111111_l1_ and l1l111111111_l1_!=l11ll1_l1_ (u"ࠪࡅࡑࡒࠧ䆿"))
		if l1ll1lll1111_l1_ or l1ll1ll1lll1_l1_:
			if   l11ll1_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䇀")  in l1l111111111_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇁"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䇂"),l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䇃"),l11ll1_l1_ (u"ࠨࠩ䇄"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇅"):l1lll111llll_l1_}])
			elif l11ll1_l1_ (u"ࠪࡉࡕࡍࠧ䇆") 		 in l1l111111111_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇇"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭䇈"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䇉"),l11ll1_l1_ (u"ࠧࠨ䇊"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇋"):l1lll111llll_l1_}])
			elif l11ll1_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䇌") in l1l111111111_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇍"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䇎"),l11ll1_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ䇏"),l11ll1_l1_ (u"࠭ࠧ䇐"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇑"):l1lll111llll_l1_}])
			elif l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䇒") 	 in l1l111111111_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䇓"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ䇔"),l11ll1_l1_ (u"ࠫࠬ䇕"),context,{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇖"):l1lll111llll_l1_}])
			else: menuItemsLIST.append([l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䇗"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䇘"),l11ll1_l1_ (u"ࠨࠩ䇙"),l11ll1_l1_ (u"ࠩࠪ䇚"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇛"):l1lll111llll_l1_}])
	total = len(l1ll1l111l11_l1_)
	PAGINATION(l1lll111llll_l1_,l11llll11111_l1_,l1l111111111_l1_,714,total,l1l1111llll1_l1_)
	return
def SHOW_EMPTY(l11lll11llll_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䇜"),l11lll11llll_l1_+l11ll1_l1_ (u"ࠬํะ่ࠢส่็อฦๆหࠣษ๊อࠠโษิ฾ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮ࠭䇝"),l11ll1_l1_ (u"࠭ࠧ䇞"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䇟"),l11lll11llll_l1_+l11ll1_l1_ (u"ࠨล๋ࠤฬ๊ฮะ็ฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤฬฺสาษๆ็ࠬ䇠"),l11ll1_l1_ (u"ࠩࠪ䇡"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䇢"),l11lll11llll_l1_+l11ll1_l1_ (u"ࠫศ๎ࠠาษห฻ࠥࡓ࠳ࡖโࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ฿๐ัࠡืะ๎า࠭䇣"),l11ll1_l1_ (u"ࠬ࠭䇤"),9999)
	return
def GROUPS(l1lll111llll_l1_,l1l111111111_l1_,l1l1111llll1_l1_,l11llll11111_l1_,l1l1l1l1_l1_=l11ll1_l1_ (u"࠭ࠧ䇥"),l1ll_l1_=True):
	if not l11llll11111_l1_: l11llll11111_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ䇦")
	l11lll11llll_l1_ = l111l1_l1_
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,l1ll_l1_): return False
	if l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䇧") in l1l1111llll1_l1_: l11llll11l11_l1_,l11lll11l1ll_l1_ = l1l1111llll1_l1_.split(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䇨"))
	else: l11llll11l11_l1_,l11lll11l1ll_l1_ = l1l1111llll1_l1_,l11ll1_l1_ (u"ࠪࠫ䇩")
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l1l111111111_l1_)
	l1l11111l111_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䇪"),l1l111111111_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䇫"))
	if not l1l11111l111_l1_: return False
	l1l111l1l1l1_l1_ = []
	for group,l1lll1_l1_ in l1l11111l111_l1_:
		if l1l1l1l1_l1_:
			if l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䇬") in group: l11lll11llll_l1_ = l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ䇭")
			elif l11ll1_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪ䇮") in group: l11lll11llll_l1_ = l11ll1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䇯")
			elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䇰") in l1l111111111_l1_: l11lll11llll_l1_ = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ䇱")
			else: l11lll11llll_l1_ = l11ll1_l1_ (u"ࠬ࡜ࡉࡅࡇࡒࡗࠬ䇲")
			l11lll11llll_l1_ = l11ll1_l1_ (u"࠭ࠬ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䇳")+l11lll11llll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䇴")
		if l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䇵") in group: l1l1111ll1l1_l1_,l11ll1lll1ll_l1_ = group.split(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䇶"))
		else: l1l1111ll1l1_l1_,l11ll1lll1ll_l1_ = group,l11ll1_l1_ (u"ࠪࠫ䇷")
		if not l1l1111llll1_l1_:
			if l1l1111ll1l1_l1_ in l1l111l1l1l1_l1_: continue
			l1l111l1l1l1_l1_.append(l1l1111ll1l1_l1_)
			if l11ll1_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࠫ䇸") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇹"),l11lll11llll_l1_+l1l1111ll1l1_l1_,l1l111111111_l1_,168,l11ll1_l1_ (u"࠭ࠧ䇺"),l11ll1_l1_ (u"ࠧ࠲ࠩ䇻"),group,l11ll1_l1_ (u"ࠨࠩ䇼"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇽"):l1lll111llll_l1_})
			elif l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䇾") in group: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇿"),l11lll11llll_l1_+l1l1111ll1l1_l1_,l1l111111111_l1_,713,l11ll1_l1_ (u"ࠬ࠭䈀"),l11ll1_l1_ (u"࠭࠱ࠨ䈁"),group,l11ll1_l1_ (u"ࠧࠨ䈂"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈃"):l1lll111llll_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈄"),l11lll11llll_l1_+l1l1111ll1l1_l1_,l1l111111111_l1_,714,l11ll1_l1_ (u"ࠪࠫ䈅"),l11ll1_l1_ (u"ࠫ࠶࠭䈆"),group,l11ll1_l1_ (u"ࠬ࠭䈇"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈈"):l1lll111llll_l1_})
		elif l11ll1_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䈉") in group and l1l1111ll1l1_l1_==l11llll11l11_l1_:
			if l11ll1lll1ll_l1_ in l1l111l1l1l1_l1_: continue
			l1l111l1l1l1_l1_.append(l11ll1lll1ll_l1_)
			if l11ll1_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࠨ䈊") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈋"),l11lll11llll_l1_+l11ll1lll1ll_l1_,l1l111111111_l1_,168,l11ll1_l1_ (u"ࠪࠫ䈌"),l11ll1_l1_ (u"ࠫ࠶࠭䈍"),group,l11ll1_l1_ (u"ࠬ࠭䈎"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈏"):l1lll111llll_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䈐"),l11lll11llll_l1_+l11ll1lll1ll_l1_,l1l111111111_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠨ࠳ࠪ䈑"),group,l11ll1_l1_ (u"ࠩࠪ䈒"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䈓"):l1lll111llll_l1_})
	#if l11ll1_l1_ (u"ࠫࡘࡕࡒࡕࡇࡇࠫ䈔") in l1l111111111_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1l1l1_l1_:
		end = int(l11llll11111_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1lll111llll_l1_,l11llll11111_l1_,l1l111111111_l1_,713,total,l1l1111llll1_l1_)
	return True
def EPG_ITEMS(l1lll111llll_l1_,url,function):
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,True): return
	headers = GET_HEADERS(l1lll111llll_l1_)
	timestamp = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ䈕")+l1lll111llll_l1_)
	if not timestamp or now-int(timestamp)>24*l11lll11ll1l_l1_:
		succeeded,l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = CHECK_ACCOUNT(l1lll111llll_l1_,False)
		if not succeeded: return
	l11lll1l1ll1_l1_ = int(settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ䈖")+l1lll111llll_l1_))
	server = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ䈗")+l1lll111llll_l1_)
	username = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡴࡡ࡮ࡧࡢࠫ䈘")+l1lll111llll_l1_)
	password = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡳࡥࡸࡹࡷࡰࡴࡧࡣࠬ䈙")+l1lll111llll_l1_)
	l11lll1ll11l_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ䈚"))
	l11ll1lllll1_l1_ = l11lll1ll11l_l1_[-1].replace(l11ll1_l1_ (u"ࠫ࠳ࡺࡳࠨ䈛"),l11ll1_l1_ (u"ࠬ࠭䈜")).replace(l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䈝"),l11ll1_l1_ (u"ࠧࠨ䈞"))
	if function==l11ll1_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ䈟"): l1l111ll1111_l1_ = l11ll1_l1_ (u"ࠩࡪࡩࡹࡥࡳࡩࡱࡵࡸࡤ࡫ࡰࡨࠩ䈠")
	else: l1l111ll1111_l1_ = l11ll1_l1_ (u"ࠪ࡫ࡪࡺ࡟ࡴ࡫ࡰࡴࡱ࡫࡟ࡥࡣࡷࡥࡤࡺࡡࡣ࡮ࡨࠫ䈡")
	l1l111lllll1_l1_,l11lllll1l1l_l1_,server,username,password = GET_URL(l1lll111llll_l1_)
	if not username: return
	l11llll11lll_l1_ = l1l111lllll1_l1_+l11ll1_l1_ (u"ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࠭䈢")+l1l111ll1111_l1_+l11ll1_l1_ (u"ࠬࠬࡳࡵࡴࡨࡥࡲࡥࡩࡥ࠿ࠪ䈣")+l11ll1lllll1_l1_
	html = OPENURL_CACHED(NO_CACHE,l11llll11lll_l1_,l11ll1_l1_ (u"࠭ࠧ䈤"),headers,l11ll1_l1_ (u"ࠧࠨ䈥"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡋࡐࡈࡡࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬ䈦"))
	l11lllllll1l_l1_ = EVAL(l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䈧"),html)
	l11lll11l11l_l1_ = l11lllllll1l_l1_[l11ll1_l1_ (u"ࠪࡩࡵ࡭࡟࡭࡫ࡶࡸ࡮ࡴࡧࡴࠩ䈨")]
	l11llll1lll1_l1_ = []
	if function in [l11ll1_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䈩"),l11ll1_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ䈪")]:
		for dict in l11lll11l11l_l1_:
			if dict[l11ll1_l1_ (u"࠭ࡨࡢࡵࡢࡥࡷࡩࡨࡪࡸࡨࠫ䈫")]==1:
				l11llll1lll1_l1_.append(dict)
				if function in [l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䈬")]: break
		if not l11llll1lll1_l1_: return
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䈭"),l111l1_l1_+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬ๊ๅๅใสฮࠥอไฤ๊็๎ࠥฮ็ั้ࠣห้่วว็ฬࠤ็ีࠠๅษࠣฮ฾๋ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䈮"),l11ll1_l1_ (u"ࠪࠫ䈯"),9999)
		if function in [l11ll1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䈰")]:
			l1l111ll11ll_l1_ = 2
			l11lll11ll11_l1_ = l1l111ll11ll_l1_*l11lll11ll1l_l1_
			l11llll1lll1_l1_ = []
			l1l111llll11_l1_ = int(int(dict[l11ll1_l1_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ䈱")])/l11lll11ll11_l1_)*l11lll11ll11_l1_
			l1l1111ll111_l1_ = now+l11lll11ll11_l1_
			l11lll11111l_l1_ = int((l1l1111ll111_l1_-l1l111llll11_l1_)/l11lll11ll1l_l1_)
			for count in range(l11lll11111l_l1_):
				if count>=6:
					if count%l1l111ll11ll_l1_!=0: continue
					l1l11lll1_l1_ = l11lll11ll11_l1_
				else: l1l11lll1_l1_ = l11lll11ll11_l1_//2
				l11lll111l11_l1_ = l1l111llll11_l1_+count*l11lll11ll1l_l1_
				dict = {}
				dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䈲")] = l11ll1_l1_ (u"ࠧࠨ䈳")
				struct = time.localtime(l11lll111l11_l1_-l11lll1l1ll1_l1_-l11lll11ll1l_l1_)
				dict[l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䈴")] = time.strftime(l11ll1_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭䈵"),struct)
				dict[l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䈶")] = str(l11lll111l11_l1_)
				dict[l11ll1_l1_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䈷")] = str(l11lll111l11_l1_+l1l11lll1_l1_)
				l11llll1lll1_l1_.append(dict)
	elif function in [l11ll1_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ䈸"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䈹")]: l11llll1lll1_l1_ = l11lll11l11l_l1_
	if function==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ䈺") and len(l11llll1lll1_l1_)>0:
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䈻"),l111l1_l1_+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึ็ࠡไสส๊ฯࠠษำส้ัࠦวๅไ้์ฬะࠠࠩฮา์้ࠦแใูࠬไࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䈼"),l11ll1_l1_ (u"ࠪࠫ䈽"),9999)
	l11llll1l1ll_l1_ = []
	l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ䈾"))
	for dict in l11llll1lll1_l1_:
		title = base64.b64decode(dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䈿")])
		if kodi_version>18.99: title = title.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䉀"))
		l11lll111l11_l1_ = int(dict[l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䉁")])
		l1l111l11111_l1_ = int(dict[l11ll1_l1_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䉂")])
		l1l1111ll1ll_l1_ = str(int((l1l111l11111_l1_-l11lll111l11_l1_+59)/60))
		l1l11l111111_l1_ = dict[l11ll1_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ䉃")].replace(l11ll1_l1_ (u"ࠪࠤࠬ䉄"),l11ll1_l1_ (u"ࠫ࠿࠭䉅"))
		struct = time.localtime(l11lll111l11_l1_-l11lll11ll1l_l1_)
		l1l1111l111l_l1_ = time.strftime(l11ll1_l1_ (u"ࠬࠫࡈ࠻ࠧࡐࠫ䉆"),struct)
		l1l1111lll11_l1_ = time.strftime(l11ll1_l1_ (u"࠭ࠥࡢࠩ䉇"),struct)
		if function==l11ll1_l1_ (u"ࠧࡔࡊࡒࡖ࡙ࡥࡅࡑࡉࠪ䉈"): title = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䉉")+l1l1111l111l_l1_+l11ll1_l1_ (u"ࠩࠣไࠥ࠭䉊")+title+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䉋")
		elif function==l11ll1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䉌"): title = l1l1111lll11_l1_+l11ll1_l1_ (u"ࠬࠦࠧ䉍")+l1l1111l111l_l1_+l11ll1_l1_ (u"࠭ࠠࠩࠩ䉎")+l1l1111ll1ll_l1_+l11ll1_l1_ (u"ࠧ࡮࡫ࡱ࠭ࠬ䉏")
		else: title = l1l1111lll11_l1_+l11ll1_l1_ (u"ࠨࠢࠪ䉐")+l1l1111l111l_l1_+l11ll1_l1_ (u"ࠩࠣࠬࠬ䉑")+l1l1111ll1ll_l1_+l11ll1_l1_ (u"ࠪࡱ࡮ࡴࠩࠡࠢࠣࠫ䉒")+title+l11ll1_l1_ (u"ࠫࠥๆࠧ䉓")
		if function in [l11ll1_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ䉔"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䉕"),l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䉖")]:
			l11lll111ll1_l1_ = server+l11ll1_l1_ (u"ࠨ࠱ࡷ࡭ࡲ࡫ࡳࡩ࡫ࡩࡸ࠴࠭䉗")+username+l11ll1_l1_ (u"ࠩ࠲ࠫ䉘")+password+l11ll1_l1_ (u"ࠪ࠳ࠬ䉙")+l1l1111ll1ll_l1_+l11ll1_l1_ (u"ࠫ࠴࠭䉚")+l1l11l111111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ䉛")+l11ll1lllll1_l1_+l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䉜")
			if function==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ䉝"): addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䉞"),l111l1_l1_+title,l11lll111ll1_l1_,9999,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䉟"),l11ll1_l1_ (u"ࠪࠫ䉠"),l11ll1_l1_ (u"ࠫࠬ䉡"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉢"):l1lll111llll_l1_})
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䉣"),l111l1_l1_+title,l11lll111ll1_l1_,235,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䉤"),l11ll1_l1_ (u"ࠨࠩ䉥"),l11ll1_l1_ (u"ࠩࠪ䉦"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉧"):l1lll111llll_l1_})
		l11llll1l1ll_l1_.append(title)
	if function==l11ll1_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ䉨") and l11llll1l1ll_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11llll1l1ll_l1_)
	return l11llll1l1ll_l1_
def USE_FASTER_SERVER(l1lll111llll_l1_):
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,True): return
	server,l11lll1ll1l1_l1_,l11lll1l11l1_l1_ = l11ll1_l1_ (u"ࠬ࠭䉩"),0,0
	succeeded,l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = CHECK_ACCOUNT(l1lll111llll_l1_,False)
	if succeeded:
		l1l111l1llll_l1_ = DNS_RESOLVER(l11lll1ll1ll_l1_)
		l11lll1ll1l1_l1_ = PING(l1l111l1llll_l1_[0],int(l1l111ll1ll1_l1_))
		l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䉪"))
		groups = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䉫"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䉬"))
		l1ll1l111l11_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䉭"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䉮"),groups[1])
		url = l1ll1l111l11_l1_[0][2]
		l1l1111l11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ䉯"),url,re.DOTALL)
		l1l1111l11ll_l1_ = l1l1111l11ll_l1_[0]
		if l11ll1_l1_ (u"ࠬࡀࠧ䉰") in l1l1111l11ll_l1_: l1l11111111l_l1_,l1l111l11ll1_l1_ = l1l1111l11ll_l1_.split(l11ll1_l1_ (u"࠭࠺ࠨ䉱"))
		else: l1l11111111l_l1_,l1l111l11ll1_l1_ = l1l1111l11ll_l1_,l11ll1_l1_ (u"ࠧ࠹࠲ࠪ䉲")
		l11lll1111l1_l1_ = DNS_RESOLVER(l1l11111111l_l1_)
		l11lll1l11l1_l1_ = PING(l11lll1111l1_l1_[0],int(l1l111l11ll1_l1_))
	if l11lll1ll1l1_l1_ and l11lll1l11l1_l1_:
		message = l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊รึๆํࠤศ๋ࠠศๆึ๎ึ็ัࠡษ็วุืูࠡมࠤࠥࠬ䉳")
		message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䉴")+l11ll1_l1_ (u"ࠪ์็ะࠠืษษ฽ࠥ็๊ࠡษ็ื๏ืแาࠢส่ศ฻ไ๋ࠩ䉵")+l11ll1_l1_ (u"ࠫࡡࡴࠧ䉶")+str(int(l11lll1l11l1_l1_*1000))+l11ll1_l1_ (u"ࠬࠦๅๅ์ࠣฯฬ์๊สࠩ䉷")
		message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ䉸")+l11ll1_l1_ (u"้ࠧไอࠤ฻อฦฺࠢไ๎ࠥอไิ์ิๅึࠦวๅสา๎้࠭䉹")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ䉺")+str(int(l11lll1ll1l1_l1_*1000))+l11ll1_l1_ (u"้้ࠩࠣ๐ࠠฬษ้๎ฮ࠭䉻")
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䉼"),l11ll1_l1_ (u"ࠫฬ๊ำ๋ำไีࠥอไฤื็๎ࠬ䉽"),l11ll1_l1_ (u"ࠬอไิ์ิๅึࠦวๅลึี฾࠭䉾"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䉿"),message)
		if l1ll111lll_l1_==1 and l11lll1ll1l1_l1_<l11lll1l11l1_l1_: server = l11lll1ll1ll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠩ䊀")+l1l111ll1ll1_l1_
	else: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䊁"),l11ll1_l1_ (u"ࠩࠪ䊂"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䊃"),l11ll1_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํะิࠦวๅีํีๆืࠠศๆหำ๏๊ࠧ䊄"))
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭䊅")+l1lll111llll_l1_,server)
	return
def PLAY(l1lll111llll_l1_,url,type):
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䊆")+l1lll111llll_l1_)
	l11l11l111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ䊇")+l1lll111llll_l1_)
	if l111llll11_l1_ or l11l11l111_l1_:
		url += l11ll1_l1_ (u"ࠨࡾࠪ䊈")
		if l111llll11_l1_: url += l11ll1_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ䊉")+l111llll11_l1_
		if l11l11l111_l1_: url += l11ll1_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䊊")+l11l11l111_l1_
		url = url.replace(l11ll1_l1_ (u"ࠫࢁࠬࠧ䊋"),l11ll1_l1_ (u"ࠬࢂࠧ䊌"))
	#l1111l1l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ䊍")+l1lll111llll_l1_)
	#if l1111l1l1l_l1_:
	#	l1l11111l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ䊎"),url,re.DOTALL)
	#	url = url.replace(l1l11111l1l1_l1_[0],l1111l1l1l_l1_)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(l1lll111llll_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䊏"),l11ll1_l1_ (u"ࠩࠪ䊐"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䊑"),l11ll1_l1_ (u"ࠫฯำะ๋ำ้ࠣ์๋้้ࠠส้ࠥาฯศࠢ࠱ࠤ๏ืฬ๊ࠢ฼ำ๊ࠦส฻์ํี์ࠦลัษࠣ็๋ะࠠๅษࠣฮ฾ืแࠡ็สࠤ์๎ࠠ࠯ࠢࠣ์฾ีๅࠡฬ฽๎๏ื็ࠡว็หࠥ฿ๆะࠢส่฻ื่าหࠣห้่ี้๋ࠣ࠲ࠥอไฮษฯอ๊ࠥ็ัษࠣห้ะฺ๋์ิࠤ์๐ࠠโไฺࠤสึวูࠡ็ฬฯࠦๅ็ๅุࠣึ้ษࠡโࡐ࠷࡚ࠦร็ࠢอ฽๊๊่ࠠาสࠤฬ๊ส฻์ํีࠥ࠴้ࠠใๅ฻ࠥ฿ๆะ็สࠤฯูสฯั่ࠤำีๅสࠢใࡑ࠸࡛ࠠหฯอหัࠦเࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤำอีࠨ䊒"))
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䊓")+l1lll111llll_l1_)
	l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䊔"),l11ll1_l1_ (u"ࠧศีอาิอๅࠡษ็วฺ๊๊ࠨ䊕"),l11ll1_l1_ (u"ࠨฬ฼ำ๏๊ࠠศๆๅำ๏๋ࠧ䊖"),l111llll11_l1_,l11ll1_l1_ (u"๊ࠩิฬࠦ็้ࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠศๆ่ืฯิฯๆࠢะห้๐วࠡ็฼ࠤๅࡓ࠳ࡖࠢส่ี๐ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะูะ์็๋ࠥษๅࠡฬิ๎ิࠦลฺษาฮ์ࠦลๅ๋ࠣ์฻฿๊สࠢส่ฯัศ๋ฬࠣห้ษีๅ์ࠣ์ฬ๊ส๋ࠢอๆึ๐ศศࠢอ๊ฬูศࠡฮ่๎฾ࠦิาๅสฮࠥๆࡍ࠴ࡗࠣรࠦ࠭䊗"))
	if l111l1l11ll_l1_==1: l111llll11_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠪว่ะศࠡโࡐ࠷࡚ࠦࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣะิ๐ฯࠨ䊘"),l111llll11_l1_,True)
	else: l111llll11_l1_ = l11ll1_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ䊙")
	if l111llll11_l1_==l11ll1_l1_ (u"ࠬࠦࠧ䊚"):
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䊛"),l11ll1_l1_ (u"ࠧࠨ䊜"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䊝"),l11ll1_l1_ (u"ࠩ฽๎ึࠦๅิ็๋ัࠥษำหะาห๊ࠦแาษ฽ࠤ้๎อะ้ࠣวํูࠦะหࠣๅึอฺศฬ่ࠣํำฯ่ษࠣ࠲࠳࠴๋ࠠฮหࠤส๋วࠡฬิ็์ࠦแศำ฽ࠤฯ๋วๆษࠣวํࠦลืษไอࠥำัโࠢฦ์ࠥษ๊ࠡึํࠤวิัࠡ็฼๋ฬ࠭䊞"))
		return
	l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䊟"),l11ll1_l1_ (u"ࠫࠬ䊠"),l11ll1_l1_ (u"ࠬ࠭䊡"),l111llll11_l1_,l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅ้ࠡำหࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣฬิ๊วࠡ็้ࠤࠥอไใัํ้ࠥลࠧ䊢"))
	if l111l1l11ll_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䊣"),l11ll1_l1_ (u"ࠨࠩ䊤"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䊥"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧ䊦"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ䊧")+l1lll111llll_l1_,l111llll11_l1_)
	#l1l1111lll1l_l1_(l1lll111llll_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_)
	return
def ADD_REFERER(l1lll111llll_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䊨"),l11ll1_l1_ (u"࠭ࠧ䊩"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䊪"),l11ll1_l1_ (u"ࠨฬะิ๏ืࠠๆ้่ࠤํํวๆࠢฯำฬࠦ࠮ࠡ์ิะ๎ูࠦะ็ࠣฮ฿๐๊า้ࠣษีอࠠไ่อࠤ้อࠠห฻ิๅ๋ࠥว้๋ࠡࠤ࠳้ࠦࠠ฻า้ࠥะฺ๋์ิ๋ࠥหไศࠢ฼๊ิࠦวๅุิ์ึฯࠠศๆๅูํ๏ࠠ࠯ࠢส่าอฬสࠢ็๋ีอࠠศๆอ฾๏๐ั้ࠡํࠤๆ่ืࠡวำหࠥ฽ไษฬ้๋้ࠣࠠีำๆอࠥๆࡍ࠴ࡗࠣว๋ࠦสฺ็็ࠤ์ึวࠡษ็ฮ฿๐๊าࠢ࠱ࠤํ็โุࠢ฼๊ิ๋วࠡฬึฮำีๅࠡะา้ฮࠦเࡎ࠵ࡘࠤฯำสศฮࠣไࡗ࡫ࡦࡦࡴࡨࡶࠥิวึࠩ䊫"))
	l11l11l111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫ䊬")+l1lll111llll_l1_)
	l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䊭"),l11ll1_l1_ (u"ࠫฬูสฯัส้ࠥอไฤื็๎ࠬ䊮"),l11ll1_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ䊯"),l11l11l111_l1_,l11ll1_l1_ (u"࠭็ัษ๋ࠣํࠦเࡓࡧࡩࡩࡷ࡫ࡲࠡษ็ุ้ะฮะ็ࠣัฬ๊๊ศ่ࠢ฽ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦสฺัํ่์ࠦรๆࠢอี๏ีࠠฦ฻สำฯํࠠฦๆ์ࠤํ฼ู๋หࠣห้ะหษ์อࠤฬ๊รึๆํࠤํอไห์ࠣฮ็ื๊ษษࠣฮ๋อำษࠢฯ้๏฿ࠠีำๆหฯࠦเࡎ࠵ࡘࠤฤࠧࠧ䊰"))
	if l111l1l11ll_l1_==1: refererr = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠧฤๅอฬࠥๆࡍ࠴ࡗࠣࡖࡪ࡬ࡥࡳࡧࡵࠤัี๊ะࠩ䊱"),l11l11l111_l1_,True)
	else: l11l11l111_l1_ = l11ll1_l1_ (u"ࠨࠩ䊲")
	if l11l11l111_l1_==l11ll1_l1_ (u"ࠩࠣࠫ䊳"):
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䊴"),l11ll1_l1_ (u"ࠫࠬ䊵"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䊶"),l11ll1_l1_ (u"ฺ๋࠭ำุ้๋่ࠣฮࠢฦืฯิฯศ็ࠣๅึอฺࠡๆ๋ัิํࠠฤ๊ࠣ฽ิฯࠠโำส฾ฬะࠠๅ๊ะำ์อࠠ࠯࠰࠱ࠤ๏าศࠡว่หࠥะัไ้ࠣๅฬืฺࠡฬ่ห๊อࠠฤ๊ࠣษ฻อแสࠢะีๆࠦร้ࠢฦ๎ฺ๊ࠥࠡฤัีู๋่ࠥษࠪ䊷"))
		return
	l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䊸"),l11ll1_l1_ (u"ࠨࠩ䊹"),l11ll1_l1_ (u"ࠩࠪ䊺"),l11l11l111_l1_,l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥํะศࠢใࡖࡪ࡬ࡥࡳࡧࡵࠤอีไศ่๊ࠢࠥࠦวๅไา๎๊ࠦฟࠨ䊻"))
	if l111l1l11ll_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䊼"),l11ll1_l1_ (u"ࠬ࠭䊽"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䊾"),l11ll1_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ䊿"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ䋀")+l1lll111llll_l1_,l11l11l111_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_)
	return
def GET_URL(l1lll111llll_l1_,l11lll11l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ䋁")):
	if not l11lll11l1l1_l1_: l11lll11l1l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䋂")+l1lll111llll_l1_)
	server = SERVER(l11lll11l1l1_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䋃"))
	username = re.findall(l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ䋄"),l11lll11l1l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ䋅"),re.DOTALL)
	password = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠩ䋆"),l11lll11l1l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪ䋇"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䋈"),l11ll1_l1_ (u"ࠪࠫ䋉"),l11ll1_l1_ (u"ࠫๆำีࠡษืฮึอใࠡโࡐ࠷࡚࠭䋊"),l11ll1_l1_ (u"ࠬืวษูࠣหูะัศๅࠣไࡒ࠹ࡕࠡษ็ิ๏ࠦโๆฬࠣห๋ะࠠษวูหๆะ็ࠡว็ํࠥอไษำ้ห๊าࠠๅษࠣ๎฾๋ไࠡล๋ࠤฬ๊ัศสฺࠤ฿๐ัࠡ็๋ะํีࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴ࠠฤา๊ฬࠥหไ๊ࠢๅหห๋ษࠡษืฮึอใࠡโࡐ࠷่࡚ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡐ࠷࡚ࠦฬะ์าࠤศ๎ࠠใ็ࠣฬส฻ไศฯࠣห้ืวษูࠣห้่ฯ๋็ࠪ䋋"))
		return l11ll1_l1_ (u"࠭ࠧ䋌"),l11ll1_l1_ (u"ࠧࠨ䋍"),l11ll1_l1_ (u"ࠨࠩ䋎"),l11ll1_l1_ (u"ࠩࠪ䋏"),l11ll1_l1_ (u"ࠪࠫ䋐")
	username = username[0]
	password = password[0]
	l1l111lllll1_l1_ = server+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻࡨࡶࡤࡧࡰࡪ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ䋑")+username+l11ll1_l1_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ䋒")+password
	l11lllll1l1l_l1_ = server+l11ll1_l1_ (u"࠭࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ䋓")+username+l11ll1_l1_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ䋔")+password+l11ll1_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࡮࠵ࡸࡣࡵࡲࡵࡴࠩ䋕")
	return l1l111lllll1_l1_,l11lllll1l1l_l1_,server,username,password
def GET_FILENAME(l1lll111llll_l1_,l1l111l1lll1_l1_=l11ll1_l1_ (u"ࠩࠪ䋖")):
	l1l111111l11_l1_ = l1l111l1lll1_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࠬ䋗"),l11ll1_l1_ (u"ࠫࡤ࠭䋘")).replace(l11ll1_l1_ (u"ࠬࡀࠧ䋙"),l11ll1_l1_ (u"࠭࡟ࠨ䋚")).replace(l11ll1_l1_ (u"ࠧ࠯ࠩ䋛"),l11ll1_l1_ (u"ࠨࡡࠪ䋜"))
	l1l111111l11_l1_ = l1l111111l11_l1_.replace(l11ll1_l1_ (u"ࠩࡂࠫ䋝"),l11ll1_l1_ (u"ࠪࡣࠬ䋞")).replace(l11ll1_l1_ (u"ࠫࡂ࠭䋟"),l11ll1_l1_ (u"ࠬࡥࠧ䋠")).replace(l11ll1_l1_ (u"࠭ࠦࠨ䋡"),l11ll1_l1_ (u"ࠧࡠࠩ䋢"))
	l1l111111l11_l1_ = os.path.join(addoncachefolder,l1l111111l11_l1_).strip(l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠭䋣"))+l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻࠧ䋤")
	return l1l111111l11_l1_
def ADD_ACCOUNT(l1lll111llll_l1_,l111l1ll_l1_):
	l1l1111l1lll_l1_ = l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䋥")
	if l111l1ll_l1_: l1l1111l1lll_l1_ = l11ll1_l1_ (u"ࠫส฼วโหࠣ์ฯเ๊๋ำࠣีฬฮืࠡࠩ䋦")+text_numbers[int(l111l1ll_l1_)]
	l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䋧"),l11ll1_l1_ (u"࠭ࠧ䋨"),l11ll1_l1_ (u"ࠧࠨ䋩"),l1l1111l1lll_l1_,l11ll1_l1_ (u"ࠨ้ำหࠥอไอิฤࠤ๊์ࠠศๆหี๋อๅอࠢํัฯอฬࠡำสฬ฼ࠦแ๋ัํ์์อสࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦร้ࠢฦุฯืวไ่ࠢำๆ๎ูࠡ็้ࠤฬ๊ิาๅสฮࠥอไห์ࠣฮอ๐ู่๋ࠢห้ืวษู้๋ࠣࠦๆ้฻ࠣࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞࡯࠶ࡹࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤํํะศ่ࠢฯฬ๊ࠠๅฬฺ๋๏ำࠠีๅ็ࠤ์ึวࠡษ็ีฬฮืࠡ࡞ࡱࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡰࡵࡸ࠰ࡳࡷ࡭࠮ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡪࡱ࠲࡭ࡵࡺࡶ࠰࡮ࡤࡲ࡬ࡻࡡࡨࡧࡶ࠳ࡦࡸࡡ࠯࡯࠶ࡹࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢศฺฬ็ษࠡล๋ࠤฯเ๊๋ำࠣวํࠦๅิฯࠣห้ืวษูࠣห้ศๆࠡมࠪ䋪"))
	if l111l1l11ll_l1_!=1: return
	l1l111l1l1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ䋫")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䋬")+l111l1ll_l1_)
	l11lll11lll1_l1_ = True
	if l1l111l1l1ll_l1_:
		l111l1l11ll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䋭"),l11ll1_l1_ (u"้ࠬสศสฬࠤัี๊ะࠩ䋮"),l11ll1_l1_ (u"࠭สฺัํ่ࠥอไใัํ้ࠬ䋯"),l11ll1_l1_ (u"ࠧๆีะࠤฬ๊โะ์่ࠫ䋰"),l11ll1_l1_ (u"ࠨษ็ีฬฮืࠡษ็ัฬ๊๊้๋ࠡ࠾ࠬ䋱"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䋲")+l1l111l1l1ll_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䋳")+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯๊ࠢิฬࠦ็้ࠢิหอ฽ࠠแࡏ࠶࡙ࠥอไๆีฯ่ࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬ฼ำ๏๊็ࠡล่ࠤฯื๊ะࠢๆฮฬฮษࠡำสฬ฼ࠦฬะ์าࠤฤࠧࠧ䋴"))
		if l111l1l11ll_l1_==-1: return
		elif l111l1l11ll_l1_==0: l1l111l1l1ll_l1_ = l11ll1_l1_ (u"ࠬ࠭䋵")
		elif l111l1l11ll_l1_==2:
			l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䋶"),l11ll1_l1_ (u"ࠧࠨ䋷"),l11ll1_l1_ (u"ࠨࠩ䋸"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䋹"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡษ็ีฬฮืࠡษ็ุ้าไࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠩ䋺"))
			if l111l1l11ll_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䋻"),l11ll1_l1_ (u"ࠬ࠭䋼"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䋽"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠศๆิหอ฽ࠧ䋾"))
			l11lll11lll1_l1_ = False
			l11llll1ll11_l1_ = l11ll1_l1_ (u"ࠨࠩ䋿")
	if l11lll11lll1_l1_:
		l11llll1ll11_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠩส็ฯฮࠠาษห฻ࠥๆࡍ࠴ࡗࠣ็ฬ๋ไศࠩ䌀"),l1l111l1l1ll_l1_)
		l11llll1ll11_l1_ = l11llll1ll11_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ䌁"))
		if not l11llll1ll11_l1_:
			l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䌂"),l11ll1_l1_ (u"ࠬ࠭䌃"),l11ll1_l1_ (u"࠭ࠧ䌄"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䌅"),l11ll1_l1_ (u"ࠨๆๅำ่ࠥๅหࠢหษิิวๅࠢิหอ฽ࠠโษิ฾ࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦวๅำสฬ฼ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ䌆"))
			if l111l1l11ll_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䌇"),l11ll1_l1_ (u"ࠪࠫ䌈"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䌉"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥอไาษห฻ࠬ䌊"))
		else:
			#l1l111lllll1_l1_,l11lllll1l1l_l1_,server,username,password = GET_URL(l1lll111llll_l1_)
			#if not username: return
			message = l11ll1_l1_ (u"࠭็ั้ࠣหู้๋ๅ๊่หฯࠦสๆࠢฦาีํวࠡ็้ࠤึอศุࠢใࡑ࠸࡛ࠠศๆำ๎ࠥอๆหࠢๆฮอะ็ࠡ࠰๋้ࠣࠦสา์าࠤฬูสฯัส้์อࠠภࠣ࡟ࡲࠬ䌋")
			#message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䌌")+server+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟฼๊ํอๆࠡษ็ื๏ืแา࠼ࠣࠫ䌍")
			#message += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䌎")+username+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡฬูๅࠡษ็ุ้ะฮะ็࠽ࠤࠬ䌏")
			#message += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䌐")+password+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣใๅ็ฬࠤฬ๊ำา࠼ࠣࠫ䌑")
			l111l1l11ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ䌒"),l11ll1_l1_ (u"ࠧࠨ䌓"),l11ll1_l1_ (u"ࠨࠩ䌔"),l11ll1_l1_ (u"ࠩส่ึอศุࠢส่ัี๊ะ๊ࠢ์࠿࠭䌕"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䌖")+l11llll1ll11_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䌗")+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䌘")+message)
			if l111l1l11ll_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䌙"),l11ll1_l1_ (u"ࠧࠨ䌚"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌛"),l11ll1_l1_ (u"ࠩอ้ࠥอไฦๆ฽หฦ࠭䌜"))
				return
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䌝")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䌞")+l111l1ll_l1_,l11llll1ll11_l1_)
	#settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ䌟")+l1lll111llll_l1_,l11ll1_l1_ (u"࠭ࠧ䌠"))
	#settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡩ࡯ࡦࡧࡡࠪ䌡")+l1lll111llll_l1_,l11ll1_l1_ (u"ࠨࠩ䌢"))
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭䌣")+l1lll111llll_l1_)
	if not l111llll11_l1_: settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ䌤")+l1lll111llll_l1_,l11ll1_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ䌥"))
	#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䌦"),l11ll1_l1_ (u"࠭ࠧ䌧"),l11ll1_l1_ (u"ࠧࠨ䌨"),l11ll1_l1_ (u"ࠨࠩ䌩"),l11llll1ll11_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴสๆࠢอ฾๏ืࠠาษห฻ࠥอิหำส็ࠥๆࡍ࠴ࡗࠣษ้๏่ࠠาสࠤฬ๊ัศสฺࠤฬ๊ฬะ์าࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢไัฺࠦ็ัษࠣห้ืวษูࠣห้ศๆࠡมࠪ䌪"))
	#if l1ll111lll_l1_==1: ok,l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = CHECK_ACCOUNT(l1lll111llll_l1_,True)
	#l1l1111lll1l_l1_(l1lll111llll_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_)
	return
def READ_ALL_LINES(lines,l1l111l1ll1l_l1_,l1l1111111l1_l1_,l11l1ll111_l1_,length,l1ll1l11ll11_l1_,l11lllll1l1l_l1_):
	l1ll1l111l11_l1_,l11lll11l111_l1_ = [],[]
	l11lll1l11ll_l1_ = [l11ll1_l1_ (u"ࠪ࠲ࡦࡼࡩࠨ䌫"),l11ll1_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䌬"),l11ll1_l1_ (u"ࠬ࠴࡭࡬ࡸࠪ䌭"),l11ll1_l1_ (u"࠭࠮ࡧ࡮ࡹࠫ䌮"),l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ䌯"),l11ll1_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ䌰")]
	for line in lines:
		if l1ll1l11ll11_l1_%473==0:
			PROGRESS_UPDATE(l11l1ll111_l1_,40+int(10*l1ll1l11ll11_l1_/length),l11ll1_l1_ (u"ࠩๅีฬวษࠡษ็ๅ๏ี๊้้สฮࠬ䌱"),l11ll1_l1_ (u"ࠪห้็๊ะ์๋ࠤึ่ๅ࠻࠯ࠪ䌲"),str(l1ll1l11ll11_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ䌳")+str(length))
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return None,None,None
		url = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡡࡴࠫࠩࠪ࡫ࡸࡹࡶࡼࡩࡶࡷࡴࡸࢂࡲࡵ࡯ࡳ࠭࠳࠰࠿ࠪࠦࠪ䌴"),line,re.DOTALL)
		if url:
			line,url,dummy = url[0]
			url = url.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ䌵"),l11ll1_l1_ (u"ࠧࠨ䌶"))
			line = line.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ䌷"),l11ll1_l1_ (u"ࠩࠪ䌸"))
		else:
			l11lll11l111_l1_.append({l11ll1_l1_ (u"ࠪࡰ࡮ࡴࡥࠨ䌹"):line})
			continue
		l1l1111l1l1l_l1_,context,group,title,type,l1l11111lll1_l1_ = {},l11ll1_l1_ (u"ࠫࠬ䌺"),l11ll1_l1_ (u"ࠬ࠭䌻"),l11ll1_l1_ (u"࠭ࠧ䌼"),l11ll1_l1_ (u"ࠧࠨ䌽"),False
		try:
			line,title = line.rsplit(l11ll1_l1_ (u"ࠨࠤ࠯ࠫ䌾"),1)
			line = line+l11ll1_l1_ (u"ࠩࠥࠫ䌿")
		except:
			try: line,title = line.rsplit(l11ll1_l1_ (u"ࠪ࠵࠱࠭䍀"),1)
			except: title = l11ll1_l1_ (u"ࠫࠬ䍁")
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ䍂")] = url
		params = re.findall(l11ll1_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䍃"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11ll1_l1_ (u"ࠧࠣࠩ䍄"),l11ll1_l1_ (u"ࠨࠩ䍅")).strip(l11ll1_l1_ (u"ࠩࠣࠫ䍆"))
			l1l1111l1l1l_l1_[key] = value.strip(l11ll1_l1_ (u"ࠪࠤࠬ䍇"))
		keys = list(l1l1111l1l1l_l1_.keys())
		if not title:
			if l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䍈") in keys and l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䍉")]: title = l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䍊")]
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䍋")] = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ䍌")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䍍"),l11ll1_l1_ (u"ࠪࠤࠬ䍎")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䍏"),l11ll1_l1_ (u"ࠬࠦࠧ䍐"))
		if l11ll1_l1_ (u"࠭࡬ࡰࡩࡲࠫ䍑") in keys:
			l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠫ䍒")] = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭䍓")]
			del l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩ࡯ࡳ࡬ࡵࠧ䍔")]
		else: l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ䍕")] = l11ll1_l1_ (u"ࠫࠬ䍖")
		if l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ䍗") in keys and l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䍘")]: group = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭䍙")]
		if any(value in url.lower() for value in l11lll1l11ll_l1_): l1l11111lll1_l1_ = True
		if l1l11111lll1_l1_ or l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䍚") in group or l11ll1_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭䍛") in group:
			type = l11ll1_l1_ (u"࡚ࠪࡔࡊࠧ䍜")
			if l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䍝") in group: type = type+l11ll1_l1_ (u"ࠬࡥࡓࡆࡔࡌࡉࡘ࠭䍞")
			elif l11ll1_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ䍟") in group: type = type+l11ll1_l1_ (u"ࠧࡠࡏࡒ࡚ࡎࡋࡓࠨ䍠")
			else: type = type+l11ll1_l1_ (u"ࠨࡡࡘࡒࡐࡔࡏࡘࡐࠪ䍡")
			group = group.replace(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䍢"),l11ll1_l1_ (u"ࠪࠫ䍣")).replace(l11ll1_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ䍤"),l11ll1_l1_ (u"ࠬ࠭䍥"))
		else:
			type = l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䍦")
			if title in l1l111l1ll1l_l1_: context = context+l11ll1_l1_ (u"ࠧࡠࡇࡓࡋࠬ䍧")
			if title in l1l1111111l1_l1_: context = context+l11ll1_l1_ (u"ࠨࡡࡄࡖࡈࡎࡉࡗࡇࡇࠫ䍨")
			if not group: type = type+l11ll1_l1_ (u"ࠩࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ䍩")
			else: type = type+context
		group = group.strip(l11ll1_l1_ (u"ࠪࠤࠬ䍪")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䍫"),l11ll1_l1_ (u"ࠬࠦࠧ䍬")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䍭"),l11ll1_l1_ (u"ࠧࠡࠩ䍮"))
		if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔࠧ䍯") in type: group = l11ll1_l1_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡍࡋ࡙ࡉࡤࡥࠡࠢࠩ䍰")
		elif l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࠨ䍱") in type: group = l11ll1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡ࡙ࡓࡉࡥ࡟ࠢࠣࠪ䍲")
		elif l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࠩ䍳") in type:
			l1l111l1l11l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥࡡࡓࡴ࡟࡟ࡨ࠰ࠦࠫ࡜ࡇࡨࡡࡡࡪࠫࠨ䍴"),l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䍵")],re.DOTALL)
			if l1l111l1l11l_l1_: l1l111l1l11l_l1_ = l1l111l1l11l_l1_[0]
			else: l1l111l1l11l_l1_ = l11ll1_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠢࠣࠪ䍶")
			group = group+l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䍷")+l1l111l1l11l_l1_
		l11lll1l1l_l1_ = l11ll1_l1_ (u"ࠪࠫ䍸")
		if l11ll1_l1_ (u"ࠫ࡮ࡪࠧ䍹") in keys:
			l11lll1l1l_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬ࡯ࡤࠨ䍺")]
			del l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡩࡥࠩ䍻")]
		if l11ll1_l1_ (u"ࠧࡊࡆࠪ䍼") in keys:
			l11lll1l1l_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡋࡇࠫ䍽")]
			del l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩࡌࡈࠬ䍾")]
		if l11ll1_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮ࡱࡵ࡫ࠬ䍿") in l11lllll1l1l_l1_ and l11ll1_l1_ (u"ࠫ࠳࠭䎀") in l11lll1l1l_l1_:
			l11lll1l1l_l1_ = l11lll1l1l_l1_.rsplit(l11ll1_l1_ (u"ࠬ࠴ࠧ䎁"),1)[1]
			l11lll1l1l_l1_ = l11ll1_l1_ (u"࠭ࡼࠨ䎂")+l11lll1l1l_l1_.upper()+l11ll1_l1_ (u"ࠧࡽࠢࠪ䎃")
		if l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭䎄") in keys: del l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䎅")]
		title = l11lll1l1l_l1_+l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䎆")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l1ll1l11l111_l1_,title = SPLIT_NAME(title)
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䎇")] = type
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭䎈")] = context
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䎉")] = group.upper()
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䎊")] = title.upper()
		try: l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ䎋")] = COUNTRIES_CODES[l1ll1l11l111_l1_.upper()]
		except: l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ䎌")] = l1ll1l11l111_l1_.upper()
		#dictt1[l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䎍")] = countryy.upper()
		l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䎎")] = language.upper()
		l1ll1l111l11_l1_.append(l1l1111l1l1l_l1_)
		l1ll1l11ll11_l1_ += 1
	return l1ll1l111l11_l1_,l1ll1l11ll11_l1_,l11lll11l111_l1_
def CLEAN_NAME(title):
	title = title.replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䎏"),l11ll1_l1_ (u"࠭ࠠࠨ䎐")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䎑"),l11ll1_l1_ (u"ࠨࠢࠪ䎒")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䎓"),l11ll1_l1_ (u"ࠪࠤࠬ䎔"))
	title = title.replace(l11ll1_l1_ (u"ࠫࢁࢂࠧ䎕"),l11ll1_l1_ (u"ࠬࢂࠧ䎖")).replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ䎗"),l11ll1_l1_ (u"ࠧ࠻ࠩ䎘")).replace(l11ll1_l1_ (u"ࠨ࠯࠰ࠫ䎙"),l11ll1_l1_ (u"ࠩ࠰ࠫ䎚"))
	title = title.replace(l11ll1_l1_ (u"ࠪ࡟ࡠ࠭䎛"),l11ll1_l1_ (u"ࠫࡠ࠭䎜")).replace(l11ll1_l1_ (u"ࠬࡣ࡝ࠨ䎝"),l11ll1_l1_ (u"࠭࡝ࠨ䎞"))
	title = title.replace(l11ll1_l1_ (u"ࠧࠩࠪࠪ䎟"),l11ll1_l1_ (u"ࠨࠪࠪ䎠")).replace(l11ll1_l1_ (u"ࠩࠬ࠭ࠬ䎡"),l11ll1_l1_ (u"ࠪ࠭ࠬ䎢"))
	title = title.replace(l11ll1_l1_ (u"ࠫࡁࡂࠧ䎣"),l11ll1_l1_ (u"ࠬࡂࠧ䎤")).replace(l11ll1_l1_ (u"࠭࠾࠿ࠩ䎥"),l11ll1_l1_ (u"ࠧ࠿ࠩ䎦"))
	title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ䎧"))
	return title
def CREATE_GROUPED_STREAMS(l11llll1llll_l1_,l11l1ll111_l1_,l111l1ll_l1_):
	l1l1111111ll_l1_ = {}
	for l11lll111_l1_ in l11llllll111_l1_: l1l1111111ll_l1_[l11lll111_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䎨")+l111l1ll_l1_] = []
	length = len(l11llll1llll_l1_)
	l1l1l1ll11_l1_ = str(length)
	l1ll1l11ll11_l1_ = 0
	l11lll11l111_l1_ = []
	for l1l1111l1l1l_l1_ in l11llll1llll_l1_:
		if l1ll1l11ll11_l1_%873==0:
			PROGRESS_UPDATE(l11l1ll111_l1_,50+int(5*l1ll1l11ll11_l1_/length),l11ll1_l1_ (u"ࠪฮฺ์๊โࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ฼ํี๋ࠥัหสฬࠫ䎩"),l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ䎪"),str(l1ll1l11ll11_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䎫")+l1l1l1ll11_l1_)
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return None,None
		group,context,title,url,l1lll1_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䎬")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ䎭")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䎮")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭䎯")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ䎰")]
		l1ll1l11l111_l1_,language,l11lll111_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ䎱")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ䎲")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ䎳")]
		l1l111l11l11_l1_ = (group,context,title,url,l1lll1_l1_)
		l1lll1l11l1_l1_ = False
		if l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䎴") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ䎵") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䎶")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䎷") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䎸")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			else: l1lll1l11l1_l1_ = True
			l1l1111111ll_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䎹")+l111l1ll_l1_].append(l1l111l11l11_l1_)
		elif l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ䎺") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䎻") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࠨ䎼")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			elif l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ䎽") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䎾")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			elif l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ䎿") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䏀")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			else: l1lll1l11l1_l1_ = True
			l1l1111111ll_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䏁")+l111l1ll_l1_].append(l1l111l11l11_l1_)
		else: l1lll1l11l1_l1_ = True
		if l1lll1l11l1_l1_: l11lll11l111_l1_.append(l1l1111l1l1l_l1_)
		l1ll1l11ll11_l1_ += 1
	l11lllllll11_l1_ = sorted(l11llll1llll_l1_,reverse=False,key=lambda key: key[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䏂")].lower())
	del l11llll1llll_l1_
	l1l1l1ll11_l1_ = str(length)
	l1ll1l11ll11_l1_ = 0
	for l1l1111l1l1l_l1_ in l11lllllll11_l1_:
		l1ll1l11ll11_l1_ += 1
		if l1ll1l11ll11_l1_%873==0:
			PROGRESS_UPDATE(l11l1ll111_l1_,55+int(5*l1ll1l11ll11_l1_/length),l11ll1_l1_ (u"ࠨฬุ๊๏็ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅาฬหอࠬ䏃"),l11ll1_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ䏄"),str(l1ll1l11ll11_l1_)+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䏅")+l1l1l1ll11_l1_)
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return None,None
		l11lll111_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䏆")]
		group,context,title,url,l1lll1_l1_ = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ䏇")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ䏈")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䏉")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ䏊")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭䏋")]
		l1ll1l11l111_l1_,language = l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䏌")],l1l1111l1l1l_l1_[l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䏍")]
		l1l111l11l1l_l1_ = (group,context+l11ll1_l1_ (u"ࠬࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ䏎"),title,url,l1lll1_l1_)
		l1l111l11l11_l1_ = (group,context,title,url,l1lll1_l1_)
		l1l111l111ll_l1_ = (l1ll1l11l111_l1_,context,title,url,l1lll1_l1_)
		l1l111l111l1_l1_ = (language,context,title,url,l1lll1_l1_)
		if l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䏏") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䏐") in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏑")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			else: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏒")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			if l11ll1_l1_ (u"ࠪࡉࡕࡍࠧ䏓")		in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏔")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			if l11ll1_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ䏕")	in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏖")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			if l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䏗")	in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䏘")+l111l1ll_l1_].append(l1l111l11l1l_l1_)
			l1l1111111ll_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࡢࠫ䏙")+l111l1ll_l1_].append(l1l111l111ll_l1_)
			l1l1111111ll_l1_[l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䏚")+l111l1ll_l1_].append(l1l111l111l1_l1_)
		elif l11ll1_l1_ (u"࡛ࠫࡕࡄࠨ䏛") in l11lll111_l1_:
			if   l11ll1_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓ࠭䏜")	in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䏝")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			elif l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧ䏞")	in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ䏟")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			elif l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ䏠")	in l11lll111_l1_: l1l1111111ll_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏡")+l111l1ll_l1_].append(l1l111l11l11_l1_)
			l1l1111111ll_l1_[l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࡣࠬ䏢")+l111l1ll_l1_].append(l1l111l111ll_l1_)
			l1l1111111ll_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉࡥࠧ䏣")+l111l1ll_l1_].append(l1l111l111l1_l1_)
	return l1l1111111ll_l1_,l11lll11l111_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l1ll1l_l1_,sep = l11ll1_l1_ (u"࠭ࠧ䏤"),l11ll1_l1_ (u"ࠧࠨ䏥")
	l1lll1l1l_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11ll1_l1_ (u"ࠨࠪࠪ䏦"): sep = l11ll1_l1_ (u"ࠩࠬࠫ䏧")
	elif first==l11ll1_l1_ (u"ࠪ࡟ࠬ䏨"): sep = l11ll1_l1_ (u"ࠫࡢ࠭䏩")
	elif first==l11ll1_l1_ (u"ࠬࡂࠧ䏪"): sep = l11ll1_l1_ (u"࠭࠾ࠨ䏫")
	elif first==l11ll1_l1_ (u"ࠧࡽࠩ䏬"): sep = l11ll1_l1_ (u"ࠨࡾࠪ䏭")
	if sep and (sep in rest):
		l1l1lll1l111_l1_,l1l1lll11lll_l1_ = rest.split(sep,1)
		l1ll1l1ll1l_l1_ = l1l1lll1l111_l1_
		l1lll1l1l_l1_ = first+l1l1lll1l111_l1_+sep+l11ll1_l1_ (u"ࠩࠣࠫ䏮")+l1l1lll11lll_l1_
	elif title.count(l11ll1_l1_ (u"ࠪࢀࠬ䏯"))>=2:
		l1l1lll1l111_l1_,l1l1lll11lll_l1_ = title.split(l11ll1_l1_ (u"ࠫࢁ࠭䏰"),1)
		l1ll1l1ll1l_l1_ = l1l1lll1l111_l1_
		l1lll1l1l_l1_ = l1l1lll1l111_l1_+l11ll1_l1_ (u"ࠬࠦࡼࠨ䏱")+l1l1lll11lll_l1_
	else:
		sep = re.findall(l11ll1_l1_ (u"࠭࡞࡝ࡹࡾ࠶ࢂ࠮ࠠࡽ࡞࠽ࢀࡡ࠳ࡼ࡝ࡾࡿࡠࡢࢂ࡜ࠪࡾ࡟ࠧࢁࡢ࠮ࡽ࡞࠯ࢀࡡࠪࡼ࡝ࠩࡿࡠࠦࢂ࡜ࡁࡾ࡟ࠩࢁࡢࠦࡽ࡞࠭ࢀࡡࡤࠩࠨ䏲"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠧ࡟࡞ࡺࡿ࠸ࢃࠨࠡࡾ࡟࠾ࢁࡢ࠭ࡽ࡞ࡿࢀࡡࡣࡼ࡝ࠫࡿࡠࠨࢂ࡜࠯ࡾ࡟࠰ࢁࡢࠤࡽ࡞ࠪࢀࡡࠧࡼ࡝ࡂࡿࡠࠪࢂ࡜ࠧࡾ࡟࠮ࢁࡢ࡞ࠪࠩ䏳"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠨࡠ࡟ࡻࢀ࠺ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ䏴"),title,re.DOTALL)
		if sep:
			l1l1lll1l111_l1_,l1l1lll11lll_l1_ = title.split(sep[0],1)
			l1ll1l1ll1l_l1_ = l1l1lll1l111_l1_
			l1lll1l1l_l1_ = l1l1lll1l111_l1_+l11ll1_l1_ (u"ࠩࠣࠫ䏵")+sep[0]+l11ll1_l1_ (u"ࠪࠤࠬ䏶")+l1l1lll11lll_l1_
	l1lll1l1l_l1_ = l1lll1l1l_l1_.replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ䏷"),l11ll1_l1_ (u"ࠬࠦࠧ䏸")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䏹"),l11ll1_l1_ (u"ࠧࠡࠩ䏺"))
	l1ll1l1ll1l_l1_ = l1ll1l1ll1l_l1_.replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䏻"),l11ll1_l1_ (u"ࠩࠣࠫ䏼"))
	if not l1ll1l1ll1l_l1_: l1ll1l1ll1l_l1_ = l11ll1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡡࠤࠥࠬ䏽")
	l1ll1l1ll1l_l1_ = l1ll1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠭䏾"))
	l1lll1l1l_l1_ = l1lll1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ䏿"))
	return l1ll1l1ll1l_l1_,l1lll1l1l_l1_
def GET_HEADERS(l1lll111llll_l1_):
	headers = {}
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䐀")+l1lll111llll_l1_)
	if l111llll11_l1_: headers[l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䐁")] = l111llll11_l1_
	l11l11l111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ䐂")+l1lll111llll_l1_)
	if l11l11l111_l1_: headers[l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䐃")] = l11l11l111_l1_
	return headers
def CREATE_STREAMS(l1lll111llll_l1_,l111l1ll_l1_):
	global l11l1ll111_l1_,l1l1111111ll_l1_,l11ll1llll1l_l1_,l1l111ll1lll_l1_,l1l111ll11l1_l1_,groups,l11lll1l1l11_l1_,l11llll11l1l_l1_,l1l111ll111l_l1_
	l11lllll1l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䐄")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䐅")+l111l1ll_l1_)
	#l1l111lllll1_l1_,l11lllll1l1l_l1_,server,username,password = GET_URL(l1lll111llll_l1_)
	#if not username: return
	l111llll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䐆")+l1lll111llll_l1_)
	headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䐇"):l111llll11_l1_}
	#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䐈"),l11ll1_l1_ (u"ࠨࠩ䐉"),l11ll1_l1_ (u"ࠩࠪ䐊"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䐋"),l11ll1_l1_ (u"ࠫ฾๋ไ๋หࠣะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠣๆิࠦสฮฬสะࠥ฿ฯสࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ็ฬࠥอไๆๆไหฯࠦวๅฤ้ࠤฤ࠭䐌"))
	#if l1ll111lll_l1_!=1: return
	l1l111111l11_l1_ = l1l1l1ll1111_l1_.replace(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ䐍"),l11ll1_l1_ (u"࠭࡟ࠨ䐎")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䐏")+l111l1ll_l1_)
	if 1:
		succeeded,l11lll1ll1ll_l1_,l1l111ll1ll1_l1_ = True,l11ll1_l1_ (u"ࠨࠩ䐐"),l11ll1_l1_ (u"ࠩࠪ䐑")
		if not succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䐒"),l11ll1_l1_ (u"ࠫࠬ䐓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䐔"),l11ll1_l1_ (u"࠭แีๆࠣฬุำศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥ࠴ࠠฤฯอ้ฬ๊ࠠาษห฻ࠥๆࡍ࠴ࡗࠣ฾๏ืࠠึฯํัࠥษ่ࠡไา๎๊ࠦร้ࠢ็หࠥ๐ูๆๆࠣ࠲࠳ูࠦๅ็สࠤศ์่ࠠา๊ࠤฬ๊ฮะ็ฬࠤฯำสศฮࠣหูะัศๅ้ࠣิ็ฺู่๋ࠢา๐อ๊ࠡํะอࠦร็ࠢอฺ๏็ࠠาษห฻ࠥอไศึอีฬ้ࠠษ่ไื่ࠦไๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣๆฬฬๅสࠢใࡑ࠸࡛ࠠศๆ่์ั๎ฯสࠢห๋ีอࠠศๆหี๋อๅอࠩ䐕"))
			if not l11lllll1l1l_l1_: LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䐖"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡓࡵࠠࡎ࠵ࡘࠤ࡚ࡘࡌࠡࡨࡲࡹࡳࡪࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡓ࠳ࡖࠢࡩ࡭ࡱ࡫ࡳࠨ䐗"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䐘"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡒ࠹ࡕࠡࡨ࡬ࡰࡪࡹࠧ䐙"))
			return
		l1l111llllll_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11lllll1l1l_l1_,headers,True)
		if not l1l111llllll_l1_: return
		open(l1l111111l11_l1_,l11ll1_l1_ (u"ࠫࡼࡨࠧ䐚")).write(l1l111llllll_l1_)
	else: l1l111llllll_l1_ = open(l1l111111l11_l1_,l11ll1_l1_ (u"ࠬࡸࡢࠨ䐛")).read()
	if kodi_version>18.99 and l1l111llllll_l1_: l1l111llllll_l1_ = l1l111llllll_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䐜"))
	#l1l111llllll_l1_ = l1l111llllll_l1_[33000111:77000111]
	l11l1ll111_l1_ = DIALOG_PROGRESS()
	l11l1ll111_l1_.create(l11ll1_l1_ (u"ࠧอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ䐝"),l11ll1_l1_ (u"ࠨࠩ䐞"))
	PROGRESS_UPDATE(l11l1ll111_l1_,15,l11ll1_l1_ (u"ࠩอ๊฽๐แࠡษ็้้็ࠠศๆิส๏ู๊ࠨ䐟"),l11ll1_l1_ (u"ࠪࠫ䐠"))
	l1l111llllll_l1_ = l1l111llllll_l1_.replace(l11ll1_l1_ (u"ࠫࠧࡺࡶࡨ࠯ࠪ䐡"),l11ll1_l1_ (u"ࠬࠨࠠࡵࡸࡪ࠱ࠬ䐢"))
	l1l111llllll_l1_ = l1l111llllll_l1_.replace(l11ll1_l1_ (u"࠭๎ࠨ䐣"),l11ll1_l1_ (u"ࠧࠨ䐤")).replace(l11ll1_l1_ (u"ࠨํࠪ䐥"),l11ll1_l1_ (u"ࠩࠪ䐦")).replace(l11ll1_l1_ (u"ࠪ๓ࠬ䐧"),l11ll1_l1_ (u"ࠫࠬ䐨")).replace(l11ll1_l1_ (u"ࠬ๒ࠧ䐩"),l11ll1_l1_ (u"࠭ࠧ䐪"))
	l1l111llllll_l1_ = l1l111llllll_l1_.replace(l11ll1_l1_ (u"ࠧ๒ࠩ䐫"),l11ll1_l1_ (u"ࠨࠩ䐬")).replace(l11ll1_l1_ (u"ࠩ๓ࠫ䐭"),l11ll1_l1_ (u"ࠪࠫ䐮")).replace(l11ll1_l1_ (u"ࠫ๒࠭䐯"),l11ll1_l1_ (u"ࠬ࠭䐰")).replace(l11ll1_l1_ (u"࠭๒ࠨ䐱"),l11ll1_l1_ (u"ࠧࠨ䐲"))
	l1l111llllll_l1_ = l1l111llllll_l1_.replace(l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠧ䐳"),l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰ࠾ࠩ䐴")).replace(l11ll1_l1_ (u"ࠪࡸࡻ࡭࠭ࠨ䐵"),l11ll1_l1_ (u"ࠫࠬ䐶"))
	l1l1111111l1_l1_,l1l111l1ll1l_l1_ = [],[]
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡓࡖࡔࡍࡒࡆࡕࡖࡣ࡚ࡖࡄࡂࡖࡈࠬࡵࡊࡩࡢ࡮ࡲ࡫࠱࠸࠰࠭ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊สࠩ࠯ࠫฬ๊ๅๅใࠣี็๋࠺࠮ࠩ࠯ࠫ࠶ࠦ࠯ࠡ࠵ࠪ࠭ࠏࠏࡩࡧࠢࡳࡈ࡮ࡧ࡬ࡰࡩ࠱࡭ࡸࡩࡡ࡯ࡥࡨࡰࡪࡪࠨࠪ࠼ࠍࠍࠎࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࡹࡷࡲࠠ࠾ࠢࡘࡖࡑࡥࡰ࡭ࡣࡼࡩࡷ࠱ࠧࠧࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡤࡹࡥࡳ࡫ࡨࡷࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠩࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡒ࠹ࡕ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏࡳࡦࡴ࡬ࡩࡸࡥࡧࡳࡱࡸࡴࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡪࡥ࡭ࠢ࡫ࡸࡲࡲࠊࠊࡨࡲࡶࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡴࠠࡴࡧࡵ࡭ࡪࡹ࡟ࡨࡴࡲࡹࡵࡹ࠺ࠋࠋࠌ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡀ࠶࠿࠺ࠡࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࡳ࠳ࡶࡡࡷࡩࡽࡺࠠ࠾ࠢࡰ࠷ࡺࡥࡴࡦࡺࡷ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡧࡳࡱࡸࡴࡂࠨࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠰ࠬ࡭ࡲࡰࡷࡳࡁࠧࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠯ࠊࠊࡦࡨࡰࠥࡹࡥࡳ࡫ࡨࡷࡤ࡭ࡲࡰࡷࡳࡷࠏࠏࡐࡓࡑࡊࡖࡊ࡙ࡓࡠࡗࡓࡈࡆ࡚ࡅࠩࡲࡇ࡭ࡦࡲ࡯ࡨ࠮࠵࠹࠱࠭ฬๅสࠣห้๋ไโษอࠤฬ๊หศ่๋๎ฮ࠭ࠬࠨษ็้้็ࠠาไ่࠾࠲࠭ࠬࠨ࠴ࠣ࠳ࠥ࠹ࠧࠪࠌࠌ࡭࡫ࠦࡰࡅ࡫ࡤࡰࡴ࡭࠮ࡪࡵࡦࡥࡳࡩࡥ࡭ࡧࡧࠬ࠮ࡀࠊࠊࠋࡳࡈ࡮ࡧ࡬ࡰࡩ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠐࠉࡶࡴ࡯ࠤࡂࠦࡕࡓࡎࡢࡴࡱࡧࡹࡦࡴ࠮ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡡࡹࡳࡩࡥࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠪࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡓ࠳ࡖ࠯ࡆࡖࡊࡇࡔࡆࡡࡖࡘࡗࡋࡁࡎࡕ࠰࠶ࡳࡪࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮ࠐࠉࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶࡾࡥ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣ࡫ࡷࡵࡵࡱࠢ࡬ࡲࠥࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴ࠼ࠍࠍࠎ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡂ࠱࠺࠼ࠣ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉ࡮࠵ࡸࡣࡹ࡫ࡸࡵࠢࡀࠤࡲ࠹ࡵࡠࡶࡨࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠲ࠧࡨࡴࡲࡹࡵࡃࠢࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧࠪࠌࠌࡨࡪࡲࠠࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠎࠎࡖࡒࡐࡉࡕࡉࡘ࡙࡟ࡖࡒࡇࡅ࡙ࡋࠨࡱࡆ࡬ࡥࡱࡵࡧ࠭࠵࠳࠰ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ࠲ࠧศๆ่่ๆࠦัใ็࠽࠱ࠬ࠲ࠧ࠴ࠢ࠲ࠤ࠸࠭ࠩࠋࠋ࡬ࡪࠥࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡩࡴࡥࡤࡲࡨ࡫࡬ࡦࡦࠫ࠭࠿ࠐࠉࠊࡲࡇ࡭ࡦࡲ࡯ࡨ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠏࠏࡵࡳ࡮ࠣࡁ࡛ࠥࡒࡍࡡࡳࡰࡦࡿࡥࡳ࠭ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠ࡮࡬ࡺࡪࡥࡳࡵࡴࡨࡥࡲࡹࠧࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡐ࠷࡚࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠴ࡴࡧࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡱ࡯ࡶࡦࡡࡤࡶࡨ࡮ࡩࡷࡧࡧࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶࡹࡣࡦࡸࡣࡩ࡫ࡹࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡯ࡣࡰࡩ࠱ࡧࡲࡤࡪ࡬ࡺࡪࡪࠠࡪࡰࠣࡰ࡮ࡼࡥࡠࡣࡵࡧ࡭࡯ࡶࡦࡦ࠽ࠎࠎࠏࡩࡧࠢࡤࡶࡨ࡮ࡩࡷࡧࡧࡁࡂ࠭࠱ࠨ࠼ࠣࡰ࡮ࡼࡥࡠࡣࡵࡧ࡭࡯ࡶࡦࡦࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡡ࡮ࡧࠬࠎࠎࡪࡥ࡭ࠢ࡯࡭ࡻ࡫࡟ࡢࡴࡦ࡬࡮ࡼࡥࡥࠌࠌࡰ࡮ࡼࡥࡠࡧࡳ࡫ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡨࡴ࡬ࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡰࡤࡱࡪ࠲ࡥࡱࡩࠣ࡭ࡳࠦ࡬ࡪࡸࡨࡣࡪࡶࡧ࠻ࠌࠌࠍ࡮࡬ࠠࡦࡲࡪࠥࡂ࠭࡮ࡶ࡮࡯ࠫ࠿ࠦ࡬ࡪࡸࡨࡣࡪࡶࡧࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡲࡦࡳࡥࠪࠌࠌࡨࡪࡲࠠ࡭࡫ࡹࡩࡤ࡫ࡰࡨࠌࠌࠦࠧࠨ䐷")
	l1l111llllll_l1_ = l1l111llllll_l1_.replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ䐸"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ䐹"))
	lines = re.findall(l11ll1_l1_ (u"ࠨࡐࡉ࠾࠭࠴ࠫࡀࠫࠦࡉ࡝࡚ࡉࠨ䐺"),l1l111llllll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠨࡋࡘࡕࡋࡑࡊ࠿࠭䐻"),re.DOTALL)
	if not lines:
		LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䐼"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡇࡱ࡯ࡨࡪࡸ࠺ࠨ䐽")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠬࠦࠠࡔࡧࡴࡹࡪࡴࡣࡦ࠼ࠪ䐾")+l111l1ll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࡑࡳࠥࡼࡩࡥࡧࡲࠤࡱ࡯࡮࡬ࡵࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡓ࠳ࡖࠢࡩ࡭ࡱ࡫ࠧ䐿"))
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䑀"),l11ll1_l1_ (u"ࠨࠩ䑁"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䑂"),l11ll1_l1_ (u"ࠪีฬฮืࠡโࡐ࠷࡚ࠦวๅาํࠤศ์สࠡลูๅฯํࠠๅษࠣฮําฯࠡใํ๋ࠥ็๊ะ์๋๋ฬะࠠ࠯࠰ࠣหาะๅศๆࠣีฬฮืࠡโࡐ࠷ฺ๋࡚ࠦำูࠣา๐อࠨ䑃")+l11ll1_l1_ (u"ࠫࡡࡴࠧ䑄")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䑅")+l11ll1_l1_ (u"࠭ัศสฺࠤึ่ๅࠡࠩ䑆")+str(int(l111l1ll_l1_)+1)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䑇"))
		l11l1ll111_l1_.close()
		return
	l11ll11l1l_l1_ = 1024*1024
	l1l11l1ll1ll_l1_ = 1+len(l1l111llllll_l1_)//l11ll11l1l_l1_//10
	del l1l111llllll_l1_
	l11ll1llllll_l1_ = len(lines)
	l11lll111lll_l1_ = SPLIT_BIGLIST(lines,l1l11l1ll1ll_l1_)
	del lines
	for l11ll1111l_l1_ in range(l1l11l1ll1ll_l1_):
		PROGRESS_UPDATE(l11l1ll111_l1_,35+int(5*l11ll1111l_l1_/l1l11l1ll1ll_l1_),l11ll1_l1_ (u"ࠨฬๅ฻๏฿ࠠศๆ่่ๆࠦวๅำษ๎ุ๐ࠧ䑈"),l11ll1_l1_ (u"ࠩส่ัุมࠡำๅ้࠿࠳ࠧ䑉"),str(l11ll1111l_l1_+1)+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䑊")+str(l1l11l1ll1ll_l1_))
		if l11l1ll111_l1_.iscanceled():
			l11l1ll111_l1_.close()
			return
		l11llllll1ll_l1_ = str(l11lll111lll_l1_[l11ll1111l_l1_])
		if kodi_version>18.99: l11llllll1ll_l1_ = l11llllll1ll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䑋"))
		open(l1l111111l11_l1_+l11ll1_l1_ (u"ࠬ࠴࠰࠱ࠩ䑌")+str(l11ll1111l_l1_),l11ll1_l1_ (u"࠭ࡷࡣࠩ䑍")).write(l11llllll1ll_l1_)
	del l11lll111lll_l1_,l11llllll1ll_l1_
	l11lll1111ll_l1_,l11llll1llll_l1_,l1ll1l11ll11_l1_ = [],[],0
	for l11ll1111l_l1_ in range(l1l11l1ll1ll_l1_):
		if l11l1ll111_l1_.iscanceled():
			l11l1ll111_l1_.close()
			return
		l11llllll1ll_l1_ = open(l1l111111l11_l1_+l11ll1_l1_ (u"ࠧ࠯࠲࠳ࠫ䑎")+str(l11ll1111l_l1_),l11ll1_l1_ (u"ࠨࡴࡥࠫ䑏")).read()
		time.sleep(1)
		try: os.remove(l1l111111l11_l1_+l11ll1_l1_ (u"ࠩ࠱࠴࠵࠭䑐")+str(l11ll1111l_l1_))
		except: pass
		if kodi_version>18.99: l11llllll1ll_l1_ = l11llllll1ll_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䑑"))
		lines = EVAL(l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䑒"),l11llllll1ll_l1_)
		del l11llllll1ll_l1_
		l1ll1l111l11_l1_,l1ll1l11ll11_l1_,l11lll11l111_l1_ = READ_ALL_LINES(lines,l1l111l1ll1l_l1_,l1l1111111l1_l1_,l11l1ll111_l1_,l11ll1llllll_l1_,l1ll1l11ll11_l1_,l11lllll1l1l_l1_)
		if l11l1ll111_l1_.iscanceled():
			l11l1ll111_l1_.close()
			return
		if not l1ll1l111l11_l1_:
			l11l1ll111_l1_.close()
			return
		l11llll1llll_l1_ += l1ll1l111l11_l1_
		l11lll1111ll_l1_ += l11lll11l111_l1_
	del lines,l1ll1l111l11_l1_
	l1l1111111ll_l1_,l11lll11l111_l1_ = CREATE_GROUPED_STREAMS(l11llll1llll_l1_,l11l1ll111_l1_,l111l1ll_l1_)
	if l11l1ll111_l1_.iscanceled():
		l11l1ll111_l1_.close()
		return
	l11lll1111ll_l1_ += l11lll11l111_l1_
	del l11llll1llll_l1_,l11lll11l111_l1_
	l1l111ll1lll_l1_,l1l111ll11l1_l1_,groups,l11lll1l1l11_l1_,l11llll11l1l_l1_ = {},{},{},0,0
	l11lll1ll111_l1_ = list(l1l1111111ll_l1_.keys())
	l1l111ll111l_l1_ = len(l11lll1ll111_l1_)*3
	import threading
	if 1:
		threads = {}
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			threads[l1l111111111_l1_] = threading.Thread(target=CREATE_MENUS,args=(l1l111111111_l1_,))
			threads[l1l111111111_l1_].start()
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			threads[l1l111111111_l1_].join()
		if l11l1ll111_l1_.iscanceled():
			l11l1ll111_l1_.close()
			return
	else:
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			CREATE_MENUS(l1l111111111_l1_)
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return
	DELETE_FILES(l1lll111llll_l1_,l111l1ll_l1_,False)
	l11lll1ll111_l1_ = list(l1l111ll1lll_l1_.keys())
	l11ll1llll1l_l1_ = 0
	if 1:
		threads = {}
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			threads[l1l111111111_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1lll111llll_l1_,l1l111111111_l1_))
			threads[l1l111111111_l1_].start()
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			threads[l1l111111111_l1_].join()
		if l11l1ll111_l1_.iscanceled():
			l11l1ll111_l1_.close()
			return
	else:
		for l1l111111111_l1_ in l11lll1ll111_l1_:
			SAVE_MENUS(l1lll111llll_l1_,l1l111111111_l1_)
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return
	l11ll1111l_l1_ = 0
	l1l111lll11l_l1_ = len(l11lll1111ll_l1_)
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䑓"))
	for stream in l11lll1111ll_l1_:
		if l11ll1111l_l1_%27==0:
			PROGRESS_UPDATE(l11l1ll111_l1_,95+int(5*l11ll1111l_l1_//l1l111lll11l_l1_),l11ll1_l1_ (u"࠭สฯิํ๊ࠥอไๆ้่่ฮ࠭䑔"),l11ll1_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ䑕"),str(l11ll1111l_l1_)+l11ll1_l1_ (u"ࠨࠢ࠲ࠤࠬ䑖")+str(l1l111lll11l_l1_))
			if l11l1ll111_l1_.iscanceled():
				l11l1ll111_l1_.close()
				return
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࡢࠫ䑗")+l111l1ll_l1_,str(stream),l11ll1_l1_ (u"ࠪࠫ䑘"),PERMANENT_CACHE)
		l11ll1111l_l1_ += 1
	WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࡤ࠭䑙")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䑚"),str(l1l111lll11l_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࡤ࠭䑛")+l111l1ll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䑜"),l11ll1_l1_ (u"ࠨ࠳ࠪ䑝"),PERMANENT_CACHE)
	#open(l1lllll11l11_l1_,l11ll1_l1_ (u"ࠩࡺࠫ䑞")).write(l11ll1_l1_ (u"ࠪࠫ䑟"))
	l11l1ll111_l1_.close()
	time.sleep(1)
	#l11llll1111l_l1_ = COUNTS(l1lll111llll_l1_,l111l1ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䑠"),l11ll1_l1_ (u"ࠬ࠭䑡"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑢"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䑣")+l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ䑤")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䑥")+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䑦")+l11llll1111l_l1_)
	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䑧"))
	DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_)
	return
def CREATE_MENUS(l1l111111111_l1_):
	global l11l1ll111_l1_,l1l1111111ll_l1_,l11ll1llll1l_l1_,l1l111ll1lll_l1_,l1l111ll11l1_l1_,groups,l11lll1l1l11_l1_,l11llll11l1l_l1_,l1l111ll111l_l1_
	l1l111ll1lll_l1_[l1l111111111_l1_] = {}
	l11lll1llll1_l1_,l1l1111l11l1_l1_ = {},[]
	l11lll111l1l_l1_ = len(l1l1111111ll_l1_[l1l111111111_l1_])
	l1l111ll1lll_l1_[l1l111111111_l1_][l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䑨")] = l11lll111l1l_l1_
	if l11lll111l1l_l1_>0:
		l1l1111lllll_l1_,l1l111llll1l_l1_,l11ll1lll11l_l1_,l1l111lll1l1_l1_,l1l11111l11l_l1_ = zip(*l1l1111111ll_l1_[l1l111111111_l1_])
		del l1l111llll1l_l1_,l11ll1lll11l_l1_,l1l111lll1l1_l1_
		l11lllll1111_l1_ = list(set(l1l1111lllll_l1_))
		for group in l11lllll1111_l1_:
			l11lll1llll1_l1_[group] = l11ll1_l1_ (u"࠭ࠧ䑩")
			l1l111ll1lll_l1_[l1l111111111_l1_][group] = []
		PROGRESS_UPDATE(l11l1ll111_l1_,60+int(15*l11llll11l1l_l1_//l1l111ll111l_l1_),l11ll1_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ䑪"),l11ll1_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭䑫"),str(l11llll11l1l_l1_)+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭䑬")+str(l1l111ll111l_l1_))
		if l11l1ll111_l1_.iscanceled(): return
		l11llll11l1l_l1_ += 1
		l11lll1l1lll_l1_ = len(l11lllll1111_l1_)
		del l11lllll1111_l1_
		l1l1111l11l1_l1_ = list(set(zip(l1l1111lllll_l1_,l1l11111l11l_l1_)))
		del l1l1111lllll_l1_,l1l11111l11l_l1_
		for group,l111_l1_ in l1l1111l11l1_l1_:
			if not l11lll1llll1_l1_[group] and l111_l1_: l11lll1llll1_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l1ll111_l1_,60+int(15*l11llll11l1l_l1_//l1l111ll111l_l1_),l11ll1_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่็๎วว็ࠪ䑭"),l11ll1_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ䑮"),str(l11llll11l1l_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䑯")+str(l1l111ll111l_l1_))
		if l11l1ll111_l1_.iscanceled(): return
		l11llll11l1l_l1_ += 1
		l11llll1l1l1_l1_ = list(l11lll1llll1_l1_.keys())
		l11lll1l1l1l_l1_ = list(l11lll1llll1_l1_.values())
		del l11lll1llll1_l1_
		l1l1111l11l1_l1_ = list(zip(l11llll1l1l1_l1_,l11lll1l1l1l_l1_))
		del l11llll1l1l1_l1_,l11lll1l1l1l_l1_
		l1l1111l11l1_l1_ = sorted(l1l1111l11l1_l1_)
	else: l11llll11l1l_l1_ += 2
	l1l111ll1lll_l1_[l1l111111111_l1_][l11ll1_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ䑰")] = l1l1111l11l1_l1_
	del l1l1111l11l1_l1_
	for group,context,title,url,l1lll1_l1_ in l1l1111111ll_l1_[l1l111111111_l1_]:
		l1l111ll1lll_l1_[l1l111111111_l1_][group].append((context,title,url,l1lll1_l1_))
	PROGRESS_UPDATE(l11l1ll111_l1_,60+int(15*l11llll11l1l_l1_//l1l111ll111l_l1_),l11ll1_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ䑱"),l11ll1_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭䑲"),str(l11llll11l1l_l1_)+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭䑳")+str(l1l111ll111l_l1_))
	if l11l1ll111_l1_.iscanceled(): return
	l11llll11l1l_l1_ += 1
	del l1l1111111ll_l1_[l1l111111111_l1_]
	groups[l1l111111111_l1_] = list(l1l111ll1lll_l1_[l1l111111111_l1_].keys())
	l1l111ll11l1_l1_[l1l111111111_l1_] = len(groups[l1l111111111_l1_])
	l11lll1l1l11_l1_ += l1l111ll11l1_l1_[l1l111111111_l1_]
	return
def SAVE_MENUS(l1lll111llll_l1_,l1l111111111_l1_):
	global l11l1ll111_l1_,l1l1111111ll_l1_,l11ll1llll1l_l1_,l1l111ll1lll_l1_,l1l111ll11l1_l1_,groups,l11lll1l1l11_l1_,l11llll11l1l_l1_,l1l111ll111l_l1_
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l1l111111111_l1_)
	for l1ll1l11ll11_l1_ in range(1+l1l111ll11l1_l1_[l1l111111111_l1_]//173):
		l11lll1l1111_l1_ = []
		l1l1111l1ll1_l1_ = groups[l1l111111111_l1_][0:273]
		for group in l1l1111l1ll1_l1_:
			l11lll1l1111_l1_.append(l1l111ll1lll_l1_[l1l111111111_l1_][group])
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l1l111111111_l1_,l1l1111l1ll1_l1_,l11lll1l1111_l1_,PERMANENT_CACHE,True)
		l11ll1llll1l_l1_ += len(l1l1111l1ll1_l1_)
		PROGRESS_UPDATE(l11l1ll111_l1_,75+int(20*l11ll1llll1l_l1_//l11lll1l1l11_l1_),l11ll1_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็ࠪ䑴"),l11ll1_l1_ (u"ࠫฬ๊โศศ่อࠥืโๆ࠼࠰ࠫ䑵"),str(l11ll1llll1l_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䑶")+str(l11lll1l1l11_l1_))
		if l11l1ll111_l1_.iscanceled(): return
		del groups[l1l111111111_l1_][0:273]
	del l1l111ll1lll_l1_[l1l111111111_l1_],groups[l1l111111111_l1_],l1l111ll11l1_l1_[l1l111111111_l1_]
	return
def COUNTS(l1lll111llll_l1_,l111l1ll_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1lll111llll_l1_,l1ll_l1_): return
	l1l1111l1lll_l1_ = l11ll1_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠥาๅ๋฻ࠣห้ื่ศสฺࠫ䑷")
	l11llll111l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䑸"))
	l1l111111ll1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䑹"))
	if l111l1ll_l1_:
		l1l1111l1lll_l1_ = l11ll1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠡำสฬ฼ࠦࠧ䑺")+text_numbers[int(l111l1ll_l1_)]
		l111l1ll_l1_ = l11ll1_l1_ (u"ࠪࡣࠬ䑻")+l111l1ll_l1_
	l1l111lll11l_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䑼"),l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䑽")+l111l1ll_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䑾"))
	l1l11111ll1l_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ䑿"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䒀")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䒁"))
	l11ll1lll1l1_l1_ = READ_FROM_SQL3(l1l111111ll1_l1_,l11ll1_l1_ (u"ࠪ࡭ࡳࡺࠧ䒂"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒃")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䒄"))
	l11lllllllll_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ䒅"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭䒆")+l111l1ll_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䒇"))
	l11lll1lll11_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࠭䒈"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䒉")+l111l1ll_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䒊"))
	l1l111l1111l_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"ࠬ࡯࡮ࡵࠩ䒋"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒌")+l111l1ll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䒍"))
	l1l111lll111_l1_ = READ_FROM_SQL3(l1l111111ll1_l1_,l11ll1_l1_ (u"ࠨ࡫ࡱࡸࠬ䒎"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䒏")+l111l1ll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䒐"))
	l11llll1l11l_l1_ = READ_FROM_SQL3(l11llll111l1_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䒑"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒒")+l111l1ll_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䒓"))
	groups = READ_FROM_SQL3(l1l111111ll1_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䒔"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䒕")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭䒖"))
	l11lllll1ll1_l1_ = []
	for group,l1lll1_l1_ in groups:
		l11lllll11l1_l1_ = group.split(l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䒗"))[1]
		l11lllll1ll1_l1_.append(l11lllll11l1_l1_)
	l1l111111lll_l1_ = len(l11lllll1ll1_l1_)
	total = int(l1l111l1111l_l1_)+int(l1l111lll111_l1_)+int(l11llll1l11l_l1_)+int(l11lll1lll11_l1_)+int(l11lllllllll_l1_)
	l11llll1111l_l1_ = l11ll1_l1_ (u"ࠫࠬ䒘")
	l11llll1111l_l1_ += l11ll1_l1_ (u"่ࠬๆ้ษอ࠾ࠥ࠭䒙")+str(l11lllllllll_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦรโๆส้࠿ࠦࠧ䒚")+str(l1l111l1111l_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ่ืู้ไศฬ࠽ࠤࠬ䒛")+str(l1l111111lll_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡฯ็ๆฬะ࠺ࠡࠩ䒜")+str(l1l111lll111_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲ็์่ศฬ้ࠣัํ่ๅห࠽ࠤࠬ䒝")+str(l11lll1lll11_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣๅ๏ี่่ษอࠤ๊า็้ๆฬ࠾ࠥ࠭䒞")+str(l11llll1l11l_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴๅอ็๋฽ࠥอไใ่๋หฯࡀࠠࠨ䒟")+str(l1l11111ll1l_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤ๋ࠥฬๆ๊฼ࠤฬ๊แ๋ัํ์์อส࠻ࠢࠪ䒠")+str(l11ll1lll1l1_l1_)
	l11llll1111l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱ้ัฺ๋่ࠢส่๊฼วโห࠽ࠤࠬ䒡")+str(total)
	l11llll1111l_l1_ += l11ll1_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠๆฮ่์฾ࠦวๅ็๊้้ฯ࠺ࠡࠩ䒢")+str(l1l111lll11l_l1_)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䒣"),l11ll1_l1_ (u"ࠩࠪ䒤"),l1l1111l1lll_l1_,l11llll1111l_l1_)
	l11llll1l111_l1_ = l11llll1111l_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䒥"),l11ll1_l1_ (u"ࠫࡡࡴࠧ䒦"))
	if not l111l1ll_l1_: l111l1ll_l1_ = l11ll1_l1_ (u"ࠬࡇ࡬࡭ࠩ䒧")
	else: l111l1ll_l1_ = l111l1ll_l1_[1]
	LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䒨"),l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠤࡈࡵࡵ࡯ࡶࡶࠤࡴ࡬ࠠࡎ࠵ࡘࠤࡻ࡯ࡤࡦࡱࡶࠤࠥࠦࡆࡰ࡮ࡧࡩࡷࡀࠠࠨ䒩")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࡘ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ䒪")+l111l1ll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ䒫")+l11llll1l111_l1_)
	return l11llll1111l_l1_
def DELETE_FILES(l1lll111llll_l1_,l111l1ll_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䒬"),l11ll1_l1_ (u"ࠫࠬ䒭"),l11ll1_l1_ (u"ࠬ࠭䒮"),l11ll1_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䒯"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯࠣห้๋ไโษอࠤฬ๊โะ์่อࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠠ࠯࠰ࠣ฽้๋วࠡษ้็ࠥะำหูํ฽ࠥ็๊ࠡลํࠤํ่สࠡษ็ำำ๎ไࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖ๋ࠢะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ䒰"))
		if l1ll111lll_l1_!=1: return
		file = l1l1l1ll1111_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䒱"),l11ll1_l1_ (u"ࠩࡢࠫ䒲")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䒳")+l111l1ll_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l11111llll_l1_)
	#except: pass
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠫࠬ䒴"))
	if l111l1ll_l1_:
		l11llllll1l1_l1_ = []
		for l11ll1l11_l1_ in l11llllll111_l1_:
			l11llllll1l1_l1_.append(l11ll1l11_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䒵")+l111l1ll_l1_)
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ䒶")+l111l1ll_l1_)
	else:
		l11llllll1l1_l1_ = l11llllll111_l1_
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭䒷"))
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠨࡉࡕࡓ࡚ࡖࡓࠨ䒸"))
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠩࡌࡘࡊࡓࡓࠨ䒹"))
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࠪ䒺"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䒻"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ䒼")+l1lll111llll_l1_)
	for l1l111111111_l1_ in l11llllll1l1_l1_:
		DELETE_FROM_SQL3(l1l1ll11l1_l1_,l1l111111111_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䒽"),l11ll1_l1_ (u"ࠧࠨ䒾"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䒿"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ䓀"))
	DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_)
	return
def CHECK_TABLES_EXIST(l1lll111llll_l1_=l11ll1_l1_ (u"ࠪࠫ䓁"),l1ll_l1_=True):
	if l1lll111llll_l1_:
		l1l1ll11l1_l1_ = GET_DBFILE_NAME(str(l1lll111llll_l1_),l11ll1_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ䓂"))
		dummy = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ䓃"),l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䓄"),l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䓅"))
		if dummy: return True
	else:
		for l1lll111llll_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1ll11l1_l1_ = GET_DBFILE_NAME(str(l1lll111llll_l1_),l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䓆"))
			dummy = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭䓇"),l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䓈"),l11ll1_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ䓉"))
			if dummy: return True
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䓊"),l11ll1_l1_ (u"࠭ࠧ䓋"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䓌"),l11ll1_l1_ (u"ࠨษ้ฮࠥฮอศฮฬࠤส๊้ࠡษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣวูหๆฯࠠาษห฻ࠥษ่ࠡษืฮึอใࠡโࡐ࠷࡚ࠨࠠ࠯࠰๋ࠣีํࠠศๆิ์ฬฮืࠡษะฮ๊อไࠡฬฯำ์อࠠโ์ࠣห้หๆหำ้ฮࠥษ่ࠡฬืฮึ๐็ศฺ่๊ࠢࠥัไหࠣๅ๏ี๊้้สฮࠥࡢ࡮࡝ࡰࠣว๊อࠠฦาสࠤ็๋สࠡใ฼่ฬࠦศฦุสๅฮࠦวๅำสฬ฼ࠦแฦา้ࠤศ์สࠡสะหัฯࠠๅฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖ๋ࠢิ้้ࠠษษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠤ࠱ࠫ䓍"))
	#SHOW_EMPTY(l111l1_l1_)
	return False
def SEARCH(l1ll1111l11_l1_,l1lll111llll_l1_=l11ll1_l1_ (u"ࠩࠪ䓎"),l1l111111111_l1_=l11ll1_l1_ (u"ࠪࠫ䓏"),l11llll11111_l1_=l11ll1_l1_ (u"ࠫࠬ䓐")):
	if not l11llll11111_l1_: l11llll11111_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ䓑")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll1111l11_l1_)
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11lllll111l_l1_ = [l11ll1_l1_ (u"࠭ࠧ䓒"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓓"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓔"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䓕"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䓖"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䓗")]
	if not l1l111111111_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࡠࠩ䓘") in options: l1l111111111_l1_ = l11lllll111l_l1_[1]
			elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ䓙") in options: l1l111111111_l1_ = l11lllll111l_l1_[2]
			elif l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ䓚") in options: l1l111111111_l1_ = l11lllll111l_l1_[3]
			else: l1l111111111_l1_ = l11lllll111l_l1_[0]
		else:
			l1l1111l1111_l1_ = [l11ll1_l1_ (u"ࠨษ็็้࠭䓛"),l11ll1_l1_ (u"ࠩๅ๊ํอสࠨ䓜"),l11ll1_l1_ (u"ࠪวๆ๊วๆࠩ䓝"),l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠬ䓞"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯࠧ䓟"),l11ll1_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ䓠")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䓡"), l1l1111l1111_l1_)
			if choice==-1: return
			l1l111111111_l1_ = l11lllll111l_l1_[choice]
	search = search+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䓢")
	if l1lll111llll_l1_: SEARCH_ONE_FOLDER(search,l1lll111llll_l1_,l1l111111111_l1_,l11llll11111_l1_)
	else:
		for l1lll111llll_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1lll111llll_l1_),l1l111111111_l1_,l11llll11111_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1ll1111l11_l1_,l1lll111llll_l1_,l1l111111111_l1_=l11ll1_l1_ (u"ࠩࠪ䓣"),l11llll11111_l1_=l11ll1_l1_ (u"ࠪࠫ䓤")):
	if not l11llll11111_l1_: l11llll11111_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭䓥")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll1111l11_l1_)
	if not l1lll111llll_l1_: return
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11lllll111l_l1_ = [l11ll1_l1_ (u"ࠬ࠭䓦"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䓧"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䓨"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓩"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䓪"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䓫")]
	if not l1l111111111_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋ࡟ࠨ䓬") in options: l1l111111111_l1_ = l11lllll111l_l1_[1]
			elif l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ䓭") in options: l1l111111111_l1_ = l11lllll111l_l1_[2]
			elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ䓮") in options: l1l111111111_l1_ = l11lllll111l_l1_[3]
			else: l1l111111111_l1_ = l11lllll111l_l1_[0]
		else:
			l1l1111l1111_l1_ = [l11ll1_l1_ (u"ࠧศๆๆ่ࠬ䓯"),l11ll1_l1_ (u"ࠨไ้์ฬะࠧ䓰"),l11ll1_l1_ (u"ࠩฦๅ้อๅࠨ䓱"),l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠫ䓲"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅอ้๋่ฮ࠭䓳"),l11ll1_l1_ (u"่ࠬๆ้ษอࠤ๊า็้ๆฬࠫ䓴")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䓵"), l1l1111l1111_l1_)
			if choice==-1: return
			l1l111111111_l1_ = l11lllll111l_l1_[choice]
	l11ll1llll11_l1_ = search.lower()
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ䓶"))
	results = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䓷"),l11ll1_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ䓸"),(l1l111111111_l1_,l11ll1llll11_l1_))
	if not results:
		l1l111l1ll11_l1_,l11lllll1l11_l1_ = [],[]
		if not l1l111111111_l1_: l11llll11ll1_l1_ = [1,2,3,4,5]
		else: l11llll11ll1_l1_ = [l11lllll111l_l1_.index(l1l111111111_l1_)]
		for l11ll1111l_l1_ in l11llll11ll1_l1_:
			#l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11lllll111l_l1_[l11ll1111l_l1_])
			if l11ll1111l_l1_!=3:
				l1ll1l111l11_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䓹"),l11lllll111l_l1_[l11ll1111l_l1_])
				del l1ll1l111l11_l1_[l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䓺")]
				del l1ll1l111l11_l1_[l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䓻")]
				del l1ll1l111l11_l1_[l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ䓼")]
				groups = list(l1ll1l111l11_l1_.keys())
				for group in groups:
					for context,title,url,l1lll1_l1_ in l1ll1l111l11_l1_[group]:
						if l11ll1llll11_l1_ in title.lower(): l11lllll1l11_l1_.append((title,url,l1lll1_l1_))
					del l1ll1l111l11_l1_[group]
				del l1ll1l111l11_l1_
			else: groups = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䓽"),l11lllll111l_l1_[l11ll1111l_l1_],l11ll1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ䓾"))
			for group in groups:
				try: group,l1lll1_l1_ = group
				except: l1lll1_l1_ = l11ll1_l1_ (u"ࠩࠪ䓿")
				if l11ll1llll11_l1_ in group.lower():
					if l11ll1111l_l1_!=3: l1l1111ll11l_l1_ = group
					else:
						l1l1111ll1l1_l1_,l11ll1lll1ll_l1_ = group.split(l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䔀"))
						if l11ll1llll11_l1_ in l1l1111ll1l1_l1_.lower(): l1l1111ll11l_l1_ = l1l1111ll1l1_l1_
						else: l1l1111ll11l_l1_ = l11ll1lll1ll_l1_
					l1l111l1ll11_l1_.append((group,l1l1111ll11l_l1_,l11lllll111l_l1_[l11ll1111l_l1_],l1lll1_l1_))
			del groups
		l1l111l1ll11_l1_ = set(l1l111l1ll11_l1_)
		l11lllll1l11_l1_ = set(l11lllll1l11_l1_)
		l1l111l1ll11_l1_ = sorted(l1l111l1ll11_l1_,reverse=False,key=lambda key: key[1])
		l11lllll1l11_l1_ = sorted(l11lllll1l11_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ䔁"),(l1l111111111_l1_,l11ll1llll11_l1_),(l1l111l1ll11_l1_,l11lllll1l11_l1_),PERMANENT_CACHE)
	else: l1l111l1ll11_l1_,l11lllll1l11_l1_ = results
	groups = len(l1l111l1ll11_l1_)
	l11lll_l1_ = len(l11lllll1l11_l1_)
	l1l1111_l1_ = int(l11llll11111_l1_)
	s1 = max(0,(l1l1111_l1_-1)*100)
	e1 = max(0,l1l1111_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l1111ll11l_l1_,l1l111l1l111_l1_,l1lll1_l1_ in l1l111l1ll11_l1_[s1:e1]:
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔂"),l111l1_l1_+l1l1111ll11l_l1_,l1l111l1l111_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"࠭࠱ࠨ䔃"),group,l11ll1_l1_ (u"ࠧࠨ䔄"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔅"):l1lll111llll_l1_})
	del l1l111l1ll11_l1_
	for title,url,l1lll1_l1_ in l11lllll1l11_l1_[s2:e2]:
		l1l111l11lll_l1_ = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ䔆"))[-1]
		if l11ll1_l1_ (u"ࠪ࠲ࠬ䔇") in l1l111l11lll_l1_ and l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䔈") not in l1l111l11lll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䔉"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䔊"),l11ll1_l1_ (u"ࠧࠨ䔋"),l11ll1_l1_ (u"ࠨࠩ䔌"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔍"):l1lll111llll_l1_})
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䔎"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䔏"),l11ll1_l1_ (u"ࠬ࠭䔐"),l11ll1_l1_ (u"࠭ࠧ䔑"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔒"):l1lll111llll_l1_})
	del l11lllll1l11_l1_
	PAGINATION(l1lll111llll_l1_,l11llll11111_l1_,l1l111111111_l1_,719,groups+l11lll_l1_,search+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䔓"))
	return
def PAGINATION(l1lll111llll_l1_,l11llll11111_l1_,l1l111111111_l1_,mode,total,text):
	if not l11llll11111_l1_: l11llll11111_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ䔔")
	if l11llll11111_l1_!=l11ll1_l1_ (u"ࠪ࠵ࠬ䔕"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔖"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ䔗")+str(1),l1l111111111_l1_,mode,l11ll1_l1_ (u"࠭ࠧ䔘"),str(1),text,l11ll1_l1_ (u"ࠧࠨ䔙"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔚"):l1lll111llll_l1_})
	if not total: total = 0
	l1l1l1lll_l1_ = int(total/100)+1
	for l1l1111_l1_ in range(2,l1l1l1lll_l1_):
		l1ll1lll1111_l1_ = (l1l1111_l1_%10==0 or int(l11llll11111_l1_)-4<l1l1111_l1_<int(l11llll11111_l1_)+4)
		l1ll1ll1lll1_l1_ = (l1ll1lll1111_l1_ and int(l11llll11111_l1_)-40<l1l1111_l1_<int(l11llll11111_l1_)+40)
		if str(l1l1111_l1_)!=l11llll11111_l1_ and (l1l1111_l1_%100==0 or l1ll1ll1lll1_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔛"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䔜")+str(l1l1111_l1_),l1l111111111_l1_,mode,l11ll1_l1_ (u"ࠫࠬ䔝"),str(l1l1111_l1_),text,l11ll1_l1_ (u"ࠬ࠭䔞"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔟"):l1lll111llll_l1_})
	if str(l1l1l1lll_l1_)!=l11llll11111_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔠"),l111l1_l1_+l11ll1_l1_ (u"ࠨลัีࠥ฻แฮหࠣࠫ䔡")+str(l1l1l1lll_l1_),l1l111111111_l1_,mode,l11ll1_l1_ (u"ࠩࠪ䔢"),str(l1l1l1lll_l1_),text,l11ll1_l1_ (u"ࠪࠫ䔣"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔤"):l1lll111llll_l1_})
	return
def GET_DBFILE_NAME(l1lll111llll_l1_,l1l111111111_l1_):
	#if l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ䔥") in l1l111111111_l1_ or l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࠬ䔦") in l1l111111111_l1_: l1l1ll11l1_l1_ = l1l1llll111l_l1_
	#else: l1l1ll11l1_l1_ = l1l1llll111l_l1_
	l1l1ll11l1_l1_ = l1l1llll111l_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ䔧"),l11ll1_l1_ (u"ࠨࡡࠪ䔨")+l1lll111llll_l1_)
	return l1l1ll11l1_l1_
def l1l1111lll1l_l1_(l1lll111llll_l1_):
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠩࠪ䔩"))
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䔪"),l11ll1_l1_ (u"ࠫࠬ䔫"),l11ll1_l1_ (u"ࠬ࠭䔬"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䔭"),l11ll1_l1_ (u"ฺࠧ็็๎ฮࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮࠦโะࠢอัฯอฬࠡ฻าอࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮั๊ศࠡษ็้้็วหࠢส่ว์ࠠภࠩ䔮"))
	if l1ll111lll_l1_!=1: return
	l1l111ll1l11_l1_(l1lll111llll_l1_,False)
	counts = [0]
	for seq in range(1,l11lllll11ll_l1_+1):
		l1l111l1lll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭䔯")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䔰")+str(seq))
		if l1l111l1lll1_l1_: CREATE_STREAMS(l1lll111llll_l1_,str(seq))
		counts.append(0)
	for l1l111111111_l1_ in l11llllll111_l1_:
		l11lll1lllll_l1_,l11llll111ll_l1_,l1l111lll1ll_l1_,l11llll1ll1l_l1_,l11lll1llll1_l1_ = 0,{},[],[],[]
		for seq in range(1,l11lllll11ll_l1_+1):
			l1l111l1l111_l1_ = l1l111111111_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䔱")+str(seq)
			l1l1111111ll_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䔲"),l1l111l1l111_l1_)
			try:
				l1l111ll1l1l_l1_ = l1l1111111ll_l1_[l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䔳")]
				count = l1l1111111ll_l1_[l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䔴")]
			except:
				l1l111ll1l1l_l1_ = []
				count = l11ll1_l1_ (u"ࠧ࠱ࠩ䔵")
			for tuple in l1l111ll1l1l_l1_:
				group,l111_l1_ = tuple
				l1ll1l111l11_l1_ = l1l1111111ll_l1_[group]
				if group not in l11llll1ll1l_l1_:
					l11llll1ll1l_l1_.append(group)
					l11lll1llll1_l1_.append(tuple)
					l11llll111ll_l1_[group] = []
				l11llll111ll_l1_[group] += l1ll1l111l11_l1_
			DELETE_FROM_SQL3(l1l1ll11l1_l1_,l1l111l1l111_l1_)
			WRITE_TO_SQL3(l1l1ll11l1_l1_,l1l111l1l111_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䔶"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11llll1ll1l_l1_:
			l1ll1l111l11_l1_ = list(set(l11llll111ll_l1_[group]))
			l11lll1lllll_l1_ += len(l1ll1l111l11_l1_)
			l1l111lll1ll_l1_.append(l1ll1l111l11_l1_)
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l1l111111111_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䔷"),str(l11lll1lllll_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l1l111111111_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䔸"),l11lll1llll1_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll11l1_l1_,l1l111111111_l1_,l11llll1ll1l_l1_,l1l111lll1ll_l1_,PERMANENT_CACHE,True)
	l1l11111l1ll_l1_ = False
	for seq in range(1,l11lllll11ll_l1_+1):
		if int(counts[seq])>0:
			l1l111l1lll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡸ࡬ࡠࠩ䔹")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䔺")+str(seq))
			WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ䔻")+str(seq),l11ll1_l1_ (u"ࠧࡠࡡࡏࡍࡓࡑ࡟ࡠࠩ䔼"),l1l111l1lll1_l1_,PERMANENT_CACHE)
			l1l11111l1ll_l1_ = True
	WRITE_TO_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䔽"),l11ll1_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ䔾"),l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䔿"),PERMANENT_CACHE)
	if l1l11111l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䕀"),l11ll1_l1_ (u"ࠬ࠭䕁"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕂"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䕃")+l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ䕄")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䕅"))
		l1l11111ll11_l1_(l1lll111llll_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䕆"))
	else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䕇"),l11ll1_l1_ (u"ࠬ࠭䕈"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕉"),l11ll1_l1_ (u"ࠧโึ็ࠤอูอษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦ࠮ࠡละฮ๊อไࠡำ๋หอ฽ࠠแࡏ࠶࡙ࠥอไห์ࠣว๋ะࠠฤุไฮ์อࠠๅๆหี๋อๅอࠢ฽๎ึࠦีฮ์ะอࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะ๋ࠥๆไࠢฦ๊ࠥะึ๋ใࠣห้ืวษูࠣฬ๋็ำไࠢ็่อืๆศ็ฯࠤออำหะาห๊ࠦโศศ่อࠥๆࡍ࠴ࡗࠣห้๋่อ๊าอࠥฮ็ัษࠣห้ฮั็ษ่ะࠬ䕊"))
	return
def l1l11111ll11_l1_(l1lll111llll_l1_):
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠨࠩ䕋"))
	if not CHECK_TABLES_EXIST(l1lll111llll_l1_,True): return
	for seq in range(1,l11lllll11ll_l1_+1):
		l1l111l1lll1_l1_ = READ_FROM_SQL3(l1l1ll11l1_l1_,l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭䕌"),l11ll1_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ䕍")+str(seq),l11ll1_l1_ (u"ࠫࡤࡥࡌࡊࡐࡎࡣࡤ࠭䕎"))
		if l1l111l1lll1_l1_: l11llll1111l_l1_ = COUNTS(l1lll111llll_l1_,str(seq))
	COUNTS(l1lll111llll_l1_,l11ll1_l1_ (u"ࠬ࠭䕏"))
	return
def l1l111ll1l11_l1_(l1lll111llll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䕐"),l11ll1_l1_ (u"ࠧࠨ䕑"),l11ll1_l1_ (u"ࠨࠩ䕒"),l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ䕓"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭䕔"))
		if l1ll111lll_l1_!=1: return
	#for seq in range(1,l11lllll11ll_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11ll1_l1_ (u"ࠫࠬ䕕"),False)
	l1l1ll11l1_l1_ = GET_DBFILE_NAME(l1lll111llll_l1_,l11ll1_l1_ (u"ࠬ࠭䕖"))
	try: os.remove(l1l1ll11l1_l1_)
	except: pass
	for seq in range(1,l11lllll11ll_l1_+1):
		filename = l1l1l1ll1111_l1_.replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ䕗"),l11ll1_l1_ (u"ࠧࡠࠩ䕘")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠨࡡࠪ䕙")+str(seq))
		l1lll11l111l_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1lll11l111l_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䕚"),l11ll1_l1_ (u"ࠪࠫ䕛"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕜"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䕝"))
	return
def DELETE_OLD_MENUS_CACHE(l1lll111llll_l1_):
	trans_provider = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭䕞"))
	trans_code = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ䕟"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ䕠")+trans_provider+l11ll1_l1_ (u"ࠩࡢࠫ䕡")+trans_code,l11ll1_l1_ (u"ࠪࠩࡤࡓࡕࠨ䕢")+l1lll111llll_l1_+l11ll1_l1_ (u"ࠫࡤࠫࠧ䕣"))
	return
COUNTRIES_CODES = {
		 l11ll1_l1_ (u"ࠬࡇࡆࠨ䕤"):l11ll1_l1_ (u"࠭ࡁࡧࡩ࡫ࡥࡳ࡯ࡳࡵࡣࡱࠫ䕥")
		,l11ll1_l1_ (u"ࠧࡂࡎࠪ䕦"):l11ll1_l1_ (u"ࠨࡃ࡯ࡦࡦࡴࡩࡢࠩ䕧")
		,l11ll1_l1_ (u"ࠩࡇ࡞ࠬ䕨"):l11ll1_l1_ (u"ࠪࡅࡱ࡭ࡥࡳ࡫ࡤࠫ䕩")
		,l11ll1_l1_ (u"ࠫࡆ࡙ࠧ䕪"):l11ll1_l1_ (u"ࠬࡇ࡭ࡦࡴ࡬ࡧࡦࡴࠠࡔࡣࡰࡳࡦ࠭䕫")
		,l11ll1_l1_ (u"࠭ࡁࡅࠩ䕬"):l11ll1_l1_ (u"ࠧࡂࡰࡧࡳࡷࡸࡡࠨ䕭")
		,l11ll1_l1_ (u"ࠨࡃࡒࠫ䕮"):l11ll1_l1_ (u"ࠩࡄࡲ࡬ࡵ࡬ࡢࠩ䕯")
		,l11ll1_l1_ (u"ࠪࡅࡎ࠭䕰"):l11ll1_l1_ (u"ࠫࡆࡴࡧࡶ࡫࡯ࡰࡦ࠭䕱")
		,l11ll1_l1_ (u"ࠬࡇࡑࠨ䕲"):l11ll1_l1_ (u"࠭ࡁ࡯ࡶࡤࡶࡨࡺࡩࡤࡣࠪ䕳")
		,l11ll1_l1_ (u"ࠧࡂࡉࠪ䕴"):l11ll1_l1_ (u"ࠨࡃࡱࡸ࡮࡭ࡵࡢࠢࡤࡲࡩࠦࡂࡢࡴࡥࡹࡩࡧࠧ䕵")
		,l11ll1_l1_ (u"ࠩࡄࡖࠬ䕶"):l11ll1_l1_ (u"ࠪࡅࡷ࡭ࡥ࡯ࡶ࡬ࡲࡦ࠭䕷")
		,l11ll1_l1_ (u"ࠫࡆࡓࠧ䕸"):l11ll1_l1_ (u"ࠬࡇࡲ࡮ࡧࡱ࡭ࡦ࠭䕹")
		,l11ll1_l1_ (u"࠭ࡁࡘࠩ䕺"):l11ll1_l1_ (u"ࠧࡂࡴࡸࡦࡦ࠭䕻")
		,l11ll1_l1_ (u"ࠨࡃࡘࠫ䕼"):l11ll1_l1_ (u"ࠩࡄࡹࡸࡺࡲࡢ࡮࡬ࡥࠬ䕽")
		,l11ll1_l1_ (u"ࠪࡅ࡙࠭䕾"):l11ll1_l1_ (u"ࠫࡆࡻࡳࡵࡴ࡬ࡥࠬ䕿")
		,l11ll1_l1_ (u"ࠬࡇ࡚ࠨ䖀"):l11ll1_l1_ (u"࠭ࡁࡻࡧࡵࡦࡦ࡯ࡪࡢࡰࠪ䖁")
		,l11ll1_l1_ (u"ࠧࡃࡕࠪ䖂"):l11ll1_l1_ (u"ࠨࡄࡤ࡬ࡦࡳࡡࡴࠩ䖃")
		,l11ll1_l1_ (u"ࠩࡅࡌࠬ䖄"):l11ll1_l1_ (u"ࠪࡆࡦ࡮ࡲࡢ࡫ࡱࠫ䖅")
		,l11ll1_l1_ (u"ࠫࡇࡊࠧ䖆"):l11ll1_l1_ (u"ࠬࡈࡡ࡯ࡩ࡯ࡥࡩ࡫ࡳࡩࠩ䖇")
		,l11ll1_l1_ (u"࠭ࡂࡃࠩ䖈"):l11ll1_l1_ (u"ࠧࡃࡣࡵࡦࡦࡪ࡯ࡴࠩ䖉")
		,l11ll1_l1_ (u"ࠨࡄ࡜ࠫ䖊"):l11ll1_l1_ (u"ࠩࡅࡩࡱࡧࡲࡶࡵࠪ䖋")
		,l11ll1_l1_ (u"ࠪࡆࡊ࠭䖌"):l11ll1_l1_ (u"ࠫࡇ࡫࡬ࡨ࡫ࡸࡱࠬ䖍")
		,l11ll1_l1_ (u"ࠬࡈ࡚ࠨ䖎"):l11ll1_l1_ (u"࠭ࡂࡦ࡮࡬ࡾࡪ࠭䖏")
		,l11ll1_l1_ (u"ࠧࡃࡌࠪ䖐"):l11ll1_l1_ (u"ࠨࡄࡨࡲ࡮ࡴࠧ䖑")
		,l11ll1_l1_ (u"ࠩࡅࡑࠬ䖒"):l11ll1_l1_ (u"ࠪࡆࡪࡸ࡭ࡶࡦࡤࠫ䖓")
		,l11ll1_l1_ (u"ࠫࡇ࡚ࠧ䖔"):l11ll1_l1_ (u"ࠬࡈࡨࡶࡶࡤࡲࠬ䖕")
		,l11ll1_l1_ (u"࠭ࡂࡐࠩ䖖"):l11ll1_l1_ (u"ࠧࡃࡱ࡯࡭ࡻ࡯ࡡࠨ䖗")
		,l11ll1_l1_ (u"ࠨࡄࡔࠫ䖘"):l11ll1_l1_ (u"ࠩࡅࡳࡳࡧࡩࡳࡧࠪ䖙")
		,l11ll1_l1_ (u"ࠪࡆࡆ࠭䖚"):l11ll1_l1_ (u"ࠫࡇࡵࡳ࡯࡫ࡤࠤࡦࡴࡤࠡࡊࡨࡶࡿ࡫ࡧࡰࡸ࡬ࡲࡦ࠭䖛")
		,l11ll1_l1_ (u"ࠬࡈࡗࠨ䖜"):l11ll1_l1_ (u"࠭ࡂࡰࡶࡶࡻࡦࡴࡡࠨ䖝")
		,l11ll1_l1_ (u"ࠧࡃࡘࠪ䖞"):l11ll1_l1_ (u"ࠨࡄࡲࡹࡻ࡫ࡴࠡࡋࡶࡰࡦࡴࡤࠨ䖟")
		,l11ll1_l1_ (u"ࠩࡅࡖࠬ䖠"):l11ll1_l1_ (u"ࠪࡆࡷࡧࡺࡪ࡮ࠪ䖡")
		,l11ll1_l1_ (u"ࠫࡎࡕࠧ䖢"):l11ll1_l1_ (u"ࠬࡈࡲࡪࡶ࡬ࡷ࡭ࠦࡉ࡯ࡦ࡬ࡥࡳࠦࡏࡤࡧࡤࡲ࡚ࠥࡥࡳࡴ࡬ࡸࡴࡸࡹࠨ䖣")
		,l11ll1_l1_ (u"࠭ࡖࡈࠩ䖤"):l11ll1_l1_ (u"ࠧࡃࡴ࡬ࡸ࡮ࡹࡨࠡࡘ࡬ࡶ࡬࡯࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ䖥")
		,l11ll1_l1_ (u"ࠨࡄࡑࠫ䖦"):l11ll1_l1_ (u"ࠩࡅࡶࡺࡴࡥࡪࠩ䖧")
		,l11ll1_l1_ (u"ࠪࡆࡌ࠭䖨"):l11ll1_l1_ (u"ࠫࡇࡻ࡬ࡨࡣࡵ࡭ࡦ࠭䖩")
		,l11ll1_l1_ (u"ࠬࡈࡆࠨ䖪"):l11ll1_l1_ (u"࠭ࡂࡶࡴ࡮࡭ࡳࡧࠠࡇࡣࡶࡳࠬ䖫")
		,l11ll1_l1_ (u"ࠧࡃࡋࠪ䖬"):l11ll1_l1_ (u"ࠨࡄࡸࡶࡺࡴࡤࡪࠩ䖭")
		,l11ll1_l1_ (u"ࠩࡎࡌࠬ䖮"):l11ll1_l1_ (u"ࠪࡇࡦࡳࡢࡰࡦ࡬ࡥࠬ䖯")
		,l11ll1_l1_ (u"ࠫࡈࡓࠧ䖰"):l11ll1_l1_ (u"ࠬࡉࡡ࡮ࡧࡵࡳࡴࡴࠧ䖱")
		,l11ll1_l1_ (u"࠭ࡃࡂࠩ䖲"):l11ll1_l1_ (u"ࠧࡄࡣࡱࡥࡩࡧࠧ䖳")
		,l11ll1_l1_ (u"ࠨࡅ࡙ࠫ䖴"):l11ll1_l1_ (u"ࠩࡆࡥࡵ࡫ࠠࡗࡧࡵࡨࡪ࠭䖵")
		,l11ll1_l1_ (u"ࠪࡏ࡞࠭䖶"):l11ll1_l1_ (u"ࠫࡈࡧࡹ࡮ࡣࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䖷")
		,l11ll1_l1_ (u"ࠬࡉࡆࠨ䖸"):l11ll1_l1_ (u"࠭ࡃࡦࡰࡷࡶࡦࡲࠠࡂࡨࡵ࡭ࡨࡧ࡮ࠡࡔࡨࡴࡺࡨ࡬ࡪࡥࠪ䖹")
		,l11ll1_l1_ (u"ࠧࡕࡆࠪ䖺"):l11ll1_l1_ (u"ࠨࡅ࡫ࡥࡩ࠭䖻")
		,l11ll1_l1_ (u"ࠩࡆࡐࠬ䖼"):l11ll1_l1_ (u"ࠪࡇ࡭࡯࡬ࡦࠩ䖽")
		,l11ll1_l1_ (u"ࠫࡈࡔࠧ䖾"):l11ll1_l1_ (u"ࠬࡉࡨࡪࡰࡤࠫ䖿")
		,l11ll1_l1_ (u"࠭ࡃ࡙ࠩ䗀"):l11ll1_l1_ (u"ࠧࡄࡪࡵ࡭ࡸࡺ࡭ࡢࡵࠣࡍࡸࡲࡡ࡯ࡦࠪ䗁")
		,l11ll1_l1_ (u"ࠨࡅࡆࠫ䗂"):l11ll1_l1_ (u"ࠩࡆࡳࡨࡵࡳࠡࠪࡎࡩࡪࡲࡩ࡯ࡩࠬࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䗃")
		,l11ll1_l1_ (u"ࠪࡇࡔ࠭䗄"):l11ll1_l1_ (u"ࠫࡈࡵ࡬ࡰ࡯ࡥ࡭ࡦ࠭䗅")
		,l11ll1_l1_ (u"ࠬࡑࡍࠨ䗆"):l11ll1_l1_ (u"࠭ࡃࡰ࡯ࡲࡶࡴࡹࠧ䗇")
		,l11ll1_l1_ (u"ࠧࡄࡍࠪ䗈"):l11ll1_l1_ (u"ࠨࡅࡲࡳࡰࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䗉")
		,l11ll1_l1_ (u"ࠩࡆࡖࠬ䗊"):l11ll1_l1_ (u"ࠪࡇࡴࡹࡴࡢࠢࡕ࡭ࡨࡧࠧ䗋")
		,l11ll1_l1_ (u"ࠫࡍࡘࠧ䗌"):l11ll1_l1_ (u"ࠬࡉࡲࡰࡣࡷ࡭ࡦ࠭䗍")
		,l11ll1_l1_ (u"࠭ࡃࡖࠩ䗎"):l11ll1_l1_ (u"ࠧࡄࡷࡥࡥࠬ䗏")
		,l11ll1_l1_ (u"ࠨࡅ࡚ࠫ䗐"):l11ll1_l1_ (u"ࠩࡆࡹࡷࡧࡣࡢࡱࠪ䗑")
		,l11ll1_l1_ (u"ࠪࡇ࡞࠭䗒"):l11ll1_l1_ (u"ࠫࡈࡿࡰࡳࡷࡶࠫ䗓")
		,l11ll1_l1_ (u"ࠬࡉ࡚ࠨ䗔"):l11ll1_l1_ (u"࠭ࡃࡻࡧࡦ࡬ࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䗕")
		,l11ll1_l1_ (u"ࠧࡄࡆࠪ䗖"):l11ll1_l1_ (u"ࠨࡆࡨࡱࡴࡩࡲࡢࡶ࡬ࡧࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡄࡱࡱ࡫ࡴ࠭䗗")
		,l11ll1_l1_ (u"ࠩࡇࡏࠬ䗘"):l11ll1_l1_ (u"ࠪࡈࡪࡴ࡭ࡢࡴ࡮ࠫ䗙")
		,l11ll1_l1_ (u"ࠫࡉࡐࠧ䗚"):l11ll1_l1_ (u"ࠬࡊࡪࡪࡤࡲࡹࡹ࡯ࠧ䗛")
		,l11ll1_l1_ (u"࠭ࡄࡎࠩ䗜"):l11ll1_l1_ (u"ࠧࡅࡱࡰ࡭ࡳ࡯ࡣࡢࠩ䗝")
		,l11ll1_l1_ (u"ࠨࡆࡒࠫ䗞"):l11ll1_l1_ (u"ࠩࡇࡳࡲ࡯࡮ࡪࡥࡤࡲࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䗟")
		,l11ll1_l1_ (u"ࠪࡘࡑ࠭䗠"):l11ll1_l1_ (u"ࠫࡊࡧࡳࡵࠢࡗ࡭ࡲࡵࡲࠨ䗡")
		,l11ll1_l1_ (u"ࠬࡋࡃࠨ䗢"):l11ll1_l1_ (u"࠭ࡅࡤࡷࡤࡨࡴࡸࠧ䗣")
		,l11ll1_l1_ (u"ࠧࡆࡉࠪ䗤"):l11ll1_l1_ (u"ࠨࡇࡪࡽࡵࡺࠧ䗥")
		,l11ll1_l1_ (u"ࠩࡖ࡚ࠬ䗦"):l11ll1_l1_ (u"ࠪࡉࡱࠦࡓࡢ࡮ࡹࡥࡩࡵࡲࠨ䗧")
		,l11ll1_l1_ (u"ࠫࡌࡗࠧ䗨"):l11ll1_l1_ (u"ࠬࡋࡱࡶࡣࡷࡳࡷ࡯ࡡ࡭ࠢࡊࡹ࡮ࡴࡥࡢࠩ䗩")
		,l11ll1_l1_ (u"࠭ࡅࡓࠩ䗪"):l11ll1_l1_ (u"ࠧࡆࡴ࡬ࡸࡷ࡫ࡡࠨ䗫")
		,l11ll1_l1_ (u"ࠨࡇࡈࠫ䗬"):l11ll1_l1_ (u"ࠩࡈࡷࡹࡵ࡮ࡪࡣࠪ䗭")
		,l11ll1_l1_ (u"ࠪࡉ࡙࠭䗮"):l11ll1_l1_ (u"ࠫࡊࡺࡨࡪࡱࡳ࡭ࡦ࠭䗯")
		,l11ll1_l1_ (u"ࠬࡌࡋࠨ䗰"):l11ll1_l1_ (u"࠭ࡆࡢ࡮࡮ࡰࡦࡴࡤࠡࡋࡶࡰࡦࡴࡤࡴࠩ䗱")
		,l11ll1_l1_ (u"ࠧࡇࡑࠪ䗲"):l11ll1_l1_ (u"ࠨࡈࡤࡶࡴ࡫ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ䗳")
		,l11ll1_l1_ (u"ࠩࡉࡎࠬ䗴"):l11ll1_l1_ (u"ࠪࡊ࡮ࡰࡩࠨ䗵")
		,l11ll1_l1_ (u"ࠫࡋࡏࠧ䗶"):l11ll1_l1_ (u"ࠬࡌࡩ࡯࡮ࡤࡲࡩ࠭䗷")
		,l11ll1_l1_ (u"࠭ࡆࡓࠩ䗸"):l11ll1_l1_ (u"ࠧࡇࡴࡤࡲࡨ࡫ࠧ䗹")
		,l11ll1_l1_ (u"ࠨࡉࡉࠫ䗺"):l11ll1_l1_ (u"ࠩࡉࡶࡪࡴࡣࡩࠢࡊࡹ࡮ࡧ࡮ࡢࠩ䗻")
		,l11ll1_l1_ (u"ࠪࡔࡋ࠭䗼"):l11ll1_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡕࡵ࡬ࡺࡰࡨࡷ࡮ࡧࠧ䗽")
		,l11ll1_l1_ (u"࡚ࠬࡆࠨ䗾"):l11ll1_l1_ (u"࠭ࡆࡳࡧࡱࡧ࡭ࠦࡓࡰࡷࡷ࡬ࡪࡸ࡮ࠡࡖࡨࡶࡷ࡯ࡴࡰࡴ࡬ࡩࡸ࠭䗿")
		,l11ll1_l1_ (u"ࠧࡈࡃࠪ䘀"):l11ll1_l1_ (u"ࠨࡉࡤࡦࡴࡴࠧ䘁")
		,l11ll1_l1_ (u"ࠩࡊࡑࠬ䘂"):l11ll1_l1_ (u"ࠪࡋࡦࡳࡢࡪࡣࠪ䘃")
		,l11ll1_l1_ (u"ࠫࡌࡋࠧ䘄"):l11ll1_l1_ (u"ࠬࡍࡥࡰࡴࡪ࡭ࡦ࠭䘅")
		,l11ll1_l1_ (u"࠭ࡄࡆࠩ䘆"):l11ll1_l1_ (u"ࠧࡈࡧࡵࡱࡦࡴࡹࠨ䘇")
		,l11ll1_l1_ (u"ࠨࡉࡋࠫ䘈"):l11ll1_l1_ (u"ࠩࡊ࡬ࡦࡴࡡࠨ䘉")
		,l11ll1_l1_ (u"ࠪࡋࡎ࠭䘊"):l11ll1_l1_ (u"ࠫࡌ࡯ࡢࡳࡣ࡯ࡸࡦࡸࠧ䘋")
		,l11ll1_l1_ (u"ࠬࡍࡒࠨ䘌"):l11ll1_l1_ (u"࠭ࡇࡳࡧࡨࡧࡪ࠭䘍")
		,l11ll1_l1_ (u"ࠧࡈࡎࠪ䘎"):l11ll1_l1_ (u"ࠨࡉࡵࡩࡪࡴ࡬ࡢࡰࡧࠫ䘏")
		,l11ll1_l1_ (u"ࠩࡊࡈࠬ䘐"):l11ll1_l1_ (u"ࠪࡋࡷ࡫࡮ࡢࡦࡤࠫ䘑")
		,l11ll1_l1_ (u"ࠫࡌࡖࠧ䘒"):l11ll1_l1_ (u"ࠬࡍࡵࡢࡦࡨࡰࡴࡻࡰࡦࠩ䘓")
		,l11ll1_l1_ (u"࠭ࡇࡖࠩ䘔"):l11ll1_l1_ (u"ࠧࡈࡷࡤࡱࠬ䘕")
		,l11ll1_l1_ (u"ࠨࡉࡗࠫ䘖"):l11ll1_l1_ (u"ࠩࡊࡹࡦࡺࡥ࡮ࡣ࡯ࡥࠬ䘗")
		,l11ll1_l1_ (u"ࠪࡋࡌ࠭䘘"):l11ll1_l1_ (u"ࠫࡌࡻࡥࡳࡰࡶࡩࡾ࠭䘙")
		,l11ll1_l1_ (u"ࠬࡍࡎࠨ䘚"):l11ll1_l1_ (u"࠭ࡇࡶ࡫ࡱࡩࡦ࠭䘛")
		,l11ll1_l1_ (u"ࠧࡈ࡙ࠪ䘜"):l11ll1_l1_ (u"ࠨࡉࡸ࡭ࡳ࡫ࡡ࠮ࡄ࡬ࡷࡸࡧࡵࠨ䘝")
		,l11ll1_l1_ (u"ࠩࡊ࡝ࠬ䘞"):l11ll1_l1_ (u"ࠪࡋࡺࡿࡡ࡯ࡣࠪ䘟")
		,l11ll1_l1_ (u"ࠫࡍ࡚ࠧ䘠"):l11ll1_l1_ (u"ࠬࡎࡡࡪࡶ࡬ࠫ䘡")
		,l11ll1_l1_ (u"࠭ࡈࡎࠩ䘢"):l11ll1_l1_ (u"ࠧࡉࡧࡤࡶࡩࠦࡉࡴ࡮ࡤࡲࡩࠦࡡ࡯ࡦࠣࡑࡨࡊ࡯࡯ࡣ࡯ࡨࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䘣")
		,l11ll1_l1_ (u"ࠨࡊࡑࠫ䘤"):l11ll1_l1_ (u"ࠩࡋࡳࡳࡪࡵࡳࡣࡶࠫ䘥")
		,l11ll1_l1_ (u"ࠪࡌࡐ࠭䘦"):l11ll1_l1_ (u"ࠫࡍࡵ࡮ࡨࠢࡎࡳࡳ࡭ࠧ䘧")
		,l11ll1_l1_ (u"ࠬࡎࡕࠨ䘨"):l11ll1_l1_ (u"࠭ࡈࡶࡰࡪࡥࡷࡿࠧ䘩")
		,l11ll1_l1_ (u"ࠧࡊࡕࠪ䘪"):l11ll1_l1_ (u"ࠨࡋࡦࡩࡱࡧ࡮ࡥࠩ䘫")
		,l11ll1_l1_ (u"ࠩࡌࡒࠬ䘬"):l11ll1_l1_ (u"ࠪࡍࡳࡪࡩࡢࠩ䘭")
		,l11ll1_l1_ (u"ࠫࡎࡊࠧ䘮"):l11ll1_l1_ (u"ࠬࡏ࡮ࡥࡱࡱࡩࡸ࡯ࡡࠨ䘯")
		,l11ll1_l1_ (u"࠭ࡉࡓࠩ䘰"):l11ll1_l1_ (u"ࠧࡊࡴࡤࡲࠬ䘱")
		,l11ll1_l1_ (u"ࠨࡋࡔࠫ䘲"):l11ll1_l1_ (u"ࠩࡌࡶࡦࡷࠧ䘳")
		,l11ll1_l1_ (u"ࠪࡍࡊ࠭䘴"):l11ll1_l1_ (u"ࠫࡎࡸࡥ࡭ࡣࡱࡨࠬ䘵")
		,l11ll1_l1_ (u"ࠬࡏࡍࠨ䘶"):l11ll1_l1_ (u"࠭ࡉࡴ࡮ࡨࠤࡴ࡬ࠠࡎࡣࡱࠫ䘷")
		,l11ll1_l1_ (u"ࠧࡊࡎࠪ䘸"):l11ll1_l1_ (u"ࠨࡋࡶࡶࡦ࡫࡬ࠨ䘹")
		,l11ll1_l1_ (u"ࠩࡌࡘࠬ䘺"):l11ll1_l1_ (u"ࠪࡍࡹࡧ࡬ࡺࠩ䘻")
		,l11ll1_l1_ (u"ࠫࡈࡏࠧ䘼"):l11ll1_l1_ (u"ࠬࡏࡶࡰࡴࡼࠤࡈࡵࡡࡴࡶࠪ䘽")
		,l11ll1_l1_ (u"࠭ࡊࡎࠩ䘾"):l11ll1_l1_ (u"ࠧࡋࡣࡰࡥ࡮ࡩࡡࠨ䘿")
		,l11ll1_l1_ (u"ࠨࡌࡓࠫ䙀"):l11ll1_l1_ (u"ࠩࡍࡥࡵࡧ࡮ࠨ䙁")
		,l11ll1_l1_ (u"ࠪࡎࡊ࠭䙂"):l11ll1_l1_ (u"ࠫࡏ࡫ࡲࡴࡧࡼࠫ䙃")
		,l11ll1_l1_ (u"ࠬࡐࡏࠨ䙄"):l11ll1_l1_ (u"࠭ࡊࡰࡴࡧࡥࡳ࠭䙅")
		,l11ll1_l1_ (u"ࠧࡌ࡜ࠪ䙆"):l11ll1_l1_ (u"ࠨࡍࡤࡾࡦࡱࡨࡴࡶࡤࡲࠬ䙇")
		,l11ll1_l1_ (u"ࠩࡎࡉࠬ䙈"):l11ll1_l1_ (u"ࠪࡏࡪࡴࡹࡢࠩ䙉")
		,l11ll1_l1_ (u"ࠫࡐࡏࠧ䙊"):l11ll1_l1_ (u"ࠬࡑࡩࡳ࡫ࡥࡥࡹ࡯ࠧ䙋")
		,l11ll1_l1_ (u"࠭ࡘࡌࠩ䙌"):l11ll1_l1_ (u"ࠧࡌࡱࡶࡳࡻࡵࠧ䙍")
		,l11ll1_l1_ (u"ࠨࡍ࡚ࠫ䙎"):l11ll1_l1_ (u"ࠩࡎࡹࡼࡧࡩࡵࠩ䙏")
		,l11ll1_l1_ (u"ࠪࡏࡌ࠭䙐"):l11ll1_l1_ (u"ࠫࡐࡿࡲࡨࡻࡽࡷࡹࡧ࡮ࠨ䙑")
		,l11ll1_l1_ (u"ࠬࡒࡁࠨ䙒"):l11ll1_l1_ (u"࠭ࡌࡢࡱࡶࠫ䙓")
		,l11ll1_l1_ (u"ࠧࡍࡘࠪ䙔"):l11ll1_l1_ (u"ࠨࡎࡤࡸࡻ࡯ࡡࠨ䙕")
		,l11ll1_l1_ (u"ࠩࡏࡆࠬ䙖"):l11ll1_l1_ (u"ࠪࡐࡪࡨࡡ࡯ࡱࡱࠫ䙗")
		,l11ll1_l1_ (u"ࠫࡑ࡙ࠧ䙘"):l11ll1_l1_ (u"ࠬࡒࡥࡴࡱࡷ࡬ࡴ࠭䙙")
		,l11ll1_l1_ (u"࠭ࡌࡓࠩ䙚"):l11ll1_l1_ (u"ࠧࡍ࡫ࡥࡩࡷ࡯ࡡࠨ䙛")
		,l11ll1_l1_ (u"ࠨࡎ࡜ࠫ䙜"):l11ll1_l1_ (u"ࠩࡏ࡭ࡧࡿࡡࠨ䙝")
		,l11ll1_l1_ (u"ࠪࡐࡎ࠭䙞"):l11ll1_l1_ (u"ࠫࡑ࡯ࡥࡤࡪࡷࡩࡳࡹࡴࡦ࡫ࡱࠫ䙟")
		,l11ll1_l1_ (u"ࠬࡒࡔࠨ䙠"):l11ll1_l1_ (u"࠭ࡌࡪࡶ࡫ࡹࡦࡴࡩࡢࠩ䙡")
		,l11ll1_l1_ (u"ࠧࡍࡗࠪ䙢"):l11ll1_l1_ (u"ࠨࡎࡸࡼࡪࡳࡢࡰࡷࡵ࡫ࠬ䙣")
		,l11ll1_l1_ (u"ࠩࡐࡓࠬ䙤"):l11ll1_l1_ (u"ࠪࡑࡦࡩࡡࡰࠩ䙥")
		,l11ll1_l1_ (u"ࠫࡒࡍࠧ䙦"):l11ll1_l1_ (u"ࠬࡓࡡࡥࡣࡪࡥࡸࡩࡡࡳࠩ䙧")
		,l11ll1_l1_ (u"࠭ࡍࡘࠩ䙨"):l11ll1_l1_ (u"ࠧࡎࡣ࡯ࡥࡼ࡯ࠧ䙩")
		,l11ll1_l1_ (u"ࠨࡏ࡜ࠫ䙪"):l11ll1_l1_ (u"ࠩࡐࡥࡱࡧࡹࡴ࡫ࡤࠫ䙫")
		,l11ll1_l1_ (u"ࠪࡑ࡛࠭䙬"):l11ll1_l1_ (u"ࠫࡒࡧ࡬ࡥ࡫ࡹࡩࡸ࠭䙭")
		,l11ll1_l1_ (u"ࠬࡓࡌࠨ䙮"):l11ll1_l1_ (u"࠭ࡍࡢ࡮࡬ࠫ䙯")
		,l11ll1_l1_ (u"ࠧࡎࡖࠪ䙰"):l11ll1_l1_ (u"ࠨࡏࡤࡰࡹࡧࠧ䙱")
		,l11ll1_l1_ (u"ࠩࡐࡌࠬ䙲"):l11ll1_l1_ (u"ࠪࡑࡦࡸࡳࡩࡣ࡯ࡰࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䙳")
		,l11ll1_l1_ (u"ࠫࡒࡗࠧ䙴"):l11ll1_l1_ (u"ࠬࡓࡡࡳࡶ࡬ࡲ࡮ࡷࡵࡦࠩ䙵")
		,l11ll1_l1_ (u"࠭ࡍࡓࠩ䙶"):l11ll1_l1_ (u"ࠧࡎࡣࡸࡶ࡮ࡺࡡ࡯࡫ࡤࠫ䙷")
		,l11ll1_l1_ (u"ࠨࡏࡘࠫ䙸"):l11ll1_l1_ (u"ࠩࡐࡥࡺࡸࡩࡵ࡫ࡸࡷࠬ䙹")
		,l11ll1_l1_ (u"ࠪ࡝࡙࠭䙺"):l11ll1_l1_ (u"ࠫࡒࡧࡹࡰࡶࡷࡩࠬ䙻")
		,l11ll1_l1_ (u"ࠬࡓࡘࠨ䙼"):l11ll1_l1_ (u"࠭ࡍࡦࡺ࡬ࡧࡴ࠭䙽")
		,l11ll1_l1_ (u"ࠧࡇࡏࠪ䙾"):l11ll1_l1_ (u"ࠨࡏ࡬ࡧࡷࡵ࡮ࡦࡵ࡬ࡥࠬ䙿")
		,l11ll1_l1_ (u"ࠩࡐࡈࠬ䚀"):l11ll1_l1_ (u"ࠪࡑࡴࡲࡤࡰࡸࡤࠫ䚁")
		,l11ll1_l1_ (u"ࠫࡒࡉࠧ䚂"):l11ll1_l1_ (u"ࠬࡓ࡯࡯ࡣࡦࡳࠬ䚃")
		,l11ll1_l1_ (u"࠭ࡍࡏࠩ䚄"):l11ll1_l1_ (u"ࠧࡎࡱࡱ࡫ࡴࡲࡩࡢࠩ䚅")
		,l11ll1_l1_ (u"ࠨࡏࡈࠫ䚆"):l11ll1_l1_ (u"ࠩࡐࡳࡳࡺࡥ࡯ࡧࡪࡶࡴ࠭䚇")
		,l11ll1_l1_ (u"ࠪࡑࡘ࠭䚈"):l11ll1_l1_ (u"ࠫࡒࡵ࡮ࡵࡵࡨࡶࡷࡧࡴࠨ䚉")
		,l11ll1_l1_ (u"ࠬࡓࡁࠨ䚊"):l11ll1_l1_ (u"࠭ࡍࡰࡴࡲࡧࡨࡵࠧ䚋")
		,l11ll1_l1_ (u"ࠧࡎ࡜ࠪ䚌"):l11ll1_l1_ (u"ࠨࡏࡲࡾࡦࡳࡢࡪࡳࡸࡩࠬ䚍")
		,l11ll1_l1_ (u"ࠩࡐࡑࠬ䚎"):l11ll1_l1_ (u"ࠪࡑࡾࡧ࡮࡮ࡣࡵࠤ࠭ࡈࡵࡳ࡯ࡤ࠭ࠬ䚏")
		,l11ll1_l1_ (u"ࠫࡓࡇࠧ䚐"):l11ll1_l1_ (u"ࠬࡔࡡ࡮࡫ࡥ࡭ࡦ࠭䚑")
		,l11ll1_l1_ (u"࠭ࡎࡓࠩ䚒"):l11ll1_l1_ (u"ࠧࡏࡣࡸࡶࡺ࠭䚓")
		,l11ll1_l1_ (u"ࠨࡐࡓࠫ䚔"):l11ll1_l1_ (u"ࠩࡑࡩࡵࡧ࡬ࠨ䚕")
		,l11ll1_l1_ (u"ࠪࡒࡑ࠭䚖"):l11ll1_l1_ (u"ࠫࡓ࡫ࡴࡩࡧࡵࡰࡦࡴࡤࡴࠩ䚗")
		,l11ll1_l1_ (u"ࠬࡔࡃࠨ䚘"):l11ll1_l1_ (u"࠭ࡎࡦࡹࠣࡇࡦࡲࡥࡥࡱࡱ࡭ࡦ࠭䚙")
		,l11ll1_l1_ (u"ࠧࡏ࡜ࠪ䚚"):l11ll1_l1_ (u"ࠨࡐࡨࡻࠥࡠࡥࡢ࡮ࡤࡲࡩ࠭䚛")
		,l11ll1_l1_ (u"ࠩࡑࡍࠬ䚜"):l11ll1_l1_ (u"ࠪࡒ࡮ࡩࡡࡳࡣࡪࡹࡦ࠭䚝")
		,l11ll1_l1_ (u"ࠫࡓࡋࠧ䚞"):l11ll1_l1_ (u"ࠬࡔࡩࡨࡧࡵࠫ䚟")
		,l11ll1_l1_ (u"࠭ࡎࡈࠩ䚠"):l11ll1_l1_ (u"ࠧࡏ࡫ࡪࡩࡷ࡯ࡡࠨ䚡")
		,l11ll1_l1_ (u"ࠨࡐࡘࠫ䚢"):l11ll1_l1_ (u"ࠩࡑ࡭ࡺ࡫ࠧ䚣")
		,l11ll1_l1_ (u"ࠪࡒࡋ࠭䚤"):l11ll1_l1_ (u"ࠫࡓࡵࡲࡧࡱ࡯࡯ࠥࡏࡳ࡭ࡣࡱࡨࠬ䚥")
		,l11ll1_l1_ (u"ࠬࡑࡐࠨ䚦"):l11ll1_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ䚧")
		,l11ll1_l1_ (u"ࠧࡎࡍࠪ䚨"):l11ll1_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ䚩")
		,l11ll1_l1_ (u"ࠩࡐࡔࠬ䚪"):l11ll1_l1_ (u"ࠪࡒࡴࡸࡴࡩࡧࡵࡲࠥࡓࡡࡳ࡫ࡤࡲࡦࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䚫")
		,l11ll1_l1_ (u"ࠫࡓࡕࠧ䚬"):l11ll1_l1_ (u"ࠬࡔ࡯ࡳࡹࡤࡽࠬ䚭")
		,l11ll1_l1_ (u"࠭ࡏࡎࠩ䚮"):l11ll1_l1_ (u"ࠧࡐ࡯ࡤࡲࠬ䚯")
		,l11ll1_l1_ (u"ࠨࡒࡎࠫ䚰"):l11ll1_l1_ (u"ࠩࡓࡥࡰ࡯ࡳࡵࡣࡱࠫ䚱")
		,l11ll1_l1_ (u"ࠪࡔ࡜࠭䚲"):l11ll1_l1_ (u"ࠫࡕࡧ࡬ࡢࡷࠪ䚳")
		,l11ll1_l1_ (u"ࠬࡖࡓࠨ䚴"):l11ll1_l1_ (u"࠭ࡐࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䚵")
		,l11ll1_l1_ (u"ࠧࡑࡃࠪ䚶"):l11ll1_l1_ (u"ࠨࡒࡤࡲࡦࡳࡡࠨ䚷")
		,l11ll1_l1_ (u"ࠩࡓࡋࠬ䚸"):l11ll1_l1_ (u"ࠪࡔࡦࡶࡵࡢࠢࡑࡩࡼࠦࡇࡶ࡫ࡱࡩࡦ࠭䚹")
		,l11ll1_l1_ (u"ࠫࡕ࡟ࠧ䚺"):l11ll1_l1_ (u"ࠬࡖࡡࡳࡣࡪࡹࡦࡿࠧ䚻")
		,l11ll1_l1_ (u"࠭ࡐࡆࠩ䚼"):l11ll1_l1_ (u"ࠧࡑࡧࡵࡹࠬ䚽")
		,l11ll1_l1_ (u"ࠨࡒࡋࠫ䚾"):l11ll1_l1_ (u"ࠩࡓ࡬࡮ࡲࡩࡱࡲ࡬ࡲࡪࡹࠧ䚿")
		,l11ll1_l1_ (u"ࠪࡔࡓ࠭䛀"):l11ll1_l1_ (u"ࠫࡕ࡯ࡴࡤࡣ࡬ࡶࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䛁")
		,l11ll1_l1_ (u"ࠬࡖࡌࠨ䛂"):l11ll1_l1_ (u"࠭ࡐࡰ࡮ࡤࡲࡩ࠭䛃")
		,l11ll1_l1_ (u"ࠧࡑࡖࠪ䛄"):l11ll1_l1_ (u"ࠨࡒࡲࡶࡹࡻࡧࡢ࡮ࠪ䛅")
		,l11ll1_l1_ (u"ࠩࡓࡖࠬ䛆"):l11ll1_l1_ (u"ࠪࡔࡺ࡫ࡲࡵࡱࠣࡖ࡮ࡩ࡯ࠨ䛇")
		,l11ll1_l1_ (u"ࠫࡖࡇࠧ䛈"):l11ll1_l1_ (u"ࠬࡗࡡࡵࡣࡵࠫ䛉")
		,l11ll1_l1_ (u"࠭ࡃࡈࠩ䛊"):l11ll1_l1_ (u"ࠧࡓࡧࡳࡹࡧࡲࡩࡤࠢࡲࡪࠥࡺࡨࡦࠢࡆࡳࡳ࡭࡯ࠨ䛋")
		,l11ll1_l1_ (u"ࠨࡔࡒࠫ䛌"):l11ll1_l1_ (u"ࠩࡕࡳࡲࡧ࡮ࡪࡣࠪ䛍")
		,l11ll1_l1_ (u"ࠪࡖ࡚࠭䛎"):l11ll1_l1_ (u"ࠫࡗࡻࡳࡴ࡫ࡤࠫ䛏")
		,l11ll1_l1_ (u"ࠬࡘࡗࠨ䛐"):l11ll1_l1_ (u"࠭ࡒࡸࡣࡱࡨࡦ࠭䛑")
		,l11ll1_l1_ (u"ࠧࡓࡇࠪ䛒"):l11ll1_l1_ (u"ࠨࡔ࣬ࡹࡳ࡯࡯࡯ࠩ䛓")
		,l11ll1_l1_ (u"ࠩࡅࡐࠬ䛔"):l11ll1_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡅࡥࡷࡺࡨ࣪࡮ࡨࡱࡾ࠭䛕")
		,l11ll1_l1_ (u"ࠫࡘࡎࠧ䛖"):l11ll1_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡍ࡫࡬ࡦࡰࡤࠫ䛗")
		,l11ll1_l1_ (u"࠭ࡋࡏࠩ䛘"):l11ll1_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡋࡪࡶࡷࡷࠥࡧ࡮ࡥࠢࡑࡩࡻ࡯ࡳࠨ䛙")
		,l11ll1_l1_ (u"ࠨࡎࡆࠫ䛚"):l11ll1_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡎࡸࡧ࡮ࡧࠧ䛛")
		,l11ll1_l1_ (u"ࠪࡑࡋ࠭䛜"):l11ll1_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡑࡦࡸࡴࡪࡰࠪ䛝")
		,l11ll1_l1_ (u"ࠬࡖࡍࠨ䛞"):l11ll1_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡖࡩࡦࡴࡵࡩࠥࡧ࡮ࡥࠢࡐ࡭ࡶࡻࡥ࡭ࡱࡱࠫ䛟")
		,l11ll1_l1_ (u"ࠧࡗࡅࠪ䛠"):l11ll1_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡗ࡫ࡱࡧࡪࡴࡴࠡࡣࡱࡨࠥࡺࡨࡦࠢࡊࡶࡪࡴࡡࡥ࡫ࡱࡩࡸ࠭䛡")
		,l11ll1_l1_ (u"࡚ࠩࡗࠬ䛢"):l11ll1_l1_ (u"ࠪࡗࡦࡳ࡯ࡢࠩ䛣")
		,l11ll1_l1_ (u"ࠫࡘࡓࠧ䛤"):l11ll1_l1_ (u"࡙ࠬࡡ࡯ࠢࡐࡥࡷ࡯࡮ࡰࠩ䛥")
		,l11ll1_l1_ (u"࠭ࡓࡂࠩ䛦"):l11ll1_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭䛧")
		,l11ll1_l1_ (u"ࠨࡕࡑࠫ䛨"):l11ll1_l1_ (u"ࠩࡖࡩࡳ࡫ࡧࡢ࡮ࠪ䛩")
		,l11ll1_l1_ (u"ࠪࡖࡘ࠭䛪"):l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡣ࡫ࡤࠫ䛫")
		,l11ll1_l1_ (u"࡙ࠬࡃࠨ䛬"):l11ll1_l1_ (u"࠭ࡓࡦࡻࡦ࡬ࡪࡲ࡬ࡦࡵࠪ䛭")
		,l11ll1_l1_ (u"ࠧࡔࡎࠪ䛮"):l11ll1_l1_ (u"ࠨࡕ࡬ࡩࡷࡸࡡࠡࡎࡨࡳࡳ࡫ࠧ䛯")
		,l11ll1_l1_ (u"ࠩࡖࡋࠬ䛰"):l11ll1_l1_ (u"ࠪࡗ࡮ࡴࡧࡢࡲࡲࡶࡪ࠭䛱")
		,l11ll1_l1_ (u"ࠫࡘ࡞ࠧ䛲"):l11ll1_l1_ (u"࡙ࠬࡩ࡯ࡶࠣࡑࡦࡧࡲࡵࡧࡱࠫ䛳")
		,l11ll1_l1_ (u"࠭ࡓࡌࠩ䛴"):l11ll1_l1_ (u"ࠧࡔ࡮ࡲࡺࡦࡱࡩࡢࠩ䛵")
		,l11ll1_l1_ (u"ࠨࡕࡌࠫ䛶"):l11ll1_l1_ (u"ࠩࡖࡰࡴࡼࡥ࡯࡫ࡤࠫ䛷")
		,l11ll1_l1_ (u"ࠪࡗࡇ࠭䛸"):l11ll1_l1_ (u"ࠫࡘࡵ࡬ࡰ࡯ࡲࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䛹")
		,l11ll1_l1_ (u"࡙ࠬࡏࠨ䛺"):l11ll1_l1_ (u"࠭ࡓࡰ࡯ࡤࡰ࡮ࡧࠧ䛻")
		,l11ll1_l1_ (u"࡛ࠧࡃࠪ䛼"):l11ll1_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡂࡨࡵ࡭ࡨࡧࠧ䛽")
		,l11ll1_l1_ (u"ࠩࡊࡗࠬ䛾"):l11ll1_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡊࡩࡴࡸࡧࡪࡣࠣࡥࡳࡪࠠࡵࡪࡨࠤࡘࡵࡵࡵࡪࠣࡗࡦࡴࡤࡸ࡫ࡦ࡬ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䛿")
		,l11ll1_l1_ (u"ࠫࡐࡘࠧ䜀"):l11ll1_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡐࡵࡲࡦࡣࠪ䜁")
		,l11ll1_l1_ (u"࠭ࡓࡔࠩ䜂"):l11ll1_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡓࡶࡦࡤࡲࠬ䜃")
		,l11ll1_l1_ (u"ࠨࡇࡖࠫ䜄"):l11ll1_l1_ (u"ࠩࡖࡴࡦ࡯࡮ࠨ䜅")
		,l11ll1_l1_ (u"ࠪࡐࡐ࠭䜆"):l11ll1_l1_ (u"ࠫࡘࡸࡩࠡࡎࡤࡲࡰࡧࠧ䜇")
		,l11ll1_l1_ (u"࡙ࠬࡄࠨ䜈"):l11ll1_l1_ (u"࠭ࡓࡶࡦࡤࡲࠬ䜉")
		,l11ll1_l1_ (u"ࠧࡔࡔࠪ䜊"):l11ll1_l1_ (u"ࠨࡕࡸࡶ࡮ࡴࡡ࡮ࡧࠪ䜋")
		,l11ll1_l1_ (u"ࠩࡖࡎࠬ䜌"):l11ll1_l1_ (u"ࠪࡗࡻࡧ࡬ࡣࡣࡵࡨࠥࡧ࡮ࡥࠢࡍࡥࡳࠦࡍࡢࡻࡨࡲࠬ䜍")
		,l11ll1_l1_ (u"ࠫࡘࡠࠧ䜎"):l11ll1_l1_ (u"࡙ࠬࡷࡢࡼ࡬ࡰࡦࡴࡤࠨ䜏")
		,l11ll1_l1_ (u"࠭ࡓࡆࠩ䜐"):l11ll1_l1_ (u"ࠧࡔࡹࡨࡨࡪࡴࠧ䜑")
		,l11ll1_l1_ (u"ࠨࡅࡋࠫ䜒"):l11ll1_l1_ (u"ࠩࡖࡻ࡮ࡺࡺࡦࡴ࡯ࡥࡳࡪࠧ䜓")
		,l11ll1_l1_ (u"ࠪࡗ࡞࠭䜔"):l11ll1_l1_ (u"ࠫࡘࡿࡲࡪࡣࠪ䜕")
		,l11ll1_l1_ (u"࡙ࠬࡔࠨ䜖"):l11ll1_l1_ (u"࠭ࡓࣤࡱࠣࡘࡴࡳࣩࠡࡣࡱࡨࠥࡖࡲ࣮ࡰࡦ࡭ࡵ࡫ࠧ䜗")
		,l11ll1_l1_ (u"ࠧࡕ࡙ࠪ䜘"):l11ll1_l1_ (u"ࠨࡖࡤ࡭ࡼࡧ࡮ࠨ䜙")
		,l11ll1_l1_ (u"ࠩࡗࡎࠬ䜚"):l11ll1_l1_ (u"ࠪࡘࡦࡰࡩ࡬࡫ࡶࡸࡦࡴࠧ䜛")
		,l11ll1_l1_ (u"࡙ࠫࡠࠧ䜜"):l11ll1_l1_ (u"࡚ࠬࡡ࡯ࡼࡤࡲ࡮ࡧࠧ䜝")
		,l11ll1_l1_ (u"࠭ࡔࡉࠩ䜞"):l11ll1_l1_ (u"ࠧࡕࡪࡤ࡭ࡱࡧ࡮ࡥࠩ䜟")
		,l11ll1_l1_ (u"ࠨࡖࡊࠫ䜠"):l11ll1_l1_ (u"ࠩࡗࡳ࡬ࡵࠧ䜡")
		,l11ll1_l1_ (u"ࠪࡘࡐ࠭䜢"):l11ll1_l1_ (u"࡙ࠫࡵ࡫ࡦ࡮ࡤࡹࠬ䜣")
		,l11ll1_l1_ (u"࡚ࠬࡏࠨ䜤"):l11ll1_l1_ (u"࠭ࡔࡰࡰࡪࡥࠬ䜥")
		,l11ll1_l1_ (u"ࠧࡕࡖࠪ䜦"):l11ll1_l1_ (u"ࠨࡖࡵ࡭ࡳ࡯ࡤࡢࡦࠣࡥࡳࡪࠠࡕࡱࡥࡥ࡬ࡵࠧ䜧")
		,l11ll1_l1_ (u"ࠩࡗࡒࠬ䜨"):l11ll1_l1_ (u"ࠪࡘࡺࡴࡩࡴ࡫ࡤࠫ䜩")
		,l11ll1_l1_ (u"࡙ࠫࡘࠧ䜪"):l11ll1_l1_ (u"࡚ࠬࡵࡳ࡭ࡨࡽࠬ䜫")
		,l11ll1_l1_ (u"࠭ࡔࡎࠩ䜬"):l11ll1_l1_ (u"ࠧࡕࡷࡵ࡯ࡲ࡫࡮ࡪࡵࡷࡥࡳ࠭䜭")
		,l11ll1_l1_ (u"ࠨࡖࡆࠫ䜮"):l11ll1_l1_ (u"ࠩࡗࡹࡷࡱࡳࠡࡣࡱࡨࠥࡉࡡࡪࡥࡲࡷࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䜯")
		,l11ll1_l1_ (u"ࠪࡘ࡛࠭䜰"):l11ll1_l1_ (u"࡙ࠫࡻࡶࡢ࡮ࡸࠫ䜱")
		,l11ll1_l1_ (u"࡛ࠬࡍࠨ䜲"):l11ll1_l1_ (u"࠭ࡕ࠯ࡕ࠱ࠤࡒ࡯࡮ࡰࡴࠣࡓࡺࡺ࡬ࡺ࡫ࡱ࡫ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䜳")
		,l11ll1_l1_ (u"ࠧࡗࡋࠪ䜴"):l11ll1_l1_ (u"ࠨࡗ࠱ࡗ࠳ࠦࡖࡪࡴࡪ࡭ࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䜵")
		,l11ll1_l1_ (u"ࠩࡘࡋࠬ䜶"):l11ll1_l1_ (u"࡙ࠪ࡬ࡧ࡮ࡥࡣࠪ䜷")
		,l11ll1_l1_ (u"࡚ࠫࡇࠧ䜸"):l11ll1_l1_ (u"࡛ࠬ࡫ࡳࡣ࡬ࡲࡪ࠭䜹")
		,l11ll1_l1_ (u"࠭ࡁࡆࠩ䜺"):l11ll1_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧ䜻")
		,l11ll1_l1_ (u"ࠨࡗࡎࠫ䜼"):l11ll1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ䜽")
		,l11ll1_l1_ (u"࡙ࠪࡘ࠭䜾"):l11ll1_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ䜿")
		,l11ll1_l1_ (u"࡛࡙ࠬࠨ䝀"):l11ll1_l1_ (u"࠭ࡕࡳࡷࡪࡹࡦࡿࠧ䝁")
		,l11ll1_l1_ (u"ࠧࡖ࡜ࠪ䝂"):l11ll1_l1_ (u"ࠨࡗࡽࡦࡪࡱࡩࡴࡶࡤࡲࠬ䝃")
		,l11ll1_l1_ (u"࡙࡙ࠩࠬ䝄"):l11ll1_l1_ (u"࡚ࠪࡦࡴࡵࡢࡶࡸࠫ䝅")
		,l11ll1_l1_ (u"࡛ࠫࡇࠧ䝆"):l11ll1_l1_ (u"ࠬ࡜ࡡࡵ࡫ࡦࡥࡳࠦࡃࡪࡶࡼࠫ䝇")
		,l11ll1_l1_ (u"࠭ࡖࡆࠩ䝈"):l11ll1_l1_ (u"ࠧࡗࡧࡱࡩࡿࡻࡥ࡭ࡣࠪ䝉")
		,l11ll1_l1_ (u"ࠨࡘࡑࠫ䝊"):l11ll1_l1_ (u"࡙ࠩ࡭ࡪࡺ࡮ࡢ࡯ࠪ䝋")
		,l11ll1_l1_ (u"࡛ࠪࡋ࠭䝌"):l11ll1_l1_ (u"ࠫ࡜ࡧ࡬࡭࡫ࡶࠤࡦࡴࡤࠡࡈࡸࡸࡺࡴࡡࠨ䝍")
		,l11ll1_l1_ (u"ࠬࡋࡈࠨ䝎"):l11ll1_l1_ (u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ䝏")
		,l11ll1_l1_ (u"࡚ࠧࡇࠪ䝐"):l11ll1_l1_ (u"ࠨ࡛ࡨࡱࡪࡴࠧ䝑")
		,l11ll1_l1_ (u"ࠩ࡝ࡑࠬ䝒"):l11ll1_l1_ (u"ࠪ࡞ࡦࡳࡢࡪࡣࠪ䝓")
		,l11ll1_l1_ (u"ࠫ࡟࡝ࠧ䝔"):l11ll1_l1_ (u"ࠬࡠࡩ࡮ࡤࡤࡦࡼ࡫ࠧ䝕")
		,l11ll1_l1_ (u"࠭ࡁ࡙ࠩ䝖"):l11ll1_l1_ (u"ࠧࣆ࡮ࡤࡲࡩ࠭䝗")
		}
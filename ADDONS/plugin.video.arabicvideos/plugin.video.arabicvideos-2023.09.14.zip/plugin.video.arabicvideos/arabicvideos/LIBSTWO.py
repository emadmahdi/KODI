# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11lll1ll11_l1_ import *
import traceback,bidi.algorithm
#import l1l1lll11l11_l1_
script_name = l11ll1_l1_ (u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ㏻")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l11l1lll1l1_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ㏼"))
	l1l1l1111l_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ㏽"))
	l111ll1l111_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ㏾"))
	l11111l11ll_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㏿"),l11ll1_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㐀"),l11ll1_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ㐁"))
	l11l1111l11_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㐂"),l11ll1_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㐃"),l11ll1_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ㐄"))
	l1ll11l111_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㐅"),l11ll1_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㐆"),l11ll1_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ㐇"))
	half_triangular_colon = l11ll1_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ㐈")
	from urllib.parse import quote as _1ll1llllll1_l1_
	#from io import BytesIO as _1ll1l111ll1_l1_
else:
	l11l1lll1l1_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ㐉"))
	l1l1l1111l_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ㐊"))
	l111ll1l111_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭㐋"))
	l11111l11ll_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㐌"),l11ll1_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㐍"),l11ll1_l1_ (u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪ㐎"))
	l11l1111l11_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㐏"),l11ll1_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㐐"),l11ll1_l1_ (u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨ㐑"))
	l1ll11l111_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㐒"),l11ll1_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㐓"),l11ll1_l1_ (u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫ㐔"))
	half_triangular_colon = l11ll1_l1_ (u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭㐕").encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㐖"))
	from urllib import quote as _1ll1llllll1_l1_
	#from StringIO import StringIO as _1ll1l111ll1_l1_
#l1lllll1l111_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11lll1l11l_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡉࡳࡱࡪࡥࡳࡒࡤࡸ࡭࠭㐗"))
l1lll111111l_l1_ = os.path.join(l111ll1l111_l1_,l11ll1_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ㐘"))
l1lll1l1ll1l_l1_ = os.path.join(l111ll1l111_l1_,l11ll1_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ㐙"))
l11ll1ll1ll_l1_ = [l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬ㐚"),l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬ㐛"),l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨ㐜"),l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸ࡭ࡻࡢࠨ㐝"),l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨ㐞"),l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬ㐟")]
l11111111l1_l1_ = l11ll1ll1ll_l1_+[l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ㐠"),l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㐡"),l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ㐢"),l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡴ࡭࡫࡮ࡰ࡯ࡨࡲࡦࡲࡅࡎࡃࡇࠫ㐣")]		# ,l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲࡮ࡴࡳࡵࡣ࡯ࡰࡊࡓࡁࡅࠩ㐤")
iptv1_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㐥"))
iptv2_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ㐦"))
l1l1llll111l_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㐧"))
#l1lll1ll1111_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠪࡼࡹࡸࡥࡢ࡯ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㐨"))
#l1lll1l11l1l_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠫࡱࡧࡳࡵ࡯ࡨࡲࡺ࠴ࡤࡢࡶࠪ㐩"))
favoritesfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭㐪"))
#dummyiptvfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"࠭ࡤࡶ࡯ࡰࡽ࡮ࡶࡴࡷ࠰ࡧࡥࡹ࠭㐫"))
fulliptvfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㐬"))
l1l1l1ll1111_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㐭"))
l1l11l1l1l11_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡩࡧࡴࠨ㐮"))
l1l11ll1ll11_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭㐯"))
l1l111llll1_l1_ = xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠫࡵࡧࡴࡩࠩ㐰"))
defaulticon = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ㐱"))
defaultthumb = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩ㐲"))
defaultfanart = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫ㐳"))
defaultbanner = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬ㐴"))
defaultlandscape = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩ㐵"))
defaultposter = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧ㐶"))
defaultclearlogo = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫ㐷"))
defaultclearart = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫ㐸"))
l1ll111l1ll1_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭㐹"))
l1ll1l1111_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㐺"))
l1ll1111l1l1_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㐻"),l11ll1_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㐼"),addon_id,l11ll1_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㐽"))
l1llll1lll11_l1_ = os.path.join(l11l1lll1l1_l1_,l11ll1_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ㐾"),l11ll1_l1_ (u"ࠬࡌ࡯࡯ࡶࡶࠫ㐿"),l11ll1_l1_ (u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩ㑀"))
l1llllll1lll_l1_ = [l11ll1_l1_ (u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩ㑁"),l11ll1_l1_ (u"ࠨࡔࡈࡔࡔࡘࡔࡔࠩ㑂"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡏࡌࡔࠩ㑃"),l11ll1_l1_ (u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ㑄"),l11ll1_l1_ (u"ࠫࡎ࡙ࡌࡂࡏࡌࡇࡘ࠭㑅"),l11ll1_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㑆"),l11ll1_l1_ (u"࠭ࡋࡏࡑ࡚ࡒࡊࡘࡒࡐࡔࡖࠫ㑇")]
l111l1lll11_l1_ = [l11ll1_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ㑈"),l11ll1_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪ㑉"),l11ll1_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫ㑊")]
FOLDERS_COUNT = 5
text_numbers = [l11ll1_l1_ (u"ูࠪๆืࠧ㑋"),l11ll1_l1_ (u"ࠫศ๎ไࠨ㑌"),l11ll1_l1_ (u"ࠬัว็์ࠪ㑍"),l11ll1_l1_ (u"࠭หศๆฮࠫ㑎"),l11ll1_l1_ (u"ࠧาษห฽ࠬ㑏"),l11ll1_l1_ (u"ࠨะสุ้࠭㑐"),l11ll1_l1_ (u"ࠩึหิูࠧ㑑"),l11ll1_l1_ (u"ࠪืฬฮูࠨ㑒"),l11ll1_l1_ (u"ࠫะอๅ็ࠩ㑓"),l11ll1_l1_ (u"ࠬะวิ฻ࠪ㑔"),l11ll1_l1_ (u"ู࠭ศึิࠫ㑕")]
l1lll1l1l1ll_l1_ = l11ll1_l1_ (u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ㑖")
NO_CACHE = 0
l1ll11lll111_l1_ = 30*l1l11ll11l1_l1_
l1ll1lll1_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
VERYLONG_CACHE = 30*l11lll1l1ll_l1_
l11llll11l1_l1_ = 1*HOUR
l1l1l1ll1lll_l1_ = [l11ll1_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㑗"),l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ㑘")]
l1lll1l1l111_l1_ = [l11ll1_l1_ (u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㑙")]
l1llll11l1ll_l1_ = [l11ll1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭㑚"),l11ll1_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ㑛"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ㑜"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ㑝"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㑞"),l11ll1_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㑟"),l11ll1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ㑠")]
l1llll11l1ll_l1_ += [l11ll1_l1_ (u"ࠫࡍࡋࡌࡂࡎࠪ㑡"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ㑢"),l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ㑣"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ㑤"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㑥"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ㑦"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ㑧")]
l1l11l1l1lll_l1_ = [l11ll1_l1_ (u"ࠫࡎࡖࡔࡗࠩ㑨"),l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ㑩"),l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ㑪"),l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ㑫")]
l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"ࠨࡏ࠶࡙ࠬ㑬"),l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ㑭"),l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㑮"),l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㑯")]
l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㑰"),l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ㑱"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ㑲")]
l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㑳"),l11ll1_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㑴"),l11ll1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㑵"),l11ll1_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㑶")]		# l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㑷")
l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㑸"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㑹"),l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㑺"),l11ll1_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㑻"),l11ll1_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㑼"),l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㑽")]
#l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㑾"),l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ㑿"),l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭㒀"),l11ll1_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㒁")]
#l1l11l1l1lll_l1_ += [l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ㒂"),l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘ࠭㒃"),l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࠨ㒄"),l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࠨ㒅")]
l1l1llll11l_l1_ = [l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㒆"),l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ㒇"),l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㒈"),l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㒉")]
l1l1llll11l_l1_ += [l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㒊"),l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ㒋"),l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㒌"),l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㒍"),l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ㒎")]
l1ll11111l1_l1_ = [l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㒏"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㒐"),l11ll1_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㒑"),l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㒒"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㒓"),l11ll1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㒔")]
l1ll11111l1_l1_ += [l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㒕"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㒖"),l11ll1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㒗"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ㒘")]
#l1ll11111l1_l1_ += [l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㒙"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㒚")]
l1ll11ll1ll_l1_ = [l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㒛"),l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㒜"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㒝"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㒞"),l11ll1_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㒟"),l11ll1_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㒠"),l11ll1_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㒡"),l11ll1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㒢")]	# ,l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㒣")
l1ll11ll1ll_l1_ += [l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㒤"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㒥"),l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㒦"),l11ll1_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㒧"),l11ll1_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㒨"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㒩"),l11ll1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㒪")]
#l1ll11ll1ll_l1_ += [l11ll1_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ㒫"),l11ll1_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ㒬"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ㒭"),l11ll1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㒮"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㒯"),l11ll1_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㒰"),l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㒱")]
l1ll111lll11_l1_  = [l11ll1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㒲"),l11ll1_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㒳"),l11ll1_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㒴"),l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㒵"),l11ll1_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㒶"),l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㒷"),l11ll1_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㒸"),l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㒹")]
l1ll111lll11_l1_ += [l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㒺"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㒻"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㒼"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㒽"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㒾"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㒿"),l11ll1_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㓀"),l11ll1_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㓁"),l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㓂")]
l1ll111lll11_l1_ += [l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㓃"),l11ll1_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㓄"),l11ll1_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㓅")]		# l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ㓆"),l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ㓇"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㓈")
l1ll111lll11_l1_ += [l11ll1_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㓉"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㓊"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㓋"),l11ll1_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ㓌"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㓍"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㓎"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㓏")]
l1ll111lll11_l1_ += [l11ll1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㓐"),l11ll1_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㓑"),l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㓒"),l11ll1_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ㓓"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㓔"),l11ll1_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ㓕"),l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㓖")]
l1l1l1l1l111_l1_  = [l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㓗"),l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㓘"),l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㓙"),l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㓚")]
l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭㓛"),l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ㓜")]
l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ㓝"),l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ㓞"),l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㓟")]
l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ㓠"),l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ㓡"),l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ㓢")]
l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ㓣"),l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭㓤"),l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ㓥")]
#l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㓦"),l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ㓧")]
#l1l1l1l1l111_l1_ += [l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࠪ㓨"),l11ll1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࠪ㓩"),l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࠫ㓪")]
l1l1ll11ll11_l1_ = [l11ll1_l1_ (u"ࠩࡐ࠷࡚࠭㓫"),l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㓬"),l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㓭"),l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㓮"),l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㓯")]		# l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㓰"),l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ㓱")
l1ll111ll1l_l1_ = l1ll111lll11_l1_+l1l1l1l1l111_l1_
l1l1lllllll1_l1_ = l1ll111lll11_l1_+l1l1ll11ll11_l1_
l11ll1ll11l_l1_ = l1ll111lll11_l1_+l1l1ll11ll11_l1_+l1l1l1ll1lll_l1_
l1ll111ll11_l1_ = l1l11l1l1lll_l1_+l1ll11111l1_l1_+l1ll11ll1ll_l1_+l1l1llll11l_l1_
# l1lll1l1lll1_l1_ will not show l111111lll1_l1_ errors and will not exit from the l11ll11ll11_l1_
l1111ll1111_l1_ = [
						l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ㓲")
						,l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ㓳")
						,l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ㓴")
						,l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭㓵")
						,l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ㓶")
						,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ㓷")
						,l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ㓸")
						,l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬ㓹")
						,l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㓺")
						,l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ㓻")
						]
l111ll1llll_l1_ = l1111ll1111_l1_+[
				 l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ㓼")
				,l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ㓽")
				,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㓾")
				,l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫ㓿")
				,l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬ㔀")
				,l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭㔁")
				,l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭㔂")
				,l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧ㔃")
				,l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨ㔄")
				,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ㔅")
				,l11ll1_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ㔆")
				,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬ㔇")
				,l11ll1_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭㔈")
				,l11ll1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ㔉")
				,l11ll1_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ㔊")
				,l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㔋")
				,l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㔌")
				#,l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭㔍")
				#,l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㔎")
				#,l11ll1_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㔏")
				#,l11ll1_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭㔐")
				#,l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ㔑")
				#,l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡉࡈࡘࡤࡒࡁࡕࡇࡖࡘࡤ࡜ࡅࡓࡕࡌࡓࡓࡥࡎࡖࡏࡅࡉࡗ࡙࠭࠲ࡵࡷࠫ㔒")
				#,l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭㔓")
				#,l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㔔")
				#,l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㔕")
				]
l1llll1ll1ll_l1_ = [l11ll1_l1_ (u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ㔖"),l11ll1_l1_ (u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ㔗"),l11ll1_l1_ (u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭㔘"),l11ll1_l1_ (u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧ㔙"),l11ll1_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ㔚"),l11ll1_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ㔛")]
l1l1lll_l1_ = {
			#,l11ll1_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㔜")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ㔝")]
			#,l11ll1_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㔞")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡱࡱࡡࡸࡶ࡫ࡥࡷࡺࡶ࠯࡫ࡵࠫ㔟")]
			#,l11ll1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㔠")	:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡦࡱ࡯࡯࡯ࡼ࠱ࡲࡪࡺࠧ㔡")]
			#,l11ll1_l1_ (u"ࠨࡇࡊ࡝࠹ࡈࡅࡔࡖࠪ㔢")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ㔣")]
			#,l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㔤")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ㔥")]
			#,l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ㔦")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬ㔧")]
			#,l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㔨")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡥࡨࡻࡱࡳࡼ࠴࡬ࡪࡸࡨࠫ㔩")]
			#,l11ll1_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ㔪")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠹࡮ࡥ࡭ࡣ࡯࠲ࡲ࡫ࠧ㔫")]
			#,l11ll1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㔬")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦࠩ㔭"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩࠬ㔮")]
			#,l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㔯")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡰࡸࡶ࠸ࡺ࠴ࡷࡴࠩ㔰")]
			#,l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ㔱")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲࡿࡣࡪ࡯ࡤ࠲ࡨࡵࠧ㔲")]
			#,l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ㔳"):[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵࠩ㔴")]
			#,l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ㔵")	:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠲ࡨࡵ࡭ࠨ㔶")]
			#,l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ㔷")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࠳ࡹࡨࡰࡱࡩࡴࡷࡵ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ㔸")]    #	l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡳࡶࡴ࠴ࡣࡰ࡯ࠪ㔹")
			 l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㔺")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬ࡱࡤࡱ࠳ࡴࡥࡵࠩ㔻")]
			,l11ll1_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㔼")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦ࡮ࡷࡢ࡭ࡷࡺ࠳ࡴࡥࡵࠩ㔽")]
			,l11ll1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㔾")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹ࠭㔿")]
			,l11ll1_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㕀")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠭㕁")]
			,l11ll1_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㕂")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭ࡨࡤࡸ࡮ࡳࡩ࠯ࡶࡹࠫ㕃")]
			,l11ll1_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㕄")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡰࡲࡧࡡࡳࡧࡩ࠲ࡨ࡮ࠧ㕅")]
			,l11ll1_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㕆")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ࠪ㕇")]
			,l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㕈")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬ㕉")]
			,l11ll1_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㕊")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡼ࡯ࡥ࠰ࡦࡳࡲ࠭㕋")]
			,l11ll1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㕌")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡷࡹࡴࡦ࡬࠱ࡧࡴࡳࠧ㕍")]
			,l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㕎")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠷࠴࠵࠴ࡣࡰ࡯ࠪ㕏")]
			,l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㕐")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬ㕑")]
			,l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㕒")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡡࡣࡦࡲ࠲ࡨࡵ࡭ࠨ㕓")]
			,l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㕔")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡩ࠮ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡳࡷࡱࠧ㕕")]
			,l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㕖")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣ࠰࡬ࡳࠬ㕗")]
			,l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㕘")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ㕙")]
			,l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㕚")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠴ࡣࡰ࡯ࠪ㕛")]
			,l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㕜")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡲࡴࡽ࠮ࡤࡱࡰࠫ㕝")]
			,l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㕞")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㕟"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㕠")]
			,l11ll1_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㕡")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫ㕢")]
			,l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㕣")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ㕤")]
			,l11ll1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ㕥")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭㕦")]
			,l11ll1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㕧")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭㕨")]
			,l11ll1_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㕩")	:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ㕪")]
			,l11ll1_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㕫")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡻ࡯ࡰࠨ㕬")]
			,l11ll1_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㕭")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭㕮")]
			,l11ll1_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㕯")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡪ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭㕰")]
			,l11ll1_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㕱")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮ࡶࡵࠪ㕲")]
			,l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㕳")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㕴"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㕵"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㕶"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㕷"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ㕸")]
			,l11ll1_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㕹")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭㕺")]
			,l11ll1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㕻")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰࠫ㕼")]
			,l11ll1_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ㕽")	:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭㕾"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧ࡯ࡴ࠯࡮ࡼ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭㕿")]
			,l11ll1_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ㖀")		:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡢࡴࡲࡾࡦ࠴࡯࡯ࡧࠪ㖁")]
			,l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㖂")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡲࡨࡾࡴࡥࡵ࠰ࡦࡥࡲ࠭㖃")]
			,l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㖄")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ㖅")]
			,l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㖆")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪࡨࡨ࠹ࡻ࠮ࡣࡧࡷࠫ㖇")]
			,l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㖈")	:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ㖉")]
			,l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㖊")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧ㖋")]
			,l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㖌")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ㖍"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ㖎"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ㖏")]
			,l11ll1_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ㖐")		:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡸࡻ࡬ࡵ࡯࠰ࡰࡩࠬ㖑")]
			,l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㖒")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪࡩࡩ࡮ࡣ࠱ࡸࡺࡨࡥࠨ㖓")]
			,l11ll1_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ㖔")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿ࠮ࡺࡣࡴࡳࡹ࠴ࡴࡷࠩ㖕")]
			,l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㖖")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩ㖗")]
			#,l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㖘")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㖙"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㖚"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㖛"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㖜"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㖝"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㖞"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㖟")]
			#,l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㖠")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㖡"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㖢"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㖣"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㖤"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㖥"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㖦"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㖧")]
			#,l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㖨")		:[l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㖩"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㖪"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㖫"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㖬"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㖭"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㖮"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㖯")]
			#,l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㖰")		:[l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㖱"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㖲"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㖳"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㖴"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㖵"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㖶"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㖷")]
			#,l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㖸")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㖹"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㖺"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㖻"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㖼"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㖽"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㖾"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㖿")]
			,l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㗀")		:[l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㗁"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㗂"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㗃"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㗄"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㗅"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㗆"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㗇")]
			,l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ㗈")	:[l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㗉"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㗊"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㗋"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㗌"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㗍"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㗎"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㗏")]
			,l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㗐")		:[l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ㗑"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭㗒"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ㗓")]
			,l11ll1_l1_ (u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖࠧ㗔")	:[l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㗕"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ㗖"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ㗗")]
			,l11ll1_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ㗘")		:[l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡰࡵࡤࡪࠩ㗙"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠭㗚"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕࠧ㗛")]
			}
class l1l1ll11lll1_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11ll11l11l_l1_ = -1
	def onClick(self,l1llll1lllll_l1_):
		if l1llll1lllll_l1_>=9010: self.l11ll11l11l_l1_ = l1llll1lllll_l1_-9010
		self.delete()
	def l1111llll11_l1_(self,*args):
		#self.getControl(9001).l1l1l1l1l11_l1_(header)
		#self.getControl(9009).l1lll1l111ll_l1_(text)
		#self.getControl(9010).l1l1l1l1l11_l1_(l111111l111_l1_)
		#self.getControl(9011).l1l1l1l1l11_l1_(l1l1ll11111l_l1_)
		#self.getControl(9012).l1l1l1l1l11_l1_(l111111ll1l_l1_)
		self.l111111l111_l1_,self.l1l1ll11111l_l1_,self.l111111ll1l_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.l11111ll11l_l1_,self.l1ll11l1ll11_l1_ = args[5],args[6]
		self.l1ll11ll111l_l1_,self.l1l11l1l1111_l1_,self.l1l1l111lll1_l1_ = args[7],args[8],args[9]
		if self.l1l11l1l1111_l1_>0 or self.l1l1l111lll1_l1_>0: self.l1ll1111llll_l1_ = True
		else: self.l1ll1111llll_l1_ = False
		self.l1lll1ll11l1_l1_,self.l1111llll1l_l1_ = l1lll1l1ll11_l1_(self.l111111l111_l1_,self.l1l1ll11111l_l1_,self.l111111ll1l_l1_,self.header,self.text,self.l11111ll11l_l1_,self.l1ll11l1ll11_l1_,self.l1ll11ll111l_l1_,self.l1ll1111llll_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll1ll11l1_l1_)
		self.getControl(9050).setHeight(self.l1111llll1l_l1_)
		if not self.l1l1ll11111l_l1_ and self.l111111l111_l1_ and self.l111111ll1l_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll1ll11l1_l1_,self.l1111llll1l_l1_
	def l11ll111l1l_l1_(self):
		if self.l1l11l1l1111_l1_:
			import threading
			self.l11lll1lll1_l1_ = threading.Thread(target=self.l1ll1l1111ll_l1_,args=())
			self.l11lll1lll1_l1_.start()
			#self.l11lll1lll1_l1_.join()
		else: self.enableButtons()
	def l1ll1l1111ll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11ll1111l_l1_ in range(1,self.l1l11l1l1111_l1_+1):
			time.sleep(1)
			l1l11l1l1l1l_l1_ = int(100*l11ll1111l_l1_/self.l1l11l1l1111_l1_)
			self.l1lll11111l1_l1_(l1l11l1l1l1l_l1_)
			if self.l11ll11l11l_l1_>0: break
		self.enableButtons()
	def l11l1l1ll1l_l1_(self):
		if self.l1l1l111lll1_l1_:
			import threading
			self.l1l1llllll1l_l1_ = threading.Thread(target=self.l1lll1lll111_l1_,args=())
			self.l1l1llllll1l_l1_.start()
			#self.l1l1llllll1l_l1_.join()
		else: self.enableButtons()
	def l1lll1lll111_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l11l1l1111_l1_)
		for l11ll1111l_l1_ in range(self.l1l1l111lll1_l1_-1,-1,-1):
			time.sleep(1)
			l1l11l1l1l1l_l1_ = int(100*l11ll1111l_l1_/self.l1l1l111lll1_l1_)
			self.l1lll11111l1_l1_(l1l11l1l1l1l_l1_)
			if self.l11ll11l11l_l1_>0: break
		if self.l1l1l111lll1_l1_>0: self.l11ll11l11l_l1_ = 10
		self.delete()
	def l1lll11111l1_l1_(self,l1l11l1l1l1l_l1_):
		self.l1l1l11l1l1l_l1_ = l1l11l1l1l1l_l1_
		self.getControl(9020).setPercent(self.l1l1l11l1l1l_l1_)
	def enableButtons(self):
		if self.l111111l111_l1_!=l11ll1_l1_ (u"ࠬ࠭㗜"): self.getControl(9010).setEnabled(True)
		if self.l1l1ll11111l_l1_!=l11ll1_l1_ (u"࠭ࠧ㗝"): self.getControl(9011).setEnabled(True)
		if self.l111111ll1l_l1_!=l11ll1_l1_ (u"ࠧࠨ㗞"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll1ll11l1_l1_)
		except: pass
		#del self
	l11ll1_l1_ (u"ࠣࠤࠥࠑࠏࠏࡤࡦࡨࠣࡹࡵࡪࡡࡵࡧࠫࡷࡪࡲࡦ࠭ࡲࡨࡶࡨ࡫࡮ࡵ࠮࠭ࡥࡷ࡭ࡳࠪ࠼ࠐࠎࠎࠏࡴࡦࡺࡷࠤࡂࠦࡡࡳࡩࡶ࡟࠵ࡣࠍࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡥࡷ࡭ࡳࠪࡀ࠴࠾ࠥࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࡦࡸࡧࡴ࡝࠴ࡡࠒࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡣࡵ࡫ࡸ࠯࠾࠳࠼ࠣࡸࡪࡾࡴࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࡤࡶ࡬ࡹ࡛࠳࡟ࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡵ࡫ࡲࡤࡧࡱࡸ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴࠡ࠿ࠣࡴࡪࡸࡣࡦࡰࡷ࠰ࡹ࡫ࡸࡵࠏࠍࠍࠎࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡪࡨ࡭࡬࡮ࡴࠡ࠿ࠣࡷࡪࡲࡦ࠯ࡥࡵࡩࡦࡺࡥࡔࡪࡲࡻࡎࡳࡡࡨࡧࠫࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮࠱࠮ࡶࡩࡱ࡬࠮ࡣࡷࡷࡸࡴࡴ࠱࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳ࠸ࠬࡴࡧ࡯ࡪ࠳࡮ࡥࡢࡦࡨࡶ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴ࠭ࡵࡨࡰ࡫࠴ࡰࡳࡱࡩ࡭ࡱ࡫ࠬࡴࡧ࡯ࡪ࠳ࡪࡩࡳࡧࡦࡸ࡮ࡵ࡮࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤࡽࡩࡥࡶ࡫࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯ࡵࡷ࡭ࡲ࡫࡯ࡶࡶ࠯ࡷࡪࡲࡦ࠯ࡥ࡯ࡳࡸ࡫ࡴࡪ࡯ࡨࡳࡺࡺࠩࠎࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡸࡴࡩࡧࡴࡦࡒࡵࡳ࡬ࡸࡥࡴࡵࡅࡥࡷ࠮ࡰࡦࡴࡦࡩࡳࡺࠩࠎࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡩࡧ࡬࡫࡭ࡺࠍࠋࠋࠥࠦࠧ㗟")
class l111l1l1ll1_l1_():
	def __init__(self,l1ll_l1_=False,l1ll111l11l1_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1ll111l11l1_l1_ = l1ll111l11l1_l1_
		self.l111ll1l11l_l1_,self.l11ll1ll111_l1_ = [],[]
		self.l1lllll11111_l1_,self.l1lll11l11l1_l1_ = {},{}
		self.l1111l1l11l_l1_ = []
		self.l1l11lll11ll_l1_,self.l1l1l111111l_l1_,self.l11l1lllll1_l1_ = {},{},{}
	def l111l11l11l_l1_(self,id,func,*args):
		id = str(id)
		self.l1lllll11111_l1_[id] = l11ll1_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ㗠")
		if self.l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠪࠫ㗡"),id)
		# l1111l1l1l1_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1111l1l1l1_l1_ 2 & 3
		import threading
		l11ll11l1ll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1111l1l11l_l1_.append(l11ll11l1ll_l1_)
		#l11ll11l1ll_l1_.start()
		return l11ll11l1ll_l1_
	def start_new_thread(self,id,func,*args):
		l11ll11l1ll_l1_ = self.l111l11l11l_l1_(id,func,*args)
		l11ll11l1ll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l11lll11ll_l1_[id] = time.time()
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㗢"),l11ll1_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡩࡥ࠼ࠣࠫ㗣")+id)
		try:
			#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㗤"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡈ࠿ࡀࠠࠨ㗥")+str(func))
			self.l1lll11l11l1_l1_[id] = func(*args)
			if l11ll1_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ㗦") in str(func) and not self.l1lll11l11l1_l1_[id].succeeded:
				l1llll111l11_l1_(l11ll1_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠࡵࡪࡵࡩࡦࡪࡥࡥࠢࡒࡔࡊࡔࡕࡓࡎࠣࡪࡦ࡯࡬ࠨ㗧"))
			self.l111ll1l11l_l1_.append(id)
			self.l1lllll11111_l1_[id] = l11ll1_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ㗨")
			#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㗩"),l11ll1_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠠࡪࡦ࠽ࠤࠬ㗪")+id)
		except Exception as err:
			#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㗫"),l11ll1_l1_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡪࡦ࠽ࠤࠬ㗬")+id)
			if self.l1ll111l11l1_l1_:
				l1llllll11ll_l1_ = traceback.format_exc()
				sys.stderr.write(l1llllll11ll_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11ll1ll111_l1_.append(id)
			self.l1lllll11111_l1_[id] = l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㗭")
		self.l1l1l111111l_l1_[id] = time.time()
		self.l11l1lllll1_l1_[id] = self.l1l1l111111l_l1_[id] - self.l1l11lll11ll_l1_[id]
	def l1ll111l111l_l1_(self):
		for proc in self.l1111l1l11l_l1_:
			proc.start()
	def l1ll111lll1l_l1_(self):
		while l11ll1_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ㗮") in list(self.l1lllll11111_l1_.values()): time.sleep(1.000)
def l1ll11l11l11_l1_():
	l1l1lll1lll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㗯"))
	l1111111l11_l1_ = True
	if l1l1lll1lll1_l1_==l11llll11ll_l1_:
		status = l11ll1_l1_ (u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㗰")
		l1111111l11_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11ll1_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ㗱")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11ll1_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㗲")
	else:
		status = l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤ࡛ࡐࡅࡃࡗࡉࠬ㗳")
		l11l111111l_l1_ = [l11ll1_l1_ (u"ࠨ࠺࠱࠹࠳࠶ࠧ㗴"),l11ll1_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠲࠱࠵࠾࠭㗵"),l11ll1_l1_ (u"ࠪ࠶࠵࠸࠱࠯࠳࠴࠲࠷࠺ࡡࠨ㗶"),l11ll1_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠶࠳࠹࠰ࠨ㗷"),l11ll1_l1_ (u"ࠬ࠸࠰࠳࠴࠱࠴࠷࠴࠰࠳ࠩ㗸"),l11ll1_l1_ (u"࠭࠲࠱࠴࠵࠲࠶࠶࠮࠳࠴ࠪ㗹"),l11ll1_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠳࠯࠲࠹ࠫ㗺"),l11ll1_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠰࠶࠰࠴࠺ࠬ㗻"),l11ll1_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠸࠱࠴࠻࠭㗼")]
		l1lll1111l11_l1_ = l11l111111l_l1_[-1]
		l11111l111l_l1_ = l1l11l1l11ll_l1_(l1lll1111l11_l1_)
		l1ll1ll11lll_l1_ = l1l11l1l11ll_l1_(l11llll11ll_l1_)
		if l1ll1ll11lll_l1_>l11111l111l_l1_:
			status = l11ll1_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ㗽")
			l11ll1_l1_ (u"ࠦࠧࠨࠍࠋࠋࠌࠍ࡫࡯࡬ࡦࡵࠣࡁࠥࡵࡳ࠯࡮࡬ࡷࡹࡪࡩࡳࠪࡤࡨࡩࡵ࡮ࡤࡣࡦ࡬ࡪ࡬࡯࡭ࡦࡨࡶ࠮ࠓࠊࠊࠋࠌࡪ࡮ࡲࡥࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡫࡯࡬ࡦࡵ࠯ࡶࡪࡼࡥࡳࡵࡨࡁ࡙ࡸࡵࡦࠫࠐࠎࠎࠏࠉࡧࡱࡵࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࠦࡩ࡯ࠢࡩ࡭ࡱ࡫ࡳ࠻ࠏࠍࠍࠎࠏࠉࡪࡨࠣࠫࡩࡧࡴࡢࡡࠪࠤ࡮ࡴࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢࡤࡲࡩࠦࠧ࠯ࡦࡥࠫࠥ࡯࡮ࠡࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠽ࠑࠏࠏࠉࠊࠋࠌࡳࡱࡪ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦࡥࠨ࠯ࠬࡂ࠭ࡡ࠴ࡤࡣࠩ࠯ࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࠦ࠽ࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡡ࠰࡞ࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠠ࠾࡙ࠢࡉࡗ࡙ࡉࡐࡐࡢࡇࡔࡓࡐࡂࡔࡈࡣࡕࡇࡒࡔࡇࡕࠬࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠫࠐࠎࠎࠏࠉࠊࠋ࡬ࡪࠥ࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡࡠࠩࠣ࡭ࡳࠦࡦࡪ࡮ࡨࡲࡦࡳࡥ࠻ࠏࠍࠍࠎࠏࠉࠊࠋ࡬ࡪࠥࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰࡢࡧࡴࡳࡰࡢࡴࡨࡂࡂࡲࡡࡴࡶࡩࡹࡱࡲ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࡠࡥࡲࡱࡵࡧࡲࡦ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࡴࡲࡤࡠࡦࡥࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡤࡨࡩࡵ࡮ࡤࡣࡦ࡬ࡪ࡬࡯࡭ࡦࡨࡶ࠱࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠩࠎࠌࠌࠍࠎࠏࠉࠊࠋࡷࡶࡾࡀࠍࠋࠋࠌࠍࠎࠏࠉࠊࠋ࡬ࡪࠥࡵ࡬ࡥࡡࡧࡦ࡫࡯࡬ࡦࠣࡀࡱࡦ࡯࡮ࡠࡦࡥࡪ࡮ࡲࡥ࠻ࠢࡲࡷ࠳ࡸࡥ࡯ࡣࡰࡩ࠭ࡵ࡬ࡥࡡࡧࡦ࡫࡯࡬ࡦ࠮ࡰࡥ࡮ࡴ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠎࠌࠌࠍࠎࠏࠉࠊࠋࠌࡷࡹࡧࡴࡶࡵࠣࡁࠥ࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭ࠍࠋࠋࠌࠍࠎࠏࠉࠊࠋࡥࡶࡪࡧ࡫ࠎࠌࠌࠍࠎࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠍࠎࠨࠢࠣ㗾")
	return status,l1111111l11_l1_
def l1llll1111l1_l1_(l1ll1111ll1_l1_,l1ll1l1lll11_l1_):
	succeeded,l1llllll111l_l1_,l11l11lllll_l1_ = True,False,False
	type,name,l1l111ll1l1_l1_,mode,l1l11l111ll_l1_,l11lll11111_l1_,text,context,l1ll1ll1l1l_l1_ = l1ll1111ll1_l1_
	l1l1l11111l1_l1_ = type,name,l1l111ll1l1_l1_,mode,l1l11l111ll_l1_,l11lll11111_l1_,text,l11ll1_l1_ (u"ࠬ࠭㗿"),l1ll1ll1l1l_l1_
	l1ll111111ll_l1_ = int(mode)
	l1111llllll_l1_ = int(l1ll111111ll_l1_%10)
	l1ll11111l11_l1_ = int(l1ll111111ll_l1_/10)
	l1l11l1ll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㘀"))
	l1lllllll111_l1_,l1111111l11_l1_ = l1ll11l11l11_l1_()
	if l1111111l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㘁"),l11ll1_l1_ (u"ࠨࠩ㘂"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㘃"),l11ll1_l1_ (u"ࠪฮ๊ࠦสฮัํฯࠥอไษำ้ห๊าࠠโ์ࠣะ์อาไ࡞ࡱษ้๏ࠠศๆศูิอัࠡำๅ้࠿ࡢ࡮࡝ࡰࠪ㘄")+l11llll11ll_l1_)
		#settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㘅"),l11ll1_l1_ (u"ࠬ࠭㘆"))
		#settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭㘇"),l11ll1_l1_ (u"ࠧࠨ㘈"))
		#settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪ㘉"),l11ll1_l1_ (u"ࠩࠪ㘊"))
		#settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭㘋"),l11ll1_l1_ (u"ࠫࠬ㘌"))
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㘍"),l11ll1_l1_ (u"࠭ࠧ㘎"))
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡸ࡮ࡳࡥࠨ㘏"),l11ll1_l1_ (u"ࠨࠩ㘐"))
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㘑"),l11ll1_l1_ (u"ࠪࠫ㘒"))
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㘓"),l11ll1_l1_ (u"ࠬ࠭㘔"))
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㘕"),l11ll1_l1_ (u"ࠧࠨ㘖"))
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ㘗"),l11ll1_l1_ (u"ࠩࠪ㘘"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㘙"),l11ll1_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㘚"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㘛"),l11ll1_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㘜"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㘝"),l11ll1_l1_ (u"ࠨࡃࡘࡘࡍ࠭㘞"))
		if not l1l11l1ll11l_l1_: settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㘟"),l11ll1_l1_ (u"ࠪࠫ㘠"))
		#l1l1lll1lll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㘡"))
		#if l1l1lll1lll1_l1_:
		#	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ㘢"),l11ll1_l1_ (u"࠭ࠧ㘣"))
		#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㘤"))
		#	return
		#l11l11111l1_l1_([main_dbfile])
		import l1l1111lll1_l1_
		if l1lllllll111_l1_==l11ll1_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ㘥"):
			LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㘦"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㘧")+addon_path+l11ll1_l1_ (u"ࠫࠥࡣࠧ㘨"))
			DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㘩"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ㘪"))
			for l1lll111llll_l1_ in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㘫"),l11ll1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩ㘬")+str(l1lll111llll_l1_))
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㘭"),l11ll1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ㘮")+str(l1lll111llll_l1_))
		else:
			LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㘯"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㘰")+addon_path+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㘱"))
			DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㘲"),l11ll1_l1_ (u"ࠨࠩ㘳"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㘴"),l11ll1_l1_ (u"ࠪฮ๊ࠦสฬสํฮࠥษ่ࠡฬะำ๏ัࠠศๆศูิอัࠡษ็ะิ๐ฯࠡๆหี๋อๅอࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢฦ์ࠥะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤࡡࡴ࡜࡯ࠢึ๎็๎ๅࠡษ็ฦ๋ࠦวๅสิ๊ฬ๋ฬࠡสห฽฻ࠦวๅใะ์ฺอสࠡๆู้ฬ์ฺࠠ็็ࠤฬ๊ศา่ส้ัࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๋สไษ่่ฮ࠭㘵"))
			l11l11111l1_l1_()
			FIX_ALL_DATABASES(False)
			l111l1l1111_l1_ = l1l11l11l11_l1_(32)
			l1l1111lll1_l1_.l1l1l1lll111_l1_()
			l1l1111lll1_l1_.l11l11llll1_l1_(l11ll1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㘶"),False)
			l1l1111lll1_l1_.l11l11llll1_l1_(l11ll1_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㘷"),False)
			l1l1111lll1_l1_.l1lll1ll111l_l1_(False)
			l1l1111lll1_l1_.l1l1l1l1ll11_l1_(False)
			l1l1111lll1_l1_.l1l1l1ll1ll1_l1_(l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㘸"),l11ll1_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࠧ㘹"),False)
			l11ll1_l1_ (u"ࠣࠤࠥࠑࠏࠏࠉࠊࡶࡵࡽ࠿ࠓࠊࠊࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࡬ࡩ࡭ࡧ࠵ࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡻࡳࡦࡴࡩࡳࡱࡪࡥࡳ࠮ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ࠲ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ࠱࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠬࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧࠪࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠴ࠣࡁࠥࡾࡢ࡮ࡥࡤࡨࡩࡵ࡮࠯ࡃࡧࡨࡴࡴࠨࡪࡦࡀࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ࠮ࠓࠊࠊࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠸࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡱ࡯ࡥ࡫ࡲࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡶࡻࡡ࡭࡫ࡷࡽ࠳ࡧࡳ࡬ࠩ࠯ࠫࡹࡸࡵࡦࠩࠬࠑࠏࠏࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠍࠋࠋࠌࠍࠧࠨࠢ㘺")
			try:
				l111lll1l1l_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㘻"),l11ll1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㘼"),l11ll1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ㘽"),l11ll1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㘾"))
				l1llll1ll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㘿"))
				l1llll1ll11l_l1_.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭㙀"),l11ll1_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ㙁"))
			except: pass
			try:
				l111lll1l1l_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㙂"),l11ll1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㙃"),l11ll1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ㙄"),l11ll1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㙅"))
				l1llll1ll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㙆"))
				l1llll1ll11l_l1_.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪ㙇"),l11ll1_l1_ (u"ࠨ࠵ࠪ㙈"))
			except: pass
			try:
				l111lll1l1l_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㙉"),l11ll1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㙊"),l11ll1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㙋"),l11ll1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㙌"))
				l1llll1ll11l_l1_ = xbmcaddon.Addon(id=l11ll1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㙍"))
				l1llll1ll11l_l1_.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬ㙎"),l11ll1_l1_ (u"ࠨ࠴ࠪ㙏"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㙐"),l11ll1_l1_ (u"ࠪࠫ㙑"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㙒"),l11ll1_l1_ (u"ࠬหะศࠢๆ๊ฯࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡏࡐࡕࡘࠣห้๋่อ๊าอࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠠโี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฮ้่วว์สࠤอาไษ่่ࠢๆอสࠡโࡌࡔ࡙࡜ࠠอัํำฮ࠭㙓"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1lllll11l11_l1_):
			#	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㙔"),l11ll1_l1_ (u"ࠧࠨ㙕"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㙖"),l11ll1_l1_ (u"ࠩศิฬࠦใ็ฬࠣฮุะฮะ็ࠣาิ๋ษࠡโࡐ࠷࡚ࠦวๅ็๋ะํีษࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦสๅไสส๏อࠠษฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ㙗"))
			#	import l1l1l111ll1l_l1_
			#	l1l1l111ll1l_l1_.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l1l111l11ll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l11l1l1l11_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㙘"),l11llll11ll_l1_)
		l1l1111lll1_l1_.l11l1l11lll_l1_(False)
		#return
	#text = text.replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㙙"),l11ll1_l1_ (u"ࠬ࠭㙚"))
	l1l11lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㙛"))
	l11l1llll1_l1_ = RESTORE_PATH_NAME(l1ll1l1lll11_l1_)
	l1l11111lll_l1_ = RESTORE_PATH_NAME(name)
	l1llll111ll1_l1_ = [0,15,17,19,26,34,50,53]
	l1ll11l1llll_l1_ = [0,15,17,19,26,34,50,53]
	l11ll1111ll_l1_ = l1ll11111l11_l1_ not in l1ll11l1llll_l1_
	l1l11l1lll11_l1_ = l1ll11111l11_l1_ in [23,28,71,72]
	l1ll1l1l1l1l_l1_ = l1ll111111ll_l1_ in [265,270]
	l1lll11ll111_l1_ = (l11ll1111ll_l1_ or l1l11l1lll11_l1_) and not l1ll1l1l1l1l_l1_
	l111lllll11_l1_ = l1l11lllll_l1_!=l11ll1_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㙜") and (l1l11lllll_l1_!=l11ll1_l1_ (u"ࠨࠩ㙝") or context==l11ll1_l1_ (u"ࠩࠪ㙞"))
	l1111l1ll11_l1_ = l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠾ࠩ㙟") in l1l11lllll_l1_
	l1l1l1ll111l_l1_ = l1ll111111ll_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l1111llllll_l1_==9 or l1ll111111ll_l1_ in [145,516,523]
	l11l1ll11l1_l1_ = not l1l1l1ll111l_l1_
	l111ll11ll1_l1_ = not SEARCH
	l1l1lll1l11l_l1_ = l11l1llll1_l1_ in [l11ll1_l1_ (u"ࠫࠬ㙠"),l11ll1_l1_ (u"ࠬ࠴࠮ࠨ㙡")]
	l11ll1lll11_l1_ = l1l1lll1l11l_l1_ or l11l1ll11l1_l1_
	l1llll11l1l1_l1_ = l1l1lll1l11l_l1_ or l111ll11ll1_l1_ or l1111l1ll11_l1_
	l1l1l1111l1l_l1_ = l1ll111111ll_l1_ not in [260,265,270,330,540]
	if l1l11l1ll11l_l1_: l111111l11l_l1_ = SEARCH or l1l1l1ll111l_l1_
	else: l111111l11l_l1_ = True
	l1l1ll1111_l1_ = l1ll11111l11_l1_ in [74,75]
	l11l1l1l11l_l1_ = l1ll111111ll_l1_ in [280,720]
	l11111ll1ll_l1_ = not l1l1ll1111_l1_ and not l11l1l1l11l_l1_
	l1ll1ll1l11l_l1_ = l11ll1lll11_l1_ and l1llll11l1l1_l1_ and l1l1l1111l1l_l1_ and l111111l11l_l1_ and l11111ll1ll_l1_
	l1ll11ll1111_l1_ = l1l1l1111l1l_l1_ and l111111l11l_l1_ and l11111ll1ll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㙢"),l11ll1_l1_ (u"ࠧࠨ㙣"),l11ll1_l1_ (u"ࠨࠩ㙤"),type+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㙥")+l1l11lllll_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ㙦")+str(l1ll11ll1111_l1_))
	trans_provider = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡳࡶࡴࡼࡩࡥࡧࡵࠫ㙧"))
	trans_code = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ㙨"))
	if 1 and l111lllll11_l1_ and l1ll1ll1l11l_l1_:
		l1lll111lll1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㙩"),l11ll1_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㙪")+trans_provider+l11ll1_l1_ (u"ࠨࡡࠪ㙫")+trans_code,l1l1l11111l1_l1_)
		if l1lll111lll1_l1_:
			#xbmcgui.Dialog().l1l1l1l111ll_l1_(l11ll1_l1_ (u"ࠩࠪ㙬"),l11ll1_l1_ (u"ࠪࡶࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࠪ㙭"),l11ll1_l1_ (u"ࠫࠬ㙮"),100,False)
			LOG_THIS(l11ll1_l1_ (u"ࠬ࠭㙯"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㙰")+trans_provider+l11ll1_l1_ (u"ࠧࡠࠩ㙱")+trans_code+l11ll1_l1_ (u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧ㙲"))
			if 1 and l1111l1ll11_l1_:
				#xbmcgui.Dialog().l1l1l1l111ll_l1_(l11ll1_l1_ (u"ࠩࠪ㙳"),l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧࡻ࡬ࡲ࡬ࠦࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ㙴"),l11ll1_l1_ (u"ࠫࠬ㙵"),100,False)
				l11l1l1l1ll_l1_ = []
				import l1l1l11l1lll_l1_,FAVORITES
				l1ll1l1llll1_l1_ = l1l1l11l1lll_l1_.l1lll111l11l_l1_
				l11l1l11l11_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lllll111ll_l1_ = l1l11lllll_l1_
				l111l1lll1l_l1_,l111ll1l1l1_l1_,l1ll1l1l1ll1_l1_,l1l1lllll1ll_l1_,l11l111ll1l_l1_,l1lll1lllll1_l1_,l111ll1l1ll_l1_,l1ll11ll1l1l_l1_,l1lll1lll1l1_l1_ = EXTRACT_KODI_PATH(l1lllll111ll_l1_)
				l1ll1ll1111l_l1_ = l111l1lll1l_l1_,l111ll1l1l1_l1_,l1ll1l1l1ll1_l1_,l1l1lllll1ll_l1_,l11l111ll1l_l1_,l1lll1lllll1_l1_,l111ll1l1ll_l1_,l11ll1_l1_ (u"ࠬ࠭㙶"),l1lll1lll1l1_l1_
				#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㙷"),str(l1ll1ll1111l_l1_))
				for l1ll111llll1_l1_ in l1lll111lll1_l1_:
					l1l1ll1l11ll_l1_ = l1ll111llll1_l1_[l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࡎࡺࡥ࡮ࠩ㙸")]
					#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㙹"),str(l1l1ll1l11ll_l1_))
					if l1l1ll1l11ll_l1_==l1ll1ll1111l_l1_ or l1ll111llll1_l1_[l11ll1_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㙺")] in [265,270]:
						l1ll111llll1_l1_ = GET_LIST_ITEM(l1l1ll1l11ll_l1_,l1ll1l1llll1_l1_,l11l1l11l11_l1_)
						if l1ll111llll1_l1_[l11ll1_l1_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭㙻")]:
							#xbmcgui.Dialog().l1l1l1l111ll_l1_(l11ll1_l1_ (u"ࠫࠬ㙼"),l11ll1_l1_ (u"ࠬࡻࡰࡥࡣࡷ࡭ࡳ࡭ࠠࡤࡱࡱࡸࡪࡾࡴࠨ㙽"),l11ll1_l1_ (u"࠭ࠧ㙾"),100,False)
							l1l1lll1llll_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l11l1l11l11_l1_,l1l1ll1l11ll_l1_,l1ll111llll1_l1_[l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡴࡦࡺࡨࠨ㙿")])
							#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㚀"),str(l1l1lll1llll_l1_))
							#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㚁"),str(l1ll111llll1_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ㚂")]))
							l1ll111llll1_l1_[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ㚃")] = l1l1lll1llll_l1_+l1ll111llll1_l1_[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㚄")]
					l11l1l1l1ll_l1_.append(l1ll111llll1_l1_)
				settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㚅"),l11ll1_l1_ (u"ࠧࠨ㚆"))
				if type==l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㚇"): WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㚈")+trans_provider+l11ll1_l1_ (u"ࠪࡣࠬ㚉")+trans_code,l1l1l11111l1_l1_,l11l1l1l1ll_l1_,REGULAR_CACHE)
			else: l11l1l1l1ll_l1_ = l1lll111lll1_l1_
			if type==l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㚊") and l11l1llll1_l1_!=l11ll1_l1_ (u"ࠬ࠴࠮ࠨ㚋") and l1lll11ll111_l1_: l1l11l111l1_l1_()
			l111lll11ll_l1_ = CREATE_KODI_MENU(l1l1l11111l1_l1_,l11l1l1l1ll_l1_,succeeded,l1llllll111l_l1_,l11l11lllll_l1_)
			#xbmcgui.Dialog().l1l1l1l111ll_l1_(l11ll1_l1_ (u"࠭ࠧ㚌"),l11ll1_l1_ (u"ࠧࡤࡴࡨࡥࡹ࡯࡮ࡨࠢࡰࡩࡳࡻࠧ㚍"),l11ll1_l1_ (u"ࠨࠩ㚎"),100,False)
			return
	elif type==l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㚏") and l1l11lllll_l1_==l11ll1_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㚐") and l1ll11ll1111_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㚑"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㚒")+trans_provider+l11ll1_l1_ (u"࠭࡟ࠨ㚓")+trans_code+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈࡪࡲࡥࡵ࡫ࡱ࡫ࠥࡵ࡬ࡥࠢࡦࡥࡨ࡮ࡥࡥࠢࡰࡩࡳࡻࠧ㚔"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㚕")+trans_provider+l11ll1_l1_ (u"ࠩࡢࠫ㚖")+trans_code,l1l1l11111l1_l1_)
	#context = l11ll1_l1_ (u"ࠪࠫ㚗")
	if l11ll1_l1_ (u"ࠫࡤ࠭㚘") in context: l1ll11ll11l1_l1_,l1l1l111l11l_l1_ = context.split(l11ll1_l1_ (u"ࠬࡥࠧ㚙"),1)
	else: l1ll11ll11l1_l1_,l1l1l111l11l_l1_ = context,l11ll1_l1_ (u"࠭ࠧ㚚")
	if l1ll11ll11l1_l1_ in [l11ll1_l1_ (u"ࠧ࠲ࠩ㚛"),l11ll1_l1_ (u"ࠨ࠴ࠪ㚜"),l11ll1_l1_ (u"ࠩ࠶ࠫ㚝"),l11ll1_l1_ (u"ࠪ࠸ࠬ㚞"),l11ll1_l1_ (u"ࠫ࠺࠭㚟")] and l1l1l111l11l_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㚠") l11l11lll1_l1_ l1l1l1111111_l1_ l1l11llll111_l1_ is no addon_handle l1l111lll_l1_ to l111llll1ll_l1_ for l1lll11ll1ll_l1_ directory
		#l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠩ㚡") l11l11lll1_l1_ to open a menu list using l1l1l1ll11ll_l1_ addon_path
		#xbmc.executebuiltin(l11ll1_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ㚢")+sys.argv[0]+addon_path.split(l11ll1_l1_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀࠫ㚣"))[0]+l11ll1_l1_ (u"ࠩࠩࡧࡴࡴࡴࡦࡺࡷࡁ࠵࠭㚤")+l11ll1_l1_ (u"ࠥ࠭ࠧ㚥"))
		#xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㚦")+addon_id+l11ll1_l1_ (u"ࠬ࠵࠿ࡵࡧࡻࡸࡂࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠩࠨ㚧"))
		# l1111l1l11_l1_ not remove addon_path .. it is needed to update l1l1llll1111_l1_ status
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㚨"),addon_path)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㚩"))
		return
	elif l1ll11ll11l1_l1_==l11ll1_l1_ (u"ࠨ࠸ࠪ㚪"):
		if l1l1l111l11l_l1_==l11ll1_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㚫"): DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪ㚬"),l11ll1_l1_ (u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫ㚭"))
		elif l1l1l111l11l_l1_==l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠬ㚮"): l1ll111111ll_l1_ = 334
		results = l1l1ll1l1ll1_l1_(type,l1l11111lll_l1_,l1l111ll1l1_l1_,l1ll111111ll_l1_,l1l11l111ll_l1_,l11lll11111_l1_,text,context,l1ll1ll1l1l_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㚯"))
		return
	elif context==l11ll1_l1_ (u"ࠧ࠸ࠩ㚰"):
		import l1lll11lll1_l1_
		l1lll11lll1_l1_.l1ll11111ll_l1_()
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㚱"))
		return
	elif context==l11ll1_l1_ (u"ࠩ࠻ࠫ㚲"):
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㚳")+addon_id+l11ll1_l1_ (u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ㚴")+str(mode)+l11ll1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ㚵"))
		return
	elif context==l11ll1_l1_ (u"࠭࠹ࠨ㚶"):
		# l1l11l1ll1l1_l1_ update the l1l11ll11ll1_l1_ menu
		#results = l1l1ll1l1ll1_l1_(type,l1l11111lll_l1_,l1l111ll1l1_l1_,mode,l1l11l111ll_l1_,l11lll11111_l1_,text,context,l1ll1ll1l1l_l1_)
		# l1l11l1ll1l1_l1_ update the l1ll1l1ll1l1_l1_ menu
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㚷"),l11ll1_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ㚸"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㚹"))
		return
	if settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㚺")) not in [l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㚻"),l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ㚼"),l11ll1_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㚽")]: settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㚾"),l11ll1_l1_ (u"ࠨࡃࡘࡘࡔ࠭㚿"))
	if not settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㛀")): settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ㛁"),l1llll1ll1ll_l1_[0])
	l1lll1l1l11l_l1_ = l1llll11111l_l1_(settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㛂")))
	l1lll1l1l11l_l1_ = 0 if not l1lll1l1l11l_l1_ else int(l1lll1l1l11l_l1_)
	if not l1lll1l1l11l_l1_ or now-l1lll1l1l11l_l1_<=0 or now-l1lll1l1l11l_l1_>l1ll1lll1_l1_:
		l11l1ll1l11_l1_ = l111l11ll11_l1_(True,False)
	l11l1llllll_l1_ = l1llll11111l_l1_(settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪࠧ㛃")))
	l11l1llllll_l1_ = 0 if not l11l1llllll_l1_ else int(l11l1llllll_l1_)
	l111ll11lll_l1_ = l1llll11111l_l1_(settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷ࠳ࡲࡡࡴࡶࡷ࡭ࡲ࡫ࠧ㛄")))
	l111ll11lll_l1_ = 0 if not l111ll11lll_l1_ else int(l111ll11lll_l1_)
	if not l11l1llllll_l1_ or not l111ll11lll_l1_ or now-l111ll11lll_l1_<0 or now-l111ll11lll_l1_>l11l1llllll_l1_:
		auth = 1
		if not l11llll1111_l1_(l11ll1_l1_ (u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ㛅")):
			# https://www.l1llll1l1l1l_l1_.com/l1l1l1lll11l_l1_/l1111lll11l_l1_
			# unescapeHTML(l11ll1_l1_ (u"ࠨࠢࠩࠧࡽ࠸࠶࠴ࡄ࠾ࠤࠫࠩࡸ࠳࠹࠴ࡈࡀࠦࠦࠤࡺ࠵࠺࠷ࡇ࠻ࠡࠨࠦࡼ࠷࠼࠳ࡃ࠽ࠪ㛆"))
			#l1ll1ll11l11_l1_ = l11ll1_l1_ (u"ࠩ⸾ࠤ⼢ࠦࠠ⾋ࠢࠣ⸮ࠥ⹁ࠧ㛇")
			#l1ll1ll111ll_l1_ = l11ll1_l1_ (u"ࠪ⸿ࠥ⼣ࠠࠡ⾍ࠣࠤⸯࠦ⸻ࠨ㛈")
			l1l1ll1l1l1l_l1_ = l11l1lll1ll_l1_(True)
			if len(l1l1ll1l1l1l_l1_)>1:
				LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㛉"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ㛊")+addon_path+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㛋"))
				id,l1l11l1l111l_l1_,l1l11lll1lll_l1_,l111l1l11ll_l1_,l111l11l1l1_l1_,reason = l1l1ll1l1l1l_l1_[0]
				#if l11ll1_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㛌") in reason: l1ll11l11lll_l1_,l1ll11l1l111_l1_,l1ll11l1l11l_l1_ = reason.split(l11ll1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㛍"),2)
				#else: l1ll11l11lll_l1_,l1ll11l1l111_l1_,l1ll11l1l11l_l1_ = reason,reason,reason
				l1lllll1111l_l1_,l1lllll111l1_l1_ = l111l1l11ll_l1_.split(l11ll1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㛎"))
				del l1l1ll1l1l1l_l1_[0]
				l1ll11111l1l_l1_ = random.sample(l1l1ll1l1l1l_l1_,1)
				id,l1l11l1l111l_l1_,l1l11lll1lll_l1_,l111l1l11ll_l1_,l111l11l1l1_l1_,reason = l1ll11111l1l_l1_[0]
				l1l11lll1lll_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ࠿ࠦࠧ㛏")+id+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㛐")+l1l11lll1lll_l1_
				l111l11l1l1_l1_ = l11ll1_l1_ (u"ࠬษัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ㛑")
				l111111l111_l1_,l1l1ll11111l_l1_ = l111l1l11ll_l1_,l111l11l1l1_l1_
				l11l11l1_l1_ = [l111111l111_l1_,l1l1ll11111l_l1_,l1lll1l1l1ll_l1_]
				choice = -9
				while choice<0:
					l111ll1lll1_l1_ = random.sample(l11l11l1_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ㛒"),l111ll1lll1_l1_[0],l111ll1lll1_l1_[1],l111ll1lll1_l1_[2],l1lllll1111l_l1_,l1l11lll1lll_l1_,l11ll1_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㛓"),10,60)
					if choice==10: break
					if choice>=0 and l111ll1lll1_l1_[choice]==l11l11l1_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ㛔"),l11ll1_l1_ (u"ࠩࠪ㛕"),l11ll1_l1_ (u"ࠪ฽ํีษࠨ㛖"),l11ll1_l1_ (u"ࠫࠬ㛗"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㛘"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ㛙")+reason,l11ll1_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㛚"),20)
						import l1l1111lll1_l1_
						l1l1111lll1_l1_.l1ll111ll111_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l111ll1lll1_l1_[choice]==l11l11l1_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࠩ㛛"),l11ll1_l1_ (u"ࠩࠪ㛜"),l1lll1l1l1ll_l1_,l11ll1_l1_ (u"ࠪࠫ㛝"),l1lllll1111l_l1_,l1l11lll1lll_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㛞")+l11l11l1_l1_[0]+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㛟"),l11ll1_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㛠"),30)
					if choice==-1: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㛡"),l11ll1_l1_ (u"ࠨࠩ㛢"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㛣"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็่ำื่อࠢสฺ่ำ๊ฮࠢฦาฯื้ࠠษะำ๋ࠥๆࠡษ็วั๎ศสࠢส่๊ะ่โำฬࠫ㛤"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡵ࡫ࡰࡩࠬ㛥"),l1ll111ll1ll_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㛦"),l11ll1_l1_ (u"࠭ࡁࡖࡖࡋࠫ㛧"),auth,PERMANENT_CACHE)
	# l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㛨")	l111llll1ll_l1_ file to read/write the l1l1ll1l1111_l1_ menu list
	# l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㛩")		no l11ll1l11ll_l1_ l1l1l1l1l1ll_l1_ to the l1l1ll1l1111_l1_ menu list
	l11ll1_l1_ (u"ࠤࠥࠦࠒࠐࠉࡔࡋࡗࡉࡘࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡋࡗࡉࡘࡥࡍࡐࡆࡈࡗࠥࡧ࡮ࡥࠢࡰࡳࡩ࡫࠱࠾࠿࠼ࠑࠏࠏࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠺࠲࠵࠲࠸࠯࠹࠷࠹࡝ࠎࠌࠌࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡏࡔࡆࡕࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠐࠎࠎࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠶ࡂࡃ࠱࠷ࠢࡤࡲࡩࠦ࡭ࡰࡦࡨ࠴ࠦࡃ࠱࠷࠲ࠐࠎࠎ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠺࡝ࠎࠌࠌࠧࡳࡧ࡭ࡦࡡࠣࡁࠥࡉࡌࡆࡃࡑࡣࡒࡋࡎࡖࡡࡏࡅࡇࡋࡌࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡲࡦࡳࡥࡠࠢࡀࠤࡗࡋࡓࡕࡑࡕࡉࡤࡖࡁࡕࡊࡢࡒࡆࡓࡅࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࡯ࡳࠢࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠑࠏࠏࡩࡧࠢࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖ࠾ࠒࠐࠉࠊࠥ࡬ࡪࠥࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖ࠾ࠥࡩ࡯࡯ࡦ࠴ࠤࡂࠦࠨ࡮ࡧࡱࡹࡤࡲࡡࡣࡧ࡯ࠤ࡮ࡴࠠ࡜ࠩ࠱࠲ࠬ࠲ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪࡡ࠮ࠓࠊࠊࠋࠦࡩࡱ࡯ࡦࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙࠺ࠡࡥࡲࡲࡩ࠷ࠠ࠾ࠢࠫࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠩࠎࠌࠌࠍ࡮࡬ࠠࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࠦࡩ࡯ࠢࡷࡩࡽࡺࠠࡢࡰࡧࠤࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠡࡣࡱࡨࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠮ࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࠦࡒࡦࡣࡧ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡱ࡯ࡨࡋࡏࡌࡆࠢࡀࠤࡴࡶࡥ࡯ࠪ࡯ࡥࡸࡺ࡭ࡦࡰࡸࡪ࡮ࡲࡥ࠭ࠩࡵࡦࠬ࠯࠮ࡳࡧࡤࡨ࠭࠯ࠍࠋࠋࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦ࡯࡭ࡦࡉࡍࡑࡋࠠ࠾ࠢࡲࡰࡩࡌࡉࡍࡇ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠑࠏࠏࠉࠊ࡯ࡨࡲࡺࡏࡴࡦ࡯ࡶࡐࡎ࡙ࡔ࡜࠼ࡠࠤࡂࠦࡅࡗࡃࡏࠬࠬࡲࡩࡴࡶࠪ࠰ࡴࡲࡤࡇࡋࡏࡉ࠮ࠓࠊࠊࠋࡨࡰࡸ࡫࠺ࠎࠌࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠲ࠥࠦࠠࡘࡴ࡬ࡸ࡮ࡴࡧࠡ࡮ࡤࡷࡹࠦ࡭ࡦࡰࡸࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ࠭ࡤࡨࡩࡵ࡮ࡠࡲࡤࡸ࡭࠱ࠧࠡ࡟ࠪ࠭ࠒࠐࠉࠊࠋࡵࡩࡸࡻ࡬ࡵࡵࠣࡁࠥࡓࡁࡊࡐࡢࡈࡎ࡙ࡐࡂࡖࡆࡌࡊࡘࠨࡵࡻࡳࡩ࠱ࡴࡡ࡮ࡧࡢ࠰ࡺࡸ࡬ࡠ࠮ࡰࡳࡩ࡫ࠬࡪ࡯ࡤ࡫ࡪࡥࠬࡱࡣࡪࡩࡤ࠲ࡴࡦࡺࡷ࠰ࡨࡵ࡮ࡵࡧࡻࡸ࠱࡯࡮ࡧࡱࡧ࡭ࡨࡺࠩࠎࠌࠌࠍࠎࡴࡥࡸࡈࡌࡐࡊࠦ࠽ࠡࡵࡷࡶ࠭ࡳࡥ࡯ࡷࡌࡸࡪࡳࡳࡍࡋࡖࡘ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡴࡥࡸࡈࡌࡐࡊࠦ࠽ࠡࡰࡨࡻࡋࡏࡌࡆ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉࡰࡲࡨࡲ࠭ࡲࡡࡴࡶࡰࡩࡳࡻࡦࡪ࡮ࡨ࠰ࠬࡽࡢࠨࠫ࠱ࡻࡷ࡯ࡴࡦࠪࡱࡩࡼࡌࡉࡍࡇࠬࠑࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡸࡥࡴࡷ࡯ࡸࡸࠦ࠽ࠡࡏࡄࡍࡓࡥࡄࡊࡕࡓࡅ࡙ࡉࡈࡆࡔࠫࡸࡾࡶࡥ࠭ࡰࡤࡱࡪࡥࠬࡶࡴ࡯ࡣ࠱ࡳ࡯ࡥࡧ࠯࡭ࡲࡧࡧࡦࡡ࠯ࡴࡦ࡭ࡥࡠ࠮ࡷࡩࡽࡺࠬࡤࡱࡱࡸࡪࡾࡴ࠭࡫ࡱࡪࡴࡪࡩࡤࡶࠬࠑࠏࠏࠢࠣࠤ㛪")
	results = l1l1ll1l1ll1_l1_(type,l1l11111lll_l1_,l1l111ll1l1_l1_,mode,l1l11l111ll_l1_,l11lll11111_l1_,text,context,l1ll1ll1l1l_l1_)
	# l11l1lll111_l1_ l1l11l11l1ll_l1_: succeeded,l1llllll111l_l1_,l11l11lllll_l1_ = True,False,True
	# l1llllll111l_l1_ = True => l1lll111l1ll_l1_ this list is l1l1llll1l1l_l1_ and will exit to main menu
	# l1llllll111l_l1_ = False => l1lll111l1ll_l1_ this list is l1111l1ll1l_l1_ and will exit to l1l1ll1l1111_l1_ menu
	# l11l11lllll_l1_ = True => will cause the l1l11l1ll111_l1_ status to l1l11l1lllll_l1_ l1ll11111lll_l1_
	# l11l11lllll_l1_ = False => will l1l1llllllll_l1_ the l1l11l1ll111_l1_ status to l1111l1111l_l1_ l111111llll_l1_
	#succeeded,l1llllll111l_l1_,l11l11lllll_l1_ = True,False,True
	#if not l11ll1l1l11_l1_: l11l11lllll_l1_ = False
	if l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㛫") in text: l1llllll111l_l1_ = True
	if type==l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㛬"):
		if l11l1llll1_l1_!=l11ll1_l1_ (u"ࠬ࠴࠮ࠨ㛭") and l1lll11ll111_l1_: l1l11l111l1_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ㛮"),l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㛯"),l11ll1_l1_ (u"ࠨࡃࡘࡘࡍ࠭㛰")) or l1ll111111ll_l1_ not in l1llll111ll1_l1_) and not l11llll1111_l1_(l11ll1_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㛱")):
				import l1l1l11l1lll_l1_
				l1lll111lll1_l1_ = GET_ALL_LIST_ITEMS(l1l1l11l1lll_l1_.l1lll111l11l_l1_)
				l111lll11ll_l1_ = CREATE_KODI_MENU(l1l1l11111l1_l1_,l1lll111lll1_l1_,succeeded,l1llllll111l_l1_,l11l11lllll_l1_)
				if 1 and l1lll111lll1_l1_ and l1ll11ll1111_l1_:
					WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㛲")+trans_provider+l11ll1_l1_ (u"ࠫࡤ࠭㛳")+trans_code,l1l1l11111l1_l1_,l1lll111lll1_l1_,REGULAR_CACHE)
				#elif 1 and not l1lll111lll1_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㛴")+trans_provider+l11ll1_l1_ (u"࠭࡟ࠨ㛵")+trans_code,l1l1l11111l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㛶")+addon_id+l11ll1_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ㛷"),xbmcgui.ListItem(l11ll1_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦๅ็ࠢฯ๋ฬุใࠨ㛸")))
				xbmcplugin.addDirectoryItem(addon_handle,l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㛹")+addon_id+l11ll1_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㛺"),xbmcgui.ListItem(l11ll1_l1_ (u"ࠬษแหฯ่ࠣฯ่ัฤࠢส่ฯ็วึ์็ࠫ㛻")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llllll111l_l1_,l11l11lllll_l1_)
	return
def l1l1ll1l1ll1_l1_(type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_):
	l1ll111111ll_l1_ = int(mode)
	l1ll11111l11_l1_ = int(l1ll111111ll_l1_//10)
	if   l1ll11111l11_l1_==0:  import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==1:  import l111l111_l1_ 		; results = l111l111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==2:  import l1l1lll1ll1_l1_ 		; results = l1l1lll1ll1_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==3:  import l111l1ll1l1_l1_ 		; results = l111l1ll1l1_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==4:  import l1l1l1l1l_l1_ 	; results = l1l1l1l1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==5:  import l11l1llll1l_l1_ 	; results = l11l1llll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==6:  import l1ll11l11_l1_ 	; results = l1ll11l11_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==7:  import l11llll_l1_ 		; results = l11llll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==8:  import l1l1lll1lll_l1_ 	; results = l1l1lll1lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==9:  import l1ll1ll1ll_l1_		; results = l1ll1ll1ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==10: import l1lll11l11ll_l1_ 		; results = l1lll11l11ll_l1_.MAIN(l1ll111111ll_l1_,url)
	elif l1ll11111l11_l1_==11: import l1l1ll11l111_l1_ 	; results = l1l1ll11l111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==12: import l11111ll11_l1_ 		; results = l11111ll11_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==13: import l1l1l1ll1_l1_	; results = l1l1l1ll1_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==14: import l11l1l1lll1_l1_ 		; results = l11l1l1lll1_l1_.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_,name,l111_l1_)
	elif l1ll11111l11_l1_==15: import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==16: import l1l1l1ll111l_l1_	 	; results = l1l1l1ll111l_l1_.MAIN(l1ll111111ll_l1_,url,text,l1l1111_l1_,l1ll1ll1l1l_l1_)
	elif l1ll11111l11_l1_==17: import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==18: import l1l11ll11l11_l1_	; results = l1l11ll11l11_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==19: import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==20: import l111ll1ll_l1_		; results = l111ll1ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==21: import l1111lll1ll_l1_ ; results = l1111lll1ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==22: import l1llll11ll1_l1_ 	; results = l1llll11ll1_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==23: import IPTV 		; results = IPTV.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l1l_l1_)
	elif l1ll11111l11_l1_==24: import l1lllll1_l1_ 		; results = l1lllll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==25: import l11l11ll1_l1_ 	; results = l11l11ll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==26: import l1l1l11l1lll_l1_ 		; results = l1l1l11l1lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1ll111111ll_l1_,context)
	elif l1ll11111l11_l1_==28: import IPTV 		; results = IPTV.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l1l_l1_)
	elif l1ll11111l11_l1_==29: import l11l11l11l1_l1_	; results = l11l11l11l1_l1_.MAIN(l1ll111111ll_l1_,url,l1l1111_l1_,text)
	elif l1ll11111l11_l1_==30: import l1ll1l1ll1_l1_		; results = l1ll1l1ll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==31: import l111ll11111_l1_	; results = l111ll11111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==32: import l1l1l1lll1l_l1_	; results = l1l1l1lll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==33: import l11l111ll1_l1_		; results = l11l111ll1_l1_.MAIN(l1ll111111ll_l1_,url)
	elif l1ll11111l11_l1_==34: import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==35: import l1l11ll1_l1_		; results = l1l11ll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==36: import l1ll11llllll_l1_		; results = l1ll11llllll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==37: import l11111lll_l1_		; results = l11111lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==38: import l1l1llllll11_l1_ 		; results = l1l1llllll11_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==39: import l1ll1l1l1ll_l1_	; results = l1ll1l1l1ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==40: import l11lll1ll1_l1_	; results = l11lll1ll1_l1_.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_)
	elif l1ll11111l11_l1_==41: import l11lll1ll1_l1_	; results = l11lll1ll1_l1_.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_)
	elif l1ll11111l11_l1_==42: import l1llllll1l_l1_		; results = l1llllll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==43: import l1lll1lll1l_l1_		; results = l1lll1lll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==44: import l1lll1llll1_l1_		; results = l1lll1llll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==45: import l11ll11ll1l_l1_		; results = l11ll11ll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==46: import l1llll11l11l_l1_		; results = l1llll11l11l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==47: import l1ll1l1lll_l1_	; results = l1ll1l1lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==48: import l1l1l11lllll_l1_		; results = l1l1l11lllll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==49: import l1lll111ll_l1_		; results = l1lll111ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==50: import l1l1111lll1_l1_ 	; results = l1l1111lll1_l1_.MAIN(l1ll111111ll_l1_,text)
	elif l1ll11111l11_l1_==51: import l1lll11ll1l_l1_ 	; results = l1lll11ll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==52: import l1lll11ll1l_l1_ 	; results = l1lll11ll1l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==53: import l1l1l11l1lll_l1_ 		; results = l1l1l11l1lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==54: import l1lll11lll1_l1_	; results = l1lll11lll1_l1_.MAIN(l1ll111111ll_l1_,url,text,l1l1111_l1_)
	elif l1ll11111l11_l1_==55: import l1lll11ll1_l1_ 	; results = l1lll11ll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==56: import l1l1ll11llll_l1_		; results = l1l1ll11llll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==57: import l1ll1l1l11l_l1_		; results = l1ll1l1l11l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==58: import l11l1l111l1_l1_	; results = l11l1l111l1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==59: import l1ll1l111l1_l1_		; results = l1ll1l111l1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==60: import l1ll1l11111_l1_		; results = l1ll1l11111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==61: import l1ll11l_l1_		; results = l1ll11l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==62: import l1ll1l1llll_l1_		; results = l1ll1l1llll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==63: import l1lll11l11_l1_		; results = l1lll11l11_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==64: import l1llllll1111_l1_		; results = l1llllll1111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==65: import l11111111_l1_		; results = l11111111_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==66: import l11l1ll11ll_l1_		; results = l11l1ll11ll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==67: import l1l1l1l1lll_l1_		; results = l1l1l1l1lll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==68: import l111lll11l_l1_		; results = l111lll11l_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==69: import l1llllllll_l1_		; results = l1llllllll_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==70: import l1l1l111ll1_l1_		; results = l1l1l111ll1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==71: import l1l1l111ll1l_l1_			; results = l1l1l111ll1l_l1_.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l1l_l1_)
	elif l1ll11111l11_l1_==72: import l1l1l111ll1l_l1_			; results = l1l1l111ll1l_l1_.MAIN(l1ll111111ll_l1_,url,text,type,l1l1111_l1_,l1ll1ll1l1l_l1_)
	elif l1ll11111l11_l1_==73: import l1l11l1l1_l1_	; results = l1l11l1l1_l1_.MAIN(l1ll111111ll_l1_,url,text)
	elif l1ll11111l11_l1_==74: import l1l1ll1111_l1_		; results = l1l1ll1111_l1_.MAIN(l1ll111111ll_l1_)
	elif l1ll11111l11_l1_==75: import l1l1ll1111_l1_		; results = l1l1ll1111_l1_.MAIN(l1ll111111ll_l1_)
	else: results = None
	return results
def l11l1l1lll_l1_(name=l11ll1_l1_ (u"࠭ࠧ㛼")):
	if not name: name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ㛽"))
	name = name.replace(l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㛾"),l11ll1_l1_ (u"ࠩࠪ㛿"))
	name = name.replace(l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠨ㜀"),l11ll1_l1_ (u"ࠫࠥ࠭㜁")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㜂"),l11ll1_l1_ (u"࠭ࠠࠨ㜃")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ㜄"),l11ll1_l1_ (u"ࠨࠢࠪ㜅")).strip(l11ll1_l1_ (u"ࠩࠣࠫ㜆"))
	name = name.replace(l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㜇"),l11ll1_l1_ (u"ࠫࠬ㜈")).replace(l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㜉"),l11ll1_l1_ (u"࠭ࠧ㜊"))
	tmp = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࠫ㜋"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11ll1_l1_ (u"ࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫ㜌")
	return name
def l1lll111l1l1_l1_(code,reason,source,l1ll_l1_):
	l1lll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㜍"))
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㜎"),l11ll1_l1_ (u"ࠫࠬ㜏"))
	if l11ll1_l1_ (u"ࠬ࠳ࠧ㜐") in source: l1ll111l11l_l1_ = source.split(l11ll1_l1_ (u"࠭࠭ࠨ㜑"),1)[0]
	else: l1ll111l11l_l1_ = source
	l111lll1l11_l1_ = code in [7,11001,11002,10054]
	l1l11l1llll1_l1_ = reason.lower()
	l1ll1llll11l_l1_ = code in [0,104,10061,111]
	l1ll1llll111_l1_ = l11ll1_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㜒") in l1l11l1llll1_l1_
	l1ll1lll1lll_l1_ = l11ll1_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㜓") in l1l11l1llll1_l1_
	l1ll1lll1ll1_l1_ = l11ll1_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㜔") in l1l11l1llll1_l1_
	l1ll1lll1l1l_l1_ = l11ll1_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㜕") in l1l11l1llll1_l1_
	l1l1ll111111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㜖"))
	l1l1l11l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㜗"))
	l1llll1l111l_l1_ = l11ll1_l1_ (u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ㜘")
	l1lll1llllll_l1_ = l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠧ㜙")+str(code)+l11ll1_l1_ (u"ࠨ࠼ࠣࠫ㜚")+reason
	l1lll1llllll_l1_ = l1111_l1_(l1lll1llllll_l1_)
	if l1ll1llll11l_l1_ or l1ll1llll111_l1_ or l1ll1lll1lll_l1_ or l1ll1lll1ll1_l1_ or l1ll1lll1l1l_l1_:
		l1llll1l111l_l1_ += l11ll1_l1_ (u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ㜛")
	if l111lll1l11_l1_: l1llll1l111l_l1_ += l11ll1_l1_ (u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ㜜")
	l1lll1llllll_l1_ = l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㜝")+l1lll1llllll_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㜞")
	if l1l1ll111111_l1_==l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ㜟") or l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ㜠"):
		l1llll1l111l_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜡")
	l11l1lll11l_l1_ = False
	if l1ll_l1_ and source not in l1111ll1111_l1_:
		if l1l1ll111111_l1_==l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㜢") or l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㜣"):
			#if kodi_version<19: l1lll1llllll_l1_ = l1lll1llllll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㜤"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㜥"),l11ll1_l1_ (u"࠭ฮา๊ฯࠫ㜦"),l11ll1_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ㜧"),l11ll1_l1_ (u"ࠨวุ่ฬำࠠศๆุ่่๊ษࠨ㜨"),l1ll111l11l_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭㜩")+TRANSLATE(l1ll111l11l_l1_),l1llll1l111l_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭㜪")+l1lll1llllll_l1_)
			if choice==1:
				import l1l1111lll1_l1_
				l1l1111lll1_l1_.l1ll111ll111_l1_()
			elif choice==2: l11l1lll11l_l1_ = True
		else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㜫"),l11ll1_l1_ (u"ࠬ࠭㜬"),l1ll111l11l_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㜭")+TRANSLATE(l1ll111l11l_l1_),l1llll1l111l_l1_,l1lll1llllll_l1_)
	#if reason.endswith(l11ll1_l1_ (u"ࠧࠡࠫࠪ㜮")): reason = reason.rsplit(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㜯"))[0]
	#if l11l1lll11l_l1_: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㜰"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㜱")+str(code)+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㜲")+reason+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㜳")+source+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡆࡘࡁࡃࡋࡆ࠾ࠥࡡࠠࠨ㜴")+l1llll1l111l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࡠࠤࠥࠦࡅࡏࡉࡏࡍࡘࡎ࠺ࠡ࡝ࠣࠫ㜵")+l1lll1llllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ㜶"))
	settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㜷"),l1lll1lll11l_l1_)
	return l11l1lll11l_l1_
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡩࡴࡳࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠶ࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠵ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠴࠼ࠐࠎࠎࠏࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠ࠾๊ࠢࠪํ฿ࠠๆ่ࠣห้ำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่࠴ࠧࠎࠌࠌࠍ࡮࡬ࠠࡴࡪࡲࡻࡉ࡯ࡡ࡭ࡱࡪࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠࠬ࠿ࠣࠫࠥํไࠡฬิ๎ิࠦสโษุ๎้ࠦวไอิࠤฤ࠭ࠍࠋࠋࠌ࡭࡫ࠦࡤ࡯ࡵ࠽ࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿้ࠣࠫี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤ࠰ࡃࠠࠨ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡨࡰࡸ࡫࠺ࠡ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿ࠣࠫ์ึวࠡษ็้ํู่ࠡใํ๋ࠥ࠭ࠫࡣ࡮ࡲࡧࡰࡥ࡭ࡦࡧࡶࡷࡦ࡭ࡥࠎࠌࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧࠬࡵࡲࡹࡷࡩࡥࠬࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ࠮ࡷࡹࡸࠨࡤࡱࡧࡩ࠮࠱ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ࠮ࡶࡪࡧࡳࡰࡰ࠮ࠫࠥࡣࠠࠡࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠼ࠣ࡟ࠥ࠭ࠫ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠫࠨࠢࡠࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠻ࠢ࡞ࠤࠬ࠱࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎࠫࠨࠢࡠࠫ࠮ࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠑࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸࠧ࠭ࡵ࡬ࡸࡪ࠱ࠧࠡࠢࠣࠫ࠰࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅࠩࡵ࡬ࡸࡪ࠯ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠳࠽ࠤ࡮ࡳࡰࡰࡴࡷࠤࡘࡋࡒࡗࡋࡆࡉࡘࠦ࠻ࠡࡕࡈࡖ࡛ࡏࡃࡆࡕ࠱ࡑࡆࡏࡎࠩ࠳࠼࠹࠮ࠓࠊࠊࡧ࡯࡭࡫ࠦࡳࡩࡱࡺࡈ࡮ࡧ࡬ࡰࡩࡶ࠾ࠒࠐࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳ࠢࡀࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠯ࠬࠦ࠮้ࠡ็ࠤฯื๊ะ่ࠢ฽ึ็ษࠡษ็วุฮวษ๋ࠢห้ำไ้ๆࠣรࠬࠓࠊࠊࠋࡼࡩࡸࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠ࡛ࡈࡗࡓࡕࠨࠨࡥࡨࡲࡹ࡫ࡲࠨ࠮ࡶ࡭ࡹ࡫ࠫࠨࠢࠣࠤࠬ࠱ࡔࡓࡃࡑࡗࡑࡇࡔࡆࠪࡶ࡭ࡹ࡫ࠩ࠭࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳࠮ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠯ࠫࠬ࠲ࠧไๆสࠫ࠱࠭ๆฺ็ࠪ࠭ࠒࠐࠉࠊ࡫ࡩࠤࡾ࡫ࡳ࠾࠿࠴࠾ࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣࡁࠥ࠭โะࠢํ็ํ์่่ࠠส็ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฾์ฯไࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦๅโื๋่ฮ࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้ืศุࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ื่ࠠา๊ࠤฬ๊ีโฯฬࠤํอไๆสิ้ัࠦไศࠢํ฽้๋ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳࡢ࡮ࠨ࠭ࠪะึฮࠠๆีะࠤฬ๊ใศึ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥาัษฺࠢี็ࠦัโ฻ࠣห้ำฬษ้ࠢࠫะ๊วࠡࡘࡓࡒࠥ࠲ࠠࡑࡴࡲࡼࡾࠦࠬࠡࡆࡑࡗ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠๆหࠤ์ึวࠡษ็้ํู่ࠡๆสั็อࠧࠎࠌࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤ࡚ࡅ࡙ࡖ࡙ࡍࡊ࡝ࡅࡓࠪࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ࠲࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠩࠎࠌࠌࠦࠧࠨ㜸")
def l11l11111l1_l1_(l1l1l11l11ll_l1_=False):
	l1llll1l1lll_l1_ = [l1l111l11ll_l1_,favoritesfile,l1l11l1l1l11_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l1l11l11ll_l1_ and (filename.startswith(l11ll1_l1_ (u"ࠫ࡮ࡶࡴࡷࠩ㜹")) or filename.startswith(l11ll1_l1_ (u"ࠬࡳ࠳ࡶࠩ㜺"))): continue
		if filename.startswith(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬ㜻")): continue
		l1lll11l111l_l1_ = os.path.join(addoncachefolder,filename)
		if l1lll11l111l_l1_ in l1llll1l1lll_l1_: continue
		try: os.remove(l1lll11l111l_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll1l11ll1l_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l11lll11_l1_=True,l1ll11l111ll_l1_=True):
	l1l1ll11l1l1_l1_,l1ll1l11llll_l1_ = proxy.split(l11ll1_l1_ (u"ࠧ࠻ࠩ㜼"))
	#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨ็ื็้ฯࠠฦ่อี๋๐สࠡ࠰ࠣืศำว้ๆࠣษฺ๊วฮ้สࠫ㜽"),l11ll1_l1_ (u"ࠩึวัืศࠡࠩ㜾")+name,time=2000)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㜿"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭ࠠࠨ㝀")+name+l11ll1_l1_ (u"ࠬࠦࡳࡦࡴࡹࡩࡷࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㝁")+proxy+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㝂")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㝃"))
	url = url+l11ll1_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㝄")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l11lll11_l1_,l1ll11l111ll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㝅"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࠧ㝆")+name+l11ll1_l1_ (u"ࠫࠥࡹࡥࡳࡸࡨࡶࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ㝇")+proxy+l11ll1_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㝈")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㝉"))
		l1llll111l11_l1_(l11ll1_l1_ (u"ࠧࡉࡖࡗࡔࠥࡘࡥࡲࡷࡨࡷࡹࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧ㝊"))
	#else: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㝋"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㝌")+proxy+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㝍")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㝎"))
	return response
def l1l1l11ll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㝏"),url,l11ll1_l1_ (u"࠭ࠧ㝐"),l11ll1_l1_ (u"ࠧࠨ㝑"),True,l11ll1_l1_ (u"ࠨࠩ㝒"),l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㝓"),True,False)
	l111111l1l1_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l1l1l11l111l_l1_
		l1ll111ll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭㝔"),html)
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㝕"),str(l1ll111ll11l_l1_))
		if l1ll111ll11l_l1_: html = l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㝖").join(l1ll111ll11l_l1_)
		proxies = html.replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ㝗"),l11ll1_l1_ (u"ࠧࠨ㝘")).strip(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㝙")).split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㝚"))
		l111111l1l1_l1_ = []
		for proxy in proxies:
			if proxy.count(l11ll1_l1_ (u"ࠪ࠲ࠬ㝛"))==3: l111111l1l1_l1_.append(proxy)
	return l111111l1l1_l1_
def l11l11lll1l_l1_(*args):
	#l1ll11l1l1ll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠹࠻࠮࠴࠵࠱࠵࠼࠴࠱࠳࠹࠲ࡥࡵ࡯࠯ࡱࡴࡲࡼࡾࡅࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡶࡴࡪ࡫ࡤ࠾࠳࠳ࠪࡱࡧࡳࡵࡡࡦ࡬ࡪࡩ࡫࠾࠳࠳ࠪ࡭ࡺࡴࡱࡵࡀࡸࡷࡻࡥࠧࡲࡲࡷࡹࡃࡴࡳࡷࡨࠪ࡫ࡵࡲ࡮ࡣࡷࡁࡹࡾࡴࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ㝜")
	l11ll111111_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭㝝")
	l1ll1lllllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪ㝞")
	#l111111l1ll_l1_ = l1l1l11ll111_l1_(l1ll11l1l1ll_l1_)
	l111111l1ll_l1_ = l1l1l11ll111_l1_(l1ll1lllllll_l1_)
	l111111l1l1_l1_ = l1l1l11ll111_l1_(l11ll111111_l1_)
	l11ll11lll1_l1_ = l111111l1ll_l1_+l111111l1l1_l1_
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㝟"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧ㝠")+str(len(l111111l1ll_l1_))+l11ll1_l1_ (u"ࠩ࠮ࠫ㝡")+str(len(l111111l1l1_l1_))+l11ll1_l1_ (u"ࠪࠤࡢ࠭㝢"))
	proxy = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㝣"))
	response = l1l11llll11_l1_()
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ㝤"),l11ll1_l1_ (u"࠭ࠧ㝥"))
	if proxy or l11ll11lll1_l1_:
		id,timeout = 0,10
		l1l1l1l1llll_l1_ = len(l11ll11lll1_l1_)
		l1111lll111_l1_ = timeout
		if l1l1l1l1llll_l1_>l1111lll111_l1_: counts = l1111lll111_l1_
		else: counts = l1l1l1l1llll_l1_
		l111ll1ll1l_l1_ = random.sample(l11ll11lll1_l1_,counts)
		if proxy: l111ll1ll1l_l1_ = [proxy]+l111ll1ll1l_l1_
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ㝦"),str(l111ll1ll1l_l1_))
		threads = l111l1l1ll1_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l111ll1l11l_l1_:
			if id<counts:
				proxy = l111ll1ll1l_l1_[id]
				threads.start_new_thread(id,l1ll1l11ll1l_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㝧"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㝨")+proxy+l11ll1_l1_ (u"ࠪࠤࡢ࠭㝩"))
		l111ll1l11l_l1_ = threads.l111ll1l11l_l1_
		if l111ll1l11l_l1_:
			l1lll11l11l1_l1_ = threads.l1lll11l11l1_l1_
			l1lll1llll1l_l1_ = l111ll1l11l_l1_[0]
			response = l1lll11l11l1_l1_[l1lll1llll1l_l1_]
			proxy = l111ll1ll1l_l1_[int(l1lll1llll1l_l1_)]
			settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㝪"),proxy)
			if l1lll1llll1l_l1_!=0: LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㝫"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㝬")+proxy+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㝭"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㝮"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㝯")+proxy+l11ll1_l1_ (u"ࠪࠤࡢ࠭㝰"))
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㝱"),l11ll1_l1_ (u"ࠬࡶࡲࡰࡺ࡬ࡩࡸࡒࡉࡔࡖ࠵ࠤ࠿ࡀࠠࠨ㝲")+str(l111ll1ll1l_l1_))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㝳"),l11ll1_l1_ (u"ࠧࡱࡴࡲࡼ࡮࡫ࡳࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ㝴")+str(l11ll11lll1_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㝵"),l11ll1_l1_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㝶")+str(threads.l111ll1l11l_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㝷"),l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㝸")+str(threads.l11ll1ll111_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㝹"),l11ll1_l1_ (u"࠭ࡲࡦࡵࡸࡰࡹࡹࡄࡊࡅࡗࠤ࠿ࡀࠠࠨ㝺")+str(threads.l1lll11l11l1_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㝻"),l11ll1_l1_ (u"ࠨࡧ࡯ࡴࡦࡹࡥࡥࡶ࡬ࡱࡪࡊࡉࡄࡖࠣ࠾࠿ࠦࠧ㝼")+str(threads.l11l1lllll1_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㝽"),l11ll1_l1_ (u"ࠪࡷࡴࡸࡴࡦࡦࡏࡍࡘ࡚ࠠ࠻࠼ࠣࠫ㝾")+str(l1llll11llll_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㝿"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㞀")+l1l1l1l11lll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㞁")+str(l1llll11llll_l1_))
	return response
def l1l11lllll1l_l1_(connection,l1l11ll1l11l_l1_):
	l111l11ll1l_l1_ = connection.create_connection
	def l1l1ll1ll1l1_l1_(address,*args,**kwargs):
		host,port = address
		l1ll1111lll1_l1_ = DNS_RESOLVER(host,l1l11ll1l11l_l1_)
		if l1ll1111lll1_l1_: host = l1ll1111lll1_l1_[0]
		else:
			if l1l11ll1l11l_l1_ in l1llll1ll1ll_l1_: l1llll1ll1ll_l1_.remove(l1l11ll1l11l_l1_)
			if l1llll1ll1ll_l1_:
				l1ll1111ll11_l1_ = l1llll1ll1ll_l1_[0]
				#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㞂"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࡛ࠡࠢࠣ࡮ࡲ࡬ࠡࡶࡵࡽࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡆࡑࡗ࠿ࡡࠠࠨ㞃")+l1ll1111ll11_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡱࡶࡸ࠿ࡡࠠࠨ㞄")+str(host)+l11ll1_l1_ (u"ࠪࠤࡢ࠭㞅"))
				l1ll1111lll1_l1_ = DNS_RESOLVER(host,l1ll1111ll11_l1_)
				if l1ll1111lll1_l1_: host = l1ll1111lll1_l1_[0]
		address = (host,port)
		return l111l11ll1l_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1ll1ll1l1_l1_
	return l111l11ll1l_l1_
def l1ll1l11ll_l1_(l1l111lllll_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ㞆"),l11ll1_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭㞇"),(method,url,data,headers))
	if html:
		l1l11l1111l_l1_(True,url,data,headers,source,l11ll1_l1_ (u"࠭ࠧ㞈"))
		return html
	html = l1llll1lll_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ㞉"),(method,url,data,headers),html,l1l111lllll_l1_)
	return html
def l1l11ll111l1_l1_(url):
	l111lllll1l_l1_,l1llllllll1l_l1_ = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ㞊"))[2],80
	if l11ll1_l1_ (u"ࠩ࠽ࠫ㞋") in l111lllll1l_l1_: l111lllll1l_l1_,l1llllllll1l_l1_ = l111lllll1l_l1_.split(l11ll1_l1_ (u"ࠪ࠾ࠬ㞌"))
	l1llll11ll11_l1_ = l11ll1_l1_ (u"ࠫ࠴࠭㞍")+l11ll1_l1_ (u"ࠬ࠵ࠧ㞎").join(url.split(l11ll1_l1_ (u"࠭࠯ࠨ㞏"))[3:])
	request = l11ll1_l1_ (u"ࠧࡈࡇࡗࠤࠬ㞐")+l1llll11ll11_l1_+l11ll1_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ㞑")
	#request += l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡀࠠ࡝ࡴ࡟ࡲࠬ㞒")
	request += l11ll1_l1_ (u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ㞓")+l111lllll1l_l1_+l11ll1_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㞔")
	request += l11ll1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㞕")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l111lllll1l_l1_,l1llllllll1l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11ll1_l1_ (u"࠭ࠧ㞖")
	return html
def SERVER(l1lllll_l1_,type):
	# url:	http://www.l11111l1l11_l1_.com
	# host:	www.l11111l1l11_l1_.com
	# name:	l11111l1l11_l1_
	#server = l11ll1_l1_ (u"ࠧ࠰ࠩ㞗").join(l1lllll_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ㞘"))[:3])
	if l11ll1_l1_ (u"ࠩ࠱ࠫ㞙") not in l1lllll_l1_: return l1lllll_l1_
	l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ㞚")
	l1l1lll1l111_l1_,l1l1lll11lll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠳࠭㞛"),1)
	l1l1lll11ll1_l1_,l1l1lll11l1l_l1_ = l1l1lll11lll_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ㞜"),1)
	server = l1l1lll1l111_l1_+l11ll1_l1_ (u"࠭࠮ࠨ㞝")+l1l1lll11ll1_l1_
	if type in [l11ll1_l1_ (u"ࠧࡩࡱࡶࡸࠬ㞞"),l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭㞟")] and l11ll1_l1_ (u"ࠩ࠲ࠫ㞠") in server: server = server.rsplit(l11ll1_l1_ (u"ࠪ࠳ࠬ㞡"),1)[1]
	if type==l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㞢") and l11ll1_l1_ (u"ࠬ࠴ࠧ㞣") in server:
		l1ll11l1ll1l_l1_ = server.split(l11ll1_l1_ (u"࠭࠮ࠨ㞤"))
		length = len(l1ll11l1ll1l_l1_)
		if length<=2 or l11ll1_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㞥") in server: l1ll11l1ll1l_l1_ = l1ll11l1ll1l_l1_[0]
		elif length>=3: l1ll11l1ll1l_l1_ = l1ll11l1ll1l_l1_[1]
		if len(l1ll11l1ll1l_l1_)>1: server = l1ll11l1ll1l_l1_
	return server
	l11ll1_l1_ (u"ࠣࠤࠥࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࠧ࠰ࠩ࠮ࡹࡷࡲ࠲ࠬࠩ࠲ࠫࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡰࡨࡸ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡵ࡫࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡺࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡷࡺ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡹࡶ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡵࡱ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡭ࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡷࡻ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡦࡳ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡸࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤ࡮ࡸࡦ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡪࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡼ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡫ࡱ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡸࡹࡺ࠲ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯࡮࠰ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡫࡭ࡣࡧࡧ࠲ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࠢࠣࠤ㞦")
def l1l1l1ll11l1_l1_(l111l1ll111_l1_):
	l111l1ll11l_l1_ = repr(l111l1ll111_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㞧"))).replace(l11ll1_l1_ (u"ࠥࠫࠧ㞨"),l11ll1_l1_ (u"ࠫࠬ㞩"))
	return l111l1ll11l_l1_
def l1l1l11lll1_l1_(string):
	#if l11ll1_l1_ (u"ࠬࡢࡵࠨ㞪") in string:
	#	string = string.decode(l11ll1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㞫"))
	#	l1lll1l11111_l1_=re.findall(l11ll1_l1_ (u"ࡲࠨ࡞ࡸ࡟࠵࠳࠹ࡂ࠯ࡉࡡࠬ㞬"),string)
	#	for unicode in l1lll1l11111_l1_
	#		char = l1l11l11ll1l_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㞭"))
	l1l11lllllll_l1_ = l11ll1_l1_ (u"ࠩࠪ㞮")
	if kodi_version<19: string = string.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㞯"))
	import unicodedata
	for l1l1l11ll11_l1_ in string:
		if   l1l1l11ll11_l1_==l11ll1_l1_ (u"ࡹࠬศࠧ㞰"): l111l111111_l1_ = l11ll1_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭㞱")
		elif l1l1l11ll11_l1_==l11ll1_l1_ (u"ࡻࠧฤࠩ㞲"): l111l111111_l1_ = l11ll1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨ㞳")
		elif l1l1l11ll11_l1_==l11ll1_l1_ (u"ࡶࠩวࠫ㞴"): l111l111111_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪ㞵")
		elif l1l1l11ll11_l1_==l11ll1_l1_ (u"ࡸࠫส࠭㞶"): l111l111111_l1_ = l11ll1_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬ㞷")
		elif l1l1l11ll11_l1_==l11ll1_l1_ (u"ࡺ࠭ฦࠨ㞸"): l111l111111_l1_ = l11ll1_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ㞹")
		else:
			l1l11l11l111_l1_ = unicodedata.decomposition(l1l1l11ll11_l1_)
			if l11ll1_l1_ (u"ࠧࠡࠩ㞺") in l1l11l11l111_l1_: l111l111111_l1_ = l11ll1_l1_ (u"ࠨ࡞࡟ࡹࠬ㞻")+l1l11l11l111_l1_.split(l11ll1_l1_ (u"ࠩࠣࠫ㞼"),1)[1]
			else:
				l111l111111_l1_ = l11ll1_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ㞽")+hex(ord(l1l1l11ll11_l1_)).replace(l11ll1_l1_ (u"ࠫ࠵ࡾࠧ㞾"),l11ll1_l1_ (u"ࠬ࠭㞿"))
				l111l111111_l1_ = l11ll1_l1_ (u"࠭࡜࡝ࡷࠪ㟀")+l111l111111_l1_[-4:]
			#if ord(l1l1l11ll11_l1_)<256: l111l111111_l1_ = l11ll1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠵࠭㟁")+l1l1lll1ll1l_l1_
			#elif ord(l1l1l11ll11_l1_)<4096: l111l111111_l1_ = l11ll1_l1_ (u"ࠨ࡞࡟ࡹ࠵࠭㟂")+l1l1lll1ll1l_l1_
			#elif l11ll1_l1_ (u"ࠩࠣࠫ㟃") in l1l11l11l111_l1_: l111l111111_l1_ = l11ll1_l1_ (u"ࠪࡠࡡࡻࠧ㟄")+l1l11l11l111_l1_.split(l11ll1_l1_ (u"ࠫࠥ࠭㟅"),1)[1]
			#else: l111l111111_l1_ = l11ll1_l1_ (u"ࠬࡢ࡜ࡶࠩ㟆")+l1l1lll1ll1l_l1_
		l1l11lllllll_l1_ += l111l111111_l1_
	l1l11lllllll_l1_ = l1l11lllllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ㟇"),l11ll1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ㟈"))
	if kodi_version<19: l1l11lllllll_l1_ = l1l11lllllll_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㟉")).encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㟊"))
	else: l1l11lllllll_l1_ = l1l11lllllll_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㟋")).decode(l11ll1_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㟌"))
	return l1l11lllllll_l1_
def OPEN_KEYBOARD(header=l11ll1_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ㟍"),default=l11ll1_l1_ (u"࠭ࠧ㟎"),l1111ll1ll1_l1_=False,source=l11ll1_l1_ (u"ࠧࠨ㟏")):
	text = l1ll111l11ll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ㟐"),l11ll1_l1_ (u"ࠩࠣࠫ㟑")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭㟒"),l11ll1_l1_ (u"ࠫࠥ࠭㟓")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ㟔"),l11ll1_l1_ (u"࠭ࠠࠨ㟕"))
	if not text and not l1111ll1ll1_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㟖"),l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㟗")+text+l11ll1_l1_ (u"ࠩࠥࠫ㟘"))
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㟙"),l11ll1_l1_ (u"ࠫࠬ㟚"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㟛"),l11ll1_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩ㟜"))
		return l11ll1_l1_ (u"ࠧࠨ㟝")
	if text not in [l11ll1_l1_ (u"ࠨࠩ㟞"),l11ll1_l1_ (u"ࠩࠣࠫ㟟")]:
		text = text.strip(l11ll1_l1_ (u"ࠪࠤࠬ㟠"))
		text = l1l1l11lll1_l1_(text)
	if source!=l11ll1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭㟡") and l11l1l1_l1_(l11ll1_l1_ (u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧ㟢"),l11ll1_l1_ (u"࠭ࠧ㟣"),[text],False):
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㟤"),l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬ㟥")+text+l11ll1_l1_ (u"ࠩࠥࠫ㟦"))
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㟧"),l11ll1_l1_ (u"ࠫࠬ㟨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㟩"),l11ll1_l1_ (u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨ㟪"))
		return l11ll1_l1_ (u"ࠧࠨ㟫")
	LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㟬"),l11ll1_l1_ (u"ࠩ࠱ࠤࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㟭")+text+l11ll1_l1_ (u"ࠪࠦࠬ㟮"))
	return text
def l11ll11ll1_l1_(l111lll_l1_,headers={}):
	#if headers[l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㟯")]==l11ll1_l1_ (u"ࠬ࠭㟰"): headers[l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㟱")] = l11ll1_l1_ (u"ࠧࠡࠩ㟲")
	#l1lll1l11ll1_l1_ = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㟳") : l11ll1_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠷࠶࠰࠳࠲࠸࠽࠷࠱࠰࠴࠸࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭㟴") }
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡪ࠸࠵࠰ࡰࡽࡨࡪ࡮࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠱ࡱ࠸ࡻ࠸ࠨ㟵")
	#open(l11ll1_l1_ (u"ࠫࡘࡀ࡜࡝ࡶࡨࡷࡹ࠸࠮࡮࠵ࡸ࠼ࠬ㟶"), l11ll1_l1_ (u"ࠬࡸࠧ㟷")).read()
	url,params = l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ㟸")
	if l11ll1_l1_ (u"ࠧࡽࠩ㟹") in l111lll_l1_:
		url,params = l111lll_l1_.split(l11ll1_l1_ (u"ࠨࡾࠪ㟺"),1)
		if l11ll1_l1_ (u"ࠩࡀࠫ㟻") not in params: url,params = l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ㟼")
	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㟽"),url,l11ll1_l1_ (u"ࠬ࠭㟾"),headers,l11ll1_l1_ (u"࠭ࠧ㟿"),l11ll1_l1_ (u"ࠧࠨ㠀"),l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ㠁"),False,False)
	html = response.content
	if l11ll1_l1_ (u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭㠂") not in html: return [l11ll1_l1_ (u"ࠪ࠱࠶࠭㠃")],[l111lll_l1_]
	#	if l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㠄") in list(headers.keys()): del headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㠅")]
	#	else: headers[l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㠆")] = l11ll1_l1_ (u"ࠧࠨ㠇")
	#	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㠈"),url,l11ll1_l1_ (u"ࠩࠪ㠉"),headers,l11ll1_l1_ (u"ࠪࠫ㠊"),l11ll1_l1_ (u"ࠫࠬ㠋"),l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠸࡮ࡥࠩ㠌"),False,False)
	#	html = response.content
	if l11ll1_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ㠍") in html: return [l11ll1_l1_ (u"ࠧ࠮࠳ࠪ㠎")],[l111lll_l1_]
	if l11ll1_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ㠏") in html: return [l11ll1_l1_ (u"ࠩ࠰࠵ࠬ㠐")],[l111lll_l1_]
	#if l11ll1_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖࠫ㠑") in html: return [l11ll1_l1_ (u"ࠫ࠲࠷ࠧ㠒")],[l111lll_l1_]
	l1lll11l_l1_,l1llll_l1_,l11111ll111_l1_,l1ll11l1l1l1_l1_ = [],[],[],[]
	lines = re.findall(l11ll1_l1_ (u"ࠬࡢࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ㠓"),html+l11ll1_l1_ (u"࠭࡜࡯ࠩ㠔"),re.DOTALL)
	if not lines: return [l11ll1_l1_ (u"ࠧ࠮࠳ࠪ㠕")],[l111lll_l1_]
	for line,l1lllll_l1_ in lines:
		l1l11lll1l11_l1_,l11l11l1l11_l1_,l111llll_l1_ = {},-1,-1
		title = l11ll1_l1_ (u"ࠨࠩ㠖")
		#hostname = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㠗"))
		#title = title+l11ll1_l1_ (u"ࠪࠤࠥ࠭㠘")+hostname+l11ll1_l1_ (u"ࠫࠥࠦࠧ㠙")
		#line = line.lower()
		items = line.split(l11ll1_l1_ (u"ࠬ࠲ࠧ㠚"))
		for item in items:
			#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㠛"),l11ll1_l1_ (u"ࠧࠨ㠜"),item,l11ll1_l1_ (u"ࠨࠩ㠝"))
			#if l11ll1_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㠞") in item: l1l11lll1l11_l1_[key] = value
			if l11ll1_l1_ (u"ࠪࡁࠬ㠟") in item:
				key,value = item.split(l11ll1_l1_ (u"ࠫࡂ࠭㠠"),1)
				l1l11lll1l11_l1_[key.lower()] = value
		if l11ll1_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㠡") in line.lower():
			l11l11l1l11_l1_ = int(l1l11lll1l11_l1_[l11ll1_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㠢")])//1024
			#title += l11ll1_l1_ (u"ࠧࡂࡸࡪࡆ࡜ࡀࠠࠨ㠣")+str(l11l11l1l11_l1_)+l11ll1_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㠤")
			title += str(l11l11l1l11_l1_)+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㠥")
		elif l11ll1_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㠦") in line.lower():
			l11l11l1l11_l1_ = int(l1l11lll1l11_l1_[l11ll1_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ㠧")])//1024
			#title += l11ll1_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ㠨")+str(l11l11l1l11_l1_)+l11ll1_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭㠩")
			title += str(l11l11l1l11_l1_)+l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㠪")
		if l11ll1_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ㠫") in line.lower():
			l111llll_l1_ = int(l1l11lll1l11_l1_[l11ll1_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭㠬")].split(l11ll1_l1_ (u"ࠪࡼࠬ㠭"))[1])
			#title += l11ll1_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ㠮")+str(l111llll_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࠨ㠯")
			title += str(l111llll_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࠩ㠰")
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠢࠪ㠱"))
		if not title: title = l11ll1_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ㠲")
		if not l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㠳")):
			if l1lllll_l1_.startswith(l11ll1_l1_ (u"ࠪ࠳࠴࠭㠴")): l1lllll_l1_ = url.split(l11ll1_l1_ (u"ࠫ࠿࠭㠵"),1)[0]+l11ll1_l1_ (u"ࠬࡀࠧ㠶")+l1lllll_l1_
			elif l1lllll_l1_.startswith(l11ll1_l1_ (u"࠭࠯ࠨ㠷")): l1lllll_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ㠸"))+l1lllll_l1_
			else: l1lllll_l1_ = url.rsplit(l11ll1_l1_ (u"ࠨ࠱ࠪ㠹"),1)[0]+l11ll1_l1_ (u"ࠩ࠲ࠫ㠺")+l1lllll_l1_
		if params!=l11ll1_l1_ (u"ࠪࠫ㠻"): l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࢁ࠭㠼")+params
		if l11ll1_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㠽") in list(l1l11lll1l11_l1_.keys()):
			l1lllll11l_l1_ = l1l11lll1l11_l1_[l11ll1_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ㠾")]
			l1lllll11l_l1_ = l1lllll11l_l1_.replace(l11ll1_l1_ (u"ࠧࠣࠩ㠿"),l11ll1_l1_ (u"ࠨࠩ㡀")).replace(l11ll1_l1_ (u"ࠤࠪࠦ㡁"),l11ll1_l1_ (u"ࠪࠫ㡂")).split(l11ll1_l1_ (u"ࠫࠨ࠭㡃"),1)[0]
			l111lll1ll_l1_ = l11l1lll1l_l1_(l1lllll11l_l1_)
			if l111lll1ll_l1_: l1lll1l1l_l1_ = title+l11ll1_l1_ (u"ࠬࠦࠠࠨ㡄")+l111lll1ll_l1_
			else: l1lll1l1l_l1_ = title
			l1lll1l1l_l1_ = l1lll1l1l_l1_+l11ll1_l1_ (u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭㡅")
			l1lll1l1l_l1_ = l1lll1l1l_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ㡆")+SERVER(l1lllll11l_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭㡇"))
			l1lll11l_l1_.append(l1lll1l1l_l1_)
			l1llll_l1_.append(l1lllll11l_l1_)
			l11111ll111_l1_.append(l111llll_l1_)
			l1ll11l1l1l1_l1_.append(l11l11l1l11_l1_)
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠦࠫ㡈"),1)[0]
		l111lll1ll_l1_ = l11l1lll1l_l1_(l1lllll_l1_)
		if l111lll1ll_l1_: title = title+l11ll1_l1_ (u"ࠪࠤࠥ࠭㡉")+l111lll1ll_l1_
		title = title+l11ll1_l1_ (u"ࠫࠥࠦࠧ㡊")+SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㡋"))
		l1lll11l_l1_.append(title)
		l1llll_l1_.append(l1lllll_l1_)
		l11111ll111_l1_.append(l111llll_l1_)
		l1ll11l1l1l1_l1_.append(l11l11l1l11_l1_)
	zz = list(zip(l1lll11l_l1_,l1llll_l1_,l11111ll111_l1_,l1ll11l1l1l1_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll11l_l1_,l1llll_l1_,l11111ll111_l1_,l1ll11l1l1l1_l1_ = list(zip(*zz))
	l1lll11l_l1_,l1llll_l1_ = list(l1lll11l_l1_),list(l1llll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ࠧ㡌"), l1lll11l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧࠨ㡍"), l1llll_l1_)
	return l1lll11l_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l11ll1l11l_l1_=l11ll1_l1_ (u"ࠨࠩ㡎")):
	if not l1l11ll1l11l_l1_: l1l11ll1l11l_l1_ = l1llll1ll1ll_l1_[0]
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㡏"),l11ll1_l1_ (u"ࠪࠫ㡐"),str(l1l11ll1l11l_l1_),str(host))
	if host.replace(l11ll1_l1_ (u"ࠫ࠳࠭㡑"),l11ll1_l1_ (u"ࠬ࠭㡒")).isdigit(): return [host]
	import struct,socket
	try:
		l111l1llll1_l1_ = struct.pack(l11ll1_l1_ (u"ࠨ࠾ࡉࠤ㡓"), 12049)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠢ࠿ࡊࠥ㡔"), 256)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠣࡀࡋࠦ㡕"), 1)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠤࡁࡌࠧ㡖"), 0)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠥࡂࡍࠨ㡗"), 0)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠦࡃࡎࠢ㡘"), 0)
		if kodi_version>18.99: l1lll111l111_l1_ = host.split(l11ll1_l1_ (u"ࠬ࠴ࠧ㡙"))
		else: l1lll111l111_l1_ = host.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㡚")).split(l11ll1_l1_ (u"ࠧ࠯ࠩ㡛"))
		for part in l1lll111l111_l1_:
			parts = part.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㡜"))
			l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠤࡅࠦ㡝"), len(part))
			for l1lllllll1l1_l1_ in part:
				l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠥࡧࠧ㡞"), l1lllllll1l1_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㡟")))
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠧࡈࠢ㡠"), 0)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠨ࠾ࡉࠤ㡡"), 1)
		l111l1llll1_l1_ += struct.pack(l11ll1_l1_ (u"ࠢ࠿ࡊࠥ㡢"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l111l1llll1_l1_), (l1l11ll1l11l_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l111lll11l1_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ㡣"), data, 0)
		l1111l11ll1_l1_ = l111lll11l1_l1_[3]
		offset = len(host)+18
		l111l1l11ll_l1_ = []
		for _ in range(l1111l11ll1_l1_):
			l11111l1ll1_l1_ = offset
			l1ll1l1l1lll_l1_ = 1
			l1llll1l1111_l1_ = False
			while True:
				l1lllllll1l1_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠤࡁࡆࠧ㡤"), data, l11111l1ll1_l1_)[0]
				if l1lllllll1l1_l1_ == 0:
					l11111l1ll1_l1_ += 1
					break
				# l1l1lll11111_l1_ the field l1l1ll111l1l_l1_ the first l111llll11l_l1_ bits l1ll1111l1ll_l1_ to 1, l1111ll11ll_l1_ a pointer
				if l1lllllll1l1_l1_ >= 192:
					l1llllll11l1_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠥࡂࡇࠨ㡥"), data, l11111l1ll1_l1_ + 1)[0]
					# l1l11ll1ll1l_l1_ the pointer
					l11111l1ll1_l1_ = ((l1lllllll1l1_l1_ << 8) + l1llllll11l1_l1_ - 0xc000) - 1
					l1llll1l1111_l1_ = True
				l11111l1ll1_l1_ += 1
				if l1llll1l1111_l1_ == False: l1ll1l1l1lll_l1_ += 1
			if l1llll1l1111_l1_ == True: l1ll1l1l1lll_l1_ += 1
			offset = offset + l1ll1l1l1lll_l1_
			l11ll11l1l1_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠦࡃࡎࡈࡊࡊࠥ㡦"), data, offset)
			offset = offset + 10
			l111llll1l1_l1_ = l11ll11l1l1_l1_[0]
			l1llll1l11l1_l1_ = l11ll11l1l1_l1_[3]
			if l111llll1l1_l1_ == 1: # l111l11llll_l1_ type
				l1lllllll1ll_l1_ = struct.unpack_from(l11ll1_l1_ (u"ࠧࡄࠢ㡧")+l11ll1_l1_ (u"ࠨࡂࠣ㡨")*l1llll1l11l1_l1_, data, offset)
				l1ll1111lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ㡩")
				for l1lllllll1l1_l1_ in l1lllllll1ll_l1_: l1ll1111lll1_l1_ += str(l1lllllll1l1_l1_) + l11ll1_l1_ (u"ࠨ࠰ࠪ㡪")
				l1ll1111lll1_l1_ = l1ll1111lll1_l1_[0:-1]
				l111l1l11ll_l1_.append(l1ll1111lll1_l1_)
			if l111llll1l1_l1_ in [1,2,5,6,15,28]: offset = offset + l1llll1l11l1_l1_
	except: l111l1l11ll_l1_ = []
	if not l111l1l11ll_l1_: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㡫"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ㡬")+host+l11ll1_l1_ (u"ࠫࠥࡣࠧ㡭"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㡮"),l11ll1_l1_ (u"࠭ࠧ㡯"),str(host),str(l111l1l11ll_l1_))
	return l111l1l11ll_l1_
def l11l1l1_l1_(script_name,url,l11l1ll_l1_,l1ll_l1_=True):
	if l11l1ll_l1_:
		l111lll1111_l1_ = [l11ll1_l1_ (u"ࠧไสสีࠬ㡰"),l11ll1_l1_ (u"ࠨสส่฿࠭㡱"),l11ll1_l1_ (u"ࠩࡤࡨࡺࡲࡴࠨ㡲"),l11ll1_l1_ (u"ࠪࡼࡽ࠭㡳"),l11ll1_l1_ (u"ࠫࡸ࡫ࡸࠨ㡴")]
		if script_name!=l11ll1_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㡵"):
			l111lll1111_l1_ += [l11ll1_l1_ (u"࠭ࡲ࠻ࠩ㡶"),l11ll1_l1_ (u"ࠧࡳ࠯ࠪ㡷"),l11ll1_l1_ (u"ࠨ࠯ࡰࡥࠬ㡸")]
			l111lll1111_l1_ += [l11ll1_l1_ (u"ࠩ࠽ࡶࠬ㡹"),l11ll1_l1_ (u"ࠪ࠱ࡷ࠭㡺"),l11ll1_l1_ (u"ࠫࡲࡧ࠭ࠨ㡻")]
		for l1ll1ll111_l1_ in l11l1ll_l1_:
			if l11ll1_l1_ (u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ㡼") in l1ll1ll111_l1_: continue
			if l11ll1_l1_ (u"࠭อๅไฬࠫ㡽") in l1ll1ll111_l1_: continue
			l1ll1ll111_l1_ = l1ll1ll111_l1_.lower()
			if kodi_version<19: l1ll1ll111_l1_ = l1ll1ll111_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㡾")).encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㡿"))
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㢀"),l11ll1_l1_ (u"ࠪࠫ㢁"),l11ll1_l1_ (u"ࠫࠬ㢂"),str(l1ll1ll111_l1_))
			#l1111l11111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ㢃"),l1ll1ll111_l1_,re.DOTALL)
			#l1111l111l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞࡝࠭ࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ㢄"),l1ll1ll111_l1_,re.DOTALL)
			#l1ll11111ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫ࡟࠯ࠩ࠭㢅"),l1ll1ll111_l1_,re.DOTALL)
			#l111l11l1ll_l1_ = any(l1111l11111_l1_,l1111l111l1_l1_,l1ll11111ll1_l1_,l11111llll1_l1_)
			l1ll1ll111_l1_ = l1ll1ll111_l1_.replace(l11ll1_l1_ (u"ࠨ࠼ࠪ㢆"),l11ll1_l1_ (u"ࠩࠪ㢇"))
			l111l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ㢈"),l1ll1ll111_l1_,re.DOTALL)
			l1ll11l1lll1_l1_ = False
			for digits in l111l11l1ll_l1_:
				if len(digits)==2:
					l1ll11l1lll1_l1_ = True
					break
			if l11ll1_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ㢉") in l1ll1ll111_l1_: continue
			elif l11ll1_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭㢊") in l1ll1ll111_l1_: continue
			elif l11ll1_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ㢋") in l1ll1ll111_l1_: continue
			elif l11llll1111_l1_(l11ll1_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ㢌")): continue
			elif l1ll1ll111_l1_ in [l11ll1_l1_ (u"ࠨࡴࠪ㢍")] or l1ll11l1lll1_l1_ or any(value in l1ll1ll111_l1_ for value in l111lll1111_l1_):
				LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㢎"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㢏")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㢐"))
				if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㢑"),l11ll1_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ㢒"))
				return True
	return False
def l1l1l1l1ll1l_l1_(l11l111_l1_,l1l1l1l1_l1_=l11ll1_l1_ (u"ࠧࠨ㢓"),l11ll1lllll_l1_=l11ll1_l1_ (u"ࠨࠩ㢔")):
	global l1l1l111l11_l1_
	import threading
	l11lll1lll1_l1_ = threading.Thread(target=l11111lll1l_l1_,args=(l11l111_l1_,l1l1l1l1_l1_,l11ll1lllll_l1_))
	l11lll1lll1_l1_.start()
	l11lll1lll1_l1_.join()
	return l1l1l111l11_l1_
def PLAY_VIDEO(l11l111_l1_,l1l1l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ㢕"),l11ll1lllll_l1_=l11ll1_l1_ (u"ࠪࠫ㢖")):
	global l1l1l111l11_l1_
	if not l11ll1lllll_l1_: l11ll1lllll_l1_ = l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㢗")
	l1l1l111l11_l1_,l111llll111_l1_,httpd = l11ll1_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࠰ࠨ㢘"),l11ll1_l1_ (u"࠭ࠧ㢙"),l11ll1_l1_ (u"ࠧࠨ㢚")
	if len(l11l111_l1_)==3:
		url,l1ll1l111111_l1_,httpd = l11l111_l1_
		if l1ll1l111111_l1_: l111llll111_l1_ = l11ll1_l1_ (u"ࠨࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀࠠ࡜ࠢࠪ㢛")+l1ll1l111111_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ㢜")
	else: url,l1ll1l111111_l1_,httpd = l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ㢝"),l11ll1_l1_ (u"ࠫࠬ㢞")
	#url = l1111_l1_(url)		# cause l1l11l11llll_l1_ for l1ll1ll1l_l1_ l1llll111_l1_ l111lll1ll1_l1_ l1ll1l111l11_l1_
	url = url.replace(l11ll1_l1_ (u"ࠬࠫ࠲࠱ࠩ㢟"),l11ll1_l1_ (u"࠭ࠠࠨ㢠"))	# needed for l1l11ll1llll_l1_
	l111lll1ll_l1_ = l11l1lll1l_l1_(url,l1l1l1l1_l1_)
	if l1l1l1l1_l1_ not in [l11ll1_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㢡"),l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠭㢢")]:
		if l1l1l1l1_l1_!=l11ll1_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㢣"): url = url.replace(l11ll1_l1_ (u"ࠪࠤࠬ㢤"),l11ll1_l1_ (u"ࠫࠪ࠸࠰ࠨ㢥"))
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㢦"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㢧")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㢨")+l111llll111_l1_)
		if l111lll1ll_l1_==l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㢩") and l1l1l1l1_l1_ not in [l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㢪"),l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㢫")]:
			headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㢬"):l11ll1_l1_ (u"ࠬ࠭㢭")}
			l1lll11l_l1_,l1llll_l1_ = l11ll11ll1_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ㢮")+str(count)+l11ll1_l1_ (u"ࠧࠡ็็ๅ࠮࠭㢯"), l1lll11l_l1_)
				if l1l_l1_ == -1:
					DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะิ฻์็ࠫ㢰"),l11ll1_l1_ (u"ࠩࠪ㢱"))
					return l1l1l111l11_l1_
			else: l1l_l1_ = 0
			url = l1llll_l1_[l1l_l1_]
			if l1lll11l_l1_[0]!=l11ll1_l1_ (u"ࠪ࠱࠶࠭㢲"):
				LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㢳"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ㢴")+l1lll11l_l1_[l1l_l1_]+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㢵")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㢶"))
		#url = url+l11ll1_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠶࠾࠶࠱࠲࠳࠴ࠬ㢷")
		#url = url+l11ll1_l1_ (u"ࠩࡿࡈࡓ࡚࠽࠲ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࡁࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠹ࠫࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠦࡂࡥࡦࡩࡵࡺ࠽ࠫ࠱࡚࠭ࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡍ࡫ࡱࡹࡽࡁࠠࡂࡰࡧࡶࡴ࡯ࡤࠡ࠹࠱࠴ࡀࠦࡓࡎ࠯ࡊ࠼࠾࠸ࡁࠡࡄࡸ࡭ࡱࡪ࠯ࡏࡔࡇ࠽࠵ࡓ࠻ࠡࡹࡹ࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯࡙ࠪࠢࡩࡷࡹࡩࡰࡰ࠲࠸࠳࠶ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠹࠱࠴࠳࠹࠳࠺࠸࠱࠼࠼ࠦࡍࡰࡤ࡬ࡰࡪࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭㢸")
		if l11ll1_l1_ (u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ㢹") in url: url = url+l11ll1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㢺")
		elif l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㢻") in url.lower() and l11ll1_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭㢼") not in url and l11ll1_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ㢽") not in url:
			if l11ll1_l1_ (u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭㢾") not in url and l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ㢿") in url.lower():
				if l11ll1_l1_ (u"ࠪࢀࠬ㣀") not in url: url = url+l11ll1_l1_ (u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨ㣁")
				else: url = url+l11ll1_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ㣂")
			if l11ll1_l1_ (u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ㣃") not in url.lower() and l1l1l1l1_l1_ not in [l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㣄"),l11ll1_l1_ (u"ࠨࡏ࠶࡙ࠬ㣅")]:
				if l11ll1_l1_ (u"ࠩࡿࠫ㣆") not in url: url = url+l11ll1_l1_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ㣇")
				else: url = url+l11ll1_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㣈")
		#url = url.replace(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ㣉"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ㣊"))
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㣋"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㣌")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㣍"))
	l11lll11l11_l1_ = xbmcgui.ListItem()
	#l11lll11l11_l1_ = xbmcgui.ListItem(l11ll1_l1_ (u"ࠪࡸࡪࡹࡴࠨ㣎"))
	l11ll1lllll_l1_,l1l11111lll_l1_,l1l111ll1l1_l1_,l11lll11lll_l1_,l1l11l111ll_l1_,l11lll11111_l1_,l1l11111ll1_l1_,l1l11111l11_l1_,l1l111l1l11_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1l1l1_l1_ not in [l11ll1_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㣏"),l11ll1_l1_ (u"ࠬࡏࡐࡕࡘࠪ㣐")]:
		if kodi_version<19: l1l11l11lll1_l1_ = l11ll1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩ㣑")
		else: l1l11l11lll1_l1_ = l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬ㣒")
		#l11lll11l11_l1_ = xbmcgui.ListItem(path=url)
		l11lll11l11_l1_.setProperty(l1l11l11lll1_l1_, l11ll1_l1_ (u"ࠨࠩ㣓"))
		l11lll11l11_l1_.setMimeType(l11ll1_l1_ (u"ࠩࡰ࡭ࡲ࡫࠯ࡹ࠯ࡷࡽࡵ࡫ࠧ㣔"))
		if kodi_version<20: l11lll11l11_l1_.setInfo(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㣕"),{l11ll1_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧ㣖"):l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ㣗")})
		else:
			l1l1l111l1ll_l1_ = l11lll11l11_l1_.getVideoInfoTag()
			l1l1l111l1ll_l1_.setMediaType(l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㣘"))
		#l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰࡬ࡧࡴࡴࠧ㣙"))
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㣚"),l11ll1_l1_ (u"ࠩࡈࡑࡆࡊ࠺࠻࠼࠽࠾ࠥ࠭㣛")+l111_l1_)
		#l11lll11l11_l1_.setArt({l11ll1_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ㣜"):l111_l1_,l11ll1_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ㣝"):l111_l1_,l11ll1_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ㣞"):l111_l1_})
		l11lll11l11_l1_.setArt({l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ㣟"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧ㣠"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨ㣡"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ㣢"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬ㣣"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ㣤"):l1l11l111ll_l1_,l11ll1_l1_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ㣥"):l1l11l111ll_l1_,l11ll1_l1_ (u"࠭ࡩࡤࡱࡱࠫ㣦"):l1l11l111ll_l1_})
		#l11lll11l11_l1_.setInfo(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㣧"),{l11ll1_l1_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧ㣨"):name})
		#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ㣩"))
		#name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ㣪"))
		# when set to l11ll1_l1_ (u"ࠦࡋࡧ࡬ࡴࡧࠥ㣫") it l11l111l11l_l1_ l1ll111111l1_l1_ l1ll1ll11111_l1_ and l1l1llllllll_l1_ l111l111l11_l1_ l1l11lll111l_l1_ l1l1llll11_l1_
		if l111lll1ll_l1_ in [l11ll1_l1_ (u"ࠬ࠴࡭ࡱࡦࠪ㣬"),l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㣭")]: l11lll11l11_l1_.setContentLookup(True)
		else: l11lll11l11_l1_.setContentLookup(False)
		#if l111lll1ll_l1_ in [l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㣮")]: l11lll11l11_l1_.setContentLookup(False)
		if l11ll1_l1_ (u"ࠨࡴࡷࡱࡵ࠭㣯") in url:
			import l1l1111lll1_l1_
			l1l1111lll1_l1_.l11l11llll1_l1_(l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ㣰"),False)
		elif l111lll1ll_l1_==l11ll1_l1_ (u"ࠪ࠲ࡲࡶࡤࠨ㣱") or l11ll1_l1_ (u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ㣲") in url:
			import l1l1111lll1_l1_
			l1l1111lll1_l1_.l11l11llll1_l1_(l11ll1_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㣳"),False)
			l11lll11l11_l1_.setProperty(l1l11l11lll1_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㣴"))
			l11lll11l11_l1_.setProperty(l11ll1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫࠮࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡷࡽࡵ࡫ࠧ㣵"),l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ㣶"))
			#l11lll11l11_l1_.setMimeType(l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡥࡣࡶ࡬࠰ࡾ࡭࡭ࠩ㣷"))
			#l11lll11l11_l1_.setContentLookup(False)
		if l1ll1l111111_l1_:
			l11lll11l11_l1_.setSubtitles([l1ll1l111111_l1_])
			#xbmc.log(LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࡄࡨࡩ࡫ࡤࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࠣࡸࡴࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼࡞ࠫ㣸")+l1ll1l111111_l1_+l11ll1_l1_ (u"ࠫࡢ࠭㣹"), level=xbmc.LOGNOTICE)
	if l11ll1lllll_l1_==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㣺") and l1l1l1l1_l1_==l11ll1_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㣻"):
		l1l1l111l11_l1_ = l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㣼")
		l1l1l1l1_l1_ = l11ll1_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ㣽")
	elif l11ll1lllll_l1_==l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㣾") and l1l11111l11_l1_.startswith(l11ll1_l1_ (u"ࠪ࠺ࠬ㣿")):
		l1l1l111l11_l1_ = l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㤀")
		l1l1l1l1_l1_ = l1l1l1l1_l1_+l11ll1_l1_ (u"ࠬࡥࡄࡍࠩ㤁")
	# l11lll1l111_l1_ l1l11lll1ll_l1_
	#	l1l1111l1l1_l1_ = l1l111lll1l_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11lll1_l1_ with xbmc.sleep(step*1000)
	if l1l1l111l11_l1_!=l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㤂"): l1l11l111l1_l1_()
	l1l1111l1l1_l1_ = l1l111lll1l_l1_()
	if l1l1111l1l1_l1_.status:
		l1l1l111l11_l1_ == l11ll1_l1_ (u"ࠧࠨ㤃")
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㤄"),l11ll1_l1_ (u"ࠩࠪ㤅"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㤆"),l11ll1_l1_ (u"้่ࠫฯࠡไส้ࠥอไๆสิ้ัࠦศฦ์ๅหๆࠦสี฼ํ่ࠥ๎สฮ็ํ่ࠥอไโ์า๎ํํวหࠢไ๎ࠥํะศࠢส่ัํวำࠩ㤇"))
	elif l11ll1lllll_l1_==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㤈") and not l1l11111l11_l1_.startswith(l11ll1_l1_ (u"࠭࠶ࠨ㤉")):
		#title = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠨ㤊"))
		#l11lll11l11_l1_.setInfo(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㤋"),{l11ll1_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ㤌"): 3600})
		#xbmcplugin.setContent(addon_handle,l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ㤍"))
		#l11lll11l11_l1_.setInfo(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㤎"),{l11ll1_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ㤏"):l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㤐")})
		#l11lll11l11_l1_.setProperty(l11ll1_l1_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫ㤑"),l11ll1_l1_ (u"ࠨࡶࡵࡹࡪ࠭㤒"))
		#l11lll11l11_l1_.setInfo(type=l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㤓"),l1l1l11111ll_l1_={l11ll1_l1_ (u"ࠥࡘ࡮ࡺ࡬ࡦࠤ㤔"):l11ll1_l1_ (u"ࠫ࡭࡫࡬࡭ࡱࠣࡻࡴࡸ࡬ࡥࠩ㤕")})
		l11lll11l11_l1_.setPath(url)
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㤖"),LOGGING(script_name)+l11ll1_l1_ (u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㤗")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㤘"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11lll11l11_l1_)
	elif l11ll1lllll_l1_==l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㤙"):
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㤚"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㤛")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㤜"))
		l1l1111l1l1_l1_.play(url,l11lll11l11_l1_)
		#xbmc.Player().play(url,l11lll11l11_l1_)
	succeeded = False
	if l1l1l111l11_l1_==l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㤝"):
		import l11l111ll1_l1_
		succeeded = l11l111ll1_l1_.l11l11ll11_l1_(url,l111lll1ll_l1_,l1l1l1l1_l1_)
		if succeeded: l1l11l111l1_l1_()
	else:
		timeout,l1l1l111l11_l1_ = 10,l11ll1_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ㤞")
		for l11ll1111l_l1_ in range(timeout):
			# l11lll1l111_l1_ l1l11lll1ll_l1_
			#	if using time.sleep() l11lll1ll1l_l1_ of xbmc.sleep() l1l11ll1lll_l1_ the l11llll1ll1_l1_ status
			#	l11ll1_l1_ (u"ࠢ࡮ࡻࡳࡰࡦࡿࡥࡳ࠰ࡶࡸࡦࡺࡵࡴࠤ㤟") will stop l1l1111l1ll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l1l111l11_l1_ = l1l1111l1l1_l1_.status
			if l1l1l111l11_l1_==l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㤠"):
				DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣ๎฾๋ไࠨ㤡"),l11ll1_l1_ (u"ࠪࠫ㤢"),time=500)
				LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㤣"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࡺ࡮ࡪࡥࡰࠢ࡬ࡷࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㤤")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㤥")+l111llll111_l1_)
				break
			elif l1l1l111l11_l1_==l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㤦"):
				LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㤧"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㤨")+url+l11ll1_l1_ (u"ࠪࠤࡢ࠭㤩")+l111llll111_l1_)
				DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭㤪"),l11ll1_l1_ (u"ࠬ࠭㤫"),time=500)
				break
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭ฬศำํࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫ㤬"),l11ll1_l1_ (u"ࠧษษๅ๎ࠥ࠭㤭")+str(timeout-l11ll1111l_l1_)+l11ll1_l1_ (u"ࠨࠢฮห๋๐ษࠨ㤮"))
		else:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠫ㤯"),l11ll1_l1_ (u"ࠪࠫ㤰"),time=500)
			if l1l1l111l11_l1_: LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㤱"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㤲")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㤳"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㤴"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸࠥࡻ࡮࡬ࡰࡲࡻࡳࠦࡰࡳࡱࡥࡰࡪࡳࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㤵")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ㤶")+l111llll111_l1_)
			l1l1l111l11_l1_ = l11ll1_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㤷")
	l11ll1_l1_ (u"ࠦࠧࠨࠍࠋࠋ࡬ࡪࠥ࡮ࡴࡵࡲࡧ࠾ࠒࠐࠉࠊࠥࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡣ࡭࡫ࡦ࡯ࠥࡵ࡫ࠡࡶࡲࠤࡸ࡮ࡵࡵࡦࡲࡻࡳࠦࡴࡩࡧࠣ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠨࠫࠐࠎࠎࠏࠣࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡐࡒࡣࡈࡇࡃࡉࡇ࠯ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ࠩࠎࠌࠌࠍࡹ࡯࡭ࡦ࠰ࡶࡰࡪ࡫ࡰࠩ࠳ࠬࠑࠏࠏࠉࡩࡶࡷࡴࡩ࠴ࡳࡩࡷࡷࡨࡴࡽ࡮ࠩࠫࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠩ࠯ࠫࠬ࠯ࠍࠋࠋࠥࠦࠧ㤸")
	if l1l1l111l11_l1_ in [l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㤹"),l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㤺")] or succeeded: response = l1l11llllll_l1_(l1l1l1l1_l1_)
	else: l1l1111l1l1_l1_.stop()
	#if l1l1l111l11_l1_ in [l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㤻"),l11ll1_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㤼"),l11ll1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㤽"),l11ll1_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㤾"),l11ll1_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㤿")]: l111lllllll_l1_(l11ll1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡍࡃ࡜ࡣ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧ㥀"),False)
	#l111lllllll_l1_(l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒ࠱࠸ࡸࡤࠨ㥁"))
	#if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ㥂") in url and l1l1l111l11_l1_ in [l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㥃"),l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ㥄")]:
	#	l1l1111l1ll_l1_ = HTTPS(False)
	#	if not l1l1111l1ll_l1_:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㥅"),l11ll1_l1_ (u"ࠫࠬ㥆"),l11ll1_l1_ (u"ࠬอไศฬุห้ࠦๅีใิࠫ㥇"),l11ll1_l1_ (u"࠭ๅีๅ็อࠥ࠴࠮࠯๊ࠢิฬࠦวๅใํำ๏๎๋ࠠฯอหัࠦวๅ๋ࠣหฯ฻วๅุ่ࠢๆืࠠࠩำห฻๋ࠥิโำࠬࠤํ๊ใ็ࠢ็่ศูแࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽้๏ࠠอ้สึ่࠭㥈"))
	#		return l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭㥉")
	#sys.exit()
	if 0 and l1l1l111l11_l1_==l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㥊"):
		LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㥋"),l11ll1_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡕࡗࡅ࡙࡛ࡓ࠻࠼ࠣࠤࠥ࠭㥌")+l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㥍"))
		while True:
			l1l1l111l11_l1_ = l1l1111l1l1_l1_.status
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭㥎"),l11ll1_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ㥏")+l1l1l111l11_l1_)
			if l1l1l111l11_l1_!=l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㥐"): break
			xbmc.sleep(1000)
		LOG_THIS(l11ll1_l1_ (u"ࠨࠩ㥑"),l11ll1_l1_ (u"ࠩࡓࡐࡆ࡟࡟ࡔࡖࡄࡘ࡚࡙࠺࠻ࠢࠣࠤࠬ㥒")+l11ll1_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ㥓"))
	return l1l1l111l11_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1ll11l1ll11_l1_ = args[0]
		l11l1l11_l1_ = args[1]
		if not l1ll11l1ll11_l1_: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㥔")
		if not l11l1l11_l1_: l11l1l11_l1_ = l11ll1_l1_ (u"ࠬอำห็ิหึ࠭㥕")
		header = args[2]
		text = l11ll1_l1_ (u"࠭࡜࡯ࠩ㥖").join(args[3:])
	else: l1ll11l1ll11_l1_,l11l1l11_l1_,header,text = l11ll1_l1_ (u"ࠧࠨ㥗"),l11ll1_l1_ (u"ࠨࡑࡎࠫ㥘"),l11ll1_l1_ (u"ࠩࠪ㥙"),l11ll1_l1_ (u"ࠪࠫ㥚")
	DIALOG_THREEBUTTONS_TIMEOUT(l1ll11l1ll11_l1_,l11ll1_l1_ (u"ࠫࠬ㥛"),l11l1l11_l1_,l11ll1_l1_ (u"ࠬ࠭㥜"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1ll11l1ll11_l1_ = args[0]
	l1ll1ll1ll1l_l1_ = args[1]
	l1ll1l1l11ll_l1_ = args[2]
	if l1ll1l1l11ll_l1_ or l1ll1ll1ll1l_l1_: l1ll1ll1l111_l1_ = True
	else: l1ll1ll1l111_l1_ = False
	header = args[3]
	text = args[4]
	if not l1ll11l1ll11_l1_: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㥝")
	if not l1ll1ll1ll1l_l1_: l1ll1ll1ll1l_l1_ = l11ll1_l1_ (u"ࠧไๆสࠫ㥞")
	if not l1ll1l1l11ll_l1_: l1ll1l1l11ll_l1_ = l11ll1_l1_ (u"ࠨ่฼้ࠬ㥟")
	if len(args)>=6: text += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㥠")+args[5]
	if len(args)>=7: text += l11ll1_l1_ (u"ࠪࡠࡳ࠭㥡")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1ll11l1ll11_l1_,l1ll1ll1ll1l_l1_,l11ll1_l1_ (u"ࠫࠬ㥢"),l1ll1l1l11ll_l1_,header,text)
	if choice==-1 and l1ll1ll1l111_l1_: choice = -1
	elif choice==-1 and not l1ll1ll1l111_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1llll111lll_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㥣") in list(kwargs.keys()): l11ll1l1ll1_l1_ = kwargs[l11ll1_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㥤")]
	else: l11ll1l1ll1_l1_ = 1000
	if len(args)>2 and l11ll1_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㥥") not in args[2]: l11111ll11l_l1_ = args[2]
	else: l11111ll11l_l1_ = l11ll1_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㥦")
	l1l1l111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࡉ࡮ࡣࡪࡩ࠳ࡾ࡭࡭ࠩ㥧"),l1l111llll1_l1_,l11ll1_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㥨"),l11ll1_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㥩"))
	l1lll1ll11l1_l1_,l1111llll1l_l1_ = l1lll1l1ll11_l1_(l11ll1_l1_ (u"ࠬ࠭㥪"),l11ll1_l1_ (u"࠭ࠧ㥫"),l11ll1_l1_ (u"ࠧࠨ㥬"),header,text,l11111ll11l_l1_,l11ll1_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㥭"),720,False)
	#time.sleep(0.200)
	l1l1l111l1l1_l1_.show()
	if l11111ll11l_l1_==l11ll1_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㥮"):
		l1l1l111l1l1_l1_.getControl(9040).setHeight(215)
		l1l1l111l1l1_l1_.getControl(9040).setPosition(55,-80)
		l1l1l111l1l1_l1_.getControl(9050).setPosition(120,-60)
		l1l1l111l1l1_l1_.getControl(400).setPosition(90,-35)
	l1l1l111l1l1_l1_.getControl(401).setVisible(False)
	l1l1l111l1l1_l1_.getControl(402).setVisible(False)
	l1l1l111l1l1_l1_.getControl(9050).setImage(l1lll1ll11l1_l1_)
	l1l1l111l1l1_l1_.getControl(9050).setHeight(l1111llll1l_l1_)
	import threading
	l11ll11l1ll_l1_ = threading.Thread(target=l1l11l11l1l1_l1_,args=(l1l1l111l1l1_l1_,l1lll1ll11l1_l1_,l11ll1l1ll1_l1_))
	l11ll11l1ll_l1_.start()
	#l11ll11l1ll_l1_.join()
	return
	#return xbmcgui.Dialog().l1l1l1l111ll_l1_(l1ll11l11111_l1_=False,*args,**kwargs)
def l1l11l11l1l1_l1_(l1l1l111l1l1_l1_,l1lll1ll11l1_l1_,l11ll1l1ll1_l1_):
	time.sleep(l11ll1l1ll1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll1ll11l1_l1_):
		try: os.remove(l1lll1ll11l1_l1_)
		except: pass
	#del l1l1l111l1l1_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,l11111ll11l_l1_,l1ll11l1ll11_l1_ = l11ll1_l1_ (u"ࠪࠫ㥯"),l11ll1_l1_ (u"ࠫࠬ㥰"),l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㥱"),l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ㥲")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: l11111ll11l_l1_ = args[2]
	if len(args)>=4: l1ll11l1ll11_l1_ = args[3]
	return l11ll1l11l_l1_(l1ll11l1ll11_l1_,header,text,l11111ll11l_l1_)
	#return xbmcgui.Dialog().l1ll1llll1ll_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1lll1ll11_l1_(*args,**kwargs)
def l11l1l111l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1ll111l11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text,l11111ll11l_l1_,l1ll11l1ll11_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l1l111l1l1_l1_ = l1l1ll11lll1_l1_(l11ll1_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㥳"),l1l111llll1_l1_,l11ll1_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㥴"),l11ll1_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㥵"))
	#l1l1l111l1l1_l1_.l1111llll11_l1_(l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text,l11111ll11l_l1_,l1ll11l1ll11_l1_,855)
	#return l1l1l111l1l1_l1_
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡹ࡯࡭ࡦࡱࡸࡸࡃ࠶࠺ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡵࡷࡥࡷࡺࡂࡶࡶࡷࡳࡳࡹࡔࡪ࡯ࡨࡳࡺࡺࠨࡵ࡫ࡰࡩࡴࡻࡴࠪࠏࠍࠍࡪࡲࡳࡦ࠼ࠣࡨ࡮ࡧ࡬ࡰࡩ࠱ࡩࡳࡧࡢ࡭ࡧࡅࡹࡹࡺ࡯࡯ࡵࠫ࠭ࠒࠐࠉࠤࡦ࡬ࡥࡱࡵࡧ࠯ࡷࡳࡨࡦࡺࡥࡑࡴࡲ࡫ࡷ࡫ࡳࡴࡄࡤࡶ࠭࠽࠰ࠪࠋࠦࠤ࠼࠶ࠥࠎࠌࠌࡨ࡮ࡧ࡬ࡰࡩ࠱ࡨࡴࡓ࡯ࡥࡣ࡯ࠬ࠮ࠓࠊࠊࡥ࡫ࡳ࡮ࡩࡥࠡ࠿ࠣࡨ࡮ࡧ࡬ࡰࡩ࠱ࡧ࡭ࡵࡩࡤࡧࡌࡈࠒࠐࠉࡵࡴࡼ࠾ࠥࡵࡳ࠯ࡴࡨࡱࡴࡼࡥࠩࡦ࡬ࡥࡱࡵࡧ࠯࡫ࡰࡥ࡬࡫࡟ࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࠐࠎࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠣࡥࡧ࡯ࠤࡩ࡯ࡡ࡭ࡱࡪࠑࠏࠏࡲࡦࡶࡸࡶࡳࠦࡣࡩࡱ࡬ࡧࡪࠓࠊࠊࠤࠥࠦ㥶")
def l1ll111l1_l1_(l1ll1l11lll1_l1_):
	if kodi_version>17.99: l1l1l111l1l1_l1_ = l11ll1_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩ㥷")
	else: l1l1l111l1l1_l1_ = l11ll1_l1_ (u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩ㥸")
	l1ll1l11lll1_l1_ = l1ll1l11lll1_l1_.lower()
	if l1ll1l11lll1_l1_==l11ll1_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㥹"): xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩ㥺")+l1l1l111l1l1_l1_+l11ll1_l1_ (u"ࠨࠫࠪ㥻"))
	elif l1ll1l11lll1_l1_==l11ll1_l1_ (u"ࠩࡶࡸࡴࡶࠧ㥼"): xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪ㥽")+l1l1l111l1l1_l1_+l11ll1_l1_ (u"ࠫ࠮࠭㥾"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1ll11l1ll11_l1_,l111111l111_l1_=l11ll1_l1_ (u"ࠬ࠭㥿"),l1l1ll11111l_l1_=l11ll1_l1_ (u"࠭ࠧ㦀"),l111111ll1l_l1_=l11ll1_l1_ (u"ࠧࠨ㦁"),header=l11ll1_l1_ (u"ࠨࠩ㦂"),text=l11ll1_l1_ (u"ࠩࠪ㦃"),l11111ll11l_l1_=l11ll1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㦄"),l1ll1ll11l1l_l1_=0,l1ll11111111_l1_=0):
	if not l1ll11l1ll11_l1_: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㦅")
	l1l1l111l1l1_l1_ = l1l1ll11lll1_l1_(l11ll1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㦆"),l1l111llll1_l1_,l11ll1_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㦇"),l11ll1_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㦈"))
	l1l1l111l1l1_l1_.l1111llll11_l1_(l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text,l11111ll11l_l1_,l1ll11l1ll11_l1_,900,l1ll1ll11l1l_l1_,l1ll11111111_l1_)
	if l1ll1ll11l1l_l1_>0: l1l1l111l1l1_l1_.l11ll111l1l_l1_()
	if l1ll11111111_l1_>0: l1l1l111l1l1_l1_.l11l1l1ll1l_l1_()
	if l1ll1ll11l1l_l1_==0 and l1ll11111111_l1_==0: l1l1l111l1l1_l1_.enableButtons()
	l1l1l111l1l1_l1_.doModal()
	choice = l1l1l111l1l1_l1_.l11ll11l11l_l1_
	return choice
def l11ll1l11l_l1_(l1ll11l1ll11_l1_,header,text,l11111ll11l_l1_=l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㦉")):
	if not l1ll11l1ll11_l1_: l1ll11l1ll11_l1_ = l11ll1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㦊")
	#text = l11ll1_l1_ (u"ࠪࡠࡳ࠭㦋").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11ll1_l1_ (u"ࠫࠬ㦌")
	l1l1l111l1l1_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨ㦍"),l1l111llll1_l1_,l11ll1_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㦎"),l11ll1_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㦏"))
	l1lll1ll11l1_l1_,l1111llll1l_l1_ = l1lll1l1ll11_l1_(l11ll1_l1_ (u"ࠨࠩ㦐"),l11ll1_l1_ (u"ࠩࠪ㦑"),l11ll1_l1_ (u"ࠪࠫ㦒"),header,text,l11111ll11l_l1_,l1ll11l1ll11_l1_,1270,False)
	l1l1l111l1l1_l1_.show()
	#time.sleep(1)
	#l1l1l111l1l1_l1_.getControl(9050).l1l11lllll11_l1_(1270-60)
	l1l1l111l1l1_l1_.getControl(9050).setHeight(l1111llll1l_l1_)
	l1l1l111l1l1_l1_.getControl(9050).setImage(l1lll1ll11l1_l1_)
	result = l1l1l111l1l1_l1_.doModal()
	#del l1l1l111l1l1_l1_
	try: os.remove(l1lll1ll11l1_l1_)
	except: pass
	return result
def l11llllll_l1_(l1l1llll11ll_l1_=True):
	if l1l1llll11ll_l1_:
		l111llll11_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ㦓"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㦔"),l11ll1_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㦕"))
		if l111llll11_l1_: return l111llll11_l1_
	#LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㦖"),l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࡷࡶࡩࡷࡧࡧࡦࡰࡷ࠾ࠥ࠭㦗")+results)
	# l11ll11l111_l1_ and l11111l1ll_l1_ common user l1ll11ll1ll1_l1_ (l1111l1111l_l1_ l11ll111ll1_l1_)
	text = l11ll1_l1_ (u"ࠩࠪ㦘")
	url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡫ࡣࡩࡤ࡯ࡳ࡬࠴ࡷࡪ࡮࡯ࡷ࡭ࡵࡵࡴࡧ࠱ࡧࡴࡳ࠯࠳࠲࠴࠶࠴࠶࠱࠰࠲࠶࠳ࡲࡵࡳࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹࡹ࠯ࠨ㦙")
	headers = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㦚"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㦛"),url,l11ll1_l1_ (u"࠭ࠧ㦜"),headers,l11ll1_l1_ (u"ࠧࠨ㦝"),l11ll1_l1_ (u"ࠨࠩ㦞"),l11ll1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ㦟"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11ll1_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫ㦠"))
		if count>80:
			text = re.findall(l11ll1_l1_ (u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㦡"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㦢"),l11ll1_l1_ (u"࠭ࠧ㦣"),l11ll1_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㦤"),l11ll1_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡕࡔࡇࡕ࠱ࡆࡍࡅࡏࡖࡖࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠨ㦥"))
	if not text:
		l1lll1111lll_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㦦"),l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫ㦧"))
		text = open(l1lll1111lll_l1_,l11ll1_l1_ (u"ࠫࡷࡨࠧ㦨")).read()
		if kodi_version>18.99: text = text.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㦩"))
		text = text.replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ㦪"),l11ll1_l1_ (u"ࠧࠨ㦫"))
	l1lll1l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ㦬"),text,re.DOTALL)
	l11l11ll1l1_l1_ = []
	for line in l1lll1l1111l_l1_:
		l1ll1l11l1ll_l1_ = line.lower()
		if l11ll1_l1_ (u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ㦭") in l1ll1l11l1ll_l1_: continue
		if l11ll1_l1_ (u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ㦮") in l1ll1l11l1ll_l1_: continue
		#if l11ll1_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩ㦯") in l1ll1l11l1ll_l1_: continue
		l11l11ll1l1_l1_.append(line)
	l111llll11_l1_ = random.sample(l11l11ll1l1_l1_,1)
	l111llll11_l1_ = l111llll11_l1_[0]
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㦰"),l11ll1_l1_ (u"࠭ࠧ㦱"),str(len(l1lll1l1111l_l1_)),l111llll11_l1_)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㦲"),l11ll1_l1_ (u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫ㦳"),l111llll11_l1_,l1ll1lll1_l1_)
	return l111llll11_l1_
def l111l1lllll_l1_(l1llllll11ll_l1_):
	#if l11ll1_l1_ (u"ࠩࡩࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠧ㦴") in str(error).lower(): return
	#l1llllll11ll_l1_ = traceback.format_exc()
	sys.stderr.write(l1llllll11ll_l1_)
	lines = l1llllll11ll_l1_.splitlines()
	error = lines[-1]
	l11111l1lll_l1_ = open(l1lll111111l_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭㦵")).read()
	if kodi_version>18.99: l11111l1lll_l1_ = l11111l1lll_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㦶"))
	l11111l1lll_l1_ = l11111l1lll_l1_[-8000:]
	sep = l11ll1_l1_ (u"ࠬࡃࠧ㦷")*100
	if sep in l11111l1lll_l1_: l11111l1lll_l1_ = l11111l1lll_l1_.rsplit(sep,1)[1]
	if error in l11111l1lll_l1_: l11111l1lll_l1_ = l11111l1lll_l1_.rsplit(error,1)[0]
	#l11ll1l11l_l1_(l11ll1_l1_ (u"࠭ࠧ㦸"),error,l11111l1lll_l1_)
	#l1l11l1l1ll_l1_ = l11111l1lll_l1_.splitlines()
	#for line in reversed(l1l11l1l1ll_l1_):
	#	if l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫࠭ࡢࡰࡤࡰࡾࡺࡩࡤࡵࠪ㦹") in line or l11ll1_l1_ (u"ࠨࡣࡰࡴࡱ࡯ࡴࡶࡦࡨ࠲ࡨࡵ࡭ࠨ㦺") in line: continue
	#	if l11ll1_l1_ (u"ࠩࡐࡳࡩ࡫࠺ࠡ࡝ࠪ㦻") not in line: continue
	l1l1ll1l1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡘࡵࡵࡳࡥࡨࢀࡒࡵࡤࡦࠫ࠽ࠤࡡࡡࠠࠩ࠰࠭ࡃ࠮ࠦ࡜࡞ࠩ㦼"),l11111l1lll_l1_,re.DOTALL)
	for typ,source in reversed(l1l1ll1l1lll_l1_):
		#if l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࠭㦽") in source: continue
		#if l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࠨ㦾") in source: continue
		if source: break
	else: source = l11ll1_l1_ (u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭㦿")
	#l11ll1l11l_l1_(l11ll1_l1_ (u"ࠧࠨ㧀"),source,str(l1l1ll1l1lll_l1_))
	file,line,func = l11ll1_l1_ (u"ࠨࠩ㧁"),l11ll1_l1_ (u"ࠩࠪ㧂"),l11ll1_l1_ (u"ࠪࠫ㧃")
	l11l11l1111_l1_ = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㧄")+error
	l1llll1l1l11_l1_ = l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㧅")+source
	for l1ll1ll1l1ll_l1_ in reversed(lines):
		if l11ll1_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭㧆") in l1ll1ll1l1ll_l1_ and l11ll1_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㧇") in l1ll1ll1l1ll_l1_: break
	l1ll1ll1l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫ㧈"),l1ll1ll1l1ll_l1_,re.DOTALL)
	if l1ll1ll1l1ll_l1_:
		file,line,func = l1ll1ll1l1ll_l1_[0]
		if l11ll1_l1_ (u"ࠩ࠲ࠫ㧉") in file: file = file.rsplit(l11ll1_l1_ (u"ࠪ࠳ࠬ㧊"),1)[1]
		else: file = file.rsplit(l11ll1_l1_ (u"ࠫࡡࡢࠧ㧋"),1)[1]
		l1l1l1111l11_l1_ = l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㧌")+file
		line2 = l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㧍")+line
		l11ll111lll_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㧎")+func
		l11111ll1l1_l1_ = l1l1l1111l11_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㧏")+line2+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㧐")+l11ll111lll_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭㧑")+l1llll1l1l11_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ㧒")+l11l11l1111_l1_
		l1ll11lll1l1_l1_ = line2+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㧓")+l1llll1l1l11_l1_+l11ll1_l1_ (u"࠭࡜࡯ࠩ㧔")+l11l11l1111_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㧕")+l1l1l1111l11_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㧖")+l11ll111lll_l1_
		l11l1l1l111_l1_ = line2+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㧗")+l11l11l1111_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭㧘")+l1l1l1111l11_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ㧙")+l11ll111lll_l1_
	else:
		l1l1l1111l11_l1_,line2,l11ll111lll_l1_ = l11ll1_l1_ (u"ࠬ࠭㧚"),l11ll1_l1_ (u"࠭ࠧ㧛"),l11ll1_l1_ (u"ࠧࠨ㧜")
		l11111ll1l1_l1_ = l1llll1l1l11_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㧝")+l11l11l1111_l1_
		l1ll11lll1l1_l1_ = l1llll1l1l11_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㧞")+l11l11l1111_l1_
		l11l1l1l111_l1_ = l11l11l1111_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l11ll1_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ㧟"),time=2000)
	l111l1ll1ll_l1_ = l11ll1_l1_ (u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨ㧠")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㧡")
	addons = l1111ll1l1l_l1_()
	l1ll1lllll1l_l1_ = []
	results = addons[l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㧢")]
	l1ll1ll11lll_l1_ = l1l11l1l11ll_l1_(l11llll11ll_l1_)
	if l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㧣") in list(addons.keys()):
		for l1l1lll1lll1_l1_,l1lllll1l1l1_l1_,l11l11l111l_l1_ in results: l1ll1lllll1l_l1_ = max(l1ll1lllll1l_l1_,l1lllll1l1l1_l1_)
		if l1ll1ll11lll_l1_<l1ll1lllll1l_l1_:
			header = l11ll1_l1_ (u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫ㧤")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㧥"),l11ll1_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㧦"),l11ll1_l1_ (u"ࠫฯำฯ๋อࠪ㧧"),l11ll1_l1_ (u"ࠬิั้ฮࠪ㧨"),l111l1ll1ll_l1_+header,l11111ll1l1_l1_)
			if choice==0:
				l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㧩"),l11ll1_l1_ (u"ࠧฯำ๋ะࠬ㧪"),l11ll1_l1_ (u"ࠨฬะำ๏ัࠧ㧫"),l11ll1_l1_ (u"ࠩࠪ㧬"),header)
				if l1ll111lll_l1_==1: choice = 1
			if choice==1:
				import l1l1111lll1_l1_
				l1l1111lll1_l1_.l1ll1l1l11l1_l1_()
			return
	l1l11l11l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㧭"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㧮"),l11ll1_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㧯"))
	if not l1l11l11l11l_l1_: l1l11l11l11l_l1_ = []
	l1ll11lll1l1_l1_ = l1ll11lll1l1_l1_.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ㧰"),l11ll1_l1_ (u"ࠧ࡝࡞ࡱࠫ㧱")).replace(l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㧲"),l11ll1_l1_ (u"ࠩࠪ㧳")).replace(l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㧴"),l11ll1_l1_ (u"ࠫࠬ㧵")).replace(l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㧶"),l11ll1_l1_ (u"࠭ࠧ㧷"))
	l11l1l1l111_l1_ = l11l1l1l111_l1_.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㧸"),l11ll1_l1_ (u"ࠨ࡞࡟ࡲࠬ㧹")).replace(l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ㧺"),l11ll1_l1_ (u"ࠪࠫ㧻")).replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㧼"),l11ll1_l1_ (u"ࠬ࠭㧽")).replace(l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㧾"),l11ll1_l1_ (u"ࠧࠨ㧿"))
	l1l11l1lll1l_l1_ = l11llll11ll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ㨀")+l11l1l1l111_l1_
	if l1l11l1lll1l_l1_ in l1l11l11l11l_l1_:
		header = l11ll1_l1_ (u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ㨁")
		#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㨂"),l11ll1_l1_ (u"ࠫำื่อࠩ㨃"),l11ll1_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㨄"),l111l1ll1ll_l1_+header,l11111ll1l1_l1_)
		#if l1ll111lll_l1_==1: DIALOG_OK(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㨅"),l11ll1_l1_ (u"ࠧฯำ๋ะࠬ㨆"),l11ll1_l1_ (u"ࠨࠩ㨇"),header)
		DIALOG_OK(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㨈"),l11ll1_l1_ (u"ࠪࠫ㨉"),l111l1ll1ll_l1_+header,l11111ll1l1_l1_)
		return
	l1l11ll1l111_l1_ = str(kodi_version).split(l11ll1_l1_ (u"ࠫ࠳࠭㨊"))[0]
	#l11l1l1ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ㨋"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㨌"),l11ll1_l1_ (u"ࠧࡂࡎࡏࡣࡐࡔࡏࡘࡐࡢࡉࡗࡘࡏࡓࡕࠪ㨍"))
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㨎")][6]
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㨏"),url,l11ll1_l1_ (u"ࠪࠫ㨐"),l11ll1_l1_ (u"ࠫࠬ㨑"),l11ll1_l1_ (u"ࠬ࠭㨒"),l11ll1_l1_ (u"࠭ࠧ㨓"),l11ll1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪ㨔"),False,False)
	html = response.content
	l11l1l1ll11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡕࡗࡅࡗ࡚࠺࠻ࡕࡗࡅࡗ࡚࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ㨕"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㨖"),l11ll1_l1_ (u"ࠪࡅࡑࡒ࡟ࡌࡐࡒ࡛ࡓࡥࡅࡓࡔࡒࡖࡘ࠭㨗"),l11l1l1ll11_l1_,REGULAR_CACHE)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㨘"),line+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㨙")+error+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㨚")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㨛")+l1l11ll1l111_l1_)
	for l111l1l1lll_l1_,l11l111llll_l1_,l1lll1lll1ll_l1_,l1ll11lll11l_l1_ in l11l1l1ll11_l1_:
		l111l1l1lll_l1_ = l111l1l1lll_l1_.split(l11ll1_l1_ (u"ࠨ࠭ࠪ㨜"))
		l1lll1lll1ll_l1_ = l1lll1lll1ll_l1_.split(l11ll1_l1_ (u"ࠩ࠮ࠫ㨝"))
		l1ll11lll11l_l1_ = l1ll11lll11l_l1_.split(l11ll1_l1_ (u"ࠪ࠯ࠬ㨞"))
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㨟"),str(l111l1l1lll_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㨠")+l11l111llll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㨡")+str(l1lll1lll1ll_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ㨢")+str(l1ll11lll11l_l1_))
		if line in l111l1l1lll_l1_ and error==l11l111llll_l1_ and l11llll11ll_l1_ in l1lll1lll1ll_l1_ and l1l11ll1l111_l1_ in l1ll11lll11l_l1_:
			header = l11ll1_l1_ (u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭㨣")
			l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㨤"),l11ll1_l1_ (u"ࠪาึ๎ฬࠨ㨥"),l11ll1_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㨦"),l111l1ll1ll_l1_+header,l11111ll1l1_l1_)
			if l1ll111lll_l1_==1: DIALOG_OK(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㨧"),l11ll1_l1_ (u"࠭ࠧ㨨"),l11ll1_l1_ (u"ࠧࠨ㨩"),header)
			return
	header = l11ll1_l1_ (u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㨪")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㨫"),l11ll1_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㨬"),l111l1ll1ll_l1_+header,l11111ll1l1_l1_)
	l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㨭"),l11ll1_l1_ (u"้ࠬไศࠩ㨮"),l11ll1_l1_ (u"࠭ๆฺ็ࠪ㨯"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㨰"),l11ll1_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩ㨱"))
	if l1ll111lll_l1_==1: l1l11ll1111l_l1_ = l11ll1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ㨲")
	else:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㨳"),l11ll1_l1_ (u"ࠫࠬ㨴"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㨵"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫ㨶"))
		return
	message = l1ll11lll1l1_l1_
	l1ll1ll111l1_l1_ = l11ll1_l1_ (u"ࠧࡂࡘ࠽ࠤࠬ㨷")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"ࠨ࠯ࡈࡶࡷࡵࡲࡴࠩ㨸")
	import l1l1111lll1_l1_
	succeeded = l1l1111lll1_l1_.l111ll11l11_l1_(l1ll1ll111l1_l1_,message,True,l11ll1_l1_ (u"ࠩࠪ㨹"),l11ll1_l1_ (u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗࠬ㨺"),l1l11ll1111l_l1_)
	if succeeded and l1l11ll1111l_l1_:
		l1l11l11l11l_l1_.append(l1l11l1lll1l_l1_)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㨻"),l11ll1_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㨼"),l1l11l11l11l_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㨽"))
	filename = l11ll1_l1_ (u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧ㨾")+str(time.time())+l11ll1_l1_ (u"ࠨ࠰ࡧࡥࡹ࠭㨿")
	open(filename,l11ll1_l1_ (u"ࠩࡺࡦࠬ㩀")).write(data)
	return
def l11l1lll1ll_l1_(l1111l11l11_l1_):
	if l1111l11l11_l1_:
		l1l1ll1l1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㩁"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㩂"),l11ll1_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㩃"))
		if l1l1ll1l1l1l_l1_: return l1l1ll1l1l1l_l1_
	url = l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㩄")][5]
	l1l1l1l11111_l1_ = l1l11l11l11_l1_(32)
	l1lllll1ll11_l1_ = l11lll111ll_l1_()
	l1ll1l11l111_l1_ = l1lllll1ll11_l1_.split(l11ll1_l1_ (u"ࠧ࠭ࠩ㩅"))[2]
	l1l1ll111ll1_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㩆"))
	l1lll11lll1l_l1_ = l1l11llll1ll_l1_()
	payload = {l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㩇"):l1l1l1l11111_l1_,l11ll1_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㩈"):l11llll11ll_l1_,l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㩉"):l1ll1l11l111_l1_,l11ll1_l1_ (u"ࠬ࡯ࡤࡴࠩ㩊"):l1ll111ll1ll_l1_(l1lll11lll1l_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㩋"),url,payload,l11ll1_l1_ (u"ࠧࠨ㩌"),l11ll1_l1_ (u"ࠨࠩ㩍"),l11ll1_l1_ (u"ࠩࠪ㩎"),l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨ㩏"))
	if not response.succeeded: return []
	html = response.content
	l1l1ll1l1l1l_l1_ = html.replace(l11ll1_l1_ (u"ࠫࡡࡢࡲࠨ㩐"),l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㩑")).replace(l11ll1_l1_ (u"࠭࡜࡝ࡰࠪ㩒"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㩓")).replace(l11ll1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㩔"),l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㩕")).replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭㩖"),l11ll1_l1_ (u"ࠫࡡࡴࠧ㩗"))
	l1l1ll1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ㩘"),l1l1ll1l1l1l_l1_,re.DOTALL)
	if not l1l1ll1l1l1l_l1_: return []
	l1l1ll1l1l1l_l1_ = sorted(l1l1ll1l1l1l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l11l1l111l_l1_,l1l11lll1lll_l1_,l111l1l11ll_l1_,l111l11l1l1_l1_,reason = l1l1ll1l1l1l_l1_[0]
	#if l11ll1_l1_ (u"࠭࡜࡯࠽࠾ࠫ㩙") in reason: l1ll11l11lll_l1_,l1ll11l1l111_l1_,l1ll11l1l11l_l1_ = reason.split(l11ll1_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㩚"),2)
	#else: l1ll11l11lll_l1_,l1ll11l1l111_l1_,l1ll11l1l11l_l1_ = reason,reason,reason
	l1ll11llll11_l1_ = reason if l11llll1111_l1_(l11ll1_l1_ (u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧ㩛")) else l1l11lll1lll_l1_
	settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ㩜"),l1ll11llll11_l1_)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㩝"),l11ll1_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㩞"),l1l1ll1l1l1l_l1_,REGULAR_CACHE)
	return l1l1ll1l1l1l_l1_
def SPLIT_BIGLIST(items,l1l11l1ll1ll_l1_=0,l1lll11l1111_l1_=0):
	if l1l11l1ll1ll_l1_ and not l1lll11l1111_l1_: l1lll11l1111_l1_ = len(items)//l1l11l1ll1ll_l1_
	l1ll1ll11ll1_l1_,l11ll1111l_l1_,l1ll1l11ll11_l1_ = [],-1,0
	for item in items:
		if l1ll1l11ll11_l1_%l1lll11l1111_l1_==0:
			l11ll1111l_l1_ += 1
			l1ll1ll11ll1_l1_.append([])
		l1ll1ll11ll1_l1_[l11ll1111l_l1_].append(item)
		l1ll1l11ll11_l1_ += 1
	return l1ll1ll11ll1_l1_
	l11ll1_l1_ (u"ࠧࠨࠢࠎࠌࠌࡰࡪࡴࡧࡵࡪࠣࡁࠥࡲࡥ࡯ࠪࡥ࡭࡬ࡲࡩࡴࡶࠬࠑࠏࠏࡳࡱ࡮࡬ࡸࡹ࡫ࡤࠡ࠿ࠣ࡟ࡢࠓࠊࠊࡨࡲࡶࠥ࡯ࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫ࠵࠱ࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠯࠶࠯࠺ࠎࠌࠌࠍ࡮࡬ࠠࡪ࡫ࠤࡁࡸࡶ࡬ࡪࡶࡶࡣࡨࡵࡵ࡯ࡶ࠽ࠑࠏࠏࠉࠊ࡮࡬ࡲࡪࡹ࠰ࠡ࠿ࠣࡦ࡮࡭࡬ࡪࡵࡷ࡟࠵ࡀࡩ࡯ࡶࠫࡰࡪࡴࡧࡵࡪ࠲ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵࠫࡠࠑࠏࠏࠉࠊࡦࡨࡰࠥࡨࡩࡨ࡮࡬ࡷࡹࡡ࠰࠻࡫ࡱࡸ࠭ࡲࡥ࡯ࡩࡷ࡬࠴ࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠭ࡢࠏࠍࠋࠋࠌࡩࡱࡹࡥ࠻ࠏࠍࠍࠎࠏ࡬ࡪࡰࡨࡷ࠵ࠦ࠽ࠡࡤ࡬࡫ࡱ࡯ࡳࡵࠏࠍࠍࠎࠏࡤࡦ࡮ࠣࡦ࡮࡭࡬ࡪࡵࡷࠑࠏࠏࠉࡴࡲ࡯࡭ࡹࡺࡥࡥ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳ࡫ࡳ࠱ࠫࠐࠎࠎࠏࡤࡦ࡮ࠣࡰ࡮ࡴࡥࡴ࠲ࠐࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡰ࡭࡫ࡷࡸࡪࠓࠊࠊࠤࠥࠦ㩟")
def l1111l1lll1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11ll1_l1_ (u"࠭ࡤࡶ࡯ࡰࡽࡳࡧ࡭ࡦࠩ㩠"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚ࡤ࠭㩡") not in filename or l11ll1_l1_ (u"ࠨࡏ࠶࡙ࡤ࠭㩢") not in filename: text = str(data)
	else:
		l1ll1ll11ll1_l1_ = SPLIT_BIGLIST(data,8)
		text = l11ll1_l1_ (u"ࠩࠪ㩣")
		for split in l1ll1ll11ll1_l1_:
			text += str(split)+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㩤")
		text = text.strip(l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㩥"))
	l1l111ll1ll_l1_ = zlib.compress(text)
	open(filepath,l11ll1_l1_ (u"ࠬࡽࡢࠨ㩦")).write(l1l111ll1ll_l1_)
	return
def l11l11ll111_l1_(l1l11l11111_l1_,filename):
	if l1l11l11111_l1_==l11ll1_l1_ (u"࠭ࡤࡪࡥࡷࠫ㩧"): data = {}
	elif l1l11l11111_l1_==l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㩨"): data = []
	elif l1l11l11111_l1_==l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ㩩"): data = l11ll1_l1_ (u"ࠩࠪ㩪")
	elif l1l11l11111_l1_==l11ll1_l1_ (u"ࠪ࡭ࡳࡺࠧ㩫"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l111ll1ll_l1_ = open(filepath,l11ll1_l1_ (u"ࠫࡷࡨࠧ㩬")).read()
	text = zlib.decompress(l1l111ll1ll_l1_)
	#open(l11ll1_l1_ (u"ࠬࡹ࠺࡝࡞ࡌࡔ࡙࡜࠱࠯ࡶࡻࡸࠬ㩭"),l11ll1_l1_ (u"࠭ࡷࡣࠩ㩮")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11ll1_l1_ (u"ࠧࡥࡷࡰࡱࡾࡴࡡ࡮ࡧࠪ㩯"))
	#if l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㩰") not in text: data = EVAL(l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭㩱"),text)
	if l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㩲") not in text: data = eval(text)
	else:
		l1ll1ll11ll1_l1_ = text.split(l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㩳"))
		del text
		data = []
		l111ll1ll11_l1_ = l111l1l1ll1_l1_()
		id = 0
		for split in l1ll1ll11ll1_l1_:
			#data += EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ㩴"),split)
			l111ll1ll11_l1_.l111l11l11l_l1_(str(id),eval,split)
			id += 1
		del l1ll1ll11ll1_l1_
		l111ll1ll11_l1_.l1ll111l111l_l1_()
		l111ll1ll11_l1_.l1ll111lll1l_l1_()
		l1l11lll1ll1_l1_ = list(l111ll1ll11_l1_.l1lll11l11l1_l1_.keys())
		l1l1l1l1l1l1_l1_ = sorted(l1l11lll1ll1_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l1l1l1l1l1_l1_:
			data += l111ll1ll11_l1_.l1lll11l11l1_l1_[id]
	return data
def l1ll1l1l111l_l1_(addon_id):
	l1l1ll11l1ll_l1_ = os.path.join(l1l1l1111l_l1_,l11ll1_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㩵"),addon_id,l11ll1_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ㩶"))
	try: l1lll11lllll_l1_ = open(l1l1ll11l1ll_l1_,l11ll1_l1_ (u"ࠨࡴࡥࠫ㩷")).read()
	except:
		l1ll1l11l11l_l1_ = os.path.join(l11l1lll1l1_l1_,l11ll1_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ㩸"),addon_id,l11ll1_l1_ (u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭㩹"))
		try: l1lll11lllll_l1_ = open(l1ll1l11l11l_l1_,l11ll1_l1_ (u"ࠫࡷࡨࠧ㩺")).read()
		except: return l11ll1_l1_ (u"ࠬ࠭㩻"),[]
	if kodi_version>18.99: l1lll11lllll_l1_ = l1lll11lllll_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㩼"))
	version = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽࡜࡞ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠢ࡝ࠩࡠࠫ㩽"),l1lll11lllll_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11ll1_l1_ (u"ࠨࠩ㩾"),[]
	l11ll1l1111_l1_,l111l111ll1_l1_ = version[0],l1l11l1l11ll_l1_(version[0])
	return l11ll1l1111_l1_,l111l111ll1_l1_
def l1111ll1l1l_l1_():
	l1111111l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㩿"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㪀"),l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ㪁"))
	if l1111111l1l_l1_: return l1111111l1l_l1_
	addons,l1111111l1l_l1_ = {},{}
	l1l1ll1l1lll_l1_ = [l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㪂")][0]]
	if kodi_version>17.99: l1l1ll1l1lll_l1_.append(l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㪃")][1])
	if kodi_version>18.99: l1l1ll1l1lll_l1_.append(l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㪄")][2])
	for l1l1l1lll1ll_l1_ in l1l1ll1l1lll_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㪅"),l1l1l1lll1ll_l1_,l11ll1_l1_ (u"ࠩࠪ㪆"),l11ll1_l1_ (u"ࠪࠫ㪇"),l11ll1_l1_ (u"ࠫࠬ㪈"),l11ll1_l1_ (u"ࠬ࠭㪉"),l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪ㪊"))
		if response.succeeded:
			html = response.content
			l1l11ll11l1l_l1_ = l1l1l1lll1ll_l1_.rsplit(l11ll1_l1_ (u"ࠧ࠰ࠩ㪋"),1)[0]
			l1111111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㪌"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1111l1l1ll_l1_ in l1111111lll_l1_:
				l111l111lll_l1_ = l1l11ll11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ㪍")+addon_id+l11ll1_l1_ (u"ࠪ࠳ࠬ㪎")+addon_id+l11ll1_l1_ (u"ࠫ࠲࠭㪏")+l1111l1l1ll_l1_+l11ll1_l1_ (u"ࠬ࠴ࡺࡪࡲࠪ㪐")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1111111l1l_l1_[addon_id] = []
				l1ll1l1l1l11_l1_ = l1l11l1l11ll_l1_(l1111l1l1ll_l1_)
				addons[addon_id].append((l1111l1l1ll_l1_,l1ll1l1l1l11_l1_,l111l111lll_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㪑"),str(addon_id)+l11ll1_l1_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭㪒")+str(addons[addon_id]))
		l1111111l1l_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㪓"),l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㪔"),l1111111l1l_l1_,REGULAR_CACHE)
	return l1111111l1l_l1_
	l11ll1_l1_ (u"ࠥࠦࠧࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧࠪࠏࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡲࡨࡪࡨࡥࡳࡩ࠱ࡳࡷ࡭࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡨࡲࡢࡰࡦ࡬࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷࡩࡦ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡤࡵࡥࡳࡩࡨ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡥࡦ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠲࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࠣࠤࠥ㪕")
def l1l11l1l11ll_l1_(l1111l1l1ll_l1_):
	l1ll1l1l1l11_l1_ = []
	l1ll1l11l1l_l1_ = l1111l1l1ll_l1_.split(l11ll1_l1_ (u"ࠫ࠳࠭㪖"))
	for l1l1111lll_l1_ in l1ll1l11l1l_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ㪗"),l1l1111lll_l1_,re.DOTALL)
		l1l11llll11l_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11llll11l_l1_.append(part)
		l1ll1l1l1l11_l1_.append(l1l11llll11l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㪘"),str(l1111l1l1ll_l1_)+l11ll1_l1_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭㪙")+str(l1ll1l1l1l11_l1_))
	return l1ll1l1l1l11_l1_
def l1ll11ll1l11_l1_(l1ll1l1l1l11_l1_):
	l1111l1l1ll_l1_ = l11ll1_l1_ (u"ࠨࠩ㪚")
	for l1l1111lll_l1_ in l1ll1l1l1l11_l1_:
		for part in l1l1111lll_l1_: l1111l1l1ll_l1_ += str(part)
		l1111l1l1ll_l1_ += l11ll1_l1_ (u"ࠩ࠱ࠫ㪛")
	l1111l1l1ll_l1_ = l1111l1l1ll_l1_.strip(l11ll1_l1_ (u"ࠪ࠲ࠬ㪜"))
	return l1111l1l1ll_l1_
def l1l1l1111ll1_l1_(l11l11l1l1l_l1_):
	# l1l1ll11ll1l_l1_ not l111llll1ll_l1_ l1ll1111ll1l_l1_ l1l1l1111111_l1_ addons status l1lllllll11_l1_ l11l111l1l_l1_ l111l1lll1_l1_ l1111lllll1_l1_
	#l1l11ll11lll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㪝"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㪞"),l11ll1_l1_ (u"࠭ࡅࡎࡃࡇࡣࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ㪟"))
	#if l1l11ll11lll_l1_: return l1l11ll11lll_l1_
	l1l11ll11lll_l1_ = {}
	addons = l1111ll1l1l_l1_()
	l11l1ll111l_l1_ = l1ll111l1111_l1_(l11l11l1l1l_l1_)
	for addon_id in l11l11l1l1l_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1111111l1l_l1_ = addons[addon_id]
		l1ll1lllll11_l1_,l11ll1l11l1_l1_,l1l11l111l1l_l1_ = l1111111l1l_l1_[0]
		#l1llllll1l1l_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧ㪠")+addon_id+l11ll1_l1_ (u"ࠨࠫࠪ㪡"))
		l1llllll1l1l_l1_,l111l1111ll_l1_ = l1ll1l1l111l_l1_(addon_id)
		l11l11111ll_l1_,l1lll111ll11_l1_ = l11l1ll111l_l1_[addon_id]
		l11l1llll11_l1_ = l11ll1l11l1_l1_>l111l1111ll_l1_ and l11l11111ll_l1_
		l1l11l111lll_l1_ = True
		if not l11l11111ll_l1_: l11l1l11ll1_l1_ = l11ll1_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㪢")
		elif not l1lll111ll11_l1_: l11l1l11ll1_l1_ = l11ll1_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ㪣")
		elif l11l1llll11_l1_: l11l1l11ll1_l1_ = l11ll1_l1_ (u"ࠫࡴࡲࡤࠨ㪤")
		else:
			l11l1l11ll1_l1_ = l11ll1_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ㪥")
			l1l11l111lll_l1_ = False
		l1l11ll11lll_l1_[addon_id] = (l1l11l111lll_l1_,l1llllll1l1l_l1_,l111l1111ll_l1_,l1ll1lllll11_l1_,l11ll1l11l1_l1_,l11l1l11ll1_l1_,l1l11l111l1l_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㪦"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭㪧"),l1l11ll11lll_l1_,REGULAR_CACHE)
	return l1l11ll11lll_l1_
	l11ll1_l1_ (u"ࠣࠤࠥࠑࠏࠏࠣࡪࡨࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠱࡯ࡳࡠࡧࡻ࡭ࡸࡺࠬࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡࡸࡨࡶࡸ࡯࡯࡯࠮ࡗࡶࡺ࡫ࠬࡕࡴࡸࡩࠒࠐࠉࠤࡧ࡯ࡷࡪࡀࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠬࡪࡵࡢࡩࡽ࡯ࡳࡵ࠮࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣࠫࠬ࠲ࡆࡢ࡮ࡶࡩ࠱ࡌࡡ࡭ࡵࡨࠑࠏࠏࠣࡪࡵࡢࡩࡽ࡯ࡳࡵࠢࡀࠤ࠭ࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡃࡰࡰࡧ࡚࡮ࡹࡩࡣ࡫࡯࡭ࡹࡿࠨࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠫࠪ࠭ࡂࡃ࠱ࠪࠏࠍࠍࠨ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡂࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡄࠧࠨࠏࠍࠍࠨ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦࠨࡹࡤࡰࡧ࠳࡭ࡥࡵࡅࡲࡲࡩ࡜ࡩࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠪࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡋࡶࡉࡳࡧࡢ࡭ࡧࡧࠬࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠬࠫ࠮ࡃ࠽࠲ࠫࠐࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࡳࡵࡴࠡࠪ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡣࡱࡨࠥࡴ࡯ࡵࠢ࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡫࡭࡬࡮ࡥࡴࡶࡢࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨࠍࠎ࠭ࠫࡴࡶࡵࠬ࡭࡯ࡧࡩࡧࡶࡸࡤࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨࠎࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡵ࡬ࡥࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡰ࡮ࡧ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧ࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩࠎࠏࠧࠬࡵࡷࡶ࠭ࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠋࠌࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡹࡴࡢࡶࡸࡷ࠮࠯ࠍࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡹࡩࡷࡹࡩࡰࡰࡶ࠾ࠥࠦࠧࠬࡵࡷࡶ࠭ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࠬ࠯ࠬࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡼ࡮ࡹࡴࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠪࠫࠐࠎࠎࠨࠢࠣ㪨")
def PROGRESS_UPDATE(l11l1ll111_l1_,l1llll1llll1_l1_,l111l1l1l1l_l1_=l11ll1_l1_ (u"ࠩࠪ㪩"),line2=l11ll1_l1_ (u"ࠪࠫ㪪"),l111l1l1lll_l1_=l11ll1_l1_ (u"ࠫࠬ㪫")):
	if kodi_version<19: l11l1ll111_l1_.update(l1llll1llll1_l1_,l111l1l1l1l_l1_,line2,l111l1l1lll_l1_)
	else: l11l1ll111_l1_.update(l1llll1llll1_l1_,l111l1l1l1l_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㪬")+line2+l11ll1_l1_ (u"࠭࡜࡯ࠩ㪭")+l111l1l1lll_l1_)
	return
def l1ll111l1l11_l1_(l1lll1ll1ll1_l1_):
	# l111llll1ll_l1_ it for this:  function(p,a,c,k,e,d)
	# l1lll1ll1l1l_l1_ l1l1lll111l1_l1_:  https://l1ll1ll1l1l1_l1_.io
	def l1lll11lll11_l1_(num,b,l1l1llll1ll1_l1_=l11ll1_l1_ (u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠢ㪮")):
		return ((num == 0) and l1l1llll1ll1_l1_[0]) or (l1lll11lll11_l1_(num // b, b, l1l1llll1ll1_l1_).lstrip(l1l1llll1ll1_l1_[0]) + l1l1llll1ll1_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11ll1_l1_ (u"ࠣ࡞࡟ࡦࠧ㪯") + l1lll11lll11_l1_(c, a) + l11ll1_l1_ (u"ࠤ࡟ࡠࡧࠨ㪰"),  k[c], p)
		return p
	l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_.split(l11ll1_l1_ (u"ࠪࢁ࠭࠭㪱"))[1][:-1]
	l1l1lll1l1l1_l1_ = eval(l11ll1_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬ㪲")+l1lll1ll1ll1_l1_,{l11ll1_l1_ (u"ࠬࡨࡡࡴࡧࡑࠫ㪳"):l1lll11lll11_l1_,l11ll1_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭㪴"):unpack})   #,locals())
	return l1l1lll1l1l1_l1_
def l1ll1l1l1l_l1_(url,l1ll1l1ll1ll_l1_=l11ll1_l1_ (u"ࠧࠨ㪵")):
	if l1ll1l1ll1ll_l1_==l11ll1_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧ㪶"): url = re.sub(l11ll1_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩ㪷"),lambda l11ll111l11_l1_: l11ll111l11_l1_.group(0).lower(),url)
	elif l1ll1l1ll1ll_l1_==l11ll1_l1_ (u"ࠪࡹࡵࡶࡥࡳࠩ㪸"): url = re.sub(l11ll1_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫ㪹"),lambda l11ll111l11_l1_: l11ll111l11_l1_.group(0).upper(),url)
	return url
def l1ll111l1111_l1_(l11l11l1l1l_l1_):
	installed,l1llll11ll1l_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l11111l11ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l11l11l1l1l_l1_)==1: l1111ll1l11_l1_ = l11ll1_l1_ (u"ࠬ࠮ࠢࠨ㪺")+l11l11l1l1l_l1_[0]+l11ll1_l1_ (u"࠭ࠢࠪࠩ㪻")
	else: l1111ll1l11_l1_ = str(tuple(l11l11l1l1l_l1_))
	cc.execute(l11ll1_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧ㪼")+l1111ll1l11_l1_+l11ll1_l1_ (u"ࠨࠢ࠾ࠫ㪽"))
	l1l1111ll11_l1_ = cc.fetchall()
	l11l1ll111l_l1_ = {}
	for addon_id in l11l11l1l1l_l1_: l11l1ll111l_l1_[addon_id] = (False,False)
	for addon_id,l1llll11ll1l_l1_ in l1l1111ll11_l1_:
		installed = True
		l1llll11ll1l_l1_ = l1llll11ll1l_l1_==1
		l11l1ll111l_l1_[addon_id] = (installed,l1llll11ll1l_l1_)
	conn.close()
	return l11l1ll111l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11ll1_l1_ (u"ࠩࠪ㪾")
	if file==l1l11l1l1l11_l1_: status = l111l11ll11_l1_(True,False)
	if os.path.exists(file):
		l1l111111l1_l1_ = open(file,l11ll1_l1_ (u"ࠪࡶࡧ࠭㪿")).read()
		if kodi_version>18.99: l1l111111l1_l1_ = l1l111111l1_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㫀"))
		if file==l1l11l1l1l11_l1_: results = l1l111111l1_l1_
		else:
			l1lllllll11l_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ㫁"),l1l111111l1_l1_)
			if l1lllllll11l_l1_:
				results = {}
				for key in l1lllllll11l_l1_.keys():
					results[key] = []
					for l1lll1l1l1l1_l1_ in l1lllllll11l_l1_[key]:
						type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_ = l11ll1_l1_ (u"࠭ࠧ㫂"),l11ll1_l1_ (u"ࠧࠨ㫃"),l11ll1_l1_ (u"ࠨࠩ㫄"),l11ll1_l1_ (u"ࠩࠪ㫅"),l11ll1_l1_ (u"ࠪࠫ㫆"),l11ll1_l1_ (u"ࠫࠬ㫇"),l11ll1_l1_ (u"ࠬ࠭㫈"),l11ll1_l1_ (u"࠭ࠧ㫉"),l11ll1_l1_ (u"ࠧࠨ㫊")
						type = l1lll1l1l1l1_l1_[0]
						name = l1lll1l1l1l1_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1lll1l1l1l1_l1_[2]
						mode = l1lll1l1l1l1_l1_[3]
						l111_l1_ = l1lll1l1l1l1_l1_[4]
						l1l1111_l1_ = l1lll1l1l1l1_l1_[5]
						if len(l1lll1l1l1l1_l1_)>6: text = l1lll1l1l1l1_l1_[6]
						if len(l1lll1l1l1l1_l1_)>7: context = l1lll1l1l1l1_l1_[7]
						if len(l1lll1l1l1l1_l1_)>8: l1ll1ll1l1l_l1_ = l1lll1l1l1l1_l1_[8]
						if file==favoritesfile: l1l11lll1111_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11ll1_l1_ (u"ࠨࠩ㫋"),l1ll1ll1l1l_l1_
						else: l1l11lll1111_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l1l_l1_
						results[key].append(l1l11lll1111_l1_)
			l11llll1l11_l1_ = str(results)
			if kodi_version>18.99: l11llll1l11_l1_ = l11llll1l11_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㫌"))
			open(file,l11ll1_l1_ (u"ࠪࡻࡧ࠭㫍")).write(l11llll1l11_l1_)
	return results
def l1l1lllll11_l1_(l1ll111l11l_l1_):
	l1ll111111l_l1_ = l1ll111l11l_l1_.split(l11ll1_l1_ (u"ࠫ࠲࠭㫎"),1)[0]
	l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_ = l11ll1_l1_ (u"ࠬ࠭㫏"),l11ll1_l1_ (u"࠭ࠧ㫐"),l11ll1_l1_ (u"ࠧࠨ㫑")
	if   l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㫒")		:	from l11llll_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㫓")	:	from l1l11ll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㫔")		:	from l1lllll1_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ㫕")	:	from l111l111_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㫖")	:	from l1ll11l11_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ㫗")	: 	from l1l1l1ll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㫘")	:	from l1l1l1l1l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㫙")	:	from l11l11ll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㫚")		:	from l11111lll_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ㫛")	:	from l1llllll1l_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㫜")	:	from l1lll111ll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㫝")	:	from l1ll1ll1ll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㫞")	:	from l1ll1l1lll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㫟"):	from l11l1l111l1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㫠")		:	from l1ll1l11111_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㫡")		:	from l1ll11l_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㫢")	:	from l1ll1l1llll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭㫣")	:	from l1lll11l11_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㫤")	:	from l1llllll1111_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㫥")	:	from l1llllllll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㫦")	:	from l1l1l111ll1_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㫧")	:	from l11111111_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㫨")		:	from l11l1ll11ll_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㫩")	:	from l1l1l1l1lll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㫪"):	from l1l11l1l1_l1_	import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㫫")	:	from l111lll11l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㫬")	:	from l1ll1l1ll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㫭"):	from l11lll1ll1_l1_	import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㫮")	:	from l11111ll11_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㫯")	:	from l1lll1llll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ㫰")	:	from l1lll1lll1l_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㫱")	:	from l1ll1l1l1ll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㫲")	:	from l1l1lll1lll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㫳")	:	from l1lll11ll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭㫴")		:	from l1l1lll1ll1_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠭㫵")		:	from IPTV			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,menu_namee as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡐ࠷࡚࠭㫶")		:	from l1l1l111ll1l_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㫷")	:	from l1l1l1lll1l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㫸")	:	from l11ll11ll1l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㫹")	:	from l1l1llllll11_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㫺")	:	from l1ll11llllll_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㫻")	:	from l1l1ll11llll_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㫼")	:	from l1ll1l1l11l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㫽")	:	from l1ll1l111l1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ㫾")		:	from l111l1ll1l1_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㫿")	:	from l1l1ll11l111_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㬀")	:	from l111ll11111_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㬁")	:	from l11l1llll1l_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㬂")	:	from l1l1l11lllll_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㬃")		:	from l1llll11l11l_l1_			import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㬄")	:	from l11l1l1lll1_l1_		import MENU as l1ll1111111_l1_,SEARCH as l1ll111l111_l1_,l111l1_l1_ as l1ll11llll1_l1_
	elif l1ll111111l_l1_==l11ll1_l1_ (u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㬅"):	from l11l11l11l1_l1_	import MENU as l1ll1111111_l1_
	return l1ll1111111_l1_,l1ll111l111_l1_,l1ll11llll1_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l11l111ll1_l1_,headers,l1ll_l1_):
	#l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ㬆"),l11ll1_l1_ (u"ࠬ࠭㬇"),l11ll1_l1_ (u"࠭ࠧ㬈"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㬉"),l11ll1_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤ๊์ࠠศๆศ๊ฯืๆห๋ࠢๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠣࠪ㬊"))
	#if l1ll111lll_l1_!=1: return l11ll1_l1_ (u"ࠩࠪ㬋")
	LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㬌"),l11ll1_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪ㬍")+l1l11l111ll1_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ㬎")+str(headers)+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㬏"))
	l11l1ll111_l1_ = DIALOG_PROGRESS()
	l11l1ll111_l1_.create(l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㬐"),l11ll1_l1_ (u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ㬑"))
	l11ll11l1l_l1_ = 1024*1024
	l1l1l11l1ll1_l1_ = bytes()
	chunk_size = 2*l11ll11l1l_l1_
	import requests
	response = requests.get(l1l11l111ll1_l1_,stream=True,headers=headers)
	l1l1l11llll1_l1_ = response.headers
	response.close()
	if not l1l1l11llll1_l1_:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㬒"),l11ll1_l1_ (u"ࠪࠫ㬓"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㬔"),l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨ㬕"))
		l11l1ll111_l1_.close()
	else:
		if l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ㬖") not in list(l1l1l11llll1_l1_.keys()): filesize = 0
		else: filesize = int(l1l1l11llll1_l1_[l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ㬗")])
		l11l1lllll_l1_ = str(int(1000*filesize/l11ll11l1l_l1_)/1000.0)
		l11l11l1l1_l1_ = int(filesize/chunk_size)+1
		if l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨ㬘") in list(l1l1l11llll1_l1_.keys()) and filesize>l11ll11l1l_l1_:
			l1l1l1lllll1_l1_ = True
			ranges = []
			l11l111l111_l1_ = 10
			ranges.append(str(0*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠩ࠰ࠫ㬙")+str(1*filesize//l11l111l111_l1_-1))
			ranges.append(str(1*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠪ࠱ࠬ㬚")+str(2*filesize//l11l111l111_l1_-1))
			ranges.append(str(2*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠫ࠲࠭㬛")+str(3*filesize//l11l111l111_l1_-1))
			ranges.append(str(3*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠬ࠳ࠧ㬜")+str(4*filesize//l11l111l111_l1_-1))
			ranges.append(str(4*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"࠭࠭ࠨ㬝")+str(5*filesize//l11l111l111_l1_-1))
			ranges.append(str(5*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠧ࠮ࠩ㬞")+str(6*filesize//l11l111l111_l1_-1))
			ranges.append(str(6*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠨ࠯ࠪ㬟")+str(7*filesize//l11l111l111_l1_-1))
			ranges.append(str(7*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠩ࠰ࠫ㬠")+str(8*filesize//l11l111l111_l1_-1))
			ranges.append(str(8*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠪ࠱ࠬ㬡")+str(9*filesize//l11l111l111_l1_-1))
			ranges.append(str(9*filesize//l11l111l111_l1_)+l11ll1_l1_ (u"ࠫ࠲࠭㬢"))
			l11l1l11111_l1_ = float(l11l11l1l1_l1_)/l11l111l111_l1_
			l1lll1llll11_l1_ = l11l1l11111_l1_/int(1+l11l1l11111_l1_)
		else:
			l1l1l1lllll1_l1_ = False
			l11l111l111_l1_ = 1
			l1lll1llll11_l1_ = 1
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㬣"),l11ll1_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨ㬤")+str(l1l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ㬥")+str(filesize)+l11ll1_l1_ (u"ࠨࠢࡠࠫ㬦"))
		l11ll1111l_l1_ = 0
		#t1 = time.time()-30
		for l1ll1l11ll11_l1_ in range(l11l111l111_l1_):
			l1l1ll11l_l1_ = headers
			if l1l1l1lllll1_l1_: l1l1ll11l_l1_[l11ll1_l1_ (u"ࠩࡕࡥࡳ࡭ࡥࠨ㬧")] = l11ll1_l1_ (u"ࠪࡦࡾࡺࡥࡴ࠿ࠪ㬨")+ranges[l1ll1l11ll11_l1_]
			response = requests.get(l1l11l111ll1_l1_,stream=True,headers=l1l1ll11l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1ll111_l1_.iscanceled():
					LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㬩"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭㬪"))
					break
				l11ll1111l_l1_ += l1lll1llll11_l1_
				PROGRESS_UPDATE(l11l1ll111_l1_,0+int(100*l11ll1111l_l1_/l11l11l1l1_l1_),l11ll1_l1_ (u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ㬫"),str(int(l11ll1111l_l1_*chunk_size//l11ll11l1l_l1_))+l11ll1_l1_ (u"ࠧࠡ࠱ࠣࠫ㬬")+l11l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡐࡆࠬ㬭"))
				l1l1l11l1ll1_l1_ += chunk
				#PROGRESS_UPDATE(l11l1ll111_l1_,0+int(35*l11ll1111l_l1_/l11l11l1l1_l1_),l11ll1_l1_ (u"ࠩฯ่อࠦวๅ็็ๅࠥอไาศํื๏ࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ㬮")+l11ll1_l1_ (u"ࠪࡠࡳ࠭㬯")+str(l11ll1111l_l1_*chunksize/l11ll11l1l_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ㬰")+l11l1lllll_l1_+l11ll1_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪ㬱")+time.strftime(l11ll1_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣ㬲")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㬳")+time.gmtime(l11l111l11_l1_))+l11ll1_l1_ (u"ࠨࠢใࠫ㬴"))
				#l11l11111l_l1_ = time.time()
				#l111llll1l_l1_ = l11l11111l_l1_-t1
				#l11l111111_l1_ = l111llll1l_l1_/l11ll1111l_l1_
				#l11l1l11l1_l1_ = l11l111111_l1_*(l11l11l1l1_l1_+1)
				#l11l111l11_l1_ = l11l1l11l1_l1_-l111llll1l_l1_
			response.close()
		l11l1ll111_l1_.close()
		if len(l1l1l11l1ll1_l1_)<filesize and filesize>0:
			LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㬵"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ㬶")+str(len(l1l1l11l1ll1_l1_)//l11ll11l1l_l1_)+l11ll1_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩ㬷")+l11l1lllll_l1_+l11ll1_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ㬸"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ㬹"),l11ll1_l1_ (u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬ㬺"),l11ll1_l1_ (u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨ㬻"),l11ll1_l1_ (u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫ㬼"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㬽"),l11ll1_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨ㬾")+str(len(l1l1l11l1ll1_l1_)//l11ll11l1l_l1_)+l11ll1_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫ㬿")+l11l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨ㭀"))
			if choice==2: l1l1l11l1ll1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l111ll1_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㭁"),l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ㭂"))
			else: return l11ll1_l1_ (u"ࠩࠪ㭃")
			if not l1l1l11l1ll1_l1_: return l11ll1_l1_ (u"ࠪࠫ㭄")
		else: LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㭅"),l11ll1_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ㭆")+l11l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㭇"))
	return l1l1l11l1ll1_l1_
def l1llll111111_l1_(script_name):
	# old l1llll11lll1_l1_ l1ll1l1lllll_l1_ l1l1llll11l1_l1_
	# hit method:    https://l1l11ll1111_l1_.google.com/l1l11l11lll_l1_/l1lll111ll1l_l1_/collection/protocol/l1l1llll11l1_l1_/l1lll11l1l1l_l1_
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠲ࠨࡷ࡭ࡩࡃࡕࡂ࠯࠴࠶࠼࠶࠴࠶࠳࠳࠸࠲࠻ࠦࡤ࡫ࡧࡁࠬ㭈")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"ࠨࠨࡷࡁࡪࡼࡥ࡯ࡶࠩࡷࡨࡃࡥ࡯ࡦࠩࡩࡨࡃࠧ㭉")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࡥࡻࡃࠧ㭊")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠪࠪࡦࡴ࠽ࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙࡟ࡏࡇ࡚ࡇࡑࡏࡅࡏࡖࡌࡈࠫ࡫ࡡ࠾ࠩ㭋")+script_name+l11ll1_l1_ (u"ࠫࠫ࡫࡬࠾ࠩ㭌")+str(kodi_version)+l11ll1_l1_ (u"ࠬࠬࡺ࠾ࠩ㭍")+l11llllll11_l1_
	#response = l1l111l1lll_l1_(l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㭎"),url,l11ll1_l1_ (u"ࠧࠨ㭏"),l11ll1_l1_ (u"ࠨࠩ㭐"),l11ll1_l1_ (u"ࠩࠪ㭑"),l11ll1_l1_ (u"ࠪࠫ㭒"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ㭓"))
	# new l1lll1l11l11_l1_ l1ll1l1lllll_l1_ 4
	# l1l1llll1lll_l1_ test:    https://l11l1ll1111_l1_-l111ll11l1l_l1_-l11l1111111_l1_.google/l1ll11llll1l_l1_/l11111l1111_l1_-l1l1lll1l1ll_l1_
	# l1l1llll1lll_l1_ json method:    https://l1l11ll1111_l1_.google.com/l1l11l11lll_l1_/l1lll111ll1l_l1_/collection/protocol/l1ll11llll1l_l1_/l1ll1ll1llll_l1_/l1l1llll1lll_l1_
	# l1l1llll1lll_l1_ json method:    https://l1l11ll1111_l1_.google.com/l1l11l11lll_l1_/l1lll111ll1l_l1_/collection/protocol/l1ll11llll1l_l1_/l1ll1ll1llll_l1_?l1l1l1l1111l_l1_=l1l11llll1l1_l1_
	# l1l1llll1lll_l1_ hit method:   https://www.l1lllll11lll_l1_.com/l1ll11llll1l_l1_-l11111l11l1_l1_-protocol-l1lll1ll1lll_l1_
	# l1l1llll1lll_l1_ hit method:   https://www.l1lllll11lll_l1_.com/l1l1ll1111ll_l1_-l11l11l1lll_l1_-google-l1l11l11lll_l1_-l11111l11l1_l1_-protocol-version-2
	# l1l1llll1lll_l1_ params:  https://data.l1l1l111ll11_l1_.com
	# l1l1llll1l11_l1_ json method
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡣࡰ࡯࠲ࡱࡵ࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡢࡲ࡬ࡣࡸ࡫ࡣࡳࡧࡷࡁ࠵࠳ࡶ࠲࠷ࡄࡨࡨࡘࡇࡢࡒࡪࡵࡷࡵࡧ࡭࠷࠼ࡏࡆࠬ࡭ࡦࡣࡶࡹࡷ࡫࡭ࡦࡰࡷࡣ࡮ࡪ࠽ࡈ࠯ࡕࡔ࠼ࡗ࡙ࡆࡌ࠼ࡋ࠾࠭㭔")
	#headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㭕"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ㭖")}
	#params = {l11ll1_l1_ (u"ࠨࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭㭗"):l11llll11ll_l1_,l11ll1_l1_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㭘"):kodi_version}
	#data = {l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡢ࡭ࡩ࠭㭙"):l1l11l11l11_l1_(32),l11ll1_l1_ (u"ࠫࡪࡼࡥ࡯ࡶࡶࠫ㭚"):[{l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㭛"):script_name,l11ll1_l1_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭㭜"):params}]}
	#response = l1l111l1lll_l1_(l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㭝"),url,str(data),headers,l11ll1_l1_ (u"ࠨࠩ㭞"),l11ll1_l1_ (u"ࠩࠪ㭟"),l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㭠"))
	l11ll1_l1_ (u"ࠦࠧࠨࠍࠋࠋࡨࡺࡪࡴࡴࡏࡣࡰࡩࠒࠐࠉࡢࡲࡳ࡚ࡪࡸࡳࡪࡱࡱࠑࠏࠏ࡯ࡱࡧࡵࡥࡹ࡯࡮ࡨࡕࡼࡷࡹ࡫࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠎࠌࠌࡹࡦࡶࡶࠎࠌࠌࡹࡸ࡫ࡲࡠ࡫ࡧࠑࠏࠏࡡࡱࡲࡢࡺࡪࡸࡳࡪࡱࡱࠑࠏࠏࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡠࡸࡨࡶࡸ࡯࡯࡯ࠏࠍࠍࡪࡼࡥ࡯ࡶࡢࡲࡦࡳࡥࠎࠌࠌࠦࠧࠨ㭡")
	# l1l1llll1l11_l1_ hit method (l11l11lll1_l1_ l111111ll11_l1_ l1l1l11lll1l_l1_)
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡣࡰ࡯࠲࡫࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠴ࠩࡸ࡮ࡪ࠽ࡈ࠯ࡕࡔ࠼ࡗ࡙ࡆࡌ࠼ࡋ࠾ࠬࡣࡪࡦࡀࠫ㭢")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"࠭ࠦࡠࡵࡀ࠵ࠫ࡫࡮࠾ࠩ㭣")+script_name+l11ll1_l1_ (u"ࠧࠧࡷࡳ࠲ࡦࡼ࡟ࡷࡧࡵࡁࠬ㭤")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠨࠨࡸࡴ࠳ࡱ࡯ࡥ࡫ࡢࡺࡪࡸ࠽ࠨ㭥")+str(kodi_version)
	#url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲࡫࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠴ࠩࡸ࡮ࡪ࠽ࡈ࠯ࡕࡔ࠼ࡗ࡙ࡆࡌ࠼ࡋ࠾ࠬ࡟ࡥࡤࡪࡁ࠶ࠬࡣࡪࡦࡀ࠵࠽࠻࠶࠱࠶࠻࠸࠾࠽࠮࠲࠸࠼࠴࠶࠺࠵࠵࠷࠺ࠫ㭦")
	#l11llllll11_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡠࡦࡥ࡫ࡂ࠷ࠦࡤ࡫ࡧࡁࠬ㭧")+str(l11llllll11_l1_)+l11ll1_l1_ (u"ࠫ࠳࠭㭨")+str(int(time.time()))
	#url += l11ll1_l1_ (u"ࠬࠬࡵࡢࡲࡹࡁ࠶࠿࠮࠲ࠨࡧࡸࡂࡑࡏࡅࡋࠨ࠶࠵ࡋࡍࡂࡆࠩࡩࡳࡃࡰࡢࡩࡨࡣࡻ࡯ࡥࡸࠨࡢࡩࡪࡃ࠱ࠧࡷ࡬ࡨࡂ࠸࠲࠳࠴࠰࠶࠷࠸࠲࠮࠵࠶࠷࠸ࠬ࡟ࡴࡵࡀ࠵ࠬ㭩")
	#response = l1l111l1lll_l1_(l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㭪"),url,l11ll1_l1_ (u"ࠧࠨ㭫"),l11ll1_l1_ (u"ࠨࠩ㭬"),l11ll1_l1_ (u"ࠩࠪ㭭"),l11ll1_l1_ (u"ࠪࠫ㭮"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ㭯"))
	# l1l1llll1l11_l1_ modified (not good l1l11ll1l1ll_l1_)
	#l11llllll11_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡣࡰ࡯࠲࡫࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠴ࠩࡸ࡮ࡪ࠽ࡈ࠯ࡕࡔ࠼ࡗ࡙ࡆࡌ࠼ࡋ࠾ࠬࡣࡪࡦࡀࠫ㭰")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"࠭ࠦࡠࡵࡀ࠵ࠫ࡫࡮࠾ࠩ㭱")+script_name+l11ll1_l1_ (u"ࠧࠧࡷࡳ࠲ࡦࡼ࡟ࡷࡧࡵࡁࠬ㭲")+l11llll11ll_l1_+l11ll1_l1_ (u"ࠨࠨࡸࡥࡵࡼ࠽ࠨ㭳")+str(kodi_version)+l11ll1_l1_ (u"ࠩࠩࡣࡵࡃࠧ㭴")+l11llllll11_l1_
	#l1l111l111l_l1_ = l11lll111ll_l1_()
	#l1ll1111lll1_l1_ = l1l111l111l_l1_.split(l11ll1_l1_ (u"ࠪ࠰ࠬ㭵"),1)[0]
	return response
def l11lll111ll_l1_(l1ll1111lll1_l1_=l11ll1_l1_ (u"ࠫࠬ㭶")):
	l1l1ll111lll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ㭷"),l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㭸"),l11ll1_l1_ (u"ࠧࡊࡒࡏࡓࡈࡇࡔࡊࡑࡑࠫ㭹"))
	if l1l1ll111lll_l1_: return l1l1ll111lll_l1_
	# url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡴࡱࡵࡣࡢࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ㭺")
	# l1l1llll11l1_l1_   url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡵࡽࡨࡰ࡫ࡶ࠲ࡦࡶࡰ࠰࡬ࡶࡳࡳ࠵ࠧ㭻")+l1ll1111lll1_l1_
	# l11lll11l1l_l1_   url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴ࡅ࡯ࡶࡶࡳࡹࡹࡃࡪࡴࡱࡱࠪ࡫࡯ࡥ࡭ࡦࡶࡁࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㭼")
	l1ll1111lll1_l1_,l1l1ll1l111l_l1_,l1ll1l11l111_l1_,l11ll1l1l1l_l1_,l1ll1l111lll_l1_,l1111111111_l1_,timezone = l11ll1_l1_ (u"ࠫࠬ㭽"),l11ll1_l1_ (u"ࠬ࠭㭾"),l11ll1_l1_ (u"࠭ࠧ㭿"),l11ll1_l1_ (u"ࠧࠨ㮀"),l11ll1_l1_ (u"ࠨࠩ㮁"),l11ll1_l1_ (u"ࠩࠪ㮂"),l11ll1_l1_ (u"ࠪࠫ㮃")
	url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡷࡩࡱ࠱࡭ࡸ࠵ࠧ㮄")+l1ll1111lll1_l1_+l11ll1_l1_ (u"ࠬࡅ࡯ࡶࡶࡳࡹࡹࡃࡪࡴࡱࡱࠪ࡫࡯ࡥ࡭ࡦࡶࡁ࡮ࡶࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰ࠯ࡧ࡮ࡺࡹ࠭ࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ㮅")
	response = l1l111l1lll_l1_(l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㮆"),url,l11ll1_l1_ (u"ࠧࠨ㮇"),l11ll1_l1_ (u"ࠨࠩ㮈"),l11ll1_l1_ (u"ࠩࠪ㮉"),l11ll1_l1_ (u"ࠪࠫ㮊"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㮋"))
	if not response.succeeded: l1lllll1ll11_l1_ = l1ll1111lll1_l1_+l11ll1_l1_ (u"ࠬ࠲ࠧ㮌")+l1l1ll1l111l_l1_+l11ll1_l1_ (u"࠭ࠬࠨ㮍")+l1ll1l11l111_l1_+l11ll1_l1_ (u"ࠧ࠭ࠩ㮎")+l1ll1l111lll_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ㮏")+l1111111111_l1_+l11ll1_l1_ (u"ࠩ࠯ࠫ㮐")+timezone
	else:
		html = response.content
		l111l11lll1_l1_ = EVAL(l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㮑"),html)
		if l11ll1_l1_ (u"ࠫ࡮ࡶࠧ㮒") in list(l111l11lll1_l1_.keys()): l1ll1111lll1_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"ࠬ࡯ࡰࠨ㮓")]
		if l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩ㮔") in list(l111l11lll1_l1_.keys()): l1l1ll1l111l_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ㮕")]
		if l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㮖") in list(l111l11lll1_l1_.keys()): l1ll1l11l111_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㮗")]
		if l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩ㮘") in list(l111l11lll1_l1_.keys()): l11ll1l1l1l_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ㮙")]
		if l11ll1_l1_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ㮚") in list(l111l11lll1_l1_.keys()): l1ll1l111lll_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭㮛")]
		if l11ll1_l1_ (u"ࠧࡤ࡫ࡷࡽࠬ㮜") in list(l111l11lll1_l1_.keys()): l1111111111_l1_ = l111l11lll1_l1_[l11ll1_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭㮝")]
		if l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㮞") in list(l111l11lll1_l1_.keys()):
			timezone = l111l11lll1_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㮟")][l11ll1_l1_ (u"ࠫࡺࡺࡣࠨ㮠")]
			if timezone[0] not in [l11ll1_l1_ (u"ࠬ࠳ࠧ㮡"),l11ll1_l1_ (u"࠭ࠫࠨ㮢")]: timezone = l11ll1_l1_ (u"ࠧࠬࠩ㮣")+timezone
		l1lllll1ll11_l1_ = l1ll1111lll1_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ㮤")+l1l1ll1l111l_l1_+l11ll1_l1_ (u"ࠩ࠯ࠫ㮥")+l1ll1l11l111_l1_+l11ll1_l1_ (u"ࠪ࠰ࠬ㮦")+l1ll1l111lll_l1_+l11ll1_l1_ (u"ࠫ࠱࠭㮧")+l1111111111_l1_+l11ll1_l1_ (u"ࠬ࠲ࠧ㮨")+timezone
		if kodi_version>18.99: l1lllll1ll11_l1_ = l1lllll1ll11_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮩")).decode(l11ll1_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㮪"))
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㮫"),l11ll1_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭㮬"),l1lllll1ll11_l1_,l1ll1lll1_l1_)
	return l1lllll1ll11_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11ll1_l1_ (u"ࠪࠫ㮭"),True
	if search.count(l11ll1_l1_ (u"ࠫࡤ࠭㮮"))>=2:
		search,options = search.split(l11ll1_l1_ (u"ࠬࡥࠧ㮯"),1)
		options = l11ll1_l1_ (u"࠭࡟ࠨ㮰")+options
		if l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ㮱") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㮲"),l11ll1_l1_ (u"ࠩࠪ㮳"),search,options)
	return search,options,l1ll_l1_
def l1l11llll1ll_l1_():
	l1l1ll111ll1_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㮴"))
	l1lll11lll1l_l1_ = 0
	if os.path.exists(l1l1ll111ll1_l1_):
		for filename in os.listdir(l1l1ll111ll1_l1_):
			if l11ll1_l1_ (u"ࠫ࠳ࡶࡹࡰࠩ㮵") in filename: continue
			if l11ll1_l1_ (u"ࠬࡥ࡟ࡱࡻࡦࡥࡨ࡮ࡥࡠࡡࠪ㮶") in filename: continue
			l1l11l1l11_l1_ = os.path.join(l1l1ll111ll1_l1_,filename)
			size,count = l1l1l11lll_l1_(l1l11l1l11_l1_)
			l1lll11lll1l_l1_ += size
	return l1lll11lll1l_l1_
def l111l11ll11_l1_(l1111l11l11_l1_,l1ll_l1_):
	url = l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㮷")][3]
	l1l1l1l11111_l1_ = l1l11l11l11_l1_(32)
	l1lllll1ll11_l1_ = l11lll111ll_l1_()
	l1ll1l11l111_l1_ = l1lllll1ll11_l1_.split(l11ll1_l1_ (u"ࠧ࠭ࠩ㮸"))[2]
	l1lll11lll1l_l1_ = l1l11llll1ll_l1_()
	payload = {l11ll1_l1_ (u"ࠨࡷࡶࡩࡷ࠭㮹"):l1l1l1l11111_l1_,l11ll1_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ㮺"):l11llll11ll_l1_,l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㮻"):l1ll1l11l111_l1_,l11ll1_l1_ (u"ࠫ࡮ࡪࡳࠨ㮼"):l1ll111ll1ll_l1_(l1lll11lll1l_l1_)}
	if not l1111l11l11_l1_: DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ㮽"),(l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㮾"),url,payload,l11ll1_l1_ (u"ࠧࠨ㮿"),l11ll1_l1_ (u"ࠨࠩ㯀"),l11ll1_l1_ (u"ࠩࠪ㯁")))
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㯂"),l11ll1_l1_ (u"ࠫࠬ㯃"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ㯄"),url,payload,l11ll1_l1_ (u"࠭ࠧ㯅"),l11ll1_l1_ (u"ࠧࠨ㯆"),l11ll1_l1_ (u"ࠨࠩ㯇"),l11ll1_l1_ (u"ࠩࡐࡉࡓ࡛ࡓ࠮ࡕࡋࡓ࡜ࡥࡍࡆࡕࡖࡅࡌࡋࡓ࠮࠳ࡶࡸࠬ㯈"),True,True)
	if not response.succeeded: l11l1ll1l11_l1_ = l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㯉")
	else:
		l11llllllll_l1_,l1llllll1l11_l1_,l1llllllllll_l1_,l1llllll1ll1_l1_ = l11ll1_l1_ (u"ࠫࠬ㯊"),l11ll1_l1_ (u"ࠬ࠭㯋"),l11ll1_l1_ (u"࠭ࠧ㯌"),[]
		newfile = response.content
		if newfile:
			l1llllll1ll1_l1_ = EVAL(l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㯍"),newfile)
			for l1lll11111ll_l1_,l1l1ll1ll111_l1_,message in l1llllll1ll1_l1_:
				if kodi_version>18.99: message = message.encode(l11ll1_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㯎")).decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㯏"))
				if l1lll11111ll_l1_==l11ll1_l1_ (u"ࠪ࠴ࠬ㯐"): l11llllllll_l1_ += message+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ㯑")
				else: l1llllll1l11_l1_ += message+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㯒")
			l1llllll1l11_l1_ = l1llllll1l11_l1_.strip(l11ll1_l1_ (u"࠭࡜࡯ࠩ㯓"))
			l11llllllll_l1_ = l11llllllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠻࠼ࠪ㯔"))
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㯕"),l11llllllll_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㯖"),l1ll111ll1ll_l1_(now))
		if os.path.exists(l1l11l1l1l11_l1_): l1llllllllll_l1_ = open(l1l11l1l1l11_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭㯗")).read()
		if kodi_version>18.99: l1llllll1l11_l1_ = l1llllll1l11_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㯘"))
		if l1llllll1l11_l1_==l1llllllllll_l1_: l11l1ll1l11_l1_ = l11ll1_l1_ (u"ࠬࡕࡌࡅࠩ㯙")
		else:
			l11l1ll1l11_l1_ = l11ll1_l1_ (u"࠭ࡎࡆ࡙ࠪ㯚")
			open(l1l11l1l1l11_l1_,l11ll1_l1_ (u"ࠧࡸࡤࠪ㯛")).write(l1llllll1l11_l1_)
		if l1ll_l1_:
			l11l1ll1l11_l1_ = l11ll1_l1_ (u"ࠨࡑࡏࡈࠬ㯜")
			l1llllll1ll1_l1_ = sorted(l1llllll1ll1_l1_,reverse=True,key=lambda key: int(key[0]))
			l1lllllllll1_l1_ = l11ll1_l1_ (u"ࠩࠪ㯝")
			for l1lll11111ll_l1_,l1l1ll1ll111_l1_,message in l1llllll1ll1_l1_:
				if kodi_version>18.99: message = message.encode(l11ll1_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㯞")).decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㯟"))
				if l1lllllllll1_l1_: l1lllllllll1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭㯠")
				if l1lll11111ll_l1_==l11ll1_l1_ (u"࠭࠰ࠨ㯡"): continue
				date = message.split(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㯢"))[0]
				l1lll1l11_l1_ = l11ll1_l1_ (u"ࠨࠩ㯣")
				if l1l1ll1ll111_l1_:
					l1lll1l11_l1_ = l11ll1_l1_ (u"ࠩิืฬ๊ษࠡะสูฮࠦไไࠢไๆ฼࠭㯤")
					if kodi_version>18.99: l1lll1l11_l1_ = l1lll1l11_l1_.encode(l11ll1_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㯥")).decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㯦"))
				l1lllllllll1_l1_ += message.replace(date,l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㯧")+date+l1lll1l11_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㯨"))+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㯩")
			l1lllllllll1_l1_ = escapeUNICODE(l1lllllllll1_l1_)
			l11ll1l11l_l1_(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㯪"),l11ll1_l1_ (u"ࠩิืฬฬไࠡ็้ࠤฬ๊ๅษำ่ะࠥหไ๊่ࠢืฯิฯๆ์ࠣห้ฮั็ษ่ะࠬ㯫"),l1lllllllll1_l1_,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㯬"))
	if l1ll_l1_ or l11l1ll1l11_l1_!=l11ll1_l1_ (u"ࠫࡓࡋࡗࠨ㯭"):
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㯮"),l11l1ll1l11_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㯯"))
	return l11l1ll1l11_l1_
def l11l1lll1l_l1_(url,l1l1l1l1_l1_=l11ll1_l1_ (u"ࠧࠨ㯰")):
	l111lll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࡟࠲ࡦࡼࡩࡽ࡞࠱ࡸࡸࢂ࡜࠯࡯ࡳ࠸ࢁࡢ࠮࡮࠵ࡸࢀࡡ࠴࡭࠴ࡷ࠻ࢀࡡ࠴࡭ࡱࡦࡿࡠ࠳ࡳ࡫ࡷࡾ࡟࠲࡫ࡲࡶࡽ࡞࠱ࡱࡵ࠹ࡼ࡝࠰ࡺࡩࡧࡳࠩࠩࡾ࡟ࡃ࠳࠰࠿ࡽ࠱࡟ࡃ࠳࠰࠿ࡽ࡞ࡿ࠲࠯ࡅࠩࠥࠩ㯱"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111lll1ll_l1_: l111lll1ll_l1_ = l111lll1ll_l1_[0][0]
	else: l111lll1ll_l1_ = l11ll1_l1_ (u"ࠩࠪ㯲")
	return l111lll1ll_l1_
	#elif not l111lll1ll_l1_ and l11ll1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㯳") in l1l1l1l1_l1_: l111lll1ll_l1_ = l11ll1_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㯴")
	#elif not l111lll1ll_l1_ and l11ll1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㯵") in l1l1l1l1_l1_: l111lll1ll_l1_ = l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ㯶")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l1l1ll1l1l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l1l1ll1l1l_l1_ = False
	l11l11111l_l1_ = time.time()
	if l1l1l1ll1l1l_l1_: resp = l11l11111l_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ㯷"),l11ll1_l1_ (u"ࠨࠩ㯸"),l11ll1_l1_ (u"ࠩࠪ㯹"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㯺"),l11ll1_l1_ (u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪ㯻"))
	else: l1ll111lll_l1_ = True
	if l1ll111lll_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11ll1_l1_ (u"ࠬ࠴ࡤࡣࠩ㯼")) and l11ll1_l1_ (u"࠭ࡤࡢࡶࡤࠫ㯽") in filename:
				l1l1ll11l1_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l11lll11l_l1_(l1l1ll11l1_l1_)
				except: return
				cc.execute(l11ll1_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪ㯾"))
				cc.execute(l11ll1_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫ㯿"))
				cc.execute(l11ll1_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪ㰀"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㰁"),l11ll1_l1_ (u"ࠫࠬ㰂"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㰃"),l11ll1_l1_ (u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧ㰄"))
	return
def l1ll111lllll_l1_(word):
	if l11ll1_l1_ (u"ࠧ࡜ࠩ㰅") in word and l11ll1_l1_ (u"ࠨ࡟ࠪ㰆") in word:
		l11l11ll1ll_l1_ = [l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㰇"),l11ll1_l1_ (u"ࠪ࡟࠴ࡘࡔࡍ࡟ࠪ㰈"),l11ll1_l1_ (u"ࠫࡠ࠵ࡌࡆࡈࡗࡡࠬ㰉"),l11ll1_l1_ (u"ࠬࡡ࠯ࡓࡋࡊࡌ࡙ࡣࠧ㰊"),l11ll1_l1_ (u"࡛࠭࠰ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ㰋"),l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㰌"),l11ll1_l1_ (u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨ㰍"),l11ll1_l1_ (u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ㰎"),l11ll1_l1_ (u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ㰏")]
		l11l1111ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠴ࠪࡀ࡞ࡠࠫ㰐"),word,re.DOTALL)
		l11l1111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠩࠣࠤ࠰࠭ࡃࡡࡣࠧ㰑"),word,re.DOTALL)
		l1l1ll1l1l11_l1_ = l11l11ll1ll_l1_+l11l1111ll1_l1_+l11l1111lll_l1_
		for tag in l1l1ll1l1l11_l1_: word = word.replace(tag,l11ll1_l1_ (u"࠭ࠧ㰒"))
	return word
def l1lll1111ll1_l1_(l11ll1ll1l1_l1_,l1llll1l1ll1_l1_,l1ll1l1ll11l_l1_,l1l1lllll111_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l11l11l1ll1_l1_,l111ll111l1_l1_,l1l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠧࠨ㰓"),0,15000
	l11ll1ll1l1_l1_ = l11ll1ll1l1_l1_.replace(l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ㰔"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠥࠦࠧࠬ㰕"))
	l1l11ll1lll1_l1_ = PIL.ImageFont.truetype(l1llll1lll11_l1_,size=l1llll1l1ll1_l1_)
	l1ll1l1ll11l_l1_ -= l1llll1l1ll1_l1_*2
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠪࡖࡌࡈࡁࠨ㰖"),(l1ll1l1ll11l_l1_,99),(255,255,255,0))
	l1111l1llll_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l1l1lll1l1_l1_ in l11ll1ll1l1_l1_.splitlines():
		l111ll111l1_l1_ += l1l1lllll111_l1_
		l1llll1ll1l1_l1_,newline = 0,l11ll1_l1_ (u"ࠫࠬ㰗")
		for word in l1l1l1lll1l1_l1_.split(l11ll1_l1_ (u"ࠬࠦࠧ㰘")):
			l11111lll11_l1_ = l1ll111lllll_l1_(l11ll1_l1_ (u"࠭ࠠࠨ㰙")+word)
			l1lll11l1l11_l1_,l1111l111ll_l1_ = l1111l1llll_l1_.textsize(l11111lll11_l1_,font=l1l11ll1lll1_l1_)
			if l1llll1ll1l1_l1_+l1lll11l1l11_l1_<l1ll1l1ll11l_l1_:
				if not newline: newline += word
				else: newline += l11ll1_l1_ (u"ࠧࠡࠩ㰚")+word
				l1llll1ll1l1_l1_ += l1lll11l1l11_l1_
			else:
				if l1lll11l1l11_l1_<l1ll1l1ll11l_l1_:
					newline += l11ll1_l1_ (u"ࠨ࡞ࡱࠤࠬ㰛")+word
					l111ll111l1_l1_ += l1l1lllll111_l1_
					l1llll1ll1l1_l1_ = l1lll11l1l11_l1_
				else:
					while l1lll11l1l11_l1_>l1ll1l1ll11l_l1_:
						for l11ll1111l_l1_ in range(1,len(l11ll1_l1_ (u"ࠩࠣࠫ㰜")+word),1):
							l1111ll11l1_l1_ = l11ll1_l1_ (u"ࠪࠤࠬ㰝")+word[:l11ll1111l_l1_]
							l11111ll1l_l1_ = word[l11ll1111l_l1_:]
							l1l1l111l111_l1_ = l1ll111lllll_l1_(l1111ll11l1_l1_)
							l11l111lll1_l1_,l1111111ll1_l1_ = l1111l1llll_l1_.textsize(l1l1l111l111_l1_,font=l1l11ll1lll1_l1_)
							if l1llll1ll1l1_l1_+l11l111lll1_l1_>l1ll1l1ll11l_l1_:
								l1ll1l111l1l_l1_ = l1lll11l1l11_l1_-l11l111lll1_l1_
								newline += l1111ll11l1_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ㰞")
								l111ll111l1_l1_ += l1l1lllll111_l1_
								l1lll11l1l11_l1_ = l1ll1l111l1l_l1_
								if l1ll1l111l1l_l1_>l1ll1l1ll11l_l1_:
									l1llll1ll1l1_l1_ = 0
									word = l11111ll1l_l1_
								else:
									l1llll1ll1l1_l1_ = l1ll1l111l1l_l1_
									newline += l11111ll1l_l1_
								break
				if l111ll111l1_l1_>l1l1l11ll1l1_l1_: break
		l11l11l1ll1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㰟")+newline
		if l111ll111l1_l1_>l1l1l11ll1l1_l1_: break
	l11l11l1ll1_l1_ = l11l11l1ll1_l1_[1:]
	l11l11l1ll1_l1_ = l11l11l1ll1_l1_.replace(l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠩࠣࠤࠩ㰠"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨ㰡"))
	return l11l11l1ll1_l1_
def l111lll111l_l1_(text):
	text = text.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㰢"),l11ll1_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ㰣"))
	text = text.replace(l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ㰤"),l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳࡶ࡯ࡣࠬ㰥"))
	text = text.replace(l11ll1_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ㰦"),l11ll1_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨ㰧"))
	text = text.replace(l11ll1_l1_ (u"ࠧ࡜ࡔࡌࡋࡍ࡚࡝ࠨ㰨"),l11ll1_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ㰩"))
	text = text.replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡊࡔࡔࡆࡔࡠࠫ㰪"),l11ll1_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧ㰫"))
	text = text.replace(l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㰬"),l11ll1_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ㰭"))
	l1lll11ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭࡜࡜ࡅࡒࡐࡔࡘࠠࠩ࠰࠭ࡃ࠮ࡢ࡝ࠨ㰮"),text,re.DOTALL)
	for l1ll11lllll1_l1_ in l1lll11ll1l1_l1_: text = text.replace(l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨ㰯")+l1ll11lllll1_l1_+l11ll1_l1_ (u"ࠨ࡟ࠪ㰰"),l11ll1_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡨࡵ࡬ࡰࡴࠪ㰱")+l1ll11lllll1_l1_+l11ll1_l1_ (u"ࠪࡣࠬ㰲"))
	return text
def l1lll1l1ll11_l1_(l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text,l11111ll11l_l1_,l11l11l11ll_l1_,l1ll11ll111l_l1_,l1ll1111llll_l1_):
	l1lll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㰳"))
	if l1lll1lll11l_l1_:
		results = LANGUAGE_TRANSLATE([l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text])
		if results: l111111l111_l1_,l1l1ll11111l_l1_,l111111ll1l_l1_,header,text = results
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㰴"))
		header = header.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㰵"))
		l111111l111_l1_ = l111111l111_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㰶"))
		l1l1ll11111l_l1_ = l1l1ll11111l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㰷"))
		l111111ll1l_l1_ = l111111ll1l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㰸"))
	l1111l11lll_l1_ = 5
	l1l11ll1l1l1_l1_ = 20
	l1ll1llll1l1_l1_ = 20
	l1ll1l11l1l1_l1_ = 0
	l11ll1lll1l_l1_ = l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㰹")
	l1l1l111llll_l1_ = 0
	l1l1l1l11ll1_l1_ = 19
	l111ll1111l_l1_ = 30
	l1ll1lll11ll_l1_ = 8
	l1ll1l1111l1_l1_ = True
	l1l1ll1111l1_l1_ = 375
	l1l11lll1l1l_l1_ = 410
	l1ll1111l11l_l1_ = 50
	l1l1lllll1l1_l1_ = 280
	l1llllllll11_l1_ = 28
	l1l1l1111lll_l1_ = 5
	l1llll11l111_l1_ = 0
	l1ll1l1ll111_l1_ = 31
	l111l1111l1_l1_ = [36,32,28]
	if l11111ll11l_l1_ in [l11ll1_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㰺"),l11ll1_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㰻")]:
		if l11111ll11l_l1_==l11ll1_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ㰼"):
			l11ll1l1lll_l1_ = l11ll1_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭㰽")
			l11ll1lll1l_l1_ = l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㰾")
			l1ll1l1111l1_l1_ = True
			l1ll1l11l1l1_l1_ = 10
		else:
			l11ll1l1lll_l1_ = 97+20
			l11ll1lll1l_l1_ = l11ll1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㰿")
			l1ll1l1111l1_l1_ = False
		l111l1111l1_l1_ = [33,33,33]
		l1ll1llll1l1_l1_ = 20
		l1l11ll1l1l1_l1_ = 0
		l111ll1111l_l1_ = 20
		l1l1l1l11ll1_l1_ = 25+10
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ㱀"): l111l1111l1_l1_ = [28,24,20] ; l11ll1l1lll_l1_ = 500
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ㱁"): l111l1111l1_l1_ = [32,28,24] ; l11ll1l1lll_l1_ = 500
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ㱂"): l111l1111l1_l1_ = [36,32,28] ; l11ll1l1lll_l1_ = 500
	elif l11111ll11l_l1_==l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㱃"): l11ll1l1lll_l1_ = 740
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㱄"): l11ll1l1lll_l1_ = l11ll1_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ㱅")
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ㱆"): l111l1111l1_l1_ = [28,23,18] ; l11ll1l1lll_l1_ = 740
	elif l11111ll11l_l1_==l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㱇"): l111l1111l1_l1_ = [28,23,18] ; l11ll1l1lll_l1_ = l11ll1_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ㱈")
	l1llll1l11ll_l1_ = l111l1111l1_l1_[0]
	l111l1l11l1_l1_ = l111l1111l1_l1_[1]
	l11ll1l111l_l1_ = l111l1111l1_l1_[2]
	l1llll1lll1l_l1_ = PIL.ImageFont.truetype(l1llll1lll11_l1_,size=l1llll1l11ll_l1_)
	l1lll1111111_l1_ = PIL.ImageFont.truetype(l1llll1lll11_l1_,size=l111l1l11l1_l1_)
	l1lll11ll11l_l1_ = PIL.ImageFont.truetype(l1llll1lll11_l1_,size=l11ll1l111l_l1_)
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠬࡘࡇࡃࡃࠪ㱉"),(100,100),(255,255,255,0))
	l1111l1llll_l1_ = PIL.ImageDraw.Draw(txt)
	l11111lllll_l1_,l1ll11l111l1_l1_ = l1111l1llll_l1_.textsize(l11ll1_l1_ (u"࠭ࡈࡉࡊࠣࡆࡇࡈࠠ࠹࠺࠻ࠤ࠵࠶࠰ࠨ㱊"),font=l1lll1111111_l1_)
	l1l1l1llll1l_l1_,l11111111ll_l1_ = l1111l1llll_l1_.textsize(l11ll1_l1_ (u"ࠧࡉࡊࡋࠤࡇࡈࡂࠡ࠺࠻࠼ࠥ࠶࠰࠱ࠩ㱋"),font=l1llll1lll1l_l1_)
	l111lll1lll_l1_ = header.count(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㱌"))+1
	l11l111ll11_l1_ = l1l11ll1l1l1_l1_+l111lll1lll_l1_*(l11111111ll_l1_+l1ll1l11l1l1_l1_)-l1ll1l11l1l1_l1_
	l1l1l11ll1ll_l1_ = {l11ll1_l1_ (u"ࠩࡧࡩࡱ࡫ࡴࡦࡡ࡫ࡥࡷࡧ࡫ࡢࡶࠪ㱍"):False,l11ll1_l1_ (u"ࠪࡷࡺࡶࡰࡰࡴࡷࡣࡱ࡯ࡧࡢࡶࡸࡶࡪࡹࠧ㱎"):True,l11ll1_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࠤࡑࡏࡇࡂࡖࡘࡖࡊࠦࡁࡍࡎࡄࡌࠬ㱏"):False}
	l11l111l1ll_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l1l11ll1ll_l1_)
	if text:
		l11ll11llll_l1_ = l1ll11ll111l_l1_-l111ll1111l_l1_*2
		l1l1l1l11l11_l1_ = l1ll11l111l1_l1_+l1ll1lll11ll_l1_
		l1ll11ll1lll_l1_ = l11l111l1ll_l1_.reshape(text)
		if l1ll1l1111l1_l1_:
			l1l11l11ll11_l1_ = l1lll1111ll1_l1_(l1ll11ll1lll_l1_,l111l1l11l1_l1_,l11ll11llll_l1_,l1l1l1l11l11_l1_)
			l1lll1ll11ll_l1_ = l1ll111lllll_l1_(l1l11l11ll11_l1_)
			l1ll11ll11ll_l1_ = l1lll1ll11ll_l1_.count(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㱐"))+1
			if l1ll11ll11ll_l1_<6:
				#l1l1ll111l11_l1_ = int(0.8*l11ll11llll_l1_) if l1ll11ll11ll_l1_<4 else int(0.9*l11ll11llll_l1_)
				l1l1ll111l11_l1_ = l11ll11llll_l1_
				l1l11l11ll11_l1_ = l1lll1111ll1_l1_(l1ll11ll1lll_l1_,l111l1l11l1_l1_,l1l1ll111l11_l1_,l1l1l1l11l11_l1_)
				l1lll1ll11ll_l1_ = l1ll111lllll_l1_(l1l11l11ll11_l1_)
				l1ll11ll11ll_l1_ = l1lll1ll11ll_l1_.count(l11ll1_l1_ (u"࠭࡜࡯ࠩ㱑"))+1
			l11l1l1l1l1_l1_ = l1l1l1l11ll1_l1_+l1ll11ll11ll_l1_*l1l1l1l11l11_l1_-l1ll1lll11ll_l1_
		else:
			l11l1l1l1l1_l1_ = l1l1l1l11ll1_l1_+l1ll11l111l1_l1_
			l1lll1ll11ll_l1_ = l1ll11ll1lll_l1_.split(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㱒"))[0]
			l1l11l11ll11_l1_ = l1ll11ll1lll_l1_.split(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ㱓"))[0]
	else: l11l1l1l1l1_l1_ = l1l1l1l11ll1_l1_
	l1ll1l1l1111_l1_ = l1llll11l111_l1_+l1ll1l1ll111_l1_
	if l1ll1111llll_l1_:
		l1l1lll111ll_l1_ = l1l11lll1l1l_l1_-l1l1ll1111l1_l1_
		l1ll1l1l1111_l1_ += l1l1lll111ll_l1_
	else: l1l1lll111ll_l1_ = 0
	if l111111l111_l1_ or l1l1ll11111l_l1_ or l111111ll1l_l1_: l1ll1l1l1111_l1_ += l1ll1111l11l_l1_
	if l11ll1l1lll_l1_!=l11ll1_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ㱔"): l1111llll1l_l1_ = l11ll1l1lll_l1_
	else: l1111llll1l_l1_ = l11l111ll11_l1_+l11l1l1l1l1_l1_+l1ll1l1l1111_l1_
	l1lll1l11lll_l1_ = l1111llll1l_l1_-l11l111ll11_l1_-l1ll1l1l1111_l1_-l1l1l1l11ll1_l1_
	txt = PIL.Image.new(l11ll1_l1_ (u"ࠪࡖࡌࡈࡁࠨ㱕"),(l1ll11ll111l_l1_,l1111llll1l_l1_),(255,255,255,0))
	l1111l1llll_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l1ll11111l_l1_ and l111111l111_l1_ and l111111ll1l_l1_:
		l1llllllll11_l1_ += 105
		l1l1l1111lll_l1_ -= 110
	if header:
		l1111l1l111_l1_ = l1l11ll1l1l1_l1_
		header = bidi.algorithm.get_display(l11l111l1ll_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1ll11lll1ll_l1_ = l1111l1llll_l1_.textsize(line,font=l1llll1lll1l_l1_)
				if l11ll1lll1l_l1_==l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㱖"): l1l1ll11l11l_l1_ = l1111l11lll_l1_+(l1ll11ll111l_l1_-width)/2
				elif l11ll1lll1l_l1_==l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㱗"): l1l1ll11l11l_l1_ = l1111l11lll_l1_+l1ll11ll111l_l1_-width-l1ll1llll1l1_l1_
				elif l11ll1lll1l_l1_==l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ㱘"): l1l1ll11l11l_l1_ = l1111l11lll_l1_+l1ll1llll1l1_l1_
				l1111l1llll_l1_.text((l1l1ll11l11l_l1_,l1111l1l111_l1_),line,font=l1llll1lll1l_l1_,fill=l11ll1_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ㱙"))
			l1111l1l111_l1_ += l1llll1l11ll_l1_+l1ll1l11l1l1_l1_
	if l111111l111_l1_ or l1l1ll11111l_l1_ or l111111ll1l_l1_:
		l11l111l1l1_l1_ = l11l111ll11_l1_+l1lll1l11lll_l1_+l1l1l1l11ll1_l1_+l1l1lll111ll_l1_+l1llll11l111_l1_
		if l111111l111_l1_:
			l111111l111_l1_ = bidi.algorithm.get_display(l11l111l1ll_l1_.reshape(l111111l111_l1_))
			l1ll11l11ll1_l1_,l1111lll1l1_l1_ = l1111l1llll_l1_.textsize(l111111l111_l1_,font=l1lll11ll11l_l1_)
			l111l11111l_l1_ = l1llllllll11_l1_+0*(l1l1l1111lll_l1_+l1l1lllll1l1_l1_)+(l1l1lllll1l1_l1_-l1ll11l11ll1_l1_)/2
			l1111l1llll_l1_.text((l111l11111l_l1_,l11l111l1l1_l1_),l111111l111_l1_,font=l1lll11ll11l_l1_,fill=l11ll1_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ㱚"))
		if l1l1ll11111l_l1_:
			l1l1ll11111l_l1_ = bidi.algorithm.get_display(l11l111l1ll_l1_.reshape(l1l1ll11111l_l1_))
			l1ll1lll1l11_l1_,l1ll1l1lll1l_l1_ = l1111l1llll_l1_.textsize(l1l1ll11111l_l1_,font=l1lll11ll11l_l1_)
			l111l1l111l_l1_ = l1llllllll11_l1_+1*(l1l1l1111lll_l1_+l1l1lllll1l1_l1_)+(l1l1lllll1l1_l1_-l1ll1lll1l11_l1_)/2
			l1111l1llll_l1_.text((l111l1l111l_l1_,l11l111l1l1_l1_),l1l1ll11111l_l1_,font=l1lll11ll11l_l1_,fill=l11ll1_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ㱛"))
		if l111111ll1l_l1_:
			l111111ll1l_l1_ = bidi.algorithm.get_display(l11l111l1ll_l1_.reshape(l111111ll1l_l1_))
			l111llllll1_l1_,l111111111l_l1_ = l1111l1llll_l1_.textsize(l111111ll1l_l1_,font=l1lll11ll11l_l1_)
			l1llll111l1l_l1_ = l1llllllll11_l1_+2*(l1l1l1111lll_l1_+l1l1lllll1l1_l1_)+(l1l1lllll1l1_l1_-l111llllll1_l1_)/2
			l1111l1llll_l1_.text((l1llll111l1l_l1_,l11l111l1l1_l1_),l111111ll1l_l1_,font=l1lll11ll11l_l1_,fill=l11ll1_l1_ (u"ࠪࡽࡪࡲ࡬ࡰࡹࠪ㱜"))
	if text:
		l1l11ll111ll_l1_,l11l1111l1l_l1_ = [],[]
		l1l11l11ll11_l1_ = l111lll111l_l1_(l1l11l11ll11_l1_)
		l1l1l1l11l1l_l1_ = l1l11l11ll11_l1_.split(l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ㱝"))
		for l1l11llllll1_l1_ in l1l1l1l11l1l_l1_:
			l11l1l1llll_l1_ = l11l11l11ll_l1_
			if   l11ll1_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ㱞") in l1l11llllll1_l1_: l11l1l1llll_l1_ = l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ㱟")
			elif l11ll1_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ㱠") in l1l11llllll1_l1_: l11l1l1llll_l1_ = l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㱡")
			elif l11ll1_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭㱢") in l1l11llllll1_l1_: l11l1l1llll_l1_ = l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㱣")
			l11l1ll1lll_l1_ = l1l11llllll1_l1_
			l11l11ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢ࠲࠯ࡅ࡟ࠨ㱤"),l1l11llllll1_l1_,re.DOTALL)
			for tag in l11l11ll1ll_l1_: l11l1ll1lll_l1_ = l11l1ll1lll_l1_.replace(tag,l11ll1_l1_ (u"ࠬ࠭㱥"))
			if l11l1ll1lll_l1_==l11ll1_l1_ (u"࠭ࠧ㱦"): width,l1ll11lll1ll_l1_ = 0,l1l1l1l11l11_l1_
			else: width,l1ll11lll1ll_l1_ = l1111l1llll_l1_.textsize(l11l1ll1lll_l1_,font=l1lll1111111_l1_)
			if   l11l1l1llll_l1_==l11ll1_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㱧"): l1lllll1lll1_l1_ = l1l1l111llll_l1_+l111ll1111l_l1_
			elif l11l1l1llll_l1_==l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㱨"): l1lllll1lll1_l1_ = l1l1l111llll_l1_+l111ll1111l_l1_+l11ll11llll_l1_-width
			elif l11l1l1llll_l1_==l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㱩"): l1lllll1lll1_l1_ = l1l1l111llll_l1_+l111ll1111l_l1_+(l11ll11llll_l1_-width)/2
			if l1lllll1lll1_l1_<l111ll1111l_l1_: l1lllll1lll1_l1_ = l1l1l111llll_l1_+l111ll1111l_l1_
			l1l11ll111ll_l1_.append(l1lllll1lll1_l1_)
			l11l1111l1l_l1_.append(width)
		l1lllll1lll1_l1_ = l1l11ll111ll_l1_[0]
		l1ll11l1111l_l1_ = l1l11l11ll11_l1_.split(l11ll1_l1_ (u"ࠪࡣࡸࡹࡳࡠࠩ㱪"))
		l11ll1111l1_l1_ = (255,255,255,255)
		l1lll1111l1l_l1_ = l11ll1111l1_l1_
		l1l1l1l111l1_l1_,l1ll1ll1ll11_l1_ = 0,0
		l1llll1111ll_l1_ = False
		l11111l1l1l_l1_ = 0
		l1l1l11l1111_l1_ = l11l111ll11_l1_+l1l1l1l11ll1_l1_/2
		if l11l1l1l1l1_l1_<(l1lll1l11lll_l1_+l1l1l1l11ll1_l1_):
			l1l1l1llll11_l1_ = (l1lll1l11lll_l1_+l1l1l1l11ll1_l1_-l11l1l1l1l1_l1_)/2
			l1l1l11l1111_l1_ = l11l111ll11_l1_+l1l1l1l11ll1_l1_+l1l1l1llll11_l1_-l1ll11l111l1_l1_/2
		for line in l1ll11l1111l_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1ll1lll1l_l1_ = line.split(l11ll1_l1_ (u"ࠫࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ㱫"),1)
			l1l1ll1llll1_l1_ = line.split(l11ll1_l1_ (u"ࠬࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨ㱬"),1)
			l1l1ll1lllll_l1_ = line.split(l11ll1_l1_ (u"࠭࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ㱭"),1)
			l1l1ll1ll11l_l1_ = line.split(l11ll1_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ㱮"),1)
			l1lll11l1ll1_l1_ = line.split(l11ll1_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ㱯"),1)
			l1l1ll1ll1ll_l1_ = line.split(l11ll1_l1_ (u"ࠩࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ㱰"),1)
			l1l1ll1lll11_l1_ = line.split(l11ll1_l1_ (u"ࠪࡣࡱ࡯࡮ࡦࡥࡨࡲࡹ࡫ࡲࡠࠩ㱱"),1)
			if len(l1l1ll1lll1l_l1_)>1:
				l11111l1l1l_l1_ += 1
				line = l1l1ll1lll1l_l1_[1]
				l1l1l1l111l1_l1_ = 0
				l1lllll1lll1_l1_ = l1l11ll111ll_l1_[l11111l1l1l_l1_]
				l1ll1ll1ll11_l1_ += l1l1l1l11l11_l1_
				l1llll1111ll_l1_ = False
			elif len(l1l1ll1llll1_l1_)>1:
				line = l1l1ll1llll1_l1_[1]
				l1lll1111l1l_l1_ = line[0:8]
				l1lll1111l1l_l1_ = l11ll1_l1_ (u"ࠫࠨ࠭㱲")+l1lll1111l1l_l1_[2:]
				line = line[9:]
			elif len(l1l1ll1lllll_l1_)>1:
				line = l1l1ll1lllll_l1_[1]
				l1lll1111l1l_l1_ = l11ll1111l1_l1_
			elif len(l1l1ll1ll11l_l1_)>1:
				line = l1l1ll1ll11l_l1_[1]
				l1llll1111ll_l1_ = True
				l1l1l1l111l1_l1_ = l11l1111l1l_l1_[l11111l1l1l_l1_]
			elif len(l1lll11l1ll1_l1_)>1:
				line = l1lll11l1ll1_l1_[1]
			elif len(l1l1ll1ll1ll_l1_)>1:
				line = l1l1ll1ll1ll_l1_[1]
			elif len(l1l1ll1lll11_l1_)>1:
				line = l1l1ll1lll11_l1_[1]
			if line:
				l1l1lllll11l_l1_ = l1l1l11l1111_l1_+l1ll1ll1ll11_l1_
				line = bidi.algorithm.get_display(line)
				width,l1ll11lll1ll_l1_ = l1111l1llll_l1_.textsize(line,font=l1lll1111111_l1_)
				if l1llll1111ll_l1_: l1l1l1l111l1_l1_ -= width
				l1lllll1ll1l_l1_ = l1lllll1lll1_l1_+l1l1l1l111l1_l1_
				l1111l1llll_l1_.text((l1lllll1ll1l_l1_,l1l1lllll11l_l1_),line,font=l1lll1111111_l1_,fill=l1lll1111l1l_l1_)
				if not l1llll1111ll_l1_: l1l1l1l111l1_l1_ += width
				if l1l1lllll11l_l1_>l1lll1l11lll_l1_+l1l1l1l11l11_l1_: break
	l1lll1ll11l1_l1_ = l1l11ll1ll11_l1_.replace(l11ll1_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ㱳"),l11ll1_l1_ (u"࠭࡟ࠨ㱴")+str(time.time())+l11ll1_l1_ (u"ࠧࡠࠩ㱵"))
	l1lll1ll11l1_l1_ = l1lll1ll11l1_l1_.replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠫ㱶"),l11ll1_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ㱷")).replace(l11ll1_l1_ (u"ࠪ࠳࠴࠭㱸"),l11ll1_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ㱹"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1lll1ll11l1_l1_)
	return l1lll1ll11l1_l1_,l1111llll1l_l1_
def l1l111l1lll_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l11lll11_l1_=True,l1ll11l111ll_l1_=True):
	# should l1l1l11l11l1_l1_ ==l11ll1_l1_ (u"ࠬ࠭㱺") l1111l1l11_l1_ not l11l111l1l_l1_ it to l11ll1_l1_ (u"࠭࡮ࡰࡶࠪ㱻")
	if allow_redirects==l11ll1_l1_ (u"ࠧࠨ㱼"): allow_redirects = True
	if l1ll_l1_==l11ll1_l1_ (u"ࠨࠩ㱽"): l1ll_l1_ = True
	if l11l11lll11_l1_==l11ll1_l1_ (u"ࠩࠪ㱾"): l11l11lll11_l1_ = True
	if l1ll11l111ll_l1_==l11ll1_l1_ (u"ࠪࠫ㱿"): l1ll11l111ll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll1l11111l_l1_ = list(headers.keys())
	if l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㲀") not in l1ll1l11111l_l1_: headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㲁")] = l11ll1_l1_ (u"࠭ࡀࡁࡂࡖࡏࡎࡖ࡟ࡉࡇࡄࡈࡊࡘࡀࡁࡂࠪ㲂")
	#if l11ll1_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ㲃") not in l1ll1l11111l_l1_: headers[l11ll1_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ㲄")] = l11ll1_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࡥࡧࡩࡰࡦࡺࡥࠨ㲅")
	l111lll_l1_,l1l1l1l1l11l_l1_,l1ll11l11l1l_l1_,l1ll1111l111_l1_ = l1l1l1llllll_l1_(url)
	l1l11ll1l11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ㲆"))
	l1l1l11l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㲇"))
	l1l1ll111111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ㲈"))
	l1l11lll11l1_l1_ = (l1l1l1l1l11l_l1_==None and l1ll11l11l1l_l1_==None and l1ll1111l111_l1_==None)
	l1111l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㲉")]
	l1l1l11ll11l_l1_ = l111lll_l1_ in l1111l11l1l_l1_
	l1111ll111l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㲊")]
	l11l1l1111l_l1_ = l111lll_l1_ in l1111ll111l_l1_
	l1111ll1lll_l1_ = l1l1l11ll11l_l1_ or l11l1l1111l_l1_
	if l1l11lll11l1_l1_ and l1111ll1lll_l1_:
		if l1l1l11ll11l_l1_:
			l1lll1l111l1_l1_ = l1111l11l1l_l1_.index(l111lll_l1_)
			l1lllll1llll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㲋")][l1lll1l111l1_l1_]
			l11111l1111_l1_ = l1llllll1lll_l1_[l1lll1l111l1_l1_]
		elif l11l1l1111l_l1_:
			l1lll1l111l1_l1_ = l1111ll111l_l1_.index(l111lll_l1_)
			l1lllll1llll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ㲌")][l1lll1l111l1_l1_]
			l11111l1111_l1_ = l111l1lll11_l1_[l1lll1l111l1_l1_]
	if l1ll11l11l1l_l1_==l11ll1_l1_ (u"ࠪࠫ㲍"): l1ll11l11l1l_l1_ = l1l11ll1l11l_l1_
	elif l1ll11l11l1l_l1_==None and l1l1l11l1l11_l1_ in [l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㲎"),l11ll1_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㲏")] and l11l11lll11_l1_: l1ll11l11l1l_l1_ = l1l11ll1l11l_l1_
	if l1l1l11ll11l_l1_ or l11l1l1111l_l1_: timeout = 10
	elif l11ll1_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㲐") in source: timeout = 15
	elif l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎࠩ㲑") in source: timeout = 70
	elif l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㲒") in source: timeout = 75
	elif l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㲓") in source: timeout = 25
	elif l11ll1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㲔") in source: timeout = 20
	elif source in l1111ll1111_l1_: timeout = 10
	else: timeout = 10
	if l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㲕") in source and not data and l11ll1_l1_ (u"ࠬࠬࠧ㲖") not in l111lll_l1_ and l11ll1_l1_ (u"࠭࠿ࠨ㲗") not in l111lll_l1_: l111lll_l1_ = l111lll_l1_.rstrip(l11ll1_l1_ (u"ࠧ࠰ࠩ㲘"))+l11ll1_l1_ (u"ࠨ࠱ࠪ㲙")
	l11l1l11l1l_l1_ = (l1l1l1l1l11l_l1_!=None)
	l1ll111ll1l1_l1_ = (l1ll11l11l1l_l1_!=None and l1l1l11l1l11_l1_!=l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ㲚"))
	if l11l1l11l1l_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭㲛"),l1l1l1l1l11l_l1_)
	elif l1ll111ll1l1_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫ㲜"),l1ll11l11l1l_l1_)
	if l11l1l11l1l_l1_:
		proxies = {l11ll1_l1_ (u"ࠧ࡮ࡴࡵࡲࠥ㲝"):l1l1l1l1l11l_l1_,l11ll1_l1_ (u"ࠨࡨࡵࡶࡳࡷࠧ㲞"):l1l1l1l1l11l_l1_}
		l1lll1l1llll_l1_ = l1l1l1l1l11l_l1_
	else: proxies,l1lll1l1llll_l1_ = {},l11ll1_l1_ (u"ࠧࠨ㲟")
	if l1ll111ll1l1_l1_:
		import urllib3.util.connection as connection
		l111l11ll1l_l1_ = l1l11lllll1l_l1_(connection,l1l11ll1l11l_l1_)
	verify = True
	l1lllll1l1ll_l1_,l1llll1l1l11_l1_,l11ll111l_l1_,l11l1ll1ll1_l1_,l11l1l111ll_l1_ = allow_redirects,source,method,False,False
	if l1111ll1lll_l1_ or (method==l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㲠") and allow_redirects): l1lllll1l1ll_l1_ = False
	if l1l1l11ll11l_l1_: l11ll111l_l1_ = l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㲡")
	import requests
	for l11ll1111l_l1_ in range(7):
		succeeded = False
		try:
			if l11ll1111l_l1_: l1llll1l1l11_l1_ = l11ll1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫ㲢")
			if not l11l1l11l1l_l1_: l1l11l1111l_l1_(False,l111lll_l1_,data,headers,l1llll1l1l11_l1_,l11ll111l_l1_)
			try: response.close()
			except: pass
			l11l111_l1_ = l111lll_l1_
			response = requests.request(l11ll111l_l1_,l111lll_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lllll1l1ll_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l1ll1ll1_l1_:
					l1lll1ll1l11_l1_ = list(response.headers.keys())
					if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㲣") in l1lll1ll1l11_l1_: l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㲤")]
					elif l11ll1_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㲥") in l1lll1ll1l11_l1_: l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㲦")]
					else: l11l1ll1ll1_l1_ = True
					if l1111ll1lll_l1_ and response.status_code==307:
						l1lllll1l1ll_l1_ = allow_redirects
						l11ll111l_l1_ = method
						l11l1ll1ll1_l1_ = True
						continue
				if not l11l1ll1ll1_l1_ or allow_redirects:
					if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭㲧") not in l111lll_l1_:
						server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㲨"))
						l111lll_l1_ = server+l111lll_l1_
				if not l11l1ll1ll1_l1_ and allow_redirects:
					l111lll1ll_l1_ = l11l1lll1l_l1_(l111lll_l1_)
					if l111lll1ll_l1_ not in [l11ll1_l1_ (u"ࠪ࠲ࡦࡼࡩࠨ㲩"),l11ll1_l1_ (u"ࠫ࠳ࡺࡳࠨ㲪"),l11ll1_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ㲫"),l11ll1_l1_ (u"࠭࠮࡮࡭ࡹࠫ㲬"),l11ll1_l1_ (u"ࠧ࠯ࡨ࡯ࡺࠬ㲭"),l11ll1_l1_ (u"ࠨ࠰ࡰࡴ࠸࠭㲮"),l11ll1_l1_ (u"ࠩ࠱ࡻࡪࡨ࡭ࠨ㲯")]: continue
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11l1l111ll_l1_ = True
			l11l111_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status will write a log line: l11ll1_l1_ (u"ࠥࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࠦ㲰")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			code = -1
			if kodi_version<19: reason = str(err.message).split(l11ll1_l1_ (u"ࠫ࠿ࠦࠧ㲱"))[1]
			else: reason = str(err).split(l11ll1_l1_ (u"ࠬࡀࠠࠨ㲲"))[1]
		except requests.exceptions.ConnectionError as err:
			code = -1
			reason = l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭㲳")
			try:
				error = err.message[0]
				reason = error
				if l11ll1_l1_ (u"ࠧࡆࡴࡵࡲࡴ࠭㲴") in error: code,reason = re.findall(l11ll1_l1_ (u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥ㲵"),error)[0]
				elif l11ll1_l1_ (u"ࠩ࠯ࠤࡪࡸࡲࡰࡴࠫࠫ㲶") in error: code,reason = re.findall(l11ll1_l1_ (u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ㲷"),error)[0]
				elif error.count(l11ll1_l1_ (u"ࠫ࠿࠭㲸"))>=2: reason,code = re.findall(l11ll1_l1_ (u"ࠬࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩࠨ㲹"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			code = -1
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			code = -1
			reason = l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭㲺")
		if l1111ll1lll_l1_ and not l11l1l111ll_l1_ and code!=200:
			l111lll_l1_ = l1lllll1llll_l1_
			l11l1l111ll_l1_ = True
			continue
		break
	if l1ll11l11l1l_l1_!=None and l1l1l11l1l11_l1_!=l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ㲻"): connection.create_connection = l111l11ll1l_l1_
	if l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨ㲼") and l11l11lll11_l1_: l1ll11l11l1l_l1_ = None
	if not succeeded and l1l1l1l1l11l_l1_==None and source not in l1111ll1111_l1_:
		l1llllll11ll_l1_ = traceback.format_exc()
		sys.stderr.write(l1llllll11ll_l1_)
	else: pass
	code = int(code)
	l1ll1111l_l1_ = l1l11llll11_l1_()
	l1ll1111l_l1_.code = code
	l1ll1111l_l1_.reason = reason
	try: l1ll1111l_l1_.content = response.content
	except: l1ll1111l_l1_.content = l11ll1_l1_ (u"ࠩࠪ㲽")
	if succeeded:
		l1ll1111l_l1_.succeeded = True
		l1ll1111l_l1_.headers 	= response.headers
		l1ll1111l_l1_.cookies 	= response.cookies
		l1ll1111l_l1_.url 	= l11l111_l1_
	#if l1ll1111l_l1_.content:
	#	if l1ll1111l_l1_.headers[l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭㲾")]==l11ll1_l1_ (u"ࠫ࡬ࢀࡩࡱࠩ㲿"):
	#		buffer = _1ll1l111ll1_l1_(l1ll1111l_l1_.content)
	#		l1l11ll11111_l1_ = l1l1lll11l11_l1_.l1l1lll1111l_l1_(fileobj=buffer)
	#		l1ll1111l_l1_.content = l1l11ll11111_l1_.read()
	if kodi_version>18.99:
		try: l1ll1111l_l1_.content = l1ll1111l_l1_.content.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳀"))
		except: pass
	l1l1l11lll11_l1_ = l11ll1_l1_ (u"࠭ࠧ㳁")
	if kodi_version<19 or isinstance(l1ll1111l_l1_.content,str): l1l1l11lll11_l1_ = l1ll1111l_l1_.content.lower()
	try: response.close()
	except: pass
	l1ll1lll1111_l1_ = (l11ll1_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㳂") in l1l1l11lll11_l1_ or l11ll1_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㳃") in l1l1l11lll11_l1_) and l1l1l11lll11_l1_.count(l11ll1_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㳄"))>2 and l11ll1_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㳅") not in source
	if code==200 and l1ll1lll1111_l1_: l1ll1111l_l1_.succeeded = False
	if l1ll1111l_l1_.succeeded and l1l11lll11l1_l1_ and l1111ll1lll_l1_:
		l1ll11111_l1_ = l1l11llllll_l1_(l11111l1111_l1_)
	#if not l1ll1111l_l1_.succeeded and source in l1111ll1111_l1_:
	#	LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㳆"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡗࡱ࡭ࡲࡶ࡯ࡳࡶࡤࡲࡹࠦࡲࡦࡳࡸࡩࡸࡺࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㳇")+l111lll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㳈")+source+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㳉"))
	if not l1ll1111l_l1_.succeeded and l1l11lll11l1_l1_:
		l1ll1ll1lll1_l1_ = (l11ll1_l1_ (u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㳊") in l1l1l11lll11_l1_ and l11ll1_l1_ (u"ࠩࡵࡥࡾࠦࡩࡥ࠼ࠣࠫ㳋") in l1l1l11lll11_l1_)
		l1lllll11l1l_l1_ = (l11ll1_l1_ (u"ࠪ࠹ࠥࡹࡥࡤࠩ㳌") in l1l1l11lll11_l1_ and l11ll1_l1_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬ㳍") in l1l1l11lll11_l1_)
		l1ll1lll111l_l1_ = (code in [403] and l11ll1_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣ࠵࠵࠸࠰ࠨ㳎") in l1l1l11lll11_l1_)
		l1ll1lll11l1_l1_ = (l11ll1_l1_ (u"࠭࡟ࡤࡨࡢࡧ࡭ࡲ࡟ࠨ㳏") in l1l1l11lll11_l1_ and l11ll1_l1_ (u"ࠧࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࠫ㳐") in l1l1l11lll11_l1_)
		if   l1ll1lll1111_l1_: reason = l11ll1_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ㳑")
		elif l1ll1ll1lll1_l1_: reason = l11ll1_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪ㳒")
		elif l1lllll11l1l_l1_: reason = l11ll1_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪ㳓")
		elif l1ll1lll111l_l1_: reason = l11ll1_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡧࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠬ㳔")
		elif l1ll1lll11l1_l1_: reason = l11ll1_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧ㳕")
		else: reason = str(reason)
		#if source not in l1111ll1111_l1_ or any([l1ll1lll1111_l1_,l1ll1ll1lll1_l1_,l1lllll11l1l_l1_,l1ll1lll111l_l1_,l1ll1lll11l1_l1_]):
		LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㳖"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㳗")+str(code)+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㳘")+reason+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㳙")+source+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㳚")+l111lll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㳛"))
		l1llll1ll111_l1_ = l1111_l1_(l111lll_l1_)
		if kodi_version<19 and isinstance(l1llll1ll111_l1_,unicode): l1llll1ll111_l1_ = l1llll1ll111_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳜"))
		if l1111ll1lll_l1_: l1llll1ll111_l1_ = l1llll1ll111_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ㳝"))[-1]
		reason = str(reason)+l11ll1_l1_ (u"ࠧ࡝ࡰࠫࠤࠬ㳞")+l1llll1ll111_l1_+l11ll1_l1_ (u"ࠨࠢࠬࠫ㳟")
		if l1ll1lll1111_l1_ or l1ll1ll1lll1_l1_ or l1lllll11l1l_l1_ or l1ll1lll111l_l1_ or l1ll1lll11l1_l1_:
			code = -2
			l1ll1111l_l1_.code = code
			l1ll1111l_l1_.reason = reason
		l1ll111lll_l1_ = True
		if (l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㳠") or l1l1ll111111_l1_==l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㳡")) and (l11l11lll11_l1_ or l1ll11l111ll_l1_):
			l1ll111lll_l1_ = l1lll111l1l1_l1_(code,reason,source,l1ll_l1_)
			if l1ll111lll_l1_ and l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠫࡆ࡙ࡋࠨ㳢"): l1l1l11l1l11_l1_ = l11ll1_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㳣")
			else: l1l1l11l1l11_l1_ = l11ll1_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㳤")
			if l1ll111lll_l1_ and l1l1ll111111_l1_==l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ㳥"): l1l1ll111111_l1_ = l11ll1_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㳦")
			else: l1l1ll111111_l1_ = l11ll1_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㳧")
			settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㳨"),l1l1l11l1l11_l1_)
			settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㳩"),l1l1ll111111_l1_)
		if l1ll111lll_l1_:
			l1lllll1l11l_l1_ = True
			if code==8 and l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㳪") in l111lll_l1_ and l1lllll1l11l_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭㳫"),l11ll1_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㳬"),time=2000)
				l11l111_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠨࡾࡿࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭㳭")
				l1ll11111_l1_ = l1l111l1lll_l1_(method,l11l111_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll11111_l1_.succeeded:
					l1ll1111l_l1_ = l1ll11111_l1_
					LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㳮"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㳯")+source+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㳰")+url+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㳱"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪ㳲"),l11ll1_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㳳"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㳴"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㳵")+source+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㳶")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㳷"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ㳸"),l11ll1_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㳹"),time=2000)
			if not l1ll1111l_l1_.succeeded and l1l1ll111111_l1_ in [l11ll1_l1_ (u"ࠧࡂࡗࡗࡓࠬ㳺"),l11ll1_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㳻")] and l1ll11l111ll_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ㳼"),l11ll1_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㳽"),time=2000)
				l1ll11111_l1_ = l11l11lll1l_l1_(method,l111lll_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll11111_l1_.succeeded:
					l1ll1111l_l1_ = l1ll11111_l1_
					LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㳾"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㳿")+source+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㴀")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㴁"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ㴂"),l11ll1_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㴃"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㴄"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㴅")+source+l11ll1_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㴆")+url+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㴇"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㴈"),l11ll1_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㴉"),time=2000)
			if not l1ll1111l_l1_.succeeded and l1l1l11l1l11_l1_ in [l11ll1_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㴊"),l11ll1_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㴋")] and l11l11lll11_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭㴌"),l11ll1_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㴍"),time=2000)
				l11l111_l1_ = l111lll_l1_+l11ll1_l1_ (u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ㴎")
				l1ll11111_l1_ = l1l111l1lll_l1_(method,l11l111_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll11111_l1_.succeeded:
					l1ll1111l_l1_ = l1ll11111_l1_
					LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㴏"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ㴐")+l1l11ll1l11l_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㴑")+source+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㴒")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㴓"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠬ์ฬศฯࠣื๏ืแาࠢࡇࡒࡘ࠭㴔"),l11ll1_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㴕"),time=2000)
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㴖"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬ㴗")+l1l11ll1l11l_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㴘")+source+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㴙")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ㴚"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㴛"),l11ll1_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㴜"),time=2000)
		if l1l1ll111111_l1_==l11ll1_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㴝") or l1l1l11l1l11_l1_==l11ll1_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㴞"): l1ll_l1_ = False
		if not l1ll1111l_l1_.succeeded:
			if l1ll_l1_: l11l1lll11l_l1_ = l1lll111l1l1_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l111ll1llll_l1_ and l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭㴟") not in source:
				l1llll111l11_l1_(l11ll1_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡦࡸࡩࠥࡺ࡯ࠡࡰࡨࡸࡼࡵࡲ࡬ࠢ࡬ࡷࡸࡻࡥࡴࠢࡺ࡭ࡹ࡮࠺ࠡࠩ㴠")+source)
	if settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㴡")) not in [l11ll1_l1_ (u"ࠬࡇࡕࡕࡑࠪ㴢"),l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ㴣"),l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ㴤")]: settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㴥"),l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㴦"))
	if settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㴧")) not in [l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㴨"),l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ㴩"),l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ㴪")]: settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㴫"),l11ll1_l1_ (u"ࠨࡃࡖࡏࠬ㴬"))
	return l1ll1111l_l1_
def OPENURL_REQUESTS_CACHED(l1l111lllll_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l11lll11_l1_=True,l1ll11l111ll_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	if l1l111lllll_l1_:
		response = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ㴭"),l11ll1_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㴮"),item)
		if response.succeeded:
			l1l11l1111l_l1_(True,url,data,headers,source,method)
			return response
	response = l1l111l1lll_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l11l11lll11_l1_,l1ll11l111ll_l1_)
	if response.succeeded:
		if l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㴯") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l1l111lllll_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ㴰"),item,response,l1l111lllll_l1_)
	return response
def OPENURL_CACHED(l1l111lllll_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㴱")
	else:
		method = l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㴲")
		data = l1111_l1_(data)
		dummy,data = l1lll1l11l_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1l111lllll_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㴳"))
	html = str(html)
	return html
def l1l1l1llllll_l1_(url):
	l1l1l1ll1l11_l1_ = url.split(l11ll1_l1_ (u"ࠩࡿࢀࠬ㴴"))
	l111lll_l1_,l1l1l1l1l11l_l1_,l1ll11l11l1l_l1_,l1ll1111l111_l1_ = l1l1l1ll1l11_l1_[0],None,None,None
	for item in l1l1l1ll1l11_l1_:
		if l11ll1_l1_ (u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㴵") in item: l1l1l1l1l11l_l1_ = item.split(l11ll1_l1_ (u"ࠫࡂ࠭㴶"))[1]
		elif l11ll1_l1_ (u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨ㴷") in item: l1ll11l11l1l_l1_ = item.split(l11ll1_l1_ (u"࠭࠽ࠨ㴸"))[1]
		elif l11ll1_l1_ (u"ࠧࡎࡻࡖࡗࡑ࡛ࡲ࡭࠿ࠪ㴹") in item: l1ll1111l111_l1_ = item.split(l11ll1_l1_ (u"ࠨ࠿ࠪ㴺"))[1]
	return l111lll_l1_,l1l1l1l1l11l_l1_,l1ll11l11l1l_l1_,l1ll1111l111_l1_
def RESTORE_PATH_NAME(name):
	start,l1ll111l11l_l1_,modified = l11ll1_l1_ (u"ࠩࠪ㴻"),l11ll1_l1_ (u"ࠪࠫ㴼"),l11ll1_l1_ (u"ࠫࠬ㴽")
	name = name.replace(ltr,l11ll1_l1_ (u"ࠬ࠭㴾")).replace(rtl,l11ll1_l1_ (u"࠭ࠧ㴿"))
	tmp = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ㵀"),name,re.DOTALL)
	if tmp: start,l1ll111l11l_l1_,name = tmp[0]
	if start not in [l11ll1_l1_ (u"ࠨࠢࠪ㵁"),l11ll1_l1_ (u"ࠩ࠯ࠫ㵂"),l11ll1_l1_ (u"ࠪࠫ㵃")]: modified = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㵄")
	if l1ll111l11l_l1_: l1ll111l11l_l1_ = l11ll1_l1_ (u"ࠬࡥࠧ㵅")+l1ll111l11l_l1_+l11ll1_l1_ (u"࠭࡟ࠨ㵆")
	#datetime = re.findall(l11ll1_l1_ (u"ࠧࠩࡡ࡟ࡨࡡࡪ࡜࠯࡞ࡧࡠࡩࡥ࡜ࡥ࡞ࡧࡠ࠿ࡢࡤ࡝ࡦࡢ࠭ࠬ㵇"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11ll1_l1_ (u"ࠨࠩ㵈"))
	name = l1ll111l11l_l1_+modified+name
	return name
def l1ll1l1lll1_l1_(url,l1ll1111111l_l1_,l1ll111l1l1l_l1_,l1lll11llll1_l1_,headers={}):
	l1l11l1l1ll1_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㵉"))
	l111ll111ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ㵊")+l1ll1111111l_l1_)
	if l111ll111ll_l1_: l11l111_l1_ = url.replace(l1l11l1l1ll1_l1_,l111ll111ll_l1_)
	else:
		l11l111_l1_ = url
		l111ll111ll_l1_ = l1l11l1l1ll1_l1_
	l1ll11111_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㵋"),l11l111_l1_,l11ll1_l1_ (u"ࠬ࠭㵌"),headers,l11ll1_l1_ (u"࠭ࠧ㵍"),l11ll1_l1_ (u"ࠧࠨ㵎"),l11ll1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ㵏"))
	html = l1ll11111_l1_.content
	try: html = html.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㵐"),l11ll1_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㵑"))
	except: pass
	if not l1ll11111_l1_.succeeded or l1lll11llll1_l1_ not in html:
		l111lll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ㵒")+l1ll111l1l1l_l1_
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㵓"):l11ll1_l1_ (u"࠭ࠧ㵔")}
		l1ll1111l_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㵕"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ㵖"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ㵗"),l11ll1_l1_ (u"ࠪࠫ㵘"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧ㵙"))
		if l1ll1111l_l1_.succeeded:
			html = l1ll1111l_l1_.content
			if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㵚"),l11ll1_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭㵛"))
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡹࡷࡲ࡜ࡀࡳࡀࠬ࠳࠰࠿ࠪࠤࠪ㵜"),html,re.DOTALL)
			l1lllll11ll1_l1_ = [l111ll111ll_l1_]
			for l1lllll_l1_ in l1l1_l1_:
				if l11ll1_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱࠬ㵝") in l1lllll_l1_: continue
				l111ll111ll_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㵞"))
				if l111ll111ll_l1_ in l1lllll11ll1_l1_: continue
				if len(l1lllll11ll1_l1_)==7:
					LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㵟"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ㵠")+l1ll1111111l_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪ㵡")+l1l11l1l1ll1_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ㵢"))
					settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㵣")+l1ll1111111l_l1_,l11ll1_l1_ (u"ࠨࠩ㵤"))
					break
				l1lllll11ll1_l1_.append(l111ll111ll_l1_)
				l11l111_l1_ = url.replace(l1l11l1l1ll1_l1_,l111ll111ll_l1_)
				l1ll11111_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㵥"),l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ㵦"),headers,l11ll1_l1_ (u"ࠫࠬ㵧"),l11ll1_l1_ (u"ࠬ࠭㵨"),l11ll1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ㵩"))
				html = l1ll11111_l1_.content
				if l1ll11111_l1_.succeeded and l1lll11llll1_l1_ in html:
					LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㵪"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤ࡫ࡵࡵ࡯ࡦࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭㵫")+l1ll1111111l_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡏࡧࡺ࠾ࠥࡡࠠࠨ㵬")+l111ll111ll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨ㵭")+l1l11l1l1ll1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ㵮"))
					settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㵯")+l1ll1111111l_l1_,l111ll111ll_l1_)
					break
	return l111ll111ll_l1_,l11l111_l1_,l1ll11111_l1_
def TRANSLATE(text):
	dict = {
	 l11ll1_l1_ (u"࠭࡯࡭ࡦࠪ㵰")			:l11ll1_l1_ (u"ࠧใัํ้ࠬ㵱")
	,l11ll1_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ㵲")		:l11ll1_l1_ (u"่ࠩฮํ่แࠨ㵳")
	,l11ll1_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ㵴")		:l11ll1_l1_ (u"๊ࠫ็โ้ัࠪ㵵")
	,l11ll1_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ㵶")			:l11ll1_l1_ (u"࠭ฬ๋ัࠪ㵷")
	,l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㵸")		:l11ll1_l1_ (u"ࠨใื่ࠬ㵹")
	,l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㵺")		:l11ll1_l1_ (u"้ࠪั๊ฯࠨ㵻")
	,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㵼")		:l11ll1_l1_ (u"ࠬ็๊ะ์๋ࠫ㵽")
	,l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ㵾")			:l11ll1_l1_ (u"ࠧใ่สอࠬ㵿")
	,l11ll1_l1_ (u"ࠨࡣ࡮ࡳࡦࡳࠧ㶀")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅไา๎๊࠭㶁")
	,l11ll1_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ㶂")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨ㶃")
	,l11ll1_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧ㶄")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧ㶅")
	,l11ll1_l1_ (u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ㶆")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨ㶇")
	,l11ll1_l1_ (u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫ㶈")		:l11ll1_l1_ (u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩ㶉")
	,l11ll1_l1_ (u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧ㶊")	:l11ll1_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨ㶋")
	,l11ll1_l1_ (u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨ㶌")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫ㶍")
	,l11ll1_l1_ (u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ㶎")		:l11ll1_l1_ (u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪ㶏")
	,l11ll1_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧ㶐")	:l11ll1_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥࡼࡩࡱࠩ㶑")
	,l11ll1_l1_ (u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧ㶒")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤฬ๊ำ๋่่หࠬ㶓")
	,l11ll1_l1_ (u"ࠧࡩࡧ࡯ࡥࡱ࠭㶔")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫ㶕")
	,l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫ㶖")		:l11ll1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫ㶗")
	,l11ll1_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭㶘")		:l11ll1_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ㶙")
	,l11ll1_l1_ (u"࠭ࡳࡩࡱࡲࡪࡲࡧࡸࠨ㶚")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧ㶛")
	,l11ll1_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ㶜")		:l11ll1_l1_ (u"่ࠩ์็฿ฺࠠำหࠤุ๐๊ะࠩ㶝")
	,l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ㶞")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ็ษ๋ࠫ㶟")
	,l11ll1_l1_ (u"ࠬࡱࡡࡳࡤࡤࡰࡦࡺࡶࠨ㶠")	:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩ㶡")
	,l11ll1_l1_ (u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭㶢")	:l11ll1_l1_ (u"ࠨ็๋ห็฿๋๊ࠠอ๎ํฮࠧ㶣")
	,l11ll1_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ㶤")		:l11ll1_l1_ (u"้ࠪํู่ࠡ็ส๎ู๊ࠥๆษࠪ㶥")
	,l11ll1_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ㶦")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠫ㶧")
	,l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨ㶨")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩ㶩")
	,l11ll1_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠴ࠪ㶪")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอไฬษ้๎ࠬ㶫")
	,l11ll1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ㶬")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢห็ึอࠧ㶭")
	,l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ㶮")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧ㶯")
	,l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࡹࡼࠧ㶰")		:l11ll1_l1_ (u"ࠨ็็ๅࠬ㶱")
	,l11ll1_l1_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻࠪ㶲")		:l11ll1_l1_ (u"้้ࠪ็ࠧ㶳")
	,l11ll1_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ㶴")		:l11ll1_l1_ (u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧ㶵")
	,l11ll1_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩ㶶")	:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬ㶷")
	,l11ll1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ㶸")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠪ㶹")
	,l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ㶺")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㶻")
	,l11ll1_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ㶼")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭㶽")
	,l11ll1_l1_ (u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨ㶾")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨ㶿")
	,l11ll1_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ㷀")		:l11ll1_l1_ (u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪ㷁")
	,l11ll1_l1_ (u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬ㷂")		:l11ll1_l1_ (u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ㷃")
	,l11ll1_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ㷄")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ㷅")
	,l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㷆")	:l11ll1_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㷇")
	,l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧ㷈")	:l11ll1_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬ㷉")
	,l11ll1_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ㷊")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ㷋")
	,l11ll1_l1_ (u"ࠧࡢࡪࡺࡥࡰ࠭㷌")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ㷍")
	,l11ll1_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ㷎")		:l11ll1_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ㷏")
	,l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭㷐")		:l11ll1_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭㷑")
	,l11ll1_l1_ (u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭㷒")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩ㷓")
	,l11ll1_l1_ (u"ࠨࡤࡵࡷࡹ࡫ࡪࠨ㷔")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠษำึฮ๏าࠧ㷕")
	,l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫ㷖")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫ㷗")
	,l11ll1_l1_ (u"ࠬࡲࡡࡳࡱࡽࡥࠬ㷘")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫ㷙")
	,l11ll1_l1_ (u"ࠧࡺࡣࡴࡳࡹ࠭㷚")		:l11ll1_l1_ (u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬ㷛")
	,l11ll1_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ㷜")		:l11ll1_l1_ (u"้ࠪํู่ࠡๅอ็ํะࠧ㷝")
	,l11ll1_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ㷞")	:l11ll1_l1_ (u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧ㷟")
	,l11ll1_l1_ (u"࠭ࡤࡳࡣࡰࡥࡸ࠽ࠧ㷠")		:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧ㷡")
	,l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ㷢")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨ㷣")
	,l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬ㷤")		:l11ll1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㷥")
	,l11ll1_l1_ (u"ࠬ࡯ࡦࡪ࡮ࡰࠫ㷦")				:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪ㷧")
	,l11ll1_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠭㷨")			:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪ㷩")
	,l11ll1_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡧࡱ࡫ࡱ࡯ࡳࡩࠩ㷪")		:l11ll1_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨ㷫")
	,l11ll1_l1_ (u"ࠫࡵࡧ࡮ࡦࡶࠪ㷬")				:l11ll1_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠩ㷭")
	,l11ll1_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㷮")			:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪ㷯")
	,l11ll1_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㷰")			:l11ll1_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧ㷱")
	,l11ll1_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ㷲")				:l11ll1_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩ㷳")
	,l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭㷴")		:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭㷵")
	,l11ll1_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ㷶")	:l11ll1_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬ㷷")
	,l11ll1_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㷸")		:l11ll1_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧ㷹")
	,l11ll1_l1_ (u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧ㷺")			:l11ll1_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧ㷻")
	,l11ll1_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪ㷼")	:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧ㷽")
	,l11ll1_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫ㷾")		:l11ll1_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪ㷿")
	,l11ll1_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭㸀")		:l11ll1_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭㸁")
	,l11ll1_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㸂")			:l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧ㸃")
	,l11ll1_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬ㸄")	:l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫ㸅")
	,l11ll1_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ㸆"):l11ll1_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪ㸇")
	,l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㸈")	:l11ll1_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬ㸉")
	,l11ll1_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫ㸊")	:l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨ㸋")
	,l11ll1_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭㸌")					:l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㸍")
	,l11ll1_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭㸎")			:l11ll1_l1_ (u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨ㸏")
	,l11ll1_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪ㸐")			:l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪ㸑")
	,l11ll1_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬ㸒")			:l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧ㸓")
	,l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠭㸔")					:l11ll1_l1_ (u"ࠪࡑ࠸࡛ࠧ㸕")
	,l11ll1_l1_ (u"ࠫࡲ࠹ࡵ࠮࡮࡬ࡺࡪ࠭㸖")				:l11ll1_l1_ (u"ࠬࡓ࠳ࡖࠢๅ๊ํอสࠨ㸗")
	,l11ll1_l1_ (u"࠭࡭࠴ࡷ࠰ࡱࡴࡼࡩࡦࡵࠪ㸘")			:l11ll1_l1_ (u"ࠧࡎ࠵ࡘࠤศ็ไศ็ࠪ㸙")
	,l11ll1_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡹࡥࡳ࡫ࡨࡷࠬ㸚")			:l11ll1_l1_ (u"ࠩࡐ࠷࡚ࠦๅิๆึ่ฬะࠧ㸛")
	}
	try: result = dict[text.lower()]
	except: result = l11ll1_l1_ (u"ࠪࠫ㸜")
	return result
def l1llll111l11_l1_(message=l11ll1_l1_ (u"ࠫࠬ㸝")):
	l1ll111l1lll_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11ll1_l1_ (u"ࠬࡀ࠯ࠨ㸞")):
	return _1ll1llllll1_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l111l111l1l_l1_(l1l111lll_l1_):
	if l1l111lll_l1_ in [l11ll1_l1_ (u"࠭ࠧ㸟"),l11ll1_l1_ (u"ࠧ࠱ࠩ㸠"),0]: return l11ll1_l1_ (u"ࠨࠩ㸡")
	l1l111lll_l1_ = int(l1l111lll_l1_)
	first = l1l111lll_l1_^l1llllll_l1_
	second = l1l111lll_l1_^REGULAR_CACHE
	l1ll1llll_l1_ = l1l111lll_l1_^l1ll1lll1_l1_
	result = str(first)+str(second)+str(l1ll1llll_l1_)
	return result
def l1l1l1l1lll1_l1_(l1l111lll_l1_):
	if l1l111lll_l1_ in [l11ll1_l1_ (u"ࠩࠪ㸢"),l11ll1_l1_ (u"ࠪ࠴ࠬ㸣"),0]: return l11ll1_l1_ (u"ࠫࠬ㸤")
	l1l111lll_l1_ = str(l1l111lll_l1_)
	result = l11ll1_l1_ (u"ࠬ࠭㸥")
	if len(l1l111lll_l1_)==15:
		first,second,l1ll1llll_l1_ = l1l111lll_l1_[0:4],l1l111lll_l1_[4:9],l1l111lll_l1_[9:]
		first = int(first)^l1ll1lll1_l1_
		second = int(second)^REGULAR_CACHE
		l1ll1llll_l1_ = int(l1ll1llll_l1_)^l1llllll_l1_
		if first==second==l1ll1llll_l1_: result = str(first*60)
	return result
def l1ll111ll1ll_l1_(l1l111lll_l1_):
	if l1l111lll_l1_ in [l11ll1_l1_ (u"࠭ࠧ㸦"),l11ll1_l1_ (u"ࠧ࠱ࠩ㸧"),0]: return l11ll1_l1_ (u"ࠨࠩ㸨")
	l1l111lll_l1_ = int(l1l111lll_l1_)+63841823
	first = l1l111lll_l1_^l1llllll_l1_
	second = l1l111lll_l1_^REGULAR_CACHE
	l1ll1llll_l1_ = l1l111lll_l1_^l1ll1lll1_l1_
	result = str(first)+str(second)+str(l1ll1llll_l1_)
	return result
def l1llll11111l_l1_(l1l111lll_l1_):
	if l1l111lll_l1_ in [l11ll1_l1_ (u"ࠩࠪ㸩"),l11ll1_l1_ (u"ࠪ࠴ࠬ㸪"),0]: return l11ll1_l1_ (u"ࠫࠬ㸫")
	l1l111lll_l1_ = str(l1l111lll_l1_)
	length = int(len(l1l111lll_l1_)/3)
	first = int(l1l111lll_l1_[0:length])^l1llllll_l1_
	second = int(l1l111lll_l1_[length:2*length])^REGULAR_CACHE
	l1ll1llll_l1_ = int(l1l111lll_l1_[2*length:3*length])^l1ll1lll1_l1_
	result = l11ll1_l1_ (u"ࠬ࠭㸬")
	if first==second==l1ll1llll_l1_: result = str(int(first)-63841823)
	return result
def l1l1l11lll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11ll11_l1_(l1lll11l1lll_l1_,l1l1ll1l11l1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ㸭"),l11ll1_l1_ (u"ࠧࠨ㸮"),l11ll1_l1_ (u"ࠨࠩ㸯"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㸰"),l1lll11l1lll_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㸱")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㸲"))
		if l1ll111lll_l1_!=1: return
	error = False
	if os.path.exists(l1lll11l1lll_l1_):
		#os.chmod(l1lll11l1lll_l1_,0o777)
		for root,dirs,files in os.walk(l1lll11l1lll_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㸳"),l11ll1_l1_ (u"࠭ࠧ㸴"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㸵"),str(err))
					error = True
			if l1l1ll1l11l1_l1_:
				for dir in dirs:
					l1l11l1l11l1_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l11l1l11l1_l1_)
					except: pass
		if l1l1ll1l11l1_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㸶"),l11ll1_l1_ (u"ࠩࠪ㸷"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㸸"),l11ll1_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ㸹"))
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㸺"),l11ll1_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩ㸻"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㸼"))
	return
def l1ll111l1lll_l1_(l1llllll11ll_l1_=l11ll1_l1_ (u"ࠨࠩ㸽")):
	#if l1llllll11ll_l1_:
	#	if l11ll1_l1_ (u"ࠩࡢࡣࡋࡕࡒࡄࡇࡇࡣࡊ࡞ࡉࡕࡡࡢࠫ㸾") in l1llllll11ll_l1_:
	#		message  = l1llllll11ll_l1_.split(l11ll1_l1_ (u"ࠪࡣࡤࡌࡏࡓࡅࡈࡈࡤࡋࡘࡊࡖࡢࡣࠬ㸿"))[1]
	#		LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㹀"),l11ll1_l1_ (u"ࠬࡌࡏࡓࡅࡈࡈࠥࡋࡘࡊࡖࠣࠤࠥࠦ࠮ࠡࠢࠣࠫ㹁")+message)
	#		#sys.stderr.write(l11ll1_l1_ (u"࠭ࡆࡐࡔࡆࡉࡉࠦࡅ࡙ࡋࡗ࠾ࡡࡴࠧ㹂")+message+l11ll1_l1_ (u"ࠧ࡝ࡰࡢࠫ㹃"))
	#	else: l111l1lllll_l1_(l1llllll11ll_l1_)
	if l1llllll11ll_l1_:
		l1lll1lll11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㹄"))
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㹅"),l11ll1_l1_ (u"ࠪࠫ㹆"))
		l111l1lllll_l1_(l1llllll11ll_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㹇"),l1lll1lll11l_l1_)
	l1l11lllll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㹈"))
	if l1l11lllll_l1_==l11ll1_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ㹉"): settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㹊"),l11ll1_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ㹋"))
	elif l1l11lllll_l1_==l11ll1_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㹌"): settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㹍"),l11ll1_l1_ (u"ࠫࠬ㹎"))
	if settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㹏")) not in [l11ll1_l1_ (u"࠭ࡁࡖࡖࡒࠫ㹐"),l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ㹑"),l11ll1_l1_ (u"ࠨࡃࡖࡏࠬ㹒")]: settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㹓"),l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ㹔"))
	if settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㹕")) not in [l11ll1_l1_ (u"ࠬࡇࡕࡕࡑࠪ㹖"),l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ㹗"),l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ㹘")]: settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ㹙"),l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭㹚"))
	l11ll11111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭㹛"))
	l111l1l1l11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ㹜"))
	if l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ㹝") in str(l111l1l1l11_l1_) and l11ll11111l_l1_ in [l11ll1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ㹞"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭㹟")]:
		#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨࠩ㹠"),l11ll11111l_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭㹡"))
	#l11l11ll11l_l1_ = sys.version_info[0]
	#l111l11l111_l1_ = sys.version_info[1]
	#if l11l11ll11l_l1_==2: python_version = l11ll1_l1_ (u"ࠪ࠶࠼࠭㹢")
	#else: python_version = str(l11l11ll11l_l1_)+str(l111l11l111_l1_)
	#l11l1ll1l1l_l1_ = os.path.join(l1l111llll1_l1_,l11ll1_l1_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ㹣")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㹤"),l11ll1_l1_ (u"࠭ࠧ㹥"),l11ll1_l1_ (u"ࠧࠨ㹦"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1llllll111l_l1_,l11l11lllll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llllll111l_l1_,l11l11lllll_l1_)
	return
from EXCLUDES import *
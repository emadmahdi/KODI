# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭凶")
#l111l1ll1l1l_l1_ = [ l11ll1_l1_ (u"ࠫࡲࡿࡳࡵࡴࡨࡥࡲ࠭凷"),l11ll1_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬ凸"),l11ll1_l1_ (u"࠭ࡶࡪࡦࡥࡳࡲ࠭凹"),l11ll1_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ出") ]
l111l1ll1l1l_l1_ = []
headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ击"):l11ll1_l1_ (u"ࠩࠪ凼")}
def l11_l1_(l1llll11_l1_,source,type,url):
	#DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ีฬฮืࠡษ็้๋อำษࠩ函"),l1llll11_l1_)
	if not l1llll11_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ凾"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ凿")+source+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ刀")+type+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ刁"))
		l111lllll111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭刂"),l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ刃"),l11ll1_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ刄"))
		datetime = time.strftime(l11ll1_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ刅"),time.gmtime(now))
		line = datetime,url
		key = source+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠪ分")+l11llll11ll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠫ切")+str(kodi_version)
		message = l11ll1_l1_ (u"ࠧࠨ刈")
		if key not in list(l111lllll111_l1_.keys()): l111lllll111_l1_[key] = [line]
		else:
			if url not in str(l111lllll111_l1_[key]): l111lllll111_l1_[key].append(line)
			else: message = l11ll1_l1_ (u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭刉")
		total = 0
		for key in list(l111lllll111_l1_.keys()):
			l111lllll111_l1_[key] = list(set(l111lllll111_l1_[key]))
			total += len(l111lllll111_l1_[key])
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ刊"),l11ll1_l1_ (u"ࠪࠫ刋"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ刌"),l11ll1_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํ࠭刍")+message+l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠷ࠣๅ๏ี๊้้สฮࠬ刎")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ刏")+l11ll1_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢไ๎ࠥอไใษษ้ฮࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠫ刐")+str(total))
		if total>=5:
			l1ll111lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ刑"),l11ll1_l1_ (u"ࠪࠫ划"),l11ll1_l1_ (u"ࠫࠬ刓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ刔"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧ刕"))
			if l1ll111lll_l1_==1:
				l111lllll1l1_l1_ = l11ll1_l1_ (u"ࠧࠨ刖")
				for key in list(l111lllll111_l1_.keys()):
					l111lllll1l1_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ列")+key
					l111111lll1l_l1_ = sorted(l111lllll111_l1_[key],reverse=False,key=lambda l11llll11l1l_l1_: l11llll11l1l_l1_[0])
					for datetime,url in l111111lll1l_l1_:
						l111lllll1l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ刘")+datetime+l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠨ则")+l1111_l1_(url)
					l111lllll1l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ刚")
				import l1l1111lll1_l1_
				l1ll1ll111l1_l1_ = l11ll1_l1_ (u"ࠬࡇࡖ࠻ࠢࠪ创")+l1l11l11l11_l1_(32)+l11ll1_l1_ (u"࠭࠭ࡗ࡫ࡧࡩࡴࡹࠧ刜")
				succeeded = l1l1111lll1_l1_.l111ll11l11_l1_(l1ll1ll111l1_l1_,l11ll1_l1_ (u"ࠧࠨ初"),False,l11ll1_l1_ (u"ࠨࠩ刞"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭刟"),l11ll1_l1_ (u"ࠪࠫ删"),l111lllll1l1_l1_)
				if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ刡"),l11ll1_l1_ (u"ࠬ࠭刢"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ刣"),l11ll1_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ判"))
				else: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ別"),l11ll1_l1_ (u"ࠩࠪ刦"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭刧"),l11ll1_l1_ (u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩ刨"))
			if l1ll111lll_l1_!=-1:
				l111lllll111_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ利"),l11ll1_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ刪"))
		if l111lllll111_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ别"),l11ll1_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ刬"),l111lllll111_l1_,PERMANENT_CACHE)
		return
	l1llll11_l1_ = list(set(l1llll11_l1_))
	l1lll11l_l1_,l1llll_l1_ = l11111ll11ll_l1_(l1llll11_l1_,source)
	l111111lll11_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ刭"))
	l11111ll1lll_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ刮"))
	l111111lllll_l1_ = len(l1llll_l1_)-l111111lll11_l1_-l11111ll1lll_l1_
	l1111l111111_l1_ = l11ll1_l1_ (u"ฺ๊ࠫว่ัฬ࠾ࠬ刯")+str(l111111lll11_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩ到")+str(l11111ll1lll_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࠢࠣวำื้࠻ࠩ刱")+str(l111111lllll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ刲"),l11ll1_l1_ (u"ࠨࠩ刳"),str(l111111lll11_l1_),str(l11111ll1lll_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1111l111111_l1_, l1llll_l1_)
	if not l1llll_l1_: result,l11l11llll1l_l1_ = l11ll1_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭刴"),l11ll1_l1_ (u"ࠪࠫ刵")
	else:
		while True:
			l11l11llll1l_l1_ = l11ll1_l1_ (u"ࠫࠬ制")
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1111l111111_l1_,l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ刷")
			else:
				title = l1lll11l_l1_[l1l_l1_]
				l1lllll_l1_ = l1llll_l1_[l1l_l1_]
				#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ券"),l11ll1_l1_ (u"ࠧࠨ刹"),title,l1lllll_l1_)
				if l11ll1_l1_ (u"ࠨีํีๆืࠧ刺") in title and l11ll1_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ刻") in title:
					LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ刼"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ刽")+title+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ刾")+l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ刿"))
					import l1l1111lll1_l1_
					l1l1111lll1_l1_.MAIN(156)
					result = l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ剀")
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ剁"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ剂")+title+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ剃")+l1lllll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ剄"))
					result,l11l11llll1l_l1_,l11ll11ll1ll_l1_ = l1111l11l1l1_l1_(l1lllll_l1_,source,type)
					#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭剅"),l11ll1_l1_ (u"࠭ࠧ剆"),result,l11l11llll1l_l1_)
			if l11ll1_l1_ (u"ࠧ࡝ࡰࠪ則") not in l11l11llll1l_l1_: l11l11l11ll1_l1_,l11l11l1111_l1_ = l11l11llll1l_l1_,l11ll1_l1_ (u"ࠨࠩ剈")
			else: l11l11l11ll1_l1_,l11l11l1111_l1_ = l11l11llll1l_l1_.split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ剉"),1)
			if result in [l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ削"),l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭剋"),l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭剌"),l11ll1_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ前")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ剎"),l11ll1_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ剏"),l11ll1_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ剐")]: break
			elif result not in [l11ll1_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ剑"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ剒")]: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭剓"),l11ll1_l1_ (u"࠭ࠧ剔"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剕"),l11ll1_l1_ (u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࠫ剖")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ剗")+l11l11l11ll1_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭剘")+l11l11l1111_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ剙"),l11ll1_l1_ (u"ࠬ࠭剚"),l11ll1_l1_ (u"࠭ࠧ剛"),str(l11ll11ll1ll_l1_))
	if result==l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ剜") and len(l1lll11l_l1_)>0: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ剝"),l11ll1_l1_ (u"ࠩࠪ剞"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭剟"),l11ll1_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ剠")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ剡")+l11l11llll1l_l1_)
	elif result in [l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭剢"),l11ll1_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ剣")] and l11l11llll1l_l1_!=l11ll1_l1_ (u"ࠨࠩ剤"): DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ剥"),l11ll1_l1_ (u"ࠪࠫ剦"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ剧"),l11l11llll1l_l1_)
	#elif l11l11llll1l_l1_==l11ll1_l1_ (u"ࠬࡘࡅࡕࡗࡕࡒࡤ࡚ࡏࡠ࡛ࡒ࡙࡙࡛ࡂࡆࠩ剨"): result = l11ll11ll1ll_l1_
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡱࠤࡠ࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ࠰ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩࡠ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࡗࡩࡸࡺ࠺ࠡࠢࠣࠫ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠱࡟࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠸࡝ࠪࠌࠌࠍࡽࡨ࡭ࡤࡲ࡯ࡹ࡬࡯࡮࠯ࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࡤࡨࡩࡵ࡮ࡠࡪࡤࡲࡩࡲࡥ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭࠯ࠩࠋࠋࠌࡴࡱࡧࡹࡠ࡫ࡷࡩࡲࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬࡵࡧࡴࡩ࠿ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡃࡲࡵࡤࡦ࠿࠴࠸࠸ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࠪ࠹ࡆࡷࠧ࠶ࡈ࡬ࡽࡢ࠲ࡲࡻ࡚ࡹࡽ࠹ࡒࠩࠬࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡰ࡭ࡣࡼࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࡭ࡸ࠴࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰࡫ࡳ࡬ࡴࡴࡥ࠰࠳࠵࠷࠹࠺࠷࠯࡯ࡳ࠸ࠬ࠲ࡰ࡭ࡣࡼࡣ࡮ࡺࡥ࡮ࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไศๆ฽หฦ࠭ࠬࠨࠩࠬࠎࠎࠨࠢࠣ剩")
	return result
	#if source==l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ剪"): l111l1_l1_ = l11ll1_l1_ (u"ࠨࡊࡏࡅࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ剫")
	#elif source==l11ll1_l1_ (u"ࠩ࠷ࡌࡊࡒࡁࡍࠩ剬"): l111l1_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡎࡅࡍࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ剭")
	#elif source==l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ剮"): l111l1_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡂࡍࡐࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭副")
	#elif source==l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ剰"): l111l1_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡖࡌ࠹ࠦࠧ剱")
	#size = len(l1ll1ll1l1_l1_)
	#for i in range(0,size):
	#	title = l11l11lll1ll_l1_[i]
	#	l1lllll_l1_ = l1ll1ll1l1_l1_[i]
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ割"),l111l1_l1_+title,l1lllll_l1_,160,l11ll1_l1_ (u"ࠩࠪ剳"),l11ll1_l1_ (u"ࠪࠫ剴"),source)
def l1111l11l1l1_l1_(url,source,type=l11ll1_l1_ (u"ࠫࠬ創")):
	url = url.strip(l11ll1_l1_ (u"ࠬࠦࠧ剶")).strip(l11ll1_l1_ (u"࠭ࠦࠨ剷")).strip(l11ll1_l1_ (u"ࠧࡀࠩ剸")).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ剹"))
	l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111111ll11_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ剺"),l11ll1_l1_ (u"ࠪࠫ剻"),url,l11l11llll1l_l1_)
	if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ剼"): return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ剽"), l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ剾")
			else:
				l111l111l1l1_l1_ = l1llll_l1_[l1l_l1_]
				title = l1lll11l_l1_[l1l_l1_]
				LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ剿"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡥ࡭ࡧࡦࡸࡪࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ劀")+title+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ劁")+str(l111l111l1l1_l1_)+l11ll1_l1_ (u"ࠪࠤࡢ࠭劂"))
				if l11ll1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ劃") in l111l111l1l1_l1_ and l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ劄") in l111l111l1l1_l1_:
					l111l1l1l11l_l1_,l11ll11l11ll_l1_,l11ll11ll1ll_l1_ = l11l11111l1l_l1_(l111l111l1l1_l1_)
					if l11ll11ll1ll_l1_: l111l111l1l1_l1_ = l11ll11ll1ll_l1_[0]
					else: l111l111l1l1_l1_ = l11ll1_l1_ (u"࠭ࠧ劅")
				if not l111l111l1l1_l1_: result = l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ劆")
				else: result = PLAY_VIDEO(l111l111l1l1_l1_,source,type)
			if result in [l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ劇"),l11ll1_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭劈")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ劉"),l11ll1_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ劊"),l11ll1_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ劋")]: break
			else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ劌"),l11ll1_l1_ (u"ࠧࠨ劍"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ劎"),l11ll1_l1_ (u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨ劏"))
	else:
		result = l11ll1_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ劐")
		l111lll1ll_l1_ = l11l1lll1l_l1_(url)
		if l111lll1ll_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11l11llll1l_l1_,l1llll_l1_
	#title = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ劑") )
	#if l11ll1_l1_ (u"ู๊ࠬาใิࠤ฾อๅࠡ็ฯ๋ํ๊ࠧ劒") in title:
	#	import l1l1111lll1_l1_
	#	l1l1111lll1_l1_.MAIN(156)
	#	return l11ll1_l1_ (u"࠭ࠧ劓")
def l1lllllll1ll1_l1_(url,source):
	# url = url+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ劔")+name+l11ll1_l1_ (u"ࠨࡡࡢࠫ劕")+type+l11ll1_l1_ (u"ࠩࡢࡣࠬ劖")+l11lll1_l1_+l11ll1_l1_ (u"ࠪࡣࡤ࠭劗")+l111llll_l1_
	# url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺ࠿࡯ࡣࡰࡩࡩࡃࡡ࡬ࡹࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣ࠼࠸࠰ࠨ劘")
	l111lll_l1_,l11l111l11l1_l1_,server,l111l11l1l11_l1_,name,type,l11lll1_l1_,l111llll_l1_ = url,l11ll1_l1_ (u"ࠬ࠭劙"),l11ll1_l1_ (u"࠭ࠧ劚"),l11ll1_l1_ (u"ࠧࠨ力"),l11ll1_l1_ (u"ࠨࠩ劜"),l11ll1_l1_ (u"ࠩࠪ劝"),l11ll1_l1_ (u"ࠪࠫ办"),l11ll1_l1_ (u"ࠫࠬ功")
	#source = source.lower()
	if l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭加") in url:
		l111lll_l1_,l11l111l11l1_l1_ = url.split(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ务"),1)
		l11l111l11l1_l1_ = l11l111l11l1_l1_+l11ll1_l1_ (u"ࠧࡠࡡࠪ劢")+l11ll1_l1_ (u"ࠨࡡࡢࠫ劣")+l11ll1_l1_ (u"ࠩࡢࡣࠬ劤")+l11ll1_l1_ (u"ࠪࡣࡤ࠭劥")
		l11l111l11l1_l1_ = l11l111l11l1_l1_.lower()
		name,type,l11lll1_l1_,l111llll_l1_,l1llll1l1l11_l1_ = l11l111l11l1_l1_.split(l11ll1_l1_ (u"ࠫࡤࡥࠧ劦"))[:5]
	if l111llll_l1_==l11ll1_l1_ (u"ࠬ࠭劧"): l111llll_l1_ = l11ll1_l1_ (u"࠭࠰ࠨ动")
	else: l111llll_l1_ = l111llll_l1_.replace(l11ll1_l1_ (u"ࠧࡱࠩ助"),l11ll1_l1_ (u"ࠨࠩ努")).replace(l11ll1_l1_ (u"ࠩࠣࠫ劫"),l11ll1_l1_ (u"ࠪࠫ劬"))
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠫࡄ࠭劭")).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ劮")).strip(l11ll1_l1_ (u"࠭ࠦࠨ劯"))
	server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡩࡱࡶࡸࠬ劰"))
	if name: l111l11l1l11_l1_ = name
	#elif source: l111l11l1l11_l1_ = source
	else: l111l11l1l11_l1_ = server
	l111l11l1l11_l1_ = SERVER(l111l11l1l11_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭励"))
	name = name.replace(l11ll1_l1_ (u"่ࠩฬฬฺัࠨ劲"),l11ll1_l1_ (u"ࠪࠫ劳")).replace(l11ll1_l1_ (u"ุࠫ๐ัโำࠪ労"),l11ll1_l1_ (u"ࠬ࠭劵")).replace(l11ll1_l1_ (u"࠭วๅࠢࠪ劶"),l11ll1_l1_ (u"ࠧࠡࠩ劷")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ劸"),l11ll1_l1_ (u"ࠩࠣࠫ効"))
	l11l111l11l1_l1_ = l11l111l11l1_l1_.replace(l11ll1_l1_ (u"้ࠪออิาࠩ劺"),l11ll1_l1_ (u"ࠫࠬ劻")).replace(l11ll1_l1_ (u"ู๊ࠬาใิࠫ劼"),l11ll1_l1_ (u"࠭ࠧ劽")).replace(l11ll1_l1_ (u"ࠧศๆࠣࠫ劾"),l11ll1_l1_ (u"ࠨࠢࠪ势")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ勀"),l11ll1_l1_ (u"ࠪࠤࠬ勁"))
	l111l11l1l11_l1_ = l111l11l1l11_l1_.replace(l11ll1_l1_ (u"๊ࠫฮวีำࠪ勂"),l11ll1_l1_ (u"ࠬ࠭勃")).replace(l11ll1_l1_ (u"࠭ำ๋ำไีࠬ勄"),l11ll1_l1_ (u"ࠧࠨ勅")).replace(l11ll1_l1_ (u"ࠨษ็ࠤࠬ勆"),l11ll1_l1_ (u"ࠩࠣࠫ勇")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭勈"),l11ll1_l1_ (u"ࠫࠥ࠭勉"))
	return l111lll_l1_,l11l111l11l1_l1_,server,l111l11l1l11_l1_,name,type,l11lll1_l1_,l111llll_l1_
def l11l11ll1l1l_l1_(url,source):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭勊"),l11ll1_l1_ (u"࠭ࠧ勋"),url,l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ勌"))
	# l1lll1l11_l1_	: سيرفر خاص
	# l11l111lllll_l1_		: سيرفر محدد
	# l11l111l1111_l1_		: سيرفر عام معروف
	# l1ll1l1l1_l1_	: سيرفر عام خارجي
	# l11111l111l1_l1_	: سيرفر عام خارجي
	l111l111111l_l1_,name,l1lll1l11_l1_,l11l111l1111_l1_,l1ll1l1l1_l1_,l11l111lllll_l1_,l11111l111l1_l1_ = l11ll1_l1_ (u"ࠨࠩ勍"),l11ll1_l1_ (u"ࠩࠪ勎"),None,None,None,None,None
	l111lll_l1_,l11l111l11l1_l1_,server,l111l11l1l11_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1lllllll1ll1_l1_(url,source)
	if l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ勏") in url:
		if   type==l11ll1_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ勐"): type = l11ll1_l1_ (u"ࠬࠦࠧ勑")+l11ll1_l1_ (u"࠭ๅโุ็ࠫ勒")
		elif type==l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭勓"): type = l11ll1_l1_ (u"ࠨࠢࠪ勔")+l11ll1_l1_ (u"ࠩࠨู้อ็ะหࠪ動")
		elif type==l11ll1_l1_ (u"ࠪࡦࡴࡺࡨࠨ勖"): type = l11ll1_l1_ (u"ࠫࠥ࠭勗")+l11ll1_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ勘")
		elif type==l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ務"): type = l11ll1_l1_ (u"ࠧࠡࠩ勚")+l11ll1_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ勛")
		elif type==l11ll1_l1_ (u"ࠩࠪ勜"): type = l11ll1_l1_ (u"ࠪࠤࠬ勝")+l11ll1_l1_ (u"ࠫࠪࠫࠥࠦࠩ勞")
		if l11lll1_l1_!=l11ll1_l1_ (u"ࠬ࠭募"):
			if l11ll1_l1_ (u"࠭࡭ࡱ࠶ࠪ勠") not in l11lll1_l1_: l11lll1_l1_ = l11ll1_l1_ (u"ࠧࠦࠩ勡")+l11lll1_l1_
			l11lll1_l1_ = l11ll1_l1_ (u"ࠨࠢࠪ勢")+l11lll1_l1_
		if l111llll_l1_!=l11ll1_l1_ (u"ࠩࠪ勣"):
			l111llll_l1_ = l11ll1_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭勤")+l111llll_l1_
			l111llll_l1_ = l11ll1_l1_ (u"ࠫࠥ࠭勥")+l111llll_l1_[-9:]
	#if any(value in server for value in l111l1ll1l1l_l1_): return l11ll1_l1_ (u"ࠬ࠭勦")
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ勧"),l11ll1_l1_ (u"ࠧࠨ勨"),name,l111l11l1l11_l1_)
	if   l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ勩")		in source: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ勪")		in source: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ勫")
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭勬")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ勭")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ勮")	in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ勯")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ勰")
	#elif l11ll1_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ勱") in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ勲")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ勳")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	#elif l11ll1_l1_ (u"ࠬࡶࡣࡳࡧࡹ࡭ࡪࡽࠧ勴")	in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ勵")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ勶")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ勷")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ勸")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ勹")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ勺")	in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ勻")
	elif l11ll1_l1_ (u"࠭แอำࠪ勼")			in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭勽")
	elif l11ll1_l1_ (u"ࠨใ็ื฼๐ๆࠨ勾")		in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬ勿")
	elif l11ll1_l1_ (u"ࠪ࡫ࡩࡸࡩࡷࡧࠪ匀")		in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ匁")
	elif l11ll1_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ匂")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭匃")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ匄")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ包")		in name:   l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ匆")	in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ匇")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ匈")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ匉")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ匊")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ匋")		in server: l1lll1l11_l1_	= l111l11l1l11_l1_
	#elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭匌")	in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࠣࠫ匍")
	elif l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ匎")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭匏")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ匐")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭匑")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ匒")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ匓")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ匔")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ匕")
	elif l11ll1_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ化")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭北")
	elif l11ll1_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ匘")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ匙")
	elif l11ll1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ匚")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ匛")
	elif l11ll1_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ匜")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭匝")
	elif l11ll1_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ匞")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ匟")
	elif l11ll1_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ匠")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ匡")
	elif l11ll1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ匢")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ匣")
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ匤")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ匥")
	elif l11ll1_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ匦")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ匧")
	elif l11ll1_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ匨")	 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠩࡦࡥࡹࡩࡨࠨ匩")
	elif l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ匪")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ匫")
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ匬")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ匭")
	elif l11ll1_l1_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭匮")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧ匯")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ匰")		in server: l11l111lllll_l1_	= l111l11l1l11_l1_
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ匱")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭匲")
	elif l11ll1_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ匳")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ匴")
	elif l11ll1_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ匵") 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ匶")
	elif l11ll1_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ匷")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭匸")
	elif l11ll1_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ匹")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ区")
	elif l11ll1_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ医") 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ匼")
	elif l11ll1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ匽")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ匾")
	elif l11ll1_l1_ (u"ࠪࡹࡵࡶࠧ匿") 			in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ區")
	elif l11ll1_l1_ (u"ࠬࡻࡰࡣࠩ十") 			in server: l11l111l1111_l1_	= l11ll1_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ卂")
	elif l11ll1_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ千") 		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ卄")
	elif l11ll1_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ卅") 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ卆")
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ升")		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ午")
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭卉") 		in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ半")
	elif l11ll1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ卋") 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭卌")
	elif l11ll1_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ卍")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ华")
	elif l11ll1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ协")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ卐")
	#elif l11ll1_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ卑") 	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ卒")
	#elif l11ll1_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭卓")	in server: l11l111l1111_l1_	= l11ll1_l1_ (u"ࠪࡹࡵࡺ࡯ࡴࡶࡵࡩࡦࡳࠧ協")
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡶࡴ࡯࠯ࠬࡃ࠽࠾ࠩ࠮ࡹࡷࡲ࠲ࠪࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠴ࡈࡰࡵࡷࡩࡩࡓࡥࡥ࡫ࡤࡊ࡮ࡲࡥࠩࡷࡵࡰ࠷࠯࠮ࡷࡣ࡯࡭ࡩࡥࡵࡳ࡮ࠫ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࡴ࠽ࠎࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠱࠲࠳࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠭ࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡌࡡ࡭ࡵࡨࠎࠎࠏࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡲ࠮ࡰࡴࡪࠎࠎࠏࠉ࡭࡫ࡶࡸࡤࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡵࡦ࡯࠱ࡴࡸࡧ࠯ࡩ࡬ࡸ࡭ࡻࡢ࠯࡫ࡲ࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠰ࡵࡸࡴࡵࡵࡲࡵࡧࡧࡷ࡮ࡺࡥࡴ࠰࡫ࡸࡲࡲࠧࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮࡯࡭ࡸࡺ࡟ࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊ࡙ࡏࡍࡘࡄࡆࡑࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࡟࠵ࡣ࠮࡭ࡱࡺࡩࡷ࠮ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࡬ࡪࡀࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠳࠴࠵࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࠌࡴࡦࡸࡴࡴࠢࡀࠤࡸ࡫ࡲࡷࡧࡵ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠳࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡲࡤࡶࡹ࠯࠼࠵࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࠌࡩࡱ࡯ࡦࠡࡲࡤࡶࡹࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࠍࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠍࠎࠏࠉࠊࡤࡵࡩࡦࡱࠊࠊࠤࠥࠦ单")
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭卖"),l11ll1_l1_ (u"࠭ࠧ南"),url,l111lll_l1_)
	if   l1lll1l11_l1_:	l111l111111l_l1_,name = l11ll1_l1_ (u"ࠧฯษุࠫ単"),l1lll1l11_l1_
	elif l11l111lllll_l1_:		l111l111111l_l1_,name = l11ll1_l1_ (u"ࠨ่ࠧัิีࠧ卙"),l11l111lllll_l1_
	elif l11l111l1111_l1_:		l111l111111l_l1_,name = l11ll1_l1_ (u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ博"),l11l111l1111_l1_
	elif l1ll1l1l1_l1_:	l111l111111l_l1_,name = l11ll1_l1_ (u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ卛"),l1ll1l1l1_l1_
	elif l11111l111l1_l1_:	l111l111111l_l1_,name = l11ll1_l1_ (u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ卜"),l111l11l1l11_l1_
	else:			l111l111111l_l1_,name = l11ll1_l1_ (u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭卝"),l111l11l1l11_l1_
	return l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉࡱࡴ࡬ࡺࡦࡺࡥࠡ࠿ࠣࠫ࡭࡫࡬ࡢ࡮ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠍࠍࡪࡲࡩࡧࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸࡨࡺࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠢࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡩࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠎࠎࠨࠢࠣ卞")
def l1111l1ll111_l1_(url,source):
	l111lll_l1_,l11l111l11l1_l1_,server,l111l11l1l11_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1lllllll1ll1_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ卟"),l11ll1_l1_ (u"ࠨࠩ占"),l11l111lllll_l1_,server)
	#if l11ll1_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ卡")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ卢"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ卣"))
	#if any(value in server for value in l111l1ll1l1l_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡅࡔࡑࡏ࡚ࡊࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࠢࡷ࡬࡮ࡹࠠࡴࡧࡵࡺࡪࡸࠧ卤")],[]
	if   l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ卥")		in source: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11llll_l1_(l111lll_l1_,name)
	elif l11ll1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭卦")		in source: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1_l1_(l111lll_l1_,type,l111llll_l1_)
	elif l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ卧")		in source: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ卨")		in source: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ卩")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ卪")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ卫")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11l1ll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ卬")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll11l111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ卭")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll11l111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ卮")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll111ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ卯")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll1lll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ印")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll11l11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ危")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll11l11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ卲")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1lll1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ即")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ却")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l11lllll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ卵")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ卶")			in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1llllll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ卷")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ卸")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭卹")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ卺")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ卻")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ卼")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll11llllll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ卽")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll11llll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ卾")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ卿")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ厀")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭厁")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡴࡦࡥ࡫ࠫ厂")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡳࡣࡷࡩࠬ厃")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡳࡧࡷ࡫ࡶࡪࡧࡺࠫ厄")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ厅")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll1ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ历")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬ࠭厇"),[l11ll1_l1_ (u"࠭ࠧ厈")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ厉")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111ll11_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧ厊")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111lll1ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ压") 		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠪࠫ厌"),[l11ll1_l1_ (u"ࠫࠬ厍")],[l111lll_l1_]
	else: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ厎"),[l11ll1_l1_ (u"࠭ࠧ厏")],[l111lll_l1_]
	return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
def l11l1111lll1_l1_(url,source):
	server = SERVER(url,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ厐"))
	#if l11ll1_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭厑")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ厒"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ厓"))
	#if any(value in server for value in l111l1ll1l1l_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗࡋࡓࡐࡎ࡙ࡉࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡦࡴࡹࡩࡷ࠭厔")],[]
	l1111l1l1lll_l1_ = False
	if   l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ厕")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1lll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭厖")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1lll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷࠫ厗") in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l11ll111_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ厘")	in url: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1ll1lll_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ厙")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ厚")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ厛")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ厜")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111l1l_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ厝")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l11l_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ厞")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1ll11_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ原")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ厠")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111lllll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ厡")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll1lll1_l1_(url)
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ厢")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llll111l_l1_(url)
	elif l11ll1_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ厣")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llll111l_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ厤")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ厥")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ厦")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡮ࡤࠨ厧")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ厨")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡪࡸ࡬ࡨࡪࡵࠧ厩")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡱࡥࡥࠬ厪")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllll11ll_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡶࡴࡪ࡫ࡤࠨ厫")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllll11ll_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡶࡲࡥࡥࡲ࠭厬") 		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࠩ厭"),[l11ll1_l1_ (u"ࠩࠪ厮")],[url]
	#elif l11ll1_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ厯")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1lll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭厰") 	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1ll11l1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ厱")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll1l11ll_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲ࡬ࡴ࠭厲")in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l111llll_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ厳") 	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llllll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ厴")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1111l_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧ࠭厵") 			in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1l11ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡹࡵࡶࠧ厶") 			in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1l11ll_l1_(url)
	#elif l11ll1_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ厷") 	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111llll111_l1_(url)
	#elif l11ll1_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ厸")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111llll111_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭厹") 		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111ll11l1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ厺") 	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1l1ll11_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ去")		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll11111_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ厼") 		in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l111l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ厽") 	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll11l1l1_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ厾")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111ll1ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ县")	in server: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111lllll11_l1_(url)
	else: l1111l1l1lll_l1_ = True
	if l1111l1l1lll_l1_ or l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ叀") in l11l11llll1l_l1_:
		l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶ࠦࡆࡢ࡫࡯ࡩࡩ࠭叁"),[],[]
	return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆࡕࡗࡖࡊࡇࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡌࡕࡕࡏࡎࡌࡑࡎ࡚ࡅࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡏࡎࡕࡑࡘࡔࡑࡕࡁࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡘࡍࡋࡖࡊࡆࡈࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡅࡗࡋࡒࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡊࡈࡐࡆࡒࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡤࡲࡱࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡅࡓࡒ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡩࡦࠪࠤࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡊࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡕࡋࡅࡗࡋࠨࡶࡴ࡯࠭ࠏࠏࠢࠣࠤ参")
def	l111l1l11l1l_l1_(l11ll1l111ll_l1_):
	if l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ參") in str(type(l11ll1l111ll_l1_)):
		l1l1_l1_ = []
		for l1lllll_l1_ in l11ll1l111ll_l1_:
			if l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ叄") in str(type(l1lllll_l1_)):
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡸࠧ叅"),l11ll1_l1_ (u"ࠬ࠭叆")).replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ叇"),l11ll1_l1_ (u"ࠧࠨ又")).strip(l11ll1_l1_ (u"ࠨࠢࠪ叉"))
			l1l1_l1_.append(l1lllll_l1_)
	else: l1l1_l1_ = l11ll1l111ll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡶࠬ及"),l11ll1_l1_ (u"ࠪࠫ友")).replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ双"),l11ll1_l1_ (u"ࠬ࠭反")).strip(l11ll1_l1_ (u"࠭ࠠࠨ収"))
	return l1l1_l1_
def l1111111ll11_l1_(url,source):
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ叏"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ叐")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ发"))
	l11111l111l1_l1_,l1lllll_l1_,l111l1l11ll1_l1_ = l11ll1_l1_ (u"ࠪࡍࡓ࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠧ叒"),l11ll1_l1_ (u"ࠫࠬ叓"),l11ll1_l1_ (u"ࠬ࠭叔")
	l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1ll111_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ叕"),l11ll1_l1_ (u"ࠧࠨ取"),l11ll1_l1_ (u"ࠨࠩ受"),l11l11llll1l_l1_)
	l1llll_l1_ = l111l1l11l1l_l1_(l1llll_l1_)
	if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ变"): return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_: l1lllll_l1_ = l1llll_l1_[0]
	if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭叙"):
		#l11l11llll1l_l1_ = l11l11llll1l_l1_.replace(l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ叚"),l11ll1_l1_ (u"ࠬ࠭叛"))
		l11111l111l1_l1_ = l11ll1_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠬ叜")
		l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1111lll1_l1_(l1lllll_l1_,source)
		l1llll_l1_ = l111l1l11l1l_l1_(l1llll_l1_)
		if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ叝"): return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
		elif l11ll1_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ叞") in l11l11llll1l_l1_:
			l111l1l11ll1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠪ叟")+l11l11llll1l_l1_
			l11111l111l1_l1_ = l11ll1_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ叠")
			l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1111ll1l_l1_(l1lllll_l1_,source)
			l1llll_l1_ = l111l1l11l1l_l1_(l1llll_l1_)
			if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ叡"): return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
			elif l11ll1_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ叢") in l11l11llll1l_l1_:
				l111l1l11ll1_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ口")+l11l11llll1l_l1_
				l11111l111l1_l1_ = l11ll1_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭古")
				l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1111ll11_l1_(l1lllll_l1_,source)
				l1llll_l1_ = l111l1l11l1l_l1_(l1llll_l1_)
				if l11l11llll1l_l1_==l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭句"): return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
				elif l11ll1_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ另") in l11l11llll1l_l1_:
					l111l1l11ll1_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠫ叧")+l11l11llll1l_l1_
	elif l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭叨") in l11l11llll1l_l1_: l111l1l11ll1_l1_ = l11ll1_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ叩")+l11l11llll1l_l1_
	if l1llll_l1_: LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭只"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ叫")+l11111l111l1_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ召")+url+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ叭")+l1lllll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭叮")+str(l1llll_l1_)+l11ll1_l1_ (u"ࠫࠥࡣࠧ可"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ台"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭叱")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ史")+l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ右")+l111l1l11ll1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ叴"))
	l111l1l11ll1_l1_ = l1111_l1_(l111l1l11ll1_l1_)
	return l111l1l11ll1_l1_,l1lll11l_l1_,l1llll_l1_
def l11111ll11ll_l1_(l11ll11ll1ll_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ叵"),l11ll11ll1ll_l1_)
	l1l111lllll_l1_ = l1llllll_l1_
	data = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ叶"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭号"),l11ll11ll1ll_l1_)
	if data:
		l1lll11l_l1_,l1llll_l1_ = list(zip(*data))
		return l1lll11l_l1_,l1llll_l1_
	l1lll11l_l1_,l1llll_l1_,l11l11lll1ll_l1_ = [],[],[]
	for l1lllll_l1_ in l11ll11ll1ll_l1_:
		if l11ll1_l1_ (u"࠭࠯࠰ࠩ司") not in l1lllll_l1_: continue
		l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l11l11ll1l1l_l1_(l1lllll_l1_,source)
		l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࠮ࠫ叹"),l111llll_l1_,re.DOTALL)
		if l111llll_l1_: l111llll_l1_ = int(l111llll_l1_[0])
		else: l111llll_l1_ = 0
		#if l111llll_l1_:
		#	l11l111111ll_l1_ = sorted(l111llll_l1_,reverse=True,key=lambda key: int(key))
		#	l111llll_l1_ = int(l11l111111ll_l1_[0])
		#else: l111llll_l1_ = 0
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭叺"))
		l11l11lll1ll_l1_.append([l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server])
	if l11l11lll1ll_l1_:
		#l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_ = zip(*l11l11lll1ll_l1_)
		#name = reversed(name)
		#l11l11lll1ll_l1_ = zip(l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_)
		l1llll11llll_l1_ = sorted(l11l11lll1ll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111l11lllll_l1_ = []
		for line in l1llll11llll_l1_:
			if line not in l111l11lllll_l1_:
				l111l11lllll_l1_.append(line)
				#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ叻"),str(line))
		for l111l111111l_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server in l111l11lllll_l1_:
			if l111llll_l1_: l111llll_l1_ = str(l111llll_l1_)
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠪࠫ叼")
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ叽"),l11ll1_l1_ (u"ࠬ࠭叾"),name,l1lllll_l1_)
			title = l11ll1_l1_ (u"࠭ำ๋ำไีࠬ叿")+l11ll1_l1_ (u"ࠧࠡࠩ吀")+type+l11ll1_l1_ (u"ࠨࠢࠪ吁")+l111l111111l_l1_+l11ll1_l1_ (u"ࠩࠣࠫ吂")+l111llll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ吃")+l11lll1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭各")+name
			if server not in title: title = title+l11ll1_l1_ (u"ࠬࠦࠧ吅")+server
			title = title.replace(l11ll1_l1_ (u"࠭ࠥࠨ吆"),l11ll1_l1_ (u"ࠧࠨ吇")).strip(l11ll1_l1_ (u"ࠨࠢࠪ合")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ吉"),l11ll1_l1_ (u"ࠪࠤࠬ吊")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ吋"),l11ll1_l1_ (u"ࠬࠦࠧ同")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ名"),l11ll1_l1_ (u"ࠧࠡࠩ后"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		if l1llll_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭吏"),l1llll_l1_)
			data = list(zip(l1lll11l_l1_,l1llll_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪ吐"),l11ll11ll1ll_l1_,data,l1l111lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ向"),l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠼࠵࠾ࠥࠦࠠࠨ吒")+str(data))
	return l1lll11l_l1_,l1llll_l1_
def	l11l1111ll1l_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡄࡤ࡛ࡤࡰࡥ࡯ࡱࡽࡏࡨ࠭吓")
	l1llllll11ll_l1_ = l11ll1_l1_ (u"࠭ࠧ吔")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l11l11111_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1llllll11ll_l1_ = str(error)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ吕"),l11ll1_l1_ (u"ࠨࠩ吖"),l11ll1_l1_ (u"ࠩࠪ吗"),str(results))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ吘"),l11ll1_l1_ (u"ࠫࠬ吙"),l11ll1_l1_ (u"ࠬ࠭吚"),str(l1llllll11ll_l1_))
	# resolveurl l1111l1ll1_l1_ l1lll1l11l1_l1_ l111l111l11l_l1_ with l1llllll1l1ll_l1_ error or l111l1l1l1ll_l1_ value False
	if not results:
		if l1llllll11ll_l1_==l11ll1_l1_ (u"࠭ࠧ君"):
			l1llllll11ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1llllll11ll_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ吜"),l11ll1_l1_ (u"ࠨࠩ吝"),l11ll1_l1_ (u"ࠩࠪ吞"),str(l1llllll11ll_l1_))
		l11l11llll1l_l1_ = l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠢࡉࡥ࡮ࡲࡥࡥࠩ吟")
		l11l11llll1l_l1_ += l11ll1_l1_ (u"ࠫࠥ࠭吠")+l1llllll11ll_l1_.splitlines()[-1]
		return l11l11llll1l_l1_,[],[]
	return l11ll1_l1_ (u"ࠬ࠭吡"),[l11ll1_l1_ (u"࠭ࠧ吢")],[results]
def	l11l1111ll11_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ吣")
	#url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭࠰ࡸ࡬ࡨࡪࡵ࠯ࡹ࠹ࡼࡽ࠹࠷ࡳࠨ吤")
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ吥"),l11ll1_l1_ (u"ࠪࠫ否"),url,l11ll1_l1_ (u"ࠫࠬ吧"))
	#return l11ll1_l1_ (u"ࠬ࠭吨"),[],[]
	l1llllll11ll_l1_ = l11ll1_l1_ (u"࠭ࠧ吩")
	results = False
	try:
		import youtube_dl
		l11l11l1lll1_l1_ = youtube_dl.YoutubeDL({l11ll1_l1_ (u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩ吪"): True})
		results = l11l11l1lll1_l1_.extract_info(url,download=False)
	except Exception as error: l1llllll11ll_l1_ = str(error)
	# youtube_dl l1111l1ll1_l1_ l1lll1l11l1_l1_ l111l111l11l_l1_ with l1llllll1l1ll_l1_ error or l111l1l1l1ll_l1_ value False
	if not results or l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ含") not in list(results.keys()):
		if l1llllll11ll_l1_==l11ll1_l1_ (u"ࠩࠪ听"):
			l1llllll11ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1llllll11ll_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ吭"),l11ll1_l1_ (u"ࠫࠬ吮"),l11ll1_l1_ (u"ࠬ࠭启"),l1llllll11ll_l1_)
		l11l11llll1l_l1_ = l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠥࡌࡡࡪ࡮ࡨࡨࠬ吰")
		l11l11llll1l_l1_ += l11ll1_l1_ (u"ࠧࠡࠩ吱")+l1llllll11ll_l1_.splitlines()[-1]
		return l11l11llll1l_l1_,[],[]
	else:
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_ in results[l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ吲")]:
			l1lll11l_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࠩ吳")])
			l1llll_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ吴")])
		return l11ll1_l1_ (u"ࠫࠬ吵"),l1lll11l_l1_,l1llll_l1_
def l11l11l1ll11_l1_(url):
	if l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ吶") in url:
		l1lll11l_l1_,l1llll_l1_ = l11ll11ll1_l1_(url)
		if l1llll_l1_: return l11ll1_l1_ (u"࠭ࠧ吷"),l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡐࡆࡘࡁࡃࠩ吸"),[],[]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ吹"),[l11ll1_l1_ (u"ࠩࠪ吺")],[url]
def l1l1l1l1lll_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ吻"),l11ll1_l1_ (u"ࠫࠬ吼"),l11ll1_l1_ (u"ࠬ࠭吽"),url)
	l1llll11_l1_,l111l1111lll_l1_ = [],[]
	if l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩ吾") in url:
		# l111ll1l1111_l1_:
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_11111l11l11_l1_.html
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l11ll11lll_l1_.l1111l1l_l1_?l1l1l1ll1ll_l1_=49e3a27b4
		# l1111lll111l_l1_: https://l111l1l1llll_l1_.l1llll11111_l1_.l1llllll11l11_l1_.l1llll11l11_l1_/15/items/40animeHD/l111l1l11lll_l1_.l1111l1l_l1_
		# l111ll1l1111_l1_:
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1111l111ll1_l1_-l111l1lllll1_l1_.html
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l11ll11lll_l1_.l1111l1l_l1_?l1l1l1ll1ll_l1_=l11111111111_l1_
		# l1111lll111l_l1_: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11ll11lll_l1_/l111l11ll1l1_l1_%20.l1111l1l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ吿"),url,l11ll1_l1_ (u"ࠨࠩ呀"),l11ll1_l1_ (u"ࠩࠪ呁"),False,l11ll1_l1_ (u"ࠪࠫ呂"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭呃"))
		if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ呄") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ呅")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ呆"))
			l111l1111lll_l1_.append(server)
	elif l11ll1_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ呇") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111ll1l1111_l1_:
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l11l11l1l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l11l11ll111l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l111l1l1l_l1_&l1llllllll11l_l1_=
		# l111ll1l1111_l1_:
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1lllll_l1_: https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?url=l1llllll1lll1_l1_==&sub=https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l111ll1l1ll1_l1_/l1llllll1ll11_l1_.l11111111l1l_l1_&l1llllllll11l_l1_=https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11111l1ll1l_l1_/l1lllll1l1lll_l1_-1.l1111l1111l1_l1_
		# l111ll1l1111_l1_:
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l11l1ll1_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l1111llllll1_l1_/?url=https://photos.l1l1ll1111ll_l1_.l111ll11ll11_l1_.l11l1l1l111l_l1_/l111l1l1lll1_l1_&sub=&l1llllllll11l_l1_=http://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11111l1ll1l_l1_/4723b8ebe-1.l1111l1111l1_l1_
		# l111ll1l1111_l1_:
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l11l1l1l1_l1_.html
		# https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l11l11ll111l_l1_/?l1lllll_l1_=https://l1l11ll1l1l_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l111l1l1l_l1_&sub=&l1llllllll11l_l1_=https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11111l1ll1l_l1_/2e8bc4c34-1.l1111l1111l1_l1_
		# l111ll1l1111_l1_:
		# https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1111l1l1l11_l1_.html
		# https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l11l11ll111l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l111l1lll_l1_=l11l111l1l11_l1_&l1llllllll11l_l1_=https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11111l1ll1l_l1_/l111ll11llll_l1_-1.l1111l1111l1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭呈"),url,l11ll1_l1_ (u"ࠪࠫ呉"),l11ll1_l1_ (u"ࠫࠬ告"),l11ll1_l1_ (u"ࠬ࠭呋"),l11ll1_l1_ (u"࠭ࠧ呌"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ呍"))
		html = response.content
		l1lll1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ呎"),html,re.DOTALL)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ呏"),str(l1lll1ll1ll1_l1_))
		if l1lll1ll1ll1_l1_:
			l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_[0]
			l1l1lll1l1l1_l1_ = l1ll111l1l11_l1_(l1lll1ll1ll1_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ呐"),str(l1l1lll1l1l1_l1_))
			l1l1ll1l1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࡜࡜࠰࠭ࡃࡡࡣࠩ࠭ࠩ呑"),l1l1lll1l1l1_l1_,re.DOTALL)
			if l1l1ll1l1lll_l1_:
				l1l1ll1l1lll_l1_ = l1l1ll1l1lll_l1_[0]
				l1l1ll1l1lll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ呒"),l1l1ll1l1lll_l1_)
				for dict in l1l1ll1l1lll_l1_:
					l1lllll_l1_ = dict[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࠫ呓")]
					l111llll_l1_ = dict[l11ll1_l1_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭呔")]
					#l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࡡࡢࠫ呕")+l111llll_l1_
					l1llll11_l1_.append(l1lllll_l1_)
					server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ呖"))
					l111l1111lll_l1_.append(l111llll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ呗")+server)
		elif l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭员") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ呙")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ呚"))
			l111l1111lll_l1_.append(server)
		# l111ll1l1111_l1_: 5
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l11l1ll1_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll11l_l1_.com/l1lllllllllll_l1_/l1111llllll1_l1_/?url=https://photos.l1l1ll1111ll_l1_.l111ll11ll11_l1_.l11l1l1l111l_l1_/l111l1l1lll1_l1_&sub=&l1llllllll11l_l1_=http://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l1111111lll1_l1_/l11111l1ll1l_l1_/4723b8ebe-1.l1111l1111l1_l1_
		if l11ll1_l1_ (u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧ呛") in url:
			l1lllll_l1_ = url.split(l11ll1_l1_ (u"ࠨࡁࡸࡶࡱࡃࠧ呜"))[1]
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࠫ呝"))[0]
			if l1lllll_l1_:
				l1llll11_l1_.append(l1lllll_l1_)
				l111l1111lll_l1_.append(l11ll1_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪ呞"))
	else:
		# l111ll1l1111_l1_:
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1lllllll1lll_l1_.html
		# l1lllll_l1_: http://ok.l111ll11ll1l_l1_/l111lll1l1l1_l1_/1676019108395
		# l111ll1l1111_l1_:
		# url: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1llllllllll1_l1_.html
		# l1lllll_l1_: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l111l1l1l_l1_
		l1llll11_l1_.append(url)
		server = SERVER(url,l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ呟"))
		l111l1111lll_l1_.append(server)
	if not l1llll11_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ呠"),[],[]
	elif len(l1llll11_l1_)==1: l1lllll_l1_ = l1llll11_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ呡"),l111l1111lll_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ呢"),[],[]
		l1lllll_l1_ = l1llll11_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ呣"),[l11ll1_l1_ (u"ࠩࠪ呤")],[l1lllll_l1_]
def l111l11ll111_l1_(url):
	# test from: https://www.l1l1l1ll11l_l1_.com/l11l1l1ll_l1_/l11l111ll11l_l1_-l111l11ll1ll_l1_-l1111lll11l1_l1_-l11111lll11l_l1_-l1111l11111l_l1_-l11ll11lll_l1_-1-date.html
	# url = https://l111lllll1ll_l1_.l1lllll1ll111_l1_.com/l1111ll1l1ll_l1_=l111l1lll1ll_l1_
	headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ呥"):l11ll1_l1_ (u"ࠫࡐࡵࡤࡪ࠱ࠪ呦")+str(kodi_version)}
	for l11ll1111l_l1_ in range(50):
		time.sleep(0.100)
		response = l1l111l1lll_l1_(l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ呧"),url,l11ll1_l1_ (u"࠭ࠧ周"),headers,False,l11ll1_l1_ (u"ࠧࠨ呩"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ呪"))
		if l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ呫") in list(response.headers.keys()):
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ呬")]
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ呭")+headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ呮")]
			return l11ll1_l1_ (u"࠭ࠧ呯"),[l11ll1_l1_ (u"ࠧࠨ呰")],[l1lllll_l1_]
		if response.code!=429: break
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚ࠧ呱"),[],[]
def l111l1ll1lll_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ呲"),l11ll1_l1_ (u"ࠪࠫ味"),l11ll1_l1_ (u"ࠫࠬ呴"),url)
	# https://photos.l1l1ll1111ll_l1_.l111ll11ll11_l1_.l11l1l1l111l_l1_/l111l1l1lll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ呵"),url,l11ll1_l1_ (u"࠭ࠧ呶"),l11ll1_l1_ (u"ࠧࠨ呷"),l11ll1_l1_ (u"ࠨࠩ呸"),l11ll1_l1_ (u"ࠩࠪ呹"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩ呺"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨ呻"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_,l111llll_l1_ = l1lllll_l1_[0]
		return l11ll1_l1_ (u"ࠬ࠭呼"),[l111llll_l1_],[l1lllll_l1_]
	return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ命"),[],[]
def l1ll1l1l11l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ呾"),l11ll1_l1_ (u"ࠨࠩ呿"),l11ll1_l1_ (u"ࠩࠪ咀"),url)
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡲࡲࡪ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡨࡩࡦ࠼࠶࠸ࡤ࠳࠼࠶ࡨ࠸࠸ࡥ࠳࠴࠶࠵࠸ࡡࡥ࠳࠻ࡨࡩ࠷࠲ࡤ࠸࠻࠴࠻࠭咁")
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡴࡧ࡯࡬ࡩ࠳ࡥ࡮ࡤࡨࡨ࠳ࡹࡣࡥࡰ࠱ࡸࡴ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡤ࠳࠵࠺࠿࠰࠵ࡣ࠻ࡥࡨ࡬࠷࠺࠷࠹ࡨ࠶࡫࠷࠷࠵࠳ࡦࡪ࠷࠷࠷࠷࠻࠻࠸࠭咂")
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ咃"),url,l11ll1_l1_ (u"࠭ࠧ咄"),l11ll1_l1_ (u"ࠧࠨ咅"),l11ll1_l1_ (u"ࠨࠩ咆"),l11ll1_l1_ (u"ࠩࠪ咇"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸࠬ咈"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬ咉"),html)
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭咊"),html,re.DOTALL)
	if l1lllll_l1_: return l11ll1_l1_ (u"࠭ࠧ咋"),[l11ll1_l1_ (u"ࠧࠨ和")],[l1lllll_l1_[0]]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ咍"),[],[]
def l1llllll1l_l1_(url):
	if l11ll1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭咎") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ咏"),url,l11ll1_l1_ (u"ࠫࠬ咐"),l11ll1_l1_ (u"ࠬ࠭咑"),l11ll1_l1_ (u"࠭ࠧ咒"),l11ll1_l1_ (u"ࠧࠨ咓"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨ咔"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ咕"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ咖") in l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ咗"),[l11ll1_l1_ (u"ࠬ࠭咘")],[l1lllll_l1_]
		return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ咙"),[],[]
	else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ咚"),[l11ll1_l1_ (u"ࠨࠩ咛")],[url]
def l1lll1lll1l_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ咜"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ咝"),l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ咞"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ咟")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ咠"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ咡"),l11ll1_l1_ (u"ࠨࠩ咢"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩ咣"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ咤"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭咥"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ咦"),[l11ll1_l1_ (u"࠭ࠧ咧")],[l1lllll_l1_]
def l1l1l11lllll_l1_(url):
	headers = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ咨"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ咩")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭咪"),url,l11ll1_l1_ (u"ࠪࠫ咫"),headers,l11ll1_l1_ (u"ࠫࠬ咬"),l11ll1_l1_ (u"ࠬ࠭咭"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ咮"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ咯"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ咰"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ咱"),[l11ll1_l1_ (u"ࠪࠫ咲")],[l1lllll_l1_]
def l1l1lll1lll_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ咳"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ咴")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ咵"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ咶"),l11ll1_l1_ (u"ࠨࠩ咷"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ咸"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ咹"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ咺"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ咻") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ咼")+l1lllll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ咽"),l11ll1_l1_ (u"ࠨࠩ咾"),l11ll1_l1_ (u"ࠩࠪ咿"),l1lllll_l1_)
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭哀"),[l11ll1_l1_ (u"ࠫࠬ品")],[l1lllll_l1_]
def l1lll11ll1_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ哂"):l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭哃")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ哄"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠨࠩ哅"),l11ll1_l1_ (u"ࠩࠪ哆"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬ哇"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ哈"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡆࡈࡄࡐࠩ哉"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ哊"),[l11ll1_l1_ (u"ࠧࠨ哋")],[l1lllll_l1_]
def l1llll11l11l_l1_(url):
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ哌"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭响"),url,l11ll1_l1_ (u"ࠪࠫ哎"),l11ll1_l1_ (u"ࠫࠬ哏"),l11ll1_l1_ (u"ࠬ࠭哐"),l11ll1_l1_ (u"࠭ࠧ哑"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡘ࡛ࡌࡕࡏ࠯࠴ࡷࡹ࠭哒"))
	html = response.content
	l1llllllll111_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡸࡤࡶࠥ࡬ࡳࡦࡴࡹࠤࡂ࠴ࠪࡀࠩࠫ࠲࠯ࡅࠩࠨࠤ哓"),html,re.DOTALL|re.IGNORECASE)
	if l1llllllll111_l1_:
		l1llllllll111_l1_ = l1llllllll111_l1_[0][2:]
		#l1llllllll111_l1_ = l1llllllll111_l1_.decode(l11ll1_l1_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ哔"))
		l1llllllll111_l1_ = base64.b64decode(l1llllllll111_l1_)
		if kodi_version>18.99: l1llllllll111_l1_ = l1llllllll111_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ哕"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哖"),l1llllllll111_l1_,re.DOTALL)
	else: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࠭哗")
	if not l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ哘"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ哙") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ哚")+l1lllll_l1_
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ哛"),[l11ll1_l1_ (u"ࠪࠫ哜")],[l1lllll_l1_]
def l111111l1l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ哝"),url,l11ll1_l1_ (u"ࠬ࠭哞"),l11ll1_l1_ (u"࠭ࠧ哟"),l11ll1_l1_ (u"ࠧࠨ哠"),l11ll1_l1_ (u"ࠨࠩ員"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫ哢"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ哣"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨ哤"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ哥"),[l11ll1_l1_ (u"࠭ࠧ哦")],[l1lllll_l1_]
def l11lll1ll1_l1_(url):
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ哧"))[-1]
	if l11ll1_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ哨") in url: url = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ哩"),l11ll1_l1_ (u"ࠪࠫ哪"))
	url = url.replace(l11ll1_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࠪ哫"),l11ll1_l1_ (u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭哬"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ哭"),url,l11ll1_l1_ (u"ࠧࠨ哮"),l11ll1_l1_ (u"ࠨࠩ哯"),l11ll1_l1_ (u"ࠩࠪ哰"),l11ll1_l1_ (u"ࠪࠫ哱"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ哲"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭哳"),url)
	l11l11llll1l_l1_ = l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭哴")
	error = re.findall(l11ll1_l1_ (u"ࠧࠣࡧࡵࡶࡴࡸࠢ࠯ࠬࡂࠦࡲ࡫ࡳࡴࡣࡪࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ哵"),html,re.DOTALL)
	if error: l11l11llll1l_l1_ = error[0]
	url = re.findall(l11ll1_l1_ (u"ࠨࡺ࠰ࡱࡵ࡫ࡧࡖࡔࡏࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ哶"),html,re.DOTALL)
	if not url and l11l11llll1l_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ哷"),l11ll1_l1_ (u"ࠪࠫ哸"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾࠭哹"),l11l11llll1l_l1_)
		return l11l11llll1l_l1_,[],[]
	l1lllll_l1_ = url[0].replace(l11ll1_l1_ (u"ࠬࡢ࡜ࠨ哺"),l11ll1_l1_ (u"࠭ࠧ哻"))
	l11ll11l11ll_l1_,l11ll11ll1ll_l1_ = l11ll11ll1_l1_(l1lllll_l1_)
	owner = re.findall(l11ll1_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻ࡽࠥ࡭ࡩࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ哼"),html,re.DOTALL)
	if owner: l1111ll1l11l_l1_,l11l11l1ll1l_l1_,l111lll111l1_l1_ = owner[0]
	else: l1111ll1l11l_l1_,l11l11l1ll1l_l1_,l111lll111l1_l1_ = l11ll1_l1_ (u"ࠨࠩ哽"),l11ll1_l1_ (u"ࠩࠪ哾"),l11ll1_l1_ (u"ࠪࠫ哿")
	l111lll111l1_l1_ = l111lll111l1_l1_.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ唀"),l11ll1_l1_ (u"ࠬ࠵ࠧ唁"))
	l11l11l1ll1l_l1_ = escapeUNICODE(l11l11l1ll1l_l1_)
	l1lll11l_l1_ = [l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ唂")+l11l11l1ll1l_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ唃")]+l11ll11l11ll_l1_
	l1llll_l1_ = [l111lll111l1_l1_]+l11ll11ll1ll_l1_
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ唄")+str(len(l1llll_l1_)-1)+l11ll1_l1_ (u"้้ࠩࠣ็ࠩࠨ唅"),l1lll11l_l1_)
	if l1l_l1_==-1: return l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ唆"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11ll1_l1_ (u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿ࠪ唇")+l111lll111l1_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡦࡺࡷࡁࠬ唈")+l11l11l1ll1l_l1_
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ唉")+new_path+l11ll1_l1_ (u"ࠢࠪࠤ唊"))
		return l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭唋"),[],[]
	l1lllll_l1_ =  l1llll_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠩࠪ唌"),[l11ll1_l1_ (u"ࠪࠫ唍")],[l1lllll_l1_]
def l11111lll_l1_(l1lllll_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ唎"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭唏"),l11ll1_l1_ (u"࠭ࠧ唐"),l11ll1_l1_ (u"ࠧࠨ唑"),l11ll1_l1_ (u"ࠨࠩ唒"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨ唓"))
	html = response.content
	if l11ll1_l1_ (u"ࠪ࠲࡯ࡹ࡯࡯ࠩ唔") in l1lllll_l1_: url = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ唕"),html,re.DOTALL)
	else: url = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ唖"),html,re.DOTALL)
	if not url: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧ唗"),[],[]
	url = url[0]
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ唘") not in url: url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ唙")+url
	return l11ll1_l1_ (u"ࠩࠪ唚"),[l11ll1_l1_ (u"ࠪࠫ唛")],[url]
def l11l11111l1l_l1_(url):
	# http://l1111l1ll1l1_l1_.l1lll1ll1l1l_l1_/l11l11ll1l11_l1_.html?l11l111lllll_l1_=l111l11lll1l_l1_
	# http://l1111l1ll1l1_l1_.l1lll1ll1l1l_l1_/l111l11111ll_l1_?op=l1llllll11lll_l1_&id=l11l11ll1l11_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ唜") : l11ll1_l1_ (u"ࠬ࠭唝") }
	if l11ll1_l1_ (u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ唞") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ唟"),headers,l11ll1_l1_ (u"ࠨࠩ唠"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫ唡"))
		#xbmc.log(html)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ唢"),l11ll1_l1_ (u"ࠫࠬ唣"),url,html)
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ唤"),html,re.DOTALL)
		if items: return l11ll1_l1_ (u"࠭ࠧ唥"),[l11ll1_l1_ (u"ࠧࠨ唦")],[items[0]]
		else:
			message = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭唧"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ唨"),l11ll1_l1_ (u"ࠪࠫ唩"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭唪"),message[0])
				return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭唫")+message[0],[],[]
	else:
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ唬"),l11ll1_l1_ (u"ࠧࠨ唭"),l1lllll_l1_,l11ll1_l1_ (u"ࠨࠩ售"))
		#url,l1ll1lll1ll_l1_ = url.split(l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ唯"))
		#l1ll1lll1ll_l1_ = l1ll1lll1ll_l1_.lower()
		l1ll1lll1ll_l1_ = l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭唰")
		# l11l1l1ll_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ唱"),headers,l11ll1_l1_ (u"ࠬ࠭唲"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ唳"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ唴"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ唵"),[],[]
		l1lllll11l_l1_ = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		if l11ll1_l1_ (u"ࠩ࠱ࡶࡦࡸࠧ唶") in block or l11ll1_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ唷") in block: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ唸"),[],[]
		items = re.findall(l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭唹"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l11l_l1_(payload)
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll11l_l1_,data,headers,l11ll1_l1_ (u"࠭ࠧ唺"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩ唻"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭唼"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭唽"),[],[]
		download = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		items = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪ唾"),block,re.DOTALL)
		l111111llll1_l1_,l1lll11l_l1_,l11l111l11ll_l1_,l1llll_l1_,l1111l11l111_l1_ = [],[],[],[],[]
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ唿") in l1lllll_l1_:
				l111111llll1_l1_,l11l111l11ll_l1_ = l11ll11ll1_l1_(l1lllll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11l111l11ll_l1_
				if l111111llll1_l1_[0]==l11ll1_l1_ (u"ࠬ࠳࠱ࠨ啀"): l1lll11l_l1_.append(l11ll1_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ啁")+l11ll1_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭啂")+l1ll1lll1ll_l1_)
				else:
					for title in l111111llll1_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭啃")+l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ啄")+l1ll1lll1ll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ啅")+title)
			else:
				title = title.replace(l11ll1_l1_ (u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭商"),l11ll1_l1_ (u"ࠬ࠭啇"))
				title = title.strip(l11ll1_l1_ (u"࠭ࠢࠨ啈"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ啉"),l11ll1_l1_ (u"ࠨࠩ啊"),title,str(l1111l11l111_l1_))
				title = l11ll1_l1_ (u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨ啋")+l11ll1_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ啌")+l1ll1lll1ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠭啍")+title
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ啎") + download
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ問"),headers,l11ll1_l1_ (u"ࠧࠨ啐"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪ啑"))
		items = re.findall(l11ll1_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨ啒"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11ll1_l1_ (u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧ啓")+l11ll1_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ啔")+l1ll1lll1ll_l1_+l11ll1_l1_ (u"ࠬࠦࠧ啕")+resolution.split(l11ll1_l1_ (u"࠭ࡸࠨ啖"))[1]
			l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ啗")+id+l11ll1_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ啘")+mode+l11ll1_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ啙")+hash
			l1111l11l111_l1_.append(resolution)
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		l1111l11l111_l1_ = set(l1111l11l111_l1_)
		l1111l1llll1_l1_,l111lll11ll1_l1_ = [],[]
		for title in l1lll11l_l1_:
			#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ啚"),l11ll1_l1_ (u"ࠫࠬ啛"),title,l11ll1_l1_ (u"ࠬ࠭啜"))
			res = re.findall(l11ll1_l1_ (u"ࠨࠠࠩ࡞ࡧ࠮ࡽࢂ࡜ࡥࠬࠬࠪࠫࠨ啝"),title+l11ll1_l1_ (u"ࠧࠧࠨࠪ啞"),re.DOTALL)
			for resolution in l1111l11l111_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11ll1_l1_ (u"ࠨࡺࠪ啟"))[1])
			l1111l1llll1_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1llll_l1_)):
			items = re.findall(l11ll1_l1_ (u"ࠤࠩࠪ࠭࠴ࠪࡀࠫࠫࡠࡩ࠰ࠩࠧࠨࠥ啠"),l11ll1_l1_ (u"ࠪࠪࠫ࠭啡")+l1111l1llll1_l1_[i]+l11ll1_l1_ (u"ࠫࠫࠬࠧ啢"),re.DOTALL)
			l111lll11ll1_l1_.append( [l1111l1llll1_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l111lll11ll1_l1_ = sorted(l111lll11ll1_l1_, key=lambda x: x[3], reverse=True)
		l111lll11ll1_l1_ = sorted(l111lll11ll1_l1_, key=lambda x: x[2], reverse=False)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for i in range(len(l111lll11ll1_l1_)):
			l1lll11l_l1_.append(l111lll11ll1_l1_[i][0])
			l1llll_l1_.append(l111lll11ll1_l1_[i][1])
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ啣"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ啤"),l1lll11l_l1_,l1llll_l1_
def l111lll1lll1_l1_(url):
	# http://l1llllll11ll1_l1_.com/717254
	parts = url.split(l11ll1_l1_ (u"ࠧࡀࠩ啥"))
	l111lll_l1_ = parts[0]
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ啦") : l11ll1_l1_ (u"ࠩࠪ啧") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ啨"),headers,l11ll1_l1_ (u"ࠫࠬ啩"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࠬ啪"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ啫"),html,re.DOTALL)
	url = items[0]
	#l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111l11l1_l1_(url)
	#return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ啬"),[l11ll1_l1_ (u"ࠨࠩ啭")],[url]
def l1111lllll1l_l1_(url):
	# https://l1lllll111l_l1_.l1llll11l11_l1_/l1lllll1l11_l1_
	# https://l1llll11l1l_l1_.cc/l1lllll1l11_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭啮") : l11ll1_l1_ (u"ࠪࠫ啯") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬ啰"),headers,l11ll1_l1_ (u"ࠬ࠭啱"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ啲"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡࡸࡶࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ啳"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠨࠩ啴"),[l11ll1_l1_ (u"ࠩࠪ啵")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡕ࡛࡜࡙ࡖࡑ࠭啶"),[],[]
def l111llll111l_l1_(url):
	# https://l1lllll111l_l1_.l1llll11l11_l1_/l1lllll1l11_l1_
	# https://l1llll11l1l_l1_.cc/l1lllll1l11_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ啷") : l11ll1_l1_ (u"ࠬ࠭啸") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"࠭ࠧ啹"),headers,l11ll1_l1_ (u"ࠧࠨ啺"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ啻"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁࠬࠦࠬ啼"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠪࠫ啽"),[l11ll1_l1_ (u"ࠫࠬ啾")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠭啿"),[],[]
def l1ll1l1l1ll_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ喀"),l11ll1_l1_ (u"ࠧࠨ喁"),l11ll1_l1_ (u"ࠨࠩ喂"),url)
	# l11l1l1ll_l1_    https://show.l1111ll1ll1l_l1_.com/l1111ll111ll_l1_-l1111l1lllll_l1_/l1111l1lllll_l1_-l111ll111111_l1_.l1ll1lll1l_l1_?action=l1111l11l11l_l1_&post=32513&l1ll1l1ll11_l1_=1&type=l1lllll11l1_l1_
	# download https://show.l1111ll1ll1l_l1_.com/l1l1_l1_/l1111111llll_l1_
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠩࠪ喃")
	# l11l1l1ll_l1_
	if l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ善") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ喅"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ喆")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ喇"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ喈"),l11ll1_l1_ (u"ࠨࠩ喉"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬ喊"))
		l11ll1ll_l1_ = response.content
		if l11ll1ll_l1_.startswith(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ喋")): l111lll_l1_ = l11ll1ll_l1_
		else:
			l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬ喌"),l11ll1ll_l1_,re.DOTALL)
			if l11l111_l1_:
				l111lll_l1_ = l11l111_l1_[0]
				l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬࠨࠬ喍"),l111lll_l1_,re.DOTALL)
				if l11l111_l1_:
					l111lll_l1_ = l1111_l1_(l11l111_l1_[0])
					return l11ll1_l1_ (u"࠭ࠧ喎"),[l11ll1_l1_ (u"ࠧࠨ喏")],[l111lll_l1_]
	# download
	elif l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩ喐") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭喑"),url,l11ll1_l1_ (u"ࠪࠫ喒"),l11ll1_l1_ (u"ࠫࠬ喓"),True,l11ll1_l1_ (u"ࠬ࠭喔"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ喕"))
		l11ll1ll_l1_ = response.content
		if l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ喖") in list(response.headers.keys()): l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ喗")]
		else: l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭喘"),l11ll1ll_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ喙"),l11ll1_l1_ (u"ࠫࠬ喚"),l111lll_l1_,str(2222))
	if l11ll1_l1_ (u"ࠬ࠵ࡶ࠰ࠩ喛") in l111lll_l1_ or l11ll1_l1_ (u"࠭࠯ࡧ࠱ࠪ喜") in l111lll_l1_:
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠰ࡨ࠲ࠫ喝"),l11ll1_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ喞"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡺ࠴࠭喟"),l11ll1_l1_ (u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ喠"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ喡"),l11ll1_l1_ (u"ࠬ࠭喢"),l111lll_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ喣"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ喤"),l11ll1_l1_ (u"ࠨࠩ喥"),l11ll1_l1_ (u"ࠩࠪ喦"),l11ll1_l1_ (u"ࠪࠫ喧"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧ喨"))
		l11ll1ll_l1_ = response.content
		items = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喩"),l11ll1ll_l1_,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡝ࠩ喪"),l11ll1_l1_ (u"ࠧࠨ喫"))
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ喬"),l11ll1ll_l1_,re.DOTALL)
			if items:
				l1lllll_l1_ = items[0]
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠬ喭"),l11ll1_l1_ (u"ࠪࠫ單"))
				l1lll11l_l1_.append(l11ll1_l1_ (u"ࠫࠬ喯"))
				l1llll_l1_.append(l1lllll_l1_)
	else: return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ喰"),[l11ll1_l1_ (u"࠭ࠧ喱")],[l111lll_l1_]
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ喲"),l11ll1_l1_ (u"ࠨࠩ喳"),str(l11ll11l1_l1_),l111lll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ喴"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ喵"),l1lll11l_l1_,l1llll_l1_
def l1l1llllll11_l1_(url):
	# l11l1l1ll_l1_ l1111l1l_l1_  https://l111l11l11ll_l1_.l11l111l111l_l1_.l1llll11l11_l1_/l11llll1ll1_l1_/l1lllll1l1l11_l1_.l1ll1lll1l_l1_?s=07&id=l11l1l111111_l1_,&l1lll1_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1111l1111l1_l1_&l111ll1lll11_l1_=l1lllllll1l1l_l1_&l1111lll1lll_l1_=l1lllll1lllll_l1_
	# l11l1l1ll_l1_ l1llll111_l1_ https://l11l111l1ll1_l1_.l11l111l111l_l1_.l1llll11l11_l1_/l11llll1ll1_l1_/l111111111ll_l1_.l1ll1lll1l_l1_?l111lllll11l_l1_=l1111l1ll1ll_l1_&l111l1l1l111_l1_=8a26a6cc61a884e89076504130c71626&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111l1111l1_l1_&l111ll1lll11_l1_=l1lllllll1l1l_l1_&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111l1111l1_l1_&l111ll1lll11_l1_=l1lllllll1l1l_l1_&l1111lll1lll_l1_=l11111l1ll11_l1_
	# download https://www.l11l11111l11_l1_.l1111ll11l11_l1_/l111lll111ll_l1_?server=l1111111111l_l1_&id=l111l1lll11l_l1_,,
	# l1l111l1l_l1_ https://l11l11111l11_l1_.l1lll1111l_l1_/l1l111l1l_l1_/l111ll1l1l1l_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ営"),url,l11ll1_l1_ (u"ࠬ࠭喷"),l11ll1_l1_ (u"࠭ࠧ喸"),l11ll1_l1_ (u"ࠧࠨ喹"),l11ll1_l1_ (u"ࠨࠩ喺"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ喻"))
	html = response.content
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠪࠫ喼")
	if l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ喽") in url or l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭喾") in url:
		if l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ喿") in url:
			l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嗀"),html,re.DOTALL)
			l111lll_l1_ = l111lll_l1_[0]
		else: l111lll_l1_ = url
		if l11ll1_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ嗁") not in l111lll_l1_: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嗂"),[l11ll1_l1_ (u"ࠪࠫ嗃")],[l111lll_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嗄"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭嗅"),l11ll1_l1_ (u"࠭ࠧ嗆"),l11ll1_l1_ (u"ࠧࠨ嗇"),l11ll1_l1_ (u"ࠨࠩ嗈"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩ嗉"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭嗊"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嗋"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1ll1l1lll11_l1_ in items:
				l1lll11l_l1_.append(l1ll1l1lll11_l1_)
				l1llll_l1_.append(l1lllll_l1_)
	elif l11ll1_l1_ (u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧ嗌") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪ嗍"),html,re.DOTALL)
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ嗎"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ嗏"),l11ll1_l1_ (u"ࠩࠪ嗐"),l11ll1_l1_ (u"ࠪࠫ嗑"),l11ll1_l1_ (u"ࠫࠬ嗒"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬ嗓"))
		html = response.content
		l11l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗔"),html,re.DOTALL)
		l11l111_l1_ = l11l111_l1_[0]
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠧࠨ嗕"))
		l1llll_l1_.append(l11l111_l1_)
	elif l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨ嗖") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嗗"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嗘"),[l11ll1_l1_ (u"ࠫࠬ嗙")],[l111lll_l1_]
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧ嗚"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ嗛"),l1lll11l_l1_,l1llll_l1_
def l11111ll11_l1_(url):
	# https://l111llll11ll_l1_.l1111ll1llll_l1_/l1l1111llll_l1_?call=l111ll1ll111_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111lllll_l1_=l111l11ll11l_l1_
	# https://l111llll11ll_l1_.l1111ll1llll_l1_/l1l1111llll_l1_?call=l111ll1ll111_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111lllll_l1_=l1111ll111l1_l1_
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ嗜"),1)[0].strip(l11ll1_l1_ (u"ࠨࡁࠪ嗝")).strip(l11ll1_l1_ (u"ࠩ࠲ࠫ嗞")).strip(l11ll1_l1_ (u"ࠪࠪࠬ嗟"))
	l1lll11l_l1_,l1llll_l1_,items,l11l111_l1_ = [],[],[],l11ll1_l1_ (u"ࠫࠬ嗠")
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ嗡"):l11ll1_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭嗢") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ嗣"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ嗤"),headers,True,l11ll1_l1_ (u"ࠩࠪ嗥"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫ嗦"))
	if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭嗧") in list(response.headers.keys()): l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ嗨")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ嗩"),l11l111_l1_,l11ll1_l1_ (u"ࠧࠨ嗪"),headers,False,l11ll1_l1_ (u"ࠨࠩ嗫"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠲࡯ࡦࠪ嗬"))
	#if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ嗭") in response.headers: l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭嗮")]
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嗯"),l11ll1_l1_ (u"࠭ࠧ嗰"),l11l111_l1_,response.content)
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ嗱") in l11l111_l1_:
		# https://l1111l11l1_l1_.top/f/l111ll111l1l_l1_/?l111ll111l_l1_=l11l1l11ll11_l1_
		# https://l1111l11l1_l1_.top/v/l111ll111l1l_l1_/?l111ll111l_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ嗲") in url: l11l111_l1_ = l11l111_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡪ࠴࠭嗳"),l11ll1_l1_ (u"ࠪ࠳ࡻ࠵ࠧ嗴"))
		l11l11l11l11_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭嗵"))[1]
		headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ嗶"):headers[l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ嗷")] , l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ嗸"):l11ll1_l1_ (u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩ嗹")+l11l11l11l11_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嗺"),l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ嗻"),headers,False,l11ll1_l1_ (u"ࠫࠬ嗼"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ嗽"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1lll1_l1_,l11l111_l1_,l11ll1_l1_ (u"࠭ࠧ嗾"),headers,l11ll1_l1_ (u"ࠧࠨ嗿"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠹ࡲࡥࠩ嘀"))
		if l11ll1_l1_ (u"ࠩ࠲ࡪ࠴࠭嘁") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嘂"),html,re.DOTALL)
		elif l11ll1_l1_ (u"ࠫ࠴ࡼ࠯ࠨ嘃") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嘄"),html,re.DOTALL)
		if items: return [],[l11ll1_l1_ (u"࠭ࠧ嘅")],[ items[0] ]
		elif l11ll1_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭嘆") in html:
			return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫ嘇"),[],[]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬ嘈"),[],[]
	#xbmc.log(html)
def l1111lll1ll_l1_(l1lllll_l1_):
	# https://l11l1l11llll_l1_.net/?l11lll11_l1_=147043&l11llll1_l1_=5
	parts = re.findall(l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ嘉"),l1lllll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ嘊"),re.DOTALL|re.IGNORECASE)
	l11lll11_l1_,l11llll1_l1_ = parts[0]
	url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭嘋")+l11lll11_l1_+l11ll1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ嘌")+l11llll1_l1_
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嘍"):l11ll1_l1_ (u"ࠨࠩ嘎") , l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ嘏"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ嘐") }
	l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ嘑"),headers,l11ll1_l1_ (u"ࠬ࠭嘒"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮࠳ࡶࡸࠬ嘓"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嘔"),l11ll1_l1_ (u"ࠨࠩ嘕"),url,l111lll_l1_)
	#l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111l11l1_l1_(l111lll_l1_)
	#return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嘖"),[l11ll1_l1_ (u"ࠪࠫ嘗")],[l111lll_l1_]
def l1ll11llllll_l1_(url):
	# https://l1llllll111ll_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll111l11_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111lll1ll11_l1_=1608181746
	server = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ嘘"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭嘙"):server,l11ll1_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ嘚"):l11ll1_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ嘛")}
	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ嘜"),url,l11ll1_l1_ (u"ࠩࠪ嘝"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠪࠫ嘞"),l11ll1_l1_ (u"ࠫࠬ嘟"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ嘠"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ嘡"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠧࠨ嘢")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘣"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ嘤"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠪࠫ嘥"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嘦"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧ嘧"),[],[]
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嘨"),[l11ll1_l1_ (u"ࠧࠨ嘩")],[l111lll_l1_]
def l1l1ll11llll_l1_(url):
	# https://l11l1l1l1111_l1_.l111111l1l11_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll111l11_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111lll1ll11_l1_=1608181746
	# https://l11l1l1l1111_l1_.l1111ll1llll_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111ll111l11_l1_=l11l11ll1lll_l1_&l111lll1ll11_l1_=1684182121
	server = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ嘪"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ嘫"):server,l11ll1_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ嘬"):l11ll1_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ嘭")}
	response = OPENURL_REQUESTS_CACHED(l1ll11lll111_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ嘮"),url,l11ll1_l1_ (u"࠭ࠧ嘯"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ嘰"),l11ll1_l1_ (u"ࠨࠩ嘱"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ嘲"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ嘳"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ嘴")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ嘵"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ嘶"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࠨ嘷"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	if not l111lll_l1_:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘸"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫ嘹"),[],[]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嘺"),[l11ll1_l1_ (u"ࠫࠬ嘻")],[l111lll_l1_]
def l1l11ll1_l1_(l1lllll_l1_):
	# https://w.l1111l1l11ll_l1_.l11l1111l11l_l1_/l1111ll111ll_l1_-content/l11l11llllll_l1_/l1111l11lll1_l1_/l11l11111lll_l1_/l1111l11ll1l_l1_/l111l11l11l1_l1_/l1111ll11ll1_l1_.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嘼"),l11ll1_l1_ (u"࠭ࠧ嘽"),l1lllll_l1_,html)
	parts = re.findall(l11ll1_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭嘾"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ嘿"),re.DOTALL)
	url,l11lll11_l1_,l11llll1_l1_ = parts[0]
	data = {l11ll1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ噀"):l11lll11_l1_,l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ噁"):l11llll1_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ噂"),url,data,l11ll1_l1_ (u"ࠬ࠭噃"),l11ll1_l1_ (u"࠭ࠧ噄"),l11ll1_l1_ (u"ࠧࠨ噅"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪ噆"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ噇"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭噈"),[l11ll1_l1_ (u"ࠫࠬ噉")],[l111lll_l1_]
def l1ll1l1lll_l1_(url):
	# https://l111lll1l111_l1_.l1lll11111_l1_-l111llll11l1_l1_.com/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1ll_l1_=l1111llll11l_l1_
	# https://l.l1111ll11lll_l1_.l1111ll11l11_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1ll_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ噊"),url,l11ll1_l1_ (u"࠭ࠧ噋"),l11ll1_l1_ (u"ࠧࠨ噌"),l11ll1_l1_ (u"ࠨࠩ噍"),l11ll1_l1_ (u"ࠩࠪ噎"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭噏"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ噐"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ噑"),[l11ll1_l1_ (u"࠭ࠧ噒")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ噓"),[],[]
def l1lll111ll_l1_(url):
	# https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/l1111ll111ll_l1_-content/l11l11llllll_l1_/old/l1lll11_l1_/server.l1ll1lll1l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ噔"),url,l11ll1_l1_ (u"ࠩࠪ噕"),l11ll1_l1_ (u"ࠪࠫ噖"),l11ll1_l1_ (u"ࠫࠬ噗"),l11ll1_l1_ (u"ࠬ࠭噘"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ噙"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噚"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ噛"),[l11ll1_l1_ (u"ࠩࠪ噜")],[l1lllll_l1_]
def l1ll1l1ll1_l1_(url):
	# https://l1l11l1l11l_l1_.l1l11ll1llll_l1_.cc/l1111ll111ll_l1_-content/l11l11llllll_l1_/l11111l11ll1_l1_%20Now%20New/l1111111ll1l_l1_.l1ll1lll1l_l1_?action=l111lll1llll_l1_&index=00&id=58504
	# https://l111ll1111ll_l1_.l1l11ll1llll_l1_.net/l1111111lll1_l1_/2021/04/05/_1111llll1ll_l1_-l11l1l11l1l1_l1_.l1lllll1l1ll1_l1_ 200.l11111111ll1_l1_.2020.l111111ll111_l1_/[l11111l11ll1_l1_-l11l1l11l1l1_l1_.l11111ll1l1l_l1_] 200.l11111111ll1_l1_.2020.l111111ll111_l1_-360p.l1111l1l_l1_
	l1lllll1l1_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ噝"))
	if l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ噞") in url:
		headers = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭噟"):l1lllll1l1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ噠"),url,l11ll1_l1_ (u"ࠧࠨ噡"),headers,l11ll1_l1_ (u"ࠨࠩ噢"),l11ll1_l1_ (u"ࠩࠪ噣"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ噤"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ噥"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			if l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭噦") in l111lll_l1_:
				l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ噧"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ器"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ噩"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ噪"),headers,l11ll1_l1_ (u"ࠪࠫ噫"),l11ll1_l1_ (u"ࠫࠬ噬"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭噭"))
				l11ll1ll_l1_ = response.content
				items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ噮"),l11ll1ll_l1_,re.DOTALL)
				l1lll11l_l1_,l1llll_l1_ = [],[]
				l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ噯"))
				for l1lllll_l1_,l111llll_l1_ in reversed(items):
					l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ噰")+l1llll1l1l_l1_
					l1lll11l_l1_.append(l111llll_l1_)
					l1llll_l1_.append(l1lllll_l1_)
				return l11ll1_l1_ (u"ࠩࠪ噱"),l1lll11l_l1_,l1llll_l1_
			else: return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭噲"),[l11ll1_l1_ (u"ࠫࠬ噳")],[l111lll_l1_]
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ噴")+l1lllll1l1_l1_
	return l11ll1_l1_ (u"࠭ࠧ噵"),[l11ll1_l1_ (u"ࠧࠨ噶")],[l111lll_l1_]
def l111l1l11l11_l1_(l1lllll_l1_):
	# https://l1l11ll1llll_l1_.l11l1111l11l_l1_/l1111ll111ll_l1_-content/l11l11llllll_l1_/l111lll1ll1l_l1_/l111111l1111_l1_/server.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	# https://l11l111ll111_l1_.l1l11ll1llll_l1_.net/l1111111lll1_l1_/2020/08/14/_1111llll1ll_l1_-l11l1l11l1l1_l1_.l1lllll1l1ll1_l1_ l11111l111ll_l1_.l111l11lll11_l1_.2020.l111l1111l11_l1_-l111l1l1111l_l1_/[l11111l11ll1_l1_-l11l1l11l1l1_l1_.l11111ll1l1l_l1_] l11111l111ll_l1_.l111l11lll11_l1_.2020.l111l1111l11_l1_-l111l1l1111l_l1_-1080p.l1111l1l_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ噷"),l11ll1_l1_ (u"ࠩࠪ噸"),url,html)
	l1lllll1l1_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ噹"))
	if l11ll1_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ噺") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ噻"),l1lllll_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ噼"),re.DOTALL)
		url,l11lll11_l1_,l11llll1_l1_ = parts[0]
		data = {l11ll1_l1_ (u"ࠧࡪࡦࠪ噽"):l11lll11_l1_,l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ噾"):l11llll1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ噿"),url,data,l11ll1_l1_ (u"ࠪࠫ嚀"),l11ll1_l1_ (u"ࠫࠬ嚁"),l11ll1_l1_ (u"ࠬ࠭嚂"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ嚃"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嚄"),html,re.DOTALL)[0]
		if l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ嚅") in l111lll_l1_:
			headers = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ嚆"):l1lllll1l1_l1_,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ嚇"):l11ll1_l1_ (u"ࠫࠬ嚈")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ嚉"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ嚊"),headers,l11ll1_l1_ (u"ࠧࠨ嚋"),l11ll1_l1_ (u"ࠨࠩ嚌"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ嚍"))
			l11ll1ll_l1_ = response.content
			items = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚎"),l11ll1ll_l1_,re.DOTALL)
			l1lll11l_l1_,l1llll_l1_ = [],[]
			l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ嚏"))
			for l1lllll_l1_,l111llll_l1_ in reversed(items):
				l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ嚐")+l1llll1l1l_l1_
				l1lll11l_l1_.append(l111llll_l1_)
				l1llll_l1_.append(l1lllll_l1_)
			return l11ll1_l1_ (u"࠭ࠧ嚑"),l1lll11l_l1_,l1llll_l1_
		else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嚒"),[l11ll1_l1_ (u"ࠨࠩ嚓")],[l111lll_l1_]
	else:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ嚔")+l1lllll1l1_l1_
		return l11ll1_l1_ (u"ࠪࠫ嚕"),[l11ll1_l1_ (u"ࠫࠬ嚖")],[l1lllll_l1_]
def l111ll1ll_l1_(l1lllll_l1_):
	# http://l11l11ll11ll_l1_.tv/?l11lll11_l1_=159485&l11llll1_l1_=0
	if l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ嚗") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ嚘"),l1lllll_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ嚙"),re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		host = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ嚚"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嚛"),l11ll1_l1_ (u"ࠪࠫ嚜"),l1lllll_l1_,host)
		url = host+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ嚝")+l11lll11_l1_+l11ll1_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ嚞")+l11llll1_l1_
		headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ嚟"):l11ll1_l1_ (u"ࠧࠨ嚠") , l11ll1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ嚡"):l11ll1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ嚢") }
		l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ嚣"),headers,l11ll1_l1_ (u"ࠫࠬ嚤"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ嚥"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ嚦"),l11ll1_l1_ (u"ࠧࠨ嚧")).replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ嚨"),l11ll1_l1_ (u"ࠩࠪ嚩"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嚪"),l11ll1_l1_ (u"ࠫࠬ嚫"),url,l111lll_l1_)
		#l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111l11l1_l1_(l111lll_l1_)
		#return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嚬"),[l11ll1_l1_ (u"࠭ࠧ嚭")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ嚮") in l1lllll_l1_:
		counts = 0
		while l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ嚯") in l1lllll_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嚰"),l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ嚱"),l11ll1_l1_ (u"ࠫࠬ嚲"),l11ll1_l1_ (u"ࠬ࠭嚳"),l11ll1_l1_ (u"࠭ࠧ嚴"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩ嚵"))
			if l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ嚶") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ嚷")]
			counts += 1
		return l11ll1_l1_ (u"ࠪࠫ嚸"),[l11ll1_l1_ (u"ࠫࠬ嚹")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ嚺"),[],[]
def l11l11ll1_l1_(url):
	# https://l1111lll1111_l1_.l11111ll111l_l1_.me/l/l11l11lll1l1_l1_=
	# https://l111ll1ll1l1_l1_.l111111ll1l1_l1_.net/l1l111l1l_l1_-l1l111l1l_l1_-l11111l11111_l1_.html
	# https://m.l111111ll1l1_l1_.net/l11111l11111_l1_
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嚻"),l11ll1_l1_ (u"ࠧࠨ嚼"),l11ll1_l1_ (u"ࠨࠩ嚽"),url)
	server = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭嚾"))
	if l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ嚿") in url and l11ll1_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ囀") not in url: url = server+l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭囁")+url.split(l11ll1_l1_ (u"࠭࠯ࠨ囂"))[-1]+l11ll1_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭囃")
	headers = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ囄"):server,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭囅"):l11llllll_l1_()}
	if l11ll1_l1_ (u"ࠪ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ囆") in url:
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ囇"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ囈")}
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ囉"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,True,l11ll1_l1_ (u"ࠧࠨ囊"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠱ࡴࡶࠪ囋"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ囌"),html,re.DOTALL|re.IGNORECASE)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠪࠫ囍"),[l11ll1_l1_ (u"ࠫࠬ囎")],[l1lllll_l1_[0]]
	elif l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭囏") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ囐"),headers,l11ll1_l1_ (u"ࠧࠨ囑"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ囒"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ囓"),html,re.DOTALL)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠪࠫ囔"),[l11ll1_l1_ (u"ࠫࠬ囕")],[l1lllll_l1_[0]]
	else:
		l1111lll11ll_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ囖"),url,l11ll1_l1_ (u"࠭ࠧ囗"),headers,l11ll1_l1_ (u"ࠧࠨ囘"),l11ll1_l1_ (u"ࠨࠩ囙"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ囚"))
		html = l1111lll11ll_l1_.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭四"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])+l11ll1_l1_ (u"ࠫࠫࡪ࠽࠲ࠩ囜")
			l1ll1111l_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ囝"),l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ回"),headers,l11ll1_l1_ (u"ࠧࠨ囟"),l11ll1_l1_ (u"ࠨࠩ因"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ囡"))
			html = l1ll1111l_l1_.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭团"),html,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠫࠬ団"),[l11ll1_l1_ (u"ࠬ࠭囤")],[l1lllll_l1_]
		if l11ll1_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ囥") in list(l1111lll11ll_l1_.headers.keys()):
			cookies = l1111lll11ll_l1_.headers[l11ll1_l1_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫ囦")]
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡡ࡯ࡲࡰࡥ࠮ࠫࡁࡀࠬ࠳࠰࠿ࠪ࠽ࠪ囧"),cookies,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ囨"),[l11ll1_l1_ (u"ࠪࠫ囩")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ囪"),[],[]
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࠥࡴ࡯ࡵࠢࡺࡳࡷࡱࡩ࡯ࡩࠍࠍࠎࠩࠠࡪࡶࠣࡲࡪ࡫ࡤࡴࠢࡦࡳࡴࡱࡩࡦࠢࡩࡶࡴࡳࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠎࠎࠏࠣࠡࡅࡲࡳࡰ࡯ࡥ࠻ࠢࡦࡪࡤࡩ࡬ࡦࡣࡵࡥࡳࡩࡥ࠾ࡅࡐࡩ࠳ࡎࡋࡈࡓ࡮ࡱࡼࡴࡓࡗࡷࡱࡾ࡛ࡏࡰࡲࡱࡺࡵࡘࡇ࡚ࡤࡲࡱࡊ࠼ࡰࡂࡑࡗࡒࡕࡧ࡟ࡂࡇ࠲࠰࠵࠻࠼࠳࠲࠳࠵࠴࠵࠼࠭࠱࠯࠵࠹࠵ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࠫࡹࡷࡲࠬࠨࡷࡵࡰࠬ࠯ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠩࠫ࠯ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࡳࡦࡴࡹࡩࡷࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨࠫࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࡿࡶࡪ࠴ࡉࡈࡐࡒࡖࡊࡉࡁࡔࡇࠬࠎࠎࠏࡩࡧࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡦ࡯ࡥࡩࡩ࠳ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࠩ࠯࡟ࠬ࠭࡝࠭࡝࡯࡭ࡳࡱ࡝ࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪ࠮࡫ࡸࡲࡲࠩࠋࠋࠌࠧࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠉࠤ࡫ࡩࠤࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠦࠍࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠥࠌࡶࡪࡺࡵࡳࡰࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠦࠧࠨ囫")
	#if l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷࠲࡭ࡺ࡭࡭ࠩ囬") in url:
	#	l1ll1ll11ll1_l1_ = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ园"))
	#	url = l11ll1_l1_ (u"ࠨ࠱ࠪ囮").join(l1ll1ll11ll1_l1_[:4])
	#	tmp = re.findall(l11ll1_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠳࠴࠴ࠪࡀ࠱ࠬࠬ࠳࠰࠿ࠪࠦࠪ囯"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ困")+tmp[0][1]+l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ囱")
	#	#return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ囲"),[l11ll1_l1_ (u"࠭ࠧ図")],[url]
	#	#l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll1ll_l1_(url)
	#	#return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
	# l1l111l1l_l1_ l1lllll_l1_
	#return l11ll1_l1_ (u"ࠧࠨ围"),[l11ll1_l1_ (u"ࠨࠩ囵")],[l1lllll_l1_]
def l1l1ll11l111_l1_(l1lllll_l1_):
	# https://l111l111ll11_l1_.l111l1l111ll_l1_/l1lllll1l111l_l1_?_11111lll111_l1_=l1llllll1ll1l_l1_&_1111l11l1ll_l1_=86046&l11llll1_l1_=0
	if l11ll1_l1_ (u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭囶") in l1lllll_l1_:
		headers = {l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭囷"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ囸")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ囹"),l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ固"),headers,l11ll1_l1_ (u"ࠧࠨ囻"),l11ll1_l1_ (u"ࠨࠩ囼"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ国"))
		url = response.content
		if url: return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭图"),[l11ll1_l1_ (u"ࠫࠬ囿")],[url]
	else:
		# https://l111111ll1ll_l1_.net/?l11lll11_l1_=142302&l11llll1_l1_=4
		parts = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭圀"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11ll1_l1_ (u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ圁"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ圂"))
		#url = server+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ圃")
		url = server+l11ll1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ圄")
		#url = server+l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ圅")+l11lll11_l1_+l11ll1_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ圆")+l11llll1_l1_
		#data = {l11ll1_l1_ (u"ࠬ࡯ࡤࠨ圇"):l11lll11_l1_,l11ll1_l1_ (u"࠭ࡩࠨ圈"):l11llll1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡧࡷࡥࠬ圉"):l11ll1_l1_ (u"ࠨࡱ࡯ࡨࡤࡹࡥࡳࡸࡨࡶࡸ࠭圊"),l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ國"):l11ll1_l1_ (u"ࠪࡳࡱࡪࠧ圌")}
		data = {l11ll1_l1_ (u"ࠫ࡮ࡪࠧ圍"):l11lll11_l1_,l11ll1_l1_ (u"ࠬ࡯ࠧ圎"):l11llll1_l1_}
		headers = {l11ll1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ圏"):l11ll1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ圐"),l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ圑"):l1lllll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ園"),url,data,headers,l11ll1_l1_ (u"ࠪࠫ圓"),l11ll1_l1_ (u"ࠫࠬ圔"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ圕"))
		l11ll1ll_l1_ = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ圖"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ圗"),[l11ll1_l1_ (u"ࠨࠩ團")],[l111lll_l1_]
	return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭圙"),[],[]
def l1lllll1_l1_(url,type,l111llll_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ圚"),l11ll1_l1_ (u"ࠫࠬ圛"),l111lll_l1_,type)
	# http://l1111ll1lll1_l1_.l11l11l111ll_l1_.io/l1lllll_l1_/136530
	l1llll11_l1_,l111l1111lll_l1_ = [],[]
	l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠬ࠭圜"),l11ll1_l1_ (u"࠭ࠧ圝"),True,l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭圞"))
	l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ土"),l11ll1ll_l1_,re.DOTALL)
	for block in l1111l1_l1_:
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭圠"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ in l1llll11_l1_: continue
			if l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ圡") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ圢") not in l1lllll_l1_: continue
			title = title.replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭圣"),l11ll1_l1_ (u"࠭ࠧ圤")).replace(l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ圥"),l11ll1_l1_ (u"ࠨࠩ圦")).strip(l11ll1_l1_ (u"ࠩࠣࠫ圧")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭在"),l11ll1_l1_ (u"ࠫࠥ࠭圩"))
			l1llll11_l1_.append(l1lllll_l1_)
			l111l1111lll_l1_.append(title)
	if not l1llll11_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭圪"),[],[]
	if len(l1llll11_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭圫"),l111l1111lll_l1_)
		if l1l_l1_==-1: l1l_l1_ = 0
	else: l1l_l1_ = 0
	l11l111_l1_ = l1llll11_l1_[l1l_l1_]
	l1llll_l1_,l1lll11l_l1_ = [],[]
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ圬"),l11l111_l1_,l11ll1_l1_ (u"ࠨࠩ圭"),l11ll1_l1_ (u"ࠩࠪ圮"),l11ll1_l1_ (u"ࠪࠫ圯"),True,l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠲࡯ࡦࠪ地"))
	l1l1ll1l1_l1_ = response.content
	if type==l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ圱"):
		l1llllll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡢࡵࡰ࠰ࡰࡴࡧࡤࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ圲"),l1l1ll1l1_l1_,re.DOTALL)
		if l1llllll1_l1_:
			l1lllll_l1_ = l1111_l1_(l1llllll1_l1_[0])
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(l111llll_l1_)
	elif type==l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭圳"):
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圴"),l1l1ll1l1_l1_,re.DOTALL)
		for l1lllll_l1_,size in l1l1_l1_:
			if not l1lllll_l1_: continue
			if l111llll_l1_ in size:
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
				break
		if not l1llll_l1_:
			for l1lllll_l1_,size in l1l1_l1_:
				if not l1lllll_l1_: continue
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ圵"),l1llll_l1_)
	if not l1llll_l1_: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ圶"),[],[]
	return l11ll1_l1_ (u"ࠫࠬ圷"),l1lll11l_l1_,l1llll_l1_
def l11llll_l1_(url,name):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭圸"),l11ll1_l1_ (u"࠭ࠧ圹"),url,l11l111lllll_l1_)
	# http://l11ll1l11ll_l1_.l1111l1l11ll_l1_.net/5cf68c23e6e79			?l11l111lllll_l1_=			__11l1l111lll_l1_
	# http://w.l11ll111_l1_.l1llll11l11_l1_/5e14fd0a2806e			?l11l111lllll_l1_=			ok.l1111lll1ll1_l1_
	#l11l111lllll_l1_ = l11l111lllll_l1_.replace(l11ll1_l1_ (u"ࠧࡢ࡭ࡲࡥࡲࡥ࡟ࠨ场"),l11ll1_l1_ (u"ࠨࠩ圻")).split(l11ll1_l1_ (u"ࠩࡢࡣࠬ圼"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ圽"),url,l11ll1_l1_ (u"ࠫࠬ圾"),l11ll1_l1_ (u"ࠬ࠭圿"),True,l11ll1_l1_ (u"࠭ࠧ址"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭坁"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ坂") in list(cookies.keys()):
		l11l1l111_l1_ = cookies[l11ll1_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ坃")]
		l11l1l111_l1_ = l1111_l1_(escapeUNICODE(l11l1l111_l1_))
		items = re.findall(l11ll1_l1_ (u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ坄"),l11l1l111_l1_,re.DOTALL)
		l111lll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ坅"),l11ll1_l1_ (u"ࠬ࠵ࠧ坆"))
		l111lll_l1_ = escapeUNICODE(l111lll_l1_)
	else: l111lll_l1_ = url
	if l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ均") in l111lll_l1_:
		id = l111lll_l1_.split(l11ll1_l1_ (u"ࠧࠦ࠴ࡉࠫ坈"))[-1]
		l111lll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫ坉")+id
		return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ坊"),[l11ll1_l1_ (u"ࠪࠫ坋")],[l111lll_l1_]
	else:
		l1l1l1l1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ坌")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ坍"),l1l1l1l1_l1_,l11ll1_l1_ (u"࠭ࠧ坎"),l11ll1_l1_ (u"ࠧࠨ坏"),True,l11ll1_l1_ (u"ࠨࠩ坐"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠷ࡴࡤࠨ坑"))
		l11l111lll1l_l1_ = response.url
		#l11l111lll1l_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ坒")]
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ坓"),l11ll1_l1_ (u"ࠬ࠭坔"),response.url,l1l1l1l1_l1_)
		l111l1111l1l_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ坕"))[2]#.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ坖"))
		l11l1l1l11l1_l1_ = l11l111lll1l_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ块"))[2]#.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ坘"))
		l11l111_l1_ = l111lll_l1_.replace(l111l1111l1l_l1_,l11l1l1l11l1_l1_)
		headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ坙"):l11ll1_l1_ (u"ࠫࠬ坚") , l11ll1_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ坛"):l11ll1_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ坜") , l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ坝"):l11l111_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭坞"), l11l111_l1_, l11ll1_l1_ (u"ࠩࠪ坟"), headers, False,l11ll1_l1_ (u"ࠪࠫ坠"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪ坡"))
		html = response.content
		#xbmc.log(str(l11l111_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ坢"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11ll1_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ坣"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ坤"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ坥"),l11ll1_l1_ (u"ࠩࠪ坦"),str(items),html)
		if items:
			l1lllll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭坧"),l11ll1_l1_ (u"ࠫ࠴࠭坨"))
			l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠬ࠵ࠧ坩"))
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ坪") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭坫") + l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ坬"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ坭"))
			if name==l11ll1_l1_ (u"ࠪࠫ坮"): l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠫࠬ坯"),[l11ll1_l1_ (u"ࠬ࠭坰")],[l1lllll_l1_]
			else: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ坱"),[l11ll1_l1_ (u"ࠧࠨ坲")],[l1lllll_l1_]
		else: l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐࡕࡁࡎࠩ坳"),[],[]
		return l11l11llll1l_l1_,l1lll11l_l1_,l1llll_l1_
def l111llllll1l_l1_(url):
	# https://www.l11l1111l1ll_l1_.com/e/l11111l1111l_l1_
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭坴") : l11ll1_l1_ (u"ࠪࠫ坵") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ坶"),headers,l11ll1_l1_ (u"ࠬ࠭坷"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ坸"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ坹"),l11ll1_l1_ (u"ࠨࠩ坺"),url,html)
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ坻"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠪࠫ坼")
	if items:
		for l1lllll_l1_,l1ll1l1lll11_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1lll11_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑࠪ坽"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭坾"),l1lll11l_l1_,l1llll_l1_
def l11111ll11l1_l1_(url):
	# https://l1111l1lll1l_l1_.io/l1l111l1l_l1_-l11111ll1l11_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭坿"),l11ll1_l1_ (u"ࠧࠨ垀"))
	headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ垁"):l11ll1_l1_ (u"ࠩࠪ垂")}
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ垃"),headers,l11ll1_l1_ (u"ࠫࠬ垄"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ垅"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ垆"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ垇"),l11ll1_l1_ (u"ࠨࠩ垈"),url,items[0])
	if items:
		url = items[0]+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ垉")+url
		return l11ll1_l1_ (u"ࠪࠫ垊"),[l11ll1_l1_ (u"ࠫࠬ型")],[url]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡓࡏࡓࡆࡊࠧ垌"),[],[]
def l111l1l1ll11_l1_(url):
	# https://l1lllll1l11l1_l1_.to/l1l111l1l_l1_/5c83f14297d62
	url = url.strip(l11ll1_l1_ (u"࠭࠯ࠨ垍"))
	if l11ll1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ垎") in url: id = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ垏"))[4]
	else: id = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ垐"))[-1]
	url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡩࡳࡵࡴࡨࡥࡲ࠴ࡴࡰ࠱ࡳࡰࡦࡿࡥࡳࡁࡩ࡭ࡩࡃࠧ垑") + id
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ垒") : l11ll1_l1_ (u"ࠬ࠭垓") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ垔"),headers,l11ll1_l1_ (u"ࠧࠨ垕"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡉࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ垖"))
	html = html.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠬ垗"),l11ll1_l1_ (u"ࠪࠫ垘"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ垙"),l11ll1_l1_ (u"ࠬ࠭垚"),url,html)
	items = re.findall(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垛"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠧࠨ垜"),[l11ll1_l1_ (u"ࠨࠩ垝")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭垞"),[],[]
def l1111l111l1l_l1_(url):
	# https://l11l11ll1111_l1_.net/l1l111l1l_l1_-l111lll1l1ll_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ垟"),l11ll1_l1_ (u"ࠫࠬ垠"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭垡"),l11ll1_l1_ (u"࠭ࠧ垢"),l11ll1_l1_ (u"ࠧࠨ垣"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡐ࡜ࡄ࠱࠶ࡹࡴࠨ垤"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࡷ࡫ࡳ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ垥"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for l1lllll_l1_,l1ll1l1lll11_l1_,res in items:
		l1lll11l_l1_.append(l1ll1l1lll11_l1_+l11ll1_l1_ (u"ࠪࠤࠬ垦")+res)
		l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭垧"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭垨"),l1lll11l_l1_,l1llll_l1_
def l111ll11l1l1_l1_(url):
	# https://l11l11lllll1_l1_.l1llll11111_l1_/l1l111l1l_l1_-l1111l1l111l_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭垩"),l11ll1_l1_ (u"ࠧࠨ垪"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ垫"),l11ll1_l1_ (u"ࠩࠪ垬"),l11ll1_l1_ (u"ࠪࠫ垭"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ垮"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥ垯"),html,re.DOTALL)
	items = set(items)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1ll1l1lll11_l1_,res in items:
		url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ垰")+id+l11ll1_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ垱")+mode+l11ll1_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ垲")+hash
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ垳"),l11ll1_l1_ (u"ࠪࠫ垴"),l11ll1_l1_ (u"ࠫࠬ垵"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ垶"))
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ垷"),html,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1lll11_l1_+l11ll1_l1_ (u"ࠧࠡࠩ垸")+res)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧ垹"),[],[]
	return l11ll1_l1_ (u"ࠩࠪ垺"),l1lll11l_l1_,l1llll_l1_
def l1lllll1l11ll_l1_(url):
	# https://l1llllll1llll_l1_.com:2053/l1lllllll11l1_l1_/l1111l11ll11_l1_.l111ll1l1lll_l1_.l11l1l11ll1l_l1_.1080p.l11l1l111l1l_l1_.l11l111llll1_l1_.l1llllll111l1_l1_.l1111l1l_l1_.html?l111ll111l11_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111lll1ll11_l1_=1624070560
	# http://l1111111l1l1_l1_.l111lll1ll1_l1_/l111ll1l111l_l1_/l111ll1ll1ll_l1_.l111l11l1l1l_l1_.l111lll11lll_l1_.2018.1080p.l111l1111l11_l1_-l111l1l1111l_l1_.l1111111l111_l1_.l1111l1l_l1_.html
	l1lllll_l1_ = l11ll1_l1_ (u"ࠪࠫ垻")
	if 1 or l11ll1_l1_ (u"ࠫࡐ࡫ࡹ࠾ࠩ垼") not in url:
		l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩ垽"),l11ll1_l1_ (u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪ垾"))
		l111lll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠧ࠰ࠩ垿"))
		id = l111lll_l1_[3]
		l111lll_l1_ = l11ll1_l1_ (u"ࠨ࠱ࠪ埀").join(l111lll_l1_[0:4])
		#headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭埁"):l11llllll_l1_(),l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ埂"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ埃")}
		payload = {l11ll1_l1_ (u"ࠬ࡯ࡤࠨ埄"):id,l11ll1_l1_ (u"࠭࡯ࡱࠩ埅"):l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ埆"),l11ll1_l1_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭埇"):l11ll1_l1_ (u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ埈")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ埉"),l111lll_l1_,payload,l11ll1_l1_ (u"ࠫࠬ埊"),l11ll1_l1_ (u"ࠬ࠭埋"),l11ll1_l1_ (u"࠭ࠧ埌"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡕࡈࡏࡎ࠯࠴ࡷࡹ࠭埍"))
		if l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ城") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ埏")]
		if not l1lllll_l1_ and response.succeeded:
			html = response.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埐"),html,re.DOTALL)
			if l1lllll_l1_: l1lllll_l1_ = l1lllll_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ埑"),url,l11ll1_l1_ (u"ࠬ࠭埒"),l11ll1_l1_ (u"࠭ࠧ埓"),l11ll1_l1_ (u"ࠧࠨ埔"),l11ll1_l1_ (u"ࠨࠩ埕"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ埖"))
		if l11ll1_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ埗") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭埘")]
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠬ࠭埙"),[l11ll1_l1_ (u"࠭ࠧ埚")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡔࡇࡕࡍࠨ埛"),[],[]
def l111l1ll11l1_l1_(url):
	# https://www.l111l111lll1_l1_.com/012ocyw9li6g.html
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ埜") : l11ll1_l1_ (u"ࠩࠪ埝") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ埞"),headers,l11ll1_l1_ (u"ࠫࠬ域"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡌࡍ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ埠"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧ࠮࠮ࠫࡁࠬࠦࠬ埡"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	if items:
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࠫ埢"))
		l1llll_l1_.append(items[0][1])
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭埣"))
		l1llll_l1_.append(items[0][0])
		return l11ll1_l1_ (u"ࠩࠪ埤"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧ埥"),[],[]
def l11l1l1lll1_l1_(url):
	# l111ll1l1ll1_l1_ l11l1111l111_l1_			url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡛࠺࡛࠹࠷ࡖࡎࡺࡼࡕࡊ࠭埦")
	# l1lllllllll11_l1_ .l11l1l11l111_l1_ l11l1111l111_l1_		url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡺࡲ࡙ࡎࡂࡻࡨࡽࡋࡏࠧ埧")
	# l111ll1l11l1_l1_ l11l1l1ll1_l1_ .l1llll111_l1_ l11l1111l111_l1_		url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡋ࡫࠸࠭ࡏࡕࡷࡗࡸࡔࡷࠨ埨")
	# l111l1lll111_l1_ l11l1111l111_l1_			url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡪࡥࡓ࠺ࡘࡹࡎࡒ࠷ࡐࡊࠩ埩")
	# l111l11ll1_l1_ files have l111l1l1ll1l_l1_ l1l11ll1111l_l1_		url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠷ࡷࡅࡔࡘ࡚ࡨ࡙ࡹࡠࡓࠪ埪")
	# url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ埫")
	# url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽ࠷ࡻ࠮ࡣࡧ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ埬")
	# url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ埭")
	# url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ埮")
	# url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡴࡋࡋ࡬࡬࡫ࡢࡎ࠶࡟࡫ࠧࡣࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡂࡍ࡯࡭ࡦࡨࡲࡑ࡯࡮ࡦࡨࡲࡶ࡙࡜ࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡤࡲࡩࡊࡩࡴࡶࡵ࡭ࡧࡻࡴࡪࡱࡱࡃࡸࡿ࡮ࡥ࡫ࡦࡥࡹ࡯࡯࡯࠿࠵࠻࠼࠻࠷࠶ࠩ埯")
	# l1ll1ll1l_l1_ l11111l1lll1_l1_ details   https://l1111l1l1111_l1_.me/l1llllll1l1l1_l1_/l1lllll1ll1ll_l1_-l1llllll1l11l_l1_-l11111l1l1ll_l1_
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ埰"))[-1]
	id = id.split(l11ll1_l1_ (u"ࠨࠨࠪ埱"))[0]
	id = id.replace(l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ埲"),l11ll1_l1_ (u"ࠪࠫ埳"))
	#id = l11ll1_l1_ (u"ࠫࡪࡥࡓ࠺ࡘࡹࡎࡒ࠷ࡐࡊࠩ埴")
	#url = l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯ࡱ࡮ࡤࡽ࠴ࡅࡶࡪࡦࡨࡳࡤ࡯ࡤ࠾ࠩ埵")+id
	#return l11ll1_l1_ (u"࠭ࠧ埶"),[l11ll1_l1_ (u"ࠧࠨ執")],[url]
	l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ埸")][0]+l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ培")+id
	l1lllll1l1l1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭基")+id
	l111l11l1lll_l1_,l1lllllll111l_l1_,l11l1l11lll1_l1_,l111111111l1_l1_ = l11ll1_l1_ (u"ࠫࠬ埻"),l11ll1_l1_ (u"ࠬ࠭埼"),l11ll1_l1_ (u"࠭ࠧ埽"),l11ll1_l1_ (u"ࠧࠨ埾")
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡢࡵ࠱࠲࠵࠺ࠬ࠲ࠧࠧࠨࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࡞ࠪ࠰ࠬ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠬ࠳࠰࠿ࠪࡦࡨࡪࡦࡻ࡬ࡵࡃࡸࡨ࡮ࡵࡔࡳࡣࡦ࡯ࡎࡴࡤࡦࡺࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠪࠬ࠯ࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡽࠥࡰࡦࡴࡧࡶࡣࡪࡩࡈࡵࡤࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩࡠ࠰ࡠ࠭ࠧ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯ࡥࡳ࡭ࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮ࡤࡲ࡬࠯ࠊࠊࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆอีั๋ษࠡษ็้๋อำษห࠽ࠫ࠱ࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࠫࠍࠍࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡡ࠰࠭࠯࠴ࡡ࠿ࠐࠉࠊࠋࠌࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎ࡞࠴ࡢ࠱ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠨࡷࡽࡵ࡫࠽ࡵࡴࡤࡧࡰࠬࡴ࡭ࡣࡱ࡫ࡂ࠭ࠫ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡵ࡬࡫ࡳࡧࡴࡶࡴࡨ࠳ࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠽ࠤࡩࡧࡳࡩࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࡩࡱࡹࡥ࠻ࠢࡧࡥࡸ࡮ࡕࡓࡎࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡶ࠳ࠬ࠲ࠧ࠰ࡵ࡬࡫ࡳࡧࡴࡶࡴࡨ࠳ࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡬ࡱࡹࡕࡓࡎࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠥ࡫ࡸࡲࡲ࠲ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮࡫ࡰࡸ࡛ࡒࡍ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌࠧ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡜࠲ࡓࡅࡅࡋࡄ࠾࡚ࡘࡉ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࡗ࡝ࡕࡋ࠽ࡔࡗࡅࡘࡎ࡚ࡌࡆࡕ࠯ࡋࡗࡕࡕࡑ࠯ࡌࡈࡂࠨࡶࡵࡶࠪ࠰࡭ࡺ࡭࡭࠴࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠦࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡩࡵࡧࡰࡷࡠ࠶࡝ࠤ࠭ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠫࡺࡹࡱࡧࡀࡸࡷࡧࡣ࡬ࠨࡷࡰࡦࡴࡧ࠾ࠩࠍࠍࡧࡲ࡯ࡤ࡭ࡶ࠰ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠰࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࢁࡽࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡶࡴ࡯ࡣࡪࡴࡣࡰࡦࡨࡨࡤ࡬࡭ࡵࡡࡶࡸࡷ࡫ࡡ࡮ࡡࡰࡥࡵࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡣࡧࡥࡵࡺࡩࡷࡧࡢࡪࡲࡺࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡯ࡦࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩࡱࡹࡥ࡬ࡪࡵࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡧ࡮ࡥࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠡ࠾࡝ࠪࠫࡢࡀࠊࠊࠋࠌࡪࡲࡺ࡟࡭࡫ࡶࡸࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡫ࡳࡴࡠ࡫ࡷࡥ࡬ࡹࠠ࠾ࠢࡩࡱࡹࡥ࡬ࡪࡵࡷ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠱࠭ࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢࡩࡱࡹࡥࡩࡵࡣࡪࡷ࠿ࠐࠉࠊࠋࠌ࡭ࡹࡧࡧ࠭ࡵ࡬ࡾࡪࠦ࠽ࠡ࡫ࡷࡩࡲ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫࠍࠍࠎࠏࠉࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࡛ࡪࡶࡤ࡫ࡢࠦ࠽ࠡࡵ࡬ࡾࡪࠐࠉࡧࡱࡵࠤࡧࡲ࡯ࡤ࡭ࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡥࡰࡴࡩ࡫࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏ࡬ࡪࡰࡨࡷࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠬࠨࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳ࡫ࠠࡪࡰࠣࡰ࡮ࡴࡥࡴ࠼ࠍࠍࠎࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪࠪࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ࠲࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊࠋࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮࡬ࡪࡰࡨ࠰ࡱ࡫ࡶࡦ࡮ࡀࡼࡧࡳࡣ࠯ࡎࡒࡋࡓࡕࡔࡊࡅࡈ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡪࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪ࡯࡭ࡳ࡫ࠩࠋࠋࠌࠍࡩ࡯ࡣࡵࠢࡀࠤࢀࢃࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡱ࡯࡮ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩࠩࠪࠬ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡱࡥࡺ࠮ࡹࡥࡱࡻࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠿ࠪ࠰࠶࠯ࠊࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝࡮ࡩࡾࡣࠠ࠾ࠢࡹࡥࡱࡻࡥࠋࠋࠌࠍ࡮࡬ࠠࠨࡵ࡬ࡾࡪ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬࠤࡦࡴࡤࠡࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠍࠍࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡼࡨࠫࡢࠦ࠽ࠡࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࡜ࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣ࡝ࠋࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵࠫࠍࠍࡧࡲ࡯ࡤ࡭ࡶ࠰ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵ࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧ࡬࡯ࡳ࡯ࡤࡸࡸࠨ࠺࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸࠨ࠺࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡬࡯ࡳࠢࡥࡰࡴࡩ࡫ࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠩࠪࠬ࠲ࠧࠧࠩࠬࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠿ࠥࠫ࠱࠭࠽ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠨࠢࠨ࠮ࠪࠦࠬ࠯ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠿ࡺࡲࡶࡧࠪ࠰ࠬࡀࡔࡳࡷࡨࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠼ࡩࡥࡱࡹࡥࠨ࠮ࠪ࠾ࡋࡧ࡬ࡴࡧࠪ࠭ࠏࠏࠉࡪࡨࠣࠫࡠ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡀࠠࡣ࡮ࡲࡧࡰࠦ࠽ࠡࠩ࡞ࠫ࠰ࡨ࡬ࡰࡥ࡮࠯ࠬࡣࠧࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡊ࡜ࡁࡍࠪࠪࡰ࡮ࡹࡴࠨ࠮ࡥࡰࡴࡩ࡫ࠪࠌࠌࠍ࡫ࡵࡲࠡࡦ࡬ࡧࡹࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫࠻ࠌࠌࠍࠎࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞ࠫࠍࠍࠎࠏࡤࡪࡥࡷ࡟ࠬࡺࡹࡱࡧࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡃࠧ࠭ࠩࡀࠦࠬ࠯ࠫࠨࠤࠪࠎࠎࠏࠉࡪࡨࠣࠫ࡫ࡶࡳࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡩࡴࡸ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡦࡱࡵࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩࡺ࡭ࡩࡺࡨࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡶ࡭ࡿ࡫ࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡸ࡫ࡧࡸ࡭࠭࡝ࠪ࠭ࠪࡼࠬ࠱ࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩ࡫ࡩ࡮࡭ࡨࡵࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡶࡸࡦࡸࡴࠨ࡟࠮ࠫ࠲࠭ࠫࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࡠ࡟ࠬ࡫࡮ࡥࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲࡩ࡫ࡸࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡸࡺࡡࡳࡶࠪࡡ࠰࠭࠭ࠨ࠭ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡧࡱࡨࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬࠤࡦࡴࡤࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࡁ࠵࠶࠷࠲࠳࠴࠶࠷࠸ࡀࠠࡥࡧ࡯ࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠍࠍࠎࠏࠉࡤ࡫ࡳ࡬ࡪࡸࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠬࠧࠪࠌࠌࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤࡨ࡯ࡰࡩࡧࡵ࠾ࠏࠏࠉࠊࠋࠌ࡯ࡪࡿࠬࡷࡣ࡯ࡹࡪࠦ࠽ࠡ࡫ࡷࡩࡲ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠽ࠨ࠮࠴࠭ࠏࠏࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜࡭ࡨࡽࡢࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡹࡥࡱࡻࡥࠪࠌࠌࠍࠎࠩࡩࡧࠢࠪࡹࡷࡲࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡷࡵࡰࠬࡣࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࡜ࠩࡸࡶࡱ࠭࡝ࠪࠌࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶࠬࠎࠎࡻࡲ࡭ࡡ࡯࡭ࡸࡺࠬࡴࡶࡵࡩࡦࡳࡳ࠱࠮ࡶࡸࡷ࡫ࡡ࡮ࡵ࠴࠰ࡸࡺࡲࡦࡣࡰࡷ࠷ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳ࠣࡥࡳࡪࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠺ࠋࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸ࠶ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠼ࠍࠍࠎࠏࡵࡳ࡮࠴ࠤࡂࠦࡤࡪࡥࡷ࠵ࡠ࠭ࡵࡳ࡮ࠪࡡࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠤࡷࡵࡰ࠶ࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࠲࡝ࠪࡹࡷࡲࠧ࡞ࠫࠬ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴ࠳ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶࠿ࠐࠉࠊࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡨ࡮ࡩࡴ࠳࡝ࠪࡹࡷࡲࠧ࡞࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠎࠩࡵࡳ࡮࠵ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡦ࡬ࡧࡹ࠸࡛ࠨࡷࡵࡰࠬࡣࠩࠪ࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠎ࡯ࡦࠡࡷࡵࡰ࠶ࡃ࠽ࡶࡴ࡯࠶ࠥࡧ࡮ࡥࠢࡸࡶࡱ࠷ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠼ࠍࠍࠎࠏࠉࠊࡷࡵࡰࡤࡲࡩࡴࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲ࠱ࠪࠌࠌࠍࠎࠏࠉࡥ࡫ࡦࡸ࠶࠴ࡵࡱࡦࡤࡸࡪ࠮ࡤࡪࡥࡷ࠶࠮ࠐࠉࠊࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷ࠵࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠵࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡳࡵࡴࡨࡥࡲࡹ࠰ࠡ࠿ࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠮ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴ࠍࠍࠧࠨࠢ埿")
	# l11111111lll_l1_ json data
	# l1l111l1l_l1_ url l11l1111l111_l1_:    https://www.l1ll1ll1l_l1_.com/l1l111l1l_l1_/l111lll11l1l_l1_
	# list of l11l1111l1l1_l1_ & l1l11ll11lll_l1_
	# https://github.com/l11111l1l1l1_l1_-l1111ll1l1l1_l1_/l11111l1l1l1_l1_-l1111ll1l1l1_l1_/blob/master/l111lllllll1_l1_/l111l11l1111_l1_/l1ll1ll1l_l1_.py
	# all the below l1111l1111ll_l1_ were l111l1ll111l_l1_ using:	https://www.l1ll1ll1l_l1_.com/l11l11l11lll_l1_/l1l1llll11l1_l1_/l11llll1ll1_l1_?l1lllll1ll1l1_l1_=l1lllllll1l1l_l1_	&	l111llll1l1l_l1_ = l111lll11l1l_l1_
	# 3 l1ll1l111l11_l1_:	13KB:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭堀"): l11ll1_l1_ (u"ࠪࡍࡔ࡙࡟ࡄࡔࡈࡅ࡙ࡕࡒࠨ堁"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ堂"): l11ll1_l1_ (u"ࠬ࠸࠲࠯࠵࠶࠲࠶࠶࠱ࠨ堃")
	# 7 l1ll1l111l11_l1_		44KB:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ堄"): l11ll1_l1_ (u"ࠧࡊࡑࡖࡣࡒࡋࡓࡔࡃࡊࡉࡘࡥࡅ࡙ࡖࡈࡒࡘࡏࡏࡏࠩ堅"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ堆"): l11ll1_l1_ (u"ࠩ࠴࠻࠳࠹࠳࠯࠴ࠪ堇")
	# 7 l1ll1l111l11_l1_		58KB:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ堈"): l11ll1_l1_ (u"ࠫࡎࡕࡓࠨ堉"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ堊"): l11ll1_l1_ (u"࠭࠱࠸࠰࠶࠷࠳࠸ࠧ堋")
	# 9 l1ll1l111l11_l1_		24KB:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ堌"): l11ll1_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡆࡖࡊࡇࡔࡐࡔࠪ堍"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ堎"): l11ll1_l1_ (u"ࠪ࠶࠷࠴࠳࠱࠰࠴࠴࠵࠭堏")
	# no json file:		21 l1ll1l111l11_l1_	95KB:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ堐"): l11ll1_l1_ (u"ࠬ࡝ࡅࡃࡡࡆࡖࡊࡇࡔࡐࡔࠪ堑"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭堒"): l11ll1_l1_ (u"ࠧ࠲࠰࠵࠴࠷࠸࠰࠸࠴࠹࠲࠵࠶࠮࠱࠲ࠪ堓")
	# no json file:		21 l1ll1l111l11_l1_	121KB:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ堔"): l11ll1_l1_ (u"࡚ࠩࡉࡇ࠭堕"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ堖"): l11ll1_l1_ (u"ࠫ࠷࠴࠲࠱࠴࠵࠴࠽࠶࠱࠯࠲࠳࠲࠵࠶ࠧ堗")
	# no json file: 	26 l1ll1l111l11_l1_	115KB:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ堘"): l11ll1_l1_ (u"࠭ࡍࡘࡇࡅࠫ堙"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ堚"): l11ll1_l1_ (u"ࠨ࠴࠱࠶࠵࠸࠲࠱࠺࠳࠵࠳࠶࠰࠯࠲࠳ࠫ堛")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭堜"): l11ll1_l1_ (u"ࠪࡅࡓࡊࡒࡐࡋࡇࠫ堝"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ堞"): l11ll1_l1_ (u"ࠬ࠷࠷࠯࠵࠴࠲࠸࠻ࠧ堟")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ堠"): l11ll1_l1_ (u"ࠧࡘࡇࡅࡣࡗࡋࡍࡊ࡚ࠪ堡"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ堢"): l11ll1_l1_ (u"ࠩ࠴࠲࠷࠶࠲࠳࠲࠺࠶࠼࠴࠰࠲࠰࠳࠴ࠬ堣")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ堤"): l11ll1_l1_ (u"ࠫ࡜ࡋࡂࡠࡇࡐࡆࡊࡊࡄࡆࡆࡢࡔࡑࡇ࡙ࡆࡔࠪ堥"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ堦"): l11ll1_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠴࠳࠱࠴࠵࠴࠰࠱ࠩ堧")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ堨"): l11ll1_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ堩"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ堪"): l11ll1_l1_ (u"ࠪ࠵࠼࠴࠳࠲࠰࠶࠹ࠬ堫")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ堬"): l11ll1_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡍࡖࡕࡌࡇࠬ堭"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭堮"): l11ll1_l1_ (u"ࠧ࠶࠰࠴࠺࠳࠻࠱ࠨ堯")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ堰"): l11ll1_l1_ (u"ࠩࡗ࡚ࡍ࡚ࡍࡍ࠷ࡢࡗࡎࡓࡐࡍ࡛ࡢࡉࡒࡈࡅࡅࡆࡈࡈࡤࡖࡌࡂ࡛ࡈࡖࠬ報"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ堲"): l11ll1_l1_ (u"ࠫ࠷࠴࠰ࠨ堳")
	# l11l1lllll1l_l1_:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ場"): l11ll1_l1_ (u"࠭ࡉࡐࡕࡢࡑ࡚࡙ࡉࡄࠩ堵"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ堶"): l11ll1_l1_ (u"ࠨ࠷࠱࠶࠶࠭堷")
	# l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ堸")][0]+l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࡁࡳࡶࡪࡺࡴࡺࡒࡵ࡭ࡳࡺ࠽ࡵࡴࡸࡩࠬ堹")  # l1lllllll1l1l_l1_ l1lll111l1ll_l1_ l1lllllll1l11_l1_ and l11111ll1111_l1_ l1ll1ll11111_l1_ l1l1l1lll1_l1_ l111111ll11l_l1_ file size
	#l11ll11l1_l1_ = l11ll1_l1_ (u"ࠫࢀ࠭堺")l1lllll1ll11l_l1_ (u"ࠬࡀࡩࡥ࠮ࠪ堻")l111l1111ll1_l1_ (u"࠭࠺ࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࡿࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠦࡆࡔࡄࡓࡑࡌࡈࠧ࠲ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠤ࠴࠻࠳࠹࠱࠯࠵࠸ࠦࢂࢃࡽࠨ堼")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ堽"),l111lll_l1_,l11ll11l1_l1_,l11ll1_l1_ (u"ࠨࠩ堾"),l11ll1_l1_ (u"ࠩࠪ堿"),l11ll1_l1_ (u"ࠪࠫ塀"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ塁"))
	#html = response.content
	for l11ll1111l_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠬอไๆฯส์้ฯࠠาไ่࠾ࠥࠦࠧ塂")+str(l11ll1111l_l1_+1),l11ll1_l1_ (u"࠭ࠧ塃"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ塄"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ塅"),l11ll1_l1_ (u"ࠩࠪ塆"),l11ll1_l1_ (u"ࠪࠫ塇"),l11ll1_l1_ (u"ࠫࠬ塈"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭塉"))
		html = response.content
		if l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ塊") in html: break
		time.sleep(2)
	#WRITE_THIS(l11ll1_l1_ (u"ࠧࠨ塋"),html)
	l11lll11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ塌"),html,re.DOTALL)
	if l11lll11ll_l1_: l11lll11ll_l1_ = l11lll11ll_l1_[0]
	else: l11lll11ll_l1_ = html
	l11lll11ll_l1_ = l11lll11ll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ塍"),l11ll1_l1_ (u"ࠪࠪࠬ塎"))
	l11111l11lll_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ塏"),l11lll11ll_l1_)
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭塐"),str(l11111l11lll_l1_))
	# l11111111lll_l1_ l111lll1l11l_l1_ & l11l1l1111ll_l1_
	# l1ll1ll1l_l1_ l111ll1l1ll1_l1_ l1lllll_l1_ l11lll1ll_l1_ l11ll1_l1_ (u"࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠨ塑") to l111l1l11l_l1_ on l11l1lll111_l1_
	l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠧษั๋๊ࠥะัอ็ฬࠤ๏๎ส๋๊หࠫ塒")],[l11ll1_l1_ (u"ࠨࠩ塓")]
	try:
		l111lll1l11l_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠩࡦࡥࡵࡺࡩࡰࡰࡶࠫ塔")][l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ塕")][l11ll1_l1_ (u"ࠫࡨࡧࡰࡵ࡫ࡲࡲ࡙ࡸࡡࡤ࡭ࡶࠫ塖")]
		for l111l1lll1l1_l1_ in l111lll1l11l_l1_:
			l1lllll_l1_ = l111l1lll1l1_l1_[l11ll1_l1_ (u"ࠬࡨࡡࡴࡧࡘࡶࡱ࠭塗")]
			try: title = l111l1lll1l1_l1_[l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ塘")][l11ll1_l1_ (u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫ塙")]
			except: title = l111l1lll1l1_l1_[l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭塚")][l11ll1_l1_ (u"ࠩࡵࡹࡳࡹࠧ塛")][0][l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࠨ塜")]
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(title)
	except: pass
	if len(l1lll11l_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭塝"), l1lll11l_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠬࡋࡘࡊࡖࠪ塞"),[],[]
		elif l1l_l1_!=0:
			l1lllll_l1_ = l1llll_l1_[l1l_l1_]+l11ll1_l1_ (u"࠭ࠦࠨ塟")
			l1111l1ll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠧࠪࡩࡱࡹࡃ࠮ࠫࡁࠬࠪࠬ塠"),l1lllll_l1_)
			if l1111l1ll11l_l1_: l1lllll_l1_ = l1lllll_l1_.replace(l1111l1ll11l_l1_[0],l11ll1_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ塡"))
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ塢")
			l111l11l1lll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ塣"))
	formats,l11l1l11111l_l1_,l11l11111111_l1_,l11l1111111l_l1_,l111llllllll_l1_ = [],[],[],[],[]
	# l11111111lll_l1_ l111l11llll1_l1_ l1ll1l111l11_l1_
	try: l1lllllll111l_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ塤")][l11ll1_l1_ (u"ࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ塥")]
	except: pass
	# l11111111lll_l1_ l111ll1l11l1_l1_ stream
	try: l11l1l11lll1_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭塦")][l11ll1_l1_ (u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ塧")]
	except: pass
	# l11111111lll_l1_ l1ll1l1l11_l1_ l1111l1l_l1_ l1ll1l111l11_l1_
	try: formats = l11111l11lll_l1_[l11ll1_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ塨")][l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ塩")]
	except: pass
	# l11111111lll_l1_ l1ll1l1l11_l1_ l11l1l11l111_l1_ l1ll1l111l11_l1_
	try: l11l1l11111l_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ塪")][l11ll1_l1_ (u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭填")]
	except: pass
	l111ll11lll1_l1_ = formats+l11l1l11111l_l1_
	for dict in l111ll11lll1_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭塬"),str(dict))
		if l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ塭") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ塮")] = str(dict[l11ll1_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭塯")])
		if l11ll1_l1_ (u"ࠩࡩࡴࡸ࠭塰") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪࡪࡵࡹࠧ塱")] = str(dict[l11ll1_l1_ (u"ࠫ࡫ࡶࡳࠨ塲")])
		if l11ll1_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ塳") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ塴")] = dict[l11ll1_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ塵")]		#.replace(l11ll1_l1_ (u"ࠨ࠿ࠪ塶"),l11ll1_l1_ (u"ࠩࡀࠫ塷"))+l11ll1_l1_ (u"ࠪࠦࠬ塸")
		if l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭塹") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ塺")] = str(dict[l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ塻")])
		if l11ll1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ塼") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ塽")] = str(dict[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ塾")])
		if l11ll1_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ塿") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ墀")] = str(dict[l11ll1_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ墁")])+l11ll1_l1_ (u"࠭ࡸࠨ墂")+str(dict[l11ll1_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ境")])
		if l11ll1_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ墄") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ墅")] = dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭墆")][l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ墇")]+l11ll1_l1_ (u"ࠬ࠳ࠧ墈")+dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ墉")][l11ll1_l1_ (u"ࠧࡦࡰࡧࠫ墊")]
		if l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ墋") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ墌")] = dict[l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ墍")][l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ墎")]+l11ll1_l1_ (u"ࠬ࠳ࠧ墏")+dict[l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ墐")][l11ll1_l1_ (u"ࠧࡦࡰࡧࠫ墑")]
		if l11ll1_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ墒") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ墓")] = dict[l11ll1_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ墔")]
		if l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ墕") in list(dict.keys()) and int(dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭墖")])>111222333: del dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ増")]
		if l11ll1_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ墘") in list(dict.keys()):
			cipher = dict[l11ll1_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ墙")].split(l11ll1_l1_ (u"ࠩࠩࠫ墚"))
			for item in cipher:
				key,value = item.split(l11ll1_l1_ (u"ࠪࡁࠬ墛"),1)
				dict[key] = l1111_l1_(value)
		if l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ墜") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ墝")] = l1111_l1_(dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ增")])
		#if l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹ࠽ࠨ墟") in dict[l11ll1_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ墠")]: dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ墡")] = dict[l11ll1_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ墢")].split(l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࡁࡡࠨࠧ墣"))[1].strip(l11ll1_l1_ (u"ࠬࡢࠢࠨ墤"))
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ墥"),dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ墦")]+l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡࠩ墧")+dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ墨")])
		l11l11111111_l1_.append(dict)
	l11l1ll11_l1_ = l11ll1_l1_ (u"ࠪࠫ墩")
	if l11ll1_l1_ (u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫ墪") in l11lll11ll_l1_:
		#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠴ࡿࡴࡴ࠱࡭ࡷࡧ࡯࡮࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࠰࠭ࡃ࠮ࠨࠧ墫"),html,re.DOTALL)
		# l11l1111l111_l1_:	/s/l11llll1ll1_l1_/6dde7fb4/l111111l1lll_l1_.l111l1111111_l1_/l111l1l111l1_l1_/base.l111111l11ll_l1_
		#l11l111ll1l1_l1_ = [l11ll1_l1_ (u"࠭࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱ࡧ࠼࠼ࡪ࠵࠹࠳ࡩ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࡚࡙࠯ࡣࡣࡶࡩ࠳ࡰࡳࠨ墬")]
		l11l111ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭墭"),html,re.DOTALL)
		if l11l111ll1l1_l1_:
			l11l111ll1l1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ墮")][0]+l11l111ll1l1_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭墯"),l11l111ll1l1_l1_,l11ll1_l1_ (u"ࠪࠫ墰"),l11ll1_l1_ (u"ࠫࠬ墱"),l11ll1_l1_ (u"ࠬ࠭墲"),l11ll1_l1_ (u"࠭ࠧ墳"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨ墴"))
			l11l1ll11_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1111111l1ll_l1_ = cipher._load_javascript(l11l1ll11_l1_)
			l1lllllll1111_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ墵"),str(l1111111l1ll_l1_))
			l11111llll1l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1lllllll1111_l1_)
	for dict in l11l11111111_l1_:
		url = dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭墶")]
		if l11ll1_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧ墷") in url or url.count(l11ll1_l1_ (u"ࠫࡸ࡯ࡧ࠾ࠩ墸"))>1:
			l11l1111111l_l1_.append(dict)
		elif l11l1ll11_l1_ and l11ll1_l1_ (u"ࠬࡹࠧ墹") in list(dict.keys()) and l11ll1_l1_ (u"࠭ࡳࡱࠩ墺") in list(dict.keys()):
			l111l1lll111_l1_ = l11111llll1l_l1_.execute(dict[l11ll1_l1_ (u"ࠧࡴࠩ墻")])
			if l111l1lll111_l1_!=dict[l11ll1_l1_ (u"ࠨࡵࠪ墼")]:
				dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭墽")] = url+l11ll1_l1_ (u"ࠪࠪࠬ墾")+dict[l11ll1_l1_ (u"ࠫࡸࡶࠧ墿")]+l11ll1_l1_ (u"ࠬࡃࠧ壀")+l111l1lll111_l1_
				l11l1111111l_l1_.append(dict)
	for dict in l11l1111111l_l1_:
		l11lll1_l1_,l11111l1l111_l1_,l1111l1lll11_l1_,l11ll1l11_l1_,codecs,l11l11l1l11_l1_ = l11ll1_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ壁"),l11ll1_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ壂"),l11ll1_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ壃"),l11ll1_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ壄"),l11ll1_l1_ (u"ࠪࠫ壅"),l11ll1_l1_ (u"ࠫ࠵࠭壆")
		try:
			l11l111111l1_l1_ = dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧࠪ壇")]
			l11l111111l1_l1_ = l11l111111l1_l1_.replace(l11ll1_l1_ (u"࠭ࠫࠨ壈"),l11ll1_l1_ (u"ࠧࠨ壉"))
			items = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ壊"),l11l111111l1_l1_,re.DOTALL)
			l11ll1l11_l1_,l11lll1_l1_,codecs = items[0]
			l11l11lll111_l1_ = codecs.split(l11ll1_l1_ (u"ࠩ࠯ࠫ壋"))
			l11111l1l111_l1_ = l11ll1_l1_ (u"ࠪࠫ壌")
			for item in l11l11lll111_l1_: l11111l1l111_l1_ += item.split(l11ll1_l1_ (u"ࠫ࠳࠭壍"))[0]+l11ll1_l1_ (u"ࠬ࠲ࠧ壎")
			l11111l1l111_l1_ = l11111l1l111_l1_.strip(l11ll1_l1_ (u"࠭ࠬࠨ壏"))
			if l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ壐") in list(dict.keys()): l11l11l1l11_l1_ = str(float(dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ壑")]*10)//1024/10)+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ壒")
			else: l11l11l1l11_l1_ = l11ll1_l1_ (u"ࠪࠫ壓")
			if l11ll1l11_l1_==l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ壔"): continue
			elif l11ll1_l1_ (u"ࠬ࠲ࠧ壕") in l11l111111l1_l1_:
				l11ll1l11_l1_ = l11ll1_l1_ (u"࠭ࡁࠬࡘࠪ壖")
				l1111l1lll11_l1_ = l11lll1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ壗")+l11l11l1l11_l1_+dict[l11ll1_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭壘")].split(l11ll1_l1_ (u"ࠩࡻࠫ壙"))[1]
			elif l11ll1l11_l1_==l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ壚"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ壛")
				l1111l1lll11_l1_ = l11l11l1l11_l1_+dict[l11ll1_l1_ (u"ࠬࡹࡩࡻࡧࠪ壜")].split(l11ll1_l1_ (u"࠭ࡸࠨ壝"))[1]+l11ll1_l1_ (u"ࠧࠡࠢࠪ壞")+dict[l11ll1_l1_ (u"ࠨࡨࡳࡷࠬ壟")]+l11ll1_l1_ (u"ࠩࡩࡴࡸ࠭壠")+l11ll1_l1_ (u"ࠪࠤࠥ࠭壡")+l11lll1_l1_
			elif l11ll1l11_l1_==l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ壢"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ壣")
				l1111l1lll11_l1_ = l11l11l1l11_l1_+str(int(dict[l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ壤")])/1000)+l11ll1_l1_ (u"ࠧ࡬ࡪࡽࠤࠥ࠭壥")+dict[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ壦")]+l11ll1_l1_ (u"ࠩࡦ࡬ࠬ壧")+l11ll1_l1_ (u"ࠪࠤࠥ࠭壨")+l11lll1_l1_
		except:
			l1llllll11ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1llllll11ll_l1_)
		if l11ll1_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ壩") in dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ壪")]: l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ士")].split(l11ll1_l1_ (u"ࠧࡥࡷࡵࡁࠬ壬"),1)[1].split(l11ll1_l1_ (u"ࠨࠨࠪ壭"),1)[0]))
		elif l11ll1_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ壮") in list(dict.keys()): l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭壯")])/1000)
		else: l1l11lll1_l1_ = l11ll1_l1_ (u"ࠫ࠵࠭声")
		if l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭壱") not in list(dict.keys()): l11l11l1l11_l1_ = dict[l11ll1_l1_ (u"࠭ࡳࡪࡼࡨࠫ売")].split(l11ll1_l1_ (u"ࠧࡹࠩ壳"))[1]
		else: l11l11l1l11_l1_ = dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ壴")]
		if l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ壵") not in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ壶")] = l11ll1_l1_ (u"ࠫ࠵࠳࠰ࠨ壷")
		dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ壸")] = l11ll1l11_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ壹")+l1111l1lll11_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠫࠫ壺")+l11111l1l111_l1_+l11ll1_l1_ (u"ࠨ࠮ࠪ壻")+dict[l11ll1_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ壼")]+l11ll1_l1_ (u"ࠪ࠭ࠬ壽")
		dict[l11ll1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ壾")] = l1111l1lll11_l1_.split(l11ll1_l1_ (u"ࠬࠦࠠࠨ壿"))[0].split(l11ll1_l1_ (u"࠭࡫ࡣࡲࡶࠫ夀"))[0]
		dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭夁")] = l11ll1l11_l1_
		dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ夂")] = l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ夃")] = codecs
		dict[l11ll1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ处")] = l1l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ夅")] = l11l11l1l11_l1_
		l111llllllll_l1_.append(dict)
	l111ll11l1ll_l1_,l11l111ll1ll_l1_,l11l1l11l11l_l1_,l111l111l111_l1_,l111llll1111_l1_ = [],[],[],[],[]
	l1111lll1l1l_l1_,l11l11111ll1_l1_,l1111l1l11l1_l1_,l11l11ll1ll1_l1_,l11l1l111l11_l1_ = [],[],[],[],[]
	if l1lllllll111l_l1_:
		dict = {}
		dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ夆")] = l11ll1_l1_ (u"࠭ࡁࠬࡘࠪ备")
		dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ夈")] = l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ変")
		dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ夊")] = dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ夋")]+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ夌")+dict[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ复")]+l11ll1_l1_ (u"࠭ࠠࠡࠩ夎")+l11ll1_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ夏")
		dict[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ夐")] = l1lllllll111l_l1_
		dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ夑")] = l11ll1_l1_ (u"ࠪ࠴ࠬ夒") # for l11l1l11ll_l1_ l1lllllll111l_l1_ any l1l111lll_l1_ will l111llll1l11_l1_ l11111llllll_l1_ sort l1l1l1llll1_l1_
		dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ夓")] = l11ll1_l1_ (u"ࠬ࠿࠸࠸࠸࠸࠸࠸࠸࠱࠱ࠩ夔") # 20
		l111llllllll_l1_.append(dict)
	if l11l1l11lll1_l1_:
		l111111llll1_l1_,l11l111l11ll_l1_ = l11ll11ll1_l1_(l11l1l11lll1_l1_)
		l11l11l1l111_l1_ = list(zip(l111111llll1_l1_,l11l111l11ll_l1_))
		for title,l1lllll_l1_ in l11l11l1l111_l1_:
			dict = {}
			dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ夕")] = l11ll1_l1_ (u"ࠧࡂ࡙࠭ࠫ外")
			dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ夗")] = l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ夘")
			dict[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ夙")] = l1lllll_l1_
			#if l11ll1_l1_ (u"ࠫࡇ࡝࠺ࠡࠩ多") in title: dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭夛")] = title.split(l11ll1_l1_ (u"࠭ࠠࠡࠩ夜"))[1].split(l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ夝"))[0]
			#if l11ll1_l1_ (u"ࠨࡔࡨࡷ࠿ࠦࠧ夞") in title: dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ够")] = title.split(l11ll1_l1_ (u"ࠪࡖࡪࡹ࠺ࠡࠩ夠"))[1]
			# title = l11ll1_l1_ (u"ࠦ࠹࠸࠶࠸࡭ࡥࡴࡸࠦࠠ࠸࠴࠳ࠤࠥ࠴࡭࠴ࡷ࠻ࠦ夡")
			if l11ll1_l1_ (u"ࠬࡱࡢࡱࡵࠪ夢") in title: dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ夣")] = title.split(l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ夤"))[0].rsplit(l11ll1_l1_ (u"ࠨࠢࠣࠫ夥"))[-1]
			else: dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ夦")] = l11ll1_l1_ (u"ࠪ࠵࠵࠭大")
			if title.count(l11ll1_l1_ (u"ࠫࠥࠦࠧ夨"))>1:
				l111llll_l1_ = title.rsplit(l11ll1_l1_ (u"ࠬࠦࠠࠨ天"))[-3]
				if l111llll_l1_.isdigit(): dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ太")] = l111llll_l1_
				else: dict[l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ夫")] = l11ll1_l1_ (u"ࠨ࠲࠳࠴࠵࠭夬")
			#dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ夭")] = title
			if title==l11ll1_l1_ (u"ࠪ࠱࠶࠭央"): dict[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ夯")] = dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ夰")]+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ失")+dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ夲")]+l11ll1_l1_ (u"ࠨࠢࠣࠫ夳")+l11ll1_l1_ (u"ࠩฯ์ิฯࠠัๅํอࠬ头")
			else: dict[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ夵")] = dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ夶")]+l11ll1_l1_ (u"ࠬࡀࠠࠡࠩ夷")+dict[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ夸")]+l11ll1_l1_ (u"ࠧࠡࠢࠪ夹")+dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ夺")]+l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ夻")+dict[l11ll1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ夼")]
			l111llllllll_l1_.append(dict)
	l111llllllll_l1_ = sorted(l111llllllll_l1_,reverse=True,key=lambda key: float(key[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ夽")]))
	if not l111llllllll_l1_:
		l1ll11l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ夾"),html,re.DOTALL)
		l1ll11l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺࡝ࡽࠥࡶࡺࡴࡳࠣ࠼࡟࡟ࡡࢁࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ夿"),html,re.DOTALL)
		l111ll111ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奀"),html,re.DOTALL)
		l111ll111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ奁"),html,re.DOTALL)
		try: l111ll11l111_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭奂")][l11ll1_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ奃")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ奄")][l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ奅")][l11ll1_l1_ (u"࠭ࡲࡶࡰࡶࠫ奆")][0][l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ奇")]
		except: l111ll11l111_l1_ = l11ll1_l1_ (u"ࠨࠩ奈")
		try: l111ll11l11l_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭奉")][l11ll1_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ奊")][l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ奋")][l11ll1_l1_ (u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭奌")][0][l11ll1_l1_ (u"࠭ࡲࡶࡰࡶࠫ奍")][0][l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ奎")]
		except: l111ll11l11l_l1_ = l11ll1_l1_ (u"ࠨࠩ奏")
		try: l11111llll11_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭奐")][l11ll1_l1_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ契")]
		except: l11111llll11_l1_ = l11ll1_l1_ (u"ࠫࠬ奒")
		if l1ll11l1l11_l1_ or l1ll11l1l1l_l1_ or l111ll111ll1_l1_ or l111ll111lll_l1_ or l111ll11l111_l1_ or l111ll11l11l_l1_ or l11111llll11_l1_:
			if   l1ll11l1l11_l1_: message = l1ll11l1l11_l1_[0]
			elif l1ll11l1l1l_l1_: message = l1ll11l1l1l_l1_[0]
			elif l111ll111ll1_l1_: message = l111ll111ll1_l1_[0]
			elif l111ll111lll_l1_: message = l111ll111lll_l1_[0]
			elif l111ll11l111_l1_: message = l111ll11l111_l1_
			elif l111ll11l11l_l1_: message = l111ll11l11l_l1_
			elif l11111llll11_l1_: message = l11111llll11_l1_
			l1111l1l1l1l_l1_ = message.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ奓"),l11ll1_l1_ (u"࠭ࠧ奔")).strip(l11ll1_l1_ (u"ࠧࠡࠩ奕"))
			l111lll11l11_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋ีอࠠศๆไ๎ิ๐่ࠡใํ๋๋ࠥิไๆฬࠤํ่ฯࠡ์ๆ์ฺ๋๋ࠦำ้้ࠣอฦๆࠢ็ฬ฾฼ࠠศๆ่ืฯิฯๆ์้ࠤศ๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ奖")
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ套"),l11ll1_l1_ (u"ࠪࠫ奘"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾่ࠦศๆ่ฬึ๋ฬࠨ奙"),l111lll11l11_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ奚")+l1111l1l1l1l_l1_)
			return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩࡀࠠࠨ奛")+l1111l1l1l1l_l1_,[],[]
		else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧ奜"),[],[]
	l11111lllll1_l1_,l1llllll11111_l1_,l111l1ll1l11_l1_ = [],[],[]
	for dict in l111llllllll_l1_:
		if dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ奝")]==l11ll1_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ奞"):
			l111ll11l1ll_l1_.append(dict[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ奟")])
			l1111lll1l1l_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ奠")]==l11ll1_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ奡"):
			l11l111ll1ll_l1_.append(dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ奢")])
			l11l11111ll1_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ奣")]==l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ奤"):
			title = dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ奥")].replace(l11ll1_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ奦"),l11ll1_l1_ (u"ࠫࠬ奧"))
			if l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭奨") not in list(dict.keys()): l11l11l1l11_l1_ = l11ll1_l1_ (u"࠭࠰ࠨ奩")
			else: l11l11l1l11_l1_ = dict[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ奪")]
			l11111lllll1_l1_.append([dict,{},title,l11l11l1l11_l1_])
		else:
			title = dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ奫")].replace(l11ll1_l1_ (u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ奬"),l11ll1_l1_ (u"ࠪࠫ奭"))
			if l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ奮") not in list(dict.keys()): l11l11l1l11_l1_ = l11ll1_l1_ (u"ࠬ࠶ࠧ奯")
			else: l11l11l1l11_l1_ = dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ奰")]
			l11111lllll1_l1_.append([dict,{},title,l11l11l1l11_l1_])
			l11l1l11l11l_l1_.append(title)
			l1111l1l11l1_l1_.append(dict)
		l11l11l1l1ll_l1_ = True
		if l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ奱") in list(dict.keys()):
			if l11ll1_l1_ (u"ࠨࡣࡹ࠴ࠬ奲") in dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ女")]: l11l11l1l1ll_l1_ = False
			elif kodi_version<18:
				if l11ll1_l1_ (u"ࠪࡥࡻࡩࠧ奴") not in dict[l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ奵")] and l11ll1_l1_ (u"ࠬࡳࡰ࠵ࡣࠪ奶") not in dict[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭奷")]: l11l11l1l1ll_l1_ = False
		if dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭奸")]==l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ她") and dict[l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ奺")]!=l11ll1_l1_ (u"ࠪ࠴࠲࠶ࠧ奻") and l11l11l1l1ll_l1_==True:
			l111llll1111_l1_.append(dict[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ奼")])
			l11l1l111l11_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ好")]==l11ll1_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ奾") and dict[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ奿")]!=l11ll1_l1_ (u"ࠨ࠲࠰࠴ࠬ妀") and l11l11l1l1ll_l1_==True:
			l111l111l111_l1_.append(dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ妁")])
			l11l11ll1ll1_l1_.append(dict)
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ如"),l11ll1_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮࠯ࠥࠦࠠࠨ妃")+dict[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ妄")])
	for l11l11l111l1_l1_ in l11l11ll1ll1_l1_:
		l111l111l1ll_l1_ = l11l11l111l1_l1_[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ妅")]
		for l111ll11111l_l1_ in l11l1l111l11_l1_:
			l11111l1llll_l1_ = l111ll11111l_l1_[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ妆")]
			l11l11l1l11_l1_ = l11111l1llll_l1_+l111l111l1ll_l1_
			title = l111ll11111l_l1_[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ妇")].replace(l11ll1_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠣࠫ妈"),l11ll1_l1_ (u"ࠪࡱࡵࡪࠠࠡࠩ妉"))
			title = title.replace(l111ll11111l_l1_[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭妊")]+l11ll1_l1_ (u"ࠬࠦࠠࠨ妋"),l11ll1_l1_ (u"࠭ࠧ妌"))
			title = title.replace(str((float(l11111l1llll_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ妍"),str((float(l11l11l1l11_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭妎"))
			title = title+l11ll1_l1_ (u"ࠩࠫࠫ妏")+l11l11l111l1_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ妐")].split(l11ll1_l1_ (u"ࠫ࠭࠭妑"),1)[1]
			l11111lllll1_l1_.append([l111ll11111l_l1_,l11l11l111l1_l1_,title,l11l11l1l11_l1_])
	l11111lllll1_l1_ = sorted(l11111lllll1_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111ll11111l_l1_,l11l11l111l1_l1_,title,l11l11l1l11_l1_ in l11111lllll1_l1_:
		l111llllll11_l1_ = l111ll11111l_l1_[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ妒")]
		if l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ妓") in list(l11l11l111l1_l1_.keys()):
			l111llllll11_l1_ = l11ll1_l1_ (u"ࠧ࡮ࡲࡧࠫ妔")
			#l111llllll11_l1_ = l111llllll11_l1_+l11l11l111l1_l1_[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ妕")]
		if l111llllll11_l1_ not in l111l1ll1l11_l1_:
			l111l1ll1l11_l1_.append(l111llllll11_l1_)
			l1llllll11111_l1_.append([l111ll11111l_l1_,l11l11l111l1_l1_,title,l11l11l1l11_l1_])
			#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ妖"),str(l11l11l1l11_l1_)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ妗")+title)
	#l1llllll11111_l1_ = sorted(l1llllll11111_l1_, reverse=True, key=lambda key: int(key[3]))
	l11111lll1ll_l1_,l1111lllllll_l1_,shift = [],[],0
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡱࡺࡲࡪࡸࠢ࠻࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡀࠊࠊࠋࡶ࡬࡮࡬ࡴࠡ࠭ࡀࠤ࠶ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧࠬࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠴ࡢ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠲࡟ࠍࠍࠎࡹࡥ࡭ࡧࡦࡸࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡨ࡮࡯ࡪࡥࡨࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠤࠥࠦ妘")
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡲࡻࡳ࡫ࡲࡠࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬ࡠ࡬ࡶࡳࡳ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡴࡽ࡮ࡦࡴࡢࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡤࡹࡹ࡮࡯ࡳࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯ࡣ࡯ࡹ࡯࡯࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫࠺ࠋࠋࠌ࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡢ࡮࡯ࡳࡼࡘࡡࡵ࡫ࡱ࡫ࡸࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡ࡫ࡰࡥ࡬࡫ࡳࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࠎ࡯࡭ࡢࡩࡨࡷࡤࡻࡲ࡭ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡭ࡲࡧࡧࡦࡵࡢࡹࡷࡲ࠺ࠡ࡫ࡰࡥ࡬࡫ࠠ࠾ࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࡡ࠭࠲࡟ࠍࠍࠎࡵࡷ࡯ࡧࡵࠤࡂࠦ࡯ࡸࡰࡨࡶࡤࡴࡡ࡮ࡧ࡞࠴ࡢࠐࠉࠊࡵ࡫࡭࡫ࡺࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࠫࡰࡹࡱࡩࡷ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡝ࡅࡃࡕࡌࡘࡊ࡙࡛ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩࡠ࡟࠵ࡣࠫࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ࠰ࡵࡷ࡯ࡧࡵࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡠ࠶࡝ࠋࠋࠌࡷࡪࡲࡥࡤࡶࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡦ࡬ࡴ࡯ࡣࡦࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ妙")
	l11l11l1ll1l_l1_,l111llll1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ妚"),l11ll1_l1_ (u"ࠧࠨ妛")
	try: l11l11l1ll1l_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ妜")][l11ll1_l1_ (u"ࠩࡤࡹࡹ࡮࡯ࡳࠩ妝")]
	except: l11l11l1ll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ妞")
	try: l1111l1l1ll1_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ妟")][l11ll1_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨ妠")]
	except: l1111l1l1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ妡")
	if l11l11l1ll1l_l1_ and l1111l1l1ll1_l1_:
		shift += 1
		title = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ妢")+l11l11l1ll1l_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ妣")
		l1lllll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ妤")][0]+l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭妥")+l1111l1l1ll1_l1_
		l11111lll1ll_l1_.append(title)
		l1111lllllll_l1_.append(l1lllll_l1_)
		try: l111llll1ll1_l1_ = l11111l11lll_l1_[l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ妦")][l11ll1_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ妧")][l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ妨")][-1][l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ妩")]
		except: pass
	#if l1lllllll111l_l1_:
	#	shift += 1
	#	l11111lll1ll_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠥา่ะหࠣิ่๐ษࠨ妪")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠩࡧࡥࡸ࡮ࠧ妫"))
	for l111ll11111l_l1_,l11l11l111l1_l1_,title,l11l11l1l11_l1_ in l1llllll11111_l1_:
		l11111lll1ll_l1_.append(title) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ妬"))
	if l11l1l11l11l_l1_: l11111lll1ll_l1_.append(l11ll1_l1_ (u"ฺࠫ๎ัสู๋ࠢํะࠠๆฯาำฮ࠭妭")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ妮"))
	if l11111lllll1_l1_: l11111lll1ll_l1_.append(l11ll1_l1_ (u"࠭ี้ำฬࠤํ฻่หࠢส่๊ะ่โำࠪ妯")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠧࡢ࡮࡯ࠫ妰"))
	if l111llll1111_l1_: l11111lll1ll_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠥอฮหำࠣห้฻่าหࠣ์ฬ๊ี้ฬࠪ妱")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠩࡰࡴࡩ࠭妲"))
	if l111ll11l1ll_l1_: l11111lll1ll_l1_.append(l11ll1_l1_ (u"ูࠪํืษࠡสา์๋ࠦี้ฬࠪ妳")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ妴"))
	if l11l111ll1ll_l1_: l11111lll1ll_l1_.append(l11ll1_l1_ (u"ࠬ฻่หࠢหำํ์ࠠึ๊ิอࠬ妵")) ; l1111lllllll_l1_.append(l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ妶"))
	l11l1l11l1ll_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1lllll1l1l1l_l1_, l11111lll1ll_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ妷"),[],[]
		elif l1l_l1_==0 and l11l11l1ll1l_l1_:
			l1lllll_l1_ = l1111lllllll_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11ll1_l1_ (u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠷࠴࠲ࠨࡱࡥࡲ࡫࠽ࠨ妸")+QUOTE(l11l11l1ll1l_l1_)+l11ll1_l1_ (u"ࠩࠩࡹࡷࡲ࠽ࠨ妹")+l1lllll_l1_
			if l111llll1ll1_l1_: new_path = new_path+l11ll1_l1_ (u"ࠪࠪ࡮ࡳࡡࡨࡧࡀࠫ妺")+QUOTE(l111llll1ll1_l1_)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ妻")+new_path+l11ll1_l1_ (u"ࠧ࠯ࠢ妼"))
			return l11ll1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ妽"),[],[]
		choice = l1111lllllll_l1_[l1l_l1_]
		l111111l1ll1_l1_ = l11111lll1ll_l1_[l1l_l1_]
		if choice==l11ll1_l1_ (u"ࠧࡥࡣࡶ࡬ࠬ妾"):
			l111111111l1_l1_ = l1lllllll111l_l1_
			break
		elif choice in [l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ妿"),l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ姀"),l11ll1_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ姁")]:
			if choice==l11ll1_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ姂"): l1lll11l_l1_,l1111ll11l1l_l1_ = l11l1l11l11l_l1_,l1111l1l11l1_l1_
			elif choice==l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姃"): l1lll11l_l1_,l1111ll11l1l_l1_ = l111ll11l1ll_l1_,l1111lll1l1l_l1_
			elif choice==l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ姄"): l1lll11l_l1_,l1111ll11l1l_l1_ = l11l111ll1ll_l1_,l11l11111ll1_l1_
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭姅"), l1lll11l_l1_)
			if l1l_l1_!=-1:
				l111111111l1_l1_ = l1111ll11l1l_l1_[l1l_l1_][l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ姆")]
				l111111l1ll1_l1_ = l1lll11l_l1_[l1l_l1_]
				break
		elif choice==l11ll1_l1_ (u"ࠩࡰࡴࡩ࠭姇"):
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࡀࠧ姈"), l111llll1111_l1_)
			if l1l_l1_!=-1:
				l111111l1ll1_l1_ = l111llll1111_l1_[l1l_l1_]
				l111llll1lll_l1_ = l11l1l111l11_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࡀࠧ姉"), l111l111l111_l1_)
				if l1l_l1_!=-1:
					l111111l1ll1_l1_ += l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ姊")+l111l111l111_l1_[l1l_l1_]
					l111l1llllll_l1_ = l11l11ll1ll1_l1_[l1l_l1_]
					l11l1l11l1ll_l1_ = True
					break
		elif choice==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࠪ始"):
			l11l1111llll_l1_,l111l11l111l_l1_,l1llllll11l1l_l1_,l111lll11111_l1_ = list(zip(*l11111lllll1_l1_))
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭姌"), l1llllll11l1l_l1_)
			if l1l_l1_!=-1:
				l111111l1ll1_l1_ = l1llllll11l1l_l1_[l1l_l1_]
				l111llll1lll_l1_ = l11l1111llll_l1_[l1l_l1_]
				if l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ姍") in l1llllll11l1l_l1_[l1l_l1_] and l111llll1lll_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭姎")]!=l1lllllll111l_l1_:
					l111l1llllll_l1_ = l111l11l111l_l1_[l1l_l1_]
					l11l1l11l1ll_l1_ = True
				else: l111111111l1_l1_ = l111llll1lll_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ姏")]
				break
		elif choice==l11ll1_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ姐"):
			#shift += 1
			l11l1111llll_l1_,l111l11l111l_l1_,l1llllll11l1l_l1_,l111lll11111_l1_ = list(zip(*l1llllll11111_l1_))
			l111llll1lll_l1_ = l11l1111llll_l1_[l1l_l1_-shift]
			if l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ姑") in l1llllll11l1l_l1_[l1l_l1_-shift] and l111llll1lll_l1_[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ姒")]!=l1lllllll111l_l1_:
				l111l1llllll_l1_ = l111l11l111l_l1_[l1l_l1_-shift]
				l11l1l11l1ll_l1_ = True
			else: l111111111l1_l1_ = l111llll1lll_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ姓")]
			l111111l1ll1_l1_ = l1llllll11l1l_l1_[l1l_l1_-shift]
			break
	if not l11l1l11l1ll_l1_: l1lllllllll1l_l1_ = l111111111l1_l1_
	else: l1lllllllll1l_l1_ = l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠩ委")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭姕")]+l11ll1_l1_ (u"ࠪࠤ࠰ࠦࡁࡶࡦ࡬ࡳ࠿ࠦࠧ姖")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ姗")]
	if l11l1l11l1ll_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭姘"),l11ll1_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰࠱ࠠࠡࠢࠪ姙")+str(l111llll1lll_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ姚"),l11ll1_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ姛")+str(l111l1llllll_l1_))
		#if l11l1l1111l1_l1_>l111l1ll1111_l1_: l1l11lll1_l1_ = str(l11l1l1111l1_l1_)
		#else: l1l11lll1_l1_ = str(l111l1ll1111_l1_)
		#l1l11lll1_l1_ = str(l11l1l1111l1_l1_) if l11l1l1111l1_l1_>l111l1ll1111_l1_ else str(l111l1ll1111_l1_)
		l11l1l1111l1_l1_ = int(l111llll1lll_l1_[l11ll1_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ姜")])
		l111l1ll1111_l1_ = int(l111l1llllll_l1_[l11ll1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ姝")])
		l1l11lll1_l1_ = str(max(l11l1l1111l1_l1_,l111l1ll1111_l1_))
		l111l1l11111_l1_ = l111llll1lll_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ姞")].replace(l11ll1_l1_ (u"ࠬࠬࠧ姟"),l11ll1_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ姠"))		# +l11ll1_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ姡")
		l11l111lll11_l1_ = l111l1llllll_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ姢")].replace(l11ll1_l1_ (u"ࠩࠩࠫ姣"),l11ll1_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ姤"))		# +l11ll1_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ姥")
		l11l1l11l111_l1_ = l11ll1_l1_ (u"ࠬࡂ࠿ࡹ࡯࡯ࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨ࠱࠯࠲ࠥࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࡃࠢࡖࡖࡉ࠱࠽ࠨ࠿࠿࡞ࡱࠫ姦")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"࠭࠼ࡎࡒࡇࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡸ࡯࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠸࠰࠱࠳࠲࡜ࡒࡒࡓࡤࡪࡨࡱࡦ࠳ࡩ࡯ࡵࡷࡥࡳࡩࡥࠣࠢࡻࡱࡱࡴࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠦࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡲࡩ࡯࡭ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠳࠼࠽࠾࠵ࡸ࡭࡫ࡱ࡯ࠧࠦࡸࡴ࡫࠽ࡷࡨ࡮ࡥ࡮ࡣࡏࡳࡨࡧࡴࡪࡱࡱࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠠࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡲࡩࡧࡲࡥࡵ࠱࡭ࡸࡵ࠮ࡰࡴࡪ࠳࡮ࡺࡴࡧ࠱ࡓࡹࡧࡲࡩࡤ࡮ࡼࡅࡻࡧࡩ࡭ࡣࡥࡰࡪ࡙ࡴࡢࡰࡧࡥࡷࡪࡳ࠰ࡏࡓࡉࡌ࠳ࡄࡂࡕࡋࡣࡸࡩࡨࡦ࡯ࡤࡣ࡫࡯࡬ࡦࡵ࠲ࡈࡆ࡙ࡈ࠮ࡏࡓࡈ࠳ࡾࡳࡥࠤࠣࡱ࡮ࡴࡂࡶࡨࡩࡩࡷ࡚ࡩ࡮ࡧࡀࠦࡕ࡚࠱࠯࠷ࡖࠦࠥࡳࡥࡥ࡫ࡤࡔࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡆࡸࡶࡦࡺࡩࡰࡰࡀࠦࡕ࡚ࠧ姧")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠧࡔࠤࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࡁࡠࡳ࠭姨")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ姩")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠱ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡶࡪࡦࡨࡳ࠴࠭姪")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ姫")]+l11ll1_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ姬")		# l111l1ll1ll1_l1_=l11ll1_l1_ (u"ࠧ࠷ࠢ姭") l11l1l111ll1_l1_=l11ll1_l1_ (u"ࠨࡴࡳࡷࡨࠦ姮") default=l11ll1_l1_ (u"ࠢࡵࡴࡸࡩࠧ姯")>\n
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭姰")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ姱")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ姲")]+l11ll1_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ姳")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ姴")]+l11ll1_l1_ (u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ姵")+str(l111llll1lll_l1_[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ姶")])+l11ll1_l1_ (u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ姷")+str(l111llll1lll_l1_[l11ll1_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ姸")])+l11ll1_l1_ (u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ姹")+str(l111llll1lll_l1_[l11ll1_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ姺")])+l11ll1_l1_ (u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬ姻")+l111llll1lll_l1_[l11ll1_l1_ (u"࠭ࡦࡱࡵࠪ姼")]+l11ll1_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ姽")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ姾")+l111l1l11111_l1_+l11ll1_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ姿")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ娀")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ威")]+l11ll1_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ娂")	# l1llllll1111l_l1_=l11ll1_l1_ (u"ࠨࡴࡳࡷࡨࠦ娃")>\n
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ娄")+l111llll1lll_l1_[l11ll1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭娅")]+l11ll1_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ娆")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭娇")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ娈")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ娉")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪ娊")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ娋")]+l11ll1_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ娌")		# l111l1ll1ll1_l1_=l11ll1_l1_ (u"ࠤ࠴ࠦ娍") l11l1l111ll1_l1_=l11ll1_l1_ (u"ࠥࡸࡷࡻࡥࠣ娎") default=l11ll1_l1_ (u"ࠦࡹࡸࡵࡦࠤ娏")>\n
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ娐")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭娑")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ娒")]+l11ll1_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ娓")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ娔")]+l11ll1_l1_ (u"ࠪࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤ࠴࠷࠵࠺࠷࠶ࠤࡁࡠࡳ࠭娕")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠫࡁࡇࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼࠵࠷࠵࠶࠳࠻࠵࠽ࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠪ娖")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭娗")]+l11ll1_l1_ (u"࠭ࠢ࠰ࡀ࡟ࡲࠬ娘")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ娙")+l11l111lll11_l1_+l11ll1_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ娚")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ娛")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ娜")]+l11ll1_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ娝")	# l1llllll1111l_l1_=l11ll1_l1_ (u"ࠧࡺࡲࡶࡧࠥ娞")>\n
		l11l1l11l111_l1_ += l11ll1_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ娟")+l111l1llllll_l1_[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ娠")]+l11ll1_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ娡")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ娢")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ娣")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ娤")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"ࠬࡂ࠯ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪ娥")
		l11l1l11l111_l1_ += l11ll1_l1_ (u"࠭࠼࠰ࡏࡓࡈࡃࡢ࡮ࠨ娦")
		#open(l11ll1_l1_ (u"ࠧࡴ࠼࡟ࡠࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ娧"),l11ll1_l1_ (u"ࠨࡹࡥࠫ娨")).write(l11l1l11l111_l1_)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ娩"),l11l1l11l111_l1_)
		#l11l1l11l111_l1_ = OPENURL_CACHED(NO_CACHE,l1lllllll111l_l1_,l11ll1_l1_ (u"ࠪࠫ娪"),l11ll1_l1_ (u"ࠫࠬ娫"),l11ll1_l1_ (u"ࠬ࠭娬"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠽ࡹ࡮ࠧ娭"))
		if kodi_version>18.99:
			import http.server as l111ll1l1l11_l1_
			import http.client as l11111lll1l1_l1_
		else:
			import BaseHTTPServer as l111ll1l1l11_l1_
			import httplib as l11111lll1l1_l1_
		class l111111l111l_l1_(l111ll1l1l11_l1_.HTTPServer):
			#l11l1l11l111_l1_ = l11ll1_l1_ (u"ࠧ࠽ࡀࠪ娮")
			def __init__(self,l1ll1111lll1_l1_=l11ll1_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ娯"),port=55055,l11l1l11l111_l1_=l11ll1_l1_ (u"ࠩ࠿ࡂࠬ娰")):
				self.l1ll1111lll1_l1_ = l1ll1111lll1_l1_
				self.port = port
				self.l11l1l11l111_l1_ = l11l1l11l111_l1_
				l111ll1l1l11_l1_.HTTPServer.__init__(self,(self.l1ll1111lll1_l1_,self.port),l111l11111l1_l1_)
				self.l1111111l11l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ娱")+l1ll1111lll1_l1_+l11ll1_l1_ (u"ࠫ࠿࠭娲")+str(port)+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ娳")
				#print(l11ll1_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡴࠥࡴ࡯ࡸࠢ࡯࡭ࡸࡺࡥ࡯࡫ࡱ࡫ࠥࡵ࡮ࠡࡲࡲࡶࡹࡀࠠࠨ娴")+str(port))
			def start(self):
				self.threads = l111l1l1ll1_l1_(False)
				self.threads.start_new_thread(1,self.l111l1l1l1l1_l1_)
			def l111l1l1l1l1_l1_(self):
				#print(l11ll1_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡧࡲࡵࡧࡧࠫ娵"))
				self.l1lllll1lll11_l1_ = True
				#l1l1ll11111_l1_ = 0
				while self.l1lllll1lll11_l1_:
					#l1l1ll11111_l1_ += 1
					#print(l11ll1_l1_ (u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠢࡤࠤࡸ࡯࡮ࡨ࡮ࡨࠤ࡭ࡧ࡮ࡥ࡮ࡨࡣࡷ࡫ࡱࡶࡧࡶࡸ࠭࠯ࠠ࡯ࡱࡺ࠾ࠥ࠭娶")+str(l1l1ll11111_l1_)+l11ll1_l1_ (u"ࠩࠪ娷"))
					#settimeout l1111lll11_l1_ not l111l1l11l_l1_ l1111l11llll_l1_ to error message if it l11111l11l1l_l1_ l1llllll1l1ll_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111l1l1l1l1_l1_ l111l1ll11ll_l1_ request l11111111l11_l1_ 60 seconds)
					self.handle_request()
				#print(l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡱࡳࡴࡪࡪ࡜࡯ࠩ娸"))
			def stop(self):
				self.l1lllll1lll11_l1_ = False
				self.l111ll1111l1_l1_()	# needed to l11l11lll11l_l1_ self.handle_request() to l111l1l1l1l1_l1_ l1111ll11ll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠥࡴ࡯ࡸ࡞ࡱࠫ娹"))
			def load(self,l11l1l11l111_l1_):
				self.l11l1l11l111_l1_ = l11l1l11l111_l1_
			def l111ll1111l1_l1_(self):
				conn = l11111lll1l1_l1_.HTTPConnection(self.l1ll1111lll1_l1_+l11ll1_l1_ (u"ࠬࡀࠧ娺")+str(self.port))
				conn.request(l11ll1_l1_ (u"ࠨࡈࡆࡃࡇࠦ娻"), l11ll1_l1_ (u"ࠢ࠰ࠤ娼"))
		class l111l11111l1_l1_(l111ll1l1l11_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11ll1_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡈࡇࡗࠤࠥ࠭娽")+self.path)
				self.send_response(200)
				self.send_header(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ娾"),l11ll1_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ娿"))
				self.end_headers()
				#self.wfile.write(self.path+l11ll1_l1_ (u"ࠫࡡࡴࠧ婀"))
				self.wfile.write(self.server.l11l1l11l111_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ婁")))
				time.sleep(1)
				if self.path==l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ婂"): self.server.shutdown()
				if self.path==l11ll1_l1_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ婃"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11ll1_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡉࡇࡄࡈࠥࠦࠧ婄")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l111111l111l_l1_(l11ll1_l1_ (u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ婅"),55055,l11l1l11l111_l1_)
		#httpd.load(l11l1l11l111_l1_)
		l111111111l1_l1_ = httpd.l1111111l11l_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l111111111l1_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱ࡯ࡶࡦࡵ࡬ࡱ࠳ࡪࡡࡴࡪ࡬ࡪ࠳ࡵࡲࡨ࠱࡯࡭ࡻ࡫ࡳࡪ࡯࠲ࡧ࡭ࡻ࡮࡬ࡦࡸࡶࡤ࠷࠯ࡢࡶࡲࡣ࠼࠵ࡴࡦࡵࡷࡴ࡮ࡩ࠴ࡠ࠺ࡶ࠳ࡒࡧ࡮ࡪࡨࡨࡷࡹ࠴࡭ࡱࡦࠪ婆")
		#l111111111l1_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡡࡴࡪ࠱ࡥࡰࡧ࡭ࡢ࡫ࡽࡩࡩ࠴࡮ࡦࡶ࠲ࡨࡦࡹࡨ࠳࠸࠷࠳࡙࡫ࡳࡵࡅࡤࡷࡪࡹ࠯࠳ࡥ࠲ࡵࡺࡧ࡬ࡤࡱࡰࡱ࠴࠷࠯ࡎࡷ࡯ࡸ࡮ࡘࡥࡴࡏࡓࡉࡌ࠸࠮࡮ࡲࡧࠫ婇")
		#l111111111l1_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡵࡵ࡬࠲ࡹ࡫࡬ࡦࡥࡲࡱ࠲ࡶࡡࡳ࡫ࡶࡸࡪࡩࡨ࠯ࡨࡵ࠳࡬ࡶࡡࡤ࠱ࡇࡅࡘࡎ࡟ࡄࡑࡑࡊࡔࡘࡍࡂࡐࡆࡉ࠴࡚ࡥ࡭ࡧࡦࡳࡲࡖࡡࡳ࡫ࡶࡘࡪࡩࡨ࠰࡯ࡳ࠸࠲ࡲࡩࡷࡧ࠲ࡱࡵ࠺࠭࡭࡫ࡹࡩ࠲ࡳࡰࡥ࠯ࡄ࡚࠲ࡈࡓ࠯࡯ࡳࡨࠬ婈")
		#l111111111l1_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡲࡥ࡯ࡨࡨ࡮ࡧ࠮ࡣࡤࡦ࠲ࡨࡵ࠮ࡶ࡭࠲ࡨࡦࡹࡨ࠰ࡱࡱࡨࡪࡳࡡ࡯ࡦ࠲ࡸࡪࡹࡴࡤࡣࡵࡨ࠴࠷࠯ࡤ࡮࡬ࡩࡳࡺ࡟࡮ࡣࡱ࡭࡫࡫ࡳࡵ࠯ࡨࡺࡪࡴࡴࡴ࠯ࡰࡹࡱࡺࡩ࡭ࡣࡱ࡫࠳ࡳࡰࡥࠩ婉")
		#l111111111l1_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ婊")
	else: httpd = l11ll1_l1_ (u"ࠨࠩ婋")
	if not l111111111l1_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ婌"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ婍"),[l11ll1_l1_ (u"ࠫࠬ婎")],[[l111111111l1_l1_,l111l11l1lll_l1_,httpd]]
def l1111ll11111_l1_(url):
	# https://l11l11ll11l1_l1_.com/l1111lll1l11_l1_
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ婏") : l11ll1_l1_ (u"࠭ࠧ婐") }
	#url = url.replace(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭婑"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ婒"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ婓"),headers,l11ll1_l1_ (u"ࠪࠫ婔"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡆࡔࡈ࠭࠲ࡵࡷࠫ婕"))
	items = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࢁ࠯࡜ࡾࠩ婖"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l111111llll1_l1_,l1lll11l_l1_,l11l111l11ll_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1lllll_l1_,dummy,l1ll1l1lll11_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭婗"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭婘"))
			if l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ婙") in l1lllll_l1_:
				l111111llll1_l1_,l11l111l11ll_l1_ = l11ll11ll1_l1_(l1lllll_l1_)
				#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ婚"),l11ll1_l1_ (u"ࠪࠫ婛"),str(l1llll_l1_),str(l11l111l11ll_l1_))
				l1llll_l1_ = l1llll_l1_ + l11l111l11ll_l1_
				if l111111llll1_l1_[0]==l11ll1_l1_ (u"ࠫ࠲࠷ࠧ婜"): l1lll11l_l1_.append(l11ll1_l1_ (u"ู๊ࠬาใิࠤำอีࠨ婝")+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧ婞"))
				else:
					for title in l111111llll1_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ࠧิ์ิๅึࠦฮศืࠪ婟")+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ婠")+title)
			else:
				title = l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ婡")+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭婢")+l1ll1l1lll11_l1_
				l1llll_l1_.append(l1lllll_l1_)
				l1lll11l_l1_.append(title)
		return l11ll1_l1_ (u"ࠫࠬ婣"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡆࡔࡈࠧ婤"),[],[]
def	l1lllllll11ll_l1_(url):
	# https://l11l11llll11_l1_.cc/l1l111l1l_l1_-1qrpoobdg7bu.html
	# https://l111l1llll1l_l1_.cc//l1l111l1l_l1_-l111lll1111l_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ婥"),url,l11ll1_l1_ (u"ࠧࠨ婦"),l11ll1_l1_ (u"ࠨࠩ婧"),l11ll1_l1_ (u"ࠩࠪ婨"),l11ll1_l1_ (u"ࠪࠫ婩"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡘࡌࡈࡊࡕࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ婪"))
	html = response.content
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ婫"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		return l11ll1_l1_ (u"࠭ࠧ婬"),[l11ll1_l1_ (u"ࠧࠨ婭")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠨࠩ婮"),[],[]
def	l1llllllll1ll_l1_(url):
	# https://l1llllllll1l1_l1_.in/l11111l1l11l_l1_
	# https://l1llllllll1l1_l1_.in/l1l111l1l_l1_-l11111l1l11l_l1_.html
	# https://l111ll1ll11l_l1_.l1111l111l11_l1_/l11l11l1l11l_l1_
	# https://l111ll1ll11l_l1_.l1111l111l11_l1_/l1l111l1l_l1_-l11l11l1l11l_l1_.html
	# https://www.l11l11l1llll_l1_.com/l1l111l1l_l1_-l111l111ll1l_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ婯"),l11ll1_l1_ (u"ࠪࠫ婰")).replace(l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ婱"),l11ll1_l1_ (u"ࠬ࠭婲"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ婳"),url,l11ll1_l1_ (u"ࠧࠨ婴"),l11ll1_l1_ (u"ࠨࠩ婵"),l11ll1_l1_ (u"ࠩࠪ婶"),l11ll1_l1_ (u"ࠪࠫ婷"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ婸"))
	html = response.content
	l1lll1ll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩ࡝ࠫࠬࠫ婹"),html,re.DOTALL)
	if l1lll1ll1ll1_l1_:
		l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_[0]
		l1l1lll1l1l1_l1_ = l1ll111l1l11_l1_(l1lll1ll1ll1_l1_)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ婺"),l1l1lll1l1l1_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠩࡾࠩ婻"),l1l1lll1l1l1_l1_,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_,title in l1l1_l1_:
			if not title: title = l1lllll_l1_.rsplit(l11ll1_l1_ (u"ࠨ࠰ࠪ婼"),1)[1]
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		return l11ll1_l1_ (u"ࠩࠪ婽"),l1lll11l_l1_,l1llll_l1_
	id = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ婾"))[3]
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ婿"):l11ll1_l1_ (u"ࠬ࠭媀") , l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ媁"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭媂") }
	payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ媃"):id , l11ll1_l1_ (u"ࠩࡲࡴࠬ媄"):l11ll1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭媅") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ媆"),url,payload,headers,l11ll1_l1_ (u"ࠬ࠭媇"),l11ll1_l1_ (u"࠭ࠧ媈"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭媉"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ媊"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠩࠪ媋"),[l11ll1_l1_ (u"ࠪࠫ媌")],[ items[0] ]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋࠬ媍"),[],[]
l11ll1_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡍࡏࡗࡋࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡹ࡭ࡩ࡫࡯࠰ࡲ࡯ࡥࡾ࠵ࡁࡂࡘࡈࡒࡩࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࠤ࠿ࠦࠧࠨࠢࢀࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑ࡙ࡍࡉ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡦࠡࠩ࠱ࡱ࠸ࡻ࠸ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧࠪࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶ࠺ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪื๏ืแาࠢัหฺ࠭ࠫࠨࠢࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤู๊ࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭ࡱ࠶ࠪࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡺࡵࡳࡰࠣࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡘࡌࡈࠬ࠲࡛࡞࠮࡞ࡡࠏࠏࠣࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠵ࡲ࠴ࡧࡰࡸ࡬ࡨ࠳ࡩ࡯࠰ࡵࡷࡶࡪࡧ࡭࠰࠴࠵࠽࠳ࡳ࠳ࡶ࠺ࠍࠦࠧࠨ媎")
#####################################################
#    l11l11l1111l_l1_ l1111llll1l1_l1_ l1111l111lll_l1_
#    16-06-2019
#####################################################
def l1111ll1ll11_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ媏"),l11ll1_l1_ (u"ࠧࠨ媐"),l11ll1_l1_ (u"ࠨࠩ媑"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ媒"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ媓"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠫࠬ媔"),[l11ll1_l1_ (u"ࠬ࠭媕")],[ items[0] ]
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ媖"),[],[]
def l1111ll1111l_l1_(url):
	return l11ll1_l1_ (u"ࠧࠨ媗"),[l11ll1_l1_ (u"ࠨࠩ媘")],[ url ]
def l1111lllll11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ媙"),l11ll1_l1_ (u"ࠪࠫ媚"),url,l11ll1_l1_ (u"ࠫࠬ媛"))
	server = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ媜"))
	basename = l11ll1_l1_ (u"࠭࠯ࠨ媝").join(server[0:3])
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ媞"),l11ll1_l1_ (u"ࠨࠩ媟"),l11ll1_l1_ (u"ࠩࠪ媠"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧ媡"))
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭媢"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭媣"),l11ll1_l1_ (u"࠭ࠧ媤"),url,str(var))
	if items:
		l11ll11l1l1l_l1_,l11ll1l1111l_l1_,l11ll1l111l1_l1_,l111ll1llll1_l1_,l111ll1lllll_l1_,l111ll1lll1l_l1_ = items[0]
		var = int(l11ll1l1111l_l1_) % int(l11ll1l111l1_l1_) + int(l111ll1llll1_l1_) % int(l111ll1lllll_l1_)
		url = basename + l11ll11l1l1l_l1_ + str(var) + l111ll1lll1l_l1_
		return l11ll1_l1_ (u"ࠧࠨ媥"),[l11ll1_l1_ (u"ࠨࠩ媦")],[url]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅࠨ媧"),[],[]
def l111ll1l11ll_l1_(url):
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ媨"),l11ll1_l1_ (u"ࠫࠬ媩"))
	url = url.replace(l11ll1_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ媪"),l11ll1_l1_ (u"࠭ࠧ媫"))
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ媬"))[-1]
	headers = { l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ媭") : l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ媮") }
	payload = { l11ll1_l1_ (u"ࠥ࡭ࡩࠨ媯"):id , l11ll1_l1_ (u"ࠦࡴࡶࠢ媰"):l11ll1_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣ媱") }
	request = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ媲"), url, payload, headers, l11ll1_l1_ (u"ࠧࠨ媳"),l11ll1_l1_ (u"ࠨࠩ媴"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ媵"))
	if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ媶") in list(request.headers.keys()): l1lllll_l1_ = request.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭媷")]
	else: l1lllll_l1_ = url
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠬ࠭媸"),[l11ll1_l1_ (u"࠭ࠧ媹")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬ媺"),[],[]
def l11111ll1ll1_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ媻"),l11ll1_l1_ (u"ࠩࠪ媼"),l11ll1_l1_ (u"ࠪࠫ媽"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ媾"))
	items = re.findall(l11ll1_l1_ (u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ媿"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"࠭ࠧ嫀"),[l11ll1_l1_ (u"ࠧࠨ嫁")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭嫂"),[],[]
def l1lllll1llll1_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ嫃"),l11ll1_l1_ (u"ࠪࠫ嫄"),l11ll1_l1_ (u"ࠫࠬ嫅"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭嫆"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嫇"),html,re.DOTALL)
	#l111l1llll11_l1_.l1llllll1l111_l1_(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭嫈") + items[0])
	if items:
		url = url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ嫉") + items[0]
		return l11ll1_l1_ (u"ࠩࠪ嫊"),[l11ll1_l1_ (u"ࠪࠫ嫋")],[ url ]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧ嫌"),[],[]
def l111l111llll_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭嫍"),l11ll1_l1_ (u"࠭ࠧ嫎"),l11ll1_l1_ (u"ࠧࠨ嫏"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕ࡛ࡂࡍࡋࡆ࡚ࡎࡊࡅࡐࡊࡒࡗ࡙࠳࠱ࡴࡶࠪ嫐"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ嫑"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嫒"),l11ll1_l1_ (u"ࠫࠬ嫓"),str(items),html)
	if items: return l11ll1_l1_ (u"ࠬ࠭嫔"),[l11ll1_l1_ (u"࠭ࠧ嫕")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓ࡙ࡇࡒࡉࡄࡘࡌࡈࡊࡕࡈࡐࡕࡗࠫ嫖"),[],[]
def l1111ll1l111_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ嫗"),l11ll1_l1_ (u"ࠩࠪ嫘"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ嫙"),l11ll1_l1_ (u"ࠫࠬ嫚"),l11ll1_l1_ (u"ࠬ࠭嫛"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ嫜"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嫝"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嫞"),l11ll1_l1_ (u"ࠩࠪ嫟"),items[0],items[0])
	if items: return l11ll1_l1_ (u"ࠪࠫ嫠"),[l11ll1_l1_ (u"ࠫࠬ嫡")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ嫢"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ〶")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨ〷")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ〸"):l11ll1_l1_ (u"ࠫࠬ〹")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l11111_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〺"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭〻"),l11ll1_l1_ (u"ࠧࠨ〼"),329,l11ll1_l1_ (u"ࠨࠩ〽"),l11ll1_l1_ (u"ࠩࠪ〾"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ〿"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ぀"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬぁ"),l11ll1_l1_ (u"࠭ࠧあ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫぃ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬい"),l11ll1_l1_ (u"ࠩࠪぅ"),headers,l11ll1_l1_ (u"ࠪࠫう"),l11ll1_l1_ (u"ࠫࠬぇ"),l11ll1_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪえ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡤࡱࡱࡳ࠲ࡶ࡬ࡶࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧぉ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭お"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title==l11ll1_l1_ (u"ࠨษ็้่ะศสࠢส่๊ืฦ๋หࠪか"): continue
		l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩが"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬき")+l111l1_l1_+title,l1lllll_l1_,321)
	return html
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬぎ"),l11ll1_l1_ (u"ࠬ࠭く"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪぐ"),url,l11ll1_l1_ (u"ࠧࠨけ"),headers,l11ll1_l1_ (u"ࠨࠩげ"),l11ll1_l1_ (u"ࠩࠪこ"),l11ll1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪご"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬさ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡱࡦ࠸ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨざ"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭し"),block,re.DOTALL)
	for l1lllll_l1_,l1lll1_l1_,count,title in items:
		count = count.replace(l11ll1_l1_ (u"ฺࠧัาࠤࠬじ"),l11ll1_l1_ (u"ࠨࠩす")).replace(l11ll1_l1_ (u"ࠩࠣࠫず"),l11ll1_l1_ (u"ࠪࠫせ"))
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴࠭ぜ"),l11ll1_l1_ (u"ࠬ࠭そ"))
		l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠨࠧࠣぞ"),l11ll1_l1_ (u"ࠧࠨた"))
		if l11ll1_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭だ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬち")+l1lllll_l1_
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬぢ")+l1lllll_l1_
		l1lll1_l1_ = l11l1l_l1_+l1lll1_l1_
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭っ"))
		title = title+l11ll1_l1_ (u"ࠬࠦࠨࠨつ")+count+l11ll1_l1_ (u"࠭ࠩࠨづ")
		if l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪて") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨで"),l111l1_l1_+title,l1lllll_l1_,321,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬと") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩど"),l111l1_l1_+title,l1lllll_l1_,322,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬな"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫに"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪぬ")+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧね"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧの")+title,l1lllll_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭は"),url,l11ll1_l1_ (u"ࠪࠫば"),headers,l11ll1_l1_ (u"ࠫࠬぱ"),l11ll1_l1_ (u"ࠬ࠭ひ"),l11ll1_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫび"))
	html = response.content
	#l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࡸࡨ࡮ࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧぴ"),html,re.DOTALL)
	#if not l1lllll_l1_:
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨふ"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]#+l11ll1_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨぶ")+l11llllll_l1_()+l11ll1_l1_ (u"ࠪࠪࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡶࡵࡹࡪ࠭ぷ")
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪへ"))
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"๋ࠬฮหษิࠫべ")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧぺ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨほ"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪぼ"),l11ll1_l1_ (u"ࠩ࠮ࠫぽ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫま")+search
	l11111_l1_(url)
	return
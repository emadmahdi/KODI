# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㇢")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡑࡘ࡚ࡠࠩ㇣")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭㇤"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭㇥"),l11ll1_l1_ (u"࠭วๅษๅืฬ๋ࠧ㇦"),l11ll1_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫ㇧")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l11111_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l1llll1_l1_(url,text)
	elif mode==704: results = l1l111_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡽ࡭ࡰࡧ࠮࠺ࠩ㇨")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㇩"),l1ll111_l1_,l11ll1_l1_ (u"ࠪࠫ㇪"),l11ll1_l1_ (u"ࠫࠬ㇫"),l11ll1_l1_ (u"ࠬ࠭㇬"),l11ll1_l1_ (u"࠭ࠧ㇭"),l11ll1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㇮"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇯"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩㇰ"),l11ll1_l1_ (u"ࠪࠫㇱ"),709,l11ll1_l1_ (u"ࠫࠬㇲ"),l11ll1_l1_ (u"ࠬ࠭ㇳ"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪㇴ"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬㇵ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨㇶ"),l11ll1_l1_ (u"ࠩࠪㇷ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㇸ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ㇹ")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬๅ๋ิࠪㇺ"),l1ll111_l1_,701,l11ll1_l1_ (u"࠭ࠧㇻ"),l11ll1_l1_ (u"ࠧࠨㇼ"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪㇽ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㇾ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬㇿ")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ㈀"),l1ll111_l1_,701,l11ll1_l1_ (u"ࠬ࠭㈁"),l11ll1_l1_ (u"࠭ࠧ㈂"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㈃"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈄"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㈅")+l111l1_l1_+l11ll1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ㈆"),l1ll111_l1_,701,l11ll1_l1_ (u"ࠫࠬ㈇"),l11ll1_l1_ (u"ࠬ࠭㈈"),l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ㈉"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈊"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㈋")+l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩ㈌"),l1ll111_l1_,701,l11ll1_l1_ (u"ࠪࠫ㈍"),l11ll1_l1_ (u"ࠫࠬ㈎"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ㈏"))
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㈐"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㈑"),l11ll1_l1_ (u"ࠨࠩ㈒"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡱ࠲ࡺ࡯ࡱ࠯ࡱࡥࡻࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡭࡯ࡤࡥࡧࡱࠫ㈓"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࠪ㈔"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = title.replace(l11ll1_l1_ (u"ࠫࡁࡨ࠾ࠨ㈕"),l11ll1_l1_ (u"ࠬ࠭㈖")).strip(l11ll1_l1_ (u"࠭ࠠࠨ㈗"))
		if title in l1l11l_l1_: continue
		if l1lllll_l1_.endswith(l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵ࠭㈘")): continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈙"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㈚")+l111l1_l1_+title,l1lllll_l1_,704)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㈛"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㈜"),l11ll1_l1_ (u"ࠬ࠭㈝"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭㈞"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ㈟"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠨࠩ㈠"))
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬ㈡"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	title = title.replace(l11ll1_l1_ (u"ࠪࡀࡧࡄࠧ㈢"),l11ll1_l1_ (u"ࠫࠬ㈣")).strip(l11ll1_l1_ (u"ࠬࠦࠧ㈤"))
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈥"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㈦")+l111l1_l1_+title,l1lllll_l1_,704)
	return
def l1l111_l1_(url):
	l1ll1l1ll_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㈧"),url,l11ll1_l1_ (u"ࠩࠪ㈨"),l11ll1_l1_ (u"ࠪࠫ㈩"),l11ll1_l1_ (u"ࠫࠬ㈪"),l11ll1_l1_ (u"ࠬ࠭㈫"),l11ll1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㈬"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳࡱ࡯ࡩࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㈭"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ㈮"),l11ll1_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ㈯"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㈰"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠫࠬ㈱"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㈲"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㈳"),l11ll1_l1_ (u"ࠧࠨ㈴"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㈵"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠩ࠽ࠤࠬ㈶")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㈷"),l111l1_l1_+title,l1lllll_l1_,701)
				l1ll1l1ll_l1_ = True
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㈸"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ㈹"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1l1ll_l1_: addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㈺"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㈻"),l11ll1_l1_ (u"ࠨࠩ㈼"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈽"),l111l1_l1_+title,l1lllll_l1_,701)
				l1ll1l1ll_l1_ = True
	l1l11llll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡺࡦࡰࡱࡷࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㈾"),html,re.DOTALL)
	if l1l11llll_l1_:
		block = l1l11llll_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㈿"),block,re.DOTALL)
		if 1:
			if l1ll1l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㉀"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㉁"),l11ll1_l1_ (u"ࠧࠨ㉂"),9999)
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ㉃"))
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉄"),l111l1_l1_+title,l1lllll_l1_,701)
				l1ll1l1ll_l1_ = True
	if not l1ll1l1ll_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠪࠫ㉅")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㉆"),l11ll1_l1_ (u"ࠬ࠭㉇"),request,url)
	if request==l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ㉈"):
		url,search = url.split(l11ll1_l1_ (u"ࠧࡀࠩ㉉"),1)
		data = l11ll1_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ㉊")+search
		headers = {l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㉋"):l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ㉌")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㉍"),url,data,headers,l11ll1_l1_ (u"ࠬ࠭㉎"),l11ll1_l1_ (u"࠭ࠧ㉏"),l11ll1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ㉐"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㉑"),url,l11ll1_l1_ (u"ࠩࠪ㉒"),l11ll1_l1_ (u"ࠪࠫ㉓"),l11ll1_l1_ (u"ࠫࠬ㉔"),l11ll1_l1_ (u"ࠬ࠭㉕"),l11ll1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㉖"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠧࠨ㉗"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ㉘"))
	if request==l11ll1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ㉙"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㉚"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠫࠬ㉛"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㉜"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㉝"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㉞"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㉟"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭㉠"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㉡"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㉢"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬ㉣"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㉤"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠧࠨ㉥"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㉦"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㉧"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ㉨"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ㉩"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫ㉪"),l11ll1_l1_ (u"࠭ใๅ์หࠫ㉫"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭㉬"),l11ll1_l1_ (u"ࠨ้าหๆ࠭㉭"),l11ll1_l1_ (u"่ࠩฬฬืวสࠩ㉮"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧ㉯"),l11ll1_l1_ (u"๊ࠫํัอษ้ࠫ㉰"),l11ll1_l1_ (u"ࠬอไษ๊่ࠫ㉱"),l11ll1_l1_ (u"࠭ๅิำะ๎ฮ࠭㉲")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ㉳"))
		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭㉴") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ㉵")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ㉶"))
		#if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㉷") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ㉸")+l1lll1_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ㉹"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ㉺"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ㉻"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㉼"),l111l1_l1_+title,l1lllll_l1_,702,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㉽"):
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㉾"),l111l1_l1_+title,l1lllll_l1_,702,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㉿") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊀"),l111l1_l1_+title,l1lllll_l1_,703,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㊁") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊂"),l111l1_l1_+title,l1lllll_l1_,701,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㊃"),l111l1_l1_+title,l1lllll_l1_,703,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㊄"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㊅")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㊆"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㊇"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ㊈"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ㊉")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ㊊"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㊋"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ㊌")+title,l1lllll_l1_,701)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㊍"),l11ll1_l1_ (u"࠭ࠧ㊎"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ㊏"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㊐"),url,l11ll1_l1_ (u"ࠩࠪ㊑"),l11ll1_l1_ (u"ࠪࠫ㊒"),l11ll1_l1_ (u"ࠫࠬ㊓"),l11ll1_l1_ (u"ࠬ࠭㊔"),l11ll1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ㊕"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ㊖"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㊗"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠩࠪ㊘")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ㊙"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧ㊚"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠩࠧ㊛"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊜"),l111l1_l1_+title,url,703,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ㊝"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹࡄࠧ㊞"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㊟"),str(l1l1l11_l1_))
	block = l1l1l11_l1_[0]
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ㊠")+l1l1l_l1_+l11ll1_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㊡"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ㊢")+l1l1l_l1_+l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㊣"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫ㊤")+l1l1l_l1_+l11ll1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㊥"),block,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣ㊦"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㊧"),l11ll1_l1_ (u"ࠫࠬ㊨"),l11ll1_l1_ (u"ࠬ࠭㊩"),l11ll1_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬ㊪"))
		if not l1l1l1l_l1_: l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ㊫"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㊬"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠱࠳ࠬ㊭"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ㊮")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭㊯"))
			title = title.replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪ㊰"),l11ll1_l1_ (u"࠭ࠠࠨ㊱"))
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㊲"),l111l1_l1_+title,l1lllll_l1_,702,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ㊳"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㊴") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ㊵")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭㊶"))
		#		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㊷"),l111l1_l1_+title,l1lllll_l1_,702,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l11l_l1_,l1llll11_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ㊸"),l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪ㊹"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㊺"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ㊻"),l11ll1_l1_ (u"ࠪࠫ㊼"),l11ll1_l1_ (u"ࠫࠬ㊽"),l11ll1_l1_ (u"ࠬ࠭㊾"),l11ll1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㊿"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ㋀"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l1l_l1_ l1lllll_l1_
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡓࡰࡦࡿࡥࡳࡪࡲࡰࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㋁"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ㋂"))
			l1llll_l1_.append(l1lllll_l1_)
		# l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ㋃"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭㋄"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㋅")+title+l11ll1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ㋆"))
				l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡖࡩࡷࡼࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㋇"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㋈"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				title = title.strip(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㋉"))
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㋊")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㋋"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l11l_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1llll11_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ㋌"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㋍"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ㋎"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ㋏"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ㋐"),l11ll1_l1_ (u"ࠪ࠯ࠬ㋑"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ㋒")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ㋓"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ㋔")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ㋕"))
	return
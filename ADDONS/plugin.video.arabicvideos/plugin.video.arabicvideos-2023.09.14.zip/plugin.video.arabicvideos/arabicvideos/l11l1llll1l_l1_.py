# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ揍")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋࡑࡤ࠭揎")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11llllll1_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l1l1_l1_ = l1l1lll_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11111_l1_(url)
	elif mode==52: results = l1llll1l_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1lll1111llll_l1_()
	elif mode==56: results = l1lll1111l1ll_l1_()
	elif mode==57: results = l1lll1111ll11_l1_(url,1)
	elif mode==58: results = l1lll1111ll11_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ描"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ提"),l11ll1_l1_ (u"ࠪࠫ揑"),59,l11ll1_l1_ (u"ࠫࠬ插"),l11ll1_l1_ (u"ࠬ࠭揓"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ揔"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ揕"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭揖"),l11ll1_l1_ (u"ࠩࠪ揗"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ揘"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭揙")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆี็ื้อสࠨ揚"),l11ll1_l1_ (u"࠭ࠧ換"),56)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揜"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ揝")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่ฬ็ไศ็ࠪ揞"),l11ll1_l1_ (u"ࠪࠫ揟"),55)
	return l11ll1_l1_ (u"ࠫࠬ揠")
def l1lll1111llll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ握"),l111l1_l1_+l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊วโๆส้ࠬ揢"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ揣"),51)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ揤"),l111l1_l1_+l11ll1_l1_ (u"ࠩสๅ้อๅࠡำสสัฯࠧ揥"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭揦"),51)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ揧"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮาࠢสฺฬ็วหࠢส่ฬ็ไศ็ࠪ揨"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ揩"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揪"),l111l1_l1_+l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠠไๆสื๏้๊สࠩ揫"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ揬"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ揭"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ揮"),l11ll1_l1_ (u"ࠬ࠭揯"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭揰"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ揱"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡽࡴࡶࠧ揲"),57)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ揳"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ援"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭揵"),57)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ揶"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ揷"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ揸"),57)
	return
def l1lll1111l1ll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ揹"),l111l1_l1_+l11ll1_l1_ (u"ࠩสัิัࠠศๆ่ืู้ไศฬࠪ揺"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵࡮ࡦࡹࡨࡷࡹ࠭揻"),51)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ揼"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦัศศฯอࠬ揽"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪ揾"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揿"),l111l1_l1_+l11ll1_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไๆี็ื้อสࠨ搀"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡲࡡࡵࡧࡶࡸࠬ搁"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ搂"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆสฮ้ࠥไศีํ็๏ฯࠧ搃"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡥ࡯ࡥࡸࡹࡩࡤࠩ搄"),51)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ搅"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ搆"),l11ll1_l1_ (u"ࠨࠩ搇"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ搈"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬุ์ษࠡษ็ห๋ะวอࠩ搉"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡺࡱࡳࠫ搊"),57)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ搋"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศศๆสๅ฻๊ࠠหไํ๎๊࠭搌"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡶࡪࡼࡩࡦࡹࠪ損"),57)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ搎"),l111l1_l1_+l11ll1_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อใฬำู้ࠣอ็ะหࠪ搏"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡶࡪࡧࡺࡷࠬ搐"),57)
	return
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ搑"),l11ll1_l1_ (u"ࠬ࠭搒"),url,url)
	if l11ll1_l1_ (u"࠭࠿ࠨ搓") in url:
		parts = url.split(l11ll1_l1_ (u"ࠧࡀࠩ搔"))
		url = parts[0]
		filter = l11ll1_l1_ (u"ࠨࡁࠪ搕") + QUOTE(parts[1],l11ll1_l1_ (u"ࠩࡀࠪ࠿࠵ࠥࠨ搖"))
	else: filter = l11ll1_l1_ (u"ࠪࠫ搗")
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ搘"),l11ll1_l1_ (u"ࠬ࠭搙"),filter,l11ll1_l1_ (u"࠭ࠧ搚"))
	parts = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ搛"))
	sort,l1l1111_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11ll1_l1_ (u"ࠨࡻࡲࡴࠬ搜"),l11ll1_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࠩ搝"),l11ll1_l1_ (u"ࠪࡺ࡮࡫ࡷࡴࠩ搞")]:
		if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ搟"): l11lll111_l1_=l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ搠")
		elif type==l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭搡"): l11lll111_l1_=l11ll1_l1_ (u"ࠧๆี็ื้࠭搢")
		#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠯ࡳࡶࡴ࡭ࡲࡢ࡯ࡶ࠳ࠬ搣") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠩ࠲ࠫ搤") + l1l1111_l1_ + l11ll1_l1_ (u"ࠪ࠳ࠬ搥") + sort + filter
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ搦") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠬ࠵ࠧ搧") + l1l1111_l1_ + l11ll1_l1_ (u"࠭࠯ࠨ搨") + sort + filter
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ搩"),l11ll1_l1_ (u"ࠨࠩ搪"),l11ll1_l1_ (u"ࠩࠪ搫"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ搬"),l11ll1_l1_ (u"ࠫࠬ搭"),l11ll1_l1_ (u"ࠬ࠭搮"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ搯"))
		#items = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࠨ࡮ࡶ࡯ࡨࡴࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡲࡦࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ搰"),html,re.DOTALL)
		items = re.findall(l11ll1_l1_ (u"ࠨࠤࡳ࡭ࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲࠮ࠫࡁࠥࡴࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿ࠣࡲࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡶࡲࡦࡵࡥࡥࡸ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ搱"),html,re.DOTALL)
		l1l1l1lllll_l1_=0
		for id,title,l1lll11111lll_l1_,l1lll1_l1_ in items:
			l1l1l1lllll_l1_ += 1
			#l1lll1_l1_ = l11llllll1_l1_ + l11ll1_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ搲") + l1lll1_l1_ + l11ll1_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ搳")
			l1lll1_l1_ = l1l1ll1l1l1_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡼ࠲࠰࡫ࡰ࡫࠴ࡶࡲࡰࡩࡵࡥࡲ࠵࡭ࡢ࡫ࡱ࠳ࠬ搴") + l1lll1_l1_ + l11ll1_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ搵")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ搶") + id
			if type==l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭搷"): addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ搸"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			if type==l11ll1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ搹"): addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ携"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆࠣࠫ搻")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅࡥࡱ࠿ࠪ搼")+l1lll11111lll_l1_+l11ll1_l1_ (u"࠭࠽ࠨ搽")+title+l11ll1_l1_ (u"ࠧ࠾ࠩ搾")+l1lll1_l1_,52,l1lll1_l1_)
	else:
		if type==l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ搿"): l11lll111_l1_=l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ摀")
		elif type==l11ll1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ摁"): l11lll111_l1_=l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ摂")
		url = l11llllll1_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡪࡴࡱࡱ࠳ࡸ࡫࡬ࡦࡥࡷࡩࡩ࠵ࠧ摃") + sort + l11ll1_l1_ (u"࠭࠭ࠨ摄") + l11lll111_l1_ + l11ll1_l1_ (u"ࠧ࠮࡙࡚࠲࡯ࡹ࡯࡯ࠩ摅")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨࠩ摆"),l11ll1_l1_ (u"ࠩࠪ摇"),l11ll1_l1_ (u"ࠪࠫ摈"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ摉"))
		items = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡦࡨࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡤࡤࡷࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ摊"),html,re.DOTALL)
		l1l1l1lllll_l1_=0
		for id,l1lll11111lll_l1_,l1lll1_l1_,title in items:
			l1l1l1lllll_l1_ += 1
			l1lll1_l1_ = l11llllll1_l1_ + l11ll1_l1_ (u"࠭࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭摋") + l1lll1_l1_ + l11ll1_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ摌")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ摍") + id
			if type==l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ摎"): addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ摏"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			elif type==l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ摐"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ摑"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ࠥ࠭摒")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡧࡳࡁࠬ摓")+l1lll11111lll_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ摔")+title+l11ll1_l1_ (u"ࠩࡀࠫ摕")+l1lll1_l1_,52,l1lll1_l1_)
	title=l11ll1_l1_ (u"ูࠪๆำษࠡࠩ摖")
	if l1l1l1lllll_l1_==16:
		for l1l1ll1l1ll_l1_ in range(1,13) :
			if not l1l1111_l1_==str(l1l1ll1l1ll_l1_):
				#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠲ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨ摗")+type+l11ll1_l1_ (u"ࠬ࠵ࠧ摘")+str(l1l1ll1l1ll_l1_)+l11ll1_l1_ (u"࠭࠯ࠨ摙")+sort + filter
				url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ摚")+type+l11ll1_l1_ (u"ࠨ࠱ࠪ摛")+str(l1l1ll1l1ll_l1_)+l11ll1_l1_ (u"ࠩ࠲ࠫ摜")+sort + filter
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ摝"),l111l1_l1_+title+str(l1l1ll1l1ll_l1_),url,51)
	return
def l1llll1l_l1_(url):
	parts = url.split(l11ll1_l1_ (u"ࠫࡂ࠭摞"))
	l1lll11111lll_l1_ = int(parts[1])
	name = l1111_l1_(parts[2])
	name = name.replace(l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ摟"),l11ll1_l1_ (u"࠭ࠧ摠"))
	l1lll1_l1_ = parts[3]
	url = url.split(l11ll1_l1_ (u"ࠧࡀࠩ摡"))[0]
	if l1lll11111lll_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨࠩ摢"),l11ll1_l1_ (u"ࠩࠪ摣"),l11ll1_l1_ (u"ࠪࠫ摤"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ摥"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭摦"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭摧"),block,re.DOTALL)
		l1lll11111lll_l1_ = int(items[-1])
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ摨"),l11ll1_l1_ (u"ࠨࠩ摩"),l1lll11111lll_l1_,l11ll1_l1_ (u"ࠩࠪ摪"))
	#name = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡩࡵ࡮ࡨࠦ摫") )
	#l1lll1_l1_ = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠧ摬") )
	for l1ll1l1_l1_ in range(l1lll11111lll_l1_,0,-1):
		l1lllll_l1_ = url + l11ll1_l1_ (u"ࠬࡅࡥࡱ࠿ࠪ摭") + str(l1ll1l1_l1_)
		title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫ摮")+name+l11ll1_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ摯")+str(l1ll1l1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ摰"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠩࠪ摱"),l11ll1_l1_ (u"ࠪࠫ摲"),l11ll1_l1_ (u"ࠫࠬ摳"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ摴"))
	l1lll1111l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ࠯ࠬࡂࡱࡴࡳࡥ࡯ࡶ࡟ࠬࠧ࠮࠮ࠫࡁࠬࠦࠬ摵"),html,re.DOTALL)
	if l1lll1111l1l1_l1_:
		time = l1lll1111l1l1_l1_[1].replace(l11ll1_l1_ (u"ࠧࡕࠩ摶"),l11ll1_l1_ (u"ࠨࠢࠣࠤࠥ࠭摷"))
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ摸"),l11ll1_l1_ (u"ࠪࠫ摹"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏࠭摺"),l11ll1_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣื๏้่็่ࠢฮํ็ัࠡ฻็ํฺ่ࠥโ่ࠢหู่ࠠษ฻าࠤ์ึวࠡษ็์็ะࠧ摻")+l11ll1_l1_ (u"࠭࡜࡯ࠩ摼")+time)
		return
	#if l11ll1_l1_ (u"ࠧ็฻อิึูࠦๅ๋ࠣ์็๎ูࠡะฺวࠬ摽") in html:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ摾"),l11ll1_l1_ (u"ࠩࠪ摿"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠬ撀"),l11ll1_l1_ (u"๋ࠫ฿สัำࠣ฽้๏้ࠠไ๋฽ࠥิืฤࠩ撁"))
	#	return
	l1lll11111l1l_l1_,l1lll1111ll1l_l1_ = [],[]
	l1lll1111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼࡡࡳࠢࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ撂"),html,re.DOTALL)[0]
	l1lll1111l11l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡶࡢࡴࠣࡦࡦࡩ࡫ࡶࡲࡢࡳࡷ࡯ࡧࡪࡰࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ撃"),html,re.DOTALL)[0]
	# l1llll111_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩ࡮ࡶ࠾ࠥ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ撄"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		if l11ll1_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ撅") in server:
			server = l11ll1_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ撆")
			url = l1lll1111l11l_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ撇")
			url = l1lll1111lll1_l1_ + l1lllll_l1_
		if l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ撈") in url:
			l1lll11111l1l_l1_.append(url)
			l1lll1111ll1l_l1_.append(l11ll1_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠤࠬ撉")+server)
		l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࠍ࡮࡬ࠠࠨ࠰ࡰ࠷ࡺ࠾ࠧࠡ࡫ࡱࠤࡺࡸ࡬࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻ࠬࡺࡸ࡬ࠪࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࡟࠵ࡣ࠽࠾ࠩ࠰࠵ࠬࡀࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡹࡷࡲ࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠭ࠏࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡰࡤࡱࡪ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧ࡮࠵ࡸ࠼ࠥࠦࠧࠬࡵࡨࡶࡻ࡫ࡲࠪࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࡯ࡩࡳ࠮ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࠫࠬ࠾ࠏࠏࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴࡡࡸࡶࡱ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࡜࡫ࡠ࠭ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡻࡳࡩࠥࡃࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࡭ࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠠࠨࠫ࡞࠴ࡢࠐࠉࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࡜࡫ࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࠤࠥࠦࠧ࠭ࠩࠣࠤࠬ࠯ࠊࠊࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡳࡧ࡭ࡦ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡩ࡭ࡱ࡫ࡴࡺࡲࡨ࠯ࠬࠦࠠࠨ࠭ࡶࡩࡷࡼࡥࡳ࠭ࠪࠤࠥ࠭ࠫࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠥࠦࠧ撊")
	# l1111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿ࡠ࡮࡬ࡲࡰ࠴ࠪࡀ࡞ࡷࠬ࠳࠰࠿ࠪࡡ࡯࡭ࡳࡱ࡜ࠬࠤࠫ࠲࠯ࡅࠩࠣࠩ撋"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11ll1_l1_ (u"ࠨ࡯ࡳ࠸࠿࠴ࠪࡀ࡞ࡷࠬ࠳࠰࠿ࠪࡡ࡯࡭ࡳࡱ࡜ࠬࠤࠫ࠲࠯ࡅࠩࠣࠩ撌"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		filename = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫ撍"))[-1]
		filename = filename.replace(l11ll1_l1_ (u"ࠪࡪࡦࡲ࡬ࡣࡣࡦ࡯ࠬ撎"),l11ll1_l1_ (u"ࠫࠬ撏"))
		filename = filename.replace(l11ll1_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ撐"),l11ll1_l1_ (u"࠭ࠧ撑"))
		filename = filename.replace(l11ll1_l1_ (u"ࠧ࠮ࠩ撒"),l11ll1_l1_ (u"ࠨࠩ撓"))
		if l11ll1_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠩ撔") in server:
			server = l11ll1_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠣࡷࡪࡸࡶࡦࡴࠪ撕")
			url = l1lll1111l11l_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠫࡲࡧࡩ࡯ࠢࡶࡩࡷࡼࡥࡳࠩ撖")
			url = l1lll1111lll1_l1_ + l1lllll_l1_
		l1lll11111l1l_l1_.append(url)
		l1lll1111ll1l_l1_.append(l11ll1_l1_ (u"ࠬࡳࡰ࠵ࠢࠣࠫ撗")+server+l11ll1_l1_ (u"࠭ࠠࠡࠩ撘")+filename)
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࠠࡗ࡫ࡧࡩࡴࠦࡑࡶࡣ࡯࡭ࡹࡿ࠺ࠨ撙"), l1lll1111ll1l_l1_)
	if l1l_l1_ == -1 : return
	url = l1lll11111l1l_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ撚"))
	return
def l1lll1111ll11_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ撛"),l11ll1_l1_ (u"ࠪࠫ撜"),url,url)
	if l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ撝") in url: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴๋ำๅี็ࠫ撞")
	else: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵แ๋ๆ่ࠫ撟")
	l111lll_l1_ = QUOTE(l111lll_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ撠"),l11ll1_l1_ (u"ࠨࠩ撡"),l11ll1_l1_ (u"ࠩࠪ撢"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡌࡉࡍࡖࡈࡖࡘ࠳࠱ࡴࡶࠪ撣"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ撤"),l11ll1_l1_ (u"ࠬ࠭撥"),url,html)
	if type==1: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡶࡤࡪࡩࡳࡸࡥࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ撦"),html,re.DOTALL)
	elif type==2: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ撧"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮ࠨ撨"),block,re.DOTALL)
	if type==1:
		for l1lll11111ll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撩"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠪࡃࡸࡻࡢࡨࡧࡱࡶࡪࡃࠧ撪")+l1lll11111ll1_l1_,58)
	elif type==2:
		url,l1lll11111ll1_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄ࠭撫"))
		for l1ll1l11l111_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撬"),l111l1_l1_+title,url+l11ll1_l1_ (u"࠭࠿ࡤࡱࡸࡲࡹࡸࡹ࠾ࠩ播")+l1ll1l11l111_l1_+l11ll1_l1_ (u"ࠧࠧࠩ撮")+l1lll11111ll1_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ撯"),l11ll1_l1_ (u"ࠩࠪ撰"),search,search)
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ撱"),l11ll1_l1_ (u"ࠫࠪ࠸࠰ࠨ撲"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ撳"), l11l1l_l1_, l11ll1_l1_ (u"࠭ࠧ撴"), l11ll1_l1_ (u"ࠧࠨ撵"), True,l11ll1_l1_ (u"ࠨࠩ撶"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ撷"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l1l111_l1_ = cookies[l11ll1_l1_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࠫ撸")]
	#l1lll1111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࡣࡨࡹࡲࡧࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫ撹"),html,re.DOTALL)
	#l1lll1111l111_l1_ = l1lll1111l111_l1_[0]
	#payload = l11ll1_l1_ (u"ࠬࡥࡣࡴࡴࡩࡁࠬ撺") + l1lll1111l111_l1_ + l11ll1_l1_ (u"࠭ࠦࡲ࠿ࠪ撻") + QUOTE(l1111ll_l1_)
	#headers = { l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭撼"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ撽") , l11ll1_l1_ (u"ࠩࡦࡳࡴࡱࡩࡦࠩ撾"):l11ll1_l1_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡁࠬ撿")+l11l1l111_l1_ }
	#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠦ࠴ࡹࡥࡢࡴࡦ࡬ࠧ擀")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ擁"), url, payload, headers, True,l11ll1_l1_ (u"࠭ࠧ擂"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭擃"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ擄")+l1111ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭擅"),url,l11ll1_l1_ (u"ࠪࠫ擆"),l11ll1_l1_ (u"ࠫࠬ擇"),True,l11ll1_l1_ (u"ࠬ࠭擈"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ擉"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡨࡧࡱࡩࡷࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡷࡪࡧࡲࡤࡪ࠰ࡦࡴࡺࡴࡰ࡯࠰ࡴࡦࡪࡤࡪࡰࡪࠫ擊"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ擋"),block,re.DOTALL)
	if items:
		for l1lllll_l1_,l1lll1_l1_,title in items:
			#title = title.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ擌")).encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ操"))
			url = l11l1l_l1_ + l1lllll_l1_
			if l11ll1_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ擎") in url:
				if l11ll1_l1_ (u"ࠬࡅࡥࡱ࠿ࠪ擏") in url:
					title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫ擐")+title
					url = url.replace(l11ll1_l1_ (u"ࠧࡀࡧࡳࡁ࠶࠭擑"),l11ll1_l1_ (u"ࠨࡁࡨࡴࡂ࠶ࠧ擒"))
					url = url+l11ll1_l1_ (u"ࠩࡀࠫ擓")+QUOTE(title)+l11ll1_l1_ (u"ࠪࡁࠬ擔")+l1lll1_l1_
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擕"),l111l1_l1_+title,url,52,l1lll1_l1_)
				else:
					title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢๅ๏๊ๅࠡࠩ擖")+title
					addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ擗"),l111l1_l1_+title,url,53,l1lll1_l1_)
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ擘"),l11ll1_l1_ (u"ࠨࠩ擙"),l11ll1_l1_ (u"ࠩࡱࡳࠥࡸࡥࡴࡷ࡯ࡸࡸ࠭據"),l11ll1_l1_ (u"่ࠪฬࠦส้ฮาࠤ๋ะววฮ่้ࠣฮอฬࠩ擛"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䕏"):l1l111_l1_ (u"࠭ࠧ䕐")}
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭䕑")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ䕒")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠩ࠶ࠫ䕓"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠪ࠵ࠬ䕔"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠫ࠷࠭䕕"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠬ࠺ࠧ䕖"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䕗"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䕘")+l1lllll_l1_+l1l111_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ䕙"),l1l111_l1_ (u"ࠩࠪ䕚"),38)
	return l1l111_l1_ (u"ࠪࠫ䕛")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠫࠬ䕜")):
	type = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䕝"))[3]
	if type==l1l111_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䕞"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䕟"),headers,l1l111_l1_ (u"ࠨࠩ䕠"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ䕡"))
		if select==l1l111_l1_ (u"ࠪ࠷ࠬ䕢"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭䕣"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕤"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬ䕥") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ䕦"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕧"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠩ࠷ࠫ䕨"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䕩"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕪"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䕫"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕬"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䕭"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ䕮"),headers,l1l111_l1_ (u"ࠩࠪ䕯"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠲࡯ࡦࠪ䕰"))
		if select==l1l111_l1_ (u"ࠫ࠶࠭䕱"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡌ࡫࡮ࡥࡧࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ䕲"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䕳"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯ࠨ䕴") + value
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ䕵"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕶"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠪ࠶ࠬ䕷"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡅࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䕸"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕹"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䕺"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡣࡦࡸࡴࡸ࠯ࠨ䕻") + value
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕼"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䕽"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ䕾"),headers,l1l111_l1_ (u"ࠫࠬ䕿"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䖀"))
	if l1l111_l1_ (u"࠭ࡨࡰ࡯ࡨࠫ䖁") in url: type=l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䖂")
	if type==l1l111_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䖃"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷ࠭࠴ࠪࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ䖄"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䖅"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䖆"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䖇"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䖈"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䖉"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠬࡁࠬࠦࠬ䖊"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ䖋"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䖌"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䖍"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䖎"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"࠭࠱ࠨ䖏"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷࠬ䖐"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࠩ䖑"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䖒") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䖓"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳ࠯ࠬࡂࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䖔"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠭䖕"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ䖖"))
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䖗"))
			name = title + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䖘") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䖙"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡫ࡱࡿࡰࡩ࡫ࡦࡳࡳ࠳ࡣࡩࡧࡹࡶࡴࡴ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠬࡁࠬࡨࡦࡺࡡ࠮ࡴࡨࡺ࡮ࡼࡥ࠮ࡼࡲࡲࡪ࡯ࡤ࠾ࠤ࠷ࠦࠬ䖚"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䖛"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䖜") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖝"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䖞") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࡶ࠲࠱ࡶࡩࡷ࡯ࡥࡴࡎ࡬ࡲࡰ࠵ࠧ䖟") + url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䖠"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䖡"),url,l1l111_l1_ (u"ࠫࠬ䖢"),headers,l1l111_l1_ (u"ࠬ࠭䖣"),l1l111_l1_ (u"࠭ࠧ䖤"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䖥"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䖦"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䖧"),l1l111_l1_ (u"ࠪ࠳ࠬ䖨"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䖩"),url,l1l111_l1_ (u"ࠬ࠭䖪"),headers,l1l111_l1_ (u"࠭ࠧ䖫"),l1l111_l1_ (u"ࠧࠨ䖬"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䖭"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䖮"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䖯"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠫࠬ䖰")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ䖱"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ䖲"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䖳"),l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䖴")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ䖵")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ䖶"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠫอำหࠡ฻้ࠤฬ็ไศ็ࠪ䖷") , l1l111_l1_ (u"ࠬฮอฬࠢ฼๊๋ࠥำๅี็หฯ࠭䖸")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣ࠱ࠥอฮหำࠣห้ฮอฬࠩ䖹"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠧࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨ䖺") in options: type = l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䖻")
		elif l1l111_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࡡࠪ䖼") in options: type = l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䖽")
		else: return
	headers[l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䖾")] = l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䖿")
	data = {l1l111_l1_ (u"࠭ࡱࡶࡧࡵࡽࠬ䗀"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡄࡰ࡯ࡤ࡭ࡳ࠭䗁"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠨ࠳ࠪ䗂"): data[l1l111_l1_ (u"ࠩࡩࡶࡴࡳࠧ䗃")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䗄"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ䗅"),data,headers,l1l111_l1_ (u"ࠬ࠭䗆"),l1l111_l1_ (u"࠭ࠧ䗇"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䗈"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䗉"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䗊"),l1l111_l1_ (u"ࠪ࠳ࠬ䗋"))
			if l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭䗌") in url: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䗍"),l1lllll_l1_+l1l111_l1_ (u"࠭แ๋ๆ่ࠤࠬ䗎")+title,url,33)
			elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䗏") in url:
				url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ䗐"),l1l111_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࠨ䗑"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗒"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫ䗓")+title,url+l1l111_l1_ (u"ࠬ࠵࠱ࠨ䗔"),32)
	count=re.findall(l1l111_l1_ (u"࠭ࠢࡵࡱࡷࡥࡱࠨ࠺ࠩ࠰࠭ࡃ࠮ࢃࠧ䗕"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗖"),l1l111_l1_ (u"ࠨืไัฮࠦࠧ䗗")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠩࠪ䗘"),39,l1l111_l1_ (u"ࠪࠫ䗙"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠫ࠴࠭䗚")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠬࡧࡈࡓ࠲ࡦࡈࡴࡼࡌ࠳ࡦࡽࡨࡍࡐ࡬࡚࡙࠳࠴ࡑࡴࡂࡩࡤࡰ࡚࠵ࡒ࡭ࡏࡸࡏࡱࡱࡹࡌ࠳ࡘ࡮࡞࠷࡜ࡦ࡚࡙ࡍࡽࡑ࠸ࡨࡩࡤࡊࡊ࡚࡜ࡩ࠺ࡹࡥࡋࡋ࠻ࡢࡈ࡮ࡽࡨࡈ࠻ࡴࡎ࠵ࡘ࠸ࠬ䗛")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䗜"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䗝"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
import bs4
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ◌")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡒࡃࡠࠩ◍")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ◎"):l111l1_l1_}
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==510: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==511: l1lll_l1_ = l1lllll1lll_l1_(url)
	elif mode==512: l1lll_l1_ = l1111ll1l1_l1_(url)
	elif mode==513: l1lll_l1_ = l1111ll11l_l1_(url)
	elif mode==514: l1lll_l1_ = l1llllll11l_l1_(url,l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ●")+text)
	elif mode==515: l1lll_l1_ = l1llllll11l_l1_(url,l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ◐")+text)
	elif mode==516: l1lll_l1_ = l11111l1l1_l1_(text)
	elif mode==517: l1lll_l1_ = l1111l11l1_l1_(url)
	elif mode==518: l1lll_l1_ = l1111l11ll_l1_(url)
	elif mode==519: l1lll_l1_ = l1lll1_l1_(text)
	elif mode==520: l1lll_l1_ = l11111ll1l_l1_(url)
	elif mode==521: l1lll_l1_ = l1lllll1ll1_l1_(url)
	elif mode==522: l1lll_l1_ = PLAY(url)
	elif mode==523: l1lll_l1_ = l1lllllll11_l1_(text)
	elif mode==524: l1lll_l1_ = l1lllllllll_l1_()
	elif mode==525: l1lll_l1_ = l1111ll111_l1_()
	elif mode==526: l1lll_l1_ = l11111ll11_l1_()
	elif mode==527: l1lll_l1_ = l111111111_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨ◑")):
	if not l1l11l11_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◒"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ◓"),l1l111_l1_ (u"ࠪࠫ◔"),519)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ◕"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ◖"),l1l111_l1_ (u"࠭ࠧ◗"),9999)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◘"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็ว฾๋วๅࠩ◙"),l1l111_l1_ (u"ࠩࠪ◚"),525)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◛"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊รีะสูࠬ◜"),l1l111_l1_ (u"ࠬ࠭◝"),526)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◞"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆู่๋็วหࠩ◟"),l1l111_l1_ (u"ࠨࠩ◠"),527)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◡"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํฺู่หࠣห้๋ๆ้฻สฮࠬ◢"),l1l111_l1_ (u"ࠫࠬ◣"),524)
	return
def l1lllllllll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◤"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠโ์า๎ํํวหࠢ࠰ࠤำอีสࠩ◥"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࠧ◦"),520)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◧"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรฮัฮࠫ◨"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡰࡦࡺࡥࡴࡶࠪ◩"),521)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◪"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦๆิ๋ࠧ◫"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵࡯࡭ࡦࡨࡷࡹ࠭◬"),521)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◭"),l1lllll_l1_+l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษใฬำู้ࠣอ็ะหࠪ◮"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࡹ࡭ࡪࡽࡳࠨ◯"),521)
	return
def l1111ll111_l1_():
	l1llllll1l1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠬ◰")
	l111111ll1_l1_ = l1llllll1l1_l1_+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧ◱")
	l1111l1lll_l1_ = l1llllll1l1_l1_+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁ࡫ࡧ࡬ࡴࡧࠩࡸࡦ࡭࠽ࠨ◲")
	l11111111l_l1_ = l1llllll1l1_l1_+l1l111_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠴ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨ◳")
	l1111111l1_l1_ = l1llllll1l1_l1_+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩ◴")
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◵"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢฦๅ้อๅࠡ฻ิฬ๏࠭◶"),l111111ll1_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◷"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤู๊ไิๆสฮࠥ฿ัษ์ࠪ◸"),l1111l1lll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◹"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅึ่ไหฯࠦรโๆส้ࠥอฬ็สํࠫ◺"),l11111111l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◻"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ็ึุ่๊วหࠢสะ๋ฮ๊ࠨ◼"),l1111111l1_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ◽"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ◾"),l1l111_l1_ (u"ࠫࠬ◿"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☀"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤศ฿ๅศๆࠣวอาฯ๋ࠩ☁"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡧ࡬ࡱࡪࡤࡦࡪࡺࠧ☂"),517)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☃"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๋ึูࠠࠡส็ำࠥอไฦ่อหั࠭☄"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡥࡲࡹࡳࡺࡲࡺࠩ★"),517)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☆"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีࠣหฺ้๊สࠩ☇"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭☈"),517)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☉"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦๅึ่ไหฯࠦวๅ฻่่ࠬ☊"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡨࡧࡱࡶࡪ࠭☋"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☌"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิࠢึ๊ฮࠦวๅวุำฬืࠧ☍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡶࡪࡲࡥࡢࡵࡨࡣࡾ࡫ࡡࡳࠩ☎"),517)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ☏"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠲࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ☐"),l1l111_l1_ (u"ࠨࠩ☑"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☒"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํอำๆࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ☓"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ☔"),515)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☕"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ษึ้ࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ☖"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ☗"),514)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭☘"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠸ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠵࡞࠳ࡈࡕࡌࡐࡔࡠࠫ☙"),l1l111_l1_ (u"ࠪࠫ☚"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☛"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี๋ࠥอะัࠪ☜"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ☝"),515)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☞"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡๅส้้࠭☟"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ☠"),514)
	return
def l111111111_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ☡"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ☢"),l1l111_l1_ (u"ࠬ࠭☣"),headers,l1l111_l1_ (u"࠭ࠧ☤"),l1l111_l1_ (u"ࠧࠨ☥"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ☦"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ☧"),multi_valued_attributes=None)
	block = l1lllll1l1l_l1_.find(l1l111_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶࠪ☨"),attrs={l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ☩"):l1l111_l1_ (u"ࠬࡺࡡࡨࠩ☪")})
	options = block.find_all(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳ࠭☫"))
	for option in options:
		value = option.get(l1l111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭☬"))
		if not value: continue
		title = option.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭☭"))
			value = value.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ☮"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠫࡺࡹࡱࡧࡀࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧ☯")+value
		title = title.replace(l1l111_l1_ (u"ࠫ็อฦๆหࠣࠫ☰"),l1l111_l1_ (u"ࠬ࠭☱"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☲"),l1lllll_l1_+title,l1ll1ll_l1_,511)
	return
def l11111ll11_l1_():
	l1llllll1l1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩ☳")
	l111111l1l_l1_ = l1llllll1l1_l1_+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬ☴")
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☵"),l1lllll_l1_+l1l111_l1_ (u"ฺ้ࠪ์แศฬࠣวูิวึࠩ☶"),l111111l1l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ☷"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☸"),l1l111_l1_ (u"࠭ࠧ☹"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☺"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦรีะสูࠥษศอัํࠫ☻"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫ☼"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☽"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิ่ࠢ์฼์ࠧ☾"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡴࡡࡵ࡫ࡲࡲࡦࡲࡩࡵࡻࠪ☿"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♀"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืࠥࠦสศำําࠥอไๆ์็หิ࠭♁"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡤ࡬ࡶࡹ࡮࡟ࡺࡧࡤࡶࠬ♂"),517)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♃"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡࠢอหึ๐ฮࠡษ็์ๆอษࠨ♄"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡩ࡫ࡡࡵࡪࡢࡽࡪࡧࡲࠨ♅"),517)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ♆"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠸࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ♇"),l1l111_l1_ (u"ࠧࠨ♈"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♉"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ♊"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ♋"),515)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♌"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ♍"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ♎"),514)
	return
def l1lllll1lll_l1_(url):
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ♏") in url: index = 0
	elif l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ♐") in url: index = 1
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭♑"),url,l1l111_l1_ (u"ࠪࠫ♒"),headers,l1l111_l1_ (u"ࠫࠬ♓"),l1l111_l1_ (u"ࠬ࠭♔"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ♕"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ♖"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1l1l_l1_.find_all(class_=l1l111_l1_ (u"ࠨ࡬ࡸࡱࡧࡵ࠭ࡵࡪࡨࡥࡹ࡫ࡲࠡࡥ࡯ࡩࡦࡸࡦࡪࡺࠪ♗"))
	for block in l1lll1l1_l1_:
		title = block.find_all(l1l111_l1_ (u"ࠩࡤࠫ♘"))[index].text
		l1ll1ll_l1_ = l111l1_l1_+block.find_all(l1l111_l1_ (u"ࠪࡥࠬ♙"))[index].get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ♚"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♛"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♜"))
		if not l1lll1l1_l1_:
			l1111ll1l1_l1_(l1ll1ll_l1_)
			return
		else:
			title = title.replace(l1l111_l1_ (u"ࠧใษษ้ฮࠦࠧ♝"),l1l111_l1_ (u"ࠨࠩ♞"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♟"),l1lllll_l1_+title,l1ll1ll_l1_,512)
	PAGINATION(l1lllll1l1l_l1_,511)
	return
def PAGINATION(l1lllll1l1l_l1_,mode):
	block = l1lllll1l1l_l1_.find(class_=l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ♠"))
	if block:
		l1ll1l1ll_l1_ = block.find_all(l1l111_l1_ (u"ࠫࡦ࠭♡"))
		l1lllll1l11_l1_ = block.find_all(l1l111_l1_ (u"ࠬࡲࡩࠨ♢"))
		l11111l1ll_l1_ = list(zip(l1ll1l1ll_l1_,l1lllll1l11_l1_))
		l1l111lll1_l1_ = -1
		length = len(l11111l1ll_l1_)
		for l1lll1l1l_l1_,l1llllll1ll_l1_ in l11111l1ll_l1_:
			l1l111lll1_l1_ += 1
			l1llllll1ll_l1_ = l1llllll1ll_l1_[l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ♣")]
			if l1l111_l1_ (u"ࠧࡶࡰࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠬ♤") in l1llllll1ll_l1_ or l1l111_l1_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࠩ♥") in l1llllll1ll_l1_: continue
			l1llllllll1_l1_ = l1lll1l1l_l1_.text
			l111lllll_l1_ = l111l1_l1_+l1lll1l1l_l1_.get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ♦"))
			if PY2:
				l1llllllll1_l1_ = l1llllllll1_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♧"))
				l111lllll_l1_ = l111lllll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♨"))
			if   l1l111lll1_l1_==0: l1llllllll1_l1_ = l1l111_l1_ (u"ࠬษ่ๅ๋ࠪ♩")
			elif l1l111lll1_l1_==1: l1llllllll1_l1_ = l1l111_l1_ (u"࠭ำศสๅอࠬ♪")
			elif l1l111lll1_l1_==length-2: l1llllllll1_l1_ = l1l111_l1_ (u"ࠧๅษะๆฮ࠭♫")
			elif l1l111lll1_l1_==length-1: l1llllllll1_l1_ = l1l111_l1_ (u"ࠨลั๎ึฯࠧ♬")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♭"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ♮")+l1llllllll1_l1_,l111lllll_l1_,mode)
	return
def l1111ll1l1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ♯"),url,l1l111_l1_ (u"ࠬ࠭♰"),headers,l1l111_l1_ (u"࠭ࠧ♱"),l1l111_l1_ (u"ࠧࠨ♲"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠴࠱࠶ࡹࡴࠨ♳"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ♴"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1l1l_l1_.find_all(class_=l1l111_l1_ (u"ࠪࡶࡴࡽࠧ♵"))
	items,first = [],True
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠭ࡸࡴࡤࡴࡵ࡫ࡲࠨ♶")): continue
		if first: first = False ; continue
		l1111111ll_l1_ = []
		l1lllll11ll_l1_ = block.find_all(class_=[l1l111_l1_ (u"ࠬࡩࡥ࡯ࡵࡲࡶࡸ࡮ࡩࡱࠢࡵࡩࡩ࠭♷"),l1l111_l1_ (u"࠭ࡣࡦࡰࡶࡳࡷࡹࡨࡪࡲࠣࡴࡺࡸࡰ࡭ࡧࠪ♸")])
		for l1lllllll1l_l1_ in l1lllll11ll_l1_:
			l1111ll1ll_l1_ = l1lllllll1l_l1_.find_all(l1l111_l1_ (u"ࠧ࡭࡫ࠪ♹"))[1].text
			if PY2:
				l1111ll1ll_l1_ = l1111ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭♺"))
			l1111111ll_l1_.append(l1111ll1ll_l1_)
		if not l11111l_l1_(l1ll1_l1_,l1l111_l1_ (u"ࠩࠪ♻"),l1111111ll_l1_,False):
			l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ♼")).get(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭♽"))
			title = block.find(l1l111_l1_ (u"ࠬ࡮࠳ࠨ♾"))
			name = title.find(l1l111_l1_ (u"࠭ࡡࠨ♿")).text
			l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠧࡢࠩ⚀")).get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭⚁"))
			l1111l111l_l1_ = block.find(class_=l1l111_l1_ (u"ࠩࡱࡳ࠲ࡳࡡࡳࡩ࡬ࡲࠬ⚂"))
			l111111l11_l1_ = block.find(class_=l1l111_l1_ (u"ࠪࡰࡪ࡭ࡥ࡯ࡦࠪ⚃"))
			if l1111l111l_l1_: l1111l111l_l1_ = l1111l111l_l1_.text
			if l111111l11_l1_: l111111l11_l1_ = l111111l11_l1_.text
			if PY2:
				l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚄"))
				name = name.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚅"))
				l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚆"))
				if l1111l111l_l1_: l1111l111l_l1_ = l1111l111l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚇"))
			l1llllll111_l1_ = {}
			if l111111l11_l1_: l1llllll111_l1_[l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡹࠧ⚈")] = l111111l11_l1_
			if l1111l111l_l1_:
				l1111l111l_l1_ = l1111l111l_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ⚉"),l1l111_l1_ (u"ࠪࠤ࠳࠴ࠠࠨ⚊"))
				l1llllll111_l1_[l1l111_l1_ (u"ࠫࡵࡲ࡯ࡵࠩ⚋")] = l1111l111l_l1_.replace(l1l111_l1_ (u"ࠬ࠴࠮࠯ษๅีศࠦวๅ็ี๎ิ࠭⚌"),l1l111_l1_ (u"࠭ࠧ⚍"))
			if l1l111_l1_ (u"ࠧ࠰ࡹࡲࡶࡰ࠵ࠧ⚎") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚏"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠩࠪ⚐"),name,l1l111_l1_ (u"ࠪࠫ⚑"),l1llllll111_l1_)
			elif l1l111_l1_ (u"ࠫ࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⚒") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚓"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"࠭ࠧ⚔"),name,l1l111_l1_ (u"ࠧࠨ⚕"),l1llllll111_l1_)
	PAGINATION(l1lllll1l1l_l1_,512)
	return
def l1111ll11l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⚖"),url,l1l111_l1_ (u"ࠩࠪ⚗"),headers,l1l111_l1_ (u"ࠪࠫ⚘"),l1l111_l1_ (u"ࠫࠬ⚙"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠲࠮࠳ࡶࡸࠬ⚚"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ⚛"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1l1l_l1_.find_all(l1l111_l1_ (u"ࠧ࡭࡫ࠪ⚜"))
	names,items = [],[]
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠱ࡼࡸࡡࡱࡲࡨࡶࠬ⚝")): continue
		if not block.find(class_=[l1l111_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠫ⚞"),l1l111_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠥࡺࡥࡹࡶ࠰ࡧࡪࡴࡴࡦࡴࠪ⚟")]): continue
		if block.find(class_=l1l111_l1_ (u"ࠫ࡭࡯ࡤࡦࠩ⚠")): continue
		title = block.find(class_=[l1l111_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠧ⚡"),l1l111_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠡࡶࡨࡼࡹ࠳ࡣࡦࡰࡷࡩࡷ࠭⚢")])
		name = title.find(l1l111_l1_ (u"ࠧࡢࠩ⚣")).text
		if name in names: continue
		names.append(name)
		l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠨࡣࠪ⚤")).get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ⚥"))
		if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡼࡵࡲ࡬࠱ࠪ⚦") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠨ⚧")).get(l1l111_l1_ (u"ࠬࡹࡲࡤࠩ⚨"))
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⚩") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ⚪")).get(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ⚫"))
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ⚬") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ⚭")).get(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭⚮"))
		else: l11l_l1_ = block.find(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠩ⚯")).get(l1l111_l1_ (u"࠭ࡳࡳࡥࠪ⚰"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚱"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚲"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚳"))
		name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ⚴"))
		items.append((name,l1ll1ll_l1_,l11l_l1_))
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⚵") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1ll1ll_l1_,l11l_l1_ in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⚶") in url: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⚷"),l1lllll_l1_+name,l1ll1ll_l1_,522,l11l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⚸") in url: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚹"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠩࠪ⚺"),name)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚻"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠫࠬ⚼"),name)
	return
def l11111l1l1_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠬอไฦ฻็ห๋࠭⚽"),l1l111_l1_ (u"࠭ࠧ⚾")).replace(l1l111_l1_ (u"ࠧๅใํ่๊࠭⚿"),l1l111_l1_ (u"ࠨࠩ⛀")).replace(l1l111_l1_ (u"ࠩส่ึูๅ๋ࠩ⛁"),l1l111_l1_ (u"ࠪࠫ⛂"))
	text = text.replace(l1l111_l1_ (u"ࠫส฿ไศ่ࠪ⛃"),l1l111_l1_ (u"ࠬ࠭⛄")).replace(l1l111_l1_ (u"࠭แ๋ๆ่ࠫ⛅"),l1l111_l1_ (u"ࠧࠨ⛆")).replace(l1l111_l1_ (u"ࠨษ็ฬึ๎ๅ้ࠩ⛇"),l1l111_l1_ (u"ࠩࠪ⛈"))
	text = text.replace(l1l111_l1_ (u"ࠪห้ะิ้์ๅ๎ࠬ⛉"),l1l111_l1_ (u"ࠫࠬ⛊")).replace(l1l111_l1_ (u"๊ࠬๅิๆึ่ࠬ⛋"),l1l111_l1_ (u"࠭ࠧ⛌")).replace(l1l111_l1_ (u"ࠧๆี็ื้࠭⛍"),l1l111_l1_ (u"ࠨࠩ⛎"))
	text = text.replace(l1l111_l1_ (u"ࠩ࠽ࠫ⛏"),l1l111_l1_ (u"ࠪࠫ⛐")).replace(l1l111_l1_ (u"ࠫ࠮࠭⛑"),l1l111_l1_ (u"ࠬ࠭⛒")).replace(l1l111_l1_ (u"࠭ࠨࠨ⛓"),l1l111_l1_ (u"ࠧࠨ⛔")).replace(l1l111_l1_ (u"ࠨ࠮ࠪ⛕"),l1l111_l1_ (u"ࠩࠪ⛖"))
	text = text.replace(l1l111_l1_ (u"ࠪࡣࠬ⛗"),l1l111_l1_ (u"ࠫࠬ⛘")).replace(l1l111_l1_ (u"ࠬࡁࠧ⛙"),l1l111_l1_ (u"࠭ࠧ⛚")).replace(l1l111_l1_ (u"ࠧ࠮ࠩ⛛"),l1l111_l1_ (u"ࠨࠩ⛜")).replace(l1l111_l1_ (u"ࠩ࠱ࠫ⛝"),l1l111_l1_ (u"ࠪࠫ⛞"))
	text = text.replace(l1l111_l1_ (u"ࠫࡡ࠭ࠧ⛟"),l1l111_l1_ (u"ࠬ࠭⛠")).replace(l1l111_l1_ (u"࠭࡜ࠣࠩ⛡"),l1l111_l1_ (u"ࠧࠨ⛢"))
	text = text.replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭⛣"),l1l111_l1_ (u"ࠩࠣࠫ⛤")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ⛥"),l1l111_l1_ (u"ࠫࠥ࠭⛦")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ⛧"),l1l111_l1_ (u"࠭ࠠࠨ⛨"))
	text = text.strip(l1l111_l1_ (u"ࠧࠡࠩ⛩"))
	l1111l1l11_l1_ = text.count(l1l111_l1_ (u"ࠨࠢࠪ⛪"))+1
	if l1111l1l11_l1_==1:
		l1lllllll11_l1_(text)
		return
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⛫"),l1lllll_l1_+l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࠣ็้๋วหࠢ็่อำหࠡ࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⛬"),l1l111_l1_ (u"ࠫࠬ⛭"),9999)
	l11111l111_l1_ = text.split(l1l111_l1_ (u"ࠬࠦࠧ⛮"))
	l1111l1ll1_l1_ = pow(2,l1111l1l11_l1_)
	l111l1111_l1_ = []
	def l111111lll_l1_(a,b):
		if a==l1l111_l1_ (u"࠭࠱ࠨ⛯"): return b
		return l1l111_l1_ (u"ࠧࠨ⛰")
	for l1l111lll1_l1_ in range(l1111l1ll1_l1_,0,-1):
		l11111lll1_l1_ = list(l1111l1l11_l1_*l1l111_l1_ (u"ࠨ࠲ࠪ⛱")+bin(l1l111lll1_l1_)[2:])[-l1111l1l11_l1_:]
		l11111lll1_l1_ = reversed(l11111lll1_l1_)
		result = map(l111111lll_l1_,l11111lll1_l1_,l11111l111_l1_)
		title = l1l111_l1_ (u"ࠩࠣࠫ⛲").join(filter(None,result))
		if PY2: l1lllllll_l1_ = title.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⛳"))
		else: l1lllllll_l1_ = title
		if len(l1lllllll_l1_)>2 and title not in l111l1111_l1_:
			l111l1111_l1_.append(title)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛴"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭⛵"),523,l1l111_l1_ (u"࠭ࠧ⛶"),l1l111_l1_ (u"ࠧࠨ⛷"),title)
	return
def l1lllllll11_l1_(l1111l1l1l_l1_):
	if PY2:
		l1111l1l1l_l1_ = l1111l1l1l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⛸"))
		import arabic_reshaper
		l1111l1l1l_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111l1l1l_l1_)
		l1111l1l1l_l1_ = bidi.algorithm.get_display(l1111l1l1l_l1_)
	import l1111l1111_l1_
	l1111l1l1l_l1_ = l1llll1_l1_(default=l1111l1l1l_l1_)
	l1111l1111_l1_.l1lll1_l1_(l1111l1l1l_l1_)
	return
def l1111l11l1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⛹"),url,l1l111_l1_ (u"ࠪࠫ⛺"),headers,l1l111_l1_ (u"ࠫࠬ⛻"),l1l111_l1_ (u"ࠬ࠭⛼"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡋࡑࡈࡊ࡞ࡅࡔࡡࡏࡍࡘ࡚ࡓ࠮࠳ࡶࡸࠬ⛽"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⛾"),multi_valued_attributes=None)
	block = l1lllll1l1l_l1_.find(class_=l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠳ࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࠢ࡯࡭ࡸࡺ࠭ࡵ࡫ࡷࡰࡪ࠭⛿"))
	l11l11_l1_ = block.find_all(l1l111_l1_ (u"ࠩࡤࠫ✀"))
	items = []
	for title in l11l11_l1_:
		name = title.text
		l1ll1ll_l1_ = l111l1_l1_+title.get(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ✁"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✂"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✃"))
		if l1l111_l1_ (u"࠭ࠣࠨ✄") not in l1ll1ll_l1_: items.append((name,l1ll1ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1ll1ll_l1_ = item
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✅"),l1lllll_l1_+name,l1ll1ll_l1_,518)
	return
def l1111l11ll_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ✆"),url,l1l111_l1_ (u"ࠩࠪ✇"),headers,l1l111_l1_ (u"ࠪࠫ✈"),l1l111_l1_ (u"ࠫࠬ✉"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ✊"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ✋"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1l1l_l1_.find(class_=l1l111_l1_ (u"ࠧࡦࡺࡳࡥࡳࡪࠧ✌")).find_all(l1l111_l1_ (u"ࠨࡶࡵࠫ✍"))
	for block in l1lll1l1_l1_:
		l11111l11l_l1_ = block.find_all(l1l111_l1_ (u"ࠩࡤࠫ✎"))
		if not l11111l11l_l1_: continue
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ✏")).get(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭✐"))
		name = l11111l11l_l1_[1].text
		l1ll1ll_l1_ = l111l1_l1_+l11111l11l_l1_[1].get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ✑"))
		l111111l11_l1_ = block.find(class_=l1l111_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭✒"))
		if l111111l11_l1_: l111111l11_l1_ = l111111l11_l1_.text
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✓"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✔"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✕"))
		l1llllll111_l1_ = {}
		if l111111l11_l1_: l1llllll111_l1_[l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩ✖")] = l111111l11_l1_
		if l1l111_l1_ (u"ࠫ࠴ࡽ࡯ࡳ࡭࠲ࠫ✗") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✘"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"࠭ࠧ✙"),name,l1l111_l1_ (u"ࠧࠨ✚"),l1llllll111_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ✛") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✜"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠪࠫ✝"),name,l1l111_l1_ (u"ࠫࠬ✞"),l1llllll111_l1_)
	PAGINATION(l1lllll1l1l_l1_,518)
	return
def l11111ll1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ✟"),url,l1l111_l1_ (u"࠭ࠧ✠"),headers,l1l111_l1_ (u"ࠧࠨ✡"),l1l111_l1_ (u"ࠨࠩ✢"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡛ࡏࡄࡆࡑࡖࡣࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ✣"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ✤"),multi_valued_attributes=None)
	l11l11_l1_ = l1lllll1l1l_l1_.find_all(class_=l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡺࡩࡵ࡮ࡨࠤ࡮ࡴ࡬ࡪࡰࡨࠫ✥"))
	l1ll_l1_ = l1lllll1l1l_l1_.find_all(class_=l1l111_l1_ (u"ࠬࡨࡵࡵࡶࡲࡲࠥ࡭ࡲࡦࡧࡱࠤࡸࡳࡡ࡭࡮ࠣࡶ࡮࡭ࡨࡵࠩ✦"))
	items = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in items:
		title = title.text
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.get(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ✧"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✨"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✩"))
		title = title.replace(l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ✪"),l1l111_l1_ (u"ࠪࠤࠬ✫")).replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠨ✬"),l1l111_l1_ (u"ࠬࠦࠧ✭")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ✮"),l1l111_l1_ (u"ࠧࠡࠩ✯"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✰"),l1lllll_l1_+title,l1ll1ll_l1_,521)
	return
def l1lllll1ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭✱"),url,l1l111_l1_ (u"ࠪࠫ✲"),headers,l1l111_l1_ (u"ࠫࠬ✳"),l1l111_l1_ (u"ࠬ࠭✴"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡘࡌࡈࡊࡕࡓࡠࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ✵"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ✶"),multi_valued_attributes=None)
	l1111lll11_l1_ = l1lllll1l1l_l1_.find(class_=l1l111_l1_ (u"ࠨ࡮ࡤࡶ࡬࡫࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠹ࠦ࡭ࡦࡦ࡬ࡹࡲ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠸ࠥࡹ࡭ࡢ࡮࡯࠱ࡧࡲ࡯ࡤ࡭࠰࡫ࡷ࡯ࡤ࠮࠴ࠪ✷"))
	l1lll1l1_l1_ = l1111lll11_l1_.find_all(l1l111_l1_ (u"ࠩ࡯࡭ࠬ✸"))
	for block in l1lll1l1_l1_:
		title = block.find(class_=l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ✹")).text
		l1ll1ll_l1_ = l111l1_l1_+block.find(l1l111_l1_ (u"ࠫࡦ࠭✺")).get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ✻"))
		l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ✼")).get(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ✽"))
		l1l1lll111_l1_ = block.find(class_=l1l111_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ✾")).text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✿"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ❀"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ❁"))
			l1l1lll111_l1_ = l1l1lll111_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ❂"))
		l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ❃"),l1l111_l1_ (u"ࠧࠨ❄")).strip(l1l111_l1_ (u"ࠨࠢࠪ❅"))
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ❆"),l1lllll_l1_+title,l1ll1ll_l1_,522,l11l_l1_,l1l1lll111_l1_)
	PAGINATION(l1lllll1l1l_l1_,521)
	return
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ❇"),url,l1l111_l1_ (u"ࠫࠬ❈"),headers,l1l111_l1_ (u"ࠬ࠭❉"),l1l111_l1_ (u"࠭ࠧ❊"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ❋"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭❌"),multi_valued_attributes=None)
	l1ll1ll_l1_ = l1lllll1l1l_l1_.find(class_=l1l111_l1_ (u"ࠩࡩࡰࡪࡾ࠭ࡷ࡫ࡧࡩࡴ࠭❍")).find(l1l111_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪ❎")).get(l1l111_l1_ (u"ࠫࡸࡸࡣࠨ❏"))
	if PY2: l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ❐"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ❑"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ❒"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ❓"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ❔"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ❕"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡅࡱ࠾ࠩ❖")+search
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ❗"),url,l1l111_l1_ (u"࠭ࠧ❘"),headers,l1l111_l1_ (u"ࠧࠨ❙"),l1l111_l1_ (u"ࠨࠩ❚"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ❛"))
	html = response.content
	l1lllll1l1l_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ❜"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1l1l_l1_.find_all(class_=l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡺࡩࡵ࡮ࡨࠤࡱ࡫ࡦࡵࠩ❝"))
	for block in l1lll1l1_l1_:
		title = block.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ❞"))
		title = title.split(l1l111_l1_ (u"࠭ࠨࠨ❟"),1)[0].strip(l1l111_l1_ (u"ࠧࠡࠩ❠"))
		if   l1l111_l1_ (u"ࠨล฼้ฬ๊ࠧ❡") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ❢"),l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡼࡵࡲ࡬࠱ࠪ❣"))
		elif l1l111_l1_ (u"ࠫศฺฮศืࠪ❤") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ❥"),l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ❦"))
		elif l1l111_l1_ (u"ࠧโ์า๎ํํวหࠩ❧") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ❨"),l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ❩"))
		else: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❪"),l1lllll_l1_+title,l1ll1ll_l1_,513)
	return
def l1llllll11l_l1_(url,text):
	global l1l11111_l1_,l1l11lll_l1_
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ❫") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ❬"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ❭"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ❮")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ❯"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ❰"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ❱")]
	elif l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ❲") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ❳"),l1l111_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ❴"),l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ❵")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ❶"),l1l111_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ❷"),l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ❸")]
	l1l1ll1l_l1_(url,text)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ❹"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ❺"),url,l1l111_l1_ (u"࠭ࠧ❻"),headers,l1l111_l1_ (u"ࠧࠨ❼"),l1l111_l1_ (u"ࠨࠩ❽"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭❾"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࠡࡣࡦࡸ࡮ࡵ࡮࠾ࠤ࠲ࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ❿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ➀"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭➁"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ➂"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ➃"))
	url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ➄"),l1l111_l1_ (u"ࠩ࠲ࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠫ࠭➅"))
	return url
def l11l11llll_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ➆"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ➇")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠬࡅࠧ➈") in url: url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ➉"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ➊"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ➋"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ➌"),l1l111_l1_ (u"ࠪࠫ➍")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ➎"))
	if type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ➏"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨ➐") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩ➑") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ➒")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ➓")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ➔")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ➕")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ➖"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ➗")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ➘"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ➙"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭➚")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭➛"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭➜"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭➝"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ➞"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨ➟"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ➠")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➡"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭➢"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➣"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ➤")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ➥"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ➦"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➧"),l1l111_l1_ (u"ࠩࠪ➨"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠪ࠱࠲࠭➩"),l1l111_l1_ (u"ࠫࠬ➪"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠬࡃࠧ➫") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ➬"):
			if l1l111ll_l1_ not in l1l11111_l1_: continue
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1111ll1l1_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭➭")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➮"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ➯"),l1lllll1_l1_,511)
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➰"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ➱"),l1lllll1_l1_,515,l1l111_l1_ (u"ࠬ࠭➲"),l1l111_l1_ (u"࠭ࠧ➳"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ➴"):
			if l1l111ll_l1_ not in l1l11lll_l1_: continue
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ➵")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ➶")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ➷")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ➸")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ➹")+l1l1ll11_l1_
			if   name==l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ➺"): name = l1l111_l1_ (u"ࠧศๆ้์฾࠭➻")
			elif name==l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ➼"): name = l1l111_l1_ (u"ࠩส่฾๋ไࠨ➽")
			elif name==l1l111_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ➾"): name = l1l111_l1_ (u"ࠫฬ๊ไ฻หࠪ➿")
			elif name==l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ⟀"): name = l1l111_l1_ (u"࠭วๅี้อࠬ⟁")
			elif name==l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ⟂"): name = l1l111_l1_ (u"ࠨษ็้ํูๅࠨ⟃")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⟄"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻࠽ࠤࠬ⟅")+name,l1lllll1_l1_,514,l1l111_l1_ (u"ࠫࠬ⟆"),l1l111_l1_ (u"ࠬ࠭⟇"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"࠭ๅึ่ไหฯࠦรฯำ์ࠫ⟈") in option: continue
			if l1l111_l1_ (u"ࠧศๆๆ่ࠬ⟉") in option: continue
			if l1l111_l1_ (u"ࠨษ็่฿ฯࠧ⟊") in option: continue
			option = option.replace(l1l111_l1_ (u"ࠩๅหห๋ษࠡࠩ⟋"),l1l111_l1_ (u"ࠪࠫ⟌"))
			if   name==l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ⟍"): name = l1l111_l1_ (u"ࠬอไ็๊฼ࠫ⟎")
			elif name==l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⟏"): name = l1l111_l1_ (u"ࠧศๆ฼้้࠭⟐")
			elif name==l1l111_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⟑"): name = l1l111_l1_ (u"ࠩส่้เษࠨ⟒")
			elif name==l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨ⟓"): name = l1l111_l1_ (u"ࠫฬ๊ำ็หࠪ⟔")
			elif name==l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ⟕"): name = l1l111_l1_ (u"࠭วๅ็๋ื๊࠭⟖")
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ⟗")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ⟘")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ⟙")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ⟚")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ⟛")+l1l1ll11_l1_
			if name: title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨ⟜")+name
			else: title = option
			if type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⟝"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟞"),l1lllll_l1_+title,url,514,l1l111_l1_ (u"ࠨࠩ⟟"),l1l111_l1_ (u"ࠩࠪ⟠"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⟡") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠫࡂ࠭⟢") in l11lll1l_l1_:
				l1llllll_l1_ = l11l11llll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟣"),l1lllll_l1_+title,l1llllll_l1_,511)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟤"),l1lllll_l1_+title,url,515,l1l111_l1_ (u"ࠧࠨ⟥"),l1l111_l1_ (u"ࠨࠩ⟦"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬ⟧"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧ⟨"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭⟩"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧ⟪") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨ⟫"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ⟬"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩ⟭")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫ⟮")
		if l1l111_l1_ (u"ࠪࠩࠬ⟯") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⟰") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ⟱"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ⟲")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⟳") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ⟴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ⟵")+key+l1l111_l1_ (u"ࠪࡁࠬ⟶")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⟷"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ⟸")+key+l1l111_l1_ (u"࠭࠽ࠨ⟹")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ⟺"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ⟻"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠩࡀ࠴ࠬ⟼"),l1l111_l1_ (u"ࠪࡁࠬ⟽"))
	return l1l1l111_l1_
l1l11111_l1_ = []
l1l11lll_l1_ = []
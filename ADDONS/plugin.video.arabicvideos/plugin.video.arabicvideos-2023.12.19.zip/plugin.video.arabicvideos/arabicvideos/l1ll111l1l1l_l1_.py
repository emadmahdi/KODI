# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ妚")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭妛")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠨ妜"),l1l111_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ妝")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ妞"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ妟"),l1l111_l1_ (u"ࠬ࠭妠"),l1l111_l1_ (u"࠭ࠧ妡"),l1l111_l1_ (u"ࠧࠨ妢"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ妣"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ妤"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬ妥"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ妦"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妧"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭妨"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠧࠨ妩"),l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭妫"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ妬"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ妭"),l1l111_l1_ (u"ࠬ࠭妮"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妯"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ妰")+l1lllll_l1_+l1l111_l1_ (u"ࠨละำะࠦวๅ็๋ห฻๐ูࠨ妱"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨ࡭ࡺࡃࡦࡧࡴࡻ࡮ࡵࠤࠪ妲"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ妳"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭妴"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妵"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ妶")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l111llll1ll1_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ妷"),url,l1l111_l1_ (u"ࠨࠩ妸"),l1l111_l1_ (u"ࠩࠪ妹"),l1l111_l1_ (u"ࠪࠫ妺"),l1l111_l1_ (u"ࠫࠬ妻"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ妼"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡱࡶࡸ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ妽"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭妾"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ妿"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ姀"),l1l111_l1_ (u"ࠪห฿์๊สࠩ姁"),l1l111_l1_ (u"ࠫศเๆ๋หࠪ姂"),l1l111_l1_ (u"้ࠬไ๋สࠪ姃"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ姄"),l1l111_l1_ (u"่ࠧัสๅࠬ姅"),l1l111_l1_ (u"ࠨ็หหึอษࠨ姆"),l1l111_l1_ (u"ࠩ฼ี฻࠭姇"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ姈"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ姉"),l1l111_l1_ (u"๋ࠬำาฯํอࠬ姊")]
	l111llll1lll_l1_ = l1l111_l1_ (u"࠭࠯ࠨ始").join(l111llll1ll1_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ姌")).split(l1l111_l1_ (u"ࠨ࠱ࠪ姍"))[4:]).split(l1l111_l1_ (u"ࠩ࠰ࠫ姎"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ姏"),title,re.DOTALL)
		if l111llll1ll1_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠫ࠴࠭姐").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ姑")).split(l1l111_l1_ (u"࠭࠯ࠨ姒"))[4:]).split(l1l111_l1_ (u"ࠧ࠮ࠩ姓"))
			l111lllll111_l1_ = len([x for x in l111llll1lll_l1_ if x in l111lllll_l1_])
			if l111lllll111_l1_>2 and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ委") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ姕"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭姖"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ู๊ࠫไิๆࠪ姗") not in title:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姘"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ姙") in title:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭姚") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姛"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ姜"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姝"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ姞"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠣ姟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ姠"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨ姡"),l1l111_l1_ (u"ࠨࠩ姢"))
			if title!=l1l111_l1_ (u"ࠩࠪ姣"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姤"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ姥")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠬ࠭姦"),l1l111_l1_ (u"࠭ࠧ姧"),l111llll1ll1_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ姨"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ姩")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭姪"),url,l1l111_l1_ (u"ࠪࠫ姫"),headers,l1l111_l1_ (u"ࠫࠬ姬"),l1l111_l1_ (u"ࠬ࠭姭"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ姮"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ姯"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ姰"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ姱"))
	l111llll1l1l_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵࡕࡨࡥࡸࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ姲"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ姳") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠩ姴"))
		if count==0: count = block.count(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠬ姵"))
		if count>1:
			l111llll1l1l_l1_ = False
			if l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦࠬ姶") in block:
				items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ姷"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠶࠳ࡶࡨࡱࡁࡶࡰࡺ࡭࠽ࠨ姸")+id
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姹"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ姺"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠮ࡱࡪࡳࡃࡸ࡫ࡲࡪࡧࡶࡍࡉࡃࠧ姻")+id
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姼"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l111llll1l1l_l1_:
		block = l1l111_l1_ (u"ࠧࠨ姽")
		if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ姾") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ姿"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ娀"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭威"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ娂"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ娃"))+l1l111_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡽࡡࡵࡥ࡫ࠫ娄")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ娅"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ娆"),l1l111_l1_ (u"ࠪࠫ娇"),l1l111_l1_ (u"ࠫࠬ娈"),l1l111_l1_ (u"ࠬ࠭娉"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ娊"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ娋"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡲࡣࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ娌"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࠬࡹ࡮ࡩࡴ࡞࠱࡭ࡩࡢࠬ࠱࡞࠯ࠬ࠳࠰࠿ࠪ࡞ࠬࠫ娍"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭娎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ娏"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ娐"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡪࡨࡵࡥࡲ࡫࠲࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ娑")+l11111l11_l1_+l1l111_l1_ (u"ࠧࠧࡸ࡬ࡨࡪࡵ࠽ࠨ娒")+l111111ll_l1_[2:]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ娓")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ娔")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡬࡫ࡴࡆ࡯ࡥࡩࡩࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ娕"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ娖"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭娗")+title+l1l111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ娘")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ娙"))+l1l111_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡤࡰࡹࡱࡰࡴࡧࡤࠨ娚")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭娛"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ娜"),l1l111_l1_ (u"ࠫࠬ娝"),l1l111_l1_ (u"ࠬ࠭娞"),l1l111_l1_ (u"࠭ࠧ娟"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ娠"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡷࡥࡧࡲࡥ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ娡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ娢"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ娣"))
			if l1l111_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ娤") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ฯษุࠫ娥")
			else: l1lllllll_l1_ = l1l111_l1_ (u"࠭ࠧ娦")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ娧")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ娨")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ娩"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠪࠫ娪")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ娫"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭娬"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ娭"),l1l111_l1_ (u"ࠧࠬࠩ娮"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠨࠩ娯"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ娰")+search+l1l111_l1_ (u"ࠪ࠳ࠬ娱")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࠬ娲"))
	return
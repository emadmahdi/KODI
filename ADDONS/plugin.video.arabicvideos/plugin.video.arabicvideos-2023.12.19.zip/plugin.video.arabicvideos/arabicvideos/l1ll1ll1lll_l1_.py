# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ⶄ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡈࡍࡅࡢࠫⶅ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅึษิ฽ฮ࠭ⶆ"),l1l111_l1_ (u"ࠧศฯาฯࠥอไษำส้ั࠭ⶇ"),l1l111_l1_ (u"ࠨษะำะࠦวๅษ็฽ฬฮࠧⶈ"),l1l111_l1_ (u"ࠩสัิัࠠศๆส฾ฬ์้ࠨⶉ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==80: l1lll_l1_ = l1l1l11_l1_()
	elif mode==81: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==82: l1lll_l1_ = PLAY(url)
	elif mode==83: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==89: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧⶊ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬⶋ"),l1l111_l1_ (u"ࠬ࠭ⶌ"),l1l111_l1_ (u"࠭ࠧⶍ"),l1l111_l1_ (u"ࠧࠨⶎ"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬⶏ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ⶐ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶑ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫⶒ"),l1l111_l1_ (u"ࠬ࠭ⶓ"),89,l1l111_l1_ (u"࠭ࠧⶔ"),l1l111_l1_ (u"ࠧࠨⶕ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬⶖ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⶗"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⶘"),l1l111_l1_ (u"ࠫࠬ⶙"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⶚"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⶛"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭⶜")+l111l1l1l_l1_+l1l111_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ⶝")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⶞"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⶟")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⶠ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⶡ"),l1l111_l1_ (u"࠭ࠧⶢ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨⶣ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶤ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫⶥ"): continue
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶦ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⶧")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠬ࠭ⶨ")):
	items = []
	if l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ⶩ") in url or l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨⶪ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧⶫ"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩⶬ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨⶭ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬⶮ"),l1l111_l1_ (u"ࠬ࠭⶯"),l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬⶰ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⶱ"),url,l1l111_l1_ (u"ࠨࠩⶲ"),l1l111_l1_ (u"ࠩࠪⶳ"),l1l111_l1_ (u"ࠪࠫⶴ"),l1l111_l1_ (u"ࠫࠬⶵ"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫⶶ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⶷"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧⶸ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⶹ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠩⶺ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬⶻ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩⶼ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡴࡸࡩࡨ࡫ࡱࡥࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⶽ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⶾ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ⶿"),l1l111_l1_ (u"ࠨใํ่๊࠭ⷀ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨⷁ"),l1l111_l1_ (u"ࠪ็้๐ศࠨⷂ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪⷃ"),l1l111_l1_ (u"ࠬํฯศใࠪⷄ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ⷅ"),l1l111_l1_ (u"ฺࠧำูࠫⷆ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ⷇"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨⷈ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬⷉ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧⷊ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧⷋ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷌ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧิๆสื้࠭ⷍ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⷎ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ⷏") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩⷐ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷑ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧⷒ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷓ"),l1lllll_l1_+title,l1ll1ll_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷔ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠨࠩⷕ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷ࠭ⷖ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⷗"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠦࠧⷘ"): continue
				if title!=l1l111_l1_ (u"ࠬ࠭ⷙ"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷚ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ⷛ")+title,l1ll1ll_l1_,81)
	if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨⷜ") in url or l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪⷝ") in url:
		if l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪⷞ") in url:
			url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ⷟"),l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ⷠ"))+l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽࠳࠲ࠪⷡ")
		elif l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨⷢ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪⷣ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫⷤ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷥ"),l1lllll_l1_+l1l111_l1_ (u"ࠫ์์วไࠢสุ่๊๊ะࠩⷦ"),url,81)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩⷧ"),url,l1l111_l1_ (u"࠭ࠧⷨ"),l1l111_l1_ (u"ࠧࠨⷩ"),l1l111_l1_ (u"ࠨࠩⷪ"),l1l111_l1_ (u"ࠩࠪⷫ"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫⷬ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡭ࡥࡵࡕࡨࡥࡸࡵ࡮ࡴࡄࡼࡗࡪࡸࡩࡦࡵࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬⷭ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡬ࡪࡵࡷ࠱ࡪࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩⷮ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨⷯ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⷰ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷱ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡲࡧࡧࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⷲ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⷳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⷴ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧⷵ"),l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧⷶ"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫⷷ"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫⷸ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ⷹ"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫⷺ"),l1l111_l1_ (u"ࠫࠬⷻ"),l1l111_l1_ (u"ࠬ࠭ⷼ"),l1l111_l1_ (u"࠭ࠧⷽ"),l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫⷾ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬⷿ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⸀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⸁"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠦ࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ⸂"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⸃"),l1l111_l1_ (u"࠭ࠧ⸄")).strip(l1l111_l1_ (u"ࠧࠡࠩ⸅"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡔࡱࡧࡹࡦࡴࡂࡷࡪࡸࡶࡦࡴࡀࠫ⸆")+server+l1l111_l1_ (u"ࠩࠩࡴࡴࡹࡴࡊࡆࡀࠫ⸇")+l11l1l11_l1_+l1l111_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫ⸈")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⸉")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⸊")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡱࡺࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⸋"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⸌"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⸍")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⸎")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⸏"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ⸐"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭⸑"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ⸒"),l1l111_l1_ (u"ࠧ࠮ࠩ⸓"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⸔")+search+l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ⸕")
	l1lll11_l1_(url)
	return
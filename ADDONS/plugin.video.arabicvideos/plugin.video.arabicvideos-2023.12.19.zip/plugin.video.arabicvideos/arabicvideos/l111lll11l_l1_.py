# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ΅")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡄ࠴ࡣࠬ`")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆๅอฬฯ๐ࠧ῰"),l1l111_l1_ (u"ࠨษํะ๏ࠦศิฬࠪ῱")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==770: l1lll_l1_ = l1l1l11_l1_()
	elif mode==771: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==772: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==773: l1lll_l1_ = PLAY(url)
	elif mode==774: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪῲ")+text)
	elif mode==775: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧῳ")+text)
	elif mode==776: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==779: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫῴ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ῵"),l1l111_l1_ (u"࠭ࠧῶ"),779,l1l111_l1_ (u"ࠧࠨῷ"),l1l111_l1_ (u"ࠨࠩῸ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ό"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨῺ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫΏ"),l1l111_l1_ (u"ࠬ࠭ῼ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ´"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ῾"),l1l111_l1_ (u"ࠨࠩ῿"),l1l111_l1_ (u"ࠩࠪ "),l1l111_l1_ (u"ࠪࠫ "),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ "))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡴࡡࡷ࠯࡯࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ "),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ "),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ "))
			if any(value in title for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ "),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ ")+l1lllll_l1_+title,l1ll1ll_l1_,771)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ "),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ "),l1l111_l1_ (u"ࠬ࠭ "),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࡶࡳࡨ࡯ࡡ࡭࠯ࡥࡳࡽ࠭​"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ‌"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ‍"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‎"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ‏")+l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠫࠬ‐"),l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡰࡩࡳࡻࠧ‑"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ‒"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ–"),l1l111_l1_ (u"ࠨࠩ—"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ―"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ‖"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭‗"))
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ‘"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ’")+l1lllll_l1_+title,l1ll1ll_l1_,771)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠧࠨ‚")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ‛"),url,l1l111_l1_ (u"ࠩࠪ“"),l1l111_l1_ (u"ࠪࠫ”"),l1l111_l1_ (u"ࠫࠬ„"),l1l111_l1_ (u"ࠬ࠭‟"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ†"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩ‡"),html,re.DOTALL)
	if l11llll_l1_:
		l111lll1l1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠨࠩ•"),l1l111_l1_ (u"ࠩࠪ‣"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠪั้่วหࠩ․") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๊ࠫ๎วิ็ࠪ‥") in name: l111lll1l1_l1_ = block
		if l111lll1l1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ…"),l111lll1l1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭‧"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ "))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ "),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ‪"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ‫"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ‬"),l1lllll_l1_+title,l1ll1ll_l1_,773)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭‭")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ‮"),url,l1l111_l1_ (u"ࠧࠨ "),l1l111_l1_ (u"ࠨࠩ‰"),l1l111_l1_ (u"ࠩࠪ‱"),l1l111_l1_ (u"ࠪࠫ′"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ″"))
	html = response.content
	items,l111lll1ll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ‴"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ‵"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ‶"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ‷"),l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠩࠪ‸"),l1l111_l1_ (u"ࠪࡷࡺࡨ࡭ࡦࡰࡸࠫ‹"))
				l111lll1ll_l1_ = True
	if not type and l1l111_l1_ (u"ࠫࡵࡃࠧ›") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬࡫ࡵࡲ࡮ࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ※"),html,re.DOTALL)
		if l11llll_l1_:
			if l111lll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ‼"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ‽"),l1l111_l1_ (u"ࠨࠩ‾"),9999)
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‿"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭⁀"),url,775,l1l111_l1_ (u"ࠫࠬ⁁"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⁂"))
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⁃"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ⁄"),url,774,l1l111_l1_ (u"ࠨࠩ⁅"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⁆"))
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⁇"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠨ⁈"),url,779)
			addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⁉"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⁊"),l1l111_l1_ (u"ࠧࠨ⁋"),9999)
			filters = True
	if not l111lll1ll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭⁌"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⁍"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠪࡠࡳ࠭⁎"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨ࠳ࠬ⁏") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⁐"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⁑"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⁒"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			l1llllll1_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ⁓")
			if l1l111_l1_ (u"ࠩࡳࡁࠬ⁔") in url: url,l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠪࡴࡂ࠭⁕"),1)
			conn = l1l111_l1_ (u"ࠫࠫ࠭⁖") if l1l111_l1_ (u"ࠬࡅࠧ⁗") in url else l1l111_l1_ (u"࠭࠿ࠨ⁘")
			url = url+conn
			url = url.replace(l1l111_l1_ (u"ࠧࡀࠨࠪ⁙"),l1l111_l1_ (u"ࠨࡁࠪ⁚"))
			if len(items)==40:
				url = url+l1l111_l1_ (u"ࠩࡳࡁࠬ⁛")+str(int(l1llllll1_l1_)+1)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⁜"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊สศๆํอࠬ⁝"),url,771)
			elif l1llllll1_l1_!=l1l111_l1_ (u"ࠬ࠷ࠧ⁞"):
				url = url+l1l111_l1_ (u"࠭ࡰ࠾ࠩ ")+str(int(l1llllll1_l1_)-1)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⁠"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ืฬฮโสࠩ⁡"),url,771)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⁢"),url,l1l111_l1_ (u"ࠪࠫ⁣"),l1l111_l1_ (u"ࠫࠬ⁤"),l1l111_l1_ (u"ࠬ࠭⁥"),l1l111_l1_ (u"࠭ࠧ⁦"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⁧"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡯ࡥࡧ࡫࡬࠿ษ็ฮฺ์๊โ࠾࠲ࡰࡦࡨࡥ࡭ࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⁨"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111lll111_l1_,l1ll11l1_l1_,l1111l1ll_l1_ = [],[],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡲ࡯ࡥࡾ࠳ࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⁩"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ⁪"))
	items = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡲࠡࡨ࡯ࡩࡽ࠳ࡳࡵࡣࡵࡸࠧ࠴ࠪࡀ࠾ࡧ࡭ࡻࡄ࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬࠫࡠࡩࢁ࠳࠭࠶ࢀ࠭ࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪ࠽࠱ࡧ࡭ࡻࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⁫"),html,re.DOTALL)
	for l111l1ll_l1_,l1ll1ll_l1_ in items:
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			l111l1ll_l1_ = l111l1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ⁬"))
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ⁭"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⁮")+server+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ⁯")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⁰"),url)
	return
def l1lll1_l1_(search,url=l1l111_l1_ (u"ࠪࠫⁱ")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭⁲"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ⁳"))
	if not url: url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲࡷࡨࡶࡾࡃࠧ⁴")+l1lll1ll_l1_
	else: url = url+l1l111_l1_ (u"ࠧࡀࡶ࡬ࡸࡱ࡫࠽ࠨ⁵")+l1lll1ll_l1_+l1l111_l1_ (u"ࠨࠨࡪࡩࡳࡸࡥ࠾ࠨࡼࡩࡦࡸ࠽ࠧ࡮ࡤࡲ࡬ࡃࠧ⁶")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ⁷"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⁸"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⁹"),url,l1l111_l1_ (u"ࠬ࠭⁺"),l1l111_l1_ (u"࠭ࠧ⁻"),l1l111_l1_ (u"ࠧࠨ⁼"),l1l111_l1_ (u"ࠨࠩ⁽"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭⁾"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪࡴࡸ࡭࠮ࡴࡲࡻ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪⁿ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫࡬ࡦࡥࡷࠤࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࠪ₀"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ₁"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ₂"),l1l111_l1_ (u"ࠧࡀࡶ࡬ࡸࡱ࡫࠽ࠧࠩ₃"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭₄"),l1l111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࠧ₅"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ₆")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ₇"),l1l111_l1_ (u"ࠬࡲࡡ࡯ࡩࠪ₈"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ₉")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ₊"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ₋"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ₌"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ₍"),l1l111_l1_ (u"ࠫࠬ₎")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ₏"))
	if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧₐ"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩₑ") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪₒ") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫₓ")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ₔ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ₕ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨₖ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨₗ"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫₘ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪₙ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡤࡰࡱ࠭ₚ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧₛ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩₜ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ₝"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ₞"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ₟")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ₠"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ₡"),l1llllll_l1_,771,l1l111_l1_ (u"ࠪࠫ₢"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ₣"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ₤"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭₥")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭₦"),l1llllll_l1_,771,l1l111_l1_ (u"ࠨࠩ₧"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ₨"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ₩"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ₪"),l1l111_l1_ (u"ࠬ࠭₫"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"࠭ใๅࠢࠪ€"),l1l111_l1_ (u"ࠧࠨ₭"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪ₮") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ₯"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ₰")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ₱"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭₲"),l1llllll_l1_,771,l1l111_l1_ (u"࠭ࠧ₳"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ₴"))
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ₵"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ₶"),l1lllll1_l1_,775,l1l111_l1_ (u"ࠪࠫ₷"),l1l111_l1_ (u"ࠫࠬ₸"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ₹"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ₺")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ₻")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ₼")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ₽")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ₾")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ₿"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ⃀")+name,l1lllll1_l1_,774,l1l111_l1_ (u"࠭ࠧ⃁"),l1l111_l1_ (u"ࠧࠨ⃂"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ⃃")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ⃄")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ⃅")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭⃆")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ⃇")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ⃈")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ⃉")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ⃊")+name
			if type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ⃋"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⃌"),l1lllll_l1_+title,url,774,l1l111_l1_ (u"ࠫࠬ⃍"),l1l111_l1_ (u"ࠬ࠭⃎"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⃏") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ⃐") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⃑"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ⃒࠭")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ⃓ࠪ"),l1lllll_l1_+title,l1llllll_l1_,771,l1l111_l1_ (u"ࠫࠬ⃔"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⃕"))
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⃖"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⃗"),l1lllll_l1_+title,url,775,l1l111_l1_ (u"ࠨ⃘ࠩ"),l1l111_l1_ (u"⃙ࠩࠪ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁ⃚ࠫ࠭"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨ⃛"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ⃜"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ⃝") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ⃞"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ⃟"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ⃠")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ⃡")
		if l1l111_l1_ (u"ࠫࠪ࠭⃢") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⃣") and value!=l1l111_l1_ (u"࠭࠰ࠨ⃤"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"⃥ࠧࠡ࠭ࠣࠫ")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶ⃦ࠫ") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ⃧"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"⃨ࠪࠪࠬ")+key+l1l111_l1_ (u"ࠫࡂ࠭⃩")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭⃪ࠩ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ⃫")+key+l1l111_l1_ (u"ࠧ࠾⃬ࠩ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤ⃭ࠬ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"⃮ࠩࠩࠫ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵⃯࠭"),l1l111_l1_ (u"ࠫࡂ࠭⃰"))
	return l1l1l111_l1_
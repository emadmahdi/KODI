# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ喷")
headers = l1l111_l1_ (u"࠭ࠧ喸")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭喹")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭喺"),l1l111_l1_ (u"ࠩส่่๊ࠧ喻"),l1l111_l1_ (u"ࠪหๆ๊วๆࠩ喼"),l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ喽"),l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ喾")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ喿")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ嗀")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll11l1_l1_(l111l1_l1_,l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ嗁"),l1l111_l1_ (u"ࠩืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤࠡ࠶ࡸࠫ嗂"),l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠲ࡳ࡫ࡴࠨ嗃"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗄"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ嗅"),l1l111_l1_ (u"࠭ࠧ嗆"),119,l1l111_l1_ (u"ࠧࠨ嗇"),l1l111_l1_ (u"ࠨࠩ嗈"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嗉"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗊"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ嗋"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嗌"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ嗍"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嗎"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嗏"),l1l111_l1_ (u"ࠩࠪ嗐"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗑"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ嗒"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠬ࠭嗓"),l1l111_l1_ (u"࠭ࠧ嗔"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ嗕"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥ࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠩ嗖"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ嗗"),l1l111_l1_ (u"ࠪࠫ嗘"),l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭嗙"),l1l111_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ嗚"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ嗛"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗜"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嗝")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ嗞"),filter)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ嗟"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嗠"),l1l111_l1_ (u"ࠬ࠭嗡"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ嗢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嗣"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ嗤"),l1l111_l1_ (u"ࠩࠪ嗥")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭嗦"),l1l111_l1_ (u"ࠫࠬ嗧")).strip(l1l111_l1_ (u"ࠬࠦࠧ嗨"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ嗩") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ嗪") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ嗫")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗬"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嗭")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ嗮"),response=l1l111_l1_ (u"ࠬ࠭嗯")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嗰"),url,l1l111_l1_ (u"ࠧࠨ嗱"),headers,l1l111_l1_ (u"ࠨࠩ嗲"),l1l111_l1_ (u"ࠩࠪ嗳"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ嗴"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭嗵"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡭࡬ࡪࡦࡨࡣࡤࡹ࡬ࡪࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嗶"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡩࡱࡺࡷ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠩ࠰࠭ࡃ࠮ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ嗷"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄࠧ嗸"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ嗹"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ嗺"),l1l111_l1_ (u"ࠪห฿์๊สࠩ嗻"),l1l111_l1_ (u"่๊๊ࠫษࠩ嗼"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ嗽"),l1l111_l1_ (u"࠭็ะษไࠫ嗾"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ嗿"),l1l111_l1_ (u"ࠨ฻ิฺࠬ嘀"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ嘁"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ嘂")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ嘃") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧ嘄"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ嘅"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ嘆"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ嘇") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩไ๎้๋ࠧ嘈") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嘉"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ嘊") in title and l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嘋") not in url:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ嘌") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘍"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲ࠰ࠩ嘎") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘏"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ嘐") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嘑") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嘒")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘓"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭嘔") in url and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭嘕") in title:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嘖"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘗"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嘘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嘙"): items = re.findall(l1l111_l1_ (u"࠭ࠨࡶࡲࡧࡥࡹ࡫ࡑࡶࡧࡵࡽ࠮࠴ࠪࡀࡀࠫ࠲࠰ࡅࠩ࠽ࠩ嘚"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠧ࠽࡮࡬ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嘛"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嘜"):
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ嘝"),l1l111_l1_ (u"ࠪࠫ嘞")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ嘟"),l1l111_l1_ (u"ࠬ࠭嘠"))
				if l1l111_l1_ (u"࠭࠿ࠨ嘡") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ嘢")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨࡁࡳࡥ࡬࡫࠽ࠨ嘣")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘤"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ嘥")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠫࠬ嘦"),l1l111_l1_ (u"ࠬ࠭嘧"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1111l111_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘨"),url,l1l111_l1_ (u"ࠧࠨ嘩"),headers,l1l111_l1_ (u"ࠨࠩ嘪"),l1l111_l1_ (u"ࠩࠪ嘫"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ嘬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠣࡨ࠲࡬࡬ࡦࡺࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嘭"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ嘮") in l11llll_l1_[0]: l111lll1l1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111lll1l1_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111lll1l1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111lll1_l1_ in range(2):
		if l11l1111l111_l1_: mode,type,block = 116,l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘯"),l111lll1l1_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嘰"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嘱"),block,re.DOTALL)
		if l11l1111l111_l1_ and len(items)<2:
			l11l1111l111_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠩࠣࠫ嘲")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠭嘳") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡸࡥࡢࡦࡦࡶࡺࡳࡢࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嘴"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嘵"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ嘶")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嘷"),url,l1l111_l1_ (u"ࠨࠩ嘸"),headers,l1l111_l1_ (u"ࠩࠪ嘹"),l1l111_l1_ (u"ࠪࠫ嘺"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ嘻"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡧࡣࡵ࡫ࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嘼"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嘽"),block,re.DOTALL)
	l11l1111l11l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ嘾") in block
	download = l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ嘿") in block
	if   l11l1111l11l_l1_ and not download: l11l1111l1l1_l1_,l11l11111lll_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠩࠪ噀")
	elif not l11l1111l11l_l1_ and download: l11l1111l1l1_l1_,l11l11111lll_l1_ = l1l111_l1_ (u"ࠪࠫ噁"),l1ll_l1_[0]
	elif l11l1111l11l_l1_ and download: l11l1111l1l1_l1_,l11l11111lll_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l1111l1l1_l1_,l11l11111lll_l1_ = l1l111_l1_ (u"ࠫࠬ噂"),l1l111_l1_ (u"ࠬ࠭噃")
	if l11l1111l11l_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ噄"),l11l1111l1l1_l1_,l1l111_l1_ (u"ࠧࠨ噅"),headers,l1l111_l1_ (u"ࠨࠩ噆"),l1l111_l1_ (u"ࠩࠪ噇"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ噈"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡱ࡫ࡴࠡࡵࡨࡶࡻ࡫ࡲࡴࠪ࠱࠮ࡄ࠯ࡰ࡭ࡣࡼࡩࡷ࠭噉"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ噊"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ噋"),l1l111_l1_ (u"ࠧ࠰ࠩ噌"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ噍")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ噎")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ噏"),l11l11111lll_l1_,l1l111_l1_ (u"ࠫࠬ噐"),headers,l1l111_l1_ (u"ࠬ࠭噑"),l1l111_l1_ (u"࠭ࠧ噒"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ噓"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࡫ࡱࡪࡴ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ噔"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噕"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ噖")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ噗")+l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ噘")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ噙"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ噚"),l1l111_l1_ (u"ࠨ࠭ࠪ噛"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭噜")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll11l1_l1_(url,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ噝"),l1l111_l1_ (u"ูࠫอ็ะࠢไ์ึ๐่ࠡ࠯ࠣࡗ࡭ࡧࡨࡪࡦࠣ࠸ࡺ࠭噞"),l1l111_l1_ (u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠴࡮ࡦࡶࠪ噟"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭噠"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ噡"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ噢"),url,l1l111_l1_ (u"ࠩࠪ噣"),headers,l1l111_l1_ (u"ࠪࠫ噤"),l1l111_l1_ (u"ࠫࠬ噥"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ噦"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ噧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡑࡶࡧࡵࡽࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࠬ器"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂࡡࡹࠪࠩ࠰࠭ࡃ࠮ࡢࡳࠫ࠾ࠪ噩"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭噪") not in url: url = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ噫")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ噬"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ噭"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ噮"),l1l111_l1_ (u"ࠧ࠰ࡁࠪ噯"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ噰"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ噱"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ噲"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭噳")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ噴"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ噵"),l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ噶")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ噷"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭噸"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ噹"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ噺"),l1l111_l1_ (u"ࠬ࠭噻")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ噼"))
	if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ噽"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪ噾") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫ噿") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚀")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ嚁")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ嚂")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ嚃")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ嚄"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ嚅")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ嚆"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嚇"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ嚈")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ嚉"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ嚊"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ嚋"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嚌"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ嚍"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚎")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚏"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ嚐"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚑"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ嚒")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ嚓"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ嚔"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嚕"),l1l111_l1_ (u"ࠫࠬ嚖"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"้ࠬไࠡࠩ嚗"),l1l111_l1_ (u"࠭ࠧ嚘"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠧ࠾ࠩ嚙") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ嚚"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭嚛")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚜"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ嚝"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚞"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ嚟"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠧࠨ嚠"),l1l111_l1_ (u"ࠨࠩ嚡"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ嚢"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚣")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ嚤")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ嚥")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ嚦")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嚧")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚨"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ嚩")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠪࠫ嚪"),l1l111_l1_ (u"ࠫࠬ嚫"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬ嚬"): option = l1l111_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭嚭")
			elif value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧ嚮"): option = l1l111_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪ嚯")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ嚰")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ嚱")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭嚲")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ嚳")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嚴")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ嚵")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪ嚶")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ嚷")+name
			if type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ嚸"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚹"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠬ࠭嚺"),l1l111_l1_ (u"࠭ࠧ嚻"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ嚼") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ嚽") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ嚾"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚿")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囀"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ囁"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"࠭ࠧ囂"),l1l111_l1_ (u"ࠧࠨ囃"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫ囄"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭囅"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬ囆"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭囇") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧ囈"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨ囉"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨ囊")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ囋")
		if l1l111_l1_ (u"ࠩࠨࠫ囌") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ囍") and value!=l1l111_l1_ (u"ࠫ࠵࠭囎"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ囏")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ囐") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ囑"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ囒")+key+l1l111_l1_ (u"ࠩࡀࠫ囓")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧ囔"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭囕")+key+l1l111_l1_ (u"ࠬࡃࠧ囖")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ囗"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ囘"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫ囙"),l1l111_l1_ (u"ࠩࡀࠫ囚"))
	return l1l1l111_l1_
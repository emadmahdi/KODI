# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙ࠫ㮒")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㮓")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠰ࠨ㮔"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠲ࠩ㮕"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠨ࠴ࠪ㮖"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠩ࠶ࠫ㮗"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠸ࠬ㮘"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮙"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ㮚")+l1l111_l1_ (u"࠭โ้ษษ้ࠥ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠫ㮛"),l1l111_l1_ (u"ࠧࠨ㮜"),762)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮝"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ㮞")+l1l111_l1_ (u"ࠪๆํอฦๆࠢไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠩ㮟"),l1l111_l1_ (u"ࠫࠬ㮠"),761)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮡"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠳ࡣࠬ㮢")+l1l111_l1_ (u"ࠧใ่๋หฯࠦๅ็่ࠢ์ฬู่่ษࠣห้ษีๅ์ฬࠫ㮣"),l1l111_l1_ (u"ࠨࠩ㮤"),101)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮥"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠴ࡠࠩ㮦")+l1l111_l1_ (u"ࠫ็์่ศฬ้ࠣำะวาห้๋๊้ࠣࠦฬํ์อ࠭㮧"),l1l111_l1_ (u"ࠬ࠭㮨"),106)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮩"),l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㮪")+l1l111_l1_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㮫"),l1l111_l1_ (u"ࠩࠪ㮬"),147)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮭"),l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㮮")+l1l111_l1_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㮯"),l1l111_l1_ (u"࠭ࠧ㮰"),148)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮱"),l1l111_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ㮲")+l1l111_l1_ (u"ࠩࠣࠤ็์วสࠢล๎ࠥ็๊ๅ็้๋ࠣࠦๅ้ไ฼๋๊ࠦࠠࠨ㮳"),l1l111_l1_ (u"ࠪࠫ㮴"),28)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㮵"),l1l111_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ㮶")+l1l111_l1_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㮷"),l1l111_l1_ (u"ࠧࠨ㮸"),41)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㮹"),l1l111_l1_ (u"ࠩࡢࡔࡓ࡚࡟ࠨ㮺")+l1l111_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ㮻"),l1l111_l1_ (u"ࠫࠬ㮼"),38)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㮽"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮾"),l1l111_l1_ (u"ࠧࠨ㮿"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯀"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠷࡟ࠨ㯁")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอࠥ฿วๆหࠪ㯂"),l1l111_l1_ (u"ࠫࠬ㯃"),102)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯄"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠵ࡣࠬ㯅")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢัหฺฯࠧ㯆"),l1l111_l1_ (u"ࠨࠩ㯇"),103)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㯈"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠳ࡠࠩ㯉")+l1l111_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦไๅใะูࠬ㯊"),l1l111_l1_ (u"ࠬ࠭㯋"),104)
	return
def ITEMS(l1llll1ll11_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡕࡘࠪ㯌")+l1llll1ll11_l1_+l1l111_l1_ (u"ࠧࡠࠩ㯍")
	user = l1l1ll111ll_l1_(32)
	payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ㯎"):l1l111_l1_ (u"ࠩࠪ㯏"),l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㯐"):user,l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㯑"):l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㯒"),l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㯓"):l1llll1ll11_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㯔"),l111l1_l1_,payload,l1l111_l1_ (u"ࠨࠩ㯕"),l1l111_l1_ (u"ࠩࠪ㯖"),l1l111_l1_ (u"ࠪࠫ㯗"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㯘"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬ࠮࡛࡟࠽࡟ࡶࡡࡴ࡝ࠬࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠭㯙"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"࠭ࡡ࡭ࠩ㯚"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯛"))
			start = start.replace(l1l111_l1_ (u"ࠨࡇ࡯ࠫ㯜"),l1l111_l1_ (u"ࠩࡄࡰࠬ㯝"))
			start = start.replace(l1l111_l1_ (u"ࠪࡅࡑ࠭㯞"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯟"))
			start = start.replace(l1l111_l1_ (u"ࠬࡋࡌࠨ㯠"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯡"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠧࡂ࡮࠰ࠫ㯢"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㯣"))
			start = start.replace(l1l111_l1_ (u"ࠩࡄࡰࠥ࠭㯤"),l1l111_l1_ (u"ࠪࡅࡱ࠭㯥"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l1111l_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠫࠨ࠭㯦") in source: continue
			if source!=l1l111_l1_ (u"࡛ࠬࡒࡍࠩ㯧"): name = name+l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࠣࠤࠬ㯨")+source+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㯩")
			url = source+l1l111_l1_ (u"ࠨ࠽࠾ࠫ㯪")+server+l1l111_l1_ (u"ࠩ࠾࠿ࠬ㯫")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠪ࠿ࡀ࠭㯬")+l1llll1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㯭"),l1lllll_l1_+l1l111_l1_ (u"ࠬ࠭㯮")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㯯"),l1lllll_l1_+l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㯰"),l1l111_l1_ (u"ࠨࠩ㯱"),9999)
	return
def PLAY(id):
	source,server,l1l1l1111l_l1_,l1llll1ll11_l1_ = id.split(l1l111_l1_ (u"ࠩ࠾࠿ࠬ㯲"))
	url = l1l111_l1_ (u"ࠪࠫ㯳")
	user = l1l1ll111ll_l1_(32)
	if source==l1l111_l1_ (u"࡚ࠫࡘࡌࠨ㯴"): url = l1l1l1111l_l1_
	elif source==l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㯵"):
		url = l1l11l1_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㯶")][0]+l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ㯷")+l1l1l1111l_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㯸"),url)
		return
	elif source==l1l111_l1_ (u"ࠩࡊࡅࠬ㯹"):
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㯺") : l1l111_l1_ (u"ࠫࠬ㯻"), l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㯼") : user , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㯽") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠱ࠨ㯾") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㯿") : l1l111_l1_ (u"ࠩࠪ㰀") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㰁"),l111l1_l1_,payload,l1l111_l1_ (u"ࠫࠬ㰂"),False,l1l111_l1_ (u"ࠬ࠭㰃"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㰄"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㰅"),l1l111_l1_ (u"ࠨࠩ㰆"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㰇"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㰈"))
			return
		html = response.content
		cookies = response.cookies
		l1l1ll11l111_l1_ = cookies[l1l111_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤࠨ㰉")]
		url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㰊")]
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㰋") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㰌") : user , l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㰍") : l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠴ࠪ㰎") , l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㰏") : l1l111_l1_ (u"ࠫࠬ㰐") }
		headers = { l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ㰑") : l1l111_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࡀࠫ㰒")+l1l1ll11l111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㰓"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠨࠩ㰔"),l1l111_l1_ (u"ࠩࠪ㰕"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㰖"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㰗"),l1l111_l1_ (u"ࠬ࠭㰘"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㰙"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㰚"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ㰛"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1l1ll111lll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠼࠳࠭㰜")+server+l1l111_l1_ (u"ࠪ࠻࠼࠽࠯ࠨ㰝")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㰞")+params
		l1l1ll111ll1_l1_ = l1l1ll111lll_l1_.replace(l1l111_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㰟"),l1l111_l1_ (u"࠭࠴࠱࠼࠺ࠫ㰠")).replace(l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㰡"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㰢"))
		l1l1ll11l11l_l1_ = l1l1ll111lll_l1_.replace(l1l111_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㰣"),l1l111_l1_ (u"ࠪ࠸࠷ࡀ࠷ࠨ㰤")).replace(l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㰥"),l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㰦"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"࠭ࡈࡅࠩ㰧"),l1l111_l1_ (u"ࠧࡔࡆ࠴ࠫ㰨"),l1l111_l1_ (u"ࠨࡕࡇ࠶ࠬ㰩")]
		l1llll_l1_ = [l1l1ll111lll_l1_,l1l1ll111ll1_l1_,l1l1ll11l11l_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠩࡑࡘࠬ㰪"):
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㰫") : l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㰬") }
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㰭") : l1l1l1111l_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰮") : user , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰯") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨ㰰") , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰱") : l1llll1ll11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㰲"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠫࠬ㰳"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㰴"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㰵"),l1l111_l1_ (u"ࠧࠨ㰶"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㰷"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㰸"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㰹")]
		url = url.replace(l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㰺"),l1l111_l1_ (u"ࠬࠦࠧ㰻"))
		url = url.replace(l1l111_l1_ (u"࠭ࠥ࠴ࡆࠪ㰼"),l1l111_l1_ (u"ࠧ࠾ࠩ㰽"))
		if l1l111_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧ㰾") in l1l1l1111l_l1_:
			url = url.replace(l1l111_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪ㰿"),l1l111_l1_ (u"ࠪࠫ㱀"))
			url = url.replace(l1l111_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧ㱁"),l1l111_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧ㱂"))
	elif source==l1l111_l1_ (u"࠭ࡐࡍࠩ㱃"):
		payload = { l1l111_l1_ (u"ࠧࡪࡦࠪ㱄") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㱅") : user , l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㱆") : l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡑࡎࠪ㱇") , l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㱈") : l1llll1ll11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㱉"), l111l1_l1_, payload, l1l111_l1_ (u"࠭ࠧ㱊"),False,l1l111_l1_ (u"ࠧࠨ㱋"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ㱌"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㱍"),l1l111_l1_ (u"ࠪࠫ㱎"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㱏"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㱐"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㱑")]
		headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㱒"):response.headers[l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㱓")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㱔"),url, l1l111_l1_ (u"ࠪࠫ㱕"),headers , l1l111_l1_ (u"ࠫࠬ㱖"),l1l111_l1_ (u"ࠬ࠭㱗"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ㱘"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㱙"),l1l111_l1_ (u"ࠨࠩ㱚"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱛"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱜"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㱝"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"࡚ࠬࡁࠨ㱞"),l1l111_l1_ (u"࠭ࡆࡎࠩ㱟"),l1l111_l1_ (u"࡚ࠧࡗࠪ㱠"),l1l111_l1_ (u"ࠨ࡙ࡖ࠵ࠬ㱡"),l1l111_l1_ (u"࡚ࠩࡗ࠷࠭㱢"),l1l111_l1_ (u"ࠪࡖࡑ࠷ࠧ㱣"),l1l111_l1_ (u"ࠫࡗࡒ࠲ࠨ㱤")]:
		if source==l1l111_l1_ (u"࡚ࠬࡁࠨ㱥"): l1l1l1111l_l1_ = id
		headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㱦") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㱧") }
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㱨") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㱩") : user , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㱪") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࠩ㱫")+source , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㱬") : l1llll1ll11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㱭"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠧࠨ㱮"),l1l111_l1_ (u"ࠨࠩ㱯"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ㱰"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㱱"),l1l111_l1_ (u"ࠫࠬ㱲"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㱳"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㱴"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㱵")]
		if source==l1l111_l1_ (u"ࠨࡈࡐࠫ㱶"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㱷"), url, l1l111_l1_ (u"ࠪࠫ㱸"), l1l111_l1_ (u"ࠫࠬ㱹"), False,l1l111_l1_ (u"ࠬ࠭㱺"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠼ࡺࡨࠨ㱻"))
			url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㱼")]
			url = url.replace(l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㱽"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㱾"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㱿"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ䊌")
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䊍") : l1l111_l1_ (u"ࠧࠨ䊎") }
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧ䊏")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1l1l1l1l1_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1l1l1l1_l1_():
	message = l1l111_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠥ࠴࠮࠯๋ࠢฬาอฬสࠢส่๎ࠦวฺษาอࠥฮัๆฮฬࠤ๊์ࠠศๆุๅึࠦ࠮࠯࠰ࠣ์ฬ๊ๅษำ่ะࠥำวๅ์สࠤฺฺ๊้ๆࠣ์๏฿ว็์ฺ้๋่ࠣࠦๅฬࠤฺำ๊สࠢ࠱࠲࠳่ࠦๅ้ำหู่ࠥโࠢํฬ็๏ࠠศๆ่์็฿ࠠๆ฼็ๆࠥอไ๊่ࠢหฺࠥวยࠢส่้ํࠧ䊐")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䊑"),l1l111_l1_ (u"ࠫࠬ䊒"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䊓"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊔"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䊕"),l1l111_l1_ (u"ࠨࠩ䊖"),189,l1l111_l1_ (u"ࠩࠪ䊗"),l1l111_l1_ (u"ࠪࠫ䊘"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䊙"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊚"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䊛")+l1lllll_l1_+l1l111_l1_ (u"ࠧษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䊜"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䊝"),l1l111_l1_ (u"ࠩࠪ䊞"),l1l111_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ䊟"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊠"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊡")+l1lllll_l1_+l1l111_l1_ (u"࠭รฮัฮࠤฬ๊วโๆส้ࠬ䊢"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䊣"),l1l111_l1_ (u"ࠨࠩ䊤"),l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊥"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊦"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䊧")+l1lllll_l1_+l1l111_l1_ (u"ࠬะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࠫ䊨"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䊩"),l1l111_l1_ (u"ࠧࠨ䊪"),l1l111_l1_ (u"ࠨࡶࡹࠫ䊫"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊬"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䊭")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วไอิࠤฺ๊ว่ัฬࠫ䊮"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䊯"),l1l111_l1_ (u"࠭ࠧ䊰"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䊱"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊲"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊳")+l1lllll_l1_+l1l111_l1_ (u"ࠪว็๎้ࠡษ็หๆ๊วๆࠢส่าอไ๋หࠪ䊴"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䊵"),l1l111_l1_ (u"ࠬ࠭䊶"),l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䊷"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䊸"),headers,l1l111_l1_ (u"ࠨࠩ䊹"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䊺"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠸࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䊻"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊼"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊽")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ䊾")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ䊿"),headers,l1l111_l1_ (u"ࠨࠩ䋀"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ䋁"))
	if type==l1l111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䋂"): block = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂศำฯฬࠢส่ศ็ไศ็࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ䋃"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠬࡨ࡯ࡹ࠯ࡲࡪ࡫࡯ࡣࡦࠩ䋄"): block = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䋅"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䋆"): block = re.findall(l1l111_l1_ (u"ࠨࡤࡷࡲ࠲࠸࠭ࡰࡸࡨࡶࡱࡧࡹࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭䋇"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䋈"): block = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࠲ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠮࠮ࠫࡁࠬࡦࡹࡴ࠭࠳ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠭䋉"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡼࠧ䋊"): block = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲ࡬ࠨࠧ䋋"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䋌"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䋍")]:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡷࡽࡱ࡫࠽ࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䋎"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥ࠷ࡠ࠶࠭࠺࡟࠮ࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䋏"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ䋐"),l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ䋑"),l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬ䋒"),l1l111_l1_ (u"ู࠭าุࠪ䋓"),l1l111_l1_ (u"ࠧࡓࡣࡺࠫ䋔"),l1l111_l1_ (u"ࠨࡕࡰࡥࡨࡱࡄࡰࡹࡱࠫ䋕"),l1l111_l1_ (u"ࠩส฽้อๆࠨ䋖"),l1l111_l1_ (u"ࠪหัุวยࠩ䋗")]
	for l1ll1l_l1_,l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l1l1l1l1ll11_l1_ in items:
		if type in [l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䋘"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䋙")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l1l1l1l1ll11_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l1l1l1l1ll11_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࠿ࡷ࡫ࡨࡻࡂࡺࡲࡶࡧࠪ䋚"),l1l111_l1_ (u"ࠧࠨ䋛"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䋜") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䋝") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋞") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䋟"),l1l111_l1_ (u"ࠬ࠭䋠")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䋡"),l1l111_l1_ (u"ࠧࠨ䋢"))
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ䋣"))
		if l1l111_l1_ (u"ࠩส่า๊โสࠩ䋤") in title or l1l111_l1_ (u"ࠪห้ำไใ้ࠪ䋥") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ䋦"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䋧") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋨"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䋩") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䋪"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䋫") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋬"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࠬ䋭"):
		items = re.findall(l1l111_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䋮"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ䋯"),l1l111_l1_ (u"ࠧࠨ䋰"))
			if title!=l1l111_l1_ (u"ࠨࠩ䋱"):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋲"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ䋳")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䋴"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䋵"),headers,l1l111_l1_ (u"࠭ࠧ䋶"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䋷"))
	block = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䋸"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ䋹"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋺") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䋻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䋼"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"࠭ࠨศๆะ่็ฯࡼศๆะ่็ํࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䋽"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䋾"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠨࠪࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䋿"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䌀"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠪࠤࠬ䌁") + title[0][1]
			else: title = l1l111_l1_ (u"ࠫࠬ䌂")
			title = name + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䌃") + l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭䌄") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䌅"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䌆") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䌇") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䌈") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䌉"),l1l111_l1_ (u"ࠬ࠭䌊")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䌋"),l1l111_l1_ (u"ࠧࠨ䌌"))
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䌍"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1l1l11ll1_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䌎"))
	l1lllll1_l1_ = l1l1l1l11ll1_l1_[0]
	del l1l1l1l11ll1_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䌏"),headers,l1l111_l1_ (u"ࠫࠬ䌐"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䌑"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡰࡷ࠱ࡸ࡯ࡺࡦ࠼ࠣ࠶࠺ࡶࡸ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䌒"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1l1l11ll1_l1_: l1l1l1l11ll1_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1l1l11ll1_l1_:
		if l1l111_l1_ (u"ࠧ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䌓") in l1ll1ll_l1_:
			l1l1l1l1111l_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1l1l1111l_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡤ࡭ࡳ࠭䌔"))
	for l1ll1ll_l1_ in l1l1l1l11ll1_l1_:
		if l1l111_l1_ (u"ࠩ࠽࠳࠴ࡼࡢ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࠬ䌕") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䌖"),headers,l1l111_l1_ (u"ࠫࠬ䌗"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䌘"))
			html = html.decode(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡹ࠭࠲࠴࠸࠺ࠬ䌙")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䌚"))
			html = html.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌛"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌜"))
			html = html.replace(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌝"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌞"))
			html = html.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ䌟"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌠"))
			html = html.replace(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ䌡"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌢"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䌣"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1l1l111l1_l1_,l1l1l1l1l111_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠪࠫ䌤")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠰࠭ࡃࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮࠰࠮࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䌥"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䌦") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠪ䌧")+l1l111_l1_ (u"ࠧࠤࠩ䌨")+l1l111_l1_ (u"ࠨ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠪ䌩")+l1l111_l1_ (u"ࠩࠦࠫ䌪")+l1l111_l1_ (u"ࠪ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䌫"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䌬") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࠫ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠨ䌭")+l1l111_l1_ (u"࠭ࠣࠨ䌮")+l1l111_l1_ (u"ࠧ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠩ䌯")+l1l111_l1_ (u"ࠨࠥࠪ䌰")+l1l111_l1_ (u"ࠩ࠶࠷࠸ࠨࠠ࠰ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌱"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠪࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䌲")
						l1l1l1l1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࠮࠮ࠫࡁࠬ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࠫࡳࡳࡲࡩ࡯ࡧࡿࡧࡴࡳࠩ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱ࠪ䌳"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠬࡄࠠࠫࠪ࡞ࡢࡁࡄ࡝ࠬࠫࠣ࠮ࡁ࠭䌴"),l1l1l1l1l11l_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"࠭ࠠࠨ䌵").join(title)
						title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䌶"))
						title = title.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䌷"),l1l111_l1_ (u"ࠩࠣࠫ䌸")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䌹"),l1l111_l1_ (u"ࠫࠥ࠭䌺")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌻"),l1l111_l1_ (u"࠭ࠠࠨ䌼")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䌽"),l1l111_l1_ (u"ࠨࠢࠪ䌾")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䌿"),l1l111_l1_ (u"ࠪࠤࠬ䍀"))
						l1l1l1l111l1_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊ห࠾ࠬ䍁"), l1l1l1l111l1_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1l1l111l1_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠩࠣࠩ䍂"),block,re.DOTALL)
				l1l1l1l11111_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1l1l11111_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡆࡰࡴࡸࡱࠬ䍃"))
				block = block.replace(l1l111_l1_ (u"ࠧแࠩ䍄"),l1l111_l1_ (u"ࠨࠩ䍅"))
				block = block.replace(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ䍆"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䍇"))
				block = block.replace(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ䍈"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡦࡴࡺࡨࠣࠢࠣࡠࡳࠦࠠࠨ䍉"))
				block = block.replace(l1l111_l1_ (u"࠭ำ๋ำไีฬะࠠศๆอั๊๐ไࠨ䍊"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ䍋"))
				block = block.replace(l1l111_l1_ (u"ࠨำ๋หอ฽ࠠศๆอั๊๐ไࠨ䍌"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠣࠤࡡࡴࠠࠡࠩ䍍"))
				block = block.replace(l1l111_l1_ (u"ࠪื๏ืแาษอࠤฬ๊ๅีษ๊ำࠬ䍎"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ䍏"))
				block = block.replace(l1l111_l1_ (u"ࠬื่ศสฺࠤฬ๊ๅีษ๊ำࠬ䍐"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡼࡧࡴࡤࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䍑"))
				l1l1l1l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࡟ࡨ࠰ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䍒"),block,re.DOTALL)
				for l1l1l1l11lll_l1_ in l1l1l1l11l11_l1_:
					type = re.findall(l1l111_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭䍓"),l1l1l1l11lll_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䍔"): type = l1l111_l1_ (u"ࠪࡣࡤ࠭䍕")+type[0]
						else: type = l1l111_l1_ (u"ࠫࠬ䍖")
					items = re.findall(l1l111_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ䍗"),l1l1l1l11lll_l1_,re.DOTALL)
					for l1l1l1l11l1l_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ䍘"),l1l1l1l11l1l_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䍙") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1l1l1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ䍚"),headers,l1l111_l1_ (u"ࠩࠪ䍛"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䍜"))
	items = re.findall(l1l111_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䍝"),html,re.DOTALL)
	if items:
		l1l1l1l1ll1l_l1_ = items[-1]
		l1llll_l1_.append(l1l1l1l1ll1l_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ䍞"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䍟"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ䍠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ䍡"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ䍢"),l1l111_l1_ (u"ࠪ࠯ࠬ䍣"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䍤"),headers,l1l111_l1_ (u"ࠬ࠭䍥"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䍦"))
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ䍧"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠨࠩ䍨") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ䍩") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ䍪"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠫࠬ䍫")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䍬")+search+l1l111_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭䍭")+category
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡉࡌࡆࡃࡑࡉࡗ࠭ᨆ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡄࡎࡑࡣࠬᨇ")
l1lll11l11_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠧࡵࡧࡰࡴࠬᨈ"))
l1ll1111ll_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪᨉ"))
l1lll111l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫᨊ"),l1l111_l1_ (u"ࠪࡘ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧᨋ"))
l1ll11lll1_l1_ = l1llll11l1_l1_
l1ll111l11_l1_ = l1l111_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧᨌ")
l1ll111l1l_l1_ = l1l111_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡸࡿࡳࡵࡧࡰ࠳ࡩࡸ࡯ࡱࡤࡲࡼࠬᨍ")
l1lll1111l_l1_ = l1l111_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩᨎ")
l1lll11l1l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࡪࡩࡷ࠭ᨏ")
l1ll11l111_l1_ = l1l111_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯࡭ࡱࡪࠫᨐ")
l1ll11l11l_l1_ = l1l111_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡣࡱࡶࠬᨑ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1lllll1l1_l1_()
	elif mode==741: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l11_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1llll1ll1_l1_(l1ll1111ll_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1llll1ll1_l1_(l1lll111l1_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11l1ll_l1_(l1ll11lll1_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll11111l_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1ll1l1_l1_()
	elif mode==751: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l11_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l1l_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1llll1ll1_l1_(l1lll1111l_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l1l_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l111_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l11l_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1ll1lll11_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1l1lll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lllll1l1_l1_():
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1lll11l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll1111ll_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll111l1_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll1l11ll_l1_(l1ll11lll1_l1_)
	l1lll1ll11_l1_ -= 36864
	l1ll11llll_l1_ -= 1
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨒ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨓ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨔ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨕ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᨖ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᨗ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ᨘࠩࠣࠬࠬ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨙ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨚ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨛ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"࠭ࠩࠨ᨜")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_
	text = l1l111_l1_ (u"ࠧࠡࠪࠪ᨝")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ᨞")+str(count)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ᨟")
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨠ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡษ็ะ๊๐ูࠨᨡ")+text,l1l111_l1_ (u"ࠬ࠭ᨢ"),745)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨣ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᨤ"),l1l111_l1_ (u"ࠨࠩᨥ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᨦ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠศๆ่่ๆอสࠡษ็้ษ่สสࠩᨧ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠫࠬᨨ"),741)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨩ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮ࠭ᨪ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠧࠨᨫ"),742)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᨬ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦวๅื๋ีࠥอไใัํ้ฮ࠭ᨭ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠪࠫᨮ"),743)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨯ"),l1lllll_l1_+l1l111_l1_ (u"ࠬะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧᨰ")+l1lllll11l_l1_,l1l111_l1_ (u"࠭ࠧᨱ"),744)
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᨲ"),l1l111_l1_ (u"ࠨࠩᨳ"))
	return
def l1ll1ll1l1_l1_():
	l1llll1l11_l1_ = True if l1l111_l1_ (u"ࠩ࠲ࠫᨴ") in l1ll11ll11_l1_ else False
	if not l1llll1l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫᨵ"),l1l111_l1_ (u"ࠫࠬᨶ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᨷ"),l1l111_l1_ (u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤ๊ะ่โำฬࠤๆ่ืࠡๆฦะ์ุษࠡ์ู๋๊่ࠠ࠯࠰ࠣ์ัํวำๅ่ࠣ๏ูࠠๆ่๊ࠣํ฿๋๊้ࠠ็ุ࠭ᨸ"))
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᨹ"))
	if not l1ll11l1l1_l1_: l1ll1l1lll_l1_()
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1ll111l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll111l1l_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll1111l_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll111ll1_l1_(l1lll11l1l_l1_)
	l1lll1l1ll_l1_,l1ll1l1111_l1_ = l1ll111ll1_l1_(l1ll11l111_l1_)
	l1lll1l1l1_l1_,l1lll11ll1_l1_ = l1ll111ll1_l1_(l1ll11l11l_l1_)
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᨺ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᨻ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᨼ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨽ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᨾ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᨿ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᩀ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᩁ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᩂ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᩃ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᩄ")+str(l1ll11llll_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᩅ")
	l1ll1l1l11_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᩆ")+l1lllll111_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᩇ")+str(l1ll1l1111_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᩈ")
	l1ll1l1ll1_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᩉ")+l1lllll111_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᩊ")+str(l1lll11ll1_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᩋ")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_+l1ll1l1111_l1_+l1lll11ll1_l1_
	text = l1l111_l1_ (u"ࠬࠦࠨࠨᩌ")+l1lllll111_l1_(size)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᩍ")+str(count)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩎ")
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩏ"),l1lllll_l1_+l1l111_l1_ (u"ࠩศ฽฼อมࠡำัูฮࠦโาษฤอࠥ๎ใหษหอࠬᩐ"),l1l111_l1_ (u"ࠪࠫᩑ"),758)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩒ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮࠢส่ัฺ๋๊ࠩᩓ")+text,l1l111_l1_ (u"࠭ࠧᩔ"),757)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩕ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᩖ"),l1l111_l1_ (u"ࠩࠪᩗ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩘ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠫᩙ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠬ࠭ᩚ"),751)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩛ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫᩜ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠨࠩᩝ"),752)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩞ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪ᩟")+l1ll1ll111_l1_,l1l111_l1_ (u"᩠ࠫࠬ"),753)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩡ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩᩢ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠧࠨᩣ"),754)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩤ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡲ࡯ࡨࠩᩥ")+l1ll1l1l11_l1_,l1l111_l1_ (u"ࠪࠫᩦ"),755)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩧ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡣࡱࡶࠬᩨ")+l1ll1l1ll1_l1_,l1l111_l1_ (u"࠭ࠧᩩ"),756)
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᩪ"),l1l111_l1_ (u"ࠨࠩᩫ"))
	return
def l1ll1l1lll_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪᩬ"),l1l111_l1_ (u"ࠪࠫᩭ"),l1l111_l1_ (u"ࠫࠬᩮ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᩯ"),l1l111_l1_ (u"࠭ไไ์ࠣ๎฾๋ไࠡษ็ฮ๋฾๊โࠢ฼๊ิ้ࠠ࠯࠰ࠣฬึ์วๆฮࠣ฽๊อฯࠡสะหัฯࠠฦๆ์ࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤ้๊ๅๅใสฮࠥ๎วๅ็ฯ่ิอสࠡษ็ฮ๏ࠦำ้ใࠣ๎ู๊อ่ษࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ฽฼อม้ࠡำ๋ࠥอไาะุอࠥอไร่ࠣรࠦ࠭ᩰ"))
	if l1llll111l_l1_==-1: return
	if l1llll111l_l1_:
		l1llll11ll_l1_ = True
		import subprocess
		try: subprocess.Popen(l1l111_l1_ (u"ࠧࡴࡷࠪᩱ"))
		except: l1llll11ll_l1_ = False
		if l1llll11ll_l1_:
			l1ll1llll1_l1_ = l1ll111l11_l1_+l1l111_l1_ (u"ࠨࠢࠪᩲ")+l1ll111l1l_l1_+l1l111_l1_ (u"ࠩࠣࠫᩳ")+l1lll1111l_l1_+l1l111_l1_ (u"ࠪࠤࠬᩴ")+l1lll11l1l_l1_+l1l111_l1_ (u"ࠫࠥ࠭᩵")+l1ll11l111_l1_+l1l111_l1_ (u"ࠬࠦࠧ᩶")+l1ll11l11l_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧ᩷")+l1ll1llll1_l1_+l1l111_l1_ (u"ࠧࠣࠩ᩸"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᩹"),l1l111_l1_ (u"ࠩࠪ᩺"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᩻"),l1l111_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡว฼฻ฬวࠠศๆิาฺฯࠧ᩼"))
			settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ᩽"),l1l111_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩ᩾"))
			xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫᩿ࠫ"))
		else: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᪀"),l1l111_l1_ (u"ࠩࠪ᪁"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪂"),l1l111_l1_ (u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠫ᪃"))
	return
def l1lllll111_l1_(size):
	for x in [l1l111_l1_ (u"ࠬࡈࠧ᪄"),l1l111_l1_ (u"࠭ࡋࡃࠩ᪅"),l1l111_l1_ (u"ࠧࡎࡄࠪ᪆"),l1l111_l1_ (u"ࠨࡉࡅࠫ᪇"),l1l111_l1_ (u"ࠩࡗࡆࠬ᪈")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧ᪉")%(size,x)
	return text
def l1ll111ll1_l1_(l1llll1111_l1_=l1l111_l1_ (u"ࠫ࠳࠭᪊")):
	global l1lll11111_l1_,l1lll1lll1_l1_
	l1lll11111_l1_,l1lll1lll1_l1_ = 0,0
	def l1lll111ll_l1_(l1llll1111_l1_):
		global l1lll11111_l1_,l1lll1lll1_l1_
		if os.path.exists(l1llll1111_l1_):
			if 0 and l1l111_l1_ (u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭᪋") in dir(os):
				for l1ll1111l1_l1_ in os.scandir(l1llll1111_l1_):
					if l1ll1111l1_l1_.l1lll1llll_l1_(follow_symlinks=False):
						l1lll111ll_l1_(l1ll1111l1_l1_.path)
					elif l1ll1111l1_l1_.l1ll1l1l1l_l1_(follow_symlinks=False):
						l1lll11111_l1_ += l1ll1111l1_l1_.stat().st_size
						l1lll1lll1_l1_ += 1
			else:
				for l1ll1111l1_l1_ in os.listdir(l1llll1111_l1_):
					l1ll111111_l1_ = os.path.abspath(os.path.join(l1llll1111_l1_,l1ll1111l1_l1_))
					if os.path.isdir(l1ll111111_l1_):
						l1lll111ll_l1_(l1ll111111_l1_)
					elif os.path.isfile(l1ll111111_l1_):
						size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
						l1lll11111_l1_ += size
						l1lll1lll1_l1_ += count
		return
	try: l1lll111ll_l1_(l1llll1111_l1_)
	except: pass
	return l1lll11111_l1_,l1lll1lll1_l1_
def l1lll1ll1l_l1_(l1ll1lllll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࠧ᪌"),l1l111_l1_ (u"ࠧࠨ᪍"),l1l111_l1_ (u"ࠨࠩ᪎"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪏"),l1ll1lllll_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ᪐")+l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้้็ࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᪑"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1ll1lllll_l1_):
		try: os.remove(l1ll1lllll_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭᪒"),l1l111_l1_ (u"࠭ࠧ᪓"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᪔"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᪕"),l1l111_l1_ (u"ࠩࠪ᪖"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪗"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ᪘"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ᪙"),l1l111_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩ᪚"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ᪛"))
	return
def l1ll11111l_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࠩ᪜"),l1l111_l1_ (u"ࠩࠪ᪝"),l1l111_l1_ (u"ࠪࠫ᪞"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪟"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠬ᪠")+l1l111_l1_ (u"࠭࡜࡯ࠩ᪡")+l1l111_l1_ (u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭᪢")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ᪣")+l1l111_l1_ (u"ࠩยࠥࠦ࠭᪤")+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᪥"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1lll11l11_l1_,True,False)
	l1llll1ll1_l1_(l1ll1111ll_l1_,True,False)
	l1llll1ll1_l1_(l1lll111l1_l1_,False,False)
	l1ll11l1ll_l1_(l1ll11lll1_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ᪦"),l1l111_l1_ (u"ࠬ࠭ᪧ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪨"),l1l111_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨ᪩"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ᪪"),l1l111_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬ᪫"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ᪬"))
	return
def l1ll1lll11_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬ᪭"),l1l111_l1_ (u"ࠬ࠭᪮"),l1l111_l1_ (u"࠭ࠧ᪯"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᪰"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อࠡ็็ๅฬะࠧ᪱")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ᪲")+l1l111_l1_ (u"ࠪࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠠ࠯࠰ࠣࡨࡷࡵࡰࡣࡱࡻࠤ࠳࠴ࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠤ࠳࠴ࠠ࡭ࡱࡪ࡫ࡪࡸࠠ࠯࠰ࠣࡰࡴ࡭ࠠ࠯࠰ࠣࡥࡳࡸࠧ᪳")+l1l111_l1_ (u"ࠫࡡࡴࠧ᪴")+l1l111_l1_ (u"ࠬࡅ᪵ࠡࠢࠩ")+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ᪶"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1ll111l11_l1_,False,False)
	l1llll1ll1_l1_(l1ll111l1l_l1_,False,False)
	l1llll1ll1_l1_(l1lll1111l_l1_,False,False)
	l1llll1ll1_l1_(l1lll11l1l_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l111_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l11l_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᪷"),l1l111_l1_ (u"ࠨ᪸ࠩ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ᪹ࠬ"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะ᪺ࠫ"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᪻"),l1l111_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ᪼"))
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪ᪽ࠪ"))
	return
def l1ll11l1ll_l1_(l1ll1lll1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ᪾"),l1l111_l1_ (u"ࠨᪿࠩ"),l1l111_l1_ (u"ᫀࠩࠪ"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᫁"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ๊ำส้์สฮ๋ࠥไโุࠢ์ึࠦวๅฮ็ำࠥลࠡࠢࠩ᫂")+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ᫃ࠧ"))
		if l1llll111l_l1_!=1: return
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽᫄ࠪ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬ᫅"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨ᫆"))
	conn.commit()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪ᫇"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᫈"),l1l111_l1_ (u"ࠫࠬ᫉"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᫊"),l1l111_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧ᫋"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᫌ"),l1l111_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᫍ"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ᫎ"))
	return
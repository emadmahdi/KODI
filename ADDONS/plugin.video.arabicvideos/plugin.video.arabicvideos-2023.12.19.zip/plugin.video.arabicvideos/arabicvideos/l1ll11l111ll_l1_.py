# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ䗞")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡐࡘ࡚࡟ࠨ䗟")
l1l1l11l1111_l1_ = 4
l1l1l111ll11_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll111_l1_):
	try: l1l11lllll1l_l1_ = str(l1llllll111_l1_[l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗠")])
	except: l1l11lllll1l_l1_ = l1l111_l1_ (u"ࠫࠬ䗡")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1l11lllll_l1_(text)
	elif mode==162: l1lll_l1_ = l1l11lll11ll_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l11lll11ll_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1l11lll1l_l1_(text)
	elif mode==165: l1lll_l1_ = l1l11ll11lll_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1l11l1l1l_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l11ll11ll1_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l11l1ll1ll_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1l11ll1l1_l1_()
	elif mode==762: l1lll_l1_ = l1l1l11111l1_l1_()
	elif mode==763: l1lll_l1_ = l1l1l1111111_l1_(l1l11lllll1l_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1l111lll1_l1_(l1l11lllll1l_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1l11ll111_l1_(l1l11lllll1l_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗢"),l1l111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์ู๋ࠦี๊สส๏ฯࠧ䗣"),l1l111_l1_ (u"ࠧࠨ䗤"),161,l1l111_l1_ (u"ࠨࠩ䗥"),l1l111_l1_ (u"ࠩࠪ䗦"),l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗧"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗨"),l1l111_l1_ (u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ䗩"),l1l111_l1_ (u"࠭ࠧ䗪"),162,l1l111_l1_ (u"ࠧࠨ䗫"),l1l111_l1_ (u"ࠨࠩ䗬"),l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗭"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗮"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ䗯"),l1l111_l1_ (u"ࠬ࠭䗰"),163,l1l111_l1_ (u"࠭ࠧ䗱"),l1l111_l1_ (u"ࠧࠨ䗲"),l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗳"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗴"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥฮอฬࠢ฼ุํอฦ๋ࠩ䗵"),l1l111_l1_ (u"ࠫࠬ䗶"),164,l1l111_l1_ (u"ࠬ࠭䗷"),l1l111_l1_ (u"࠭ࠧ䗸"),l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗹"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗺"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䗻"),l1l111_l1_ (u"ࠪࠫ䗼"),763,l1l111_l1_ (u"ࠫࠬ䗽"),l1l111_l1_ (u"ࠬ࠭䗾"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䗿"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䘀"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䘁"),l1l111_l1_ (u"ࠩࠪ䘂"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘃"),l1l111_l1_ (u"ࠫ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ䘄"),l1l111_l1_ (u"ࠬ࠭䘅"),163,l1l111_l1_ (u"࠭ࠧ䘆"),l1l111_l1_ (u"ࠧࠨ䘇"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘈"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘉"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ䘊"),l1l111_l1_ (u"ࠫࠬ䘋"),163,l1l111_l1_ (u"ࠬ࠭䘌"),l1l111_l1_ (u"࠭ࠧ䘍"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘎"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘏"),l1l111_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ䘐"),l1l111_l1_ (u"ࠪࠫ䘑"),162,l1l111_l1_ (u"ࠫࠬ䘒"),l1l111_l1_ (u"ࠬ࠭䘓"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘔"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘕"),l1l111_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䘖"),l1l111_l1_ (u"ࠩࠪ䘗"),162,l1l111_l1_ (u"ࠪࠫ䘘"),l1l111_l1_ (u"ࠫࠬ䘙"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘚"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘛"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷࡚ࠦศฮอࠣ฽ู๎วว์ࠪ䘜"),l1l111_l1_ (u"ࠨࠩ䘝"),164,l1l111_l1_ (u"ࠩࠪ䘞"),l1l111_l1_ (u"ࠪࠫ䘟"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘠"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘡"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭䘢"),l1l111_l1_ (u"ࠧࠨ䘣"),765,l1l111_l1_ (u"ࠨࠩ䘤"),l1l111_l1_ (u"ࠩࠪ䘥"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘦"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䘧"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䘨"),l1l111_l1_ (u"࠭ࠧ䘩"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘪"),l1l111_l1_ (u"ࠨไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭䘫"),l1l111_l1_ (u"ࠩࠪ䘬"),163,l1l111_l1_ (u"ࠪࠫ䘭"),l1l111_l1_ (u"ࠫࠬ䘮"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘯"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘰"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ䘱"),l1l111_l1_ (u"ࠨࠩ䘲"),163,l1l111_l1_ (u"ࠩࠪ䘳"),l1l111_l1_ (u"ࠪࠫ䘴"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘵"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘶"),l1l111_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ䘷"),l1l111_l1_ (u"ࠧࠨ䘸"),162,l1l111_l1_ (u"ࠨࠩ䘹"),l1l111_l1_ (u"ࠩࠪ䘺"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘻"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘼"),l1l111_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䘽"),l1l111_l1_ (u"࠭ࠧ䘾"),162,l1l111_l1_ (u"ࠧࠨ䘿"),l1l111_l1_ (u"ࠨࠩ䙀"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䙁"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙂"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ䙃"),l1l111_l1_ (u"ࠬ࠭䙄"),164,l1l111_l1_ (u"࠭ࠧ䙅"),l1l111_l1_ (u"ࠧࠨ䙆"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙇"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙈"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䙉"),l1l111_l1_ (u"ࠫࠬ䙊"),764,l1l111_l1_ (u"ࠬ࠭䙋"),l1l111_l1_ (u"࠭ࠧ䙌"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䙍"))
	return
def l1l1l11ll1l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙎"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ䙏")+l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨ䙐"),l1l111_l1_ (u"ࠫࠬ䙑"),764)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙒"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䙓"),l1l111_l1_ (u"ࠧࠨ䙔"),9999)
	for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡌࡔࠬ䙕")+str(l1l11lllll1l_l1_)+l1l111_l1_ (u"ࠩࡢࠫ䙖")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙗"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭䙘")+NUMBERS_SEQ_NAME[l1l11lllll1l_l1_],l1l111_l1_ (u"ࠬ࠭䙙"),764,l1l111_l1_ (u"࠭ࠧ䙚"),l1l111_l1_ (u"ࠧࠨ䙛"),l1l111_l1_ (u"ࠨࠩ䙜"),l1l111_l1_ (u"ࠩࠪ䙝"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙞"):l1l11lllll1l_l1_})
	return
def l1l1l11111l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙟"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䙠")+l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),765)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䙣"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䙤"),l1l111_l1_ (u"ࠪࠫ䙥"),9999)
	for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡕࠨ䙦")+str(l1l11lllll1l_l1_)+l1l111_l1_ (u"ࠬࡥࠧ䙧")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙨"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ䙩")+NUMBERS_SEQ_NAME[l1l11lllll1l_l1_],l1l111_l1_ (u"ࠨࠩ䙪"),765,l1l111_l1_ (u"ࠩࠪ䙫"),l1l111_l1_ (u"ࠪࠫ䙬"),l1l111_l1_ (u"ࠫࠬ䙭"),l1l111_l1_ (u"ࠬ࠭䙮"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙯"):l1l11lllll1l_l1_})
	return
def l1l1l11ll11l_l1_(l1lll11l1l1_l1_):
	l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_ = l1ll1llll11_l1_(l1lll11l1l1_l1_)
	try:
		if l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭䙰") in l1lll11l1l1_l1_: l1lll11111l_l1_(l1lll11l1l1_l1_)
		else: l1lll11111l_l1_()
		l1l1l111111l_l1_ = False
	except:
		l11l11ll11l_l1_()
		l1l1l111111l_l1_ = True
	l1lll11l1l1_l1_ = TRANSLATE(l1lll11l1l1_l1_)
	if l1l1l111111l_l1_: l1ll1lll_l1_(l1lll11l1l1_l1_,l1l111_l1_ (u"ࠨใื่๊ࠥไฤีไࠫ䙱"),time=2000)
	else: l1ll1lll_l1_(l1lll11l1l1_l1_,l1l111_l1_ (u"ࠩࠪ䙲"),time=1000)
	return l1l1l111111l_l1_
def l1l11llll1ll_l1_(l1l1l11111ll_l1_=True):
	if not l1l1l11111ll_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䙳"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䙴"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ䙵"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䙶"),l1l111_l1_ (u"ࠧࠨ䙷"),l1l111_l1_ (u"ࠨࠩ䙸"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䙹"),l1l111_l1_ (u"่่ࠪ๐ࠠห็็สࠥํะ่ࠢส่็อฦๆหࠣ࠲ࠥอไษำ้ห๊า๋ࠠฯอหัࠦร็ࠢํๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์ࠥอไห์ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐ำหะิะ๋ࠥๆ่ษࠣๅ็฽ࠠศๆฦๆุอๅࠡษ็ีห๐ำ๋หࠣ࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰ࠣ฽๊๊๊ส่่ࠢหࠦฬๆ์฼ࠤฬ๊รใีส้ࠥะอหษฯࠤ฾อฯสࠢฦๆ้ࠦๅ็ࠢ࠶ࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠศๆล๊ࠥลࠧ䙺"))
	if l1llll111l_l1_!=1: return
	l1l11ll11111_l1_ = menuItemsLIST
	l1l11llll11l_l1_,l1l11lll1lll_l1_ = 0,l1l111_l1_ (u"ࠫࠬ䙻")
	for l1lll11l1l1_l1_ in l1l1111l1l1_l1_:
		time.sleep(0.5)
		l1l1l111111l_l1_ = l1l1l11ll11l_l1_(l1lll11l1l1_l1_)
		if l1l1l111111l_l1_:
			l1l11llll11l_l1_ += 1
			l1l11lll1lll_l1_ += l1l111_l1_ (u"ࠬࠦࠧ䙼")+l1lll11l1l1_l1_
			if l1l11llll11l_l1_>=l1l1l111ll11_l1_: break
	menuItemsLIST[:] = l1l11ll11111_l1_
	if l1l11llll11l_l1_>=l1l1l111ll11_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䙽"),l1l111_l1_ (u"ࠧࠨ䙾"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䙿"),l1l111_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ䚀")+str(l1l11llll11l_l1_)+l1l111_l1_ (u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ䚁")+l1l11lll1lll_l1_)
	else:
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䚂"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ䚃"),contentsDICT,l1ll111l11l_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚄"),l1l111_l1_ (u"ࠧࠨ䚅"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䚆"),l1l111_l1_ (u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ䚇"))
	return
def l1l11lll1111_l1_(l1l11lllll1l_l1_,options):
	l1l1ll1lll1_l1_ = False
	l1l11l1lll11_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1ll1lll1_l1_ and l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䚈") not in options:
		l1lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䚉"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䚊"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ䚋")+l1l11lllll1l_l1_)
	elif l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䚌") not in options or l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䚍") not in options:
		import IPTV
		message = l1l111_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ䚎")
		if l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䚏") not in options:
			try: IPTV.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䚐"),l1l111_l1_ (u"ࠬ࠭䚑"),l1l111_l1_ (u"࠭ࠧ䚒"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚓"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚔"),l1l111_l1_ (u"ࠩࠪ䚕"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䚖"),message)
			try: IPTV.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚗"),l1l111_l1_ (u"ࠬ࠭䚘"),l1l111_l1_ (u"࠭ࠧ䚙"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚚"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚛"),l1l111_l1_ (u"ࠩࠪ䚜"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䚝"),message)
			try: IPTV.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚞"),l1l111_l1_ (u"ࠬ࠭䚟"),l1l111_l1_ (u"࠭ࠧ䚠"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚡"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚢"),l1l111_l1_ (u"ࠩࠪ䚣"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䚤"),message)
		if l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䚥") not in options:
			try: IPTV.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚦"),l1l111_l1_ (u"࠭ࠧ䚧"),l1l111_l1_ (u"ࠧࠨ䚨"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚩"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚪"),l1l111_l1_ (u"ࠪࠫ䚫"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ䚬"),message)
			try: IPTV.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚭"),l1l111_l1_ (u"࠭ࠧ䚮"),l1l111_l1_ (u"ࠧࠨ䚯"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚰"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚱"),l1l111_l1_ (u"ࠪࠫ䚲"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ䚳"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1ll1lll1_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䚴"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ䚵")+l1l11lllll1l_l1_,l1lll_l1_,l1ll111l11l_l1_)
	menuItemsLIST[:] = l1l11l1lll11_l1_
	return l1lll_l1_
def l1l11lllllll_l1_(l1l11lllll1l_l1_,options):
	l1l1ll1lll1_l1_ = False
	l1l11l1lll11_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1ll1lll1_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䚶") not in options:
		l1lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䚷"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䚸"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ䚹")+l1l11lllll1l_l1_)
	elif l1l111_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ䚺") not in options or l1l111_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ䚻") not in options:
		import M3U
		message = l1l111_l1_ (u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ䚼")
		if l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䚽") not in options:
			try: M3U.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚾"),l1l111_l1_ (u"ࠩࠪ䚿"),l1l111_l1_ (u"ࠪࠫ䛀"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛁"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䛂"),l1l111_l1_ (u"࠭ࠧ䛃"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䛄"),message)
			try: M3U.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䛅"),l1l111_l1_ (u"ࠩࠪ䛆"),l1l111_l1_ (u"ࠪࠫ䛇"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛈"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䛉"),l1l111_l1_ (u"࠭ࠧ䛊"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䛋"),message)
			try: M3U.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䛌"),l1l111_l1_ (u"ࠩࠪ䛍"),l1l111_l1_ (u"ࠪࠫ䛎"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛏"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䛐"),l1l111_l1_ (u"࠭ࠧ䛑"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䛒"),message)
		if l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䛓") not in options:
			try: M3U.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䛔"),l1l111_l1_ (u"ࠪࠫ䛕"),l1l111_l1_ (u"ࠫࠬ䛖"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛗"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䛘"),l1l111_l1_ (u"ࠧࠨ䛙"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ䛚"),message)
			try: M3U.GROUPS(l1l11lllll1l_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䛛"),l1l111_l1_ (u"ࠪࠫ䛜"),l1l111_l1_ (u"ࠫࠬ䛝"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛞"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䛟"),l1l111_l1_ (u"ࠧࠨ䛠"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ䛡"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1ll1lll1_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䛢"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ䛣")+l1l11lllll1l_l1_,l1lll_l1_,l1ll111l11l_l1_)
	menuItemsLIST[:] = l1l11l1lll11_l1_
	return l1lll_l1_
def l1l1l1111111_l1_(l1l11lllll1l_l1_,options,l1l11ll1l11l_l1_):
	if l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䛤") in options and l1l11ll1l11l_l1_==l1l111_l1_ (u"ࠬ࠭䛥"): l1l11llll1ll_l1_(True)
	elif l1l11ll1l11l_l1_: l1l11llll1ll_l1_(False)
	l1l11ll1ll11_l1_ = options.replace(l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䛦"),l1l111_l1_ (u"ࠧࠨ䛧")).replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛨"),l1l111_l1_ (u"ࠩࠪ䛩")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䛪"),l1l111_l1_ (u"ࠫࠬ䛫"))
	if not l1l11ll1l11l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䛬"),l1l111_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ䛭"),l1l111_l1_ (u"ࠧࠨ䛮"),763,l1l111_l1_ (u"ࠨࠩ䛯"),l1l111_l1_ (u"ࠩࠪ䛰"),l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䛱")+l1l11ll1ll11_l1_,l1l111_l1_ (u"ࠫࠬ䛲"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䛳"):l1l11lllll1l_l1_})
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䛴"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䛵"),l1l111_l1_ (u"ࠨࠩ䛶"),9999)
	l1llllll11_l1_ = [l1l111_l1_ (u"ࠩฦๅ้อๅࠨ䛷"),l1l111_l1_ (u"ุ้๊ࠪำๅษอࠫ䛸"),l1l111_l1_ (u"ู๊ࠫัฮ์สฮࠬ䛹"),l1l111_l1_ (u"ࠬฮัศ็ฯࠫ䛺"),l1l111_l1_ (u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬ䛻"),l1l111_l1_ (u"ࠧา็ูห๋࠭䛼"),l1l111_l1_ (u"ࠨละำะ࠳รฯำࠪ䛽"),l1l111_l1_ (u"ࠩึ่ฬูไࠨ䛾"),l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ䛿"),l1l111_l1_ (u"ࠫศฺ็า࠯ฦ็ะืࠧ䜀"),l1l111_l1_ (u"ࠬอไร่ࠪ䜁"),l1l111_l1_ (u"࠭ึฮๅࠪ䜂"),l1l111_l1_ (u"ࠧา์สฺฮ࠭䜃"),l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ䜄"),l1l111_l1_ (u"่้ࠩะ๊๊็ࠩ䜅"),l1l111_l1_ (u"ࠪฬะࠦอ๋ࠩ䜆"),l1l111_l1_ (u"ࠫิ๐ๆ๋หࠪ䜇"),l1l111_l1_ (u"ูࠬๆ้ษอࠫ䜈"),l1l111_l1_ (u"࠭รฯำ์ࠫ䜉")]
	l1l11ll1111l_l1_ = [l1l111_l1_ (u"ࠧศใ็ห๊࠭䜊"),l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ䜋"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ䜌"),l1l111_l1_ (u"ࠪๅ้๋ࠧ䜍")]
	l1ll11lll11_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆࠪ䜎"),l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䜏")]
	l1l1l11llll1_l1_ = [l1l111_l1_ (u"࠭ๅิษิัࠬ䜐"),l1l111_l1_ (u"ࠧๆีิั๏อสࠨ䜑")]
	l1l11ll1l1ll_l1_ = [l1l111_l1_ (u"ࠨสิห๊าࠧ䜒"),l1l111_l1_ (u"ࠩࡶ࡬ࡴࡽࠧ䜓"),l1l111_l1_ (u"ࠪฮ้็า๋๊้ࠫ䜔"),l1l111_l1_ (u"ࠫฯ๊๊โิํ์๋࠭䜕")]
	l1l1l111l1l1_l1_ = [l1l111_l1_ (u"ࠬอๆๆ์ࠪ䜖"),l1l111_l1_ (u"࠭ใาฬ๋๊ࠬ䜗"),l1l111_l1_ (u"ࠧไษิฮํ์ࠧ䜘"),l1l111_l1_ (u"ࠨ࡭࡬ࡨࡸ࠭䜙"),l1l111_l1_ (u"ฺࠩๅ้࠭䜚"),l1l111_l1_ (u"ࠪห฼็วๅࠩ䜛")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠫึ๋ึศ่ࠪ䜜")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠬออะอࠪ䜝"),l1l111_l1_ (u"࠭วฯำࠪ䜞"),l1l111_l1_ (u"ࠧๆ๊ัีࠬ䜟"),l1l111_l1_ (u"ࠨฮา๎ิ࠭䜠"),l1l111_l1_ (u"ฺ่ࠩฬ็ࠧ䜡"),l1l111_l1_ (u"ࠪัิ๐หࠨ䜢")]
	l1l11lll111l_l1_ = [l1l111_l1_ (u"ุ๊ࠫวิๆࠪ䜣"),l1l111_l1_ (u"ูࠬไิๆ๊ࠫ䜤")]
	l1l11l1ll1l1_l1_ = [l1l111_l1_ (u"࠭ว฻ษ้๎ࠬ䜥"),l1l111_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ䜦"),l1l111_l1_ (u"ࠨๅ็๎อ࠭䜧"),l1l111_l1_ (u"ࠩะๅ้࠭䜨"),l1l111_l1_ (u"ࠪࡱࡺࡹࡩࡤࠩ䜩")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠫฬ้หาࠩ䜪"),l1l111_l1_ (u"ࠬอิ่ำࠪ䜫"),l1l111_l1_ (u"࠭ๅๆ์ี๋ࠬ䜬"),l1l111_l1_ (u"ࠧศ฻็ํࠬ䜭"),l1l111_l1_ (u"ࠨ็ัฮฬื็ࠨ䜮"),l1l111_l1_ (u"่ࠩาฯอัศฬࠪ䜯"),l1l111_l1_ (u"ࠪห็๎้ࠨ䜰")]
	l1l11l1ll11l_l1_ = [l1l111_l1_ (u"ࠫฬ๊ว็ࠩ䜱"),l1l111_l1_ (u"ࠬำวๅ์ࠪ䜲"),l1l111_l1_ (u"࠭ๅฬสอࠫ䜳"),l1l111_l1_ (u"ࠧาษษะࠬ䜴")]
	l1l11l1lll1l_l1_ = [l1l111_l1_ (u"ࠨุะ็ࠬ䜵"),l1l111_l1_ (u"ࠩๆ์๊๐ฯ๋ࠩ䜶")]
	l1l1l11l1l11_l1_ = [l1l111_l1_ (u"ࠪี๏อึ่ࠩ䜷"),l1l111_l1_ (u"่ࠫ๎ั่ࠩ䜸"),l1l111_l1_ (u"๋ࠬีศำ฼๋ࠬ䜹"),l1l111_l1_ (u"࠭ิ้ฬࠪ䜺"),l1l111_l1_ (u"ࠧา์สฺฮ࠭䜻")]
	l1l1l1111l1l_l1_ = [l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ䜼"),l1l111_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ䜽"),l1l111_l1_ (u"๊ࠪ๏ะแๅ์ๆืࠬ䜾")]
	l1l11l1lllll_l1_ = [l1l111_l1_ (u"๊๋ࠫหๅ์้ࠫ䜿"),l1l111_l1_ (u"ࠬอิฯษุࠫ䝀"),l1l111_l1_ (u"࠭ๆอ๊่ࠫ䝁")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠧษอࠣั๏࠭䝂"),l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䝃"),l1l111_l1_ (u"ࠩๅ๊ฬํࠧ䝄"),l1l111_l1_ (u"ࠪๆ๋๎วหࠩ䝅")]
	l1l1l111l111_l1_ = [l1l111_l1_ (u"ࠫิ๐ๆࠨ䝆"),l1l111_l1_ (u"ࠬอฯฺ์๊ࠫ䝇"),l1l111_l1_ (u"࠭า๋ษิหฯ࠭䝈"),l1l111_l1_ (u"ࠧๅู่๎ฬะࠧ䝉"),l1l111_l1_ (u"ࠨั฼หฦ࠭䝊"),l1l111_l1_ (u"ࠩๅีฬ์ࠧ䝋"),l1l111_l1_ (u"ࠪๆฺอฦะࠩ䝌"),l1l111_l1_ (u"ࠫึัวยࠩ䝍"),l1l111_l1_ (u"๋ࠬัอ฻ํ๋ࠬ䝎"),l1l111_l1_ (u"࠭วัษ้ࠫ䝏"),l1l111_l1_ (u"ࠧศี็ห๊࠭䝐"),l1l111_l1_ (u"ࠨฬ๋หู๐อࠨ䝑"),l1l111_l1_ (u"ࠩั฻อ࠭䝒"),l1l111_l1_ (u"ࠪัํุ่๋ࠩ䝓"),l1l111_l1_ (u"ࠫ฾ะศศฬࠪ䝔"),l1l111_l1_ (u"๋่ࠬศๆํำࠬ䝕"),l1l111_l1_ (u"࠭ๆ้ษ฼๎ࠬ䝖"),l1l111_l1_ (u"ฺࠧไสสิ࠭䝗"),l1l111_l1_ (u"ࠨษ้หู๐ฯࠨ䝘")]
	l1l11ll111l1_l1_ = [l1l111_l1_ (u"ࠩ࠴࠽ࠬ䝙"),l1l111_l1_ (u"ࠪ࠶࠵࠭䝚"),l1l111_l1_ (u"ࠫ࠷࠷ࠧ䝛"),l1l111_l1_ (u"ࠬ࠸࠲ࠨ䝜"),l1l111_l1_ (u"࠭࠲࠴ࠩ䝝"),l1l111_l1_ (u"ࠧ࠳࠶ࠪ䝞"),l1l111_l1_ (u"ࠨ࠴࠸ࠫ䝟"),l1l111_l1_ (u"ࠩ࠵࠺ࠬ䝠")]
	if not l1l11ll1l11l_l1_:
		l1l11ll1l11l_l1_ = 0
		for l1l11lllll11_l1_ in l1llllll11_l1_:
			l1l11ll1l11l_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝡"),l1lllll_l1_+l1l11lllll11_l1_,l1l111_l1_ (u"ࠫࠬ䝢"),763,l1l111_l1_ (u"ࠬ࠭䝣"),str(l1l11ll1l11l_l1_),l1l11ll1ll11_l1_,l1l111_l1_ (u"࠭ࠧ䝤"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝥"):l1l11lllll1l_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1llllllll1_l1_ = name.lower()
			category = []
			if any(value in l1llllllll1_l1_ for value in l1l11ll1111l_l1_): category.append(1)
			if any(value in l1llllllll1_l1_ for value in l1ll11lll11_l1_): category.append(2)
			if any(value in l1llllllll1_l1_ for value in l1l1l11llll1_l1_): category.append(3)
			if any(value in l1llllllll1_l1_ for value in l1l11ll1l1ll_l1_): category.append(4)
			if any(value in l1llllllll1_l1_ for value in l1l1l111l1l1_l1_): category.append(5)
			if any(value in l1llllllll1_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l1llllllll1_l1_ for value in l1lllll1l_l1_) and l1llllllll1_l1_ not in [l1l111_l1_ (u"ࠨษัี๎࠭䝦")]: category.append(7)
			if any(value in l1llllllll1_l1_ for value in l1l11lll111l_l1_): category.append(8)
			if any(value in l1llllllll1_l1_ for value in l1l11l1ll1l1_l1_): category.append(9)
			if any(value in l1llllllll1_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l1llllllll1_l1_ for value in l1l11l1ll11l_l1_): category.append(11)
			if any(value in l1llllllll1_l1_ for value in l1l11l1lll1l_l1_): category.append(12)
			if any(value in l1llllllll1_l1_ for value in l1l1l11l1l11_l1_): category.append(13)
			if any(value in l1llllllll1_l1_ for value in l1l1l1111l1l_l1_): category.append(14)
			if any(value in l1llllllll1_l1_ for value in l1l11l1lllll_l1_): category.append(15)
			if any(value in l1llllllll1_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l1llllllll1_l1_ for value in l1l1l111l111_l1_): category.append(17)
			if any(value in l1llllllll1_l1_ for value in l1l11ll111l1_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l11ll1l11l_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝧"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠪࠫ䝨"),l1l111_l1_ (u"ࠫࠬ䝩"),l1l11ll1ll11_l1_+l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䝪"))
	return
def l1l1l111lll1_l1_(l1l11lllll1l_l1_,options):
	l1l1ll1lll1_l1_ = False
	if l1l1ll1lll1_l1_:
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䝫"),l1l111_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ䝬"),l1l111_l1_ (u"ࠨࠩ䝭"),764,l1l111_l1_ (u"ࠩࠪ䝮"),l1l111_l1_ (u"ࠪࠫ䝯"),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝰"),l1l111_l1_ (u"ࠬ࠭䝱"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝲"):l1l11lllll1l_l1_})
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䝳"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䝴"),l1l111_l1_ (u"ࠩࠪ䝵"),9999)
	l1l11l1lll11_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l11lllll1l_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l11lllll1l_l1_,True): return
		l1l11lll11l1_l1_ = l1l11lll1111_l1_(l1l11lllll1l_l1_,options)
		l111l1l111_l1_ = sorted(l1l11lll11l1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䝶"),True): return
		if l1l1ll1lll1_l1_ and l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝷") not in options:
			l111l1l111_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䝸"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭䝹"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫ䝺"))
		else:
			l1l11ll111ll_l1_,l111l1l111_l1_,l1l11lll11l1_l1_ = [],[],[]
			for l1l11llll1l1_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l111_l1_ += l1l11lll1111_l1_(str(l1l11llll1l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in l111l1l111_l1_:
				if text not in l1l11ll111ll_l1_:
					l1l11ll111ll_l1_.append(text)
					l1l1l11l1ll1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll111_l1_
					l1l11lll11l1_l1_.append(l1l1l11l1ll1_l1_)
			l111l1l111_l1_ = sorted(l1l11lll11l1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1ll1lll1_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䝻"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭䝼"),l111l1l111_l1_,l1ll111l11l_l1_)
	menuItemsLIST[:] = l1l11l1lll11_l1_+l111l1l111_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䝽"))
	return
def l1l1l11ll111_l1_(l1l11lllll1l_l1_,options):
	l1l1ll1lll1_l1_ = False
	if l1l1ll1lll1_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䝾"),l1l111_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ䝿"),l1l111_l1_ (u"࠭ࠧ䞀"),765,l1l111_l1_ (u"ࠧࠨ䞁"),l1l111_l1_ (u"ࠨࠩ䞂"),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䞃"),l1l111_l1_ (u"ࠪࠫ䞄"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䞅"):l1l11lllll1l_l1_})
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䞆"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䞇"),l1l111_l1_ (u"ࠧࠨ䞈"),9999)
	l1l11l1lll11_l1_ = menuItemsLIST[:]
	import M3U
	if l1l11lllll1l_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l11lllll1l_l1_,True): return
		l1l11lll11l1_l1_ = l1l11lllllll_l1_(l1l11lllll1l_l1_,options)
		l111l1l111_l1_ = sorted(l1l11lll11l1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䞉"),True): return
		if l1l1ll1lll1_l1_ and l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䞊") not in options:
			l111l1l111_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䞋"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ䞌"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨ䞍"))
		else:
			l1l11ll111ll_l1_,l111l1l111_l1_,l1l11lll11l1_l1_ = [],[],[]
			for l1l11llll1l1_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l111_l1_ += l1l11lllllll_l1_(str(l1l11llll1l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in l111l1l111_l1_:
				if text not in l1l11ll111ll_l1_:
					l1l11ll111ll_l1_.append(text)
					l1l1l11l1ll1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll111_l1_
					l1l11lll11l1_l1_.append(l1l1l11l1ll1_l1_)
			l111l1l111_l1_ = sorted(l1l11lll11l1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1ll1lll1_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ䞎"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪ䞏"),l111l1l111_l1_,l1ll111l11l_l1_)
	menuItemsLIST[:] = l1l11l1lll11_l1_+l111l1l111_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䞐"))
	return
def l1l11ll11lll_l1_(group,options):
	l1l1ll1lll1_l1_ = False
	l1lll_l1_ = []
	l1l11llllll1_l1_ = l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䞑") if l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ䞒") in options else l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䞓")
	if l1l1ll1lll1_l1_: l1lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䞔"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ䞕")+l1l11llllll1_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1ll1lll1_l1_: l1lll_l1_ += l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䞖"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䞗")+l1l11llllll1_l1_[:-1],l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ䞘")+l1l11llllll1_l1_+str(l1l11lllll1l_l1_))
			elif l1l11llllll1_l1_==l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䞙"): l1lll_l1_ += l1l11lll1111_l1_(str(l1l11lllll1l_l1_),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䞚"))
			elif l1l11llllll1_l1_==l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䞛"): l1lll_l1_ += l1l11lllllll_l1_(str(l1l11lllll1l_l1_),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䞜"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in l1lll_l1_:
			if text==group: l1ll1l1111l1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in menuItemsLIST:
			l1l1l1111lll_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠧࠨ䞝")
			if l1l1l1111lll_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1l1111lll_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1ll1lll1_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䞞")+l1l11llllll1_l1_[:-1],group,l1lll_l1_,l1ll111l11l_l1_)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䞟") in options and len(l1lll_l1_)>l1l1l11l1111_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䞠"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䞡")+group+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䞢"),group,165,l1l111_l1_ (u"࠭ࠧ䞣"),l1l111_l1_ (u"ࠧࠨ䞤"),l1l11llllll1_l1_+l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䞥"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䞦"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䞧"),group,165,l1l111_l1_ (u"ࠫࠬ䞨"),l1l111_l1_ (u"ࠬ࠭䞩"),l1l11llllll1_l1_+l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞪"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䞫"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䞬"),l1l111_l1_ (u"ࠩࠪ䞭"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1l11l1111_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䞮"))
	return
def l1l1l11lllll_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䞯"),l1l111_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไ้์ฬะฺࠠึ๋หห๐ษࠨ䞰"),l1l111_l1_ (u"࠭ࠧ䞱"),161,l1l111_l1_ (u"ࠧࠨ䞲"),l1l111_l1_ (u"ࠨࠩ䞳"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ䞴"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䞵"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䞶"),l1l111_l1_ (u"ࠬ࠭䞷"),9999)
	l1l1l111ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1lll1ll1l1l_l1_
	l1lll1ll1l1l_l1_.ITEMS(l1l111_l1_ (u"࠭࠰ࠨ䞸"),False)
	l1lll1ll1l1l_l1_.ITEMS(l1l111_l1_ (u"ࠧ࠲ࠩ䞹"),False)
	l1lll1ll1l1l_l1_.ITEMS(l1l111_l1_ (u"ࠨ࠴ࠪ䞺"),False)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䞻") in options:
		menuItemsLIST[:] = l1l11lll1ll1_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l11l1111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1111_l1_)
	menuItemsLIST[:] = l1l1l111ll1l_l1_+menuItemsLIST
	return
def l1l1l11lll1l_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞼"),l1l111_l1_ (u"ࠫࠬ䞽")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞾"),l1l111_l1_ (u"࠭ࠧ䞿"))
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䟀") : l1l111_l1_ (u"ࠨࠩ䟁") }
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨ䟂")
	data = {l1l111_l1_ (u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬ䟃"):l1l111_l1_ (u"ࠫ࠺࠶ࠧ䟄")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1lll11l1l1l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䟅"),url,data,headers,l1l111_l1_ (u"࠭ࠧ䟆"),l1l111_l1_ (u"ࠧࠨ䟇"),l1l111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔ࠯ࡕࡅࡓࡊࡏࡎࡡ࡙ࡍࡉࡋࡏࡔࡡࡉࡖࡔࡓ࡟ࡘࡑࡕࡈࡘ࠳࠱ࡴࡶࠪ䟈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫ䟉"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ䟊"),block,re.DOTALL)
	l1l11l1l1lll_l1_,l1l11ll11l11_l1_ = list(zip(*items))
	l1l1l11l1lll_l1_ = []
	l1l1l11lll11_l1_ = [l1l111_l1_ (u"ࠫࠥ࠭䟋"),l1l111_l1_ (u"ࠬࠨࠧ䟌"),l1l111_l1_ (u"࠭ࡠࠨ䟍"),l1l111_l1_ (u"ࠧ࠭ࠩ䟎"),l1l111_l1_ (u"ࠨ࠰ࠪ䟏"),l1l111_l1_ (u"ࠩ࠽ࠫ䟐"),l1l111_l1_ (u"ࠪ࠿ࠬ䟑"),l1l111_l1_ (u"ࠦࠬࠨ䟒"),l1l111_l1_ (u"ࠬ࠳ࠧ䟓")]
	l1l11ll1ll1l_l1_ = l1l11ll11l11_l1_+l1l11l1l1lll_l1_
	for word in l1l11ll1ll1l_l1_:
		if word in l1l11ll11l11_l1_: l1l1l1111l11_l1_ = 2
		if word in l1l11l1l1lll_l1_: l1l1l1111l11_l1_ = 4
		l1l11ll1llll_l1_ = [i in word for i in l1l1l11lll11_l1_]
		if any(l1l11ll1llll_l1_):
			index = l1l11ll1llll_l1_.index(True)
			l1l11ll1l1l1_l1_ = l1l1l11lll11_l1_[index]
			l1l1l11l11l1_l1_ = l1l111_l1_ (u"࠭ࠧ䟔")
			if word.count(l1l11ll1l1l1_l1_)>1: l1l1l11l11ll_l1_,l1l1l11l111l_l1_,l1l1l11l11l1_l1_ = word.split(l1l11ll1l1l1_l1_,2)
			else: l1l1l11l11ll_l1_,l1l1l11l111l_l1_ = word.split(l1l11ll1l1l1_l1_,1)
			if len(l1l1l11l11ll_l1_)>l1l1l1111l11_l1_: l1l1l11l1lll_l1_.append(l1l1l11l11ll_l1_.lower())
			if len(l1l1l11l111l_l1_)>l1l1l1111l11_l1_: l1l1l11l1lll_l1_.append(l1l1l11l111l_l1_.lower())
			if len(l1l1l11l11l1_l1_)>l1l1l1111l11_l1_: l1l1l11l1lll_l1_.append(l1l1l11l11l1_l1_.lower())
		elif len(word)>l1l1l1111l11_l1_: l1l1l11l1lll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1l11l1lll_l1_)
	if l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䟕") in options:
		l1l11l1llll1_l1_ = l1ll1ll1111l_l1_
	elif l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䟖") in options:
		l1l11l1llll1_l1_ = [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ䟗")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䟘"),True): return
	elif l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䟙") in options:
		l1l11l1llll1_l1_ = [l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ䟚")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䟛"),True): return
	count,l1l11ll11l1l_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䟜"),l1l111_l1_ (u"ࠨ࡝ࠣࠤࡢࠦ࠺ศๆหัะูࠦ็ࠩ䟝"),l1l111_l1_ (u"ࠩࠪ䟞"),164,l1l111_l1_ (u"ࠪࠫ䟟"),l1l111_l1_ (u"ࠫࠬ䟠"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟡")+options)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟢"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅสะฯࠥอไฺึ๋หห๐ࠧ䟣"),l1l111_l1_ (u"ࠨࠩ䟤"),164,l1l111_l1_ (u"ࠩࠪ䟥"),l1l111_l1_ (u"ࠪࠫ䟦"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䟧")+options)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䟨"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䟩"),l1l111_l1_ (u"ࠧࠨ䟪"),9999)
	l1l11l1l1ll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l11ll1ll_l1_ = []
	for word in l1l1l11l1lll_l1_:
		l1l1l11l111l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀࠨ䟫")+l1l111_l1_ (u"ࠩࠦࠫ䟬")+l1l111_l1_ (u"ࠪࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧ䟭"),word,re.DOTALL)
		if l1l1l11l111l_l1_: word = word.split(l1l1l11l111l_l1_[0],1)[0]
		l1l1l111l1ll_l1_ = word.replace(l1l111_l1_ (u"ࠫ๖࠭䟮"),l1l111_l1_ (u"ࠬ࠭䟯")).replace(l1l111_l1_ (u"࠭๎ࠨ䟰"),l1l111_l1_ (u"ࠧࠨ䟱")).replace(l1l111_l1_ (u"ࠨํࠪ䟲"),l1l111_l1_ (u"ࠩࠪ䟳")).replace(l1l111_l1_ (u"ࠪ๓ࠬ䟴"),l1l111_l1_ (u"ࠫࠬ䟵")).replace(l1l111_l1_ (u"ࠬ๒ࠧ䟶"),l1l111_l1_ (u"࠭ࠧ䟷"))
		l1l1l111l1ll_l1_ = l1l1l111l1ll_l1_.replace(l1l111_l1_ (u"ࠧ๑ࠩ䟸"),l1l111_l1_ (u"ࠨࠩ䟹")).replace(l1l111_l1_ (u"ࠩ๐ࠫ䟺"),l1l111_l1_ (u"ࠪࠫ䟻")).replace(l1l111_l1_ (u"ࠫ๗࠭䟼"),l1l111_l1_ (u"ࠬ࠭䟽")).replace(l1l111_l1_ (u"࠭ฌࠨ䟾"),l1l111_l1_ (u"ࠧࠨ䟿")).replace(l1l111_l1_ (u"ࠨโࠪ䠀"),l1l111_l1_ (u"ࠩࠪ䠁"))
		if l1l1l111l1ll_l1_: l1l1l11ll1ll_l1_.append(l1l1l111l1ll_l1_)
	l1l1l111l11l_l1_ = []
	for l1l111lll1_l1_ in range(0,20):
		search = random.sample(l1l1l11ll1ll_l1_,1)[0]
		if search in l1l1l111l11l_l1_: continue
		l1l1l111l11l_l1_.append(search)
		l1lll11l1l1_l1_ = random.sample(l1l11l1llll1_l1_,1)[0]
		l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䠂"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧ䠃")+str(l1lll11l1l1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨ䠄")+search)
		l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_ = l1ll1llll11_l1_(l1lll11l1l1_l1_)
		l1lll11l11l_l1_(search+l1l111_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ䠅"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䠆"),l1l111_l1_ (u"ࠨࠩ䠇"))
	l1l11l1l1ll1_l1_[0][1] = l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䠈")+search+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀศฮอࠣ฽๋ࡣࠧ䠉")
	menuItemsLIST[:] = l1l11lll1ll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l11l1111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1111_l1_)
	menuItemsLIST[:] = l1l11l1l1ll1_l1_+menuItemsLIST
	return
def l1l1l11l1l1l_l1_(l1l11ll1l111_l1_,options):
	l1l11ll1l111_l1_ = l1l11ll1l111_l1_.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䠊"),l1l111_l1_ (u"ࠬ࠭䠋"))
	options = options.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠌"),l1l111_l1_ (u"ࠧࠨ䠍")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠎"),l1l111_l1_ (u"ࠩࠪ䠏"))
	l1l11llll1ll_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䠐") in options:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䠑"),l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䠒")+l1l11ll1l111_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ䠓"),l1l11ll1l111_l1_,166,l1l111_l1_ (u"ࠧࠨ䠔"),l1l111_l1_ (u"ࠨࠩ䠕"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠖")+options)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠗"),l1l111_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䠘"),l1l11ll1l111_l1_,166,l1l111_l1_ (u"ࠬ࠭䠙"),l1l111_l1_ (u"࠭ࠧ䠚"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠛")+options)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䠜"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䠝"),l1l111_l1_ (u"ࠪࠫ䠞"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l11ll1l111_l1_].keys())):
		type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = contentsDICT[l1l11ll1l111_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䠟") in options or len(contentsDICT[l1l11ll1l111_l1_])==1:
			l1ll1l1111l1_l1_(type,l1l111_l1_ (u"ࠬ࠭䠠"),url,l1ll1ll11ll1_l1_,l1l111_l1_ (u"࠭ࠧ䠡"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠧࠨ䠢"),l1l111_l1_ (u"ࠨࠩ䠣"))
			menuItemsLIST[:] = l1l11lll1ll1_l1_(menuItemsLIST)
			l1l11l1lll11_l1_,l111l1l111_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1l111_l1_)
			if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䠤") in options: menuItemsLIST[:] = l1l11l1lll11_l1_+l111l1l111_l1_[:l1l1l11l1111_l1_]
			else: menuItemsLIST[:] = l1l11l1lll11_l1_+l111l1l111_l1_
		elif l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䠥") in options: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䠦"),l1l11l11_l1_,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_)
	return
def l1l11lll11ll_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠧"),l1l111_l1_ (u"࠭ࠧ䠨")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠩"),l1l111_l1_ (u"ࠨࠩ䠪"))
	name,l1l11ll1lll1_l1_ = l1l111_l1_ (u"ࠩࠪ䠫"),[]
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠬"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䠭")+name+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䠮"),l1l111_l1_ (u"࠭ࠧ䠯"),mode,l1l111_l1_ (u"ࠧࠨ䠰"),l1l111_l1_ (u"ࠨࠩ䠱"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠲")+options)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠳"),l1l111_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫ䠴"),l1l111_l1_ (u"ࠬ࠭䠵"),mode,l1l111_l1_ (u"࠭ࠧ䠶"),l1l111_l1_ (u"ࠧࠨ䠷"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䠸")+options)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䠹"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䠺"),l1l111_l1_ (u"ࠫࠬ䠻"),9999)
	l1l11l1lll11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䠼") in options:
		l1l11llll1ll_l1_(False)
		if contentsDICT=={}: return
		l1l11lll1l1l_l1_ = list(contentsDICT.keys())
		l1l11ll1l111_l1_ = random.sample(l1l11lll1l1l_l1_,1)[0]
		l1l1l11l1lll_l1_ = list(contentsDICT[l1l11ll1l111_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1l11l1lll_l1_,1)[0]
		type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = contentsDICT[l1l11ll1l111_l1_][l1l11l11_l1_]
		l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䠽"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪ䠾")+l1l11l11_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䠿")+name+l1l111_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䡀")+url+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䡁")+str(l1ll1ll11ll1_l1_))
	elif l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䡂") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䡃"),True): return
		for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11lll1111_l1_(str(l1l11lllll1l_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = random.sample(l1lll_l1_,1)[0]
		l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䡄"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䡅")+name+l1l111_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䡆")+url+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䡇")+str(l1ll1ll11ll1_l1_))
	elif l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䡈") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䡉"),True): return
		for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11lllllll_l1_(str(l1l11lllll1l_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = random.sample(l1lll_l1_,1)[0]
		l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䡊"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䡋")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䡌")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䡍")+str(l1ll1ll11ll1_l1_))
	l1l1l1111ll1_l1_ = name
	l1l11llll111_l1_ = []
	for i in range(0,10):
		if i>0: l11llllll1_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䡎"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䡏")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䡐")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䡑")+str(l1ll1ll11ll1_l1_))
		menuItemsLIST[:] = []
		if l1ll1ll11ll1_l1_==234 and l1l111_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡒") in text: l1ll1ll11ll1_l1_ = 233
		if l1ll1ll11ll1_l1_==714 and l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡓") in text: l1ll1ll11ll1_l1_ = 713
		if l1ll1ll11ll1_l1_==144: l1ll1ll11ll1_l1_ = 291
		dummy = l1ll1l1111l1_l1_(type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_)
		if l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䡔") in options and l1ll1ll11ll1_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䡕") in options and l1ll1ll11ll1_l1_==168: del menuItemsLIST[:3]
		l1l11ll1lll1_l1_[:] = l1l11lll1ll1_l1_(menuItemsLIST)
		if l1l11llll111_l1_ and l111l1lllll_l1_(l1l111_l1_ (u"ࡸࠫา๊โสࠩ䡖")) in str(l1l11ll1lll1_l1_) or l111l1lllll_l1_(l1l111_l1_ (u"ࡹࠬำไใ้ࠪ䡗")) in str(l1l11ll1lll1_l1_):
			name = l1l1l1111ll1_l1_
			l1l11ll1lll1_l1_[:] = l1l11llll111_l1_
			break
		l1l1l1111ll1_l1_ = name
		l1l11llll111_l1_ = l1l11ll1lll1_l1_
		if str(l1l11ll1lll1_l1_).count(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䡘"))>0: break
		if str(l1l11ll1lll1_l1_).count(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䡙"))>0: break
		if l1ll1ll11ll1_l1_==233: break
		if l1ll1ll11ll1_l1_==713: break
		if l1ll1ll11ll1_l1_==291: break
		if l1l11ll1lll1_l1_: type,name,url,l1ll1ll11ll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = random.sample(l1l11ll1lll1_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠧ࠯࠰࠱࠲ࠬ䡚")
	elif name.count(l1l111_l1_ (u"ࠨࡡࠪ䡛"))>1: name = name.split(l1l111_l1_ (u"ࠩࡢࠫ䡜"),2)[2]
	name = name.replace(l1l111_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭䡝"),l1l111_l1_ (u"ࠫࠬ䡞"))
	name = name.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䡟"),l1l111_l1_ (u"࠭ࠧ䡠"))
	l1l11l1lll11_l1_[0][1] = l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䡡")+name+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䡢")
	for i in range(9): random.shuffle(l1l11ll1lll1_l1_)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䡣") in options: menuItemsLIST[:] = l1l11l1lll11_l1_+l1l11ll1lll1_l1_[:l1l1l11l1111_l1_]
	else: menuItemsLIST[:] = l1l11l1lll11_l1_+l1l11ll1lll1_l1_
	return
def l1l11ll11ll1_l1_(l1l11l1ll111_l1_,l1l1l111llll_l1_):
	l1l1l111llll_l1_ = l1l1l111llll_l1_.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡤"),l1l111_l1_ (u"ࠫࠬ䡥")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡦"),l1l111_l1_ (u"࠭ࠧ䡧"))
	l1l11lll1l11_l1_ = l1l1l111llll_l1_
	if l1l111_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䡨") in l1l1l111llll_l1_:
		l1l11lll1l11_l1_ = l1l1l111llll_l1_.split(l1l111_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䡩"))[0]
		type = l1l111_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䡪")
	elif l1l111_l1_ (u"࡚ࠪࡔࡊࠧ䡫") in l1l11l1ll111_l1_: type = l1l111_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ䡬")
	elif l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ䡭") in l1l11l1ll111_l1_: type = l1l111_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ䡮")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䡯"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䡰")+type+l1l11lll1l11_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䡱"),l1l11l1ll111_l1_,167,l1l111_l1_ (u"ࠪࠫ䡲"),l1l111_l1_ (u"ࠫࠬ䡳"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡴")+l1l1l111llll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡵"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䡶"),l1l11l1ll111_l1_,167,l1l111_l1_ (u"ࠨࠩ䡷"),l1l111_l1_ (u"ࠩࠪ䡸"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡹")+l1l1l111llll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䡺"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䡻"),l1l111_l1_ (u"࠭ࠧ䡼"),9999)
	import IPTV
	for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䡽") in l1l1l111llll_l1_: IPTV.GROUPS(str(l1l11lllll1l_l1_),l1l11l1ll111_l1_,l1l1l111llll_l1_,l1l111_l1_ (u"ࠨࠩ䡾"),False)
		else: IPTV.ITEMS(str(l1l11lllll1l_l1_),l1l11l1ll111_l1_,l1l1l111llll_l1_,l1l111_l1_ (u"ࠩࠪ䡿"),False)
	menuItemsLIST[:] = l1l11lll1ll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1111_l1_)
	return
def l1l11l1ll1ll_l1_(l1l11l1ll111_l1_,l1l1l111llll_l1_):
	l1l1l111llll_l1_ = l1l1l111llll_l1_.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䢀"),l1l111_l1_ (u"ࠫࠬ䢁")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䢂"),l1l111_l1_ (u"࠭ࠧ䢃"))
	l1l11lll1l11_l1_ = l1l1l111llll_l1_
	if l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䢄") in l1l1l111llll_l1_:
		l1l11lll1l11_l1_ = l1l1l111llll_l1_.split(l1l111_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䢅"))[0]
		type = l1l111_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䢆")
	elif l1l111_l1_ (u"࡚ࠪࡔࡊࠧ䢇") in l1l11l1ll111_l1_: type = l1l111_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ䢈")
	elif l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ䢉") in l1l11l1ll111_l1_: type = l1l111_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ䢊")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䢋"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䢌")+type+l1l11lll1l11_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䢍"),l1l11l1ll111_l1_,168,l1l111_l1_ (u"ࠪࠫ䢎"),l1l111_l1_ (u"ࠫࠬ䢏"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䢐")+l1l1l111llll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䢑"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䢒"),l1l11l1ll111_l1_,168,l1l111_l1_ (u"ࠨࠩ䢓"),l1l111_l1_ (u"ࠩࠪ䢔"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䢕")+l1l1l111llll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䢖"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䢗"),l1l111_l1_ (u"࠭ࠧ䢘"),9999)
	import M3U
	for l1l11lllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䢙") in l1l1l111llll_l1_: M3U.GROUPS(str(l1l11lllll1l_l1_),l1l11l1ll111_l1_,l1l1l111llll_l1_,l1l111_l1_ (u"ࠨࠩ䢚"),False)
		else: M3U.ITEMS(str(l1l11lllll1l_l1_),l1l11l1ll111_l1_,l1l1l111llll_l1_,l1l111_l1_ (u"ࠩࠪ䢛"),False)
	menuItemsLIST[:] = l1l11lll1ll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1111_l1_)
	return
def l1l11lll1ll1_l1_(menuItemsLIST):
	l1l11ll1lll1_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ูࠪๆำษࠨ䢜") in name or l1l111_l1_ (u"ฺࠫ็อ่ࠩ䢝") in name or l1l111_l1_ (u"ࠬࡶࡡࡨࡧࠪ䢞") in name.lower(): continue
		l1l11ll1lll1_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_])
	return l1l11ll1lll1_l1_
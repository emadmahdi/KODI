# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l111l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡉࡏࡋࡗࠫ揢")
l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ揣"),l1l111_l1_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࠭揤"))
l1lll111ll1_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = l1lll111ll1_l1_
l1ll1ll11l1l_l1_ = int(mode)
l1lll1ll1ll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ揥"))
l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_.replace(ltr,l1l111_l1_ (u"ࠪࠫ揦")).replace(rtl,l1l111_l1_ (u"ࠫࠬ揧"))
if l1ll1ll11l1l_l1_==260: message = l1l111_l1_ (u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭揨")+l1l11l1l1l1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭揩")+l1l1l11ll11_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ揪")
else:
	l111l1l1ll11_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ揫"),l1l111_l1_ (u"ࠩࠪ揬")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭揭"),l1l111_l1_ (u"ࠫࠬ揮"))
	l111l1l1ll11_l1_ = l111l1l1ll11_l1_.replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ揯"),l1l111_l1_ (u"࠭ࠧ揰")).strip(l1l111_l1_ (u"ࠧࠡࠩ揱"))
	l111l1l1ll11_l1_ = l111l1l1ll11_l1_.replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭揲"),l1l111_l1_ (u"ࠩࠣࠫ揳")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ援"),l1l111_l1_ (u"ࠫࠥ࠭揵")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ揶"),l1l111_l1_ (u"࠭ࠠࠨ揷"))
	message = l1l111_l1_ (u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭揸")+l1lll1ll1ll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨ揹")+mode+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ揺")+l111l1l1ll11_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭揻")
l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ揼"),l11llll11l_l1_(l1ll1_l1_)+message)
l1ll1l1l1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ揽"))
l111l111ll1_l1_ = False if l1ll1l1l1l1l_l1_==l1l11l1l1l1_l1_ else True
if not l111l111ll1_l1_ and l1ll1ll11l1l_l1_ in [235,715]:
	l1l11lllll1l_l1_ = str(l1llllll111_l1_[l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭揾")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ揿") if l1ll1ll11l1l_l1_==235 else l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ搀")
	l11ll11lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࠭搁")+l1ll1_l1_+l1l111_l1_ (u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ搂")+l1l11lllll1l_l1_)
	l11lll11ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࠨ搃")+l1ll1_l1_+l1l111_l1_ (u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨ搄")+l1l11lllll1l_l1_)
	if l11ll11lll_l1_ or l11lll11ll_l1_:
		url += l1l111_l1_ (u"࠭ࡼࠨ搅")
		if l11ll11lll_l1_: url += l1l111_l1_ (u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭搆")+l11ll11lll_l1_
		if l11lll11ll_l1_: url += l1l111_l1_ (u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ搇")+l11lll11ll_l1_
		url = url.replace(l1l111_l1_ (u"ࠩࡿࠪࠬ搈"),l1l111_l1_ (u"ࠪࢀࠬ搉"))
	l11l11l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࠨ搊")+l1ll1_l1_+l1l111_l1_ (u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ搋")+l1l11lllll1l_l1_)
	if l11l11l11l_l1_:
		l111l1l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩ搌"),url,re.DOTALL)
		url = url.replace(l111l1l1ll1l_l1_[0],l11l11l11l_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll1l11l1_l1_,l111111l111_l1_,l1ll1lll1l11_l1_
	l1111ll1l11_l1_ = l1l111_l1_ (u"ࠧࠨ損")
	l11ll1l11l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ搎"))
	try: l111111l111_l1_(l1lll111ll1_l1_,l1lll1ll1ll1_l1_)
	except Exception as error: l1111ll1l11_l1_ = traceback.format_exc()
	l11ll1l11l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡴࡶࠧ搏"))
	l1ll1lll1l11_l1_(l1111ll1l11_l1_)
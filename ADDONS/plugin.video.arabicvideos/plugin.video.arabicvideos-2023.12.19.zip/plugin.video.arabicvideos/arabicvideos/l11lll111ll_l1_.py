# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ岀")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭岁")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111ll11ll11_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l111ll11l1l1_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l111lll1ll11_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l111ll1lll1l_l1_()
	elif mode==148: l1lll_l1_ = l111ll1lllll_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岂"),l1lllll_l1_+l1l111_l1_ (u"ࠩๅหห๋ษࠨ岃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ岄"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岅"),l1lllll_l1_+l1l111_l1_ (u"ฺࠬฮึࠩ岆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ岇"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岈"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ๆ฾࠭岉"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ岊"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),l1lllll_l1_+l1l111_l1_ (u"ࠫาูวษࠩ岌"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭岍"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岎"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ฼หอ࠭岏"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ岐"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岑"),l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠩ岒"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ岓"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岔"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะࠧ岕"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭岖"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岗"),l1lllll_l1_+l1l111_l1_ (u"ࠩๅู๏ืษࠨ岘"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ岙"),144,l1l111_l1_ (u"ࠫࠬ岚"),l1l111_l1_ (u"ࠬ࠭岛"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ岜"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岝"),l1lllll_l1_+l1l111_l1_ (u"ࠨฬุๅา࠭岞"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ岟"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岠"),l1lllll_l1_+l1l111_l1_ (u"ࠫึฬ๊ิ์ฬࠫ岡"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠭岢"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岣"),l1lllll_l1_+l1l111_l1_ (u"ࠧาษษะࠬ岤"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭岥"),144)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ岦"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ岧"),l1l111_l1_ (u"ࠫࠬ岨"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岩"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭岪"),l1l111_l1_ (u"ࠧࠨ岫"),149,l1l111_l1_ (u"ࠨࠩ岬"),l1l111_l1_ (u"ࠩࠪ岭"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ岮"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ岯"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ岰"),l1l111_l1_ (u"࠭ࠧ岱"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岲"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ岳"),l111l1_l1_+l1l111_l1_ (u"ࠩࠪ岴"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岵"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ัศศฯอࠬ岶"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭岷"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岸"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆอูๆำࠧ岹"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ岺"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岻"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้่ี๋ำฬࠫ岼"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ岽"),144,l1l111_l1_ (u"ࠬ࠭岾"),l1l111_l1_ (u"࠭ࠧ岿"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ峀"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峁"),l1lllll_l1_+l1l111_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ峂"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ峃"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峄"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ峅"),l1l111_l1_ (u"࠭ࠧ峆"),290)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ峇"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ峈"),l1l111_l1_ (u"ࠩࠪ峉"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峊"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ峋"),l1l111_l1_ (u"ࠬ࠭峌"),147)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峍"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ峎"),l1l111_l1_ (u"ࠨࠩ峏"),148)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峐"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭峑"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ峒"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峓"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ峔"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ峕"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峖"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ峗"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ峘"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峙"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ峚"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ峛"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峜"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ峝"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ峞"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峟"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ峠"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ峡"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峢"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ峣"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ峤"),144)
	return
def l111ll11l1l1_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峥"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ峦")+name,url,144,l11l_l1_)
	return
def l111ll1lll1l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ峧"))
	return
def l111ll1lllll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ峨"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"࠭ࠦࠨ峩"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111ll1l1ll1_l1_(yccc,url,index):
	level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ峪"))
	l111ll11l111_l1_,l111ll1l1lll_l1_ = [],[]
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ峫") in url: l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝ࠣ峬"))
	if l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ峭") in url: l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠࠦ峮"))
	if level==l1l111_l1_ (u"ࠬ࠷ࠧ峯"): l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ峰"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ峱"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠࠦ峲"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡧࡱࡸࡷ࡯ࡥࡴࠩࡠࠦ峳"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟࡞࠷ࡢࡡࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ峴"))
	l111lll111l1_l1_,yddd,l111ll1l1l1l_l1_ = l111ll111ll1_l1_(yccc,l1l111_l1_ (u"ࠫࠬ峵"),l111ll11l111_l1_)
	if level==l1l111_l1_ (u"ࠬ࠷ࠧ島") and l111lll111l1_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ峷") not in url:
			for zz in range(len(yddd)):
				l111ll11llll_l1_ = str(zz)
				l111ll11l111_l1_ = []
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ峸")+l111ll11llll_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ峹"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ峺")+l111ll11llll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࠧ࡞ࠤ峻"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ峼")+l111ll11llll_l1_+l1l111_l1_ (u"ࠧࡣࠢ峽"))
				succeeded,item,l1111ll1_l1_ = l111ll111ll1_l1_(yddd,l1l111_l1_ (u"࠭ࠧ峾"),l111ll11l111_l1_)
				if succeeded: l111ll1l1lll_l1_.append([item,url,l1l111_l1_ (u"ࠧ࠳࠼࠽ࠫ峿")+l111ll11llll_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ崀")])
			l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟ࠥ崁"))
			succeeded,item,l1111ll1_l1_ = l111ll111ll1_l1_(yccc,l1l111_l1_ (u"ࠪࠫ崂"),l111ll11l111_l1_)
			if succeeded and l111ll1l1lll_l1_ and l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪ崃") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ崄")
				l111ll1l1lll_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ崅")])
	return yddd,l111lll111l1_l1_,l111ll1l1lll_l1_,l111ll1l1l1l_l1_
def l111ll1111ll_l1_(yccc,yddd,url,index):
	level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ崆"))
	l111ll11l111_l1_,l111ll1ll111_l1_ = [],[]
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崇"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崈")+l111ll11llll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ崉"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝࠴ࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ崊"))
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ崋") in url: l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ崌"))
	elif l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭崍") in url: l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崎"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崏")+l111ll11llll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崐"))
	if l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ崑") in url or (l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭崒") in url and l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ崓") not in url):
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ崔")+l111ll11llll_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崕"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崖")+l111ll11llll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ崗"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崘")+l111ll11llll_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡢࡤ࡯ࡩ࡙ࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ崙"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崚")+l111ll11llll_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ崛"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ崜")+l111ll11llll_l1_+l1l111_l1_ (u"ࠤࡠࠦ崝"))
	l111lll11111_l1_,yeee,l111ll1l1l11_l1_ = l111ll111ll1_l1_(yddd,l1l111_l1_ (u"ࠪࠫ崞"),l111ll11l111_l1_)
	if level==l1l111_l1_ (u"ࠫ࠷࠭崟") and l111lll11111_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l111ll11l111_l1_ = []
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崠")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ崡"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崢")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ崣"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崤")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ崥"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崦")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ崧"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崨")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ崩"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崪")+index2+l1l111_l1_ (u"ࠤࡠࠦ崫"))
				succeeded,item,l1111ll1_l1_ = l111ll111ll1_l1_(yeee,l1l111_l1_ (u"ࠪࠫ崬"),l111ll11l111_l1_)
				if succeeded: l111ll1ll111_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠸ࡀ࠺ࠨ崭")+l111ll11llll_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ崮")+index2+l1l111_l1_ (u"࠭࠺࠻࠲ࠪ崯")])
			l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ崰"))
			l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠱࡞ࠤ崱"))
			succeeded,item,l1111ll1_l1_ = l111ll111ll1_l1_(yddd,l1l111_l1_ (u"ࠩࠪ崲"),l111ll11l111_l1_)
			if succeeded and l111ll1ll111_l1_ and l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ崳") in list(item.keys()):
				l111ll1ll111_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ崴")])
	return yeee,l111lll11111_l1_,l111ll1ll111_l1_,l111ll1l1l11_l1_
def l111ll11l1ll_l1_(yccc,yeee,url,index):
	level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ崵"))
	l111ll11l111_l1_,l111ll11ll1l_l1_ = [],[]
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崶")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡺࡪࡸࡴࡪࡥࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崷"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崸")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崹"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崺")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崻"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崼")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崽"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崾")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崿"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ嵀")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嵁"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嵂")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ嵃"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嵄")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嵅"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嵆"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嵇"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嵈"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嵉")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嵊"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嵋")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嵌"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࠨ嵍"))
	l111lll11l11_l1_,yfff,l111lll1lll1_l1_ = l111ll111ll1_l1_(yeee,l1l111_l1_ (u"ࠩࠪ嵎"),l111ll11l111_l1_)
	if level==l1l111_l1_ (u"ࠪ࠷ࠬ嵏") and l111lll11l11_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l111ll1l111l_l1_ = str(zz)
				l111ll11l111_l1_ = []
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾ࡬ࡦࡧ࡝ࠥ嵐")+l111ll1l111l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ嵑"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡧࡨࡩ࡟ࠧ嵒")+l111ll1l111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ嵓"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ嵔")+l111ll1l111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ嵕"))
				l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ嵖")+l111ll1l111l_l1_+l1l111_l1_ (u"ࠦࡢࠨ嵗"))
				succeeded,item,l1111ll1_l1_ = l111ll111ll1_l1_(yfff,l1l111_l1_ (u"ࠬ࠭嵘"),l111ll11l111_l1_)
				if succeeded: l111ll11ll1l_l1_.append([item,url,l1l111_l1_ (u"࠭࠴࠻࠼ࠪ嵙")+l111ll11llll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵚")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵛")+l111ll1l111l_l1_])
	return yfff,l111lll11l11_l1_,l111ll11ll1l_l1_,l111lll1lll1_l1_
def l111ll111ll1_l1_(l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l111ll11lll1_l1_):
	yccc,l1l1l1l1l1ll_l1_ = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	yddd,l1l1l1l1l1ll_l1_ = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	yeee,l1l1l1l1l1ll_l1_ = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	yfff,l1l1l1l1l1ll_l1_ = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	item,yrender = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	count = len(l111ll11lll1_l1_)
	for l1l111lll1_l1_ in range(count):
		try:
			out = eval(l111ll11lll1_l1_[l1l111lll1_l1_])
			return True,out,l1l111lll1_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠩࠪ嵜"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠪࠫ嵝"),data=l1l111_l1_ (u"ࠫࠬ嵞")):
	l111ll1l1lll_l1_,l111ll1ll111_l1_,l111ll11ll1l_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵟") not in index: index = l1l111_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嵠")
	level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵡"))
	if level==l1l111_l1_ (u"ࠨ࠶ࠪ嵢"): level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ嵣"),l111ll11llll_l1_,index2,l111ll1l111l_l1_
	data = data.replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嵤"),l1l111_l1_ (u"ࠫࠬ嵥"))
	html,yccc,l1l11llll_l1_ = l111ll1ll11l_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵦")+l111ll11llll_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嵧")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵨")+l111ll1l111l_l1_
	if level in [l1l111_l1_ (u"ࠨ࠳ࠪ嵩"),l1l111_l1_ (u"ࠩ࠵ࠫ嵪"),l1l111_l1_ (u"ࠪ࠷ࠬ嵫")]:
		yddd,l111lll111l1_l1_,l111ll1l1lll_l1_,l111ll1l1l1l_l1_ = l111ll1l1ll1_l1_(yccc,url,index)
		if not l111lll111l1_l1_: return
		l1llll1l1l_l1_ = len(l111ll1l1lll_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠫ࠶࠭嵬"): level = l1l111_l1_ (u"ࠬ࠸ࠧ嵭")
			l111ll1l1lll_l1_ = []
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ嵮")+l111ll11llll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵯")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵰")+l111ll1l111l_l1_
	if level in [l1l111_l1_ (u"ࠩ࠵ࠫ嵱"),l1l111_l1_ (u"ࠪ࠷ࠬ嵲")]:
		yeee,l111lll11111_l1_,l111ll1ll111_l1_,l111ll1l1l11_l1_ = l111ll1111ll_l1_(yccc,yddd,url,index)
		if not l111lll11111_l1_: return
		l1ll1l111l_l1_ = len(l111ll1ll111_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠫ࠷࠭嵳"): level = l1l111_l1_ (u"ࠬ࠹ࠧ嵴")
			l111ll1ll111_l1_ = []
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ嵵")+l111ll11llll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵶")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵷")+l111ll1l111l_l1_
	if level in [l1l111_l1_ (u"ࠩ࠶ࠫ嵸")]:
		yfff,l111lll11l11_l1_,l111ll11ll1l_l1_,l111lll1lll1_l1_ = l111ll11l1ll_l1_(yccc,yeee,url,index)
		if not l111lll11l11_l1_: return
		l1ll1l11l1_l1_ = len(l111ll11ll1l_l1_)
	for item,url,index in l111ll1l1lll_l1_+l111ll1ll111_l1_+l111ll11ll1l_l1_:
		l1ll11l11ll1_l1_ = l111ll11l11l_l1_(item,url,index)
	return
def l111ll11l11l_l1_(item,url=l1l111_l1_ (u"ࠪࠫ嵹"),index=l1l111_l1_ (u"ࠫࠬ嵺")):
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵻") in index: level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ嵼"))
	else: level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ嵽"),l1l111_l1_ (u"ࠨ࠲ࠪ嵾"),l1l111_l1_ (u"ࠩ࠳ࠫ嵿"),l1l111_l1_ (u"ࠪ࠴ࠬ嶀")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_,l111lll1l1ll_l1_ = l111llll1111_l1_(item)
	l1llll111l11_l1_ = l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࡄ࠭嶁") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡳࡵࡴࡨࡥࡲࡹ࠿ࠨ嶂") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࡂࠫ嶃") in l1ll1ll_l1_
	l1llll1111l1_l1_ = l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡂࠫ嶄") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࡁࠪ嶅") in l1ll1ll_l1_
	if l1llll111l11_l1_ or l1llll1111l1_l1_: l1ll1ll_l1_ = url
	l1llll111l11_l1_ = l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ嶆") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ嶇") not in l1ll1ll_l1_
	l1llll1111l1_l1_ = l1l111_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ嶈") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ嶉") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠭嶊") and l1llll111l11_l1_ and l1llll1111l1_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ嶋") in url or l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ嶌") in l1ll1ll_l1_:
		level,l111ll11llll_l1_,index2,l111ll1l111l_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ嶍"),l1l111_l1_ (u"ࠪ࠴ࠬ嶎"),l1l111_l1_ (u"ࠫ࠵࠭嶏"),l1l111_l1_ (u"ࠬ࠶ࠧ嶐")
		index = l1l111_l1_ (u"࠭ࠧ嶑")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠧࠨ嶒")
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ嶓") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ嶔") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ嶕") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭嶖"))
		if data.count(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ嶗"))==4:
			l111lll111ll_l1_,key,l111ll1llll1_l1_,l111ll1ll1ll_l1_,token = data.split(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ嶘"))
			l1l11llll_l1_ = l111lll111ll_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嶙")+key+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ嶚")+l111ll1llll1_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭嶛")+l111ll1ll1ll_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ嶜")+l111lll1l1ll_l1_
			if l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ嶝") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ嶞")+key
	if not title:
		global l111ll11ll11_l1_
		l111ll11ll11_l1_ += 1
		title = l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࠩ嶟")+str(l111ll11ll11_l1_)
		index = l1l111_l1_ (u"ࠧ࠴ࠩ嶠")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶡")+l111ll11llll_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶢")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嶣")+l111ll1l111l_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡔࡾࡼࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ嶤") in str(item): return False
	elif l1l111_l1_ (u"ࠬ࠵ࡡࡣࡱࡸࡸࠬ嶥") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"࠭࠯ࡤࡱࡰࡱࡺࡴࡩࡵࡻࠪ嶦") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ嶧") in list(item.keys()) or l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ嶨") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶩")+l111ll11llll_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭嶪")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶫")+l111ll1l111l_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶬"),l1lllll_l1_+l1l111_l1_ (u"࠭࠺࠻ࠢࠪ嶭")+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ嶮"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ嶯") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭嶰")+title
		index = l1l111_l1_ (u"ࠪ࠷ࠬ嶱")+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶲")+l111ll11llll_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶳")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嶴")+l111ll1l111l_l1_
		url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ嶵"),l1l111_l1_ (u"ࠨࠩ嶶"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶷"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠪࠫ嶸"),index,l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ嶹"))
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ嶺") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"࠭࠳ࠨ嶻")+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶼")+l111ll11llll_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶽")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶾")+l111ll1l111l_l1_
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ嶿")+title
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巀"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪ࠭巁") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"࠭࠺࠻ࠢࠪ巂")+title
		index = l1l111_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ巃")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巄"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ巅") in str(item):
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ巆")+title
		index = l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ巇")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巈"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ巉") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ巊"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ巋"),9999)
	elif l111lll11l1l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ巌"),l1lllll_l1_+l111lll11l1l_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ巍") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巎"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡒࡉࡔࡖࠪ巏")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ巐")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ巑") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ巒"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ巓"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭巔") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ巕") in l1ll1ll_l1_ and count:
			l111lll1111l_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ巖"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ巗")+l111lll1111l_l1_
			index = l1l111_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ巘")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巙"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ巚")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ巛")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ巜"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ川"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ州") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡥ࠲ࠫ巟") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠨ࠱ࡃࠫ巠") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠩ࠲ࠫ巡"))==3):
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ巢"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ巣")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ巤")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭工") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ左"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭巧")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭巨")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ巩")+title
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巪"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l111llll1111_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_,token = False,l1l111_l1_ (u"ࠬ࠭巫"),l1l111_l1_ (u"࠭ࠧ巬"),l1l111_l1_ (u"ࠧࠨ巭"),l1l111_l1_ (u"ࠨࠩ差"),l1l111_l1_ (u"ࠩࠪ巯"),l1l111_l1_ (u"ࠪࠫ巰"),l1l111_l1_ (u"ࠫࠬ己"),l1l111_l1_ (u"ࠬ࠭已")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_,token
	for l111ll1lll11_l1_ in list(item.keys()):
		yrender = item[l111ll1lll11_l1_]
		if isinstance(yrender,dict): break
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ巳"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ巴"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤ࡭࡫ࡱࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ巵"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ巶"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ巷"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ巸"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ巹"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ巺"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ巻"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ巼"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ巽"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪࡡࠧ巾"))
	succeeded,title,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ巿"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ帀"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ币"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡤࡴ࡮࡛ࡲ࡭ࠩࡠࠦ市"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ布"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ帄"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ帅"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ帆"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ帇"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡸࡥࡦ࡮࡚ࡥࡹࡩࡨࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ师"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ帉"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ帊"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ帋"))
	succeeded,count,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ希"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ帍"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帎"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡥࡲࡲࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࡚ࡹࡱࡧࠪࡡࠧ帏"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡷࡽࡱ࡫ࠧ࡞ࠤ帐"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ帑"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡷࡳࡰ࡫࡮ࠨ࡟ࠥ帒"))
	succeeded,token,l1111ll1_l1_ = l111ll111ll1_l1_(item,yrender,l111ll11l111_l1_)
	if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ帓") in l1l1lll111_l1_: l1l1lll111_l1_,l111lll11l1l_l1_ = l1l111_l1_ (u"ࠫࠬ帔"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭帕")
	if l1l111_l1_ (u"࠭ๅษษืีࠬ帖") in l1l1lll111_l1_: l1l1lll111_l1_,l111lll11l1l_l1_ = l1l111_l1_ (u"ࠧࠨ帗"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ帘")
	if l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ帙") in list(yrender.keys()):
		l111lll1l11l_l1_ = str(yrender[l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ帚")])
		if l1l111_l1_ (u"ࠫࡋࡸࡥࡦࠢࡺ࡭ࡹ࡮ࠠࡂࡦࡶࠫ帛") in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ帜")
		if l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠫ帝") in l111lll1l11l_l1_: l111lll11l1l_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ帞")
		if l1l111_l1_ (u"ࠨࡄࡸࡽࠬ帟") in l111lll1l11l_l1_ or l1l111_l1_ (u"ࠩࡕࡩࡳࡺࠧ帠") in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ帡")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡹ๋ࠬศศึิࠫ帢")) in l111lll1l11l_l1_: l111lll11l1l_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭帣")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡻࠧีำสลࠬ帤")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭帥")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡶࠩสืฯฬฬศำࠪ带")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ帧")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡸࠫส฿ไศ่สฮࠬ帨")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠠࠡࠩ帩")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ帪") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"࠭࠿ࠨ師"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ帬") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ席")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111ll1ll1l1_l1_: title = l111ll1ll1l1_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠩ࠯ࠫ帮"),l1l111_l1_ (u"ࠪࠫ帯"))
	count = count.replace(l1l111_l1_ (u"ࠫ࠱࠭帰"),l1l111_l1_ (u"ࠬ࠭帱"))
	count = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ帲"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠧࠨ帳")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_,token
def l111ll1ll11l_l1_(url,data=l1l111_l1_ (u"ࠨࠩ帴"),request=l1l111_l1_ (u"ࠩࠪ帵")):
	if request==l1l111_l1_ (u"ࠪࠫ帶"): request = l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ帷")
	l11ll11lll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ常"):l11ll11lll_l1_,l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭帹"):l1l111_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ帺")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ帻"))
	if data.count(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭帼"))==4: l111lll111ll_l1_,key,l111ll1llll1_l1_,l111ll1ll1ll_l1_,token = data.split(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ帽"))
	else: l111lll111ll_l1_,key,l111ll1llll1_l1_,l111ll1ll1ll_l1_,token = l1l111_l1_ (u"ࠫࠬ帾"),l1l111_l1_ (u"ࠬ࠭帿"),l1l111_l1_ (u"࠭ࠧ幀"),l1l111_l1_ (u"ࠧࠨ幁"),l1l111_l1_ (u"ࠨࠩ幂")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠤࡦࡳࡳࡺࡥࡹࡶࠥ幃"):{l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ幄"):{l1l111_l1_ (u"ࠦ࡭ࡲࠢ幅"):l1l111_l1_ (u"ࠧࡧࡲࠣ幆"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ幇"):l1l111_l1_ (u"ࠢࡘࡇࡅࠦ幈"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ幉"):l111ll1llll1_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ幊") or l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ幋") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡶࡪ࡫࡬࠰ࡴࡨࡩࡱࡥࡷࡢࡶࡦ࡬ࡤࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ幌")+l1l111_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ幍")+key
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࡑࡣࡵࡥࡲࡹࠧ幎")] = l111lll111ll_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ幏"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭幐"))
	elif l1l111_l1_ (u"ࠩ࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ幑") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭幒")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ幓"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ幔"))
	elif l1l111_l1_ (u"࠭࡫ࡦࡻࡀࠫ幕") in url and l111lll111ll_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭幖")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ幗")][l1l111_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࠩ幘")][l1l111_l1_ (u"ࠪࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ幙")] = l111lll111ll_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ幚"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ幛"))
	elif l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ幜") in url and l111ll1ll1ll_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ幝"):l1l111_l1_ (u"ࠨ࠳ࠪ幞"),l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭幟"):l111ll1llll1_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ幠"):l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ幡")+l111ll1ll1ll_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ幢"),url,l1l111_l1_ (u"࠭ࠧ幣"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ幤"),l1l111_l1_ (u"ࠨࠩ幥"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠹ࡹ࡮ࠧ幦"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ幧"),url,l1l111_l1_ (u"ࠫࠬ幨"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭幩"),l1l111_l1_ (u"࠭ࠧ幪"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠸ࡷ࡬ࠬ幫"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ幬"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ幭"),html,re.DOTALL|re.I)
	if tmp: l111ll1llll1_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭幮"),html,re.DOTALL|re.I)
	if tmp: l111lll111ll_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ幯") in list(cookies.keys()): l111ll1ll1ll_l1_ = cookies[l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ幰")]
	l1l1l1111_l1_ = l111lll111ll_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ幱")+key+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ干")+l111ll1llll1_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ平")+l111ll1ll1ll_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭年")+token
	if request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ幵") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ并") in html:
		l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ幷"),html,re.DOTALL)
		if not l11ll111l1_l1_: l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ幸"),html,re.DOTALL)
		l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ幹"),l11ll111l1_l1_[0])
	elif request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭幺") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ幻") in html:
		l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ幼"),html,re.DOTALL)
		l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ幽"),l11ll111l1_l1_[0])
	elif l1l111_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ幾") not in html: l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ广"),html)
	else: l111lll1l111_l1_ = l1l111_l1_ (u"ࠧࠨ庀")
	if 0:
		yccc = str(l111lll1l111_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭庁"))
		open(l1l111_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ庂"),l1l111_l1_ (u"ࠪࡻࡧ࠭広")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭庄"),l1l1l1111_l1_)
	return html,l111lll1l111_l1_,l1l1l1111_l1_
def l111lll1ll11_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ庅"),l1l111_l1_ (u"࠭ࠫࠨ庆"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ庇")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ庈"),l1l111_l1_ (u"ࠩ࠮ࠫ庉"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ床")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ庋") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ庌")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ庍") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ庎")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭序") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ庐")
		else: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠪࠫ庑")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1l11ll_l1_
	else:
		l111ll1l11l1_l1_,l111ll111l1l_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠫࠬ庒")
		l111ll111lll_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ库"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ应"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ底"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ庖"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭店")]
		l111lll11lll_l1_ = [l1l111_l1_ (u"ࠪࠫ庘"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ庙"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ庚"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ庛"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭府")]
		l111lll1l1l1_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ庝"),l111ll111lll_l1_)
		if l111lll1l1l1_l1_ == -1: return
		l111ll1l1111_l1_ = l111lll11lll_l1_[l111lll1l1l1_l1_]
		html,c,data = l111ll1ll11l_l1_(l1lllll1_l1_+l111ll1l1111_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ庞")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭废")][l1l111_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭庠")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ庡")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ庢")][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ庣")][l1l111_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ庤")]
				for l111ll111l11_l1_ in range(len(d)):
					group = d[l111ll111l11_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ庥")][l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ度")]
					for l111lll1ll1l_l1_ in range(len(group)):
						yrender = group[l111lll1ll1l_l1_][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ座")]
						if l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ庨") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ庩")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ庪")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭庫")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭庬")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ庭"),l1l111_l1_ (u"ࠫࠫ࠭庮"))
							title = yrender[l1l111_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭庯")]
							title = title.replace(l1l111_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ庰"),l1l111_l1_ (u"ࠧࠨ庱"))
							if l1l111_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ庲") in title: continue
							if l1l111_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ庳") in title:
								title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ庴")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ庵") in title: continue
							title = title.replace(l1l111_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ庶"),l1l111_l1_ (u"࠭ࠧ康"))
							if l1l111_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ庸") in title: continue
							if l1l111_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ庹") in title:
								title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ庺")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ庻") in title: continue
							l111ll1l11l1_l1_.append(escapeUNICODE(title))
							l111ll111l1l_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l111lll11ll1_l1_ = l1l111_l1_ (u"ࠫࠬ庼")
		else:
			l111ll1l11l1_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ庽"),l1lllllll_l1_]+l111ll1l11l1_l1_
			l111ll111l1l_l1_ = [l1l111_l1_ (u"࠭ࠧ庾"),l111lllll_l1_]+l111ll111l1l_l1_
			l111lll1llll_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ庿"),l111ll1l11l1_l1_)
			if l111lll1llll_l1_ == -1: return
			l111lll11ll1_l1_ = l111ll111l1l_l1_[l111lll1llll_l1_]
		if l111lll11ll1_l1_: l1llllll_l1_ = l111l1_l1_+l111lll11ll1_l1_
		elif l111ll1l1111_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1111_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
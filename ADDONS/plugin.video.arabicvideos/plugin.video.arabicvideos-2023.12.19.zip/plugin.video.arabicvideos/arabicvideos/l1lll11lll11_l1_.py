# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ䏿")
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䐀"):l1l111_l1_ (u"ࠧࠨ䐁")}
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ䐂")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭䐃"),l1l111_l1_ (u"ࠪࡻࡼ࡫ࠧ䐄")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䐅")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ䐆")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐇"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䐈"),l111l1_l1_,369,l1l111_l1_ (u"ࠨࠩ䐉"),l1l111_l1_ (u"ࠩࠪ䐊"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䐋"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐌"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ䐍"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䐎"),364)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐏"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䐐"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䐑"),365)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䐒"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐓"),l1l111_l1_ (u"ࠬ࠭䐔"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䐕"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䐖"),l1l111_l1_ (u"ࠨࠩ䐗"),l1l111_l1_ (u"ࠩࠪ䐘"),l1l111_l1_ (u"ࠪࠫ䐙"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䐚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䐛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐜"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠧࠨ䐝"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐞"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䐟")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䐠"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐡"),l1l111_l1_ (u"ࠬ࠭䐢"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ䐣"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䐤"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐥"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䐦")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䐧"),url,l1l111_l1_ (u"ࠫࠬ䐨"),l1l111_l1_ (u"ࠬ࠭䐩"),l1l111_l1_ (u"࠭ࠧ䐪"),l1l111_l1_ (u"ࠧࠨ䐫"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䐬"))
	html = response.content
	if l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ䐭") in html:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐮"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䐯"),url,361,l1l111_l1_ (u"ࠬ࠭䐰"),l1l111_l1_ (u"࠭ࠧ䐱"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䐲"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䐳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䐴"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐵"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1lll1ll111l_l1_,type=l1l111_l1_ (u"ࠫࠬ䐶")):
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ䐷") in l1lll1ll111l_l1_:
		l1llllll_l1_,url = l1lll1ll111l_l1_.split(l1l111_l1_ (u"࠭࠺࠻ࠩ䐸"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䐹"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1ll111l_l1_,l1lll1ll111l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䐺"),url,l1l111_l1_ (u"ࠩࠪ䐻"),l1l111_l1_ (u"ࠪࠫ䐼"),l1l111_l1_ (u"ࠫࠬ䐽"),l1l111_l1_ (u"ࠬ࠭䐾"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䐿"))
	html = response.content
	if type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䑀"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ䑁"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䑂"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ䑃"),l1l111_l1_ (u"ࠫ࠴࠭䑄")).replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ䑅"),l1l111_l1_ (u"࠭ࠢࠨ䑆"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡈࡴ࡬ࡨ࠲࠳ࡍࡺࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ䑇"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ䑈"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ䑉"),l1l111_l1_ (u"ࠪࠫ䑊"))
			if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䑋") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑌"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"࠭อๅไฬࠫ䑍") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ䑎"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䑏") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑐"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䑑"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䑒"):
			l111l1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ䑓"),block,re.DOTALL)
			if l111l1l1ll_l1_:
				count = l111l1l1ll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ䑔")+count
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑕"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ䑖"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠩࠪ䑗"),l1l111_l1_ (u"ࠪࠫ䑘"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䑙"))
		elif type==l1l111_l1_ (u"ࠬ࠭䑚"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䑛"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䑜"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠨืไัฮࠦࠧ䑝")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑞"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ䑟")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䑠"),url,l1l111_l1_ (u"ࠬ࠭䑡"),l1l111_l1_ (u"࠭ࠧ䑢"),l1l111_l1_ (u"ࠧࠨ䑣"),l1l111_l1_ (u"ࠨࠩ䑤"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䑥"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡩࡵࡧࡰࠦࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠪ࠱࠮ࡄ࠯ࠢࠨ䑦"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭䑧"),l1l111_l1_ (u"ࠬࠦࠧ䑨")).strip(l1l111_l1_ (u"࠭࠯ࠨ䑩"))
	if l1l111_l1_ (u"ࠧๆ๊ึ้ࠬ䑪") in name and type==l1l111_l1_ (u"ࠨࠩ䑫"):
		name = name.split(l1l111_l1_ (u"่ࠩ์ุ๋ࠧ䑬"))[0]
		name = name.replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠪ䑭"),l1l111_l1_ (u"ࠫࠬ䑮")).strip(l1l111_l1_ (u"ࠬࠦࠧ䑯"))
	elif l1l111_l1_ (u"࠭อๅไฬࠫ䑰") in name:
		name = name.split(l1l111_l1_ (u"ࠧฮๆๅอࠬ䑱"))[0]
		name = name.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠨ䑲"),l1l111_l1_ (u"ࠩࠪ䑳")).strip(l1l111_l1_ (u"ࠪࠤࠬ䑴"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵ࡬ࡲ࡬ࡲࡥࡴࡧࡦࡸ࡮ࡵ࡮ࠨ䑵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠬ࠭䑶"):
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ䑷"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭䑸") in title: continue
				if l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩ䑹") in title: continue
				title = name+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䑺")+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑻"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠫࠬ䑼"),l1l111_l1_ (u"ࠬ࠭䑽"),l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䑾"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䑿"),block+l1l111_l1_ (u"ࠨࠨࠩࠫ䒀"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䒁"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䒂"))
				title = name+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䒃")+title
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒄"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䒅"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠧࠡ࠯้ࠣฬ๐ࠠิ์่หࠬ䒆"),l1l111_l1_ (u"ࠨࠩ䒇")).replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ䒈"),l1l111_l1_ (u"ࠪࠫ䒉"))
		else: title = l1l111_l1_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ䒊")
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒋"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䒌"),url,l1l111_l1_ (u"ࠧࠨ䒍"),l1l111_l1_ (u"ࠨࠩ䒎"),l1l111_l1_ (u"ࠩࠪ䒏"),l1l111_l1_ (u"ࠪࠫ䒐"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䒑"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂฬ๊สึ่ํๅࡁ࠴ࠪࡀ࠾ࡤ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䒒"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡋ࡭ࡣࡧࡧࠦࠬ䒓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ䒔"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䒕") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠩึ๎ึ็ัࠡ็ส๎ู๊ࠥๆษࠪ䒖"): name = l1l111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ䒗")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䒘")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䒙")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䒚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䒛"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䒜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ䒝"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䒞")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠬ䒟")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡳࡹࡤ࡫ࡰࡥࠬ䒠")+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䒡")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䒢"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠨࠩ䒣")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ䒤"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ䒥"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭䒦"),l1l111_l1_ (u"ࠬ࠱ࠧ䒧"))
	l1llll_l1_ = [l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ䒨"),l1l111_l1_ (u"ࠧ࠰ࠩ䒩"),l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ䒪"),l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ䒫"),l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ䒬")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠫฬ๊ใๅࠩ䒭"),l1l111_l1_ (u"ࠬอไฤใ็ห๊࠭䒮"),l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠩ䒯"),l1l111_l1_ (u"ࠧศๆส๊๏๋๊๊ࠡࠣห้้ัห๊้ࠫ䒰"),l1l111_l1_ (u"ࠨษ็ฬึอๅอࠢอ่๏็า๋๊้๎ฮ࠭䒱")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ䒲"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠪࠫ䒳"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䒴"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭䒵"),l1l111_l1_ (u"࠭ࠧ䒶"),False,l1l111_l1_ (u"ࠧࠨ䒷"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䒸"))
		hostname = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䒹")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠪ࠳ࠬ䒺"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭䒻")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1ll111l_l1_,filter):
	if l1l111_l1_ (u"ࠬࡅ࠿ࠨ䒼") in l1lll1ll111l_l1_: url = l1lll1ll111l_l1_.split(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䒽"))[0]
	else: url = l1lll1ll111l_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䒾"),l1l111_l1_ (u"ࠨࠩ䒿"))
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭䓀"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ䓁"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ䓂"),l1l111_l1_ (u"ࠬ࠭䓃")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ䓄"))
	if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ䓅"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䓆") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠩࡀࡁࠬ䓇") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䓈")+category+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ䓉")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䓊")+category+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ䓋")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䓌"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䓍")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ䓎"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓏"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䓐")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䓑"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䓒"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ䓓"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䓔"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ䓕"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䓖")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1ll111l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓗"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ䓘"),l1111111_l1_,361,l1l111_l1_ (u"࠭ࠧ䓙"),l1l111_l1_ (u"ࠧࠨ䓚"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䓛"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓜"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ䓝")+l11l1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ䓞"),l1111111_l1_,361,l1l111_l1_ (u"ࠬ࠭䓟"),l1l111_l1_ (u"࠭ࠧ䓠"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䓡"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䓢"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䓣"),l1l111_l1_ (u"ࠪࠫ䓤"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䓥"),url,l1l111_l1_ (u"ࠬ࠭䓦"),l1l111_l1_ (u"࠭ࠧ䓧"),l1l111_l1_ (u"ࠧࠨ䓨"),l1l111_l1_ (u"ࠨࠩ䓩"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䓪"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ䓫"),l1l111_l1_ (u"ࠫࠧ࠭䓬")).replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ䓭"),l1l111_l1_ (u"࠭࠯ࠨ䓮"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ䓯"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䓰"),block+l1l111_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䓱"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䓲") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭䓳"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠬࡃ࠽ࠨ䓴") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䓵"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䓶")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1ll111l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓷"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ䓸"),l1111111_l1_,361,l1l111_l1_ (u"ࠪࠫ䓹"),l1l111_l1_ (u"ࠫࠬ䓺"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓻"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓼"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ䓽"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠨࠩ䓾"),l1l111_l1_ (u"ࠩࠪ䓿"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䔀"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䔁")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ䔂")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䔃")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ䔄")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䔅")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔆"),l1lllll_l1_+name+l1l111_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ䔇"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠫࠬ䔈"),l1l111_l1_ (u"ࠬ࠭䔉"),l1l111l1_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䔊"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠧࡳࠩ䔋") or value==l1l111_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䔌"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䔍") in option: continue
			if l1l111_l1_ (u"ࠪห้้ไࠨ䔎") in option: continue
			if l1l111_l1_ (u"ࠫࡳ࠳ࡡࠨ䔏") in value: continue
			if option==l1l111_l1_ (u"ࠬ࠭䔐"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ䔑"),option,re.DOTALL)
			if l1ll1l111ll_l1_: l1l11l1ll_l1_ = l1ll1l111ll_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠧ࠻ࠢࠪ䔒")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䔓")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁࠬ䔔")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䔕")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃࠧ䔖")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䔗")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ䔘"):
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔙"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠨࠩ䔚"),l1l111_l1_ (u"ࠩࠪ䔛"),l1l1l11l_l1_+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䔜"))
			elif type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䔝") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔞") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䔟"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䔠")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1ll111l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔡"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠩࠪ䔢"),l1l111_l1_ (u"ࠪࠫ䔣"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䔤"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔥"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"࠭ࠧ䔦"),l1l111_l1_ (u"ࠧࠨ䔧"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ䔨"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ䔩"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ䔪")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠫࡲࡶࡡࡢࠩ䔫"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ䔬"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䔭"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ䔮"),l1l111_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩ䔯"),l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ䔰"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ䔱"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䔲")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䔳") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䔴"),l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࠨ䔵"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䔶"),l1l111_l1_ (u"ࠩ࠽࠾࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࠴࠭䔷"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࡁࡂ࠭䔸"),l1l111_l1_ (u"ࠫ࠴࠭䔹"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬࠬࠦࠨ䔺"),l1l111_l1_ (u"࠭࠯ࠨ䔻"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䔼"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠨࠩ䔽")
	if l1l111_l1_ (u"ࠩࡀࡁࠬ䔾") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠫ࠭䔿"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂࡃࠧ䕀"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ䕁")
		if l1l111_l1_ (u"࠭ࠥࠨ䕂") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䕃") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ䕄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭䕅")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䕆") and value!=l1l111_l1_ (u"ࠫ࠵࠭䕇"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䕈")+key+l1l111_l1_ (u"࠭࠽࠾ࠩ䕉")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ䕊"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䕋")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ䕌")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ䕍"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ䕎"))
	return l1l1l111_l1_
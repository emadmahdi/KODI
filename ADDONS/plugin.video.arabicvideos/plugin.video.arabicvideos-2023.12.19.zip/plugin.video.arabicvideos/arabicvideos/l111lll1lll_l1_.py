# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ僐")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ僑") : l1l111_l1_ (u"ࠬ࠭僒") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ僓")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11ll1l11l1l_l1_(url)
	elif mode==215: l1lll_l1_ = l11ll1l11ll1_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1l1l1l1l1_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1l1l1l1_l1_():
	message = l1l111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ僔")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ僕"),l1l111_l1_ (u"ࠩࠪ僖"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僗"),l1l111_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ僘"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僙"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭僚"),l1l111_l1_ (u"ࠧࠨ僛"),219,l1l111_l1_ (u"ࠨࠩ僜"),l1l111_l1_ (u"ࠩࠪ僝"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ僞"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ僟")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僠"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ僡")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ僢"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ僣"),headers,l1l111_l1_ (u"ࠩࠪ僤"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ僥"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ僦"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ僧"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ僨")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僩"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ僪")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ僫"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僬"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ僭"),l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ僮")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ僯"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僰"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ僱")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ僲"),headers,l1l111_l1_ (u"ࠪࠫ僳"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ僴"))
	if l1l111_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ僵") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ僶") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭僷"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僸"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ價"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ僺"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ僻"),l1l111_l1_ (u"้ࠬไ๋สࠪ僼"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ僽"),l1l111_l1_ (u"่ࠧัสๅࠬ僾"),l1l111_l1_ (u"ࠨ็หหึอษࠨ僿"),l1l111_l1_ (u"ࠩ฼ี฻࠭儀"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ儁"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ儂")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ儃") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ億"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ儅"))
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ儆") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ儇"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭儈") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ儉") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ儊"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ儋") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儌"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ儍"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ儎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭儏"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ儐"),l1l111_l1_ (u"ࠬ࠭儑"))
			if title!=l1l111_l1_ (u"࠭ࠧ儒"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儓"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ儔")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ儕"),headers,l1l111_l1_ (u"ࠪࠫ儖"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ儗"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ儘"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"࠭ࠧ儙").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭儚"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ儛"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ儜") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ儝"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭儞"),l1l111_l1_ (u"ࠬࠦࠧ償"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ儠"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ儡"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ儢")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ儣"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭儤"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭儥") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ儦") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭儧"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ儨") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ儩"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ優"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ儫"),headers,l1l111_l1_ (u"ࠫࠬ儬"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭儭"))
	if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ儮") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭儯"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ儰"),headers,l1l111_l1_ (u"ࠩࠪ儱"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ儲"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ儳"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ儴"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ儵"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l1111l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ儶")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ儷")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ儸")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ儹")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪࠥࢀࠫࡷࡵࡰࡶ࠾࠭ࠬ儺"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ儻") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ儼"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ儽"),headers,l1l111_l1_ (u"ࠨࠩ儾"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ儿"))
		id = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ兀"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l1111l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ允"):l1l111_l1_ (u"ࠬ࠭兂") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ元"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ兄") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ充")+l1l1l1111l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ兆"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ兇"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ先"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ光"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ兊"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ克")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ兌")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ免")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠼ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭兎"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠫࠬ兏")
					items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ児"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"࠭ࠦࠧࠩ兑") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ兒"))[2].lower() + l1l111_l1_ (u"ࠨࠨࠩࠫ兓")
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ兔"),l1l111_l1_ (u"ࠪࠫ兕")).replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ兖"),l1l111_l1_ (u"ࠬ࠭兗"))
						server = server.replace(l1l111_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭兘"),l1l111_l1_ (u"ࠧࠨ兙")).replace(l1l111_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ党"),l1l111_l1_ (u"ࠩࠪ兛"))
						server = server.replace(l1l111_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ兜"),l1l111_l1_ (u"ࠫࠬ兝")).replace(l1l111_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ兞"),l1l111_l1_ (u"࠭ࠧ兟"))
						server = server.replace(l1l111_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭兠"),l1l111_l1_ (u"ࠨࠩ兡")).replace(l1l111_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ兢"),l1l111_l1_ (u"ࠪࠫ兣"))
						server = server.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ兤"),l1l111_l1_ (u"ࠬ࠭入"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ兦") + name + server + l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ內")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ全"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ兩"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ兪"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭八"),l1l111_l1_ (u"ࠬ࠱ࠧ公"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ六")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ∙")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡈࡆ࠸ࡥࠧ√")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส่๊฻วา฻ฬࠤฬ๊อาหࠪ∛"),l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠬ∜"),l1l111_l1_ (u"ࠫฬ๊สึ็ํ้ࠥอไอัํำࠬ∝"),l1l111_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼อࠬ∞"),l1l111_l1_ (u"࠭ๅไฬหฮ๏࠭∟"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่ัี๊ะࠩ∠"),l1l111_l1_ (u"ࠨษํะ๏ࠦศิฬࠣห้ฮฯ๋ๆࠪ∡"),l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ∢"),l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศิฬࠪ∣"),l1l111_l1_ (u"๊ࠫ๎โฺ้ࠢฮๆ๊๊ไีࠪ∤")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==790: l1lll_l1_ = l1l1l11_l1_()
	elif mode==791: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==792: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==793: l1lll_l1_ = PLAY(url)
	elif mode==796: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==799: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ∥"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ∦"),l1l111_l1_ (u"ࠧࠨ∧"),l1l111_l1_ (u"ࠨࠩ∨"),l1l111_l1_ (u"ࠩࠪ∩"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ∪"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵ࠯ࡳࡥ࡬࡫ࡳࠩ࠰࠭ࡃ࠮࡬ࡡ࠮ࡨࡲࡰࡩ࡫ࡲࠨ∫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ∬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ∭"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ∮") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ∯"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ∰")+l1lllll_l1_+title,l1ll1ll_l1_,791)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ∱"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ∲"),l1l111_l1_ (u"ࠬ࠭∳"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࡶࡳࡨ࡯ࡡ࡭࠯ࡥࡳࡽ࠭∴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ∵"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ∶"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ∷") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ∸"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭∹")+l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠬ࠭∺"),l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡱࡪࡴࡵࠨ∻"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ∼"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ∽"),l1l111_l1_ (u"ࠩࠪ∾"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ∿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ≁"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ≂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ≃"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ≄")+l1lllll_l1_+title,l1ll1ll_l1_,791)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠩࠪ≅")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ≆"),url,l1l111_l1_ (u"ࠫࠬ≇"),l1l111_l1_ (u"ࠬ࠭≈"),l1l111_l1_ (u"࠭ࠧ≉"),l1l111_l1_ (u"ࠧࠨ≊"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰ࡗࡊࡇࡓࡐࡐࡖࡣࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ≋"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡢࡴࡷ࡭ࡨࡲࡥࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡥࡷࡺࡩࡤ࡮ࡨࠫ≌"),html,re.DOTALL)
	if l11llll_l1_:
		l111lll1l1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠪࠫ≍"),l1l111_l1_ (u"ࠫࠬ≎"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠬำไใษอࠫ≏") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"࠭ๅ้ษึ้ࠬ≐") in name: l111lll1l1_l1_ = block
		if l111lll1l1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ≑"),l111lll1l1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ≒"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ≓"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ≔"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ≕"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ≖"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ≗"),l1lllll_l1_+title,l1ll1ll_l1_,793)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ≘")):
	limit,start,l1l1l1ll1_l1_,select,l111l1ll1l_l1_ = 0,0,l1l111_l1_ (u"ࠨࠩ≙"),l1l111_l1_ (u"ࠩࠪ≚"),l1l111_l1_ (u"ࠪࠫ≛")
	if l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ≜") in type:
		l111ll1111_l1_,data = l1ll11ll1_l1_(url)
		limit = int(data[l1l111_l1_ (u"ࠬࡲࡩ࡮࡫ࡷࠫ≝")])
		start = int(data[l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ≞")])
		l1l1l1ll1_l1_ = data[l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ≟")]
		select = data[l1l111_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴࠨ≠")]
		l1l11llll_l1_ = l1l111_l1_ (u"ࠩ࡯࡭ࡲ࡯ࡴ࠾ࠩ≡")+str(limit)+l1l111_l1_ (u"ࠪࠪࡸࡺࡡࡳࡶࡀࠫ≢")+str(start)+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࠫ≣")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡦ࡮ࡨࡧࡹࡃࠧ≤")+select
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ≥"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭≦")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭≧"),l111ll1111_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ≨"),l1l111_l1_ (u"ࠪࠫ≩"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ≪"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡷࠬ≫")+html+l1l111_l1_ (u"࠭ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ≬")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ≭"),url,l1l111_l1_ (u"ࠨࠩ≮"),l1l111_l1_ (u"ࠩࠪ≯"),l1l111_l1_ (u"ࠪࠫ≰"),l1l111_l1_ (u"ࠫࠬ≱"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ≲"))
		html = response.content
		l11l1ll1_l1_ = html
		code = re.findall(l1l111_l1_ (u"ࠨ࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࠩࡸࡤࡶ࠳࠰࠿࠾࠰࠭ࡃࡀࡼࡡࡳ࠰࠭ࡃࡂ࠴ࠪࡀ࠽ࡹࡥࡷ࠴ࠪࡀ࠿࠱࠮ࡄࡁࡶࡢࡴ࠱࠮ࡄࡃ࠮ࠫࡁ࠾ࡺࡦࡸ࠮ࠫࡁࡀ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠦ≳"),html,re.DOTALL)
		if code:
			code = code[0].replace(l1l111_l1_ (u"ࠧࡷࡣࡵࠫ≴"),l1l111_l1_ (u"ࠨࠩ≵")).replace(l1l111_l1_ (u"ࠩࠣࠫ≶"),l1l111_l1_ (u"ࠪࠫ≷")).replace(l1l111_l1_ (u"ࠦࠬࠨ≸"),l1l111_l1_ (u"ࠬ࠭≹")).replace(l1l111_l1_ (u"࠭࠻ࠨ≺"),l1l111_l1_ (u"ࠧࠧࠩ≻"))
			dummy,data = l1ll11ll1_l1_(l1l111_l1_ (u"ࠨࡁࠪ≼")+code)
			limit = int(data[l1l111_l1_ (u"ࠩ࡯࡭ࡲ࡯ࡴࠨ≽")])
			start = int(data[l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ≾")])
			l1l1l1ll1_l1_ = data[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ≿")]
			select = data[l1l111_l1_ (u"ࠬࡹࡥ࡭ࡧࡦࡸࠬ⊀")]
			l111l1ll1l_l1_ = data[l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻࡹࡷࡲࠧ⊁")]
			l1l11llll_l1_ = l1l111_l1_ (u"ࠧ࡭࡫ࡰ࡭ࡹࡃࠧ⊂")+str(limit)+l1l111_l1_ (u"ࠨࠨࡶࡸࡦࡸࡴ࠾ࠩ⊃")+str(start)+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࠩ⊄")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡫࡬ࡦࡥࡷࡁࠬ⊅")+select
			l111ll1111_l1_ = l111l1_l1_+l111l1ll1l_l1_
			l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⊆"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ⊇")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ⊈"),l111ll1111_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ⊉"),l1l111_l1_ (u"ࠨࠩ⊊"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࡙ࡏࡔࡍࡇࡖ࠱࠸ࡸࡤࠨ⊋"))
			l11l1ll1_l1_ = response.content
			l11l1ll1_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠪ⊌")+l11l1ll1_l1_+l1l111_l1_ (u"ࠫࡦࡸࡴࡪࡥ࡯ࡩࠬ⊍")
	items,l111lll1ll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⊎"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⊏"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ⊐"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊑"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠩࠪ⊒"),l1l111_l1_ (u"ࠪࡷࡺࡨ࡭ࡦࡰࡸࠫ⊓"))
				l111lll1ll_l1_ = True
	if not type:
		filters = l111l1lll1_l1_(html)
	if not l111lll1ll_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩ⊔"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⊕"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"࠭࡜࡯ࠩ⊖"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩ⊗") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊘"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1ll1l_l1_)
				elif l1l111_l1_ (u"่ࠩืู้ไࠨ⊙") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨ⊚") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊛"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				elif l1l111_l1_ (u"๋่ࠬิ็ࠪ⊜") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ⊝") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊞"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⊟"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
		length = 12
		data = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠫࡰࡴࡧࡤ࠮࡯ࡲࡶࡪ࠴ࠪࡀࠫ࠿ࠫ⊠"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ⊡") in type):
			l1l11llll_l1_ = l1l111_l1_ (u"ࠫࡱ࡯࡭ࡪࡶࡀࠫ⊢")+str(length)+l1l111_l1_ (u"ࠬࠬࡳࡵࡣࡵࡸࡂ࠭⊣")+str(start+length)+l1l111_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠭⊤")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠧࠧࡵࡨࡰࡪࡩࡴ࠾ࠩ⊥")+select
			l1lllll1_l1_ = l111ll1111_l1_+l1l111_l1_ (u"ࠨࡁࡱࡩࡽࡺ࠽ࡱࡣࡪࡩࠫ࠭⊦")+l1l11llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⊧"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋า๋ัࠪ⊨"),l1lllll1_l1_,791,l1l111_l1_ (u"ࠫࠬ⊩"),l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡡࠪ⊪")+type)
	return
def l111l1lll1_l1_(html):
	filters = False
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࡤࡶࡹ࡯ࡣ࡭ࡧࠪ⊫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⊬"),block,re.DOTALL)
		if l1lll1l1_l1_: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⊭"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⊮"),l1l111_l1_ (u"ࠪࠫ⊯"),9999)
		for category,name,block in l1lll1l1_l1_:
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭⊰"))
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⊱"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ⊲")+value
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊳"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠨࠩ⊴"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⊵"))
				filters = True
	return filters
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⊶"),url,l1l111_l1_ (u"ࠫࠬ⊷"),l1l111_l1_ (u"ࠬ࠭⊸"),l1l111_l1_ (u"࠭ࠧ⊹"),l1l111_l1_ (u"ࠧࠨ⊺"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⊻"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠯࡬ࡸࡪࡳ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⊼"),html,re.DOTALL)
	for l111ll11l1_l1_ in items:
		l111ll1l11_l1_ = base64.b64decode(l111ll11l1_l1_)
		if PY3: l111ll1l11_l1_ = l111ll1l11_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⊽"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⊾"),l111ll1l11_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⊿"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋀")+server+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⋁"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬ⋂"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡸࡷࠦࡦ࡭ࡧࡻ࠱ࡸࡺࡡࡳࡶࠥ࠲࠯ࡅ࠼ࡥ࡫ࡹࡂࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪࠩ࡞ࡧࡿ࠸࠲࠴ࡾࠫ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⋃"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ⋄") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴ࡅࡵࡳ࡮ࡀࠫ⋅"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⋆"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋇")+server+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ⋈")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⋉"),url)
	return
def l1lll1_l1_(text):
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᢁ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇࡒࡒ࡟ࠨᢂ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪๆ๋๎วหࠢไฺฬฬ๊สࠩᢃ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==470: l1lll_l1_ = l1l1l11_l1_()
	elif mode==471: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==472: l1lll_l1_ = PLAY(url)
	elif mode==473: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==474: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==479: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᢄ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᢅ"),l1l111_l1_ (u"࠭ࠧᢆ"),l1l111_l1_ (u"ࠧࠨᢇ"),l1l111_l1_ (u"ࠨࠩᢈ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᢉ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡺࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᢊ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠫ࠴࠭ᢋ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩᢌ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢍ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᢎ"),l1l111_l1_ (u"ࠨࠩᢏ"),479,l1l111_l1_ (u"ࠩࠪᢐ"),l1l111_l1_ (u"ࠪࠫᢑ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᢒ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᢓ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᢔ"),l1l111_l1_ (u"ࠧࠨᢕ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢖ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᢗ")+l1lllll_l1_+l1l111_l1_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨᢘ"),l1l11ll_l1_,471,l1l111_l1_ (u"ࠫࠬᢙ"),l1l111_l1_ (u"ࠬ࠭ᢚ"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨᢛ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᢜ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᢝ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠩࠣࠤࠬᢞ"),l1l111_l1_ (u"ࠪࠫᢟ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᢠ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡩࡡࡵ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴ࠳ࠪᢡ"),l1l111_l1_ (u"࠭ࡣࡢࡶࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡱࡴࡼࡩࡦࡵࠪᢢ"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢣ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᢤ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᢥ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᢦ"),l1l111_l1_ (u"ࠫࠬᢧ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩᢨ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁᢩࠦ"),html,re.DOTALL)
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᢪ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠨ็ึุ่๊ࠠࠨ᢫") in title: continue
		if l1l111_l1_ (u"ࠩหี๋อๅอࠢࠪ᢬") in title: continue
		if l1l111_l1_ (u"่้้ࠪศศำࠪ᢭") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᢮"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᢯")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᢰ"),url,l1l111_l1_ (u"ࠧࠨᢱ"),l1l111_l1_ (u"ࠨࠩᢲ"),l1l111_l1_ (u"ࠩࠪᢳ"),l1l111_l1_ (u"ࠪࠫᢴ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᢵ"))
	html = response.content
	if l1l111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬᢶ") in url: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠪᢷ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᢸ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᢹ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࠩᢺ") in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂ࡫࡮ࡨ࡮࡬ࡷ࡭࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᢻ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃ࡯࡯࡮࡬ࡲࡪ࠳࡭ࡰࡸ࡬ࡩࡸ࠷ࠧᢼ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽࡮࡫ࡶࡧࠬᢽ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡶࡹ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࠬᢾ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠧๆ่ำࠤฬ๊ศะษํอࠬᢿ") in title and l1l111_l1_ (u"ࠨࡦࡲࡁࡷࡧࡴࡪࡰࡪࠫᣀ") not in l1ll1ll_l1_: continue
			else: title = l1l111_l1_ (u"ࠩอีฯ๐ศࠡสสืฯิฯศ็࠽ࠤࠥ࠭ᣁ")+title
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᣂ"),l1lllll_l1_+title,l1ll1ll_l1_,471)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠫࠬᣃ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩᣄ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᣅ"),url,l1l111_l1_ (u"ࠧࠨᣆ"),l1l111_l1_ (u"ࠨࠩᣇ"),l1l111_l1_ (u"ࠩࠪᣈ"),l1l111_l1_ (u"ࠪࠫᣉ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᣊ"))
	html = response.content
	items = []
	if request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᣋ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡪࡱࡻࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᣌ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᣍ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᣎ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠮࠮ࠫࡁࠬࡀࡸࡺࡹ࡭ࡧࡁࠫᣏ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠨᣐ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᣑ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬᣒ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣓ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᣔ"),html,re.DOTALL)
		if not l11llll_l1_: return
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᣕ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᣖ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪᣗ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩᣘ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫᣙ"),l1l111_l1_ (u"࠭ใๅ์หࠫᣚ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ᣛ"),l1l111_l1_ (u"ࠨ้าหๆ࠭ᣜ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩᣝ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧᣞ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫᣟ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫᣠ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭ᣡ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩᣢ"))
		title = title.replace(l1l111_l1_ (u"ࠨ็ส๎ู๊ࠥๆษࠪᣣ"),l1l111_l1_ (u"ࠩࠪᣤ")).replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠪᣥ"),l1l111_l1_ (u"ࠫࠬᣦ")).strip(l1l111_l1_ (u"ࠬࠦࠧᣧ")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩᣨ"),l1l111_l1_ (u"ࠧࠡࠩᣩ"))
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᣪ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫᣫ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬᣬ"))
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᣭ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧᣮ")+l1ll1l_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨᣯ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᣰ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᣱ")+title
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᣲ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪห้ำไใหࠪᣳ") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᣴ")+l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣵ"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ᣶") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᣷"),l1lllll_l1_+title,l1ll1ll_l1_,471,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᣸"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ᣹"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ᣺")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᣻"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᣼"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ᣽"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ᣾")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ᣿"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤀ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩᤁ")+title,l1ll1ll_l1_,471)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᤂ"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤃ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭ᤄ"),l1ll1ll_l1_,471)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᤅ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᤆ"),url,l1l111_l1_ (u"ࠩࠪᤇ"),l1l111_l1_ (u"ࠪࠫᤈ"),l1l111_l1_ (u"ࠫࠬᤉ"),l1l111_l1_ (u"ࠬ࠭ᤊ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨᤋ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᤌ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭ᤍ")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᤎ"),html,re.DOTALL)
	items = []
	if l11ll1l_l1_ and not l1l11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᤏ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹࡢࠬࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨᤐ"),block,re.DOTALL)
		for l1l11_l1_,title in items: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤑ"),l1lllll_l1_+title,url,473,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧᤒ"),l1l11_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᤓ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠣࡶ࡬ࡸࡱ࡫࠽ࠨࠪ࠱࠮ࡄ࠯ࠧࠡࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢᤔ"),block,re.DOTALL)
		if items:
			for title,l1ll1ll_l1_ in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫᤕ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬᤖ"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᤗ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᤘ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᤙ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩᤚ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪᤛ"))
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᤜ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
	if l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡶࡪࡲࡡࡵࡧࡧࠦࠬᤝ") in html:
		if items: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᤞ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᤟"),l1l111_l1_ (u"࠭ࠧᤠ"),9999)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᤡ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ห฻๐ูࠡาสฮࠥ฻ไสࠩᤢ"),url,471)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᤣ"),url,l1l111_l1_ (u"ࠪࠫᤤ"),l1l111_l1_ (u"ࠫࠬᤥ"),l1l111_l1_ (u"ࠬ࠭ᤦ"),l1l111_l1_ (u"࠭ࠧᤧ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᤨ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠿ࠪ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠬᤩ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨᤪ"),block,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,True): return
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᤫ"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ᤬"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ᤭"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ᤮"),l1l111_l1_ (u"ࠧࠨ᤯"),l1l111_l1_ (u"ࠨࠩᤰ"),l1l111_l1_ (u"ࠩࠪᤱ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᤲ"))
	html = response.content
	l1llllllll_l1_ = []
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧ࡙ࡗࡒࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᤳ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ and l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᤴ")
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᤵ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᤶ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠣ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠦᤷ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᤸ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫᤹ࠫ")
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᤺") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽᤻ࠫ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ᤼"),l1l111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨ᤽"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ᤾"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ᤿"),l1l111_l1_ (u"ࠪࠫ᥀"),l1l111_l1_ (u"ࠫࠬ᥁"),l1l111_l1_ (u"ࠬ࠭᥂"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ᥃"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᥄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ᥅"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l1llllllll_l1_:
				l1llllllll_l1_.append(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᥆")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ᥇")
				if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᥈") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᥉")+l1ll1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᥊"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ᥋"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ᥌"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ᥍"),l1l111_l1_ (u"ࠪ࠯ࠬ᥎"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ᥏")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ⢹")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡋࡐࡓࡠࠩ⢺")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊สึ่ํๅฬะࠧ⢻"),l1l111_l1_ (u"ࠬอๆีษฤࠤาูวษࠩ⢼"),l1l111_l1_ (u"࠭ืๅสสฮࠥอไำ๊๔หึ࠭⢽")]
def l11l1ll_l1_(mode,url,text):
	if   mode==390: l1lll_l1_ = l1l1l11_l1_()
	elif mode==391: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==392: l1lll_l1_ = PLAY(url)
	elif mode==393: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==399: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢾"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⢿"),l1l111_l1_ (u"ࠩࠪ⣀"),399,l1l111_l1_ (u"ࠪࠫ⣁"),l1l111_l1_ (u"ࠫࠬ⣂"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⣃"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⣄"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⣅"),l1l111_l1_ (u"ࠨࠩ⣆"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⣇"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ⣈"),l1l111_l1_ (u"ࠫࠬ⣉"),l1l111_l1_ (u"ࠬ࠭⣊"),l1l111_l1_ (u"࠭ࠧ⣋"),l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⣌"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⣍"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣎"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⣏")+l1lllll_l1_+title,l111l1_l1_,391,l1l111_l1_ (u"ࠫࠬ⣐"),l1l111_l1_ (u"ࠬ࠭⣑"),l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭⣒")+str(seq))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣓"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⣔")+l1lllll_l1_+l1l111_l1_ (u"่ࠩาฯอัศฬࠣ฽ู๎วว์ฬࠫ⣕"),l111l1_l1_,391,l1l111_l1_ (u"ࠪࠫ⣖"),l1l111_l1_ (u"ࠫࠬ⣗"),l1l111_l1_ (u"ࠬࡸࡡ࡯ࡦࡲࡱࡸ࠭⣘"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣙"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⣚")+l1lllll_l1_+l1l111_l1_ (u"ࠨล฼่๎ࠦวๅลไ่ฬ๋ࠠหไํ๎๊อ๋ࠨ⣛"),l111l1_l1_,391,l1l111_l1_ (u"ࠩࠪ⣜"),l1l111_l1_ (u"ࠪࠫ⣝"),l1l111_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⣞"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣟"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⣠")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤ฻็ํࠥอไๆี็ื้อสࠡฬๅ๎๏๋ว์ࠩ⣡"),l111l1_l1_,391,l1l111_l1_ (u"ࠨࠩ⣢"),l1l111_l1_ (u"ࠩࠪ⣣"),l1l111_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡹࡥࡳ࡫ࡨࡷࠬ⣤"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣥"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⣦")+l1lllll_l1_+l1l111_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫ⣧"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⣨"),391,l1l111_l1_ (u"ࠨࠩ⣩"),l1l111_l1_ (u"ࠩࠪ⣪"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⣫"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣬"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⣭")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭⣮"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩ⣯"),391,l1l111_l1_ (u"ࠨࠩ⣰"),l1l111_l1_ (u"ࠩࠪ⣱"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭⣲"))
	block = l1l111_l1_ (u"ࠫࠬ⣳")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪ⣴"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⣵"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⣶"),l1l111_l1_ (u"ࠨࠩ⣷"),l1l111_l1_ (u"ࠩࠪ⣸"),l1l111_l1_ (u"ࠪࠫ⣹"),l1l111_l1_ (u"ࠫࠬ⣺"),l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ⣻"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡮ࡨࡥࡸ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࡡࡴ࡫ࡧࡩࠬ⣼"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⣽"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⣾"),l1l111_l1_ (u"ࠩࠪ⣿"),9999)
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⤀"),block,re.DOTALL)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫ⤁"):
			if first:
				title = l1l111_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ⤂")+title
				first = False
			else: title = l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ⤃")+title
		if title not in l11lll_l1_:
			if title==l1l111_l1_ (u"ࠧฤใ็ห๊࠭⤄"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤅"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⤆")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ⤇"),391,l1l111_l1_ (u"ࠫࠬ⤈"),l1l111_l1_ (u"ࠬ࠭⤉"),l1l111_l1_ (u"࠭ࡡ࡭࡮ࡢࡱࡴࡼࡩࡦࡵࡢࡸࡻࡹࡨࡰࡹࡶࠫ⤊"))
			elif title==l1l111_l1_ (u"ࠧๆี็ื้อสࠨ⤋"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤌"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⤍")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷࠬ⤎"),391,l1l111_l1_ (u"ࠫࠬ⤏"),l1l111_l1_ (u"ࠬ࠭⤐"),l1l111_l1_ (u"࠭ࡡ࡭࡮ࡢࡱࡴࡼࡩࡦࡵࡢࡸࡻࡹࡨࡰࡹࡶࠫ⤑"))
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤒"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⤓")+l1lllll_l1_+title,l1ll1ll_l1_,391)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⤔"),url,l1l111_l1_ (u"ࠪࠫ⤕"),l1l111_l1_ (u"ࠫࠬ⤖"),l1l111_l1_ (u"ࠬ࠭⤗"),l1l111_l1_ (u"࠭ࠧ⤘"),l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⤙"))
	html = response.content
	if type in [l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ⤚"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬ⤛")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ⤜"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"ࠫࡦࡲ࡬ࡠ࡯ࡲࡺ࡮࡫ࡳࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ⤝"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ⤞"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"࠭ࡴࡰࡲࡢ࡭ࡲࡪࡢࡠ࡯ࡲࡺ࡮࡫ࡳࠨ⤟"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡵࡱࡳ࠱࡮ࡳࡤࡣ࠯࡯࡭ࡸࡺࠠࡵ࡮ࡨࡪࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡷ࡯ࡧࡩࡶࠥ⤠"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⤡"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫ⤢"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡷ࡯ࡧࡩࡶࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸࠢ⤣"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⤤"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⤥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ⤦"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⤧"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ⤨"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭⤩"),html,re.DOTALL)
		block = l11llll_l1_[0]
		l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ⤪"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*l1lll1l_l1_)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬ⤫"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⤬"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⤭"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⤮") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⤯"),l1l111_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ⤰"))
		html = html.replace(l1l111_l1_ (u"ࠪࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ⤱"),l1l111_l1_ (u"ࠫࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡨࡲࡩࡄࠧ⤲"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ⤳"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==6:
			l1lll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⤴"),block,re.DOTALL)
			l1l1ll1ll_l1_,l1l1lll1_l1_,l1llll_l1_ = zip(*l1lll1l_l1_)
			items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭⤵"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ⤶") in url:
				items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⤷"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭⤸") in url:
				items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⤹"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⤺"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠫ⤻") in title: continue
		if l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭⤼") in title:
			title = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⤽"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⤾")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿ࠫ⤿"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ⥀") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥁"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ⥂") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥃"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ⥄") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥅"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⥆") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⥇"),l1lllll_l1_+title,l1ll1ll_l1_,391,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⥈"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	if type not in [l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨ⥉"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⥊")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⥋"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⥌"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⥍"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⥎")+title,l1ll1ll_l1_,391,l1l111_l1_ (u"ࠬ࠭⥏"),l1l111_l1_ (u"࠭ࠧ⥐"),type)
	return
def l1ll1l11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ⥑"))
	url = url.replace(server,l111l1_l1_)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⥒"),url,l1l111_l1_ (u"ࠩࠪ⥓"),l1l111_l1_ (u"ࠪࠫ⥔"),l1l111_l1_ (u"ࠫࠬ⥕"),l1l111_l1_ (u"ࠬ࠭⥖"),l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⥗"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⥘"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰࡪࡵࡲࡨ࡮ࡵࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⥙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⥚"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⥛"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1llll1lll1_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⥜"),url,l1l111_l1_ (u"ࠬ࠭⥝"),l1l111_l1_ (u"࠭ࠧ⥞"),l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⥟"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⥠"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࡡࠢࡽ࡞ࠪࡡ࠭ࡹࡨࡦࡣࡧࡩࡷࢂࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠮ࡡࠢࡽ࡞ࠪࡡࠬ⥡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡶ࡯ࡴࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡹࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪ࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⥢"),block,re.DOTALL)
		for type,l1ll11l_l1_,l1llll1llll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡦࡲࡳࡤࡶ࡬ࡢࡻࡨࡶࡤࡧࡪࡢࡺࠩࡴࡴࡹࡴ࠾ࠩ⥣")+l1ll11l_l1_+l1l111_l1_ (u"ࠬࠬ࡮ࡶ࡯ࡨࡁࠬ⥤")+l1llll1llll_l1_+l1l111_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠭⥥")+type
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⥦")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⥧")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫ࡮ࡪ࠽࡜ࠤࠪࡡࡩࡵࡷ࡯࡮ࡲࡥࡩࡡࠢࠨ࡟ࠣࡧࡱࡧࡳࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࡡࠢࠨ࡟ࡶࡦࡴࡾ࡛ࠣࠩࡠࠫࠬ࠭⥨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠫࠬ࡯࡭ࡨࠢࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠴ࠪࡀ࡝ࠥࠫࡢࡷࡵࡢ࡮࡬ࡸࡾࡡࠢࠨ࡟ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫ⥩"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l111l1ll_l1_,l1lllll1111_l1_ in items:
			if l1l111_l1_ (u"ࠫࡂ࠭⥪") in l1ll1l_l1_:
				host = l1ll1l_l1_.split(l1l111_l1_ (u"ࠬࡃࠧ⥫"))[1]
				title = l1l111l_l1_(host,l1l111_l1_ (u"࠭ࡨࡰࡵࡷࠫ⥬"))
			else: title = l1l111_l1_ (u"ࠧࠨ⥭")
			title = l1lllll1111_l1_+l1l111_l1_ (u"ࠨࠢࠪ⥮")+title
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⥯")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ⥰")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⥱"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭⥲"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ⥳"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ⥴"),l1l111_l1_ (u"ࠨ࠭ࠪ⥵"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⥶")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⥷"))
	return
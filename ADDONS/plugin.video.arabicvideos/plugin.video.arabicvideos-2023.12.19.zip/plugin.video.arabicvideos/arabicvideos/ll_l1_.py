# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䢟")
l11lllllll1l_l1_ = []
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䢠"):l1l111_l1_ (u"ࠨࠩ䢡")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l11llllll1_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䢢"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡦࡪࡰࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࡷࠥࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ䢣")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࠣࡘࡾࡶࡥ࠻ࠢ࡞ࠤࠬ䢤")+type+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䢥"))
		l11ll1llll1l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ䢦"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䢧"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ䢨"))
		datetime = time.strftime(l1l111_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏࠪ䢩"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ䢪")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ䢫")+str(kodi_version)
		message = l1l111_l1_ (u"ࠬ࠭䢬")
		if key not in list(l11ll1llll1l_l1_.keys()): l11ll1llll1l_l1_[key] = [line]
		else:
			if url not in str(l11ll1llll1l_l1_[key]): l11ll1llll1l_l1_[key].append(line)
			else: message = l1l111_l1_ (u"࠭࡜࡯๊ࠢิฬࠦวๅใํำ๏๎ࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡษ็ๅ๏ี๊้้สฮࠥอไห์่๊ࠣࠦสฺ็็ࠫ䢭")
		total = 0
		for key in list(l11ll1llll1l_l1_.keys()):
			l11ll1llll1l_l1_[key] = list(set(l11ll1llll1l_l1_[key]))
			total += len(l11ll1llll1l_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䢮"),l1l111_l1_ (u"ࠨࠩ䢯"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䢰"),l1l111_l1_ (u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫ䢱")+message+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠢ็่฾๊ๅࠡษ็ฬึ์วๆฮࠣ๎็๎ๅࠡสฯ้฾ࠦโศศ่อࠥฮวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤ๏าฯࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ์ุ๎แࠡ์฼ี฻ูࠦๅ์ๆࠤฬ๊ศา่ส้ัࠦร็ࠢอีุ๊่ࠠา๊ࠤฬ๊โศศ่อࠥหไ๊ࠢส่๊ฮัๆฮࠣ฽๋ีๅศࠢํูอำฺࠠัา๋ฬࠦ࠵ࠡใํำ๏๎็ศฬࠪ䢲")+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䢳")+l1l111_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣห้่วว็ฬࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠩ䢴")+str(total))
		if total>=5:
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ䢵"),l1l111_l1_ (u"ࠨࠩ䢶"),l1l111_l1_ (u"ࠩࠪ䢷"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䢸"),l1l111_l1_ (u"ࠫฬ๊ศา่ส้ัࠦฬๆ฻ࠣๆฬฬๅสࠢไ๎์อࠠ࠶ࠢไ๎ิ๐่่ษอࠤ้๋๋ࠠฮาࠤฬ๊ศา่ส้ัࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศๆีะࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡวิืฬ๊่ࠠา๊ࠤฬ๊โศศ่อ่ࠥศๅ่ࠢืาํวࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎็๎ๅࠡษ็้อืๅอࠢหๅา฻่ࠠา๊ࠤฬ๊แ๋ัํ์์อสࠡมࠤࠥࠬ䢹"))
			if l1llll111l_l1_==1:
				l11ll1llllll_l1_ = l1l111_l1_ (u"ࠬ࠭䢺")
				for key in list(l11ll1llll1l_l1_.keys()):
					l11ll1llllll_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠩ䢻")+key
					l1l111ll111l_l1_ = sorted(l11ll1llll1l_l1_[key],reverse=False,key=lambda l11ll1ll111l_l1_: l11ll1ll111l_l1_[0])
					for datetime,url in l1l111ll111l_l1_:
						l11ll1llllll_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࠪ䢼")+datetime+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭䢽")+l111l11_l1_(url)
					l11ll1llllll_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䢾")
				import l1l1l111l11_l1_
				succeeded = l1l1l111l11_l1_.l11l11lllll_l1_(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࡵࠪ䢿"),l1l111_l1_ (u"ࠫࠬ䣀"),False,l1l111_l1_ (u"ࠬ࠭䣁"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䣂"),l1l111_l1_ (u"ࠧࠨ䣃"),l11ll1llllll_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䣄"),l1l111_l1_ (u"ࠩࠪ䣅"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䣆"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ䣇"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䣈"),l1l111_l1_ (u"࠭ࠧ䣉"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣊"),l1l111_l1_ (u"ࠨใื่ฯูࠦๆๆํอࠥอไฦำึห้࠭䣋"))
			if l1llll111l_l1_!=-1:
				l11ll1llll1l_l1_ = {}
				l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䣌"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䣍"))
		if l11ll1llll1l_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䣎"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䣏"),l11ll1llll1l_l1_,l1ll111l11l_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11ll1l11lll_l1_(l1ll11l1_l1_,source)
	l1l111l1l111_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䣐"))
	l11ll1l1lll1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䣑"))
	l1l111ll1l11_l1_ = len(l1llll_l1_)-l1l111l1l111_l1_-l11ll1l1lll1_l1_
	l11lll111l11_l1_ = l1l111_l1_ (u"ࠨ็ืห์ีษ࠻ࠩ䣒")+str(l1l111l1l111_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࠦสฮ็ํ่࠿࠭䣓")+str(l11ll1l1lll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࠠฤะิํ࠿࠭䣔")+str(l1l111ll1l11_l1_)
	if not l1llll_l1_: result,l1l111ll1ll1_l1_ = l1l111_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䣕"),l1l111_l1_ (u"ࠬ࠭䣖")
	else:
		while True:
			l1l111ll1ll1_l1_ = l1l111_l1_ (u"࠭ࠧ䣗")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l11lll111l11_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ䣘")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠨีํีๆืࠧ䣙") in title and l1l111_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ䣚") in title:
					l11llllll1_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䣛"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ䣜")+title+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ䣝")+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䣞"))
					import l1l1l111l11_l1_
					l1l1l111l11_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䣟")
				else:
					l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䣠"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ䣡")+title+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䣢")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ䣣"))
					result,l1l111ll1ll1_l1_,l1l1l1l1l111_l1_ = l11llll1ll11_l1_(l1ll1ll_l1_,source,type)
			if l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣤") not in l1l111ll1ll1_l1_: l11llll1l1l1_l1_,l11ll111ll1_l1_ = l1l111ll1ll1_l1_,l1l111_l1_ (u"࠭ࠧ䣥")
			else: l11llll1l1l1_l1_,l11ll111ll1_l1_ = l1l111ll1ll1_l1_.split(l1l111_l1_ (u"ࠧ࡝ࡰࠪ䣦"),1)
			if result in [l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䣧"),l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䣨"),l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ䣩"),l1l111_l1_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ䣪"),l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ䣫")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䣬"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䣭"),l1l111_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ䣮")]: break
			elif result not in [l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭䣯"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ䣰")]: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣱"),l1l111_l1_ (u"ࠬ࠭䣲"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䣳"),l1l111_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ䣴")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣵")+l11llll1l1l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ䣶")+l11ll111ll1_l1_)
	if result==l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䣷") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣸"),l1l111_l1_ (u"ࠬ࠭䣹"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䣺"),l1l111_l1_ (u"ࠧิ์ิๅึࠦ็ัษࠣห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠥาัษࠢไ๎ิ๐่ࠡ฼ํี์࠭䣻")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣼")+l1l111ll1ll1_l1_)
	elif result in [l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ䣽"),l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ䣾")] and l1l111ll1ll1_l1_!=l1l111_l1_ (u"ࠫࠬ䣿"): l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䤀"),l1l111_l1_ (u"࠭ࠧ䤁"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䤂"),l1l111ll1ll1_l1_)
	return result
def l11llll1ll11_l1_(url,source,type=l1l111_l1_ (u"ࠨࠩ䤃")):
	url = url.strip(l1l111_l1_ (u"ࠩࠣࠫ䤄")).strip(l1l111_l1_ (u"ࠪࠪࠬ䤅")).strip(l1l111_l1_ (u"ࠫࡄ࠭䤆")).strip(l1l111_l1_ (u"ࠬ࠵ࠧ䤇"))
	l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11lll_l1_(url,source)
	if l1l111ll1ll1_l1_==l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䤈"): return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭䤉"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䤊")
			else:
				l1l11l11llll_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l11llllll1_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䤋"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡴࡧ࡯ࡩࡨࡺࡥࡥࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ䤌")+title+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ䤍")+str(l1l11l11llll_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䤎"))
				if l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ䤏") in l1l11l11llll_l1_ and l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ䤐") in l1l11l11llll_l1_:
					l1l11l1l11l1_l1_,l1l1l1l111l1_l1_,l1l1l1l1l111_l1_ = l11lll1l111l_l1_(l1l11l11llll_l1_)
					if l1l1l1l1l111_l1_: l1l11l11llll_l1_ = l1l1l1l1l111_l1_[0]
					else: l1l11l11llll_l1_ = l1l111_l1_ (u"ࠨࠩ䤑")
				if not l1l11l11llll_l1_: result = l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䤒")
				else: result = l1llll111_l1_(l1l11l11llll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ䤓"),l1l111_l1_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ䤔"),l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ䤕")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䤖"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䤗"),l1l111_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ䤘")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䤙"),l1l111_l1_ (u"ࠪࠫ䤚"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䤛"),l1l111_l1_ (u"ࠬอไๆๆไࠤ้๋๋ࠠ฻่่ࠥาัษ่่ࠢๆฺ๋ࠦำ๊ࠫ䤜"))
	else:
		result = l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䤝")
		l11ll11ll1_l1_ = l1l111l1l1_l1_(url)
		if l11ll11ll1_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l111ll1ll1_l1_,l1llll_l1_
def l11llll11l11_l1_(url,source):
	l1lllll1_l1_,l11llll1lll1_l1_,server,l11ll1ll11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠧࠨ䤞"),l1l111_l1_ (u"ࠨࠩ䤟"),l1l111_l1_ (u"ࠩࠪ䤠"),l1l111_l1_ (u"ࠪࠫ䤡"),l1l111_l1_ (u"ࠫࠬ䤢"),l1l111_l1_ (u"ࠬ࠭䤣"),l1l111_l1_ (u"࠭ࠧ䤤")
	if l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䤥") in url:
		l1lllll1_l1_,l11llll1lll1_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䤦"),1)
		l11llll1lll1_l1_ = l11llll1lll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࠬ䤧")+l1l111_l1_ (u"ࠪࡣࡤ࠭䤨")+l1l111_l1_ (u"ࠫࡤࡥࠧ䤩")+l1l111_l1_ (u"ࠬࡥ࡟ࠨ䤪")
		l11llll1lll1_l1_ = l11llll1lll1_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1ll1l1l1l11_l1_ = l11llll1lll1_l1_.split(l1l111_l1_ (u"࠭࡟ࡠࠩ䤫"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠧࠨ䤬"): l111l1ll_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ䤭")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠩࡳࠫ䤮"),l1l111_l1_ (u"ࠪࠫ䤯")).replace(l1l111_l1_ (u"ࠫࠥ࠭䤰"),l1l111_l1_ (u"ࠬ࠭䤱"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"࠭࠿ࠨ䤲")).strip(l1l111_l1_ (u"ࠧ࠰ࠩ䤳")).strip(l1l111_l1_ (u"ࠨࠨࠪ䤴"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ䤵"))
	if name: l11ll1ll11l1_l1_ = name
	else: l11ll1ll11l1_l1_ = server
	l11ll1ll11l1_l1_ = l1l111l_l1_(l11ll1ll11l1_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䤶"))
	name = name.replace(l1l111_l1_ (u"๊ࠫฮวีำࠪ䤷"),l1l111_l1_ (u"ࠬ࠭䤸")).replace(l1l111_l1_ (u"࠭ำ๋ำไีࠬ䤹"),l1l111_l1_ (u"ࠧࠨ䤺")).replace(l1l111_l1_ (u"ࠨษ็ࠤࠬ䤻"),l1l111_l1_ (u"ࠩࠣࠫ䤼")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䤽"),l1l111_l1_ (u"ࠫࠥ࠭䤾"))
	l11llll1lll1_l1_ = l11llll1lll1_l1_.replace(l1l111_l1_ (u"๋ࠬศศึิࠫ䤿"),l1l111_l1_ (u"࠭ࠧ䥀")).replace(l1l111_l1_ (u"ࠧิ์ิๅึ࠭䥁"),l1l111_l1_ (u"ࠨࠩ䥂")).replace(l1l111_l1_ (u"ࠩส่ࠥ࠭䥃"),l1l111_l1_ (u"ࠪࠤࠬ䥄")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䥅"),l1l111_l1_ (u"ࠬࠦࠧ䥆"))
	l11ll1ll11l1_l1_ = l11ll1ll11l1_l1_.replace(l1l111_l1_ (u"࠭ๅษษืีࠬ䥇"),l1l111_l1_ (u"ࠧࠨ䥈")).replace(l1l111_l1_ (u"ࠨีํีๆืࠧ䥉"),l1l111_l1_ (u"ࠩࠪ䥊")).replace(l1l111_l1_ (u"ࠪห้ࠦࠧ䥋"),l1l111_l1_ (u"ࠫࠥ࠭䥌")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䥍"),l1l111_l1_ (u"࠭ࠠࠨ䥎"))
	return l1lllll1_l1_,l11llll1lll1_l1_,server,l11ll1ll11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l111l1l11l_l1_(url,source):
	l1l111lllll1_l1_,name,l11l1lll1l1_l1_,l11llll11l1l_l1_,l11llll11ll1_l1_,l11llllllll1_l1_,l1l111lll1l1_l1_ = l1l111_l1_ (u"ࠧࠨ䥏"),l1l111_l1_ (u"ࠨࠩ䥐"),None,None,None,None,None
	l1lllll1_l1_,l11llll1lll1_l1_,server,l11ll1ll11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll11l11_l1_(url,source)
	if l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䥑") in url:
		if   type==l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥࠩ䥒"): type = l1l111_l1_ (u"ࠫࠥ࠭䥓")+l1l111_l1_ (u"๋ࠬแืๆࠪ䥔")
		elif type==l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ䥕"): type = l1l111_l1_ (u"ࠧࠡࠩ䥖")+l1l111_l1_ (u"ࠨุ่ࠧฬํฯสࠩ䥗")
		elif type==l1l111_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䥘"): type = l1l111_l1_ (u"ࠪࠤࠬ䥙")+l1l111_l1_ (u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭䥚")
		elif type==l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䥛"): type = l1l111_l1_ (u"࠭ࠠࠨ䥜")+l1l111_l1_ (u"ࠧࠦࠧࠨฮา๋๊ๅࠩ䥝")
		elif type==l1l111_l1_ (u"ࠨࠩ䥞"): type = l1l111_l1_ (u"ࠩࠣࠫ䥟")+l1l111_l1_ (u"ࠪࠩࠪࠫࠥࠨ䥠")
		if l111lll_l1_!=l1l111_l1_ (u"ࠫࠬ䥡"):
			if l1l111_l1_ (u"ࠬࡳࡰ࠵ࠩ䥢") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"࠭ࠥࠨ䥣")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠧࠡࠩ䥤")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠨࠩ䥥"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬ䥦")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠤࠬ䥧")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䥨")		in source: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䥩")		in source: l11l1lll1l1_l1_	= l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࠬ䥪")
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䥫")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ䥬")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ䥭")	in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ䥮")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䥯")
	elif l1l111_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ䥰")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭䥱")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࠭䥲")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨࡶ࠺ࡱࡪ࡫࡬ࠨ䥳")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ䥴")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ䥵")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䥶")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬ็ฬาࠩ䥷")			in name:   l11l1lll1l1_l1_	= l1l111_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ䥸")
	elif l1l111_l1_ (u"ࠧโๆึ฻๏์ࠧ䥹")		in name:   l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠨࡲࡤࡰࡪࡹࡴࡪࡰࡨࠫ䥺")
	elif l1l111_l1_ (u"ࠩࡪࡨࡷ࡯ࡶࡦࠩ䥻")		in l1lllll1_l1_:   l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ䥼")
	elif l1l111_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ䥽")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ䥾")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䥿")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ䦀")		in name:   l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭䦁")	in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ䦂")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ䦃")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ䦄")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭䦅")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ䦆")		in server: l11l1lll1l1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ䦇")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ䦈")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ䦉")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ䦊")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭䦋")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ䦌")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࠬ䦍")	 	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ䦎")
	elif l1l111_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ䦏")	 	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ䦐")
	elif l1l111_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ䦑")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨ䦒")
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ䦓")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨ䦔")
	elif l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ䦕")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪ䦖")
	elif l1l111_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ䦗")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ䦘")
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ䦙")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䦚")
	elif l1l111_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ䦛")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳࠧ䦜")
	elif l1l111_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ䦝")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䦞")
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭䦟")	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ䦠")
	elif l1l111_l1_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭䦡")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ䦢")
	elif l1l111_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ䦣")	 	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠨࡥࡤࡸࡨ࡮ࠧ䦤")
	elif l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ䦥")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䦦")
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ䦧")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ䦨")
	elif l1l111_l1_ (u"࠭ࡶࡪࡦ࡫ࡨࠬ䦩")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭䦪")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡺ࡮࡯ࡤࠨ䦫")		in server: l11llllllll1_l1_	= l11ll1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ䦬")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ䦭")
	elif l1l111_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ䦮")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ䦯")
	elif l1l111_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䦰") 	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ䦱")
	elif l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ䦲")	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ䦳")
	elif l1l111_l1_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨ䦴")	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ䦵")
	elif l1l111_l1_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ䦶") 	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ䦷")
	elif l1l111_l1_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ䦸")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ䦹")
	elif l1l111_l1_ (u"ࠩࡸࡴࡵ࠭䦺") 			in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ䦻")
	elif l1l111_l1_ (u"ࠫࡺࡶࡢࠨ䦼") 			in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠬࡻࡰࡣࡱࡰࠫ䦽")
	elif l1l111_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭䦾") 		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䦿")
	elif l1l111_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ䧀") 	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䧁")
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ䧂")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䧃")
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ䧄") 		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭䧅")
	elif l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ䧆") 	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ䧇")
	elif l1l111_l1_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭䧈")	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䧉")
	elif l1l111_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ䧊")	in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ䧋")
	elif l1l111_l1_ (u"࠭ࡨࡥ࠯ࡦࡨࡳ࠭䧌")		in server: l11llll11l1l_l1_	= l1l111_l1_ (u"ࠧࡩࡦ࠰ࡧࡩࡴࠧ䧍")
	if   l11l1lll1l1_l1_:	l1l111lllll1_l1_,name = l1l111_l1_ (u"ࠨะสูࠬ䧎"),l11l1lll1l1_l1_
	elif l11llllllll1_l1_:		l1l111lllll1_l1_,name = l1l111_l1_ (u"ࠩࠨ้าีฯࠨ䧏"),l11llllllll1_l1_
	elif l11llll11l1l_l1_:		l1l111lllll1_l1_,name = l1l111_l1_ (u"ࠪࠩࠪ฿วๆ่ࠢ฽ึ๎แࠨ䧐"),l11llll11l1l_l1_
	elif l11llll11ll1_l1_:	l1l111lllll1_l1_,name = l1l111_l1_ (u"ฺࠫࠪࠫࠥษ่ࠤำอัอ์ࠪ䧑"),l11llll11ll1_l1_
	elif l1l111lll1l1_l1_:	l1l111lllll1_l1_,name = l1l111_l1_ (u"ࠬࠫࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ䧒"),l11ll1ll11l1_l1_
	else:			l1l111lllll1_l1_,name = l1l111_l1_ (u"࠭ࠥࠦࠧࠨࠩ฾อๅࠡ็ฯ๋ํ๊ࠧ䧓"),l11ll1ll11l1_l1_
	return l1l111lllll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l11lllll1l1l_l1_(url,source):
	l1lllll1_l1_,l11llll1lll1_l1_,server,l11ll1ll11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll11l11_l1_(url,source)
	if   l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭䧔")		in source: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ䧕")		in source: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ䧖")		in source: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ䧗")		in source: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭䧘")		in source: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ䧙")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮ࠩ䧚")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ䧛")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ䧜")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ䧝")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ䧞")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111lllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䧟")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111lll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ䧠")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111lll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡴࡷ࠯ࡩ࠲ࡨࡵ࡭ࠨ䧡")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111lll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䧢")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1ll1lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ䧣")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ䧤")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll111l1l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ䧥")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡻࡹ࠴ࡶࠩ䧦")			in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1ll11111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ䧧")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䧨")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ䧩")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳࡬ࡪࡩ࡫ࡸࠬ䧪")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬ䧫")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ䧬")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll11lll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ䧭")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11llll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ䧮")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䧯")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䧰")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ䧱")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡶࡨࡧ࡭࠭䧲")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪ࡫ࡺࡲࡦࡵࡧࡦ࡬ࠬ䧳")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡶࡦࡺࡥࠨ䧴")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡶࡣࡳࡧࡹ࡭ࡪࡽࠧ䧵")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭䧶")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ䧷")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䧸")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ䧹"),[l1l111_l1_ (u"ࠪࠫ䧺")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭䧻")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111lll11l_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䧼")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1llll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬ䧽")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l111lll1lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡶࡲࡥࡥࡲ࠭䧾") 		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ䧿"),[l1l111_l1_ (u"ࠩࠪ䨀")],[l1lllll1_l1_]
	else: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䨁"),[l1l111_l1_ (u"ࠫࠬ䨂")],[l1lllll1_l1_]
	return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
def l11llll11111_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䨃"))
	l11lllll1l11_l1_ = False
	if   l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࠬ䨄")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111ll_l1_(url)
	elif l1l111_l1_ (u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧ䨅")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸࠬ䨆") in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1llll11_l1_(url)
	elif l1l111_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ䨇")	in url: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111111_l1_(url)
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䨈")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡶࡦࡺࡥࠨ䨉")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䨊")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(url)
	elif l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䨋")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l111l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ䨌")		in url   : l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l11l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䨍")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111lllll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䨎")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lllll1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䨏")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡪ࠻ࡴࡴࡣࡵࠫ䨐")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l1l1l1_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䨑")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ䨒")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡩࡦ࠰ࡧࡩࡴࠧ䨓")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䨔")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ䨕")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䨖")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ䨗")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ䨘")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ䨙")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11l111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ䨚")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lll11_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ䨛")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lll11_l1_(url)
	elif l1l111_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䨜") 		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䨝"),[l1l111_l1_ (u"ࠫࠬ䨞")],[url]
	elif l1l111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䨟") 	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1lll_l1_(url)
	elif l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䨠")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111l111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳ࡭ࡵࠧ䨡")in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䨢") 	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111ll1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䨣")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111ll11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡹࡵࡨࠧ䨤") 			in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡺࡶࡰࠨ䨥") 			in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䨦") 		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllllllll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䨧") 	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1llll_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䨨")		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ䨩") 		in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lll1l_l1_(url)
	elif l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䨪") 	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111lll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䨫")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l1l11l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ䨬")	in server: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1111_l1_(url)
	else: l11lllll1l11_l1_ = True
	if l11lllll1l11_l1_ or l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ䨭") in l1l111ll1ll1_l1_:
		l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠥࡌࡡࡪ࡮ࡨࡨࠬ䨮"),[],[]
	return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll1ll111_l1_(l1l1l1l11ll1_l1_):
	if l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䨯") in str(type(l1l1l1l11ll1_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1l1l11ll1_l1_:
			if l1l111_l1_ (u"ࠨࡵࡷࡶࠬ䨰") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䨱"),l1l111_l1_ (u"ࠪࠫ䨲")).replace(l1l111_l1_ (u"ࠫࡡࡴࠧ䨳"),l1l111_l1_ (u"ࠬ࠭䨴")).strip(l1l111_l1_ (u"࠭ࠠࠨ䨵"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1l1l11ll1_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ䨶"),l1l111_l1_ (u"ࠨࠩ䨷")).replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ䨸"),l1l111_l1_ (u"ࠪࠫ䨹")).strip(l1l111_l1_ (u"ࠫࠥ࠭䨺"))
	return l1ll_l1_
def l1l111l11lll_l1_(url,source):
	l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䨻"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䨼")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䨽"))
	l1l111lll1l1_l1_,l1ll1ll_l1_,l11lll1ll11l_l1_ = l1l111_l1_ (u"ࠨࡋࡑࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ䨾"),l1l111_l1_ (u"ࠩࠪ䨿"),l1l111_l1_ (u"ࠪࠫ䩀")
	l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l1l_l1_(url,source)
	l1llll_l1_ = l11lll1ll111_l1_(l1llll_l1_)
	if l1l111ll1ll1_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䩁"): return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_: l1ll1ll_l1_ = l1llll_l1_[0]
	if l1l111ll1ll1_l1_==l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䩂"):
		l1l111lll1l1_l1_ = l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠬ䩃")
		l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11111_l1_(l1ll1ll_l1_,source)
		l1llll_l1_ = l11lll1ll111_l1_(l1llll_l1_)
		if l1l111ll1ll1_l1_==l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䩄"): return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ䩅") in l1l111ll1ll1_l1_:
			l11lll1ll11l_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠪ䩆")+l1l111ll1ll1_l1_
			l1l111lll1l1_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ䩇")
			l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lllll_l1_(l1ll1ll_l1_,source)
			l1llll_l1_ = l11lll1ll111_l1_(l1llll_l1_)
			if l1l111ll1ll1_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䩈"): return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ䩉") in l1l111ll1ll1_l1_:
				l11lll1ll11l_l1_ += l1l111_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ䩊")+l1l111ll1ll1_l1_
				l1l111lll1l1_l1_ = l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭䩋")
				l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1llll1_l1_(l1ll1ll_l1_,source)
				l1llll_l1_ = l11lll1ll111_l1_(l1llll_l1_)
				if l1l111ll1ll1_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䩌"): return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ䩍") in l1l111ll1ll1_l1_:
					l11lll1ll11l_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠫ䩎")+l1l111ll1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭䩏") in l1l111ll1ll1_l1_: l11lll1ll11l_l1_ = l1l111_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ䩐")+l1l111ll1ll1_l1_
	if l1llll_l1_: l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䩑"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ䩒")+l1l111lll1l1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䩓")+url+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䩔")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭䩕")+str(l1llll_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠧ䩖"))
	else: l11llllll1_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䩗"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䩘")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䩙")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ䩚")+l11lll1ll11l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䩛"))
	l11lll1ll11l_l1_ = l111l11_l1_(l11lll1ll11l_l1_)
	return l11lll1ll11l_l1_,l1l1lll1_l1_,l1llll_l1_
def l11ll1l11lll_l1_(l1l1l1l1l111_l1_,source):
	l1l1l1l1lll_l1_ = l1ll1ll1_l1_
	data = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䩜"),l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩝"),l1l1l1l1l111_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l111l1llll_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1l1l1l1l111_l1_:
		if l1l111_l1_ (u"ࠬ࠵࠯ࠨ䩞") not in l1ll1ll_l1_: continue
		l1l111lllll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111l1l11l_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ䩟"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䩠"))
		l1l111l1llll_l1_.append([l1l111lllll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l111l1llll_l1_:
		l11lll1ll1ll_l1_ = sorted(l1l111l1llll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll111ll_l1_ = []
		for line in l11lll1ll1ll_l1_:
			if line not in l11ll111ll_l1_:
				l11ll111ll_l1_.append(line)
		for l1l111lllll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll111ll_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䩡")
			title = l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䩢")+l1l111_l1_ (u"ࠪࠤࠬ䩣")+type+l1l111_l1_ (u"ࠫࠥ࠭䩤")+l1l111lllll1_l1_+l1l111_l1_ (u"ࠬࠦࠧ䩥")+l111l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䩦")+l111lll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䩧")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠨࠢࠪ䩨")+server
			title = title.replace(l1l111_l1_ (u"ࠩࠨࠫ䩩"),l1l111_l1_ (u"ࠪࠫ䩪")).strip(l1l111_l1_ (u"ࠫࠥ࠭䩫")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䩬"),l1l111_l1_ (u"࠭ࠠࠨ䩭")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䩮"),l1l111_l1_ (u"ࠨࠢࠪ䩯")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䩰"),l1l111_l1_ (u"ࠪࠤࠬ䩱"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩲"),l1l1l1l1l111_l1_,data,l1l1l1l1lll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l11lll1lllll_l1_(url,source):
	l1111ll1l11_l1_ = l1l111_l1_ (u"ࠬ࠭䩳")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l1111ll1l11_l1_ = str(error)
	if not l1lll_l1_:
		if l1111ll1l11_l1_==l1l111_l1_ (u"࠭ࠧ䩴"):
			l1111ll1l11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111ll1l11_l1_)
		l1l111ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷ࠦࡆࡢ࡫࡯ࡩࡩ࠭䩵")
		l1l111ll1ll1_l1_ += l1l111_l1_ (u"ࠨࠢࠪ䩶")+l1111ll1l11_l1_.splitlines()[-1]
		return l1l111ll1ll1_l1_,[],[]
	return l1l111_l1_ (u"ࠩࠪ䩷"),[l1l111_l1_ (u"ࠪࠫ䩸")],[l1lll_l1_]
def l11lll1llll1_l1_(url,source):
	l1111ll1l11_l1_ = l1l111_l1_ (u"ࠫࠬ䩹")
	l1lll_l1_ = False
	try:
		import youtube_dl
		l1l1111l1lll_l1_ = youtube_dl.YoutubeDL({l1l111_l1_ (u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸࠧ䩺"): True})
		l1lll_l1_ = l1l1111l1lll_l1_.extract_info(url,download=False)
	except Exception as error: l1111ll1l11_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䩻") not in list(l1lll_l1_.keys()):
		if l1111ll1l11_l1_==l1l111_l1_ (u"ࠧࠨ䩼"):
			l1111ll1l11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111ll1l11_l1_)
		l1l111ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠠࡇࡣ࡬ࡰࡪࡪࠧ䩽")
		l1l111ll1ll1_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䩾")+l1111ll1l11_l1_.splitlines()[-1]
		return l1l111ll1ll1_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ䩿")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫ䪀")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䪁")])
		return l1l111_l1_ (u"࠭ࠧ䪂"),l1l1lll1_l1_,l1llll_l1_
def l1l1111l1l11_l1_(url):
	if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭䪃") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠨࠩ䪄"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡁࡓࡃࡅࠫ䪅"),[],[]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪆"),[l1l111_l1_ (u"ࠫࠬ䪇")],[url]
def l1ll11ll1l1_l1_(url):
	l1ll11l1_l1_,l111lll111_l1_ = [],[]
	if l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠴࡭ࡱ࠶ࡂࡺ࡮ࡪ࠽ࠨ䪈") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䪉"),url,l1l111_l1_ (u"ࠧࠨ䪊"),l1l111_l1_ (u"ࠨࠩ䪋"),False,l1l111_l1_ (u"ࠩࠪ䪌"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠳ࡶࡸࠬ䪍"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䪎") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪏")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪐"))
			l111lll111_l1_.append(server)
	elif l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦ࠰ࡦࡳࡲ࠭䪑") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪒"),url,l1l111_l1_ (u"ࠩࠪ䪓"),l1l111_l1_ (u"ࠪࠫ䪔"),l1l111_l1_ (u"ࠫࠬ䪕"),l1l111_l1_ (u"ࠬ࠭䪖"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠷ࡴࡤࠨ䪗"))
		html = response.content
		l1llllllll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࡤ࡝ࠫ࠱࠮ࡄࡢࠩ࡝ࠫࠬ࠲ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ䪘"),html,re.DOTALL)
		if l1llllllll1l_l1_:
			l1llllllll1l_l1_ = l1llllllll1l_l1_[0]
			l1ll1l1l111l_l1_ = l1ll1lll111l_l1_(l1llllllll1l_l1_)
			l1ll1l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭࠱࠭䪙"),l1ll1l1l111l_l1_,re.DOTALL)
			if l1ll1l1111ll_l1_:
				l1ll1l1111ll_l1_ = l1ll1l1111ll_l1_[0]
				l1ll1l1111ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䪚"),l1ll1l1111ll_l1_)
				for dict in l1ll1l1111ll_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࠨ䪛")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ䪜")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䪝"))
					l111lll111_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䪞")+server)
		elif l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪟") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䪠")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䪡"))
			l111lll111_l1_.append(server)
		if l1l111_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࡰࡱࠪ䪢") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡻࡲ࡭࠿ࠪ䪣"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬࠧ䪤"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111lll111_l1_.append(l1l111_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸࠦࡧࡰࡱࡪࡰࡪ࠭䪥"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䪦"))
		l111lll111_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ䪧"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䪨"),l111lll111_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䪩"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䪪"),[l1l111_l1_ (u"ࠬ࠭䪫")],[l1ll1ll_l1_]
def l11ll1llll11_l1_(url):
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䪬"):l1l111_l1_ (u"ࠧࡌࡱࡧ࡭࠴࠭䪭")+str(kodi_version)}
	for l1l111lll1_l1_ in range(50):
		time.sleep(0.100)
		response = l1111ll1lll_l1_(l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪮"),url,l1l111_l1_ (u"ࠩࠪ䪯"),headers,False,l1l111_l1_ (u"ࠪࠫ䪰"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ䪱"))
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪲") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪳")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭䪴")+headers[l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䪵")]
			return l1l111_l1_ (u"ࠩࠪ䪶"),[l1l111_l1_ (u"ࠪࠫ䪷")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪ䪸"),[],[]
def l1l111111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䪹"),url,l1l111_l1_ (u"࠭ࠧ䪺"),l1l111_l1_ (u"ࠧࠨ䪻"),l1l111_l1_ (u"ࠨࠩ䪼"),l1l111_l1_ (u"ࠩࠪ䪽"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩ䪾"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨ䪿"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠬ࠭䫀"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ䫁"),[],[]
def l1llll1l11l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䫂"),url,l1l111_l1_ (u"ࠨࠩ䫃"),l1l111_l1_ (u"ࠩࠪ䫄"),l1l111_l1_ (u"ࠪࠫ䫅"),l1l111_l1_ (u"ࠫࠬ䫆"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ䫇"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䫈"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ䫉"),[l1l111_l1_ (u"ࠨࠩ䫊")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭䫋"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䫌") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䫍"),url,l1l111_l1_ (u"ࠬ࠭䫎"),l1l111_l1_ (u"࠭ࠧ䫏"),l1l111_l1_ (u"ࠧࠨ䫐"),l1l111_l1_ (u"ࠨࠩ䫑"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ䫒"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫓"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䫔") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫕"),[l1l111_l1_ (u"࠭ࠧ䫖")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩ䫗"),[],[]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫘"),[l1l111_l1_ (u"ࠩࠪ䫙")],[url]
def l1111lllll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䫚"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䫛"),l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䫜"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䫝")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫞"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䫟"),l1l111_l1_ (u"ࠩࠪ䫠"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ䫡"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫢"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ䫣"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䫤"),[l1l111_l1_ (u"ࠧࠨ䫥")],[l1ll1ll_l1_]
def l1ll111l1l1l_l1_(url):
	headers = {l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䫦"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䫧")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䫨"),url,l1l111_l1_ (u"ࠫࠬ䫩"),headers,l1l111_l1_ (u"ࠬ࠭䫪"),l1l111_l1_ (u"࠭ࠧ䫫"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩ䫬"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫭"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭䫮"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䫯"),[l1l111_l1_ (u"ࠫࠬ䫰")],[l1ll1ll_l1_]
def l1ll1ll1lll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䫱"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䫲")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫳"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䫴"),l1l111_l1_ (u"ࠩࠪ䫵"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䫶"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ䫷"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ䫸"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䫹") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䫺")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫻"),[l1l111_l1_ (u"ࠩࠪ䫼")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䫽"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䫾")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䫿"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䬀"),l1l111_l1_ (u"ࠧࠨ䬁"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪ䬂"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ䬃"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡄࡆࡉࡕࠧ䬄"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䬅"),[l1l111_l1_ (u"ࠬ࠭䬆")],[l1ll1ll_l1_]
def l111111lll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䬇"),url,l1l111_l1_ (u"ࠧࠨ䬈"),l1l111_l1_ (u"ࠨࠩ䬉"),l1l111_l1_ (u"ࠩࠪ䬊"),l1l111_l1_ (u"ࠪࠫ䬋"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪ䬌"))
	html = response.content
	l11ll1ll1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䬍"),html,re.DOTALL|re.IGNORECASE)
	if l11ll1ll1l11_l1_:
		l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_[0][2:]
		l11ll1ll1l11_l1_ = base64.b64decode(l11ll1ll1l11_l1_)
		if PY3: l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䬎"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬏"),l11ll1ll1l11_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䬐")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪ䬑"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䬒") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䬓")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䬔"),[l1l111_l1_ (u"࠭ࠧ䬕")],[l1ll1ll_l1_]
def l1l111ll1l1l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䬖"),url,l1l111_l1_ (u"ࠨࠩ䬗"),l1l111_l1_ (u"ࠩࠪ䬘"),l1l111_l1_ (u"ࠪࠫ䬙"),l1l111_l1_ (u"ࠫࠬ䬚"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧ䬛"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䬜"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫ䬝"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䬞"),[l1l111_l1_ (u"ࠩࠪ䬟")],[l1ll1ll_l1_]
def l1l1l111l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ䬠"))[-1]
	if l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ䬡") in url: url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ䬢"),l1l111_l1_ (u"࠭ࠧ䬣"))
	url = url.replace(l1l111_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴࠭䬤"),l1l111_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩ䬥"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䬦"),url,l1l111_l1_ (u"ࠪࠫ䬧"),l1l111_l1_ (u"ࠫࠬ䬨"),l1l111_l1_ (u"ࠬ࠭䬩"),l1l111_l1_ (u"࠭ࠧ䬪"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ䬫"))
	html = response.content
	l1l111ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ䬬")
	error = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬭"),html,re.DOTALL)
	if error: l1l111ll1ll1_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬮"),html,re.DOTALL)
	if not url and l1l111ll1ll1_l1_:
		return l1l111ll1ll1_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠫࡡࡢࠧ䬯"),l1l111_l1_ (u"ࠬ࠭䬰"))
	l1l1l1l111l1_l1_,l1l1l1l1l111_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬱"),html,re.DOTALL)
	if owner: l1l1111ll111_l1_,l1l1111l1ll1_l1_,l1l11l111lll_l1_ = owner[0]
	else: l1l1111ll111_l1_,l1l1111l1ll1_l1_,l1l11l111lll_l1_ = l1l111_l1_ (u"ࠧࠨ䬲"),l1l111_l1_ (u"ࠨࠩ䬳"),l1l111_l1_ (u"ࠩࠪ䬴")
	l1l11l111lll_l1_ = l1l11l111lll_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭䬵"),l1l111_l1_ (u"ࠫ࠴࠭䬶"))
	l1l1111l1ll1_l1_ = escapeUNICODE(l1l1111l1ll1_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ䬷")+l1l1111l1ll1_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䬸")]+l1l1l1l111l1_l1_
	l1llll_l1_ = [l1l11l111lll_l1_]+l1l1l1l1l111_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ䬹")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠨ่่ࠢๆ࠯ࠧ䬺"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䬻"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ䬼")+l1l11l111lll_l1_+l1l111_l1_ (u"ࠫࠫࡺࡥࡹࡶࡀࠫ䬽")+l1l1111l1ll1_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ䬾")+new_path+l1l111_l1_ (u"ࠨࠩࠣ䬿"))
		return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䭀"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠨࠩ䭁"),[l1l111_l1_ (u"ࠩࠪ䭂")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䭃"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䭄"),l1l111_l1_ (u"ࠬ࠭䭅"),l1l111_l1_ (u"࠭ࠧ䭆"),l1l111_l1_ (u"ࠧࠨ䭇"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧ䭈"))
	html = response.content
	if l1l111_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨ䭉") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䭊"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䭋"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭䭌"),[],[]
	url = url[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䭍") not in url: url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䭎")+url
	return l1l111_l1_ (u"ࠨࠩ䭏"),[l1l111_l1_ (u"ࠩࠪ䭐")],[url]
def l11lll1l111l_l1_(url):
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䭑") : l1l111_l1_ (u"ࠫࠬ䭒") }
	if l1l111_l1_ (u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ䭓") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䭔"),headers,l1l111_l1_ (u"ࠧࠨ䭕"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪ䭖"))
		items = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䭗"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠪࠫ䭘"),[l1l111_l1_ (u"ࠫࠬ䭙")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䭚"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䭛"),l1l111_l1_ (u"ࠧࠨ䭜"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ䭝"),message[0])
				return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ䭞")+message[0],[],[]
	else:
		l1llllllll1_l1_ = l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭䭟")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䭠"),headers,l1l111_l1_ (u"ࠬ࠭䭡"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ䭢"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䭣"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䭤"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠩ࠱ࡶࡦࡸࠧ䭥") in block or l1l111_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ䭦") in block: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ䭧"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䭨"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"࠭ࠧ䭩"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩ䭪"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭䭫"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䭬"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪ䭭"),block,re.DOTALL)
		l1l111ll11l1_l1_,l1l1lll1_l1_,l11llll1l1ll_l1_,l1llll_l1_,l11llll11lll_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䭮") in l1ll1ll_l1_:
				l1l111ll11l1_l1_,l11llll1l1ll_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11llll1l1ll_l1_
				if l1l111ll11l1_l1_[0]==l1l111_l1_ (u"ࠬ࠳࠱ࠨ䭯"): l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ䭰")+l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭䭱")+l1llllllll1_l1_)
				else:
					for title in l1l111ll11l1_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭䭲")+l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ䭳")+l1llllllll1_l1_+l1l111_l1_ (u"ࠪࠤࠬ䭴")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭䭵"),l1l111_l1_ (u"ࠬ࠭䭶"))
				title = title.strip(l1l111_l1_ (u"࠭ࠢࠨ䭷"))
				title = l1l111_l1_ (u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭䭸")+l1l111_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ䭹")+l1llllllll1_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭺")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬ䭻") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䭼"),headers,l1l111_l1_ (u"ࠬ࠭䭽"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠺ࡺࡨࠨ䭾"))
		items = re.findall(l1l111_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯ࠦ䭿"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡฬะ้๏๊ࠠฯษุࠤࠬ䮀")+l1l111_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ䮁")+l1llllllll1_l1_+l1l111_l1_ (u"ࠪࠤࠬ䮂")+resolution.split(l1l111_l1_ (u"ࠫࡽ࠭䮃"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ䮄")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭䮅")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ䮆")+hash
			l11llll11lll_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l11llll11lll_l1_ = set(l11llll11lll_l1_)
		l1l1111111l1_l1_,l1l11l11ll1l_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠣࠢࠫࡠࡩ࠰ࡸࡽ࡞ࡧ࠮࠮ࠬࠦࠣ䮇"),title+l1l111_l1_ (u"ࠩࠩࠪࠬ䮈"),re.DOTALL)
			for resolution in l11llll11lll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠪࡼࠬ䮉"))[1])
			l1l1111111l1_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠦࠫࠬࠨ࠯ࠬࡂ࠭࠭ࡢࡤࠫࠫࠩࠪࠧ䮊"),l1l111_l1_ (u"ࠬࠬࠦࠨ䮋")+l1l1111111l1_l1_[i]+l1l111_l1_ (u"࠭ࠦࠧࠩ䮌"),re.DOTALL)
			l1l11l11ll1l_l1_.append( [l1l1111111l1_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l11l11ll1l_l1_ = sorted(l1l11l11ll1l_l1_, key=lambda x: x[3], reverse=True)
		l1l11l11ll1l_l1_ = sorted(l1l11l11ll1l_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l11l11ll1l_l1_)):
			l1l1lll1_l1_.append(l1l11l11ll1l_l1_[i][0])
			l1llll_l1_.append(l1l11l11ll1l_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䮍"),[],[]
	return l1l111_l1_ (u"ࠨࠩ䮎"),l1l1lll1_l1_,l1llll_l1_
def l11ll1l1l1l1_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠩࡂࠫ䮏"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䮐") : l1l111_l1_ (u"ࠫࠬ䮑") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䮒"),headers,l1l111_l1_ (u"࠭ࠧ䮓"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺࠧ䮔"))
	items = re.findall(l1l111_l1_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ䮕"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䮖"),[l1l111_l1_ (u"ࠪࠫ䮗")],[url]
def l1l1111l1l1l_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䮘") : l1l111_l1_ (u"ࠬ࠭䮙") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ䮚"),headers,l1l111_l1_ (u"ࠧࠨ䮛"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ䮜"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡺࡸ࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮝"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠪࠫ䮞"),[l1l111_l1_ (u"ࠫࠬ䮟")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨ䮠"),[],[]
def l11ll1ll1111_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䮡") : l1l111_l1_ (u"ࠧࠨ䮢") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ䮣"),headers,l1l111_l1_ (u"ࠩࠪ䮤"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ䮥"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠤ࠯ࠦ࠭࡮ࡴࡵ࠰࠭ࡃ࠮ࠨࠧ䮦"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠬ࠭䮧"),[l1l111_l1_ (u"࠭ࠧ䮨")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨ䮩"),[],[]
def l1llll1ll1l_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠨࠩ䮪")
	if l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭䮫") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䮬"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䮭")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䮮"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䮯"),l1l111_l1_ (u"ࠧࠨ䮰"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧࠫ䮱"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䮲")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ䮳"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫࠧࠫ䮴"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠬ࠭䮵"),[l1l111_l1_ (u"࠭ࠧ䮶")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡰࡹ࠯ࠨ䮷") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䮸"),url,l1l111_l1_ (u"ࠩࠪ䮹"),l1l111_l1_ (u"ࠪࠫ䮺"),True,l1l111_l1_ (u"ࠫࠬ䮻"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨ䮼"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䮽") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䮾")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䮿"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠩ࠲ࡺ࠴࠭䯀") in l1lllll1_l1_ or l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䯁") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡬࠯ࠨ䯂"),l1l111_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ䯃"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䯄"),l1l111_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭䯅"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䯆"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䯇"),l1l111_l1_ (u"ࠪࠫ䯈"),l1l111_l1_ (u"ࠫࠬ䯉"),l1l111_l1_ (u"ࠬ࠭䯊"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠹ࡲࡥࠩ䯋"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤ࡯ࡥࡧ࡫࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䯌"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ䯍"),l1l111_l1_ (u"ࠩࠪ䯎"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䯏"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ䯐"),l1l111_l1_ (u"ࠬ࠭䯑"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠧ䯒"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䯓"),[l1l111_l1_ (u"ࠨࠩ䯔")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ䯕"),[],[]
	return l1l111_l1_ (u"ࠪࠫ䯖"),l1l1lll1_l1_,l1llll_l1_
def l1ll1ll11111_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯗"),url,l1l111_l1_ (u"ࠬ࠭䯘"),l1l111_l1_ (u"࠭ࠧ䯙"),l1l111_l1_ (u"ࠧࠨ䯚"),l1l111_l1_ (u"ࠨࠩ䯛"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ䯜"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠪࠫ䯝")
	if l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ䯞") in url or l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭䯟") in url:
		if l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ䯠") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯡"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䯢") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䯣"),[l1l111_l1_ (u"ࠪࠫ䯤")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯥"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䯦"),l1l111_l1_ (u"࠭ࠧ䯧"),l1l111_l1_ (u"ࠧࠨ䯨"),l1l111_l1_ (u"ࠨࠩ䯩"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩ䯪"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭䯫"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯬"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1lll1ll1ll1_l1_ in items:
				l1l1lll1_l1_.append(l1lll1ll1ll1_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧ䯭") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪ䯮"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䯯"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䯰"),l1l111_l1_ (u"ࠩࠪ䯱"),l1l111_l1_ (u"ࠪࠫ䯲"),l1l111_l1_ (u"ࠫࠬ䯳"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬ䯴"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯵"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠨ䯶"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨ䯷") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯸"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䯹"),[l1l111_l1_ (u"ࠫࠬ䯺")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧ䯻"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䯼"),l1l1lll1_l1_,l1llll_l1_
def l1111ll11_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ䯽")][0]
	headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䯾"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䯿"),url,l1l111_l1_ (u"ࠪࠫ䰀"),headers,l1l111_l1_ (u"ࠫࠬ䰁"),l1l111_l1_ (u"ࠬ࠭䰂"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡅ࠱࠷ࡴࡤࠨ䰃"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䰄"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰅"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䰆"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡪ࡮ࡲࡥ࠻ࠩࠫ࠲࠯ࡅࠩࠨࠤ䰇"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䰈")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠬ࠭䰉"),[l1l111_l1_ (u"࠭ࠧ䰊")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧ䰋") in html:
		l1l11111l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰌"),html,re.DOTALL)
		if l1l11111l11l_l1_:
			l1ll1ll_l1_ = l1l11111l11l_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䰍"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ䰎"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨ䰏"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䰐")+l1l11l11_l1_
				return l1l111_l1_ (u"࠭ࠧ䰑"),[l1l111_l1_ (u"ࠧࠨ䰒")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䰓"),[l1l111_l1_ (u"ࠩࠪ䰔")],[url]
def l111lll11l_l1_(url):
	l111lll111_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䰕") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴࠷࠯ࠨ䰖"),l1l111_l1_ (u"ࠬ࠵࠴࠰ࠩ䰗"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰘"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䰙"),l1l111_l1_ (u"ࠨࠩ䰚"),False,l1l111_l1_ (u"ࠩࠪ䰛"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬ䰜"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪ䰝"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰞"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䰟"))
					l111lll111_l1_.append(server+l1l111_l1_ (u"ࠧࠡࠢࠪ䰠")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠨࠩ䰡"),l111lll111_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩ࠲ࡨ࠴࠭䰢") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䰣"),url,l1l111_l1_ (u"ࠫࠬ䰤"),l1l111_l1_ (u"ࠬ࠭䰥"),l1l111_l1_ (u"࠭ࠧ䰦"),l1l111_l1_ (u"ࠧࠨ䰧"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠲࡯ࡦࠪ䰨"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰩"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䰪"),l1l111_l1_ (u"ࠫ࠴࠺࠯ࠨ䰫"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰬"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䰭"),l1l111_l1_ (u"ࠧࠨ䰮"),False,l1l111_l1_ (u"ࠨࠩ䰯"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧࠫ䰰"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰱"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䰲"),[l1l111_l1_ (u"ࠬ࠭䰳")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ䰴"),[],[]
def l111l1llll_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䰵"),url,l1l111_l1_ (u"ࠨࠩ䰶"),l1l111_l1_ (u"ࠩࠪ䰷"),l1l111_l1_ (u"ࠪࠫ䰸"),l1l111_l1_ (u"ࠫࠬ䰹"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠵ࡸࡺࠧ䰺"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"࠭ࠢࡢࡥࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰻"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠧࡰࡲࡀࠫ䰼")+op+l1l111_l1_ (u"ࠨࠨ࡬ࡨࡂ࠭䰽")+id+l1l111_l1_ (u"ࠩࠩࡪࡳࡧ࡭ࡦ࠿ࠪ䰾")+fname
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䰿"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䱀")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䱁"),url,data,headers,l1l111_l1_ (u"࠭ࠧ䱂"),l1l111_l1_ (u"ࠧࠨ䱃"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳࠲࡯ࡦࠪ䱄"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡪ࡬ࡥࡳࡧࡵࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱅"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䱆"),[l1l111_l1_ (u"ࠫࠬ䱇")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ䱈"),[],[]
def l11l11l111_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䱉"),1)[0].strip(l1l111_l1_ (u"ࠧࡀࠩ䱊")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䱋")).strip(l1l111_l1_ (u"ࠩࠩࠫ䱌"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠪࠫ䱍")
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱎"):l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬ䱏") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䱐"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䱑"),headers,True,l1l111_l1_ (u"ࠨࠩ䱒"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪ䱓"))
	if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䱔") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䱕")]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䱖") in l1llllll_l1_:
		if l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䱗") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䱘"),l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䱙"))
		l1l111111ll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ䱚"))[1]
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䱛"):headers[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱜")] , l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䱝"):l1l111_l1_ (u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ䱞")+l1l111111ll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱟"),l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ䱠"),headers,False,l1l111_l1_ (u"ࠩࠪ䱡"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䱢"))
		html = response.content
		if l1l111_l1_ (u"ࠫ࠴࡬࠯ࠨ䱣") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱤"),html,re.DOTALL)
		elif l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䱥") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱦"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠨࠩ䱧")],[ items[0] ]
		elif l1l111_l1_ (u"ࠩ࠿࡬࠶ࡄ࠴࠱࠶࠿࠳࡭࠷࠾ࠨ䱨") in html:
			return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣื๏ืแาࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎ࠥ๎ๅึัิ๋๋ࠥๆࠡษ็ษ๋ะั็ฬࠣห้ิวึหࠣฬ่࠭䱩"),[],[]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚ࠧ䱪"),[],[]
def l111lll1lll_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䱫"),l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䱬"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮࠮࡯ࡧࡷ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ䱭")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ䱮")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䱯"):l1l111_l1_ (u"ࠪࠫ䱰") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䱱"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䱲") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䱳"),headers,l1l111_l1_ (u"ࠧࠨ䱴"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧ䱵"))
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䱶"),[l1l111_l1_ (u"ࠪࠫ䱷")],[l1lllll1_l1_]
def l1lll11lll11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䱸"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䱹"):server,l1l111_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䱺"):l1l111_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䱻")}
	response = l11l1l_l1_(l1lll11l1l1l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䱼"),url,l1l111_l1_ (u"ࠩࠪ䱽"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䱾"),l1l111_l1_ (u"ࠫࠬ䱿"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䲀"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䲁"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠧࠨ䲂")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䲃"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䲄"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࠫ䲅"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䲆"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧ䲇"),[],[]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䲈"),[l1l111_l1_ (u"ࠧࠨ䲉")],[l1lllll1_l1_]
def l1ll11llll11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䲊"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䲋"):server,l1l111_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ䲌"):l1l111_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ䲍")}
	response = l11l1l_l1_(l1lll11l1l1l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲎"),url,l1l111_l1_ (u"࠭ࠧ䲏"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䲐"),l1l111_l1_ (u"ࠨࠩ䲑"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䲒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ䲓"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠫࠬ䲔")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䲕"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䲖"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࠨ䲗"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲘"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫ䲙"),[],[]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲚"),[l1l111_l1_ (u"ࠫࠬ䲛")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䲜"),l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䲝"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨ䲞"):l11l1l11_l1_,l1l111_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ䲟"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䲠"),url,data,l1l111_l1_ (u"ࠪࠫ䲡"),l1l111_l1_ (u"ࠫࠬ䲢"),l1l111_l1_ (u"ࠬ࠭䲣"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ䲤"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲥"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䲦"),[l1l111_l1_ (u"ࠩࠪ䲧")],[l1lllll1_l1_]
def l11111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䲨"),url,l1l111_l1_ (u"ࠫࠬ䲩"),l1l111_l1_ (u"ࠬ࠭䲪"),l1l111_l1_ (u"࠭ࠧ䲫"),l1l111_l1_ (u"ࠧࠨ䲬"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ䲭"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲮"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲯"),[l1l111_l1_ (u"ࠫࠬ䲰")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ䲱"),[],[]
def l11111l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲲"),url,l1l111_l1_ (u"ࠧࠨ䲳"),l1l111_l1_ (u"ࠨࠩ䲴"),l1l111_l1_ (u"ࠩࠪ䲵"),l1l111_l1_ (u"ࠪࠫ䲶"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡑ࠯࠴ࡷࡹ࠭䲷"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡉࡇࡔࡄࡑࡊࠦࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲸"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䲹"),[l1l111_l1_ (u"ࠧࠨ䲺")],[l1ll1ll_l1_]
def l1lllllll1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䲻"))
	if l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ䲼") in url:
		headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䲽"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䲾"),url,l1l111_l1_ (u"ࠬ࠭䲿"),headers,l1l111_l1_ (u"࠭ࠧ䳀"),l1l111_l1_ (u"ࠧࠨ䳁"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ䳂"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳃"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䳄") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭䳅"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䳆"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䳇"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䳈"),headers,l1l111_l1_ (u"ࠨࠩ䳉"),l1l111_l1_ (u"ࠩࠪ䳊"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ䳋"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䳌"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䳍"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䳎")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠧࠨ䳏"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䳐"),[l1l111_l1_ (u"ࠩࠪ䳑")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䳒")+l11l11111_l1_
	return l1l111_l1_ (u"ࠫࠬ䳓"),[l1l111_l1_ (u"ࠬ࠭䳔")],[l1lllll1_l1_]
def l11llllll1ll_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳕"))
	if l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䳖") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䳗"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䳘"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠪ࡭ࡩ࠭䳙"):l11l1l11_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䳚"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䳛"),url,data,l1l111_l1_ (u"࠭ࠧ䳜"),l1l111_l1_ (u"ࠧࠨ䳝"),l1l111_l1_ (u"ࠨࠩ䳞"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ䳟"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䳠"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䳡") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䳢"):l11l11111_l1_,l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳣"):l1l111_l1_ (u"ࠧࠨ䳤")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳥"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䳦"),headers,l1l111_l1_ (u"ࠪࠫ䳧"),l1l111_l1_ (u"ࠫࠬ䳨"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䳩"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䳪"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䳫"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䳬")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠩࠪ䳭"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䳮"),[l1l111_l1_ (u"ࠫࠬ䳯")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䳰")+l11l11111_l1_
		return l1l111_l1_ (u"࠭ࠧ䳱"),[l1l111_l1_ (u"ࠧࠨ䳲")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ䳳") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䳴"),l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䳵"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䳶"))
		url = host+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䳷")+l11l1l11_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䳸")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䳹"):l1l111_l1_ (u"ࠨࠩ䳺") , l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䳻"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䳼") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䳽"),headers,l1l111_l1_ (u"ࠬ࠭䳾"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠶ࡹࡴࠨ䳿"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ䴀"),l1l111_l1_ (u"ࠨࠩ䴁")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䴂"),l1l111_l1_ (u"ࠪࠫ䴃"))
		return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴄"),[l1l111_l1_ (u"ࠬ࠭䴅")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ䴆") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ䴇") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䴈"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䴉"),l1l111_l1_ (u"ࠪࠫ䴊"),l1l111_l1_ (u"ࠫࠬ䴋"),l1l111_l1_ (u"ࠬ࠭䴌"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨ䴍"))
			if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䴎") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䴏")]
			counts += 1
		return l1l111_l1_ (u"ࠩࠪ䴐"),[l1l111_l1_ (u"ࠪࠫ䴑")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ䴒"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䴓"))
	if l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ䴔") in url and l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䴕") not in url: url = server+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ䴖")+url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䴗"))[-1]+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ䴘")
	headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䴙"):server,l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䴚"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"࠭࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䴛") in url:
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䴜"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䴝")}
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䴞"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠪࠫ䴟"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠴ࡷࡹ࠭䴠"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䴡"),html,re.DOTALL|re.IGNORECASE)
		if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ䴢"),[l1l111_l1_ (u"ࠧࠨ䴣")],[l1ll1ll_l1_[0]]
	elif l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ䴤") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䴥"),headers,l1l111_l1_ (u"ࠪࠫ䴦"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭䴧"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴨"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ䴩"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䴪"))
			return l1l111_l1_ (u"ࠨࠩ䴫"),[l1l111_l1_ (u"ࠩࠪ䴬")],[l1ll1ll_l1_]
	else:
		l1l111l1l1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䴭"),url,l1l111_l1_ (u"ࠫࠬ䴮"),headers,l1l111_l1_ (u"ࠬ࠭䴯"),l1l111_l1_ (u"࠭ࠧ䴰"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ䴱"))
		html = l1l111l1l1ll_l1_.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ䴲"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠩࠩࡨࡂ࠷ࠧ䴳")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䴴"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䴵"),headers,l1l111_l1_ (u"ࠬ࠭䴶"),l1l111_l1_ (u"࠭ࠧ䴷"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ䴸"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴹"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠩࠪ䴺"),[l1l111_l1_ (u"ࠪࠫ䴻")],[l1ll1ll_l1_]
		if l1l111_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ䴼") in list(l1l111l1l1ll_l1_.headers.keys()):
			cookies = l1l111l1l1ll_l1_.headers[l1l111_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ䴽")]
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡟࡭ࡰ࡮ࡣ࠳࠰࠿࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ䴾"),cookies,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䴿"),[l1l111_l1_ (u"ࠨࠩ䵀")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡕࡈࡉࡉ࠭䵁"),[],[]
def l1ll11ll1l11_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠪࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠧ䵂") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䵃"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䵄")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䵅"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䵆"),headers,l1l111_l1_ (u"ࠨࠩ䵇"),l1l111_l1_ (u"ࠩࠪ䵈"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬ䵉"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䵊"),[l1l111_l1_ (u"ࠬ࠭䵋")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ䵌"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠧࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪ䵍"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵎"))
		url = server+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䵏")
		data = {l1l111_l1_ (u"ࠪ࡭ࡩ࠭䵐"):l11l1l11_l1_,l1l111_l1_ (u"ࠫ࡮࠭䵑"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䵒"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䵓"),l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䵔"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䵕"),url,data,headers,l1l111_l1_ (u"ࠩࠪ䵖"),l1l111_l1_ (u"ࠪࠫ䵗"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠵ࡲࡩ࠭䵘"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䵙"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䵚"),[l1l111_l1_ (u"ࠧࠨ䵛")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ䵜"),[],[]
def l1l111l11l11_l1_(l11ll1ll1ll1_l1_):
	l1l11111llll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡶࡸࡷ࠭䵝"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䵞"),l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࡢ࡚ࡊࡘࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠩ䵟"))
	headers = {l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䵠"):l1l11111llll_l1_} if l1l11111llll_l1_ else l1l111_l1_ (u"࠭ࠧ䵡")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䵢"),l11ll1ll1ll1_l1_,l1l111_l1_ (u"ࠨࠩ䵣"),headers,l1l111_l1_ (u"ࠩࠪ䵤"),l1l111_l1_ (u"ࠪࠫ䵥"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠲ࡵࡷࠫ䵦"))
	l11lllll111l_l1_ = response.content
	l1l111lll11l_l1_ = str(response.headers)
	l11ll1l1l1ll_l1_ = l1l111lll11l_l1_+l11lllll111l_l1_
	if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䵧") in l11ll1l1l1ll_l1_: found = True
	else:
		l11lll1l1l1l_l1_,token,l11ll1l1llll_l1_,l11llll111ll_l1_,found = l1l111_l1_ (u"࠭ࠧ䵨"),l1l111_l1_ (u"ࠧࠨ䵩"),l1l111_l1_ (u"ࠨࠩ䵪"),l1l111_l1_ (u"ࠩࠪ䵫"),False
		l11lll11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵬"),l11lllll111l_l1_,re.DOTALL)
		if l11lll11llll_l1_: l11ll1l1llll_l1_,l11llll111ll_l1_ = l11lll11llll_l1_[0]
		l11lll1l1111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䵭")][7]
		user = l1l1ll111ll_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵮"):user,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵯"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵰"):l11ll1ll1ll1_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵱"):l11llll111ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵲"):l1l111_l1_ (u"ࠪࠫ䵳"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵴"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭䵵")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵶"),l11lll1l1111_l1_,data,l1l111_l1_ (u"ࠧࠨ䵷"),l1l111_l1_ (u"ࠨࠩ䵸"),l1l111_l1_ (u"ࠩࠪ䵹"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠲࡯ࡦࠪ䵺"))
			html = response.content
		html = l1l111_l1_ (u"ࠫࠬ䵻")
		if html.startswith(l1l111_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ䵼")):
			l1l1l1l11ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䵽"),html.split(l1l111_l1_ (u"ࠧࡖࡔࡏࡗࡂ࠭䵾"),1)[1])
			for request in l1l1l1l11ll1_l1_:
				url = request[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵿")]
				method = request[l1l111_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࠩ䶀")]
				data = request[l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ䶁")]
				headers = request[l1l111_l1_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ䶂")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠬ࠭䶃"),l1l111_l1_ (u"࠭ࠧ䶄"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ䶅"))
				l11lllll111l_l1_ = response.content
				if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䶆") in l11lllll111l_l1_:
					found = True
					break
				l1l111lll11l_l1_ = str(response.headers)
				l11ll1l1l1ll_l1_ = l1l111lll11l_l1_+l11lllll111l_l1_
				l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ䶇"),l11ll1l1l1ll_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ䶈"),l11ll1l1l1ll_l1_,re.DOTALL)
				if token: token = token[0]
				if l11lll1l1l1l_l1_ or token: break
		if not found:
			if not l11lll1l1l1l_l1_:
				if not token and l11lll11llll_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠫࡎࡊ࠽ࠨ䶉")):
						data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䶊"):user,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䶋"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䶌"):l11ll1ll1ll1_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䶍"):l11llll111ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䶎"):l1l111_l1_ (u"ࠪࠫ䶏"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䶐"):l1l111_l1_ (u"ࠬ࡭ࡥࡵ࡫ࡧࠫ䶑")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䶒"),l11lll1l1111_l1_,data,l1l111_l1_ (u"ࠧࠨ䶓"),l1l111_l1_ (u"ࠨࠩ䶔"),l1l111_l1_ (u"ࠩࠪ䶕"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪ䶖"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬ䶗")
					if html.startswith(l1l111_l1_ (u"ࠬࡏࡄ࠾ࠩ䶘")):
						l11ll1ll11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬ䶙"),html,re.DOTALL)
						l1l11l11l11l_l1_,l1l111l111l_l1_ = l11ll1ll11ll_l1_[0]
						message = l1l111_l1_ (u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬ䶚")+l1l111l111l_l1_+l1l111_l1_ (u"ࠨࠢฮห๋๐ษࠨ䶛")
						l1l1111l1l_l1_ = l1l111ll1l_l1_()
						l1l1111l1l_l1_.create(l1l111_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨ䶜"),message)
						t1 = time.time()
						l11lllll1ll1_l1_,l11lll1111ll_l1_ = 0,0
						while l11lllll1ll1_l1_<int(l1l111l111l_l1_):
							l1l111111l_l1_(l1l1111l1l_l1_,int(l11lllll1ll1_l1_/int(l1l111l111l_l1_)*100),message,l1l111_l1_ (u"ࠪࠫ䶝"),l1l111l111l_l1_+l1l111_l1_ (u"ࠫࠥ࠵ࠠࠨ䶞")+str(int(l11lllll1ll1_l1_))+l1l111_l1_ (u"ࠬࠦࠠฬษ้๎ฮ࠭䶟"))
							if l11lllll1ll1_l1_>l11lll1111ll_l1_+10:
								data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䶠"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䶡"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䶢"):l11ll1ll1ll1_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䶣"):l11llll111ll_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䶤"):l1l11l11l11l_l1_,l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䶥"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡶࡲ࡯ࡪࡴࠧ䶦")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䶧"),l11lll1l1111_l1_,data,l1l111_l1_ (u"ࠧࠨ䶨"),l1l111_l1_ (u"ࠨࠩ䶩"),l1l111_l1_ (u"ࠩࠪ䶪"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ䶫"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ䶬")):
									token = html.split(l1l111_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ䶭"),1)[1]
									break
								l11lll1111ll_l1_ = l11lllll1ll1_l1_
							else: time.sleep(1)
							l11lllll1ll1_l1_ = time.time()-t1
						l1l1111l1l_l1_.close()
				if token:
					l11ll1ll1l1l_l1_ = response.cookies
					l1l1ll11l111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭䶮"),l11ll1l1l1ll_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ䶯") in list(l11ll1ll1l1l_l1_.keys()): l1l1ll11l111_l1_ = l11ll1ll1l1l_l1_[l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ䶰")]
					elif l1l1ll11l111_l1_: l1l1ll11l111_l1_ = l1l1ll11l111_l1_[0]
					l11lll11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶱"),l11lllll111l_l1_,re.DOTALL)
					if l11lll11llll_l1_: l11ll1l1llll_l1_,l11llll111ll_l1_ = l11lll11llll_l1_[0]
					if l1l1ll11l111_l1_ and l11lll11llll_l1_:
						headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䶲"):l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ䶳")+l1l1ll11l111_l1_,l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䶴"):l11ll1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䶵"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䶶")}
						data = l1l111_l1_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ䶷")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䶸"),l11ll1l1llll_l1_,data,headers,False,l1l111_l1_ (u"ࠪࠫ䶹"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ䶺"))
						l11lllll111l_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ䶻"),str(cookies),re.DOTALL)
			if l11lll1l1l1l_l1_:
				name,l11lll1l1l1l_l1_ = l11lll1l1l1l_l1_[0]
				l1l11111llll_l1_ = name+l1l111_l1_ (u"࠭࠽ࠨ䶼")+l11lll1l1l1l_l1_
				l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䶽"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࡟ࡗࡇࡕࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠭䶾"),l1l11111llll_l1_,l1ll111l11l_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䶿"),l1l111_l1_ (u"ࠪࠫ䷀"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䷁"),l1l111_l1_ (u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢไัฺࠦร็ษࠣษู๋ว็ࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮฮำ่๊ࠣฯอฦอ๊ࠢิฬࠦวๅใะู๊ࠥใ๋ࠢํืฯิฯๆ้สࠤ้ออใษࠣ࠲࠳่ࠦๅษࠣฮําฯࠡฯสะฮࠦไฦ฻สำฮࠦ็ัษࠣห้็อึࠢ็฽ิฯࠠฤึ๊ีࠥࡢ࡮࡝ࡰࠣ฽้๋วࠡล้ࠤ์ึวࠡษ็ๅา฻ࠠิ๊ไࠤ๏ะใาำࠣๅ๏ࠦอศๆฬࠤฯเ๊าࠢิฬ฼ࠦวๅฮ๊หืࠦศศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡวฺๅฬวࠠาษ๋ฮึࠦวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠโื็ࠤุ๊ใࠡษ็ีฬ๎สาࠢ࠱࠲ࠥษ่ࠡษึฮำีวๆ࡙ࠢࡔࡓࠦร้ࠢหีํ้ำ๋ࠩ䷂"))
				if l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䷃") not in l11lllll111l_l1_:
					headers = {l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ䷄"):l1l11111llll_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䷅"),l11ll1ll1ll1_l1_,l1l111_l1_ (u"ࠩࠪ䷆"),headers,l1l111_l1_ (u"ࠪࠫ䷇"),l1l111_l1_ (u"ࠫࠬ䷈"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬ䷉"))
					l11lllll111l_l1_ = response.content
	if not found and not l1l11111llll_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䷊"),l1l111_l1_ (u"ࠧࠨ䷋"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䷌"),l1l111_l1_ (u"ࠩ฼้้๐ษࠡใะูࠥษๆศࠢฦุ๊อๆࠡใื่ฯࠦ࠮࠯ࠢะหํ๊ࠠฦ฻สำฮࠦวๅ฻่่๏ฯࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤ๋็ำࠡษ็ๅ๏ี๊้ࠢฦ์ࠥ็๊ะ์๋ࠤ฿๐ั่่๊ࠢࠥ์แิࠢส่๊๎โฺࠩ䷍"))
	return l11lllll111l_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111lll111_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䷎"),url,l1l111_l1_ (u"ࠫࠬ䷏"),l1l111_l1_ (u"ࠬ࠭䷐"),l1l111_l1_ (u"࠭ࠧ䷑"),l1l111_l1_ (u"ࠧࠨ䷒"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ䷓"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠽࠱ࡤࡂࠬ䷔"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䷕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ䷖") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ䷗") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧ䷘"),l1l111_l1_ (u"ࠧࠨ䷙")).replace(l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䷚"),l1l111_l1_ (u"ࠩࠪ䷛")).strip(l1l111_l1_ (u"ࠪࠤࠬ䷜")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䷝"),l1l111_l1_ (u"ࠬࠦࠧ䷞"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111lll111_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭䷟"),l111lll111_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ䷠"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ䷡"),[],[]
	l11ll1ll1ll1_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l11lllll111l_l1_ = l1l111l11l11_l1_(l11ll1ll1ll1_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䷢"):
		l1l1111ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷣"),l11lllll111l_l1_,re.DOTALL)
		if l1l1111ll1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l1111ll1ll_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䷤"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷥"),l11lllll111l_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ䷦"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䷧"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䷨"),url,l1l111_l1_ (u"ࠩࠪ䷩"),l1l111_l1_ (u"ࠪࠫ䷪"),True,l1l111_l1_ (u"ࠫࠬ䷫"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫ䷬"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䷭") in list(cookies.keys()):
		l1l11111llll_l1_ = cookies[l1l111_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ䷮")]
		l1l11111llll_l1_ = l111l11_l1_(escapeUNICODE(l1l11111llll_l1_))
		items = re.findall(l1l111_l1_ (u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷯"),l1l11111llll_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䷰"),l1l111_l1_ (u"ࠪ࠳ࠬ䷱"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭䷲") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬࠫ࠲ࡇࠩ䷳"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩ䷴")+id
		return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䷵"),[l1l111_l1_ (u"ࠨࠩ䷶")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䷷")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䷸"),l1l11l11_l1_,l1l111_l1_ (u"ࠫࠬ䷹"),l1l111_l1_ (u"ࠬ࠭䷺"),True,l1l111_l1_ (u"࠭ࠧ䷻"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭䷼"))
		l11llll111l1_l1_ = response.url
		l1l11l111ll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䷽"))[2]
		l1l11l1l11ll_l1_ = l11llll111l1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䷾"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l11l111ll1_l1_,l1l11l1l11ll_l1_)
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䷿"):l1l111_l1_ (u"ࠫࠬ一") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ丁"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ丂") , l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ七"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭丄"), l1llllll_l1_, l1l111_l1_ (u"ࠩࠪ丅"), headers, False,l1l111_l1_ (u"ࠪࠫ丆"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪ万"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ丈"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ三"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ上"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ下"),l1l111_l1_ (u"ࠩ࠲ࠫ丌"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠪ࠳ࠬ不"))
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ与") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ丏") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ丐"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ丑"))
			if name==l1l111_l1_ (u"ࠨࠩ丒"): l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ专"),[l1l111_l1_ (u"ࠪࠫ且")],[l1ll1ll_l1_]
			else: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ丕"),[l1l111_l1_ (u"ࠬ࠭世")],[l1ll1ll_l1_]
		else: l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧ丗"),[],[]
		return l1l111ll1ll1_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll111ll1_l1_(url):
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ丘") : l1l111_l1_ (u"ࠨࠩ丙") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ业"),headers,l1l111_l1_ (u"ࠪࠫ丛"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ东"))
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丝"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"࠭ࠧ丞")
	if items:
		for l1ll1ll_l1_,l1lll1ll1ll1_l1_ in items:
			l1l1lll1_l1_.append(l1lll1ll1ll1_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭丟"),[],[]
	return l1l111_l1_ (u"ࠨࠩ丠"),l1l1lll1_l1_,l1llll_l1_
def l11lllllllll_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ両"),l1l111_l1_ (u"ࠪࠫ丢"))
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ丣"):l1l111_l1_ (u"ࠬ࠭两")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ严"),headers,l1l111_l1_ (u"ࠧࠨ並"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ丧"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ丨"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭丩")+url
		return l1l111_l1_ (u"ࠫࠬ个"),[l1l111_l1_ (u"ࠬ࠭丫")],[url]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨ丬"),[],[]
def l11llll1llll_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ中"))
	if l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ丮") in url: id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ丯"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ丰"))[-1]
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ丱") + id
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ串") : l1l111_l1_ (u"࠭ࠧ丳") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ临"),headers,l1l111_l1_ (u"ࠨࠩ丵"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡃࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ丶"))
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭丷"),l1l111_l1_ (u"ࠫࠬ丸"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ丹"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ为"),[l1l111_l1_ (u"ࠧࠨ主")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ丼"),[],[]
def l11lll1lll1l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ丽"),l1l111_l1_ (u"ࠪࠫ举"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ丿"),l1l111_l1_ (u"ࠬ࠭乀"),l1l111_l1_ (u"࠭ࠧ乁"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ乂"))
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ乃"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1lll1ll1ll1_l1_,res in items:
		l1l1lll1_l1_.append(l1lll1ll1ll1_l1_+l1l111_l1_ (u"ࠩࠣࠫ乄")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ久"),[],[]
	return l1l111_l1_ (u"ࠫࠬ乆"),l1l1lll1_l1_,l1llll_l1_
def l1l111111lll_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ乇"),l1l111_l1_ (u"࠭ࠧ么"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ义"),l1l111_l1_ (u"ࠨࠩ乊"),l1l111_l1_ (u"ࠩࠪ之"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ乌"))
	items = re.findall(l1l111_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ乍"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1lll1ll1ll1_l1_,res in items:
		url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ乎")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭乏")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ乐")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ乑"),l1l111_l1_ (u"ࠩࠪ乒"),l1l111_l1_ (u"ࠪࠫ乓"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ乔"))
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ乕"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1lll1ll1ll1_l1_+l1l111_l1_ (u"࠭ࠠࠨ乖")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭乗"),[],[]
	return l1l111_l1_ (u"ࠨࠩ乘"),l1l1lll1_l1_,l1llll_l1_
def l11lll11lll1_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ乙")
	if 1 or l1l111_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ乚") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ乛"),l1l111_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ乜"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ九"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ乞").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ也"):id,l1l111_l1_ (u"ࠩࡲࡴࠬ习"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭乡"),l1l111_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ乢"):l1l111_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ乣")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ乤"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠧࠨ乥"),l1l111_l1_ (u"ࠨࠩ书"),l1l111_l1_ (u"ࠩࠪ乧"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ乨"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭乩") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ乪")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ乫"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ乬"),url,l1l111_l1_ (u"ࠨࠩ乭"),l1l111_l1_ (u"ࠩࠪ乮"),l1l111_l1_ (u"ࠪࠫ乯"),l1l111_l1_ (u"ࠫࠬ买"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ乱"))
		if l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ乲") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ乳")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ乴"),[l1l111_l1_ (u"ࠩࠪ乵")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ乶"),[],[]
def l11lllll1lll_l1_(url):
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ乷") : l1l111_l1_ (u"ࠬ࠭乸") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ乹"),headers,l1l111_l1_ (u"ࠧࠨ乺"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ乻"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ乼"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ乽"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ乾"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠬ࠭乿"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ亀"),[],[]
def l11lll111ll_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ亁"))[-1]
	id = id.split(l1l111_l1_ (u"ࠨࠨࠪ亂"))[0]
	id = id.replace(l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ亃"),l1l111_l1_ (u"ࠪࠫ亄"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ亅")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ了")+id
	l11lll1l1l11_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ亇")+id
	l1l111l11ll1_l1_,l11lll1ll1l1_l1_,l1l11111lll1_l1_,l11lllll1111_l1_ = l1l111_l1_ (u"ࠧࠨ予"),l1l111_l1_ (u"ࠨࠩ争"),l1l111_l1_ (u"ࠩࠪ亊"),l1l111_l1_ (u"ࠪࠫ事")
	for l1l111lll1_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ二"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭亍"),l1l111_l1_ (u"࠭ࠧ于"),l1l111_l1_ (u"ࠧࠨ亏"),l1l111_l1_ (u"ࠨࠩ亐"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ云"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ互") in html: break
		time.sleep(2)
	l1l11lllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ亓"),html,re.DOTALL)
	if l1l11lllll_l1_: l1l11lllll_l1_ = l1l11lllll_l1_[0]
	else: l1l11lllll_l1_ = html
	l1l11lllll_l1_ = l1l11lllll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭五"),l1l111_l1_ (u"࠭ࠦࠨ井"))
	l1l111ll1lll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ亖"),l1l11lllll_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ亗")],[l1l111_l1_ (u"ࠩࠪ亘")]
	try:
		l1l11l1l111l_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ亙")][l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ亚")][l1l111_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ些")]
		for l1l111111l1l_l1_ in l1l11l1l111l_l1_:
			l1ll1ll_l1_ = l1l111111l1l_l1_[l1l111_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ亜")]
			try: title = l1l111111l1l_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ亝")][l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ亞")]
			except: title = l1l111111l1l_l1_[l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ亟")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ亠")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ亡")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ亢"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ亣"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠧࠧࠩ交")
			l11llllll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭亥"),l1ll1ll_l1_)
			if l11llllll1l1_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l11llllll1l1_l1_[0],l1l111_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ亦"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ产")
			l1l111l11ll1_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭亨"))
	formats,l1l111lll111_l1_,l11lll11l1l1_l1_,l11lll11l1ll_l1_,l11lll11l11l_l1_ = [],[],[],[],[]
	try: l11lll1ll1l1_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ亩")][l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ亪")]
	except: pass
	try: l1l11111lll1_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ享")][l1l111_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ京")]
	except: pass
	try: formats = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ亭")][l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ亮")]
	except: pass
	try: l1l111lll111_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ亯")][l1l111_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ亰")]
	except: pass
	l1l111l11l1l_l1_ = formats+l1l111lll111_l1_
	for dict in l1l111l11l1l_l1_:
		if l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ亱") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ亲")] = str(dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭亳")])
		if l1l111_l1_ (u"ࠩࡩࡴࡸ࠭亴") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ亵")] = str(dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ亶")])
		if l1l111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ亷") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ亸")] = dict[l1l111_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ亹")]
		if l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ人") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭亻")] = str(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ亼")])
		if l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ亽") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亾")] = str(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亿")])
		if l1l111_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭什") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭仁")] = str(dict[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ仂")])+l1l111_l1_ (u"ࠪࡼࠬ仃")+str(dict[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ仄")])
		if l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ仅") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ仆")] = dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ仇")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ仈")]+l1l111_l1_ (u"ࠩ࠰ࠫ仉")+dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭今")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ介")]
		if l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ仌") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ仍")] = dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ从")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ仏")]+l1l111_l1_ (u"ࠩ࠰ࠫ仐")+dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ仑")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ仒")]
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭仓") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ仔")] = dict[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ仕")]
		if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ他") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ仗")])>111222333: del dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ付")]
		if l1l111_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭仙") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ仚")].split(l1l111_l1_ (u"࠭ࠦࠨ仛"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ仜"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仝") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仞")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ仟")])
		l11lll11l1l1_l1_.append(dict)
	l1l1111l11l1_l1_ = l1l111_l1_ (u"ࠫࠬ仠")
	if l1l111_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ仡") in l1l11lllll_l1_:
		l1l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ仢"),html,re.DOTALL)
		if l1l111l1lll1_l1_:
			l1l111l1lll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ代")][0]+l1l111l1lll1_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ令"),l1l111l1lll1_l1_,l1l111_l1_ (u"ࠩࠪ以"),l1l111_l1_ (u"ࠪࠫ仦"),l1l111_l1_ (u"ࠫࠬ仧"),l1l111_l1_ (u"ࠬ࠭仨"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ仩"))
			l1l1111l11l1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11ll1lll111_l1_ = cipher._load_javascript(l1l1111l11l1_l1_)
			l11lll1l1lll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ仪"),str(l11ll1lll111_l1_))
			l11ll1lll1l1_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11lll1l1lll_l1_)
	for dict in l11lll11l1l1_l1_:
		url = dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仫")]
		if l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭们") in url or url.count(l1l111_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ仭"))>1:
			l11lll11l1ll_l1_.append(dict)
		elif l1l1111l11l1_l1_ and l1l111_l1_ (u"ࠫࡸ࠭仮") in list(dict.keys()) and l1l111_l1_ (u"ࠬࡹࡰࠨ仯") in list(dict.keys()):
			l1l1111111ll_l1_ = l11ll1lll1l1_l1_.execute(dict[l1l111_l1_ (u"࠭ࡳࠨ仰")])
			if l1l1111111ll_l1_!=dict[l1l111_l1_ (u"ࠧࡴࠩ仱")]:
				dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仲")] = url+l1l111_l1_ (u"ࠩࠩࠫ仳")+dict[l1l111_l1_ (u"ࠪࡷࡵ࠭仴")]+l1l111_l1_ (u"ࠫࡂ࠭仵")+l1l1111111ll_l1_
				l11lll11l1ll_l1_.append(dict)
	for dict in l11lll11l1ll_l1_:
		l111lll_l1_,l11lll111111_l1_,l1l11l11lll1_l1_,l1l1l1ll1_l1_,codecs,l11ll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭件"),l1l111_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ价"),l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ仸"),l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ仹"),l1l111_l1_ (u"ࠩࠪ仺"),l1l111_l1_ (u"ࠪ࠴ࠬ任")
		try:
			l11lll11ll11_l1_ = dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ仼")]
			l11lll11ll11_l1_ = l11lll11ll11_l1_.replace(l1l111_l1_ (u"ࠬ࠱ࠧ份"),l1l111_l1_ (u"࠭ࠧ仾"))
			items = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ仿"),l11lll11ll11_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l111l1ll11_l1_ = codecs.split(l1l111_l1_ (u"ࠨ࠮ࠪ伀"))
			l11lll111111_l1_ = l1l111_l1_ (u"ࠩࠪ企")
			for item in l1l111l1ll11_l1_: l11lll111111_l1_ += item.split(l1l111_l1_ (u"ࠪ࠲ࠬ伂"))[0]+l1l111_l1_ (u"ࠫ࠱࠭伃")
			l11lll111111_l1_ = l11lll111111_l1_.strip(l1l111_l1_ (u"ࠬ࠲ࠧ伄"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ伅") in list(dict.keys()): l11ll11l1ll_l1_ = str(float(dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伆")]*10)//1024/10)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ伇")
			else: l11ll11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ伈")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨ伉"): continue
			elif l1l111_l1_ (u"ࠫ࠱࠭伊") in l11lll11ll11_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ伋")
				l1l11l11lll1_l1_ = l111lll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ伌")+l11ll11l1ll_l1_+dict[l1l111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ伍")].split(l1l111_l1_ (u"ࠨࡺࠪ伎"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ伏"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ伐")
				l1l11l11lll1_l1_ = l11ll11l1ll_l1_+dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ休")].split(l1l111_l1_ (u"ࠬࡾࠧ伒"))[1]+l1l111_l1_ (u"࠭ࠠࠡࠩ伓")+dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ伔")]+l1l111_l1_ (u"ࠨࡨࡳࡷࠬ伕")+l1l111_l1_ (u"ࠩࠣࠤࠬ伖")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ众"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ优")
				l1l11l11lll1_l1_ = l11ll11l1ll_l1_+str(int(dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ伙")])/1000)+l1l111_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ会")+dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ伛")]+l1l111_l1_ (u"ࠨࡥ࡫ࠫ伜")+l1l111_l1_ (u"ࠩࠣࠤࠬ伝")+l111lll_l1_
		except:
			l1111ll1l11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111ll1l11_l1_)
		if l1l111_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ伞") in dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ伟")]: l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ传")].split(l1l111_l1_ (u"࠭ࡤࡶࡴࡀࠫ伡"),1)[1].split(l1l111_l1_ (u"ࠧࠧࠩ伢"),1)[0]))
		elif l1l111_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ伣") in list(dict.keys()): l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ伤")])/1000)
		else: l1l1lll111_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ伥")
		if l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伦") not in list(dict.keys()): l11ll11l1ll_l1_ = dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ伧")].split(l1l111_l1_ (u"࠭ࡸࠨ伨"))[1]
		else: l11ll11l1ll_l1_ = dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伩")]
		if l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭伪") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ伫")] = l1l111_l1_ (u"ࠪ࠴࠲࠶ࠧ伬")
		dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ伭")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ伮")+l1l11l11lll1_l1_+l1l111_l1_ (u"࠭ࠠࠡࠪࠪ伯")+l11lll111111_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ估")+dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭伱")]+l1l111_l1_ (u"ࠩࠬࠫ伲")
		dict[l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ伳")] = l1l11l11lll1_l1_.split(l1l111_l1_ (u"ࠫࠥࠦࠧ伴"))[0].split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ伵"))[0]
		dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伶")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伷")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ伸")] = codecs
		dict[l1l111_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ伹")] = l1l1lll111_l1_
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伺")] = l11ll11l1ll_l1_
		l11lll11l11l_l1_.append(dict)
	l1l111l111l1_l1_,l11llllll111_l1_,l1l11l111l11_l1_,l1l11l11l1l1_l1_,l11ll1l1ll11_l1_ = [],[],[],[],[]
	l1l111l1ll1l_l1_,l11lll1l11ll_l1_,l11lll1l1ll1_l1_,l1l111l1l1l1_l1_,l1l111llll1l_l1_ = [],[],[],[],[]
	if l11lll1ll1l1_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ伻")] = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ似")
		dict[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ伽")] = l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ伾")
		dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ伿")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ佀")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ佁")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佂")]+l1l111_l1_ (u"ࠬࠦࠠࠨ佃")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ佄")
		dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ佅")] = l11lll1ll1l1_l1_
		dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ但")] = l1l111_l1_ (u"ࠩ࠳ࠫ佇")
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ佈")] = l1l111_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ佉")
		l11lll11l11l_l1_.append(dict)
	if l1l11111lll1_l1_:
		l1l111ll11l1_l1_,l11llll1l1ll_l1_ = l1l11l11ll_l1_(l1l11111lll1_l1_)
		l1l11111l1l1_l1_ = list(zip(l1l111ll11l1_l1_,l11llll1l1ll_l1_))
		for title,l1ll1ll_l1_ in l1l11111l1l1_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ佊")] = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ佋")
			dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ佌")] = l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭位")
			dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭低")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ住") in title: dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ佐")] = title.split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ佑"))[0].rsplit(l1l111_l1_ (u"࠭ࠠࠡࠩ佒"))[-1]
			else: dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ体")] = l1l111_l1_ (u"ࠨ࠳࠳ࠫ佔")
			if title.count(l1l111_l1_ (u"ࠩࠣࠤࠬ何"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠪࠤࠥ࠭佖"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ佗")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭佘")] = l1l111_l1_ (u"࠭࠰࠱࠲࠳ࠫ余")
			if title==l1l111_l1_ (u"ࠧ࠮࠳ࠪ佚"): dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ佛")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ作")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ佝")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佞")]+l1l111_l1_ (u"ࠬࠦࠠࠨ佟")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ你")
			else: dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佡")] = dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ佢")]+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭佣")+dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ佤")]+l1l111_l1_ (u"ࠫࠥࠦࠧ佥")+dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佦")]+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭佧")+dict[l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ佨")]
			l11lll11l11l_l1_.append(dict)
	l11lll11l11l_l1_ = sorted(l11lll11l11l_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佩")]))
	if not l11lll11l11l_l1_:
		l1lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ佪"),html,re.DOTALL)
		l1lll1l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ佫"),html,re.DOTALL)
		l1l1111lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ佬"),html,re.DOTALL)
		l1l1111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ佭"),html,re.DOTALL)
		try: l11ll1l1l111_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佮")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ佯")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ佰")][l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佱")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佲")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佳")]
		except: l11ll1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭佴")
		try: l1l111l11111_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ併")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ佶")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ佷")][l1l111_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ佸")][0][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佹")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佺")]
		except: l1l111l11111_l1_ = l1l111_l1_ (u"ࠬ࠭佻")
		try: l1l111l1111l_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佼")][l1l111_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ佽")]
		except: l1l111l1111l_l1_ = l1l111_l1_ (u"ࠨࠩ佾")
		if l1lll1l1l1l_l1_ or l1lll1l1ll1_l1_ or l1l1111lll1l_l1_ or l1l1111llll1_l1_ or l11ll1l1l111_l1_ or l1l111l11111_l1_ or l1l111l1111l_l1_:
			if   l1lll1l1l1l_l1_: message = l1lll1l1l1l_l1_[0]
			elif l1lll1l1ll1_l1_: message = l1lll1l1ll1_l1_[0]
			elif l1l1111lll1l_l1_: message = l1l1111lll1l_l1_[0]
			elif l1l1111llll1_l1_: message = l1l1111llll1_l1_[0]
			elif l11ll1l1l111_l1_: message = l11ll1l1l111_l1_
			elif l1l111l11111_l1_: message = l1l111l11111_l1_
			elif l1l111l1111l_l1_: message = l1l111l1111l_l1_
			l1l11l11ll11_l1_ = message.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ使"),l1l111_l1_ (u"ࠪࠫ侀")).strip(l1l111_l1_ (u"ࠫࠥ࠭侁"))
			l1l11l11l1ll_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭侂")
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ侃"),l1l111_l1_ (u"ࠧࠨ侄"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ侅"),l1l11l11l1ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ來")+l1l11l11ll11_l1_)
			return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ侇")+l1l11l11ll11_l1_,[],[]
		else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ侈"),[],[]
	l11lll11111l_l1_,l11lll1111l1_l1_,l11lllllll11_l1_ = [],[],[]
	for dict in l11lll11l11l_l1_:
		if dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ侉")]==l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ侊"):
			l1l111l111l1_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭例")])
			l1l111l1ll1l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ侌")]==l1l111_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ侍"):
			l11llllll111_l1_.append(dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ侎")])
			l11lll1l11ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭侏")]==l1l111_l1_ (u"ࠬࡳࡰࡥࠩ侐"):
			title = dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侑")].replace(l1l111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ侒"),l1l111_l1_ (u"ࠨࠩ侓"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ侔") not in list(dict.keys()): l11ll11l1ll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ侕")
			else: l11ll11l1ll_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ侖")]
			l11lll11111l_l1_.append([dict,{},title,l11ll11l1ll_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ侗")].replace(l1l111_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭侘"),l1l111_l1_ (u"ࠧࠨ侙"))
			if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侚") not in list(dict.keys()): l11ll11l1ll_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ供")
			else: l11ll11l1ll_l1_ = dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ侜")]
			l11lll11111l_l1_.append([dict,{},title,l11ll11l1ll_l1_])
			l1l11l111l11_l1_.append(title)
			l11lll1l1ll1_l1_.append(dict)
		l1l1111l11ll_l1_ = True
		if l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ依") in list(dict.keys()):
			if l1l111_l1_ (u"ࠬࡧࡶ࠱ࠩ侞") in dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭侟")]: l1l1111l11ll_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠧࡢࡸࡦࠫ侠") not in dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ価")] and l1l111_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ侢") not in dict[l1l111_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ侣")]: l1l1111l11ll_l1_ = False
		if dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ侤")]==l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ侥") and dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ侦")]!=l1l111_l1_ (u"ࠧ࠱࠯࠳ࠫ侧") and l1l1111l11ll_l1_==True:
			l11ll1l1ll11_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ侨")])
			l1l111llll1l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ侩")]==l1l111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ侪") and dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ侫")]!=l1l111_l1_ (u"ࠬ࠶࠭࠱ࠩ侬") and l1l1111l11ll_l1_==True:
			l1l11l11l1l1_l1_.append(dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侭")])
			l1l111l1l1l1_l1_.append(dict)
	for l1l1111l1111_l1_ in l1l111l1l1l1_l1_:
		l1l11l1l1111_l1_ = l1l1111l1111_l1_[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ侮")]
		for l1l1111lll11_l1_ in l1l111llll1l_l1_:
			l1l11l1l1l1l_l1_ = l1l1111lll11_l1_[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侯")]
			l11ll11l1ll_l1_ = l1l11l1l1l1l_l1_+l1l11l1l1111_l1_
			title = l1l1111lll11_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ侰")].replace(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ侱"),l1l111_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ侲"))
			title = title.replace(l1l1111lll11_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侳")]+l1l111_l1_ (u"࠭ࠠࠡࠩ侴"),l1l111_l1_ (u"ࠧࠨ侵"))
			title = title.replace(str((float(l1l11l1l1l1l_l1_*10)//1024/10))+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭侶"),str((float(l11ll11l1ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ侷"))
			title = title+l1l111_l1_ (u"ࠪࠬࠬ侸")+l1l1111l1111_l1_[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ侹")].split(l1l111_l1_ (u"ࠬ࠮ࠧ侺"),1)[1]
			l11lll11111l_l1_.append([l1l1111lll11_l1_,l1l1111l1111_l1_,title,l11ll11l1ll_l1_])
	l11lll11111l_l1_ = sorted(l11lll11111l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l1111lll11_l1_,l1l1111l1111_l1_,title,l11ll11l1ll_l1_ in l11lll11111l_l1_:
		l11lll111l1l_l1_ = l1l1111lll11_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ侻")]
		if l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ侼") in list(l1l1111l1111_l1_.keys()):
			l11lll111l1l_l1_ = l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ侽")
		if l11lll111l1l_l1_ not in l11lllllll11_l1_:
			l11lllllll11_l1_.append(l11lll111l1l_l1_)
			l11lll1111l1_l1_.append([l1l1111lll11_l1_,l1l1111l1111_l1_,title,l11ll11l1ll_l1_])
	l11ll1ll1lll_l1_,l1l111ll11ll_l1_,shift = [],[],0
	l1l1111l1ll1_l1_,l1l111llll11_l1_ = l1l111_l1_ (u"ࠩࠪ侾"),l1l111_l1_ (u"ࠪࠫ便")
	try: l1l1111l1ll1_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ俀")][l1l111_l1_ (u"ࠬࡧࡵࡵࡪࡲࡶࠬ俁")]
	except: l1l1111l1ll1_l1_ = l1l111_l1_ (u"࠭ࠧ係")
	try: l11lllll11ll_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭促")][l1l111_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ俄")]
	except: l11lllll11ll_l1_ = l1l111_l1_ (u"ࠩࠪ俅")
	if l1l1111l1ll1_l1_ and l11lllll11ll_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ俆")+l1l1111l1ll1_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭俇")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭俈")][0]+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ俉")+l11lllll11ll_l1_
		l11ll1ll1lll_l1_.append(title)
		l1l111ll11ll_l1_.append(l1ll1ll_l1_)
		try: l1l111llll11_l1_ = l1l111ll1lll_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭俊")][l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ俋")][l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭俌")][-1][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俍")]
		except: pass
	for l1l1111lll11_l1_,l1l1111l1111_l1_,title,l11ll11l1ll_l1_ in l11lll1111l1_l1_:
		l11ll1ll1lll_l1_.append(title) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ俎"))
	if l1l11l111l11_l1_: l11ll1ll1lll_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧ俏")) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ俐"))
	if l11lll11111l_l1_: l11ll1ll1lll_l1_.append(l1l111_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫ俑")) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ俒"))
	if l11ll1l1ll11_l1_: l11ll1ll1lll_l1_.append(l1l111_l1_ (u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ俓")) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俔"))
	if l1l111l111l1_l1_: l11ll1ll1lll_l1_.append(l1l111_l1_ (u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫ俕")) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ俖"))
	if l11llllll111_l1_: l11ll1ll1lll_l1_.append(l1l111_l1_ (u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭俗")) ; l1l111ll11ll_l1_.append(l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭俘"))
	l1l11l11l111_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l11lll1l1l11_l1_, l11ll1ll1lll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭俙"),[],[]
		elif l11l11l_l1_==0 and l1l1111l1ll1_l1_:
			l1ll1ll_l1_ = l1l111ll11ll_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩ俚")+QUOTE(l1l1111l1ll1_l1_)+l1l111_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ俛")+l1ll1ll_l1_
			if l1l111llll11_l1_: new_path = new_path+l1l111_l1_ (u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬ俜")+QUOTE(l1l111llll11_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ保")+new_path+l1l111_l1_ (u"ࠨࠩࠣ俞"))
			return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ俟"),[],[]
		choice = l1l111ll11ll_l1_[l11l11l_l1_]
		l1l111l111ll_l1_ = l11ll1ll1lll_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠨࡦࡤࡷ࡭࠭俠"):
			l11lllll1111_l1_ = l11lll1ll1l1_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ信"),l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ俢"),l1l111_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ俣")]:
			if choice==l1l111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ俤"): l1l1lll1_l1_,l1l1111l111l_l1_ = l1l11l111l11_l1_,l11lll1l1ll1_l1_
			elif choice==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ俥"): l1l1lll1_l1_,l1l1111l111l_l1_ = l1l111l111l1_l1_,l1l111l1ll1l_l1_
			elif choice==l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭俦"): l1l1lll1_l1_,l1l1111l111l_l1_ = l11llllll111_l1_,l11lll1l11ll_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ俧"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l11lllll1111_l1_ = l1l1111l111l_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俨")]
				l1l111l111ll_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俩"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ俪"), l11ll1l1ll11_l1_)
			if l11l11l_l1_!=-1:
				l1l111l111ll_l1_ = l11ll1l1ll11_l1_[l11l11l_l1_]
				l11ll1lll11l_l1_ = l1l111llll1l_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ俫"), l1l11l11l1l1_l1_)
				if l11l11l_l1_!=-1:
					l1l111l111ll_l1_ += l1l111_l1_ (u"࠭ࠠࠬࠢࠪ俬")+l1l11l11l1l1_l1_[l11l11l_l1_]
					l1l111111l11_l1_ = l1l111l1l1l1_l1_[l11l11l_l1_]
					l1l11l11l111_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ俭"):
			l11llll1111l_l1_,l11ll1l1ll1l_l1_,l11lll11ll1l_l1_,l1l11l111l1l_l1_ = list(zip(*l11lll11111l_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ修"), l11lll11ll1l_l1_)
			if l11l11l_l1_!=-1:
				l1l111l111ll_l1_ = l11lll11ll1l_l1_[l11l11l_l1_]
				l11ll1lll11l_l1_ = l11llll1111l_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠩࡰࡴࡩ࠭俯") in l11lll11ll1l_l1_[l11l11l_l1_] and l11ll1lll11l_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俰")]!=l11lll1ll1l1_l1_:
					l1l111111l11_l1_ = l11ll1l1ll1l_l1_[l11l11l_l1_]
					l1l11l11l111_l1_ = True
				else: l11lllll1111_l1_ = l11ll1lll11l_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俱")]
				break
		elif choice==l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭俲"):
			l11llll1111l_l1_,l11ll1l1ll1l_l1_,l11lll11ll1l_l1_,l1l11l111l1l_l1_ = list(zip(*l11lll1111l1_l1_))
			l11ll1lll11l_l1_ = l11llll1111l_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"࠭࡭ࡱࡦࠪ俳") in l11lll11ll1l_l1_[l11l11l_l1_-shift] and l11ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ俴")]!=l11lll1ll1l1_l1_:
				l1l111111l11_l1_ = l11ll1l1ll1l_l1_[l11l11l_l1_-shift]
				l1l11l11l111_l1_ = True
			else: l11lllll1111_l1_ = l11ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俵")]
			l1l111l111ll_l1_ = l11lll11ll1l_l1_[l11l11l_l1_-shift]
			break
	if not l1l11l11l111_l1_: l11llll1ll1l_l1_ = l11lllll1111_l1_
	else: l11llll1ll1l_l1_ = l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ俶")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俷")]+l1l111_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ俸")+l1l111111l11_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俹")]
	if l1l11l11l111_l1_:
		l1l111lll1ll_l1_ = int(l11ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ俺")])
		l11lllll11l1_l1_ = int(l1l111111l11_l1_[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ俻")])
		l1l1lll111_l1_ = str(max(l1l111lll1ll_l1_,l11lllll11l1_l1_))
		l11lll1l11l1_l1_ = l11ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俼")].replace(l1l111_l1_ (u"ࠩࠩࠫ俽"),l1l111_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ俾"))
		l11llllll11l_l1_ = l1l111111l11_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俿")].replace(l1l111_l1_ (u"ࠬࠬࠧ倀"),l1l111_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ倁"))
		l1l11l11111l_l1_ = l1l111_l1_ (u"ࠧ࠽ࡁࡻࡱࡱࠦࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣ࠳࠱࠴ࠧࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠾ࠤࡘࡘࡋ࠳࠸ࠣࡁࡁࡠࡳ࠭倂")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡐࡔࡉࠦࡸ࡮࡮ࡱࡷ࠿ࡾࡳࡪ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠳࠲࠳࠵࠴࡞ࡍࡍࡕࡦ࡬ࡪࡳࡡ࠮࡫ࡱࡷࡹࡧ࡮ࡤࡧࠥࠤࡽࡳ࡬࡯ࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠨࠠࡹ࡯࡯ࡲࡸࡀࡸ࡭࡫ࡱ࡯ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠵࠾࠿࠹࠰ࡺ࡯࡭ࡳࡱࠢࠡࡺࡶ࡭࠿ࡹࡣࡩࡧࡰࡥࡑࡵࡣࡢࡶ࡬ࡳࡳࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡸࡦࡴࡤࡢࡴࡧࡷ࠳࡯ࡳࡰ࠰ࡲࡶ࡬࠵ࡩࡵࡶࡩ࠳ࡕࡻࡢ࡭࡫ࡦࡰࡾࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࡔࡶࡤࡲࡩࡧࡲࡥࡵ࠲ࡑࡕࡋࡇ࠮ࡆࡄࡗࡍࡥࡳࡤࡪࡨࡱࡦࡥࡦࡪ࡮ࡨࡷ࠴ࡊࡁࡔࡊ࠰ࡑࡕࡊ࠮ࡹࡵࡧࠦࠥࡳࡩ࡯ࡄࡸࡪ࡫࡫ࡲࡕ࡫ࡰࡩࡂࠨࡐࡕ࠳࠱࠹ࡘࠨࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩ倃")+l1l1lll111_l1_+l1l111_l1_ (u"ࠩࡖࠦࠥࡺࡹࡱࡧࡀࠦࡸࡺࡡࡵ࡫ࡦࠦࠥࡶࡲࡰࡨ࡬ࡰࡪࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡲࡵࡳ࡫࡯࡬ࡦ࠼࡬ࡷࡴ࡬ࡦ࠮࡯ࡤ࡭ࡳࡀ࠲࠱࠳࠴ࠦࡃࡢ࡮ࠨ倄")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠪࡀࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ倅")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠳ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡸ࡬ࡨࡪࡵ࠯ࠨ倆")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ倇")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ倈")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ倉")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ倊")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ個")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ倌")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ倍")]+l1l111_l1_ (u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨ倎")+str(l11ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ倏")])+l1l111_l1_ (u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪ倐")+str(l11ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ們")])+l1l111_l1_ (u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭倒")+str(l11ll1lll11l_l1_[l1l111_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ倓")])+l1l111_l1_ (u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫ倔")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ倕")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ倖")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ倗")+l11lll1l11l1_l1_+l1l111_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ倘")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ候")+l11ll1lll11l_l1_[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ倚")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ倛")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ倜")+l11ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ倝")]+l1l111_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ倞")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ借")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ倠")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ倡")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠴ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨ倢")+l1l111111l11_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ倣")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ値")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ倥")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ倦")+l1l111111l11_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ倧")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ倨")+l1l111111l11_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ倩")]+l1l111_l1_ (u"ࠬࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦ࠶࠹࠰࠵࠹࠸ࠦࡃࡢ࡮ࠨ倪")
		l1l11l11111l_l1_ += l1l111_l1_ (u"࠭࠼ࡂࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾࠷࠹࠰࠱࠵࠽࠷࠿ࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠬ倫")+l1l111111l11_l1_[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ倬")]+l1l111_l1_ (u"ࠨࠤ࠲ࡂࡡࡴࠧ倭")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ倮")+l11llllll11l_l1_+l1l111_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ倯")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ倰")+l1l111111l11_l1_[l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ倱")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ倲")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ倳")+l1l111111l11_l1_[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭倴")]+l1l111_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ倵")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭倶")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ倷")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ倸")
		l1l11l11111l_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ倹")
		l1l11l11111l_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ债")
		if PY3:
			import http.server as l11llll1l111_l1_
			import http.client as l1l11111111l_l1_
		else:
			import BaseHTTPServer as l11llll1l111_l1_
			import httplib as l1l11111111l_l1_
		class l1l1111ll1l1_l1_(l11llll1l111_l1_.HTTPServer):
			def __init__(self,l1ll1ll1l1ll_l1_=l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ倻"),port=55055,l1l11l11111l_l1_=l1l111_l1_ (u"ࠩ࠿ࡂࠬ值")):
				self.l1ll1ll1l1ll_l1_ = l1ll1ll1l1ll_l1_
				self.port = port
				self.l1l11l11111l_l1_ = l1l11l11111l_l1_
				l11llll1l111_l1_.HTTPServer.__init__(self,(self.l1ll1ll1l1ll_l1_,self.port),l1l111llllll_l1_)
				self.l1l11111ll1l_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ倽")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠫ࠿࠭倾")+str(port)+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ倿")
			def start(self):
				self.threads = l11l11l1111_l1_(False)
				self.threads.start_new_thread(1,self.l11llll1l11l_l1_)
			def l11llll1l11l_l1_(self):
				self.l11ll1lll1ll_l1_ = True
				while self.l11ll1lll1ll_l1_:
					self.handle_request()
			def stop(self):
				self.l11ll1lll1ll_l1_ = False
				self.l1l1111ll11l_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l11l11111l_l1_):
				self.l1l11l11111l_l1_ = l1l11l11111l_l1_
			def l1l1111ll11l_l1_(self):
				conn = l1l11111111l_l1_.HTTPConnection(self.l1ll1ll1l1ll_l1_+l1l111_l1_ (u"࠭࠺ࠨ偀")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠢࡉࡇࡄࡈࠧ偁"), l1l111_l1_ (u"ࠣ࠱ࠥ偂"))
		class l1l111llllll_l1_(l11llll1l111_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ偃"),l1l111_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ偄"))
				self.end_headers()
				self.wfile.write(self.server.l1l11l11111l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ偅")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ偆"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ假"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l1111ll1l1_l1_(l1l111_l1_ (u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪ偈"),55055,l1l11l11111l_l1_)
		l11lllll1111_l1_ = httpd.l1l11111ll1l_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠨࠩ偉")
	if not l11lllll1111_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ偊"),[],[]
	return l1l111_l1_ (u"ࠪࠫ偋"),[l1l111_l1_ (u"ࠫࠬ偌")],[[l11lllll1111_l1_,l1l111l11ll1_l1_,httpd]]
def l1l11111l1ll_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ偍") : l1l111_l1_ (u"࠭ࠧ偎") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ偏"),headers,l1l111_l1_ (u"ࠨࠩ偐"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡄࡒࡆ࠲࠷ࡳࡵࠩ偑"))
	items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤࡿ࠭ࡡࢃࠧ偒"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l111ll11l1_l1_,l1l1lll1_l1_,l11llll1l1ll_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1ll1ll_l1_,dummy,l1lll1ll1ll1_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ偓"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ偔"))
			if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ偕") in l1ll1ll_l1_:
				l1l111ll11l1_l1_,l11llll1l1ll_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11llll1l1ll_l1_
				if l1l111ll11l1_l1_[0]==l1l111_l1_ (u"ࠧ࠮࠳ࠪ偖"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨีํีๆืࠠฯษุࠫ偗")+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ偘"))
				else:
					for title in l1l111ll11l1_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭偙")+l1l111_l1_ (u"ࠫࠥࠦࠠࠨ做")+title)
			else:
				title = l1l111_l1_ (u"ู๊ࠬาใิࠤำอีࠨ偛")+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩ停")+l1lll1ll1ll1_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
				l1l1lll1_l1_.append(title)
		return l1l111_l1_ (u"ࠧࠨ偝"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ偞"),[],[]
def l11lll1lll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭偟"),url,l1l111_l1_ (u"ࠪࠫ偠"),l1l111_l1_ (u"ࠫࠬ偡"),l1l111_l1_ (u"ࠬ࠭偢"),l1l111_l1_ (u"࠭ࠧ偣"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜࡛ࡏࡄࡆࡑࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ偤"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ健"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		return l1l111_l1_ (u"ࠩࠪ偦"),[l1l111_l1_ (u"ࠪࠫ偧")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࠬ偨"),[],[]
def l11lll11l111_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ偩"),l1l111_l1_ (u"࠭ࠧ偪")).replace(l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭偫"),l1l111_l1_ (u"ࠨࠩ偬"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭偭"),url,l1l111_l1_ (u"ࠪࠫ偮"),l1l111_l1_ (u"ࠫࠬ偯"),l1l111_l1_ (u"ࠬ࠭偰"),l1l111_l1_ (u"࠭ࠧ偱"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭偲"))
	html = response.content
	l1llllllll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ偳"),html,re.DOTALL)
	if l1llllllll1l_l1_:
		l1llllllll1l_l1_ = l1llllllll1l_l1_[0]
		l1ll1l1l111l_l1_ = l1ll1lll111l_l1_(l1llllllll1l_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ側"),l1ll1l1l111l_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪࠬࢁࠬ偵"),l1ll1l1l111l_l1_,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_,title in l1ll_l1_:
			if not title: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠫ࠳࠭偶"),1)[1]
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		return l1l111_l1_ (u"ࠬ࠭偷"),l1l1lll1_l1_,l1llll_l1_
	id = url.split(l1l111_l1_ (u"࠭࠯ࠨ偸"))[3]
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ偹"):l1l111_l1_ (u"ࠨࠩ偺") , l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ偻"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ偼") }
	payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ偽"):id , l1l111_l1_ (u"ࠬࡵࡰࠨ偾"):l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ偿") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ傀"),url,payload,headers,l1l111_l1_ (u"ࠨࠩ傁"),l1l111_l1_ (u"ࠩࠪ傂"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ傃"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ傄"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠬ࠭傅"),[l1l111_l1_ (u"࠭ࠧ傆")],[ items[0] ]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡛ࠢࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇࠨ傇"),[],[]
def l1l1111lllll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ傈"),l1l111_l1_ (u"ࠩࠪ傉"),l1l111_l1_ (u"ࠪࠫ傊"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡑࡕࡁࡅࡕ࠰࠵ࡸࡺࠧ傋"))
	items = re.findall(l1l111_l1_ (u"ࠬࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ傌"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ傍"),[l1l111_l1_ (u"ࠧࠨ傎")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡍࡑࡄࡈࡘ࠭傏"),[],[]
def l1l11111ll11_l1_(url):
	return l1l111_l1_ (u"ࠩࠪ傐"),[l1l111_l1_ (u"ࠪࠫ傑")],[ url ]
def l1l111ll1111_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠫ࠴࠭傒"))
	basename = l1l111_l1_ (u"ࠬ࠵ࠧ傓").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ傔"),l1l111_l1_ (u"ࠧࠨ傕"),l1l111_l1_ (u"ࠨࠩ傖"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭傗"))
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ傘"),html,re.DOTALL)
	if items:
		l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l1l1l1l1ll11_l1_,l1l11l1111l1_l1_,l1l11l1111ll_l1_,l1l11l111111_l1_ = items[0]
		var = int(l1l1l1l1l1ll_l1_) % int(l1l1l1l1ll11_l1_) + int(l1l11l1111l1_l1_) % int(l1l11l1111ll_l1_)
		url = basename + l1l1l1l111ll_l1_ + str(var) + l1l11l111111_l1_
		return l1l111_l1_ (u"ࠫࠬ備"),[l1l111_l1_ (u"ࠬ࠭傚")],[url]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ傛"),[],[]
def l1l11111l111_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ傜"),l1l111_l1_ (u"ࠨࠩ傝"))
	url = url.replace(l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ傞"),l1l111_l1_ (u"ࠪࠫ傟"))
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭傠"))[-1]
	headers = { l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ傡") : l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ傢") }
	payload = { l1l111_l1_ (u"ࠢࡪࡦࠥ傣"):id , l1l111_l1_ (u"ࠣࡱࡳࠦ傤"):l1l111_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ傥") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ傦"), url, payload, headers, l1l111_l1_ (u"ࠫࠬ傧"),l1l111_l1_ (u"ࠬ࠭储"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ傩"))
	if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ傪") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ傫")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࠪ催"),[l1l111_l1_ (u"ࠪࠫ傭")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ傮"),[],[]
def l11ll1l1l11l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭傯"),l1l111_l1_ (u"࠭ࠧ傰"),l1l111_l1_ (u"ࠧࠨ傱"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ傲"))
	items = re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ傳"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ傴"),[l1l111_l1_ (u"ࠫࠬ債")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ傶"),[],[]
def l11ll1lllll1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ傷"),l1l111_l1_ (u"ࠧࠨ傸"),l1l111_l1_ (u"ࠨࠩ傹"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ傺"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ傻"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ傼") + items[0]
		return l1l111_l1_ (u"ࠬ࠭傽"),[l1l111_l1_ (u"࠭ࠧ傾")],[ url ]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ傿"),[],[]
def l1l11l1l1l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ僀"),l1l111_l1_ (u"ࠩࠪ僁"),l1l111_l1_ (u"ࠪࠫ僂"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡗࡅࡐࡎࡉࡖࡊࡆࡈࡓࡍࡕࡓࡕ࠯࠴ࡷࡹ࠭僃"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ僄"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ僅"),[l1l111_l1_ (u"ࠧࠨ僆")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘࠬ僇"),[],[]
def l11lll111lll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ僈"),l1l111_l1_ (u"ࠪࠫ僉"),l1l111_l1_ (u"ࠫࠬ僊"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭僋"))
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭僌"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ働"),[l1l111_l1_ (u"ࠨࠩ僎")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ像"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ⋊")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡈ࠴ࡠࠩ⋋")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯ࠭⋌"),l1l111_l1_ (u"ࠬอสึๆࠣฬ๋อࠧ⋍"),l1l111_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็หฺ๊๊ࠨ⋎"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่ัี๊ะࠩ⋏"),l1l111_l1_ (u"ࠨษํะ๏ࠦศิฬࠣห้ฮฯ๋ๆࠪ⋐"),l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ⋑"),l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศิฬࠪ⋒")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==800: l1lll_l1_ = l1l1l11_l1_()
	elif mode==801: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==802: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==803: l1lll_l1_ = PLAY(url)
	elif mode==804: l1lll_l1_ = l111l1lll1_l1_(url)
	elif mode==806: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==809: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋓"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⋔"),l1l111_l1_ (u"࠭ࠧ⋕"),809,l1l111_l1_ (u"ࠧࠨ⋖"),l1l111_l1_ (u"ࠨࠩ⋗"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⋘"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋙"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠩ⋚"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ⋛"),804,l1l111_l1_ (u"࠭ࠧ⋜"),l1l111_l1_ (u"ࠧࠨ⋝"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⋞"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⋟"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⋠"),l1l111_l1_ (u"ࠫࠬ⋡"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⋢"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ⋣"),l1l111_l1_ (u"ࠧࠨ⋤"),l1l111_l1_ (u"ࠨࠩ⋥"),l1l111_l1_ (u"ࠩࠪ⋦"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⋧"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡳࡧࡶ࠮ࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⋨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⋩"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⋪"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ⋫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋬"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⋭")+l1lllll_l1_+title,l1ll1ll_l1_,801)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⋮"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⋯"),l1l111_l1_ (u"ࠬ࠭⋰"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ⋱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⋲"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⋳"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⋴") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋵"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⋶")+l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠬ࠭⋷"),l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡱࡪࡴࡵࠨ⋸"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⋹"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⋺"),l1l111_l1_ (u"ࠩࠪ⋻"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⋼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⋽"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⋾"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ⋿") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌀"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⌁")+l1lllll_l1_+title,l1ll1ll_l1_,801)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠩࠪ⌂")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⌃"),url,l1l111_l1_ (u"ࠫࠬ⌄"),l1l111_l1_ (u"ࠬ࠭⌅"),l1l111_l1_ (u"࠭ࠧ⌆"),l1l111_l1_ (u"ࠧࠨ⌇"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡗࡊࡇࡓࡐࡐࡖࡣࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⌈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴࡔࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡶࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠪ⌉"),html,re.DOTALL)
	if l11llll_l1_:
		l111lll1l1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠪࠫ⌊"),l1l111_l1_ (u"ࠫࠬ⌋"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠬำไใษอࠫ⌌") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"࠭ๅ้ษึ้ࠬ⌍") in name: l111lll1l1_l1_ = block
		if l111lll1l1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⌎"),l111lll1l1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌏"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ⌐"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⌑"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⌒"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⌓"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⌔"),l1lllll_l1_+title,l1ll1ll_l1_,803)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⌕")):
	limit,start,l1l1l1ll1_l1_,select,l111l1ll1l_l1_ = 0,0,l1l111_l1_ (u"ࠨࠩ⌖"),l1l111_l1_ (u"ࠩࠪ⌗"),l1l111_l1_ (u"ࠪࠫ⌘")
	if l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ⌙") in type:
		l111ll1111_l1_,l1l11llll_l1_ = url.split(l1l111_l1_ (u"ࠬࡅ࡮ࡦࡺࡷࡁࡵࡧࡧࡦࠨࠪ⌚"))
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⌛"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⌜")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭⌝"),l111ll1111_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ⌞"),l1l111_l1_ (u"ࠪࠫ⌟"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⌠"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠬࡹࡥࡤࡅࡲࡲࡹ࡫࡮ࡵࠩ⌡")+html+l1l111_l1_ (u"࠭࠼ࡧࡱࡲࡸࡪࡸ࠾ࠨ⌢")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⌣"),url,l1l111_l1_ (u"ࠨࠩ⌤"),l1l111_l1_ (u"ࠩࠪ⌥"),l1l111_l1_ (u"ࠪࠫ⌦"),l1l111_l1_ (u"ࠫࠬ⌧"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⌨"))
		html = response.content
		l11l1ll1_l1_ = html
	items,l111lll1ll_l1_,filters = [],False,False
	if not type and l1l111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷࠬ〈") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ〉"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⌫"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ⌬"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌭"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠫࠬ⌮"),l1l111_l1_ (u"ࠬࡹࡵࡣ࡯ࡨࡲࡺ࠭⌯"))
				l111lll1ll_l1_ = True
	if not l111lll1ll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡦࡥࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲࡈࡵ࡮ࡵࡧࡱࡸࠬ⌰"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⌱"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠨ࡞ࡱࠫ⌲"))
				title = unescapeHTML(title)
				if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⌳") in l1ll1ll_l1_ and type==l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪ⌴"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌵"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⌶"))
				elif l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⌷") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌸"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ⌹") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌺"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪ⌻"))
				elif l1l111_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡵࠪ⌼") in url: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⌽"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠫ⌾"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⌿"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮ࡲࡥࡩࡓ࡯ࡳࡧࡓࡥࡷࡧ࡭ࡴࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾ࠫ⍀"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			params = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ⍁"),block)
			l111l1ll1l_l1_ = params[l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸࡶࡴ࡯ࠫ⍂")]
			l111l1l1ll_l1_ = int(params[l1l111_l1_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡶࡡࡨࡧࠪ⍃")])+1
			l111l1ll11_l1_ = int(params[l1l111_l1_ (u"ࠬࡳࡡࡹࡡࡳࡥ࡬࡫ࠧ⍄")])
			query = params[l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡷࠬ⍅")].replace(l1l111_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭⍆"),l1l111_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ⍇")).replace(l1l111_l1_ (u"ࠩࡗࡶࡺ࡫ࠧ⍈"),l1l111_l1_ (u"ࠪࡸࡷࡻࡥࠨ⍉")).replace(l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࠩ⍊"),l1l111_l1_ (u"ࠬࡴࡵ࡭࡮ࠪ⍋"))
			if l111l1l1ll_l1_<l111l1ll11_l1_:
				l1l11llll_l1_ = l1l111_l1_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡃ࡬ࡰࡣࡧࡱࡴࡸࡥࠧࡳࡸࡩࡷࡿ࠽ࠨ⍌")+QUOTE(query,l1l111_l1_ (u"ࠧࠨ⍍"))+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ⍎")+str(l111l1l1ll_l1_)
				l1lllll1_l1_ = l111l1ll1l_l1_+l1l111_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ⍏")+l1l11llll_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍐"),l1lllll_l1_+l1l111_l1_ (u"ࠫั๊ศࠡษ็้ื๐ฯࠨ⍑"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠬ࠭⍒"),l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡢࠫ⍓")+type)
		elif l1l111_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ⍔") in url:
			l1l11llll_l1_,l1lll1l1l_l1_ = l1l11llll_l1_.rsplit(l1l111_l1_ (u"ࠨ࠿ࠪ⍕"),1)
			l1lll1l1l_l1_ = int(l1lll1l1l_l1_)+1
			l1lllll1_l1_ = l111ll1111_l1_+l1l111_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ⍖")+l1l11llll_l1_+l1l111_l1_ (u"ࠪࡁࠬ⍗")+str(l1lll1l1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⍘"),l1lllll_l1_+l1l111_l1_ (u"ࠬาไษࠢสุ่๊๊ะࠩ⍙"),l1lllll1_l1_,801,l1l111_l1_ (u"࠭ࠧ⍚"),l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࡣࠬ⍛")+type)
	return
def l111l1lll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⍜"),url,l1l111_l1_ (u"ࠩࠪ⍝"),l1l111_l1_ (u"ࠪࠫ⍞"),l1l111_l1_ (u"ࠫࠬ⍟"),l1l111_l1_ (u"ࠬ࠭⍠"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡈࡌࡐ࡙ࡋࡒࡔ࠯࠴ࡷࡹ࠭⍡"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡷࡥࡣࡳࡧࡶࠩ࠰࠭ࡃ࠮ࡹࡥࡤࡅࡲࡲࡹ࡫࡮ࡵࠢࠪ⍢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡹࡷࡸࡥ࡯ࡶࡢࡳࡵࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⍣"),block,re.DOTALL)
		for name,block in l1lll1l1_l1_:
			if l1l111_l1_ (u"ࠩส่ฯ฻ๆ๋ใࠪ⍤") in name: continue
			name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ⍥"))
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⍦"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ⍧")+value
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⍨"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠧࠨ⍩"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⍪"))
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⍫"),url,l1l111_l1_ (u"ࠪࠫ⍬"),l1l111_l1_ (u"ࠫࠬ⍭"),l1l111_l1_ (u"ࠬ࠭⍮"),l1l111_l1_ (u"࠭ࠧ⍯"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⍰"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⍱"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l111ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡅ࡮ࡤࡨࡨ࠳࠰࠿ࡱࡱࡶࡸࡂ࠮࠮ࠫࡁࠬࠦࠬ⍲"),html,re.DOTALL)
	if l111ll11l1_l1_:
		l1ll_l1_ = base64.b64decode(l111ll11l1_l1_[0])
		if PY3: l1ll_l1_ = l1ll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⍳"))
		l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⍴"),l1ll_l1_)
		l1ll_l1_ = list(l1ll_l1_.values())
		for l1ll1ll_l1_ in l1ll_l1_:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⍵"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⍶")+server+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⍷"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹࡊ࡯ࡸࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ⍸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡷࡄ࠮ࠫࡁ࠿ࡸࡩࡄ࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬࠫࡠࡩࢁ࠳࠭࠶ࢀ࠭ࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⍹"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ⍺") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴ࡅࡵࡳ࡮ࡀࠫ⍻"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⍼"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⍽")+server+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ⍾")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⍿"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ⎀"),l1l111_l1_ (u"ࠪ࠯ࠬ⎁"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⎂")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⎃"))
	return
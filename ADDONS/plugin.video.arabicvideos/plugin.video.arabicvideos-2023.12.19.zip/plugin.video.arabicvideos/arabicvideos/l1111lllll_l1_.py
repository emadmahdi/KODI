# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ⑾")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡈࡐࡢࠫ⑿")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫ⒀"),l1l111_l1_ (u"ࠧศๆๆ่ࠬ⒁"),l1l111_l1_ (u"ࠨࡰ࠲ࡅࠬ⒂"),l1l111_l1_ (u"ࠩสุ่๊๊ะࠩ⒃"),l1l111_l1_ (u"ࠪๆฺฯฺࠠึๅࠫ⒄")]
def l11l1ll_l1_(mode,url,text):
	if   mode==430: l1lll_l1_ = l1l1l11_l1_()
	elif mode==431: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==432: l1lll_l1_ = PLAY(url)
	elif mode==433: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==434: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⒅")+text)
	elif mode==435: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⒆")+text)
	elif mode==436: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==437: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==439: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⒇"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧ⒈"),l1l111_l1_ (u"ࠨࠩ⒉"),l1l111_l1_ (u"ࠩࠪ⒊"),l1l111_l1_ (u"ࠪࠫ⒋"),l1l111_l1_ (u"ࠫࠬ⒌"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⒍"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡱࡳࡳ࡯ࡣࡢ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⒎"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠧ࠰ࠩ⒏"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ⒐"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒑"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⒒"),l1l111_l1_ (u"ࠫࠬ⒓"),439,l1l111_l1_ (u"ࠬ࠭⒔"),l1l111_l1_ (u"࠭ࠧ⒕"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⒖"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒗"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ⒘"),l1l11ll_l1_,435)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒙"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ⒚"),l1l11ll_l1_,434)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒛"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⒜"),l1l111_l1_ (u"ࠧࠨ⒝"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒞"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⒟")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ⒠"),l1l11ll_l1_,431)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⒡"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⒢")+l1lllll_l1_+l1l111_l1_ (u"࠭วโๆส้ࠥอ่็ࠢ็ห๏์ࠧ⒣"),l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹ࠱ࠨ⒤"),436)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒥"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⒦")+l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤฬ๎ๆࠡๆส๎๋࠭⒧"),l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲ࡧ࡬࡭࠳ࠪ⒨"),436)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒩"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⒪")+l1lllll_l1_+l1l111_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧ⒫"),l1l11ll_l1_,437)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⒬"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⒭"),l1l111_l1_ (u"ࠪࠫ⒮"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡩࡵࡧࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬ࠧ࠭⒯"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⒰"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ⒱"): continue
		if l1l111_l1_ (u"ࠧศ๊้ࠤ้อ๊็ࠩ⒲") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒳"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⒴")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫ⒵")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨⒶ"),l1l11l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬⒷ"),l1l111_l1_ (u"࠭ࠧⒸ"),l1l111_l1_ (u"ࠧࠨⒹ"),l1l111_l1_ (u"ࠨࠩⒺ"),l1l111_l1_ (u"ࠩࠪⒻ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬⒼ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡ࡯ࡱࡱ࡭ࡨࡧ࡬ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⒽ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠬ࠵ࠧⒾ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪⒿ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡎ࡬ࡷࡹࡊࡲࡰࡲࡨࡨࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫࡭ࡳ࡭ࡍࡢࡵࡷࡩࡷࠨࠧⓀ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⓁ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11lll_l1_: continue
		l1ll1ll_l1_ = l1l11l11_l1_+l1l111_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭Ⓜ")+category+l1l111_l1_ (u"ࠪࡁࠬⓃ")+value
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓄ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⓅ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l11ll1_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪⓆ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⓇ"),url,l1l111_l1_ (u"ࠨࠩⓈ"),l1l111_l1_ (u"ࠩࠪⓉ"),l1l111_l1_ (u"ࠪࠫⓊ"),l1l111_l1_ (u"ࠫࠬⓋ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪⓌ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓧ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧⓎ"),url,431)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨⓏ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨⓐ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		if title in l11lll_l1_: continue
		l1lllll1_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡑࡴࡼࡩࡦࡵ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࡄࡱࡥࡺ࠿ࠪⓑ")+l111l1l1l_l1_
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓒ"),l1lllll_l1_+title,l1lllll1_l1_,431)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭ⓓ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪⓔ"))
	items = []
	if l1l111_l1_ (u"ࠧ࠰ࡖࡨࡶࡲࡹ࠮ࡱࡪࡳࠫⓕ") in url or l1l111_l1_ (u"ࠨ࠱ࡊࡩࡹ࠴ࡰࡩࡲࠪⓖ") in url or l1l111_l1_ (u"ࠩ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࠬⓗ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ⓘ"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬⓙ"),l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫⓚ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ⓛ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬⓜ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩⓝ"),l1l111_l1_ (u"ࠩࠪⓞ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧⓟ"))
		html = response.content
		block = html
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ⓠ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩⓡ"),url,l1l111_l1_ (u"࠭ࠧⓢ"),l1l111_l1_ (u"ࠧࠨⓣ"),l1l111_l1_ (u"ࠨࠩⓤ"),l1l111_l1_ (u"ࠩࠪⓥ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧⓦ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡓࡡࡪࡰࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡏࡤࡸࡨ࡮ࡥࡴࡖࡤࡦࡱ࡫ࠢࠨⓧ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨⓨ"),block,re.DOTALL)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪⓩ"),url,l1l111_l1_ (u"ࠧࠨ⓪"),l1l111_l1_ (u"ࠨࠩ⓫"),l1l111_l1_ (u"ࠩࠪ⓬"),l1l111_l1_ (u"ࠪࠫ⓭"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⓮"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡓࡥ࡬࡯࡮ࡢࡶࡨࠦࠬ⓯"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭⓰"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡬ࡱࡦ࡭ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⓱"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ⓲"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ⓳"),l1l111_l1_ (u"ࠪห฿์๊สࠩ⓴"),l1l111_l1_ (u"่๊๊ࠫษࠩ⓵"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ⓶"),l1l111_l1_ (u"࠭็ะษไࠫ⓷"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ⓸"),l1l111_l1_ (u"ࠨ฻ิฺࠬ⓹"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ⓺"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ⓻")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠫ࠴࠭⓼"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ⓽"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⓾"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ⓿") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ─") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ━"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ│") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┃"),l1lllll_l1_+title,l1ll1ll_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┄"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	if request!=l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ┅"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ┆"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ┇"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ┈") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				if title!=l1l111_l1_ (u"ࠪࠫ┉"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┊"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ┋")+title,l1ll1ll_l1_,431)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ┌"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┍"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ┎"),l1ll1ll_l1_,431)
	return
def l1ll1l11_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭┏"))
	l11ll1l_l1_,l11ll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࡷ࠳ࡶࡨࡱࠩ┐") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ┑"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭┒"),l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ┓"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ└")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭┕"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ┖"),l1l111_l1_ (u"ࠪࠫ┗"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ┘"))
		html = response.content
		l11ll11_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ┙"),url,l1l111_l1_ (u"࠭ࠧ┚"),l1l111_l1_ (u"ࠧࠨ┛"),l1l111_l1_ (u"ࠨࠩ├"),l1l111_l1_ (u"ࠩࠪ┝"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ┞"))
		html = response.content
		l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ┟"),html,re.DOTALL)
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ┠"),html,re.DOTALL)
	if l11ll1l_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡩ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┡"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ┢"),block,re.DOTALL)
		for l1ll11l_l1_,l111l11l1_l1_,title in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡇࡳ࡭ࡸࡵࡤࡦࡵ࠱ࡴ࡭ࡶ࠿ࠨ┣")+l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯࠿ࠪ┤")+l111l11l1_l1_+l1l111_l1_ (u"ࠪࠪࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭┥")+l1ll11l_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┦"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭┧"))
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪ┨"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠧࠡࠩ┩")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ┪"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ┫")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ┬"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ┭"),l1l111_l1_ (u"ࠬ࠭┮"),l1l111_l1_ (u"࠭ࠧ┯"),l1l111_l1_ (u"ࠧࠨ┰"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ┱"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭┲"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠭ࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ┳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭┴"),block,re.DOTALL)
		if l11111l11_l1_:
			l11111l11_l1_ = l11111l11_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ┵"),block,re.DOTALL)
			for server,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂࡷࡪࡸࡶࡦࡴࡀࠫ┶")+server+l1l111_l1_ (u"ࠧࠧࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ┷")+l11111l11_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ┸")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ┹")
				l1llll_l1_.append(l1ll1ll_l1_)
	l1111lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠭ࡪࡨࡵࡥࡲ࡫ࠢ࠿࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ┺"),html,re.DOTALL)
	if l1111lll1l_l1_:
		l1111lll1l_l1_ = l1111lll1l_l1_[0].replace(l1l111_l1_ (u"ࠫࡡࡴࠧ┻"),l1l111_l1_ (u"ࠬ࠭┼"))
		title = l1l111l_l1_(l1111lll1l_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ┽"))
		l1ll1ll_l1_ = l1111lll1l_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ┾")+title+l1l111_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ┿")
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ╀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ╁"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ╂"),l1l111_l1_ (u"ࠬ࠭╃"))
			if l111l1ll_l1_!=l1l111_l1_ (u"࠭ࠧ╄"): l111l1ll_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬ╅")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ╆")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭╇")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ╈"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ╉"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭╊"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ╋"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ╌"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭╍")+search
	l1lll11_l1_(url)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╎"))[0]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ╏"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ═"),l1l11ll_l1_,l1l111_l1_ (u"ࠬ࠭║"),l1l111_l1_ (u"࠭ࠧ╒"),l1l111_l1_ (u"ࠧࠨ╓"),l1l111_l1_ (u"ࠨࠩ╔"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ╕"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨ╖"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠮࠭╗"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫࡠࡩ࠱ࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭╘"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ╙"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ╚"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ╛"),l1l111_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭╜"))
	return url
def l1111llll1_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭╝"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ╞")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
l1l11111_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ╟"),l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ╠"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭╡"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ╢")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ╣"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ╤"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ╥"),l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ╦"),l1l111_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ╧"),l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ╨")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࠪ╩") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╪"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ╫"),1)
	if filter==l1l111_l1_ (u"ࠫࠬ╬"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭╭"),l1l111_l1_ (u"࠭ࠧ╮")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ╯"))
	if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ╰"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫ╱") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬ╲") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭╳")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ╴")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ╵")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪ╶")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ╷"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭╸")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ╹"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ╺"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ╻")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ╼"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ╽"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩ╾"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ╿"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫ▀"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ▁")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▂"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ▃"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▄"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ▅")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ▆"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ▇"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ█"),l1l111_l1_ (u"ࠬ࠭▉"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩ▊"),l1l111_l1_ (u"ࠧࠨ▋"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪ▌") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ▍"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ▎")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▏"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭▐"),l1lllll1_l1_,431)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭░"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ▒"),l1lllll1_l1_,435,l1l111_l1_ (u"ࠨࠩ▓"),l1l111_l1_ (u"ࠩࠪ▔"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭▕"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭▖")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ▗")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ▘")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ▙")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ▚")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▛"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ▜")+name,l1lllll1_l1_,434,l1l111_l1_ (u"ࠫࠬ▝"),l1l111_l1_ (u"ࠬ࠭▞"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭▟"): option = l1l111_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧ■")
			elif value==l1l111_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨ□"): option = l1l111_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫ▢")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ▣")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭▤")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ▥")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ▦")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ▧")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ▨")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠩ࠳ࠫ▩")]
			title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭▪")+name
			if type==l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ▫"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▬"),l1lllll_l1_+title,url,434,l1l111_l1_ (u"࠭ࠧ▭"),l1l111_l1_ (u"ࠧࠨ▮"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ▯") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠩࡀࠫ▰") in l11lll1l_l1_:
				l1llllll_l1_ = l1111llll1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▱"),l1lllll_l1_+title,l1llllll_l1_,431)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▲"),l1lllll_l1_+title,url,435,l1l111_l1_ (u"ࠬ࠭△"),l1l111_l1_ (u"࠭ࠧ▴"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠧ࠾ࠨࠪ▵"),l1l111_l1_ (u"ࠨ࠿࠳ࠪࠬ▶"))
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫ▷"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ▸") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭▹"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ►"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ▻")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ▼")
		if l1l111_l1_ (u"ࠨࠧࠪ▽") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ▾") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ▿"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ◀")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ◁") and value!=l1l111_l1_ (u"࠭࠰ࠨ◂"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ◃")+key+l1l111_l1_ (u"ࠨ࠿ࠪ◄")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ◅"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ◆")+key+l1l111_l1_ (u"ࠫࡂ࠭◇")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ◈"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ◉"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠲ࠪ◊"),l1l111_l1_ (u"ࠨ࠿ࠪ○"))
	return l1l1l111_l1_
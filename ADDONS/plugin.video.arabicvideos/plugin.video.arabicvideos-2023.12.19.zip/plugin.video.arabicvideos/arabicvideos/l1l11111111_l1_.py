# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㲀")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ㲁")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ㲂"),l1l111_l1_ (u"ࠧศีอๅุอัหๅ่ࠤํࠦวๅู็ฬฬะࠧ㲃")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㲄"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ㲅"),l1l111_l1_ (u"ࠪࠫ㲆"),l1l111_l1_ (u"ࠫࠬ㲇"),l1l111_l1_ (u"ࠬ࠭㲈"),l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㲉"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㲊"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲋"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ㲌"),l1l111_l1_ (u"ࠪࠫ㲍"),459,l1l111_l1_ (u"ࠫࠬ㲎"),l1l111_l1_ (u"ࠬ࠭㲏"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㲐"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲑"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㲒")+l1lllll_l1_+l1l111_l1_ (u"่ࠩฯอะวหࠢ็์ิ๐ࠠ็ฬࠪ㲓"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠪࠫ㲔"),l1l111_l1_ (u"ࠫࠬ㲕"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㲖"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲗"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㲘")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ㲙"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠩࠪ㲚"),l1l111_l1_ (u"ࠪࠫ㲛"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㲜"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㲝"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㲞"),l1l111_l1_ (u"ࠧࠨ㲟"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡐࡥ࡮ࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࠥࡗ࡮ࡺࡥࡔ࡮࡬ࡨࡪࡸࠢࠨ㲠"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㲡"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ㲢"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲣"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㲤")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"࠭ࠧ㲥")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㲦"),url,l1l111_l1_ (u"ࠨࠩ㲧"),l1l111_l1_ (u"ࠩࠪ㲨"),l1l111_l1_ (u"ࠪࠫ㲩"),l1l111_l1_ (u"ࠫࠬ㲪"),l1l111_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㲫"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㲬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡼࡧࡶࡦࡵࠥࠫ㲭"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㲮"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡖࡪࡩࡥ࡯ࡶࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ㲯"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ㲰") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㲱"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࠤࡄࡧࡹࡵࡲࡏࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㲲"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"࠭࠰ࠨ㲳"),l1l111_l1_ (u"ࠧ࠲ࠩ㲴"),l1l111_l1_ (u"ࠨ࠴ࠪ㲵")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭㲶"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ㲷"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭㲸"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ㲹"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ㲺"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭㲻"),l1l111_l1_ (u"ࠨล฽๊๏ฯࠧ㲼"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ㲽"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ㲾"),l1l111_l1_ (u"ࠫ์ีวโࠩ㲿"),l1l111_l1_ (u"๋ࠬศศำสอࠬ㳀"),l1l111_l1_ (u"ู࠭าุࠪ㳁"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ㳂"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ㳃")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠨ㳄") in html and l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠨ㳅") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㳆"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧ㳇"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ㳈"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㳉"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ㳊") not in title:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㳋"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨ㳌") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㳍") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳎"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳏"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠧࠨ㳐"),l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㳑")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㳒"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㳓"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㳔"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ㳕")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㳖"),url,l1l111_l1_ (u"ࠧࠨ㳗"),l1l111_l1_ (u"ࠨࠩ㳘"),l1l111_l1_ (u"ࠩࠪ㳙"),l1l111_l1_ (u"ࠪࠫ㳚"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪ㳛"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡔࡷࡥࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㳜"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬ㳝") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮࠳ࠧ㳞"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"ࠨࠢࠪ㳟"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳠"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㳡"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㳢"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㳣"),url,l1l111_l1_ (u"࠭ࠧ㳤"),l1l111_l1_ (u"ࠧࠨ㳥"),l1l111_l1_ (u"ࠨࠩ㳦"),l1l111_l1_ (u"ࠩࠪ㳧"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㳨"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㳩"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ㳪"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㳫"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㳬"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㳭"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳮"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ㳯")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭㳰"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤࡳ࡯ࡷ࡫ࡨࡷ࠴࠭㳱"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ㳲"),l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ㳳"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㳴"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ㳵"),l1l111_l1_ (u"ࠪࠫ㳶"),l1l111_l1_ (u"ࠫࠬ㳷"),l1l111_l1_ (u"ࠬ࠭㳸"),l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㳹"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㳺"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡕ࡫ࡷࡰࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࡴ࡫ࡧࡩࡃ࠭㳻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ㳼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㳽")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ㳾")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡹࡥ࡭ࡣࡵࡽࠧ࠭㳿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ㴀"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ㴁"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭㴂")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"ࠩࠪ㴃")
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫ㴄")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㴅")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㴆")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㴇"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ㴈"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ㴉"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ㴊"),l1l111_l1_ (u"ࠪ࠯ࠬ㴋"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭㴌")+search
	l1lll11_l1_(url)
	return